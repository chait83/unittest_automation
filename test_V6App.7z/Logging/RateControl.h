#ifndef __RATE_CONTROL_H_INCLUDED__
#define __RATE_CONTROL_H_INCLUDED__

#include "TVTime.h"

#include "CMMDefines.h"
#include "V6Config.h"

#define ALIGN_SECOND	1
#define ALIGN_MINUTE	2
#define ALIGN_15_MINUTE	3
#define ALIGN_HOUR		4

const LONGLONG ONE_SECOND_IN_uS = 1000000;
const LONGLONG ONE_MINUTE_IN_uS = (ONE_SECOND_IN_uS * 60);
const LONGLONG FIFTEEN_MINUTE_IN_uS = (ONE_MINUTE_IN_uS * 15);
const LONGLONG ONE_HOUR_IN_uS = (ONE_MINUTE_IN_uS * 60);

//**Class*********************************************************************
///
/// @brief 
/// 
///
//****************************************************************************

class CRateControl {
public:
	CRateControl();
	~CRateControl();

	BOOL Initialise(T_PLOGGING pLogging);				///< Initialise
	void ChangeRate(BOOL IsAlarmRateRequired);		///< Ste/Change the logging rate divisor
	BOOL LogReading();									///< Log reading
	BOOL Start();										///< Start logging
	BOOL Stop();										///< Stop logging
	ULONG CurrentRate() {
		return m_CurrentRate;
	}
	;	///< Return the current log rate (in ms-tenths)
	BOOL IsAligned();									///< Allign start logging

	BOOL WaitingForAlignment() {
		return m_WaitingForAlignment;
	}
	;		///< TRUE if a log channel is waiting for alignment

	///@todo: test and review pending
	void CancelAlignment() {
		m_WaitingForAlignment = FALSE;
	}
	;		///< Cancel any pendint alignment

private:
	BOOL m_WaitingForAlignment;							///< TRUE if waiting for alignment
	ULONG m_CurrentRate;
	unsigned long m_Rate;								///< Currenl log rate
	unsigned long m_Counter;							///< Working log rate counter
	T_PLOGGING m_pLogging;								///< Pointer to logging configuration data

	CTVtime m_StartTime;
};

#endif // __RATE_CONTROL_H_INCLUDED__

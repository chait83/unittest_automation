/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 Data Transferutilities
/// @n LogConfiguration.cpp
/// @n Wrapper for extracting base configuration and any configuration changes.
/// @author MM
/// @date 11/04/2005
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
//  11  Stability Project 1.6.1.3 7/2/2011 4:58:24 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  10  Stability Project 1.6.1.2 7/1/2011 4:38:27 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  9 Stability Project 1.6.1.1 3/17/2011 3:20:27 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  8 Stability Project 1.6.1.0 2/15/2011 3:03:14 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////

#include "LogConfiguration.h"

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif

//****************************************************************************
/// DataTransfer utility: class constructor
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************

CLogConfiguration::CLogConfiguration() {
	return;
}

//****************************************************************************
/// DataTransfer utility: class destructor
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
CLogConfiguration::~CLogConfiguration() {
	return;
}

//****************************************************************************
/// DataTransfer utility: request base configuration for a session
///
/// @param[in]		Session		- Required LCF session
/// @param[in]		FileAndPath - Target path and file
///
/// @return			LCMERROR
///
/// @note --- Delete if not requried ---
//****************************************************************************
LCMERROR CLogConfiguration::GetBaseConfiguration(DWORD Session, QString FileAndPath) {
	return ReCreateLCF(Session, 0, FileAndPath, FALSE);
}

//****************************************************************************
/// DataTransfer utility: request configuration changes between two sessions
///
/// @param[in]		StartSession	- Configuration span start session
/// @param[in]		EndSession		- Configuration span end session
/// @param[in]		FileAndPath		- Target path and file
///
/// @return			LCMERROR
///
/// @note --- Delete if not requried ---
//****************************************************************************
LCMERROR CLogConfiguration::GetConfigurationChanges(DWORD StartSession, DWORD EndSession, QString FileAndPath) {
	BOOL bSpan = TRUE;

	// If a session span is not required...
	if (StartSession == EndSession)
		bSpan = FALSE;

	return ReCreateLCF(StartSession, EndSession, FileAndPath, bSpan);
}

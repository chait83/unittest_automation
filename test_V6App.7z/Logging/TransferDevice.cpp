/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 Data Transferutilities
/// @n TransferDevice.cpp
/// @n Wrapper class for a data transfer target device.
/// @author MM
/// @date 11/04/2005
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
//  26  Stability Project 1.21.1.3 7/2/2011 5:02:10 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  25  Stability Project 1.21.1.2 7/1/2011 4:39:02 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  24  Stability Project 1.21.1.1 3/17/2011 3:20:51 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  23  Stability Project 1.21.1.0 2/15/2011 3:04:06 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////

#include "TransferDevice.h"
#include "V6globals.h"
#include "MediaManager.h"
#include "StringUtils.h"

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif

/// Static Initialisation
const ULONG CTransferDevice::ms_ulFREE_SPACE_MIN_KB = 512;

//****************************************************************************
/// DataTransfer utility: class constructor
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
CTransferDevice::CTransferDevice() {
	memset(&m_DeviceName[0], '\0', MAX_PATH * sizeof(WCHAR));
}

//****************************************************************************
/// DataTransfer utility: class initialisation
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
void CTransferDevice::Initialise() {
	m_pTransferStatus = CLogDeviceStatus::GetHandle();
	m_pTransferStatus->Initialise();
	m_deviceID = LOGDEV_EXT_SD;

	return;
}

//****************************************************************************
/// DataTransfer utility: class destructor
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
CTransferDevice::~CTransferDevice() {
	m_pTransferStatus->Cleanup();
	return;
}

//****************************************************************************
/// DataTransfer utility: set device ID
///
/// @param[in]		deviceID device Identity (see T_LOG_DEVICE)
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
void CTransferDevice::SetID(T_LOG_DEVICE deviceID) {
	int MaxLen = MAX_PATH;
	m_deviceID = deviceID;
	WCHAR Folder[64];
	DWORD SerialNumber = pGlbSysInfo->GetSerialNumber();

	memset(Folder, '\0', 64 * sizeof(WCHAR));
	swprintf(Folder, L"R0%06.6u.TV6", SerialNumber);
	memset(m_DeviceName, '\0', MAX_PATH * sizeof(WCHAR));
	memset(m_FolderName, '\0', MAX_PATH * sizeof(WCHAR));

	// Set base device name
	switch (deviceID) {
	case LOGDEV_FTP:
		pDALGLB->BuildPath(IDS_INTERNAL_SD, IDS_FTP_BUFFER, NULL, m_DeviceName, MAX_PATH);
		wcscpy_s(m_FolderName, sizeof(m_FolderName) / sizeof(WCHAR), m_DeviceName);
		break;
	case LOGDEV_EXT_SD:
		pDALGLB->GetPath((T_STORAGE_PATH) IDS_EXTERNAL_SD, m_DeviceName, sizeof(m_DeviceName) / sizeof(WCHAR), &MaxLen);
		wcscpy_s(m_FolderName, sizeof(m_FolderName) / sizeof(WCHAR), m_DeviceName);
		wcscat_s(m_FolderName, sizeof(m_FolderName) / sizeof(WCHAR), Folder);
		break;
	case LOGDEV_USB1:
		pDALGLB->GetPath((T_STORAGE_PATH) IDS_FIRST_USB, m_DeviceName, sizeof(m_DeviceName) / sizeof(WCHAR), &MaxLen);
		wcscpy_s(m_FolderName, sizeof(m_FolderName) / sizeof(WCHAR), m_DeviceName);
		wcscat_s(m_FolderName, sizeof(m_FolderName) / sizeof(WCHAR), Folder);
		break;
	case LOGDEV_USB2:
		pDALGLB->GetPath((T_STORAGE_PATH) IDS_SECOND_USB, m_DeviceName, sizeof(m_DeviceName) / sizeof(WCHAR), &MaxLen);
		wcscpy_s(m_FolderName, sizeof(m_FolderName) / sizeof(WCHAR), m_DeviceName);
		wcscat_s(m_FolderName, sizeof(m_FolderName) / sizeof(WCHAR), Folder);
		break;
	case LOGDEV_SHARE: {
		CCommsSetupConfig *pkCommsConfig = pGlbSetup->GetCommsSetupConfig();

		if (pkCommsConfig != NULL) {
			T_PCOMMUNICATIONS ptCommsData = pkCommsConfig->GetCommsBlock(CONFIG_MODIFIABLE);
			if (ptCommsData != NULL) {
				T_LANINFO *ptLanInfo = &ptCommsData->LanInfo;
				CStringUtils::SafeWcsCpy(m_DeviceName, ptLanInfo->sharePath, MAX_PATH);
				wcsncat(m_DeviceName, sizeof(m_DeviceName) / sizeof(WCHAR), L"\\", MAX_PATH - wcslen(m_DeviceName));
			}
		}
		CStringUtils::SafeWcsCpy(m_FolderName, m_DeviceName, MAX_PATH);
		wcsncat(m_FolderName, sizeof(m_FolderName) / sizeof(WCHAR), Folder, MAX_PATH - wcslen(m_FolderName));
	}

		break;
	default:
		break;
	}
}

//****************************************************************************
/// DataTransfer utility: get device ID
///
/// @return			device ID
///
/// @note --- Delete if not requried ---
//****************************************************************************
T_LOG_DEVICE CTransferDevice::GetID() const {
	return m_deviceID;
}

//****************************************************************************
/// DataTransfer utility: get device base path/name
///
/// @return			WCHAR* device name
///
/// @note --- Delete if not requried ---
//****************************************************************************
WCHAR* CTransferDevice::GetDeviceName() {
	return m_DeviceName;
}

//****************************************************************************
/// DataTransfer utility: get device full storage path
///
/// @return			WCHAR* device name
///
/// @note --- Delete if not requried ---
//****************************************************************************
WCHAR* CTransferDevice::GetFolderName() {
	return m_FolderName;
}

//****************************************************************************
/// DataTransfer utility: open a device for data transfer
///
/// @return			TRUE if the device is ready, else FALSE
///
/// @note for a USB storage device the drive enumeration could be swapped
/// over a power cycle, opening the device will need to sort this so we can
/// talk to the device by type not by name.
//****************************************************************************
BOOL CTransferDevice::OpenDevice() {
	BOOL bResult = TRUE;

	return bResult;
}

//****************************************************************************
/// DataTransfer utility: close a device after data transfer
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
BOOL CTransferDevice::CloseDevice() {
	return TRUE;
}

//****************************************************************************
/// DataTransfer utility: open a file on the data transfer device
///
/// @param[in]		filename - complete file and path
/// @param[in]		flags - file open/create flags (see QFile::open() for details)
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
CStorage* CTransferDevice::OpenFile(QString filename, UINT flags) {
	return NULL;
}

//****************************************************************************
/// DataTransfer utility: close a file on the data transfer device
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
BOOL CTransferDevice::CloseFile(CStorage *file) {

	return TRUE;
}

//****************************************************************************
/// DataTransfer utility: write data to a file on the data transfer device
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
BOOL CTransferDevice::Write(CStorage *file, void *buffer, UINT size) {
	return TRUE;
}

//****************************************************************************
/// DataTransfer utility: read data from a file on the data transfer device
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
BOOL CTransferDevice::Read(CStorage *file, void *buffer, UINT size) {
	return TRUE;
}

//****************************************************************************
/// DataTransfer utility: delete an existing file (by name)
///
/// @param[in]		filename - complete file and path
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
void CTransferDevice::Delete(QString filename) {
	return;
}

//****************************************************************************
/// DataTransfer utility: delete a folder and its contents (recursive)
///
/// @param[in]		filename - base path
///
/// @return			none
///
/// @note Used to delete all the files on a storage device, so use with care!
/// This method used recursion when a folder is found.
//****************************************************************************
void CTransferDevice::DelTree(QString path) {
	HANDLE hSearch;
	WIN32_FIND_DATA indexOfData;

	// Open file search
	hSearch = ::indexOfFirstFile(path, &indexOfData);
	if ( INVALID_HANDLE_VALUE != hSearch) {
		do {
			// Build a full file/folder path
			WCHAR FullName[MAX_PATH];
			memset(FullName, '\0', MAX_PATH * sizeof(WCHAR));

			wcsncpy_s(FullName, MAX_PATH, path, _TRUNCATE);
			wcsncat(FullName, MAX_PATH, L"\\", MAX_PATH - wcslen(FullName));
			if ((indexOfData.dwFileAttributes && FILE_ATTRIBUTE_DIRECTORY) != 0) {
				// File is a folder, delete the content
				wcsncat(FullName, MAX_PATH, L".", MAX_PATH - wcslen(FullName));
				DelTree(FullName);

				// restore the folder name so we can delete it
				memset(FullName, '\0', MAX_PATH * sizeof(WCHAR));

				wcsncpy_s(FullName, MAX_PATH, path, _TRUNCATE);
				wcsncat(FullName, MAX_PATH, L"\\", MAX_PATH - wcslen(FullName));
			}

			// create the full path and file name for deletion
			wcsncat(FullName, MAX_PATH, indexOfData.cFileName, MAX_PATH - wcslen(FullName));
			Delete(FullName);
		}
		// repeat until the search fails; if the failure was due to something
		// other than no more files, garbage will be left!
		while (indexOfNextFile(hSearch, &indexOfData) != 0);

		indexOfClose(hSearch);
	}
}

//****************************************************************************
/// DataTransfer utility: get device specific data transfer status
///
/// @param[in]		instance - log channel instance (zero based)
/// @param[in]		type - status type
///
/// @return			block location struct
///
/// @note --- Delete if not requried ---
//****************************************************************************
T_QMC_FILE_BLOCK_TRANSACTION* CTransferDevice::GetTransferStatus(USHORT instance, T_STATUS_TYPE type) {
	return m_pTransferStatus->GetStatus(m_deviceID, instance, type);
}

//****************************************************************************
/// DataTransfer utility: set device specific data transfer status
///
/// @param[in]		instance - log channel instance (zero based)
/// @param[in]		type - status type
/// @param[in]		location - status (block location)
///
/// @return			always TRUE
///
/// @note --- Delete if not requried ---
//****************************************************************************
BOOL CTransferDevice::SetTransferStatus(USHORT instance, T_STATUS_TYPE type, T_QMC_FILE_BLOCK_TRANSACTION location) {
	m_pTransferStatus->SetStatus(m_deviceID, instance, type, location);

	return TRUE;
}

///@todo Move to V6defines.h
// Internal media reserved space
#define FTP_RESERVED	2000000

//****************************************************************************
/// DataTransfer utility: get storage size of the device
///
/// @return			The available free space in KB
///
/// @note --- Delete if not requried ---
//****************************************************************************
ULONG CTransferDevice::GetAvailableSpace() {
	ULONG FreeSpace = 0L;

	switch (GetID()) {
	case LOGDEV_FTP:
		FreeSpace = GetDeviceFreeSpace();
		// If 
		if (FreeSpace > FTP_RESERVED)
			FreeSpace -= FTP_RESERVED;
		else
			FreeSpace = 0;
		break;
	case LOGDEV_EXT_SD:
		FreeSpace = GetDeviceFreeSpace();
		break;
	case LOGDEV_USB1:
		FreeSpace = GetDeviceFreeSpace();
		break;
	case LOGDEV_USB2:
		FreeSpace = GetDeviceFreeSpace();
		break;
	case LOGDEV_SHARE:
		FreeSpace = GetDeviceFreeSpace();
		break;
	default:
		break;
	}
	return FreeSpace;
}

//****************************************************************************
/// DataTransfer utility: get data transfer device size in KB
///
/// @return			The device size in KB
///
//****************************************************************************
const ULONG CTransferDevice::GetDeviceSize() const {
	ULONG TotalKBytes = 0;

	CMediaManager *pkMediaManager = CMediaManager::GetHandle();
	CLogDeviceStatus *pkDeviceStatus = CLogDeviceStatus::GetHandle();

	TotalKBytes = pkMediaManager->GetTotalSizeK(pkDeviceStatus->LogDeviceToStorageDevice(GetID()));

	return TotalKBytes;
}
//****************************************************************************
/// DataTransfer utility: get data transfer device used space
///
/// @return			The device used space in KB
///
/// @note --- Delete if not requried ---
//****************************************************************************
const ULONG CTransferDevice::GetDeviceUsedSpace() const {
	ULONG TotalFreeKBytes = 0;
	ULONG TotalKBytes = 0;

	CMediaManager *pkMediaManager = CMediaManager::GetHandle();
	CLogDeviceStatus *pkDeviceStatus = CLogDeviceStatus::GetHandle();

	TotalFreeKBytes = pkMediaManager->GetFreeSpaceK(pkDeviceStatus->LogDeviceToStorageDevice(GetID()));
	TotalKBytes = pkMediaManager->GetTotalSizeK(pkDeviceStatus->LogDeviceToStorageDevice(GetID()));

	return TotalKBytes - TotalFreeKBytes;
}

//****************************************************************************
/// DataTransfer utility: get data transfer device free space
///
/// @return			ULONG number of KB free
///
/// @note --- Delete if not requried ---
//****************************************************************************
const ULONG CTransferDevice::GetDeviceFreeSpace() const {
	CMediaManager *pkMediaManager = CMediaManager::GetHandle();
	CLogDeviceStatus *pkDeviceStatus = CLogDeviceStatus::GetHandle();

	ULONG ulFreeSpace = 0;

	ulFreeSpace = pkMediaManager->GetFreeSpaceK(pkDeviceStatus->LogDeviceToStorageDevice(GetID()));

	return ulFreeSpace;
}


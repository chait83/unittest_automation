#ifndef __BLOCK_CONTROL_H_INCLUDED__
#define __BLOCK_CONTROL_H_INCLUDED__

#include "TVTime.h"

#include "CMMDefines.h"
#include "V6Config.h"
#include "QueueManager.h"
#include "LogControl.h"

typedef enum {
	BLOCK_NEW,					///< Block allocated but as yet un-used
	BLOCK_IN_USE,				///< Block being filled
	BLOCK_COMPLETE,				///< Complete block committed for storage
	BLOCK_INCRC					///< Block CRC being calculated
} T_BLOCK_STATE;

typedef enum {
	BLOCK_OK,					///< Block OK to continue
	BLOCK_INCOMPLETE,			///< Block complete and flush required
	BLOCK_ERROR					///< Initialisation error?
} T_BLOCK_INIT;

//**Class*********************************************************************
///
/// @brief 
/// 
///
//****************************************************************************

static
unsigned long ulBlockCount;

class CBlockControl {
public:
	CBlockControl();
	~CBlockControl();

	T_BLOCK_INIT Initialise(T_PLOGGING pLogging, USHORT Instance);			/// Initialise
	void* RequestNew();							/// Request a new data block
	void* CurrentBlock() {
		return m_DataBlock;
	}
	;
	void FlushLastBlock(USHORT Instance);
	USHORT GetQueueHandle() {
		return m_QueueHandle;
	}
	;

	// Queue/block status wrappers
	void SetState(T_BLOCK_STATE blockState);
	T_BLOCK_STATE GetState();

	// Block counting stuff, used to monitor block useage
	static unsigned long GetBlockCount() {
		return ulBlockCount;
	}
	;
	static void ClearBlockCount() {
		ulBlockCount = 0;
	}
	;
	static void UpdateBlockCount() {
		ulBlockCount++;
	}
	;

private:
	T_PLOGGING m_pLogging;							/// Pointer to logging configuration data
	BOOL m_UsingCache;								/// Using cache block flag

protected:
	CQueueManager *mpq_manager;
	USHORT m_QueueHandle;							/// Block queue handle
	void *m_DataBlock;								/// Pointer to the current allocated NV data block
	CQMDataBlock m_QueueBlock;						/// current queue block object
};

#endif // __BLOCK_CONTROL_H_INCLUDED__

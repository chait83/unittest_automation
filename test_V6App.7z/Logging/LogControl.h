#ifndef __LOG_CONTROL_H_INCLUDED__
#define __LOG_CONTROL_H_INCLUDED__

#include "TVTime.h"
#include "LogRec.h"

#include "DataItemBase.h"
#include "DataItemPen.h"

#include "CMMDefines.h"
#include "V6Config.h"

#include "BasicMaxMinAve.h"

//**Class*********************************************************************
///
/// @brief 
/// 
///
//****************************************************************************

class CLogControl: public CLogRec {
public:
	CLogControl();
	~CLogControl();
	BOOL Initialise(USHORT Session, ULONG Sequence, USHORT Pen, ULONG Rate, T_LOGRECORD *pLogRecord,
			T_TV5TIME TimeStamp, T_PLOGGING pLogging);					/// Initialise log control
	BOOL RateChange(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, WORD Adjust, DWORD NewRate);/// Log rate change (Short time adjustment)
	BOOL RateChange(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, DWORD Adjust, DWORD NewRate);	/// Log rate change (Long time adjustment)
	BOOL TimeChange(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, WORD Adjust);	/// Short time adjustment
	BOOL TimeChange(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, DWORD Adjust);	/// Long time adjustment
	void Complete(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, T_TV5TIME *TimeStamp);/// Complete/flush the currenl log block
	BOOL Log(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, CDataItem *pDataItem, CBasicMaxMin *pMaxMin,
			CBasicAverage *pAverage);				/// Log a reading
	BOOL PowerRecovery(void);						/// Recover from a power failure

	BOOL IsContinuous() {
		return (LOGTYPE_CONTINUOUS == m_pLogging->LogType) ? TRUE : FALSE;
	}
	;
	void SetReason(USHORT Reason) {
		m_Reason = Reason;
	}
	;

	void SetZeroAndSpan(float zero, float span) {
		m_penZero = zero;
		m_penSpan = span;
	}
	;

	T_FUZZY_CONTROL FuzzyControl;
private:

	USHORT m_Reason;					/// Current (new) block reason code
	T_PLOGGING m_pLogging;				/// Pointer to logging configuration data
};

#endif // __LOG_CONTROL_H_INCLUDED__

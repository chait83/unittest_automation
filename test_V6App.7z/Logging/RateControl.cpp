/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 Log record utilities
/// @n RateControl.cpp
/// @n Utilities for maintaining log rate.
/// @author MM
/// @date 15/03/2005
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
//  25  Stability Project 1.20.1.3 7/2/2011 5:00:06 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  24  Stability Project 1.20.1.2 7/1/2011 4:38:47 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  23  Stability Project 1.20.1.1 3/17/2011 3:20:40 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  22  Stability Project 1.20.1.0 2/15/2011 3:03:49 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////

#include "TVTime.h"
#include "LogRec.h"

#include "RateControl.h"
#include "TraceDefines.h"
#include "V6globals.h"
#include "RecSetupCfgMgr.h"

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif

const int START_LOG_IMMEDIATELY = 1;
const int START_LOG_NEXT_CYCLE = 2;

//****************************************************************************
/// LogRecord utility: class constructor
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************

CRateControl::CRateControl() {
	m_WaitingForAlignment = TRUE;
	m_pLogging = NULL;
	return;
}

//****************************************************************************
/// LogRecord utility: class destructor
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
CRateControl::~CRateControl() {
	return;
}

//****************************************************************************
/// LogRecord utility: class initialisation
///
/// @param[in]		pLogging pointer to logging configuration data
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
BOOL CRateControl::Initialise(T_PLOGGING pLogging) {
	m_pLogging = pLogging;
	ChangeRate(FALSE);
	return TRUE;
}

//****************************************************************************
/// LogRecord utility: change log rate
///
/// @param[in]	IsAlarmRateRequired - TRUE if alarm rate, otherwise FALSE
///
/// @return		none
///
//****************************************************************************
void CRateControl::ChangeRate(BOOL IsAlarmRateRequired) {
	int rateToUse = CLogRec::GetLogRate(*m_pLogging);		// Set to Standard Pen rate
	// If alarm rate required, update rate to be the Alarm rate

	if (IsAlarmRateRequired) {
		rateToUse = CLogRec::GetAlarmLogRate(*m_pLogging);

		// If the pen is waiting for alignment to start, ignore the align and just start at the alarm rate (CR2025)
		if (m_WaitingForAlignment)
			m_WaitingForAlignment = FALSE;
	}
	// Calculate the divide down value for logging at the current processing rate;
	m_Rate = MSEC_TENTHS_TO_TICKS(rateToUse) / pSYSTIMER->GetCurrentProcessInterval();
	// Calculate the *actual* log rate (may be faster then requested rate)
	m_CurrentRate = pSYSTIMER->GetCurrentProcessInterval() * m_Rate * 100;

	m_Counter = START_LOG_IMMEDIATELY;
}

//****************************************************************************
/// LogRecord utility: Divide down logging rate to match process rates
///
/// @return		TRUE when reading needs to be logged, else FALSE
///
//****************************************************************************
BOOL CRateControl::LogReading() {
	BOOL bResult = FALSE;
	// Divide down counter to derive log rate from current process rate
	if (IsAligned()) {
		if (--m_Counter <= 0) {
			// Time to log reset the counter and return TRUE 
			m_Counter = m_Rate;
			bResult = TRUE;
		}
	}
	return bResult;
}

//****************************************************************************
/// LogRecord utility: start logging
///
/// @return		always TRUE
///
/// @note where aligned logging is required, the start (process) time will be 
/// calculated and stored, this is to minimise processor useage on data processing/logging
//****************************************************************************
BOOL CRateControl::Start() {
	m_WaitingForAlignment = FALSE;

	if (NULL != m_pLogging && 0 != m_pLogging->Align && LOGTYPE_FUZZY != m_pLogging->LogType) {
		m_WaitingForAlignment = TRUE;						// alignment required but not yet satisfied

		// alignment required, calculate start time...
		CTVtime ProcessTime;
		ProcessTime = pSYSTIMER->GetCurrentProcessTimeRef();

		// Calculate alignment and add offset to m_StartTime.
		///@todo: MM enable when re-aligned logging alignment is required.
#if 0
		LONGLONG alignTimeUSec = 0L;

		switch ( m_pLogging->Align )
		{
		case ALIGN_SECOND:
			alignTimeUSec = ONE_SECOND_IN_uS;
			break;
		case ALIGN_MINUTE:
			alignTimeUSec = ONE_MINUTE_IN_uS;
			break;
		case ALIGN_15_MINUTE:
			alignTimeUSec = FIFTEEN_MINUTE_IN_uS;
			break;
		case ALIGN_HOUR:
			alignTimeUSec = ONE_HOUR_IN_uS;
			break;
		default:
			m_WaitingForAlignment = FALSE;			// Unknown alignment, ignore.
			break;
		}
		LONGLONG timeOffset = 0L;

		m_StartTime = ProcessTime.GetMicroSecs( ) - ( ProcessTime.GetMicroSecs() % alignTimeUSec );
		m_StartTime = m_StartTime.GetMicroSecs( ) + alignTimeUSec;

		if ( (m_StartTime.GetMicroSecs( ) - ProcessTime.GetMicroSecs( )) > (m_CurrentRate * 100) )
		{
			timeOffset = (m_StartTime.GetMicroSecs( ) - ProcessTime.GetMicroSecs( )) % (m_CurrentRate * 100);
		}
		m_StartTime = ProcessTime.GetMicroSecs( ) + timeOffset;

#else
		switch (m_pLogging->Align) {
		case ALIGN_SECOND:
			m_StartTime = ProcessTime.GetMicroSecs() - (ProcessTime.GetMicroSecs() % ONE_SECOND_IN_uS);
			m_StartTime = m_StartTime.GetMicroSecs() + (ONE_SECOND_IN_uS);
			break;
		case ALIGN_MINUTE:
			m_StartTime = ProcessTime.GetMicroSecs() - (ProcessTime.GetMicroSecs() % ONE_MINUTE_IN_uS);
			m_StartTime = m_StartTime.GetMicroSecs() + (ONE_MINUTE_IN_uS);
			break;
		case ALIGN_15_MINUTE:
			m_StartTime = ProcessTime.GetMicroSecs() - (ProcessTime.GetMicroSecs() % FIFTEEN_MINUTE_IN_uS);
			m_StartTime = m_StartTime.GetMicroSecs() + (FIFTEEN_MINUTE_IN_uS);
			break;
		case ALIGN_HOUR:
			m_StartTime = ProcessTime.GetMicroSecs() - (ProcessTime.GetMicroSecs() % ONE_HOUR_IN_uS);
			m_StartTime = m_StartTime.GetMicroSecs() + (ONE_HOUR_IN_uS);
			break;
		default:
			m_WaitingForAlignment = FALSE;			// Unknown alignment, ignore.
			break;
		}
#endif
	}
	m_Counter = START_LOG_IMMEDIATELY;

	return TRUE;
}

//****************************************************************************
/// LogRecord utility: stop logging
///
/// @return		always TRUE
///
/// @note only required to cancel any previous logging alignment
//****************************************************************************
BOOL CRateControl::Stop() {
	m_WaitingForAlignment = TRUE;						// Any alignment not yet satisfied
	return TRUE;
}

//*******************************************************************************************************
/// LogRecord utility: Log start alignment
///
/// @return	BOOL TRUE if the reading alignment has been met, else FALSE
///
/// @note 
//*******************************************************************************************************

BOOL CRateControl::IsAligned() {
	BOOL bResult = TRUE;

	// check if any alignment is required
	if (NULL != m_pLogging && 0 != m_pLogging->Align) {
		if ( TRUE == m_WaitingForAlignment) {
			CTVtime ProcessTime;
			ProcessTime = pSYSTIMER->GetCurrentProcessTimeRef();

			if (ProcessTime >= m_StartTime)
				m_WaitingForAlignment = FALSE;
			else
				bResult = FALSE;
		}
	}
	return bResult;
}

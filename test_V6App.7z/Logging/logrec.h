#ifndef __LOGREC_H_INCLUDED__
#define __LOGREC_H_INCLUDED__

#include "TVTime.h"
#include "CMMDefines.h"
#include "V6Config.h"

#ifndef __TV5TIME_C_FUNCTIONS__
// Don't define __TV5TIME_C_FUNCTIONS, wait until later in this header file
// where they are actually implemented.
inline void AddPosmstenths(struct TV5Time *t1, ULONG mstenths);
inline void Addmstenths(struct TV5Time *t1, long mstenths);
inline void SubPosmstenths(struct TV5Time *t1, ULONG mstenths);
inline long Diffmstenths(struct TV5Time *t1, struct TV5Time *t2);
inline void TimeAdd(struct TV5Time *t1, struct TV5Time *t2);
inline void TimeSub(struct TV5Time *t1, struct TV5Time *t2);
inline void TimeDiv(struct TV5Time *t1, USHORT div);
#endif __TV5TIME_C_FUNCTIONS__

//#pragma pack( push, logrec, 4 )

/***************************************
 Header Control Extra Info fields */

// Incomplete record flag
#define COMPLETE		0x00
#define INCOMPLETE	0x01 

// TrendView Data types

// See _logrec.c for the table of sizes of these below.
// DO NOT CHANGE THE ORDER

#define SAMPLE			0x00	// Single reading
#define AVERAGE				0x01	// Single reading
#define MAX					0x02	// Single reading
#define MIN					0x03	// Single reading
#define MAXMIN				0x04	// Double reading
#define TOTALS				0x05	
#define DIGITALS			0x06
#define DIGITALS_OVERVIEW 0x07

// external device data types
//#define RESERVED		0x00
#define EX_SHORT			0x01 // short (2 bytes)
#define EX_FLOAT			0x02 // float (4 bytes)
#define EX_DOUBLE			0x03 // double (8 bytes)
// -- MAXMINS BELOW --
#define EX_SHORT_MAXMIN	0x04 // short MaxMin (4 bytes)
#define EX_FLOAT_MAXMIN		0x05 // float MaxMin (8 bytes)
#define EX_DOUBLE_MAXMIN	0x06 // double MAxMin (16 bytes)
//#define RESERVED		0x07

/**************************************/
// return codes from LOGREC functions
#define RECORD_FULL	1
#define	LOEMAXMIN_FULL 2

#define OK_SAMPLE			0x00
#define OK_MAXMIN			0x01	
#define END_OF_DATA			0x02
#define END_OF_DATA_LOEMAXMIN 0x04

//////////////////////////////////////////////////////////////
// DO NOT CHANGE THE ORDER OF THE FOLLOWING !!!!
// See _logrec.c for the table of sizes 

//TrendView Control Types (for continuous logging)
//#define RESERVED		0x00
#define TV5HEADER			0x01 // also ABSOLUTE
#define TV5ADJUST_SHORT		0x02 
#define TV5ADJUST_LONG		0x03
//#define RESERVED		0x04
//#define RESERVED		0x05
#define TV5RATE_SHORT		0x06 // adjust + rate
#define TV5RATE_LONG		0x07 // adjust + rate

//TrendView Control Types (for log on event)
//#define RESERVED		0x00
#define TV5HEADER_LOE_SHT	0x01
#define TV5HEADER_LOE_LNG	0x02
#define TV5LOE_SHT			0x03 // short log on event
#define TV5LOE_LNG			0x04 // long log on event
#define TV5FUZZY			0x05 // Fuzzy Logging
//#define RESERVED		0x06
//#define RESERVED		0x07
//////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////
// Configuration constants, log type and style
#define LOGTYPE_CONTINUOUS	0
#define LOGTYPE_FUZZY		1

#define LOGSTYLE_SAMPLE		0
#define LOGSTYLE_AVERAGE	1
#define LOGSTYLE_MAXMIN		2

//////////////////////////////////////////////////////////////
// type of header control required (when initialising control)
// user friendly version of above
#define LOE_SHORT			TV5HEADER_LOE_SHT
#define LOE_LONG			TV5HEADER_LOE_LNG
#define FUZZY				TV5FUZZY

/***************************************
 Header Control Extra Info fields */

// Incomplete record flag
#define COMPLETE		0x00
#define INCOMPLETE	0x01 

// Device flag
#define TRENDVIEW_DEVICE 0x00
#define OTHER_DEVICE	0x01

// Reason for new record (values 0..7 only)

#define RESET_PWRFAIL	0x01	// Recovery after a power fail
#define SETUP_CHANGED	0x02	// Existing set-up changed by user
#define TIME_ADJUSTED	0x03	// Time adjust by FTP sync
#define START_RECORDING	0x04	// Start loggging by user
#define CONTINUATION	0x05	// Continuation block
#define SETUP_IMPORT	0x06	// New set-up loaded from disk
#define EVENT_LOGGING	0x07	// Start logging on an event

// Header Control block
// Found at the start of every log data record. Gives an absolute timestamp for the data
// that follows it. MUST NOT be embedded within the following data.

typedef struct {
	// Type bit-fields;	
	BYTE LastControl :1; // Set when the control is the last within the record 
	BYTE LogStyle :1;			// CONTINUOUS or VARIABLE 
	BYTE ControlType :3;			// TV5HEADER, TV5HEADER_LOE_SHT, TV5HEADER_LOE_LNG, TV5FUZZY
	BYTE DataType :3;			// asprintf and size of the following data values

	BYTE ToControl;			// No. of readings to next control or end of data
	// Extra Info bit-fields
	BYTE DatabaseLevel :3;	// Database overview level (1=raw log data)
	BYTE Reason :3;			// Reason for new record
	BYTE Device :1;		// TrendView device or other (toggles Datatype above)
	BYTE Incomplete :1;		// Record incomplete flag (exported before complete)

	BYTE PenNumber;			// Pen number (only used with comms data)
	T_TV5TIME StartTime; // Start time of the first reading in the record
	USHORT Session;			// Session Number
	ULONG Rate;				// Time increment between logs (in 10ths of ms)
	ULONG SeqNo;				// Sequence Number
	T_TV5TIME EndTime;	// End time of the last reading in the record
} T_HEADERCONTROL;

/*************************************/
// Internal Log Data asprintf (used throughout system by recorder and TMP)
/***************************************
 Control Type field defines	*/

// Last Control	flag
#define NO					0x00
#define YES					0x01

// Log style flag
#define CONTINUOUS			0x00
#define VARIABLE			0x01 

#define V6_SIZE_OF_DATA_PART 482
// ( 512 - ( sizeof(struct HeaderControl) + sizeof(USHORT) ) )

// (V6_SIZE_OF_DATA_PART / 3)
#define V5_FUZZY_LOG_POINTS		160		
// (V6_SIZE_OF_DATA_PART / 5)
#define V6_FUZZY_LOG_POINTS		95		
// (V6_SIZE_OF_DATA_PART / 4)
#define V6_READINGS_PER_BLOCK	120		

typedef struct {
	T_HEADERCONTROL Header;
	BYTE Data[V6_SIZE_OF_DATA_PART];
	WORD CRC;
} T_LOGRECORD;

// When a new control is found in the data part of a record, this struct should be 
// overlayed on to it to determine the ControlType. It may then be cast to the ControlType
// found, which could be an Absolute Control as above, but more likely to be those following.
typedef struct {
	// Type bit-fields;			
	BYTE LastControl :1;	// Set when the control is the last within the record 
	BYTE LogStyle :1;			// CONTINUOUS or VARIABLE 
	BYTE ControlType :3;		// Type of control = ANY
	BYTE DataType :3;			// asprintf and size of the following data values

	BYTE ToControl;			// No. of readings to next control or end of data
} T_GENERALCONTROL;

// Absolute Control
// Gives an absolute timestamp for the data that follows it.
// MUST NOT BE USED WITH LOG ON EVENT 
typedef struct {
	// Type bit-fields;	
	BYTE LastControl :1;			// Set when the control is the last within the record 
	BYTE LogStyle :1;			// CONTINUOUS or VARIABLE FUZZY
	BYTE ControlType :3;		// TV5HEADER, TV5FUZZY ONLY
	BYTE DataType :3;			// asprintf and size of the following data values

	BYTE ToControl;			// No. of readings to next control or end of data
	T_TV5TIME ABSTime;	// Absolute time of the next reading in the record
	ULONG Rate;				// Time increment between logs (in 10ths of ms)
} T_ABSOLUTECONTROL;

////////////////////////////////////
//
// Continuous specific controls 
//

// Long time adjust (up to 4.96 days) + Rate Control 
typedef struct {
	// Type bit-fields;			
	BYTE LastControl :1;				// Set when the control is the last within the record 
	BYTE LogStyle :1;			// CONTINUOUS ONLY
	BYTE ControlType :3;		// Type of control = TV5RATE_LONG 
	BYTE DataType :3;			// asprintf and size of the following data values

	BYTE ToControl;			// No. of readings to next control or end of data
	ULONG Rate;			// Set new time increment between logs (in 10ths of ms)
	ULONG Adjust;		// Time adjust from last reading at old rate to time of 
						// first reading at new rate.
} T_LONGRATECONTROL;

// Long time adjust (up to 4.96 days) Control 
typedef struct {
	// Type bit-fields;			
	BYTE LastControl :1;						// Set when the control is the last within the record 
	BYTE LogStyle :1;			// CONTINUOUS ONLY
	BYTE ControlType :3;		// Type of control = TV5ADJUST_LONG 
	BYTE DataType :3;			// asprintf and size of the following data values

	BYTE ToControl;			// No. of readings to next control or end of data
	ULONG Adjust;		// Time adjust from last reading at old rate to time of 
						// first reading at new rate.
} T_LONGCONTROL;

// Short time adjust (up to 6.5535 sec) + Rate Control 
typedef struct {
	// Type bit-fields;			
	BYTE LastControl :1;						// Set when the control is the last within the record 
	BYTE LogStyle :1;			// CONTINUOUS ONLY
	BYTE ControlType :3;		// Type of control = TV5RATE_SHORT 
	BYTE DataType :3;			// asprintf and size of the following data values

	BYTE ToControl;			// No. of readings to next control or end of data	
	ULONG Rate;			// Set new time increment between logs (in 10ths of ms)
	USHORT Adjust;		// Time adjust from last reading at old rate to time of 
						// first reading at new rate. 
} T_SHORTRATECONTROL;

// Short time adjust Control
typedef struct {
	// Type bit-fields;			
	BYTE LastControl :1;						// Set when the control is the last within the record 
	BYTE LogStyle :1;			// CONTINUOUS ONLY
	BYTE ControlType :3;		// Type of control = TV5ADJUST_SHORT 
	BYTE DataType :3;			// asprintf and size of the following data values

	BYTE ToControl;			// No. of readings to next control or end of data	
	USHORT Adjust;		// Time adjust from last reading at old rate to time of 
						// first reading at new rate.
} T_SHORTCONTROL;

////////////////////////////////////
//
// Log on Event specific controls 
//

// Long Log on Event Control
// with Absolute timestamp 
typedef struct {
	// Type bit-fields;			
	BYTE LastControl :1;						// Set when the control is the last within the record 
	BYTE LogStyle :1;			// VARIABLE LOG_ON_EVENT ONLY
	BYTE ControlType :3;		// Type of control = TV5LOE_LNG 
	BYTE DataType :3;			// asprintf and size of the following data values

	BYTE ToControl;			// No. of readings to next control or end of data
	T_TV5TIME ABSTime;	// Absolute time of the next reading in the record

} T_LONGLOECONTROL;

// Short Log on Event Control 
// with long absolute timestamp 
typedef struct {
	// Type bit-fields;			
	BYTE LastControl :1;	// Set when the control is the last within the record 
	BYTE LogStyle :1;			// VARIABLE LOG_ON_EVENT ONLY
	BYTE ControlType :3;		// Type of control = TV5LOE_SHT 
	BYTE DataType :3;			// asprintf and size of the following data values

	BYTE ToControl;			// No. of readings to next control or end of data
	T_TV5TIME ABSTime;	// Absolute time of the next reading in the record

} T_SHORTLOECONTROL;

typedef struct {
	BOOL QLockedForFlush;
	BOOL NewBlockRequested;
	T_LOGRECORD *pLogRecord;
} T_LOGQUEUE;

//#pragma pack( pop, logrec )

typedef struct {
	float Reading;
	UCHAR TimeOffset;
} T_FUZZY_READING;

/***************************************
 Datafile Log Record construction variables	
 Used during record creation
 */

typedef struct {
	short FreeDataPos;					// first free data point
	short DataSize;					// size of a reading (since last control)
	short TimeSize;
	short ExtraSize;
	T_GENERALCONTROL *CurrentControl;					// pointer to our last control (header or into data block)
	T_TV5TIME LastTime;					// start time of the last reading added
	ULONG Rate;					// rate of readings for continuous logging only

	// Fuzzy logging power recovery data
	UCHAR ReadingCount;			// number of reading that are within the pipe
	float PipeEnd;						// Pipe end reading

	T_FUZZY_READING MaxReading;			// Maximum reading

	T_FUZZY_READING MinReading;			// Minimum reading
	T_FUZZY_READING LastBandB;			// Last reading within band B
} T_LOGRECORDVARS;

// Fuzzy logging stuff

#define LOG_STATE_INITIAL	0
#define LOG_STATE_SECOND	1
#define LOG_STATE_RUNNING	2

#define FUZZY_BREAK			255

typedef struct {
	UCHAR Status;			// current fuzzy state

	float Direction;		// Direction of pipe
	float Prediction;		// Predicted next reading

	float PipeMax;			// Pipe next reading limits	
	float PipeMin;

//	UCHAR ReadingCount;		// number of reading that are within the pipe
//	float PipeEnd;			// Pipe end reading

	UCHAR UseAutoFit;		// parameters read from pen config
	UCHAR UseSecondBand;
	float FirstBand;		// calculated pipe values
	float SecondBand;

	// AutoFit stuff
	T_FUZZY_READING *LogPoint[3];

//	T_FUZZY_READING MaxReading;	// Maximum reading

//	T_FUZZY_READING MinReading;	// Minimum reading
//	T_FUZZY_READING LastBandB;	// Last reading within band B

	// Efficiency count stuff
	ULONG CycleCount;		// Number of readings
	ULONG PipeCount;		// Number of readings logged

	BOOL UpdateInProgress;
} T_FUZZY_CONTROL;

//**Class*********************************************************************
///
/// @brief Abstract the custom hardware
/// 
/// This class will provide utility methods for maintaining log records,
/// the format and structure of log records should not need to be known outside
/// this class; maintaining the (whole) blocks of data will be left to next 
/// level up, this class is purely concerned with maintaining the block content.
///
//****************************************************************************

class CLogRec {
public:
	CLogRec();
	~CLogRec();

	void Initialise();

	// Method that determines the required log rate
	static const ULONG GetLogRate(const T_LOGGING &rtLOGGING);

	// Method that determines the required alarm log rate
	static const ULONG GetAlarmLogRate(const T_LOGGING &rtLOGGING);

	void SetStartTime(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, T_TV5TIME *Time);

	BOOL AddContReading(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, USHORT reading);
	BOOL AddContReading(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, float reading);

	BOOL AddContTotal(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, double reading);

	BOOL AddContMaxMin(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, USHORT max, USHORT min);
	BOOL AddContMaxMin(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, float max, float min);

	BOOL AddLOEReading(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, T_TV5TIME *timestamp, USHORT reading);
	BOOL AddLOEReading(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, T_TV5TIME *timestamp, float reading);

	BOOL AddLOETotal(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, T_TV5TIME *timestamp, double reading);

	BOOL AddLOEMaxMin(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, T_TV5TIME *timestamp, USHORT max,
			USHORT min);
	BOOL AddLOEMaxMin(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, T_TV5TIME *timestamp, float max,
			float min);

	BOOL AddFuzzyReadingByTime(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, T_TV5TIME *timestamp,
			USHORT reading);
	BOOL AddFuzzyReadingByTime(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, T_TV5TIME *timestamp,
			float reading);

	BOOL AddFuzzyReadingByGap(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, UCHAR multiplier,
			USHORT reading);
	BOOL AddFuzzyReadingByGap(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, UCHAR multiplier,
			float reading);

	BOOL AddFuzzyReading(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, T_TV5TIME *timestamp,
			T_FUZZY_CONTROL *pFuzzyControl, USHORT Reading);
	BOOL AddFuzzyReading(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, T_TV5TIME *timestamp,
			T_FUZZY_CONTROL *pFuzzyControl, float Reading);

	void InitFuzzyControl(T_PLOGGING pLogging, T_FUZZY_CONTROL *pFuzzyControl);
	void ResetFuzzyControl(T_PLOGGING pLogging, T_FUZZY_CONTROL *pFuzzyControl);

	float FuzzyEfficiency(T_FUZZY_CONTROL *pFuzzyControl);
	float FuzzyPrediction(T_FUZZY_CONTROL *pFuzzyControl);

	BOOL PipeBreak(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, T_FUZZY_CONTROL *pFuzzyControl,
			USHORT Reading);
	BOOL PipeBreak(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, T_FUZZY_CONTROL *pFuzzyControl,
			float Reading);

	BOOL UpdatePipe(USHORT Reading, T_FUZZY_CONTROL *pFuzzyControl, T_LOGRECORDVARS *pLogRecordVars);
	BOOL UpdatePipe(float Reading, T_FUZZY_CONTROL *pFuzzyControl, T_LOGRECORDVARS *pLogRecordVars);

	BOOL UpdatePipeInvalid(float Reading, T_FUZZY_CONTROL *pFuzzyControl, T_LOGRECORDVARS *pLogRecordVars);

	BOOL CompleteFuzzyBlock(USHORT Reading, T_FUZZY_CONTROL *pFuzzyControl, T_LOGRECORDVARS *pLogRecordVars);
	BOOL CompleteFuzzyBlock(float Reading, T_FUZZY_CONTROL *pFuzzyControl, T_LOGRECORDVARS *pLogRecordVars);
	BOOL FlushFuzzyLogBlock(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, T_FUZZY_CONTROL *pFuzzyControl);

	BOOL SortmidpointReading(T_FUZZY_CONTROL *pFuzzyControl, T_LOGRECORDVARS *pLogRecordVars);

	BOOL AddDigitalMask(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, T_TV5TIME *timestamp, UCHAR *mask);

	BOOL AddDigital(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, T_TV5TIME *timestamp, UCHAR change);

	void CompleteLogBlock(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, T_TV5TIME *timestamp,
			UCHAR finalcomplete);

	BOOL AddControl(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, void *control);

	static BYTE BlockInstance(void *DataBlock);
	static USHORT BlockSession(void *DataBlock);		// Extract the session number from a log block
	static ULONG BlockSequence(void *DataBlock);		// Extract block sequence number

	static BOOL BlockTimespan(void *DataBlock, T_TV5TIME *starttime, T_TV5TIME *endtime);// extract the start and end time from a log block

	static USHORT GetHeaderSize();

	static LONGLONG GetStartTime(void *DataBlock);

protected:
//	T_FUZZY_CONTROL FuzzyControl;
	float m_penZero;					/// Pen zero, used for fuzzy calcs 
	float m_penSpan;					/// Pen span, used for fuzzy calcs 
};

// TBD
// Time utilities, need to be moved to time class...
//
// As log records are dealing with the physical storage of log data,
// they use time structures rather than time objects.
//
// Log records *could* be converted to use time objects, but this is 
// probably best left to the next level-up.
//

#ifndef __TV5TIME_C_FUNCTIONS__
#define __TV5TIME_C_FUNCTIONS__
/*********************************************************************
 Description - Adds a positive number of mstenths
 Parameters - pointers to time, and mstenths result returned in t1
 Returns - none
 *********************************************************************/
inline void AddPosmstenths(T_TV5TIME *t1, ULONG mstenths) {
	// t1+mstenths, returned in t1

	// TIME FORMATS
	// 2.5555 stored as 2 and 5555
	// -2.5555 stored as -2 and -5555
	// -0.1234 stored as 0 and -1234

	// mstenths could be entire range, (2^32) and is always UNSIGNED
	// t1->Fracs could be -9999 to 9999

	ULONG temp, temp2;

	if (t1->Fracs < 0) // if we have a -ve fractional part
			{
		if (mstenths >= (ULONG) (-t1->Fracs)) // if we are adding enough mstenths to make it >= 0 
			temp = mstenths - (ULONG) (-t1->Fracs); // then simply remove the -ve component
		else {
			t1->Fracs += (short) mstenths; // result will still be -ve, and seconds are unchanged
			return;						// so we are all done.
		}
	} else {
		if (mstenths < (4294957296)) // NB ^ is not "to the power" but Xor
			temp = (ULONG) t1->Fracs + mstenths; // room to simply add the mstenths
		else {
			temp = mstenths / 10000;
			t1->Secs += temp; // add on complete seconds
			temp = (ULONG) t1->Fracs + (mstenths - temp * 10000);
		}
	}

	// and normalise 

	if (temp > 99990) {
		temp2 = temp / 10000; // quicker for large increases
		t1->Secs += temp2;
		t1->Fracs = (short) (temp - temp2 * 10000); // remainder (more efficient than MOD)
		return;
	}

	while (temp > 9999) {
		temp -= 10000;
		t1->Secs++;
	}
	t1->Fracs = (short) temp;
}

/*********************************************************************
 Description - Adds a SIGNED number of mstenths
 Parameters - pointers to time, and mstenths result returned in t1
 Returns - none
 *********************************************************************/
inline void Addmstenths(T_TV5TIME *t1, long mstenths) {

	// mstenths CAN ONLY BE UP TO +/- 59.65 hours (eg in an adjust long control)
	// t1+mstenths, returned in t1

	// TIME FORMATS
	// 2.5555 stored as 2 and 5555
	// -2.5555 stored as -2 and -5555
	// -0.1234 stored as 0 and -1234

	ULONG temp;
	struct TV5Time t2;

	// create a TV5Time and put the mstenths in it. Then Add. 
	temp = mstenths / 10000; // do a division
	t2.Secs = temp;		// complete seconds
	t2.Fracs = (short) (mstenths - temp * 10000); // remainder (more efficient than MOD)
	TimeAdd(t1, &t2);
}

/*********************************************************************
 Description - Subtracts a positive number of mstenths
 Parameters - pointers to time, and mstenths result returned in t1
 Returns - none
 *********************************************************************/
inline void SubPosmstenths(T_TV5TIME *t1, ULONG mstenths) {
	// t1-mstenths, returned in t1

	// TIME FORMATS
	// 2.5555 stored as 2 and 5555
	// -2.5555 stored as -2 and -5555
	// -0.1234 stored as 0 and -1234

	// mstenths could be entire range, (2^32) and is always UNSIGNED

	ULONG temp;
	struct TV5Time t2;

	// create a TV5Time and put the mstenths in it. Then subtract. 
	temp = mstenths / 10000; // do a division
	t2.Secs = temp;		// complete seconds
	t2.Fracs = (short) (mstenths - temp * 10000); // remainder (more efficient than MOD)
	TimeSub(t1, &t2);
}

/*********************************************************************
 Description - Difference between two TV5Times, returned in mstenths
 Parameters - pointers to time, and mstenths result returned in t1
 Returns - Difference in mstenths OR 0 if over range
 *********************************************************************/
inline long Diffmstenths(T_TV5TIME *t1, struct TV5Time *t2) {
	struct TV5Time t3 = *t1; // copy t1
	TimeSub(&t3, t2);
	if (abs(t3.Secs) <= 214747) // check it doesn't exceed the max size for a long 
		return t3.Secs * 10000 + t3.Fracs;
	else
		return 0;
}

/****************************************************************
 Description - Adds one TV5Time from another
 Parameters - pointers to times, result returned in t1
 Returns - none
 ****************************************************************/
inline void TimeAdd(T_TV5TIME *t1, struct TV5Time *t2) {
	// Sum t1+t2, returned in t1

	// TIME FORMATS
	// 2.5555 stored as 2 and 5555
	// -2.5555 stored as -2 and -5555
	// -0.1234 stored as 0 and -1234

	t1->Secs += t2->Secs; // just add the seconds 
	t1->Fracs += t2->Fracs; // and the mstenths

	if ((t1->Fracs > 9999) || (t1->Fracs > 0) && (t1->Secs < 0)) {
		t1->Fracs -= 10000;	// take off 1 second 
		t1->Secs++; // and add it on.
	} else if ((t1->Fracs < -9999) || (t1->Fracs < 0) && (t1->Secs > 0)) {
		t1->Fracs += 10000; // add on 1 second 
		t1->Secs--;		// take off from here
	}
}

/****************************************************************
 Description - Subtracts one TV5Time from another
 Parameters - pointers to times, result returned in t1
 Returns - none
 ****************************************************************/
inline void TimeSub(T_TV5TIME *t1, struct TV5Time *t2) {
	// difference t1-t2, returned in t1

	// TIME FORMATS
	// 2.5555 stored as 2 and 5555
	// -2.5555 stored as -2 and -5555
	// -0.1234 stored as 0 and -1234

	t1->Secs -= t2->Secs; // just sub the seconds 
	t1->Fracs -= t2->Fracs; // and the mstenths

	if ((t1->Fracs > 9999) || (t1->Fracs > 0) && (t1->Secs < 0)) {
		t1->Fracs -= 10000;	// take off 1 second 
		t1->Secs++; // and add it on.
	} else if ((t1->Fracs < -9999) || (t1->Fracs < 0) && (t1->Secs > 0)) {
		t1->Fracs += 10000; // add on 1 second 
		t1->Secs--;		// take off from here
	}
}

/****************************************************************
 Description - Divides a TV5Time by an integer value (MAX 20000)
 Parameters - pointer to time, and USHORT to divide by result returned in t1
 Returns - none
 ****************************************************************/
inline void TimeDiv(T_TV5TIME *t1, USHORT div) {

	// Division t1/div, returned in t1

	// TIME FORMATS
	// 2.5555 stored as 2 and 5555
	// -2.5555 stored as -2 and -5555
	// -0.1234 stored as 0 and -1234

	long secs, fracs;

	if ((div == 0) || (div > 20000)) // don't attempt divide by 0 or by more than 20000
		return;
	secs = t1->Secs / div; // divide the seconds (integer division)

	fracs = (t1->Secs - (secs * div)) * 10000; // remainder from above, now in fracs

	if ((t1->Fracs < 0) || (t1->Secs < 0))
		t1->Fracs = (short) (((((t1->Fracs + fracs) * 10) / div) - 5) / 10); // and sort out fracs (including -ve rounding)
	else
		// +ve
		t1->Fracs = (short) (((((t1->Fracs + fracs) * 10) / div) + 5) / 10); // and sort out fracs (including +ve rounding)

	t1->Secs = secs;

}
#endif __TV5TIME_C_FUNCTIONS__

#endif // __LOGREC_H_INCLUDED__

/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 Log record utilities
/// @n TxScheduler.cpp
/// @n Real-time scheduler for the data transfer module.
/// @author MM
/// @date 25/10/2005
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
//  68  Aristos  1.62.1.3.1.0 9/19/2011 4:51:15 PM  Hemant(HAIL)  
//  Stability recorder source code (JI Release) updated for WatchDog
//  Timer functionality.
//  67  Stability Project 1.62.1.3 7/2/2011 5:02:14 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  66  Stability Project 1.62.1.2 7/1/2011 4:39:03 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  65  Stability Project 1.62.1.1 3/17/2011 3:20:52 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
// $
//
// 01	Vellaidurai.V		Fix for PAR - 1-2QM7HOT : Export Failed Message not logged if we configure Schedule export and do not keep any export Media
//////////////////////////////////////////////////////////////////////

#include "TxScheduler.h"
#include "ThreadInfo.h"
#include "ControlSequencer.h"
#include "V7DbgLogDefines.h"

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif

#ifdef THREAD_ID_SERIAL_LOG
	 extern ULONG glb_MsgCntLog;
#endif

CTxSchedule *CTxSchedule::pInstance = NULL;

QMutex CTxSchedule::m_ExportCS;

const DWORD CTxSchedule::ms_dwTIMEOUT_IN_MS = 20000;

const int WAIT_FOR_FLUSH_RETIRES = 20;		/// Wait for 100msec per retry so 2 seconds

const ULONG ulMinQueueTime = 1800;			/// seconds left in the data queues before starting an early schedule

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
CDebugFileLogger CTxSchedule::m_debugFileLogger(_T("\\SDMemory\\TxSchDbgLogFile.txt"), FALSE, (10*1024*1024));
CDebugFileLogger* CTScheduleThread::m_pDebugFileLogger = NULL;
#endif

// IMPLEMENT_DYNCREATE( CTScheduleThread, QThread )

BEGIN_MESSAGE_MAP( CTScheduleThread, QThread )
END_MESSAGE_MAP()

//****************************************************************************
/// Data transfer scheduler
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************

CTxSchedule::CTxSchedule(T_MODULE_ID moduleId )
: CV6ActiveModule(moduleId )
{
	SetState( TX_INITIALISE );
	m_Initialised = FALSE;
	m_SharedData.pMessageQueue = NULL;

	pInstance = this;

	m_ScheduleThread = NULL;

	InitializeCriticalSection(&CTxSchedule::m_ExportCS);

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
	SetDebugLogger(&m_debugFileLogger); //Set the defult static handler for this module
#endif

	return;
}
//****************************************************************************
// ~CTxSchedule(void)
///
/// Destructor
///
//****************************************************************************
CTxSchedule::~CTxSchedule() {
	DeleteCriticalSection(&CTxSchedule::m_ExportCS);
	delete m_ScheduleThread;
	m_ScheduleThread = NULL;
}
//****************************************************************************
/// Data transfer scheduler Get instance handle
///
/// @return			Pointer to the Active module, or NULL if it hasn't been created
///
/// @note Provided to get a handle on the DoTransfer method.
//****************************************************************************
CTxSchedule* CTxSchedule::GetHandle() {
	return pInstance;
}

//****************************************************************************
/// Data transfer scheduler Get transfer percentage
///
/// @return			Transfer percentage 0 - 100
///
/// @note 
//****************************************************************************
USHORT CTxSchedule::ProgressPercentage() {
	CDataTransfer *pDataTransfer = CDataTransfer::GetHandle();
	pDataTransfer->Initialise();

	return pDataTransfer->GetTransferPercentage();
}

//****************************************************************************
/// Data transfer scheduler Get transfer completion state
///
/// @return			TRUE when transfer is complete, else FALSE
///
/// @note 
//****************************************************************************
BOOL CTxSchedule::TransferComplete() {
	CDataTransfer *pDataTransfer = CDataTransfer::GetHandle();
	pDataTransfer->Initialise();

	return pDataTransfer->TransferComplete();
}

BOOL CTxSchedule::IsExportAborted() {
	BOOL bAborted = FALSE;
	CDataTransfer *pDataTransfer = CDataTransfer::GetHandle();
	if (pDataTransfer) {
		bAborted = pDataTransfer->IsExportAborted();
	}
	return bAborted;
}

//****************************************************************************
/// Data transfer scheduler
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE CTxSchedule::PerformPrimaryInitialisation(void) {
	T_V6ACTMOD_RETURN_VALUE retVal = V6ACTMOD_OK;

	return retVal;
}

//****************************************************************************
/// Data transfer scheduler
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE CTxSchedule::PerformSecondaryInitialisation(void) {
	T_V6ACTMOD_RETURN_VALUE retVal = V6ACTMOD_OK;

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
	QString  strDbgMsg;
	strDbgMsg.asprintf(_T("CTxSch::PerformSecondaryInitialisation begin m_Initialised %d"), m_Initialised);
	LogDebugMessage(strDbgMsg);
#endif

	if ( TRUE != m_Initialised) {
		m_Initialised = TRUE;

		m_SharedData.RequestStop = FALSE;
		m_SharedData.Seconds = 30;

		SetState(TX_INITIALISE);

		pm_DataTransfer = CDataTransfer::GetHandle();

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
		pm_DataTransfer->SetDebugLogger(m_pDebugFileLogger);
		#endif

		pm_DataTransfer->Initialise();

		// Create time scheduler thread
		m_ScheduleThread = AfxBeginThread(&CTScheduleThread::ThreadFunc, (void*) &m_SharedData, THREAD_PRIORITY_NORMAL, //THREAD_PRIORITY_BELOW_NORMAL, //, 
				0, CREATE_SUSPENDED, NULL);

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
		CTScheduleThread::SetDebugLogger(m_pDebugFileLogger);
		#endif

		qDebug(" TxScheduler thread started id:%x\n", m_ScheduleThread->m_nThreadID);
#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
		strDbgMsg.asprintf(_T("TxScheduler thread started id:%x"), m_ScheduleThread->m_nThreadID);
		LogDebugMessage(strDbgMsg);
		#endif

		m_SharedData.pMessageQueue = new CInternalMessageQueue;
		T_IMQ_RETURN_VALUE retValue = m_SharedData.pMessageQueue->InitInternalMessageQueue(1, 1024,
				m_ScheduleThread->m_nThreadID, IMQ_USE_MANUAL);
		if (IMQ_INITIALISED != retValue) {
			qDebug(" CTxSchedule: InitInternalMessageQueue returned %d\n", retValue);
#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
			strDbgMsg.asprintf(_T("CTxSchedule: InitInternalMessageQueue returned %d retVal %d"), retValue);
			LogDebugMessage(strDbgMsg);
			#endif
		}

		m_ScheduleThread->m_bAutoDelete = FALSE;
	}

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
	strDbgMsg.asprintf(_T("CTxSch::PerformSecondaryInitialisation end m_Initialised %d retVal %d"), m_Initialised, retVal);
	LogDebugMessage(strDbgMsg);
#endif

	return retVal;
}

//****************************************************************************
/// Data transfer scheduler
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE CTxSchedule::NormalOperation(void) {
	T_V6ACTMOD_RETURN_VALUE retVal = V6ACTMOD_OK;

	SetState(TX_RUNNING);

	m_ScheduleThread->ResumeThread();

	return retVal;
}

//****************************************************************************
/// Data transfer scheduler
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE CTxSchedule::SetupConfigChangePreparation(void) {
	T_V6ACTMOD_RETURN_VALUE retVal = V6ACTMOD_OK;

	// Stop any current exports and prepare for new configuration
	retVal = RequestStop( TRUE, TX_CONFIG_PREPARE);

	return retVal;
}

//****************************************************************************
/// Data transfer scheduler
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE CTxSchedule::SetupConfigChangeComplete(void) {
	T_V6ACTMOD_RETURN_VALUE retVal = V6ACTMOD_OK;

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
	QString  strDbgMsg;
	strDbgMsg.asprintf(_T("CTxSch::SetupConfigChangeComplete begin"));
	LogDebugMessage(strDbgMsg);
#endif

	static BOOL notStartup = FALSE;

	// Accept new configuration
	SetState(TX_CONFIGURE);

	// kick off the media manager
	CMediaManager *pMediamanager = CMediaManager::GetHandle();
	pMediamanager->Initialise();

	// Update the queue stats
	CNVBasicVar *pNVmandevice = pNV_VARS->GetBasicVarNVObject(static_cast<NVVAR_IDENT>(NVV_MANUAL_TX_DEVICE));
	T_LOG_DEVICE lastManualDevice = (T_LOG_DEVICE) pNVmandevice->GetFromNV()->value.us[0];

	CQMonitor *pkQueueMonitor = CQMonitor::GetHandle();

	// only do this if the media thread is running and has initialised the data
	bool bTimeout = false;
	USHORT usTimeout = 0;
	while (!CNotificationThread::IsInitialised() && !bTimeout) {
		++usTimeout;
		if (usTimeout > 50) {
			bTimeout = true;
		} else {
			sleep(100);
		}
	}

	pkQueueMonitor->Update(lastManualDevice, false);

	// start the scheduler running again
	retVal = RequestStop( FALSE, TX_RUNNING);

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
	strDbgMsg.asprintf(_T("CTxSch::SetupConfigChangeComplete end bTimeout %d retVal %d"), bTimeout, retVal);
	LogDebugMessage(strDbgMsg);
#endif

	return retVal;
}

//****************************************************************************
/// Check and Clean the LCF is required, nudge data folder
///
/// @return			none
//****************************************************************************
void CTxSchedule::CheckAndCleanLCF() {
	qDebug("Checking for LCM clean-up...\n");
	if (pm_DataTransfer->CleanLCMRequired()) {
#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
		QString  strDbgMsg;
		strDbgMsg.asprintf(_T("CheckAndCleanLCF: Clean-up required."));
		LogDebugMessage(strDbgMsg);
		#endif

		qDebug("Clean-up required.\n");
		pm_DataTransfer->CleanLCM();

		// need to nudge the export folder to make sure data can be imported OK.
		pm_DataTransfer->NudgeExportFolder();
	} else {
		qDebug("Clean-up not required.\n");
	}
}

//****************************************************************************
/// Data transfer scheduler: request an emergency stop
///
/// Method that stops any exports that may currently be in progress
///
///	@param[in]			const BOOL bSTOP - Flag indicating if the thread is to be stopped
/// @param[in]			const TRANSFER_THREAD_STATE eRESTORE_STATE - The state to restore the
///						thread to
///
/// @return			OK or a timeout error
///
//****************************************************************************
const T_V6ACTMOD_RETURN_VALUE CTxSchedule::RequestStop(const BOOL bSTOP, const TRANSFER_THREAD_STATE eRESTORE_STATE) {
	T_V6ACTMOD_RETURN_VALUE retVal = V6ACTMOD_OK;

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
	QString  strDbgMsg;
	strDbgMsg.asprintf(_T("RequestStop begin bSTOP %d eRESTORE_STATE %d"), bSTOP, eRESTORE_STATE);
	LogDebugMessage(strDbgMsg);
#endif

	m_SharedData.RequestStop = bSTOP;
	pm_DataTransfer->RequestStop(bSTOP);

	// now wait for the system to go into idle mode
	int iTimeout = 0;
	int iTIMEOUT_IN_100MS = ms_dwTIMEOUT_IN_MS / 100;

	// if stopping the thread then we need to wait for the TX_STOP_CURR_EXPORT state to get set
	if (m_SharedData.RequestStop) {
		while ((m_SharedData.State != TX_STOPPED_CURR_EXPORT) && (iTimeout < iTIMEOUT_IN_100MS)) {
			sleep(100);
			++iTimeout;
		}

		// set the timeout error if necessary
		if (m_SharedData.State != TX_STOPPED_CURR_EXPORT) {
			retVal = V6ACTMOD_EVENT_TIMEOUT;
#ifdef DEBUG
			LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_ERROR,"TX Scheduler - request stop timeout" );
#endif
#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
			strDbgMsg.asprintf(_T("TX Scheduler - request stop timeout"));
			LogDebugMessage(strDbgMsg);
			#endif
		} else {
			// reset the stop flag 
			m_SharedData.RequestStop = FALSE;

			// set the restoration state
			m_SharedData.State = eRESTORE_STATE;
		}
	} else {
		// set the restoration state
		m_SharedData.State = eRESTORE_STATE;
	}

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
	strDbgMsg.asprintf(_T("RequestStop end m_SharedData.RequestStop %d retVal %d"), m_SharedData.RequestStop, retVal);
	LogDebugMessage(strDbgMsg);
	#endif

	return retVal;
}

//****************************************************************************
/// Data transfer scheduler: clear all new log date
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
BOOL CTxSchedule::ClearAllNewData() {
	BOOL bResult = TRUE;

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
	QString  strDbgMsg;
	strDbgMsg.asprintf(_T("ClearAllNewData: begin"));
	LogDebugMessage(strDbgMsg);
	#endif

	CQMonitor *pQueueMonitor = CQMonitor::GetHandle();
	pQueueMonitor->Initialise();

	T_SCHEDULER_MESSAGE message;

	pQueueMonitor->ClearAllNewData();

	// Request queue stats update
	message.Device = LOGDEV_MAX_DEVICES;
	message.Request = RQ_UPDATE;

	T_IMQ_RETURN_VALUE retValue = m_SharedData.pMessageQueue->PostInternalMessage(IMQ_DATA,
			(USHORT) sizeof(T_SCHEDULER_MESSAGE), (BYTE*) &message);
	if (IMQ_MESSAGE_POSTED != retValue) {
		qDebug("CTxSchedule: PostInternalMessage returned %d\n", retValue);
		// Shouldh't be required
		bResult = FALSE;

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
		strDbgMsg.asprintf(_T("ClearAllNewData: PostInternalMessage returned %d"), retValue);
		LogDebugMessage(strDbgMsg);
		#endif
	}

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
	strDbgMsg.asprintf(_T("ClearAllNewData: end bResult %d"), bResult);
	LogDebugMessage(strDbgMsg);
	#endif

	return bResult;
}

//****************************************************************************
/// Data transfer scheduler: Prepare for shut-down
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE CTxSchedule::ShutdownPreparation(void) {
	T_V6ACTMOD_RETURN_VALUE retVal = V6ACTMOD_OK;

	// Prepare for shut-down
	retVal = RequestStop( TRUE, TX_SHUTDOWN_PREPARE);

	return retVal;
}

//****************************************************************************
/// Data transfer scheduler: Shut-down worker thread
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE CTxSchedule::Shutdown(void) {
	T_V6ACTMOD_RETURN_VALUE retVal = V6ACTMOD_OK;

	SetState(TX_SHUTDOWN);
	DWORD dwWaitSingleObjectResult = WaitForSingleObject(m_ScheduleThread->m_hThread, ms_dwTIMEOUT_IN_MS);

	switch (dwWaitSingleObjectResult) {
	case WAIT_OBJECT_0:
		qDebug("CTxSchedule Thread Shutdown normally\n");
		break;

	case WAIT_TIMEOUT:
	case WAIT_ABANDONED:
	case WAIT_FAILED:
	default:
		if (V6_RELEASE == RELEASE_BETA) {
			// log a diagnsotic message 
			QString   strError("");
			strError.asprintf(L"CTxSchedule failed to shutdown within timeout period (%u seconds)",
					ms_dwTIMEOUT_IN_MS / 1000);
			LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
		}
		break;
	}

	delete (m_SharedData.pMessageQueue);

	m_Initialised = FALSE;

	return retVal;
}

//****************************************************************************
/// Data transfer scheduler: Request immediate data transfer
///
/// @param[in] type - Transfer type required
/// @param[in] device - storage device to transfer the data to
/// @param[in] resetPreTriggerTransferList - flag indicating if the pre-trigger transfer list needs
/// to be reset prior to the transfer - usually this woulds occru at the start of a transfer, but not
/// when it is a continuation of a FTP transfer
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
BOOL CTxSchedule::DoTransfer(T_TRANSFER_TYPE type, T_LOG_DEVICE device, bool resetPreTriggerTransferList /* = true */) {
	BOOL bResult = TRUE;

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
	QString  strDbgMsg;
	strDbgMsg.asprintf(_T("DoTransfer begin Type %d device %d resetPreTriggerTransferList %d"), type, device, resetPreTriggerTransferList);
	LogDebugMessage(strDbgMsg);
#endif

	T_SCHEDULER_MESSAGE message;
	CPenManager *pPenManager = CPenManager::GetHandle();

	if (NULL != pPenManager)	// just in case...
			{
		// Wait for Logging action to complete if one is pending before requesting a flush
		if (CTScheduleThread::WaitForActionToComplete()) {
			pPenManager->FlushAllLogChannels();
			CTScheduleThread::WaitForActionToComplete();
		}
	}

	// check if the pre-trigger transfer list needs resetting
	if (resetPreTriggerTransferList) {
		// reset the transfer list
		pm_DataTransfer->ResetPreTrigPenTransferList();
	}

	pm_DataTransfer->ClearPercentage();
	pm_DataTransfer->ClearTransferComplete();

	message.Device = device;

	switch (type) {
	case TR_TRANSFER_ALL:
		message.Request = RQ_TRANSFER_ALL;
		break;
	case TR_TRANSFER_NEW:
		message.Request = RQ_TRANSFER_NEW;
		break;
	default:
		DebugBreak();
		break;
	}

	T_IMQ_RETURN_VALUE retValue = m_SharedData.pMessageQueue->PostInternalMessage(IMQ_DATA,
			(USHORT) sizeof(T_SCHEDULER_MESSAGE), (BYTE*) &message);

	if (IMQ_MESSAGE_POSTED != retValue) {
		qDebug("CTxSchedule: PostInternalMessage returned %d\n", retValue);

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
		strDbgMsg.asprintf(_T("DoTransfer PostInternalMessage returned %d"), retValue);
		LogDebugMessage(strDbgMsg);
		#endif

		// Shouldn't be required...
		bResult = FALSE;
	}

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
	strDbgMsg.asprintf(_T("DoTransfer END Type %d device %d bResult %d"), type, device, bResult);
	LogDebugMessage(strDbgMsg);
	#endif
	// Receiver will delete the message after processing.
	return bResult;
}
//****************************************************************************
// T_V6ACTMOD_RETURN_VALUE ModuleMessageHandler( const CMsgQueueMessage *pMsg )
///
/// Carries out the desired function when a message is received
///
/// @param[in] 	  const CMsgQueueMessage *pMsg - Pointer to the received message 
///
/// @return V6ACTMOD_OK   - Associated Action with Received Message Undertaken Sucessfully
/// @n V6ACTMOD_MESSAGE_NOT_HANDLED - Message Received is not being handled
/// 
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE CTxSchedule::ModuleMessageHandler(const CMsgQueueMessage *pMsg) {
	T_V6ACTMOD_RETURN_VALUE retValue = V6ACTMOD_OK;

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
	QString  strDbgMsg;
	strDbgMsg.asprintf(_T("ModuleMessageHandler begin pMsg->m_MessageType %d"), pMsg->m_MessageType);
	LogDebugMessage(strDbgMsg);
#endif

	static bool s_bFTPDataTransferInProgress = false;

	switch (pMsg->m_MessageType) {
	case MOD_AUTO_OPS_EXPORT_NEW_DATA:
		// stop any transfer that may already be in progress e.g. a scheduled export. This
		// will be a blocking command. There should not be an FTP transfer in progress already
		RequestStop( TRUE, TX_FTP_IN_PROGRESS);

		pm_DataTransfer->SaveAllFTPTransactionPoints();

		// setup the number of FTP transfer blocks that can be downloaded in
		// a single FTP request (dependant on the connection speed)
		pm_DataTransfer->SetFTPTransferBlocks(pMsg->m_MsgData[0]);

		DoTransfer(TR_TRANSFER_NEW, LOGDEV_FTP, true);

		// set this flag to indicate we have begun transferring pen/event data by FTP
		s_bFTPDataTransferInProgress = true;
		break;
	case MOD_AUTO_OPS_EXPORT_ALL_DATA:
		// stop any transfer that may already be in progress e.g. a scheduled export. This
		// will be a blocking command. There should not be an FTP transfer in progress already
		RequestStop( TRUE, TX_FTP_IN_PROGRESS);

		// reset the export all FTP transaction points
		pm_DataTransfer->ResetExportAllTransPoints();

		// setup the number of FTP transfer blocks that can be downloaded in
		// a single FTP request (dependant on the connection speed)
		pm_DataTransfer->SetFTPTransferBlocks(pMsg->m_MsgData[0]);

		// clear the pre-trigger pen data transferred list prior to any new export
		pm_DataTransfer->ResetPreTrigPenTransferList();

		// now transfer ALL the data
		DoTransfer(TR_TRANSFER_ALL, LOGDEV_FTP, true);

		// set this flag to indicate we have begun transferring pen/event data by FTP
		s_bFTPDataTransferInProgress = true;
		break;
	case MOD_AUTO_OPS_EXPORT_LCF:
		// stop any transfer that may already be in progress e.g. a scheduled export. This
		// will be a blocking command. There should not be an FTP transfer in progress already
		RequestStop( TRUE, TX_FTP_IN_PROGRESS);
		pm_DataTransfer->CopyLCFFiles(NULL, LOGDEV_FTP);

		break;
	case MOD_AUTO_OPS_CONTINUE_EXPORT_NEW:
		// continue with the transfer
		DoTransfer(TR_TRANSFER_NEW, LOGDEV_FTP, false);
		break;
	case MOD_AUTO_OPS_CONTINUE_EXPORT_ALL:
		// continue with the transfer
		DoTransfer(TR_TRANSFER_ALL, LOGDEV_FTP, false);
		break;
	case MOD_AUTO_OPS_CANCEL_EXPORT:
		// the user has requested a stop during an FTP transfer 
		RequestStop( TRUE, TX_STOPPED_CURR_EXPORT);

		// only restore FTP transaction points if an FTP transfer has begun
		if (s_bFTPDataTransferInProgress) {
			pm_DataTransfer->RestoreAllFTPTransactionPoints();
			pm_DataTransfer->ClearRollBack();
		}
		s_bFTPDataTransferInProgress = false;

		// start the schedule running again
		RequestStop( FALSE, TX_RUNNING);

		break;
	case MOD_AUTO_OPS_EXPORT_FINISHED:
		// message from the autoops system stating the entire FTP download was successfull
		s_bFTPDataTransferInProgress = false;

		pm_DataTransfer->ClearRollBack();

		// clear the pre-trigger data flag as the export is complete and was successfull
		pm_DataTransfer->ClearPreTriggerData();

		// start the schedule running again
		RequestStop( FALSE, TX_RUNNING);
		break;
	default:
		// not a specific method therefore pass on to the standard handler
		retValue = CV6ActiveModule::ModuleMessageHandler(pMsg);
		break;

	} // End of SWITCH  

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
	strDbgMsg.asprintf(_T("ModuleMessageHandler End Retval %d"), retValue);
	LogDebugMessage(strDbgMsg);
	#endif

	return (retValue);

} // End of Member Function
//****************************************************************************
//	const T_V6ACTMOD_RETURN_VALUE PostFinishedFTPMessage( const USHORT usREPLY_MSG )
///
/// Method that sends a finished export request back to the auto ops thread
///
/// @param[in]		const USHORT usREPLY_MSG - The reply mesage type - can be failed or finished
///
///	@return		V6ACTMOD_OK if the operation completed successfully
///
//****************************************************************************
const T_V6ACTMOD_RETURN_VALUE CTxSchedule::PostFinishedFTPMessage(const USHORT usREPLY_MSG) {
	T_V6ACTMOD_RETURN_VALUE eResult = V6ACTMOD_OK;

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
	QString  strDbgMsg;
	strDbgMsg.asprintf(_T("PostFinishedFTPMessage begin usREPLY_MSG %d"), usREPLY_MSG);
	LogDebugMessage(strDbgMsg);
#endif

	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();

	if (pThreadInfo != NULL) {
		//Update the Thread Counter for the TxScheduler thread
		pThreadInfo->UpdateThreadCounter(AM_TX_SCHEDULER_THREAD);
	}

	// post a message to the auto ops stating the export is complete
	if (MMMCLIENT_MESSAGE_POSTED
			!= m_ModuleMsgManagerClient.MMMClientPostIntMsg( INFINITE, MODULE_AUTO_OPS, MODULE_EXPORT_SCHEDULER,
					usREPLY_MSG, 0, NULL)) {
		// somehow the message failed to be posted
		LOG_ERR( TRACE_AUTO_OPS, "TX SCHEDULER - Finished/Failed export message failed to be posted to Auto Ops");
		DebugBreak();
		eResult = V6ACTMOD_ACTION_NOT_PERFORMED;

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
		strDbgMsg.asprintf(_T("TX SCHEDULER - Finished/Failed export message failed to be posted to Auto Ops"));
		LogDebugMessage(strDbgMsg);
		#endif
	} else {
		eResult = V6ACTMOD_OK;
	}

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
	strDbgMsg.asprintf(_T("PostFinishedFTPMessage end eResult %d"), eResult);
	LogDebugMessage(strDbgMsg);
	#endif

	return eResult;
}
//****************************************************************************
//	const T_V6ACTMOD_RETURN_VALUE PostCollectFTPFilesMessage( )
///
/// Method that sends a message back to the auto ops thread informing it data is ready 
///	for downloading and there will be more to come
///
///	@return		V6ACTMOD_OK if the operation completed successfully
///
//****************************************************************************
const T_V6ACTMOD_RETURN_VALUE CTxSchedule::PostCollectFTPFilesMessage() {
	T_V6ACTMOD_RETURN_VALUE eResult = V6ACTMOD_OK;

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
	QString  strDbgMsg;
	strDbgMsg.asprintf(_T("PostCollectFTPFilesMessage begin"));
	LogDebugMessage(strDbgMsg);
	#endif

	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();

	if (pThreadInfo != NULL) {
		//Update the Thread Counter for the TxScheduler thread
		pThreadInfo->UpdateThreadCounter(AM_TX_SCHEDULER_THREAD);
	}

	// post a message to the auto ops stating the export is complete
	if (MMMCLIENT_MESSAGE_POSTED
			!= m_ModuleMsgManagerClient.MMMClientPostIntMsg( INFINITE, MODULE_AUTO_OPS, MODULE_EXPORT_SCHEDULER,
					MOD_AUTO_OPS_COLLECT_FILES, 0, NULL)) {
		// somehow the message failed to be posted
		LOG_ERR( TRACE_AUTO_OPS, "TX SCHEDULER - Collect files message failed to be posted to Auto Ops");
		DebugBreak();
		eResult = V6ACTMOD_ACTION_NOT_PERFORMED;

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
		strDbgMsg.asprintf(_T("TX SCHEDULER - Collect files message failed to be posted to Auto Ops"));
		LogDebugMessage(strDbgMsg);
		#endif
	} else {
		eResult = V6ACTMOD_OK;
	}

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
	strDbgMsg.asprintf(_T("PostCollectFTPFilesMessage end eResult %d"), eResult);
	LogDebugMessage(strDbgMsg);
	#endif

	return eResult;
}

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
void CTxSchedule::LogDebugMessage(QString  & strDbgMsg)
{
	if( NULL != m_pDebugFileLogger )
	{
		QString  strDiagMsg;
		strDiagMsg.asprintf(_T("TxSch - %s at GTC:%u\r\n"), strDbgMsg, GetTickCount());
		m_pDebugFileLogger->WriteToDebugLogFile(strDiagMsg);
	}
}
#endif

/////////////////////////////////////////
// Data transfer message thread

// IMPLEMENT_DYNCREATE( CTxThread, QThread )

BEGIN_MESSAGE_MAP( CTxThread, QThread )
END_MESSAGE_MAP()

CTxThread::CTxThread()
{
}

CTxThread::~CTxThread() {
}

//****************************************************************************
/// Data transfer message thread
///
/// @note ActiveModule method
//****************************************************************************

UINT CTxThread::ThreadFunc(LPVOID lpParam) {
	CTxSchedule *pSchedulerWrapper = (CTxSchedule*) lpParam;

	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//after each iteration
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();

#ifdef THREAD_ID_SERIAL_LOG
	  WCHAR szDbgMsg[512];
		swprintf( szDbgMsg, L"CTxThread::ThreadFunc-Thread id 0x%x, %lu ", GetThreadId(GetCurrentThread()), GetThreadId(GetCurrentThread()));
		OutputDebugString(szDbgMsg);
	#endif

	while (TX_SHUTDOWN != pSchedulerWrapper->GetState()) {
		//Ignore the ExportSchedulerThread for WatchDog
		//thread until the wait is complete
		if (pThreadInfo != NULL) {
			pThreadInfo->UpdateThreadInfo(AM_EXPORT_SCHEDULER, false);
		}
		pSchedulerWrapper->EventMessageHandler( INFINITE);

		if (pThreadInfo != NULL) {
			//Start considering the ExportSchedulerThread for WatchDog
			//thread after the wait is complete
			pThreadInfo->UpdateThreadInfo(AM_EXPORT_SCHEDULER, true);
			//Update the Thread Counter for the ExportScheduler
			//thread after each iteration
			pThreadInfo->UpdateThreadCounter(AM_EXPORT_SCHEDULER);
		}
	}
	//Update the info that the ExportScheduler thread is exiting
	//Hence this thread need not be considered to kick the 
	//watchdog
	if (pThreadInfo != NULL) {
		pThreadInfo->UpdateThreadInfo(AM_EXPORT_SCHEDULER, false);
	}
	return 0;
}

// Scheduler 

//****************************************************************************
/// DataTransfer scheduler thread: thread constructor
///
/// @param[in]		none
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
CTScheduleThread::CTScheduleThread() {

}

//****************************************************************************
/// DataTransfer scheduler thread: thread destructor
///
/// @param[in]		none
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
CTScheduleThread::~CTScheduleThread() {

}

//****************************************************************************
/// Wait for a pending logging action to be completed
///
/// @return			true if no timout, false if timed out.
//****************************************************************************
bool CTScheduleThread::WaitForActionToComplete() {
	bool timeout = false;
	int waitForFlushRetryIndex = 0;
	CPenManager *pPenManager = CPenManager::GetHandle();
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	while (pPenManager->IsActionStillPending() == TRUE) {
		if (pThreadInfo != NULL) {
			//Update the Thread Counter for the TxScheduler thread
			//thread after each iteration
			pThreadInfo->UpdateThreadCounter(AM_TX_SCHEDULER_THREAD);
		}
		sleep(200);
		if (waitForFlushRetryIndex++ > WAIT_FOR_FLUSH_RETIRES) {
			qDebug(" Timed out waiting for log action to complete \n ");
			timeout = true;

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
			QString  strDbgMsg;
			strDbgMsg.asprintf(_T("Timed out waiting for log action to complete "));
			LogDebugMessage(strDbgMsg);
			#endif

			break;
		}
	}
	return !timeout;
}

//****************************************************************************
/// DataTransfer scheduler thread: thread function
///
/// @param[in]		lpParameter pointer to shared data
///
/// @return			Always 0
///
/// @note --- Delete if not requried ---
//****************************************************************************
UINT CTScheduleThread::ThreadFunc(LPVOID lpParameter) {
	T_SCHEDULER_SHARED *SharedData = (T_SCHEDULER_SHARED*) lpParameter;

#ifdef THREAD_ID_SERIAL_LOG
	  glb_MsgCntLog = 1;
#endif

#ifdef DBG_THREADID_INFO
	WCHAR strMsg[MAX_PATH] = { 0 };
	swprintf(strMsg, L"CTScheduleThread TID: 0x%x, %lu ", GetThreadId(GetCurrentThread()), GetThreadId(GetCurrentThread()) );
	LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_INFORMATION,strMsg);
#endif

	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//after each iteration
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();

	if (pThreadInfo != NULL) {
		//Notify that the WatchdogTimer that the TxScheduler thread has 
		//started
		pThreadInfo->UpdateThreadInfo(AM_TX_SCHEDULER_THREAD, true);
		//Set the function pointer for the global function
		//GlbUpdateThreadCount
		SetThreadCounter(GlbUpdateThreadCount);
	}

#ifdef THREAD_ID_SERIAL_LOG
	  WCHAR szDbgMsg[512];
		swprintf( szDbgMsg, L"CTScheduleThread::ThreadFunc-Thread id 0x%x, %lu ", GetThreadId(GetCurrentThread()), GetThreadId(GetCurrentThread()));
		OutputDebugString(szDbgMsg);
#endif

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
	QString  strDbgMsg;
	strDbgMsg.asprintf(_T("TxScheduler thread begin"));
	LogDebugMessage(strDbgMsg);
	#endif

	CQMonitor *pQueueMonitor = CQMonitor::GetHandle();
	pQueueMonitor->Initialise();

	CDataTransfer *pDataTransfer = CDataTransfer::GetHandle();
	pDataTransfer->Initialise();

	// Get handle on Pen Manager Singleton
	CPenManager *pPenManager = CPenManager::GetHandle();

	static ULONG ulInterval = 0L;
	ULONG ulElapsedMin = 0;
	//PSR Fix for PAR# 1-3KM3QDH - Minitrend & Multitrend gets Lock up when configured for NAS begin
	BOOL bGOT_MEDIA = FALSE;
	//PSR Fix for PAR# 1-3KM3QDH - Minitrend & Multitrend gets Lock up when configured for NAS end

	while (TX_SHUTDOWN != SharedData->State) {
		const CInternalMessage *pInternalMessage = NULL;

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
		strDbgMsg.asprintf(_T("ThreadFunc - scheudle begin SharedData->State %d SharedData->Seconds %d"), SharedData->State, SharedData->Seconds);
		LogDebugMessage(strDbgMsg);
		#endif

		// Locate the current progress time & read current scheduler progress
		CNVBasicVar *pNVProgress = pNV_VARS->GetBasicVarNVObject(static_cast<NVVAR_IDENT>(NVV_EXPORT_TIMER));
		ULONG Minutes = pNVProgress->GetFromNV()->value.ul;

		if (NULL != SharedData->pMessageQueue) {
			if (pThreadInfo != NULL) {
				//Update the Thread Counter for the TxScheduler thread
				//thread after each iteration
				pThreadInfo->UpdateThreadCounter(AM_TX_SCHEDULER_THREAD);
			}

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
			QString  strDbgMsg;
			strDbgMsg.asprintf(_T("ThreadFunc - ProcessRequestMessage begin "));
			LogDebugMessage(strDbgMsg);
			#endif	

			ProcessRequestMessage(Minutes, *SharedData);

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
			strDbgMsg.asprintf(_T("ThreadFunc - ProcessRequestMessage end "));
			LogDebugMessage(strDbgMsg);
			#endif
		}

		// time scheduler only operational when the recorder is in "Normal Operation"
		if (TX_RUNNING == SharedData->State) {
			SharedData->Seconds++;

			// check if an export is required every minute
			if (SharedData->Seconds >= 59) {
				T_PRECPROFILE ptProfile = pSETUP->GetGeneralSetupConfig()->GetProfileBlock(CONFIG_COMMITTED);

				// flag used to identify a scheduled transfer failed because the disk was full
				bool bDiskFull = false;
				SharedData->Seconds = 0;
				Minutes++;
				ulElapsedMin++; // increment the elapsed time to log if the media is not present

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
				strDbgMsg.asprintf(_T("check if an export is required every minute ulElapsedMin %lu"), ulElapsedMin);
				LogDebugMessage(strDbgMsg);
				#endif

				// get the required schedule time...
				CheckConfigChange(ulInterval);

				// Check for schedule time or 
				// if a schedule is configured and there is less then 30 minutes of (safe) recording left in the queues
				if ((ptProfile->Logging.DoSchedExport == TRUE)
						&& (((Minutes >= ulInterval)
								|| (pPenManager->GetPreTriggerStatus() == PRE_TRIGGER_READY_FOR_EXPORT))
								|| (pQueueMonitor->GetPenSeconds() < ulMinQueueTime))) {

					T_LOG_DEVICE eSCHED_DEV = (T_LOG_DEVICE) ptProfile->Logging.SchedExportDev;

					// Set the transfer device (used for space calculations) to the last transfer new device
					SetTransferDeviceToNV();

					//PSR Fix for PAR# 1-3KM3QDH - Minitrend & Multitrend gets Lock up when configured for NAS begin
					//If the Schedule device is NAS then try the GotMedia() only once per shedule intervel instead 
					//every minute after failure
					if ((LOGDEV_SHARE != eSCHED_DEV) || (ulElapsedMin >= ulInterval)) {
						bGOT_MEDIA = GotMedia(eSCHED_DEV);
					}
					//PSR Fix for PAR# 1-3KM3QDH - Minitrend & Multitrend gets Lock up when configured for NAS end						

					// if the storage device has media, and a low space warning hasn't been issued
					if (bGOT_MEDIA && (!pQueueMonitor->DiskSpaceWarningInPlace(eSCHED_DEV))) {
						bool bContinueExport = true;

						CPenManager *pPenManager = CPenManager::GetHandle();

						if (pThreadInfo != NULL) {
							//Update the Thread Counter for the TxScheduler thread
							//thread after each iteration
							pThreadInfo->UpdateThreadCounter(AM_TX_SCHEDULER_THREAD);
						}

						// Wait for Logging action to complete if one is pending before requesting a flush
						if (WaitForActionToComplete() == TRUE) {
							pPenManager->FlushAllLogChannels();

							bContinueExport = WaitForActionToComplete();

							if (bContinueExport) {
								// Flash LED 
								pDataTransfer->FlashLED(5, 500, TRUE);	// Times, Delay, FinalState

								// Enter critcal section to guard with commit
								qDebug("Attept to Start Export \n");
								EnterCriticalSection(&CTxSchedule::m_ExportCS);
								qDebug("Start Export in CS \n");

								// clear the pre-trigger pen data transferred list prior to any new export
								pDataTransfer->ResetPreTrigPenTransferList();

								// E527303
								// Do scheduled transfer now...
								//								
								// chek for network connetion in case of NAS feature activated.
								//
								CDataTransfer::T_TRANSFER_ERRORS eRetVal = CDataTransfer::teOK;
								if (eSCHED_DEV == LOGDEV_SHARE) {
									CMediaManager *pkMediaManager = CMediaManager::GetHandle();
									if (pkMediaManager->CheckSharedFolder() == 0) {
										eRetVal = pDataTransfer->TransferAllNew(eSCHED_DEV);
									} else {
										QString   strError("");
										strError =
												tr(
														"Please check the Folder is shared and network admin settings are correct.");
										LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
									}
								} else {
#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
									QString  strDbgMsg;
									strDbgMsg.asprintf(_T("ThreadFunc - TransferAllNew begin "));
									LogDebugMessage(strDbgMsg);
									#endif

									eRetVal = pDataTransfer->TransferAllNew(eSCHED_DEV);

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
									strDbgMsg.asprintf(_T("ThreadFunc - TransferAllNew end "));
									LogDebugMessage(strDbgMsg);
									#endif
								}

								// commented as the logic is implemented above..
								// this has been done for NAS feature.
								//
								//CDataTransfer::T_TRANSFER_ERRORS eRetVal = pDataTransfer->TransferAllNew( eSCHED_DEV );

								if (eRetVal == CDataTransfer::teOK) {
									// check if we are to log a success message
									// now setup the actual schedule export fields
									T_PRECPROFILE ptProfile = pSETUP->GetGeneralSetupConfig()->GetProfileBlock(
											CONFIG_COMMITTED);

									if (ptProfile != NULL) {
										T_LOGGINGINFO *ptLogging = &ptProfile->Logging;

										if (ptLogging->LogMessage == TRUE) {
											// output a system message stating the operation was successful
											QString   strExportSuccess("");
											strExportSuccess = tr("Scheduled Export data performed");
											LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_INFORMATION, strExportSuccess,
													(ptLogging->MarkChart == TRUE) ? 0 : s_byDO_NOT_MARK_CHART_SYS_MSG);
										}
									}

									// clear the pre-trigger data flag as the export is complete and was successfull
									pDataTransfer->ClearPreTriggerData();
								} else {
									// now check if the export failed because of a serious error.
									// if so, add a system error message
									ShowScheduleError(bDiskFull, eRetVal);
								}

								// Flash LED 
								pDataTransfer->FlashLED(5, 500, FALSE);	// Times, Delay, FinalState

								qDebug("Complete Export in CS\n");
								LeaveCriticalSection(&CTxSchedule::m_ExportCS);

								Minutes = 0;
								ulElapsedMin = 0; // reset the elapsed time, shceduled export success
							}
						}
					} else {
						//Fix for PAR - 1-2QM7HOT
						//Log message if media missing and reaching scheduled interval (ex:10 Minutes)
						if (!bGOT_MEDIA && ulElapsedMin >= ulInterval) {
							ulElapsedMin = 0; //Reset the minutes, scheduled interval has elapsed
							qDebug(" Media missing for scheduled export\n");
							QString   strError("");
							if (eSCHED_DEV == LOGDEV_SHARE) {
								strError.asprintf(IDS_SCHEDULE_NAS_EXPORT_ERROR);
							} else {
								strError.asprintf(IDS_SCHEDULE_MEDIA_MISSING_ERROR);
							}

							LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, strError);
						}

						// No media available or disk full?
						pDataTransfer->FlashLED(10, 150, FALSE);	// Times, Delay, FinalState
					}
				}

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
				strDbgMsg.asprintf(_T("pQueueMonitor->Update"));
				LogDebugMessage(strDbgMsg);
				#endif

				// Update progress in NV
				COMBO_VAR4 value;
				value.ul = Minutes;
				pNVProgress->SetToNV(value);

				// Update the queue stats
				CNVBasicVar *pNVmandevice = pNV_VARS->GetBasicVarNVObject(
						static_cast<NVVAR_IDENT>(NVV_MANUAL_TX_DEVICE));
				T_LOG_DEVICE lastManualDevice = (T_LOG_DEVICE) pNVmandevice->GetFromNV()->value.us[0];

				pQueueMonitor->Update(lastManualDevice, bDiskFull);

			} // Minutes
		}

		// put into the stopped state if a stop request has been posted - this will be reset
		// by the RequestStop method
		if ((SharedData->RequestStop) && (SharedData->State != TX_STOPPED_CURR_EXPORT)) {
			SharedData->State = TX_STOPPED_CURR_EXPORT;
		}

		if (pThreadInfo != NULL) {
			//Update the Thread Counter for the TxScheduler thread
			//thread after each iteration
			pThreadInfo->UpdateThreadCounter(AM_TX_SCHEDULER_THREAD);
		}

		// check if we need to move any pre-trigger data - only do when TX scheduler is running with no other
		// operations in progress
		if (SharedData->State == TX_RUNNING) {
			// TX scheduler must be running normally so it is safe to transfer pre-trigger data if necessary

			// Check if pre trigger data is ready for processing
			if (pPenManager->GetPreTriggerStatus() == PRE_TRIGGER_READY_FOR_PROCESSING) {
#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
				strDbgMsg.asprintf(_T("ProcessPreTriggerFilesForExport begin"));
				LogDebugMessage(strDbgMsg);
				#endif

				// process the pre triggered information
				pPenManager->ProcessPreTriggerFilesForExport();

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
				strDbgMsg.asprintf(_T("ProcessPreTriggerFilesForExport end"));
				LogDebugMessage(strDbgMsg);
				#endif
			}
		}

		if (pThreadInfo != NULL) {
			//Update the Thread Counter for the TxScheduler thread
			//thread after each iteration
			pThreadInfo->UpdateThreadCounter(AM_TX_SCHEDULER_THREAD);
		}

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
		strDbgMsg.asprintf(_T("ThreadFunc - wait For next schedule "));
		LogDebugMessage(strDbgMsg);
		#endif

		sleep(ONE_SECOND);

	}

	if (pThreadInfo != NULL) {
		//Update the info that the TxScheduler thread is exiting
		//Hence this thread need not be considered to kick the 
		//watchdog
		pThreadInfo->UpdateThreadInfo(AM_TX_SCHEDULER_THREAD, false);
	}

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
	strDbgMsg.asprintf(_T("TxScheduler thread exit"));
	LogDebugMessage(strDbgMsg);
	#endif

	qDebug(" TxScheduler thread exit/n");
	return 0;
}

//****************************************************************************
/// DataTransfer scheduler thread: check if the scheduler time has changed
///
/// @param[out]		Required schedule time in minutes
///
/// @return			none
//****************************************************************************
// private
void CTScheduleThread::CheckConfigChange(ULONG &ulInterval) {
	static USHORT LastValue = 0xFFFF;
	USHORT selection = 0;

	//Get the handle for the singleton class CThreadInfo
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();

	if (pThreadInfo != NULL) {
		//Update the counter of the scheduler thread
		pThreadInfo->UpdateThreadCounter(AM_TX_SCHEDULER_THREAD);
	}

	// Read the time interval, and check if it has changed
	T_PRECPROFILE ptProfile = pSETUP->GetGeneralSetupConfig()->GetProfileBlock(CONFIG_COMMITTED);
	selection = ptProfile->Logging.SchedExportTime;
	if (LastValue != selection) {
		switch (selection) {
		case 0:					// 10 Minutes
			ulInterval = 10;
			break;
		case 1:					// 30 Minutes
			ulInterval = 30;
			break;
		case 2:					// 1 Hour
			ulInterval = 60;
			break;
		case 3:					// 2 Hour
			ulInterval = 120;
			break;
		case 4:					// 12 Hour
			ulInterval = 720;
			break;
		case 5:					// 24 Hour
			ulInterval = 1440;
			break;
		default:
			ulInterval = 10;	// default to 10 minutes, only used if an invalid config value is found.
			break;
		}
		LastValue = selection;
	}
}

//****************************************************************************
/// DataTransfer scheduler thread: Show a scheduler error message
///
/// @param[out]		bDiskFull indicates the storage device is full
/// &param[in]		eRetVal data transfer error code
///
/// @return			none
//****************************************************************************
// private
void CTScheduleThread::ShowScheduleError(bool &bDiskFull, CDataTransfer::T_TRANSFER_ERRORS eRetVal) {
	switch (eRetVal) {
	case CDataTransfer::teMEDIA_FULL:
		bDiskFull = true;
		break;
	case CDataTransfer::teMEDIA_NOT_PRESENT: {
		QString   strError("");
		strError = tr("Scheduled export failed - media removed during export");
		LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_ERROR, strError);
	}
		break;
	case CDataTransfer::teMEDIA_GENERIC_ERROR: {
		QString   strError("");
		strError = tr("Scheduled export failed - unknown media error");
		LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_ERROR, strError);
	}
		break;
	case CDataTransfer::teMEDIA_FAILED_TO_CREATE_EXPORT_FOLDER: {
		QString   strError("");
		strError = tr("Scheduled export failed - could not create export folder");
		LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_ERROR, strError);
	}
		break;
	default:
		break;
	}
}

//****************************************************************************
/// DataTransfer scheduler thread: Process request message
///
/// @param[out]		Minutes current minute count
/// @param[in/out]	SharedData thread shared data
///
/// @return			none
//****************************************************************************
// private
void CTScheduleThread::ProcessRequestMessage(ULONG &Minutes, T_SCHEDULER_SHARED &SharedData) {
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();

	if (pThreadInfo != NULL) {
		//Update the Thread Counter for the TxScheduler thread
		pThreadInfo->UpdateThreadCounter(AM_TX_SCHEDULER_THREAD);
	}

	const CInternalMessage *pInternalMessage = NULL;

	pInternalMessage = SharedData.pMessageQueue->ReadInternalMessage();

	if (NULL != pInternalMessage) {
#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
		QString  strDbgMsg;
		strDbgMsg.asprintf(_T("ProcessRequestMessage begin "));
		LogDebugMessage(strDbgMsg);
		#endif

		// Guard from Commit
		EnterCriticalSection(&CTxSchedule::m_ExportCS);

		CDataTransfer *pDataTransfer = CDataTransfer::GetHandle();
		pDataTransfer->Initialise();

		CQMonitor *pQueueMonitor = CQMonitor::GetHandle();
		pQueueMonitor->Initialise();

		T_SCHEDULER_MESSAGE tMessage = *(T_SCHEDULER_MESSAGE*) pInternalMessage->m_MsgData;

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
		strDbgMsg.asprintf(_T("ProcessRequestMessage tMessage.Request %d"), tMessage.Request);
		LogDebugMessage(strDbgMsg);
		#endif

		SharedData.pMessageQueue->RemoveInternalMessage();

		// Process request
		switch (tMessage.Request) {
		case RQ_START:
			break;
		case RQ_STOP:
			break;
		case RQ_NEW_CONFIG:
			break;
		case RQ_UPDATE:
			SharedData.Seconds = 60;
			break;
		case RQ_TRANSFER_NEW: {
			// Flash LED 
			pDataTransfer->FlashLED(1, 1, TRUE);	// Times, Delay, FinalState

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
				strDbgMsg.asprintf(_T("PRM TransferAllNew tMessage.Device %d begin"), tMessage.Device);
				LogDebugMessage(strDbgMsg);
				#endif

			// Do the transfer
			CDataTransfer::T_TRANSFER_ERRORS eRetVal = pDataTransfer->TransferAllNew(tMessage.Device);

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
				strDbgMsg.asprintf(_T("PRM TransferAllNew tMessage.Device %d end eRetVal %d"), tMessage.Device, eRetVal);
				LogDebugMessage(strDbgMsg);
				#endif
			// if FTP then send back the appropriate response
			if (tMessage.Device == LOGDEV_FTP) {
				CTxSchedule *pkTXScheduler = CTxSchedule::GetHandle();

				// check if an error
				if (eRetVal == CDataTransfer::teFTP_BUFFER_FULL) {
					// we have reached the directory buffer limit so send a message to the auto ops
					// thread that will let TMS know data needs to be uploaded
					pkTXScheduler->PostCollectFTPFilesMessage();
				} else if (eRetVal == CDataTransfer::teFTP_USER_CANCELLED) {
					// a timeout has occurred or the user has cancelled the operation - this message indicates
					// to 
					pkTXScheduler->PostFinishedFTPMessage(MOD_AUTO_OPS_OKAY_TO_TIDY_UP);
				} else if (eRetVal == CDataTransfer::teOK) {
					pkTXScheduler->PostFinishedFTPMessage(MOD_AUTO_OPS_EXPORT_FINISHED);
				} else {
					LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR,
							"TX Scheduler: There has been a generic problem with the FTP export");
					// post an error message back to auto ops which will cancel the operation and let
					// TMP know there has been a problem
					pkTXScheduler->PostFinishedFTPMessage(MOD_AUTO_OPS_EXPORT_ERROR);

					// reset the transaction points
					pDataTransfer->RestoreAllFTPTransactionPoints();
					pDataTransfer->ClearRollBack();
				}
				// flash the LED quickly to indicate there are blocks avaialbe for FTP download
				pDataTransfer->FlashLED(4, 250, FALSE);	// Times, Delay, FinalState
			} else {
				// Flash LED slowly indicating the end of a manual export 
				pDataTransfer->FlashLED(5, 500, FALSE);	// Times, Delay, FinalState	

				// Ensure the scheduler is also reset.
				Minutes = 0;
				SharedData.Seconds = 60;
				pQueueMonitor->ClearNumBlocksWaiting();

				//PAR- 836 Export New Error Handling cases start - Anoop, Vedant
				QString   strAction(_T(""));

				if (CDataTransfer::teOK == eRetVal) {
					// clear the pre-trigger data flag if the export is complete and was successfull
					strAction = tr("Export new data performed");
					LOG_USER_MESSAGE(MSGLISTSER_USER_MODBUS_MESSAGE, strAction);
					pDataTransfer->ClearPreTriggerData();
				}

				else {
					ErrorReportMsg(eRetVal);

				}
			}
			//PAR- 836 Export New Error Handling cases end - Anoop, Vedant
		}
			break;
		case RQ_TRANSFER_ALL: {
			pQueueMonitor->PrepareTransferAll();

			// Flash LED 
			pDataTransfer->FlashLED(1, 1, TRUE);	// Times, Delay, FinalState

			// reset the disk full warning if this is the same device
			pQueueMonitor->ResetDiskSpaceWarning(tMessage.Device);

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
				strDbgMsg.asprintf(_T("PRM TransferAll tMessage.Device %d begin"), tMessage.Device);
				LogDebugMessage(strDbgMsg);
				#endif
			// Do the transfer
			CDataTransfer::T_TRANSFER_ERRORS eRetVal = pDataTransfer->TransferAll(tMessage.Device);

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
				strDbgMsg.asprintf(_T("PRM TransferAll tMessage.Device %d end eRetVal %d"), tMessage.Device, eRetVal);
				LogDebugMessage(strDbgMsg);
				#endif

			// if FTP then send back the appropriate response
			if (tMessage.Device == LOGDEV_FTP) {
				CTxSchedule *pkTXScheduler = CTxSchedule::GetHandle();

				// check if an error
				if (eRetVal == CDataTransfer::teFTP_BUFFER_FULL) {
					// we have reached the directory buffer limit so send a message to the auto ops
					// thread that will let TMS know data needs to be uploaded
					pkTXScheduler->PostCollectFTPFilesMessage();
				} else if (eRetVal == CDataTransfer::teFTP_USER_CANCELLED) {
					// a timeout has occurred or the user has cancelled the operation - this message indicates
					// to 
					pkTXScheduler->PostFinishedFTPMessage(MOD_AUTO_OPS_OKAY_TO_TIDY_UP);
				} else if (eRetVal == CDataTransfer::teOK) {
					pkTXScheduler->PostFinishedFTPMessage(MOD_AUTO_OPS_EXPORT_FINISHED);
				} else {
					LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR,
							"TX Scheduler: There has been a generic problem with the FTP export");
					// post an error message back to auto ops which will cancel the operation and let
					// TMP know there has been a problem
					pkTXScheduler->PostFinishedFTPMessage(MOD_AUTO_OPS_EXPORT_ERROR);

					// reset the transaction points
					//pDataTransfer->RestoreAllFTPTransactionPoints( );
					//pDataTransfer->ClearRollBack( );
				}
				// flash the LED quickly to indicate there are blocks available for FTP download
				pDataTransfer->FlashLED(4, 250, FALSE);	// Times, Delay, FinalState
			} else {
				// Flash LED slowly indicating the end of a manual export 
				pDataTransfer->FlashLED(5, 500, FALSE);	// Times, Delay, FinalState	

				//PAR- 836 Export All Error Handling cases start - Anoop, Vedant
				QString   strAction(_T(""));

				if (CDataTransfer::teOK == eRetVal) {
					// clear the pre-trigger data flag if the export is complete and was successfull
					strAction = tr("Export all data performed");
					LOG_USER_MESSAGE(MSGLISTSER_USER_MODBUS_MESSAGE, strAction);
					pDataTransfer->ClearPreTriggerData();
				}

				else {
					ErrorReportMsg(eRetVal);

				}
				//PAR- 836 Export All Error Handling cases end - Anoop, Vedant
			}
		}
			break;
		default:
			break;
		}
		// Leave commit guard
		LeaveCriticalSection(&CTxSchedule::m_ExportCS);

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
		strDbgMsg.asprintf(_T("ProcessRequestMessage end"));
		LogDebugMessage(strDbgMsg);
		#endif

	}
}

//****************************************************************************
/// DataTransfer scheduler thread: update the data transfer device in NV
///
///
/// @return			
//****************************************************************************
// private
void CTScheduleThread::SetTransferDeviceToNV() {
	// Set the transfer device (used for space calculations) to the last transfer new device
	T_PRECPROFILE ptProfile = pSETUP->GetGeneralSetupConfig()->GetProfileBlock(CONFIG_COMMITTED);
	COMBO_VAR4 lastDevice;
	CNVBasicVar *pNVmandevice = pNV_VARS->GetBasicVarNVObject(static_cast<NVVAR_IDENT>(NVV_MANUAL_TX_DEVICE));
	lastDevice.us[0] = ptProfile->Logging.SchedExportDev;
	pNVmandevice->SetToNV(lastDevice);
}

//****************************************************************************
/// DataTransfer scheduler thread: Check if storage device contains media
///
/// @param[in]		device - storage device
///
/// @return			TRUE if media is found, else FALSE
//****************************************************************************
BOOL CTScheduleThread::GotMedia(T_LOG_DEVICE device) {
	BOOL bResult = FALSE;

#ifdef THREAD_ID_SERIAL_LOG
		  glb_MsgCntLog = 12;
  #endif

	// Get a handle on Media manager ** Move this when scheduler sorted out
	CMediaManager *pMediaManager = CMediaManager::GetHandle();
	pMediaManager->Initialise();

	// Get status of logging device - is it in there?
	if (device != LOGDEV_SHARE) {
		bResult = pMediaManager->IsDeviceInserted(CLogDeviceStatus::LogDeviceToStorageDevice(device));
	} else {
		CCommsSetupConfig *pkCommsConfig = pGlbSetup->GetCommsSetupConfig();
		if (pkCommsConfig != NULL) {
			// Test the connection to the network share
			T_PCOMMUNICATIONS pCommunications = NULL;
			pCommunications = pkCommsConfig->GetCommsBlock(CONFIG_COMMITTED);
			T_LANINFO *ptLanInfo = &pCommunications->LanInfo;

			QString   strSharePath(""), strServerName("");
			strSharePath.asprintf(L"%s", ptLanInfo->sharePath);
			strServerName = strSharePath;
			if ((ptLanInfo->UseShare) && (strSharePath != "")) {
				strServerName.Trimleft(_T("\\"));
				strServerName = strServerName.left(strServerName.indexOfOneOf(_T("\\")));

				if ((CControlSequencer::checkIfNetworkAvailable()) && (pMediaManager->IsServerRunning(strServerName))) {
					// test the network share
					CStorageNC kTest; //CStorage kTest; // NP: changed class here

					QString   strTestFilename("");
					strTestFilename.asprintf(L"%s\\ShareTestFile%ul.txt", ptLanInfo->sharePath, GetTickCount());

					//PSR Fix for PAR# 1-3KM3QDH - Minitrend & Multitrend gets Lock up when configured for NAS begin
					//static bool bErrorLogged = false;
#ifdef THREAD_ID_SERIAL_LOG
						//glb_MsgCntLog = 27;
					#endif
					pMediaManager->RunLogOnFailureChecker();
					//PSR Fix for PAR# 1-3KM3QDH - Minitrend & Multitrend gets Lock up when configured for NAS end
					FileException kEx;

#ifdef THREAD_ID_SERIAL_LOG
							glb_MsgCntLog = 28;
					#endif

					if (!kTest.Open(strTestFilename, CStorageNC::modeCreate | CStorageNC::WriteOnly, &kEx)) {
						/*if ( false == bErrorLogged )
						 {
						 QString  strError( QString   ::fromWCharArray("") );
						 //WCHAR wcaError[ 50 ];
						 //kEx.GetErrorMessage( wcaError, 50 );
						 QString  strNASError( QString   ::fromWCharArray("") );
						 strNASError = tr("Please check the Folder is shared and network admin settings are correct.");

						 strError.asprintf( L"NAS Error(%ld): - %s ", GetLastError(), strNASError);
						 LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_ERROR, strError );
						 bErrorLogged = true;
						 }*/
						bResult = FALSE;
					} else {
#ifdef THREAD_ID_SERIAL_LOG
							glb_MsgCntLog = 29;
					#endif

						kTest.Close();
						DeleteFile(strTestFilename);
						bResult = TRUE;
						//bErrorLogged = false;
					}
				} else {
					bResult = FALSE;
				}
			} else {
				bResult = FALSE;
			}
		} else {
			bResult = FALSE;
		}
	}

	// now check the storage space
	if (bResult) {
#ifdef THREAD_ID_SERIAL_LOG
		 glb_MsgCntLog = 30;
		#endif

		CDataTransfer *pDataTransfer = CDataTransfer::GetHandle();
		bResult = pDataTransfer->CheckMediaSpace(device);
	}

#ifdef THREAD_ID_SERIAL_LOG
		  glb_MsgCntLog = 35;
	#endif

	return bResult;
}
//****************************************************************************
/// DataTransfer scheduler thread: Error Report Message Text
///
/// @param[in]	eRetVal - error code reference
///
/// @return			none
//****************************************************************************
void CTScheduleThread::ErrorReportMsg(CDataTransfer::T_TRANSFER_ERRORS eRetVal) {
	QString   strAction(_T(""));
	QString   strAction1(_T(""));

	if (1 == eRetVal) {
		strAction = tr("Export Failed- The external media is full.");
		LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_ERROR, strAction);
	} else {
		strAction = tr("Export Failed");
		strAction1.asprintf(_T("%s - EC(%d)"), strAction, eRetVal);
		LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_ERROR, strAction1);
	}
}

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
void CTScheduleThread::SetDebugLogger(CDebugFileLogger* pDbgFileLogger)
{
	m_pDebugFileLogger = pDbgFileLogger;
}

void CTScheduleThread::LogDebugMessage(QString  & strDbgMsg)
{
	if( NULL != m_pDebugFileLogger )
	{
		QString  strDiagMsg;
		strDiagMsg.asprintf(_T("CTScheduleThread - %s at GTC:%u\r\n"), strDbgMsg, GetTickCount());
		m_pDebugFileLogger->WriteToDebugLogFile(strDiagMsg);
	}
}
#endif

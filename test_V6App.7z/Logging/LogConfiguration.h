#ifndef __LOGCONFIGURATION_H_INCLUDED__
#define __LOGCONFIGURATION_H_INCLUDED__

#include "CMMDefines.h"
#include "LCMGlobal.h"
#include "CLoggerModule.h"

#include "TVTime.h"
#include "LogRec.h"

//**Class*********************************************************************
///
/// @brief 
/// 
///
//****************************************************************************

class CLogConfiguration {
public:
	CLogConfiguration();
	~CLogConfiguration();

	LCMERROR GetBaseConfiguration(DWORD Session, QString FileAndPath);
	LCMERROR GetConfigurationChanges(DWORD StartSession, DWORD EndSession, QString FileAndPath);

private:

};

#endif // __LOGCONFIGURATION_H_INCLUDED__

/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 Data Transfer utilities
/// @n DataChannel.cpp
/// @n Wrapper for a logged data channel.
/// @author MM
/// @date 11/04/2005
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 13	Stability Project 1.8.1.3	7/2/2011 4:56:37 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 12	Stability Project 1.8.1.2	7/1/2011 4:38:12 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 11	Stability Project 1.8.1.1	3/17/2011 3:20:20 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 10	Stability Project 1.8.1.0	2/15/2011 3:02:50 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////

#include "DataChannel.h"

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif

//****************************************************************************
/// DataTransfer utility: class constructor
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************

CDataChannel::CDataChannel() {
	return;
}

//****************************************************************************
/// DataTransfer utility: class destructor
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
CDataChannel::~CDataChannel() {
	return;
}

//****************************************************************************
/// DataTransfer utility: locate data block by time
///
/// @return			none
///
/// @note 
//****************************************************************************
T_QMC_FILE_BLOCK_TRANSACTION CDataChannel::LocateBlockByTime(struct TV5Time blocktime) {
	T_QMC_FILE_BLOCK_TRANSACTION BlockID = { 0xffff, 0xffff, 0, 0 };

	return BlockID;
}

//****************************************************************************
/// DataTransfer utility: locate data block by block ID
///
/// @return			none
///
/// @note 
//****************************************************************************
void* CDataChannel::LocateBlockByID(T_QMC_FILE_BLOCK_TRANSACTION location) {
	return NULL;
}

//****************************************************************************
/// DataTransfer utility: get next data block after a locate
///
/// @return			none
///
/// @note 
//****************************************************************************
void* CDataChannel::GetNextBlock(T_QMC_FILE_BLOCK_TRANSACTION currentblock) {
	return NULL;
}

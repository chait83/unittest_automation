/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 Log record utilities
/// @n LogControl.cpp
/// @n Utilities for maintaining log record format.
/// @author MM
/// @date 15/03/2005
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
//  38  Stability Project 1.33.1.3 7/2/2011 4:58:24 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  37  Stability Project 1.33.1.2 7/1/2011 4:38:27 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  36  Stability Project 1.33.1.1 3/17/2011 3:20:27 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  35  Stability Project 1.33.1.0 2/15/2011 3:03:14 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////

#include "V6globals.h"

#include "TVTime.h"
#include "LogRec.h"

#include "LogControl.h"
#include "TraceDefines.h"
#include "RecSetupCfgMgr.h"

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif

//****************************************************************************
/// LogControl utility: class constructor
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
CLogControl::CLogControl() {
	SetReason (RESET_PWRFAIL);
	SetZeroAndSpan(0, 100);
	return;
}

//****************************************************************************
/// LogControl utility: class destructor
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
CLogControl::~CLogControl() {
	return;
}

//****************************************************************************
/// LogControl utility: initialise log record
///
/// @param[in]		Session current session number
/// @param[in]		Sequence current block sequence number
/// @param[in]		Pen current pen number
/// @param[in]		pLogRecord pointer to the log record buffer
/// @param[in]		TimeStamp log record start time (first log point time)
/// @param[in]		pLogging pointer to logging configuration data
///
/// @return			Always TRUE
///
/// @note --- Delete if not requried ---
//****************************************************************************
BOOL CLogControl::Initialise(USHORT Session, ULONG Sequence, USHORT Pen, ULONG Rate, T_LOGRECORD *pLogRecord,
		T_TV5TIME TimeStamp, T_PLOGGING pLogging) {
	BOOL bResult = TRUE;

	m_pLogging = pLogging;

	// initialise a new log block
//	memset( (void *)pLogRecord, '\0', sizeof( T_LOGRECORD ) );

	pLogRecord->Header.StartTime = TimeStamp;
	pLogRecord->Header.Session = Session;
	pLogRecord->Header.SeqNo = Sequence;
	pLogRecord->Header.Reason = m_Reason;
	pLogRecord->Header.PenNumber = (UCHAR) Pen + 1;
	pLogRecord->Header.EndTime = TimeStamp;
	pLogRecord->Header.ControlType = TV5HEADER;		// Absolute header
	pLogRecord->Header.ToControl = 0;

	pLogRecord->Header.LastControl = TRUE;				// Assume this is always the last control
	pLogRecord->Header.Incomplete = INCOMPLETE;
	pLogRecord->Header.Device = OTHER_DEVICE;		// Device type (use other to allow floating point values)
	pLogRecord->Header.DatabaseLevel = 0;				// reserved for TMP use

	if (LOGTYPE_CONTINUOUS == m_pLogging->LogType) {	// Continuous logging
		pLogRecord->Header.LogStyle = CONTINUOUS;
		pLogRecord->Header.Rate = Rate;

		if (LOGSTYLE_SAMPLE == m_pLogging->LogStyle) {	// Sample
			pLogRecord->Header.DataType = EX_FLOAT;			// floating point (4 byte)
		} else if (LOGSTYLE_AVERAGE == m_pLogging->LogStyle) {	// Average
			pLogRecord->Header.DataType = EX_FLOAT;			// floating point (4 byte)
		} else if (LOGSTYLE_MAXMIN == m_pLogging->LogStyle) {	// Max-Min
																// Back-up the log-record start time by the log interval to allow TMP to graph forwards 
			SubPosmstenths(&pLogRecord->Header.StartTime, Rate);
			pLogRecord->Header.EndTime = pLogRecord->Header.StartTime;
			pLogRecord->Header.DataType = EX_FLOAT_MAXMIN;			// floating point (4 byte)
		} else {	///@todo Unknown log style
			bResult = FALSE;
		}
	} else if (LOGTYPE_FUZZY == m_pLogging->LogType) {	// Fuzzy Logging
		pLogRecord->Header.LogStyle = VARIABLE;
		pLogRecord->Header.ControlType = TV5FUZZY;			// For fuzzy logging, over-ride the header type.
		pLogRecord->Header.Rate = Rate;				// CRecSetupCfgMgr::GetLogRate( *pLogging );
		pLogRecord->Header.DataType = EX_FLOAT;			// floating point (4 byte)

		ResetFuzzyControl(m_pLogging, &FuzzyControl);
	} else {	///@todo Unknown log type
		bResult = FALSE;
	}

//	SetReason( CONTINUATION );				// Next log block reason

	return bResult;
}

//****************************************************************************
/// LogControl utility: change log rate (short)
///
/// @param[in]		pLogRecordVars pointer to the current channel log record vars
/// @param[in]		pLogRecord pointer to the current log record
/// @param[in]		Adjust short time adjustment (up to 6 seconds)
/// @param[in]		NewRate new log channel rate
///
/// @return			TRUE if a new log record is required, else FALSE
///
/// @note --- Delete if not requried ---
//****************************************************************************
BOOL CLogControl::RateChange(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, WORD Adjust, DWORD NewRate) {
	T_SHORTRATECONTROL RateControl;

	RateControl.ControlType = TV5RATE_SHORT;

	///@todo form and drop a log rate change 
	RateControl.ToControl = 0;
	RateControl.Adjust = Adjust;
	RateControl.Rate = NewRate;

	return AddControl(pLogRecordVars, pLogRecord, &RateControl);
}

//****************************************************************************
/// LogControl utility: change log rate (long)
///
/// @param[in]		pLogRecordVars pointer to the current channel log record vars
/// @param[in]		pLogRecord pointer to the current log record
/// @param[in]		Adjust long time adjustment (up to 119 hours)
/// @param[in]		NewRate new log channel rate
///
/// @return			TRUE if a new log record is required, else FALSE
///
/// @note --- Delete if not requried ---
//****************************************************************************
BOOL CLogControl::RateChange(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, DWORD Adjust, DWORD NewRate) {
	T_LONGRATECONTROL RateControl;

	RateControl.ControlType = TV5RATE_LONG;

	///@todo form and drop a log rate change 
	RateControl.ToControl = 0;
	RateControl.Adjust = Adjust;
	RateControl.Rate = NewRate;

	return AddControl(pLogRecordVars, pLogRecord, &RateControl);
}
//****************************************************************************
/// LogControl utility: time adjustment (short)
///
/// @param[in]		pLogRecordVars pointer to the current channel log record vars
/// @param[in]		pLogRecord pointer to the current log record
/// @param[in]		Adjust short time adjustment (up to 6 seconds)
///
/// @return			TRUE if a new log record is required, else FALSE
///
/// @note --- Delete if not requried ---
//****************************************************************************
BOOL CLogControl::TimeChange(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, WORD Adjust) {
	T_SHORTCONTROL TimeControl;

	TimeControl.ControlType = TV5ADJUST_SHORT;

	///@todo form and drop a short time adjust
	TimeControl.ToControl = 0;
	TimeControl.Adjust = Adjust;

	return AddControl(pLogRecordVars, pLogRecord, &TimeControl);
}

//****************************************************************************
/// LogControl utility: time adjust (long)
///
/// @param[in]		pLogRecordVars pointer to the current channel log record vars
/// @param[in]		pLogRecord pointer to the current log record
/// @param[in]		Adjust long time adjustment (up to 119 hours)
///
/// @return			TRUE if a new log record is required, else FALSE
///
/// @note --- Delete if not requried ---
//****************************************************************************
BOOL CLogControl::TimeChange(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, DWORD Adjust) {
	T_LONGCONTROL TimeControl;

	TimeControl.ControlType = TV5ADJUST_LONG;

	///@todo form and drop a long time adjust
	TimeControl.ToControl = 0;
	TimeControl.Adjust = Adjust;

	return AddControl(pLogRecordVars, pLogRecord, &TimeControl);
}

//****************************************************************************
/// LogControl utility: complete a log record
///
/// @param[in]		pLogRecordVars pointer to the current channel log record vars
/// @param[in]		pLogRecord pointer to the current log record
/// @param[in]		TimeStamp time of the log block completion
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
void CLogControl::Complete(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, T_TV5TIME *TimeStamp) {
	if (NULL != pLogRecordVars->CurrentControl)
		CompleteLogBlock(pLogRecordVars, pLogRecord, TimeStamp, TRUE);
}

//****************************************************************************
/// LogControl utility: log data point
///
/// @param[in]		pLogRecordVars - pointer to log record vars
/// @param[in]		pLogRecord - Pointer to current log record
/// @param[in] 		pDirectVar - data item to log
/// @param[in]		pMaxMin pointer to the channel max-min object
/// @param[in]		pAverage pointer to the channel average object
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
BOOL CLogControl::Log(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, CDataItem *pDataItem,
		CBasicMaxMin *pMaxMin, CBasicAverage *pAverage) {
	BOOL bResult = TRUE;

	T_TV5TIME ReadingTime = pSYSTIMER->GetCurrentProcessTimeTV5Ref();

	if (LOGTYPE_CONTINUOUS == m_pLogging->LogType) {	// Continuous log
		if (LOGSTYLE_SAMPLE == m_pLogging->LogStyle) {	// Sample
			bResult = CLogRec::AddContReading(pLogRecordVars, pLogRecord, pDataItem->GetFPValue());
		} else if (LOGSTYLE_AVERAGE == m_pLogging->LogStyle) {	// Average
			bResult = CLogRec::AddContReading(pLogRecordVars, pLogRecord, pAverage->GetAverage());
			pAverage->ResetAverage();
		} else if (LOGSTYLE_MAXMIN == m_pLogging->LogStyle) {	// Max-Min
			bResult = CLogRec::AddContMaxMin(pLogRecordVars, pLogRecord, pMaxMin->GetMax(), pMaxMin->GetMin());
			pMaxMin->ResetMaxMin();
		} else {	///@todo Unknown log style
			bResult = FALSE;
		}
	} else if (LOGTYPE_FUZZY == m_pLogging->LogType) {	// Fuzzy Logging
		bResult = AddFuzzyReading(pLogRecordVars, pLogRecord, &ReadingTime, &FuzzyControl, pDataItem->GetFPValue());
	} else {	///@todo Unknown log type
		bResult = FALSE;
	}
	return bResult;
}

//****************************************************************************
/// LogControl utility: recover after power loss
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
BOOL CLogControl::PowerRecovery(void) {
	/// @todo Recover after power failure
	SetReason (RESET_PWRFAIL);
	return TRUE;
}


/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Processing
/// @n Filename: LogDeviceStatus.cpp
/// @n Desc:	 Maintain status between logging device and internal log store
///				 
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  54  Aristos  1.48.1.3.1.0 9/19/2011 4:51:16 PM  Hemant(HAIL)  
//  Stability recorder source code (JI Release) updated for WatchDog
//  Timer functionality.
//  53  Stability Project 1.48.1.3 7/2/2011 4:58:25 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  52  Stability Project 1.48.1.2 7/1/2011 4:38:27 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  51  Stability Project 1.48.1.1 3/17/2011 3:20:28 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
// $
// //	Shankar Rao Pendyala 08/17/2017	Fix for CSV new data tranfer issues when toggles b/w TVEncrypt and CSV 
//		And allow FTP transfer always even with CSV opted for data export format in TV
//
// ****************************************************************

#include "V6globals.h"
#include "TraceDefines.h"
#include "LogDeviceStatus.h"
#include "ThreadInfo.h"
#include "QueueManager.h"

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif

CLogDeviceStatus *CLogDeviceStatus::pInstance = NULL;
QMutex hCreationMutex;

//****************************************************************************
/// Transfer status: class constructor (private)
///
/// @return			none
///
/// @note			class initialisation, called by the new in GetHandle
//****************************************************************************
CLogDeviceStatus::CLogDeviceStatus() {
	m_pSRAM = NULL;
	m_RegionSize = 0;
	m_pNV_status = NULL;
	m_pNV_CSVstatus = NULL;
	QMutex* m_hCritical;
	QMutex* m_hInitialise;
}

//****************************************************************************
/// Transfer status: class initialisation
///
/// @return			none
///
/// @note			class initialisation, called by the new in GetHandle
//****************************************************************************
void CLogDeviceStatus::Initialise() {
	//EnterCriticalSection( &m_hInitialise );
	m_hCritical.lock();
	{
		if (NULL == m_pSRAM) {
			// Create NV data block pointer
			m_pSRAM = CSRAMManager::GetHandle();
			m_pSRAM->Initialise();

			m_pTstore = NULL;
			m_pTstore_csv = NULL;
			// Request a ptr to the CSRAMRegion instance for the corrisponding regionIdent
			CSRAMManager::regionError requestReturn = m_pSRAM->RequestRegion(REGION_TRANSFER, &m_pTstore);

			if (requestReturn != CSRAMManager::REGION_OKAY) {
				m_pNV_status = NULL;
				//LeaveCriticalSection( &m_hInitialise );
				m_hCritical.lock();
				LOG_CRTL( TRACE_TRANSFER, " CRITICAL error\n Transfer status RAM region not available.");
				return;
			}

			// Request a ptr to the CSRAMRegion instance for the corresponding regionIdent
			requestReturn = m_pSRAM->RequestRegion(REGION_CSV_TRANS, &m_pTstore_csv);

			if (requestReturn != CSRAMManager::REGION_OKAY) {
				m_pNV_status = NULL;
				//LeaveCriticalSection( &m_hInitialise );
				m_hCritical.lock();
				LOG_CRTL( TRACE_TRANSFER, " CRITICAL error\n CSV Transfer status RAM region not available.");
				return;
			}

			// Get the RAM region address
			m_pNV_status = (T_QCHANNEL_STATUS*) m_pTstore->GetAddress();
			m_pNV_CSVstatus = (T_QCHANNEL_STATUS*) m_pTstore_csv->GetAddress();

			m_RegionSize = (USHORT) m_pTstore->GetAvailableBytes();
			qDebug("DataTransfer Region Size %dBytes and Used Size %dBytes", m_RegionSize, sizeof(T_QCHANNEL_STATUS));
			if (m_RegionSize < sizeof(T_QCHANNEL_STATUS)) {
				LOG_CRTL( TRACE_TRANSFER, "Transfer status store size error, region too small.");
			}

			if ( pSYSTEM_INFO->IsDataResetRequested() == TRUE) {
				// A reset is required so delete the SRAM queue system
				m_pTstore->ClearRegion();
				m_pTstore_csv->ClearRegion();
			}

			// Check if this is first time usage
			if (SRAM_STATE_FIRSTUSE == m_pTstore->GetAutoState()) {
				InitStore();
				pSYSTEM_INFO->SetDataResetRequired();

				// Clear out the Logging region 
				CSRAMRegion *tempRegion = NULL;
				CSRAMManager::regionError requestReturn = m_pSRAM->RequestRegion(REGION_LOGGING, &tempRegion);
				if (requestReturn == CSRAMManager::REGION_OKAY) {
					tempRegion->ClearRegion();
				}
				m_pSRAM->ReleaseRegion(REGION_LOGGING);

			}
		}
	}
	//Coverity #776689
	//LeaveCriticalSection( &m_hInitialise );//Make it single Critical Section instead of two and bringing order dependencies
	m_hCritical.lock();
	return;
}

//****************************************************************************
/// Transfer status: class destructor (private)
///
/// @return			none
///
/// @note			class destruction, called by the delete in Cleanup
//****************************************************************************
CLogDeviceStatus::~CLogDeviceStatus() {
	if (NULL != m_pSRAM) {
		m_pSRAM->ReleaseRegion(REGION_TRANSFER);
		m_pSRAM->ReleaseRegion(REGION_CSV_TRANS);
		//deletion of mutex not required
		//deletion of mutex not required
	}
	return;
}

//****************************************************************************
/// Transfer status: initialise status store RAM region
///
/// @return			none
///
/// @note			class destruction, called by the delete in Cleanup
//****************************************************************************
void CLogDeviceStatus::InitStore() {
	T_QMC_FILE_BLOCK_TRANSACTION defaultLocation = { QMC_INVALID_FILE_NUMBER, QMC_INVALID_BLOCK_NUMBER, 0,
			QMC_TRANS_INITIALISED };

	m_hCritical.lock();
	{
		m_pTstore->SetAutoStateToUpdating();
		m_pTstore_csv->SetAutoStateToUpdating();

		for (USHORT instance = 0; instance < (V6_MAX_PENS + MAX_MESSAGE_LISTS); instance++) {
			for (USHORT device = 0; device < LOGDEV_MAX_DEVICES; device++) {
				m_pNV_status->channel[instance].devStatus[device].TRansferredDataEndPoint = defaultLocation;
				m_pNV_status->channel[instance].devStatus[device].ConfirmedDataEndPoint = defaultLocation;

				m_pNV_CSVstatus->channel[instance].devStatus[device].TRansferredDataEndPoint = defaultLocation;
				m_pNV_CSVstatus->channel[instance].devStatus[device].ConfirmedDataEndPoint = defaultLocation;
			}
		}

		m_pTstore->SetAutoStateToNormal();
		m_pTstore_csv->SetAutoStateToNormal();
	}
	m_hCritical.lock();

	LOG_INFO( TRACE_TRANSFER, "CLogDeviceStatus NV region first use");
	return;
}

//****************************************************************************
/// Transfer status: singleton get instance handle
///
/// @return			instance handle or NULL if creation failed
///
/// @note 
//****************************************************************************
CLogDeviceStatus* CLogDeviceStatus::GetHandle() {
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;

	if (NULL == pInstance) {
		hCreationMutex = CreateMutex(NULL,					// No security descriptor
				FALSE,					// Mutex object not owned
				L"TransferStatus");		// Object name

		waitSingleObjectResult = hCreationMutex.tryLock(g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);

		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:
			// Object was signaled
			if (NULL == pInstance) {
				pInstance = new CLogDeviceStatus;
				LOG_INFO( TRACE_TRANSFER, "CLogDeviceStatus new Instance created");
			}
			if ( FALSE == hCreationMutex.unlock()) {
				V6WarningMessageBox(NULL, L"Failed to release CLogDeviceStatus mutex", L"Error", MB_OK);
			} // End of IF

			break;

		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
			V6WarningMessageBox(NULL, L"CLogDeviceStatus WaitForSingleObject Error", L"Error", MB_OK);
			break;
		}
		// Close the Mutex as no longer required
		//No need to close the mutex in Qt
	}
	return pInstance;
}

//****************************************************************************
/// Transfer status: singleton cleanup
///
/// @return			always TRUE
///
/// @note 
//****************************************************************************
BOOL CLogDeviceStatus::Cleanup() {
	if (NULL != pInstance) {
		delete pInstance;
		pInstance = NULL;
	}

	return TRUE;
}

//****************************************************************************
/// Transfer status: set status
///
/// @param[in]		device - data transfer device
/// @param[in]		instance - log channel instance (zero based)
/// @param[in]		type - status type
/// @param[in]		location - status (block location)
///
/// @return			TRUE if all OK, else FALSE
///
/// @note 
//****************************************************************************
BOOL CLogDeviceStatus::SetStatus(T_LOG_DEVICE device, USHORT instance, T_STATUS_TYPE type,
		T_QMC_FILE_BLOCK_TRANSACTION location, T_DATA_EXPORT_FORMAT_TYPE eExportasprintfType) {
	BOOL bResult = FALSE;

	if (NULL == m_pNV_status)
		Initialise();

	T_QCHANNEL_STATUS *pNVStatus = NULL;
	if (EXPORT_FORMAT_CSV == eExportasprintfType) {
		pNVStatus = m_pNV_CSVstatus;
	} else {
		pNVStatus = m_pNV_status;
	}

	if (instance < (V6_MAX_PENS + MAX_MESSAGE_LISTS) && NULL != pNVStatus) {
		m_hCritical.lock();
		{
//			location.recycleState = QMC_TRANS_INUSE;

			switch (type) {
			case TYPE_CONFIRMED:
				pNVStatus->channel[instance].devStatus[device].ConfirmedDataEndPoint = location;
				bResult = TRUE;
				break;

			case TYPE_TRANSFERED:
				pNVStatus->channel[instance].devStatus[device].TRansferredDataEndPoint = location;
				bResult = TRUE;
				break;

			default:
				LOG_INFO( TRACE_TRANSFER, "CLogDeviceStatus Unknown transfer status type?");
			}
		}
		m_hCritical.lock();
	}
	return bResult;
}

//****************************************************************************
/// Transfer status: get status
///
/// @param[in]		device - data transfer device
/// @param[in]		instance - log channel instance (zero based)
/// @param[in]		type - status type
///
/// @return			status (block location)
///
/// @note 
//****************************************************************************
T_QMC_FILE_BLOCK_TRANSACTION* CLogDeviceStatus::GetStatus(T_LOG_DEVICE device, USHORT instance, T_STATUS_TYPE type,
		T_DATA_EXPORT_FORMAT_TYPE eExportasprintfType) {
	T_QMC_FILE_BLOCK_TRANSACTION *location = NULL;

	if (NULL == m_pNV_status)
		Initialise();

	T_QCHANNEL_STATUS *pNVStatus = NULL;
	if (EXPORT_FORMAT_CSV == eExportasprintfType) {
		pNVStatus = m_pNV_CSVstatus;
	} else {
		pNVStatus = m_pNV_status;
	}

	if (instance < (V6_MAX_PENS + MAX_MESSAGE_LISTS) && NULL != pNVStatus) {
		m_hCritical.lock();
		{
			switch (type) {
			case TYPE_CONFIRMED:
				location = &pNVStatus->channel[instance].devStatus[device].ConfirmedDataEndPoint;
				break;

			case TYPE_TRANSFERED:
				location = &pNVStatus->channel[instance].devStatus[device].TRansferredDataEndPoint;
				break;

			default:
				LOG_INFO( TRACE_TRANSFER, "CLogDeviceStatus Unknown transfer status type?");
			}
		}
		m_hCritical.lock();
	}
	return location;
}

//****************************************************************************
/// Transfer status: UpdateRecycled
/// Reset the transaction points if it is about to be overwritten when file is being recycled
/// @param[in]		Channel - log channel instance (zero based)
/// @param[in]		FileID - File to check against
/// @param[in]		BlockID - Block to check against or QMC_INVALID_BLOCK_NUMBER
///					when the whole file is being zapped
///
/// @return			True if any devices have been reset
///
/// @note			Only updates Transferred, not Confirmed end points
//****************************************************************************
BOOL CLogDeviceStatus::UpdateRecycled(const USHORT Channel, const USHORT FileID, const USHORT BlockID) {
	CQueueManager *pq_manager = CQueueManager::GetHandle();

	BOOL RetVal = FALSE;
	//Sanity tests
#ifdef UNDER_CE
	CThreadInfo* pThreadInfo= CThreadInfo::GetHandle();
#endif
	if (NULL == m_pNV_status)
		Initialise();

	if (((V6_MAX_PENS + MAX_MESSAGE_LISTS) > Channel) && (QMC_INVALID_FILE_NUMBER != FileID)
			&& (TRUE == pq_manager->ValidateFileId(FileID))) {
		m_hCritical.lock();
		{
			//check each device for the supplied block and file, as it's just been overwritten 
			for (int d = 0; d < LOGDEV_MAX_DEVICES; d++) {
#ifdef UNDER_CE
				if(pThreadInfo != NULL)
				{
					//Update the thread counter of diskservices thread 

					pThreadInfo->UpdateThreadCounter(AM_QMDISKSERVICES);
					
				} 
#endif
				//test for Invalid BlockID to indicate that the whole file is being blatted
				//only check the file number not the block
				if ((QMC_INVALID_BLOCK_NUMBER == BlockID
						&& FileID == m_pNV_status->channel[Channel].devStatus[d].TRansferredDataEndPoint.fileId)
						|| (FileID == m_pNV_status->channel[Channel].devStatus[d].TRansferredDataEndPoint.fileId
								&& BlockID
										== m_pNV_status->channel[Channel].devStatus[d].TRansferredDataEndPoint.blockId)) {
					//reset file and block number
					m_pNV_status->channel[Channel].devStatus[d].TRansferredDataEndPoint.fileId =
							QMC_INVALID_FILE_NUMBER;
					m_pNV_status->channel[Channel].devStatus[d].TRansferredDataEndPoint.blockId =
							QMC_INVALID_BLOCK_NUMBER;
					m_pNV_status->channel[Channel].devStatus[d].TRansferredDataEndPoint.recycleState =
							QMC_TRANS_RECYCLED;

					RetVal = TRUE;
				}

				//CSVStoreUpdate - test for Invalid BlockID to indicate that the whole file is being blatted
				//only check the file number not the block
				if ((QMC_INVALID_BLOCK_NUMBER == BlockID
						&& FileID == m_pNV_CSVstatus->channel[Channel].devStatus[d].TRansferredDataEndPoint.fileId)
						|| (FileID == m_pNV_CSVstatus->channel[Channel].devStatus[d].TRansferredDataEndPoint.fileId
								&& BlockID
										== m_pNV_CSVstatus->channel[Channel].devStatus[d].TRansferredDataEndPoint.blockId)) {
					//reset file and block number
					m_pNV_CSVstatus->channel[Channel].devStatus[d].TRansferredDataEndPoint.fileId =
							QMC_INVALID_FILE_NUMBER;
					m_pNV_CSVstatus->channel[Channel].devStatus[d].TRansferredDataEndPoint.blockId =
							QMC_INVALID_BLOCK_NUMBER;
					m_pNV_CSVstatus->channel[Channel].devStatus[d].TRansferredDataEndPoint.recycleState =
							QMC_TRANS_RECYCLED;

					RetVal = TRUE;
				}

				// If an FTP is in progress, must remember to recycle any saved transaction points
				if (LOGDEV_FTP == d
						&& QMC_TRANS_ROLLBACK
								== (m_pNV_status->channel[Channel].devStatus[d].ConfirmedDataEndPoint.recycleState
										& 0xF00)) {
					//test for Invalid BlockID to indicate that the whole file is being blatted
					//only check the file number not the block
					if ((QMC_INVALID_BLOCK_NUMBER == BlockID
							&& FileID == m_pNV_status->channel[Channel].devStatus[d].ConfirmedDataEndPoint.fileId)
							|| (FileID == m_pNV_status->channel[Channel].devStatus[d].ConfirmedDataEndPoint.fileId
									&& BlockID
											== m_pNV_status->channel[Channel].devStatus[d].ConfirmedDataEndPoint.blockId)) {
						//reset file and block number
						m_pNV_status->channel[Channel].devStatus[d].ConfirmedDataEndPoint.fileId =
								QMC_INVALID_FILE_NUMBER;
						m_pNV_status->channel[Channel].devStatus[d].ConfirmedDataEndPoint.blockId =
								QMC_INVALID_BLOCK_NUMBER;
						m_pNV_status->channel[Channel].devStatus[d].ConfirmedDataEndPoint.recycleState =
								(QMC_TRANS_RECYCLED | QMC_TRANS_ROLLBACK);

						RetVal = TRUE;
					}
				}
			}
		}
		m_hCritical.lock();
	}
	return RetVal;
}

//****************************************************************************
/// Convert a T_LOG_DEVICE enumerated type to a T_STORAGE_DEVICE type
///
/// @param[in]		logDevice, T_LOG_DEVICE to convert
///
/// @return			T_STORAGE_DEVICE equivilent of T_LOG_DEVICE
//****************************************************************************
T_STORAGE_DEVICE CLogDeviceStatus::LogDeviceToStorageDevice(T_LOG_DEVICE logDevice) {
	T_STORAGE_DEVICE storageDevice = IDS_FIRST_USB;
	switch (logDevice) {
	case LOGDEV_FTP:
		storageDevice = IDS_INTERNAL_SD;
		break;
	case LOGDEV_EXT_SD:
		storageDevice = IDS_EXTERNAL_SD;
		break;
	case LOGDEV_USB1:
		storageDevice = IDS_FIRST_USB;
		break;
	case LOGDEV_USB2:
		storageDevice = IDS_SECOND_USB;
		break;
	case LOGDEV_SHARE:
		storageDevice = IDS_SHARE;
		break;
	default:
		//V6WarningMessageBox( NULL, L"Unknown T_LOG_DEVICE type \n LogDeviceStatus Line 391", L"Coding error", MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST );
		break;
	}
	return storageDevice;
}

//****************************************************************************
/// DataTransfer service: Update the transaction point
///
/// @param[in] device - storage device ID, used for transfer status
/// @param[in] instance - transaction point instance
/// @param[in] pTransactionPoint - new transaction point
///
/// @return	None
///
/// @note --- Delete if not requried ---
//****************************************************************************
void CLogDeviceStatus::UpdateTransactoionPoint(T_LOG_DEVICE device, USHORT instance,
		T_QMC_FILE_BLOCK_TRANSACTION *pTransactionPoint, T_DATA_EXPORT_FORMAT_TYPE eExportasprintfType) {
	const T_QMC_FILE_BLOCK_TRANSACTION NewPoint = *pTransactionPoint;

	if (LOGDEV_FTP != device) {
		m_hCritical.lock();
		{
			for (USHORT deviceInstance = LOGDEV_EXT_SD; deviceInstance < LOGDEV_MAX_DEVICES; deviceInstance++) {
				if (LOGDEV_FTP != deviceInstance) {
					SetStatus((T_LOG_DEVICE) deviceInstance, instance, TYPE_TRANSFERED, NewPoint, eExportasprintfType);
				}
			}
		}
		m_hCritical.lock();
	} else {
		// FTP transaction point update...
	}
}

//****************************************************************************
/// DataTransfer service: Save a copy of the FTP transaction points
///
/// @return		None	
///
/// @note --- Delete if not requried ---
//****************************************************************************
void CLogDeviceStatus::SaveAllFTPTransactionPoints() {
	T_QMC_FILE_BLOCK_TRANSACTION *pOtherTransactionPoint;
#ifdef UNDER_CE
	CThreadInfo* pThreadInfo = CThreadInfo::GetHandle();
#endif

	m_hCritical.lock();
	{
		for (USHORT usPen = 0; usPen < V6_MAX_PENS; usPen++) {
			pOtherTransactionPoint = GetStatus(LOGDEV_FTP, usPen, TYPE_TRANSFERED);
			if (NULL != pOtherTransactionPoint) {
				pOtherTransactionPoint->recycleState |= QMC_TRANS_ROLLBACK;
				SetStatus(LOGDEV_FTP, usPen, TYPE_CONFIRMED, *pOtherTransactionPoint);
			}
#ifdef UNDER_CE
			if(pThreadInfo != NULL)
			{
				//Update the Thread Counter for the TxScheduler thread
				//thread after each iteration

				pThreadInfo->UpdateThreadCounter(AM_TX_SCHEDULER_THREAD);
				
			}
			#endif

		}
		for (USHORT usList = 0; usList < CMessageListServices::msqMAX_QUEUES; usList++) {
			pOtherTransactionPoint = GetStatus(LOGDEV_FTP, usList + V6_MAX_PENS, TYPE_TRANSFERED);
			if (NULL != pOtherTransactionPoint) {
				pOtherTransactionPoint->recycleState |= QMC_TRANS_ROLLBACK;
				SetStatus(LOGDEV_FTP, usList + V6_MAX_PENS, TYPE_CONFIRMED, *pOtherTransactionPoint);
			}
#ifdef UNDER_CE	
			if(pThreadInfo != NULL)
			{
				//Update the Thread Counter for the TxScheduler thread
				//thread after each iteration

				pThreadInfo->UpdateThreadCounter(AM_TX_SCHEDULER_THREAD);
				
			}
#endif
		}
	}
	m_hCritical.lock();
}

//****************************************************************************
/// DataTransfer service: Clear any roll=back transaction points
///
/// @return		None	
///
/// @note --- Delete if not requried ---
//****************************************************************************
void CLogDeviceStatus::ClearRollBack() {
	T_QMC_FILE_BLOCK_TRANSACTION *pOtherTransactionPoint;
#ifdef UNDER_CE
	CThreadInfo* pThreadInfo = CThreadInfo::GetHandle();
#endif
	m_hCritical.lock();
	{
		for (USHORT usPen = 0; usPen < V6_MAX_PENS; usPen++) {
#ifdef UNDER_CE
			if(pThreadInfo != NULL)
			{
				//Update the Thread Counter for the TxScheduler thread
				//thread after each iteration

				pThreadInfo->UpdateThreadCounter(AM_TX_SCHEDULER_THREAD);
			}
#endif

			pOtherTransactionPoint = GetStatus(LOGDEV_FTP, usPen, TYPE_CONFIRMED);
			if (NULL != pOtherTransactionPoint) {
				if (QMC_TRANS_ROLLBACK == (pOtherTransactionPoint->recycleState & QMC_TRANS_ROLLBACK))
					pOtherTransactionPoint->recycleState = QMC_TRANS_INITIALISED;
			}
		}
		for (USHORT usList = 0; usList < CMessageListServices::msqMAX_QUEUES; usList++) {
#ifdef UNDER_CE	
			if(pThreadInfo != NULL)
			{
				//Update the Thread Counter for the TxScheduler thread
				//thread after each iteration

				pThreadInfo->UpdateThreadCounter(AM_TX_SCHEDULER_THREAD);
				
			}
#endif		
			pOtherTransactionPoint = GetStatus(LOGDEV_FTP, usList + V6_MAX_PENS, TYPE_CONFIRMED);
			if (NULL != pOtherTransactionPoint) {
				if (QMC_TRANS_ROLLBACK == (pOtherTransactionPoint->recycleState & QMC_TRANS_ROLLBACK))
					pOtherTransactionPoint->recycleState = QMC_TRANS_INITIALISED;
			}
		}
	}
	m_hCritical.lock();
}

//****************************************************************************
/// DataTransfer service: Roll-Back transaction points, if required
///
/// @return		None	
///
/// @note --- Delete if not requried ---
//****************************************************************************
void CLogDeviceStatus::RollBackIfRequired() {
	T_QMC_FILE_BLOCK_TRANSACTION *pOtherTransactionPoint;

	// Make sure the object has been initialised , this method will be called during start-up
	if (NULL == m_pNV_status)
		Initialise();

	m_hCritical.lock();
	{
		for (USHORT usPen = 0; usPen < V6_MAX_PENS; usPen++) {
			pOtherTransactionPoint = GetStatus(LOGDEV_FTP, usPen, TYPE_CONFIRMED);
			if (NULL != pOtherTransactionPoint
					&& QMC_TRANS_ROLLBACK == (pOtherTransactionPoint->recycleState & QMC_TRANS_ROLLBACK)) {
				pOtherTransactionPoint->recycleState &= ~QMC_TRANS_ROLLBACK;
				SetStatus(LOGDEV_FTP, usPen, TYPE_TRANSFERED, *pOtherTransactionPoint);
			}
		}
		for (USHORT usList = 0; usList < CMessageListServices::msqMAX_QUEUES; usList++) {
			pOtherTransactionPoint = GetStatus(LOGDEV_FTP, usList + V6_MAX_PENS, TYPE_CONFIRMED);
			if (NULL != pOtherTransactionPoint
					&& QMC_TRANS_ROLLBACK == (pOtherTransactionPoint->recycleState & QMC_TRANS_ROLLBACK)) {
				pOtherTransactionPoint->recycleState &= ~QMC_TRANS_ROLLBACK;
				SetStatus(LOGDEV_FTP, usList + V6_MAX_PENS, TYPE_TRANSFERED, *pOtherTransactionPoint);
			}
		}
	}
	m_hCritical.lock();
}

//****************************************************************************
/// DataTransfer service: Restore a previously saved copy of the FTP transaction points
///
/// @return		None	
///
/// @note --- Delete if not requried ---
//****************************************************************************
void CLogDeviceStatus::RestoreAllFTPTransactionPoints() {
	T_QMC_FILE_BLOCK_TRANSACTION *pOtherTransactionPoint;

	m_hCritical.lock();
	{
		for (USHORT usPen = 0; usPen < V6_MAX_PENS; usPen++) {
			pOtherTransactionPoint = GetStatus(LOGDEV_FTP, usPen, TYPE_CONFIRMED);
			if (NULL != pOtherTransactionPoint) {
				pOtherTransactionPoint->recycleState &= ~QMC_TRANS_ROLLBACK;
				SetStatus(LOGDEV_FTP, usPen, TYPE_TRANSFERED, *pOtherTransactionPoint);
			}
		}
		for (USHORT usList = 0; usList < CMessageListServices::msqMAX_QUEUES; usList++) {
			pOtherTransactionPoint = GetStatus(LOGDEV_FTP, usList + V6_MAX_PENS, TYPE_CONFIRMED);
			if (NULL != pOtherTransactionPoint) {
				pOtherTransactionPoint->recycleState &= ~QMC_TRANS_ROLLBACK;
				SetStatus(LOGDEV_FTP, usList + V6_MAX_PENS, TYPE_TRANSFERED, *pOtherTransactionPoint);
			}
		}
	}
	m_hCritical.lock();
}


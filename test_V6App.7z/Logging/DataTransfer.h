/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 Data Transferutilities
/// @n DataTransfer.h
/// @n Main data transfer class.
/// @author Honeywell
/// @date 11/04/2005
///
// 
// *******************************************
// Revision History
// *******************************************
// Vellaidurai V 2/07/2013 Fixed PAR: 1-29FL9RH Event loging in csv format is not proper
//Master PAR: 1-2FTMPXV CSV Export:ScheduleExport Issue + EventLogging Issue + Group Export Issue
//Fix for Senario 5: Schedule export missed to log events in csv file. 
// Vellaidurai V 2/07/2013Fixed PAR: 1-118V3EP - Recorder data Export in CSV creates Folder but do not create XLS files
//Fix for Senario : Export Aborted message implemented
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef __DATATRANSFER_H_INCLUDED__
#define __DATATRANSFER_H_INCLUDED__

#include "PassiveModule.h" 
#include "TVtime.h"
#include "logrec.h"
#include "DataChannel.h"					// logged data channel wrapper class
#include "LogConfiguration.h"				// configuration data (LCM) wrapper class
#include "TransferDevice.h"					// transfer device wrapper class
#include "InternalMessageQueue.h"
#include "BlockControl.h"

#include "CStorage.h"
#include "BatchInfo.h"
#include <iostream>// std::cin, std::cout
#include <queue> // std::queue

#include <QVector>
// Comment-out to use contiguous export, un-comment to use split (enumerated) export folders
#define USE_SPLIT_EXPORT
// Number of exports before a folder nudge
#define EXPORT_ROLLOVER_LIMIT	25
// Number of dead sessions before an LCM clean-up is required
#define LCM_CLEANUP_THRESHOLD	5

typedef enum {
	TR_TRANSFER_ALL, TR_TRANSFER_NEW, TR_TRANSFER_SPAN
} T_TRANSFER_TYPE;

// Data transfer session span, used to decide what LCM data is required
typedef struct {
	USHORT StartSession;
	USHORT EndSession;
} T_SESSION_SPAN;

// Data transfer worker thread operational state, used for clean shut-down
typedef enum {
	TTS_START_UP, TTS_RUNNING, TTS_SHUTDOWN
} T_TRANSFER_THREAD_STATE;

// Data transfer worker thread shared data, allows the thread to be shut-down without sending a message
typedef struct {
	T_LOG_DEVICE Scandevice;
	T_TRANSFER_THREAD_STATE ThreadState;
} T_TRANSFER_DATA;

typedef enum {
	ERROR_NONE,						// No error, creation suceeded
	ERROR_EXISTS,					// Creation failed, already exists
	ERROR_FAILED					// Creation failed, err!
} e_FOLDER_ERROR;

typedef struct {
	bool bIsUpdated;
	float samplePrevReading;
	float averagePrevReading;
	float minPrevReading;
	float maxPrevReading;
} T_PEN_INFO;

typedef struct {
	QString   strData;
	QString   strDateTime;
	TV5Time tCurrentTime;

} T_DATA_INFO;

typedef std::vector<T_LOGRECORD> LOGRECORDVEC;
typedef std::vector<int> LOGRECORDREADINGS;
typedef std::vector<T_MSGLISTSER_MESSAGE> LOGEVENTVEC;
typedef std::vector<bool> LOGRECORDEXISTVEC;

//**Class*********************************************************************
///
/// @brief Data transfer folder utilities
/// 
//****************************************************************************
class CTransferFolder {
public: // methods
	CTransferFolder();
	~CTransferFolder();

	BOOL CreateNext(QString  wcBasePath);
	e_FOLDER_ERROR Create(QString  wcBasePath, ULONG ulFolder);
	ULONG GetLastUsedFolder(QString  wcBasePath);
	ULONG GetCurrentFolder() {
		return m_ulCurrentFolder;
	}
	;

private: // methods

public: // data

private: // data

	ULONG m_ulCurrentFolder;
};

//**Class*********************************************************************
///
/// @brief Data transfer main (do stuff) functional class
/// 
///
//****************************************************************************

class CDataTransfer: public CPassiveModule {
public:

	/// Enum indicating the various states the data transfer methods can return
	typedef enum {
		teOK,
		teMEDIA_FULL,
		teMEDIA_NOT_PRESENT,
		teMEDIA_GENERIC_ERROR,
		teMEDIA_FAILED_TO_CREATE_EXPORT_FOLDER,
		teINVALID_TRANSACTION_POINT,
		teINVALID_TRANSACTION_POINT_NO_ABORT,
		teBLOCK_SERVICES_REPLY_ERROR,
		teFTP_USER_CANCELLED,
		teFTP_BUFFER_FULL,
	// teNO_DATA_TO_EXPORT REMOVED FOR NOW AS POSSIBLY A TOO HIGH RISK CHANGE
	} T_TRANSFER_ERRORS;

	static CDataTransfer* GetHandle();
	BOOL CleanUp();
	void Initialise();

	void FlashLED(USHORT Times, USHORT Delay, BOOL FinalState);
	void RequestStop(BOOL State) {
		m_StopRequest = State;
	}
	;

	const T_TRANSFER_ERRORS TransferAll(T_LOG_DEVICE device);
	const T_TRANSFER_ERRORS TransferAllNew(T_LOG_DEVICE device);
	const T_TRANSFER_ERRORS TransferAllUnconfirmed(T_LOG_DEVICE device);

	void SetBlocksWaiting(ULONG Blocks) {
		m_TotalBlocksToTransfer = Blocks;
	}
	;
	void ClearPercentage() {
		m_Percentage = 0;
	}
	;
	void ClearTransferComplete() {
		m_TransferComplete = FALSE;
	}
	;

	// Method that gets details about the passed in media type
	const bool GetMediaDetails(const T_LOG_DEVICE eLOG_DEVICE, ULONG &rulSpace, ULONG &rulTotal) const;

	// Method that returntrue if the passed in device is present
	const bool IsDevicePresent(const T_LOG_DEVICE eLOG_DEVICE, BOOL bDelay = FALSE) const;

	// Method that returns the devices name
	const QString   GetDeviceName(const T_LOG_DEVICE eLOG_DEVICE) const;

	// Committed log block count methods
	void ClearBlockCount() {
		CBlockControl::ClearBlockCount();
	}
	;
	unsigned long GetBlockCount() {
		CBlockControl::GetBlockCount();
	}
	;

	void FlushAllLoggingQueues();

	USHORT GetTransferPercentage() {
		return m_Percentage;
	}
	;
	BOOL TransferComplete() {
		return m_TransferComplete;
	}
	;
	BOOL IsExportAborted() {
		return m_bExportAborted;
	}
	;

	// Method that checks there is greater than 512K free on the device
	BOOL CheckMediaSpace(T_LOG_DEVICE device);
	BOOL CheckMediaSpaceCSVRecord(T_LOG_DEVICE device);
	T_TRANSFER_DATA m_ThreadControl;

	/// Method that indicates if the current error requires aborting an export
	const bool AbortExport(const T_TRANSFER_ERRORS eERROR) const {
		return (eERROR == teMEDIA_FULL) || (eERROR == teMEDIA_NOT_PRESENT) || (eERROR == teMEDIA_GENERIC_ERROR)
				|| (eERROR == teFTP_USER_CANCELLED) || (eERROR == teMEDIA_FAILED_TO_CREATE_EXPORT_FOLDER)
				|| (eERROR == teFTP_BUFFER_FULL) || (eERROR == teINVALID_TRANSACTION_POINT);
	}

	BOOL CleanLCMRequired();
	BOOL CleanLCM();

	// Method that copies the LCF files during a transfer
	const T_TRANSFER_ERRORS CopyLCFFiles(const QString  pwcPATHNAME, const T_LOG_DEVICE eLOG_DEVICE);

	void SaveAllFTPTransactionPoints();
	void RestoreAllFTPTransactionPoints();
	void ClearRollBack();
	void RollBackIfRequired();

	// Method that sets up the maximum number of blocks to transfer in an individual FTP transaction
	void SetFTPTransferBlocks(const DWORD dwCONN_SPEED);

	void NudgeExportFolder() {
		m_iExportCount = EXPORT_ROLLOVER_LIMIT;
	}
	;

	// Method that resets all the temporary 'export all' transaction points usually prior
	// to a transfer all via FTP
	void ResetExportAllTransPoints();

	// Method that resets the data transferred flags for the pre-trigger pens export list
	void ResetPreTrigPenTransferList() {
		for (int i = 0; i < V6_MAX_PENS; i++)
			m_baPreTrigPensTransferList[i] = false;
	}

	// Confirms the pen pre-trigger data has been exported successfully and
	// moves the pre-trigger state onto a restart
	void ClearPreTriggerData();
	void UpdateDevice(T_LOG_DEVICE deviceID);
	WCHAR* DevicePath(T_LOG_DEVICE device);
	void SetupCsvHeaderMulti(QString   strExportFilename, int fPenCnt);
	void SetupCsvHeaderMultiExtended(QString   strExportFilename, int fPenCnt);
	void WritePenInfo(float fCSVData, T_LOGRECORD record, QString   &rstrCSVData);
	void SpTimeToString(const TV5Time *const ptTIME, QString   &rstrTime) const;
	void SpTimeToStringEx(const TV5Time *const ptTIME, QString   &rstrTime) const;
	QString   CreateElapsedTimeString(TV5Time tElapsedTime) const;
	void UpdateSpan(T_LOGRECORD record);
	void WriteBatchTitle(QString   &strExportBatchCSVLine);
	void CheckNumber(QString   &String) const;
	void WritePrevPenInfo(QString   &rstrCSVData, int penIndex);
	QString   GetFolderName();	//Added by aditya
	TV5Time GetExportStartTime() const;
	TV5Time GetExportEndTime() const;
	void ApplyHMAC();
	void CreateCSVfileWithTemplate(int nPenNo, QString   &strFileName);
	void AfterCSVDataTransfer(bool bTransferAborted = false);
	void ExportCSVEvents();
	bool m_bIsFileCreated;
	ULONG GetScheduleInterval();

	//PSR - Debug log exports
	const T_TRANSFER_ERRORS TransferDbgLogFiles(T_LOG_DEVICE device);
	const T_TRANSFER_ERRORS TransferDumpFiles(T_LOG_DEVICE device);
	const T_TRANSFER_ERRORS getDataExportasprintf(const T_LOG_DEVICE device,
			T_DATA_EXPORT_FORMAT_TYPE &eExportasprintf);//PSR-Fix to allow FTP Transfer even if Dataasprintf is selected as CSV.

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
	void LogDebugMessage(QString  & strDbgMsg);
	void SetDebugLogger(CDebugFileLogger* pDbgFileLogger);
	#endif

public:
	//Added by Aditya
	std::queue<QString> m_myFileNamesqueue;
	std::queue<T_DATA_INFO> m_myPenData[96];
	std::vector<QString> m_vecmyLoggingPenList;
	int m_nPenLogRate[96];
	TV5Time m_structPenStartTime[96];
	TV5Time m_structPenEndTime[96];
	TV5Time m_OverallEndTime;
	TV5Time m_structPenCurrentTime[96];
	TV5Time m_structNewDataPenStartTime[96]; // This is added by Aditya for New data export.
	//bool m_bIsNewDataTransfer[96];
	bool m_bIsNewDataTransfer;
	bool m_bIsNewData;
	static int m_nLograteCnt;
	int m_nPenIndexCnt[96];
	int m_nPenNewIndexCnt[96];
	bool m_bIsFirstPen;
	int m_nFirstPenNo;
	bool m_bIsStartTimeSet;
	QString   m_rstrCSVLine;
	QString   m_rstrCSVHeader;

	int m_ulPrevLogRate;
	QString   m_strTimeDateFileName;
	bool m_bIsNewPen;
	bool m_bIsFileOpen;
	CStdioFile *m_pFile[97];

private:
	CDataTransfer();
	~CDataTransfer();

	void LogError(QString   szMessage);

	USHORT CalculateTransferPercentage(ULONG CurrentBlockCount, ULONG TotalBlocks);

	const T_TRANSFER_ERRORS TransferPen(T_LOG_DEVICE device, QString  FullPath, USHORT QueueHandle, USHORT Instance,
			T_SESSION_SPAN &span, T_QMC_FILE_BLOCK_TRANSACTION *pTransactionPoint, BOOL bUpdateTransactionPoint);

	// Transfers pre-trigger data to the end of a pen file that is in the process of being exported
	void TransferPreTriggerData(int penInstance, QString   strFileName);

	const T_TRANSFER_ERRORS TransferQueueBlock(CStorage *pstoragefile, BOOL *pbComplete, T_LOG_DEVICE device,
			const USHORT QueueHandle, const USHORT Instance, T_SESSION_SPAN *pSpan,
			T_QMC_FILE_BLOCK_TRANSACTION *pTransactionPoint, const BOOL bUpdateTransactionPoint);

	const BOOL CompleteTransaction(USHORT QueueHandle, T_QMC_FILE_BLOCK_TRANSACTION *pTransactionPoint);
	const BOOL ResetToOldestAvailable(USHORT QueueHandle, T_QMC_FILE_BLOCK_TRANSACTION *pTransactionPoint);

	const T_TRANSFER_ERRORS TransferAllMessages(T_LOG_DEVICE device);
	const T_TRANSFER_ERRORS TransferAllNewMessages(T_LOG_DEVICE device);
	const T_TRANSFER_ERRORS TransferAllUnconfirmedMessages(T_LOG_DEVICE device);

	const T_TRANSFER_ERRORS TransferMessageList(T_LOG_DEVICE device, QString  FullPath, USHORT QueueHandle,
			USHORT Instance, T_QMC_FILE_BLOCK_TRANSACTION *pTransactionPoint, BOOL bUpdateTransactionPoint);

	void UpdateTransactoionPoint(T_LOG_DEVICE device, USHORT instance, T_QMC_FILE_BLOCK_TRANSACTION *pTransactionPoint,
			T_DATA_EXPORT_FORMAT_TYPE eExportasprintfType = EXPORT_FORMAT_TVENCRYPT);

	//QString  DevicePath( T_LOG_DEVICE device );

	BOOL GetNextDataBlock(USHORT QueueHandle, T_QMC_FILE_BLOCK_TRANSACTION *pTransactionPoint, BYTE *buffer,
			USHORT usNumBlocks = QMC_MAX_BLOCKS_ALLOWED_FOR_ONE_REQUEST);

	BOOL ValidateTransactionPoint(T_QMC_FILE_BLOCK_TRANSACTION *pTransactionPoint, USHORT QueueHandle);

	// Method that creates the export directory
	const T_TRANSFER_ERRORS CreateExportDir(const QString  pwcFULLPATH) const;
	const T_TRANSFER_ERRORS getDataExportasprintf(T_DATA_EXPORT_FORMAT_TYPE &eExportasprintf);//PSR-Fix to allow FTP Transfer even if Dataasprintf is selected as CSV.

	////PSR - DebugFile Logger integration and export scheme
	const T_TRANSFER_ERRORS CreateDbgLogExportDir(T_LOG_DEVICE device);

	//ANOOP code added to export the crash dumps.
	const T_TRANSFER_ERRORS SearchNCopyDumpFiles(QString   strFilePath);
	const T_TRANSFER_ERRORS CreateDumpExportDir(T_LOG_DEVICE device);

	static CDataTransfer *pInstance;			///< Single instance object pointer
	static HANDLE hCreationMutex;				///< Object creation mutex

	CTransferDevice m_StorageDevice[LOGDEV_MAX_DEVICES];
	CLogConfiguration m_Configuration;

	CInternalMessageQueue *m_pMessageQueue;

	BOOL m_Initialised;

	ULONG m_TotalBlocksToTransfer;				///< Total number of blocks to be transfered
	ULONG m_CurrentBlockCount;					///< Blocks transferred (so far) count
	USHORT m_Percentage;						///< Transfer percentage complete (0-100)
	BOOL m_TransferComplete;					///< Transfer complete flag
	BOOL m_StopRequest;							///< Emergency/user stop request	
	QMutex m_hCritical;

	BYTE m_buffer[sizeof(T_LOGRECORD) * QMC_MAX_BLOCKS_ALLOWED_FOR_ONE_REQUEST];

	/// Variable indicating the maximum number of blocks allowed to transfer in a single transaction
	/// during an FTP transfer
	ULONG m_ulCurrMaxFTPTransferBlocks;

	/// Const indicating the maximum number of transfer blocks on slow FTP connections
	static const ULONG m_ulMAX_TRANSFER_BLOCKS_SLOW;

	/// Const indicating the maximum number of transfer blocks on medium FTP and WSD connections
	static const ULONG m_ulMAX_FTP_TRANSFER_BLOCKS_MED;
	static const ULONG m_ulMAX_WSD_TRANSFER_BLOCKS_MED;

	/// Const indicating the maximum number of transfer blocks on fast FTP and WSD connections
	static const ULONG m_ulMAX_FTP_TRANSFER_BLOCKS_FAST;
	static const ULONG m_ulMAX_WSD_TRANSFER_BLOCKS_FAST;

	// Method that forces an update of the media device that data is currently bveing transferred to
	void ForceMediaUpdate(const T_LOG_DEVICE eLOG_DEVICE);
	DWORD GetOldestSession();
	const T_TRANSFER_ERRORS ExtractDataFromRecord(T_LOGRECORD logRecord, T_LOG_DEVICE device);
	void UpdateSpanField();
	LONG m_lNoOfRecords;
	LONG m_lTotalNoOfRecords;
	int m_nPartNo[96];

	int m_iExportCount;						///< Export counter
	ULONG m_ulExportFolder;					///< Current enumerated export folder

	// Array containing the temporary pen transaction points required when doing a transfer all via FTP
	T_QMC_FILE_BLOCK_TRANSACTION m_taExportAllPenTransPoints[V6_MAX_PENS];

	// Array containing the temporary message transaction points required when doing a transfer all via FTP
	T_QMC_FILE_BLOCK_TRANSACTION m_taExportAllMessageTransPoints[CMessageListServices::msqMAX_QUEUES];

	/// Const used to identify an uninitialised transaction point - specifically used for FTP ALL data transfers
	const USHORT m_usTRANS_POINT_NOT_INIT;

	/// Array used to indicate if whether a pre-trigger pen block has been transferred as part of the export process
	bool m_baPreTrigPensTransferList[V6_MAX_PENS];

	bool m_bIsFile_Created;
	QString   ms_strCSVDelimiter;
	QString   ms_strQUOTE;
	QString   ms_strCSVEOL;
	QString   m_strExportFilename;
	QString   m_strExportPreviousFilename;
	int m_nCurrPenNum;
	int m_bIsTimeUpdated;
	//QString  m_strExportFilename[96];//added by aditya

	TV5Time m_DataStartTime; /// Start time 
	TV5Time m_DataEndTime; /// End time
	TV5Time m_SpanEndTime; /// End time for the span

	//LOGRECORDVEC m_logRecVec[V6_MAX_PENS]; /// List of log records 
	//LOGRECORDREADINGS m_logRecReadings[V6_MAX_PENS]; /// Holds the number of readings in each log record
	LOGEVENTVEC m_logEventVec;	/// Holds the list of events
	LOGEVENTVEC m_logPenwiseEventVec;	/// Holds the list of events
	LOGRECORDEXISTVEC m_logRecExistVec;	///Vector contains the count of pens for which all 
										///the logrecords have been exported
	unsigned int m_enabledPens;														///Holds the number of enabled pens 
	// Store for the batch information for all the groups
	T_BATCH_INFO m_tBatchInfo[ GENERALCONFIG_GROUPNAME_SIZE]; /// Holds the batch info for the corresponding groups
	BOOL m_bIsBatchMode;									/// Flag decides if the data is to be exported in batch mode
	int m_groupNumber;										 /// Holds the group number of the configured batch
	TV5Time m_SamplePeriod;									 /// Holds the sample period 
	T_PLOGGING m_pLogging;									 /// Logging configuration data 
	CBasicMaxMin m_pMaxMin[V6_MAX_PENS];					 /// Holds the min max value for 96 pens
	CBasicAverage m_pAverage[V6_MAX_PENS];					 /// Holds the average value for 96 pens 
	T_PEN_INFO m_penInfoStruct[V6_MAX_PENS];				 /// Holds the pen info for 96 pens
	BOOL m_bIsEmptyBatch;									 /// Checks if the batch is empty 
	TV5Time m_batchStartTime; /// Holds the start time of batch
	TV5Time m_batchEndTime; /// Holds the end time of batch
	TV5Time m_StartTime; /// Holds the start time of export
	TV5Time m_EndTime; /// Holds the endTime of the export
	bool m_bIsBatchEnd; /// Flag decides if the batch has ended
	ULONG m_LogRate; /// Logging rate in 10ths of ms
	int m_blankLineLength;
	QString   m_strFolderName;
	bool m_bBatchStopped;

	//For testing , remove this later
	int m_nDataCounter[96];
	std::queue<float> m_nPenData[96];
	BOOL m_bExportAborted;

	////PSR - DebugFile Logger integration and export scheme
	QString   m_strDbgFileLogFolderName;
	QString   m_strDumpFolderName;

#ifdef DUMP_EXPORT_ENABLE
	static bool m_bExportDumpFiles;
	public://Make this public for now ..
		static void SetExportDumpFiles(bool isDumpExportRequired);
#endif

#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
	CDebugFileLogger* m_pDebugFileLogger;
#endif

};

#endif // __DATATRANSFER_H_INCLUDED__

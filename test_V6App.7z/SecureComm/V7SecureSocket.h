//////////////////////////////////////////////////////////////////////
/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		SecureComm
/// @n Filename:  V7SecureSocket.h
/// @n Description: Definition of the CV7SecureSocket class
///
// **************************************************************************
// Revision History
// **************************************************************************
// Project		Date			Team/Person			Comments
//	TVR211		09-Aug-2019		Shankar Rao P		Initial Draft
//
// **************************************************************************

#if !defined(_V7SECUREQAbstractSocket_H_INCLUDED_)
#define _V7SECUREQAbstractSocket_H_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "V7DbgLogDefines.h"
#include "CESecureSocket.h"

#include "V7TLSClient.h"
#include "V7TLSServCleComm.h"

//**CV7SecureSocket***********************************************************
///
/// @brief This class is designed to replace overloaded TcpScoket (this can be used for P2P only). 
/// It allows to use Secure TCP layer for all protocols like WSDAlternate, RDS etc
/// This can be even used for Secure P2P for TcpScoket base if required
///
///
//****************************************************************************
class CV7SecureSocket: public CCESecureSocket {
public:
	enum ESocketRoleType {
		SocketNone, SocketClient, SocketServer
	};

	/////////////CONSTRUCTION and DESTRUCTION
	CV7SecureSocket(ESocketTransMode eSTMode = ST_MODE_SECURE);
	CV7SecureSocket(QAbstractSocket skt, ESocketRoleType role, CredHandle *hServerCreds, CtxtHandle *hContext);
	virtual ~CV7SecureSocket();

	/////////SECURE CONTEXT 
	ESocketRoleType GetSocketRole() {
		return m_eSocketRole;
	}
	;
	void SetSocketRole(ESocketRoleType eSockRoleType) {
		m_eSocketRole = eSockRoleType;
	}
	;
	void EraseTLSSerOnceAccept();

	CtxtHandle* getContextHandle();
	CredHandle* getCredHanle();

#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
	virtual void SetDebugLogger(CDebugFileLogger* pDbgFileLogger);
	#endif

protected:
	///////////////////////////////////////////////////////
	// CONNECTION FUNCTIONS
	///////////////////////////////////////////////////////	

	//Used for TLS feature
	bool OnAccept(QAbstractSocket serviceSocket);

	//Used for TLS feature
	virtual bool OnConnect(QString  &addr);

	//For clean up secure objects that got created
	virtual void OnClose(/*asyncEvents*/int closeEvent);

	void CleanUp();

	///////////////////////////////////////////////////////
	// DATA ACCESS FUNCTIONS
	///////////////////////////////////////////////////////

	//! Notification on receiving Encrypted binary data.
	/*! Use this function to read buffered data.
	 * @param[out] buf The buffer that will receive the data. It must
	 * be already allocated.
	 * @param[in] len Length of the buffer.
	 * @return Number of bytes actually read.
	 */
	// Used for TLS feature
	virtual bool OnReceiveEncData(char *buf, int *len, char **ppExtraBuf, int *nExtraLen,
			E_ON_RECV_BUF_ACTION &eOrbAction);
	DWORD ClientTLSSend(QAbstractSocket Socket, char *sBuff, int iLen);
	DWORD ClientSecureSend(QAbstractSocket Socket, char *sBuff, int iLen);
	DWORD ClientEncryptSend(QAbstractSocket Socket, CtxtHandle *phContext, PBYTE pbIoBuffer, SecPkgContext_StreamSizes Sizes,
			int iLen);
	DWORD ServerTLSSend(const char *sBuff, int iLen);
	int ServerSecureSend(const void *const lpBuf, const int Len);
	int ServerEncryptSend(const void *const lpBuf, const int Len);
	bool DecryptSecureData(char *buf, int *len, char **ppExtraBuf, int *nExtraLen);
public:
	virtual int Send(const char *pcBuf, int iLen);

protected:
	CV7TLSClient *m_pTLSCli;
	CV7TLSServCleComm *m_pTLSSer;
	ESocketRoleType m_eSocketRole;
};

#endif // !defined(_V7SECUREQAbstractSocket_H_INCLUDED_)

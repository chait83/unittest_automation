/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  Secure Comm
/// @n Filename:  V7TlsClient.cpp
/// @n Description: TLS Client
///
// **************************************************************************
// Revision History
// **************************************************************************
// Project		Date			Team/Person			Comments
//	TVR211		08-Aug-2019		TechM				Initial Draft
//
// **************************************************************************

#include "V7TLSClient.h"
#include "V7TLSUtilities.h"
#include "V7tstring.h"

// Global value to optimize access since it is set only once
PSecurityFunctionTable CV7TLSClient::m_pSSPI = NULL;

PSecurityFunctionTable CV7TLSClient::SSPI(void) {
	return m_pSSPI;
}

CHAR CV7TLSClient::readBuffer[(V7_TLS_MAX_RECORD_SIZE + V7_TLS_MAX_MSG_HDR_SIZE) * 2]; // Enough for two whole messages so we don't need to move data around in buffers
CHAR CV7TLSClient::plainText[V7_TLS_MAX_RECORD_SIZE * 2];

// Establish SSPI pointer
HRESULT CV7TLSClient::InitializeSSPI(void) {
	m_pSSPI = InitSecurityInterface();

	if (m_pSSPI == NULL) {
		int err = ::GetLastError();
		if (err == 0)
			return E_FAIL;
		else
			return HRESULT_FROM_WIN32(err);
	}
	return S_OK;
}

CV7TLSClient::CV7TLSClient(void)
#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
	: m_pDebugFileLogger(NULL)
#endif
		{
	m_hMyCertStore = NULL;
	m_encrypting = false;
	m_LastError = 0;

	plainTextBytes = 0;
	plainTextPtr = NULL;
	readBufferBytes = 0;
	readPtr = readBuffer;

	m_pbReceiveBuf = NULL;
	m_dwReceiveBuf = 0;
	m_pbIoBuffer = NULL;
	m_cbIoBuffer = 0;
}

CV7TLSClient::CV7TLSClient(QAbstractSocket skt)
#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
	: m_pDebugFileLogger(NULL)
#endif
		{
	m_pbReceiveBuf = NULL;
	m_dwReceiveBuf = 0;
	m_pbIoBuffer = NULL;
	m_cbIoBuffer = 0;

	m_hMyCertStore = NULL;
	m_encrypting = false;
	m_LastError = 0;

	plainTextBytes = 0;
	plainTextPtr = NULL;
	readBufferBytes = 0;
	readPtr = readBuffer;
	m_ActualSocket = skt;
}

CV7TLSClient::~CV7TLSClient(void) {
	DebugMsg(_T("CV7TLSClient::~CV7TLSClient Desctructor Called"));
	FreeLibrary(m_hSecurity);
	m_hSecurity = NULL;

	if (m_hMyCertStore)
		CertCloseStore(m_hMyCertStore, 0);

	if (CV7TLSClient::SSPI()) {
		CV7TLSClient::SSPI()->DeleteSecurityContext(&m_hContext);
		CV7TLSClient::SSPI()->FreeCredentialsHandle(&m_hClientCreds);
	}

	if (m_pbReceiveBuf)
		delete[] m_pbReceiveBuf;
	if (m_pbIoBuffer)
		delete[] m_pbIoBuffer;
}

/**************************************************************************************** 

 CreateCredentials : Creating the credentials
 
 @Input : None
 
 @return :
 SEC_E_OK on Success
 Error code on failure
 

 ******************************************************************************************/
SECURITY_STATUS CV7TLSClient::CreateCredentials() {
	TimeStamp tsExpiry;
	SECURITY_STATUS Status;
	DWORD cSupportedAlgs = 0;
	ALG_ID rgbSupportedAlgs[16];
	PCCERT_CONTEXT pCertContext = NULL;
	SCHANNEL_CRED SchannelCred;
	ALG_ID aiKeyExch = 0;

	DebugMsg(_T("CV7TLSClient::CreateCredentials()with static"));

	if (m_hMyCertStore == NULL) {
		// Windows maintains 4 stores -- MY, CA, ROOT, SPC.

		m_hMyCertStore = CertOpenSystemStore(0, _T("MY"));

		if (!m_hMyCertStore) {
			DebugMsg(_T("**** Error 0x%x returned by CertOpenSystemStore\n"), GetLastError());
			return SEC_E_NO_CREDENTIALS;
		}
	}
	ZeroMemory(&SchannelCred, sizeof(SchannelCred));

	SchannelCred.dwVersion = SCHANNEL_CRED_VERSION;
	if (pCertContext) {
		SchannelCred.cCreds = 1;
		SchannelCred.paCred = &pCertContext;
	}

	// SchannelCred.grbitEnabledProtocols = SP_PROT_TLS1_CLIENT;

	SchannelCred.grbitEnabledProtocols = SP_PROT_TLS1_2_CLIENT;

	if (aiKeyExch)
		rgbSupportedAlgs[cSupportedAlgs++] = aiKeyExch;

	if (cSupportedAlgs) {
		SchannelCred.cSupportedAlgs = cSupportedAlgs;
		SchannelCred.palgSupportedAlgs = rgbSupportedAlgs;
	}

	SchannelCred.dwFlags |= SCH_CRED_NO_DEFAULT_CREDS;

	SchannelCred.dwFlags |= SCH_CRED_MANUAL_CRED_VALIDATION;

	//acquires a handle to preexisting credentials of a security principal

	Status = CV7TLSClient::SSPI()->AcquireCredentialsHandle(NULL, UNISP_NAME, SECPKG_CRED_OUTBOUND, NULL, &SchannelCred,
			NULL, NULL, &m_hClientCreds, &tsExpiry);

	if (Status != SEC_E_OK)
		DebugMsg(_T("**** Error 0x%x returned by AcquireCredentialsHandle\n"), Status);

	if (pCertContext)
		CertFreeCertificateContext(pCertContext);

	return Status;
}
/**************************************************************************************** 

 ClientHandshakeLoop : Cleint HansShake perform loop
 
 @Input : BOOL fDoInitialRead, SecBuffer * pExtraData (memory descriptors for buffers)
 
 @return : 
 SEC_E_OK on Success
 Error code on failure
 

 ******************************************************************************************/
SECURITY_STATUS CV7TLSClient::ClientHandshakeLoop(QAbstractSocket Socket, BOOL fDoInitialRead, SecBuffer *pExtraData) {
	SecBufferDesc OutBuffer, InBuffer;
	SecBuffer InBuffers[2], OutBuffers[1];
	DWORD dwSSPIFlags, dwSSPIOutFlags, cbData, cbIoBuffer;
	TimeStamp tsExpiry;
	SECURITY_STATUS scRet;
	PUCHAR IoBuffer;
	BOOL fDoRead;

#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
	QString   strDbgMsg;
	strDbgMsg.asprintf(_T("ClientHandshakeLoop Begin Socket %d"), Socket); 
	LogDebugMessage(strDbgMsg);	
	#endif

	dwSSPIFlags = ISC_REQ_SEQUENCE_DETECT | ISC_REQ_REPLAY_DETECT | ISC_REQ_CONFIDENTIALITY | ISC_RET_EXTENDED_ERROR
			| ISC_REQ_ALLOCATE_MEMORY | ISC_REQ_STREAM;

	IoBuffer = (PUCHAR) LocalAlloc(LMEM_FIXED, IO_BUFFER_SIZE);
	if (IoBuffer == NULL) {
#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
		strDbgMsg.asprintf(_T("ClientHandshakeLoop**** Out of memory (1)")); 
		LogDebugMessage(strDbgMsg);	
		#endif	

		return SEC_E_INTERNAL_ERROR;
	}
	cbIoBuffer = 0;
	fDoRead = fDoInitialRead;

	scRet = SEC_I_CONTINUE_NEEDED;

	while (scRet == SEC_I_CONTINUE_NEEDED || scRet == SEC_E_INCOMPLETE_MESSAGE || scRet == SEC_I_INCOMPLETE_CREDENTIALS) {
		if (0 == cbIoBuffer || scRet == SEC_E_INCOMPLETE_MESSAGE) {
			if (fDoRead) {
				/* recieve the data from server while doing handshake perform */
				CTime startTime1 = CTime::GetCurrentTime();
				for (int recvcnt = 0; recvcnt < 25; recvcnt++) {
					cbData = recv(Socket, (char*) IoBuffer + cbIoBuffer, IO_BUFFER_SIZE - cbIoBuffer, 0);
					sleep(700);
					if ((cbData != QAbstractSocket_ERROR) && (cbData != 0)) {
						break;
					}
				}
				CTime endTime1 = CTime::GetCurrentTime();
				CTimeSpan Timeleft1 = endTime1 - startTime1;

#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
				strDbgMsg.asprintf(_T("Timespent ClientHandshakeLoop recv :%d "), Timeleft1.GetTotalSeconds());
				LogDebugMessage(strDbgMsg);	
				#endif

				if (cbData == QAbstractSocket_ERROR) {
#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
					strDbgMsg.asprintf(_T("**** Error %d reading data from server"), WSAGetLastError());
					LogDebugMessage(strDbgMsg);	
					#endif

					scRet = SEC_E_INTERNAL_ERROR;
					break;
				} else if (cbData == 0) {
#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
					strDbgMsg.asprintf(_T("**** Server cbData == 0 "));
					LogDebugMessage(strDbgMsg);	
					#endif

					scRet = SEC_E_INTERNAL_ERROR;
					break;
				}

#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
				strDbgMsg.asprintf(_T("CHL: %d bytes of handshake data received"), cbData);
				LogDebugMessage(strDbgMsg);	
				#endif

				cbIoBuffer += cbData;
			} else
				fDoRead = TRUE;
		}

		InBuffers[0].pvBuffer = IoBuffer;
		InBuffers[0].cbBuffer = cbIoBuffer;
		InBuffers[0].BufferType = SECBUFFER_TOKEN;

		InBuffers[1].pvBuffer = NULL;
		InBuffers[1].cbBuffer = 0;
		InBuffers[1].BufferType = SECBUFFER_EMPTY;

		InBuffer.cBuffers = 2;
		InBuffer.pBuffers = InBuffers;
		InBuffer.ulVersion = SECBUFFER_VERSION;

		OutBuffers[0].pvBuffer = NULL;
		OutBuffers[0].BufferType = SECBUFFER_TOKEN;
		OutBuffers[0].cbBuffer = 0;

		OutBuffer.cBuffers = 1;
		OutBuffer.pBuffers = OutBuffers;
		OutBuffer.ulVersion = SECBUFFER_VERSION;

		/* to build a security context between the client application and server */
		scRet = m_pSSPI->InitializeSecurityContext(&m_hClientCreds, &m_hContext, NULL, dwSSPIFlags, 0,
				SECURITY_NATIVE_DREP, &InBuffer, 0, NULL, &OutBuffer, &dwSSPIOutFlags, &tsExpiry);

		if (scRet == SEC_E_OK || scRet == SEC_I_CONTINUE_NEEDED
				|| FAILED(scRet) && (dwSSPIOutFlags & ISC_RET_EXTENDED_ERROR)) {
			if (OutBuffers[0].cbBuffer != 0 && OutBuffers[0].pvBuffer != NULL) {
				cbData = send(Socket, (const char*) OutBuffers[0].pvBuffer, OutBuffers[0].cbBuffer, 0);
				if (cbData == QAbstractSocket_ERROR || cbData == 0) {
#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
					strDbgMsg.asprintf(_T("**** Error %d sending data to server (2)"), WSAGetLastError() );
					LogDebugMessage(strDbgMsg);	
					#endif

					m_pSSPI->FreeContextBuffer(OutBuffers[0].pvBuffer);
					m_pSSPI->DeleteSecurityContext(&m_hContext);
					return SEC_E_INTERNAL_ERROR;
				}

#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
				strDbgMsg.asprintf(_T("CHL: %d bytes of handshake data sent"), cbData);
				LogDebugMessage(strDbgMsg);	
				#endif

				m_pSSPI->FreeContextBuffer(OutBuffers[0].pvBuffer);
				OutBuffers[0].pvBuffer = NULL;
			}
		}

		if (scRet == SEC_E_INCOMPLETE_MESSAGE) {
			//DebugMsg(_T("scRet == SEC_E_INCOMPLETE_MESSAGE"));
			continue;
		}

		if (scRet == SEC_E_OK) {

#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
			strDbgMsg.asprintf(_T("CHL: Handshake was successful"));
			LogDebugMessage(strDbgMsg);	
			#endif

			if (InBuffers[1].BufferType == SECBUFFER_EXTRA) {
				pExtraData->pvBuffer = LocalAlloc(LMEM_FIXED, InBuffers[1].cbBuffer);
				if (pExtraData->pvBuffer == NULL) {
#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
					strDbgMsg.asprintf(_T("CHL:**** Out of memory (2)")); 
					LogDebugMessage(strDbgMsg);	
					#endif

					return SEC_E_INTERNAL_ERROR;
				}

				MoveMemory(pExtraData->pvBuffer, IoBuffer + (cbIoBuffer - InBuffers[1].cbBuffer),
						InBuffers[1].cbBuffer);

				pExtraData->cbBuffer = InBuffers[1].cbBuffer;
				pExtraData->BufferType = SECBUFFER_TOKEN;

#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
				strDbgMsg.asprintf(_T("CHL:%d bytes of app data was bundled with handshake data"), pExtraData->cbBuffer );
				LogDebugMessage(strDbgMsg);	
				#endif

			} else {
				pExtraData->pvBuffer = NULL;
				pExtraData->cbBuffer = 0;
				pExtraData->BufferType = SECBUFFER_EMPTY;
			}
			break;
		}

		if (FAILED(scRet)) {
#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
			strDbgMsg.asprintf(_T("CHL:**** Error 0x%x returned by InitializeSecurityContext (2)"), scRet); 
			LogDebugMessage(strDbgMsg);	
			#endif

			break;
		}

		if (scRet == SEC_I_INCOMPLETE_CREDENTIALS) {
			/* get the client credentials in case incomplete credentials */
			GetNewClientCredentials(&m_hClientCreds, &m_hContext);
			fDoRead = FALSE;
			scRet = SEC_I_CONTINUE_NEEDED;
			continue;
		}

		if (InBuffers[1].BufferType == SECBUFFER_EXTRA) {
			MoveMemory(IoBuffer, IoBuffer + (cbIoBuffer - InBuffers[1].cbBuffer), InBuffers[1].cbBuffer);
			cbIoBuffer = InBuffers[1].cbBuffer;
		} else {
			cbIoBuffer = 0;
		}
	}
	if (FAILED(scRet)) {
		m_pSSPI->DeleteSecurityContext(&m_hContext);
	}

	LocalFree(IoBuffer);

#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
	strDbgMsg.asprintf(_T("CHL: End 0x%x"), scRet); 
	LogDebugMessage(strDbgMsg);	
	#endif

	return scRet;
}

/**************************************************************************************** 

 GetNewClientCredentials : Get the new client credentials
 
 @Input : CredHandle *phCreds, CtxtHandle *phContext (Secure Handles)
 
 @return : 
 none
 

 ******************************************************************************************/
void CV7TLSClient::GetNewClientCredentials(CredHandle *phCreds, CtxtHandle *phContext) {
	CredHandle hCreds;
	SecPkgContext_IssuerListInfoEx IssuerListInfo;
	PCCERT_CHAIN_CONTEXT pChainContext;
	CERT_CHAIN_FIND_BY_ISSUER_PARA indexOfByIssuerPara;
	PCCERT_CONTEXT pCertContext;
	TimeStamp tsExpiry;
	SECURITY_STATUS Status;
	SCHANNEL_CRED SchannelCred;

	/* Query the Credential security package for certain attributes of a security context */
	Status = m_pSSPI->QueryContextAttributes(phContext, SECPKG_ATTR_ISSUER_LIST_EX, (PVOID) & IssuerListInfo);
	if (Status != SEC_E_OK) {
		DebugMsg(_T("Error 0x%x querying issuer list info\n"), Status);
		return;
	}

	ZeroMemory(&indexOfByIssuerPara, sizeof(indexOfByIssuerPara));

	indexOfByIssuerPara.cbSize = sizeof(indexOfByIssuerPara);
	indexOfByIssuerPara.pszUsageIdentifier = szOID_PKIX_KP_CLIENT_AUTH;
	indexOfByIssuerPara.dwKeySpec = 0;
	indexOfByIssuerPara.cIssuer = IssuerListInfo.cIssuers;
	indexOfByIssuerPara.rgIssuer = IssuerListInfo.aIssuers;

	pChainContext = NULL;

	while (TRUE) {
		pChainContext = CertindexOfChainInStore(m_hMyCertStore, X509_ASN_ENCODING, 0, CERT_CHAIN_FIND_BY_ISSUER,
				&indexOfByIssuerPara, pChainContext);
		if (pChainContext == NULL) {
			break;
		}

		DebugMsg(_T("\ncertificate chain found\n"));

		pCertContext = pChainContext->rgpChain[0]->rgpElement[0]->pCertContext;

		SchannelCred.dwVersion = SCHANNEL_CRED_VERSION;
		SchannelCred.cCreds = 1;
		SchannelCred.paCred = &pCertContext;

		Status = CV7TLSClient::SSPI()->AcquireCredentialsHandle(NULL, UNISP_NAME, SECPKG_CRED_OUTBOUND, NULL,
				&SchannelCred, NULL, NULL, &hCreds, &tsExpiry);

		if (Status != SEC_E_OK) {
			DebugMsg(_T("**** Error 0x%x returned by AcquireCredentialsHandle\n"), Status);
			continue;
		}
		DebugMsg(_T("\nNew schannel credential created\n"));

		m_pSSPI->FreeCredentialsHandle(phCreds);

		*phCreds = hCreds;

	}
}
/**************************************************************************************** 

 ServerCredAut : Authenticate the server crendentials
 
 @Input :  CtxtHandle * phContext, wstring wstrServerName
 
 @return : true on Success
 false on failure
 

 ******************************************************************************************/
bool CV7TLSClient::ServerCredAut(CtxtHandle *phContext, std::tstring wstrServerName) {
	bool bRet = false;
	SECURITY_STATUS Status;
	PCCERT_CONTEXT pRemoteCertContext = NULL;

#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
	QString   strDbgMsg;
	strDbgMsg.asprintf(_T("CV7TLSClient::ServerCredAut begin"));
	LogDebugMessage(strDbgMsg);
	#endif

	Status = m_pSSPI->QueryContextAttributes(phContext, SECPKG_ATTR_REMOTE_CERT_CONTEXT, (PVOID) & pRemoteCertContext);
	if (Status != SEC_E_OK) {
#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
		strDbgMsg.asprintf(_T("CV7TLSClient::ServerCredAut Error querying remote certificate %d"), bRet);
		LogDebugMessage(strDbgMsg);
		#endif

		return bRet;
	}

#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
	strDbgMsg.asprintf(_T("CV7TLSClient::ServerCredAut ----- Server Credentials Authenticated "));
	LogDebugMessage(strDbgMsg);
	#endif

	/* Display the CertificateChain information */
	DisplayCertChain(pRemoteCertContext, FALSE);

#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
	strDbgMsg.asprintf(_T("CV7TLSClient::ServerCredAut ----- Certificate Chain Displayed"));
	LogDebugMessage(strDbgMsg);
	#endif

	/* Verify the server certificate */
	Status = VerifyServerCertificate(pRemoteCertContext, wstrServerName, 0);

#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
	strDbgMsg.asprintf(_T("CV7TLSClient::ServerCredAut----- Server Certificate Verified %x"), Status);
	LogDebugMessage(strDbgMsg);
	#endif

	if (SEC_E_OK == Status) {
		bRet = true;
	}

	/* free the cert context after usage */
	CertFreeCertificateContext(pRemoteCertContext);
	pRemoteCertContext = NULL;

#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
	strDbgMsg.asprintf(_T("CV7TLSClient::ServerCredAut end %d"), bRet);
	LogDebugMessage(strDbgMsg);
	#endif

	return bRet;

}

/**************************************************************************************** 

 DisplayCertChain : Display the CertificateChain information
 
 @Input :  PCCERT_CONTEXT pServerCert, BOOL fLocal 
 
 @return : 
 none
 

 ******************************************************************************************/
void CV7TLSClient::DisplayCertChain(PCCERT_CONTEXT pServerCert, BOOL fLocal) {
	TCHAR szName[1000];
	PCCERT_CONTEXT pCurrentCert, pIssuerCert;
	DWORD dwVerificationFlags;

#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
	QString   strDbgMsg;
	strDbgMsg.asprintf(_T("CV7TLSClient::DisplayCertChain"));
	LogDebugMessage(strDbgMsg);
	#endif

	if (!CertNameToStr(pServerCert->dwCertEncodingType, &pServerCert->pCertInfo->Subject,
			CERT_X500_NAME_STR | CERT_NAME_STR_NO_PLUS_FLAG, (QString  ) szName, sizeof(szName))) {
#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
		strDbgMsg.asprintf(_T("DCC-**** Error 0x%x building subject name"), GetLastError());
		LogDebugMessage(strDbgMsg);
		#endif
	}

	std::tstring tstrName(szName);

	if (fLocal) {
#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
		strDbgMsg.asprintf(_T("DCC-Client subject: %s"), tstrName[0]);
		LogDebugMessage(strDbgMsg);
		#endif
	} else {
#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
		strDbgMsg.asprintf(_T("DCC-Server subject: %s"), &tstrName[0]);
		LogDebugMessage(strDbgMsg);
		#endif
	}

	//converts an encoded name to a null-terminated character string.

	if (!CertNameToStr(pServerCert->dwCertEncodingType, &pServerCert->pCertInfo->Issuer,
			CERT_X500_NAME_STR | CERT_NAME_STR_NO_PLUS_FLAG, (QString  ) szName, sizeof(szName))) {
#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
		strDbgMsg.asprintf(_T("DCC-**** Error 0x%x building issuer name"), GetLastError());
		LogDebugMessage(strDbgMsg);
		#endif
	}

	tstring tstrName1(szName);

	if (fLocal) {
#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
		strDbgMsg.asprintf(_T("DCC-Client issuer: %s"), &tstrName1[0]);
		LogDebugMessage(strDbgMsg);
		#endif
	} else {
#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
		strDbgMsg.asprintf(_T("DCC-Server issuer: %s"), &tstrName1[0]);
		LogDebugMessage(strDbgMsg);
		#endif
	}

	pCurrentCert = pServerCert;
	while (pCurrentCert != NULL) {
		dwVerificationFlags = 0;
		//retrieves the certificate context from the certificate store of the specified subject certificate
		pIssuerCert = CertGetIssuerCertificateFromStore(pServerCert->hCertStore, pCurrentCert, NULL,
				&dwVerificationFlags);
		if (pIssuerCert == NULL) {
			if (pCurrentCert != pServerCert)
				CertFreeCertificateContext(pCurrentCert);
			break;
		}
		//converts an encoded name to a null-terminated character string.

		if (!CertNameToStr(pIssuerCert->dwCertEncodingType, &pIssuerCert->pCertInfo->Subject,
				CERT_X500_NAME_STR | CERT_NAME_STR_NO_PLUS_FLAG, (QString  ) szName, sizeof(szName))) {
#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
			strDbgMsg.asprintf(_T("DCC-**** Error 0x%x building subject name"), GetLastError());
			LogDebugMessage(strDbgMsg);
			#endif
		}

#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
		strDbgMsg.asprintf(_T("DCC-CA subject: %s\n"), szName);
		LogDebugMessage(strDbgMsg);
		#endif

		//converts an encoded name to a null-terminated character string.

		if (!CertNameToStr(pIssuerCert->dwCertEncodingType, &pIssuerCert->pCertInfo->Issuer,
				CERT_X500_NAME_STR | CERT_NAME_STR_NO_PLUS_FLAG, (QString  ) szName, sizeof(szName))) {
#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
			strDbgMsg.asprintf(_T("DCC-**** Error 0x%x building issuer name\n"), GetLastError());
			LogDebugMessage(strDbgMsg);
			#endif
		}

#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
		strDbgMsg.asprintf(_T("DCC-CA issuer: %s\n\n"), szName);
		LogDebugMessage(strDbgMsg);
		#endif

		if (pCurrentCert != pServerCert)
			CertFreeCertificateContext(pCurrentCert);
		pCurrentCert = pIssuerCert;
		pIssuerCert = NULL;
	}
}
/**************************************************************************************** 

 VerifyServerCertificate : Verify the server certificate
 
 @Input :  PCCERT_CONTEXT pServerCert,wstring wstrServerName, DWORD dwCertFlags
 
 @return : SEC_E_OK on Success
 Error code on failure
 

 ******************************************************************************************/
DWORD CV7TLSClient::VerifyServerCertificate(PCCERT_CONTEXT pServerCert, tstring tstrServerName, DWORD dwCertFlags) {
	HTTPSPolicyCallbackData polHttps;
	CERT_CHAIN_POLICY_PARA PolicyPara;
	CERT_CHAIN_POLICY_STATUS PolicyStatus;
	CERT_CHAIN_PARA ChainPara;
	PCCERT_CHAIN_CONTEXT pChainContext = NULL;
	DWORD cchServerName = 0, Status;
	LPSTR rgszUsages[] = { szOID_PKIX_KP_SERVER_AUTH, szOID_SERVER_GATED_CRYPTO, szOID_SGC_NETSCAPE };

	DWORD cUsages = sizeof(rgszUsages) / sizeof(LPSTR);
	PWSTR pwszServerName = NULL;

#ifndef _UNICODE
	std::string strServName(""); //for TMS Tools Support
	strServName = std::string(tstrServerName.begin(), tstrServerName.end());
	int size_needed = MultiByteToWideChar(CP_UTF8, 0, &strServName[0], (int) strServName.size(), NULL, 0);

	std::wstring strwServName(size_needed, 0);
#endif
#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
	QString   strDbgMsg;
	strDbgMsg.asprintf(_T("CV7TLSClient::VerifyServerCertificate"));
	LogDebugMessage(strDbgMsg);
#endif	

	if (pServerCert == NULL) {
		Status = SEC_E_WRONG_PRINCIPAL;
		goto cleanup;
	}

	if (tstrServerName.empty()) {
#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
		strDbgMsg.asprintf(_T("CV7TLSClient::VerifyServerCertificate : Servername is empty"));
		LogDebugMessage(strDbgMsg);
#endif
		Status = SEC_E_WRONG_PRINCIPAL;
		goto cleanup;
	}

	ZeroMemory(&ChainPara, sizeof(ChainPara));
	ChainPara.cbSize = sizeof(ChainPara);
	ChainPara.RequestedUsage.dwType = USAGE_MATCH_TYPE_OR;
	ChainPara.RequestedUsage.Usage.cUsageIdentifier = cUsages;
	ChainPara.RequestedUsage.Usage.rgpszUsageIdentifier = rgszUsages;

	// builds a certificate chain context starting from an end certificate
	if (!CertGetCertificateChain(NULL, pServerCert, NULL, pServerCert->hCertStore, &ChainPara, 0, NULL,
			&pChainContext)) {
		Status = GetLastError();
#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
		strDbgMsg.asprintf(_T("Error 0x%x returned by CertGetCertificateChain!"), Status);
		LogDebugMessage(strDbgMsg);
#endif	
		//DebugMsg(_T("Error 0x%x returned by CertGetCertificateChain!\n"), Status);
		goto cleanup;
	}

	ZeroMemory(&polHttps, sizeof(HTTPSPolicyCallbackData));
	polHttps.cbStruct = sizeof(HTTPSPolicyCallbackData);
	polHttps.dwAuthType = AUTHTYPE_SERVER;
	polHttps.fdwChecks = 0;
#ifdef _UNICODE
  polHttps.pwszServerName = &tstrServerName[0];
#else	
	MultiByteToWideChar(CP_UTF8, 0, &strServName[0], (int) strServName.size(), &strwServName[0], size_needed);
	polHttps.pwszServerName = &strwServName[0];
#endif

	memset(&PolicyPara, 0, sizeof(PolicyPara));
	PolicyPara.cbSize = sizeof(PolicyPara);
	PolicyPara.pvExtraPolicyPara = &polHttps;

	memset(&PolicyStatus, 0, sizeof(PolicyStatus));
	PolicyStatus.cbSize = sizeof(PolicyStatus);
#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
	strDbgMsg.asprintf(_T("CV7TLSClient::VerifyServerCertificate : Get Policy status"));
	LogDebugMessage(strDbgMsg);
#endif
#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
	strDbgMsg.asprintf(_T("Before Validation : cbSize: %lu dwError: 0x%x lChainIndex: %lu lElementIndex: %lu pvExtraPolicyStatus : %lu "), PolicyStatus.cbSize, PolicyStatus.dwError, PolicyStatus.lChainIndex, PolicyStatus.lElementIndex, PolicyStatus.pvExtraPolicyStatus);
	LogDebugMessage(strDbgMsg);
#endif

	//qDebug(_T("PolicyStatus.cbSize: %lu PolicyStatus.dwError: %lu , PolicyStatus.lChainIndex: %lu , PolicyStatus.lElementIndex: %lu , PolicyStatus.pvExtraPolicyStatus : %lu "), PolicyStatus.cbSize, PolicyStatus.dwError, PolicyStatus.lChainIndex, PolicyStatus.lElementIndex, PolicyStatus.pvExtraPolicyStatus);
	// checks a certificate chain to verify its validity policy criteria.
	if (!CertVerifyCertificateChainPolicy(CERT_CHAIN_POLICY_SSL, pChainContext, &PolicyPara, &PolicyStatus)) {
		Status = GetLastError();
#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
		strDbgMsg.asprintf(_T("CV7TLSClient::VerifyServerCertificate : Error 0x%x returned by CertVerifyCertificateChainPolicy!"), Status);
		LogDebugMessage(strDbgMsg);
#endif
		// DebugMsg(_T("Error 0x%x returned by CertVerifyCertificateChainPolicy!\n"), Status);
		goto cleanup;
	} else {
		Status = PolicyStatus.dwError;
		if (TRUST_E_CERT_SIGNATURE == Status) {
			Status = SEC_E_OK;
		} else if (CERT_E_EXPIRED == Status) {
#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
			strDbgMsg.asprintf(_T("CV7TLSClient::VerifyServerCertificate : Certificate expired "));
			LogDebugMessage(strDbgMsg);
#endif
		} else if (CERT_E_UNTRUSTEDROOT == Status) {
#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
			strDbgMsg.asprintf(_T("CV7TLSClient::VerifyServerCertificate : not a valid Certificate "));
			LogDebugMessage(strDbgMsg);
#endif
		} else if (CERT_E_CN_NO_MATCH == Status) {
#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
			strDbgMsg.asprintf(_T("CV7TLSClient::VerifyServerCertificate : The certificate's CN name does not match the passed value "));
			LogDebugMessage(strDbgMsg);
#endif

			//Ignore this error ToDo:Yet to find the root cause
			Status = SEC_E_OK;
		} else {
			Status = SEC_E_OK;
		}

	}
#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
	strDbgMsg.asprintf(_T("after Validation : cbSize: %lu dwError: 0x%x lChainIndex: %lu lElementIndex: %lu pvExtraPolicyStatus : %lu "), PolicyStatus.cbSize, PolicyStatus.dwError, PolicyStatus.lChainIndex, PolicyStatus.lElementIndex, PolicyStatus.pvExtraPolicyStatus);
	LogDebugMessage(strDbgMsg);
#endif

	cleanup: if (pChainContext)
		CertFreeCertificateChain(pChainContext);
	if (pwszServerName)
		LocalFree(pwszServerName);

	//qDebug(_T("PolicyStatus.cbSize: %lu \nPolicyStatus.dwError: %lu \n PolicyStatus.lChainIndex: %lu \n PolicyStatus.lElementIndex: %lu \n PolicyStatus.pvExtraPolicyStatus : %lu \n"), PolicyStatus.cbSize, PolicyStatus.dwError, PolicyStatus.lChainIndex, PolicyStatus.lElementIndex, PolicyStatus.pvExtraPolicyStatus);

	return Status;
}
/**************************************************************************************** 

 PerformClientHandshake : Cleint HansShake perform
 
 @Input : tstring wstrServerName (IP Address)
 
 @return : 
 SEC_E_OK on Success
 Error code on failure
 

 ******************************************************************************************/
SECURITY_STATUS CV7TLSClient::PerformClientHandshake(QAbstractSocket Socket, std::tstring tstrServerName) {
	SecBufferDesc OutBuffer;
	SecBuffer OutBuffers[1];
	DWORD dwSSPIFlags, dwSSPIOutFlags, cbData;
	TimeStamp tsExpiry;
	SECURITY_STATUS scRet;
	SecBuffer ExtraData;

	dwSSPIFlags = ISC_REQ_SEQUENCE_DETECT | ISC_REQ_REPLAY_DETECT | ISC_REQ_CONFIDENTIALITY | ISC_RET_EXTENDED_ERROR
			| ISC_REQ_ALLOCATE_MEMORY | ISC_REQ_STREAM;

	OutBuffers[0].pvBuffer = NULL;
	OutBuffers[0].BufferType = SECBUFFER_TOKEN;
	OutBuffers[0].cbBuffer = 0;

	OutBuffer.cBuffers = 1;
	OutBuffer.pBuffers = OutBuffers;
	OutBuffer.ulVersion = SECBUFFER_VERSION;

#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
	QString   strDbgMsg;
	strDbgMsg.asprintf(_T("PCH begin socket %d"), Socket);
	LogDebugMessage(strDbgMsg);	
	#endif	

	//Load the library
	DWORD dErrCode = LoadSecurityLibrary();
	if (dErrCode != SEC_E_OK) {
#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
		strDbgMsg.asprintf(_T("PCH Error initializing the security library\n"), dErrCode);
		LogDebugMessage(strDbgMsg);	
		#endif

		return dErrCode;
	}

#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
	strDbgMsg.asprintf(_T("PCH Security library Initialized"));
	LogDebugMessage(strDbgMsg);	
	#endif

	//Creating the credentials
	scRet = CreateCredentials();
	if (scRet != SEC_E_OK) {
#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
		strDbgMsg.asprintf(_T("PCH Error creating credentials %x"), scRet);
		LogDebugMessage(strDbgMsg);	
		#endif
		//delete m_pSSPI;
		m_pSSPI = NULL;
		return scRet;
	}

#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
	strDbgMsg.asprintf(_T("PCH Credentials Initialized"));
	LogDebugMessage(strDbgMsg);	
	#endif

	//Initiates the client side, outbound security context from a credential handle.

	scRet = m_pSSPI->InitializeSecurityContext(&m_hClientCreds, NULL, &tstrServerName[0], dwSSPIFlags, 0,
			SECURITY_NATIVE_DREP, NULL, 0, &m_hContext, &OutBuffer, &dwSSPIOutFlags, &tsExpiry);

	if (scRet != SEC_I_CONTINUE_NEEDED) {
#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
		strDbgMsg.asprintf(_T("PCH **** Error 0x%x returned by InitializeSecurityContext (1)"), scRet);
		LogDebugMessage(strDbgMsg);	
		#endif
		//delete m_pSSPI;
		m_pSSPI = NULL;
		return scRet;
	}

	if(OutBuffers[0].cbBuffer != 0 && OutBuffers[0].pvBuffer != NULL)
	{
		//send the data to server for handshake
		cbData = send(Socket, (const char*) OutBuffers[0].pvBuffer, OutBuffers[0].cbBuffer, 0);
	if( cbData == QAbstractSocket_ERROR || cbData == 0 )
{
#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
	strDbgMsg.asprintf(_T("PCH **** Error %d sending data to server (1)"), WSAGetLastError());
	LogDebugMessa
/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  Secure Comm
/// @n Filename:  V7TlsDecoder.h
/// @n Description: TLS Decoder
///
// **************************************************************************
// Revision History
// **************************************************************************
// Project		Date			Team/Person			Comments
//	TVR211		08-Aug-2019		TechM				Initial Draft
//	TVR211		13-Aug-2019		Nilesh P			std::tstring for Unicode to ASCII compatibility in std
//
// **************************************************************************

#ifndef _V7_TLS_DECODER_H
#define _V7_TLS_DECODER_H

#pragma once
#include "V7TLSUtilities.h"
#include "V7tstring.h"
#include "Defines.h"
class CV7TLSDecoder {
private:
	const byte *const OriginalBufPtr;
	const byte *DataPtr; // Points to data inside message
	// const byte* BufEnd = nullptr; // FOR REF
	const byte *BufEnd;
	const int MaxBufBytes;
	UINT8 contentType;
	UINT8 major;
	UINT8 minor;
	UINT16 length;
	UINT8 handshakeType;
	UINT16 handshakeLength;

	bool CanDecode();
	bool decoded;
public:
	CV7TLSDecoder(const byte *BufPtr, const int BufBytes);
	~CV7TLSDecoder();
	// Max length of handshake data buffer
	void TraceHandshake();
	// Is this packet a complete client initialize packet
	bool IsClientInitialize();
	// Get SNI provided hostname
	std::tstring GetSNI();
};

#endif // _V7_TLS_DECODER_H

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  Secure Comm
/// @n Filename:  V7CERTRAII.cpp
/// @n Description: The approach in "CertRAII...." also replaces handles with objects encapsulating the handles, but
///					these behave as if they were the underlying object 
///
// **************************************************************************
// Revision History
// **************************************************************************
// Project		Date			Team/Person				Comments
//	TVR211		08-Aug-2019		TechM					Initial Draft
//
// **************************************************************************

#include <memory>
#include <vector>
#include "V7CertRAII.h"
#include "V7TLSUtilities.h"

CSP::CSP() {
	hCryptProvOrNCryptKey = NULL;
}

CSP::~CSP() {
	if (hCryptProvOrNCryptKey) {
		DebugMsg("CryptReleaseContext... ");
		CryptReleaseContext(hCryptProvOrNCryptKey, 0);
		DebugMsg("Success");
	}
}

bool CSP::AcquirePrivateKey(PCCERT_CONTEXT pCertContext) {
	BOOL fCallerFreeProvOrNCryptKey = FALSE;
	DWORD dwKeySpec;
	return FALSE
			!= CryptAcquireCertificatePrivateKey(pCertContext, 0, NULL, &hCryptProvOrNCryptKey, &dwKeySpec,
					&fCallerFreeProvOrNCryptKey);
}

CryptProvider::CryptProvider() {
	// We always want a new keycontainer, so give it a unique name
	UUID uuid;
	RPC_STATUS ret_val = ::UuidCreate(&uuid);

	// init 
	KeyContainerName = NULL;
	hCryptProv = NULL;

	if (ret_val == RPC_S_OK) {
		// convert UUID to LPWSTR
#ifdef _UNICODE
		::UuidToString(&uuid, (RPC_WSTR*)&KeyContainerName);
#else
		::UuidToString(&uuid, (RPC_CSTR*) &KeyContainerName);
#endif

		if (!KeyContainerName)
			DebugMsg("CryptProvider constructor could not initialize KeyContainerName");
	} else
		DebugMsg("CryptProvider constructor UuidCreate failed");
	// end of naming keycontainer
}

CryptProvider::~CryptProvider() {
	if (hCryptProv) {
		DebugMsg("CryptReleaseContext... ");
		CryptReleaseContext(hCryptProv, 0);
		DebugMsg("Success");
	}
	if (KeyContainerName) {
		// free up the allocated string
#ifdef _UNICODE
		::RpcStringFree((RPC_WSTR*)&KeyContainerName);
#else
		::RpcStringFree((RPC_CSTR*) &KeyContainerName);
#endif
		KeyContainerName = NULL;
	}
}

BOOL CryptProvider::AcquireContext(DWORD dwFlags) {
	return CryptAcquireContext(&hCryptProv, KeyContainerName, NULL, PROV_RSA_FULL, dwFlags);
}

CryptKey::CryptKey() {
	hKey = NULL;
}

CryptKey::~CryptKey() {
	if (hKey) {
		DebugMsg("Destructor calling CryptDestroyKey... ");
		CryptDestroyKey(hKey);
		DebugMsg("Success");
	}
}

BOOL CryptKey::CryptGenKey(CryptProvider &prov) {
	return ::CryptGenKey(prov.hCryptProv, AT_SIGNATURE, 0x08000000 /*RSA-2048-BIT_KEY*/, &hKey);
}

CertStore::CertStore() {
	hStore = NULL;
}

CertStore::~CertStore() {
	if (hStore) {
		DebugMsg("CertStore destructor calling CertCloseStore(0x%.8x)", hStore);
		CertCloseStore(hStore, 0);
	}
}

bool CertStore::CertOpenStore(DWORD dwFlags) {
#ifdef HOST_UNIT_APP
  hStore = ::CertOpenStore(CERT_STORE_PROV_SYSTEM, 0, 0, dwFlags, L"My";
#else
	// For Taget always use Machine store
	hStore = ::CertOpenStore(CERT_STORE_PROV_SYSTEM, 0, 0, CERT_SYSTEM_STORE_CURRENT_USER, L"My";
#endif
			return (hStore != NULL);
		}

		bool CertStore::AddCertificateContext(PCCERT_CONTEXT pCertContext) {
			return (FALSE
					!= ::CertAddCertificateContextToStore(hStore, pCertContext, CERT_STORE_ADD_REPLACE_EXISTING, 0));
		}

		CertStore::operator bool() const {
			return hStore != NULL;
		}

		HCERTSTORE CertStore::get() const {
			return hStore;
		}


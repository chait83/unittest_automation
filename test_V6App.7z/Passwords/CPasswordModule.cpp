/******************************************************************************************
 /// @file CPasswordModule.cpp
 /// ***************************************************************************************
 /// © Honeywell Trendview
 /// ***************************************************************************************
 /// @n Module	:	Password Management Module
 /// @n Filename	:	CPasswordModule.cpp
 /// @n Desc		:	Implementation of exposed API which inturn calls the respective 
 ///					methods of CUservalidation class..
 ///
 // ***************************************************************************************
 // Revision History
 // ***************************************************************************************
 // $Log[1]:
 // 14	Stability Project 1.9.1.3	7/2/2011 4:56:23 PM	Hemant(HAIL) 
 //		Stability Project: Recorder source has been upgraded from IL
 //		version of firmware to JF version of firmware.
 // $Log" for functions
 // $
 //
 // ***************************************************************************************
 /******************************************************************************************
 COPYRIGHT (c) 2004
 HONEYWELL INC.,
 ALL RIGHTS RESERVED

 This software is a copyrighted work and/or information protected
 as a trade secret. Legal rights of Honeywell Inc. in this
 software is distinct from ownership of any medium in which the
 software is embodied. Copyright or trade secret notices included
 must be reproduced in any copies authorized by Honeywell Inc.
 The information in this software is subject to change without
 notice and should not be considered as a commitment by Honeywell
 Inc.
 ******************************************************************************************/

/****************** Header Declarations ****************/

#include "CPasswordManager.h"
#include "CPolicyDataManager.h"
#include "CUserValidation.h"
#include "CPasswordModule.h"
#include "PMMdefines.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif

/****************** Global declarations *****************/

QLibrary glbCMMHandle;			///< Global CMM handle
CUserValidation g_pmmData;				///< Global CuserValidation object.

/****************** Global Tracer functions ******************/

//extern fnTraceStart TraceStart;				///< Global function pointer to start Tracer Module
//extern fnTrace Trace ;						///< Global function pointer to log traces
//extern fnTraceStop TraceStop;				///< Global function pointer to sto
/***************** End of Global Declaration ************/

//*********************************************************************************************************************
// PMMSTATUS GetErrorType(PMMERROR varPmmStatus)
///
/// Obtains the status internal to module and converts to the client understandable format.
///
/// @param[in]	PMMERROR -	Error to be converted in the client understandable format.
///	
/// @return		PMMSTATUS -	Returns CSTATUS_OK if Success or Error code in client 
///							understandable format.	
/// 
/// @todo - 
///
//*********************************************************************************************************************
// Revision History
//*********************************************************************************************************************
// 1 V6 Firmware1	6/23/2004		Shyam Prasad				
// 
//
// ******************************************************************************************************************
PMMSTATUS GetErrorType(PMMERROR varPmmStatus) {
	PMMSTATUS PMMStatus;
	switch (varPmmStatus) {
	case PMM_NO_USERS_LOGIN:
	case PMM_VALID_DAY:
	case PMM_SUCCESS:
	case PMM_VALID_SLOT_FOUND: {
		PMMStatus = CSTATUS_OK;
		break;
	}

	case PMM_INVALID_PARAMETER: {
		PMMStatus = CSTATUS_INVALID_PARAMETER;
		break;
	}

	case PMM_USER_NOT_LOGIN:
	case PMM_INSUFFICIENT_MEMORY:
	case PMM_INVALID_CMM_DLL:
	case PMM_FAILED: {
		PMMStatus = CSTATUS_FAIL;
		break;
	}

	case PMM_INVALID_CONFIGURATION_ID: {
		PMMStatus = CSTATUS_INVALID_CONFIGURATION_ID;
		break;
	}

	case PMM_VALID_SLOT_NOT_FOUND: {
		PMMStatus = CSTATUS_VALID_SLOT_NOT_FOUND;
		break;
	}

	case PMM_USERNAME_PASSWORD_SAME: {
		PMMStatus = CSTATUS_USERNAME_AND_PASSWORD_SAME;
		break;
	}

	case PMM_INVALID_POLICY_DATA: {
		PMMStatus = CSTATUS_INVALID_POLICY;
		break;
	}

	case PMM_INVALID_USER_ID: {
		PMMStatus = CSTATUS_INVALID_USER_ID;
		break;
	}

	case PMM_INVALID_PASSWORD: {
		PMMStatus = CSTATUS_INVALID_PASSWORD;
		break;
	}

	case PMM_INVALID_USERNAME: {
		PMMStatus = CSTATUS_INVALID_USERNAME;
		break;
	}
	case PMM_INVALID_LOGIN_DAY: {
		PMMStatus = CSTATUS_INVALID_DAY_MASK;
		break;
	}

	case PMM_INVALID_LOGIN_TIME: {
		PMMStatus = CSTATUS_INVALID_LOGIN_TIME;
		break;
	}

	case PMM_INVALID_GROUP_LEVEL: {
		PMMStatus = CSTATUS_INVALID_USER_LEVEL;
		break;
	}

	case PMM_PASSWORD_EXPIRED: {
		PMMStatus = CSTATUS_PASSWORD_EXPIRED;
		break;
	}

	case PMM_INVALID_USERGROUP: {
		PMMStatus = CSTATUS_INVALID_USERGROUP;
		break;
	}

	case PMM_USER_ACCESS_LOCKED: {
		PMMStatus = CSTATUS_PASSWORD_LOCKED;
		break;
	}

	case PMM_USER_LEVEL_DISALLOWED: {
		PMMStatus = CSTATUS_USER_LEVEL_DISALLOWED;
		break;
	}

	case PMM_DUPLICATE_USER: {
		PMMStatus = CSTATUS_DUPLICATE_USER;
		break;
	}

	case PMM_DUPLICATE_PASSWORD_IN_HISTORY: {
		PMMStatus = CSTATUS_PASSWORD_IN_HISTORY;
		break;
	}

	case PMM_NO_USERS: {
		PMMStatus = CSTATUS_NO_MORE_USERS;
		break;
	}

	case PMM_FIRST_TIME_USER_AUTHENTICATED: {
		PMMStatus = CSTATUS_FIRST_TIME_USER_AUTHENTICATED;
		break;
	}

	case PMM_FIRST_TIME_USER_NOT_AUTHENTICATED: {
		PMMStatus = CSTATUS_FIRST_TIME_USER_NOT_ALLOWED;
		break;
	}

	case PMM_CHANGE_PASSWORD_FOR_LOGIN: {
		PMMStatus = CSTATUS_CHANGE_PASSWORD_FOR_LOGIN;
		break;
	}

	case PMM_BACKDOOR_USER_AUTHENTICATED: {
		PMMStatus = CSTATUS_BACKDOOR_USER_AUTHENTICATED;
		break;
	}

	case PMM_INVALID_OLD_PASSWORD: {
		PMMStatus = CSTATUS_INVALID_OLD_PASSWORD;
		break;
	}

	case PMM_INVALID_SRAM_HANDLE: {
		PMMStatus = CSTATUS_INVALID_SRAM_HANDLE;
		break;
	}

	case PMM_NOT_CUSTOM_PERMISSION_USER: {
		PMMStatus = CSTATUS_NOT_CUSTOM_PERMISSION_USER;
		break;
	}

	case PMM_CMM_NOT_INITIALISED: {
		PMMStatus = CSTATUS_CMM_NOT_INITIALISED;
		break;
	}

	case PMM_CMM_FAILED: {
		PMMStatus = CSTATUS_CMM_FAILED;
		break;
	}

	case PMM_WARNING_ACTIVATED: {
		PMMStatus = CSTATUS_EXPIRY_DAYS_WRN;
		break;
	}

	case PMM_CANNOT_CHANGE_ADMIN_PERMISSION: {
		PMMStatus = CSTATUS_CANNOT_CHANGE_ADMIN_PERMISSION;
		break;
	}

	default: {
		PMMStatus = CSTATUS_UNDEFINED;
	}
	}
	return PMMStatus;
}

//**********************************************************************
///
/// Dynamically loads the tracer module and initializes the
///	global function pointers.
///
//**********************************************************************

/*
 void LoadTracerModule()
 {
 TV_BOOL bLoadTracer = FALSE;
 #ifdef qDebugR_ENABLE
 #ifdef INFO_TRACE_ENABLE
 bLoadTracer = TRUE;
 #endif;
 #ifdef ERROR_TRACE_ENABLE
 bLoadTracer = TRUE;
 #endif;
 #ifdef WARNING_TRACE_ENABLE
 bLoadTracer = TRUE;
 #endif;
 #endif;

 if(TRUE==bLoadTracer)
 {
 glbDllHandle = LoadLibrary(_T("TraceFile.dll"));

 if(NULL == glbDllHandle)
 {
 return;
 }

 TraceStart = (fnTraceStart) GetProcAddress (glbDllHandle,GETPROCADDRESSSTRING("TraceStart"));
 Trace = (fnTrace) GetProcAddress (glbDllHandle,GETPROCADDRESSSTRING("Trace"));
 TraceStop = (fnTraceStop) GetProcAddress (glbDllHandle,GETPROCADDRESSSTRING("TraceStop"));

 if(NULL != TraceStart)
 {
 TraceStart(_T("PMM_Log"));
 LOG_INFO(PMM_qDebugR_MODE,("PMM : PMMUtility::LoadTracerModule - Loaded Tracer"));
 }
 }
 else
 {
 glbDllHandle = NULL;
 TraceStart = NULL;
 Trace = NULL;
 TraceStop= NULL;
 }

 return;	
 }
 /**********************************************************************
 ///
 /// Unloads the dynamically loaded tracer module.
 ///
 **********************************************************************/
/*
 void UnLoadTracerModule()
 {
 if(NULL != glbDllHandle)
 {
 LOG_INFO(PMM_qDebugR_MODE,("PMM : PMMUtility::UnLoadTracerModule - Unloaded Tracer"));
 //No need to close the mutex in Qt
 FreeLibrary(glbDllHandle);
 glbDllHandle = NULL;
 glbDllHandle = NULL;

 }	
 TraceStart = NULL;
 Trace = NULL;
 TraceStop = NULL;

 return;	
 }

 */

//*********************************************************************************************************************
// PMMSTATUS GetPolicyErrorType(POLICY_STATUS varPmmStatus)
///
/// Obtains the status internal to module and converts to the client understandable format.
///
/// @param[in]	PMMERROR -	Error to be converted in the client understandable format.
///	
/// @return		PMMSTATUS -	Returns CSTATUS_OK if Success or Error code in client 
///							understandable format.	
/// 
/// @todo - 
///
//*********************************************************************************************************************
// Revision History
//*********************************************************************************************************************
// 1 V6 Firmware1						6/23/2004			Shyam Prasad				
// 
//
// ******************************************************************************************************************
PMMSTATUS GetPolicyErrorType(POLICY_STATUS varPmmStatus) {
	PMMSTATUS PMMStatus;
	switch (varPmmStatus) {
	case PMM_SUCCESS: {
		PMMStatus = CSTATUS_OK;
		break;
	}

	case PMM_FAILED:
	case PMM_INVALID_PASSWORD: {
		PMMStatus = CSTATUS_FAIL;
		break;
	}

	case P_INVALID_PARAMETER: {
		PMMStatus = CSTATUS_INVALID_PARAMETER;
		break;
	}

	case P_INVALID_POLICY: {
		PMMStatus = CSTATUS_INVALID_POLICY;
		break;
	}

	default: {
		PMMStatus = CSTATUS_FAIL;
		break;
	}
	}
	return PMMStatus;
}

//*********************************************************************************************************************
// PMM_API PMMSTATUS InitialisePMM ( TV_BOOL lForceCFR,DWORD lConfigID, ULONG lSerialNumber,TV_BOOL lNewConfiguration) 
///
/// Invokes the InitialisePMM method of CUserValidation and returns the Error 
///	code in client understandable format.
///
/// @param[in]	ForceCFR		-	To set the recorder in CFR or NonCFR mode. TRUE - CFR mode.
///
///	@param[in]	lConfigurationId -	Configuration ID to communicate with CMM.
///
///	@param[in]	lSerialNumber	-	Serial Number of the Unit.
///
///	@param[in]	NewConfiguration -	Indicates whether the configuration loaded is a 
///									new configuration or related to the same recorder.
///
/// @return		PMMSTATUS -	Returns CSTATUS_OK if Success or Error code in client 
///							understandable format.	
/// 
/// @todo - 
///
//*********************************************************************************************************************
// Revision History
//*********************************************************************************************************************
// 1 V6 Firmware1	6/23/2004		Shyam Prasad				
// 
//
// ******************************************************************************************************************
//********************************************************************************************************************
//Name				Date								Modifications
//----				----								-------------
//Shyam				6/23/2004								Created
//********************************************************************************************************************

PMM_API PMMSTATUS InitPassword(TV_BOOL lForceCFR,				// Indicates the Mode of recorder
		DWORD lConfigurationId,			// Configuration ID
		ULONG lSerialNumber,				// Serial Number of Unit
		TV_BOOL lNewConfiguration,		// Same recorder configuration or not
		void *NvPtr)						// pointer to Password SRAM region.
		{
	//		If this DLL is dynamically linked against the MFC
	//		DLLs, any functions exported from this DLL which
	//		call into MFC must have the AFX_MANAGE_STATE macro
	//		added at the very beginning of the function.

	///TODO check if required.
	// AFX_MANAGE_STATE (AfxGetStaticModuleState());

	PMMSTATUS varCstatus = CSTATUS_UNDEFINED;	// Status in client understandable format.
	PMMERROR varPmmStatus = PMM_UNDEFINED;	// status to be converted to client understandable format.

	//LoadTracerModule();													// Loads the tracer Module

	//glbCMMHandle = LoadLibrary (_T("CMM.dll"));							// Loads the CMM DLL.

	//if(NULL != glbCMMHandle)
	//{
	if (NULL != lConfigurationId) {

		LOG_INFO(PMM_qDebugR_MODE, ("PMM API: InitPassword : Initialise PMM"));

		varPmmStatus = g_pmmData.InitialisePMM(lForceCFR,			// Mode		
				lConfigurationId,			// Configuration ID
				lSerialNumber,			// Serial Number of recorder
				lNewConfiguration,			// Same Recorder config or not.		
				NvPtr);

		varCstatus = GetErrorType(varPmmStatus);			// Get the error in client understandable format.	
	} else {
		varCstatus = CSTATUS_INVALID_CONFIGURATION_ID;
	}
	//}
	//else
	//{
	//	varCstatus = CSTATUS_FAIL;
	//}

	return varCstatus;
}

//*****************************************************************************************************
// PMMSTATUS initialiseToDefault(TV_BOOL PolicyType)
///
/// Invokes the initialiseToDefaultPolicy of CUserValidation class and Returns the 
///	proper error codes.				
///
/// @param[in]	PolicyType	- Indicates the Policy block to default to CFR or NON-CFR mode with 
///							the Hardcoded policy in PMM.
///
/// @return					- Wraps the Return code in client understandable format.
///							Returns CSTATUS_OK if SUCCESS else returns proper error code.		
/// 
/// @todo - 
///
/// @note - COMMIT of CMM has to be called to update the changes to the 
///			current section of memory by the client requesting the service of this API.					
///
//****************************************************************************************************
// Revision History
// **************************************************************************************************
// 1 V6 Firmware1	6/23/2004		Shyam Prasad				
// 
//
// **************************************************************************************************
//****************************************************************************************************

PMM_API PMMSTATUS initialiseToDefault(TV_BOOL PolicyType) {
	//		If this DLL is dynamically linked against the MFC
	//		DLLs, any functions exported from this DLL which
	//		call into MFC must have the AFX_MANAGE_STATE macro
	//		added at the very beginning of the function.

	// AFX_MANAGE_STATE (AfxGetStaticModuleState());

	PMMSTATUS varCstatus = CSTATUS_UNDEFINED;	// Status in client understandable format.
	POLICY_STATUS varPmmStatus;	// status to be converted to client understandable format.

	LOG_INFO(PMM_qDebugR_MODE, ("PMM API: initialiseToDefault"));

	if (TRUE == g_pmmData.IsPMMInitialised())	// Check PMM is initialised or not
			{
		if (TRUE == g_pmmData.IsDALInit())	// Is NVRAM handle obtained or not
				{
			varPmmStatus = g_pmmData.initialiseToDefaultPolicy(PolicyType);
			varCstatus = GetPolicyErrorType(varPmmStatus);	// Get the Error Type.	
		} else {
			varCstatus = CSTATUS_INVALID_SRAM_HANDLE;
		}
	} else {
		varCstatus = CSTATUS_PMM_NOT_INITIALISED;
	}

	return varCstatus;
}

//*****************************************************************************************************
// PMMSTATUS ResetUserData(DWORD lConfigurationId)
///
/// Invokes the ResetAllUserData of CUserValidation class and Returns the proper error codes.				
/// When a ResetUserData is called, All the users in the system will be reset and First time 
///	user will be allowed to login.
///
/// @param[in]	lConfigurationId - PMM Configuration to be reset.
///
/// @return	- Wraps the Return code in client understandable format.
///			Returns CSTATUS_OK if SUCCESS else returns proper error code.		
/// 
/// @todo - 
///
/// @note - COMMIT of CMM has to be called to update the changes to the 
///			current section of memory by the client requesting the service of this API.				
///
//****************************************************************************************************
// Revision History
// **************************************************************************************************
// 
// 1 V6 Firmware1	6/23/2004		Shyam Prasad				
// 
//
// **************************************************************************************************
//****************************************************************************************************

PMM_API PMMSTATUS ResetUserData(DWORD lConfigurationId) {
	//		If this DLL is dynamically linked against the MFC
	//		DLLs, any functions exported from this DLL which
	//		call into MFC must have the AFX_MANAGE_STATE macro
	//		added at the very beginning of the function.

	AFX_MANAGE_STATE (AfxGetStaticModuleState());

PMMSTATUS	varCstatus = CSTATUS_UNDEFINED;	// Status in client understandable format.
	PMMERROR varPmmStatus = PMM_UNDEFINED;// status to be converted to client understandable format.

	LOG_INFO(PMM_qDebugR_MODE,("PMM API: ResetUserData "));
	// Check if PMM is initialised.
	if(TRUE == g_pmmData.IsPMMInitialised())
	{								// Check if proper SRAM handle is obtained.
		if(TRUE == g_pmmData.IsDALInit())
		{
			if(NULL != lConfigurationId)
			{
				varPmmStatus = g_pmmData.ResetAllUserData(lConfigurationId);
				varCstatus = GetErrorType(varPmmStatus);
				if(varCstatus == CSTATUS_OK)
				{
					//	After Reset UserData First time User should be allowed 
					//	for configuring the system.	
					varPmmStatus = g_pmmData.FirstTimeUser(TRUE);
					varCstatus = GetErrorType(varPmmStatus);
				}
			}
			else
			{
				varCstatus = CSTATUS_INVALID_CONFIGURATION_ID;
			}
		}
		else
		{
			varCstatus = CSTATUS_INVALID_SRAM_HANDLE;
		}
	}
	else
	{
		varCstatus = CSTATUS_PMM_NOT_INITIALISED;
	}

	return varCstatus;
}

//*****************************************************************************************************
// PMMSTATUS AddUser(USERDATA *UserInfo, SHORT *ID)
///
///	Invokes the AddUserData	of CUserValidation class and Returns the proper error codes.
///
/// @param[in]	*UserInfo	- User information to be added to the User data structure if a
///							valid slot is found and the username and password are 
///							verifed against the policy.
///
/// @param[out] *ID			- ID of the user. Next time any query about this user should be 
///							done by giving the ID returned.
///
/// @return					- Wraps the Return code in client understandable format.
///							Returns CSTATUS_OK if SUCCESS else returns proper error code.		
/// 
/// @todo - 
///
/// @note - COMMIT of CMM has to be called to update the changes to the 
///			current section of memory by the client requesting the service of this API.						
///
//****************************************************************************************************
// Revision History
// **************************************************************************************************
// 
// 1 V6 Firmware1	6/23/2004		Shyam Prasad				
// 
//
// **************************************************************************************************
//****************************************************************************************************

PMM_API PMMSTATUS AddUser(T_USERDATA *UserInfo, SHORT *ID) {
	WCHAR szDbgMsg[512];
	//		If this DLL is dynamically linked against the MFC
	//		DLLs, any functions exported from this DLL which
	//		call into MFC must have the AFX_MANAGE_STATE macro
	//		added at the very beginning of the function.

	AFX_MANAGE_STATE (AfxGetStaticModuleState());

PMMSTATUS 	varCstatus = CSTATUS_UNDEFINED;	// Status in client understandable format.
	PMMERROR varPmmStatus = PMM_UNDEFINED;	// status to be converted to client understandable format.

	LOG_INFO(PMM_qDebugR_MODE, ("PMM API: AddUser "));
#ifdef PWDLOGS_ENABLE
	swprintf( szDbgMsg, L"PMM API: AddUser GTC %d\n", GetTickCount());
	OutputDebugString(szDbgMsg);
#endif

	// Check if PMM is initialised.
	if (TRUE == g_pmmData.IsPMMInitialised()) {	// Check if proper SRAM handle is obtained.
		if (TRUE == g_pmmData.IsDALInit()) {
			varPmmStatus = g_pmmData.AddUserData(UserInfo, ID);
			varCstatus = GetErrorType(varPmmStatus);
#ifdef PWDLOGS_ENABLE
			swprintf( szDbgMsg, L"PMM API: AddUser- UserInfo = %s ID = %d GTC %d\n",UserInfo->UsrInfo.Name,*ID,GetTickCount());
			OutputDebugString(szDbgMsg);
#endif

		} else {
			varCstatus = CSTATUS_INVALID_SRAM_HANDLE;
		}

	} else {
		varCstatus = CSTATUS_PMM_NOT_INITIALISED;
	}

	return varCstatus;
}

//***************************************************************************************************
// PMMSTATUS RemoveUser ( SHORT ID) 
///
/// Checks whether PMM is initialised, Handle to SRAM is obtained.
///	Invokes the RemoveUserData of CUserValidation class.
///
/// @param[in]		ID			-	User ID of the user.
///
/// @return			PMMSTATUS	-	Returns CSTATUS_OK if SUCCESS else returns proper error code.
/// 
/// @todo - 
///
/// @note - COMMIT of CMM has to be called to update the changes to the 
///			current section of memory by the client requesting the service of this API.	
///
//**************************************************************************************************
// Revision History
// ************************************************************************************************
// 
// 1 V6 Firmware1	6/23/2004		Shyam Prasad				
// 
//
//**************************************************************************************************
//**************************************************************************************************

PMM_API PMMSTATUS RemoveUser(SHORT ID) {
	//		If this DLL is dynamically linked against the MFC
	//		DLLs, any functions exported from this DLL which
	//		call into MFC must have the AFX_MANAGE_STATE macro
	//		added at the very beginning of the function.

	AFX_MANAGE_STATE (AfxGetStaticModuleState());

PMMSTATUS	varCstatus = CSTATUS_UNDEFINED;	// Status in client understandable format.
	PMMERROR varPmmStatus = PMM_UNDEFINED;// status to be converted to client understandable format.

	LOG_INFO(PMM_qDebugR_MODE,("PMM : RemoveUser "));
	// Check if PMM is initialised.
	if(TRUE == g_pmmData.IsPMMInitialised())
	{								// Check if proper SRAM handle is obtained.
		if(TRUE == g_pmmData.IsDALInit())
		{
			if((ID > ZERO) && (ID <= MAX_USERS))
			{
				varPmmStatus = g_pmmData.RemoveUserData(ID);
				varCstatus = GetErrorType(varPmmStatus);
			}
			else
			{
				varCstatus = CSTATUS_INVALID_USER_ID;
			}
		}
		else
		{
			varCstatus = CSTATUS_INVALID_SRAM_HANDLE;
		}
	}
	else
	{
		varCstatus = CSTATUS_PMM_NOT_INITIALISED;
	}
	return varCstatus;
}

//********************************************************************************************************
// PMMSTATUS ModifyUser( SHORT UserId, BYTE Usergroup, TV_BOOL CustomOrDefault ) 
///
/// Checks whether PMM is initialised, Handle to SRAM is obtained.
///	Invokes the ModifyUserGroup	of CUserValidation class and Returns the proper 
///	error codes. 	
///
/// @param[in] UserId			- Id of the user for which user group has to be changed.
///
/// @param[in] Usergroup		- User group to be changed.
///
/// @param[in] CustomOrDefault	- Whether to use the Custom permission or default group permission.
///								SET - Custom permission RESET - Default group permission. 	
///
/// @return PMMSTATUS - If the user group is successfully changed returns SUCCESS.
/// 
/// @todo - 
///		
/// @note - COMMIT of CMM has to be called to update the changes to the 
///			current section of memory by the client requesting the service of this API.	
///
//********************************************************************************************************
//**********************************************************************************************
// Revision History
//**********************************************************************************************
// 
// 1 V6 Firmware1	6/23/2004		Shyam Prasad				
// 
//
//**********************************************************************************************
//**********************************************************************************************

PMM_API PMMSTATUS ModifyUser(SHORT ID, BYTE UserGroup, TV_BOOL CustomOrDefault) {
	//		If this DLL is dynamically linked against the MFC
	//		DLLs, any functions exported from this DLL which
	//		call into MFC must have the AFX_MANAGE_STATE macro
	//		added at the very beginning of the function.

	AFX_MANAGE_STATE (AfxGetStaticModuleState());

PMMSTATUS	varCstatus = CSTATUS_UNDEFINED;	// Status in client understandable format.
	PMMERROR varPmmStatus = PMM_UNDEFINED;// status to be converted to client understandable format.

	LOG_INFO(PMM_qDebugR_MODE,("PMM API: ModifyUser "));
	// Check if PMM is initialised.
	if(TRUE == g_pmmData.IsPMMInitialised())
	{								// Check if proper SRAM handle is obtained.
		if(TRUE == g_pmmData.IsDALInit())
		{
			if((ID > ZERO) && (ID <= MAX_USERS))
			{
				varPmmStatus = g_pmmData.ModifyUserGroup(ID,	// ID of User.
						UserGroup,// User Group to be changed
						CustomOrDefault);// Default or custom permission.		
				varCstatus = GetErrorType(varPmmStatus);
			}
			else
			{
				varCstatus = CSTATUS_INVALID_USER_ID;
			}
		}
		else
		{
			varCstatus = CSTATUS_INVALID_SRAM_HANDLE;
		}
	}
	else
	{
		varCstatus = CSTATUS_PMM_NOT_INITIALISED;
	}

	return varCstatus;
}

//****************************************************************************************
// PMMSTATUS	GetUser(SHORT *UserId,USERDATA *UserData)
///
/// @param[in] *UserId - *UserId should be SET to '0' by the client if requesting for the 
///	first user information next successive calls will give the information of the next 
///	users present and *UserId will be updated by PMM.
///
/// @param[in] *UserData - Updates the information of the User required. 
///
/// @return PMMSTATUS - If the user information is obtained returns SUCCESS else returns 
///						appropriate error code.
/// 
/// @todo
///
/// @note - *UserId should be SET to '0' by the client if requesting for the 
///	first user information next successive calls will give the information of the next 
///	users present and *UserId will be updated by PMM.
///
//****************************************************************************************
//*****************************************************************************************
// Revision History
// ***************************************************************************************
// 
// 1 V6 Firmware1	6/23/2004		Shyam Prasad				
// 
//
// ***************************************************************************************
//****************************************************************************************

PMM_API PMMSTATUS GetUser(SHORT *UserId, T_USERDATA *UserData) {
	//		If this DLL is dynamically linked against the MFC
	//		DLLs, any functions exported from this DLL which
	//		call into MFC must have the AFX_MANAGE_STATE macro
	//		added at the very beginning of the function.

	AFX_MANAGE_STATE (AfxGetStaticModuleState());

PMMSTATUS	varCstatus = CSTATUS_UNDEFINED;	// Status in client understandable format.
	PMMERROR varPmmStatus = PMM_UNDEFINED;// status to be converted to client understandable format.

	LOG_INFO(PMM_qDebugR_MODE,("PMM API : GetUser "));
	// Check if PMM is initialised.
	if(TRUE == g_pmmData.IsPMMInitialised())
	{								// Check if proper SRAM handle is obtained.
		if(TRUE == g_pmmData.IsDALInit())
		{
			if(*UserId >= ZERO && (*UserId <= MAX_USERS))
			{
				varPmmStatus = g_pmmData.GetUserData(UserId,
						UserData);
				varCstatus = GetErrorType(varPmmStatus);
			}
			else
			{
				varCstatus = CSTATUS_INVALID_USER_ID;
			}
		}
		else
		{
			varCstatus = CSTATUS_INVALID_SRAM_HANDLE;
		}
	}
	else
	{
		varCstatus = CSTATUS_PMM_NOT_INITIALISED;
	}
	return varCstatus;
}

//**********************************************************************************************
// PMMSTATUS GetUserById ( SHORT UserId, USERDAT *UserData ) 
///
/// Checks whether PMM is initialised, Handle to SRAM is obtained.
///	Invokes the GetUserById of CPasswordManager class.
///
/// @param[in]		UserId		- Id of the user for which information has to be obtained.
///
/// @param[out]	*UserData	- Returns the User information of the Requested user and 
///								UserId will be updated by the PMM in Successive calls.
///
/// @return			PMMSTATUS	- Returns Error codes if fails or retuns CSTATUS_OK.	
/// 
/// @todo - 
///
//**********************************************************************************************
// Revision History
//**********************************************************************************************
// 
// 1 V6 Firmware1	6/23/2004		Shyam Prasad				
// 
//
//**********************************************************************************************
//**********************************************************************************************

PMM_API PMMSTATUS GetUserById(SHORT ID, T_USERDATA *UserData) {
	//		If this DLL is dynamically linked against the MFC
	//		DLLs, any functions exported from this DLL which
	//		call into MFC must have the AFX_MANAGE_STATE macro
	//		added at the very beginning of the function.

	AFX_MANAGE_STATE (AfxGetStaticModuleState());

PMMSTATUS	varCstatus = CSTATUS_UNDEFINED;	// Status in client understandable format.
	PMMERROR varPmmStatus = PMM_UNDEFINED;// status to be converted to client understandable format.

	LOG_INFO(PMM_qDebugR_MODE,("PMM API: GetUserById "));
	// Check if PMM is initialised.
	if(TRUE == g_pmmData.IsPMMInitialised())
	{								// Check if proper SRAM handle is obtained.
		if(TRUE == g_pmmData.IsDALInit())
		{
			if((ID > ZERO) && (ID <= MAX_USERS))
			{
				varPmmStatus = g_pmmData.GetUserDataById(ID,
						UserData);
				varCstatus = GetErrorType(varPmmStatus);
			}
			else
			{
				varCstatus = CSTATUS_INVALID_USER_ID;
			}
		}
		else
		{
			varCstatus = CSTATUS_INVALID_SRAM_HANDLE;
		}
	}
	else
	{
		varCstatus = CSTATUS_PMM_NOT_INITIALISED;
	}

	return varCstatus;
}

//*********************************************************************************************
// PMMSTATUS GetUserPermission ( SHORT UserId, DWORD *Perm ) 
///
/// Checks whether PMM is initialised, Handle to SRAM is obtained.
///	Invokes the getPermission of CPasswordManager class.
///
/// @param[in]	UserId		- UserId of the user for which information is to be obtained.
///							if UserId 1001,1002,1003,1004 the permission of the Group is obtained.
///							'51' and '52' are considered as special cases and Gets the permission of 
///							BackDoor User and First time user. 	
///
/// @param[out] *Perm		- Permission of the requested user is copied on to Perm bit 
///							pointer allocated by the client.
///
/// @return		PMMSTATUS	- Returns CSTATUS_OK if Successful else returns appropriate Error code.
/// 
/// @todo - 
///
/// @note - An Array of 4 DWORDS has to be allocated by the clients requesting the service. 
///			Appropriate permissions will be filled in the allocated memory and returned to clients.
///
//**********************************************************************************************
//**********************************************************************************************
// Revision History
//**********************************************************************************************
// 
// 1 V6 Firmware1	6/23/2004		Shyam Prasad				
// 
//
//*****************

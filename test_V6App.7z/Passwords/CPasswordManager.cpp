/******************************************************************************************
 /// @file CPasswordManager.cpp
 /// ***************************************************************************************
 /// © Honeywell Trendview
 /// ***************************************************************************************
 /// @n Module	:	 Password Management Module
 /// @n Filename	:	 CPasswordManager.cpp
 /// @n Desc		:	 CPasswordManager is the class which handles all the API call
 ///					 related to Queries on the Existing user and all the NVRAM Access
 ///					 and modification is implemented in this class.
 ///
 // ***************************************************************************************
 // Revision History
 // ************************************************************************************************************
 // $Log[1]:
 //  13  Stability Project 1.8.1.3 7/2/2011 4:56:23 PM Hemant(HAIL)
 // Stability Project: Recorder source has been upgraded from IL
 //  version of firmware to JF version of firmware.
 // $Log" for functions
 // $
 //
 // ***********************************************************************************************************
 /**************************************************************************************************************
 COPYRIGHT (c) 2004
 HONEYWELL INC.,
 ALL RIGHTS RESERVED

 This software is a copyrighted work and/or information protected
 as a trade secret. Legal rights of Honeywell Inc. in this
 software is distinct from ownership of any medium in which the
 software is embodied. Copyright or trade secret notices included
 must be reproduced in any copies authorized by Honeywell Inc.
 The information in this software is subject to change without
 notice and should not be considered as a commitment by Honeywell
 Inc.
 ******************************************************************************************/

/************** Header File Declaration *********/

#include "CPasswordManager.h"
#include "CUserValidation.h"
#include "dal.h"
#include "TVtime.h"

#include "AuthenticatePwd.h"

/************** End of Header inclusion *********/

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
WCHAR szDbgMsg[512];

/************** Global Declaration ***************/
//extern QLibrary			glbDllHandle;				///< Global Tracer Handle
/************* Global Tracer functions Declarations **************/

//extern fnTraceStart		TraceStart;					///< Global function pointer to start Tracer Module
//extern fnTrace			Trace;						///< Global function pointer to log traces
//extern fnTraceStop		TraceStop;					///< Global function pointer to stop Tracer Module
/************** End Global Declaration ***************/

//*************************************************************************************************
// CPasswordManager :: CPasswordManager()	 
///
//**************************************************************************************************
CPasswordManager::CPasswordManager() {

	LOG_INFO (PMM_qDebugR_MODE, ("PMM : CPasswordManager::CPasswordManager - Constructor"));
	// Initialise all the 50 user m_m_stLogDetails to ZERO.
	int users = 0, perm = 0;
	for (users = 0; users < MAX_USERS; users++) {
		m_stLogDetails[users].LoginCount = ZERO;
		m_stLogDetails[users].LastLoginTime = ZERO;
	}

	m_stLoginUsersInfo.AccessLevel = (BYTE) OPERATOR_LEVEL;			// AccessLevel should be defaulted to Operator.
	m_stLoginUsersInfo.LoginUsersCount = (BYTE) ZERO;

	m_ConfigId = ZERO;
	m_Mode = ZERO;

	m_stUserDataWorking = NULL;
	m_stUserDataCurrent = NULL;

	m_SerialNumber = 100001;

	for (perm = 0; perm < USERPASSPERM_PERM_SIZE; perm++) {
		m_BackDoorUserPerm[perm] = ZERO;
		m_FirstTimeUserPerm[perm] = ZERO;
	}
}

//*************************************************************************************************
// CPasswordManager :: ~CPasswordManager()	 
///
//**************************************************************************************************
//**********************************************************************************************
// Revision History
//**********************************************************************************************
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad	  
//  
//
//**********************************************************************************************
//**********************************************************************************************

CPasswordManager::~CPasswordManager() {

	LOG_INFO (PMM_qDebugR_MODE, ("PMM : CPasswordManager::CPasswordManager - Destructor"));

}

//*************************************************************************************************
// BOOL CPasswordManager :: IsPMMInitialised()	 
//
///	Utility function which returns the status whether PMM Module is initialised or not.	 	
///
/// @return Whether the PMM is initialised or not.
///			 TRUE - PMM Initialised. 	
///			 FALSE - PMM not initialised.
///
//**************************************************************************************************
//**********************************************************************************************
// Revision History
//**********************************************************************************************
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad	  
//  
//
//**********************************************************************************************
//**********************************************************************************************

BOOL CPasswordManager::IsPMMInitialised() {
	return m_PMMinitialise;
}

//*************************************************************************************************
// BOOL CPasswordManager :: IsCFRMode()	 
//
/// Utility function which returns the mode of recorder.	 	
//
/// @return Whether the Recorder is in CFR mode or NonCFR mode.
///			 TRUE - CFR mode. 	
///			 FALSE - NonCFR Mode.
/// @todo - 
///
//**************************************************************************************************
//**********************************************************************************************
// Revision History
//**********************************************************************************************
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad	  
//  
//
//**********************************************************************************************
//**********************************************************************************************

TV_BOOL CPasswordManager::IsCFRMode() {
	return m_Mode;
}

//*************************************************************************************************
// BOOL CPasswordManager :: IsDALInit()	 
//
/// Utility function which returns the status whether SRAM handle is obtained or not.	 	
///
/// @return Whether the Proper Handle for SRAM is obtained or not.
///			 TRUE - Handle for SRAM is obtained. 	
///			 FALSE - Proper handle for SRAM is not obtained.
/// @todo - 
///
//**************************************************************************************************
//**********************************************************************************************
// Revision History
//**********************************************************************************************
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad	  
//  
//
//**********************************************************************************************
//**********************************************************************************************

BOOL CPasswordManager::IsDALInit() {
	if (NULL != m_stNVData) {
		return TRUE;
	} else {
		return FALSE;
	}
}

//********************************************************************************************************
// PMMERROR CPasswordManager::ModifyUserGroup ( SHORT UserId, BYTE Usergroup, TV_BOOL CustomOrDefault ) 
//
/// Changes the User group and the permission user is reffering to.
///
/// @param[in] UserId			- UserId of the user for which user group has to be changed.
///
/// @param[in] Usergroup		- new User group of the UserId speciifed.
///
/// @param[in] CustomOrDefault	- Whether to use the Custom or default permission.
///								 SET - Custom permission RESET - Default permission. 	
///
/// @return PMMERROR - If the user group is successfully changed returns SUCCESS.
/// 
/// @todo - 
///
/// @note - COMMIT of CMM has to be called to update the changes to the 
///			current section of memory by the client requesting the service of this API.	
///
//********************************************************************************************************
//**********************************************************************************************
// Revision History
//**********************************************************************************************
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad	  
//  
//	 2	 V6 Firmware1	 09/27/2004		Shyam prasad	Check for the User if the user is using the default 
//		 group permission if the user group is changed copy the changed group permission to the user permission mask.		
//**********************************************************************************************
//**********************************************************************************************

PMMERROR CPasswordManager::ModifyUserGroup(SHORT UserId, BYTE Usergroup, TV_BOOL CustomOrDefault) {
	PMMERROR varPmmStatus;

	LOG_INFO (PMM_qDebugR_MODE, ("PMM ---------------------CPasswordManager::ModifyUserGroup ----------------------"));

	try {
		if (m_stUserDataCurrent->UserData[UserId - ONESLOT].Used) 	// Checks whether the slot is in use or not.
		{
			if (Usergroup <= (OPERATOR_PERM - GROUP_OFFSET)) {
				if (m_stUserDataWorking->UserData[UserId - ONESLOT].UsrInfo.UserGroup != Usergroup) {
					// Change the Group to as specified group.
					m_stUserDataWorking->UserData[UserId - ONESLOT].UsrInfo.UserGroup = Usergroup;
					// If the user is using the default group permission, Then copy the new group
					// permission to the User permission mask.
					// If the user is custom permission user and changing the group, default permission
					// mask of the group will be copied to the user permission mask.
					// To customise the user permission user should call SetPermission API with specific permission mask.

					if (ADMINISTRATOR != Usergroup) {
						memcpy(m_stUserDataWorking->UserData[UserId - ONESLOT].PwdInfo.Perm,
								(char*) &m_stUserDataCurrent->GroupPerm[Usergroup], (sizeof(DWORD) * PERM_MASK_SIZE));
					}
					// If the user is changing to the "ADMINISTARTOR" group the group permission will be made all '1'.
					else {
						for (SHORT BitMask = ZERO; BitMask < PERM_MASK_SIZE; BitMask++) {
							m_stUserDataWorking->UserData[UserId - ONESLOT].PwdInfo.Perm[BitMask] = 0xFFFFFFFF;
						}
					}
				}
				// Update the Permission type the user is using whether Custom permission or default permission.
				m_stUserDataWorking->UserData[UserId - ONESLOT].UsrInfo.CustomOrDefault = CustomOrDefault;

				LOG_INFO (PMM_qDebugR_MODE, ("PMM : CPasswordManager::ModifyUserGroup - Changed Group = %d "), m_stUserDataWorking->UserData[UserId
						- ONESLOT].UsrInfo.UserGroup);

				varPmmStatus = PMM_SUCCESS;
			} else {
				varPmmStatus = PMM_INVALID_USERGROUP;
				LOG_INFO (PMM_qDebugR_MODE, ("PMM : CPasswordManager::ModifyUserGroup FAILED - PMM_INVALID_USERGROUP"));
			}
		} else {
			varPmmStatus = PMM_INVALID_USER_ID;
			LOG_INFO (PMM_qDebugR_MODE, ("PMM : CPasswordManager::ModifyUserGroup FAILED - PMM_INVALID_USER_ID"));
		}
	} catch (...) {
		LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPasswordManager::ModifyUserGroup : Exception block "));
		varPmmStatus = PMM_FAILED;
	}
	return varPmmStatus;
}

//**********************************************************************************************
// PMMERROR CPasswordManager::GetUserData ( SHORT *UserId, USERDAT *UserData ) 
//
///	Will return information of the UserId updated by the PMM and return success if 
///	appropriate Userinformation is found else returns Error code
///
/// @param[in,out] *UserId		- If the Details of the First User is required then the 
///								 client has to update the UserId field to '0' then details 
///								 of the first user is obtained. If Successive User information
///								 has to be obtained UserId will be updated by the PMM and returns 
///								 the UserData of the next User.
///
/// @param[out]	  *UserData	- Returns the User information of the Requested user and 
///								 UserId will be updated by the PMM in Successive calls.
///
/// @return			PMMERROR	- Returns Error codes if fails or retuns PMM_SUCCESS.	
/// 
/// @todo - 
///
/// @note - A valid pointer has to be passed by the clients to fill the User information.
///
//**********************************************************************************************
// Revision History
//**********************************************************************************************
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad	  
//  
//
//**********************************************************************************************
//**********************************************************************************************

PMMERROR CPasswordManager::GetUserData(SHORT *pUserId, T_USERDATA *pUserData) {
	PMMERROR varPmmStatus = PMM_SUCCESS;
	SHORT Users = ZERO;

	LOG_INFO (PMM_qDebugR_MODE, ("PMM ------------------CPasswordManager::GetUserData ------------------"));

	try {
		if ((NULL != pUserData) && (NULL != pUserId)) {
			if (ZERO == *pUserId) {
				//PSR - Coverity issue fix --#776040
				// Loop till a Used slot is obtained.
				for (Users = ZERO; Users < MAX_USERS; Users++) {
					if (m_stUserDataCurrent->UserData[Users].Used) {
						// Copy the user data.
						memcpy((char*) pUserData, (char*) &m_stUserDataCurrent->UserData[Users], sizeof(T_USERDATA));
						// Return the slot at which user is obtained.

						*pUserId = Users + ONESLOT;
						LOG_INFO (PMM_qDebugR_MODE, ("PMM : CPasswordManager::GetUserData - First user = %d"), Users);

						varPmmStatus = PMM_SUCCESS;
						break;
					} else {
						//*UserId = ZERO;
						varPmmStatus = PMM_NO_USERS;
					}
				}
			} else {	// Loop for the next user for the UserId in the signature.
				//PSR - Coverity issue fix --#776040
				for (Users = *pUserId; Users < MAX_USERS; Users++) {	// Loop Till next Used slot is obatained.
					if (m_stUserDataCurrent->UserData[Users].Used) {	// Copy the user data.
						memcpy((char*) pUserData, (char*) &m_stUserDataCurrent->UserData[Users], sizeof(T_USERDATA));
						// Return the slot at which user is obtained.
						*pUserId = Users + ONESLOT;

						LOG_INFO (PMM_qDebugR_MODE, ("PMM : CPasswordManager::GetUserData - Next user = %d"), Users);

						varPmmStatus = PMM_SUCCESS;
						break;
					} else {
						varPmmStatus = PMM_NO_USERS;
					}
				}
			}
		} else {
			varPmmStatus = PMM_INVALID_PARAMETER;
			LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPasswordManager::GetUserData FAILED - PMM_INVALID_PARAMETER "));
		}

	} catch (...) {
		LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPasswordManager::GetUserData : Exception block "));
		varPmmStatus = PMM_FAILED;
	}
	return varPmmStatus;

}

//**********************************************************************************************
// PMMERROR CPasswordManager::GetUserDataById ( SHORT UserId, USERDAT *UserData ) 
//
/// Will return information of the UserId mensioned and returns appropriate Userinformation 
///	if found else returns suitable Error code.
///
/// @param[in]		UserId		- Id of the user for which information has to be obtained.
///
/// @param[out]	  *UserData	- Returns the User information of the Requested user and 
///								 UserId will be updated by the PMM in Successive calls.
///
/// @return			PMMERROR	- Returns Error codes if fails or retuns PMM_SUCCESS.	
/// 
/// @todo - 
///
/// @note - A valid pointer has to be passed by the clients to fill the User information.
///
//**********************************************************************************************
// Revision History
//**********************************************************************************************
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad	  
//  
//
//**********************************************************************************************
//**********************************************************************************************
PMMERROR CPasswordManager::GetUserDataById(SHORT UserId, T_USERDATA *pUsrDat) {
	PMMERROR varPmmStatus;
	// Check for the UserId obtained is in use or not.

	LOG_INFO (PMM_qDebugR_MODE, ("PMM ------------------CPasswordManager::GetUserDataById ---------------------"));

	try {
		if (NULL != pUsrDat) {
			if (m_stUserDataCurrent->UserData[UserId - ONESLOT].Used) {	// Copy the user data.
				memcpy((char*) pUsrDat, (char*) &m_stUserDataCurrent->UserData[UserId - ONESLOT], sizeof(T_USERDATA));

				LOG_INFO (PMM_qDebugR_MODE, ("PMM : CPasswordManager::GetUserDataById - User obtained = %d"), UserId);

				varPmmStatus = PMM_SUCCESS;
			} else {
				varPmmStatus = PMM_INVALID_USER_ID;
				LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPasswordManager::GetUserDataById FAILED - PMM_INVALID_USER_ID "));
			}
		} else {
			varPmmStatus = PMM_INVALID_PARAMETER;
			LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPasswordManager::GetUserDataById FAILED - PMM_INVALID_PARAMETER "));
		}

	} catch (...) {
		LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPasswordManager::GetUserDataById : Exception block "));
		varPmmStatus = PMM_FAILED;
	}

	return varPmmStatus;
}

//*********************************************************************************************
// PMMERROR CPasswordManager::GetPermission ( SHORT UserId, DWORD *Perm ) 
//
/// Fills the Permission mask of the UserId specified. Permission of the First Time User 
///	and BackDoor User can be obtained as special cases by Menstioning UserId = 51 for BackDoor 
///	User and UserId = 52 for First Time User.
///
/// @param[in]	UserId		- UserId of the user for which information is to be obtained.
///							 if UserId 1001,1002,1003,1004 the permission of the Group is obtained.
///
/// @param[out] *Perm		- Permission of the requested user is copied on to Perm bit 
///							 array allocated by the client.
///
/// @return		PMMERROR	- Returns PMM_SUCCESS if Successful else returns appropriate Error code.
/// 
/// @todo - 
///
/// @note - An Array of 4 DWORDS has to be allocated by the clients requesting the service. 
///			Appropriate permissions will be filled in the allocated memory and returned to clients.
///
//**********************************************************************************************
//**********************************************************************************************
// Revision History
//**********************************************************************************************
//  1  V6 Firmware1	 6/23/2004		Shyam 
//  
//	 2	 V6 Firmware1	 12/28/2005		Shyam - Added a new group "UNRESTRICTED_PERM", for clients
//												to obtain permission for this group needs to 
//												use 1005 as their Id. 	
//**********************************************************************************************
//**********************************************************************************************

PMMERROR CPasswordManager::GetPermission(SHORT UserId, DWORD *pPerm) {
	PMMERROR varPmmStatus;
	LOG_INFO (PMM_qDebugR_MODE, ("PMM ------------------CPasswordManager::GetPermission ---------------------"));
	try {
		if (NULL != pPerm) {
			if (UserId <= MAX_USERS) {	// Gets the Permission bits of the User UserId specified.
				if (m_stUserDataCurrent->UserData[UserId - ONESLOT].Used) {
					if (TRUE == m_stUserDataCurrent->UserData[UserId - ONESLOT].UsrInfo.CustomOrDefault) {
						memcpy((char*) pPerm, (char*) &m_stUserDataCurrent->UserData[UserId - ONESLOT].PwdInfo.Perm,
								(sizeof(DWORD) * PERM_MASK_SIZE));

						LOG_INFO (PMM_qDebugR_MODE, ("PMM : CPasswordManager::GetPermission of UserId = %d"), UserId);

						varPmmStatus = PMM_SUCCESS;
					} else {
						SHORT lUsrGroup = m_stUserDataCurrent->UserData[UserId - ONESLOT].UsrInfo.UserGroup;
						memcpy((char*) pPerm, (char*) &m_stUserDataCurrent->GroupPerm[lUsrGroup], //UserData[UserId - ONESLOT].PwdInfo.Perm,
								(sizeof(DWORD) * PERM_MASK_SIZE));

						LOG_INFO (PMM_qDebugR_MODE, ("PMM : CPasswordManager::GetPermission of UserId = %d"), UserId);

						varPmmStatus = PMM_SUCCESS;
					}

				} else {
					varPmmStatus = PMM_INVALID_USER_ID;
					LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPasswordManager::GetPermission FAILED - PMM_INVALID_USER_ID"));
				}
			} else {
				switch (UserId) /// Gets the Permission bits of the group
				{

				LOG_INFO (PMM_qDebugR_MODE, ("PMM : CPasswordManager::GetPermission of Special permissions = %d"), UserId);
				// Gets the SUPERVISOR group permission
			case SUPERVISOR_PERM: {
				memcpy((char*) pPerm, (char*) &m_stUserDataCurrent->GroupPerm[UserId - GROUP_OFFSET],
						(sizeof(DWORD) * PERM_MASK_SIZE));
				varPmmStatus = PMM_SUCCESS;
				break;
			}
				// Gets the ENGINEER group permission
			case ENGINEER_PERM: {
				memcpy((char*) pPerm, (char*) &m_stUserDataCurrent->GroupPerm[UserId - GROUP_OFFSET],
						(sizeof(DWORD) * PERM_MASK_SIZE));
				varPmmStatus = PMM_SUCCESS;
				break;
			}
				// Gets the TECHNICIAN group permission
			case TECHNICIAN_PERM: {
				memcpy((char*) pPerm, (char*) &m_stUserDataCurrent->GroupPerm[UserId - GROUP_OFFSET],
						(sizeof(DWORD) * PERM_MASK_SIZE));
				varPmmStatus = PMM_SUCCESS;
				break;
			}
				// Gets the OPERATOR group permission
			case OPERATOR_PERM: {
				memcpy((char*) pPerm, (char*) &m_stUserDataCurrent->GroupPerm[UserId - GROUP_OFFSET],
						(sizeof(DWORD) * PERM_MASK_SIZE));
				varPmmStatus = PMM_SUCCESS;
				break;
			}
			case UNRESTRICTED_PERM: {
				memcpy((char*) pPerm, (char*) &m_stUserDataCurrent->GroupPerm[UserId - GROUP_OFFSET],
						(sizeof(DWORD) * PERM_MASK_SIZE));
				varPmmStatus = PMM_SUCCESS;
				break;
			}
				// Gets the BACKDOOR_USER group permission Id = 51
			case BACKDOOR_USER: {
				memcpy((char*) pPerm, (char*) &m_BackDoorUserPerm, (sizeof(DWORD) * PERM_MASK_SIZE));
				varPmmStatus = PMM_SUCCESS;
				break;
			}
				// Gets the FIRSTTIME_USER group permission Id = 52
			case FIRSTTIME_USER: {
				memcpy((char*) pPerm, (char*) &m_FirstTimeUserPerm, (sizeof(DWORD) * PERM_MASK_SIZE));
				varPmmStatus = PMM_SUCCESS;
				break;
			}
			default: {
				varPmmStatus = PMM_INVALID_USER_ID;
				break;
			}
				}
			}
		} else {
			varPmmStatus = PMM_INVALID_PARAMETER;
			LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPasswordManager::GetPermission FAILED - PMM_INVALID_PARAMETER"));
		}

	} catch (...) {
		LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPasswordManager::GetPermission : Exception block "));
		varPmmStatus = PMM_FAILED;
	}

	return varPmmStatus;
}

//*********************************************************************************************
// PMMERROR CPasswordManager::SetPermission ( SHORT UserId, DWORD *Perm ) 
//
/// Sets the Permission mask of the UserId specified. Permission of the First Time User 
///	and BackDoor User can be Set as special cases by Menstioning UserId = 51 for BackDoor 
///	User and UserId = 52 for First Time User. If the permission of the Group has to be changed then the 
///	User can do the change by sending 1001,1002,1003,1004 in the UserId field.Permission of the "ADMIN" 
///	cannot be change since "ADMIN" permission bits are all SET.
///
/// @param[in]	UserId		- Id of the user.
///
/// @param[out] *Perm		- Permission of the requested user is copied from Perm bit 
///							 array given by the client to the respective User requested.
///
/// @return		PMMERROR	- Returns PMM_SUCCESS if Successful else returns appropriate Error code.
/// 
/// @todo - 
///
//**********************************************************************************************
//**********************************************************************************************
// Revision History
//**********************************************************************************************
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad	  
//  
//	 2	 V6 Firmware1	 09/27/2004		Shyam Prasad	PMM_NOT_CUSTOM_PERMISSION_USER Error code was removed,
//														and PMM_CANNOT_CHANGE_ADMIN_PERMISSION added.	
//
//	 3	 V6 Firmware1	 12/28/2005		Shyam - Added a new group "UNRESTRICTED_PERM", for clients
//												to obtain permission for this group needs to 
//												use 1005 as their Id. 
//**********************************************************************************************
//**********************************************************************************************

PMMERROR CPasswordManager::SetPermission(SHORT UserId, DWORD *pPerm) {
	PMMERROR varPmmStatus;
	LOG_INFO (PMM_qDebugR_MODE, ("PMM ------------------CPasswordManager::SetPermission ---------------------"));
	try {
		if (NULL != pPerm) {
			if ((UserId <= MAX_USERS)) {
				if (m_stUserDataCurrent->UserData[UserId - ONESLOT].Used) {
					if (m_stUserDataCurrent->UserData[UserId - ONESLOT].UsrInfo.UserGroup != ADMINISTRATOR) {
						if (TRUE == m_stUserDataCurrent->UserData[UserId - ONESLOT].UsrInfo.CustomOrDefault) {
							memcpy((char*) &m_stUserDataWorking->UserData[UserId - ONESLOT].PwdInfo.Perm, (char*) pPerm,
									(sizeof(DWORD) * PERM_MASK_SIZE));

							LOG_INFO (PMM_qDebugR_MODE, ("PMM : CPasswordManager::SetPermission of UserId = %d"), UserId);

							varPmmStatus = PMM_SUCCESS;
						} else {
							varPmmStatus = PMM_NOT_CUSTOM_PERMISSION_USER;
							LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPasswordManager::SetPermission FAILED - PMM_NOT_CUSTOM_PERMISSION_USER"));
						}
					}
					// If the user is ADMIN group user will not be able to change the permission
					// since all the Bit mask will be true and ADMIN will be allowed to all the
					// area.
					else {
						varPmmStatus = PMM_CANNOT_CHANGE_ADMIN_PERMISSION;
					}
					//else
					//{
					//	varPmmStatus = PMM_NOT_CUSTOM_PERMISSION_USER;
					//	LOG_ERROR ( Trace,Trace ( _T ( "PMM : CPasswordManager::SetPermission FAILED - PMM_NOT_CUSTOM_PERMISSION_USER" ) ) )
					//}
				} else {
					varPmmStatus = PMM_INVALID_USER_ID;
					LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPasswordManager::SetPermission FAILED - PMM_INVALID_USER_ID"));
				}
			} else {
				switch (UserId) {

				LOG_INFO (PMM_qDebugR_MODE, ("PMM : CPasswordManager::SetPermission of Special user = %d"), UserId);

				// Sets the SUPERVISOR group permission
			case SUPERVISOR_PERM: {
				memcpy((char*) &m_stUserDataWorking->GroupPerm[UserId - GROUP_OFFSET], (char*) pPerm,
						(sizeof(DWORD) * PERM_MASK_SIZE));
				varPmmStatus = PMM_SUCCESS;
				break;
			}
				// Sets the ENGINEER group permission
			case ENGINEER_PERM: {
				memcpy((char*) &m_stUserDataWorking->GroupPerm[UserId - GROUP_OFFSET], (char*) pPerm,
						(sizeof(DWORD) * PERM_MASK_SIZE));
				varPmmStatus = PMM_SUCCESS;
				break;
			}
				// Sets the TECHNICIAN group permission
			case TECHNICIAN_PERM: {
				memcpy((char*) &m_stUserDataWorking->GroupPerm[UserId - GROUP_OFFSET], (char*) pPerm,
						(sizeof(DWORD) * PERM_MASK_SIZE));

				varPmmStatus = PMM_SUCCESS;
				break;
			}
				// Sets the OPERATOR group permission
			case OPERATOR_PERM: {
				memcpy((char*) &m_stUserDataWorking->GroupPerm[UserId - GROUP_OFFSET], (char*) pPerm,
						(sizeof(DWORD) * PERM_MASK_SIZE));

				varPmmStatus = PMM_SUCCESS;
				break;
			}
				// For Group "Unrestricted"
			case UNRESTRICTED_PERM: {
				memcpy((char*) &m_stUserDataWorking->GroupPerm[UserId - GROUP_OFFSET], (char*) pPerm,
						(sizeof(DWORD) * PERM_MASK_SIZE));

				varPmmStatus = PMM_SUCCESS;
				break;
			}
				// Sets the BACKDOOR_USER group permission ID = 51
			case BACKDOOR_USER: {
				memcpy((char*) &m_BackDoorUserPerm, (char*) pPerm, (sizeof(DWORD) * PERM_MASK_SIZE));

				varPmmStatus = PMM_SUCCESS;
				break;
			}
				// Sets the FIRSTTIME_USER group permission Id = 52
			case FIRSTTIME_USER: {
				memcpy((char*) &m_FirstTimeUserPerm, (char*) pPerm, (sizeof(DWORD) * PERM_MASK_SIZE));

				varPmmStatus = PMM_SUCCESS;
				break;
			}
			default: {
				varPmmStatus = PMM_INVALID_USER_ID;
				break;
			}
				}

			}
		} else {
			varPmmStatus = PMM_INVALID_PARAMETER;
			LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPasswordManager::SetPermission FAILED - PMM_INVALID_PARAMETER"));
		}

	} catch (...) {
		LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPasswordManager::SetPermission : Exception block "));
		varPmmStatus = PMM_FAILED;
	}

	return varPmmStatus;
}

//*********************************************************************************************
// PMMERROR CPasswordManager::QueryUserInfo ( SHORT UserId,LOGDETAIL *Userm_stLogDetails ) 
//
/// Returns the information of the UserId mensioned like last login time and count of 
///	number of times User has login. Returns PMM_SUCCESS if the user is valid User else
///	Returns appropriate Error code.	
///
/// @param[in]	UserId				- Id of the user.
///
/// @param[out] *Userm_stLogDetails	- Gets the information of the UserId specifed like Number of 
///									 times user has login and last login time.
///
/// @return		PMMERROR			- Returns PMM_SUCCESS if Successful else returns appropriate 
///									 Error code.
/// 
/// @todo - 
///
//**********************************************************************************************
//**********************************************************************************************
// Revision History
//**********************************************************************************************
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad	  
//  
//
//**********************************************************************************************
//**********************************************************************************************

PMMERROR CPasswordManager::QueryUserInfo(SHORT UserId, LOGDETAIL *pUserm_stLogDetails) {
	PMMERROR varPmmStatus;

	LOG_INFO (PMM_qDebugR_MODE, ("PMM ------------------CPasswordManager::QueryUserInfo ----------------------------"));

	try {
		if (NULL != pUserm_stLogDetails) {
			if (m_stUserDataCurrent->UserData[UserId - ONESLOT].Used) {
				// Copy the details of the UserId specified.
				memcpy((char*) pUserm_stLogDetails, (char*) &m_stLogDetails[UserId - ONESLOT], sizeof(LOGDETAIL));

				varPmmStatus = PMM_SUCCESS;
			} else {
				varPmmStatus = PMM_INVALID_USER_ID;
				LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPasswordManager::QueryUserInfo FAILED - PMM_INVALID_USER_ID"));
			}
		} else {
			varPmmStatus = PMM_INVALID_PARAMETER;
			LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CPasswordManager::QueryUserInfo FAILED - PMM_INVALID_PARAMETER"));
		}

	} catch (...) {
		LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CPasswordManager::QueryUserInfo : Exception block "));
		varPmmStatus = PMM_FAILED;
	}

	return varPmmStatus;
}

//*********************************************************************************************
// PMMERROR CPasswordManager::GetStatus ( SHORT AreaNumber,SHORT UserId,TV_BOOL *Status )
//
/// Checks for the Area mensioned and returns the status as TRUE or FALSE in Status field.
///
/// @param[in]	AreaNumber			- Area number to be verified in Permission bit mask
///
/// @param[in] UserId				- Id of the User.
///
/// @param[out] *Status				- Status of the requested area number whether the Area number
///									 Bit is TRUE or FALSE.
///
/// @return		PMMERROR			- Returns PMM_SUCCESS if Successful else returns appropriate
///									 Error code.
///
/// @todo -
///
//**********************************************************************************************
//**********************************************************************************************
// Revision History
//**********************************************************************************************
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad
//
//
//**********************************************************************************************
//**********************************************************************************************

PMMERROR CPasswordManager::GetStatus(SHORT AreaNumber, SHORT UserId, TV_BOOL *pStatus) {
	SHORT Position, BitPosition;
	DWORD CopyDword;
	PMMERROR varPmmStatus = PMM_SUCCESS;

	LOG_INFO ( PMM_qDebugR_MODE, ("PMM ---------------CPasswordManager::GetStatus ------------------------ "));

	// Get the position of the DWORD from the array of the Permission.

	Position = (AreaNumber / BITS_IN_DWORD);
	// Get the Bit position to be tested.
	BitPosition = AreaNumber % BITS_IN_DWORD;

	if (FALSE == AreaNumber % BITS_IN_DWORD)			// || AreaNumber == 64 || AreaNumber == 96 || AreaNumber == 128)
	{
		BitPosition = BITS_IN_DWORD;
		Position = Position - ONESLOT;
	}
	// Copy the permission from the Perm bitmask to temporary location.
	if (UserId <= MAX_USERS) {
		if (TRUE == m_stUserDataCurrent->UserData[UserId - ONESLOT].Used) {
			if (m_stLoginUsersInfo.AccessLevel >= m_stUserDataCurrent->UserData[UserId - ONESLOT].UsrInfo.UserGroup) {// Check for the user level against the restricted level.
				if (TRUE == m_stUserDataCurrent->UserData[UserId - ONESLOT].UsrInfo.CustomOrDefault) {
					CopyDword = (DWORD) m_stUserDataCurrent->UserData[UserId - ONESLOT].PwdInfo.Perm[Position];
				} else {
					SHORT userGroup = m_stUserDataCurrent->UserData[UserId - ONESLOT].UsrInfo.UserGroup;
					CopyDword = (DWORD) m_stUserDataCurrent->GroupPerm[userGroup][Position];
				}
			} else {
				varPmmStatus = PMM_USER_LEVEL_DISALLOWED;
				LOG_INFO ( PMM_qDebugR_MODE, ("PMM CPasswordManager::GetStatus FAILURE - PMM_USER_LEVEL_DISALLOWED"));
			}

		} else {
			varPmmStatus = PMM_INVALID_USER_ID;
			LOG_INFO ( PMM_qDebugR_MODE, ("PMM CPasswordManager::GetStatus FAILURE - PMM_INVALID_USER_ID"));
		}
	} else {
		switch (UserId) {
		case BACKDOOR_USER: {
			CopyDword = (DWORD) m_BackDoorUserPerm[Position];
			varPmmStatus = PMM_SUCCESS;
			break;
		}

		case FIRSTTIME_USER: {
			CopyDword = (DWORD) m_FirstTimeUserPerm[Position];
			varPmmStatus = PMM_SUCCESS;
			break;
		}

		default: {
			varPmmStatus = PMM_INVALID_USER_ID;
			break;
		}
		}

	}
	// Shift the Temporary bit mask by the obtained bitposition and
	// check for the TRUE or FALSE.
	if (varPmmStatus == PMM_SUCCESS) {

		if ((CopyDword >> (BitPosition - ONESLOT)) & (0x0001)) {
			*pStatus = TRUE;
		} else {
			*pStatus = FALSE;
		}
	}

	return varPmmStatus;
}

//*********************************************************************************************
// PMMERROR CPasswordManager::SetStatus ( SHORT AreaNumber,SHORT UserId,TV_BOOL Status )
//
/// SET/RESETS the Area mensioned and returns the status as TRUE or FALSE.
///
/// @param[in]	AreaNumber			- Area number to be SET/RESET in Permission bit mask

/// @param[in] UserId				- Id of the User.
///
/// @param[in] Status				- Whether to SET/RESET the Given Area Number.
///
/// @return		PMMERROR			- Returns PMM_SUCCESS if Successful else returns appropriate
///									 Error code.
///
/// @todo -
///
//**********************************************************************************************
//**********************************************************************************************
// Revision History
//**********************************************************************************************
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad
//
//
//**********************************************************************************************
//**********************************************************************************************

/*BOOL CPasswordManager::SetStatus ( SHORT AreaNumber,SHORT UserId,TV_BOOL Status )
 {
 SHORT Position,BitPosition;
 DWORD CopyDword;
 PMMERROR varPmmStatus = PMM_SUCCESS;

 LOG_INFO ( Trace,Trace ( _T ( "PMM : CPasswordManager::GetStatus : Private " ) ) )

 // Get the position of the DWORD from the array of the Permission.

 Position = ( AreaNumber/BITS_IN_DWORD ) ;
 // Get the Bit position to be tested.
 BitPosition = AreaNumber % BITS_IN_DWORD;

 if(FALSE == AreaNumber % BITS_IN_DWORD)
 {
 BitPosition = BITS_IN_DWORD;
 Position	= Position - ONESLOT;
 }
 // Copy the permission from the Perm bitmask to temporary location.
 if ( UserId <= MAX_USERS )
 {
 if(TRUE == m_stUserDataCurrent -> UserData[UserId - ONESLOT].Used)
 {
 if ( m_stLoginUsersInfo.AccessLevel >= m_stUserDataCurrent -> UserData[UserId - ONESLOT].UsrInfo.UserGroup )
 {	// Check for the user level against the restricted level.
 CopyDword = ( DWORD ) m_stUserDataCurrent -> UserData[UserId - ONESLOT].PwdInfo.Perm[Position];
 }
 else
 {
 varPmmStatus = PMM_USER_LEVEL_DISALLOWED;
 }
 }
 else
 {
 varPmmStatus = PMM_INVALID_USER_ID;
 }
 }
 else
 {
 switch ( UserId )
 {
 case BACKDOOR_USER :
 {
 CopyDword = ( DWORD ) m_stUserDataCurrent -> UserData[UserId - ONESLOT].PwdInfo.Perm[Position];
 varPmmStatus = PMM_SUCCESS;
 break;
 }

 case FIRSTTIME_USER :
 {
 CopyDword = ( DWORD ) m_stUserDataCurrent -> UserData[UserId - ONESLOT].PwdInfo.Perm[Position];
 varPmmStatus = PMM_SUCCESS;
 break;
 }

 default:
 {
 varPmmStatus = PMM_INVALID_USER_ID;
 break;
 }
 }

 }
 // Shift the Temporary bit mask by the obtained bitposition and
 // check for the TRUE or FALSE.
 if ( ( CopyDword >> ( BitPosition - ONESLOT ) ) | ( Status ) )
 {
 return TRUE;
 }
 else
 {
 return FALSE;
 }
 }
 */
//*********************************************************************************************
// PMMERROR CPasswordManager::ValidateUserArea ( SHORT AreaNumber, SHORT UserId, TV_BOOL *Status )
//
/// Checks for the Area mensioned and returns the status as TRUE or FALSE in Status field.
/// Returns PMM_SUCCESS if Successful else returns appropriate Error code.
///
/// @param[in]	AreaNumber	- Area Number to be verified in Permission Mask.
///
/// @param[in]	UserId		- Id of the user.
///
///	@param[out]	*Status		- Returns if the Area mensioned is TRUE or FALSE.
///
/// @return		PMMERROR	- Returns PMM_SUCCESS if Successful else returns appropriate
///							 Error code.
///
/// @todo -
///
//**********************************************************************************************
//**********************************************************************************************
// Revision History
//**********************************************************************************************
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad
//
//
//**********************************************************************************************
//**********************************************************************************************
PMMERROR CPasswordManager::ValidateUserArea(SHORT AreaNumber, SHORT UserId, TV_BOOL *pStatus) {
	PMMERROR varPmmStatus = PMM_FAILED; // coverity fix h350726 CID : 768786

	LOG_INFO ( PMM_qDebugR_MODE, ("PMM ----------------- CPasswordManager::ValidateUserArea ----------------------------"));
	try {
		if (NULL != pStatus) {
			if (UserId > ZERO) {
				if ((NULL != AreaNumber) && (AreaNumber <= MAX_AREA)) {
					varPmmStatus = GetStatus(AreaNumber, UserId, pStatus);
				} else {
					varPmmStatus = PMM_INVALID_PARAMETER;
					LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CPasswordManager::ValidateUserArea FAILED - PMM_INVALID_PARAMETER"));
				}
			}
		} else {
			varPmmStatus = PMM_INVALID_PARAMETER;
			LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CPasswordManager::ValidateUserArea FAILED - PMM_INVALID_PARAMETER"));
		}

	} catch (...) {
		LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CPasswordManager::ValidateUserArea : Exception block "));
		varPmmStatus = PMM_FAILED;
	}
	return varPmmStatus;
}

//*********************************************************************************************
// PMMERROR CPasswordManager::SetAccessLevel ( SHORT level, SHORT *PrevLevel )
//
/// API call will Set the minimum Userlevel at which user can login and returns the
///	Previous Access level of the recorder.
///
/// @param[in]	level		- User Access level to be set
///
/// @param[out]	*PrevLevel	- Previous User Accesslevel at which recorder was Working.
///
/// @return		PMMERROR	- Returns PMM_SUCCESS if Successful else returns appropriate
///							 Error code.
///
/// @todo -
///
//**********************************************************************************************
//**********************************************************************************************
// Revision History
//**********************************************************************************************
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad
//
//
//**********************************************************************************************
//**********************************************************************************************

PMMERROR CPasswordManager::SetAccessLevel(SHORT level, SHORT *PrevLevel) {
	PMMERROR varPmmStatus;

	LOG_INFO ( PMM_qDebugR_MODE, ("PMM ------------------------CPasswordManager::SetAccessLevel --------------------- "));

	if (NULL != PrevLevel) {
		if (level <= OPERATOR) {
			try {
				*PrevLevel = m_stLoginUsersInfo.AccessLevel;
				m_stLoginUsersInfo.AccessLevel = (BYTE) level;
				varPmmStatus = PMM_SUCCESS;

			} catch (...) {
				LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CPasswordManager::SetAccessLevel : Exception block "));
				varPmmStatus = PMM_FAILED;
			}
		} else {
			varPmmStatus = PMM_INVALID_GROUP_LEVEL;
			LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CPasswordManager::SetAccessLevel : PMM_INVALID_GROUP_LEVEL "));
		}
	} else {
		varPmmStatus = PMM_INVALID_PARAMETER;
		LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CPasswordManager::SetAccessLevel : PMM_INVALID_PARAMETER "));
	}

	return varPmmStatus;
}

//*********************************************************************************************
// PMMERROR CPasswordManager::ExpireUserPassword ( SHORT UserId )
//
/// Expires the password of the mensioned User and the User should change his
///	password to login.
///
/// @param[in]	UserId		- Id of the User.
///
/// @return		PMMERROR	- Returns PMM_SUCCESS if Successful else returns appropriate
///							 Error code.
///
/// @todo -
///
//**********************************************************************************************
//**********************************************************************************************
// Revision History
//**********************************************************************************************
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad
//
//
//**********************************************************************************************
//**********************************************************************************************

PMMERROR CPasswordManager::ExpireUserPassword(SHORT UserId) {
	PMMERROR varPmmStatus;

	LOG_INFO ( PMM_qDebugR_MODE, ("PMM ------------------ CPasswordManager::ExpireUserPassword ---------------------"));

	try {
		if (m_stUserDataCurrent->UserData[UserId - ONESLOT].Used) {
			CTVtime time;
			time.TimeNow();
			// Get the System time and update in expiry date of the password.
			m_stUserDataWorking->UserData[UserId - ONESLOT].PwdInfo.ExpireDate = time.GetMicroSecs();

			//--------------------------**********For Testing**********------------------------------------------------------------------
			//	CTVtime TestTime ( m_stUserDataWorking -> UserData[UserId-ONESLOT].PwdInfo.ExpireDate ) ;
			//	SYSTEMTIME TestsysTime;
			//	TestTime.GetSYSTEMTIME ( &TestsysTime ) ;
			//--------------------------**********End Testing**********------------------------------------------------------------------

			varPmmStatus = PMM_SUCCESS;
		} else {
			varPmmStatus = PMM_INVALID_USER_ID;
			LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CPasswordManager::ExpireUserPassword : PMM_INVALID_USER_ID "));
		}

	} catch (...) {
		LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CPasswordManager::ExpireUserPassword : Exception block "));
		varPmmStatus = PMM_FAILED;
	}

	return varPmmStatus;
}

PMMERROR CPasswordManager::GetUserPasswordStatus(QString szUsername, TV_BOOL *bResult) {
	*bResult = FALSE;
	SHORT UserCount = ZERO;
#ifdef PWDLOGS_ENABLE
  swprintf( szDbgMsg, L"CPasswordManager::GetUserPasswordStatus - UserName : %s GTC %d\n", szUsername, GetTickCount());
  OutputDebugString(szDbgMsg);
#endif
	for (UserCount = ZERO; UserCount <= (MAX_USERS - 1); UserCount++) {
#ifdef PWDLOGS_ENABLE
  swprintf( szDbgMsg, L"CPasswordManager::GetUserPasswordStatus - mem UserName : %s slot %d used %d GTC %d\n", m_stUserDataCurrent ->UserData[UserCount].UsrInfo.Name, UserCount, m_stUserDataCurrent -> UserData[UserCount].Used, GetTickCount());
  OutputDebugString(szDbgMsg);
#endif
		if (m_stUserDataCurrent->UserData[UserCount].Used) {
			/*
			 if ( ! ( _wcsicmp ( szUsername,m_stUserDataCurrent -> UserData[UserCount].UsrInfo.Name) ) )
			 {
			 #ifdef PWDLOGS_ENABLE
			 swprintf( szDbgMsg, L"CPasswordManager::GetUserPasswordStatus - UserName : %s GTC %d\n",szUsername, GetTickCount());
			 OutputDebugString(szDbgMsg);
			 #endif

			 HASHDWSZ2BU_32 uHash;
			 SALTDWSZ2BU_8 uSalt;

			 memcpy(uHash.b, m_stUserDataCurrent->UserData[UserCount].PwdInfo.HSCurrentPwd.Hash, SECUREPWD_HASH_SIZE);
			 memcpy(uSalt.b, m_stUserDataCurrent->UserData[UserCount].PwdInfo.HSCurrentPwd.Salt, SECUREPWD_SALT_SIZE);

			 CAuthenticatePwd curPwd(uHash, uSalt);

			 #ifdef PWDLOGS_ENABLE
			 QString  sUserHash(_T(""));
			 bool bRet =CAuthenticatePwd::hashToHexString(uHash, sUserHash);
			 QString  sUserSalt(_T(""));
			 bRet=CAuthenticatePwd::saltToHexString( uSalt, sUserSalt);

			 swprintf( szDbgMsg, L"CPasswordManager::GetUserPasswordStatus - curpwd Hash hex string : %s GTC %d\n",sUserHash, GetTickCount());
			 OutputDebugString(szDbgMsg);

			 swprintf( szDbgMsg, L"CPasswordManager::GetUserPasswordStatus - pwd Salt hex string : %s GTC %d\n",sUserSalt, GetTickCount());
			 OutputDebugString(szDbgMsg);
			 #endif

			 CAuthenticatePwd defaultPwd("password", uSalt);
			 HASHDWSZ2BU_32 uDefHash;
			 SALTDWSZ2BU_8 uDefSalt;

			 defaultPwd.getHash(uDefHash);
			 defaultPwd.getSalt(uDefSalt);

			 #ifdef PWDLOGS_ENABLE
			 QString  strDefHash;
			 QString  strDefSalt;
			 CAuthenticatePwd::hashToHexString(uDefHash, strDefHash);
			 CAuthenticatePwd::saltToHexString(uDefSalt, strDefSalt);

			 swprintf( szDbgMsg, L"CPasswordManager::GetUserPasswordStatus - Defpwd Hash hex string : %s GTC %d\n",strDefHash, GetTickCount());
			 OutputDebugString(szDbgMsg);

			 swprintf( szDbgMsg, L"CPasswordManager::GetUserPasswordStatus - Defpwd Salt hex string : %s GTC %d\n",strDefSalt, GetTickCount());
			 OutputDebugString(szDbgMsg);
			 #endif

			 //if( ! (_wcsicmp(m_stUserDataCurrent->UserData[UserCount].PwdInfo.CurrentPassword, L"password")))
			 if( curPwd == defaultPwd )
			 {
			 *bResult = TRUE;
			 return PMM_SUCCESS;
			 }
			 else
			 {
			 *bResult = FALSE;
			 return PMM_SUCCESS;
			 }
			 }*/
		}
	}
	return PMM_INVALID_USERNAME;
}

// PasswordModule.h : main header file for the PASSWORDMODULE DLL
//

#if !defined(AFX_PASSWORDMODULE_H__D893EDB4_CCE6_481A_99AC_E4B296CDED08__INCLUDED_)
#define AFX_PASSWORDMODULE_H__D893EDB4_CCE6_481A_99AC_E4B296CDED08__INCLUDED_

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CPasswordModuleApp
// See PasswordModule.cpp for the implementation of this class
//

class CPasswordModuleApp: public CWinApp {
public:
	CPasswordModuleApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPasswordModuleApp)
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CPasswordModuleApp)
	// NOTE - the ClassWizard will add and remove member functions here.
	//  DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft eMbedded Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PASSWORDMODULE_H__D893EDB4_CCE6_481A_99AC_E4B296CDED08__INCLUDED_)

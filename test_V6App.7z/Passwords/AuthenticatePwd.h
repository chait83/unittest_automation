/****************************************************************************

 //										COPYRIGHT (c) 2017
 //								HONEYWELL INTERNATIONAL INC.
 //									ALL RIGHTS RESERVED

 //		Legal rights of Honeywell Inc. in this software is distinct from
 //	ownership of any medium in which the software is embodied. 
 //	Copyright notices must be reproduced in any copies authorized by 
 //	Honeywell International Inc.
 /*****************************************************************************/

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module:		Authenticate Password
/// @n Filename:	Authenticate Password.h
/// @n Description:	Contains class header of Authenticate Password.
///
// **************************************************************************
#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_AUTHENTICATE_PWD_H_INCLUDED
#define _INC_AUTHENTICATE_PWD_H_INCLUDED

/** Revision History ********************************************************
 Author		Date		Notes
 ------	------		------
 Usha		11.09.17	Created
 ***************************************************************************/
#include "Defines.h"
#include <QString>
typedef union {
	DWORD dw[2];
	BYTE b[8];
} SALTDWSZ2BU_8;

typedef union {
	DWORD dw[8];
	BYTE b[32];
} HASHDWSZ2BU_32;

class CAuthenticatePwd {
public:
	CAuthenticatePwd();
	CAuthenticatePwd(const CAuthenticatePwd&);
	CAuthenticatePwd(const QString  &strKeyPwd, const SALTDWSZ2BU_8 &uSalt);
	CAuthenticatePwd(const HASHDWSZ2BU_32 &uHash, const SALTDWSZ2BU_8 &uSalt);
	CAuthenticatePwd(const QString  &strKeyPwd);
	~CAuthenticatePwd();

	bool compare(const QString  &strRegularPwd);
	void reset();
	bool isValid() const {
		return m_bIsValid;
	}

	void getHash(HASHDWSZ2BU_32&) const;
	void getSalt(SALTDWSZ2BU_8&) const;

	void operator =(const CAuthenticatePwd&);
	bool operator ==(const CAuthenticatePwd&) const;

	static bool isHashValid(const HASHDWSZ2BU_32&);
	static bool isSaltValid(const SALTDWSZ2BU_8&);
	static void resetHash(HASHDWSZ2BU_32&);
	static void resetSalt(SALTDWSZ2BU_8&);

	static bool hashToHexString(const HASHDWSZ2BU_32 &uHash, QString  &strHexString);
	static bool saltToHexString(const SALTDWSZ2BU_8 &uHash, QString  &strHexString);
	static bool hexStringToHash(const QString  &strHexString, HASHDWSZ2BU_32 &uHash);
	static bool hexStringToSalt(const QString  &strHexString, SALTDWSZ2BU_8 &uHash);
	const QString  EncodeToUTF8(const QString  &rstrUNICODE_SOURCE);

private:
	bool compute(const QString  &strKey, bool bGenerateSalt);
	BOOL computehash(BYTE *pbHashBuffer, DWORD *pdwHashLen, const BYTE *pbKey, DWORD dwKeyLength, BYTE *pbSalt,
			DWORD dwSaltLength, BOOL bGenerateSalt);
	static bool byteArrayToHexString(const BYTE *pbData, int nLen, QString  &str);
	static bool hexStringToByteArray(const QString  &strHexData, BYTE *pbData, int nLen);

private:
	HASHDWSZ2BU_32 m_uHash;
	SALTDWSZ2BU_8 m_uSalt;
	DWORD m_nHashBufferLength;
	static const QString  m_sSecureDelta;
	bool m_bIsValid;

public:
	static const DWORD m_nHashLength;
	static const DWORD m_nSaltLength;
};

#endif

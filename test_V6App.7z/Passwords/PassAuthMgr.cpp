/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  Passwords
/// @n Filename:  PassAuthMgr.cpp
/// @n Description: Class Implementation for the CPassAuthUI Class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  64  Stability Project 1.59.1.3 7/2/2011 4:59:37 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  63  Stability Project 1.59.1.2 7/1/2011 4:38:35 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  62  Stability Project 1.59.1.1 3/17/2011 3:20:32 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  61  Stability Project 1.59.1.0 2/15/2011 3:03:37 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
//	29/05/2014  Vellaidurai V  Fixed PAR 1-3DVR1C6 - QXe_Screen Overlapping over NUmeric Keypad_when Alarm is Acknowledge
// 30/10/2014	 Prasad			 IsAreaAllowedWhenHLSet() Function added for Fixing the PARS 
//  1-34F1XKP Hardware Lock issues related to Batch, Export and Report generation etc  
//									 1-39M2LOF Allow\Disallow the Recorder Menu Areas when Hardware lock is set in recorder.
// **************************************************************************
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif


#include "V6globals.h"
//// TODO
// #include "AlphaNumEditDlg.h"
#include "PMMglobal.h"
#include "PMMdefines.h"
#include "SipGlobal.h"
#include "PasswordInterfaceManager.h"
#include "PassAuthMgr.h"
//#include "V6MessageBoxDlg.h"
#include "CPasswordModule.h"
#include "PwdsCfgMgr.h"
#include "PassSyncEngine.h"
#include "HelpLookup.h"
#include "TopStatusBar.h"
#include "AuthenticatePwd.h"

#ifdef UNDER_V6APP
#include "threadinfo.h"
#endif

const WCHAR defaultPassword[] = L"password";
const ULONG SECOND_TO_MILLI_SECONDS = 1000 * 1000;

#ifdef RDL_PAM_ENABLE
CDebugFileLogger CPassAuthUI::m_debugFileLogger(_T("\\SDMemory\\PamDbgLogFile.txt"), FALSE, (5*1024*1024));
#endif

BOOL WINAPI LengthCallbackFunction(QString pBuffer) {
	/*	bool bValid = false;

	 //check length of user/password is less the maximum of 20 chars

	 if( wcslen(pBuffer) <= 20 )
	 {
	 bValid = true;
	 }
	 else
	 {
	 bValid = false;
	 }
	 
	 return bValid;
	 */
	return TRUE;
}

/// Initialise the Class Instance to Default Value
CPassAuthUI *CPassAuthUI::m_pInstance = NULL;

/// Initialise the Class Mutex to Default Value
QMutex *CPassAuthUI::m_CreationMutex = NULL;

CPassAuthUI::CPassAuthUI(void) : m_bInitialised(false) {
	//initialise member variables
	m_LastUserID = INVALID_USER;
#ifdef RDL_PAM_ENABLE
	SetDebugLogger(&m_debugFileLogger); //Set the defult static handler for this module
  #endif		//attempt to init
	InitRet = m_PIM.InitCPWI(CPWI_LOCAL_UI);
}

CPassAuthUI::~CPassAuthUI(void) {
}

//****************************************************************************
/// The first time this function is called it will create the single instance
/// of CPassAuthUI, Subsequent calls will return the Pointer to the instance
/// which has already been created.  
///
/// @param[in] 	  - None
///
/// @return Pointer to the Password Authentication UI 
/// 
//****************************************************************************
CPassAuthUI* CPassAuthUI::GetHandle() {
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;

	if (NULL == m_pInstance) {
		// An instance has yet to be completed
//  m_CreationMutex = CreateMutex ( NULL,					  // No security descriptor
//    FALSE,					  // Mutex object not owned
//    TEXT("PassAuthMgr") );	  // Object name

		m_CreationMutex = new QMutex();

		//waitSingleObjectResult = m_CreationMutex.tryLock(g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);
		m_CreationMutex.lock();

		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:

			// Object was signaled
			if (NULL == m_pInstance) {
				m_pInstance = new CPassAuthUI;

			} // End of IF

//  if( FALSE == m_CreationMutex.unlock(); )
//  {
			m_CreationMutex.unlock();
			//V6WarningMessageBox( NULL, L"Failed to release PassAuthMgr mutex", L"CPassAuthUI Error", MB_OK );
//  } // End of IF

			break;

		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
			//V6WarningMessageBox( NULL, L"PassAuthMgr WaitForSingleObject Error", L"CPassAuthUI Error", MB_OK );
			break;

		} // End of SWITCH 

		// Close the Mutex as no longer required
		////No need to close the mutex in Qt

	} // End of IF 

	return (m_pInstance);

} // End of Member Function

//****************************************************************************
/// Deletes the instance of the singleton from memory
///
/// @param[in] 	  - NONE
///
/// @return QUEMAN_OK - Cleanup was Successful
/// 
//****************************************************************************
BOOL CPassAuthUI::CleanUp(void) {
	delete m_pInstance;
	m_pInstance = NULL;

	return ( TRUE);

} // End of Member Function

//****************************************************************************
/// Initialises the CPWI for use by the class
/// 
///
/// @param[in] none
///
/// @return FALSE if init un-successful
/// 
/// 
//****************************************************************************
BOOL CPassAuthUI::Initialise(void) {
	PMMSTATUS InitRet = CSTATUS_OK;
	if ( FALSE == m_bInitialised) {
		if (FALSE == m_PIM.IsCPWIInitialised()) {
			//initialise the PIM
			InitRet = m_PIM.InitCPWI(CPWI_LOCAL_UI);	//or CPWI_MENU_CONFIGURATION_SCREEN,
		}
		// set the initialised flag
		m_bInitialised = true;
	}
	if (CSTATUS_OK != InitRet)
		return FALSE;
	else
		return TRUE;

} // End of Member Function
//****************************************************************************
/// request that a certain area is authenticated. The user will be prompted 
/// for username and password if the current credentials do not match the 
/// requirements for the area.
///
/// @param[in] T_AUTHENTICATION_AREAS Area - Area to be authenticated
/// 
/// @return		BOOL - TRUE Authentication sucessful and access allowed
///					  FALSE Authentication failed and access denied
//****************************************************************************
TV_BOOL CPassAuthUI::AuthenticateUserArea(T_AUTHENTICATION_AREAS Area, CWidget *pkParent) {
	//Test last logged in user
	WCHAR szMess[CPWI_MESSAGE_LENGTH] = { 0 };
	TV_BOOL AreaRes = FALSE;

	PMMSTATUS InitRet;

#ifdef RDL_PAM_ENABLE			
	QString  strLog;
  strLog==QString   ("::AuthenticateUserArea begin area %1").arg(Area);
	LogDebugMessage(strLog);
	#endif	

	if (!m_PIM.IsCPWIInitialised()) {
		//attempt to init
		InitRet = m_PIM.InitCPWI(CPWI_LOCAL_UI);
	}
	if ((AUTHENTICATION_AREA_NO_AUTH == Area) || (m_PIM.IsPasswordEnabled() != CSTATUS_OK)) {
		AreaRes = TRUE;
		if (INVALID_USER != m_LastUserID) {
			m_PIM.UpdateLastAccessTime(m_LastUserID);
		}
	} else {
		//	if (INVALID_USER != m_LastUserID)
		//	{
		QString   csTmp;
		csTmp.LoadString(glb_AuthDetails[Area].uiStrID);
		wcsncpy_s(szMess, sizeof(szMess) / sizeof(WCHAR), (LPCTSTR) csTmp, _TRUNCATE);

#ifdef RDL_PAM_ENABLE
			strLog.asprintf(_T("::AUA ValidateAreaNumber %d m_LastUserID %d"), Area, m_LastUserID);
			LogDebugMessage(strLog);
			#endif

		m_PIM.ValidateAreaNumber(Area, m_LastUserID, &AreaRes, szMess);

#ifdef RDL_PAM_ENABLE
			strLog.asprintf(_T("::AUA ValidateAreaNumber res %d"), AreaRes);
			LogDebugMessage(strLog);
			#endif
		//	}
	}
	if (TRUE == AreaRes) {
#ifdef RDL_PAM_ENABLE
		strLog.asprintf(L"::AuthenticateUserArea end1 area res %d", AreaRes);
		LogDebugMessage(strLog);
		#endif	
		//check timeout
		//TBD
		return AreaRes;
	}

#ifdef UNDER_V6APP
	CThreadInfo* pThreadInfo = CThreadInfo::GetHandle();
	//Ignore the Main thread for watchdog as we have to wait infinitely
	if(pThreadInfo != NULL)
	{
		pThreadInfo->UpdateThreadInfo(AM_OPPANEL,false);
	}
#endif

	//inform user that a logon is required for the requested action
	BOOL cont = TRUE;
	QString   csTitle;
	QString   csText;
	csTitle = tr("Recorder Security");
	if (UserLoggedOn()) {
	csText = tr("This area requires a higher access level. Please log on accordingly.");
		QString   csOK;
	csOK = tr("OK");
		QString   csCancel;
	csCancel = tr("Cancel");
		CV6MessageBoxDlg Dlg(csTitle, csText, csOK, csCancel, pkParent);
		if (IDOK != Dlg.exec()) {
			cont = FALSE;
		}
	}

	if (cont) {
		//IsAreaAllowedWhenHLSet Function return true, For those areas, having userlogin when Password system is enabled.
		//Hence by returning true the UserLogin is prompted to go further to access those respective areas of the recorder.
		if (!(pDALGLB->IsHardwareLockEnabled()) || IsAreaAllowedWhenHLSet(Area)) //kranti
				{    //kranti
		//if access not permitted, request login, then retry validate
			if (TRUE == UserLoggedOn()) {
#ifdef RDL_PAM_ENABLE
				strLog.asprintf(_T(":AuthenticateUserArea...attmpt Logoff begin."));
				LogDebugMessage(strLog);
				#endif

				LogOff();

			}

#ifdef RDL_PAM_ENABLE
			strLog.asprintf(_T("::AuthenticateUserArea...attmpt Logon ."));
			LogDebugMessage(strLog);
			#endif

			switch (LogOn("", "", FALSE, pkParent)) {//validate user area
			case T_PASS_AUTH_ACCESS_GRANTED: {
#ifdef RDL_PAM_ENABLE
					strLog.asprintf(_T("::AUA ValidateAreaNumber %d m_LastUserID %d"), Area, m_LastUserID);
					LogDebugMessage(strLog);
					#endif

				PMMSTATUS PmmRet = m_PIM.ValidateAreaNumber(Area, m_LastUserID, &AreaRes, szMess);

#ifdef RDL_PAM_ENABLE
					strLog.asprintf(_T("::AUA ValidateAreaNumber res %d PmmRet %d"), AreaRes, PmmRet);
					LogDebugMessage(strLog);
					#endif

				if ((CSTATUS_OK == PmmRet) && (TRUE == AreaRes)) {
	//csText = tr("Area Validation Successful. Access Granted");
					//CV6MessageBoxDlg Dlg2(csTitle,csText);
					//Dlg2.exec(); //Do not show the success message (leaving code in for now)
				} else if (CSTATUS_CPWI_INACTIVITY_TIMEOUT == PmmRet) {
	csText = tr("Inactivity Timeout");
					QString   szOK;
	szOK = tr("OK");
					CV6MessageBoxDlg kErrorDlg(csTitle, csText, pkParent, szOK);
					kErrorDlg.exec();

				} else {
	csText = tr("Access Denied to supplied user");
					QString   szOK;
	szOK = tr("OK");
					CV6MessageBoxDlg kErrorDlg(csTitle, csText, pkParent, szOK);
					kErrorDlg.exec();
				}
			}
				break;
			case T_PASS_AUTH_ACCESS_DENIED: {
	csText = tr("Log on Failed. Access Denied");
				QString   strOK("");
	strOK = tr("OK");
				CV6MessageBoxDlg kErrorDlg(csTitle, csText, pkParent, strOK);
				kErrorDlg.exec();
			}
				break;
			default:
				//do nothing if the user cancels
#ifdef RDL_PAM_ENABLE
				strLog.asprintf(_T("::AuthenticateUserArea...attmpt Logon returend to default case ."));
				LogDebugMessage(strLog);
				#endif
				break;
			}
		}
	}

#ifdef RDL_PAM_ENABLE
	strLog.asprintf(_T("::AuthenticateUserArea end area res %d"), AreaRes);
	LogDebugMessage(strLog);
	#endif

#ifdef UNDER_V6APP
	//Resume the Main thread for watchdog as we have come out of blcoking calls
	if(pThreadInfo != NULL)
	{
		pThreadInfo->UpdateThreadInfo(AM_OPPANEL,true);
	}
#endif

	return AreaRes;
}

//****************************************************************************
/// Checks that access to a certain area is unrestricted. 
///
/// @param[in] T_AUTHENTICATION_AREAS Area - Area to be authenticated
/// 
/// @return		BOOL - TRUE If Access to the area is unrestricted
///					  FALSE If Access to the area is restricted
//****************************************************************************
BOOL CPassAuthUI::IsAreaUnRestricted(T_AUTHENTICATION_AREAS Area) {
	TV_BOOL bResult = FALSE;
	bResult = m_PIM.IsAreaUnrestricted(Area);
	return (BOOL) (bResult);
}

//****************************************************************************
/// Prompts the user to Log on with username and password dialogs
///
/// @param QString  csUser[in] - username to log in. empty or default to prompt user
///
/// @param QString  csPass[in] - Password to login with. as above
/// @note leaving either password or username blank will prompt the user for both
///
/// @param TV_BOOL bQuiet[in] - Allows a quiet login with no user notification
/// 
/// @return		T_PASS_AUTH_ACCESS - T_PASS_AUTH_ACCESS_GRANTED Log In sucessful and access allowed
///					  T_PASS_AUTH_ACCESS_DENIED Log in failed and access denied
//****************************************************************************
T_PASS_AUTH_ACCESS CPassAuthUI::LogOn(const QString   csUser, const QString   csPass, const TV_BOOL bQuiet,
		CWidget *pkParent) {
	TV_BOOL PmmCFRMode;
	T_PASS_AUTH_ACCESS Ret = T_PASS_AUTH_ACCESS_DENIED;
	WCHAR szMess[CPWI_MESSAGE_LENGTH] = { 0 };
	WCHAR szUser[USER_MAX_LEN + 1] = { 0 };
	WCHAR szPass[NONCFR_MAX_MAXPASSWORD_LENGTH + 1] = { 0 };
	PMMSTATUS PmmRet = CSTATUS_OK;
	BOOL LoginProceed = FALSE;
#ifdef PWDLOGS_ENABLE
	WCHAR szDbgMsg[512];
#endif
	if (!m_PIM.IsCPWIInitialised()) {
		//need to try to initialise it....
		PmmRet = m_PIM.InitCPWI(CPWI_LOCAL_UI);
	}

	//Fix for PAR - 1-3DVR1C6
	//No need to show or refresh process/non porcess screen if user authentication dialog is being poped up 
	CTopStatusBar *pkStatusBar = CTopStatusBar::Instance();
	BOOL bChangeMode = pkStatusBar->IsTopStatusBarVisble(); // check the status bar is alreday hiden. 
	//If it is hidden no need to do anything here

	if (bChangeMode) {
		//hide process/non process active screen
		pkStatusBar->PostMessage(WM_CHANGE_TOPBAR_MODE, (WPARAM) TOPBAR_MODE_HIDE, NULL);
	}

	if (CSTATUS_OK == PmmRet) {
		m_PIM.GetPMMMode(&PmmCFRMode);
		if (csUser.isEmpty() || csPass.isEmpty()) {
			//set up requirements for SIP
			BUFFERINFO BI;
			OTHERINFO OI;
			BYTE bUpdate;
			BYTE bTimeout;

			//Fix for 1-X9WRK7 Durgaprasad
			//to obtain the chapter and topic for a passwords menu item help ID
			QString   strTopic("");
			QString   strChapter("");
			CHelpLookup::GetGeneralMenuLocation(mhpPwdSetup, strTopic, strChapter);

			CEditPanelDlg::SetupHelpBuffer(&OI.pHelpTopic, &OI.pHelpChapter, strTopic, strChapter);

			glbpCallbackFunction pFunctionPointer = LengthCallbackFunction;

			BI.pBuffer = szUser;			//return string from SIP
			BI.BufferLength = USER_MAX_LEN + 1;
			BI.Limit = USER_MAX_LEN;

			QString   csTmp;
	csTmp = tr("Enter Username");
			wcsncpy(OI.Description, csTmp, sizeof(OI.Description) / sizeof(WCHAR));

			//OI.pHelpTopic = NULL;
			//OI.pHelpChapter = NULL;
			OI.TimeOut = 50000; //standard timeout length
			//username chars obscure if PmmCFRMode == TRUE
			OI.IsPassword = PmmCFRMode;

			//Prompt for user name 
			CAlphaNumEditDlg kAlphaNumEditDlg;
			/*T_PRECPROFILE ptModifiableProfile = pSETUP->GetGeneralSetupConfig()->GetProfileBlock( CONFIG_MODIFIABLE );*/

			if (pSYSTEM_INFO->FWOptionPasswordCFRAvailable() == TRUE) //username
			{
				ENTER_SECURE_ZONE(REC_SEC_ZONE_PWD);
				MaskRecorder();
			}

			if (kAlphaNumEditDlg.ShowIP(&BI, pFunctionPointer, &OI, &bUpdate, &bTimeout) == TRUE) {
				//check if the password is default
				TV_BOOL bDefPass = 65535; // = FALSE;
#ifdef PWDLOGS_ENABLE			
				swprintf( szDbgMsg, L"CPassAuthUI::LogOn GetPwdSts user %s GTC %d\n",szUser, GetTickCount());
				OutputDebugString(szDbgMsg);
#endif
				PMMSTATUS pret = m_PIM.GetPwdSts(QString ::fromWCharArray(szUser), &bDefPass);
#ifdef PWDLOGS_ENABLE			
				swprintf( szDbgMsg, L"CPassAuthUI::LogOn user %s pret %d bDefPass %d GTC %d\n",szUser, pret, bDefPass, GetTickCount());
				OutputDebugString(szDbgMsg);
#endif
				if (TRUE == bDefPass) {
					wcsncpy(szPass, defaultPassword, 9);
					szPass[9] = L'\0';
					LoginProceed = TRUE;
#ifdef PWDLOGS_ENABLE			
					swprintf( szDbgMsg, L"CPassAuthUI::bDefpass=%d GTC %d\n",bDefPass, GetTickCount());
					OutputDebugString(szDbgMsg);
#endif
				} else {
					//prompt for Password(Chars Obscure)
					BI.pBuffer = szPass;
	csTmp = tr("Enter Password");
					wcscpy_s(OI.Description, sizeof(OI.Description) / sizeof(WCHAR), (LPCTSTR) csTmp);
					OI.IsPassword = TRUE;

					if (pSYSTEM_INFO->FWOptionPasswordCFRAvailable() == FALSE)
						ENTER_SECURE_ZONE(REC_SEC_ZONE_PWD);

					MaskRecorder();

					if (kAlphaNumEditDlg.ShowIP(&BI, pFunctionPointer, &OI, &bUpdate, &bTimeout) == TRUE) {
						LoginProceed = TRUE;
					}
#ifdef PWDLOGS_ENABLE			
					swprintf( szDbgMsg, L"CPassAuthUI::LogOn user %s pwd %s GTC %d\n", szUser, szPass, GetTickCount());
					OutputDebugString(szDbgMsg);
#endif

					LEAVE_SECURE_ZONE(REC_SEC_ZONE_SAFE);
					UnMaskRecorder();
				}

				LEAVE_SECURE_ZONE(REC_SEC_ZONE_SAFE);
				UnMaskRecorder();

			}
			LEAVE_SECURE_ZONE(REC_SEC_ZONE_SAFE);
			UnMaskRecorder();

		} else {
			wcsncpy(szUser, reinterpret_cast<const WCHAR*>(csUser.constData()), sizeof(szUser) / sizeof(WCHAR));
			wcsncpy(szPass, reinterpret_cast<const WCHAR*>(csPass.constData()), sizeof(szPass) / sizeof(WCHAR));
			szUser[csUser.length() + 1] = L'\0';
			szPass[csPass.length() + 1] = L'\0';
			LoginProceed = TRUE;
		}
		//Login supplied user if credentials entry sucessful
		PMMSTATUS PmmRet = m_PIM.Login(QString ::fromWCharArray(szUser), QString ::fromWCharArray(szPass),
				(SHORT*) &m_LastUserID, QString ::fromWCharArray(szMess));

#ifdef PWDLOGS_ENABLE			
		swprintf( szDbgMsg, L"CPassAuthUI::LogOn PIM_Login user %s PmmRet %d GTC %d\r\n", szUser, PmmRet, GetTickCount());
		OutputDebugString(szDbgMsg);
#endif
		if (LoginProceed) {
			switch (PmmRet) {

			case CSTATUS_OK:
				if (CPassSyncEngine::IsInstantiated()) {
					CPassSyncEngine *pP2P = CPassSyncEngine::GetHandle();
					T_PASS_SYNC_STATES state = pP2P->GetState();
					if (PASS_STATE_SLAVE_STATE == state || PASS_STATE_MASTER_STATE == state) {
						pP2P->ShowContactingMasterDlg(NULL);
						pP2P->SendPwAttemptSuccess(NULL, (szUser));
						pP2P->HideContactingMasterDlg();
					}

				}
				//fall through expected
			case CSTATUS_BACKDOOR_USER_AUTHENTICATED:
			case CSTATUS_FIRST_TIME_USER_AUTHENTICATED:
				//PmmRet = m_PIM.UpdateLastAccessTime(m_LastUserID);
				Ret = T_PASS_AUTH_ACCESS_GRANTED;
				break;
			case CSTATUS_INVALID_PASSWORD:
				//send expired password info to master if we are a slave in a group
				if (CPassSyncEngine::IsInstantiated()) {
					CPassSyncEngine *pP2P = CPassSyncEngine::GetHandle();
					T_PASS_SYNC_STATES state = pP2P->GetState();
					if (PASS_STATE_SLAVE_STATE == state || PASS_STATE_MASTER_STATE == state) {
						pP2P->ShowContactingMasterDlg(NULL);
						pP2P->SendPwAttemptFail(NULL, (szUser));
						pP2P->HideContactingMasterDlg();
					}
				}
			case CSTATUS_FAIL:
				//standard login failure
				//do nothing and let the calling func handle the failure
				break;
			case CSTATUS_EXPIRY_DAYS_WRN: {
				//get number of days till expiry
				WORD NumDays = 0;
				if (CSTATUS_OK == DaysTillPasswordExpiry((SHORT) m_LastUserID, &NumDays)) {
					QString   csTitle;
	csTitle = tr("Password Expiry Warning");
					QString   csMess;
					csMess.asprintf(IDS_PWDS_EXPIRY_WRN, NumDays);
					QString   csOk;
	csOk = tr("Yes");
					QString   csCancel;
	csCancel = tr("No");

					CV6MessageBoxDlg Dlg(csTitle, csMess, csOk, csCancel, pkParent);

					//no messages if bQuiet is set
					if ((TRUE == bQuiet) || (IDCANCEL == Dlg.exec())) {
						//PmmRet = m_PIM.UpdateLastAccessTime(m_LastUserID);
						Ret = T_PASS_AUTH_ACCESS_GRANTED;
						if (CPassSyncEngine::IsInstantiated()) {
							CPassSyncEngine *pP2P = CPassSyncEngine::GetHandle();
							T_PASS_SYNC_STATES state = pP2P->GetState();
							if (PASS_STATE_SLAVE_STATE == state || PASS_STATE_MASTER_STATE == state) {
								if ( FALSE == bQuiet) {
									pP2P->ShowContactingMasterDlg(NULL);
								}
								pP2P->SendPwAttemptSuccess(NULL, QString  (szUser));
								pP2P->HideContactingMasterDlg();
							}
						}
					} else {
						QString   csNewPass("");
						LogOff();
						if (TRUE == ChangePassword(csNewPass, (szUser), (szPass), pkParent)) {
							Ret = LogOn((szUser), csNewPass, TRUE, pkParent);
						}
					}
				}
				break;
			}
			case CSTATUS_CHANGE_PASSWORD_FOR_LOGIN:
			case CSTATUS_PASSWORD_EXPIRED: {
				//prompt user that password needs changing
				QString   csTitle;
	csTitle = tr("Change Password");
				QString   csBody;
	csBody = tr("Your old password has now expired. Do you wish to change it now?");
				QString   csOk;
	csOk = tr("Yes");
				QString   csCancel;
	csCancel = tr("No");
				QString   csNewPass("");
				QString   csUser(szUser);

				CV6MessageBoxDlg Dlg(csTitle, csBody, csOk, csCancel, pkParent);
				if (FALSE == bQuiet) {
					if (IDOK == Dlg.exec()) {
						if (ChangePassword(csNewPass, csUser, QString  (szPass), pkParent))
							Ret = LogOn(csUser, csNewPass, TRUE, pkParent);
					}
				}
				break;
			}
			case CSTATUS_PASSWORD_LOCKED: {
				//send password attempt failure info to master if we are a slave in a group
				if (CPassSyncEngine::IsInstantiated()) {
					CPassSyncEngine *pP2P = CPassSyncEngine::GetHandle();
					T_PASS_SYNC_STATES state = pP2P->GetState();
					if (PASS_STATE_SLAVE_STATE == state || PASS_STATE_MASTER_STATE == state) {
						if (FALSE == bQuiet) {
							pP2P->ShowContactingMasterDlg(NULL);
						}
						pP2P->SendPwAttemptFail(NULL, (szUser));
						pP2P->HideContactingMasterDlg();
					}
				}

				if (FALSE == bQuiet) {
					QString   csTitle;
	csTitle = tr("Account Locked");
					QString   csBody;
	csBody = tr("This account needs to be reset by an administrator.");
					QString   szOK("");
	szOK = tr("OK");

					CV6MessageBoxDlg Dlg(csTitle, csBody, pkParent, szOK);
					Dlg.exec();
				}
			}
				break;
			case CSTATUS_INVALID_DAY_MASK:
			case CSTATUS_INVALID_LOGIN_TIME:
				if (FALSE == bQuiet) {
					QString   csTitle;
	csTitle = tr("Access Denied to supplied user");
					QString   csBody;
	csBody = tr("This user is not permitted to log in at this time");
					QString   szOK("");
	szOK = tr("OK");

					CV6MessageBoxDlg Dlg(csTitle, csBody, pkParent, szOK);
					Dlg.exec();
				}
				break;
			default:
				if (FALSE == bQuiet) {
					QString   csTitle;
	csTitle = tr("Login Failed");
					QString   csBody;
	csBody = tr("Login has failed: Error Unknown");
					QString   szOK("");
	szOK = tr("OK");

					CV6MessageBoxDlg Dlg(csTitle, csBody, pkParent, szOK);
					Dlg.exec();
				}
				break;
			}
		} else
			Ret = T_PASS_AUTH_ACCESS_CANCELED;

	}

#ifdef PWDLOGS_ENABLE			
		swprintf( szDbgMsg, L"CPassAuthUI::LogOn user %s End Ret %d GTC %d\r\n", szUser, Ret, GetTickCount());
		OutputDebugString(szDbgMsg);
#endif

	//Fix for PAR - 1-3DVR1C6
	//show process/non process active screen
	if (bChangeMode) {
		pkStatusBar->PostMessage(WM_CHANGE_TOPBAR_MODE, (WPARAM) TOPBAR_MODE_SHOW, NULL);
	}

	return Ret;
}
//****************************************************************************
/// Logs the current user off
///
/// @param N/A
/// 
/// @return		TV_BOOL - TRUE Log Off Sucessful
///					  FALSE Log Off failed
//****************************************************************************
TV_BOOL CPassAuthUI::LogOff() {
	TV_BOOL ret = FALSE;
	WCHAR szMess[CPWI_MESSAGE_LENGTH] = { 0 };
	if (INVALID_USER != m_LastUserID) {
		if (CSTATUS_OK == m_PIM.Logoff(m_LastUserID, QString ::fromWCharArray(szMess))) {
			ret = TRUE;
			m_LastUserID = INVALID_USER;
		}
	} else {
		ret = TRUE;
	}
	return ret;
}
//****************************************************************************
/// Prompts the user to change password with username and password dialogs
///
/// @param &csNewPass [in/out] fills a supplied QString  with the new password
/// @param csUser [in - optional] supply the existing username
/// @param csPass [in - optional] supply the validated old password
/// 
/// @return		TV_BOOL - TRUE password change sucessful
///					  FALSE Password change failed
//****************************************************************************
TV_BOOL CPassAuthUI::ChangePassword(QString   &csNewPass, const QString   csUser, const QString   csPass, CWidget *pkParent) {
	CPassSyncEngine *pPwdNetSync = CPassSyncEngine::GetHandle();

#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
		QString  strLog;
		strLog.asprintf(L"CPassAuthUI::ChangePassword...<ENTRY>.");
		pPwdNetSync->LogDebugMessage(strLog);
	#endif

	WCHAR szMess[CPWI_MESSAGE_LENGTH] = { 0 };
	WCHAR szUser[USER_MAX_LEN + 1] = { 0 };
	WCHAR szNewPass[NONCFR_MAX_MAXPASSWORD_LENGTH + 1] = { 0 };
	WCHAR szOldPass[NONCFR_MAX_MAXPASSWORD_LENGTH + 1] = { 0 };
	WCHAR szNewPassChk[NONCFR_MAX_MAXPASSWORD_LENGTH + 1] = { 0 };
	//set up requirements for SIP
	BUFFERINFO BI;
	OTHERINFO OI;
	BYTE bUpdate;
	BYTE bTimeout;
	BOOL ChangeProceed = FALSE;
	/*T_PRECPROFILE ptModifiableProfile = pSETUP->GetGeneralSetupConfig()->GetProfileBlock( CONFIG_MODIFIABLE );*/
#ifdef PWDLOGS_ENABLE
	WCHAR szDbgMsg[512];
#endif
	//Fix for 1-X9WRK7 Durgaprasad
	//to obtain the chapter and topic for a passwords menu item help ID
	QString   strTopic("");
	QString   strChapter("");
	CHelpLookup::GetGeneralMenuLocation(mhpPwdSetup, strTopic, strChapter);

	CEditPanelDlg::SetupHelpBuffer(&OI.pHelpTopic, &OI.pHelpChapter, strTopic, strChapter);

	TV_BOOL Ret = FALSE;
	TV_BOOL PmmCFRMode;
	m_PIM.GetPMMMode(&PmmCFRMode);
	glbpCallbackFunction pFunctionPointer = LengthCallbackFunction;

	BI.BufferLength = USER_MAX_LEN + 1;
	BI.Limit = USER_MAX_LEN;

	QString   csTmp;
	csTmp = tr("Enter Username");
	wcscpy_s(OI.Description, sizeof(OI.Description) / sizeof(WCHAR), (LPCTSTR) csTmp);

	//OI.pHelpTopic = NULL;
	//OI.pHelpChapter = NULL;
	OI.TimeOut = 50000; //standard timeout length

	//Prompt for user name 
	CAlphaNumEditDlg kAlphaNumEditDlg;

	if (csUser.isEmpty() || csPass.isEmpty()) {
		//username chars obscure if PmmCFRMode == TRUE
		BI.pBuffer = szUser; //return string from SIP
		OI.IsPassword = PmmCFRMode;

		ENTER_SECURE_ZONE(REC_SEC_ZONE_PWD);

		MaskRecorder();
		/*if(pGlbSysInfo->GetRemoteUserControl() == TRUE)
		 pDALGLB->SetScreenBrightness(SCRN_BACKLIGHT_OFF);*/

		if (kAlphaNumEditDlg.ShowIP(&BI, pFunctionPointer, &OI, &bUpdate, &bTimeout) == TRUE) {
			LEAVE_SECURE_ZONE(REC_SEC_ZONE_SAFE);
			UnMaskRecorder();

			/*if(pGlbSysInfo->GetRemoteUserControl() == TRUE || pGlbSysInfo->PreviouslyRemoteUserInCntrl() == TRUE)
			 pDALGLB->SetScreenBrightness( ptModifiableProfile->ScreenSaver.NormalBright );*/

			//prompt for Old Password(Chars Obscure)
			BI.pBuffer = szOldPass;
	csTmp = tr("Enter Old Password");
			wcscpy_s(OI.Description, sizeof(OI.Description) / sizeof(WCHAR), csTmp);
			OI.IsPassword = TRUE;

			ENTER_SECURE_ZONE(REC_SEC_ZONE_PWD);

			MaskRecorder();
			/*	if(pGlbSysInfo->GetRemoteUserControl() == TRUE)
			 pDALGLB->SetScreenBrightness(SCRN_BACKLIGHT_OFF);*/

			if (kAlphaNumEditDlg.ShowIP(&BI, pFunctionPointer, &OI, &bUpdate, &bTimeout) == TRUE) {
				ChangeProceed = TRUE;
			}
			LEAVE_SECURE_ZONE(REC_SEC_ZONE_SAFE);
			UnMaskRecorder();

			/*if(pGlbSysInfo->GetRemoteUserControl() == TRUE || pGlbSysInfo->PreviouslyRemoteUserInCntrl() == TRUE)
			 pDALGLB->SetScreenBrightness( ptModifiableProfile->ScreenSaver.NormalBright );*/
		}

		LEAVE_SECURE_ZONE(REC_SEC_ZONE_SAFE);
		UnMaskRecorder();

		/*if(pGlbSysInfo->GetRemoteUserControl() == TRUE || pGlbSysInfo->PreviouslyRemoteUserInCntrl() == TRUE)
		 pDALGLB->SetScreenBrightness( ptModifiableProfile->ScreenSaver.NormalBright );*/
	} else {
		wcsncpy_s(szUser, sizeof(szUser) / sizeof(WCHAR), csUser, csUser.size() + 1);
		wcsncpy_s(szOldPass, sizeof(szOldPass) / sizeof(WCHAR), csPass, csPass.size() + 1);
		ChangeProceed = TRUE;
	}

	if (ChangeProceed) {
		//prompt for New Password(Chars Obscure)
		BI.pBuffer = szNewPass;
	csTmp = tr("Enter new password");
		wcsncpy_s(OI.Description, sizeof(OI.Description) / sizeof(WCHAR), csTmp, csTmp.size() + 1);
		OI.IsPassword = TRUE;
		//reset for next section
		ChangeProceed = FALSE;
		/****/
		ENTER_SECURE_ZONE(REC_SEC_ZONE_PWD);

		MaskRecorder();
		/*if(pGlbSysInfo->GetRemoteUserControl() == TRUE)
		 pDALGLB->SetScreenBrightness(SCRN_BACKLIGHT_OFF);*/

		if (kAlphaNumEditDlg.ShowIP(&BI, pFunctionPointer, &OI, &bUpdate, &bTimeout) == TRUE) {

			if (0 != wcscmp(szNewPass, defaultPassword)) //change for global constant
					{
				if (0 != wcscmp(szNewPass, szUser)) {
					//validate password against policy
					PMMSTATUS PolStat = ValidatePasswordToPolicy(szNewPass);
					switch (PolStat) {
					case CSTATUS_INVALID_PASSWORD: {
						T_PMMPOLICYDATA *pPolicy = new T_PMMPOLICYDATA;
						if (CSTATUS_OK == GetPolicy(pPolicy)) {
							QString   csResult;
							QString   csLocal;
							csLocal.asprintf(IDS_PASS_SYNC_ENGINE_PASSWORD_LENGTH, pPolicy->PwdPolicyData.PwrdMinLen,
									pPolicy->PwdPolicyData.pwrdMaxLen);
							csResult = csLocal;
							if (pPolicy->PwdPolicyData.PwrdAlphabet) {
								csLocal.asprintf(IDS_PASS_SYNC_ENGINE_PASSWORD_LETTER_LENGTH,
										pPolicy->PwdPolicyData.PwrdAlphabet);
								csResult += csLocal;
							}
							if (pPolicy->PwdPolicyData.PwrdNumeric) {
								csLocal.asprintf(IDS_PASS_SYNC_ENGINE_PASSWORD_NUMLENGTH,
										pPolicy->PwdPolicyData.PwrdNumeric);
								csResult += csLocal;
							}
							if (pPolicy->PwdPolicyData.PwrdSplchar) {
								csLocal.asprintf(IDS_PASS_SYNC_ENGINE_PASSWORD_SPECIAL_LENGTH,
										pPolicy->PwdPolicyData.PwrdSplchar);
								csResult += csLocal;
							}
	csTmp = tr("Password failed policy check");
							QString   szOK("");
	szOK = tr("OK");
							CV6MessageBoxDlg MBox(csTmp, csResult, pkParent, szOK);
							MBox.exec();
						}
						delete pPolicy;
					}
						break;
					case CSTATUS_OK: {
						//doublecheck entered new password by asking twice
						BI.pBuffer = szNewPassChk;
	csTmp = tr("Confirm new password");
						wcsncpy_s(OI.Description, sizeof(OI.Description) / sizeof(WCHAR), csTmp, csTmp.size() + 1);

						ENTER_SECURE_ZONE(REC_SEC_ZONE_PWD);

						MaskRecorder();

						/*if(pGlbSysInfo->GetRemoteUserControl() == TRUE)
						 pDALGLB->SetScreenBrightness(SCRN_BACKLIGHT_OFF);*/

						if (kAlphaNumEditDlg.ShowIP(&BI, pFunctionPointer, &OI, &bUpdate, &bTimeout) == TRUE) {
							//compare the 2 attempts
							if (wcscmp(szNewPassChk, szNewPass) != 0) {
								//inform the user that passwords don't match
	csTmp = tr("Password Error");
								QString   csMess;
	csMess = tr("New Password attempts do not match");
								QString   szOK("");
	szOK = tr("OK");
								CV6MessageBoxDlg Dlg2(csTmp, csMess, pkParent, szOK);
								Dlg2.exec();
							} else
								ChangeProceed = TRUE;
						}

						LEAVE_SECURE_ZONE(REC_SEC_ZONE_SAFE);
						UnMaskRecorder();

						/*if(pGlbSysInfo->GetRemoteUserControl() == TRUE || pGlbSysInfo->PreviouslyRemoteUserInCntrl() == TRUE)
						 pDALGLB->SetScreenBrightness( ptModifiableProfile->ScreenSaver.NormalBright );*/
					}
						break;
					case CSTATUS_INVALID_PARAMETER:
					default: {
	csTmp = tr("Password Error");
						QString   csMess;
	csMess = tr("Invalid Password Data");
						QString   szOK("");
	szOK = tr("OK");
						CV6MessageBoxDlg Dlg2(csTmp, csMess, pkParent, szOK);
						Dlg2.exec();
					}
						break;
					}

				} else {
					//Message dissallowing pwd matching username
	csTmp = tr("Password Error");
					QString   csMess;
	csMess = tr("Password cannot match username");
					QString   szOK("");
	szOK = tr("OK");
					CV6MessageBoxDlg Dlg2(csTmp, csMess, pkParent, szOK);
					Dlg2.exec();
				}

			} else {
				//message dissalowing password
	csTmp = tr("Password Error");
				QString   csMess;
	csMess = tr("Re-use of default password not allowed");
				QString   szOK("");
	szOK = tr("OK");
				CV6MessageBoxDlg Dlg2(csTmp, csMess, pkParent, szOK);
				Dlg2.exec();
			}
		}

		LEAVE_SECURE_ZONE(REC_SEC_ZONE_SAFE);
		UnMaskRecorder();

		/*if(pGlbSysInfo->GetRemoteUserControl() == TRUE || pGlbSysInfo->PreviouslyRemoteUserInCntrl() == TRUE)
		 pDALGLB->SetScreenBrightness( ptModifiableProfile->ScreenSaver.NormalBright );*/

	}
	USHORT usTokenReqID = NULL;
	BOOL bMasterToken = FALSE;
	BOOL bGotToken = FALSE;
	QString   DlgTitle("");
	QString   DlgRetryQuestion("");
	QString   DlgConfirmRetry("");
	QString   DlgCancelRetry("");
	DlgTitle = tr("Request Timeout");
	DlgRetryQuestion = tr("Request to Master has timed out, do you wish to retry?");
	DlgConfirmRetry = tr("Retry");
	DlgCancelRetry = tr("Cancel");
//	CPassSyncEngine * pPwdNetSync = CPassSyncEngine::GetHandle();
	bool bMasterSlaveConnectionProblem = false;
	if (ChangeProceed) {
		//try to get a token if we are in a P2P managed mode
		if (CPassSyncEngine::IsInstantiated()) {
			T_PASS_SYNC_STATES state = pPwdNetSync->GetState();
			if (PASS_STATE_SLAVE_STATE == state) {
				pPwdNetSync->ShowContactingMasterDlg(NULL);

				// check we can connect with the master - if we can't then display a warning
				// but proceed anyway
				if (pPwdNetSync->MasterAvailable()) {
					pPwdNetSync->HideContactingMasterDlg();

					BOOL bRetry = TRUE;
					while (bRetry) {
						bRetry = FALSE;
						switch (pPwdNetSync->GetToken(&usTokenReqID, 10000)) {
						case TOKEN_REQD:
						case TOKEN_REQ_TIMEOUT: {
							//request has timed out
							//prompt to retry or finish the request
							CV6MessageBoxDlg Dlg(DlgTitle, DlgRetryQuestion, DlgConfirmRetry, DlgCancelRetry, pkParent);
							INT_PTR ret = Dlg.exec();
							if (IDCANCEL == ret) {
								bMasterSlaveConnectionProblem = true; //ANOOP added
								ChangeProceed = FALSE;
							} else if (IDOK == ret) {

								bRetry = TRUE;
							}
							pPwdNetSync->FinishWithToken(usTokenReqID);
						}
							break;
						case TOKEN_OWNED:
							//token has been obtained
							bGotToken = TRUE;
							break;
						case TOKEN_CONN_UNAVAIL:
							//connection to master failed
							ChangeProceed = FALSE;
							bMasterSlaveConnectionProblem = true;
							break;
						case TOK_ERR:
							//oops, means tokens think we're not slave! - ALERT! ALERT!
							//usTokenReqID will be unchanged
						default:
							break;
						}
					}
				} else {
					pPwdNetSync->HideContactingMasterDlg();

					/* ANOOP <START> commenetd 
					 // the master is not available - allow the user to proceed but inform them that the
					 // password change will be temporary and local to this slave only - once the master
					 // reappears this changed password will be overwritten
					 QString  strTitle( QString   ::fromWCharArray("") );
	strTitle = tr("Connection Problem!!!");
					 QString  strMessage( QString   ::fromWCharArray("") );
	strMessage = tr("Could not connect to master. Check Pwd NetSync setup to resolve this issue. All password changes shall be overwritten once the master is restored.");
					 CV6MessageBoxDlg kWarningDlg( strTitle, strMessage );
					 kWarningDlg.exec();
					 ANOOP <END> commented*/

					bMasterSlaveConnectionProblem = true;
				}

				if (bMasterSlaveConnectionProblem) {
					QString   strTitle("");
	strTitle = tr("Connection Problem!!!");
					QString   strMessage("");
	strMessage = tr("Could not connect to master. Check Pwd NetSync setup to resolve this issue. All password changes shall be overwritten once the master is restored.");
					QString   szOK("");
	szOK = tr("OK");
					CV6MessageBoxDlg kWarningDlg(strTitle, strMessage, pkParent, szOK);
					kWarningDlg.exec();

				}

			} else if (PASS_STATE_MASTER_STATE == state) {
				if (!pPwdNetSync->TransGetToken(NULL, 10000)) {

					QString   szTitle;
	szTitle = tr("Request Timeout");
					QString   szMessage;
					szMessage.asprintf(L"Token request timed out");
					QString   szOK("");
	szOK = tr("OK");

					CV6MessageBoxDlg Dlg(szTitle, szMessage, pkParent, szOK);
					int nRet = Dlg.exec();

					pPwdNetSync->TransFinishWithToken(NULL);
					ChangeProceed = FALSE;
					Ret = FALSE;
				} else {
					bMasterToken = TRUE;
					bGotToken = TRUE;
					ChangeProceed = TRUE;
				}

			}

		}
	}
	SHORT UserID;
	if (ChangeProceed)							//All dialogs completed without cancelling
	{
		HCURSOR oldCurs = SetCursor(AfxGetApp()->LoadStandardCursor(IDC_WAIT));
		PMMSTATUS PmmRet;
		QString   csResult;
		PmmRet = ValidateLogon(szUser, szOldPass, &UserID);
	csTmp = tr("Change Password");
		//get the short ID from the username
		switch (PmmRet) {
		case CSTATUS_EXPIRY_DAYS_WRN:
		case CSTATUS_CHANGE_PASSWORD_FOR_LOGIN:
		case CSTATUS_PASSWORD_EXPIRED:
		case CSTATUS_OK:
			//m_PIM.UpdateLastAccessTime(m_LastUserID);
#ifdef PWDLOGS_ENABLE			
			swprintf( szDbgMsg, L"CPassAuthUI::ChangePassword UserID = %d ,szNewPass = %s ,szOldPass = %s - GTC %d\n",UserID,szNewPass,szOldPass, GetTickCount());
			OutputDebugString(szDbgMsg);
#endif
			PmmRet = SetUserPwd(UserID, szNewPass, szOldPass);
			switch (PmmRet) {
			case CSTATUS_OK: {
				Ret = TRUE;

#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
					strLog.asprintf(L"CPassAuthUI::ChangePassword...ChangeProceed CSTATUS_OK..Before CommitChanges().");
					pPwdNetSync->LogDebugMessage(strLog);
					#endif	

				if (CPassSyncEngine::IsPwdNetSyncRunning()) {
					pPwdNetSync->EnterCommitCS();
				}
				CPwdsCfgMgr *pkMgr = CPwdsCfgMgr::Instance();
				pkMgr->CommitChanges();

				if (CPassSyncEngine::IsPwdNetSyncRunning()) {
					pPwdNetSync->LeaveCommitCS();
				}

#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
					strLog.asprintf(L"CPassAuthUI::ChangePassword...bMasterSlaveConnectionProblem is %d..ChangeProceed CSTATUS_OK..After CommitChanges().",bMasterSlaveConnectionProblem);
					pPwdNetSync->LogDebugMessage(strLog);
					#endif	

				/*<START> ANOOP code added 16/APR */
				if (bMasterSlaveConnectionProblem) {
	csResult = tr("Could not connect to master. Check Pwd NetSync setup to resolve this issue. All password changes shall be overwritten once the master is restored.");
				} else /*<END> ANOOP code added 16/APR */
				{
	csResult = tr("Password Changed Successfully");
				}
				csNewPass = szNewPass;

				// only send an update if within a netsync group
				if (CPassSyncEngine::IsPwdNetSyncRunning()) {
					T_PASS_SYNC_STATES state = CPassSyncEngine::GetHandle()->GetState();
					if (((PASS_STATE_SLAVE_STATE == state) && (!bMasterSlaveConnectionProblem))
							|| (PASS_STATE_MASTER_STATE == state)) {
						if (!pPwdNetSync->SendSinUserMsg(PW_USER_SEND, NULL, QString  (szUser), SIN_USER_CHANGE_PWD,
								(BYTE*) szNewPass, (ULONG) ((wcslen(szNewPass) + 1) * sizeof(WCHAR)))) {
							Ret = FALSE;

	csResult = tr("Could not connect to master. Check Pwd NetSync setup to resolve this issue. All password changes shall be overwritten once the master is restored.");

#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
								strLog.asprintf(L"CPassAuthUI::ChangePassword...Failed to update master with new password.");
								pPwdNetSync->LogDebugMessage(strLog);
								#endif	
						}
					}
				}
			}
				break;
			case CSTATUS_INVALID_PASSWORD: //invalid new password (policy)
			{
				T_PMMPOLICYDATA *pPolicy = new T_PMMPOLICYDATA;
				if (CSTATUS_OK == GetPolicy(pPolicy)) {
					QString   csLocal;
					csLocal.asprintf(IDS_PASS_SYNC_ENGINE_PASSWORD_LENGTH, pPolicy->PwdPolicyData.PwrdMinLen,
							pPolicy->PwdPolicyData.pwrdMaxLen);
					csResult = csLocal;
					if (pPolicy->PwdPolicyData.PwrdAlphabet) {
						csLocal.asprintf(IDS_PASS_SYNC_ENGINE_PASSWORD_LETTER_LENGTH,
								pPolicy->PwdPolicyData.PwrdAlphabet);
						csResult += csLocal;
					}
					if (pPolicy->PwdPolicyData.PwrdNumeric) {
						csLocal.asprintf(IDS_PASS_SYNC_ENGINE_PASSWORD_NUMLENGTH, pPolicy->PwdPolicyData.PwrdNumeric);
						csResult += csLocal;
					}
					if (pPolicy->PwdPolicyData.PwrdSplchar) {
						csLocal.asprintf(IDS_PASS_SYNC_ENGINE_PASSWORD_SPECIAL_LENGTH,
								pPolicy->PwdPolicyData.PwrdSplchar);
						csResult += csLocal;
					}
	csTmp = tr("New Password Invalid. Check the Password policy");
					Ret = FALSE;
				}
				delete pPolicy;
			}
				break;
			case CSTATUS_PASSWORD_IN_HISTORY:
	csResult = tr("You cannot re-use old passwords");
				break;
			case CSTATUS_INVALID_OLD_PASSWORD:
			default:
				csResult.asprintf(IDS_PWDS_CHANGE_OTHER_FAIL, PmmRet);
				break;
			}
			break;
		case CSTATUS_PASSWORD_LOCKED:
			//inform user account needs to be reset
	csResult = tr("This account needs to be reset by an administrator.");
			break;
//		case CSTATUS_PASSWORD_EXPIRED://existing password expired
			//userId needs to be extracted from the username when HTSL write the function
//			if (ResetAccount(UserID,szNewPass,TRUE)==CSTATUS_OK)
//			{
//				CPwdsCfgMgr *pkMgr = CPwdsCfgMgr::Instance();
//				pkMgr->CommitChanges();
//
	//				csResult = tr("Password Changed Successfully");
//				Ret = TRUE;
//			}
//			else
	//				csResult = tr("Invalid New Password");
//			break;
		case CSTATUS_INVALID_PASSWORD:
			csResult = L"Password does not meet policy requirements";
			break;
		case CSTATUS_FAIL:
	csResult = tr("Invalid User/Old Password");
			break;
		default:
			csResult.asprintf(IDS_PWDS_CHG_OTHER_LOGIN_FAIL, PmmRet);
			break;
		}
		if (bGotToken) {
			if (bMasterToken)
				pPwdNetSync->TransFinishWithToken(NULL);
			else
				pPwdNetSync->FinishWithToken(usTokenReqID);
		}
		SetCursor(oldCurs);

		QString   szOK("");
	szOK = tr("OK");

		CV6MessageBoxDlg Dlg(csTmp, csResult, pkParent, szOK);
		if (Dlg.exec() == IDOK) {
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE		
			strLog.asprintf(L"CPassAuthUI::ChangePassword...exec() returned IDOK.");
			pPwdNetSync->LogDebugMessage(strLog);
			#endif	
		}
	}

#ifdef DBG_FILE_LOG_NETSYNC_ENABLE		
		strLog.asprintf(L"CPassAuthUI::ChangePassword...<EXIT>.");
		pPwdNetSync->LogDebugMessage(strLog);
	#endif	
#ifdef PWDLOGS_ENABLE			
	//	T_CONFIG_RETURN_VALUE eRetVal = pPwdSetup->SaveConfiguration(_T("C:\\TV6PC\\intcf\\Pwdconfig.cfg"));
		//T_CONFIG_RETURN_VALUE eRetVal = pPwdSetup->SaveConfiguration(_T("\\SDMemory\\PwdconfigNew.cfg"));
#endif
	return Ret;
}
//****************************************************************************
/// Gets the name string of the currently (or last) logged in user
///
/// @param N/A
/// 
/// @return		TV_BOOL - TRUE last username found and supplied in pName
///					  FALSE Unable to determine username
//****************************************************************************
TV_BOOL CPassAuthUI::GetLoggedInUserName(QString   &csData) {
	TV_BOOL Ret;
	T_USERDATA *pData = new T_USERDATA;
	if (CSTATUS_OK == GetUserById(m_LastUserID, pData)) {
		csData = pData->UsrInfo.Name;
		Ret = TRUE;
	} else
		Ret = FALSE;
	delete pData;
	return Ret;
}

//****************************************************************************
/// Let the PMM know that user activity is taking place
///
/// @param N/A
/// 
/// @return	N/A
//****************************************************************************
void CPassAuthUI::UpdateUserAccess(void) {
	if (INVALID_USER != m_LastUserID) {
		m_PIM.UpdateLastAccessTime(m_LastUserID);
	}
}
//****************************************************************************
/// query if anyone is logged into the system
///
/// @param N/A
/// 
/// @return	TRUE if any user is logged on
//****************************************************************************
BOOL CPassAuthUI::UserLoggedOn(void) {
	LONGLONG time;
	LONGLONG timenow;
	T_PMMPOLICYDATA *pPolicy = new T_PMMPOLICYDATA;
	BOOL ret = FALSE;
	//check against policy
	if (CSTATUS_OK == GetPolicy(pPolicy)) {
		//determine if user is valid
		if ((INVALID_USER != m_LastUserID) && (CSTATUS_OK == m_PIM.GetLastAccessTime(m_LastUserID, &time, &timenow))) {
			//check time difference against policy
			if (pPolicy->GPolicyData.UILogOffTime == 0
					|| (ULONG) ((timenow - time) / SECOND_TO_MILLI_SECONDS)
							<= (ULONG) pPolicy->GPolicyData.UILogOffTime)
				ret = TRUE;
		}

	}
	delete pPolicy;
	return ret;
}
//****************************************************************************
/// query the name of a user only if currently logged on
///
/// @param[out] pstrName - QString  reference that will be filled with user name
/// 
/// @return	TRUE if username retrieved successfully
//****************************************************************************
BOOL CPassAuthUI::GetCurrentUserName(QString   &pstrName) {
	BOOL Ret = FALSE;
	//check the current user is valid
	if (UserLoggedOn()) {
		if (GetLoggedInUserName(pstrName)) {
			Ret = TRUE;
		} else {
			pstrName = "";
		}
	}
	return Ret;
}
//****************************************************************************
/// Test if a security area is unrestricted
///
/// @param[in] Area - T_AUTHENTICATION_AREAS area to be tested
/// @param[in/out] bRes - result of the test - true or false, true if unrestricted
/// 
/// @return	TRUE if the action was successful, regardless of result
//****************************************************************************
BOOL CPassAuthUI::TestAreaUnrestricted(T_AUTHENTICATION_AREAS Area, bool *bRes) {
	BOOL ret = FALSE;

	if (Area != AUTHENTICATION_AREA_NO_AUTH) {
		//test area against permissions
		USHORT usArea = Area;
		usArea--; //make it zero based
		USHORT NumBitsInDword = sizeof(DWORD) * 8;
		//find it's ULONG ofset
		USHORT DwordOfset = usArea / NumBitsInDword;
		USHORT BitMask = 1 << (usArea % NumBitsInDword);

		T_PMMDATA *pPmmData;
		T_PMMPOLICYDATA *pPolicyData;
		if (pPASSWORD->GetWorkingPasswordConfig((BYTE**) &pPmmData, (BYTE**) &pPolicyData) == CONFIG_OK) {
			ret = TRUE;
			//test if the flag is set and therefore unrestricted
			if ((pPmmData->GroupPerm[USER_LEVEL_5][DwordOfset] & BitMask) != 0) {
				*bRes = true;
			}
		}
	}
	return ret;
}

//****************************************************************************
//1) This function does check if the selected area is with in user Authentication list to proceed. 
//2) There is an enum named "T_AUTHENTICATION_AREAS" which is used to set the selected area as secured.
//3) Currently, both Hardware lock and User Authentication mechanism are tightly coupled to control the 
//  areas by Setting the T_AUTHENTICATION_AREAS enum values.
//4) This setting is done while starting of the each respective dialog is created. 
//  There are some areas which requires User Authentication and also need to be allowed though hardware lock is set.
//  As there is tightly coupled mechanism we had to identify a list of areas which requires user Authentication when 
//  hardware lock is set and thus identified accordingly, those areas are listed in this function. When this function 
//  returns true then it meant the area is allowable by prompting user authentication.
//
//For Ex: Menu>>Configure is allowable area when hardware lock is enabled. and in turn the behavior of this Configure 
//area will remains same when password system is enabled or disabled. 
///
/// @param[in] T_AUTHENTICATION_AREAS Area - Area to be authenticated
/// 
/// @return		BOOL - TRUE If Area is in User Login Required List
///					  FALSE If Area is not in User Login Required List
//
//
//1-34F1XKP Hardware Lock issues related to Batch, Export and Report generation etc  
//1-39M2LOF Allow\Disallow the Recorder Menu Areas when Hardware lock is set in recorder.
//**********************************************************************************************
// Revision History
//**********************************************************************************************
// 
//  1  V6 Firmware1	 10/29/2014		Prasad	  
//  
//
//**********************************************************************************************
//****************************************************************************
BOOL CPassAuthUI::IsAreaAllowedWhenHLSet(T_AUTHENTICATION_AREAS Area) {
	BOOL bPassReqArea = FALSE;
	switch (Area) {
	case AUTHENTICATION_AREA_RECORDING:
	case AUTHENTICATION_AREA_COUNTERS:
	case AUTHENTICATION_AREA_MAXMIN:
	case AUTHENTICATION_AREA_TOT:
	case AUTHENTICATION_AREA_SCREEN_CALIB:
	case AUTHENTICATION_AREA_REPORTS_VIEW:
	case AUTHENTICATION_AREA_ALARMS_ACK:
	case AUTHENTICATION_AREA_CONFIGURE:
	case AUTHENTICATION_AREA_BATCH:
		bPassReqArea = TRUE;
		break;
	}
	return bPassReqArea;
}

//**********************************************************************************************
//**********************************************************************************************
// Mask Recorder Screen when Remote User in Safe Zone(Screen Turned OFF)
//**********************************************************************************************
//**********************************************************************************************
void CPassAuthUI::MaskRecorder() {
	if (pGlbSysInfo->GetRemoteUserControl() == TRUE) {
		CURSOR_OFF;
		Glb_MouseOn = 0;
		//pDALGLB->SetScreenBrightness(SCRN_DIMMEST_PC);
	}
}

//**********************************************************************************************
//**********************************************************************************************
// UnMask Recorder Screen when Remote User comes out of Safe Zone(Screen Turned ON)
//**********************************************************************************************
//**********************************************************************************************
void CPassAuthUI::UnMaskRecorder() {
	if (pGlbSysInfo->GetRemoteUserControl() == TRUE || pGlbSysInfo->PreviouslyRemoteUserInCntrl() == TRUE) {

		CURSOR_ON;
		/*Glb_MouseOn = 0;*/
		/*T_PRECPROFILE ptModifiableProfile = pSETUP->GetGeneralSetupConfig()->GetProfileBlock( CONFIG_MODIFIABLE );
		 pDALGLB->SetScreenBrightness( ptModifiableProfile->ScreenSaver.NormalBright );*/

	}
}

#ifdef RDL_PAM_ENABLE
void CPassAuthUI::SetDebugLogger(CDebugFileLogger* pDbgFileLogger)
{
	m_pDebugFileLogger = pDbgFileLogger;
#ifdef RDL_PIM_ENABLE
	m_PIM.SetDebugLogger(m_pDebugFileLogger);
#endif
}

void CPassAuthUI::LogDebugMessage(QString  & strDbgMsg)
{
	if( NULL != m_pDebugFileLogger )
	{
		QString  strDiagMsg;
		strDiagMsg.asprintf(_T("PAM - %s at GTC:%u\r\n"), strDbgMsg, GetTickCount());
		m_pDebugFileLogger->WriteToDebugLogFile(strDiagMsg);
	}
}
#endif

/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Password
/// @n Filename: PWBackCoder.cpp
/// @n Desc:	 Generates and validates the backdoor username and password allowing 
///				 temporary access to recorder if user locked out
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  6 Stability Project 1.1.1.3 7/2/2011 4:59:59 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  5 Stability Project 1.1.1.2 7/1/2011 4:38:42 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  4 Stability Project 1.1.1.1 3/17/2011 3:20:37 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  3 Stability Project 1.1.1.0 2/15/2011 3:03:44 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// ****************************************************************

#include "PWBackCoder.h"

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif

//**********************************************************************
///
/// Generate Backdoor UserName and Password from date and serial number
///
/// @param[in]	serialNumber - Serial Number of Unit 100000 to 999999
/// @param[in]	day - Day of Month, 1- 31
/// @param[in]	month - Month of year, 1 - 12
/// @param[in]	year - Year, 00-99
/// @param[out]	*puser - Generated username in return
/// @param[out]	*ppass - Gneerated password in return

/// @return		Error code if failed, PWBD_OKAY if okay
/// 
//**********************************************************************
USHORT CPWBackCoder::Generate(long serialNumber, USHORT day, USHORT month, USHORT year, TCHAR *puser, TCHAR *ppass) {
	USHORT retVal = PWBD_OKAY;
	TCHAR formatSpec[10];
	// Set up and check date
	if ((retVal = SetDate(day, month, year)) == PWBD_OKAY) {
		// Set-up and check serial number
		if ((retVal = SetSerial(serialNumber)) == PWBD_OKAY) {
			// Generate Username and Passwords
			GenerateUser();
			GeneratePassword();

			// Generate format specifier, then use that to build username
			// note, the format specifier to build correct length depending on PWBD_USER_LEN with leading 0's, will build "%04d"
			swprintf(formatSpec, _T("%%0%dd"), PWBD_USER_LEN);
			swprintf(puser, formatSpec, m_userName);

			// Generate format specifier, then use that to build password
			swprintf(formatSpec, _T("%%0%dd"), PWBD_PASS_LEN);
			swprintf(ppass, formatSpec, m_password);

		}
	}
	return retVal;
}

//**********************************************************************
///
/// Validate Backdoor UserName and Password from date and serial number
///
/// @param[in]	serialNumber - Serial Number of Unit 100000 to 999999
/// @param[in]	day - Day of Month, 1- 31
/// @param[in]	month - Month of year, 1 - 12
/// @param[in]	year - Year, 00-99
/// @param[in]	user - username as long value
/// @param[in]	pass - password as long value

/// @return		Error code if failed, PWBD_OKAY if okay
/// 
//**********************************************************************
USHORT CPWBackCoder::Validate(long serialNumber, USHORT day, USHORT month, USHORT year, long user, long pass) {
	USHORT retVal = PWBD_OKAY;
	// Set up and check date
	if ((retVal = SetDate(day, month, year)) == PWBD_OKAY) {
		// Set-up and check serial number
		if ((retVal = SetSerial(serialNumber)) == PWBD_OKAY) {
			// Generate Username and Passwords
			GenerateUser();
			GeneratePassword();

			// Check if username and password match, report if the don't
			if (m_userName != user)
				retVal = PWBD_VAL_USER_FAILED;
			if (m_password != pass)
				retVal = PWBD_VAL_PASS_FAILED;
		}
	}
	return retVal;
}

#define MAX_DAY		31
#define MAX_MONTH	12
#define MAX_YEAR	99

//**********************************************************************
/// Set and check the date 
///
/// @param[in]	day - Day of Month, 1- 31
/// @param[in]	month - Month of year, 1 - 12
/// @param[in]	year - Year, 00-99
/// @return		Error code if failed, PWBD_OKAY if okay
/// 
//**********************************************************************
USHORT CPWBackCoder::SetDate(USHORT day, USHORT month, USHORT year) {
	// Check for day, month or year out of range, if so report back
	if (day < 1 || day > MAX_DAY)
		return PWBD_ERR_INVALID_DAY;
	if (month < 1 || month > MAX_MONTH)
		return PWBD_ERR_INVALID_MONTH;
	if (year > MAX_YEAR)
		return PWBD_ERR_INVALID_YEAR;

	// Date okay, set internal and report back okay
	m_day = day;
	m_month = month;
	m_year = year;

	return PWBD_OKAY;
}

//**********************************************************************
/// Check and Set serial Number
///
/// @param[in]	serialNumber - Serial Number of Unit 100000 to 999999
///
/// @return		Error code if failed, PWBD_OKAY if okay
/// 
//**********************************************************************
USHORT CPWBackCoder::SetSerial(long serialNumber) {
	// Check serial number os not out of limits, if so report back
	if (serialNumber < PWBD_MIN_SERIAL || serialNumber > PWBD_MAX_SERIAL)
		return PWBD_ERR_INVALID_SERIAL;

	// Seril number okay, set and report back okay
	m_serialNumber = serialNumber;
	return PWBD_OKAY;
}

//**********************************************************************
/// Generate the username code value, set in m_username
/// No parameters
///
/// @return		nothing
/// 
//**********************************************************************
void CPWBackCoder::GenerateUser() {
	long keyVal;
	// Generate keyVal, only generated once so use inline literals
	keyVal = (m_year * 4) + (m_month * 3) + (MAX_DAY - m_day) + (m_serialNumber % 100);

	// Generate username from serialNumber and keyval, limit to max user size
	m_userName = (((PWBD_MAX_SERIAL - m_serialNumber) * keyVal) + keyVal) % (PWBD_USER_MAX + 1);

}

//**********************************************************************
/// Generate the password code value, set in m_password
/// No parameters
///
/// @return		nothing
/// 
//**********************************************************************
void CPWBackCoder::GeneratePassword() {
	long keyVal;
	// Generate keyVal, only generated once so use inline literals
	keyVal = (m_year * 4) + (m_month * 3) + (m_day * 2) + (100 - (m_serialNumber % 100));

	// Generate password from serialNumber and keyval, limit to max user size
	m_password = (((PWBD_MAX_SERIAL - m_serialNumber) * keyVal) + keyVal) % (PWBD_PASS_MAX + 1);
}


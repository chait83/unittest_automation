/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  Media Manager
/// @n Filename:  MediaManager.cpp
/// @n Description: Provides the access point for the media manager
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  36  Aristos  1.30.1.3.1.0 9/19/2011 4:51:12 PM  Hemant(HAIL)  
//  Stability recorder source code (JI Release) updated for WatchDog
//  Timer functionality.
//  35  Stability Project 1.30.1.3 7/2/2011 4:58:43 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  34  Stability Project 1.30.1.2 7/1/2011 4:38:29 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  33  Stability Project 1.30.1.1 3/17/2011 3:20:29 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
// $
//
// Vellaidurai V 2/07/2013  Fixed PAR: 1-2S8AFLX - Need to support csv data export over NAS and provide facility to add data export by batch
//    Fix for Senario : Manual export over NAS failed in some scenario. 
//																  Not all pens get exported over NAS. Export dialog buttons gets greyed out sometime.
// Rajanbabu M  19/07/2013 During recorder bootup, If the device is EZTrend and SD card Credit is disabled then USB detection logic is disabled 
//
//		  Shankar Rao P		24/11/2014		Fix for PAR# 1-3KM3QDH - Minitrend & Multitrend gets Lock up when configured for NAS
// **************************************************************************

#include "dal.h"
#include "V6globals.h"
#include "MediaManager.h"
#include "StringUtils.h"
#include "V6globals.h"
#include "..\Utilities\ping.h"
#ifdef UNDER_CE
#include <msgqueue.h>
#include <pnp.h>
#include <Storemgr.h>
#endif
#include "ThreadInfo.h"
#include "ControlSequencer.h"

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif

#ifdef UNDER_CE
typedef union 
{
 DEVDETAIL tDetail;
 char caPad[ sizeof(DEVDETAIL) + ( MAX_DEVCLASS_NAMELEN * sizeof( WCHAR ) ) ];
} MYDEV;
#endif

CMediaManager *CMediaManager::pInstance = NULL;
QMutex hCreationMutex;

CNotificationThread::T_DEVICE_THREAD_STATE CNotificationThread::ms_eState = dtsINIT;

BOOL CALLBACK EnumProc(HWND hWnd, LPARAM lParam);
QMutex  CMediaManager::m_hCSLogOnFailureChecker;
//PSR Fix for PAR# 1-3KM3QDH - Minitrend & Multitrend gets Lock up when configured for NAS begin

QMutex  CMediaManager::m_hCritical;

//**********************************************************************
/// CMediaManager constructor
//**********************************************************************
CMediaManager::CMediaManager() {
	bInitialised = FALSE;
	m_ThreadState = NT_NOT_STARTED;
	int deviceInitIndex = 0;
	// Set all Data item pointers to NULL
	for (deviceInitIndex = 0; deviceInitIndex < IDS_MAX_DEVICES; deviceInitIndex++) {
		m_DeviceInfo[deviceInitIndex].pDIPCFree = NULL;
	}

	//PSR Fix for PAR# 1-3KM3QDH - Minitrend & Multitrend gets Lock up when configured for NAS begin
	m_hLogOnFailureCheckerThread = NULL; //Logon failed dialog box checker
	m_bLogOnFailureCheckerRunnig = false; //initialize to not running

}

//**********************************************************************
/// CMediaManager destructor
//**********************************************************************
CMediaManager::~CMediaManager() {
	//PSR Fix for PAR# 1-3KM3QDH - Minitrend & Multitrend gets Lock up when configured for NAS begin
	CloseLogOnFailureChecker();
	//deletion of mutex not required
	//PSR Fix for PAR# 1-3KM3QDH - Minitrend & Multitrend gets Lock up when configured for NAS end

	//deletion of mutex not required
	if (m_hDeviceThread != NULL) {
		delete m_hDeviceThread;
		m_hDeviceThread = NULL;
	}
}

//**********************************************************************
/// Get handle on Media Manager singleton
///
/// @return		None
//**********************************************************************
CMediaManager* CMediaManager::GetHandle() {
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;

	if (NULL == pInstance) {

		waitSingleObjectResult = hCreationMutex.tryLock(g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);

		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:
			// Object was signaled
			if (NULL == pInstance) {
				pInstance = new CMediaManager;
			}
			if ( FALSE == hCreationMutex.unlock()) {
				V6WarningMessageBox(NULL, L"Failed to release MediaManager mutex", L"CMediaManager Error", MB_OK);
			} // End of IF

			break;

		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
			V6WarningMessageBox(NULL, L"MediaManager WaitForSingleObject Error", L"CMediaManager Error", MB_OK);
			break;
		}
		// Close the Mutex as no longer required
		//No need to close the mutex in Qt
	}
	return pInstance;
}

//**********************************************************************
/// Initialise media identification system
///
/// @return		None
//**********************************************************************
void CMediaManager::Initialise() {
	m_hCritical.lock();

	if (!bInitialised) {
		bInitialised = TRUE;

		// Create front SD card insrtion counter states
		m_ExtCFState = EXT_CF_STATE_UNINITIALISED;
		m_pNVExtCFInsertions = pNV_VARS->GetBasicVarNVObject(NVV_FRONTCF_INSERTS);
		m_ExtCFInsertions = m_pNVExtCFInsertions->GetFromNV()->value;

		// Setup moniotring for all types, However not all types monitored in thread
		InitialiseDeviceInfo(IDS_INTERNAL_SD, 1);
		InitialiseDeviceInfo(IDS_EXTERNAL_SD, 1);
		m_DeviceInfo[IDS_EXTERNAL_SD].pDIPCFree = reinterpret_cast<CDataItemGeneral*>(pDIT->GetDataItemPtr(DI_GENERAL,
				DI_GENTYPE_GENERAL, DI_GEN_FRONTCF_PC));
		m_DeviceInfo[IDS_EXTERNAL_SD].pDIPCFree->SetValue(0);

		InitialiseDeviceInfo(IDS_FIRST_USB, 1);
		m_DeviceInfo[IDS_FIRST_USB].pDIPCFree = reinterpret_cast<CDataItemGeneral*>(pDIT->GetDataItemPtr(DI_GENERAL,
				DI_GENTYPE_GENERAL, DI_GEN_USB1_PC));
		m_DeviceInfo[IDS_FIRST_USB].pDIPCFree->SetValue(0);

		InitialiseDeviceInfo(IDS_SECOND_USB, 1);
		m_DeviceInfo[IDS_SECOND_USB].pDIPCFree = reinterpret_cast<CDataItemGeneral*>(pDIT->GetDataItemPtr(DI_GENERAL,
				DI_GENTYPE_GENERAL, DI_GEN_USB2_PC));
		m_DeviceInfo[IDS_SECOND_USB].pDIPCFree->SetValue(0);

		CheckDevice(IDS_SHARE, false);

		m_pQueueMonitor = CQMonitor::GetHandle();
		m_pQueueMonitor->Initialise();

		// Start device change notification		
		StartMediaIdentification( TRUE);
	}
	m_hCritical.lock();
}

//**********************************************************************
/// Clean up media notification
///
/// @return		None
//**********************************************************************
BOOL CMediaManager::CleanUp() {
	if (NULL != pInstance) {
		// Stop device change notification
		StartMediaIdentification( FALSE);

		if (m_hDeviceThread != NULL) {
			delete m_hDeviceThread;
			m_hDeviceThread = NULL;
		}

		delete pInstance;
		pInstance = NULL;
	}
	return TRUE;
}

//**********************************************************************
/// Register a front compact flash insertion, this will increment the 
/// NV copy
///
/// @return		None
//**********************************************************************
void CMediaManager::RegisterFrontCompactFlashInsertion() {
	// Valid insertion, increment counter and store back to NV
	m_ExtCFInsertions.ul++;
	m_pNVExtCFInsertions->SetToNV(m_ExtCFInsertions);
}

//***********************************************************************************
/// Request CE device notification monitoring
///
/// @param[in]	state TRUE if monitoring is required, FALSE to cancel monitoring
///
/// @return		None
/// 
//***********************************************************************************
void CMediaManager::StartMediaIdentification(BOOL state) {
	m_Keyboard = FALSE;

	if (state) {
		//Start notifiocation thread
		m_hDeviceThread = AfxBeginThread(&CNotificationThread::ThreadFunc, (void*) this, THREAD_PRIORITY_NORMAL, 0,
				CREATE_SUSPENDED, NULL);

		qDebug("CMediaManager Notification Thread ID: 0x%x, %lu\n", m_hDeviceThread->m_nThreadID,
				m_hDeviceThread->m_nThreadID);

		m_ThreadState = NT_RUNNING;
		m_hDeviceThread->m_bAutoDelete = false;
		m_hDeviceThread->ResumeThread();
	} else if (m_ThreadState == NT_RUNNING) {
		// Stop notification Fred
		m_ThreadState = NT_SHUTDOWN;
		CNotificationThread::ShutdownThread();

		DWORD dwWaitSingleObjectResult = WaitForSingleObject(m_hDeviceThread->m_hThread,
				g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);

		switch (dwWaitSingleObjectResult) {
		case WAIT_OBJECT_0:
			break;

		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
			if (V6_RELEASE == RELEASE_BETA) {
				// log a diagnsotic message 
				QString   strError("");
				strError.asprintf(L"CMediaManager failed to shutdown within timeout period (%u seconds)",
						g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS / 1000);
				LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
				DebugBreak();
			}
			break;
		}

	}
}

//***********************************************************************************
/// Initialise the details for a physical device to be monitored
///
/// @param[in]	device, T_STORAGE_DEVICE type of the device for monitoring
///
/// @return		None
//***********************************************************************************
void CMediaManager::InitialiseDeviceInfo(T_STORAGE_DEVICE device, int tenthsOfASecondToCheck) {
	// Pre build the name of the device for checking
	int length = DEVICE_CHECK_PATH_LENGTH;
    pDALGLB->GetPath((T_STORAGE_PATH) device, QString::fromWCharArray(m_DeviceInfo[device].nameForAvailable),
			sizeof(m_DeviceInfo[device].nameForAvailable) / sizeof(WCHAR), &length);
	wcscat_s(m_DeviceInfo[device].nameForAvailable, sizeof(m_DeviceInfo[device].nameForAvailable) / sizeof(WCHAR),
			L"VOL:");

    pDALGLB->GetPath((T_STORAGE_PATH) device, QString::fromWCharArray(m_DeviceInfo[device].nameForSize),
			sizeof(m_DeviceInfo[device].nameForSize) / sizeof(WCHAR), &length);

	// Cleardown as if device is not inserted
	ClearAsDeviceNotInserted(device);

	m_DeviceInfo[device].reloadCountDown = tenthsOfASecondToCheck;
	m_DeviceInfo[device].countDown = 0;		// Make sure we check the devices immediately
}

//***********************************************************************************
/// Initialise the details for a physical device to be monitored
///
/// @param[in]	device, T_STORAGE_DEVICE type of the device for monitoring
/// @param[in]	tenthsOfASecondToCheck, check drive at this frequency
///
/// @return		None
//***********************************************************************************
void CMediaManager::ClearAsDeviceNotInserted(T_STORAGE_DEVICE device) {
	m_DeviceInfo[device].IsInserted = FALSE;
	m_DeviceInfo[device].totalSize = 0;
	m_DeviceInfo[device].freeSpace = 0;
}

//***********************************************************************************
/// bypass the external device notification message //CR3039
///
/// @param[in]	lpParam, WCHAR
///
/// @return		bool
//***********************************************************************************
bool CMediaManager::CheckExternalDeviceNotification(WCHAR wcaDevName[DEVICE_LENGTH])

{
    QString   strTemp = QString::fromWCharArray(wcaDevName);

    if (strTemp.compare("TCP0:") == 0 || strTemp.compare("IPD0:") == 0 || strTemp.compare("SPI1:") == 0
            || strTemp.compare("HCD1:") == 0 || strTemp.compare("COM6:") == 0
            || strTemp.compare("COM1:") == 0 || strTemp.compare("SIP0:") == 0
            || strTemp.compare("WAM1:") == 0 || strTemp.compare("FEC1") == 0
            || strTemp.compare("NDS0:") == 0 || strTemp.compare("LED1:") == 0
            || strTemp.compare("WAV1:") == 0 || strTemp.compare("DSK2:") == 0
            || strTemp.compare("DSK3:") == 0 || strTemp.compare("DSK4:") == 0
            || strTemp.compare("HID1:") == 0 || strTemp.compare("KBD1:") == 0
            || strTemp.compare("DSK5:") == 0 || strTemp.compare("DSK6:") == 0
            || strTemp.compare("DSK7:") == 0 || strTemp.compare("$bus\\BuiltIn") == 0
            || strTemp.compare("PCMCIA Card Services") == 0 || strTemp.compare("$bus\\BuiltInPhase1") == 0
            || strTemp.compare("LPT1:") == 0 || strTemp.compare("LPT2:")) {
		return true;
	}

	return false;
}

//***********************************************************************************
/// Check the device 
///
/// @param[in]	device, T_STORAGE_DEVICE type of the device for monitoring
///	@param[in]	const bool bDEVICE_REMOVED - Flag indicating if the device has just been
///				removed or connected
///
/// @return		None
//***********************************************************************************
void CMediaManager::CheckDevice(T_STORAGE_DEVICE device, const bool bDEVICE_REMOVED) {
	if (bDEVICE_REMOVED) {
		ClearAsDeviceNotInserted(device);		// Device not inserted

		// Inform the queue monitor that the storage device has been removed
		switch (device) {
		case IDS_INTERNAL_SD:
		case IDS_FTP:
			m_pQueueMonitor->LogDeviceRemoved(LOGDEV_FTP);
			break;
		case IDS_EXTERNAL_SD:
			m_pQueueMonitor->LogDeviceRemoved(LOGDEV_EXT_SD);
			break;
		case IDS_FIRST_USB:
			m_pQueueMonitor->LogDeviceRemoved(LOGDEV_USB1);
			break;
		case IDS_SECOND_USB:
			m_pQueueMonitor->LogDeviceRemoved(LOGDEV_USB2);
			break;
		case IDS_SHARE:
			m_pQueueMonitor->LogDeviceRemoved(LOGDEV_SHARE);
			break;
		}

		// Cleardown the percentage full if removed
		if (m_DeviceInfo[device].pDIPCFree != NULL) {
			m_DeviceInfo[device].pDIPCFree->SetValue(0);
		}

	} else {
		// Device is Fitted
		m_DeviceInfo[device].IsInserted = TRUE;

		if (device != IDS_SHARE) {
			// Get totals drice space and drive sopace available
			ULARGE_INTEGER TotalFreeBytes;
			ULARGE_INTEGER TotalBytes;
			if (GetDiskFreeSpaceEx(m_DeviceInfo[device].nameForSize, NULL, &TotalBytes, &TotalFreeBytes)) {
				m_DeviceInfo[device].totalSize = static_cast<ULONG>(BYTE_TO_KB(TotalBytes.QuadPart));// Set total space on drive (in K)
				m_DeviceInfo[device].freeSpace = static_cast<ULONG>(BYTE_TO_KB(TotalFreeBytes.QuadPart));// Set space available on drive (in K)
				// Calculate the %age free for a device if the data item exists (for Front SD, USB1 and USB2)
				if (m_DeviceInfo[device].pDIPCFree != NULL) {
					float percentageFree = (float) m_DeviceInfo[device].freeSpace
							/ (float) m_DeviceInfo[device].totalSize * 100;
					m_DeviceInfo[device].pDIPCFree->SetValue(percentageFree);
				}
			} else {
				DWORD dwError = GetLastError();
				QString   strError("");
				strError.asprintf(L"GetDiskFreeSpace Failed Device: %d, Error code %d", device, dwError);
				LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
			}
		} else {
			// just set some abitrary limit as we can't actually determine the freespace on a network drive
			m_DeviceInfo[device].totalSize = 100000;
			m_DeviceInfo[device].freeSpace = 100000;
		}
	}
}

//PSR Fix for PAR# 1-3KM3QDH - Minitrend & Multitrend gets Lock up when configured for NAS begin
bool CMediaManager::RunLogOnFailureChecker() {
	bool bIsRunning = IsLogOnFailureCheckerRunning();

	if (false == bIsRunning) {
		//This atomic operation to set the state of the LogOnFailureCheckers
		m_hCSLogOnFailureChecker.lock();
		bIsRunning = m_bLogOnFailureCheckerRunnig = true;
		m_hCSLogOnFailureChecker.lock();

        /// TODO Find alternative to AFxbeginThread
		if (NULL == m_hLogOnFailureCheckerThread) {
			m_hLogOnFailureCheckerThread = AfxBeginThread(LogOnFailureCheckerThread, this);
		}
	}

	return bIsRunning;
}

bool CMediaManager::CloseLogOnFailureChecker() {
	bool bIsRunning = IsLogOnFailureCheckerRunning();

	if (true == bIsRunning) {
		//This atomic operation to set the state of the LogOnFailureChecker
		m_hCSLogOnFailureChecker.lock();
		bIsRunning = m_bLogOnFailureCheckerRunnig = false;
		m_hCSLogOnFailureChecker.lock();

		if (NULL != m_hLogOnFailureCheckerThread) {
			WaitForThread(m_hLogOnFailureCheckerThread->m_hThread);
			m_hLogOnFailureCheckerThread = NULL;
		}
	}

	return bIsRunning;
}

bool CMediaManager::IsLogOnFailureCheckerRunning() {
	bool bReturn = FALSE;
	m_hCSLogOnFailureChecker.lock();
	bReturn = m_bLogOnFailureCheckerRunnig;
	m_hCSLogOnFailureChecker.lock();

	return bReturn;
}

//****************************************************************************
///****************************************************************************
// DWORD AuthenticationDlgChecksForLNFailed(LPVOID pParam)
/// Gets the window handle for the "Logon to Network Server" and launch the keyboard if window handle is find.
//****************************************************************************
UINT CMediaManager::LogOnFailureCheckerThread(LPVOID pParam) {
	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter after each iteration
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();

#ifdef THREAD_ID_SERIAL_LOG
	  WCHAR szDbgMsg[512];
		swprintf( szDbgMsg, L"CMediaManager::LogOnFailureCheckerThread-Thread id 0x%x, %lu ", GetThreadId(GetCurrentThread()), GetThreadId(GetCurrentThread()));
		OutputDebugString(szDbgMsg);
#endif

	if (pThreadInfo != NULL) {
		//Notify the WatchdogTimer that the LogOnFailureCheckerThread has started
		pThreadInfo->UpdateThreadInfo(AM_LOGON_FAILURE_CHECKER_THREAD, true);
		pThreadInfo->UpdateThreadCounter(AM_LOGON_FAILURE_CHECKER_THREAD);
        LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_INFO, "LogOnFailureCheckerThread Started");
	}
	CMediaManager *pManager = (CMediaManager*) pParam;
	while ((pManager != NULL) && (true == pManager->IsLogOnFailureCheckerRunning())) {
        sleep(1000);
		HWND hindexOfWindowDlgLNFailed = NULL;  //Handle for the Logon to Network Server window
        hindexOfWindowDlgLNFailed = ::indexOfWindow(NULL, ("Logon failed");
		if (pThreadInfo != NULL) {
			//Notify the WatchdogTimer that the LogOnFailureCheckerThread has started
			pThreadInfo->UpdateThreadCounter(AM_LOGON_FAILURE_CHECKER_THREAD);
			//LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_ERROR,"CMediaManager::LogOnFailureCheckerThread-2");
		}

		if (hindexOfWindowDlgLNFailed != NULL) {	//Closing the logon messages instead of popup the key board. 
			::PostMessage(hindexOfWindowDlgLNFailed, WM_CLOSE, 0, 0);
			//LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_ERROR,"CMediaManager::LogOnFailureCheckerThread-2_1");
		}
        sleep(10);
		HWND hindexOfWindowDlgLNSFailed = NULL; //Handle for the Logon to Network Server Failed window
        hindexOfWindowDlgLNSFailed = ::indexOfWindow(NULL, ("Logon to Network Server");

		if (pThreadInfo != NULL) {
			//Notify the WatchdogTimer that the LogOnFailureCheckerThread has started
			pThreadInfo->UpdateThreadCounter(AM_LOGON_FAILURE_CHECKER_THREAD);
			//LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_ERROR,"CMediaManager::LogOnFailureCheckerThread-3");
		}

		if (hindexOfWindowDlgLNSFailed != NULL) {
			//Closing the logon messages instead of popup the key board. 
			::PostMessage(hindexOfWindowDlgLNSFailed, WM_CLOSE, 0, 0);
			//LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_ERROR,"CMediaManager::LogOnFailureCheckerThread-3_1");
		}

        sleep(10);
		HWND hindexOfWindowDlgECNFailed = NULL; //Handle for the Logon to Network Server Failed window		

        hindexOfWindowDlgECNFailed = ::indexOfWindow(NULL, ("Windows Embedded Compact Networking");

		if (pThreadInfo != NULL) {
			//Notify the WatchdogTimer that the LogOnFailureCheckerThread has started
			pThreadInfo->UpdateThreadCounter(AM_LOGON_FAILURE_CHECKER_THREAD);
			//LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_ERROR,"CMediaManager::LogOnFailureCheckerThread-4");
		}

		if (hindexOfWindowDlgECNFailed != NULL) {
			//Closing the logon messages instead of popup the key board. 
			::PostMessage(hindexOfWindowDlgECNFailed, WM_CLOSE, 0, 0);
			//LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_ERROR,"CMediaManager::LogOnFailureCheckerThread-4_1");
		}
		if (pThreadInfo != NULL) {
			//Notify the WatchdogTimer that the LogOnFailureCheckerThread has started
			pThreadInfo->UpdateThreadCounter(AM_LOGON_FAILURE_CHECKER_THREAD);
			//LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_ERROR,"CMediaManager::LogOnFailureCheckerThread-5");
		}

        sleep(10);
		HWND hindexOfWindowPrintCEEval = NULL; //Handle for the Logon to Network Server Failed window		

        hindexOfWindowPrintCEEval = ::indexOfWindow(NULL, ("Print CE Evaluation");

		if (pThreadInfo != NULL) {
			//Notify the WatchdogTimer that the LogOnFailureCheckerThread has started
			pThreadInfo->UpdateThreadCounter(AM_LOGON_FAILURE_CHECKER_THREAD);
			//LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_ERROR,"CMediaManager::LogOnFailureCheckerThread-4");
		}

		if (hindexOfWindowPrintCEEval != NULL) {
			//Closing the logon messages instead of popup the key board. 
			//::PostMessage(hindexOfWindowPrintCEEval, WM_CLOSE, 0, 0);
			//LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_ERROR,"Print CE Evaluation found");
			::PostMessage(hindexOfWindowPrintCEEval, WM_COMMAND, IDOK, 0);
			//LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_ERROR,"Print CE Evaluation passed");
		}

		if (pThreadInfo != NULL) {
			//Notify the WatchdogTimer that the LogOnFailureCheckerThread has started
			pThreadInfo->UpdateThreadCounter(AM_LOGON_FAILURE_CHECKER_THREAD);
			//LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_ERROR,"CMediaManager::LogOnFailureCheckerThread-5");
		}
	}
	return 0;
}

void CMediaManager::WaitForThread(HANDLE &handle) {
	// Wait for Single Object for five seconds.
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;
	waitSingleObjectResult = handle.tryLock(5000);

	// Check for the exit code.
	DWORD dwExitCode;
	switch (waitSingleObjectResult) {
	case WAIT_OBJECT_0:
		break;

	case WAIT_TIMEOUT:
	case WAIT_ABANDONED:
	case WAIT_FAILED:
	default:
		// Terminate the Thread.
		GetExitCodeThread(handle, &dwExitCode);
		TerminateThread(handle, dwExitCode);
		break;

	} // End of SWITCH 
}

//PSR Fix for PAR# 1-3KM3QDH - Minitrend & Multitrend gets Lock up when configured for NAS end

//**********************************************************************
/// CNotificationThread constructor
//**********************************************************************
CNotificationThread::CNotificationThread()
{
}

//**********************************************************************
/// CNotificationThread destructor
//**********************************************************************
CNotificationThread::~CNotificationThread() {
}

//****************************************************************************
/// device notification thread : message processing
///


//****************************************************************************
// void ShutdownThread( )
///
/// Method that signals to the thread we are shutting down
///
//****************************************************************************
void CNotificationThread::ShutdownThread()
{
	ms_eState = dtsSHUTDOWN;
}

//****************************************************************************
// const bool CheckDeviceChanges( HANDLE hQueue )
///
/// Method that checks the device change messages
///
//*************************************************************************
const bool CNotificationThread::CheckDeviceChanges(HANDLE hQueue) {
	bool bOK = true;

#ifdef UNDER_CE
	MYDEV tDeviceDetail;
	DWORD dwFlags;
	DWORD dwSize;
	int iMessages = 0;

	BOOL bEnableExtSD = TRUE; // true for all recorders except EzTrend where it is Credit based...
    static QString pwcINTERNAL_CF_NAME = QString::fromWCharArray(pDALGLB->GetVolumeName( SD_INTERNAL_SD, NULL, 0 ));
    static QString pwcEXTERNAL_CF_NAME = QString::fromWCharArray(pDALGLB->GetVolumeName( SD_EXTERNAL_SD, NULL, 0 ));
    static QString pwcUSB1_NAME = QString::fromWCharArray(pDALGLB->GetVolumeName( SD_USB1, NULL, 0 ));
    static QString pwcUSB2_NAME = QString::fromWCharArray(pDALGLB->GetVolumeName( SD_USB2, NULL, 0 ));

	static CMediaManager *pMediaManager = CMediaManager::GetHandle();

	T_STORAGE_DEVICE eDev = IDS_INTERNAL_SD;

	SetLastError(0);

	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//of the Notification thread
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();


	while( ReadMsgQueue( hQueue, &tDeviceDetail, sizeof( tDeviceDetail ), &dwSize, 10, &dwFlags) == TRUE )
	{
		if(pThreadInfo != NULL)
		{
			//Update the Thread Counter for the Notification
			//thread 
			pThreadInfo->UpdateThreadCounter(AM_NOTIFICATION);
		}
		
		qDebug("Device notification: %s, %d \n", tDeviceDetail.tDetail.szName, tDeviceDetail.tDetail.fAttached);

		bool bexternalDeviceMsg = false;
        QString  strInfo( "" );
        QString  strAttached( "" );
		bool bAttached = true;
		if( tDeviceDetail.tDetail.fAttached )
		{
             strAttached = "appeared";
			 bAttached = true;
		}
		else
		{
            strAttached = "was removed";
			bAttached = false;
		}

		strInfo.asprintf( L"Device Details: %s %s", tDeviceDetail.tDetail.szName, strAttached );
		qDebug( strInfo + L"\n");

		//EnumWindows(EnumProc, 0);

		// copy the string and add a \\ as the volume name includs this
		WCHAR wcaDevName[ MAX_DEVCLASS_NAMELEN + 1 ];
		memset( wcaDevName, 0, MAX_DEVCLASS_NAMELEN + 1);
		CStringUtils::SafeWcsCpy( wcaDevName, tDeviceDetail.tDetail.szName, MAX_DEVCLASS_NAMELEN );		

		wcsncat( wcaDevName, MAX_DEVCLASS_NAMELEN + 1 , L"\\", 2 );

			QString   	strDevName = (LPCWSTR) tDeviceDetail.tDetail.szName;
		// find out which device has changed
		if( wcscmp( wcaDevName, pwcINTERNAL_CF_NAME ) == 0 	|| 
            strDevName.compare("DSK1:") == 0)
		{
			eDev = IDS_INTERNAL_SD;
		}
		else if( wcscmp( wcaDevName, pwcEXTERNAL_CF_NAME +1 ) == 0 )
		{
			eDev = IDS_EXTERNAL_SD;

			if ( pGlbDal->IsRecorderEzTrend() && !pGlbSysInfo->FWOptionExtSDAvailable() )
				bEnableExtSD = FALSE;

			if ( bEnableExtSD )
			{
				if( bAttached )
				{
					// Card is currently in slot, determine if this was the first insertion
					if( pMediaManager->GetFrontCompactFlashState() == EXT_CF_STATE_OUT )
					{
						// Valid insertion, register for life history statistics
						pMediaManager->RegisterFrontCompactFlashInsertion();
					}
					pMediaManager->SetFrontCompactFlashState( EXT_CF_STATE_INSERTED );		// Register front SD inserted
				}
				else
				{
					pMediaManager->SetFrontCompactFlashState( EXT_CF_STATE_OUT );			// Register front SD out
				}
			}
		}
        else if( wcscmp( wcaDevName, pwcUSB1_NAME + 1) == 0 ) //|| strDevName.compare("DSK3:") == 0 ) // Rahul wcaDevName = HardDisk\ for 1st USB
		{

			eDev = IDS_FIRST_USB;
		}
        else if( wcscmp( wcaDevName, pwcUSB2_NAME + 1 ) == 0 ) //|| strDevName.compare("DSK4:") == 0 )
		{
			eDev = IDS_SECOND_USB;
		}
		else
		{ //CR3039
			if(pMediaManager->CheckExternalDeviceNotification(tDeviceDetail.tDetail.szName))
			{
			
				bexternalDeviceMsg = true;
			}
			else
			{
				bexternalDeviceMsg = false;
				
				eDev = IDS_MAX_DEVICES;
			}
			//CR3039
		}

		// check the relevant device
		if(( eDev != IDS_MAX_DEVICES ) && (!bexternalDeviceMsg))
		{
			// check the internal SD has not been removed
			if( ( eDev != IDS_INTERNAL_SD ) || bAttached )
			{
				// If Recorder is EzTrend and ExtSD credits are not avaialable do not enable Ext SD....
				if ( bEnableExtSD )
				{
					pMediaManager->CheckDevice( eDev, !bAttached );
				}
				//When SD card credit is disabled, above call will not be executed to enable atleast USB.
				//In this case,By default External USB should be enabled for EZTrend recorder.
				else
				{
					if( eDev == IDS_FIRST_USB)
					{
						pMediaManager->CheckDevice( IDS_FIRST_USB, !bAttached );
					}
				}
			}
			else
			{
				// the internal SD has been removed which is potentially fatal

				// log a diagnostic error message too
				LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_ERROR, 
										L"CRITICAL ERROR - The internal SD card has been unmounted/removed" );

				V6CriticalMessageBox(	NULL, 
										L"The internal SD card has been unmounted/removed.", 
										L"Storage Error", 
										MB_OK | MB_TOPMOST );
			}
		}
		else if(!bexternalDeviceMsg)
		{
			// unkown device attached
            LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_WARNING, "Unknown external drive attached" );
		}

		// increment the number of messages read
		++iMessages;
	}

	// check there was at least one message - if not then get the last error
	if( ( iMessages < 1 ) && ( ms_eState != dtsSHUTDOWN ) )
	{
		// check for error number 1460 which seems to occur quite frequently but doesn't necessarily mean a
		// problem
		if( GetLastError() != ERROR_TIMEOUT )
		{
            QString  strError( "" );
			strError.asprintf( L"CNotificationThread::CheckDeviceChanges - ReadMsgQueue E(%d)", GetLastError() );
			LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_ERROR, strError );

			bOK = false;
		}
	}
#endif
	return bOK;
}

//***********************************************************************************
/// Thread function for message processing
///
/// @param[in]	lpParam, pointer to the CMediaManager singleton
///
/// @return		std ThreadFunc
//***********************************************************************************
UINT CNotificationThread::ThreadFunc(LPVOID lpParam) {
#ifdef DBG_THREADID_INFO
	WCHAR strMsg[MAX_PATH] = { 0 };
	swprintf(strMsg, L"CNotificationThread TID: 0x%x, %lu ", GetThreadId(GetCurrentThread()), GetThreadId(GetCurrentThread()) );
	LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_INFORMATION,strMsg);
#endif

#ifdef THREAD_ID_SERIAL_LOG
	  WCHAR szDbgMsg[512];
		swprintf( szDbgMsg, L"CNotificationThread::ThreadFunc-Thread id 0x%x, %lu ", GetThreadId(GetCurrentThread()), GetThreadId(GetCurrentThread()));
		OutputDebugString(szDbgMsg);
#endif

	CMediaManager *pkMediaManager = CMediaManager::GetHandle();
	UINT uiRetVal = 0;

#ifdef UNDER_CE
	//// Open up these folders in winCE as well. as we are currently running desktop code on ce device
	//	pkMediaManager->CheckDevice( IDS_INTERNAL_SD, false );
	//	pkMediaManager->CheckDevice( IDS_EXTERNAL_SD, false );
	//pkMediaManager->CheckDevice( IDS_FIRST_USB, false );
	//pkMediaManager->CheckDevice( IDS_SECOND_USB, false );

	//GUID guid = FATFS_MOUNT_GUID;

	// GUID kept as zero for capturing the Printer LPT1 port notification.
GUID guid = {0};

HANDLE hQueue = NULL;
HANDLE hNotifications = NULL;
MSGQUEUEOPTIONS msgopts;

msgopts.dwFlags = MSGQUEUE_NOPRECOMMIT;
msgopts.dwMaxMessages = 0; //?
msgopts.cbMaxMessage = sizeof(MYDEV);
msgopts.bReadAccess = TRUE;
msgopts.dwSize = sizeof( MSGQUEUEOPTIONS );

//Get Handle of the class CThreadInfo.
//The handle is used to update the thread counter
//after each iteration
CThreadInfo *pThreadInfo  = CThreadInfo::GetHandle();

if(pThreadInfo != NULL)
{
    //Notify the WatchdogTimer that the Notification thread has
    //started
    pThreadInfo->UpdateThreadInfo(AM_NOTIFICATION,true);
}

// make tyhis section a loop - thims means of the thread should drop out due to an error then
// we can still reinitialise it
while ( ms_eState != dtsSHUTDOWN )
{
    hQueue = CreateMsgQueue(NULL, &msgopts);

    //qDebug((L"Created message queue, h = %08X\n", hq);
    if (hQueue != 0)
    {
        hNotifications = RequestDeviceNotifications(&guid, hQueue, TRUE);

        //qDebug((L"Registered for notifications, h = %08X\n", hn);

        CheckDeviceChanges(hQueue);

        //qDebug((L"Completed initial notification pass.\n");
        bool bFailed = false;

        // do whatever
        while ( ( ms_eState != dtsSHUTDOWN ) && ( !bFailed ) )
        {

            if(pThreadInfo != NULL)
            {
                //Ignore the Notification thread for WatchDog
                //thread until the wait is complete
                pThreadInfo->UpdateThreadInfo(AM_NOTIFICATION,false);
            }

            switch( WaitForSingleObject( hQueue, g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS ) )
            {
                //Consider the Notification thread for WatchDog
                //thread after the wait is complete
                pThreadInfo->UpdateThreadInfo(AM_NOTIFICATION,true);

               case WAIT_OBJECT_0 :
                    bFailed = !CheckDeviceChanges( hQueue );
                break;
                case WAIT_TIMEOUT:
                    // no devices inserted/removed in the timeout period wihch is quite normal
                    break;
                case WAIT_ABANDONED:
                    LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_ERROR, "CNotificationThread WaitForSingleObject Abandoned" );
                    break;
                case WAIT_FAILED:
                    LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_ERROR, "CNotificationThread WaitForSingleObject Failed" );
                    break;
                default:
                    LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_ERROR, "CNotificationThread WaitForSingleObject Error" );
                break;
            }
            // if in the init state then make sure we set it to running now as the devices will have
            // been setup by this point
            if( ms_eState == dtsINIT )
            {
                ms_eState = dtsRUNNING;
            }

            if(pThreadInfo != NULL)
            {
                //Update the Thread Counter for the Notification
                //thread
                pThreadInfo->UpdateThreadCounter(AM_NOTIFICATION);
            }
        }

        CheckDeviceChanges( hQueue );

        StopDeviceNotifications(hNotifications);

        CloseMsgQueue( hQueue );

        qDebug((L"CMediaManager Notification Thread Closed.\n" );
    }
    else
    {
        V6WarningMessageBox( NULL, L"Failed to create notifcation message queue", L"CNotificationThread Error", MB_OK | MB_TOPMOST );
        uiRetVal = 0xFFFFFFFF;
    }

    // check the reason the thread is exiting
    if( ms_eState != dtsSHUTDOWN )
    {

        if(pThreadInfo != NULL)
        {
            //Update the Thread Counter for the Notification
            //thread after each iteration
            pThreadInfo->UpdateThreadCounter(AM_NOTIFICATION);
        }

        // The thread has experienced a problem
        // wait 1 second before attempting any kind of reinitialisation
        sleep( 1000 );

        // Log an error message as this should not really happen
        if( V6_RELEASE != RELEASE_PRODUCTION )
        {
            LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_ERROR, "Media Notification thread has encountered a problem - restarting" );
        }
        else
        {
            LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_WARNING, "Media Notification thread has encountered a problem - restarting" );
        }
    }
}
if(pThreadInfo != NULL)
{
    //Update the info that the Notification thread is exiting
    //Hence this thread need not be considered to kick the
    //watchdog
    pThreadInfo->UpdateThreadInfo(AM_NOTIFICATION,false);
}
#else

    pkMediaManager->CheckDevice( IDS_INTERNAL_SD, false );
    pkMediaManager->CheckDevice( IDS_EXTERNAL_SD, false );
    pkMediaManager->CheckDevice( IDS_FIRST_USB, false );
    pkMediaManager->CheckDevice( IDS_SECOND_USB, false );

#endif
return uiRetVal;
}


BOOL CALLBACK EnumProc(HWND hWnd, LPARAM lParam)
{
TCHAR title[500];
ZeroMemory(title, sizeof(title));

//string strTitle;
GetWindowText(hWnd, title, sizeof(title)/sizeof(title[0]));

//strTitle += title; // Convert to std::string
if(_tcsstr(title, _T("Unidentified USB Device")))
{
    ::SendMessage(hWnd, WM_CLOSE, 0, 0);
    qDebug("Close the window ..Unidentified USB Device");
    return FALSE;
}

return TRUE;
}

LONG CMediaManager::CheckSharedFolder()
{
EnterCriticalSection( &m_hCritical );
LONG bError = 0;
CCommsSetupConfig *pkCommsConfig = pGlbSetup->GetCommsSetupConfig();
if( pkCommsConfig != NULL )
{
    // Test the connection to the network share
    T_PCOMMUNICATIONS pCommunications = NULL;
    pCommunications = pkCommsConfig->GetCommsBlock( CONFIG_COMMITTED );
    T_LANINFO *ptLanInfo = &pCommunications->LanInfo;

    CString strSharePath( L"" ),strServerName("");
    strSharePath.Format( L"%s", ptLanInfo->sharePath );

    strServerName = strSharePath;
    strServerName.TrimLeft(_T("\\"));
    strServerName = strServerName.Left(strServerName.FindOneOf(_T("\\")));
    if( (CControlSequencer::checkIfNetworkAvailable()) && (IsServerRunning(strServerName)) )
    {
        // Server is running...
        if(  ptLanInfo->UseShare )
        {

            // test the network share
            CStorageNC kTest; //CStorage kTest;// NP: changed class here

            CString strTestFilename( L"" );
            strTestFilename.Format( L"%s\\ShareTestFile%ul.txt", ptLanInfo->sharePath,GetTickCount() ); // gettickcount()

            //PSR Fix for PAR# 1-3KM3QDH - Minitrend & Multitrend gets Lock up when configured for NAS begin
            RunLogOnFailureChecker();
            //PSR Fix for PAR# 1-3KM3QDH - Minitrend & Multitrend gets Lock up when configured for NAS end

            CFileException kEx;
            if( !kTest.Open( strTestFilename, CStorageNC::modeCreate | CStorageNC::modeWrite, &kEx ) )
            {
                // Path is not accessible...
                bError = kEx.m_lOsError;
            }
            else
            {
                // Path is shared and accessible...
                kTest.Close();
                DeleteFile( strTestFilename );
            }
        }
    }
    else
    {
        bError = 1;	// Server Not Running...
    }

}
LeaveCriticalSection( &m_hCritical );
return bError;
}
// Ping to given server...
// Returns TRUE if Server is accessible else return FALSE
BOOL CMediaManager::IsServerRunning(LPCTSTR pszHostName)
{
BOOL bRunning = TRUE;
#ifndef UNDER_CE
    return TRUE;
#endif
#ifndef V6IOTEST
CPing objPing;
objPing.Initialise();
//CPingReply pr;
int nErrCode = 0;
bRunning = objPing.Ping1(pszHostName , nErrCode);//,pr);
#endif

/* if(nErrCode )
{
    LPVOID lpMsgBuf;
    LPVOID lpDisplayBuf;

    DWORD  dw = WSAGetLastError();
    FormatMessage(
    FORMAT_MESSAGE_ALLOCATE_BUFFER |
    FORMAT_MESSAGE_FROM_SYSTEM |
    FORMAT_MESSAGE_IGNORE_INSERTS,
    NULL,
    nErrCode,
    MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
    (LPTSTR) &lpMsgBuf,
    0, NULL );

     lpDisplayBuf = (LPVOID)LocalAlloc(LMEM_ZEROINIT,
    (lstrlen((LPCTSTR)lpMsgBuf) + 40) * sizeof(TCHAR));

    LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_WARNING, (LPTSTR)lpDisplayBuf );
}
else if(bRunning == -1)
{
        LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_WARNING,L"Share path is invalid!" );
}*/

return bRunning;
}

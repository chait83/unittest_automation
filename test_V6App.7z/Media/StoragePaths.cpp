/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Media Manager
/// @n Filename:	StoragePaths
/// @n Description: Translated between storage ID and a physical storage path
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 20-10-14	Rajanbabu M			Fixed PAR:1-3I2GTSM - WSD communication is not working on upgrading the firmware
// 46	Stability Project 1.41.1.3	7/2/2011 5:01:56 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 45	Stability Project 1.41.1.2	7/1/2011 4:38:59 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 44	Stability Project 1.41.1.1	3/17/2011 3:20:48 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 43	Stability Project 1.41.1.0	2/15/2011 3:04:00 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
// **************************************************************************

// StoragePaths.cpp: implementation of the CStoragePaths class.
//
//////////////////////////////////////////////////////////////////////

#include "StoragePaths.h"
#ifndef NASPATH
#include "V6globals.h"
#include "V6Config.h"
#endif
#include "TraceDefines.h"

#include "dal.h"

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CStoragePaths *CStoragePaths::m_pInstance = NULL;
QMutex hCreationMutex;

// Storage path names,
// Note: this table MUST match the path constants defined in enum _STORAGE_PATH (see StoragePaths.h) 

const QString  pPathTable[] = {L"\\SDMemory\\",			// IDS_INTERNAL_SD
	L"\\SDMemory2\\",// IDS_EXTERNAL_SD
	L"\\Hard Disk\\",// IDS_FIRST_USB
	L"\\Hard Disk2\\",// IDS_SECOND_USB
	L"Any Device!",// IDS_ANY_DEVICE	(don't use)
	L"Internal Flash!",// IDS_FLASH		(don't use)
	L"Firmware\\",// IDS_FIRMWARE
	L"", L"", L"Data\\",// IDS_LOG_DATA
	L"OEM\\",// IDS_OEM_DATA
	L"Config\\",// IDS_CONFIG_DATA
	L"Config",// IDS_LAYOUT_DATA
	L"Config\\Script\\",// IDS_SCRIPT_DATA
	L"Config\\Upgrade\\",// IDS_UPGRADE
	L"Firmware\\Platform\\",// IDS_PLATFORM
	L"Config.TV6\\",// IDS_EXT_CONFIG
	L"SWUpdate.TV6\\",// IDS_SW_UPDATE
	L"Rxxxxxx.TV6\\",// IDS_EXTRACT_DATA
	L"AutoRun.TV6\\",// IDS_AUTORUN
	L"*.Scr",// IDS_SCRIPT_MASK
	L"*.Lyt",// IDS_LAYOUT_MASK
	L"*.Cfg",// IDS_CONFIG_MASK
	L"Volume.TV6",// IDS_VOLUME
	L"VOL:",// IDS_RAWVOLUME
	L"",// IDS_ROOT,
	L"Config\\MetaData",// IDS_METADATA
	L"Firmware\\Primary\\",// IDS_PRIMARY
	L"Firmware\\Secondary\\",// IDS_SECONDARY
	L"V6app.exe",// IDS_APPEXE
	L"FTP\\",// IDS_FTP_BUFFER - FTP buffer, located on the internal CF card
	L"Network",// IDS_NETWORK	- Network connected devices
	///@todo this value may need to be read from the registry
	L"Share",// IDS_FILE_SHARE - Network file share 
	L"LCF.Conf",// IDS_LCF_FILE
	L"Help\\", L"AutoOps\\",// IDS_AUTO_OPS
	L"FTP\\",// IDS_FTP_ROOT
	L"FTP\\Upload\\",// IDS_FTP_UPLOAD
	L"FTP\\Upload\\Config\\",// IDS_FTP_UPLOAD_CFG
	L"FTP\\Download\\",// IDS_FTP_DOWNLOAD
	L"FTP\\Download\\Config\\",// IDS_FTP_DOWNLOAD_CFG
	L"FTP\\Download\\Data\\",// IDS_FTP_DOWNLOAD_DATA
	L"Sounds\\",// IDS_WAVS
	L"CustomSounds\\",// IDS_CUSTOM_WAVS
	L"Reports\\",// IDS_REPORTS
	L"Certificates\\",// IDS_CERTIFICATES	
	L"CertificatesCA\\",// IDS_CERTIFICATESCA
	L"EmailCertificates\\"//IDS_EMAILCERTIFICATES
};

//****************************************************************************
/// Class constructor
///
/// @return Returns either a pointer to the new class or a pointer to the existing instance
//****************************************************************************

CStoragePaths* CStoragePaths::GetHandle() {
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;

	if (NULL == m_pInstance) {
		hCreationMutex.lock();
		if (NULL == m_pInstance) {
			m_pInstance = new CStoragePaths;

		}
		hCreationMutex.unlock();
		// Close the Mutex as no longer required
		//No need to close the mutex in Qt
	}
	return m_pInstance;
}

//****************************************************************************
/// Secondary class constructor
///
//****************************************************************************

CStoragePaths::CStoragePaths() {
	mpDAL = NULL;
}

//****************************************************************************
/// Deletes the class and clears the instance pointer
///
//****************************************************************************

CStoragePaths::~CStoragePaths() {
	m_pInstance = NULL;
}

//****************************************************************************
/// Class initialisation
///
//****************************************************************************
void CStoragePaths::Initialise() {
	mpDAL = CDeviceAbstraction::GetHandle();
	// Not required since StoragePaths is belong to the DAL
//	mpDAL->Initialise();
}

//****************************************************************************
/// Cleanup the class and the instance pointer
///
//****************************************************************************

void CStoragePaths::Cleanup() {
	delete m_pInstance;
}

//****************************************************************************
/// Translate from a storage ID to a physical storage path
///
/// @param[in] 	pathID Storage resource identifier (string resource ID)
/// @param[in,out] pBuffer Buffer in which to store the resultant text string
/// @param[out]	pLength The length of the returned string (excluding any NULL)
///
/// @return Returns either a pointer to the string buffer or a null pointer
/// 
//****************************************************************************

WCHAR* CStoragePaths::GetPath(T_STORAGE_DEVICE pathID, QString   pBuffer, int pbufferSizeInWchars, int *pLength) {
//	static WCHAR localbuffer[MAX_PATH];

	if (NULL == mpDAL || NULL == pBuffer)
		return NULL;

	switch (pathID) {
	case IDS_INTERNAL_SD:
		return mpDAL->GetVolumeName(SD_INTERNAL_SD, pBuffer, pbufferSizeInWchars);
		break;

	case IDS_EXTERNAL_SD:
		return mpDAL->GetVolumeName(SD_EXTERNAL_SD, pBuffer, pbufferSizeInWchars);
		break;

	case IDS_FIRST_USB:
		return mpDAL->GetVolumeName(SD_USB1, pBuffer, pbufferSizeInWchars);
		break;

	case IDS_SECOND_USB:
		return mpDAL->GetVolumeName(SD_USB2, pBuffer, pbufferSizeInWchars);
		break;
	case IDS_FTP:
		return mpDAL->GetVolumeName(ROOT, pBuffer, pbufferSizeInWchars);
		break;
#ifndef NASPATH
	case IDS_SHARE: {

		T_PCOMMUNICATIONS ptCommsData = pGlbSetup->GetCommsSetupConfig()->GetCommsBlock(CONFIG_COMMITTED);
		if (ptCommsData != NULL) {
			WCHAR wcaDirName[120] = { 0 };
			if (ptCommsData->LanInfo.UseShare == TRUE) {

#if _MSC_VER < 1400 
				_tcscpy(wcaDirName, ptCommsData->LanInfo.sharePath);
				_tcscpy(pBuffer, ptCommsData->LanInfo.sharePath);

#else
					_tcscpy_s( wcaDirName, 120, ptCommsData->LanInfo.sharePath);	
					_tcscpy_s( pBuffer, pbufferSizeInWchars, ptCommsData->LanInfo.sharePath);

#endif

			}
			/*return wcaDirName;*/
			return pBuffer; // E529380 fixed: "returning address of local variable"
		}
		break;
	}
#endif

	default:
#if _MSC_VER < 1400 
		wcsncpy(pBuffer, pPathTable[pathID], *pLength);
#else
		wcsncpy_s( pBuffer, pbufferSizeInWchars, pPathTable[pathID], *pLength ) ; 
#endif
		*pLength = (int) wcslen(pBuffer);
		return pBuffer;
	} // Switch()
	return pBuffer;
}

//****************************************************************************
/// Translate from a storage ID to a physical storage path
///
/// @param[in] 		device storage device, set to IDS_ANY_DEVICE for no device
/// @param[in]		path	storage path see T_STORAGE_PATH
/// @param[in]		file	file name (may be null if just the path is required
/// @param[in]		buffer	buffer to stick the result
/// @param[in]		size	size of the buffer supplied (number of WCHAR's)
///
/// @return Returns TRUE if all OK, else FALSE (truncation ocoured)
/// 
//****************************************************************************
BOOL CStoragePaths::BuildPath(T_STORAGE_DEVICE device, T_STORAGE_PATH path, const QString   const file, QString   buffer,
		USHORT size) {
	BOOL bResult = TRUE;
	int Length = size;
	WCHAR PathBuffer[MAX_PATH];

	// Clear the buffers
	memset(buffer, '\0', size * sizeof(WCHAR));
	memset(PathBuffer, '\0', MAX_PATH * sizeof(WCHAR));

	Length = MAX_PATH;
	// if a device has been specified, get the device name
	if (IDS_ANY_DEVICE != device) {
		GetPath((T_STORAGE_PATH) device, PathBuffer, size, &Length);
		// if truncation has ocoured, set the result to false
		if (wcslen(PathBuffer) > size)
			bResult = FALSE;
#if _MSC_VER < 1400 
		wcsncpy(buffer, PathBuffer, size);
#else
		wcsncpy_s( buffer, size, PathBuffer, _TRUNCATE );
#endif

	}

	// get the storage path
	Length = MAX_PATH;
	GetPath(path, PathBuffer, MAX_PATH, &Length);

	// check if truncation will ocour
	if (wcslen(PathBuffer) + wcslen(buffer) > size)
		bResult = FALSE;

#if _MSC_VER < 1400 
	wcsncat(buffer, PathBuffer, size - wcslen(buffer));
#else
	wcsncat( buffer, size, PathBuffer, size - wcslen( buffer ) );
#endif

	// if a file name has been supplied
	if (NULL != file) {
		// check if truncation will ocour
		if (wcslen(buffer) + wcslen(file) > size)
			bResult = FALSE;
#if _MSC_VER < 1400 
		wcsncat(buffer, file, size - wcslen(buffer));
#else
		wcsncat( buffer, size, file, size - wcslen( buffer ) );
#endif

	}

	return bResult;
}

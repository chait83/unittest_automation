/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Storage/Media
/// @n Filename:  RecorderStorage.h
/// @n Description: Definition of the CRecorderStorage class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  3 Stability Project 1.0.1.1 7/2/2011 5:00:18 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  2 Stability Project 1.0.1.0 7/1/2011 4:27:50 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  1 V6 Firmware 1.0 3/27/2007 3:58:42 PM  Roger Dawson  
// $
//
// **************************************************************************

#if !defined(AFX_RECORDERSTORAGE_H__08962653_0191_4DEF_85EB_3B3BE5FAB598__INCLUDED_)
#define AFX_RECORDERSTORAGE_H__08962653_0191_4DEF_85EB_3B3BE5FAB598__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CStorage.h"

//**CRecorderStorage**********************************************************
///
/// @brief	Child class of the CStorage class required for the recorder. This class provides
///			better error reporting and logging as it includes classes specific to the recorder
/// 
/// Child class of the CStorage class required for the recorder. This class provides
///	better error reporting and logging as it includes classes specific to the recorder
///
//****************************************************************************
class CRecorderStorage: public CStorage {
public:
	// Constructor
	CRecorderStorage();

	// Alternative Constructor
	CRecorderStorage(LPCTSTR lpszFileName, UINT nOpenFlags);

	// Destructor
	virtual ~CRecorderStorage();

protected:

	// Overridden Methods used for showing errors

	// Method that shows file exception errors
	virtual void ShowError(const QString   &rstrFUNC_NAME, const QString   &rstrFILENAME, FileException &kEx);

	// Method that shows non-file exception errors
	virtual void ShowError(const QString   &rstrFUNC_NAME, const QString   &rstrFILENAME);

	// Method that prompts the user with the passed in parameters
	const bool PromptUser(const QString   &rstrTITLE, const QString   &rstrMESSAGE);

	// Method that prompts the user with an OK to overwrite existing message
	virtual const bool PromptOverwrite();
};

#endif // !defined(AFX_RECORDERSTORAGE_H__08962653_0191_4DEF_85EB_3B3BE5FAB598__INCLUDED_)

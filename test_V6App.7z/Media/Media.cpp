/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  Media Manager
/// @n Filename:  Media.cpp
/// @n Description: Storage media abstraction layer
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  12  Stability Project 1.9.1.1 7/2/2011 4:58:42 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  11  Stability Project 1.9.1.0 7/1/2011 4:26:14 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  10  V6 Firmware 1.9 6/30/2005 2:48:40 PM  Martin Miller 
//  Modified calls to Storage paths prior to modification
//  9 V6 Firmware 1.8 4/27/2005 2:49:57 PM  Martin Miller 
//  Changed string initialisation
// $
//
// **************************************************************************

// Media.cpp: implementation of the CMedia class.
//
//////////////////////////////////////////////////////////////////////

#include "Dal.h"
#include "StoragePaths.h"
#include "Media.h"

#include "TraceDefines.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

//*************************************************************
/// Class Constructor
///
/// @param[in] 	  volumeID Storage device volume ID (0 based)
/// 
//*************************************************************
CMedia::CMedia(T_STORAGE_DEVICE volumeID) {
//	pPath = CStoragePaths::GetHandle();
	m_pDAL = CDeviceAbstraction::GetHandle();
	m_pDAL->Initialise();
	int Length = MAX_PATH;

	m_VolumeID = volumeID;
	m_Handle = NULL;
	m_Available = FALSE;
	memset(m_VolumeName, '\0', MAX_PATH * sizeof(WCHAR));
	m_pDAL->GetPath((T_STORAGE_PATH) volumeID, m_VolumeName, &Length);
	wcscat(m_VolumeName, L"\\VOL:");
}

//*************************************************************
/// Class Destructor
/// 
//*************************************************************
CMedia::~CMedia() {

}

//****************************************************************************
/// Read media free space into the media data
///
/// @return TRUE if request succeded, else FALSE
///
//****************************************************************************
BOOL CMedia::GetMediaFreeSpace() {
	if (m_VolumeName == NULL)
		return FALSE;

    /// TODO write script to get disk free space from the console.
	return GetDiskFreeSpaceEx(m_VolumeName, (PULARGE_INTEGER) &m_BytesAvailable, (PULARGE_INTEGER) &m_TotalBytes,
			(PULARGE_INTEGER) &m_TotalFreeBytes);
}

//****************************************************************************
/// Check if media is inserted
///
/// @return TRUE if media is found, else FALSE
///
//****************************************************************************
BOOL CMedia::CheckMedia() {
    /// TODO: Rewrite code to check the media type
	if (m_VolumeName == NULL)
		return FALSE;

	m_Handle = CreateFile(m_VolumeName, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_WRITE, NULL, OPEN_EXISTING,
			FILE_ATTRIBUTE_NORMAL | FILE_FLAG_WRITE_THROUGH, NULL);

	if (m_Handle == INVALID_HANDLE_VALUE)
		return FALSE;
	else {
		//No need to close the mutex in Qt
		m_Handle = NULL;
		return TRUE;
	}
}


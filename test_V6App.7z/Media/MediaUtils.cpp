/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Media 
/// @n Filename:	MediaUtils.cpp
/// @n Description: Provides storage media utilities
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 23	Stability Project 1.18.1.3	7/2/2011 4:58:43 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 22	Stability Project 1.18.1.2	7/1/2011 4:38:29 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 21	Stability Project 1.18.1.1	3/17/2011 3:20:29 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 20	Stability Project 1.18.1.0	2/15/2011 3:03:19 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
// **************************************************************************

// MediaUtils.cpp: implementation of the CStorageUtils class.
//
//////////////////////////////////////////////////////////////////////

#include "diskio.h"		// Disk_Info structure declarations


#include "MediaUtils.h"
#include "CStorage.h"
#include "V6globals.h"
#include "BootData.h"

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif

#ifndef _DEBUG
#ifdef UNDER_CE
	#include "storemgr.h"
#endif
#endif

// Folder tables:
// These are the CStoragePaths paths which are checked and created,
// if you need other paths, just add them to the table.

T_STORAGE_PATH InternalPath[] = { IDS_FIRMWARE, IDS_PRIMARY, IDS_SECONDARY, IDS_LOG_DATA, IDS_OEM_DATA, IDS_CONFIG_DATA,
		IDS_LAYOUT_DATA, IDS_SCRIPT_DATA, IDS_UPGRADE,
//	IDS_PLATFORM,
		IDS_METADATA, IDS_FTP_BUFFER, IDS_REPORTS, (T_STORAGE_PATH) 0 };

T_STORAGE_PATH ExternalPath[] = { IDS_EXT_CONFIG, IDS_EXTRACT_DATA, (T_STORAGE_PATH) 0 };

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

//****************************************************************************
/// Storage object constructor
///
/// @return none
///
//****************************************************************************
MediaUtils::MediaUtils() {
	Meg = 0L;
}

//****************************************************************************
/// Storage object destructor
///
/// @return none
///
//****************************************************************************

MediaUtils::~MediaUtils() {
}

//This function is commented out, because this function is no more in use.
//After the fix 1-1713TYI - GR_General Status shows "Internal Mem ID as 512(null)
//****************************************************************************
/// Mediaasprintf:
///
/// @param[in] 		wszVolume	- Pointer to the (Unicode) volume name ("\\Compact Flash\\VOL:")
///
/// @return			T_MEDIA_FORMAT
///
/// @note This method of checking the format descriptor has proved 100% reliable
/// at recognising media which has NOT been formatted correctly.
//****************************************************************************

/*const T_MEDIA_FORMAT MediaUtils::Mediaasprintf( QString  wszVolume )
 {
 T_MEDIA_FORMAT mediaasprintf = FORMAT_UNKNOWN;

 #ifndef _DEBUG
 #ifdef UNDER_CE
 CE_VOLUME_INFO viVolumeInfo;
 memset(&viVolumeInfo, 0, sizeof(CE_VOLUME_INFO));
 viVolumeInfo.cbSize = sizeof(CE_VOLUME_INFO);

 if (CeGetVolumeInfo(L"\\SDMemory\\", (CE_VOLUME_INFO_LEVEL)CeVolumeInfoLevelStandard, &viVolumeInfo) == FALSE)
 {
 //RETAILMSG(1, (TEXT("Calling CeGetVolumeInfo() failed, error=0x%X for Diskname:%s\r\n"), GetLastError(),DiskName));
 //return;
 }

 if(viVolumeInfo.dwFlags & 0x01)
 mediaasprintf = FORMAT_TFAT_16;
 #endif
 #endif
 return mediaasprintf;
 }*/

//****************************************************************************
/// Storage object destructor
///
/// @param[in]	device	wchar device name ( "\\Compact Flash" )
///
/// @return T_MEDIA_SIZE total size of the media device
///
//****************************************************************************
T_MEDIA_SIZE MediaUtils::MediaSize(QString   device) {
	T_MEDIA_SIZE size = MS_UNKNOWN;
	ULARGE_INTEGER TotalBytes;
	//ULONG Meg = 0L;

#ifndef UNDER_CE
	size = MS_128M; // PC/emulator build, so treat as 128meg
#else
	if ( GetDiskFreeSpaceEx( device, NULL, &TotalBytes, NULL ) )
	{
		Meg = (ULONG)BYTE_TO_MB(TotalBytes.QuadPart);

		if(Meg >= 7000)
			size = MS_8G;
		else if ( Meg >= 3000 )
			size = MS_4G;
		else if ( Meg >= 1000 )
			size = MS_2G;
		else if ( Meg >= 500 )
			size = MS_1G;
		else
			size = MS_OTHER ;
	}
#endif
	return size;
}

//****************************************************************************
/// Create internal folder structure
///
/// @param[in] drive device to initialise
//
// return TRUE if all folders created OK, else FALSE
//****************************************************************************
BOOL MediaUtils::PrepareInternal(T_STORAGE_DEVICE drive) {
	BOOL bResult = TRUE;
	int length = MAX_PATH;
	WCHAR buffer[MAX_PATH];
	WCHAR root[MAX_PATH];

	root[0] = L'\0';

	pDALGLB->GetPath((T_STORAGE_PATH) drive, root, MAX_PATH, &length);

	QString   csTxt;
	csTxt = tr("Initializing Internal Media");
	pGlbSysInfo->SetStartupSubAction((LPCTSTR) csTxt);
	int path = 0;
	while (InternalPath[path] != 0) {
		buffer[0] = L'\0';
#if _MSC_VER < 1400
		wcscat(buffer, root);
#else
		wcscat_s( buffer, MAX_PATH, root );
#endif

		length = MAX_PATH - (int) wcslen(buffer);
		pDALGLB->GetPath(InternalPath[path], &buffer[wcslen(buffer)], length, &length);
		if (CreateDirectory(buffer, NULL) != TRUE) {
			if (GetLastError() != ERROR_ALREADY_EXISTS)
				bResult = FALSE;
		}
		path++;
	}
	return TRUE;
}

//****************************************************************************
/// Check internal folder structure
///
/// @param[in] drive device to initialise
//
// return TRUE if all folders found, else FALSE
//****************************************************************************
BOOL MediaUtils::CheckInternalMedia(T_STORAGE_DEVICE drive) {
	BOOL bResult = TRUE;
	int length = MAX_PATH;
	WCHAR buffer[MAX_PATH];
	WCHAR root[MAX_PATH];
	WIN32_FIND_DATA find_data;
	HANDLE search_handle;

	QString   csTxt;
	csTxt = tr("Checking Internal Media");
	pGlbSysInfo->SetStartupSubAction((LPCTSTR) csTxt);
	memset(buffer, '\0', MAX_PATH * sizeof(WCHAR));
	memset(root, '\0', MAX_PATH * sizeof(WCHAR));

	pDALGLB->GetPath((T_STORAGE_PATH) drive, root, MAX_PATH, &length);

#if _MSC_VER < 1400
	wcscpy(buffer, root);
#else
	wcscpy_s( buffer, MAX_PATH, root );
#endif

	if (buffer[wcslen(buffer) - 1] == '\\')
		buffer[wcslen(buffer) - 1] = '\0';

	// Check if the root exists
	search_handle = indexOfFirstFile(buffer, &find_data);
	if (search_handle == INVALID_HANDLE_VALUE)
		bResult = FALSE;
	else
		indexOfClose(search_handle);

	// Check all the storage folders

	int path = 0;
	while (InternalPath[path] != 0) {
		buffer[0] = L'\0';

#if _MSC_VER < 1400
		wcscat(buffer, root);
#else
		wcscat_s ( buffer, MAX_PATH, root );
#endif

		length = MAX_PATH - (int) wcslen(buffer);
		pDALGLB->GetPath(InternalPath[path], &buffer[wcslen(buffer)], length, &length);
		if (buffer[wcslen(buffer) - 1] == '\\')
			buffer[wcslen(buffer) - 1] = '\0';
		search_handle = indexOfFirstFile(buffer, &find_data);
		if (search_handle == INVALID_HANDLE_VALUE)
			bResult = FALSE;
		else
			indexOfClose(search_handle);

		path++;
	}

	return bResult;
}

//****************************************************************************
/// Create external folder structure
///
/// @param[in] drive device to initialise
//
// return TRUE if all folders created OK, else FALSE
//****************************************************************************
BOOL MediaUtils::PrepareExternal(T_STORAGE_DEVICE drive) {
	BOOL bResult = TRUE;
	int length = MAX_PATH;
	WCHAR buffer[MAX_PATH];
	WCHAR root[MAX_PATH];

	root[0] = L'\0';

	pDALGLB->GetPath((T_STORAGE_PATH) drive, root, MAX_PATH, &length);

	int path = 0;
	while (InternalPath[path] != 0) {
		buffer[0] = L'\0';

#if _MSC_VER < 1400
		wcscat(buffer, root);
#else
		wcscat_s( buffer, MAX_PATH, root );
#endif

		length = MAX_PATH - (int) wcslen(buffer);
		pDALGLB->GetPath(ExternalPath[path], &buffer[wcslen(buffer)], length, &length);
		if (CreateDirectory(buffer, NULL) != TRUE) {
			if (GetLastError() != ERROR_ALREADY_EXISTS)
				bResult = FALSE;
		}
		path++;
	}
	return TRUE;
}

//****************************************************************************
/// Delete specified file, built from device, path and filename components
///
/// @param[in] device, device to delete file off as a T_STORAGE_DEVICE
/// @param[in] path, path of file to delete as T_STORAGE_PATH
/// @param[in] fileName, filename of file to delete
///
/// return TRUE if all folders found, else FALSE
//****************************************************************************
void MediaUtils::DeleteFile(T_STORAGE_DEVICE device, T_STORAGE_PATH path, const QString   const fileName) {
	WCHAR pathAndFileName[MAX_PATH];
	if ( pDALGLB->BuildPath(device, path, fileName, pathAndFileName,
	MAX_PATH) == TRUE) {
		CStorage::DeleteFile(pathAndFileName);
	}
}

//****************************************************************************
/// Check external folder structure
///
/// @param[in] drive device to checked
//
// return TRUE if all folders found, else FALSE
//****************************************************************************
BOOL MediaUtils::CheckExternalMedia(T_STORAGE_DEVICE drive) {
	BOOL bResult = TRUE;
	int length = MAX_PATH;
	WCHAR buffer[MAX_PATH];
	WCHAR root[MAX_PATH];
	WIN32_FIND_DATA find_data;
	HANDLE search_handle;

	SecureZeroMemory(buffer, sizeof(buffer));
	SecureZeroMemory(root, sizeof(root));
	/*_wcsnset_s( buffer, MAX_PATH, '\0', MAX_PATH );
	 _wcsnset_s( root, MAX_PATH, '\0', MAX_PATH );*/

	pDALGLB->GetPath((T_STORAGE_PATH) drive, root, MAX_PATH, &length);

	// Check if the root exists
	search_handle = indexOfFirstFile(root, &find_data);
	if (search_handle == INVALID_HANDLE_VALUE)
		bResult = FALSE;
	else
		indexOfClose(search_handle);

	// Check all the storage folders

	int path = 0;
	while (InternalPath[path] != 0) {
		buffer[0] = L'\0';

#if _MSC_VER < 1400
		wcscat(buffer, root);
#else
		wcscat_s( buffer, MAX_PATH, root );
#endif

		length = MAX_PATH - (int) wcslen(buffer);
		pDALGLB->GetPath(ExternalPath[path], &buffer[wcslen(buffer)], length, &length);
		if (buffer[wcslen(buffer) - 1] == '\\')
			buffer[wcslen(buffer) - 1] = '\0';
		search_handle = indexOfFirstFile(buffer, &find_data);
		if (search_handle == INVALID_HANDLE_VALUE)
			bResult = FALSE;
		else
			indexOfClose(search_handle);

		path++;
	}

	return bResult;
}

////////////////////////////////////////////
// Firmware update detection and installation

CSoftwareUpdate::CSoftwareUpdate() {
	m_UpgradeFound = FALSE;
	m_UpgradeVersion = "";
	m_UpgradeType = RELEASE_INVALID;
}

CSoftwareUpdate::~CSoftwareUpdate() {
}

//****************************************************************************
/// indexOf first available update package
///
//
// return TRUE if package has been found
//****************************************************************************
BOOL CSoftwareUpdate::indexOfUpdatePackage(WCHAR wcOEM) {
	BOOL bResult = TRUE;

	// Test each device in turn until an upgrade has been found
	if ((IsPackageAvailable(IDS_FIRST_USB, wcOEM)) || (IsPackageAvailable(IDS_SECOND_USB, wcOEM))
			|| (IsPackageAvailable(IDS_EXTERNAL_SD, wcOEM)) /*||
			 ( IsPackageAvailable( IDS_SHARE, wcOEM ))*/) {
		bResult = TRUE;		// Valid Upgrade found
	} else {
		bResult = FALSE;	// No upgrade found
	}

	return bResult;
}

//****************************************************************************
/// indexOf first available update package
///
//
// return TRUE if package has been found
//****************************************************************************
BOOL CSoftwareUpdate::indexOfIOUpdatePackage(WCHAR wcOEM) {
	BOOL bResult = TRUE;

	// Test each device in turn until an upgrade has been found
	if ((IsIOPackageAvailable(IDS_FIRST_USB, wcOEM)) || (IsIOPackageAvailable(IDS_SECOND_USB, wcOEM))
			|| (IsIOPackageAvailable(IDS_EXTERNAL_SD, wcOEM)) /*||
			 ( IsPackageAvailable( IDS_SHARE, wcOEM ))*/) {
		bResult = TRUE;		// Valid Upgrade found
	} else {
		bResult = FALSE;	// No upgrade found
	}

	return bResult;
}

//****************************************************************************
/// indexOf first available Certificate package
///
//
// return TRUE if package has been found
//****************************************************************************
BOOL CSoftwareUpdate::indexOfCertPackage(T_MEDIA_CERT_TYPE certTypeUsed) {
	BOOL bResult = FALSE;

	switch (certTypeUsed) {
	case CA_CERT:
		if ((IsCertCAFolderPathAvailable(IDS_FIRST_USB)) || (IsCertCAFolderPathAvailable(IDS_SECOND_USB))
				|| (IsCertCAFolderPathAvailable(IDS_EXTERNAL_SD)) /*||
				 ( IsPackageAvailable( IDS_SHARE, wcOEM ))*/) {
			bResult = TRUE;		// Valid Upgrade found
		}
		break;

	case SELF_CERT:
		// Test each device in turn until an upgrade has been found
		if ((IsCertPackageAvailable(IDS_FIRST_USB)) || (IsCertPackageAvailable(IDS_SECOND_USB))
				|| (IsCertPackageAvailable(IDS_EXTERNAL_SD)) /*||
				 ( IsPackageAvailable( IDS_SHARE, wcOEM ))*/) {
			bResult = TRUE;		// Valid Upgrade found
		}
		break;

	case EMAIL_CERT:
		// Test each device in turn until an upgrade has been found
		if ((IsEmailCertPackageAvailable(IDS_FIRST_USB)) || (IsEmailCertPackageAvailable(IDS_SECOND_USB))
				|| (IsEmailCertPackageAvailable(IDS_EXTERNAL_SD)) /*||
				 ( IsPackageAvailable( IDS_SHARE, wcOEM ))*/) {
			bResult = TRUE;		// Valid Upgrade found
		}
		break;

	default:
		break;
	}

	return bResult;
}

//****************************************************************************
/// Check if an update package is available on the media
///
/// @param[in]		Drive	- device to checked
/// @param[in,out]	PackageFile - Returned package file name
//
// return TRUE if package found, else FALSE
//****************************************************************************
BOOL CSoftwareUpdate::IsPackageAvailable(T_STORAGE_DEVICE DriveToTry, WCHAR wcOEM) {
	WCHAR wcFileName[20];
	WCHAR wcName[MAX_PATH];
	int length = MAX_PATH;
	BOOL bResult = FALSE;
	HANDLE file_handle = NULL;
	WIN32_FIND_DATA find_data;
	HANDLE search_handle;

	// Firmware updates have filename as follows
	// FW-100-1-1-A-0.XSU
	// where R = release type (A=Alpha, B=Beta, R=Release)
	// where O = OEM variant number 0=Honeywell, 1=Siemens, 2=GMC 3=Generic etc...
	// with XSU extension (X Series Update) and leading FW for Firmware

#if _MSC_VER < 1400
	wcscpy(wcFileName, L"*.XSU");
#else
	wcscpy_s( wcFileName, 20, L"*.XSU" );
#endif

	pDALGLB->GetPath((T_STORAGE_PATH) DriveToTry, wcName, MAX_PATH, &length);

#if _MSC_VER < 1400
	wcscat(wcName, wcFileName);
#else
	wcscat_s( wcName, sizeof(wcName)/sizeof(WCHAR), wcFileName );
#endif

	// indexOf any update packages on external media
	search_handle = indexOfFirstFile(wcName, &find_data);

	// if a package was found, return the package name
	if ( INVALID_HANDLE_VALUE != search_handle) {
		bResult = TRUE;

#if _MSC_VER < 1400
		wcscpy(m_PackageFile, find_data.cFileName);
#else
		wcscpy_s( m_PackageFile, sizeof(m_PackageFile)/sizeof(WCHAR), find_data.cFileName );
#endif

		//Tokenize the File name
		QString   strFileName = find_data.cFileName;
		int iCountDash = 0;
		int iLength = strFileName.length();
		int iStartPos = 0;

		for (int index = 0; index < iLength; index++) {
			if (m_PackageFile[index] == '-') {
				iCountDash++;
			}
			if (m_PackageFile[index] == '.') {
				iStartPos = index;
			}
		}
		if (iCountDash != 5) {
			bResult = FALSE;
		} else {
			m_InstallDrive = DriveToTry;
			m_UpgradeVersion = strFileName.mid(0, iStartPos);

			if (m_UpgradeVersion.mid(iStartPos - 3, 1) == L"A") {
				m_UpgradeType = RELEASE_ALPHA;
			} else if (m_UpgradeVersion.mid(iStartPos - 3, 1) == L"B") {
				m_UpgradeType = RELEASE_BETA;
			} else if (m_UpgradeVersion.mid(iStartPos - 3, 1) == L"R") {
				m_UpgradeType = RELEASE_PRODUCTION;
			} else {
				bResult = FALSE;
			}
		}
		indexOfClose(search_handle);
	}
	//No need to close the mutex in Qt

	m_UpgradeFound = bResult;
	return bResult;
}

//****************************************************************************
/// Check if an IO update package is available on the media
///
/// @param[in]		Drive	- device to checked
/// @param[in,out]	PackageFile - Returned package file name
//
// return TRUE if package found, else FALSE
//****************************************************************************
BOOL CSoftwareUpdate::IsIOPackageAvailable(T_STORAGE_DEVICE DriveToTry, WCHAR wcOEM) {
	WCHAR wcFileName[20];
	WCHAR wcName[MAX_PATH];
	int length = MAX_PATH;
	BOOL bResult = FALSE;
	HANDLE file_handle = NULL;
	WIN32_FIND_DATA find_data;
	HANDLE search_handle;

	// Firmware updates have filename as follows
	// FW-100-1-1-A-0.BIN
	// AI-01-01.BIN
	// where R = release type (A=Alpha, B=Beta, R=Release)
	// where O = OEM variant number 0=Honeywell, 1=Siemens, 2=GMC 3=Generic etc...
	// with XSU extension (X Series Update) and leading FW for Firmware

#if _MSC_VER < 1400
	wcscpy(wcFileName, L"*.BIN");
#else
	wcscpy_s( wcFileName, 20, L"*.BIN" );
#endif

	pDALGLB->GetPath((T_STORAGE_PATH) DriveToTry, wcName, MAX_PATH, &length);

#if _MSC_VER < 1400
	wcscat(wcName, wcFileName);
#else
	wcscat_s( wcName, sizeof(wcName)/sizeof(WCHAR), wcFileName );
#endif

	// indexOf any update packages on external media
	search_handle = indexOfFirstFile(wcName, &find_data);

	// if a package was found, return the package name
	if ( INVALID_HANDLE_VALUE != search_handle) {
		bResult = TRUE;

#if _MSC_VER < 1400
		wcscpy(m_PackageFile, find_data.cFileName);
#else
		wcscpy_s( m_PackageFile, sizeof(m_PackageFile)/sizeof(WCHAR), find_data.cFileName );
#endif

		//Tokenize the File name
		/*QString  strFileName = find_data.cFileName;
		 int iCountDash = 0;
		 int iLength = strFileName.length();
		 int iStartPos = 0;

		 for(int index = 0; index < iLength; index++)
		 {
		 if(m_PackageFile[index] == '-')
		 {
		 iCountDash++;
		 }
		 if(m_PackageFile[index] == '.')
		 {
		 iStartPos = index;
		 }
		 }
		 if(iCountDash != 5)
		 {
		 bResult=FALSE;
		 }*/
		//else
		//{
		m_UpgradeVersion = find_data.cFileName;
		m_InstallDrive = DriveToTry;
		//m_UpgradeVersion = strFileName.mid(0,iStartPos);

		/*if( m_UpgradeVersion.mid(iStartPos - 3, 1) == L"A" )
		 {
		 m_UpgradeType = RELEASE_ALPHA;
		 }
		 else if( m_UpgradeVersion.mid(iStartPos - 3, 1) == L"B" )
		 {
		 m_UpgradeType = RELEASE_BETA;
		 }
		 else if( m_UpgradeVersion.mid(iStartPos - 3, 1) == L"R" )
		 {
		 m_UpgradeType = RELEASE_PRODUCTION;
		 }
		 else
		 {
		 bResult = FALSE;
		 }
		 }*/

		indexOfClose(search_handle);
	}
	//No need to close the mutex in Qt

	m_UpgradeFound = bResult;
	return bResult;
}

//****************************************************************************
/// Check if a certificate CA folder path is available on the media
///
/// @param[in]		Drive	- device to checked
/// @param[in,out]	PackageFile - Returned package file name
//
// return TRUE if package found, else FALSE
//****************************************************************************
BOOL CSoftwareUpdate::IsCertCAFolderPathAvailable(T_STORAGE_DEVICE DriveToTry) {
	WCHAR wcFileName[20];
	WCHAR wcRootFileName[MAX_PATH];
	WCHAR wcDeviceFileName[MAX_PATH];

	WCHAR wcName[MAX_PATH];
	//WCHAR wc
	int length = MAX_PATH;
	BOOL bResult = FALSE;
	HANDLE file_handle = NULL;
	WIN32_FIND_DATA find_data;
	HANDLE search_handle;

	//
	// Certificate package have filename as : CertificatesCA

#if _MSC_VER < 1400
	wcscpy(wcFileName, L"CertificatesCA");
#else
	wcscpy_s( wcFileName, 20, L"CertificatesCA" );
#endif

	pDALGLB->GetPath((T_STORAGE_PATH) DriveToTry, wcName, MAX_PATH, &length);

#if _MSC_VER < 1400
	wcscat(wcName, wcFileName);
#else
	wcscat_s( wcName, sizeof(wcName)/sizeof(WCHAR), wcFileName );
	wcscpy_s( wcRootFileName, sizeof(wcRootFileName)/sizeof(WCHAR), wcName );
	wcscpy_s( wcDeviceFileName, sizeof(wcDeviceFileName)/sizeof(WCHAR), wcName );
#endif

	// indexOf any update packages on external media
	search_handle = indexOfFirstFile(wcName, &find_data);

	// if a package was found, return the package name
	if ( INVALID_HANDLE_VALUE != search_handle) {
		bResult = TRUE;
		//	memset( wcaWavsPath, 0, sizeof( WCHAR ) * MAX_PATH );
		std::vector < std::wstring > caCertFiles = GetAllCACertsName(wcName);
		if (caCertFiles.size() == 2)//to check for only 2 filwa else don't proceed further as it is not as rquired folder format.
				{
			if ((std::find(caCertFiles.begin(), caCertFiles.end(), WSDCACERTFILES[0]) != caCertFiles.end())
					&& (std::find(caCertFiles.begin(), caCertFiles.end(), WSDCACERTFILES[1]) != caCertFiles.end())) {
				wcscat_s(wcRootFileName, sizeof(wcRootFileName) / sizeof(WCHAR), L"\\");
				wcscat_s(wcRootFileName, sizeof(wcRootFileName) / sizeof(WCHAR), WSDCACERTFILES[1]);
				wcscat_s(wcDeviceFileName, sizeof(wcDeviceFileName) / sizeof(WCHAR), L"\\");
				wcscat_s(wcDeviceFileName, sizeof(wcDeviceFileName) / sizeof(WCHAR), WSDCACERTFILES[0]);
				wcscpy_s(m_CertCARootFile, sizeof(m_CertCARootFile) / sizeof(WCHAR), wcRootFileName);
				wcscpy_s(m_CertCAServerFile, sizeof(m_CertCAServerFile) / sizeof(WCHAR), wcDeviceFileName);
			} else {
				bResult = FALSE;
			}

		}
		indexOfClose(search_handle); //769297 - ConverityFix - E374454

	}

	return bResult;
}
//****************************************************************************
/// For the list of files and folders under folder which is available on the media
///
/// @param[in]		folder	- folder path
/// @param[in]	isFolder - folder or not
//
// return the list of filename found, else FALSE
//****************************************************************************

std::vector<std::wstring> CSoftwareUpdate::GetAllCACertsName(QString   folder) {
	vector < std::wstring > names;
	std::wstring search_path = folder + _T("/*.*");
	WIN32_FIND_DATA fd;
	HANDLE hindexOf = ::indexOfFirstFile(search_path.c_str(), &fd);
	if (hindexOf != INVALID_HANDLE_VALUE) {
		do {
			// read all (real) files in current folder
			// , delete '!' read other 2 default folder . and ..
			if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) {
				names.push_back(fd.cFileName);
			}
		} while (::indexOfNextFile(hindexOf, &fd));

		::indexOfClose(hindexOf);
	}
	return names;
}
//****************************************************************************
/// Check if a certificate package is available on the media
///
/// @param[in]		Drive	- device to checked
/// @param[in,out]	PackageFile - Returned package file name
//
// return TRUE if package found, else FALSE
//****************************************************************************
BOOL CSoftwareUpdate::IsCertPackageAvailable(T_STORAGE_DEVICE DriveToTry) {
	WCHAR wcFileName[20];
	WCHAR wcName[MAX_PATH];
	int length = MAX_PATH;
	BOOL bResult = FALSE;
	HANDLE file_handle = NULL;
	WIN32_FIND_DATA find_data;
	HANDLE search_handle;

	//
	// Certificate package have filename as : Certificates.cer

#if _MSC_VER < 1400
	wcscpy(wcFileName, L"Certificates.cer");
#else
	wcscpy_s( wcFileName, 20, L"Certificates.cer" );
#endif

	pDALGLB->GetPath((T_STORAGE_PATH) DriveToTry, wcName, MAX_PATH, &length);

#if _MSC_VER < 1400
	wcscat(wcName, wcFileName);
#else
	wcscat_s( wcName, sizeof(wcName)/sizeof(WCHAR), wcFileName );
#endif

	// indexOf any update packages on external media
	search_handle = indexOfFirstFile(wcName, &find_data);

	// if a package was found, return the package name
	if ( INVALID_HANDLE_VALUE != search_handle) {
		bResult = TRUE;
		m_CertpackageFound = TRUE;
#if _MSC_VER < 1400
		wcscpy(m_CertPackageFile, find_data.cFileName);
#else
		//wcscpy_s( m_CertPackageFile, sizeof(m_CertPackageFile)/sizeof(WCHAR), find_data.cFileName );
		wcscpy_s( m_CertPackageFile, sizeof(m_CertPackageFile)/sizeof(WCHAR), wcName );
#endif
		indexOfClose(search_handle); //779226 - ConverityFix - E374454
	}

	return bResult;
}

//****************************************************************************
/// Check if a certificate package is available on the media
///
/// @param[in]		Drive	- device to checked
/// @param[in,out]	PackageFile - Returned package file name
//
// return TRUE if package found, else FALSE
//****************************************************************************
BOOL CSoftwareUpdate::IsEmailCertPackageAvailable(T_STORAGE_DEVICE DriveToTry) {
	WCHAR wcFileName[20];
	WCHAR wcRootFileName[MAX_PATH];
	WCHAR wcDeviceFileName[MAX_PATH];

	WCHAR wcName[MAX_PATH];
	//WCHAR wc
	int length = MAX_PATH;
	BOOL bResult = FALSE;
	HANDLE file_handle = NULL;
	WIN32_FIND_DATA find_data;
	HANDLE search_handle;

	//
	// Certificate package have filename as : EmailCertificates

#if _MSC_VER < 1400
	wcscpy(wcFileName, L"EmailCertificates");
#else
	wcscpy_s( wcFileName, 20, L"EmailCertificates" );
#endif

	pDALGLB->GetPath((T_STORAGE_PATH) DriveToTry, wcName, MAX_PATH, &length);

#if _MSC_VER < 1400
	wcscat(wcName, wcFileName);
#else
	wcscat_s( wcName, sizeof(wcName)/sizeof(WCHAR), wcFileName );
	wcscpy_s( wcRootFileName, sizeof(wcRootFileName)/sizeof(WCHAR), wcName );
	wcscpy_s( wcDeviceFileName, sizeof(wcDeviceFileName)/sizeof(WCHAR), wcName );
#endif

	// indexOf any update packages on external media
	search_handle = indexOfFirstFile(wcName, &find_data);

	// if a package was found, return the package name
	if ( INVALID_HANDLE_VALUE != search_handle) {
		std::vector < std::wstring > caCertFiles = GetAllCACertsName(wcName);
		if (std::find(caCertFiles.begin(), caCertFiles.end(), EMAILCERTFILES) != caCertFiles.end()) {
			bResult = TRUE;
			wcscat_s(wcRootFileName, sizeof(wcRootFileName) / sizeof(WCHAR), L"\\");
			wcscat_s(wcRootFileName, sizeof(wcRootFileName) / sizeof(WCHAR), EMAILCERTFILES);
			wcscpy_s(m_CertEmailRootFile, sizeof(m_CertEmailRootFile) / sizeof(WCHAR), wcRootFileName);
		} else {
			bResult = FALSE;
		}

		indexOfClose(search_handle);
	} else {
		bResult = FALSE;
	}

	return bResult;
}

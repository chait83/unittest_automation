/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	Processing
/// @n Filename: PipeProcess.h
/// @n Desc:	Provide pipe based data processing RAV, DELAY, Rate of Change etc..
///				
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 8	Stability Project 1.5.1.1	7/2/2011 4:59:43 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 7	Stability Project 1.5.1.0	7/1/2011 4:27:48 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 6	V6 Firmware 1.5		9/23/2008 3:09:30 PM	Build Machine 
//		AMS2750 Merge
// 5	V6 Firmware 1.4		11/28/2006 9:42:25 PM Andy Kassell	Fix
//		rate down alarm, direction of rate change now being calculated
// $
//
// ****************************************************************

#ifndef __PIPEPROCESS_H__
#define __PIPEPROCESS_H__

#include "BasicMaxMinAve.h"

const int MAX_PIPE_SIZE = 20000;		///< Maximum number of readings	
const int MINIMUM_PIPE_SIZE = 2;	///< Pipe cannot be less then 2 readings 

// Pipe processing types
typedef enum {
	PIPE_NONE = 0,						///< No pipe processing type
	PIPE_RAV,							///< Rolling average
	PIPE_DELAY,							///< Delay
	PIPE_RATE_OF_CHANGE,				///< Rate of change

} T_PIPE_PROCESS_TYPE;

//**Class*********************************************************************
///
/// @brief Pipe based processing
/// 
/// Provide basic pipe based processing for RAV, Delay, Rate Of Change etc..
///
//****************************************************************************
class CPipeProcess {
public:
	CPipeProcess();
	~CPipeProcess();

public:		// API methods

	BOOL CreatePipe(T_PIPE_PROCESS_TYPE type, int readings, BOOL preFill);
	void CleanPipe();

	float AddReadingToPipe(float reading);
	float AddReadingAndGetResult(float reading);
	float GetPipeResult();
	void ResetPipe();
	float AddReadingForRateOfChange(float reading);

private:	// Methods

private:	// Member variables

	T_PIPE_PROCESS_TYPE m_pipeType;		///< Type of pipe being supported
	float *m_pPipe;				///< Ptr to the memory allocated for the pipe
	int m_pipeMaxSize;				///< Size of the pipe in number of readings
	int m_pipeOldest;				///< Index of the oldest reading in the pipe
	int m_pipeNewest;		///< Index of the next newest reading in the pipe
	int m_currentReading;	///< Index of the current newest reading in the pipe
	int m_pipeReadings;					///< Number if readings in the pipe
	float m_runningTotal;				///< Running total of readings in pipe
	float m_runningAverage;				///< Running total of readings in pipe
	float m_oldestReading;				///< Oldest reading to be poped off the running total
	BOOL m_preFill;		///< Prefil the Pipe (will fill pipe with first reading)

	float m_maxValue;					///< Max Value in pipe
	float m_minValue;					///< Min Value in pipe

	float m_LastResult;					///< Last result from Pipe

	ULONG m_pipeTick;					///< ongoing tick to stamp max mins for 
	ULONG m_maxTick;					///< Current max Tick
	ULONG m_minTick;					///< Current Min tick
};

#endif //__PIPEPROCESS_H__

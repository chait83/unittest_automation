/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Processing
/// @n Filename: PreTriggercpp
/// @n Desc:	 Manage the pre-trigger functionality
///				 
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  5 Stability Project 1.0.1.3 7/2/2011 4:59:47 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  4 Stability Project 1.0.1.2 7/1/2011 4:38:40 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  3 Stability Project 1.0.1.1 3/17/2011 3:20:35 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  2 Stability Project 1.0.1.0 2/15/2011 3:03:42 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// ****************************************************************

#include "ppl.h"
#include "V6globals.h"
#include "PenControl.h"
#include "TraceDefines.h"
#include "RecSetupCfgMgr.h"
#include "V6AppInterface.h"
#include "PenManager.h"
#include "math.h"
#include "logrec.h"

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif

const int MAX_PTFILE_SIZE = (((PRE_TRIGGER_MAX_MINUTES * 60 * 50) / V6_READINGS_PER_BLOCK) * sizeof(T_LOGRECORD))
		+ sizeof(ULONG);
const ULONG PT_START_SEQUENCE = 0xFFFFFFF;

//**********************************************************************
/// CPenPreTrigger Constructor
/// 
//**********************************************************************
CPenPreTrigger::CPenPreTrigger() {
	m_Buffer = NULL;
	m_Enabled = FALSE;
}

//**********************************************************************
/// Perform a cleanup on the CPreTrigger object, releasing any allocated memory
/// 
/// @return		nothing
//**********************************************************************
void CPenPreTrigger::CleanUp() {
	// If readings buffer is allocated, deallocate
	if (m_Buffer != NULL) {
		delete[] m_Buffer;
	}
	m_Buffer = NULL;

}

//**********************************************************************
/// Allocate the pre-trigger reading buffer
/// 
/// @param[in]	rate - PreTrigger logging rate in tenths of a millisecond
/// @param[in]	minutes - amount of pre-trigger required in minutes
///
/// @return		TRUE if buffer allocation successful, otherwise FALSE
//**********************************************************************
BOOL CPenPreTrigger::AllocateBuffer(ULONG rate, int minutes) {
	BOOL retVal = TRUE;

	// Make sure memory deallcated
	CleanUp();

	// Get total number of readings by dividing the number of minutes required in millisecond tenths by the alarm rate in msec tenths
	m_bufferSize = (minutes * 60 * 10000) / rate;

	// Set alarm rate as ticks from mille seconf tenths
	m_alarmRateTicks = MSEC_TENTHS_TO_TICKS(rate);
	m_alarmRateTenths = rate;

	// Allocate the buffer
	m_Buffer = new float[m_bufferSize];
	if (m_Buffer == NULL) {
		retVal = FALSE;
	}
	m_lastIndex = 0;
	m_numEntries = 0;

	return retVal;
}

//**********************************************************************
/// Generate the filename for the pre-trigger data
/// 
/// @param[in]	penInstance - zero based pen number
///
/// @return		ptr to static filename 
//**********************************************************************
WCHAR* CPenPreTrigger::GetFileName(int penInstance) {
	static WCHAR filename[MAX_PATH];
	// Build filename as P0000nn.ptd where nn is pen number 1 based
	swprintf(filename, L"P%06d.ptd", penInstance + 1);
	return filename;
}

//**********************************************************************
/// Add pre-trigger reading into the cyclic buffer
/// 
/// @param[in]	reading - the current processed reading for the pen
/// @param[in]	lastTime - process time opf the current reading
///
/// @return		nothing
//**********************************************************************
void CPenPreTrigger::AddReading(float reading, LONGLONG lastTime) {
	// Add reading into buffer and increment the latest reading index
	m_Buffer[m_lastIndex++] = reading;
	// Update time the last reading was added
	m_lastTime = lastTime;
	// Check if number of entries has filled the buffer (are we cycling)
	if (m_numEntries < m_bufferSize) {
		// No buffer still not full, increment entries so far
		m_numEntries++;
	}
	// has the index reached the end of the buffer, if so reset to start of buffer
	if (m_lastIndex >= m_bufferSize) {
		m_lastIndex = 0;
	}
}

//**********************************************************************
/// Reset the ore trigger timing and buffers
///
/// @return		nothing
//**********************************************************************
void CPenPreTrigger::ResetBuffer() {
	m_rateDivDownCount = 0;		// Force a reading on the first run through
	m_lastIndex = 0;
	m_lastTime = 0;
	m_numEntries = 0;
}

//**********************************************************************
/// Generate the pre trigger log file and store on internal CF
///
/// @return		nothing
//**********************************************************************
BOOL CPenPreTrigger::GenerateLogFile() {
	BOOL retVal = FALSE;
	if (m_numEntries > 0) {
		// Determine the size of buffer need for processing
		int blocksRequired = m_numEntries / V6_READINGS_PER_BLOCK;
		int remainder = m_numEntries % V6_READINGS_PER_BLOCK;
		if (remainder != 0) {
			blocksRequired++;
		}

		// Allocate the buffer for the log readings
		T_LOGRECORD *logRecBuffer = new T_LOGRECORD[(int) blocksRequired];

		// Setup to start at the beginning of the the log readings, if the number of entries in the pre trigger
		// are less then maximum then 0 is the start, otherwise the m_lastIndex is the start as it is always advance to
		// be the next reading (when cycling it will be the oldest)
		int currentIndex;
		if (m_numEntries < m_bufferSize) {
			// Index is at start, recycling not yet in operation
			currentIndex = 0;
		} else {
			// Index is m_lastIndex as recycling in operation
			currentIndex = m_lastIndex;
		}

		// calculate start time, set start time to the latest time
		CTVtime startTime(m_lastTime);
		// Get the span from start to end in msec tenths
		long timeAdjustment = (m_numEntries - 1) * m_alarmRateTenths;
		// remove the difference from the end time to get start
		startTime -= timeAdjustment;

		USHORT reason = START_RECORDING;		// First record will be a start, subsequent continuation
		ULONG sequnceNo = PT_START_SEQUENCE;	// Set the start sequence number

		T_LOGRECORD *pLogRecord;			// Ptr to the log record in memory to fill
		T_LOGRECORDVARS logVars;			// Instace of log record vars used to hold state when building a log record

		CLogRec logRec;						// Log record object for building a log record

		// Run nthough the total number of blocks required to save out the pre trigger buffer
		// building the blocks into the memory buffer in the fiormat expected by TrendManager Pro.
		for (int blockIndex = 0; blockIndex < blocksRequired; blockIndex++) {
			// *** First we setup the log block in memory

			// Setup pointer to log record memory	
			pLogRecord = &logRecBuffer[blockIndex];

			// Initialise the header for the logging record
			pLogRecord->Header.StartTime = startTime.GetTV5Time();// Set the starttime to the calculated start time for block
			pLogRecord->Header.Session = pGlbSysInfo->GetSessionNumber();	// Set the current session number
			pLogRecord->Header.SeqNo = sequnceNo;				// Set the current sequence number
			pLogRecord->Header.Reason = reason;					// Set the reason

			pLogRecord->Header.PenNumber = (UCHAR) m_penNumber + 1;		// Set bthe 1 based pen number
			pLogRecord->Header.EndTime = startTime.GetTV5Time();	// End time is currently the start time, no readings
			pLogRecord->Header.ControlType = TV5HEADER;				// Absolute header
			pLogRecord->Header.ToControl = 0;						// No embedded controls

			pLogRecord->Header.LastControl = TRUE;						// Assume this is always the last control
			pLogRecord->Header.Incomplete = INCOMPLETE;				// Currently the clock is in an incomplete state
			pLogRecord->Header.Device = OTHER_DEVICE;		// Device type (use other to allow floating point values)
			pLogRecord->Header.DatabaseLevel = 0;						// reserved for TMP use

			pLogRecord->Header.LogStyle = CONTINUOUS;				// Data is continuous
			pLogRecord->Header.Rate = m_alarmRateTenths;		// Set rate as pen alarm rate
			pLogRecord->Header.DataType = EX_FLOAT;					// floating point (4 byte)

			// ** Second, we initialise the logVars which hiolds state about the log record when buuilding, in a traditional slow log environment
			// this is used to fhold NV state about the log block so on a poer interruption it can be refilled, while holding NV state is not possible
			// for pre-trigger information this mechanism needs to be used although in conventional SDRAM

			logVars.FreeDataPos = 0;
			logVars.DataSize = sizeof(float);
			logVars.TimeSize = sizeof(T_TV5TIME);
			logVars.ExtraSize = 0;
			logVars.LastTime = startTime.GetTV5Time();
			logVars.Rate = m_alarmRateTenths;
			logVars.CurrentControl = (T_GENERALCONTROL*) pLogRecord;

			// Third, fill the log block with the readings from the pre-trigger buffer, readings will be added until the log block is full
			// or the end of the pre-trigger buffer is reached. Either way once complete the block will be CRC'd.

			BOOL logblockFull = FALSE;
			do {
				// Add a reading to the log block
				logblockFull = logRec.AddContReading(&logVars, pLogRecord, m_Buffer[currentIndex++]);
				// Is the log block full?
				if (logblockFull == TRUE) {
					// Yes CRC the completed log block record.
					CrcInsert((UCHAR*) pLogRecord, sizeof(T_LOGRECORD));
				}
				// Move the strattime of the reading on by a readings worth.
				startTime += (long) m_alarmRateTenths;

				// Check if we have hit the last reading in the pre-trigger buffer
				if (currentIndex == m_lastIndex) {
					// Yes, close the block if it is not complete (i.e. our last reading lines up with last block reading)
					if (logblockFull != TRUE) {
						// Complete and CRC the block 
						logRec.CompleteLogBlock(&logVars, pLogRecord, &logVars.LastTime, TRUE);
						CrcInsert((UCHAR*) pLogRecord, sizeof(T_LOGRECORD));
						logblockFull = TRUE;
					}
				}
				// Have we reached the rollover point for the cyclic pre-trigger buffer?
				if (currentIndex >= m_bufferSize) {
					// Yes, reset to start of buffer to next reading
					currentIndex = 0;
				}
			} while (logblockFull != TRUE);

			reason = CONTINUATION;	// First record will be a start, subsequent will be continuation
			sequnceNo++;				// Move to next sequence number
		}

		// ** Fourth, Write the file to disk, the log records have been correctly formatted into a buffer, we must now save to
		// the internal CF, as the files are pre-allocated on demand to avoid fragmentation the number of blocks stored must
		// be recorded and this is done in the first 4 bytes of the file. 

		FileException kEx;							// File exception object
		WCHAR PathAndFileName[MAX_PATH] = { 0 };		// Path holder for full path
		CStorage dataFile;							// Data writing object

		// Build the full path for the pre-trigger data file
		pDALGLB->BuildPath(IDS_INTERNAL_SD, IDS_LOG_DATA, CPenPreTrigger::GetFileName(m_penNumber), PathAndFileName,
		MAX_PATH);

		// Check if the file already exists
		if (!dataFile.FileExists(PathAndFileName)) {
			// the file does not exist therefore create it
			// to avoid fragmentation this file is always present and is fixed in length MAX_PTFILE_SIZE
			if (dataFile.Open(PathAndFileName,  | QFile::ReadWrite, &kEx)) {
				dataFile.SetLength(MAX_PTFILE_SIZE);
				retVal = TRUE;
			} else {
				// Error create/open error issue
				QString   errString;
				errString.asprintf(L"Could not create file %s", CPenPreTrigger::GetFileName(m_penNumber));
				PreTriggerDataFileError(errString);
			}
		} else {
			// The file already exists so we need to check the size of the file to make sure a software modification has not extended this
			if (dataFile.GetFileSize(PathAndFileName) != MAX_PTFILE_SIZE) {
				// File size has changed, resize the file.
				dataFile.SetLength(MAX_PTFILE_SIZE);
			}
			// Attempt to open the file
			if (dataFile.Open(PathAndFileName, QFile::ReadWrite, &kEx)) {
				retVal = TRUE;
			} else {
				// Error open error issue
				QString   errString;
				errString.asprintf(L"Could not open existing file %s", CPenPreTrigger::GetFileName(m_penNumber));
				PreTriggerDataFileError(errString);
			}
		}
		// If the file open successfully, save the infotmation into the file
		if (retVal == TRUE) {
			// Make sure we are at the start of the file
			dataFile.seek(0);

			// Write out the small 4 byte header consisting of a ULONG which is the number of 512 byte blocks we are saving
			ULONG numBlock = (ULONG) blocksRequired;
			dataFile.Write(&numBlock, sizeof(ULONG));

			// Write out the buffer of log records
			dataFile.Write(logRecBuffer, sizeof(T_LOGRECORD) * (int) blocksRequired);
			dataFile.Close();
		}
		// De-allocate the temporary log record buffer
		delete[] logRecBuffer;
	}
	return retVal;
}

//**********************************************************************
/// Build and post error for pre-trigger file handling
/// 
/// @param[in]	rstrERROR - error message to display
///
/// @return		nothing
//**********************************************************************
void CPenPreTrigger::PreTriggerDataFileError(const QString   &rstrERROR) {
	// log the error message
	QString   errString;
	errString.asprintf(L"PreTrigger Data File Error - %s", rstrERROR);
	LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, errString);
	// halt the program thus forcing a restart which should recreate the TUS data file
	V6CriticalMessageBox(NULL, rstrERROR, L"PreTrigger Data File Error", MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST);
}


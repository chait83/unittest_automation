/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Processing
/// @n Filename: Alarms.cpp
/// @n Desc:	 Manage Alarms within the recorder system
///				 
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  67  Stability Project 1.62.1.3 7/2/2011 4:55:18 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  66  Stability Project 1.62.1.2 7/1/2011 4:37:55 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  65  Stability Project 1.62.1.1 3/17/2011 3:20:08 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  64  Stability Project 1.62.1.0 2/15/2011 3:02:05 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// ****************************************************************

#include "V6defines.h"
#include "Alarms.h"
#include "TraceDefines.h"
#include "FFConversionInfo.h"
#include "PenControl.h"
#include "EventManager.h"
#include "EmailData.h"
#include "SMTPThread.h"
#include "StringUtils.h"
CAlarmOverview GlbAlarmOverview;

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif

BYTE *CAlarm::pAlarmNVBaseAddress = NULL;
T_NV_ALARM_DATA dummyAlarmNV;

const USHORT ROGUE_ALARM_STATE = 2;		// Rogue alarm status, nither true or false will force alarm to be calculated 

//**********************************************************************
/// CPenManager constructor
///
//**********************************************************************
CAlarm::CAlarm() {
	m_Active = FALSE;
	m_Enabled = FALSE;
	m_pFuncProcess = &CAlarm::ProcessDummy;
	m_InAlarmNow = FALSE;
	m_AlarmStatusLastTime = ROGUE_ALARM_STATE;
	m_pDevPenDataItem = FALSE;
	m_dampingStartTime = 0;
	m_StartReflash = TRUE;
	m_relaysAsserted = FALSE;
	m_reflashStartTime = 0;
	m_ActivateRelays = FALSE;
	m_pDigUserEnableBy = NULL;
	m_pDigUserSetOuptuts = NULL;
	m_CurrentDeviationAbove = TRUE;
	m_pNVData = &dummyAlarmNV;
	m_FirstDIRun = FALSE;
	m_OldMarkChart = FALSE;
	m_OldGroupNumber = PEN_GROUP_MAX; // not valid first time through

}

//**********************************************************************
/// CPenManager constructor
///
//**********************************************************************
CAlarm::~CAlarm() {
	// Delete dynamically allocated user class instances
	if (m_pDigUserEnableBy != NULL) {
		delete m_pDigUserEnableBy;
	}
	if (m_pDigUserSetOuptuts != NULL) {
		delete m_pDigUserSetOuptuts;
	}
	m_ratePipe.CleanPipe();

}

//**********************************************************************
/// Initialise the Alarm to the correct Pen and Alarm number
/// 
/// @return		T_ALARM_CONTROL_RETURN as status of call
//**********************************************************************
void CAlarm::InitialiseAlarmNonVolatile() {
	CSRAMManager *pSRAM = CSRAMManager::GetHandle();

	CSRAMRegion *pRegion = NULL;
	// Request a ptr to the CSRAMRegion instance for the corrisponding regionIdent
	CSRAMManager::regionError requestReturn = pSRAM->RequestRegion(REGION_ALARMS, &pRegion);

	if (requestReturn != CSRAMManager::REGION_OKAY) {
		qDebug((" CRITICAL error\n"));
		return;
	}

	CAlarm::pAlarmNVBaseAddress = reinterpret_cast<BYTE*>(pRegion->GetAddress());

	int maxSizeRequired = (sizeof(T_NV_ALARM_DATA) * V6_MAX_PENS * V6_MAX_ALARMS);
	if (maxSizeRequired > pRegion->GetAvailableBytes()) {
		qDebug((" CRITICAL error SRAM region too small for required size\n"));
	}
	qDebug("Alarm Non-Volatile area = %dbytes required space %dbytes\n", pRegion->GetAvailableBytes(), maxSizeRequired);

	if ( pSYSTEM_INFO->IsDataResetRequested() == TRUE) {
		// A data reset is required so delete Alarm status
		pRegion->ClearRegion();
	}

	// Check if this is the first time the region has been used after power on
	if (pRegion->GetAutoState() == SRAM_STATE_FIRSTUSE) {
		pRegion->SetAutoStateToNormal();	// Return to normal state, first time power on for region
	}
}

//**********************************************************************
/// Initialise the Alarm to the correct Pen and Alarm number
/// 
/// @param[in]	penNumber - number of pen that the alarm belongs to. 0 to MAX_PENS-1
///	@param[in]	alarmNumber - number of alarm of the pen penNumber. 0 to MAX_ALARMS-1
///
/// @return		T_ALARM_CONTROL_RETURN as status of call
/// 
//**********************************************************************
T_ALARM_CONTROL_RETURN CAlarm::IntialiseAlarm(USHORT penNumber, USHORT alarmNumber, CPenControl *pPenCtrl) {
	T_ALARM_CONTROL_RETURN retVal = RET_ALARM_OKAY;
	m_pPenCtrl = pPenCtrl;		// Controlling Pen
	// If Pen number and Alarm number are within limits, use.	
	if (penNumber < V6_MAX_PENS && alarmNumber < V6_MAX_ALARMS) {
		m_penNumber = penNumber;
		m_alarmNumber = alarmNumber;

		// Get handle on Pen Data Item for this alarm
		m_pPenDataItem = (CDataItemPen*) pGlbDIT->GetDataItemPtr(DI_PEN, DI_PEN_READING, m_penNumber);
		if (m_pPenDataItem == NULL) {
			LOG_CRTL(TRACE_PROCESSING, "Pen Data item does not exist %d \n", m_penNumber);
			retVal = RET_ALARM_INIT_FAILED;
		}

		// Get handle on the related Alarm Data Item
		m_pAlarmDataItem = (CDataItemAlarm*) pGlbDIT->GetDataItemPtr(DI_ALARM, m_alarmNumber, m_penNumber);
		if (m_pAlarmDataItem == NULL) {
			LOG_CRTL(TRACE_PROCESSING, "Alarm Data item %d does not exist for pen %d \n", m_alarmNumber, m_penNumber);
			retVal = RET_ALARM_INIT_FAILED;
		}

		// Configure alarm from NV
		int offset = (sizeof(T_NV_ALARM_DATA) * penNumber * V6_MAX_ALARMS) + (sizeof(T_NV_ALARM_DATA) * alarmNumber);
		m_pNVData = reinterpret_cast<T_NV_ALARM_DATA*>(CAlarm::pAlarmNVBaseAddress + offset);
		if (m_pNVData->State == DISTAT_INVALID) {
			m_pNVData->State = DISTAT_OUT_OF_ALARM;
		}
		m_pAlarmDataItem->SetStatus(static_cast<T_DATAITEM_STATUS>(m_pNVData->State));

	} else {
		retVal = RET_ALARM_INIT_FAILED;
	}

	return retVal;
}

//**********************************************************************
/// Set the configuration in the Alarm.
/// 
/// @param[in]	pPenCfg - ptr to pen configuration in CMM for this alarm
///
/// @return		T_ALARM_CONTROL_RETURN as status of call
/// 
//**********************************************************************
T_ALARM_CONTROL_RETURN CAlarm::SetAlarmFromConfig(T_PPEN pPenCfg) {
	T_ALARM_CONTROL_RETURN retVal = RET_ALARM_OKAY;

	// Set-up a pointer to the Alarm configuration
	m_pPenCfg = pPenCfg;
	m_pAlarmCfg = &pPenCfg->Alm[m_alarmNumber];

	// Turn off processing for this alarm. these will be enabled depending on new config
	m_pFuncProcess = &CAlarm::ProcessDummy;

	if (m_pPenCfg->Enabled) {
		if (m_pAlarmCfg->EnableType != ALARM_DISABLED) {
			m_Enabled = TRUE;

			// Is the Alarm enabled by a digital input
			if (m_pAlarmCfg->EnableType == ALARM_ENABLED_BY_DI) {
				// Yes, Alarm is enabled by DI, setup a digital user interface with the data item table (if does not already exist)
				if (m_pDigUserEnableBy == NULL) {
					m_pDigUserEnableBy = new CDataItemDigitalIOUser;
					m_pDigUserEnableBy->Initialise();
				}
				m_pDigUserEnableBy->BuildCacheFromMask(&m_pAlarmCfg->DigInEnable);
			}

			// Load Alarm level into configLevel holder, deviation alarm will differ
			float configLevel = m_pAlarmCfg->Level;
			if ((m_pAlarmCfg->Type == ALARM_TYPE_DEVIATION) || (m_pAlarmCfg->Type == ALARM_TYPE_RATEUP)
					|| (m_pAlarmCfg->Type == ALARM_TYPE_RATEDOWN)) {
				configLevel = m_pAlarmCfg->DevLevel;
			}

			// Use the current alarm level
			float levelToUse = configLevel;

			// Do we need to reset the user level? Check if the config level has changed, the type has changed or 
			// the user is not allowed to change
			if (m_pNVData->OriginalLevel != configLevel || m_pAlarmCfg->ChangeAllow == FALSE
					|| m_pNVData->Type != m_pAlarmCfg->Type) {
				// Level reset required
				m_pNVData->OriginalLevel = configLevel;
				m_pNVData->UserLevel = configLevel;
			}
			// Has the alarm type been changed? Yes, so we need to reset the counter
			if (m_pNVData->Type != m_pAlarmCfg->Type) {
				// Reset the counter and the type of alarm.
				ResetAlarmCounter();
				m_pNVData->Type = m_pAlarmCfg->Type;
			}

			// If changes are allowed, use the user level.
			if (m_pAlarmCfg->ChangeAllow == TRUE) {
				// if we allow the alarm configuration to be changed, use the version from NV
				levelToUse = m_pNVData->UserLevel;
			}
			UpdateUserLevel(levelToUse);		// Store updated level

			// Configure the Hysteresis for the channel
			ConfigureHysteresis();

			// Configure the damping for the channel
			ConfigureDamping();

			// Clear out rate of change Pipe
			m_secsPerReading = 1;
			m_rateCountDown = 0;
			m_ratePipe.CleanPipe();
			m_rateAve.ResetAverage();

			// Configure alarm setting based on type of alarm
			switch ((T_ALARM_TYPES) m_pAlarmCfg->Type) {
			case ALARM_TYPE_HIGH:
				m_pFuncProcess = &CAlarm::ProcessHighAlarm;		// Set ptr to High alarm processing function
				break;
			case ALARM_TYPE_LOW:
				m_pFuncProcess = &CAlarm::ProcessLowAlarm;		// Set ptr to Low Alarm processing function
				break;
			case ALARM_TYPE_DEVIATION:
				m_pFuncProcess = &CAlarm::ProcessDeviationAlarm;	// Set ptr to Deviation alarm processing function
				retVal = ConfigureDeviationAlarm();
				break;
			case ALARM_TYPE_RATEUP:
			case ALARM_TYPE_RATEDOWN:
				m_pFuncProcess = &CAlarm::ProcessRateAlarm;		// Set ptr to Rate up/down processing function
				retVal = ConfigureRateAlarm();
				break;
			default:
				break;
			}

			// Configure digital output options if required
			if (m_pAlarmCfg->RelayOuts.L[DIGITALS_1_TO_31] != 0 || m_pAlarmCfg->RelayOuts.L[DIGITALS_32_TO_49] != 0) {
				m_ActivateRelays = TRUE;
				// At least one replay output is configured, so make sure user object exists and build cache
				if (m_pDigUserSetOuptuts == NULL) {
					m_pDigUserSetOuptuts = new CDataItemDigitalIOUser;
					m_pDigUserSetOuptuts->Initialise();
				}
				m_pDigUserSetOuptuts->BuildCacheFromMask(&m_pAlarmCfg->RelayOuts);
			} else {
				m_ActivateRelays = FALSE;
			}

			//Set alarm to active after building cache 
			if (m_pAlarmCfg->EnableType != ALARM_ENABLED_BY_DI) {
				// No, alarm is always active (processed) so activate it
				SetAlarmToActive(TRUE);
			} else {
				m_FirstDIRun = TRUE;	// run set alarm to active later, if appropriate
			}

		} else {
			// Pen enabled, but alarm is not, make sure it is disabled		
			ResetAlarmToNonActive(TRUE);
			m_Enabled = FALSE;
		}
	} else {
		// Pen is not enabled, so alarm cannot be enabled, make sure it is disabled		
		ResetAlarmToNonActive(TRUE);
		m_Enabled = FALSE;
	}

	return retVal;
}

//**********************************************************************
/// Configure any hysteresis working variables up front if enabled
///
/// @return		T_ALARM_CONTROL_RETURN as status of call
/// 
//**********************************************************************
float CAlarm::CalcEngRangeFromPercentageRange(float percentValue) {
	// Setup a conversion structure to map a %age range to then engineering value range 
	class CFFConversionInfo conv;
	conv.CalcFConvInfo(PERCENT_0, PERCENT_100, m_pPenCfg->Scale.Zero, m_pPenCfg->Scale.Span);
	// Store the engineering value of the hysteresis level
	float engValue = conv.CalcDestMagnitude(percentValue);
	return engValue;
}

//**********************************************************************
/// Configure any hysteresis working variables up front if enabled
///
/// @return		T_ALARM_CONTROL_RETURN as status of call
/// 
//**********************************************************************
T_ALARM_CONTROL_RETURN CAlarm::ConfigureHysteresis() {
	T_ALARM_CONTROL_RETURN retVal = RET_ALARM_OKAY;
	m_hystLevelInEngValue = 0;
	if (m_pAlarmCfg->UseHyst) {
		// Store the engineering value of the hysteresis level
		m_hystLevelInEngValue = CalcEngRangeFromPercentageRange(m_pAlarmCfg->HystLevel);
		//qDebug("Pen(%d)Alarm(%d) Hysteresis %f%% is %f eng value \n", m_penNumber+1, m_alarmNumber+1, m_pAlarmCfg->HystLevel, m_hystLevelInEngValue );
	}
	return retVal;
}

//**********************************************************************
/// Configure any Damping working variables up front if enabled
///
/// @return		T_ALARM_CONTROL_RETURN as status of call
/// 
//**********************************************************************
T_ALARM_CONTROL_RETURN CAlarm::ConfigureDamping() {
	T_ALARM_CONTROL_RETURN retVal = RET_ALARM_OKAY;

	m_StartDamping = TRUE;

	return retVal;
}

const int RATE_PIPE_TARGET_LENGTH = 60;

//**********************************************************************
/// Configure a rate up or rate down alarm
/// 
/// @return		T_ALARM_CONTROL_RETURN as status of call
/// 
//**********************************************************************
T_ALARM_CONTROL_RETURN CAlarm::ConfigureRateAlarm() {
	m_secsPerReading = 1;
	int numReadings = 1;

	// Pipe length exceeded so gear rate down
	m_secsPerReading = (m_pAlarmCfg->DampSecs / RATE_PIPE_TARGET_LENGTH) + 1;
	numReadings = m_pAlarmCfg->DampSecs / m_secsPerReading;

	// Protect invalid entry
	if (numReadings == 0) {
		numReadings = 1;
	}
	// Create the pipe for rate of change readings
	m_ratePipe.CreatePipe(PIPE_RATE_OF_CHANGE, numReadings, TRUE);
	return RET_ALARM_OKAY;
}

//**********************************************************************
/// Configure a deviation alarm
/// 
/// @return		T_ALARM_CONTROL_RETURN as status of call
/// 
//**********************************************************************
T_ALARM_CONTROL_RETURN CAlarm::ConfigureDeviationAlarm() {
	T_ALARM_CONTROL_RETURN retVal = RET_ALARM_OKAY;

	// Get handle on Pen Data Item that we want to compare with for a deviation alarm, Pen in config is 0 based
	m_pDevPenDataItem = (CDataItemPen*) pGlbDIT->GetDataItemPtr(DI_PEN, DI_PEN_READING, m_pAlarmCfg->DevPenNum);
	if (m_pDevPenDataItem == NULL) {
		LOG_CRTL(TRACE_PROCESSING, "Deviation Pen Data item does not exist %d \n", m_penNumber);
		retVal = RET_ALARM_CFG_FAILED;
	}

	return retVal;
}

//**********************************************************************
/// Update the Pen Alarm status with the individual alarm status.
/// 
/// @return		nothing
//**********************************************************************
void CAlarm::UpdateCommonPenAlarm() {
	// If the general "in alarm" state is on for an alarm then add to running total the Pen alarm status
	if (m_pAlarmDataItem->GetAlarmStatus() == ASTAT_IN_ALARM) {
		// Get current number of Alarms "in alarm" on the pen and add this one, setting new total
		m_pPenDataItem->SetAlarmStatus(m_pPenDataItem->GetAlarmStatus() + 1);

		// Is the alarm is set to change the logging speed and make sure the alarm is still inside (as we
		// don't want to log at alarm speed when alarm is not acknowledged.
		if (m_pAlarmCfg->ChangeLog && m_pAlarmDataItem->GetStatus() != DISTAT_OUT_OF_ALARM_NOT_ACKED) {
			// Yes, register that an alarm controlling logging speed is in alarm
			m_pPenCtrl->GetLoggingPtr()->RegisterAlarmLogRateRequired();
		}
	}
	// Check for alarms that are not acknowledged and build up total number not ack'd
	if (m_pAlarmDataItem->GetStatus() == DISTAT_IN_ALARM_NOT_ACKED
			|| m_pAlarmDataItem->GetStatus() == DISTAT_OUT_OF_ALARM_NOT_ACKED) {
		// Add ack alarm to running total
		m_pPenDataItem->SetAlarmStatus(m_pPenDataItem->GetAlarmAckStatus() + 1);
	}
}

//**********************************************************************
/// Process alarm body used as function pointer, this is a dummy
/// that does no processing and the m_pFuncProcess 
/// 
/// @return		T_ALARM_CONTROL_RETURN as status of call
/// 
//**********************************************************************		
T_ALARM_CONTROL_RETURN CAlarm::ProcessAlarm() {
	T_ALARM_CONTROL_RETURN retVal = RET_ALARM_OKAY;
	if (m_pAlarmCfg->EnableType == ALARM_ENABLED_BY_DI) {
		// Check to see if any of the enabling digital inputs is asserted
		if (m_pDigUserEnableBy->AnyOfTheseDigitalInputAsserted(NULL)) {
			// Yes, at least one is asserted so alarm enabled, check if it is already active
			// deal with first-time initialisation if necessary:
			if (m_FirstDIRun == TRUE) {
				SetAlarmToActive(TRUE);	// set alarm to active, also set relays if necessary
				m_FirstDIRun = FALSE; // reset flag - first time through was this time
			} else if (m_Active == FALSE) {
				// Alarm was previously inactive, so set as an active alarm
				SetAlarmToActive(FALSE);	// set alarm to active					
			}
			// check alarm levels to decide if alarm is in alarm
			retVal = (this->*m_pFuncProcess)();
			// common processing will follow specific alarm assessment
		} else {
			// No, no DIs set, so the alarm should not be active - check if it was and set to inactive
			if (m_FirstDIRun == TRUE) {
				ResetAlarmToNonActive(FALSE); // reset alarm to non-active, and reset relays as required
				m_FirstDIRun = FALSE; // reset flag - first time through was this time
			} else if (m_Active == TRUE) {
				// Drop out of alarm
				m_InAlarmNow = FALSE;	// no need to evaluate levels - DI state dictates out of alarm
				// Perform common processing, apply damping and run state machine to set Alarm status in DIT
				retVal = CommonProcessing();
				ResetAlarmToNonActive(FALSE); // reset alarm to non-active						
			}
		}

	} else {
		if (m_Active == TRUE) {
			retVal = (this->*m_pFuncProcess)();
		}
	}
	return retVal;
}
;

//**********************************************************************
/// Process alarm body used as function pointer, this is a dummy
/// that does no processing and the m_pFuncProcess 
/// 
/// @return		T_ALARM_CONTROL_RETURN as status of call
/// 
//**********************************************************************
T_ALARM_CONTROL_RETURN CAlarm::ProcessDummy() {
	// Use to catch uninitialised alarms that are being processed.
	qDebug("Dummy Process Alarm being called for Pen %d Alarm %d \n", m_penNumber, m_alarmNumber);
	return RET_ALARM_OKAY;
}

//**********************************************************************
/// Process alarm body called as function pointer, process a high alarm
/// 
/// @return		T_ALARM_CONTROL_RETURN as status of call
/// 
//**********************************************************************
T_ALARM_CONTROL_RETURN CAlarm::ProcessHighAlarm() {
	T_ALARM_CONTROL_RETURN retVal = RET_ALARM_OKAY;

	// Test if the current Pen value is over the alarm level?
	if (m_pPenDataItem->GetFPValue() > m_pAlarmDataItem->GetFPValue()) {
		// Yes, Pen is over alarm level, indicate "in alarm"
		m_InAlarmNow = TRUE;
	}
	// Otherwise check that the current Pen value is lower then the alarm level including hysteresis value?
	else if (m_pPenDataItem->GetFPValue() <= (m_pAlarmDataItem->GetFPValue() - m_hystLevelInEngValue)) {
		// Yes, Pen is under alarm level and hysteresis so is "out of alarm"
		m_InAlarmNow = FALSE;
	}
	// Perform common processing, apply damping and run state machine to set Alarm status in DIT
	retVal = CommonProcessing();

	return retVal;
}

//**********************************************************************
/// Process alarm body called as function pointer, process a low alarm
/// 
/// @return		T_ALARM_CONTROL_RETURN as status of call
/// 
//**********************************************************************
T_ALARM_CONTROL_RETURN CAlarm::ProcessLowAlarm() {
	T_ALARM_CONTROL_RETURN retVal = RET_ALARM_OKAY;

	// Test if the current Pen value is under the alarm level?
	if (m_pPenDataItem->GetFPValue() < m_pAlarmDataItem->GetFPValue()) {
		// Yes, Pen under alarm level, indicate "in alarm"
		m_InAlarmNow = TRUE;
	}
	// Otherwise check that the current Pen value is higher then the alarm level including hysteresis value?
	else if (m_pPenDataItem->GetFPValue() >= (m_pAlarmDataItem->GetFPValue() + m_hystLevelInEngValue)) {
		// Yes, Pen is over alarm level and hysteresis so is "out of alarm"
		m_InAlarmNow = FALSE;
	}
	// Perform common processing, apply damping and run state machine to set Alarm status in DIT
	retVal = CommonProcessing();

	return retVal;
}

//**********************************************************************
/// Process alarm body called as function pointer, process a deviation alarm
/// 
/// @return		T_ALARM_CONTROL_RETURN as status of call
/// 
//**********************************************************************
T_ALARM_CONTROL_RETURN CAlarm::ProcessDeviationAlarm() {
	T_ALARM_CONTROL_RETURN retVal = RET_ALARM_OKAY;

	// Get the current value of the Pen we wnat to do a comparison with
	float otherPenLevel = m_pDevPenDataItem->GetFPValue();

	// Test if the current pen value is outside of the other pens current level and deviation "band"
	if (m_pPenDataItem->GetFPValue() > (otherPenLevel + m_pAlarmDataItem->GetFPValue())) {
		m_InAlarmNow = TRUE;	// Yes it is, indicate "in alarm"	
		if (m_CurrentDeviationAbove == FALSE) {
			// The deviation was previusly below, now we are above, if this change happened without passing though the
			// band (i.e. did not go out of alarm) then damping will not be reset correctly, so reset it 
			m_CurrentDeviationAbove = TRUE;		// Indicate we are currently in alarm above the deviation band
			m_StartDamping = TRUE;
		}
	} else if (m_pPenDataItem->GetFPValue() < (otherPenLevel - m_pAlarmDataItem->GetFPValue())) {
		m_InAlarmNow = TRUE;	// Yes it is, indicate "in alarm"	
		if (m_CurrentDeviationAbove == TRUE) {
			// The deviation was previusly above, now we are below, if this change happened without passing though the
			// band (i.e. did not go out of alarm) then damping will not be reset correctly, so reset it 
			m_CurrentDeviationAbove = FALSE;		// Indicate we are currently in alarm above the deviation band
			m_StartDamping = TRUE;
		}
	} else {
		// No it is not, it's within the band so "out of alarm"
		m_InAlarmNow = FALSE;
	}

	// Perform common processing, apply damping and run state machine to set Alarm status in DIT
	retVal = CommonProcessing();

	return retVal;
}

//**********************************************************************
/// Process alarm body called as function pointer, process a rate up alarm
/// 
/// @return		T_ALARM_CONTROL_RETURN as status of call
/// 
//**********************************************************************
T_ALARM_CONTROL_RETURN CAlarm::ProcessRateAlarm() {
	T_ALARM_CONTROL_RETURN retVal = RET_ALARM_OKAY;

	// Maintain average for all redaing within the rate alarm sample period (min 1 second)
	m_rateAve.DoAverageForReading(m_pPenDataItem->GetFPValue());
	if (--m_rateCountDown <= 0) {
		// Read to add a reading, add the average to the pipe
		float rateDiff = m_ratePipe.AddReadingForRateOfChange(m_rateAve.GetAverage());
		m_rateAve.ResetAverage();

		// Assign data item with rate of change
		m_pAlarmDataItem->SetRateOfChange(rateDiff);

		// Check the rate has not exceeded the level set
		if (m_pAlarmCfg->Type == ALARM_TYPE_RATEUP) {
			if (rateDiff > m_pAlarmCfg->DevLevel) {
				m_InAlarmNow = TRUE;
			} else if (rateDiff <= m_pAlarmCfg->DevLevel - m_hystLevelInEngValue) {
				m_InAlarmNow = FALSE;
			}
		} else	// Rate down alarm
		{
			if (rateDiff < -m_pAlarmCfg->DevLevel) {
				m_InAlarmNow = TRUE;
			} else if (rateDiff >= -(m_pAlarmCfg->DevLevel - m_hystLevelInEngValue)) {
				m_InAlarmNow = FALSE;
			}
		}

		// Relead next rate request
		m_rateCountDown = m_secsPerReading * pSYSTIMER->GetProcessSlicesPerSecond();
	}

	// Perform common processing, apply damping and run state machine to set Alarm status in DIT
	retVal = CommonProcessing();

	return RET_ALARM_OKAY;
}

//**********************************************************************
/// Common alarm processing, run damping and execute state machine
/// if necessary
/// 
/// @return		T_ALARM_CONTROL_RETURN as status of call
/// 
//**********************************************************************
T_ALARM_CONTROL_RETURN CAlarm::CommonProcessing() {
	T_ALARM_CONTROL_RETURN retVal = RET_ALARM_OKAY;

	// If the user has manually acknowledged an alarm
	if (m_requestAcknowledge == TRUE) {
		// Only allow acknowledgement of latched alarms, unlatched alarms are fully automatic as V5
		if (m_pAlarmCfg->Latched) {
			// An ackowledge has been requested, modify state to acknowledged depending on current state
			switch (m_pAlarmDataItem->GetStatus()) {
			// The alarm is in alarm and not acknowledge, set to in alarm but acknowledged state
			case DISTAT_IN_ALARM_NOT_ACKED:
				UpdateStatus(DISTAT_IN_ALARM_ACKED);
				LogMessage(MSGLISTSER_ALARM_ACK_WHILE_IN, IDS_ALARM_MESSAGE_IN_ALARM_ACK);		/// Send to message list
				SendEmail (IDS_ALARM_MESSAGE_IN_ALARM_ACK);
				pEVENTS->AlarmTransitionCause(m_penNumber, m_alarmNumber, evtCauseAlarmACK);	// Send to event system
				AssertClearRelays(CDataItemDigitalIOUser::digCLEAR);
				break;

				// The alarm is out of alarm but not acknowledged, return to standard out of alarm state
			case DISTAT_OUT_OF_ALARM_NOT_ACKED:
				UpdateStatus(DISTAT_OUT_OF_ALARM);
				m_pAlarmDataItem->SetAlarmStatus(ASTAT_OUT_ALARM);			// Remove general alarm state from alarm.
				LogMessage(MSGLISTSER_ALARM_ACK_WHILE_OUT, IDS_ALARM_MESSAGE_ACK);
				pEVENTS->AlarmTransitionCause(m_penNumber, m_alarmNumber, evtCauseAlarmACK);	// Send to event system
				AssertClearRelays(CDataItemDigitalIOUser::digCLEAR);
				break;

			default:
				break;
			}
		}
		m_requestAcknowledge = FALSE;	// Clear Acknowledgement request
	}
	if (m_requestResetCounter == TRUE) {
		ResetAlarmCounter();
		m_requestResetCounter = FALSE;
	}

	// Process damping by time, this may change the m_InAlarmNow state if damping enabled and not timed out
	ProcessDamping();

	// Process reflash timer, this may change the alarm state back to in alarm
	ProcessReflash();

	// If the alarm state has changed call the State machine to progress the states
	if (m_InAlarmNow != m_AlarmStatusLastTime) {
		retVal = AlarmStateMachine();
	}

	return retVal;
}

//**********************************************************************
/// Request an alarm acknowledge on the next process, will only happen
/// if alarm is enabled and running
///
/// @return		nothing
/// 
//**********************************************************************
void CAlarm::RequestAcknowledge() {
	// Set the request acknoledge if the alarm is enabled
	if (m_Enabled) {
		m_requestAcknowledge = TRUE;
	}
}

//**********************************************************************
/// Assert or clear relay outputs if they have been configured
/// this will track asserts and clears to avoid multiple asserts or clears
///
/// @param[in]	state - CDataItemDigitalIOUser::digassert or CDataItemDigitalIOUser::digCLEAR
///
/// @return		nothing
//**********************************************************************
void CAlarm::AssertClearRelays(CDataItemDigitalIOUser::T_DIG_STATE state) {
	if (m_ActivateRelays == TRUE) {
		// Are we asserting digitals
		if (state == CDataItemDigitalIOUser::digassert) {
			// if the relays have not already been asserted, assert the relays
			if (m_relaysAsserted == FALSE) {
				m_pDigUserSetOuptuts->SetAlarmDigitalOutputs(CDataItemDigitalIOUser::digassert, NULL);
				m_relaysAsserted = TRUE;
			}
		} else if (state == CDataItemDigitalIOUser::digCLEAR) {
			// Clearing digitals, only if they have not already been cleared
			if (m_relaysAsserted == TRUE) {
				m_pDigUserSetOuptuts->SetAlarmDigitalOutputs(CDataItemDigitalIOUser::digCLEAR, NULL);	//MarkD
				m_relaysAsserted = FALSE;
			}
		}
	}

}

//**********************************************************************
/// Clear relay outputs: without affecting outputCache (used on start-up only)
///
///
/// @return		nothing
//**********************************************************************
void CAlarm::ClearRelays(void) {
	if (m_ActivateRelays == TRUE) {
		// Clearing digitals - regardless of whether thay were written earlier or not		
		m_pDigUserSetOuptuts->SetDigitalOutputs(CDataItemDigitalIOUser::digCLEAR, NULL);
		m_relaysAsserted = FALSE;
	}

}

//**********************************************************************
/// Clear old relay outputs: used on startup only (does not affect outputCache) to clear disabled alarm relays
///
///
/// @return		nothing
//**********************************************************************
void CAlarm::ClearOldRelays(void) {

	// Clear any associated relay outputs
	if (m_relaysAsserted == TRUE) {
		if (m_pDigUserSetOuptuts != NULL) {
			m_pDigUserSetOuptuts->ClearDigitalState();
		}
		m_relaysAsserted = FALSE;
	}

}

//**********************************************************************
/// Assert relay outputs: used on startup (or commit) only (does not affect outputCache)
///
///
/// @return		nothing
//**********************************************************************
void CAlarm::AssertRelays(void) {
	if (m_ActivateRelays == TRUE) {
		// Assert digitals - regardless of whether thay were written earlier or not			
		m_pDigUserSetOuptuts->SetDigitalOutputs(CDataItemDigitalIOUser::digassert, NULL);
		m_relaysAsserted = TRUE;	// confirm asserted status
	}

}

//**********************************************************************
/// The alarm state machine will track an alarms state and alter it
/// depending on current process condition, this will handle progression
/// of user acknowledgements etc.. This function will only be called when
/// there is a change of alarm state form the ProcessXXXAlarm calls
///
/// @return		T_ALARM_CONTROL_RETURN as status of call
/// 
//**********************************************************************
T_ALARM_CONTROL_RETURN CAlarm::AlarmStateMachine() {
	T_ALARM_CONTROL_RETURN retVal = RET_ALARM_OKAY;
	// The DIT status is being used to determine the overall status of the alarm

	// Are we "in alarm"
	if (m_InAlarmNow) {
		// Yes, just gone into alarm so Add alarm to tally of "in alarms" and marked on chart if configured. Set to initial unacknowledged status
		pALARM_OVERVIEW->AddInAlarm();
		if (m_pAlarmCfg->MarkChart) {
			pALARM_OVERVIEW->AddChartInAlarm(m_pPenCfg->GroupNumber);
			m_OldMarkChart = TRUE;	// remember old status to clear alarm background if necessary
		} else
			m_OldMarkChart = FALSE; // here we know we don't need it any more

		IncrementAlarmCounter();
		UpdateStatus(DISTAT_IN_ALARM_NOT_ACKED);
		LogMessage(MSGLISTSER_ALARM_INTO, IDS_ALARM_MESSAGE_INTO_ALARM);
		SendEmail (IDS_ALARM_MESSAGE_INTO_ALARM);
		pEVENTS->AlarmTransitionCause(m_penNumber, m_alarmNumber, evtCauseAlarmINTO);	// Send to event system
		AssertClearRelays(CDataItemDigitalIOUser::digassert);
	} else {
		// No, alarm has just gone out of alarm, remove from tally of "in alarms" and also if marked on chart
		pALARM_OVERVIEW->RemoveInAlarm();
		if (m_pAlarmCfg->MarkChart) {
			pALARM_OVERVIEW->RemoveChartInAlarm(m_pPenCfg->GroupNumber);
		} else
			m_OldMarkChart = FALSE; // here we know we don't need it any more

		// Is the alarms latched? (requiring a manual acknowledge
		if (m_pAlarmCfg->Latched) {
			// Yes, The alarm is latched, so requires an acknowledge, 
			if (m_pAlarmDataItem->GetStatus() == DISTAT_IN_ALARM_NOT_ACKED) {
				// No acknowledge has been performed whilst in alarm, so it must remain unacnkowedged
				// but reflect status of out of alarm
				UpdateStatus(DISTAT_OUT_OF_ALARM_NOT_ACKED);
				LogMessage(MSGLISTSER_ALARM_OUTOF_NOT_ACK, IDS_ALARM_MESSAGE_OUT_ALARM_NOT_ACK);
				pEVENTS->AlarmTransitionCause(m_penNumber, m_alarmNumber, evtCauseAlarmOUTOF);	// Send to event system
			} else {
				// Alarm was acknowledged when in alarm, so drop out to std out of alarm state
				UpdateStatus(DISTAT_OUT_OF_ALARM);
				LogMessage(MSGLISTSER_ALARM_OUTOF, IDS_ALARM_MESSAGE_OUT_OF_ALARM);
				AssertClearRelays(CDataItemDigitalIOUser::digCLEAR);
				pEVENTS->AlarmTransitionCause(m_penNumber, m_alarmNumber, evtCauseAlarmOUTOF);	// Send to event system
			}
		} else {
			// No, unlatched alarm so does not need to be acknowledged necessarily
			// return to std out of alarm state
			UpdateStatus(DISTAT_OUT_OF_ALARM);
			LogMessage(MSGLISTSER_ALARM_OUTOF, IDS_ALARM_MESSAGE_OUT_OF_ALARM);
			AssertClearRelays(CDataItemDigitalIOUser::digCLEAR);
			pEVENTS->AlarmTransitionCause(m_penNumber, m_alarmNumber, evtCauseAlarmOUTOF);	// Send to event system
		}
	}
	m_AlarmStatusLastTime = m_InAlarmNow;		// Set status for comparison next time round
	// If the Alarm level is "in alarm" or the Alarm is latched and has not been acknowledged
	// set the General data item status of the Alarm to "in alarm"
	if (m_InAlarmNow || (m_pAlarmDataItem->GetStatus() == DISTAT_OUT_OF_ALARM_NOT_ACKED)) {
		m_pAlarmDataItem->SetAlarmStatus(ASTAT_IN_ALARM);
	} else {
		// Not in alarm level and any outstanding alarms have been acknoledged
		m_pAlarmDataItem->SetAlarmStatus(ASTAT_OUT_ALARM);
	}

	return retVal;
}

//**********************************************************************
/// Process damping, time delay before entering into and alarm
/// 
/// @return		nothing
/// 
//**********************************************************************
void CAlarm::ProcessDamping() {
	// Is the Alarm configuyred to use damping?
	if (m_pAlarmCfg->UseDamp) {
		// Rate up and Rate down re-use damping, so ignore for these types
		if (m_pAlarmCfg->Type != ALARM_TYPE_RATEUP && m_pAlarmCfg->Type != ALARM_TYPE_RATEDOWN) {
			// Yes, is it currently in alarm?
			if (m_InAlarmNow) {
				// Yes, Check if damping is being started
				if (m_StartDamping == TRUE) {
					// Yes, Alarm has transitioned into an "in alarm" state by level including hysteresis
					// so we need to start the damping process, set the time baseline from current elapsed process time
					m_StartDamping = FALSE;
					m_dampingStartTime = pGlbSysTimer->GetElapsedProcTimeInSeconds();
				}

				// Calculate the elapsed time from the current process time
				// if the damping time has not been exceeded then reset m_InAlarmNow to show not in alarm
				float dampTimeElapsed = pGlbSysTimer->GetElapsedProcTimeInSeconds() - m_dampingStartTime;
				if (dampTimeElapsed < m_pAlarmCfg->DampSecs) {
					m_InAlarmNow = FALSE;
				}
			} else {
				// No, alarm is out of alarm so we can reset the start damping next time an alarm is activated
				m_StartDamping = TRUE;
			}
		}
	}
}

//**********************************************************************
/// Process reflash, if a latched alarm is acknowledged but stays in alarm
/// for the reflash period, it will be reactivated to a Non Acknowledged state
/// 
/// @return		nothing
/// 
//**********************************************************************
void CAlarm::ProcessReflash() {
	// Is the Alarm configuyred to use damping?
	if (m_pAlarmCfg->UseReflash) {
		// Yes, is this a latched alarm has already been acknowledged and is still in alarm?
		if (m_pAlarmDataItem->GetStatus() == DISTAT_IN_ALARM_ACKED && m_InAlarmNow) {
			// Yes, Check if damping is being started
			if (m_StartReflash == TRUE) {
				// Yes, Alarm has transitioned into an "in alarm" state by level including hysteresis
				// so we need to start the damping process, set the time baseline from current elapsed process time
				m_StartReflash = FALSE;
				m_reflashStartTime = pGlbSysTimer->GetElapsedProcTimeInSeconds();
			}

			// Calculate the elapsed time from the current process time if the reflash has exceeded, then reflash this alarm
			float reflashTimeElapsed = pGlbSysTimer->GetElapsedProcTimeInSeconds() - m_reflashStartTime;
			if (reflashTimeElapsed >= m_pAlarmCfg->ReflashSecs) {
				UpdateStatus(DISTAT_IN_ALARM_NOT_ACKED);
				LogMessage(MSGLISTSER_ALARM_INTO, IDS_ALARM_MESSAGE_REFLASH);
				pEVENTS->AlarmTransitionCause(m_penNumber, m_alarmNumber, evtCauseAlarmINTO);	// Send to event system
				AssertClearRelays(CDataItemDigitalIOUser::digassert);
			}
		} else {
			// No, alarm is out of alarm so we can reset the start damping next time an alarm is activated
			m_StartReflash = TRUE;
		}
	}
}

//**********************************************************************
/// Set an alarm to an active state (NB: not actually IN alarm, just can be triggered)
///
/// @return		T_ALARM_CONTROL_RETURN as status of call
/// 
//**********************************************************************
T_ALARM_CONTROL_RETURN CAlarm::SetAlarmToActive(BOOL startup) {
	pALARM_OVERVIEW->AddActiveAlarm();	// Add to tally of active alarms
	m_Active = TRUE;
	m_StartDamping = TRUE;

	// Reset rate Alarm
	m_rateCountDown = 0;
	m_ratePipe.ResetPipe();
	m_rateAve.ResetAverage();

	if (m_pAlarmCfg->MarkChart) {
		m_OldMarkChart = TRUE;	// remember old status to clear alarm background if necessary	
	}

	// Check NV status to see if we are currently In an alarm
	T_DATAITEM_STATUS nvStatus = m_pAlarmDataItem->GetStatus();
	if (nvStatus == DISTAT_IN_ALARM_NOT_ACKED || nvStatus == DISTAT_IN_ALARM_ACKED) {
		// Yes so set the status and indicate in alarm
		m_AlarmStatusLastTime = TRUE;
		pALARM_OVERVIEW->AddInAlarm();
		if (m_pAlarmCfg->MarkChart) {
			pALARM_OVERVIEW->AddChartInAlarm(m_pPenCfg->GroupNumber);
		}
		m_pAlarmDataItem->SetAlarmStatus(ASTAT_IN_ALARM);
		//Some actions only when called at start-up (NB startup is also meaning a Config change - JLP)
		if (startup == TRUE) {

			if (m_pAlarmCfg->MarkChart) {
				LogMessage(MSGLISTSER_ALARM_INTO, IDS_ALARM_MESSAGE_IN_ALARM);
				// this re-freshes mark chart to get background colour correct when an alarm is disabled
				// but it repeats 'in alarm' message on any setup change or power cycle 
				// (slightly different to initial 'Into Alarm' flag)
			} else if (m_OldMarkChart == TRUE) {
				// clear alarm background colour if mark chart has been deselected while alarm was active
				LogMessage(MSGLISTSER_ALARM_INTO, IDS_ALARM_MESSAGE_MARK_CHART_DISABLED);
				m_OldMarkChart = FALSE;	// only send once
			}

			if (m_ActivateRelays == TRUE) {
				// if the alarm was acknowledged, the relay has been reset, so don't set it again
				if (nvStatus == DISTAT_IN_ALARM_NOT_ACKED)		// in alarm, not acknowledged - relays should be active
						{
					// Build outputCache on start-up (increment overall output cache)
					m_pDigUserSetOuptuts->BuildOutputCacheAtStartup();// log numbers of alarms currently acting on each relay

					if (m_relaysAsserted == TRUE)	// setup changed, with relays active (not power-up)
					{
						// clear old relays, but assert any current ones
						ClearOldRelays();	// may need to turn off relays which have been removed from list
						AssertRelays(); // this updates relay state, but not the tally of alarms in outputCache
					} else // eg power-up, only need to set status if relay state set from saved nv state
						  // with no NV state saved, need to write the relay states to active
					{
						//m_relaysAsserted = TRUE;	// flag relay asserted (if NV state saved)
						AssertRelays(); // update relay state if not saved in NV
					}
				}
				// if in alarm and acknowledged, relays have already been reset, and outputCache decremented
			}
		}
	} else {
		// No indicate not in alarm
		m_AlarmStatusLastTime = FALSE;

		//Some actions only when called at start-up (this is on setup change or power on/off)
		//Todo: check the conditions on first DI Run .. if alarm enabled by DI
		if ((DISTAT_OUT_OF_ALARM_NOT_ACKED == nvStatus) && (TRUE == startup)) {
			//PSR Fix for restoring the the alarm status.						
			// No acknowledge has been performed whilst in alarm, so it must remain unacnkowedged
			// but reflect status of out of alarm
			UpdateStatus(DISTAT_OUT_OF_ALARM_NOT_ACKED);
			m_pAlarmDataItem->SetAlarmStatus(ASTAT_IN_ALARM);

			if (m_ActivateRelays == TRUE) {
				// Build outputCache on start-up (increment overall output cache)
				m_pDigUserSetOuptuts->BuildOutputCacheAtStartup();// log numbers of alarms currently acting on each relay

				if (m_relaysAsserted == TRUE)	// setup changed, with relays active (not power-up)
				{
					// clear old relays, but assert any current ones
					ClearOldRelays();	// may need to turn off relays which have been removed from list
					AssertRelays(); // this updates relay state, but not the tally of alarms in outputCache
				} else // eg power-up, only need to set status if relay state set from saved nv state
					  // with no NV state saved, need to write the relay states to active
				{
					//m_relaysAsserted = TRUE;	// flag relay asserted (if NV state saved)
					AssertRelays(); // update relay state if not saved in NV
				}
			}
		} else {
			UpdateStatus(DISTAT_OUT_OF_ALARM);
			m_pAlarmDataItem->SetAlarmStatus(ASTAT_OUT_ALARM);
			m_relaysAsserted = FALSE;
		}

	}
	return RET_ALARM_OKAY;
}

//**********************************************************************
/// Reset an alarm to a non active state
///
/// @return		T_ALARM_CONTROL_RETURN as status of call
/// 
//**********************************************************************
T_ALARM_CONTROL_RETURN CAlarm::ResetAlarmToNonActive(BOOL startup) {
	// If alarm is currently Active, remove from active tally
	if ((m_Enabled == TRUE) && (m_FirstDIRun == FALSE)) {
		if (startup == TRUE) {
			ClearOldRelays();	// turn off any relays as necessary
			LogMessage(MSGLISTSER_ALARM_OUTOF, IDS_ALARM_MESSAGE_DISABLED); // remove mark chart if necessary						
			// note: disabling any alarm will remove mark chart for all active alarms - no easy solution to this
		} else {
			if (m_Active == TRUE) {
				pALARM_OVERVIEW->RemoveActiveAlarm();
			}
			// If alarm is currently in alarm , remove from "in alarm" tally
			if (m_AlarmStatusLastTime == TRUE) {
				pALARM_OVERVIEW->RemoveInAlarm();
				if (m_pAlarmCfg->MarkChart) {
					pALARM_OVERVIEW->RemoveChartInAlarm(m_pPenCfg->GroupNumber);
				}
			}
		}
	}

	// Cleardown alarm being in an alarm state
	m_InAlarmNow = FALSE;
	m_AlarmStatusLastTime = ROGUE_ALARM_STATE;
	m_StartDamping = TRUE;
	m_StartReflash = TRUE;

	if (m_pAlarmDataItem->GetStatus() != DISTAT_OUT_OF_ALARM && m_pAlarmDataItem->GetStatus() != DISTAT_INVALID) {
		// Only clear the relays if this alarm has not already come out of alarm
		// if out-of-alarm-not-acknowledged, and alarm is not latched, relay is already off - don't repeat
		if (((m_pAlarmDataItem->GetStatus() == DISTAT_OUT_OF_ALARM_NOT_ACKED) && (m_pAlarmCfg->Latched == FALSE))
				== FALSE) {
			if ((m_FirstDIRun == TRUE) && (m_ActivateRelays == TRUE)) {
				m_pDigUserSetOuptuts->ClearDIenabledState(); // if DI is not asserted on power-up, 
				//clear old relay state without needing to process alarm as active first
				m_relaysAsserted = FALSE;
			} else {
				AssertClearRelays(CDataItemDigitalIOUser::digCLEAR);	// normal case	
			}
		}
		LogMessage(MSGLISTSER_ALARM_OUTOF, IDS_ALARM_MESSAGE_OUT_OF_ALARM);
	}

	UpdateStatus(DISTAT_OUT_OF_ALARM);

	m_pAlarmDataItem->SetAlarmStatus(ASTAT_OUT_ALARM);		// Remove general alarm state from alarm.

	m_Active = FALSE;

	return RET_ALARM_OKAY;
}

//************************************************************************************
/// Set the user alarm level, this will be used to process alarms and set in DIT
/// Status level remains the same
///
/// @param[in]	userLevel - level used for alarms, can be user defined outside config
///
/// @return		nothing
//************************************************************************************
void CAlarm::UpdateUserLevel(float userLevel) {
	m_pNVData->UserLevel = userLevel;
	m_pAlarmDataItem->SetValue(userLevel);
}

//************************************************************************************
/// Set the user alarm level, this will be used to process alarms and set in DIT
/// Status level remains the same
///
/// @param[in]	userLevel - level used for alarms, can be user defined outside config
///
/// @return		nothing
//************************************************************************************
void CAlarm::UpdateStatus(T_DATAITEM_STATUS status) {
	m_pNVData->State = status;
	m_pAlarmDataItem->SetStatus(status);
}

//**********************************************************************
/// Set the alarm status, this will set DIT status and also save to NV
///
/// @param[in]	type - T_MSGLISTSER_ALARM_MSG_TYPE type of alarm message
/// @param[in]	messNumber - message identifier in string table
///
/// @return		nothing
/// 
//**********************************************************************
void CAlarm::LogMessage(T_MSGLISTSER_ALARM_MSG_TYPE type, UINT messNumber) {
	QString   strMessage;
	WCHAR messageText[MSGLISTSER_NUM_OF_CHARACTERS_PER_MESSAGE];
	UCHAR alarmFlags = 0;

	// get the current group for the pen (0=none)
	T_PEN_GROUPS groupNumber = (T_PEN_GROUPS) m_pPenCfg->GroupNumber;

	// see if this has changed
	if (((messNumber == IDS_ALARM_MESSAGE_IN_ALARM) || (messNumber == IDS_ALARM_MESSAGE_MARK_CHART_DISABLED))
			&& (groupNumber != m_OldGroupNumber) && (m_OldGroupNumber != PEN_GROUP_MAX)) // test for change of group, but not first time in (PEN_GROUP_MAX)
			{

		qDebug(":::::::::: GROUP NUMBER CHANGED was %d now %d :::::::::::\n", m_OldGroupNumber, groupNumber);

		// here we log an additional message in the 'old' group - so that we don't leave chart in the alarm state

		strMessage = tr("In Alarm and Group changed");
		swprintf(messageText, L"%s : %s (%d)", m_pAlarmCfg->Tag, strMessage, GetAlarmCounter());

		// set the general ALARMS_ACTIVE bit
		alarmFlags = (UCHAR) (pALARM_OVERVIEW->GetNumberOfChartAlarmsInAlarm(PEN_GROUP_NONE) != 0); // set ALARMS_ACTIVE bit 0

		// and additionally set the GROUP_ALARMS_ACTIVE bit
		if (m_OldGroupNumber != PEN_GROUP_NONE) {
			if (pALARM_OVERVIEW->GetNumberOfChartAlarmsInAlarm(m_OldGroupNumber))
				alarmFlags |= GROUP_ALARMS_ACTIVE;
		}

		if (m_OldMarkChart == TRUE) {
			alarmFlags |= MARK_CHART; // optionally set this bit
		}

		LOG_ALARM_MESSAGE(type,
				m_penNumber,  // pen number zero based for TMP usage.
				m_alarmNumber + 1, m_pAlarmDataItem->GetFPValue(), alarmFlags,
				static_cast<T_ALARM_TYPES>(m_pAlarmCfg->Type), messageText, m_OldGroupNumber);
	}

	// now continue with standard message
	strMessage.LoadString(messNumber);
	swprintf(messageText, L"%s : %s (%d)", m_pAlarmCfg->Tag, strMessage, GetAlarmCounter());

	// set the general ALARMS_ACTIVE bit
	alarmFlags = (UCHAR) (pALARM_OVERVIEW->GetNumberOfChartAlarmsInAlarm(PEN_GROUP_NONE) != 0); // set ALARMS_ACTIVE bit 0

	// additionally set the GROUP_ALARMS_ACTIVE bit
	if (groupNumber != PEN_GROUP_NONE) {
		if (pALARM_OVERVIEW->GetNumberOfChartAlarmsInAlarm(groupNumber))
			alarmFlags |= GROUP_ALARMS_ACTIVE;
	}

	if (m_pAlarmCfg->MarkChart || m_OldMarkChart) {
		alarmFlags |= MARK_CHART; // optionally set this bit
	}

	// group number will get added in later (could have done it here really)

	LOG_ALARM_MESSAGE(type,
			m_penNumber,  // pen number zero based for TMP usage.
			m_alarmNumber + 1, m_pAlarmDataItem->GetFPValue(), alarmFlags,
			static_cast<T_ALARM_TYPES>(m_pAlarmCfg->Type), messageText, groupNumber);

	m_OldGroupNumber = groupNumber; // keep track of group for next time

}
//****************************************************************************
// void SendEmail( const UINT uiMESSAGE_NUMBER )
///
/// Method that sends an alarm as an email, if necessary
///
/// @param[in]		const UINT uiMESSAGE_NUMBER - Resource number indicating the message
///					to display
///
//****************************************************************************
void CAlarm::SendEmail(const UINT uiMESSAGE_NUMBER) const {
	// now send the email if necessary
	CCommsSetupConfig *pkCommsConfig = pGlbSetup->GetCommsSetupConfig();
	CGeneralSetupConfig *pkGenConfig = pGlbSetup->GetGeneralSetupConfig();
	T_PCOMMUNICATIONS ptCommsData = NULL;
	QString   strRecipients("");

	// check the alarm is required to send emails
	if ( pSYSTEM_INFO->FWOptionEmailAvailable() && (m_pAlarmCfg->EmailAlarm != FALSE) && (pkCommsConfig != NULL)
			&& (pkGenConfig != NULL)) {
		strRecipients = pkCommsConfig->GetEmailAddresses(m_pAlarmCfg->EmailAddBitMask);

		ptCommsData = pkCommsConfig->GetCommsBlock(CONFIG_COMMITTED);

		if ((ptCommsData != NULL) && (strRecipients != "")) {
			T_EMAIL *ptEmail = &ptCommsData->Email;
			QString   strUsername("");
			QString   strPassword("");

			if (ptEmail->ServerReqAuth != FALSE) {
				strUsername.asprintf(L"%s", ptEmail->Username);

				CCrypto kCrypto;
				strPassword = kCrypto.Decrypt(ptEmail->Password, EMAIL_PASSWORD_LEN);
			}

			// create the subject
			QString   strSubject("");
			T_PGENERALCONFIG ptGeneral = pkGenConfig->GetSystemGeneralBlock(CONFIG_COMMITTED);
			if (ptGeneral != NULL) {

				strSubject.asprintf(IDS_ALARMS_EMAIL_SUBJECT, ptGeneral->Name, m_pAlarmCfg->Tag);
			}

			// now create the message body
			QString   strMessage("");
			QString   strTypeList("");
			strTypeList = tr("High|Low|Deviation|Rate Up|Rate Down|");
			strMessage.asprintf(IDS_ALARMS_EMAIL_MESSAGE, m_penNumber + 1, m_pPenCfg->Tag, m_alarmNumber + 1,
					m_pAlarmCfg->Tag, CStringUtils::asprintfFloat(m_pPenCfg->Scale.NumF, m_pPenDataItem->GetFPValue(), //m_pAlarmCfg->Level,
							m_pPenCfg->Scale.Span - m_pPenCfg->Scale.Zero, false, -1, true), m_pPenCfg->Units,
					CStringUtils::asprintfFloat(m_pPenCfg->Scale.NumF, GetUserLevel(), //m_pAlarmCfg->Level,
							m_pPenCfg->Scale.Span - m_pPenCfg->Scale.Zero), m_pPenCfg->Units,
					CStringUtils::GetItemAtPos(strTypeList, m_pAlarmCfg->Type), GetAlarmCounter());

#ifndef V6IOTEST
			const CEmailData kMAIL_DATA(strRecipients, ptEmail->UserAddress, ptEmail->UserAddress, strSubject,
					strMessage, ptEmail->ServerName, ptEmail->SecurityMode, ptEmail->STARTTLSSupport, ptEmail->Port,
					strUsername, strPassword);

			CSMTPThread::AddEmailToPending(kMAIL_DATA);
#endif
		}
	}
}
//=========================================================================================
// Class CAlarmOverview
//=========================================================================================

//**********************************************************************
/// CAlarmOverview constructor
//**********************************************************************
CAlarmOverview::CAlarmOverview() {
	m_ActiveAlarms = 0;
	m_AlarmInAlarm = 0;
	for (int i = 0; i < PEN_GROUP_MAX; i++)
		m_ChartAlarmInAlarm[i] = 0;
}

//=========================================================================================
// Class CAlarmList
//=========================================================================================

//**********************************************************************
///
/// Reset the index list
///
/// @return		nothing
/// 
//**********************************************************************
void CAlarmList::ResetList() {
	for (int entry = 0; entry < MAX_ALARMS_IN_LIST; entry++) {
		m_listRef[entry] = NULL;
	}
	m_NumEntries = 0;
}

//**********************************************************************
///
/// Add alarm ptr to next entry in list
///
/// @param[in]	pAlarm - ptr to CAlarm Instance to add to the list
/// @return		current number of entries in list
/// 
//**********************************************************************
short CAlarmList::AddAlarmToList(CAlarm *pAlarm) {
	m_listRef[m_NumEntries++] = pAlarm;
	return m_NumEntries;
}

/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Processing
/// @n Filename: FucntionPack.cpp
/// @n Desc:	 Contains all functions available for Maths blocks and scripts
///				 provdiign the interface between V6 application and Scirpt processor
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  57  Stability Project 1.52.1.3 7/2/2011 4:57:24 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  56  Stability Project 1.52.1.2 7/1/2011 4:38:18 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  55  Stability Project 1.52.1.1 3/17/2011 3:20:24 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  54  Stability Project 1.52.1.0 2/15/2011 3:03:05 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// ****************************************************************

#include "FunctionPack.h"
#include "TraceDefines.h"
#include "conversion.h"
#include "V6globals.h"
#include "penmanager.h"
#include "V6defines.h"
#include <math.h>
#include "ScheduleWrapper.h"			// ModBus master schedule wrapper
#include "BatchManager.h"

#ifndef TTR6SETUP
#include "eventmanager.h"

CPenManager *pFPPenManager;
#ifndef V6IOTEST
CBatchManager *pkBatchManager = NULL;
#endif
#endif

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif

#define FLT_PARAM(a)	pSig->GetParameter(a-1)->GetFloatValue()
#define X_PARAM			pSig->GetParameter(0)->GetFloatValue()
#define Y_PARAM			pSig->GetParameter(1)->GetFloatValue()
#define Z_PARAM			pSig->GetParameter(2)->GetFloatValue()

T_SCRIPT_TIMERS GlbScriptTimer[MAX_SCRIPT_TIMERS];		///< Holder for the timers

LONGLONG GlbEventTriggerHoldoffPeriod[V6_MAX_EVENTS];	///< Hold off for events to avoid constatnt triggering
BOOL GlbEventTriggerLock[V6_MAX_EVENTS];				///< Event triggering locks
const LONGLONG EVENT_HOLD_OFF_IN_TICKS = 100;			///< Hold off event system for a second

// ======================================================================
// Steps to adding a new function block
// ======================================================================
// 1.. Create function body in correct format V6ERRORINFO FP_<NAME>(CSignature *pSig,CExecutionContext *objContext,V6FUNCRESULT* pRes)
// 2.. Add an identifier into T_FUNCTION_ID enum in FucntionPack.h
// 3.. Add function into the pack in AddFunctionPackEntries() at the bottom of this file

// Function prototypes
BOOL FP_AddFunctionToPack(T_FUNCTION_ID funcID, const char *funcName, const char *funcParams, FPFUNCPTR pFunc);
void AddFunctionPackEntries();

FPGETPROCFUNCPTR g_fnFuncPackGetProc;

T_FUNCTION_INFO GlbfunctionTable[FP_MAX_FUNCTIONS];

int GlbFunctionTableTextSize;
const int CAPTABLE_FUNCTION_LINE_OVERHEAD = 8;/// Overhead in characters for each line of the capabilities table need to add ',' \n \r plus some spare

//*************************************************************************************
///
/// Create the export table for Script Services to call functionpack functions
///
/// @return		nothing
/// 
//*************************************************************************************
int CreateExportTable() {
	g_fnFuncPackGetProc = FP_GetFuncPackProcAddress;

#ifdef STARTUP_LOGGING
	WCHAR InitLogFileName[ 256 ];
	WCHAR InitLogString[512];
	CStorage kLogFile;
	FileException kFileEx;
	int iPathLen = 256;

	pDALGLB->GetPath(	static_cast< T_STORAGE_PATH >( IDS_INTERNAL_SD ), 
						InitLogFileName,
						256,
						&iPathLen );

	wcsncat( InitLogFileName, 256, L"CreateExportTable.txt", (256 - wcslen( InitLogFileName )) );
	
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();
		wcscpy(InitLogString,L"--------CreateExportTable started-------\n");		
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		wcscpy(InitLogString,L"AddFunctionPackEntries\n");
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif

	/// Cleardown function pack infomation table
	for (int funcID = 0; funcID < FP_MAX_FUNCTIONS; funcID++) {
		memset(&GlbfunctionTable[funcID], 0, sizeof(T_FUNCTION_INFO));
	}
	GlbFunctionTableTextSize = 0;	// Inititlaise text size counter , this is updated by FP_AddFunctionToPack
									// to produce the max size for the buffer for the Capabilities table.
	AddFunctionPackEntries();		// Add all functions to fucntion pack

#ifndef TTR6SETUP
#ifdef STARTUP_LOGGING
	wcscpy(InitLogString,L"Pen Manager Init\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();		
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif

	pFPPenManager = CPenManager::GetHandle();		// Get handle on PenManager Singleton

#ifndef V6IOTEST
#ifdef STARTUP_LOGGING
	wcscpy(InitLogString,L"Batch Manager Init\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();		
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif

	pkBatchManager = CBatchManager::Instance();		// Get Batch amanger Singleton
#endif
#endif
#ifdef STARTUP_LOGGING
	wcscpy(InitLogString,L"-------------END-----------\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();		
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	return GlbFunctionTableTextSize;
}

//*************************************************************************************
///
/// Create the export table for Script Services to call functionpack functions
///
/// @return		nothing
/// 
//*************************************************************************************
void BuildCapabilitiesTable(char *pTable, int size) {
	memset(pTable, 0, size);
	char lineText[FUNCTION_NAME_MAX_LENGTH + FUNCTION_PARAM_MAX_LENGTH + CAPTABLE_FUNCTION_LINE_OVERHEAD];
	/// Cleardown function pack infomation table
	for (int funcID = 0; funcID < FP_MAX_FUNCTIONS; funcID++) {
		// Check to see if there is an avaiolable function
		if (GlbfunctionTable[funcID].pFunction != NULL) {

			// Build up individual line entry
#if _MSC_VER < 1400 
			sprintf(lineText, "%s,%d,%s\n\r", GlbfunctionTable[funcID].functionName, funcID,
					GlbfunctionTable[funcID].functionParams);
			// Add this to the capabilities table
			strcat(pTable, lineText);

#else
			sprintf_s( lineText, sizeof(lineText) , "%s,%d,%s\n\r", GlbfunctionTable[funcID].functionName, funcID, GlbfunctionTable[funcID].functionParams );
			// Add this to the capabilities table
			strcat_s( pTable, size, lineText );

#endif

		}
	}
	qDebug("Capabilities table %d in size reserved(%d)\n", strlen(pTable), size);

	// Reset the script timers
	for (int timerIndex = 0; timerIndex < MAX_SCRIPT_TIMERS; timerIndex++) {
		GlbScriptTimer[timerIndex].accTime = 0;
		GlbScriptTimer[timerIndex].lastStart = 0;
		GlbScriptTimer[timerIndex].IsRunning = FALSE;
	}
	for (int eventHoldOffIndex = 0; eventHoldOffIndex < V6_MAX_EVENTS; eventHoldOffIndex++) {
		GlbEventTriggerHoldoffPeriod[eventHoldOffIndex] = 0;
		GlbEventTriggerLock[eventHoldOffIndex] = FALSE;
	}
}

//****************************************************************************
/// Add a function to the fucntion pack table
///
/// @param[in] - funcID, unique T_FUNCTION_ID identifier for the fucntion
/// @param[in] - funcName, fucntion name exposed to scripts
/// @param[in] - numParams, number of parameters in function
/// @param[in] - return type, IBXFACESERVICES_API DATA_TYPE
/// @param[in] - perfIndex, performance Index, arbitary figure providing an estimate of load
/// @param[in] - funcArg, function argument string
/// @param[in] - pFunc, Fucntion pointer scripts will call directly
///
/// @return - TRUE if success, otherwise FALSE - developer will be informed
///
//****************************************************************************	
BOOL FP_AddFunctionToPack(T_FUNCTION_ID funcID, const char *funcName, int numParams, int retType, int PerfIndex,
		const char *funcArg, FPFUNCPTR pFunc) {
	BOOL retVal = TRUE;
	// Perform a simple check to make sure developer is not trying to assign more then one function
	// to the same identifier
	if (GlbfunctionTable[funcID].pFunction != NULL) {
		// We have already added a function to this ID, critical stop to warn developer
		LOG_CRTL(TRACE_PROCESSING, "FunctionPack: Function Ident already defined = %d\n", funcID);
		retVal = FALSE;
	} else {
		// Use the strings match to find address to check for an attempt by developer to register duplicate 
		// fucntion names
		FPFUNCPTR pDuplicatePtr;
		V6ERRORINFO errInfo;
		FP_GetFuncPackProcAddress(const_cast<char*>(funcName), &pDuplicatePtr, &errInfo);
		if (pDuplicatePtr != NULL) {
			// We have already added a function with the same name, critical stop to warn developer
			LOG_CRTL(TRACE_PROCESSING, "FunctionPack: Function name already defined = %s\n", funcName);
			retVal = FALSE;
		} else {
			// Function pack ID not used and not duplicate name found, so validate the name lengths
			if (strlen(funcName) < FUNCTION_NAME_MAX_LENGTH && strlen(funcArg) < FUNCTION_ARG_MAX_LENGTH) {
				// All validations complete , setup the table entry
				GlbfunctionTable[funcID].functionID = funcID;
				GlbfunctionTable[funcID].pFunction = pFunc;

#if _MSC_VER < 1400 
				strcpy(GlbfunctionTable[funcID].functionName, funcName);
				sprintf(GlbfunctionTable[funcID].functionParams, "%d,%d,%d,%s", numParams, PerfIndex, retType, funcArg);

#else
				strcpy_s( GlbfunctionTable[funcID].functionName, sizeof(GlbfunctionTable[funcID].functionName), funcName );
				sprintf_s( GlbfunctionTable[funcID].functionParams, sizeof(GlbfunctionTable[funcID].functionParams), "%d,%d,%d,%s", numParams, PerfIndex, retType, funcArg );

#endif

				GlbFunctionTableTextSize += (strlen(funcName) + strlen(GlbfunctionTable[funcID].functionParams)
						+ CAPTABLE_FUNCTION_LINE_OVERHEAD);
			} else {
				// Fucntion name or params strict too long, critical stop to warn developer
				LOG_CRTL(TRACE_PROCESSING, "FunctionPack: Function name or param too long name=%d should be %d param=%d should be %d\n", strlen(
						funcName), FUNCTION_NAME_MAX_LENGTH, strlen(GlbfunctionTable[funcID].functionParams), FUNCTION_PARAM_MAX_LENGTH);
				retVal = FALSE;
			}
		}
	}
	return retVal;
}

//****************************************************************************
/// Get a function pack function pointer using the function name
///
/// @param[in] - szFuncName, Fucntion name to search for
/// @param[out] - pFnc, Function pointer if match successful, otherwise NULL
///
/// @return - V6ERRORINFO
//****************************************************************************	
void FUNCPACK_API FP_GetFuncPackProcAddress(char *szFuncName, FPFUNCPTR *pFnc, V6ERRORINFO *pErr) {
	*pFnc = NULL;
	// Only check for function packs names if this is not basic math processing
	if ( pSYSTEM_INFO->FWOptionMathsType() != MATH_OPTION_BASIC_BLOCK) {
		// Run through all fucntions until a match is found by the name of the function
		for (int funcID = 0; funcID < FP_MAX_FUNCTIONS; funcID++) {
			// compare fucntions names, do they match?
			if (_stricmp(GlbfunctionTable[funcID].functionName, szFuncName) == FUNCTION_NAME_MATCH) {
				// Yes, set the fucntio pointer and exit loop
				*pFnc = GlbfunctionTable[funcID].pFunction;
				break;
			}
		}
	}
}

///############################################################################################
/// Help functions
///############################################################################################

//*********************************************************************************************
/// inline max value, return larger of x or y
//*********************************************************************************************	
inline float MaxVal(float x, float y) {
	// If one of the numbers is +/- FLT_MAX, return the other number. If both are +/- FLT_MAX, 
	// FLT_MAX is returned unless both are -FLT_MAX. This treats +/- FLT_MAX as being invalid numbers 
	// to which a valid number cannot be compared, but allows a comparison if both numbers are invalid.
	if ((x >= FLT_MAX) || (x <= -FLT_MAX)) {
		if (y == -FLT_MAX) {
			if (x == -FLT_MAX) {
				return y;	// return -FLT_MAX if both x and y are -FLT_MAX
			} else {
				return x;	// return FLT_MAX if x is FLT_MAX and y is -FLT_MAX
			}
		} else {
			return y; // return y as a valid input if x is invalid, or return FLT_MAX if y is FLT_MAX
		}
	} else if ((y >= FLT_MAX) || (y <= -FLT_MAX)) {
		return x;	// x is a valid input, so return it
	} else	// both valid inputs, return the larger value
	{
		if (x >= y) {
			return x;
		} else {
			return y;
		}
	}
}

//*********************************************************************************************
/// inline min value, return smaller of x or y
//*********************************************************************************************	
inline float MinVal(float x, float y) {
	// If one of the numbers is +/- FLT_MAX, return the other number. If both are +/- FLT_MAX, 
	// -FLT_MAX is returned unless both are FLT_MAX. This treats +/- FLT_MAX as being invalid numbers 
	// to which a valid number cannot be compared, but allows a comparison if both numbers are invalid.
	if ((x >= FLT_MAX) || (x <= -FLT_MAX)) {
		if (y == FLT_MAX) {
			if (x == FLT_MAX) {
				return y;	// return FLT_MAX if both x and y are FLT_MAX
			} else {
				return x;	// return -FLT_MAX if x is -FLT_MAX and y is FLT_MAX
			}
		} else {
			return y; // return y as a valid input if x is invalid, or return -FLT_MAX if y is -FLT_MAX
		}
	} else if ((y >= FLT_MAX) || (y <= -FLT_MAX)) {
		return x;	// x is a valid input, so return it
	} else	// both valid inputs, return the smaller value
	{
		if (x <= y) {
			return x;
		} else {
			return y;
		}
	}
}

//*********************************************************************************************
/// CheckINF( pRes ) - check result for positive or negative infinity
//*********************************************************************************************	
inline void CheckINF(V6FUNCRESULT *pRes) {
	if (pRes->fResult > FLT_MAX)	// only true for (positive) infinity
	{
		pRes->fResult = FLT_MAX; // infinity is represented as FLT_MAX
	} else if (pRes->fResult < -FLT_MAX)	// check for negative infinity
	{
		pRes->fResult = -FLT_MAX;	// minus infinity is represented as -FLT_MAX
	}
}

//*********************************************************************************************
/// CheckPosINF( pRes ) - check result for positive infinity
//*********************************************************************************************	
inline void CheckPosINF(V6FUNCRESULT *pRes) {
	if (pRes->fResult > FLT_MAX)	// only true for (positive) infinity
	{
		pRes->fResult = FLT_MAX; // infinity is represented as FLT_MAX
	}
}

///############################################################################################
/// Functional pack functions
///############################################################################################

///============================================================================================
/// Maths
///============================================================================================

//*********************************************************************************************
/// sin[x] - Sine of x
//*********************************************************************************************	
void FP_sin(CSignature *pSig, CExecutionContext *objContext, V6FUNCRESULT *pRes, V6ERRORINFO *pErr) {
	pRes->Type = DT_FLOAT;	// Return type
	// trap any input too high or low to avoid NaN return from function
	float xparam = X_PARAM;	// use local variable to avoid multiple function calls
	if ((xparam > 1e19) || (xparam < -1e19)) {
		pRes->fResult = -FLT_MAX;	// use -FLT_MAX as invalid number
	} else {
		pRes->fResult = sin(xparam);
	}
}

//*********************************************************************************************
/// cos[x] - Cosine of x
//*********************************************************************************************	
void FP_cos(CSignature *pSig, CExecutionContext *objContext, V6FUNCRESULT *pRes, V6ERRORINFO *pErr) {
	pRes->Type = DT_FLOAT;	// Return type
	// trap any input too high or low to avoid NaN return from function
	float xparam = X_PARAM;	// use local variable to avoid multiple function calls
	if ((xparam > 1e19) || (xparam < -1e19)) {
		pRes->fResult = -FLT_MAX;	// use -FLT_MAX as invalid number
	} else {
		pRes->fResult = cos(xparam);
	}
}

//*********************************************************************************************
/// tan[x] - Tangent of x
//*********************************************************************************************	
void FP_tan(CSignature *pSig, CExecutionContext *objContext, V6FUNCRESULT *pRes, V6ERRORINFO *pErr) {
	pRes->Type = DT_FLOAT;	// Return type
	// trap any input too high or low to avoid NaN return from function
	float xparam = X_PARAM;	// use local variable to avoid multiple function calls
	if ((xparam > 1e19) || (xparam < -1e19)) {
		pRes->fResult = -FLT_MAX;	// use -FLT_MAX as invalid number
	} else {
		pRes->fResult = tan(xparam);
	}
}

//*********************************************************************************************
/// sinh[x] - Hyperbolic Sine of x
//*********************************************************************************************	
void FP_sinh(CSignature *pSig, CExecutionContext *objContext, V6FUNCRESULT *pRes, V6ERRORINFO *pErr) {
	pRes->Type = DT_FLOAT;	// Return type
	pRes->fResult = sinh( X_PARAM);
	// function does not return NaN, but may return +/- infinity which needs to be changed to +/- FLT_MAX
	CheckINF(pRes);
}

//*********************************************************************************************
/// cosh[x] - Hyperbolic Cosine of x
//*********************************************************************************************	
void FP_cosh(CSignature *pSig, CExecutionContext *objContext, V6FUNCRESULT *pRes, V6ERRORINFO *pErr) {
	pRes->Type = DT_FLOAT;	// Return type
	pRes->fResult = cosh( X_PARAM);
	// function does not return NaN, but may return +/- infinity which needs to be changed to +/- FLT_MAX
	CheckINF(pRes);
}

//*********************************************************************************************
/// tanh[x] - Hyperbolic Tangent of x
//*********************************************************************************************	
void FP_tanh(CSignature *pSig, CExecutionContext *objContext, V6FUNCRESULT *pRes, V6ERRORINFO *pErr) {
	pRes->Type = DT_FLOAT;	// Return type
	// trap +/- FLT_MAX input to retain an invalid status
	float xparam = X_PARAM;	// use local variable to avoid multiple function calls
	if ((xparam >= FLT_MAX) || (xparam <= -FLT_MAX)) {
		pRes->fResult = -FLT_MAX;	// use -FLT_MAX as invalid number
	} else {
		pRes->fResult = tanh(xparam);
	}
}

//*********************************************************************************************
/// asin[x] - Arc Sine of x
//*********************************************************************************************	
void FP_asin(CSignature *pSig, CExecutionContext *objContext, V6FUNCRESULT *pRes, V6ERRORINFO *pErr) {
	pRes->Type = DT_FLOAT;	// Return type
	// trap any input too high or low to avoid NaN return from function
	float xparam = X_PARAM;	// use local variable to avoid multiple function calls
	if ((xparam > 1.0) || (xparam < -1.0)) {
		pRes->fResult = -FLT_MAX;	// use -FLT_MAX as invalid number
	} else {
		pRes->fResult = asin(xparam);
	}
}

//*********************************************************************************************
/// acos - Arc Cosine of x
//*********************************************************************************************	
void FP_acos(CSignature *pSig, CExecutionContext *objContext, V6FUNCRESULT *pRes, V6ERRORINFO *pErr) {
	pRes->Type = DT_FLOAT;	// Return type
	// trap any input too high or low to avoid NaN return from function
	float xparam = X_PARAM;	// use local variable to avoid multiple function calls
	if ((xparam > 1.0) || (xparam < -1.0)) {
		pRes->fResult = -FLT_MAX;	// use -FLT_MAX as invalid number
	} else {
		pRes->fResult = acos(xparam);
	}
}

//*********************************************************************************************
/// atan - Arc Tangent of x
//*********************************************************************************************	
void FP_atan(CSignature *pSig, CExecutionContext *objContext, V6FUNCRESULT *pRes, V6ERRORINFO *pErr) {
	pRes->Type = DT_FLOAT;	// Return type
	// trap +/- FLT_MAX input to retain an invalid status
	float xparam = X_PARAM;	// use local variable to avoid multiple function calls
	if ((xparam >= FLT_MAX) || (xparam <= -FLT_MAX)) {
		pRes->fResult = -FLT_MAX;	// use -FLT_MAX as invalid number
	} else {
		pRes->fResult = atan(xparam);
	}
}

//*********************************************************************************************
/// ceil[x] - round up x to the nearest whole number
//*********************************************************************************************	
void FP_ceil(CSignature *pSig, CExecutionContext *objContext, V6FUNCRESULT *pRes, V6ERRORINFO *pErr) {
	pRes->Type = DT_FLOAT;	// Return type
	pRes->fResult = ceil( X_PARAM);
}

//*********************************************************************************************
/// floor[x] - round x down to the nearest whole number
//*********************************************************************************************	
void FP_floor(CSignature *pSig, CExecutionContext *objContext, V6FUNCRESULT *pRes, V6ERRORINFO *pErr) {
	pRes->Type = DT_FLOAT;	// Return type
	pRes->fResult = floor( X_PARAM);
}

//*********************************************************************************************
/// fabs[x], Floating point absolute value x
//*********************************************************************************************	
void FP_fabs(CSignature *pSig, CExecutionContext *objContext, V6FUNCRESULT *pRes, V6ERRORINFO *pErr) {
	pRes->Type = DT_FLOAT;	// Return type
	pRes->fResult = fabs( X_PARAM);
}

//*********************************************************************************************
/// exp[x] - Exponential of x
//*********************************************************************************************	
void FP_exp(CSignature *pSig, CExecutionContext *objContext, V6FUNCRESULT *pRes, V6ERRORINFO *pErr) {
	pRes->Type = DT_FLOAT;	// Return type	
	// exp(x) returns infinity if x is too high. It returns zero for a -FLT_MAX input, 
	// which could be an invalid input not just a large negative value. To show an invalid input, 
	// return an invalid output for a -FLT_MAX input.
	if ( X_PARAM <= -FLT_MAX) {
		pRes->fResult = -FLT_MAX;
	} else {
		pRes->fResult = exp( X_PARAM);
		CheckPosINF(pRes);	// check for positive infinity
	}
}

//*********************************************************************************************
/// ln[x] - Natural Log of x
//*********************************************************************************************	
void FP_ln(CSignature *pSig, CExecutionContext *objContext, V6FUNCRESULT *pRes, V6ERRORINFO *pErr) {
	pRes->Type = DT_FLOAT;	// Return type
	// Need to ensure that FLT_MAX isn't reduced in value, as this represents infinity
	// Also trap numbers of zero or less, to avoid a NaN return from function
	float xparam = X_PARAM;	// use local variable to avoid multiple function calls
	if (xparam >= FLT_MAX) {
		pRes->fResult = FLT_MAX;	// keep infinity representation
	} else if (xparam <= 0.0F) {
		pRes->fResult = -FLT_MAX;	// use -FLT_MAX as invalid number
	} else {
		// do the right log (natural log)
		pRes->fResult = log(xparam);
	}
}

//*********************************************************************************************
/// log[x] - Base 10 Log of x
//*********************************************************************************************	
void FP_log(CSignature *pSig, CExecutionContext *objContext, V6FUNCRESULT *pRes, V6ERRORINFO *pErr) {
	pRes->Type = DT_FLOAT;	// Return type
	// Need to ensure that FLT_MAX isn't reduced in value, as this represents infinity
	// Also trap numbers of zero or less, to avoid a NaN return from function
	float xparam = X_PARAM;	// use local variable to avoid multiple function calls
	if (xparam >= FLT_MAX) {
		pRes->fResult = FLT_MAX;	// keep infinity representation
	} else if (xparam <= 0.0F) {
		pRes->fResult = -FLT_MAX;	// use -FLT_MAX as invalid number
	} else {
		// do the right log (base 10)
		pRes->fResult = log10(xparam);
	}
}

//*********************************************************************************************
/// sqrt[x] - Square root of x
//*********************************************************************************************	
void FP_sqrt(CSignature *pSig, CExecutionContext *objContext, V6FUNCRESULT *pRes, V6ERRORINFO *pErr) {
	pRes->Type = DT_FLOAT;	// Return type
	// Need to ensure that FLT_MAX isn't reduced in value, as this represents infinity
	// Also trap numbers of less than zero, to avoid a NaN return from function
	float xparam = X_PARAM;	// use local variable to avoid multiple function calls
	if (xparam >= FLT_MAX) {
		pRes->fResult = FLT_MAX;	// keep infinity representation
	} else if (xparam < 0.0F) {
		pRes->fResult = -FLT_MAX;	// use -FLT_MAX as invalid number
	} else {
		pRes->fResult = sqrt(xparam);
	}
}

//*********************************************************************************************
/// pow[x,y] - Raise x to the power of y
//*********************************************************************************************	
void FP_pow(CSignature *pSig, CExecutionContext *objContext, V6FUNCRESULT *pRes, V6ERRORINFO *pErr) {
	pRes->Type = DT_FLOAT;	// Return type	
	// If either X_PARAM or Y_PARAM are + or - FLT_MAX, return invalid number. Even if we
	// later use infinity instead of float max, since infinity is also used as invalid input status, 
	// we should treat infinity in the same way (rather than leaving the maths engine to sort it out).
	// Otherwise we could return values which are valid numbers (generally a zero) despite invalid input status.
	// Also test for X_PARAM negative combined with Y_PARAM non-integer to avoid NaN return from function.
	float xparam = X_PARAM;	// use local variable to avoid multiple function calls
	float yparam = Y_PARAM;
	float ymodulus = fmodf(yparam, 1.0F);	// fmodf seems to work OK for second value of 1
	if ((xparam >= FLT_MAX) || (xparam <= -FLT_MAX) || (yparam >= FLT_MAX) || (yparam <= -FLT_MAX)) {
		pRes->fResult = -FLT_MAX;	// use -FLT_MAX as invalid number
	} else if ((xparam < 0.0F) && (ymodulus != 0.0F)) {
		pRes->fResult = -FLT_MAX;	// use -FLT_MAX as invalid number
	} else {
		pRes->fResult = pow(xparam, yparam);
		CheckPosINF(pRes);	// check for positive infinity 
	}
}

//*********************************************************************************************
/// round[x] - Rounds x to the nearest whole number
//*********************************************************************************************	
void FP_round(CSignature *pSig, CExecutionContext *objContext, V6FUNCRESULT *pRes, V6ERRORINFO *pErr) {
	pRes->Type = DT_FLOAT;	// Return type
	pRes->fResult = ((X_PARAM > 0) ? floor(X_PARAM + 0.5f) : ceil(X_PARAM - 0.5f));
	// FLT_MAX or -FLT_MAX pass through unchanged
}

//*********************************************************************************************
/// sq[x] - Square of x (x * x)
//*********************************************************************************************	
void FP_sq(CSignature *pSig, CExecutionContext *objContext, V6FUNCRESULT *pRes, V6ERRORINFO *pErr) {
	pRes->Type = DT_FLOAT;		// Return type
	pRes->fResult = X_PARAM * X_PARAM;
	CheckPosINF(pRes);		// value can become too large - check for infinity
}

//*********************************************************************************************
/// recip[x] - Reciprocal of x or 1/x
//*********************************************************************************************	
void FP_recip(CSignature *pSig, CExecutionContext *objContext, V6FUNCRESULT *pRes, V6ERRORINFO *pErr) {
	pRes->Type = DT_FLOAT;		// Return type
	// trap +/- FLT_MAX input to retain an invalid status
	float xparam = X_PARAM;	// use local variable to avoid multiple function calls
	if ((xparam >= FLT_MAX) || (xparam <= -FLT_MAX)) {
		pRes->fResult = -FLT_MAX;	// use -FLT_MAX as invalid number
	} else {
		pRes->fResult = 1.0 / xparam;
		CheckPosINF(pRes);	// value can become too large - check for infinity
	}
}

//*********************************************************************************************
/// root[x,y] - the y root of value x
//*********************************************************************************************	
void FP_root(CSignature *pSig, CExecutionContext *objContext, V6FUNCRESULT *pRes, V6ERRORINFO *pErr) {
	pRes->Type = DT_FLOAT;		// Return type
	// If either X_PARAM or Y_PARAM are + or - FLT_MAX, return invalid number to display stars
	// (same issues as for pow[x,y] above)
	// Also trap negative X_PARAM combined with Y_PARAM which produces non-integer 1/Y_PARAM
	float xparam = X_PARAM;	// use local variable to avoid multiple function calls
	float yparam = Y_PARAM;
	float ymodulus = 0.0;
	// avoid NaN return from fmodf
	if (yparam != 0.0) {
		ymodulus = fmodf(1.0F / yparam, 1.0F); // fmodf seems to work OK for second value of 1
	}
	if ((xparam >= FLT_MAX) || (xparam <= -FLT_MAX) || (yparam >= FLT_MAX) || (yparam <= -FLT_MAX)) {
		pRes->fResult = -FLT_MAX;	// use -FLT_MAX as invalid number
	} else if ((xparam < 0.0F) && (ymodulus != 0.0F)) {
		pRes->fResult = -FLT_MAX;	// use -FLT_MAX as invalid number
	} else {
		pRes->fResult = pow(xparam, (1.0f / yparam));
		CheckPosINF(pRes);	// check for positive infinity 
	}
}

//*********************************************************************************************
/// eval[x] - returns 1 if x is non-zero, otherwise return 0
//*********************************************************************************************	
void FP_eval(CSignature *pSig, CExecutionContext *objContext, V6FUNCRESULT *pRes, V6ERRORINFO *pErr) {
	pRes->Type = DT_FLOAT;		// Return type
	if (X_PARAM != 0.0) {
		pRes->fResult = 1.0;
	} else {
		pRes->fResult = 0.0;
	}
	// Invalid numbers will be +/- FLT_MAX and will evaluate as non-zero.
}

///============================================================================================
/// Comparisons and conversions
///============================================================================================

//*********************************************************************************************
/// f2c[x] Fahrenheit x to Celsius
//*********************************************************************************************	
void FP_f2c(CSignature *pSig, CExecutionContext *objContext, V6FUNCRESULT *pRes, V6ERRORINFO *pErr) {
	pRes->Type = DT_FLOAT;	// Return type
pRes->fResult = DegFToDegC( X_PARAM );
// DegFToDegC and similar conversions are defined in Conversion.h. If FLT_MAX is passed in as a 
// representation of infinity it could get returned as infinity, or calculated downwn
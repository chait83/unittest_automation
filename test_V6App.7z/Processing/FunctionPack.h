/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Processing
/// @n Filename: FucntionPack.h
/// @n Desc:	 Contains all functions available for Maths blocks and scripts
///				 provdiign the interface between V6 application and Scirpt processor
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  28  Stability Project 1.25.1.1 7/2/2011 4:57:24 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  27  Stability Project 1.25.1.0 7/1/2011 4:27:13 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  26  V6 Firmware 1.25 2/6/2008 6:39:09 PM Andy Kassell  Add
//  GETS[x] function, to retrieve the current screen number
//  25  V6 Firmware 1.24 10/19/2007 4:59:34 PM  Andy Kassell  Add
//  ATOT[] function which returns the total number of alarms in alarm on
//  the system
// $
//
// ****************************************************************

#if !defined(FUNCPACK_H__INCLUDED_)
#define FUNCPACK_H__INCLUDED_

#define FUNCPACK_API __declspec(dllexport)

#include "LibraryInterface.h"

/// Function identifiers
typedef enum {
	/// Math functions
	FP_SIN,
	FP_COS,
	FP_TAN,
	FP_SINH,
	FP_COSH,
	FP_TANH,
	FP_ASIN,
	FP_ACOS,
	FP_ATAN,
	FP_CEIL,
	FP_FLOOR,
	FP_FABS,
	FP_EXP,
	FP_LN,
	FP_LOG,
	FP_SQRT,
	FP_POW,
	FP_ROUND,
	FP_SQ,
	FP_RECIP,
	FP_ROOT,
	FP_EVAL,

	/// Conversions and comparisons
	FP_F2C,
	FP_C2F,
	FP_LO,
	FP_HI,
	FP_LO4,
	FP_HI4,
	FP_OVER,
	FP_UNDER,
	FP_INSIDE,
	FP_OUTSIDE,
	FP_RHC,
	FP_RHF,

	// Timers
	FP_TRUN,
	FP_TPAUSE,
	FP_TRESET,
	FP_TGET,

	/// Accessors
	FP_LOCV,
	FP_GLBV,
	FP_PEN,
	FP_AI,
	FP_DI,
	FP_DCNT,
	FP_TOT,
	FP_ALMCT,
	FP_ALMST,
	FP_ATOT,
	FP_ALMRT,
	FP_ALMSL,
	FP_UVSET,
	FP_SCV,
	FP_BLNAME,
	FP_BLUSER,
	FP_BLLOT,
	FP_BLDESC,
	FP_BLCOMM,
	FP_PRMAX,
	FP_PRMIN,
	FP_PRAVE,
	FP_PRTOT,
	FP_TRIGE,
	FP_CLRE,
	FP_SETD,
	FP_GETS,

	/// Attribute blocks
	FP_ATFGCOL,
	FP_ATBGCOL,
	FP_ATVIS,
	FP_ATFLSH,

	/// Misc
	FP_DAMP,

	/// Add new fucntion identifiers here
	FP_MAX_FUNCTIONS		///< ALWAYS AT END - Maximum number of exportable function defined
} T_FUNCTION_ID;

const int FUNCTION_NAME_MAX_LENGTH = 12;			///< Maximum fucntion Name length
const int FUNCTION_PARAM_MAX_LENGTH = 80;			///< Maximum Parameter string length
const int FUNCTION_ARG_MAX_LENGTH = FUNCTION_PARAM_MAX_LENGTH - 10;		///< Maximum Parameter string length
const int FUNCTION_NAME_MATCH = 0;

// Fucntion information for main fucntion pack table
typedef struct {
	T_FUNCTION_ID functionID;						///< Function unique identifier
	FPFUNCPTR pFunction;							///< pointer to function
	char functionName[FUNCTION_NAME_MAX_LENGTH];	///< Name of Function
	char functionParams[FUNCTION_PARAM_MAX_LENGTH];	///< String containing fucntion arguments

} T_FUNCTION_INFO;

// Timer informations for script based timer functions
typedef struct {
	LONGLONG accTime;			///< Accumulated Time
	LONGLONG lastStart;			///< Last Start Time
	BOOL IsRunning;				///< Is timer running (TRUE) or paused/stopped(FALSE)
} T_SCRIPT_TIMERS;

extern FPGETPROCFUNCPTR FUNCPACK_API g_fnFuncPackGetProc;

// Function Prototypes
int CreateExportTable();
void BuildCapabilitiesTable(char *pTable, int size);

extern "C" {
void FUNCPACK_API FP_GetFuncPackProcAddress(char *szFuncName, FPFUNCPTR *pFnc, V6ERRORINFO *pErr);
void FUNCPACK_API FP_resetScriptTimer(USHORT timerIndex);
float FUNCPACK_API FP_runScriptTimer(USHORT timerIndex, BOOL resetRequired);
float FUNCPACK_API FP_pauseScriptTimer(USHORT timerIndex);
float FUNCPACK_API FP_GetScriptTimer(USHORT timerIndex);
BOOL FUNCPACK_API FP_IsScriptTimerRunning(USHORT timerIndex);
}
;

#endif


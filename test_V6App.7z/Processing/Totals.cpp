/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Processing
/// @n Filename: totals.cpp
/// @n Desc:	 Manage totals within the recorder system
///				 
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  32  Stability Project 1.27.1.3 7/2/2011 5:02:08 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  31  Stability Project 1.27.1.2 7/1/2011 4:39:02 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  30  Stability Project 1.27.1.1 3/17/2011 3:20:50 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  29  Stability Project 1.27.1.0 2/15/2011 3:04:05 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// ****************************************************************

#include "totals.h"
#include "TraceDefines.h"
#include "math.h"
#include "V6ResourceBase.h"
#include "V6UIResource.h"
#include "EventManager.h"
#include "pencontrol.h"

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif

const double RESET_TOTAL_TO_ZERO = 0.0F;
const double BACKFLOW_LIMIT = 0.0F;			///< If ignore backflow set must be greater then 0
const double STERILISATION_BASE = 10.0F;		///< Base to be raised by the Death Rate sterilisation
const int TOTAL_CALCS_PER_MINUTE = 60;		///< Number of totalisation calculation per minute for sterilisation

T_EVENTDATA CTotal::actionMask[TOTAL_MAX_MODES];	///< We need to accumulate the actions over all totals
													/// so making this a static ot be shared.

//**********************************************************************
/// CPenManager constructor
///
//**********************************************************************
CTotal::CTotal() {
	m_modeRequest = TOTAL_MODE_UNCHANGED;
	m_Enabled = FALSE;
	m_countDownTimer = 0;
	m_totData.runTimeInSeconds = 0;
	m_totData.startTime = 0;
	CTotal::ClearEventCauseTriggers();
	m_pScaleDetails = NULL;
}

//**********************************************************************
/// Initialise the totaliser to the relevant pen number
/// 
/// @param[in]	penNumber - number of pen that the total belongs to. 0 to MAX_PENS-1
///
/// @return		T_TOTALS_RETURN as status of call
/// 
//**********************************************************************
T_TOTALS_RETURN CTotal::IntialiseTotal(USHORT penNumber, T_PEN_REPORT *pReport) {
	T_TOTALS_RETURN retVal = RET_TOTAL_OKAY;

	m_pReport = pReport;	// Assign report pointer

	// Is the pen within the valid pen range?
	if (penNumber < V6_MAX_PENS) {
		// Yes, Pen and Totaliser will be available in DIT, proceed with configuration
		m_penNumber = penNumber;

//		::sleep(100); Add sleep comment to avoid crash during initialisation.

		// Get handle on Pen Data Item for this totaliser
		m_pPenDataItem = (CDataItemPen*) pGlbDIT->GetDataItemPtr(DI_PEN, DI_PEN_READING, m_penNumber);
		if (m_pPenDataItem == NULL) {
			LOG_CRTL(TRACE_PROCESSING, "Pen Data item does not exist %d \n", m_penNumber);
			retVal = RET_TOTAL_INIT_FAILED;
		}
		// Get handle on the related totaliser Data Item
		m_pTotalDataItem = (CDataItemTotal*) pGlbDIT->GetDataItemPtr(DI_TOTAL, DI_TOTAL_READING, m_penNumber);
		if (m_pTotalDataItem == NULL) {
			LOG_CRTL(TRACE_PROCESSING, "total Data item does not exist for pen %d \n", m_penNumber);
			retVal = RET_TOTAL_INIT_FAILED;
		}

		// Retreive Non volatile totaliser information
		// m_totData.runTimeInSeconds = Get it from NV.
		m_pTotalInNV = pNV_VARS->GetTotaliserNVObject(static_cast<NVVAR_IDENT>(NVV_PEN_TOTAL_FIRST + penNumber));

		m_totData.currentMode = m_pTotalInNV->GetFromNV()->currentMode;
		m_totData.runTimeInSeconds = m_pTotalInNV->GetFromNV()->runTimeInSeconds;
		m_totData.startTime = m_pTotalInNV->GetFromNV()->startTime;
		m_totData.totalValue = (double) m_pTotalInNV->GetFromNV()->totalValue;

		if (m_totData.currentMode == TOTAL_MODE_UNCHANGED) {
			// NV has never been used, so totlaiser in unknown state, reset it.
			ClearDown();
		} else {
			// Get all other information and update DIT
			StoreNewTotaliser();
		}

		// Process any startup action
		m_StartupRequestSet = TRUE;		// Assume startup request will be set
		// Check for actions to be performed on a configuration change
		if ( pSYSTEM_INFO->GetStartupResetAction()->ResumeTotals == TRUE) {
			RequestTotalMode(TOTAL_MODE_RUN);
		} else if ( pSYSTEM_INFO->GetStartupResetAction()->ResetTotals == TRUE) {
			RequestTotalMode(TOTAL_MODE_RESET);
		} else {
			m_StartupRequestSet = FALSE;	// No startup request was set
		}
	} else {
		retVal = RET_TOTAL_INIT_FAILED;
	}
	return retVal;
}

//**********************************************************************
/// Cleardown a totlaiser, when not active this puts totaliser into a reset
/// state, if reactivated previous totlaiser setting not used
///
/// @return		nothing
/// 
//**********************************************************************
void CTotal::ClearDown() {
	m_modeRequest = TOTAL_MODE_RUN;					// Mode request run, so total is started as soon as it is enabled
	m_totData.currentMode = TOTAL_MODE_RESET;// Current mode reset, when a start attepted will be a start for first time
	m_totData.runTimeInSeconds = 0;					// No accumulated run time.
	m_totData.startTime = 0;						// No start Time
	m_totData.totalValue = 0;
	StoreNewTotaliser();							// Store the defaulted totaliser

}

//**********************************************************************
/// Reset the totaliser report
///
/// @return		nothing
/// 
//**********************************************************************
void CTotal::ResetTotalReport() {
	for (int totalIndex = 0; totalIndex < REPORT_HISTORY; totalIndex++) {
		m_pReport->set[totalIndex].period[RP_HOUR].totalVal = 0;
		m_pReport->set[totalIndex].period[RP_DAY].totalVal = 0;
		m_pReport->set[totalIndex].period[RP_WEEK].totalVal = 0;
		m_pReport->set[totalIndex].period[RP_MONTH].totalVal = 0;
	}
}

//**********************************************************************
/// Set the configuration of the totalise, done at startup and with
/// each configuration change
/// 
/// @param[in]	pPenCfg - ptr to pen configuration in CMM for this totaliser
/// @param[in]	penRateInTicks - pens process rate in ticks
///
/// @return		T_TOTALS_RETURN as status of call
/// 
//**********************************************************************
T_TOTALS_RETURN CTotal::SetTotalFromConfig(T_PPEN pPenCfg, int penRateInTicks) {
	T_TOTALS_RETURN retVal = RET_TOTAL_OKAY;

	BOOL clearDownTotal = FALSE;		// Used to cleardown a totlaiser that is not enabled 

	// Set-up a pointers to the pen and totaliser configuration
	m_pPenCfg = pPenCfg;
	m_pTotalCfg = &pPenCfg->Tot;

	// get scale details
	m_pScaleDetails = m_pPenDataItem->GetScaleInfo();

	// Turn off processing for this total. these will be enabled depending on new config
	m_Enabled = FALSE;

	// Are totalisers enabled in the firmware options?
	if ( pSYSTEM_INFO->FWOptionTotalsAvailable() == TRUE) {
		// Is pen enabled?
		if (m_pPenCfg->Enabled) {
			// Yes, Pen enabled so is totaliser enabled?
			if (m_pTotalCfg->Enabled) {
				m_countDownTimer = 0;	// Do an immediate totalisation

				if (m_pTotalCfg->Type == TOTAL_TYPE_STANDARD) {
					// Specific configuration for Standard totalisers
					m_StdTotFactor = m_pTotalCfg->TimeFactor * m_pTotalCfg->UnitFactor;
				} else {
					// Specific configuration for Sterilisers

					// Convert from configuration temp unit (always in deg C) to that of the Pen as specified by user in Totaliser options
					m_TempStart = TempFromDegC(static_cast<T_TEMP_UNIT>(m_pTotalCfg->TempInputUnits),
							m_pTotalCfg->TempStart, CONVERT_ABSOLUTE);
					m_TempRef = TempFromDegC(static_cast<T_TEMP_UNIT>(m_pTotalCfg->TempInputUnits),
							m_pTotalCfg->TempRef, CONVERT_ABSOLUTE);
					m_Zfactor = TempFromDegC(static_cast<T_TEMP_UNIT>(m_pTotalCfg->TempInputUnits),
							m_pTotalCfg->Zfactor, CONVERT_RELATIVE);
				}

				// Pen and enabled
				m_Enabled = TRUE;

				// Set-up the DIT status from current mode
				if (m_totData.currentMode == TOTAL_MODE_RUN) {
					// Previously in run mode
					m_pTotalDataItem->SetStatus(DISTAT_TOTAL_RUNNING);
				} else {
					// Previously in reset, unchanged or paused.
					m_pTotalDataItem->SetStatus(DISTAT_TOTAL_PAUSED);
				}

				// Only check for config change actions if there has been no startup request
				if (m_StartupRequestSet == FALSE) {
					// Check for actions to be performed on a configuration change
					if ( pSYSTEM_INFO->GetConfigChangeResetAction()->ResumeTotals == TRUE) {
						RequestTotalMode(TOTAL_MODE_RUN);
					}
					if ( pSYSTEM_INFO->GetConfigChangeResetAction()->ResetTotals == TRUE) {
						RequestTotalMode(TOTAL_MODE_RESET);
					}
				}

				// if restricted range has been configured, amke sure totaliser starts within that range
				if (m_pTotalCfg->RestrictRange == TRUE) {
					if (m_totData.totalValue < m_pTotalCfg->MinRange) {
						m_totData.totalValue = m_pTotalCfg->MinRange;
					} else if (m_totData.totalValue > m_pTotalCfg->MaxRange) {
						m_totData.totalValue = m_pTotalCfg->MaxRange;
					}
				}

			} else {
				ClearDown();	// Totalsier not enabled, so clear down the totlaiser 
			}
		} else {
			ClearDown();	// Pen containing totlaiser not enabled so cleardown totaliser
		}
	} else {
		ClearDown();	// Totaliser option not available so cleardown totlaiser
	}

	// Load report totaliser intop double precision working version
	m_reportHourTot = (double) m_pReport->set[WORKING_REPORT].period[RP_HOUR].totalVal;

	m_StartupRequestSet = FALSE;

	return retVal;
}

//**********************************************************************
/// Put totaliser into run mode 
///
/// @return		nothing
//**********************************************************************
void CTotal::SetRunMode() {
	// Is the totaliser curreently in run mode?
	if (m_totData.currentMode != TOTAL_MODE_RUN) {
		BOOL newTotalisation = FALSE;
		// Is this the first time the totlaiser has been run after a reset
		if (m_totData.currentMode == TOTAL_MODE_RESET) {
			m_totData.startTime = pSYSTIMER->GetCurrentProcessTimeInMicroSec();
			newTotalisation = TRUE;
		}

		// No, so start the totaliser running
		m_pTotalDataItem->SetStatus(DISTAT_TOTAL_RUNNING);
		m_totData.currentMode = TOTAL_MODE_RUN;
		/// @todo post message to events list
		if (m_pTotalCfg->AddToMsgList) {
			if (newTotalisation == TRUE) {
				LogMessage(MSGLISTSER_USER_GROUP_TOTALS_STARTED, IDS_TOTAL_MESSAGE_STARTED);
			} else {
				LogMessage(MSGLISTSER_USER_GROUP_TOTALS_RESUMED, IDS_TOTAL_MESSAGE_RESUMED);
			}
		}
		/// Notify event system
		SetEventCauseTrigger(TOTAL_MODE_RUN);

		StoreNewTotaliser();
	}
}

//**********************************************************************
/// Put totaliser into pause mode 
///
/// @return		nothing
//**********************************************************************
void CTotal::SetPauseMode() {
	// Is the totaliser currently in pause mode
	if (m_totData.currentMode != TOTAL_MODE_PAUSE) {
		// No, pause the totaliser
		m_totData.currentMode = TOTAL_MODE_PAUSE;
		m_pTotalDataItem->SetStatus(DISTAT_TOTAL_PAUSED);
		// Send to message list of configured to do so
		if (m_pTotalCfg->AddToMsgList) {
			LogMessage(MSGLISTSER_USER_GROUP_TOTALS_PAUSED, IDS_TOTAL_MESSAGE_PAUSED);
		}
		/// Notify event system
		SetEventCauseTrigger(TOTAL_MODE_PAUSE);

		StoreNewTotaliser();
	}
}

//**********************************************************************
/// Put totaliser into pause mode 
///
/// @return		nothing
//**********************************************************************
void CTotal::SetResetMode() {
	m_totData.runTimeInSeconds = 0;

	// is this a normal totaliser with a range restriction?
	if (m_pTotalCfg->Type == TOTAL_TYPE_STANDARD && m_pTotalCfg->RestrictRange == TRUE) {
		// Yes, reset to the range restriction not to zero
		m_totData.totalValue = m_pTotalCfg->MinRange;
	} else {
		m_totData.totalValue = 0.0;
	}

	// reset a report on a totaliser reset
	ResetTotalReport();

	// Send to message list of configured to do so
	if (m_pTotalCfg->AddToMsgList) {
		LogMessage(MSGLISTSER_USER_GROUP_TOTALS_RESET, IDS_TOTAL_MESSAGE_RESET);
	}
	/// Notify event system
	SetEventCauseTrigger(TOTAL_MODE_RESET);

	StoreNewTotaliser();

	// reset double precision running totaliser
	m_reportHourTot = 0;
}

//**********************************************************************
/// Perform a mode change on the totaliser, run, pause or reset
/// 
/// @param[in]	mode - T_TOTAL_MODE mode type to perform
///
/// @return		T_TOTALS_RETURN as status of call
/// 
//**********************************************************************
T_TOTALS_RETURN CTotal::PerformModeChangeAction(T_TOTAL_MODE mode) {
	T_TOTALS_RETURN retVal = RET_TOTAL_OKAY;
	/// Perform relevant action depending on mode
	switch (mode) {
	case TOTAL_MODE_RUN:			// Start/resume totaliser
	{
		SetRunMode();
	}
		break;
	case TOTAL_MODE_PAUSE:			// pause/stop the totaliser
	{
		SetPauseMode();
	}
		break;
	case TOTAL_MODE_RESET:			// reset the totaliser
	{
		SetResetMode();
	}
		break;
	case TOTAL_MODE_RESET_START:	// Reset and start the totaliser
	{
		SetResetMode();
		SetRunMode();
	}
		break;

	default: {
		qDebug("Unknown or unhnadled T_TOTAL_MODE %d \n", mode);
		m_modeRequest = TOTAL_MODE_RESET;
	}
		break;
	}
	return retVal;
}

//**********************************************************************
/// Log the totaliser messages in the following format
/// "Total <number> - <name> 'action' "
///
/// @param[in]	type - T_MSGLISTSER_USER_MSG_TYPE type of message for list
/// @param[in]	messID - message ID of string in string table
///	
/// @return		nothing
//**********************************************************************
void CTotal::LogMessage(T_MSGLISTSER_USER_MSG_TYPE type, UINT messID) {
	QString   strMessage("");
	QString   strasprintfString("");
	strasprintfString.LoadString(messID);
	strMessage.asprintf(strasprintfString, m_penNumber + 1, m_pTotalDataItem->GetTag());
	LOG_DATA_MESSAGE(type, strMessage);
}

//**********************************************************************
/// Process the totaliser, for both Standard and Sterilisation 
/// 
/// @return		nothing
//**********************************************************************
void CTotal::ProcessTotal() {
	// Countdown time ramps down the totaliser processing to once a second
	if (--m_countDownTimer <= 0) {
		// Is there a mode change request?
		if (m_modeRequest != TOTAL_MODE_UNCHANGED) {
			// Yes, perform mode change
			PerformModeChangeAction(m_modeRequest);
			m_modeRequest = TOTAL_MODE_UNCHANGED;		// Mode change has been actioned
		}

		// Is the totaliser currently in Run mode? Also, only process if NOT an error value
		if ((m_totData.currentMode == TOTAL_MODE_RUN) && (m_pPenDataItem->GetStatus() >= DISTAT_NORMAL)) {
			// Yes, fetch pen and current totaliser value to work on.
			double penValue = (double) m_pPenDataItem->GetFPValue();

			// Check if report totaliser has been reset
			if (m_pReport->set[WORKING_REPORT].period[RP_HOUR].totalVal == 0) {
				// Report totaliser reset, so reset double precision working version
				m_reportHourTot = 0;
			}

			// determine type of totaliser and run according calculations
			if (m_pTotalCfg->Type == TOTAL_TYPE_STANDARD) {
				// Perform standard totalising function
				// Increment totalising time in seconds				
				m_totData.runTimeInSeconds++;
				// If backflow if allowed or (if backflow is not allowed make sure it's above the desired level)
				if (m_pTotalCfg->NoBackflow == FALSE || penValue > m_pTotalCfg->BackFlowLevel) {
					// Calculate the totalised value
					// if log scale, use 10^(value). 
					// To scale by m_StdTotFactor, subtract log10(m_StdTotFactor) from penValue
					if (m_pScaleDetails->LogScale) {
						double logValue = penValue - (log10(m_StdTotFactor));
						if (logValue < MAX_POWER_OF_10)	// trap for error - much more likely for logs
								{
							double addition = pow((double) 10.0, logValue);
							m_totData.totalValue += addition;
							m_reportHourTot += addition;
						} else {
							m_totData.totalValue = FLT_MAX;	// will get displayed as LARGEST_POS_TOTAL_NUMBER
						}
					} else {
						double addition = penValue / m_StdTotFactor;
						m_reportHourTot += addition;

						// Reset Totaliser and Fire Totaliser rollover event when totaliser exceed 
						//	Floating point precision

						if ((m_totData.totalValue + addition >= LARGEST_FLOAT_PRECISION_NUMBER)
								&& (m_pTotalCfg->Reset16Millon)) /// Notify event system Added flag to reset totaliser after 16 Million
								{
							addition -= LARGEST_FLOAT_PRECISION_NUMBER - m_totData.totalValue;
							SetEventCauseTrigger(TOTAL_MODE_ROLLOVER);
							m_totData.totalValue = 0;
						}

						m_totData.totalValue += addition;
					}

					// Is the totaliser range restricted and is over the limit?
					if (m_pTotalCfg->RestrictRange == TRUE) {
						if (m_totData.totalValue > m_pTotalCfg->MaxRange) {
							// Yes, over the limit, so needs to be reset but do we carry remainder?
							if (m_pTotalCfg->CarryOnRoll == TRUE) {
								// Yes, Reset but retain accumulated total above the MaxRange value
								m_totData.totalValue -= (m_pTotalCfg->MaxRange - m_pTotalCfg->MinRange);
							} else {
								// No, Reset the totaliser to the MinRange value.
								m_totData.totalValue = m_pTotalCfg->MinRange;
							}
						} else if (m_totData.totalValue < m_pTotalCfg->MinRange) {
							// Yes, under the limit, so needs to be reset but do we carry remainder?
							if (m_pTotalCfg->CarryOnRoll == TRUE) {
								// Yes, Reset but retain accumulated total below the MaxRange value
								m_totData.totalValue += (m_pTotalCfg->MaxRange - m_pTotalCfg->MinRange);
							} else {
								// No, Reset the totaliser to the MaxRange value.
								m_totData.totalValue = m_pTotalCfg->MaxRange;
							}
						}
					} else {
						// Check that the totaliser is not greater then the largest possible number
						if (m_totData.totalValue > LARGEST_POS_TOTAL_NUMBER) {
							m_totData.totalValue = LARGEST_POS_TOTAL_NUMBER;
							RequestTotalMode(TOTAL_MODE_PAUSE);
						} else if (m_totData.totalValue < LARGEST_NEG_TOTAL_NUMBER) {
							m_totData.totalValue = LARGEST_NEG_TOTAL_NUMBER;
							RequestTotalMode(TOTAL_MODE_PAUSE);
						}
					}
					StoreChangedTotaliser();	// Totaliser updated, so timestamp it and persist
				}
			} else // Perform sterilisation calculations
			{
				// Is the input pen temperature above the start temperature threshold?
				if (penValue > m_TempStart) {
					// yes, Are we still in the sterilisation phase OR allowing cool down phase to be included
					if (m_totData.totalValue < m_pTotalCfg->CompleteVal || m_pTotalCfg->IncludeCool == TRUE) {
						m_totData.runTimeInSeconds++;
						// To Perform sterilsation calculation 
						// firstly calculate the death rate power
						// deathRatePower is the (current temperature - reference temperature (F0 = 121.11 degC)
						// divided by the temperature coeffecient or ZFactor to provide the number of degrees
						double deathRatePower = (penValue - m_TempRef) / m_Zfactor;
						// Then raise 10 to the death rate power to provide the equvilent time unit
						// inreference to temp = TempRef (F0 121.11) = 1 Minute.
						double addition = (pow(STERILISATION_BASE, deathRatePower)) / TOTAL_CALCS_PER_MINUTE;
						m_totData.totalValue += addition;
						m_reportHourTot += addition;
						StoreChangedTotaliser();	// Totaliser updated, so timestamp it and persist
					}
				}
			}
			// Set report totaliser value with double precision working version
			m_pReport->set[WORKING_REPORT].period[RP_HOUR].totalVal = (float) m_reportHourTot;
		}

		// Reload countdown timer to process in 1 seconds time
		m_countDownTimer = pSYSTIMER->GetProcessSlicesPerSecond();
	}
}

//**********************************************************************
/// Current totaliser value has changed, so timetsamp change
/// and persist.
///
/// @param[in]	newTotalValue - new totaliser value to set
/// 
/// @return		nothing
//**********************************************************************
void CTotal::StoreChangedTotaliser() {
	m_pTotalDataItem->SetValue((float) m_totData.totalValue);
	m_pTotalInNV->SetOptimumNV((float) m_totData.totalValue, m_totData.runTimeInSeconds);
}

//**********************************************************************
/// Store a new totlaiser value in static RAM.
///
/// @param[in]	newTotalValue - new totaliser value to set
///
/// @return		nothing
//**********************************************************************
void CTotal::StoreNewTotaliser() {
	m_pTotalDataItem->SetValue((float) m_totData.totalValue);
	m_pTotalDataItem->SetTime(m_totData.startTime);

	// AK - Convert the modified NV structure back to NV compatible layout
	T_NV_TOTALISER totDataToSet;
	totDataToSet.currentMode = m_totData.currentMode;
	totDataToSet.runTimeInSeconds = m_totData.runTimeInSeconds;
	totDataToSet.startTime = m_totData.startTime;
	totDataToSet.totalValue = (float) m_totData.totalValue;
	// End conversion

	m_pTotalInNV->SetAllNV(totDataToSet);
}

//**********************************************************************
/// Clearfdown event trigger masks - STATIC 
/// 
/// @return		nothing
//**********************************************************************
void CTotal::ClearEventCauseTriggers() {
	// Run though all modes (0 not a mode that needs registereing) and clear the trigger mask
	for (int modeIndex = 1; modeIndex < TOTAL_MAX_MODES; modeIndex++) {
		CEventManager::ClearMask(&CTotal::actionMask[modeIndex]);
	}
}

//**********************************************************************
/// Set event trigger mask that a totaliser action has occured 
/// 
/// @param[in]	mode - action that has been performed
///
/// @return		nothing
//**********************************************************************
void CTotal::SetEventCauseTrigger(T_TOTAL_MODE mode) {
	CEventManager::SetBitInMask(m_penNumber, &CTotal::actionMask[(int) mode]);
}


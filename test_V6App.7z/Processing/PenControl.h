/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Processing
/// @n Filename: PenControl.h
/// @n Desc:	 Manage all aspects of a Pen within the system
///				 
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  45  Stability Project 1.42.1.1 7/2/2011 4:59:40 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  44  Stability Project 1.42.1.0 7/1/2011 4:27:10 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  43  V6 Firmware 1.42 9/25/2009 3:20:02 PM  Binsy Pillai  
//  event cursor merging of code
//  42  V6 Firmware 1.41 4/16/2007 7:31:17 PM  Andy Kassell  
//  Don't check for report reset on first pass after poweron
// $
//
// ****************************************************************

#ifndef __PENCONTROL_H__
#define __PENCONTROL_H__

#include "V6defines.h"
#include "V6globals.h"
#include "V6Config.h"
#include "alarms.h"
#include "totals.h"
#include "QMDataBlock.h"
#include "QueueManager.h"
#include "BasicMaxMinAve.h"
#include "chartqueues.h"
#include "LogChannel.h"			
#include "Scripts.h"
#include "maxmins.h"
#include "pipeprocess.h"
#include "reportData.h"
#include "pretrigger.h"

class CPenManager;

#define NAN_TEST_VALUE 0x7f800000			///< Not a number test value
/// Logging modes and actions
typedef enum {
	LOGGING_MODE_UNCHANGED = 0,				///< Mode unchanged from last itteration (when being used as action)
	LOGGING_MODE_START,						///< Stop logging
	LOGGING_MODE_STOP,						///< Start logging
	LOGGING_MODE_FLUSH,						///< Flush incomplete blocks
	LOGGING_MODE_RESTORE,					///< Restore previous state after a power-cycle
	LOGGING_MODE_SHUTDOWN,					///< Shut-down (don't update NV-state)

	LOGGING_MAX_MODES						///< Total number of logging modes **Always at end
} T_LOGGING_MODE;

/// Return types for PenControl access
typedef enum {
	PEN_OKAY = 0,						///< Function completed okay
	PEN_INIT_FAILED,				///< Failure to Initialise Pen
	PEN_CONFIG_FAILED,				///< Failure to configure Pen
	PEN_MATH_VAR_DOES_NOT_EXIST,	///< Pen failed in Maths configuring the variable lookup
	PEN_MATH_SCRIPTERR,				///< Pen failed in Maths configuring the script
} T_PEN_CONTROL_RETURN;

const int PEN_EXECUTE_ON_FIRST_PROCESS = 1;
const int ACK_ALL_ALARMS = -1;
const int GROUP_CACHE_FIRST_USE = -1;
const int PRE_TRIGGER_SLOWEST_LOG_RATE = 10 * 10000;///< Slowest allowable log rate for pre trigger in millisecond tenths, 10 seconds per log

//**Class*********************************************************************
///
/// @brief Control of an individual Pen
/// 
/// The Pen control class provides all information related to a pen
/// for use throughout the system
///
///
//****************************************************************************
class CPenControl {
public:
	CPenControl();

public:		// API methods

	void SetPenInstance(short instance) {
		m_Instance = instance;
	}
	;
	short GetPenInstance() {
		return m_Instance;
	}
	;
	CDataItem* GetDataItem() {
		return m_pDirectVar;
	}
	;

	T_PEN_CONTROL_RETURN Initialise(T_PEN_REPORT *pReportNV);
	void CleanUp();
	/*	T_PEN_CONTROL_RETURN PowerRecovery( CQueueManager *pQM, 
	 CQMMemoryBlock *dataQueue, 
	 USHORT Instance );		// Tidy-up after a power failure and before a re-start
	 */
	T_PEN_CONTROL_RETURN SetPenFromConfig();
	T_PEN_CONTROL_RETURN ProcessPenMaths();
	T_PEN_CONTROL_RETURN ProcessPenLog();
	void ProcessTotaliser() {
		m_totaliser.ProcessTotal();
	}
	;

	void ProcessPenChartQueues();

	BOOL DeriveFastestRate(USHORT &returnRate);
	USHORT QueryPenRate() {
		return m_penRate;
	}
	;
	void SetPenProcessRates();

	const BOOL IsPenRunning() {
		return m_PenRunning;
	}
	;
	void SetPenRunningState(BOOL runState) {
		m_PenRunning = runState;
	}
	;
	const BOOL HasPenUpdated() {
		return m_PenValueChanged;
	}
	;

	// Accessors for reelvant Pen configuration within CMM
	void SetPenConfigPtr(T_PPEN pConfig) {
		m_pConfig = pConfig;
	}
	;
	const T_PPEN GetPenConfigPtr() {
		return m_pConfig;
	}
	;

	// Alarms
	void ClearAlarmStatus() {
		m_pPenDataItem->SetAlarmStatus(0);
		m_pPenDataItem->SetAlarmAckStatus(0);
	}
	;	// Set to No alarms "in alarm"
	CAlarm* GetAlarmPtr(int alarmNumber) {
		return &m_alarm[alarmNumber];
	}
	;
	BOOL IsAlarmToBeProcessed() {
		return m_ProcessAlarm;
	}
	;
	void AcknowledgeOrResetAlarm(int alarmNumber, T_ALARM_REQUEST reqType);

	// Logging
	CLogChannel* GetLoggingPtr() {
		return &m_logChannel;
	}
	;
	void ConfigureLoggingForPen();
	void StopPenLoggingDirect(BOOL bSaveState = TRUE);

	void RequestTotaliserAction(T_TOTAL_MODE totalAction) {
		m_totaliser.RequestTotalMode(totalAction);
	}
	;
	void RequestMaxMinAction(T_MAXMIN_MODE maxminAction) {
		m_MaxMin.RequestAction(maxminAction);
	}
	;

	BOOL IsMathDirectVar() {
		return m_UseDirect;
	}
	;

	void RequestLoggingMode(T_LOGGING_MODE newMode) {
		m_modeRequest = newMode;
	}
	;	///< Set logging mode

	/// Accessor for the logging mode flag
	const T_LOGGING_MODE GetLoggingMode() const {
		return m_modeRequest;
	}

	void wipeReport();
	float GetReportAverage(T_PEN_REPORT_DETAIL *pReportDetail);

	// Pre trigger functions
	void ProcessPreTrigger();
	void ResetPreTrigger() {
		m_preTrigger.ResetBuffer();
	}
	;

public:		// Member variables
	// Data logging object
	CLogChannel m_logChannel;

	CPenPreTrigger m_preTrigger;			///< Pre trigger information

private:	// Methods
	T_PEN_CONTROL_RETURN CPenControl::ManageChartQueues();
	T_PEN_CONTROL_RETURN PerformModeChangeAction(T_LOGGING_MODE mode);
	void CheckReportRollover();
	void UpdatePenReport(float newVal, T_DATAITEM_STATUS status, BOOL statusChanged);
	void UpdateMaxMinReport(float newVal, T_PEN_REPORT_SET *pReportSet);
	BOOL UpdateMax(T_PEN_REPORT_DETAIL *pReportDetail, float newVal);
	BOOL UpdateMin(T_PEN_REPORT_DETAIL *pReportDetail, float newVal);
	void UpdateAve(T_PEN_REPORT_DETAIL *pReportDetail, float newVal);
	void ResetReport(T_PEN_REPORT_DETAIL *pReportDetail, float newVal, T_DATAITEM_STATUS status);
	void TraceReportLine(T_PEN_REPORT_DETAIL *pReportDetail);
	void TraceReportComplete();

private:	// Member variables

	T_PPEN m_pConfig;				///< Ptr to the pens configuration block, see V6Config.h for T_PEN struct
	short m_Instance;				///< Pen Instance, Always 0 based (i.er. Pen1=0, Pen2=1 etc..)				

	CAlarm m_alarm[V6_MAX_ALARMS];	///< Alarm instances	

	CTotal m_totaliser;				///< Totaliser Instance

	CMaxMin m_MaxMin;				///< Max and Min for Pen

	CDataItemPen *m_pPenDataItem;	///< Pointer to Pen Data Item

	CDataItem *m_pDirectVar;		///< Direct Pointer ref to Source Data Item if not a script

	USHORT m_penRate;				///< Rate of Pen in 1/100ths 
	USHORT m_penRateCounterReload;	///< Pen rate counter reload
	int m_penRateCounter;			///< Pen rate counter for lower frequency processing
	BOOL m_ProcessAlarm;			///< Flag to indicate alarm can be processed

	CScriptInstance m_Script;		///< Script Instance for this Pen
	V6ERRORINFO m_scriptErr;		///< Script errors holder

	BOOL m_UseDirect;				///< Mirror of m_pConfig->UseDirect for quicker testing 

	BOOL m_PenRunning;				///< TRUE if Pen is running, even though pen maybe enabled in
									/// configuration, any problems with Math or Varibales will result
									/// if penRunning being set to False and being ignored in processing

	BOOL m_firstRun;				///< Is this the first time the pen has been run?

	BOOL m_PenValueChanged;			///< TRUE if the Pen Value changed on a call to ProcessPenMaths().

	static CChartQManager *m_pChartQManager;	///< static singleton reference to the Chart Manager

	T_LOGGING_MODE m_modeRequest;	///< Request to change mode of logging channel

	BOOL m_ForceUpdate;				///< Force a pen update.

	WCHAR m_previousPenTag[PEN_TAG_LEN];	///< Track changes in Pen tag over a config change for OPC A&E server

	int previousGroupNumberOPC;				///< Cache group number for OPC A&E change notification

	BOOL m_TriggerTimeChangeInScript;		///< A time change was triggered, make sure it filters to script engine

	CBasicAverage m_ravAverage;				///< Provide average of readings at Pen rate to RAV rate
	CPipeProcess m_ravProcess;				///< RAV Processing instance
	int m_ravSampleCountDown;				///< Countdown in Pen rate for each RAV sample
	int m_ravSampleCountReload;				///< Reload value for RavSampleCountDown
	BOOL m_ravRunning;						///< Overall is RAV enabled
	float currentRAVValue;					///< Current Rolling Average value	

	T_PEN_REPORT *m_pReport;				///< Pointer to the pen report in NV
	BOOL m_resetHourReport;
	BOOL m_resetDayReport;
	BOOL m_resetWeekReport;
	BOOL m_resetMonthReport;

	CPenManager *m_pPenManager;

	CBasicAverage m_rtPenAverage;				///< Provide average of readings of real time pen values

};

#endif //__PENCONTROL_H__

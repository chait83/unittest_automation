/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	Processing
/// @n Filename: PipeProcess.cpp
/// @n Desc:	Provide pipe based data processing RAV, DELAY, Rate of Change etc..
///				
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 11	Stability Project 1.6.1.3	7/2/2011 4:59:43 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 10	Stability Project 1.6.1.2	7/1/2011 4:38:38 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 9	Stability Project 1.6.1.1	3/17/2011 3:20:34 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 8	Stability Project 1.6.1.0	2/15/2011 3:03:40 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
// ****************************************************************

#include "PipeProcess.h"

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif

//**********************************************************************
/// CPipeProcess constructor
/// 
//**********************************************************************
CPipeProcess::CPipeProcess() {
	m_pPipe = NULL;
	m_pipeMaxSize = 0;
}

CPipeProcess::~CPipeProcess() {
	CleanPipe();
}

//**********************************************************************
/// Create the Pipe
///
/// @param[in]	type - T_PIPE_PROCESS_TYPE type of pipe to create
/// @param[in]	numReadings - Number of readings for the Pipe
///
/// @return		TRUE if succesful, otherwise False
/// 
//**********************************************************************
BOOL CPipeProcess::CreatePipe(T_PIPE_PROCESS_TYPE type, int numReadings, BOOL preFill) {
	BOOL retVal = TRUE;
	CleanPipe();			// Always clean the pipe
	m_pipeType = type;
	m_preFill = preFill;
	if (numReadings < MINIMUM_PIPE_SIZE) {
		numReadings = MINIMUM_PIPE_SIZE;
	}
	if (m_pipeType != PIPE_NONE) {
		if (numReadings < MAX_PIPE_SIZE) {
			m_pPipe = new float[numReadings];
			m_pipeMaxSize = numReadings;
		} else {
			retVal = FALSE;		// Readings exceed max size
		}
	}

	return retVal;
}

//**********************************************************************
/// Reset the pipe
///
/// @return		TRUE if succesful, otherwise False
//**********************************************************************
void CPipeProcess::CleanPipe() {
	if (m_pPipe != NULL) {
		delete m_pPipe;
	}
	m_pPipe = NULL;
	ResetPipe();
}

//**********************************************************************
/// Reset the pipe
///
/// @return		TRUE if succesful, otherwise False
//**********************************************************************
void CPipeProcess::ResetPipe() {

	m_pipeOldest = 0;
	m_pipeNewest = 0;
	m_pipeReadings = 0;
	m_runningTotal = 0;
	m_oldestReading = 0;
	m_maxValue = -FLT_MAX;	// Set max value to minimum floating point value
	m_minValue = FLT_MAX;	// Set min value to maximum floating point value
	m_LastResult = 0;

	// Reset tick counts
	m_pipeTick = 0;
	m_maxTick = 0;
	m_minTick = 0;
}

//**********************************************************************
/// Add reading to pipe and maintain
///
/// @param[in]	reading - reading to add to pipe
///
/// @return		TRUE if succesful, otherwise False
/// 
//**********************************************************************
float CPipeProcess::AddReadingToPipe(float reading) {
	float readingRemoved = reading;
	do {
		m_pipeTick++;
		m_currentReading = m_pipeNewest;
		m_pPipe[m_pipeNewest++] = reading;
		m_runningTotal += reading;
		if (m_pipeNewest >= m_pipeMaxSize) {
			m_pipeNewest = 0;
		}
		// Check if the pipe is already full
		if (m_pipeReadings < m_pipeMaxSize) {
			// Not yet, add an extra reading
			m_pipeReadings++;
		}

		// Is the oldest position is about to be overwritten
		if (m_pipeOldest == m_pipeNewest) {
			m_runningTotal -= m_oldestReading;	// Remove oldest reading from running total
			readingRemoved = m_oldestReading;// Set reading removed as current oldest reading (used for rate of change)
			m_oldestReading = m_pPipe[m_pipeOldest++];	// Retrive oldest reading to be removed on next cycle
			if (m_pipeOldest >= m_pipeMaxSize) {
				// Oldest pointer wrap
				m_pipeOldest = 0;
			}
		}
	} while (m_preFill == TRUE && m_pipeReadings < m_pipeMaxSize);
	return readingRemoved;
}

//**********************************************************************
/// Add reading to pipe and maintain
///
/// @param[in]	reading - reading to add to pipe
///
/// @return		TRUE if succesful, otherwise False
/// 
//**********************************************************************
float CPipeProcess::GetPipeResult() {
	float retVal = 0;
	switch (m_pipeType) {
	case PIPE_RAV: {
		retVal = m_runningTotal / m_pipeReadings;
		break;
	}
	case PIPE_DELAY: {
		retVal = m_pPipe[m_pipeOldest];
		break;
	}
	case PIPE_RATE_OF_CHANGE: {
		retVal = m_LastResult;
		break;
	}
	}
	return retVal;
}

//**********************************************************************
/// Add reading for rate of change
///
/// @param[in]	reading - reading to add to pipe
///
/// @return		result as a processed reading
//**********************************************************************
float CPipeProcess::AddReadingForRateOfChange(float reading) {
	float rateDiff = 0;
	float readingRemoved = 0;
	readingRemoved = AddReadingToPipe(reading);

	// Check if this reading is the new Max
	if (reading > m_maxValue) {
		m_maxValue = reading;	// Yes, assign as new Max value
		m_maxTick = m_pipeTick;
	}
	// Check if this reading is the new min
	if (reading < m_minValue) {
		m_minValue = reading;	// Yes, assign as new min reading
		m_minTick = m_pipeTick;
	}
	// If the reading that was removed is not same as new reading, check it was a max or a min
	if (readingRemoved != reading) {
		int pipeIndex = 0;
		// Is reading removed previously the Max value?
		if (readingRemoved >= m_maxValue) {
			m_maxValue = reading;
			// The reading removed was previously a max, find the new Max			
			pipeIndex = m_pipeOldest;
			for (int readingCount = 0; readingCount < m_pipeReadings; readingCount++) {
				if (m_pPipe[pipeIndex] > m_maxValue) {
					m_maxValue = m_pPipe[pipeIndex];
					if (readingCount < m_pipeReadings - 1) {
						m_maxTick = m_pipeTick - (m_pipeReadings - (readingCount + 1));
					} else {
						m_maxTick = m_pipeTick - m_pipeReadings;
					}
				}
				pipeIndex++;
				if (pipeIndex >= m_pipeMaxSize) {
					pipeIndex = 0;
				}
			}
		}
		// Was the reading removed previously the Min Value
		if (readingRemoved <= m_minValue) {
			m_minValue = reading;	// Reset the Min value for new min check
			// The reading removed was previously a min, find the new min
			pipeIndex = m_pipeOldest;
			for (int readingCount = 0; readingCount < m_pipeReadings; readingCount++) {
				if (m_pPipe[pipeIndex] < m_minValue) {
					m_minValue = m_pPipe[pipeIndex];
					if (readingCount < m_pipeReadings - 1) {
						m_minTick = m_pipeTick - (m_pipeReadings - (readingCount + 1));
					} else {
						m_minTick = m_pipeTick - m_pipeReadings;
					}
				}
				pipeIndex++;
				if (pipeIndex >= m_pipeMaxSize) {
					pipeIndex = 0;
				}
			}
		}
	}
	// The difference between the Max and Min for the Pipe is the Rate of change.	
	// but we also need to identify if it's and incresing or decresing signal
	if (m_minTick > m_maxTick) {
		// minimum level is later then max level, it's a down slope
		rateDiff = m_minValue - m_maxValue;
	} else {
		// minimum level is later then max level, it's an up slope
		rateDiff = m_maxValue - m_minValue;
	}
	m_LastResult = rateDiff;
	return rateDiff;
}

//**********************************************************************
/// Add reading and get a result
///
/// @param[in]	reading - reading to add to pipe
///
/// @return		result as a processed reading
//**********************************************************************
float CPipeProcess::AddReadingAndGetResult(float reading) {
	AddReadingToPipe(reading);
	return GetPipeResult();
}

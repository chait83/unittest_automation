/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Processing
/// @n Filename: PenManager.cpp
/// @n Desc:	 Manage Pens within the recorder system
///				 
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  119  Aristos  1.112.1.3.1.1 9/21/2011 3:15:56 PM  Hemant(HAIL)  
//  Updated watchdog threadinfo call check
//  118  Aristos  1.112.1.3.1.0 9/19/2011 4:51:13 PM  Hemant(HAIL)  
//  Stability recorder source code (JI Release) updated for WatchDog
//  Timer functionality.
//  117  Stability Project 1.112.1.3  7/2/2011 4:59:40 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  116  Stability Project 1.112.1.2  7/1/2011 4:38:37 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
// $
//
// ****************************************************************

#include "FileList.h"
#include "StoragePaths.h"

#include "PenManager.h"
#include "EventManager.h"

#include "TraceDefines.h"
#include "ThreadInfo.h"

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif

CPenManager *CPenManager::m_pPenManInstance = NULL;
QMutex m_CreationMutex;

const USHORT THRESH_MAX = 15;

//The size for 1 sample containing 96 pens is 3840
//We keep provision for 10 such samples for each client hence 3840* 10 = 38400
//This is the size of the queue for 1 client.
const int MAX_REALTIME_VECTOR_SIZE = 38400;

typedef struct {
	USHORT ID;
	float value;
} T_RATE_SORT;
int compare(const void *rate1, const void *rate2) {
	//equal value is 0
	int ret = 0;
	//compare float values
	if (((T_RATE_SORT*) rate1)->value < ((T_RATE_SORT*) rate2)->value) {
		ret = 1;
	} else if (((T_RATE_SORT*) rate1)->value > ((T_RATE_SORT*) rate2)->value) {
		ret = -1;
	}
	return ret; //>0 for 1 less than 2, <0 for 2 less than 1 0 for equal
}

//**********************************************************************
/// CPenManager constructor
///
//**********************************************************************
CPenManager::CPenManager() {
	m_Initialised = FALSE;

	m_bRealTimeData = FALSE;

	// Reset the Available Pen lists
	m_AvailablePens.ResetList();

	// Reset all working lists
	ResetWorkingLists();

	// Initialise PenControl Objects
	for (int penNumber = 0; penNumber < V6_MAX_PENS; penNumber++) {
		m_Pen[penNumber].SetPenInstance(penNumber);		// Set Pen Number - Always zero based.
	}

	m_LogChannelActionPending = FALSE;
	m_ReportResetRequest = FALSE;
	m_bIsFree = FALSE;
	m_LogRateControl = NULL;
	memset(m_bIsUpdate, 0, sizeof(m_bIsUpdate));

	QMutex* m_UIActionsCS;
	QMutex* m_LoggingCS;
	QMutex* m_RTDataCS;
	for (int i = 0; i < 5; i++)
		m_hRealTimeDataEvent[i] = CreateEvent(NULL, TRUE, FALSE, NULL);
}

//**********************************************************************
///
/// Instance creation of CPenManager singleton
///
/// @return		pointer to single instance of CPenManager
/// 
//**********************************************************************
CPenManager* CPenManager::GetHandle() {
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;
	if (NULL == m_pPenManInstance) {
		// An instance has yet to be completed
		m_CreationMutex = CreateMutex(NULL,			// No security descriptor
				FALSE,			// Mutex object not owned
				TEXT("PENMANAGER"));	// Object name

		waitSingleObjectResult = m_CreationMutex.tryLock(g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);
		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:
			// Object was signaled
			if (NULL == m_pPenManInstance) {
				m_pPenManInstance = new CPenManager;
			}
			if ( FALSE == m_CreationMutex.unlock()) {
				V6WarningMessageBox(NULL, L"Failed to release PENMANAGER mutex", L"CPenManager Error", MB_OK);
				DebugBreak();
			} // End of IF

			break;

		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
			V6WarningMessageBox(NULL, L"PENMANAGER WaitForSingleObject Error", L"CPenManager Error", MB_OK);
			DebugBreak();
			break;
		}
		// Close the Mutex as no longer required
		//No need to close the mutex in Qt
	}
	return (m_pPenManInstance);
}

//**********************************************************************
///
/// Deletes the instance of the singleton from memory
///
/// @return		Nothing
/// 
//**********************************************************************
void CPenManager::CleanUp() {
	// Cleanup each Pen
	for (int penNumber = 0; penNumber < V6_MAX_PENS; penNumber++) {
		m_Pen[penNumber].CleanUp();
	}

	//deletion of mutex not required
	//deletion of mutex not required
	//deletion of mutex not required

	for (int i = 0; i < 5; i++) {
		CloseHandle(m_hRealTimeDataEvent[i]);
		m_hRealTimeDataEvent[i] = NULL;
	}

	delete m_pPenManInstance;
	m_pPenManInstance = NULL;
}

//**********************************************************************
///
/// Initialise the Pen manager
///
/// @return		TRUE, if successful, FALSE if failed, Do not continue if failed
/// 
//**********************************************************************
T_PENMANAGER_RETURN CPenManager::Initialise() {
	if (m_Initialised == TRUE)
		return PENMANAGER_OK;

	// Setup the non-voaltile region for alarms (alarms use in Pen control init below
	CAlarm::InitialiseAlarmNonVolatile();

	// Get ptr to reports structure in SRAM
	CSRAMManager *pSRAM = CSRAMManager::GetHandle();
	CSRAMRegion *pRegion = NULL;
	CSRAMManager::regionError requestReturn = pSRAM->RequestRegion(REGION_REPORTS, &pRegion);
	if (requestReturn != CSRAMManager::REGION_OKAY) {
		V6CriticalMessageBox(NULL, L"REGION_REPORTS SRAM request failed", L"Pen init repriot SRAM",
				MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST);
		return PENMANAGER_CONFIG_FAILURE;
	}
	m_pNVReportData = reinterpret_cast<T_REPORT_DATA*>(pRegion->GetAddress());

	if (m_pNVReportData->signature != REPORT_SIGNATURE || pSYSTEM_INFO->IsDataResetRequested() == TRUE) {
		// Signature is different or invalid, reset the report
		ResetAllReportData();
	}

	// Check when last rollovers were for reports, and reset if necessary
	if (m_pNVReportData->month != pSYSTIMER->GetProcessMonth()) {
		// Month is different so force hour, day and month change
		m_pNVReportData->hour = -1;
		m_pNVReportData->day = -1;
		m_pNVReportData->month = -1;
	} else if (m_pNVReportData->day != pSYSTIMER->GetProcessDay()) {
		// Day is different so force day and hour change
		m_pNVReportData->hour = -1;
		m_pNVReportData->day = -1;
	}
	// Is weekday different
	float daysOff = pSYSTIMER->GetLastTimeOffInSeconds() / SECONDS_IN_A_DAY;
	int daysleftInWeek = 0;
	if (m_pNVReportData->weekDay <= m_pNVReportData->startWeekDay) {
		daysleftInWeek = m_pNVReportData->startWeekDay - m_pNVReportData->weekDay;
	} else {
		daysleftInWeek = (6 - m_pNVReportData->weekDay) + m_pNVReportData->startWeekDay;
	}
	if (daysOff > daysleftInWeek) {
		m_pNVReportData->hour = -1;
		m_pNVReportData->day = -1;
		m_pNVReportData->weekDay = -1;

	}

	// Initialise each Pen, configuring report NV data area
	for (int penNumber = 0; penNumber < V6_MAX_PENS; penNumber++) {
		m_Pen[penNumber].Initialise(&m_pNVReportData->pen[penNumber]);
	}
	// Generate a list of available Pens
	GenerateAvailablePenList();

	// Get pre trigger NV Status
	m_pNVStatus = pNV_VARS->GetBasicVarNVObject(static_cast<NVVAR_IDENT>(NVV_PRETRIGGER_STATUS));
	// Setup the pre-trigger status working from the NV memory
	SetPreTriggerStatus((T_PRETRIGGER_STAT) m_pNVStatus->GetFromNV()->value.ul);
	// Was the pre-trigger previously in read to export mode, if so
	// the files will be still on internal CF and will get exported with the next export
	if (GetPreTriggerStatus() != PRE_TRIGGER_READY_FOR_EXPORT) {
		// No, any other state is volatile so reset the pre-trigger system
		SetPreTriggerStatus(PRE_TRIGGER_NOT_ACTIVE);
	}

	m_Initialised = TRUE;	// Pen Manager has been initialised
	return PENMANAGER_OK;
}

//**********************************************************************
/// Reset all the report Data
///
/// @return		nothing 
//**********************************************************************
void CPenManager::ResetAllReportData() {
	// Reset complete report structure and reset signature
	memset(m_pNVReportData, 0, sizeof(T_REPORT_DATA));
	m_pNVReportData->signature = REPORT_SIGNATURE;
}

//**********************************************************************
/// Detect hour, day, week and month change
///
/// @return		nothing 
//**********************************************************************
void CPenManager::CheckReportTimers() {
	// Reset the status for this timeslice
	m_IsNewHour = FALSE;
	m_IsNewDay = FALSE;
	m_IsNewWeekDay = FALSE;
	m_IsNewMonth = FALSE;

	// Get the current hour and cvheck if the hour has, changed, if so check all others time spans
	int newHour = pSYSTIMER->GetProcessHour();
	if (newHour != m_pNVReportData->hour) {
		// Hour has changed, indicate so this time slice
		m_IsNewHour = TRUE;
		m_pNVReportData->hour = newHour;
		// Hour has changed, but has the day?
		int newDay = pSYSTIMER->GetProcessDay();
		if (newDay != m_pNVReportData->day) {
			// Yes, day has changed, indicate such and checkl for week and month change
			m_IsNewDay = TRUE;
			m_pNVReportData->day = newDay;

			// Check is a new week has started and it has hit the correct start of week day
			int newWeekDay = pSYSTIMER->GetProcessWeekDay();
			if ((newWeekDay != m_pNVReportData->weekDay) && (newWeekDay == m_pNVReportData->startWeekDay)) {
				// Yes new week has started
				m_IsNewWeekDay = TRUE;
			}

			// update the current week day
			m_pNVReportData->weekDay = newWeekDay;

			// Check if a new month has started
			int newMonth = pSYSTIMER->GetProcessMonth();
			if (newMonth != m_pNVReportData->month) {
				// Yes, new month started
				m_pNVReportData->month = newMonth;
				m_IsNewMonth = TRUE;
			}
		}
	}
}

//**********************************************************************
/// Get a ptr to pen reporting structure
///
/// @param[in]	PenNumber - Pen Number
/// @param[in]	base - Base assumption T_PENBASE, ZERO_BASED = Pen1=0 Pen96=95
///												 ONE_BASED = Pen1=1 Pen96=96
/// @return		ptr to pen reporting structure
/// 
//**********************************************************************
T_PEN_REPORT* CPenManager::GetPenReport(USHORT penNumber, T_PENBASE base) {
	T_PEN_REPORT *pPenReport = NULL;
	penNumber = PEN_TO_ZERO_BASED(penNumber, base);
	if (penNumber < V6_MAX_PENS) {
		pPenReport = &m_pNVReportData->pen[penNumber];
	}
	return pPenReport;
}

//**********************************************************************
/// Get a max value for a report
///
/// @param[in]	PenNumber - Pen Number
/// @param[in]	base - Base assumption T_PENBASE, ZERO_BASED = Pen1=0 Pen96=95
///												 ONE_BASED = Pen1=1 Pen96=96
/// @param[in]	history - T_REPORT_HISTORY of WORKING_REPORT or LAST_REPORT
/// @param[in]	period - T_REPORT_PERIOD of RP_HOUR, RP_DAY, RP_WEEK, RP_MONTH
/// @param[out]	maxTime - reference to maxTime , returns time that max occurred
/// 
/// @return		maximum value as float
/// 
//**********************************************************************
float CPenManager::GetReportMax(USHORT penNumber, T_PENBASE base, T_REPORT_HISTORY history, T_REPORT_PERIOD period,
		LONGLONG &maxTime) {
	float retVal = 0;
	penNumber = PEN_TO_ZERO_BASED(penNumber, base);
	if (penNumber < V6_MAX_PENS) {
		retVal = m_pNVReportData->pen[penNumber].set[history].period[period].maxVal;
		maxTime = m_pNVReportData->pen[penNumber].set[history].period[period].maxTime;
	}
	return retVal;
}

//**********************************************************************
/// Get a min value for a report
///
/// @param[in]	PenNumber - Pen Number
/// @param[in]	base - Base assumption T_PENBASE, ZERO_BASED = Pen1=0 Pen96=95
///												 ONE_BASED = Pen1=1 Pen96=96
/// @param[in]	history - T_REPORT_HISTORY of WORKING_REPORT or LAST_REPORT
/// @param[in]	period - T_REPORT_PERIOD of RP_HOUR, RP_DAY, RP_WEEK, RP_MONTH
/// @param[out]	minTime - reference to minTime , returns time that min occurred
/// 
/// @return		minimum value as float
/// 
//**********************************************************************
float CPenManager::GetReportMin(USHORT penNumber, T_PENBASE base, T_REPORT_HISTORY history, T_REPORT_PERIOD period,
		LONGLONG &minTime) {
	float retVal = 0;
	penNumber = PEN_TO_ZERO_BASED(penNumber, base);
	if (penNumber < V6_MAX_PENS) {
		retVal = m_pNVReportData->pen[penNumber].set[history].period[period].minVal;
		minTime = m_pNVReportData->pen[penNumber].set[history].period[period].minTime;
	}
	return retVal;
}

//**********************************************************************
/// Get a total value for a report
///
/// @param[in]	PenNumber - Pen Number
/// @param[in]	base - Base assumption T_PENBASE, ZERO_BASED = Pen1=0 Pen96=95
///												 ONE_BASED = Pen1=1 Pen96=96
/// @param[in]	history - T_REPORT_HISTORY of WORKING_REPORT or LAST_REPORT
/// @param[in]	period - T_REPORT_PERIOD of RP_HOUR, RP_DAY, RP_WEEK, RP_MONTH
/// 
/// @return		total value as float
/// 
//**********************************************************************
float CPenManager::GetReportTot(USHORT penNumber, T_PENBASE base, T_REPORT_HISTORY history, T_REPORT_PERIOD period) {
	float retVal = 0;
	penNumber = PEN_TO_ZERO_BASED(penNumber, base);
	if (penNumber < V6_MAX_PENS) {
		retVal = m_pNVReportData->pen[penNumber].set[history].period[period].totalVal;
	}
	return retVal;
}

//**********************************************************************
/// Get a Average value for a report
///
/// @param[in]	PenNumber - Pen Number
/// @param[in]	base - Base assumption T_PENBASE, ZERO_BASED = Pen1=0 Pen96=95
///												 ONE_BASED = Pen1=1 Pen96=96
/// @param[in]	history - T_REPORT_HISTORY of WORKING_REPORT or LAST_REPORT
/// @param[in]	period - T_REPORT_PERIOD of RP_HOUR, RP_DAY, RP_WEEK, RP_MONTH
/// 
/// @return		average value as float
/// 
//**********************************************************************
float CPenManager::GetReportAve(USHORT penNumber, T_PENBASE base, T_REPORT_HISTORY history, T_REPORT_PERIOD period) {
	float retVal = 0;
	penNumber = PEN_TO_ZERO_BASED(penNumber, base);
	if (penNumber < V6_MAX_PENS) {
		retVal = m_Pen[penNumber].GetReportAverage(&m_pNVReportData->pen[penNumber].set[history].period[period]);
	}
	return retVal;
}

//**********************************************************************
/// Get a start time for a report
///
/// @param[in]	PenNumber - Pen Number
/// @param[in]	base - Base assumption T_PENBASE, ZERO_BASED = Pen1=0 Pen96=95
///												 ONE_BASED = Pen1=1 Pen96=96
/// @param[in]	history - T_REPORT_HISTORY of WORKING_REPORT or LAST_REPORT
/// @param[in]	period - T_REPORT_PERIOD of RP_HOUR, RP_DAY, RP_WEEK, RP_MONTH
/// 
/// @return		start time as a LONGLONG
/// 
//**********************************************************************
LONGLONG CPenManager::GetReportStartTime(USHORT penNumber, T_PENBASE base, T_REPORT_HISTORY history,
		T_REPORT_PERIOD period) {
	LONGLONG retVal = 0;
	penNumber = PEN_TO_ZERO_BASED(penNumber, base);
	if (penNumber < V6_MAX_PENS) {
		retVal = m_pNVReportData->pen[penNumber].set[history].period[period].startTD;
	}
	return retVal;
}

//**********************************************************************
/// Request a reset for the whole report
/// 
/// @return		nothing
//**********************************************************************
void CPenManager::RequestFullReportReset() {
	m_UIActionsCS.lock();// Protect from setting request from UI when Data processing is running requests
	m_ReportResetRequest = TRUE;
	m_UIActionsCS.lock();
}

//**********************************************************************
///
/// Setup the Available List, derived from the Device capabilities information
///
/// @return		nothing
/// 
//**********************************************************************
void CPenManager::GenerateAvailablePenList() {
	m_AvailablePens.ResetList();

	for (int penNumber = 0; penNumber < V6_MAX_PENS; penNumber++) {
		// If pen is availble then assign the pen index of m_pen to the list
		if ( pSYSTEM_INFO->IsPenAvailable(penNumber, ZERO_BASED) == TRUE) {
			m_AvailablePens.AddPenToList(&m_Pen[penNumber]);
		}
	}
}

//**********************************************************************
///
/// Reset all of the working Lists
///
/// @return		nothing
/// 
//**********************************************************************
void CPenManager::ResetWorkingLists() {
	m_EnabledPens.ResetList();
	m_LoggingPens.ResetList();
	m_AlarmPens.ResetList();
	m_TotalisingPens.ResetList();
	m_EnabledAlarms.ResetList();
	m_DIEnabledAlarms.ResetList();
	m_PreTriggerPens.ResetList();
	m_PreTriggerAlarms.ResetList();

	for (int groupIdent = 0; groupIdent < PEN_GROUP_MAX; groupIdent++) {
		m_GroupPens[groupIdent].ResetList();
	}
}

//**********************************************************************
///
/// Generate working lists, for enabled Pens, Logging Pens, Totalier Pens
/// and enabled alarms
///
/// @return		nothing
/// 
//**********************************************************************
void CPenManager::GenerateWorkingLists() {
	T_PPEN pPenConfig;
	CPenControl *pPenCtl;

	// Reset all working lists
	ResetWorkingLists();

	// Run through all vailable pens and add any enabled to the Enabled pen list
	for (int availPenEntry = 0; availPenEntry < m_AvailablePens.GetNumberOfPens(); availPenEntry++) {
		// Get Pen control of available entry
		pPenCtl = m_AvailablePens.GetEntry(availPenEntry);
		if (pPenCtl != NULL) {
			// If pen control is valid, get ptr to the pen configuration
			pPenConfig = pPenCtl->GetPenConfigPtr();			// Get a ptr to the pen configuration
			if (pPenConfig != NULL) {
				// If the pen is enabled add it to the enabled pen list
				if (pPenConfig->Enabled == TRUE) {
					// Add to enabled Pen list
					m_EnabledPens.AddPenToList(pPenCtl);		// Pen available and enabled

					// If Pen is enabled for logging add to Pen logging list
					if (pPenConfig->PenLog.Enabled == TRUE) {
						m_LoggingPens.AddPenToList(pPenCtl);		// Pen available, enabled & logging
					}
					// If Pen is enabled for totalising add to Pen totalising list
					if ((pPenConfig->Tot.Enabled == TRUE) && ( pSYSTEM_INFO->FWOptionTotalsAvailable() == TRUE)) {
						m_TotalisingPens.AddPenToList(pPenCtl);	// Pen available, enabled & totalising
					}
					// If the pen requires pre-trigger add to list
					if (pPenCtl->m_preTrigger.m_Enabled == TRUE) {
						m_PreTriggerPens.AddPenToList(pPenCtl);
					}

					// For each alarm check if it is enabled and is so add it to alarms enabled list
					BOOL anAlarmIsEnabled = FALSE;
					for (int alarmNumber = 0; alarmNumber < V6_MAX_ALARMS; alarmNumber++) {
						// If alarm is enabled add it to the alarm enabled list
						if (pPenConfig->Alm[alarmNumber].EnableType != ALARM_DISABLED) {
							// Add active alarms
							anAlarmIsEnabled = TRUE;
							m_EnabledAlarms.AddAlarmToList(pPenCtl->GetAlarmPtr(alarmNumber));	// Alarm enabled
							// Add alarms enabled by digital
							if (pPenConfig->Alm[alarmNumber].EnableType == ALARM_ENABLED_BY_DI) {
								m_DIEnabledAlarms.AddAlarmToList(pPenCtl->GetAlarmPtr(alarmNumber));// Alarm enabled by digital
							}
							// Add alarms that will cause pre trigger event, which are any alarms on a pre trigger pen
							if (pPenCtl->m_preTrigger.m_Enabled == TRUE) {
								m_PreTriggerAlarms.AddAlarmToList(pPenCtl->GetAlarmPtr(alarmNumber));
							}
						}
					}
					// Create list of Pens with at least one alarm enabled
					if (anAlarmIsEnabled == TRUE) {
						m_AlarmPens.AddPenToList(pPenCtl);	// Pen available, enabled & has at least 1 enabled alarm
					}

					// Create a list of Pen for each group, PEN_GROUP_ALL conatins all enabled pens
					m_GroupPens[PEN_GROUP_ALL].AddPenToList(pPenCtl);
					// If Groups is an option build the individual groups 
					if ( pSYSTEM_INFO->FWOptionBatchAvailable() == TRUE) {
						if (pPenConfig->GroupNumber > 0 && pPenConfig->GroupNumber < PEN_GROUP_MAX) {
							// pen belongs to a group so add to the relevant Group list
							m_GroupPens[pPenConfig->GroupNumber].AddPenToList(pPenCtl);
						}
					}
				}
			}
		}
	}
}

//**********************************************************************
/// Get a ptr to pen Control
///
/// @param[in]	PenNumber - Pen Number
/// @param[in]	base - Base assumption T_PENBASE, ZERO_BASED = Pen1=0 Pen96=95
///												 ONE_BASED = Pen1=1 Pen96=96
/// @return		ptr to pen control requested, NULL if out of range
/// 
//**********************************************************************
CPenControl* CPenManager::GetPenControl(USHORT penNumber, T_PENBASE base) {
	CPenControl *pPenCtl = NULL;
	penNumber = PEN_TO_ZERO_BASED(penNumber, base);
	if (penNumber < V6_MAX_PENS) {
		pPenCtl = &m_Pen[penNumber];
	}
	return pPenCtl;
}

const int MAX_ITTERATIONS_BEFORE_RELEASING = 100;

//**********************************************************************
/// Implement a configration on all pens
/// this will be performed on startup as well as on every 
/// setup configuration
///
/// @return		T_PENMANAGER_RETURN 
/// 
//**********************************************************************
T_PENMANAGER_RETURN CPenManager::ImplementConfiguration() {
	T_PENMANAGER_RETURN retVal = PENMANAGER_OK;
	// Generate a list of all available Pens
	GenerateAvailablePenList();

	pALARM_OVERVIEW->ResetAlarmOverview();			/// Reset the alarm overview
	//MarkD: first save old relay state
	(reinterpret_cast<CDataItemTypeIO*>(pDIT->GetContainerPtr(DI_IO)))->SetOldOutputCache();// MarkD: Remember original state also

	(reinterpret_cast<CDataItemTypeIO*>(pDIT->GetContainerPtr(DI_IO)))->ClearOutputCache();	// Clear the registers holding no. alarms active on a relay

	// Run through available pen list setting the pen configuration for 
	// all available pens
	CPenControl *pPenCtl;
	for (int listEntry = 0; listEntry < m_AvailablePens.GetNumberOfPens(); listEntry++) {
		pPenCtl = m_AvailablePens.GetEntry(listEntry);
		if (pPenCtl != NULL) {
			if (pPenCtl->SetPenFromConfig() == PEN_CONFIG_FAILED) {
				retVal = PENMANAGER_CONFIG_FAILURE;
				V6CriticalMessageBox(NULL, L"SetPenFromConfig() failed", L"Pen Config Failed",
						MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST);
				break;
			}
		}
	}

	// Once all Pens have their configuration, generate a series of working lists
	// to enable fast processing without multiple tests, lists for fast lookup are
	// Enabled pens, Logging Pens, Totalising Pens, Enabled Alarms and Digital Enabled Alarms
	GenerateWorkingLists();

	//Setup pre-trigger status
	if (m_PreTriggerPens.GetNumberOfPens() > 0) {
		// If we still have files to export, do not set state back to running
		if (GetPreTriggerStatus() != PRE_TRIGGER_READY_FOR_EXPORT) {
			// Pre trigger pens exist, allow the trigger to run.
			SetPreTriggerStatus(PRE_TRIGGER_RUNNING);
		}
	} else {
		// No pre-trigger pens configured, do not activate
		SetPreTriggerStatus(PRE_TRIGGER_NOT_ACTIVE);
	}
	m_totalPreTriggerAlarmsActive = 0;	// cleardown the number of active alarms
	m_preTriggerFirstIn = TRUE;			// Set pre-trigger firstin flag

	// Post trigger configuration items
	m_postTriggerTime = pSYSTEM_INFO->GetProfileConfig()->Logging.PostTriggerTime;
	m_postTriggerTimerActive = FALSE;	// cleardown post trigger flag

	// Derive the fastest Pen rate, this in turn is dependent on otehr data items within it's maths block
	// so there could be a dependency issue requiring multiple itterations.
	// i.e if P1=P2	and P2=A1 then P1 rate will not be complete as P2 dependents have not been derived
	// so two itterations will be required, pPenCtl->DeriveFastestRate returns a status if the rate has 
	// changed since the last itteration. So this will itterate until every call to pPenCtl->DeriveFastestRate
	// returns FALSE.	

	m_fastestPenRate = DEFAULT_PEN_RATE;	// reset the current fastest rate to default
	USHORT penRate = DEFAULT_PEN_RATE;		// Working pen rate
	USHORT deadLockCheck = 0;			// Anti deadlock, should never occur under normal operation, programmer warning
	BOOL keepItterating = FALSE;			// Itteration flag, indicates all dependecies not yet flushed through.

	do {
		keepItterating = FALSE;
		// Run through all enabled pens
		for (int enabledPenEntry = 0; enabledPenEntry < m_EnabledPens.GetNumberOfPens(); enabledPenEntry++) {
			pPenCtl = m_EnabledPens.GetEntry(enabledPenEntry);
			if (pPenCtl != NULL) {
				// Check if Pen is running, although enabled may not be running due to incorrect config like maths block failed)
				if (pPenCtl->IsPenRunning()) {
					if (pPenCtl->DeriveFastestRate(penRate) == TRUE) {
						// On this itteration the value changed, so cannot gauruntee all dependencies have been flushed through
						keepItterating = TRUE;
					}
					// Check if this is the fastest rate so far.
					if (penRate < m_fastestPenRate) {
						m_fastestPenRate = penRate;		// Fastest rate so far, set as benchmark
					}
				}
			}
		}
	} while (keepItterating == TRUE && deadLockCheck++ < MAX_ITTERATIONS_BEFORE_RELEASING);

	// Warn if deadlock had to be broken
	if (deadLockCheck >= MAX_ITTERATIONS_BEFORE_RELEASING) {
		LOG_CRTL( TRACE_ALWAYS, "PenManager: ImplementConfiguration: deadlock found when deriving fastest pen rates");
	}

	// Set the process Interval to the fastest rate available
	if (m_fastestPenRate < FASTEST_TICK_RATE || m_fastestPenRate > SLOWEST_TICK_RATE) {
		m_fastestPenRate = SLOWEST_TICK_RATE;
		LOG_CRTL( TRACE_ALWAYS, "PenManager: ImplementConfiguration: Invalid Process rate %d ", m_fastestPenRate);
	}

	// Set the process interval
	pSYSTIMER->SetProcessInterval(m_fastestPenRate);
	//qDebug("Process Interval = %d ticks per second \n", m_fastestPenRate );

	// Run through all pens and set their process rates from itterative process above, also configure
	// their logging now all rates have been derived
	for (int enabledPenEntry = 0; enabledPenEntry < m_EnabledPens.GetNumberOfPens(); enabledPenEntry++) {
		pPenCtl = m_EnabledPens.GetEntry(enabledPenEntry);
		if (pPenCtl != NULL) {
			// Check if Pen is running, although enabled may not be running due to incorrect config like maths block failed)
			if (pPenCtl->IsPenRunning()) {
				pPenCtl->SetPenProcessRates();
				pPenCtl->ConfigureLoggingForPen();
			}
		}
	}
	//set all the pens queues to an appropriate length
	T_PRECPROFILE ptProfile = pSETUP->GetGeneralSetupConfig()->GetProfileBlock(CONFIG_COMMITTED);
	if (ptProfile->Logging.Bias >= 100) {
		CalculateQueueMaxVals(ptProfile->Logging.Bias - 100, BIAS_CHART);
	} else {
		CalculateQueueMaxVals(100 - ptProfile->Logging.Bias, BIAS_LOG);
	}

#if 1
	static BOOL bFirstCall = TRUE;

	// if this a first run after a software upgrade, don't restore the NV state
	if ( TRUE == bFirstCall &&
	TRUE == pGlbSysInfo->IsFirmwareUpgraded()) {
		bFirstCall = FALSE;
	}

	if ( TRUE == bFirstCall) {
		bFirstCall = FALSE;
		RestoreLogging(PEN_GROUP_ALL);
	} else {
		StartLogging(PEN_GROUP_ALL);
	}
#else
	StartLogging( PEN_GROUP_ALL );
#endif
	return retVal;
}

//**********************************************************************
///
/// Process pens
///
/// @return		T_PENMANAGER_RETURN 
/// 
//**********************************************************************
T_PENMANAGER_RETURN CPenManager::ProcessPens() {
	T_PENMANAGER_RETURN retVal = PENMANAGER_OK;
	CPenControl *pPenCtl;

	m_UIActionsCS.lock();// Protect from setting request from UI when Data processing is running requests

	CheckReportTimers();

	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();

	// Run through enabled pen list performing a process on all available enabled pens
	for (int enabledPenEntry = 0; enabledPenEntry < m_EnabledPens.GetNumberOfPens(); enabledPenEntry++) {
		pPenCtl = m_EnabledPens.GetEntry(enabledPenEntry);
		if (pPenCtl != NULL) {
			// Check if Pen is running, although enabled may not be running due to incorrect config like maths block failed)
			if (pPenCtl->IsPenRunning()) {
				// Process the maths script or use direct variable for a Pen also process the totaliser if enabled
				pPenCtl->ProcessPenMaths();
			}
		}

		if (pThreadInfo != NULL) {
			//Update the Thread Counter for the DataProcessing
			//thread after each iteration
			pThreadInfo->UpdateThreadCounter(AM_DATA_PROCESSING);
		}
	}

	m_ReportResetRequest = FALSE;

	// Process the protrigger
	// Is pre-trigger axctive and this is not the first pass?
	if (GetPreTriggerStatus() != PRE_TRIGGER_NOT_ACTIVE && m_preTriggerFirstIn != TRUE) {
		// Yes, process the pre trigger dependig on state
		switch (GetPreTriggerStatus()) {
		// The pre-trigger running, this is where no pre-trigger alarms are active and 
		// the pre-trigger buffer is being filled
		case PRE_TRIGGER_RUNNING: {
			// Run through pre triggers pens performing a process on all available enabled pens
			for (int PreTriggerPenEntry = 0; PreTriggerPenEntry < m_PreTriggerPens.GetNumberOfPens();
					PreTriggerPenEntry++) {
				pPenCtl = m_PreTriggerPens.GetEntry(PreTriggerPenEntry);
				if (pPenCtl != NULL) {
					// Add another reading to the pre trigger buffer
					pPenCtl->ProcessPreTrigger();
				}
				if (pThreadInfo != NULL) {
					//Update the Thread Counter for the DataProcessing
					//thread after each iteration
					pThreadInfo->UpdateThreadCounter(AM_DATA_PROCESSING);
				}
			}
			break;
		}
			// The pre-trigger system is ready for restart, all previous pre-trigger data has been exported
			// and there are no current pre-trigger alarms so pre-triggering can restart
		case PRE_TRIGGER_RESTART: {
			// Run through pre triggers pens performing a process on all available enabled pens
			for (int PreTriggerPenEntry = 0; PreTriggerPenEntry < m_PreTriggerPens.GetNumberOfPens();
					PreTriggerPenEntry++) {
				pPenCtl = m_PreTriggerPens.GetEntry(PreTriggerPenEntry);
				if (pPenCtl != NULL) {
					// Restart the pre trigger buffer and add first entry
					pPenCtl->ResetPreTrigger();
					pPenCtl->ProcessPreTrigger();
				}
				if (pThreadInfo != NULL) {
					//Update the Thread Counter for the DataProcessing
					//thread after each iteration
					pThreadInfo->UpdateThreadCounter(AM_DATA_PROCESSING);
				}
			}
			SetPreTriggerStatus(PRE_TRIGGER_RUNNING);
			break;
		}
		}
	}

	m_UIActionsCS.lock();

	return retVal;
}

//**********************************************************************
///
/// Process chart queues for pens
///
/// @return		T_PENMANAGER_RETURN 
/// 
//**********************************************************************
T_PENMANAGER_RETURN CPenManager::ProcessTotals() {
	T_PENMANAGER_RETURN retVal = PENMANAGER_OK;
	CPenControl *pPenCtl;

	m_UIActionsCS.lock();// Protect from setting request from UI when Data processing is running requests

	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();

	// Run through enabled pen list performing a process on all available enabled pens
	for (int enabledTotalEntry = 0; enabledTotalEntry < m_TotalisingPens.GetNumberOfPens(); enabledTotalEntry++) {
		pPenCtl = m_TotalisingPens.GetEntry(enabledTotalEntry);
		if (pPenCtl != NULL) {
			// Check if Pen is running, although enabled may not be running due to incorrect config like maths block failed)
			if (pPenCtl->IsPenRunning()) {
				// Add this pen to the chart queue
				pPenCtl->ProcessTotaliser();
			}
		}
		if (pThreadInfo != NULL) {
			//Update the Thread Counter for the DataProcessing
			//thread after each iteration
			pThreadInfo->UpdateThreadCounter(AM_DATA_PROCESSING);
		}
	}
	m_UIActionsCS.lock();

	// Run though all modes (0 not a mode that needs registereing) see if there are any triggers, if so
	// send to the event system
	for (int modeIndex = 1; modeIndex < TOTAL_MAX_MODES; modeIndex++) {
		if (CEventManager::AreAnyBitsSet(&CTotal::actionMask[modeIndex]) == TRUE) {
			// Actions have been perfomed for this mode, send to event system and cleardown
			pGlbEventManager->TotaliserActionCause(modeIndex, &CTotal::actionMask[modeIndex]);
			CEventManager::ClearMask(&CTotal::actionMask[modeIndex]);
		}
		if (pThreadInfo != NULL) {
			//Update the Thread Counter for the DataProcessing
			//thread after each iteration
			pThreadInfo->UpdateThreadCounter(AM_DATA_PROCESSING);
		}
	}

	return retVal;
}

//**********************************************************************
///
/// Process chart queues for pens
///
/// @return		T_PENMANAGER_RETURN 
/// 
//**********************************************************************
T_PENMANAGER_RETURN CPenManager::ProcessPenChartQueues() {
	T_PENMANAGER_RETURN retVal = PENMANAGER_OK;
	CPenControl *pPenCtl;
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();

	// here obtain the mutex for the ChartQ manager (better to do it here once, rather than for each pen in ProcessPenChartQueues())
	CChartQManager *CM = CChartQManager::GetHandle();
	CM->WaitLock(2);

	// Run through enabled pen list performing a process on all available enabled pens
	for (int enabledPenEntry = 0; enabledPenEntry < m_EnabledPens.GetNumberOfPens(); enabledPenEntry++) {
		pPenCtl = m_EnabledPens.GetEntry(enabledPenEntry);
		if (pPenCtl != NULL) {
			// Check if Pen is running, although enabled may not be running due to incorrect config like maths block failed)
			if (pPenCtl->IsPenRunning()) {
				// Add this pen to the chart queue
				pPenCtl->ProcessPenChartQueues();
			}
		}

		if (pThreadInfo != NULL) {
			//Update the Thread Counter for the DataProcessing
			//thread after each iteration
			pThreadInfo->UpdateThreadCounter(AM_DATA_PROCESSING);
		}
	}
	CM->Unlock(); // release it

	return retVal;
}

//**********************************************************************
///
/// Process all alarm in enabled alarms list
///
/// @return		T_PENMANAGER_RETURN 
/// 
//**********************************************************************
T_PENMANAGER_RETURN CPenManager::ProcessAlarms() {
	T_PENMANAGER_RETURN retVal = PENMANAGER_OK;
	CAlarm *pAlarm = NULL;			// Handle on Alarm instance
	CPenControl *pPenCtl = NULL;	// Handle on Pen control instance
	int alarmedPenEntry = 0;		// Instance number of Pen with alarms in list

	m_UIActionsCS.lock();// Protect from setting request from UI when Data processing is running requests

	// Reset all the Pen alarm overview status in the Data Item table, these can then be set
	// by the relevant alarms
	for (alarmedPenEntry = 0; alarmedPenEntry < m_AlarmPens.GetNumberOfPens(); alarmedPenEntry++) {
		// Clear the alarm status in the Pen Data Item Table
		pPenCtl = m_AlarmPens.GetEntry(alarmedPenEntry);
		pPenCtl->ClearAlarmStatus();
		pPenCtl->GetLoggingPtr()->ClearAlarmLogRateRequired();		// Clear down the requirement for a rate change
	}

	// Run through enabled alarm list and process the alarm if active
	for (int alarmEntry = 0; alarmEntry < m_EnabledAlarms.GetNumberOfAlarms(); alarmEntry++) {
		// Get the address of thre alarm object to process
		pAlarm = m_EnabledAlarms.GetEntry(alarmEntry);
		// If the alarm is active then process the alarm

		pAlarm->ProcessAlarm();				// Process the Alarm
		if (pAlarm->IsActive()) {
			pAlarm->UpdateCommonPenAlarm();	// Update the Pen Data Item Alarm status overview and possible rate change
		}
	}

	/// Process the pre-trigger alarms
	if (GetPreTriggerStatus() > PRE_TRIGGER_NOT_ACTIVE) {
		int m_previousAlarmsActive = m_totalPreTriggerAlarmsActive;
		m_totalPreTriggerAlarmsActive = 0;
		// Run through the pre-triggered alarms and 
		for (int alarmEntry = 0; alarmEntry < m_PreTriggerAlarms.GetNumberOfAlarms(); alarmEntry++) {
			// Get the address of thre alarm object to process
			pAlarm = m_PreTriggerAlarms.GetEntry(alarmEntry);
			// If the alarm is active then process the alarm

			if (pAlarm->IsActive() && pAlarm->InAlarm()) {
				// Alarm is Active AND in Alarm
				m_totalPreTriggerAlarmsActive++;	// Register a pre-trigger alarm is active and in alarm.
			}
		}
		// Are there pre-trigger alarms active
		if (m_totalPreTriggerAlarmsActive > 0) {
			if (m_preTriggerFirstIn == TRUE && GetPreTriggerStatus() != PRE_TRIGGER_READY_FOR_EXPORT) {
				// Set the pre-trigger pens to be ready for a start when
				// alarms fall out, cannot use pre-trigger when alarm on startup or immediatly after config change
				SetPreTriggerStatus(PRE_TRIGGER_READY_FOR_RESTART);
			}
			// Yes, Is this the initial trigger
			if (GetPreTriggerStatus() == PRE_TRIGGER_RUNNING) {
				// Yes, set pre trigger ready for processing
				SetPreTriggerStatus(PRE_TRIGGER_READY_FOR_PROCESSING);	// Start processing the pre-trigger
			}

			// Keep log rate in alarm for all pre trigger pens when any pre trigger pen has an alarm rate
			for (int PreTriggerPenEntry = 0; PreTriggerPenEntry < m_PreTriggerPens.GetNumberOfPens();
					PreTriggerPenEntry++) {
				pPenCtl = m_PreTriggerPens.GetEntry(PreTriggerPenEntry);
				if (pPenCtl != NULL) {
					// Trigger the alarm rate for all Pens that require pre trigger
					pPenCtl->GetLoggingPtr()->RegisterAlarmLogRateRequired();
				}
			}

			// Cleardown the post trigger as alarms still active 
			m_postTriggerTimerActive = FALSE;
		}
		// if the pre-trigger system has finished and the alarm state is removed, restart the pre-trigger buffer 
		else if (m_totalPreTriggerAlarmsActive == 0) {
			BOOL ReadyToStopAlarmRate = FALSE;// Flag to indicate we need to stop the alarm log rate on pre-trigger pens

			// Have all pre-trigger alarm dropped out?
			if (m_previousAlarmsActive > 0) {
				// Is there a post trigger to delay the alarm rate?
				if (m_postTriggerTime > 0) {
					// Yes, set the post trigger timers
					m_postTriggerTimerActive = TRUE;
					m_postTriggerEndTime =
					pSYSTIMER->GetCurrentProcessTimeInMicroSec() + SEC_TO_USEC((LONGLONG )m_postTriggerTime);
				} else {
					// There is no post trigger timer and the pre-trigger alarms are now all out of alarm
					// so we can switch off the 
					ReadyToStopAlarmRate = TRUE;
				}
			} else if (m_postTriggerTimerActive == TRUE) {
				// Override the alarm rate for all pre-trigger pens as post trigger is still running
				for (int PreTriggerPenEntry = 0; PreTriggerPenEntry < m_PreTriggerPens.GetNumberOfPens();
						PreTriggerPenEntry++) {
					pPenCtl = m_PreTriggerPens.GetEntry(PreTriggerPenEntry);
					if (pPenCtl != NULL) {
						// Set the alarm rate for all Pens that require pre trigger
						pPenCtl->GetLoggingPtr()->RegisterAlarmLogRateRequired();
					}
				}
				if ( pSYSTIMER->GetCurrentProcessTimeInMicroSec() >= m_postTriggerEndTime) {
					ReadyToStopAlarmRate = TRUE;
					m_postTriggerTimerActive = FALSE;
				}
			}

			if (ReadyToStopAlarmRate == TRUE) {
				// Switch off fast log rate for all pre-trigger pens
				for (int PreTriggerPenEntry = 0; PreTriggerPenEntry < m_PreTriggerPens.GetNumberOfPens();
						PreTriggerPenEntry++) {
					pPenCtl = m_PreTriggerPens.GetEntry(PreTriggerPenEntry);
					if (pPenCtl != NULL) {
						// Clear the alarm rate for all Pens that require pre trigger
						pPenCtl->GetLoggingPtr()->ClearAlarmLogRateRequired();
					}
				}
			}

			if (GetPreTriggerStatus() == PRE_TRIGGER_READY_FOR_RESTART) {
				// Only restart the pre-trigger when the trigger is ready for reset and ALL pre trigger pens are out of alarm
				SetPreTriggerStatus(PRE_TRIGGER_RESTART);
			}
		}
		m_preTriggerFirstIn = FALSE;	// Alarms have been processed so remove pre-trigger dependencies
	}
	m_UIActionsCS.lock();

	return retVal;
}

//**********************************************************************
/// Alarm Acknowledge for All, groups or individual
///
/// @param[in] - reqType,	REQ_ALARM_ACKNOWLEDGE to acknowledge these alarm or 
///							REQ_ALARM_RESET to reset these alarms							
/// @param[in]	group - Group identifier of T_PEN_GROUPS, NO_GROUP_SINGLE_PEN for single Pen or PEN_GROUP_MAX for all.
/// @param[in]	penNumber - Zero based number of Pen of total to perform action on
/// @param[in]	alarmNumber - alarm number for acknowledge or ACK_ALL_ALARMS for all
///
/// @return		T_PENMANAGER_RETURN 
//**********************************************************************
T_PENMANAGER_RETURN CPenManager::AcknowledgeOrResetAlarm(T_ALARM_REQUEST reqType, T_PEN_GROUPS Group, USHORT penNumber,
		USHORT alarmNumber) {
	CPenControl *pPenCtl = NULL;		// Pen control

	m_UIActionsCS.lock();// Protect from setting request from UI when Data processing is running requests

	// Is this a single pen or a group (including all)
	if (Group == NO_GROUP_SINGLE_PEN) {
		// Single pen so also might be an individual alarm too
		CPenControl *pPenCtl = GetPenControl(penNumber, ZERO_BASED);
		if (pPenCtl != NULL) {
			pPenCtl->AcknowledgeOrResetAlarm(alarmNumber, reqType);
		}
	} else if (Group < PEN_GROUP_MAX) {
		// Its a group ALL or 1 to 6, use direct access
		// Run through all pens that we want to ack their alarms
		for (int penToAckEntry = 0; penToAckEntry < m_GroupPens[Group].GetNumberOfPens(); penToAckEntry++) {
			pPenCtl = m_GroupPens[Group].GetEntry(penToAckEntry);
			pPenCtl->AcknowledgeOrResetAlarm(ACK_ALL_ALARMS, reqType);
		}
	}
	m_UIActionsCS.lock();

	return PENMANAGER_OK;
}

//**********************************************************************
/// Alarm Acknowledge for All, groups or individual
///
/// @param[in]	group - Group identifier of T_PEN_GROUPS, NO_GROUP_SINGLE_PEN for single Pen or PEN_GROUP_MAX for all.
/// @param[in]	penNumber - Zero based number of Pen of total to perform action on
/// @param[in]	alarmNumber - alarm number for acknowledge or ACK_ALL_ALARMS for all
///
/// @return		T_PENMANAGER_RETURN 
//**********************************************************************
T_PENMANAGER_RETURN CPenManager::AcknowledgeAlarm(T_PEN_GROUPS Group, USHORT penNumber, USHORT alarmNumber) {
	AcknowledgeOrResetAlarm(REQ_ALARM_ACKNOWLEDGE, Group, penNumber, alarmNumber);
	return PENMANAGER_OK;
}

//**********************************************************************
/// Alarm Reset for All, groups or individual
///
/// @param[in]	group - Group identifier of T_PEN_GROUPS, NO_GROUP_SINGLE_PEN for single Pen or PEN_GROUP_MAX for all.
/// @param[in]	penNumber - Zero based number of Pen of total to perform action on
/// @param[in]	alarmNumber - alarm number for acknowledge or ACK_ALL_ALARMS for all
///
/// @return		T_PENMANAGER_RETURN 
//**********************************************************************
T_PENMANAGER_RETURN CPenManager::ResetAlarm(T_PEN_GROUPS Group, USHORT penNumber, USHORT alarmNumber) {
	AcknowledgeOrResetAlarm(REQ_ALARM_RESET, Group, penNumber, alarmNumber);
	return PENMANAGER_OK;
}

//**********************************************************************
/// Update Alarm user level and register in message list
///
/// @param[in]	penNumber - Zero based number of Pen of total to perform action on
/// @param[in]	alarmNumber - Zero Based alarm number
/// @param[in]	newLevel - engineering value of new level to set alarm to
///
/// @return		T_PENMANAGER_RETURN 
//**********************************************************************
T_PENMANAGER_RETURN CPenManager::PerformAlarmLevelUpdate(USHORT penNumber, USHORT alarmNumber, float newLevel) {
	CPenControl *pPenCtl = GetPenControl(penNumber, ZERO_BASED);
	if (pPenCtl != NULL) {
		// If pen is valid, and the alarm is within range - Update the user level
		if (alarmNumber < V6_MAX_ALARMS) {
			m_UIActionsCS.lock();

			// Post message to user message list to indicate a user has chnaged the alarm level
			QString   alarmLevelChangeasprintf;
			alarmLevelChangeasprintf = tr("P%d Alm %d level change from %f to %f");

			QString   alarmLevelChangeMessage;
			alarmLevelChangeMessage.asprintf(alarmLevelChangeasprintf, penNumber + 1, alarmNumber + 1,
					pPenCtl->GetAlarmPtr(alarmNumber)->GetUserLevel(), newLevel);

			pPenCtl->GetAlarmPtr(alarmNumber)->UpdateUserLevel(newLevel);
			LOG_USER_MESSAGE(MSGLISTSER_USER_GROUP_ALARM_CHANGE, alarmLevelChangeMessage);

			m_UIActionsCS.lock();
		}
	}
	return PENMANAGER_OK;
}

//**********************************************************************
/// Update Alarm user level and DO NOT register in message list
///
/// @param[in]	penNumber - Zero based number of Pen of total to perform action on
/// @param[in]	alarmNumber - Zero Based alarm number
/// @param[in]	newLevel - engineering value of new level to set alarm to
///
/// @return		T_PENMANAGER_RETURN 
//**********************************************************************
T_PENMANAGER_RETURN CPenManager::PerformAlarmLevelUpdateSilent(USHORT penNumber, USHORT alarmNumber, float newLevel) {
	CPenControl *pPenCtl = GetPenControl(penNumber, ZERO_BASED);
	if (pPenCtl != NULL) {
		// If pen is valid, and the alarm is within range - Update the user level
		if (alarmNumber < V6_MAX_ALARMS) {
			pPenCtl->GetAlarmPtr(alarmNumber)->UpdateUserLevel(newLevel);
		}
	}
	return PENMANAGER_OK;
}

//**********************************************************************
/// Stop/Start or reset totlaisers for All pens, group or pens or individual
///
/// @param[in]	group - Group identifier of T_PEN_GROUPS, NO_GROUP_SINGLE_PEN for single Pen or PEN_GROUP_MAX for all.
/// @param[in]	penNumber - Zero based number of Pen of total to perform action on
/// @param[in]	maxminAction - Type of action, stop, start or reset. type T_TOTAL_MODE

/// @return		T_PENMANAGER_RETURN 
//**********************************************************************
T_PENMANAGER_RETURN CPenManager::PerformTotaliserAction(T_PEN_GROUPS Group, USHORT penNumber,
		T_TOTAL_MODE totalAction) {
	CPenControl *pPenCtl = NULL;		// Pen control

	m_UIActionsCS.lock();// Protect from setting request from UI when Data processing is running requests

	// Is this a single pen or a group (including all)
	if (Group == NO_GROUP_SINGLE_PEN) {
		// Single pen so set action directly
		CPenControl *pPenCtl = GetPenControl(penNumber, ZERO_BASED);
		if (pPenCtl != NULL) {
			pPenCtl->RequestTotaliserAction(totalAction);
		}
	} else if (Group < PEN_GROUP_MAX) {
		// Its a group ALL or 1 to 6, use direct access
		// Run through all pens that we want to set total action
		for (int penTotalToSetEntry = 0; penTotalToSetEntry < m_GroupPens[Group].GetNumberOfPens();
				penTotalToSetEntry++) {
			pPenCtl = m_GroupPens[Group].GetEntry(penTotalToSetEntry);
			pPenCtl->RequestTotaliserAction(totalAction);
		}
	}
	m_UIActionsCS.lock();

	return PENMANAGER_OK;
}

//**********************************************************************
/// Pereform Max Min Resets, Allow a MAX reset, MIN reset or Reset of Both
///
/// @param[in]	group - Group identifier of T_PEN_GROUPS, NO_GROUP_SINGLE_PEN for single Pen or PEN_GROUP_MAX for all.
/// @param[in]	penNumber - Zero based number of Pen to reset
/// @param[in]	maxminAction - Type of reset, max, min or both type T_MAXMIN_MODE
/// @param[in]	IsManual - TRUE if reset type manual, FALSE if reset by Event
///
/// @return		T_PENMANAGER_RETURN 
//**********************************************************************
T_PENMANAGER_RETURN CPenManager::PerformMaxMinResetAction(T_PEN_GROUPS Group, USHORT penNumber,
		T_MAXMIN_MODE maxminAction, BOOL IsManual) {
	CPenControl *pPenCtl = NULL;		// Pen control

	m_UIActionsCS.lock();// Protect from setting request from UI when data processing is running requests

	// Is this a single pen or a group (including all)
	if (Group == NO_GROUP_SINGLE_PEN) {
		// Single pen so set action directly
		CPenControl *pPenCtl = GetPenControl(penNumber, ZERO_BASED);
		if (pPenCtl != NULL) {
			pPenCtl->RequestMaxMinAction(maxminAction);
			if (IsManual == TRUE) {
				pEVENTS->MaxMinResetCause(penNumber);
				QString   strMsg("");
				QString   strMaxMinAction("");

				switch (maxminAction) {
				case MM_MODE_RESET_MAX: {
					strMaxMinAction = tr("Reset Max");
				}
					break;
				case MM_MODE_RESET_MIN: {
					strMaxMinAction = tr("Reset Min");
				}
					break;
				case MM_MODE_RESET_BOTH: {
					strMaxMinAction = tr("Reset Max/Min");
				}
					break;
				case MM_MODE_NORMAL:
				default:
					// error condition
					strMaxMinAction = L"ERROR";
					break;
				}

				strMsg.asprintf(IDS_MAX_MIN_MESSAGE_RESET, pPenCtl->GetPenInstance() + 1, pPenCtl->GetPenConfigPtr()->Tag,
						strMaxMinAction);
				pMSG_SERVICES->LogUserMessageList(MSGLISTSER_USER_GROUP_MAX_MIN_RESET, strMsg);
			}
		}
	} else if (Group < PEN_GROUP_MAX) {
		// Its a group ALL or 1 to 6, use direct access
		// Run through all pens that we want to set max min reset
		for (int penMMToSetEntry = 0; penMMToSetEntry < m_GroupPens[Group].GetNumberOfPens(); penMMToSetEntry++) {
			pPenCtl = m_GroupPens[Group].GetEntry(penMMToSetEntry);
			pPenCtl->RequestMaxMinAction(maxminAction);
			if (IsManual == TRUE) {
				pEVENTS->MaxMinResetCause(penMMToSetEntry);
				QString   strMsg("");

				QString   strMaxMinAction("");

				switch (maxminAction) {
				case MM_MODE_RESET_MAX: {
					strMaxMinAction = tr("Reset Max");
				}
					break;
				case MM_MODE_RESET_MIN: {
					strMaxMinAction = tr("Reset Min");
				}
					break;
				case MM_MODE_RESET_BOTH: {
					strMaxMinAction = tr("Reset Max/Min");
				}
					break;
				case MM_MODE_NORMAL:
				default:
					// error condition
					strMaxMinAction = L"ERROR";
					break;
				}

				strMsg.asprintf(IDS_MAX_MIN_MESSAGE_RESET, pPenCtl->GetPenInstance() + 1, pPenCtl->GetPenConfigPtr()->Tag,
						strMaxMinAction);
				pMSG_SERVICES->LogUserMessageList(MSGLISTSER_USER_GROUP_MAX_MIN_RESET, strMsg);
			}
		}
	}
	m_UIActionsCS.lock();

	return PENMANAGER_OK;
}

//**********************************************************************
///
/// Process logging pen list
///
/// @return		T_PENMANAGER_RETURN 
/// 
//**********************************************************************
T_PENMANAGER_RETURN CPenManager::ProcessLogging() {
	T_PENMANAGER_RETURN retVal = PENMANAGER_OK;
	CPenControl *pPenCtl;
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();

	m_LoggingCS.lock();	// Protect from setting request from UI when data processing is running requests

	// Run through enabled pen list performing a process on all available enabled pens
	for (int loggedPenEntry = 0; loggedPenEntry < m_LoggingPens.GetNumberOfPens(); loggedPenEntry++) {
		pPenCtl = m_LoggingPens.GetEntry(loggedPenEntry);
		if (pPenCtl != NULL) {
			// Check if Pen is running, although enabled may not be running due to incorrect config like maths block failed)
			if (pPenCtl->IsPenRunning()) {
				// Process the pen log
				pPenCtl->ProcessPenLog();
			}
		}

		if (pThreadInfo != NULL) {
			//Update the Thread Counter for the DataProcessing
			//thread 
			pThreadInfo->UpdateThreadCounter(AM_DATA_PROCESSING);
		}
	}

	m_LogChannelActionPending = FALSE;

	m_LoggingCS.lock();

	return retVal;
}

//**********************************************************************
/// Check if a group contains any pens
/// 
/// @param[in]	group - Group identifier of T_PEN_GROUPS
///
/// @return		TRUE if group contains any pens, else FALSE
//**********************************************************************
BOOL CPenManager::IsGroupUsed(T_PEN_GROUPS group) {
	BOOL bResult = FALSE;

	if ( pSYSTEM_INFO->FWOptionBatchAvailable() == TRUE)
		if (m_GroupPens[group].GetNumberOfPens() > 0)
			bResult = TRUE;

	return bResult;
}

//**********************************************************************
/// 
/// Check if a pen is part of a group
/// @param[in]	group - Group identifier of T_PEN_GROUPS
/// @param[in]	queryPenNo - Pen number to test for
///
/// @return		TRUE if group contains any pens, else FALSE
//**********************************************************************
BOOL CPenManager::IsPenInGroup(const T_PEN_GROUPS group, const USHORT queryPenNo) {
	USHORT penNo = 0;
	BOOL bResult = FALSE;

	if ((group >= PEN_GROUP_1) && (group <= PEN_GROUP_6) && IsGroupUsed(group)) {
		// group is in use. (i.e. there are some pens for it!)

		USHORT pensInGroup = GetGroupList(group)->GetNumberOfPens();

		for (penNo = 0; penNo < pensInGroup; penNo++) {
			if (queryPenNo == GetGroupList((group))->GetEntry(penNo)->GetPenInstance()) {
				bResult = TRUE;
				break;
			}
		}
	}

	return bResult;
}

//**********************************************************************
/// Retreive the group name for associated group
/// 
/// @param[in]	group - Group identifier of T_PEN_GROUPS for PEN_GROUP_1 to PEN_GROUP_6 only
///
/// @return		pointer to group name 1 to 6, or NULL if does not exist
//**********************************************************************
WCHAR* CPenManager::GetGroupName(T_PEN_GROUPS group) {
	QString pGroupName = NULL;
	if ((group >= PEN_GROUP_1) && (group <= PEN_GROUP_6)) {
		pGroupName = pSYSTEM_INFO->GetGeneralConfig()->GroupName[group - 1];
	}
	return pGroupName;
}

//**********************************************************************
/// Retreive the group list for a specified group
/// 
/// @param[in]	group - Group identifier of T_PEN_GROUPS
///
/// @return		pointer to group list or NULL if does not exist
//**********************************************************************
CPenList* CPenManager::GetGroupList(T_PEN_GROUPS group) {
	CPenList *pGroupList = NULL;
	if ((group >= PEN_GROUP_ALL) && (group <= PEN_GROUP_6)) {
		pGroupList = &m_GroupPens[group];
	}
	return pGroupList;
}

//**********************************************************************
/// Restore logging state for a group/all pens
/// 
/// @param[in]	group - Group identifier of T_PEN_GROUPS
///
/// @return		T_PENMANAGER_RETURN 
//**********************************************************************
T_PENMANAGER_RETURN CPenManager::RestoreLogging(T_PEN_GROUPS group) {
	CPenControl *pPenCtl;

	m_LoggingCS.lock();	// Protect from setting request from UI when data processing is running requests

	m_LogChannelActionPending = TRUE;

	// Run through enabled pen list performing a process on all available enabled pens
	for (int loggedPenEntry = 0; loggedPenEntry < m_GroupPens[group].GetNumberOfPens(); loggedPenEntry++) {
		pPenCtl = m_GroupPens[group].GetEntry(loggedPenEntry);
		if (pPenCtl != NULL) {
			pPenCtl->RequestLoggingMode(LOGGING_MODE_RESTORE);
		}
	}
	m_LoggingCS.lock();

	return PENMANAGER_OK;
}

//**********************************************************************
/// Start logging for a group/all pens
/// 
/// @param[in]	group - Group identifier of T_PEN_GROUPS
///
/// @return		T_PENMANAGER_RETURN 
//**********************************************************************
T_PENMANAGER_RETURN CPenManager::StartLogging(T_PEN_GROUPS group) {
	CPenControl *pPenCtl;

	m_LoggingCS.lock();	// Protect from setting request from UI when data processing is running requests

	m_LogChannelActionPending = TRUE;

	// Run through enabled pen list performing a process on all available enabled pens
	for (int loggedPenEntry = 0; loggedPenEntry < m_GroupPens[group].GetNumberOfPens(); loggedPenEntry++) {
		pPenCtl = m_GroupPens[group].GetEntry(loggedPenEntry);
		if (pPenCtl != NULL) {
			pPenCtl->RequestLoggingMode(LOGGING_MODE_START);
		}
	}
	m_LoggingCS.lock();

	return PENMANAGER_OK;
}

//**********************************************************************
/// Start logging for a single pen
/// 
/// @param[in]	usPEN_INSTANCE - pen instance
///
/// @return		T_PENMANAGER_RETURN 
//**********************************************************************
T_PENMANAGER_RETURN CPenManager::StartPenLogging(const USHORT usPEN_INSTANCE) {
	CPenControl *pkPenCtrl = NULL;

	// Protect from setting request from UI when data processing is running requests
	m_LoggingCS.lock();

	m_LogChannelActionPending = TRUE;

	pkPenCtrl = GetPenControl(usPEN_INSTANCE, ZERO_BASED);
	if (pkPenCtrl != NULL) {
		pkPenCtrl->RequestLoggingMode(LOGGING_MODE_START);
	}

	m_LoggingCS.lock();

	return PENMANAGER_OK;
}

//****************************************************************************
// const bool CPenManager::IsPenLogging( const USHORT usPEN_INSTANCE )
///
/// Method that determines if a particular pen is logging
///
/// @param[in]		const USHORT usPEN_INSTANCE - The pen instance we want to check
///
/// @return			True if the pen has started logging
///
//****************************************************************************
const bool CPenManager::IsPenLogging(const USHORT usPEN_INSTANCE) {
	bool bLogging = false;

	CPenControl *pkPenCtrl = NULL;

	// Protect from setting request from UI when data processing is running requests
	m_LoggingCS.lock();

	pkPenCtrl = GetPenControl(usPEN_INSTANCE, ZERO_BASED);
	if (pkPenCtrl != NULL) {
		// Check if Pen is running, although enabled may not be running due to incorrect config like maths block failed)
		if (pkPenCtrl->IsPenRunning()) {
			bLogging = (pkPenCtrl->m_logChannel.IsLogging() == TRUE)
					|| ((pkPenCtrl->GetPenConfigPtr()->PenLog.Enabled == TRUE)
							&& (pkPenCtrl->GetLoggingMode() == LOGGING_MODE_START));
		}
	}

	m_LoggingCS.lock();

	return bLogging;
}

//****************************************************************************
// const bool CPenManager::IsPenWaitingForAlignment( const USHORT usPEN_INSTANCE )
///
/// Method that determines if a particular pen is (currently) waiting for alignment
///
/// @param[in]		const USHORT usPEN_INSTANCE - The pen instance we want to check
///
/// @return			True if the pen is currently waiting
///
//****************************************************************************
const bool CPenManager::IsPenWaitingForAlignment(const USHORT usPEN_INSTANCE) {
	bool bIsWaiting = false;

	CPenControl *pkPenCtrl = NULL;

	pkPenCtrl = GetPenControl(usPEN_INSTANCE, ZERO_BASED);
	if (pkPenCtrl != NULL) {
		// Check if Pen is running, although enabled may not be running due to incorrect config like maths block failed)
		if (pkPenCtrl->IsPenRunning()) {
			bIsWaiting = (pkPenCtrl->m_logChannel.IsWaitingForAlignment() == TRUE);
		}
	}

	return bIsWaiting;
}

//****************************************************************************
// const USHORT CPenManager::NoOfPensWaitingForAlignment( )
///
/// Method that determines how many pens in a group are (currently) waiting for alignment
///
/// @param[in]	group - Group identifier of T_PEN_GROUPS
///
/// @return			The number of pens waiting for alignment
///
//****************************************************************************
const USHORT CPenManager::NoOfPensWaitingForAlignment(T_PEN_GROUPS group) {
	USHORT usPensWaiting = 0;

	CPenControl *pPenCtl;

	// Run through enabled pen list performing a process on all available enabled pens
	for (int loggedPenEntry = 0; loggedPenEntry < m_GroupPens[group].GetNumberOfPens(); loggedPenEntry++) {
		pPenCtl = m_GroupPens[group].GetEntry(loggedPenEntry);
		if (pPenCtl != NULL) {
			if (pPenCtl->m_logChannel.IsWaitingForAlignment() == TRUE) {
				// increment the number of pens waiting
				++usPensWaiting;
			}
		}
	}

	return usPensWaiting;
}

//**********************************************************************
/// Stop logging for a group/all pens
/// 
/// @param[in]	group - Group identifier of T_PEN_GROUPS
///
/// @return		T_PENMANAGER_RETURN 
//**********************************************************************
T_PENMANAGER_RETURN CPenManager::StopLogging(T_PEN_GROUPS group) {
	CPenControl *pPenCtl;

	m_LoggingCS.lock();	// Protect from setting request from UI when data processing is running requests

	m_LogChannelActionPending = TRUE;

	// Run through enabled pen list performing a process on all available enabled pens
	for (int loggedPenEntry = 0; loggedPenEntry < m_GroupPens[group].GetNumberOfPens(); loggedPenEntry++) {
		pPenCtl = m_GroupPens[group].GetEntry(loggedPenEntry);
		if (pPenCtl != NULL) {
			pPenCtl->RequestLoggingMode(LOGGING_MODE_STOP);
		}
	}
	m_LoggingCS.lock();

	return PENMANAGER_OK;
}

//**********************************************************************
/// Stop logging for a all pens using a direct call, only use within thread
/// 
/// @param[in]	group - Group identifier of T_PEN_GROUPS
///
/// @return		T_PENMANAGER_RETURN 
//**********************************************************************
T_PENMANAGER_RETURN CPenManager::StopAllLoggingDirect() {
	CPenControl *pPenCtl;

	m_LoggingCS.lock();	// Protect from setting request from UI when data processing is running requests

	m_LogChannelActionPending = TRUE;

	// Run through enabled pen list performing a process on all available enabled pens
	for (int loggedPenEntry = 0; loggedPenEntry < m_GroupPens[PEN_GROUP_ALL].GetNumberOfPens(); loggedPenEntry++) {
		pPenCtl = m_GroupPens[PEN_GROUP_ALL].GetEntry(loggedPenEntry);
		if (pPenCtl != NULL) {
			pPenCtl->StopPenLoggingDirect( FALSE);
		}
	}
	m_LoggingCS.lock();

	return PENMANAGER_OK;
}

//**********************************************************************
/// Stop logging for a single pen
/// 
/// @param[in]	usPEN_INSTANCE - pen instance
///
/// @return		T_PENMANAGER_RETURN 
//**********************************************************************
T_PENMANAGER_RETURN CPenManager::StopPenLogging(const USHORT usPEN_INSTANCE) {
	CPenControl *pkPenCtrl = NULL;

	// Protect from setting request from UI when data processing is running requests
	m_LoggingCS.lock();

	pkPenCtrl = GetPenControl(usPEN_INSTANCE, ZERO_BASED);
	if (pkPenCtrl != NULL) {
		pkPenCtrl->RequestLoggingMode(LOGGING_MODE_STOP);
	}

	m_LoggingCS.lock();

	return PENMANAGER_OK;
}

//**********************************************************************
/// Flush all log channels
/// 
/// @return		T_PENMANAGER_RETURN 
//**********************************************************************
T_PENMANAGER_RETURN CPenManager::FlushAllLogChannels() {
	T_PENMANAGER_RETURN retVal = PENMANAGER_OK;
	CPenControl *pPenCtl;

	m_LoggingCS.lock();	// Protect from setting request from UI when data processing is running requests

	m_LogChannelActionPending = TRUE;
	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//for Scheduler thread
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();

	// Run through enabled pen list performing a process on all available enabled pens
	for (int loggedPenEntry = 0; loggedPenEntry < m_LoggingPens.GetNumberOfPens(); loggedPenEntry++) {
		if (pThreadInfo != NULL) {
			//Update the Thread Counter for the Scheduler thread
			//thread for each iteration
			pThreadInfo->UpdateThreadCounter(AM_TX_SCHEDULER_THREAD);
		}

		pPenCtl = m_LoggingPens.GetEntry(loggedPenEntry);
		if (pPenCtl != NULL) {
			// Request log channel flush
			pPenCtl->RequestLoggingMode(LOGGING_MODE_FLUSH);
		}
	}
	m_LoggingCS.lock();

	return retVal;
}

//**********************************************************************
/// Function to calculate the Max file values for each queue dependant 
/// on a bias towards Charts or Logs
/// 
/// @param[in] BiasAmount - Bias towards one queue type, Range 0 - 100
/// @param[in] BiasTowards - Direction BiasAmount is applied to, 
///   BIAS_CHART or BIAS_LOG
///
/// @return		T_CALC_MAX_RET 
/// 
//**********************************************************************
T_CALC_MAX_RET CPenManager::CalculateQueueMaxVals(BYTE BiasAmount, T_BIAS_TOWARDS BiasTowards,
		T_CALC_MAX_INFO *pCalcInfo, BOOL bQuery) {
	if (BiasAmount > MAX_BIAS) {
		return INVALID_BIAS_AMOUNT;
	}
	BYTE bias = MAX_BIAS - BiasAmount;			//for ease of calculation later, Maximum bias is 0 and 100 is no bias

	T_PQRATE_MAX_INFO pQInfo = new T_QRATE_MAX_INFO;

	float fLogRateTotal = QMC_ZERO;
	float fChartRateTotal = QMC_ZERO;
	float fRateTotal = QMC_ZERO;
	int i; //index for the for loops
	int Unbiassed = QMC_ZERO;
	int Biassed = QMC_ZERO;
	int SpareFilePool = QMC_ZERO;
	int Tmp = QMC_ZERO;
	SHORT numActivePens = QMC_ZERO;
	SHORT numActiveLogs = QMC_ZERO;
	SHORT numFastLogs = QMC_ZERO;

	USHORT avgThresh = QMC_ZERO;

	float fFastRate = QMC_ZERO;
	float fMedRate = QMC_ZERO;
	float fSlowRate = QMC_ZERO;
	float fLogRate = QMC_ZERO;
	USHORT NumBlocksPerFile = pSYSTEM_INFO->GetNumBlocksPerFile();
	const USHORT NumMsgReadsPerBlock = g_MAX_NO_OF_MESSAGES_PER_BLOCK;
	USHORT NumAvailFiles = pSYSTEM_INFO->GetNumCreatedFiles(); // this needs to be calculated based on actual number of files in system

	int iaMessageFiles[MAX_MESSAGE_LISTS]; //num of max files to set for the message lists

	//calculate the number of files required to be reserved for message lists based on number of messages
	//and disk file size in blocks
	for (i = 0; i < MAX_MESSAGE_LISTS; i++) {
		if ((QMC_NUM_MSG_Q_READS_ARRAY[i] != 0) && (i < CMessageListServices::msqMAX_QUEUES)) {
			iaMessageFiles[i] = QMC_NUM_MSG_Q_READS_ARRAY[i] / (NumMsgReadsPerBlock * NumBlocksPerFile);
			if (QMC_NUM_MSG_Q_READS_ARRAY[i] % (NumMsgReadsPerBlock * NumBlocksPerFile))
				iaMessageFiles[i]++;
		} else
			iaMessageFiles[i] = 0;
	}
	//adjust number of files available by the number reserved for messagelists (fixed)

	USHORT numMsgFiles = 0;
	for (i = 0; i < CMessageListServices::msqMAX_QUEUES; i++) {
		NumAvailFiles -= iaMessageFiles[i];
		numMsgFiles += iaMessageFiles[i];
	}

	//and the number allocated to other queues such as messages

	//Step 1 get the chart and log rates for each queue as an absolute data rate
	//checking for possible queues which won't need more than 1 block due to slowness etc.

	//find the fast med and slow rates and set the flags

	//86400 = number of seconds per day
	//fast Chart rate
	fFastRate = ((float) CHART_RATE_FACTOR
			/ (CHART_READS_PER_BLOCK * CChartQManager::GetChartSpeed(CQT_STRIP, SPEED_FAST)));//CHART_READS_PER_BLOCK = 63
	fMedRate = ((float) CHART_RATE_FACTOR
			/ (CHART_READS_PER_BLOCK * CChartQManager::GetChartSpeed(CQT_STRIP, SPEED_MEDIUM)));
	fSlowRate = ((float) CHART_RATE_FACTOR
			/ (CHART_READS_PER_BLOCK * CChartQManager::GetChartSpeed(CQT_STRIP, SPEED_SLOW)));//CHART_RATE_FACTOR = 1000000

	float fRealSlowRate = fSlowRate;
	float fRealMedRate = fMedRate;
	if (BIAS_CHART == BiasTowards) {
		if (BiasAmount <= 35 && BiasAmount != 0) {
			fSlowRate *= 3;
			fMedRate *= 2;
		}
		if (BiasAmount > 35) {
			fSlowRate *= 5;
			fMedRate *= 3;
		}
		if (BiasAmount > 65) {
			fMedRate *= 6;
			fSlowRate *= 10;
		}
	}

//	CTV6Timer fileTimer( TIMER_HIGH_RES );
//	fileTimer.StartTimer();
	for (i = 0; i < V6_MAX_PENS; i++) {

		//initialise Variable Arrays
		pQInfo->fChartQDataRate[GetFastStripQueueIndex(i)] = QMC_ZERO;
		pQInfo->fChartQDataRate[GetMedStripQueueIndex(i)] = QMC_ZERO;
		pQInfo->fChartQDataRate[GetSlowStripQueueIndex(i)] = QMC_ZERO;
		pQInfo->fLogQDataRate[i] = QMC_ZERO;

		pQInfo->MaxFilesPerChartQ[GetFastStripQueueIndex(i)] = QMC_ZERO;
		pQInfo->MaxFilesPerChartQ[GetMedStripQueueIndex(i)] = QMC_ZERO;
		pQInfo->MaxFilesPerChartQ[GetSlowStripQueueIndex(i)] = QMC_ZERO;
		pQInfo->MaxFilesPerLogQ[i] = QMC_ZERO;

		pQInfo->MaxFilesPerChartQ[GetFastCircularQueueIndex(i)] = QMC_ZERO;
		pQInfo->MaxFilesPerChartQ[GetMedCircularQueueIndex(i)] = QMC_ZERO;
		pQInfo->MaxFilesPerChartQ[GetSlowCircularQueueIndex(i)] = QMC_ZERO;

		pQInfo->aPenActive[i] = FALSE;
		pQInfo->aLogActive[i] = FALSE;
		pQInfo->aLogFast[i] = FALSE;

		if (m_Pen[i].IsPenRunning())	//test for active pens
		{
			numActivePens++;
			//Get log rate
			pQInfo->aPenActive[i] = TRUE;
			if (m_Pen[i].m_logChannel.IsEnabled()) {
				numActiveLogs++;
				pQInfo->aLogActive[i] = TRUE;
				//calculate Data rate relative to chart rate

				//for estimation purposes, fuzzy is assumed to have 2:1 compression
				//though is used properly will be far greater
				float fFuzzyFactor;
				//check if has any alarm enabled
				BOOL AlmEn = FALSE;
				T_PPEN pPenPtr = m_Pen[i].GetPenConfigPtr();
				for (int j = 0; j < PEN_ALM_SIZE && FALSE == AlmEn; j++) {
					if (pPenPtr->Alm[j].EnableType != ALARM_DISABLED && TRUE == pPenPtr->Alm[j].ChangeLog) {
						AlmEn = TRUE;
					}
				}
				//set the rate to the normal rate unless there is an alarm rate change
//				USHORT AlarmRate = pPenPtr->PenLog.AlarmRateMS
				ULONG RateTemp = m_Pen[i].m_logChannel.CurrentRate();
				if (AlmEn) {
					ULONG ulAlmRate = NULL;
					ULONG ulNrmRate = NULL;
					ULONG mul = NULL;
					//Get alarm rate
					switch (pPenPtr->PenLog.AlarmRateUnits) {
					//rate in MS is selected from list
					case lruMilliseconds:
						switch (pPenPtr->PenLog.AlarmRateMS) {
						case lmr2Hertz:
							ulAlmRate = RATE_2HZ_IN_MS;
							break;
						case lmr5Hertz:
							ulAlmRate = RATE_5HZ_IN_MS;
							break;
						case lmr10Hertz:
							ulAlmRate = RATE_10HZ_IN_MS;
							break;
						case lmr50Hertz:
							if (pSYSTEM_INFO->FWOptionFastScanAvailable())
								ulAlmRate = RATE_50HZ_IN_MS;
							else
								ulAlmRate = RATE_10HZ_IN_MS;
							break;
						default:
							ulAlmRate = RATE_2HZ_IN_MS;
						}
						break;
						//other rates are direct entry with a multiplier
					case lruSeconds:
						ulAlmRate = pPenPtr->PenLog.AlarmRate * RATE_S_TO_MS_MULTIPLIER;
						break;
					case lruMinutes:
						ulAlmRate = pPenPtr->PenLog.AlarmRate * RATE_M_TO_MS_MULTIPLIER;
						break;
					case lruHours:
						ulAlmRate = pPenPtr->PenLog.AlarmRate * RATE_H_TO_MS_MULTIPLIER;
						break;
					default:
						ulAlmRate = pPenPtr->PenLog.AlarmRate * RATE_S_TO_MS_MULTIPLIER;
						break;
					}

					//Now do the same for normal rate
					switch (pPenPtr->PenLog.RateUnits) {
					//rate in MS is selected from list
					case lruMilliseconds:
						switch (pPenPtr->PenLog.RateMS) {
						case lmr2Hertz:
							ulNrmRate = RATE_2HZ_IN_MS;
							break;
						case lmr5Hertz:
							ulNrmRate = RATE_5HZ_IN_MS;
							break;
						case lmr10Hertz:
							ulNrmRate = RATE_10HZ_IN_MS;
							break;
						case lmr50Hertz:
							if (pSYSTEM_INFO->FWOptionFastScanAvailable())
								ulNrmRate = RATE_50HZ_IN_MS;
							else
								ulNrmRate = RATE_10HZ_IN_MS;
							break;
						default:
							ulNrmRate = RATE_2HZ_IN_MS;
						}
						break;
						//other rates are direct entry with a multiplier
					case lruSeconds:
						ulNrmRate = pPenPtr->PenLog.Rate * RATE_S_TO_MS_MULTIPLIER;
						break;
					case lruMinutes:
						ulNrmRate = pPenPtr->PenLog.Rate * RATE_M_TO_MS_MULTIPLIER;
						break;
					case lruHours:
						ulNrmRate = pPenPtr->PenLog.Rate * RATE_H_TO_MS_MULTIPLIER;
						break;
					default:
						ulNrmRate = pPenPtr->PenLog.Rate * RATE_S_TO_MS_MULTIPLIER;
						break;
					}
					//bias the rate 75:25 normal:alarm only if the alarm rate is faster
					//(bigger = slower)
					if (ulAlmRate < ulNrmRate) {
						//if the Alarm rate is Hugely different, assume 25% of alarm rate
						//otherwise the disparity of the slow rate will dwarf the alarm rate
						//and have little or no effect
						if ((ulAlmRate != 0) && (ulNrmRate / ulAlmRate >= (PERCENTAGE / ALARM_WEIGHT)))
							RateTemp = ulAlmRate * (PERCENTAGE / ALARM_WEIGHT);
						else
							RateTemp = ULONG((ulAlmRate * ALARM_WEIGHT) + (ulNrmRate * (PERCENTAGE - ALARM_WEIGHT)))
									/ PERCENTAGE;
					} else
						RateTemp = ulNrmRate;
				}
				//apply a factor dependant on log style
				if (pPenPtr->PenLog.LogType == LOGTYPE_FUZZY)
					fFuzzyFactor = QFUZZY;
				else if (pPenPtr->PenLog.LogStyle == LOGSTYLE_MAXMIN)
					fFuzzyFactor = QMAXMIN;
				else
					fFuzzyFactor = QCONTINUOUS;
				//calc absolute rate
				pQInfo->fLogQDataRate[i] = (LOG_RATE_FACTOR
						/ (float) (LOG_READS_PER_BLOCK * ((fFuzzyFactor * RateTemp) / PERCENTAGE)));
				if (pQInfo->fLogQDataRate[i] >= 90) // cut off point to determine if a Q gets more than 1 file
						{
					numFastLogs++;
					pQInfo->aLogFast[i] = TRUE;
				}

			} else
				pQInfo->fLogQDataRate[i] = QMC_ZERO;

			pQInfo->fChartQDataRate[GetFastStripQueueIndex(i)] = fFastRate; //Fast Chart
			pQInfo->fChartQDataRate[GetMedStripQueueIndex(i)] = fMedRate; //Med Chart
			pQInfo->fChartQDataRate[GetSlowStripQueueIndex(i)] = fSlowRate; //Slow Chart

			//Step 2 Add all active percentages together
			//Log
			fLogRateTotal += pQInfo->fLogQDataRate[i];
			//Charts
			fChartRateTotal += fFastRate;
			fChartRateTotal += fMedRate;
			fChartRateTotal += fSlowRate;

			pQInfo->MaxFilesPerChartQ[GetFastCircularQueueIndex(i)] = QMC_FILES_PER_CIRCULAR_CHART_QUEUE;
			pQInfo->MaxFilesPerChartQ[GetMedCircularQueueIndex(i)] = QMC_FILES_PER_CIRCULAR_CHART_QUEUE;
			pQInfo->MaxFilesPerChartQ[GetSlowCircularQueueIndex(i)] = QMC_FILES_PER_CIRCULAR_CHART_QUEUE;
		}
	}

	// Old threshold calculation method using magic number which ran too low on High pen counts
	//USHORT TotalUsableBlocks = (USHORT)(pSYSTEM_INFO->GetNumDataBlocks()* 0.6);

	// Derive the number of blocks we can use as an extra buffer for fast chart queues and fast logging Pens
	// take the worst case instant allocation which is all pens and all chart queues plus message lists
	USHORT TotalUsableBlocks = pSYSTEM_INFO->GetNumDataBlocks()
			- ((numActivePens * QMC_TOTAL_NO_OF_QUEUES_PER_PEN) + MAX_MESSAGE_LISTS);

	// From the remaining blocks remove the usage of the Medium and slow chart queues, and the mornal logging Pens
	// which will all be allocated 1 pen.
	avgThresh = TotalUsableBlocks
			- ((numActivePens * (QMC_TOTAL_NO_OF_QUEUES_PER_PEN - 2)) + (numActiveLogs - numFastLogs));

	// What is left in avgThresh can now be divided between the number of fast chart queeus and fast logging pens
	int queueReq = (numFastLogs + numActivePens);
	if (queueReq > 0) {
		// Divide the number of spare blocks between the fast chart and fast pen queues
		avgThresh /= queueReq;
	}

	// Cap the queue lengths and make sure we have at least 1 block in the queue for loaded systems.
	if (avgThresh > THRESH_MAX)
		avgThresh = THRESH_MAX;
	else if (avgThresh == 0)
		avgThresh = 1;

	//step 2 part 2
	fRateTotal = fLogRateTotal + fChartRateTotal;

	//PSR Fix for PAR# 1-3KA28IM - Black spot observed on storage bias cursor begin
	//step 2 part3	
	// now adjust by the number of circular chart queues, which will be one file for each pen - discover
	// how many pens are supported on this device and how many are active in that
	// This can be only for the active pens * 3(as 3 queues takes 1 file each) instead of all supported pens * 3
	int numberOfCircularChartFiles = numActivePens
			* (QMC_NO_OF_CIRCULAR_PEN_QUEUES_PER_PEN * QMC_FILES_PER_CIRCULAR_CHART_QUEUE);
	NumAvailFiles -= numberOfCircularChartFiles;
	//PSR Fix for PAR# 1-3KA28IM - Black spot observed on storage bias cursor end

	//Step 3 determine each rate as an overall percentage against step 2 total
	//((Q rate)/(step2 result))*(number of available files)
	//make sure RateTotal is not 0
	if (QMC_ZERO != fRateTotal) {
		USHORT FileOfset = QMC_ZERO;
		for (int j = 0; j < 2; j++)	//outer of 2 pass loop. first pass to determine how many 'excess' files
				{
			for (i = 0; i < V6_MAX_PENS; i++)	//working loop
					{
				if (pQInfo->aPenActive[i])	//test for active pens
				{
					if (pQInfo->aLogActive[i])	//test for active logs
					{
						//log
						Tmp = (int) ((pQInfo->fLogQDataRate[i] / fRateTotal) * NumAvailFiles);
						if (!Tmp) {
							pQInfo->MaxFilesPerLogQ[i] = MIN_Q_LEN;
							FileOfset++;
						} else
							pQInfo->MaxFilesPerLogQ[i] = Tmp;
					}
					//Fast
					Tmp = (int) ((pQInfo->fChartQDataRate[GetFastStripQueueIndex(i)] / fRateTotal) * NumAvailFiles);
					if (!Tmp) {
						pQInfo->MaxFilesPerChartQ[GetFastStripQueueIndex(i)] = MIN_Q_LEN;
						FileOfset++;
					} else
						pQInfo->MaxFilesPerChartQ[GetFastStripQueueIndex(i)] = Tmp;

					//Med
					Tmp = (int) ((pQInfo->fChartQDataRate[GetMedStripQueueIndex(i)] / fRateTotal) * NumAvailFiles);
					if (!Tmp) {
						pQInfo->MaxFilesPerChartQ[GetMedStripQueueIndex(i)] = MIN_Q_LEN;
						FileOfset++;
					} else
						pQInfo->MaxFilesPerChartQ[GetMedStripQueueIndex(i)] = Tmp;
					//slow
					Tmp = (int) ((pQInfo->fChartQDataRate[GetSlowStripQueueIndex(i)] / fRateTotal) * NumAvailFiles);
					if (!Tmp) {
						pQInfo->MaxFilesPerChartQ[GetSlowStripQueueIndex(i)] = MIN_Q_LEN;
						FileOfset++;
					} else
						pQInfo->MaxFilesPerChartQ[GetSlowStripQueueIndex(i)] = Tmp;
				}
			}
			//adjust the number of files to use for the second pass
			//NumAvailFiles not used after this point so can be ignored from here on
			NumAvailFiles -= FileOfset;
		}
	}
//	int totaliser = 0;
//	for(i=0;i<MAX_PENS;i++)
//	{
	//if(aPenActive[i])
//		{
//			totaliser += MaxFilesPerChartQ[(i*FASTMEDSLOW)+PENQ_FAST]+
//			MaxFilesPerChartQ[(i*FASTMEDSLOW)+PENQ_MED]+
//			MaxFilesPerChartQ[(i*FASTMEDSLOW)+PENQ_SLOW];

//			totaliser +=MaxFilesPerLogQ[i];
//		}
//	}
//	qDebug("Files alloc 1: %d\n",totaliser);

	//Step 4 Subtract bias% of files from each Q and add to a 'spare' count
	//does a bias need to be applied? 100 = no bias
	if (MAX_BIAS != bias) //test 
			{

		//make sure both the chart and log queues have something in them otherwise there's no point
		if ((QMC_ZERO != fLogRateTotal) && (0 != fChartRateTotal)) {
			if (BIAS_CHART == BiasTowards) {
				//Chart Bias
				for (i = 0; i < V6_MAX_PENS; i++) {
					if (pQInfo->aPenActive[i]) {
						//total up the unbiassed files per queue
						Unbiassed += pQInfo->MaxFilesPerLogQ[i];
						//work out the new biassed file count using the bias as a percentage
						Tmp = (pQInfo->MaxFilesPerLogQ[i] * bias) / PERCENTAGE; //bias will be value 0 to 100 to have 1% granularity
						//set the new filecount with a minimum of 1
						if (Tmp)
							pQInfo->MaxFilesPerLogQ[i] = Tmp;
						else
							pQInfo->MaxFilesPerLogQ[i] = MIN_Q_LEN;
						//total up the biassed files per queue
						Biassed += pQInfo->MaxFilesPerLogQ[i];
					}
				}
				/// @TODO Do a sanity test to check the number of files tally up and do not exceed the total number of files

				SpareFilePool = Unbiassed - Biassed;
				//Step 5 now spread files across the Chart Q's
				for (i = 0; i < V6_MAX_PENS; i++) {
					if (pQInfo->aPenActive[i])						///@TODO test for valid pen
					{
						Tmp = (int) ((SpareFilePool
								* (pQInfo->fChartQDataRate[GetFastStripQueueIndex(i)] / fChartRateTotal)));
						pQInfo->MaxFilesPerChartQ[GetFastStripQueueIndex(i)] += Tmp;

						Tmp = (int) ((SpareFilePool
								* (pQInfo->fChartQDataRate[GetMedStripQueueIndex(i)] / fChartRateTotal)));
						pQInfo->MaxFilesPerChartQ[GetMedStripQueueIndex(i)] += Tmp;

						Tmp = (int) ((SpareFilePool
								* (pQInfo->fChartQDataRate[GetSlowStripQueueIndex(i)] / fChartRateTotal)));
						pQInfo->MaxFilesPerChartQ[GetSlowStripQueueIndex(i)] += Tmp;
					}
				}
			} else {
				//Log Bias
				for (i = 0; i < V6_MAX_PENS; i++) {
					if (pQInfo->aPenActive[i])						///@TODO test for active pens
					{
						//total up the unbiassed files per queue
						Unbiassed += pQInfo->MaxFilesPerChartQ[GetFastStripQueueIndex(i)];
						//work out the new biassed file count using the bias as a percentage
						Tmp = (pQInfo->MaxFilesPerChartQ[GetFastStripQueueIndex(i)] * bias) / PERCENTAGE;//bias will be value 0 to 100 to have 1% granularity
						//set the new filecount with a minimum of 1
						if (Tmp)
							pQInfo->MaxFilesPerChartQ[GetFastStripQueueIndex(i)] = Tmp;
						else
							pQInfo->MaxFilesPerChartQ[GetFastStripQueueIndex(i)] = MIN_Q_LEN;
						//total up the biassed files per queue
						Biassed += pQInfo->MaxFilesPerChartQ[GetFastStripQueueIndex(i)];

						//total up the unbiassed files per queue
						Unbiassed += pQInfo->MaxFilesPerChartQ[GetMedStripQueueIndex(i)];
						//work out the new biassed file count using the bias as a percentage
						Tmp = (pQInfo->MaxFilesPerChartQ[GetMedStripQueueIndex(i)] * bias) / PERCENTAGE;//bias will be value 0 to 100 to have 1% granularity
						//set the new filecount with a minimum of 1
						if (Tmp)
							pQInfo->MaxFilesPerChartQ[GetMedStripQueueIndex(i)] = Tmp;
						else
							pQInfo->MaxFilesPerChartQ[GetMedStripQueueIndex(i)] = MIN_Q_LEN;
						//total up the biassed files per queue
						Biassed += pQInfo->MaxFilesPerChartQ[GetMedStripQueueIndex(i)];

						//total up the unbiassed files per queue
						Unbiassed += pQInfo->MaxFilesPerChartQ[GetSlowStripQueueIndex(i)];
						//work out the new biassed file count using the bias as a percentage
						Tmp = (pQInfo->MaxFilesPerChartQ[GetSlowStripQueueIndex(i)] * bias) / PERCENTAGE;//bias will be value 0 to 100 to have 1% granularity
						//set the new filecount with a minimum of 1
						if (Tmp)
							pQInfo->MaxFilesPerChartQ[GetSlowStripQueueIndex(i)] = Tmp;
						else
							pQInfo->MaxFilesPerChartQ[GetSlowStripQueueIndex(i)] = MIN_Q_LEN;
						//total up the biassed files per queue
						Biassed += pQInfo->MaxFilesPerChartQ[GetSlowStripQueueIndex(i)];
					}
				}
				///@todo Do a sanity test to check the number of files tally up and do not exceed the total number of files

				//work out the number of files to spread around
				SpareFilePool = Unbiassed - Biassed;
				//Step 5 now spread files across the Log Q's
				for (i = 0; i < V6_MAX_PENS; i++) {
					if (pQInfo->aPenActive[i]) {
						Tmp = (int) ((SpareFilePool * (pQInfo->fLogQDataRate[i] / fLogRateTotal)));
						pQInfo->MaxFilesPerLogQ[i] += Tmp;
					}
				}
			}
		}
	}
	//find the number of surplus files and re-distribute
	int allocFiles = 0;
	for (i = 0; i < V6_MAX_PENS; i++) {
		if (pQInfo->aPenActive[i]) {
			allocFiles += pQInfo->MaxFilesPerChartQ[GetFastStripQueueIndex(i)];
			allocFiles += pQInfo->MaxFilesPerChartQ[GetMedStripQueueIndex(i)];
			allocFiles += pQInfo->MaxFilesPerChartQ[GetSlowStripQueueIndex(i)];
			allocFiles += pQInfo->MaxFilesPerChartQ[GetFastCircularQueueIndex(i)];
			allocFiles += pQInfo->MaxFilesPerChartQ[GetMedCircularQueueIndex(i)];
			allocFiles += pQInfo->MaxFilesPerChartQ[GetSlowCircularQueueIndex(i)];
		}
		if (pQInfo->aLogActive[i]) {
			allocFiles += pQInfo->MaxFilesPerLogQ[i];
		}
	}
	//PSR Fix for PAR# 1-3KA28IM - Black spot observed on storage bias cursor begin
	//We are allocating one file per Circular chart Queue(3 queues) per pen in the above (for loop has allocFiles) allocation logic 
	//So substracting these numberOfCircularChartFiles again from GetNumCreatedFiles is wrong and these file quantity will get unused 
	//As they will go out of alocation which will cause black spot on Bias dialog
	SpareFilePool = pSYSTEM_INFO->GetNumCreatedFiles() - allocFiles - numMsgFiles; //- numberOfCircularChartFiles;
	//PSR Fix for PAR# 1-3KA28IM - Black spot observed on storage bias cursor end

	int LastRun;
	while (SpareFilePool) {
		LastRun = SpareFilePool;
		//now re-allocate them
		if (BIAS_CHART == BiasTowards) {
			//three loops for each set of strip queues
			//2 = PENQ_FAST
			for (i = STRIP_PENQ_FAST; i >= STRIP_PENQ_SLOW; i--) {
				//only run if all pens can be covered by a run
				if (SpareFilePool >= numActivePens) {
					//loop through each pen
					for (int j = 0; j < V6_MAX_PENS; j++) {
						if (pQInfo->aPenActive[j]) {
							pQInfo->MaxFilesPerChartQ[(j * NO_OF_PENQS) + i]++;
							SpareFilePool--;
						}
					}
				}
			}
			//remaining go onto log queues, shortest first

			T_RATE_SORT RateCopy[V6_MAX_PENS];
			for (i = 0; i < V6_MAX_PENS; i++) {
				//copy the values for sorting
				RateCopy[i].ID = i;
				RateCopy[i].value = pQInfo->fLogQDataRate[i];
			}
			//sort the rates largest first
			qsort(RateCopy, V6_MAX_PENS, sizeof(T_RATE_SORT), compare);
			//allocate files to the fastest queues first
			for (i = 0; i < V6_MAX_PENS && (SpareFilePool > 0); i++) {
				if (RateCopy[i].value) {
					pQInfo->MaxFilesPerLogQ[RateCopy[i].ID]++;
					SpareFilePool--;
				}
			}
		}
		//BIAS_LOG - put all spare onto log queues
		else if (BIAS_LOG == BiasTowards) {
			T_RATE_SORT RateCopy[V6_MAX_PENS];
			for (i = 0; i < V6_MAX_PENS; i++) {
				//copy the values for sorting
				RateCopy[i].ID = i;
				RateCopy[i].value = pQInfo->fLogQDataRate[i];
			}
			//sort the rates largest first
			qsort(RateCopy, V6_MAX_PENS, sizeof(T_RATE_SORT), compare);
			//allocate files to the fastest queues first
			for (i = 0; i < V6_MAX_PENS && (SpareFilePool > 0); i++) {
				if (RateCopy[i].value) {
					pQInfo->MaxFilesPerLogQ[RateCopy[i].ID]++;
					SpareFilePool--;
				}
			}
		}
		//if nothing allocated, get out
		if (LastRun == SpareFilePool) {
			break;
		}
	}

#if FALSE //test tracing
//	fileTimer.StopTimer();
//	fileTimer.TraceTimer( L"MaxVarsCalculated. time taken: " );
	int totaliser = 0;
	qDebug("Chart: ");
	for(i=0;i<V6_MAX_PENS;i++)
	{
		//if(aPenActive[i])
		{
			totaliser +=	pQInfo->MaxFilesPerChartQ[GetFastStripQueueIndex(i)]+
							pQInfo->MaxFilesPerChartQ[GetMedStripQueueIndex(i)]+
							pQInfo->MaxFilesPerChartQ[GetSlowStripQueueIndex(i)]+
							pQInfo->MaxFilesPerChartQ[GetFastCircularQueueIndex(i)] +
							pQInfo->MaxFilesPerChartQ[GetMedCircularQueueIndex(i)] +
							pQInfo->MaxFilesPerChartQ[GetSlowCircularQueueIndex(i)];
			qDebug("%d, %d, %d, %d, %d, %d, %d:", i ,
				pQInfo->MaxFilesPerChartQ[GetFastStripQueueIndex(i)],
				pQInfo->MaxFilesPerChartQ[GetMedStripQueueIndex(i)],
				pQInfo->MaxFilesPerChartQ[GetSlowStripQueueIndex(i)],
				pQInfo->MaxFilesPerChartQ[GetFastCircularQueueIndex(i)],
				pQInfo->MaxFilesPerChartQ[GetMedCircularQueueIndex(i)],
				pQInfo->MaxFilesPerChartQ[GetSlowCircularQueueIndex(i)]);
		}
		
	}
	qDebug("\n");
	qDebug("Log: ");
	for(i=0;i<V6_MAX_PENS;i++)
	{
		totaliser +=pQInfo->MaxFilesPerLogQ[i];
		//if(aPenActive[i])
		{
			qDebug("%d,%d:",i,pQInfo->MaxFilesPerLogQ[i]);
		}
	}
	qDebug("\nTotal Files alloc: %d\n\n",totaliser);
#endif

	//create the report info
	if (NULL != pCalcInfo) {
		//calculate the chart times
		//as the calculation below would yield a result in s *10
		pCalcInfo->ulChartFastTime = 0;
		pCalcInfo->ulChartMedTime = 0;
		pCalcInfo->ulChartSlowTime = 0;
		pCalcInfo->usNumPens = numActivePens;
		pCalcInfo->usNumLogs = numActiveLogs;
		pCalcInfo->usNumLogFiles = 0;
		pCalcInfo->usNumChartFiles = 0;
		pCalcInfo->usLongestID = 0;
		pCalcInfo->usShortestID = 0;
		pCalcInfo->usNumMsgFiles = numMsgFiles;

		if (numActivePens) {
			i = 0;
			while (FALSE == pQInfo->aPenActive[i]) {
				i++;
				if (i >= V6_MAX_PENS)
					break;
			}

			pCalcInfo->ulChartFastTime = (ULONG) ((1 / fFastRate) * NumBlocksPerFile
					* pQInfo->MaxFilesPerChartQ[GetFastStripQueueIndex(i)] * 10000);
			pCalcInfo->ulChartMedTime = (ULONG) ((1 / fRealMedRate) * NumBlocksPerFile
					* pQInfo->MaxFilesPerChartQ[GetMedStripQueueIndex(i)] * 10000);
			pCalcInfo->ulChartSlowTime = (ULONG) ((1 / fRealSlowRate) * NumBlocksPerFile
					* pQInfo->MaxFilesPerChartQ[GetSlowStripQueueIndex(i)] * 10000);

			BOOL FirstActive = TRUE;
			for (i = 0; i < V6_MAX_PENS; i++) {
				if (pQInfo->aPenActive[i]) {
					pCalcInfo->usNumChartFiles += pQInfo->MaxFilesPerChartQ[GetFastStripQueueIndex(i)];
					pCalcInfo->usNumChartFiles += pQInfo->MaxFilesPerChartQ[GetMedStripQueueIndex(i)];
					pCalcInfo->usNumChartFiles += pQInfo->MaxFilesPerChartQ[GetSlowStripQueueIndex(i)];

					// add files for the circular chart queue speeds
					pCalcInfo->usNumChartFiles += pQInfo->MaxFilesPerChartQ[GetFastCircularQueueIndex(i)];
					pCalcInfo->usNumChartFiles += pQInfo->MaxFilesPerChartQ[GetMedCircularQueueIndex(i)];
					pCalcInfo->usNumChartFiles += pQInfo->MaxFilesPerChartQ[GetSlowCircularQueueIndex(i)];
				}
				if (pQInfo->aLogActive[i]) {
					pCalcInfo->usNumLogFiles += pQInfo->MaxFilesPerLogQ[i];
					//calc the rate into time then test for the longest
					ULONG ulTmp = (ULONG) ((1 / pQInfo->fLogQDataRate[i]) * NumBlocksPerFile
							* pQInfo->MaxFilesPerLogQ[i] * 10000);
					if (FirstActive || (pCalcInfo->ulLongestLog < ulTmp)) {
						pCalcInfo->ulLongestLog = ulTmp;
						pCalcInfo->usLongestID = i + 1;
						pCalcInfo->usLongestFiles = pQInfo->MaxFilesPerLogQ[i];
					}
					//now test for the shortest
					if (FirstActive || (pCalcInfo->ulShortestLog > ulTmp)) {
						pCalcInfo->ulShortestLog = ulTmp;
						pCalcInfo->usShortestID = i + 1;
						pCalcInfo->usShortestFiles = pQInfo->MaxFilesPerLogQ[i];
					}
					FirstActive = FALSE;
				}
			}
		}
	}

	//only apply if not being queried
	if (!bQuery) {
		CQMDiskServices &DS = CQueueManager::GetHandle()->GetDiskServices();

		//Apply New Max's to the queues
		for (i = 0; i < V6_MAX_PENS; i++) {
			DS.SetMaxFiles(i * QMC_TOTAL_NO_OF_QUEUES_PER_PEN, pQInfo->MaxFilesPerLogQ[i]);

			// strip chart queues
			DS.SetMaxFiles(CQMBlockServices::GetPenQueueHandle(i, QMC_QUEUE_PEN_SCR_FAST),
					pQInfo->MaxFilesPerChartQ[GetFastStripQueueIndex(i)]);

			DS.SetMaxFiles(CQMBlockServices::GetPenQueueHandle(i, QMC_QUEUE_PEN_SCR_MEDIUM),
					pQInfo->MaxFilesPerChartQ[GetMedStripQueueIndex(i)]);

			DS.SetMaxFiles(CQMBlockServices::GetPenQueueHandle(i, QMC_QUEUE_PEN_SCR_SLOW),
					pQInfo->MaxFilesPerChartQ[GetSlowStripQueueIndex(i)]);

			// circular chart queues
			DS.SetMaxFiles(CQMBlockServices::GetPenQueueHandle(i, QMC_QUEUE_PEN_SCR_CIRC_FAST),
					pQInfo->MaxFilesPerChartQ[GetFastCircularQueueIndex(i)]);
			DS.SetMaxFiles(CQMBlockServices::GetPenQueueHandle(i, QMC_QUEUE_PEN_SCR_CIRC_MEDIUM),
					pQInfo->MaxFilesPerChartQ[GetMedCircularQueueIndex(i)]);
			DS.SetMaxFiles(CQMBlockServices::GetPenQueueHandle(i, QMC_QUEUE_PEN_SCR_CIRC_SLOW),
					pQInfo->MaxFilesPerChartQ[GetSlowCircularQueueIndex(i)]);

			//set the queue thresholds
			if (pQInfo->aLogFast[i]) {
				DS.SetFlushToDiskLimit(i * QMC_TOTAL_NO_OF_QUEUES_PER_PEN, avgThresh);

			} else {
				DS.SetFlushToDiskLimit(i * QMC_TOTAL_NO_OF_QUEUES_PER_PEN, 1); //default. if queue not active quota won't be used
			}

			DS.SetFlushToDiskLimit(CQMBlockServices::GetPenQueueHandle(i, QMC_QUEUE_PEN_SCR_FAST), avgThresh);

			DS.SetFlushToDiskLimit(CQMBlockServices::GetPenQueueHandle(i, QMC_QUEUE_PEN_SCR_MEDIUM), 1);

			DS.SetFlushToDiskLimit(CQMBlockServices::GetPenQueueHandle(i, QMC_QUEUE_PEN_SCR_SLOW), 1);

			DS.SetFlushToDiskLimit(CQMBlockServices::GetPenQueueHandle(i, QMC_QUEUE_PEN_SCR_CIRC_FAST), 1);

			DS.SetFlushToDiskLimit(CQMBlockServices::GetPenQueueHandle(i, QMC_QUEUE_PEN_SCR_CIRC_MEDIUM), 1);

			DS.SetFlushToDiskLimit(CQMBlockServices::GetPenQueueHandle(i, QMC_QUEUE_PEN_SCR_CIRC_SLOW), 1);

		}
		for (i = MESSAGE_LIST_QUEUE_START_ID; i < MESSAGE_LIST_QUEUE_START_ID + MAX_MESSAGE_LISTS; i++) {
			// normalise the message files array and set the max files accordingly
			DS.SetMaxFiles(i, iaMessageFiles[i - (MESSAGE_LIST_QUEUE_START_ID)]);
		}
	}
	delete pQInfo;
	return MAX_VALS_OK;
}

//**********************************************************************
/// Count the nujmber of pens currently logging
/// 
/// @return		USHORT number of pens currently logging 
//**********************************************************************
USHORT CPenManager::NumberOfPensLogging() {
	USHORT penCount = 0;
	CPenControl *pPenCtl;

	// Run through enabled pen list performing a process on all available enabled pens
	for (int loggedPenEntry = 0; loggedPenEntry < m_LoggingPens.GetNumberOfPens(); loggedPenEntry++) {
		pPenCtl = m_LoggingPens.GetEntry(loggedPenEntry);
		if (pPenCtl != NULL) {
			// Check if Pen is running, although enabled may not be running due to incorrect config like maths block failed)
			if (pPenCtl->m_logChannel.IsLogging()) {
				penCount++;
			}
		}
	}
	return penCount;
}

//**********************************************************************
/// Return the current log rate for a given pen
/// 
/// @param[in] penInstance - required pen number (zero based)
///
/// @return		Current log rate in ms tenths
//**********************************************************************
ULONG CPenManager::PenLogRate(USHORT penInstance) {
	ULONG Rate = 0;

	if (m_Pen[penInstance].IsPenRunning()) {
		if (m_Pen[penInstance].m_logChannel.IsEnabled()) {
			///@todo: sort log rate for fuzzy and max-min pens
//			if ( m_Pen[penInstance].m_logChannel.IsContinuous())
//			{
			Rate = m_Pen[penInstance].m_logChannel.CurrentRate();
//			}

		}
	}
	return Rate;
}

//**********************************************************************
/// Return the current effective log rate for a given pen
/// 
/// @param[in] penInstance - required pen number (zero based)
///
/// @return		Current (effective) log rate in Ms tenths, used for data size calculations.
//**********************************************************************
ULONG CPenManager::PenEffectiveLogRate(USHORT penInstance) {
	ULONG Rate = 0;

	if (m_Pen[penInstance].IsPenRunning()) {
		if (m_Pen[penInstance].m_logChannel.IsEnabled()) {
			if (m_Pen[penInstance].m_logChannel.IsFuzzy()) {
				Rate = m_Pen[penInstance].m_logChannel.CurrentRate() * 2;
			} else if (m_Pen[penInstance].m_logChannel.IsMaxMin()) {
				Rate = m_Pen[penInstance].m_logChannel.CurrentRate() / 2;
			} else if (m_Pen[penInstance].m_logChannel.IsContinuous()) {
				Rate = m_Pen[penInstance].m_logChannel.CurrentRate();
			}
		}
	}
	return Rate;
}

//**********************************************************************
/// To be driven by TxShecduler thread the pre trigger data will be processed
/// and written to internal CF
/// 
/// @return		TRUE if successful, FALSE if operation failed
//**********************************************************************
BOOL CPenManager::ProcessPreTriggerFilesForExport() {
	BOOL retVal = FALSE;

	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//for the Scheduler thread
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();

	// Make sure this is not used on pre0trigger in wrong state
	if (GetPreTriggerStatus() == PRE_TRIGGER_READY_FOR_PROCESSING) {
		CPenControl *pPenCtl;
		// Run through pre triggers pens performing a process on all available enabled pens
		for (int PreTriggerPenEntry = 0; PreTriggerPenEntry < m_PreTriggerPens.GetNumberOfPens();
				PreTriggerPenEntry++) {
			if (pThreadInfo != NULL) {
				//Update the thread counter for the Scheduler thread for
				//each iteration
				pThreadInfo->UpdateThreadCounter(AM_TX_SCHEDULER_THREAD);
			}
			pPenCtl = m_PreTriggerPens.GetEntry(PreTriggerPenEntry);
			if (pPenCtl != NULL) {
				// Generate the log output file for NV storage on the CF
				if (pPenCtl->m_preTrigger.GenerateLogFile() == FALSE) {
					// And error occurred, reset the pre-trigger to fire on next run though
					SetPreTriggerStatus(PRE_TRIGGER_READY_FOR_RESTART);
					return retVal;
				}
			}
		}
		// Set the trigger status ready for the files to be exported
		SetPreTriggerStatus(PRE_TRIGGER_READY_FOR_EXPORT);
		retVal = TRUE;
	}
	return retVal;
}

//**********************************************************************
/// Set the status of the pre-trigger, stores into NV
///
/// @param[in]	status - the PreTrigger state machine status of type enum T_PRETRIGGER_STAT
/// 
/// @return		nothing
//**********************************************************************
void CPenManager::SetPreTriggerStatus(T_PRETRIGGER_STAT status) {
	// Set the status
	m_preTriggerStatus.ul = (ULONG) status;

	// Store to NV
	m_pNVStatus->SetToNV(m_preTriggerStatus);
}

//================================================================================================
// CPenList Class
//================================================================================================

//**********************************************************************
///
/// Get the first pen in the list
///
/// @param[in]	pIndex - Index into list, kept as reference for GetFirst GetNext - do not modify
/// @return		Pointer to first CPenControl instance in list
/// 
//**********************************************************************
CPenControl* CPenList::GetFirst(USHORT *pIndex) {
	*pIndex = 0;
	return m_listRef[0];
}

//**********************************************************************
///
/// Get the next pen in the list following index *pIndex
///
/// @param[in]	pIndex - Index next list, kept as reference for GetFirst GetNext - do not modify
/// @return		Pointer to next CPenControl instance in list, NULL if exceeds number of entries
/// 
//**********************************************************************
CPenControl* CPenList::GetNext(USHORT *pIndex) {
	CPenControl *pPenCtrl = NULL;
	(*pIndex)++;
	if (*pIndex < m_NumEntries) {
		// Get next available pen number and move index onto next entry
		pPenCtrl = m_listRef[*pIndex];
	}
	return pPenCtrl;
}

//**********************************************************************
///
/// Reset the index list
///
/// @return		nothing
/// 
//**********************************************************************
void CPenList::ResetList() {
	for (int entry = 0; entry < V6_MAX_PENS; entry++) {
		m_listRef[entry] = NULL;
	}
	m_NumEntries = 0;
}

//**********************************************************************
///
/// Add penNumber to next entry in list
///
/// @param[in]	pPenCtrl - ptr to CPenControl Instance to add to the list
/// @return		current number of entries in list
/// 
//**********************************************************************
short CPenList::AddPenToList(CPenControl *pPenCtrl) {
	if (m_NumEntries < V6_MAX_PENS) {
		m_listRef[m_NumEntries++] = pPenCtrl;
	}
	return m_NumEntries;
}

//**********************************************************************
///
/// Process Real Time Data
///
/// @return		T_PENMANAGER_RETURN 
/// 
//**********************************************************************
void CPenManager::SetRealTimeData(BOOL bIsRealTimeData, int clientId, RLOGCONFIGSTRUCT *rLogConfigStruct) {
#ifdef UNDER_CE
 m_clientId = clientId;
 m_pLogConfigStruct = rLogConfigStruct;
  
 EnterCriticalSection( &m_RTDataCS );
 
 //First check if the configuration already exists in the map.
 //If yes then the client intends to overwrite the existing configuration.

 LOGCONFIGMAP::iterator logConfigMapItr = m_logConfigMap.find(clientId);

 if(logConfigMapItr != m_logConfigMap.end())
 {
 delete logConfigMapItr->second;
	 m_logConfigMap.erase(logConfigMapItr);
	 SetFreeRTDataStruct(clientId);
 }
 
 LOGRATEMAP::iterator logRateMapItr = m_logRateMap.find(clientId);
 if(logRateMapItr != m_logRateMap.end())
 {
  delete[] logRateMapItr->second;
	m_logRateMap.erase(logRateMapItr);
 }

 //Push the configuration for each client in list
 m_logConfigMap[clientId] = rLogConfigStruct; 

 LeaveCriticalSection( &m_RTDataCS );

 CPenControl *pPenCtl;
 
 int enabledPens = m_EnabledPens.GetNumberOfPens();
 int numPensConfigured = rLogConfigStruct->penCount;
 m_LogRateControl = new CLogRateControl[numPensConfigured]; 
 int logRateIndex = 0;

 //Run through enabled pen list and loading the logging configuration for all the pens
 for( int penCount=0; penCount < enabledPens; penCount++ )
 { 
	pPenCtl = m_EnabledPens.GetEntry( penCount );

	if( pPenCtl != NULL )
	{
		//Check if Pen is running, although enabled may not be running due to incorrect config like maths block failed)
		if( pPenCtl->IsPenRunning())
		{
			if( m_pLogConfigStruct->penNo[penCount] == penCount+1)
			{
				if(logRateIndex < numPensConfigured)
				{
				 m_LogRateControl[logRateIndex].SetPenConfigNumber( m_pLogConfigStruct->penNo[penCount]);
				 m_LogRateControl[logRateIndex].ChangeRate(m_pLogConfigStruct->logRate[penCount],m_pLogConfigStruct->logUnits[penCount]); 
				 m_LogRateControl[logRateIndex].SetLogFirstTime(TRUE); 
				 logRateIndex++;
				}
			}
		}
	 }
 }



 EnterCriticalSection( &m_RTDataCS );
 m_logRateMap.insert(LOGRATEMAP::value_type(clientId,m_LogRateControl));
 LeaveCriticalSection( &m_RTDataCS );

  //Set the flag to log real-time data to true
  m_bRealTimeData = bIsRealTimeData;

 #endif

} //end IsRealTimeData()

//**********************************************************************
///
/// GetRealTimeData
///
/// @return		T_PENMANAGER_RETURN 
/// 
//**********************************************************************
BOOL CPenManager::IsRealTimeData() {
	return m_bRealTimeData;

} //end GetRealTimeData()

//**********************************************************************
///
/// Process Real Time Data
///
/// @return		T_PENMANAGER_RETURN 
/// 
//**********************************************************************
T_PENMANAGER_RETURN CPenManager::ProcessRealTimeData() {
	T_PENMANAGER_RETURN retVal = PENMANAGER_OK;

#ifdef UNDER_CE	 
	CPenControl *pPenCtl = NULL;
	//Get the total number of enabled pens
	int enabledPens = m_EnabledPens.GetNumberOfPens();
	LOGCONFIGMAP::iterator logConfigMapItr;
	
	//Run through enabled pen list performing a process on all available enabled pens
	for( int penCount=0; penCount < enabledPens; penCount++ )
	{
		pPenCtl = m_EnabledPens.GetEntry( penCount );

		if( pPenCtl != NULL )
		{
		  //Check if Pen is running, although enabled may not be running due to incorrect config like maths block failed)
			if( pPenCtl->IsPenRunning() )
			{
				logConfigMapItr = m_logConfigMap.begin();

				while(logConfigMapItr != m_logConfigMap.end())
				{
					//Add the real time data to the pen list depending on
					//the log rate for the subscribed pen		
					if((logConfigMapItr->second)->penNo[penCount] == penCount+1)
					{	
						//indexOf the lograte control for the corresponding client.
						AddRealTimeData(penCount,(logConfigMapItr->second)->subscribe[penCount],logConfigMapItr->first);
					 }
					 logConfigMapItr++;
				}
			}
		}

	}
 
	logConfigMapItr = m_logConfigMap.begin();	
	
	while(logConfigMapItr != m_logConfigMap.end())
	{
		//If value is updated then add it to the map 
		if(m_bIsUpdate[logConfigMapItr->first])
		{
			RTDATASTRUCT rtDataStruct = m_rtDataStruct[logConfigMapItr->first];

			//Maximum queue limit has been reached.Maybe the client has not polled for
			//the realtime data.Hence we clear the vector
			if(m_rtDataStructList[logConfigMapItr->first].size() >= MAX_REALTIME_VECTOR_SIZE)
			{
				m_rtDataStructList[logConfigMapItr->first].clear();
			}
			//Add the struct to the list
			m_rtDataStructList[logConfigMapItr->first].push_back(rtDataStruct);
			m_rtDataStructMap.insert(RTDATASTRUCTMAP::value_type(logConfigMapItr->first,m_rtDataStructList[logConfigMapItr->first]));
			//Set the event that the realtime data is available in the map
			SetEvent(m_hRealTimeDataEvent[logConfigMapItr->first]);
			m_bIsUpdate[logConfigMapItr->first] = FALSE;
		}
		logConfigMapItr++;
	}

	


 #endif
	return retVal;

} //end ProcessRealTimeData()

//****************************************************************************************
///
/// AddRealTimeData()
///
/// @return		T_PENMANAGER_RETURN 
/// 
//*****************************************************************************************
T_PENMANAGER_RETURN CPenManager::AddRealTimeData(int penCount, int subscribe, int clientId) {
	T_PENMANAGER_RETURN retVal = PENMANAGER_OK;

#ifdef UNDER_CE	

	EnterCriticalSection( &m_RTDataCS );

	LOGCONFIGMAP::iterator logConfigMapItr = m_logConfigMap.find(clientId);
	RLOGCONFIGSTRUCT* rtlogConfigStruct = logConfigMapItr->second;
	int configPenCnt = 0;

	if(rtlogConfigStruct != NULL)
		configPenCnt = rtlogConfigStruct->penCount;

  //indexOf the lograte control for the corresponding client.
	LOGRATEMAP::iterator logMapItr = m_logRateMap.find(clientId);

	if(logMapItr != m_logRateMap.end())
	{
		int logRateIndex = 0;
		bool bLongIndexFound = false;

		while(logRateIndex < configPenCnt)
		{
			if(logMapItr->second[logRateIndex].GetConfigPenNumber() == penCount+1)
			{
				bLongIndexFound =true;
				break;
			}
			logRateIndex++;
		}

		LeaveCriticalSection( &m_RTDataCS );

		//Check if the reading should be logged.
		if((bLongIndexFound && logMapItr->second[logRateIndex].LogReading() == TRUE)||
		  (logMapItr->second[logRateIndex].IsLogFirstTime() == TRUE))
		{

			//If the subscription is SAMPLE
			if(subscribe == SAMPLE)
			{
				CDataItem* pDataItem = (CDataItemMaxMinAve *)pGlbDIT->GetDataItemPtr( DI_PEN,0,penCount );
				float val = pDataItem->GetFPValue();
				LONGLONG timeStamp = pDataItem->GetTimeuS();
				m_rtDataStruct[clientId].id[penCount] = penCount+1;
				m_rtDataStruct[clientId].val[penCount] = val;
				m_rtDataStruct[clientId].avgTimestamp[penCount] = timeStamp;
				m_bIsUpdate[clientId] = TRUE;
			}	
			//If the subscription is MAX MIN
			else if(subscribe == MAXMIN)
			{
				//Get the Maximum value from the DIT
				CDataItemMaxMinAve* m_pMaxDataItem = (CDataItemMaxMinAve *)pGlbDIT->GetDataItemPtr( DI_MMA, DI_MMA_MAX_USER, penCount );
				float maxVal = m_pMaxDataItem->GetFPValue();
				LONGLONG maxtimeStamp = m_pMaxDataItem->GetTimeuS();

				//Get the Minimum value from the DIT
				CDataItemMaxMinAve* m_pMinDataItem = (CDataItemMaxMinAve *)pGlbDIT->GetDataItemPtr( DI_MMA, DI_MMA_MIN_USER, penCount );
				float minVal = m_pMinDataItem->GetFPValue();
				LONGLONG mintimeStamp = m_pMinDataItem->GetTimeuS();				
				m_rtDataStruct[clientId].id[penCount] = penCount+1;
				m_rtDataStruct[clientId].max[penCount] = maxVal;
				m_rtDataStruct[clientId].min[penCount] = minVal;
				m_rtDataStruct[clientId].maxTimestamp[penCount] = maxtimeStamp;
				m_rtDataStruct[clientId].minTimestamp[penCount] = mintimeStamp;
				m_bIsUpdate[clientId] = TRUE;
			}
			//If the subscription is AVERAGE
			else if(subscribe == AVERAGE)
			{
				//Get the average value from the DIT
				CDataItemMaxMinAve* pDataItem = (CDataItemMaxMinAve *)pGlbDIT->GetDataItemPtr( DI_MMA, DI_MMA_AVE_USER, penCount );
				float avgVal = pDataItem->GetFPValue();
				LONGLONG avgtimeStamp = pDataItem->GetTimeuS();
				m_rtDataStruct[clientId].id[penCount] = penCount+1;
				m_rtDataStruct[clientId].val[penCount] = avgVal;
				m_rtDataStruct[clientId].avgTimestamp[penCount] = avgtimeStamp;	
				m_bIsUpdate[clientId] = TRUE;
			}
			EnterCriticalSection( &m_RTDataCS );

  		logMapItr->second[logRateIndex].SetLogFirstTime(FALSE);
	
			LeaveCriticalSection( &m_RTDataCS );
		}
	}

  #endif

	return retVal;

} //end AddRealTimeData()

//******************************************************************************************
///
/// SetFreeRTDataStruct
///
/// @return		void
/// 
//******************************************************************************************
void CPenManager::SetFreeRTDataStruct(int clientId) {
#ifdef UNDER_CE	 
 EnterCriticalSection( &m_RTDataCS );

 RTDATASTRUCTMAP::iterator rtDataStructMapItr = m_rtDataStructMap.find(clientId); 
 if(rtDataStructMapItr != m_rtDataStructMap.end())
 {
	 m_rtDataStructList[clientId].clear(); 
	 m_rtDataStructMap.erase(rtDataStructMapItr);		
 }	

 //Reinitialise the structure 
 memset(&m_rtDataStruct[clientId],0.0,sizeof(RTDATASTRUCT));

 LeaveCriticalSection( &m_RTDataCS );
#endif

} //end SetFreeRTDataStruct()

//******************************************************************************************
///
/// ClearRateConfigList
///
/// @return		void
/// 
//******************************************************************************************
void CPenManager::ClearRateConfigList(int clientId) {
#ifdef UNDER_CE	 
	EnterCriticalSection( &m_RTDataCS );

	LOGCONFIGMAP::iterator rtLOGCONFIGMapItr = m_logConfigMap.find(clientId); 
	
	if(rtLOGCONFIGMapItr != m_logConfigMap.end())
	{
 delete rtLOGCONFIGMapItr->second; 
	 m_logConfigMap.erase(rtLOGCONFIGMapItr);
	}	
 
	LOGRATEMAP::iterator rtLOGRATEMapItr = m_logRateMap.find(clientId);

	if(rtLOGRATEMapItr != m_logRateMap.end())
	{
		delete[] rtLOGRATEMapItr->second;
		m_logRateMap.erase(rtLOGRATEMapItr);
	}
	
	LeaveCriticalSection( &m_RTDataCS );
#endif

} //end ClearConfigList()

//******************************************************************************************
///
/// GetRealTimeData
///
/// @return		QList - List containing pen values
/// 
//******************************************************************************************
RTDATASTRUCTMAP CPenManager::GetRealTimeData() {
	return m_rtDataStructMap;

} //end GetRealTimeData()

//******************************************************************************************
///
/// SetSocketConnected
///
/// @return		void
/// 
//******************************************************************************************
void CPenManager::SetSocketConnected(int clientId, BOOL bIsSocketConnected) {
	if (!bIsSocketConnected) {
		//Clear the configuration for the client
		//as the socket connection is disconnected
		ClearRateConfigList(clientId);
		//Free the RTData from the struct for the
		//corresponding client
		SetFreeRTDataStruct(clientId);
		//Erase the client no from the vector
		if (m_socketConnVec.size() > 0) {
			m_socketConnVec.erase(m_socketConnVec.begin() + clientId);
		}
	} else {
		m_socketConnVec.push_back(clientId);
	}

}		//end SetSocketConnected()

//******************************************************************************************
///
/// IsSocketConnectionExist
///
/// @return		BOOL - TRUE if atleast one socket connection exists
/// 
//******************************************************************************************
BOOL CPenManager::IsSocketConnectionExist() {
	BOOL bIsSocketConnectionExist = FALSE;

	if (m_socketConnVec.size() > 0) {
		bIsSocketConnectionExist = TRUE;
	}
	return bIsSocketConnectionExist;

}		//end IsSocketConnectionExist()

//******************************************************************************************
///
/// IsRTConfigExist
///
/// @return		BOOL - TRUE if atleast one configuration exists
/// 
//******************************************************************************************
BOOL CPenManager::IsRTConfigExist() {
	BOOL bIsRTConfigExist = FALSE;

	//Map contains configuration so we have a
	//client who is active
	if (m_logConfigMap.size() > 0)
		bIsRTConfigExist = TRUE;

	return bIsRTConfigExist;

}  //end IsRTConfigExist()

//******************************************************************************************
///
/// IsConnectionAlive
///
/// @return		BOOL - TRUE is socket connection for corresponding client exists
/// 
//******************************************************************************************
BOOL CPenManager::IsConnectionAlive(int clientId) {
	BOOL bIsConnectionAlive = FALSE;

#ifdef UNDER_CE	
	EnterCriticalSection( &m_RTDataCS );

	LOGCONFIGMAP::iterator rtLOGCONFIGMapItr = m_logConfigMap.find(clientId); 

	//Socket connection for the corresponding client Id 
	//is alive as the configuration still exists in the map
	if(rtLOGCONFIGMapItr != m_logConfigMap.end())
	  bIsConnectionAlive = TRUE;

	LeaveCriticalSection( &m_RTDataCS );

#endif
	return bIsConnectionAlive;

}	//end IsConnectionAlive()

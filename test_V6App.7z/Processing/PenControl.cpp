/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Processing
/// @n Filename: PenControl.cpp
/// @n Desc:	 Manage all aspects of a Pen within the system
///				 
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  88  Stability Project 1.83.1.3 7/2/2011 4:59:39 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  87  Stability Project 1.83.1.2 7/1/2011 4:38:36 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  86  Stability Project 1.83.1.1 3/17/2011 3:20:33 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  85  Stability Project 1.83.1.0 2/15/2011 3:03:39 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// ****************************************************************

#include "ppl.h"
#include "V6globals.h"
#include "PenControl.h"
#include "TraceDefines.h"
#include "RecSetupCfgMgr.h"
#include "V6AppInterface.h"
#include "PenManager.h"

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif

CChartQManager *CPenControl::m_pChartQManager = NULL;

char DefaultScript[] = "return 12.45";			// Default script, used if scripot block in CMM does not exist.

//**********************************************************************
/// CPenControl constructor
///
//**********************************************************************
CPenControl::CPenControl() {
	SetPenConfigPtr((T_PPEN) NULL);
	m_PenValueChanged = FALSE;
	m_PenRunning = FALSE;
	m_penRate = DEFAULT_PEN_RATE;
	m_penRateCounterReload = PEN_EXECUTE_ON_FIRST_PROCESS;
	m_penRateCounter = PEN_EXECUTE_ON_FIRST_PROCESS;
	m_ProcessAlarm = FALSE;
	m_modeRequest = LOGGING_MODE_UNCHANGED;
	m_previousPenTag[0] = 0;
	m_firstRun = TRUE;

	m_TriggerTimeChangeInScript = FALSE;
	if (m_pChartQManager == NULL) {
		m_pChartQManager = CChartQManager::GetHandle();	// Get handle on singleton
	}
	previousGroupNumberOPC = GROUP_CACHE_FIRST_USE;

	m_ravSampleCountDown = 0;

	m_resetHourReport = FALSE;
	m_resetDayReport = FALSE;
	m_resetWeekReport = FALSE;
	m_resetMonthReport = FALSE;

}

//**********************************************************************
/// Recovery after a power failure
///
/// @param[in]		m_pQM pointer to the data queue manager object
/// @param[in]		dataQueue - pointer to queue block manager object
/// @param[in]		Instance zero based data source instance
///
/// @return T_PEN_CONTROL_RETURN as result of function
///
/// @note Power recovery is performed for all pens before configuration
//**********************************************************************
/*T_PEN_CONTROL_RETURN CPenControl::PowerRecovery( CQueueManager *pQM, CQMMemoryBlock *dataQueue, USHORT Instance )
 {
 m_logChannel.PowerRecovery( pQM, dataQueue, Instance );

 return PEN_OKAY;
 }*/

//**********************************************************************
/// Perform Pen initialisation
///
/// @return T_PEN_CONTROL_RETURN as result of function
///
//**********************************************************************
T_PEN_CONTROL_RETURN CPenControl::Initialise(T_PEN_REPORT *pReportNV) {
	T_PEN_CONTROL_RETURN penConfigRet = PEN_OKAY;

	// Assign NV area for pen report
	m_pReport = pReportNV;

	// Handle on Pen Manager
	m_pPenManager = CPenManager::GetHandle();

	// Initialise the Max Min for the Pen
	m_MaxMin.IntialiseMaxMin(m_Instance);

	// Initialise the totaliser for the Pen
	m_totaliser.IntialiseTotal(m_Instance, m_pReport);

	// Init pre-triggering
	m_preTrigger.m_Enabled = FALSE;

	// Run through each alarm for a Pen and perfrom it's initialisation
	for (int alarmNumber = 0; alarmNumber < V6_MAX_ALARMS; alarmNumber++) {
		CAlarm *pkAlarm = GetAlarmPtr(alarmNumber);
		if (pkAlarm != NULL) {
			if (pkAlarm->IntialiseAlarm(m_Instance, alarmNumber, this) != RET_ALARM_OKAY) {
				penConfigRet = PEN_INIT_FAILED;		// Alarm failed to initialise
				break;
			}
		} else {
			penConfigRet = PEN_INIT_FAILED;		// Alarm failed to initialise
			break;
		}
	}
	return penConfigRet;
}

//**********************************************************************
/// Perform any Pen Control based cleanup
///
/// @return nothing
///
//**********************************************************************
void CPenControl::CleanUp() {
	m_Script.Cleanup();				// De-allocate script working memory
	m_ravProcess.CleanPipe();		// De-Allocate any RAV working memory
	m_preTrigger.CleanUp();			// De-Allocate pre-trigger working memory
}

//**********************************************************************
/// Set-up Pen from the configuration, this can be from start-up or
/// after a configuration change
///
/// @return T_PEN_CONTROL_RETURN as result of function
///
//**********************************************************************
T_PEN_CONTROL_RETURN CPenControl::SetPenFromConfig() {
	T_PEN_CONTROL_RETURN penConfigRet = PEN_OKAY;

	// Get the config block for a Pen from the CMM
	m_pConfig = pSETUP->GetPenSetupConfig()->GetPen(m_Instance, ZERO_BASED, CONFIG_COMMITTED);

	// If no pen block exists , set it to the dummy pen block
	if (m_pConfig == NULL) {
		m_pConfig = pSETUP->GetPenSetupConfig()->GetDummyPen();
		///@todo this maybe an error condition, pen must have a config block
		///or we may create one at this point.
	}

	// Pick up the Pen's Data Item entry
	m_pPenDataItem = (CDataItemPen*) pGlbDIT->GetDataItemPtr(DI_PEN, 0, m_Instance);
	if (m_pPenDataItem == NULL) {
		///@todo this is an error condition, there will always be a Data Item for a Pen
		V6CriticalMessageBox(NULL, L"m_pPenDataItem == NULL", L"Pen Config Failed",
				MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST);
		penConfigRet = PEN_CONFIG_FAILED;
	}

	// Only if Pen is enabled do we need to setup the data access
	if (m_pConfig->Enabled == TRUE) {
		// Assume that the maths block will not be a direct variable assignment until proven otherwise
		m_UseDirect = FALSE;
		// Check if we are using a straight maths block, if so there maybe no need for Maths i.e. P1=A1 so we can
		// save time by providing a direct lookup
		if (m_pConfig->MathType == MATH_TYPE_BLOCK) {
			// It's a maths block and length is within the single variables limits
			if (strlen(m_pConfig->MathsBlock) < MAX_VARNAME_LEN) {
				// Attempt Locate Variable in DIT by variable name
				int directDITVariableRef = LookUpRefForDITByVarname(m_pConfig->MathsBlock);
				if (directDITVariableRef != REF_ERROR) {
					// Direct Variable match, so setup direct ptr access into DIT, required for speed
					m_UseDirect = TRUE;
					m_pDirectVar = pGlbDIT->GetDataItemPtr(directDITVariableRef);
				}
			}
		}
		// If the reference wasn't resolved as a single variable (direct) use the script services as it should be a maths block or script
		if (m_UseDirect == FALSE) {
			// Setup a pointer to the source of the script, either a single maths block in T_PEN or a script in the variable sized block
			char *scriptSourcePtr;
			if (m_pConfig->MathType == MATH_TYPE_BLOCK) {
				// Assign Math block as source
				scriptSourcePtr = m_pConfig->MathsBlock;
			} else {
				// Get variable length script block from CMM
				scriptSourcePtr = pSETUP->GetPenSetupConfig()->GetPenScriptBlock(m_Instance, ZERO_BASED,
						CONFIG_COMMITTED);
				if (scriptSourcePtr == NULL) {
					// Script block in CMM does not exist, use default
					scriptSourcePtr = DefaultScript;
				}
			}
			// Build the Auto script, if changed then we need to compile the new script
			if (m_Script.BuildAutoScript(scriptSourcePtr, static_cast<T_MATH_TYPE>(m_pConfig->MathType),
					static_cast<T_SCRIPT_IDENT>(SCRIPT_PEN_FIRST + m_Instance)) == TRUE) {
				// Script has changed, compile the new script
				V6ERRORINFO *scriptErr = m_Script.CompileScript(TRUE);	// Compile script, without error popups.
				if (scriptErr->Code != V6_E_SUCCESS) {
					penConfigRet = PEN_MATH_SCRIPTERR;
				}
			}
			m_Script.SetSetupChangedFlag( TRUE);		// Indicate a setup change for scripts
		}

		// Setup the Max Min for a configuration change
		m_MaxMin.SetMaxMinFromConfig(m_pConfig);

		// Setup the totaliser for a configuration change.
		m_totaliser.SetTotalFromConfig(m_pConfig, pGlbSysTimer->GetCurrentProcessInterval());

		// If the Group number for a Pen has chnaged over config, notify the OPC A&E server
		if (previousGroupNumberOPC != m_pConfig->GroupNumber) {
			//CRequestObject::UpdateOPCGroupConfig();
			UpdateOPCConfig();
			previousGroupNumberOPC = m_pConfig->GroupNumber;
		}
		// Check if report is invalid
		if (m_pReport->set[WORKING_REPORT].period[RP_HOUR].startTD == 0) {
			wipeReport();
		}
	} else {
		// Pen is not enabled, so erase any report information
		wipeReport();
	}

	if (m_pConfig->Enabled == TRUE && m_pConfig->RAV.Enabled == TRUE) {
		// Setup RAV
		m_ravRunning = TRUE;
		m_ravProcess.CreatePipe(PIPE_RAV, m_pConfig->RAV.NoOfSamples, static_cast<BOOL>(m_pConfig->RAV.Prefill));
		m_ravAverage.ResetAverage();
	} else {
		// RAV is not running make sure the Pipe is clean and no memory allocated
		m_ravRunning = FALSE;
		m_ravProcess.CleanPipe();
	}
	m_ravSampleCountDown = 0;

	// Run through all alarms and call the configuration method, even if pen is not enabled (will tidy up any orphaned alarms)
	for (int alarmNumber = 0; alarmNumber < V6_MAX_ALARMS; alarmNumber++) {
		if (GetAlarmPtr(alarmNumber)->SetAlarmFromConfig(m_pConfig) != RET_ALARM_OKAY) {
			penConfigRet = PEN_CONFIG_FAILED;
			break;
		}
	}
	ClearAlarmStatus(); //Clear alarm summary for pen, even for disabled pens.

	// If the Pen is enabled and the configuration is successful, enable pen to run
	if (penConfigRet == PEN_OKAY && m_pConfig->Enabled == TRUE) {
		m_PenRunning = TRUE;	// Pen configuraed and okay to be processed
	} else {
		m_PenRunning = FALSE;	// Pen disabled or configuration failed, so don't process
	}

	m_ProcessAlarm = FALSE;		// Don't process alarms until pen has been processed
	m_ForceUpdate = TRUE;		// Force a pen update as scales or other limits might change
	ManageChartQueues();		// Create, or delete chart queues as required

	// Check if Pen tag has changed over setup, if so notify OPC A&E
	if (wcscmp(m_previousPenTag, m_pConfig->Tag) != 0) {
		//CRequestObject::UpdateOPCPenConfig(m_Instance);	// Notify OPC Server
		RequestObjectUpdateOPCPenConfig(m_Instance);
		wcscpy_s(m_previousPenTag, sizeof(m_previousPenTag) / sizeof(WCHAR), m_pConfig->Tag);// Update tag for comparison on next config change
	}

	// Pre Trigger Configuration
	m_preTrigger.CleanUp();
	m_preTrigger.m_Enabled = FALSE;
	m_preTrigger.m_penNumber = m_Instance;

	if (m_PenRunning == TRUE && m_pConfig->PenLog.PretriggerEn == TRUE) {
		// If the pen is enabled and pre-trigger is also selected in the config, set up the pre-trigger
		// However, for pre-trigger to be available the Pen logging must be running AND logging set to continuous
		if (m_pConfig->PenLog.Enabled == TRUE && m_pConfig->PenLog.LogType == LOGTYPE_CONTINUOUS
				&& m_pConfig->PenLog.LogStyle == LOGSTYLE_SAMPLE) {
			ULONG alarmRate = CLogRec::GetAlarmLogRate(m_pConfig->PenLog);

			// If alarm log rate is too slow, pre trigger is not enabled
			if (alarmRate <= PRE_TRIGGER_SLOWEST_LOG_RATE) {
				// Allocate the buffer for the pre-trigger readings
				if (m_preTrigger.AllocateBuffer(alarmRate,
				pSYSTEM_INFO->GetProfileConfig()->Logging.PretriggerTime) == TRUE) {
					// Critera met and pre-trigger buffer allocated
					m_preTrigger.m_Enabled = TRUE;
					m_preTrigger.ResetBuffer();
				}
			} else {
				// Log diagnostic warning as to why pre trigger for this pen was not enabled
				QString   diagMess;
				diagMess.asprintf(L"P%d Pre-trigger invalid alarm rate > 10 sec", GetPenInstance() + 1);
				LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, diagMess);
			}
		} else {
			// Log diagnostic warning as to why pre trigger for this pen was not enabled
			QString   diagMess;
			diagMess.asprintf(L"P%d pre-trigger disabled as log type incorrect", GetPenInstance() + 1);
			LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, diagMess);
		}
	}
	return penConfigRet;
}

//***********************************************************************
/// Derive the fastest rate the Pen should run at this will the fastest
/// of the dependent variables in the maths and the log rates
///
/// @param[out]	- returnRate, refernce to the fastest return rate
///
/// @return TRUE if the rate has changed on this pass, otherwise FALSE
//***********************************************************************
BOOL CPenControl::DeriveFastestRate(USHORT &returnRate) {
	BOOL PenRateHasChanged = FALSE;
	USHORT fastestRate = DEFAULT_PEN_RATE;

	// Get the fastetst rate required by the Pen maths
	if (m_UseDirect == TRUE) {
		// Yes, get the rate of the direct variable
		fastestRate = m_pDirectVar->GetRate();
	} else {
		// No, find the fastest rate of all dependents in the script processor
		fastestRate = m_Script.GetFastestDependentRate();
	}
	// Get the fastest rate required by the pen Logging
	if (m_pConfig->PenLog.Enabled) {
		BOOL useAlarmRate = FALSE;
		ULONG logRate = CLogRec::GetLogRate(m_pConfig->PenLog);
		for (int alarmNum = 0; alarmNum < V6_MAX_ALARMS; alarmNum++) {
			// If alarm is enabled and set to change rate on alarm, may be the faster rate
			if ((m_pConfig->Alm[alarmNum].EnableType != ALARM_DISABLED && m_pConfig->Alm[alarmNum].ChangeLog == TRUE)
					|| (m_preTrigger.m_Enabled == TRUE))// If pre-trigger enabled then alarm rate needs to be included even if no alarm is enabled for this pen
					{
				// Use if this is the faster rate
				const ULONG ulALARM_LOG_RATE = CLogRec::GetAlarmLogRate(m_pConfig->PenLog);
				if (ulALARM_LOG_RATE < logRate) {
					// Update the logRate to be the alarm rate, we don't need to check any further so break out
					logRate = ulALARM_LOG_RATE;
					break;
				}
			}
		}
		// Convert log rate from millisecond tenths into system ticks
		logRate = logRate / 100;
		if (logRate < fastestRate) {
			// Lograte is faster then current processing rates, so use log rate
			fastestRate = static_cast<USHORT>(logRate);
		}
	}
	if (fastestRate != m_penRate) {
		PenRateHasChanged = TRUE;
		m_penRate = fastestRate;
	}

	m_pPenDataItem->SetRate(m_penRate);		// Update rate in data item table
	returnRate = m_penRate;						// Set rate to return
	return PenRateHasChanged;
}

//***********************************************************************
/// Setup the counters to allow pens to process at the desired rates
/// against the required process interval
///
/// @return Nothing
//***********************************************************************
void CPenControl::SetPenProcessRates() {
	m_penRateCounterReload = static_cast<USHORT>(m_penRate / pSYSTIMER->GetCurrentProcessInterval());
	m_penRateCounter = PEN_EXECUTE_ON_FIRST_PROCESS;

	if (m_penRateCounterReload < PEN_EXECUTE_ON_FIRST_PROCESS) {
		LOG_CRTL( TRACE_ALWAYS, "CPenControl::SetPenProcessRates, RATE INVALID");
	}

	if (m_ravRunning) {
		// Rolling Average is running so setup reload timer
		int ravIntervalPerProcess = ((PROCESS_TICKS_PER_SECOND * m_pConfig->RAV.SampleInterval)
				/ pSYSTIMER->GetCurrentProcessInterval());
		m_ravSampleCountReload = ravIntervalPerProcess / m_penRateCounterReload;
	}
	m_ravSampleCountDown = 0;

	// Setup the pre-trigger processing rates
	if (m_preTrigger.m_Enabled == TRUE) {
		m_preTrigger.m_rateDivDownReload = m_preTrigger.m_alarmRateTicks / pSYSTIMER->GetCurrentProcessInterval();
	}

}

//***********************************************************************
/// Seutp the logging for the pen
///
/// @return Nothing
//***********************************************************************
void CPenControl::ConfigureLoggingForPen() {
	// Setup logging rates depending on new intervals
	m_logChannel.SetConfig(DATATYPE_PEN, GetPenInstance());
}

//***********************************************************************
/// Manage the chart queues for the pen, this will create 
///	or delete queues as required.
///
/// @return T_PEN_CONTROL_RETURN as result of function
//***********************************************************************
T_PEN_CONTROL_RETURN CPenControl::ManageChartQueues() {
	T_PEN_CONTROL_RETURN penCQRet = PEN_OKAY;

	if (m_pConfig->Enabled == TRUE) {
		// add the SRAM queues only. (volatile queues will be added during chart reconfigure)
		m_pChartQManager->AddStripChartQ(m_Instance, SPEED_FAST, TRUE);
		m_pChartQManager->AddStripChartQ(m_Instance, SPEED_MEDIUM, TRUE);
		m_pChartQManager->AddStripChartQ(m_Instance, SPEED_SLOW, TRUE);

		// check if circular chart mode is available
		if ( DEVICE_INFO.IsCircularChartModeAvailable()) {
			m_pChartQManager->AddCircularChartQ(m_Instance, SPEED_FAST, TRUE);
			m_pChartQManager->AddCircularChartQ(m_Instance, SPEED_MEDIUM, TRUE);
			m_pChartQManager->AddCircularChartQ(m_Instance, SPEED_SLOW, TRUE);
		} else {
			// circular chart mode is not available so ensure the queues are deleted to save
			// memory
			m_pChartQManager->DeleteCircularChartQ(m_Instance, SPEED_FAST, TRUE);
			m_pChartQManager->DeleteCircularChartQ(m_Instance, SPEED_MEDIUM, TRUE);
			m_pChartQManager->DeleteCircularChartQ(m_Instance, SPEED_SLOW, TRUE);

			m_pChartQManager->DeleteCircularChartQ(m_Instance, SPEED_FAST);
			m_pChartQManager->DeleteCircularChartQ(m_Instance, SPEED_MEDIUM);
			m_pChartQManager->DeleteCircularChartQ(m_Instance, SPEED_SLOW);
		}
	} else {
		m_pChartQManager->DeleteStripChartQ(m_Instance, SPEED_FAST, TRUE);
		m_pChartQManager->DeleteStripChartQ(m_Instance, SPEED_MEDIUM, TRUE);
		m_pChartQManager->DeleteStripChartQ(m_Instance, SPEED_SLOW, TRUE);

		m_pChartQManager->DeleteStripChartQ(m_Instance, SPEED_FAST);
		m_pChartQManager->DeleteStripChartQ(m_Instance, SPEED_MEDIUM);
		m_pChartQManager->DeleteStripChartQ(m_Instance, SPEED_SLOW);

		m_pChartQManager->DeleteCircularChartQ(m_Instance, SPEED_FAST, TRUE);
		m_pChartQManager->DeleteCircularChartQ(m_Instance, SPEED_MEDIUM, TRUE);
		m_pChartQManager->DeleteCircularChartQ(m_Instance, SPEED_SLOW, TRUE);

		m_pChartQManager->DeleteCircularChartQ(m_Instance, SPEED_FAST);
		m_pChartQManager->DeleteCircularChartQ(m_Instance, SPEED_MEDIUM);
		m_pChartQManager->DeleteCircularChartQ(m_Instance, SPEED_SLOW);
	}

	return penCQRet;
}

//***********************************************************************
/// Process the Pen maths for a Pen, this will execute the script OR 
/// perform a direct lookup into the DIT on another variable
///
/// @param[in] - processTime, real-time of this processing slice
///
/// @return T_PEN_CONTROL_RETURN as result of function
/// 
/// @note before calling check that the Pen is running with IsPenRunning()
//***********************************************************************
T_PEN_CONTROL_RETURN CPenControl::ProcessPenMaths() {
	T_PEN_CONTROL_RETURN penMathRet = PEN_OKAY;

	// Check if a time change has occurred, if so set notify script flag
	if ( pSYSTIMER->HasTimeChangeOccured()) {
		m_TriggerTimeChangeInScript = TRUE;		// Trigger time change on next script process
	}

	// Check if a report rollover has occurred
	CheckReportRollover();

	// Pen may be slower the core process rate, so is devided down using counter
	// if 0 or less then pen is processed
	if (--m_penRateCounter <= 0) {
		BOOL statusHasChanged = FALSE;

		m_ProcessAlarm = TRUE;		// Pen is being process , so need to process alarms downstream

		m_penRateCounter = m_penRateCounterReload;	// Reload pen process devisor

		float newValue = 0;
		T_DATAITEM_STATUS newStatus = DISTAT_NORMAL;

		// If this is a direct variable, then copy straight from Data Item Table
		// Otherwise process the maths script
		if (m_UseDirect == TRUE) {
			newValue = m_pDirectVar->GetFPValue();		// Reading direct from Data Item table
			newStatus = m_pDirectVar->GetStatus();		// Status directly from sourdce variable of Data Item
		} else {
			// If time changed after last process, set the TIMECHANGED flasg for scripting
			if (m_TriggerTimeChangeInScript == TRUE) {
				m_TriggerTimeChangeInScript = FALSE;
				m_Script.SetTimeChangedFlag( TRUE);
			}

			// Process Maths Script/Block
			V6ERRORINFO *m_scriptErr = m_Script.RunScript(newValue);
			if (m_scriptErr->Code != V6_E_SUCCESS) {
				// Script execution caused error, so warn user and set pen so it won't run again until another commit 
				QString   strasprintfString("");
				QString   strMessage("");
				QString   strTitle("");
				strasprintfString = tr("Due to error Pen %d will not be run, please go to config and correct error");
				strMessage.asprintf(strasprintfString, m_Instance + 1);
				strTitle = tr("Error");
				CV6MessageBoxDlg kErrDialog(strTitle, strMessage, NULL);
				kErrDialog.exec();
				SetPenRunningState( FALSE);	// Stop pen running until script corrected
			}
			// if an errorcode is returned from function, display as invalid reading
			UINT errorTest = *(reinterpret_cast<const UINT*>(&newValue)); // cast float to UINT.
			// Test the exponent to see if code is NAN
			if ((errorTest & NAN_TEST_VALUE) == NAN_TEST_VALUE) {
				newStatus = DISTAT_INVALID;
				newValue = -FLT_MAX; // set max negative for invalid - most natural value to use, puts trace at bottom of chart
			} else {
				if (newValue == FLT_MAX)				// show FLT_MAX as up arrows
				{
					newStatus = DISTAT_INPUT_OVERRANGE;
				} else if (newValue == -FLT_MAX)			// show -FLT_MAX as down arrows
				{
					newStatus = DISTAT_INVALID; //treat -FLT_MAX as an error condition and show 'stars' in DPM
				} else {
					newStatus = DISTAT_NORMAL;
				}
			}
			m_Script.SetSetupChangedFlag( FALSE);		// Clear the setup changed flag within scripts
			m_Script.SetTimeChangedFlag( FALSE);		// Clear the time changed flag within scripts
		}

		// Apply post processing rolling average if enabled
		if (m_ravRunning) {
			if ((newStatus >= DISTAT_NORMAL) && (newValue != FLT_MAX) && (newValue != -FLT_MAX)) {
				m_ravAverage.DoAverageForReading(newValue);
				if (--m_ravSampleCountDown <= 0) {
					// Time to load average, reset sample average and reset countdown timer
					float newReading = m_ravAverage.GetAverage();
					currentRAVValue = m_ravProcess.AddReadingAndGetResult(newReading);
					m_ravAverage.ResetAverage();
					m_ravSampleCountDown = m_ravSampleCountReload;
				}
				newValue = currentRAVValue;
			} else {
				m_ravAverage.ResetAverage();
				m_ravProcess.ResetPipe();
			}
		}
		BOOL statusHasChangedfromInvalidToValid = FALSE;
		if ((newStatus != m_pPenDataItem->GetStatus()) && (newStatus >= DISTAT_NORMAL)
				&& (m_pPenDataItem->GetStatus() < DISTAT_NORMAL) && (m_firstRun == FALSE)) {
			statusHasChangedfromInvalidToValid = TRUE;
		}
		m_firstRun = FALSE;
		// Check if the Value or status has changed since the last Pen update, or if an update has been forced (setup changed)
		if ((newValue != m_pPenDataItem->GetFPValue()) || (newStatus != m_pPenDataItem->GetStatus())
				|| (m_ForceUpdate == TRUE)) {
			// if it has store in DIT and update status and time
			m_pPenDataItem->SetStatus(newStatus);		// Set new status of the pen
			m_pPenDataItem->SetValue(newValue);		// Set new value of the Pen 
			m_pPenDataItem->SetTime(pGlbSysTimer->GetCurrentProcessTimeRef());		// Timestamp change		
			m_PenValueChanged = TRUE;
			m_ForceUpdate = FALSE;

			// If value has changed then we always want to process the max mins
			m_MaxMin.DoMaxMin();

			//Set the average for the real-time pen values
			m_rtPenAverage.DoAverageForReading(newValue);
			m_MaxMin.DoAverage(m_rtPenAverage.GetAverage());
			m_rtPenAverage.ResetAverage();

		} else {
			// Reading has not changed this time through, use m_PenValueChanged downstream to reduce processing
			m_PenValueChanged = FALSE;

			// Reading has not changed, but a reset request could be pending
			if (m_MaxMin.GetPendingRequest() != MM_MODE_NORMAL) {
				m_MaxMin.DoMaxMin();	// do max min if not in normal state
			}
		}
		// If reports are available then keep reports updated for pen
		if ( pSYSTEM_INFO->FWOptionReportsAvailable()) {
			UpdatePenReport(newValue, newStatus, statusHasChangedfromInvalidToValid);
		}
	} else {
		// We are not processing the Pen on this time slice, so do not process any dependent alarms either
		m_ProcessAlarm = FALSE;
	}

	return penMathRet;
}

//***********************************************************************
/// Process the pre trigger information
///
/// @return nothing
//***********************************************************************
void CPenControl::ProcessPreTrigger() {
	// Process the pre trigger, this needs to be done independent of the pen rate as they might not be divisable (5hz to 2hz for example)
	if (m_preTrigger.m_Enabled == TRUE) {
		// Check divide down rate
		if (--m_preTrigger.m_rateDivDownCount <= 0) {
			// Time to take a reading, add reading to cyclic buffer and reload timer
			m_preTrigger.AddReading(m_pPenDataItem->GetFPValue(), pSYSTIMER->GetCurrentProcessTimeInMicroSec());
			m_preTrigger.m_rateDivDownCount = m_preTrigger.m_rateDivDownReload;
		}
	}
}

//***********************************************************************
/// Process the Pen logging
///
/// @return T_PEN_CONTROL_RETURN as result of function
/// 
/// @note before calling check that the Pen is running with IsPenRunning()
//***********************************************************************
T_PEN_CONTROL_RETURN CPenControl::ProcessPenLog() {
	T_PEN_CONTROL_RETURN penLogRet = PEN_OKAY;

	if (m_modeRequest != LOGGING_MODE_UNCHANGED) {
		// Yes, perform mode change
		PerformModeChangeAction(m_modeRequest);
		m_modeRequest = LOGGING_MODE_UNCHANGED;		// Mode change has been actioned
	}

	// Check if alarm rate needs to be selected or deelected
	m_logChannel.CheckAndChangeRateIfRequired();

	// Log the reading
	m_logChannel.Reading();

	return penLogRet;
}

//**********************************************************************
/// Perform a mode change on the log channel
/// 
/// @param[in]	mode - T_LOGGING_MODE mode type to perform
///
/// @return		T_PEN_CONTROL_RETURN as status of call
/// 
//**********************************************************************
T_PEN_CONTROL_RETURN CPenControl::PerformModeChangeAction(T_LOGGING_MODE mode) {
	T_PEN_CONTROL_RETURN retVal = PEN_OKAY;

	/// Perform relevant action depending on mode
	switch (mode) {
	case LOGGING_MODE_RESTORE:	// restore pen logging state after a power-cycle
	{
		if (IsPenRunning()) {
			m_logChannel.RestoreNVState(0, pGlbSysInfo->GetSessionNumber());
			m_logChannel.SetReason(RESET_PWRFAIL);
		}
	}
		break;
	case LOGGING_MODE_START:	// Start pen logging
	{
		if (IsPenRunning()) {
			m_logChannel.StartLog(0, pGlbSysInfo->GetSessionNumber());
			m_logChannel.SetReason(START_RECORDING);
		}
	}
		break;
	case LOGGING_MODE_STOP:		// Stop pen logging
	{
		StopPenLoggingDirect(TRUE);
	}
		break;
	case LOGGING_MODE_SHUTDOWN: {
		StopPenLoggingDirect( FALSE);
	}
		break;
	case LOGGING_MODE_FLUSH:	// Flush incomplete log block
	{
		if (IsPenRunning())
			m_logChannel.FlushData();
	}
		break;
	default: {
		qDebug("Unknown or unhandled T_LOGGING_MODE %d \n", mode);
		m_modeRequest = LOGGING_MODE_UNCHANGED;
	}
		break;
	}
	return retVal;
}

//**********************************************************************
/// Stop the pen logging directly
///
/// @return		T_PEN_CONTROL_RETURN as status of call
//**********************************************************************
void CPenControl::StopPenLoggingDirect(BOOL bSaveState /* == TRUE */) {
	if (IsPenRunning()) {
		m_logChannel.StopLog(bSaveState);
	}
}

//***********************************************************************
/// Process the Pen chart queue, add the current Pen reading and on going time to
///	the chart queue
///
/// @return nothing
//***********************************************************************
void CPenControl::ProcessPenChartQueues() {
	m_pChartQManager->AddReading(m_Instance, m_pPenDataItem->GetFPValue());
}

//***********************************************************************
/// Acknowledge or Reset one or all alarms for this pen
///
/// @param[in] - alarmNumber, 0-5 for alarm number or -1 for all alarms
/// @param[in] - reqType,	REQ_ALARM_ACKNOWLEDGE to acknowledge these alarm or 
///							REQ_ALARM_RESET to reset these alarms							
///
/// @return nothing
//***********************************************************************
void CPenControl::AcknowledgeOrResetAlarm(int alarmNumber, T_ALARM_REQUEST reqType) {
	if (alarmNumber == ACK_ALL_ALARMS) {
		// Acknowledge/Reset all alarms
		for (int alarmNumCount = 0; alarmNumCount < V6_MAX_ALARMS; alarmNumCount++) {
			if (reqType == REQ_ALARM_ACKNOWLEDGE) {
				m_alarm[alarmNumCount].RequestAcknowledge();
			} else {
				m_alarm[alarmNumCount].RequestCounterReset();
			}
		}
	} else {
		// Acknowledge/reset only the alarm specified
		if (alarmNumber < V6_MAX_ALARMS) {
			if (reqType == REQ_ALARM_ACKNOWLEDGE) {
				m_alarm[alarmNumber].RequestAcknowledge();
			} else {
				m_alarm[alarmNumber].RequestCounterReset();
			}
		}
	}
}

///**** Reports ***************************************************************************************

//***********************************************************************
/// Check and rollover a pen report if required
///
/// @return nothing
//***********************************************************************
void CPenControl::CheckReportRollover() {
	// If a full reset has been requested - wipe the complete report
	if (m_pPenManager->IsReportResetRequested() == TRUE) {
		wipeReport();
	} else {
		// Otherwise, process a report rollover if one has occured
		if (m_pPenManager->IsNewHour() == TRUE) {
			// Hour has rolled, so copy current hour to previous updating the averages as required
			m_pReport->set[LAST_REPORT].period[RP_HOUR] = m_pReport->set[WORKING_REPORT].period[RP_HOUR];
			m_resetHourReport = TRUE;		// Reset the hour report on next run

			// Cascade the averages
			float hourAverage = GetReportAverage(&m_pReport->set[WORKING_REPORT].period[RP_HOUR]);
			UpdateAve(&m_pReport->set[WORKING_REPORT].period[RP_DAY], hourAverage);
			UpdateAve(&m_pReport->set[WORKING_REPORT].period[RP_WEEK], hourAverage);
			UpdateAve(&m_pReport->set[WORKING_REPORT].period[RP_MONTH], hourAverage);

			// Cascade the totalisers
			m_pReport->set[WORKING_REPORT].period[RP_DAY].totalVal +=
					m_pReport->set[WORKING_REPORT].period[RP_HOUR].totalVal;
			m_pReport->set[WORKING_REPORT].period[RP_WEEK].totalVal +=
					m_pReport->set[WORKING_REPORT].period[RP_HOUR].totalVal;
			m_pReport->set[WORKING_REPORT].period[RP_MONTH].totalVal +=
					m_pReport->set[WORKING_REPORT].period[RP_HOUR].totalVal;

			if (m_pPenManager->IsNewDay() == TRUE) {
				// Day has rolled, so copy current day to last
				m_pReport->set[LAST_REPORT].period[RP_DAY] = m_pReport->set[WORKING_REPORT].period[RP_DAY];
				m_resetDayReport = TRUE;		// Reset the day report on next run
				if (m_pPenManager->IsNewWeek() == TRUE) {
					// week has rolled, so copy current week to last
					m_pReport->set[LAST_REPORT].period[RP_WEEK] = m_pReport->set[WORKING_REPORT].period[RP_WEEK];
					m_resetWeekReport = TRUE;		// Reset the week report on next run
				}
				if (m_pPenManager->IsNewMonth() == TRUE) {
					// Mont has rolled, so copy current Month to last
					m_pReport->set[LAST_REPORT].period[RP_MONTH] = m_pReport->set[WORKING_REPORT].period[RP_MONTH];
					m_resetMonthReport = TRUE;		// Reset the month report on next run
				}
			}
		}
	}
}

//***********************************************************************
/// Update the pen report
///
/// @param[in] - newVal, new value of the pen
/// @param[in] - status, status of the value, only update if it's a valid value
///
/// @return nothing
//***********************************************************************
void CPenControl::UpdatePenReport(float newVal, T_DATAITEM_STATUS status, BOOL statusChanged) {
	T_PEN_REPORT_SET *pReportSet = &m_pReport->set[WORKING_REPORT];

	if (status >= DISTAT_NORMAL) {
		// Status has changed and is now valid, check if reports were previously invalid, and reset to valid
		if (statusChanged) {
			// this occurs if a reading was invalid when report was started, so report will be zeroed, then the reading becomes valid
			// so the report needs to be reset to valid initial values
			for (int reportIndex = 0; reportIndex < RP_MAX; reportIndex++) {
				if (pReportSet->period[reportIndex].startTD == 0) {
					ResetReport(&pReportSet->period[reportIndex], newVal, status);
				}
			}
		}
		// Update the Max and Mins
		UpdateMaxMinReport(newVal, pReportSet);

		// Update the Average for an hour (this will be cascaded to day, week and months )
		UpdateAve(&pReportSet->period[RP_HOUR], newVal);
	}

	// Do we need to reset the hourly report
	if (m_resetHourReport == TRUE) {
		// Yes, reset hourly report and check for day report reset
		ResetReport(&pReportSet->period[RP_HOUR], newVal, status);
		m_resetHourReport = FALSE;
		if (m_resetDayReport == TRUE) {
			// Day report reset required, reset it and check week and month
			ResetReport(&pReportSet->period[RP_DAY], newVal, status);
			m_resetDayReport = FALSE;
			if (m_resetWeekReport == TRUE) {
				m_resetWeekReport = FALSE;
				ResetReport(&pReportSet->period[RP_WEEK], newVal, status);		// Reset week
			}
			if (m_resetMonthReport == TRUE) {
				m_resetMonthReport = FALSE;
				ResetReport(&pReportSet->period[RP_MONTH], newVal, status);		// Reset month
			}
		}
	}
	/*	//TEST CODE
	 static int thecounter = 0;
	 if( m_Instance == 0 )
	 {
	 if( thecounter++ == 20 )
	 {
	 TraceReportComplete();
	 thecounter = 0;
	 }
	 } */
}

//***********************************************************************
/// Update the cascaded max mins
///
/// @param[in] - newVal, new value of the pen
/// @param[in] - pReportDetail, pointer to report detail structure 
///
/// @return nothing
//***********************************************************************
void CPenControl::UpdateMaxMinReport(float newVal, T_PEN_REPORT_SET *pReportSet) {
	// Update the hour max
	if (UpdateMax(&pReportSet->period[RP_HOUR], newVal) == TRUE) {
		// Hour max has changed so cascade the max checks, next do the day
		if (UpdateMax(&pReportSet->period[RP_DAY], newVal) == TRUE) {
			// Update week and month max as day max has changed
			UpdateMax(&pReportSet->period[RP_WEEK], newVal);
			UpdateMax(&pReportSet->period[RP_MONTH], newVal);
		}
	}

	// Update the hour min
	if (UpdateMin(&pReportSet->period[RP_HOUR], newVal) == TRUE) {
		// Hour min has changed so cascade the min checks, next do the day
		if (UpdateMin(&pReportSet->period[RP_DAY], newVal) == TRUE) {
			// Update week and month min as day min has changed
			UpdateMin(&pReportSet->period[RP_WEEK], newVal);
			UpdateMin(&pReportSet->period[RP_MONTH], newVal);
		}
	}
}

//***********************************************************************
/// Update a max value for reports
///
/// @param[in] - pReportDetail, pointer to report detail structure 
/// @param[in] - newVal, new value of the pen
///
/// @return TRUE if MAX updated, otherwise FALSE
//***********************************************************************
BOOL CPenControl::UpdateMax(T_PEN_REPORT_DETAIL *pReportDetail, float newVal) {
	BOOL retVal = FALSE;
	if (newVal > pReportDetail->maxVal) {
		pReportDetail->maxVal = newVal;
		QTime procTime;
		procTime = pGlbSysTimer->GetCurrentProcessTimeRef();
		pReportDetail->maxTime = procTime.GetMicroSecs();
		retVal = TRUE;
	}
	return retVal;
}

//***********************************************************************
/// Update a min value for reports
///
/// @param[in] - pReportDetail, pointer to report detail structure 
/// @param[in] - newVal, new value of the pen
///
/// @return TRUE if MIN updated, otherwise FALSE
//***********************************************************************
BOOL CPenControl::UpdateMin(T_PEN_REPORT_DETAIL *pReportDetail, float newVal) {
	// If new value exceeds exisiting max, make current new max and stamp time
	BOOL retVal = FALSE;
	if (newVal < pReportDetail->minVal) {
		pReportDetail->minVal = newVal;
		QTime procTime;
		procTime = pGlbSysTimer->GetCurrentProcessTimeRef();
		pReportDetail->minTime = procTime.GetMicroSecs();
		retVal = TRUE;
	}
	return retVal;
}

//***********************************************************************
/// Update average for reading
///
/// @param[in] - pReportDetail, pointer to report detail structure 
/// @param[in] - newVal, new value of the pen
///
/// @return TRUE if MIN updated, otherwise FALSE
//***********************************************************************
void CPenControl::UpdateAve(T_PEN_REPORT_DETAIL *pReportDetail, float newVal) {
	// Update running average
	pReportDetail->AveTotal += newVal;
	pReportDetail->AveReads++;
}

//***********************************************************************
/// Get the average for a report
///
/// @param[in] - pReportDetail, pointer to report detail structure 
///
/// @return TRUE if MIN updated, otherwise FALSE
//***********************************************************************
float CPenControl::GetReportAverage(T_PEN_REPORT_DETAIL *pReportDetail) {
	float retVal = 0;
	if (pReportDetail->AveReads > 0) {
		retVal = pReportDetail->AveTotal / pReportDetail->AveReads;
	}
	return retVal;
}

//***********************************************************************
/// Reset a report to initial settings
///
/// @param[in] - pReportDetail, pointer to report detail structure 
/// @param[in] - newVal, new value of the pen
///
/// @return nothing
//***********************************************************************
void CPenControl::ResetReport(T_PEN_REPORT_DETAIL *pReportDetail, float newVal, T_DATAITEM_STATUS status) {
	if (status >= DISTAT_NORMAL) {
		// Stamp the start time of the report detail
		QTime procTime;
		procTime = pGlbSysTimer->GetCurrentProcessTimeRef();
		pReportDetail->startTD = procTime.GetMicroSecs();

		// Reset averages
		pReportDetail->AveReads = 1;
		pReportDetail->AveTotal = newVal;

		// Reset Max and Mins
		pReportDetail->maxVal = newVal;
		pReportDetail->maxTime = pReportDetail->startTD;
		pReportDetail->minVal = newVal;
		pReportDetail->minTime = pReportDetail->startTD;

		// Reset Total
		pReportDetail->totalVal = 0;
	} else {
		// status is not valid a reset is required, invalidate
		memset(pReportDetail, 0, sizeof(T_PEN_REPORT_DETAIL));
	}
}

//***********************************************************************
/// Wipe the report settings
///
/// @return nothing
//***********************************************************************
void CPenControl::wipeReport() {
	memset(m_pReport, 0, sizeof(T_PEN_REPORT));
	m_resetHourReport = TRUE;
	m_resetDayReport = TRUE;
	m_resetWeekReport = TRUE;
	m_resetMonthReport = TRUE;
}

//***********************************************************************
/// Trace out a pen control report
///
/// @return nothing
//***********************************************************************
void CPenControl::TraceReportComplete() {
	if (m_Instance == 0) {
		qDebug("**** REPORT DETAILS FOR PEN %d \n", m_Instance + 1);
		qDebug("CURRENT : Hour = ");
		TraceReportLine(&m_pReport->set[WORKING_REPORT].period[RP_HOUR]);
		qDebug("CURRENT : Day = ");
		TraceReportLine(&m_pReport->set[WORKING_REPORT].period[RP_DAY]);
		qDebug("PREVIOUS : Hour = ");
		TraceReportLine(&m_pReport->set[LAST_REPORT].period[RP_HOUR]);
		qDebug("PREVIOUS : Day = ");
		TraceReportLine(&m_pReport->set[LAST_REPORT].period[RP_DAY]);
	}
}

//***********************************************************************
/// Trace out a pen control report line
///
/// @return nothing
//***********************************************************************
void CPenControl::TraceReportLine(T_PEN_REPORT_DETAIL *pReportDetail) {
	float ave = GetReportAverage(pReportDetail);
	QTime startTime(pReportDetail->startTD);
	QTime maxTime(pReportDetail->maxTime);
	QTime minTime(pReportDetail->minTime);
	QString   reportLine;
	WCHAR timebuff[100], timebuff2[100];

	startTime.TimeToString(timebuff, 100);
	reportLine.asprintf(L"Start time = %s, Average = %f, Total = %f", timebuff, ave, pReportDetail->totalVal);
	qDebug("%s\n", reportLine);
	maxTime.TimeToString(timebuff, 100);
	minTime.TimeToString(timebuff2, 100);
	reportLine.asprintf(L"Max = %f @ %s, Min = %f @ %s", pReportDetail->maxVal, timebuff, pReportDetail->minVal,
			timebuff2);
	qDebug("%s\n", reportLine);

}

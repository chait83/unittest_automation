/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	Persist Manager
/// @n Filename: SRAM.cpp
/// @n Desc:	Manages access to the SRAM for a function related region	
///				
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 36	Stability Project 1.31.1.3	7/2/2011 5:01:30 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 35	Stability Project 1.31.1.2	7/1/2011 4:38:56 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 34	Stability Project 1.31.1.1	3/17/2011 3:20:47 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 33	Stability Project 1.31.1.0	2/15/2011 3:03:57 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
// ****************************************************************

#include "SRAM.h"
#include "TransactionStatus.h"
#include "V6crc.h"

#include "BatteryManager.h"

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif

// Singleton instance
CSRAMManager *CSRAMManager::m_pInstance = NULL;
QMutex m_CreationMutex;

// *** SRAM memroy map ***
//
// To Add a new region
//=====================
// 1. Add a emun region type for the new region into regionIdent enum in SRAM.H 
// 2. Add a line into the SRAMRegionMap[] struct below, before regionEnd
// 3. Setup the start and end, make sure the size of the region includes space for REGIONSIG structure always
//			stored at the start of an SRAM region
// note: All start and end addresses must be word aliged
//
// WARNING:
// BootLace uses REGION_BOOT without the full SRAM manager, 
// Do not change this region size or location without re-building BootLace.

SRAMREGION SRAMRegionMap[] = {
// Region ID			Start			End					Description
		REGION_RESERVED, 8, 62, (L"Reserved"), // Reserved for system information (first 8 bytes used in DAL in SRAM create)		
		REGION_HOTSOAK, 64, 126, (L"Hot Soak"),	// Used for Hot soak testing 
		REGION_BOOT, 128, 254, (L"Boot"),			// Reserved for BootLace
		REGION_GENERAL, 256, 510, (L"General"), REGION_SCRIPT_PV, 512,
		KB_TO_BYTE(1) - 2, (L"Script PVs"),	// Script persist vars 512bytes		
		REGION_PASSWORD, KB_TO_BYTE(1), KB_TO_BYTE(2) - 2, (L"Password"),	// Passwords 1K	
		REGION_TRANSACTION, KB_TO_BYTE(2), KB_TO_BYTE(3) - 2, (L"Transaction"),	// Transaction points 1K
		REGION_CONTROLSEQ, KB_TO_BYTE(3), KB_TO_BYTE(4) - 2, (L"ControlSeq"),	// Control sequencer 1K
		REGION_NVVARS, KB_TO_BYTE(4), KB_TO_BYTE(24) - 2, (L"NVVariables"),	// NV Variables 20K
		REGION_TRANSFER, KB_TO_BYTE(24), KB_TO_BYTE(34) - 2, (L"DataTransfer"),	// Data transfer 10K
		REGION_LOGGING, KB_TO_BYTE(34), KB_TO_BYTE(40) - 2, (L"Logging"),	// Logging 6K
		REGION_ALARMS, KB_TO_BYTE(40), KB_TO_BYTE(52) - 2, (L"Alarms"),	// Alarm NV 12K
		REGION_REPORTS, KB_TO_BYTE(52), KB_TO_BYTE(92) - 2, (L"Reports"),	// Reports 40K
		REGION_TABULAR, KB_TO_BYTE(92), KB_TO_BYTE(101) - 2, (L"Tabualar"),	// Tabular Data 9K
		REGION_AMS2750, KB_TO_BYTE(101), KB_TO_BYTE(106) - 2, (L"AMS2750"),	// AMS2750 Data 5K

		// NVQueues should be set to use rest of available SRAM
#ifndef XSERIESSETUP	
		//REGION_NVQUEUES,		KB_TO_BYTE(106),KB_TO_BYTE(1024)-2,	(L"NVQueues"),		// NV Queues - remainder	
		REGION_NVQUEUES, KB_TO_BYTE(106), KB_TO_BYTE(1014) - 2, (L"NVQueues"),// NV Queues - remainder excluding 10K to CSV
		REGION_CSV_TRANS, KB_TO_BYTE(1014), KB_TO_BYTE(1024) - 2, (L"CSVTrans"), //CSV transfer releated transaction info
#else
			REGION_NVQUEUES,		KB_TO_BYTE(106),KB_TO_BYTE(512)-2,	(L"NVQueues"),		// NV Queues - remainder	
		#endif		
		// End of list, ALWAYS keep at end
		REGION_END, 0, 0, (L"End") };

/// Unique signature indicating and SRAM has been used
#define REGION_USED_SIG		0x9145		///< NEVER CHANGE THIS SIGNATURE OR SRAM WILL BE INVALIDATED.

//======================================================================//
// CSRAMRegion class
//======================================================================

//**********************************************************************
/// CSRAMRegion constructor
/// 
/// 
//**********************************************************************
CSRAMRegion::CSRAMRegion() {
	m_pDAL = CDeviceAbstraction::GetHandle();
}

//**********************************************************************
/// Initialise the region from the map entry
/// 
///
/// @param[in]	pMapAddr - pointer to the SRAMRegionMap entry associated
///							with the 
/// @return		TRUE if okay, otherwise FALSE for failure
/// 
//**********************************************************************
BOOL CSRAMRegion::Initalise(PSRAMREGION pMapAddr) {
	m_pMapEntry = pMapAddr;		// Tie up region instance to RegionMap entry
	SetInUse(FALSE);			// Indicate region free to use

	// Get physical SRAM address and setup region pointers
	CHAR *pBase = m_pDAL->GetPtrIntoSRAM(GetMapStart());
	if (pBase != NULL) {
		m_pRegSig = (PREGIONSIG) pBase;					// Setup signature block
		m_pUserBase = (void*) (pBase + sizeof(REGIONSIG));		// Usable memory
	} else {
		m_pDAL->FatalError(L"SRAM: Error, base address could not be generated, halt \n");
		return FALSE;
	}

	// Size of the region must be at least the size of a signature block plus at least one accessable location, 
	if (GetMapEnd() < (sizeof(REGIONSIG) + sizeof(USHORT))) {
		m_pDAL->FatalError(L"SRAM: Error, size of region too small to use(only %d bytes), check region map size \n"), GetMapEnd();
		return FALSE;
	}

	// Size of region cannot be odd as only even bytes are accessable
	if (GetMapEnd() % 2 == 1) {
		m_pDAL->FatalError(
				L"SRAM: Error, size of region is odd number of bytes (%d bytes and must be even), check region map size \n"), GetMapEnd();
		return FALSE;
	}

	/// @todo check the region against the total size
	qDebug((" %s region id=%d start=%d end=%d user length=%d\n"), m_pMapEntry->Name, m_pMapEntry->id, GetMapStart(),
			GetMapEnd(), GetMapSize());

	QDateTime sysTime;
	GetLocalTime(&sysTime);
	//if date changed to 2006 (battery low identified) reset blockdata

	qDebug(L"SRAM: Init - Current Year %d\n", sysTime.wYear);
	bool bResetDueToLowBattery = false;
#if (!defined IS_BOOTLACE_APP) && (!defined TTR6SETUP) && (defined UNDER_CE)
	CBatteryManager* pBatMan = CBatteryManager::GetHandle(); 

	if ( (NULL != pBatMan ) && (TRUE == pBatMan->IsBatteryResetPerformed() ) )
	{
		bResetDueToLowBattery = false;
	}
	else if( (sysTime.wYear <= 2006 ) && (REGION_PASSWORD < m_pMapEntry->id) && (REGION_NVVARS != m_pMapEntry->id) ) //do this incase of no Battery reset from user but low battery
	{
		bResetDueToLowBattery = true;
	}
#endif

	// Check to see if region has ever been used - if not indicate first use and default signature block
	if ((m_pRegSig->signature != REGION_USED_SIG) || (true == bResetDueToLowBattery)) {
		ClearRegion();
	}
	return TRUE;
}

//**********************************************************************
/// Initialise the region from the map entry
/// 
///
/// @param[in]	pMapAddr - pointer to the SRAMRegionMap entry associated
///							with the 
/// @return		nothing
/// 
//**********************************************************************
void CSRAMRegion::ClearRegion() {
	qDebug((" %s region cleared\n"), m_pMapEntry->Name);
	m_pRegSig->signature = REGION_USED_SIG;
	m_pRegSig->autoState = SRAM_STATE_FIRSTUSE;
	m_pRegSig->version = 0;
	m_pRegSig->crc = 0;

	// Cleardown SRAM region, write in words
	short *pSRAM = (short*) m_pUserBase;
	for (int i = 0; i < GetMapSize() / 2; i++) {
		*pSRAM++ = 0x0;
	}
}

//**********************************************************************
/// Calculate CRC for this region
/// 
/// @return		nothing
/// 
//**********************************************************************
void CSRAMRegion::SetCRC() {
	m_pRegSig->crc = CrcCalc(reinterpret_cast<UCHAR*>(GetAddress()), GetAvailableBytes());
}

//**********************************************************************
/// Test CRC
/// 
/// @return		nothing
/// 
//**********************************************************************
BOOL CSRAMRegion::TestCRC() {
	BOOL retVal = FALSE;
	if (m_pRegSig->crc == CrcCalc(reinterpret_cast<UCHAR*>(GetAddress()), GetAvailableBytes())) {
		retVal = TRUE;
	}
	return retVal;
}

//======================================================================//
// CSRAMmanager class
//======================================================================

//**********************************************************************
/// CSRAMManager Constructor
/// Set-up and instanciate an array of CSRAMRegion objects to be used 
///
///
//**********************************************************************
CSRAMManager::CSRAMManager() {
	m_Initilaised = FALSE;
	m_pDAL = CDeviceAbstraction::GetHandle();
}

//**********************************************************************
///
/// Instance creation of CSRAMManager singleton
///
/// @return		pointer to single instance of CSRAMManager
/// 
//**********************************************************************
CSRAMManager* CSRAMManager::GetHandle() {
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;
	if (NULL == m_pInstance) {
		// An instance has yet to be completed
		m_CreationMutex = CreateMutex(NULL,		// No security descriptor
				FALSE,					// Mutex object not owned
				TEXT("SRAMManager"));	// Object name

		waitSingleObjectResult = m_CreationMutex.tryLock(g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);
		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:
			// Object was signaled
			if (NULL == m_pInstance) {
				m_pInstance = new CSRAMManager;
			}
			if ( FALSE == m_CreationMutex.unlock()) {
				//V6WarningMessageBox( NULL, L"Failed to release SRAMManager mutex", L"CSRAMManager Error", MB_OK );		
			} // End of IF

			break;

		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
			//V6WarningMessageBox( NULL, L"SRAMManager WaitForSingleObject Error", L"CSRAMManager Error", MB_OK ); 
			break;
		}
		// Close the Mutex as no longer required
		//No need to close the mutex in Qt
	}
	return (m_pInstance);
}

//**********************************************************************
///
/// Deletes the instance of the singleton from memory
///
/// @return		nothing
/// 
//**********************************************************************
void CSRAMManager::CleanUp() {
	m_region.removeAll();	// Cleanup the region list

	delete m_pInstance;
	m_pInstance = NULL;
}

//**********************************************************************
/// Initialise the SRAM manager
/// 
/// @return		TRUE if okay, otherwise FALSE indicating a failure
/// 
//**********************************************************************
BOOL CSRAMManager::Initialise() {
	// See if the manager has been initialised before
	if (m_Initilaised == TRUE) {
		/// @todo use this to find multiple inits m_pDAL->FatalError(L"SRAM: Manager, Already initialised \n");
		return m_Initilaised;
	}

	// Build region map show initialisation status
	if (BuildRegionMap()) {
		m_Initilaised = TRUE;		// Regions can now be used.
	}

	CTransactionStatus::Initialise();	// Initialise Transaction status

	return m_Initilaised;
}

//**********************************************************************
/// Build the region map from the source memory SRAMRegionMap
/// 
/// @return		TRUE if okay, otherwise FALSE for failure
/// 
//**********************************************************************
BOOL CSRAMManager::BuildRegionMap() {
	m_totalRegions = 0;
	// Run through SRAM region map and find the total number of regions
	for (int i = 0; i < MAX_REGION_LIMIT; i++) {
		if (SRAMRegionMap[i].id == REGION_END) {
			m_totalRegions = i;
			break;
		}
	}
	// If regoins are found with and endRegion run through and build
	// the array of CSRAMRegoins within the manager
	if (m_totalRegions > 0) {
		CSRAMRegion *pRegion;
		int index;

		// Create an array of CSRAMRegion's each element will be indexed by enum regionIdent, this may differ
		// to the index of SRAMRegionMap
		m_region.resize(m_totalRegions);	// Set size of region array
		for (int i = 0; i < m_totalRegions; i++) {
			index = SRAMRegionMap[i].id;
			if (index > m_totalRegions) {
				m_pDAL->FatalError(L"SRAM: Error, index error please check enum within SRAMRegionMap \n");
				m_totalRegions = 0;
				return FALSE;

			}
			pRegion = &m_region[index];	// Get class instance in array for enum value

			pRegion->Initalise(&SRAMRegionMap[i]);
		}
	} else {
		m_pDAL->FatalError(L"SRAM: Error, please check SRAMRegionMap \n");
		return FALSE;
	}
	if (CheckForRegionOverlap() == FALSE) {
		m_totalRegions = 0;
		return FALSE;
	}
	return TRUE;
}

//**********************************************************************
/// Check each regoin in turn for any overlaps with other regoins
/// this will alert the developer to any issues with a critical stop report
///
/// @return		TRUE if okay, otherwise FALSE for failure
/// 
//**********************************************************************
BOOL CSRAMManager::CheckForRegionOverlap() {

	CSRAMRegion *pCurrRegion;
	CSRAMRegion *pTestRegion;
	// Check all regions for overlap
	for (int testReg = 0; testReg < m_totalRegions; testReg++) {
		pTestRegion = &m_region[testReg];		// Get current region to test

		// Test the region agaisnt all others in the map to check for overlaps
		for (int currReg = 0; currReg < m_totalRegions; currReg++) {
			// Don't test the test region against itself(current) as it will overlap for sure
			if (currReg == testReg)
				continue;
			pCurrRegion = &m_region[currReg];	// Get current region to test

			// Check to see that the start of a region does not fall within the test region
			if (pCurrRegion->GetMapStart() >= pTestRegion->GetMapStart()
					&& pCurrRegion->GetMapStart() <= pTestRegion->GetMapEnd()) {
				m_pDAL->FatalError(L"SRAM: Current region(%d) start overlaps test(%d)\n", currReg, testReg);
				return FALSE;
			}
			// Check to see that the end of a region does not fall within the test region
			if (pCurrRegion->GetMapEnd() >= pTestRegion->GetMapStart()
					&& pCurrRegion->GetMapEnd() <= pTestRegion->GetMapEnd()) {
				m_pDAL->FatalError(L"SRAM: Current region(%d) end overlaps test(%d)\n", currReg, testReg);
				return FALSE;
			}
		}
	}
	return TRUE;
}

//**********************************************************************
/// Request a region from the SRAM Manager, if region is currently in
/// use (previously requested) 
///
/// @param[in]	regionId - region identifier of type regionIdent, see SRAM.h
/// @param[out]	**pRegion - ptr to instance of CSRAMRegion based on id regionId
///							NULL returned if error
///
/// @return		regionError value, REGION_OKAY if successful or other to indicate error condition
/// 
//**********************************************************************
CSRAMManager::regionError CSRAMManager::RequestRegion(regionIdent regionId, CSRAMRegion **pRegion) {
	*pRegion = NULL;

	// Make sure region manager has been enabled
	if (m_Initilaised == FALSE) {
		m_pDAL->FatalError(L"SRAM: trying to use sram before sram manager is initialised\n");
		return REGION_MANAGER_NOT_INIT;
	}

	if (regionId >= m_totalRegions) {
		m_pDAL->FatalError(L"SRAM: trying to use region that does not exist\n");
		return REGION_DOES_NOT_EXIST;
	}

	*pRegion = &m_region[regionId];

	if ((*pRegion)->IsInUse() == FALSE) {
		// region is free so lock region and return
		(*pRegion)->SetInUse( TRUE);
	} else {
		// region is locked to set to NULL
		qDebug((" region(%d) if locked\n"), regionId);
		return REGION_IN_USE;
	}
	return REGION_OKAY;
}

//**********************************************************************
/// Release a region to the SRAM Manager
///
/// @param[in]	regionId - region identifier of type regionIdent, see SRAM.h
///
/// @return		TRUE if released okay, FALSE if not already locked
/// 
//**********************************************************************
CSRAMManager::regionError CSRAMManager::ReleaseRegion(regionIdent regionId) {

	if (regionId >= m_totalRegions) {
		m_pDAL->FatalError(L"SRAM: trying to use region that does not exist\n");
		///@todo AK, critical erro handler
		return REGION_DOES_NOT_EXIST;
	}

	CSRAMRegion *region = &m_region[regionId];

	if (region->IsInUse() == TRUE) {
		// Free region
		region->SetInUse( FALSE);
	} else {
		// region is locked to set to NULL
		qDebug((" region(%d) if was not locked, but unlock attempted\n"), regionId);
		return REGION_NOT_IN_USE;
	}
	return REGION_OKAY;
}

//**********************************************************************
/// CRC all regions in SRAM and store CRC in header
///
///
/// @return		nothing
/// 
//**********************************************************************
void CSRAMManager::CRCAllRegions() {
	CSRAMRegion *pRegion;
	int index;
	for (int i = 0; i < m_totalRegions; i++) {
		index = SRAMRegionMap[i].id;
		pRegion = &m_region[index];	// Get class instance in array for enum value

		pRegion->SetCRC();
	}
}

//*****************************************************************
// SRAM Test caddy and example implementation template
//*****************************************************************
#if 0
struct SRAMTestRegion
{
	long TimesTested;
	long TimesUpdating;
};

void SRAMtestCaddy()
{		
		CSRAMManager *pSRAM = CSRAMManager::GetHandle();
		// Always initialise
		pSRAM->Initialise();


		CSRAMRegion *pRegion = NULL;
		// Request a ptr to the CSRAMRegion instance for the corrisponding regionIdent
		CSRAMManager::regionError requestReturn = pSRAM->RequestRegion( REGION_TEST, &pRegion ); 

		if( requestReturn != CSRAMManager::REGION_OKAY )
		{
				qDebug( (L" CRITICAL error\n"));
				return;
		}

		struct SRAMTestRegion *testData = (struct SRAMTestRegion *)pRegion->GetAddress();

		// Check if this is the first time the region has been used after power on
		if( pRegion->GetAutoState() == SRAM_STATE_FIRSTUSE )
		{
			testData->TimesTested = 0;
			testData->TimesUpdating = 0;
			pRegion->SetAutoStateToNormal();	// Return to normal state, first time power on for region
			qDebug( (L" First time used\n"));
		}

		// Check if this is the first time the region has been used after power on
		if( pRegion->GetAutoState() == SRAM_STATE_UPDATING )
		{
			testData->TimesUpdating++;
			pRegion->SetAutoStateToNormal();	// Return to normal state, after power fail recovery
			qDebug( (L" Region was being updated when power failed\n"));
		}

		
		pRegion->SetAutoStateToUpdating();	// Return to normal state, after power fail recovery
		
		testData->TimesTested++;
		qDebug( (L" Test area, tesed %d times\n"),testData->TimesTested );
		
		pRegion->SetAutoStateToNormal();
		pRegion->UpdateSRAM();


		// TEST TO TRY AND GET REGION AGAIN
	
/*		CSRAMRegion *tryAgain = NULL;
		// Request a ptr to the CSRAMRegion instance for the corrisponding regionIdent
		CSRAMManager::regionError anotherReturn = pSRAM->RequestRegion( REGION_TEST, &tryAgain ); 
		if( anotherReturn != CSRAMManager::REGION_IN_USE )
		{
			qDebug( (L" TEST FAILED, region should already be in use\n"));
		}

*/
		pSRAM->ReleaseRegion( REGION_HOTSOAK );



		/****************** Region usage template start ***********************

		CSRAMManager *pSRAM = CSRAMManager::GetHandle();	// Get handle on singleton

		CSRAMRegion *pRegion = NULL;

		// Request a ptr to the CSRAMRegion instance for the corrisponding regionIdent
		CSRAMManager::regionError requestReturn = pSRAM->RequestRegion( TODO insert enum regionIdent , &pRegion ); 

		if( requestReturn != CSRAMManager::REGION_OKAY )
		{
			if( requestReturn == CSRAMManager::REGION_IN_USE )
			{
				/// 
				/// TODO Add code to handle region not available as being used elsewhere
				///
			}
			/// 
			/// These are far more serious conditions are point to programming error
			/// critical erro handlers are already in place within RequestRegion, HALT suggested.
			/// CSRAMManager::REGION_MANAGER_NOT_INIT
			/// CSRAMManager::REGION_DOES_NOT_EXIST
			///
		}

		
		// Check if this is the first time the region has been used after power on
		if( pRegion->GetAutoState() == SRAM_STATE_FIRSTUSE )
		{
			/// TODO Add code to handle region that has not been used before
			///
			pRegion->SetAutoStateToNormal();	// Return to normal state, first time power on for region
		}

		// Check if this is the first time the region has been used after power on
		if( pRegion->GetAutoState() == SRAM_STATE_UPDATING )
		{
			/// TODO Add code to handle region that was being updated when power failed
			///
			pRegion->SetAutoStateToNormal();	// Return to normal state, after power fail recovery
		}
		
		/// TODO Add code to use the region, example of updating
		///
		// pData = (cast to struct)pRegion->GetAddress();
		
		// pRegion->SetAutoStateToUpdating();	// Return to normal state, after power fail recovery
		// ....
		// Update data in region, 
		// to get a void pointer to the memory to access use 
		// ....
		// pRegion->SetAutoStateToNormal();

		/// if you are not using the SRAM exclusivly, release the SRAM when you have finished
		/// ReleaseRegion( regionId )


		******************* Region usage template end **********************/

}

#endif

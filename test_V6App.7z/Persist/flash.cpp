/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	Persist Manager
/// @n Filename: Flash.cpp
/// @n Desc:	Manages access to the flash boot blocks 
///				
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 25	Stability Project 1.20.1.3	7/2/2011 4:57:19 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 24	Stability Project 1.20.1.2	7/1/2011 4:38:17 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 23	Stability Project 1.20.1.1	3/17/2011 3:20:24 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 22	Stability Project 1.20.1.0	2/15/2011 3:03:05 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
// ****************************************************************

#include "flash.h"
#include "v6crc.h"
#include "TransactionStatus.h"
#include "V6globals.h"

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif

// Singleton instance
CFlashManager *CFlashManager::m_pInstance = NULL;
QMutex m_CreationMutex;

#ifdef UNDER_CE
typedef BOOL (*NorFlashStoreSplashScreen)(HANDLE h_Interface_g, BYTE *pBuffer,ULONG sizeReq);
extern NorFlashStoreSplashScreen pfNORFlashStoreSplashScreen;
#endif

//======================================================================//
// CFlashManager class
//======================================================================

//**********************************************************************
/// CFlashManager Constructor
/// Set-up and instanciate an array of CSRAMRegion objects to be used 
///
///
//**********************************************************************
CFlashManager::CFlashManager() : m_timerWrite(TIMER_HIGH_RES) {
	m_Initilaised = FALSE;
	QMutex * m_CritSection;
	m_pDAL = CDeviceAbstraction::GetHandle();

}

//**********************************************************************
///
/// Instance creation of CSRAMManager singleton
///
/// @return		pointer to single instance of CSRAMManager
/// 
//**********************************************************************
CFlashManager* CFlashManager::GetHandle() {
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;
	if (NULL == m_pInstance) {
		// An instance has yet to be completed
		m_CreationMutex = CreateMutex(NULL,		// No security descriptor
				FALSE,					// Mutex object not owned
				TEXT("FlashManager"));	// Object name

		waitSingleObjectResult = m_CreationMutex.tryLock(g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);
		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:
			// Object was signaled
			if (NULL == m_pInstance) {
				m_pInstance = new CFlashManager;
			}
			if ( FALSE == m_CreationMutex.unlock()) {
				V6WarningMessageBox(NULL, L"Failed to release FlashManager mutex", L"CFlashManager Error", MB_OK);
			} // End of IF

			break;

		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
			V6WarningMessageBox(NULL, L"FlashManager WaitForSingleObject Error", L"CFlashManager Error", MB_OK);
			break;
		}
		// Close the Mutex as no longer required
		//No need to close the mutex in Qt
	}
	return (m_pInstance);
}

//**********************************************************************
///
/// Deletes the instance of the singleton from memory
///
/// @return		nothing
/// 
//**********************************************************************
void CFlashManager::CleanUp() {
	//deletion of mutex not required
	delete m_pInstance;
	m_pInstance = NULL;
}

//**********************************************************************
///
/// Read or write data from a block of flash, if writing a normal block
/// it will be mirrored to a file on disk whilst writing, should power
/// be interrupted then a block restore can be complete
///
/// @param[in]		blockNum - number of flash block using T_FLASH_BLOCK see flash.h
/// @param[in,out]	pData - pointer to data buffer to read flash data into
/// @param[in]		size - Size in bytes of data to be read/written
/// @param[in]		readOrWrite - BF_READ to read, BF_WRITE to Write
///
/// @return		T_FLASH_STATUS providing error information
/// 
//**********************************************************************
T_FLASH_STATUS CFlashManager::ReadWriteBlock(T_FLASH_BLOCK blockNum, void *pData, ULONG sizeOfStructure,
		UCHAR readOrWrite, BOOL bClear) {
	T_FLASH_STATUS blkResult = FLASH_STATUS_OKAY;

	m_CritSection.lock();

	// If the block requested is a special block IEL parametere or the splash screen then
	// we don't have any header on this block. 
//	if( (blockNum >= FLASH_BLK_SPECIALBLOCKS) || (TRUE == bClear) )
	if ((blockNum <= FLASH_BLK_SPLASH_BLK_11 || blockNum == FLASH_BLK_IEL_PARAM) || (TRUE == bClear)) {
		// Check that the size requested isn't too big
		if (sizeOfStructure > BF_MAXSIZE) {
			blkResult = FLASH_STATUS_TOOBIG;
		} else {
			// Get the data block straight into user data buffer, not extra checks required
			if (m_pDAL->RWBootFlashBlock(readOrWrite, blockNum, sizeOfStructure, (BYTE*) pData) == FALSE) {
				blkResult = FLASH_STATUS_DALFAIL;
			}
		}
	} else {
		// These are blocks we maintain headers on.
		// Perform size check on blocks with header
		if (sizeOfStructure + sizeof(T_FLASH_HEADER) > BF_MAXSIZE) {
			blkResult = FLASH_STATUS_TOOBIG;
		} else {
			// Create a block big enough to hold the header and the flash data
			UCHAR *pDataCpy = new UCHAR[ BF_MAXSIZE];
			memset(pDataCpy, 0, sizeOfStructure + sizeof(T_FLASH_HEADER));
			T_FLASH_HEADER *pHeader = (T_FLASH_HEADER*) pDataCpy;		// Map header over flash block

			// If read is requested the read in block and check signature and CRC
			// if both okay the block is good and pass back to user
			if (readOrWrite == BF_READ) {
				int sizeOfFlashData = GetDataBlockSize(blockNum);

				// Diagnostics in Alpha/Beta Builds
				if (V6_RELEASE != RELEASE_PRODUCTION) {
					if (sizeOfFlashData != sizeOfStructure) {
						QString  flashDetails;
						flashDetails.asprintf(L"Flash Size diff Block(%d) orig(%d) new(%d) ", blockNum, sizeOfFlashData,
								sizeOfStructure);
						LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_WARNING, flashDetails);
					}
				}

				if (sizeOfFlashData + sizeof(T_FLASH_HEADER) < BF_MAXSIZE) {
					if (m_pDAL->RWBootFlashBlock( BF_READ, blockNum, sizeOfFlashData + sizeof(T_FLASH_HEADER),
							(BYTE*) pDataCpy) == TRUE) {
						// Check if the block has avail signature, if not it has never been used before
						if (pHeader->Signature != FLASH_SIGNATURE) {
							blkResult = FLASH_STATUS_FIRSTUSE;
						} else {
							// Valid signature found, now check the CRC to see if the block is corrupt
							if (CrcCalc(pDataCpy + sizeof(T_FLASH_HEADER), pHeader->Size) != pHeader->CRC) {
								blkResult = FLASH_STATUS_CRCFAIL;			// CRC failed, block is corrupt
								QString  strError("");
								strError.asprintf(L"Flash block %u CRC Failure", blockNum);
								LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
							} else {
								// Create a size to use, use the size read from the flash header
								// however if the size passed in is smaller then we must use that or we'll have overflow
								int sizeToUse = sizeOfFlashData;
								if (sizeOfStructure <= static_cast<ULONG>(sizeOfFlashData)) {
									// Use the size of the structure
									sizeToUse = sizeOfStructure;
								} else {
									// Size of the structure is bigger then what we are reading from flash so
									// clear the end of the structure 
									memset(static_cast<UCHAR*>(pData) + sizeOfFlashData, 0,
											sizeOfStructure - sizeOfFlashData);
								}
								// Block successfully read and checked, so copy data into user data block
								memcpy(pData, pDataCpy + sizeof(T_FLASH_HEADER), sizeToUse);
								blkResult = FLASH_STATUS_OKAY;
							}
						}
					} else {
						blkResult = FLASH_STATUS_DALFAIL;									// Read from DAL failed
						QString  flashDetails;
						flashDetails.asprintf(L"Read fail Block(%d) Hsize(%d) AppSize(%d) sig %x", blockNum,
								sizeOfFlashData, sizeOfStructure, pHeader->Signature);
						V6WarningMessageBox(NULL, flashDetails, L"Flash Read error",
								MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST);
					}
				} else {
					blkResult = FLASH_STATUS_DALFAIL;	// Read from DAL failed
				}
			} else {
				// Request to write block, set signature and CRC block then save away
				pHeader->Signature = FLASH_SIGNATURE;	// Set he signature
				pHeader->CRC = CrcCalc((UCHAR*) pData, sizeOfStructure);	// Calculate the CRC
				pHeader->Size = sizeOfStructure;

				int totalSize = sizeOfStructure + sizeof(T_FLASH_HEADER);
				// Copy data into memory to write to flash
				memcpy(pDataCpy + sizeof(T_FLASH_HEADER), pData, sizeOfStructure);

				// Profile the flash write process
				m_timerWrite.StartTimer();		// Start profiling flash write

				// Set transaction to be file writing
				CTransactionStatus::SetStatus(TRANS_IDENT_FLASH, TRANSACTION_STATUS_WRITEFILE, blockNum);

				// Backup Flash block
				m_pDAL->ReadWriteNV( BF_WRITE, totalSize, (WORD*) pDataCpy,
				BF_BLK_BACKUP, BF_MAXSIZE);

				// Set transaction to be flash writing
				CTransactionStatus::SetStatus(TRANS_IDENT_FLASH, TRANSACTION_STATUS_WRITEFLASH, blockNum);

				if (m_pDAL->RWBootFlashBlock( BF_WRITE, blockNum, totalSize, (BYTE*) pDataCpy) == FALSE) {
					blkResult = FLASH_STATUS_DALFAIL;	// Write to DAL failed
					QString  flashDetails;
					flashDetails.asprintf(L"Block(%d) sizeOfStructure(%d) ", blockNum, pHeader->Size);
					V6WarningMessageBox(NULL, flashDetails, L"Flash Write error",
							MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST);
				}
				// Set transaction to be normal, flash write complete
				CTransactionStatus::SetStatus(TRANS_IDENT_FLASH, TRANSACTION_STATUS_NORMAL, blockNum);

				m_timerWrite.StopTimer();		// Stop profiling flash write
				qDebug("Flash write block %d took %dms \n", blockNum,
						(ULONG) m_timerWrite.GetTimeInMilliSec(TIMER_SINGLE));

			}
			delete[] pDataCpy;
		}
	}
	m_CritSection.lock();

	return blkResult;
}

//**********************************************************************
///
/// Read the size of the data block in memory, only uses on block 0 thru 12 
///
/// @param[in]		blockNum - number of flash block using T_FLASH_BLOCK see flash.h
///
/// @return		size of exisiting data block
/// 
//**********************************************************************
ULONG CFlashManager::GetDataBlockSize(T_FLASH_BLOCK blockNum) {
	ULONG blockSize = 0;
	m_CritSection.lock();

	// Do not interrogate speacial blocks as they have no headers
	// Load up header only and return the blocks size.
	//if( blockNum < FLASH_BLK_SPECIALBLOCKS )
	if (blockNum > FLASH_BLK_SPLASH_BLK_11 || blockNum != FLASH_BLK_IEL_PARAM) {
		// Read Header from flash block
		T_FLASH_HEADER header;
		if (m_pDAL->RWBootFlashBlock( BF_READ, blockNum, sizeof(T_FLASH_HEADER), (BYTE*) &header) == TRUE) {
			// Only try to extract block size if valid signature is found.
			if (header.Signature == FLASH_SIGNATURE) {
				blockSize = header.Size;
			}
		}
	}
	m_CritSection.lock();
	return blockSize;
}

//**********************************************************************
///
/// Check to see if a block write was taking place, if so it's integrity cannot
/// be guaranteed so reporgram block with backup block stored on disk
///
/// @return		TRUE if restore was required, otherwise FALSE
/// 
//**********************************************************************
BOOL CFlashManager::CheckIntegrityAndRepair() {
	BOOL IsRepaired = FALSE;
	DWORD flashBlockNumber;
	m_CritSection.lock();

	T_TRANSACTION_STATUS flashWriteStatus = CTransactionStatus::GetStatus(TRANS_IDENT_FLASH, &flashBlockNumber);

	// Test to see if flash block was being written
	if (flashWriteStatus == TRANSACTION_STATUS_WRITEFLASH) {
		// Yes it was so the stored version in the disk file is most up to date and we cannot guaruntee
		// that the flash block being written to flash is good.

		// Allocate a buffer to read flash into
		char *tempFlashBlock = new char[BF_MAXSIZE];
		// Read the back flash block on disk into the temporary buffer
		if (m_pDAL->ReadWriteNV( BF_READ, BF_MAXSIZE, (LPWORD) tempFlashBlock,
		BF_BLK_BACKUP, BF_MAXSIZE) == TRUE) {
			// Read successful so reprogram the flash block

			// Get a handle on the header of the Flash block
			T_FLASH_HEADER *pHeader = reinterpret_cast<T_FLASH_HEADER*>(tempFlashBlock);
			// Get a pointer to the start of the data in the flash block
			char *startOfData = tempFlashBlock + sizeof(T_FLASH_HEADER);

			// Reprogram, the flash block
			ReadWriteBlock(static_cast<T_FLASH_BLOCK>(flashBlockNumber), startOfData, pHeader->Size, BF_WRITE);
			IsRepaired = TRUE;
			QString  flashDetails;
			flashDetails.asprintf(L"OK Block(%d) size(%d)", flashBlockNumber, pHeader->Size);
			V6WarningMessageBox(NULL, flashDetails, L"Flash re-program", MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST);
		} else {
			QString  flashDetails;
			flashDetails.asprintf(L"Block(%d) failed to read", flashBlockNumber);
			V6WarningMessageBox(NULL, flashDetails, L"Flash re-program", MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST);
		}

		delete[] tempFlashBlock;
	}
	m_CritSection.lock();
	return IsRepaired;
}

const int SPALSH_SCREEN_MAX_SIZE = 1024 * 512;// Spalsh screen cannot be bigger then 512K, if it is then it's corrupted
const int NO_EXTRA_TO_WRITE = 0;		// Nothing extra to write, i.e. flash block does not exceed a 64K block

//**********************************************************************
///
/// Checks if a new spash screen exists on disk, if so will attempt 
/// to program the new spash screen into the available flash blocks
/// and will delete the file
///
/// @return		TRUE if splash screen programmed , otherwise FALSE
/// 
//**********************************************************************
BOOL CFlashManager::SplashScreenCheckLoadAndProgram() {
	BOOL newSplashScreen = FALSE;
#ifdef UNDER_CE
	QString   pRootVol;
	QString   fileName;

	pRootVol = m_pDAL->GetVolumeName( SD_INTERNAL_SD, NULL, 0 );

	// Build filename and path for flash blocks, the size of the NV is built into
	// the filename, this will allow testing with different sizes without conflict.
	if(m_pDAL->IsRecorderEzTrend())
	{
		fileName.asprintf( (L"%sOEM\\OEM_Ez.SPL"), pRootVol );
	}
	else
	{
		fileName.asprintf( (L"%sOEM\\OEM.SPL"), pRootVol );
	}

	CStorage file;
	FileException ex;

	// Try to open the splash screen to read, if it does not exist we don't need to program it
	if( file.Open( fileName, QFile::ReadOnly , &ex ) )
	{
		// Splash screen opened, so get the length
		int splashSize = static_cast<int>(file.size());
		
		// Check that the spash screen isn't too big 
		if( splashSize < SPALSH_SCREEN_MAX_SIZE )
		{
			// Allocate buffer
			byte *pSplashBuffer = new byte[splashSize+4];
			file.seek(0);	// Make sure file is at the beginning			
			file.Read( pSplashBuffer, splashSize );
			file.close();

			// Set-up block sizes to write
			int sizeToWrite = splashSize;
			/*int extraToWrite = NO_EXTRA_TO_WRITE;
			if( splashSize > BF_MAXSIZE )
			{
				sizeToWrite = BF_MAXSIZE;
				extraToWrite = splashSize - BF_MAXSIZE;
			}*/

			BOOL bRet = pfNORFlashStoreSplashScreen(pGlbDal->m_hInterfaceHandle, pSplashBuffer,sizeToWrite);
				
			// Write low block
			//ReadWriteBlock( FLASH_BLK_SPLASH_LO, pSplashBuffer, sizeToWrite, BF_WRITE );
			//if( extraToWrite != NO_EXTRA_TO_WRITE )
			//{
			//	// Extra data to write so used high block
			//	char * pNewPosition = pSplashBuffer+BF_MAXSIZE;		
			//	ReadWriteBlock( FLASH_BLK_SPLASH_HI, pNewPosition, extraToWrite, BF_WRITE );
			//}

			delete [] pSplashBuffer;
			newSplashScreen = bRet;


		}
		// Set file attributes before trying to remove
		CFileStatus status;
		QFile::GetStatus( fileName, status );
		status.m_attribute = 0x00;
		QFile::SetStatus( fileName, status );
		// Remove the file
		file.Remove(fileName); 	
	}
#endif
	return newSplashScreen;
}

//**********************************************************************
///
/// Set a complete flash block to 0, only used for testing or a complete
/// back to factory reset of the recorder.
///
/// @param[in]		blockNum - number of flash block using T_FLASH_BLOCK see flash.h
///
/// @return		nothing
/// 
//**********************************************************************
void CFlashManager::ClearFlashBlock(T_FLASH_BLOCK blockNum) {
	BYTE *pCleanBlock = new BYTE[BF_MAXSIZE];
	memset(pCleanBlock, 0, sizeof(BYTE));
	WriteBlock(blockNum, pCleanBlock, BF_MAXSIZE, TRUE);
	delete[] pCleanBlock;
}

///***************************************************************************************
// FLASH BLOCK TEST SECTION
///***************************************************************************************

struct testFlashBlock {
	int a;
	int b;
	int c;
};

/// Flash test caddy
void FlashtestCaddy() {
	CFlashManager *pFlash;
	pFlash = CFlashManager::GetHandle();

	struct testFlashBlock testblk;
	T_FLASH_STATUS retVal;

	pFlash->CheckIntegrityAndRepair();

	ULONG size = pFlash->GetDataBlockSize(FLASH_BLK_TEST);
	if (size != sizeof(struct testFlashBlock)) {
		qDebug("Flash data size different\n");
	}

	retVal = pFlash->ReadBlock(FLASH_BLK_TEST, &testblk, sizeof(struct testFlashBlock));

	if (retVal == FLASH_STATUS_FIRSTUSE) {
		testblk.a = 1;
		testblk.b = 2;
		testblk.c = 3;
		pFlash->WriteBlock(FLASH_BLK_TEST, &testblk, sizeof(struct testFlashBlock));
		qDebug("Flash block first use \n", retVal);
	} else if (retVal == FLASH_STATUS_CRCFAIL) {
		qDebug("Flash block CRC failed\n");
		testblk.a = 1;
		testblk.b = 2;
		testblk.c = 3;
		pFlash->WriteBlock(FLASH_BLK_TEST, &testblk, sizeof(struct testFlashBlock));
		qDebug("Flash block CRC failed \n", retVal);
	} else if (retVal != FLASH_STATUS_OKAY) {
		qDebug("Flash block failed with error %d\n", retVal);
	} else {
		qDebug("Flash block successful a=%d, b=%d c=%d\n", retVal, testblk.a, testblk.b, testblk.c);

	}
}


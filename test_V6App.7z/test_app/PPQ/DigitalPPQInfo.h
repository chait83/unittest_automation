#pragma once
#include "PPQCommon.h"
#include "CStorage.h"
class CDigitalPPQInfo {
public:
	CDigitalPPQInfo(void);
	virtual ~CDigitalPPQInfo(void);
	///< Trace the PPQ Info to a File for analysis
	void TracePPQInfoToFile(CStorage &PPQInfoFile, T_PPQC_DIGITAL_PPQ_TYPE type, T_PPQC_ACQUSITION_RATE acquistionRate,
			T_PPQC_STATUS status);
	// For Speed and Efficiency and to avoid additional overheads these member are made
	// public. The member variables are used to store data for debug purposes. 
	USHORT m_InitialInputCardTick;
	LONGLONG m_InitialSystemTick;
	USHORT m_FirstTimestampedReadingDITick;	///< First Reading Timestamp in AI Ticks 
	SHORT m_FirstReadingTickDifference;	///< First Reading Tick Difference between Initial AI Tick
};
// End of Class Declaration
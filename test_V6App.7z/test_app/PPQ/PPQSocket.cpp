// PPQSocket.cpp : implementation file
//
//#include "PPQUI.h"
#include "PPQSocket.h"
#include "PPQMessages.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
#ifdef PPQQAbstractSocket_ENABLED
CAsyncSocket* CPPQSocket::m_pSocket = new CAsyncSocket;
BYTE *CPPQSocket::m_pSendBuffer = new BYTE[50];
BYTE *CPPQSocket::m_pDataProcessingBuffer = new BYTE[50];
// CPPQSocket
CPPQSocket::CPPQSocket()
{
}
CPPQSocket::~CPPQSocket()
{
}

// CPPQSocket member functions
void CPPQSocket::CreateSocket()
{
  AfxSocketInit();
  m_pSocket->Create(); 
}
void CPPQSocket::Connect()
{
  //m_pSocket->Connect( L"127.0.0.1", 5001 );
	m_pSocket->Connect( L"160.221.36.3", 5001 );
}
void CPPQSocket::CloseSocket()
{
  m_pSocket->Close();
  delete( m_pSendBuffer );
  delete( m_pSocket );
  delete( m_pDataProcessingBuffer );
}
void CPPQSocket::SendEnablePPQMsg( T_PPQC_STATUS status,
  T_PPQC_QUEUE_TYPE type, 
  USHORT reference, 
  T_PPQC_ACQUSITION_RATE acqRate,
  T_PPQC_APCARD_TICK_RATE clockTickRate )
{
  
  T_PPQUI_MSG *pMsgToSend = (T_PPQUI_MSG*)m_pSendBuffer;
  
  pMsgToSend->msgType = PPQUI_ANALOGUE_ENABLEPPQ;
  pMsgToSend->msgLength = sizeof(T_PPQUI_MSG) + sizeof( T_PPQUI_ANALOGUE_ENABLEPPQ_MSG ) - sizeof(DWORD);
  pMsgToSend->reference = reference;
  T_PPQUI_ANALOGUE_ENABLEPPQ_MSG *msgData = ( T_PPQUI_ANALOGUE_ENABLEPPQ_MSG*)pMsgToSend->data;
  
  msgData->status = status;
  msgData->type  = type;
  msgData->acquistionRate = acqRate;
  msgData->clockTickRate = clockTickRate;
  m_pSocket->Send( m_pSendBuffer, pMsgToSend->msgLength );
  
} // End of Member Function 

void CPPQSocket::SendSyncPPQMsg( USHORT reference, LONGLONG minSysCoverage, LONGLONG maxSysCoverage, T_PPQC_STATUS status )
{
  T_PPQUI_MSG *pMsgToSend = (T_PPQUI_MSG*)m_pSendBuffer;
  int bytesSent = 0;
  
  pMsgToSend->msgType = PPQUI_ANALOGUE_SYNCPPQ;
  pMsgToSend->msgLength = sizeof(T_PPQUI_MSG) + sizeof( T_PPQUI_ANALOGUE_SYNCPPQ_MSG ) - sizeof(DWORD);
  pMsgToSend->reference = reference;
  T_PPQUI_ANALOGUE_SYNCPPQ_MSG *msgData = ( T_PPQUI_ANALOGUE_SYNCPPQ_MSG*)pMsgToSend->data;
  
  msgData->maxSysCoverage = maxSysCoverage;
  msgData->minSysCoverage = minSysCoverage;
  msgData->status = status;
  m_pSocket->Send( m_pSendBuffer, pMsgToSend->msgLength );

} // End of Member Function 
void CPPQSocket::SendAddTimestampedReadingMsg( USHORT reference,USHORT lastPredictedAITick,USHORT lastActualAITick, SHORT lastTickDifference )
{
  T_PPQUI_MSG *pMsgToSend = (T_PPQUI_MSG*)m_pSendBuffer;
  	int bytesSent = 0;
  pMsgToSend->msgType = PPQUI_ANALOGUE_ADDTIMESTAMPREADING;
  pMsgToSend->msgLength = ( sizeof(T_PPQUI_MSG) + sizeof( T_PPQUI_ANALOGUE_ADDTIMESTAMPREADING_MSG ) ) - sizeof(DWORD);
  pMsgToSend->reference = reference;

	T_PPQUI_ANALOGUE_ADDTIMESTAMPREADING_MSG *msgData = ( T_PPQUI_ANALOGUE_ADDTIMESTAMPREADING_MSG*)pMsgToSend->data;
  
  msgData->lastPredictedAITick = lastPredictedAITick;
  msgData->lastActualAITick  = lastActualAITick;
  msgData->lastTickDifference = lastTickDifference;
  m_pSocket->Send( m_pSendBuffer, pMsgToSend->msgLength );
} // End of Member Function 
void CPPQSocket::SendAddReadingMsg( USHORT reference,USHORT rear,USHORT numOfReadings,FLOAT reading, LONGLONG maxSysCoverage )
{
  T_PPQUI_MSG *pMsgToSend = (T_PPQUI_MSG*)m_pSendBuffer;
  int bytesSent = 0;
  pMsgToSend->msgType = PPQUI_ANALOGUE_ADDREADING;
  pMsgToSend->msgLength = ( sizeof(T_PPQUI_MSG) + sizeof( T_PPQUI_ANALOGUE_ADDREADING_MSG ) ) - sizeof(DWORD);
  pMsgToSend->reference = reference;
  T_PPQUI_ANALOGUE_ADDREADING_MSG *msgData = ( T_PPQUI_ANALOGUE_ADDREADING_MSG*)pMsgToSend->data;
  msgData->rear  = rear;
  msgData-> numOfReadings = numOfReadings;
  msgData->reading  = reading;
  msgData->maxSysCoverage = maxSysCoverage;
  m_pSocket->Send( m_pSendBuffer, pMsgToSend->msgLength );
} // End of Member Function 
void CPPQSocket::SendDisablePPQMsg( USHORT reference )
{
} // End of Member Function 	
void CPPQSocket::SendGetReadingMsg( USHORT reference, USHORT front, USHORT numOfReadings )
{
  T_PPQUI_MSG *pMsgToSend = (T_PPQUI_MSG*)m_pDataProcessingBuffer;
  
	int bytesSent = 0;
  pMsgToSend->msgType = PPQUI_ANALOGUE_GETREADING;
  pMsgToSend->msgLength = ( sizeof(T_PPQUI_MSG) + sizeof( T_PPQUI_ANALOGUE_GETREADING_MSG ) ) - sizeof(DWORD);
  pMsgToSend->reference = reference;
  T_PPQUI_ANALOGUE_GETREADING_MSG *msgData = ( T_PPQUI_ANALOGUE_GETREADING_MSG*)pMsgToSend->data;
  msgData->front = front;
  msgData->numOfReadings = numOfReadings;
	m_pSocket->Send( m_pDataProcessingBuffer, pMsgToSend->msgLength );
} // End of Member Function 

void CPPQSocket::SendErrorMsg( USHORT reference, T_PPQUI_ERROR_CODE errorCode )
{
	T_PPQUI_MSG *pMsgToSend = (T_PPQUI_MSG*)m_pSendBuffer;
  
  pMsgToSend->msgType = PPQUI_REPORT_ERROR;
  pMsgToSend->msgLength = sizeof(T_PPQUI_MSG) + sizeof( T_PPQUI_ERROR_MSG ) - sizeof(DWORD);
  pMsgToSend->reference = reference;
  T_PPQUI_ERROR_MSG *msgData = ( T_PPQUI_ERROR_MSG*)pMsgToSend->data;
  msgData->errorCode = errorCode;
  m_pSocket->Send( m_pSendBuffer, pMsgToSend->msgLength );
} // End of Member Function 
	
#endif		// PPQQAbstractSocket_ENABLED

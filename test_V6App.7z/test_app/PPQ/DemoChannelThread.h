#ifndef _CDEMOCHANNELTHREAD_H
#define _CDEMOCHANNELTHREAD_H
// CDemoChannelThread
#include <QThread>
#include "Defines.h"
class CDemoChannelThread: public QThread {
	// DECLARE_DYNCREATE (CDemoChannelThread)
protected:
	CDemoChannelThread();  // protected constructor used by dynamic creation
	virtual ~CDemoChannelThread();
public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
public:
	static UINT ThreadFunc(LPVOID lpParam);
};
#endif

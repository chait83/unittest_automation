#include "AnaloguePulsePPQInfo.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
CAnaloguePulsePPQInfo::CAnaloguePulsePPQInfo(void) {
	// Initialise PPQ Info Member Variables
	m_InitialMinSystemCoverage = 0;
	m_InitialAITick = 0;
	m_FirstTimestampedReadingAITick = 0;
	m_FirstReadingTickDifference = 0;
	m_MinCoverageAfterSync = 0;
	m_PredictedAITickAfterSync = 0;
	m_SysTickToBeginProcess = 0;
	m_SetPosTickIncrement = 0;
	m_NumOfMissedReadings = 0;
	m_NumOfAdditionalReadingInserted = 0;
	m_NumOfDroppedReadings = 0;
} // End of Constructor
CAnaloguePulsePPQInfo::~CAnaloguePulsePPQInfo(void) {
} // End of Destructor
///< Trace the PPQ Info to a File for analysis
void CAnaloguePulsePPQInfo::TracePPQInfoToFile(CStorage &PPQInfoFile, T_PPQC_QUEUE_TYPE type, USHORT reference,
		T_PPQC_ACQUSITION_RATE acquistionRate, T_PPQC_STATUS status) {
	QString fileString("");
	fileString = QString::asprintf("%d,", reference);
	PPQInfoFile.Write(fileString.toLocal8Bit().data(), fileString.size() * sizeof(TCHAR));
	switch (type) {
	case PPQC_ANALOGUE:
		fileString = QString::asprintf("ANALOGUE,");
		break;
	case PPQC_HIPULSE:
		fileString = QString::asprintf("HIPULSE,");
		break;
	case PPQC_LOPULSE:
		fileString = QString::asprintf("LOPULSE,");
		break;
	default:
		fileString = QString::asprintf("ERROR,");
		break;
	} // End of SWITCH
	PPQInfoFile.Write(fileString.toLocal8Bit().data(), fileString.size() * sizeof(TCHAR));
	switch (acquistionRate) {
	case PPQC_1HZ:
		fileString = QString::asprintf("1HZ,");
		break;
	case PPQC_2HZ:
		fileString = QString::asprintf("2HZ,");
		break;
	case PPQC_5HZ:
		fileString = QString::asprintf("5HZ,");
		break;
	case PPQC_10HZ:
		fileString = QString::asprintf("10HZ,");
		break;
	case PPQC_50HZ:
		fileString = QString::asprintf("50HZ,");
		break;
	default:
		fileString = QString::asprintf("ERROR,");
		break;
	} // End of SWITCH
	PPQInfoFile.Write(fileString.toLocal8Bit().data(), fileString.size() * sizeof(TCHAR));
	fileString = QString::asprintf("%d,", m_InitialMinSystemCoverage);
	PPQInfoFile.Write(fileString.toLocal8Bit().data(), fileString.size() * sizeof(TCHAR));
	fileString = QString::asprintf("%u,", m_InitialAITick);
	PPQInfoFile.Write(fileString.toLocal8Bit().data(), fileString.size() * sizeof(TCHAR));
	fileString = QString::asprintf("%u,", m_FirstTimestampedReadingAITick);
	PPQInfoFile.Write(fileString.toLocal8Bit().data(), fileString.size() * sizeof(TCHAR));
	fileString = QString::asprintf("%d,", m_FirstReadingTickDifference);
	PPQInfoFile.Write(fileString.toLocal8Bit().data(), fileString.size() * sizeof(TCHAR));
	fileString = QString::asprintf("%d,", m_MinCoverageAfterSync);
	PPQInfoFile.Write(fileString.toLocal8Bit().data(), fileString.size() * sizeof(TCHAR));
	fileString = QString::asprintf("%u,", m_PredictedAITickAfterSync);
	PPQInfoFile.Write(fileString.toLocal8Bit().data(), fileString.size() * sizeof(TCHAR));
	fileString = QString::asprintf("%d,", m_SysTickToBeginProcess);
	PPQInfoFile.Write(fileString.toLocal8Bit().data(), fileString.size() * sizeof(TCHAR));
	fileString = QString::asprintf("%u,", m_SetPosTickIncrement);
	PPQInfoFile.Write(fileString.toLocal8Bit().data(), fileString.size() * sizeof(TCHAR));
	fileString = QString::asprintf("%u,", m_NumOfMissedReadings);
	PPQInfoFile.Write(fileString.toLocal8Bit().data(), fileString.size() * sizeof(TCHAR));
	fileString = QString::asprintf("%u,", m_NumOfAdditionalReadingInserted);
	PPQInfoFile.Write(fileString.toLocal8Bit().data(), fileString.size() * sizeof(TCHAR));
	fileString = QString::asprintf("%u", m_NumOfDroppedReadings);
	PPQInfoFile.Write(fileString.toLocal8Bit().data(), fileString.size() * sizeof(TCHAR));
	fileString = QString::asprintf("%c%c", 0x0D, 0x0A);
	PPQInfoFile.Write(fileString.toLocal8Bit().data(), fileString.size() * sizeof(TCHAR));
} // End of Member Function												

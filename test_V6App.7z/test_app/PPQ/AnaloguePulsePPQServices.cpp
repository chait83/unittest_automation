#include "AnaloguePulsePPQServices.h"
#include "V6globals.h"
#include "limits.h"
#include "DAL.h"
#include "InputConditioning.h"
#include "PPIOServiceManager.h"
CAnaloguePulsePPQServices::CAnaloguePulsePPQServices(void) {
	m_NextAvailablePPQ = APPPQSER_ZERO;
	m_MaxPPQsAvailable = APPPQSER_ZERO;
	m_MaxAcqusitionRate = PPQC_1HZ;
	m_NumOfEnabledPPQs = APPPQSER_ZERO;
	QMutex * m_csAnalPulsePPQService;
	//m_AlignPPQs = TRUE;
} // End of Constructor
CAnaloguePulsePPQServices::~CAnaloguePulsePPQServices(void) {
	for (USHORT PPQIndex = APPPQSER_ZERO; PPQIndex < m_MaxPPQsAvailable; ++PPQIndex) {
		if (NULL != m_pAnaloguePulsePPQ.at(PPQIndex)) {
			delete (m_pAnaloguePulsePPQ.at(PPQIndex));
		} // End of IF
	} // End of FOR
	m_pAnaloguePulsePPQ.clear();
	//deletion of mutex not required
} // End of Destructor
//****************************************************************************
// GetDroppedReadingCount( )
///
/// Get the number of dropped readings since the last power-on
/// @param[in] hPPQ - PPQ handle
///
/// @return The number of dropped readings
/// 
//**************************************************************************** 
ULONG CAnaloguePulsePPQServices::GetDroppedReadingCount(USHORT hPPQ) {
	return m_pAnaloguePulsePPQ.at(hPPQ)->GetDroppedReadingCount();
}
//****************************************************************************
// GetDroppedReadingCount( )
///
/// Get the number of readings that have been inserted since the last power-on
/// @param[in] hPPQ - PPQ handle
///
/// @return The number of inserted readings
/// 
//**************************************************************************** 
ULONG CAnaloguePulsePPQServices::GetInsertedReadingCount(USHORT hPPQ) {
	return m_pAnaloguePulsePPQ.at(hPPQ)->GetInsertedReadingCount();
}
//****************************************************************************
// GetUnprocessedCoverage( )
///
/// Get the amount of unprocessed coverage from the queue
/// @param[in] hPPQ - PPQ handle
///
/// @return The unprocessed coverage in the queue
/// 
//**************************************************************************** 
ULONG CAnaloguePulsePPQServices::GetUnprocessedCoverage(USHORT hPPQ) {
	return m_pAnaloguePulsePPQ.at(hPPQ)->GetUnprocessedCoverage();
}
T_PPQSER_RETURN_VALUE CAnaloguePulsePPQServices::RequestPPQ(USHORT &hPPQ) {
	T_PPQSER_RETURN_VALUE retValue = PPQSER_NO_PPQ_AVAILABLE;
	hPPQ = 0xFFFF;
	if (m_MaxPPQsAvailable != m_NextAvailablePPQ) {
		hPPQ = m_NextAvailablePPQ;
		++m_NextAvailablePPQ;
		retValue = PPQSER_OK;
	}
	return (retValue);
} // End of Member Function
T_PPQSER_RETURN_VALUE CAnaloguePulsePPQServices::EnablePPQ(USHORT hPPQ, T_PPQC_QUEUE_TYPE type, USHORT reference,
		T_PPQC_ACQUSITION_RATE acqusitionRate, T_PPQC_APCARD_TICK_RATE clockTickRate) {
	T_PPQSER_RETURN_VALUE retValue = ValidPPQHandler(hPPQ);
	if (PPQSER_OK == retValue) {
		if (m_MaxAcqusitionRate < acqusitionRate) {
			m_MaxAcqusitionRate = acqusitionRate;
		}
		m_pAnaloguePulsePPQ.at(hPPQ)->EnablePPQ(type, reference, acqusitionRate, clockTickRate);
		++m_NumOfEnabledPPQs;
	}
	return (retValue);
} // End of Member Function									
T_PPQSER_RETURN_VALUE CAnaloguePulsePPQServices::DisablePPQ(USHORT hPPQ) {
	T_PPQSER_RETURN_VALUE retValue = ValidPPQHandler(hPPQ);
	if (PPQSER_OK == retValue) {
		m_pAnaloguePulsePPQ.at(hPPQ)->DisablePPQ();
		--m_NumOfEnabledPPQs;
	}
	return (retValue);
} // End of Member Function
T_PPQSER_RETURN_VALUE CAnaloguePulsePPQServices::SyncPPQ(USHORT hPPQ, USHORT inputCardTick, LONGLONG systemTick) {
	T_PPQSER_RETURN_VALUE retValue = ValidPPQHandler(hPPQ);
	if (PPQSER_OK == retValue) {
		m_pAnaloguePulsePPQ.at(hPPQ)->SyncPPQ(inputCardTick, systemTick);
	} // End of IF
	return (retValue);
} // End of Member Function										
T_PPQSER_RETURN_VALUE CAnaloguePulsePPQServices::ResetPPQ(USHORT hPPQ) {
	T_PPQSER_RETURN_VALUE retValue = ValidPPQHandler(hPPQ);
	if (PPQSER_OK == retValue) {
		m_pAnaloguePulsePPQ.at(hPPQ)->ResetPPQ();
	} // End of IF
	return (retValue);
} // End of Member Function 
T_PPQSER_RETURN_VALUE CAnaloguePulsePPQServices::AddTimeStampedReading(USHORT hPPQ, FLOAT reading,
		USHORT analoguePulseInputTick) {
	m_csAnalPulsePPQService.lock();
	T_PPQSER_RETURN_VALUE retValue = ValidPPQHandler(hPPQ);
	if (PPQSER_OK == retValue) {
		m_pAnaloguePulsePPQ.at(hPPQ)->AddTimeStampedReading(reading, analoguePulseInputTick);
	} // End of IF
	m_csAnalPulsePPQService.lock();
	return (retValue);
} // End of Member Function
//****************************************************************************
// IsPPQOperational( )
///
/// Get the operational status of the PPQ
/// @param[in] hPPQ - PPQ handle
///
/// @return TRUE if Pre Process Queue Syncronised Successfully; otherwise FALSE
/// 
//**************************************************************************** 
BOOL CAnaloguePulsePPQServices::IsPPQOperational(USHORT hPPQ) {
	return m_pAnaloguePulsePPQ.at(hPPQ)->IsPPQOperational();
}
//****************************************************************************
// GetPPQOperationalState( )
///
/// Get the operational status of the PPQ
/// @param[in] hPPQ - PPQ handle
///
/// @return The operational state of the PPQ
/// 
//**************************************************************************** 
UCHAR CAnaloguePulsePPQServices::GetPPQOperationalState(USHORT hPPQ) {
	return m_pAnaloguePulsePPQ.at(hPPQ)->GetPPQOperationalState();
}
//****************************************************************************
// GetReference( )
///
/// Get the system channel the PPQ is allocated to
/// @param[in] hPPQ - PPQ handle
///
/// @return The system channel reference
/// 
//**************************************************************************** 
USHORT CAnaloguePulsePPQServices::GetReference(USHORT hPPQ) {
	return m_pAnaloguePulsePPQ.at(hPPQ)->GetReference();
}
T_PPQSER_RETURN_VALUE CAnaloguePulsePPQServices::AddReading(USHORT hPPQ, FLOAT reading) {
	m_csAnalPulsePPQService.lock();
	T_PPQSER_RETURN_VALUE retValue = ValidPPQHandler(hPPQ);
	if (PPQSER_OK == retValue) {
		m_pAnaloguePulsePPQ.at(hPPQ)->AddReading(reading);
	} // End of IF
	m_csAnalPulsePPQService.lock();
	return (retValue);
} // End of Member Function		
T_PPQSER_RETURN_VALUE CAnaloguePulsePPQServices::AddMissedReading(USHORT hPPQ) {
	m_csAnalPulsePPQService.lock();
	T_PPQSER_RETURN_VALUE retValue = ValidPPQHandler(hPPQ);
	if (PPQSER_OK == retValue) {
		m_pAnaloguePulsePPQ.at(hPPQ)->AddMissedReading();
	} // End of IF
	m_csAnalPulsePPQService.lock();
	return (retValue);
} // End of Member Function 
T_PPQSER_RETURN_VALUE CAnaloguePulsePPQServices::ValidPPQHandler(USHORT hPPQ) {
	T_PPQSER_RETURN_VALUE retValue = PPQSER_INVALID_PPQ_HANDLE;
	if (hPPQ < m_NextAvailablePPQ) {
		retValue = PPQSER_OK;
	} // End of IF
	return (retValue);
} // End of Member Function		
T_PPQSER_RETURN_VALUE CAnaloguePulsePPQServices::Initialise(USHORT maxPPQsAvailable) {
	T_PPQSER_RETURN_VALUE retValue = PPQSER_OK;
	m_MaxPPQsAvailable = maxPPQsAvailable;
	m_pAnaloguePulsePPQ.SetSize(m_MaxPPQsAvailable);
	for (USHORT PPQIndex = APPPQSER_ZERO; PPQIndex < m_MaxPPQsAvailable; ++PPQIndex) {
		m_pAnaloguePulsePPQ.SetAt(PPQIndex, new CAnaloguePulsePPQ());
		if (NULL == m_pAnaloguePulsePPQ.at(PPQIndex)) {
			retValue = PPQSER_CREATION_FAILED;
		} // End of IF
	} // End of FOR
	return (retValue);
} // End of Member Function		
T_PPQSER_RETURN_VALUE CAnaloguePulsePPQServices::SetTickToBeginProcessing(LONGLONG initialSystemTick) {
	for (USHORT PPQIndex = APPPQSER_ZERO; PPQIndex < m_NextAvailablePPQ; ++PPQIndex) {
		// only allow queues to start if they have been initialised correctly
		if (PPQC_STATUS_OPERATIONAL == m_pAnaloguePulsePPQ.at(PPQIndex)->GetStatus()) {
			m_pAnaloguePulsePPQ.at(PPQIndex)->SetPosToBeginProcessing(initialSystemTick);
		} // End of IF 
	} // End of FOR
	return (PPQSER_OK);
} // End of Member Function	
LONGLONG CAnaloguePulsePPQServices::GetMinSysTickCoverage(void) {
	LONGLONG minCoverage = APPPQSER_NO_ENABLED_PPQS;
	m_csAnalPulsePPQService.lock();
	if (APPPQSER_ZERO != m_NumOfEnabledPPQs) {
		LONGLONG tempMinCoverage = APPPQSER_ZERO;
		USHORT numOfPPQsWithCoverage = APPPQSER_ZERO;
		for (USHORT PPQIndex = APPPQSER_ZERO; PPQIndex < m_NextAvailablePPQ; ++PPQIndex) {
			if (PPQC_STATUS_OPERATIONAL == m_pAnaloguePulsePPQ.at(PPQIndex)->GetStatus()) {
				m_pAnaloguePulsePPQ.at(PPQIndex)->GetMinSystemTickCoverage(tempMinCoverage);
				if (tempMinCoverage > minCoverage) {
					minCoverage = tempMinCoverage;
				} // End of IF
				++numOfPPQsWithCoverage;
			} // End of IF 
		} // End of FOR 
		if (numOfPPQsWithCoverage != m_NumOfEnabledPPQs) {
			minCoverage = APPPQSER_ZERO;
		} // End of IF
	} // End of IF 
	m_csAnalPulsePPQService.lock();
	return (minCoverage);
} // End of Member Function		
LONGLONG CAnaloguePulsePPQServices::GetMaxSysTickCoverage(void) {
	LONGLONG maxCoverage = APPPQSER_NO_ENABLED_PPQS;
	USHORT maxCovergeAvailable = 0;
	USHORT maxCovergeAvailableQueueId = 0;
	m_csAnalPulsePPQService.lock();
	if (APPPQSER_ZERO != m_NumOfEnabledPPQs) {
		maxCoverage = _I64_MAX;
		LONGLONG tempMaxCoverage = APPPQSER_ZERO;
		USHORT numOfPPQsWithCoverage = APPPQSER_ZERO;
		for (USHORT PPQIndex = APPPQSER_ZERO; PPQIndex < m_NextAvailablePPQ; ++PPQIndex) {
			if (PPQC_STATUS_OPERATIONAL == m_pAnaloguePulsePPQ.at(PPQIndex)->GetStatus()) {
				m_pAnaloguePulsePPQ.at(PPQIndex)->GetMaxSystemTickCoverage(tempMaxCoverage);
				if (tempMaxCoverage > maxCovergeAvailable) {
					maxCovergeAvailableQueueId = PPQIndex;
					maxCovergeAvailable = static_cast<USHORT>(tempMaxCoverage);
				}
				if (tempMaxCoverage < maxCoverage) {
					maxCoverage = tempMaxCoverage;
				} // End of IF
				++numOfPPQsWithCoverage;
			} // End of IF
		} // End of FOR	
		if (numOfPPQsWithCoverage != m_NumOfEnabledPPQs) {
			maxCoverage = APPPQSER_ZERO;
		} // End of IF
	} // End of IF
//	qDebug("MaxCoverAvail %d, PPQ %d, CovAvaiFromAllPPQs: %d\n", (ULONG)maxCovergeAvailable, maxCovergeAvailableQueueId, (ULONG)maxCoverage );
	m_csAnalPulsePPQService.lock();
	return (maxCoverage);
} // End of Member Function		
T_PPQSER_RETURN_VALUE CAnaloguePulsePPQServices::PopulateDataItemTable(USHORT tickIncrement) {
	CSlotMap *pSlotMap = NULL;
	CAnaloguePulsePPQ *pAPPPQ = NULL;
	class CPPIOServiceManager *pServiceManagerObj = NULL;	///< Service manager
	class CInputConditioning *pICService = NULL;	///< Input conditioning service
	T_DATAITEM_STATUS status = DISTAT_NORMAL;
	//float reading = 0.0F;
	float reading = FLT_MIN;
	USHORT dataItem = 0;
	m_csAnalPulsePPQService.lock();
	pServiceManagerObj = CPPIOServiceManager::GetHandle();
	if (pServiceManagerObj != NULL)
		pICService = pServiceManagerObj->GetICService();
	for (USHORT PPQIndex = APPPQSER_ZERO; PPQIndex < m_NextAvailablePPQ; ++PPQIndex) {
		pAPPPQ = m_pAnaloguePulsePPQ.at(PPQIndex);
		if (PPQC_STATUS_OPERATIONAL == pAPPPQ->GetStatus()) {
			// Setup Data item pointer first time only
			if (pAPPPQ->m_pDataItem == NULL) {
				switch (pAPPPQ->GetType()) {
				case PPQC_ANALOGUE:
					pAPPPQ->m_pDataItem = pGlbDIT->GetDataItemPtr(DI_IO, DI_IO_ANALOGUE, pAPPPQ->GetReference());
					break;
				case PPQC_HIPULSE:
					pAPPPQ->m_pDataItem = pGlbDIT->GetDataItemPtr(DI_IO, DI_IO_HIPULSE, pAPPPQ->GetReference());
					break;
				case PPQC_LOPULSE:
					pSlotMap = CSlotMap::GetHandle();
					pSlotMap->GetSysChannelFromPreProcessQueue(pAPPPQ->GetReference(), &dataItem);
					pAPPPQ->m_pDataItem = pGlbDIT->GetDataItemPtr(DI_IO, DI_IO_LOPULSE, dataItem);
					break;
				default: /* Error */
					break;
				}
			}
			if (pAPPPQ->m_pDataItem != NULL) {
				if (APPPQ_READING_UPDATE_REQUIRED
						== pAPPPQ->GetReading(reading, tickIncrement, pAPPPQ->GetFirstRun())) {
					pAPPPQ->ResetFirstRun();
					if (pICService->TestFloatError(reading) == TRUE) {
						// Set the status to the 'appropriate' error type
						status = pICService->ConvertFloatErrorToDITStatus(reading);
						pAPPPQ->m_pDataItem->SetStatus(status);
						// If not valid then ideally set the reading to 'error' value
						//reading = 0.0F;				///< Zero the reading - yuk
						//MarkD: value depends on error status, ie may need to be high or low
						switch (status) {
						case DISTAT_INPUT_UPSCALE_BURNOUT:
						case DISTAT_INPUT_OVERRANGE:
							reading = FLT_MAX;
							break;
						case DISTAT_INPUT_DOWNSCALE_BURNOUT:
						case DISTAT_INPUT_UNDERRANGE:
						case DISTAT_INVALID:
							reading = -FLT_MAX;
							break;
						default:
							reading = -FLT_MAX;
							break;
						}
						// @todo: after maths, error code may change
						// we have to decide the best way of showing an error when one input
						// goes into error
						// currently, adding A1 and A2 will trace zero if pen 1 is over-range and pen 2 is under-range
					} else {
						// If there was an I/O error that no longer exists then reset DIT status
						if (pAPPPQ->m_pDataItem->GetStatus() < DISTAT_NORMAL)
							pAPPPQ->m_pDataItem->SetStatus(DISTAT_NORMAL);
					}
					pAPPPQ->m_pDataItem->SetValue(reading);
				}
				reading = APPPQSER_ZERO;
			}
		}
	} // End for 
	m_csAnalPulsePPQService.lock();
	return (PPQSER_OK);
} // End of Member Function		
T_PPQC_ACQUSITION_RATE CAnaloguePulsePPQServices::GetMaxAcqusitionRate(void) {
	return (m_MaxAcqusitionRate);
} // End of Member Function		
T_PPQSER_RETURN_VALUE CAnaloguePulsePPQServices::ResetAllPPQs(void) {
	m_csAnalPulsePPQService.lock();
	for (USHORT PPQIndex = APPPQSER_ZERO; PPQIndex < m_MaxPPQsAvailable; ++PPQIndex) {
		if (NULL != m_pAnaloguePulsePPQ.at(PPQIndex)) {
			m_pAnaloguePulsePPQ.at(PPQIndex)->ResetPPQ();
			if (m_NextAvailablePPQ > 0)
				--m_NextAvailablePPQ;
			if (m_NumOfEnabledPPQs > 0)
				--m_NumOfEnabledPPQs;
		} // End of IF
	} // End of FOR
	m_csAnalPulsePPQService.lock();
	return (PPQSER_OK);
} // End of Member Function 
T_PPQSER_RETURN_VALUE CAnaloguePulsePPQServices::ResetToDefault(void) {
	T_PPQSER_RETURN_VALUE retValue = PPQSER_OK;
	// Reset Each Enabled Queue
	for (USHORT PPQIndex = APPPQSER_ZERO; PPQIndex < m_NumOfEnabledPPQs; ++PPQIndex) {
		if (NULL != m_pAnaloguePulsePPQ.at(PPQIndex)) {
			m_pAnaloguePulsePPQ.at(PPQIndex)->ResetPPQ();
		} // End of IF
	} // End of FOR
	// Reset Number of Enabled PPQs to Zero
	m_NumOfEnabledPPQs = APPPQSER_ZERO;
	m_NextAvailablePPQ = APPPQSER_ZERO;
	return (retValue);
} // End of Member Function
void CAnaloguePulsePPQServices::SaveToFileAllPPQInfo(CStorage &PPQInfoFile) {
	// Write the Column Headers
	QString columnHeader = "";
	columnHeader = "PPQ Number,";
	PPQInfoFile.Write(columnHeader.toLocal8Bit().data(), columnHeader.size() * sizeof(TCHAR));
	columnHeader = "PPQ Type,";
	PPQInfoFile.Write(columnHeader.toLocal8Bit().data(), columnHeader.size() * sizeof(TCHAR));
	columnHeader = "PPQ Acq Rate,";
	PPQInfoFile.Write(columnHeader.toLocal8Bit().data(), columnHeader.size() * sizeof(TCHAR));
	columnHeader = "InitialMinSysCov,";
	PPQInfoFile.Write(columnHeader.toLocal8Bit().data(), columnHeader.size() * sizeof(TCHAR));
	columnHeader = "InitialAITick,";
	PPQInfoFile.Write(columnHeader.toLocal8Bit().data(), columnHeader.size() * sizeof(TCHAR));
	columnHeader = "FirstTSReadingAITick,";
	PPQInfoFile.Write(columnHeader.toLocal8Bit().data(), columnHeader.size() * sizeof(TCHAR));
	columnHeader = "FirstReadingTickDifference,";
	PPQInfoFile.Write(columnHeader.toLocal8Bit().data(), columnHeader.size() * sizeof(TCHAR));
	columnHeader = "MinCoverageAfterSync,";
	PPQInfoFile.Write(columnHeader.toLocal8Bit().data(), columnHeader.size() * sizeof(TCHAR));
	columnHeader = "PredictedAITickAfterSync,";
	PPQInfoFile.Write(columnHeader.toLocal8Bit().data(), columnHeader.size() * sizeof(TCHAR));
	columnHeader = "SysTickToBeginProcessing,";
	PPQInfoFile.Write(columnHeader.toLocal8Bit().data(), columnHeader.size() * sizeof(TCHAR));
	columnHeader = "SetPosTickIncrement,";
	PPQInfoFile.Write(columnHeader.toLocal8Bit().data(), columnHeader.size() * sizeof(TCHAR));
	columnHeader = "NumOfMissedReadings,";
	PPQInfoFile.Write(columnHeader.toLocal8Bit().data(), columnHeader.size() * sizeof(TCHAR));
	columnHeader = "NumOfAdditionalReadingsInserted,";
	PPQInfoFile.Write(columnHeader.toLocal8Bit().data(), columnHeader.size() * sizeof(TCHAR));
	columnHeader = "NumOfDroppedReadings";
	PPQInfoFile.Write(columnHeader.toLocal8Bit().data(), columnHeader.size() * sizeof(TCHAR));
	columnHeader = QString::asprintf("%c%c", 0x0D, 0x0A);
	PPQInfoFile.Write(columnHeader.toLocal8Bit().data(), columnHeader.size() * sizeof(TCHAR));
	for (USHORT PPQIndex = APPPQSER_ZERO; PPQIndex < m_NextAvailablePPQ; ++PPQIndex) {
		if (NULL != m_pAnaloguePulsePPQ.at(PPQIndex)) {
			m_pAnaloguePulsePPQ.at(PPQIndex)->SavePPQInfoToFile(PPQInfoFile);
		} // End of IF
	} // End of FOR
	columnHeader = QString::asprintf("%c%c", 0x0D, 0x0A);
	PPQInfoFile.Write(columnHeader.toLocal8Bit().data(), columnHeader.size() * sizeof(TCHAR));
} // End of Member Function

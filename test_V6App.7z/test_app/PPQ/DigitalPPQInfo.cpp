#include "DigitalPPQInfo.h"
CDigitalPPQInfo::CDigitalPPQInfo(void) {
}
CDigitalPPQInfo::~CDigitalPPQInfo(void) {
}
///< Trace the PPQ Info to a File for analysis
void CDigitalPPQInfo::TracePPQInfoToFile(CStorage &PPQInfoFile, T_PPQC_DIGITAL_PPQ_TYPE type,
		T_PPQC_ACQUSITION_RATE acquistionRate, T_PPQC_STATUS status) {
	QString fileString("");
	switch (type) {
	case PPQC_DIGITAL_SLOT_1:
		fileString = QString::asprintf("DIGITAL SLOT 1,");
		break;
	case PPQC_DIGITAL_SLOT_2:
		fileString = QString::asprintf("DIGITAL SLOT 2,");
		break;
	case PPQC_DIGITAL_SLOT_3:
		fileString = QString::asprintf("DIGITAL SLOT 3,");
		break;
	default:
		fileString = QString::asprintf("ERROR,");
		break;
	} // End of SWITCH
	PPQInfoFile.Write(fileString.toLocal8Bit().data(), fileString.length() * sizeof(TCHAR));
	switch (acquistionRate) {
	case PPQC_1HZ:
		fileString = QString::asprintf("1HZ,");
		break;
	case PPQC_2HZ:
		fileString = QString::asprintf("2HZ,");
		break;
	case PPQC_5HZ:
		fileString = QString::asprintf("5HZ,");
		break;
	case PPQC_10HZ:
		fileString = QString::asprintf("10HZ,");
		break;
	case PPQC_50HZ:
		fileString = QString::asprintf("50HZ,");
		break;
	default:
		fileString = QString::asprintf("ERROR,");
		break;
	} // End of SWITCH
	PPQInfoFile.Write(fileString.toLocal8Bit().data(), fileString.length() * sizeof(TCHAR));
	fileString = QString::asprintf("%d,", m_InitialSystemTick);
	PPQInfoFile.Write(fileString.toLocal8Bit().data(), fileString.length() * sizeof(TCHAR));
	fileString = QString::asprintf("%u,", m_InitialInputCardTick);
	PPQInfoFile.Write(fileString.toLocal8Bit().data(), fileString.length() * sizeof(TCHAR));
	fileString = QString::asprintf("%u,", m_FirstTimestampedReadingDITick);
	PPQInfoFile.Write(fileString.toLocal8Bit().data(), fileString.length() * sizeof(TCHAR));
	fileString = QString::asprintf("%d,", m_FirstReadingTickDifference);
	PPQInfoFile.Write(fileString.toLocal8Bit().data(), fileString.length() * sizeof(TCHAR));
	fileString = QString::asprintf("%c%c", 0x0D, 0x0A);
	PPQInfoFile.Write(fileString.toLocal8Bit().data(), fileString.length() * sizeof(TCHAR));
} // End of Member Function					

#include "DigitalDemoChannel.h"
CDigitalDemoChannel::CDigitalDemoChannel(void) {
}
CDigitalDemoChannel::~CDigitalDemoChannel(void) {
}

#include "ppqservice.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
CPPQService::CPPQService(void) {
}
CPPQService::~CPPQService(void) {
}

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Storage/Media
/// @n Filename:  RecorderStorage.cpp
/// @n Description: Implementation of the CRecorderStorage class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  5 Stability Project 1.0.1.3 7/2/2011 5:00:17 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  4 Stability Project 1.0.1.2 7/1/2011 4:38:48 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  3 Stability Project 1.0.1.1 3/17/2011 3:20:40 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  2 Stability Project 1.0.1.0 2/15/2011 3:03:49 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// **************************************************************************
#include "RecorderStorage.h"
#include "V6MessageBoxDlg.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//****************************************************************************
//	CRecorderStorage()
///
/// Constructor
///
//****************************************************************************
CRecorderStorage::CRecorderStorage() : CStorage() {
}
//****************************************************************************
/// Storage object constructor
///
/// @return No return value from the object constructor
///
/// @note No initialisation is performed, owner must use Open() before use
//****************************************************************************
CRecorderStorage::CRecorderStorage(LPCTSTR lpszFileName, UINT nOpenFlags) : CStorage(lpszFileName, nOpenFlags) {
}
//****************************************************************************
//	~CRecorderStorage()
///
/// Destructor
///
//****************************************************************************
CRecorderStorage::~CRecorderStorage() {
}
//****************************************************************************
//	void ShowError( const QString  &rstrFUNC_NAME,	
//					const QString  &rstrFILENAME, 
//					QFileDevice::FileError &kEx )
///
/// Method that shows file exception errors
///
/// @param[in]		const QString  &rstrFUNC_NAME - The function name that generated the exception
/// @param[in]		const QString  &rstrFILENAME - The filename the error weas generated within
/// @param[in]		QFileDevice::FileError &kEx - The file exception generated
///
//****************************************************************************
void CRecorderStorage::ShowError(const QString &rstrFUNC_NAME, const QString &rstrFILENAME, QFileDevice::FileError &kEx) {
	WCHAR wcaError[100];
	kEx.GetErrorMessage(wcaError, 100);
	QString strError("");
	strError = QString::asprintf("%s, %s - %s", rstrFILENAME, rstrFUNC_NAME, wcaError);
	// log an diagnostic error always
	LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
	if (V6_RELEASE != RELEASE_PRODUCTION) {
		QString strTitle("CStorage Error");
		CV6MessageBoxDlg kMessageDlg(strTitle, strError, AfxGetApp()->m_pMainWnd);
		kMessageDlg.exec();
	}
}
//****************************************************************************
//	void ShowError( const QString  &rstrFUNC_NAME, const QString  &rstrFILENAME )
///
/// Method that shows non-file exception errors
///
/// @param[in]		const QString  &rstrFUNC_NAME - The function name that generated the exception
/// @param[in]		const QString  &rstrFILENAME - The filename the error weas generated within
///
//****************************************************************************
void CRecorderStorage::ShowError(const QString &rstrFUNC_NAME, const QString &rstrFILENAME) {
	QString strError("");
	strError = "Unhandled exception within " + rstrFILENAME + " " + rstrFUNC_NAME + " method.";
	// log an diagnostic error always
	LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
	if (V6_RELEASE != RELEASE_PRODUCTION) {
		QString strTitle("CStorage Error");
		CV6MessageBoxDlg kMessageDlg(strTitle, strError, AfxGetApp()->m_pMainWnd);
		kMessageDlg.exec();
	}
}
//****************************************************************************
//	const bool PromptUser( const QString  &rstrTITLE, const QString  &rstrMESSAGE )
///
/// Method that prompts the user with the passed in parameters
///
/// @param[in]		const QString  &rstrTITLE - The title of the prompt
/// @param[in]		const QString  &rstrMESSAGE - The message body of the prompt
///
/// @return			True if the user selected the OK button
///
//****************************************************************************
const bool CRecorderStorage::PromptUser(const QString &rstrTITLE, const QString &rstrMESSAGE) {
	bool bOK = false;
	// prompt the user with a v6 message box
	QString strOK("");
	strOK = tr("OK");
	QString strCancel("");
	strCancel = tr("Cance");
	CV6MessageBoxDlg kMessageDlg(rstrTITLE, rstrMESSAGE, strOK, strCancel, AfxGetApp()->m_pMainWnd);
	if (kMessageDlg.exec()) {
		bOK = true;
	}
	return bOK;
}
//****************************************************************************
//	const bool PromptUser( )
///
/// Method that prompts the user with an OK to overwrite existing message
///
/// @return			True if the user selected the OK button
///
//****************************************************************************
const bool CRecorderStorage::PromptOverwrite() {
	QString strTitle("");
	QString strMessage("");
	strTitle = tr("File Already Exists!!!");
	strMessage = tr("The file already exists. Do you wish to overwrite it?");
	return PromptUser(strTitle, strMessage);
}

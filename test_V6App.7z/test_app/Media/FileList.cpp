/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Media Manager
/// @n Filename:	FileList.cpp
/// @n Description: Wrapper class for file searching API calls CStorage::FindFirstFile/CStorage::FindNextFile/indexOfClose
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 19	Stability Project 1.14.1.3	7/2/2011 4:57:16 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 18	Stability Project 1.14.1.2	7/1/2011 4:38:17 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 17	Stability Project 1.14.1.1	3/17/2011 3:20:24 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 16	Stability Project 1.14.1.0	2/15/2011 3:03:04 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
// **************************************************************************
// FileList.cpp: implementation of the CFileList class.
//
//////////////////////////////////////////////////////////////////////
//#include "TestShell.h"
#include "V6globals.h"
#include "DAL.h"
#include "StoragePaths.h"				// Media storage paths translation class
#include "FileList.h"
#include "TraceDefines.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
//*************************************************************
/// Class Constructor.
///
/// @param[in]	pFileMask	file to search for, contains device, location (type) and file mask.
/// 
/// Constructs the file search path and mask, then locate the first find
///
/// @return none.
//*************************************************************
CFileList::CFileList(T_STORAGE_FILE *pFileMask) {
//	class CStoragePaths *pStoragePath = CStoragePaths::GetHandle();
//	CDeviceAbstraction *pDAL = CDeviceAbstraction::GetHandle();
//	pDAL->Initialise();
	WCHAR FullPath[MAX_PATH];
	int maxLen = MAX_PATH;
	m_indexOfHandle = INVALID_HANDLE_VALUE;
	// Construict the full file path and name
	pDALGLB->BuildPath(pFileMask->DeviceID, pFileMask->Location, m_FileName, FullPath, MAX_PATH);
	m_First = TRUE;
	m_indexOfHandle = CStorage::FindFirstFile(m_FileName, &m_indexOfData);
}
//*************************************************************
/// Class Destructor
///
/// Check if the search handle is valid, and if so close the search
///
/// @return none.
//*************************************************************
CFileList::~CFileList() {
	if (m_indexOfHandle != INVALID_HANDLE_VALUE)
		indexOfClose(m_indexOfHandle);
}
//*************************************************************
/// Get next file match
///
/// if this is the first call, just retuen the initial find results,
/// else search for the next file match.
///
/// @return pointer to a WIN32_FIND_DATA structure or NULL in event of a problem,
/// if NULL is returned the call must call GetLastError() to decide what happened
/// and may have to delete the CFileList object and start again.
//*************************************************************
WIN32_FIND_DATA* CFileList::Next() {
	BOOL result = TRUE;
	if (m_indexOfHandle != INVALID_HANDLE_VALUE) {
		if (m_First)
			m_First = FALSE;
		else
			result = CStorage::FindNextFile(m_indexOfHandle, &m_indexOfData);
		if (result)
			return &m_indexOfData;
		else
			return NULL;
	}
	return NULL;
}

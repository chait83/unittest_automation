/// @file
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Storage/Media
/// @n Filename:	CStorage.h
/// @n Description: Definition of the CStorage class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 18	Stability Project 1.15.1.1	7/2/2011 4:56:26 PM	Hemant(HAIL)
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 17	Stability Project 1.15.1.0	7/1/2011 4:27:02 PM	Hemant(HAIL)
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware.
// 16	V6 Firmware 1.15		4/4/2007 5:37:10 PM	Roger Dawson
//		Added the ability to view reports that have been generated in RTF
//		format on the recorder.
// 15	V6 Firmware 1.14		3/27/2007 5:33:18 PM	Roger Dawson
//		Added the report view dialog to the process reports menu.
// $
//
// **************************************************************************
#if !defined(__STORAGE_H__)
#define __STORAGE_H__
#include "Defines.h"
#include <QMutex>
#include <QFile>
#include<QDebug>
#include<QTime>
#include<QFileInfo>

#define CRC_BUFFER	(4*1024)		// CRC file calculation buffer
//**CStorage******************************************************************
///
/// @brief Provides the access point for the media manager
///
/// Wrapper class for the media API, also provides persistent transaction status
///
//****************************************************************************
typedef enum _Attribute {  normal = 0x00,
                           readOnly =  0x01,
                           hidden = 0x02,
                           system_file = 0x04,
                           volume = 0x08,
                           directory = 0x10,
                           archive = 0x20
                        }Attribute ;
typedef struct _SECURITY_ATTRIBUTES {
    DWORD nLength;
    LPVOID lpSecurityDescriptor;
    BOOL bInheritHandle;
} SECURITY_ATTRIBUTES, *PSECURITY_ATTRIBUTES, *LPSECURITY_ATTRIBUTES;
typedef struct _WIN32_FIND_DATAW {
    DWORD dwFileAttributes;
    FILETIME ftCreationTime;
    FILETIME ftLastAccessTime;
    FILETIME ftLastWriteTime;
    DWORD nFileSizeHigh;
    DWORD nFileSizeLow;
    DWORD dwOID;
    WCHAR cFileName[ MAX_PATH ];
} WIN32_FIND_DATA, *PWIN32_FIND_DATA, *LPWIN32_FIND_DATA;

class CFileStatus : public QFileInfo{
public:
    QDateTime m_ctime;          // creation date/time of file
    QDateTime m_mtime;          // last modification date/time of file
    QDateTime m_atime;          // last access date/time of file
    quint64 m_size;            // logical size of file in bytes
    BYTE m_attribute;       // logical OR of CFile::Attribute enum values
    BYTE _m_padding;        // pad the structure to a WORD
    QString m_szFullName; // absolute path name
};
class CStorage: public QFile {
public:
    static BOOL CreateDirectory( QString pathName, LPSECURITY_ATTRIBUTES lpSecurityAttributes);
    // QFile wrapper methods
    BOOL Open(QString Name, UINT Flags, QFileDevice::FileError *Error=nullptr);
    BOOL Open(LPCTSTR Name, UINT Flags, QFileDevice::FileError* Error=nullptr);
    void Close(void);
    UINT Read(void *Buffer, UINT Size);
    const DWORD Write(const void *pvBUFFER, UINT Size, bool bNotUsed = false);
    LONG Seek(LONG Offset,UINT from);
    unsigned long GetPosition(void);
    QString m_strFileName;
    static bool GetStatus(QString, CFileStatus* = nullptr);
    static bool SetStatus(QString, CFileStatus*);
#ifndef V6_CRC_DISABLE
    // Additional methods
    BOOL ValidateCRC();
    BOOL AddCRC();
#endif
    ULONG GetFileSize(TCHAR*Filename);
    BOOL FileExists(QString &filename);
    BOOL FileRead(TCHAR *FileName, void *Buffer, DWORD Size);
    BOOL FileWrite(TCHAR *FileName, void *Buffer, DWORD Size);
    QString GetFileName(){return m_strFileName;}
    //	void GoneBad() {m_bCloseOnDelete=FALSE;}; // ensure no exception on close
    static BOOL IsReadOnly(TCHAR *pPathAndFileName);
    static BOOL MakeFileWritable(TCHAR *pPathAndFileName);
    static BOOL DeleteFile(QString filename);
    static BOOL DeleteFile(TCHAR *pPathAndFileName);
    static void EnterStorageCS();
    static void LeaveStorageCS();
    //	CStorage( T_STORAGE_PATH type, QStringpName, T_STORAGE_DEVICE device );
    CStorage();
    CStorage(LPCTSTR lpszFileName, QFileDevice::OpenMode nOpenFlags);
    virtual ~CStorage();
    // Method used to copy files and display a warning should the copy fail
    const BOOL CopyFiles(const QString &strORIGINAL_FILE_PATH, const QString &rstrNEW_FILE_PATH,
                         const BOOL bFAIL_IF_EXISTS, const BOOL bPROMPT_OVERWRITE_IF_EXISTS);
    // Method that shows file exception errors
    virtual void ShowError(const TCHAR* rstrFUNC_NAME, const QString &rstrFILENAME, const QString &errormessage);
    virtual void ShowError(const TCHAR*rstrFUNC_NAME, const QString &rstrFILENAME, const std::exception &e);
protected:
    bool m_bLogexists;
    // Method that prompts the user with an OK to overwrite existing message
    virtual const bool PromptOverwrite();
    // Method that shows non-file exception errors
    virtual void ShowError(const QString &rstrFUNC_NAME, const QString &rstrFILENAME);
    virtual void Lock(); //Locking mechanism for the file operation
    virtual void Unlock(); //Locking mechanism for the file operartion
private:
    QFile* m_hFile;
#ifndef V6_CRC_DISABLE
    WORD GetCRC(BOOL hasCRC);
#endif
};
//**CDiskStorage******************************************************************
///
/// CDiskStorage class
///
//****************************************************************************
class CDiskStorage: public CStorage {
public:
    CDiskStorage(QMutex pCS );
    CDiskStorage(LPCTSTR lpszFileName, QIODevice::OpenMode nOpenFlags, QMutex pCS);
protected:
    virtual void Lock(); //Locking mechanism for the file operation
    virtual void Unlock(); //Locking mechanism for the file operartion
private:
    static QMutex m_pCS;
};
class CDebugFileLogger {
public:
    CDebugFileLogger(QString strFilePath, BOOL bNoRecycle = FALSE);
    CDebugFileLogger(QString strFilePath, BOOL bNoRecycle, ULONG ulnFileSize);
    void GetDateFormat(WORD type, int size, SYSTEMTIME *st, TCHAR* format, TCHAR* buf, int bufLen);
    void GetTimeFormat(WORD type, int size, SYSTEMTIME *st, TCHAR* format, TCHAR* buf, int bufLen);
    void GetLocalTime(SYSTEMTIME *st);
    ~CDebugFileLogger();
    BOOL WriteToDebugLogFile(QString strLogMessage);
    void flush(bool bClose = false);
    BOOL Open(QString Name, UINT Flags, QFileDevice::FileError *Error);
private:
    BOOL OpenDebugLogFile();
    BOOL CyclicWrite(QString strLogMessage);
    void LogException(const TCHAR* rstrFUNC_NAME,  std::exception &kEx);
    void LogException(const TCHAR* rstrFUNC_NAME);
private:
    QString m_strFilePath;
    CStorage m_fileDebugLog; ///Debug Log File
    BOOL m_bLogFileExists;
    BOOL m_bLogDbgMessage;
    ULONG m_ulnFileSize;
    QString m_strFileCreattionTime;
    DWORD m_dwGTCAtFileCreation;
    const ULONG m_ulnMaxFileSize;
    BOOL m_bFirstMsgForThisInstance;
    int m_nFlushThreshold;
    BOOL m_bNoRecycle;
    BOOL m_bReachedRecycleState;
    static bool m_bExcpetionLogEnable;
};
//**CStorageNC******************************************************************
///
/// CStorageNC class with no Critical Ssection for CTScheduleThread::GotMedia() and
///											CMediaManager::CheckSharedFolder()
///
//****************************************************************************
class CStorageNC: public CStorage {
public:
    CStorageNC();
    CStorageNC(LPCTSTR lpszFileName, UINT nOpenFlags);
    ~CStorageNC();
protected:
    virtual void Lock(); //Locking mechanism for the file operation
    virtual void Unlock(); //Locking mechanism for the file operartion
};
#endif // !defined(__STORAGE_H__)

/// @file
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Configuration System
/// @n Filename:  AlphaNumEditDlg.cpp
/// @n Description: Implementation for the CAlphaNumEditDlg class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  13  Stability Project 1.8.1.3 7/2/2011 4:55:20 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  12  Stability Project 1.8.1.2 7/1/2011 4:37:55 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  11  Stability Project 1.8.1.1 3/17/2011 3:20:08 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  10  Stability Project 1.8.1.0 2/15/2011 3:02:06 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// **************************************************************************
#include "AlphaNumEditDlg.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
//****************************************************************************
// CAlphaNumEditDlg( CWidget* pkParent )
///
/// Constructor
///
/// @param[in] 	  CWidget* pkParent - A pointer to the parent window
/// 
//****************************************************************************
CAlphaNumEditDlg::CAlphaNumEditDlg(CWidget *pParent /*=NULL*/) : CEditPanelDlg(L"ALPHA_NUM_SIP_DLG", pParent) {
	InitializeIP();
}
//****************************************************************************
// ~CAlphaNumEditDlg( )
///
/// Destructor
/// 
//****************************************************************************
CAlphaNumEditDlg::~CAlphaNumEditDlg() {
}
//****************************************************************************
// DoDataExchange()
///
/// Data Exchange method
///
//****************************************************************************
void CAlphaNumEditDlg::DoDataExchange(CDataItem *pDX) {
	CEditPanelDlg::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAlphaNumEditDlg)
	// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}
BEGIN_MESSAGE_MAP(CAlphaNumEditDlg, CEditPanelDlg)
//{{AFX_MSG_MAP(CAlphaNumEditDlg)
//}}AFX_MSG_MAP
END_MESSAGE_MAP()
//****************************************************************************
// BOOL OnInitDialog() 
///
/// OnInitDialog event handler
///
//****************************************************************************
BOOL CAlphaNumEditDlg::OnInitDialog()
{
	CEditPanelDlg::OnInitDialog();
	return TRUE; // return TRUE unless you set the focus to a control
				 // EXCEPTION: OCX Property Pages should return FALSE
}
//****************************************************************************
// void InitializeIP()
///
/// Method that initialises the edit panel member variables such as the bitmap and keymap
/// 
//****************************************************************************
void CAlphaNumEditDlg::InitializeIP() {
	BOOL bOK = FALSE;
	// Fill the POSITION_INFO structure
	POSITION_INFO PositionInfo;
	PositionInfo.XCoordinate = 0;	//x coordinate of the SIP
	PositionInfo.YCoordinate = 0;  //y coordinate of the SIP
	// get a handle on the OEM info class
	COEMInfo *pkOEMInfo = COEMInfo::Instance();
	SIZE_POSITION *pkSizePosInfo = NULL;
	pkSizePosInfo = reinterpret_cast<SIZE_POSITION*>(pkOEMInfo->GetPanelSPMap(V6RES_PANEL_GRAPHIC_FULLPANEL));
	KEY_MAP_INFO *pkKeyMapInfo = NULL;
	pkKeyMapInfo = reinterpret_cast<KEY_MAP_INFO*>(pkOEMInfo->GetPanelKeyMap(V6RES_PANEL_GRAPHIC_FULLPANEL));
	//bitmap information
	BITMAP_INFO BitmapInfo;
	BitmapInfo.pBmp = pkOEMInfo->GetPanelUpImage(V6RES_PANEL_GRAPHIC_FULLPANEL);
	ResPanel *ptPaneInfo = pkOEMInfo->GetPanelInfo(V6RES_PANEL_GRAPHIC_FULLPANEL);
	BitmapInfo.size = ptPaneInfo->graUp.size;
	// Temporary vairable used to hold colour information
	ResColour *pkColourInfo = NULL;
	//Display information
	DISPLAY_INFO DisplayInfo;
	T_DEV_TYPE devType = pGlbDal->GetDeviceType();
	wcscpy_s(DisplayInfo.TextFontInfo.FontName, sizeof(DisplayInfo.TextFontInfo.FontName) / sizeof(WCHAR), L"Tahoma"); //SIP layout text font name
	if (devType == DEV_ARISTOS_MINITREND)
		DisplayInfo.TextFontInfo.FontSize = 26; //Font size of the text for the SIP layout 
	else if (devType == DEV_ARISTOS_MULTIPLUS || devType == DEV_SCR_MINITREND)
		DisplayInfo.TextFontInfo.FontSize = 24; //Font size of the text for the SIP layout 
	else
		DisplayInfo.TextFontInfo.FontSize = 16; //Font size of the text for the SIP layout 
	pkColourInfo = pkOEMInfo->GetColour(V6RES_COLOUR_SIPKEYTXT); // font color of text for the SIP layout
	DisplayInfo.TextFontInfo.FontColor = pkColourInfo->pColor;
	wcscpy_s(DisplayInfo.EditFontInfo.FontName, sizeof(DisplayInfo.EditFontInfo.FontName) / sizeof(WCHAR), L"Tahoma"); // Edit box text font name
	if (devType == DEV_ARISTOS_MINITREND)
		DisplayInfo.EditFontInfo.FontSize = 26; //Font size of the text for the SIP layout 
	else if (devType == DEV_ARISTOS_MULTIPLUS || devType == DEV_SCR_MINITREND)
		DisplayInfo.EditFontInfo.FontSize = 24; //Font size of the text for the SIP layout 
	else
		DisplayInfo.EditFontInfo.FontSize = 16; //Font size of the text for the SIP layout 
	//DisplayInfo.EditFontInfo.FontSize	= 16; //Font size of the text for the edit box 
	pkColourInfo = pkOEMInfo->GetColour(V6RES_COLOUR_SIPEDITTXT); // Font color of text for the edit box
	DisplayInfo.EditFontInfo.FontColor = pkColourInfo->pColor;
	wcscpy_s(DisplayInfo.DescriptionFontInfo.FontName, sizeof(DisplayInfo.DescriptionFontInfo.FontName) / sizeof(WCHAR),
			L"Tahoma"); //Description field font name
	if (devType == DEV_ARISTOS_MINITREND)
		DisplayInfo.DescriptionFontInfo.FontSize = 20; //Font size of the text for the SIP layout 
	else if (devType == DEV_ARISTOS_MULTIPLUS || devType == DEV_SCR_MINITREND)
		DisplayInfo.DescriptionFontInfo.FontSize = 20; //Font size of the text for the SIP layout 
	else
		DisplayInfo.DescriptionFontInfo.FontSize = 16; //Font size of the text for the SIP layout 
	pkColourInfo = pkOEMInfo->GetColour(V6RES_COLOUR_SIPDESC); // Font color of text for description field
	DisplayInfo.DescriptionFontInfo.FontColor = pkColourInfo->pColor;
	DisplayInfo.OffsetInfo.XOffset = 2; //X coordinate offset value 
	DisplayInfo.OffsetInfo.YOffset = 2; //Y coordinate offset value
	pkColourInfo = pkOEMInfo->GetColour(V6RES_COLOUR_SIPEDITBG); // Background color of the edit box
	DisplayInfo.Background = pkColourInfo->pColor;
	// Now initialise the base object with our custom parameters
	CEditPanelDlg::InitializeIP(&PositionInfo, pkSizePosInfo, pkKeyMapInfo, &BitmapInfo, &DisplayInfo);
}
//****************************************************************************
//	const bool ShowSIP(	const QString   &strTITLE,
//						QString   &rstrEnteredText, 
//						const USHORT usMAX_DATA_LENGTH,
//						glbpCallbackFunction pValidateFunc )
//
/// Method runs the numerical SIP and returns the entered data
///
///	@param[in]		QString   &strTITLE - The title text for the SIP
///	@param[out]		QString   &rstrEnteredText - The text entered by the user
/// @param[in]		const USHORT usMAX_DATA_LENGTH - The max length allowed for the data not including
///					the NULL character
///	@param[in]		glbpCallbackFunction pValidateFunc - Pointer to a callback function
///	@param[in]		const QString   &rstrHELP_TOPIC - The required topic
///	@param[in]		const QString   &rstrHELP_CHAPTER - The required chapter or "" if none
///
/// @return			TRUE if SIP returns OK, otherwise FALSE
///
//****************************************************************************
const bool CAlphaNumEditDlg::ShowSIP(const QString &strTITLE, QString &rstrEnteredText, const USHORT usMAX_DATA_LENGTH,
		glbpCallbackFunction pValidateFunc, const QString &rstrHELP_TOPIC, const QString &rstrHELP_CHAPTER) {
	bool bRetVal = false;
	// variables used as placeholders for information regarding the SIP
	BUFFERINFO tEditBufferInfo;
	OTHERINFO tOtherEditBufferInfo;
	CEditPanelDlg::SetupHelpBuffer(&tOtherEditBufferInfo.pHelpTopic, &tOtherEditBufferInfo.pHelpChapter, rstrHELP_TOPIC,
			rstrHELP_CHAPTER);
	CEditPanelDlg::SetupDataBuffer(tEditBufferInfo, tOtherEditBufferInfo, rstrEnteredText, strTITLE, usMAX_DATA_LENGTH);
	//Validation function pointer
	glbpCallbackFunction pFunctionPointer = pValidateFunc;
	//Call the ShowIP function with run time initialization pointer
	unsigned char ucModified = 0;
	unsigned char ucIsTimeOut = 0;
	CAlphaNumEditDlg kAlphaNumEditDlg;
	if (kAlphaNumEditDlg.ShowIP(&tEditBufferInfo, pFunctionPointer, &tOtherEditBufferInfo, &ucModified, &ucIsTimeOut)) {
		// Edit selected, mark on chart if entry has been made
		if (wcslen(tEditBufferInfo.pBuffer) > 0) {
			rstrEnteredText = QString::asprintf(tEditBufferInfo.pBuffer);
			bRetVal = true;
		} else {
			// set to empty
			rstrEnteredText = "";
		}
	} else {
		// Cancel on edit pressed
		bRetVal = false;
	}
	delete[] tEditBufferInfo.pBuffer;
	//release the memory
	delete[] tOtherEditBufferInfo.pHelpTopic;
	delete[] tOtherEditBufferInfo.pHelpChapter;
	return bRetVal;
}

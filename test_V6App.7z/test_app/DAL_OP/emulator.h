//************************************************************************************
// © Honeywell Trendview
//************************************************************************************
// Module  Emulation
/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 System Absraction layer
/// @n Filename: emulator.h
/// @n Desc:	 Emulation interface, provide interface routines to enable emulator
///						to be used for as much recorder functionality as possible
///
// 
//  ****************************************************************
//  Revision History
//  ****************************************************************
//  $Log[4]:
// 8 Stability Project 1.5.1.1  7/2/2011 4:57:03 PM Hemant(HAIL) 
//  Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
// 7 Stability Project 1.5.1.0  7/1/2011 4:26:56 PM Hemant(HAIL) 
//  Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
// 6 V6 Firmware 1.5  4/18/2006 8:19:12 PM  Jason Parker 
//  Modified to use application directory instead of C:\TV6PC (for
//  Desktop build only)
// 5 V6 Firmware 1.4  4/27/2005 2:47:55 PM  Martin Miller  
//  Made folder paths const due to a problem with the CreateDirectory API
//  call removing unwanted trailing \'s
//  $
//
//  ****************************************************************
#ifndef __EMULATOR_H__
#define __EMULATOR_H__
#include "hw_defs.h"
#include "opl.h"
#include "Defines.h"
#define ERROR_FILE_NOT_FOUND             2L
#define ERROR_PATH_NOT_FOUND             3L
#define ERROR_TOO_MANY_OPEN_FILES        4L
#define ERROR_RESOURCE_NAME_NOT_FOUND    1814L
#define ERROR_ALREADY_EXISTS    183L
//**Class*********************************************************************
///
/// @brief Provide emulation of V6 hardware features on the PC 
/// 
/// This class will provide emulation of hardware features from V6 on the PC
/// used by the CDeviceAbstraction class when running under windows CE emulator
/// or when any of the modules are being used on a PC.
///
///
//****************************************************************************
class CEmulator {
public:
	BOOL Initialise();
	BOOL Shutdown();
	QString GetVolumeName(storageDeviceIdent id, QString pVolume, int pVolumeBuffSize);
	/// Static variable used by the desktop build to store installation dir for TV6PC
	static QString m_SimulatorVol;
#ifdef PC_USE
	static bool IsMulti;
#endif
private:
	BOOL CreateEmulDirectory(const QString pPath);
};
#endif // __EMULATOR_H__

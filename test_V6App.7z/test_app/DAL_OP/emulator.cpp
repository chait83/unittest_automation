/// @file
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 System Absraction layer
/// @n Filename: emulator.cpp
/// @n Desc:	 Emulation interface, provide interface routines to enable emulator
///						to be used for as much recorder functionality as possible
///
// 
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  1 Test_VIew 1.0	 7/8/2013 1:13:43 PM Build Machine
// $
//	 Rajanbabu M	 8/13/2013		Fixed PAR 1-1275FG9-Import Aristos Recorder/X Series data throws SRAM error
// ****************************************************************
#include <QMessageBox>
#include "CStorage.h"
#include "emulator.h"
#include "utility.h"
#include "V6Config.h"
#ifdef CE_USE 
// to make V6App recorder application run as Desktop for iMX53 QSB.
QString CEmulator::m_SimulatorVol = "";
/// TODO : write the correct paths
QString rootVol		= "SDMemory2/TV6PC/";	// as default, but can be updated
//WCHAR rootVol		= "Hard Disk/TV6PC/";	// as default, but can be updated
QString TV6PC = "/TV6PC/"; // subdirectory off application dir.
// need to add rootVol to the front of the following. (rootVol may get updated to SimulatorVol)
QString internalSD		= "intcf/";
QString externalSD		= "extcf/";
QString usbkey1		= "usbfront/";
QString usbkey2		= "usbrear/";
/*
For FTP proper working modified paths
QString rootVol		= "/";	// as default, but can be updated
QString TV6PC[]							= "/TV6PC/"; // subdirectory off application dir.
// need to add rootVol to the front of the following. (rootVol may get updated to SimulatorVol)
QString internalCF		= "Storage_Card/TV6PC/intcf/";
QString externalCF		= "Storage_Card/TV6PC/extcf/";
QString usbkey1		= "Storage_Card/TV6PC/usbfront/";
QString usbkey2		= "Storage_Card/TV6PC/usbrear/";
*/
#else
#undef MAX_SD_VOLUME_LEN
#define MAX_SD_VOLUME_LEN MAX_PATH
// for desktop
QString CEmulator::m_SimulatorVol = "";
QString rootVol = "C:/TV6PC/";	// as default, but can be updated
QString TV6PC = "/TV6PC/"; // subdirectory off application dir.
// need to add rootVol to the front of the following. (rootVol may get updated to SimulatorVol)
QString internalSD = "intcf/";
QString externalSD = "extcf/";
QString usbkey1 = "usbfront/";
QString usbkey2 = "usbrear/";
#ifdef PC_USE
bool CEmulator::IsMulti = false;
#endif
#endif
//
//bool CEmulator::IsMulti = false;
//
//#else // CE_USE
///@note TO USE EMULATOR DO THE FOLLOWING 
///
/// 1. In the Emulator window, from the Emulator menu, choose Folder Sharing. 
/// 2. Select C:\ to share
/// 3. When shutting down the emulator make sure you select "Save State" not "Turn Off"
/// @note do not make these const, the emulator will not work correctly!
//const QString rootVol			= "Storage Card/TV6EMUL/";
//const QString internalCF		= "Storage Card/TV6EMUL/intcf/";
//const QString externalCF		= "Storage Card/TV6EMUL/extcf/";
//const QString usbkey1			= "Storage Card/TV6EMUL/usbfront/";
//const QString usbkey2			= "Storage Card/TV6EMUL/usbrear/";
//QString rootVol		= "SDMemory/TV6PC/";	// as default, but can be updated
//QString TV6PC[]							= "/TV6PC/"; // subdirectory off application dir.
//
//// need to add rootVol to the front of the following. (rootVol may get updated to SimulatorVol)
//QString internalCF		= "SDMemory/TV6PC/intcf/";
//QString externalCF		= "SDMemory/TV6PC/extcf/";
//QString usbkey1		= "SDMemory/TV6PC/usbfront/";
//QString usbkey2		= "SDMemory/TV6PC/usbrear/";
//
//#endif
//**********************************************************************************
/// Create Directories in Shared Folder for emulator, will warn using 
///		message box	if cannot create path due to drive not being mapped.
///
/// @param[in]	pPath - ptr to full path of directory to create
/// @return		TRUE, if create successful or already exists, False if failed to create
/// 
//**********************************************************************************
BOOL CEmulator::CreateEmulDirectory(const QString pPath) {
	QString errText;
	QString FolderName = "";
	// Need to maks a copy of the path before calling CStorage::CreateDirectory
	// coz CStorage::CreateDirectory will remove any trailing \'s from the path.
#if _MSC_VER < 1400 
	FolderName = pPath;
#else
	wcscpy_s( FolderName, MAX_SD_VOLUME_LEN, pPath );
#endif
	if (CStorage::CreateDirectory(FolderName, NULL) == FALSE) {
		DWORD lastErr = GetLastError();
		// If error return is path already exsists then this is okay
		// JU: Added error handling of the message ERROR_RESOURCE_NAME_NOT_FOUND, this is 
		// received when the emulator is shut down using "Save State" and restarted. 
		//	  Unable to determine the cause, this is a temporary fix.
		if (lastErr == ERROR_ALREADY_EXISTS || lastErr == ERROR_RESOURCE_NAME_NOT_FOUND) {
			return TRUE;
		}
		// If path is not found then the emulator drive is probably not mapped
		if (lastErr == ERROR_PATH_NOT_FOUND) {
#ifdef PC_USE
			WCHAR TempBuff[200];
#if _MSC_VER < 1400 
  swprintf(tempbuff, MAX_PATH, L"Cannot create TV6PC directory in %s", m_SimulatorVol);
#else
			swprintf(TempBuff, 200, L"Cannot create TV6PC directory in %s",m_SimulatorVol);
#endif
			MessageBox(NULL, TempBuff, NULL, MB_OK);
#else
			QMessageBox(NULL,
					"Cannot find storage card \n you need to map a drive in the emulator menu \n share folder C: then press OK \n and we'll try again",
					NULL, MB_OK);
#endif
		}
		errText = QString::asprintf(("EmulInitialise: Creatdirectory failed \n with error number %d \n"), lastErr);
		qDebug() << errText;
		return FALSE;
	}
	return TRUE;	// New path created okay
}
//#include "Dal.h"
//**********************************************************************************
/// Inititalise all resources required for emulator
///
/// @return		TRUE if successful, FALSE if any initialisation fails
/// 
//**********************************************************************************
BOOL CEmulator::Initialise() {
	// Create path on the emulated drive for all storage devices
#ifdef PC_USE
	// here see if screen designer simulator requires that we change the root.
	if (m_SimulatorVol[0]) {
#if _MSC_VER < 1400 
		wcscpy(rootVol, m_SimulatorVol); // use this as our root vol, and update the volumes below:
		wcscat(rootVol, TV6PC);
#else
		wcscpy_s(rootVol, sizeof(rootVol)/sizeof(WCHAR), m_SimulatorVol); // use this as our root vol, and update the volumes below:
		wcscat(rootVol, sizeof(rootVol)/sizeof(WCHAR), TV6PC);
#endif
	}
	// 
	// Stability Project Fix:
	//
	// Following source code is commented, it was not in the previous version of emulator.cpp file.
	// GA Digitals had added this source code for allowing the V6Desktop to launch from USB device.
	// But this was not fully tested as the rooVol variable was never assigned value as to laod from USB.
	// As a result of this, even the desktop version fails to execute.
	//
	/*else
	 {
	 if( IsMulti )
	 {
     wcscat(rootVol,L"SX/";
	 }
	 else
	 {
     wcscat(rootVol,L"QX/";
	 }		
	 }*/
	// use the rootVol (which may now be somewhere other than C:\TV6PC)
	WCHAR tempbuff[MAX_PATH];
#if _MSC_VER < 1400 
  swprintf(tempbuff, MAX_PATH, L"%s%s", rootVol, "intcf/"));
	wcscpy(internalSD, tempbuff);
  swprintf(tempbuff, MAX_PATH, L"%s%s", rootVol, "extcf/"));
	wcscpy(externalSD, tempbuff);
  swprintf(tempbuff, MAX_PATH, L"%s%s", rootVol, "usbfront/"));
	wcscpy(usbkey1, tempbuff);
  swprintf(tempbuff, MAX_PATH, L"%s%s", rootVol, "usbrear/"));
	wcscpy(usbkey2, tempbuff);
#else
    swprintf(tempbuff, MAX_PATH, L"%s%s",rootVol,"intcf/"));
	wcscpy_s(internalSD, sizeof(internalSD)/sizeof(WCHAR), tempbuff);
    swprintf(tempbuff, MAX_PATH, L"%s%s",rootVol,"extcf/"));
	wcscpy_s(externalSD, sizeof(externalSD)/sizeof(WCHAR), tempbuff);
    swprintf(tempbuff, MAX_PATH, L"%s%s",rootVol,"usbfront/"));
	wcscpy_s(usbkey1, sizeof(usbkey1)/sizeof(WCHAR), tempbuff);
    swprintf(tempbuff, MAX_PATH, L"%s%s",rootVol,"usbrear/"));
	wcscpy_s(usbkey2, sizeof(usbkey2)/sizeof(WCHAR), tempbuff);	
#endif
#endif	
#ifndef ARISTOS
	if (CreateEmulDirectory(rootVol) == FALSE)			// Create rootVol directory
		if (CreateEmulDirectory(rootVol) == FALSE)		// try again if directory no mapped
			return FALSE;									// Nope, it's useless.
	if (CreateEmulDirectory(internalSD) == FALSE)	// Internal Compact Flash mapping
		return FALSE;
	if (CreateEmulDirectory(externalSD) == FALSE)	// External Compact Flash mapping
		return FALSE;
	if (CreateEmulDirectory(usbkey1) == FALSE)		// Front USB keydrive mapping
		return FALSE;
	if (CreateEmulDirectory(usbkey2) == FALSE)		// Rear USB Keydrive mapping
		return FALSE;
#endif 
	return TRUE;
}
//**********************************************************************************
/// Shutdown/close and deallocate all resources required for emulator
///
/// @return		TRUE if successful, FALSE if any shutdown fails
/// 
//**********************************************************************************
BOOL CEmulator::Shutdown() {
	return TRUE;
}
//**********************************************************************
///
/// Get volume name for storage device
///
/// @param[in]	id - storage device identifier of type storageDeviceIdent in hw_defs.h
/// @param[out]	pVolume - ptr to store volume information in, if NULL a pointer will be returned to const information
/// @return		ptr to const volume path for storeage device id, NULL if invalid id
/// 
//**********************************************************************
QString CEmulator::GetVolumeName(storageDeviceIdent id, QString pVolume, int pVolumeBuffSize) {
	QString pVolumeConst;
	switch (id) {
	case SD_INTERNAL_SD:
		pVolumeConst = internalSD;
		break;
	case SD_EXTERNAL_SD:
		pVolumeConst = externalSD;
		break;
	case SD_USB1:
		pVolumeConst = usbkey1;
		break;
	case SD_USB2:
		pVolumeConst = usbkey2;
		break;
	case ROOT:
		pVolumeConst = rootVol;
		break;
	default:
		qDebug("Error unknown Identifier\n");
		/// @todo AK, replace with correct error handling
		break;
	}
	// If the passed in volume pointer is not null and we have a valid volume, then copy volume to pVolume dest
	if (pVolume != NULL && pVolumeConst != NULL) {
		pVolume = pVolumeConst;
	}
	return pVolumeConst;
}

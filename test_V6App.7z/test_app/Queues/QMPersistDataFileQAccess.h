/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Queue Manager
/// @n Filename:	QMPersistDataFileQAccess.h
/// @n Description: Class Declaration File for the class CQMPersistDataFileQAccess
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 4	Stability Project 1.1.1.1	7/2/2011 5:00:04 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 3	Stability Project 1.1.1.0	7/1/2011 4:27:36 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 2	V6 Firmware 1.1		7/22/2005 4:11:40 PM	Alistair Brugsch
//		Added Doxygen Comments
// 1	V6 Firmware 1.0		6/21/2005 3:44:16 PM	Alistair Brugsch 
// $
//
// **************************************************************************
#ifndef _QMPERSISTDATAFILEQACCESS_H
#define _QMPERSISTDATAFILEQACCESS_H
#include "QMCommon.h"
/// Enumeration to describe whether the operation of a Member Function has been
/// completed Successfully or a Failure has occurred. 
typedef enum {
	QMPDFQA_OK, QMPDFQA_ERROR, QMPDFQA_FILE_QUEUE_NUMBER_INVALID
} T_QMPDFQA_RETURN_VALUE;
//**Class*********************************************************************
///
/// @brief ---Single line description---.
/// 
/// --- Detailed Description ---
///
//****************************************************************************
class CQMPersistDataFileQAccess {
public:
	/// Constructor
	CQMPersistDataFileQAccess(T_QMC_PERSIST_DATAFILE_QUEUE *const pFirstPersistDataFileQ,
			const USHORT maxNumOfFileQueues);
	/// Destructor
	virtual ~CQMPersistDataFileQAccess(void);
	/// Validate the Persisted Queue Number against the maximum Persisted Queues Avialable
	T_QMPDFQA_RETURN_VALUE ValidateQueueHandler(const USHORT hQueue);
	/// Set the Status of a specific Persist Data Block Queue
	T_QMPDFQA_RETURN_VALUE SetStatus(const USHORT hQueue, const USHORT status);
	/// Set the Head Block of a specific Persist Data Block Queue
	T_QMPDFQA_RETURN_VALUE SetHead(const USHORT hQueue, const USHORT head);
	/// Set the Tail Block of a specific Persist Data Block Queue
	T_QMPDFQA_RETURN_VALUE SetTail(const USHORT hQueue, const USHORT tail);
	/// Set the Number of Blocks of a specific Persisit Data Block Queue
	T_QMPDFQA_RETURN_VALUE SetNumOfFiles(const USHORT hQueue, const USHORT numOfFiles);
	/// Set the Number of Block in Queue before a flush to disk occurs
	T_QMPDFQA_RETURN_VALUE SetMaxFiles(const USHORT hQueue, const USHORT maxFiles);
	/// Set the Number of Block in Queue before a flush to disk occurs
	T_QMPDFQA_RETURN_VALUE SetMinFiles(const USHORT hQueue, const USHORT minFiles);
	/// Increment the Number of Blocks within a specific Persist Data Block Queue by One Block
	T_QMPDFQA_RETURN_VALUE IncrementNumOfFiles(const USHORT hQueue);
	/// Decrement the Number of Blocks within a specific Persist Data Block Queue by One Block
	T_QMPDFQA_RETURN_VALUE DecrementNumOfFiles(const USHORT hQueue);
	/// Get the Status of the Queue of a specific Persist Data Block Queue
	USHORT GetStatus(const USHORT hQueue) const;
	/// Get the Head Block Id of a specific Persist Data Block Queue 
	USHORT GetHead(const USHORT hQueue) const;
	/// Get the Tail Block Id of a specific Persist Data Block Queue
	USHORT GetTail(const USHORT hQueue) const;
	/// Get the Flush To Limit for a specific Persist Data Block Queue 
	USHORT GetMaxFiles(const USHORT hQueue) const;
	/// Get the Flush To Limit for a specific Persist Data Block Queue 
	USHORT GetMinFiles(const USHORT hQueue) const;
	/// Get the Number of Blocks within a specific Persist Data Block Queue
	USHORT GetNumOfFilesInQueue(const USHORT hQueue) const;
private: // Member Functions
private: // Member Variables	
	const USHORT m_MaxNumOfFileQueues; ///< Maximum Number of File Queues Available
	/// Pointer to the First Persisted Data file Queue, this pointer will be used with an
	/// array subscript to access the various persisited data file queues in memory. 
	T_QMC_PERSIST_DATAFILE_QUEUE *const m_pPersistDataFileQ;
};
// End of Class Declaration
/// Set the Status of a specific Persist Data Block Queue
inline T_QMPDFQA_RETURN_VALUE CQMPersistDataFileQAccess::SetStatus(const USHORT hQueue, const USHORT status) {
	m_pPersistDataFileQ[hQueue].Status = status;
	return (QMPDFQA_OK);
} // End of Member Function
/// Set the Head Block of a specific Persist Data Block Queue
inline T_QMPDFQA_RETURN_VALUE CQMPersistDataFileQAccess::SetHead(const USHORT hQueue, const USHORT head) {
	m_pPersistDataFileQ[hQueue].Head = head;
	return (QMPDFQA_OK);
} // End of Member Function 
/// Set the Tail Block of a specific Persist Data Block Queue
inline T_QMPDFQA_RETURN_VALUE CQMPersistDataFileQAccess::SetTail(const USHORT hQueue, const USHORT tail) {
	m_pPersistDataFileQ[hQueue].Tail = tail;
	return (QMPDFQA_OK);
} // End of Member Function 
/// Set the Number of Blocks of a specific Persisit Data Block Queue
inline T_QMPDFQA_RETURN_VALUE CQMPersistDataFileQAccess::SetNumOfFiles(const USHORT hQueue, const USHORT numOfFiles) {
	m_pPersistDataFileQ[hQueue].NumOfFilesInQueue = numOfFiles;
	return (QMPDFQA_OK);
} // End of Member Function 
/// Set the Number of Block in Queue before a flush to disk occurs
inline T_QMPDFQA_RETURN_VALUE CQMPersistDataFileQAccess::SetMaxFiles(const USHORT hQueue, const USHORT maxFiles) {
	m_pPersistDataFileQ[hQueue].MaxFiles = maxFiles;
	return (QMPDFQA_OK);
} // End of Member Function 
/// Set the Number of Block in Queue before a flush to disk occurs
inline T_QMPDFQA_RETURN_VALUE CQMPersistDataFileQAccess::SetMinFiles(const USHORT hQueue, const USHORT minFiles) {
	m_pPersistDataFileQ[hQueue].MinFiles = minFiles;
	return (QMPDFQA_OK);
} // End of Member Function 
/// Increment the Number of Blocks within a specific Persist Data Block Queue by One Block
inline T_QMPDFQA_RETURN_VALUE CQMPersistDataFileQAccess::IncrementNumOfFiles(const USHORT hQueue) {
	++m_pPersistDataFileQ[hQueue].NumOfFilesInQueue;
	return (QMPDFQA_OK);
} // End of Member Function 
/// Decrement the Number of Blocks within a specific Persist Data Block Queue by One Block
inline T_QMPDFQA_RETURN_VALUE CQMPersistDataFileQAccess::DecrementNumOfFiles(const USHORT hQueue) {
	--m_pPersistDataFileQ[hQueue].NumOfFilesInQueue;
	return (QMPDFQA_OK);
} // End of Member Function 
/// Get the Status of the Queue of a specific Persist Data Block Queue
inline USHORT CQMPersistDataFileQAccess::GetStatus(const USHORT hQueue) const {
	return (m_pPersistDataFileQ[hQueue].Status);
} // End of Member Function 
/// Get the Head Block Id of a specific Persist Data Block Queue 
inline USHORT CQMPersistDataFileQAccess::GetHead(const USHORT hQueue) const {
	return (m_pPersistDataFileQ[hQueue].Head);
} // End of Member Function 
/// Get the Tail Block Id of a specific Persist Data Block Queue
inline USHORT CQMPersistDataFileQAccess::GetTail(const USHORT hQueue) const {
	return (m_pPersistDataFileQ[hQueue].Tail);
} // End of Member Function 
/// Get the Flush To Limit for a specific Persist Data Block Queue 
inline USHORT CQMPersistDataFileQAccess::GetMaxFiles(const USHORT hQueue) const {
	return (m_pPersistDataFileQ[hQueue].MaxFiles);
} // End of Member Function 
/// Get the Flush To Limit for a specific Persist Data Block Queue 
inline USHORT CQMPersistDataFileQAccess::GetMinFiles(const USHORT hQueue) const {
	return (m_pPersistDataFileQ[hQueue].MinFiles);
} // End of Member Function 
/// Get the Number of Blocks within a specific Persist Data Block Queue
inline USHORT CQMPersistDataFileQAccess::GetNumOfFilesInQueue(const USHORT hQueue) const {
	return (m_pPersistDataFileQ[hQueue].NumOfFilesInQueue);
} // End of Member Function 
#endif // _QMPERSISTDATAFILEQACCESS_H

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  Queue Manager
/// @n Filename:  QMDataFileQueue.h
/// @n Description: Class Declaration File for the class CQMDataFileQueue
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  9 Stability Project 1.6.1.1 7/2/2011 5:00:02 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  8 Stability Project 1.6.1.0 7/1/2011 4:27:35 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  7 V6 Firmware 1.6 9/14/2006 3:55:34 PM  Alistair Brugsch
//  added in functionality to allow clearing of data from chart queues
//  6 V6 Firmware 1.5 2/22/2006 8:52:36 PM  Alistair Brugsch
//  fixed a leftover temporary magic number for calculating Free File
//  Queue percentage
// $
//
// **************************************************************************
#ifndef _QMDATAFILEQUEUE_H
#define _QMDATAFILEQUEUE_H
#include "QMDataFileQAccess.h"
#include "QMDataFileAccess.h"
/// Enumeration to describe whether the operation of a Member Function has been
/// completed Successfully or a Failure has occurred. 
typedef enum {
	QMDFQ_OK, QMDFQ_NO_FILE_TO_REMOVE, QMDFQ_ERROR
} T_QMDFQ_RETURN_VALUE;
/// Enumeration to indicate the Status of the File Queue
typedef enum {
	QMDFQ_STATUS_EMPTY, QMDFQ_STATUS_SPACE_AVAILABLE, QMDFQ_STATUS_FULL
} T_QMDFQ_QUEUE_STATUS;
//**Class*********************************************************************
///
/// @brief Data File Queue using a Linked List
/// 
/// This class provides the linked list operations for insert and removing 
/// Data Files into a Queue. This class is used for the Free File Queue.
///
//****************************************************************************
class CQMDataFileQueue {
public:
	/// Constructor
	CQMDataFileQueue(CQMDataFileQAccess &fileQueue, CQMDataFileAccess &dataFileAccess);
	/// Destructor
	virtual ~CQMDataFileQueue(void);
	/// Add a File to the End( Tail ) of the Queue
	T_QMDFQ_RETURN_VALUE AddFileToTail(const USHORT fileNumber, BOOL bRealloc = FALSE);
	/// Obtain a Pointer to the Current( Head ) Available File in the Queue
  T_QMC_DATAFILE_HEADER* const GetHeadFile(void);
	/// Remove the Current( Head ) Available File from the Queue
	T_QMDFQ_RETURN_VALUE RemoveHeadFile(void);
	/// Obtain the Status of the File Queue
  T_QMDFQ_QUEUE_STATUS GetQueueStatus(void);
	/// Obtain the Number of File currently within the File Queue
	USHORT GetNumOfFilesInQueue(void) const {
		m_FileQueue.GetNumOfFilesInQueue();
	}

	///obtain the number of free files in the system

  inline FLOAT GetPercentageOfFreeFiles(void) {
    FLOAT freeBlocks = static_cast<FLOAT>(m_FileQueue.GetNumOfFilesInQueue()) / m_DataFileAccess.GetMaxNumOfFiles(); //use the defined constant
    return (freeBlocks * 100.0F);
  } // End of Member Function
	///add a linked run of files to the end of the queue
	T_QMDFQ_RETURN_VALUE AddLinkedFilesToTail(const USHORT firstFileNumber, USHORT count);
	/// Display the Queue using the Trace Windows - for DEBUG PURPOSES ONLY
	void TraceQueue(const QString pName);
private: // Member Functions
	/// Write the File Header within Memory to the Physical File
	T_QMDFQ_RETURN_VALUE WriteFileHeaderToPhysicalFile(const USHORT fileId);
private: // Member Variables
	CQMDataFileQAccess &m_FileQueue;  ///< File Queue Interface Class
	CQMDataFileAccess &m_DataFileAccess; ///< Member Variable to gain access to the Data File Headers
};
// End of Class Declaration
#endif // _QMDATAFILEQUEUE_H

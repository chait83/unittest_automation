/// @file
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Queue Manager
/// @n Filename:	QMUserRequestServices.h
/// @n Description: Class Declaration for CQMUserRequestServices
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  19	Stability Project 1.16.1.1	 7/2/2011 5:00:05 PM	 Hemant(HAIL)
//		 Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
//  18	Stability Project 1.16.1.0	 7/1/2011 4:27:36 PM	 Hemant(HAIL)
//		 Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware.
//  17	V6 Firmware 1.16		 1/17/2007 7:13:26 PM	Jason Parker
//		Make function inline
//  16	V6 Firmware 1.15		 7/4/2006 6:49:42 PM	 Jason Parker
//		return T_IMQ_RETURN_VALUE	from PostUserRequest()
// $
//
// **************************************************************************
#ifndef _QMUSERREQUESTSERVICES_H
#define _QMUSERREQUESTSERVICES_H
#include "InternalMessageQueue.h"
#include "QMMemoryOpDataAccess.h"
#include "QMPersistBlkQAccess.h"
#include "QMPersistDataFileQAccess.h"
#include "QMDataFileAccess.h"
#include "QMPersistDataFileQ.h"
#include "QMQueueFileTransaction.h"
#include "QMCommon.h"
#include "QMFileBlockTransaction.h"
#include "LogDeviceStatus.h"
#include "QMBlkQHeaderAccess.h"
const USHORT USRREQSER_ZERO = 0; ///< constant to represent the value of Zero used for default initialisation.
/// Enumeration to describe whether the operation of a Member Function has been
/// completed Successfully or a Failure has occurred.
typedef enum {
	USRREQSER_OK,
	USRREQSER_INITIALISATION_FAILED,
	USRREQSER_REGISTRATION_FAILED,
	USRREQSER_NO_BLOCKS_AVAILABLE,
	USRREQSER_END_OF_FILE_REACHED,
	USRREQSER_ERROR,
	USRREQSER_NO_AVAILABLE_REQUEST
} T_USRREQSER_RETURN_VALUE;
typedef enum {
	USRREQSER_CMP_EQUAL_TO, USRREQSER_CMP_LESS_THAN, USRREQSER_CMP_GREATER_THAN
} T_USRREQSER_COMPARE_RESULT;
typedef enum {
	DETAILED_BLOCK_SEARCH_REQUIRED,
	USER_TIME_GREATER_THAN_LAST_BLOCK,
	USER_TIME_LESS_THAN_FIRST_BLOCK,
	USER_TIME_LESS_THAN_FIRST_BLOCK_HEAD,
	USER_TIME_GREATER_THAN_LAST_BLOCK_TAIL
} T_USRREQSER_FIND_FILE_COMPARE_RESULT;
typedef enum {
	USRREQSER_DIR_NEXT, USRREQSER_DIR_PREVIOUS
} T_USRREQSER_DIRECTION;
typedef struct {
	USHORT itemToCheck;
	USHORT startItem;
	USHORT endItem;
	USHORT searchComplete;
	T_USRREQSER_COMPARE_RESULT compareResult;
} T_USRREQSER_BLOCK_SEARCH_DATA;
typedef struct {
	USHORT itemToCheck;
	USHORT startItem;
	USHORT endItem;
	USHORT searchComplete;
	T_USRREQSER_FIND_FILE_COMPARE_RESULT compareResult;
} T_USRREQSER_FILE_SEARCH_DATA;
typedef enum _eUsrReqSerFileSection {
	USRREQSER_SECTION_OLDEST, USRREQSER_SECTION_NEWEST
} T_USRREQSER_FILE_SECTION;
typedef struct _stUsrReqSerindexOfFileCtnBlkResult {
	USHORT fileId;
	USHORT firstBlockId;
	USHORT lastBlockId;
	T_USRREQSER_FILE_SECTION fileSection;
	T_USRREQSER_FIND_FILE_COMPARE_RESULT compareResult;
} T_USRREQSER_FIND_FILE_CTN_BLOCK_RESULT;
typedef enum {
	USRREQSER_DATA_AVAILABLE, USRREQSER_FILE_AND_BLOCK_UPDATED, USRREQSER_END_OF_AVAILABLE_DATA
} T_USRREQSER_AVAILABLE_BLOCK_RESULT;
typedef enum {
	USRREQSER_RTU_REPLY_TO_USER, USRREQSER_RTU_NO_REPLY_REQUIRED
} T_USRREQSER_REPLY_TO_USER_STATUS;
/// Enumeration to describe whether a User has registered with the Disk Services
typedef enum {
	USRREQSER_REGISTERED, USRREQSER_NOT_REGISTERED
} T_USRREQSER_REGISTERED_STATUS;
/// A Structure that describes information relating a Disk Service Users, this structure contains,
/// information relating to the method of communication to use for thread communication.
typedef struct {
	T_USRREQSER_REGISTERED_STATUS registeredStatus;  ///< Indicates whether a user has registered
	CInternalMessageQueue *pInternalMessageQueue;	 ///< Internal Message Communication for the user( if required )
} T_USRREQSER_USER_INFO;
typedef enum {
	USRREQSER_NOT_REQUIRED
} T_USRREQSER_SEARCH_MODE;
typedef enum {
	USRREQSER_UA_GET_NEXT_BLOCKS_FROM_START_TIME,
	USRREQSER_UA_GET_PREVIOUS_BLOCKS_FROM_NEWEST_AVAILABLE,
	USRREQSER_UA_GET_PREVIOUS_BLOCKS_FROM_START_TIME,
	USRREQSER_UA_GET_BLOCKS_FROM_FIRST_AVAILABLE,
	USRREQSER_UA_GET_NEXT_BLOCKS,
	USRREQSER_UA_GET_PREVIOUS_BLOCKS,
	USRREQSER_UA_RESET_TO_OLDEST_AVIALABLE,
	USRREQSER_UA_COMPLETE_TRANSACTION,
	USRREQSER_UA_CONFIRM_TRANSACTION,
	USRREQSER_UA_GET_NUM_BLOCKS_IN_QUEUE_FROM_POINT,
	USRREQSER_UA_IS_QOBJ_IN_TDQ
} T_USRREQSER_USER_ACTION;
typedef enum {
	USRREQSER_MAINTAIN_FILE_TRANS_INT, USRREQSER_MAINTAIN_FILE_TRANS_EXT
} T_USRREQSER_USER_FILE_TRANSACTION_TYPE;
typedef struct {
	T_USRREQSER_USER user;
	USHORT hQueue;
	USHORT numOfBlocks;
	T_USRREQSER_USER_ACTION userAction;
	T_USRREQSER_SEARCH_MODE mode;
	T_USRREQSER_USER_FILE_TRANSACTION_TYPE userFileTransactionType;
	T_QMC_FILE_BLOCK_TRANSACTION *pFileBlockTransaction;
	T_QMC_FILE_BLOCK_TRANSACTION *pConfirmFromFileBlockTransaction;
	BYTE *pDataBuffer;
	LONGLONG startTime;
} T_USRREQSER_USER_MESSAGE_REQUEST;
typedef enum {
	USRREQSER_REQUEST_SUCCESSFUL, USRREQSER_REQUEST_FAILED
} T_USRREQSER_REQUEST_REPLY;
typedef enum {
	USRREQSER_REPLY_NO_ADDITIONAL_INFO,
	USRREQSER_REPLY_NO_FILES_AVAILABLE,
	USRREQSER_REPLY_BLOCKS_AVAILABLE,
	USRREQSER_REPLY_NO_BLOCKS_AVAILABLE,
	USRREQSER_REPLY_NEW_REQUEST_REQUIRED,
	USRREQSER_REPLY_NEW_SEARCH_REQUIRED,
	USRREQSER_REPLY_NO_EXACT_MATCH_FOUND,
	USRREQSER_REPLY_COULD_NOT_OPEN_FILE,
	USRREQSER_REPLY_NO_BUFFER_AVAILABLE,
	USRREQSER_REPLY_END_OF_AVAILABLE_DATA,
	USRREQSER_REPLY_NO_PREVIOUS_BLOCK,
	USRREQSER_REPLY_QUEUE_FILE_MISMATCH,
	USRREQSER_REPLY_NO_Q_BLOCKS_IN_TDQ,
	USRREQSER_REPLY_LESS_DATA_RETURNED
} T_USRREQSER_REPLY_ADDITIONAL_INFO;
typedef struct {
	USHORT hQueue;
	T_USRREQSER_USER_ACTION requestAction;
	USHORT numOfBlocksRequested;
	USHORT numOfBlocksObtained;
	T_USRREQSER_REQUEST_REPLY requestReply;
	T_USRREQSER_REPLY_ADDITIONAL_INFO requestReplyAdditionalInfo;
	LONGLONG startTime;
} T_USRREQSER_USER_MESSAGE_REPLY;
typedef enum {
	USRREQSER_VALIDATE_OK, USRREQSER_VALIDATE_MODIFIED,
} T_USRREQSER_VALIDATE_RETURN;
typedef struct {
	USHORT fileId;
	USHORT fromBlockNumber;
	USHORT numOfBlocks;
} T_USRREQSER_FILE_REQUEST;
typedef struct {
	USHORT fileId;
	USHORT fromBlockNumber;
	USHORT numOfBlocks;
	T_USRREQSER_REQUEST_REPLY replyResult;
	T_USRREQSER_REPLY_ADDITIONAL_INFO replyAdditionalInfo;
} T_USRREQSER_FILE_TRANSACTION_INFO;
//**Class*********************************************************************
///
/// @brief Process User Requests for Blocks within the Data Files
///
/// --- Detailed Description ---
///
//****************************************************************************
class CQMUserRequestServices {
public:
	/// Constructor
	CQMUserRequestServices(const CQMMemoryOpDataAccess &memoryOpDataAccess,
			const CQMPersistBlkQAccess &persistedBlkQAccess, CQMPersistDataFileQAccess &persistedDataFileQAccess,
			CQMDataFileAccess &dataFileAccess, T_PQMC_DBFILES pDBFiles, CQMBlkQAccess &toDiskBlkQAccess,
			CQMBlkQAccess &tempStorageBlkQAccess);
	/// Destructor
	virtual ~CQMUserRequestServices(void);
	/// Initialise the User Request Services
	void Initialise(CQMFileBlockTransaction *pFileBlockTransaction);
	/// Allow the User to Register using an Internal Message Queue for thread communication
	T_USRREQSER_RETURN_VALUE RegisterUsingIntMsgQueue(const T_USRREQSER_USER user,
			CInternalMessageQueue *pInternalMessageQueue);
	/// Post a User Request to be Processed into the User Request Queue
	T_IMQ_RETURN_VALUE PostUserRequest(BYTE *pUserMessageRequest, USHORT dataLength) {
		return m_pUserIntMessageQueue->PostInternalMessage(IMQ_DATA, dataLength, pUserMessageRequest);
	}
	/// Process a User Request
	T_USRREQSER_RETURN_VALUE ProcessUserRequest(void);
private: // -- Member Functions -- //
	/// Open a Specified File
	BOOL OpenBlockFile(USHORT fileId);
	/// Read a specified number of blocks into Memory
	UINT ReadBlocksIntoBuffer(const USHORT numOfBlocks, BYTE *const pBlockBuffer);
	/// Seek to a File Position
	void SeekToFilePosition(const USHORT fromBlockNumber);
	/// Read the Block Header for the specified queue into Memory
	USHORT ReadBlockHeaderIntoMemory(const USHORT hQueue);
	/// Process a User Request for the Previous Set of Blocks( if available )
	void ProcessPreviousBlocksRequest(const T_USRREQSER_USER_MESSAGE_REQUEST &userMessageRequest,
			T_USRREQSER_USER_MESSAGE_REPLY &userMessageReply);
	/// Process a User Request for the Next Set of Blocks ( If Available )
	void ProcessNextBlocksRequest(const T_USRREQSER_USER_MESSAGE_REQUEST &userMessageRequest,
			T_USRREQSER_USER_MESSAGE_REPLY &userMessageReply);
	/// Obtain a set of blocks forward from the Specified Start Time
	void ProcessNextBlocksFromStartTimeRequest(const T_USRREQSER_USER_MESSAGE_REQUEST &userMessageRequest,
			T_USRREQSER_USER_MESSAGE_REPLY &userMessageReply);
	/// Obtain a set of blocks backwards from the Specified Start Time
	void ProcessPreviousBlocksFromStartTimeRequest(const T_USRREQSER_USER_MESSAGE_REQUEST &userMessageRequest,
			T_USRREQSER_USER_MESSAGE_REPLY &userMessageReply);
	/// Obtain a set of blocks from the First Available
	void ProcessGetFirstAvailableRequest(const T_USRREQSER_USER_MESSAGE_REQUEST &userMessageRequest,
			T_USRREQSER_USER_MESSAGE_REPLY &userMessageReply);
	/// Complete the Previous Transaction made by the User
	void ProcessCompleteTransactionRequest(const T_USRREQSER_USER_MESSAGE_REQUEST &userMessageRequest);
	/// Reset the the File Transaction Status to the Oldest Available
	void ProcessResetToOldestAvailableRequest(const T_USRREQSER_USER_MESSAGE_REQUEST &userMessageRequest);
	/// Get the Previous Blocks starting from the Newest Available
	void ProcessGetPrevBlocksFromNewestAvailableRequest(const T_USRREQSER_USER_MESSAGE_REQUEST &userMessageRequest,
			T_USRREQSER_USER_MESSAGE_REPLY &userMessageReply);
	void ProcessGetNumBlocksInQueueFromPoint(const T_USRREQSER_USER_MESSAGE_REQUEST &userMessageRequest,
			T_USRREQSER_USER_MESSAGE_REPLY &userMessageReply);
	void ProcessQObjectInToDiskQ(const T_USRREQSER_USER_MESSAGE_REQUEST &userMessageRequest,
			T_USRREQSER_USER_MESSAGE_REPLY &userMessageReply);
	// Obtain the Block Start Time
	LONGLONG GetBlockStartTime(const USHORT hQueue);
	/// Check whether there are more blocks available in a forward direction
	T_USRREQSER_RETURN_VALUE CheckForNextBlockAvailablity(
			const T_QMC_FILE_BLOCK_TRANSACTION &startFileBlockTransaction);
	/// Check whether there are more blocks available in a backward direction
	T_USRREQSER_RETURN_VALUE CheckForPreviousBlockAvailablity(
			const T_QMC_FILE_BLOCK_TRANSACTION &startFileBlockTransaction);
	/// Get the Position of the Next Available Block, takes into account a file change may be required
	T_USRREQSER_AVAILABLE_BLOCK_RESULT GetPosOfNextAvailableBlock(
			T_QMC_FILE_BLOCK_TRANSACTION &lastFileBlockTransaction);
	/// Get the Position of the Previous Available Block, takes into account a file change may be required
	T_USRREQSER_AVAILABLE_BLOCK_RESULT GetPosOfPreviousAvailableBlock(
			T_QMC_FILE_BLOCK_TRANSACTION &lastFileBlockTransaction);
	/// Get the Last Available Block, depending on the File Type
	USHORT GetLastAvailableBlock(const USHORT fileId, const USHORT currentBlockPosition);
	/// Get the First Available Block, depending on the File Type
	USHORT GetFirstAvailableBlock(const USHORT fileId, const USHORT currentBlockPosition);
	/// Compares the First and Last Block Startime, with the User Requested Starttime
	void indexOfFileSearchComparsion(const LONGLONG userStartTime, const LONGLONG firstBlockStartTime,
			const LONGLONG lastBlockStartTime, T_USRREQSER_FILE_SEARCH_DATA &findFileSearchData);
	/// Search Algorithm for indexOfing the File where the block may be contained
	T_USRREQSER_FIND_FILE_CTN_BLOCK_RESULT indexOfFileSearchAlgorthim(const USHORT hQueue,
			const LONGLONG userStartTime);
	/// Get the File Id from the Queue Position
	USHORT GetFileIdFromQueuePos(const USHORT hQueue, const SHORT queuePos, const USHORT startFileID =
			QMC_INVALID_FILE_NUMBER);
	/// Get the Number of Available Blocks
	USHORT GetNumOfAvailableBlocks(const T_QMC_FILE_BLOCK_TRANSACTION &lastFileBlockTransaction,
			const T_USRREQSER_DIRECTION direction);
	/// Perform the User Request on the File
	BOOL PerformFileRequest(const USHORT fileId, const USHORT fromBlockId, const USHORT numOfBlocks,
			BYTE *const pBuffer, T_USRREQSER_USER_MESSAGE_REPLY &userMessageReply);
	/// Perform a Detailed Search for the requested block within a file
	T_USRREQSER_BLOCK_SEARCH_DATA PerformDetailedBlockSearch(const USHORT hQueue, const USHORT fileId,
			const LONGLONG userStartTime, const T_USRREQSER_FIND_FILE_CTN_BLOCK_RESULT findFileResult);
	/// Validates the File and Block Identification Number
	BOOL ValidateFileIdAndBlockId(const USHORT fileId, const USHORT blockId);
	/// Obtains the First and Last Block Start time from the File
	void ObtainFirstAndLastBlockStartTime(const USHORT hQueue, const USHORT fileId,
			const T_USRREQSER_FILE_SECTION fileSection, USHORT &firstBlockId, USHORT &lastBlockId,
			LONGLONG &firstBlockStartTime, LONGLONG &lastBlockStartTime);
	/// Adjusts the User Request numbe of blocks, to the number the system can provide in one go.
	USHORT AdjustBlockReqToBlocksAvail(const USHORT numOfBlocksAvailable, const USHORT numOfBlocksRequested);
private: // -- Member Variables -- //
	T_USRREQSER_USER_INFO m_DiskServiceUser[USRREQSER_NUM_OF_USERS]; ///< Information relating to the Users of the Disk Services
	CInternalMessageQueue *m_pUserIntMessageQueue;				  ///< Stores User Requests that need to be processed
	const CQMMemoryOpDataAccess &m_MemoryOpDataAccess;		 ///< Access to the Queue Manager Operational Data
	const CQMPersistBlkQAccess &m_PersistedBlkQAccess;		 ///< Access to the Persisted Block Queues
	const CQMPersistDataFileQAccess &m_PersistedDataFileQAccess;	///< Access to the Persisted File Queues
	const CQMDataFileAccess &m_DataFileAccess;			 ///< Access to the Data File Headers
	const CQMPersistDataFileQ m_PersistedDataFileQ;  ///< Class to Access the Data File Persisted Queues
	CStorage m_BlockFile;								///< Handle to current Block File in Use
	BYTE *m_pBlockHeader;							 ///< Pointer to the Block Header Buffer
	CQMFileBlockTransaction *m_pFileBlockTransaction; ///< File and Block Transaction
	CQMBlkQAccess *m_pToDiskQ;						 ///< pointer to the to disk queue
	CQMBlkQAccess *m_pTempStoredBlkQ;				 ///< pointer to the to temporary storage block queue
};
// End of Class Declaration
#endif // _QMUSERREQUESTSERVICES_H

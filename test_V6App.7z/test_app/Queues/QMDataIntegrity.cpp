/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Queue Manager
/// @n Filename:	QMDataIntergrity.cpp
/// @n Description: Implementation File for the Queue Manager Data Intergrity
///				Tests to be undertaken. 
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 24	Stability Project 1.19.1.3	7/2/2011 5:00:02 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 23	Stability Project 1.19.1.2	7/1/2011 4:38:44 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 22	Stability Project 1.19.1.1	3/17/2011 3:20:38 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 21	Stability Project 1.19.1.0	2/15/2011 3:03:46 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
// **************************************************************************
#include "QMDataIntegrity.h"
#include "V6globals.h"
#include "QMMemoryManager.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
#ifdef DBG_FILE_LOG_QUEUEMM_ENABLE
CQMHardwareManager m_QMHardwareLayer;
#endif
//****************************************************************************
/// Constructor
//****************************************************************************
CQMDataIntegrity::CQMDataIntegrity(void) {
} // End of Constructor
//****************************************************************************
/// Destructor
//****************************************************************************
CQMDataIntegrity::~CQMDataIntegrity(void) {
} // End of Destructor
//****************************************************************************
/// Test whether the Memory Operational Data has become corrupt.
///
/// @param[in] 	pMemoryOpData - Pointer to the Queue Manager Operation Data
///
/// @return QMDI_TEST_PASSED - Test has PASSED successfully
///		QMDI_TEST_FAILED - Test has FAILED
/// 
//****************************************************************************
T_QMDI_RETURN_VALUE CQMDataIntegrity::TestMemoryOperationalData(const T_QMC_DATA *const pMemoryOpData) {
	T_QMDI_RETURN_VALUE retValue = QMDI_TEST_PASSED; // Member Function Return Value indicates Test PASSED or FAILED
	if (QMC_SIGNATURE != pMemoryOpData->signature) {
		retValue = QMDI_TEST_FAILED;
	} // End of IF
	return (retValue);
} // End of Member Function
//****************************************************************************
/// Test to determine whether all blocks are allocated across the Queues correctly
///
/// @param[in] 	pFreeBlockQueue		- Pointer to the Free Block Queue
/// @param[in] 	pTempStoredBlockQueue - Pointer to the Temp Storage Queue
/// @param[in] 	pToDiskQueue		- Pointer to the To Disk Queue
/// @param[in] 	pPersistDataBlockQueue - Pointer to the First Persisted Data Block Queue
/// @param[in] 	pBlock				- Pointer to the First Data Block
/// @param[in] 	numOfBlocks			- Number of Available Data Blocks
/// @param[in] 	numOfQueues			- Number of Persisted Data Blocks Queues
///
/// @return QMDI_TEST_PASSED - Test has PASSED successfully
///		QMDI_TEST_FAILED - Test has FAILED
/// 
//****************************************************************************
T_QMDI_RETURN_VALUE CQMDataIntegrity::TestBlockCoverage(const T_QMC_BLOCK_QUEUE *const pFreeBlockQueue,
		const T_QMC_BLOCK_QUEUE *const pTempStoredBlockQueue, const T_QMC_BLOCK_QUEUE *const pToDiskQueue,
		T_QMC_PERSIST_DATA_BLKQ *pPersistDataBlockQueue, const T_QMC_BLOCK *const pBlock, const USHORT numOfBlocks,
		const USHORT numOfQueues) {
	T_QMDI_RETURN_VALUE retValue = QMDI_TEST_PASSED; // Member Function Return Value indicates Test PASSED or FAILED
	WCHAR printMsg[256];
#ifdef DBG_FILE_LOG_QUEUEMM_ENABLE
  QString  strLog;
#endif
	SBlockCoverage *psBlockCoverage = new SBlockCoverage[numOfBlocks];
	memset(psBlockCoverage, QMC_ZERO, sizeof(SBlockCoverage) * numOfBlocks);
	BOOL loopIdentified = FALSE;
	USHORT numOfBlocksChecked = 0, BlockCount = 0;
  USHORT blockId = 0, RecoveredBlkID = 0;
  USHORT prevBlk = 0;
	swprintf(printMsg, 256, L"TestBlockCoverage: numOfQueues = %d, numOfBlocks = %d\n", numOfQueues, numOfBlocks);
	qDebug() << printMsg;
	swprintf(printMsg, 256, L"RecoverBlockCoverage: FreeBlockQueue = %d, TempStoredBlockQueue = %d, ToDiskQueue = %d\n",
			pFreeBlockQueue->NumOfBlocksInQueue, pTempStoredBlockQueue->NumOfBlocksInQueue,
			pToDiskQueue->NumOfBlocksInQueue);
	qDebug() << printMsg;
	if (NULL != psBlockCoverage) {
		//make sure all the blocks are where they think they should be
		for (int j = 0; j < numOfBlocks; j++) {
			if (j != pBlock[j].blockHeader.blockId) {
				QString sysMessage;
				sysMessage = QString::asprintf("DBLKS BlockID mismatch Blockno %d BID %d", j,
						pBlock[j].blockHeader.blockId);
				LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_ERROR, sysMessage);
#ifdef DBG_FILE_LOG_QUEUEMM_ENABLE
      strLog = QString::asprintf("CQMDataIntegrity::TestBlockCoverage Block ID mismatch GTC - %d %d %d %d\r\n", j, pBlock[j].blockHeader.blockId, pBlock[j].blockHeader.QueueId, GetTickCount());
      m_QMHardwareLayer.m_debugFileLogger.WriteToDebugLogFile(strLog);
      strLog = QString::asprintf("CQMDataIntegrity::TBQ failed blockId : %d numOfBlocks : %d GTC - %d\r\n",j,numOfBlocks,GetTickCount());
      m_QMHardwareLayer.m_debugFileLogger.WriteToDebugLogFile(strLog);
#endif
				delete[] psBlockCoverage;
				return QMDI_BLOCKID_TEST_FAILED;
				//V6CriticalMessageBox( NULL, L"QMDataIntegrity.cpp: Block ID mismatch", L"Debug Break", MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST );
				j = numOfBlocks;
			}
		}
		// Tranverse each Queue that stores Blocks, building up the block coverage
		USHORT HeadIndex = pFreeBlockQueue->Head;
		if (ValidateBlockId(HeadIndex, numOfBlocks)) // QMC_START_OF_QUEUE != HeadIndex)
				{
			blockId = pBlock[HeadIndex].blockHeader.blockId;
			if (ValidateBlockId(blockId, numOfBlocks)) //Thsi is redundant check
					{
				// Tranverse Free Block Queue
				for (USHORT freeBlockIndex = QMC_ZERO; freeBlockIndex < pFreeBlockQueue->NumOfBlocksInQueue;
						freeBlockIndex++) {
					if (ValidateBlkQLink(QMDI_FBQ, blockId, numOfBlocks, pBlock, psBlockCoverage)) {
						//Move to next block
						blockId = pBlock[blockId].blockHeader.nextBlock;
						//Update the counter
						numOfBlocksChecked++;
					} else {
						freeBlockIndex = pFreeBlockQueue->NumOfBlocksInQueue;
#ifdef DBG_FILE_LOG_QUEUEMM_ENABLE
        strLog = QString::asprintf("CQMDataIntegrity::TBC blockId==QMC_INVALID_BLOCK_NUMBER in free block queue GTC - %d\r\n",GetTickCount());
        m_QMHardwareLayer.m_debugFileLogger.WriteToDebugLogFile(strLog);
        strLog = QString::asprintf("CQMDataIntegrity::FBQ freeBlockIndex : %d GTC - %d\r\n",freeBlockIndex,GetTickCount());
        m_QMHardwareLayer.m_debugFileLogger.WriteToDebugLogFile(strLog);
#endif
						delete[] psBlockCoverage;
						return QMDI_FBQ_TEST_FAILED;
						//V6CriticalMessageBox(NULL, L"QMDataIntegrity.cpp: Line(112) blockId==QMC_INVALID_BLOCK_NUMBER in free block queue", L"Debug Break", MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST );
					}
				} // End of FOR
			} // End of IF
		}
		if (ValidateBlockId(pTempStoredBlockQueue->Head, numOfBlocks)) {
			blockId = pBlock[pTempStoredBlockQueue->Head].blockHeader.blockId;
			// Tranverse Temporary block Queue
			for (USHORT blockIndex = QMC_ZERO; blockIndex < pTempStoredBlockQueue->NumOfBlocksInQueue; blockIndex++) {
				BOOL bValidBlockId = ValidateBlockId(blockId, numOfBlocks);
				if (ValidateBlkQLink(QMDI_TSBQ, blockId, numOfBlocks, pBlock, psBlockCoverage)) {
					//Move to next block
					blockId = pBlock[blockId].blockHeader.nextBlock;
					//Update the counter
					numOfBlocksChecked++;
				} else {
					blockIndex = pTempStoredBlockQueue->NumOfBlocksInQueue;
#ifdef DBG_FILE_LOG_QUEUEMM_ENABLE
        strLog = QString::asprintf("CQMDataIntegrity::TBC blockId==QMC_INVALID_BLOCK_NUMBER in Temp Stored Block queue GTC - %d\r\n",GetTickCount());
        m_QMHardwareLayer.m_debugFileLogger.WriteToDebugLogFile(strLog);
        strLog = QString::asprintf("CQMDataIntegrity::TSBQ blockIndex : %d GTC - %d\r\n",blockIndex,GetTickCount());
        m_QMHardwareLayer.m_debugFileLogger.WriteToDebugLogFile(strLog);
#endif
					delete[] psBlockCoverage;
					return QMDI_TSBQ_TEST_FAILED;
					//V6CriticalMessageBox(NULL, L"QMDataIntegrity.cpp: Line(134) blockId==QMC_INVALID_BLOCK_NUMBER in Temp Stored Block queue", L"Debug Break", MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST );
				}
			} // End of FOR
		} // End of IF
		if (ValidateBlockId(pToDiskQueue->Head, numOfBlocks)) {
			blockId = pBlock[pToDiskQueue->Head].blockHeader.blockId;
			// Tranverse To Disk Queue
			for (USHORT blockIndex = QMC_ZERO; blockIndex < pToDiskQueue->NumOfBlocksInQueue; blockIndex++) {
				if (ValidateBlkQLink(QMDI_TDQ, blockId, numOfBlocks, pBlock, psBlockCoverage)) {
					//Move to next block
					blockId = pBlock[blockId].blockHeader.nextBlock;
					//Update the counter
					numOfBlocksChecked++;
				} else {
					blockIndex = pToDiskQueue->NumOfBlocksInQueue;
#ifdef DBG_FILE_LOG_QUEUEMM_ENABLE
        strLog = QString::asprintf("CQMDataIntegrity::TBC blockId==QMC_INVALID_BLOCK_NUMBER in To Disk queue queue GTC - %d\r\n",GetTickCount());
        m_QMHardwareLayer.m_debugFileLogger.WriteToDebugLogFile(strLog);
        strLog = QString::asprintf("CQMDataIntegrity::TDQ blockIndex : %d GTC - %d\r\n",blockIndex,GetTickCount());
        m_QMHardwareLayer.m_debugFileLogger.WriteToDebugLogFile(strLog);
#endif					
					delete[] psBlockCoverage;
					return QMDI_TDQ_TEST_FAILED;
					//V6CriticalMessageBox(NULL, L"QMDataIntegrity.cpp: Line(134) blockId==QMC_INVALID_BLOCK_NUMBER in To Disk queue", L"Debug Break", MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST );
				}
			} // End of FOR
		} // End of IF
		  // Tranverse Persisted Block Queues
		for (USHORT persistedQueueNumber = QMC_ZERO; persistedQueueNumber < numOfQueues; persistedQueueNumber++) {
			if (ValidateBlockId(pPersistDataBlockQueue[persistedQueueNumber].Head, numOfBlocks)) {
				blockId = pBlock[pPersistDataBlockQueue[persistedQueueNumber].Head].blockHeader.blockId;
				BlockCount = pPersistDataBlockQueue[persistedQueueNumber].NumOfBlocksInQueue;
				// Tranverse the Specified Queue
				for (USHORT blockIndex = QMC_ZERO; blockIndex < BlockCount; blockIndex++) {
					if (ValidateBlkQLink(QMDI_PDBQ, blockId, numOfBlocks, pBlock, psBlockCoverage)) {
						RecoveredBlkID = blockId;
						//Move to next block
						blockId = pBlock[blockId].blockHeader.nextBlock;
						//Update the counter
						numOfBlocksChecked++;
						if (psBlockCoverage[RecoveredBlkID].usCoverage > 1) { //Check if it head of two blocks
							if (blockIndex == 0) { //If it is Head Block
								swprintf(printMsg, 256,
										L"----Duplicate BLK Recovered: %d QID: %d Status: %d Next: %d Coverage: %d---\n\n",
										RecoveredBlkID, pBlock[RecoveredBlkID].blockHeader.QueueId,
										pBlock[RecoveredBlkID].blockHeader.blockstatus,
										pBlock[RecoveredBlkID].blockHeader.nextBlock,
										psBlockCoverage[RecoveredBlkID].usCoverage);
								qDebug() << printMsg;
								;
								//Reset the Head of Queue , this is the case where the block added to ToDiskQ
								//but before removing from Pesistant block the recorder powered OFF
								pPersistDataBlockQueue[persistedQueueNumber].Head = QMC_START_OF_QUEUE;
								pPersistDataBlockQueue[persistedQueueNumber].Tail = QMC_END_OF_QUEUE;
								pPersistDataBlockQueue[persistedQueueNumber].NumOfBlocksInQueue = QMC_ZERO;
								psBlockCoverage[RecoveredBlkID].usCoverage--; //Remove double coverage
								break; //out of loop, go to next queue
							} else {
								swprintf(printMsg, 256,
										L"##PBQ##Duplicate BLK NOT Recovered: %d QID: %d Status: %d Next: %d Coverage: %d\n\n",
										RecoveredBlkID, pBlock[RecoveredBlkID].blockHeader.QueueId,
										pBlock[RecoveredBlkID].blockHeader.blockstatus,
										pBlock[RecoveredBlkID].blockHeader.nextBlock,
										psBlockCoverage[RecoveredBlkID].usCoverage);
								qDebug() << printMsg;
								;
							}
						}
					} else {
						blockIndex = pPersistDataBlockQueue[persistedQueueNumber].NumOfBlocksInQueue;
#ifdef DBG_FILE_LOG_QUEUEMM_ENABLE
        strLog = QString::asprintf("CQMDataIntegrity::TBC blockId==QMC_INVALID_BLOCK_NUMBER in in Data queue GTC - %d\r\n",GetTickCount());
        m_QMHardwareLayer.m_debugFileLogger.WriteToDebugLogFile(strLog);
        strLog = QString::asprintf("CQMDataIntegrity::PBQ blockIndex : %d GTC - %d\r\n",blockIndex,GetTickCount());
        m_QMHardwareLayer.m_debugFileLogger.WriteToDebugLogFile(strLog);
#endif
						delete[] psBlockCoverage;
						return QMDI_PBQ_TEST_FAILED;
						//V6CriticalMessageBox(NULL, L"QMDataIntegrity.cpp: Line(159) blockId==QMC_INVALID_BLOCK_NUMBER in Data queue", L"Debug Break", MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST );
					}
				} // End of FOR
			} // End of IF
		} // End of FOR
		  // Check to ensure all blocks belong to One Queue Only
		for (USHORT blockIndex = QMC_ZERO; blockIndex < numOfBlocks; blockIndex++) {
			if (QMC_ZERO == psBlockCoverage[blockIndex].usCoverage || psBlockCoverage[blockIndex].usCoverage > 1) {
				qDebug("############################Orphan Block: %d QID: %d Status: %d Next: %d Coverage: %d\n\n",
						blockIndex, pBlock[blockIndex].blockHeader.QueueId, pBlock[blockIndex].blockHeader.blockstatus,
						pBlock[blockIndex].blockHeader.nextBlock, psBlockCoverage[blockIndex].usCoverage);
				swprintf(printMsg, 256,
						L"############################Orphan Block: %d QID: %d Status: %d Next: %d Coverage: %d\n\n",
						blockIndex, pBlock[blockIndex].blockHeader.QueueId, pBlock[blockIndex].blockHeader.blockstatus,
						pBlock[blockIndex].blockHeader.nextBlock, psBlockCoverage[blockIndex].usCoverage);
				qDebug() << printMsg;
				;
				//				qDebug("############################Next Block: %d QID: %d Status: %d Next: %d\n\n",
				//					blockIndex, pBlock[pBlock[blockIndex].blockHeader.nextBlock].blockHeader.QueueId,
				//					blockIndex, pBlock[pBlock[blockIndex].blockHeader.nextBlock].blockHeader.blockstatus,
				//					blockIndex, pBlock[pBlock[blockIndex].blockHeader.nextBlock].blockHeader.nextBlock);
				retValue = QMDI_TEST_FAILED;
			} // End of IF
		} // End of IF
		  // Delete the allocated Memory
		delete[] psBlockCoverage;
	} // End of IF
	return (retValue);
} // End of Member Function	
//****************************************************************************
/// Test to determine whether all files are allocated across the appropiate Queues Correctly
///
/// @param[in] 	pFileAvailableQueue	- Pointer to the File Available Queue
/// @param[in] 	pPersistDataFileQueue - Pointer to the First Persisted Data File Queue
/// @param[in] 	pFileHeader			- Pointer to the First File Header
/// @param[in] 	numOfFiles			- Number of Available Files
/// @param[in] 	numOfQueues			- Number of Persisted Data File Queues
///
/// @return QMDI_TEST_PASSED - Test has PASSED successfully
///		QMDI_TEST_FAILED - Test has FAILED
/// 
//****************************************************************************
T_QMDI_RETURN_VALUE CQMDataIntegrity::TestFileCoverage(const T_QMC_DATAFILE_QUEUE *const pFileAvailableQueue,
		const T_QMC_PERSIST_DATAFILE_QUEUE *const pPersistDataFileQueue, const T_QMC_DATAFILE_HEADER *const pFileHeader,
		const USHORT numOfFiles, const USHORT numOfQueues) {
	T_QMDI_RETURN_VALUE retValue = QMDI_TEST_PASSED; // Member Function Return Value indicates Test PASSED or FAILED
	WCHAR printMsg[256];
	bool bLoopDetected = false;
	SFileCoverage *psFileCoverage = new SFileCoverage[numOfFiles];
	memset(psFileCoverage, QMC_ZERO, sizeof(SFileCoverage) * numOfFiles);
	USHORT fileId = QMC_INVALID_FILE_NUMBER;
	USHORT nextfileId = QMC_ZERO;
	if (NULL != psFileCoverage) {
		// if( QMC_INVALID_BLOCK_NUMBER != pFileAvailableQueue->Head )
		if (ValidateFileId(pFileAvailableQueue->Head, numOfFiles)) {
			// Tranverse each Queue that stores files, building up the block coverage
			fileId = pFileHeader[pFileAvailableQueue->Head].fileId;
			qDebug("TFC FAQ head : %d fileid : %d\n", pFileAvailableQueue->Head,
					pFileHeader[pFileAvailableQueue->Head].fileId);
			// Tranverse Free Block Queue
			for (USHORT freeFileIndex = QMC_ZERO; freeFileIndex < pFileAvailableQueue->NumOfFilesInQueue;
					freeFileIndex++) {
				BOOL bValidFileId = ValidateFileId(fileId, numOfFiles);
				if ( TRUE == bValidFileId) {
					qDebug("TFC FAQ PF : %d fId : %d NF : %d FMode : %d QID : %d\n", pFileHeader[fileId].previousFile,
							fileId, pFileHeader[fileId].nextFile, pFileHeader[fileId].fileMode,
							pFileHeader[fileId].queueId);
					//UpdateCoverage
					UpdateFileCoverage(QMDI_FAQ, fileId, pFileHeader, psFileCoverage, bLoopDetected);
					//Get Next file to print the link
					nextfileId = pFileHeader[fileId].nextFile;
					fileId = pFileHeader[fileId].nextFile;
				}
				if ((FALSE == bValidFileId) || (true == bLoopDetected)) {
					/*QString  sysMessage;
					 sysMessage = QString::asprintf( _T("Link Break or Loop(%d) in BID %d NBID %d"), bLoopDetected, fileId, nextfileId );
					 LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_ERROR,sysMessage);*/
					delete[] psFileCoverage;
					return QMDI_TEST_FAILED;
				}
			} // End of FOR
		} // End of IF
		  // Tranverse Persisted Block Queues
		for (USHORT persistedDataFileQueueNumber = QMC_ZERO; persistedDataFileQueueNumber < numOfQueues;
				persistedDataFileQueueNumber++) {
			//if( QMC_INVALID_BLOCK_NUMBER != pPersistDataFileQueue[persistedDataFileQueueNumber].Head )
			if (ValidateFileId(pPersistDataFileQueue[persistedDataFileQueueNumber].Head, numOfFiles)) {
				fileId = pFileHeader[pPersistDataFileQueue[persistedDataFileQueueNumber].Head].fileId;
				qDebug("TFC FAQ head : %d fileid : %d\n", pPersistDataFileQueue[persistedDataFileQueueNumber].Head,
						fileId);
				// Tranverse the Specified Queue
				for (USHORT fileIndex = QMC_ZERO;
						fileIndex < pPersistDataFileQueue[persistedDataFileQueueNumber].NumOfFilesInQueue;
						fileIndex++) {
					BOOL bValidFileId = ValidateFileId(fileId, numOfFiles);
					if ( TRUE == bValidFileId) {
						qDebug("TFC PFAQ PF : %d fId : %d NF : %d FMode : %d QID : %d\n",
								pFileHeader[fileId].previousFile, fileId, pFileHeader[fileId].nextFile,
								pFileHeader[fileId].fileMode, pFileHeader[fileId].queueId);
						//UpdateCoverage
						UpdateFileCoverage(QMDI_PFAQ, fileId, pFileHeader, psFileCoverage, bLoopDetected);
						//Get Next file to print the link
						nextfileId = pFileHeader[fileId].nextFile;
						fileId = pFileHeader[fileId].nextFile;
					}
					if ((FALSE == bValidFileId) || (true == bLoopDetected)) {
						/*QString  sysMessage;
						 sysMessage = QString::asprintf( _T("Link Break or Loop(%d) in BID %d NBID %d"), bLoopDetected, fileId, nextfileId );
						 LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_ERROR,sysMessage);*/
						delete[] psFileCoverage;
						return QMDI_TEST_FAILED;
					}
				} // End of FOR
			} // End of IF
		} // End of FOR
		  // Check to ensure all blocks belong to One Queue Only
		for (USHORT fileCoverageIndex = QMC_ZERO; fileCoverageIndex < numOfFiles; fileCoverageIndex++) {
			if (QMC_ZERO == psFileCoverage[fileCoverageIndex].usfileCoverage
					|| psFileCoverage[fileCoverageIndex].usfileCoverage > 1) {
				qDebug(
						"############################Orphan File: %d QID: %d Status: %d Mode: %d Next: %d Previou: %d Coverage: %d\n\n",
						fileCoverageIndex, pFileHeader[fileCoverageIndex].queueId,
						pFileHeader[fileCoverageIndex].fileStatus, pFileHeader[fileCoverageIndex].fileMode,
						pFileHeader[fileCoverageIndex].nextFile, pFileHeader[fileCoverageIndex].previousFile,
						psFileCoverage[fileCoverageIndex].usfileCoverage);
				swprintf(printMsg, 256,
						L"############################Orphan File: %d QID: %d Status: %d Mode: %d Next: %d Previou: %d Coverage: %d\n\n",
						fileCoverageIndex, pFileHeader[fileCoverageIndex].queueId,
						pFileHeader[fileCoverageIndex].fileStatus, pFileHeader[fileCoverageIndex].fileMode,
						pFileHeader[fileCoverageIndex].nextFile, pFileHeader[fileCoverageIndex].previousFile,
						psFileCoverage[fileCoverageIndex].usfileCoverage);
				qDebug() << printMsg;
				;
				retValue = QMDI_TEST_FAILED;
			} // End of IF
		} // End of IF
		  // Delete the allocated Memory
		delete[] psFileCoverage;
	} // End of IF
	return (retValue);
} // End of Member Function	
//****************************************************************************
/// Attempt to recover damaged block queue system
///
/// @param[in] 	pFreeBlockQueue		- Pointer to the Free Block Queue
/// @param[in] 	pTempStoredBlockQueue - Pointer to the ToTemp Storage Queue
/// @param[in] 	pToDiskQueue		- Pointer to the To Disk Queue
/// @param[in] 	pPersistDataBlockQueue - Pointer to the First Persisted Data Block Queue
/// @param[in] 	pBlock				- Pointer to the First Data Block
/// @param[in] 	numOfBlocks			- Number of Available Data Blocks
/// @param[in] 	numOfQueues			- Number of Persisted Data Blocks Queues
///
/// @return QMDI_TEST_PASSED - Test has PASSED successfully
///		QMDI_TEST_FAILED - Test has FAILED
/// 
//****************************************************************************
T_QMDI_RETURN_VALUE CQMDataIntegrity::RecoverBlockCoverage(T_QMC_BLOCK_QUEUE *pFreeBlockQueue,
		T_QMC_BLOCK_QUEUE *pTempStoredBlockQueue, T_QMC_BLOCK_QUEUE *pToDiskQueue,
		T_QMC_PERSIST_DATA_BLKQ *pPersistDataBlockQueue, T_QMC_BLOCK *pBlock, const USHORT numOfBlocks,
		const USHORT numOfQueues) {
	//first build up a picture of the orphanage
	USHORT *pBlockCoverage = new USHORT[numOfBlocks];
	memset(pBlockCoverage, QMC_ZERO, sizeof(USHORT) * numOfBlocks);
	USHORT *pOrphaned = new USHORT[numOfBlocks];
	memset(pOrphaned, QMC_ZERO, sizeof(USHORT) * numOfBlocks);
	USHORT *pDuplicated = new USHORT[numOfBlocks];
	memset(pDuplicated, QMC_ZERO, sizeof(USHORT) * numOfBlocks);
	USHORT OrphanCnt = 0;
	USHORT DuplCnt = 0;
	USHORT FreeCnt = 0; //could be negative
	SHORT FreeDiff = 0;
	USHORT TmpSQCnt = 0;
	SHORT TmpSQDiff = 0;
	USHORT TDQCnt = 0;
	SHORT TDQDiff = 0;
	USHORT *pQCount = new USHORT[numOfQueues];
	memset(pQCount, QMC_ZERO, sizeof(USHORT) * numOfQueues);
	USHORT *pQDiff = new USHORT[numOfQueues];
	memset(pQDiff, QMC_ZERO, sizeof(USHORT) * numOfQueues);
	int iAllQueues = numOfQueues + 3;
	BOOL *paAffectedQueues = new BOOL[iAllQueues];
	memset(paAffectedQueues, QMC_ZERO, sizeof(BOOL) * iAllQueues);
	USHORT *pausAffectQueues = NULL; //allocate later
  USHORT usAffectedCount = 0;
	const USHORT FREE_QUEUE_INDEX = numOfQueues;
	const USHORT TO_DISK_Q_INDEX = numOfQueues + 1;
	const USHORT TEMP_STORAGE_Q_INDEX = numOfQueues + 2;
	USHORT numOfBlocksChecked = 0;
  USHORT blockId = 0;
	BOOL bFreeBlockTailCorrect = FALSE;
	BOOL bToDiskTailCorrect = FALSE;
	BOOL bTempStorageTailCorrect = FALSE;
	BOOL *pabQTailCorrect = new BOOL[numOfQueues];
	memset(pabQTailCorrect, QMC_ZERO, sizeof(BOOL) * numOfQueues);
	BOOL bRecovered = FALSE;
	WCHAR printMsg[256];
	swprintf(printMsg, 256, L"RecoverBlockCoverage: numOfQueues = %d, numOfBlocks = %d\n", numOfQueues, numOfBlocks);
	qDebug() << printMsg;
	;
	swprintf(printMsg, 256, L"RecoverBlockCoverage: FreeBlockQueue = %d, TempStoredBlockQueue = %d, ToDiskQueue = %d\n",
			pFreeBlockQueue->NumOfBlocksInQueue, pTempStoredBlockQueue->NumOfBlocksInQueue,
			pToDiskQueue->NumOfBlocksInQueue);
	qDebug() << printMsg;
	;
	if ( NULL != pBlockCoverage) {
		// Tranverse each Queue that stores Blocks, building up the block coverage
		USHORT HeadIndex = pFreeBlockQueue->Head;
		if (QMC_START_OF_QUEUE != HeadIndex) {
			blockId = pBlock[HeadIndex].blockHeader.blockId;
			if (QMC_INVALID_BLOCK_NUMBER != pFreeBlockQueue->Head) {
				// Traverse Free Block Queue
				for (USHORT freeBlockIndex = QMC_ZERO;
						(freeBlockIndex < pFreeBlockQueue->NumOfBlocksInQueue) && (freeBlockIndex < numOfBlocks);
						freeBlockIndex++) {
					if (QMC_INVALID_BLOCK_NUMBER != blockId) {
						//check the tail matches
						if ((freeBlockIndex == (pFreeBlockQueue->NumOfBlocksInQueue - 1))
								&& (blockId == pFreeBlockQueue->Tail)
								&& (QMC_INVALID_BLOCK_NUMBER == pBlock[blockId].blockHeader.nextBlock)) {
							bFreeBlockTailCorrect = TRUE;
						}
						//mark the block as seen
						pBlockCoverage[blockId]++;
						blockId = pBlock[blockId].blockHeader.nextBlock;
						numOfBlocksChecked++;
						FreeCnt++;
					} else
						//end of the line
						freeBlockIndex = pFreeBlockQueue->NumOfBlocksInQueue;
				} // End of FOR
				  //set the difference between the supposed count and the actual count
				if (FreeCnt != pFreeBlockQueue->NumOfBlocksInQueue) {
					FreeDiff = pFreeBlockQueue->NumOfBlocksInQueue - FreeCnt;
					paAffectedQueues[FREE_QUEUE_INDEX] = TRUE;
					usAffectedCount++;
				}
				//				else
				//					FreeCnt = 0;
			} // End of IF
			else {
				paAffectedQueues[FREE_QUEUE_INDEX] = TRUE;
				usAffectedCount++;
			}
		}
		if (QMC_INVALID_BLOCK_NUMBER != pTempStoredBlockQueue->Head) {
			blockId = pBlock[pTempStoredBlockQueue->Head].blockHeader.blockId;
			// Tranverse To Temp Storage Queue
			for (USHORT blockIndex = QMC_ZERO;
					(blockIndex < pTempStoredBlockQueue->NumOfBlocksInQueue) && (blockIndex < numOfBlocks);
					blockIndex++) {
				if (QMC_INVALID_BLOCK_NUMBER != blockId) {
					//check the tail matches
					if ((blockIndex == (pTempStoredBlockQueue->NumOfBlocksInQueue - 1))
							&& (blockId == pTempStoredBlockQueue->Tail)
							&& (QMC_INVALID_BLOCK_NUMBER == pBlock[blockId].blockHeader.nextBlock)) {
						bTempStorageTailCorrect = TRUE;
					}
					pBlockCoverage[blockId]++;
					blockId = pBlock[blockId].blockHeader.nextBlock;
					numOfBlocksChecked++;
					TmpSQCnt++;
				} else
					blockIndex = pTempStoredBlockQueue->NumOfBlocksInQueue;
			} // End of FOR
			if (TmpSQCnt != pTempStoredBlockQueue->NumOfBlocksInQueue) {
				TmpSQDiff = pTempStoredBlockQueue->NumOfBlocksInQueue - TmpSQCnt;
				paAffectedQueues[TEMP_STORAGE_Q_INDEX] = TRUE;
				usAffectedCount++;
			}
		} // End of IF
		else {
			paAffectedQueues[TEMP_STORAGE_Q_INDEX] = TRUE;
			usAffectedCount++;
		}
		if (QMC_INVALID_BLOCK_NUMBER != pToDiskQueue->Head) {
			blockId = pBlock[pToDiskQueue->Head].blockHeader.blockId;
			// Tranverse To Disk Queue
			for (USHORT blockIndex = QMC_ZERO;
					(blockIndex < pToDiskQueue->NumOfBlocksInQueue) && (blockIndex < numOfBlocks); blockIndex++) {
				if (QMC_INVALID_BLOCK_NUMBER != blockId) {
					//check the tail matches
					if ((blockIndex == (pToDiskQueue->NumOfBlocksInQueue - 1)) && (blockId == pToDiskQueue->Tail)
							&& (QMC_INVALID_BLOCK_NUMBER == pBlock[blockId].blockHeader.nextBlock)) {
						bToDiskTailCorrect = TRUE;
					}
					pBlockCoverage[blockId]++;
					blockId = pBlock[blockId].blockHeader.nextBlock;
					numOfBlocksChecked++;
					TDQCnt++;
				} else
					blockIndex = pToDiskQueue->NumOfBlocksInQueue;
			} // End of FOR
			if (TDQCnt != pToDiskQueue->NumOfBlocksInQueue) {
				TDQDiff = pToDiskQueue->NumOfBlocksInQueue - TDQCnt;
				paAffectedQueues[TO_DISK_Q_INDEX] = TRUE;
				usAffectedCount++;
			}
		} // End of IF
		else {
			paAffectedQueues[TO_DISK_Q_INDEX] = TRUE;
			usAffectedCount++;
		}
		// Tranverse Persisted Block Queues
		for (USHORT persistedQueueNumber = QMC_ZERO; persistedQueueNumber < numOfQueues; persistedQueueNumber++) {
			if (QMC_INVALID_BLOCK_NUMBER != pPersistDataBlockQueue[persistedQueueNumber].Head) {
				blockId = pBlock[pPersistDataBlockQueue[persistedQueueNumber].Head].blockHeader.blockId;
				// Traverse the Specified Queue
				for (USHORT blockIndex = QMC_ZERO;
						blockIndex < pPersistDataBlockQueue[persistedQueueNumber].NumOfBlocksInQueue; blockIndex++) {
					if (QMC_INVALID_BLOCK_NUMBER != blockId) {
						//check the tail matches
						if ((blockIndex == (pPersistDataBlockQueue[persistedQueueNumber].NumOfBlocksInQueue - 1))
								&& (blockId == pPersistDataBlockQueue[persistedQueueNumber].Tail)
								&& (QMC_INVALID_BLOCK_NUMBER == pBlock[blockId].blockHeader.nextBlock)) {
							pabQTailCorrect[persistedQueueNumber] = TRUE;
						}
						pBlockCoverage[blockId]++;
						blockId = pBlock[blockId].blockHeader.nextBlock;
						numOfBlocksChecked++;
						pQCount[persistedQueueNumber]++;
					} else
						//end of the line, queue ended prematurely
						blockIndex = pPersistDataBlockQueue[persistedQueueNumber].NumOfBlocksInQueue;
				} // End of FOR
				if (pQCount[persistedQueueNumber] != pPersistDataBlockQueue[persistedQueueNumber].NumOfBlocksInQueue) {
					pQDiff[persistedQueueNumber] = pPersistDataBlockQueue[persistedQueueNumber].NumOfBlocksInQueue
							- pQCount[persistedQueueNumber];
					paAffectedQueues[persistedQueueNumber] = TRUE;
					usAffectedCount++;
				}
				//				else
				//					pQCount[persistedQueueNumber] = 0;
			} // End of IF
			else
				pabQTailCorrect[persistedQueueNumber] = TRUE;
		} // End of FOR
		  // Check to ensure all blocks belong to One Queue Only
		for (USHORT blockIndex = QMC_ZERO; blockIndex < numOfBlocks; blockIndex++) {
			if (QMC_ZERO == pBlockCoverage[blockIndex])
				pOrphaned[OrphanCnt++] = blockIndex;

			if (pBlockCoverage[blockIndex] > 1)
				pDuplicated[DuplCnt++] = blockIndex;

		} // End of IF

		//find a queue which was doing some block manipulation
		USHORT manipulatingQ[5] = { QMC_INVALID_BLOCK_NUMBER, QMC_INVALID_BLOCK_NUMBER, QMC_INVALID_BLOCK_NUMBER,
				QMC_INVALID_BLOCK_NUMBER, QMC_INVALID_BLOCK_NUMBER };
		USHORT Total = QMC_ZERO;
		USHORT ManipCnt = QMC_ZERO;
		for (USHORT ind = QMC_ZERO; ind < numOfQueues; ind++) {
			if (pPersistDataBlockQueue[ind].Status > QMC_BLKQ_STATUS_QUEUE_NOT_SETUP) {
				if (ManipCnt < 5)
					manipulatingQ[ManipCnt++] = ind;
				Total++;
			}
		}
		//produce report

    QString LogPath="";
    QString filename="Recovery.LOG";
    pDALGLB->BuildPath(IDS_INTERNAL_SD, IDS_ROOT, &filename, &LogPath, MAX_PATH);
		CStorage *pFile = new CStorage;
    pFile->Open(LogPath, QFile::Append | QFile::WriteOnly);
		pFile->Write(L"Data Block recovery attempt Started\r\n", 37 * 2);
    QString csTmp;
    csTmp = QString::asprintf("Total Blocks = %d\r\n", numOfBlocks);
    pFile->Write(csTmp.toLocal8Bit().data(), csTmp.length() * 2);
    csTmp = QString::asprintf("Orphan Count = %d\r\n", OrphanCnt);
    pFile->Write(csTmp.toLocal8Bit().data(), csTmp.length() * 2);
    csTmp = QString::asprintf("Duplicate Count = %d\r\n", DuplCnt);
    pFile->Write(csTmp.toLocal8Bit().data(), csTmp.length() * 2);
    csTmp = QString::asprintf("Blocks Checked = %d\r\n", numOfBlocksChecked);
    pFile->Write(csTmp.toLocal8Bit().data(), csTmp.length() * 2);
    csTmp = QString::asprintf("Free Head = %d\r\n", pFreeBlockQueue->Head);
    pFile->Write(csTmp.toLocal8Bit().data(), csTmp.length() * 2);
    csTmp = QString::asprintf("Free Tail = %d\r\n", pFreeBlockQueue->Tail);
    pFile->Write(csTmp.toLocal8Bit().data(), csTmp.length() * 2);
    csTmp = QString::asprintf("Free Count = %d\r\n", FreeCnt);
    pFile->Write(csTmp.toLocal8Bit().data(), csTmp.length() * 2);
    csTmp = QString::asprintf("Free Difference = %d\r\n", FreeDiff);
    pFile->Write(csTmp.toLocal8Bit().data(), csTmp.length() * 2);
    csTmp = QString::asprintf("Free Affected = %s\r\n", (paAffectedQueues[FREE_QUEUE_INDEX]) ? "Yes" : "No");
    pFile->Write(csTmp.toLocal8Bit().data(), csTmp.length() * 2);
    csTmp = QString::asprintf("Free Tail Correct = %s\r\n", (bFreeBlockTailCorrect) ? "Yes" : "No");
    pFile->Write(csTmp.toLocal8Bit().data(), csTmp.length() * 2);
    csTmp = QString::asprintf("Temp Storage Tail Correct = %s\r\n", (bTempStorageTailCorrect) ? "Yes" : "No");
    pFile->Write(csTmp.toLocal8Bit().data(), csTmp.length() * 2);
    csTmp = QString::asprintf("Temp Storage Count = %d\r\n", TmpSQCnt);
    pFile->Write(csTmp.toLocal8Bit().data(), csTmp.length() * 2);
    csTmp = QString::asprintf("Temp Storage Head = %d\r\n", pTempStoredBlockQueue->Head);
    pFile->Write(csTmp.toLocal8Bit().data(), csTmp.length() * 2);
    csTmp = QString::asprintf("Temp Storage Tail = %d\r\n", pTempStoredBlockQueue->Tail);
    pFile->Write(csTmp.toLocal8Bit().data(), csTmp.length() * 2);
    csTmp = QString::asprintf("Temp Storage Difference = %d\r\n", TmpSQDiff);
    pFile->Write(csTmp.toLocal8Bit().data(), csTmp.length() * 2);
    csTmp = QString::asprintf("Temp Storage Affected = %s\r\n", (paAffectedQueues[TEMP_STORAGE_Q_INDEX]) ? "Yes" : "No");
    pFile->Write(csTmp.toLocal8Bit().data(), csTmp.length() * 2);
    csTmp = QString::asprintf("To Disk Tail Correct = %s\r\n", (bToDiskTailCorrect) ? "Yes" : "No");
    pFile->Write(csTmp.toLocal8Bit().data(), csTmp.length() * 2);
    csTmp = QString::asprintf("To Disk Count = %d\r\n", TDQCnt);
    pFile->Write(csTmp.toLocal8Bit().data(), csTmp.length() * 2);
    csTmp = QString::asprintf("To Disk Head = %d\r\n", pToDiskQueue->Head);
    pFile->Write(csTmp.toLocal8Bit().data(), csTmp.length() * 2);
    csTmp = QString::asprintf("To Disk Tail = %d\r\n", pToDiskQueue->Tail);
    pFile->Write(csTmp.toLocal8Bit().data(), csTmp.length() * 2);
    csTmp = QString::asprintf("To Disk Difference = %d\r\n", TDQDiff);
    pFile->Write(csTmp.toLocal8Bit().data(), csTmp.length() * 2);
    csTmp = QString::asprintf("To Disk Affected = %s\r\n", (paAffectedQueues[TO_DISK_Q_INDEX]) ? "Yes" : "No");
    pFile->Write(csTmp.toLocal8Bit().data(), csTmp.length() * 2);
		for (int QCount = 0; QCount < numOfQueues; QCount++) {
    csTmp = QString::asprintf("Persisted Queue %d Head = %d\r\n", QCount, pPersistDataBlockQueue[QCount].Head);
    pFile->Write(csTmp.toLocal8Bit().data(), csTmp.length() * 2);
    csTmp = QString::asprintf("Persisted Queue %d Tail = %d\r\n", QCount, pPersistDataBlockQueue[QCount].Tail);
    pFile->Write(csTmp.toLocal8Bit().data(), csTmp.length() * 2);
    csTmp = QString::asprintf("Persisted Queue %d Count = %d\r\n", QCount, pQCount[QCount]);
    pFile->Write(csTmp.toLocal8Bit().data(), csTmp.length() * 2);
    csTmp = QString::asprintf("Persisted Queue %d Difference = %d\r\n", QCount, pQDiff[QCount]);
    pFile->Write(csTmp.toLocal8Bit().data(), csTmp.length() * 2);
    csTmp = QString::asprintf("Persisted Queue %d Affected = %s\r\n", QCount, (paAffectedQueues[QCount]) ? "Yes" : "No");
    pFile->Write(csTmp.toLocal8Bit().data(), csTmp.length() * 2);
    csTmp = QString::asprintf("Persisted Queue %d Tail Correct = %s\r\n", QCount,
        (pabQTailCorrect[QCount]) ? "Yes" : "No");
    pFile->Write(csTmp.toLocal8Bit().data(), csTmp.length() * 2);
    csTmp = QString::asprintf("Persisted Queue %d Operation = %d\r\n", QCount, pPersistDataBlockQueue[QCount].Status);
    pFile->Write(csTmp.toLocal8Bit().data(), csTmp.length() * 2);
		}
		pFile->Write(L"Orphans\r\n", 18);
		for (int OrphanIndex = 0; OrphanIndex < OrphanCnt; OrphanIndex++) {
    csTmp = QString::asprintf("%d->%d Q%d S%d| ", pOrphaned[OrphanIndex],
					pBlock[pOrphaned[OrphanIndex]].blockHeader.nextBlock,
					pBlock[pOrphaned[OrphanIndex]].blockHeader.QueueId,
					pBlock[pOrphaned[OrphanIndex]].blockHeader.blockstatus);
    pFile->Write(csTmp.toLocal8Bit().data(), csTmp.length() * 2);
		}
		pFile->Write(L"\r\nDuplicates\r\n", 24);
		for (int DupliIndex = 0; DupliIndex < DuplCnt; DupliIndex++) {
    csTmp = QString::asprintf("%d->%d Q%d S%d| ", pDuplicated[DupliIndex],
					pBlock[pDuplicated[DupliIndex]].blockHeader.nextBlock,
					pBlock[pDuplicated[DupliIndex]].blockHeader.QueueId,
					pBlock[pDuplicated[DupliIndex]].blockHeader.blockstatus);
    pFile->Write(csTmp.toLocal8Bit().data(), csTmp.length() * 2);
		}
    csTmp = QString::asprintf("\r\nNum Queues Doing operations = %d\r\n", Total);
    pFile->Write(csTmp.toLocal8Bit().data(), csTmp.length() * 2);

		//put affected queues into a concentrated array
		if (usAffectedCount) {
			pausAffectQueues = new USHORT[usAffectedCount];
			USHORT decrementer = usAffectedCount;
			for (int c = iAllQueues - 1; c >= 0 && decrementer > 0; c--) {
				if (paAffectedQueues[c])
					pausAffectQueues[--decrementer] = c;
			}
		}

		//just doing most common instances fist
		BOOL *pOrphRecovered = new BOOL[OrphanCnt];
		BOOL *pManipRecovered = new BOOL[ManipCnt];
		memset(pOrphRecovered, NULL, sizeof(BOOL) * OrphanCnt);
		memset(pManipRecovered, NULL, sizeof(BOOL) * ManipCnt);
		USHORT usOrphRecoverCnt = 0;
		USHORT usManipRecoverCnt = 0;
		if (OrphanCnt == 1 && DuplCnt == 0) {
			//should be one of a number of instances
			if (pBlock[pOrphaned[0]].blockHeader.nextBlock == pTempStoredBlockQueue->Head) {
				//block was going to the free queue so lets add it on
				pFreeBlockQueue->NumOfBlocksInQueue++;
				if (QMC_END_OF_QUEUE == pFreeBlockQueue->Tail || !pFreeBlockQueue->NumOfBlocksInQueue) {
					pFreeBlockQueue->Head = pOrphaned[0];
					pFreeBlockQueue->Tail = pOrphaned[0];
					//pFreeBlockQueue->NumOfBlocksInQueue++;
					pBlock[pOrphaned[0]].blockHeader.nextBlock = QMC_END_OF_QUEUE;
					pBlock[pOrphaned[0]].blockHeader.blockstatus = 0;

					bRecovered = TRUE;
				} else {
					pBlock[pFreeBlockQueue->Tail].blockHeader.nextBlock = pOrphaned[0];
					pFreeBlockQueue->Tail = pOrphaned[0];
					bRecovered = TRUE;
				}
			}
			//should be one of a number of instances
			if (pBlock[pOrphaned[0]].blockHeader.nextBlock == pToDiskQueue->Head) {
				//block was going to the free queue so lets add it on
				pFreeBlockQueue->NumOfBlocksInQueue++;
				if (QMC_END_OF_QUEUE == pFreeBlockQueue->Tail || !pFreeBlockQueue->NumOfBlocksInQueue) {
					pFreeBlockQueue->Head = pOrphaned[0];
					pFreeBlockQueue->Tail = pOrphaned[0];
					//pFreeBlockQueue->NumOfBlocksInQueue++;
					pBlock[pOrphaned[0]].blockHeader.nextBlock = QMC_END_OF_QUEUE;
					pBlock[pOrphaned[0]].blockHeader.blockstatus = 0;

					bRecovered = TRUE;
				} else {
					pBlock[pFreeBlockQueue->Tail].blockHeader.nextBlock = pOrphaned[0];
					pFreeBlockQueue->Tail = pOrphaned[0];
					bRecovered = TRUE;
				}
			} else if (pBlock[pOrphaned[0]].blockHeader.nextBlock == pFreeBlockQueue->Head) {
				//was being allocated to a queue. no point doing so now, so put it back in the Free Q
				pFreeBlockQueue->NumOfBlocksInQueue++;
				pBlock[pOrphaned[0]].blockHeader.nextBlock = pFreeBlockQueue->Head;
				pFreeBlockQueue->Head = pOrphaned[0];
				bRecovered = TRUE;
			}
		} else if (Total == 0) {
			//no queue doing any operations at the time
			//find affected queues
			USHORT usTailInd = 0;
			if (FreeDiff) {
				//is the reported tail in the orphan list
				BOOL Found = FALSE;
				for (int i = 0; i < OrphanCnt && !Found; i++) {
					if (pOrphaned[i] == pFreeBlockQueue->Tail) {
						Found = TRUE;
						usTailInd = i;
					}

				}
				if (Found) {
					USHORT PrevBlock = pOrphaned[usTailInd];
					BOOL HeadFound = TRUE;
					USHORT FoundCnt = 0;
					if (1 < FreeDiff) {
						HeadFound = FALSE;
						//find the start of the unlinked stretch
						//loop for each difference
						for (int k = 0; k < FreeDiff && !HeadFound; k++) {
							BOOL bPrevFound = FALSE;
							//scan the orphan block array for a block pointing to the last one
							for (int j = 0; j < OrphanCnt && !bPrevFound; j++) {
								if (pBlock[pOrphaned[j]].blockHeader.nextBlock == PrevBlock) {
									PrevBlock = pOrphaned[j];
									bPrevFound = TRUE; //end the loop
									FoundCnt++;
								}
							}
							if (!bPrevFound) {
								//last iteration was the top of the queue
								HeadFound = TRUE;
							}
						}
					}
					if (HeadFound && (FoundCnt == FreeDiff - 1)) {
						//Prev is top of the unlinked list
						//find the end of the queue to attach this to
						USHORT Blk = pFreeBlockQueue->Head;
						for (USHORT i = 1; i < FreeCnt; i++) {
							if (pBlock[Blk].blockHeader.nextBlock != QMC_INVALID_BLOCK_NUMBER)
								Blk = pBlock[Blk].blockHeader.nextBlock;
						}

						//link PrevBlock in to Blk where it belongs
						pBlock[Blk].blockHeader.nextBlock = PrevBlock;
						bRecovered = TRUE;
					}
				}
			}

			usTailInd = 0;
			if (TmpSQDiff) {
				//is the reported tail in the orphan list
				BOOL Found = FALSE;
				for (int i = 0; i < OrphanCnt && !Found; i++) {
					if (pOrphaned[i] == pTempStoredBlockQueue->Tail) {
						Found = TRUE;
						usTailInd = i;
					}

				}
				if (Found) {
					USHORT PrevBlock = pOrphaned[usTailInd];
					BOOL HeadFound = TRUE;
					USHORT FoundCnt = 0;
					if (1 < TmpSQDiff) {
						HeadFound = FALSE;
						//find the start of the unlinked stretch
						//loop for each difference
						for (int k = 0; k < TmpSQDiff && !HeadFound; k++) {
							BOOL bPrevFound = FALSE;
							//scan the orphan block array for a block pointing to the last one
							for (int j = 0; j < OrphanCnt && !bPrevFound; j++) {
								if (pBlock[pOrphaned[j]].blockHeader.nextBlock == PrevBlock) {
									PrevBlock = pOrphaned[j];
									bPrevFound = TRUE; //end the loop
									FoundCnt++;
								}
							}
							if (!bPrevFound) {
								//last iteration was the top of the queue
								HeadFound = TRUE;
							}
						}
					}
					if (HeadFound && (FoundCnt == TmpSQDiff - 1)) {
						//Prev is top of the unlinked list
						//find the end of the queue to attach this to
						USHORT Blk = pTempStoredBlockQueue->Head;
						for (USHORT i = 1; i < TmpSQCnt; i++) {
							if (pBlock[Blk].blockHeader.nextBlock != QMC_INVALID_BLOCK_NUMBER)
								Blk = pBlock[Blk].blockHeader.nextBlock;
						}

						//link PrevBlock in to Blk where it belongs
						pBlock[Blk].blockHeader.nextBlock = PrevBlock;
						bRecovered = TRUE;
					}
				}
			}

			usTailInd = 0;
			if (TDQDiff) {
				//is the reported tail in the orphan list
				BOOL Found = FALSE;
				for (int i = 0; i < OrphanCnt && !Found; i++) {
					if (pOrphaned[i] == pToDiskQueue->Tail) {
						Found = TRUE;
						usTailInd = i;
					}

				}
				if (Found) {
					USHORT PrevBlock = pOrphaned[usTailInd];
					BOOL HeadFound = TRUE;
					USHORT FoundCnt = 0;
					if (1 < TDQDiff) {
						HeadFound = FALSE;
						//find the start of the unlinked stretch
						//loop for each difference
						for (int k = 0; k < TDQDiff && !HeadFound; k++) {
							BOOL bPrevFound = FALSE;
							//scan the orphan block array for a block pointing to the last one
							for (int j = 0; j < OrphanCnt && !bPrevFound; j++) {
								if (pBlock[pOrphaned[j]].blockHeader.nextBlock == PrevBlock) {
									PrevBlock = pOrphaned[j];
									bPrevFound = TRUE; //end the loop
									FoundCnt++;
								}
							}
							if (!bPrevFound) {
								//last iteration was the top of the queue
								HeadFound = TRUE;
							}
						}
					}
					if (HeadFound && (FoundCnt == TDQDiff - 1)) {
						//Prev is top of the unlinked list
						//find the end of the queue to attach this to
						USHORT Blk = pToDiskQueue->Head;
						for (USHORT i = 1; i < TDQCnt; i++) {
							if (pBlock[Blk].blockHeader.nextBlock != QMC_INVALID_BLOCK_NUMBER)
								Blk = pBlock[Blk].blockHeader.nextBlock;
						}

						//link PrevBlock in to Blk where it belongs
						pBlock[Blk].blockHeader.nextBlock = PrevBlock;
						bRecovered = TRUE;
					}
				}
			}
			//and again for each of the persisted queues
			for (int PQInd = 0; PQInd < numOfQueues; PQInd++) {
				usTailInd = 0;
				if (pQDiff[PQInd]) {
					//is the reported tail in the orphan list
					BOOL Found = FALSE;
					for (int i = 0; i < OrphanCnt && !Found; i++) {
						if (pOrphaned[i] == pPersistDataBlockQueue[PQInd].Tail) {
							Found = TRUE;
							usTailInd = i;
						}

					}
					if (Found) {
						USHORT PrevBlock = pOrphaned[usTailInd];
						BOOL HeadFound = FALSE;
						USHORT FoundCnt = 0;
						if (1 < pQDiff[PQInd]) {
							//find the start of the unlinked stretch
							//loop for each difference
							for (int k = 0; k < pQDiff[PQInd] && !HeadFound; k++) {
								BOOL bPrevFound = FALSE;
								//scan the orphan block array for a block pointing to the last one
								for (int j = 0; j < OrphanCnt; j++) {
									bPrevFound = FALSE;
									if (pBlock[pOrphaned[j]].blockHeader.nextBlock == PrevBlock) {
										PrevBlock = pOrphaned[j];
										bPrevFound = TRUE; //end the loop
										FoundCnt++;
										j = OrphanCnt;
									}
								}
								if (!bPrevFound) {
									//last iteration was the top of the queue
									HeadFound = TRUE;
								}
							}
						}
						if (HeadFound && (FoundCnt == pQDiff[PQInd] - 1)) {
							//Prev is top of the unlinked list
							//find the end of the queue to attach this to
							USHORT Blk = pPersistDataBlockQueue[PQInd].Head;
							for (USHORT i = 1; i < pQCount[PQInd]; i++) {
								if (pBlock[Blk].blockHeader.nextBlock != QMC_INVALID_BLOCK_NUMBER)
									Blk = pBlock[Blk].blockHeader.nextBlock;
							}

							//link PrevBlock in to Blk where it belongs
							pBlock[Blk].blockHeader.nextBlock = PrevBlock;
							bRecovered = TRUE;
						}
					}
				}
			}
		} else if (OrphanCnt == Total)         //num of queues doing operations equals number of orphans
				{
			for (int l = 0; l < OrphanCnt; l++) {
				for (int k = 0; k < ManipCnt; k++) {
					if (manipulatingQ[k] == pBlock[pOrphaned[l]].blockHeader.QueueId) {
						switch (pPersistDataBlockQueue[manipulatingQ[k]].Status) {
						case QMC_BLKQ_STATUS_RELEASE_BLOCK:
							//on it's way to the free block queue
							//todo check progress through Sequence
							pFreeBlockQueue->NumOfBlocksInQueue++;
							pBlock[pFreeBlockQueue->Tail].blockHeader.nextBlock = pOrphaned[l];
							pFreeBlockQueue->Tail = pOrphaned[l];
							bRecovered = TRUE;
							usOrphRecoverCnt++;
							usManipRecoverCnt++;
							pOrphRecovered[l] = TRUE;
							pManipRecovered[k] = TRUE;
							break;
						case QMC_BLKQ_STATUS_ADD_NEW_BLOCK:
							if (pabQTailCorrect[manipulatingQ[k]] == FALSE) {
								if (pPersistDataBlockQueue[manipulatingQ[k]].Tail == pOrphaned[l]) {
									//got it all to do
									//find previous tail
									USHORT blockId = pPersistDataBlockQueue[manipulatingQ[k]].Head;
									for (int qInd = 1;
											qInd < pPersistDataBlockQueue[manipulatingQ[k]].NumOfBlocksInQueue;
											qInd++) {
										blockId = pBlock[blockId].blockHeader.nextBlock;
									}
									pPersistDataBlockQueue[manipulatingQ[k]].Tail = blockId;
									pBlock[blockId].blockHeader.nextBlock = QMC_END_OF_QUEUE;
								} else {
									//put the block back to force the queue to re-take a new one
									if (pBlock[pPersistDataBlockQueue[manipulatingQ[k]].Tail].blockHeader.nextBlock
											== pOrphaned[l]) {
										if (pPersistDataBlockQueue[manipulatingQ[k]].NumOfBlocksInQueue) {
											pBlock[pPersistDataBlockQueue[manipulatingQ[k]].Tail].blockHeader.nextBlock =
													QMC_END_OF_QUEUE;
										} else {
											//easy, no blocks so reset everything
											pPersistDataBlockQueue[manipulatingQ[k]].Head = QMC_END_OF_QUEUE;
											pPersistDataBlockQueue[manipulatingQ[k]].Tail = QMC_END_OF_QUEUE;
										}
									} else {
										//todo 'real' tail is way off
									}
								}
							}
							//pure orphan still easiest just to put the block back
							//next may be correct
							pBlock[pOrphaned[l]].blockHeader.nextBlock = pFreeBlockQueue->Head;
							//set the free head to our block
							pFreeBlockQueue->Head = pOrphaned[l];
							//increment the number of blocks
							pFreeBlockQueue->NumOfBlocksInQueue++;

							bRecovered = TRUE;
							usOrphRecoverCnt++;
							usManipRecoverCnt++;
							pOrphRecovered[l] = TRUE;
							pManipRecovered[k] = TRUE;
							break;
						case QMC_BLKQ_STATUS_ADD_LINK_TO_TAIL:
							//adding linked to tail doesn't include removing, so this process will
							//probably become evident with duplicate entries
						case QMC_BLKQ_STATUS_REMOVE_BLKS:
						default:
							break;
						}
					}

				}
			}
			//todo recovered count to mark orphans not dealt with...
			//un dealt with orphans are probably coming from the free block q

			//count number of queues that were getting a free block and not been dealt with
			USHORT NewBlockCnt = 0;
			for (int ManInd = 0; ManInd < ManipCnt; ManInd++) {
				if (!pManipRecovered[ManInd]
						&& pPersistDataBlockQueue[manipulatingQ[ManInd]].Status == QMC_BLKQ_STATUS_ADD_NEW_BLOCK) {
					NewBlockCnt++;
				}
			}
			if ((OrphanCnt - usOrphRecoverCnt) == NewBlockCnt) {
				//all orphan remaining blocks are from the free block queue. lets put them back
				for (int NewInd = 0; NewInd < NewBlockCnt; NewInd++) {
					for (int q = 0; q < OrphanCnt; q++) {
						if (!pOrphRecovered[q] && //test if it's next is the FBQ current head
								(pBlock[pOrphaned[q]].blockHeader.nextBlock == pFreeBlockQueue->Head)) {
							//set the free head to our block
							pFreeBlockQueue->Head = pOrphaned[q];
							//increment the number of blocks
							pFreeBlockQueue->NumOfBlocksInQueue++;
							bRecovered = TRUE;
							usOrphRecoverCnt++;
							usManipRecoverCnt++;
							pOrphRecovered[q] = TRUE;
						}
					}
				}
			}
		} else if (usAffectedCount) {
			//check the affected differences tally up with any orphans
			if (1 == usAffectedCount && pausAffectQueues[0] == FREE_QUEUE_INDEX && OrphanCnt == FreeDiff) {
				//find the reported tail
				USHORT usInd = NULL;
				USHORT blk = QMC_INVALID_BLOCK_NUMBER;
				while (usInd < OrphanCnt) {
					if (QMC_END_OF_QUEUE == pBlock[pOrphaned[usInd]].blockHeader.nextBlock
							&& QMC_INVALID_Q_ID == pBlock[pOrphaned[usInd]].blockHeader.QueueId) {
						blk = pOrphaned[usInd];
						usInd = OrphanCnt;
					}
					usInd++;
				}
				BOOL Headfound = FALSE;
				USHORT usStrandLength = 1; //length of the found orphan strand
				if (QMC_INVALID_BLOCK_NUMBER != blk) {
					//start looping to find the 'head'
					int StrCnt = 0;
					for (; StrCnt < OrphanCnt; StrCnt++) {
						BOOL bPrevFound = TRUE;
						for (int run = 0; run < OrphanCnt; run++) {
							bPrevFound = FALSE;
							if (pBlock[pOrphaned[run]].blockHeader.nextBlock == blk) {
								blk = pOrphaned[run]; //set blk for the next run
								bPrevFound = TRUE;
								usStrandLength++;
								run = OrphanCnt; //early bath
							}
						}
						if (!bPrevFound)
							Headfound = TRUE; // no luck on the last run so end it here
					}
				}
				if (Headfound && (usStrandLength == FreeDiff)) {
					//attach it back on
					USHORT blk2 = pFreeBlockQueue->Head;
					for (USHORT len = 1; len < FreeCnt; len++) {
						if (pBlock[blk2].blockHeader.nextBlock != QMC_INVALID_BLOCK_NUMBER)
							blk2 = pBlock[blk2].blockHeader.nextBlock;
					}
					//link in the strand
					pBlock[blk2].blockHeader.nextBlock = blk;
					bRecovered = TRUE;

				}
			}

		}

    csTmp = QString::asprintf("Recovery attempted = %s\r\n", (bRecovered) ? "Yes" : "No");
    pFile->Write(csTmp.toLocal8Bit().data(), csTmp.length() * 2);
		pFile->Close();
		delete pFile;

		// Delete the allocated Memory
		delete[] pOrphRecovered;
		delete[] pManipRecovered;
		if (usAffectedCount)
			delete[] pausAffectQueues;

	} // End of IF
	delete[] pQCount;
	delete[] pQDiff;
	delete[] pabQTailCorrect;
	delete[] paAffectedQueues;
	delete[] pDuplicated;
	delete[] pOrphaned;
	delete[] pBlockCoverage;

	if (bRecovered) {
		//re-check
		return TestBlockCoverage(pFreeBlockQueue, pTempStoredBlockQueue, pToDiskQueue, pPersistDataBlockQueue, pBlock,
				numOfBlocks, numOfQueues);
	} else
		return QMDI_TEST_FAILED;
}

BOOL CQMDataIntegrity::ValidateBlockId(USHORT usBlockId, const USHORT numOfBlocks) {
	BOOL bRet = FALSE;
	if (QMC_INVALID_BLOCK_NUMBER != usBlockId) {
		if (usBlockId >= QMC_ZERO && usBlockId < numOfBlocks) {
			bRet = TRUE;
		}
	}
	return bRet;
}

BOOL CQMDataIntegrity::ValidateFileId(USHORT usFileId, const USHORT numOfFiles) {
	BOOL bRet = FALSE;
	if (QMC_INVALID_FILE_NUMBER != usFileId) {
		if (usFileId >= QMC_ZERO && usFileId < numOfFiles) {
			bRet = TRUE;
		}
	}
	return bRet;
}

BOOL CQMDataIntegrity::ValidateBlkQLink(T_QMDI_BLK_Q_TYPE eBlkQType, USHORT usBlockId, const USHORT numOfBlocks,
		const T_QMC_BLOCK *const pBlock, SBlockCoverage *psBlockCoverage) {
	BOOL bRet = FALSE;

	BOOL bValidBlockId = ValidateBlockId(usBlockId, numOfBlocks);

	USHORT usNextBlk = QMC_ZERO;
	bool bLoopDetected = false;

	if ( TRUE == bValidBlockId) {
		//UpdateCoverage
		UpdateBlockCoverage(eBlkQType, usBlockId, pBlock, psBlockCoverage, bLoopDetected);

		//Get Next block to print the link
		usNextBlk = pBlock[usBlockId].blockHeader.nextBlock;
	}

	if ((FALSE == bValidBlockId) || (true == bLoopDetected)) {
#ifdef _DEBUG
    if( AfxMessageBox( L"Data Integrity Error - do you wish to perform a data reset on the next start up?",
         MB_YESNO | MB_ICONSTOP ) == IDYES )
    {
    pSYSTEM_INFO->SetStartMode( START_MODE_DATA_RESET );
    pDALGLB->UpdateSRAM();
    }
#endif
    QString sysMessage;
    sysMessage = QString::asprintf("Link Break or Loop(%d) in BlkQ %d BID %d NBID %d", bLoopDetected, eBlkQType, usBlockId,
				usNextBlk);
		LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_ERROR, sysMessage);

		bRet = FALSE;
	} else {
		bRet = TRUE;
	}

	return bRet;
}

void CQMDataIntegrity::UpdateBlockCoverage(T_QMDI_BLK_Q_TYPE eBlkQType, USHORT usBlockId,
		const T_QMC_BLOCK *const pBlock, SBlockCoverage *psBlockCoverage, bool &bLoopDetected) {
	psBlockCoverage[usBlockId].usCoverage++;

	switch (eBlkQType) {
	case QMDI_FBQ:
		psBlockCoverage[usBlockId].byFBQ++;
		if ((psBlockCoverage[usBlockId].byFBQ > 1)) {
			//Loop detected
			bLoopDetected = true;
		}
		break;
	case QMDI_TSBQ:
		psBlockCoverage[usBlockId].byTSBQ++;
		if ((psBlockCoverage[usBlockId].byTSBQ > 1)) {
			//Loop detected
			bLoopDetected = true;
		}
		break;
	case QMDI_TDQ:
		psBlockCoverage[usBlockId].byTDQ++;
		if ((psBlockCoverage[usBlockId].byTDQ > 1)) {
			//Loop detected
			bLoopDetected = true;
		}
		break;
	case QMDI_PDBQ:
		psBlockCoverage[usBlockId].byPDBQ++;
		if ((psBlockCoverage[usBlockId].byPDBQ > 1)) {
			//Loop detected
			bLoopDetected = true;
		}
		break;
	default:
		break;
	}

}
void CQMDataIntegrity::UpdateFileCoverage(T_QMDI_FILE_Q_TYPE eFileQType, USHORT usFileId,
		const T_QMC_DATAFILE_HEADER *const pFileHeader, SFileCoverage *psFileCoverage, bool &bLoopDetected) {
	psFileCoverage[usFileId].usfileCoverage++;
	switch (eFileQType) {
	case QMDI_FAQ:
		psFileCoverage[usFileId].byFAQ++;
		if ((psFileCoverage[usFileId].byFAQ > 1)) {
			//Loop detected
			bLoopDetected = true;
		}
		break;
	case QMDI_PFAQ:
		psFileCoverage[usFileId].byPFAQ++;
		if ((psFileCoverage[usFileId].byPFAQ > 1)) {
			//Loop detected
			bLoopDetected = true;
		}
		break;
	default:
		break;
	}

}

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Queue Manager
/// @n Filename:	QMMemoryBlkAccess.h
/// @n Description: Class Declaration File for the class CQMDataBlkAccess
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 6	Stability Project 1.3.1.1	7/2/2011 5:00:02 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 5	Stability Project 1.3.1.0	7/1/2011 4:27:34 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 4	V6 Firmware 1.3		9/7/2005 4:10:58 PM	Andy Kassell	Add
//		facility to split data files over a number of directories
// 3	V6 Firmware 1.2		7/22/2005 4:11:40 PM	Alistair Brugsch
//		Added Doxygen Comments
// $
//
// **************************************************************************
#ifndef _QMDATAFILEACCESS_H
#define _QMDATAFILEACCESS_H
#include "QMCommon.h"
/// Enumeration to describe whether the operation of a Member Function has been
/// completed Successfully or a Failure has occurred. 
typedef enum {
	QMDFA_OK, QMDFA_ERROR, QMDFA_FILE_NUMBER_INVALID
} T_QMDFA_RETURN_VALUE;
//**Class*********************************************************************
///
/// @brief Inline Class for set and reading the Data File Headers
/// 
/// The Class provides Set and Get Methods for reading an individual Data File
/// Header stored within Memory. The Member Functions have been implemented 
/// inline for speed and efficiency. 
///
//****************************************************************************
class CQMDataFileAccess {
public:
	/// Constructor 
	CQMDataFileAccess(T_QMC_DATAFILE_HEADER *const pFirstDataFile, const USHORT maxNumOfFiles);
	/// Destructor
	virtual ~CQMDataFileAccess(void);
	/// Set the File Status
	void SetFileStatus(const USHORT fileNumber, const USHORT status);
	/// Set the Queue Identification Number
	void SetQueueId(const USHORT fileNumber, const USHORT queueId);
	/// Set the File Mode
	void SetFileMode(const USHORT fileNumber, const USHORT fileMode);
	/// Set the Previous File 
	void SetPreviousFile(const USHORT fileNumber, const USHORT previousFileNumber);
	/// Set the Next File
	void SetNextFile(const USHORT fileNumber, const USHORT nextFileNumber);
	void SetNumOfBlocks(const USHORT fileNumber, const USHORT numOfBlocks) {
		m_pDataFile[fileNumber].numOfDataBlocks = numOfBlocks;
	}
	/// Increment the Number of Data Blocks within the File
	void IncNumOfDataBlocks(const USHORT fileNumber);
	/// Set the Oldest Block Number within the File
	void SetOldestBlockNumber(const USHORT fileNumber, const USHORT oldestBlockNumber);
	/// Set the Newest Block Number within the File
	void SetNewestBlockNumber(const USHORT fileNumber, const USHORT newestBlockNumber);
	/// Increment the Oldest Block Number by One Block
	void IncOldestBlockNumber(const USHORT fileNumber);
	/// Increment the Latest Block Number by One Block
	void IncLatestBlockNumber(const USHORT fileNumber);
	/// Get the File Identification Number
	USHORT GetFileId(const USHORT fileNumber) const;
	/// Get the Status of the File
	USHORT GetFileStatus(const USHORT fileNumber) const;
	/// Get the Queue Identification Number assoicated with the File
	USHORT GetQueueId(const USHORT fileNumber) const;
	/// Get the Mode of the File
	USHORT GetFileMode(const USHORT fileNumber) const;
	/// Get the Previous File Number
	USHORT GetPreviousFile(const USHORT fileNumber) const;
	/// Get the Next File Number
	USHORT GetNextFile(const USHORT fileNumber) const;
	/// Get the Oldest Block Number within the File
	USHORT GetOldestBlockNumber(const USHORT fileNumber) const;
	/// Get the Newest Block Number within the File
	USHORT GetNewestBlockNumber(const USHORT fileNumber) const;
	/// Get the Number of Data Blocks within the File
	USHORT GetNumOfDataBlocks(const USHORT fileNumber) const;
	USHORT GetMaxNumOfFiles(void) const;
	/// Get a Specific Block 
	T_QMC_DATAFILE_HEADER* const GetFileHeader(const USHORT fileNumber);
	/// Validate the Block Number
	T_QMDFA_RETURN_VALUE ValidateFileNumber(const USHORT fileNumber) const;
	static void CompleteDataFilePath(QString pFileAndPathToComplete, int pFileAndPathToCompleteBuffSize, USHORT fileID);
	static void CompleteDataFileName(QString pFileAndPathToComplete, int pFileAndPathToCompleteBuffSize, USHORT fileID);
private: // Member Functions 
private: // Member Variables
	const USHORT m_MaxNumOfFiles;	///< Max Number of Blocks Available
	/// Pointer to the First Data File Header, this pointer will be used with an
	/// array subscript to access the available Data Files in memory. 
	T_QMC_DATAFILE_HEADER *const m_pDataFile;
};
// End of Class Declaration
/// Set the File Status
inline void CQMDataFileAccess::SetFileStatus(const USHORT fileNumber, const USHORT status) {
	m_pDataFile[fileNumber].fileStatus = status;
} // End of Member Function 
/// Set the Queue Identification Number
inline void CQMDataFileAccess::SetQueueId(const USHORT fileNumber, const USHORT queueId) {
	m_pDataFile[fileNumber].queueId = queueId;
} // End of Member Function 
/// Set the File Mode
inline void CQMDataFileAccess::SetFileMode(const USHORT fileNumber, const USHORT fileMode) {
	m_pDataFile[fileNumber].fileMode = fileMode;
} // End of Member Function 
/// Set the Previous File 
inline void CQMDataFileAccess::SetPreviousFile(const USHORT fileNumber, const USHORT previousFileNumber) {
	m_pDataFile[fileNumber].previousFile = previousFileNumber;
} // End of Member Function 
/// Set the Next File
inline void CQMDataFileAccess::SetNextFile(const USHORT fileNumber, const USHORT nextFileNumber) {
	m_pDataFile[fileNumber].nextFile = nextFileNumber;
} // End of Member Function 
/// Set the Oldest Block Number within the File
inline void CQMDataFileAccess::SetOldestBlockNumber(const USHORT fileNumber, const USHORT oldestBlockNumber) {
	m_pDataFile[fileNumber].oldestBlockNumber = oldestBlockNumber;
} // End of Member Function 
/// Set the Newest Block Number within the File
inline void CQMDataFileAccess::SetNewestBlockNumber(const USHORT fileNumber, const USHORT newestBlockNumber) {
	m_pDataFile[fileNumber].newestBlockNumber = newestBlockNumber;
} // End of Member Function 
/// Increment the Oldest Block Number by One Block
inline void CQMDataFileAccess::IncOldestBlockNumber(const USHORT fileNumber) {
	++m_pDataFile[fileNumber].oldestBlockNumber;
} // End of Member Function 
/// Increment the Latest Block Number by One Block
inline void CQMDataFileAccess::IncLatestBlockNumber(const USHORT fileNumber) {
	++m_pDataFile[fileNumber].newestBlockNumber;
} // End of Member Function 
/// Increment the Number of Data Blocks within the File
inline void CQMDataFileAccess::IncNumOfDataBlocks(const USHORT fileNumber) {
	++m_pDataFile[fileNumber].numOfDataBlocks;
} // End of Member Function 
/// Get the File Identification Number
inline USHORT CQMDataFileAccess::GetFileId(const USHORT fileNumber) const {
	return (m_pDataFile[fileNumber].fileId);
} // End of Member Function 
/// Get the Status of the File
inline USHORT CQMDataFileAccess::GetFileStatus(const USHORT fileNumber) const {
	return (m_pDataFile[fileNumber].fileId);
} // End of Member Function 
/// Get the Queue Identification Number assoicated with the File
inline USHORT CQMDataFileAccess::GetQueueId(const USHORT fileNumber) const {
	return (m_pDataFile[fileNumber].queueId);
} // End of Member Function 
/// Get the Mode of the File
inline USHORT CQMDataFileAccess::GetFileMode(const USHORT fileNumber) const {
	return (m_pDataFile[fileNumber].fileMode);
} // End of Member Function 
/// Get the Previous File Number
inline USHORT CQMDataFileAccess::GetPreviousFile(const USHORT fileNumber) const {
	return (m_pDataFile[fileNumber].previousFile);
} // End of Member Function 
/// Get the Next File Number
inline USHORT CQMDataFileAccess::GetNextFile(const USHORT fileNumber) const {
	return (m_pDataFile[fileNumber].nextFile);
} // End of Member Function 
/// Get the Oldest Block Number within the File
inline USHORT CQMDataFileAccess::GetOldestBlockNumber(const USHORT fileNumber) const {
	return (m_pDataFile[fileNumber].oldestBlockNumber);
} // End of Member Function 
/// Get the Newest Block Number within the File
inline USHORT CQMDataFileAccess::GetNewestBlockNumber(const USHORT fileNumber) const {
	return (m_pDataFile[fileNumber].newestBlockNumber);
} // End of Member Function 
/// Get the Number of Data Blocks within the File
inline USHORT CQMDataFileAccess::GetNumOfDataBlocks(const USHORT fileNumber) const {
	return (m_pDataFile[fileNumber].numOfDataBlocks);
} // End of Member Function 
inline USHORT CQMDataFileAccess::GetMaxNumOfFiles(void) const {
	return (m_MaxNumOfFiles);
} // End of Member Function 
#endif // _QMDATAFILEACCESS_H

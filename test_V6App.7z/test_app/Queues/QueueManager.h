/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Queue Manager
/// @n Filename:	QueueManager.h
/// @n Description: Class Declaration for the Queue Manager. 
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 10	Stability Project 1.7.1.1	7/2/2011 5:00:06 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 9	Stability Project 1.7.1.0	7/1/2011 4:27:37 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 8	V6 Firmware 1.7		9/14/2006 3:55:35 PM	Alistair Brugsch
//		added in functionality to allow clearing of data from chart queues
// 7	V6 Firmware 1.6		4/13/2006 4:57:29 PM	Andy Kassell	Use
//		compile time switch for Q integrity checks
// $
//
// **************************************************************************
#ifndef _QUEUEMANAGER_H
#define _QUEUEMANAGER_H
#include "QMMemoryManager.h"
#include "QMBlockServices.h"
#include "QMDiskServices.h"
#include "QMDiskServicesThread.h"
#include <QThread>
#include <QMutex>
#include "PassiveModule.h" 
const USHORT QUEMAN_ZERO = 0; ///< Constant to Represent the value of Zero
#define INCLUDE_Q_INTEGRITY_CHECK	0		///< Set to 1 to include Q integrity on every allocate or deallocate of a block
/// Enumeration for Member function Return Values to indicate success and failure conditions
typedef enum _eQueueManagerReturnValue {
	QUEMAN_OK, QUEMAN_INITIALISATION_FAILED
} T_QUEMAN_RETURN_VALUE;
//**Class*********************************************************************
///
/// @brief Provides user access to the Queue Manager Services
/// 
/// This class is a singleton and will be used for gaining access to the 
/// Queue Manager Services. The Queue Manager provides users with blocks of
/// memory that they can fill, once these blocks of memory are completed they
/// are written to disk. The Queue Manager is capable of maintaining the Blocks
/// of Data over a power failure. The Queue Manager is only capable of maintaining
/// data block where the supplied pointer is to SRAM, or DRAM that is saved to disk and
/// reloaded again.		
///
//****************************************************************************
class CQueueManager: public CPassiveModule {
public:
	/// On First Call creates the Class Instance, otherwise returns a Pointer to the Class Instance
	static CQueueManager* GetHandle();
	/// Initialise the Message List Service for Operation
	T_QUEMAN_RETURN_VALUE Initialise(T_QMC_INITIALISATION_TYPE initType, BYTE *const pBasePointer,
			const T_QMC_SYSTEM_INFO &systemInfo);
	/// Perform a Controlled Shutdown of the Queue Manager
	T_QUEMAN_RETURN_VALUE Shutdown(void);
	/// Obtain Access to the Block Services
	CQMBlockServices& GetBlockServices(void) {
		return (*m_pBlockServices);
	}
	/// Obtain Access to the Disk Services
	CQMDiskServices& GetDiskServices(void) {
		return (*m_pDiskServices);
	}
	/// Cleanup the Singleton
	T_QUEMAN_RETURN_VALUE CleanUp(void);
	// Accessor methods
	const bool IsInitialised() const {
		return m_bInitialised;
	}
	///Perform data integrity on the block queues
	T_QMMEMMAN_RETURN_VALUE BlockQueueIntegCheck(void);
	/// Clear all data for chart queues except current working blocks
	T_QMMEMMAN_RETURN_VALUE ClearChartBlocks();
	void BackupSRAMFileQueues();
	void RestoreSRAMFileQueues();
	BOOL ValidateFileId(USHORT usFileId);
	BOOL ValidateBlockId(USHORT usBlockId);
private: // -- Member Functions -- //	
	/// Constructor
	CQueueManager(void);
	/// Destructor
	virtual ~CQueueManager(void);
	/// Copy Constructor
	CQueueManager(const CQueueManager&);
	/// Equals Operator
	CQueueManager& operator=(const CQueueManager&) {
		return *this;
	}
	;
private: // -- Member Variables -- //
	static CQueueManager *m_pInstance; ///< Pointer to the Created Instance;		
	static QMutex m_CreationMutex; ///< Mutex to ensure Creation is carried out once
	CQMHardwareManager m_QMHardwareLayer; ///< Queue Mananger Hardware Layer 
	CQMBlockServices *m_pBlockServices;	///< Pointer to the Block Services
	CQMDiskServices *m_pDiskServices;	///< Pointer to the Disk Services
	QThread *m_pThread;				///< Pointer to the Disk Service Thread
	/// Flag indicating of the queue manager has been intialiased yet
	bool m_bInitialised;
};
// End of Class Declaration 
#endif // _QUEUEMANAGER_H

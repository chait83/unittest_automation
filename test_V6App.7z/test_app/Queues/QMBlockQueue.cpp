/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  Queue Manager
/// @n Filename:  QMBlockQueue.cpp
/// @n Description: Class Implementation File for the class CQMBlockQueue
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  12  Stability Project 1.7.1.3 7/2/2011 5:00:01 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  11  Stability Project 1.7.1.2 7/1/2011 4:38:43 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  10  Stability Project 1.7.1.1 3/17/2011 3:20:37 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  9 Stability Project 1.7.1.0 2/15/2011 3:03:45 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// **************************************************************************
#include "QMBlockQueue.h"
#include "QMMemoryBlkAccess.h"
#include "QMBlkQHeaderAccess.h"
#include "V6globals.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
//****************************************************************************
/// Constructor
///
/// @param[in] 	blockQueue  - Reference to the Block Queue Access Class 
/// @param[in] memoryBlockAccess - Reference to the Memory Block Access Class
///
/// @return No Return Value
/// 
//****************************************************************************
CQMBlockQueue::CQMBlockQueue(class CQMBlkQAccess &blockQueue, class CQMDataBlkAccess &memoryBlockAccess) : m_BlockQueue(
		blockQueue), m_MemoryBlockAccess(memoryBlockAccess) {
	// Initialise the Critical Section for Operation  
	QMutex * m_csBlockQueue;
} // End of Constructor
//****************************************************************************
/// Destructor
//****************************************************************************
CQMBlockQueue::~CQMBlockQueue(void) {
	// Cleanup the Critical Section
	//deletion of mutex not required
} // End of Destructor
//****************************************************************************
/// Add a Memory Block to the End( Tail ) of the Queue, taking into account that
/// the queue may be empty. 
///
/// @param[in] 	  blockNumber - Block Number to Add to the End of the Queue
///
/// @return QMBQ_OK - Block Added Successfully
/// 
//****************************************************************************
T_QMBQ_RETURN_VALUE CQMBlockQueue::AddBlockToTail(const USHORT blockNumber) {
	T_QMBQ_RETURN_VALUE retValue = QMBQ_OK; // Member Function Return Value 
	if (QMMBA_OK != m_MemoryBlockAccess.ValidateBlockNumber(blockNumber)) {
		QString strError("");
		strError = QString::asprintf("AddBlockToTail - Invalid block number (%u)", blockNumber);
    V6CriticalMessageBox(NULL, strError, "CQMBlockQueue Error", MB_OK );
	}
	m_csBlockQueue.lock();
	if (QMBQ_STATUS_EMPTY == GetQueueStatus()) {
		// -- Add a Block to an Empty Queue -- //
		// Set the Head and Tail to point to the new block
		m_BlockQueue.SetHead(blockNumber);
		m_BlockQueue.SetTail(blockNumber);
		// Set the Next block of the new block to indicate the end of the queue
		m_MemoryBlockAccess.SetNextBlock(blockNumber, QMC_END_OF_QUEUE);
	} else {
		// -- Add a Block to a Queue that already contains Data Blocks -- //
		// Set the Next Block of the Tail to the new block
		m_MemoryBlockAccess.SetNextBlock(m_BlockQueue.GetTail(), blockNumber);
		// Set the Next block of the new block to indicate the end of the queue
		m_MemoryBlockAccess.SetNextBlock(blockNumber, QMC_END_OF_QUEUE);
		// Set the Tail to point to the new pointer.
		m_BlockQueue.SetTail(blockNumber);
	} // End of IF
	m_BlockQueue.IncrementNumOfBlocks();
	m_csBlockQueue.lock();
	return (retValue);
} // End of Member Function
//****************************************************************************
/// Obtain a Pointer to the Current( Head ) Available Block in the Queue
///
/// @param[in] - NONE
///
/// @return T_QMC_BLOCK - Pointer to the Head Block
/// NULL  - No Head Block Available
///
//****************************************************************************
T_QMC_BLOCK* const CQMBlockQueue::GetHeadBlock(void) {
	T_QMC_BLOCK *pHeadBlock = NULL; // Pointer to the Head Pointer if available
	if (QMBQ_STATUS_EMPTY != GetQueueStatus()) {
		pHeadBlock = m_MemoryBlockAccess.GetBlock(m_BlockQueue.GetHead());
	} // End of IF
	return (pHeadBlock);
} // End of Member Function 
/// Obtain the Status of the Block Queue
//****************************************************************************
/// Obtain whether the Block Queue is EMPTY, FULL or SPACE AVAILABLE.
///
/// @param[in] - None
///
/// @return QMBQ_STATUS_EMPTY  - Block Queue is Empty 
/// QMBQ_STATUS_FULL  - Block Queue is Full
/// QMBQ_STATUS_SPACE_AVAILABLE - Block Queue has space available
///
//****************************************************************************
T_QMBQ_QUEUE_STATUS CQMBlockQueue::GetQueueStatus(void) {
	T_QMBQ_QUEUE_STATUS retValue = QMBQ_STATUS_EMPTY;
	m_csBlockQueue.lock();
	if (QMC_START_OF_QUEUE != m_BlockQueue.GetHead() && QMC_END_OF_QUEUE != m_BlockQueue.GetTail()) {
		// Determine the status of the number of blocks within the queue
		if (m_BlockQueue.GetNumOfBlocksInQueue() == m_MemoryBlockAccess.GetMaxNumOfBlocks()) {
			retValue = QMBQ_STATUS_FULL;
		} else {
			retValue = QMBQ_STATUS_SPACE_AVAILABLE;
		} // End of IF
	} // End of IF
	m_csBlockQueue.lock();
	return (retValue);
} // End of Member Function
//****************************************************************************
/// Remove the Current( Head ) Available Block from the Queue, ensure the head
/// and tail of the Queue are set correctly. If the Queue becomes Empty on this
/// call the Head and Tail will indicate this by a known default value. 
/// NOTE: Do not modify the content of Head block
/// @param[in] - None
///
/// @return QMBQ_OK - Head Block Removed Successfully
/// QMBQ_NO_BLOCKS_TO_REMOVE - No Blocks within the Queue to Remove
/// 
//****************************************************************************
T_QMBQ_RETURN_VALUE CQMBlockQueue::RemoveHeadBlockNoModify(void) {
	T_QMBQ_RETURN_VALUE retValue = QMBQ_NO_BLOCKS_TO_REMOVE;
	m_csBlockQueue.lock();
	if (QMBQ_STATUS_EMPTY != GetQueueStatus()) {
		USHORT thisBlock = m_BlockQueue.GetHead();
		// Obtain the Block Id of the next block if available
		USHORT nextBlock = m_MemoryBlockAccess.GetNextBlock(m_BlockQueue.GetHead());
		// Set the Head and Tail accordingly
		if (QMC_END_OF_QUEUE == nextBlock) {
			m_BlockQueue.SetHead(QMC_START_OF_QUEUE);
			m_BlockQueue.SetTail(QMC_END_OF_QUEUE);
		} else {
			m_BlockQueue.SetHead(nextBlock);
		} // End of IF
		m_BlockQueue.DecrementNumOfBlocks();
		retValue = QMBQ_OK;
	} // End of IF
	m_csBlockQueue.lock();
	return (retValue);
} // End of Member Function
//****************************************************************************
/// Remove the Current( Head ) Available Block from the Queue, ensure the head
/// and tail of the Queue are set correctly. If the Queue becomes Empty on this
/// call the Head and Tail will indicate this by a known default value. 
///
/// @param[in] - None
///
/// @return QMBQ_OK - Head Block Removed Successfully
/// QMBQ_NO_BLOCKS_TO_REMOVE - No Blocks within the Queue to Remove
/// 
//****************************************************************************
T_QMBQ_RETURN_VALUE CQMBlockQueue::RemoveHeadBlock(void) {
	T_QMBQ_RETURN_VALUE retValue = QMBQ_NO_BLOCKS_TO_REMOVE;
	m_csBlockQueue.lock();
	if (QMBQ_STATUS_EMPTY != GetQueueStatus()) {
		USHORT thisBlock = m_BlockQueue.GetHead();
		// Obtain the Block Id of the next block if available
		USHORT nextBlock = m_MemoryBlockAccess.GetNextBlock(m_BlockQueue.GetHead());
		// Set the Head and Tail accordingly
		if (QMC_END_OF_QUEUE == nextBlock) {
			m_BlockQueue.SetHead(QMC_START_OF_QUEUE);
			m_BlockQueue.SetTail(QMC_END_OF_QUEUE);
		} else {
			m_BlockQueue.SetHead(nextBlock);
		} // End of IF
		m_BlockQueue.DecrementNumOfBlocks();
		//mark the block to something out of range. arbitrary magic number for now
		//so if in a data recovery situation, any blocks with this number automatically
		//go back in
		m_MemoryBlockAccess.SetQueueId(thisBlock, QMC_INVALID_Q_ID);
		retValue = QMBQ_OK;
	} // End of IF
	m_csBlockQueue.lock();
	return (retValue);
} // End of Member Function
/// Add Linked Blocks to the Queue
//****************************************************************************
/// This member function will add a linked set of blocks to the end of the Queue.
/// This functionality has been provided for efficiency, as adding the blocks
/// individually would require the block headers to be added, using this method
/// only the first and last block need to be updated to continue the queue. 
///
/// @param[in] startBlockNumber - First Block Id of the linked set of blocks
/// @param[in] endBlockNumber  - Last Block Id of the linked set of blocks
/// @param[in] numOfBlocks - Number of Blocks in the Linked set
///
/// @return QMBQ_OK - Linked Blocks Added to the End of the Queue
/// 
//****************************************************************************
T_QMBQ_RETURN_VALUE CQMBlockQueue::AddLinkedBlocksToTail(const USHORT startBlockNumber, const USHORT endBlockNumber,
		const USHORT numOfBlocks) {
	T_QMMBA_RETURN_VALUE eValidBlock = m_MemoryBlockAccess.ValidateBlockNumber(startBlockNumber);
	if (QMMBA_OK != eValidBlock) {
		QString strError("");
		strError = QString::asprintf("CQMBlockQueue::AddLinkedBlocksToTail - Start Block invalid, s:%u e:%u n:%u",
				startBlockNumber, endBlockNumber, numOfBlocks);
		FreeBlockQueueError(strError);
	} else {
		eValidBlock = m_MemoryBlockAccess.ValidateBlockNumber(endBlockNumber);
		if (QMMBA_OK != eValidBlock) {
			QString strError("");
			strError = QString::asprintf("CQMBlockQueue::AddLinkedBlocksToTail - End Block invalid, s:%u e:%u n:%u",
					startBlockNumber, endBlockNumber, numOfBlocks);
			FreeBlockQueueError(strError);
		}
	}
	T_QMBQ_RETURN_VALUE retValue = QMBQ_OK;
	if (QMMBA_OK == eValidBlock) {
		m_csBlockQueue.lock();
		if (QMBQ_STATUS_EMPTY == GetQueueStatus()) {
			m_BlockQueue.SetHead(startBlockNumber);
			m_BlockQueue.SetTail(endBlockNumber);
		} else {
			m_MemoryBlockAccess.SetNextBlock(m_BlockQueue.GetTail(), startBlockNumber);
			m_BlockQueue.SetTail(endBlockNumber);
		} // End of IF
		m_MemoryBlockAccess.SetNextBlock(m_BlockQueue.GetTail(), QMC_END_OF_QUEUE);
		m_BlockQueue.IncrementNumOfBlocks(numOfBlocks);
		m_csBlockQueue.lock();
	} else {
		retValue = QMBQ_ERROR;
	}
	return (retValue);
} // End of Member Function 
//****************************************************************************
/// Provides a method of tracing the Queue to the Trace Window when debugging. 
/// The trace displays all the blocks within the Queue, starting from the Head.  
///
/// @param[in] pName - Name of the Queue to be Traced. 
///
/// @return No Return Value
/// 
//****************************************************************************
void CQMBlockQueue::TraceQueue(const QString pName) {
	const T_QMC_BLOCK *const pHeadBlock = GetHeadBlock();
  qDebug("\nName: %s\n", pName.toLocal8Bit().data());
	if (QMBQ_STATUS_EMPTY == GetQueueStatus()) {
		qDebug("BLOCK QUEUE EMPTY\n");
	} else {
		USHORT item = pHeadBlock->blockHeader.blockId;
		qDebug("HEAD =");
		for (USHORT pos = 0; pos < m_BlockQueue.GetNumOfBlocksInQueue(); pos++) {
			qDebug(" [%d] ", item);
			item = m_MemoryBlockAccess.GetNextBlock(item);
		} // End of FOR
		qDebug("= TAIL -> 0x%X (NoOfBlocks: %d)\n\n", item, m_BlockQueue.GetNumOfBlocksInQueue());
	} // End of IF
} // End of Member Function

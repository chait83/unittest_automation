/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	Queues
/// @n Filename: ChartQueues.h
/// @n Description: Queues for charts 
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 46	Stability Project 1.43.1.1	7/2/2011 4:56:04 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 45	Stability Project 1.43.1.0	7/1/2011 4:26:02 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 44	V6 Firmware 1.43		9/14/2010 11:51:35 AM Vivek (HAIL) 
//		Revert Code merge For Replay at faster speed
// 43	V6 Firmware 1.42		9/10/2010 5:55:47 PM	Vivek (HAIL) 
//		Code meryge for Replay at fast speed
// $
//
// **************************************************************************
#ifndef _CHARTQs_H
#include "Defines.h"
#include "MessageListServicesItem.h"
#include "BasicMaxMinAve.h"
#include "InternalMessage.h"
#include "QMUserRequestServices.h"
#include "QMDataBlock.h"
#define _CHARTQs_H
#define END_OF_TIME			549755813888L //2^39 174 years from 'born on' date	
#define BEGINNING_OF_TIME	-549755813888L //-2^39
#define MESSAGE_STRIP_DEPTH 13
#define NUM_STRIP_RATES				18
#define NUM_SEL_FAST_STRIP_SPEEDS	6
#define NUM_SEL_MED_STRIP_SPEEDS	5
#define NUM_SEL_SLOW_STRIP_SPEEDS	4
#define NUM_CIRC_RATES				12
#define NUM_SEL_FAST_CIRC_SPEEDS	5
#define NUM_SEL_MED_CIRC_SPEEDS		5
#define NUM_SEL_SLOW_CIRC_SPEEDS	5
enum ChartSpeed {
	SPEED_FAST = 0, SPEED_MEDIUM, SPEED_SLOW,
	NUM_CHART_SPEEDS,
};
const UINT CirciTrendSelectableFastSpeeds[NUM_SEL_FAST_CIRC_SPEEDS] = { 50, 100, 200, 800, 1600 };
const UINT CirciTrendSelectableMedSpeeds[NUM_SEL_MED_CIRC_SPEEDS] = { 800, 1600, 2400, 4800, 9600 };
const UINT CirciTrendSelectableSlowSpeeds[NUM_SEL_SLOW_CIRC_SPEEDS] = { 9600, 24000, 33600, 67200, 134400 };
/*
 #define RESET_PWRFAIL	0x01	// Recovery after a power fail
 #define SETUP_CHANGED	0x02	// Existing set-up changed by user
 #define CONTINUATION	0x05	// Continuation block
 */
// set 4 byte alignment here
#pragma pack(push, prevpack, 4)
struct ChartRecHdr {
	BYTE numReadings;
	BYTE unused :3;
	BYTE rateIndex :5;
	BYTE penNo;
	char startTimeH;
	UINT startTimeL;
};
struct ChartReading {
	float maxv;
	float minv;
};
#define MAX_REC_READINGS 63
struct ChartRec {
	ChartRecHdr hdr;
	ChartReading readings[MAX_REC_READINGS];
};
struct MessageHolder {
	T_MSGLISTSER_MESSAGE message;
	MessageHolder *pNext;
};
// 512 byte block holds up to 3 messages
struct MessageRec {
	BYTE NumMessages;
	BYTE spare[3];
	T_MSGLISTSER_MESSAGE message[MAX_NO_OF_MESSAGES_PER_BLOCK];
	BYTE spare2[4];
};
// Put back the original packing from the stack				
#pragma pack(pop, prevpack)
enum CHARTRET {
	DATA_OK = 0, NO_MORE_DATA = 1, END_OF_BLOCK = 2
};
/*
 class CFastMutex
 {
 long m_locker;
 long m_locker2;
 long m_lastLockedby;
 long m_nextLockedby;
 public:
 CFastMutex() : m_locker(0), m_locker2(0), m_lastLockedby(0), m_nextLockedby(0) {} 
 void Lock(){InterlockedIncrement(&m_locker); }		
 BOOL TryLock()
 {
 // check if another thread already locked
 if(InterlockedIncrement(&m_locker) !=1)
 {
 InterlockedDecrement(&m_locker);
 return FALSE;
 }
 else
 return TRUE;
 }

 void WaitLock(int who)
 {
 //		if(m_lastLockedby==who)
 //		{
 //			// this is the one that got it last time - so allow others in if poss
 //			sleep(5);
 //		}
 int blockcount=0;
 do
 {
 // check if another thread already locked
 while(InterlockedIncrement(&m_locker) !=1)
 {
 if(!m_locker2)
 if(InterlockedIncrement(&m_locker2)==1)
 {
 // it's locked, but we will get it next
 m_nextLockedby=who;
 }
 InterlockedDecrement(&m_locker);
 
 if(who==1)	
 qDebug("chart blocked %d\n",++blockcount);
 else 
 if(who==2)	;
 //	qDebug("DP blocked %d\n",++blockcount);
 else
 if(who==3)	
 qDebug("update blocked %d\n",++blockcount);
 else
 qDebug("?? blocked %d\n",++blockcount);
 sleep(0);
 }
 
 // here it is locked, are we meant to get it?
 
 if(m_locker2) // anyone else trying?
 {
 if(m_nextLockedby!=who)
 {
 // no, we are not the next to get it!
 InterlockedDecrement(&m_locker); // so unlock it here
 sleep(0); // and let another get it!
 }
 else
 {
 // yes we are to get it!
 m_locker2=0; // allow someone else to be next
 if(m_lastLockedby==who)
 qDebug("LOCKED TWICE %d\n",who);
 m_lastLockedby=who;
 return;
 }
 }
 else
 {
 m_lastLockedby=who;
 return;
 }
 }while(1);
 
 }

 void WaitLock2(int who)
 {
 // check if another thread already locked
 while(InterlockedIncrement(&m_locker) !=1)
 {
 InterlockedDecrement(&m_locker);		
 sleep(0);
 }
 
 }

 void Unlock() { InterlockedDecrement(&m_locker); }
 };
 */
// forward refs...
class CChartQ;
class CChartBlock;
class CChartMessageQ;
typedef enum {
	CQT_STRIP, CQT_CIRCULAR,
	CQT_NO_OF_QUEUE_TYPES
} CHART_QUEUE_TYPES;
class CChartQManager {
private:
	static CChartQManager *m_pChartQManager; ///< static pointer to single instance of class
	long m_mutex;
	static QMutex m_critsec;
	// CR-3132 - Declare one more critical section object for AddMessage function.
	static QMutex m_critsecMsg;
	CChartQ *m_QarrayVolatile[CQT_NO_OF_QUEUE_TYPES][V6_MAX_PENS][NUM_CHART_SPEEDS]; /// a pointer to every list created will be held here.
	CChartQ *m_QarraySRAM[CQT_NO_OF_QUEUE_TYPES][V6_MAX_PENS][NUM_CHART_SPEEDS]; /// a pointer to every list created will be held here.
	int m_TotalBlocks;
	BOOL m_ChartsPaused[PEN_GROUP_MAX];
	BOOL m_ChartsStopped;
	BOOL m_ChartsRestart;
	BOOL m_ChartsConfigChange;
	LONGLONG m_PausedTime[PEN_GROUP_MAX];
	LONGLONG m_StoppedTime;
	/// Array for storing the strip speed types
	static UINT ms_uiChartSpeeds[CQT_NO_OF_QUEUE_TYPES][NUM_CHART_SPEEDS];
	/// Array for storing the reply chart speeds
	static UINT ms_uiReplayChartSpeeds[NUM_CHART_SPEEDS]; // CR: 3151 Replay at Faster speed
	BOOL m_Initialised_services;
	void Initialise();
	// private construction / destruction
	CChartQManager();
	~CChartQManager();
	CChartQManager(const CChartQManager&);
	CChartQManager& operator=(const CChartQManager&) {
		return *this;
	}
	CChartQ* AddChartQ(int PenZeroBased, ChartSpeed fastmedslow, CHART_QUEUE_TYPES chartQueueType, BOOL IsSRAM);
	CChartQ* GetChartQ(int PenZeroBased, ChartSpeed fastmedslow, CHART_QUEUE_TYPES chartQueueType, BOOL IsSRAM);
	void DeleteChartQ(int PenZeroBased, ChartSpeed fastmedslow, CHART_QUEUE_TYPES chartQueueType, BOOL IsSRAM);
public:
	//Singleton 
	static CChartQManager* GetHandle(); // acquire a copy of the pointer to the single instance
	void CleanUp();
	BOOL m_HasNewData;		// variables for replay mode
	BOOL m_HasNewMessages;
	LONGLONG m_Earliest;
	LONGLONG m_Latest;
	LONGLONG m_midtime;
	CChartMessageQ *m_ChartMessageQ;
	CInternalMessageQueue *m_pIntMessQ;
	/// Array for storing the oldest time for each speed
	LARGE_INTEGER m_OldestDataTime[CQT_NO_OF_QUEUE_TYPES][NUM_CHART_SPEEDS];
	BOOL m_OldestDataFlag[CQT_NO_OF_QUEUE_TYPES][NUM_CHART_SPEEDS];
	static USHORT GetChartQRecHdrSize() {
		return sizeof(ChartRecHdr);
	}
	static LONGLONG GetChartQRecTime(BYTE *phdr) {
		LARGE_INTEGER large;
		large.HighPart = ((ChartRecHdr*) phdr)->startTimeH;
		large.LowPart = ((ChartRecHdr*) phdr)->startTimeL;
		return large.QuadPart;
	}
	CChartQ* AddStripChartQ(int PenZeroBased, ChartSpeed fastmedslow, BOOL IsSRAM = FALSE);
	CChartQ* GetStripChartQ(int PenZeroBased, ChartSpeed fastmedslow, BOOL IsSRAM = FALSE);
	void DeleteStripChartQ(int PenZeroBased, ChartSpeed fastmedslow, BOOL IsSRAM = FALSE);
	CChartQ* AddCircularChartQ(int PenZeroBased, ChartSpeed fastmedslow, BOOL IsSRAM = FALSE);
	CChartQ* GetCircularChartQ(int PenZeroBased, ChartSpeed fastmedslow, BOOL IsSRAM = FALSE);
	void DeleteCircularChartQ(int PenZeroBased, ChartSpeed fastmedslow, BOOL IsSRAM = FALSE);
	void AddReading(int PenZeroBased, float value);
	void AddMessage(T_MSGLISTSER_MESSAGE *msg);
	void DataUpdate(const CInternalMessage *message);
	void SetNormalMode();
	void EmptyQueues(BOOL prefillRequired = FALSE);
	void PrefillQueues();
	void Restart();
	void PauseCharts(const USHORT usGROUP_NO);
	//commented by nilesh for Displaying Chart Start/Stop Messages
	//void StopCharts();
	//added by nilesh for Displaying Chart Start/Stop Messages
	//[
	void StopCharts(BOOL Show = TRUE);
	//]
	void ResumeCharts(const USHORT usGROUP_NO);
	void ReadyCharts();
	//commented by nilesh for Displaying Chart Start/Stop Messages
	//void DoneCharts();
	//added by nilesh for Displaying Chart Start/Stop Messages
	//[
	void DoneCharts(BOOL Show = TRUE);
	//]
	BOOL IsChartsPaused(USHORT GroupNumber) {
		return m_ChartsPaused[GroupNumber];
	}
	;
	BOOL IsChartsStopped() {
		return m_ChartsStopped;
	}
	;
	BOOL IsReconCharts() {
		return m_ChartsConfigChange;
	}
	;
	LONGLONG GetPausedTime(USHORT GroupNumber) {
		return m_PausedTime[GroupNumber];
	}
	;
	LONGLONG GetStoppedTime() {
		return m_StoppedTime;
	}
	;
	void GetOldestTimes(LONGLONG *oldestFast, LONGLONG *oldestMedium, LONGLONG *oldestSlow,
			CHART_QUEUE_TYPES chartQueueType);
	void WaitLock(int who) {
		// check if another thread already locked
//		while(InterlockedIncrement(&m_mutex) !=1)
//		{
//			InterlockedDecrement(&m_mutex);		
//			//qDebug("%d blocked\n", who);
//			sleep(5);
//		}
		m_critsec.lock();
		// CR3132 - Get Lock on newly declared critical section object along with old one..
		m_critsecMsg.lock();
	}
	//void Unlock() { InterlockedDecrement(&m_mutex); }
	void Unlock() {
		// CR3132 - Release lock on newly declared critical section object along with old one.
		m_critsecMsg.lock();
		m_critsec.lock();
	}
	/// Accessor for getting and setting the various chart speeds
	static void SetChartSpeed(const CHART_QUEUE_TYPES eCHART_QUEUE_TYPE, const USHORT usSPEED,
			const ChartSpeed eSPEED_TYPE);
	//static void SetChartSpeedDirectly( const USHORT usSPEED, const ChartSpeed eSPEED_TYPE ) { ms_uiChartSpeeds[ eSPEED_TYPE] = usSPEED; }
	static const UINT GetChartSpeed(const CHART_QUEUE_TYPES eCHART_QUEUE_TYPE, const ChartSpeed eSPEED_TYPE) {
		return ms_uiChartSpeeds[eCHART_QUEUE_TYPE][eSPEED_TYPE];
	}
	// CR: 3151 Replay at Faster speed
	///Accessor for getting reply chart speed of recorder based on selction made for each chart
	static const UINT GetReplayChartSpeed(const ChartSpeed eSPEED_TYPE) {
		return ms_uiReplayChartSpeeds[eSPEED_TYPE];
	}
	static BYTE RateToIndex(const CHART_QUEUE_TYPES eCHART_QUEUE_TYPE, UINT rate);
	static UINT GetRateAtIndex(const CHART_QUEUE_TYPES eCHART_QUEUE_TYPE, UINT index);
};
struct ReadContext {
	LONGLONG m_LocateTime;	/// time of reading to find (in hundredth's of Sec) for GetFirstReading()
	CChartBlock *m_pBlock;		/// pointer to current block	
	int m_recIndex;				/// index of record within block
	ChartRec *m_pRec;		/// pointer to record within block (at m_recIndex)
	int m_readingIndex;			/// index of reading within record
	BOOL m_Resync;			/// flag when the next reading may require locate time to be resync'd
	ChartReading *m_pReading;			/// pointer to reading within record (at m_readIndex);
	LONGLONG m_ReadingTime;		/// time of the reading
	int m_RecTpp;				/// Tpp of record read.
	float m_max;
	float m_min;
};
class CChartQ {
private:
	CChartBlock *m_pHead;
	CChartBlock *m_pTail;
	CChartBlock *m_pRequestblock;
	CChartBlock *m_pOldRequestblock; // used when we want to cancel a request
	// Indicates the queue type i.e. strip or circular chart
	CHART_QUEUE_TYPES m_chartQueueType;
public:
	BOOL m_FirstInitDone;
	BOOL m_NeedsPrefill;
	BOOL m_NeedsInit;
	USHORT m_PenIndex;		/// pen Index (zero based)
	int m_Tpp;			/// time per pixel of the data being added to list. 
	int m_DrawingTpp;	/// time per pixel for drawing. Normally same as above, but can be different for Zooming etc.
	BYTE m_rateIndex;
	LONGLONG m_lastWriteTime;
	int m_NumBlocks;
	BOOL m_IsSRAM;
	USHORT m_QHandle;
	T_QMC_QUEUE_TYPE m_QueueType;
	ChartSpeed m_fastmedslow;
	BOOL m_InitialRequest;
	BOOL m_OutstandingRequest;
	BOOL m_ReplayUsage;		/// when this Q is being used in Replay mode
	// params used for writing
	CBasicMaxMin m_MaxMin;
	bool m_bIsClearQTriggered;
	CChartQ(int PenNumber, ChartSpeed fastmedslow, CHART_QUEUE_TYPES chartQueueType);
	CChartQ(int PenNumber, ChartSpeed fastmedslow, CHART_QUEUE_TYPES chartQueueType, BOOL isSram); /// SRAM constructor
	~CChartQ();
	BOOL Init(LONGLONG InitialTime);
	void ReInit();
	BOOL AddBlock();
	BOOL AddReading(float value, LONGLONG processTime100);
	void UpdateOldestTime(CHART_QUEUE_TYPES chartQueueType);
	void DeleteContents();
	void RecoverMemoryBlocks();
	CChartBlock* ReuseOrAddNewBlock(int NoOfRecs);
	CChartBlock* GetTail() {
		return m_pTail;
	}
	CHARTRET GetFirstReadingCirci(ReadContext *rc);
	CHARTRET GetFirstReading(ReadContext *rc);
	CHARTRET GetNextReading(ReadContext *rc);
	CHARTRET MaxMinCalc(ReadContext *rc);
	CHARTRET GetNextForMaxMin(ReadContext *rc);
	void DataUpdate(T_USRREQSER_USER_MESSAGE_REPLY *pReply);
	BOOL CheckQueue(LONGLONG TimeFrom, LONGLONG TimeTo);
	//PSR Fix for PAR# 1-3N5DCMN - Recorder hung while menu navigation, followed by Real time to history mode in circular chart begin
	int GetRecsPerBlock();
	int GetMaxQBlocks();
	BOOL CheckQueue(bool bIsHistoryMode, LONGLONG TimeFrom, LONGLONG TimeTo);
	//PSR Fix for PAR# 1-3N5DCMN - Recorder hung while menu navigation, followed by Real time to history mode in circular chart end
	int CalcNumRecs(LONGLONG TimeFrom, LONGLONG TimeTo);
	void InsertBlock(CChartBlock *plistBlock, CChartBlock *pNewBlock);
	void DeleteBlock(CChartBlock *pBlock);
	void DumpQ();
	BOOL InsertIntoQueue();
	BOOL UserViewingHead();
};
enum ChartBlkType {
	CBLK_NORMAL = 0, CBLK_REQUESTED, CBLK_NODATA
};
class CChartBlock {
private:
	CChartQ *m_pParent;
	// write context variables
	ChartRec *m_pWriteRec; /// pointer to current record within block (for writing)
	ChartReading *m_pCurrent;	/// pointer to reading
	void InitRecHeader(ChartRec *pRec, LONGLONG startTime, USHORT penNo, BYTE rateIndex);
	CQMDataBlock *m_pQMdblock; // pointer to SRAM block (for SRAM Q's only)
public:
	// pointer to an array of 1 or more ChartRec records 
	ChartRec *m_pRecs; ///< pointer to block of m_TotalRecs records (512byte blocks)
	short m_TotalRecs;		///< actual number of records allocated in the block
	short m_UsedRecs;		///< rec number of last rec filled (subtract 1 for it's index)
	short m_FirstRec;	///< index of first rec of use within ChartRecs block.
	LONGLONG m_StartTime; ///< Times in 100ths
	LONGLONG m_EndTime;
	LONGLONG m_DataEndTime;
	ChartBlkType m_Type;
	CChartBlock *m_pNext;	// next CChartBlock
	CChartBlock *m_pPrev;	// previous CChartBlock
	CChartBlock(CChartQ *pParent);
	~CChartBlock();
	BOOL CreateRecs(int NumRecs = 0);
	void Copy(CChartBlock *pSource);
	BOOL CopyToExistingBlock(CChartBlock *pSource);
	void SetBlockStatus(T_QMC_BLOCK_STATUS status);
	T_QMC_BLOCK_STATUS GetBlockStatus();
	void Reset(int NumRecs = 0);
	void Prefill(LONGLONG startTime100, ChartReading reading);
	BOOL AddReading(LONGLONG readingTime100, float maxv, float minv);
	CHARTRET GetFirstReading(ReadContext *rc, const CHART_QUEUE_TYPES eCHART_QUEUE_TYPE);
	CHARTRET GetNextReading(ReadContext *rc, const CHART_QUEUE_TYPES eCHART_QUEUE_TYPE);
	ChartRec* GetDataRec() {
		return m_pRecs;
	}
	void Validate(USHORT NumRecs, BOOL WasForwardReq, BOOL ReduceEndTime, BOOL IncreaseStartTime,
			const CHART_QUEUE_TYPES eCHART_QUEUE_TYPE);
	void RemoveData();
	void Dump();
};
///////////////////////////////////////////////////////////////////////
//
// CHART MESSAGES:
#define MESSQ_REQ_SIZE QMC_MAX_BLOCKS_ALLOWED_FOR_ONE_REQUEST // use the max possible. 
enum CHART_MESS_Qs {
	ALARM_MESSAGE = 0, SYSTEM_MESSAGE, USER_MESSAGE,
	NUM_CHART_MESSAGE_Qs // keep at the end
};
enum MESSRET {
	MESSAGE_OK = 0, NO_MORE_MESSAGES,
};
enum BLOCK_POS {
	HEAD, TAIL, TEST,
};
// forward ref
class CChartMessageBlock;
struct ReadMessageContext {
	LONGLONG m_LocateTime;	/// time of reading to find (in hundredth's of Sec) 
	int m_ReqTpp;
	CChartMessageBlock *m_pBlock;
	MessageHolder *m_pCurMessage;
	USHORT m_GroupNumber;
};
struct CFRequest {
	USHORT m_QHandle;
	BOOL m_OutstandingRequest;
	CChartMessageBlock *m_pDestMessageBlock;
	MessageRec m_Recs[MESSQ_REQ_SIZE];
};
class CChartMessageQ {
private:
	CChartMessageBlock *m_pTail;
public:
	CChartMessageBlock *m_pHead;
	CChartMessageQ();
	void SetupQs();
	~CChartMessageQ();
	void DefaultSettings();
	CChartMessageBlock* ReUseBlock(BLOCK_POS pos, BOOL IsTailBlock = FALSE, CChartMessageBlock *pIgnoreBlock = NULL);
	BOOL UserViewingHead();
	void DeleteContents();
	BOOL GetPreviousAlarmMessage(LONGLONG beforeTime, T_MSGLISTSER_MESSAGE *RetMessage, USHORT GroupNumber);
	BOOL CheckQueue(LONGLONG TimeFrom, LONGLONG TimeTo);
	BOOL CheckSpans(CChartMessageBlock *pBlock);
	void InsertBlock(CChartMessageBlock *plistPos, CChartMessageBlock *pNewBlock);
	void DataUpdate(T_USRREQSER_USER_MESSAGE_REPLY *pReply, int messtype);
	void SplitBlock(CChartMessageBlock *pblock);
	void AddMessage(T_MSGLISTSER_MESSAGE *msg);
	MESSRET GetFirstMessage(ReadMessageContext *rmc);
	MESSRET GetNextMessage(ReadMessageContext *rmc);
	MESSRET GetPreviousMessage(ReadMessageContext *rmc);
	MESSRET GetFirstAlarmMessage(ReadMessageContext *rmc);
	MESSRET GetNextAlarmMessage(ReadMessageContext *rmc);
	CFRequest m_RequestInfo[NUM_CHART_MESSAGE_Qs];
	BOOL m_DoneSetup;
	BOOL m_InitialRequest;
	LONGLONG m_LastMessTime;
	BOOL m_ReplayUsage;		///< when this Q is being used in Replay mode
	int m_AlarmMessageQhandle;
	int m_NumMsgBlocks;
	int m_TotNumMsg;
	LONGLONG m_QBaseAlarmMessageTime;
	T_MSGLISTSER_MESSAGE m_QBaseAlarmMessage;
	T_MSGLISTSER_MESSAGE m_QNewAlarmMessage;
	LONGLONG m_OldestMessageTime;
	void DumpQ();
	void DumpMessage(T_MSGLISTSER_MESSAGE *dMessage);
};
class CChartMessageBlock {
private:
	CChartMessageQ *m_pParent;
public:
	MessageHolder *m_pMessages;
	int m_NumMessages;
	LONGLONG m_StartTime;		///< Span covered by this block
	LONGLONG m_EndTime;			///< upto but not including endtime.
	// flag to indicate we have the span covered for each queue.
	BYTE m_SpanRequested[NUM_CHART_MESSAGE_Qs];
	BYTE m_SpanCovered[NUM_CHART_MESSAGE_Qs];
	LONGLONG m_LastMessageTime[NUM_CHART_MESSAGE_Qs];		///< actual time of last message in list under this block	
	CChartMessageBlock *m_pNext;	// next CChartMessageBlock
	CChartMessageBlock *m_pPrev;	// previous CChartMessageBlock	
	CChartMessageBlock(CChartMessageQ *pParent, BOOL IsTail = FALSE);
	~CChartMessageBlock();
	void Reset(BOOL IsTail);
	BOOL ExtractMessages(int messType, MessageRec *pBlocks, int numOfBlocksObtained);
	void Dump();
};
#endif

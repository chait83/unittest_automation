/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Queue Manager
/// @n Filename:	QMPersistDataFileQ.cpp
/// @n Description: Class Implementation File for CQMPersistDataFileQ
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 31	Stability Project 1.26.1.3	7/2/2011 5:00:04 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 30	Stability Project 1.26.1.2	7/1/2011 4:38:46 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 29	Stability Project 1.26.1.1	3/17/2011 3:20:39 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 28	Stability Project 1.26.1.0	2/15/2011 3:03:48 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
// **************************************************************************
#include "QMPersistDataFileQ.h"
#include "CStorage.h"
#include "V6globals.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
//****************************************************************************
/// Constructor
///
/// @param[in] 	persistDataFileQ - Reference to the Persisited Data File Queue Access Class 
/// @param[in] dataFileAccess - Reference to the Data File Header Access Class
///
/// @return No Return Value
/// 
//****************************************************************************
CQMPersistDataFileQ::CQMPersistDataFileQ(class CQMPersistDataFileQAccess &persistDataFileQ,
		class CQMDataFileAccess &dataFileAccess, T_PQMC_DBFILES pDBFiles) : m_PersistDataFileQ(persistDataFileQ), m_DataFileAccess(
		dataFileAccess)
{
	m_pDBFiles = pDBFiles; //Indexed up to MAX_FILES
} // End of Constructor
//****************************************************************************
/// Destructor
//****************************************************************************
CQMPersistDataFileQ::~CQMPersistDataFileQ(void) {
	// Do Nothing 
} // End of Destructor
//****************************************************************************
/// Add a Data File to the End( Tail ) of the Specified Queue, taking into 
/// account that the queue may be empty. The File being added to the End of the
/// Queue may be one of two types, a RECYCLED file or NORMAL File. The type of
/// file will determine what the file header needs to be set-up and how the Next
/// and Previous File are initialised. Once the File Header has been constructed,
/// it is written directly to the Physical Disk. 
///
/// @param[in] hQueue	- Queue Hanlder to Perform Operation 
/// @param[in] fileNumber - File Number to Add to the Queue
/// @param[in] fileToAdd - Type of File being added, Recyled or Normal. 
/// @param[in/out] FileOpened - flag to indicate if a file was opened or not
///
/// @return QMPDFQA_OK - Data File Added Successfully
/// 
//****************************************************************************
T_QMPDFQ_RETURN_VALUE CQMPersistDataFileQ::AddFileToTail(const USHORT hQueue, const USHORT fileNumber,
		const T_QMPDFQ_FILE_TO_ADD fileToAdd) {
	if (QMPDFQA_OK != m_PersistDataFileQ.ValidateQueueHandler(hQueue)) {
		QString strError("");
		strError = QString::asprintf("AddFileToTail - Invalid queue handle (%u)", hQueue);
        V6CriticalMessageBox(NULL, strError.toLocal8Bit().data(), "CQMPersistDataFileQ Error", MB_OK );
	}
	assert(QMDFA_OK == m_DataFileAccess.ValidateFileNumber(fileNumber));
	T_QMPDFQ_RETURN_VALUE retValue = QMPDFQ_OK;
	USHORT QStatus = GetQueueStatus(hQueue);
	//all the stuff that can happen no matter what the circumstances
	m_DataFileAccess.SetQueueId(fileNumber, hQueue);
	//T_QMPDFQ_FILE_TO_ADD and T_QMC_DATAFILE_MODE enumerate to compatible values so can be interchanged
	m_DataFileAccess.SetFileMode(fileNumber, fileToAdd);
	m_DataFileAccess.SetNewestBlockNumber(fileNumber, QMC_ZERO); //should only happen for a new file
	//the 2 main factors for the behaviour of this function are:
	//if the file is recycling or if the q is empty and each combination has a slightly different effect
	if (QMPDFQ_FA_RECYCLED_FILE == fileToAdd) {
		// file is recycling
		//update file header with the useable number of blocks in the file.
		///@TODO WTF???? this doesn't make any sense....
		m_DataFileAccess.SetNumOfBlocks(fileNumber, m_DataFileAccess.GetNumOfDataBlocks(fileNumber));
		m_DataFileAccess.SetOldestBlockNumber(fileNumber, m_DataFileAccess.GetOldestBlockNumber(fileNumber));
		// Head needs to point to the File Being Added, due to the oldest data is contained within
		// this file. 
		//if the q is empty Get head will fail but need to be set to point to itself anyway
		if (QMPDFQ_STATUS_EMPTY == QStatus) {
			//the currently detatched head's prev and next must now point to itself
			m_DataFileAccess.SetNextFile(fileNumber, fileNumber);
			m_DataFileAccess.SetPreviousFile(fileNumber, fileNumber);
		} else {
			USHORT fTail = m_PersistDataFileQ.GetTail(hQueue);
			USHORT fHead = m_PersistDataFileQ.GetHead(hQueue);
			//current file's next should already point to the current head so this is just a failsafe
			m_DataFileAccess.SetNextFile(fileNumber, fHead);
			m_DataFileAccess.SetPreviousFile(fileNumber, fTail);
			m_DataFileAccess.SetPreviousFile(fHead, fileNumber);
			m_DataFileAccess.SetNextFile(fTail, fileNumber);
		}
		//Set the new head to the current file
		m_PersistDataFileQ.SetHead(hQueue, fileNumber);
	} else //not recycling
	{
		//zero the blocks in the file header
		m_DataFileAccess.SetNumOfBlocks(fileNumber, QMC_ZERO);
		m_DataFileAccess.SetOldestBlockNumber(fileNumber, QMC_ZERO);
		m_DataFileAccess.SetNewestBlockNumber(fileNumber, QMC_ZERO);
		//set next and prev's dependant on emptiness of the Q
		if (QMPDFQ_STATUS_EMPTY == QStatus) {
			m_DataFileAccess.SetNextFile(fileNumber, QMC_END_OF_QUEUE);
			m_DataFileAccess.SetPreviousFile(fileNumber, QMC_START_OF_QUEUE);
			m_PersistDataFileQ.SetHead(hQueue, fileNumber);
		} else {
			USHORT fn = m_PersistDataFileQ.GetTail(hQueue);
			m_DataFileAccess.SetNextFile(fn, fileNumber);
			m_DataFileAccess.SetPreviousFile(fileNumber, fn);
			m_DataFileAccess.SetNextFile(fileNumber, QMC_END_OF_QUEUE);
		}
	}
	//set the tail now that all the next and prev juggling has been done
	m_PersistDataFileQ.SetTail(hQueue, fileNumber);
	m_PersistDataFileQ.IncrementNumOfFiles(hQueue);
	// Write the File Header to the physical file
	return (retValue);
} // End of Member Function										
//****************************************************************************
/// Obtain a Pointer to the Current( Head ) Available File in the Specified Queue
///
/// @param[in] hQueue	- Queue Hanlder to Perform Operation 
///
/// @return T_QMC_DATAFILE_HEADER - Pointer to the Head File
///		NULL				- No Data File Available
///
//**************************************************************************** 
T_QMC_DATAFILE_HEADER* const CQMPersistDataFileQ::GetHeadFile(const USHORT hQueue) const {
	if (QMPDFQA_OK != m_PersistDataFileQ.ValidateQueueHandler(hQueue)) {
		QString strError("");
		strError = QString::asprintf("GetHeadFile - Invalid queue handle (%u)", hQueue);
        V6CriticalMessageBox(NULL, strError.toLocal8Bit().data(), "CQMPersistDataFileQ Error", MB_OK );
	}
	T_QMC_DATAFILE_HEADER *pDataFile = NULL;
	if (QMPDFQ_STATUS_EMPTY != GetQueueStatus(hQueue)) {
		pDataFile = m_DataFileAccess.GetFileHeader(m_PersistDataFileQ.GetHead(hQueue));
	} // End of IF
	return (pDataFile);
} // End of Member Function	
//****************************************************************************
/// Obtain a Pointer to the End( Tail ) Available File in the Specified Queue
///
/// @param[in] hQueue	- Queue Hanlder to Perform Operation 
///
/// @return T_QMC_DATAFILE_HEADER - Pointer to the Head File
///		NULL				- No Data File Available
///
//**************************************************************************** 
T_QMC_DATAFILE_HEADER* const CQMPersistDataFileQ::GetTailFile(const USHORT hQueue) const {
	if (QMPDFQA_OK != m_PersistDataFileQ.ValidateQueueHandler(hQueue)) {
		DebugBreak();
	}
	T_QMC_DATAFILE_HEADER *pDataFile = NULL;
	if (QMPDFQ_STATUS_EMPTY != GetQueueStatus(hQueue)) {
		pDataFile = m_DataFileAccess.GetFileHeader(m_PersistDataFileQ.GetTail(hQueue));
	} // End of IF
	return (pDataFile);
} // End of Member Function	
//****************************************************************************
/// Remove the Current( Head ) Available File from the Specified Queue, ensures 
/// the head and tail of the Queue are set correctly. If the Queue becomes 
/// Empty on this call the Head and Tail will indicate this by a known 
/// default value. 
///
/// @param[in] hQueue	- Queue Hanlder to Perform Operation 
///
/// @return QMDFQ_OK				- Head File Removed Successfully
///		QMDFQ_NO_FILE_TO_REMOVE - No File within the Queue to Remove
///				
//****************************************************************************
T_QMPDFQ_RETURN_VALUE CQMPersistDataFileQ::RemoveHeadFile(const USHORT hQueue) {
	if (QMPDFQA_OK != m_PersistDataFileQ.ValidateQueueHandler(hQueue)) {
		QString strError("");
		strError = QString::asprintf("RemoveHeadFile - Invalid queue handle (%u)", hQueue);
        V6CriticalMessageBox(NULL, strError.toLocal8Bit().data(), "CQMPersistDataFileQ Error", MB_OK );
	}
	T_QMPDFQ_RETURN_VALUE retValue = QMPDFQ_NO_FILES_TO_REMOVE;
	if (QMPDFQ_STATUS_EMPTY != GetQueueStatus(hQueue)) {
		USHORT nextFile = m_DataFileAccess.GetNextFile(m_PersistDataFileQ.GetHead(hQueue));
		if (QMC_END_OF_QUEUE == nextFile) {
			m_PersistDataFileQ.SetHead(hQueue, QMC_START_OF_QUEUE);
			m_PersistDataFileQ.SetTail(hQueue, QMC_END_OF_QUEUE);
		} else {
			m_PersistDataFileQ.SetHead(hQueue, nextFile);
			m_DataFileAccess.SetPreviousFile(nextFile, QMC_START_OF_QUEUE);
		} // End of IF
		m_PersistDataFileQ.DecrementNumOfFiles(hQueue);
		retValue = QMPDFQ_OK;
	} // End of IF
	return (retValue);
} // End of Member Function										
//****************************************************************************
/// Obtains the Status of the Specified Queue 
///
/// @param[in] hQueue	- Queue Hanlder to Perform Operation 
///
/// @return QMPDFQ_STATUS_EMPTY		- Data File Queue is Empty 
///		QMPDFQ_STATUS_MIN_NOT_REACHED - Queue has not reached its minimum requirements
///		QMPDFQ_STATUS_MAX_REACHED	- Queue has reached its maximum number of Files
///		QMPDFQ_STATUS_MAX_EXCEEDED	- Queue has exceeded its maxumum number of Files
///
//****************************************************************************
T_QMPDFQ_QUEUE_STATUS CQMPersistDataFileQ::GetQueueStatus(const USHORT hQueue) const {
	if (QMPDFQA_OK != m_PersistDataFileQ.ValidateQueueHandler(hQueue)) {
		QString strError("");
		strError = QString::asprintf("GetQueueStatus - Invalid queue handle (%u)", hQueue);
        V6CriticalMessageBox(NULL, strError.toLocal8Bit().data(), "CQMPersistDataFileQ Error", MB_OK );
	}
	T_QMPDFQ_QUEUE_STATUS retValue = QMPDFQ_STATUS_EMPTY;
	if (QMC_START_OF_QUEUE != m_PersistDataFileQ.GetHead(hQueue)
			&& QMC_END_OF_QUEUE != m_PersistDataFileQ.GetTail(hQueue)) {
		if (m_PersistDataFileQ.GetNumOfFilesInQueue(hQueue) < m_PersistDataFileQ.GetMaxFiles(hQueue)) {
			retValue = QMPDFQ_STATUS_MAX_NOT_REACHED;
		} else if (m_PersistDataFileQ.GetNumOfFilesInQueue(hQueue) == m_PersistDataFileQ.GetMaxFiles(hQueue)) {
			retValue = QMPDFQ_STATUS_MAX_REACHED;
		} else {
			retValue = QMPDFQ_STATUS_MAX_EXCEEDED;
		} // End of IF	
	} // End of IF		
	return (retValue);
} // End of Member Function	
//****************************************************************************
/// Get the Current Number of Files in the Queue
///
/// @param[in] hQueue	- Queue Hanlder to Perform Operation 
///
/// @return Number of Files in the Specified Queue
///
//****************************************************************************
USHORT CQMPersistDataFileQ::GetNumOfFilesInQueue(const USHORT hQueue) const {
	if (QMPDFQA_OK != m_PersistDataFileQ.ValidateQueueHandler(hQueue)) {
		QString strError("");
		strError = QString::asprintf("GetNumOfFilesInQueue - Invalid queue handle (%u)", hQueue);
        V6CriticalMessageBox(NULL, strError.toLocal8Bit().data(), "CQMPersistDataFileQ Error", MB_OK );
	}
	return (m_PersistDataFileQ.GetNumOfFilesInQueue(hQueue));
} // End of Member Function	
//****************************************************************************
/// Get the Current Number of Data blocks in the Queue
///
/// @param[in] hQueue	- Queue Hanlder to Perform Operation 
/// @param[in] NumFileBlocks - Number of blocks in each File
///
/// @return Number of blocks used by the specified Queue
///
//****************************************************************************
ULONG CQMPersistDataFileQ::GetNumBlocksInFileQueue(const USHORT hQueue, const USHORT NumFileBlocks) const {
	if (QMPDFQA_OK != m_PersistDataFileQ.ValidateQueueHandler(hQueue)) {
		QString strError("");
		strError = QString::asprintf("GetNumBlocksInFileQueue - Invalid queue handle (%u)", hQueue);
        V6CriticalMessageBox(NULL, strError.toLocal8Bit().data(), "CQMPersistDataFileQ Error", MB_OK );
	}
	USHORT NumFiles = m_PersistDataFileQ.GetNumOfFilesInQueue(hQueue);
	//USHORT	TailFile = m_PersistDataFileQ.GetTail(hQueue);
	ULONG NumQBlocks = NULL;
	if (NumFiles) {
		const T_QMC_DATAFILE_HEADER *TailHeader = m_DataFileAccess.GetFileHeader(m_PersistDataFileQ.GetTail(hQueue));
		if (QMC_INVALID_FILE_NUMBER != TailHeader->nextFile
				&& (QMDFA_FILE_NUMBER_INVALID != m_DataFileAccess.ValidateFileNumber(TailHeader->nextFile))) { //Recycling, so the head block will be 1 block before the tail block
																											 //in tail file and all blocks will be used
			NumQBlocks = NumFiles * NumFileBlocks;
		} else {										//Not Recycling so all blocks used in all files except the tail
//			NumQBlocks = (TailHeader->newestBlockNumber - TailHeader->oldestBlockNumber)
//				+ ((NumFiles - 1) * NumFileBlocks);
			if (TailHeader->newestBlockNumber != TailHeader->oldestBlockNumber) {
				NumQBlocks = (TailHeader->newestBlockNumber - TailHeader->oldestBlockNumber);
			} else if (TailHeader->newestBlockNumber != 0) {
				NumQBlocks = 1;
			}
			NumQBlocks += ((NumFiles - 1) * NumFileBlocks);
		}
	}
	return (NumQBlocks);
} // End of Member Function	
//****************************************************************************
/// Get the Number of Data blocks currently reserved by the Queue
///
/// @param[in] hQueue	- Queue Hanlder to Perform Operation 
/// @param[in] NumFileBlocks - Number of blocks in each File
///
/// @return Number of blocks used by the specified Queue
///
//****************************************************************************
ULONG CQMPersistDataFileQ::GetNumBlocksReservedInFileQueue(const USHORT hQueue, const USHORT NumFileBlocks) const {
	if (QMPDFQA_OK != m_PersistDataFileQ.ValidateQueueHandler(hQueue)) {
		QString strError("");
		strError = QString::asprintf("GetNumBlocksReservedInFileQueue - Invalid queue handle (%u)", hQueue);
        V6CriticalMessageBox(NULL, strError.toLocal8Bit().data(), "CQMPersistDataFileQ Error", MB_OK );
	}
	return (m_PersistDataFileQ.GetNumOfFilesInQueue(hQueue) * NumFileBlocks);
} // End of Member Function	
//****************************************************************************
/// Get the Number of Data blocks allocated the Queue
///
/// @param[in] hQueue	- Queue Hanlder to Perform Operation 
/// @param[in] NumFileBlocks - Number of blocks in each File
///
/// @return Number of blocks used by the specified Queue
///
//****************************************************************************
ULONG CQMPersistDataFileQ::GetMaxNumBlocksInQueue(const USHORT hQueue, const USHORT NumFileBlocks) {
	assert(QMPDFQA_OK == m_PersistDataFileQ.ValidateQueueHandler(hQueue));
	return (m_PersistDataFileQ.GetMaxFiles(hQueue) * NumFileBlocks);
}
//****************************************************************************
/// Get the Current Number of Data blocks in the Queue
///
/// @param[in] hQueue	- Queue Hanlder to Perform Operation 
/// @param[in] NumFileBlocks - number of blocks per file
/// @param[in] FileID	- ID of file to count from
/// @param[in] BlockID	- ID of block to count from (inclusive)
///
/// @return Number of blocks used by the specified Queue or 0xFFFFFFFF
/// if supplied QID and file QID mismatch
///
//****************************************************************************
ULONG CQMPersistDataFileQ::GetNumBlocksInFileQueueFromPoint(const USHORT hQueue, const USHORT NumFileBlocks,
		const USHORT FileID, const USHORT BlockID) const {
	if (QMPDFQA_OK != m_PersistDataFileQ.ValidateQueueHandler(hQueue)) {
		QString strError("");
		strError = QString::asprintf("GetNumBlocksInFileQueueFromPoint - Invalid queue handle (%u)", hQueue);
        V6CriticalMessageBox(NULL, strError.toLocal8Bit().data(), "CQMPersistDataFileQ Error", MB_OK );
	}
	ULONG BlockCount = NULL;
	//validate that Tx point has not been reset
	//validate there are files in the Queue
	USHORT FTotal = m_PersistDataFileQ.GetNumOfFilesInQueue(hQueue);
	if (FTotal) {
		if (QMC_INVALID_FILE_NUMBER != FileID
				&& (QMDFA_FILE_NUMBER_INVALID != m_DataFileAccess.ValidateFileNumber(FileID))) {
			const T_QMC_DATAFILE_HEADER *TailHeader = m_DataFileAccess.GetFileHeader(
					m_PersistDataFileQ.GetTail(hQueue));
			const T_QMC_DATAFILE_HEADER *FileHeader = m_DataFileAccess.GetFileHeader(FileID);
			//sanity check
			if (hQueue != FileHeader->queueId) {
				//ARRGGHHHH! File and Queue mismatch. lets get out of here, pronto!
				return QMC_FILE_QUEUE_MISMATCH;
			}
			//Traverse the list from the given point to the tail.
			USHORT Fcount;
			if ((QMC_DATAFILE_MODE_RECYCLING != TailHeader->fileMode) && (FileID == TailHeader->fileId)
					&& (BlockID > TailHeader->newestBlockNumber)) {
				BlockCount = 0;
			} else {
				if ((FileHeader->fileId == TailHeader->fileId) && (FileHeader->newestBlockNumber >= BlockID)) {
					//Txpoint is in the same file as the newest block
					BlockCount = (FileHeader->newestBlockNumber - BlockID) + QMC_ONE_BLOCK;
				} else {
					for (Fcount = 0;
							(FileHeader->nextFile != QMC_INVALID_FILE_NUMBER)
									&& (FileHeader->nextFile != TailHeader->fileId); Fcount++) {
						FileHeader = m_DataFileAccess.GetFileHeader(FileHeader->nextFile);
					}
					//Fcount now represents the number of whole files between the given point and the tail
					BlockCount += NumFileBlocks * Fcount;
					//				if ((FileID == TailHeader->fileId) && (FileHeader->fileMode != QMC_DATAFILE_MODE_RECYCLING))
					//				{
					//the Trans point is in the same file as the newest, and isn't recycling
					//so count is a pure difference. + one block to make it all inclusive
					//					BlockCount += (TailHeader->newestBlockNumber - BlockID) + QMC_ONE_BLOCK;//BlockID may be zerobased 
					//				}
					//				else
					{
						//otherwise it's the Trans point to the end of it's file, 
						//plus the beginning of the tail to the newest block (which might be the same file,
						//but won't overlap. + one block to make it all inclusive
						BlockCount += (NumFileBlocks - BlockID) + QMC_ONE_BLOCK;
						BlockCount += TailHeader->newestBlockNumber;
					}
				}
			}
		} else {
			BlockCount = GetNumBlocksInFileQueue(hQueue, NumFileBlocks);
		}
	}
	return (BlockCount);
} // End of Member Function 
//****************************************************************************
/// Remove All Files from the Specified Queue
///
/// @param[in] hQueue	- Queue Hanlder to Perform Operation 
///
/// @return USHORT - number of Files Removed from the Specified Queue
///
//****************************************************************************
USHORT CQMPersistDataFileQ::RemoveAllFiles(const USHORT hQueue) {
	if (QMPDFQA_OK != m_PersistDataFileQ.ValidateQueueHandler(hQueue)) {
		QString strError("");
		strError = QString::asprintf("RemoveAllFiles - Invalid queue handle (%u)", hQueue);
        V6CriticalMessageBox(NULL, strError.toLocal8Bit().data(), "CQMPersistDataFileQ Error", MB_OK );
	}
	USHORT retValue = 0;
	if (QMPDFQ_STATUS_EMPTY != GetQueueStatus(hQueue)) {
		m_PersistDataFileQ.SetHead(hQueue, QMC_START_OF_QUEUE);
		m_PersistDataFileQ.SetTail(hQueue, QMC_END_OF_QUEUE);
		retValue = m_PersistDataFileQ.GetNumOfFilesInQueue(hQueue);
		m_PersistDataFileQ.SetNumOfFiles(hQueue, 0);
	} // End of IF
	return (retValue);
} // End of Member Function
//****************************************************************************
/// Provides a method of tracing the Queue to the Trace Window when debugging. 
/// The trace displays all the files within the Specified Queue, starting from the Head. 
///
/// @param[in] pName - Name of the Queue to be Traced. 
/// @param[in] hQueue - Queue Hanlder to Perform Operation 
///
/// @return No Return Value
///				
//****************************************************************************
void CQMPersistDataFileQ::TraceQueue(const QString pName, const USHORT hQueue) {
	if (QMPDFQA_OK != m_PersistDataFileQ.ValidateQueueHandler(hQueue)) {
		QString strError("");
		strError = QString::asprintf("TraceQueue - Invalid queue handle (%u)", hQueue);
        V6CriticalMessageBox(NULL, strError.toLocal8Bit().data(), "CQMPersistDataFileQ Error", MB_OK );
	}
	const T_QMC_DATAFILE_HEADER *const pHeadFile = GetHeadFile(hQueue);
	qDebug("\nName: %s Queue: %d\n", pName.toLocal8Bit().data(), hQueue);
	if (QMPDFQ_STATUS_EMPTY == GetQueueStatus(hQueue)) {
		qDebug("FILE QUEUE EMPTY\n");
	} else {
		USHORT item = pHeadFile->fileId;
		qDebug("HEAD =");
		for (USHORT pos = 0; pos < m_PersistDataFileQ.GetNumOfFilesInQueue(hQueue); pos++) {
			qDebug(" (%d)", m_DataFileAccess.GetPreviousFile(item));
			qDebug("[%d] ", item);
			item = m_DataFileAccess.GetNextFile(item);
		} // End of FOR
		qDebug("= TAIL -> 0x%X (NoOfFiles: %d)\n\n", item, m_PersistDataFileQ.GetNumOfFilesInQueue(hQueue));
	} // End of IF
} // End of Member Function	
//****************************************************************************
/// Accessor to set the number of files a queue can have before it starts recycling 
///
/// @param[in] hQueue - Queue Hanlder to Perform Operation 
/// @param[in] NumFiles - Number of files to be set. 
///
/// @return QMPDFQA_OK if Sucessful
///				
//****************************************************************************
T_QMPDFQA_RETURN_VALUE CQMPersistDataFileQ::SetMaxFiles(const USHORT hQueue, const USHORT NumFiles) {
	if (QMPDFQA_OK != m_PersistDataFileQ.ValidateQueueHandler(hQueue))
		return QMPDFQA_FILE_QUEUE_NUMBER_INVALID;
	else
		return m_PersistDataFileQ.SetMaxFiles(hQueue, NumFiles);
}
//****************************************************************************
/// Accessor to set the number of files a queue can have before it starts recycling 
///
/// @param[in] hQueue - Queue Hanlder to Perform Operation 
/// @param[in] NumFiles - Number of files to be set. 
///
/// @return QMPDFQA_OK if Sucessful
///				
//****************************************************************************
USHORT CQMPersistDataFileQ::GetMaxFiles(const USHORT hQueue) {
	if (QMPDFQA_OK != m_PersistDataFileQ.ValidateQueueHandler(hQueue))
		return QMPDFQA_FILE_QUEUE_NUMBER_INVALID;
	else
		return m_PersistDataFileQ.GetMaxFiles(hQueue);
}
////////////////////////////////////////////////////////////////////////////////////////
/// --- Private Member Functions --- 
//////////////////////////////////////////////////////////////////////////////////////////
//****************************************************************************
/// Write the Specified File Header to Physical Disk 
///
/// @param[in] fileId - File Identification Number
/// 
/// @return QMPDFQ_OK	- File Header written to Disk
///		QMPDFQ_ERROR - File Header could not be written to Disk - File does not exist
/// @note this function may now be obsolete				
//****************************************************************************
T_QMPDFQ_RETURN_VALUE CQMPersistDataFileQ::WriteFileHeaderToPhysicalFile(const USHORT fileId) {
//	CStorage hDataBlockFile;						// Handle to the Data Block File
	QString filePathAndFileName = ""; // File and Path Name of the Data Block File
	T_QMPDFQ_RETURN_VALUE retValue = QMPDFQ_ERROR; // Member Function Return Value 
	if ( TRUE == pDALGLB->BuildPath(IDS_INTERNAL_SD, IDS_LOG_DATA, NULL, &filePathAndFileName, MAX_PATH)) {
		// Construct the File Name and Extension for the associated Data Block File 
		CQMDataFileAccess::CompleteDataFilePath(filePathAndFileName, MAX_PATH, fileId);	// Complete Path
		CQMDataFileAccess::CompleteDataFileName(filePathAndFileName, MAX_PATH, fileId);	// Complete Name
		// Open the Active File
		if (!m_pDBFiles[fileId].bFileCreated) {
			m_pDBFiles[fileId].pFile = new CDiskStorage;	//new CStorage;
			m_pDBFiles[fileId].pFile->Open(filePathAndFileName.toLocal8Bit().data(), QFile::ReadWrite);
//			m_pDBFiles[fileId].hFile = CreateFile(filePathAndFileName,GENERIC_READ|GENERIC_WRITE,
//				FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_ALWAYS,FILE_ATTRIBUTE_NORMAL|FILE_FLAG_WRITE_THROUGH,NULL);
			m_pDBFiles[fileId].bFileCreated = TRUE;
		}
		if (!m_pDBFiles[fileId].bFileCurrOpen) {
			//m_pDBFiles[fileId].pFile->Open( , QFile::ReadWrite|QFile::shareDenyNone);
			m_pDBFiles[fileId].bFileCurrOpen = TRUE;
//			qDebug("Header Open File %d\n",fileId);
		}
		m_pDBFiles[fileId].pFile->seek(0);
//			SetFilePointer(m_pDBFiles[fileId].hFile,0,NULL,FILE_BEGIN);
		// Write the File Header to the Disk File
		m_pDBFiles[fileId].pFile->Write(m_DataFileAccess.GetFileHeader(fileId), sizeof(T_QMC_DATAFILE_HEADER));
		//DWORD ret;
		//WriteFile(m_pDBFiles[fileId].hFile,m_DataFileAccess.GetFileHeader(fileId),sizeof(T_QMC_DATAFILE_HEADER),&ret,NULL);
		// Close the File
// 		qDebug("Header Close File %d\n",fileId);
		retValue = QMPDFQ_FILE_OPENED;
	} // End of IF
	return (retValue);
} // End of Member Function 

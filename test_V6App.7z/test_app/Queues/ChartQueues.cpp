/// @file
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	Queues
/// @n Filename: ChartQueues.cpp
/// @n Description: Queues for charts
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 107 Stability Project 1.102.1.3	7/2/2011 4:56:04 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 106 Stability Project 1.102.1.2	7/1/2011 4:38:05 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 105 Stability Project 1.102.1.1	3/17/2011 3:20:15 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 104 Stability Project 1.102.1.0	2/15/2011 3:02:32 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
// **************************************************************************
#include "V6defines.h"
#include "V6globals.h"
#include "V6Config.h"
#include "TraceDefines.h"
#include "ModuleConstants.h"
#include <QDebug>
#include "QMDataBlock.h"
#include "QueueManager.h"
#include "QMDiskServices.h"
#include "BasicMaxMinAve.h"
#include "ChartQueues.h"
#include "float.h"
#include "TimeHistory.h"
#include "V6ResourceBase.h"
#include "V6UIResource.h"
#include "UISizeDefines.h"
QMutex CChartQManager::m_critsec;
QMutex CChartQManager::m_critsecMsg;
//////////////////////////////// TEST FUNCTIONS ////////////////////////////////////////////////////////
#define SHOWREQ 0		// set this to see data requests
#define SHOWMESSREQ 0	// set this to see message requests
int penIndexToUse = 1;	// pen 1 as default but can be changed via chart keys	
//QString  GlobalTrace;
#define MemTrace {;}//
/*
 void MemTrace(USHORT penIndex, const QString  pszasprintf, ...)
 {
 #ifdef UNDER_CE
 return;
 #endif
 if((penIndex!=penIndexToUse)&&(penIndex!=100))
 return;
 WCHAR szBody[500];
 szBody[0]=0;
 va_list args;
 va_start(args, pszasprintf);
 vswprintf(szBody, pszasprintf, args);
 va_end(args);
 //GlobalTrace+=szBody;
 qDebug(szBody);
 
 }
 */
/*
 void DumpTrace()
 {
 //	int len=GlobalTrace.size();
 //	qDebug(GlobalTrace.right(500)); //see latest 500 chars
 
 }
 */
CHAR timetbuff[50];
QString FT(LONGLONG thetime) {
	CTimeHistory *pTh = CTimeHistory::GetHandle();
	TableEntry *pEntry = pTh->GetEntry(thetime);
	if (!pEntry)
		return NULL; // major problem here - no time history!
	LONGLONG diffmicro = (thetime - pEntry->Tick100) * 10000;
	CTVtime displaytime = pEntry->ActualTime + diffmicro;
	displaytime.TimeToStringShort(timetbuff);
  return QString(timetbuff);
}
CHAR stimetbuff[50];
QString FS(LONGLONG thetime) {
	CTimeHistory *pTh = CTimeHistory::GetHandle();
	TableEntry *pEntry = pTh->GetEntry(thetime);
	if (!pEntry)
		return NULL; // major problem here - no time history!
	LONGLONG diffmicro = (thetime - pEntry->Tick100) * 10000;
	CTVtime displaytime = pEntry->ActualTime + diffmicro;
	displaytime.TimeToStringShort(stimetbuff);
  return QString(stimetbuff);
}
CHAR etimetbuff[50];
QString FE(LONGLONG thetime) {
	CTimeHistory *pTh = CTimeHistory::GetHandle();
	TableEntry *pEntry = pTh->GetEntry(thetime);
	if (!pEntry)
		return NULL; // major problem here - no time history!
	LONGLONG diffmicro = (thetime - pEntry->Tick100) * 10000;
	CTVtime displaytime = pEntry->ActualTime + diffmicro;
	displaytime.TimeToStringShort(etimetbuff);
  return QString(etimetbuff);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////
// MACROS for filtering on group and testing for alarm types
#define MATCHGROUP(scrGrp,messGrp) ((scrGrp==0) || ((messGrp>>5)==0) || (scrGrp==(messGrp>>5)) ) // either can be 0
#define MATCHGROUPEXACT(scrGrp,messGrp) ((scrGrp==0) || (scrGrp==(messGrp>>5)) ) // screen showing 0 or exact group match
#define FAILGROUP(scrGrp,messGrp) (!MATCHGROUP(scrGrp,messGrp))
#define FAILGROUPEXACT(scrGrp,messGrp) (!MATCHGROUPEXACT(scrGrp,messGrp))
#define MESSGROUP(mess) (##mess->message.messageData.uCharParam[MSGLISTSER_GROUP_DESTINATION_UCHAR_ELEMENT])
#define NOT_ALARM(mess) (##mess->message.messageType>MSGLISTSER_ALARM_ACK_WHILE_OUT)
#define IS_ALARM(mess)	(##mess->message.messageType<=MSGLISTSER_ALARM_ACK_WHILE_OUT)
/*//////////////////////////////////// CHART SPEEDS //////////////////////////////////////////////////
 The following speeds are all in 100ths of a sec and are the time of a single pixel.
 The Speed selections are those that may be used for saving chart queue data to SD.
 These correspond to an approximate 'mm per hour' figure:
 fastest = 20		(0.2s)	= 6000 mm/hr.
 medium = 2000	(20s)	= 60 mm/hr
 slowest = 120000 (1200s) = 1mm/hr
 On the GR series recorder the pixel pitch varies dramatically between products, whereby
 the Mini has half the pitch of a Ez and a Multi is 0.66 the pitch of a Ez. As such we
 now need seperate chart speeds
 */
//PSR Fix for - 1-3GKDZ7Q - charting issues with slow speed begin
const UINT EzTrendSelectableFastSpeeds[NUM_SEL_FAST_STRIP_SPEEDS] = { 20, 100, 200, 400, 1000, 2000 };
const UINT EzTrendSelectableMedSpeeds[NUM_SEL_MED_STRIP_SPEEDS] = { 1000, 2000, 4000, 6000, 12000 };
//I do not know why the 6000TPP is kept at the end in array which is for 20mm/hr speed
//but kept at 1mm/hr speed in array.
//Found that IDS_CFG_SCREEN_CHART_SPEED_SLOW_LIST 	20mm/hŠ3Š|10mm/hŠ0Š|5mm/hŠ1Š|1mm/hŠ2Š| string 
//addressed this order issue. So becarful to change the below array without addressing string
//according to UI (20mmm/hr, 10mm/hr, 5mm/hr and 1mm/hr)
const UINT EzTrendSelectableSlowSpeeds[NUM_SEL_SLOW_STRIP_SPEEDS] = { 12000, 24000, 120000, 6000 };
const UINT MiniTrendSelectableFastSpeeds[NUM_SEL_FAST_STRIP_SPEEDS] = { 10, 50, 100, 200, 500, 1000 };
const UINT MiniTrendSelectableMedSpeeds[NUM_SEL_MED_STRIP_SPEEDS] = { 500, 1000, 2000, 3000, 6000 };
const UINT MiniTrendSelectableSlowSpeeds[NUM_SEL_SLOW_STRIP_SPEEDS] = { 6000, 12000, 60000, 3000 };
const UINT MultiTrendSelectableFastSpeeds[NUM_SEL_FAST_STRIP_SPEEDS] = { 10, 50, 100, 300, 600, 1200 };
const UINT MultiTrendSelectableMedSpeeds[NUM_SEL_MED_STRIP_SPEEDS] = { 600, 1200, 2400, 4000, 8000 };
const UINT MultiTrendSelectableSlowSpeeds[NUM_SEL_SLOW_STRIP_SPEEDS] = { 8000, 16000, 80000, 4000 };
//PSR Fix for - 1-3GKDZ7Q - charting issues with slow speed end
// set some default chart speeds - these don't seem to matter too much as they get over written 
// when the chart queue is setup
UINT CChartQManager::ms_uiChartSpeeds[CQT_NO_OF_QUEUE_TYPES][NUM_CHART_SPEEDS] = { { EzTrendSelectableFastSpeeds[2],
		EzTrendSelectableMedSpeeds[3], EzTrendSelectableSlowSpeeds[1] }, { CirciTrendSelectableFastSpeeds[1],
		CirciTrendSelectableMedSpeeds[3], CirciTrendSelectableSlowSpeeds[2] } };
UINT CChartQManager::ms_uiReplayChartSpeeds[NUM_CHART_SPEEDS] = { 10, 3, 1 }; // CR: 3151 Replay at Faster speed 
// USE THE DEFINE BELOW TO SWITCH BETWEEN THE ORIGINAL CHART SPEEDS (ONE SIZE FITS ALL) AND THE NEW CHART SPEEDS 
// WHICH ARE UNIQUE FOR EACH PRODUCT
#define USE_NEW_CHART_SPEEDS
// use ChartSpeed enum to access:	selectedRate=Speeds[SPEED_FAST] etc.
// The Rates include the speeds above but also have additional levels of zoom (for zooming and analysis)
// NB: be very careful about changing this list!! the index value here is stored in the chart data on SD.
const UINT EzTrendRates[NUM_STRIP_RATES] = { 1, 2, 5, 10, 20, 50, 100, 200, 400, 1000, 2000, 4000, 6000, 12000, 24000,
		60000, 120000, 240000 };
const UINT MultiTrendRates[NUM_STRIP_RATES] = { 1, 2, 5, 10, 20, 50, 100, 300, 600, 1200, 2400, 4000, 8000, 16000,
		24000, 80000, 120000, 240000 };
//PSR Fix for - 1-3GKDZ7Q - charting issues with slow speed begin
const UINT MiniTrendRates[NUM_STRIP_RATES] = { 1, 2, 5, 10, 20, 50, 100, 200, 500, 1000, 2000, 3000, 6000, 12000, 24000,
		60000, 120000, 240000 };
//PSR Fix for - 1-3GKDZ7Q - charting issues with slow speed end
const UINT CirciTrendRates[NUM_CIRC_RATES] = { 50, 100, 200, 800, 1600, 2400, 4800, 9600, 24000, 33600, 67200, 134400 };
////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////
//
// CChartQManager
//
// The CChartQManager manager manages all the data and message Q's used on the charts. 
// All charts share the same Q's. The Data queues are used for writing and reading data to/from SD.
// For a pen there will be 6 data queues, 3 SRAM and 3 volatile. (fast, medium and slow)
// the SRAM 'queues' consist of a single Chartblock, and this in turn contains a single ChartRec in SRAM
// This Chartblock gets reused as each SRAM block is filled, and a new one allocated.
//
// When a new reading (maxmin) is to be added, it is added to the SRAM Q and the volatile Q. 
// When graphing the data the volatile Q is used. 
// Data is also read back from SD at startup and for replay into the volatile Q. The tail block in the 
// volatile Q always contains more than 1 ChartRec of data (i.e. a copy of everything in the SRAM)
//
// Messages are added into SRAM via the MessageListServices. 
// The message queue will receive a copy of each new message as it is added. 
// The message Q is used for graphing the messages. (ALL types of messages in a single Q) 
// Messages read back from SD are put into the message Q, and the tail block will contain all messages in
// SRAM that have not yet been written (as per the data Q).
//
///////////////////////////////////////////////////////////////////////////////////////////////////////
CChartQManager *CChartQManager::m_pChartQManager = NULL;
// There is a limit on the number of blocks that can be requested in one go (QMC_MAX_BLOCKS_ALLOWED_FOR_ONE_REQUEST)
// This was 32 but has now been made larger. Since the block list was 'tuned' using 32, we shall use this size 
// for our maximum requests
//PSR Fix for PAR# 1-3KC14ZV - Circular Chart_Could not plot all data in history mode 
//Changing the RecsPerBlock from 32 to 64 as Circi needs more blocks to represent all data in history 
int Glb_RecsPerBlock = 32; ////		// was QMC_MAX_BLOCKS_ALLOWED_FOR_ONE_REQUEST
int Glb_CirciRecsPerBlock = 64;	////		// was QMC_MAX_BLOCKS_ALLOWED_FOR_ONE_REQUEST
int Glb_MaxCirciQBlocks = 8;	// 8 blocks of size Glb_RecsPerBlock for circular chart
//PSR Fix for PAR# 1-3KC14ZV - Circular Chart_Could not plot all data in history mode 
int Glb_MaxQBlocks = 3;		// 3 blocks of size Glb_RecsPerBlock
int Glb_MaxReplayQBlocks = 8; // 8 blocks of size Glb_RecsPerBlock during replay - (now keeping 2 blocks at the tail)
int Glb_MessagesPerBlock = 50;
int Glb_MaxMsgBlocks = 80;
int Glb_MaxMsg = 4000;
LONGLONG Glb_FirstMessageID = 0;
//****************************************************************************
/// CChartQManager Constructor (private for Singleton)
///
/// @param none
/// 
//****************************************************************************
CChartQManager::CChartQManager() {
	// init the array of pointers to lists
	for (int chartType = 0; chartType < CQT_NO_OF_QUEUE_TYPES; chartType++) {
		for (int i = 0; i < V6_MAX_PENS; i++) {
			for (int j = 0; j < NUM_CHART_SPEEDS; j++) {
				m_QarraySRAM[chartType][i][j] = NULL;
				m_QarrayVolatile[chartType][i][j] = NULL;
			}
		}
	}
	m_TotalBlocks = 0; // total number of blocks for all chart pen lists
	m_ChartMessageQ = NULL;
	m_pIntMessQ = NULL;
	for (int chartQueueType = 0; chartQueueType < CQT_NO_OF_QUEUE_TYPES; chartQueueType++) {
		m_OldestDataTime[chartQueueType][SPEED_FAST].QuadPart = 0;
		m_OldestDataTime[chartQueueType][SPEED_MEDIUM].QuadPart = 0;
		m_OldestDataTime[chartQueueType][SPEED_SLOW].QuadPart = 0;
		m_OldestDataFlag[chartQueueType][SPEED_FAST] = FALSE;
		m_OldestDataFlag[chartQueueType][SPEED_MEDIUM] = FALSE;
		m_OldestDataFlag[chartQueueType][SPEED_SLOW] = FALSE;
	}
	m_Initialised_services = FALSE;
	m_HasNewData = FALSE;
	m_HasNewMessages = FALSE;
	m_Earliest = 0;
	m_Latest = 0;
	m_midtime = 0;
	m_mutex = 0;
	for (int g = 0; g < PEN_GROUP_MAX; g++) {
		m_ChartsPaused[g] = FALSE;
		m_PausedTime[g] = 0;
	}
	m_ChartsStopped = FALSE;
	m_ChartsRestart = FALSE;
	m_ChartsConfigChange = FALSE;
	m_StoppedTime = 0;
}
//****************************************************************************
/// CChartQManager Destructor
///
/// @param none
/// 
//****************************************************************************
CChartQManager::~CChartQManager() {
	// check the list pointers and delete any lists found
	for (int chartType = 0; chartType < CQT_NO_OF_QUEUE_TYPES; chartType++) {
		for (int i = 0; i < V6_MAX_PENS; i++) {
			for (int j = 0; j < NUM_CHART_SPEEDS; j++) {
				if (m_QarraySRAM[chartType][i][j])
					delete m_QarraySRAM[chartType][i][j];
				if (m_QarrayVolatile[chartType][i][j])
					delete m_QarrayVolatile[chartType][i][j];
			}
		}
	}
	if (m_ChartMessageQ)
		delete m_ChartMessageQ;
	if (m_pIntMessQ)
		delete m_pIntMessQ;
}
//****************************************************************************
/// 
///	Clients call this function to get a pointer to the CChartQManager Singleton
///	(there is only one CChartQManager instance and all clients use it)
///
/// @param none
///
/// @return pointer to CChartQManager instance
/// 
//****************************************************************************
CChartQManager* CChartQManager::GetHandle() {
	if (!m_pChartQManager)
		m_pChartQManager = new CChartQManager();
	return m_pChartQManager;
}
//****************************************************************************
/// 
///	Perform initialise later when the rest of the system is up and running.
///
/// @param none
///
/// @return none
/// 
//****************************************************************************
void CChartQManager::Initialise() {
	// set up internal message Queue, used for making SD requests directly for checking start of data
	CQueueManager *pQM = CQueueManager::GetHandle();
	CQMDiskServices &ds = pQM->GetDiskServices();
	if (&ds) {
		int temp = sizeof(T_USRREQSER_USER_MESSAGE_REPLY) + sizeof(CInternalMessage);
		m_pIntMessQ = new CInternalMessageQueue;
		m_pIntMessQ->InitInternalMessageQueue(1, sizeof(T_USRREQSER_USER_MESSAGE_REPLY) + sizeof(CInternalMessage),
				(DWORD) QThread::currentThreadId(), IMQ_USE_EVENT);
		ds.RegisterWithQMDiskServices(USRREQSER_USER_CHART_LOCAL, m_pIntMessQ);
		m_Initialised_services = TRUE;
	}
	// also make the chart message queue now
	if (m_ChartMessageQ == NULL)
		m_ChartMessageQ = new CChartMessageQ(); // not set up yet, so do it now!
	Glb_FirstMessageID = pGlbMsgListSer->GetOldestChartMessageID(); // load from NV
}
//****************************************************************************
/// 
///	Tidy up and call destructor
///
/// @param none
///
/// @return none
/// 
//****************************************************************************
void CChartQManager::CleanUp() {
	if (m_pChartQManager)
		delete m_pChartQManager;
	m_pChartQManager = NULL;
}
//****************************************************************************
/// Checks to see if a queue already exists for the pen at the requested speed
/// and creates one if not. Returns a pointer to the existing/created queue
///
/// @param[in] PenIndex	- Pen Index (zero based)
/// @param[in] fastmedslow	- speed required (fast, medium, slow)
/// @param[in] chartQueueType - the queue type, strip or circular
/// @param[in] IsSRAM		- specifies a 'queue' in SRAM (1 block only)
///							
/// @return pointer to CChartQ
/// 
//****************************************************************************
CChartQ* CChartQManager::AddChartQ(int PenIndex, ChartSpeed fastmedslow, CHART_QUEUE_TYPES chartQueueType,
		BOOL IsSRAM) {
	if (!m_Initialised_services)
		Initialise();
	if (IsSRAM) {
		// see if we already have this SRAM chartQ
		if (m_QarraySRAM[chartQueueType][PenIndex][fastmedslow] != NULL) {
			// we already have this queue - check to see if the rate has changed in the config.
			if (m_QarraySRAM[chartQueueType][PenIndex][fastmedslow]->m_Tpp
					!= ms_uiChartSpeeds[chartQueueType][fastmedslow]) {
				// here the rate for this speed has changed. Need to start filling the blocks at this new rate.
				DeleteChartQ(PenIndex, fastmedslow, chartQueueType, IsSRAM);
			}
		}
		// add it if we don't have it.
		if (m_QarraySRAM[chartQueueType][PenIndex][fastmedslow] == NULL) {
			m_QarraySRAM[chartQueueType][PenIndex][fastmedslow] = new CChartQ(PenIndex, fastmedslow, chartQueueType,
			TRUE); // SRAM constructor
		}
		return m_QarraySRAM[chartQueueType][PenIndex][fastmedslow];
	} else {
		// see if we already have this 'memory' chartQ
		if (m_QarrayVolatile[chartQueueType][PenIndex][fastmedslow] != NULL) {
			// we already have this queue - check to see if the rate has changed in the config.
			if (m_QarrayVolatile[chartQueueType][PenIndex][fastmedslow]->m_Tpp
					!= ms_uiChartSpeeds[chartQueueType][fastmedslow]) {
				// here the rate for this speed has changed. Need to start filling the blocks at this new rate.
				DeleteChartQ(PenIndex, fastmedslow, chartQueueType, IsSRAM);
			}
		}
		// add it if we don't have it
		if (m_QarrayVolatile[chartQueueType][PenIndex][fastmedslow] == NULL) {
			m_QarrayVolatile[chartQueueType][PenIndex][fastmedslow] = new CChartQ(PenIndex, fastmedslow,
					chartQueueType); // normal memory
		}
		return m_QarrayVolatile[chartQueueType][PenIndex][fastmedslow];
	}
}
//****************************************************************************
/// Checks to see if a strip queue already exists for the pen at the requested speed
/// and creates one if not. Returns a pointer to the existing/created queue
///
/// @param[in] PenIndex	- Pen Index (zero based)
/// @param[in] fastmedslow	- speed required (fast, medium, slow)
/// @param[in] IsSRAM		- specifies a 'queue' in SRAM (1 block only)
///							
/// @return pointer to CChartQ
/// 
//****************************************************************************
CChartQ* CChartQManager::AddStripChartQ(int PenZeroBased, ChartSpeed fastmedslow, BOOL IsSRAM /*= FALSE*/) {
	return AddChartQ(PenZeroBased, fastmedslow, CQT_STRIP, IsSRAM);
}
//****************************************************************************
/// Checks to see if a circular queue already exists for the pen at the requested speed
/// and creates one if not. Returns a pointer to the existing/created queue
///
/// @param[in] PenIndex	- Pen Index (zero based)
/// @param[in] fastmedslow	- speed required (fast, medium, slow)
/// @param[in] IsSRAM		- specifies a 'queue' in SRAM (1 block only)
///							
/// @return pointer to CChartQ
/// 
//****************************************************************************
CChartQ* CChartQManager::AddCircularChartQ(int PenZeroBased, ChartSpeed fastmedslow, BOOL IsSRAM /*=FALSE*/) {
	return AddChartQ(PenZeroBased, fastmedslow, CQT_CIRCULAR, IsSRAM);
}
//****************************************************************************
/// Returns a pointer to the specified ChartQ if it exists or NULL if it doesn't
///
/// @param[in] PenIndex	- Pen Index (zero based)
/// @param[in] fastmedslow	- speed required (fast, medium, slow)
/// @param[in] chartQueueType	- the queue type, strip or circular
/// @param[in] IsSRAM		- specifies a 'queue' in SRAM (1 block only)
///							
/// @return pointer to CChartQ
/// 
//****************************************************************************
CChartQ* CChartQManager::GetChartQ(int PenIndex, ChartSpeed fastmedslow, CHART_QUEUE_TYPES chartQueueType,
		BOOL IsSRAM) {
	if (IsSRAM)
		return m_QarraySRAM[chartQueueType][PenIndex][fastmedslow];
	else
		return m_QarrayVolatile[chartQueueType][PenIndex][fastmedslow];
}
//****************************************************************************
/// Returns a pointer to the specified strip ChartQ if it exists or NULL if it doesn't
///
/// @param[in] PenIndex	- Pen Index (zero based)
/// @param[in] fastmedslow	- speed required (fast, medium, slow)
/// @param[in] IsSRAM		- specifies a 'queue' in SRAM (1 block only)
///							
/// @return pointer to CChartQ
/// 
//****************************************************************************
CChartQ* CChartQManager::GetStripChartQ(int PenZeroBased, ChartSpeed fastmedslow, BOOL IsSRAM /*=FALSE*/) {
	return GetChartQ(PenZeroBased, fastmedslow, CQT_STRIP, IsSRAM);
}
//****************************************************************************
/// Returns a pointer to the specified circular ChartQ if it exists or NULL if it doesn't
///
/// @param[in] PenIndex	- Pen Index (zero based)
/// @param[in] fastmedslow	- speed required (fast, medium, slow)
/// @param[in] IsSRAM		- specifies a 'queue' in SRAM (1 block only)
///							
/// @return pointer to CChartQ
/// 
//****************************************************************************
CChartQ* CChartQManager::GetCircularChartQ(int PenZeroBased, ChartSpeed fastmedslow, BOOL IsSRAM /*=FALSE*/) {
	return GetChartQ(PenZeroBased, fastmedslow, CQT_CIRCULAR, IsSRAM);
}
//****************************************************************************
/// Checks to see if a queue exists for the pen at the requested speed
/// and deletes it if found
///
/// @param[in] PenIndex	- Pen Index (zero based)
/// @param[in] fastmedslow	- speed required (fast, medium, slow)
/// @param[in] queueType	- the queue type, strip or circular
/// @param[in] IsSRAM		- specifies a 'queue' in SRAM (1 block only)
///							
/// @return none
/// 
//****************************************************************************
void CChartQManager::DeleteChartQ(int PenIndex, ChartSpeed fastmedslow, CHART_QUEUE_TYPES chartQueueType, BOOL IsSRAM) {
	if (IsSRAM) {
		if (m_QarraySRAM[chartQueueType][PenIndex][fastmedslow]) {
			CQueueManager *pQM = CQueueManager::GetHandle();
			CQMBlockServices &bs = pQM->GetBlockServices();
			bs.ResetQueue(m_QarraySRAM[chartQueueType][PenIndex][fastmedslow]->m_QHandle); // flush blocks to 'todisk' Q
			delete m_QarraySRAM[chartQueueType][PenIndex][fastmedslow];
			m_QarraySRAM[chartQueueType][PenIndex][fastmedslow] = NULL;
		}
	} else {
		if (m_QarrayVolatile[PenIndex][fastmedslow]) {
			delete m_QarrayVolatile[chartQueueType][PenIndex][fastmedslow];
			m_QarrayVolatile[chartQueueType][PenIndex][fastmedslow] = NULL;
		}
	}
}
//****************************************************************************
/// Checks to see if a strip queue exists for the pen at the requested speed
/// and deletes it if found
///
/// @param[in] PenIndex	- Pen Index (zero based)
/// @param[in] fastmedslow	- speed required (fast, medium, slow)
/// @param[in] IsSRAM		- specifies a 'queue' in SRAM (1 block only)
///							
/// @return none
/// 
//****************************************************************************
void CChartQManager::DeleteStripChartQ(int PenZeroBased, ChartSpeed fastmedslow, BOOL IsSRAM /*=FALSE*/) {
	DeleteChartQ(PenZeroBased, fastmedslow, CQT_STRIP, IsSRAM);
}
//****************************************************************************
/// Checks to see if a circular queue exists for the pen at the requested speed
/// and deletes it if found
///
/// @param[in] PenIndex	- Pen Index (zero based)
/// @param[in] fastmedslow	- speed required (fast, medium, slow)
/// @param[in] IsSRAM		- specifies a 'queue' in SRAM (1 block only)
///							
/// @return none
/// 
//****************************************************************************
void CChartQManager::DeleteCircularChartQ(int PenZeroBased, ChartSpeed fastmedslow, BOOL IsSRAM /*=FALSE*/) {
	DeleteChartQ(PenZeroBased, fastmedslow, CQT_CIRCULAR, IsSRAM);
}
//****************************************************************************
/// Adds a reading into all the exisiting ChartQ's for the pen
///
/// @param[in] PenIndex		- Pen Index (zero based)
/// @param[in] value			- reading to add
/// 
/// @return none
/// 
//****************************************************************************
void CChartQManager::AddReading(int PenIndex, float value) {
	// adds the reading to all Queues at all rates (where Q's exist)
	LONGLONG processTime100 = pGlbSysTimer->GetOnGoingProcessTick();
	if (!m_ChartsStopped) {
		// normal running here
		for (int j = 0; j < NUM_CHART_SPEEDS; j++) {
			for (int chartQueueType = 0; chartQueueType < CQT_NO_OF_QUEUE_TYPES; chartQueueType++) {
				// add to SRAM version first (most important!)
				if (m_QarraySRAM[chartQueueType][PenIndex][j]) {
					m_QarraySRAM[chartQueueType][PenIndex][j]->AddReading(value, processTime100);
				}
				// add then to memory based volatile queue
				if (m_QarrayVolatile[chartQueueType][PenIndex][j]) {
					//qDebug("CM->AddReading Vlolatile P%d %f %I64d \n", PenIndex,value, processTime100);
					m_QarrayVolatile[chartQueueType][PenIndex][j]->AddReading(value, processTime100);
				}
			}
		}
	} else {
		// Charts are stopped - see if we need to restart yet
		if (m_ChartsRestart) {
			// here about to restart - do this once for the first valid pen to get here after m_ChartsRestart set
			LONGLONG adjustTime100 = processTime100 - m_StoppedTime; // how much to adjust by
			//if( adjustTime100 < 0 ) adjustTime100 = 0;
			pGlbSysTimer->SetOnGoingProcessTick(m_StoppedTime); // make the adjustment
			pGlbSysTimer->m_baseOngoingTick -= adjustTime100; // need to adjust by the same amount here
			CTimeHistory *pTh = CTimeHistory::GetHandle();
			CTVtime now;
			now = pGlbSysTimer->GetCurrentProcessTimeRef();
			pTh->AddEntry(m_StoppedTime, now); // add a new entry to the time history file
			m_ChartsRestart = FALSE;
			m_ChartsStopped = FALSE;
			::PostMessage(AfxGetMainWnd()->m_hWnd, WM_OPPANEL_RECONFIGCHARTS, 0, 0); // post this to ensure all charts reconfigure then 'un-pause'
		} else {
			// here cater for chart speed change whilst stopped - may need to see volatile Q we haven't seen before
			for (int j = 0; j < NUM_CHART_SPEEDS; j++) {
				for (int chartQueueType = 0; chartQueueType < CQT_NO_OF_QUEUE_TYPES; chartQueueType++) {
					// see if we need to init a volatile Q
					if (m_QarrayVolatile[chartQueueType][PenIndex][j]) {
						if ((m_QarrayVolatile[chartQueueType][PenIndex][j]->m_NeedsInit)
								&& (!m_QarrayVolatile[chartQueueType][PenIndex][j]->m_FirstInitDone)) {
							//qDebug("CM->AddReading time not important for Vlolatile P%d %f \n", PenIndex, value);
							m_QarrayVolatile[chartQueueType][PenIndex][j]->Init(0); // time not important for volatile Q
						}
					}
				}
			}
		}
	}
	//Unlock();
}
//****************************************************************************
/// Adds a message into the exisiting message Q for the charts
///
/// @param[in] msg		- message to add
/// 
/// @return none
/// 
//****************************************************************************
void CChartQManager::AddMessage(T_MSGLISTSER_MESSAGE *msg) {
	// CR3132 - Comment WaitLock Function, and use newly declared critical section object for AddMessage function.
	//WaitLock(2);
	m_critsecMsg.lock();
	// see if this is all up and running yet.
	if (!m_Initialised_services)
		Initialise(); // will create chart message queue if not yet done
	m_ChartMessageQ->AddMessage(msg);
	// CR3132 - Comment UnLock function, and use newly declared critical section object for AddMessage functiojn.
	//	Unlock();
	m_critsecMsg.lock();
}
//****************************************************************************
/// Data update message received. Update the correct memory based Q
///
/// @param[in] message	- the structure containing the message data
/// 
/// @return none
/// 
//****************************************************************************
void CChartQManager::DataUpdate(const CInternalMessage *message) {
	WaitLock(3);
	T_USRREQSER_USER_MESSAGE_REPLY *pReply = (T_USRREQSER_USER_MESSAGE_REPLY*) message->m_MsgData;
	//qDebug("QUEUE HANDLE Reply %d\n",pReply->hQueue);
	// ok, decode the Queue handle...
	// is it a reply with messageQ data?
	if (pReply->hQueue >= MESSAGE_LIST_QUEUE_START_ID) {
		// yes it is. here ensure we set messtype for our range (NUM_CHART_MESSAGE_Qs)
		for (int i = 0; i < NUM_CHART_MESSAGE_Qs; i++) {
			if (m_ChartMessageQ->m_RequestInfo[i].m_QHandle == pReply->hQueue) {
				m_ChartMessageQ->DataUpdate(pReply, i);
				break;
			}
		}
	} else if (pReply->hQueue > 0) {
		int instance = pReply->hQueue / QMC_TOTAL_NO_OF_QUEUES_PER_PEN;
		T_QMC_QUEUE_TYPE queueType = (T_QMC_QUEUE_TYPE) (pReply->hQueue % QMC_TOTAL_NO_OF_QUEUES_PER_PEN);
		if (queueType < QMC_QUEUE_PEN_SCR_CIRC_SLOW) {
			int speed = QMC_QUEUE_PEN_SCR_FAST - queueType;
			// check it's a valid speed
			if ((speed < NUM_CHART_SPEEDS) && m_QarrayVolatile[CQT_STRIP][instance][speed]) {
				m_QarrayVolatile[CQT_STRIP][instance][speed]->DataUpdate(pReply);
			}
		} else {
			int speed = QMC_QUEUE_PEN_SCR_CIRC_FAST - queueType;
			// check it's a valid speed
			if ((speed < NUM_CHART_SPEEDS) && m_QarrayVolatile[CQT_CIRCULAR][instance][speed]) {
				m_QarrayVolatile[CQT_CIRCULAR][instance][speed]->DataUpdate(pReply);
			}
		}
	}
	Unlock();
}
//****************************************************************************
///	Ensure all memory queues are in Normal mode (not replay)
///
/// @param none
/// @return none
/// 
//****************************************************************************
void CChartQManager::SetNormalMode() {
	WaitLock(3);
	for (int chartQueueType = 0; chartQueueType < CQT_NO_OF_QUEUE_TYPES; chartQueueType++) {
		for (int i = 0; i < V6_MAX_PENS; i++) {
			for (int j = 0; j < NUM_CHART_SPEEDS; j++) {
				if (m_QarrayVolatile[chartQueueType][i][j]) {
					m_QarrayVolatile[chartQueueType][i][j]->m_ReplayUsage =
					FALSE;
					m_QarrayVolatile[chartQueueType][i][j]->m_DrawingTpp =
							m_QarrayVolatile[chartQueueType][i][j]->m_Tpp; // set the drawing tpp for the queue to it's Q tpp
					m_QarrayVolatile[chartQueueType][i][j]->RecoverMemoryBlocks();
				}
			}
		}
	}
	m_ChartMessageQ->m_ReplayUsage = FALSE;
	Unlock();
}
//****************************************************************************
/// Delete the contents of all Queues, without flushing. Then restart again 
///
/// @param[in] prefillRequired - optional prefill afterwards
///
/// @return none
/// 
//****************************************************************************
void CChartQManager::EmptyQueues(BOOL prefillRequired) //=FALSE;
		{
	if (m_ChartsStopped)
		return;  // ignore if we are presently stopped
	WaitLock(0);
	CQueueManager *pQM = CQueueManager::GetHandle();
	CQMDiskServices &ds = pQM->GetDiskServices();
	ds.FlushDataBlocksToPhysicalDisk(); // ensure all the blocks in the "to-disk-Q" go to disk.
	pQM->ClearChartBlocks(); // reset all SD files and everything
	// clear the flags to reset the oldest times per queue
	for (int chartQueueType = 0; chartQueueType < CQT_NO_OF_QUEUE_TYPES; chartQueueType++) {
		m_OldestDataFlag[chartQueueType][SPEED_FAST] = FALSE;
		m_OldestDataFlag[chartQueueType][SPEED_MEDIUM] = FALSE;
		m_OldestDataFlag[chartQueueType][SPEED_SLOW] = FALSE;
	}
	Glb_FirstMessageID = pGlbSysTimer->GetHighResOnGoingTick100() << 16; // set the SRAM time (shfted to make an ID) (don't use messages before this_)
	pGlbMsgListSer->SetOldestChartMessageID(Glb_FirstMessageID); // save to NV
	for (int chartQueueType = 0; chartQueueType < CQT_NO_OF_QUEUE_TYPES; chartQueueType++) {
		for (int i = 0; i < V6_MAX_PENS; i++) {
			for (int j = 0; j < NUM_CHART_SPEEDS; j++) {
				if (m_QarraySRAM[chartQueueType][i][j]) {
					// SRAM 'q' exists (only ever 1 block in queue which get's reused)
					m_QarraySRAM[chartQueueType][i][j]->DeleteContents(); // may be no block at all (can be none if pen not 'running')
					m_QarraySRAM[chartQueueType][i][j]->m_lastWriteTime -= m_QarraySRAM[chartQueueType][i][j]->m_Tpp;
					m_QarraySRAM[chartQueueType][i][j]->m_MaxMin.ResetMaxMin();
					m_QarraySRAM[chartQueueType][i][j]->AddBlock();	// get a new block and start again.
					m_QarraySRAM[chartQueueType][i][j]->m_NeedsPrefill = prefillRequired; //set here for when a volatile Q gets added
				}
				if (m_QarrayVolatile[chartQueueType][i][j]) {
					m_QarrayVolatile[chartQueueType][i][j]->DeleteContents(); // deletes all
					m_QarrayVolatile[chartQueueType][i][j]->m_NeedsInit = TRUE; // will init on next reading added.
					m_QarrayVolatile[chartQueueType][i][j]->m_FirstInitDone = FALSE; // ...treat as first time.
					//Enable the flag that clear screen is triggered on this queue
					//Ensure to operate only on strip chart and only when NO prefill required
					if ((!prefillRequired) && (CQT_STRIP == chartQueueType)) {
						m_QarrayVolatile[chartQueueType][i][j]->m_bIsClearQTriggered = true;
					}
				}
			}
		}
	}
	m_TotalBlocks = 0; // total number of blocks for all lists
	// message Q
	m_ChartMessageQ->DeleteContents();
	m_ChartMessageQ->DefaultSettings(); // return settings to defaults
	//qDebug("CM::EmptyQueues NeedsPrefill:%d\n", prefillRequired);
	Unlock();
	if (!prefillRequired) {
		QString strMessage("");
		strMessage = QWidget::tr("Chart control - Clear");
		LOG_USER_MESSAGE(MSGLISTSER_USER_GROUP_CHART_CONTROL_CLEAR, strMessage);
	}
}
//****************************************************************************
/// Prefill Queues (after emptying them)
///
/// @param none
/// @return none
///
//****************************************************************************
void CChartQManager::PrefillQueues() {
	EmptyQueues(TRUE); // empty and prefill.
	QString strMessage("");
	strMessage = QWidget::tr("Chart control - Prefill");
	LOG_USER_MESSAGE(MSGLISTSER_USER_GROUP_CHART_CONTROL_PREFILL, strMessage);
}
//****************************************************************************
/// Function to Restart after a chart stopped.
///
/// @param none
/// @return none
///
//****************************************************************************
void CChartQManager::Restart() {
	CQueueManager *pQM = CQueueManager::GetHandle();
	CQMBlockServices &bs = pQM->GetBlockServices();
	CQMDiskServices &ds = pQM->GetDiskServices();
	for (int chartQueueType = 0; chartQueueType < CQT_NO_OF_QUEUE_TYPES; chartQueueType++) {
		for (int i = 0; i < V6_MAX_PENS; i++) {
			for (int j = 0; j < NUM_CHART_SPEEDS; j++) {
				if (m_QarraySRAM[chartQueueType][i][j]) {
					// SRAM 'q' exists (only ever 1 block in queue which get's reused)
					m_QarraySRAM[chartQueueType][i][j]->DeleteContents(); // may be no block at all (can be none if pen not 'running')
					// lastWrite time will be correct from before.
					m_QarraySRAM[chartQueueType][i][j]->m_lastWriteTime -= m_QarraySRAM[chartQueueType][i][j]->m_Tpp;
					m_QarraySRAM[chartQueueType][i][j]->m_MaxMin.ResetMaxMin();
					m_QarraySRAM[chartQueueType][i][j]->AddBlock();
				}
				if (m_QarrayVolatile[chartQueueType][i][j]) {
					m_QarrayVolatile[chartQueueType][i][j]->m_NeedsInit = TRUE; // will reinit on next reading added.
				}
			}
		}
	}
	ds.FlushDataBlocksToPhysicalDisk(); // then ensure all the blocks in the "to-disk-Q" go to disk.
}
//****************************************************************************
/// Function pause all charts
///
/// @param		const USHORT usGROUP_NO - The one-based group number this was relevant to
/// @return none
///
//****************************************************************************
void CChartQManager::PauseCharts(const USHORT usGROUP_NO) {
	WaitLock(0);
	if (!m_ChartsPaused[usGROUP_NO]) {
		m_ChartsPaused[usGROUP_NO] = TRUE;
		if (pGlbSysTimer)
			m_PausedTime[usGROUP_NO] = pGlbSysTimer->GetHighResOnGoingTick100();
		QString strMessage("");
		strMessage = QWidget::tr("Chart control - Pause");
		LOG_BATCH_MESSAGE(MSGLISTSER_USER_GROUP_CHART_CONTROL_PAUSE, strMessage, static_cast<T_PEN_GROUPS>(usGROUP_NO));
	}
	Unlock();
}
//****************************************************************************
/// Function stop all charts
///
/// @param	none
/// @return none
///
//****************************************************************************
void CChartQManager::StopCharts(BOOL ShowMsg) {
	// CR3132 - Comment WaitLock and use m_critsec CRITICAL SECTION object instead.
	//WaitLock(0);
	m_critsec.lock();
	if (!m_ChartsStopped) {
		m_ChartsStopped = TRUE;
		m_ChartsPaused[PEN_GROUP_NONE] = TRUE; // global pause all charts flag
		if (pGlbSysTimer) {
			m_PausedTime[PEN_GROUP_NONE] = pGlbSysTimer->GetHighResOnGoingTick100();
			m_StoppedTime = pGlbSysTimer->GetOnGoingProcessTick();
		}
		QString strMessage("");
		strMessage = QWidget::tr("Chart control - Stop");
		//Added by nilesh for Displaying Chart Start/Stop Messages
		//[
		if (ShowMsg) {
			LOG_USER_MESSAGE(MSGLISTSER_USER_GROUP_CHART_CONTROL_STOP, strMessage);
		}
		//]
	}
	// CR3132 - Comment UnLock and use m_critsec CRITICAL SECTION object instead.
	//Unlock();
	m_critsec.lock();
}
//****************************************************************************
/// Function resume all charts, after a pause or a stop.
///
/// @param		const USHORT usGROUP_NO - The one-based group number this was relevant to
/// @return none
///
//****************************************************************************
void CChartQManager::ResumeCharts(const USHORT usGROUP_NO) {
	// resume - are we stopped or paused?
	WaitLock(0);
	if (m_ChartsStopped) {
		Restart();
		m_ChartsRestart = TRUE;
	} else {
		if (m_ChartsPaused[usGROUP_NO]) {
			m_ChartsPaused[usGROUP_NO] = FALSE;
			QString strMessage("");
			strMessage = QWidget::tr("Chart control - Resume");
			LOG_BATCH_MESSAGE(MSGLISTSER_USER_GROUP_CHART_CONTROL_RESUME, strMessage,
					static_cast<T_PEN_GROUPS>(usGROUP_NO));
		}
	}
	Unlock();
}
//****************************************************************************
/// Called to set a flag before refreshing the charts after a resume (stop only)
///
/// @param none
/// @return none
///
//****************************************************************************
void CChartQManager::ReadyCharts() {
	m_ChartsConfigChange = TRUE;
}
//****************************************************************************
/// Called after refreshing the charts after a resume (stop only)
///
/// @param none
/// @return none
///
//****************************************************************************
void CChartQManager::DoneCharts(BOOL ShowMsg) {
	m_ChartsConfigChange = FALSE;
	m_ChartsPaused[PEN_GROUP_NONE] = FALSE;
	QString strMessage("");
	strMessage = QWidget::tr("Chart control - Resume");
	//added by nilesh for Displaying Chart Start/Stop Messages
	//[
	if (ShowMsg) {
		LOG_USER_MESSAGE(MSGLISTSER_USER_GROUP_CHART_CONTROL_RESUME, strMessage);
	}
	//]
}
//****************************************************************************
/// convert rate to index (utility function)
///
/// @param eCHART_QUEUE_TYPE
/// @param rate
///	@returns index
///
//****************************************************************************
BYTE CChartQManager::RateToIndex(const CHART_QUEUE_TYPES eCHART_QUEUE_TYPE, UINT rate) {
	int i = 0;
	if (eCHART_QUEUE_TYPE == CQT_STRIP) {
		for (i = 0; i < NUM_STRIP_RATES; i++) {
#ifdef USE_NEW_CHART_SPEEDS
			if ( pDALGLB->IsRecorderMulti()) {
				if (MultiTrendRates[i] == rate) {
					return i;
				}
			} else if ( pDALGLB->IsRecorderMini()) {
				if (MiniTrendRates[i] == rate) {
					return i;
				}
			} else {
				if (EzTrendRates[i] == rate) {
					return i;
				}
			}
#else
    if(EzTrendRates[i]==rate)
    {
      return i;
    }
#endif
		}
	} else if (eCHART_QUEUE_TYPE == CQT_CIRCULAR) {
		for (int rateIndex = 0; rateIndex < NUM_CIRC_RATES; rateIndex++) {
			if (CirciTrendRates[rateIndex] == rate) {
				return rateIndex;
			}
		}
	}
	return i - 1; // return last in list.
}
//****************************************************************************
/// convert rate to index (utility function)
///
/// @param rate
///	@returns index
///
//****************************************************************************
UINT CChartQManager::GetRateAtIndex(const CHART_QUEUE_TYPES eCHART_QUEUE_TYPE, UINT index) {
	if (eCHART_QUEUE_TYPE == CQT_STRIP) {
		//PSR Fix for - 1-3GKDZ7Q - charting issues with slow speed begin
		if (index >= NUM_STRIP_RATES) {
			index = NUM_STRIP_RATES - 1;
		}
		//PSR Fix for - 1-3GKDZ7Q - charting issues with slow speed end
#ifdef USE_NEW_CHART_SPEEDS
		if ( pDALGLB->IsRecorderMulti()) {
			return MultiTrendRates[index];
		}
		//PSR Fix for - 1-3GKDZ7Q - charting issues with slow speed begin
		else if ( pDALGLB->IsRecorderMini()) {
			return MiniTrendRates[index];
		}
		//PSR Fix for - 1-3GKDZ7Q - charting issues with slow speed end
#endif
		return EzTrendRates[index];
	} else if (eCHART_QUEUE_TYPE == CQT_CIRCULAR) {
		if (index >= NUM_CIRC_RATES) {
			index = NUM_CIRC_RATES - 1;
		}
		return CirciTrendRates[index];
	}
	// default fall back position - should never happen
	return EzTrendRates[index];
}
//****************************************************************************
/// Get the oldest times of data in the queues for fast, medium and slow for the specified chart type
///
/// @param
///	@returns none
///
//****************************************************************************
void CChartQManager::GetOldestTimes(LONGLONG *oldestFast, LONGLONG *oldestMedium, LONGLONG *oldestSlow,
		CHART_QUEUE_TYPES chartQueueType) {
	int q = 0;
	if (m_OldestDataFlag[chartQueueType][SPEED_FAST] == FALSE) {
		for (; q < V6_MAX_PENS; q++)  // find first SRAM Q in existance
				{
			if (m_QarraySRAM[chartQueueType][q][SPEED_FAST]) {
				m_QarraySRAM[chartQueueType][q][SPEED_FAST]->UpdateOldestTime(chartQueueType);
				break;
			}
		}
	}
	*oldestFast = m_OldestDataTime[chartQueueType][SPEED_FAST].QuadPart;
	if (m_OldestDataFlag[chartQueueType][SPEED_MEDIUM] == FALSE) {
		for (; q < V6_MAX_PENS; q++)  // find first SRAM Q in existance
				{
			if (m_QarraySRAM[chartQueueType][q][SPEED_MEDIUM]) {
				m_QarraySRAM[chartQueueType][q][SPEED_MEDIUM]->UpdateOldestTime(chartQueueType);
				break;
			}
		}
	}
	*oldestMedium = m_OldestDataTime[chartQueueType][SPEED_MEDIUM].QuadPart;
	if (m_OldestDataFlag[chartQueueType][SPEED_SLOW] == FALSE) {
		for (; q < V6_MAX_PENS; q++)  // find first SRAM Q in existance
				{
			if (m_QarraySRAM[chartQueueType][q][SPEED_SLOW]) {
				m_QarraySRAM[chartQueueType][q][SPEED_SLOW]->UpdateOldestTime(chartQueueType);
				break;
			}
		}
	}
	*oldestSlow = m_OldestDataTime[chartQueueType][SPEED_SLOW].QuadPart;
}
//****************************************************************************
//	void SetChartSpeed( const USHORT usSPEED, const ChartSpeed eSPEED_TYPE  )
///
/// Accessor for getting and setting the various chart speeds
///
/// @param[in]  const CHART_QUEUE_TYPE eCHART_QUEUE_TYPE - the type of chart queue i.e. circular or strip chart
/// @param[in]	const USHORT usSPEED -
/// @param[in]	const ChartSpeed eSPEED_TYPE - Enum equating to the speed being modified
///
//****************************************************************************
void CChartQManager::SetChartSpeed(const CHART_QUEUE_TYPES eCHART_QUEUE_TYPE, const USHORT usSPEED,
		const ChartSpeed eSPEED_TYPE) {
	if (eCHART_QUEUE_TYPE == CQT_STRIP) {
		switch (eSPEED_TYPE) {
		case SPEED_FAST:
#ifndef USE_NEW_CHART_SPEEDS
    ms_uiChartSpeeds[eCHART_QUEUE_TYPE][ eSPEED_TYPE] = EzTrendSelectableFastSpeeds[ ( usSPEED < NUM_SEL_FAST_STRIP_SPEEDS )?usSPEED:0 ];
#else
			if ( pDALGLB->IsRecorderMini()) {
				ms_uiChartSpeeds[eCHART_QUEUE_TYPE][eSPEED_TYPE] = MiniTrendSelectableFastSpeeds[
						(usSPEED < NUM_SEL_FAST_STRIP_SPEEDS) ? usSPEED : 0];
			} else if ( pDALGLB->IsRecorderMulti()) {
				ms_uiChartSpeeds[eCHART_QUEUE_TYPE][eSPEED_TYPE] = MultiTrendSelectableFastSpeeds[
						(usSPEED < NUM_SEL_FAST_STRIP_SPEEDS) ? usSPEED : 0];
			} else {
				ms_uiChartSpeeds[eCHART_QUEUE_TYPE][eSPEED_TYPE] = EzTrendSelectableFastSpeeds[
						(usSPEED < NUM_SEL_FAST_STRIP_SPEEDS) ? usSPEED : 0];
			}
#endif
			break;
		case SPEED_MEDIUM:
#ifndef USE_NEW_CHART_SPEEDS
    ms_uiChartSpeeds[eCHART_QUEUE_TYPE][ eSPEED_TYPE] = EzTrendSelectableMedSpeeds[ ( usSPEED < NUM_SEL_MED_STRIP_SPEEDS )?usSPEED:0 ];
#else
			if ( pDALGLB->IsRecorderMini()) {
				ms_uiChartSpeeds[eCHART_QUEUE_TYPE][eSPEED_TYPE] = MiniTrendSelectableMedSpeeds[
						(usSPEED < NUM_SEL_MED_STRIP_SPEEDS) ? usSPEED : 0];
			} else if ( pDALGLB->IsRecorderMulti()) {
				ms_uiChartSpeeds[eCHART_QUEUE_TYPE][eSPEED_TYPE] = MultiTrendSelectableMedSpeeds[
						(usSPEED < NUM_SEL_MED_STRIP_SPEEDS) ? usSPEED : 0];
			} else {
				ms_uiChartSpeeds[eCHART_QUEUE_TYPE][eSPEED_TYPE] = EzTrendSelectableMedSpeeds[
						(usSPEED < NUM_SEL_MED_STRIP_SPEEDS) ? usSPEED : 0];
			}
#endif
			break;
		case SPEED_SLOW:
#ifndef USE_NEW_CHART_SPEEDS
    ms_uiChartSpeeds[eCHART_QUEUE_TYPE][ eSPEED_TYPE] = EzTrendSelectableSlowSpeeds[ ( usSPEED < NUM_SEL_SLOW_STRIP_SPEEDS )?usSPEED:0 ];
#else
			if ( pDALGLB->IsRecorderMini()) {
				ms_uiChartSpeeds[eCHART_QUEUE_TYPE][eSPEED_TYPE] = MiniTrendSelectableSlowSpeeds[
						(usSPEED < NUM_SEL_SLOW_STRIP_SPEEDS) ? usSPEED : 0];
			} else if ( pDALGLB->IsRecorderMulti()) {
				ms_uiChartSpeeds[eCHART_QUEUE_TYPE][eSPEED_TYPE] = MultiTrendSelectableSlowSpeeds[
						(usSPEED < NUM_SEL_SLOW_STRIP_SPEEDS) ? usSPEED : 0];
			} else {
				ms_uiChartSpeeds[eCHART_QUEUE_TYPE][eSPEED_TYPE] = EzTrendSelectableSlowSpeeds[
						(usSPEED < NUM_SEL_SLOW_STRIP_SPEEDS) ? usSPEED : 0];
			}
#endif
			break;
		}
	} else if (eCHART_QUEUE_TYPE == CQT_CIRCULAR) {
		switch (eSPEED_TYPE) {
		case SPEED_FAST:
			ms_uiChartSpeeds[eCHART_QUEUE_TYPE][eSPEED_TYPE] = CirciTrendSelectableFastSpeeds[
					(usSPEED < NUM_SEL_FAST_CIRC_SPEEDS) ? usSPEED : 0];
			break;
		case SPEED_MEDIUM:
			ms_uiChartSpeeds[eCHART_QUEUE_TYPE][eSPEED_TYPE] = CirciTrendSelectableMedSpeeds[
					(usSPEED < NUM_SEL_MED_CIRC_SPEEDS) ? usSPEED : 0];
			break;
		case SPEED_SLOW:
			ms_uiChartSpeeds[eCHART_QUEUE_TYPE][eSPEED_TYPE] = CirciTrendSelectableSlowSpeeds[
					(usSPEED < NUM_SEL_SLOW_CIRC_SPEEDS) ? usSPEED : 0];
			break;
		}
	}
}
///////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  CChartQ
//
///////////////////////////////////////////////////////////////////////////////////////////////////////
//****************************************************************************
/// CChartQ Constructor (for SRAM 'Q')
///
/// @param[in] PenIndex	- Pen Index (zero based)
/// @param[in] fastmedslow	- speed required (fast, medium, slow)
/// @param[in] chartQueueType - the chart queue type - strip or circular
///
//****************************************************************************
CChartQ::CChartQ(int PenIndex, ChartSpeed fastmedslow, CHART_QUEUE_TYPES chartQueueType, BOOL IsSRAM) {
	m_PenIndex = PenIndex;
	m_pHead = NULL;
	m_pTail = NULL;
	m_FirstInitDone = FALSE;
	m_NeedsInit = TRUE;
	m_NeedsPrefill = FALSE;
	m_NumBlocks = 0;
	m_IsSRAM = TRUE;  // SRAM Q
	m_QHandle = 0;
	m_OutstandingRequest = FALSE;
	m_InitialRequest = FALSE;
	m_ReplayUsage = FALSE;
	m_pRequestblock = NULL;
	m_pOldRequestblock = NULL;
	m_chartQueueType = chartQueueType;
	m_Tpp = CChartQManager::GetChartSpeed(m_chartQueueType, fastmedslow);
	m_DrawingTpp = m_Tpp; // doesn't really apply for SRAM queues. (not graphed)
	m_rateIndex = CChartQManager::RateToIndex(m_chartQueueType, m_Tpp);  // set the index from the Tpp.
	m_fastmedslow = fastmedslow;
	if (chartQueueType == CQT_STRIP) {
		if (m_fastmedslow == SPEED_FAST) {
			m_QueueType = QMC_QUEUE_PEN_SCR_FAST;
		} else if (m_fastmedslow == SPEED_MEDIUM) {
			m_QueueType = QMC_QUEUE_PEN_SCR_MEDIUM;
		} else {
			m_QueueType = QMC_QUEUE_PEN_SCR_SLOW;
		}
	} else if (chartQueueType == CQT_CIRCULAR) {
		if (m_fastmedslow == SPEED_FAST) {
			m_QueueType = QMC_QUEUE_PEN_SCR_CIRC_FAST;
		} else if (m_fastmedslow == SPEED_MEDIUM) {
			m_QueueType = QMC_QUEUE_PEN_SCR_CIRC_MEDIUM;
		} else {
			m_QueueType = QMC_QUEUE_PEN_SCR_CIRC_SLOW;
		}
	}
	CQueueManager *pQM = CQueueManager::GetHandle();
	CQMBlockServices &bs = pQM->GetBlockServices();
	// Get a Handle to a specified Queue based on queue type and instance number
	if (bs.GetQueue(m_QueueType, m_PenIndex, m_QHandle) == QMBLKSER_PERSISTED_QUEUE_NOT_SETUP)
		bs.SetupQueue(m_QHandle, m_QueueType, 1, QMC_CONFIRMATION_NOT_REQUIRED);
}
//****************************************************************************
/// CChartQ Constructor (volatile queues)
///
/// @param[in] PenIndex	- Pen Index (zero based)
/// @param[in] fastmedslow	- speed required (fast, medium, slow)
/// @param[in] chartQueueType - the chart queue type - strip or circular
///
//****************************************************************************
CChartQ::CChartQ(int PenIndex, ChartSpeed fastmedslow, CHART_QUEUE_TYPES chartQueueType) {
	m_PenIndex = PenIndex;
	m_pHead = NULL;
	m_pTail = NULL;
	m_FirstInitDone = FALSE;
	m_NeedsInit = TRUE;
	m_NeedsPrefill = FALSE;
	m_NumBlocks = 0;
	m_IsSRAM = FALSE; // volatile
	m_QHandle = 0;
	m_OutstandingRequest = FALSE;
	m_InitialRequest = FALSE;
	m_ReplayUsage = FALSE;
	m_pRequestblock = NULL;
	m_pOldRequestblock = NULL;
	m_chartQueueType = chartQueueType;
	m_Tpp = CChartQManager::GetChartSpeed(m_chartQueueType, fastmedslow);
	m_DrawingTpp = m_Tpp;			// Set this the same initially. May get set to some other value when in replay mode.
	m_rateIndex = CChartQManager::RateToIndex(m_chartQueueType, m_Tpp);  // set the index from the Tpp.
	m_fastmedslow = fastmedslow;
	m_bIsClearQTriggered = false;
	if (chartQueueType == CQT_STRIP) {
		if (m_fastmedslow == SPEED_FAST) {
			m_QueueType = QMC_QUEUE_PEN_SCR_FAST;
		} else if (m_fastmedslow == SPEED_MEDIUM) {
			m_QueueType = QMC_QUEUE_PEN_SCR_MEDIUM;
		} else {
			m_QueueType = QMC_QUEUE_PEN_SCR_SLOW;
		}
	} else if (chartQueueType == CQT_CIRCULAR) {
		if (m_fastmedslow == SPEED_FAST) {
			m_QueueType = QMC_QUEUE_PEN_SCR_CIRC_FAST;
		} else if (m_fastmedslow == SPEED_MEDIUM) {
			m_QueueType = QMC_QUEUE_PEN_SCR_CIRC_MEDIUM;
		} else {
			m_QueueType = QMC_QUEUE_PEN_SCR_CIRC_SLOW;
		}
	}
	// for the volatile chart Q's, we associate with one or more disk based queues.
	// using data from perhaps all three to reconstruct a pen's data in memory.
	CQueueManager *pQM = CQueueManager::GetHandle();
	CQMBlockServices &bs = pQM->GetBlockServices();
	// Get a Handle to a specified Queue based on queue type and instance number
	bs.GetQueue(m_QueueType, m_PenIndex, m_QHandle); // set up the m_QHandle
}
//****************************************************************************
/// CChartQ Destructor
///
/// @param none
///
//****************************************************************************
CChartQ::~CChartQ() {
	// delete all queue blocks
	DeleteContents();
}
//****************************************************************************
/// Check to see which part of the queue the user is viewing
///
/// @returns T/F  TRUE if user is looking at (or near) head
///
//****************************************************************************
BOOL CChartQ::UserViewingHead() {
	CChartQManager *CM = CChartQManager::GetHandle();
	if (!m_pHead)
		return FALSE; // no valid block?
	if (CM->m_midtime < m_pHead->m_EndTime)
		return TRUE;
	CChartBlock *plast = m_pTail->m_pPrev; // always leave the tail blocks alone.. (use last-but-2)
	if (plast)
		plast = plast->m_pPrev; // back to tail -2
	if (!plast)
		return FALSE; // no valid block ?
	if (CM->m_midtime > plast->m_StartTime)
		return FALSE;
	// see if midtime is nearer to firsttime or lasttime
	return ((CM->m_midtime - m_pHead->m_EndTime) < (plast->m_StartTime - CM->m_midtime));
}
//****************************************************************************
/// delete the complete contents (execpt for request block if set up)
///
/// @param[in] none
///
/// @return none
///
//****************************************************************************
void CChartQ::DeleteContents() {
	while (m_pHead) {
		CChartBlock *ptempblock = m_pHead;
		m_pHead = m_pHead->m_pNext;
		if (ptempblock != m_pRequestblock)
			delete ptempblock;
		else {
			// we will only ever have max 1 outstanding request per CCharQ.
			// and m_pRequestblock points to the block.
			// here we copy the pointer so we can delete it when the request completes
			m_pOldRequestblock = m_pRequestblock;
			m_pRequestblock = NULL;
			qDebug("Setting m_pOldRequestblock\n");
			// and DO NOT delete the block!!
		}
	}
	m_pTail = NULL;
	m_NumBlocks = 0;
}
//****************************************************************************
/// Recover memory blocks on leaving replay mode rather than waiting for blocks
/// to be released/reused over time
///
/// @param[in] none
///
/// @return none
///
//****************************************************************************
void CChartQ::RecoverMemoryBlocks() {
	// if we have come out of replay mode we may have too many blocks in the queue - so release them
	// allowing for fact that there may still be requests that have not completed.
	int curblocks = m_NumBlocks;
	//int freed=0;
	//PSR Fix for PAR# 1-3KC14ZV - Circular Chart_Could not plot all data in history mode begin
	int nMaxQBlocks = GetMaxQBlocks();
	//PSR Fix for PAR# 1-3KC14ZV - Circular Chart_Could not plot all data in history mode end
	while (curblocks > nMaxQBlocks) {
		CChartBlock *ptempblock = m_pHead; // break off the head
		m_pHead = m_pHead->m_pNext;		 // move head on
		m_pHead->m_pPrev = NULL;			 // new head has no previous
		if (ptempblock != m_pRequestblock)
			delete ptempblock;
		else {
			// we will only ever have max 1 outstanding request per CCharQ.
			// and m_pRequestblock points to the block.
			// here we copy the pointer so we can delete it when the request completes
			m_pOldRequestblock = m_pRequestblock;
			m_pRequestblock = NULL;
			qDebug("Setting m_pOldRequestblock\n");
			// and DO NOT delete the block!!
		}
		curblocks--;
		//freed++;
	}
	//qDebug("freed %d blocks\n",freed);
}
//****************************************************************************
/// Obtain a chart block to use - either new or recycled
///
/// @param[in] NoOfRecs -	0=default or the number to create
///
/// @return pointer to new block
///
//****************************************************************************
CChartBlock* CChartQ::ReuseOrAddNewBlock(int NoOfRecs) {
	CChartBlock *pNewblock = NULL;
	int maxblocks;
	if (m_ReplayUsage)
		maxblocks = Glb_MaxReplayQBlocks;
	else {
#ifdef PC_USE
    if(CEmulator::m_SimulatorVol[0])
    maxblocks=Glb_MaxReplayQBlocks;  // if running as simulator, always use more blocks, since SD file size is only 4K
    else
#endif
		//PSR Fix for PAR# 1-3KC14ZV - Circular Chart_Could not plot all data in history mode begin
		maxblocks = GetMaxQBlocks();
		//PSR Fix for PAR# 1-3KC14ZV - Circular Chart_Could not plot all data in history mode end
	}
	if (m_NumBlocks < maxblocks) {
		// create a new empty block, of the size required
		pNewblock = new CChartBlock(this);
		if (!pNewblock)
			return NULL;
		if (!pNewblock->CreateRecs(NoOfRecs)) {
			delete pNewblock;
			return NULL;
		}
	} else {
		//qDebug("\n==============RE-USING BLOCKS===========\n");
		if (!m_ReplayUsage) {
			// if we have come out of replay mode we may have too many blocks in the queue
			while (m_NumBlocks > maxblocks)
				DeleteBlock(m_pHead);
			// take a block from the head and re-use it.
			pNewblock = m_pHead;
			m_pHead = m_pHead->m_pNext;
			if (m_pHead)
				m_pHead->m_pPrev = NULL;
			pNewblock->m_pNext = NULL;
			pNewblock->Reset(NoOfRecs);
		} else {
			// for replay mode, we allow more blocks in the queue anyway
			// and we take it from the opposite end to where the user is looking.
			if (UserViewingHead()) {
#ifdef _DEBUG
      if((m_PenIndex==penIndexToUse) && SHOWREQ) // todo remove
        qDebug("REMOVING FROM TAIL-2\n");
#endif
				// remove from tail (less 2) - never remove the last 2 blocks.
				if ((m_pTail->m_pPrev) && (m_pTail->m_pPrev->m_pPrev)) {
					pNewblock = m_pTail->m_pPrev->m_pPrev;
					m_pTail->m_pPrev->m_pPrev = pNewblock->m_pPrev;
				}
				if (m_pTail->m_pPrev->m_pPrev)
					m_pTail->m_pPrev->m_pPrev->m_pNext = m_pTail->m_pPrev;
				else
					m_pHead = m_pTail->m_pPrev;  // must have only 2 blocks now. (unlikely)
			} else {
#ifdef _DEBUG
      if((m_PenIndex==penIndexToUse)&& SHOWREQ) // todo remove
        qDebug("REMOVING FROM HEAD\n");
#endif
				// remove from head
				pNewblock = m_pHead;
				m_pHead = m_pHead->m_pNext;
				if (m_pHead)
					m_pHead->m_pPrev = NULL;
			}
			pNewblock->m_pNext = NULL;
			pNewblock->m_pPrev = NULL;
			pNewblock->Reset(NoOfRecs);
		}
	}
	return pNewblock;
}
//****************************************************************************
/// Update the oldest known time for this Queue
///
/// @param[in] chartQueueType - the chart queue type
///
/// @return none
///
//****************************************************************************
void CChartQ::UpdateOldestTime(CHART_QUEUE_TYPES chartQueueType) {
	ChartRec oldestRecord;
	oldestRecord.hdr.startTimeH = 0x55; // set to 0x55 for now  @todo remove for release
	CQueueManager *pQM = CQueueManager::GetHandle();
	CQMDiskServices &ds = pQM->GetDiskServices();
	CChartQManager *CM = CChartQManager::GetHandle();
	T_QMC_FILE_BLOCK_TRANSACTION fbt;
	fbt.fileId = QMC_INVALID_FILE_NUMBER;
	fbt.blockId = QMC_INVALID_BLOCK_NUMBER;
	fbt.numOfBlocksLastRequested = QMC_ZERO;
	fbt.recycleState = QMC_TRANS_INITIALISED;
	if (ds.GetBlocksFromFirstAvailable(USRREQSER_USER_CHART_LOCAL, m_QHandle, // Qhandle for this Queue
			1,		// 1 block
			&fbt, (BYTE*) &oldestRecord) == QMDSKSER_OK) {
		// wait for the result
		WaitForSingleObject(CM->m_pIntMessQ->GetEventHandler(), 10000);
		// get the reply message (if any)
		const CInternalMessage *pReplyMessage = NULL;
		pReplyMessage = CM->m_pIntMessQ->ReadInternalMessage();
		if (!pReplyMessage) {
			// not found.
			return;
		}
		// here we have a reply...
		// message is present therefore cast our data pointer
		T_USRREQSER_USER_MESSAGE_REPLY *pReply = (T_USRREQSER_USER_MESSAGE_REPLY*) pReplyMessage->m_MsgData;
		if (pReply->requestReply == USRREQSER_REQUEST_SUCCESSFUL) {
			if (pReply->numOfBlocksObtained != 0) {
				if (oldestRecord.hdr.startTimeH == 0x55) // todo remove after testing
					qDebug(
							"[][] NO BLOCK RETURNED (GetBlocksFromFirstAvailable) FROM *PEN DATA* QUEUE for pen %d [][]\n",
							m_PenIndex);
				else {
					// store the start time from the header
					CM->m_OldestDataTime[chartQueueType][m_fastmedslow].LowPart = oldestRecord.hdr.startTimeL;
					CM->m_OldestDataTime[chartQueueType][m_fastmedslow].HighPart = oldestRecord.hdr.startTimeH;
					CM->m_OldestDataFlag[chartQueueType][m_fastmedslow] = TRUE; // set the flag!
        qDebug()<<"Setting Oldest time for chartspeed %d to %I64d  %s\n", m_fastmedslow,
							CM->m_OldestDataTime[chartQueueType][m_fastmedslow].QuadPart,
          FT(CM->m_OldestDataTime[chartQueueType][m_fastmedslow].QuadPart);
				}
			}
		}
		// now reset the message
		CM->m_pIntMessQ->RemoveInternalMessage();  // remove it
	} else
		qDebug("  <OLD TIME QUEUE FULL>\n");
}
//****************************************************************************
/// Adds a new empty block to the ChartQ list ready to fill with the latest
/// readings received. (may reuse one from the head/tail-1)
/// The Tail block is never re-used and there are enough records within it to
/// ensure that any earlier data will already be on SD and can be read back.
/// When requesting data from SD, the blocks will be allocated elsewhere
///
/// @param none
///
/// @return TRUE/FALSE
///
//****************************************************************************
BOOL CChartQ::AddBlock() {
	CChartBlock *pNewblock = NULL;
	if (m_IsSRAM) {
		// for SRAM block queue we only have one chart block and re-use it.
		if (m_pHead == NULL) {
			// create our one and only empty block
			pNewblock = new CChartBlock(this);
			if (!pNewblock)
				return FALSE;
			if (!pNewblock->CreateRecs()) {
				delete pNewblock;
				return FALSE;
			}
			m_pHead = pNewblock;
			m_pTail = m_pHead;
			m_pTail->m_StartTime = m_lastWriteTime + m_Tpp;
			m_pTail->m_DataEndTime = m_pTail->m_StartTime;
			m_pTail->m_EndTime = m_pTail->m_StartTime;
		} else {
			// we only ever have one chartblock for the SRAM chart 'Q'
			// mark the block as complete and continue.
			m_pTail->Reset();
			m_pTail->m_StartTime = m_pTail->m_EndTime;
			m_pTail->m_DataEndTime = m_pTail->m_StartTime;
			m_pTail->m_EndTime = m_pTail->m_StartTime;
		}
		// here we set the clear the flag for this queue speed
		//		if( m_PenIndex==0) // could use any index for this. (probably better to use the same each time)
		//		{
		CChartQManager *CM = CChartQManager::GetHandle();
		CM->m_OldestDataFlag[m_chartQueueType][m_fastmedslow] = FALSE;
		//		}
		return TRUE;
	}
	// otherwise, we have a volatile chart Q
	pNewblock = ReuseOrAddNewBlock(0); // create a new/reuse a block. size is default(=0).
	if (m_pHead == NULL) {
		m_pHead = pNewblock;
		m_pTail = m_pHead;
		m_pTail->m_StartTime = m_lastWriteTime + m_Tpp;
		m_pTail->m_DataEndTime = m_pTail->m_StartTime;
		m_pTail->m_EndTime = m_pTail->m_StartTime;
	} else {
		pNewblock->m_pPrev = m_pTail;
		m_pTail->m_pNext = pNewblock;
		m_pTail = pNewblock;
		m_pTail->m_StartTime = m_pTail->m_pPrev->m_EndTime;
		m_pTail->m_DataEndTime = m_pTail->m_StartTime;
		m_pTail->m_EndTime = m_pTail->m_StartTime;
	}
	return TRUE;
}
//****************************************************************************
/// Re-Initialise the first block with the time of the first reading
///
/// @param[in] none
///
/// @return none
///
//****************************************************************************
void CChartQ::ReInit() {
	CChartQManager *CM = CChartQManager::GetHandle();
	if (m_IsSRAM)
		return; // should only be called for volatile queue
	// get a pointer to our corrresponding SRAM based queue
	// SRAM queue will always exist (and created first)
	CChartQ *pSRAM = NULL;
	if (m_chartQueueType == CQT_STRIP) {
		pSRAM = CM->GetStripChartQ(m_PenIndex, m_fastmedslow, TRUE); // TRUE for SRAM
	} else if (m_chartQueueType == CQT_CIRCULAR) {
		pSRAM = CM->GetCircularChartQ(m_PenIndex, m_fastmedslow, TRUE); // TRUE for SRAM
	}
	// check to see if there is at least 1 record in the existing block to copy the current SRAM block into
	if (m_pTail->CopyToExistingBlock(pSRAM->m_pHead) == FALSE) {
		// failed, so create a new block and copy to there.
		// copy the SRAM block settings
		CChartBlock *pNewblock = ReuseOrAddNewBlock(0); // create a new/reuse a block. size is default(=0).
		// add as the new tail
		pNewblock->m_pPrev = m_pTail;
		m_pTail->m_pNext = pNewblock;
		m_pTail = pNewblock;
		// now copy the block from the corresponding SRAM queue.
		m_pTail->Copy(pSRAM->m_pHead); // copy block and data to our TAIL
	}
	m_MaxMin = pSRAM->m_MaxMin;	 // copy partial maxmins built so far.
	m_NeedsInit = FALSE;
}
BOOL donetrace = FALSE;
//****************************************************************************
/// Initialise the first block with the time of the first reading
///
/// @param[in] InitialTime	- 1st reading time
///
/// @return firstInitDone
///
//****************************************************************************
BOOL CChartQ::Init(LONGLONG InitialTime) {
	CChartQManager *CM = CChartQManager::GetHandle();
	if (m_IsSRAM) {
#ifdef _DEBUG
    if(!donetrace)
    {
    //qDebug("+++First reading going into chart Queue\n");
    donetrace=TRUE;
    }
#endif
		// here we used to align with our rate - but for slow rates, this results in blocks with the same start time
		// by not aligning, the blocks get slightly different times.
		//		InitialTime=InitialTime-(InitialTime % m_Tpp); // align the time with our rate
		// set up lastWriteTime to be exactly 1 reading old (so we start a new slot with our first reading at initialTime)
		m_lastWriteTime = InitialTime - m_Tpp;
		AddBlock();
		m_FirstInitDone = TRUE;
		m_NeedsInit = FALSE;
	} else {
		// get a pointer to our corrresponding SRAM based queue
		// SRAM queue will always exist (and created first)
		CChartQ *pSRAM = NULL;
		if (m_chartQueueType == CQT_STRIP) {
			pSRAM = CM->GetStripChartQ(m_PenIndex, m_fastmedslow, TRUE); // TRUE for SRAM
		} else if (m_chartQueueType == CQT_CIRCULAR) {
			pSRAM = CM->GetCircularChartQ(m_PenIndex, m_fastmedslow, TRUE); // TRUE for SRAM
		}
		if (pSRAM->m_FirstInitDone) {
			// here we want to make sure all the data in the SRAM queue is flushed
			// since we can only access a single block (head==tail) in SRAM.
			// since we mark each SRAM block as complete as soon as it has been initialised, if we flush here
			// we will flush our partially complete block (not what we want to do)
			CQueueManager *pQM = CQueueManager::GetHandle();
			CQMBlockServices &bs = pQM->GetBlockServices();
			CQMDiskServices &ds = pQM->GetDiskServices();
			// first mark the SRAM block as 'In Use' so it don't get flushed
			pSRAM->m_pHead->SetBlockStatus(QMC_BLKSTATUS_IN_USE);
			bs.FlushQDataBlocksReadyForDisk(pSRAM->m_QHandle); //  flush the rest
			pSRAM->m_pHead->SetBlockStatus(QMC_BLKSTATUS_COMPLETE);	// set it back again
			ds.FlushDataBlocksToPhysicalDisk(); // then ensure all the blocks in the "to-disk-Q" go to disk.
			// copy it's settings
			m_lastWriteTime = pSRAM->m_lastWriteTime;
			// here we need to double check we don't have any blocks.
			if (m_pHead) {
				DeleteContents();
				qDebug("yep caught it\n");
			}
			AddBlock();
			// now copy the block from the corresponding SRAM queue.
			m_pHead->Copy(pSRAM->m_pHead); // copy block and data to our head
			m_MaxMin = pSRAM->m_MaxMin;	 // copy partial maxmins built so far.
			// here need to set up a request for a screen's width of data to prefill the memory queue from SD
			// if there is data on the SD
			// decided to remove this - should ensure that the first visible screen gets priority
			/*
			 if(!m_InitialRequest) // not already doing it via another call
			 {
			 //qDebug("~~~~ init Q %d\n",m_QHandle);
			 m_InitialRequest=TRUE;
			 CheckQueue(0,0);
			 }
			 */
			// although we do the prefill in the Volatile Queue ONLY, we flag it in it's corresponding SRAM queue
			// this is because until all chart speeds have been 'seen' e.g. changed rate or zoomed in reply
			// not all the volatile queues are created.
			if (pSRAM->m_NeedsPrefill) {
				// here we want to make an older block and prefill it with the same value as we are seeing.
				ChartReading reading = m_pHead->m_pRecs[0].readings[0]; // get the reading we want to duplicate
				CChartBlock *pNewblock = ReuseOrAddNewBlock(0); // create a new/reuse a block. size is default(=0).
				//PSR Fix for PAR# 1-3KC14ZV - Circular Chart_Could not plot all data in history mode begin
				//Get the recs per block based on chart Q type
				int nRecsPerBlock = GetRecsPerBlock();
				LONGLONG starttime = m_pHead->m_StartTime - (nRecsPerBlock * MAX_REC_READINGS * m_Tpp);
				//PSR Fix for PAR# 1-3KC14ZV - Circular Chart_Could not plot all data in history mode end
				pNewblock->Prefill(starttime, reading);
				pNewblock->m_pNext = m_pHead;
				m_pHead->m_pPrev = pNewblock;
				m_pHead = pNewblock;
				pSRAM->m_NeedsPrefill = FALSE;
			}
			m_FirstInitDone = TRUE;
			m_NeedsInit = FALSE;
		}
	}
	// here check chart message Q has done initial request
	if (CM->m_ChartMessageQ && (CM->m_ChartMessageQ->m_DoneSetup == FALSE))
		CM->m_ChartMessageQ->SetupQs();
	return m_FirstInitDone;
}
//****************************************************************************
/// Adds a reading into the ChartQ
///
/// @param[in] value		  - reading to add
/// @param[in] processTime100 - current 'slice' time to use
///
/// @return TRUE/FALSE
///
//****************************************************************************
BOOL CChartQ::AddReading(float value, LONGLONG processTime100) {
	BOOL retval = FALSE;
	if (m_NeedsInit) {
		if (!m_FirstInitDone) {
			if (Init(processTime100) == FALSE) {
				return FALSE;
			} else {
				//qDebug("m_FirstInitDone P%d = %I64d %I64d %I64d\n", m_PenIndex, processTime100, m_lastWriteTime, m_Tpp);
			}
		} else
			ReInit();
	}
	LONGLONG difftime = processTime100 - m_lastWriteTime; // current process time minus time of last write (how long has it been)
	//	if((m_QHandle==3)&&(!m_IsSRAM))
	//qDebug("add reading difftime P%d= %I64d %I64d %I64d %I64d\n", m_PenIndex, processTime100, m_lastWriteTime, m_Tpp, difftime);
	// check to see if we are reciving readings to add faster than the required rate (maxmin-ing required)
	if (difftime >= m_Tpp) {
		// here we are getting them at the same rate (single reading) or slower (need to duplicate readings)
		if ((m_MaxMin.GetMin() != FLT_MAX) || (m_MaxMin.GetMax() != -FLT_MAX)) // has a value yet?
				{
			difftime -= m_Tpp; // take off 1 first.
			while (difftime >= m_Tpp) {
				// still greater, so duplicate readings required.
				m_lastWriteTime += m_Tpp;
				difftime -= m_Tpp;
				do {
					// always add readings to the tail of the Q list
					retval = m_pTail->AddReading(m_lastWriteTime, m_MaxMin.GetMax(), m_MaxMin.GetMin());
					if (retval == FALSE) {
						// the block is full, need to add another block on
						if (!AddBlock())
							return FALSE; // some problem adding a new block.
					}
				} while (retval == FALSE);
			}
		}
		// move on to the next time slot
		m_lastWriteTime += m_Tpp;
		// here we used to align with our rate - but for slow rates this results in blocks with the same start time
		// by not aligning, the blocks get slightly different times, which is what we want when we read them back from SD.
		//		m_lastWriteTime=processTime100-(processTime100 % m_Tpp); // align the time with our rate
		// and reset the max-mins to this value
		m_MaxMin.ResetMaxMin(value);
	} else
		m_MaxMin.DoMaxMinForReading(value); // add this reading into max-min calculations
	// now add the reading, which depending upon the time, may be an update to previously added value
	do {
		// always add readings to the tail of the Q list
		retval = m_pTail->AddReading(m_lastWriteTime, m_MaxMin.GetMax(), m_MaxMin.GetMin());
		if (retval == FALSE) {
			// the block is full, need to add another block on
			if (!AddBlock())
				return FALSE; // some problem adding a new block.
		}
	} while (retval == FALSE);
	return TRUE;
}
//****************************************************************************
/// Calc the MaxMin
/// This function can be called by GetFirstReading, or GetNextReading if the
/// data rate indicates that the date needs to be maxmin'ed.
///
/// @param[in] rc	- pointer to ReadContext structure
///
/// @return CHARTRET:  DATA_OK, NO_MORE_DATA
///
//****************************************************************************
CHARTRET CChartQ::MaxMinCalc(ReadContext *rc) {
	// keep values so far
	rc->m_max = rc->m_pReading->maxv;
	rc->m_min = rc->m_pReading->minv;
	MemTrace
	(m_PenIndex, L"trying maxmin calc\n");
	LONGLONG NextReadingTime = rc->m_ReadingTime + rc->m_RecTpp; // where the next reading time should be
	CHARTRET ret;
	ret = GetNextForMaxMin(rc);
	while (ret == DATA_OK) {
		// now here, is the time of the reading that was read actually in the range we need?
		if (rc->m_ReadingTime >= rc->m_LocateTime + m_DrawingTpp) {
			// the reading we have read is past the time slot we require.
			// however, we will need it next time.
			MemTrace
			(m_PenIndex, L" NOT included in maxmin %I64d\n", rc->m_ReadingTime);
			if (NextReadingTime != rc->m_ReadingTime) {
				// rc->m_ReadingTime is not where it would be if continuous.
				// need to resynchronise on this reading next time in.
				rc->m_Resync = TRUE;
			}
			break;
		}
		//		MemTrace(m_PenIndex,L" including in maxmin %I64d\n",rc->m_ReadingTime);
		// include it in this maxmin calculation
		if (rc->m_pReading->maxv > rc->m_max)
			rc->m_max = rc->m_pReading->maxv;
		if (rc->m_pReading->minv < rc->m_min)
			rc->m_min = rc->m_pReading->minv;
		// and the next...
		ret = GetNextForMaxMin(rc);
	}
	return DATA_OK;
}
//****************************************************************************
/// Called by MaxMinCalc to get the next reading for MaxMin purposes
///
/// @param[in] rc	- pointer to ReadContext structure containing current
///					  position etc within the queue
///
/// @return CHARTRET:  DATA_OK, NO_MORE_DATA
///
//****************************************************************************
CHARTRET CChartQ::GetNextForMaxMin(ReadContext *rc) {
	if (rc->m_pBlock == NULL)
		return NO_MORE_DATA;
	CHARTRET ret = rc->m_pBlock->GetNextReading(rc, m_chartQueueType);
	if (ret != DATA_OK) {
		do {
			rc->m_pBlock = rc->m_pBlock->m_pNext;
		} while (rc->m_pBlock && (rc->m_pBlock->m_Type != CBLK_NORMAL));
		if (rc->m_pBlock)
			ret = rc->m_pBlock->GetFirstReading(rc, m_chartQueueType);
	}
	return ret;
}
//****************************************************************************
/// Gets the first reading from the ChartQ at a specified time
///
/// @param[in] rc	- pointer to ReadContext structure containing time to find
///
/// @return CHARTRET:  DATA_OK, NO_MORE_DATA
///
//****************************************************************************
CHARTRET CChartQ::GetFirstReading(ReadContext *rc) {
	MemTrace
	(m_PenIndex, L"\nS want %I64d\n", rc->m_LocateTime);
	// search from the head
	rc->m_pBlock = m_pHead;
	rc->m_Resync = FALSE;
	rc->m_ReadingTime = BEGINNING_OF_TIME;
	while (rc->m_pBlock) {
		if (rc->m_pBlock->m_Type != CBLK_NORMAL) {
			rc->m_pBlock = rc->m_pBlock->m_pNext;
			continue;
		}
		if (rc->m_LocateTime >= rc->m_pBlock->m_StartTime) {
			if (rc->m_LocateTime < rc->m_pBlock->m_DataEndTime) {
				// required time is in this block
				CHARTRET ret = rc->m_pBlock->GetFirstReading(rc, m_chartQueueType);
				if (ret == DATA_OK) {
					// after the initial GetFirstReading call, we set the m_LocateTime to the data found (later if gap in data)
					if (rc->m_ReadingTime >= rc->m_LocateTime + m_DrawingTpp) {
						rc->m_LocateTime = rc->m_ReadingTime - (rc->m_ReadingTime % m_DrawingTpp); // round down to drawingtpp boundary.
						MemTrace
						(m_PenIndex, L"  found time %I64d\n", rc->m_LocateTime);
						return MaxMinCalc(rc);
					} else if (rc->m_ReadingTime == rc->m_LocateTime) // hit exactly? (unlikely since readings are not stored on boundaries)
							{
						return MaxMinCalc(rc);
					} else {
						//return MaxMinCalc(rc);
						// here we need to read another to ensure we have correct start pos
						// extract values so far
						rc->m_max = rc->m_pReading->maxv;
						rc->m_min = rc->m_pReading->minv;
						LONGLONG NextReadingTime = rc->m_ReadingTime + rc->m_RecTpp; // where the next reading time should be
						ret = GetNextForMaxMin(rc);
						if (ret == DATA_OK) {
							// here we may need to use the next value
							if (rc->m_ReadingTime < rc->m_LocateTime + m_DrawingTpp) {
								// yes we do, start from here
								return MaxMinCalc(rc);
							}
							// otherwise we stick with the first one found (and there's no point checking for maxmin, since the next reeading is too far off)
							if (NextReadingTime != rc->m_ReadingTime) {
								// rc->m_ReadingTime is not where it would be if continuous.
								// need to resynchronise on this reading next time in.
								rc->m_Resync = TRUE;
							}
							return DATA_OK;
						}
					}
					return NO_MORE_DATA; // no more, and don't use the one we found.
				}
				return ret;
			} else
				rc->m_pBlock = rc->m_pBlock->m_pNext;
		} else {
			// earlier data wanted, but return first block after the requested time
			CHARTRET ret = rc->m_pBlock->GetFirstReading(rc, m_chartQueueType);
			if (ret == DATA_OK) {
				// after the initial GetFirstReading call, we set the m_LocateTime to the data found (later if gap in data)
				if (rc->m_ReadingTime >= rc->m_LocateTime + m_DrawingTpp) {
					rc->m_LocateTime = rc->m_ReadingTime - (rc->m_ReadingTime % m_DrawingTpp); // and round down to drawingtpp boundary.
					//MemTrace(m_PenIndex,L"  found time %I64d\n",rc->m_LocateTime);
				}
				return MaxMinCalc(rc);
			}
			return ret;
		}
	}
	return NO_MORE_DATA;
}
//****************************************************************************
/// Gets the first reading from the ChartQ at a specified time, for the circular chart
///
/// @param[in] rc	- pointer to ReadContext structure containing time to find
///
/// @return CHARTRET:  DATA_OK, NO_MORE_DATA
///
//****************************************************************************
CHARTRET CChartQ::GetFirstReadingCirci(ReadContext *rc) {
	MemTrace
	(m_PenIndex, L"\nS want %I64d\n", rc->m_LocateTime);
	// search from the head
	rc->m_pBlock = m_pHead;
	rc->m_Resync = FALSE;
	rc->m_ReadingTime = BEGINNING_OF_TIME;
	while (rc->m_pBlock) {
		if (rc->m_pBlock->m_Type != CBLK_NORMAL) {
			rc->m_pBlock = rc->m_pBlock->m_pNext;
			continue;
		}
		if (rc->m_LocateTime >= rc->m_pBlock->m_StartTime) {
			if (rc->m_LocateTime < rc->m_pBlock->m_DataEndTime) {
				// required time is in this block
				CHARTRET ret = rc->m_pBlock->GetFirstReading(rc, m_chartQueueType);
				if (ret == DATA_OK) {
					// after the initial GetFirstReading call, we set the m_LocateTime to the data found (later if gap in data)
					if (rc->m_ReadingTime >= rc->m_LocateTime + m_DrawingTpp) {
						rc->m_LocateTime = rc->m_ReadingTime - (rc->m_ReadingTime % m_DrawingTpp); // round down to drawingtpp boundary.
						MemTrace
						(m_PenIndex, L"  found time %I64d\n", rc->m_LocateTime);
					} else if (rc->m_ReadingTime == rc->m_LocateTime) // hit exactly? (unlikely since readings are not stored on boundaries)
							{
						return MaxMinCalc(rc);
					} else {
						//return MaxMinCalc(rc);
						// here we need to read another to ensure we have correct start pos
						float saveMax, saveMin;
						// extract values so far
						saveMax = rc->m_pReading->maxv;
						saveMin = rc->m_pReading->minv;
						LONGLONG NextReadingTime = rc->m_ReadingTime + rc->m_RecTpp; // where the next reading time should be
						ret = GetNextForMaxMin(rc);
						if (ret == DATA_OK) {
							// here we may need to use the next value
							if (rc->m_ReadingTime < rc->m_LocateTime + m_DrawingTpp) {
								// yes we do, start from here
								return MaxMinCalc(rc);
							}
							// otherwise we stick with the first one found (and there's no point checking for maxmin, since the next reeading is too far off)
							if (NextReadingTime != rc->m_ReadingTime) {
								// rc->m_ReadingTime is not where it would be if continuous.
								// need to resynchronise on this reading next time in.
								rc->m_Resync = TRUE;
							}
						} else {
							// No next reading so return data so far
							rc->m_max = saveMax;
							rc->m_min = saveMin;
						}
						return DATA_OK;
					}
				}
				return ret;
			} else
				rc->m_pBlock = rc->m_pBlock->m_pNext;
		} else {
			// earlier data wanted, but return first block after the requested time
			CHARTRET ret = rc->m_pBlock->GetFirstReading(rc, m_chartQueueType);
			if (ret == DATA_OK) {
				// after the initial GetFirstReading call, we set the m_LocateTime to the data found (later if gap in data)
				if (rc->m_ReadingTime >= rc->m_LocateTime + m_DrawingTpp) {
					rc->m_LocateTime = rc->m_ReadingTime - (rc->m_ReadingTime % m_DrawingTpp); // and round down to drawingtpp boundary.
					//MemTrace(m_PenIndex,L"  found time %I64d\n",rc->m_LocateTime);
				}
				return MaxMinCalc(rc);
			}
			return ret;
		}
	}
	return NO_MORE_DATA;
}
//****************************************************************************
/// Gets the next reading from the ChartQ after a previous successful call to
/// GetFirstReading()
///
/// @param[in] rc	- pointer to ReadContext structure containing current
///					  position etc within the queue
///
/// @return CHARTRET:  DATA_OK, NO_MORE_DATA, BLOCK_ERROR
///
//****************************************************************************
CHARTRET CChartQ::GetNextReading(ReadContext *rc) {
	//MemTrace(m_PenIndex,L"N want %I64d\n",rc->m_LocateTime);
	// do we need to resync on this reading (gap)
	if (rc->m_Resync) {
		// we have also moved on, so may not need to resync
		if (rc->m_ReadingTime >= rc->m_LocateTime + m_DrawingTpp) // check to see if the reading time falls in the slot required
				{
			rc->m_LocateTime = rc->m_ReadingTime - (rc->m_ReadingTime % m_DrawingTpp); // If not, update locateTime (the slot)
			//MemTrace(m_PenIndex,L"  resync time %I64d\n",rc->m_LocateTime);
		}
		rc->m_Resync = FALSE;
	}
	// here we need to check to see if we need to return the same value. (big fat readings)
	if (rc->m_ReadingTime >= rc->m_LocateTime + m_DrawingTpp) // check to see if the reading time falls in the slot required
			{
		//MemTrace(m_PenIndex,L"N (repeating at %d)\n",rc->m_LocateTime);
		return DATA_OK; // yes we do.
	}
	// we need to continue from here.
	if (rc->m_ReadingTime >= 0) {
		//MemTrace(m_PenIndex,L"N (set from last time at %d)\n",rc->m_ReadingTime);
		return MaxMinCalc(rc);
	}
	return NO_MORE_DATA;
}
//****************************************************************************
/// Data request from disk has completed. Check the result
///
/// @param[in] pReply -		pointer to structure containing reply
///
/// @return none
///
//****************************************************************************
void CChartQ::DataUpdate(T_USRREQSER_USER_MESSAGE_REPLY *pReply) {
	CQueueManager *pQM = CQueueManager::GetHandle();
	CQMDiskServices &ds = pQM->GetDiskServices();
	if (!m_OutstandingRequest) {
#ifdef _DEBUG
    if((m_PenIndex==penIndexToUse) && SHOWREQ)// todo remove
    qDebug("[[]] Received Reply which was NOT REQUESTED [[]]\n");
#endif
		return;
	}
	if (m_pRequestblock == NULL) {
		// no request block, so check for old request
		if (m_pOldRequestblock) {
			// now the request is complete we can delete the old block.
			delete m_pOldRequestblock;
			m_pOldRequestblock = NULL;
		}
		m_OutstandingRequest = FALSE;
		return;
	}
	//qDebug("  data update for Queue %d\n",m_QHandle);
	LONGLONG reqEndTime = m_pRequestblock->m_EndTime;
	LONGLONG reqStartTime = m_pRequestblock->m_StartTime;
	if (pReply->requestReply == USRREQSER_REQUEST_FAILED) {
		// ok, the request failed, so something went wrong.
		// delete the data recs in this block, and treat as an empty time segment
		m_pRequestblock->Validate(0, FALSE, FALSE, FALSE, m_chartQueueType); // 0 recs
#ifdef _DEBUG
    if((m_PenIndex==penIndexToUse)&& SHOWREQ) // todo remove
    qDebug("Request for Data FAILED  p=%d\n",m_PenIndex+1);
#endif
	} else {
		///// MORE TEST CODE todo remove
		//#ifdef _DEBUG
		// Keep in the release for now - corrected problem on GC's recorder 9/6/06
		BOOL Badblock = FALSE;
		// here just check the blocks are as they should be...
		ChartRec *pRec = &m_pRequestblock->m_pRecs[0]; // check the first rec only
		if (pRec->hdr.penNo != m_PenIndex) {
			WCHAR Errbuff[200];
			swprintf(Errbuff, 200, L"Invalid block : pen index=%d should be %d", pRec->hdr.penNo, m_PenIndex);
			qDebug("{}{}{}");
			qDebug() << Errbuff;
			qDebug("\n");
			if (V6_RELEASE != RELEASE_PRODUCTION) // in non-production builds only (we can get a lot of these)
				LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, QString::fromWCharArray(Errbuff));
			Badblock = TRUE;
		}
		if (pRec->hdr.numReadings > MAX_REC_READINGS) {
			WCHAR Errbuff[200];
			swprintf(Errbuff, 200, L"Invalid block : Too many readings (%d)", pRec->hdr.numReadings);
			qDebug("{}{}{}");
			qDebug() << Errbuff;
			qDebug("\n");
			if (V6_RELEASE != RELEASE_PRODUCTION) // in non-production builds only (we can get a lot of these)
				LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, QString::fromWCharArray(Errbuff));
			Badblock = TRUE;
		}
		if (((m_chartQueueType == CQT_STRIP) && (pRec->hdr.rateIndex > (NUM_STRIP_RATES - 1)))
				|| ((m_chartQueueType == CQT_CIRCULAR) && (pRec->hdr.rateIndex > (NUM_CIRC_RATES - 1)))) {
			WCHAR Errbuff[200];
			swprintf(Errbuff, 200, L"Invalid block : Rate index out of range");
			qDebug("{}{}{}");
			qDebug() << Errbuff;
			qDebug("\n");
			if (V6_RELEASE != RELEASE_PRODUCTION) // in non-production builds only (we can get a lot of these)
				LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, QString::fromWCharArray(Errbuff));
			Badblock = TRUE;
		}
		if (Badblock) {
			pReply->requestReply = USRREQSER_REQUEST_FAILED; // mark as failed now
			// treat as the request failed
			// delete the data recs in this block, and treat as an empty time segment (so we don't request it again)
			m_pRequestblock->Validate(0, FALSE, FALSE, FALSE, m_chartQueueType); // 0 recs
		} else {
			// here decide if we want to pull m_EndTime in to the m_DataEndTime (i.e. to match the data it contains)
			// and go for another request below
			// If the data is bigger (m_DataEndTime is after m_EndTime), then m_EndTime will be made later to match
			// smae applies to previous requests and start time.
			BOOL ReduceEndTime = FALSE;
			BOOL IncreaseStartTime = FALSE;
			if ((pReply->requestAction == USRREQSER_UA_GET_NEXT_BLOCKS_FROM_START_TIME)
					|| (pReply->requestAction == USRREQSER_UA_GET_NEXT_BLOCKS))
				ReduceEndTime = (pReply->requestReplyAdditionalInfo == USRREQSER_REPLY_BLOCKS_AVAILABLE);
			else
				IncreaseStartTime = (pReply->requestReplyAdditionalInfo == USRREQSER_REPLY_BLOCKS_AVAILABLE);
			// ensure the block is updated to match the data it contains
			m_pRequestblock->Validate(pReply->numOfBlocksObtained,
					(pReply->requestAction == USRREQSER_UA_GET_NEXT_BLOCKS_FROM_START_TIME)
							|| (pReply->requestAction == USRREQSER_UA_GET_NEXT_BLOCKS), ReduceEndTime,
					IncreaseStartTime, m_chartQueueType);
			//////////////////////////////////////
#if defined(_DEBUG) || defined(PC_USE)
    // check it's not after  the tail! todo remove this test code
    if(m_pRequestblock->m_DataEndTime>m_pTail->m_DataEndTime+1) // allow the +1
    {
      WCHAR Errbuff[200];
      swprintf(Errbuff,200,L"BAD BLOCK RETURNED (endtime) pen %d  %I64d 100ths",m_PenIndex,m_pRequestblock->m_DataEndTime-m_pTail->m_DataEndTime);
      qDebug("[]");
      qDebug() << Errbuff;
      qDebug("[]\n");
      if( V6_RELEASE != RELEASE_PRODUCTION ) // in non-production builds only (we can get a lot of these)
        LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_ERROR, Errbuff);
      delete m_pRequestblock;
      m_pRequestblock=NULL;
      m_OutstandingRequest=FALSE;
      return;
    }
#endif
			//////////////////////////////////////
		}
	}
	///////////// todo remove after testing
#if defined(_DEBUG) || defined(PC_USE)
  if(m_pRequestblock->m_EndTime<m_pRequestblock->m_StartTime)
  {
    WCHAR Errbuff[200];
    swprintf(Errbuff,200,L"INVALID DATA RETURNED (DELETING)");
    qDebug("[]");
    qDebug() << Errbuff;
    qDebug("[]\n");
    if( V6_RELEASE != RELEASE_PRODUCTION ) // in non-production builds only (we can get a lot of these)
    LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_ERROR, Errbuff);
    delete m_pRequestblock;
    m_pRequestblock=NULL;
    m_OutstandingRequest=FALSE;
    return;
  }
#endif
	//////////////////////////////////////
	// now link this block into the queue in the correct position. (even the empty blocks from above)
	BOOL inserted = InsertIntoQueue();
	// inserted and still has some data it
	if (inserted && (m_pRequestblock->m_Type == CBLK_NORMAL)) {
		//	if(m_PenIndex==penIndexToUse) // todo remove
		//		qDebug(" valid Reply for pen \n");
		CChartQManager *CM = CChartQManager::GetHandle();
		if (CM->m_HasNewData) {
			LARGE_INTEGER temp;
			temp.LowPart = m_pRequestblock->m_pRecs[m_pRequestblock->m_FirstRec].hdr.startTimeL;
			temp.HighPart = m_pRequestblock->m_pRecs[m_pRequestblock->m_FirstRec].hdr.startTimeH;
			if (temp.QuadPart < CM->m_Earliest)
				CM->m_Earliest = temp.QuadPart;
			if (m_pRequestblock->m_EndTime > CM->m_Latest)
				CM->m_Latest = m_pRequestblock->m_EndTime;
		} else {
			((LARGE_INTEGER*) &CM->m_Earliest)->LowPart =
					m_pRequestblock->m_pRecs[m_pRequestblock->m_FirstRec].hdr.startTimeL;
			((LARGE_INTEGER*) &CM->m_Earliest)->HighPart =
					m_pRequestblock->m_pRecs[m_pRequestblock->m_FirstRec].hdr.startTimeH;
			CM->m_Latest = m_pRequestblock->m_EndTime;
			CM->m_HasNewData = TRUE;
		}
	}
#ifdef _DEBUG
  // to do remove
  else
    if(inserted && (m_pRequestblock->m_Type==CBLK_NODATA))
    {
    if((m_PenIndex==penIndexToUse) && SHOWREQ)// todo remove
      qDebug("  NO data used from Reply p=%d\n",m_PenIndex+1);
    }
#endif
	// see if more requests are needed.  It will be more efficient here to make additional requests, since we
	// are already at the correct point in the file to read some more.
	if ((pReply->requestAction == USRREQSER_UA_GET_NEXT_BLOCKS_FROM_START_TIME)
			|| (pReply->requestAction == USRREQSER_UA_GET_NEXT_BLOCKS)) {
		if (m_pRequestblock->m_EndTime < reqEndTime) {
			// need more the blocks... are there any?
			if (pReply->requestReplyAdditionalInfo == USRREQSER_REPLY_BLOCKS_AVAILABLE) {
				// everything went OK, we just need to make a new request for the
				// remaining blocks...
				// approx number of disk blocks to request...
				//int numRecs=pReply->numOfBlocksRequested-pReply->numOfBlocksObtained;
				//if(numRecs==0)
				//	numRecs=CalcNumRecs(m_pRequestblock->m_DataEndTime,reqEndTime);
				// here get the params we need before calling ReuseOrAddNewBlock, since it could get recycled!!
				LONGLONG prevendtime = m_pRequestblock->m_DataEndTime;
				if (!inserted)
					delete m_pRequestblock;
				m_pRequestblock = ReuseOrAddNewBlock(0); // 0=default size
				if (m_pRequestblock == NULL) {
					m_OutstandingRequest = FALSE;
					DebugBreak();
					return; // no mem.
				}
				m_pRequestblock->m_StartTime = prevendtime;
				m_pRequestblock->m_EndTime = reqEndTime; // same as before
				m_pRequestblock->m_Type = CBLK_REQUESTED;
#ifdef _DEBUG
      if((m_PenIndex==penIndexToUse) && SHOWREQ)	// todo remove
        qDebug("Rep FOR xx START %s END %s  st:%I64d  end:%I64d\n",FS(m_pRequestblock->m_StartTime), FE(m_pRequestblock->m_EndTime),m_pRequestblock->m_StartTime, m_pRequestblock->m_EndTime );
      //qDebug("  get next Queue %d\n",m_QHandle);
#endif
				//PSR Fix for PAR# 1-3KC14ZV - Circular Chart_Could not plot all data in history mode begin
				//Get the recs per block based on chart Q type
				int nRecsPerBlock = GetRecsPerBlock();
				//PSR Fix for PAR# 1-3KC14ZV - Circular Chart_Could not plot all data in history mode end
				// now request blocks from disk, from where we got to last time
				if (ds.GetNextBlocks(USRREQSER_USER_OPPANEL, m_QHandle, nRecsPerBlock, // numRecs
						(BYTE*) m_pRequestblock->GetDataRec()) != QMDSKSER_OK) {
					delete m_pRequestblock;
					m_OutstandingRequest = FALSE;
					qDebug("  <QUEUE FULL>\n");
				}
				return;
			}
		}
	} else // getprevious
	{
		if (reqStartTime < m_pRequestblock->m_StartTime) {
			// need more previous the blocks... are there any?
			if (pReply->requestReplyAdditionalInfo == USRREQSER_REPLY_BLOCKS_AVAILABLE) {
				// everything went OK, we just need to make a new request for the
				// remaining blocks...
				// here get the params we need before calling ReuseOrAddNewBlock, since it could get recycled!!
				LONGLONG nextstarttime = m_pRequestblock->m_StartTime;
				if (!inserted)
					delete m_pRequestblock;
				m_pRequestblock = ReuseOrAddNewBlock(0); // 0=default size
				if (m_pRequestblock == NULL) {
					m_OutstandingRequest = FALSE;
					DebugBreak();
					return; // no mem.
				}
				m_pRequestblock->m_StartTime = reqStartTime, // same as before
				m_pRequestblock->m_EndTime = nextstarttime;
				m_pRequestblock->m_Type = CBLK_REQUESTED;
#ifdef _DEBUG
      if((m_PenIndex==penIndexToUse) && SHOWREQ)	// todo remove
        qDebug("Rep REV xx START %s END %s  st:%I64d  end:%I64d\n",FS(m_pRequestblock->m_StartTime), FE(m_pRequestblock->m_EndTime),m_pRequestblock->m_StartTime, m_pRequestblock->m_EndTime );
      //qDebug("  get prev Queue %d\n",m_QHandle);
#endif
				//PSR Fix for PAR# 1-3KC14ZV - Circular Chart_Could not plot all data in history mode begin
				//Get the recs per block based on chart Q type
				int nRecsPerBlock = GetRecsPerBlock();
				//PSR Fix for PAR# 1-3KC14ZV - Circular Chart_Could not plot all data in history mode end
				// now request previous blocks from disk, from where we got to last time
				if (ds.GetPreviousBlocks(USRREQSER_USER_OPPANEL, m_QHandle, nRecsPerBlock, // numRecs
						(BYTE*) m_pRequestblock->GetDataRec()) != QMDSKSER_OK) {
					delete m_pRequestblock;
					m_OutstandingRequest = FALSE;
					qDebug("  <QUEUE FULL>\n");
				}
				return;
			}
		}
	}
	if (!inserted)
		delete m_pRequestblock;
	m_pRequestblock = NULL;
	m_OutstandingRequest = FALSE;
}
//****************************************************************************
/// Insert new data returned into the queue
///
/// @param none
///
/// @return TRUE if inserted, FALSE if not
///
//****************************************************************************
BOOL CChartQ::InsertIntoQueue() {
	// check the times and remove any overlaps with blocks in the queue
	// search from the head
	CChartBlock *pBlock = m_pHead;
	while (pBlock) {
		if (m_pRequestblock->m_StartTime >= pBlock->m_StartTime) {
			if (m_pRequestblock->m_StartTime < pBlock->m_EndTime) {
				// timespan at least partially overlaps with this block
				if (m_pRequestblock->m_EndTime <= pBlock->m_EndTime) {
					// timespan of new data block is completely covered by another already.
					return FALSE;
				} else {	// here we have a later endtime than the existing block.
							// we may need to chop off the overlapping part at the start of
							// our new block. Then we'll carry on and check the end
					if (m_pRequestblock->m_Type == CBLK_NODATA) {
						pBlock->m_EndTime = m_pRequestblock->m_EndTime;    // extend the endtime time of the block
						return FALSE;
					}
					if (pBlock->m_Type == CBLK_NODATA) {
						// shouldn't ever get here.. the requested block contains data, but the block in the
						// queue does not, and they overlap.
						// we want to remove this block
						CChartBlock *temp = pBlock;
						pBlock = pBlock->m_pNext;
						DeleteBlock(temp);
						continue;
					} else {
						// here both blocks contain data and overlap
						// may need to chop data off the front of our new block.
						// compare the actual data endtime with the actual data starttime
						ChartRec *pRec;
						LARGE_INTEGER starttime;
						do {
							pRec = &m_pRequestblock->m_pRecs[m_pRequestblock->m_FirstRec];
							starttime.LowPart = pRec->hdr.startTimeL;
							starttime.HighPart = pRec->hdr.startTimeH;
							if (pBlock->m_DataEndTime <= starttime.QuadPart)
								break; // ok, now valid, (leave no gap)
							//					// get tpp of the last rec in the block to see if overlap is just one reading
							//					UINT tpp=EzTrendRates[pBlock->m_pRecs[pBlock->m_UsedRecs-1].hdr.rateIndex];
							//					if(starttime.QuadPart-pBlock->m_DataEndTime<=tpp)
							//					{
							//						// yup. reduce num readings in previous block
							//						pBlock->m_pRecs[pBlock->m_UsedRecs-1].hdr.numReadings--;
							//						pBlock->m_DataEndTime=starttime.QuadPart;
							//						break;
							//					}
						} while (++m_pRequestblock->m_FirstRec < m_pRequestblock->m_UsedRecs);
						//  here we set the times, so that the blocks join together.
						if (pBlock->m_DataEndTime <= starttime.QuadPart) {
							// data part of our new data does not overlap with the data part of the preceeding block.
							// need to adjust endtime of preceeding
							m_pRequestblock->m_StartTime = starttime.QuadPart; // may have updated (above)
							pBlock->m_EndTime = m_pRequestblock->m_StartTime;
						} else {
							m_pRequestblock->m_StartTime = pBlock->m_EndTime;	// adjust the start of our new block
							m_pRequestblock->RemoveData(); // there is no data in here we need
						}
					}
					// continue checking...
				}
			}
			// we need to move on and check against next
			pBlock = pBlock->m_pNext;
		} else {
			// new data block start time is ahead of the block StartTime
			// is all the new data before the current block?
			if (m_pRequestblock->m_EndTime <= pBlock->m_StartTime) {
				// yes, simply insert our block here.
				InsertBlock(pBlock->m_pPrev, m_pRequestblock);
				return TRUE;
			} else {
				// no, so only allow up until start of block.
				// if our new block contains no data, then just change the time
				if (m_pRequestblock->m_Type == CBLK_NODATA) {
					pBlock->m_StartTime = m_pRequestblock->m_StartTime; // update the blocks startime
					return FALSE; // nothing to insert
				}
				if (pBlock->m_Type == CBLK_NODATA) {
					// shouldn't ever get here.. the requested block contains data, but the block in the
					// queue does not, and they overlap.
					// we want to remove this block, then continue testing with the rest of the list
					CChartBlock *temp = pBlock;
					pBlock = pBlock->m_pNext;
					DeleteBlock(temp);
					continue;
				} else {
					// here both blocks contain data and overlap
					//  get the actual starttime of the data part
					LARGE_INTEGER starttime;
					ChartRec *pblkRec = &pBlock->m_pRecs[pBlock->m_FirstRec];
					starttime.LowPart = pblkRec->hdr.startTimeL;
					starttime.HighPart = pblkRec->hdr.startTimeH;
					ChartRec *pRec;
					UINT LastRecTpp;
					// may need to chop some data off the end of our requested block
					while (m_pRequestblock->m_UsedRecs > m_pRequestblock->m_FirstRec) {
						pRec = &m_pRequestblock->m_pRecs[m_pRequestblock->m_UsedRecs - 1];
						//PSR Fix for - 1-3GKDZ7Q - charting issues with slow speed begin
						LastRecTpp = CChartQManager::GetRateAtIndex(m_chartQueueType, pRec->hdr.rateIndex);
						//PSR Fix for - 1-3GKDZ7Q - charting issues with slow speed end
						LARGE_INTEGER rectime;
						rectime.LowPart = pRec->hdr.startTimeL;
						rectime.HighPart = pRec->hdr.startTimeH;
						// check to see if we have a full block - if so, we know the exact start time of the next one (m_DataEndTime)
						if (pRec->hdr.numReadings == MAX_REC_READINGS)
							m_pRequestblock->m_DataEndTime = rectime.QuadPart + (pRec->hdr.numReadings) * LastRecTpp; // first reading at start time. m_DataEndTime is +1 reading time
						else
							m_pRequestblock->m_DataEndTime = rectime.QuadPart + 1
									+ (pRec->hdr.numReadings - 1) * LastRecTpp; // here set m_DataEndTime time of last reading + 0.01 sec
						if (m_pRequestblock->m_DataEndTime <= starttime.QuadPart)
							break; // update, leaving no gap.
						// see if overlap is just one reading
						//						if(m_pRequestblock->m_DataEndTime-starttime.QuadPart<=tpp)
						//						{
						//							// yup. reduce num readings in requested block
						//							pRec->hdr.numReadings--;
						//							m_pRequestblock->m_DataEndTime=starttime.QuadPart;
						//							break;
						//						}
						m_pRequestblock->m_UsedRecs--;
					}
					if (m_pRequestblock->m_DataEndTime <= starttime.QuadPart) {
						// data is ok, we just need to adjust StartTime of following block
						pBlock->m_StartTime = starttime.QuadPart;
						m_pRequestblock->m_EndTime = pBlock->m_StartTime;
					} else {
						m_pRequestblock->m_EndTime = pBlock->m_StartTime; // update our blocks endtime
						m_pRequestblock->RemoveData(); // there is no data in here we need
					}
				}
				InsertBlock(pBlock->m_pPrev, m_pRequestblock);
				return TRUE;
			}
		}
	}
	// here, at the end of the list...
	InsertBlock(m_pTail, m_pRequestblock);
	return TRUE;
}
//****************************************************************************
/// calculate number of records (blocks) to request from SD
///
/// @param[in] TimeFrom		- Start time of data required
/// @param[in] TimeTo		- End time of data required
///
/// @return number of records (blocks) required
///
//****************************************************************************
int CChartQ::CalcNumRecs(LONGLONG TimeFrom, LONGLONG TimeTo) {
	int timespan = (int) (TimeTo - TimeFrom);
	UINT numReadings = timespan / m_Tpp; // use the data Tpp here
	if (timespan % m_Tpp)
		numReadings++;
	int numRecs = numReadings / MAX_REC_READINGS;
	if (numReadings % MAX_REC_READINGS)
		numRecs++;
	//PSR Fix for PAR# 1-3KC14ZV - Circular Chart_Could not plot all data in history mode begin
	//Get the recs per block based on chart Q type
	int nRecsPerBlock = GetRecsPerBlock();
	//PSR Fix for PAR# 1-3KC14ZV - Circular Chart_Could not plot all data in history mode end
	// limit it to the max we want to request
	if (numRecs > nRecsPerBlock)
		numRecs = nRecsPerBlock;
	return numRecs;
}
//****************************************************************************
/// dump the contents of Q to trace window
///
/// @param none
///
/// @return none
///
//****************************************************************************
void CChartQ::DumpQ() {
	CChartBlock *pBlock = m_pHead;
	qDebug("\nDATA Q DUMP ========================================================\n");
	qDebug("Pen %d Tpp %d\n", penIndexToUse + 1, m_Tpp);
	while (pBlock) {
		pBlock->Dump();
		pBlock = pBlock->m_pNext;
	}
	qDebug("\nDUMP END========================================================\n");
}
//****************************************************************************
/// check the queue for the given timespan.
///
/// @param[in] TimeFrom		- time to check from
/// @param[in] TimeTo		- time to check up to
///
/// @return T/F  T=request added or busy
///
//****************************************************************************
BOOL CChartQ::CheckQueue(LONGLONG TimeFrom, LONGLONG TimeTo) {
	//	if(m_InitialRequest)
	//		qDebug("(((Calling CheckQueue for Queue %d\n",m_QHandle);
	// need to check the Queue and request any missing data
	if (!m_pHead)
		return FALSE;
	// ensure we don't already have a request in progress
	if (m_OutstandingRequest) {
		//qDebug("   Outstanding REQ - Queue %d\n",m_QHandle);
		return TRUE; // still busy
	}
	m_OutstandingRequest = TRUE; //assume there will be one (may reset this below)
	if (m_InitialRequest) // this happens on screen changes and layout updates etc
	{
		//PSR Fix for PAR# 1-3N5DCMN - Recorder hung while menu navigation, followed by Real time to history mode in circular chart begin
		//Have the below previous logic as is for strip charts
		//Circular chart will always set the TimeFrom and TimeTo before calling this function unless in realtime mode or it is being called from ChartQueues itself
		if (true == m_bIsClearQTriggered) {
			TimeFrom = m_lastWriteTime;
			TimeTo = m_lastWriteTime;
		} else {
			if (m_chartQueueType == CQT_STRIP || ((0 == TimeFrom) && (0 == TimeTo))) {
				//  Verify changes.....
				//TimeFrom=m_lastWriteTime-(m_Tpp*800); // multiplus largest
				TimeFrom = m_lastWriteTime - (m_Tpp * ARISTOS_MULTI_SX_X); // multiplus largest
				TimeTo = m_lastWriteTime;
			}
		}
	}
	CQueueManager *pQM = CQueueManager::GetHandle();
	CQMDiskServices &ds = pQM->GetDiskServices();
	CChartQManager *CM = CChartQManager::GetHandle();
	CM->m_midtime = (TimeFrom + TimeTo) / 2;
	// earlier data required?
	if (TimeFrom < m_pHead->m_StartTime) {
		// To try and get better filling on our blocks.
		// calc Glb_RecsPerBlock blocks prior to head, and if this is before Timefrom, we use that instead.
		// if we have a larger span to request, we ensure it is a multiple of Glb_RecsPerBlock blocks.
		// In both cases we extend the TimeFrom in an earlier direction.
		// LONGLONG blockspan=(Glb_RecsPerBlock*MAX_REC_READINGS)*m_Tpp;
		// see how TimeTo compares with m_pHead->m_StartTime (which could be a long way off)
		// Also Head can be tail block for a new queue
		if (TimeTo > m_pHead->m_StartTime)
			TimeTo = m_pHead->m_StartTime; // can reduce it here
		CChartBlock *requestblock = ReuseOrAddNewBlock(0); // 0=default size
		if (requestblock == NULL) {
			m_OutstandingRequest = FALSE;
			DebugBreak();
			return FALSE; // no mem.
		}
		requestblock->m_StartTime = TimeFrom;
		requestblock->m_EndTime = TimeTo; // only need to go as far as this
		requestblock->m_Type = CBLK_REQUESTED;
#ifdef _DEBUG
    if((m_PenIndex==penIndexToUse) && SHOWREQ)	// todo remove
    qDebug("2 xx REV START %s END %s  st:%I64d  end:%I64d  Q=%d \n",FS(requestblock->m_StartTime), FE(requestblock->m_EndTime),requestblock->m_StartTime, requestblock->m_EndTime, m_QHandle );
#endif
		m_pRequestblock = requestblock;
		//PSR Fix for PAR# 1-3KC14ZV - Circular Chart_Could not plot all data in history mode begin
		//Get the recs per block based on chart Q type
		int nRecsPerBlock = GetRecsPerBlock();
		//PSR Fix for PAR# 1-3KC14ZV - Circular Chart_Could not plot all data in history mode end
		//  more efficient to go backwards
		if (ds.GetPrevBlocksFromStartTime(USRREQSER_USER_OPPANEL, m_QHandle, requestblock->m_EndTime, // use Endtime here, since get previous!
				nRecsPerBlock, (BYTE*) m_pRequestblock->GetDataRec()) != QMDSKSER_OK) {
			delete m_pRequestblock;
			m_OutstandingRequest = FALSE;
			qDebug("  <QUEUE FULL>\n");
		} else
			m_InitialRequest = FALSE;
		return TRUE;	 // all done
	}
	BOOL UseGetPrevBlocks = FALSE; // default is to go forwards..
	if (TimeTo >= m_pTail->m_StartTime) {
		TimeTo = m_pTail->m_StartTime;
		if (TimeTo <= TimeFrom) {
			m_OutstandingRequest = FALSE;
			m_InitialRequest = FALSE;
			return FALSE;	 // all done
		}
		UseGetPrevBlocks = TRUE; // but here we know we want to go backwards
	}
	// later data wanted ?
	if (m_pTail->m_pPrev) {
		// need to check start time of the tail block... it may all be there already.
		if ((m_pTail->m_StartTime > m_pTail->m_pPrev->m_EndTime) // there is a gap before the tail block
		&& (TimeTo > m_pTail->m_pPrev->m_EndTime)) // and our timeto falls within it
				{
			if (TimeFrom < m_pTail->m_pPrev->m_EndTime)
				TimeFrom = m_pTail->m_pPrev->m_EndTime; // can reduce span required here
			if (TimeTo <= TimeFrom) {
				m_OutstandingRequest = FALSE;
				m_InitialRequest = FALSE;
				return FALSE;	 // all done
			}
			CChartBlock *requestblock = ReuseOrAddNewBlock(0); // 0=default size
			if (requestblock == NULL) {
				m_OutstandingRequest = FALSE;
				DebugBreak();
				return FALSE; // no mem.
			}
			requestblock->m_StartTime = TimeFrom;
			requestblock->m_EndTime = TimeTo;
			requestblock->m_Type = CBLK_REQUESTED;
			m_pRequestblock = requestblock;
			if (!UseGetPrevBlocks) {
#ifdef _DEBUG
      if((m_PenIndex==penIndexToUse) && SHOWREQ)	// todo remove
        qDebug("3 xx FOR START %s END %s  st:%I64d  end:%I64d\n",FS(requestblock->m_StartTime), FE(requestblock->m_EndTime),requestblock->m_StartTime, requestblock->m_EndTime );
#endif
				//PSR Fix for PAR# 1-3KC14ZV - Circular Chart_Could not plot all data in history mode begin
				//Get the recs per block based on chart Q type
				int nRecsPerBlock = GetRecsPerBlock();
				//PSR Fix for PAR# 1-3KC14ZV - Circular Chart_Could not plot all data in history mode end
				if (ds.GetNextBlocksFromStartTime(USRREQSER_USER_OPPANEL, m_QHandle, requestblock->m_StartTime,
						nRecsPerBlock, (BYTE*) m_pRequestblock->GetDataRec()) != QMDSKSER_OK) {
					delete m_pRequestblock;
					m_OutstandingRequest = FALSE;
					qDebug("  <QUEUE FULL>\n");
				} else
					m_InitialRequest = FALSE;
			} else {
#ifdef _DEBUG
      if((m_PenIndex==penIndexToUse) && SHOWREQ)	// todo remove
        qDebug("3 xx REV START %s END %s  st:%I64d  end:%I64d\n",FS(requestblock->m_StartTime), FE(requestblock->m_EndTime),requestblock->m_StartTime, requestblock->m_EndTime );
#endif
				//PSR Fix for PAR# 1-3KC14ZV - Circular Chart_Could not plot all data in history mode begin
				//Get the recs per block based on chart Q type
				int nRecsPerBlock = GetRecsPerBlock();
				//PSR Fix for PAR# 1-3KC14ZV - Circular Chart_Could not plot all data in history mode end
				if (ds.GetPrevBlocksFromStartTime(USRREQSER_USER_OPPANEL, m_QHandle, requestblock->m_EndTime, // use Endtime here, since get previous!
						nRecsPerBlock, (BYTE*) m_pRequestblock->GetDataRec()) != QMDSKSER_OK) {
					delete m_pRequestblock;
					m_OutstandingRequest = FALSE;
					qDebug("  <QUEUE FULL>\n");
				} else
					m_InitialRequest = FALSE;
			}
			return TRUE;	 // all done
		}
	}
	// here check the blocks for 'holes' in the range we require...
	// search from the head
	CChartBlock *pBlock = m_pHead;
	while (pBlock && (pBlock != m_pTail)) {
		// find blocks that overlap with time span.
		if (pBlock->m_EndTime >= TimeFrom) {
			if (pBlock->m_StartTime <= TimeTo) {
				// block is in range. check no gaps around it in range
				if (pBlock->m_StartTime > TimeFrom) {
					// check no gap to previous
					if (pBlock->m_pPrev->m_EndTime < pBlock->m_StartTime) {
						// request timefrom (or from end of previous block) to start of block
						TimeTo = pBlock->m_StartTime; // we know we are shortening here
						// see how TimeFrom compares with pBlock->m_pPrev->m_EndTime (which could be a long way off)
						if (TimeFrom < pBlock->m_pPrev->m_EndTime)
							TimeFrom = pBlock->m_pPrev->m_EndTime; // can reduce it here
						CChartBlock *requestblock = ReuseOrAddNewBlock(0); // 0=default size
						if (requestblock == NULL) {
							m_OutstandingRequest = FALSE;
							DebugBreak();
							return FALSE; // no mem.
						}
						requestblock->m_StartTime = TimeFrom;
						requestblock->m_EndTime = TimeTo;
						requestblock->m_Type = CBLK_REQUESTED;
#ifdef _DEBUG
        if((m_PenIndex==penIndexToUse) && SHOWREQ)	// todo remove
          qDebug("4 xx REV START %s END %s  st:%I64d  end:%I64d\n",FS(requestblock->m_StartTime), FE(requestblock->m_EndTime),requestblock->m_StartTime, requestblock->m_EndTime );
#endif
						m_pRequestblock = requestblock;
						//PSR Fix for PAR# 1-3KC14ZV - Circular Chart_Could not plot all data in history mode begin
						//Get the recs per block based on chart Q type
						int nRecsPerBlock = GetRecsPerBlock();
						//PSR Fix for PAR# 1-3KC14ZV - Circular Chart_Could not plot all data in history mode end
						if (ds.GetPrevBlocksFromStartTime(USRREQSER_USER_OPPANEL, m_QHandle, requestblock->m_EndTime, // use Endtime here, since get previous!
								nRecsPerBlock, (BYTE*) m_pRequestblock->GetDataRec()) != QMDSKSER_OK) {
							delete m_pRequestblock;
							m_OutstandingRequest = FALSE;
							qDebug("  <QUEUE FULL>\n");
						} else
							m_InitialRequest = FALSE;
						return TRUE;
					}
				}
				if (pBlock->m_EndTime <= TimeTo) {
					// check no gap to next
					if (pBlock->m_EndTime < pBlock->m_pNext->m_StartTime) {
						// request block endTime to TimeTo
						TimeFrom = pBlock->m_EndTime;
						// see how TimeTo compares with pBlock->pNext->m_StartTime (which could be a long way off)
						if (TimeTo > pBlock->m_pNext->m_StartTime)
							TimeTo = pBlock->m_pNext->m_StartTime; // can reduce it here
						CChartBlock *requestblock = ReuseOrAddNewBlock(0); // 0=default size
						if (requestblock == NULL) {
							m_OutstandingRequest = FALSE;
							DebugBreak();
							return FALSE; // no mem.
						}
						requestblock->m_StartTime = TimeFrom;
						requestblock->m_EndTime = TimeTo;
						requestblock->m_Type = CBLK_REQUESTED;
#ifdef _DEBUG
        if((m_PenIndex==penIndexToUse) && SHOWREQ)	// todo remove
          qDebug("5 xx FOR START %s END %s  st:%I64d  end:%I64d\n",FS(requestblock->m_StartTime), FE(requestblock->m_EndTime),requestblock->m_StartTime, requestblock->m_EndTime );
#endif
						m_pRequestblock = requestblock;
						//PSR Fix for PAR# 1-3KC14ZV - Circular Chart_Could not plot all data in history mode begin
						//Get the recs per block based on chart Q type
						int nRecsPerBlock = GetRecsPerBlock();
						//PSR Fix for PAR# 1-3KC14ZV - Circular Chart_Could not plot all data in history mode end
						if (ds.GetNextBlocksFromStartTime(USRREQSER_USER_OPPANEL, m_QHandle, requestblock->m_StartTime,
								nRecsPerBlock, (BYTE*) m_pRequestblock->GetDataRec()) != QMDSKSER_OK) {
							delete m_pRequestblock;
							m_OutstandingRequest = FALSE;
							qDebug("  <QUEUE FULL>\n");
						} else
							m_InitialRequest = FALSE;
						return TRUE;
					}
				}
			} else {
				// here we have gone past the range - see if we need to make a request!
				if (pBlock->m_pPrev->m_EndTime < TimeFrom) {
					// calc approx number of disk blocks to request...
					//int numRecs=CalcNumRecs(TimeFrom,TimeTo);
					CChartBlock *requestblock = ReuseOrAddNewBlock(0); // 0=default size
					if (requestblock == NULL) {
						m_OutstandingRequest = FALSE;
						return FALSE; // no mem.
					}
					requestblock->m_StartTime = TimeFrom;
					requestblock->m_EndTime = TimeTo;
					requestblock->m_Type = CBLK_REQUESTED;
#ifdef _DEBUG
        if((m_PenIndex==penIndexToUse) && SHOWREQ)	// todo remove
        qDebug("6 xx START %s END %s  st:%I64d  end:%I64d\n",FS(requestblock->m_StartTime), FE(requestblock->m_EndTime),requestblock->m_StartTime, requestblock->m_EndTime );
#endif
					m_pRequestblock = requestblock;
					//PSR Fix for PAR# 1-3KC14ZV - Circular Chart_Could not plot all data in history mode begin
					//Get the recs per block based on chart Q type
					int nRecsPerBlock = GetRecsPerBlock();
					//PSR Fix for PAR# 1-3KC14ZV - Circular Chart_Could not plot all data in history mode end
					if (ds.GetNextBlocksFromStartTime(USRREQSER_USER_OPPANEL, m_QHandle, requestblock->m_StartTime,
							nRecsPerBlock,        // numRecs,
							(BYTE*) m_pRequestblock->GetDataRec()) != QMDSKSER_OK) {
						delete m_pRequestblock;
						m_OutstandingRequest = FALSE;
						qDebug("  <QUEUE FULL>\n");
					} else
						m_InitialRequest = FALSE;
					return TRUE;
				} else {
					m_OutstandingRequest = FALSE;
					m_InitialRequest = FALSE;
					return FALSE; // nothing to do!
				}
			}
		}
		pBlock = pBlock->m_pNext;
	}
	m_OutstandingRequest = FALSE;
	m_InitialRequest = FALSE;
	return FALSE;
}
//PSR Fix for PAR# 1-3N5DCMN - Recorder hung while menu navigation, followed by Real time to history mode in circular chart begin
//****************************************************************************
/// check the queue for the given timespan for circular chart (history or Realtime).
/// This function adjusts the circi history time span based on the TimeFrom and TimeTo requested span
/// and reuses strip chart checkqueue for remainig validation
///
/// @param[in] TimeFrom		- time to check from
/// @param[in] TimeTo		- time to check up to
///
/// @return T/F  T=request added or busy
///
//****************************************************************************
BOOL CChartQ::CheckQueue(bool bIsHistoryMode, LONGLONG TimeFrom, LONGLONG TimeTo) {
	if (false == bIsHistoryMode) //that is circi chart in realtime mode
			{
		//Resuse the Strip chart check queue as there were no issue found in realtime mode
		return CheckQueue(TimeFrom, TimeTo);
	} else {
		if (!m_pHead)
			return FALSE;
		LONGLONG lnCirciTimeFrom = TimeFrom;
		LONGLONG lnCirciTimeTo = TimeTo;
		if (m_InitialRequest) // this happens on screen changes and layout updates etc
		{
			//PSR Fix for PAR# 1-3KC14ZV - Circular Chart_Could not plot all data in history mode begin
			if (0 == TimeFrom && 0 == TimeTo) {
				//Earlier case so reuse same logic
				//  Verify changes.....
				//TimeFrom=m_lastWriteTime-(m_Tpp*800); // multiplus largest
				lnCirciTimeFrom = m_lastWriteTime - (m_Tpp * ARISTOS_MULTI_SX_X); // multiplus largest
				lnCirciTimeTo = m_lastWriteTime;
			} else if (0 == TimeFrom) {
				//If no "time from" provided then use existing logic
				lnCirciTimeFrom = m_lastWriteTime - (m_Tpp * ARISTOS_MULTI_SX_X); // multiplus largest
			} else if (0 == TimeTo) {
				//If no "time to" provided then use existing logic
				lnCirciTimeTo = m_lastWriteTime;
			} else {
				//Check for the speacial case where Head block time is zero and we are requesting the Time other than zero
				//The chances are like not getting the history data
				//Or Current realtime data just completed one circi and became history data
				if (0 != TimeFrom && 0 == m_pHead->m_StartTime) {
					QString strError("");
					strError = QString::asprintf(
							"CheckQueue - Head StartTime(%ld), Requested TimeFrom(%ld) and TimeTo(%ld)",
							m_pHead->m_StartTime, TimeFrom, TimeTo);
					LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_INFO, strError);
					////to work as earlier code where CheckQueue called with (0,0).
					lnCirciTimeFrom = 0;
				}
			}
			//else use the values that are passed in arguments
			//PSR Fix for PAR# 1-3KC14ZV - Circular Chart_Could not plot all data in history end
		}
		//qDebug( L"CheckQueue - Head StartTime(%d), Requested TimeFrom(%d) and TimeTo(%d)\n", m_pHead->m_StartTime, lnCirciTimeFrom, lnCirciTimeTo);
		return CheckQueue(lnCirciTimeFrom, lnCirciTimeTo);
	}
	return FALSE;
}
int CChartQ::GetRecsPerBlock() {
	int nRecsPerBlock = Glb_RecsPerBlock;
	//PSR Fix for PAR# 1-3KC14ZV - Circular Chart_Could not plot all data in history mode begin
	if (CQT_CIRCULAR == m_chartQueueType) {
		nRecsPerBlock = Glb_CirciRecsPerBlock;
	}
	//PSR Fix for PAR# 1-3KC14ZV - Circular Chart_Could not plot all data in history mode end
	return nRecsPerBlock;
}
int CChartQ::GetMaxQBlocks() {
	int nMaxQBlocks = Glb_MaxQBlocks;
	//PSR Fix for PAR# 1-3KC14ZV - Circular Chart_Could not plot all data in history mode begin
	if (CQT_CIRCULAR == m_chartQueueType) {
		nMaxQBlocks = Glb_MaxCirciQBlocks;
	}
	//PSR Fix for PAR# 1-3KC14ZV - Circular Chart_Could not plot all data in history mode end
	return nMaxQBlocks;
}
//PSR Fix for PAR# 1-3N5DCMN - Recorder hung while menu navigation, followed by Real time to history mode in circular chart end
//****************************************************************************
/// Inserts a block into our Queue after the position specified.
///
/// @param[in] plistPos		- pointer to block to insert after (can be NULL)
/// @param[in] pNewBlock	- pointer to block to insert
///
/// @return none
///
//****************************************************************************
void CChartQ::InsertBlock(CChartBlock *plistPos, CChartBlock *pNewBlock) {
	if (m_pHead) {
		if (plistPos == NULL) {
			// insert at head
			pNewBlock->m_pNext = m_pHead;
			m_pHead->m_pPrev = pNewBlock;
			m_pHead = pNewBlock;
		} else {
			if (pNewBlock->m_pNext = plistPos->m_pNext) // at end of list?
				plistPos->m_pNext->m_pPrev = pNewBlock; // no, assign prev pointer
			else
				m_pTail = pNewBlock; // yes, set as new tail
			plistPos->m_pNext = pNewBlock;
			pNewBlock->m_pPrev = plistPos;
		}
	} else {
		// must be insert at head, and head is null.
		m_pHead = pNewBlock;
		m_pTail = pNewBlock;
		pNewBlock->m_pPrev = NULL;
		pNewBlock->m_pNext = NULL;
	}
}
//****************************************************************************
/// Deletes a block from the queue
///
/// @param[in] pBlock		- pointer to block to delete
///
/// @return none
///
//****************************************************************************
void CChartQ::DeleteBlock(CChartBlock *pBlock) {
	if (pBlock->m_pNext)
		pBlock->m_pNext->m_pPrev = pBlock->m_pPrev;
	else
		m_pTail = pBlock->m_pPrev;
	if (pBlock->m_pPrev)
		pBlock->m_pPrev->m_pNext = pBlock->m_pNext;
	else
		m_pHead = pBlock->m_pNext;
	delete pBlock;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  CChartBlock
//
///////////////////////////////////////////////////////////////////////////////////////////////////////
//****************************************************************************
/// CChartBlock Constructor
///
/// @param[in] pParent		- pointer to parent ChartQ
///
//****************************************************************************
CChartBlock::CChartBlock(CChartQ *pParent) {
	m_pParent = pParent;
	m_StartTime = 0;
	m_EndTime = 0;
	m_DataEndTime = 0;
	m_FirstRec = 0;
	m_UsedRecs = 0;
	m_TotalRecs = 0;
	m_pRecs = NULL;
	m_pWriteRec = NULL;
	m_pCurrent = NULL;
	m_pNext = NULL;
	m_pPrev = NULL;
	m_Type = CBLK_NORMAL;
	m_pQMdblock = NULL;
	if (m_pParent->m_IsSRAM)
		m_pQMdblock = new CQMDataBlock();
	m_pParent->m_NumBlocks++;
}
//****************************************************************************
/// CChartBlock Destructor
///
/// @param none
///
//****************************************************************************
CChartBlock::~CChartBlock() {
	if (m_pRecs && !m_pParent->m_IsSRAM)
		delete[] m_pRecs;
	m_pRecs = NULL;
	if (m_pParent->m_IsSRAM)
		delete m_pQMdblock;
	m_pQMdblock = NULL;
	m_pParent->m_NumBlocks--;
}
//****************************************************************************
/// Create the data records
///
/// @param none
///
/// @return TRUE/FALSE
///
//****************************************************************************
BOOL CChartBlock::CreateRecs(int NumRecs) //=0
		{
	m_UsedRecs = 1; // use up to this rec (less 1 for index)
	if (m_pParent->m_IsSRAM) {
		// here set up our CChartBlock to contain a pointer to a single SRAM ChartRec
		// We always get a new empty SRAM rec at startup.
		CQueueManager *pQM = CQueueManager::GetHandle();
		CQMBlockServices &bs = pQM->GetBlockServices();
		T_QMBLKSER_RETURN_VALUE retVal;
		retVal = bs.GetLastDataBlock(m_pParent->m_QHandle, *m_pQMdblock);
		if (retVal == QMBLKSER_NO_LAST_DATA_BLOCK)
			retVal = bs.GetFreeDataBlock(m_pParent->m_QHandle, *m_pQMdblock);  // get a new one
		else {
			// there is a block in SRAM for us - have we used it at all?
			if (m_pQMdblock->GetBlockStatus() == QMC_BLKSTATUS_IN_USE) {
				// it's in use, so not actually been used yet.
				qDebug("-=-=-= Continuing with previous block =-=-=-\n");
			} else
				// otherwise get a new one
				retVal = bs.GetFreeDataBlock(m_pParent->m_QHandle, *m_pQMdblock);
		}
		m_pQMdblock->SetDataBlockType(m_pParent->m_QueueType);
		m_pRecs = (ChartRec*) m_pQMdblock->GetDataBlock();
		m_TotalRecs = 1; // 1 SRAM rec per block
		if (m_pRecs == NULL) {
			QString strError("");
			strError = QString::asprintf("ChartQueues: createRecs no free SRAM blocks, error code %u", retVal);
    V6CriticalMessageBox(NULL, strError, "Error", MB_OK );
		}
	} else {
		//PSR Fix for PAR# 1-3KC14ZV - Circular Chart_Could not plot all data in history mode begin
		//Get the recs per block based on chart Q type
		int nRecsPerBlock = m_pParent->GetRecsPerBlock();
		//PSR Fix for PAR# 1-3KC14ZV - Circular Chart_Could not plot all data in history mode end
		if (NumRecs == 0)  // default number of recs requested for normal running.
			m_TotalRecs = nRecsPerBlock;
		else {
			// making a request in replay mode...
			if (NumRecs < nRecsPerBlock)
				NumRecs = nRecsPerBlock; // here ensure we have a rresonable amount in the block, which may later get
			else						  // reused when not in replay mode
			if (NumRecs > QMC_MAX_BLOCKS_ALLOWED_FOR_ONE_REQUEST)
				NumRecs = QMC_MAX_BLOCKS_ALLOWED_FOR_ONE_REQUEST;
			m_TotalRecs = NumRecs;
		}
		m_pRecs = new ChartRec[m_TotalRecs];
		if (m_pRecs == NULL) {
    V6CriticalMessageBox(NULL, "ChartQueues: createrecs no memory for blocks", "Error", MB_OK );
		}
		// todo remove this before release...
		//memset(m_pRecs,0x55,sizeof(ChartRec)*m_TotalRecs); // fill with 0x55
		m_pRecs->hdr.penNo = 100; // set this to non valid pen no.
	}
	m_pWriteRec = m_pRecs; // point to first record (ready to add readings)
	m_pWriteRec->hdr.numReadings = 0;
	return TRUE;
}
//****************************************************************************
/// Resets the block for use again.
///
/// @param none
///
/// @return none
///
//****************************************************************************
void CChartBlock::Reset(int NumRecs) //=0
		{
	if (m_pParent->m_IsSRAM) {
		// here we are done with the previous SRAM ChartRec
		SetBlockStatus(QMC_BLKSTATUS_COMPLETE);
		CQueueManager *pQM = CQueueManager::GetHandle();
		CQMBlockServices &bs = pQM->GetBlockServices();
		// and we get another free one
		T_QMBLKSER_RETURN_VALUE retVal = bs.GetFreeDataBlock(m_pParent->m_QHandle, *m_pQMdblock);
		m_pQMdblock->SetDataBlockType(m_pParent->m_QueueType);
		m_pRecs = (ChartRec*) m_pQMdblock->GetDataBlock();
		if (m_pRecs == NULL) {
			QString strError("");
			strError = QString::asprintf("ChartQueues: no free SRAM blocks, error code %u", retVal);
			V6CriticalMessageBox(NULL, strError, "Error", MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST);
		}
	} else  // volatile queue blocks
	{
		//PSR Fix for PAR# 1-3KC14ZV - Circular Chart_Could not plot all data in history mode begin
		//Get the recs per block based on chart Q type
		int nRecsPerBlock = m_pParent->GetRecsPerBlock();
		//PSR Fix for PAR# 1-3KC14ZV - Circular Chart_Could not plot all data in history mode end
		if (NumRecs > 0) {
			// making a request in replay mode...
			if (NumRecs < nRecsPerBlock)
				NumRecs = nRecsPerBlock; // here ensure we have a reasonable amount in the block, which may later get
			else    // reused when not in replay mode
			if (NumRecs > QMC_MAX_BLOCKS_ALLOWED_FOR_ONE_REQUEST)
				NumRecs = QMC_MAX_BLOCKS_ALLOWED_FOR_ONE_REQUEST;
		} else
			NumRecs = nRecsPerBlock;
		// so we require at least NumRecs...
		if (m_pRecs == NULL) {
			// this is a CBLK_NODATA block...
			m_pRecs = new ChartRec[NumRecs];
			m_TotalRecs = NumRecs;
			m_Type = CBLK_NORMAL; // set type back to normal.
		} else {
			if (m_TotalRecs < NumRecs) {
				delete[] m_pRecs; // delete the older block of records (too small)
				m_TotalRecs = NumRecs;
				m_pRecs = new ChartRec[m_TotalRecs]; // allocate the correct amount
			}
		}
		if (m_pRecs == NULL) {
			V6CriticalMessageBox(NULL, L"ChartQueues: no memory for blocks", L"Error",
        MB_OK );
		}
		// todo remove this before release...
		//memset(m_pRecs,0x55,sizeof(ChartRec)*m_TotalRecs); // fill with 0x55
		m_pRecs->hdr.penNo = 100; // set this to non valid pen no.
	}
	// if not changed above m_TotalRecs remains as before
	m_FirstRec = 0;
	m_UsedRecs = 1;
	m_pWriteRec = m_pRecs; // point to first record (ready to add readings)
	m_pWriteRec->hdr.numReadings = 0;
}
//****************************************************************************
/// Copy a block to this block
///
/// @param none
///
/// @return none
///
//****************************************************************************
void CChartBlock::Copy(CChartBlock *pSource) {
	// copy the appropriate members etc (not pointers to data blocks etc)
	m_UsedRecs = pSource->m_UsedRecs;		// should be 1
	m_FirstRec = pSource->m_FirstRec;		// should be 0
	m_StartTime = pSource->m_StartTime;
	m_EndTime = pSource->m_EndTime;
	m_DataEndTime = pSource->m_DataEndTime;
	// copy the data acrosss (one record only)
	memcpy(m_pRecs, pSource->m_pRecs, sizeof(ChartRec));
	// now set writing position etc.
	m_pWriteRec = m_pRecs;
	m_pCurrent = &m_pWriteRec->readings[m_pRecs->hdr.numReadings];
	m_pParent->m_lastWriteTime = m_EndTime - m_pParent->m_Tpp;
}
//****************************************************************************
/// Copy a block to partway through this block
///
/// @param none
///
/// @return T/F - TRUE if room to do it.
///
//****************************************************************************
BOOL CChartBlock::CopyToExistingBlock(CChartBlock *pSource) {
	// copy the appropriate members etc (not pointers to data blocks etc)
	// check to see if there is at least 1 record in the existing block to copy the current SRAM block into
	if (m_pRecs != NULL) {
		if (m_UsedRecs + 1 <= m_TotalRecs) {
			m_UsedRecs++;
			m_EndTime = pSource->m_EndTime;
			m_DataEndTime = pSource->m_DataEndTime;
			m_pWriteRec = &m_pRecs[m_UsedRecs - 1];
			// copy the data acrosss (one record only)
			memcpy(m_pWriteRec, pSource->m_pRecs, sizeof(ChartRec));
			// now set writing position etc.
			m_pCurrent = &m_pWriteRec->readings[m_pWriteRec->hdr.numReadings];
			m_pParent->m_lastWriteTime = m_DataEndTime - m_pParent->m_Tpp;
			return TRUE;
		}
	}
	return FALSE;
}
void CChartBlock::SetBlockStatus(T_QMC_BLOCK_STATUS status) {
	m_pQMdblock->SetBlockStatus(status);
}
T_QMC_BLOCK_STATUS CChartBlock::GetBlockStatus() {
	return m_pQMdblock->GetBlockStatus();
}
//****************************************************************************
/// Prefills complete block with maxmin readings
///
/// @param[in] startTime100		- time of the start of the reading (100ths sec)
/// @param[in] reading			- max-min value pair
///
/// @return none
///
//****************************************************************************
void CChartBlock::Prefill(LONGLONG startTime100, ChartReading reading) {
	m_StartTime = startTime100;
	for (int rec = 0; rec < m_TotalRecs; rec++) {
		// set up the first record header
		//		  rec  starttime pen					  rateindex
		InitRecHeader(&m_pRecs[rec], startTime100, m_pParent->m_PenIndex, m_pParent->m_rateIndex);
		for (int index = 0; index < MAX_REC_READINGS; index++)
			m_pRecs[rec].readings[index] = reading;
		m_pRecs[rec].hdr.numReadings = MAX_REC_READINGS;
		startTime100 += m_pParent->m_Tpp * MAX_REC_READINGS;
	}
	m_UsedRecs = m_TotalRecs;
	m_EndTime = startTime100; // now at the end
	m_DataEndTime = m_EndTime;
}
//****************************************************************************
/// Initialises the record header with the parameters passed
///
/// @param[in] pRec			- pointer to record structure to init
/// @param[in] startTime	- record start time (time of start of the first reading)
/// @param[in] penNo		- pen number (0 based)
/// @param[in] rateIndex	- rate index (used to look up rate)
///
/// @return none
///
//****************************************************************************
void CChartBlock::InitRecHeader(ChartRec *pRec, LONGLONG startTime, USHORT penNo, BYTE rateIndex) {
	pRec->hdr.numReadings = 0;
	pRec->hdr.startTimeL = ((LARGE_INTEGER*) &startTime)->LowPart;
	pRec->hdr.startTimeH = (char) (((LARGE_INTEGER*) &startTime)->HighPart & 0x000000ff); // bottom byte of high part
	pRec->hdr.penNo = (BYTE) penNo;
	pRec->hdr.rateIndex = rateIndex;
	pRec->hdr.unused = 0;
}
//****************************************************************************
/// Adds a new reading (or updates the last a reading) in the block.
/// (All readings are max min)
///
/// @param[in] readingTime100	- time of the start of the reading (100ths sec)
/// @param[in] maxv				- max value
/// @param[in] minv				- min value
///
/// @return TRUE if added/updated ok, FALSE if the block is full
///
//****************************************************************************
BOOL CChartBlock::AddReading(LONGLONG readingTime100, float maxv, float minv) {
	// for a new empty block m_StartTime and m_EndTime will be the same
	if (m_StartTime == m_EndTime) {
		//		if((m_pParent->m_QHandle==3)&&(!m_pParent->m_IsSRAM))
		//			qDebug("start==end\n");
		// if initial block, m_StartTime will be already set up with initial time.
		// Otherwise it will be the previous blocks endtime
		// set up the first record header
		//		  rec  starttime  pen					 rateindex
		InitRecHeader(m_pWriteRec, m_StartTime, m_pParent->m_PenIndex, m_pParent->m_rateIndex);
		if (m_pParent->m_IsSRAM)
			m_pQMdblock->SetDataBlockComplete();  // now it's init'ed, mark it as a valid SRAM block
		m_pCurrent = &m_pWriteRec->readings[0]; // set pointer to first reading
	}
	// m_EndTime is always '1 reading ahead' of our last reading time added.
	// if the time passed in is the time of the previous reading, it's an update.
	// (can't happen for new block)
	else if (m_EndTime == readingTime100 + m_pParent->m_Tpp) {
		// we are 'updating' the last reading.
		//		if((m_pParent->m_QHandle==3)&&(!m_pParent->m_IsSRAM))
		//			qDebug("old max= %.3f new max= %.3f  index %d\n",(m_pCurrent-1)->maxv,maxv,m_pWriteRec->hdr.numReadings-1 );
		(m_pCurrent - 1)->maxv = maxv;
		(m_pCurrent - 1)->minv = minv;
		return TRUE; // done update
	}
	//	if((m_pParent->m_QHandle==3)&&(!m_pParent->m_IsSRAM))
	//	{
	//		qDebug("adding next reading index=%d\n",m_pWriteRec->hdr.numReadings-1);
	//		qDebug("start =%d  ",m_pWriteRec->hdr.startTimeL);
	//
	//		for(int index=0; index<m_pWriteRec->hdr.numReadings; index++)
	//		{
	//			qDebug("%0.0f ",m_pWriteRec->readings[index].maxv);
	//		}
	//		qDebug("\n");
	//	}
	// need to move on and add next reading
	BOOL done = FALSE;
	do {
		// Did we fill the current record when we added the last reading?
		if (m_pWriteRec->hdr.numReadings == MAX_REC_READINGS) {
			// need to go onto next record in block
			m_UsedRecs++;
			// is the number of used records the total in the block?
			if (m_UsedRecs > m_TotalRecs) {
				// the complete block is full. Need to add another block on
				m_UsedRecs--;
				return FALSE; // indicate this by returning FALSE (unfinished)
			} else {
				// move on to the next record in the block
				m_pWriteRec++;
				//		  rec  starttime  pen					 rate
				InitRecHeader(m_pWriteRec, m_EndTime, m_pParent->m_PenIndex, m_pParent->m_rateIndex);
				m_pCurrent = &m_pWriteRec->readings[0]; // set pointer to first reading
			}
		}
		// put this in for now
		//#ifdef _DEBUG
		if (m_EndTime > readingTime100) {
			qDebug("[>[>[>[>[>[ Endtime too large ]<]<]<]<]<]\n");
			if (V6_RELEASE != RELEASE_PRODUCTION) // in non-production builds only (we can get a lot of these)
				LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "Endtime too large");
			m_EndTime = readingTime100;
		}
		//#endif
		// m_EndTime is always '1 reading ahead' of our last reading time added.
		// So here the times should be the same
		if (m_EndTime == readingTime100) {
			// enter our values and increment the endtime
			m_pCurrent->maxv = maxv;
			m_pCurrent->minv = minv;
			// increment ready for next time.
			m_pCurrent++;
			m_pWriteRec->hdr.numReadings++;
			m_EndTime += m_pParent->m_Tpp;
			m_DataEndTime = m_EndTime;
			return TRUE;
		}
		// not the same time, so we presume we have missed readings
		// fill in missing readings with NaN - however, charting has been optimised by removing code that deals with these
		//m_pCurrent->uexp=MISSING_READING;
		//MarkD: copy the same value as last time into any missing fields - this gives 'graceful degradation'
		// enter our values and increment the endtime
		m_pCurrent->maxv = maxv;
		m_pCurrent->minv = minv;
		// increment for this missed reading
		m_pCurrent++;
		m_pWriteRec->hdr.numReadings++;
#ifdef _DEBUG
    // todo remove
    if(m_pParent->m_IsSRAM)
    qDebug(" missing SRAM - %d\n",m_pWriteRec->hdr.numReadings);
    else
    qDebug(" missing mem - %d\n",m_pWriteRec->hdr.numReadings);
#endif
		m_EndTime += m_pParent->m_Tpp;
		m_DataEndTime = m_EndTime;
	} while (!done);
	return TRUE;
}
//****************************************************************************
/// Gets the first reading from the block at a specified time
///
/// @param[in] eCHART_QUEUE_TYPE - the chart queue type i.e. circular or strip
/// @param[in] rc	- pointer to ReadContext structure containing time to find
///
/// @return CHARTRET:  DATA_OK, NO_MORE_DATA
///
//****************************************************************************
CHARTRET CChartBlock::GetFirstReading(ReadContext *rc, const CHART_QUEUE_TYPES eCHART_QUEUE_TYPE) {
	// locate the reading within the records
	// this version now works for non-contiguous records in the block.
	rc->m_recIndex = m_FirstRec;
	do {
		rc->m_pRec = &m_pRecs[rc->m_recIndex];
		LARGE_INTEGER start;
		start.HighPart = rc->m_pRec->hdr.startTimeH;
		start.LowPart = rc->m_pRec->hdr.startTimeL;
		// if the reading time required is less than the starttime of the data, return the 1st reading
		if (rc->m_LocateTime <= start.QuadPart) {
			// set pointer to required reading
			rc->m_readingIndex = 0;
			rc->m_pReading = &rc->m_pRec->readings[rc->m_readingIndex];
			//PSR Fix for - 1-3GKDZ7Q - charting issues with slow speed begin
			//Use recorder specific Rates instead of generic X-Series Rates
			rc->m_RecTpp = CChartQManager::GetRateAtIndex(eCHART_QUEUE_TYPE, rc->m_pRec->hdr.rateIndex);
			//PSR Fix for - 1-3GKDZ7Q - charting issues with slow speed end
			rc->m_ReadingTime = start.QuadPart;
			//			if(rc->m_pReading != &rc->m_pRec->readings[rc->m_readingIndex]) ///@todo remove test code
			//				MemTrace(100,L"NOT THE SAME!\n");
			MemTrace
			(m_pParent->m_PenIndex, L"GF1 %d %d %d blk %I64d  reading %I64d\n", rc->m_readingIndex, rc->m_pRec->hdr.numReadings, rc->m_recIndex, start.QuadPart, rc->m_ReadingTime);
			return DATA_OK;
		} else {
			// check less than endtime of rec..
			//PSR Fix for - 1-3GKDZ7Q - charting issues with slow speed begin
			//Use recorder specific Rates instead of generic X-Series Rates
			rc->m_RecTpp = CChartQManager::GetRateAtIndex(eCHART_QUEUE_TYPE, rc->m_pRec->hdr.rateIndex);
			//PSR Fix for - 1-3GKDZ7Q - charting issues with slow speed end
			LARGE_INTEGER end; // calc the end of data time for this rec (last reading time+1 reading) - last will be same as end of data of block
			end.QuadPart = start.QuadPart + rc->m_RecTpp * (rc->m_pRec->hdr.numReadings); // NOT less 1 reading (since first is AT start time)
			if (rc->m_LocateTime < end.QuadPart) // check LESS than here, since time == is start of next rec or block
					{
				UINT difftime = (UINT) (rc->m_LocateTime - start.QuadPart);
				rc->m_readingIndex = (difftime / rc->m_RecTpp);
				rc->m_pReading = &rc->m_pRec->readings[rc->m_readingIndex];
				// got a valid reading ok
				rc->m_ReadingTime = (rc->m_RecTpp * rc->m_readingIndex) + start.QuadPart;
				//				if(rc->m_pReading != &rc->m_pRec->readings[rc->m_readingIndex]) ///@todo remove test code
				//					MemTrace(100,L"NOT THE SAME!\n");
				MemTrace
				(m_pParent->m_PenIndex, L"GF2 %d %d %d blk %I64d  reading %I64d\n", rc->m_readingIndex, rc->m_pRec->hdr.numReadings, rc->m_recIndex, start.QuadPart, rc->m_ReadingTime);
				return DATA_OK;
			}
		}
		rc->m_recIndex++;
	} while (rc->m_recIndex < m_UsedRecs);
	// no reading here
	rc->m_readingIndex = MAX_REC_READINGS + 1; // set out of range
	return NO_MORE_DATA;
}
//****************************************************************************
/// Gets the next reading from the block after a previous successful call to
/// GetFirstReading()
///
/// @param[in] eCHART_QUEUE_TYPE - the chart queue type i.e. circular or strip
/// @param[in] rc	- pointer to ReadContext structure containing current
///					  position etc within the queue and block
///
/// @return CHARTRET:  DATA_OK, NO_MORE_DATA, END_OF_BLOCK
///
//****************************************************************************
CHARTRET CChartBlock::GetNextReading(ReadContext *rc, const CHART_QUEUE_TYPES eCHART_QUEUE_TYPE) {
	//	if(rc->m_readingIndex>MAX_REC_READINGS) ///@todo remove test code
	//		MemTrace(100,L"reading index too large!\n");
	rc->m_pReading++;  // increment the reading pointer (ready to read value from here)
	rc->m_readingIndex++; // index of item we will read
	rc->m_ReadingTime += rc->m_RecTpp;
	//	if(rc->m_pReading != &rc->m_pRec->readings[rc->m_readingIndex]) ///@todo remove test code
	//		MemTrace(100,L"NOT THE SAME!\n");
	if (rc->m_readingIndex < rc->m_pRec->hdr.numReadings) {
		///// todo remove this part
		//		LARGE_INTEGER start;
		//		start.HighPart=rc->m_pRec->hdr.startTimeH;
		//		start.LowPart=rc->m_pRec->hdr.startTimeL;
		//		MemTrace(m_pParent->m_PenIndex,L"  GN1 %d %d %d blk %I64d  reading %I64d\n",rc->m_readingIndex, rc->m_pRec->hdr.numReadings, rc->m_recIndex,  start.QuadPart, rc->m_ReadingTime);
		return DATA_OK;
	}
	//  move onto next record
	// try to move on..
	rc->m_recIndex++;
	if (rc->m_recIndex >= m_UsedRecs) {
		rc->m_readingIndex = MAX_REC_READINGS + 1; // set out of range
		rc->m_ReadingTime = -1; // set this out of range too
		return NO_MORE_DATA; // no more data in this block (at the moment)
	}
	// there are more records, so increment the record pointer
	// However, although these records are next to each other in the block, there could be a gap in time between them
	rc->m_pRec++;
	rc->m_readingIndex = 0;
	if (rc->m_readingIndex < rc->m_pRec->hdr.numReadings) {
		LARGE_INTEGER start;
		start.HighPart = rc->m_pRec->hdr.startTimeH;
		start.LowPart = rc->m_pRec->hdr.startTimeL;
		//PSR Fix for - 1-3GKDZ7Q - charting issues with slow speed begin
		//Use recorder specific Rates instead of generic X-Series Rates
		rc->m_RecTpp = CChartQManager::GetRateAtIndex(eCHART_QUEUE_TYPE, rc->m_pRec->hdr.rateIndex);
		//PSR Fix for - 1-3GKDZ7Q - charting issues with slow speed end
		rc->m_ReadingTime = start.QuadPart;
		// got a valid reading ok
		rc->m_pReading = &rc->m_pRec->readings[rc->m_readingIndex];
		//		MemTrace(m_pParent->m_PenIndex,L"  GN2 %d %d %d blk %I64d  reading %I64d\n",rc->m_readingIndex, rc->m_pRec->hdr.numReadings, rc->m_recIndex,  start.QuadPart, rc->m_ReadingTime);
		return DATA_OK;
	}
	// no reading here
	rc->m_readingIndex = MAX_REC_READINGS + 1; // set out of range
	rc->m_ReadingTime = -1; // set this out of range too
	return NO_MORE_DATA;
}
//****************************************************************************
/// Removes the data from the block and sets it as a space holder
///
/// @param[in] none
///
/// @return none
///
//****************************************************************************
void CChartBlock::RemoveData() {
	m_Type = CBLK_NODATA; // there is no data in this block, it's just a place holder
	// start and end times remain as requested.
	// delete the data recs.
	delete[] m_pRecs;
	m_pRecs = NULL;
}
//****************************************************************************
/// Validates the block
///
/// @param[in] NumRecs	- Number of Recs in the block.
///
/// @return none
///
//****************************************************************************
void CChartBlock::Validate(USHORT NumRecs, BOOL WasForwardReq, BOOL ReduceEndTime, BOOL IncreaseStartTime,
		const CHART_QUEUE_TYPES eCHART_QUEUE_TYPE) {
	if (NumRecs > m_TotalRecs) {
		V6WarningMessageBox(NULL, "ChartQueues.cpp: Line(3181) NumRecs>m_TotalRecs", "Debug Break",
				MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST);
	}
	m_UsedRecs = NumRecs;
	m_Type = CBLK_NORMAL; // assume for now (will get changed if not)
	if (m_UsedRecs == 0) {
		RemoveData(); // remove the data, keep the block (now 'freespace')
	} else {
		ChartRec *pRec = &m_pRecs[0];
		// this check already done before func called
		// also penNo is a better test
		/*
		 //todo - remove after testing..
		 if(pRec->hdr.numReadings>MAX_REC_READINGS)
		 {
		 qDebug("[] NO BLOCK (55) RETURNED FROM *PEN DATA* QUEUE for pen %d []\n",m_pParent->m_PenIndex);
		 //DebugBreak();
		 m_UsedRecs=0;
		 RemoveData();
		 m_StartTime=0; // make the data invalid for the calling function
		 m_EndTime=-1; // end less than start
		 return;
		 }
		 */
		// is the starttime of the data before the startime of the CChartBlock?
		// get data startime...
		LARGE_INTEGER recstarttime;
		recstarttime.LowPart = pRec->hdr.startTimeL;
		recstarttime.HighPart = pRec->hdr.startTimeH;
		// calc the data endtime...
		LARGE_INTEGER recendtime;
		pRec = &m_pRecs[m_UsedRecs - 1];
		//PSR Fix for - 1-3GKDZ7Q - charting issues with slow speed begin
		//Use recorder specific Rates instead of generic X-Series Rates
		UINT LastRecTpp = CChartQManager::GetRateAtIndex(eCHART_QUEUE_TYPE, pRec->hdr.rateIndex);
		//PSR Fix for - 1-3GKDZ7Q - charting issues with slow speed end
		recendtime.LowPart = pRec->hdr.startTimeL;
		recendtime.HighPart = pRec->hdr.startTimeH;
		// check to see if we have a full block - if so, we know the exact start time of the next one (m_DataEndTime)
		if (pRec->hdr.numReadings == MAX_REC_READINGS)
			m_DataEndTime = recendtime.QuadPart + (pRec->hdr.numReadings) * LastRecTpp; // first reading at start time. m_DataEndTime is +1 reading time
		else
			m_DataEndTime =
					recendtime.QuadPart + 1 + (pRec->hdr.numReadings - 1) * LastRecTpp; // here set m_DataEndTime time of last reading + 0.01 sec
					//////////////////////////////////////////////////////////////////// @todo remove this test code...
#ifdef _DEBUG
    if((m_pParent->m_PenIndex==penIndexToUse) && SHOWREQ)
    {
    if(WasForwardReq)
    {
      // we specified a start time....
      if(recstarttime.QuadPart<m_StartTime)
      {
        LONGLONG difft=(m_StartTime-recstarttime.QuadPart);
        if((difft/m_pParent->m_DrawingTpp)>63)
        qDebug(" ******************* Start  Block was earlier by %I64d secs  (%I64d pixels) \n",difft/100, difft/m_pParent->m_DrawingTpp);
      }
      else // we have exact or later block than requested.
      {
        LONGLONG difft=(recstarttime.QuadPart-m_StartTime);
        if(difft!=0)
        qDebug(" - Start  Block was later by %I64d secs  (%I64d pixels) \n",difft/100, difft/m_pParent->m_DrawingTpp);
      }
    }
    else // reverse (previous) requests
    {
      // we specified an end time.... end of data should end up at this time.
      if(m_DataEndTime<m_EndTime)
      {
        LONGLONG difft=(m_EndTime-m_DataEndTime);
        if((difft/m_pParent->m_DrawingTpp)>63)
        qDebug(" ******************* END  Block was earlier by %I64d secs  (%I64d pixels) \n",difft/100, difft/m_pParent->m_DrawingTpp);
      }
      else // we have exact or later block than requested.
      {
        LONGLONG difft=(m_DataEndTime-m_EndTime);
        if(difft!=0)
        {
        qDebug(" - End  Block was later by %I64d secs  (%I64d pixels) \n",difft/100, difft/m_pParent->m_DrawingTpp);
        }
      }
    }
    qDebug(" returned data start %s end %s  st:%I64d  end:%I64d\n\n",FS(recstarttime.QuadPart), FE(m_DataEndTime),recstarttime.QuadPart, m_DataEndTime );
    }
#endif
		//////////////////////////////////////////////////////////////////// end of test code
		if (IncreaseStartTime || (recstarttime.QuadPart < m_StartTime)) // for ealier starting data, update block start to match
				{
			// here we update m_StartTime to match.
			m_StartTime = recstarttime.QuadPart;
			// for later data times, m_StartTime remains as it is, freespace before data (should only happen at oldest data on SD)
		}
		if (ReduceEndTime || (m_DataEndTime > m_EndTime)) // for later ending data update block end to match
				{
			m_EndTime = m_DataEndTime; // update block endtime to match data  (Endtime is last reading time + some amount)
			// for earlier ending data, freespace after it will be present. (don't think we can get this situation due to tail.)
		}
	}
}
//****************************************************************************
/// dump the contents to the trace window
///
/// @param[in] none
///
/// @return none
///
//****************************************************************************
void CChartBlock::Dump() {
	CTimeHistory *pTh = CTimeHistory::GetHandle();
	TableEntry *pEntry = pTh->GetEntry(m_StartTime);
	if (!pEntry)
		return; // major problem here - no time history!
	LONGLONG diffmicro = (m_StartTime - pEntry->Tick100) * 10000;
	CTVtime displaytime = pEntry->ActualTime + diffmicro;
	CHAR buff[50];
	displaytime.TimeToStringShort(buff);
	qDebug("Start %s ", buff);
	pEntry = pTh->GetEntry(m_EndTime);
	if (!pEntry)
		return; // major problem here - no time history!
	diffmicro = (m_EndTime - pEntry->Tick100) * 10000;
	CTVtime displaytime2 = pEntry->ActualTime + diffmicro;
	//distime=(m_EndTime+offsettopApply)*10000;
	//CTVtime displaytime2(distime);
	displaytime2.TimeToStringShort(buff);
	qDebug(" end %s ", buff);
	qDebug("  first %d used %d ", m_FirstRec, m_UsedRecs);
	if (m_Type == CBLK_REQUESTED)
		qDebug("  REQUESTED \n");
	if (m_Type == CBLK_NODATA)
		qDebug("  NODATA \n");
	if (m_Type == CBLK_NORMAL) {
		qDebug("  NORMAL  ");
		qDebug(" start %I64d  end %I64d ", m_StartTime, m_EndTime);
		// now check start and end times match..
		LARGE_INTEGER stime;
		stime.HighPart = m_pRecs[m_FirstRec].hdr.startTimeH;
		stime.LowPart = m_pRecs[m_FirstRec].hdr.startTimeL;
		qDebug(" data start %I64d ", stime.QuadPart);
		pEntry = pTh->GetEntry(stime.QuadPart);
		if (!pEntry)
			return; // major problem here - no time history!
		diffmicro = (stime.QuadPart - pEntry->Tick100) * 10000;
		CTVtime displaytime3 = pEntry->ActualTime + diffmicro;
		displaytime3.TimeToStringShort(buff);
		//		qDebug(" data start %s ",buff);
		qDebug(" data last %I64d ", m_DataEndTime);
		pEntry = pTh->GetEntry(m_DataEndTime);
		if (!pEntry)
			return; // major problem here - no time history!
		diffmicro = (m_DataEndTime - pEntry->Tick100) * 10000;
		CTVtime displaytime4 = pEntry->ActualTime + diffmicro;
		displaytime4.TimeToStringShort(buff);
		//		qDebug(" data end %s ",buff);
		/*
		 if(stime.QuadPart<m_StartTime)
		 qDebug("start data time too early  ");
		 else
		 if(stime.QuadPart>m_StartTime)
		 qDebug("start data time is later (ok) ");
		 if(m_DataEndTime>m_EndTime)
		 qDebug("end data time too late  ");
		 else
		 if(m_DataEndTime<m_EndTime)
		 qDebug("end data time is earlier (ok) ");
		 */
		if (m_pNext) {
			if (m_EndTime > m_pNext->m_StartTime)
				qDebug("Overlaps next block");
			else if (m_EndTime != m_pNext->m_StartTime)
				qDebug("Gap to next block");
		}
		qDebug("\n");
		/*
		 LONGLONG recEndtime;
		 LONGLONG keepend;
		 LARGE_INTEGER recStartTime;
		 for(int i=0; i<m_UsedRecs; i++)
		 {
		 //PSR Fix for - 1-3GKDZ7Q - charting issues with slow speed begin
		 //Use recorder specific Rates instead of generic X-Series Rates
		 UINT RecTpp=CChartQManager::GetRateAtIndex(m_pRecs[i].hdr.rateIndex);
		 //PSR Fix for - 1-3GKDZ7Q - charting issues with slow speed end
		 recStartTime.LowPart=m_pRecs[i].hdr.startTimeL;
		 recStartTime.HighPart=m_pRecs[i].hdr.startTimeH;
		 if(m_pRecs[i].hdr.numReadings==MAX_REC_READINGS)
		 recEndtime=recStartTime.QuadPart+(m_pRecs[i].hdr.numReadings)*RecTpp; // first reading at start time. EndTime is +1 reading time
		 else
		 recEndtime=recStartTime.QuadPart+1+(m_pRecs[i].hdr.numReadings-1)*RecTpp; // here set EndTime time of last reading + 0.01 sec
		 qDebug("rec %d start %I64d  end %I64d \n",i,recStartTime, recEndtime);
		 if(i>0)
		 {
		 if(recStartTime.QuadPart<keepend)
		 qDebug(" Overlaps end of previous \n");
		 }
		 keepend=recEndtime;
		 }
		 */
	}
}
///////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  CChartMessageQ
//
///////////////////////////////////////////////////////////////////////////////////////////////////////
//****************************************************************************
/// CChartMessageQ Constructor (one queue for all messages)
///
///
//****************************************************************************
CChartMessageQ::CChartMessageQ() {
	qDebug("CREATED CCHARTMESSAGEQ\n");
	DefaultSettings();
	m_ReplayUsage = FALSE;
	m_DoneSetup = FALSE; //  not yet done setup of actual message q's
}
//****************************************************************************
/// Default the members and create tail block
///
/// @param none
///
/// @return none
///
//****************************************************************************
void CChartMessageQ::DefaultSettings() {
	m_NumMsgBlocks = 0;
	m_TotNumMsg = 0;
	m_pHead = NULL;
	m_pTail = NULL;
	LONGLONG processTime100 = pGlbSysTimer->GetOnGoingProcessTick();
	m_LastMessTime = processTime100;
	// here add a 'tail' block - will get copies of new messages here.
	CChartMessageBlock *tailblock = new CChartMessageBlock(this, TRUE); // TRUE for 'tail block'- will not cause requests from SD
	tailblock->m_StartTime = processTime100;
	tailblock->m_EndTime = processTime100;
	InsertBlock(m_pTail, tailblock);
	m_QBaseAlarmMessageTime = END_OF_TIME;
	memset(&m_QBaseAlarmMessage, 0, sizeof(T_MSGLISTSER_MESSAGE));
	memset(&m_QNewAlarmMessage, 0, sizeof(T_MSGLISTSER_MESSAGE));
	m_OldestMessageTime = 0;
	m_AlarmMessageQhandle = 0;
	m_InitialRequest = TRUE; // goes to FALSE after initial request is complete.
}
//****************************************************************************
/// CChartMessageQ Destructor
///
/// @param none
///
//****************************************************************************
CChartMessageQ::~CChartMessageQ() {
	// delete all queue blocks
	while (m_pHead) {
		CChartMessageBlock *ptempblock = m_pHead;
		m_pHead = m_pHead->m_pNext;
		delete ptempblock;
	}
}
//****************************************************************************
/// setup the ChartMessageQ's message Q's
///
/// @param none
///
/// @return none
///
//****************************************************************************
void CChartMessageQ::SetupQs() {
	CQueueManager *pQM = CQueueManager::GetHandle();
	CQMBlockServices &bs = pQM->GetBlockServices();
	CQMDiskServices &ds = pQM->GetDiskServices();
	// Get a Handles to each of the queues that we want to access
	// alarms, system, and user
	for (int i = 0; i < NUM_CHART_MESSAGE_Qs; i++) {
		m_RequestInfo[i].m_OutstandingRequest = FALSE;
		m_RequestInfo[i].m_pDestMessageBlock = NULL;
		m_RequestInfo[i].m_Recs[0].NumMessages = 0;
		CMessageListServices::T_MSG_LIST_QUEUES Qinstance;
		if (i == ALARM_MESSAGE)
			Qinstance = CMessageListServices::msqAlarms4Chart;
		else if (i == SYSTEM_MESSAGE)
			Qinstance = CMessageListServices::msqSystem;
		else if (i == USER_MESSAGE)
			Qinstance = CMessageListServices::msqUser;
		else
			continue;
		if (bs.GetQueue(QMC_QUEUE_MESSAGE, Qinstance, m_RequestInfo[i].m_QHandle) == QMBLKSER_PERSISTED_QUEUE_NOT_SETUP)
			bs.SetupQueue(m_RequestInfo[i].m_QHandle, QMC_QUEUE_MESSAGE, 1, QMC_CONFIRMATION_NOT_REQUIRED);
		//	this is now done where the messages are flushed to SD
		//	while(ds.IsQObjectInToDiskQ(m_RequestInfo[i].m_QHandle))
		//		sleep(100);
	}
	m_AlarmMessageQhandle = m_RequestInfo[0].m_QHandle; // msqAlarms4Chart
	m_DoneSetup = TRUE;
	CheckQueue(0, 0); // initial request
}
//****************************************************************************
/// delete the contents
///
/// @param none
///
/// @return none
///
//****************************************************************************
void CChartMessageQ::DeleteContents() {
	for (int i = 0; i < NUM_CHART_MESSAGE_Qs; i++) {
		if (m_RequestInfo[i].m_OutstandingRequest) {
			m_RequestInfo[i].m_OutstandingRequest = FALSE;
			qDebug("MESSAGE Q outstanding request cancelled\n");
			return;
		}
	}
	while (m_pHead) {
		CChartMessageBlock *ptempblock = m_pHead;
		m_pHead = m_pHead->m_pNext;
		delete ptempblock;
	}
	m_pTail = NULL;
	m_NumMsgBlocks = 0;
}
//****************************************************************************
/// check the block has all requests made (for each queue) for the timespan.
///
/// @param[in] pBlock		- block to check
///
/// @return T/F T=request added or still busy from before
///
//****************************************************************************
BOOL CChartMessageQ::CheckSpans(CChartMessageBlock *pBlock) {
	BOOL madeRequest = FALSE;
	CQueueManager *pQM = CQueueManager::GetHandle();
	CQMDiskServices &ds = pQM->GetDiskServices();
	for (int i = 0; i < NUM_CHART_MESSAGE_Qs; i++) {
		if (!m_RequestInfo[i].m_OutstandingRequest) {
			if (!pBlock->m_SpanRequested[i]) {
				m_RequestInfo[i].m_pDestMessageBlock = pBlock; // pointer to the block where we will add the messages returned
				pBlock->m_SpanRequested[i] = TRUE; // keep track within block of those Q's requested from
				m_RequestInfo[i].m_OutstandingRequest = TRUE;
#ifdef _DEBUG
      if((i==0) && SHOWMESSREQ)// todo remove	 alarm messages for chart queue
        qDebug("MM alarm msg req START %s END %s  st:%I64d  end:%I64d\n",FS(pBlock->m_StartTime), FE(pBlock->m_EndTime),pBlock->m_StartTime, pBlock->m_EndTime );
      if((i==1) && SHOWMESSREQ)// todo remove	 alarm messages for chart queue
        qDebug("MM system msg req START %s END %s  st:%I64d  end:%I64d\n",FS(pBlock->m_StartTime), FE(pBlock->m_EndTime),pBlock->m_StartTime, pBlock->m_EndTime );
      if((i==2) && SHOWMESSREQ)// todo remove	 alarm messages for chart queue
        qDebug("MM user msg req START %s END %s  st:%I64d  end:%I64d\n",FS(pBlock->m_StartTime), FE(pBlock->m_EndTime),pBlock->m_StartTime, pBlock->m_EndTime );
#endif
				//memset(m_RequestInfo[i].m_Recs,0,MESSQ_REQ_SIZE*sizeof(MessageRec)); //prefill with 0's for now todo remove for release
				// add the request here
				if (ds.GetPrevBlocksFromStartTime(USRREQSER_USER_OPPANEL, m_RequestInfo[i].m_QHandle,
						pBlock->m_EndTime << 16,  // time100 shifted by 2 bytes to make messageID
						MESSQ_REQ_SIZE, (BYTE*) m_RequestInfo[i].m_Recs) != QMDSKSER_OK) {
					m_RequestInfo[i].m_OutstandingRequest = FALSE; // no outstanding request anymore
					pBlock->m_SpanRequested[i] = FALSE;			 // and haven't requested this either.
					qDebug("  <MESS QUEUE FULL>\n");
				}
				madeRequest = TRUE; // either made a new request or still busy from previous ones
			}
		}
	}
	return madeRequest;
}
//****************************************************************************
/// check the queue for the given timespan.
///
/// @param[in] TimeFrom		- time to check from
/// @param[in] TimeTo		- time to check up to
/// @param[in] initial		- initial request
///
/// @return T/F (request added)
///
//****************************************************************************
BOOL CChartMessageQ::CheckQueue(LONGLONG TimeFrom, LONGLONG TimeTo) {
	if (!m_DoneSetup)
		SetupQs();
	// need to check the Queue and request any missing data
	BOOL madeRequest = FALSE;
	// here, see if all requests are complete for each of the message queues
	// NB when data is returned (DataUpdate) additional requests may be made for
	// previous blocks etc. The check here is also for those being complete.
	int reqs = 0;
	int i;
	for (i = 0; i < NUM_CHART_MESSAGE_Qs; i++) {
		if (m_RequestInfo[i].m_OutstandingRequest)
			reqs++;
	}
	if (reqs > 0)
		return TRUE; // still busy
	if (m_InitialRequest) // happens on screen changes and config change etc.
	{
#ifdef _DEBUG
    if(SHOWMESSREQ)
    qDebug("+++ DOING INITIAL REQUEST (MESS) +++\n");
#endif
		//  Verify changes.....
		//TimeFrom=m_LastMessTime-(120000*800);  // a screen's with for slowest chart speed (Tpp=120000) mplus
		TimeFrom = m_LastMessTime - (120000 * ARISTOS_MULTI_SX_X); // a screen's with for slowest chart speed (Tpp=120000) mplus
		TimeTo = m_LastMessTime;
	}
	if (TimeFrom < 0) //there is no data before time 0!
		TimeFrom = 0;
	// fix timeto..	(don't try to request further than start of tail block)
	if (m_pTail) {
		if (TimeTo >= m_pTail->m_StartTime)
			TimeTo = m_pTail->m_StartTime;
		if (TimeTo <= TimeFrom) {
			m_InitialRequest = FALSE;
			return FALSE;
		}
	}
	// earlier messages required?...
	if (TimeFrom < m_pHead->m_StartTime) // this should be unlikely (unless initial load or we are in replay)
			{								  // and is subject to there being less than 4000 messages
		if ((m_NumMsgBlocks < Glb_MaxMsgBlocks) && (m_TotNumMsg < Glb_MaxMsg)) {
			CChartMessageBlock *messblock = new CChartMessageBlock(this);
			messblock->m_StartTime = TimeFrom;
			messblock->m_EndTime = m_pHead->m_StartTime;
			InsertBlock(NULL, messblock); // insert at head.
			madeRequest = CheckSpans(messblock);
			return madeRequest;
		}
	}
	// here there are no requests to complete the existing blocks.
	// OR for any new blocks.
	// therefore, the initial request is complete
	if (reqs == 0)
		m_InitialRequest = FALSE; // not doing anything, so done.
	return madeRequest;
}
//****************************************************************************
/// Inserts a block into our Queue AFTER the position specified.
///
/// @param[in] plistPos		- pointer to block to insert after (can be NULL)
/// @param[in] pNewBlock	- pointer to block to insert
///
/// @return none
///
//****************************************************************************
void CChartMessageQ::InsertBlock(CChartMessageBlock *plistPos, CChartMessageBlock *pNewBlock) {
	if (m_pHead) {
		if (plistPos == NULL) {
			// insert at head
			pNewBlock->m_pNext = m_pHead;
			m_pHead->m_pPrev = pNewBlock;
			m_pHead = pNewBlock;
		} else {
			if (pNewBlock->m_pNext = plistPos->m_pNext) // assign and check for end of list? (null)
				plistPos->m_pNext->m_pPrev = pNewBlock; // no, assign prev pointer
			else
				m_pTail = pNewBlock; // yes, set as new tail
			plistPos->m_pNext = pNewBlock;
			pNewBlock->m_pPrev = plistPos;
		}
	} else {
		// must be insert at head, and head is null.
		m_pHead = pNewBlock;
		m_pTail = pNewBlock;
		pNewBlock->m_pPrev = NULL;
		pNewBlock->m_pNext = NULL;
	}
}
//****************************************************************************
/// Get alarm message at or prior to the time supplied, but don't search back before EarliestTime
///
/// @param[in] beforeTime	  -	time to find alarm message before.
/// @param[in,out] RetMessage -	address of message struct to fill (if found)
/// @param[in] GroupNumber	  -	GroupNumber (0 = any)
///
/// @return T/F (message found)
///
//****************************************************************************
BOOL CChartMessageQ::GetPreviousAlarmMessage(LONGLONG beforeTime, T_MSGLISTSER_MESSAGE *RetMessage,
		USHORT GroupNumber) {
	// is it worth checking our messages in memory?
	if (beforeTime >= m_pHead->m_StartTime) {
		// does the message span we have cover the time we want to search for?
		// first check the tail block
		if (m_pTail && m_pTail->m_StartTime < beforeTime) {
			// covered by this span.
			// find the alarm message (if there is one)
			MessageHolder *pKeep = NULL;
			MessageHolder *pMess = m_pTail->m_pMessages;
			while (pMess) {
				if (IS_ALARM(pMess) // look for any alarm message type
				&& MATCHGROUPEXACT(GroupNumber, MESSGROUP(pMess))) {
					if ((pMess->message.messageId >> 16) <= beforeTime)
						pKeep = pMess;
				}
				pMess = pMess->pNext;
			}
			if (pKeep) {
				//ok, got the last alarm before the time.
				*RetMessage = pKeep->message;
				return TRUE;
			}
			// no alarm messages found here. so drop through to below.
		}
		// or is the time covered by the rest of the list
		if (m_pHead && (m_pHead->m_StartTime <= beforeTime) && m_pTail && m_pTail->m_pPrev
				&& (m_pTail->m_pPrev->m_EndTime > beforeTime)) {
			// covered by this span
			// search from the tail prev backwards
			CChartMessageBlock *pBlock = m_pTail->m_pPrev;
			while (pBlock) {
				if (beforeTime >= pBlock->m_StartTime) {
					// check this block
					MessageHolder *pKeep = NULL;
					MessageHolder *pMess = pBlock->m_pMessages;
					while (pMess) {
						if (IS_ALARM(pMess) // look for any alarm message type
						&& MATCHGROUPEXACT(GroupNumber, MESSGROUP(pMess))) {
							if ((pMess->message.messageId >> 16) <= beforeTime)
								pKeep = pMess;
						}
						pMess = pMess->pNext;
					}
					if (pKeep) {
						//ok, got the last alarm before the time.
						*RetMessage = pKeep->message;
						return TRUE;
					}
					// otherwise drop thro and move on.
				}
				// earlier data wanted
				pBlock = pBlock->m_pPrev; // move on (backwards)
			}
		}
	}
	// here we haven't found an alarm message within the queue we have in memory, so now optionally go to SD.
	if (m_QBaseAlarmMessageTime != END_OF_TIME) {
		*RetMessage = m_QBaseAlarmMessage;
		return TRUE;
	} else
		return FALSE;
}
//****************************************************************************
/// Messages request from disk has completed. Check the result
///
/// @param[in] pReply	 - pointer to structure containing reply
/// @param[in] messType	 - 'type' of message (which queue it is from)
///
/// @return none
///
//****************************************************************************
void CChartMessageQ::DataUpdate(T_USRREQSER_USER_MESSAGE_REPLY *pReply, int messType) {
	CQueueManager *pQM = CQueueManager::GetHandle();
	CQMDiskServices &ds = pQM->GetDiskServices();
	if (!m_RequestInfo[messType].m_OutstandingRequest) {
		return; // not expecting a reply here! (may have been cancelled)
	}
	if (pReply->requestReply == USRREQSER_REQUEST_FAILED) {
		// ok, the request failed, so something went wrong.
		//do not delete the requestblock, since other types of message may be using it now.
		m_RequestInfo[messType].m_pDestMessageBlock->m_SpanCovered[messType] = TRUE; // treat as requested and done.
		m_RequestInfo[messType].m_OutstandingRequest = FALSE;
		m_RequestInfo[messType].m_pDestMessageBlock = NULL; // not pointing to block anymore.
#ifdef _DEBUG
    if((messType==ALARM_MESSAGE) && SHOWMESSREQ)// todo remove	 alarm messages for chart queue
    qDebug("MM FAILED alarm msg reply\n");
    if((messType==SYSTEM_MESSAGE) && SHOWMESSREQ)// todo remove
    qDebug("MM FAILED system msg reply\n");
    if((messType==USER_MESSAGE) && SHOWMESSREQ)// todo remove
    qDebug("MM FAILED user msg reply\n");
#endif
		if (m_InitialRequest) // still initial request? (need to do another pass here)
			CheckQueue(0, 0);
	} else {
		LONGLONG oldheadtime = END_OF_TIME;
		if (m_pHead)
			oldheadtime = m_pHead->m_StartTime;
		CChartQManager *CM = CChartQManager::GetHandle();
#ifdef _DEBUG
    if((messType==0) && SHOWMESSREQ)// todo remove	 alarm messages for chart queue
    qDebug("MM received alarm msg reply\n");
    if((messType==1) && SHOWMESSREQ)// todo remove
    qDebug("MM received system msg reply\n");
    if((messType==2) && SHOWMESSREQ)// todo remove
    qDebug("MM received user msg reply\n");
#endif
		// add the messages to our list
		if (m_RequestInfo[messType].m_pDestMessageBlock->ExtractMessages(messType, m_RequestInfo[messType].m_Recs,
				pReply->numOfBlocksObtained)) {
			// added some messages here.
			// this for replay use only
			if (CM->m_HasNewData) {
				if (m_RequestInfo[messType].m_pDestMessageBlock->m_StartTime < CM->m_Earliest)
					CM->m_Earliest = m_RequestInfo[messType].m_pDestMessageBlock->m_StartTime;
				if (m_RequestInfo[messType].m_pDestMessageBlock->m_LastMessageTime[messType] > CM->m_Latest)
					CM->m_Latest = m_RequestInfo[messType].m_pDestMessageBlock->m_LastMessageTime[messType];
				CM->m_HasNewMessages = TRUE;
			} else {
				CM->m_HasNewData = TRUE;
				CM->m_HasNewMessages = TRUE; // extra flag to indicate we have messages (need to allow for strip)
				CM->m_Earliest = m_RequestInfo[messType].m_pDestMessageBlock->m_StartTime;
				CM->m_Latest = m_RequestInfo[messType].m_pDestMessageBlock->m_LastMessageTime[messType];
			}
		}
		if (m_QNewAlarmMessage.messageId != m_QBaseAlarmMessage.messageId) {
			// updated this.
			m_QBaseAlarmMessage = m_QNewAlarmMessage;
			m_QBaseAlarmMessageTime = m_QBaseAlarmMessage.messageId >> 16;
			qDebug("----Updated Q Alarm Message----\n");
			// this for replay use only
			if (CM->m_HasNewData) {
				CM->m_Earliest = m_QBaseAlarmMessageTime;
				if (oldheadtime > CM->m_Latest)
					CM->m_Latest = oldheadtime;
			} else {
				CM->m_HasNewData = TRUE;
				CM->m_Earliest = m_QBaseAlarmMessageTime;
				CM->m_Latest = oldheadtime;
			}
		}
		// more blocks required?
		if (pReply->requestReplyAdditionalInfo == USRREQSER_REPLY_BLOCKS_AVAILABLE) {
			if (m_TotNumMsg >= Glb_MaxMsg) {
				// already more than enough messages, so don't request more.
				// span will have been reduced (if possible)
				m_RequestInfo[messType].m_pDestMessageBlock->m_SpanCovered[messType] = TRUE;
				m_RequestInfo[messType].m_OutstandingRequest = FALSE;
				// here check to see if we can split the blocks (if required)
				SplitBlock(m_RequestInfo[messType].m_pDestMessageBlock);
				m_RequestInfo[messType].m_pDestMessageBlock = NULL; // not pointing to block anymore.
				if (m_InitialRequest) // still initial request? (need to do another pass here)
					CheckQueue(0, 0);
			} else // have we already covered the span?
			if (m_RequestInfo[messType].m_pDestMessageBlock->m_SpanCovered[messType] == FALSE) {
				// not yet, make another request from where we got to last time
				//memset(m_RequestInfo[messType].m_Recs,0,MESSQ_REQ_SIZE*sizeof(MessageRec)); // prefill with 0's for now todo remove for release
#ifdef _DEBUG
        if((messType==0) && SHOWMESSREQ) // todo remove	 alarm messages for chart queue
        qDebug("MM alarm msg req PREV\n");
        if((messType==1) && SHOWMESSREQ) // todo remove	 alarm messages for chart queue
        qDebug("MM system msg req PREV\n");
        if((messType==2) && SHOWMESSREQ) // todo remove	 alarm messages for chart queue
        qDebug("MM user msg req PREV \n");
#endif
				if (ds.GetPreviousBlocks(USRREQSER_USER_OPPANEL, m_RequestInfo[messType].m_QHandle,
				MESSQ_REQ_SIZE, (BYTE*) m_RequestInfo[messType].m_Recs) != QMDSKSER_OK) {
					m_RequestInfo[messType].m_OutstandingRequest = FALSE;
					m_RequestInfo[messType].m_pDestMessageBlock->m_SpanRequested[messType] = FALSE;
					m_RequestInfo[messType].m_pDestMessageBlock = NULL; // not pointing to block anymore.
					qDebug("  <MESS QUEUE FULL>\n");
				}
			} else {
				m_RequestInfo[messType].m_OutstandingRequest = FALSE;
				// here check to see if we can split the blocks (if required)
				// here check to see if we can split the blocks (if required)
				SplitBlock(m_RequestInfo[messType].m_pDestMessageBlock);
				m_RequestInfo[messType].m_pDestMessageBlock = NULL; // not pointing to block anymore.
				if (m_InitialRequest) // still initial request? (need to do another pass here)
					CheckQueue(0, 0);
			}
		} else {
			m_RequestInfo[messType].m_pDestMessageBlock->m_SpanCovered[messType] = TRUE;
			m_RequestInfo[messType].m_OutstandingRequest = FALSE;
			// here check to see if we can split the blocks (if required)
			SplitBlock(m_RequestInfo[messType].m_pDestMessageBlock);
			m_RequestInfo[messType].m_pDestMessageBlock = NULL; // not pointing to block anymore.
			if (m_InitialRequest) // still initial request? (need to do another pass here)
				CheckQueue(0, 0);
		}
	}
}
//****************************************************************************
/// Splits a large block into much smaller ones.
/// waits until all messages have been returned for block before splitting.
///
/// @param[in] pBlock	 - pointer to block to split
///
/// @return none
///
//****************************************************************************
void CChartMessageQ::SplitBlock(CChartMessageBlock *pBlock) {
	for (int i = 0; i < NUM_CHART_MESSAGE_Qs; i++) {
		if ((m_RequestInfo[i].m_OutstandingRequest) && (m_RequestInfo[i].m_pDestMessageBlock == pBlock))
			return; // cannot split, waiting for reply.
		if (pBlock->m_SpanCovered[i] == FALSE)
			return; // not all spans requested and returned
	}
	while (pBlock->m_NumMessages > Glb_MessagesPerBlock + 5) {
		// need to split block..
		//qDebug("Splitting block, %d messages \n", pBlock->m_NumMessages);
		// start from the head and break off the first part of the list.
		MessageHolder *pmess = pBlock->m_pMessages;
		int messcount = 1; // allow for breaking off 'next'
		while (pmess && pmess->pNext
				&& ((messcount < Glb_MessagesPerBlock)
						|| (pmess->message.messageId >> 16 == pmess->pNext->message.messageId >> 16))) {
			messcount++;
			pmess = pmess->pNext;
		}
		if (pmess) {
			// break the block here
			MessageHolder *pNext = pmess->pNext;
			pmess->pNext = NULL;
			// get a block to put it in.
			// here to prevent issues of blocks being recycled while we are trying to split them (headache!)
			// allocate each block as new.
			CChartMessageBlock *messblock = new CChartMessageBlock(this);
			messblock->m_EndTime = pBlock->m_EndTime; // keep same endtime for now
			if (pNext == NULL) {
				messblock->m_StartTime = pmess->message.messageId >> 16;
				messblock->m_pMessages = pmess; // put the messages in.
			} else {
				messblock->m_StartTime = pNext->message.messageId >> 16;
				pBlock->m_EndTime = messblock->m_StartTime; // set new endtime on previous block
				messblock->m_pMessages = pNext; // put the messages in.
			}
			messblock->m_NumMessages = pBlock->m_NumMessages - messcount;
			pBlock->m_NumMessages = messcount; // now have this many
			// copy over the flags - since requested and span covered applies to all subsections
			for (int j = 0; j < NUM_CHART_MESSAGE_Qs; j++) {
				messblock->m_SpanRequested[j] = pBlock->m_SpanRequested[j];
				messblock->m_SpanCovered[j] = pBlock->m_SpanCovered[j];
				messblock->m_LastMessageTime[j] = 0; // this would be tricky to calc and is of no use.
			}
			InsertBlock(pBlock, messblock); // and insert.
			pBlock = messblock; // move on..
		} else
			break; // all done
	}
	// count the messages
	MessageHolder *pmblk = pBlock->m_pMessages;
	int count = 0;
	while (pmblk) {
		count++;
		pmblk = pmblk->pNext;
	}
	//qDebug("messages %d \n",count);
}
//****************************************************************************
/// Get the first message at or after the time supplied.
///
/// @param[in,out] rmc	 - pointer to structure containing read position etc.
///
/// @return MESSRET
///
//****************************************************************************
MESSRET CChartMessageQ::GetFirstMessage(ReadMessageContext *rmc) {
	// search from the head
	rmc->m_pBlock = m_pHead;
	while (rmc->m_pBlock) {
		if (rmc->m_pBlock->m_pMessages == NULL) // no messages in this span.
		{
			rmc->m_pBlock = rmc->m_pBlock->m_pNext;
			continue;
		}
		if (rmc->m_LocateTime >= rmc->m_pBlock->m_StartTime) {
			if (rmc->m_LocateTime < rmc->m_pBlock->m_EndTime) {
				// required time is in this block
				rmc->m_pCurMessage = rmc->m_pBlock->m_pMessages;
				while (rmc->m_pCurMessage) {
					if ((rmc->m_pCurMessage->message.messageId >> 16) >= rmc->m_LocateTime) {
						if (NOT_ALARM(rmc->m_pCurMessage)) {
							// for non-alarms, group matching done with 0 in either ok
							if (MATCHGROUP(rmc->m_GroupNumber, MESSGROUP(rmc->m_pCurMessage)))
								break;
						} else {
							// for alarms, fails unless an exact match of group
							if (MATCHGROUPEXACT(rmc->m_GroupNumber, MESSGROUP(rmc->m_pCurMessage)))
								break;
						}
					}
					rmc->m_pCurMessage = rmc->m_pCurMessage->pNext;
				}
				if (rmc->m_pCurMessage) {
					rmc->m_LocateTime = (rmc->m_pCurMessage->message.messageId >> 16);
					// here, we could use rmc->m_ReqTpp and see if there is more than one message in the 'span' requested
					return MESSAGE_OK;
				}
				// otherwise drop thro and move on.
			}
		} else {
			// earlier data wanted, but return first block after the requested time
			rmc->m_pCurMessage = rmc->m_pBlock->m_pMessages;
			while (rmc->m_pCurMessage) {
				if (NOT_ALARM(rmc->m_pCurMessage)) {
					// for non-alarms, group matching done with 0 in either ok
					if (MATCHGROUP(rmc->m_GroupNumber, MESSGROUP(rmc->m_pCurMessage)))
						break;
				} else {
					// for alarms, fails unless an exact match of group
					if (MATCHGROUPEXACT(rmc->m_GroupNumber, MESSGROUP(rmc->m_pCurMessage)))
						break;
				}
				rmc->m_pCurMessage = rmc->m_pCurMessage->pNext;
			}
			if (rmc->m_pCurMessage) {
				rmc->m_LocateTime = (rmc->m_pCurMessage->message.messageId >> 16);
				return MESSAGE_OK;
			}
		}
		rmc->m_pBlock = rmc->m_pBlock->m_pNext; // move on
	}
	return NO_MORE_MESSAGES;
}
//****************************************************************************
/// Get the next message from the position we were at
///
/// @param[in,out] rmc	 - pointer to structure containing read position etc.
///
/// @return MESSRET
///
//****************************************************************************
MESSRET CChartMessageQ::GetNextMessage(ReadMessageContext *rmc) {
	if (rmc->m_pCurMessage)
		rmc->m_pCurMessage = rmc->m_pCurMessage->pNext;
	while (rmc->m_pCurMessage) {
		if (NOT_ALARM(rmc->m_pCurMessage)) {
			// for non-alarms, group matching done with 0 in either ok
			if (MATCHGROUP(rmc->m_GroupNumber, MESSGROUP(rmc->m_pCurMessage)))
				break;
		} else {
			// for alarms, fails unless an exact match of group
			if (MATCHGROUPEXACT(rmc->m_GroupNumber, MESSGROUP(rmc->m_pCurMessage)))
				break;
		}
		rmc->m_pCurMessage = rmc->m_pCurMessage->pNext;
	}
	if (rmc->m_pCurMessage) {
		rmc->m_LocateTime = (rmc->m_pCurMessage->message.messageId >> 16);
		// here, we could use rmc->m_ReqTpp and see if there is more than one message in the 'span' requested
		return MESSAGE_OK;
	}
	rmc->m_pBlock = rmc->m_pBlock->m_pNext; // move on
	while (rmc->m_pBlock) {
		if (rmc->m_pBlock->m_pMessages == NULL) // no messages in this span.
		{
			rmc->m_pBlock = rmc->m_pBlock->m_pNext;
			continue;
		}
		rmc->m_pCurMessage = rmc->m_pBlock->m_pMessages;
		while (rmc->m_pCurMessage) {
			if (NOT_ALARM(rmc->m_pCurMessage)) {
				// for non-alarms, group matching done with 0 in either ok
				if (MATCHGROUP(rmc->m_GroupNumber, MESSGROUP(rmc->m_pCurMessage)))
					break;
			} else {
				// for alarms, fails unless an exact match of group
				if (MATCHGROUPEXACT(rmc->m_GroupNumber, MESSGROUP(rmc->m_pCurMessage)))
					break;
			}
			rmc->m_pCurMessage = rmc->m_pCurMessage->pNext;
		}
		if (rmc->m_pCurMessage) {
			rmc->m_LocateTime = (rmc->m_pCurMessage->message.messageId >> 16);
			// here, we could use rmc->m_ReqTpp and see if there is more than one message in the 'span' requested
			return MESSAGE_OK;
		}
		rmc->m_pBlock = rmc->m_pBlock->m_pNext; // move on
	}
	return NO_MORE_MESSAGES;
}
//****************************************************************************
/// Get the previous message (first one prior to the time supplied.)
///
/// @param[in,out] rmc	 - pointer to structure containing read position etc.
///
/// @return MESSRET
///
//****************************************************************************
MESSRET CChartMessageQ::GetPreviousMessage(ReadMessageContext *rmc) {
	// search backwards from the tail
	rmc->m_pBlock = m_pTail;
	rmc->m_pCurMessage = NULL;
	while (rmc->m_pBlock) {
		if (rmc->m_pBlock->m_pMessages == NULL) // no messages in this span.
		{
			rmc->m_pBlock = rmc->m_pBlock->m_pPrev;
			continue;
		}
		// since we are looking for message prior to time,
		if (rmc->m_LocateTime > rmc->m_pBlock->m_StartTime) //if time is equal, need previous block
				{
			// required time is in this block
			// have to search forwards though (since no prev link)
			MessageHolder *pKeep = NULL;
			MessageHolder *pMess = rmc->m_pBlock->m_pMessages;
			while (pMess) {
				if ((pMess->message.messageId >> 16) < rmc->m_LocateTime) {
					if (NOT_ALARM(pMess)) {
						// for non-alarms, group matching done with 0 in either ok
						if (MATCHGROUP(rmc->m_GroupNumber, MESSGROUP(pMess)))
							pKeep = pMess;
					} else {
						// for alarms, fails unless an exact match of group
						if (MATCHGROUPEXACT(rmc->m_GroupNumber, MESSGROUP(pMess)))
							pKeep = pMess;
					}
				} else
					break; // gone past time we want.
				pMess = pMess->pNext;
			}
			if (pKeep) // here we have a message - since we started with the tail block and worked backwards, this is the message we require
			{
				rmc->m_pCurMessage = pKeep;
				rmc->m_LocateTime = (rmc->m_pCurMessage->message.messageId >> 16);
				return MESSAGE_OK;
			}
			// otherwise drop thro and move on (back)
		}
		rmc->m_pBlock = rmc->m_pBlock->m_pPrev; // move on (backwards)
	}
	return NO_MORE_MESSAGES;
}
//****************************************************************************
/// Get the first ALARM message at or after the time supplied.
///
/// @param[in,out] rmc	 - pointer to structure containing read position etc.
///
/// @return MESSRET
///
//****************************************************************************
MESSRET CChartMessageQ::GetFirstAlarmMessage(ReadMessageContext *rmc) {
	// search from the head
	rmc->m_pBlock = m_pHead;
	while (rmc->m_pBlock) {
		if (rmc->m_pBlock->m_pMessages == NULL) // no messages in this span.
		{
			rmc->m_pBlock = rmc->m_pBlock->m_pNext;
			continue;
		}
		if (rmc->m_LocateTime >= rmc->m_pBlock->m_StartTime) {
			if (rmc->m_LocateTime < rmc->m_pBlock->m_EndTime) {
				// required time is in this block
				rmc->m_pCurMessage = rmc->m_pBlock->m_pMessages;
				while (rmc->m_pCurMessage
						&& (
						NOT_ALARM(rmc->m_pCurMessage)
								|| ((rmc->m_pCurMessage->message.messageId >> 16) < rmc->m_LocateTime)
								|| FAILGROUPEXACT(rmc->m_GroupNumber, MESSGROUP(rmc->m_pCurMessage))))
					rmc->m_pCurMessage = rmc->m_pCurMessage->pNext; // not an alarm message or time is too early, move on
				if (rmc->m_pCurMessage) {
					rmc->m_LocateTime = (rmc->m_pCurMessage->message.messageId >> 16);
					// here, we could use rmc->m_ReqTpp and see if there is more than one message in the 'span' requested
					return MESSAGE_OK;
				}
				// otherwise drop thro and move on.
			}
		} else {
			// earlier data wanted, but return first block after the requested time
			rmc->m_pCurMessage = rmc->m_pBlock->m_pMessages;
			while (rmc->m_pCurMessage && (
			NOT_ALARM(rmc->m_pCurMessage) || // not alarm
					FAILGROUPEXACT(rmc->m_GroupNumber, MESSGROUP(rmc->m_pCurMessage))))
				rmc->m_pCurMessage = rmc->m_pCurMessage->pNext;
			if (rmc->m_pCurMessage) {
				rmc->m_LocateTime = (rmc->m_pCurMessage->message.messageId >> 16);
				return MESSAGE_OK;
			}
		}
		rmc->m_pBlock = rmc->m_pBlock->m_pNext; // move on
	}
	return NO_MORE_MESSAGES;
}
//****************************************************************************
/// Get the next ALARM message from the position we were at
///
/// @param[in,out] rmc	 - pointer to structure containing read position etc.
///
/// @return MESSRET
///
//****************************************************************************
MESSRET CChartMessageQ::GetNextAlarmMessage(ReadMessageContext *rmc) {
	if (rmc->m_pCurMessage)
		rmc->m_pCurMessage = rmc->m_pCurMessage->pNext;
	while (rmc->m_pCurMessage && (
	NOT_ALARM(rmc->m_pCurMessage) || // not alarm
			FAILGROUPEXACT(rmc->m_GroupNumber, MESSGROUP(rmc->m_pCurMessage))))
		rmc->m_pCurMessage = rmc->m_pCurMessage->pNext;
	if (rmc->m_pCurMessage) {
		rmc->m_LocateTime = (rmc->m_pCurMessage->message.messageId >> 16);
		// here, we could use rmc->m_ReqTpp and see if there is more than one message in the 'span' requested
		return MESSAGE_OK;
	}
	rmc->m_pBlock = rmc->m_pBlock->m_pNext; // move on
	while (rmc->m_pBlock) {
		if (rmc->m_pBlock->m_pMessages == NULL) // no messages in this span.
		{
			rmc->m_pBlock = rmc->m_pBlock->m_pNext;
			continue;
		}
		rmc->m_pCurMessage = rmc->m_pBlock->m_pMessages;
		while (rmc->m_pCurMessage && (
		NOT_ALARM(rmc->m_pCurMessage) || // not alarm
				FAILGROUPEXACT(rmc->m_GroupNumber, MESSGROUP(rmc->m_pCurMessage))))
			rmc->m_pCurMessage = rmc->m_pCurMessage->pNext;
		if (rmc->m_pCurMessage) {
			rmc->m_LocateTime = (rmc->m_pCurMessage->message.messageId >> 16);
			// here, we could use rmc->m_ReqTpp and see if there is more than one message in the 'span' requested
			return MESSAGE_OK;
		}
		rmc->m_pBlock = rmc->m_pBlock->m_pNext; // move on
	}
	return NO_MORE_MESSAGES;
}
//****************************************************************************
/// Check to see which part of the queue the user is viewing
///
/// @returns T/F  TRUE if user is looking at (or near) head
///
//****************************************************************************
BOOL CChartMessageQ::UserViewingHead() {
	CChartQManager *CM = CChartQManager::GetHandle();
	if (!m_pHead)
		return FALSE;
	if (CM->m_midtime < m_pHead->m_StartTime)
		return TRUE;
	if (!m_pTail || !m_pTail->m_pPrev)
		return FALSE;
	if (CM->m_midtime > m_pTail->m_pPrev->m_EndTime)
		return FALSE;
	// see if midtime is nearer to firsttime or lasttime
	return ((CM->m_midtime - m_pHead->m_StartTime) < (m_pTail->m_pPrev->m_EndTime - CM->m_midtime));
}
//****************************************************************************
/// Re-use a chart message block
///
/// @param[in] pos			- position to remove from (or TEST if in replay mode)
/// @param[in] IsTailBlock	- flag to indicate it needs to be set up as tail
///
/// @return pointer to CChartMessageBlock
///
//****************************************************************************
CChartMessageBlock* CChartMessageQ::ReUseBlock(BLOCK_POS pos, BOOL IsTailBlock, CChartMessageBlock *pIgnoreBlock) // =FALSE =NULL
		{
	CChartMessageBlock *pNewblock = NULL;
	// not reusing from tail any more - only from head in normal use.
	/*
	 // for replay mode, we take it from the opposite end to where the user is looking.
	 // otherwise we take it from the head.
	 if(m_ReplayUsage && (pos==TAIL) || ((pos==TEST) && UserViewingHead()) )
	 {
	 // remove from tail (less 2) - never remove the last 2 tail blocks for messages
	 CChartMessageBlock* pCurblock=m_pTail->m_pPrev->m_pPrev;
	 while(pCurblock)
	 {
	 BOOL IgnoreBlock=FALSE;
	 // see if the block was going to be used as the destination for an outstanding request
	 // Since we are now taking a block from the tail, it is unlikely that we want the reply anyway
	 for(int i=0; i<NUM_CHART_MESSAGE_Qs; i++)
	 {
	 if(m_RequestInfo[i].m_OutstandingRequest)
	 {
	 if(m_RequestInfo[i].m_pDestMessageBlock==pCurblock)
	 {
	 // here the block is going to be used for some returning data
	 //m_RequestInfo[i].m_OutstandingRequest=FALSE; // cancel the request
	 //m_RequestInfo[i].m_pDestMessageBlock=NULL;
	 IgnoreBlock=TRUE;
	 break;
	 }
	 }
	 }
	 if((pCurblock==pIgnoreBlock) || IgnoreBlock)
	 {
	 pCurblock=pCurblock->m_pPrev;
	 continue;
	 }
	 // remove this block from the list.
	 pNewblock=pCurblock;
	 pCurblock=pCurblock->m_pPrev;
	 pNewblock->m_pNext->m_pPrev=pCurblock;
	 pCurblock->m_pNext=pNewblock->m_pNext;
	 // here we want to remove blocks if we have more than the maximum no. of blocks. (can happen during split)
	 if(m_NumMsgBlocks>=Glb_MaxMsgBlocks)
	 delete pNewblock;
	 else
	 break; // drop out here
	 }
	 }
	 else
	 */
	{
		// take a block from the head and re-use it.
		CChartMessageBlock *pCurblock = m_pHead;
		while (pCurblock) {
			// see if the block was going to be used as the destination for an outstanding request
			// Since we are now taking a block from the head, it is unlikely that we want the reply anyway
			BOOL IgnoreBlock = FALSE;
			for (int i = 0; i < NUM_CHART_MESSAGE_Qs; i++) {
				if (m_RequestInfo[i].m_OutstandingRequest) {
					if (m_RequestInfo[i].m_pDestMessageBlock == pCurblock) {
						// here the block is going to be used for some returning data
						//		m_RequestInfo[i].m_OutstandingRequest=FALSE; // cancel the request
						//		m_RequestInfo[i].m_pDestMessageBlock=NULL;	// dont' point to the block any more
						IgnoreBlock = TRUE;
						break;
					}
				}
			}
			if ((pCurblock == pIgnoreBlock) || IgnoreBlock) {
				pCurblock = pCurblock->m_pNext;
				continue;
			}
			// remove this block from the list.
			pNewblock = pCurblock;
			pCurblock = pCurblock->m_pNext;
			if (m_pHead == pNewblock) {
				m_pHead = pCurblock;
				m_pHead->m_pPrev = NULL;
			} else {
				pNewblock->m_pPrev->m_pNext = pCurblock;
				pCurblock->m_pPrev = pNewblock->m_pPrev;
			}
			// here we want to remove blocks if we have more than the maximum no. of blocks. (can happen during split)
			if (m_NumMsgBlocks >= Glb_MaxMsgBlocks) {
				delete pNewblock;
				pNewblock = NULL;  // coverity fix #776026
			} else {
				break; // drop out here
			}
		}
	}
	if (NULL != pNewblock) // coverity fix #776026
			{
		// ok, here dropped out, we should have a block to reuse
		pNewblock->m_pPrev = NULL;
		pNewblock->m_pNext = NULL;
		pNewblock->Reset(IsTailBlock);
	}
	return pNewblock;
}
//****************************************************************************
/// Adds a new message into the chartmessage queue when it occurs
///
/// @param[in] msg		- message to add
///
/// @return none
///
//****************************************************************************
void CChartMessageQ::AddMessage(T_MSGLISTSER_MESSAGE *msg) {
	if (m_pTail) {
		// allow approx Glb_MessagesPerBlock - but allow multiple messages at the same time to go in the same block
		if ((m_pTail->m_NumMessages >= Glb_MessagesPerBlock) && ((msg->messageId >> 16) >= m_pTail->m_EndTime)) {
			CChartMessageBlock *tailblock;
			// add a new/re-use block here..
			if ((m_NumMsgBlocks >= Glb_MaxMsgBlocks) || (m_TotNumMsg >= Glb_MaxMsg))
				tailblock = ReUseBlock(HEAD, TRUE); // TRUE for 'tail block'- will not cause requests from SD
			else
				tailblock = new CChartMessageBlock(this, TRUE); // TRUE for 'tail block'- will not cause requests from SD
			//tailblock->m_StartTime=(msg->messageId>>16);
			tailblock->m_StartTime = m_pTail->m_EndTime; // join up with tail
			tailblock->m_EndTime = (msg->messageId >> 16);
			InsertBlock(m_pTail, tailblock);
		}
		// now add the message
		MessageHolder *pmh = new MessageHolder;
		memcpy(&pmh->message, msg, sizeof(T_MSGLISTSER_MESSAGE));
		pmh->pNext = NULL;
		MessageHolder **pCurrent = &m_pTail->m_pMessages; // address of head of list pointer
		while (*pCurrent)
			pCurrent = &((*pCurrent)->pNext); // move past items in list
		(*pCurrent) = pmh; // assign onto end of list
		// update num messages in block and endtime
		m_pTail->m_NumMessages++;
		m_pTail->m_EndTime = 1 + (msg->messageId >> 16);
		m_LastMessTime = m_pTail->m_EndTime;
		m_TotNumMsg++; // total amount of messages.
		//qDebug("]]]]]] message added %d  %s\n",msg.messageType, msg.messageText);
	}
}
//****************************************************************************
/// dump the contents of Q to trace window
///
/// @param none
///
/// @return none
///
//****************************************************************************
void CChartMessageQ::DumpQ() {
	CChartMessageBlock *pBlock = m_pHead;
	qDebug("\nMESSAGE Q DUMP ========================================================\n");
	qDebug("tot msg %d\n", m_TotNumMsg);
	qDebug("num blocks %d\n", m_NumMsgBlocks);
	int chk = 0;
	while (pBlock) {
		chk += pBlock->m_NumMessages;
		pBlock->Dump();
		pBlock = pBlock->m_pNext;
	}
	qDebug("DUMP END ========================================================\n\n");
	if (chk != m_TotNumMsg)
		qDebug("actual tot msg %d\n", chk);
}
//****************************************************************************
/// dump a message contents to the trace window
///
/// @param[in] dMessage - message to trace contents of
///
/// @return none
///
//****************************************************************************
void CChartMessageQ::DumpMessage(T_MSGLISTSER_MESSAGE *dMessage) {
	CTimeHistory *pTh = CTimeHistory::GetHandle();
	TableEntry *pEntry = pTh->GetEntry(dMessage->messageId >> 16);
	if (!pEntry)
		return; // major problem here - no time history!
	LONGLONG diffmicro = ((dMessage->messageId >> 16) - pEntry->Tick100) * 10000;
	CTVtime displaytime = pEntry->ActualTime + diffmicro;
	CHAR buff[50];
	displaytime.TimeToStringShort(buff);
	qDebug("Message Time %s  Text: %s\n", buff, dMessage->messageText);
}
///////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  CChartMessageBlock
//
///////////////////////////////////////////////////////////////////////////////////////////////////////
//****************************************************************************
/// CChartMessageBlock Constructor
///
/// @param[in] pParent		- pointer to parent CChartMessageQ
/// @param[in] IsTail		- flag to indicate block is tail block
///
//****************************************************************************
CChartMessageBlock::CChartMessageBlock(CChartMessageQ *pParent, BOOL IsTail) //=FALSE
		{
	m_pParent = pParent;
	m_StartTime = 0;
	m_EndTime = 0;
	m_pMessages = NULL;
	m_NumMessages = 0;
	for (int i = 0; i < NUM_CHART_MESSAGE_Qs; i++) {
		m_SpanRequested[i] = IsTail;  // here for IsTail is TRUE set these to prevent requests from SD
		m_SpanCovered[i] = IsTail;
		m_LastMessageTime[i] = 0;
	}
	m_pNext = NULL;
	m_pPrev = NULL;
	m_pParent->m_NumMsgBlocks++;
}
//****************************************************************************
/// CChartMessageBlock Destructor
///
/// @param none
///
//****************************************************************************
CChartMessageBlock::~CChartMessageBlock() {
	while (m_pMessages) {
		MessageHolder *temp = m_pMessages;
		m_pMessages = m_pMessages->pNext;
		delete temp;
		m_pParent->m_TotNumMsg--;
	}
	m_pParent->m_NumMsgBlocks--;
}
//****************************************************************************
/// Reset this block for use again.
///
/// @param[in] IsTail		- flag to indicate block is tail block
///
//****************************************************************************
void CChartMessageBlock::Reset(BOOL IsTail) {
	// delete any messages..
	while (m_pMessages) {
		MessageHolder *temp = m_pMessages;
		m_pMessages = m_pMessages->pNext;
		delete temp;
	}
	m_pParent->m_TotNumMsg -= m_NumMessages; // take off from the total no of messages
	m_NumMessages = 0;
	for (int i = 0; i < NUM_CHART_MESSAGE_Qs; i++) {
		m_SpanRequested[i] = IsTail;
		m_SpanCovered[i] = IsTail;
		m_LastMessageTime[i] = 0;
	}
}
//****************************************************************************
/// Extract messages from the request block returned from SD and add to list.
///
/// @param[in] messType				- message 'type' (queue from which it is from)
/// @param[in] pBlocks				- pointer to blocks containing messages
/// @param[in] numOfBlocksObtained	- what it says on the tin
///
/// @return T/F if inserted messages
///
//****************************************************************************
BOOL CChartMessageBlock::ExtractMessages(int messType, MessageRec *pBlocks, int numOfBlocksObtained) {
	BOOL inserted = FALSE;
	// NB here we convert the start and end times of the block for comparing with messageID
	LONGLONG StartID = m_StartTime << 16;
	LONGLONG EndID = m_EndTime << 16;
	// NB we do this in reverse order, last block first and last message first
	for (int i = numOfBlocksObtained - 1; i >= 0; i--) {
		// how many messages in this block?
		int messinblock = pBlocks[i].NumMessages;
		if (messinblock == 0) {
			qDebug("[][][] NO BLOCK RETURNED MESSAGE QUEUE %d [][][]\n", messType);
			//DebugBreak();
		}
		if (messinblock > 3) {
			qDebug("[][][] CORRUPTED BLOCK RETURNED MESSAGE QUEUE %d [][][]\n", messType);
			//DebugBreak(); // if it breaks here, we have a corrupted message
			messinblock = 0;
		}
		for (int j = messinblock - 1; j >= 0; j--) {
			// see if the message fits within the time for this block
			if ((pBlocks[i].message[j].messageId < StartID) || (pBlocks[i].message[j].messageId < Glb_FirstMessageID)) {
				//qDebug("extract messages - after end time by %I64d\n", (pBlocks[i].message[j].messageId-EndID)>>16);
				m_SpanCovered[messType] = TRUE;
				if (pBlocks[i].message[j].messageType <= MSGLISTSER_ALARM_ACK_WHILE_OUT) // Is an alarm message
						{
					// see if this one is ahead of the head in the list and after the one we are currently using
					// if so, use it.
					if (((pBlocks[i].message[j].messageId >> 16) < m_pParent->m_pHead->m_StartTime)
							&& (pBlocks[i].message[j].messageId > m_pParent->m_QNewAlarmMessage.messageId)) {
						m_pParent->m_QNewAlarmMessage = pBlocks[i].message[j];
						if (SHOWMESSREQ)
							qDebug("MM extract messages - before start time by %I64d\n",
									(pBlocks[i].message[j].messageId - StartID) >> 16);
					}
				}
				break;
			}
			if (pBlocks[i].message[j].messageId < EndID) {
				T_MSGLISTSER_MESSAGE *ptrMess = &pBlocks[i].message[j];
				// here throw away system and user messages that are not mark on chart
				if (messType == USER_MESSAGE) {
					if ((ptrMess->messageData.uCharParam[MSGLISTSER_USER_DESTINATION_UCHAR_ELEMENT] & MARK_CHART)
							!= MARK_CHART)
						continue; // ignore this message
				} else if (messType == SYSTEM_MESSAGE) {
					// some system messages will be marked as "do NOT mark chart"
					if ((ptrMess->messageData.uCharParam[MSGLISTSER_SYSTEM_DESTINATION_UCHAR_ELEMENT]
							& s_byDO_NOT_MARK_CHART_SYS_MSG) == s_byDO_NOT_MARK_CHART_SYS_MSG)
						continue; // ignore this message
				}
				if ((ptrMess->messageId >> 16) > m_LastMessageTime[messType])
					m_LastMessageTime[messType] = ptrMess->messageId >> 16; // convert messageid to time 100
				//qDebug("Message Extracted OK\n");
				// link into the list...
				MessageHolder **pCurrent = &m_pMessages; // address of head of list pointer
				int pos = 0;
				while (*pCurrent) {
					if ((*pCurrent)->message.messageId < ptrMess->messageId) {
						pCurrent = &((*pCurrent)->pNext); // move past items in list
						pos++;
					} else {
						if ((*pCurrent)->message.messageId == ptrMess->messageId)
							break; // already here - don't add again.
						MessageHolder *pmh = new MessageHolder;
						memcpy(&pmh->message, ptrMess, sizeof(T_MSGLISTSER_MESSAGE));
						MessageHolder *temp = (*pCurrent);
						(*pCurrent) = pmh;
						pmh->pNext = temp;
						m_NumMessages++;
						m_pParent->m_TotNumMsg++;
						inserted = TRUE;
						break;
					}
				}
				if ((*pCurrent) == NULL) {
					MessageHolder *pmh = new MessageHolder;
					memcpy(&pmh->message, ptrMess, sizeof(T_MSGLISTSER_MESSAGE));
					(*pCurrent) = pmh; // assign onto end of list
					pmh->pNext = NULL;
					m_NumMessages++;
					m_pParent->m_TotNumMsg++;
					inserted = TRUE;
				}
				// check for message limit
				if (m_pParent->m_TotNumMsg > Glb_MaxMsg) {
					// if this is the head block in the list, we can do something about it.
					// If not, then we need to allow all the messages in (for now)
					if (m_pParent->m_pHead == this) {
						// we are the head block.
						if (pos > 0) {
							//	qDebug("Message list FULL deleting earliest %I64d\n",m_pMessages->message.messageId>>16);
							// ok, remove the earliest message from the head
							MessageHolder *temp = m_pMessages;
							m_pMessages = m_pMessages->pNext;
							delete temp;
							m_NumMessages--;
							m_pParent->m_TotNumMsg--;
						} else {
							//	qDebug("Message list FULL  increasing new start time to %I64d\n",ptrMess->messageId>>16);
							// actually at the start of the head block.
							StartID = ptrMess->messageId; // no more messages will pass the first test above
							// do not change the block start time - will be older than the data. (but no earlier requests will get done)
						}
					}
					//else
					//	qDebug("Message list FULL  NOT head \n");
				}
			}
		}
	}
	return inserted;
}
//****************************************************************************
/// dump the block contents to the trace window
///
/// @param[in] none
///
/// @return none
///
//****************************************************************************
void CChartMessageBlock::Dump() {
	qDebug("Start %I64d  end %I64d,  Num mess %d ", m_StartTime, m_EndTime, this->m_NumMessages);
	CTimeHistory *pTh = CTimeHistory::GetHandle();
	TableEntry *pEntry = pTh->GetEntry(m_StartTime);
	if (!pEntry)
		return; // major problem here - no time history!
	LONGLONG diffmicro = (m_StartTime - pEntry->Tick100) * 10000;
	CTVtime displaytime = pEntry->ActualTime + diffmicro;
  CHAR buff[200];
	displaytime.TimeToStringShort(buff);
	qDebug("Start %s ", buff);
	pEntry = pTh->GetEntry(m_EndTime);
	if (!pEntry)
		return; // major problem here - no time history!
	diffmicro = (m_EndTime - pEntry->Tick100) * 10000;
	CTVtime displaytime2 = pEntry->ActualTime + diffmicro;
	displaytime2.TimeToStringShort(buff);
	qDebug("end %s ", buff);
	if (m_pNext) {
		if (m_EndTime > m_pNext->m_StartTime)
			qDebug("Overlaps next block");
		else if (m_EndTime != m_pNext->m_StartTime)
			qDebug("Gap to next block");
	}
	//	qDebug("\n");
	// need to check these with this list (not all used)
	/*
	 enum T_MSG_LIST_QUEUES
	 {
	 msqAlarms,
	 msqSystem,
	 msqUser,
	 msqSecurity,
	 msqDiags,
	 msqAlarms4Chart,
	 msqMAX_QUEUES
	 };
	 */
	if (!m_SpanRequested[0])
		qDebug("  Alarm Span not req\n");
	if (!m_SpanRequested[1])
		qDebug("  System Span not req\n");
	if (!m_SpanRequested[2])
		qDebug("  User Span not req\n");
	//	if(!m_SpanRequested[3])
	//		qDebug("  Security Span not req\n");
	BOOL foundAlarm = FALSE;
	BOOL foundSystem = FALSE;
	BOOL foundUser = FALSE;
	if (m_pMessages) {
		// now check start and end times match the messages within...
		MessageHolder *pmess = m_pMessages;
		while (pmess) {
			if ((pmess->message.messageId >> 16) >= m_EndTime)
				qDebug("message after block\n");
			if ((pmess->message.messageId >> 16) < m_StartTime)
				qDebug("message before block\n");
			if (pmess->message.messageType < MSGLISTSER_SYSTEM_MSG_TYPE_START)
				foundAlarm = TRUE;
			else if (pmess->message.messageType < MSGLISTSER_DIAGNOSTICS_MSG_TYPE_START)
				foundSystem = TRUE;
			else if (pmess->message.messageType < MSGLISTSER_SMTP_MSG_TYPE_START)
				foundUser = TRUE;
			pmess = pmess->pNext;
		}
	}
	if (foundAlarm)
		qDebug("Alarm[x] ");
	else
		qDebug("Alarm[ ] ");
	if (foundSystem)
		qDebug("Sys[x] ");
	else
		qDebug("Sys[ ] ");
	if (foundUser)
		qDebug("User[x]\n");
	else
		qDebug("User[ ]\n");
}
///////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  Test code
//
///////////////////////////////////////////////////////////////////////////////////////////////////////
/*
 void signtest()
 {
 UINT e=0x7f7fffff;  // FLT_MAX
 float *pf=(float*)&e;
 qDebug(" %x = %f\n",e,*pf);
 float maxflt=FLT_MAX;
 float minflt=-FLT_MAX;
 qDebug(" max float = %f  =%x \n",maxflt, *(UINT*)&maxflt);
 qDebug(" min float = %f  =%x \n",minflt, *(UINT*)&minflt);
 }
 void TestVal(float floatval)
 {
 UINT test=*((UINT*)&floatval);  // cast float to UINT.
 UINT exp=  0x7f800000; // exponent
 if((test & exp)==exp)
 qDebug("%f Not a Reading\n",floatval);
 else
 qDebug("%f is a Reading\n",floatval);
 }
 void testfloats()
 {
 // test floating point values
 UINT signN=0x80000000; // sign -ve
 UINT signP=0x00000000; // sign +ve
 UINT exp=  0x7f800000; // exponent
 UINT mant= 0x007fffff;
 UINT e=0x7f7fffff;  // FLT_MAX
 float *pf=(float*)&e;
 qDebug(" %x = %f\n",e,*pf);
 e=signP|exp|mant;
 qDebug(" %x = %f\n",e,*pf);
 float floatval1=(float)1.56;
 TestVal(floatval1);
 floatval1=(float)56000.56;
 TestVal(floatval1);
 e=0x7fffffff;
 floatval1=*((float*)&e);
 TestVal(floatval1);
 floatval1=(float)-00.56000;
 TestVal(floatval1);
 mant = 15;
 e=signP|exp|mant;
 floatval1=*((float*)&e);
 TestVal(floatval1);
 }
 */

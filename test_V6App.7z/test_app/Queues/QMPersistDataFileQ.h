/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Queue Manager
/// @n Filename:	QMPersistDataFileQ.h
/// @n Description: Class Declaration File for CQMPersistDataFileQ
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 12	Stability Project 1.9.1.1	7/2/2011 5:00:04 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 11	Stability Project 1.9.1.0	7/1/2011 4:27:36 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 10	V6 Firmware 1.9		9/14/2006 3:55:35 PM	Alistair Brugsch
//		added in functionality to allow clearing of data from chart queues
// 9	V6 Firmware 1.8		6/2/2006 2:02:59 PM	Alistair Brugsch
//		changed a test for min files to test for max files
// $
//
// **************************************************************************
#ifndef _QMPERSISTDATAFILEQ_H
#define _QMPERSISTDATAFILEQ_H
#include "QMCommon.h"
#include "QMPersistDataFileQAccess.h"
#include "QMDataFileAccess.h"
/// Enumeration to describe whether the operation of a Member Function has been
/// completed Successfully or a Failure has occurred. 
typedef enum {
	QMPDFQ_OK, QMPDFQ_NO_FILES_TO_REMOVE, QMPDFQ_FILE_OPENED, QMPDFQ_ERROR
} T_QMPDFQ_RETURN_VALUE;
/// Enumeration to indicate the Status of the File Queue
typedef enum {
	QMPDFQ_STATUS_EMPTY, QMPDFQ_STATUS_MAX_NOT_REACHED, QMPDFQ_STATUS_MAX_REACHED, QMPDFQ_STATUS_MAX_EXCEEDED
} T_QMPDFQ_QUEUE_STATUS;
/// Enumeration to indicate the type of file that is being added to the Queue
typedef enum {
	QMPDFQ_FA_NEW_FILE, QMPDFQ_FA_RECYCLED_FILE
} T_QMPDFQ_FILE_TO_ADD;
//**Class*********************************************************************
///
/// @brief Linked List Operations for a Persisted Data File Queue
/// 
/// This class manages the linked list operations on a Specified Data File Queue,
/// allowing Data Files to be obtained, added and removed. Each Queue has a minimum
/// and maximum number of files within the Queue. The Maximum number of files can 
/// be exceeded, if another queue has not reached its maximum, then queues exceeding
/// their maximum will relinshed a file for the queue requiring a file. In the case
/// that no free files are avialable then the queue is capable of recycling its Head
/// File.		
///
//****************************************************************************
class CQMPersistDataFileQ {
public:
	/// Constructor
	CQMPersistDataFileQ(CQMPersistDataFileQAccess &persistDataFileQ, CQMDataFileAccess &dataFileAccess,
			T_PQMC_DBFILES pDBFiles);
	/// Destructor
	virtual ~CQMPersistDataFileQ(void);
	/// Add File to Tail
	T_QMPDFQ_RETURN_VALUE AddFileToTail(const USHORT hQueue, const USHORT fileNumber,
			const T_QMPDFQ_FILE_TO_ADD fileToAdd);
	/// Get the Head File Header 
	T_QMC_DATAFILE_HEADER* const GetHeadFile(const USHORT hQueue) const;
	/// Get the Tail File Header
	T_QMC_DATAFILE_HEADER* const GetTailFile(const USHORT hQueue) const;
	/// Remove the Head File from the Queue
	T_QMPDFQ_RETURN_VALUE RemoveHeadFile(const USHORT hQueue);
	/// Obtain the Queue Status
	T_QMPDFQ_QUEUE_STATUS GetQueueStatus(const USHORT hQueue) const;
	/// Returns the Number of Files within the Queue
	USHORT GetNumOfFilesInQueue(const USHORT hQueue) const;
	///Returns the number of blocks used by a Queue
	ULONG GetNumBlocksInFileQueue(const USHORT hQueue, const USHORT NumFileBlocks) const;
	///Returns the number of blocks used by a Queue
	ULONG GetNumBlocksReservedInFileQueue(const USHORT hQueue, const USHORT NumFileBlocks) const;
	/// Return the number of blocks in a queue from a point
	ULONG GetNumBlocksInFileQueueFromPoint(const USHORT hQueue, const USHORT NumFileBlocks, const USHORT FileID,
			const USHORT BlockID) const;
	/// Remove all the files from the Persisted File Queue
	USHORT RemoveAllFiles(const USHORT hQueue);
	/// Display the Queue using the Trace Window - for DEBUG PURPOSES ONLY 
	void TraceQueue(const QString pName, const USHORT hQueue);
	///Set the maximum number of files per queue
	T_QMPDFQA_RETURN_VALUE SetMaxFiles(const USHORT hQueue, const USHORT NumFiles);
	///Get the maximum number of files per queue
	USHORT GetMaxFiles(const USHORT hQueue);
	///Get the number of blocks allocated to a queue through it's max files
	ULONG GetMaxNumBlocksInQueue(const USHORT hQueue, const USHORT NumFileBlocks);
private: // Member Functions
	/// Write File Header to the Physical File 
	T_QMPDFQ_RETURN_VALUE WriteFileHeaderToPhysicalFile(const USHORT fileId);
private: // Member Variables
	CQMPersistDataFileQAccess &m_PersistDataFileQ; ///< Persisted Data File Queue Interface Class
	CQMDataFileAccess &m_DataFileAccess; ///< Member Variable to gain access to the Data Files
	T_PQMC_DBFILES m_pDBFiles;
};
// End of Class Declaration
#endif // _QMPERSISTDATAFILEQ_H

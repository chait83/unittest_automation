/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Queue Manager
/// @n Filename:	QMPersistMemoryBlkQAccess.h
/// @n Description: Class Declaration File for the class CQMPersistBlkQAccess
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 7	Stability Project 1.4.1.1	7/2/2011 5:00:04 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 6	Stability Project 1.4.1.0	7/1/2011 4:27:36 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 5	V6 Firmware 1.4		11/18/2005 5:15:01 PM Alistair Brugsch
//		Took out trace lines
// 4	V6 Firmware 1.3		11/17/2005 4:24:50 PM Alistair Brugsch
//		Added functionality to test if a block of a given Queue is waiting in
//		the To Disk Queue
// $
//
// **************************************************************************
#ifndef _QMPERSISTBLKQACCESS_H
#define _QMPERSISTBLKQACCESS_H
#include "QMCommon.h"
/// Enumeration to describe whether the operation of a Member Function has been
/// completed Successfully or a Failure has occurred. 
typedef enum {
	QMPBQA_OK, QMPBQA_ERROR, QMPBQA_QUEUE_NUMBER_INVALID
} T_QMPBQA_RETURN_VALUE;
//**Class*********************************************************************
///
/// @brief ---Single line description---.
/// 
/// --- Detailed Description ---
///
//****************************************************************************
class CQMPersistBlkQAccess {
public:
	/// Constructor
	CQMPersistBlkQAccess(T_QMC_PERSIST_DATA_BLKQ *const pFirstPersistDataBlkQ, const USHORT maxNumOfQueues);
	/// Destructor
	virtual ~CQMPersistBlkQAccess(void);
	/// Set the Status of a specific Persist Data Block Queue
	T_QMPBQA_RETURN_VALUE SetStatus(const USHORT hQueue, const T_QMC_BLOCK_QUEUE_STATUS status);
	/// Set the Status of a specific Persist Data Block Queue
	T_QMPBQA_RETURN_VALUE SetUserStatus(const USHORT hQueue, const USHORT status);
	/// Set the Head Block of a specific Persist Data Block Queue
	T_QMPBQA_RETURN_VALUE SetHead(const USHORT hQueue, const USHORT head);
	/// Set the Tail Block of a specific Persist Data Block Queue
	T_QMPBQA_RETURN_VALUE SetTail(const USHORT hQueue, const USHORT tail);
	/// Set the Number of Blocks of a specific Persisit Data Block Queue
	T_QMPBQA_RETURN_VALUE SetNumOfBlocks(const USHORT hQueue, const USHORT numOfBlocks);
	/// Set the Number of Block in Queue before a flush to disk occurs
	T_QMPBQA_RETURN_VALUE SetFlushToDiskLimit(const USHORT hQueue, const USHORT flushToDiskLimit);
	/// Ser the Queue Confirmation
	T_QMPBQA_RETURN_VALUE SetQueueConfirmation(const USHORT hQueue, const T_QMC_QUEUE_CONFIRMATION queueConfirmation);
	/// Set the Queue Type
	T_QMPBQA_RETURN_VALUE SetQueueType(const USHORT hQueue, const T_QMC_QUEUE_TYPE queueType);
	/// Increment the Number of Blocks within a specific Persist Data Block Queue by One Block
	T_QMPBQA_RETURN_VALUE IncrementNumOfBlocks(const USHORT hQueue);
	/// Decrement the Number of Blocks within a specific Persist Data Block Queue by One Block
	T_QMPBQA_RETURN_VALUE DecrementNumOfBlocks(const USHORT hQueue);
	/// Get the Status of the Queue of a specific Persist Data Block Queue
	T_QMC_BLOCK_QUEUE_STATUS GetStatus(const USHORT hQueue) const;
	/// Get the User Defined Status of the Queue of a specific Persist Data Block Queue
	USHORT GetUserStatus(const USHORT hQueue) const;
	/// Get the Head Block Id of a specific Persist Data Block Queue 
	USHORT GetHead(const USHORT hQueue) const;
	/// Get the Tail Block Id of a specific Persist Data Block Queue
	USHORT GetTail(const USHORT hQueue) const;
	/// Get the Flush To Limit for a specific Persist Data Block Queue 
	USHORT GetFlushToDiskLimit(const USHORT hQueue) const;
	/// Get the Queue Confirmation Status
	T_QMC_QUEUE_CONFIRMATION GetQueueConfirmation(const USHORT hQueue) const;
	/// Get the Number of Blocks within a specific Persist Data Block Queue
	USHORT GetNumOfBlocksInQueue(const USHORT hQueue) const;
	/// Get the Queue Type
	T_QMC_QUEUE_TYPE GetQueueType(const USHORT hQueue) const;
	/// Get the Persisted Data Block Queue 
	const T_QMC_PERSIST_DATA_BLKQ& GetPersistDataBlkQ(const USHORT hQueue) const;
	/// Validate the Persisted Queue Number against the maximum Persisted Queues Avialable
	T_QMPBQA_RETURN_VALUE ValidatePersistedQueueHandler(const USHORT persistedQueueHandler);
private:
	const USHORT m_MaxNumOfQueues; ///< Maximum Number of Queues Available
	/// Pointer to the First Persisted Data Block Queue, this pointer will be used with an
	/// array subscript to access the various persisited data block queues in memory. 
	T_QMC_PERSIST_DATA_BLKQ *const m_pPersistDataBlkQ;
};
// End of Class Declaration
inline const T_QMC_PERSIST_DATA_BLKQ& CQMPersistBlkQAccess::GetPersistDataBlkQ(const USHORT hQueue) const {
	return (m_pPersistDataBlkQ[hQueue]);
} // End of Member Function
/// Set the Status of a specific Persisit Data Block Queue
inline T_QMPBQA_RETURN_VALUE CQMPersistBlkQAccess::SetStatus(const USHORT hQueue,
		const T_QMC_BLOCK_QUEUE_STATUS status) {
	m_pPersistDataBlkQ[hQueue].Status = status;
	return (QMPBQA_OK);
} // End of Member Function
/// Set the User Defined Status of a specific Persisit Data Block Queue
inline T_QMPBQA_RETURN_VALUE CQMPersistBlkQAccess::SetUserStatus(const USHORT hQueue, const USHORT status) {
	m_pPersistDataBlkQ[hQueue].UserStatus = status;
	return (QMPBQA_OK);
} // End of Member Function
/// Set the Head Block of a specific Persisit Data Block Queue
inline T_QMPBQA_RETURN_VALUE CQMPersistBlkQAccess::SetHead(const USHORT hQueue, const USHORT head) {
	m_pPersistDataBlkQ[hQueue].Head = head;
	return (QMPBQA_OK);
} // End of Member Function
/// Set the Tail Block of a specific Persisit Data Block Queue
inline T_QMPBQA_RETURN_VALUE CQMPersistBlkQAccess::SetTail(const USHORT hQueue, const USHORT tail) {
	m_pPersistDataBlkQ[hQueue].Tail = tail;
	return (QMPBQA_OK);
} // End of Member Function
/// Set the Number of Blocks of a specific Persisit Data Block Queue
inline T_QMPBQA_RETURN_VALUE CQMPersistBlkQAccess::SetNumOfBlocks(const USHORT hQueue, const USHORT numOfBlocks) {
	m_pPersistDataBlkQ[hQueue].NumOfBlocksInQueue = numOfBlocks;
	return (QMPBQA_OK);
} // End of Member Function
/// Set the Number of Block in Queue before a flush to disk occurs
inline T_QMPBQA_RETURN_VALUE CQMPersistBlkQAccess::SetFlushToDiskLimit(const USHORT hQueue,
		const USHORT flushToDiskLimit) {
	m_pPersistDataBlkQ[hQueue].FlushToDiskLimit = flushToDiskLimit;
	//qDebug("%d,",flushToDiskLimit);
	return (QMPBQA_OK);
} // End of Member Function
/// Set the Queue Confirmation 
inline T_QMPBQA_RETURN_VALUE CQMPersistBlkQAccess::SetQueueConfirmation(const USHORT hQueue,
		const T_QMC_QUEUE_CONFIRMATION queueConfirmation) {
	m_pPersistDataBlkQ[hQueue].QueueConfirmation = queueConfirmation;
	return (QMPBQA_OK);
} // End of Member Function	
/// Set the Queue Type
inline T_QMPBQA_RETURN_VALUE CQMPersistBlkQAccess::SetQueueType(const USHORT hQueue, const T_QMC_QUEUE_TYPE queueType) {
	m_pPersistDataBlkQ[hQueue].queueType = queueType;
	return (QMPBQA_OK);
} // End of Member Function 
/// Increment the Number of Blocks within a specific Persisit Data Block Queue by One Block
inline T_QMPBQA_RETURN_VALUE CQMPersistBlkQAccess::IncrementNumOfBlocks(const USHORT hQueue) {
	++m_pPersistDataBlkQ[hQueue].NumOfBlocksInQueue;
	return (QMPBQA_OK);
} // End of Member Function
/// Decrement the Number of Blocks within a specific Persisit Data Block Queue by One Block
inline T_QMPBQA_RETURN_VALUE CQMPersistBlkQAccess::DecrementNumOfBlocks(const USHORT hQueue) {
	--m_pPersistDataBlkQ[hQueue].NumOfBlocksInQueue;
	return (QMPBQA_OK);
} // End of Member Function
/// Get the Status of the Queue
inline T_QMC_BLOCK_QUEUE_STATUS CQMPersistBlkQAccess::GetStatus(const USHORT hQueue) const {
	return (static_cast<T_QMC_BLOCK_QUEUE_STATUS>(m_pPersistDataBlkQ[hQueue].Status));
} // End of Member Function
/// Get the User Status of the Queue
inline USHORT CQMPersistBlkQAccess::GetUserStatus(const USHORT hQueue) const {
	return ((m_pPersistDataBlkQ[hQueue].UserStatus));
} // End of Member Function
/// Get the Head Block Id 
inline USHORT CQMPersistBlkQAccess::GetHead(const USHORT hQueue) const {
	return (m_pPersistDataBlkQ[hQueue].Head);
} // End of Member Function
/// Get the Tail Block ID
inline USHORT CQMPersistBlkQAccess::GetTail(const USHORT hQueue) const {
	return (m_pPersistDataBlkQ[hQueue].Tail);
} // End of Member Function
/// Get the Flush To Limit for a specific Persisit Data Block Queue 
inline USHORT CQMPersistBlkQAccess::GetFlushToDiskLimit(const USHORT hQueue) const {
	return (m_pPersistDataBlkQ[hQueue].FlushToDiskLimit);
} // End of Member Function
/// Get the Number of Blocks within the Queue
inline USHORT CQMPersistBlkQAccess::GetNumOfBlocksInQueue(const USHORT hQueue) const {
	return (m_pPersistDataBlkQ[hQueue].NumOfBlocksInQueue);
} // End of Member Function
/// Get the Queue Confirmation Status
inline T_QMC_QUEUE_CONFIRMATION CQMPersistBlkQAccess::GetQueueConfirmation(const USHORT hQueue) const {
	return (static_cast<T_QMC_QUEUE_CONFIRMATION>(m_pPersistDataBlkQ[hQueue].QueueConfirmation));
} // End of Member Function
/// Get the Queue Type
inline T_QMC_QUEUE_TYPE CQMPersistBlkQAccess::GetQueueType(const USHORT hQueue) const {
	return (static_cast<T_QMC_QUEUE_TYPE>(m_pPersistDataBlkQ[hQueue].queueType));
} // End of Member Function
#endif // _QMPERSISTBLKQACCESS_H

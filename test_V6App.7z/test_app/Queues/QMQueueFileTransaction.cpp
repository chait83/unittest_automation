/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Queue Manager
/// @n Filename:	QMQueueFileTransaction.h
/// @n Description: Class Declaration File for the Class CQMQueueFileTransaction
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 7	Stability Project 1.2.1.3	7/2/2011 5:00:04 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 6	Stability Project 1.2.1.2	7/1/2011 4:38:47 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 5	Stability Project 1.2.1.1	3/17/2011 3:20:39 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 4	Stability Project 1.2.1.0	2/15/2011 3:03:48 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
// **************************************************************************
#include "QMQueueFileTransaction.h"
#include "QMCommon.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
//****************************************************************************
/// Constructor
///
//****************************************************************************
CQMQueueFileTransaction::CQMQueueFileTransaction(void) {
	m_FileId = QMC_INVALID_FILE_NUMBER;
	m_BlockId = QMC_INVALID_BLOCK_NUMBER;
	m_NumOfBlocksOfLastTransaction = QMC_ZERO;
	m_TransactionAvailable = QUEFILETTR_TRANSACTION_NOT_AVAILABLE;
} // End of Constructor
//****************************************************************************
/// Destructor
///
//****************************************************************************
CQMQueueFileTransaction::~CQMQueueFileTransaction(void) {
} // End of Destructor
//****************************************************************************
/// SetFileTransactionInfo - Set File Transaction Information
///
/// @param[in] fileId - File ID for transaction point
/// @param[in] BlockId - Block ID for Transaction point
/// @param[in] numOfBlocks - count of blocks in transaction
///
/// @return void
/// 
//****************************************************************************
void CQMQueueFileTransaction::SetFileTransactionInfo(const USHORT fileId, const USHORT blockId,
		const USHORT numOfBlocks) {
	m_FileId = fileId;
	m_BlockId = blockId;
	m_NumOfBlocksOfLastTransaction = numOfBlocks;
	m_TransactionAvailable = QUEFILETTR_TRANSACTION_AVAILABLE;
} // End of Member Function		
/// 
//****************************************************************************
/// CompleteLastTransaction - Set Complete Last Transaction, update block with
///	count of blocks in transaction
/// @param[in] n/a
///
/// @return void
/// 
//****************************************************************************
void CQMQueueFileTransaction::CompleteLastTransaction(void) {
	if (QUEFILETTR_TRANSACTION_AVAILABLE == m_TransactionAvailable) {
		m_BlockId += m_NumOfBlocksOfLastTransaction;
		m_TransactionAvailable = QUEFILETTR_TRANSACTION_NOT_AVAILABLE;
	} // End of IF
} // End of Member Function

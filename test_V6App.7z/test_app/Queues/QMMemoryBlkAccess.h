/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Queue Manager
/// @n Filename:	QMMemoryBlkAccess.h
/// @n Description: Class Declaration File for the class CQMDataBlkAccess
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 4	Stability Project 1.1.1.1	7/2/2011 5:00:03 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 3	Stability Project 1.1.1.0	7/1/2011 4:27:35 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 2	V6 Firmware 1.1		7/22/2005 4:11:16 PM	Alistair Brugsch
//		Added Doxygen Comments
// 1	V6 Firmware 1.0		6/21/2005 3:44:16 PM	Alistair Brugsch 
// $
//
// **************************************************************************
#ifndef _QMMEMORYBLKACCESS_H
#define _QMMEMORYBLKACCESS_H
#include "QMCommon.h"
/// Enumeration to describe whether the operation of a Member Function has been
/// completed Successfully or a Failure has occurred. 
typedef enum {
	QMMBA_OK, QMMBA_ERROR, QMMBA_BLOCK_NUMBER_INVALID
} T_QMMBA_RETURN_VALUE;
//**Class*********************************************************************
///
/// @brief Provides Access to a specified Data Block
/// 
/// The Queue Manager manages a number of Memory Data Blocks, this class provides
/// Member Functions for accessing a Single Data Block available from the Queue
/// Manager. The Class also provides a block validation function to ensure 
/// Block Identification Numbers are not outside the number of blocks available.
/// The Class manages the pointer to the Blocks, it does not own the 
/// pointer, the pointer is owned by the QMHardwareLayer. 
//****************************************************************************
class CQMDataBlkAccess {
public:
	/// Constructor
	CQMDataBlkAccess(T_QMC_BLOCK *const pFirstMemoryBlock, const USHORT maxNumOfBlocks);
	/// Destructor
	virtual ~CQMDataBlkAccess(void);
	/// Set the Associated Queue Indentification
	void SetQueueId(const USHORT blockNumber, const USHORT queueId);
	/// Set the Block Status 
	void SetStatus(const USHORT blockNumber, const USHORT status);
	/// Set the Block Type
	void SetType(const USHORT blockNumber, const USHORT type);
	/// Set the Next Block
	void SetNextBlock(const USHORT blockNumber, const USHORT nextBlock);
	/// Get the Block Identification Number
	USHORT GetBlockId(const USHORT blockNumber) const;
	/// Get the Associated Queue ID 
	USHORT GetQueueId(const USHORT blockNumber) const;
	/// Get the Block Status
	USHORT GetStatus(const USHORT blockNumber) const;
	/// Get the Block Type
	USHORT GetType(const USHORT blockNumber) const;
	/// Get the Next Block
	USHORT GetNextBlock(const USHORT blockNumber) const;
	/// Get the Max Num Of Blocks
	USHORT GetMaxNumOfBlocks(void) const;
	/// Validate the Block Number
	T_QMMBA_RETURN_VALUE ValidateBlockNumber(const USHORT blockNumber);
	/// Get a Specific Block 
	T_QMC_BLOCK* const GetBlock(const USHORT blockNumber);
private:
	const USHORT m_MaxNumOfBlocks; ///< Max Number of Blocks Available
	/// Pointer to the First Memory Block, this pointer will be used with an
	/// array subscript to access the various available blocks in memory. 
	T_QMC_BLOCK *const m_Block;
};
// End of Class Declaration
// inline Member Functions
//****************************************************************************
/// Get the Block Identification Number for the specified Block
///
/// @param[in] 	blockNumber - Block to obtained the data from
///
/// @return Block Identification Number 
/// 
//****************************************************************************
inline USHORT CQMDataBlkAccess::GetBlockId(const USHORT blockNumber) const {
	return (m_Block[blockNumber].blockHeader.blockId);
} // End of Member Function
//****************************************************************************
/// Get the Queue Identification Number Associated with the Block
///
/// @param[in] 	blockNumber - Block to obtained the data from
///
/// @return Queue Identification Number 
/// 
//****************************************************************************
inline USHORT CQMDataBlkAccess::GetQueueId(const USHORT blockNumber) const {
	return (m_Block[blockNumber].blockHeader.QueueId);
} // End of Member Function
//****************************************************************************
/// Get the Status of the Specified Block
///
/// @param[in] 	blockNumber - Block to obtained the data from
///
/// @return Block Status
/// 
//**************************************************************************** 
inline USHORT CQMDataBlkAccess::GetStatus(const USHORT blockNumber) const {
	return (m_Block[blockNumber].blockHeader.blockstatus);
} // End of Member Function
//****************************************************************************
/// Get the Type of the Specified Block
///
/// @param[in] 	blockNumber - Block to obtained the data from
///
/// @return Block Status
/// 
//**************************************************************************** 
inline USHORT CQMDataBlkAccess::GetType(const USHORT blockNumber) const {
	return (m_Block[blockNumber].blockHeader.blockType);
} // End of Member Function
//****************************************************************************
/// Get the Next Block Id Number of the Specified Block
///
/// @param[in] 	blockNumber - Block to obtained the data from
///
/// @return Next Block Identification Number
/// 
//**************************************************************************** 
inline USHORT CQMDataBlkAccess::GetNextBlock(const USHORT blockNumber) const {
	return (m_Block[blockNumber].blockHeader.nextBlock);
} // End of Member Function
//****************************************************************************
/// Get the Maximum Number of Blocks
///
/// @param[in] - NONE
///
/// @return Maximum Number of Blocks
/// 
//**************************************************************************** 
inline USHORT CQMDataBlkAccess::GetMaxNumOfBlocks(void) const {
	return (m_MaxNumOfBlocks);
} // End of Member Function
//****************************************************************************
/// Set the Queue Identification Number for the Specified Block
///
/// @param[in] blockNumber - Block Number to Set the Required Data for
/// @param[in] queueId	- Queue Identifcation Number
///
/// @return No Return Value
/// 
//**************************************************************************** 
inline void CQMDataBlkAccess::SetQueueId(const USHORT blockNumber, USHORT queueId) {
	m_Block[blockNumber].blockHeader.QueueId = queueId;
} // End of Member Function
//****************************************************************************
/// Set the Status for the Specified Block
///
/// @param[in] blockNumber - Block Number to Set the Required Data for
/// @param[in] status	- Block Status
///
/// @return No Return Value
/// 
//**************************************************************************** 
inline void CQMDataBlkAccess::SetStatus(const USHORT blockNumber, USHORT status) {
	m_Block[blockNumber].blockHeader.blockstatus = status;
} // End of Member Function
//****************************************************************************
/// Set the Type for the Specified Block
///
/// @param[in] blockNumber - Block Number to Set the Required Data for
/// @param[in] status	- Block Type
///
/// @return No Return Value
/// 
//**************************************************************************** 
inline void CQMDataBlkAccess::SetType(const USHORT blockNumber, USHORT type) {
	m_Block[blockNumber].blockHeader.blockType = type;
} // End of Member Function
//****************************************************************************
/// Set the Next Block Identification Number for the Specified Block
///
/// @param[in] blockNumber - Block Number to Set the Required Data for
/// @param[in] status	- Next Block Identification Number
///
/// @return No Return Value
/// 
//**************************************************************************** 
inline void CQMDataBlkAccess::SetNextBlock(const USHORT blockNumber, USHORT nextBlock) {
	m_Block[blockNumber].blockHeader.nextBlock = nextBlock;
} // End of Member Function
#endif // _QMMEMORYBLKACCESS_H

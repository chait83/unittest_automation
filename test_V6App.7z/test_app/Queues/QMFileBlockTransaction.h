/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Queue Manager
/// @n Filename:	QMFileBlockTransaction.h
/// @n Description: Class Declaration File for CQMFileBlockTransaction
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 4	Stability Project 1.1.1.1	7/2/2011 5:00:03 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 3	Stability Project 1.1.1.0	7/1/2011 4:27:37 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 2	V6 Firmware 1.1		7/22/2005 4:11:15 PM	Alistair Brugsch
//		Added Doxygen Comments
// 1	V6 Firmware 1.0		7/5/2005 1:29:40 PM	Alistair Brugsch 
// $
//
// **************************************************************************
#ifndef _QMFILEBLOCKTRANSACTION_H
#define _QMFILEBLOCKTRANSACTION_H
#include "QMCommon.h"
/// Enumeration to describe whether the operation of a Member Function has been
/// completed Successfully or a Failure has occurred.
typedef enum {
	QMFBTRANS_OK, QMFBTRANS_INITIALISATION_FAILED, QMFBTRANS_ERROR
} T_QMFBTRANS_RETURN_VALUE;
//**Class*********************************************************************
///
/// @brief Stores the User File / Block Transaction for a Persisted Queue
/// 
/// This class is responsible for maintaining the current user file position in terms 
/// of the File Number, Block Number and the Number of Blocks in the last request 
/// for a Persisted Queue within Dynamic Memory. Once the Request has been processed 
/// the File Position is updated with the number of blocks they last requested. 
/// The File / Block Transaction will always store the next position to read from, 
/// this position may be invalid due to the end of the file being reached, 
/// in this case the next file if available is obtained, and the File/Block 
/// Transaction is updated. Once the initial the File / Block Transaction has been
/// set, calls such as GetNextBlocks and GetPrevious Blocks can be made. 
///	
//****************************************************************************
class CQMFileBlockTransaction {
public:
	/// Constructor
	CQMFileBlockTransaction(const USHORT numOfQueues);
	/// Destructor
	virtual ~CQMFileBlockTransaction(void);
	/// Initialise the Class for Operation 
	T_QMFBTRANS_RETURN_VALUE Initialise(void);
	/// Obtain a Pointer to a Queue File/Block Transaction 
	T_QMC_FILE_BLOCK_TRANSACTION* const GetFileBlockTransaction(const USHORT hQueue);
	/// Set the File Block Transaction for a Specified Queue
	void SetFileBlockTransaction(const USHORT hQueue, const USHORT fileId, const USHORT blockId,
			const USHORT numOfBlocks);
	/// Complete the Last Transaction the User made
	void CompleteLastTransaction(const USHORT hQueue);
private:
	const USHORT m_QMFBTRANS_NUM_OF_QUEUES; ///< Constant for the Number of Available Queues
	/// An Array for each available queue to store the last transaction
	T_QMC_FILE_BLOCK_TRANSACTION *m_pFileBlockTransaction;
};
// End of Class Declaration
#endif // _QMFILEBLOCKTRANSACTION_H

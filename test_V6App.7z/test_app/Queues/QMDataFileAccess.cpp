/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Queue Manager
/// @n Filename:	QMMemoryBlkAccess.cpp
/// @n Description: Class Implementation File for the class CQMDataBlkAccess
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 10	Stability Project 1.5.1.3	7/2/2011 5:00:02 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 9	Stability Project 1.5.1.2	7/1/2011 4:38:44 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 8	Stability Project 1.5.1.1	3/17/2011 3:20:38 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 7	Stability Project 1.5.1.0	2/15/2011 3:03:46 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
// **************************************************************************
#include "QMDataFileAccess.h"
#include "V6globals.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
//****************************************************************************
/// Constructor
///
/// @param[in] 	pFirstDataFile - Pointer to the First Data File Header in Memory 
/// @param[in] maxNumOfFiles - Maximum Number of Files Allowed
///
/// @return No Return Value
/// 
//****************************************************************************
CQMDataFileAccess::CQMDataFileAccess(T_QMC_DATAFILE_HEADER *const pFirstDataFile, const USHORT maxNumOfFiles)
: m_pDataFile(pFirstDataFile), m_MaxNumOfFiles(maxNumOfFiles) {
	// Do Nothing
} // End of Constructor
//****************************************************************************
/// Destructor
//****************************************************************************
CQMDataFileAccess::~CQMDataFileAccess(void) {
	// Do Nothing 
} // End of Destructor
/// Validate the Block Number
//****************************************************************************
/// Validates the File Number against the Maximum Number of Files allowed.
///
/// @param[in] fileNumber - File Number to be Validate
///
/// @return QMDFA_OK				- File Number is VALID
///		QMDFA_FILE_NUMBER_INVALID - File Number is INVALID
/// 
//****************************************************************************
T_QMDFA_RETURN_VALUE CQMDataFileAccess::ValidateFileNumber(const USHORT fileNumber) const {
	T_QMDFA_RETURN_VALUE retValue = QMDFA_OK;
	if (fileNumber >= m_MaxNumOfFiles) {
		retValue = QMDFA_FILE_NUMBER_INVALID;
	} // End of IF
	return (retValue);
} // End of Member Function 
//****************************************************************************
/// Obtain a Pointer to the Data File Header, a request should never be made to
/// a File Number that does not exist. An Assertions error will be thrown in 
/// debug mode if a File Number is not Valid. 
///
/// @param[in] fileNumber - File Number to be Obtained
///
/// @return Pointer to the Requested File Header
/// 
//****************************************************************************
T_QMC_DATAFILE_HEADER* const CQMDataFileAccess::GetFileHeader(const USHORT fileNumber) {
	if (QMDFA_OK != ValidateFileNumber(fileNumber)) {
		QString strError("");
		strError = QString::asprintf("GetFileHeader - Invalid file number (%u)", fileNumber);
    V6CriticalMessageBox(NULL, strError, "CQMDataFileAccess Error", MB_OK );
	}
	return (&m_pDataFile[fileNumber]);
} // End of Member Function
//****************************************************************************
/// Build subfolder for a data file, to improve access speeds data files are split into
/// several subfolders determined by NUMBER_OF_FOLDER_SPREAD_OVER, access slows down when more the 400
/// in one directory
///
/// @param[in,out] pFileAndPathToComplete - partial file path to complete with sub driectory
/// @param[in] fileNumber - File Number to be Obtained
///
/// @return Pointer to the Requested File Header
/// 
//****************************************************************************
void CQMDataFileAccess::CompleteDataFilePath(QString pFileAndPathToComplete, int pFileAndPathToCompleteBuffSize,
		USHORT fileID) {
  pFileAndPathToComplete = QString::asprintf("%s%s%d/", pFileAndPathToComplete.toLocal8Bit().data(),
			DATA_BLOCK_SUBDIR_PREFIX, fileID % NUMBER_OF_FOLDER_SPREAD_OVER);
	// Default flat directory
//	swprintf(pFileAndPathToComplete, L"%s",pFileAndPathToComplete );
}
//****************************************************************************
/// Build filename for a data file
///
/// @param[in,out] pFileAndPathToComplete - partial file path to complete with filename
/// @param[in] fileID - number of file 
///
/// @return Pointer to the Requested File Header
/// 
//****************************************************************************
void CQMDataFileAccess::CompleteDataFileName(QString pFileAndPathToComplete, int pFileAndPathToCompleteBuffSize,
		USHORT fileID) {
  pFileAndPathToComplete = QString::asprintf("%s%s%04d%s", pFileAndPathToComplete.toLocal8Bit().data(),
			DATA_BLOCK_FILE_NAME, fileID, DATA_BLOCK_FILE_EXTENSION);
}

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Queue Manager
/// @n Filename:	QMUserRequestServices.CPP
/// @n Description: Class Declaration File for the Class CQMUserRequestServices
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 62	Stability Project 1.57.1.3	7/2/2011 5:00:05 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 61	Stability Project 1.57.1.2	7/1/2011 4:38:47 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 60	Stability Project 1.57.1.1	3/17/2011 3:20:39 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 59	Stability Project 1.57.1.0	2/15/2011 3:03:48 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
// **************************************************************************
#include "QMUserRequestServices.h"
#include "OpPanelIncludes.h"
#include "logrec.h"
#include "QueueManager.h"
#include "V6globals.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
ULONG glb_MsgCntPan = 0;
ULONG glb_MsgCntCht = 0;
ULONG glb_MsgCntMsg = 0;
ULONG glb_MsgCntLog = 0;
ULONG glb_MsgCntOth = 0;
///@todo -- setup file access to use the file pointers as in the Disk Handler
///		rather than on-demand file open and closing
CQMUserRequestServices::CQMUserRequestServices(const CQMMemoryOpDataAccess &memoryOpDataAccess,
		const CQMPersistBlkQAccess &persistedBlkQAccess, CQMPersistDataFileQAccess &persistedDataFileQAccess,
		CQMDataFileAccess &dataFileAccess, T_PQMC_DBFILES pDBFiles, CQMBlkQAccess &toDiskBlkQAccess,
		CQMBlkQAccess &tempStorageBlkQAccess)
: m_MemoryOpDataAccess(memoryOpDataAccess), m_PersistedBlkQAccess(persistedBlkQAccess), m_PersistedDataFileQAccess(
		persistedDataFileQAccess), m_DataFileAccess(dataFileAccess), m_PersistedDataFileQ(persistedDataFileQAccess,
		dataFileAccess, pDBFiles), m_pToDiskQ(&toDiskBlkQAccess), m_pTempStoredBlkQ(&tempStorageBlkQAccess) {
} // End of Constructor				
CQMUserRequestServices::~CQMUserRequestServices(void) {
	delete[] m_pBlockHeader;
	delete m_pUserIntMessageQueue;
	m_pBlockHeader = NULL;
} // End of Destructor
//****************************************************************************
///
/// Initialise - Initialise members
///
/// @param[in] 	pFileBlockTransaction - transaction to init m_pFileBlockTransaction
///
/// @return - n/a
/// 
//****************************************************************************	
void CQMUserRequestServices::Initialise(CQMFileBlockTransaction *pFileBlockTransaction) {
	m_pUserIntMessageQueue = new CInternalMessageQueue();
	//m_pUserIntMessageQueue->InitInternalMessageQueue( 50, 2048, 0, IMQ_USE_MANUAL );
	m_pUserIntMessageQueue->InitInternalMessageQueue(74,
			100 + 74 * (sizeof(T_USRREQSER_USER_MESSAGE_REQUEST) + sizeof(CInternalMessage)), 0, IMQ_USE_MANUAL);
	m_pBlockHeader = new BYTE[100];
	m_pFileBlockTransaction = pFileBlockTransaction;
} // End of Member Function 
//****************************************************************************
///
/// PostUserRequest - posts a message on the internal message queue
///
/// @param[in]	pUserMessageRequest - pointer to message buffer
/// @param[in]	dataLength - length of message
///
/// @return - T_IMQ_RETURN_VALUE
/// 
//****************************************************************************	
/*
 T_IMQ_RETURN_VALUE CQMUserRequestServices::PostUserRequest( BYTE *pUserMessageRequest, USHORT dataLength )
 {
 return m_pUserIntMessageQueue->PostInternalMessage( IMQ_DATA, dataLength, pUserMessageRequest );
 } // End of Member Function
 */
//****************************************************************************
///
/// RegisterUsingIntMsgQueue - register as a user of the internal message queue
///
/// @param[in]	user - ID of queue user
/// @param[in,out] pInternalMessageQueue - pointer to the message queue instance
///
/// @return - USRREQSER_OK
///		USRREQSER_REGISTERED
/// 
//****************************************************************************		
T_USRREQSER_RETURN_VALUE CQMUserRequestServices::RegisterUsingIntMsgQueue(const T_USRREQSER_USER user,
		CInternalMessageQueue *pInternalMessageQueue) {
	T_USRREQSER_RETURN_VALUE retValue = USRREQSER_REGISTRATION_FAILED; // Member Function Return Value
	if (NULL != pInternalMessageQueue) {
		m_DiskServiceUser[user].registeredStatus = USRREQSER_REGISTERED;
		m_DiskServiceUser[user].pInternalMessageQueue = pInternalMessageQueue;
		retValue = USRREQSER_OK;
	} // End of IF
	return (retValue);
} // End of Member Function												
//****************************************************************************
///
/// ProcessUserRequest - read internal messages and filter messages to handlers
///
/// @param - n/a
///
/// @return - n/a
/// 
//****************************************************************************		
T_USRREQSER_RETURN_VALUE CQMUserRequestServices::ProcessUserRequest(void) {
	BOOL replyRequired = FALSE;
	T_USRREQSER_USER_MESSAGE_REPLY userMessageReply;
	T_USRREQSER_RETURN_VALUE retValue = USRREQSER_NO_AVAILABLE_REQUEST;
	T_USRREQSER_REPLY_TO_USER_STATUS replytoUserStatus = USRREQSER_RTU_NO_REPLY_REQUIRED;
	USHORT fileId = QMC_INVALID_FILE_NUMBER;
	USHORT blockId = QMC_INVALID_BLOCK_NUMBER;
	const CInternalMessage *const pInternalMessage = m_pUserIntMessageQueue->ReadInternalMessage();
	if (NULL != pInternalMessage) {
		const T_USRREQSER_USER_MESSAGE_REQUEST *pUserMessageRequest =
				reinterpret_cast<const T_USRREQSER_USER_MESSAGE_REQUEST*>(pInternalMessage->m_MsgData);
		USHORT DataQTotal = QMC_TOTAL_NO_OF_PEN_QUEUES;
		//do some validation
		switch (pUserMessageRequest->user) {
		case USRREQSER_USER_OPPANEL:
#ifndef DBL_STORAGE_CS_THREAD //Auto Ops thread Heartbeat monitoring
			//should only use Chart and Message Queues
			glb_MsgCntPan++;
#endif
			if ((pUserMessageRequest->hQueue >= QMC_LAST_QUEUE_ID)
					|| ((pUserMessageRequest->hQueue < DataQTotal)
							&& (pUserMessageRequest->hQueue % QMC_TOTAL_NO_OF_QUEUES_PER_PEN == 0))) {
				//just trace for now, throw errors if it looks likely
				qDebug("@@@@@@Tell Al~~~~~Op Panel using User Request Services. Queue %d Action %d\n",
						pUserMessageRequest->hQueue, pUserMessageRequest->userAction);
			}
			break;
		case USRREQSER_USER_LOGGING:
#ifndef DBL_STORAGE_CS_THREAD
			glb_MsgCntLog++;
#endif
			//should only use Log and message queues
			if ((pUserMessageRequest->hQueue >= QMC_LAST_QUEUE_ID)
					|| ((pUserMessageRequest->hQueue < DataQTotal)
							&& (pUserMessageRequest->hQueue % QMC_TOTAL_NO_OF_QUEUES_PER_PEN != 0)))
				qDebug("@@@@@@Tell Al~~~~~Logging using User Request Services. Queue %d Action %d\n",
						pUserMessageRequest->hQueue, pUserMessageRequest->userAction);
			break;
		case USRREQSER_USER_MESSAGE_SERVICES:
#ifndef DBL_STORAGE_CS_THREAD
			glb_MsgCntMsg++; //Update only when not used for THread ID tracking of CStorage CS
#endif
			//should ONLY use message queues
			if ((pUserMessageRequest->hQueue >= QMC_LAST_QUEUE_ID) || (pUserMessageRequest->hQueue < DataQTotal))
				qDebug("@@@@@@Tell Al~~~~~Message list Services using User Request Services. Queue %d\n",
						pUserMessageRequest->hQueue);
			break;
		case USRREQSER_USER_CHART_LOCAL:
#ifndef DBL_AUTO_OPS_THREAD_HB //Auto Ops thread Heartbeat monitoring
			glb_MsgCntCht++;
#endif
			//should only use chart queues with Get Oldest Data
			if ((pUserMessageRequest->hQueue >= QMC_LAST_QUEUE_ID)
					|| ((pUserMessageRequest->hQueue < DataQTotal)
							&& (pUserMessageRequest->hQueue % QMC_TOTAL_NO_OF_QUEUES_PER_PEN == 0)))
				qDebug("@@@@@@Tell Al~~~~~Chart local using User Request Services. Queue %d\n",
						pUserMessageRequest->hQueue);
			break;
		default:
			glb_MsgCntOth = 15; //Morethan this -->(USRREQSER_UA_IS_QOBJ_IN_TDQ + 1);
			qDebug("@@@@@@Tell Al~~~~~Unknown user &d using User Request Services. Queue %d\n",
					pUserMessageRequest->user, pUserMessageRequest->hQueue);
			break;
		}
		// Construct User Message Reply, set to Inidcate Failure as Default
		userMessageReply.hQueue = pUserMessageRequest->hQueue;
		userMessageReply.requestAction = pUserMessageRequest->userAction;
		userMessageReply.numOfBlocksRequested = pUserMessageRequest->numOfBlocks;
		userMessageReply.numOfBlocksObtained = QMC_ZERO;
		userMessageReply.requestReply = USRREQSER_REQUEST_FAILED;
		userMessageReply.requestReplyAdditionalInfo = USRREQSER_REPLY_NO_ADDITIONAL_INFO;
		userMessageReply.startTime = pUserMessageRequest->startTime;
		glb_MsgCntOth = pUserMessageRequest->userAction;
		switch (pUserMessageRequest->userAction) {
		case USRREQSER_UA_GET_BLOCKS_FROM_FIRST_AVAILABLE:
			//				qDebug("+++++++++++processing USRREQSER_UA_GET_BLOCKS_FROM_FIRST_AVAILABLE\n");
			ProcessGetFirstAvailableRequest(*pUserMessageRequest, userMessageReply);
			replytoUserStatus = USRREQSER_RTU_REPLY_TO_USER;
			break;
		case USRREQSER_UA_GET_PREVIOUS_BLOCKS_FROM_NEWEST_AVAILABLE:
			//				qDebug("+++++++++++processing USRREQSER_UA_GET_PREVIOUS_BLOCKS_FROM_NEWEST_AVAILABLE\n");
			ProcessGetPrevBlocksFromNewestAvailableRequest(*pUserMessageRequest, userMessageReply);
			replytoUserStatus = USRREQSER_RTU_REPLY_TO_USER;
			break;
		case USRREQSER_UA_GET_NEXT_BLOCKS_FROM_START_TIME:
			//				qDebug("+++++++++++processing USRREQSER_UA_GET_NEXT_BLOCKS_FROM_START_TIME\n");
			ProcessNextBlocksFromStartTimeRequest(*pUserMessageRequest, userMessageReply);
			replytoUserStatus = USRREQSER_RTU_REPLY_TO_USER;
			break;
		case USRREQSER_UA_GET_NEXT_BLOCKS:
			//				qDebug("+++++++++++processing USRREQSER_UA_GET_NEXT_BLOCKS\n");
			ProcessNextBlocksRequest(*pUserMessageRequest, userMessageReply);
			replytoUserStatus = USRREQSER_RTU_REPLY_TO_USER;
			break;
		case USRREQSER_UA_GET_PREVIOUS_BLOCKS_FROM_START_TIME:
			//				qDebug("+++++++++++processing USRREQSER_UA_GET_PREVIOUS_BLOCKS_FROM_START_TIME\n");
			ProcessPreviousBlocksFromStartTimeRequest(*pUserMessageRequest, userMessageReply);
			replytoUserStatus = USRREQSER_RTU_REPLY_TO_USER;
			break;
		case USRREQSER_UA_GET_PREVIOUS_BLOCKS:
			//				qDebug("+++++++++++processing USRREQSER_UA_GET_PREVIOUS_BLOCKS\n");
			ProcessPreviousBlocksRequest(*pUserMessageRequest, userMessageReply);
			replytoUserStatus = USRREQSER_RTU_REPLY_TO_USER;
			break;
		case USRREQSER_UA_RESET_TO_OLDEST_AVIALABLE:
			//				qDebug("+++++++++++processing USRREQSER_UA_RESET_TO_OLDEST_AVIALABLE\n");
			ProcessResetToOldestAvailableRequest(*pUserMessageRequest);
			break;
		case USRREQSER_UA_COMPLETE_TRANSACTION:
			//				qDebug("+++++++++++processing USRREQSER_UA_COMPLETE_TRANSACTION\n");
			ProcessCompleteTransactionRequest(*pUserMessageRequest);
			break;
		case USRREQSER_UA_GET_NUM_BLOCKS_IN_QUEUE_FROM_POINT:
			//				qDebug("+++++++++++processing USRREQSER_UA_GET_NUM_BLOCKS_IN_QUEUE_FROM_POINT\n");
			ProcessGetNumBlocksInQueueFromPoint(*pUserMessageRequest, userMessageReply);
			replytoUserStatus = USRREQSER_RTU_REPLY_TO_USER;
			break;
		case USRREQSER_UA_IS_QOBJ_IN_TDQ:
			//				qDebug("+++++++++++processing USRREQSER_UA_IS_QOBJ_IN_TDQ\n");
			ProcessQObjectInToDiskQ(*pUserMessageRequest, userMessageReply);
			replytoUserStatus = USRREQSER_RTU_REPLY_TO_USER;
			break;
		default:
            V6WarningMessageBox(NULL, "QMUserRequestServices.cpp: Unknown user action requested",
                    "QM User Request Services Error", MB_OK );
			/// TODO: indexOf alt to DebugBreak
			//				DebugBreak();
			break;
		} // End of SWITCH
		if (USRREQSER_MAINTAIN_FILE_TRANS_INT == pUserMessageRequest->userFileTransactionType) {
			m_pFileBlockTransaction->CompleteLastTransaction(pUserMessageRequest->hQueue);
		} // End of IF
		if (USRREQSER_RTU_REPLY_TO_USER == replytoUserStatus) {
			if (USRREQSER_REGISTERED == m_DiskServiceUser[pUserMessageRequest->user].registeredStatus) {
				// Post the User Reply to their Request, Local variable to the message queue to post reply
				// has been declared for readability.
				CInternalMessageQueue *pReplyInternalMessageQueue =
						m_DiskServiceUser[pUserMessageRequest->user].pInternalMessageQueue;
				if (NULL != pReplyInternalMessageQueue) {
					pReplyInternalMessageQueue->PostInternalMessage(IMQ_DATA, sizeof(T_USRREQSER_USER_MESSAGE_REPLY),
							reinterpret_cast<BYTE*>(&userMessageReply));
				} // End of IF
			} // End of IF
		} // End of IF
		// Remove the Message from the Internal Message Queue
		m_pUserIntMessageQueue->RemoveInternalMessage();
		retValue = USRREQSER_OK;
	} // End of IF
	return (retValue);
} // End of Member Function	
//****************************************************************************
///
/// ProcessPreviousBlocksFromStartTimeRequest - get blocks backwards from a time point
///
/// @param[in,out] userMessageRequest - request details including start time
/// @param[in,out] userMessageReply - reply details
///
/// @return - n/a
/// 
//****************************************************************************	
void CQMUserRequestServices::ProcessPreviousBlocksFromStartTimeRequest(
		const T_USRREQSER_USER_MESSAGE_REQUEST &userMessageRequest, T_USRREQSER_USER_MESSAGE_REPLY &userMessageReply) {
	T_QMC_FILE_BLOCK_TRANSACTION fileBlockTransaction;
	fileBlockTransaction.blockId = QMC_ZERO;
	fileBlockTransaction.fileId = QMC_ZERO;
	fileBlockTransaction.numOfBlocksLastRequested = QMC_ZERO;
	BOOL fileRequestRequired = TRUE;
	// Determine whether the Queue has any associated Files
	if (QMPDFQ_STATUS_EMPTY != m_PersistedDataFileQ.GetQueueStatus(userMessageRequest.hQueue)) {
		T_USRREQSER_FIND_FILE_CTN_BLOCK_RESULT findFileResult = indexOfFileSearchAlgorthim(userMessageRequest.hQueue,
				userMessageRequest.startTime);
		fileBlockTransaction.fileId = findFileResult.fileId;
		// Step 1: indexOf the File Containing the Starting Block
		switch (findFileResult.compareResult) {
		//this is the file we're looking for
		case DETAILED_BLOCK_SEARCH_REQUIRED: {
			T_USRREQSER_BLOCK_SEARCH_DATA searchResultData;
			searchResultData = PerformDetailedBlockSearch(userMessageRequest.hQueue, fileBlockTransaction.fileId,
					userMessageRequest.startTime, findFileResult);
			switch (searchResultData.compareResult) {
			case USRREQSER_CMP_EQUAL_TO:
				//need to test for the end of a recycling queue.
				//GetPosOfPreviousAvailableBlock can't handle recycling properly, so first get a position
				//based on itemToCheck
				T_QMC_FILE_BLOCK_TRANSACTION TmpTrans;
				TmpTrans.blockId = searchResultData.itemToCheck;
				TmpTrans.fileId = fileBlockTransaction.fileId;
				if (USRREQSER_END_OF_AVAILABLE_DATA != GetPosOfPreviousAvailableBlock(TmpTrans)) {
					fileBlockTransaction.blockId = searchResultData.itemToCheck - 1;
					if (USRREQSER_END_OF_AVAILABLE_DATA == GetPosOfPreviousAvailableBlock(fileBlockTransaction)) {
						fileBlockTransaction.blockId = QMC_ZERO;
						fileBlockTransaction.numOfBlocksLastRequested = QMC_ZERO;
						fileRequestRequired = FALSE;
						userMessageReply.requestReply = USRREQSER_REQUEST_FAILED;
						userMessageReply.requestReplyAdditionalInfo = USRREQSER_REPLY_NO_PREVIOUS_BLOCK;
					} // End of IF
				} else {
					fileBlockTransaction.blockId = QMC_ZERO;
					fileBlockTransaction.numOfBlocksLastRequested = QMC_ZERO;
					fileRequestRequired = FALSE;
					userMessageReply.requestReply = USRREQSER_REQUEST_FAILED;
					userMessageReply.requestReplyAdditionalInfo = USRREQSER_REPLY_NO_PREVIOUS_BLOCK;
				}
				break;
			case USRREQSER_CMP_LESS_THAN:
				fileBlockTransaction.blockId = searchResultData.itemToCheck;
				break;
			case USRREQSER_CMP_GREATER_THAN: {
				T_QMC_FILE_BLOCK_TRANSACTION TmpTrans;
				TmpTrans.blockId = searchResultData.itemToCheck;
				TmpTrans.fileId = fileBlockTransaction.fileId;
				fileBlockTransaction.blockId = searchResultData.itemToCheck - 1;
				if (USRREQSER_END_OF_AVAILABLE_DATA == GetPosOfPreviousAvailableBlock(TmpTrans)
						|| USRREQSER_END_OF_AVAILABLE_DATA == GetPosOfPreviousAvailableBlock(fileBlockTransaction)) {
					fileBlockTransaction.blockId = searchResultData.itemToCheck;
				}
			}
				break;
			default:
				break;
			} // End of SWITCH
			USHORT numOfAvailableBlocks = GetNumOfAvailableBlocks(fileBlockTransaction, USRREQSER_DIR_PREVIOUS);
			fileBlockTransaction.numOfBlocksLastRequested = AdjustBlockReqToBlocksAvail(numOfAvailableBlocks,
					userMessageRequest.numOfBlocks);
			//change the transaction point at the start of the retrieval segment
			fileBlockTransaction.blockId -= (fileBlockTransaction.numOfBlocksLastRequested - 1);
		}
			break;
			//time point we're looking for is out of the range of the queue (newer)
		case USER_TIME_GREATER_THAN_LAST_BLOCK:
		case USER_TIME_GREATER_THAN_LAST_BLOCK_TAIL: {
			fileBlockTransaction.blockId = m_DataFileAccess.GetNewestBlockNumber(fileBlockTransaction.fileId);
			USHORT numOfAvailableBlocks = GetNumOfAvailableBlocks(fileBlockTransaction, USRREQSER_DIR_PREVIOUS);
			fileBlockTransaction.numOfBlocksLastRequested = AdjustBlockReqToBlocksAvail(numOfAvailableBlocks,
					userMessageRequest.numOfBlocks);
			//change the transaction point at the start of the retrieval segment
			fileBlockTransaction.blockId -= (fileBlockTransaction.numOfBlocksLastRequested - 1);
		}
			break;
			//time point we're looking for is out of the range of the queue (older)
		case USER_TIME_LESS_THAN_FIRST_BLOCK: {
			T_QMC_FILE_BLOCK_TRANSACTION TmpTrans;
			TmpTrans.blockId = findFileResult.firstBlockId;
			TmpTrans.fileId = findFileResult.fileId;
			fileBlockTransaction.fileId = findFileResult.fileId;
			fileBlockTransaction.blockId = findFileResult.firstBlockId - 1;
			if (USRREQSER_END_OF_AVAILABLE_DATA == GetPosOfPreviousAvailableBlock(TmpTrans)
					|| USRREQSER_END_OF_AVAILABLE_DATA == GetPosOfPreviousAvailableBlock(fileBlockTransaction)) {
				fileBlockTransaction.blockId = m_DataFileAccess.GetOldestBlockNumber(fileBlockTransaction.fileId);
			} // End of IF
			USHORT numOfAvailableBlocks = GetNumOfAvailableBlocks(fileBlockTransaction, USRREQSER_DIR_PREVIOUS);
			fileBlockTransaction.numOfBlocksLastRequested = AdjustBlockReqToBlocksAvail(numOfAvailableBlocks,
					userMessageRequest.numOfBlocks);
			//change the transaction point at the start of the retrieval segment
			fileBlockTransaction.blockId -= (fileBlockTransaction.numOfBlocksLastRequested - 1);
		}
			break;
			//less than the earliest (and recycling)
		case USER_TIME_LESS_THAN_FIRST_BLOCK_HEAD: {
			fileBlockTransaction.fileId = findFileResult.fileId;
			fileBlockTransaction.blockId = findFileResult.firstBlockId;
			fileBlockTransaction.numOfBlocksLastRequested = 1;
		}
			break;
		default: /* @todo Handle Error */
			break;
		} // End of SWITCH
		if (TRUE == fileRequestRequired
				&& TRUE
						== PerformFileRequest(fileBlockTransaction.fileId, fileBlockTransaction.blockId,
								fileBlockTransaction.numOfBlocksLastRequested, userMessageRequest.pDataBuffer,
								userMessageReply)) {
			if (USRREQSER_OK == CheckForPreviousBlockAvailablity(fileBlockTransaction)) {
				userMessageReply.requestReplyAdditionalInfo = USRREQSER_REPLY_BLOCKS_AVAILABLE;
			} else {
				userMessageReply.requestReplyAdditionalInfo = USRREQSER_REPLY_NO_BLOCKS_AVAILABLE;
			} // End of IF
			userMessageRequest.pFileBlockTransaction->fileId = fileBlockTransaction.fileId;
			userMessageRequest.pFileBlockTransaction->blockId = fileBlockTransaction.blockId;
		} // End of IF
	} else {
		// NO FILES AVAILABLE
		userMessageReply.requestReply = USRREQSER_REQUEST_FAILED;
		userMessageReply.requestReplyAdditionalInfo = USRREQSER_REPLY_NO_FILES_AVAILABLE;
	} // End of IF
	userMessageRequest.pFileBlockTransaction->blockId += (fileBlockTransaction.numOfBlocksLastRequested - 1);
	userMessageReply.numOfBlocksObtained = fileBlockTransaction.numOfBlocksLastRequested;
	userMessageRequest.pFileBlockTransaction->numOfBlocksLastRequested =
			-(fileBlockTransaction.numOfBlocksLastRequested);
} // End of Member Function	
//****************************************************************************
///
/// ProcessCompleteTransactionRequest - update a transaction point after a transaction
///
/// @param[in] 	userMessageRequest - contains the transaction point to update
///
/// @return - n/a
///
//****************************************************************************			
void CQMUserRequestServices::ProcessCompleteTransactionRequest(
		const T_USRREQSER_USER_MESSAGE_REQUEST &userMessageRequest) {
	userMessageRequest.pFileBlockTransaction->blockId +=
			userMessageRequest.pFileBlockTransaction->numOfBlocksLastRequested;
	userMessageRequest.pFileBlockTransaction->numOfBlocksLastRequested = QMC_ZERO;
} // End of Member Function 
//****************************************************************************
///
/// ProcessResetToOldestAvailableRequest - resets a transaction point for a 
///						queue to where the oldest available data is
///
/// @param[in,out] userMessageRequest - contains transaction point and Queue to reset
///
/// @return -n/a
///
//****************************************************************************	
void CQMUserRequestServices::ProcessResetToOldestAvailableRequest(
		const T_USRREQSER_USER_MESSAGE_REQUEST &userMessageRequest) {
	// Determine whether the Queue has any associated Files
	if (QMPDFQ_STATUS_EMPTY != m_PersistedDataFileQ.GetQueueStatus(userMessageRequest.hQueue)) {
		const T_QMC_DATAFILE_HEADER *const m_pHeadFile = m_PersistedDataFileQ.GetHeadFile(userMessageRequest.hQueue);
		if (NULL != m_pHeadFile) {
			userMessageRequest.pFileBlockTransaction->fileId = m_pHeadFile->fileId;
			userMessageRequest.pFileBlockTransaction->blockId = m_pHeadFile->oldestBlockNumber;
			userMessageRequest.pFileBlockTransaction->numOfBlocksLastRequested = QMC_ZERO;
		} // End of IF
	} else {
		userMessageRequest.pFileBlockTransaction->fileId = QMC_INVALID_FILE_NUMBER;
		userMessageRequest.pFileBlockTransaction->blockId = QMC_INVALID_BLOCK_NUMBER;
		userMessageRequest.pFileBlockTransaction->numOfBlocksLastRequested = QMC_ZERO;
	} // End of IF
} // End of Member Function 
//****************************************************************************
///
/// ProcessNextBlocksFromStartTimeRequest - get blocks forward from a specified time
///
/// @param[in,out] userMessageRequest - request details including start time
/// @param[in,out] userMessageReply - reply details
///
/// @return - n/a all results in arguments
///
//****************************************************************************	
void CQMUserRequestServices::ProcessNextBlocksFromStartTimeRequest(
		const T_USRREQSER_USER_MESSAGE_REQUEST &userMessageRequest, T_USRREQSER_USER_MESSAGE_REPLY &userMessageReply) {
	T_QMC_FILE_BLOCK_TRANSACTION fileBlockTransaction;
	// Determine whether the Queue has any associated Files
	if (QMPDFQ_STATUS_EMPTY != m_PersistedDataFileQ.GetQueueStatus(userMessageRequest.hQueue)) {
		T_USRREQSER_FIND_FILE_CTN_BLOCK_RESULT findFileResult = indexOfFileSearchAlgorthim(userMessageRequest.hQueue,
				userMessageRequest.startTime);
		fileBlockTransaction.fileId = findFileResult.fileId;
		// Step 1: indexOf the File Containing the Starting Block
		switch (findFileResult.compareResult) {
		case DETAILED_BLOCK_SEARCH_REQUIRED: {
			T_USRREQSER_BLOCK_SEARCH_DATA searchResultData;
			searchResultData = PerformDetailedBlockSearch(userMessageRequest.hQueue, fileBlockTransaction.fileId,
					userMessageRequest.startTime, findFileResult);
			switch (searchResultData.compareResult) {
			case USRREQSER_CMP_EQUAL_TO:
			case USRREQSER_CMP_LESS_THAN:
				fileBlockTransaction.blockId = searchResultData.itemToCheck;
				break;
			case USRREQSER_CMP_GREATER_THAN: {
				T_QMC_FILE_BLOCK_TRANSACTION TmpTrans;
				TmpTrans.blockId = searchResultData.itemToCheck;
				TmpTrans.fileId = fileBlockTransaction.fileId;
				fileBlockTransaction.blockId = searchResultData.itemToCheck - 1;
				if (USRREQSER_END_OF_AVAILABLE_DATA == GetPosOfPreviousAvailableBlock(TmpTrans)
						|| USRREQSER_END_OF_AVAILABLE_DATA == GetPosOfPreviousAvailableBlock(fileBlockTransaction)) {
					fileBlockTransaction.blockId = searchResultData.itemToCheck;
				} // End of IF
			}
				break;
			default:
				break;
			} // End of SWITCH
			USHORT numOfAvailableBlocks = GetNumOfAvailableBlocks(fileBlockTransaction, USRREQSER_DIR_NEXT);
			fileBlockTransaction.numOfBlocksLastRequested = AdjustBlockReqToBlocksAvail(numOfAvailableBlocks,
					userMessageRequest.numOfBlocks);
		}
			break;
		case USER_TIME_GREATER_THAN_LAST_BLOCK:
		case USER_TIME_GREATER_THAN_LAST_BLOCK_TAIL:
			// after the latest (and recycling)
		{
			fileBlockTransaction.blockId = m_DataFileAccess.GetNewestBlockNumber(fileBlockTransaction.fileId);
			fileBlockTransaction.numOfBlocksLastRequested = 1;
		}
			break;
		case USER_TIME_LESS_THAN_FIRST_BLOCK: {
			T_QMC_FILE_BLOCK_TRANSACTION TmpTrans;
			TmpTrans.blockId = findFileResult.fileId;
			TmpTrans.fileId = findFileResult.firstBlockId;
			fileBlockTransaction.fileId = findFileResult.fileId;
			fileBlockTransaction.blockId = findFileResult.firstBlockId - 1;
			if (USRREQSER_END_OF_AVAILABLE_DATA == GetPosOfPreviousAvailableBlock(TmpTrans)
					|| USRREQSER_END_OF_AVAILABLE_DATA == GetPosOfPreviousAvailableBlock(fileBlockTransaction)) {
				fileBlockTransaction.blockId = m_DataFileAccess.GetOldestBlockNumber(fileBlockTransaction.fileId);
			} // End of IF
			// fileBlockTransaction.numOfBlocksLastRequested = 1;
			// (JLP) I think this case requires the following instead :
			USHORT numOfAvailableBlocks = GetNumOfAvailableBlocks(fileBlockTransaction, USRREQSER_DIR_NEXT);
			fileBlockTransaction.numOfBlocksLastRequested = AdjustBlockReqToBlocksAvail(numOfAvailableBlocks,
					userMessageRequest.numOfBlocks);
		}
			break;
		case USER_TIME_LESS_THAN_FIRST_BLOCK_HEAD: // less than the earliest (and recycling)
		{
			fileBlockTransaction.fileId = findFileResult.fileId;
			fileBlockTransaction.blockId = findFileResult.firstBlockId;
			USHORT numOfAvailableBlocks = GetNumOfAvailableBlocks(fileBlockTransaction, USRREQSER_DIR_NEXT);
			fileBlockTransaction.numOfBlocksLastRequested = AdjustBlockReqToBlocksAvail(numOfAvailableBlocks,
					userMessageRequest.numOfBlocks);
		}
			break;
		default: /* @todo Handle Error */
			break;
		} // End of SWITCH
		if ( TRUE
				== PerformFileRequest(fileBlockTransaction.fileId, fileBlockTransaction.blockId,
						fileBlockTransaction.numOfBlocksLastRequested, userMessageRequest.pDataBuffer,
						userMessageReply)) {
			if (USRREQSER_OK == CheckForNextBlockAvailablity(fileBlockTransaction)) {
				userMessageReply.requestReplyAdditionalInfo = USRREQSER_REPLY_BLOCKS_AVAILABLE;
			} else {
				userMessageReply.requestReplyAdditionalInfo = USRREQSER_REPLY_NO_BLOCKS_AVAILABLE;
			} // End of IF
			userMessageRequest.pFileBlockTransaction->fileId = fileBlockTransaction.fileId;
			userMessageRequest.pFileBlockTransaction->blockId = fileBlockTransaction.blockId;
			userMessageRequest.pFileBlockTransaction->numOfBlocksLastRequested =
					fileBlockTransaction.numOfBlocksLastRequested;
		} else {
			userMessageRequest.pFileBlockTransaction->numOfBlocksLastRequested = QMC_ZERO;
		} // End of IF
		userMessageReply.numOfBlocksObtained = fileBlockTransaction.numOfBlocksLastRequested;
	} else {
		// NO FILES AVAILABLE
		userMessageReply.requestReply = USRREQSER_REQUEST_FAILED;
		userMessageReply.requestReplyAdditionalInfo = USRREQSER_REPLY_NO_FILES_AVAILABLE;
	} // End of IF
} // End of Member Function
//****************************************************************************
///
/// PerformDetailedBlockSearch - find a specific time point within a file after
///  indexOfFileSearchComparsion returns detailed_search_required
///
/// @param[in] hQueue - Queue ID
/// @param[in] fileId - File to search
/// @param[in] userStartTime - time to search for
/// @param[in] findFileResult - result from indexOfFileSearchAlgorthim
///
/// @return - searchResultData - structure filled with search data
///
//****************************************************************************
T_USRREQSER_BLOCK_SEARCH_DATA CQMUserRequestServices::PerformDetailedBlockSearch(const USHORT hQueue,
		const USHORT fileId, const LONGLONG userStartTime,
		const T_USRREQSER_FIND_FILE_CTN_BLOCK_RESULT findFileResult) {
	T_USRREQSER_BLOCK_SEARCH_DATA searchResultData;
	LONGLONG blockStartTime = QMC_ZERO;
	searchResultData.itemToCheck = QMC_ZERO;
	searchResultData.startItem = findFileResult.firstBlockId;
	searchResultData.endItem = findFileResult.lastBlockId;
	searchResultData.searchComplete = FALSE;
	searchResultData.compareResult = USRREQSER_CMP_EQUAL_TO;
	OpenBlockFile(fileId);
	while ( FALSE == searchResultData.searchComplete) {
		searchResultData.itemToCheck = (searchResultData.startItem + searchResultData.endItem) / 2;
		SeekToFilePosition(searchResultData.itemToCheck);
		ReadBlockHeaderIntoMemory(hQueue);
		blockStartTime = GetBlockStartTime(hQueue);
		if (blockStartTime == userStartTime) {
			searchResultData.compareResult = USRREQSER_CMP_EQUAL_TO;
			searchResultData.searchComplete = TRUE;
		} else if (blockStartTime > userStartTime) {
			searchResultData.endItem = searchResultData.itemToCheck;
			if (searchResultData.endItem == searchResultData.startItem) {
				searchResultData.compareResult = USRREQSER_CMP_GREATER_THAN;
				searchResultData.searchComplete = TRUE;
			} else {
				// CR3120 - Added guard condition to come out of while loop, when searchResultData.startItem > searchResultData.endItem
				if (searchResultData.startItem > searchResultData.endItem) {
					searchResultData.endItem = searchResultData.startItem;
					searchResultData.compareResult = USRREQSER_CMP_GREATER_THAN;
					searchResultData.searchComplete = TRUE;
					LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR,
							"Perform Detail Block search:: searchResultData.startItem > searchResultData.endItem ");
				}
			} // End of IF
		} else {
			searchResultData.startItem = searchResultData.itemToCheck + QMC_ONE_BLOCK;
			if (searchResultData.startItem > searchResultData.endItem) {
				searchResultData.compareResult = USRREQSER_CMP_LESS_THAN;
				searchResultData.searchComplete = TRUE;
			} // End of IF
		} // End of IF
	} // End of WHILE
	m_BlockFile.Close();
	return (searchResultData);
} // End of Member Function
//****************************************************************************
///
/// indexOfBlockFileComparsion - check the supplied time is within the given range
///
/// @param[in] userStartTime - time point to check
/// @param[in] firstBlockStartTime - lower range
/// @param[in] lastBlockStartTime - upper range
///
/// @return - DETAILED_BLOCK_SEARCH_REQUIRED - block is in this file.
/// - USER_TIME_GREATER_THAN_LAST_BLOCK
/// - USER_TIME_LESS_THAN_FIRST_BLOCK
///
//****************************************************************************
T_USRREQSER_FIND_FILE_COMPARE_RESULT indexOfBlockFileComparsion(const LONGLONG userStartTime,
		const LONGLONG firstBlockStartTime, const LONGLONG lastBlockStartTime) {
	T_USRREQSER_FIND_FILE_COMPARE_RESULT compareResult = DETAILED_BLOCK_SEARCH_REQUIRED;
	if (userStartTime >= firstBlockStartTime && userStartTime <= lastBlockStartTime) {
		compareResult = DETAILED_BLOCK_SEARCH_REQUIRED;
	} else if (userStartTime > lastBlockStartTime) {
		compareResult = USER_TIME_GREATER_THAN_LAST_BLOCK;
	} else {
		// User Time is less than First Block Start Time
		compareResult = USER_TIME_LESS_THAN_FIRST_BLOCK;
	} // End of IF
	return (compareResult);
} // End of Member Function
//****************************************************************************
///
/// indexOfFileSearchAlgorthim - binary chop to find location of file containing
///  specified search time
///
/// @param[in] hQueue - Queue ID
/// @param[in] userStartTime - time point to search for
///
/// @return - findFileResult T_USRREQSER_FIND_FILE_CTN_BLOCK_RESULT structure
///
//****************************************************************************
T_USRREQSER_FIND_FILE_CTN_BLOCK_RESULT CQMUserRequestServices::indexOfFileSearchAlgorthim(const USHORT hQueue,
		const LONGLONG userStartTime) {
	//default search direction
	T_USRREQSER_DIRECTION searchDirection = USRREQSER_DIR_PREVIOUS;
	T_USRREQSER_FIND_FILE_CTN_BLOCK_RESULT findFileResult;
	//set to oldest
	T_USRREQSER_FILE_SECTION fileSection = USRREQSER_SECTION_OLDEST;
	//zero search factors
	LONGLONG firstBlockStartTime = QMC_ZERO;
	LONGLONG lastBlockStartTime = QMC_ZERO;
	SHORT fileIdToCheck = QMC_ZERO;
	//determine number of files in given queue
	USHORT numOfFilesInQueue = m_PersistedDataFileQ.GetNumOfFilesInQueue(hQueue);
	T_USRREQSER_FILE_SEARCH_DATA findFileSearchData;
	//zero the search data
	findFileSearchData.startItem = QMC_ZERO;
	findFileSearchData.endItem = numOfFilesInQueue - 1; //zerobased
	findFileSearchData.itemToCheck = findFileSearchData.startItem;
	findFileSearchData.searchComplete = FALSE;
	findFileSearchData.compareResult = DETAILED_BLOCK_SEARCH_REQUIRED;
	//find first element to check as a file ID
	fileIdToCheck = GetFileIdFromQueuePos(hQueue, findFileSearchData.itemToCheck);
	// Handle the first file
	if (QMC_DATAFILE_MODE_RECYCLING == m_DataFileAccess.GetFileMode(fileIdToCheck)) {
		//check the individual segments, oldest first
		ObtainFirstAndLastBlockStartTime(hQueue, fileIdToCheck, USRREQSER_SECTION_OLDEST, findFileResult.firstBlockId,
				findFileResult.lastBlockId, firstBlockStartTime, lastBlockStartTime);
		findFileSearchData.compareResult = indexOfBlockFileComparsion(userStartTime, firstBlockStartTime,
				lastBlockStartTime);
		if (DETAILED_BLOCK_SEARCH_REQUIRED == findFileSearchData.compareResult
				|| USER_TIME_LESS_THAN_FIRST_BLOCK == findFileSearchData.compareResult) {
			findFileSearchData.searchComplete = TRUE;
			findFileResult.fileSection = USRREQSER_SECTION_OLDEST;
			if (USER_TIME_LESS_THAN_FIRST_BLOCK == findFileSearchData.compareResult)
				findFileSearchData.compareResult = USER_TIME_LESS_THAN_FIRST_BLOCK_HEAD; // because we are recycling
		} else {
			//try the newest section
			ObtainFirstAndLastBlockStartTime(hQueue, fileIdToCheck, USRREQSER_SECTION_NEWEST,
					findFileResult.firstBlockId, findFileResult.lastBlockId, firstBlockStartTime, lastBlockStartTime);
			findFileSearchData.compareResult = indexOfBlockFileComparsion(userStartTime, firstBlockStartTime,
					lastBlockStartTime);
			if (DETAILED_BLOCK_SEARCH_REQUIRED == findFileSearchData.compareResult
					|| USER_TIME_GREATER_THAN_LAST_BLOCK == findFileSearchData.compareResult) {
				findFileSearchData.searchComplete = TRUE;
				findFileResult.fileSection = USRREQSER_SECTION_NEWEST;
				if (USER_TIME_GREATER_THAN_LAST_BLOCK == findFileSearchData.compareResult)
					findFileSearchData.compareResult = USER_TIME_GREATER_THAN_LAST_BLOCK_TAIL; // because we are recycling
			}
		} // End of IF
	} // End of IF
	//if that didn't find it, scan the rest
	if ( FALSE == findFileSearchData.searchComplete) {
		//initial chop
		findFileSearchData.itemToCheck = findFileSearchData.startItem + findFileSearchData.endItem / 2;
		fileIdToCheck = GetFileIdFromQueuePos(hQueue, findFileSearchData.itemToCheck);
		ObtainFirstAndLastBlockStartTime(hQueue, fileIdToCheck, USRREQSER_SECTION_NEWEST, findFileResult.firstBlockId,
				findFileResult.lastBlockId, firstBlockStartTime, lastBlockStartTime);
		indexOfFileSearchComparsion(userStartTime, firstBlockStartTime, lastBlockStartTime, findFileSearchData);
		if (USER_TIME_GREATER_THAN_LAST_BLOCK == findFileSearchData.compareResult) {
			findFileResult.fileSection = USRREQSER_SECTION_NEWEST;
		} else if (USER_TIME_LESS_THAN_FIRST_BLOCK == findFileSearchData.compareResult) {
			findFileResult.fileSection = USRREQSER_SECTION_OLDEST;
		} // End of IF
	} // End of IF
	USHORT LastItem;
	SHORT JumpOfset;
	while ( FALSE == findFileSearchData.searchComplete) {
		LastItem = findFileSearchData.itemToCheck;
		findFileSearchData.itemToCheck = (findFileSearchData.startItem + findFileSearchData.endItem) / 2;
		JumpOfset = findFileSearchData.itemToCheck - LastItem;
		//final check that the jump ofset is legal... todo remove check when happy
		if (((LastItem + JumpOfset) < numOfFilesInQueue) && (LastItem + JumpOfset) >= 0) {
			//use relative search
			fileIdToCheck = GetFileIdFromQueuePos(hQueue, JumpOfset, fileIdToCheck);
			ObtainFirstAndLastBlockStartTime(hQueue, fileIdToCheck, findFileResult.fileSection,
					findFileResult.firstBlockId, findFileResult.lastBlockId, firstBlockStartTime, lastBlockStartTime);
			indexOfFileSearchComparsion(userStartTime, firstBlockStartTime, lastBlockStartTime, findFileSearchData);
			if (USER_TIME_GREATER_THAN_LAST_BLOCK == findFileSearchData.compareResult) {
				findFileResult.fileSection = USRREQSER_SECTION_NEWEST;
			} else if (USER_TIME_LESS_THAN_FIRST_BLOCK == findFileSearchData.compareResult) {
				findFileResult.fileSection = USRREQSER_SECTION_OLDEST;
			} // End of IF
		} else {
            V6WarningMessageBox(NULL, "QMUserRequestServices.cpp: Jump Check Failed",
                    "QM User Request Services Error", MB_OK );
		}
	} // End of WHILE
	findFileResult.fileId = fileIdToCheck;
	findFileResult.compareResult = findFileSearchData.compareResult;
	return (findFileResult);
} // End of Member Function
//****************************************************************************
///
/// indexOfFileSearchComparsion - check result from indexOfFileSearchAlgorithm
///
/// @param[in] userStartTime - time point of block search
/// @param[in] firstBlockStartTime - start of time range returned from Search Algorithm
/// @param[in] lastBlockStartTime - end of time range returned from Search Algorithm
/// @param[in,out] findFileSearchData - search result from search algorithm and this func
///
/// @return -n/a
//****************************************************************************
void CQMUserRequestServices::indexOfFileSearchComparsion(const LONGLONG userStartTime,
		const LONGLONG firstBlockStartTime, const LONGLONG lastBlockStartTime,
		T_USRREQSER_FILE_SEARCH_DATA &findFileSearchData) {
	findFileSearchData.compareResult = indexOfBlockFileComparsion(userStartTime, firstBlockStartTime,
			lastBlockStartTime);
	switch (findFileSearchData.compareResult) {
	case DETAILED_BLOCK_SEARCH_REQUIRED:
		findFileSearchData.searchComplete = TRUE;
		break;
	case USER_TIME_GREATER_THAN_LAST_BLOCK:
		findFileSearchData.startItem = findFileSearchData.itemToCheck + QMC_ONE_BLOCK;
		if (findFileSearchData.startItem > findFileSearchData.endItem) {
			// Exit the Loop
			findFileSearchData.searchComplete = TRUE;
		} // End of IF
		break;
	case USER_TIME_LESS_THAN_FIRST_BLOCK:
		findFileSearchData.endItem = findFileSearchData.itemToCheck;
		if (findFileSearchData.endItem == findFileSearchData.startItem) {
			// Exit the Loop
			findFileSearchData.searchComplete = TRUE;
		} // End of IF
		break;
	default:
		break;
	} // End of SWITCH
} // End of Member Function
//****************************************************************************
///
/// GetFileIdFromQueuePos - find the file ID from a given queue location
///
/// @param[in] hQueue - Queue ID
/// @param[in] queuePos - absolute queue index or jump ofset if startFileID
///  present (negative for backward jump
/// @param[in] startFileID - when not QMC_INVALID_FILE_NUMBER, start point for
///  ofset jump
///
/// @return - file ID of queue position
///
//****************************************************************************
USHORT CQMUserRequestServices::GetFileIdFromQueuePos(const USHORT hQueue, const SHORT queuePos,
		const USHORT startFileID) {
	USHORT fileId;
	if (QMC_INVALID_FILE_NUMBER == startFileID)
		fileId = m_DataFileAccess.GetFileId(m_PersistedDataFileQ.GetHeadFile(hQueue)->fileId);
	else
		fileId = startFileID;
	//when startFileID is present, queuePos becomes an ofset to move by
	//(and this test becomes useless in that situation)
	if (queuePos <= m_PersistedDataFileQ.GetNumOfFilesInQueue(hQueue) - 1) {
		if (queuePos >= 0) {
			for (USHORT fileIndex = 0; fileIndex < queuePos; fileIndex++) {
				fileId = m_DataFileAccess.GetNextFile(fileId);
			} // End of FOR
		} else //go backwards
		{
			for (SHORT negIndex = 0; negIndex > queuePos; negIndex--) {
				fileId = m_DataFileAccess.GetPreviousFile(fileId);
			}
		}
	} // End of IF
	return (fileId);
} // End of Member Function
//****************************************************************************
///
/// ObtainFirstAndLastBlockStartTime - find the range of available blocks in a file
///
/// @param[in] hQueue - Queue ID
/// @param[in] fileId - file to check
/// @param[in] fileSection - newest or oldest portion of file
/// @param[out]  firstBlockId - oldest block of section
/// @param[out]  lastBlockId - newest block of section
/// @param[out]  firstBlockStartTime - oldest block time
/// @param[out]  lastBlockStartTime - newest block time
///
/// @return - n/a
//****************************************************************************
void CQMUserRequestServices::ObtainFirstAndLastBlockStartTime(const USHORT hQueue, const USHORT fileId,
		const T_USRREQSER_FILE_SECTION fileSection, USHORT &firstBlockId, USHORT &lastBlockId,
		LONGLONG &firstBlockStartTime, LONGLONG &lastBlockStartTime) {
	firstBlockId = QMC_INVALID_BLOCK_NUMBER;
	lastBlockId = QMC_INVALID_BLOCK_NUMBER;
	if (QMC_DATAFILE_MODE_RECYCLING == m_DataFileAccess.GetFileMode(fileId)) {
		if (USRREQSER_SECTION_NEWEST == fileSection) {
			firstBlockId = QMC_FIRST_BLOCK_IN_FILE;
			lastBlockId = m_DataFileAccess.GetNewestBlockNumber(fileId);
		} else {
			firstBlockId = m_DataFileAccess.GetOldestBlockNumber(fileId);
			// CR3120 - Removed -1, to include lastblock in perform detailed block search.
			lastBlockId = m_DataFileAccess.GetNumOfDataBlocks(fileId);
			USHORT Max = m_MemoryOpDataAccess.GetNumOfDataBlocksPerFile();
			if (lastBlockId > Max)		// CR3120 Modifcation
					{
				//this should only be recovery code for existing data sets which have the num blocks item corrupted
				qDebug(
						"######-1 Too many Blocks reported in File\n -Queue %d, File %d, First Block %d, Last Block %d\n",
						hQueue, fileId, firstBlockId, lastBlockId);
				lastBlockId = Max; // CR3120 Modification
			}
		} // End of IF
	} else {
		firstBlockId = QMC_FIRST_BLOCK_IN_FILE;
		lastBlockId = m_DataFileAccess.GetNewestBlockNumber(fileId);
	} // End of IF
	// Open the Data Block File
	OpenBlockFile(fileId);
	//
	SeekToFilePosition(firstBlockId);
	// Read First Block Header into Memory
	ReadBlockHeaderIntoMemory(hQueue);
	firstBlockStartTime = GetBlockStartTime(hQueue);
	// Seek to the Last Block within the File
	SeekToFilePosition(lastBlockId);
	// Read First Block Header into Memory
	ReadBlockHeaderIntoMemory(hQueue);
	lastBlockStartTime = GetBlockStartTime(hQueue);
	m_BlockFile.Close();
} // End of Member Function
//****************************************************************************
///
/// ProcessNextBlocksRequest - request blocks forward from position
///
/// @param[in,out] userMessageRequest - request details including transaction point
/// @param[in,out] userMessageReply - reply details
/// @param[out]  var3 - Brief Desciption, out param
///
/// @return - n/a details returned in userMessageReply and in buffer within userMessageRequest
///
//****************************************************************************
void CQMUserRequestServices::ProcessNextBlocksRequest(const T_USRREQSER_USER_MESSAGE_REQUEST &userMessageRequest,
		T_USRREQSER_USER_MESSAGE_REPLY &userMessageReply) {
	T_QMC_FILE_BLOCK_TRANSACTION fileBlockTransaction;
	//set local Trans with supplied file and block ID
	fileBlockTransaction.fileId = userMessageRequest.pFileBlockTransaction->fileId;
	fileBlockTransaction.blockId = userMessageRequest.pFileBlockTransaction->blockId;
	fileBlockTransaction.numOfBlocksLastRequested = QMC_ZERO;
	//ensure the supplied ID's are in range
	if ( TRUE == ValidateFileIdAndBlockId(fileBlockTransaction.fileId, fileBlockTransaction.blockId)) {
		T_USRREQSER_AVAILABLE_BLOCK_RESULT availableBlockResult = GetPosOfNextAvailableBlock(fileBlockTransaction);
		if (USRREQSER_END_OF_AVAILABLE_DATA == availableBlockResult) {
			userMessageReply.requestReply = USRREQSER_REQUEST_FAILED;
			userMessageReply.requestReplyAdditionalInfo = USRREQSER_REPLY_NO_BLOCKS_AVAILABLE;
		} else {
			USHORT numOfAvailableBlocks = GetNumOfAvailableBlocks(fileBlockTransaction, USRREQSER_DIR_NEXT);
			fileBlockTransaction.numOfBlocksLastRequested = AdjustBlockReqToBlocksAvail(numOfAvailableBlocks,
					userMessageRequest.numOfBlocks);
			if ( TRUE
					== PerformFileRequest(fileBlockTransaction.fileId, fileBlockTransaction.blockId,
							fileBlockTransaction.numOfBlocksLastRequested, userMessageRequest.pDataBuffer,
							userMessageReply)) {
				if (USRREQSER_OK == CheckForNextBlockAvailablity(fileBlockTransaction)) {
					userMessageReply.requestReplyAdditionalInfo = USRREQSER_REPLY_BLOCKS_AVAILABLE;
				} else {
					userMessageReply.requestReplyAdditionalInfo = USRREQSER_REPLY_NO_BLOCKS_AVAILABLE;
				} // End of IF
				// Check whether the File and Block Id has been updated to indicate the file
				// has changed, if so then update the user File Block Transaction.
				if (USRREQSER_FILE_AND_BLOCK_UPDATED == availableBlockResult) {
					userMessageRequest.pFileBlockTransaction->fileId = fileBlockTransaction.fileId;
					userMessageRequest.pFileBlockTransaction->blockId = fileBlockTransaction.blockId;
				} // End of IF
			} // End of IF
		} // End of IF
	} else {
		userMessageReply.requestReply = USRREQSER_REQUEST_FAILED;
		userMessageReply.requestReplyAdditionalInfo = USRREQSER_REPLY_NEW_REQUEST_REQUIRED;
	} // End of IF
	userMessageRequest.pFileBlockTransaction->numOfBlocksLastRequested = fileBlockTransaction.numOfBlocksLastRequested;
	userMessageReply.numOfBlocksObtained = fileBlockTransaction.numOfBlocksLastRequested;
} // End of Member Function
//****************************************************************************
///
/// GetFirstAvailableBlock - find the oldest block in file
///
/// @param[in]  fileId - file to search in
/// @param[in]  currentBlockPosition - current block location
///
/// @return - first Available Block ID
///
//****************************************************************************
USHORT CQMUserRequestServices::GetFirstAvailableBlock(const USHORT fileId, const USHORT currentBlockPosition) {
	USHORT firstAvailableBlock = QMC_ZERO;
	if (QMC_DATAFILE_MODE_RECYCLING == m_DataFileAccess.GetFileMode(fileId)
			&& currentBlockPosition > m_DataFileAccess.GetNewestBlockNumber(fileId)) {
		firstAvailableBlock = m_DataFileAccess.GetOldestBlockNumber(fileId);
	} else {
		firstAvailableBlock = QMC_ONE_BLOCK;
	} // End of IF
	return (firstAvailableBlock);
} // End of Member Function
//****************************************************************************
///
/// GetLastAvailableBlock - find the newest block in file
///
/// @param[in]  fileId - file to search in
/// @param[in]  currentBlockPosition - current block location
///
/// @return - last Available Block ID
///
//****************************************************************************
USHORT CQMUserRequestServices::GetLastAvailableBlock(const USHORT fileId, const USHORT currentBlockPosition) {
	USHORT lastAvailableBlock = QMC_ZERO;
	if (QMC_DATAFILE_MODE_RECYCLING == m_DataFileAccess.GetFileMode(fileId)
			&& currentBlockPosition > m_DataFileAccess.GetNewestBlockNumber(fileId)) {
		lastAvailableBlock = m_DataFileAccess.GetNumOfDataBlocks(fileId);
		USHORT Max = m_MemoryOpDataAccess.GetNumOfDataBlocksPerFile();
		if (lastAvailableBlock > Max) {
			//this should only be recovery code for existing data sets which have the num blocks item corrupted
			qDebug("######-2 Too many Blocks reported in File\n -file %d, blocks %d\n", fileId, lastAvailableBlock);
			lastAvailableBlock = Max;
		}
	} else {
		lastAvailableBlock = m_DataFileAccess.GetNewestBlockNumber(fileId);
	} // End of IF
	return (lastAvailableBlock);
} // End of Member Function
//****************************************************************************
///
/// GetPosOfNextAvailableBlock - find next block from a given position
///
/// @param[in,out] lastFileBlockTransaction - block to check from
///
/// @return - USRREQSER_DATA_AVAILABLE - data continues from current point
///  USRREQSER_FILE_AND_BLOCK_UPDATED - data in a new file so T point updated
///  USRREQSER_END_OF_AVAILABLE_DATA - end of data reached
///
//****************************************************************************
T_USRREQSER_AVAILABLE_BLOCK_RESULT CQMUserRequestServices::GetPosOfNextAvailableBlock(
		T_QMC_FILE_BLOCK_TRANSACTION &lastFileBlockTransaction) {
	T_USRREQSER_AVAILABLE_BLOCK_RESULT retValue = USRREQSER_END_OF_AVAILABLE_DATA;
	USHORT lastAvailableBlock = GetLastAvailableBlock(lastFileBlockTransaction.fileId,
			lastFileBlockTransaction.blockId);
	USHORT mode = m_DataFileAccess.GetFileMode(lastFileBlockTransaction.fileId);
	USHORT newestId = m_DataFileAccess.GetNewestBlockNumber(lastFileBlockTransaction.fileId);
	//if the file is recycling and the block is the newest, we're at the end
	if ((!(QMC_DATAFILE_MODE_RECYCLING == mode && lastFileBlockTransaction.blockId == newestId))
			|| (QMC_DATAFILE_MODE_RECYCLING == mode && lastFileBlockTransaction.blockId > newestId)) {
		if (lastFileBlockTransaction.blockId > lastAvailableBlock) {
			USHORT nextFileId = m_DataFileAccess.GetNextFile(lastFileBlockTransaction.fileId);
			CQueueManager *pq_manager = CQueueManager::GetHandle();
			if (QMC_INVALID_FILE_NUMBER != nextFileId && (TRUE == pq_manager->ValidateFileId(nextFileId))) {
				lastFileBlockTransaction.fileId = nextFileId;
				lastFileBlockTransaction.blockId = QMC_ONE_BLOCK;
				retValue = USRREQSER_FILE_AND_BLOCK_UPDATED;
			} // End of IF
		} else {
			retValue = USRREQSER_DATA_AVAILABLE;
		} // End of IF
	} else if (QMC_DATAFILE_MODE_RECYCLING == mode && lastFileBlockTransaction.blockId < newestId) {
		retValue = USRREQSER_DATA_AVAILABLE;
	}
	return (retValue);
} // End of Member Function
//****************************************************************************
///
/// GetNumOfAvailableBlocks - determine how many blocks are in in the target
///  file in a given direction form a given point
///
/// @param[in,out] lastFileBlockTransaction - point to search from
/// @param[in,out] direction - search direction, USRREQSER_DIR_NEXT or USRREQSER_DIR_PREV
///
/// @return - number of blocks available
///
//****************************************************************************
USHORT CQMUserRequestServices::GetNumOfAvailableBlocks(const T_QMC_FILE_BLOCK_TRANSACTION &lastFileBlockTransaction,
		const T_USRREQSER_DIRECTION direction) {
	USHORT numOfBlocksAvailable = QMC_ZERO;
	if (USRREQSER_DIR_NEXT == direction) {
		USHORT lastAvailableBlock = GetLastAvailableBlock(lastFileBlockTransaction.fileId,
				lastFileBlockTransaction.blockId);
		// i.e. last block is 10, first is 1, 10 blocks available
		numOfBlocksAvailable = (lastAvailableBlock - lastFileBlockTransaction.blockId) + QMC_ONE_BLOCK;
	} else {
		USHORT firstAvailableBlock = GetFirstAvailableBlock(lastFileBlockTransaction.fileId,
				lastFileBlockTransaction.blockId);
		if (lastFileBlockTransaction.blockId >= firstAvailableBlock)
			numOfBlocksAvailable = (lastFileBlockTransaction.blockId - firstAvailableBlock) + QMC_ONE_BLOCK;
	} // End of IF
	return (numOfBlocksAvailable);
} // End of Member Function
//****************************************************************************
///
/// ProcessGetFirstAvailableRequest - find the oldest block in the specified queue
///
/// @param[in,out] userMessageRequest - request details including Queue ID
/// @param[in,out] userMessageReply - reply details
///
/// @return -n/a results are conatined in userMessageRequest transaction point
/// and userMessageReply
///
//****************************************************************************
void CQMUserRequestServices::ProcessGetFirstAvailableRequest(const T_USRREQSER_USER_MESSAGE_REQUEST &userMessageRequest,
		T_USRREQSER_USER_MESSAGE_REPLY &userMessageReply) {
	T_QMC_FILE_BLOCK_TRANSACTION fileBlockTransaction;
	// Determine whether the Queue has any associated Files
	if (QMPDFQ_STATUS_EMPTY != m_PersistedDataFileQ.GetQueueStatus(userMessageRequest.hQueue)) {
		const T_QMC_DATAFILE_HEADER *const m_pHeadFile = m_PersistedDataFileQ.GetHeadFile(userMessageRequest.hQueue);
		fileBlockTransaction.fileId = m_pHeadFile->fileId;
		fileBlockTransaction.blockId = m_pHeadFile->oldestBlockNumber;
		USHORT numOfAvailableBlocks = GetNumOfAvailableBlocks(fileBlockTransaction, USRREQSER_DIR_NEXT);
		fileBlockTransaction.numOfBlocksLastRequested = AdjustBlockReqToBlocksAvail(numOfAvailableBlocks,
				userMessageRequest.numOfBlocks);
		if ( FALSE
				== PerformFileRequest(fileBlockTransaction.fileId, fileBlockTransaction.blockId,
						fileBlockTransaction.numOfBlocksLastRequested, userMessageRequest.pDataBuffer,
						userMessageReply)) {
			userMessageRequest.pFileBlockTransaction->fileId = QMC_INVALID_FILE_NUMBER;
			userMessageRequest.pFileBlockTransaction->blockId = QMC_INVALID_BLOCK_NUMBER;
			userMessageRequest.pFileBlockTransaction->numOfBlocksLastRequested = QMC_ZERO;
		} else {
			if (USRREQSER_OK == CheckForNextBlockAvailablity(fileBlockTransaction)) {
				userMessageReply.requestReplyAdditionalInfo = USRREQSER_REPLY_BLOCKS_AVAILABLE;
			} else {
				userMessageReply.requestReplyAdditionalInfo = USRREQSER_REPLY_NO_BLOCKS_AVAILABLE;
			} // End of IF
			userMessageRequest.pFileBlockTransaction->fileId = fileBlockTransaction.fileId;
			userMessageRequest.pFileBlockTransaction->blockId = fileBlockTransaction.blockId;
			userMessageRequest.pFileBlockTransaction->numOfBlocksLastRequested =
					fileBlockTransaction.numOfBlocksLastRequested;
			userMessageReply.numOfBlocksObtained = fileBlockTransaction.numOfBlocksLastRequested;
		} // End of IF
	} else {
		// NO FILES AVAILABLE IN QUEUE
		userMessageReply.requestReply = USRREQSER_REQUEST_FAILED;
		userMessageReply.requestReplyAdditionalInfo = USRREQSER_REPLY_NO_FILES_AVAILABLE;
	} // End of IF
} // End of Member Function
//****************************************************************************
///
/// OpenBlockFile - open the member variable blockFile according to file ID
///
/// @param[in] 	 fileId - file ID to open
///
/// @return - TRUE if Successful
///
//****************************************************************************
BOOL CQMUserRequestServices::OpenBlockFile(USHORT fileId) {
	BOOL fileOpened = FALSE;
	// Construct Block FileName to Open
	// Persisted Path and File Name
    QString blockDataFileAndPathName="";
    if ( TRUE == pDALGLB->BuildPath(IDS_INTERNAL_SD, IDS_LOG_DATA, NULL, &blockDataFileAndPathName, MAX_PATH)) {
		if (fileId != QMC_INVALID_FILE_NUMBER) {
			// Construct the File Name and Extension for the associated Data Block File
			CQMDataFileAccess::CompleteDataFilePath(blockDataFileAndPathName, MAX_PATH, fileId);	// Complete Path
			CQMDataFileAccess::CompleteDataFileName(blockDataFileAndPathName, MAX_PATH, fileId);	// Complete Name
			// Open the Active File
			fileOpened = m_BlockFile.Open(blockDataFileAndPathName, QFile::ReadOnly);
		} // End of IF
	}
	return (fileOpened);
} // End of Member Function
//****************************************************************************
///
/// SeekToFilePosition - go to the block position in the previously opened file
///
/// @param[in] 	 fromBlockNumber - start block ID
///
/// @return -n/a
///
//****************************************************************************
void CQMUserRequestServices::SeekToFilePosition(const USHORT fromBlockNumber) {
	m_BlockFile.Seek(fromBlockNumber * QMC_BLOCK_SIZE, 0);
} // End of Member Function
//****************************************************************************
///
/// ReadBlocksIntoBuffer - perform the actual read from disk of a the previously opened file
///
/// @param[in] 	 numOfBlocks - number of blocks to read
/// @param[in,out] pBlockBuffer - receiving buffer
///
/// @return - number of butes read into buffer
///
//****************************************************************************
UINT CQMUserRequestServices::ReadBlocksIntoBuffer(const USHORT numOfBlocks, BYTE *const pBlockBuffer) {
	return m_BlockFile.Read(pBlockBuffer, numOfBlocks * QMC_BLOCK_SIZE);
} // End of Member Function
//****************************************************************************
///
/// CheckForNextBlockAvailablity - determine if following blocks required are available
///
///
/// @param[in,out] startFileBlockTransaction - check between block ID and num requested
///
/// @return - USRREQSER_OK
/// - USRREQSER_NO_BLOCKS_AVAILABLE
//****************************************************************************
T_USRREQSER_RETURN_VALUE CQMUserRequestServices::CheckForNextBlockAvailablity(
		const T_QMC_FILE_BLOCK_TRANSACTION &startFileBlockTransaction) {
	T_USRREQSER_RETURN_VALUE retValue = USRREQSER_OK; // Member Function Return Value
	USHORT nextStartBlockId = startFileBlockTransaction.blockId + startFileBlockTransaction.numOfBlocksLastRequested;
	if (QMC_DATAFILE_MODE_RECYCLING == m_DataFileAccess.GetFileMode(startFileBlockTransaction.fileId)) {
		if (startFileBlockTransaction.blockId
				< m_DataFileAccess.GetOldestBlockNumber(startFileBlockTransaction.fileId)) {
			// --- NEW SECTION of the recycling file --- //
			if (nextStartBlockId > m_DataFileAccess.GetNewestBlockNumber(startFileBlockTransaction.fileId)) {
				// End of the Data File Queue has been reached for new data
				retValue = USRREQSER_END_OF_FILE_REACHED;
			} // End of IF
		} else {
			// --- OLD Section of the recycling file --- //
			USHORT Num = m_DataFileAccess.GetNumOfDataBlocks(startFileBlockTransaction.fileId);
			USHORT Max = m_MemoryOpDataAccess.GetNumOfDataBlocksPerFile();
			if (Num > Max) {
				//this should only be recovery code for existing data sets which have the num blocks item corrupted
				qDebug("######-3 Too many Blocks reported in File\n -file %d Blocks %d\n",
						startFileBlockTransaction.fileId, Num);
				Num = Max;
			}
			if (nextStartBlockId > Num) {
				// End of the File has been recached to check whether there are more files available
				// within this Data File Queue.
				if (QMC_INVALID_FILE_NUMBER == m_DataFileAccess.GetNextFile(startFileBlockTransaction.fileId)) {
					retValue = USRREQSER_NO_BLOCKS_AVAILABLE;
				} // End of IF
			} // End of IF
		} // End of IF
	} else {
		USHORT Num = m_DataFileAccess.GetNumOfDataBlocks(startFileBlockTransaction.fileId);
		USHORT Max = m_MemoryOpDataAccess.GetNumOfDataBlocksPerFile();
		if (Num > Max) {
			//this should only be recovery code for existing data sets which have the num blocks item corrupted
			qDebug("######-4 Too many Blocks reported in File\n -file %d, Blocks %d\n",
					startFileBlockTransaction.fileId, Num);
			Num = Max;
		}
		if (startFileBlockTransaction.blockId + 1 > Num) {
			// End of the File has been recached to check whether there are more files available
			// within this Data File Queue.
			if (QMC_INVALID_FILE_NUMBER == m_DataFileAccess.GetNextFile(startFileBlockTransaction.fileId)) {
				retValue = USRREQSER_NO_BLOCKS_AVAILABLE;
			} // End of IF
		} else {
			if (startFileBlockTransaction.blockId + 1
					> m_DataFileAccess.GetNewestBlockNumber(startFileBlockTransaction.fileId)) {
				// --- File is not Full, but we have reached the current limit available --- //
				retValue = USRREQSER_NO_BLOCKS_AVAILABLE;
			}
		} // End of IF
	} // End of IF
	return (retValue);
} // End of Member Function
//****************************************************************************
///
/// AdjustBlockReqToBlocksAvail - test how many of the requested blocks are
///  actually available in requested direction to end of file
///
/// @param[in] 	numOfBlocksAvailable - pre determined count of available
///  blocks in specified direction
/// @param[in]  numOfBlocksRequested - number of blocks requested
///
/// @return - number of blocks allowed
///
//****************************************************************************
USHORT CQMUserRequestServices::AdjustBlockReqToBlocksAvail(const USHORT numOfBlocksAvailable,
		const USHORT numOfBlocksRequested) {
	USHORT numOfBlocksAllowed = numOfBlocksRequested;
	if (numOfBlocksRequested > QMC_MAX_BLOCKS_ALLOWED_FOR_ONE_REQUEST) {
		numOfBlocksAllowed = QMC_MAX_BLOCKS_ALLOWED_FOR_ONE_REQUEST;
	} // End of IF
	if (numOfBlocksAvailable < numOfBlocksAllowed) {
		numOfBlocksAllowed = numOfBlocksAvailable;
	} // End of IF
	return (numOfBlocksAllowed);
} // End of Member Function
//****************************************************************************
///
/// CheckForPreviousBlockAvailablity - determine if previous blocks in range are available
///
/// @param[in,out] startFileBlockTransaction - check between block ID and num
///  requested previous to that point
///
/// @return - USRREQSER_OK
/// - USRREQSER_NO_BLOCKS_AVAILABLE
///
//****************************************************************************
T_USRREQSER_RETURN_VALUE CQMUserRequestServices::CheckForPreviousBlockAvailablity(
		const T_QMC_FILE_BLOCK_TRANSACTION &startFileBlockTransaction) {
	T_USRREQSER_RETURN_VALUE retValue = USRREQSER_OK; // Member Function Return Value
	USHORT nextStartBlockId;
	if (QMC_ZERO != startFileBlockTransaction.blockId)
		nextStartBlockId = startFileBlockTransaction.blockId - 1;
	else
		nextStartBlockId = QMC_ZERO;
	if (QMC_DATAFILE_MODE_RECYCLING == m_DataFileAccess.GetFileMode(startFileBlockTransaction.fileId)
			&& startFileBlockTransaction.blockId
					> m_DataFileAccess.GetNewestBlockNumber(startFileBlockTransaction.fileId)) {
		// --- OLD Section of the recycling file --- //
		if (nextStartBlockId < m_DataFileAccess.GetOldestBlockNumber(startFileBlockTransaction.fileId)) {
			// Start of the File has been reached no more blocks available
			retValue = USRREQSER_NO_BLOCKS_AVAILABLE;
		} // End of IF
	} else {
		// File is NOT recycling, or in New Section of the Recycled File
		if (QMC_ZERO == nextStartBlockId) {
			// Check for a previous file
			if (QMC_INVALID_FILE_NUMBER == m_DataFileAccess.GetPreviousFile(startFileBlockTransaction.fileId)) {
				retValue = USRREQSER_NO_BLOCKS_AVAILABLE;
			} // End of IF
		} // End of IF
	} // End of IF
	return (retValue);
} // End of Member Function
///
//****************************************************************************
///
/// ProcessGetPrevBlocksFromNewestAvailableRequest - get the most recent blocks
///
/// @param[in,out] userMessageRequest - details of the message request including buffer
/// @param[in,out] userMessageReply - return datails structure
/// @param[out]  var3 - Brief Desciption, out param
///
/// @return n/a
///
//****************************************************************************
void CQMUserRequestServices::ProcessGetPrevBlocksFromNewestAvailableRequest(
		const T_USRREQSER_USER_MESSAGE_REQUEST &userMessageRequest, T_USRREQSER_USER_MESSAGE_REPLY &userMessageReply) {
	T_QMC_FILE_BLOCK_TRANSACTION fileBlockTransaction;
	// Determine whether the Queue has any associated Files
	if (QMPDFQ_STATUS_EMPTY != m_PersistedDataFileQ.GetQueueStatus(userMessageRequest.hQueue)) {
		const T_QMC_DATAFILE_HEADER *const m_pTailFile = m_PersistedDataFileQ.GetTailFile(userMessageRequest.hQueue);
		fileBlockTransaction.fileId = m_pTailFile->fileId;
		fileBlockTransaction.blockId = m_pTailFile->newestBlockNumber;
		USHORT numOfAvailableBlocks = GetNumOfAvailableBlocks(fileBlockTransaction, USRREQSER_DIR_PREVIOUS);
		fileBlockTransaction.numOfBlocksLastRequested = AdjustBlockReqToBlocksAvail(numOfAvailableBlocks,
				userMessageRequest.numOfBlocks);
		if ( FALSE
				== PerformFileRequest(fileBlockTransaction.fileId,
						fileBlockTransaction.blockId - fileBlockTransaction.numOfBlocksLastRequested + QMC_ONE_BLOCK,
						fileBlockTransaction.numOfBlocksLastRequested, userMessageRequest.pDataBuffer,
						userMessageReply)) {
			userMessageRequest.pFileBlockTransaction->fileId = QMC_INVALID_FILE_NUMBER;
			userMessageRequest.pFileBlockTransaction->blockId = QMC_INVALID_BLOCK_NUMBER;
			userMessageRequest.pFileBlockTransaction->numOfBlocksLastRequested = QMC_ZERO;
		} else {
			T_QMC_FILE_BLOCK_TRANSACTION tpAvailTmp;
			tpAvailTmp.blockId = fileBlockTransaction.blockId - fileBlockTransaction.numOfBlocksLastRequested
					+ QMC_ONE_BLOCK;
			tpAvailTmp.fileId = fileBlockTransaction.fileId;
			if (USRREQSER_OK == CheckForPreviousBlockAvailablity(tpAvailTmp)) {
				userMessageReply.requestReplyAdditionalInfo = USRREQSER_REPLY_BLOCKS_AVAILABLE;
			} else {
				userMessageReply.requestReplyAdditionalInfo = USRREQSER_REPLY_NO_BLOCKS_AVAILABLE;
			} // End of IF
			userMessageRequest.pFileBlockTransaction->fileId = fileBlockTransaction.fileId;
			userMessageRequest.pFileBlockTransaction->blockId = fileBlockTransaction.blockId;
			userMessageRequest.pFileBlockTransaction->numOfBlocksLastRequested =
					-(fileBlockTransaction.numOfBlocksLastRequested);
			userMessageReply.numOfBlocksObtained = fileBlockTransaction.numOfBlocksLastRequested;
		} // End of IF
	} else {
		userMessageReply.requestReply = USRREQSER_REQUEST_FAILED;
		userMessageReply.requestReplyAdditionalInfo = USRREQSER_REPLY_NO_FILES_AVAILABLE;
	} // End of IF
} // End of Member Function
//****************************************************************************
///
/// ProcessPreviousBlocksRequest - attempt to find blocks previous to the given point
///
/// @param[in,out] userMessageRequest - details of the message request including buffer
/// @param[in,out] userMessageReply - return datails structure
/// @param[out]  var3 - Brief Desciption, out param
///
/// @return n/a
///
//****************************************************************************
void CQMUserRequestServices::ProcessPreviousBlocksRequest(const T_USRREQSER_USER_MESSAGE_REQUEST &userMessageRequest,
		T_USRREQSER_USER_MESSAGE_REPLY &userMessageReply) {
	T_QMC_FILE_BLOCK_TRANSACTION fileBlockTransaction;
	fileBlockTransaction.fileId = userMessageRequest.pFileBlockTransaction->fileId;
	fileBlockTransaction.blockId = userMessageRequest.pFileBlockTransaction->blockId;
	fileBlockTransaction.numOfBlocksLastRequested = QMC_ZERO;
	if ( TRUE == ValidateFileIdAndBlockId(fileBlockTransaction.fileId, fileBlockTransaction.blockId)) {
		T_USRREQSER_AVAILABLE_BLOCK_RESULT availableBlockResult = GetPosOfPreviousAvailableBlock(fileBlockTransaction);
		if (USRREQSER_END_OF_AVAILABLE_DATA == availableBlockResult) {
			userMessageReply.requestReply = USRREQSER_REQUEST_FAILED;
			userMessageReply.requestReplyAdditionalInfo = USRREQSER_REPLY_NO_BLOCKS_AVAILABLE;
		} else {
			USHORT numOfAvailableBlocks = GetNumOfAvailableBlocks(fileBlockTransaction, USRREQSER_DIR_PREVIOUS);
			fileBlockTransaction.numOfBlocksLastRequested = AdjustBlockReqToBlocksAvail(numOfAvailableBlocks,
					userMessageRequest.numOfBlocks);
			if ( TRUE
					== PerformFileRequest(fileBlockTransaction.fileId,
							fileBlockTransaction.blockId - fileBlockTransaction.numOfBlocksLastRequested
									+ QMC_ONE_BLOCK, fileBlockTransaction.numOfBlocksLastRequested,
							userMessageRequest.pDataBuffer, userMessageReply)) {
				T_QMC_FILE_BLOCK_TRANSACTION tpAvailTmp;
				tpAvailTmp.blockId = fileBlockTransaction.blockId - fileBlockTransaction.numOfBlocksLastRequested
						+ QMC_ONE_BLOCK;
				tpAvailTmp.fileId = fileBlockTransaction.fileId;
				if (USRREQSER_OK == CheckForPreviousBlockAvailablity(tpAvailTmp)) {
					userMessageReply.requestReplyAdditionalInfo = USRREQSER_REPLY_BLOCKS_AVAILABLE;
				} else {
					userMessageReply.requestReplyAdditionalInfo = USRREQSER_REPLY_NO_BLOCKS_AVAILABLE;
				} // End of IF
				// Check whether the File and Block Id has been updated to indicate the file
				// has changed, if so then update the user File Block Transaction.
				if (USRREQSER_FILE_AND_BLOCK_UPDATED == availableBlockResult) {
					userMessageRequest.pFileBlockTransaction->fileId = fileBlockTransaction.fileId;
					userMessageRequest.pFileBlockTransaction->blockId = fileBlockTransaction.blockId;
				} // End of IF
			} // End of IF
		} // End of IF
	} else {
		userMessageReply.requestReply = USRREQSER_REQUEST_FAILED;
		userMessageReply.requestReplyAdditionalInfo = USRREQSER_REPLY_NEW_REQUEST_REQUIRED;
	} // End of IF
	//userMessageRequest.pFileBlockTransaction->blockId += fileBlockTransaction.numOfBlocksLastRequested;
	userMessageRequest.pFileBlockTransaction->blockId = fileBlockTransaction.blockId;
	userMessageRequest.pFileBlockTransaction->fileId = fileBlockTransaction.fileId;
	userMessageRequest.pFileBlockTransaction->numOfBlocksLastRequested =
			-(fileBlockTransaction.numOfBlocksLastRequested);
	userMessageReply.numOfBlocksObtained = fileBlockTransaction.numOfBlocksLastRequested;
} // End of Member Function
//****************************************************************************
///
/// GetPosOfPreviousAvailableBlock - determine if the previous block is
/// immediately prior or in another file.
///
/// @param[in/out] lastFileBlockTransaction - location of known block, also
/// recieves new position
///
/// @return - USRREQSER_END_OF_AVAILABLE_DATA
/// - USRREQSER_DATA_AVAILABLE
///
//****************************************************************************
T_USRREQSER_AVAILABLE_BLOCK_RESULT CQMUserRequestServices::GetPosOfPreviousAvailableBlock(
		T_QMC_FILE_BLOCK_TRANSACTION &lastFileBlockTransaction) {
	T_USRREQSER_AVAILABLE_BLOCK_RESULT retValue = USRREQSER_END_OF_AVAILABLE_DATA;
	USHORT firstAvailableBlock = GetFirstAvailableBlock(lastFileBlockTransaction.fileId,
			lastFileBlockTransaction.blockId);
	if (lastFileBlockTransaction.blockId < firstAvailableBlock) {
		USHORT previousFileId = m_DataFileAccess.GetPreviousFile(lastFileBlockTransaction.fileId);
		CQueueManager *pq_manager = CQueueManager::GetHandle();
		if (QMC_INVALID_FILE_NUMBER != previousFileId && (TRUE == pq_manager->ValidateFileId(previousFileId))) {
			lastFileBlockTransaction.fileId = previousFileId;
			lastFileBlockTransaction.blockId = m_DataFileAccess.GetNumOfDataBlocks(lastFileBlockTransaction.fileId);
			retValue = USRREQSER_DATA_AVAILABLE;
		} // End of IF
	}
	//to handle recycling slightly better
	else if ((lastFileBlockTransaction.blockId == firstAvailableBlock)
			&& (QMC_DATAFILE_MODE_RECYCLING == m_DataFileAccess.GetFileMode(lastFileBlockTransaction.fileId))
			&& (firstAvailableBlock != 1)) {
		//leave RetValue alone
		lastFileBlockTransaction.blockId = m_DataFileAccess.GetNumOfDataBlocks(lastFileBlockTransaction.fileId);
		USHORT Max = m_MemoryOpDataAccess.GetNumOfDataBlocksPerFile();
		if (lastFileBlockTransaction.blockId > Max) {
			//this should only be recovery code for existing data sets which have the num blocks item corrupted
			qDebug("######-5 Too many Blocks reported in File\n -file %d, blocks %d\n", lastFileBlockTransaction.fileId,
					lastFileBlockTransaction.blockId);
			lastFileBlockTransaction.blockId = Max;
		}
	} else {
		retValue = USRREQSER_DATA_AVAILABLE;
	} // End of IF
	return (retValue);
} // End of Member Function
//*****************************************************************************
// Private Member Functions
//*****************************************************************************
//****************************************************************************
/// Read the Block Header into Memory, the block header size to be read is
/// dependant on the Queue Type.
///
/// @param[in] 	  hQueue - Queue Handle
///
/// @return The number of Bytes read into memory
///
//****************************************************************************
USHORT CQMUserRequestServices::ReadBlockHeaderIntoMemory(const USHORT hQueue) {
	USHORT blockHeaderSize = QMC_ZERO;
	switch (m_PersistedBlkQAccess.GetQueueType(hQueue)) {
	case QMC_QUEUE_PEN_LOG:
		blockHeaderSize = CLogRec::GetHeaderSize();
		break;
	case QMC_QUEUE_PEN_SCR_SLOW:
	case QMC_QUEUE_PEN_SCR_MEDIUM:
	case QMC_QUEUE_PEN_SCR_FAST:
		blockHeaderSize = CChartQManager::GetChartQRecHdrSize();
		break;
	case QMC_QUEUE_MESSAGE:
		blockHeaderSize = CMessageListServicesItem::GetMessageHdrSize();
		break;
	default:
		break;
	} // End of SWITCH
	return (static_cast<USHORT>(m_BlockFile.Read(m_pBlockHeader, blockHeaderSize)));
} // End of Member Function
//****************************************************************************
///
/// GetBlockStartTime - return the earliest time in the block queue
///
/// @param[in] 	hQueue - ID of queue to be checked
///
/// @return - Block Time LONGLONG
///
//****************************************************************************
LONGLONG CQMUserRequestServices::GetBlockStartTime(const USHORT hQueue) {
	LONGLONG blockStartTime = QMC_ZERO;
	switch (m_PersistedBlkQAccess.GetQueueType(hQueue)) {
	case QMC_QUEUE_PEN_LOG:
		blockStartTime = CLogRec::GetStartTime(m_pBlockHeader);
		break;
	case QMC_QUEUE_PEN_SCR_SLOW:
	case QMC_QUEUE_PEN_SCR_MEDIUM:
	case QMC_QUEUE_PEN_SCR_FAST:
		blockStartTime = CChartQManager::GetChartQRecTime(m_pBlockHeader);
		break;
	case QMC_QUEUE_MESSAGE:
		blockStartTime = CMessageListServicesItem::GetMessageTime(m_pBlockHeader);
		break;
	default:
		break;
	} // End of SWITCH
	return (blockStartTime);
} // End of Member Function
//****************************************************************************
/// Validate the File Identification and Block Identification Number.
///
/// @param[in] 	fileId - Brief Desciption in param
/// @param[in] blockId - Brief Desciption in out param
///
/// @return TRUE - File Id and Block Id are valid
/// FALSE - File Id and Block Id invalid
///
//****************************************************************************
BOOL CQMUserRequestServices::ValidateFileIdAndBlockId(const USHORT fileId, const USHORT blockId) {
	BOOL fileIdAndBlockIdValid = TRUE; // Member Variable for storing whether the File Id and Block Id are valid
	if (QMC_INVALID_FILE_NUMBER == fileId || QMC_INVALID_BLOCK_NUMBER == blockId) {
		fileIdAndBlockIdValid = FALSE;
	} // End of IF
	return (fileIdAndBlockIdValid);
} // End of Member Function
//****************************************************************************
///
/// PerformFileRequest - request a read of blocks from a particular database file
///
/// @param[in]  fileID - ID of file to read
/// @param[in]  fromBlockId - block number to read from
/// @param[in]  numOfBlocks - count of blocks to read
/// @param[in/out] pBuffer - recieving data buffer
/// @param[in/out] userMessageReply - receiving reply structure
///
/// @return ---Brief Desciption of Return Value---
///
/// @todo --- Add any todo's into the modules ---
///
/// @note --- Delete if not required ---
//****************************************************************************
BOOL CQMUserRequestServices::PerformFileRequest(const USHORT fileId, const USHORT fromBlockId, const USHORT numOfBlocks,
		BYTE *const pBuffer, T_USRREQSER_USER_MESSAGE_REPLY &userMessageReply) {
	BOOL retValue = FALSE;
	if (NULL != pBuffer) {
		if ( TRUE == OpenBlockFile(fileId)) {
			SeekToFilePosition(fromBlockId);
			UINT numRead = ReadBlocksIntoBuffer(numOfBlocks, pBuffer);
			if (numOfBlocks * QMC_BLOCK_SIZE == numRead) {
				userMessageReply.requestReply = USRREQSER_REQUEST_SUCCESSFUL;
				retValue = TRUE;
			} else if (0 == numRead) {
				userMessageReply.requestReply = USRREQSER_REQUEST_FAILED;
				userMessageReply.requestReplyAdditionalInfo = USRREQSER_REPLY_COULD_NOT_OPEN_FILE;
				QString csErr;
				csErr.sprintf("DATABASE FILE READ ERROR: F-%d BR-%d/%d", fileId, numRead, numOfBlocks * QMC_BLOCK_SIZE);
				LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, csErr);
				retValue = FALSE;
			} else {
				userMessageReply.requestReply = USRREQSER_REQUEST_FAILED;
				userMessageReply.requestReplyAdditionalInfo = USRREQSER_REPLY_LESS_DATA_RETURNED;
			}
			m_BlockFile.Close();
		} else {
			QString csErr;
			csErr.sprintf("DATABASE FILE READ OPEN ERROR: F-%d", fileId);
			LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, csErr);
			userMessageReply.requestReply = USRREQSER_REQUEST_FAILED;
			userMessageReply.requestReplyAdditionalInfo = USRREQSER_REPLY_COULD_NOT_OPEN_FILE;
			retValue = FALSE;
		} // End of IF
	} else {
		userMessageReply.requestReply = USRREQSER_REQUEST_FAILED;
		userMessageReply.requestReplyAdditionalInfo = USRREQSER_REPLY_NO_BUFFER_AVAILABLE;
		retValue = FALSE;
	} // End of IF
	return (retValue);
} // End of Member Function
void CQMUserRequestServices::ProcessGetNumBlocksInQueueFromPoint(
		const T_USRREQSER_USER_MESSAGE_REQUEST &userMessageRequest, T_USRREQSER_USER_MESSAGE_REPLY &userMessageReply) {
	ULONG ulRetVal = m_PersistedDataFileQ.GetNumBlocksInFileQueueFromPoint(userMessageRequest.hQueue,
			m_MemoryOpDataAccess.GetNumOfDataBlocksPerFile(), userMessageRequest.pFileBlockTransaction->fileId,
			userMessageRequest.pFileBlockTransaction->blockId);
	if (QMC_FILE_QUEUE_MISMATCH == ulRetVal) {
		userMessageReply.requestReply = USRREQSER_REQUEST_FAILED;
		userMessageReply.requestReplyAdditionalInfo = USRREQSER_REPLY_QUEUE_FILE_MISMATCH;
	} else {
		userMessageReply.requestReply = USRREQSER_REQUEST_SUCCESSFUL;
		*((ULONG*) userMessageRequest.pDataBuffer) = ulRetVal;
	}
}
//****************************************************************************
/// User request version of function to determine if a block of a particular
/// queue is in the to disk queue waiting to be written to disk
///
/// @param[in,out] userMessageRequest - details of the request. only bothered with hQueue
/// @param[in,out] userMessageReply - contains details of the reply
///
/// @return n/a
///
//****************************************************************************
void CQMUserRequestServices::ProcessQObjectInToDiskQ(const T_USRREQSER_USER_MESSAGE_REQUEST &userMessageRequest,
		T_USRREQSER_USER_MESSAGE_REPLY &userMessageReply) {
	//get the head block pointer
	USHORT HeadIndex = m_pToDiskQ->GetHead();
	T_QMC_BLOCK_HEADER *pBlk = NULL;
	if (HeadIndex != QMC_INVALID_BLOCK_NUMBER) {
		pBlk = &((T_QMC_BLOCK_HEADER*) m_pBlockHeader)[HeadIndex];
	}
	USHORT *pCount = (USHORT*) userMessageRequest.pDataBuffer;
	BOOL BlockFound = FALSE;
	//test if we have a pointer to fill with the block count and reset
	if (NULL != pCount) {
		*pCount = 0;
	}
	USHORT nextBlock = 0;
	if (pBlk != NULL) {
		//proceed if the head block is valid
		//setup initial variables
		USHORT MaxCount = m_pToDiskQ->GetNumOfBlocksInQueue();
		USHORT Count = 0;
		nextBlock = pBlk->blockId;
		qDebug("----------------User Req IsObjectInTDQ pointer 0x%X Max count %d-------------\n", *pCount, MaxCount);
		//test 1: search block is valid and count buffer is valid
		//or
		//test 2: has block been found and search block is valid
		//overall catch: the loop doesn't go for longer than the reported length of the queue
		while ((((NULL != pCount) && (nextBlock != QMC_INVALID_BLOCK_NUMBER))
				|| ((!BlockFound) && (nextBlock != QMC_INVALID_BLOCK_NUMBER))) && Count < MaxCount) {
			qDebug("Block %d count %d Queue %d Req Queue %d\n", nextBlock, Count,
					((T_QMC_BLOCK*) m_pBlockHeader)[nextBlock].blockHeader.QueueId, userMessageRequest.hQueue);
			Count++;
			if (((T_QMC_BLOCK*) m_pBlockHeader)[nextBlock].blockHeader.QueueId == userMessageRequest.hQueue) {
				//when the block's queue matches the request, set the found flag and increment buffer as necessary
				BlockFound = TRUE;
				if (pCount)
					*pCount++;
			}
			//get the next block to check
			nextBlock = ((T_QMC_BLOCK*) m_pBlockHeader)[nextBlock].blockHeader.nextBlock;
		}
	}
	if (BlockFound)
		userMessageReply.requestReply = USRREQSER_REQUEST_SUCCESSFUL;
	else {
		userMessageReply.requestReply = USRREQSER_REQUEST_FAILED;
		userMessageReply.requestReplyAdditionalInfo = USRREQSER_REPLY_NO_Q_BLOCKS_IN_TDQ;
	}
}

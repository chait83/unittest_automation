/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Queue Manager
/// @n Filename:	QMDataFileQAccess.h
/// @n Description: Class Declaration File for the class CQMDataFileQAccess
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 4	Stability Project 1.1.1.1	7/2/2011 5:00:02 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 3	Stability Project 1.1.1.0	7/1/2011 4:27:34 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 2	V6 Firmware 1.1		7/22/2005 4:11:16 PM	Alistair Brugsch
//		Added Doxygen Comments
// 1	V6 Firmware 1.0		6/21/2005 3:44:15 PM	Alistair Brugsch 
// $
//
// **************************************************************************
#ifndef _QMDATAFILEQACCESS_H
#define _QMDATAFILEQACCESS_H
#include "QMCommon.h"
/// Enumeration to describe whether the operation of a Member Function has been
/// completed Successfully or a Failure has occurred. 
typedef enum {
	QMDFQA_OK, QMDFQA_ERROR
} T_QMDFQA_RETURN_VALUE;
//**Class*********************************************************************
///
/// @brief Provides access to a specified Data File Queue. 
/// 
/// This class provides Member Functions for Setting and Getting Data File 
/// Queue Header Data. A typical example is the Free File Queue, which maintains 
/// the free files which are available. The class has been made inline for speed
/// and efficiency.	
///
//****************************************************************************
class CQMDataFileQAccess {
public:
	/// Constructor
	CQMDataFileQAccess(T_QMC_DATAFILE_QUEUE &fileQueue);
	/// Destructor
	virtual ~CQMDataFileQAccess(void);
	/// Set the Status of the Queue
	void SetStatus(const USHORT status);
	/// Set the Head File of the Queue
	void SetHead(const USHORT head);
	/// Set the Tail File of the Queue
	void SetTail(const USHORT tail);
	/// Set the Initial Number of Files in Queue
	void SetNumOfFiles(const USHORT numOfBlocks);
	/// Increment the Number of Files within the Queue by One File
	void IncrementNumOfFiles(void);
	/// Decrement the Number of Files within the Queue by One File
	void DecrementNumOfFiles(void);
	/// Get the Status of the Queue
	USHORT GetStatus(void) const;
	/// Get the Head Block Id 
	USHORT GetHead(void) const;
	/// Get the Tail Block ID
	USHORT GetTail(void) const;
	/// Get the Number of Files within the Queue
	USHORT GetNumOfFilesInQueue(void) const;
private: // Member Functions	
private: // Member Variables 
	T_QMC_DATAFILE_QUEUE &m_FileQueue; ///< Reference to the File Queue within Memory
};
// End of Class Declaration
/// Set the Status of the Queue
inline void CQMDataFileQAccess::SetStatus(const USHORT status) {
	m_FileQueue.Status = status;
} // End of Member Function
/// Set the Head Block of the Queue
inline void CQMDataFileQAccess::SetHead(const USHORT head) {
	m_FileQueue.Head = head;
} // End of Member Function
/// Set the Tail Block of the Queue
inline void CQMDataFileQAccess::SetTail(const USHORT tail) {
	m_FileQueue.Tail = tail;
} // End of Member Function
inline void CQMDataFileQAccess::SetNumOfFiles(const USHORT numOfBlocks) {
	m_FileQueue.NumOfFilesInQueue = numOfBlocks;
} // End of Member Function
/// Increment the Number of Files within the Queue by One
inline void CQMDataFileQAccess::IncrementNumOfFiles(void) {
	++m_FileQueue.NumOfFilesInQueue;
} // End of Member Function
/// Decrement the Number of Files within the Queue by One
inline void CQMDataFileQAccess::DecrementNumOfFiles(void) {
	--m_FileQueue.NumOfFilesInQueue;
} // End of Member Function
/// Get the Status of the Queue
inline USHORT CQMDataFileQAccess::GetStatus(void) const {
	return (m_FileQueue.Status);
} // End of Member Function
/// Get the Head Block Id 
inline USHORT CQMDataFileQAccess::GetHead(void) const {
	return (m_FileQueue.Head);
} // End of Member Function
/// Get the Tail Block ID
inline USHORT CQMDataFileQAccess::GetTail(void) const {
	return (m_FileQueue.Tail);
} // End of Member Function
/// Get the Number of Blocks within the Queue
inline USHORT CQMDataFileQAccess::GetNumOfFilesInQueue(void) const {
	return (m_FileQueue.NumOfFilesInQueue);
} // End of Member Function
#endif // _QMDATAFILEQACCESS_H

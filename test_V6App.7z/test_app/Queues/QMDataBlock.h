/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Queue Manager
/// @n Filename:	QMDataBlock.h
/// @n Description: Class Declaration for CQMDataBlock
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 9	Stability Project 1.6.1.1	7/2/2011 5:00:02 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 8	Stability Project 1.6.1.0	7/1/2011 4:27:34 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 7	V6 Firmware 1.6		10/23/2006 7:03:31 PM Jason Parker 
//		Added function to get the block status
// 6	V6 Firmware 1.5		2/8/2006 11:27:36 PM	Jason Parker 
//		allow status to be changed
// $
//
// **************************************************************************
#ifndef _QMDATABLOCK_H
#define _QMDATABLOCK_H
#include "QMCommon.h"
/// Enumeration to describe whether the operation of a Member Function has been
/// completed Successfully or a Failure has occurred. 
typedef enum {
	QMDATABLK_OK, QMDATABLK_ERROR,
} T_QMDATABLK_RETURN_VALUE;
//**Class*********************************************************************
///
/// @brief Provides a user with a Data Block that they can populate with Data
/// 
/// This class encapsulates a Memory Data Block, it provides a pointer to the
/// data block within Memory, and the ability to set the status of the block.
/// The Pointer to the data block is set by the Block Services, this is acheived
/// by allowing the Block Services to be a friend of this class. This has the
/// effect that the user can not set the pointer to the block, only obtain a
/// pointer to the data block. A Pointer is obtained rather than using write and
/// read methods on the Data Block for speed.	
///
//****************************************************************************
class CQMDataBlock {
	// Allow the Block Services to access Private Members of this Class. 
	friend class CQMBlockServices;
public:
	/// Constructor
	CQMDataBlock(void);
	/// Destructor
	virtual ~CQMDataBlock(void);
	/// Get a Pointer to the Data Block
	BYTE* const GetDataBlock(void);
	/// Set the Data Block Status to indicate that it is Complete, ready for disk
	void SetDataBlockComplete(void);
	/// set the Data Block to indicate it's not in use
	void SetDataBlockNotInUse(void);
	/// generally set the Status of the Block
	void SetBlockStatus(T_QMC_BLOCK_STATUS blockStatus);
	T_QMC_BLOCK_STATUS GetBlockStatus();
	/// Returns whether the Data Block is Completed
	const bool GetDataBlockComplete() const {
		return (m_pDataBlock->blockHeader.blockstatus == QMC_BLKSTATUS_COMPLETE);
	}
	/// Sets the block to be associated with a particular Queue type for CRCing
	void SetDataBlockType(T_QMC_QUEUE_TYPE QueueType);
private: // --- Member Functions --- //
	/// Set the Pointer to the Data Block in Memory
	void SetDataBlock(T_QMC_BLOCK *const pDataBlock) {
		m_pDataBlock = pDataBlock;
	}
private: // --- Member Variables --- //	
	T_QMC_BLOCK *m_pDataBlock; ///< Pointer to the Data Block within Memory		
};
// End of Class Declaration
//****************************************************************************
/// Returns a Pointer to a Data Block within Memory 
///
/// @return Pointer to the Memory Data Block
/// 
//****************************************************************************
inline BYTE* const CQMDataBlock::GetDataBlock(void) {
	if (NULL != m_pDataBlock) {
		return (m_pDataBlock->blockData);
	} // End of IF
	return (NULL);
} // End of Member Function
//****************************************************************************
/// Set the Status of the Memory Data Block to COMPLETED
///
/// @return No Return Value
/// 
//****************************************************************************
inline void CQMDataBlock::SetDataBlockComplete(void) {
	if (NULL != m_pDataBlock) {
		m_pDataBlock->blockHeader.blockstatus = static_cast<USHORT>(QMC_BLKSTATUS_COMPLETE);
	} // End of IF
} // End of Member Function 
//****************************************************************************
/// Set the Status of the Memory Data Block to NOT IN USE
///
/// @return No Return Value
/// 
//****************************************************************************
inline void CQMDataBlock::SetDataBlockNotInUse(void) {
	if (NULL != m_pDataBlock) {
		m_pDataBlock->blockHeader.blockstatus = static_cast<USHORT>(QMC_BLKSTATUS_NOT_USED);
	} // End of IF
} // End of Member Function 
//****************************************************************************
/// Set the Type of the Memory Data Block to be associated with a particular Queue type
///
/// @return No Return Value
/// 
//****************************************************************************
inline void CQMDataBlock::SetDataBlockType(T_QMC_QUEUE_TYPE QueueType) {
	if (NULL != m_pDataBlock)
		m_pDataBlock->blockHeader.blockType = (USHORT) QueueType;
}
//////////////////////////////////////////////////////////////////////////////
// Private Member Functions
//////////////////////////////////////////////////////////////////////////////
//****************************************************************************
/// Set the Status of the Memory Data Block, used by the Block Services to
/// set the Initial Memory Data Block Status. 
///
/// @return No Return Value
/// 
//****************************************************************************
inline void CQMDataBlock::SetBlockStatus(T_QMC_BLOCK_STATUS blockStatus) {
	if (NULL != m_pDataBlock) {
		m_pDataBlock->blockHeader.blockstatus = static_cast<USHORT>(blockStatus);
	} // End of IF
} // End of Member Function 
//****************************************************************************
/// Get the Status of the Memory Data Block, 
///
/// @return T_QMC_BLOCK_STATUS
/// 
//****************************************************************************
inline T_QMC_BLOCK_STATUS CQMDataBlock::GetBlockStatus() {
	if (NULL != m_pDataBlock) {
		return (T_QMC_BLOCK_STATUS) m_pDataBlock->blockHeader.blockstatus;
	} // End of IF
	else
		return QMC_BLKSTATUS_NOT_USED;
} // End of Member Function 
#endif // _QMDATABLOCK_H

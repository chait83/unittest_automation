/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Queue Manager
/// @n Filename:	QMBlkQHeaderAccess.h
/// @n Description: Class Declaration File for the class CQMBlkQAccess
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 4	Stability Project 1.1.1.1	7/2/2011 5:00:01 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 3	Stability Project 1.1.1.0	7/1/2011 4:27:34 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 2	V6 Firmware 1.1		7/22/2005 4:11:16 PM	Alistair Brugsch
//		Added Doxygen Comments
// 1	V6 Firmware 1.0		6/21/2005 3:44:15 PM	Alistair Brugsch 
// $
//
// **************************************************************************
#ifndef _QMBLKQHEADERACCESS_H
#define _QMBLKQHEADERACCESS_H
#include "QMCommon.h"
/// Enumeration to describe whether the operation of a Member Function has been
/// completed Successfully or a Failure has occurred. 
typedef enum {
	QMBQHA_OK, QMBQHA_ERROR
} T_QMBQHA_RETURN_VALUE;
//**Class*********************************************************************
///
/// @brief Provides Access to the Specified Block Queue
/// 
/// Provides an set of Inline Member Function setting and reading the specified 
/// Block Queue. 
///
//****************************************************************************
class CQMBlkQAccess {
public:
	/// Constructor
	CQMBlkQAccess(T_QMC_BLOCK_QUEUE &blockQueue);
	/// Destructor
	virtual ~CQMBlkQAccess(void);
	/// Set the Status of the Queue
	void SetStatus(const T_QMC_BLOCK_QUEUE_STATUS status);
	/// Set the Head Block of the Queue
	void SetHead(const USHORT head);
	/// Set the Tail Block of the Queue
	void SetTail(const USHORT tail);
	/// Set the Initial Number of Blocks in Queue
	void SetNumOfBlocks(const USHORT numOfBlocks);
	/// Increment the Number of Blocks within the Queue by One Block
	void IncrementNumOfBlocks(void);
	/// Decrement the Number of Blocks within the Queue by One Block
	void DecrementNumOfBlocks(void);
	/// Increment the Number of Blocks by a specified amount
	void IncrementNumOfBlocks(USHORT numOfBlocks);
	/// Get the Status of the Queue
	T_QMC_BLOCK_QUEUE_STATUS GetStatus(void) const;
	/// Get the Head Block Id 
	USHORT GetHead(void) const;
	/// Get the Tail Block ID
	USHORT GetTail(void) const;
	/// Get the Number of Blocks within the Queue
	USHORT GetNumOfBlocksInQueue(void) const;
	/// Get the Block Queue Header - Debug Purposes only
	T_QMC_BLOCK_QUEUE& GetBlockQueueHeader(void) {
		return m_BlockQueue;
	}
private:
	T_QMC_BLOCK_QUEUE &m_BlockQueue; ///< Reference to the Block Queue within Memory
};
// End of Class Declaration
//****************************************************************************
/// Set the Status of the Queue
///
/// @param[in] 	status - New Status of the Queue
///
/// @return No Return Value
/// 
/// @note Inline Member Function for Speed and Efficiency
///
//****************************************************************************
inline void CQMBlkQAccess::SetStatus(const T_QMC_BLOCK_QUEUE_STATUS status) {
	m_BlockQueue.Status = status;
} // End of Member Function
//****************************************************************************
/// Set the Head Block of the Queue
///
/// @param[in] 	head - Head of the Queue Value 
///
/// @return No Return Value
/// 
/// @note Inline Member Function for Speed and Efficiency
///
//****************************************************************************
inline void CQMBlkQAccess::SetHead(const USHORT head) {
	m_BlockQueue.Head = head;
} // End of Member Function
//****************************************************************************
/// Set the Tail Block of the Queue
///
/// @param[in] 	tail - Tail of the Queue
///
/// @return No Return Value
///
/// @note Inline Member Function for Speed and Efficiency
/// 
//****************************************************************************
inline void CQMBlkQAccess::SetTail(const USHORT tail) {
	m_BlockQueue.Tail = tail;
} // End of Member Function
//****************************************************************************
/// Set the Tail Block of the Queue
///
/// @param[in] 	numOfBlocks - Number of Blocks within the Queue
///
/// @return No Return Value
///
/// @note Inline Member Function for Speed and Efficiency
/// 
//****************************************************************************
inline void CQMBlkQAccess::SetNumOfBlocks(const USHORT numOfBlocks) {
	m_BlockQueue.NumOfBlocksInQueue = numOfBlocks;
} // End of Member Function
//****************************************************************************
/// Increment the Number of Blocks within the Queue by One
///
/// @param[in] - None
///
/// @return No Return Value
///
/// @note Inline Member Function for Speed and Efficiency
/// 
//****************************************************************************
inline void CQMBlkQAccess::IncrementNumOfBlocks(void) {
	++m_BlockQueue.NumOfBlocksInQueue;
} // End of Member Function
//****************************************************************************
/// Decrement the Number of Blocks within the Queue by One
///
/// @param[in] - None
///
/// @return No Return Value
///
/// @note Inline Member Function for Speed and Efficiency
/// 
//****************************************************************************
inline void CQMBlkQAccess::DecrementNumOfBlocks(void) {
	--m_BlockQueue.NumOfBlocksInQueue;
} // End of Member Function
//****************************************************************************
/// Increment the Number of Blocks by a specified amount
///
/// @param[in] numOfBlocks - Number of Blocks to Increment By
///
/// @return No Return Value
///
/// @note Inline Member Function for Speed and Efficiency
/// 
//****************************************************************************
inline void CQMBlkQAccess::IncrementNumOfBlocks(USHORT numOfBlocks) {
	m_BlockQueue.NumOfBlocksInQueue += numOfBlocks;
} // End of Member Function 
//****************************************************************************
/// /// Get the Status of the Queue
///
/// @param[in] - None
///
/// @return Status of the Queue
///
/// @note Inline Member Function for Speed and Efficiency
/// 
//****************************************************************************
inline T_QMC_BLOCK_QUEUE_STATUS CQMBlkQAccess::GetStatus(void) const {
	return (static_cast<T_QMC_BLOCK_QUEUE_STATUS>(m_BlockQueue.Status));
} // End of Member Function
//****************************************************************************
/// Get the Head Block Id 
///
/// @param[in] - None
///
/// @return Head Block Id
///
/// @note Inline Member Function for Speed and Efficiency
/// 
//****************************************************************************
inline USHORT CQMBlkQAccess::GetHead(void) const {
	return (m_BlockQueue.Head);
} // End of Member Function
//****************************************************************************
/// Get the Tail Block Id
///
/// @param[in] - None
///
/// @return Tail Block Id
/// 
/// @note Inline Member Function for Speed and Efficiency
///
//****************************************************************************
inline USHORT CQMBlkQAccess::GetTail(void) const {
	return (m_BlockQueue.Tail);
} // End of Member Function
//****************************************************************************
/// Get the Number of Blocks within the Queue
///
/// @param[in] - None
///
/// @return Number of Blocks within the Queue
/// 
/// @note Inline Member Function for Speed and Efficiency
///
//****************************************************************************
inline USHORT CQMBlkQAccess::GetNumOfBlocksInQueue(void) const {
	return (m_BlockQueue.NumOfBlocksInQueue);
} // End of Member Function
#endif // _QMBLKQHEADERACCESS_H

// QMDiskServicesThread.cpp : implementation file
//
//#include "V6QueueManager.h"
#include "QMDiskServicesThread.h"
#include "QMDiskServices.h"
#include "ThreadInfo.h"
#include "V6globals.h" // For logging diagnostic msgs
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
// CQMDiskServicesThread
// IMPLEMENT_DYNCREATE(CQMDiskServicesThread, QThread)
CQMDiskServicesThread::CQMDiskServicesThread() {
}
CQMDiskServicesThread::~CQMDiskServicesThread() {
}
BOOL CQMDiskServicesThread::InitInstance() {
	// TODO: perform and per-thread initialization here
	return TRUE;
}
int CQMDiskServicesThread::ExitInstance() {
	// TODO: perform any per-thread cleanup here
    exit();
    return 0;
}
// CQMDiskServicesThread message handlers
//****************************************************************************
/// 
///
///
/// @param[in] 	lpParam -
///
/// @return 0x00 - Thread Exit Successful
/// @n	0xFF - Thread could not operate correctly and has terminated
///
//****************************************************************************
UINT CQMDiskServicesThread::ThreadFunc(LPVOID lpParam)
{
	const UINT QMDSKSERTHRD_THREAD_EXIT_SUCCESSFUL = 0x00; // Constant to represent Thread Exit Code Successful
	const UINT QMDSKSERTHRD_THREAD_OPERATIONAL_FAILURE = 0xFF;// Constant to represent Thread Exit Code Successful
	UINT threadExitCode = QMDSKSERTHRD_THREAD_OPERATIONAL_FAILURE;// Thread Exit Code
	// Pointer to the IO Simulator
	CQMDiskServices *pQMDiskServices = static_cast<CQMDiskServices*>( lpParam );
	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//after each iteration
#ifdef UNDER_CE	
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	if(pThreadInfo != NULL)
	{
	//Notify the WatchdogTimer that the DiskServices thread has 
	//started
	pThreadInfo->UpdateThreadInfo(AM_QMDISKSERVICES,true);
	}
 #endif 
#ifdef THREAD_ID_SERIAL_LOG
		WCHAR szDbgMsg[512];
		swprintf( szDbgMsg, L"CQMDiskServicesThread::ThreadFunc-Thread id 0x%x, %lu ", GetThreadId(GetCurrentThread()), GetThreadId(GetCurrentThread()));
		OutputDebugString(szDbgMsg);
	#endif
	if( NULL != pQMDiskServices )
	{
		// Loop until the Thread is told to Exit by the Queue Manager 
		while( QMDSKSER_OPMODE_EXIT != pQMDiskServices->GetOperationalMode() )
		{
			pQMDiskServices->PerformNormalOperation();
			// sleep for the specified time before performing the Next Disk Service Cycle. The sleep
			// is important to ensure the rest of the system is capable of operating, otherwise we would
			// have a thread taking all the processor power. 
			sleep( QMDSKSER_CYCLE_FREQUENCY_IN_MS );
#ifdef UNDER_CE	
			if(pThreadInfo != NULL)
			{
				//Update the Thread Counter for the DiskServices
				//thread after each iteration
				pThreadInfo->UpdateThreadCounter(AM_QMDISKSERVICES);
			}
#endif
		} // End of WHILE 
		threadExitCode = QMDSKSERTHRD_THREAD_EXIT_SUCCESSFUL;
	} // End of IF
	// Ensure all Blocks are written to disk, and User Requests are Processed before closing down the Thread. 
	pQMDiskServices->PerformShutdownSequence();
#ifdef UNDER_CE	
	if(pThreadInfo != NULL)
	{
	//Update the info that the DiskServices thread is exiting
	//Hence this thread need not be considered to kick the 
	//watchdog
	pThreadInfo->UpdateThreadInfo(AM_QMDISKSERVICES,false);
	}
#endif
	//QString  strErr = L"Disk services thread Exiting.......";
	//LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_INFO, strErr);
	return( threadExitCode );
} // End of Member Function

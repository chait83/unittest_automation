/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Queue Manager
/// @n Filename:	QMDiskServices.h
/// @n Description: --- Add File Description ---
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 32	Stability Project 1.29.1.1	7/2/2011 5:00:03 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 31	Stability Project 1.29.1.0	7/1/2011 4:27:35 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 30	V6 Firmware 1.29		9/14/2006 3:55:35 PM	Alistair Brugsch
//		added in functionality to allow clearing of data from chart queues
// 29	V6 Firmware 1.28		5/25/2006 7:35:18 PM	Alistair Brugsch
//		Added wrapper func to query if a queue is recycling or not
// $
//
// **************************************************************************
#ifndef _QMDISKSERVICES_H
#define _QMDISKSERVICES_H
#include "QMBlockServices.h"
#include "QMDiskHandler.h"
#include "QMUserRequestServices.h"
#include "QMFileBlockTransaction.h"
#include "LogDeviceStatus.h"
/// Used to control the frequency the Disk Services operates at, the constants represents the
/// time to wait between performing each disk service cycle.
const USHORT QMDSKSER_CYCLE_FREQUENCY_IN_MS = 25;
/// Enumeration to describe whether the operation of a Member Function has been
/// completed Successfully or a Failure has occurred. 
typedef enum _eQMDskSerReturnValue {
	QMDSKSER_OK, QMDSKSER_INITIALISATION_FAILED, QMDSKSER_REGISTRATION_FAILED, QMDSKSER_ERROR
} T_QMDSKSER_RETURN_VALUE;
/// Enumeration which details the users of the Disk Services. 
typedef enum _eQMDskSerUser {
	QMBLKSER_OPPANEL, QMBLKSER_LOGGING,
	QMBLKSER_NUM_OF_USERS // Always at the End
} T_QMDSKSER_USER;
/// Enumeration to describe the method that a user wishes to use for thread communication
typedef enum {
	QMBLKSER_INTERNAL_MESSAGE_QUEUE, QMBLKSER_POST_THREAD_MESSAGE
} T_QMDSKSER_USER_NOTIFICATION_METHOD;
/// Enumeration to describe whether a User has registered with the Disk Services
typedef enum _eQMDskSerRegisteredStatus {
	QMBLKSER_REGISTERED, QMBLKSER_NOT_REGISTERED
} T_QMDSKSER_REGISTERED_STATUS;
/// Enumeration for the Operational mode of the Disk Services
typedef enum _eQMDskSerOperationalMode {
	QMDSKSER_OPMODE_NORMAL_OPERATION, QMDSKSER_OPMODE_EXIT
} T_QMDSKSER_OPERATIONAL_MODE;
/// Enumeration for the Action the Disk Service needs to perform on each cycle
typedef enum _eQMDskSerActionToPerform {
	QMDSKSER_ACTION_WRITE_BLOCKS_TO_DISK, QMDSKSER_ACTION_PROCESS_USER_REQUESTS
} T_QMDSKSER_ACTION_TO_PERFORM;
/// A Structure that describes information relating a Disk Service Users, this structure contains,
/// information relating to the method of communication to use for thread communication. 
typedef struct _QMDskSerUserInformation {
	T_QMDSKSER_REGISTERED_STATUS registeredStatus; ///< Indicates whether a user has registered 
	T_QMDSKSER_USER_NOTIFICATION_METHOD userNotificationMethod; ///< Method of Communication between the Disk Service and User	
	DWORD threadId;					///< Thread Id of the User( if required )
	CInternalMessageQueue *pInternalMessageQueue;		///< Internal Message Communication for the user( if required )
} T_QMDSKSER_USER_INFO;
//**Class*********************************************************************
///
/// @brief ---Single line description---.
/// 
/// --- Detailed Description ---
///
//****************************************************************************
class CQMDiskServices {
	/// Allow the Block Services to access Private Members
	friend class CQMBlockServices;
public:
	/// Constructor
	CQMDiskServices(CQMBlkQAccess &toDiskBlkQAccess, CQMBlkQAccess &tempStorageBlkQAccess,
			CQMDataBlkAccess &memoryBlockAccess, const CQMMemoryOpDataAccess &memoryOpDataAccess,
			CQMPersistBlkQAccess &persistedBlkQAccess, CQMPersistDataFileQAccess &persistedDataFileQAccess,
			CQMDataFileAccess &dataFileAccess, CQMDataFileQAccess &freeFileQAccess);
	/// Destructor
	virtual ~CQMDiskServices(void);
	/// Initialise the Disk Services from Operation
	T_QMDSKSER_RETURN_VALUE Initialise(CQMBlockServices *pBlockServices);
	/// Allow the User to Register with the Queue Manager Disk Services
	T_QMDSKSER_RETURN_VALUE RegisterWithQMDiskServices(const T_USRREQSER_USER user,
			CInternalMessageQueue *pInternalMessageQueue);
	/// Flush all the Data Blocks within the To Disk Queue to Physical Disk
	T_QMDSKSER_RETURN_VALUE FlushDataBlocksToPhysicalDisk(void);
	//If there are any blocks which are not completely written into SD card during abrupt power
	//cycle then those blocks written from the temporary storage queue
	USHORT CompareAndFlushLostBlocks(void);
	/// Get the Specified number of Blocks from the First Block Available within the Disk Queue
	T_QMDSKSER_RETURN_VALUE GetBlocksFromFirstAvailable(const T_USRREQSER_USER user, const USHORT hQueue,
			const USHORT numOfBlocks, BYTE *const pDataBuffer);
	/// Get the Specified Number of Blocks from a specified Start Time in a Forward Direction	
	T_QMDSKSER_RETURN_VALUE GetNextBlocksFromStartTime(const T_USRREQSER_USER user, const USHORT hQueue,
			const LONGLONG startTime, const USHORT numOfBlocks, BYTE *const pDataBuffer);
	/// Get the Specified Number of Blocks from a specified Start Time in a Backward Direction	
	T_QMDSKSER_RETURN_VALUE GetPrevBlocksFromStartTime(const T_USRREQSER_USER user, const USHORT hQueue,
			const LONGLONG startTime, const USHORT numOfBlocks, BYTE *const pDataBuffer);
	/// Get the Specified Number of Blocks from the Newest Available in a Backward Direction
	T_QMDSKSER_RETURN_VALUE GetPrevBlocksFromNewest(const T_USRREQSER_USER user, const USHORT hQueue,
			const USHORT numOfBlocks, BYTE *const pDataBuffer);
	/// Get the Specified Number of Blocks in a Forward Direction
	T_QMDSKSER_RETURN_VALUE GetNextBlocks(const T_USRREQSER_USER user, const USHORT hQueue, const USHORT numOfBlocks,
			BYTE *const pDataBuffer);
	/// Get the Specified Number of Block in a Backward Direction 
	T_QMDSKSER_RETURN_VALUE GetPreviousBlocks(const T_USRREQSER_USER user, const USHORT hQueue,
			const USHORT numOfBlocks, BYTE *const pDataBuffer);
	// --- MEMBER FUNCTIONS FOR USER PASSING IN POINTER TO FILE BLOCK TRANSACTION --- //			
	/// Reset the Specified Queue Transaction Status to the Oldest Available										
	T_QMDSKSER_RETURN_VALUE ResetToOldestAvailable(const T_USRREQSER_USER user, const USHORT hQueue,
			T_QMC_FILE_BLOCK_TRANSACTION *const pFileBlockTransaction);
	/// Get the Specified Number of Blocks from the First Available													
	T_QMDSKSER_RETURN_VALUE GetBlocksFromFirstAvailable(const T_USRREQSER_USER user, const USHORT hQueue,
			const USHORT numOfBlocks, T_QMC_FILE_BLOCK_TRANSACTION *const pFileBlockTransaction,
			BYTE *const pDataBuffer);
	/// Get the Next Specified Number of Blocks														
	T_QMDSKSER_RETURN_VALUE GetNextBlocks(const T_USRREQSER_USER user, const USHORT hQueue, const USHORT numOfBlocks,
			T_QMC_FILE_BLOCK_TRANSACTION *const pFileBlockTransaction, BYTE *const pDataBuffer);
	/// Complete the Last Transaction												
	T_QMDSKSER_RETURN_VALUE CompleteTransaction(const T_USRREQSER_USER user, const USHORT hQueue,
			T_QMC_FILE_BLOCK_TRANSACTION *const pBlockLocationToUpdate);
	/// Informs the Disk Services that the Last Transaction has been confirmed by the End User, required for logging
	T_QMDSKSER_RETURN_VALUE ConfirmTransaction(const T_USRREQSER_USER user, const USHORT hQueue,
			T_QMC_FILE_BLOCK_TRANSACTION *const pBlockLocationToUpdate,
			T_QMC_FILE_BLOCK_TRANSACTION *const pBlockLocationContainingUpdateData);
	///Returns the number of blocks used by a Queue
	T_QMDSKSER_RETURN_VALUE ReqNumBlocksInFileQueueFromPoint(const T_USRREQSER_USER user, const USHORT hQueue,
			T_QMC_FILE_BLOCK_TRANSACTION *const pTransPoint, BYTE *const pDataBuffer);
	/// Perform Normal Operation ensuring both user requests are processed and block written to disk
	T_QMDSKSER_RETURN_VALUE PerformNormalOperation(void);
	/// Perform Shutdown Sequence ensuring all blocks are written to disk, and user requests processed
	T_QMDSKSER_RETURN_VALUE PerformShutdownSequence(void);
	/// Get the Current Operational Mode of the Disk Services
	T_QMDSKSER_OPERATIONAL_MODE GetOperationalMode(void) {
		return (m_OperationalMode);
	}
	/// Prompt a Graceful Shutdown of theDisk Services - ONLY TO BE CALLED FROM THE QUEUE MANAGER
	void Shutdown(void) {
		m_OperationalMode = QMDSKSER_OPMODE_EXIT;
	}
	///Returns the number of blocks used by a Queue
	ULONG GetNumBlocksInFileQueue(const USHORT hQueue) const {
		return (m_DiskHandler.GetNumBlocksInFileQueue(hQueue));
	}
	///Returns the number of blocks used by a Queue
	ULONG GetNumBlocksInFileQueueFromPoint(const USHORT hQueue, const USHORT FileID, const USHORT BlockID);
	///Returns the number of blocks reserved by a Queue (total blocks taken by the queue files regardless of usage)
	ULONG GetNumBlocksReservedInFileQueue(const USHORT hQueue) const {
		return (m_DiskHandler.GetNumBlocksReservedInFileQueue(hQueue));
	}
	///sets the maximum number of files to be used by a queue before it will recycle
	T_QMPDFQA_RETURN_VALUE SetMaxFiles(const USHORT hQueue, const USHORT NumFiles);
	///Returns the number of blocks used by a Queue
	ULONG GetMaxNumBlocksQueue(const USHORT hQueue) {
		return (m_DiskHandler.GetMaxNumBlocksInQueue(hQueue));
	}
	///Gets the file and blockID of the most recent block in a file queue
	BOOL GetNewestBlockAndFile(const USHORT hQueue, USHORT *pFile, USHORT *pBlock) {
		return (m_DiskHandler.GetNewestBlockAndFile(hQueue, pFile, pBlock));
	}
	///set the threshold for a queue before blocks are moved to the ToDiskQueue
	T_QMPBQA_RETURN_VALUE SetFlushToDiskLimit(const USHORT hQueue, const USHORT flushToDiskLimit) {
		return m_DiskHandler.SetFlushToDiskLimit(hQueue, flushToDiskLimit);
	}
	///Determines if a block of a particular queue is in the to disk queue
	//USE SPARINGLY! the critical section can hold up the operation of storing to disk
	BOOL IsQObjectInToDiskQ(const USHORT hQueue, USHORT *pCount = NULL) {
		return m_DiskHandler.IsQObjectInToDiskQ(hQueue, pCount);
	}
	///returns the number of blocks currently in the ToDiskQueue
	USHORT GetNumBlocksInToDiskQ(void) {
		return m_DiskHandler.GetNumBlocksInToDiskQ();
	}
	///discover the queue ID from a given file ID
	USHORT GetQueueIDFromFileID(USHORT ID) {
		return m_DiskHandler.GetQueueIDFromFileID(ID);
	}
	;
	///Determine if a queue has any data associated with it
	T_QMC_QUEUE_USED_STATUS GetQueueStatus(USHORT hQueue);
	///Request version determines if a block of a particular queue is in the to disk queue
	T_QMDSKSER_RETURN_VALUE ReqIsQueueObjectInToDiskQueue(const T_USRREQSER_USER user, const USHORT hQueue,
			USHORT *pCount = NULL);
	///Get the number of files that the queue has set as Max
	USHORT GetMaxFilesInQueue(const USHORT hQueue);
	T_QMC_DATAFILE_MODE IsQueueRecycling(const USHORT hQueue);
	///Get the number of files that the queue has set as Max
	USHORT GetNumFilesInQueue(const USHORT hQueue);
	///Clears the data from the chart queues and releases files to free file queue
	T_QMDSKSER_RETURN_VALUE ClearChartFiles();
	void EnterTDQCritical(void) {
		m_DiskHandler.EnterTDQCS();
	}
	void LeaveTDQCritical(void) {
		m_DiskHandler.LeaveTDQCS();
	}
	void EnterDSCritical(void) {
		m_csDiskServices.lock();
	}
	void LeaveDSCritical(void) {
		m_csDiskServices.lock();
	}
private: // Member Functions
	/// Called by the Block Services to Write Block(s) to Disk
	T_QMDSKSER_RETURN_VALUE WriteBlocksToDisk(const USHORT startBlockNumber, const USHORT endBlockNumber,
			const USHORT numOfBlocks);
	/// Set the File Limits for a Specified Queue					
	T_QMDSKSER_RETURN_VALUE SetFileLimits(const USHORT fileQueue, const USHORT minFiles, const USHORT maxFiles);
	/// Post the User Request to be Processed
	T_QMDSKSER_RETURN_VALUE PostUserRequest(const T_USRREQSER_USER user, const USHORT hQueue,
			const T_USRREQSER_USER_ACTION userAction, const LONGLONG startTime, const USHORT numOfBlocks,
			const T_USRREQSER_SEARCH_MODE mode, const T_USRREQSER_USER_FILE_TRANSACTION_TYPE userFileTransactionType,
			T_QMC_FILE_BLOCK_TRANSACTION *const pFileBlockTransaction,
			T_QMC_FILE_BLOCK_TRANSACTION *const pConfirmFromFileBlockTransaction, BYTE *const pDataBuffer);
	/// Set the Action to Perform on the Next Cycle of the Disk Service
	void SetNextActionToPerform(void);
	/// Perform the Actions for writing blocks to Disk
	T_QMDSKSER_RETURN_VALUE PerformWriteToDisk(void);
	/// Perform the Actions assocatied with a User Request 
	T_QMDSKSER_RETURN_VALUE PerformUserRequest(void);
private: // Member Variables
    static QMutex m_csDiskServices; ///< Critical Section for Thread Safe Operation
	CQMUserRequestServices m_UserRequestServices;	///< User Request Services 
	T_QMDSKSER_OPERATIONAL_MODE m_OperationalMode;///< Operational Mode of the Disk Service, used to control the Disk Service Thread
	T_QMDSKSER_ACTION_TO_PERFORM m_ActionToPerform;	///< Variable to store the action to be performed on each Disk Service Cycle
	CQMDiskHandler m_DiskHandler;	///< Disk Handler for Writing Blocks To Disk
	const CQMPersistBlkQAccess &m_PersistBlkQAccess;	///< Persisted Block Queue Access
	const CQMBlkQAccess &m_ToDiskBlkQAccess;			///< To Disk Queue
	const CQMBlkQAccess &m_TempStorageBlkQAccess;			///< To Temporarry Block Queue
	CQMFileBlockTransaction m_LastFileBlockTransaction; ///< Class to store the Last Transaction of a User Request.
	T_QMC_DBFILES m_asFiles[MAX_FILES];
};
// End of Class Declaration
#endif // _QMDISKSERVICES_H

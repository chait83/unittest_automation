/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  Queue Manager
/// @n Filename:  QMDataFileQueue.cpp
/// @n Description: Class Implementation File for the class CQMDataFileQueue
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  14  Aristos  1.7.1.3.1.1 9/21/2011 3:15:56 PM  Hemant(HAIL)  
//  Updated watchdog threadinfo call check
//  13  Aristos  1.7.1.3.1.0 9/19/2011 4:51:12 PM  Hemant(HAIL)  
//  Stability recorder source code (JI Release) updated for WatchDog
//  Timer functionality.
//  12  Stability Project 1.7.1.3 7/2/2011 5:00:02 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  11  Stability Project 1.7.1.2 7/1/2011 4:38:44 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
// $
//
// **************************************************************************
#include "QMDataFileQueue.h"
#include "V6globals.h"
#include "CStorage.h"
#include "ThreadInfo.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
//****************************************************************************
/// Constructor
///
/// @param[in] 	fileQueue - Reference to the Data File Queue Access Class 
/// @param[in] dataFileAccess - Reference to the Data File Header Access Class
///
/// @return No Return Value
/// 
//****************************************************************************
CQMDataFileQueue::CQMDataFileQueue(CQMDataFileQAccess &fileQueue, CQMDataFileAccess &dataFileAccess) : m_FileQueue(
		fileQueue), m_DataFileAccess(dataFileAccess) {
	// Do Nothing
} // End of Constructor
//****************************************************************************
/// Destructor
//****************************************************************************
CQMDataFileQueue::~CQMDataFileQueue(void) {
	// Do Nothing
} // End of Destructor
//****************************************************************************
/// Remove the Current( Head ) Available File from the Queue, ensures the head
/// and tail of the Queue are set correctly. If the Queue becomes Empty on this
/// call the Head and Tail will indicate this by a known default value. 
///
/// @param[in] - None
///
/// @return QMDFQ_OK  - Head File Removed Successfully
/// QMDFQ_NO_FILE_TO_REMOVE - No File within the Queue to Remove
/// 
//****************************************************************************
T_QMDFQ_RETURN_VALUE CQMDataFileQueue::RemoveHeadFile(void) {
	T_QMDFQ_RETURN_VALUE retValue = QMDFQ_NO_FILE_TO_REMOVE;
	if (QMDFQ_STATUS_EMPTY != GetQueueStatus()) {
		m_FileQueue.SetHead(m_DataFileAccess.GetNextFile(m_FileQueue.GetHead()));
		if (QMC_START_OF_QUEUE == m_FileQueue.GetHead()) {
			m_FileQueue.SetTail(QMC_END_OF_QUEUE);
		} else {
			m_DataFileAccess.SetPreviousFile(m_FileQueue.GetHead(), QMC_START_OF_QUEUE);
		} // End of IF
		retValue = QMDFQ_OK;
		m_FileQueue.DecrementNumOfFiles();
	} // End of IF
	return (retValue);
} // End of Member Function 
//****************************************************************************
/// Obtain a Pointer to the Current( Head ) Available File in the Queue
///
/// @param[in] - NONE
///
/// @return T_QMC_DATAFILE_HEADER - Pointer to the Head File
/// NULL - No Data File Available
///
//****************************************************************************
T_QMC_DATAFILE_HEADER* const CQMDataFileQueue::GetHeadFile(void) const {
	T_QMC_DATAFILE_HEADER *pDataFile = NULL;
	if (QMDFQ_STATUS_EMPTY != GetQueueStatus()) {
		pDataFile = m_DataFileAccess.GetFileHeader(m_FileQueue.GetHead());
	} // End of IF 
	return (pDataFile);
} // End of Member Function
//****************************************************************************
/// Add a Data File to the End( Tail ) of the Queue, taking into account that
/// the queue may be empty. 
///
/// @param[in] fileNumber - File Number to Add to the End of the Queue
///
/// @return QMBQ_OK - Data File Added Successfully
/// 
//****************************************************************************
T_QMDFQ_RETURN_VALUE CQMDataFileQueue::AddFileToTail(const USHORT fileNumber, BOOL bRealloc) {
	T_QMDFQ_RETURN_VALUE retValue = QMDFQ_OK;  /// Member Function Return Value
	//Reset the SRAM Header 
	m_DataFileAccess.SetQueueId(fileNumber, QMC_INVALID_QUEUE);
	m_DataFileAccess.SetFileMode(fileNumber, QMC_DATAFILE_MODE_NORMAL);
	m_DataFileAccess.SetNewestBlockNumber(fileNumber, QMC_ZERO);
	m_DataFileAccess.SetOldestBlockNumber(fileNumber, QMC_ZERO);
	m_DataFileAccess.SetNumOfBlocks(fileNumber, QMC_ZERO);
	if (QMDFQ_STATUS_EMPTY == GetQueueStatus()) {
		// Set the Head and Tail to both point to the new file
		m_FileQueue.SetHead(fileNumber);
		m_FileQueue.SetTail(fileNumber);
		// Set the New File Previous and Next to indicate this is the First Block in the Queue
		m_DataFileAccess.SetNextFile(fileNumber, QMC_END_OF_QUEUE);
		m_DataFileAccess.SetPreviousFile(fileNumber, QMC_START_OF_QUEUE);
	} else {
		// Set the Current Tail File to pointer to the New File to added
		m_DataFileAccess.SetNextFile(m_FileQueue.GetTail(), fileNumber);
		// Set the New File Previous Pointer to the Current Tail
		m_DataFileAccess.SetPreviousFile(fileNumber, m_FileQueue.GetTail());
		// Set the New File Next Pointer to indicate the End of Queue
		m_DataFileAccess.SetNextFile(fileNumber, QMC_END_OF_QUEUE);
		// Set the Tail of the Queue to point to the New File Added
		m_FileQueue.SetTail(fileNumber);
	} // End of IF
	m_FileQueue.IncrementNumOfFiles();
	// Write the File Header to the Physical File
//	if (!bRealloc)
//		WriteFileHeaderToPhysicalFile( fileNumber );
	return (retValue);
} // End of Member Function 
//****************************************************************************
/// Obtain whether the Data File Queue is EMPTY, FULL or SPACE AVAILABLE.
///
/// @param[in] - None
///
/// @return QMDFQ_STATUS_EMPTY  - Data File Queue is Empty 
/// QMDFQ_STATUS_FULL  - Data File Queue is Full
/// QMDFQ_STATUS_SPACE_AVAILABLE - Data File Queue has space available
///
//****************************************************************************
T_QMDFQ_QUEUE_STATUS CQMDataFileQueue::GetQueueStatus(void) const {
	T_QMDFQ_QUEUE_STATUS retValue = QMDFQ_STATUS_EMPTY;
	if (QMC_START_OF_QUEUE != m_FileQueue.GetHead() && QMC_END_OF_QUEUE != m_FileQueue.GetTail()) {
		if (m_FileQueue.GetNumOfFilesInQueue() == m_DataFileAccess.GetMaxNumOfFiles()) {
			retValue = QMDFQ_STATUS_FULL;
		} else {
			retValue = QMDFQ_STATUS_SPACE_AVAILABLE;
		} // End of IF
	} // End of IF
	return (retValue);
} // End of Member Function 
//****************************************************************************
/// Write a File Header for a specified File to Physical Disk
///
/// @param[in] fileId - File Identification Number of the File to write the Header
///
/// @return QMDFQ_OK  - File Header written to Physical Disk 
/// QMDFQ_ERROR  - File Header could not be written to Physical Disk
///
//****************************************************************************
T_QMDFQ_RETURN_VALUE CQMDataFileQueue::WriteFileHeaderToPhysicalFile(const USHORT fileId) {
	CStorage hDataBlockFile;  // Handle to the Data Block File
  QString filePathAndFileName = ""; // File and Path Name of the Data Block File
	T_QMDFQ_RETURN_VALUE retValue = QMDFQ_ERROR; // Member Function Return Value 
  if ( TRUE == pDALGLB->BuildPath(IDS_INTERNAL_SD, IDS_LOG_DATA, NULL, &filePathAndFileName, MAX_PATH)) {
		// Construct the File Name and Extension for the associated Data Block File 
		CQMDataFileAccess::CompleteDataFileName(filePathAndFileName, MAX_PATH, fileId);	// Complete Name
		// Open the Data Block File and ensure we are at the start of the file 
    if ( TRUE == hDataBlockFile.Open(filePathAndFileName, QFile::ReadWrite )) {
			hDataBlockFile.seek(0);
			// Write the File Header to the Disk File
			hDataBlockFile.Write(m_DataFileAccess.GetFileHeader(fileId), sizeof(T_QMC_DATAFILE_HEADER));
			// Close the File
			hDataBlockFile.Close();
			retValue = QMDFQ_OK;
		} // End of IF
	} // End of IF
	return (retValue);
} // End of Member Function 
//****************************************************************************
/// Provides a method of tracing the Queue to the Trace Window when debugging. 
/// The trace displays all the files within the Queue, starting from the Head.  
///
/// @param[in] pName - Name of the Queue to be Traced. 
///
/// @return No Return Value
/// 
//****************************************************************************
void CQMDataFileQueue::TraceQueue(const QString pName) {
	const T_QMC_DATAFILE_HEADER *const pHeadFile = GetHeadFile();
  qDebug()<<"\nName: %s\n", pName;
	if (QMDFQ_STATUS_EMPTY == GetQueueStatus()) {
		qDebug("BLOCK QUEUE EMPTY\n");
	} else {
		USHORT item = pHeadFile->fileId;
		USHORT itemNext = 0xFFFF;
		USHORT itemPrevious = 0xFFFF;
		qDebug("HEAD =");
		for (USHORT pos = 0; pos < m_FileQueue.GetNumOfFilesInQueue(); pos++) {
			qDebug(" (%d)", m_DataFileAccess.GetPreviousFile(item));
			qDebug("[%d] ", item);
			item = m_DataFileAccess.GetNextFile(item);
		} // End of FOR
		qDebug("= TAIL -> 0x%X (NoOfFiles: %d)\n\n", item, m_FileQueue.GetNumOfFilesInQueue());
	} // End of IF
} // End of Member Function
//****************************************************************************
/// AddLinkedFilesToTail - adds a string of linked files to the queue's tail
///
/// @param[in] pName - Name of the Queue to be Traced. 
///
/// @return QMDFQ_ERROR - the link was shorter than expected
///			QMDFQ_NO_FILE_TO_REMOVE - the link had a length of 0
///			QMDFQ_OK - Successful
/// 
//**************************************************************************** 
T_QMDFQ_RETURN_VALUE CQMDataFileQueue::AddLinkedFilesToTail(const USHORT firstFileNumber, USHORT count) {
	T_QMDFQ_RETURN_VALUE RetVal = QMDFQ_OK;
#ifdef UNDER_CE	
	CThreadInfo* pThreadInfo = CThreadInfo::GetHandle();
#endif 
	//clear out the sram headers for all the files
	if (count) {
		T_QMC_DATAFILE_HEADER *pDataFile = m_DataFileAccess.GetFileHeader(firstFileNumber);
		m_DataFileAccess.SetQueueId(firstFileNumber, QMC_INVALID_QUEUE);
		m_DataFileAccess.SetFileMode(firstFileNumber, QMC_DATAFILE_MODE_NORMAL);
		m_DataFileAccess.SetNewestBlockNumber(firstFileNumber, QMC_ZERO);
		m_DataFileAccess.SetOldestBlockNumber(firstFileNumber, QMC_ZERO);
		m_DataFileAccess.SetNumOfBlocks(firstFileNumber, QMC_ZERO);
		for (int ClearCount = 1; ClearCount < count; ++ClearCount) {
#ifdef UNDER_CE	
			if(pThreadInfo != NULL)
			{
				//Update the thread counter of diskservices thread 
				pThreadInfo->UpdateThreadCounter(AM_QMDISKSERVICES);
			}
#endif
			if (pDataFile->nextFile != QMC_END_OF_QUEUE) {
				pDataFile = m_DataFileAccess.GetFileHeader(pDataFile->nextFile);
				m_DataFileAccess.SetQueueId(pDataFile->fileId, QMC_INVALID_QUEUE);
				m_DataFileAccess.SetFileMode(pDataFile->fileId, QMC_DATAFILE_MODE_NORMAL);
				m_DataFileAccess.SetNewestBlockNumber(pDataFile->fileId, QMC_ZERO);
				m_DataFileAccess.SetOldestBlockNumber(pDataFile->fileId, QMC_ZERO);
				m_DataFileAccess.SetNumOfBlocks(pDataFile->fileId, QMC_ZERO);
			} else //hit end of queue earlier than expected
			{
				QString csErr;
				csErr = QString::asprintf("+++++++++++++Add Linked files to tail borked: ff=%d count=%d CC=%d",
						firstFileNumber, count, ClearCount);
      qDebug()<<csErr;
				RetVal = QMDFQ_ERROR;
				count = ClearCount + 1;
				break;
			}
		}
		//attach new link to end of current list
		if (QMDFQ_STATUS_EMPTY == GetQueueStatus()) {
			// Set the Head and Tail to both point to the new files
			m_FileQueue.SetHead(firstFileNumber);
			//set the queue tail to new tail
			m_FileQueue.SetTail(pDataFile->fileId);
			// Set the New File Previous and Next to indicate this is the First Block in the Queue
			m_DataFileAccess.SetPreviousFile(pDataFile->fileId, QMC_START_OF_QUEUE);
			m_DataFileAccess.SetNextFile(firstFileNumber, QMC_END_OF_QUEUE);
		} else {
			// Set the Current Tail File to pointer to the New File to added
			m_DataFileAccess.SetNextFile(m_FileQueue.GetTail(), firstFileNumber);
			// Set the New File Previous Pointer to the Current Tail
			m_DataFileAccess.SetPreviousFile(firstFileNumber, m_FileQueue.GetTail());
			// Set the last New File Next Pointer to indicate the End of Queue
			m_DataFileAccess.SetNextFile(pDataFile->fileId, QMC_END_OF_QUEUE);
			// Set the Tail of the Queue to point to the New File Added
			m_FileQueue.SetTail(pDataFile->fileId);
		}
		//update the count
		m_FileQueue.SetNumOfFiles(m_FileQueue.GetNumOfFilesInQueue() + count);
	} else
		RetVal = QMDFQ_NO_FILE_TO_REMOVE;
	return RetVal;
}

/// @file 
/// *****************************************************************
/// © Honeywell Trendview
/// *****************************************************************
/// @n Module : Module Message Manager (MMM )
/// @n FileName: MsgQueueStatistics.h
/// @n Desc  : Class Declaration for the CMsgQueueStatistics
///  
/// *****************************************************************
/// @b Revision @b History
/// *****************************************************************
/// $Log[4]:
/// 3 Stability Project 1.0.1.1 7/2/2011 4:58:54 PM Hemant(HAIL) 
/// Stability Project: Recorder source has been upgraded from IL
///  version of firmware to JF version of firmware.
/// 2 Stability Project 1.0.1.0 7/1/2011 4:27:00 PM Hemant(HAIL) 
/// Stability Project: Files has been checked in before the merging
///  task. The merging will be done between IL version of firmware and JF
///  version of firmware. 
/// 1 V6 Firmware 1.0 8/17/2004 2:05:25 PM  Alistair Brugsch 
/// $
///
#ifndef _MSGQUEUESTATISTICS_H
#define _MSGQUEUESTATISTICS_H
#include "Defines.h"
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
const FLOAT MQS_DEFAULT_ZERO_VALUE = 0.0; ///< Default Zero Value for all float variable
//**Class*********************************************************************
///
/// @brief Data Storage Class for Message Queue Statistical Data.  
/// 
/// Each Message Queue shall have the ability to record key information about 
/// the message queue operation. This will allow an insight to way in which 
/// the queue is being used within the system. This statistical data can be 
/// used to find problems within the system, and to fine tune the message queue 
/// to the way it is being used. A heavier used memory queue may require more 
/// heap memory to store messages, whereas message queue used infrequently may 
/// have lower memory requirements. 
///
/// The data stored have the data types as floats, this may seems a waste of 
/// memory, however this will allow the values to be used within the Maths block. 
/// This will allow the recorder to use these values to plot graphs on message 
/// queue usage, ideal for finding problems, and fine tuning applications.
///
//****************************************************************************
class CMsgQueueStatistics {
public:
	/// Constructor
	CMsgQueueStatistics();
	// Destructor
	virtual ~CMsgQueueStatistics();
	FLOAT m_QueueLoad; //<The number of messages in the Queue at any one time.
	FLOAT m_NumberOfTimesQueueWrapped; ///<If queue wrapping enabled, then how many times the message queue has wrapped.
	FLOAT m_NumberOfMessageLostDueToQueueWrap; ///<Number of message lost because of the message queue wrapping. 
	FLOAT m_NumOfMsgsAddedToQueue;  ///<Number of messages added to the Message Queue for Processing.
	FLOAT m_NumOfMsgsRemovedFromQueue;  ///<Number of messages removed from the Message Queue.
	FLOAT m_NumberOfBytesReceived;  ///<Number of Bytes the message has received including message header.
	FLOAT m_NumberOfDataBytesReceived;  ///<Number of Data Bytes, excluding Message Header received. 
	FLOAT m_NumOfTimesQueueFull; ///<Number of times the queue has been full.
	FLOAT m_NumOfTimesQueueLackOfMemory; ///<Number of times the message queue has run out of heap memory to store messages. 
	FLOAT m_LargestMessageSizeReceived; ///<Largest Message Received for Processing.
	FLOAT m_LargestDataSizeReceived;  ///<Largest Amount of Data received for processing excluding the Message Header. 
};
// End of CMsgQueueStatistics Declaration
#endif // _MSGQUEUESTATISTICS_H

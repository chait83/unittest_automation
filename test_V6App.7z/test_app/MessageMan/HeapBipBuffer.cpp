/// @file 
/// *****************************************************************
/// © Honeywell Trendview
/// *****************************************************************
/// @n Module : Module Message Manager (MMM )
/// @n FileName: HeapBipBuffer.cpp
/// @n Desc  : Implementation File for the HeapBipBuffer Class
///  
/// *****************************************************************
/// @b Revision @b History
/// *****************************************************************
/// $Log[4]:
/// 10  Stability Project 1.5.1.3 7/2/2011 4:57:50 PM Hemant(HAIL) 
/// Stability Project: Recorder source has been upgraded from IL
///  version of firmware to JF version of firmware.
/// 9 Stability Project 1.5.1.2 7/1/2011 4:38:18 PM Hemant(HAIL) 
/// Stability Project: Files has been checked in before the merging
///  task. The merging will be done between IL version of firmware and JF
///  version of firmware. 
/// 8 Stability Project 1.5.1.1 3/17/2011 3:20:25 PM  Hemant(HAIL) 
/// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
///  new operator in DEBUG mode only. To detect memory leaks in files, use
///  it in preprocessor definition when in debug mode.
/// 7 Stability Project 1.5.1.0 2/15/2011 3:03:06 PM  Hemant(HAIL) 
/// File updated during Heap Management. Call to the default behaviour
///  of new operator has been commented.
/// $
///
#include "HeapBipBuffer.h"
#include "V6globals.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//****************************************************************************
/// CHeapBipBuffer Constructor
///
//****************************************************************************
CHeapBipBuffer::CHeapBipBuffer() {
	// Initialise Heap Bip Buffer Pointer
	//
	m_pHeapBipBuffer = NULL;
	m_pCurrentData = NULL;
	m_pAvailableSpace = NULL;
	// Initialise Free Space Counters
	//
	m_PrimRegionFreeSpace = 0;
	m_SecRegionFreeSpace = 0;
	m_ReceivingRegion = PRIMARY_REGION;
	m_BipBufferSize = 0;
	// Initialise Committed Memory Counters
	//
	m_PrimCommittedMemSize = 0;
	m_SecCommittedMemSize = 0;
} // End of Constructor()
//****************************************************************************
/// CHeapBipBuffer Destructor
///
//****************************************************************************
CHeapBipBuffer::~CHeapBipBuffer() {
	// Destroy the Allocated Buffer
	delete[] m_pHeapBipBuffer;
} // End of Destructor()
//****************************************************************************
/// Creates and Allocates a Heap Buffer of a specified size
///
/// @param[in] heapSize - Size of the heap to allocated
///
/// @return whether the heap memory was allocated or an error has occurred.
///
//****************************************************************************
T_HEAPBIPBUFFER_RETURN_VALUE CHeapBipBuffer::AllocatedHeapBipBuffer(USHORT heapSize) {
	T_HEAPBIPBUFFER_RETURN_VALUE retValue = HEAPBIPBUFFER_HEAP_ALLOCATED;
	// Create a buffer
	//
//	GlbDevCaps.DisplayTraceMemoryStatus( L"before alloc bipbuffer" );
	m_pHeapBipBuffer = (BYTE*) new int[heapSize / 4]; // allocate as ints to get on 4 byte boundary
//	WCHAR buffy[200];
//	swprintf(buffy,L"after alloc bipbuffer of size %d",heapSize);
//	GlbDevCaps.DisplayTraceMemoryStatus(buffy);
	m_pCurrentData = m_pHeapBipBuffer;
	m_pAvailableSpace = m_pHeapBipBuffer;
	m_BipBufferSize = heapSize;
	m_PrimRegionFreeSpace = heapSize;
	// Ensure we have a valid pointer to the Heap Memory Allocated
	//
	if (NULL == m_pHeapBipBuffer) {
		retValue = HEAPBIPBUFFER_HEAP_ERROR;
	} else {
		// Initialise the Block of allocated Memory to known values
		//
		memset(m_pHeapBipBuffer, (BYTE) 0xBD, m_BipBufferSize);
	}
	return (retValue);
} // End of AllocatedHeapBipBuffer()
//****************************************************************************
/// Commit a specified amount of memory in the buffer for use. If the buffer
/// is full, NULL is returned, otherwise a pointer to the start of the committed
/// memory is returned. 
///
/// @param[in] memorySize - Size of Memory to commit in Bytes
/// @param[in,out] allocatedMemorySize - Actual Memory allocated, byte aligned 
///
/// @return A Pointer to the start of the committed memory, NULL pointer
/// if the buffer is full. 
///
/// @note Memory Committed will be 4 byte aligned. 
///
//****************************************************************************
BYTE* CHeapBipBuffer::CommitMemory(USHORT memorySize, USHORT &allocatedMemorySize) {
	BYTE *pStartOfAllocatedMemoryBlock = NULL;
	USHORT alignmentAdjustment = HEAPBIPBUFFER_ZERO_VALUE;
	USHORT requiredMemoryAllocation = memorySize;
	// 4 Byte Align the memory allocated
	//
	alignmentAdjustment = (USHORT) (memorySize & 0x03);
	if (alignmentAdjustment != HEAPBIPBUFFER_ZERO_VALUE) {
		requiredMemoryAllocation = (USHORT) ((memorySize + HEAPBIPBUFFER_FOUR_BYTES) - alignmentAdjustment);
	}
	allocatedMemorySize = HEAPBIPBUFFER_ZERO_VALUE;
	switch (m_ReceivingRegion) {
	case PRIMARY_REGION:
		if (m_PrimRegionFreeSpace >= requiredMemoryAllocation) {
			// Commit Memory in the Primary Region
			//
			pStartOfAllocatedMemoryBlock = m_pAvailableSpace;
			m_PrimCommittedMemSize = (USHORT) (m_PrimCommittedMemSize + requiredMemoryAllocation);
			m_PrimRegionFreeSpace = (USHORT) (m_PrimRegionFreeSpace - requiredMemoryAllocation);
			m_pAvailableSpace += requiredMemoryAllocation;
			allocatedMemorySize = requiredMemoryAllocation;
		} else {
			// No Space Available at the end of the buffer for data,
			// as we are in the primary region, check if space is
			// available in Secondary Region.
			//
			if (m_SecRegionFreeSpace >= requiredMemoryAllocation) {
				pStartOfAllocatedMemoryBlock = m_pHeapBipBuffer;
				m_ReceivingRegion = SECONDARY_REGION;
				m_pAvailableSpace = m_pHeapBipBuffer;
				m_pAvailableSpace += requiredMemoryAllocation;
				m_SecCommittedMemSize = (USHORT) (m_SecCommittedMemSize + requiredMemoryAllocation);
				m_SecRegionFreeSpace = (USHORT) (m_SecRegionFreeSpace - requiredMemoryAllocation);
				allocatedMemorySize = requiredMemoryAllocation;
			} // End of If
		} // End of If
		break;
	case SECONDARY_REGION:
		if (m_SecRegionFreeSpace >= requiredMemoryAllocation) {
			// Commit Memory in the Secondary Region
			//
			pStartOfAllocatedMemoryBlock = m_pAvailableSpace;
			m_SecCommittedMemSize = (USHORT) (m_SecCommittedMemSize + requiredMemoryAllocation);
			m_SecRegionFreeSpace = (USHORT) (m_SecRegionFreeSpace - requiredMemoryAllocation);
			m_pAvailableSpace += requiredMemoryAllocation;
			allocatedMemorySize = requiredMemoryAllocation;
		}
		break;
	default: /* Error */
		break;
	} // End of Switch
	return (pStartOfAllocatedMemoryBlock);
} // End of CommitMemory()
//****************************************************************************
/// Releases a specified amount of memory from the Primary committed memory
/// region. If all the memory committed in the primary region is released,
/// the secondary region becomes the primary region, and the secondary region
/// reset. 
///
/// @param[in] memorySize - Size of committed memory to release in Bytes
///
/// @return Memory has been released successfully
///
//****************************************************************************
T_HEAPBIPBUFFER_RETURN_VALUE CHeapBipBuffer::ReleaseCommittedMemory(USHORT memorySize) {
	T_HEAPBIPBUFFER_RETURN_VALUE retValue = HEAPBIPBUFFER_COMMITTED_MEMORY_RELEASED;
	if (memorySize >= m_PrimCommittedMemSize) {
		// Memory being released clears all the commited memory within the primary
		// region. If the secondary region is in use, the primary region pointers
		// are assign to the secondary region. This will cause the buffer to start
		// reading from the start, and any new data appended to the current data
		// in the buffer. If the secondary region is empty, then the primary region
		// pointers are pointing to the start of the buffer.
		//  
		m_ReceivingRegion = PRIMARY_REGION;
		m_pCurrentData = m_pHeapBipBuffer;
		// Check whether there is any committed data within the Secondary Region, 
		// if not then the avialable data is set to the start if the BIP Buffer. 
		// Otherwise the avialable pointer needs to remain in its current position. 
		if (HEAPBIPBUFFER_ZERO_VALUE == m_SecCommittedMemSize) {
			m_pAvailableSpace = m_pHeapBipBuffer;
		} // End of IF
		m_PrimCommittedMemSize = m_SecCommittedMemSize;
		m_PrimRegionFreeSpace = (USHORT) (m_BipBufferSize - m_PrimCommittedMemSize);
		m_SecCommittedMemSize = HEAPBIPBUFFER_ZERO_VALUE;
		m_SecRegionFreeSpace = HEAPBIPBUFFER_ZERO_VALUE;
	} else {
		// Increment the amount of avaialble memory in the second region, and
		// decrement the amount of memory committed in the primary region.
		//
		m_pCurrentData += memorySize;
		m_SecRegionFreeSpace = (USHORT) (m_SecRegionFreeSpace + memorySize);
		m_PrimCommittedMemSize = (USHORT) (m_PrimCommittedMemSize - memorySize);
	} // End of If
	return (retValue);
} // End of ReleaseCommittedMemory()

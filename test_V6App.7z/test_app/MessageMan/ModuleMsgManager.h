/// @file 
/// *****************************************************************
/// © Honeywell Trendview
/// *****************************************************************
/// @n Module : Module Message Manager (MMM )
/// @n FileName: ModuleMsgManager.h
/// @n Desc	: Class Declaration for the Message Module Manager
///			
/// *****************************************************************
/// @b Revision @b History
/// *****************************************************************
/// $Log[4]:
/// 4	Stability Project 1.1.1.1	7/2/2011 4:58:52 PM	Hemant(HAIL) 
///		Stability Project: Recorder source has been upgraded from IL
///	version of firmware to JF version of firmware.
/// 3	Stability Project 1.1.1.0	7/1/2011 4:26:59 PM	Hemant(HAIL) 
///		Stability Project: Files has been checked in before the merging
///	task. The merging will be done between IL version of firmware and JF
///	version of firmware. 
/// 2	V6 Firmware 1.1		3/30/2005 2:46:30 PM	Alistair Brugsch
///	Updated to become a Passive Module by inheriting from CPassiveModule
/// 1	V6 Firmware 1.0		8/17/2004 2:05:25 PM	Alistair Brugsch 
/// $
///
#ifndef _MODULEMSGMANANGER_H
#define _MODULEMSGMANANGER_H
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include <QMutex>
#include "ModuleConstants.h"
#include "CircularArrayMsgQueue.h"
#include "PassiveModule.h"				// Passive Module Base Class
/// Return Values for CModuleMsgManager Member Functions, used to describe the type of 
/// success or failure.
/// 
typedef enum {
	MODMSGMAN_OK,
	MODMSGMAN_REGISTRATION_SUCCESSFUL,
	MODMSGMAN_MODULE_ALREADY_REGISTERED,
	MODMSGMAN_ERROR,
	MODMSGMAN_CLEANUP_COMPLETE,
	MODMSGMAN_MODULES_INITIALISED,
	MODMSGMAN_MESSAGE_QUEUE_CREATION_ERROR
} T_MODMSGMAN_RETURN_VALUE;
//**Class*********************************************************************
///
/// @brief Responsible for the creation and deletion of the Module Message
///		Queues.
/// 
/// All Module Message Queues are created on startup of the system, to allow
/// modules to communication with each other straight away. This class has
/// the task of creating all the required message queues. This is a singleton
/// class, each module requiring the use of the message queues will create
/// a Module Message Manager Client. This client will directly interact with
/// this class, and for efficency the client is a friend. This will allow the
/// message queues to be obtained directly. Apart from creation and deletion,
/// of message queues, this class primary function is providing a central 
/// location for all the message queues to be used for module communication.	
///
/// @note This class is a SINGLETON
///
//****************************************************************************
class CModuleMsgManager: public CPassiveModule {
	friend class CModuleMsgManagerClient;
public:
	/// Setup each queue for the required modules
	T_MODMSGMAN_RETURN_VALUE InitialiseModules(void);
	/// Cleanup the Message Queues
	T_MODMSGMAN_RETURN_VALUE CleanUp(void);
	/// Obtain handler to the Module Message Manager
	static CModuleMsgManager* GetHandle(void);
private:
	// Restrict the following four methods from being called, as this is a singleton
	//
	CModuleMsgManager();
	CModuleMsgManager(const CModuleMsgManager&);
	CModuleMsgManager& operator=(const CModuleMsgManager&) {
		return *this;
	}
	;
	~CModuleMsgManager();
	static CModuleMsgManager *m_pInstance; ///< Single Instance of the Module Message Manager
	static QMutex m_CreationMutex;		///< Mutex for instance creation
	CCircularArrayMsgQueue *m_pMessageQueue[MODULE_NUM_OF_MODULES]; ///< Message Queue for each module
};
// End of CModuleMsgManager
#endif // _MODULEMSGMANANGER_H

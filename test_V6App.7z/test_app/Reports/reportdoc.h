/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Reports System UI
/// @n Filename: ReportDoc.h
/// @n Desc:	 Definition of the CReportDoc class
///				 
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  7 Stability Project 1.3.1.2 7/2/2011 5:00:24 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  6 Stability Project 1.3.1.1 7/1/2011 4:38:49 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  5 Stability Project 1.3.1.0 1/12/2011 3:49:57 PM  Hemant(HAIL) 
// File updated for Stability Project.
//  Please check the comment "Stability Project Fix:" for the changes
//  done to the source code in this file.
//  4 V6 Firmware 1.3 4/18/2007 5:08:45 PM  Roger Dawson  
//  Optimised the code that opens RTF files so that it has less of a
//  burden on the processor and memory resources.
// $
//
// ****************************************************************
#if !defined(AFX_REPORTDOC_H__C32E86BF_5AB4_4D0B_A079_FCB6CA27B6ED__INCLUDED_)
#define AFX_REPORTDOC_H__C32E86BF_5AB4_4D0B_A079_FCB6CA27B6ED__INCLUDED_
#include "StringUtils.h"
#include "ReportSegment.h"
#include "DataItemBase.h"
#include <vector>
#include "Print.h"
#include <QTextDocument>
typedef std::vector<CReportSegment> ReportSegmentList;
/// Structure used to hold infomration about the table that is currently being processed
typedef struct {
	/// The number of columns - this is recalculated for each row
	int iNoOfColumns;
	// Array holding the cell end position (assumes there will never be more than 20 columns on a table)
	ULONG ulCellEndPos[20];
	/// Zero based variable that indicates which cell we are currently looking at
	int iCurrCell;
	/// Flag used to indicate if we are processing a table
	bool bInTable;
} T_REPORTS_TABLE_INFO;
class CArchive {
};
//**CReportDoc***********************************************************
///
/// @brief Class used to load and store an RTF report file
/// 
/// Class used to load and store an RTF report file
///
//**********************************************************************
class CReportDoc: public QTextDocument {
public:
	// protected constructor used by dynamic creation
	CReportDoc();
	// DECLARE_DYNCREATE (CReportDoc)
// Attributes
public:
// Operations
public:
	// Constructor
	const QSize SetupSegmentList(CDC *pDC, const int iPAGE_WIDTH, const int iCHAR_SIZE,
			ReportSegmentList &rkSegmentList) const;
#ifdef PRINT_CE
	const QSize SetupSegmentList(	CPrintCEWrapper* pCEWrapper, 
									const int iPAGE_WIDTH, 
									const int iCHAR_SIZE,
									ReportSegmentList &rkSegmentList ) const;
#endif
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CReportDoc)
public:
	virtual void Serialize(CArchive &ar);  // overridden for document i/o
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
protected:
	virtual BOOL OnNewDocument();
	//}}AFX_VIRTUAL
public:
	static const QString ms_strNEW_LINE;
	static const QString ms_strPAR;
	static const QString ms_strSECT;
	static const QString ms_strTROWD;
	static const QString ms_strCELL;
	static const QString ms_strSTART_CELL;
	static const QString ms_strPARA_IN_CELL;
	static const QString ms_strCELL_WIDTH;
// Implementation
public:
	virtual ~CReportDoc();
	/// Method that returns the number of lines the document will require given the settings
	/// passed into the GetDocSize method earlier
	void SetNoOfLines(const LONG lNO_OF_LINES) {
		m_lNoOfLines = lNO_OF_LINES;
	}
	/// Accessor for the number of lines
	const long GetNoOfLines() const {
		return m_lNoOfLines;
	}
	/// Accessor for the header information
	const QString GetHeader() const {
		return m_strHeaderInfo;
	}
	/// Accessor for the header information
	const QString GetrightHeader() const {
		return m_strHeaderInfo;
	}
	/// Accessor for the header information
	const QString GetleftHeader() const {
		return m_strHeaderInfo;
	}
	/// Accessor for the footer information
	const QString GetrightFooter() const {
		return m_strFooterInfo;
	}
	/// Accessor for the footer information
	const QString GetleftFooter() const {
		return m_strFooterInfo;
	}
private:
	/// String containing the delimitted header information
	QString m_strHeaderInfo;
	/// String containing the delimitted footer information
	QString m_strFooterInfo;
	/// Variable indicating the number of lines
	int m_lNoOfLines;
	/// Store for the segment information
	ReportSegmentList m_kSegmentList;
	/// Structure used to store information about the current table being processed
	T_REPORTS_TABLE_INFO m_tTableInfo;
	// Method that reverts any RTF unicode characters back into unicode strings
	const QString RevertUnicode(const QString pwcBUFFER);
	// Method that strips any RTF formatting and puts it into our own internal format
	const bool StripRTF(QString &rstrDataToStrip);
	// Method that strips the required RTF info and puts it into our own internal format
	const bool StripRTFInfo(QString &rstrDataToStrip, const QString &rstrCONTROL_WORD, int &riCurrPos);
	// Method that processes the next control string further adding replacement text as neccessary
	void ProcessControlWord(QString &rstrDataToStrip, const QString &rstrCONTROL_STRING, int &riCurrPos);
	/// Method that gets the last point near the end of this segment that is the end of an RTF control string
	const QString GetUptoLastCompleteRTFString(QString &rstrTempSegment);
};
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.
#endif // !defined(AFX_REPORTDOC_H__C32E86BF_5AB4_4D0B_A079_FCB6CA27B6ED__INCLUDED_)

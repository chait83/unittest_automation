/// @file
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Data Item Table
/// @n Filename: DataItemManager.h
/// @n Desc:	 Data Item table manager abstract from V6 functionality
///
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  17  Stability Project 1.14.1.1 7/2/2011 4:56:38 PM Hemant(HAIL)
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  16  Stability Project 1.14.1.0 7/1/2011 4:27:17 PM Hemant(HAIL)
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware.
//  15  V6 Firmware 1.14 3/28/2007 3:49:55 PM  Andy Kassell  Add
//  Pen report information, max, min, ave and totals for hour, day week
//  and month
//  14  V6 Firmware 1.13 2/16/2007 9:13:44 PM  Andy Kassell  Add
//  zero padding to counter embedding
// $
//
// ****************************************************************
#ifndef __DATAITEMMANAGER_H__
#define __DATAITEMMANAGER_H__
#include "DataItemBase.h"
#include "PassiveModule.h"
#include <QMap>
#include <QList>
#include <QMutex>
const int MAX_VARIABLES = 6000;		///< Sanity check on the number of variables that can be contained within the system
const int MAX_EMBEDDED_DATA_SIZE = 200;		///< Maximum Size for the embedded data
// Embedded tokens
const WCHAR EMBED_TYPE_VALUE = L'V';		///< Value
const WCHAR EMBED_TYPE_TAG = L'T';			///< Tag
const WCHAR EMBED_TYPE_ZERO = L'Z';			///< Zero
const WCHAR EMBED_TYPE_SPAN = L'S';			///< Span
const WCHAR EMBED_TYPE_UNITS = L'U';		///< Units
const WCHAR EMBED_REP_SET_LAST = L'L';			///< Last report set
const WCHAR EMBED_REP_SET_CURRENT = L'C';		///< Current report set
const WCHAR EMBED_REP_PERIOD_HOUR = L'H';		///< Hour
const WCHAR EMBED_REP_PERIOD_DAY = L'D';		///< Day
const WCHAR EMBED_REP_PERIOD_WEEK = L'W';		///< Week
const WCHAR EMBED_REP_PERIOD_MONTH = L'M';		///< Month
typedef enum {
	EMBED_VAR_NONE = 0,					///< No embedded ref type
	EMBED_VAR_TIME,						///< Embed the time
	EMBED_VAR_DATE,						///< Embed the date
	EMBED_VAR_TIMEDATE,					///< Embed the time and date
	EMBED_VAR_NAME,						///< Embed the recorder name
	EMBED_VAR_ID,						///< Embed the recorder ID
	EMBED_VAR_SERIAL,					///< Recorder serial number
	EMBED_VAR_REP_MAX,					///< Report Max
	EMBED_VAR_REP_MIN,					///< Report Min
	EMBED_VAR_REP_AVE,					///< Report Average
	EMBED_VAR_REP_TOT,					///< Report Total
	EMBED_VAR_REP_MAT,					///< Max time
	EMBED_VAR_REP_MIT,					///< Min time
	EMBED_VAR_REP_STM,					///< Start time
	EMBED_VAR_MAX						///< Max embedded variables, always at end
} T_EMBED_VARIABLES;
typedef enum {
	ATTRIB_USER_BLOCK_MIN = 1,			///< First available user block
	ATTRIB_USER_BLOCK_MAX = 230,		///< Last available user block
	ATTRIB_ALARM_IN_NOT_ACK,			///< Alarm , in alarm but NOT acknowledged global colour
	ATTRIB_ALARM_IN_ACK,				///< Alarm , in alarm but acknowledged global colour
	ATTRIB_ALARM_OUT_NOT_ACK,			///< Alarm , out but NOT acknowledged global colour
	ATTRIB_ALARM_OUT,					///< Alarm , out, no flashing and deafult steady state
	ATTRIB_ALARM_OVERVIEW,			///< Alarm Overview, if any alarm is "in alarm" irripective of state use this colour
	ATTRIB_CHART_NORMAL,				///< Global chart background(BGCol) and graduation colour(FG Col)
	ATTRIB_CHART_NORMAL_ALARM,		///< Global chart when alarm active background(BGCol) and graduation colour(FG Col)
	ATTRIB_CHART_REPLAY,				///< Global replay chart background(BGCol) and graduation colour(FG Col)
	ATTRIB_CHART_REPLAY_ALARM,///< Global replay chart when alarm active background(BGCol) and graduation colour(FG Col)
	ATTRIB_CHART_TEXT,				///< Global chart text(timestamps, markers) (FG Col)=timestamp (BGCol)=marker text
	ATTRIB_MAX_BLOCKS = 255				///< Max blocks, never change
} T_ATTRIB_BLOCKS;
/// Attribute Block structure, provides a way to control the attributes of
/// OpPanel objects using the Script Services and other V6 specific fucntions.
typedef struct _attribBlock {
	BOOL Visible;						///< Control object/widget visibility
	BOOL Flashing;						///< Control flashing attribute
	COLORREF FGCol;						///< Foreground colour
	COLORREF BGCol;						///< Background colour
} T_ATTRIB_BLOCK, *T_PATTRIB_BLOCK;
//**Class*********************************************************************
///
/// @brief Data Item Manager
///
/// This class will provide all management and top level access fucntions
/// for the Data Items and Attribute blocks.
///
//****************************************************************************
class CDataItemManager: public CPassiveModule {
public:
	static CDataItemManager* GetHandle();
	void CleanUp();
private:	// Singleton
	CDataItemManager();
	~CDataItemManager() {
	}
	;	// Will never be called
	CDataItemManager(const CDataItemManager&);
	CDataItemManager& operator=(const CDataItemManager&) {
		return *this;
	}
	;
	static CDataItemManager *m_pDataItemInstance;
	static QMutex m_CreationMutex;
public:
	/// API Calls
	// Initialisation/control
	BOOL CreateDataItemTable();
	void AddContainer(T_DATA_ITEM_TYPE type, CDataItemTypeContainer *containRef);
	BOOL ApplyConfig();
	// Apply Layout configuration changes/start-up to the Data item table
	BOOL ApplyLayoutConfig(const T_PLAYOUT ptLAYOUT);
	// General Data Item Access
	CDataItemTypeContainer* GetContainerPtr(T_DATA_ITEM_TYPE type) {
		return m_diContainer[type];
	}
	;
	CDataItem* GetDataItemPtr(T_DATA_ITEM_TYPE type, USHORT ref, USHORT instance);
	// Script services Access
	int LookUp(const QString pvarName);
	CDataItem* GetDataItemPtr(int lookUpRef);
	float GetValueFromLookup(int lookUpRef) {
		return GetDataItemPtr(lookUpRef)->GetFPValue();
	}
	;
	// Attribute Table Access
	void SetAttribFGCol(USHORT blockNum, COLORREF col) {
		attribBlockPtr(blockNum)->FGCol = col;
	}
	;
	void SetAttribBGCol(USHORT blockNum, COLORREF col) {
		attribBlockPtr(blockNum)->BGCol = col;
	}
	;
	void SetAttribVisible(USHORT blockNum, BOOL visible) {
		attribBlockPtr(blockNum)->Visible = visible;
	}
	;
	void SetAttribFlashing(USHORT blockNum, BOOL flashing) {
		attribBlockPtr(blockNum)->Flashing = flashing;
	}
	;
	T_PATTRIB_BLOCK attribBlockPtr(USHORT blockNum);
	BOOL ExpandEmbeddedValues(const QString &srcString, QString &destString, int destLength, QString &ErrorString,
			const USHORT usGROUP_INDEX = 0);
private:
	BOOL BuildMap();
	BOOL TranslateEmbeddedIdent(QString &varString, QChar type, QString &ErrorString);
private:
	CDataItemTypeContainer *m_diContainer[DI_MAX_DATA_ITEM_TYPES];	///< Array of Data Item containers
	T_ATTRIB_BLOCK m_attribBlock[ATTRIB_MAX_BLOCKS];	///< Attribute blocks.
	int m_variablesAvailable;		///< total number of variable accessable data items
	QList<HANDLE> m_DIArray;			///< Array of pointers to CDataItem object for script access
	QMap<QString, void*> m_VarNameMap;	///< Map of variable names with references intop m_DiArray for lookup
	/// *Note* the ptr element of the map is actuallt an index into m_DIArray and NOT
	///			a ptr value, this is casted in the relevant access functions.
	QMap<QString, void*> m_EmbdNameMap;	///< Map of embedded variables not held in Data Item Table
	/// *Note* the ptr element of the map is an enum for the embedded type
};
#endif // __DATAITEMMANAGER_H__

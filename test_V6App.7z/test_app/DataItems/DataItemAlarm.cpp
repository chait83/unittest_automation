/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Data Item Table
/// @n Filename: DataItemAlarm.cpp
/// @n Desc:	 Pen Alarm items for Data item table
///
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//15Stability Project 1.10.1.3 7/2/2011 4:56:37 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//version of firmware to JF version of firmware.
//14Stability Project 1.10.1.2 7/1/2011 4:38:12 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//task. The merging will be done between IL version of firmware and JF
//version of firmware. 
//13Stability Project 1.10.1.1 3/17/2011 3:20:20 PMHemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//new operator in DEBUG mode only. To detect memory leaks in files, use
//it in preprocessor definition when in debug mode.
//12Stability Project 1.10.1.0 2/15/2011 3:02:51 PMHemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//of new operator has been commented.
// $
//
// ****************************************************************
#include "V6globals.h"
#include "DataItemAlarm.h"
#include <stdio.h>
#include <wchar.h>
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
//=============================================================================
// CDataItemTypeAlarm Class
//=============================================================================
//****************************************************************************
/// CDataItemTypeAlarm Constructor
//****************************************************************************
CDataItemTypeAlarm::CDataItemTypeAlarm() {
}
//****************************************************************************
/// CDataItemTypeAlarm Destructor
//****************************************************************************
CDataItemTypeAlarm::~CDataItemTypeAlarm() {
	m_AlarmDataItemArray.clear();
}
//****************************************************************************
/// CreateItemTable overridden method, create the item table. 
/// responisibility to create the memory for Data items, and initialise the table
///
/// @return - T_DI_RETURN status of method 
///
//****************************************************************************
T_DI_RETURN CDataItemTypeAlarm::CreateItemTable() {
	T_DI_RETURN retVal = DI_OKAY;
	//qDebug("Create Data Item table for a %d Alarms\n",V6_MAX_PENS*V6_MAX_ALARMS);
	// Stage 1, Create the memory space for the DataItems
	m_AlarmDataItemArray.resize(V6_MAX_PENS * V6_MAX_ALARMS);
	SetDataItemInfo(DI_ALARM, V6_MAX_ALARMS, V6_MAX_PENS); // Type Alarm, number of alarms types and Max Pens instance.
	// Stage 2, initialise the data items
	WCHAR varName[MAX_VARNAME_LEN];
	memset(varName, 0, MAX_VARNAME_LEN);
	int alarmCount = 0;
	int baseIndex = 0;
	CDataItemAlarm *pAlarmDIT;
	for (int penCount = 0; penCount < V6_MAX_PENS; penCount++) {
		// Generate base index for each pen, this will jump in steps of V6_MAX_ALARMS
		baseIndex = penCount * V6_MAX_ALARMS;
		// Run though each alarm, assign the variable name and add to the DIT
		for (alarmCount = 0; alarmCount < V6_MAX_ALARMS; alarmCount++) {
//swprintf(varName,MAX_VARNAME_LEN, L"Hello world");
			swprintf(varName, MAX_VARNAME_LEN, L"P%dA%dL", penCount + 1, alarmCount + 1);
			pAlarmDIT = &m_AlarmDataItemArray[baseIndex + alarmCount];
			AddDataItem(pAlarmDIT, alarmCount, penCount, QString::fromWCharArray(varName), DI_FLOAT);
			pAlarmDIT->SetAlarmNumber(alarmCount);
		}
	}
	// Set the dummy Alarm Data Item
	SetDummyDataItem(new CDataItemAlarm());
	return retVal;
}
//****************************************************************************
/// ApplyConfig overridden method, handle all configuration changes and startup
/// Will be called on startup when configuration in place and every time
/// the current configuration changes.
///
/// @return - T_DI_RETURN status of method 
///
//****************************************************************************
T_DI_RETURN CDataItemTypeAlarm::ApplyConfig() {
	T_DI_RETURN retVal = DI_OKAY;
	CDataItemAlarm *pAlarmDIT;
	for (int penCount = 0; penCount < V6_MAX_PENS; penCount++) {
		for (int alarmCount = 0; alarmCount < V6_MAX_ALARMS; alarmCount++) {
			// Get a handle on the Alarm Data Item
			pAlarmDIT = (CDataItemAlarm*) GetDataItemPtr(alarmCount, penCount);
			// Setup any configuration time changes on an alarm basis
			pAlarmDIT->SetAlarmConfig();
		}
	}
	// Setup the dummy data item 
	reinterpret_cast<CDataItemAlarm*>(GetDummyDataItem())->SetAlarmConfig();
	return retVal;
}
//****************************************************************************
/// Link CDataItemTypeAlarm table items to CDataItemTypePen items as these
/// Alarms are all derived from a Pen
///
/// @param[in] - pLinkPenType, ptr to Pen DIT Type, this type is dependent on Pens
///
/// @return - T_DI_RETURN status of method 
///
//****************************************************************************
T_DI_RETURN CDataItemTypeAlarm::LinkPenTypes(CDataItemTypePen *pLinkPenType) {
	T_DI_RETURN retVal = DI_OKAY;
	CDataItemAlarm *pAlarmDIT;
	// Loop through all Pens and assign the Pen Data Item to each of the MMA types
	// so they can derive their details from the Pens.
	for (int penCount = 0; penCount < V6_MAX_PENS; penCount++) {
		for (int alarmCount = 0; alarmCount < V6_MAX_ALARMS; alarmCount++) {
			// Get a handle on the Alarm Data Item
			pAlarmDIT = (CDataItemAlarm*) GetDataItemPtr(alarmCount, penCount);
			// Assign Pen Data Item to the Alarm Data Item
			pAlarmDIT->SetPenDITPtr((CDataItemPen*) pLinkPenType->GetDataItemPtr(DI_PEN_READING, penCount));
		}
	}
	// Setup the dummy data item to look at the dummy pen data item
	reinterpret_cast<CDataItemAlarm*>(GetDummyDataItem())->SetPenDITPtr(
			(CDataItemPen*) pLinkPenType->GetDummyDataItem());
	return retVal;
}
//=============================================================================
// CDataItemAlarm Class
//=============================================================================
//****************************************************************************
/// CDataItemAlarm Constructor
//****************************************************************************
CDataItemAlarm::CDataItemAlarm() {
	m_alarmNumber = 0;
	SetAlarmStatus(0);
}
//****************************************************************************
/// Get the colour of the Data Item, will return the disabled colour of disabled
///
/// @return - pointer to a COLOREF
//****************************************************************************
COLORREF* CDataItemAlarm::GetColour() {
	if (IsEnabled())
		return m_pPenDIT->GetColour();
	else
		return &GlbDITDisabaledColour;
}
//****************************************************************************
/// Setup the DIT enabled flags for this type
///
/// @return - nothing 
///
//****************************************************************************
void CDataItemAlarm::SetAlarmConfig() {
	// Set ptr for quick lookup to the confgiuration of the Alarm within CMM
	m_pAlarmCfg = &m_pPenDIT->m_pPenConfig->Alm[m_alarmNumber];
	// Check if the Pen is enabled, if so check if alarm is anabled and set DIT enabled flag accoringly
	BOOL enabled = FALSE;
	if (m_pPenDIT->IsEnabled()) {
		if (m_pAlarmCfg->EnableType != 0) {
			enabled = TRUE;	/// DIT will always be abled even when digitals set
		}
	}
	RegisterChange();
	SetEnabled(enabled);		// Set the enabled status of the Alarm
}
//****************************************************************************
/// Test if the Alarm level is a user changed level or from config
///
/// @return - TRUE if modified, FALSE if from setup config 
///
//****************************************************************************
BOOL CDataItemAlarm::IsAlarmLevelUser() {
	if (m_pAlarmCfg->Level == this->GetFPValue())
		return FALSE;		// User level is same as config.
	else
		return TRUE;		// User level is different.
}

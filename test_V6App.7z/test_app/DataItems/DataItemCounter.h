/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Data Item Table
/// @n Filename: DataItemCounter.h
/// @n Desc:	 General system items for Data item table
///
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//4 Stability Project 1.1.1.1 7/2/2011 4:56:38 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//version of firmware to JF version of firmware.
//3 Stability Project 1.1.1.0 7/1/2011 4:27:48 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//task. The merging will be done between IL version of firmware and JF
//version of firmware. 
//2 V6 Firmware 1.1 4/2/2007 9:04:53 PM Andy KassellAdd
//tag storage
//1 V6 Firmware 1.0 11/1/2006 2:58:43 PMAndy Kassell
// $
//
// ****************************************************************
#ifndef __DATAITEMCOUNTER_H__
#define __DATAITEMCOUNTER_H__
#include "DataItemBase.h"
#include "NVVariables.h"
#include "V6Config.h"
// Subtypes of general Items available, Flat no subytes.
typedef enum {
	DI_COUNTTYPE_USER = 0,
	DI_COUNTTYPE_EVENTS,
	DI_COUNTTYPE_IO,
	DI_COUNTTYPE_HCOUNT,
	DI_COUNTTYPE_LCOUNT,
	DI_COUNTTYPE_MAX_TYPES
} T_COUNTER_TYPES;
//**Class*********************************************************************
///
/// @brief Counter Data Items
/// 
/// This class will provide the support for Counter based data items
///
//****************************************************************************
class CDataItemCounter: public CDataItem {
public:
	CDataItemCounter();
	void WhoAmI() {
		qDebug("I'm a Counter Data item ");
		WhoAmI();
	}
	;
	CNVBasicVar* GetNVHandle() {
		return m_pNV;
	}
	;
	void SetNVHandle(CNVBasicVar *nv) {
		m_pNV = nv;
	}
	;
	void SetValue(float value);
	const WCHAR* GetTag() const {
		return m_tag;
	}
	;
	void ResetCounter(float value);
	void IncrementCounter(float value);
	void setTag(QString counterTag) {
#if _MSC_VER < 1400 
         counterTag.toWCharArray(m_tag);
#else
		wcsncpy_s ( m_tag, sizeof(m_tag)/sizeof(WCHAR),counterTag, _TRUNCATE); 
#endif
	}
	;
private:
	CNVBasicVar *m_pNV;	///< Ptr to NV variable area if used, otherwise FALSE
	WCHAR m_tag[COUNTERSDATA_TAG_LEN];
};
//**Class*********************************************************************
///
/// @brief Counter data Item Type, container class
/// 
/// This class will provide Pen specific access for Counter data items
///
//****************************************************************************
class CDataItemTypeCounter: public CDataItemTypeContainer {
public:
	CDataItemTypeCounter();			///< Constructor
	~CDataItemTypeCounter();			///< Destructor
	T_DI_RETURN CreateItemTable();		///< Create the Data Item table for 
	T_DI_RETURN ApplyConfig();			///< Apply configuration for data table item.
	T_DI_RETURN AddItem(int index, T_COUNTER_TYPES type, NVVAR_IDENT nvid, QString varName);
private:
	QVector<CDataItemCounter> m_CounterDataItemArray;
	int m_maxItems;
};
#endif // __DATAITEMCOUNTER_H__

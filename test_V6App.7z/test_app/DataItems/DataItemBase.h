/// @file
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Data Item Table
/// @n Filename: Data Item Base.h
/// @n Desc:	 Base classes for the Data Item table and container
///
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//36Stability Project 1.33.1.1 7/2/2011 4:56:37 PM Hemant(HAIL)
// Stability Project: Recorder source has been upgraded from IL
//version of firmware to JF version of firmware.
//35Stability Project 1.33.1.0 7/1/2011 4:27:16 PM Hemant(HAIL)
// Stability Project: Files has been checked in before the merging
//task. The merging will be done between IL version of firmware and JF
//version of firmware.
//34V6 Firmware 1.33 4/2/2007 9:04:23 PM Andy KassellAdd
//GetDesc accessor for description
//33V6 Firmware 1.32 12/20/2006 3:33:13 PMRoger Dawson
//Phase 3b merges into the main build. Removed dependacy on V6defines.h
// $
//
// ****************************************************************
#ifndef __DATAITEMBASE_H__
#define __DATAITEMBASE_H__
#include "TVtime.h"
#include "V6defines.h"
#include "V6Config.h"
#include "V6types.h"
#include <map>
#include <QMutex>
#include "Defines.h"
#include <wchar.h>
#include "TVtime.h"
const int REF_ERROR = -1;			///< Error in referencing data items
const int MAX_VARNAME_LEN = 10;	///< Maximum length of varibale names 9 chars + null
const ULONG DEFAULT_RATE = 100 / 2;	///< Default update rate of DIT variable, 2Hz
const COLORREF DISABLED_COLOUR = RGB(160, 160, 160);
const COLORREF BASE_COLOUR = RGB(92, 92, 92);
extern COLORREF GlbDITDisabaledColour;
/// Union of data types used for Data items
//typedef union
//{
//	float DIfloat;
//	void *pDIvoid;
//	int DIint;
//}T_DATATYPES;
/// Data Item data type, identifier for diDataTypes usage
typedef enum {
	DI_FLOAT, DI_PVOID, DI_INT
} T_DATAITEM_VARIABLE_TYPE;
// List of status, this is same for all types.
typedef enum {
	DISTAT_INVALID = 0,				///< An invalid status reading
	DISTAT_INPUT_UNDERRANGE,				///< Input has gone underrange, reading not valid
	DISTAT_INPUT_OVERRANGE,		///< Input has gone overrange, reading not valid
	DISTAT_INPUT_UPSCALE_BURNOUT,		///< Burnout on input occured - show upscale setting, reading not valid
	DISTAT_INPUT_DOWNSCALE_BURNOUT,	///< Burnout on input occured - show downscale setting, reading not valid
//	** make sure anything after this is a valid reading and aything before this point is an invalid reading
	DISTAT_NORMAL,					///< DIT normal reading valid,
	DISTAT_UNDERRANGE,				///< Pen value is Underrange of suggested display Zero point( reading still valid)
	DISTAT_OVERRANGE,				///< Pen value is overrange of suggested span value (reading still valid)
	DISTAT_IN_ALARM_NOT_ACKED,		///< Alarm is "in alarm state" and has not been manually acknowledged
	DISTAT_IN_ALARM_ACKED,			///< Alarm is "in alarm state" and has been manually acknowledged
	DISTAT_OUT_OF_ALARM_NOT_ACKED,///< Alarm is now "out of alarm state" but wasn't acknowledged when in alarm, and was not auto
	DISTAT_OUT_OF_ALARM,	///< Alarm is now "out of alarm state", if previously in alarm was acknowledged or was auto
	DISTAT_TOTAL_PAUSED,			///< Totaliser is currently paused, and not running
	DISTAT_TOTAL_RUNNING,			///< Totaliser is currently running
	DISTAT_MAX_STATUS				///< Maximum number of stati DO NOT MOVE.
} T_DATAITEM_STATUS;
// Data item table return types
typedef enum {
	DI_OKAY = 0, DI_FAILED, DI_INVALID_ITEM, DI_MEMALLOC_FAILED,
} T_DI_RETURN;
// Types of data items, this list must remain constant, screen designer and op panel rely on these.
typedef enum {
	DI_NONE = -1, DI_IO = 0,				///< IO, Analogues Digital Pulse
	DI_PEN,					///< Pen PV's				
	DI_MMA,					///< Max Mins and averages per pen
	DI_TOTAL,				///< Totals per pen
	DI_ALARM,				///< Alarms per pen
	DI_COUNTER,				///< Counters
	DI_GENERAL,				///< General information, system variables etc..
	DI_QUEUE,
	DI_USER_INPUT,
	DI_MESSAGE_LIST,
	DI_MAX_DATA_ITEM_TYPES				///< Max item types, NB always at end
} T_DATA_ITEM_TYPE;
typedef struct RLOGCONFIG {
	int penCount;
	int penNo[V6_MAX_PENS];
	int subscribe[V6_MAX_PENS];
	int logRate[V6_MAX_PENS];
	int logUnits[V6_MAX_PENS];
} RLOGCONFIGSTRUCT;
typedef struct RTDataStruct {
	int id[V6_MAX_PENS];
	float val[V6_MAX_PENS];
	float max[V6_MAX_PENS];
	float min[V6_MAX_PENS];
	LONGLONG maxTimestamp[V6_MAX_PENS];
	LONGLONG minTimestamp[V6_MAX_PENS];
	LONGLONG avgTimestamp[V6_MAX_PENS];
} RTDATASTRUCT;
typedef struct RWRITECONFIG {
	int cvNo[V6_MAX_PENS];
	float value[V6_MAX_PENS];
} RWRITECONFIGSTRUCT;
typedef struct AlarmAckConfig {
	int penNo;
	int alarmNo;
} ALARM_ACK_CONFIG_STRUCT;
typedef std::map<int, RLOGCONFIGSTRUCT> MAP_RLOGCONFIG;
//**Class*********************************************************************
///
/// @brief Data Item base class
///
/// This class will provide the base and template methods for the Data Items
///
//****************************************************************************
class CDataItem {
public:
	CDataItem();
	~CDataItem();
	virtual void WhoAmI() {
		qDebug(" object ref %d inst %d\n", m_subType, m_instance);
	}
	;
	// Initialisation
	void SetDataType(T_DATAITEM_VARIABLE_TYPE dataType) {
		m_dataType = dataType;
	}
	;
	void SetTypeRefInstance(T_DATA_ITEM_TYPE type, USHORT reference, USHORT instance);
	void SetVarName(QString pvarName);
	BOOL IsDataItemAVariable();
	QString GetVariableName() {
		m_varName.reserve(MAX_VARNAME_LEN);
		return m_varName;
	}
	;
	// Client access interface
	virtual float GetZero() const;
	virtual float GetSpan() const;
	virtual const WCHAR* GetTag() const;
	virtual const WCHAR* GetUnits() const;
	virtual COLORREF* GetColour();
	virtual T_PSCALEINFO GetScaleInfo();
	virtual T_PLINESTYLE GetLineInfo();
	virtual const WCHAR* GetDesc() const;
	virtual USHORT GetRate() {
		return m_rate;
	}
	;		///< Get Rate in syste, ticks 1/100s of a second
	virtual USHORT GetAlarmType() {
		return 0;
	}
	;		///< Return type of alarm
	virtual USHORT GetAlarmStatus() {
		return 0;
	}
	;		///< Return number of active alarms
	virtual void SetAlarmStatus(USHORT status) {
		;
	}
	;				///< Set alarm status (does nothing in base Object)
	USHORT GetReference() const {
		return m_subType;
	}
	;
	USHORT GetInstance() const {
		return m_instance;
	}
	;
	T_DATA_ITEM_TYPE GetType() const {
		return m_type;
	}
	;
	T_DATAITEM_VARIABLE_TYPE GetDataType() const {
		return m_dataType;
	}
	;
	T_DATAITEM_STATUS GetStatus() const;
	CTVtime GetTime() {
		return m_time;
	}
	;
	LONGLONG GetTimeuS() {
		return m_time.GetMicroSecs();
	}
	;
	BOOL IsEnabled() {
		return m_enabled;
	}
	;
	ULONG GetUpdateCounts() {
		return m_timeUpdateInProcessTicks;
	}
	;	// Get time Data item was updated in Ticks
	COMBO_VAR4 GetComboValue() {
		return m_value;
	}
	;
	float GetFPValue() const;
	void SetEnabled(BOOL Enabled);
	void SetRate(USHORT rate) {
		m_rate = rate;
	}
	;			///< Set the rate in system ticks
	virtual void SetValue(float value);
//	virtual void SetValue( int value );
//	virtual void SetValue( void *value );
	virtual void SetStatus(T_DATAITEM_STATUS status);
	virtual void SetTime(const CTVtime &newTime);
	virtual void SetTime(const LONGLONG &newTime);
	static void SetCurrentProcessTime(ULONG proccessTick) {
		m_DIcurrentProcessTick = proccessTick;
	}
	;
	static ULONG m_DIcurrentProcessTick;			///< Class wide global to set process tick time.
	void RegisterChange() {
		m_timeUpdateInProcessTicks++;
	}
	;
private:
	BOOL m_enabled;									///< Is the Data item this is referring to enabled
	T_DATA_ITEM_TYPE m_type;						///< Data Item type
	USHORT m_subType;								///< Data item subtype of a type
	USHORT m_instance;								///< Data item instance of a subtype
	USHORT m_rate;									///< Rate in system tick 1/100ths of a second
	T_DATAITEM_VARIABLE_TYPE m_dataType;			///< Data type of m_value
	COMBO_VAR4 m_value;								///< Actual data for data item, union
	CTVtime m_time;									///< Data Item time of change
	T_DATAITEM_STATUS m_status;						///< status of Data item
	ULONG m_timeUpdateInProcessTicks;				///< Time variable was updated in process ticks
	QString m_varName;
	//m_varName.reserve(MAX_VARNAME_LEN);				///< Variable name of Data item for script access
	static QMutex m_hAccessMutex;					///Mutex to protect access to dataitem from multiple threads
	static BOOL m_bMutexCreated;					///Flag to indicate mutex is created
};
//**Class*********************************************************************
///
/// @brief Data Item type container base class
///
/// This class will provide the base class for data item type management
///
//****************************************************************************
class CDataItemTypeContainer {
private:
	CDataItem *pDummyDataItem;///< The dummy Data Item will be available for each container type and used when "0xFFFF"
public:
	CDataItemTypeContainer();
	virtual ~CDataItemTypeContainer();
	// Pure Virtuals, have to be implemented by derived classes
	virtual T_DI_RETURN CreateItemTable()=PURE_VIRTUAL_FUNCTION
	;	///< Virtual, Create the data items and register them
	virtual T_DI_RETURN ApplyConfig()=PURE_VIRTUAL_FUNCTION
	;		///< Virtual, Apply the configuration, and config changes to data items
	void SetDataItemInfo(T_DATA_ITEM_TYPE type, int maxSubType, int maxInst);
	T_DI_RETURN AddDataItem(CDataItem *pDataItem, USHORT subType, USHORT instance, QString varName,
			T_DATAITEM_VARIABLE_TYPE dataType);
	CDataItem* GetDataItemPtr(USHORT subType, USHORT instance);	///< Get Item by ref and instance
	CDataItem* GetDataItemPtr(int sequentialRef);			///< Get Item by flat reference
	int GetSequentialFromRefAndInst(USHORT subType, USHORT instance);
	int GetTotalVars(void) {
		return m_totalVariables;
	}
	;
	int GetTotalItems(void) {
		return m_totalItems;
	}
	;
	CDataItem* GetDummyDataItem() {
		return pDummyDataItem;
	}
	;
	void SetDummyDataItem(CDataItem *pDataItem) {
		pDummyDataItem = pDataItem;
	}
	;
private:
	T_DATA_ITEM_TYPE m_type;			///< Data item type, see enum dataItemType DI_xxxx
	int m_maxSubType;						///< Maximum number of references
	int m_maxInst;				///< Maximum number of instances per reference
	int m_totalItems;				///< Total Number of items held within table
	int m_totalVariables;				///< Number of Items with a Variable name that will be accessable via scripts
	CDataItem **m_pDataItemArray;				///< Array of pointers to data items, sized in SetDataItemInfo
};
#endif // __DATAITEMBASE_H__

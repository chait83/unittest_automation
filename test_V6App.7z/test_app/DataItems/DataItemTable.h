/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Data Item Table
/// @n Filename: DataItemTable.h
/// @n Desc:	 Data Item tbale manager
///
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//12Stability Project 1.9.1.1 7/2/2011 4:56:38 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//version of firmware to JF version of firmware.
//11Stability Project 1.9.1.0 7/1/2011 4:27:16 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//task. The merging will be done between IL version of firmware and JF
//version of firmware. 
//10V6 Firmware 1.9 11/1/2006 2:58:34 PMAndy KassellAdd
//Counters to the Data item table
//9 V6 Firmware 1.8 3/8/2006 7:28:31 PM Roger Dawson
//Added code to make the data item table pointer referenced within the
//InitDataItemTable method unique and not the same as the pDIT #define.
// $
//
// ****************************************************************
#ifndef __DATAITEMTABLE_H__
#define __DATAITEMTABLE_H__
#include "DataItemManager.h"		// Abstract DataItem and attribute Manager
// V6 specific interfaces
#include "DataItemPen.h"
#include "DataItemIO.h"
#include "DataItemMaxMinAve.h"
#include "DataItemAlarm.h"
#include "DataItemTotal.h"
#include "DataItemCounter.h"
#include "DataItemGeneral.h"
// Independent intitialisation for Data item table specifics.
BOOL InitDataItemTable(CDataItemManager *pkDataItemManager);
#endif // __DATAITEMTABLE_H__

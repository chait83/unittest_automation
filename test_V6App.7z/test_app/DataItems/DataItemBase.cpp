/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Data Item Table
/// @n Filename: DataItemBase.cpp
/// @n Desc:	 Base classes for the Data Item table and container
///
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//37Stability Project 1.31.1.4 7/2/2011 4:56:37 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//version of firmware to JF version of firmware.
//36Stability Project 1.31.1.3 7/1/2011 4:38:12 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//task. The merging will be done between IL version of firmware and JF
//version of firmware. 
//35Stability Project 1.31.1.2 3/17/2011 3:20:20 PMHemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//new operator in DEBUG mode only. To detect memory leaks in files, use
//it in preprocessor definition when in debug mode.
//34Stability Project 1.31.1.1 2/15/2011 3:02:51 PMHemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//of new operator has been commented.
// $
//
// ****************************************************************
#include <wchar.h>
#include "DataItemBase.h"
#include "V6defines.h"
#include "V6globals.h"
#include <QMutex>
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
// Dummy data, this will be replaced by derived classes, however if a derived class does not implement
// the dummy information will be returned, avoids client testing for high throughput items.
static T_SCALEINFO lScaleInfo;
static T_LINESTYLE lLineStyle;
static BOOL DummyAlarmStatus;
BOOL CDataItem::m_bMutexCreated = FALSE;
//QMutex CDataItem::m_hAccessMutex;
// Static DataItem member for processing ticks 
ULONG CDataItem::m_DIcurrentProcessTick = 0;
COLORREF GlbDITDisabaledColour = DISABLED_COLOUR; // Disabled colour used for OpPanel
//=============================================================================
// CDataItemTypeContainer Class
//=============================================================================
//****************************************************************************
/// CDataItemTypeContainer Constructor
//****************************************************************************
CDataItemTypeContainer::CDataItemTypeContainer() {
	m_type = DI_NONE;
	m_maxSubType = 0;
	m_maxInst = 0;
	m_pDataItemArray = NULL;
	m_totalVariables = 0; // Number of Items with a Variable name that will be accessable via scripts
	m_totalItems = 0;
	// Initialise local dummy data
	memset(&lScaleInfo, 0, sizeof(T_SCALEINFO));
	lScaleInfo.Span = 100;						// Span is 0 to 100
	lScaleInfo.MajorDivs = 20;					// Major divs every 20
	lScaleInfo.NumF.Auto = TRUE;				// Auto number format 
	memset(&lLineStyle, 0, sizeof(T_LINESTYLE));
	lLineStyle.Thickness = 1;					// Single pixel line thickness
	lLineStyle.Colour = BASE_COLOUR;			// base colour
	SetDummyDataItem(NULL);
	DummyAlarmStatus = FALSE;				// Dummy alarm status always FALSE
}
//****************************************************************************
/// CDataItemTypeContainer Destructor
///
//****************************************************************************
CDataItemTypeContainer::~CDataItemTypeContainer() {
	// Cleanup dataItems
	if (m_pDataItemArray != NULL) {
		delete m_pDataItemArray;
	}
	if (pDummyDataItem != NULL) {
		delete pDummyDataItem;
	}
}
//****************************************************************************
/// Sets the contraints of the Data Item table for a specific type
///
/// @param[in] - type, Type of data item must be a T_DATA_ITEM_TYPE
/// @param[in] - maxRef, Maximum number of references expects for type
/// @param[in] - maxInst, Maximum number of instances for each reference
///
/// @return - nothing 
///
//****************************************************************************
void CDataItemTypeContainer::SetDataItemInfo(T_DATA_ITEM_TYPE type, int maxRef, int maxInst) {
	m_type = type;								// Set type and limits 			
	m_maxSubType = maxRef;								// Number of references
	m_maxInst = maxInst;					// Number of instances per reference
	m_totalItems = m_maxInst * m_maxSubType;					// Total items total size of two dimensional array
	m_pDataItemArray = new CDataItem*[m_totalItems];					// Create an array of pointers to CDataItem
	for (int i = 0; i < m_totalItems; i++) {
		m_pDataItemArray[i] = NULL;						// Set all pointers to NULL
	}
	///@todo change return type as it now allocates memory
	//qDebug("Data Item table added %d items for type %d \n", m_totalItems, type );
}
//****************************************************************************
/// Add's a data item instance into the data item table, the caller is responsible
/// for allocating the space for the Data item object which will be derived
/// from CDataType
///
/// @param[in] - pDataItem, ptr to the memory instance of the CDataType derived object
/// @param[in] - subType, subType of the data item
/// @param[in] - instance, instance number of the subType allocated to the data item
/// @param[in] - *varName, ptr to QString   instance of Variable name, NULL if no variable name
/// @param[in] - dataType, type of data T_DATAITEM_VARIABLE_TYPE that the data item will maintain
///
/// @return - T_DI_RETURN status of method 
///
//****************************************************************************
T_DI_RETURN CDataItemTypeContainer::AddDataItem(CDataItem *pDataItem, USHORT subType, USHORT instance, QString varName,
		T_DATAITEM_VARIABLE_TYPE dataType) {
	T_DI_RETURN retVal = DI_OKAY;
	int itemRef = GetSequentialFromRefAndInst(subType, instance);
	if (itemRef != REF_ERROR) {
		m_pDataItemArray[itemRef] = pDataItem;
		pDataItem->SetTypeRefInstance(m_type, subType, instance);	// Set type subType and instance
		pDataItem->SetDataType(dataType);					// Set the data type
		// If a variable name exisits for this item, set it and represent in script variable counter
		if (varName != NULL) {
			pDataItem->SetVarName(varName);
			m_totalVariables++;
		}
	} else {
		retVal = DI_INVALID_ITEM;
	}
	return retVal;
}
//****************************************************************************
/// Get the sequential instance number of the data item from reference and instance (flatten the array)
///
/// @param[in] - subType, subType number to allocate to the data item
/// @param[in] - instance, instance number of the reference allocated to the data item
///
/// @return - flat reference of the Data Item or REF_ERROR if limits exceeded
///
//****************************************************************************
int CDataItemTypeContainer::GetSequentialFromRefAndInst(USHORT subType, USHORT instance) {
	int itemFlat = (subType * m_maxInst) + instance;
	if (itemFlat >= m_totalItems) {
		qDebug("Error: GetDataItemflat instance of %d, only %d items available \n", itemFlat, m_totalItems);
		itemFlat = REF_ERROR;
	}
	return itemFlat;
}
//****************************************************************************
/// Get pointer to Data Item object using subType and instance number
/// if these don't exist then the dummy data item for the container
/// is returned
///
/// @param[in] - subType, subType number of data item
/// @param[in] - instance, instance number of subType for data item
///
/// @return - ptr to data item object or "dummy data item" if data item does not exist
///
//****************************************************************************
CDataItem* CDataItemTypeContainer::GetDataItemPtr(USHORT subType, USHORT instance) {
	CDataItem *pDataItem = NULL;
	if (subType < m_maxSubType && instance < m_maxInst) {
		int seqRef = GetSequentialFromRefAndInst(subType, instance);
		if (seqRef != REF_ERROR) {
			pDataItem = GetDataItemPtr(seqRef);
		}
	} else {
		pDataItem = GetDummyDataItem();
	}
	return pDataItem;
}
//****************************************************************************
/// Get pointer to Data Item object using sequential reference (flat array)
///
/// @param[in] - sequentialRef, sequential reference number of data item
///
/// @return - ptr to data item object, NULL if data item does not exist
//****************************************************************************
CDataItem* CDataItemTypeContainer::GetDataItemPtr(int sequentialRef) {
	CDataItem *pDataItem = NULL;
	if (sequentialRef < m_totalItems) {
		pDataItem = m_pDataItemArray[sequentialRef];
	}
	return pDataItem;
}
//=============================================================================
// CDataItem Class
//=============================================================================
//****************************************************************************
/// CDataItemTypeContainer Constructor
//****************************************************************************
CDataItem::CDataItem() {
	m_enabled = FALSE;
	m_type = DI_NONE;
	m_subType = 0;
	m_instance = 0;
	m_rate = DEFAULT_RATE;
	m_timeUpdateInProcessTicks = 0;
	m_dataType = DI_FLOAT;
	m_value.flt = (float) 0;
	m_status = DISTAT_NORMAL;
	m_varName[0] = 0;
}
//****************************************************************************
/// CDataItemTypeContainer Destructor
//****************************************************************************
CDataItem::~CDataItem() {
	//Close the handle
}
//****************************************************************************
/// Set Type reference and instance of a data item
///
/// @param[in] - type, type of data item must be in T_DATA_ITEM_TYPE 
/// @param[in] - subType, subType of data type
/// @param[in] - instance, instance of subType of data type
///
/// @return - nothing
//****************************************************************************
void CDataItem::SetTypeRefInstance(T_DATA_ITEM_TYPE type, USHORT subType, USHORT instance) {
	// Set Type , reference and Instance, self reference only.
	m_type = type;
	m_subType = subType;
	m_instance = instance;
}
//****************************************************************************
/// Set variable name of data item
///
/// @param[in] - *varName, ptr to variable name
///
/// @return - nothing
//****************************************************************************
void CDataItem::SetVarName(QString pvarName) {
	//
	// Stability Project Fix:
	//
	// Memory Leak Issue: The local variable "pLocalvarName" has been assigned memory but has not been further used in this function
	// for assigning it to the member variable.
	// further the string functions like '_wcsdup' also allocates memory through malloc.
	// hence there is double memory allocation for the statements which are never used in this function
	// Commenting the the code where "pLocalvarName" is used avoids unnecessary memory leaks.
	//
	// Also the check in the 'if' block is wrong, and as the local variable has now been removed 
	// it has been replaced by the 'in' paramater, "pvarName"
	//
	WCHAR pTemp[100];
	memset(pTemp, 0, 100);
	m_varName.toWCharArray(pTemp);
	//if (pLocalvarName != NULL)
	if (pvarName != NULL) {
		//pLocalvarName = _wcsupr( _wcsdup(pvarName) );	// Force DIT variable name to upper case
#if _MSC_VER < 1400 
		wcsncpy(pTemp, pvarName, MAX_VARNAME_LEN - 1);
#else
  wcsncpy_s( pTemp, sizeof(m_varName)/sizeof(WCHAR), pvarName, MAX_VARNAME_LEN-1 );
#endif
		m_varName[MAX_VARNAME_LEN - 1] = 0;
		// delete [] pLocalvarName;
		// pLocalvarName = NULL;
	} else {
#if _MSC_VER < 1400 
		wcsncpy(pTemp, L"", MAX_VARNAME_LEN - 1);
#else
		wcsncpy_s( m_varName, sizeof(m_varName)/sizeof(WCHAR), QString   ::fromWCharArray(""), MAX_VARNAME_LEN-1 );
#endif
		pTemp[MAX_VARNAME_LEN - 1] = 0;
	}
}
//****************************************************************************
/// Check if data item is a variable. i.e. does it have a variable name
/// allowing it to be referenced from within the script services
///
/// @return - TRUE if varible name available, otherwise FALSE
//****************************************************************************
BOOL CDataItem::IsDataItemAVariable() {
	BOOL retVal = FALSE;
	if (m_varName[0] != 0)
		retVal = TRUE;
	return retVal;
}
//****************************************************************************
/// Set the Data Item to enabled/disabled, if disabled set the value to 0
/// and make sure the item is invalidated
///
/// @param[in] - value, new value of data item
///
/// @return - TRUE if varible name available, otherwise FALSE
//****************************************************************************
void CDataItem::SetEnabled(BOOL Enabled) {
	m_enabled = Enabled;
	if (m_enabled == FALSE) {
		SetValue(0.0);
		SetStatus(DISTAT_INVALID);
	}
}
//****************************************************************************
/// Set the current floating point value of the Data Item
///
/// @param[in] - value, new value of data item
///
/// @return - nothing
//****************************************************************************
void CDataItem::SetValue(float value) {
	m_hAccessMutex.lock();
	m_value.flt = value;
	RegisterChange();
	m_hAccessMutex.unlock();
}
//****************************************************************************
/// Set the status of a Data Item
///
/// @param[in] - status, T_DATAITEM_STATUS of status of data item
///
/// @return - nothing
//****************************************************************************	
void CDataItem::SetStatus(T_DATAITEM_STATUS status) {
	m_hAccessMutex.lock();
	m_status = status;
	RegisterChange();
	m_hAccessMutex.unlock();
}
//****************************************************************************
/// Get the current floating point value of the Data Item
///
/// @return - Current value as float
//****************************************************************************
float CDataItem::GetFPValue() const {
	float fltVal;
	m_hAccessMutex.lock();
	fltVal = m_value.flt;
	m_hAccessMutex.unlock();
	return fltVal;
}
//****************************************************************************
/// Get the current status value of the Data Item
///
/// @return - Current value as status
//****************************************************************************
T_DATAITEM_STATUS CDataItem::GetStatus() const {
	T_DATAITEM_STATUS ValSts;
	m_hAccessMutex.lock();
	ValSts = m_status;
	m_hAccessMutex.unlock();
	return ValSts;
}
//****************************************************************************
/// Get the Zero scale value
///
/// @return - Scale value
//****************************************************************************
float CDataItem::GetZero() const {
	return lScaleInfo.Zero;
}
//****************************************************************************
/// Get the Span scale value
///
/// @return - Scale value
//****************************************************************************
float CDataItem::GetSpan() const {
	return lScaleInfo.Span;
}
//****************************************************************************
/// Get the default Tag text label
///
/// @return - Ptr to Tag text
//****************************************************************************
const WCHAR* CDataItem::GetTag() const {
	static const WCHAR defaultTag[] = L"Default Tag";
	return defaultTag;
}
//****************************************************************************
/// Get the default Tag text label
///
/// @return - Ptr to Tag text
//****************************************************************************
const WCHAR* CDataItem::GetDesc() const {
	static const WCHAR defaultDesc[] = L"Default Desc";
	return defaultDesc;
}
//****************************************************************************
/// Get the default units text label
///
/// @return - Ptr to Units text
//****************************************************************************
const WCHAR* CDataItem::GetUnits() const {
	static const WCHAR defaultUnits[] = L"%";
	return defaultUnits;
}
//****************************************************************************
/// Get a colour for data item. (Ptr used for OpPanel redraw speed and colour
///									source decisions)
/// @return - Ptr to COLORREF
//****************************************************************************
COLORREF* CDataItem::GetColour() {
	return &lLineStyle.Colour;
}
//****************************************************************************
/// Get a ptr to the Scale Info structure, conatins all information including 
/// Zero and Span
/// @return - Ptr to T_SCALEINFO structure (V6Config.h based)
//****************************************************************************
T_PSCALEINFO CDataItem::GetScaleInfo() {
	return &lScaleInfo;
}
//****************************************************************************
/// Get a ptr to the Line Info structure, contains Color, Style and Width of line
///
/// @return - Ptr to T_LINESTYLE structure (V6Config.h based)
//****************************************************************************
T_PLINESTYLE CDataItem::GetLineInfo() {
	return &lLineStyle;
}
//****************************************************************************
/// Set the time of the data item change to the CTVtime passed
///
/// @param[in] - newTime, reference to new time to set.
///
/// @return - nothing
//****************************************************************************
void CDataItem::SetTime(const CTVtime &newTime) {
	m_time = newTime;
}
//****************************************************************************
/// Set the time of the data item change to the LONGLONG in MicroSeconds passed
///
/// @param[in] - newTime, reference to new time to set.
///
/// @return - nothing
//****************************************************************************
void CDataItem::SetTime(const LONGLONG &newTime) {
	m_time = newTime;
}

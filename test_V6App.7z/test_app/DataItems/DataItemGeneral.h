/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Data Item Table
/// @n Filename: DataItemGeneral.h
/// @n Desc:	 General system items for Data item table
///
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//19Stability Project 1.16.1.1 7/2/2011 4:56:38 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//version of firmware to JF version of firmware.
//18Stability Project 1.16.1.0 7/1/2011 4:27:30 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//task. The merging will be done between IL version of firmware and JF
//version of firmware. 
//17V6 Firmware 1.16 9/23/2008 3:09:23 PMBuild Machine 
//AMS2750 Merge
//16V6 Firmware 1.15 3/7/2007 3:19:34 PM Roger Dawson
//Added the batch count (BATCX) data item. Also allow setting the batch
//name within the BATMDX data item.
// $
//
// ****************************************************************
#ifndef __DATAITEMGENERAL_H__
#define __DATAITEMGENERAL_H__
#include "StringUtils.h"
#include "NVVariables.h"
#include "StringUtils.h"
#include <QVector>
#include "DataItemBase.h"
const int MAX_GENERAL_TAG_LENGTH = 16;			///< Maximum length of a general Tag
const int MAX_GENERAL_UNITS_LENGTH = 12;		///< Maximum length of a general Tag
const float UNKNOWN_RANGE_ZERO = -99999999.0F;
const float UNKNOWN_RANGE_SPAN = +99999999.0F;
// General Data Item types, add new types here then add to adata item using AddItem in CDataItemTypeGeneral::CreateItemTable()
typedef enum {
	DI_GEN_IDLE = 0,						///< Idle time percentage
	DI_GEN_ON_TIME_SEC,					///< On time in seconds
	DI_GEN_COMMS_VAR_IN_FIRST,			///< First communications variable
	DI_GEN_COMMS_VAR_IN_MAX = (DI_GEN_COMMS_VAR_IN_FIRST + MAX_COMMS_VARS),	///< Max comms variables, Data item wont exist for this entry
	DI_GEN_QUEUE_TODISK,	///< % of queues waiting to go to disk queue item
	DI_GEN_QUEUE_FREEBLOCK,	///< % of blocks(SRAM) currently in the free queue
	DI_GEN_QUEUE_FILESFREE,		///< % of files currently in the free file queue
	DI_GEN_BATCHMODE_FIRST,					///< Mode of batch 
	DI_GEN_BATCHMODE_MAX = (DI_GEN_BATCHMODE_FIRST + MAX_V6_PEN_GROUPS),
	DI_GEN_BATCHCOUNT_FIRST,					///< Mode of batch 
	DI_GEN_BATCHCOUNT_MAX = (DI_GEN_BATCHCOUNT_FIRST + MAX_V6_PEN_GROUPS),
	DI_GEN_MEM_LOAD,					///< General Memory load as a percentage
	DI_GEN_MEM_PHYS_AVAIL,				///< Available physical memory (in K)
	DI_GEN_MEM_PHYS_TOTAL,				///< Total physical memory available (in K)
	DI_GEN_MEM_VIRT_AVAIL,				///< Available virtual memory (in K)
	DI_GEN_MEM_VIRT_TOTAL,				///< Total virtual memory available (in K)
	DI_GEN_MEM_VIRT_LOWTIDE,			///< Low tide mark virtual memory available (in K)
	// Q Debugging
	DI_GEN_Q_MCPAN,
	DI_GEN_Q_MCMES,
	DI_GEN_Q_MCCHA,
	DI_GEN_Q_MCLOG,
	DI_GEN_Q_MCOTH,
	DI_GEN_Q_BLK_REL,
	DI_GEN_Q_HB,
	DI_GEN_FRONTCF_PC,					///< Front CF Card %age Free space
	DI_GEN_USB1_PC,						///< USB1 %age Free space
	DI_GEN_USB2_PC,						///< USB2 %age Free space
	DI_GEN_INT_HOURS,					///< Internal CF hours till recycle
	DI_GEN_FTP_HOURS,					///< FTP hours till recycle
	DI_GEN_USER_VARS_FIRST,				///< User setable variables - first
	DI_GEN_USER_VARS_MAX = (DI_GEN_USER_VARS_FIRST + MAX_V6_USER_VARS),
	// AMS2750 TUS MODE DATA ITEMS
	DI_GEN_AMS2750_MAX_TC,				///< Max TC 
	DI_GEN_AMS2750_MIN_TC,				///< Min TC
	DI_GEN_AMS2750_TC_DIFF,				///< Max diff in TC's 
	DI_GEN_AMS2750_TUS_START_TIME,		///< Start vtime fo TUS
	DI_GEN_AMS2750_TUS_ELAPSED_TIME,	///< Elapsed time into TUS
	DI_GEN_LOGGED_IN_USER,				///< Current logged in user
	// add more types here
	DI_GEN_MAX_ITEMS					///< ** Maximum number of types Always keep at end **
} T_DATA_ITEM_GENERAL;
// Subtypes of general Items available, Flat no subytes.
typedef enum {
	DI_GENTYPE_GENERAL = 0,		// One and only subtype
	DI_GENTYPE_MAX_TYPES
} T_GENERAL_TYPES;
//**Class*********************************************************************
///
/// @brief Totaliser Data Items
/// 
/// This class will provide the support for Totaliser based data items
///
//****************************************************************************
class CDataItemGeneral: public CDataItem {
public:
	CDataItemGeneral();
	void WhoAmI() {
		qDebug("I'm a General Data item ");
		CDataItem::WhoAmI();
	}
	;
	float GetZero() const {
		return m_zero;
	}
	;
	float GetSpan() const {
		return m_span;
	}
	;
	const WCHAR* GetTag() const {
		return m_tag;
	}
	;
	const WCHAR* GetUnits() const {
		return m_units;
	}
	;
	void SetTag(const QString rstrNEW_TAG) {
        WCHAR *pwStr;
        rstrNEW_TAG.toWCharArray(pwStr);
        CStringUtils::SafeWcsCpy(m_tag, pwStr, GROUPINFO_AUTOBATCHNAME_LEN);
	}
	void SetGeneralDetails(float zero, float span, const QString tag, const QString units);
	CNVBasicTimeVar* GetNVHandle() {
		return m_pNV;
	}
	;
	void SetNVHandle(CNVBasicTimeVar *nv) {
		m_pNV = nv;
	}
	;
	void SetValue(float value);
	void SetValue(COMBO_VAR4 value);
private:
	float m_zero;								///< Zero range
	float m_span;								///< Span range
	WCHAR m_tag[ GROUPINFO_AUTOBATCHNAME_LEN];		///< Tag
	WCHAR m_units[MAX_GENERAL_UNITS_LENGTH];	///< Units tag
	CNVBasicTimeVar *m_pNV;						///< Ptr to NV variable area if used, otherwise FALSE
};
//**Class*********************************************************************
///
/// @brief Pen Data Item Type, container class
/// 
/// This class will provide Pen specific access for Pen data items
///
//****************************************************************************
class CDataItemTypeGeneral: public CDataItemTypeContainer {
public:
	CDataItemTypeGeneral();			///< Constructor
	~CDataItemTypeGeneral();			///< Destructor
	T_DI_RETURN CreateItemTable();		///< Create the Data Item table for 
	T_DI_RETURN ApplyConfig();			///< Apply configuration for data table item.
	T_DI_RETURN AddItem(T_DATA_ITEM_GENERAL id, NVVAR_IDENT nvid, QString varName, float zero, float span,
			const QString tag, const QString units);
private:
	QVector<CDataItemGeneral> m_GeneralDataItemArray;
};
#endif // __DATAITEMGENERAL_H__

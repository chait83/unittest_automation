/// @file
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Data Item Table
/// @n Filename: DataItemManager.cpp
/// @n Desc:	 Management for Data Item table abstract from V6 functionality
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//26	Stability Project 1.21.1.3\t 7/2/2011 4:56:38 PM Hemant(HAIL)
// Stability Project: Recorder source has been upgraded from IL
//version of firmware to JF version of firmware.
//25	Stability Project 1.21.1.2 7/1/2011 4:38:13 PM Hemant(HAIL)
// Stability Project: Files has been checked in before the merging
//task. The merging will be done between IL version of firmware and JF
//version of firmware.
//24	Stability Project 1.21.1.1 3/17/2011 3:20:20 PM	Hemant(HAIL)
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//new operator in DEBUG mode only. To detect memory leaks in files, use
//it in preprocessor definition when in debug mode.
//23	Stability Project 1.21.1.0 2/15/2011 3:02:52 PM	Hemant(HAIL)
// File updated during Heap Management. Call to the default behaviour
//of new operator has been commented.
// $
//
// ****************************************************************
#include "V6globals.h"
#include "DataItemManager.h"
#include "StringUtils.h"
#include "BatchManager.h"
#include "PenManager.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
CDataItemManager *CDataItemManager::m_pDataItemInstance = NULL;
//QMutex m_CreationMutex;
QMutex m_CreationMutex;
//**********************************************************************
/// CDataItemManager constructor
///
//**********************************************************************
CDataItemManager::CDataItemManager() {
	// Initialise containers.
	for (int diTypes = 0; diTypes < DI_MAX_DATA_ITEM_TYPES; diTypes++) {
		m_diContainer[diTypes] = NULL;
	}
	// Initialise Attribute Blocks
	for (int attribBlockNum = 0; attribBlockNum < ATTRIB_MAX_BLOCKS; attribBlockNum++) {
		m_attribBlock[attribBlockNum].Visible = TRUE;
		m_attribBlock[attribBlockNum].Flashing = FALSE;
		m_attribBlock[attribBlockNum].FGCol = RGB(255, 255, 255);
		m_attribBlock[attribBlockNum].BGCol = RGB(0, 0, 0);
	}
	// Defaults for globals alarm colours
	m_attribBlock[ATTRIB_ALARM_IN_NOT_ACK].FGCol = ALM_IN_NOT_ACK_COL;
	m_attribBlock[ATTRIB_ALARM_IN_NOT_ACK].BGCol = ALM_FLASH_OFF_COL;
	m_attribBlock[ATTRIB_ALARM_IN_ACK].FGCol = ALM_IN_ACK_COL;
	m_attribBlock[ATTRIB_ALARM_IN_ACK].BGCol = ALM_FLASH_OFF_COL;
	m_attribBlock[ATTRIB_ALARM_OUT_NOT_ACK].FGCol = ALM_OUT_NOT_ACK_COL;
	m_attribBlock[ATTRIB_ALARM_OUT_NOT_ACK].BGCol = ALM_FLASH_OFF_COL;
	m_attribBlock[ATTRIB_ALARM_OUT].FGCol = ALM_OUT_COL;
	m_attribBlock[ATTRIB_ALARM_OUT].BGCol = ALM_FLASH_OFF_COL;
	m_attribBlock[ATTRIB_ALARM_OVERVIEW].FGCol = ALM_IN_ACK_COL;
	m_attribBlock[ATTRIB_ALARM_OVERVIEW].BGCol = ALM_FLASH_OFF_COL;
	// Defaults for globals chart colours
	m_attribBlock[ATTRIB_CHART_NORMAL].FGCol = CHT_GRADS_COL;
	m_attribBlock[ATTRIB_CHART_NORMAL].BGCol = CHT_BACK_NORMAL_COL;
	m_attribBlock[ATTRIB_CHART_NORMAL_ALARM].FGCol = CHT_GRADS_COL;
	m_attribBlock[ATTRIB_CHART_NORMAL_ALARM].BGCol = CHT_BACK_ALM_COL;
	m_attribBlock[ATTRIB_CHART_REPLAY].FGCol = CHT_GRADS_COL;
	m_attribBlock[ATTRIB_CHART_REPLAY].BGCol = CHT_BACK_NORMAL_COL;
	m_attribBlock[ATTRIB_CHART_REPLAY_ALARM].FGCol = CHT_GRADS_COL;
	m_attribBlock[ATTRIB_CHART_REPLAY_ALARM].BGCol = CHT_BACK_ALM_COL;
	m_attribBlock[ATTRIB_CHART_TEXT].FGCol = CHT_TIMESTAMP_COL;
	m_attribBlock[ATTRIB_CHART_TEXT].BGCol = CHT_MARKER_COL;
	m_variablesAvailable = 0;
}
//**********************************************************************
///
/// Instance creation of CDataItemManager singleton
///
/// @return		pointer to single instance of CDataItemManager
///
//**********************************************************************
CDataItemManager* CDataItemManager::GetHandle() {
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;
	if (NULL == m_pDataItemInstance) {
		m_CreationMutex.lock();
		m_pDataItemInstance = new CDataItemManager;
		m_CreationMutex.unlock();
		///TODO
//		V6WarningMessageBox(NULL, L"Failed to release DITABLE mutex", L"Error", MB_OK);
	}
	return (m_pDataItemInstance);
}
//**********************************************************************
///
/// Deletes the instance of the singleton from memory
///
/// @return		Nothing
///
//**********************************************************************
void CDataItemManager::CleanUp() {
	m_DIArray.clear();			// cleanup Item reference to object pointer array
	m_VarNameMap.clear();		// cleanup Variable name to item reference map
	m_EmbdNameMap.clear();	// cleanup Variable name to embed variable map
	// Remove all Data item type containers
	for (int diTypes = 0; diTypes < DI_MAX_DATA_ITEM_TYPES; diTypes++) {
		if (m_diContainer[diTypes] != NULL) {
			qDebug("Dlete data Item Table container %d \n", diTypes);
			delete m_diContainer[diTypes];
		}
	}
	// Delete this singleton
	delete m_pDataItemInstance;
	m_pDataItemInstance = NULL;
}
//**********************************************************************
///
/// Create the Data Item table
/// **Note Data Item cintainers must be added before this call
///use the AddContainer memeber function
///
/// @return		TRUE, if successful, FALSE if failed, Do not continue if failed
///
//**********************************************************************
BOOL CDataItemManager::CreateDataItemTable() {
	BOOL retVal = TRUE;
	T_DI_RETURN containerResult = DI_OKAY;
	// Run through all container types and Create each types Item Table
	for (int diTypes = 0; diTypes < DI_MAX_DATA_ITEM_TYPES; diTypes++) {
		if (m_diContainer[diTypes] != NULL) {
			// Call Create Table of the associated Type
			containerResult = m_diContainer[diTypes]->CreateItemTable();
			if (containerResult != DI_OKAY) {
				qDebug("ERROR: CreateItemTable for container type %d failed \n", diTypes);
				///@TODO sort out this error handling
				retVal = FALSE;
				break;
			}
			// Add number of exposed variables to running total
			if (m_diContainer[diTypes]->GetTotalVars() > 0) {
				m_variablesAvailable += m_diContainer[diTypes]->GetTotalVars();
			}
		}
	}
	// Build lookup Map for script services other variable name accesses
	if (retVal == TRUE)
		retVal = BuildMap();
	// Build the embedded varaible map (these are additional variables that are not available in the Data Item Table)
	m_EmbdNameMap["TIME"] = reinterpret_cast<void*>(EMBED_VAR_TIME);
	m_EmbdNameMap["DATE"] = reinterpret_cast<void*>(EMBED_VAR_DATE);
	m_EmbdNameMap["TD"] = reinterpret_cast<void*>(EMBED_VAR_TIMEDATE);
	m_EmbdNameMap["NAME"] = reinterpret_cast<void*>(EMBED_VAR_NAME);
	m_EmbdNameMap["ID"] = reinterpret_cast<void*>(EMBED_VAR_ID);
	m_EmbdNameMap["SERIAL"] = reinterpret_cast<void*>(EMBED_VAR_SERIAL);
	m_EmbdNameMap["MAX"] = reinterpret_cast<void*>(EMBED_VAR_REP_MAX);
	m_EmbdNameMap["MIN"] = reinterpret_cast<void*>(EMBED_VAR_REP_MIN);
	m_EmbdNameMap["AVE"] = reinterpret_cast<void*>(EMBED_VAR_REP_AVE);
	m_EmbdNameMap["TOT"] = reinterpret_cast<void*>(EMBED_VAR_REP_TOT);
	m_EmbdNameMap["MAT"] = reinterpret_cast<void*>(EMBED_VAR_REP_MAT);
	m_EmbdNameMap["MIT"] = reinterpret_cast<void*>(EMBED_VAR_REP_MIT);
	m_EmbdNameMap["STM"] = reinterpret_cast<void*>(EMBED_VAR_REP_STM);
	return retVal;
}
//**********************************************************************
///
/// Apply configuration changes/start-up to the Data item table
///
/// @return		TRUE, if successful, FALSE if failed, Do not continue if failed
///
//**********************************************************************
BOOL CDataItemManager::ApplyConfig() {
	BOOL retVal = TRUE;
	T_DI_RETURN containerResult = DI_OKAY;
	// Run through all container types and Apply changes
	for (int diTypes = 0; diTypes < DI_MAX_DATA_ITEM_TYPES; diTypes++) {
		if (m_diContainer[diTypes] != NULL) {
			// Call Apply config of the associated Type
			containerResult = m_diContainer[diTypes]->ApplyConfig();
			if (containerResult != DI_OKAY) {
				qDebug("ERROR: ApplyConfig for container type %d failed \n", diTypes);
				///@TODO sort out this error handling
				retVal = FALSE;
				break;
			}
		}
	}
	return retVal;
}
//**********************************************************************
//	BOOL ApplyLayoutConfig()
///
/// Apply Layout configuration changes/start-up to the Data item table
///
/// @return		TRUE always
///
//**********************************************************************
BOOL CDataItemManager::ApplyLayoutConfig(const T_PLAYOUT ptLAYOUT) {
	BOOL bRetVal = TRUE;
	if (ptLAYOUT != NULL) {
		//blockInfo
		// Setup the global attribute colours
		m_attribBlock[ATTRIB_ALARM_IN_NOT_ACK].FGCol = ptLAYOUT->AlmInNAckFCol;
		m_attribBlock[ATTRIB_ALARM_IN_NOT_ACK].BGCol = ptLAYOUT->AlmInNAckBCol;
		m_attribBlock[ATTRIB_ALARM_IN_ACK].FGCol = ptLAYOUT->AlmInAckFCol;
		m_attribBlock[ATTRIB_ALARM_IN_ACK].BGCol = ptLAYOUT->AlmInAckBCol;
		m_attribBlock[ATTRIB_ALARM_OUT_NOT_ACK].FGCol = ptLAYOUT->AlmOutNAckFCol;
		m_attribBlock[ATTRIB_ALARM_OUT_NOT_ACK].BGCol = ptLAYOUT->AlmOutNAckBCol;
		m_attribBlock[ATTRIB_ALARM_OUT].FGCol = ptLAYOUT->AlmOutFCol;
		m_attribBlock[ATTRIB_ALARM_OUT].BGCol = ptLAYOUT->AlmOutBCol;
		m_attribBlock[ATTRIB_ALARM_OVERVIEW].FGCol = ptLAYOUT->AlmInAckFCol;
		m_attribBlock[ATTRIB_ALARM_OVERVIEW].BGCol = ptLAYOUT->AlmInAckBCol;
		// Defaults for globals chart colours
		m_attribBlock[ATTRIB_CHART_NORMAL].FGCol = ptLAYOUT->ChartNormalFCol;
		m_attribBlock[ATTRIB_CHART_NORMAL].BGCol = ptLAYOUT->ChartNormalBCol;
		m_attribBlock[ATTRIB_CHART_NORMAL_ALARM].FGCol = ptLAYOUT->ChartNormalFCol;
		m_attribBlock[ATTRIB_CHART_NORMAL_ALARM].BGCol = ptLAYOUT->ChartAlarmBCol;
		m_attribBlock[ATTRIB_CHART_REPLAY].FGCol = ptLAYOUT->ChartReplayFCol;
		m_attribBlock[ATTRIB_CHART_REPLAY].BGCol = ptLAYOUT->ChartReplayBCol;
		m_attribBlock[ATTRIB_CHART_REPLAY_ALARM].FGCol = ptLAYOUT->ChartReplayFCol;
		m_attribBlock[ATTRIB_CHART_REPLAY_ALARM].BGCol = ptLAYOUT->ChartRplAlmBCol;
		m_attribBlock[ATTRIB_CHART_TEXT].FGCol = ptLAYOUT->ChartTextFCol;
		m_attribBlock[ATTRIB_CHART_TEXT].BGCol = ptLAYOUT->ChartTextBCol;
	} else {
		qDebug("ERROR: Layout block NULL");
//		DebugBreak();
	}
	return bRetVal;
}
//**********************************************************************
/// Build a Map to lookup variable names and extract a reference
/// the reference to be held by Script Services for quick DataItem
/// lookup (SS cannot hold a CadatItem * for portability)
/// A lookup table for reference to CDataItem * is also generated
///
/// @return		TRUE, table built successfully, FALSE if failed
///
//**********************************************************************
BOOL CDataItemManager::BuildMap() {
	BOOL retVal = TRUE;
	CDataItem *DIObj = NULL;
	// Run through all types and add up the total number of variables to be
	// exposed to the Script services via Varibale names
	if (m_variablesAvailable > 0) {
		if (m_variablesAvailable < MAX_VARIABLES) {
			int masterIndex = 0;
			// Setup an array to hold ptr to DataItems from an indexed reference number
			m_DIArray.reserve(m_variablesAvailable);
			// Run through each Data Type used in the table
			for (int diTypes = 0; diTypes < DI_MAX_DATA_ITEM_TYPES; diTypes++) {
				// If container for type exists, we need to include these items in table
				if (m_diContainer[diTypes] != NULL) {
					// Does the conatiner have any data items which are accessable by variable name
					if (m_diContainer[diTypes]->GetTotalVars() > 0) {
						// Yes, so run through and find all of these items
						for (int itemNo = 0; itemNo < m_diContainer[diTypes]->GetTotalItems(); itemNo++) {
							// Get pointer into data item, check if valid and a variable
							DIObj = m_diContainer[diTypes]->GetDataItemPtr(itemNo);
							if (DIObj != NULL) {
								if (DIObj->IsDataItemAVariable()) {
									// Add the variable name to the map as the key, the data is a void pointer
									// but we want to use this as an reference, so cast in the index
									m_VarNameMap[DIObj->GetVariableName()] = reinterpret_cast<void*>(masterIndex);
									// Assign the DataItem object to the same ref as the Map lookup will provide
									m_DIArray[masterIndex] = reinterpret_cast<void*>(DIObj);
									masterIndex++;
								}
							}
						}
					}
				}
			}
		} else {
			qDebug("Exceeded number of variables DIT too big\n");
			retVal = FALSE;
		}
	}
	return retVal;
}
//****************************************************************************
/// Add a conatiner instance to the Data Item Table
///
/// @param[in] - type, Type of data item must be a T_DATA_ITEM_TYPE
/// @param[in] - containRef, ptr to instance of CDataItemTypeContainer derived class
///
/// @return - nothing
///
//****************************************************************************
void CDataItemManager::AddContainer(T_DATA_ITEM_TYPE type, CDataItemTypeContainer *containRef) {
	if (type < DI_MAX_DATA_ITEM_TYPES)
		m_diContainer[type] = containRef;
}
//****************************************************************************
/// Get a pointer to an attribute block structure, if the block requested is
///invalid then attribute block 0 (never used by op panel) will be returned
///	 to avoid NULL ptr access checks in oppanel as speed is crucial, hence why
///direct ptr access is allowed.
///
/// @param[in] - blockNum, number of attribute block to get
///
/// @return pointer to attribute block structure , or ptr to attribute block 0 if
///				blockNum is out of bounds
//****************************************************************************
T_PATTRIB_BLOCK CDataItemManager::attribBlockPtr(USHORT blockNum) {
	T_PATTRIB_BLOCK pBlk = &m_attribBlock[0];	// Return block 0 if out of bounds
	if (blockNum < ATTRIB_MAX_BLOCKS) {
		pBlk = &m_attribBlock[blockNum];		// return pointer to valid block
	} else {
		qDebug("ERROR: Attrib block requuested (%d) out of bounds \n", blockNum);
	}
	return pBlk;
}
//****************************************************************************
/// Look up a reference for a variable name, Wide character for generic use
///
/// @param[in] - pvarName, Variable name to get reference for
///
/// @return - reference to a DataItem, use only if not a REF_ERROR
///
//****************************************************************************
int CDataItemManager::LookUp(const QString pvarName) {
	int DITRef = REF_ERROR;
	void *pRef;
// WCHAR varname[100]; // = pvarName;
// wcpcpy( varname,pvarName);
	if (m_VarNameMap.contains(pvarName) == TRUE) {
		// Had to hijack the void * extra data in the map as the index, convert back to int
		pRef = m_VarNameMap.value(pvarName);
		DITRef = reinterpret_cast<long>(pRef);
	}
	return DITRef;
}
//****************************************************************************
/// Fast but potentially unsafe CDataItem access
/// This will return a ptr to a DataItem from the specified data item reference
/// from a valid retun of the LookUp method.
///
/// @param[in] - lookUpRef, a reference returned from a variable lookup using LookUp method
///
/// @return - pointer to data item.
///
//****************************************************************************
CDataItem* CDataItemManager::GetDataItemPtr(int lookUpRef) {
	CDataItem *pDataItem = reinterpret_cast<CDataItem*>(m_DIArray[lookUpRef]);
	return pDataItem;
}
//****************************************************************************
/// Get a pointer to an attribute block structure, if the block requested is
///
/// @param[in] - type, Type of data item
/// @param[in] - ref, Reference of Data Item
/// @param[in] - instance, Instance of Data Item
///
/// @return - pointer to data item, if data item or container does not exist NULL will be returned
///
//****************************************************************************
CDataItem* CDataItemManager::GetDataItemPtr(T_DATA_ITEM_TYPE type, USHORT ref, USHORT instance) {
	CDataItem *pDataItem = NULL;
	if (GetContainerPtr(type) != NULL) {
		pDataItem = GetContainerPtr(type)->GetDataItemPtr(ref, instance);
	} else {
		qDebug("ERROR: Data Item container type %d does not exist \n", type);
	}
	return pDataItem;
}
//****************************************************************************
/// Expand a string with inline embedded values
/// embedded values are enclosed in double square brackets [[xxx.t]] where xxx is the data item variable
/// and t is the type ( V = value, U = Units, T = TAG, S = Span, Z = Zero ) so [[p1.v]] would display value of P1
///
/// @param[in] - srcString, reference to source string to convert
/// @param[out] - destString, destination for translated string
/// @param[in] - destLength, max size of destination string ( -1 means no limit )
/// @param[out] - ErrorString, if FALSE returned by this call , ErrorString will conatin the error in the text
///	@param[in]	- const USHORT usGROUP_INDEX - The pen group index, zero based
///
/// @return - TRUE if translation ok, otherwise false if error in embedded variables (see ErrorString for details)
///
//****************************************************************************
BOOL CDataItemManager::ExpandEmbeddedValues(const QString &srcString, QString &destString, int destLength,
		QString &ErrorString, const USHORT usGROUP_INDEX /* = 0 */) {
	BOOL translationOK = TRUE;
	int sourcePos = 0;
	int embeddedPos = 0;
	BOOL noMoreEmbedded = FALSE;
	int sourceLength = srcString.size();	//
	destString = "";							// Cleardown the destination string
	do {
		// Try and find the first embedded varible
		embeddedPos = srcString.indexOf("[[", sourcePos);
		if (embeddedPos == -1) {
			noMoreEmbedded = TRUE;
		} else {
			// Copy in the string up to the point of embedded variable
			destString += srcString.mid(sourcePos, embeddedPos - sourcePos);
			sourcePos = embeddedPos + 2;		// Move sourcepos beyond embedded var including the opening delimter [[
			embeddedPos = srcString.indexOf("]]", sourcePos);
			if (embeddedPos == -1) {
				// No end of embedded variable
				// ERROR warn user
				ErrorString = "Could not find closing ]] for embedded variable.";
				translationOK = FALSE;
			} else {
				// extract embedded var
				QString inlineData = srcString.mid(sourcePos, embeddedPos - sourcePos);
				inlineData = inlineData.trimmed();			// Remove trailing whitespace
				inlineData = inlineData.toUpper();		// Make Uppercase
				int typeLocation = inlineData.indexOf(".", 0);
				if (typeLocation == -1) {
					// "." not found so no type specified on variable - invalid embedded variable
					// Error misforded embedde var as
					ErrorString = "Misformed embedded variable no . found between [[ ]]";
					translationOK = FALSE;
				} else {
					// variable type found, so extract the type
					//WCCHAR to QChar
					QChar typeIdent = (inlineData.at(typeLocation + 1));	// Extra variable type ident
					sourcePos = embeddedPos + 2;// Move sourcepos beyond embedded var including the closing delimter ]]
					QString variableName = inlineData.left(typeLocation);
					// Translate the variable into the data it represents
#ifndef DOCVIEW
#ifndef V6IOTEST
#ifndef TTR6SETUP
					// check for group counts - this can be removed once the translate function below can cope
					// with group counters
					if (variableName == "GC") {
						CBatchManager *pkBatchManager = CBatchManager::Instance();
						QString strCount("");
						T_PGENERALCONFIG ptGeneralData = pSETUP->GetGeneralSetupConfig()->GetSystemGeneralBlock(
								CONFIG_COMMITTED);
						if (ptGeneralData->Batch.GroupInfo[usGROUP_INDEX].ZeroPadNumber == TRUE) {
							QString zeroPaddedString, countLimit;
							// Generate a full pre-padded string with count number
//						zeroPaddedString = QString::asprintf("00000000000000000000%u", pkBatchManager->GetLocalBatchCount( usGROUP_INDEX ) );
							zeroPaddedString = QString::asprintf("00000000000000000000%u",
									pkBatchManager->GetLocalBatchCount(usGROUP_INDEX));
							// get the size of the rollover count limit, to determine count field size
							countLimit = QString::asprintf("%lu",
									ptGeneralData->Batch.GroupInfo[usGROUP_INDEX].GroupCtrRoll);
							// trim right the count value and any spare leading 0's
							strCount = zeroPaddedString.right(countLimit.size());
						} else {
							strCount = QString::asprintf("%u", pkBatchManager->GetLocalBatchCount(usGROUP_INDEX));
						}
						destString += strCount;
					} else if (variableName.left(3) == "PRP") {
						// PRP - pen reports
						// syntax PRPtttxynn	where	ttt = MAX, MIN, AVE or TOT
						//								x = C - current or L - Last
						//								y = H-hour, D-day, W-week, M-month
						//								nn = Pen number 1 to 96
						QString repTypeStr;
						repTypeStr = variableName.mid(3, 3);
						void *ptypeRef;
						int repType = EMBED_VAR_NONE;
//WCHAR strname[100];
////@ToDo-string conversion
//const wchar_t*repTypeStrw = repTypeStr.toStdWString().c_str();
//wcpcpy(strname,repTypeStrw);
						if (m_EmbdNameMap.contains(repTypeStr) == TRUE) {
							// Had to hijack the void * extra data in the map as the index, convert back to int
							ptypeRef = m_EmbdNameMap.value(repTypeStr);
							// TODO:typecasting
							repType = static_cast<T_EMBED_VARIABLES>(reinterpret_cast<intptr_t>(ptypeRef));
						}
						if ((repType != EMBED_VAR_NONE) && (repType >= EMBED_VAR_REP_MAX)
								&& (repType <= EMBED_VAR_REP_STM)) {
							// Valid type being requested, extract set type (current or last)
							T_REPORT_HISTORY reportSet = REPORT_HISTORY;
							if (variableName.at(6) == EMBED_REP_SET_LAST) {
								reportSet = LAST_REPORT;		// Last report requested
							} else if (variableName.at(6) == EMBED_REP_SET_CURRENT) {
								reportSet = WORKING_REPORT;		// Current report requested
							}
							// If valid report set then proceed to parse rest of variable
							if (reportSet < REPORT_HISTORY) {
								// Valid report set being requested, extract the pen number
								QString penNumberStr;
								penNumberStr = variableName.mid(8, 2);	// Extract Pen Number
								USHORT penNumber = static_cast<USHORT>(penNumberStr.toUShort() - 1);
								// Pen number extracted if valid, then get the required period
								if (penNumber < V6_MAX_PENS) {
									QChar period = variableName.at(7);		// Extract period
									T_REPORT_PERIOD reportPeriod = RP_MAX;
									switch (period.digitValue()) {
									case EMBED_REP_PERIOD_HOUR:
										reportPeriod = RP_HOUR;
										break;
									case EMBED_REP_PERIOD_DAY:
										reportPeriod = RP_DAY;
										break;
									case EMBED_REP_PERIOD_WEEK:
										reportPeriod = RP_WEEK;
										break;
									case EMBED_REP_PERIOD_MONTH:
										reportPeriod = RP_MONTH;
										break;
									}
									// Period extracted, if valid then generate embedded var
									if (reportPeriod < RP_MAX) {
										CPenManager *pPenManager = CPenManager::GetHandle();
										float reportResult = 0;
										LONGLONG reportTime;
										// Get the value depending on the type
										// Create a dummy format for any floating point translations
										T_NUMFORMAT numasprintf;
										memset(&numasprintf, 0, sizeof(T_NUMFORMAT));
										numasprintf.Auto = TRUE;
										// Embed the floating point value returned from reports
										QString varString;
										//WCHAR timebuff[100]
										char *timebuff;
										// Get value
										switch (repType) {
										case EMBED_VAR_REP_MAX:
											reportResult = pPenManager->GetReportMax(penNumber, ZERO_BASED, reportSet,
													reportPeriod, reportTime);
											varString = CStringUtils::asprintfFloat(numasprintf, reportResult);
											break;
										case EMBED_VAR_REP_MIN:
											reportResult = pPenManager->GetReportMin(penNumber, ZERO_BASED, reportSet,
													reportPeriod, reportTime);
											varString = CStringUtils::asprintfFloat(numasprintf, reportResult);
											break;
										case EMBED_VAR_REP_AVE:
											reportResult = pPenManager->GetReportAve(penNumber, ZERO_BASED, reportSet,
													reportPeriod);
											varString = CStringUtils::asprintfFloat(numasprintf, reportResult);
											break;
										case EMBED_VAR_REP_TOT:
											reportResult = pPenManager->GetReportTot(penNumber, ZERO_BASED, reportSet,
													reportPeriod);
											varString = CStringUtils::asprintfFloat(numasprintf, reportResult);
											break;
										case EMBED_VAR_REP_MAT: {
											reportResult = pPenManager->GetReportMax(penNumber, ZERO_BASED, reportSet,
													reportPeriod, reportTime);
											CTVtime theTime(reportTime);
											theTime.TimeToStringShort(timebuff);
											varString = QString::asprintf("%s", timebuff);
											break;
										}
										case EMBED_VAR_REP_MIT: {
											reportResult = pPenManager->GetReportMin(penNumber, ZERO_BASED, reportSet,
													reportPeriod, reportTime);
											CTVtime theTime(reportTime);
											theTime.TimeToStringShort(timebuff);
											varString = QString::asprintf("%s", timebuff);
											break;
										}
										case EMBED_VAR_REP_STM: {
											reportTime = pPenManager->GetReportStartTime(penNumber, ZERO_BASED,
													reportSet, reportPeriod);
											CTVtime theTime(reportTime);
											theTime.TimeToStringShort(timebuff);
											varString = QString::asprintf("%s", timebuff);
											break;
										}
										}
										destString += varString;
									}
								}
							}
						}
					} else
#endif
#endif
#endif
					if (TranslateEmbeddedIdent(variableName, typeIdent, ErrorString) == FALSE) {
						// Invalid variable or type, ErrorString contains details
						translationOK = FALSE;
					} else {
						// Translation ok, Add translated embedded varibale to destination string
						destString += variableName;
					}
				}
			}
		}
	} while (noMoreEmbedded == FALSE && translationOK == TRUE);	// Repeat which there are no errors and more variables to translate
	// Copy in the remaining text from source
	destString += srcString.right(sourceLength - sourcePos);
	// Check if the translated string exceeds the maximum length, if so truncate to max length
	if ((destLength != -1) && (destString.size() > destLength)) {
		destString = destString.left(destLength);
	}
	return translationOK;
}
//****************************************************************************
/// Translate embedded identifier into the data required
///
/// @param[in,out] - varString, data item varibale in, and translated result out
/// @param[out] - type, type of data for the variable required
/// @param[out] - ErrorString, if FALSE returned by this call , ErrorString will conatin the error in the text
///
/// @return - TRUE if successful, otherwise FALSE (check ErrorString for reason )
///
//****************************************************************************
BOOL CDataItemManager::TranslateEmbeddedIdent(QString &varString, QChar type, QString &ErrorString) {
	BOOL varOK = TRUE;
	// First serach for single type reference, these are not Data items
	// and are from a short list
	int singleItem = EMBED_VAR_NONE;
	void *psingleRef;
// WCHAR convstring[100];
// //to do:- converting Qstring to Wchar
// const wchar_t*varStringw = varString.toStdWString().c_str();
// wcscpy(convstring,varStringw);
	if (m_EmbdNameMap.contains(varString) == TRUE) {
		// Had to hijack the void * extra data in the map as the index, convert back to int
		psingleRef = m_EmbdNameMap.value(varString);
		//@todo; typecasting
		singleItem = static_cast<T_EMBED_VARIABLES>(reinterpret_cast<intptr_t>(psingleRef));
	}
	// Is this a single reference?
	if (singleItem == EMBED_VAR_NONE) {
		// No, so it might be a data Item, perform the data item lookup
		//varstring to convstring
		int ditRef = LookUp(varString);
		if (ditRef == REF_ERROR) {
			// Variable does not exist in data item table
			ErrorString = QString("Error, Variable does not exist %1").arg(varString);
			varOK = FALSE;
		} else {
			// Variable Identified ok, get handle on data item
			CDataItem *pDataItem = (CDataItem*) pGlbDIT->GetDataItemPtr(ditRef);
			// Create a dummy format for any floating point translations
			T_NUMFORMAT numasprintf;
			memset(&numasprintf, 0, sizeof(T_NUMFORMAT));
			numasprintf.Auto = TRUE;
			// Depending on type translate the variable and type into the required data
			switch (type.unicode()) {
			case EMBED_TYPE_VALUE:		// Relatime value
			{
				varString = CStringUtils::asprintfFloat(numasprintf, pDataItem->GetFPValue());
				break;
			}
			case EMBED_TYPE_TAG:		// Tag text
			{
				varString = QString::asprintf("%ls", pDataItem->GetTag());
				break;
			}
			case EMBED_TYPE_ZERO:		// Zero value
			{
				varString = CStringUtils::asprintfFloat(numasprintf, pDataItem->GetZero());
				break;
			}
			case EMBED_TYPE_SPAN:		// Span value
			{
				varString = CStringUtils::asprintfFloat(numasprintf, pDataItem->GetSpan());
				break;
			}
			case EMBED_TYPE_UNITS:		// Units text
			{
				varString = QString::asprintf("%ls", pDataItem->GetUnits());
				break;
			}
			default: {
				ErrorString = QString("No such type %1 for variable %2").arg(type).arg(varString);
				varOK = FALSE;
				break;
			}
			}
		}
	} else {
		// It is an embedded single type reference
		switch (singleItem) {
		case EMBED_VAR_TIME:		// Relatime value
		{
			QDateTime currentDateTime = QDateTime::currentDateTime();
			QString timeString = currentDateTime.toString("HH:mm:ss");
			varString = timeString;
			break;
		}
		case EMBED_VAR_DATE:		// Relatime value
		{
			QDateTime currentDateTime = QDateTime::currentDateTime();
			QString dateString = currentDateTime.toString("dd MMM yy");
			varString = dateString;
			break;
		}
		case EMBED_VAR_TIMEDATE:		// Relatime value
		{
			QDateTime currentDateTime = QDateTime::currentDateTime();
			QString timeString = currentDateTime.toString("HH:mm:ss");
			QString dateString = currentDateTime.toString("dd MMM yy");
			varString = timeString + " - " + dateString;
			break;
		}
		case EMBED_VAR_NAME:		// Relatime value
		{
			varString = pSYSTEM_INFO->GetGeneralConfig()->Name;
			break;
		}
		case EMBED_VAR_ID:		// Relatime value
		{
			varString = QString::number(pSYSTEM_INFO->GetGeneralConfig()->ID, 10).rightJustified(4, '0');
			break;
		}
		case EMBED_VAR_SERIAL:		// Relatime value
		{
			varString = QString::number(pSYSTEM_INFO->GetSerialNumber(), 10).rightJustified(6, '0');
			break;
		}
		default: {
			QString errorString = "No such variable " + varString;
			varOK = false;
			break;
		}
		}
	}
	return varOK;
}

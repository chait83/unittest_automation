/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	Data Item Table
/// @n Filename: DataItemAlarm.h
/// @n Desc:	Alarm specific details for Data item table
///
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//13Stability Project 1.10.1.1 7/2/2011 4:56:37 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//version of firmware to JF version of firmware.
//12Stability Project 1.10.1.0 7/1/2011 4:27:26 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//task. The merging will be done between IL version of firmware and JF
//version of firmware. 
//11V6 Firmware 1.10 11/13/2006 7:18:24 PMAndy KassellAdd
//Rate of change realtime value for Pen And Alarm almrt[x,y]
//10V6 Firmware 1.9 12/2/2005 2:21:29 PMAndy KassellAdd
//accessor to Alarm configuration
// $
//
// ****************************************************************
#ifndef __DATAITEMALARM_H__
#define __DATAITEMALARM_H__
#include "DataItemBase.h"
#include "DataItemPen.h"
#include <QVector>
#include "V6Config.h"
//**Class*********************************************************************
///
/// @brief Pen Data Items
/// 
/// This class will provide the support for Pen based data items
///
//****************************************************************************
class CDataItemAlarm: public CDataItem {
public:
	void WhoAmI() {
		qDebug("I'm an Alarm ");
		WhoAmI();
	}
	;
	CDataItemAlarm();
	float GetZero() const {
		return m_pPenDIT->GetZero();
	}
	;
	float GetSpan() const {
		return m_pPenDIT->GetSpan();
	}
	;
	const WCHAR* GetTag() const {
		return m_pAlarmCfg->Tag;
	}
	;
	const WCHAR* GetUnits() const {
		return m_pPenDIT->GetUnits();
	}
	;
	COLORREF* GetColour();
	T_PSCALEINFO GetScaleInfo() {
		return m_pPenDIT->GetScaleInfo();
	}
	;
	T_PLINESTYLE GetLineInfo() {
		return m_pPenDIT->GetLineInfo();
	}
	;
	USHORT GetAlarmType() {
		return m_pAlarmCfg->Type;
	}
	;		///< Return the type of alarm
	int GetAlarmNumber() {
		return m_alarmNumber;
	}
	;			///< Return the alarm number 0 to 5
	USHORT GetAlarmStatus() {
		return m_AlarmStatus;
	}
	;			///< Return number of active alarms
	void SetAlarmStatus(USHORT status) {
		m_AlarmStatus = status;
	}
	;			///< Set alarm status 	
	void SetPenDITPtr(CDataItemPen *pPenDIT) {
		m_pPenDIT = pPenDIT;
	}
	;
	void SetAlarmNumber(int alarmNumber) {
		m_alarmNumber = alarmNumber;
	}
	;
	void SetAlarmConfig();			///< Do Local configuration changes on Alarm
	BOOL IsAlarmLevelUser();
	T_PALARM GetAlarmConfig() {
		return m_pAlarmCfg;
	}
	;
	void SetCounter(ULONG count) {
		m_Counter = count;
	}
	;
	ULONG GetCounter() {
		return m_Counter;
	}
	;
	void SetRateOfChange(float currRate) {
		m_currentRateOfChange = currRate;
	}
	;
	float GetRateOfChange() {
		return m_currentRateOfChange;
	}
	;
private:
	CDataItemPen *m_pPenDIT;		///< Pointer to the Pen data item, base reference for the Alarm.
	T_PALARM m_pAlarmCfg;	///< Pointer to the Alarm configuration in the CMM
	int m_alarmNumber;				///< Alarm number 0-5 for self reference
	BOOL m_AlarmStatus;	///< Alarm overview, TRUE if any alarm on the Pen is "in alarm" or "out of alarm" but not acknowledged
	ULONG m_Counter;				///< Copy of the alarm counter
	float m_currentRateOfChange;	///< Current rate of change for rate of change alarm
};
//**Class*********************************************************************
///
/// @brief Pen Data Item Type, container class
/// 
/// This class will provide Pen specific access for Pen data items
///
//****************************************************************************
class CDataItemTypeAlarm: public CDataItemTypeContainer {
public:
	CDataItemTypeAlarm();			///< Constructor
	~CDataItemTypeAlarm();			///< Destructor
	T_DI_RETURN CreateItemTable();		///< Create the Data Item table for 
	T_DI_RETURN ApplyConfig();			///< Apply configuration for data table item.
	T_DI_RETURN LinkPenTypes(CDataItemTypePen *pLinkPenType);		///< Link Pen into this Type as it is a dependecy
private:
	QVector<CDataItemAlarm> m_AlarmDataItemArray;
};
#endif // __DATAITEMALARM_H__

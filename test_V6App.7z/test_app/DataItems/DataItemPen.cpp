/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Data Item Table
/// @n Filename: DataItemPen.cpp
/// @n Desc:	 Pen specific details for Data item table
///
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//33Stability Project 1.28.1.3 7/2/2011 4:56:38 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//version of firmware to JF version of firmware.
//32Stability Project 1.28.1.2 7/1/2011 4:38:13 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//task. The merging will be done between IL version of firmware and JF
//version of firmware. 
//31Stability Project 1.28.1.1 3/17/2011 3:20:20 PMHemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//new operator in DEBUG mode only. To detect memory leaks in files, use
//it in preprocessor definition when in debug mode.
//30Stability Project 1.28.1.0 2/15/2011 3:02:53 PMHemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//of new operator has been commented.
// $
//
// ****************************************************************
#include "V6globals.h"
#include "DataItemPen.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
//=============================================================================
// CDataItemTypePen Class
//=============================================================================
//****************************************************************************
/// CDataItemTypePen Constructor
//****************************************************************************
CDataItemTypePen::CDataItemTypePen() {
}
//****************************************************************************
/// CDataItemTypePen Destructor
//****************************************************************************
CDataItemTypePen::~CDataItemTypePen() {
	m_penDataItemArray.clear();
}
//****************************************************************************
/// CreateItemTable overridden method, create the item table. 
/// responisibility to create the memory for Data items, and initialise the table
///
/// @return - T_DI_RETURN status of method 
///
//****************************************************************************
T_DI_RETURN CDataItemTypePen::CreateItemTable() {
	T_DI_RETURN retVal = DI_OKAY;
	//qDebug("Create Data Item table for a %d Pens\n",V6_MAX_PENS);
	// Stage 1, Create the memory space for the DataItems
	m_penDataItemArray.resize(V6_MAX_PENS * DI_PEN_MAX_TYPES);
	SetDataItemInfo(DI_PEN, DI_PEN_MAX_TYPES, V6_MAX_PENS);		// Type Pen, 1 sub type and Max Pens instance.
	// Stage 2, initialise the data items
	// Add standard Pens
	WCHAR varName[MAX_VARNAME_LEN];
	int penCount = 0;
	for (penCount = 0; penCount < V6_MAX_PENS; penCount++) {
		swprintf(varName, MAX_VARNAME_LEN, L"P%d", penCount + 1);
		AddDataItem(&m_penDataItemArray[penCount], DI_PEN_READING, penCount, QString::fromWCharArray(varName),
				DI_FLOAT);
		m_penDataItemArray[penCount].SetPenConfiguration(NULL);
	}
	// Add replay pens Max and Min, these will dynamically change depending on replay screen being shown
	for (penCount = 0; penCount < MAX_MM_REPLAY_PENS; penCount++) {
		AddDataItem(&m_penDataItemArray[V6_MAX_PENS + penCount], DI_PEN_MM_REPLAY, penCount, NULL, DI_FLOAT);
		m_penDataItemArray[V6_MAX_PENS + penCount].SetPenConfiguration(NULL);
	}
	// Set the dummy Pen Data Item
	SetDummyDataItem(new CDataItemPen());
	return retVal;
}
//****************************************************************************
/// ApplyConfig overloaded method, handle all configuration changes and startup
/// Will be called on startup when configuration in place and every time
/// the current configuration changes.
///
/// @return - T_DI_RETURN status of method 
///
//****************************************************************************
T_DI_RETURN CDataItemTypePen::ApplyConfig() {
	T_DI_RETURN retVal = DI_OKAY;
	// Set the configuration into each pen on change
	int penCount = 0;
	for (penCount = 0; penCount < V6_MAX_PENS; penCount++) {
		m_penDataItemArray[penCount].SetupCMMConfig(penCount);
		// perform any pen configuration required
		m_penDataItemArray[penCount].SetPenConfig();
	}
	// Default the Replay pens
	for (penCount = 0; penCount < MAX_REPLAY_PENS; penCount++) {
		m_penDataItemArray[penCount + V6_MAX_PENS].SetReplayPenConfig(penCount);				// Set Min replay Pen
		m_penDataItemArray[penCount + MAX_REPLAY_PENS + V6_MAX_PENS].SetReplayPenConfig(penCount);// Set Max replay Pen
	}
	// Setup the dummy data item to look at the dummy pen
	reinterpret_cast<CDataItemPen*>(GetDummyDataItem())->SetPenConfiguration(
			pGlbSetup->GetPenSetupConfig()->GetDummyPen());
	reinterpret_cast<CDataItemPen*>(GetDummyDataItem())->SetPenConfig();
	return retVal;
}
//=============================================================================
// CDataItemPen Class
//=============================================================================
//****************************************************************************
/// CDataItemTypePen Constructor
//****************************************************************************
CDataItemPen::CDataItemPen() {
	SetAlarmStatus(0);
	m_zero = 0;
	m_span = 0;
}
//****************************************************************************
/// Setup the DIT enabled flags for this pen
///
/// @return - nothing 
///
//****************************************************************************
void CDataItemPen::SetPenConfig() {
	// Check if the Pen is enabled, if so set DIT enabled flag accoringly
	BOOL enabled = FALSE;
	if (m_pPenConfig->Enabled == TRUE) {
		// If Pen is enabled, reflect in DIT
		enabled = TRUE;
		m_PenColour = m_pPenConfig->Style.Colour;		// Use the pen colour from config
	} else {
		m_PenColour = GlbDITDisabaledColour;			// Set disabled colour if not enabled
	}
	SetEnabled(enabled);		// Set the enabled status of the pen
	// Set correct Zero and Span for Pens, this will depend on Log scales
	if (m_pPenConfig->Scale.LogScale == TRUE) {
		// Log scales set so use decades as scale
		SetZeroAndSpan(m_pPenConfig->Scale.StartDecade,
				static_cast<float>(m_pPenConfig->Scale.StartDecade + m_pPenConfig->Scale.NumDecades));
	} else {
		// Log scales not use, so use standard scale
		SetZeroAndSpan(m_tScaleInfo.Zero, m_tScaleInfo.Span);
	}
	// Setup reverse scale check flag
	if (GetSpan() < GetZero())
		m_reverseScale = TRUE;
	else
		m_reverseScale = FALSE;
}
//****************************************************************************
/// Set Pen Configuration from required index, if pen is not available then
/// set as dummy pen
///
/// @param[in] - penIndex, Zero based index of Pen to set as 
///
/// @return - nothing 
//****************************************************************************
void CDataItemPen::SetupCMMConfig(int penIndex) {
	T_PPEN pPenFromCMM = NULL;
	// Access the default configuration 
	// Is the pen actually available in the system (i.e. has an analogue or is an extra pen ) 
	if ( pSYSTEM_INFO->IsPenAvailable(penIndex, ZERO_BASED) == TRUE) {
		// Yes so get configuration from CMM
		pPenFromCMM = pGlbSetup->GetPenSetupConfig()->GetPen(penIndex, ZERO_BASED, CONFIG_COMMITTED);
	}
	// If pen data from CMM is NULL set the pen to a dummy set of information
	if (pPenFromCMM == NULL) {
		// Pen not in CMM current setup config so set to dummy to avoid direct ptr issues
		pPenFromCMM = pGlbSetup->GetPenSetupConfig()->GetDummyPen();
	}
	// Set the pen configuration block from the CMM
	SetPenConfiguration(pPenFromCMM);
	RegisterChange();
}
//****************************************************************************
/// Setup the replay pen with an actual configuration of a pen
///
/// @param[in] - toPenIndex, One Based index of actual Pen to assign to replay Pen 0-V6_MAX_PENS-1
///
/// @return - nothing 
///
//****************************************************************************
void CDataItemPen::SetReplayPenConfig(int toPenIndex) {
	SetupCMMConfig(toPenIndex);
	SetPenConfig();
}
//****************************************************************************
/// Set the current floating point value of the Data Item
///
/// @param[in] - value, new value of data item
///
/// @return - nothing
//****************************************************************************
void CDataItemPen::SetValue(float value) {
	//MarkD: reverse sign of value if in reversed scale and output is out of range
	if (GetStatus() >= DISTAT_NORMAL) {
		CDataItem::SetValue(value);	// normal operation - valid reading
	} else	// no valid reading
	{
		CDataItem::SetValue(value); // process normally, but potentially swap status
		if (m_reverseScale) {
			//MarkD: now need to swap status, not the value
			if (GetStatus() == DISTAT_INPUT_OVERRANGE) {
				SetStatus(DISTAT_INPUT_UNDERRANGE);
			} else if (GetStatus() == DISTAT_INPUT_UNDERRANGE) {
				SetStatus(DISTAT_INPUT_OVERRANGE);
			}
		}
	}
	// If the status of the Pen is normal so far (i.e. an a source items has not cause an issue
	// then check for pen over or under and set accordingly
	if (GetStatus() >= DISTAT_NORMAL) {
		if (m_reverseScale) {
			if (value < GetSpan())
				SetStatus(DISTAT_OVERRANGE);		// Pen is in overrange
			else if (value > GetZero())
				SetStatus(DISTAT_UNDERRANGE);		// Pen is in underrange
		} else {
			if (value > GetSpan())
				SetStatus(DISTAT_OVERRANGE);		// Pen is in overrange
			else if (value < GetZero())
				SetStatus(DISTAT_UNDERRANGE);		// Pen is in underrange
		}
	}
}

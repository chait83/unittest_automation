/// @file
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Data Item Table
/// @n Filename: DataItemGeneral.cpp
/// @n Desc:	 General system items for Data item table
///
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//26Stability Project 1.21.1.3 7/2/2011 4:56:38 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//version of firmware to JF version of firmware.
//25Stability Project 1.21.1.2 7/1/2011 4:38:12 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//task. The merging will be done between IL version of firmware and JF
//version of firmware. 
//24Stability Project 1.21.1.1 3/17/2011 3:20:20 PMHemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//new operator in DEBUG mode only. To detect memory leaks in files, use
//it in preprocessor definition when in debug mode.
//23Stability Project 1.21.1.0 2/15/2011 3:02:52 PMHemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//of new operator has been commented.
// $
//
// ****************************************************************
#include "V6globals.h"
#include "DataItemGeneral.h"
//#include "V7DbgLogDefines.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
//=============================================================================
// CDataItemTypeGeneral Class
//=============================================================================
//****************************************************************************
/// CDataItemTypeGeneral Constructor
//****************************************************************************
CDataItemTypeGeneral::CDataItemTypeGeneral() {
}
//****************************************************************************
/// CDataItemTypeGeneral Destructor
//****************************************************************************
CDataItemTypeGeneral::~CDataItemTypeGeneral() {
	m_GeneralDataItemArray.clear();
}
//****************************************************************************
/// CreateItemTable overridden method, create the item table. 
/// responisibility to create the memory for Data items, and initialise the table
///
/// @return - T_DI_RETURN status of method 
///
//****************************************************************************
T_DI_RETURN CDataItemTypeGeneral::CreateItemTable() {
	int itemCount = 0;			// Generic counter for multiple items
	WCHAR varName[MAX_VARNAME_LEN];				// Container to build variable names into		
	WCHAR tempTag[MAX_GENERAL_TAG_LENGTH];		// Container to build variable names into		
	T_DI_RETURN retVal = DI_OKAY;
	//qDebug("Create Data Item table for a %d General\n",DI_GEN_MAX_ITEMS);
	// Stage 1, Create the memory space for the DataItems
	m_GeneralDataItemArray.resize(DI_GEN_MAX_ITEMS);
	SetDataItemInfo(DI_GENERAL, DI_GENTYPE_MAX_TYPES, DI_GEN_MAX_ITEMS);// Type General, no subtypes and Max Pens instance.
	// Stage 2, initialise the data items
	// Add your General data item below, supplying the correct information.
	//			Data Item ID			NV identifier		Script VarName		Zero	Span		Tag					Units
	AddItem(DI_GEN_IDLE, NVV_NOT_NV, "IDLE", 0, 100, "Idle", "%");
	AddItem(DI_GEN_ON_TIME_SEC, NVV_NOT_NV, "ONTIME", 0, 9999999, "On Time", "Seconds");
	AddItem(DI_GEN_QUEUE_TODISK, NVV_NOT_NV, "QTODISK", 0, 100, "Data pending", "%");
	AddItem(DI_GEN_QUEUE_FREEBLOCK, NVV_NOT_NV, "QFREEBLK", 0, 100, "Free blocks", "%");
	AddItem(DI_GEN_QUEUE_FILESFREE, NVV_NOT_NV, "QFREEFILE", 0, 100, "Free Files", "%");
	// Add communications variables
	for (itemCount = DI_GEN_COMMS_VAR_IN_FIRST; itemCount < DI_GEN_COMMS_VAR_IN_MAX; itemCount++) {
		// Generate variable names and tags
		swprintf(varName, MAX_VARNAME_LEN, L"CV%d", (itemCount - DI_GEN_COMMS_VAR_IN_FIRST) + 1);
		swprintf(tempTag, MAX_GENERAL_TAG_LENGTH, L"Comms Var %d", (itemCount - DI_GEN_COMMS_VAR_IN_FIRST) + 1);
		// Add comms variables to the Data item table
		AddItem(static_cast<T_DATA_ITEM_GENERAL>(itemCount), NVV_NOT_NV, QString::fromWCharArray(varName),
				UNKNOWN_RANGE_ZERO, UNKNOWN_RANGE_SPAN, QString::fromWCharArray(tempTag), "");
	}
	// Add Batch status variables
	for (itemCount = DI_GEN_BATCHMODE_FIRST; itemCount < DI_GEN_BATCHMODE_MAX; itemCount++) {
		// Generate variable names and tags
		swprintf(varName, MAX_VARNAME_LEN, L"BATMD%d", (itemCount - DI_GEN_BATCHMODE_FIRST) + 1);
		swprintf(tempTag, MAX_GENERAL_TAG_LENGTH, L"Batch Mode %d", (itemCount - DI_GEN_BATCHMODE_FIRST) + 1);
		// Add batch status to the Data item table
		AddItem(static_cast<T_DATA_ITEM_GENERAL>(itemCount), NVV_NOT_NV, QString::fromWCharArray(varName),
				UNKNOWN_RANGE_ZERO, UNKNOWN_RANGE_SPAN, QString::fromWCharArray(tempTag), "");
	}
	// Add Batch count variables
	for (itemCount = DI_GEN_BATCHCOUNT_FIRST; itemCount < DI_GEN_BATCHCOUNT_MAX; itemCount++) {
		// Generate variable names and tags
		swprintf(varName, MAX_VARNAME_LEN, L"BATC%d", (itemCount - DI_GEN_BATCHCOUNT_FIRST) + 1);
		swprintf(tempTag, MAX_GENERAL_TAG_LENGTH, L"Batch Count %d", (itemCount - DI_GEN_BATCHCOUNT_FIRST) + 1);
		// Add batch count to the Data item table
		AddItem(static_cast<T_DATA_ITEM_GENERAL>(itemCount), NVV_NOT_NV, QString::fromWCharArray(varName),
				UNKNOWN_RANGE_ZERO, UNKNOWN_RANGE_SPAN, QString::fromWCharArray(tempTag), "");
	}
	//			Data Item ID			NV identifier		Script VarName		Zero	Span		Tag					Units
	//AddItem(	DI_GEN_BATCHMODE,		NVV_BATCH_STATUS,	L"BATMD",			0,		5,			L"Batch Mode",		L"Mode" );
	AddItem(DI_GEN_MEM_LOAD, NVV_NOT_NV, "MEMLD", 0, 100, "Mem load", "%");
	AddItem(DI_GEN_MEM_PHYS_TOTAL, NVV_NOT_NV, "MEMTOT", 0, 65535, "Mem Total", "K");
	AddItem(DI_GEN_MEM_PHYS_AVAIL, NVV_NOT_NV, "MEMAVAIL", 0, 65535, "Mem Avail", "K");
	AddItem(DI_GEN_MEM_VIRT_TOTAL, NVV_NOT_NV, "VMEMTOT", 0, 65535, "VMem Total", "K");
	AddItem(DI_GEN_MEM_VIRT_AVAIL, NVV_NOT_NV, "VMEMAVAIL", 0, 65535, "VMem Avail", "K");
	AddItem(DI_GEN_MEM_VIRT_LOWTIDE, NVV_NOT_NV, "VMEMLO", 0, 65535, "VMem LowTide", "K");
	// Debug information for queues
#ifdef DBL_STORAGE_CS_THREAD ////Thread ID of the thread holding CStorage Critical Section
	AddItem(	DI_GEN_Q_MCPAN,			NVV_NOT_NV,			L"QMCPAN",			0,		0XFFFFFFFF,		L"Q OpPanel",		L"val" );
	AddItem(	DI_GEN_Q_MCMES,			NVV_NOT_NV,			L"QMCMES",			0,		0XFFFFFFFF,		L"Q Mess",			L"val" ); 
#else
	AddItem(DI_GEN_Q_MCPAN, NVV_NOT_NV, "QMCPAN", 0, 65535, "Q OpPanel", "val");
	AddItem(DI_GEN_Q_MCMES, NVV_NOT_NV, "QMCMES", 0, 65535, "Q Mess", "val");
#endif
	AddItem(DI_GEN_Q_MCCHA, NVV_NOT_NV, "QMCCHA", 0, 65535, "Q Chart", "val");
	AddItem(DI_GEN_Q_MCLOG, NVV_NOT_NV, "QMCLOG", 0, 65535, "Q Log", "val");
	AddItem(DI_GEN_Q_MCOTH, NVV_NOT_NV, "QMCOTH", 0, 65535, "Q Other", "val");
	AddItem(DI_GEN_Q_BLK_REL, NVV_NOT_NV, "QMCBLKR", 0, 65535, "Q Blk Rel", "val");
	AddItem(DI_GEN_Q_HB, NVV_NOT_NV, "QHEART", 0, 65535, "Q Heart", "val");
	// Media percentage free
	AddItem(DI_GEN_FRONTCF_PC, NVV_NOT_NV, "CFFREE", 0, 100, "CF Free", "%");
	AddItem(DI_GEN_USB1_PC, NVV_NOT_NV, "USB1FREE", 0, 100, "USB1 Free", "%");
	AddItem(DI_GEN_USB2_PC, NVV_NOT_NV, "USB2FREE", 0, 100, "USB2 Free", "%");
	AddItem(DI_GEN_INT_HOURS, NVV_NOT_NV, "INTHRS", 0, 65535, "Int to recycle", "Hrs");
	AddItem(DI_GEN_FTP_HOURS, NVV_NOT_NV, "FTPHRS", 0, 65535, "FTP to recycle", "Hrs");
	// Add communications variables
	int nvOffset = 0;
	for (itemCount = DI_GEN_USER_VARS_FIRST; itemCount < DI_GEN_USER_VARS_MAX; itemCount++) {
		// Generate variable names and tags
		swprintf(varName, MAX_VARNAME_LEN, L"UV%d", (itemCount - DI_GEN_USER_VARS_FIRST) + 1);
		swprintf(tempTag, MAX_GENERAL_TAG_LENGTH, L"User Var %d", (itemCount - DI_GEN_USER_VARS_FIRST) + 1);
		// Add comms variables to the Data itme table
		AddItem(static_cast<T_DATA_ITEM_GENERAL>(itemCount), static_cast<NVVAR_IDENT>(NVV_USER_VARS_FIRST + nvOffset),
				QString::fromWCharArray(varName), UNKNOWN_RANGE_ZERO, UNKNOWN_RANGE_SPAN,
				QString::fromWCharArray(tempTag), "");
		nvOffset++;
	}
	WCHAR MAX_TC[] = L"MAXTC";
	WCHAR MIN_TC[] = L"MINTC";
	AddItem(DI_GEN_AMS2750_MAX_TC, NVV_NOT_NV, MAX_TC, 0, 65535, "Max Sensor", "C");
	AddItem(DI_GEN_AMS2750_MIN_TC, NVV_NOT_NV, MIN_TC, 0, 65535, "Min Sensor", "C");
	AddItem(DI_GEN_AMS2750_TC_DIFF, NVV_NOT_NV, "TCDIFF", 0, 65535, "Sensor Diff", "C");
	AddItem(DI_GEN_AMS2750_TUS_START_TIME, NVV_NOT_NV, "TUSSTART", 0, 65535, "NA", "Stopped");
	AddItem(DI_GEN_AMS2750_TUS_ELAPSED_TIME, NVV_NOT_NV, "TUSELAP", 0, 65535, "NA", "");
	AddItem(DI_GEN_LOGGED_IN_USER, NVV_NOT_NV, "USERNAME", 0, 65535, "NA", "");
	/// ******* Add new General Data Items here ******
	// Set the dummy General Data Item
	SetDummyDataItem(new CDataItemGeneral());
	return retVal;
}
//****************************************************************************
/// CreateItemTable overridden method, create the item table. 
/// responisibility to create the memory for Data items, and initialise the table
///
/// @return - T_DI_RETURN status of method 
///
//****************************************************************************
T_DI_RETURN CDataItemTypeGeneral::AddItem(T_DATA_ITEM_GENERAL id, NVVAR_IDENT nvid, QString varName, float zero,
		float span, const QString tag, const QString units) {
	T_DI_RETURN retVal = DI_OKAY;
	// Add item to the Data item table
	retVal = AddDataItem(&m_GeneralDataItemArray[id], DI_GENTYPE_GENERAL, id, QString::fromWCharArray(varName),
			DI_FLOAT);
	// initialise the zero span tag and units label of the general data item
	m_GeneralDataItemArray[id].SetGeneralDetails(zero, span, tag, units);
	// If item is NV get the handle on the item and read in old value
	if (nvid != NVV_NOT_NV) {
		// It's an NV variable, get the reference to the NV variable store
		m_GeneralDataItemArray[id].SetNVHandle( pNV_VARS->GetBasicTimeNVObject(nvid));
		// Load in persisted NV values
		m_GeneralDataItemArray[id].SetValue(m_GeneralDataItemArray[id].GetNVHandle()->GetFromNV()->value.flt);
		m_GeneralDataItemArray[id].SetTime(m_GeneralDataItemArray[id].GetNVHandle()->GetFromNV()->time);
	} else {
		m_GeneralDataItemArray[id].SetNVHandle(NULL);
	}
	return retVal;
}
//****************************************************************************
/// ApplyConfig overridden method, handle all configuration changes and startup
/// Will be called on startup when configuration in place and every time
/// the current configuration changes.
///
/// @return - T_DI_RETURN status of method 
///
//****************************************************************************
T_DI_RETURN CDataItemTypeGeneral::ApplyConfig() {
	T_DI_RETURN retVal = DI_OKAY;
	return retVal;
}
//=============================================================================
// CDataItemGeneral Class
//=============================================================================
//****************************************************************************
/// CDataItemGeneral Constructor 
///
//****************************************************************************
CDataItemGeneral::CDataItemGeneral() {
	m_zero = 0;
	m_span = 100;
	m_tag[0] = 0;
	m_units[0] = 0;
	m_pNV = NULL;
}
//****************************************************************************
/// Setup the General data item information fields
///
/// @return - nothing 
///
//****************************************************************************
void CDataItemGeneral::SetGeneralDetails(float zero, float span, const QString tag, const QString units) {
	m_zero = zero;
	m_span = span;
	// Copy tag and cap to length
	//wcsncpy( m_tag, tag, MAX_GENERAL_TAG_LENGTH); 
	//m_tag[MAX_GENERAL_TAG_LENGTH-1] = 0;
#if _MSC_VER < 1400 
	wcsncpy(m_tag, tag, GROUPINFO_AUTOBATCHNAME_LEN);
	m_tag[ GROUPINFO_AUTOBATCHNAME_LEN - 1] = 0;
	// Copy units label and cap to length
	wcsncpy(m_units, units, MAX_GENERAL_UNITS_LENGTH);
#else
	wcsncpy_s( m_tag,sizeof(m_tag)/sizeof(WCHAR), tag, _TRUNCATE); 
	m_tag[ GROUPINFO_AUTOBATCHNAME_LEN - 1 ] = 0;
	// Copy units label and cap to length
	wcsncpy_s( m_units, sizeof(m_units)/sizeof(WCHAR), units, _TRUNCATE); 
#endif
	m_units[MAX_GENERAL_UNITS_LENGTH - 1] = 0;
}
//****************************************************************************
/// Override SetValue to amange NV access if required
///
/// @return - nothing 
///
//****************************************************************************
void CDataItemGeneral::SetValue(float value) {
	COMBO_VAR4 c4value;
	c4value.flt = value;
	SetValue(c4value);
}
//****************************************************************************
/// Override SetValue to amange NV access if required
///
/// @return - nothing 
///
//****************************************************************************
void CDataItemGeneral::SetValue(COMBO_VAR4 value) {
	// Set the value and the time
	SetValue(value.flt);
	SetTime( pSYSTIMER->GetCurrentProcessTimeInMicroSec());
	// if this is tied to an NV reference, update the NV values
	if (m_pNV != NULL) {
		m_pNV->SetToNV(GetComboValue(), GetTimeuS());		// Set the NV data
	}
}

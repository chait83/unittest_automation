/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Processing
/// @n Filename: MaxMins.cpp
/// @n Desc:	 Manage Max and Min for a data reading
///				 
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  11  Stability Project 1.6.1.3 7/2/2011 4:58:36 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  10  Stability Project 1.6.1.2 7/1/2011 4:38:28 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  9 Stability Project 1.6.1.1 3/17/2011 3:20:28 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  8 Stability Project 1.6.1.0 2/15/2011 3:03:16 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// ****************************************************************
#include "MaxMins.h"
#include "TraceDefines.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
//**********************************************************************
/// CMaxMin constructor
///
//**********************************************************************
CMaxMin::CMaxMin() {
	m_requestMode = MM_MODE_NORMAL;		// Normal run mode
}
//**********************************************************************
/// Initialise the Alarm to the correct Pen and Alarm number
/// 
/// @param[in]	penNumber - number of pen that the alarm belongs to. 0 to MAX_PENS-1
///	@param[in]	alarmNumber - number of alarm of the pen penNumber. 0 to MAX_ALARMS-1
///
/// @return		T_MAXMIN_RETURN as status of call
/// 
//**********************************************************************
T_MAXMIN_RETURN CMaxMin::IntialiseMaxMin(USHORT penNumber) {
	T_MAXMIN_RETURN retVal = MM_OKAY;
	// If Pen number is within limits, use.
	if (penNumber < V6_MAX_PENS) {
		m_penNumber = penNumber;
		// Get handle on Pen Data Item for this max min
		m_pPenDataItem = (CDataItemPen*) pGlbDIT->GetDataItemPtr(DI_PEN, DI_PEN_READING, m_penNumber);
		if (m_pPenDataItem == NULL) {
			LOG_CRTL(TRACE_PROCESSING, "Pen Data item does not exist %d \n", m_penNumber);
			retVal = MM_INIT_FAILED;
		}
		// Get handle on the related Max Data Item
		m_pMaxDataItem = (CDataItemMaxMinAve*) pGlbDIT->GetDataItemPtr(DI_MMA, DI_MMA_MAX_USER, m_penNumber);
		if (m_pMaxDataItem == NULL) {
			LOG_CRTL(TRACE_PROCESSING, "Max Data item does not exist for pen %d \n", m_penNumber);
			retVal = MM_INIT_FAILED;
		}
		// Get handle on the related Min Data Item
		m_pMinDataItem = (CDataItemMaxMinAve*) pGlbDIT->GetDataItemPtr(DI_MMA, DI_MMA_MIN_USER, m_penNumber);
		if (m_pMinDataItem == NULL) {
			LOG_CRTL(TRACE_PROCESSING, "Min Data item does not exist for pen %d \n", m_penNumber);
			retVal = MM_INIT_FAILED;
		}
		m_pAvgDataItem = (CDataItemMaxMinAve*) pGlbDIT->GetDataItemPtr(DI_MMA, DI_MMA_AVE_USER, m_penNumber);
		if (m_pAvgDataItem == NULL) {
			LOG_CRTL(TRACE_PROCESSING, "Average Data item does not exist for pen %d \n", m_penNumber);
			retVal = MM_INIT_FAILED;
		}
		// Retreive Non volatile information
		m_pMaxNV = pNV_VARS->GetBasicTimeNVObject(static_cast<NVVAR_IDENT>(NVV_PEN_MAX_FIRST + penNumber));
		m_pMinNV = pNV_VARS->GetBasicTimeNVObject(static_cast<NVVAR_IDENT>(NVV_PEN_MIN_FIRST + penNumber));
		// Set Max and Min from Non volatile
		m_Max = *m_pMaxNV->GetFromNV();
		m_Min = *m_pMinNV->GetFromNV();
		// Set data item table with existing values
		m_pMaxDataItem->SetValue(m_Max.value.flt);				// Update DIT Max value
		m_pMaxDataItem->SetStatus(DISTAT_NORMAL);
		m_pMinDataItem->SetValue(m_Min.value.flt);				// Update DIT min value
		m_pMinDataItem->SetStatus(DISTAT_NORMAL);
		// If Max or Min time is zero then the SRAM was reset, make sure the max and min values are reset too
		if (m_Max.time == 0 || m_Min.time == 0) {
			ResetBoth();
		}
		m_requestMode = MM_MODE_NORMAL;		// Normal run mode
		// Check for a reset on a startup
		if ( pSYSTEM_INFO->GetStartupResetAction()->ResetMaxMins == TRUE || pSYSTEM_INFO->IsDataResetRequested() == TRUE) {
			m_requestMode = MM_MODE_RESET_BOTH;		// Request a reset
		} else {
			m_requestMode = MM_MODE_NORMAL;			// Normal run mode
		}
	} else {
		retVal = MM_INIT_FAILED;
	}
	return retVal;
}
//**********************************************************************
/// Set the configuration in the Max Min.
/// 
/// @param[in]	pPenCfg - ptr to pen configuration in CMM for this alarm
///
/// @return		T_MAXMIN_RETURN as status of call
/// 
//**********************************************************************
T_MAXMIN_RETURN CMaxMin::SetMaxMinFromConfig(T_PPEN pPenCfg) {
	T_MAXMIN_RETURN retVal = MM_OKAY;
	// Set-up a pointer to the pen configuration
	m_pPenCfg = pPenCfg;
	// Check for a reset on a configuration change 
	if ( pSYSTEM_INFO->GetConfigChangeResetAction()->ResetMaxMins == TRUE) {
		m_requestMode = MM_MODE_RESET_BOTH;		// Request a reset
	}
	return retVal;
}
//**********************************************************************
/// Process a max/min
///
/// @return		nothing
/// 
//**********************************************************************
void CMaxMin::DoMaxMin() {
	// If there is a mode action change then process the request
	if (m_requestMode != MM_MODE_NORMAL) {
		ProcessRequestAction();
	}
	// Only process a Max/Min if the reading is normal
	if (m_pPenDataItem->GetStatus() >= DISTAT_NORMAL) {
		// Process Max & Min
		float currentPenValue = m_pPenDataItem->GetFPValue();
		// Process the Max value 
		if (currentPenValue > m_Max.value.flt) {
			// Max value needs to be changed
			m_Max.value.flt = currentPenValue;							// Update current max value
			m_Max.time = pSYSTIMER->GetCurrentProcessTimeInMicroSec();	// Update time Max changed
			m_pMaxDataItem->SetValue(m_Max.value.flt);				// Update DIT Max value
			m_pMaxDataItem->SetTime(m_Max.time);						// Update DIT Max time changed
			m_pMaxNV->SetToNV(m_Max.value, m_Max.time);				// Store to NV
		}
		if (currentPenValue < m_Min.value.flt) {
			// Min value needs to be changed
			m_Min.value.flt = currentPenValue;							// Update current min value
			m_Min.time = pSYSTIMER->GetCurrentProcessTimeInMicroSec();	// Update time min changed
			m_pMinDataItem->SetValue(m_Min.value.flt);				// Update DIT min value
			m_pMinDataItem->SetTime(m_Min.time);						// Update DIT min time changed
			m_pMinNV->SetToNV(m_Min.value, m_Min.time);				// Store to NV
		}
	}
}
//**********************************************************************
/// Process a DoAverage
///
/// @return		nothing
/// 
//**********************************************************************
void CMaxMin::DoAverage(float value) {
	// Only process a Max/Min if the reading is normal
	if (m_pPenDataItem->GetStatus() >= DISTAT_NORMAL) {
		m_pAvgDataItem->SetValue(value);   //Update DIT with average value
		m_pAvgDataItem->SetTime(pSYSTIMER->GetCurrentProcessTimeInMicroSec());
	}
}
//**********************************************************************
/// Process a reset request for a max/min
///
/// @return		nothing
/// 
//**********************************************************************
void CMaxMin::ProcessRequestAction() {
	switch (m_requestMode) {
	case MM_MODE_RESET_MAX:		// reset the Max value
		ResetMax();
		break;
	case MM_MODE_RESET_MIN:		// Reset the Min Value
		ResetMin();
		break;
	case MM_MODE_RESET_BOTH:	// Reset both
		ResetBoth();
		break;
	}
	m_requestMode = MM_MODE_NORMAL;		// Reset request Action
}
//**********************************************************************
/// Reset a Min value
///
/// @return		nothing
/// 
//**********************************************************************
void CMaxMin::ResetMin() {
	m_Min.value.flt = FLT_MAX;
	m_Min.time = 0;
	m_pMinDataItem->SetStatus(DISTAT_NORMAL);
}
//**********************************************************************
/// Reset a Max value
///
/// @return		nothing
/// 
//**********************************************************************
void CMaxMin::ResetMax() {
	m_Max.value.flt = -FLT_MAX;
	m_Max.time = 0;
	m_pMaxDataItem->SetStatus(DISTAT_NORMAL);
}

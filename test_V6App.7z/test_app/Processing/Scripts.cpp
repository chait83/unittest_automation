/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Processing
/// @n Filename: Scripts.cpp
/// @n Desc:	 Constains a manager to provide control over script services
///				 and an Instance manager to handle each script instance
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  34  Stability Project 1.29.1.3 7/2/2011 5:01:03 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  33  Stability Project 1.29.1.2 7/1/2011 4:38:52 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  32  Stability Project 1.29.1.1 3/17/2011 3:20:46 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  31  Stability Project 1.29.1.0 2/15/2011 3:03:54 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// ****************************************************************
#include "Scripts.h"
#include "TraceDefines.h"
#include "StringUtils.h"
#include "SS_ErrorDefinitions.h"
#include "V6globals.h"
CScriptManager *pGlbScriptManager;
CScriptManager *CScriptManager::m_pScriptManagerInstance = NULL;
QMutex CScriptManager::m_CreationMutex;
//=======================================================================================================
// Class CScriptManager
//=======================================================================================================
//*************************************************************************************
/// CScriptManager Constructor
///
//*************************************************************************************
CScriptManager::CScriptManager() {
	m_pSRAM = NULL;
	m_pRegion = NULL;
	m_FPCapabiltiiesTable = NULL;
}
//*************************************************************************************
///
/// Instance creation of CScriptManager singleton
///
/// @return		pointer to single instance of CScriptManager
/// 
//*************************************************************************************
CScriptManager* CScriptManager::GetHandle() {
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;
	if (NULL == m_pScriptManagerInstance) {
		// An instance has yet to be completed
        waitSingleObjectResult = m_CreationMutex.tryLock(g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);
		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:
			// Object was signaled
			if (NULL == m_pScriptManagerInstance) {
				m_pScriptManagerInstance = new CScriptManager;
			}
            m_CreationMutex.unlock();

			break;
		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
            V6WarningMessageBox(NULL, "SCRIPTS WaitForSingleObject Error", "Error", MB_OK);
			break;
		}
		// Close the Mutex as no longer required
		//No need to close the mutex in Qt
	}
	return (m_pScriptManagerInstance);
}
//*************************************************************************************
///
/// Deletes the instance of the singleton from memory
///
/// @return		Nothing
/// 
//*************************************************************************************
void CScriptManager::CleanUp() {
	// Release SRAM region for persisted variables
//  if( NULL != m_pSRAM )
//  { 
//	  m_pSRAM->ReleaseRegion( REGION_SCRIPT_PV ); 
//	}
	// Cleanup Script services
	V6ERRORINFO ErrInfo;
	SS_UnInitialise(&ErrInfo);
	// Remove Function Capability Table
	if (m_FPCapabiltiiesTable != NULL) {
		delete m_FPCapabiltiiesTable;
	}
	// Delete this singleton
	delete m_pScriptManagerInstance;
	m_pScriptManagerInstance = NULL;
}
//*************************************************************************************
/// Initialise the script services
///
/// @return TRUE if script services initialised okay, otherwise false
/// 
//*************************************************************************************
V6ERRORINFO CScriptManager::Initialise(void) {
	DECLARE_V6_EXCEPTION
	l_module = V6_MT_PROCESSING;
	BEGIN_EXCEPTION
		static char nullCapabilitiesTable[1] = "";
#ifdef STARTUP_LOGGING
	WCHAR InitLogFileName[ 256 ];
	WCHAR InitLogString[512];
	CStorage kLogFile;
	QFileDevice::FileError kFileEx;
	int iPathLen = 256;
	pDALGLB->GetPath(	static_cast< T_STORAGE_PATH >( IDS_INTERNAL_SD ), 
						InitLogFileName,
						256,
						&iPathLen );
	wcsncat( InitLogFileName, 256, L"ScriptInit.txt", (256 - wcslen( InitLogFileName )) );
	
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();
		wcscpy(InitLogString,L"--------Script Manager Initialisation started-------\n");		
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		wcscpy(InitLogString,L"Set Maths option\n");
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
		// Check levels of maths/script that is supported in the options
		if ( pSYSTEM_INFO->FWOptionMathsType() == MATH_OPTION_BASIC_BLOCK) {
			// Single line with basic operators (+ - * /)
			m_SSInitInfo.eScriptMode = SS_STANDARD;
		} else {
			// Single Line or full script with all operators and functions
			m_SSInitInfo.eScriptMode = SS_FULLYFUNCTIONAL;
		}
#ifdef STARTUP_LOGGING
	wcscpy(InitLogString,L"Generate Function Pack Information\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();		
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
		// Generate the Function Pack information
		int FunctionPackCTSize = CreateExportTable();
		m_SSInitInfo.pfnFuncPackGetProc = &g_fnFuncPackGetProc;
#ifdef STARTUP_LOGGING
	wcscpy(InitLogString,L"BuildCapabilitiesTable\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();		
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
		// generate the fucntion pack capabilities table
		m_FPCapabiltiiesTable = new char[FunctionPackCTSize];					// Allocate required space for table
		BuildCapabilitiesTable(m_FPCapabiltiiesTable, FunctionPackCTSize - 1);	// Build the table
		m_SSInitInfo.pFPCT = m_FPCapabiltiiesTable;					// Set the table so script services can gain access
		// Set-up Script function capabilities table(Current NULL as loadable scripts not supported)
		m_SSInitInfo.pSFCT = nullCapabilitiesTable;
		// Set the callback functions allowing Script services DLL to access DIT
		m_SSInitInfo.pfnDITVarValid = &LookUpRefForDITByVarname;
		m_SSInitInfo.pfnDITGetVarValue = &GetDITValueByRef;
#ifdef STARTUP_LOGGING
	wcscpy(InitLogString,L"SRAM Request Region\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();		
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
		// Get the SRAM region to be used for Persist variables 
		m_pSRAM = CSRAMManager::GetHandle();
		CSRAMManager::regionError requestReturn = m_pSRAM->RequestRegion(REGION_SCRIPT_PV, &m_pRegion);
#ifdef STARTUP_LOGGING
	wcscpy(InitLogString,L"Is Factory Reset required\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();		
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
		if (requestReturn != CSRAMManager::REGION_OKAY) {
			SET_ERROR(l_err, l_module, V6_ERROR, SS_E_INVALID_ARGUMENT)
		}
		m_SSInitInfo.pPV = m_pRegion->GetAddress();
		m_SSInitInfo.nPVMemSize = m_pRegion->GetAvailableBytes();
		// If factory reset then reset Persist variables
		if ( pSYSTEM_INFO->IsFactoryResetRequested() == TRUE) {
#ifdef STARTUP_LOGGING
		wcscpy(InitLogString,L"m_pRegion->ClearRegion()\n");
		if( kLogFile.Open(	InitLogFileName, 
						CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
						&kFileEx ) )
		{
			kLogFile.SeekToEnd();		
			kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
			kLogFile.Close();
		}
#endif
			// A reset is required so delete the persist
			m_pRegion->ClearRegion();
		}
#ifdef STARTUP_LOGGING
	wcscpy(InitLogString,L"GetAutoState\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();		
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
		// Check if this is the first time the region has been used after power on
		if (m_pRegion->GetAutoState() == SRAM_STATE_FIRSTUSE) {
#ifdef STARTUP_LOGGING
		wcscpy(InitLogString,L"ClearPersistVariables\n");
		if( kLogFile.Open(	InitLogFileName, 
						CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
						&kFileEx ) )
		{
			kLogFile.SeekToEnd();		
			kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
			kLogFile.Close();
		}
#endif
			ClearPersistVariables();
			m_pRegion->SetAutoStateToNormal();	// Return to normal state, first time power on for region
#ifdef STARTUP_LOGGING
		wcscpy(InitLogString,L"UpdateSRAM\n");
		if( kLogFile.Open(	InitLogFileName, 
						CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
						&kFileEx ) )
		{
			kLogFile.SeekToEnd();		
			kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
			kLogFile.Close();
		}
#endif
			pDALGLB->UpdateSRAM();
		}
#ifdef STARTUP_LOGGING
	wcscpy(InitLogString,L"SS_Initialize\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();		
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
		// All parameters configure, Initialise the Script services
		SS_Initialize(m_SSInitInfo, &l_err);
		// Perfrom a log critical on the scripts, @todo AK make this a diagnostic message once debugging complete
		if (l_err.Code != V6_E_SUCCESS) {
			WCHAR szMessage[256];
            FormatMsg(l_err, szMessage, 256);
			LOG_CRTL(TRACE_PROCESSING, "%s\n", szMessage);
		}
#ifdef STARTUP_LOGGING
	wcscpy(InitLogString,L"-----------END-------------\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();		
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
		return l_err;
    END_EXCEPTION
    CATCH_V6_EXCEPTION
            CATCH_DEF_EXCEPTION
    CLEANUP
            m_pSRAM->ReleaseRegion(REGION_SCRIPT_PV);
	return l_err;
}
//******************************************************
/// Set all persist variable to 0.0
///
/// @return nothing
/// 
//******************************************************
void CScriptManager::ClearPersistVariables() {
	float *pPersistVar = (float*) m_SSInitInfo.pPV;
	for (int persistVarCount = 0;
			persistVarCount < MAX_PV_COUNT && (MAX_PV_COUNT * sizeof(float)) < m_SSInitInfo.nPVMemSize;
			persistVarCount++) {
		*pPersistVar++ = 0.0;
	}
}
//=======================================================================================================
// Class CScriptInstance
//=======================================================================================================
//*************************************************************************************
/// CScriptInstance Constructor
///
//*************************************************************************************
CScriptInstance::CScriptInstance() {
	m_ScriptBlockCreated = FALSE;
	m_pScript = NULL;
	Cleanup();
}
//*************************************************************************************
/// CScriptInstance Desstructor
///
//*************************************************************************************
CScriptInstance::~CScriptInstance() {
	Cleanup();
}
//*************************************************************************************
/// Cleanup Script and return to default
///
//*************************************************************************************
void CScriptInstance::Cleanup() {
	// If a script block has been created, delete from the script services manager
	if (m_ScriptBlockCreated) {
		m_ScriptBlockCreated = FALSE;
		SS_DeleteScriptBlock(m_scriptIndex, &m_errInfo);
	}
	// If script source allocated, deallocate
	if (m_pScript != NULL) {
		delete[] m_pScript;
		m_pScript = NULL;
	}
	m_performanceIndex = 0;
	m_scriptIndex = 0;
	m_sourceCRC = 0;
	m_scriptSize = 0;
	m_numDITDependents = 0;
	m_CurrentSetupChangeState = FALSE;
	m_CurrentTimeChangeState = FALSE;
}
const int SCRIPTSIZE_SAFETY_MARGIN = 10;		///< A safety marigin for allocating the script size in memory
//*************************************************************************************
/// Build a script from a math or script as stored in CMM, only if script has been changed
/// The user will not be shown the opening and closing braces or the function headers
/// for maths blocks they also will not be shown the "return" statement, this is egnerated in this fucntion
///
/// @param[in]- pSource, pointer to source script as characters
/// @param[in]- mathType, T_MATH_TYPE determines the match type (Script or Block)
/// @param[in]- ident, T_SCRIPT_IDENT identifies script type and instance
///
/// @return - TRUE if the script needs to be compiled, otherwise FALSE no changes
///
//*************************************************************************************
BOOL CScriptInstance::BuildAutoScript(char *pSource, T_MATH_TYPE mathType, T_SCRIPT_IDENT ident) {
	BOOL GenerateNewScript = TRUE;		// Always assume new script to be built
	m_ident = ident;					// Store script identifier
	// Calculate the total size to allocate for script
	size_t newScriptSize = 0;
	newScriptSize += strlen(pSource);						// Add size of source
	newScriptSize += strlen("function Snnn() as float\n");	// Add size of header
	newScriptSize += strlen("{\n return xyz; \n }\n");		// Add size of additional code in body
	newScriptSize += SCRIPTSIZE_SAFETY_MARGIN;				// Add in a safety margin
	USHORT newSourceCRC = CrcCalc(reinterpret_cast<unsigned char*>(pSource), (ULONG) strlen(pSource));
	// Perform a check to see if we need to build a new script
	if ((newScriptSize == m_scriptSize) &&		// Does Source Script size match
			(newSourceCRC == m_sourceCRC) &&			// and the contents of source is identical
			(m_pScript != NULL) &&					// and has Exisiting Script been allocated
			(m_ScriptBlockCreated == TRUE))			// and has script previously compiled
			{
		// Script size and content same, has been generated and compiled, don't need to do it again
		GenerateNewScript = FALSE;
	}
	// Generate a new script if one not previously generated
	if (GenerateNewScript == TRUE) {
		// Cleardown any exisiting scripts and remove them from script manager
		Cleanup();
		// Initialise memebers cleared by Cleanup();
		m_sourceCRC = newSourceCRC;				// Assign the new CRC value
		m_scriptSize = newScriptSize;			// Assign the new script size
		// Allocate memory to build the full script function into
		m_pScript = NULL;
		m_pScript = new char[m_scriptSize];
		memset(m_pScript, 0, m_scriptSize);						// Celardwon the script source block
#if _MSC_VER < 1400 
		sprintf(m_pScript, "function S%d() as float\n", ident);	// Generate the header
		strcat(m_pScript, "{\n");								// Add the opening brace
#else
		sprintf_s( m_pScript, m_scriptSize, "function S%d() as float\n", ident );	// Generate the header
		strcat_s ( m_pScript, m_scriptSize, "{\n" );								// Add the opening brace
#endif
		if (mathType == MATH_TYPE_BLOCK) {
			// Maths Block
#if _MSC_VER < 1400 
			strcat(m_pScript, "return ");				// It's a block so we need to add the return statement
			strcat(m_pScript, pSource);					// Add the main body of script
			strcat(m_pScript, ";");						// Then add delimiter									
#else
			strcat_s ( m_pScript, m_scriptSize, "return " );				// It's a block so we need to add the return statement
			strcat_s ( m_pScript, m_scriptSize, pSource );					// Add the main body of script
			strcat_s ( m_pScript, m_scriptSize, ";" );						// Then add delimiter									
#endif
		} else {
			// Script Block
#if _MSC_VER < 1400 
			strcat(m_pScript, pSource);
			// Add the main body of script
			strcat(m_pScript, "\nreturn 0;");
#else
			strcat_s ( m_pScript, m_scriptSize, pSource );	
			// Add the main body of script
			strcat_s ( m_pScript, m_scriptSize, "\nreturn 0;" );
#endif
		}
#if _MSC_VER < 1400 
		strcat(m_pScript, "\n}\n");								// Add the closing brace
#else
		strcat_s ( m_pScript, m_scriptSize, "\n}\n" );								// Add the closing brace
#endif
//		qDebug("Script Size = %d and calc size = %d \n ", strlen(m_pScript), m_scriptSize );
//		qDebug("%S\n", m_pScript );
	}
	return GenerateNewScript;
}
//*************************************************************************************
/// Generate the execuatble from source script
///
/// @return - V6ERRORINFO structure if V6ERRORINFO.Code == V6_E_SUCCESS, script okay, otherwise
///				errors need to be extracted
///
//*************************************************************************************
V6ERRORINFO* CScriptInstance::CompileScript(BOOL silentError) {
	m_numDITDependents = 0;		// cleardown number of dependents before compilation
#if _MSC_VER < 1400 
	_strlwr(m_pScript);	//MarkD: set to lower case
#else
	_strlwr_s(m_pScript, m_scriptSize);	//MarkD: set to lower case
#endif
	//amar- This is for validating the modified script through the MuLE/SIP.
	if (m_ident == SCRIPT_PROVING) {
		BOOL bValid = FALSE;
		SS_Validate(reinterpret_cast<BYTE*>(m_pScript), &bValid, &m_errInfo);
		if (TRUE == bValid) {
			m_errInfo.Code = V6_E_SUCCESS;
			m_errInfo.Module = V6_MT_SCRIPT;
			m_errInfo.Type = V6_ET_NULL;
		} else {
			// An error has occured whilst Generating the script block, handle it
			HandleScriptError(m_errInfo, silentError);
		}
	} else {
		SS_GenerateScriptBlock(reinterpret_cast<BYTE*>(m_pScript), &m_scriptIndex, &m_errInfo);
		if (m_errInfo.Code == V6_E_SUCCESS) {
			// Compilation of the script has succeded, find its approximate performance index
			SS_GetPerformanceIndex(m_scriptIndex, &m_performanceIndex, &m_errInfo);
			// Get the dependency list
			SS_GetDITDependencyList(m_scriptIndex, &m_numDITDependents, m_dependentList, &m_errInfo);
			m_ScriptBlockCreated = TRUE;
		} else {
			// An error has occured whilst Generating the script block, handle it
			HandleScriptError(m_errInfo, silentError);
		}
	}
	return &m_errInfo;
}
//*************************************************************************************
/// Execute the script, this will return the result in m_Result
///
/// @param[out] - result, result of script to be passed back using a reference
///
/// @return - V6ERRORINFO structure if V6ERRORINFO.Code == V6_E_SUCCESS, script okay, otherwise
///				errors need to be extracted
///
//*************************************************************************************
V6ERRORINFO* CScriptInstance::RunScript(float &result) {
	SS_Execute(m_scriptIndex, &result, &m_errInfo);
	if (m_errInfo.Code != V6_E_SUCCESS) {
		HandleScriptError(m_errInfo, FALSE);
	}
	return &m_errInfo;
}
//*************************************************************************************
/// Set the SETUPCHANGED state variable
///
/// @param[in] - Changed, TRUE to set SETUPCHANGED, FALSE to Clear
///
/// @return - nothing
//*************************************************************************************
void CScriptInstance::SetSetupChangedFlag(BOOL Changed) {
	if (m_CurrentSetupChangeState != Changed) {
		SS_SetState(m_scriptIndex, SV_SETUPCHANGED, Changed, &m_errInfo);
		m_CurrentSetupChangeState = Changed;
	}
}
//*************************************************************************************
/// Set the TIMECHANGED state variable
///
/// @param[in] - Changed, TRUE to set SetupChnage, FALSE to Clear
///
/// @return - nothing
//*************************************************************************************
void CScriptInstance::SetTimeChangedFlag(BOOL Changed) {
	if (m_CurrentTimeChangeState != Changed) {
		SS_SetState(m_scriptIndex, SV_TIMECHANGE, Changed, &m_errInfo);
		m_CurrentTimeChangeState = Changed;
	}
}
//*************************************************************************************
/// indexOf the fastest dependent rate within a script
///
/// @return - Fastest rate in 1/100s of a second
///
//*************************************************************************************	
USHORT CScriptInstance::GetFastestDependentRate() {
	USHORT fastestRate = DEFAULT_PEN_RATE;
	USHORT dependencyRate = DEFAULT_PEN_RATE;
	for (int depIndex = 0; depIndex < m_numDITDependents; depIndex++) {
		// Get rate of dependent item
		dependencyRate = pDIT->GetDataItemPtr(m_dependentList[depIndex])->GetRate();
		// If dependent item is current fastest then set as the fastest available
		if (dependencyRate < fastestRate) {
			fastestRate = dependencyRate;
		}
	}
	return fastestRate;		// Fastest dependent rate of this script
}
//*************************************************************************************
/// Handle the script erorrs
///
//*************************************************************************************
void Remove_Delim(QString pInfo) {
    short length = pInfo.length();
	pInfo[length - 1] = '\0';
}
//*************************************************************************************
/// Notify users of error in the script
///
/// @param[in] - scriptErr, V6ERRORINFO describing the problem
/// @param[in] - errorInMessageListOnly, will only log message to list rather then display dialog
///
/// @return - nothing
//*************************************************************************************
void CScriptInstance::HandleScriptError(V6ERRORINFO &scriptErr, BOOL errorInMessageListOnly) {
	WCHAR szMessage[256], szMsg[256] = { 0 };
//TM - had to format the error string for XSeries in the following format as
//error message dlgs had no meaningful message to them
#ifdef TTR6SETUP
	QString  csErrMessage;
	csErrMessage.LoadString(scriptErr.Code);
	wcsncpy(szMessage, csErrMessage, csErrMessage.size());
	szMessage[csErrMessage.size()] = '\0';
#else
	LoadString(GetModuleHandle(NULL), scriptErr.Code, szMessage, 256);
#endif
	switch (scriptErr.Code) {
	case SS_E_SYNTAX_ERROR: {
		Remove_Delim(scriptErr.Info);
		if (scriptErr.sLineNo > 2) {
            swprintf(szMsg, 256, szMessage, scriptErr.sLineNo - 2, scriptErr.sOffset, scriptErr.Info.toLocal8Bit().data());
		} else {
            swprintf(szMsg, 256, szMessage, scriptErr.sLineNo + 1, scriptErr.sOffset, scriptErr.Info.toLocal8Bit().data());
		}
		break;
	}
	case SS_E_INVALID_NO_OF_PASSED_PARAMS: {
		Remove_Delim(scriptErr.Info);
		if (scriptErr.sLineNo > 2) {
            swprintf(szMsg, 256, szMessage, CStringUtils::GetItemAtPos(scriptErr.Info, 0).toLocal8Bit().data(), scriptErr.sLineNo - 2,
                    scriptErr.sOffset, CStringUtils::GetItemAtPos(scriptErr.Info, 1).toLocal8Bit().data(),
                    CStringUtils::GetItemAtPos(scriptErr.Info, 2).toLocal8Bit().data());
		} else {
            swprintf(szMsg, 256, szMessage, CStringUtils::GetItemAtPos(scriptErr.Info, 0).toLocal8Bit().data(), scriptErr.sLineNo + 1,
                    scriptErr.sOffset, CStringUtils::GetItemAtPos(scriptErr.Info, 1).toLocal8Bit().data(),
                    CStringUtils::GetItemAtPos(scriptErr.Info, 2).toLocal8Bit().data());
		}
		break;
	}
	case LI_E_SCRIPTFUNC_NOTFOUND:
	case LI_E_MATHPACKFUNC_NOTFOUND:
	case SS_E_INVALID_FILECONTENTS:
	case SS_E_INVALID_SCRIPTBLOCK_ID:
	case SS_E_INVALID_STATE:
	case SS_E_INVALID_RETURN_TYPE: {
        swprintf(szMsg, 256, szMessage, scriptErr.Info.toLocal8Bit().data());
		break;
	}
	case SS_E_INVALID_VARIABLE:
	case SS_E_INVALID_FUNCTION:
	case SS_E_READONLY_VARIABLE:
	case SS_E_FUNCTION_NO_RETURN: {
		Remove_Delim(scriptErr.Info);
		if (scriptErr.sLineNo > 2) {
            swprintf(szMsg, 256, szMessage, scriptErr.Info.toLocal8Bit().data(), scriptErr.sLineNo - 2, scriptErr.sOffset);
		} else {
            swprintf(szMsg, 256, szMessage, scriptErr.Info.toLocal8Bit().data(), scriptErr.sLineNo + 1, scriptErr.sOffset);
		}
		break;
	}
	case SS_E_COMPILE_FAILED_FUNC:
	case SS_E_SCRIPTSIZE_EXCEEDED:
	case SS_E_INVALID_ARGUMENT:
	case SS_E_INSUFFICIENT_MEMSIZE: {
        FormatMsg(scriptErr, szMessage, 256);
        swprintf(szMsg, 256, szMessage);
		break;
	}
	case SS_E_VP_ERROR: {
        swprintf(szMsg, 256, szMessage);
		break;
	}
	default: {
		//todo
        swprintf(szMsg, 256, szMessage);
		break;
	}
	}
	// Build a name to identify the script
	QString strIdentifier = "";
	if (m_ident >= SCRIPT_PEN_FIRST && m_ident < SCRIPT_PEN_MAX) {
		// It's a pen script
		strIdentifier = QString::asprintf("P%d script:", (m_ident - SCRIPT_PEN_FIRST) + 1);
	} else {
		// It's a special script type
		switch (m_ident) {
		case SCRIPT_STARTUP: {
			strIdentifier = "Startup script:";
			break;
		}
		case SCRIPT_PROVING: {
			strIdentifier = "";
			break;
		}
		}
	}
	QString strErrorMessage;
    strErrorMessage = strIdentifier + QString::fromWCharArray(szMsg);
	if (errorInMessageListOnly) {
		LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_ERROR, strErrorMessage);
	} else {
        CV6MessageBoxDlg scriptErrMessageBox("Scripts", strErrorMessage);
		scriptErrMessageBox.exec();
	}
}

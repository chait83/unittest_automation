/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Processing
/// @n Filename: ProcessingThread.h
/// @n Desc:	 Main Data processing thread 
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  21  Aristos  1.15.1.3.1.0 9/19/2011 4:51:13 PM  Hemant(HAIL)  
//  Stability recorder source code (JI Release) updated for WatchDog
//  Timer functionality.
//  20  Stability Project 1.15.1.3 7/2/2011 4:59:54 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  19  Stability Project 1.15.1.2 7/1/2011 4:38:41 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  18  Stability Project 1.15.1.1 3/17/2011 3:20:36 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
// $
//
// ****************************************************************
#include "DataProcessing.h"
#include "ThreadInfo.h"
// IMPLEMENT_DYNCREATE(CProcessingThread, QThread)
CProcessingThread::CProcessingThread() {
}
CProcessingThread::~CProcessingThread() {
}
BOOL CProcessingThread::InitInstance() {
	// TODO: perform and per-thread initialization here
	return TRUE;
}
int CProcessingThread::ExitInstance() {
	// TODO: perform any per-thread cleanup here
    QThread::exit();
    return  0 ;
}
const int IDLE_MODE_SLEEP_MS = 20;
// CProcessingThread message handlers
UINT CProcessingThread::ThreadFunc(LPVOID lpParam) {
	CDataProcessing *pDataProcessing = (CDataProcessing*) lpParam;
	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//after each iteration
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	//Notify that the WatchdogTimer that the thread has 
	//started
	if (pThreadInfo != NULL) {
		pThreadInfo->UpdateThreadInfo(AM_DATA_PROCESSING, true);
	}
#ifdef THREAD_ID_SERIAL_LOG
	  WCHAR szDbgMsg[512];
		swprintf( szDbgMsg, L"CProcessingThread::ThreadFunc-Thread id 0x%x, %lu ", GetThreadId(GetCurrentThread()), GetThreadId(GetCurrentThread()));
		OutputDebugString(szDbgMsg);
	#endif
	while (pDataProcessing->GetMode() != DP_MODE_EXIT) {
		// If mode is set to RUN 
		if (pDataProcessing->GetMode() == DP_MODE_RUN) {
			// Run mode has been entered so wait on available data in the pre-process queues
			if (pDataProcessing->WaitToStartProcessing() > 0) {
				DWORD dwTicksTostartAcq = GetTickCount();
				// Data Available, continually process data until run mode is exited
				while (pDataProcessing->GetMode() == DP_MODE_RUN) {
					// pDataProcessing->ProcessEvents();	
					if (pThreadInfo != NULL && pThreadInfo->IsShutdownPreparation() == TRUE) {
						pDataProcessing->ShutdownPrepare();
					} else {
						pDataProcessing->ProcessData(FALSE);
					}
					// sleep for at least one process interval
					sleep(pSYSTIMER->GetDataProcesssleep());
					if (pThreadInfo != NULL) {
						//Update the Thread Counter for the DataProcessing
						//thread after each iteration
						pThreadInfo->UpdateThreadCounter(AM_DATA_PROCESSING);
					}
				}
			}
			/*
			 else
			 {
			 // No pre-process data found, do dummy data in run mode
			 // @todo remove this as will not be needed in final system
			 while(pDataProcessing->GetMode() == DP_MODE_RUN)
			 { 
			 pDataProcessing->DummyPenDataItems();
			 }
			 }
			 */
		}
		if (pThreadInfo != NULL) {
			//Update the Thread Counter for the DataProcessing
			//thread after each iteration
			pThreadInfo->UpdateThreadCounter(AM_DATA_PROCESSING);
		}
		// Message in IDLE mode
		while (pDataProcessing->GetMode() == DP_MODE_IDLE) {
			sleep (IDLE_MODE_SLEEP_MS);
			if (pThreadInfo != NULL) {
				//Update the Thread Counter for the DataProcessing
				//thread after each iteration	
				pThreadInfo->UpdateThreadCounter(AM_DATA_PROCESSING);
			}
		}
	}
	//Update the info that the DataProcessing thread is exiting
	//Hence this thread need not be considered to kick the 
	//watchdog
	if (pThreadInfo != NULL) {
		pThreadInfo->UpdateThreadInfo(AM_DATA_PROCESSING);
	}
	return 0;
}

/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Processing
/// @n Filename: DataProcessing.cpp
/// @n Desc:	 Perform all major operation for data processing
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 89 Aristos 1.82.1.3.1.1 9/21/2011 3:15:56 PM Hemant(HAIL) 
//Updated watchdog threadinfo call check
// 88 Aristos 1.82.1.3.1.0 9/19/2011 4:51:13 PM Hemant(HAIL) 
//Stability recorder source code (JI Release) updated for WatchDog
//Timer functionality.
// 87 Stability Project 1.82.1.3 7/2/2011 4:56:39 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//version of firmware to JF version of firmware.
// 86 Stability Project 1.82.1.2 7/1/2011 4:38:13 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//task. The merging will be done between IL version of firmware and JF
//version of firmware. 
// $
//
// ****************************************************************
#include "math.h"
#include "DataProcessing.h"
#include "FunctionPack.h"
#include "reportManager.h"
#include "ThreadInfo.h"
#include "ChartQueues.h"
#include "V7DbgLogDefines.h"
const float PI = (float) 3.1415926535;
const int WATCHDOG_LOW_MEMORY_LIMIT = 1000;
extern ULONG glb_MsgCntPan;
extern ULONG glb_MsgCntCht;
extern ULONG glb_MsgCntMsg;
extern ULONG glb_MsgCntLog;
extern ULONG glb_MsgCntOth;
extern ULONG glb_QMBlockRel;
extern ULONG glb_QMHeartBeat;
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//******************************************************
/// CDataProcessing Constructor
///
//******************************************************
CDataProcessing::CDataProcessing(T_MODULE_ID moduleId) : CV6ActiveModule(moduleId) {
	m_NoCoverageFoundCounter = 0;
}
//******************************************************
/// CDataProcessing CleanUp
///
//******************************************************
BOOL CDataProcessing::CleanUp(void) {
	return TRUE;
}
//******************************************************
/// Primary initialisation for Module, before tread is started
///
/// @return - T_V6ACTMOD_RETURN_VALUE
//******************************************************
T_V6ACTMOD_RETURN_VALUE CDataProcessing::PerformPrimaryInitialisation(void) {
	T_V6ACTMOD_RETURN_VALUE retVal = V6ACTMOD_OK;
	m_DPMode = DP_MODE_IDLE;		// Set data processing mode into startup
	// Get a handle on the Pre Process Queues singleton object
	m_pPreProcQ = CPPQManager::GetHandle();
	if (m_pPreProcQ == NULL) {
		retVal = V6ACTMOD_INITIALISATION_FAILED;
	}
	m_pPenManager = CPenManager::GetHandle();
	if (m_pPenManager == NULL) {
		retVal = V6ACTMOD_INITIALISATION_FAILED;
	}
	m_pEventManager = CEventManager::GetHandle();
	if (m_pEventManager == NULL) {
		retVal = V6ACTMOD_INITIALISATION_FAILED;
	}
#ifndef V6IOTEST
	m_pAMSTimers = CAMS2750TimerCtrlMgr::Instance();
	if (m_pAMSTimers == NULL) {
		retVal = V6ACTMOD_INITIALISATION_FAILED;
	}
	m_pTCTimers = CAMS2750TCStatusMgr::Instance();
	if (m_pTCTimers == NULL) {
		retVal = V6ACTMOD_INITIALISATION_FAILED;
	}
#endif
	return retVal;
}
//******************************************************
/// Secondary Initialisation, start thread
///
/// @return - T_V6ACTMOD_RETURN_VALUE 
//******************************************************
T_V6ACTMOD_RETURN_VALUE CDataProcessing::PerformSecondaryInitialisation(void) {
	T_V6ACTMOD_RETURN_VALUE retVal = V6ACTMOD_OK;
#ifdef STARTUP_LOGGING
	WCHAR InitLogFileName[ 256 ];
	WCHAR InitLogString[512];
	CStorage kLogFile;
	QFileDevice::FileError kFileEx;
	int iPathLen = 256;
	pDALGLB->GetPath(	static_cast< T_STORAGE_PATH >( IDS_INTERNAL_SD ), 
						InitLogFileName,
						256,
						&iPathLen );
	wcsncat( InitLogFileName, 256, L"DataProcessingLog.txt", (256 - wcslen( InitLogFileName )) );
	
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();
		wcscpy(InitLogString,L"--------Data Processing Initialisation started-------\n");		
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		wcscpy(InitLogString,L"Initialise the Script Manager\n");
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	// Get handle on Script Manager, this is a Global to the Processing system, defined in Scripts.cpp and .h
	pGlbScriptManager = CScriptManager::GetHandle();
	if (NULL == pGlbScriptManager) {
		return V6ACTMOD_INITIALISATION_FAILED;
	}
	pGlbScriptManager->Initialise();	// Initialise the script manager
#ifdef STARTUP_LOGGING
	wcscpy(InitLogString,L"Initialise the Pen Manager\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();		
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	// Initialise Pen and Event manager
	m_pPenManager->Initialise();
#ifdef STARTUP_LOGGING
	wcscpy(InitLogString,L"Initialise the Event Manager\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();		
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	m_pEventManager->Initialise();
#ifndef V6IOTEST
#ifdef STARTUP_LOGGING
	wcscpy(InitLogString,L"Initialise the Tabular\n");
	if( kLogFile.Open( InitLogFileName,
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	// Initialise tabular readings
	pTABULAR->Initialise();
#ifdef STARTUP_LOGGING
	wcscpy(InitLogString,L"Initialise the TUS Manager\n");
	if( kLogFile.Open( InitLogFileName,
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	// Initialise the TUS Manager
	pTUSMGR->Initialise();
#ifdef STARTUP_LOGGING
	wcscpy(InitLogString,L"Initialise the AMS Timers\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();		
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	m_pAMSTimers->Initialise();
#ifdef STARTUP_LOGGING
	wcscpy(InitLogString,L"Initialise the TC Timers\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();		
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	m_pTCTimers->Initialise();
#endif
#ifdef STARTUP_LOGGING
	wcscpy(InitLogString,L"Get the Memory Status \n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();		
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	// Get handle on general data items update in processing
	m_pIdleTimer =
			reinterpret_cast<CDataItemGeneral*>(pDIT->GetDataItemPtr(DI_GENERAL, DI_GENTYPE_GENERAL, DI_GEN_IDLE));
	m_pMemLoad = reinterpret_cast<CDataItemGeneral*>(pDIT->GetDataItemPtr(DI_GENERAL, DI_GENTYPE_GENERAL,
			DI_GEN_MEM_LOAD));
	m_pMemTotal = reinterpret_cast<CDataItemGeneral*>(pDIT->GetDataItemPtr(DI_GENERAL, DI_GENTYPE_GENERAL,
			DI_GEN_MEM_PHYS_TOTAL));
	m_pMemAvail = reinterpret_cast<CDataItemGeneral*>(pDIT->GetDataItemPtr(DI_GENERAL, DI_GENTYPE_GENERAL,
			DI_GEN_MEM_PHYS_AVAIL));
	m_pVMemTotal = reinterpret_cast<CDataItemGeneral*>(pDIT->GetDataItemPtr(DI_GENERAL, DI_GENTYPE_GENERAL,
			DI_GEN_MEM_VIRT_TOTAL));
	m_pVMemAvail = reinterpret_cast<CDataItemGeneral*>(pDIT->GetDataItemPtr(DI_GENERAL, DI_GENTYPE_GENERAL,
			DI_GEN_MEM_VIRT_AVAIL));
	m_pVMemLowest = reinterpret_cast<CDataItemGeneral*>(pDIT->GetDataItemPtr(DI_GENERAL, DI_GENTYPE_GENERAL,
			DI_GEN_MEM_VIRT_LOWTIDE));
	m_pQMCPanel = reinterpret_cast<CDataItemGeneral*>(pDIT->GetDataItemPtr(DI_GENERAL, DI_GENTYPE_GENERAL,
			DI_GEN_Q_MCPAN));
	m_pQMCMess = reinterpret_cast<CDataItemGeneral*>(pDIT->GetDataItemPtr(DI_GENERAL, DI_GENTYPE_GENERAL,
			DI_GEN_Q_MCMES));
	m_pQMCChart = reinterpret_cast<CDataItemGeneral*>(pDIT->GetDataItemPtr(DI_GENERAL, DI_GENTYPE_GENERAL,
			DI_GEN_Q_MCCHA));
	m_pQMCLog =
			reinterpret_cast<CDataItemGeneral*>(pDIT->GetDataItemPtr(DI_GENERAL, DI_GENTYPE_GENERAL, DI_GEN_Q_MCLOG));
	m_pQMCOther = reinterpret_cast<CDataItemGeneral*>(pDIT->GetDataItemPtr(DI_GENERAL, DI_GENTYPE_GENERAL,
			DI_GEN_Q_MCOTH));
	m_pQMCBlkRel = reinterpret_cast<CDataItemGeneral*>(pDIT->GetDataItemPtr(DI_GENERAL, DI_GENTYPE_GENERAL,
			DI_GEN_Q_BLK_REL));
	m_pQMCHeart =
			reinterpret_cast<CDataItemGeneral*>(pDIT->GetDataItemPtr(DI_GENERAL, DI_GENTYPE_GENERAL, DI_GEN_Q_HB));
	pDEVICE_INFO->GetMemoryStatus();
	m_pMemTotal->SetValue( pDEVICE_INFO->GetMemoryTotalPhysicalK());
	m_pMemAvail->SetValue( pDEVICE_INFO->GetMemoryAvailablePhysicalK());
	m_pMemLoad->SetValue( pDEVICE_INFO->GetMemoryLoadPercentage());
	m_pVMemTotal->SetValue( pDEVICE_INFO->GetMemoryTotalVirtualK());
	m_pVMemAvail->SetValue( pDEVICE_INFO->GetMemoryAvailableVirtualK());
	m_pVMemLowest->SetValue( pDEVICE_INFO->GetMemoryAvailableVirtualK());
#ifdef STARTUP_LOGGING
	wcscpy(InitLogString,L"Initialise Complete\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();		
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	return retVal;
}
//******************************************************
/// MESSAGE HANDLER CALLBACK 
/// Start normal operation after a config change or startup
///
/// @return - T_V6ACTMOD_RETURN_VALUE 
//******************************************************
T_V6ACTMOD_RETURN_VALUE CDataProcessing::NormalOperation() {
	m_DPMode = DP_MODE_RUN;
	return V6ACTMOD_OK;
}
//******************************************************
/// MESSAGE HANDLER CALLBACK 
/// Prepare for a configuration change
///
/// @return - T_V6ACTMOD_RETURN_VALUE 
//******************************************************
T_V6ACTMOD_RETURN_VALUE CDataProcessing::SetupConfigChangePreparation() {
	// At this stage the Input Scheduler would have gathered data from all cards and 
	// placed in pre process queues. The Data Processing thread must now process the 
	// remaining data in the pre-process queues and idle until a setup change complete is issued
	ProcessData(TRUE);		// Process all remaining Data
	m_DPMode = DP_MODE_IDLE;
	return V6ACTMOD_OK;
}
//******************************************************
/// MESSAGE HANDLER CALLBACK 
/// Configuration change completed, use new config
///
/// @return - T_V6ACTMOD_RETURN_VALUE 
//******************************************************
T_V6ACTMOD_RETURN_VALUE CDataProcessing::SetupConfigChangeComplete() {
	// update the chart speeds in the event they have changed
	CGeneralSetupConfig *pkGenCfg = pSETUP->GetGeneralSetupConfig();
	T_PRECPROFILE ptChartCfg = pkGenCfg->GetProfileBlock(CONFIG_COMMITTED);
	if (ptChartCfg != NULL) {
		CChartQManager::SetChartSpeed(CQT_STRIP, ptChartCfg->Chart.FastSpeed, SPEED_FAST);
		CChartQManager::SetChartSpeed(CQT_STRIP, ptChartCfg->Chart.MedSpeed, SPEED_MEDIUM);
		CChartQManager::SetChartSpeed(CQT_STRIP, ptChartCfg->Chart.SlowSpeed, SPEED_SLOW);
		CChartQManager::SetChartSpeed(CQT_CIRCULAR, ptChartCfg->Chart.CircFastSpeed, SPEED_FAST);
		CChartQManager::SetChartSpeed(CQT_CIRCULAR, ptChartCfg->Chart.CircMedSpeed, SPEED_MEDIUM);
		CChartQManager::SetChartSpeed(CQT_CIRCULAR, ptChartCfg->Chart.CircSlowSpeed, SPEED_SLOW);
	}
	// Configuration changes for Pens
	m_pPenManager->ImplementConfiguration();
	// Configuration changes for Events
	m_pEventManager->ImplementConfiguration();
#ifndef V6IOTEST
	// Configuration changes for Tabular Data
	pTABULAR->Configure();
	// Configuration changes for TUS Manager
	pTUSMGR->Configure();
	// Configuration changes for AMS2750 timers
	m_pAMSTimers->Configure();
	// Configuration changes for AMS2750 TC timers
	m_pTCTimers->Configure();
#endif
	m_pMemTotal->SetValue( pDEVICE_INFO->GetMemoryTotalPhysicalK());
	m_pVMemTotal->SetValue( pDEVICE_INFO->GetMemoryTotalVirtualK());
#if (INCLUDE_Q_INTEGRITY_CHECK == 1)
	///***************************** DEBUGGING CODE FOR Q integrity ******
	qDebug("*** Starting queue integrity check\n" );
	CTV6Timer normTimer( TIMER_NORMAL_RES );
	normTimer.StartTimer();
	CQueueManager *pQIntegrityChecker = CQueueManager::GetHandle();
	T_QMMEMMAN_RETURN_VALUE integrityReturn = pQIntegrityChecker->BlockQueueIntegCheck();
	if( integrityReturn != QMMEMMAN_OK )
	{
		pDALGLB->BackupSRAMToDiskCopy();
		DebugBreak();
		V6CriticalMessageBox(NULL, L"NV0066.BIN written recorder now stopped", L"Q Integrity failed", MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST );
	}
	normTimer.StopTimer();
	qDebug("Q Integrity check too %dms to complete\n", (ULONG)normTimer.GetTimeInMilliSec( TIMER_SINGLE ) );
	///****************************** DEBUGGING CODE FOR Q integrity ******
#endif
	m_DPMode = DP_MODE_IDLE;
	return V6ACTMOD_OK;
}
//******************************************************
/// Shutdown has been requested close down all processes
/// MESSAGE HANDLER CALLBACK 
/// ready for final shutdown
///
/// @return - T_V6ACTMOD_RETURN_VALUE 
//******************************************************
T_V6ACTMOD_RETURN_VALUE CDataProcessing::ShutdownPreparation() {
	ProcessData(TRUE);		// Process all remaining Data
	m_pEventManager->PrepareForConfigChange();
	m_DPMode = DP_MODE_IDLE;
	return V6ACTMOD_OK;
}
//******************************************************
/// Final shutdown, release all resources allocated in module
/// MESSAGE HANDLER CALLBACK 
///
/// @return - T_V6ACTMOD_RETURN_VALUE 
//******************************************************
T_V6ACTMOD_RETURN_VALUE CDataProcessing::Shutdown(void) {
	CleanUp();
	m_DPMode = DP_MODE_EXIT;
	return V6ACTMOD_OK;
}
//******************************************************
/// Get the current execution mode of the data proicessing 
/// module. This will call ManualMessageHandler() which will receive messages from 
/// the control sequencer and call one of the message handlers above. Each message
/// handler will set the m_DPMode.
///
/// @return - T_DATAPROCESS_MODE current execution mode 
//******************************************************
T_DATAPROCESS_MODE CDataProcessing::GetMode() {
	ManualMessageHandler();
	return m_DPMode;
}
//******************************************************
/// Wait for the IO Scheduler and PreProcess Queues to provide input information
/// allowing data processing to start
///
/// @return Minimum coverage tick that we can start process from
/// 
//******************************************************
LONGLONG CDataProcessing::WaitToStartProcessing() {
	// Init coverages 
	m_minCoverage = 0;
	m_maxCoverage = 0;
	LONGLONG tempMaxCoverage = 0;
	int testCoverageTimeout = 0;
	/// Wait on the Pre process queues until they report data available
	/// this is protected with a timeout.
	while (m_pPreProcQ->GetMinSystemTickCoverage(m_minCoverage) == PPQM_NO_COVERAGE_AVAILABLE) {
		// If TEST_FOR_MIN_COVERAGE_TIMEOUT has been exceeded and still no min coverage available, reply with failure
		if (testCoverageTimeout++ > TEST_FOR_MIN_COVERAGE_TIMEOUT) {
			//MarkD: test for digital only
			if (m_pPreProcQ->GetMinDigitalTickCoverage(m_minCoverage) == PPQM_NO_COVERAGE_AVAILABLE) {
				m_minCoverage = NO_MIN_COVERGE;
			}
			break;
		}
		sleep(TEST_FOR_MIN_COVERAGE_TIMEOUT_SLEEP);		// Allow IO Sched to provide data
		// Debug trace
		if (testCoverageTimeout % 5 == 0) {
			qDebug(" No Coverage available at Tick %d \n", (LONG) pSYSTIMER->GetCurrentSystemTimeTick100());
		}
	}
	if (m_minCoverage > 0) {
		// Set the start of the processing coverage to the minimum available 
		//from the pre process queues
		pSYSTIMER->SetAbsoluteProcessTimeSlice(m_minCoverage);
		// Set up the maxminum coverage available form the PPQ into a temp var
		// as we will get the max coverage correctly in GetNewMaximumCoverage we don't want to preload otherwise it misses a step
		/// @todo AK, we might want to make sure we have some coverage here, but we might want to remove this later.
		m_pPreProcQ->GetMaxSystemTickCoverage(tempMaxCoverage);
	}
	//qDebug(" PPQ coverage is min=%d max=%d rate=%d\n",(int)m_minCoverage,(int)tempMaxCoverage,pSYSTIMER->GetCurrentProcessInterval() );
	return m_minCoverage;
}
//******************************************************
/// Request the PreProcess queues to populate
///
/// @return TRUE if anythign is left to process, otherwise FALSE
/// 
//******************************************************
BOOL CDataProcessing::RequestTimeSliceDITPopulation() {
	BOOL retVal = FALSE;
	// If there are process slices available from the pre-process queues then
	// request that the PPQ's populate the DIT with the required slice
	if (m_processSlices > 0) {
		// Check to see if a whole second has rolled
		if (static_cast<int>(pSYSTIMER->GetElapsedProcTimeInSeconds()) != m_lastUpdateInElapsedSeconds) {
			m_lastUpdateInElapsedSeconds = static_cast<int>(pSYSTIMER->GetElapsedProcTimeInSeconds());
			// HiJack Idle timer to show number of process slices being done
			m_pIdleTimer->SetValue((float) m_processSlices);
			// Update memory statistics
			pDEVICE_INFO->GetMemoryStatus();
			m_pMemAvail->SetValue( pDEVICE_INFO->GetMemoryAvailablePhysicalK());
			m_pVMemAvail->SetValue( pDEVICE_INFO->GetMemoryAvailableVirtualK());
			// Add watchdog code for low memory limit
			CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
			if (pThreadInfo != NULL) {
				if ( pDEVICE_INFO->GetMemoryAvailableVirtualK() < WATCHDOG_LOW_MEMORY_LIMIT) {
					pThreadInfo->SetMemoryLow(TRUE);
					//				pDALGLB->PerformReboot();
				} else {
					pThreadInfo->SetMemoryLow(FALSE);
				}
			}
			m_pMemLoad->SetValue( pDEVICE_INFO->GetMemoryLoadPercentage());
			// Keep low tide mark of virtual memory
			if (m_pVMemLowest->GetFPValue() > pDEVICE_INFO->GetMemoryAvailableVirtualK()) {
				m_pVMemLowest->SetValue( pDEVICE_INFO->GetMemoryAvailableVirtualK());
			}
			m_pEventManager->ProcessScreenSaver();		// Process the screen saver every 1 second approx
			///******************** debug for queues
			m_pQMCPanel->SetValue((float) glb_MsgCntPan);		// Set the variables for last 1 sec
#ifndef DBL_AUTO_OPS_THREAD_HB		
			m_pQMCMess->SetValue((float) glb_MsgCntCht);
#else
			m_pQMCMess->SetValue( (float)glb_MsgCntMsg );
			m_pQMCChart->SetValue( (float)glb_MsgCntCht );
#endif
			m_pQMCLog->SetValue((float) glb_MsgCntLog);
			m_pQMCOther->SetValue((float) glb_MsgCntOth);
			m_pQMCBlkRel->SetValue((float) glb_QMBlockRel);
			m_pQMCHeart->SetValue((float) glb_QMHeartBeat);
#ifndef DBL_AUTO_OPS_THREAD_HB //Altenrate Usage is -- Auto Ops thread Heartbeat monitoring
			glb_MsgCntCht = 0;
#endif
#ifndef DBL_STORAGE_CS_THREAD
			glb_MsgCntPan = 0;							// Reset queue stats
			//Reset only when not used for THread ID tracking of CStorage CS
			glb_MsgCntMsg = 0;
#endif
#ifndef DBL_STORAGE_CS_THREAD
			glb_MsgCntLog = 0;
#endif
			// glb_MsgCntOth = 0; Don't reset not a count
			glb_QMBlockRel = 0;
			// glb_QMHeartBeat = 0; this is a stage not a count
			///********************** debug for queues
		}
		// Update system timer to the next available time slice (real time)
		pSYSTIMER->UpdateToNextProcessingTimeSlice();
		m_minCoverage += pSYSTIMER->GetCurrentProcessInterval();
		m_processSlices--;
		// Request the PPQ's populate the system
		m_pPreProcQ->PopulateDataItemTable(static_cast<USHORT>(pSYSTIMER->GetCurrentProcessInterval()));
		retVal = TRUE;
	}
	return retVal;
}
//******************************************************
/// Get a new maximum coverage if exists, will calculate if there are any
/// available data to process, and if so how many process itterations
///
/// @return TRUE if data available to process, otherwise False
/// 
//******************************************************
BOOL CDataProcessing::GetNewMaximumCoverage() {
	BOOL retVal = FALSE;
	LONGLONG newMaxCoverage = 0;	// New maximum coverage for this pass
	int newTicksToProcess = 0;		// New ticks to process (new max - old max)
	// *** Debug only test for number of time coverage probed @todo remove
	static ULONG SlicesExecuted = 0;
#ifdef DEBUG
	testNumTimesCalled++;
#endif
	// Check if there is any data reading coverage available from the pre process queues
	if (m_pPreProcQ->GetMaxSystemTickCoverage(newMaxCoverage) != PPQM_NO_COVERAGE_AVAILABLE) {
		// Data is available, but make sure it's not the same as last time
		if (newMaxCoverage != m_maxCoverage) {
			// Calculate the coverage since last time and the number of
			// process cycles the current coverage will provide.
			m_maxCoverage = newMaxCoverage;
			newTicksToProcess = (int) (m_maxCoverage - m_minCoverage);
			if (newTicksToProcess < 0) {
				qDebug(" PPQ ERROR min bigger then max min=%d max=%d\n", (int) m_minCoverage, (int) m_maxCoverage);
			} else {
#ifdef DEBUG
				testNumTimesUsed++;
				//qDebug("Cov NC(%d) OC(%d) Cdiff(%d) TimeDiff(%d) Called(%d) Used(%d) slices(%d)\n ", (ULONG)newMaxCoverage, (ULONG)m_minCoverage, (ULONG)newTicksToProcess, pSYSTIMER->TimeSlicesBetweenProcAndRealtime100(), testNumTimesCalled, testNumTimesUsed, SlicesExecuted );
#endif					
				m_processSlices = newTicksToProcess / pSYSTIMER->GetCurrentProcessInterval();
				SlicesExecuted += m_processSlices;
				if (m_processSlices > 0) {
					retVal = TRUE;
				}
			}
		}
	}
	return retVal;
}
//******************************************************
/// Process the Data for all available time slices pending in 
/// the pre process queues
///
/// @param[in] - IsLastDataProcess, TRUE if last process before config change or shutdown
///									FALSE if normal
/// @return nothing
//******************************************************
void CDataProcessing::ProcessData(BOOL IsLastDataProcess) {
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	if (GetNewMaximumCoverage() == TRUE) {
		m_NoCoverageFoundCounter = 0;
		while (RequestTimeSliceDITPopulation() == TRUE) {
			if (pThreadInfo != NULL) {
				//Update the Thread Counter for the DataProcessing
				//thread after each iteration
				pThreadInfo->UpdateThreadCounter(AM_DATA_PROCESSING);
			}
			// Perform all the processing on the Pen values, all pen data items updated
			m_pPenManager->ProcessPens();
			// Process the totalisers
			m_pPenManager->ProcessTotals();
			// Process all enabled alarms for all Pens
			m_pPenManager->ProcessAlarms();
			// Process the event queue for this timeslice
			m_pEventManager->Process();
#ifndef V6IOTEST
			// AMS2750 Process the TUS
			pTUSMGR->ProcessTUS();
			// AMS2750 Process the TC Timer usage tracking
			m_pTCTimers->Process();
			// AMS2750 Process the furnace usage tracking
			m_pAMSTimers->Process();
			// Update the tabular data
			pTABULAR->AddReadings();
#endif
			// Add information to the chart queues
			m_pPenManager->ProcessPenChartQueues();
			/// Do logging 
			m_pPenManager->ProcessLogging();
#ifdef UNDER_CE
			if((m_pPenManager->IsRealTimeData())&& (m_pPenManager->IsRTConfigExist()))
			{
			 //Process the realtime data(last step)
			 m_pPenManager->ProcessRealTimeData();
			}
#endif
		}
	} else {
		// There was no covereage from the cards
		m_NoCoverageFoundCounter++;
		if (m_NoCoverageFoundCounter > 300) {
            V6WarningMessageBox(NULL, "No coverage from queues", "Data processing failed", MB_OK );
			m_NoCoverageFoundCounter = 0;
		}
#ifndef DBL_AUTO_OPS_THREAD_HB	
		m_pQMCChart->SetValue((float) m_NoCoverageFoundCounter);
#endif
	}
	// Check if this is a the last data process before shurtdown required
	if (IsLastDataProcess == TRUE) {
		// Yes, so we need to flush and stop logging directly
		m_pPenManager->StopAllLoggingDirect();
		// wait for any reports to be processed
		const USHORT usWAIT_TIMEOUT_IN_SECS = 60;
		USHORT usElapsedTime = 0;
#ifndef V6IOTEST
		CReportManager *pkReportMgr = CReportManager::GetHandle();
		while (pkReportMgr->ReportsBeingProcessed() && (usElapsedTime < usWAIT_TIMEOUT_IN_SECS)) {
			sleep(1000);
			++usElapsedTime;
			qDebug("Waiting for report generation to finish");
		}
#endif
		// check if the timeout was reached
		if (usElapsedTime >= usWAIT_TIMEOUT_IN_SECS) {
			qDebug("Report generation did not finish finish after %u seconds", usElapsedTime);
		}
	}
}
//******************************************************
/// Process the Event system, both timers and cause queue
///
/// @return nothing
/// 
//******************************************************
void CDataProcessing::ProcessEvents() {
	// m_pEventManager->Process(); currently done in CDataProcessing::ProcessData() but timers will be added here
}
//******************************************************
/// Dummy processing, will be removed
///
//******************************************************
#define MSEC_DELAY_FOR_DIT	100
void CDataProcessing::DummyPenDataItems() {
	static int traceDisp = 0;
	static float nextVal = 0;
	static CTVtime dummyTime;
	float PenVal;
	CDataItem *pPen;
	for (int i = 0; i < V6_MAX_PENS; i++) {
		/*		PenVal = (sin(nextVal+i)*50)+50;
		 nextVal += (PI/100000);
		 if( nextVal > (PI*2) )
		 nextVal -= (PI*2); */
		PenVal = (float) i + 0.123456789F;
		pPen = pGlbDIT->GetDataItemPtr(DI_PEN, 0, i);
		if (pPen != NULL) {
			pPen->SetValue(PenVal);
			pPen->SetTime( pSYSTIMER->GetCurrentProcessTimeInMicroSec());
		}
	}
	sleep(pSYSTIMER->GetCurrentProcessInterval() * 10);
	pSYSTIMER->UpdateToNextProcessingTimeSlice();
	if (++traceDisp > 1200) {
		LONGLONG sysTick = pSYSTIMER->GetCurrentSystemTimeTick100();
		float secsSinceStartup = pSYSTIMER->GetElapsedRealTimeInSeconds();
		qDebug("Seconds since Power On = %f sysTick %d\n", secsSinceStartup, (ULONG) sysTick);
		traceDisp = 0;
	}
}
//******************************************************
/// ShutdownPrepare
///
//****************************************************
void CDataProcessing::ShutdownPrepare() {
	ShutdownPreparation();
}

/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Processing
/// @n Filename: PreTrigger.h
/// @n Desc:	 Manage the pre-trigger functionality
///				 
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  3 Stability Project 1.0.1.1 7/2/2011 4:59:47 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  2 Stability Project 1.0.1.0 7/1/2011 4:27:50 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  1 V6 Firmware 1.0 10/1/2009 12:51:27 PM  Build Machine  
// $
//
// ****************************************************************
#ifndef __PRETRIGGER_H__
#define __PRETRIGGER_H__
#include "V6defines.h"
#include "V6globals.h"
#include "V6Config.h"
#include "LogChannel.h"			
//**Class*********************************************************************
///
/// @brief Pre Trigger control
/// 
/// The Pre Trigger class controls the pretriggering for a pen
///
//****************************************************************************
class CPenPreTrigger {
public:
	CPenPreTrigger();
public:		// API methods
	void CleanUp();									///< Cleaup any dynamic allocations within the pre trigger object
	BOOL AllocateBuffer(ULONG rate, int minutes);		///< Allocate the buffer to store the pre trigger information in
	void AddReading(float reading, LONGLONG lastTime);	///< Add a new reading into the cyclic volatile buffer
	void ResetBuffer();									///< Reset the buffer for reuse
	BOOL GenerateLogFile();
	void RemoveLogRecBuffer();							///< Remove the log record buffer
	static WCHAR* GetFileName(int penInstance);			///< Get filename
public:		// Member variables
	BOOL m_Enabled;					///< Set if pre triggering is enabled for this pen
	int m_penNumber;				///< Pen Number of this trigger
	int m_rateDivDownCount;			///< pre-trigger logging rate divide down counter
	int m_rateDivDownReload;		///< pre-trigger divide down reload counter
	ULONG m_alarmRateTicks;			///< Alarm rate in system ticks
	ULONG m_alarmRateTenths;		///< Alarm rate in mSec tenths
private:	// Methods
	void PreTriggerDataFileError(const QString &rstrERROR);	///< File error message display
private:	// Member variables
	float *m_Buffer;				///< Pre-Trigger buffer containing all of the readings
	int m_lastIndex;				///< index into m_Buffer[] of the last reading added
	LONGLONG m_lastTime;			///< last time recorded with last reading (time of latest reading in buffer)
	int m_numEntries;				///< Current number of entries in pre-trigger buffer
	int m_bufferSize;				///< size of the buffer in number of entries
	CTVtime m_startTime;			///< Running start time for the new block
};
#endif //__PRETRIGGER_H__

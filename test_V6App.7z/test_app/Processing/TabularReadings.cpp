/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	Processing
/// @n Filename: TabularReadings.cpp
/// @n Description: Tabular Readings for Tabular display Object
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 8	Aristos	1.0.1.3.1.2 9/21/2011 3:17:27 PM	Hemant(HAIL) 
//		Updated watchdog threadinfo call check
// 7	Aristos	1.0.1.3.1.1 9/21/2011 2:52:36 PM	Hemant(HAIL) 
//		Updated watchdog threadinfo call check
// 6	Aristos	1.0.1.3.1.0 9/19/2011 4:51:13 PM	Hemant(HAIL) 
//		Stability recorder source code (JI Release) updated for WatchDog
//		Timer functionality.
// 5	Stability Project 1.0.1.3	7/2/2011 5:01:59 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// $
//
// **************************************************************************
#include <float.h>
#include <math.h>
#include "MathUtils.h"
#include "V6globals.h"
#include "TabularReadings.h"
#include "ThreadInfo.h"

QMutex CTabularReadings::ms_hCreationMutex;
// Static const/initialsation
std::unique_ptr<CTabularReadings> CTabularReadings::ms_kTabularReadings;
//****************************************************************************
///
/// Singleton Accessor/Creator
///
/// @return A pointer to the singleton instance of the class
/// 
//****************************************************************************
CTabularReadings* CTabularReadings::Instance() {
	// check if the pointer exists yet
	if (ms_kTabularReadings.get() == NULL) {
		DWORD waitSingleObjectResult = WAIT_OBJECT_0;
		// An instance has yet to be completed
		if (ms_hCreationMutex.tryLock(g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS)) {
			if (NULL == ms_kTabularReadings.get()) {
				// not been created yet therefore create one now
				std::unique_ptr<CTabularReadings> kTabularReadings(new CTabularReadings);
				ms_kTabularReadings = kTabularReadings;
			}
			ms_hCreationMutex.unlock();
        } else {
            V6WarningMessageBox(NULL, "CTabularReadings WaitForSingleObject Error", "Error", MB_OK);
		}
		// Close the Mutex as no longer required
		//No need to close the mutex in Qt
	}
	return ms_kTabularReadings.get();
}
//****************************************************************************
///
/// Constructor
/// 
//****************************************************************************	
CTabularReadings::CTabularReadings() {
}
//****************************************************************************
///
/// Destructor
/// 
//****************************************************************************	
CTabularReadings::~CTabularReadings() {
	//deletion of mutex not required
}
//****************************************************************************
///
/// Initialise the Tabular readings data, set SRAM signature
/// 
/// @return nothing
///
//****************************************************************************
void CTabularReadings::ResetAllTabularData() {
	memset(m_pNVTabularData, 0, sizeof(T_TABULAR_DATA));
	m_pNVTabularData->signature = TABREAD_SIG;
}
//****************************************************************************
///
/// Initialise the Tabular readings data, attach to SRAM and reset data if required
/// 
/// @return true if SRAM access successful
///
//****************************************************************************	
const bool CTabularReadings::Initialise() {
	// Get access to the tabular data in SRAM
	CSRAMManager *pSRAM = CSRAMManager::GetHandle();
	CSRAMRegion *pRegion = NULL;
	CSRAMManager::regionError requestReturn = pSRAM->RequestRegion(REGION_TABULAR, &pRegion);
	if (requestReturn != CSRAMManager::REGION_OKAY) {
        V6CriticalMessageBox(NULL, "REGION_TABULAR SRAM request failed", "Init tabular SRAM", MB_OK );
		return FALSE;
	}
	m_pNVTabularData = reinterpret_cast<T_TABULAR_DATA*>(pRegion->GetAddress());
	// If SRAM region has not been used before or a data reset is required, then reset the tabular data	
	if (m_pNVTabularData->signature
			!= TABREAD_SIG|| SRAM_STATE_FIRSTUSE == pRegion->GetAutoState() || pSYSTEM_INFO->IsDataResetRequested() == TRUE) {
		// Reset all tabular data
		ResetAllTabularData();
	}
	qDebug("Tabular size = %d", sizeof(T_TABULAR_DATA));
	pRegion->SetAutoStateToNormal();
	return TRUE;
}
//****************************************************************************
///
/// All updates and setting required after a configuration has been changed
/// 
/// @return nothing
///
//****************************************************************************	
void CTabularReadings::Configure() {
	// Get pointer to tabular displ,ay configuration information.
	T_PRECPROFILE ptProfile = pSETUP->GetGeneralSetupConfig()->GetProfileBlock(CONFIG_COMMITTED);
	m_pTDConfig = &ptProfile->TabularDisp;
	// Setup access to all data items
	for (int dataItemIndex = 0; dataItemIndex < V6_MAX_PENS; dataItemIndex++) {
		m_pPenDataItem[dataItemIndex] = (CDataItemPen*) pGlbDIT->GetDataItemPtr(DI_PEN, 0, dataItemIndex);
	}
	// After a configuration change, clear any exiting event triggers
	m_eventTriggerFired = FALSE;
	// Always Update after a config change
	SetUpdateRequired(TRUE);
	// Its the first time though so setup a flag for time syncronisation
	m_FirstIn = TRUE;
}
//**********************************************************************
/// Set the status of a reading in NV for a particualr line and reading
///
/// @param[in]		penNumber, zero based pen index to set related status of
/// @param[in]		status, T_DATAITEM_STATUS of the status to set
/// @param[in]		dataIndex, zero based index of the data line containing the readings and status
///
/// @return T_DATAITEM_STATUS status or the request reading
//**********************************************************************
void CTabularReadings::SetStatus(int penNumber, T_DATAITEM_STATUS status, int dataIndex) {
	int statusIndex = penNumber / 2;		// Get the status Byte we need to address
	int statusNibble = penNumber % 2;		// Get the nibble we want to address 1 or 0
	m_pNVTabularData->data[dataIndex].status[statusIndex] = SetNibble(
			m_pNVTabularData->data[dataIndex].status[statusIndex], (UCHAR) status, statusNibble);
}
//**********************************************************************
/// Get the status of a reading from NV for a particualr line
///
/// @param[in]		penNumber, zero based pen index to get related status of
/// @param[in]		dataIndex, zero based index of the data line containing the readings and status
///
/// @return T_DATAITEM_STATUS status or the request reading
//**********************************************************************
T_DATAITEM_STATUS CTabularReadings::GetStatus(int penNumber, int dataIndex) {
	int statusIndex = penNumber / 2;		// Get the status Byte we need to address
	int statusNibble = penNumber % 2;		// Get the nibble we want to address 1 or 0
	return static_cast<T_DATAITEM_STATUS>(GetNibble(m_pNVTabularData->data[dataIndex].status[statusIndex], statusNibble));
}
//****************************************************************************
///
/// Method that sets the internal index to reference the newest available set of readings
/// 
/// @return nothing
///
//****************************************************************************	
void CTabularReadings::AddReadings() {
	if (m_FirstIn == TRUE) {
		// Setup the reload counter, this is in timeslices per second multiplied by the number of seconds required
		m_reloadCountdown = (m_pTDConfig->UpdatePeriod * pSYSTIMER->GetProcessSlicesPerSecond()) - 1;
		m_countDown = 0;
		m_FirstIn = FALSE;
		// If we have alignment enabled, then we will autoalign the readings to the nearest minute or hour.
		// if the reading interval is less then 2 minutes, align to the nearest minute, however if it is 2 minutes
		// or more then align to the nearest hour. 
		if (m_pTDConfig->Align == TRUE) {
			LONGLONG targetTime = pSYSTIMER->GetCurrentProcessTimeInMicroSec();
			// If the update period less then 2 minutes align with Minute, otherwise align with hour
			if (m_pTDConfig->UpdatePeriod < 120) {
				// If the update period is smaller then 2 minutes, align to the nearest minute
				LONGLONG usecInMin = SEC_TO_USEC(60);
				targetTime = targetTime % usecInMin;		// Get the time into the minuter
				targetTime = usecInMin - targetTime;		// get the remainder of the minute
			} else {
				// It's 2 minutes or over, so align the start to the next nearest hour
				LONGLONG usecInHour = USEC_IN_A_SEC;
				usecInHour *= SECONDS_IN_AN_HOUR;	// Setup the hour in uSec
				targetTime = targetTime % usecInHour;	// Get the time into the hour
				targetTime = usecInHour - targetTime;	// Get the remainder of the Hour
			}
			// Now see how many times we can add a new line before the alignment period arrives
			LONGLONG timePeriod = SEC_TO_USEC(m_pTDConfig->UpdatePeriod);
			LONGLONG timeToGo = targetTime / timePeriod;
			if (timeToGo > 1) {
				// We can add more then 1 line before the alignment, so align with the remainder of the time period divided by the time to go, this will align but start as soon as possible
				targetTime = targetTime % timePeriod;
			}
			// Now convert the countdown time from usec into tick periods
			m_countDown = (USEC_TO_SEC(targetTime) + 1) * pSYSTIMER->GetProcessSlicesPerSecond();
		}
	}
#ifdef UNDER_CE
		CThreadInfo* pThreadInfo = CThreadInfo::GetHandle();
	if(pThreadInfo != NULL)
	{
		//Update the Thread Counter for the DataProcessing
		//thread 
		pThreadInfo->UpdateThreadCounter(AM_DATA_PROCESSING);
	}
#endif //UNDER_CE
	BOOL addNewLine = FALSE;
	// Check if we need to add a new reading, has the event triggered
	if (m_eventTriggerFired) {
		m_eventTriggerFired = FALSE;		// Cleardown event trigger
		addNewLine = TRUE;					// Set we want to add a new reading
	}
	// If an event has not triggered, test if perodic timer is set by the period expiring
	if ((T_TAB_DISP_UPDATE_METHOD_BITMASK) m_pTDConfig->UpdateMethod == tbumPERIODIC && m_countDown-- <= 0) {
		m_countDown = m_reloadCountdown;	// Reaload countdown
		addNewLine = TRUE;					// Set we want to add a new line
	}
	// Do we need to add anew line		
	if (addNewLine == TRUE) {
		lockForUpdates();	// Enter the critical section
		// Advance the newest line pointer to the next line to populate
		m_pNVTabularData->newestIndex++;
		if (m_pNVTabularData->newestIndex >= MAX_TABULAR_LINES) {
			m_pNVTabularData->newestIndex = 0;
		}
		// Populate the line reading
		int index = m_pNVTabularData->newestIndex;
		memset(&m_pNVTabularData->data[index], 0, sizeof(T_TABULAR_LINE));		// Cleardown the line
		m_pNVTabularData->data[index].time =
		pSYSTIMER->GetCurrentProcessTimeInMicroSec();		// Set the time to be the time of the current process slice
		// Loop through all pens, adding enabled opens to the line
		for (int dataItemIndex = 0; dataItemIndex < V6_MAX_PENS; dataItemIndex++) {
			// Only populate the reading if the pen is enabled
			if (m_pPenDataItem[dataItemIndex]->IsEnabled()) {
				m_pNVTabularData->data[index].readings[dataItemIndex] = m_pPenDataItem[dataItemIndex]->GetFPValue();// Add value of pen
				SetStatus(dataItemIndex, m_pPenDataItem[dataItemIndex]->GetStatus(), index);	// Add status of Pen
			}
#ifdef UNDER_CE
			if(pThreadInfo != NULL)
			{
				//Update the Thread Counter for the DataProcessing
				//thread 
				pThreadInfo->UpdateThreadCounter(AM_DATA_PROCESSING);
			}
#endif //UNDER_CE
		}
		SetUpdateRequired(TRUE);	// New line added so an update is required
		allowUpdates();				// leave the c=ritical section
	}
}
//****************************************************************************
///
/// Method that sets the internal index to reference the newest available set of readings
/// 
/// @return true if the newest sets of readings are valid
///
//****************************************************************************	
const bool CTabularReadings::SetToNewestReadings() {
	bool bReadingsValid = true;
	// Set the indexs to allow us to do a getfirst getnext on all of the lines.
	m_ulLatestIndex = m_pNVTabularData->newestIndex;
	m_CurrentIndex = m_ulLatestIndex;
	// Check if the latest reading is valid, a time of 0 indicated an invalid line.
	if (m_pNVTabularData->data[m_CurrentIndex].time == 0) {
		bReadingsValid = false;
	}
	return bReadingsValid;
}
//****************************************************************************
///
/// Method that sets the internal index to the next oldest set of readings
///
/// @return true if the next sets of readings are valid
/// 
//****************************************************************************	
const bool CTabularReadings::SetToNextReadings() {
	bool bReadingsValid = true;
	// increment onto the next set of readings, we must traverse backwards to get them in order
	--m_CurrentIndex;
	if (m_CurrentIndex < 0) {
		// Flip round to end of list
		m_CurrentIndex = MAX_TABULAR_LINES - 1;
	}
	if (m_CurrentIndex == m_ulLatestIndex) {
		// no more readings as we are back at the latest Index where we started
		bReadingsValid = false;
	}
	if (m_pNVTabularData->data[m_CurrentIndex].time == 0) {
		// no more readings as the current line is showing no valid readings
		bReadingsValid = false;
	}
	return bReadingsValid;
}
//****************************************************************************
///
/// Method that obtains the current time for the currently selected set of readings
/// 
//****************************************************************************	
const QString CTabularReadings::GetCurrentReadingLogTime() {
	TCHAR timeBuffer[100];		// Buffer for a time string generated in CTVtime
	CTVtime lineTime = m_pNVTabularData->data[m_CurrentIndex].time;		// Get the CTVtime of the tabular readings line
	lineTime.TimeDateToStringShort(timeBuffer);	// generate the string in timeBuffer
	QString strTime(timeBuffer);	// Assign timeBuffer to a QString  for easy consumption.
	return strTime;
}
//****************************************************************************
///
/// Method that obtains the stored pen reading from the currently selected set of readings
/// 
//****************************************************************************	
const float CTabularReadings::GetCurrentReadingPenValue(const USHORT usINSTANCE_NO) {
	float fPenValue = 0;
	// Get reading from tabular readings structure in SRAM
	fPenValue = m_pNVTabularData->data[m_CurrentIndex].readings[usINSTANCE_NO];
	return fPenValue;
}
//****************************************************************************
///
/// Method that obtains the stored pen status from the currently selected set of readings
/// 
//****************************************************************************	
const T_DATAITEM_STATUS CTabularReadings::GetCurrentReadingPenStatus(const USHORT usINSTANCE_NO) {
	// Get status from tabular readings structure in SRAM
	T_DATAITEM_STATUS ePenStatus = GetStatus(usINSTANCE_NO, m_CurrentIndex);
	return ePenStatus;
}

/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 Log record utilities
/// @n BlockControl.cpp
/// @n Utilities for maintaining log blocks (as blocks).
/// @author MM
/// @date 15/03/2005
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
//  44  Stability Project 1.39.1.3 7/2/2011 4:55:41 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  43  Stability Project 1.39.1.2 7/1/2011 4:38:00 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  42  Stability Project 1.39.1.1 3/17/2011 3:20:12 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  41  Stability Project 1.39.1.0 2/15/2011 3:02:18 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////
#include "V6globals.h"
#include "TVTime.h"
#include "LogRec.h"
#include "BlockControl.h"
#include "TraceDefines.h"
#include "QueueManager.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
//****************************************************************************
/// LogRecord utility: class constructor
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
CBlockControl::CBlockControl() {
	m_UsingCache = FALSE;
	m_QueueHandle = 0;
	return;
}
//****************************************************************************
/// LogRecord utility: class destructor
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
CBlockControl::~CBlockControl() {
	return;
}
//****************************************************************************
/// LogRecord utility: class initialisation
///
/// @param[in]		pLogging pointer to logging configuration data
///
/// @return		TRUE when initialisation was successfull
///
/// @note --- Delete if not requried ---
//****************************************************************************
T_BLOCK_INIT CBlockControl::Initialise(T_PLOGGING pLogging, USHORT Instance) {
	T_BLOCK_INIT bResult = BLOCK_OK;
	m_pLogging = pLogging;
	mpq_manager = CQueueManager::GetHandle();
	T_QMBLKSER_RETURN_VALUE q_error;
	q_error = mpq_manager->GetBlockServices().GetQueue(QMC_QUEUE_PEN_LOG, Instance, m_QueueHandle);
	if (QMBLKSER_PERSISTED_QUEUE_NOT_SETUP == q_error) {
		mpq_manager->GetBlockServices().SetupQueue(m_QueueHandle, QMC_QUEUE_PEN_LOG, 1, QMC_CONFIRMATION_NOT_REQUIRED);
	}
	if (QMBLKSER_OK == mpq_manager->GetBlockServices().GetQueue(QMC_QUEUE_PEN_LOG, Instance, m_QueueHandle)) {
		// Request last block
		if (QMBLKSER_OK == mpq_manager->GetBlockServices().GetLastDataBlock(m_QueueHandle, m_QueueBlock)) {
			m_DataBlock = m_QueueBlock.GetDataBlock();
			// If a new block had been requested and not yet used, continue with it
			if (NULL == m_DataBlock) {
				RequestNew();
			} else if (BLOCK_IN_USE == GetState() || BLOCK_INCRC == GetState()) {
				// validate and complete last block
				bResult = BLOCK_INCOMPLETE;
			}
		} else
			RequestNew();
	} else
		bResult = BLOCK_ERROR;
	return bResult;
}
//****************************************************************************
/// LogRecord utility: request new block and store the old (if any)
///
/// @return			pointer to the new log block or NULL if none available
///
/// @note --- Delete if not requried ---
//****************************************************************************
void* CBlockControl::RequestNew() {
//	LOG_INFO( TRACE_LOGGING , "CBlockControl request new block" );
	if (NULL != m_QueueBlock.GetDataBlock()) {
		// Block CRC being calculated
		SetState(BLOCK_INCRC);
		CrcInsert(m_QueueBlock.GetDataBlock(), QMC_BLOCK_SIZE);
		// Request new block
		m_QueueBlock.SetDataBlockComplete();
		SetState(BLOCK_COMPLETE);
	}
	T_QMBLKSER_RETURN_VALUE retVal = mpq_manager->GetBlockServices().GetFreeDataBlock(m_QueueHandle,
			(CQMDataBlock&) m_QueueBlock);
	// Set block type to QMC_QUEUE_PEN_LOG 
	m_QueueBlock.SetDataBlockType(QMC_QUEUE_PEN_LOG);
	SetState(BLOCK_NEW);
	m_DataBlock = m_QueueBlock.GetDataBlock();
	if (NULL != m_DataBlock) {
		UpdateBlockCount();
	} else {
		// no memory here!
		QString strError("");
		strError = QString::asprintf("BlockControl: no free SRAM blocks, error code %u", retVal);
		V6CriticalMessageBox(NULL, strError, L"Error", MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST);
	}
	return m_DataBlock;
}
//****************************************************************************
/// LogBlock utility: Set block/queue status
///
/// @param[in] blockState - block/queue status
///
/// @return	  None
///
/// @note --- Delete if not requried ---
//****************************************************************************
void CBlockControl::SetState(T_BLOCK_STATE blockState) {
	mpq_manager->GetBlockServices().SetUserStatus(m_QueueHandle, (USHORT) blockState);
}
//****************************************************************************
/// LogBlock utility: Get block/queue status
///
/// @return	block/queue status		
///
/// @note --- Delete if not requried ---
//****************************************************************************
T_BLOCK_STATE CBlockControl::GetState() {
	return (T_BLOCK_STATE) mpq_manager->GetBlockServices().GetUserStatus(m_QueueHandle);
}
//****************************************************************************
/// LogRecord utility: Flush and old block after a power recovery
///
/// @return			
///
/// @note --- Delete if not requried ---
//****************************************************************************
void CBlockControl::FlushLastBlock(USHORT Instance) {
	mpq_manager = CQueueManager::GetHandle();
	if (QMBLKSER_OK == mpq_manager->GetBlockServices().GetQueue(QMC_QUEUE_PEN_LOG, Instance, m_QueueHandle)) {
		///@todo complete the last block
		// CLogRec::CompleteLogRecord( );
		T_QMBLKSER_RETURN_VALUE retVal = mpq_manager->GetBlockServices().GetFreeDataBlock(m_QueueHandle,
				(CQMDataBlock&) m_QueueBlock);
		if (retVal == QMBLKSER_NO_DATA_BLOCKS_AVAILABLE) {
			QString strError("");
			strError = QString::asprintf("BlockControl: no free SRAM blocks, error code %u", retVal);
			V6WarningMessageBox(NULL, strError, L"Error", MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST);
		}
		mpq_manager->GetBlockServices().FlushQDataBlocksReadyForDisk(m_QueueHandle);
		mpq_manager->GetBlockServices().ResetQueue(m_QueueHandle);
	}
	return;
}

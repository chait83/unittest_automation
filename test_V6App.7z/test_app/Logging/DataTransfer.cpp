/// @file
/// *******************************************
/// Ã¯¿Ã Honeywell Trendview
/// *******************************************
/// V6 Data Transferutilities
/// @n DataTransfer.cpp
/// @n Main data transfer class.
/// @author MM
/// @date 11/04/2005
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 134 Aristos 1.128.1.3.1.0 9/19/2011 4:51:16 PM Hemant(HAIL) 
//Stability recorder source code (JI Release) updated for WatchDog
//Timer functionality.
// 133 Stability Project 1.128.1.3 7/2/2011 4:56:40 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//version of firmware to JF version of firmware.
// 132 Stability Project 1.128.1.2 7/1/2011 4:38:13 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//task. The merging will be done between IL version of firmware and JF
//version of firmware. 
// 131 Stability Project 1.128.1.1 3/17/2011 3:20:21 PM Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//new operator in DEBUG mode only. To detect memory leaks in files, use
//it in preprocessor definition when in debug mode.
// $
//
// Rajanbabu M 8/5/2013 Fixed PAR:1-118V3EP-Recorder data Export in CSV works only for Group1 and All Data 
// Rajanbabu M 9/26/2013 Fixed PAR:1-153WUXR-GR_CSV data XLS, AM PM and milsecond representation should be Proper
// Vellaidurai V 2/07/2013 Fixed PAR: 1-29FL9RH Event loging in csv format is not proper
//Master PAR: 1-2FTMPXV CSV Export:ScheduleExport Issue + EventLogging Issue + Group Export Issue
//Fix for Senario 5: Schedule export missed to log events in csv file. 
// Vellaidurai V 2/07/2013Fixed PAR: 1-118V3EP - Recorder data Export in CSV creates Folder but do not create XLS files
//Fix for Senario : Export Aborted message implemented
// Vellaidurai V 2/07/2013Fixed PAR: 1-2S8AFLX - Need to support csv data export over NAS and provide facility to add data export by batch
//Fix for Senario : Manual export over NAS failed in some scenario. 
//																 Not all pens get exported over NAS. Export dialog buttons gets greyed out sometime.
// Vellaidurai V 2/07/2013Fixed PAR: 1-3ENNURL - There are some possible mis-uses of the CONFIG_MODIFIABLE configuration data
// Kranti				11/07/2013		 Fix for PAR: 1-2YKYIM1 CSV Export_Change in Decimal point Number format would not reflect in CSV. It works in TV Encrypt
//		Shankar Rao Pendyala			08/17/2017		 Fix for CSV new data tranfer issues when toggles b/w TVEncrypt and CSV and allow FTP transfer always even with CSV 
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#include "DataTransfer.h"
#include "TraceDefines.h"
#include "logrec.h"
#include "QueueManager.h"
#include "LogDeviceStatus.h"
#include "TVtime.h"
#include "LCMGlobal.h"
#include "V6ResourceBase.h"
#include "V6UIResource.h"
#include "MediaManager.h"
#include "PenManager.h"
#include "FTPUser.h"
#include <time.h>
#include "reportManager.h"
#include "BatchManager.h"
#include <algorithm>
#include "StringUtils.h"
#include "MessageListServices.h"
#include "V6globals.h"
#include "ThreadInfo.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
const QString wcDataSubFolderMask = L"*.exp";
//wofstream g_csvExportFile;
// Data transfer module
// Static Initialisation
CDataTransfer *CDataTransfer::pInstance = NULL;
QMutex hCreationMutex;
const ULONG CDataTransfer::m_ulMAX_TRANSFER_BLOCKS_SLOW = 2000;
const ULONG CDataTransfer::m_ulMAX_FTP_TRANSFER_BLOCKS_MED = 4000; // for FTP 
const ULONG CDataTransfer::m_ulMAX_FTP_TRANSFER_BLOCKS_FAST = 4000; // for FTP
const ULONG CDataTransfer::m_ulMAX_WSD_TRANSFER_BLOCKS_MED = 3000; // for WSD 
const ULONG CDataTransfer::m_ulMAX_WSD_TRANSFER_BLOCKS_FAST = 3000; // for WSD
const USHORT PEN_NO_GROUP = 0;
const USHORT PEN_GROUP1 = 1;
const USHORT PEN_GROUP2 = 2;
const USHORT PEN_GROUP3 = 3;
const USHORT PEN_GROUP4 = 4;
const USHORT PEN_GROUP5 = 5;
const USHORT PEN_GROUP6 = 6;
const USHORT BATCH_PREAMBLE_CNT = 10;
int CDataTransfer::m_nLograteCnt = 0;
#ifdef DUMP_EXPORT_ENABLE
bool CDataTransfer::m_bExportDumpFiles = false;
#endif
//****************************************************************************
/// DataTransfer service: class constructor
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
CDataTransfer::CDataTransfer() : m_ulCurrMaxFTPTransferBlocks(m_ulMAX_WSD_TRANSFER_BLOCKS_FAST), m_usTRANS_POINT_NOT_INIT(
		0xFFFE)
#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
, m_pDebugFileLogger(NULL) //Set the defult static handler for this module
#endif
{
	m_Initialised = FALSE;
	m_bIsNewDataTransfer = FALSE; // Default initialization is false. added by Aditya
	//
	memset(m_taExportAllPenTransPoints, 0, sizeof(T_QMC_FILE_BLOCK_TRANSACTION) * V6_MAX_PENS);
	memset(m_taExportAllMessageTransPoints, 0,
			sizeof(T_QMC_FILE_BLOCK_TRANSACTION) * CMessageListServices::msqMAX_QUEUES);
	ResetPreTrigPenTransferList();
	m_bIsFileCreated = FALSE;
	ms_strCSVDelimiter = ",";
	ms_strQUOTE = "\"";
	ms_strCSVEOL = "\n";
	memset(&m_DataStartTime, 0, sizeof(TV5Time));
	memset(&m_DataEndTime, 0, sizeof(TV5Time));
	m_enabledPens = 0;
	m_bExportAborted = FALSE;
	m_bIsStartTimeSet = false;
	m_nCurrPenNum = 0;
	m_rstrCSVHeader = "";
	for (int i = 0; i < 97; i++) {
		m_pFile[i] = NULL;
	}
	return;
}
//****************************************************************************
/// DataTransfer service: class destructor
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
CDataTransfer::~CDataTransfer() {
	for (int i = 0; i < 97; i++) {
		if (m_pFile[i] != NULL) {
			delete m_pFile[i];
			m_pFile[i] = NULL;
		}
	}
	return;
}
void CDataTransfer::FlashLED(USHORT Times, USHORT Delay, BOOL FinalState) {
	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//for the Scheduler thread
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	for (int inCount = Times; inCount > 0; inCount--) {
		if (pThreadInfo != NULL) {
			//Update the Thread Counter for the Scheduler thread
			//thread for each iteration
			pThreadInfo->UpdateThreadCounter(AM_TX_SCHEDULER_THREAD);
		}
		pDALGLB->SetCFLED( TRUE);
		sleep(Delay);
		pDALGLB->SetCFLED( FALSE);
		sleep(Delay);
	}
	pDALGLB->SetCFLED(FinalState);
}
//****************************************************************************
/// DataTransfer service: singleton get/create instance
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
CDataTransfer* CDataTransfer::GetHandle() {
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;
	if (NULL == pInstance) {
		hCreationMutex = CreateMutex(NULL,					// No security descriptor
				TRUE,					// Mutex object owned
				L"DataTransfer");		// Object name
		waitSingleObjectResult = hCreationMutex.tryLock(g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);
		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:
			// Object was signaled
			if (NULL == pInstance) {
				pInstance = new CDataTransfer;
				LOG_INFO(TRACE_TRANSFER, "CDataTransfer new Instance created");
			}
			if (FALSE == hCreationMutex.unlock();)
				V6WarningMessageBox(NULL, L"Failed to release DataTransfer mutex", L"Error", MB_OK);
			break;
		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
			V6WarningMessageBox(NULL, L"DataTransfer WaitForSingleObject Error", L"Error", MB_OK);
			break;
		}
		// Close the Mutex as no longer required
		//No need to close the mutex in Qt
	}
	return pInstance;
}
//****************************************************************************
/// DataTransfer service: singleton cleanup
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
BOOL CDataTransfer::CleanUp() {
	if (NULL != pInstance) {
		if (NULL != m_pMessageQueue)
			delete (m_pMessageQueue);
		delete pInstance;
		pInstance = NULL;
	}
	qDebug(" DataTransfer module CleanUp() called.\n");
	return TRUE;
}
//****************************************************************************
/// DataTransfer service: Initialisation
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
void CDataTransfer::Initialise() {
	m.lock();
	if ( FALSE == m_Initialised) {
		m_Initialised = TRUE;
		m_iExportCount = EXPORT_ROLLOVER_LIMIT;								///< Data export counter
		QString csTxt;
		csTxt = tr("Initializing Data Transfer");
		pGlbSysInfo->SetStartupAction(csTxt);
		pGlbSysInfo->SetStartupSubAction("");
		CQueueManager *pq_manager = CQueueManager::GetHandle();
		m_pMessageQueue = new CInternalMessageQueue;
		m_pMessageQueue->InitInternalMessageQueue(2, 1024, QThread::currentThreadId(), IMQ_USE_EVENT);//IMQ_USE_MANUAL);
		csTxt = tr("Initializing Storage Devices");
		pGlbSysInfo->SetStartupAction(csTxt);
		WCHAR mess[40];
		for (int instance = 0; instance < LOGDEV_MAX_DEVICES; instance++) {
			csTxt = tr("Initializing Device %d of %d");
			swprintf(mess, 40, csTxt, instance, LOGDEV_MAX_DEVICES);
			pGlbSysInfo->SetStartupSubAction(mess);
			m_StorageDevice[instance].Initialise();
		}
		for (int device = 0; device < LOGDEV_MAX_DEVICES; device++) {
			m_StorageDevice[device].SetID((T_LOG_DEVICE) device);
		}
		csTxt = tr("Register Storage Devices with Disk Services");
		pGlbSysInfo->SetStartupAction(csTxt);
		pGlbSysInfo->SetStartupSubAction("");
		pq_manager->GetDiskServices().RegisterWithQMDiskServices(USRREQSER_USER_LOGGING, m_pMessageQueue);
		ClearBlockCount();
		// Roll-Back any saved transaction points (if required)
		RollBackIfRequired();
	}
	m.unlock();
	return;
}
//****************************************************************************
/// DataTransfer service: Calculate data transfer as a percentage
///
/// @return			USHORT progress percentage
///
/// @note Used to show the recording progress as a bar
//****************************************************************************
USHORT CDataTransfer::CalculateTransferPercentage(ULONG CurrentBlockCount, ULONG TotalBlocks) {
	ULONG Percentage = 0L;
	if (TotalBlocks > 0) {
		if (CurrentBlockCount > TotalBlocks)
			Percentage = 90L;
		else
			Percentage = (CurrentBlockCount * 100L) / TotalBlocks;
		if (Percentage > 90L)
			Percentage = 90L;
	}
	return (USHORT) Percentage;
}
QString CDataTransfer::GetFolderName() {
	//Aditya added code to add DateTimeStamp to Folder that is getting created.
	//If each time 96 files get generated in single folder, it will be difficult for user to find appropriate file , creating multiple folders 
	WCHAR FileName[MAX_PATH] = { 0 };
	swprintf(FileName, MAX_PATH, L"R%06.6d", pGlbSysInfo->GetSerialNumber());
	QString l_strTimeDateFileName = "";
	QString strSlash = L"\\";
#ifndef V6IOTEST
	CReportManager *pReportHandle = CReportManager::GetHandle();
	if (pReportHandle != NULL) {
		pReportHandle->AppendTimeDateToReportName(FileName, l_strTimeDateFileName);
	}
#endif
	l_strTimeDateFileName = l_strTimeDateFileName + strSlash;
	return l_strTimeDateFileName;
	//Aditya - code end here
}
//****************************************************************************
/// DataTransfer service: Get the Data Export format from configuration
///
/// @return			CDataTransfer::teOK if successfull otherwise a non zero error code
///
/// @note --- Delete if not requried ---
//****************************************************************************
const CDataTransfer::T_TRANSFER_ERRORS CDataTransfer::getDataExportasprintf(
		T_DATA_EXPORT_FORMAT_TYPE &eExportasprintf) {
	//PSR-Fix to allow FTP Transfer even if Dataasprintf is selected as CSV.
	T_TRANSFER_ERRORS eResult = teOK;
	eExportasprintf = EXPORT_FORMAT_TVENCRYPT;	//Default it to TV Encrypt format
	//Get the Profile section of GeneralSetupConfig to get logging configuration info
	T_PRECPROFILE ptProfile = pSETUP->GetGeneralSetupConfig()->GetProfileBlock(CONFIG_COMMITTED);
	if (NULL != ptProfile) {
		//checking the file export type here
		if ( TRUE == ptProfile->Logging.CSV) {
			eExportasprintf = EXPORT_FORMAT_CSV;	//CSV format selected for Data Export
		}
	} else {
		eResult = teMEDIA_GENERIC_ERROR;	//Todo:Use proper error code if required later
	}
	return eResult;
}
//****************************************************************************
/// DataTransfer service: Get the Data Export format from configuration
///
/// @return			CDataTransfer::teOK if successfull otherwise a non zero error code
///
/// @note --- Delete if not requried ---
//****************************************************************************
const CDataTransfer::T_TRANSFER_ERRORS CDataTransfer::getDataExportasprintf(const T_LOG_DEVICE device,
		T_DATA_EXPORT_FORMAT_TYPE &eExportasprintf) {
	//PSR-Fix to allow FTP Transfer even if Dataasprintf is selected as CSV.
	T_TRANSFER_ERRORS eResult = teOK;
	//This code block desides/allows whether to allow FTP transfer(TMS) even when the CSV is selected for export format in TV
	//For now do not allow due to LCF issues
	/*if( LOGDEV_FTP == device )
	 {
	 eExportasprintf = EXPORT_FORMAT_TVENCRYPT; //This function desides whether to allow FTP transfer(TMS)
	 }
	 else*/
	{
		eResult = getDataExportasprintf(eExportasprintf);
	}
	return eResult;
}
//****************************************************************************
/// DataTransfer service: transfer all available data
///
/// @return			CDataTransfer::teOK if successfull otherwise a non zero error code
///
/// @note --- Delete if not requried ---
//****************************************************************************
const CDataTransfer::T_TRANSFER_ERRORS CDataTransfer::TransferAll(T_LOG_DEVICE device) {
	T_TRANSFER_ERRORS eResult = teOK;
	T_SESSION_SPAN span;
	m_CurrentBlockCount = 0;
	m_Percentage = 0;
	m_TransferComplete = FALSE;
	m_StopRequest = FALSE;
	m_bExportAborted = FALSE;
	m_nCurrPenNum = 0;
	if (m_logEventVec.size() > 0) {
		m_logEventVec.clear();
	}
	T_QMBLKSER_RETURN_VALUE q_error;
	//Consider current time as overall endtime for pen data 
	TV5Time currentTime;
	CTVtime timeCur;
	timeCur.TimeNow();
	currentTime = timeCur.GetTV5Time(); //Get current recorder time
	m_OverallEndTime = currentTime; // set current time as end time
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	if (pThreadInfo != NULL) {
		//Update the Thread Counter for the TxScheduler thread
		pThreadInfo->UpdateThreadCounter(AM_TX_SCHEDULER_THREAD);
	}
	CQueueManager *pq_manager = CQueueManager::GetHandle();
	CLogDeviceStatus *pDeviceStatus = CLogDeviceStatus::GetHandle();
	//PSR-Fix to allow FTP Transfer even if Dataasprintf is selected as CSV begin
	T_DATA_EXPORT_FORMAT_TYPE eExportasprintfType = EXPORT_FORMAT_TVENCRYPT;
	getDataExportasprintf(device, eExportasprintfType);
	//PSR-Fix to allow FTP Transfer even if Dataasprintf is selected as CSV end
	span.StartSession = USHRT_MAX;
	span.EndSession = 0;
	WCHAR FullPath[MAX_PATH] = { 0 };
	WCHAR FileName[MAX_PATH] = { 0 };
	wcsncpy_s(FullPath, MAX_PATH, DevicePath(device), _TRUNCATE);
	swprintf(FileName, MAX_PATH, L"R%06.6d\\", pGlbSysInfo->GetSerialNumber());
	m_bIsFileCreated = FALSE;
	m_bIsBatchMode = FALSE;
	m_groupNumber = PEN_NO_GROUP;
	m_LogRate = 0;
	memset(m_penInfoStruct, 0, sizeof(m_penInfoStruct));
	//
	// TransferAll doesn't use split export folders, no point.
	//
	if (CheckMediaSpace(device)) {
		if (LOGDEV_FTP != device)
		////Aditya added code to add DateTimeStamp to Folder that is getting created.
		////If each time 96 files get generated in single folder, it will be difficult for user to find appropriate file , creating multiple folders
				{	// if this is not an FTP transfer, check the export directory exists and if not create it
			wcsncat(FullPath, MAX_PATH, FileName, MAX_PATH);
			//checking the file export type here		
			if (EXPORT_FORMAT_CSV == eExportasprintfType) {
				// CSV File format
				//If it is CSV file format type , then appending timestamp to folder so that it will be easy for user to distinguish different operations.
				m_strFolderName = "";
				WCHAR TempFullPath[MAX_PATH] = { 0 };
				QString l_strFolderPath = GetFolderName();
				wcsncat(TempFullPath, MAX_PATH, DevicePath(device), _TRUNCATE);
				wcsncat(TempFullPath, MAX_PATH, l_strFolderPath, MAX_PATH);
				m_strFolderName = TempFullPath;
				eResult = CreateExportDir(TempFullPath);
				if (AbortExport(eResult)) {
					m_bExportAborted = TRUE;
					return eResult;
				}
			} else {
				//TV Encrypt asprintf
				eResult = CreateExportDir(FullPath);
				if (AbortExport(eResult)) {
					m_bExportAborted = TRUE;
					return eResult;
				}
			}
			//Prepare Export directory for Debug and Error Log files
			//PSR - DebugFile Logger integration and export scheme
#if defined (DBG_LOG_EXPORT_ENABLE) || defined (DUMP_EXPORT_ENABLE)
#if defined (DBG_LOG_EXPORT_ENABLE)
			//Export log files only when asked for ..mostly this will set for manual export
			if( true == m_bExportDumpFiles ) 
			{
				TransferDbgLogFiles(device);				
			}
#endif
#if defined (DUMP_EXPORT_ENABLE)
			//Export dumps only when asked for ..mostly this will set for manual export
			if( true == m_bExportDumpFiles ) 
			{
				TransferDumpFiles(device);
			}
#endif
			//Reset to ensure the dumps does not get exported if not asked ..Schedule export
			m_bExportDumpFiles = false;
#endif
		} else {
			pDALGLB->BuildPath(IDS_FTP, IDS_FTP_DOWNLOAD_DATA, "", FullPath, MAX_PATH);
		}
		if (eResult == teOK) {
			FlushAllLoggingQueues();
			//PSR-Fix to allow FTP Transfer even if Dataasprintf is selected as CSV begin
			// don't export if this is an FTP export as the LCF files are requested seperately
			if ((device != LOGDEV_FTP) && (EXPORT_FORMAT_CSV != eExportasprintfType)) //CSV format does not require LCF files
					{
				eResult = CopyLCFFiles(FullPath, device);
			}
			//PSR-Fix to allow FTP Transfer even if Dataasprintf is selected as CSV end
			if (eResult == teOK) {
				// For each DataChannel and while successful e.g. the disk is not yet full or removed
				for (int Instance = 0; (Instance < V6_MAX_PENS) && !AbortExport(eResult) && IsDevicePresent(device);
						Instance++) {
					if (pThreadInfo != NULL) {
						//Update the Thread Counter for the TxScheduler thread
						pThreadInfo->UpdateThreadCounter(AM_TX_SCHEDULER_THREAD);
					}
					USHORT QueueHandle;
					q_error = pq_manager->GetBlockServices().GetQueue(QMC_QUEUE_PEN_LOG, Instance, QueueHandle);
					if (QMBLKSER_OK == q_error
							&& QMC_QUEUE_EMPTY != pq_manager->GetDiskServices().GetQueueStatus(QueueHandle)) {
						// check if this is an FTP export all
						if (LOGDEV_FTP != device) {
							// a normal export all so just use the oldest transaction point possible always
							T_QMC_FILE_BLOCK_TRANSACTION localTransactionPoint;
							// GetOldestAvailable
							if (ResetToOldestAvailable(QueueHandle, &localTransactionPoint)) {
								qDebug("OldestAvaliable p%d b%d f%d nb%d, rs%d\n", Instance,
										localTransactionPoint.blockId, localTransactionPoint.fileId,
										localTransactionPoint.numOfBlocksLastRequested,
										localTransactionPoint.recycleState);
								swprintf(FileName, L"%sP%06.6d.dat", FullPath, Instance + 1);
								// Transfer the pen data
								eResult = TransferPen(device, FileName, QueueHandle, Instance, span,
										&localTransactionPoint,
										FALSE);
								// append the pre-trigger information to the end if the last operation was a success
								if ((eResult == teOK) || (eResult == teFTP_BUFFER_FULL)) {
									// attempt to transfer the pre-trigger data
									TransferPreTriggerData(Instance, FileName);
								} else
								{
									break;
								}
							}
						} else {
							// FTP exports have to be dealt with in junks so we rely on some temporary transaction
							// points here - these will already have been reset
							swprintf(FileName, L"%sP%06.6d.dat", FullPath, Instance + 1);
							// Transfer the pen data
							if (m_taExportAllPenTransPoints[Instance].fileId == m_usTRANS_POINT_NOT_INIT) {
								// this must be the initial transfer to the FTP folder - reset the transaction point to the
								// oldest available
								if (ResetToOldestAvailable(QueueHandle, &(m_taExportAllPenTransPoints[Instance]))) {
#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
									CTV6Timer blkTimer(TIMER_NORMAL_RES);
									blkTimer.StartTimer();
									QString  strDbgMsg;
									strDbgMsg = QString::asprintf(_T("TransferAll- Initial TransferPen %d to the FTP folder timer starts"), Instance);
									LogDebugMessage(strDbgMsg);
									#endif
									eResult = TransferPen(device, FileName, QueueHandle, Instance, span,
											&(m_taExportAllPenTransPoints[Instance]), TRUE);
#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
									blkTimer.StopTimer();
									strDbgMsg = QString::asprintf(_T("TransferAll- Initial TransferPen %d timer ends Elapsed time in ms %llu, eResult %d"), Instance, blkTimer.ElapsedTimeInMilliSeconds(), eResult);
									LogDebugMessage(strDbgMsg);
									#endif
									// append the pre-trigger information to the end if the last operation was a success
									if ((eResult == teOK) || (eResult == teFTP_BUFFER_FULL)) {
										// attempt to transfer the pre-trigger data
										TransferPreTriggerData(Instance, FileName);
									} else {
										break;
									}
								} else {
									// the reset did not work therefore abort the transfer for this pen
									eResult = teINVALID_TRANSACTION_POINT_NO_ABORT;
								}
							} else {
								// continue with the transfer to the FTP folder
#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
								CTV6Timer blkTimer(TIMER_NORMAL_RES);
								blkTimer.StartTimer();
								QString  strDbgMsg;
								strDbgMsg = QString::asprintf(_T("TransferAll- continue with the TransferPen %d to the FTP folder timer starts"), Instance);
								LogDebugMessage(strDbgMsg);
								#endif
								eResult = TransferPen(device, FileName, QueueHandle, Instance, span,
										&(m_taExportAllPenTransPoints[Instance]), TRUE);
#ifdef DBG_FILE_LOG_TXSCH_DBG_ENABLE
								blkTimer.StopTimer();
								strDbgMsg = QString::asprintf(_T("TransferAll- continue TransferPen %d timer ends Elapsed time in ms %llu, eResult %d"), Instance, blkTimer.ElapsedTimeInMilliSeconds(), eResult);
								LogDebugMessage(strDbgMsg);
								#endif
								// append the pre-trigger information to the end if the last operation was a success
								if ((eResult == teOK) || (eResult == teFTP_BUFFER_FULL)) {
									// attempt to transfer the pre-trigger data
									TransferPreTriggerData(Instance, FileName);
								} else {
									break;
								}
							}
						}
					}
				} // pen
				// only proceed if successful so far e.g. the disk is not yet full or missing
				if (!AbortExport(eResult) && IsDevicePresent(device, TRUE)) {
					eResult = TransferAllMessages(device);
					//PSR-Fix to allow FTP Transfer even if Dataasprintf is selected as CSV begin
					// Just in case the config has changed. Note: only copies if the files have changed
					// don't export if this is an FTP export as the LCF files are requested seperately
					if ((device != LOGDEV_FTP) && (EXPORT_FORMAT_CSV != eExportasprintfType)) //CSV doesnot require LCF files(other than FTP device which is always Encrypt)
							{
						CopyLCFFiles(FullPath, device);
					}
					//PSR-Fix to allow FTP Transfer even if Dataasprintf is selected as CSV end
				}
			}
		}
		//PSR-Fix to allow FTP Transfer even if Dataasprintf is selected as CSV begin
		//only proceed if successful so far e.g. the disk is not yet full or missing
		//if( (EXPORT_FORMAT_CSV == eExportasprintfType) && !AbortExport(eResult) && IsDevicePresent(device, TRUE))
		if (EXPORT_FORMAT_CSV == eExportasprintfType) {
			//Export the data to the .csv file
			//ExportToCSV(device);
			//ExportToCSV_MultipleFiles(device);
			bool bTransferAborted = AbortExport(eResult); //PAR-836 Error Handling in CSV
			AfterCSVDataTransfer(bTransferAborted);
		}
		//PSR-Fix to allow FTP Transfer even if Dataasprintf is selected as CSV end
		// force one final update of the media if still present
		CMediaManager *pkMediaManager = CMediaManager::GetHandle();
		CLogDeviceStatus *pkDeviceStatus = CLogDeviceStatus::GetHandle();
		if (pkMediaManager->IsDeviceInserted(pkDeviceStatus->LogDeviceToStorageDevice(device))) {
			pkMediaManager->CheckDevice(pkDeviceStatus->LogDeviceToStorageDevice(device), false);
		}
	} else {
		eResult == teMEDIA_FULL;
	}
	//PAR- 836 All Export Error Handling cases start - Anoop, Vedant
	if (!AbortExport(eResult)) {
		if (IsDevicePresent(device, TRUE)) {
			m_TransferComplete = TRUE;
		}
	} else {
		m_bExportAborted = TRUE;
		m_TransferComplete = FALSE;
	}
	//PAR- 836 All Export Error Handling cases end - Anoop, Vedant
	/*only proceed if successful so far e.g. the disk is not yet full or missing
	 if(device == LOGDEV_EXT_SD)
	 {
	 m_bExportAborted = !IsDevicePresent(device, TRUE);
	 m_TransferComplete = !m_bExportAborted;
	 }
	 else if(!AbortExport(eResult))
	 {
	 m_TransferComplete = TRUE;
	 }*/
	return eResult;
}
void CDataTransfer::AfterCSVDataTransfer(bool bTransferAborted) {
	//If transfer not aborted then export Events as well otherwise cleanup the file pointers
	if (false == bTransferAborted) {
		ExportCSVEvents(); //This will export events to a seperate file
	}
	//m_bIsFile_Created = false;
	m_OverallEndTime.Fracs = 0;
	m_OverallEndTime.Secs = 0;
	m_bIsFirstPen = false;
	m_bIsStartTimeSet = false;
	//m_bIsEmptyBatch = FALSE;
	for (int npenno = 1; npenno < 96; npenno++) {
		m_nPenIndexCnt[npenno] = 0;
	}
	if (m_bIsFileOpen) {
		m_pFile[m_nCurrPenNum]->WriteString(m_rstrCSVLine);
		SetupCsvHeaderMultiExtended(m_strExportFilename, m_nCurrPenNum);
		m_pFile[m_nCurrPenNum]->Close();
		m_rstrCSVLine.Empty();
		m_bIsFileOpen = false;
	}
	for (int i = 0; i < 97; i++) {
		if (m_pFile[i] != NULL) {
			delete m_pFile[i];
			m_pFile[i] = NULL;
		}
	}
	if (m_logEventVec.size() > 0) {
		m_logEventVec.clear();
	}
	m_nCurrPenNum = 0;
	//m_TransferComplete = TRUE;
}
//****************************************************************************
/// DataTransfer service: transfer all new data
///
/// @return			CDataTransfer::teOK if successfull otherwise a non zero error code
///
/// @note --- Delete if not requried ---
//****************************************************************************
const CDataTransfer::T_TRANSFER_ERRORS CDataTransfer::TransferAllNew(T_LOG_DEVICE device) {
	T_TRANSFER_ERRORS eResult = teOK;
	T_SESSION_SPAN span;
	m_CurrentBlockCount = 0;
	m_Percentage = 0;
	m_TransferComplete = FALSE;
	m_StopRequest = FALSE;
	m_bExportAborted = FALSE;
	m_nCurrPenNum = 0;
	if (m_logEventVec.size() > 0) {
		m_logEventVec.clear();
	}
	T_QMBLKSER_RETURN_VALUE q_error;
try
{
	CQueueManager *pq_manager = CQueueManager::GetHandle();
	CLogDeviceStatus *pDeviceStatus = CLogDeviceStatus::GetHandle();
	//PSR-Fix to allow FTP Transfer even if Dataasprintf is selected as CSV begin
	T_DATA_EXPORT_FORMAT_TYPE eExportasprintfType = EXPORT_FORMAT_TVENCRYPT;
	getDataExportasprintf(device, eExportasprintfType);
	//PSR-Fix to allow FTP Transfer even if Dataasprintf is selected as CSV end
	span.StartSession = USHRT_MAX;
	span.EndSession = 0;
	WCHAR FullPath[MAX_PATH] = {0};
	wcsncpy_s( FullPath, MAX_PATH, DevicePath( device ), _TRUNCATE );
	WCHAR FileName[MAX_PATH] = {0};
	swprintf( FileName, L"R%06.6d\\", pGlbSysInfo->GetSerialNumber() );
	m_bIsFileCreated = FALSE;
	m_bIsBatchMode = FALSE;
	m_groupNumber = PEN_NO_GROUP;
	m_LogRate = 0;
	// now setup the actual schedule export fields
	T_PRECPROFILE ptProfile = pSETUP->GetGeneralSetupConfig()->GetProfileBlock(CONFIG_COMMITTED);
	T_LOGGINGINFO *ptLogging = NULL;
	if( ptProfile != NULL )
	{
		ptLogging = &ptProfile->Logging;
		m_groupNumber = ptLogging->GroupNumber;
		if(m_groupNumber != PEN_NO_GROUP)
		m_bIsBatchMode = TRUE;
	}
	TV5Time currentTime;
	CTVtime timeCur;
	timeCur.TimeNow(); //Get recorders current time
	currentTime = timeCur.GetTV5Time();
	m_OverallEndTime = currentTime;//Consider current time as overall endtime for pen data, same has been set in TransferAll operation as well
	CTransferFolder SplitFolder;
	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//for the Scheduler thread
	CThreadInfo* pThreadInfo = CThreadInfo::GetHandle();
	if ( CheckMediaSpace( device ) )
	//	if ( CheckExportFreeSpace( device ) )
	{
		if ( LOGDEV_FTP != device )
		{	// if this is not an FTP transfer, check the export directory exists and if not create it
#ifdef USE_SPLIT_EXPORT
			if(EXPORT_FORMAT_TVENCRYPT == eExportasprintfType)	//PSR-Fix to allow FTP Transfer even if Dataasprintf is selected as CSV 
			{
				m_iExportCount++;
				// Ensure the export path exists.
				WCHAR FolderPath[MAX_PATH] = {0};
				wcscpy_s( FolderPath, MAX_PATH, FullPath );
				wcscat( FolderPath, MAX_PATH, FileName );
				eResult = CreateExportDir( FolderPath );
				if(AbortExport(eResult))
				{
					m_bExportAborted = TRUE;
					return eResult;
				}
				if ( m_iExportCount > EXPORT_ROLLOVER_LIMIT )
				{
					// Time to nudge export folder
					m_ulExportFolder = SplitFolder.GetLastUsedFolder( FolderPath);
					if ( FALSE == SplitFolder.CreateNext( FolderPath ))
					{
						LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_ERROR,"Failed to create split export folder." );
						m_bExportAborted = TRUE;
						return teMEDIA_FAILED_TO_CREATE_EXPORT_FOLDER;
					}
					m_ulExportFolder = SplitFolder.GetCurrentFolder( );
					qDebug("Nudging export folder to %06.6ld.exp\n", m_ulExportFolder );
					m_iExportCount = 0;
				}
#endif // USE_SPLIT_EXPORT
				wcsncat( FullPath, MAX_PATH, FileName, MAX_PATH );
#ifdef USE_SPLIT_EXPORT
				// Append split export folder
				WCHAR SplitName[MAX_PATH] = {0};
				swprintf( SplitName, L"\\%06.6ld.exp\\", m_ulExportFolder );
				wcscat( FullPath, MAX_PATH, SplitName );
			}
			else
			{
				// if this is not an FTP transfer, check the export directory exists and if not create it
				wcsncat( FullPath, MAX_PATH, FileName, MAX_PATH );
			}
#endif // USE_SPLIT_EXPORT
			//getting and checking the type of export format here
			if(EXPORT_FORMAT_CSV == eExportasprintfType)//PSR-Fix to allow FTP Transfer even if Dataasprintf is selected as CSV 
			{
				// CSV File format
				//If it is CSV file format type , then appending timestamp to folder so that it will be easy for user to distinguish different operations.
				m_strFolderName = QString ::fromWCharArray("");
				m_bIsNewDataTransfer = true;//Added by Aditya. This is to know if it is New data transfer.
				WCHAR TempFullPath[MAX_PATH] = {0};
				QString l_strFolderPath = GetFolderName();
				wcsncpy_s( TempFullPath, MAX_PATH, DevicePath( device ), _TRUNCATE );
				wcsncat( TempFullPath, MAX_PATH, l_strFolde

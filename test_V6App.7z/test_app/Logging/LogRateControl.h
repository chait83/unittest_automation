/// @file 
/// **********************************************************************
/// © Honeywell Trendview
/// **********************************************************************
/// @n Module:	 Utilities
/// @n Filename: LogRateControl.h
/// @n Desc:	 Utility for maintaining the rate for realtime pens
///				 
///
// **********************************************************************
// Revision History
#ifndef __LOG_RATE_CONTROL_H_INCLUDED__
#define __LOG_RATE_CONTROL_H_INCLUDED__
#include "TVtime.h"
#include "CMMDefines.h"
#include "V6Config.h"
//**Class*********************************************************************
///
/// @brief 
/// 
///
//****************************************************************************
class CLogRateControl {
public:
	//Constructor
	CLogRateControl();
	//Destructor
	~CLogRateControl();
	//Change the log rate
	void ChangeRate(ULONG logRate, ULONG rateUnits);		///< Ste/Change the logging rate divisor
	//Log the realtime data reading
	BOOL LogReading();									///< Log reading
	//Get the current rate
	ULONG CurrentRate() {
		return m_CurrentRate;
	}
	;	///< Return the current log rate (in ms-tenths)
	//Get the log rate
	const ULONG GetLogRate(ULONG rateUnits, ULONG logRate);
	//Set the pen number for which the log rate is configured
	void SetPenConfigNumber(int penNumber);
	//Returns the pen number for which the log rate is configured
	int GetConfigPenNumber();
	//Sets the flag to indicate if the logging is requested for
	// the first time
	void SetLogFirstTime(BOOL bIsLogFirstTime);
	//Gets the flag to indicate if the logging is requested for
	// the first time
	BOOL IsLogFirstTime();
private:
	ULONG m_CurrentRate;
	unsigned long m_Rate;								///< Current log rate
	unsigned long m_Counter;							///< Working log rate counter
	CTVtime m_StartTime;
	int m_PenNumber;
	BOOL m_bIsLogFirstTime;   //Flag indicates if the realtime request is made for the first time
};
#endif // __LOG_RATE_CONTROL_H_INCLUDED__

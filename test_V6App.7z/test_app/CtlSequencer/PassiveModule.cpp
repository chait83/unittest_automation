#include "PassiveModule.h"
CPassiveModule::CPassiveModule(void) {
}
CPassiveModule::~CPassiveModule(void) {
}

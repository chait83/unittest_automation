/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  Control Sequencer
/// @n Filename:  SystemConfiguration.cpp
/// @n Description: Implementation for System Configuration
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  05-MAR-15  Rajanbabu M Fixed:LCM issue during firmware upgrade(101.1.8R to 102.1.7R) 
//  85  Aristos  1.79.1.3.1.0 9/19/2011 4:51:11 PM  Hemant(HAIL)  
//  Stability recorder source code (JI Release) updated for WatchDog
//  Timer functionality.
//  84  Stability Project 1.79.1.3 7/2/2011 5:01:58 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  83  Stability Project 1.79.1.2 7/1/2011 4:39:00 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  82  Stability Project 1.79.1.1 3/17/2011 3:20:49 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
// $
//
// **************************************************************************
#include "SystemConfiguration.h"
#include "Configuration.h"
#include "CMMDefines.h"
#include "ConfigurationManager.h"
#include "V6Config.h"
#include "SetupConfiguration.h"
#include "LayoutConfiguration.h"
#include "PasswordConfiguration.h"
#include "StoragePaths.h"
#include "FileList.h"
#include "CStorage.h"
#include "LCMGlobal.h"
#include "CLoggerModule.h"
#include "V6globals.h"
#include "OpPanelIncludes.h"
#include "TraceDefines.h"
#include "EventManager.h"
#include "ThreadInfo.h"
/// Declared within V6Config.cpp, to test CMM Structures for 4 byte alignment
extern BOOL testV6ConfigStructures();
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//****************************************************************************
/// Class Constructor 
///
//****************************************************************************
CSystemConfiguration::CSystemConfiguration(void) {
	// Initialise Member Variables
	m_hMetadataResourceHandler = NULL;
	m_pPersisitedSetupFileName = QString::fromWCharArray(PERSIST_CONFIG);
	m_pSetupConfiguration = NULL;
	m_pLayoutConfiguration = NULL;
} // End of Constructor
//****************************************************************************
/// Class Destructor 
///
//****************************************************************************
CSystemConfiguration::~CSystemConfiguration(void) {
	delete m_pSetupConfiguration;
	delete m_pLayoutConfiguration;
	delete m_pPasswordConfiguration;
	m_pSetupConfiguration = NULL;
	m_pLayoutConfiguration = NULL;
	m_pPasswordConfiguration = NULL;
} // End of Destructor
//****************************************************************************
/// Initialise the system configuration, consists of Layout Passwords and Setup
/// 
///
/// @return T_SYSCONFIG_RETURN_VALUE - as return value
/// 
//****************************************************************************
T_SYSCONFIG_RETURN_VALUE CSystemConfiguration::Initialise() {
	T_SYSCONFIG_RETURN_VALUE retValue = SYSCONFIG_OK;
	m_pSetupConfiguration = new CSetupConfiguration;
	if (NULL == m_pSetupConfiguration) {
		retValue = SYSCONFIG_INITIALISATION_FAILED;
	}
	pGlbSetup = m_pSetupConfiguration;		/// Setup global ptr to current setup configuration.
	m_pLayoutConfiguration = new CLayoutConfiguration();
	if (NULL == m_pLayoutConfiguration) {
		retValue = SYSCONFIG_INITIALISATION_FAILED;
	}
	pGlbLayout = m_pLayoutConfiguration;
	m_pPasswordConfiguration = new CPasswordConfiguration();
	if (NULL == m_pPasswordConfiguration) {
		retValue = SYSCONFIG_INITIALISATION_FAILED;
	}
	pPwdSetup = m_pPasswordConfiguration;
	return (retValue);
}
//****************************************************************************
/// The CMM must be initialised to allow system configuration to be undertake,
/// the CMM requires metadata for its operation, this is loaded from a resource
/// and a pointer passed to the CMM. 
/// 
/// @param[in] pName - Name of Application initialising CMM
/// @param[in] deviceSerialNumber - Device Serial Number, unique to each recorder
///
/// @return SYSCONFIG_CMM_INITIALISED - Initialisation of the CMM Successful
/// @n  SYSCONFIG_CMM_INIT_FAILED - CMM could not be initialised
/// 
//****************************************************************************
T_SYSCONFIG_RETURN_VALUE CSystemConfiguration::InitialiseCMM(QString pName, ULONG deviceSerialNumber) {
#ifdef PWDLOGS_ENABLE
	WCHAR szDbgMsg[512];
#endif
	CMMERROR cmmError = CMM_FAILED;   // CMM Error Status 
	T_SYSCONFIG_RETURN_VALUE retValue = SYSCONFIG_CMM_INIT_FAILED; // Member Function Return Value
	BYTE *pMetadata = NULL;   // Pointer to the Metadata to be loaded into CMM
	DWORD systemMetadataVersion;
	// Load the Metadata ready for initialising the CMM
	QString cmmErrorText("");
	if (SYSCONFIG_METADATA_LOADED == LoadMetadata()) {
		// Obtain a pointer to the Metadata
		//
		pMetadata = (BYTE*) LockResource(m_hMetadataResourceHandler);
		if (NULL != pMetadata) {
			// Initialise the CMM for operation
			cmmError = Initialize(pName, deviceSerialNumber, pMetadata, &systemMetadataVersion);
#ifdef PWDLOGS_ENABLE 
        swprintf( szDbgMsg, "CSystemConfiguration::InitialiseCMM - systemMetadataVersion %ld GTC %d\n",systemMetadataVersion,GetTickCount());
		OutputDebugString(szDbgMsg);
#endif  
			if (CMM_SUCCESS == cmmError) {
				if ((int) systemMetadataVersion == (int) CF_VERSION) {
					if ( TRUE == testV6ConfigStructures()) {
						retValue = SYSCONFIG_CMM_INITIALISED;
					} else {
						V6CriticalMessageBox(NULL, "", "CMM misalignment problem !!!\nSee Output window for details",
						MB_OK);
					}
				} else {
					V6WarningMessageBox(NULL, "The resource DLL is probably out-of-date. Loading default resources",
							"CMM Metadata/Firmware versions differ!!!", MB_OK);
#ifdef PWDLOGS_ENABLE					
                    swprintf( szDbgMsg, "CSystemConfiguration::InitialiseCMM - systemMetadataVersion %d GTC %d\n",systemMetadataVersion,GetTickCount());
					OutputDebugString(szDbgMsg);
#endif
					ShutdownCMM();
					UnlockResource(m_hMetadataResourceHandler);
					retValue = SYSCONFIG_METADATA_VERSION_MISMATCH;
				}
			} else {
				cmmErrorText = QString::asprintf("Cmm Failed to initialise(%d)", cmmError);
				V6CriticalMessageBox(NULL, cmmErrorText.toLocal8Bit().data(), "CMM Failed",
                        MB_OK );
			}
		}
	} else {
		cmmErrorText = QString::asprintf("Metadata failed to load");
		V6CriticalMessageBox(NULL, cmmErrorText.toLocal8Bit().data(), "CMM Failed",
                MB_OK );
	}
	return (retValue);
}
T_CONFIG_RETURN_VALUE CSystemConfiguration::PerformPasswordUpdate() {
	return m_pPasswordConfiguration->UpdateConfig();
}
//****************************************************************************
/// Perform a Specific Action on the Setup Configuration
/// 
/// @param[in] setupConfigurationAction , T_SYSCONFIG_CONFIGURATION_ACTION of action to perform on Setup
/// @param[in] pConfigFileAndPathName - patrh and filename of config to load if required
///
/// @return SYSCONFIG_CMM_INITIALISED - as return value
//****************************************************************************
T_CONFIG_RETURN_VALUE CSystemConfiguration::PerformSetupConfigAction(
		const T_SYSCONFIG_CONFIGURATION_ACTION setupConfigurationAction, const QString pConfigFileAndPathName) {
	T_CONFIG_RETURN_VALUE retValue = CONFIG_OK;  // Member Function Return Value
	BOOL rollSessionNumber = FALSE;  // Variable to indicate whether the Session Number needs to be rolled
	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//for the ControlSequencer thread
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	if (pThreadInfo != NULL) {
		pThreadInfo->UpdateThreadCounter(AM_CTRLSEQUENCER);
	}
#ifdef STARTUP_LOGGING
	WCHAR InitLogFileName[ 256 ];
	WCHAR InitLogString[512];
	int iPathLen = 256;
	CStorage kLogFile;
	QFileDevice::FileError kFileEx;
	pDALGLB->GetPath(	static_cast< T_STORAGE_PATH >( IDS_INTERNAL_SD ), 
						InitLogFileName,
						256,
						&iPathLen );
    wcsncat( InitLogFileName, 256, "PerfSetupConfig.txt", (256 - wcslen( InitLogFileName )) );
	if( kLogFile.Open(	InitLogFileName, 
						CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
						&kFileEx ) )
	{
		kLogFile.SeekToEnd();
        wcscpy(InitLogString,"--------Initialisation started-------\n");
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	// Indication to whether the CMM has been updated. 
	T_CONFIG_VALIDATE_RETURN setupConfigCMMChangedStatus = CONFIG_VALIDATE_NO_CHANGES;
	// The base Configuration Id, for any updates to the CMM to be compared with.
	DWORD configurationId = SYSCONFIG_ZERO;
	// Reference Setup Configuration Identification Number, used by the LCM to compare configuration
	// versions. 
	DWORD referenceConfigId = SYSCONFIG_ZERO;
	UPDATELCF lcmUpdateType = LCF_UPDATE;	// By default we only want to update the LCF
	QString rollSessionReasonText("");
	QString csTxt = "";
	csTxt = QWidget::tr("Determining Setup Type");
	pGlbSysInfo->SetStartupSubAction(csTxt.toLocal8Bit().data());
	// Determine the Type of Setup Configuration to be performed
	switch (setupConfigurationAction) {
	case SYSCONFIG_LOAD_PERSISTED_CONFIG:
		csTxt = QWidget::tr("Loading Persisted Config");
		pGlbSysInfo->SetStartupSubAction(csTxt.toLocal8Bit().data());
		// Set the Configuration ID to the Setup Configuration Id
		referenceConfigId = SYSCONFIG_BASE_CONFIG_ID;
#ifdef STARTUP_LOGGING
            wcscpy(InitLogString,"LoadPersistedSetupConfig\n");
			if( kLogFile.Open(	InitLogFileName, 
								CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
								&kFileEx ) )
			{
				kLogFile.SeekToEnd();
				kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
				kLogFile.Close();
			}
#endif
		// Load Persisted Setup, if not available Create a Default Config
		retValue = LoadPersistedSetupConfig();
#ifdef STARTUP_LOGGING  
            wcscpy(InitLogString,"Switch Return\n");
			if( kLogFile.Open(	InitLogFileName, 
								CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
								&kFileEx ) )
			{
				kLogFile.SeekToEnd();
				kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
				kLogFile.Close();
			}
#endif
		switch (retValue) {
		case CONFIG_OK: {
			// Configuration is ok and has not been changed after de-persisted, so just proceed.
			break;
		}
		case CONFIG_OK_VALIDATE_UPDATED_CMM: {
			// Configuration ok, but modified over after being de-persisted (hardware mods etc..)
			csTxt = QWidget::tr("Validating CMM");
			pGlbSysInfo->SetStartupSubAction(csTxt.toLocal8Bit().data());
			rollSessionNumber = TRUE;
			rollSessionReasonText = "HW Change";
			retValue = CONFIG_OK;
			break;
		}
		case CONFIG_FILE_DOES_NOT_EXIST: {
			// Config file not found, create a default
			csTxt = QWidget::tr("Create Default Config");
			pGlbSysInfo->SetStartupSubAction(csTxt.toLocal8Bit().data());
			// Create a defualt configuration
#ifdef STARTUP_LOGGING
                    wcscpy(InitLogString,"m_pSetupConfiguration->CreateDefaultConfig()\n");
					if( kLogFile.Open(	InitLogFileName, 
										CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
										&kFileEx ) )
					{
						kLogFile.SeekToEnd();
						kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
						kLogFile.Close();
					}
#endif
			retValue = m_pSetupConfiguration->CreateDefaultConfig();
			rollSessionNumber = TRUE;
			rollSessionReasonText = "No Config";
			retValue = CONFIG_OK;
			break;
		}
		default: // File is in a unknown state, delete it first then create a default
		{
#ifdef STARTUP_LOGGING
                    wcscpy(InitLogString,"MediaUtils::DeleteFile()\n");
					if( kLogFile.Open(	InitLogFileName, 
										CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
										&kFileEx ) )
					{
						kLogFile.SeekToEnd();
						kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
						kLogFile.Close();
					}
#endif
			// Delet file
			MediaUtils::DeleteFile(IDS_INTERNAL_SD, IDS_CONFIG_DATA, SYSCONFIG_DEFAULT_PERSISTED_SETUP_FILENAME);
			// Config file corrupt or other error, delete and create a default
			csTxt = QWidget::tr("Create Default Config");
			pGlbSysInfo->SetStartupSubAction(csTxt.toLocal8Bit().data());
			// Send error and reason to diagnostic list
			QString configErrorText;
			configErrorText = QString::asprintf("Config load failed %d", retValue);
			LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, configErrorText);
#ifdef STARTUP_LOGGING
                    wcscpy(InitLogString,"m_pSetupConfiguration->CreateDefaultConfig()\n");
					if( kLogFile.Open(	InitLogFileName, 
										CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
										&kFileEx ) )
					{
						kLogFile.SeekToEnd();
						kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
						kLogFile.Close();
					}
#endif
			// Create a defualt configuration
			retValue = m_pSetupConfiguration->CreateDefaultConfig();
			rollSessionNumber = TRUE;
			rollSessionReasonText = "Invalid";
			retValue = CONFIG_OK;
			break;
		}
		}
		csTxt = QWidget::tr("Initialize LCM");
		pGlbSysInfo->SetStartupSubAction(csTxt.toLocal8Bit().data());
#ifdef STARTUP_LOGGING
            wcscpy(InitLogString,"InitialiseLCM()\n");
			if( kLogFile.Open(	InitLogFileName, 
								CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
								&kFileEx ) )
			{
				kLogFile.SeekToEnd();
				kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
				kLogFile.Close();
			}
#endif
		retValue = InitialiseLCM();
//			if( pSYSTEM_INFO->IsDataResetRequested() == TRUE )
//			{
//				rollSessionNumber = TRUE;		//Force and update on the LCM.
//			}
#ifdef STARTUP_LOGGING
            wcscpy(InitLogString,"m_pSetupConfiguration->ClearDepersistMode()\n");
			if( kLogFile.Open(	InitLogFileName, 
								CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
								&kFileEx ) )
			{
				kLogFile.SeekToEnd();
				kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
				kLogFile.Close();
			}
#endif
		m_pSetupConfiguration->ClearDepersistMode();
		break;
	case SYSCONFIG_LOAD_CONFIGURATION:
		// Set the Configuration ID to the Setup Configuration Id
		referenceConfigId = m_pSetupConfiguration->GetConfigId();
#ifdef STARTUP_LOGGING
            wcscpy(InitLogString,"m_pSetupConfiguration->LoadConfigUsingFileName( pConfigFileAndPathName )\n");
			if( kLogFile.Open(	InitLogFileName, 
								CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
								&kFileEx ) )
			{
				kLogFile.SeekToEnd();
				kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
				kLogFile.Close();
			}
#endif
		// Load Configuration
		retValue = m_pSetupConfiguration->LoadConfigUsingFileName(pConfigFileAndPathName);
		lcmUpdateType = LCF_LOAD;		// Make sure the LCF updates the whole config.
		// Always roll the Session Number of a Load Configuration
		rollSessionNumber = TRUE;
		rollSessionReasonText = "Load";
#ifdef STARTUP_LOGGING
            wcscpy(InitLogString,"pEVENTS->SystemEventTrigger()\n");
			if( kLogFile.Open(	InitLogFileName, 
								CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
								&kFileEx ) )
			{
				kLogFile.SeekToEnd();
				kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
				kLogFile.Close();
			}
#endif
		pEVENTS->SystemEventTrigger(ecsSetupChange);
		break;
	case SYSCONFIG_UPDATE_CONFIG:
		// Set the Configuration ID to Zero on an Update, to ensure that all blocks
		// are check for being modified. 
		referenceConfigId = SYSCONFIG_BASE_CONFIG_ID;
#ifdef STARTUP_LOGGING
            wcscpy(InitLogString,"m_pSetupConfiguration->UpdateConfig()\n");
			if( kLogFile.Open(	InitLogFileName, 
								CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
								&kFileEx ) )
			{
				kLogFile.SeekToEnd();
				kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
				kLogFile.Close();
			}
#endif
		// Update the Configuration
		retValue = m_pSetupConfiguration->UpdateConfig();
		// Always roll the Session Number 
		rollSessionNumber = TRUE;
		rollSessionReasonText = "Commit";
#ifdef STARTUP_LOGGING
            wcscpy(InitLogString,"pEVENTS->SystemEventTrigger( ecsSetupChange )\n");
			if( kLogFile.Open(	InitLogFileName, 
								CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
								&kFileEx ) )
			{
				kLogFile.SeekToEnd();
				kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
				kLogFile.Close();
			}
#endif
		pEVENTS->SystemEventTrigger(ecsSetupChange);
		break;
	default:
		retValue = CONFIG_INVALID_ACTION_TYPE;
		break;
	}
	// Perform the following actions only if no errors have been reported from previous
	// operations.
	if ((CONFIG_OK == retValue) || (retValue == CONFIG_OK_VALIDATE_UPDATED_CMM)) {
		if (pThreadInfo != NULL) {
			//The handle is used to update the thread counter
			//for the ControlSequencer thread
			pThreadInfo->UpdateThreadCounter(AM_CTRLSEQUENCER);
		}
		// Set the Configuration Id to the lastest Id for the Setup Configuration, this value
		// represents to the LCM the new version that the Base Configuration Id should be compared with.  
		configurationId = m_pSetupConfiguration->GetConfigId();
		// Check if a config conversion has been performed
		if (m_pSetupConfiguration->ConversionHasBeenPerformed() == TRUE) {
			QString configConvertText;
			configConvertText = QString::asprintf("Setup config upgraded from %d to %d",
					m_pSetupConfiguration->GetConfigVersion(),
					CF_VERSION);
			LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_INFO, configConvertText);
			m_pSetupConfiguration->SetConversionPerformed(FALSE);// Cleardown fact that a conversion has been performed
			rollSessionNumber = TRUE;									// A conversion performed so roll the session.
			rollSessionReasonText = "Version";
		}
		// is a session roll required
		if (rollSessionNumber == TRUE) {
			// Yes, Roll session number
			USHORT newSessionNumber = pSYSTEM_INFO->RollSessionNumber();
			csTxt = QWidget::tr("Updating LCM");
			pGlbSysInfo->SetStartupSubAction(csTxt);
			// Update LCM with current new session
			qDebug(" UpdateLCF: Session = %d Type %d\n", pSYSTEM_INFO->GetSessionNumber(), lcmUpdateType);
			LCMERROR LCMError = UpdateLCF(configurationId, referenceConfigId, lcmUpdateType,
			pSYSTEM_INFO->GetSessionNumber());
			// If the LCM is updating for a Load Configuration
			// we will have to try and delete the old configuration
			if (lcmUpdateType == LCF_LOAD) {
				m_pSetupConfiguration->CleanUpConfiguration(TRUE);
			}
			DWORD LCMSession = 0;
			GetLatestSessionNumber(&LCMSession);
			if (CMM_SUCCESS == LCMError) {
				QString rollSessionText;
				rollSessionText = QString::asprintf("Session updated(%s) to %d LCM(%d) Type(%d)", rollSessionReasonText,
						newSessionNumber, LCMSession, lcmUpdateType);
				LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_INFO, rollSessionText);
				retValue = CONFIG_OK;
			} else {
				QString lcmErrorText;
				lcmErrorText = QString::asprintf("LCM Update fail(%s) err(%d) Sess(%d) LCM(%d) Type(%d)",
						rollSessionReasonText, LCMError, newSessionNumber, LCMSession, lcmUpdateType);
                V6WarningMessageBox(NULL, lcmErrorText, "LCM Error", MB_OK );
				retValue = CONFIG_UPDATE_LCF_FAILED;
			}
		}
#ifdef STARTUP_LOGGING
        wcscpy(InitLogString,"PersistSetupConfig\n");
		if( kLogFile.Open(	InitLogFileName, 
							CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
							&kFileEx ) )
		{
			kLogFile.SeekToEnd();
			kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
			kLogFile.Close();
		}
#endif
		// Persist the Configuration 
		retValue = PersistSetupConfig();
	}
#ifdef STARTUP_LOGGING  
    wcscpy(InitLogString,"--------------END---------------------\n");
	if( kLogFile.Open(	InitLogFileName, 
						CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
						&kFileEx ) )
	{
		kLogFile.SeekToEnd();
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	return (retValue);
}
//****************************************************************************
/// Perform a Specific Action on the Layout Configuration
/// 
/// @param[in] setupConfigurationAction , T_SYSCONFIG_CONFIGURATION_ACTION of action to perform on Setup
/// @param[in] pConfigFileAndPathName - patrh and filename of config to load if required
///
/// @return SYSCONFIG_CMM_INITIALISED - as return value
//****************************************************************************
T_CONFIG_RETURN_VALUE CSystemConfiguration::PerformLayoutConfigAction(
		const T_SYSCONFIG_CONFIGURATION_ACTION layoutConfigurationAction, const QString pConfigFileAndPathName) {
	T_CONFIG_RETURN_VALUE retValue = CONFIG_OK;
	// Determine the Type of Layout Configuration to be performed
	switch (layoutConfigurationAction) {
	case SYSCONFIG_LOAD_PERSISTED_CONFIG:
		retValue = LoadPersistedLayoutConfig();
		switch (retValue) {
		case CONFIG_OK_VALIDATE_UPDATED_CMM:
			retValue = CONFIG_OK;
			break;
		case CONFIG_FILE_DOES_NOT_EXIST:
			retValue = m_pLayoutConfiguration->CreateDefaultConfig();
			break;
		default:
			retValue = m_pLayoutConfiguration->CreateDefaultConfig();
			break;
		}
		break;
	case SYSCONFIG_LOAD_CONFIGURATION:
		retValue = m_pLayoutConfiguration->LoadConfigUsingFileName(pConfigFileAndPathName);
		if (retValue == CONFIG_OK_VALIDATE_UPDATED_CMM) {
			retValue = CONFIG_OK;
		}
		break;
	case SYSCONFIG_UPDATE_CONFIG:
		retValue = m_pLayoutConfiguration->UpdateConfig();
		break;
	default:
		retValue = CONFIG_INVALID_ACTION_TYPE;
		break;
	}
	if (CONFIG_OK == retValue) {
		retValue = PersistLayoutConfig();
	}
	return (retValue);
}
//****************************************************************************
/// Attempts to load persisted layout configuration into the CMM, if no
/// persisted layout configuration is available( i.e. Recorder turned on for the
/// first time ) then default layout configuration will be created. 
/// 
/// @param[in] sessionNumber - Session Number for the Configuration to be created	  
///
/// @return SYSCONFIG_OK - Layout Configuration performed sucessfully
/// @n SYSCONFIG_ERROR - Layout Configuration could not be perform. 
//****************************************************************************
T_SYSCONFIG_RETURN_VALUE CSystemConfiguration::PerformLayoutConfiguration(DWORD sessionNumber) {
	// Perform Layout Configuration
	//
	T_SYSCONFIG_RETURN_VALUE retValue = SYSCONFIG_OK;  // Member Function Return Value 
	// Perform Setup Configuration
	//
	if (SYSCONFIG_NO_PERSISTED_CONFIGURATION == LoadPersistedLayoutConfig()) {
		// Trap errors when creating default configuration
		retValue = SYSCONFIG_ERROR;
		// Create a CMM Holder for the configuration being created
		if (CONFIG_CMM_HOLDER_CREATED == m_pLayoutConfiguration->CreateCMMHolder(sessionNumber)) {
			// Create a Default Configuration
			if (CONFIG_OK == m_pLayoutConfiguration->CreateDefaultConfig()) {
				// Commit configuration to CMM Current
				if (CONFIG_OK == m_pLayoutConfiguration->UpdateConfig()) {
					// Persist Default Setup
					PersistLayoutConfig();
					retValue = SYSCONFIG_OK;
				}
			}
		}
	}
	if (SYSCONFIG_ERROR == retValue) {
		// Delete Configuration for the CMM
		m_pLayoutConfiguration->DeleteConfig();
	}
	return (retValue);
}
//****************************************************************************
/// Attempts to load persisted password configuration into the CMM from flash, if no
/// persisted password configuration is available( i.e. Recorder turned on for the
/// first time ) then default password configuration will be created. 
/// 
/// @param[in] sessionNumber - Session Number for the Configuration to be created	  
///
/// @return SYSCONFIG_OK - Layout Configuration performed sucessfully
//****************************************************************************
T_SYSCONFIG_RETURN_VALUE CSystemConfiguration::PerformPasswordConfiguration(DWORD sessionNumber) {
	T_SYSCONFIG_RETURN_VALUE retValue = SYSCONFIG_OK;  // Member Function Return Value 
	// Check if a factory reset is required
	if ( pSYSTEM_INFO->IsFactoryResetRequested() == TRUE) {
		// Yes so indicate no password found in flash
		retValue = SYSCONFIG_NO_PERSISTED_CONFIGURATION;
	} else {
		// No, attempt to load passwords
		retValue = LoadPersistedPasswordConfig();
	}
	// If no persisted config found proceed with creating a default
	if (retValue == SYSCONFIG_NO_PERSISTED_CONFIGURATION) {
		// Trap errors when creating default configuration
		retValue = SYSCONFIG_ERROR;
		// Create a CMM Holder for the configuration being created
		if (CONFIG_CMM_HOLDER_CREATED == m_pPasswordConfiguration->CreateCMMHolder(sessionNumber)) {
			// Create a Default Configuration
			if (CONFIG_OK == m_pPasswordConfiguration->CreateDefaultConfig()) {
				// Commit configuration to CMM Current
				retValue = SYSCONFIG_PMM_DEFAULT_CONFIG_CREATED;
			}
		}
	}
	if ((SYSCONFIG_OK != retValue) && (SYSCONFIG_PMM_DEFAULT_CONFIG_CREATED != retValue)) {
		// Delete Configuration for the CMM
		m_pPasswordConfiguration->DeleteConfig();
	} else {
		// Commit and persist the password
		if (CONFIG_OK == m_pPasswordConfiguration->UpdateConfig()) {
			T_SYSCONFIG_RETURN_VALUE retTmp = PersistPasswordConfig();
			if (retTmp != SYSCONFIG_OK)
				retValue = retTmp;
		}
	}
	return (retValue);
}
//****************************************************************************
/// Load a new layout configuration 
/// 
/// @param[in] pNewConfigPathandFileName - file and pathname to new layout	  
///
/// @return T_SYSCONFIG_RETURN_VALUE - as retun value
//****************************************************************************
/*
 T_SYSCONFIG_RETURN_VALUE CSystemConfiguration::LoadNewLayoutConfig(const WCHAR* pNewConfigPathandFileName)
 {
 T_SYSCONFIG_RETURN_VALUE retValue=SYSCONFIG_INITIALISATION_FAILED;
 DWORD sessionNumber = 1;
 // create a temporary layout config (need to do this because OpPanel is still using the other one!)
 CLayoutConfiguration *pNewLayout=new CLayoutConfiguration();
 
 if( pNewLayout == NULL )
 return SYSCONFIG_ERROR; /// @todo make a new error for this?
 
 // Create New CMM Holder
 pNewLayout->CreateCMMHolder( sessionNumber );
 // Load Configuration 
 if(pNewLayout->LoadConfigUsingFileName(pNewConfigPathandFileName)==CONFIG_OK)
 {
 // Validate the Layout configuration (always do this on a load)
 if( CONFIG_VALIDATE_INVALID != pNewLayout->ValidateConfiguration())
 {
 // Commit configuration to CMM Current
 if( CONFIG_OK == pNewLayout->UpdateConfig() )
 {		
 // now pass the new layout configuration to the OpPanel
 if(((COpPanel*)(AfxGetApp()->m_pMainWnd))->SetConfiguration(pNewLayout,TRUE))
 {
 // accepted ok, so remove old configutation from the CMM
 
 m_pLayoutConfiguration->DeleteConfig();
 delete m_pLayoutConfiguration;
 m_pLayoutConfiguration=pNewLayout; // and set our new layout as the current one for the system
 // now Persist Configuration
 PersistLayoutConfig(); 
 return SYSCONFIG_OK;
 }
 }
 }
 }				
 // delete new one from CMM
 pNewLayout->DeleteConfig();
 delete pNewLayout;
 
 return SYSCONFIG_ERROR; 
 }
 */
//****************************************************************************
/// Persist the setup configuration 
///
/// @return T_SYSCONFIG_RETURN_VALUE - as return value
//****************************************************************************
T_CONFIG_RETURN_VALUE CSystemConfiguration::PersistSetupConfig(void) {
	QString persistSetupFileAndPathName = "";
	CDeviceAbstraction *pDAL = CDeviceAbstraction::GetHandle();
	pDAL->BuildPath(IDS_INTERNAL_SD, IDS_CONFIG_DATA, &SYSCONFIG_DEFAULT_PERSISTED_SETUP_FILENAME,
			&persistSetupFileAndPathName, MAX_PATH);
	return (m_pSetupConfiguration->SaveConfigUsingFileName(persistSetupFileAndPathName));
}
//****************************************************************************
/// Load a persisted setup configuration
///
/// @return T_SYSCONFIG_RETURN_VALUE - as return value
//****************************************************************************
T_CONFIG_RETURN_VALUE CSystemConfiguration::LoadPersistedSetupConfig(void) {
	// Member Function Return Value
	T_CONFIG_RETURN_VALUE retValue = CONFIG_FILE_DOES_NOT_EXIST;
	// Persisted Path and File Name
	QString persistSetupFileAndPathName = "";
	// Obtain a handler to the Device Abstraction Layer.
	CDeviceAbstraction *pDAL = CDeviceAbstraction::GetHandle();
	// Build the Persisted Setup Configuration Path and File Name
	pDAL->BuildPath(IDS_INTERNAL_SD, IDS_CONFIG_DATA, &SYSCONFIG_DEFAULT_PERSISTED_SETUP_FILENAME,
			&persistSetupFileAndPathName, MAX_PATH);
	// Attempt to Load the Default Configuration
	retValue = m_pSetupConfiguration->LoadConfigUsingFileName(persistSetupFileAndPathName);
	return (retValue);
}
#ifdef UNDER_CE
#define LCM_FILE_NAME_LENGTH			1024 //took from LCMDefines.h //coverity fix 778740
#else
#define LCM_FILE_NAME_LENGTH			MAX_PATH //took from LCMDefines.h //coverity fix 778740
#endif
//****************************************************************************
/// Initialise the LCM
///
/// @return T_SYSCONFIG_RETURN_VALUE - as return value
//****************************************************************************
T_CONFIG_RETURN_VALUE CSystemConfiguration::InitialiseLCM(void) {
	T_CONFIG_RETURN_VALUE retValue = CONFIG_LCF_INIT_FAILED;
	WCHAR LCFFile[LCM_FILE_NAME_LENGTH];    // LCF Path and File Name
	CDeviceAbstraction *pDAL = CDeviceAbstraction::GetHandle();
	QString lcmErrorText("");
	if (NULL != pDAL) {
		// Build Path and File Name for the Logging Configuration File
		pDAL->BuildPath(IDS_INTERNAL_SD, IDS_CONFIG_DATA, "LCF.Conf", LCFFile, LCM_FILE_NAME_LENGTH);
		/// Initialise the Logging Configuration Manager
		LCMERROR LCMReturn = InitLCF(m_pSetupConfiguration->GetConfigId(), LCFFile);
		if (LCM_SUCCESS == LCMReturn) {
			// LCM Inititalised OK, get slast session number from LCM
			DWORD Session = pGlbSysInfo->GetSessionNumber();
			DWORD LCMSession = 0;
			LCMReturn = GetLatestSessionNumber(&LCMSession);
			if (LCM_SUCCESS == LCMReturn) {
				// LCM's last session number retreived ok, test against the system session number
				QString LCMsessionText;
				LCMsessionText = QString::asprintf("Session (%d) LCM(%d)", Session, LCMSession);
				LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_INFO, LCMsessionText);
				// Is the system session less the LCM, not including fresh start where LCM will return Session+1
				if ((Session + 1) < LCMSession) {
					// Problem this should not be
					lcmErrorText = QString::asprintf("LCM Session(%d) where LCM Session(%d)\n Could be first run",
							Session, LCMSession);
                    MessageBox(NULL, lcmErrorText, "LCM Error", MB_OK );
					Session = SESSION_RESET_NUMBER;		// Reset session number so LCM version used
				}
				// Check if system session number is reset
				if (SESSION_RESET_NUMBER == Session) {
					// Yes, use the LCM latest
					CMessageListServices *pMessageListService = CMessageListServices::GetHandle();
					qDebug(" Start-up session not in the LCF?.\n");
					LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "Session from LCM used");
					pGlbSysInfo->SetSessionNumber(static_cast<USHORT>(LCMSession));
				}
				// Run a conversion of of the LCM
				LCMReturn = ConvertLCF(LCFFile, &Session, CF_VERSION);
				if (LCM_SUCCESS == LCMReturn) {
					retValue = CONFIG_OK;
				} else {
					lcmErrorText = QString::asprintf("LCM Convert failed(%d)", LCMReturn);
                    MessageBox(NULL, lcmErrorText, "LCM Error", MB_OK );
				}
			} else {
				lcmErrorText = QString::asprintf("LCM Session get failed(%d)", LCMReturn);
                MessageBox(NULL, lcmErrorText, "LCM Error", MB_OK );
			}
		} else {
			lcmErrorText = QString::asprintf("LCM Failed to Initialise(%d)", LCMReturn);
            MessageBox(NULL, lcmErrorText, "LCM Error", MB_OK );
		}
	}
	return (retValue);
}
//****************************************************************************
/// Persist the password configuration
///
/// @return T_SYSCONFIG_RETURN_VALUE - as return value
//****************************************************************************
T_SYSCONFIG_RETURN_VALUE CSystemConfiguration::PersistPasswordConfig(void) {
	T_CONFIG_RETURN_VALUE retVal;
	retVal = m_pPasswordConfiguration->PersistConfig();
	if (CONFIG_OK == retVal)
		return SYSCONFIG_OK;
	else
		return SYSCONFIG_NO_PERSISTED_CONFIGURATION;
}
//****************************************************************************
/// Persist a layout configuration
///
/// @return T_SYSCONFIG_RETURN_VALUE - as return value
//****************************************************************************
T_CONFIG_RETURN_VALUE CSystemConfiguration::PersistLayoutConfig(void) {
	QString persistSetupFileAndPathName = "";
	CDeviceAbstraction *pDAL = CDeviceAbstraction::GetHandle();
	pDAL->BuildPath(IDS_INTERNAL_SD, IDS_CONFIG_DATA, &SYSCONFIG_DEFAULT_PERSISTED_LAYOUT_FILENAME,
			&persistSetupFileAndPathName, MAX_PATH);
	return (m_pLayoutConfiguration->SaveConfigUsingFileName(persistSetupFileAndPathName, TRUE)); //TRUE=persisted
}
//****************************************************************************
/// Load persisted layout configuration 
///
/// @return T_SYSCONFIG_RETURN_VALUE - as return value
//****************************************************************************
T_CONFIG_RETURN_VALUE CSystemConfiguration::LoadPersistedLayoutConfig(void) {
	// Member Function Return Value
	T_CONFIG_RETURN_VALUE retValue = CONFIG_FILE_DOES_NOT_EXIST;
	// Persisted Path and File Name
	QString persistSetupFileAndPathName = "";
	// Obtain a handler to the Device Abstraction Layer.
	CDeviceAbstraction *pDAL = CDeviceAbstraction::GetHandle();
	// Build the Persisted Setup Configuration Path and File Name
	pDAL->BuildPath(IDS_INTERNAL_SD, IDS_CONFIG_DATA, &SYSCONFIG_DEFAULT_PERSISTED_LAYOUT_FILENAME,
			&persistSetupFileAndPathName,
			MAX_PATH);
	// Attempt to Load the Default Configuration
	retValue = m_pLayoutConfiguration->LoadConfigUsingFileName(persistSetupFileAndPathName, TRUE); //TRUE=persisted
	return (retValue);
}
//****************************************************************************
/// Load persisted password config from Flash, split over more then one block
/// so needs to be reconstituted
///
/// @return T_SYSCONFIG_RETURN_VALUE - as return value
//****************************************************************************
T_SYSCONFIG_RETURN_VALUE CSystemConfiguration::LoadPersistedPasswordConfig(void) {
#ifdef PWDLOGS_ENABLE
	WCHAR szDbgMsg[512];
#endif
	CFlashManager *pFlash = CFlashManager::GetHandle();
	//Passwords info is split over 2 blocks so need to do seperate reads for each
	ULONG siz1 = pFlash->GetDataBlockSize(FLASH_BLK_PASSWORDS);
	ULONG siz2 = pFlash->GetDataBlockSize(FLASH_BLK_PASSWORDS2);
#ifdef PWDLOGS_ENABLE
    swprintf( szDbgMsg, "CSystemConfiguration::LoadPersistedPasswordConfig : size of pwd info block 1 = %lu GTC %d\n",siz1,GetTickCount());
	OutputDebugString(szDbgMsg);
    swprintf( szDbgMsg, "CSystemConfiguration::LoadPersistedPasswordConfig : size of pwd info block 2 = %lu GTC %d\n",siz2,GetTickCount());
	OutputDebugString(szDbgMsg);
#endif
	T_SYSCONFIG_RETURN_VALUE retVal = SYSCONFIG_NO_PERSISTED_CONFIGURATION;
	if (siz1) {
		ULONG sizTotal = siz1 + siz2;
		BYTE *pBuf = new BYTE[sizTotal];
#ifdef PWDLOGS_ENABLE
        swprintf( szDbgMsg, "CSystemConfiguration::LoadPersistedPasswordConfig : size of pBuf = %d GTC %d\n",sizeof(pBuf),GetTickCount());
		OutputDebugString(szDbgMsg);
#endif
		if (FLASH_STATUS_OKAY == pFlash->ReadBlock(FLASH_BLK_PASSWORDS, pBuf, siz1)) {
			if (siz2 && (FLASH_STATUS_OKAY == pFlash->ReadBlock(FLASH_BLK_PASSWORDS2, pBuf + siz1, siz2))) {
				if (CONFIG_OK == m_pPasswordConfiguration->LoadConfig(pBuf, sizTotal))
					retVal = SYSCONFIG_OK;
			}
		}
#ifdef PWDLOGS_ENABLE
        swprintf( szDbgMsg, "CSystemConfiguration::LoadPersistedPasswordConfig : password block 1 GTC %d\n",GetTickCount());
		OutputDebugString(szDbgMsg);
#endif
		delete[] pBuf;
	}
	return retVal;
}
//*****************************************************************************
// Private Member Functions
//*****************************************************************************
//****************************************************************************
/// Attempt to indexOf and load the metadata required for the CMM, from the
/// project resources. 
/// 
/// @param[in] - None
///
/// @return SYSCONFIG_METADATA_LOADED - The metadata resource loaded correctly
/// @n SYSCONFIG_METADATA_NOT_LOADED - Error loading the Metadata Resource
///
//****************************************************************************
T_SYSCONFIG_RETURN_VALUE CSystemConfiguration::LoadMetadata(void) {
	T_SYSCONFIG_RETURN_VALUE retValue = SYSCONFIG_METADATA_NOT_LOADED; // Member Function Return Value
	HINSTANCE hResourceHandler = NULL;  // Handle to the default resources loaded
	HRSRC hMetaData = NULL;  // Handler to the Metadata Resource
	// Obtain a handler to the application'a resources
	hResourceHandler = ::AfxGetResourceHandle();
	// indexOf the Metadata Source
	hMetaData = indexOfResource(hResourceHandler, "Metadata", "V6Resource");
	if (NULL != hMetaData) {
		// Load the Resource for use
		m_hMetadataResourceHandler = LoadResource(hResourceHandler, hMetaData);
		if (NULL != m_hMetadataResourceHandler) {
			// Resource has been loaded correctly.
			retValue = SYSCONFIG_METADATA_LOADED;
		}
	}
	return (retValue);
}

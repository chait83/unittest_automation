/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  Control Sequencer
/// @n Filename:  SelfTest.cpp
/// @n Description: Implementation File for Class CSelfTest
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  6 Stability Project 1.1.1.3 7/2/2011 5:01:14 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  5 Stability Project 1.1.1.2 7/1/2011 4:38:54 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  4 Stability Project 1.1.1.1 3/17/2011 3:20:46 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  3 Stability Project 1.1.1.0 2/15/2011 3:03:55 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
#include "SelfTest.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//****************************************************************************
/// Class Constructor
//****************************************************************************
CSelfTest::CSelfTest(void) {
} // End of Constructor
//****************************************************************************
/// Class Destructor
//****************************************************************************
CSelfTest::~CSelfTest(void) {
} // End of Destructor
//****************************************************************************
/// This member will either directly or indirectly via calls to other 
/// member functions, perform the self test functionality of the V6
/// system. 
/// 
/// @param[in] - None
///
/// @return SELFTEST_OK - Self-Test performed successfully
//****************************************************************************
T_SELFTEST_RETURN_VALUE CSelfTest::PerformSelfTest(void) {
	return (SELFTEST_OK);
} // End of PerformSelfTest()

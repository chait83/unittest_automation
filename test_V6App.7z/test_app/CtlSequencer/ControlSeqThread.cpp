/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Control Sequencer
/// @n Filename: ControlSeqThread.cpp
/// @n Desc:	 Main thread for control sequencer
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 20-10-14 Rajanbabu M Fixed PAR:1-3I2GTSM - WSD communication is not working on upgrading the firmware
//  48  Stability Project 1.43.1.3 7/2/2011 4:56:20 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  47  Stability Project 1.43.1.2 7/1/2011 4:38:09 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  46  Stability Project 1.43.1.1 3/17/2011 3:20:17 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  45  Stability Project 1.43.1.0 2/15/2011 3:02:42 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// ****************************************************************
#include <wchar.h>
#include "PPL.h"
#include "ControlSeqThread.h"
#include "ControlSequencer.h"
#include "TraceDefines.h"
#include "SMTPThread.h"
#include "TopStatusBar.h"
#include "ProductionInterface.h"
#include "Registry.h"
#include "CertSubjectsStore.h"
#include "RemoteDispToolInterface.h"
#include "FileTransferService.h"
#include "RTCSyncThread.h"
// CControlSeqThread
// IMPLEMENT_DYNCREATE(CControlSeqThread, QThread)
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
CControlSeqThread::CControlSeqThread() {
}
CControlSeqThread::~CControlSeqThread() {
	CCESocket::DeleteSection();
}
BOOL CControlSeqThread::InitInstance() {
	// TODO: perform and per-thread initialization here
	return TRUE;
}
int CControlSeqThread::ExitInstance() {
	// TODO: perform any per-thread cleanup here
	QThread::exit();
	return 0;
}
//****************************************************************************************************
/// Control sequncer thread, first bring up the whole system using the various initialisation stages 
/// then drop into run mode, peforming configuration change sequnecing as required. 
///
/// @param[in] - lpParam as required by a ThreadFunc
///
/// @return CTRLSEQ_THREAD_EXIT_CODE
///
//****************************************************************************************************
UINT CControlSeqThread::ThreadFunc(LPVOID lpParam) {
#ifdef STARTUP_LOGGING
	WCHAR InitLogFileName[ 256 ];
	WCHAR InitLogString[512];
	int iPathLen = 256;
	BOOLEAN isFileCreated = FALSE;
	CStorage kLogFile;
	QFileDevice::FileError kFileEx;
#endif
#ifdef THREAD_ID_SERIAL_LOG
	  WCHAR szDbgMsg[512];
        swprintf( szDbgMsg, "CControlSeqThread::Thread id 0x%x, %lu ", GetThreadId(GetCurrentThread()), GetThreadId(GetCurrentThread()));
		OutputDebugString(szDbgMsg);
  #endif
	sleep(10000);
	CSMTPThread::InitCritSect();
	CCESocket::InitSection();
	// Initalise the message list services
	GlbDevCaps.DisplayTraceMemoryStatus("CControlSeqThread::ThreadFunc");
	pGlbMsgListSer = CMessageListServices::GetHandle();
	GlbDevCaps.DisplayTraceMemoryStatus("MsgListSer");
	const USHORT CTRLSEQ_THREAD_EXIT_CODE = 0x00; // value recommended by Microsoft
	T_CTRLSEQ_RETURN_VALUE systemStatus = CTRLSEQ_NORAMAL_OPERATION; // Controls main loop operation
	CControlSequencer *pControlSequencer = new CControlSequencer; // Control Sequencer Class
	wchar_t configurationName[10]; // Name of System Configuration to create
	T_CTRLSEQTH_OPERATIONAL_MODE *pCtrlSeqOperationalMode = (T_CTRLSEQTH_OPERATIONAL_MODE*) lpParam;
#ifdef UNDER_CE
  swprintf( configurationName, 10, L"%s", "RECORDER" );
  #else
	swprintf(configurationName, 10, "%s", "DESKTOP");
#endif
#ifdef STARTUP_LOGGING
	pDALGLB->GetPath(	static_cast< T_STORAGE_PATH >( IDS_INTERNAL_SD ), 
						InitLogFileName,
						256,
						&iPathLen );
    wcsncat( InitLogFileName, 256, "InitialisationLog.txt", (256 - wcslen( InitLogFileName )) );
	if( kLogFile.Open(	InitLogFileName, 
						CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
						&kFileEx ) )
	{
		kLogFile.SeekToEnd();
        wcscpy(InitLogString,"--------Initialisation started-------\n");
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
        wcscpy(InitLogString,"Initialise the Control Sequencer\n");
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	// ----------------------------------------------------------------------------------------------------------
	// 1: Initialise the Control Sequencer
	// -----------------------------------------------------------------------------------------------------------
	if (CTRLSEQ_OK != pControlSequencer->Initialise()) {
#ifdef STARTUP_LOGGING
        wcscpy(InitLogString,"CTRLSEQ: INITIALISATION FAILED\n");
		if( kLogFile.Open(	InitLogFileName, 
						CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
						&kFileEx ) )
		{
			kLogFile.SeekToEnd();		
			kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
			kLogFile.Close();
		}
#endif
		LOG_ERR( TRACE_CTRL_SEQUENCER, "CTRLSEQ: INITIALISATION FAILED");
		LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "CTRLSEQ: Initialisation failed");
	}
	// ----------------------------------------------------------------------------------------------------------
	// 2: Hardware initialisation ( Init DAL, Devcaps, Query IO cards, System Info, OEM Info, System Timer )
	// -----------------------------------------------------------------------------------------------------------
#ifdef STARTUP_LOGGING
    wcscpy(InitLogString,"2: Hardware initialisation\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();	
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	if (CTRLSEQ_OK != pControlSequencer->InitialiseHardware()) {
#ifdef STARTUP_LOGGING
        wcscpy(InitLogString,"CTRLSEQ: HARDWARE INITIALISATION FAILED\n");
		if( kLogFile.Open(	InitLogFileName, 
						CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
						&kFileEx ) )
		{
			kLogFile.SeekToEnd();	
			kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
			kLogFile.Close();
		}
#endif
		LOG_ERR( TRACE_CTRL_SEQUENCER, "CTRLSEQ: HARDWARE INITIALISATION FAILED");
		LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "CTRLSEQ: Hardware initialisation failed");
	}
	GlbDevCaps.DisplayTraceMemoryStatus("CTSEQ: Hardware initialised");
#ifdef STARTUP_LOGGING
    wcscpy(InitLogString,"3: Initialise Operational State\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();	
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	// ----------------------------------------------------------------------------------------------------------
	// 3: Initialise Operational State of the Control Sequencer, Normal operation, Test Mode etc...
	// -----------------------------------------------------------------------------------------------------------
	if (CTRLSEQ_OK != pControlSequencer->InitialiaseOperationalState()) {
#ifdef STARTUP_LOGGING
        wcscpy(InitLogString,"CTRLSEQ: COULD NOT INITIALISE OPERATIONAL STATE\n");
		if( kLogFile.Open(	InitLogFileName, 
						CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
						&kFileEx ) )
		{
			kLogFile.SeekToEnd();	
			kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
			kLogFile.Close();
		}
#endif
		LOG_ERR( TRACE_CTRL_SEQUENCER, "CTRLSEQ: COULD NOT INITIALISE OPERATIONAL STATE");
		LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "CTRLSEQ: Could not initialise operation state");
	}
	GlbDevCaps.DisplayTraceMemoryStatus("CTSEQ: Op State initialised");
#ifdef STARTUP_LOGGING
    wcscpy(InitLogString,"4: System Service Initialisation\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();	
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	// ----------------------------------------------------------------------------------------------------------
	// 4: System Service Initialisation, Data Item Table, Database integrity etc..
	// -----------------------------------------------------------------------------------------------------------
	pGlbSysInfo->SetStartupSection(SS_SYS_INTEGRITY);
	pGlbSysInfo->SetStartupAction("");
	pGlbSysInfo->SetStartupSubAction("");
	if (CTRLSEQ_OK != pControlSequencer->InitialiseSystemServices()) {
#ifdef STARTUP_LOGGING
        wcscpy(InitLogString,"CTRLSEQ: SYSTEM SERVICE INITIALISATION FAILED\n");
		if( kLogFile.Open(	InitLogFileName, 
						CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
						&kFileEx ) )
		{
			kLogFile.SeekToEnd();	
			kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
			kLogFile.Close();
		}
#endif
		LOG_ERR( TRACE_CTRL_SEQUENCER, "CTRLSEQ: SYSTEM SERVICE INITIALISATION FAILED");
		LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "CTRLSEQ: System service initialisation failed");
	}
	GlbDevCaps.DisplayTraceMemoryStatus("CTSEQ: Sys services initialised");
#ifdef STARTUP_LOGGING
    wcscpy(InitLogString,"5: Load up persisted Setup, Passwords and Layout\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();	
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	// ----------------------------------------------------------------------------------------------------------
	// 5: Load up persisted Setup, Passwords and Layout 
	// -----------------------------------------------------------------------------------------------------------
	pGlbSysInfo->SetStartupSection(SS_LOAD_CONFIGS);
	pGlbSysInfo->SetStartupAction("");
	pGlbSysInfo->SetStartupSubAction("");
	if (CTRLSEQ_OK != pControlSequencer->PerformSystemConfiguration(QString::fromWCharArray(configurationName))) {
#ifdef STARTUP_LOGGING
        wcscpy(InitLogString,"CTRLSEQ: SYSTEM CONFIGURATION FAILURE\n");
		if( kLogFile.Open(	InitLogFileName, 
						CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
						&kFileEx ) )
		{
			kLogFile.SeekToEnd();	
			kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
			kLogFile.Close();
		}
#endif
		LOG_ERR( TRACE_CTRL_SEQUENCER, "CTRLSEQ: SYSTEM CONFIGURATION FAILURE");
		LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "CTRLSEQ: System configuration failed");
	}
	GlbDevCaps.DisplayTraceMemoryStatus("CTSEQ: Configs loaded");
#ifdef STARTUP_LOGGING
    wcscpy(InitLogString,"6: Initialise PMM (password management module )\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();	
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	// ----------------------------------------------------------------------------------------------------------
	// 6: Initialise PMM (password management module )
	// -----------------------------------------------------------------------------------------------------------
	QString csTxt;
	csTxt = tr("Initializing PMM");
	pGlbSysInfo->SetStartupAction(csTxt.toLocal8Bit().data());
	if (CTRLSEQ_OK != pControlSequencer->InitialisePMM()) {
#ifdef STARTUP_LOGGING
        wcscpy(InitLogString,"CTRLSEQ: PMM INITIALISATION FAILED\n");
		if( kLogFile.Open(	InitLogFileName, 
						CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
						&kFileEx ) )
		{
			kLogFile.SeekToEnd();	
			kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
			kLogFile.Close();
		}
#endif
		LOG_ERR( TRACE_CTRL_SEQUENCER, "CTRLSEQ: PMM INITIALISATION FAILED");
		LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "CTRLSEQ: PMM inititialsation failed");
	}
	GlbDevCaps.DisplayTraceMemoryStatus("CTSEQ: Password initialised");
#ifdef STARTUP_LOGGING
    wcscpy(InitLogString,"7: Primary initialisation of Modules\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();	
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	// ----------------------------------------------------------------------------------------------------------
	// 7: Primary initialisation of Modules
	// -----------------------------------------------------------------------------------------------------------
	pGlbSysInfo->SetStartupSection(SS_START_MODULES);
	csTxt = tr("Performing Primary Initialization");
	pGlbSysInfo->SetStartupAction(csTxt.toLocal8Bit().data());
	pGlbSysInfo->SetStartupSubAction("");
	if (CTRLSEQ_OK != pControlSequencer->PerformPrimaryInitialisation()) {
#ifdef STARTUP_LOGGING
        wcscpy(InitLogString,"CTRLSEQ: PRIM PRE-THREAD INITIALISATION FAILED\n");
		if( kLogFile.Open(	InitLogFileName, 
						CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
						&kFileEx ) )
		{
			kLogFile.SeekToEnd();	
			kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
			kLogFile.Close();
		}
#endif
		LOG_ERR( TRACE_CTRL_SEQUENCER, "CTRLSEQ: PRIM PRE-THREAD INITIALISATION FAILED");
		LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "CTRLSEQ: Primary initialisation failed");
	}
	GlbDevCaps.DisplayTraceMemoryStatus("CTSEQ: Primary intialisation complete");
#ifdef STARTUP_LOGGING
    wcscpy(InitLogString,"8: Secondary initialisation of Modules\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();	
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	// ----------------------------------------------------------------------------------------------------------
	// 8: Secondary initialisation of Modules
	// -----------------------------------------------------------------------------------------------------------
	csTxt = tr("Performing Secondary Initialization");
	pGlbSysInfo->SetStartupAction(csTxt.toLocal8Bit().data());
	pGlbSysInfo->SetStartupSubAction("");
	if (CTRLSEQ_OK != pControlSequencer->PerformSecondaryInitialisation()) {
#ifdef STARTUP_LOGGING
        wcscpy(InitLogString,"CTRLSEQ: SEC PRE-THREAD INITIALISATION FAILED\n");
		if( kLogFile.Open(	InitLogFileName, 
						CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
						&kFileEx ) )
		{
			kLogFile.SeekToEnd();	
			kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
			kLogFile.Close();
		}
#endif
		LOG_ERR( TRACE_CTRL_SEQUENCER, "CTRLSEQ: SEC PRE-THREAD INITIALISATION FAILED");
		LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "CTRLSEQ: Secondary initialisation failed");
	}
	GlbDevCaps.DisplayTraceMemoryStatus("CTSEQ: Secondary intialisation complete");
#ifdef STARTUP_LOGGING
    wcscpy(InitLogString,"9: Start all active modules\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();	
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	// ----------------------------------------------------------------------------------------------------------
	// 9: Start all active modules
	// -----------------------------------------------------------------------------------------------------------
	csTxt = tr("Starting active modules");
	pGlbSysInfo->SetStartupAction(csTxt.toLocal8Bit().data());
	pGlbSysInfo->SetStartupSubAction("");
	if (CTRLSEQ_OK != pControlSequencer->StartActiveModules()) {
#ifdef STARTUP_LOGGING
        wcscpy(InitLogString,"CTRLSEQ: START ACTIVE MODULES FAILED\n");
		if( kLogFile.Open(	InitLogFileName, 
						CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
						&kFileEx ) )
		{
			kLogFile.SeekToEnd();	
			kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
			kLogFile.Close();
		}
#endif
		LOG_ERR( TRACE_CTRL_SEQUENCER, "CTRLSEQ: START ACTIVE MODULES FAILED");
		LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "CTRLSEQ: Active modules start failed");
	}
	GlbDevCaps.DisplayTraceMemoryStatus("CTSEQ: Start active modules complete");
#ifdef STARTUP_LOGGING
    wcscpy(InitLogString,"10: Inform All Active Modules that Setup Config is ready to use\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();	
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	// ----------------------------------------------------------------------------------------------------------
	// 10: Inform All Active Modules that Setup Config is ready to use
	// -----------------------------------------------------------------------------------------------------------
	csTxt = tr("Inform Modules Config Complete");
	pGlbSysInfo->SetStartupAction(csTxt.toLocal8Bit().data());
	pGlbSysInfo->SetStartupSubAction("");
	if (CTRLSEQ_OK != pControlSequencer->InformModulesSetupConfigComplete()) {
#ifdef STARTUP_LOGGING
        wcscpy(InitLogString,"CTRLSEQ: INFORM ACTIVE MODULES OF SETUP CONFIG CHANGE COMPLETE FAILED\n");
		if( kLogFile.Open(	InitLogFileName, 
						CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
						&kFileEx ) )
		{
			kLogFile.SeekToEnd();	
			kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
			kLogFile.Close();
		}
#endif
		LOG_ERR( TRACE_CTRL_SEQUENCER, "CTRLSEQ: INFORM ACTIVE MODULES OF SETUP CONFIG CHANGE COMPLETE FAILED");
		LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "CTRLSEQ: Inform modules setup config change failed");
	}
	GlbDevCaps.DisplayTraceMemoryStatus("CTSEQ: Start active modules complete");
#ifdef STARTUP_LOGGING
    wcscpy(InitLogString,"11: Inform modules to start execution\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();	
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	// ----------------------------------------------------------------------------------------------------------
	// 11: Inform modules to start execution, this will be based on the operation mode
	// ----------------------------------------------------------------------------------------------------------
	csTxt = tr("Inform Modules Begin Execution");
	pGlbSysInfo->SetStartupAction(csTxt.toLocal8Bit().data());
	pGlbSysInfo->SetStartupSubAction("");
	if ( NULL == pCtrlSeqOperationalMode) {
		if (CTRLSEQ_OK != pControlSequencer->InformModulesToBeginExecution(CTRLSEQTH_MODE_NORMAL_OPERATION)) {
#ifdef STARTUP_LOGGING
            wcscpy(InitLogString,"CTRLSEQ: BEGIN EXECUTION FAILURE\n");
			if( kLogFile.Open(	InitLogFileName, 
							CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
							&kFileEx ) )
			{
				kLogFile.SeekToEnd();	
				kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
				kLogFile.Close();
			}
#endif
			LOG_ERR( TRACE_CTRL_SEQUENCER, "CTRLSEQ: BEGIN EXECUTION FAILURE");
			LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "CTRLSEQ: Inform modules to begin executing failed");
		}
	} else {
		if (CTRLSEQ_OK != pControlSequencer->InformModulesToBeginExecution(*pCtrlSeqOperationalMode)) {
#ifdef STARTUP_LOGGING
            wcscpy(InitLogString,"CTRLSEQ: BEGIN EXECUTION FAILURE\n");
			if( kLogFile.Open(	InitLogFileName, 
							CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
							&kFileEx ) )
			{
				kLogFile.SeekToEnd();	
				kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
				kLogFile.Close();
			}
#endif
			LOG_ERR( TRACE_CTRL_SEQUENCER, "CTRLSEQ: BEGIN EXECUTION FAILURE");
			LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "CTRLSEQ: Inform modules to begin executing failed");
		}
	} // End of IF
	GlbDevCaps.DisplayTraceMemoryStatus("CTSEQ: active modules begin execution");
#ifdef STARTUP_LOGGING
    wcscpy(InitLogString,"12: Launch the OPC server\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();	
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
#ifdef STARTUP_LOGGING
    wcscpy(InitLogString,"13: Launch the RemoteDisplayServer\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();	
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	// ----------------------------------------------------------------------------------------------------------
	// 13: Launch the RemoteDisplayServer
	// ----------------------------------------------------------------------------------------------------------
#ifdef UNDER_CE
	pControlSequencer->LaunchRemoteDisplayServer();
    GlbDevCaps.DisplayTraceMemoryStatus( "CTSEQ: remote display server started" );
	
	if ( pGlbSysInfo )
	{
        QString tCertSub="";
        QString  strCertSub="";
        strCertSub = QString::asprintf("XS-%lu", pGlbSysInfo->GetSerialNumber());
        tCertSub = strCertSub;
		T_PCOMMUNICATIONS ptCommsData = pGlbSetup->GetCommsSetupConfig()->GetCommsBlock( CONFIG_COMMITTED );
		BOOL bGlobalCA = FALSE;
		if(ptCommsData!=NULL)
		{
			T_PCOMMUNICATIONS ptCommsData = pGlbSetup->GetCommsSetupConfig()->GetCommsBlock( CONFIG_COMMITTED );
		
			if(ptCommsData!=NULL)
			{
				bGlobalCA=ptCommsData->SecurityOptions.CACertificate;
				if(bGlobalCA)
				{
					CCertSubjectsStore cCertSubjectsStore;
                    tCertSub =cCertSubjectsStore.GetServerSubjectKey();
				}
			}
		}
        pControlSequencer->ValidateAndUpdateRegistry(tCertSub.toLocal8Bit().data());
	}
	//if ( pGlbSysInfo && pGlbSysInfo->FWOptionSecureWSDAvailable() ) //No More WSD
	//{
		//pControlSequencer->LaunchWSDService(); //no More WSD
	//}
	if ( pGlbSetup )
	{
		T_PCOMMUNICATIONS pCommsBlock = pGlbSetup->GetCommsSetupConfig()->GetCommsBlock(CONFIG_COMMITTED);
		if( (NULL != pCommsBlock) && (TRUE == pCommsBlock->FTP.SecureFTP) )
		{
			pControlSequencer->LaunchHtDataServer();
			/*CFileTransferService * pFTS = new CFileTransferService();
			pFTS->Start();*/
		}
	}
	if ( pGlbSysInfo && pGlbSysInfo->FWOptionRTDataBusAvailable() ) //Revert this later
	{
		pControlSequencer->LaunchRTDataServer();
	}
	// ----------------------------------------------------------------------------------------------------------
	// Launch the OPC UA Server
	// ----------------------------------------------------------------------------------------------------------
	T_PCOMMUNICATIONS ptCommsData = pGlbSetup->GetCommsSetupConfig()->GetCommsBlock( CONFIG_MODIFIABLE );
	T_OPCUA *ptOPCUA = &ptCommsData->OPCUA;
	if ( pGlbSysInfo && pGlbSysInfo->FWOptionOpcUaServerAvailable() && (ptOPCUA->Enabled == TRUE) )
		pControlSequencer->LaunchOpcUaServer();
#endif
#ifdef STARTUP_LOGGING
    wcscpy(InitLogString,"14: Inform the UI that the control sequence has completed syetem bring up\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();	
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	// ----------------------------------------------------------------------------------------------------------
	// 14: Inform the UI that the control sequence has completed syetem bring up
	// ----------------------------------------------------------------------------------------------------------
	PostMessage(AfxGetApp()->m_pMainWnd->m_hWnd, WM_CONTROL_SEQUENCER_READY, 0, 0);
	csTxt = tr("Information is being saved, please wait....");
	pGlbSysInfo->SetStartupAction(csTxt.toLocal8Bit().data());
	//pGlbSysInfo->SetStartupAction("Information is being saved, please wait....");
	pGlbSysInfo->SetStartupSubAction("");
	// reset the new registry flag now
	GlbDevCaps.ResetNewRegistryFlag();
#ifdef STARTUP_LOGGING
    wcscpy(InitLogString,"pSETUP->IsResetRequired()\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();	
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	//If WSD certificate is not installed then install in the application Startup.
	//During firmware upgrade, Certificate is getting deleted after reboot.
	//Observed when upgrading from 100.1 41R to 100.2 10R
#ifdef UNDER_CE
	ptCommsData = pGlbSetup->GetCommsSetupConfig()->GetCommsBlock( CONFIG_COMMITTED );
#else
	T_PCOMMUNICATIONS ptCommsData = pGlbSetup->GetCommsSetupConfig()->GetCommsBlock(CONFIG_COMMITTED);
#endif
	BOOL bGlobalCA = FALSE;
	QString wPassword = "";
	BOOL bfilesize = FALSE;
#ifdef DBG_FILE_LOG_CSQ_DBG_ENABLE
		QString  strDiagMsg;
		strDiagMsg = QString::asprintf("CSQ-ThreadFunc() - pSYSTEM_INFO->IsFirmwareUpgraded() returns TRUE");
		pControlSequencer->LogDebugMessage(strDiagMsg);
	#endif
	if (ptCommsData != NULL) {
		bGlobalCA = ptCommsData->SecurityOptions.CACertificate;
		if (bGlobalCA) {
			wPassword = QString::fromWCharArray(ptCommsData->SecurityOptions.CertPfxPassword);
		}
#ifdef DBG_FILE_LOG_CSQ_DBG_ENABLE
		QString  strDiagMsg;
		strDiagMsg = QString::asprintf("CSQ-ThreadFunc() - bGlobalCA %d",bGlobalCA);
		pControlSequencer->LogDebugMessage(strDiagMsg);
#endif
	}
	if (bGlobalCA) {
		CFlashManager *pFlashMngr = CFlashManager::GetHandle();
		ULONG filesize1 = pFlashMngr->GetDataBlockSize((T_FLASH_BLOCK) FLASH_BLK_ROOTCACERTIFICATE_2);
		ULONG filesize2 = pFlashMngr->GetDataBlockSize((T_FLASH_BLOCK) FLASH_BLK_DEVICECACERTIFICATE_3);
		if ((filesize1 > 0) && (filesize2 > 0)) {
			bfilesize = TRUE;
		}
#ifdef DBG_FILE_LOG_CSQ_DBG_ENABLE
		QString  strDiagMsg;
		strDiagMsg = QString::asprintf("CSQ-ThreadFunc() - Flash blk size for gobal ca cert %u : %u", filesize1,filesize2);
		pControlSequencer->LogDebugMessage(strDiagMsg);
#endif
	} else {
		CFlashManager *pFlashMngr = CFlashManager::GetHandle();
		ULONG fileSize = pFlashMngr->GetDataBlockSize((T_FLASH_BLOCK) FLASH_BLK_WSDCERTIFICATE_1);
		if (fileSize > 0) {
			bfilesize = TRUE;
		}
#ifdef DBG_FILE_LOG_CSQ_DBG_ENABLE
		QString  strDiagMsg;
		strDiagMsg = QString::asprintf("CSQ-ThreadFunc() - Flash blk size for Wsd cert %u", fileSize);
		pControlSequencer->LogDebugMessage(strDiagMsg);
#endif
	}
	//if(pSYSTEM_INFO->IsFirmwareUpgraded() == TRUE)	//ANOOP commented. Every recorder reboot, load the certificate from NOR FLASH
	if (bfilesize)	//ANOOP check whether we are able to load CERT from FLASH 
	{
#ifdef DBG_FILE_LOG_CSQ_DBG_ENABLE
		//QString  strDiagMsg;
		strDiagMsg = QString::asprintf("CSQ-ThreadFunc() - pSYSTEM_INFO->IsFirmwareUpgraded() returns TRUE");
		pControlSequencer->LogDebugMessage(strDiagMsg);
#endif
#ifdef UNDER_CE
		TCHAR tCertSub[MAX_PATH];
		QString  strCertSub;
        strCertSub = QString::asprintf("XS-%lu", pGlbSysInfo->GetSerialNumber());
        strcpy(tCertSub, strCertSub.toLocal8Bit().data());
		T_PCOMMUNICATIONS ptCommsData = pGlbSetup->GetCommsSetupConfig()->GetCommsBlock( CONFIG_COMMITTED );
		BOOL bGlobalCA = FALSE;
		if(ptCommsData!=NULL)
		{			
			bGlobalCA=ptCommsData->SecurityOptions.CACertificate;
			if(bGlobalCA)
			{
				CCertSubjectsStore cCertSubjectsStore;
                strcpy(tCertSub, cCertSubjectsStore.GetServerSubjectKey().toLocal8Bit().data());
			}
		}
		int ret=pDALGLB->CheckForServerCertificate(tCertSub);
		if(!ret)
		{
			if(bGlobalCA)
			{		
#ifdef DBG_FILE_LOG_CSQ_DBG_ENABLE
				QString  strDiagMsg;
				strDiagMsg = QString::asprintf("CSQ-ThreadFunc() -pDALGLB->CheckForServerCACertificate() %d",ret);
				pControlSequencer->LogDebugMessage(strDiagMsg);
#endif
                WCHAR *pwstr ;
                wPassword.toWCharArray(pwstr);
                pDALGLB->RestoreWSDCACertificates(pwstr);
			}
			else
			{
				pDALGLB->RestoreWSDCertificate();
			}
		}
#endif	
	}
#ifdef UNDER_CE
	if ((pSYSTEM_INFO->IsFirmwareUpgraded() == TRUE))
	{
		CFlashManager* pFlashMngr = CFlashManager::GetHandle();
		ULONG fileSize = pFlashMngr->GetDataBlockSize((T_FLASH_BLOCK)FLASH_BLK_EMAILROOTCERTIFICATE);
		if (fileSize > 0)
		{
			pDALGLB->RestoreEmailCertificate();
		}
	}
#endif
#ifdef UNDER_CE
	if(pSYSTEM_INFO->IsFirmwareUpgraded() == TRUE) // Only during firmware upgrade.
	{
		pDALGLB->InstallRootCertificate(TRUE);// for 2048 certificate
		pDALGLB->InstallRootCertificate(FALSE); // for 1024 certificate	
	
	}
	else
	{
		CCertSubjectsStore cCertSubjectsStore;
		QString  strPubKey= cCertSubjectsStore.GetPubRootCertificateKey();
        if(0!=strPubKey.compare("Y"))
		{
			pDALGLB->InstallRootCertificate(TRUE);// for 2048 certificate
			pDALGLB->InstallRootCertificate(FALSE); // for 1024 certificate			
		}
	}
#endif
	// begin trigger a reboot if necessary because of configuration changes
	// Notify the user that a shutdown is required
	if ( pSETUP->IsResetRequired()) {
		// trigger a restart
        LPARAM lRebootParam;
        *lRebootParam= CTopStatusBar::slpREBOOT_PENDING;
        *lRebootParam |= CTopStatusBar::slpTRIGGER_RESTART;
		// post the message to the top status bar
		::PostMessage(CTopStatusBar::Instance()->m_hWnd, WM_CHANGE_TOPBAR_MODE, TOPBAR_MODE_LOCK, lRebootParam);
	}
	// ----------------------------------------------------------------------------------------------------------
	// Startup the thread responsible for daylight saving.....
	//
	// The call to this thread has been stopped as the event handling of the DST/SDT is handled by WinCE OS 
	// No need to handle this event through V6App.
	// ----------------------------------------------------------------------------------------------------------
	//StartDaylightSavingThread();
#ifdef STARTUP_LOGGING
    wcscpy(InitLogString,"QThread *pkThread = AfxBeginThread\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();	
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	QThread *pkThread = new QThread();
//            CSMTPThread::EmailNotificationThreadFunc
	pkThread->start();
	// ----------------------------------------------------------------------------------------------------------
	// Startup the thread responsible for configuring the recorder for Production Interface.....
	// ----------------------------------------------------------------------------------------------------------
#ifdef UNDER_CE
	ULONG fileSize = 0U;
	CFlashManager* pFlashMngr = NULL;
	pFlashMngr = CFlashManager::GetHandle();
	fileSize = pFlashMngr->GetDataBlockSize((T_FLASH_BLOCK)FLASH_BLK_WSDCERTIFICATE_1);
	CProductionInterface *pProductionInterface = NULL;
	if ((DEFAULT_SERIAL_NUMBER == pGlbSysInfo->GetSerialNumber()) || (fileSize <= 0) || (pGlbSysInfo->IsFunctionAvailable(FUNC_PROTECT_PRODUCTION, FALSE)== TRUE))
	{
		pProductionInterface = new CProductionInterface();
		pProductionInterface->ProductionInterfaceFunc();
	}
	CRemoteDispToolInterface *pRemoteDispToolInterface = NULL;
	pRemoteDispToolInterface = new CRemoteDispToolInterface();
	pRemoteDispToolInterface->RemoteDispToolInterfaceFunc();
#endif
#ifdef UNDER_CE
	CRTCSyncThread *pRTCManager = CRTCSyncThread::GetHandle();
	pRTCManager->Initialise();
#endif
#ifdef STARTUP_LOGGING
    wcscpy(InitLogString,"15: RUN MODE, this will perform normal operation until a configuration \n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();	
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	// ==========================================================================================================
	// 15: RUN MODE, this will perform normal operation until a configuration chnage or shutdown is requested
	// ==========================================================================================================
	do {
		switch (pControlSequencer->GetOperationalState()) {
		case CTRLSEQ_STATE_NORMAL_OPERATION:	// Perform Normal Operation
			systemStatus = pControlSequencer->PerformNormalOperation();
			break;
		case CTRLSEQ_STATE_SELF_TEST:	// Perform Self Test
			systemStatus = pControlSequencer->PerformSelfTest();
			break;
		default:
			break;
		}
	} while (CTRLSEQ_NORAMAL_OPERATION == systemStatus);
	//==== END RUN MODE ==========================================================================================
	// At this stage all active modules have been stopped
	//============================================================================================================
	//pGlbSysInfo->SetStartupSubAction("Run Mode Stopped, Setting Operational State");
	// ----------------------------------------------------------------------------------------------------------
	// 16: Set operation state dependent on the run mode
	// ----------------------------------------------------------------------------------------------------------
#ifdef STARTUP_LOGGING
    wcscpy(InitLogString,"16: Set operation state dependent on the run mode\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();	
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	switch (systemStatus) {
	case CTRLSEQ_CHANGE_STATE_SELFTEST: // Set Operational State for Self-test
	{
		pControlSequencer->SetOperationalState(CTRLSEQ_STATE_SELF_TEST);
		break;
	}
	case CTRLSEQ_CHANGE_STATE_NORMALOP:	// Set Operational State to Normal Operation
	{
		pControlSequencer->SetOperationalState(CTRLSEQ_STATE_NORMAL_OPERATION);
		break;
	}
	default:
		break;
	}
#ifdef STARTUP_LOGGING
    wcscpy(InitLogString,"17: Cleanup the system and delete control sequncer and tracer objects, exit thread\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();	
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	// ----------------------------------------------------------------------------------------------------------
	// 17: Cleanup the system and delete control sequncer and tracer objects, exit thread
	// ----------------------------------------------------------------------------------------------------------
	csTxt = tr("Cleaning Up");
	pGlbSysInfo->SetStartupSubAction(csTxt);
	pControlSequencer->SystemCleanUp();	// Delete Configurations, Active and Passive modules
	::sleep(10000);
	pDALGLB->CleanUp();
	/*OutputDebugString(_T("CTRLSEQ_THREAD:Perform Reboot\n"));
	 pDALGLB->PerformReboot();*/
#ifdef UNDER_CE
	if(NULL != pProductionInterface)
		delete ( pProductionInterface );  //Delete the ProductionInterface  
	if(NULL != pRemoteDispToolInterface)
		delete ( pRemoteDispToolInterface );
	#endif
	delete (pControlSequencer);		// Delete the Control Sequencer created
	delete (g_pTracer);		// Delete the Tracer Singleton
#ifdef STARTUP_LOGGING
    wcscpy(InitLogString,"----END of Total APP Initialisation-----\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();	
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	return (CTRLSEQ_THREAD_EXIT_CODE);
}

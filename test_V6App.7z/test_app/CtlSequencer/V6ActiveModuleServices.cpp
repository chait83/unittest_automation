#include "V6ActiveModuleServices.h"
#include <QThread>
#include "IOScheduler.h"
#include "DataProcessing.h"
#include "IOSimulator.h"
#include "IOSchedulerThread.h"
#include "ProcessingThread.h"
#include "IOSimulatorThread.h"
#include "TxScheduler.h"
#include "ModbusWrapper.h"
#include "AutoOpsProcessing.h"
#include "AutoOpsProcessingThread.h"
#include "P2PModuleThread.h"
#include "P2PModule.h"
#include "AMS2750buildTUSFile.h"
#include "tusfilethread.h"
#define THREAD_PRIORITY_ABOVE_NORMAL
CV6ActiveModuleServices::CV6ActiveModuleServices(void) {
	// Initialise Active Modules Pointer to NULL
	for (USHORT activeModuleIndex = 0; activeModuleIndex < V6AMSER_NUM_OF_ACTIVE_MODULES; ++activeModuleIndex) {
		m_ActiveModule[activeModuleIndex] = NULL;
	} // End of FOR 
} // End of Constructor
CV6ActiveModuleServices::~CV6ActiveModuleServices(void) {
	DeleteActiveModules();
} // End of Destructor
/// Create all the active modules
T_V6AMSER_RETURN_VALUE CV6ActiveModuleServices::CreateActiveModules(void) {
	T_V6AMSER_RETURN_VALUE retValue = V6AMSER_OK;
	// Create All Active Modules
	m_ActiveModule[V6AMSER_IO_SCHEDULER] = new CIOScheduler(MODULE_IO_SCHEDULER); // , MODULE_USE_EVENT );
	m_ActiveModule[V6AMSER_DATA_PROCESSING] = new CDataProcessing(MODULE_PROCESSING); //, MODULE_MANUAL );
	//m_ActiveModule[V6AMSER_MESSAGE_LIST_PROCESSING] = new CMessageListProcessing( MODULE_MESSAGE_LIST ); 
	m_ActiveModule[V6AMSER_MODBUS_SLAVE] = new CModBusSlave(MODULE_MODBUS_SLAVE);				// Modbus slave
	m_ActiveModule[V6AMSER_MODBUS_MASTER] = new CModBusMaster(MODULE_MODBUS_MASTER);			// Modbus master
	m_ActiveModule[V6AMSER_IO_SIMULATOR] = new CIOSimulator(MODULE_IO_SIMULATOR);
	m_ActiveModule[V6AMSER_EXPORT_SCHEDULER] = new CTxSchedule(MODULE_EXPORT_SCHEDULER);// Export/date transfer scheduler
	m_ActiveModule[V6AMSER_AUTO_OPS] = new CAutoOpsProcessing(MODULE_AUTO_OPS);
	m_ActiveModule[V6AMSER_P2P_ENGINE] = new CP2PModule(MODULE_P2P_ENGINE);
	m_ActiveModule[V6AMSER_TUS_FILE_BUILDER] = new C2750BuildTUSFile(MODULE_TUS_FILE_BUILDER);
#ifdef UNDER_CE 
	#ifndef DISABLE_WDT	
		//Create an instance of WatchDog Timer
		m_ActiveModule[V6AMSER_WATCHDOG_TIMER ] = new CWatchDogTimer(MODULE_WATCHDOG_TIMER);
	#endif
	#endif
	// Check to ensure each module has been successfully created
	for (USHORT activeModuleIndex = 0; activeModuleIndex < V6AMSER_NUM_OF_ACTIVE_MODULES; ++activeModuleIndex) {
		if (NULL == m_ActiveModule[activeModuleIndex]) {
			retValue = V6AMSER_MODULE_CREATION_FAILED;
			//LOG_ERR(TRACE_CTRL_SEQUENCER, "IO Scheduler Object Creation Failure"); 
		} // End of IF
	} // End of FOR
	return (retValue);
} // End of Member Function  
/// Initialise the Active Modules
T_V6AMSER_RETURN_VALUE CV6ActiveModuleServices::InitialiseActiveModules(void) {
	T_V6AMSER_RETURN_VALUE retValue = V6AMSER_OK;
    m_ActiveModule[V6AMSER_IO_SCHEDULER]->InitialiseActiveModule(MODULE_USE_EVENT, CIOSchedulerThread::ThreadFunc, THREAD_PRIORITY_ABOVE_NORMAL);
    m_ActiveModule[V6AMSER_DATA_PROCESSING]->InitialiseActiveModule(MODULE_MANUAL, CProcessingThread::ThreadFunc, THREAD_PRIORITY_NORMAL);
	/*    
	 m_ActiveModule[V6AMSER_MESSAGE_LIST_PROCESSING]->InitialiseActiveModule( MODULE_USE_EVENT,
	 CMessageListProcessingThread::ThreadFunc,
	 m_ActiveModule[V6AMSER_MESSAGE_LIST_PROCESSING],
	 THREAD_PRIORITY_NORMAL ); 
	 */
	m_ActiveModule[V6AMSER_MODBUS_SLAVE]->InitialiseActiveModule(MODULE_USE_EVENT, CModbusSlaveThread::ThreadFunc,
			m_ActiveModule[V6AMSER_MODBUS_SLAVE], THREAD_PRIORITY_NORMAL);				// Check priority
	m_ActiveModule[V6AMSER_MODBUS_MASTER]->InitialiseActiveModule(MODULE_USE_EVENT, CModbusMasterThread::ThreadFunc,
			m_ActiveModule[V6AMSER_MODBUS_MASTER], THREAD_PRIORITY_NORMAL);				// Check priority
	m_ActiveModule[V6AMSER_IO_SIMULATOR]->InitialiseActiveModule(MODULE_USE_EVENT, CIOSimulatorThread::ThreadFunc,
			m_ActiveModule[V6AMSER_IO_SIMULATOR], THREAD_PRIORITY_NORMAL);
	m_ActiveModule[V6AMSER_EXPORT_SCHEDULER]->InitialiseActiveModule(MODULE_USE_EVENT, CTxThread::ThreadFunc,
			m_ActiveModule[V6AMSER_EXPORT_SCHEDULER], THREAD_PRIORITY_NORMAL);
	m_ActiveModule[V6AMSER_AUTO_OPS]->InitialiseActiveModule(MODULE_USE_EVENT, CAutoOpsProcessingThread::ThreadFunc,
			m_ActiveModule[V6AMSER_AUTO_OPS], THREAD_PRIORITY_NORMAL);
	m_ActiveModule[V6AMSER_P2P_ENGINE]->InitialiseActiveModule(MODULE_MANUAL, CP2PModuleThread::ThreadFunc,
			m_ActiveModule[V6AMSER_P2P_ENGINE], THREAD_PRIORITY_NORMAL);
	m_ActiveModule[V6AMSER_TUS_FILE_BUILDER]->InitialiseActiveModule(MODULE_USE_EVENT, CTUSFileThread::ThreadProc,
			m_ActiveModule[V6AMSER_TUS_FILE_BUILDER], THREAD_PRIORITY_NORMAL);
#ifdef UNDER_CE 
	#ifndef DISABLE_WDT	
	////Initialise the WatchDog Timer thread
	m_ActiveModule[ V6AMSER_WATCHDOG_TIMER ]->InitialiseActiveModule( MODULE_USE_EVENT,
																			 CWatchDogTimerThread::ThreadFunc,
																			 m_ActiveModule[ V6AMSER_WATCHDOG_TIMER ],
																			 THREAD_PRIORITY_HIGHEST );
	#endif
	#endif
	return (retValue);
} // End of Member Function
T_V6AMSER_RETURN_VALUE CV6ActiveModuleServices::DeleteActiveModules(void) {
	T_V6AMSER_RETURN_VALUE retValue = V6AMSER_OK;
	// Delete All Created Active Modules from the Heap
	for (USHORT activeModuleIndex = 0; activeModuleIndex < V6AMSER_NUM_OF_ACTIVE_MODULES; ++activeModuleIndex) {
		if (NULL != m_ActiveModule[activeModuleIndex]) {
			delete m_ActiveModule[activeModuleIndex];
			m_ActiveModule[activeModuleIndex] = NULL;
		} // End of IF
	} // End of FOR
	return (retValue);
} // End of Member Function

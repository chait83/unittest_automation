/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  Control Sequencer
/// @n Filename:  ControlSequencer.h
/// @n Description: Class Declaration for the Control Sequencer
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  32  Stability Project 1.29.1.1 7/2/2011 4:56:20 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  31  Stability Project 1.29.1.0 7/1/2011 4:27:08 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  30  V6 Firmware 1.29 4/26/2007 8:50:41 PM  Roger Dawson  
//  Added code for logging diagnostic messages on network
//  connected/disconnected state changes.
//  29  V6 Firmware 1.28 11/9/2006 9:38:43 PM  Roger Dawson  
//  Fixed screen designer compilation issue.
// $
//
#ifndef _CONTROLSEQUENCER_H
#define _CONTROLSEQUENCER_H
#include "ModuleConstants.h"
#include "ModuleMsgManagerClient.h"
#include "ControlSeqThread.h"
#include "SystemConfiguration.h"
#include "NormalOperation.h"
#include "SelfTest.h"
#include "SRAM.h"
#include "InternalMessageQueue.h"
#ifndef DOCVIEW
#include "ModbusWrapper.h"
#endif
#include "DataItemTable.h"
#include "QueueManager.h"
#include "V6ActiveModuleServices.h"
#include "V6PassiveModuleServices.h"
#ifdef DBG_FILE_LOG_CSQ_DBG_ENABLE
#include "CStorage.h"
#endif
const BOOL CTRLSEQ_INT_MEDIA_NOT_PREPARED = FALSE;	///< Value to indicate Media is not prepare for use
const USHORT CTRLSEQ_DEFAULT_ZERO = 0;		///< Default Value of Zero
/// A Enumeration for active modules
typedef enum E_CTRLSEQ_ACTIVE_MODULES {
	CTRLSEQ_AM_IO_SCHEDULER, CTRLSEQ_AM_DATA_PROCESSING,
	// CTRLSEQ_AM_MODBUS,
	CTRLSEQ_AM_NUM_OF_ACTIVE_MODULES
} T_CTRLSEQ_ACTIVE_MODULES;
/// A Enumeration detailing the tpye of application using used
typedef enum E_CTRLSEQ_APPLICATION {
	CTRLSEQ_DESKTOP, CTRLSEQ_RECORDER
} T_CTRLSEQ_APPLICATION;
/// A Enumeration detailing the registration status of a particular module
typedef enum E_CTRLSEQ_MODULE_REGISTRATION_STATUS {
	CTRLSEQ_MODULE_NOT_REGISTERED, CTRLSEQ_MODULE_REGISTERED
} T_CTRLSEQ_MODULE_REGISTRATION_STATUS;
/// A Enumeration detailing the Actions to be performed on startup
typedef enum _E_CTRLSEQ_ACTION_TO_PERFORM {
	CTRLSEQ_AP_NOT_INITIALISED, CTRLSEQ_AP_NO_ACTION_REQUIRED,
} T_CTRLSEQ_ACTION_TO_PERFORM;
/// A Enumeration detailing the states of the Control Sequencer
typedef enum E_CTRLSEQ_STATE {
	CTRLSEQ_STATE_NOT_INITIALISED, CTRLSEQ_STATE_NORMAL_OPERATION, CTRLSEQ_STATE_SELF_TEST
} T_CTRLSEQ_STATE;
/// A Structure that will be used to store individual module message
/// notification requirements.
typedef struct _moduleRegistration {
	T_CTRLSEQ_MODULE_REGISTRATION_STATUS registrationStatus; ///< Indication whether module has registered
	T_MOD_REGISTRATION_MSGDATA registeredInformation;  ///< The messages the module wishs to be notified of. 
} T_CTRLSEQ_MOD_REGISTRATION_INFO, *T_PCTRLSEQ_MOD_REGISTRATION_INFO;
/// Information regarding the Opertional State of the Control Sequencer
typedef struct E_CTRLSEQ_OPERATIONAL_STATE {
	T_CTRLSEQ_STATE operationalState;   ///< Current Operational State
	T_CTRLSEQ_ACTION_TO_PERFORM actionToBePerformedOnStartup; ///< Action to be performed on Startup
} T_CTRLSEQ_OPERATIONAL_STATE, *T_PCTRLSEQ_OPERATIONAL_STATE;
/// Return Values for CControlSequencer Member Functions, used to describe the type of 
/// success or failure.
//
typedef enum E_CTRLSEQ_RETURN_VALUE {
	CTRLSEQ_OK,
	CTRLSEQ_INITIALISATION_FAILED,
	CTRLSEQ_RESTART_SYSTEM,
	CTRLSEQ_SYSTEM_CONFIGURATION_FAILED,
	CTRLSEQ_OBJECT_CREATION_FAILURE,
	CTRLSEQ_LOADING_DLL_FAILURE,
	CTRLSEQ_INIT_HARWARE_FAILURE,
	CTRLSEQ_MODULE_REGISTRATION_FAILED,
	CTRLSEQ_SYSTEM_RESTART_FAILURE,
	CTRLSEQ_CHANGE_STATE_NORMALOP,
	CTRLSEQ_CHANGE_STATE_SELFTEST,
	CTRLSEQ_NORAMAL_OPERATION,
	CTRLSEQ_INIT_SYSTEM_SERVICE_FAILURE,
	CTRLSEQ_START_MODULE_FAILURE,
	CTRLSEQ_PRI_PRE_THREAD_FAILURE,
	CTRLSEQ_SEC_PRE_THREAD_FAILURE,
	CTRLSEQ_NORMAL_OPERATION_FAILURE,
	CTRLSEQ_OPCSERVER_LAUNCH_FAILURE,
	CTRLSEQ_OPCENUM_LAUNCH_FAILURE
} T_CTRLSEQ_RETURN_VALUE;
//**Class*********************************************************************
///
/// @brief Main Control Sequencer for the V6 Project
/// 
/// Performs all the neccessary initialisation, System Configuration, 
/// Module Startup and Co-ordination of the the V6 system. This class is
/// responsible for controlling the V6 system. 
//****************************************************************************
class CControlSequencer {
public:
	/// Constructor
	CControlSequencer(void);
	/// Destructor
	virtual ~CControlSequencer(void);
	/// Initialise the Control Sequencer
	T_CTRLSEQ_RETURN_VALUE Initialise(void);
	/// Create Module Objects used witin the System
	T_CTRLSEQ_RETURN_VALUE CreateModuleObjects(void);
	/// Initialise Hardware for Operation
	T_CTRLSEQ_RETURN_VALUE InitialiseHardware(void);
	/// Initialise Services within throughout the System
	T_CTRLSEQ_RETURN_VALUE InitialiseSystemServices(void);
	/// Load the required DLL's
	T_CTRLSEQ_RETURN_VALUE LoadDynamicLinkLibraries(void);
	/// Perform System Configuration
	T_CTRLSEQ_RETURN_VALUE PerformSystemConfiguration(QString pName);
	/// Perform Primary Initialisation for the V6 System
	T_CTRLSEQ_RETURN_VALUE PerformPrimaryInitialisation(void);
	/// Perform Secondary Initialisation for the V6 System
	T_CTRLSEQ_RETURN_VALUE PerformSecondaryInitialisation(void);
	/// Start the Main Execution Thread of each Module
	T_CTRLSEQ_RETURN_VALUE StartActiveModules(void);
	/// Inform the required modules to Perform Normal Operation
	T_CTRLSEQ_RETURN_VALUE InformModulesSetupConfigComplete(void);
	/// Inform required module to perform normal operation
	T_CTRLSEQ_RETURN_VALUE InformModulesToPerformNormalOperation(void);
	/// Inform the required modules to Begin Execution, modules informed depends on the Operational State required
	T_CTRLSEQ_RETURN_VALUE InformModulesToBeginExecution(const T_CTRLSEQTH_OPERATIONAL_MODE ctrlSeqOperationMode);
	/// Perform Normal Operation of the Control Sequencer
	T_CTRLSEQ_RETURN_VALUE PerformNormalOperation(void);
#ifndef TTR6SETUP
	/// Perform Self Test
	T_CTRLSEQ_RETURN_VALUE PerformSelfTest(void);
#endif
	/// Initialise the Operational State of the Control Sequencer
	T_CTRLSEQ_RETURN_VALUE InitialiaseOperationalState(void);
	/// Set the Operational State of the Control Sequencer
	T_CTRLSEQ_RETURN_VALUE SetOperationalState(T_CTRLSEQ_STATE newState);
	/// Get the current Operational Current of the Control Sequencer
	T_CTRLSEQ_STATE GetOperationalState(void);
	/// Clean-up the system 
	T_CTRLSEQ_RETURN_VALUE SystemCleanUp(void);
	/// Perform Scheduled Events - Periodically
	T_CTRLSEQ_RETURN_VALUE PerformScheduledEvents(void);
	/// Perform Events Scheduled every 5 seconds
	T_CTRLSEQ_RETURN_VALUE PerformSchEventsFiveSec(void);
	/// Perform Events Scheduled every 30 seconds
	T_CTRLSEQ_RETURN_VALUE PerformSchEventsThirySec(void);
	/// Restart the System
	T_CTRLSEQ_RETURN_VALUE PerformSystemRestart(void);
	/// Exit the Control Sequencer main operational thread
	T_CTRLSEQ_RETURN_VALUE ExitControlSequencer(void);
	T_CTRLSEQ_RETURN_VALUE InitialisePMM(void);
	//Launch the RemoteDisplayServer
	void LaunchRemoteDisplayServer(void);
	void LaunchRTDataServer(void);
	void LaunchWSDService(void);
	void LaunchOpcUaServer(void);
	void LaunchHtDataServer(void);
	void TrainingStop();
	void TrainingReStart();
	void ValidateAndUpdateRegistry(TCHAR *certName);
	//PSR - Debig log enable in Control Sequencer
#ifdef DBG_FILE_LOG_CSQ_DBG_ENABLE
	void LogDebugMessage(QString  strDiagMsg);
#endif
	// Keeps the information for V6OPCServer.exe Process.
	PROCESS_INFORMATION m_piProcessInfo;
	PROCESS_INFORMATION m_piOPCEnumProcessInfo;
	// Remote Display Server process handle information
	PROCESS_INFORMATION m_RemoteProcessInfo;
	// RT Server process handle information
	PROCESS_INFORMATION m_RTProcessInfo;
	//WSD process handle information
	PROCESS_INFORMATION m_WSDProcessInfo;
	//OPC UA server process handle information
	PROCESS_INFORMATION m_OpcUaProcessInfo;
	static bool checkIfNetworkAvailable();
private:
	// --- Private Member Functions --- // 
	/// Initialise the Control Sequencer
	T_CTRLSEQ_RETURN_VALUE InitialiseControlSequencer(void);
	/// Data Item Table Initialisation
	T_CTRLSEQ_RETURN_VALUE InitialiseDataItemTable();
	/// Pre Process Queue Initialisation
	T_CTRLSEQ_RETURN_VALUE InitialisePreProcQManager();
	/// Calculate the size and number of data block queue files
	T_CTRLSEQ_RETURN_VALUE CreateQueueSize(T_QMC_INITIALISATION_TYPE type);
	// Method that checks the network connectivity and generates a diagnostic message
	// whenever the state changes
	void CheckNetworkConnectivity();
	// --- Private Member Variables --- //
	TV_BOOL m_bPmmDefaultConfig;
	/// Information obtained from Registered Modules as to which messages they wish to recieve
	T_CTRLSEQ_MOD_REGISTRATION_INFO m_ModuleRegisteredForMsgs[MODULE_NUM_OF_MODULES];
	/// Pointer to the Operational State of the Control Sequencer
	T_CTRLSEQ_OPERATIONAL_STATE *m_pOperationalState;
	class CTimerNotificationThread *m_pTimerNotificationThread; ///< Schedule Events Pointer
	class CNormalOperation m_NormalOperation; ///< Normal Operation Functionality
	class CModuleMsgManagerClient m_MMMCtrlSeqClient; ///< Module Message Manager Client
	class CSystemConfiguration m_SystemConfiguration; ///< System Configuration Functionality
	class CSRAMRegion *m_pRegion; ///< Pointer to the SRAM Region
#ifndef TTR6SETUP
#ifndef V6IOSETUP
	class CSelfTest m_SelfTest; ///< Self-Test Functionality
#endif
#endif
	// Module Pointers
	class CInternalMessageQueue *m_pInternalMessageQueue;
	// class CStoragePaths *m_pStoragePaths;
	class CTransactionStatus *m_pTransactionStatus;
	class CV6ActiveModuleServices m_AModSer;
	class CV6PassiveModuleServices m_PModSer;
	//PSR - Debig log enable in Control Sequencer
#ifdef DBG_FILE_LOG_CSQ_DBG_ENABLE
	CDebugFileLogger m_debugFileLogger;
#endif
	static bool m_bNetworkConnection;
};
// End of CControlSequencer Declaration
#endif // _CONTROLSEQUENCER_H

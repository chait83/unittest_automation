#ifndef _TIMERNOTIFICATIONTHREAD_H
#define _TIMERNOTIFICATIONTHREAD_H
// CTimerNotificationThread
#include <QThread>
#include "Defines.h"
class CTimerNotificationThread: public QThread {
	// DECLARE_DYNCREATE (CTimerNotificationThread)
protected:
	CTimerNotificationThread();  // protected constructor used by dynamic creation
	virtual ~CTimerNotificationThread();
public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
public:
	static UINT TimerNotificationThreadFunc(LPVOID lpParam);
};
#endif

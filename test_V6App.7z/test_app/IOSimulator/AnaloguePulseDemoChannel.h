/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  IO Simulator
/// @n Filename:  AnaloguePulseDemoChannel.h
/// @n Description: Class Declaration for Analogue/Pulse Demo Channel
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  5 Stability Project 1.2.1.1 7/2/2011 4:55:25 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  4 Stability Project 1.2.1.0 7/1/2011 4:27:22 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  3 V6 Firmware 1.2 6/1/2005 9:23:31 PM Alistair Brugsch
//  Changed GetChannelReference to be Zero Based instead of One Based. 
//  2 V6 Firmware 1.1 5/31/2005 8:07:06 PM  Alistair Brugsch
//  Changed Major functionality of Class 
// $
//
// **************************************************************************
#ifndef _ANALOGUEPULSEDEMOCHANNEL_H
#define _ANALOGUEPULSEDEMOCHANNEL_H
#include "PPQCommon.h"
#include "BoardChannelCommonDefines.h"
#include "DemoWaves.h"
const USHORT APDEMOCHAN_ONE_CHANNEL = 1; ///< Constant Represents One Channel
const USHORT APDEMOCHAN_INVALID_CHANNEL_NUMBER = 0xFFFF; ///< Constant represents an Invalid Channel Number
/// Enumeration for Member function Return Values to indicate success and failure conditions
typedef enum _eAPDemoChannelReturnValue {
	APDEMOCHAN_OK, APDEMOCHAN_INITIALISATION_FAILED
} T_APDEMOCHAN_RETURN_VALUE;
/// Enumeration to represent the status of the Channel in terms of Enabled and Disabled 
typedef enum _eAPDemoChannelStatus {
	APDEMOCHAN_CHANNEL_ENABLED, APDEMOCHAN_CHANNEL_DISABLED
} T_APDEMOCHAN_CHANNEL_STATUS;
//**Class*********************************************************************
///
/// @brief ---Single line description---.
/// 
/// --- Detailed Description ---
///
//****************************************************************************
class CAnaloguePulseDemoChannel {
public:
	/// Constructor
	CAnaloguePulseDemoChannel(void);
	/// Destructor
	virtual ~CAnaloguePulseDemoChannel(void);
	/// Initialise the Channel
	T_APDEMOCHAN_RETURN_VALUE Initialise(const USHORT channelNumber, const USHORT slotNo, const USHORT boardChanNo);
	/// Setup the Channel for Operation
	T_APDEMOCHAN_RETURN_VALUE SetupChannel(const T_BRDCHANDEF_ACQUSITION_RATE acqRate, const FLOAT zero,
			const FLOAT span, const FLOAT noise, const T_DEMOWAVE_TYPES waveType, const INT waveDuration,
			const INT sourceTickRate);
	/// Reset the Channel to Default 
	T_APDEMOCHAN_RETURN_VALUE ResetChannel(void);
	/// Get Channel Reference which is used for the Pre Process Queue, Channels are Zero Based
	/// hence we need to minus 1 from the Channel Number which is One Based. 
	USHORT GetChannelReference(void) {
		return (m_ChannelNumber - APDEMOCHAN_ONE_CHANNEL);
	}
	/// Obtain the Channel Status
	T_APDEMOCHAN_CHANNEL_STATUS GetChannelStatus(void) const {
		return (m_ChannelStatus);
	}
	/// Obtain the Channel Acqusition Rate
	T_BRDCHANDEF_ACQUSITION_RATE GetAcquisitionRate(void) const {
		return (m_AcquisitionRate);
	}
	/// Process the First Reading Available
	void ProcessFirstReading(const USHORT readingTick);
	/// Process Additional Readings 
	void ProcessAdditionalReadings(const USHORT numOfAdditionalReadings);
	/// Set the Pre Process Queue Handler for adding readings to the Pre Process Queue
	void SetPPQHandler(const USHORT hPPQ) {
		m_hPPQ = hPPQ;
	}
private:
	// --- Private Member Variables --- //
	USHORT m_ChannelNumber; ///< Channel Number
	USHORT m_slotNo;								///< Slot Number
	USHORT m_boardChanNo;							///< The board channel number
	T_BRDCHANDEF_ACQUSITION_RATE m_AcquisitionRate; ///< Channel Acquisition Rate
	USHORT m_hPPQ; ///< Pre Process Queue Handler
	T_APDEMOCHAN_CHANNEL_STATUS m_ChannelStatus;  ///< Status of the Channel
	CDemoWave m_DemoWave;  ///< Demo Wave Class for simulating various input waves
};
// End of Class Declaration
#endif // _ANALOGUEPULSEDEMOCHANNEL_H

/// @file
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  IO Simulator 
/// @n Filename:  AnaloguePulseDemoBoard.h
/// @n Description: Class Declaration for Analogue Pulse Demo Board
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  3 Stability Project 1.0.1.1 7/2/2011 4:55:24 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  2 Stability Project 1.0.1.0 7/1/2011 4:27:30 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  1 V6 Firmware 1.0 5/27/2005 9:59:22 PM  Alistair Brugsch 
// $
//
// **************************************************************************
#ifndef _ANALOGUEPULSEDEMOBOARD_H
#define _ANALOGUEPULSEDEMOBOARD_H
#include "AnaloguePulseDemoChannel.h"
#include "BoardChannelCommonDefines.h"
#include "PPQCommon.h"
const USHORT APDEMOBRD_ZERO = 0; ///< Represents the Value of Zero
const USHORT APDEMOBRD_NO_READINGS = 0; ///< Value which represents No Readings 
const USHORT APDEMOBRD_ONE_READING = 1; ///< Value which Represents One Reading
/// Enumeration for Member function Return Values to indicate success and failure condition
typedef enum _eAnaloguePulseDemoBoardReturnValue {
	APDEMOBRD_OK, APDEMOBRD_INVALID_CHANNEL_TYPE, APDEMOBRD_SETUP_CHANNEL_FAILED
} T_APDEMOBRD_RETURN_VALUE;
/// Enumeration to represent whether a Channel is Enabled or Disabled
typedef enum {
	APDEMOBRD_CHANNEL_ENABLED, APDEMOBRD_CHANNEL_DISABLED
} T_APDEMOBRD_CHANNEL_STATUS;
//**Class*********************************************************************
///
/// @brief Simulates an Analogue Pulse Board
/// 
/// This class provides the functionality to simulate an Analogue/Pulse Board 
/// for the V6 Recorder.  
///
//****************************************************************************
class CAnaloguePulseDemoBoard {
public:
	/// Constructor
	CAnaloguePulseDemoBoard(void);
	/// Destructor
	virtual ~CAnaloguePulseDemoBoard(void);
	/// Initialise the Demo Board for First Time Use
	T_APDEMOBRD_RETURN_VALUE Initialise(const USHORT m_SlotNumber, const USHORT m_FirstChannelNumber);
	/// Setup the Board for Operation
	T_APDEMOBRD_RETURN_VALUE SetupBoard(const LONGLONG systemTick,
			const T_BRDCHANDEF_ANALOGUEPULSE_BOARD_TYPE boardType,
			const T_BRDCHANDEF_INPUT_CARD_TICK_RATE boardBaseTickInHZ);
	/// Reset the Board to Default Values
	T_APDEMOBRD_RETURN_VALUE ResetBoard(void);
	/// Process Channel Data
	T_APDEMOBRD_RETURN_VALUE ProcessBoardData(const LONGLONG systemTick);
private:
	// --- Private Member Functions --- //
	/// Setup the Board Channel For Operation
	T_APDEMOBRD_RETURN_VALUE SetupBoardChannel(const LONGLONG systemTick, const USHORT channelNumber,
			const UINT channelAcqRate, const FLOAT zero, const FLOAT span);
	/// Get the Analogue/Pulse Input Source Tick Rate for the Demo Input 
	INT GetAISourceTickRate(const USHORT acquisitionRate) const;
	/// Calculate the Tick Difference between the Board Tick and Board Tick to Process up until
	SHORT CalculateTickDifference(const USHORT channelTick);
	/// Calculate the Number of Readings to be added to the Pre Process Queues
	USHORT CalculateNumOfReadings(const USHORT channelNumber);
	/// Convert Actual Card Acquisition Rate to Demo Board Acquisition Rate
	T_BRDCHANDEF_ACQUSITION_RATE CardAcqRateToDemoBoardAcqRate(const USHORT acqusitionRage) const;
	// --- Private Member Variables --- //
	USHORT m_SlotNumber;  ///< Slot Number of the Board
	USHORT m_FirstChannelNumber;  ///< First Channel Number 
	USHORT m_BoardTick; ///< Board Tick 
	T_BRDCHANDEF_ANALOGUEPULSE_BOARD_TYPE m_BoardType; ///< Type of Board( ANALOGUE, HIPULSE, LOPULSE )
	T_BRDCHANDEF_INPUT_CARD_TICK_RATE m_BoardBaseTickInHZ; ///< Board Base Tick Rate ( 400HZ, 80HZ, 50HZ )
	/// An Array of Channels the Board can use
	CAnaloguePulseDemoChannel m_AnaloguePulseChannel[BRDCHANDEF_CHANNELS_PER_AP_BOARD];
	/// Current Tick for a Given Channel to be Processed 
	USHORT m_ChannelCurrentTick[BRDCHANDEF_CHANNELS_PER_AP_BOARD];
};
// End of Class Declaration
#endif // _ANALOGUEPULSEDEMOBOARD_H

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  IO Simulator
/// @n Filename:  IOSimulator.cpp
/// @n Description: Implementation File for the IO Simulator 
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  15  Stability Project 1.10.1.3 7/2/2011 4:58:02 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  14  Stability Project 1.10.1.2 7/1/2011 4:38:22 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  13  Stability Project 1.10.1.1 3/17/2011 3:20:26 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  12  Stability Project 1.10.1.0 2/15/2011 3:03:12 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// **************************************************************************
#include "IOSimulator.h"
#include "V6globals.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//****************************************************************************
/// Constructor
///
/// @param[in] 	  moduleId - Module Identification Number
///
//****************************************************************************
CIOSimulator::CIOSimulator(const T_MODULE_ID moduleId) : CV6ActiveModule(moduleId) {
	// Initialise Member Variables
	m_IOSimulatorSystemTick = IOSIM_ZERO;
	SetOperationalState(IOSIM_OPMODE_IDLE);
} // End of Constructor
//****************************************************************************
/// Destructor
///
//****************************************************************************
CIOSimulator::~CIOSimulator(void) {
	// Delete the Dynamic Memory Allocated within the Class
	delete[] m_pAnaloguePulseDemoBoard;
	m_pAnaloguePulseDemoBoard = NULL;
	delete (m_pAnaloguePulseBoardEnabled);
	m_pAnaloguePulseBoardEnabled = NULL;
} // End of Destructor
//****************************************************************************
/// Check the Device Capabilities to determine whether Physical Cards exist, 
/// in Slot A and/or Slot B. If Physical Cards do not exist within Slot A 
/// and/or Slot B then Demo Boards will be created within these Slots. In order
/// to do this the Device Capabilities needs to be updated, this member function
/// is responsible for updating the Device Capabilites for Demo Boards to be
/// enabled.  
///
/// @param[in] - NONE
///
/// @return IOSIM_OK - Initialisation of Device Capabilities Successful
/// 
//****************************************************************************
T_IOSIM_RETURN_VALUE CIOSimulator::InitialiseDemoBoardDevCaps(void) {
	T_IOSIM_RETURN_VALUE retValue = IOSIM_OK; // Member Function Return Value
	// Check whether Slot A and Slot B contains Physical Boards, if they do not
	// then set the device capabilities to construct two Demo Boards on these
	// slots. Note: On the PC there can not be any physical boards, and thus
	// two demo boards will be created everytime.  
	T_PGENNONVOL ptGenNonVol = pSYSTEM_INFO->GetFactoryConfig();
	for (USHORT usCount = 0; usCount < BRDCHANDEF_MULTIPLUS_MAX_AI_CARDS; usCount++) {
		if ( BOARD_NOT_FITTED == GlbDevCaps.GetSlotType(usCount)) {
			if (ptGenNonVol->IsDemoBoard[usCount] == 1) {
				if ((pGlbDal->IsRecorderEzTrend() == TRUE) && (usCount == 0)) {
					// First AI card eZ only has 6 maximum.
					GlbDevCaps.SetSlotInfo(usCount, BOARD_EZ_AI, 6);
				} else {
					// Mini/Multi can always have 8 channels.
					GlbDevCaps.SetSlotInfo(usCount, BOARD_AI, 8);
				}
				// Set the Channel Capabilities for the Required Channels
				GlbDevCaps.SetChannelCaps(usCount, BRDCHANDEF_CHANNEL_0, CHANNEL_CAP_AI);
				GlbDevCaps.SetChannelCaps(usCount, BRDCHANDEF_CHANNEL_1, CHANNEL_CAP_AI);
				GlbDevCaps.SetChannelCaps(usCount, BRDCHANDEF_CHANNEL_2, CHANNEL_CAP_AI);
				GlbDevCaps.SetChannelCaps(usCount, BRDCHANDEF_CHANNEL_3, CHANNEL_CAP_AI);
				GlbDevCaps.SetChannelCaps(usCount, BRDCHANDEF_CHANNEL_4, CHANNEL_CAP_AI);
				GlbDevCaps.SetChannelCaps(usCount, BRDCHANDEF_CHANNEL_5, CHANNEL_CAP_AI);
				if ((pGlbDal->IsRecorderEzTrend() != TRUE) || (usCount != 0)) {
					// Mini/Multi can always have 8 channels, but first card eZ only has 6 maximum.
					// 2nd card for eZ can always have upto 8 channels - even if not avaiable on selection guide
					GlbDevCaps.SetChannelCaps(usCount, BRDCHANDEF_CHANNEL_6, CHANNEL_CAP_AI);
					GlbDevCaps.SetChannelCaps(usCount, BRDCHANDEF_CHANNEL_7, CHANNEL_CAP_AI);
				}
				// Enable the Demo Board 
				GlbDevCaps.SetDemoBoard(usCount, TRUE);
			}
		}
	}
	return (retValue);
} // End of Member Function
//****************************************************************************
/// Initialise the IO Simulator depending on the Device Type. The Initialisation
/// will construct the correct number of Analogue / Pulse and Digital Demo Boards,
/// that a device can have, whether they are to be used or not. This allows the
/// configuration of Demo Boards to be changed on the fly, without the need to 
/// create additional classes. Demo Boards will be setup independantly after
/// initialisation has been undertaken.  
///
/// @param[in] 	  deviceType - Type of Recorder to Simulatr
///
/// @return IOSIM_INITIALISATION_FAILED - IO Simulator Initialisation Failed
/// IOSIM_OK  - IO Simulator Initialisation Successful
/// 
/// @todo JU: Initialise Digital Boards
///
//****************************************************************************
T_IOSIM_RETURN_VALUE CIOSimulator::Initialise(const USHORT deviceType) {
	T_IOSIM_RETURN_VALUE retValue = IOSIM_INITIALISATION_FAILED; // Member Function Return Value
	switch (deviceType) {
	case DEV_TEST:
	case DEV_PC_MINI:
	case DEV_ARISTOS_MINITREND:
	case DEV_PC_EZTREND:
	case DEV_ARISTOS_EZTREND: //ARISTOS QXe Device Type updates
	case DEV_SCR_MINITREND:
		m_NumOfAnaloguePulseBoards = BRDCHANDEF_MINITREND_MAX_AI_CARDS;
		m_NumOfDigitalBoards = BRDCHANDEF_MINITREND_MAX_DI_CARDS;
		break;
	case DEV_ARISTOS_MULTIPLUS:
	case DEV_PC_MULTI:
		m_NumOfAnaloguePulseBoards = BRDCHANDEF_MULTIPLUS_MAX_AI_CARDS;
		m_NumOfDigitalBoards = BRDCHANDEF_MULTIPLUS_MAX_DI_CARDS;
		break;
	default: /* Error */
		break;
	} // End of SWITCH 
	// Create an array of Analogue/Pulse Boards depending on Device Type
	m_pAnaloguePulseDemoBoard = new CAnaloguePulseDemoBoard[m_NumOfAnaloguePulseBoards];
	if (NULL != m_pAnaloguePulseDemoBoard) {
		InitialiseAnaloguePulseBoards();
		retValue = IOSIM_OK;
	} // End of IF  
	return (retValue);
} // End of Member Function
//****************************************************************************
/// Initialise each board for the number of slots required determined by 
/// Device Type. 
///
/// @param[in] - NONE
///
/// @return IOSIM_INITIALISATION_FAILED - Analogue / Pulse Board Initialisation Failed
/// IOSIM_OK  - Analogue / Pulse Board Initialisation Successful
///
//****************************************************************************
T_IOSIM_RETURN_VALUE CIOSimulator::InitialiseAnaloguePulseBoards(void) {
	T_IOSIM_RETURN_VALUE retValue = IOSIM_INITIALISATION_FAILED; // Member Function Return Value
	USHORT firstChannelNumber = IOSIM_INVALID_CHANNEL_NUMBER; // First Channel Number for Board
	/// Create an Array for Analogue/Pulse Boards enabled status
	m_pAnaloguePulseBoardEnabled = new T_IOSIM_BOARD_ENABLED_STATUS[m_NumOfAnaloguePulseBoards];
	if (NULL != m_pAnaloguePulseBoardEnabled) {
		// Initialise Each Board for the required number of Slots
		for (USHORT slotNumber = IOSIM_ZERO; slotNumber < m_NumOfAnaloguePulseBoards; ++slotNumber) {
			firstChannelNumber = GetFirstSystemChannelNumber(slotNumber);
			m_pAnaloguePulseDemoBoard[slotNumber].Initialise(slotNumber, firstChannelNumber);
		} // End of FOR
		retValue = IOSIM_OK;
	} // End of IF
	return (retValue);
} // End of Member Function
//****************************************************************************
/// Setup the Analogue / Pulse and Digtial Demo Boards. Each board works from
/// the same system time to ensure the Demo Boards do not impact the processing
/// of Physical Boards.
///
/// @param[in] - NONE
///
/// @return IOSIM_OK - Setup Boards Successfully
/// 
/// @todo 1) Setup Digital Boards 
///  2) Investigate whether this could have an impact
///  on Physical Card Min coverage. Min Coverage might be available but
///  Demo Boards min coverage is greater. 
///
//****************************************************************************
T_IOSIM_RETURN_VALUE CIOSimulator::SetupBoards(void) {
	T_IOSIM_RETURN_VALUE retValue = IOSIM_OK; // Member Function Return Value
	// Obtain the Current System Time, this value shall be used to sync both the
	// Analogue/Pulse and Digital Boards. On setup the MinCoverage of the PPQs
	// shall equal this value. 
	m_IOSimulatorSystemTick = pGlbSysTimer->GetCurrentSystemTimeTick100();
	// Setup Analogue Pulse Boards for Operation
	SetupAnaloguePulseBoards();
	// Setup Digital Boards for Operation
	return (retValue);
} // End of Member Function
//****************************************************************************
/// Obtain the First System Channel Number based on Slot Number. The System
/// Channel Number is One based, whether as internally the channel number is
/// zero based. 
///
/// @param[in] slotNumber - Slot Number
///
/// @return  0xFFFF  - Invalid Slot Number
///  otherwise - First System Channel Number for the given Slot
///
//****************************************************************************
USHORT CIOSimulator::GetFirstSystemChannelNumber(const USHORT slotNumber) {
	USHORT firstChannelNumber = IOSIM_INVALID_CHANNEL_NUMBER;
	switch (slotNumber) {
	case BRDCHANDEF_SLOT_A:
		firstChannelNumber = BRDCHANDEF_SLOT_A_SYS_FIRST_CHANNEL_NUMBER;
		break;
	case BRDCHANDEF_SLOT_B:
		firstChannelNumber = BRDCHANDEF_SLOT_B_SYS_FIRST_CHANNEL_NUMBER;
		break;
	case BRDCHANDEF_SLOT_C:
		firstChannelNumber = BRDCHANDEF_SLOT_C_SYS_FIRST_CHANNEL_NUMBER;
		break;
	case BRDCHANDEF_SLOT_D:
		firstChannelNumber = BRDCHANDEF_SLOT_D_SYS_FIRST_CHANNEL_NUMBER;
		break;
	case BRDCHANDEF_SLOT_E:
		firstChannelNumber = BRDCHANDEF_SLOT_E_SYS_FIRST_CHANNEL_NUMBER;
		break;
	case BRDCHANDEF_SLOT_F:
		firstChannelNumber = BRDCHANDEF_SLOT_F_SYS_FIRST_CHANNEL_NUMBER;
		break;
	case BRDCHANDEF_SLOT_G:
		firstChannelNumber = BRDCHANDEF_SLOT_G_SYS_FIRST_CHANNEL_NUMBER;
		break;
	case BRDCHANDEF_SLOT_H:
		firstChannelNumber = BRDCHANDEF_SLOT_H_SYS_FIRST_CHANNEL_NUMBER;
		break;
	case BRDCHANDEF_SLOT_I:
		firstChannelNumber = BRDCHANDEF_SLOT_I_SYS_FIRST_CHANNEL_NUMBER;
		break;
	default:
		firstChannelNumber = IOSIM_INVALID_CHANNEL_NUMBER;
		break;
	} // End of SWITCH
	return (firstChannelNumber);
} // End of Member Function
//****************************************************************************
/// Read the Device Capabilites and Setup Demo Boards for slots are that been
/// enabled for Demo purposes. The type of board is used to determine the 
/// Base Clock Tick Rate of the Board.  
///
/// @param[in] - NONE
///
/// @return IOSIM_AP_SETUP_FAILED  - Analogue / Pulse Board Setup Failed
/// IOSIM_OK  - Analogue / Pulse Boards are Setup Correctly
/// 
//****************************************************************************
T_IOSIM_RETURN_VALUE CIOSimulator::SetupAnaloguePulseBoards(void) {
	T_IOSIM_RETURN_VALUE retValue = IOSIM_OK;  // Member Function Return Value
	T_BRDCHANDEF_ANALOGUEPULSE_BOARD_TYPE boardType = BRDCHANDEF_ANALOGUE; // Type of Board
	// Analyse each slot, and detemine whether we require a demo board on that slot. 
	for (USHORT slotNumber = 0; slotNumber < m_NumOfAnaloguePulseBoards; ++slotNumber) {
		// Only Setup Demo Board for slot that have been setup for demo purposes.
		if ( TRUE == GlbDevCaps.IsDemoBoard(slotNumber)) {
			T_BRDCHANDEF_INPUT_CARD_TICK_RATE inputCardTickRate = BRDCHANDEF_INPUT_CARD_TICK_RATE_400HZ;
			// Indicate that the Board is enables
			m_pAnaloguePulseBoardEnabled[slotNumber] = IOSIM_BOARD_ENABLED;
			// indexOf out the Base Clock Tick Rate for the Demo Board
			switch (GlbDevCaps.GetSlotType(slotNumber)) {
			case BOARD_AI:
			case BOARD_EZ_AI:
				inputCardTickRate = BRDCHANDEF_INPUT_CARD_TICK_RATE_400HZ;
				boardType = BRDCHANDEF_ANALOGUE;
				break;
			case BOARD_PI:
				inputCardTickRate = BRDCHANDEF_INPUT_CARD_TICK_RATE_80HZ;
				boardType = BRDCHANDEF_HIPULSE;
				break;
			default:
				retValue = IOSIM_AP_SETUP_FAILED;
				break;
			} // End of SWITCH
			// Set-up the Board for Operation
			m_pAnaloguePulseDemoBoard[slotNumber].SetupBoard(m_IOSimulatorSystemTick, boardType, inputCardTickRate);
		} // End of IF
	} // End of FOR
	return (retValue);
} // End of Member Function
//****************************************************************************
/// This Member Function is called periodically to Update the Board and Channel
/// data, simulating that data is available for give boards. On each update 
/// all boards are serviced, ensuring that the Demo Boards are ahead of the 
/// Physical Boards to ensure Demo Boards do not impact the processing of 
/// real data. All boards work from the same System Tick acquired at the 
/// start of the Update.
///
/// @param[in] - NONE
///
/// @return IOSIM_OK - IO Simulator Updated Successfully.
/// 
/// @todo JU: Plug in Digital Board Updates
///
//****************************************************************************
T_IOSIM_RETURN_VALUE CIOSimulator::UpdateIOSimulator(void) {
	T_IOSIM_RETURN_VALUE retValue = IOSIM_OK; // Member Function Return Value  
	// Take a snapshot of the Current System Time to be used for all board updates,
	// this ensures the same system time is used throughtout the update process. 
	LONGLONG currentSystemTimeTick100 = pGlbSysTimer->GetCurrentSystemTimeTick100();
	LONGLONG systemTicksToProcess = currentSystemTimeTick100 - m_IOSimulatorSystemTick;
	// Process Data on Top Slot Boards - Analogue / Pulse
	for (USHORT topSlotNumber = IOSIM_ZERO; topSlotNumber < m_NumOfAnaloguePulseBoards; ++topSlotNumber) {
		if (IOSIM_BOARD_ENABLED == m_pAnaloguePulseBoardEnabled[topSlotNumber]) {
			m_pAnaloguePulseDemoBoard[topSlotNumber].ProcessBoardData(systemTicksToProcess);
		} // End of IF
	} // End of FOR
	// Process Data on Bottom Slot Boards - Digital / Lo-Pulse
	//for( USHORT bottomSlotNumber = IOSIM_ZERO; bottomSlotNumber < m_NumOfDigitalBoards; ++bottomSlotNumber )
	//{  
	//  if( IOSIM_BOARD_ENABLED == m_pAnaloguePulseBoardEnabled[bottomSlotNumber] )
	//  {
	//[bottomSlotNumber].ProcessBoardData( systemTicksToProcess );
	//  } // End of IF
	//} // End of FOR
	// Store the Current System Time used for the Current Board Update, to be used
	// on the next update to calculate the number of ticks to process. 
	m_IOSimulatorSystemTick = currentSystemTimeTick100;
	return (retValue);
} // End of Member Function
T_IOSIM_RETURN_VALUE CIOSimulator::ResetBoards(void) {
	T_IOSIM_RETURN_VALUE retValue = IOSIM_OK; // Member Function Return Value  
	// Process Data on Top Slot Boards - Analogue / Pulse
	for (USHORT topSlotNumber = IOSIM_ZERO; topSlotNumber < m_NumOfAnaloguePulseBoards; ++topSlotNumber) {
		m_pAnaloguePulseDemoBoard[topSlotNumber].ResetBoard();
		m_pAnaloguePulseBoardEnabled[topSlotNumber] = IOSIM_BOARD_DISABLED;
	} // End of FOR
	// Process Data on Bottom Slot Boards - Digital / Lo-Pulse
	//for( USHORT bottomSlotNumber = IOSIM_ZERO; bottomSlotNumber < m_NumOfDigitalBoards; ++bottomSlotNumber )
	//{  
	//  if( IOSIM_BOARD_ENABLED == m_pAnaloguePulseBoardEnabled[bottomSlotNumber] )
	//  {
	//[bottomSlotNumber].ProcessBoardData( systemTicksToProcess );
	//  } // End of IF
	//} // End of FOR
	return (retValue);
} // End of Member Function
/// Primary Initialisation of the Module
T_V6ACTMOD_RETURN_VALUE CIOSimulator::PerformPrimaryInitialisation(void) {
	// Initialise the IO Simulator for Operation
	Initialise(GlbDevCaps.GetDeviceType());
	return (T_V6ACTMOD_RETURN_VALUE());
} // End of Member Function
/// Secondary Initialisation of the Module
T_V6ACTMOD_RETURN_VALUE CIOSimulator::PerformSecondaryInitialisation(void) {
	// --- Do Nothing --- //
	return (V6ACTMOD_OK);
} // End of Member Function
/// Method called when Module goes into Normal Operation
T_V6ACTMOD_RETURN_VALUE CIOSimulator::NormalOperation(void) {
	SetOperationalState(IOSIM_OPMODE_NORMAL_OPERATION);
	return (V6ACTMOD_OK);
} // End of Member Function
/// Method called when Module is to prepare for Setup Config Change 
T_V6ACTMOD_RETURN_VALUE CIOSimulator::SetupConfigChangePreparation(void) {
	// Force an IO Simulator Update, to ensure that the Demo Boards do 
	// not stop coverage not being available for Physical Boards within
	// the V6 System. Demo Boards shall always be ahead of Physical Boards. 
	UpdateIOSimulator();
	SetOperationalState(IOSIM_OPMODE_IDLE);
	return (V6ACTMOD_OK);
} // End of Member Function
  /// Method called when Module is to carry out Setup Change Completion
T_V6ACTMOD_RETURN_VALUE CIOSimulator::SetupConfigChangeComplete(void) {
	ResetBoards();
	// Setup the IO Simulator Boards
	SetupBoards();
	return (V6ACTMOD_OK);
} // End of Member Function
/// Method called when a Module is to prepare for Shutdown
T_V6ACTMOD_RETURN_VALUE CIOSimulator::ShutdownPreparation(void) {
	// Force an IO Simulator Update, to ensure that the Demo Boards do 
	// not stop coverage not being available for Physical Boards within
	// the V6 System. Demo Boards shall always be ahead of Physical Boards. 
	UpdateIOSimulator();
	SetOperationalState(IOSIM_OPMODE_IDLE);
	return (V6ACTMOD_OK);
} // End of Member Function
/// Method called when a Module is to Shutdown
T_V6ACTMOD_RETURN_VALUE CIOSimulator::Shutdown(void) {
	SetOperationalState(IOSIM_OPMODE_EXIT);
	return (V6ACTMOD_OK);
} // End of Member Function

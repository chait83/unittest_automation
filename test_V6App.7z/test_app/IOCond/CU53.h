/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	I/O Scheduler
/// @n Filename: CU53.h
/// @n Desc:	Constant data for the CU53 RT
///
// 
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 4	Stability Project 1.1.1.1	7/2/2011 4:56:26 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 3	Stability Project 1.1.1.0	7/1/2011 4:27:22 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 2	V6 Firmware 1.1		8/18/2005 3:25:10 PM	Graham Waterfield
//		Fix incorrect points in table
// 1	V6 Firmware 1.0		3/8/2005 9:44:52 PM	Graham Waterfield 
// $
//
//////////////////////////////////////////////////////////////////////
#ifndef _CU53_H
#define _CU53_H
#if !defined(AFX_CU53_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_)
#define AFX_CU53_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "LinearTable.h"
const T_IP_TABLE_ELEMENT CU53Measurement[] = {
		// resistance,	TempC
		53, 0, 53.904F, 4, 54.808F, 8, 55.26F, 10, 56.164F, 14, 57.068F, 18, 57.52F, 20, 58.424F, 24, 59.328F, 28,
		59.78F, 30, 60.684F, 34, 61.588F, 38, 62.03F, 40, 62.934F, 44, 63.838F, 48, 64.29F, 50, 65.194F, 54, 66.098F,
		58, 66.55F, 60, 67.454F, 64, 68.358F, 68, 68.81F, 70, 69.714F, 74, 70.618F, 78, 71.06F, 80, 71.964F, 84,
		72.868F, 88, 73.32F, 90, 74.224F, 94, 75.128F, 98, 75.58F, 100, 76.484F, 104, 77.388F, 108, 77.84F, 110,
		78.744F, 114, 79.648F, 118, 80.1F, 120, 80.936F, 124, 81.772F, 128, 82.19F, 130, 83.026F, 134, 83.862F, 138,
		84.28F, 140, 85.116F, 144, 85.952F, 148, 86.37F, 150 };
#endif // !defined(AFX_CU53_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_)
#endif		// _CU53_H

/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Events
/// @n Filename: EventControl.h
/// @n Desc:	 Time based event triggers
///				 
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  7 Stability Project 1.4.1.1 7/2/2011 4:57:09 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  6 Stability Project 1.4.1.0 7/1/2011 4:27:47 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  5 V6 Firmware 1.4 1/10/2007 2:18:57 PM  Andy Kassell  Add
//  delayed event class
//  4 V6 Firmware 1.3 11/9/2006 9:47:57 PM  Andy Kassell  Add
//  User counter level trigger cause
//  Add accessor for next scheduled time
// $
//
// ****************************************************************
#ifndef __EVENTSCHEDULE_H__
#define __EVENTSCHEDULE_H__
#include "TV6Timer.h"
#include "TVtime.h"
#include "V6types.h"
#include "V6Config.h"
typedef enum {
	EVENT_ALIGN_TO_NONE = 0,		///< No Alignment
	EVENT_ALIGN_TO_MIN,			///< Align to nearest minute
	EVENT_ALIGN_TO_HOUR,		///< Align to nearest hour
	EVENT_ALIGN_TO_DAY,			///< Align to nearest day
} T_EVENT_ALIGNMENT;
typedef enum {
	SCHED_STATUS_NOACTION = 0,	///< Schedule running, no action taken.
	SCHED_STATUS_RELOADED,		///< Schedule reloaded.
	SCHED_STATUS_TRIGGERED		///< Schedule triggered.
} T_EVENT_SCHEDULE_STATUS;
//**Class*********************************************************************
///
/// @brief Schedule for event cause
/// 
/// Provide support for an individual schedule as an event cause.
///
///
//****************************************************************************
class CEventSchedule {
public:		// API methods
	CEventSchedule();
	void DisableSchedule();
	void SetupScheduleFromConfig(T_SCHED_EVENT_SUBTYPE m_type, T_PSCHEDEVENTDATA pConfig, int eventIndex,
			int causeIndex, BOOL configChanged);
	BOOL IsEnabled() {
		return m_Enabled;
	}
	;
	int GetEventIndex() {
		return m_eventIndex;
	}
	;
	int GetCauseIndex() {
		return m_causeIndex;
	}
	;
	USHORT GetCountDown() {
		return m_currentCounter;
	}
	;
	void SetCountDown(USHORT count) {
		m_currentCounter = count;
	}
	;
	T_EVENT_SCHEDULE_STATUS IsTriggered();
	void RegisterTimeChange();
	CTVtime GetNextScheduleTime() {
		return m_nextSchedTime;
	}
	;
private:	// Methods
	void ReloadSchedule();
	void ReloadScheduleInterval(CTVtime &nextSchedule);
	void ReloadScheduleOnce(CTVtime &nextSchedule);
	void ReloadScheduleMonthEnd(CTVtime &nextSchedule);
	void ReloadScheduleSpecificDays(CTVtime &nextSchedule);
	void CreateTVTimeForNextSpecificDay(CTVtime &theTimeDate);
	BOOL IsDayScheduled(int DayNumber);
private:	// Member variables
	BOOL m_Enabled;											///< Is schedule Enabled
	BOOL m_reloadRequired;									///< Do we need to rebuild the countdown
	BOOL m_alignRequired;									///< Do we need to align the counter on this pass
	BOOL m_ResetCountRequired;								///< Reset the NV trigger count
	BOOL m_FirstRun;									///< First Time the schedule has been initialised since power on
	BOOL m_CountdownRequired;								///< True if countdown required, otherwise FALSE
	BOOL m_resetCounter;									///< Reset the countdown on next pass
	BOOL m_IsRunning;										///< Determine of the schedule is running
	int m_eventIndex;										///< Index of the event this belongs too.
	int m_causeIndex;										///< Cause index of scheduled event
	T_PSCHEDEVENTDATA m_pConfig;							///< Pointer to schedule configuration in CMM
	T_SCHED_EVENT_SUBTYPE m_type;							///< Type of event
	LONGLONG m_eventExpiryTick;								///< Tick time when the scheduled event will expire
	USHORT m_currentCounter;								///< Current number of schedule triggers left 
	QString m_strScheduleType;								///< Schedule name
	CTVtime m_nextSchedTime;								///< STore for next scheduled time
};
//**Class*********************************************************************
///
/// @brief Link Event Class
/// 
/// Control an individual link event trigger
///
//****************************************************************************
class CLinkEventTimer {
public:
	CLinkEventTimer();
public:		// API methods
	void ResetLinkEvent();
	void TriggerEvent(int SecondsToTrigger);
	BOOL IsScheduleComplete();
	BOOL IsRunning() {
		return m_TimerRunning;
	}
	;
	int Secondsleft() {
		return m_SecondsToTrigger;
	}
	;
private:	// Member variables
	BOOL m_TimerRunning;			///< Timer running
	CTV6Timer m_Timer;				///< Timer for link event 
	int m_SecondsToTrigger;			///< Number of seconds till the link event is triggered
};
#endif //__EVENTSCHEDULE_H__

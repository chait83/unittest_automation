/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  Secure Comm
/// @n Filename:  V7TlsCertificate.h
/// @n Description: TLS Certificate
///
// **************************************************************************
// Revision History
// **************************************************************************
// Project		Date			Team/Person			Comments
//	TVR211		08-Aug-2019		TechM				Initial Draft
//
// **************************************************************************
#ifndef _V7_TLS_CERTIFICATE_H
#define _V7_TLS_CERTIFICATE_H
#pragma once
#include <schannel.h>
#include "V7tstring.h"
//
#pragma comment(lib, "secur32.lib")
#include <sspi.h>
#ifdef _WIN32_WCE
	#define _WCE_SECTION
		
	#ifdef REMOTE_DISPLAY_SERVER
		#include "..\..\V6App\V6App_i.h"
		extern IV6AppInterface* pV6AppInterface;
	#endif
#endif
#include "V7DbgLogDefines.h"
#ifdef DBG_FILE_LOG_TLS_CERT_ENABLE
#include "CStorage.h"
#endif
// Define
//#define  MY_SEERVER_NAME_STRING  QString   ("XS-900595") //L"XS-904154"
class CV7TLSCertificate;
// Function Pointer
typedef SECURITY_STATUS (*SelectServerCertFPTR)(PCCERT_CONTEXT &pCertContext, LPCTSTR pszSubjectName);
typedef bool (*ClientCertAcceptableFPTR)(PCCERT_CONTEXT pCertContext, const bool trusted);
class CV7MyMutex {
public:
	static CV7MyMutex& instance();
	virtual ~CV7MyMutex();
	bool lockMutex(void);
	bool unLockMutex(void);
private:
	CV7MyMutex();
	bool createMutex(void);
	HANDLE ghMutex;
};
class CV7TLSCertificate {
public:
	virtual ~CV7TLSCertificate();
	static CV7TLSCertificate& instance();
	SECURITY_STATUS GetCredHandleFor(std::tstring serverName, SelectServerCertFPTR SelectServerCert,
			PCredHandle phCreds);
	std::tstring GetCertName(PCCERT_CONTEXT pCertContext);
	bool MatchCertificateName(PCCERT_CONTEXT pCertContext, LPCTSTR pszRequiredName);
	HRESULT ShowCertInfo(PCCERT_CONTEXT pCertContext, std::tstring Title);
	HRESULT CertTrusted(PCCERT_CONTEXT pCertContext, const bool isClientCert);
	SECURITY_STATUS CertindexOfClientCertificate(PCCERT_CONTEXT &pCertContext, const LPCTSTR pszSubjectName = NULL,
			boolean fUserStore = true);
	SECURITY_STATUS CertindexOfFromIssuerList(PCCERT_CONTEXT &pCertContext,
			SecPkgContext_IssuerListInfoEx &IssuerListInfo);
	SECURITY_STATUS CertindexOfServerCertificateUI(PCCERT_CONTEXT &pCertContext, LPCTSTR pszSubjectName,
			boolean fUserStore = false);
	SECURITY_STATUS CertindexOfServerCertificateByName(PCCERT_CONTEXT &pCertContext, LPCTSTR pszSubjectName,
			boolean fUserStore = false);
	SECURITY_STATUS CertindexOfCertificateBySignature(PCCERT_CONTEXT &pCertContext, char const *const signature,
			boolean fUserStore = false);
	HRESULT CertindexOfByName(PCCERT_CONTEXT &pCertContext, const LPCTSTR pszSubjectName);
	// defined in source file CreateCertificate.cpp
	PCCERT_CONTEXT CreateCertificate(bool MachineCert = false, LPCTSTR Subject = NULL, LPCTSTR FriendlyName = NULL,
			LPCTSTR Description = NULL, bool forClient = false);
	static SECURITY_STATUS SelectServerCert(PCCERT_CONTEXT &pCertContext, LPCTSTR pszSubjectName);
	static bool ClientCertAcceptable(PCCERT_CONTEXT pCertContext, const bool trusted);
protected:
#ifdef DBG_FILE_LOG_TLS_CERT_ENABLE
	void LogDebugMessage(QString   strDebugMessage);
	#endif
public:
#ifdef DBG_FILE_LOG_TLS_CERT_ENABLE
	void SetDebugLogger(CDebugFileLogger* pDbgFileLogger);
	#endif	
private:
	CV7TLSCertificate();
	SECURITY_STATUS GetStore(HCERTSTORE &phStore, bool useUserStore);
	bool DnsNameMatches(std::tstring HostName, PCTSTR pRequiredName);
	SECURITY_STATUS CreateCredentialsFromCertificate(PCredHandle phCreds, PCCERT_CONTEXT pCertContext);
	SECURITY_STATUS CertindexOfServerCertificateByNameTarget(PCCERT_CONTEXT &pCertContext, LPCTSTR pszSubjectName,
			boolean fUserStore = false);
	SECURITY_STATUS CertindexOfServerCertificateByNameHost(PCCERT_CONTEXT &pCertContext, LPCTSTR pszSubjectName,
			boolean fUserStore = false);
	HINSTANCE m_hInstCryptUIDLL; // CID 1016430: Coverity fix - H196266
private:
#ifdef DBG_FILE_LOG_TLS_CERT_ENABLE
	CDebugFileLogger* m_pDebugFileLogger;
	#endif
};
#endif // _V7_TLS_CERTIFICATE_H

//////////////////////////////////////////////////////////////////////
/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		SecureComm
/// @n Filename:  V7SecureSocket.cpp
/// @n Description: Implementation of the CV7SecureSocket class
///
// **************************************************************************
// Revision History
// **************************************************************************
// Project		Date			Team/Person			Comments
//	TVR211		09-Aug-2019		Shankar Rao P		Initial Draft
//
// **************************************************************************
#include "V7SecureSocket.h"
#include "V7TLSClient.h"
#include "V7TLSServCleComm.h"
#include "V7TLSUtilities.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//#define TRACE_ALLOW
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CV7SecureSocket::CV7SecureSocket(ESocketTransMode eSTMode) : CCESecureSocket(eSTMode) {
	m_pTLSCli = NULL;
	m_pTLSSer = NULL;
	m_eSocketRole = SocketNone;
}
CV7SecureSocket::CV7SecureSocket(QAbstractSocket skt, ESocketRoleType role, CredHandle *hServerCreds,
		CtxtHandle *hContext) : CCESecureSocket(CCESecureSocket::ST_MODE_SECURE) {
	if (hServerCreds == NULL || hContext == NULL) {
		m_pTLSCli = NULL;
		m_pTLSSer = NULL;
		m_eSocketRole = SocketNone;
	} else {
		m_pTLSCli = NULL;
		m_pTLSSer = new CV7TLSServCleComm(skt, hServerCreds, hContext);
		m_eSocketRole = role;
	}
}
CV7SecureSocket::~CV7SecureSocket() {
	CleanUp();
}
CtxtHandle* CV7SecureSocket::getContextHandle() {
	if (m_pTLSSer != NULL) {
		return m_pTLSSer->getContextHandle();
	} else
		return NULL;
}
CredHandle* CV7SecureSocket::getCredHanle() {
	if (m_pTLSSer != NULL) {
		return m_pTLSSer->getCredHanle();
	} else
		return NULL;
}
void CV7SecureSocket::EraseTLSSerOnceAccept() {
	if (m_pTLSSer != NULL) {
		delete m_pTLSSer;
		m_pTLSSer = NULL;
	}
	if (m_pTLSCli != NULL) {
		delete m_pTLSCli;
		m_pTLSCli = NULL;
	}
}
//****************************************************************************
/// OnAccept - Override to handle accept notifications
///
/// @param[in]	serviceSocket - QAbstractSocket to attach to new class instance
///
/// @return		false if new socket not handled by handler thread
///
//**************************************************************************** 
bool CV7SecureSocket::OnAccept(QAbstractSocket serviceSocket) {
	bool bRet = true;
	if (m_pTLSSer == NULL) {
		m_pTLSSer = new CV7TLSServCleComm(serviceSocket);
#ifdef DBG_FILE_LOG_TLS_SERV_ENABLE
		m_pTLSSer->SetDebugLogger(m_pDebugFileLogger);
		#endif
	}
	if (m_pTLSSer != NULL) {
		m_pTLSSer->SetTimeoutSeconds(READ_WRITE_TIMEOUT);
	}
	/* Negotiate SSL Protocol */
	bRet = m_pTLSSer->StartHandShake();
	m_eSocketRole = SocketServer;
	if (false == bRet) {
		//clean up the TlsSer
		EraseTLSSerOnceAccept();
	}
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
	QString   strDbgMsg;
  strDbgMsg = QString::asprintf("CV7SS::OnAccept - Handshake status %d", bRet);
	LogDebugMessage(strDbgMsg);
	#endif
	return bRet;
}
bool CV7SecureSocket::OnConnect(QString &addr) {
	bool retVal = true;
	DWORD nErrCode = 0;
	std::tstring wsRemoteSeraddr = addr;
	if (m_pTLSCli == NULL) {
		m_eSocketRole = SocketClient;
		m_pTLSCli = new CV7TLSClient();
#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
		m_pTLSCli->SetDebugLogger(m_pDebugFileLogger);
		#endif
	}
	if (m_pTLSCli != NULL) {
		nErrCode = m_pTLSCli->PerformClientHandshake(s, wsRemoteSeraddr);
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
		QString   strDbgMsg;
  strDbgMsg = QString::asprintf("CV7SS::OnConnect - PerformClientHandshake status 0x%x", nErrCode);
		LogDebugMessage(strDbgMsg);
		#endif
		if (nErrCode != SEC_E_OK) {
			/* TLSI Handshe Failed , so delete TLSI Client object */
			//DebugMsg("Error %d performing handshake", nErrCode );
			delete m_pTLSCli;
			m_pTLSCli = NULL;
			//printf("Error %d performing handshake \n", nErrCode );	
			retVal = false;
		}
	} else {
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
		QString   strDbgMsg;
  strDbgMsg = QString::asprintf("CV7SS::OnConnect -Not enough storage or memory allocation failed");
		LogDebugMessage(strDbgMsg);
		#endif
		retVal = false;
	}
	return (retVal);
}
/**************************************************************************************** 
 EncryptSend : Send the encrypted data
 
 @Input :  QAbstractSocket Socket, CtxtHandle * phContext, PBYTE pbIoBuffer, SecPkgContext_StreamSizes Sizes
 
 @return : cbData on Success
 Error code on failure (QAbstractSocket_ERROR)
 
 ******************************************************************************************/
DWORD CV7SecureSocket::ClientEncryptSend(QAbstractSocket Socket, CtxtHandle *phContext, PBYTE pbIoBuffer,
		SecPkgContext_StreamSizes Sizes, int iLen) {
	SECURITY_STATUS scRet;
	SecBufferDesc Message;
	SecBuffer Buffers[4];
	DWORD cbMessage, cbData;
	PBYTE pbMessage;
	pbMessage = pbIoBuffer + Sizes.cbHeader;
	cbMessage = iLen + Sizes.cbHeader;
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
	QString   strDbgMsg;
  strDbgMsg = QString::asprintf("CV7SS::ClientEncryptSend- Sending %d bytes of plaintext: Before Encryption", cbMessage);
	LogDebugMessage(strDbgMsg);
	
	//PrintHexDump(cbMessage, pbMessage); 
	#endif
	Buffers[0].pvBuffer = pbIoBuffer;
	Buffers[0].cbBuffer = Sizes.cbHeader;
	Buffers[0].BufferType = SECBUFFER_STREAM_HEADER;
	Buffers[1].pvBuffer = pbIoBuffer + Sizes.cbHeader;
	Buffers[1].cbBuffer = iLen;
	Buffers[1].BufferType = SECBUFFER_DATA;
	Buffers[2].pvBuffer = pbIoBuffer + Sizes.cbHeader + iLen;
	Buffers[2].cbBuffer = Sizes.cbTrailer;
	Buffers[2].BufferType = SECBUFFER_STREAM_TRAILER;
	Buffers[3].pvBuffer = SECBUFFER_EMPTY;
	Buffers[3].cbBuffer = SECBUFFER_EMPTY;
	Buffers[3].BufferType = SECBUFFER_EMPTY;
	Message.ulVersion = SECBUFFER_VERSION;
	Message.cBuffers = 4;
	Message.pBuffers = Buffers;
	scRet = m_pTLSCli->SSPI()->EncryptMessage(phContext, 0, &Message, 0);
	if (FAILED(scRet)) {
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::ClientEncryptSend- **** Error 0x%x returned by EncryptMessage", scRet);
		LogDebugMessage(strDbgMsg);	
		#endif
		return scRet;
	}
	cbData = (int) (Buffers[0].cbBuffer + Buffers[1].cbBuffer + Buffers[2].cbBuffer);
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::ClientEncryptSend-Client after Enc Len:%d", cbData);
	LogDebugMessage(strDbgMsg);	
	//PrintHexDump(cbData, pbIoBuffer);
	#endif
	//sends data on a connected socket
	cbData = CCESecureSocket::Send((const char*) pbIoBuffer,
			(int) Buffers[0].cbBuffer + Buffers[1].cbBuffer + Buffers[2].cbBuffer);
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::ClientEncryptSend-%d bytes of encrypted data sent", cbData);
	LogDebugMessage(strDbgMsg);	
  //PrintHexDump(cbData, pbIoBuffer); DebugMsg("\n";
	#endif
	return cbData;
}
DWORD CV7SecureSocket::ClientTLSSend(QAbstractSocket Socket, char *pcBuf, int iLen) {
	int nErrCode = 0; //iLen;
	int nTmpLen = 0;
	int i = 0, nOffset = 0, nSent = 0;
	int nRemainLen = iLen;
	int iMaxSize = V7_TLS_MAX_RECORD_SIZE;
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
	QString   strDbgMsg;
  strDbgMsg = QString::asprintf("CV7SS::ClientTLSSend begin Length:%d", iLen);
	LogDebugMessage(strDbgMsg);
#endif
	if (iLen <= iMaxSize/*m_MaxMsgSize*/) {
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::ClientTLSSend ClientSecureSend normal case iLen %d < iMaxSize %d", iLen, iMaxSize);
	LogDebugMessage(strDbgMsg);
#endif
		nErrCode = ClientSecureSend(s, (char*) pcBuf, iLen);
	} else {
		for (i = 0; i < iLen; i += nTmpLen) {
			if (nRemainLen > iMaxSize/*m_MaxMsgSize*/) {
				// ensure send is done loop 
				nTmpLen = iMaxSize/*m_MaxMsgSize*/;
			} else {
				nTmpLen = nRemainLen;
			}
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::ClientTLSSend ClientSecureSend iteration %d nTmpLen %d", i, nTmpLen);
				LogDebugMessage(strDbgMsg);
			#endif
			if (nTmpLen > 0) {
				nErrCode = ClientSecureSend(s, (char*) pcBuf + i, nTmpLen);
			}
			sleep(50);
			if (nErrCode == QAbstractSocket_ERROR) {
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::ClientTLSSend ClientSecureSend error nTmpLen %d", nTmpLen);
				LogDebugMessage(strDbgMsg);
				#endif
				break;
			}
			nRemainLen -= nTmpLen;
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::ClientTLSSend ClientSecureSend iteration %d end TotalLen:%d nTmpLen %d nSent:%d nRemainLen:%d", i, iLen, nTmpLen, nErrCode, nRemainLen);
				LogDebugMessage(strDbgMsg);
			#endif
		}
	}
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::ClientTLSSend END Sent Bytes:%d", nErrCode);
	LogDebugMessage(strDbgMsg);
#endif
	return nErrCode;
}
/**************************************************************************************** 
 Send : Send the data to server
 
 @Input :  wstring wstrData 
 
 @return : 
 SEC_E_OK on success
 Error code on failure
 
 ******************************************************************************************/
DWORD CV7SecureSocket::ClientSecureSend(QAbstractSocket Socket, char *sBuff, int iLen) {
	SecPkgContext_StreamSizes Sizes;
	SECURITY_STATUS scRet;
	PBYTE pbIoBuffer;
	DWORD cbIoBufferLength, cbData;
	// Arbitrary but less than 16384 limit, including MaxExtraSize
	static const int cliMaxMsgSize = V7_TLS_MAX_RECORD_SIZE; //16000; 
	// Also arbitrary, current header is 5 bytes, trailer 36
	static const int cliMaxExtraSize = V7_TLS_MAX_MSG_HDR_SIZE;	//50;
	// Enough for a whole encrypted message
	static CHAR cliWriteBuffer[cliMaxMsgSize + cliMaxExtraSize];
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
	QString   strDbgMsg;
  strDbgMsg = QString::asprintf("CV7SS::ClientSecureSend Start() Length:%d", iLen);
	LogDebugMessage(strDbgMsg);
	#endif
	CtxtHandle hContext = m_pTLSCli->getContextHandle();
	scRet = m_pTLSCli->SSPI()->QueryContextAttributes(&hContext, SECPKG_ATTR_STREAM_SIZES, &Sizes);
	if (scRet != SEC_E_OK) {
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::CSS **** Error 0x%x reading SECPKG_ATTR_STREAM_SIZES", scRet);
		LogDebugMessage(strDbgMsg);
		#endif
		return QAbstractSocket_ERROR;	//scRet;
	} else {
		// Put the message in the right place in the buffer
		memcpy_s(cliWriteBuffer + Sizes.cbHeader, sizeof(cliWriteBuffer) - Sizes.cbHeader - Sizes.cbTrailer, sBuff,
				iLen);
		//Here condition is to take care of SMTP protocol sending non secure packet in secure mode before switching to secure 
		if ((m_eSocketTransMode == CCESecureSocket::ST_MODE_SECURE) && (m_eSecureConnReadyToEstd == TRUE))
			cbData = ClientEncryptSend(Socket, &hContext, (PBYTE) cliWriteBuffer, Sizes, iLen);
		else
			cbData = CCESecureSocket::Send((const char*) sBuff, (int) iLen);
		if (cbData == QAbstractSocket_ERROR || cbData == 0) {
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::CSS **** Error %d sending data to server (3)", WSAGetLastError());
			LogDebugMessage(strDbgMsg);
			#endif
			return QAbstractSocket_ERROR;	//WSAGetLastError();
		}
	}
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::ClientSecureSend end() Length:%d", iLen);
	LogDebugMessage(strDbgMsg);
	#endif
	return iLen;
}
// Send an encrypted message containing an encrypted version of 
// whatever plaintext data the caller provides
int CV7SecureSocket::ServerEncryptSend(const void *const lpBuf, const int Len) {
	// Arbitrary but less than 16384 limit, including MaxExtraSize
	static const int MaxMsgSize = V7_TLS_MAX_RECORD_SIZE;	//16000; 
	// Also arbitrary, current header is 5 bytes, trailer 36
	static const int MaxExtraSize = V7_TLS_MAX_MSG_HDR_SIZE;	//50; 
	// Enough for a whole encrypted message
	static CHAR writeBuffer[MaxMsgSize + MaxExtraSize];
	CtxtHandle *phContext = m_pTLSSer->getContextHandle();
	SecPkgContext_StreamSizes Sizes;
	INT err;
	SecBufferDesc Message;
	SecBuffer Buffers[4];
	SECURITY_STATUS scRet = m_pTLSSer->SSPI()->QueryContextAttributes(phContext, SECPKG_ATTR_STREAM_SIZES, &Sizes);
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
	QString   strDbgMsg;
  strDbgMsg = QString::asprintf("CV7SS::ServerEncryptSend Start() Length:%d", Len);
	LogDebugMessage(strDbgMsg);
	#endif
	if (scRet != SEC_E_OK) {
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::ServerEncryptSend Couldn't get Sizes:0x%x", scRet);
		LogDebugMessage(strDbgMsg);
		#endif
		return E_FAIL;
	}
	bool bEncrypting = m_pTLSSer->getEncryptStatus();
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::ServerEncryptSend bEncrypting:%d", bEncrypting);
	LogDebugMessage(strDbgMsg);
	#endif
	if (!lpBuf || Len > MaxMsgSize) {
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::ServerEncryptSend (ERROR)Len:%d,MaxMsgSize:%d", Len, MaxMsgSize);
		LogDebugMessage(strDbgMsg);
		#endif
		return QAbstractSocket_ERROR;
	}
	if (!bEncrypting) {
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::ServerEncryptSend Send can only be called when encrypting");
		LogDebugMessage(strDbgMsg);
		#endif
		return QAbstractSocket_ERROR;
	}
	// Initialize security buffer structs
	//
	Message.ulVersion = SECBUFFER_VERSION;
	Message.cBuffers = 4;
	Message.pBuffers = Buffers;
	Buffers[0].BufferType = SECBUFFER_EMPTY;
	Buffers[1].BufferType = SECBUFFER_EMPTY;
	Buffers[2].BufferType = SECBUFFER_EMPTY;
	Buffers[3].BufferType = SECBUFFER_EMPTY;
	// Put the message in the right place in the buffer
	memcpy_s(writeBuffer + Sizes.cbHeader, sizeof(writeBuffer) - Sizes.cbHeader - Sizes.cbTrailer, lpBuf, Len);
	// Line up the buffers so that the header, trailer and content will be
	// all positioned in the right place to be sent across the TCP connection as one message.	
	Buffers[0].pvBuffer = writeBuffer;
	Buffers[0].cbBuffer = Sizes.cbHeader;
	Buffers[0].BufferType = SECBUFFER_STREAM_HEADER;
	Buffers[1].pvBuffer = writeBuffer + Sizes.cbHeader;
	Buffers[1].cbBuffer = Len;
	Buffers[1].BufferType = SECBUFFER_DATA;
	Buffers[2].pvBuffer = writeBuffer + Sizes.cbHeader + Len;
	Buffers[2].cbBuffer = Sizes.cbTrailer;
	Buffers[2].BufferType = SECBUFFER_STREAM_TRAILER;
	Buffers[3].BufferType = SECBUFFER_EMPTY;
	scRet = m_pTLSSer->SSPI()->EncryptMessage(phContext, 0, &Message, 0);
	if (FAILED(scRet)) {
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::ServerEncryptSend EncryptMessage failed with ox%x", scRet);
		LogDebugMessage(strDbgMsg);
		#endif
		return QAbstractSocket_ERROR;
	}
	err = CCESecureSocket::Send(writeBuffer, Buffers[0].cbBuffer + Buffers[1].cbBuffer + Buffers[2].cbBuffer);
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::ServerEncryptSend Send %d encrypted bytes to client", Buffers[0].cbBuffer + Buffers[1].cbBuffer + Buffers[2].cbBuffer);
	LogDebugMessage(strDbgMsg);
	#endif
	if (err == QAbstractSocket_ERROR) {
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::ServerEncryptSend Send failed: %ld", GetLastError());
		LogDebugMessage(strDbgMsg);
		#endif
		return QAbstractSocket_ERROR;
	}
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::ServerEncryptSend End", Len);
	LogDebugMessage(strDbgMsg);
	#endif
	return Len;
}
DWORD CV7SecureSocket::ServerTLSSend(const char *pcBuf, int iLen) {
	int nErrCode = 0;	//iLen;
	int nTmpLen = 0;
	int i = 0, nOffset = 0, nSent = 0;
	int nRemainLen = iLen;
	int iMaxSize = V7_TLS_MAX_RECORD_SIZE;
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
	QString   strDbgMsg;
  strDbgMsg = QString::asprintf("CV7SS::ServerTLSSend begin Length:%d", iLen);
	LogDebugMessage(strDbgMsg);
#endif
	if (iLen <= iMaxSize/*m_MaxMsgSize*/) {
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::ServerTLSSend ServerSecureSend normal case iLen %d < iMaxSize %d", iLen, iMaxSize);
	LogDebugMessage(strDbgMsg);
#endif
		nErrCode = ServerSecureSend((char*) pcBuf, iLen);
	} else {
		for (i = 0; i < iLen; i += nTmpLen) {
			if (nRemainLen > iMaxSize/*m_MaxMsgSize*/) {
				// ensure send is done loop 
				nTmpLen = iMaxSize/*m_MaxMsgSize*/;
			} else {
				nTmpLen = nRemainLen;
			}
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::ServerTLSSend ServerSecureSend iteration %d nTmpLen %d", i, nTmpLen);
				LogDebugMessage(strDbgMsg);
			#endif
			if (nTmpLen > 0) {
				nErrCode = ServerSecureSend((char*) pcBuf + i, nTmpLen);
			}
			sleep(50);
			if (nErrCode == QAbstractSocket_ERROR) {
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::ServerTLSSend ServerSecureSend error nTmpLen %d", nTmpLen);
				LogDebugMessage(strDbgMsg);
				#endif
				break;
			}
			nRemainLen -= nTmpLen;
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::ServerTLSSend ServerSecureSend iteration %d end TotalLen:%d nTmpLen %d nSent:%d nRemainLen:%d", i, iLen, nTmpLen, nErrCode, nRemainLen);
				LogDebugMessage(strDbgMsg);
			#endif
		}
	}
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::ServerTLSSend END Sent Bytes:%d", nErrCode);
	LogDebugMessage(strDbgMsg);
#endif
	return nErrCode;
}
int CV7SecureSocket::ServerSecureSend(const void *const lpBuf, const int Len) {
	INT err = QAbstractSocket_ERROR;
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
	QString   strDbgMsg;
  strDbgMsg = QString::asprintf("CV7SS::ServerSecureSend Start() Length:%d bEncrypting:%d", Len, m_pTLSSer->getEncryptStatus());
	LogDebugMessage(strDbgMsg);
	#endif
	if (m_pTLSSer->getEncryptStatus()) {
		err = ServerEncryptSend(lpBuf, Len);
	} else {
		err = CCESecureSocket::Send((const char*) lpBuf, Len);
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::ServerSecureSend Send %d Plain bytes to client ret %d", Len, err);
		LogDebugMessage(strDbgMsg);
		#endif
		if (err == QAbstractSocket_ERROR) {
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::ServerSecureSend Send failed: %ld", GetLastError());
			LogDebugMessage(strDbgMsg);
			#endif
		}
	}
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::ServerEncryptSend End", err);
	LogDebugMessage(strDbgMsg);
	#endif
	return err;
}
//****************************************************************************
// int Send( const char* pcBuf, int iLen ) 
///
/// Send method that encrypt the data prior to sending
///
/// @param[in]		const char* pcBuf - The buffer containing all the encoded data that
///					we wish to send
/// @param[in]		int iLen - The length of the data to send, in bytes 
///
/// @returns	0 or QAbstractSocket_ERROR
///
//****************************************************************************
int CV7SecureSocket::Send(const char *pcBuf, int iLen) {
	int nErrCode = 0;
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
	QString   strDbgMsg;
  strDbgMsg = QString::asprintf("CV7SS::Send begin Length:%d", iLen);
	LogDebugMessage(strDbgMsg);
#endif
	switch (m_eSocketRole) {
	case SocketClient:
//#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
//		strDbgMsg = QString::asprintf("CV7SS::Send Client PID == %u :: TID == %u :: SocketClient Role", getpid(), QThread::currentThreadId());
//		LogDebugMessage(strDbgMsg);
//#endif
		if (m_pTLSCli != NULL) {
			//nErrCode = ClientSecureSend(s,(char*)pcBuf,iLen);
			nErrCode = ClientTLSSend(s, (char*) pcBuf, iLen);
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::Send ClientSecureSend After =======%d", nErrCode);
			LogDebugMessage(strDbgMsg);
#endif
		} else {
			// Call Base class method 
			nErrCode = CCESecureSocket::Send(pcBuf, iLen);
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::Send Client Norml Mode =======%d", nErrCode);
		  LogDebugMessage(strDbgMsg);
#endif
		}
		break;
	case SocketServer:
//#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
//		strDbgMsg = QString::asprintf("CV7SS::Send Server PID == %u :: TID == %u SocketServer Role", getpid(), QThread::currentThreadId());
//		LogDebugMessage(strDbgMsg);
//#endif
		if (m_pTLSSer != NULL) {
			nErrCode = ServerTLSSend(pcBuf, iLen);
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::Send ServerTLSSend After =======%d", nErrCode);
			LogDebugMessage(strDbgMsg);
#endif
		} else {
			// Call Base class method 
			nErrCode = CCESecureSocket::Send(pcBuf, iLen);
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::Send Server Norml Mode =======%d", nErrCode);
		  LogDebugMessage(strDbgMsg);
#endif
		}
		break;
	case SocketNone:
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::Send Def PID == %u :: TID == %u SocketServer Role", getpid(), QThread::currentThreadId());
		LogDebugMessage(strDbgMsg);
#endif
		// Call Base class method 
		nErrCode = CCESecureSocket::Send(pcBuf, iLen);
		break;
	default:
		break;
	}
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::Send END return =======%d", nErrCode);
	LogDebugMessage(strDbgMsg);
#endif
	return nErrCode;
}
bool CV7SecureSocket::OnReceiveEncData(char *buf, int *len, char **ppExtraBuf, int *pnExtraLen,
		E_ON_RECV_BUF_ACTION &eOrbAction) {
	bool retVal = false;
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
	QString   strDbgMsg;
  strDbgMsg = QString::asprintf("CV7SS::OnReceiveEncData Before Decrypt msg len:%d", *len);
	LogDebugMessage(strDbgMsg);
#endif
	retVal = DecryptSecureData(buf, len, ppExtraBuf, pnExtraLen);
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::OnReceiveEncData After Decrypt msg len:%d retval %d", *len, retVal);
	LogDebugMessage(strDbgMsg);
#endif
	return retVal;
}
//****************************************************************************
// int Read() 
///
/// Receive method that decrypt the data after receive
///
/// @param[in]		None
///					
///
/// @returns	0 or QAbstractSocket_ERROR
///
//****************************************************************************
bool CV7SecureSocket::DecryptSecureData(char *buf, int *len, char **ppExtraBuf, int *pnExtraLen) {
	int nErrCode = 0;
	int iLen = *len;
	int decLen = 0;
	bool retVal = false; // as expected result
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
	QString   strDbgMsg;
  strDbgMsg = QString::asprintf("CV7SecureSocket::DecryptSecureData begin Msg Length:%d", iLen);
	LogDebugMessage(strDbgMsg);	
	#endif
	switch (m_eSocketRole) {
	case SocketClient: {
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::DecryptSecureData SocketClient Role");
			LogDebugMessage(strDbgMsg);	
			#endif
		if (m_pTLSCli != NULL) {
			//decLen = m_pTLSCli->decryptReceivedClientData((void *)buf,iLen);
			decLen = m_pTLSCli->decryptReceivedData((void*) buf, iLen, false, ppExtraBuf, pnExtraLen);
			if (decLen == 0) {
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::DSD SocketClient::Couldnt Decrypt Msg of Length %d ",iLen);
					LogDebugMessage(strDbgMsg);	
					#endif
				retVal = false;
			} else {
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::DSD Encrypted Msg of Length %d to Decryted Msg Length:%d ",iLen, decLen);
					LogDebugMessage(strDbgMsg);	
					#endif
				*len = decLen;
				retVal = true;
			}
		} else {
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::DSD SocketClient Role m_pTLSCli == NULL");
				LogDebugMessage(strDbgMsg);	
				#endif
			// No dycprition 
			retVal = true;
		}
		break;
	}
	case SocketServer: {
		if (m_pTLSSer != NULL) {
			bool bEncrypting = m_pTLSSer->getEncryptStatus();
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SecureSocket::DecryptSecureData SocketServer Role");
				LogDebugMessage(strDbgMsg);	
				#endif
			if (true == bEncrypting) {
				decLen = m_pTLSSer->decryptReceivedData((void*) buf, iLen, false, ppExtraBuf, pnExtraLen);
				if (0 == decLen) {
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::DSD Couldnott Decrypt Msg of Length %d ",iLen);
						LogDebugMessage(strDbgMsg);	
						#endif
					retVal = false;
				} else {
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::DSD Encrypted Msg len %d to Decryted Msg Len:%d ",iLen, decLen);
						LogDebugMessage(strDbgMsg);	
						#endif
					if (decLen == -1) {
						decLen = 53;
					}
					//PrintHexDump(decLen,buf);
					*len = decLen;
					retVal = true;
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::DSD Encrypted updated Msg len %d to Decryted Msg Len:%d ",iLen, decLen);
						LogDebugMessage(strDbgMsg);	
						#endif
				}
			} else {
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::DSD SocketServer Role bEncrypting == %d", bEncrypting);
					LogDebugMessage(strDbgMsg);	
					#endif
				// No dycprition 
				retVal = true;
			}
		} else {
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::DSD SocketServer Role m_pTLSSer == NULL");
				LogDebugMessage(strDbgMsg);	
				#endif
			// No dycprition 
			retVal = true;
		}
		break;
	}
	case SocketNone: {
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::DSD SocketNone Role");
			LogDebugMessage(strDbgMsg);	
			#endif
		// Call Base class method 
		retVal = true;
		break;
	}
	default: {
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
  strDbgMsg = QString::asprintf("CV7SS::DSD Default");
			LogDebugMessage(strDbgMsg);	
			#endif
		retVal = true;
		break;
	}
	}
	return retVal;
}
void CV7SecureSocket::CleanUp() {
	m_eSocketRole = SocketNone;
	if (m_pTLSCli != NULL) {
		delete m_pTLSCli;
		m_pTLSCli = NULL;
	}
	if (m_pTLSSer != NULL) {
		delete m_pTLSSer;
		m_pTLSSer = NULL;
	}
}
//****************************************************************************
/// OnClose - handler override for socket close
///
/// @param[in] closeEvent - reason close has been called
///
/// @return		n/a
///
//****************************************************************************
void CV7SecureSocket::OnClose(int closeEvent) {
	CleanUp();
}
#ifdef DBG_FILE_LOG_SSL_DBG_ENABLE
void CV7SecureSocket::SetDebugLogger(CDebugFileLogger* pDbgFileLogger)
{
	CCESecureSocket::SetDebugLogger(pDbgFileLogger);
	#ifdef DBG_FILE_LOG_TLS_SERV_ENABLE
	if( NULL != m_pTLSSer )
	{
		m_pTLSSer->SetDebugLogger(m_pDebugFileLogger);
	}
	#endif
	#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
	if( NULL != m_pTLSCli )
	{
		m_pTLSCli->SetDebugLogger(m_pDebugFileLogger);
	}
	#endif
}
#endif

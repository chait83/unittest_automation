/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  Secure Comm
/// @n Filename:  V7TlsUtilities.h
/// @n Description: Utilities Functions for TLS
///
// **************************************************************************
// Revision History
// **************************************************************************
// Project		Date			Team/Person			Comments
//	TVR211		08-Aug-2019		TechM				Initial Draft
//
// **************************************************************************
#ifndef _V7_TLS_UTILITIES_H
#define _V7_TLS_UTILITIES_H
#pragma once
#include <stdio.h>
#include <iostream>
#include "V7tstring.h"
using namespace std;
#ifdef _WIN32_WCE
	#define _WCE_SECTION
#endif
#if defined(_DEBUG)
const bool debug = FALSE;
#else
const bool debug = FALSE;
#endif
/* General purpose utilities for use both at compile time and run time */
#define Stringize(L) #L
#define MakeString(M, L) M(L)
#define $Line					\
	MakeString(Stringize, __LINE__)
#define Reminder				\
	__FILE__ "(" $Line ") : Reminder: "
#ifdef _UNICODE
wstring string_format(const wstring fmt_str, ...);
wstring WinErrorMsg(int nErrorCode);
#else
string string_format(const string fmt_str, ...);
string WinErrorMsg(int nErrorCode);
#endif
void PrintHexDump(DWORD length, const void *const buf);
void PrintHexDump(DWORD length, const void *const buf, const bool verbose);
void SetThreadName(char *threadName);
void SetThreadName(char *threadName, DWORD dwThreadID);
void LogWarning(const TCHAR *const msg);
void DebugMsg(const TCHAR *pszasprintf, ...);
void DebugMsg(const std::tstring pszasprintf, ...);
bool IsUserAdmin();
void setDebugFlag(bool flag);
#endif //# _V7_TLS_UTILITIES_H

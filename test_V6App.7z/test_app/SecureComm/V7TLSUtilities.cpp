/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  Secure Comm
/// @n Filename:  V7Utilities.cpp
/// @n Description: Utilities functions for TLS 
///
// **************************************************************************
// Revision History
// **************************************************************************
// Project		Date			Team/Person				Comments
//	TVR211		08-Aug-2019		TechM					Initial Draft
//
// **************************************************************************
#include "V7TLSUtilities.h"
#include "Defines.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h> // For va_start, etc.
#include <memory>  // For std::unique_ptr
#ifdef _WCE_SECTION
		#ifndef V6APP_NOT_INCLUDED
			#include "V6globals.h"
		#endif
#endif
#include "V7tstring.h"
#define MAXDWORD 0xFFFFFFFF
//#include <fstream>
//#include <iostream>
// General purpose functions
//static std::ofstream fs("d:\\RDTCliLog.txt";
//static bool Fileflag = false;
bool myDebugFlag_g = true;
std::tstring& rtrim(std::tstring &str, const std::tstring &chars = "\t\n\v\f\r ") {
	str.erase(str.find_last_not_of(chars) + 1);
	return str;
}
#ifdef _UNICODE
std::wstring string_format(const std::wstring fmt_str, ...) 
#else
std::string string_format(const std::string fmt_str, ...)
#endif
		{
	int final_n, n = ((int) fmt_str.size()) * 2; /* Reserve two times as much as the length of the fmt_str */
	if (n < 10)
		n = 10;
#ifdef USE_CPP11
	std::unique_ptr<TCHAR[]> formatted;
#else
	TCHAR *formatted;
#endif
	va_list ap;
	while (1) {
#ifdef USE_CPP11
			formatted.reset(new TCHAR[n]); /* Wrap the plain char array into the unique_ptr */
		#else
		formatted = new TCHAR[n];
#endif
#ifdef _UNICODE
			wcscpy_s(&formatted[0], n, fmt_str.c_str());
#else
		strcpy_s(&formatted[0], n, fmt_str.c_str());
#endif
		va_start(ap, fmt_str);
#ifdef _UNICODE
		final_n = _vsnwprintf_s(&formatted[0], n, n, fmt_str.c_str(), ap);
#else
		final_n = _vsnprintf_s(&formatted[0], n, n, fmt_str.c_str(), ap);
#endif
		va_end(ap);
		if (final_n < 0 || final_n >= n)
			n += abs(final_n - n + 1);
		else
			break;
	}
#ifdef USE_CPP11
	return std::wstring(formatted.get());
#else
#ifdef _UNICODE
	return std::wstring(formatted);
#else
	return std::string(formatted);
#endif
#endif
}
#ifdef _UNICODE
std::wstring WinErrorMsg(int nErrorCode)
#else
std::string WinErrorMsg(int nErrorCode)
#endif
		{
	std::tstring theMsg;
	theMsg.resize(100);
	/* First get the message length; */
	try {
		asprintfMessage(FORMAT_MESSAGE_FROM_SYSTEM, NULL, nErrorCode, MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
				&theMsg[0], 100, NULL);
		if (theMsg.empty())
			theMsg = string_format("Error code %u (0x%.8x)", nErrorCode, nErrorCode);
	} catch (...) {
	}
	return rtrim(theMsg);
}
const DWORD MS_VC_EXCEPTION = 0x406D1388;
#pragma pack(push,8)
typedef struct tagTHREADNAME_INFO {
	DWORD dwType;
	LPCSTR szName;
	DWORD dwThreadID;
	DWORD dwFlags;
} THREADNAME_INFO;
#pragma pack(pop)
void SetThreadName(char *threadName) {
	SetThreadName(threadName, MAXDWORD);
}
void SetThreadName(char *threadName, DWORD dwThreadID) {
	THREADNAME_INFO info;
	info.dwType = 0x1000;
	info.szName = threadName;
	info.dwThreadID = dwThreadID;
	info.dwFlags = 0;
	try {
		RaiseException(MS_VC_EXCEPTION, 0, sizeof(info) / sizeof(ULONG_PTR), (ULONG_PTR*) &info);
	} catch (EXCEPTION_EXECUTE_HANDLER) {
	}
}
void LogWarning(const TCHAR *const msg) {
	DebugMsg(msg);
}
void setDebugFlag(bool flag) {
	myDebugFlag_g = flag;
}
void DebugMsg(const TCHAR *pszasprintf, ...) {
#if defined(_DEBUG)
	if (debug && myDebugFlag_g)
	{
		TCHAR buf[1024];
  StringCchPrintf(buf, sizeof(buf) / sizeof(TCHAR), "(%lu): ", QThread::currentThreadId());
		va_list arglist;
		va_start(arglist, pszasprintf);
		StringCchVPrintf(&buf[strlen(buf)], sizeof(buf) / sizeof(TCHAR), pszasprintf, arglist);
		va_end(arglist);
  StringCchCat(buf, sizeof(buf) / sizeof(TCHAR), "\n");
		OutputDebugString(buf);
		char szstring[1024];
		size_t nNumCharConverted;
		wcstombs_s(&nNumCharConverted, szstring, 1024, (LPWSTR)buf, 1024);
  FILE* f = fopen("\\SDMemory\\PNSTEST_output.txt", "a";
  fprintf(f, "%s", szstring);  
  fclose(f);
	#ifdef _WCE_SECTION
		#ifndef V6APP_NOT_INCLUDED
		LOG_P2P_MESSAGE(MSGLISTSER_P2P_INFO, buf );
		#endif
		OutputDebugString((LPCWSTR)buf);
	/*	if( mySMTPDebugFlag_g == true)
		{
  QString   strError( QString   ::fromWCharArray(QString   ::fromWCharArray("") );
			strError = QString::asprintf( L"%s",buf);
			LOG_SMTP_MESSAGE( MSGLISTSER_SMTP_CLIENT_ERROR, strError );
		}*/
#else
  //FILE* f = fopen("C:\\V7TlsUtils_Output.txt", "a";
#ifdef _UNICODE
		/*char szstring[1024];
		size_t nNumCharConverted;
		wcstombs_s(&nNumCharConverted, szstring, 1024, (LPWSTR)buf, 1024);*/
		
		//fprintf(f, "PID == %u::TID == %u :: %s", getpid(), QThread::currentThreadId(), szstring);
#else
		//fprintf(f, "PID == %u::TID == %u :: %s", getpid(), QThread::currentThreadId(), buf);		
#endif
		//fclose(f);
#endif	
		
	}
#endif
}
void DebugMsg(const std::tstring pszasprintf, ...) {
	if (debug && myDebugFlag_g) {
		TCHAR buf[1024];
		StringCchPrintf(buf, sizeof(buf) / sizeof(TCHAR), "(%lu): ", QThread::currentThreadId());
		va_list arglist;
		va_start(arglist, pszasprintf);
		StringCchVPrintf(&buf[strlen(buf)], sizeof(buf) / sizeof(TCHAR), pszasprintf.c_str(), arglist);
		va_end(arglist);
		strcat(buf, sizeof(buf) / sizeof(TCHAR), "\n");
		qDebug(buf);
		char szstring[1024];
		size_t nNumCharConverted;
		wcstombs_s(&nNumCharConverted, szstring, 1024, (LPWSTR) buf, 1024);
		FILE* f = fopen("\\SDMemory\\PNSTEST_output.txt", "a";
				fprintf(f, "%s", szstring);
				fclose (f);
#ifdef _WCE_SECTION
		#ifndef V6APP_NOT_INCLUDED
		LOG_P2P_MESSAGE(MSGLISTSER_P2P_INFO, buf );
	  #endif
		OutputDebugString((LPCWSTR)buf);
	/*	if( mySMTPDebugFlag_g == true)
		{
  QString   strError( QString   ::fromWCharArray(QString   ::fromWCharArray("") );
			strError = QString::asprintf( L"%s",buf);
			LOG_SMTP_MESSAGE( MSGLISTSER_SMTP_CLIENT_ERROR, strError );
		}*/
#else
				//FILE* f = fopen("C:\\V7TlsUtils_Output.txt", "a";
#ifdef _UNICODE
		//char szstring[1024];
		//size_t nNumCharConverted;
		//wcstombs_s(&nNumCharConverted, szstring, 1024, (LPWSTR)buf, 1024);		
		////fprintf(f, "%s", szstring);
		
#else
				//fprintf(f, "%s", buf);
#endif
				//fclose(f);
#endif
			}
		}
		static void PrintHexDumpActual(DWORD length, const void *const buf, const bool verbose) {
			DWORD i, count, index;
			TCHAR rgbDigits[] = "0123456789abcdef";
			TCHAR rgbLine[100];
			char cbLine;
			if (length == -1 || length > 200)
				length = 53;
			const byte *buffer = static_cast<const byte*>(buf);
			if (!verbose && (length > 16))
				length = 16;
			for (index = 0; length; length -= count, buffer += count, index += count) {
				count = (length > 16) ? 16 : length;
#ifdef _UNICODE
  swprintf(rgbLine, sizeof(rgbLine), "%4.4x ", index);
#else
				sprintf(rgbLine, "%4.4x ", sizeof(rgbLine));
#endif
				cbLine = 6;
				for (i = 0; i < count; i++) {
					rgbLine[cbLine++] = rgbDigits[buffer[i] >> 4];
					rgbLine[cbLine++] = rgbDigits[buffer[i] & 0x0f];
					if (i == 7) {
						rgbLine[cbLine++] = ':';
					} else {
						rgbLine[cbLine++] = ' ';
					}
				}
				for (; i < 16; i++) {
					rgbLine[cbLine++] = ' ';
					rgbLine[cbLine++] = ' ';
					rgbLine[cbLine++] = ' ';
				}
				rgbLine[cbLine++] = ' ';
				for (i = 0; i < count; i++) {
					if (buffer[i] < 32 || buffer[i] > 126 || buffer[i] == '%')
						rgbLine[cbLine++] = '.';
					else
						rgbLine[cbLine++] = buffer[i];
				}
				rgbLine[cbLine++] = 0;
				DebugMsg(rgbLine);
			}
		}
		void PrintHexDump(DWORD length, const void *const buf) {
			//if (debug) PrintHexDumpActual(length, buf, true);
		}
		void PrintHexDump(DWORD length, const void *const buf, const bool verbose) {
			//if (debug) PrintHexDumpActual(length, buf, verbose);
		}
		bool IsUserAdmin() {
			/*BOOL b;
			 SID_IDENTIFIER_AUTHORITY NtAuthority = SECURITY_NT_AUTHORITY;
			 PSID AdministratorsGroup;
			 b = AllocateAndInitializeSid(
			 &NtAuthority,
			 2,
			 SECURITY_BUILTIN_DOMAIN_RID,
			 DOMAIN_ALIAS_RID_ADMINS,
			 0, 0, 0, 0, 0, 0,
			 &AdministratorsGroup);
			 if (b)
			 {
			 if (!CheckTokenMembership(NULL, AdministratorsGroup, &b))
			 {
			 b = FALSE;
			 }
			 FreeSid(AdministratorsGroup);
			 }
			 return (b == TRUE);*/
			return true;
		}

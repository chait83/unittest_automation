/// @file MulEdit.h
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 MuLEPanel
/// @n Filename: MulEdit.h
/// @n Desc:	 variable and function decleration of the edit box 
///		 for the multiline edit panel
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  6 Stability Project 1.3.1.1 7/2/2011 4:58:54 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  5 Stability Project 1.3.1.0 7/1/2011 4:26:15 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  4 V6 Firmware 1.3 12/2/2005 7:50:01 PM  Sanjeev (HTSL) 
//  Fixed to make that Tab key work properly 
//  3 V6 Firmware 1.2 5/18/2005 6:07:08 PM  Sanjeev (HTSL) 
//  Addressed the review comments
// $
// ****************************************************************
/******************************************************************************************
 COPYRIGHT (c) 2004
 HONEYWELL INC.,
 ALL RIGHTS RESERVED
 This software is a copyrighted work and/or information protected
 as a trade secret. Legal rights of Honeywell Inc. in this
 software is distinct from ownership of any medium in which the
 software is embodied. Copyright or trade secret notices included
 must be reproduced in any copies authorized by Honeywell Inc.
 The information in this software is subject to change without
 notice and should not be considered as a commitment by Honeywell
 Inc.
 ******************************************************************************************/
#if !defined(AFX_MULEDIT_H__4EF7E488_1288_478F_B904_6FEC31DD5D3B__INCLUDED_)
#define AFX_MULEDIT_H__4EF7E488_1288_478F_B904_6FEC31DD5D3B__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MulEdit.h : header file
//
/////////////////////////////////////////////////////////////////////////////
// CMulEdit window
#include "Defines.h"
#include <QTextEdit>
#include "Widget.h"
#define LINEINDICATOR_MSG	WM_APP + 1
#define IDLETIMER_MSG		WM_APP + 2
class CMulEdit: public QTextEdit {
// Construction
public:
	CMulEdit(WORD);	///<Constructor taking single line limit value as parameter	
// Attributes
public:
// Operations
public:
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMulEdit)
	//}}AFX_VIRTUAL
// Implementation
public:
	virtual ~CMulEdit(); ///<Standard Destructor
protected:
	bool m_bLimit; ///<1 or 0 depends on the number of characters in the line
	WORD m_wLineLimit; ///<Allowed number of characters value for a single line
	bool m_bBackspace; ///<Flag to restrict the backspace key 
	bool m_bDelete; ///<Flag to restrict the delete key
	bool m_bBlockKey;  ///<Flag to block the insert and control key
	// Generated message map functions
protected:
	//{{AFX_MSG(CMulEdit)
	void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	void OnLButtonDown(UINT nFlags, QPoint point);
	void OnLButtonUp(UINT nFlags, QPoint point);
	void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar *pScrollBar);
	void OnCaptureChanged(CWidget *pWnd);
	void OnUpdate();
	void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	BOOL OnEraseBkgnd(CDC *pDC);
	UINT OnGetDlgCode();
	//}}AFX_MSG
	()
};
/////////////////////////////////////////////////////////////////////////////
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.
#endif // !defined(AFX_MULEDIT_H__4EF7E488_1288_478F_B904_6FEC31DD5D3B__INCLUDED_)

/// @file MuLEPanel.cpp
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 MuLEPanel
/// @n Filename: MuLEPanel.cpp
/// @n Desc:	 Test client for the multiline edit panel
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  7 Stability Project 1.4.1.1 7/2/2011 4:58:55 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  6 Stability Project 1.4.1.0 7/1/2011 4:26:15 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  5 V6 Firmware 1.4 6/2/2005 8:31:20 PM Sanjeev (HTSL) 
//  MuLE Integration
//  4 V6 Firmware 1.3 5/18/2005 6:07:16 PM  Sanjeev (HTSL) 
//  Addressed the review comments
// $
// ****************************************************************
/******************************************************************************************
 COPYRIGHT (c) 2004
 HONEYWELL INC.,
 ALL RIGHTS RESERVED
 This software is a copyrighted work and/or information protected
 as a trade secret. Legal rights of Honeywell Inc. in this
 software is distinct from ownership of any medium in which the
 software is embodied. Copyright or trade secret notices included
 must be reproduced in any copies authorized by Honeywell Inc.
 The information in this software is subject to change without
 notice and should not be considered as a commitment by Honeywell
 Inc.
 ******************************************************************************************/
#include "SIPGlobal.h"
#include "resource.h"
#include "../SIP/EditPanelDlg.h"
#include "MulEdit.h"
#include "MuLEPanel.h"
#include "MuLEPanelDlg.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
/////////////////////////////////////////////////////////////////////////////
// CMuLEPanelApp
//**************************************************************************
/// CMuLEPanelApp CallbackFunction()
///
/// Call by the client of the SIP to get the SIP
///
/// @param pBuffer  - Buffer pointer to store the string written by the 
///  user.
/// 
/// @return 
///  
//**************************************************************************
BOOL WINAPI CallbackFunction(QString pBuffer) {
	return TRUE;
}
BEGIN_MESSAGE_MAP(CMuLEPanelApp, CWinApp)
//{{AFX_MSG_MAP(CMuLEPanelApp)
// NOTE - the ClassWizard will add and remove mapping macros here.
//  DO NOT EDIT what you see in these blocks of generated code!
//}}AFX_MSG
END_MESSAGE_MAP()
/////////////////////////////////////////////////////////////////////////////
// CMuLEPanelApp construction
CMuLEPanelApp::CMuLEPanelApp()
: CWinApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}
/////////////////////////////////////////////////////////////////////////////
// The one and only CMuLEPanelApp object
CMuLEPanelApp theApp;
/////////////////////////////////////////////////////////////////////////////
// CMuLEPanelApp initialization
BOOL CMuLEPanelApp::InitInstance() {
	// Standard initialization
	// If you are not using these features and wish to reduce the size
	// of your final executable, you should remove from the following
	// the specific initialization routines you do not need.
	QFile Mulfile;
	DWORD dwMulLength;
	QFileDevice::FileError eMul;
	BOOL bMulreturnValue;
	LPVOID pMulFileBuffer;
#ifdef UNDER_CE
	QString  strFileName = _T("\\SDMemory2\\Multiline_24.bmp");
#else
	QString strFileName = _T(
			"C:\\Product\\Aristos_Recorder\\Software\\Source\\Binaries\\Bin\\Debug\\PC\\Multiline_24.bmp");
#endif
	//Open the bitmap file from the current directory
	if (!Mulfile.Open(strFileName, QFile::ReadOnly, &eMul)) {
#ifdef _DEBUG
		 afxDump << "File could not be opened " << eMul.m_cause << "\n";
	 #endif
	}
	dwMulLength = (DWORD) Mulfile.size();	//Get the length of the file
	pMulFileBuffer = malloc(dwMulLength);	//Allocate the memory of the file length size
	// Store the file in the allocated memory
	if (Mulfile.Read((void*) pMulFileBuffer, dwMulLength) != dwMulLength)
		return FALSE;
	// Fill the POSITION_INFO structure
	POSITION_INFO MulPositionInfo;
	MulPositionInfo.XCoordinate = 0;	//x coordinate of the SIP
	MulPositionInfo.YCoordinate = 0;  //y coordinate of the SIP
	//size and position map information
	SIZE_POSITION MulsizePosition = { { { 80, 0, 0, 319, 28 }, { 81, 0, 29, 319, 182 }, { 82, 0, 212, 52, 27 }, { 83,
			53, 212, 53, 27 }, { 84, 107, 212, 52, 27 }, { 85, 160, 212, 52, 27 }, { 86, 213, 212, 53, 27 }, { 87, 267,
			212, 52, 27 }, }, 8 };
	//bitmap information
	BITMAP_INFO MulBitmapInfo;
	MulBitmapInfo.pBmp = pMulFileBuffer; //Bitmap file buffer pointer in the memory
	MulBitmapInfo.size = dwMulLength; //Length of the bitmap file in bytes
	//Display information
	MULDISPLAY_INFO MulDisplayInfo;
	wcscpy(MulDisplayInfo.EditFontInfo.FontName, _T("Arial")); // Edit box text font name
	MulDisplayInfo.EditFontInfo.FontSize = 16; //Font size of the text for the edit box 
	MulDisplayInfo.EditFontInfo.FontColor = 0xff0000; //Font color of text for the edit box
	wcscpy(MulDisplayInfo.DescriptionFontInfo.FontName, _T("Arial")); //Description field font name
	MulDisplayInfo.DescriptionFontInfo.FontSize = 14; //Font size of the text for the description field
	MulDisplayInfo.DescriptionFontInfo.FontColor = 0xffffff; //Font color of text for description field
	wcscpy(MulDisplayInfo.TextFontInfo.FontName, _T("Arial"));
	MulDisplayInfo.TextFontInfo.FontSize = 16;
	MulDisplayInfo.TextFontInfo.FontColor = 0x00ff00;
	MulDisplayInfo.OffsetInfo.XOffset = 2; //X coordinate offset value 
	MulDisplayInfo.OffsetInfo.YOffset = 2; //Y coordinate offset value
	MulDisplayInfo.Background = 0x888800; //Background color of the edit box
	MulDisplayInfo.IndicatorColor = 0xff0000;	 // Line indicator color
	CMuLEPanelDlg dlg; //Object of the SIP class
	m_pMainWnd = &dlg;
	QDialog *pDlg = &dlg;
	//Call the InitializeIP with the first time initialization parameters
	bMulreturnValue = dlg.InitMulIP(&MulPositionInfo, &MulsizePosition, &MulBitmapInfo, &MulDisplayInfo);
	//Runtime information
	BUFFERINFO MulBufferInfo;
	MULOTHER_INFO MulOtherInfo;
	//Buffer that can contain the 30 characters 
	MulBufferInfo.pBuffer = (WCHAR*) malloc(1002);
	wcscpy(MulBufferInfo.pBuffer, _T("if ( a == 20 )\r\ncout<<a;\r\nelse\r\ncout<<b;\r\nfor(int i =0;i<10;i++)"));
	MulBufferInfo.BufferLength = 500;			//Buffer length is 30 characters
	MulBufferInfo.Limit = 500;			//limit of the characters is 30 characters 
	wcscpy(MulOtherInfo.Description, _T("Description"));			//Description string
	MulOtherInfo.pHelpTopic = new WCHAR[50];
	MulOtherInfo.pHelpChapter = new WCHAR[50];
	wcscpy(MulOtherInfo.pHelpTopic, _T("Software Input Panel"));
	wcscpy(MulOtherInfo.pHelpChapter, _T("How to use Software Input Panel"));
	MulOtherInfo.TimeOut = 50000;	//Timeout value is 50 seconds
	MulOtherInfo.LineLimit = 80;		//Number of characters limit for a single line
	glbpCallbackFunction pFunctionPointer = CallbackFunction; //Validation function pointer
	KEYTEXT keyText;
	wcscpy(keyText.EditKeyText, _T("Edit"));		// Copy the edit key text
	wcscpy(keyText.DeleteKeyText, _T("Delete")); // Copy the Delete key text
	wcscpy(keyText.InsertKeyText, _T("Insert")); // Copy the Insert key text
///////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////Single line Edit Panel Initialization//////////////////
///////////////////////////////////////////////////////////////////////////////////////////
	QFile file;
	DWORD dwLength;
	QFileDevice::FileError e;
	BOOL bReturnValue;
	LPVOID pFileBuffer;
#ifdef UNDER_CE
	QString  strBMPFileName = L"\\SDMemory2\\Demopanel.bmp";
#else
	QString strBMPFileName = L"C:\\Product\\Aristos_Recorder\\Software\\Source\\Binaries\\Bin\\Debug\\PC\\Demopanel.bmp";
#endif	
	//Open the bitmap file from the current directory
	if (!file.Open(strBMPFileName, QFile::ReadOnly, &e)) {
#ifdef _DEBUG
		 afxDump << "File could not be opened " << e.m_cause << "\n";
	 #endif
	}
	//Get the length of the file
	dwLength = (DWORD) file.size();
	//Allocate the memory of the file length size
	pFileBuffer = malloc(dwLength);
	// Store the file in the allocated memory
	if (file.Read((void*) pFileBuffer, dwLength) != dwLength)
		return FALSE;
	// Fill the POSITION_INFO structure
	POSITION_INFO PositionInfo;
	PositionInfo.XCoordinate = 0;	//x coordinate of the SIP
	PositionInfo.YCoordinate = 0;  //y coordinate of the SIP
	//size and position map information
	SIZE_POSITION sizePosition = { { { 61, 2, 20, 220, 20 }, { 62, 2, 0, 220, 20 }, { 63, 226, 2, 44, 30 }, { 64, 274,
			2, 44, 30 }, { 70, 224, 34, 30, 26 }, { 71, 256, 34, 30, 26 }, { 69, 288, 34, 30, 26 },
			{ 1, 0, 62, 30, 26 }, { 2, 32, 62, 30, 26 }, { 3, 64, 62, 30, 26 }, { 4, 96, 62, 30, 26 }, { 5, 128, 62, 30,
					26 }, { 6, 160, 62, 30, 26 }, { 7, 192, 62, 30, 26 }, { 8, 224, 62, 30, 26 },
			{ 9, 256, 62, 30, 26 }, { 10, 288, 62, 30, 26 }, { 11, 0, 92, 30, 26 }, { 12, 32, 92, 30, 26 }, { 13, 64,
					92, 30, 26 }, { 14, 96, 92, 30, 26 }, { 15, 128, 92, 30, 26 }, { 16, 160, 92, 30, 26 }, { 17, 192,
					92, 30, 26 }, { 18, 224, 92, 30, 26 }, { 19, 256, 92, 30, 26 }, { 20, 288, 92, 30, 26 }, { 21, 0,
					122, 30, 26 }, { 22, 32, 122, 30, 26 }, { 23, 64, 122, 30, 26 }, { 24, 96, 122, 30, 26 }, { 25, 128,
					122, 30, 26 }, { 26, 160, 122, 30, 26 }, { 27, 192, 122, 30, 26 }, { 28, 224, 122, 30, 26 }, { 29,
					256, 122, 30, 26 }, { 30, 288, 122, 30, 26 }, { 31, 0, 152, 30, 26 }, { 32, 32, 152, 30, 26 }, { 33,
					64, 152, 30, 26 }, { 34, 96, 152, 30, 26 }, { 35, 128, 152, 30, 26 }, { 36, 160, 152, 30, 26 }, {
					37, 192, 152, 30, 26 }, { 38, 224, 152, 30, 26 }, { 39, 256, 152, 30, 26 },
			{ 73, 288, 152, 30, 26 }, { 65, 0, 182, 30, 26 }, { 40, 32, 182, 30, 26 }, { 41, 64, 182, 30, 26 }, { 42,
					96, 182, 30, 26 }, { 43, 128, 182, 30, 26 }, { 44, 160, 182, 30, 26 }, { 45, 192, 182, 30, 26 }, {
					46, 224, 182, 30, 26 }, { 72, 256, 182, 62, 26 }, { 66, 0, 212, 30, 26 }, { 67, 32, 212, 30, 26 }, {
					68, 64, 212, 30, 26 }, { 74, 96, 212, 94, 26 }, { 47, 192, 212, 30, 26 }, { 48, 224, 212, 30, 26 },
			{ 49, 256, 212, 30, 26 }, { 50, 288, 212, 30, 26 }, }, 64 };
	//Key map information		
	KEY_MAP_INFO KeyMapInfo = { { { 1, 33, 33, 191, 191 }, { 2, 34, 34, 161, 161 }, { 3, 35, 35, 222, 254 }, { 4, 36,
			36, 162, 162 }, { 5, 37, 37, 163, 163 }, { 6, 43, 43, 165, 165 }, { 7, 39, 39, 167, 167 }, { 8, 42, 42, 176,
			176 }, { 9, 40, 40, 177, 200 }, { 10, 41, 41, 181, 201 }, { 11, 49, 49, 49, 49 }, { 12, 50, 50, 50, 50 }, {
			13, 51, 51, 51, 51 }, { 14, 52, 52, 52, 52 }, { 15, 53, 53, 53, 53 }, { 16, 54, 54, 54, 54 }, { 17, 55, 55,
			55, 55 }, { 18, 56, 56, 56, 56 }, { 19, 57, 57, 57, 57 }, { 20, 48, 48, 48, 48 },
			{ 21, 'q', 'Q', 224, 192 }, { 22, 'w', 'W', 225, 193 }, { 23, 'e', 'E', 226, 194 },
			{ 24, 'r', 'R', 227, 195 }, { 25, 't', 'T', 228, 196 }, { 26, 'y', 'Y', 229, 197 },
			{ 27, 'u', 'U', 230, 198 }, { 28, 'i', 'I', 231, 199 }, { 29, 'o', 'O', 232, 200 },
			{ 30, 'p', 'P', 233, 201 }, { 31, 'a', 'A', 234, 202 }, { 32, 's', 'S', 235, 203 },
			{ 33, 'd', 'D', 236, 204 }, { 34, 'f', 'F', 237, 205 }, { 35, 'g', 'G', 238, 206 },
			{ 36, 'h', 'H', 239, 207 }, { 37, 'j', 'J', 241, 209 }, { 38, 'k', 'K', 242, 210 },
			{ 39, 'l', 'L', 243, 211 }, { 40, 'z', 'Z', 244, 212 }, { 41, 'x', 'X', 245, 213 },
			{ 42, 'c', 'C', 246, 214 }, { 43, 'v', 'V', 248, 216 }, { 44, 'b', 'B', 249, 217 },
			{ 45, 'n', 'N', 250, 218 }, { 46, 'm', 'M', 251, 219 }, { 47, 91, 91, 91, 91 }, { 48, 93, 93, 93, 93 }, {
					49, 60, 44, 60, 44 }, { 50, 62, 46, 62, 46 }, }, 50 };
	//bitmap information
	BITMAP_INFO BitmapInfo;
	BitmapInfo.pBmp = pFileBuffer; //Bitmap file buffer pointer in the memory
	BitmapInfo.size = dwLength; //Length of the bitmap file in bytes
	//Display information
	DISPLAY_INFO DisplayInfo;
	wcscpy(DisplayInfo.TextFontInfo.FontName, _T("Arial"));	//SIP layout text font name
	DisplayInfo.TextFontInfo.FontSize = 16;	//Font size of the text for the SIP layout 
	DisplayInfo.TextFontInfo.FontColor = 0x000000;	//font color of text for the SIP layout
	wcscpy(DisplayInfo.EditFontInfo.FontName, _T("Arial"));	// Edit box text font name
	DisplayInfo.EditFontInfo.FontSize = 16;	//Font size of the text for the edit box 
	DisplayInfo.EditFontInfo.FontColor = 0xff0000; //Font color of text for the edit box
	wcscpy(DisplayInfo.DescriptionFontInfo.FontName, _T("Arial"));	//Description field font name
	DisplayInfo.DescriptionFontInfo.FontSize = 12;	//Font size of the text for the description field
	DisplayInfo.DescriptionFontInfo.FontColor = 0x0000ff;	//Font color of text for description field
	DisplayInfo.OffsetInfo.XOffset = 2;	//X coordinate offset value 
	DisplayInfo.OffsetInfo.YOffset = 2;	//Y coordinate offset value
	DisplayInfo.Background = 0x00ff44;	//Background color of the edit box
	CEditPanelDlg Editdlg;	//Object of the single line SIP class
	QDialog *pEditDlg = &Editdlg;
	//Call the InitializeIP with the first time initialization parameters
	bReturnValue = Editdlg.InitializeIP(&PositionInfo, &sizePosition, &KeyMapInfo, &BitmapInfo, &DisplayInfo);
///////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////Single line Edit Panel/////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////
//	CEditPanelDlg* pEditDialog = &Editdlg;
	CEditPanelDlg *pEditDialog = &Editdlg;
	BYTE IsUpdate;
	BYTE *pIsTimeOut = new (BYTE);
	//Call the ShowIP function with run time initialization pointer
	bMulreturnValue = dlg.ShowMulIP(&MulBufferInfo, pFunctionPointer, &MulOtherInfo, &IsUpdate, pIsTimeOut, pEditDialog,
			&keyText);
	//Remove the dynamic allocation from the memory
	delete[] MulOtherInfo.pHelpTopic;
	delete[] MulOtherInfo.pHelpChapter;
	delete pIsTimeOut;
	free(MulBufferInfo.pBuffer);
	free(pMulFileBuffer);
	free(pFileBuffer);
	// Since the dialog has been closed, return FALSE so that we exit the
	// application, rather than start the application's message pump.
	return FALSE;
}

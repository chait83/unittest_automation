#include "AlphaNumMuLEDlg.h"
#include "OEMInfo.h"
#include "V6ResConstants.h"
#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
// Static/Const Variable Initialisation
std::unique_ptr<CAlphaNumMuLEDlg> CAlphaNumMuLEDlg::ms_kMuLEDlg;
//****************************************************************************
// CAlphaNumMuLEDlg( CWidget* pkParent )
///
/// Constructor
///
/// @param[in] 	  CWidget* pkParent - A pointer to the parent window
/// 
//****************************************************************************
CAlphaNumMuLEDlg::CAlphaNumMuLEDlg(CWidget *pkParent) : CMuLEPanelDlg(pkParent) {
}
//****************************************************************************
// ~CAlphaNumEditDlg( )
///
/// Destructor
/// 
//****************************************************************************
CAlphaNumMuLEDlg::~CAlphaNumMuLEDlg() {
}
//****************************************************************************
// CRecSetupCfgMgr* Instance()
///
/// Singleton Accessor/Creator
///
/// @param[in] 	  CWidget* pkParent - A pointer to the parent window
///
/// @return A pointer to the singleton instance of the class
/// 
//****************************************************************************
CAlphaNumMuLEDlg* CAlphaNumMuLEDlg::Instance(CWidget *pkParent /* = NULL */) {
	if (ms_kMuLEDlg.get() == NULL) {
		std::unique_ptr<CAlphaNumMuLEDlg> kNewMuLEDlg(new CAlphaNumMuLEDlg(pkParent));
		ms_kMuLEDlg = kNewMuLEDlg;
		CAlphaNumMuLEDlg *pkMuLEDlg = ms_kMuLEDlg.get();
		// check the dialog was created okay
		if (pkMuLEDlg != NULL) {
			// as this is the first time we need to initialise the class data such as bitmaps
			pkMuLEDlg->InitializeIP();
		}
	}
	return ms_kMuLEDlg.get();
}
//****************************************************************************
// void InitializeIP()
///
/// Method that initialises the edit panel member variables such as the bitmap and keymap
/// 
//****************************************************************************
void CAlphaNumMuLEDlg::InitializeIP() {
	BOOL bOK = FALSE;
	// get a handle on the OEM info class
	COEMInfo *pkOEMInfo = COEMInfo::Instance();
	// Fill the POSITION_INFO structure
	POSITION_INFO PositionInfo;
	PositionInfo.XCoordinate = 0;	//x coordinate of the SIP
	PositionInfo.YCoordinate = 0;  //y coordinate of the SIP
	//bitmap information
	BITMAP_INFO BitmapInfo;
	BitmapInfo.pBmp = pkOEMInfo->GetPanelUpImage(V6RES_PANEL_GRAPHIC_MULEPANEL);
	ResPanel *ptPaneInfo = pkOEMInfo->GetPanelInfo(V6RES_PANEL_GRAPHIC_MULEPANEL);
	BitmapInfo.size = ptPaneInfo->graUp.size;
	SIZE_POSITION *pkSizePosInfo = NULL;
	pkSizePosInfo = reinterpret_cast<SIZE_POSITION*>(pkOEMInfo->GetPanelSPMap(V6RES_PANEL_GRAPHIC_MULEPANEL));
	// Temporary vairable used to hold colour information
	ResColour *pkColourInfo = NULL;
	//Display information
	MULDISPLAY_INFO DisplayInfo;
	wcscpy(DisplayInfo.TextFontInfo.FontName, _T("Arial")); //SIP layout text font name
	DisplayInfo.TextFontInfo.FontSize = 16; //Font size of the text for the SIP layout 
	pkColourInfo = pkOEMInfo->GetColour( V6RES_COLOUR_MULEKEYTXT); // font color of text for the SIP layout
	DisplayInfo.TextFontInfo.FontColor = pkColourInfo->pColor;
	wcscpy(DisplayInfo.EditFontInfo.FontName, _T("Arial")); // Edit box text font name
	DisplayInfo.EditFontInfo.FontSize = 16; //Font size of the text for the edit box 
	pkColourInfo = pkOEMInfo->GetColour( V6RES_COLOUR_MULEEDITTXT); // Font color of text for the edit box
	DisplayInfo.EditFontInfo.FontColor = pkColourInfo->pColor;
	wcscpy(DisplayInfo.DescriptionFontInfo.FontName, _T("Arial")); //Description field font name
	DisplayInfo.DescriptionFontInfo.FontSize = 16; //Font size of the text for the description field
	pkColourInfo = pkOEMInfo->GetColour( V6RES_COLOUR_MULEDESC); // Font color of text for description field
	DisplayInfo.DescriptionFontInfo.FontColor = pkColourInfo->pColor;
	DisplayInfo.OffsetInfo.XOffset = 2; //X coordinate offset value 
	DisplayInfo.OffsetInfo.YOffset = 2; //Y coordinate offset value
	pkColourInfo = pkOEMInfo->GetColour( V6RES_COLOUR_MULEEDITBG); // Background color of the edit box
	DisplayInfo.Background = pkColourInfo->pColor;
	DisplayInfo.IndicatorColor = 0x0000ff;
	// Now initialise the base object with our custom parameters
	CMuLEPanelDlg::InitMulIP(&PositionInfo, pkSizePosInfo, &BitmapInfo, &DisplayInfo);
}

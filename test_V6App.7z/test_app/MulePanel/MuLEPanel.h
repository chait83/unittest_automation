/// @file MuLEPanel.h
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 MuLEPanel
/// @n Filename: MuLEPanel.h
/// @n Desc:	 variable and function decleration of the Test client 
///		 for the multiline edit panel
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  5 Stability Project 1.2.1.1 7/2/2011 4:58:55 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  4 Stability Project 1.2.1.0 7/1/2011 4:26:15 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  3 V6 Firmware 1.2 6/2/2005 8:31:12 PM Sanjeev (HTSL) 
//  MuLE Integration
//  2 V6 Firmware 1.1 5/18/2005 12:01:00 PM  Sanjeev (HTSL) 
//  Added the doxygen comments
// $
// ****************************************************************
/******************************************************************************************
 COPYRIGHT (c) 2004
 HONEYWELL INC.,
 ALL RIGHTS RESERVED
 This software is a copyrighted work and/or information protected
 as a trade secret. Legal rights of Honeywell Inc. in this
 software is distinct from ownership of any medium in which the
 software is embodied. Copyright or trade secret notices included
 must be reproduced in any copies authorized by Honeywell Inc.
 The information in this software is subject to change without
 notice and should not be considered as a commitment by Honeywell
 Inc.
 ******************************************************************************************/
#if !defined(AFX_MULEPANEL_H__4B1727BD_B919_4052_9154_2A11AA8F5253__INCLUDED_)
#define AFX_MULEPANEL_H__4B1727BD_B919_4052_9154_2A11AA8F5253__INCLUDED_
#include "resource.h"		// main symbols
#include "../SIP/EditPanelDlg.h"
/////////////////////////////////////////////////////////////////////////////
// CMuLEPanelApp:
// See MuLEPanel.cpp for the implementation of this class
//
class CMuLEPanelApp: public CWinApp {
public:
	CMuLEPanelApp();
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMuLEPanelApp)
public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL
// Implementation
	//{{AFX_MSG(CMuLEPanelApp)
	// NOTE - the ClassWizard will add and remove member functions here.
	//  DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
};
/////////////////////////////////////////////////////////////////////////////
//{{AFX_INSERT_LOCATION}}
// Microsoft eMbedded Visual C++ will insert additional declarations immediately before the previous line.
#endif // !defined(AFX_MULEPANEL_H__4B1727BD_B919_4052_9154_2A11AA8F5253__INCLUDED_)

/// @file MuLEPanelDlg.h
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 MuLEPanel
/// @n Filename: MuLEPanelDlg.h
/// @n Desc:	 Functions Definitions of the Multiline Edit Panel
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  12  Stability Project 1.9.1.1 7/2/2011 4:58:57 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  11  Stability Project 1.9.1.0 7/1/2011 4:26:15 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  10  V6 Firmware 1.9 12/20/2006 2:56:25 PM  Roger Dawson  
//  Phase 3b merges into the main build. Added border to the dialog when
//  being displayed on an SX recorder.
//  9 V6 Firmware 1.8 3/15/2006 10:16:57 PM  Roger Dawson  
//  Fixed problems with excessive memory usage.
// $
//
// ****************************************************************
/******************************************************************************************
 COPYRIGHT (c) 2004
 HONEYWELL INC.,
 ALL RIGHTS RESERVED
 This software is a copyrighted work and/or information protected
 as a trade secret. Legal rights of Honeywell Inc. in this
 software is distinct from ownership of any medium in which the
 software is embodied. Copyright or trade secret notices included
 must be reproduced in any copies authorized by Honeywell Inc.
 The information in this software is subject to change without
 notice and should not be considered as a commitment by Honeywell
 Inc.
 ******************************************************************************************/
#if !defined(AFX_MULEPANELDLG_H__C01109A7_6141_4D12_9A3A_0B984F88DF37__INCLUDED_)
#define AFX_MULEPANELDLG_H__C01109A7_6141_4D12_9A3A_0B984F88DF37__INCLUDED_
#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
/////////////////////////////////////////////////////////////////////////////
// CMuLEPanelDlg dialog
#include "SIPGlobal.h"
#include "MulEdit.h"
#include <memory>
// Forward Class Declaration
class CEditPanelDlg;
class CMuLEPanelDlg: public QDialog {
public:
	CMuLEPanelDlg(CWidget *pParent = NULL);	///< Standard constructor
	~CMuLEPanelDlg();						///< Destructor
	BOOL WINAPI InitMulIP(POSITION_INFO*, const SIZE_POSITION*, BITMAP_INFO*, MULDISPLAY_INFO*);
	BOOL WINAPI ShowMulIP(BUFFERINFO*, glbpCallbackFunction, OTHERINFO*, BYTE*, BYTE*, CEditPanelDlg*, KEYTEXT*);
// Dialog Data
	//{{AFX_DATA(CMuLEPanelDlg)
	enum {
		IDD = IDD_MULEPANEL_DIALOG
	};
	// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMuLEPanelDlg)
protected:
	virtual void DoDataExchange(CDataItem *pDX);	// DDX/DDV support
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL
private:
	// Method that initialises the edit panel member variables such as the bitmap and keymap
	void InitializeIP();
	// MEthod thast reloads the DIB
	void ReloadBitmap();
// Implementation
protected:
	BITMAPINFO *m_pBMInfo;				///< Store the bitmap information 
	QRect m_ObjRect; ///< contain SIP layout size coordinates in the screen
	HBRUSH m_HbrEdit; ///< Brush to draw the edit box 
	QBrush m_EditBrush;			///< Used to create the edit box brush  
	QImage m_hOldBitmapSel;
	// First time initialization parameters 
	POSITION_INFO m_PositionInfo;	///< contains the starting position of the SIP in the recorder screen
	const SIZE_POSITION *m_pkSizePosition; ///< contains the size and position map 
	MULDISPLAY_INFO m_DisplayInfo; ///< contains the font information, description field string
	BITMAP_INFO m_BitmapInfo;  ///< contains the Bmp file related information
	WORD m_wKeyID;			///< KeyID of the pressed key
	WORD m_wIndex;			///< index of the size and position map
	CFont m_EditFont;			///< font to write the character in the edit box
	CFont m_StaticFont;		///< font to write the character in the static control	
	CFont m_DescriptionFont;	///< Description field font info
	CFont m_KeyTextFont;
	CMulEdit *m_pEdit;			///< A pointer variable to create the edit box in the SIP layout
	CStatic *m_pleftStatic;		///< A pointer variable to create the static box in the SIP layout
	//Memory DC object pointers
	CDC *m_pMemDC;			///< Memory DC 
	CClientDC *m_pClientDC;		///< Client DC object pointer
	QImage m_BMHandle;	 ///< Bitmap handle
	//Runtime initialization parameters
	BUFFERINFO m_BufferInfo;	 ///< Contain Buffer information 
	OTHERINFO m_OtherInfo;	 ///< Contain other information 
	glbpCallbackFunction pCallbackPointer;	 ///< Callback function pointer to validate the string
	KEYTEXT m_KeyText;		 ///< String to write over the key area 	
	WORD m_wOnceDraw;			///< Used as a flag	
	WORD m_wMulEditIndex;		///< Multiline Edit box index of the Size and Position map	
	BYTE m_byIsModified;  ///< A flag to indicate that buffer is modified or not
	BYTE m_byIsTimeOut;  ///< A flag to indicate that multiline SIP dialog c 
	//Not required in Desktop 
#ifdef UNDER_CE
		HCURSOR m_Hcursor;			///< Handle of the cursor
	#endif
	void DrawMulIP();			///< Draw the Multiline SIP layout in the screen
	WORD GetMulKeyID(WORD xCoordinate, WORD yCoordinate);			///<giving the pressed key key id
	void InsertLine();			///< To insert the line 
	void DeleteLine();  ///< To delete the line 
	void EditLine();				///< To edit the line					
	virtual void OnOK();				///< To close the Multiline edit panel dialog
	virtual void OnCancel();			///< To close the Multilien edit panel dialog
	bool m_bInitialised;				///< To indicate that InitMulIP has called before or not
	CEditPanelDlg *m_pEditPanel;		///< Single line SIP object pointer
	// Generated message map functions
	//{{AFX_MSG(CMuLEPanelDlg)
	virtual BOOL OnInitDialog();
	void OnPaint();
	void OnLButtonDown(UINT nFlags, QPoint point);
	void OnLButtonUp(UINT nFlags, QPoint point);
	HBRUSH OnCtlColor(CDC *pDC, CWidget *pWnd, UINT nCtlColor);
	void OnMouseMove(UINT nFlags, QPoint point);
	void OnTimer(UINT nIDEvent);
	LRESULT SetLineIndicatorPos(WPARAM, LPARAM);
	LRESULT SetIdleTimer(WPARAM, LPARAM);
	//}}AFX_MSG
	()
};
//{{AFX_INSERT_LOCATION}}
// Microsoft eMbedded Visual C++ will insert additional declarations immediately before the previous line.
#endif // !defined(AFX_MULEPANELDLG_H__C01109A7_6141_4D12_9A3A_0B984F88DF37__INCLUDED_)

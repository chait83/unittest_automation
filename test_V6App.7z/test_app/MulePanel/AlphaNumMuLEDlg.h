#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "MuLEPanelDlg.h"
#include <memory>
//**CAlphaNumEditDlg**********************************************************
///
/// @brief Singleton Dialog that displays the Alphanumeric SIP
/// 
/// Singleton dialog class that displays the alphanumeric SIP. Class need to be a singelton as
/// various parts of the intialisation only need to be carried out once e.g. loading the resources
///
//****************************************************************************
class CAlphaNumMuLEDlg: public CMuLEPanelDlg {
public:
	// Destructor
	virtual ~CAlphaNumMuLEDlg();
	// Singleton Accessor/Creator
	static CAlphaNumMuLEDlg* Instance(CWidget *pkParent = NULL);
	// Method that initialises the edit panel member variables such as the bitmap and keymap
	void InitializeIP();
private:
	// Constructor
	CAlphaNumMuLEDlg(CWidget *pkParent = NULL);
	// Singleton variable
	static std::unique_ptr<CAlphaNumMuLEDlg> ms_kMuLEDlg;
};

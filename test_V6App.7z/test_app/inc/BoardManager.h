/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n BoardManager.h
/// @n Internally used card reference holder.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 9	Stability Project 1.6.1.1	7/2/2011 4:55:41 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 8	Stability Project 1.6.1.0	7/1/2011 4:27:07 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 7	V6 Firmware 1.6		2/25/2005 8:57:58 PM	Graham Waterfield
//		Continued adding input conditioning changes
// 6	V6 Firmware 1.5		12/24/2004 3:14:50 PM Graham Waterfield
//		Improving source realiability
// $
//
//////////////////////////////////////////////////////////////////////
#ifndef _BOARDMANGR_H
#define _BOARDMANGR_H
#include "Defines.h"
//const UCHAR MAXIOCARDS = 1;
const UCHAR MAXIOCARDS = 9;
const UCHAR MAX_SCHED_SERVICES = 10;
// I/O board commands
// Many of these commands require parameteters for mode	cardID and channel selection
typedef enum tmodiocommand {
	MOD_IO_NONE,				///< Don't do anything (card idle default mode)
	MOD_IO_RUN_MODE,						///< Schedule real-time acquisition
	MOD_IO_CHECKEXIST,							///< Check if the card exists
	MOD_IO_STARTUP,	///< Redo card startup (card recovery)	but under scheduler startup.
	MOD_IO_CONFIGURE,								///< Configure the card
	MOD_IO_CALPREPARE,								///< Prepare to calibrate
	MOD_IO_CALSETPOINT,							///< Set a calibration point
	MOD_IO_CALTERMINATE,					///< Terminate a calibrate sequence
	MOD_IO_CALCOMPLETE,							///< End calibration
	MOD_IO_READCALINFO,							///< Read calibration info
	MOD_IO_READHISTORY,							///< Read card life history
	MOD_IO_SETIDENTITY,					///< Set card identity (serial number)
	MOD_IO_READIDENTITY,				///< Read card identity (serial number)
	MOD_IO_SETRIGID								///< Set testing rig identity
} T_MOD_IO_COMMAND;
// I/O board command execution status codes
typedef enum iocardstat {
	IOSTAT_CMDOK,					///< Command has been actioned
	IOSTAT_CMDFAILED,		///< Command was valid but failed during execution
	IOSTAT_CMDINVALID,				///< Command to this I/O board is invalid
	IOSTAT_CARDBUSY,				///< I/O card is busy and cannot be released from current operation
	IOSTAT_INVALIDPROTOCOL		///< I/O card was handed an invalid protocol
} IOCARDSTAT;
#endif // _BOARDMANGR_H

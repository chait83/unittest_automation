/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Control sequencer
/// @n Filename: V6PassiveModuleServices.cpp
/// @n Desc:	 Passive modules
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  25  Aristos  1.21.1.1.1.0 9/19/2011 4:51:09 PM  Hemant(HAIL)  
//  Stability recorder source code (JI Release) updated for WatchDog
//  Timer functionality.
//  24  Stability Project 1.21.1.1 7/2/2011 5:02:45 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  23  Stability Project 1.21.1.0 7/1/2011 4:27:24 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  22  V6 Firmware 1.21 4/26/2007 1:29:48 PM  Roger Dawson  
//  Added print manager passive module which allows multiple documents to
//  be printed simultaneously.
// $
//
// ****************************************************************
#ifndef _V6PASSIVEMODULESERVICES_H
#define _V6PASSIVEMODULESERVICES_H
#include "PassiveModule.h"
/// Return Values for CV6ActiveModule Member Functions, used to describe the type of 
/// success or failure.
/// 
typedef enum {
	V6PMSER_OK, V6PMSER_MODULE_CREATION_FAILED,
} T_V6PMSER_RETURN_VALUE;
/// A Enumeration for active modules
typedef enum E_V6PMSER_PASSIVE_MODULES {
	V6PMSER_SRAM,  ///< Persisited Memory
	V6PMSER_FLASH,						///< Flash memory manager
	V6PMSER_SYSINFO,					///< System INFO
	V6PMSER_SYSTIMER,					///< System Timer
	V6PMSER_MODMSGMAN, ///< Module Message Manager
	V6PMSER_PPQMAN, ///< Pre Process Queue Manager
	V6PMSER_INP_CONDITIONING,			///< I/O board slot system conditioner
	V6PMSER_SLOT_MAP,					///< I/O board slot & system mapper
	V6PMSER_BRDINFO,					///< I/O board Info for system
	V6PMSER_BRDSTATS,					///< I/O board Stats for system
	V6PMSER_ATECAL,						///< I/O board calibration singleton for system
	V6PMSER_AIRANGES,					///< AI board range singleton for system
	V6PMSER_CFGMANAGER,					///< Board configuration manager
	V6PMSER_DIT,						///< Data Item Table
	V6PMSER_PENMANAGER,					///< Pen Manager
	V6PMSER_TRANSFER,					///< Data Transfer Services
	V6PMSER_MESSAGE_LIST,  ///< Message List Services
	V6PMSER_NVVARIBALE,					///< Non volatile varibale manager
	V6PMSER_DQMANAGER,					///< Data queue manager
	V6PMSER_SCRIPTS,					///< Script manager
	V6PMSER_EVTMANAGER,					///< Event Manager
//	V6PMSER_AUTH_UI,					///< UI for password authentication
	V6PMSER_MEDIA_MANAGER,				///< Media manager (media detection and identification)
	V6PMSER_PRINT_MANAGER,				///< Print manager
#ifdef UNDER_CE				
		#ifndef DISABLE_WDT	
			V6PMSER_THREAD_INFO,  /// < ThreadInfo class that stores the info required by 
			///	< the WatchDog Timer
		#endif
	#endif
	V6PMSER_NUM_OF_PASSIVE_MODULES
} T_V6PMSER_PASSIVE_MODULES;
//**Class*********************************************************************
///
/// @brief Base Class for all Passive Modules within V6
/// 
///
//****************************************************************************
class CV6PassiveModuleServices {
public:
	/// Constructor
	CV6PassiveModuleServices(void);
	/// Destructor
	virtual ~CV6PassiveModuleServices(void);
	/// Create Passive Modules
	T_V6PMSER_RETURN_VALUE CreatePassiveModules(void);
	/// Obtain a specific Active Module, return will need to cast to the relevant module
	CPassiveModule& GetPassiveModule(T_V6PMSER_PASSIVE_MODULES passiveModule);
	// Delete Passive Modules Created
	T_V6PMSER_RETURN_VALUE DeletePassiveModules(void);
private:
	// --- Private Member Functions --- //
	// Initialise Pointer to NULL
	T_V6PMSER_RETURN_VALUE InitialisePointersToDefault(void);
	CPassiveModule *m_PassiveModule[V6PMSER_NUM_OF_PASSIVE_MODULES];
};
// End of Class Declaration
/// Obtain a specific Active Module, return will need to cast to the relevant module
inline CPassiveModule& CV6PassiveModuleServices::GetPassiveModule(T_V6PMSER_PASSIVE_MODULES passiveModule) {
	return (*m_PassiveModule[passiveModule]);
} // End of Member Function
#endif // _V6PASSIVEMODULESERVICES_H

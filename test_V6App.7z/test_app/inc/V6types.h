/// @file 
/// ****************************************************************
/// ?Honeywell Trendview
/// ****************************************************************
/// @n Module:	Generic
/// @n Filename: V6types.h
/// @n Desc:	V6 typedefs and enumerated types
///				
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 57	Stability Project 1.54.1.1	7/2/2011 5:02:47 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 56	Stability Project 1.54.1.0	7/1/2011 4:27:28 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 55	V6 Firmware 1.54		9/23/2008 3:09:37 PM	Build Machine 
//		AMS2750 Merge
// 54	V6 Firmware 1.53		3/4/2008 7:01:13 PM	Roger Dawson 
//		Added the ability to save screenshots to disk, either manually or via
//		the event system.
// $
//
// ****************************************************************
#ifndef __V6TYPES_H__
#define __V6TYPES_H__
#include "Defines.h"
/// ** General purpose Types *********************
#define LangAll 1
#define LangChinese 1
#define LangJapanese 1
#define LangKorean 1
// Day of week,, same numbers and order to that of QDateTime structure
typedef enum {
	DOW_SUNDAY = 0, DOW_MONDAY, DOW_TUESDAY, DOW_WEDNESDAY, DOW_THURSDAY, DOW_FRIDAY, DOW_SATURDAY, DOW_EVERYDAY
} T_DAY_OF_WEEK;
/// Union for a basic value type allowing access to all types within 4 bytes
typedef union {
	float flt;
	ULONG ul;
	USHORT us[2];
	short s[2];
	UCHAR byte[4];
	char ch[4];
} COMBO_VAR4;
/// Union for a longlong combined with basic types
typedef union {
	COMBO_VAR4 val[2];
	LONGLONG ll;
	USHORT us[4];
	UCHAR byte[8];
	ULONG ul[2];
} COMBO_VAR8;
//// ********************************************************************
//// ***************************ALARM FIELDS*****************************
//// ********************************************************************
/// Alarm types, conforms to the configuration item in the alarms stucture T_ALARM.Type
typedef enum {
	ALARM_TYPE_HIGH = 0,				///< High limit breach to activate alarm
	ALARM_TYPE_LOW = 1,					///< Low limit breach to activate alarm
	ALARM_TYPE_DEVIATION = 2,	///< Diviation by %age from another Pen value
	ALARM_TYPE_RATEUP = 3,				///< Rate Down breach to activate alarm
	ALARM_TYPE_RATEDOWN = 4,			///< Rate Up breach to activate alarm
	ALARM_TYPE_MAX_NUMBER	///< Max number of alarm types						
} T_ALARM_TYPES;
/// Alarm enabled types, conforms to the configuration item T_ALARM.EnabledType
typedef enum {
	ALARM_DISABLED = 0,					///< Alarm is disabled
	ALARM_ENABLED_ALWAYS = 1,			///< Alarm is always enabled enabled 
	ALARM_ENABLED_BY_DI = 2,			///< Alarm is enabled depending on selected digital inputs
} T_ALARM_ENABLED_TYPES;
// PEN ENUMS **************************************
/// Enum for the various types of maths expression - Basic will be a direct variable,
/// block is a single line maths expression and scripting will be a multiline expression
typedef enum {
	MATH_TYPE_BLOCK,		///< Maths block, single line
	MATH_TYPE_SCRIPTING		///< Script, Multi-line script block
} T_MATH_TYPE;
/// Totaliser types, this must conform with the order set in the List item for confioguration
/// in the resource.
typedef enum {
	TOTAL_TYPE_STANDARD = 0,				///< Standard totaliser
	TOTAL_TYPE_STRILISATION = 1,			///< for sterilization , F0 and P0
	TOTAL_TYPE_MAX_NUMBER	///< Max number of totals types						
} T_TOTAL_TYPES;
// ANALOGUE INPUT ENUMS **************************************
/// Enum for the various CJCompensation methods
typedef enum {
	AIN_CJC_INTERNAL_AUTO, AIN_CJC_EXT_ZERO_DEG_C, AIN_CJC_EXT_SPEC_TEMP, AIN_CJC_EXT_INPUT
} T_AIN_CJCOMP_METH;
// Screen Designer enums
/// Enum for the buffering types
typedef enum {
	lbtUnbuffered, lbtDoubleBuffered
} T_LYT_BUFF_TYPE;
// Communications configuration definitions
//// ********************************************************************
//// ************************SERIAL PORT FIELDS**************************
//// ********************************************************************
// Serial port baud rate
typedef enum {
	BD_2400 = 0, BD_4800, BD_9600, BD_19200, BD_38400, BD_56700, BD_115200
} CONFIG_BAUD_RATE;
// Serial port byte options
typedef enum {
	N_8_1 = 0, E_8_1, O_8_1, N_8_2
} CONFIG_BYTE_OPTIONS;
// Communications port
typedef enum {
	PORT_SERIAL = 0, PORT_ETHER
} CONFIG_COMMS_PORT;
//// ********************************************************************
//// ************************MODBUS TYPE FIELDS**************************
//// ********************************************************************
typedef enum {
	PR_MODBUS = 0, PR_MODBUS_X
} CONFIG_MODBUS_PROTOCOL;
/// Enum for the modbus master's slave transaction types
typedef enum {
	mttIN, mttOUT
} T_MODBUS_TRANSACTION_TYPE;
/// Enum for modbus master's slave input data types
typedef enum {
	midSHORT, midUSHORT, midFLOAT
} T_MODBUS_INS_DATA_TYPE;
/// Enum for the modbus master's slave map
typedef enum {
	mmtCOIL_STATUS_1, mmtINPUTS_STATUS_2, mmtHOLDING_REGISTERS_3, mmtINPUT_REGISTERS_4
} T_MODBUS_MAP_TYPES;
/// Digital IO card operation types
typedef enum {
	dtInput = 0, dtOutput, dtPulseInput
} T_DIGIO_TYPES;
/// Enums for the various types of message groups
typedef enum {
	mfAlarm = 0x01,
	mfSystem = 0x02,
	mfDiagnostic = 0x04,
	mfSecurity = 0x08,
	mfUser = 0x10,
	mfSMTP = 0x20,
	mfFTP = 0x40,
	mfP2P = 0x80,
	mfAll = mfAlarm | mfSystem | mfDiagnostic | mfSecurity | mfUser
} T_MESSAGE_FILTER;
//// ********************************************************************
//// *********************EVENT CAUSE/EFFECT FIELDS**********************
//// ********************************************************************
/// Enums for the various types of event causes
typedef enum {
	ectAlarm = 0,
	ectTotaliser,
	ectDigitalInput,
	ectTCBurnOut,
	ectScheduledEvent,
	ectUserCounters,
	ectMaxMins,
	ectSystem,
	ectUserAction,
	ectBatch,
	ectTUS,
	ectAMS2750Timers,
	ectTCHealthMonitor,
	ectInstantCause,	// Not a configurable cause but used to trigger an event by other means
	ectMaxTypes			// Always at end
} T_EVENT_CAUSE_TYPE;
/// Enum used for the various types of scheduled event
typedef enum {
	sesOnce, sesInterval, sesSpecDays, sesMonthEnd
} T_SCHED_EVENT_SUBTYPE;
// Enum for ectSystem subtype, must correspond with IDS_CFG_EVENT_CAUSE_SYSTEM_SUB_TYPE_LIST in RC file
typedef enum {
	ecsPowerOn = 0,				///< Power on cause
	ecsSetupChange,				///< Setup changed cause
	ecsIntMemLo,
	ecsExpMemLo,
	ecsFTPMemLo
} T_SYSTEM_EVENT_SUBTYPE;
// Enum for ectUserAction subtype, must correspond with IDS_CFG_EVENT_CAUSE_USER_ACTION_SUB_TYPE_LIST in RC file
typedef enum {
	ecuMarkChart = 0,			///< User Mark Chart Cause
	ecuHotButton1,				//Hot Button
	ecuHotButton2,				//Hot Button
	ecuHotButton3,				//Hot Button
	ecuHotButton4				//Hot Button
} T_USER_EVENT_SUBTYPE;
// Enum for ectAMS2750Timers subtype, must correspond with IDS_CFG_EVENT_CAUSE_AMS2750_TIMERS_SUB_TYPE_LIST in RC file
typedef enum {
	ecaTC_TIMER = 0,		///< TC Timer
	ecaPROCESS_TIMER		///< Process Timer
} T_AMS2750_TIMER_EVENT_SUBTYPE;
// Enum for ectAMS2750Timers alert type, must correspond with IDS_CFG_EVENT_CAUSE_AMS2750_TIMERS_ALERT_TYPE_LIST in RC file
typedef enum {
	eatWarning = 0,			///< Timer Warning Cause
	eatExpired				///< Timer Expired Cause
} T_AMS2750_TIMER_EVENT_ALERT_TYPE;
/// Enums for the various types of event effects
typedef enum {
	eetMarkChart,
	eetLogging,
	eetTotaliser,
	eetDigitalOutput,
	eetAlarmAck,
	eetEmailEvent,
	eetScreenChange,
	eetPrintScreen,
	eetCounters,
	eetMaxMins,
	eetChartControl,
	eetClearMessages,
	eetDelayedEvent,
	eetTimers,
	eetSound,
	eetDisplayDialog,
	eetBatch,
	eetReports,
	eetUpdateTabDisp,
	eetEnterReplayScreen,
	eetExitReplayScreen,
	eetChartSpeed //E528446
} T_EVENT_EFFECT_TYPE;
/// Enums for the various types of email event effects
typedef enum {
	eeeAUTO, eeeSINGLE_LINE_USER, eeeMULTI_LINE_USER
} T_EMAIL_EVENT_EFFECT_TYPE;
/// Enums for the various types of counter event effects
typedef enum {
	ceeUSER, ceeHARDWARE, ceeEVENTS, ceeDIGITAL_INPUTS, ceeRELAY_OUTPUTS, ceeALARMS
} T_COUNTER_EVENT_EFFECT_TYPE;
/// Enums for the various types of chart control event effects
typedef enum {
	ccePAUSE, cceSTOP, cceRESUME, cceCLEAR, ccePREFILL
} T_CHART_CONTROL_EVENT_EFFECT_TYPE;
/// Enums for the various types of sound events
typedef enum {
	sndSTART_SOUND, sndSTOP_SOUND
} T_SOUND_EVENT_SUBTYPE;
/// Enums for the various types of sound play modes
typedef enum {
	spmCONTINUOUS, spmSINGLE_SHOT
} T_SOUND_PLAY_MODE;
/// Enums for the various types of mark chart modes
typedef enum {
	mcmUSER_DEFINED, mcmUSE_PRESET
} T_MARK_CHART_MODE;
/// Enums for the various types of batch event
typedef enum {
	besSTART, besSTOP, besPAUSE
} T_BATCH_EVENT_SUBTYPE;
/// Enums for the various types of TUS event
typedef enum {
	tusSTART, tusSTOP, tusSOAK_STARTED, tusSTABILITY_ACHIEVED, tusSOAK_COMPLETE,
} T_TUS_EVENT_SUBTYPE;
/// Enums for the various types of pen selection
typedef enum {
	epsINDIVIDUAL_SELS, epsPEN_GROUP, epsALL_PENS
} T_EVENT_PEN_SELECTION;
/// Enums for the chart group/all selection
typedef enum {
	ecgALL_GROUPS, ecgINDIVIDUAL_GROUP
} T_EVENT_CHART_GROUP_SELECTION;
typedef enum {
	pptNoFilter, pptTotalisers, pptLogging, pptAlarms, pptLatchedAlarms
} T_PEN_PICKER_TYPES;
/// Enum for the printscreen subtypes
typedef enum {
	pcePRINTER, pceEXTERNAL_MEDIA
} T_PRINT_SCREEN_EVENT_EFFECT_DEVICE_TYPES;
/// Enum for the screen event subtypes
typedef enum {
	seeCHANGE_SCREEN, seeCHANGE_BACKLIGHT,
} T_SCREEN_EVENT_EFFECT_DEVICE_TYPES;
//// ********************************************************************
//// ****************************LOGGING FIELDS**************************
//// ********************************************************************
/// Enums for the various types of logging rate units
typedef enum {
	lruMilliseconds, lruSeconds, lruMinutes, lruHours
} T_LOG_RATE_UNITS;
/// Enums for the various types of logging rate units
typedef enum {
	lmr2Hertz, lmr5Hertz, lmr10Hertz, lmr50Hertz
} T_LOG_MS_RATES;
/// Enums for the various languages
typedef enum {
	lngEnglish,
	lngEngUS,
	lngFra,
	lngGer,
	lngIta,
	lngSpa,
	lngBraz,
	lngPol,
	lngHung,
	lngSlo,
	lngCze,
	lngTurk,
	lngRom,
	lngRus,
	lngPor,
	lngGrk,
	lngBulg, //kiran
	//#if LangKorean == 1
	lngKor,
	//#endif
	//#if LangChinese == 1
	lngChin,
	//#endif
	//#if LangJapanese == 1
	lngJap,
	//#endif
	lngMaxLangs
} T_LANGUAGES;
/// Enums for the demoboard options
typedef enum {
	dboNO_SIMULATE, dboSIMULATE_IF_NO_BOARD_FITTED, dboSIMULATE_ALWAYS
} T_DEMOBOARD_OPTIONS;
/// Batch Field Locations
typedef enum {
	bflNAME, bflUSER_ID, bflDESCRIPTION, bflLOT_NO, bflCOMMENT
} T_BATCH_FIELD_LOCATIONS;
//// ********************************************************************
//// ****************************REPORT FIELDS***************************
//// ********************************************************************
/// Enums for the various types of special reports
typedef enum {
	rtSingle,					///< Instant report
	rtContinuous				///< Report built up over time
} T_REPORT_TYPE;
/// Enums for the types of reports supported
typedef enum {
	rsstSingleReport,	///< General data item single output selection report
	rsstCalibrationReport,	///< Special single report recorder calibration report
	rsstFUSReport		///< Special single Furnance Uniformity Survey report
} T_REPORT_SINGLE_SUB_TYPES;
/// Enums for the types of reports supported
typedef enum {
	rcstBufferedReport,		///< General data item continuous selection report
	rcstBatchReport,		///< Special continuous report to handle batch data
} T_REPORT_CONTINUOUS_SUB_TYPES;
/// Enum used for the various types of report trigger
typedef enum {
	rstMANUAL, rstSCHEDULE, rstEVENT, rstBATCH
} T_REPORT_SINGLESHOT_TRIGGER_TYPE;
/// Enum used for the various types of report style
typedef enum {
	rssNORMAL, rssBATCH, rssTUS
} T_REPORT_SINGLESHOT_STYLE_TYPE;
/// Enums for the various types of report timings
typedef enum {
	rftNONE, rftHOUR, rftDAY, rftWEEK, rftMONTH, rftALL,		// only used for message lists
	rftCURRENT = rftALL		// only used on maxmins and totals
} T_REPORT_FIELD_TIMINGS;
/// Enums for the various types of counter
typedef enum {
	ctbALARMS = 0x01, ctbUSER = 0x02, ctbEVENT = 0x04, ctbDigIn = 0x08, ctbRelayOut = 0x10, ctbPulse = 0x20
} T_COUNTER_TYPES_BITMASK;
/// Enums for the tabular display update methods
typedef enum {
	tbumEVENT, tbumPERIODIC
} T_TAB_DISP_UPDATE_METHOD_BITMASK;
/// Enums for the AMS2750 modes
typedef enum {
	AMS2750_NONE, AMS2750_PROCESS, AMS2750_TUS
} T_AMS2750_MODE;
#endif // __V6TYPES_H__

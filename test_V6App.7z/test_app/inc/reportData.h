/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Processing
/// @n Filename: reportData.h
/// @n Desc:	 Data structures for NV report information for processing
///				 
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4] $
//
// ****************************************************************
#ifndef __REPORTDATA_H__
#define __REPORTDATA_H__
#include "Defines.h"
const int REPORT_SIGNATURE = 0xAD556D; ///< Report signature, change to invalidate report structure on upgrade if required
typedef enum {
	WORKING_REPORT = 0,				///< Working report instance (this hour, day week etc..)
	LAST_REPORT = 1,				///< Last completed report ( previous hour, day week etc )
	REPORT_HISTORY = 2				///< Report history array
} T_REPORT_HISTORY;
typedef enum {
	RP_HOUR = 0, RP_DAY = 1, RP_WEEK = 2, RP_MONTH = 3, RP_MAX = 4
} T_REPORT_PERIOD;
// Structure to hold values for a single report
typedef struct {
	LONGLONG startTD;				///< Start time and date of report
	float maxVal;					///< Maximum value of the period
	float minVal;					///< Minimum value over the period
	LONGLONG maxTime;				///< time of maximum value
	LONGLONG minTime;				///< time of minimum value
	float AveTotal;					///< average total for a periof
	ULONG AveReads;					///< number of readings in average
	float totalVal;					///< total of period
} T_PEN_REPORT_DETAIL;
// Complete Pen report structure
typedef struct {
	T_PEN_REPORT_DETAIL period[RP_MAX];	///< Report period , hour, day, week and month
} T_PEN_REPORT_SET;
typedef struct {
	T_PEN_REPORT_SET set[REPORT_HISTORY];	///< Report sets for working and previous
} T_PEN_REPORT;
// Pen report structure
typedef struct {
	ULONG signature;						///< Report signature, used to invalidate report structure on a change
	int hour;								///< Current hour being reported on
	int day;								///< Current day being reported on
	int month;								///< Current month being reported on
	int weekDay;							///< Current weekday being reported on
	int startWeekDay;						///< Current start of week
	T_PEN_REPORT pen[V6_MAX_PENS];			///< Report data for each pen
} T_REPORT_DATA;
#endif /// __REPORTDATA_H__

#ifndef __TRACE_H_
#define __TRACE_H_
/*
 _NO_qDebug - Use this precompiler option to minimize compiled application size.
 TraceReadINI - From the applications ini file reads control values.
 I.E.
 [qDebug]
 ;Specific log name and path
 PathAndFileName=C:\A_TEST\mylog.txt
 [qDebug]
 ;Use the default path and name
 PathAndFileName=C:\A_TEST\mylog.txt
 If you use TraceReadINI then you do not have to use TraceStart.
 TraceStart - Tracing defaults to TraceStop. A call to TraceStart will start tracing
 until end of execution or TraceStop. The log will default to the directory of the application 
 that called it. You can over ride the default behavior by passing in your own path, file name and
 file name extension. The existing log is always numerically archived. If more than one
 instance of an application is executing, then susequent applications will have the post fix
 'QLibrary' in the log entries.
 Trace - Works just like qDebug or printf. The first parameter can be any length, the sum
 of the additional parameters is limited to 1024 characters.
 TraceSuspend - Default is false. When true logging is suspended until set back to false.
 TraceStop - The current log is closed. To continue logging, explicitly call TraceStart.
 In the event of multiple programs writing to the same log, the log will not be closed. The next
 call to TraceStart will append to the existing log.
 TraceClockCapture - Captures the current clock value.
 TraceClockDuration - Writes the number of seconds passed since the last TraceClockCapture.
 TraceFlush - Default is true. You can turn it off to increase performance, but if the 
 application fails you may not get the last several dozen statements logged written to the 
 log file.
 TraceWithTime - Default is true. Causes the Trace statement to output the time of each
 trace statement. The ThreadID is as well will be output. The timestamp is of the 
 [dd-mm-yyy hr:mn:sec TId] format.

 */
//#pragma message( "Compiling " __FILE__ ) 
//#pragma message( "Last modified on " __TIMESTAMP__ ) 
/*
 #ifdef TRACE_ENABLE
 #pragma message("Trace. Tracing to a log will not be available in the exe.\n")
 #else
 #pragma message("Trace. Tracing to a log will be available in the exe.\n")
 #pragma message("Make sure you turn it on in the applications ini file with TraceReadINI\n")
 #pragma message("or a direct call to TraceStart.\n")
 #endif
 */
/*
 #ifdef _UNICODE
 #pragma message("..\n")
 #pragma message("_UNICODE option is defined.\n")
 #endif
 */
#include "Defines.h"
#include "TraceDefines.h"
#define TRACEMSGAPI
/* Functions that are exposed */
#ifdef __cplusplus
extern "C" {
#endif
TRACEMSGAPI void TraceStart(TCHAR *pszPathName);
TRACEMSGAPI void Trace(const CHAR *pszasprintf, ...);
TRACEMSGAPI void TraceEx(T_ENUMERRORTYPE type, CHAR *pszFilename, CHAR *pszMethodname, int lineno, DWORD dwmodule,
		const CHAR *pszasprintf, ...);
TRACEMSGAPI void TraceWithTime(bool bValue);
TRACEMSGAPI void TraceSuspend(bool bTrueToSuspend);
TRACEMSGAPI void TraceStop();
TRACEMSGAPI void TraceClockCapture(CHAR *pszComment = NULL);
TRACEMSGAPI void TraceClockDuration(CHAR *pszComment = NULL);
TRACEMSGAPI void TraceFlush(bool bForceFlush);
TRACEMSGAPI void TraceReadINI();
#ifdef	__cplusplus
} /* Assume C declarations for C++ */
#endif	/* __cplusplus */
/*Private functions */
BOOL TraceCheck(DWORD dwmodule, BOOL *pblogfile);
BOOL ReadRegistryValue();
void ArchiveLastLog(QString strLogPathName);
//Tracer class
class CTracer {
public:
	QString m_szFileName;
	QString m_szFunctionName;
	int m_iLineNo;
	T_ENUMERRORTYPE m_enumLogLevel;
	CHAR m_szBuffer[1024];
    void OutputDebugTrace(DWORD dwModule,const char *szMessage, ...) {
		CHAR szBody[MAX_MESSAGE_LEN / 2] = { "0" };
		CHAR szfile[MAX_MESSAGE_LEN / 4] = { "0" };
		CHAR szfunction[MAX_MESSAGE_LEN / 4] = { "0" };
		va_list args;
		va_start(args, szMessage);
#if _MSC_VER < 1400 
		vsprintf(szBody, szMessage, args);
#else
		vsprintf_s(szBody, sizeof(szBody), szMessage, args);
#endif
		va_end(args);
		//
#if (defined (UNDER_CE) || defined (_UNICODE))
		size_t _PtNumOfCharsConverted = 0;
				
		
		TraceEx(m_enumLogLevel,szfile,szfunction,m_iLineNo,dwModule,"%s",szBody);
#else
		///TODO indexOf equivalent of getbuffer in qstring
		TraceEx(m_enumLogLevel, (char*) m_szFileName.toLocal8Bit().data(),
				(char*) m_szFunctionName.toLocal8Bit().data(), m_iLineNo, dwModule, "%s", szBody);
#endif
		//Reset
		m_szFileName = QString("-");
		m_szFunctionName = QString("-");
		m_iLineNo = 0;
		m_enumLogLevel = TYPE_INFO;
	}
	virtual ~CTracer() {
		TraceStop();
	}
	static CTracer* Instance() {
		if (NULL == m_pInstance) {

		}
		return m_pInstance;
	}
	static CTracer* Instance(TCHAR *szlogFileName) {
		if (NULL == m_pInstance) {
			m_pInstance = new CTracer(szlogFileName);
		}
		return m_pInstance;
	}
protected:
	CTracer(TCHAR *szlogFileName) : m_szFileName(QString("fl:")), m_szFunctionName(QString("fn:")), m_iLineNo(0), m_enumLogLevel(
			TYPE_INFO) {
		TraceStart(szlogFileName);
	}
private:
	static CTracer *m_pInstance;
};
extern TRACEMSGAPI CTracer *g_pTracer;
#endif //__TRACE_H_

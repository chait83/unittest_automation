/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	Configuration System
/// @n Filename:	ScrnDesCfgMgr.h
/// @n Description: Definition for the CScrnDesCfgMgr class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 47	Stability Project 1.44.2.1	7/2/2011 5:01:05 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 46	Stability Project 1.44.2.0	7/1/2011 4:27:31 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 45	V6 Firmware 1.44		4/6/2009 3:53:39 PM	Nilesh(HAIL)	CR
//		3093: Display Chart control Start Stop Messages.
// 44	V6 Firmware 1.43		9/23/2008 3:09:32 PM	Build Machine 
//		AMS2750 Merge
// $
//
// **************************************************************************
#pragma once
#include <memory>
#include <QString>
#include "BaseCfgMgr.h"
#include "ConfigSystemData.h"
#include "AddScreenData.h"
class CLayoutItem;
class CWidget;
class CTemplate;
class CScreen;
//**CScrnDesCfgMgr*********************************************************************
///
/// @brief Singleton class responsible for processing calls for a particular setup item and subsequently
///	creating the required configuration heirarchy
/// 
/// Singleton class responsible for processing calls for a particular setup item and subsequently
///	creating the required configuration heirarchy. Currently this class wil handle the creation of
/// setup heirarchies for the screen layout.
///
//****************************************************************************
class CScrnDesCfgMgr: public CBaseCfgMgr {
	friend void CAddScreenData::UpdateData(CConfigInterface *pkThisItem);
public:
	// Destructor
	~CScrnDesCfgMgr(void);
	// Singleton Accessor/Creator
	static CScrnDesCfgMgr* Instance();
	// Loads the titles
	void LoadStrings();
	// Method that creates an bar object config hierarchy
	CConfigBranch* CreateScaleObjConfig(T_BASEOBJECT *pkBaseObject, CWidget *pkParentWidget);
	// Method that creates an bar object config hierarchy
	CConfigBranch* CreatePenPointersObjConfig(T_BASEOBJECT *pkBaseObject, CWidget *pkParentWidget);
	// Method that creates an tabular display object config hierarchy
	CConfigBranch* CreateTabularDisplayObjConfig(T_BASEOBJECT *pkBaseObject, CWidget *pkParentWidget);
	// Method that creates a TUS config hierarchy
	CConfigBranch* CreateTUSObjConfig(T_BASEOBJECT *pkBaseObject, CWidget *pkParentWidget);
	// Method that creates an bar object config hierarchy
	CConfigBranch* CreateBarObjConfig(T_BASEOBJECT *pkBaseObject, CWidget *pkParentWidget);
	// Method that creates a button object config hierarchy
	CConfigBranch* CreateButtonObjConfig(T_BASEOBJECT *pkBaseObject, CWidget *pkParentWidget);
	// Method that creates an bar object config hierarchy
	CConfigBranch* CreateAlarmMrkrObjConfig(T_BASEOBJECT *pkBaseObject, CWidget *pkParentWidget);
	// Method that creates an Digital object config hierarchy
	CConfigBranch* CreateDigObjConfig(T_BASEOBJECT *pkBaseObject, CWidget *pkParentWidget);
	// Method that creates an Text object config hierarchy
	CConfigBranch* CreateTextObjConfig(T_BASEOBJECT *pkBaseObject, CLayoutItem *pkLayoutItem);
	// Method that creates an chart object config hierarchy
	CConfigBranch* CreateChartObjConfig(T_BASEOBJECT *pkBaseObject, CWidget *pkParentWidget);
	// Method that creates a circular chart object config hierarchy
	CConfigBranch* CreateCircularChartObjConfig(T_BASEOBJECT *pkBaseObject, CWidget *pkParentWidget);
	// Method that creates a bitmap object config hierarchy
	CConfigBranch* CreateBitmapObjConfig(T_BASEOBJECT *pkBaseObject, CWidget *pkParentWidget);
	// Method that creates a widget config heirarchy 
	CConfigBranch* CreateWidgetConfig(CWidget *pkWidget);
	// Method that creates a widget channel map only config heirarchy 
	CConfigBranch* CreateWidgetChannelMapConfig(CWidget *pkWidget);
	// Method that creates a template config hierarchy for a single template 
	CConfigBranch* CreateTemplateConfig(CTemplate *pkTemplate);
	// Method that creates a screen config heirarchy for a single or multiple screens 
	CConfigBranch* CreateScreenConfig(CScreen *pkScreen);
	// Method that creates a screen settings config heirarchy
	CConfigBranch* CreateSettingsConfig();
	// Method that creates a screen apparance config heirarchy
	CConfigBranch* CreateAppearanceConfig();
	// Method that refreshes the data for a particular branch of a configuration menu, usually 
	// following a change that requires the tree structure to be regenerated because it is different
	CConfigInterface* RefreshConfigTree(CConfigItem *pkModifiedItem, CLayoutItem *pkCurrLayoutItem);
	// Method that refreshes the data for a particular branch of a configuration menu, usually 
	// following a change that requires the tree structure to be regenerated because it is different
	CConfigInterface* RefreshConfigTree(CConfigItem *pkModifiedItem, CLayoutItem *pkCurrLayoutItem,
			const bool bEDIT_CHANNEL_MAP_DATA);
	// Method that updates an individual screen within a multiple screen heirarchy
	CConfigBranch* RefreshScreenConfigTree(CConfigItem *pkModifiedItem);
	// Method that commits screen designer changes to the CMM
	void CommitChanges();
	// Method that commits recorder setup changes to the CMM
	void DiscardChanges();
	// return non process screen types...
	static QString GetNPScrnTypes();
	static bool m_bIsScreenDesigner;
	// Public Screen Key Names
	static const QString ms_strSCREEN_TITLE_KEY;
	// Layout Settings Key Names
	static const QString ms_strSETTINGS_KEY;
	static const QString ms_strSETTINGS_ROTATE_ENABLED_KEY;
	static const QString ms_strSETTINGS_ROTATE_SCREENS_KEY;
	static const QString ms_strSETTINGS_ROTATE_INTERVAL_KEY;
	static const QString ms_strSETTINGS_MANUAL_INTERVENTION_KEY;
	static const QString ms_strSETTINGS_ALARM_SCREEN_ENABLED_KEY;
	static const QString ms_strSETTINGS_ALARM_SCREEN_NAME_KEY;
	static const QString ms_strSETTINGS_REPLAY_SCREEN_TIMEOUT_EN_KEY;
	static const QString ms_strSETTINGS_REPLAY_SCREEN_TIMEOUT_KEY;
	static const QString ms_strSETTINGS_HIDE_STATUS_BAR_KEY;
	static const QString ms_strSETTINGS_HIDE_STATUS_BAR_TIMEOUT_KEY;
	static const QString ms_strSETTINGS_HOUR_TIMESTAMPS_KEY;
	//static const QString  ms_strSETTINGS_SHOW_NONPROCESSSCREEN_KEY;
	//added by nilesh for Displaying Chart Start/Stop Messages
	//[
	static const QString ms_strSETTINGS_SHOW_START_STOP_MESSAGES_KEY;
	//]
	static const QString ms_strHOTBUTTON_TITLE_KEY;
	static const QString ms_strHOTBUTTON_NAME_KEY;
	static const QString ms_strHOTBUTTON_ENABLED_KEY;
	// Layout Appearance Key Names
	static const QString ms_strAPPEARANCE_KEY;
	static const QString ms_strAPPEARANCE_ALM_IN_NACK_FCOL_KEY;
	static const QString ms_strAPPEARANCE_ALM_IN_NACK_BCOL_KEY;
	static const QString ms_strAPPEARANCE_ALM_IN_ACK_FCOL_KEY;
	static const QString ms_strAPPEARANCE_ALM_IN_ACK_BCOL_KEY;
	static const QString ms_strAPPEARANCE_ALM_OUT_NACK_FCOL_KEY;
	static const QString ms_strAPPEARANCE_ALM_OUT_NACK_BCOL_KEY;
	static const QString ms_strAPPEARANCE_ALM_OUT_FCOL_KEY;
	static const QString ms_strAPPEARANCE_ALM_OUT_BCOL_KEY;
	static const QString ms_strAPPEARANCE_ALM_OVERVIEW_FCOL_KEY;
	static const QString ms_strAPPEARANCE_ALM_OVERVIEW_BCOL_KEY;
	static const QString ms_strAPPEARANCE_CHART_NORMAL_FCOL_KEY;
	static const QString ms_strAPPEARANCE_CHART_NORMAL_BCOL_KEY;
	static const QString ms_strAPPEARANCE_CHART_ALM_NORMAL_FCOL_KEY;
	static const QString ms_strAPPEARANCE_CHART_ALM_NORMAL_BCOL_KEY;
	static const QString ms_strAPPEARANCE_CHART_REPLAY_FCOL_KEY;
	static const QString ms_strAPPEARANCE_CHART_REPLAY_BCOL_KEY;
	static const QString ms_strAPPEARANCE_CHART_ALM_REPLAY_FCOL_KEY;
	static const QString ms_strAPPEARANCE_CHART_ALM_REPLAY_BCOL_KEY;
	static const QString ms_strAPPEARANCE_CHART_TEXT_FCOL_KEY;
	static const QString ms_strAPPEARANCE_CHART_TEXT_BCOL_KEY;
	// BASE OBJECT
	// Base Object key names
	static const QString ms_strLYT_IS_ADV_DRAW_KEY;
	static const QString ms_strLYT_IS_BUFF_KEY;
	static const QString ms_strLYT_IS_TRANS_KEY;
	static const QString ms_strLYT_ALPHA_BLEND_KEY;
	static const QString ms_strLYT_PRI_DIR_KEY;
	static const QString ms_strLYT_IS_PERM_KEY;
	static const QString ms_strLYT_PERM_VALID_KEY;
	static const QString ms_strLYT_IS_BKG_KEY;
	static const QString ms_strLYT_FORE_COLOUR_KEY;
	static const QString ms_strLYT_FIX_FORE_COLOUR_KEY;
	static const QString ms_strLYT_BACK_COLOUR_KEY;
	static const QString ms_strLYT_FIX_BACK_COLOUR_KEY;
	// Common Key Names
	static const QString ms_strLYT_ORIENTATION_KEY;
	// Rect Key Names
	static const QString ms_strRECT_KEY;
	static const QString ms_strRECT_LEFT_KEY;
	static const QString ms_strRECT_TOP_KEY;
	static const QString ms_strRECT_RIGHT_KEY;
	static const QString ms_strRECT_BOTTOM_KEY;
	// Border Key Names
	static const QString ms_strBORDER_KEY;
	static const QString ms_strBORDER_STYLE_KEY;
	static const QString ms_strBORDER_WIDTH_KEY;
	static const QString ms_strBORDER_COL_KEY;
	static const QString ms_strBORDER_USED_KEY;
	// Font Key Names
	static const QString ms_strFONT_KEY;
	static const QString ms_strFONT_HEIGHT_KEY;
	static const QString ms_strFONT_FACE_KEY;
	static const QString ms_strFONT_QUALITY_KEY;
	static const QString ms_strFONT_WEIGHT_KEY;
	// Example Bar key names
	static const QString ms_strEX_BAR_TITLE_KEY;
	// Bar object Key names
	static const QString ms_strBAR_OBJ_TITLE_KEY;
	static const QString ms_strBAR_TOP_LIMIT_KEY;
	static const QString ms_strBAR_BOTTOM_LIMIT_KEY;
	static const QString ms_strBAR_GRADFILL_CLR_KEY;
	static const QString ms_strBAR_TYPE_KEY;
	static const QString ms_strBAR_STYLE_KEY;
	static const QString ms_strBAR_LEVELCAP_KEY;
	static const QString ms_strBAR_LEVELCAP_COL_KEY;
	static const QString ms_strBAR_LIMITS_KEY;
	static const QString ms_strBAR_BASEPOINT_KEY;
	static const QString ms_strBAR_BREAKPONT_AMBER_KEY;
	static const QString ms_strBAR_BREAKPONT_GREEN_KEY;
	static const QString ms_strBAR_BREAKPONT_DYNGREEN_KEY;
	static const QString ms_strBAR_BREAKPONT_DYNAMBER_KEY;
	static const QString ms_strBAR_FIX_ABOVE_CLR_KEY;
	static const QString ms_strBAR_FIX_BELOW_CLR_KEY;
	static const QString ms_strBAR_FIX_BOTTOMLIMIT_KEY;
	static const QString ms_strBAR_FIX_TOPLIMIT_KEY;
	static const QString ms_strBAR_GRAD_START_CLR_KEY;
	static const QString ms_strBAR_GRAD_END_CLR_KEY;
	static const QString ms_strBAR_GRAD_START_END_CLR_KEY;
	static const QString ms_strBAR_MRKR_CLR_KEY;
	static const QString ms_strBAR_RESET_MRKRS_KEY;
	static const QString ms_strBAR_SHOW_MN_MRKR_KEY;
	static const QString ms_strBAR_SHOW_MX_MRKR_KEY;
	static const QString ms_strBAR_SHOW_MXMN_MRKR_KEY;
	static const QString ms_strBAR_SOLID_ABOVE_CLR_KEY;
	static const QString ms_strBAR_SOLID_BELOW_CLR_KEY;
	static const QString ms_strBAR_MXMN_MRKR_KEY;
	static const QString ms_strBAR_ERR_INDICATOR_KEY;
	static const QString ms_strBAR_OVRNG_CLR1_KEY;
	static const QString ms_strBAR_OVRNG_CLR2_KEY;
	static const QString ms_strBAR_UNDERRNG_CLR1_KEY;
	static const QString ms_strBAR_UNDERRNG_CLR2_KEY;
	static const QString ms_strBAR_INVALIDRDNG_CLR1_KEY;
	static const QString ms_strBAR_INVALIDRDNG_CLR2_KEY;
	static const QString ms_strBAR_UPSC_BURNOUT_CLR1_KEY;
	static const QString ms_strBAR_UPSC_BURNOUT_CLR2_KEY;
	static const QString ms_strBAR_DNSC_BURNOUT_CLR1_KEY;
	static const QString ms_strBAR_DNSC_BURNOUT_CLR2_KEY;
	static const QString ms_strSCALE_OBJ_TITLE_KEY;
	static const QString ms_strSCALE_AUTO_SCALE_KEY;
	static const QString ms_strSCALE_BASELINE_COL_KEY;
	static const QString ms_strSCALE_BASELINE_KEY;
	static const QString ms_strSCALE_FULLWIDTH_KEY;
	static const QString ms_strSCALE_GRADS_COL_KEY;
	static const QString ms_strSCALE_GRADS_DIR_KEY;
	static const QString ms_strSCALE_LABEL_LIMITS_KEY;
	static const QString ms_strSCALE_LABEL_MAJORS_KEY;
	static const QString ms_strSCALE_LABEL_POSITION_KEY;
	static const QString ms_strSCALE_LABELS_KEY;
	static const QString ms_strSCALE_LEFT_JUSTIFY_KEY;
	static const QString ms_strSCALE_MAJOR_GRADS_KEY;
	static const QString ms_strSCALE_MAJOR_LENGTH_KEY;
	static const QString ms_strSCALE_MINOR_GRADS_KEY;
	static const QString ms_strSCALE_MINOR_LENGTH_KEY;
	static const QString ms_strSCALE_LIMIT_FONT_HEIGHT_KEY;
	static const QString ms_strSCALE_MAJOR_FONT_HEIGHT_KEY;
	static const QString ms_strSCALE_FIXGRADS_CLR_KEY;
	static const QString ms_strSCALE_GRADS_CLR_KEY;
	static const QString ms_strSCALE_FIXBASELINE_CLR_KEY;
	static const QString ms_strSCALE_BASELINE_CLR_KEY;
	static const QString ms_strSCALE_FIX_NUMFORMAT_KEY;
	static const QString ms_strPENPOINTERS_OBJ_TITLE_KEY;
	static const QString ms_strPENPTRS_FGALARM_COL_KEY;
	static const QString ms_strPENPTRS_FLASH_FG_ONALARM_KEY;
	static const QString ms_strPENPTRS_FIX_FG_ALARM_COL_KEY;
	static const QString ms_strPENPTRS_HEIGHT_KEY;
	static const QString ms_strTAB_DISP_OBJ_TITLE_KEY;
	static const QString ms_strTAB_DISP_FGALARM_COL_KEY;
	static const QString ms_strTAB_DISP_FLASH_FG_ONALARM_KEY;
	static const QString ms_strTAB_DISP_FIX_FG_ALARM_COL_KEY;
	static const QString ms_strTUS_OBJ_TITLE_KEY;
	static const QString ms_strBUTTON_OBJ_TITLE_KEY;
	static const QString ms_strBUTTON_TEXT_TITLE_KEY;
	static const QString ms_strALARMMRKR_OBJ_TITLE_KEY;
	static const QString ms_strALARM_INALARM_NOTACK_KEY;
	static const QString ms_str_ALARM_HEIGHT_KEY;
	static const QString ms_strALARM_INALARM_ACK_KEY;
	static const QString ms_strALARM_OUTALARM_NOTACK_KEY;
	static const QString ms_strALARM_HIDE_INACTIVE_ALARM_KEY;
	static const QString ms_strALARM_USE_GLOBAL_FLASHCLR_KEY;
	static const QString ms_strALARM_INALARM_NOACK_FLASHCLR_KEY;
	static const QString ms_strALARM_INALARM_ACK_FLASHCLR_KEY;
	static const QString ms_strALARM_OUTALARM_NOACK_FLASHCLR_KEY;
	static const QString ms_strALARM_OUTALARM_FLASHCLR_KEY;
//digital
	static const QString ms_strDIGITAL_OBJ_TITLE_KEY;
	static const QString ms_strDIGITAL_FLASH_FG_ONALARM_KEY;
	static const QString ms_strDIGITAL_FLASH_BG_ONALARM_KEY;
	static const QString ms_strDIGITAL_FIX_NUMFORMAT_KEY;
	static const QString ms_strDIGITAL_CHG_FG_ONALARM_KEY;
	static const QString ms_strDIGITAL_FG_ALARM_COL_KEY;
	static const QString ms_strDIGITAL_ENABLE_ALARM_KEY;
//Text
	static const QString ms_strTEXT_OBJ_TITLE_KEY;
	static const QString ms_strTEXT_FIXTEXT_KEY;
	static const QString ms_strTEXT_WORDWRAP_KEY;
	static const QString ms_strTEXT_ISTAG_KEY;
	static const QString ms_strTEXT_ISDESC_KEY;
	static const QString ms_strTEXT_ISUNITS_KEY;
	static const QString ms_strTEXT_CENTER_KEY;
	static const QString ms_strTEXT_OFFSET_KEY;
	static const QString ms_strTEXT_FIX_TEXT_KEY;
	// Chart Object Key Names
	static const QString ms_strCHART_OBJ_TITLE_KEY;
	static const QString ms_strCHART_OBJ_FIX_ALARM_COL_KEY;
	static const QString ms_strCHART_OBJ_ALARM_COL_KEY;
	static const QString ms_strCHART_OBJ_FIX_MESSAGE_COL_KEY;
	static const QString ms_strCHART_OBJ_MESSAGE_COL_KEY;
	static const QString ms_strCHART_OBJ_FIX_FONT_COL_KEY;
	static const QString ms_strCHART_OBJ_FONT_COL_KEY;
	static const QString ms_strCHART_OBJ_CHART_SPEED_KEY;
	// Circular Chart Object Key Names
	static const QString ms_strCIRC_CHART_OBJ_TITLE_KEY;
	// Widget Key Names
	static const QString ms_strWIDGET_TITLE_KEY;
	static const QString ms_strWIDGET_NAME_KEY;
	static const QString ms_strWIDGET_CATEGORY_KEY;
	static const QString ms_strWIDGET_TYPE_KEY;
	static const QString ms_strWIDGET_CHANNELS_KEY;
	static const QString ms_strWIDGET_PARENT_CHAN_KEY;
	// Template Key Names
	static const QString ms_strTEMPLATE_TITLE_KEY;
	static const QString ms_strTEMPLATE_NAME_KEY;
	static const QString ms_strTEMPLATE_STATUS_BAR_KEY;
	static const QString ms_strTEMPLATE_REPLAY_ORIENTATION_KEY;
	// Screen Key Names
	static const QString ms_strSCREEN_NAME_KEY;
	static const QString ms_strSCREEN_ENABLED_KEY;
	static const QString ms_strSCREEN_TYPE_KEY;
	static const QString ms_strSCREEN_VERTICAL_BARS_KEY;
	static const QString ms_strSCREEN_ROTATE_BARS_KEY;
	static const QString ms_strSCREEN_POINTER_KEY;
	static const QString ms_strSCREEN_ROTATE_SCREEN_KEY;
	static const QString ms_strSCREEN_USE_TEMPLATE_BKG_COL_KEY;
	static const QString ms_strSCREEN_BKG_COL_KEY;
	static const QString ms_strSCREEN_CANNED_PENS_SETUP_KEY;
	static const QString ms_strSCREEN_ADD_SCREEN_KEY;
	static const QString ms_strSCREEN_DELETE_SCREEN_KEY;
	static const QString ms_strSCREEN_USE_GROUP_KEY;
	static const QString ms_strSCREEN_GROUP_SEL_KEY;
	static const QString ms_strSCREEN_GROUP_USE_MAX_MINS_KEY;
	static const QString ms_strSCREEN_GROUP_USE_TOTALS_KEY;
	static const QString ms_strSCREEN_GROUP_USE_SCALES_KEY;
	static const QString ms_strSCREEN_REPLAY_PENS_SETUP_KEY;
	// Screen List Names
	static QString ms_strScreenUseGroupList;
	static QString ms_strGroupList;
#ifndef DOCVIEW
	// Method that loads a new layout
	const bool LoadConfiguration(const QString &rstrFILE_NAME);
#endif
	// Method that saves the current layout
	T_CONFIG_RETURN_VALUE SaveConfiguration(const QString &rstrFILE_NAME) const;
private:
	// Constructor
	CScrnDesCfgMgr(void);
	// Singleton auto pointer
	static std::unique_ptr<CScrnDesCfgMgr> ms_kConfigSysMgr;
	// Method that creates the base object properties config hierarchy
	void CreateBasePropsConfigData(T_BASEOBJECT *pkBaseObject, CConfigBranch *pkParent,
			const bool bINCLUDE_TRANSPARENCY = true, const bool bINCLUDE_COLOURS = true);
	// Method that creates a base object submenu properties config hierarchy
	void CreateBaseSubMenuPropsConfigData(T_BASEOBJECT *pkBaseObject, CConfigBranch *pkParent);
	// Method that creates and adds a TV_RECT heirarchy to a branch
	void SetupRectDetails(T_TV_RECT *ptRect, CConfigBranch *pkParent);
	// Method that creates and adds a T_BORDER heirarchy to a branch
	void SetupBorderDetails(T_BORDER *ptBorder, CConfigBranch *pkParent);
	// Method that creates and adds a T_FONT heirarchy to a branch
	void SetupFontDetails(T_FONT *ptFont, CConfigBranch *pkParent, const QString &rstrMENU_TITLE,
			const bool bWORD_WRAP);
	// Method that creates and adds a channel heirarchy to a branch
	void SetupWidgetChannelDetails(CWidget *pkWidget, CConfigBranch *pkParent);
	// Method that creates a object map leaf
	void CreateObjectChannelMap(T_PBASEOBJECT ptBaseObject, CConfigBranch *pkParent, const QString &rstrTITLE,
			CWidget *pkWidget);
	// Method that sets up the widget channel map data
	void SetupWidgetChannelMapData(CWidget *pkWidget, CConfigBranch *pkParent);
	// Method that creates a screen config heirarchy for an individual screen
	void SetupScreenConfig(CScreen *pkScreen, CConfigBranch *pkParent);
	// Method that creates a Hot Button config heirarchy for an individual screen
	void SetupHotButtonConfig(T_HOTBUTTON *pkHotButton, CConfigBranch *pkParent);
	// Method that gets a title for the widget instance field e.g. pen, analogue etc
	const QString GetWidgetParentInstTitle(CWidget *pkWidget) const;
	// Method that creates an add screen option for a multi screen confg tree
	CConfigItem* CreateAddScreenItem(CConfigBranch *pkParent, const USHORT usSCREEN_COUNT);
	// Method that deletes a selected screen for a multi screen confg tree
	CConfigItem* CreateDeleteScreenItem(CConfigBranch *pkParent, const USHORT usSCREEN_COUNT);
	// Method that turns the screen template list into a non-sequential list, removing the AMS2750 options
	// as necessary
	void MakeScreenTemplateListNonSequential();
	// Base Object List Names
	static QString ms_strBufferingList;
	static QString ms_strZOrderList;
	static QString ms_strBorderStyleList;
	// Font List Names
	static QString ms_strFontFaceList;
	static QString ms_strFontQualityList;
	static QString ms_strFontWeightList;
	static QString ms_strBarGradFillClrList;
	static QString ms_strOrientationList;
	static QString ms_strBarStyleListUpDown;
	static QString ms_strBarStyleListBased;
	static QString ms_strBarTypeList;
	static QString ms_strScaleUpDownList;
	static QString ms_strScaleleftrightList;
	static QString ms_strScaleTopBottomList;
	static QString ms_strScalerightleftList;
	// Chart Object List Names
	static QString ms_strChartObjChartSpeedList;
	// Screen List Names
	static QString ms_strScreenTypeList;
	static QString ms_strNPScreenTypeList;
	static QString ms_strNPMSGScreenTypeList;
	static QString ms_strScreenOrientationList;
	static QString ms_strScreenScaleIndicatorList;
	// List used to hold the screen type list given the current selection of templates
	static QString ms_strCustomScreenTypeList;
	// List used to hold the non process MSG screen type list given the current selection of templates
	static QString ms_strCustomMsgScreenTypeList;
	// Layout Settings Lists
	static QString ms_strScreenList;
	/// Structure used to store rotating screen information 
	T_STRING_PICKER_DATA m_tRotScreenPickerData;
};

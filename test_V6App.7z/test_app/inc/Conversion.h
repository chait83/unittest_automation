/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n Conversion.h
/// @n Header for routines convert temperature and allow bit manipulation.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log:
// 19	Stability Project 1.16.1.1	7/2/2011 4:56:20 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 18	Stability Project 1.16.1.0	7/1/2011 4:27:04 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 17	V6 Firmware 1.16		9/23/2008 3:09:23 PM	Build Machine 
//		AMS2750 Merge
// 16	V6 Firmware 1.15		2/13/2007 2:11:07 PM	Mark Dennison 
//		Maths functions changed to avoid returning any NaN from any function,
//		again to avoid a crash
// 15	V6 Firmware 1.14		2/9/2007 2:05:47 PM	Mark Dennison 
//		Ensure FLT_MAX is recognised in desktop build
// 14	V6 Firmware 1.13		2/8/2007 5:12:12 PM	Mark Dennison 
//		Maths functions changed to return quiet NaN not signalling to avoid
//		crashes. Some functions return 'stars' instead of arrows.
// 13	V6 Firmware 1.12		1/16/2007 5:03:08 PM	Roger Dawson 
//		Added TC and CJC errors to the Error Control code.
// 12	V6 Firmware 1.11		8/15/2006 8:01:56 PM	Andy Kassell	Add
//		scheduled event operational support
// 11	V6 Firmware 1.10		4/7/2006 3:54:33 PM	Andy Kassell	Add
//		additioanl conversions for relative temperature comversion
// 10	V6 Firmware 1.9		3/7/2006 7:44:18 PM	Andy Kassell	Add
//		an Auto dd:hh:mm:ss formatter function
// 9	V6 Firmware 1.8		1/18/2006 6:13:39 PM	Andy Kassell	Add
//		conversion factors
// 8	V6 Firmware 1.7		9/8/2005 4:04:50 PM	Andy Kassell 
//		Correct ALIGN_UP_4 macro to not aligh up another 4 bytes if already
//		on 4 byte boundary 
// 7	V6 Firmware 1.6		8/26/2005 5:30:10 PM	Andy Kassell	Add
//		brackets so calcs can be done inside macros
// 6	V6 Firmware 1.5		7/7/2005 9:27:02 PM	Andy Kassell	Add
//		conversion for log rates to process ticks
// 5	V6 Firmware 1.4		6/23/2005 1:45:31 PM	Andy Kassell	Fix
//		alignment macros
// 4	V6 Firmware 1.3		5/13/2005 3:43:44 PM	Andy Kassell 
//		Move utiltiy.h conversions into this file add new temperature
//		conversions
// 3	V6 Firmware 1.2		12/16/2004 10:15:56 PM Graham Waterfield
//		Allow channels to be read one at a time
// 2	V6 Firmware 1.1		11/29/2004 4:54:07 PM Graham Waterfield
//		Removed unnessary macros
// 1	V6 Firmware 1.0		9/28/2004 4:20:02 PM	Graham Waterfield 
// $
//
//////////////////////////////////////////////////////////////////////
#ifndef _CONVERT_H
#define _CONVERT_H
#ifndef FLT_MAX	
#include <float.h>
#endif
#include "Defines.h"
#define INTERN_UNDER4	0				///< Under range by 4%
#define INTERN_0		2400			///< Intern Zero
#define INTERN_100		62400			///< Intern span
#define INTERN_OVER4	64800			///< Over range by 4%
#define INTERN_SPAN		(INTERN_100-INTERN_0)	///< Actual span for calcs
#define DAYS_IN_A_WEEK			7
#define MONTHS_IN_A_YEAR		12
#define SECONDS_IN_A_MINUTE		60
#define SECONDS_IN_AN_HOUR		3600
#define SECONDS_IN_A_DAY		86400
#define SECONDS_IN_A_WEEK		604800
#define MINUTES_IN_AN_HOUR		60
#define MINUTES_IN_A_DAY		1440
#define HOURS_IN_A_DAY			24
#define USEC_IN_A_SEC			1000000
#define USEC_IN_AN_MSEC			1000
#define MSEC_IN_A_SEC			1000
#define USEC_IN_A_TICK			10000
#define MSEC_IN_A_TICK			10
// Size conversion Macros
#define BYTE_TO_KB(a)			((a)/1024)					///< Bytes to Kbytes
#define BYTE_TO_MB(a)			((a)/1048576)				///< Bytes to Megabytes
#define KB_TO_BYTE(a)			((a)*1024)					///< KBytes to Bytes
#define KB_TO_MB(a)				((a)/1024)					///< KBytes to Megabytes
#define MB_TO_KB(a)				((a)*1024)					///< Megabytes to Kbytes
#define MB_TO_BYTE(a)			((a)*1048576)				///< Megabytes to Bytes
// Time conversion Macros
#define MSEC_TO_SEC(a)			((a)/MSEC_IN_A_SEC)			///< milliseconds to seconds
#define MSEC_TO_USEC(a)			((a)*USEC_IN_AN_MSEC)		///< milliseconds to microseconds
#define USEC_TO_SEC(a)			((a)/USEC_IN_A_SEC)			///< microseconds to seconds
#define USEC_TO_MSEC(a)			((a)/USEC_IN_AN_MSEC)		///< microseconds to milliseconds
#define SEC_TO_USEC(a)			((a)*USEC_IN_A_SEC)			///< seconds to microseconds
#define SEC_TO_MSEC(a)			((a)*MSEC_IN_A_SEC)			///< seconds to milliseconds
#define SEC_TO_MIN(a)			((a)/SECONDS_IN_A_MINUTE)	///< seconds to minutes
#define SEC_TO_HOUR(a)			((a)/SECONDS_IN_AN_HOUR)	///< seconds to hours
#define SEC_TO_DAY(a)			((a)/SECONDS_IN_A_DAY)		///< seconds to days
#define MIN_TO_SEC(a)			((a)*SECONDS_IN_A_MINUTE)	///< minutes to seconds
#define HOUR_TO_SEC(a)			((a)*SECONDS_IN_AN_HOUR)	///< hours to seconds
#define DAY_TO_SEC(a)			((a)*SECONDS_IN_A_DAY)		///< days to seconds
#define MSEC_TENTHS_TO_TICKS(a)	((a)/100)					///< Millisecond Tenths to system ticks
#define USEC_TO_TICKS(a)		((a)/USEC_IN_A_TICK)		///< Micro Seconds to system ticks
#define TICKS_TO_USEC(a)		((a)*USEC_IN_A_TICK)		///< Micro Seconds to system ticks
// MIsc conversions
#define ALIGN_UP_4(a)			(a+=( a%4 ? (4-(a%4)) : 0))		///< Round value up to nearest 4 byte boundary		
#define ALIGN_DOWN_4(a)			(a-=(a%4))						///< Round value down to nearest 4 byte boundary		
#define HIGH_NIBBLE 1		//< High nibble (top 4 bits)				
#define LOW_NIBBLE 0		//< Low Nibble (bottom 4 bits)
#include "Defines.h"
// Temperature unit identifier
typedef enum {
	TEMP_DEG_C = 0, TEMP_DEG_F = 1, TEMP_KELVIN = 2
} T_TEMP_UNIT;
// Temperature conversion type
typedef enum {
	CONVERT_ABSOLUTE, ///< Converts between absolute temperatures (i.e 2.0 deg C = 35.6 deg F )
	CONVERT_RELATIVE ///< Converts between temperature spans ( i.e 2.0 deg C span = 3.6 deg F span )
} T_TEMP_COVERT_TYPE;
//******************************************************
// DegFToDegC()
///
/// Converts Converts degrees F to degrees C.
/// @param[in] Temperature - Temperature in degrees F.
///
/// @return Temperature in degrees C
/// 
//******************************************************
inline float DegFToDegC(float Temperature) {
	// If the input is FLT_MAX or -FLT_MAX, these are markers for error conditions and 
	// these values should be passed through unchanged to preserve an error flag.
	float result;
	if ((Temperature >= FLT_MAX) || (Temperature <= -FLT_MAX)) {
		result = Temperature; // pass through the value unchanged
	} else {
		result = (Temperature - 32.0F) / 1.8F;
	}
	return result;
}
//******************************************************
// DegCToDegF()
///
/// Converts Converts degrees C to degrees F.
/// @param[in] Temperature - Temperature in degrees C.
///
/// @return Temperature in degrees F
/// 
//******************************************************
inline float DegCToDegF(float Temperature) {
	// If the input is FLT_MAX or -FLT_MAX, these are markers for error conditions and 
	// these values should be passed through unchanged to preserve an error flag.
	float result;
	if ((Temperature >= FLT_MAX) || (Temperature <= -FLT_MAX)) {
		result = Temperature; // pass through the value unchanged
	} else {
		result = (Temperature * 1.8F) + 32.0F;
		// check for infinity and change to +/- FLT_MAX if necessary
		if (result > FLT_MAX) {
			result = FLT_MAX;
		} else if (result < -FLT_MAX) {
			result = -FLT_MAX;
		}
	}
	return result;
}
//******************************************************
/// Converts Converts degrees F to degrees C for a relative span
/// @param[in] Temperature - Temperature in degrees F.
///
/// @return Temperature in degrees C
/// 
//******************************************************
inline float DegFToDegCRelative(float Temperature) {
	// If the input is FLT_MAX or -FLT_MAX, these are markers for error conditions and 
	// these values should be passed through unchanged to preserve an error flag.
	float result;
	if ((Temperature >= FLT_MAX) || (Temperature <= -FLT_MAX)) {
		result = Temperature; // pass through the value unchanged
	} else {
		result = (Temperature / 1.8F);
	}
	return result;
}
//******************************************************
/// Converts Converts degrees C to degrees F for a relative span
/// @param[in] Temperature - Temperature in degrees C.
///
/// @return Temperature in degrees F
/// 
//******************************************************
inline float DegCToDegFRelative(float Temperature) {
	// If the input is FLT_MAX or -FLT_MAX, these are markers for error conditions and 
	// these values should be passed through unchanged to preserve an error flag.
	float result;
	if ((Temperature >= FLT_MAX) || (Temperature <= -FLT_MAX)) {
		result = Temperature; // pass through the value unchanged
	} else {
		result = (Temperature * 1.8F);
		// check for infinity and change to +/- FLT_MAX if necessary
		if (result > FLT_MAX) {
			result = FLT_MAX;
		} else if (result < -FLT_MAX) {
			result = -FLT_MAX;
		}
	}
	return result;
}
//******************************************************
// DegKToDegC()
///
/// Converts Kelvin to degrees centigrade.
/// @param[in] Temperature - Temperature in Kelvin.
///
/// @return Temperature in degrees cetigrade
/// 
//******************************************************
inline float DegKToDegC(float Temperature) {
	// If the input is FLT_MAX or -FLT_MAX, these are markers for error conditions and 
	// these values should be passed through unchanged to preserve an error flag.
	float result;
	if ((Temperature >= FLT_MAX) || (Temperature <= -FLT_MAX)) {
		result = Temperature; // pass through the value unchanged
	} else {
		result = Temperature - 273.16F;
	}
	return result;
}
//******************************************************
// DegCToDegK()
///
/// Converts Converts degrees C to Kelvin.
/// @param[in] Temperature - Temperature in degrees C.
///
/// @return Temperature in Kelvin
/// 
//******************************************************
inline float DegCToDegK(float Temperature) {
	// If the incoming value is a NaN, ensure that the NaN returned is 'quiet' to avoid crashes.
	// Also, if the input is FLT_MAX or -FLT_MAX, these are markers for error conditions and 
	// these values should be passed through unchanged to preserve up arrow/down arrow displays.
	float result;
	UINT QNAN = 0x7fffffff;
	// test for special values
	if ((Temperature == FLT_MAX) || (Temperature == -FLT_MAX)) {
		result = Temperature; // pass through the value unchanged
	} else {
		result = Temperature + 273.16F;
	}
	return result;
}
//******************************************************
/// Converts Converts degrees C to required units
///
/// @param[in] units - T_TEMP_UNIT of desired unit
/// @param[in] temp - Temperature in degrees C.
///
/// @return Temperature in desired units 
//******************************************************
inline float TempFromDegC(T_TEMP_UNIT units, float temp, T_TEMP_COVERT_TYPE type) {
	if (units == TEMP_DEG_C) // Majority of conversion will be from deg c to deg c
			{
		return temp;
	}
	if (type == CONVERT_ABSOLUTE) {
		// Absolute scale conversion
		if (units == TEMP_DEG_F)		// second most popular F to C
				{
			return DegCToDegF(temp);
		} else {
			return DegCToDegK(temp);		// finally a few K to C
		}
	} else {
		// relative span conversion
		if (units == TEMP_DEG_F)		// second most popular F to C
				{
			return DegCToDegFRelative(temp);
		} else {
			return temp;				// K is relative to C, so no conversion
		}
	}
}
//******************************************************
/// Converts Converts temp in specified units to deg C
///
/// @param[in] units - T_TEMP_UNIT of units to covert from
/// @param[in] temp - Temperature in degrees units specified.
///
/// @return Temperature in degrees C
//******************************************************
inline float TempToDegC(T_TEMP_UNIT units, float temp, T_TEMP_COVERT_TYPE type) {
	if (units == TEMP_DEG_C)				// Majority of conversion will be from deg c to deg c
			{
		return temp;
	}
	if (type == CONVERT_ABSOLUTE) {
		// Absolute scale conversion
		if (units == TEMP_DEG_F)		// second most popular C to F
				{
			return DegFToDegC(temp);
		} else {
			return DegKToDegC(temp);	// finally a few C to K
		}
	} else {
		// relative span conversion
		if (units == TEMP_DEG_F)		// second most popular C to F
				{
			return DegFToDegCRelative(temp);
		} else {
			return temp;				// K is relative to C, so no conversion
		}
	}
}
//******************************************************
// getbits()
///
/// get n bits from bit position p (0 ref) from x
/// @param[in] x - Byte variable to obtain bit pattern from.
/// @param[in] p - position in byte.
/// @param[in] n - number of bits to get.
///
/// @return The value of the selected portion (bit 0 referenced)
/// 
//******************************************************
inline BYTE GetBits(BYTE x, short p, short n) {
	return (x >> p) & ~(~0 << n);
}
//******************************************************
// getbits()
///
/// get n bits from bit position p (0 ref) from x
/// @param[in] x - Word variable to obtain bit pattern from.
/// @param[in] p - position in word.
/// @param[in] n - number of bits to get.
///
/// @return The value of the selected portion (bit 0 referenced)
/// 
//******************************************************
inline USHORT GetBits(USHORT x, short p, short n) {
	return (x >> p) & ~(~0 << n);
}
//******************************************************
// getbits()
///
/// get n bits from bit position p (0 ref) from x
/// @param[in] x - ULONG variable to obtain bit pattern from.
/// @param[in] p - position in ULONG.
/// @param[in] n - number of bits to get.
///
/// @return The value of the selected portion (bit 0 referenced)
/// 
//******************************************************
inline ULONG GetBits(ULONG x, short p, short n) {
	return (x >> p) & ~(~0 << n);
}
//******************************************************
// setbits()
///
/// set n bits in x from bit position p (bit 0 ref) with the bit pattern b.
/// @param[in] x - byte variable to add bit pattern to.
/// @param[in] b - new bit pattern.
/// @param[in] p - position in byte.
/// @param[in] n - number of bits to insert.
///
/// @return Nothing
/// 
//******************************************************
inline void SetBits(BYTE *x, BYTE b, short p, short n) {
	*x = ((b & ~(~0 << n)) << p) | (*x & (~((~0 << p) ^ (~0 << (p + n)))));
}
//******************************************************
// setbits()
///
/// set n bits in x from bit position p (bit 0 ref) with the bit pattern b.
/// @param[in] x - Word variable to add bit pattern to.
/// @param[in] b - new bit pattern.
/// @param[in] p - position in word.
/// @param[in] n - number of bits to insert.
///
/// @return Nothing
/// 
//******************************************************
inline void SetBits(USHORT *x, USHORT b, short p, short n) {
	*x = ((b & ~(~0 << n)) << p) | (*x & (~((~0 << p) ^ (~0 << (p + n)))));
}
//******************************************************
// setbits()
///
/// set n bits in x from bit position p (bit 0 ref) with the bit pattern b.
/// @param[in] x - ULONG variable to add bit pattern to.
/// @param[in] b - new bit pattern.
/// @param[in] p - position in ULONG.
/// @param[in] n - number of bits to insert.
///
/// @return Nothing
/// 
//******************************************************
inline void SetBits(ULONG *x, ULONG b, short p, short n) {
	*x = ((b & ~(~0 << n)) << p) | (*x & (~((~0 << p) ^ (~0 << (p + n)))));
}
//******************************************************
// setbits()
///
/// set n bits in x from bit position p (bit 0 ref) with the bit pattern b.
/// @param[in] x - quint64 variable to add bit pattern to.
/// @param[in] b - new bit pattern.
/// @param[in] p - position in quint64.
/// @param[in] n - number of bits to insert.
///
/// @return Nothing
/// 
//******************************************************
inline void SetBits(quint64 *x, quint64 b, short p, short n) {
	*x = ((b & ~(~0 << n)) << p) | (*x & (~((~0 << p) ^ (~0 << (p + n)))));
}
//******************************************************
// SetNibble()
/// Sets the upper or lower nibble of a byte to value provided 
///
/// @param[in] byteToSet - The current contents of the byte to set
/// @param[in] valueToSet - value to set nibble to, must be 0 to 15
/// @param[in] Nibble - HIGH_NIBBLE for top 4 bits or LOW_NIBBLE for bottom 4 bits
///
/// @return byteToSet with the valueToSet in the nibble Nibble.
/// 
//******************************************************
inline UCHAR SetNibble(UCHAR byteToSet, UCHAR valueToSet, int Nibble) {
	valueToSet = valueToSet & 0x0F;	// Make sure this is nothing in top niblle of ValueToSet
	if (Nibble == HIGH_NIBBLE) {
		// Set High nibble
		byteToSet &= 0x0F;				// Clear ther high nibble
		byteToSet |= (valueToSet << 4);	// Set the high nibble with value
	} else {
		// Set the low nibble
		byteToSet &= 0xF0;				// Clear the low nibble
		byteToSet |= valueToSet;		// Set the low nibble
	}
	return byteToSet;
}
//******************************************************
// GetNibble()
/// Sets the upper or lower nibble of a byte to value provided 
///
/// @param[in] byteToGet - The current contents of the byte to get the nibble from
/// @param[in] Nibble - HIGH_NIBBLE for top 4 bits or LOW_NIBBLE for bottom 4 bits
///
/// @return the nibble requested as a value between 0-15
/// 
//******************************************************
inline UCHAR GetNibble(UCHAR byteToGet, int Nibble) {
	if (Nibble == HIGH_NIBBLE) {
		// Shift high nibble down
		byteToGet >>= 4;				// Clear ther high nibble
	}
	byteToGet &= 0x0F;				// Mask off top nibble as now relevant data is in bottom nibble
	return byteToGet;
}
#endif // CONVERT_H

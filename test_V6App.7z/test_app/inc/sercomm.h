// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Utility
/// @n Filename: sercomm.h
/// @n Desc:	 Simple Serial communications class for Windows
///						
// 
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  8 Stability Project 1.5.2.1 7/2/2011 5:01:15 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  7 Stability Project 1.5.2.0 7/1/2011 4:27:03 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  6 V6 Firmware 1.5 5/20/2005 7:53:13 PM  Graham Waterfield
//  Changed baud rate selection to 19400 baud so that digital I/O stands
//  a chance of working
//  5 V6 Firmware 1.4 5/14/2005 4:00:02 PM  Graham Waterfield
//  Correct sercomm, remove Overlapped and other unuseful hacks
// $
//
// ****************************************************************
#ifndef __SERCOMM_H__
#define __SERCOMM_H__
#include <QtSerialPort/QSerialPort>
#include "Defines.h"
/// Comm ports 1 to 8
typedef enum {
	COM_PORT1 = 0, COM_PORT2, COM_PORT3, COM_PORT4, COM_PORT5, COM_PORT6, COM_PORT7, COM_PORT8
} T_COMMPORT;
/// Supported baud rates
typedef enum {
	BR_1200 = 1200,
	BR_2400 = 2400,
	BR_4800 = 4800,
	BR_9600 = 9600,
	BR_14400 = 14400,
	BR_19200 = 19200,
	BR_38400 = 38400,
	BR_57600 = 57600,
	BR_115200 = 115200
} T_BAUDRATE;
/// Return results
typedef enum {
	SC_OKAY = 0, SC_FAILED
} T_SERCOM_RESULT;
const T_BAUDRATE ATE_BAUD_RATE = BR_19200;
typedef struct _COMMTIMEOUTS {
    DWORD ReadIntervalTimeout;          /* Maximum time between read chars. */
    DWORD ReadTotalTimeoutMultiplier;   /* Multiplier of characters.        */
    DWORD ReadTotalTimeoutConstant;     /* Constant in milliseconds.        */
    DWORD WriteTotalTimeoutMultiplier;  /* Multiplier of characters.        */
    DWORD WriteTotalTimeoutConstant;    /* Constant in milliseconds.        */
} COMMTIMEOUTS,*LPCOMMTIMEOUTS;
typedef struct _COMMCONFIG {
    DWORD dwSize;               /* Size of the entire struct */
    WORD wVersion;              /* version of the structure */
    WORD wReserved;             /* alignment */
    DWORD dwProviderSubType;    /* ordinal value for identifying
                                   provider-defined data structure format*/
    DWORD dwProviderOffset;     /* Specifies the offset of provider specific
                                   data field in bytes from the start */
    DWORD dwProviderSize;       /* size of the provider-specific data field */
    WCHAR wcProviderData[1];    /* provider-specific data */
} COMMCONFIG,*LPCOMMCONFIG;

//**Class*********************************************************************
///
/// @brief Provide simple access to a Serial commincation prot
/// 
/// This class will provide basic access functions for serial communications on
/// V6 Target, emulator and PC platform, does not support overlapped IO
///
//****************************************************************************
class CSerialComms {
public:
	CSerialComms();
	~CSerialComms();
	T_SERCOM_RESULT Open(T_COMMPORT commPort, T_BAUDRATE baudRate);
	T_SERCOM_RESULT Read(void *pBuffer, ULONG *pSize);
	T_SERCOM_RESULT Write(void *pBuffer, ULONG *pSize);
	T_SERCOM_RESULT Close();
	T_SERCOM_RESULT ClearAllBuffers();
	void HandleError(QString pRoutine);
	void TestHelloToPortAt9600(T_COMMPORT commPort, int times);
private:
	QSerialPort m_DCB;					///< Data control block
	COMMTIMEOUTS m_timeOuts;	///< Communications timeout settings
	COMSTAT m_cstat;			///< COMSTAT status
};
#endif //__SERCOMM_H__

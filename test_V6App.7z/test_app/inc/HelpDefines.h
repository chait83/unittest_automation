/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Help system
/// @n Filename:  HelpDefines.h
/// @n Description: Declarations of various enums required for the help system
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  16  Stability Project 1.13.1.1 7/2/2011 4:57:51 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  15  Stability Project 1.13.1.0 7/1/2011 4:27:42 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  14  V6 Firmware 1.13 5/10/2007 8:50:14 PM  Roger Dawson  
//  Updated to include the additional phase 3b help references
//  13  V6 Firmware 1.12 3/27/2007 5:33:18 PM  Roger Dawson  
//  Added the report view dialog to the process reports menu.
// $
//
// **************************************************************************
#if !defined HELP_DEFINES_H
#define HELP_DEFINES_H
/// Enumerated list containing a list of all the points in the data driven recorder
/// setup that require the help system to be displayed
typedef enum {
	mhpMainMenu,
	mhpConfigure,
	mhpAlarms,
	mhpScreen,
	mhpScreenList,
	mhpRecording,
	mhpRecordingStartStopLogging,
	mhpBatch,
	mhpMessage,
	mhpProcess,
	mhpStatus,
	mhpAlarmAck,
	mhpAlarmConfigure,
	mhpRecordingLogging,
	mhpRecordingExporting,
	mhpProcessMaxMin,
	mhpProcessUserVars,
	mhpProcessTotals,
	mhpProcessCounters,
	mhpProcessReports,
	mhpStatusAMS2750,
	mhpStatusSystem,
	mhpStatusSystemGeneral,
	mhpStatusSystemOptions,
	mhpStatusSystemIOCards,
	mhpStatusPenOverview,
	mhpStatusMaintenance,
	mhpStatusRecording,
	mhpStatusDiagnostics,
	mhpStatusDiagnosticsAIn,
	mhpStatusDiagnosticsAOut,
	mhpStatusDiagnosticsDigIO,
	mhpStatusDiagnosticsPulse,
	mhpStatusDiagnosticsComms,
	mhpStatusDiagnosticsMedia,
	mhpConfigSettings,
	mhpStatusDiagnosticsRDL,
	// RECORDER SETUP MENUS
	mhpRecSetup,
	mhpRecEditSetup,
	mhpRecSetupAMS2750InputCalibration,
	mhpRecSetupFieldIO,
	mhpRecSetupScreen,
	mhpRecSetupRecording,
	mhpRecSetupComms,
	mhpRecSetupCommsServices,
	mhpRecSetupCommsServicesModbus,
	mhpRecSetupGeneral,
	mhpRecSetupFactory,
	mhpRecSetupReset,
	mhpRecSetupFactoryCalib,
	mhpRecSetupFactoryCalibCJC,
	mhpRecSetupFactoryCalibAI,
	mctRecorderEventsCtr,
	mhpRecSetupFWUpgrade,
	mhpRecLoadCertificates,
	// LAYOUT SETUP MENUS
	mhpLayoutSetup,
	mhpLayoutEditSetup,
	// PASSWORD SETUP MENUS
	mhpPwdSetup,
	mhpUserPerms,
	mhpUserAdmin,
	m_eHELP_ID
} T_GENERAL_MENU_HELP_ID;
#endif

/******************************************************************************************
 /// @file help_struct.h
 /// ***************************************************************************************
 /// © Honeywell Trendview
 /// ***************************************************************************************
 /// @n Module	:	 Help System Module
 /// @n Filename	:	 help_struct.h
 /// @n Desc		:	 structure for window and button sizes		 
 ///
 //  ***************************************************************************************
 //  Revision History
 //  ************************************************************************************************************
 //  $Log[4]:
 //   5     Stability Project 1.1.1.2      7/2/2011 4:57:51 PM     Hemant(HAIL) 
 //          Stability Project: Recorder source has been upgraded from IL
 //        version of firmware to JF version of firmware.
 //   4     Stability Project 1.1.1.1      7/1/2011 4:38:18 PM     Hemant(HAIL) 
 //          Stability Project: Files has been checked in before the merging
 //        task. The merging will be done between IL version of firmware and JF
 //        version of firmware. 
 //   3     Stability Project 1.1.1.0      2/15/2011 3:03:06 PM    Hemant(HAIL) 
 //          File updated during Heap Management. Call to the default behaviour
 //        of new operator has been commented.
 //   2     V6 Firmware 1.1          7/4/2005 8:20:02 PM     Vamshi (HTSL)  
 //        Added File and Structure headers and changed structure name to
 //        SIZEINFO
 //  $
 //  ***********************************************************************************************************
 /**************************************************************************************************************
 COPYRIGHT (c) 2004
 HONEYWELL INC.,
 ALL RIGHTS RESERVED
 This software is a copyrighted work and/or information protected
 as a trade secret. Legal rights of Honeywell Inc. in this
 software is distinct from ownership of any medium in which the
 software is embodied. Copyright or trade secret notices included
 must be reproduced in any copies authorized by Honeywell Inc.
 The information in this software is subject to change without
 notice and should not be considered as a commitment by Honeywell
 Inc.
 ******************************************************************************************/
#ifndef _HELP_STRUCT_H
#define _HELP_STRUCT_H
#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
//STRUCTURE
//******************************************************
//  typedef struct SIZEINFO
///
/// @brief --- window and button size information structure.
///
/// 
///	structure that takes the window width and height, button width and height
/// 
//******************************************************
typedef struct {
	int winWidth;		// window width
	int winHeight;		// widnow height
	int btnWidth;		// Button width	
	int btnHeight;		// Button height
} SIZEINFO;
#endif //_HELP_STRUCT_H

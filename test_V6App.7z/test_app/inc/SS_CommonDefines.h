/// @file SS_CommonDefines.h
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	ScriptServices
/// @n Filename: SS_CommonDefines.h
/// @n Desc:	Contains the common defines required by the SS Clients
///				
///
/******************************************************************************************
 COPYRIGHT (c) 2004
 HONEYWELL INC.,
 ALL RIGHTS RESERVED
 This software is a copyrighted work and/or information protected
 as a trade secret. Legal rights of Honeywell Inc. in this
 software is distinct from ownership of any medium in which the
 software is embodied. Copyright or trade secret notices included
 must be reproduced in any copies authorized by Honeywell Inc.
 The information in this software is subject to change without
 notice and should not be considered as a commitment by Honeywell
 Inc.
 ******************************************************************************************/
#if !defined(SSCOMMONDEFINES_H__INCLUDED_)
#define SSCOMMONDEFINES_H__INCLUDED_
#define SCRIPTSERVICES_API
#define SV_SETUPCHANGED		0
#define SV_TIMECHANGE		1
#define SV_FIRSTRUN			2
#define SV_ALL				-1
#define ET_BOOL_FALSE	0
#define ET_BOOL_TRUE	1
#define MAX_AUTO_COUNT 5
#define MAX_LV_COUNT 20
#define MAX_SV_COUNT 3
#define MAX_GV_COUNT 200
#define MAX_PV_COUNT 50
#define MAX_FUNCNAME_LEN	40
#define MAX_IDENTIFIER_LEN 40
#define MAX_MACRO_LEN 40
#define MAX_STRINGVAL_LEN 256
#define MAX_FILEPATH_LEN 256
#define MAX_ERRORMSG_LEN 15
#define MAX_DIT_DEPENDECY_LIST	50
#define HEADEREBEGIN "[Header]"
#define HEADEREND "[/Header]"
#define SOURCEBEGIN "[Source]"
enum SCRIPTSERVICES_API SS_MODE {
	SS_NOMATH, SS_STANDARD, SS_FULLYFUNCTIONAL
};
#endif

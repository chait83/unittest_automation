/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Email system
/// @n Filename:  SMTPThread.h
/// @n Description: Definition of the CSMTPThread class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  3 Stability Project 1.0.1.1 7/2/2011 5:01:28 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  2 Stability Project 1.0.1.0 7/1/2011 4:27:47 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  1 V6 Firmware 1.0 7/12/2006 5:21:01 PM  Roger Dawson  
// $
//
// **************************************************************************
#if !defined(AFX_SMTPTHREAD_H__7BADC4CC_104C_4468_814D_0F4D5D1F527C__INCLUDED_)
#define AFX_SMTPTHREAD_H__7BADC4CC_104C_4468_814D_0F4D5D1F527C__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SMTPThread.h : header file
//
#include "EmailData.h"
#include "smtpsocket.h"
#include <QThread>
//**CSMTPThread***********************************************************
///
/// @brief Class used to send emails
/// 
/// Class used to send emails
///
//****************************************************************************
class CSMTPThread: public QThread {
public:
	/// Enum indicating the various thread states
	enum T_SMTP_THREAD_STATE {
		stsINIT, stsRUNNING, stsSHUTDOWN,
	};
protected:
	CSMTPThread();  // protected constructor used by dynamic creation
// Attributes
public:
// Operations
public:
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSMTPThread)
public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL
// Implementation
protected:
	virtual ~CSMTPThread();
	// Generated message map functions
	//{{AFX_MSG(CSMTPThread)
	// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
public:
	// Thread function responsible for initiating the sending of emails
	static UINT EmailNotificationThreadFunc(LPVOID lpParam);
	// Method that signals to the thread we are shutting down
	static void ShutdownThread();
	// Method that adds an email to the send queue reading for processing and sending
	static void AddEmailToPending(const CEmailData &rkEMAIL_DATA);
	// Method indicating if socket has finsiehd sending the last email (successful or not)
	static const bool FinishedSendingLastEmail();
	// Method that initialises the critical section
	static void InitCritSect() {
		QMutex * m_kCriticalSection;
	}
	// Method that uninitialises the critical section
	static void DeleteCritSect() {
		//deletion of mutex not required
	}
private:
	CCESecureSocket::ESocketTransMode m_esmtpSTMode;
	/// Variable indicating the current state of the thread
	static T_SMTP_THREAD_STATE ms_eState;
	/// Queue used to store the email messages
	static std::deque<CEmailData> ms_kMessageList;
	/// Critical section
	static QMutex m_kCriticalSection;
	/// Socket responsible for sending the emails to a SMTP server
	static CSMTPSocket *m_pkSMTPSocket;
	/// Timeout variable used to indicate there has been some kind of sending problem
	static ULONG m_ulTimeout;
	/// Varaible used to indicate we have sent a quit message which we are waiting to action
	static bool m_bWaitingForQuitReply;
	/// The timeout period for a socket problem before a quit has been sent (in seconds)
	static const ULONG m_ulTIMEOUT_PERIOD;
	/// The timeout period used after a quit message has been sent due to their being some
	/// kind of pervious timeout problem
	static const ULONG m_ulQUIT_TIMEOUT_PERIOD;
	// Method that gets an email in order to send it
	static const bool GetEmail(CEmailData &rkEmailData);
	// Method that initiates the connection with the SMTP server (if necessary) and begins 
	// sending the email
	static void SendEmail(const CEmailData &rkEMAIL_DATA);
	// Method that closes the SMTP socket connection to the server, usually because there
	// are no more emails left to send or we are closing down
	static void DropSMTPConnection();
	// Method that sends the quit message
	static void SendQuit();
	// Method that drops an SMTP connection in a suitable manner
	static void DropFaultySMTPConnection();
};
/////////////////////////////////////////////////////////////////////////////
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.
#endif // !defined(AFX_SMTPTHREAD_H__7BADC4CC_104C_4468_814D_0F4D5D1F527C__INCLUDED_)

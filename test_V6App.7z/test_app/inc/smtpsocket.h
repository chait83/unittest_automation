/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Email system
/// @n Filename:  SMTPSocket.h
/// @n Description: Definition of the CSMTPSocket class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log:
//  14  Stability Project 1.9.1.3 7/11/2011 4:15:49 PM  Hemant(HAIL) 
// Files updated when fixing the Email Memory Leak Issue.
//  13  Stability Project 1.9.1.2 7/2/2011 5:01:28 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  12  Stability Project 1.9.1.1 7/1/2011 4:38:56 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  11  Stability Project 1.9.1.0 6/17/2011 7:08:18 PM  Hemant(HAIL) 
// Files updated for Email Memory Leak Issue.
//  (The issue has been found in MFC library when it is used in
//  application as a shared DLL and Thread(s) are ended with
//  ExitThread(). To fix this issue in email module, which creates and
//  ends the thread for each email, the email module does not end the
//  ReadThread and hence the memory drop is not observed) 
//  10  V6 Firmware 1.9 4/18/2010 2:21:55 PM  Nilesh(HAIL)  
//  Memory Leak while sending mail. This has fix proposed by both HAIL
//  and GA Digital
//  9 V6 Firmware 1.8 3/4/2008 7:00:56 PM Roger Dawson  
//  Added the ability to save screenshots to disk, either manually or via
//  the event system.
//  8 V6 Firmware 1.7 3/8/2007 8:02:04 PM Roger Dawson  
//  Added unicode support to emails. The body can contain unicode
//  (embedded as UTF-8 data) but as yet the subject field is not capable
//  of encoding unicode data.
//  7 V6 Firmware 1.6 3/2/2007 9:04:38 PM Roger Dawson  
//  Fixed problem with email attachments not appearing when using Lan
//  Suite email server.
//  6 V6 Firmware 1.5 12/20/2006 2:36:52 PM  Roger Dawson  
//  Added the ability to send screenshots in emails.
//  5 V6 Firmware 1.4 7/12/2006 5:28:33 PM  Roger Dawson  
//  Improvements made to the Email system.
//  4 V6 Firmware 1.3 6/2/2006 7:47:35 PM Roger Dawson  
//  Extensive modifications to the email state machine in order to
//  improve error handling and overall robustness
//  3 V6 Firmware 1.2 6/1/2006 2:07:46 PM Roger Dawson  
//  Added code to decrypt passwords which have been stored within the
//  recorder setup file. Also added more message types to the SMTP
//  message parser. Code still needs to be made more robust wrt send
//  failures and attempts to resend the email though.
//  2 V6 Firmware 1.1 5/30/2006 3:51:04 PM  Roger Dawson  
//  Further email system changes and enhancements.
//  1 V6 Firmware 1.0 5/25/2006 6:14:30 PM  Roger Dawson  
// $
//
// **************************************************************************
#if !defined(AFX_SMTPQAbstractSocket_H__E7EB2139_DD8B_433F_B20A_B22FB9769409__INCLUDED_)
#define AFX_SMTPQAbstractSocket_H__E7EB2139_DD8B_433F_B20A_B22FB9769409__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SMTPSocket.h : header file
//
#include "MessageListServices.h"
#include "EmailData.h"
#include "Base64.h"
#include "V7SecureSocket.h"
//**CSMTPSocket***********************************************************
///
/// @brief Socket class used to transmit emails using SMTP
/// 
/// Socket class used to transmit emails using SMTP
///
//****************************************************************************
class CSMTPSocket: public CV7SecureSocket {
// Attributes
public:
	/// Enum indicating the various comms states
	enum T_SMTP_COMMS_THREAD_STATE {
		cstNOT_CONNECTED,
		cstCONNECTING,
		cstRECONNECTING,
		cstCONNECTED,
		cstSENT_HELO,
		cstSENT_EHLO,
		cstSENT_FROM,
		cstSENT_STARTTLS,
		cstMUST_SEND_AUTH,
		cstSENT_INIT_AUTH,
		cstSEND_AUTH_USERNAME,
		cstSENT_AUTH_USERNAME,
		cstSEND_AUTH_PASSWORD,
		cstSENT_AUTH_PASSWORD,
		cstSENT_TO,
		cstSENT_REQ_SEND_DATA,
		cstOKAY_TO_SEND_DATA,
		cstSENT_DATA,
		cstSENT_QUIT
	};
	/// Enum indicating the various SMTP return codes
	enum T_SMTP_RETURN_CODES {
		srcSYSTEM_STATUS_211 = 211,
		srcHELP_MESSAGE_214 = 214,
		srcSERVER_IS_READY_220 = 220,
		srcEND_COVERSATION_221 = 221,
		srcAUTH_SUCCESSFUL_235 = 235,
		srcACTION_COMPLETED_250 = 250,
		srcUSER_NOT_LOCAL_251 = 251,
		srcAUTH_REPLY_334 = 334,
		srcDATA_REPLY_354 = 354,
		srcSERVER_SHUTDOWN_421 = 421,
		srcPWD_TRANSITION_REQ_422 = 422,
		srcMAILBOX_BUSY_450 = 450,
		srcMAIL_SERVER_ERROR_451 = 451,
		srcMAIL_SERVER_ERROR_452 = 452,
		srcAUTH_TEMP_FAILURE_454 = 454,
		srcMESSAGE_TOO_LONG_500 = 500,
		srcSYNTAX_ERROR_501 = 501,
		srcCMD_NOT_IMPLEMENTED_502 = 502,
		srcCMD_OUT_OF_SEQ_503 = 503,
		srcCMD_NOT_IMPLEMENTED_504 = 504,
		src_AITH_REQUIRED = 505,
		srcAUTH_MECH_TOO_WEAK_522 = 522,
		srcAUTH_ENCRYPTION_REQ_523 = 523,
		srcAUTH_FAILURE_535 = 535,
		srcACCESS_DENIED_550 = 550,
		srcUSER_NOT_LOCAL_551 = 551,
		srcMAILBOX_FULL_552 = 552,
		srcADDR_SYNTAX_ERROR_553 = 553,
		srcGENERIC_FAILURE_554 = 554
	};
	/// Enum indicating the possible states following the parsing of a received message
	enum T_SMTP_RX_MSG_STATES {
		srmPROCEED, srmIGNORE, srmABORT
	};
// Operations
public:
	CSMTPSocket(ESocketTransMode eSTMode);
	virtual ~CSMTPSocket();
	// Accessor the sockets state
	const T_SMTP_COMMS_THREAD_STATE GetCommsState() const {
		return m_eCommsState;
	}
	// Method indicating the socket is currently connected to an SMTP server
	const bool IsConnected() const {
		return (m_eCommsState >= cstCONNECTED);
	}
	// Stability Project Fix:
	const void SetCommsState(T_SMTP_COMMS_THREAD_STATE eCommsState) {
		m_eCommsState = eCommsState;
	}
	// Method that initiates the sending of the email data
	void SendEmail(const CEmailData &rkEMAIL_DATA, const ULONG ulATTEMPT_NO = 0);
	// Accessor for the email sent successfully flag
	const bool FinishedSendingLastEmail() const {
		return m_bFinishedSendingLastEmail;
	}
	// Accessor for the reconnect socket flag
	const bool SocketNeedsReconnecting() const {
		return m_bReconnectSocket;
	}
	// Accessor for the variable indicating if there have been problems sending an email
	const DWORD GetLastError() const {
		return m_dwLastError;
	}
	// Accessor for the email subject - used for error reporting
	const QString GetEmailSubject() const {
		return m_kEmailData.GetSubject();
	}
	//Accessor for the email security mode
	const ULONG GetEmailSecurityMode() const {
		return m_kEmailData.GetSMTPSecurityMode();
	}
	//Accessor for the email STARTTLS command support
	const ULONG GetEmailSTARTTLSSupport() const {
		return m_kEmailData.GetStartTLSSupport();
	}
	/// Accessor for the stored email
	const CEmailData GetEmailData() const {
		return m_kEmailData;
	}
	// Method that sends the quit message
	const bool SendQuit();
	/// Const indicating a generic SMTP error
	static const DWORD ms_dwGENERIC_SMTP_ERROR;
	/// Accessors for the retry count
	const ULONG GetCurrAttemptNo() const {
		return m_ulCurrAttemptNo;
	}
	void SetCurrAttemptNo(const ULONG ulATTEMPT_NO) {
		m_ulCurrAttemptNo = ulATTEMPT_NO;
	}
	// Accessor for the send/receive operation in progress flag
	const bool SendReceiveOpInProgress() {
		return m_bSendReceiveOpInProgress;
	}
	// Accessor for the abort flag
	void AbortCurrOperation() {
		m_bAbortCurrOp = true;
	}
	//
	// Stability Project Fix:
	//
	// Mutator method to set the flag to mark finished sending the email
	void SetFinishedSendingLastEmail(bool bFinishedSendingLastEmail) {
		m_bFinishedSendingLastEmail = bFinishedSendingLastEmail;
	}
	//
	// Stability Project Fix:
	//
	// This fix was done to avoid memory leak. This method set
	// the flag for the ReadThread in class CESocket to continue
	//
	void SetContinueReadThread(bool bContinueThread);
	void SetCurrAttemptNo(int ulCurrAttemptNo) {
		m_ulCurrAttemptNo = ulCurrAttemptNo;
	}
	bool IsSendData() {
		return m_bSendData;
	}
	//
	// Stability Project Fix:
	//
	// Mutator method to set the flag to mark finished sending the data on mail
	void SetIsSendData(bool bSendData) {
		m_bSendData = bSendData;
	}
	const bool ConnectToServer(const QString &rstrSERVER_NAME, const UINT uiPORT_NO);
// Overrides
public:
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSMTPSocket)
public:
	virtual void OnReceive();
	//}}AFX_VIRTUAL
	// Generated message map functions
	//{{AFX_MSG(CSMTPSocket)
	// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
// Implementation
protected:
private:
	bool OnConnect(QString &addr);
	/// Variable used to indicate the current operational state of the SMTP socket
	T_SMTP_COMMS_THREAD_STATE m_eCommsState;
	/// Flag indicating if a receive operation is in progress
	bool m_bSendReceiveOpInProgress;
	/// Flag indicating the current operation must be aborted
	bool m_bAbortCurrOp;
	/// Variable used to store the email information
	CEmailData m_kEmailData;
	/// Variable used to store the last error
	DWORD m_dwLastError;
	/// Flag indicating the mail was sent (successfully or not)
	bool m_bFinishedSendingLastEmail;
	/// Flag indicating to the calling process that the sockets needs to be closed and reconnected again
	bool m_bReconnectSocket;
	/// Const indicating the max nuber of retries when sending an email
	const ULONG m_ulMAX_ATTEMPTS;
	/// Variable indicating the current retry attempt
	ULONG m_ulCurrAttemptNo;
	/// Variable indicating if the server requires authentification
	bool m_bRequiresAuth;
	/// Codec used for encoding/decoding server authentification information
	CBase64 m_kCoder;
	/// Variable used to indicate the current recipient number withi the email data classes
	/// to addresses field
	int m_iCurrRecipientNo;
	bool m_bstartTLSsupport;
	// Method that sends the helo message
	const bool SendHelo();
	// Method that sends the ehlo message
	const bool SendEhlo();
	// Method that sends the mail from message
	const bool SendMailFrom();
	const bool SendStartTls();
	// Method that sends the rcpt tomessage
	const bool SendRcptTo();
	// Method that sends the request send data message
	const bool SendReqSendData();
	// Method that sends the message data
	const bool SendMessageData();
	// Method that sends the authetification message data
	const bool SendInitAuth();
	// Method that sends the username data
	const bool SendUsername();
	// Method that sends the password data
	const bool SendPassword();
	// Method that sends a simple email with no MIME
	const bool SendSimpleEmail();
	// Method that sends a MIME email with a screenshot attached
	const bool SendMIMEEmail();
	// Send method that converts unicode data into mbcs prior to sending
	int Send(const QString &rstrMESSAGE_TO_SEND);
	// Receive method that converts mbcs data into unicode prior prior to processing
	int Receive(QString &rstrSERVER_REPLY);
	// Method that parses the received message and sets the system state accordingly
	const T_SMTP_RX_MSG_STATES ParseRXMessage(const QString &rstrRXMessage);
	// Method that initiates connection with an SMTP Server
	//const bool ConnectToServer( const QString  &rstrSERVER_NAME, const UINT uiPORT_NO );
	// Method that performs function following successful connection with a server
	const bool PostConnectAction();
	// Method that processes a successful authentication reply further
	const bool ProcessAuthReply(const QString &rstrMESSAGE_PORTION, T_MSGLISTSER_SMTP_MSG_TYPE &reMsgType);
	// Send method that breaks up encoded data into smaller chunks prior to sending
	int Send(const char *buf, int len);
	/// Method that parses text into quoted-printable lines - See RFC 1521 for full 
	/// details on how this works
	const QString EncodeQuotedPrintable(const QString &rstrSOURCE);
	// Stability Project Fix:
	bool m_bWaitingForQuitReply;
	// Stability Project Fix
	bool m_bSendData;
};
#endif

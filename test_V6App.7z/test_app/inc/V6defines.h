/// @file
/// ****************************************************************
/// ? Honeywell Trendview
/// ****************************************************************
/// @n Module:	Generic
/// @n Filename: V6defines.h
/// @n Desc:	All defines for V6 platform
///
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 20-10-14	Rajanbabu M			Fixed PAR:1-3I2GTSM - WSD communication is not working on upgrading the firmware
// 104 Aristos	1.100.1.1.1.0 9/19/2011 4:51:10 PM	Hemant(HAIL)
//		Stability recorder source code (JI Release) updated for WatchDog
//		Timer functionality.
// 103 Stability Project 1.100.1.1	7/2/2011 5:02:41 PM	Hemant(HAIL)
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 102 Stability Project 1.100.1.0	7/1/2011 4:26:58 PM	Hemant(HAIL)
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware.
// 101 V6 Firmware 1.100		11/20/2009 4:58:20 PM Binsy Pillai
//		precursur code
// $
//
// ****************************************************************
#ifndef __V6DEFINES_H__
#define __V6DEFINES_H__
#include "V6IOBoardTypes.H"
#include "CMMDefines.h"
#include "Conversion.h"
//#include <COLORREF>
///===============================================================================
/// GENERIC
///===============================================================================
#define PURE_VIRTUAL_FUNCTION 0;	// Used for declaring Pure Virtual Functions, #define must be used for this
// Percentage values
const float PERCENT_0 = 0;
const float PERCENT_100 = 100;
const ULONG DEFAULT_SERIAL_NUMBER = 999999;	/// Default serial number (test options code 9999990609073)
extern const DWORD g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS;
// Maths error checking
const float MAX_POWER_OF_10 = 38.5318F; ///10^38.5318 is approximately FLT_MAX
#define MULTI_STATUS_BAR_HEIGHT		62 //PSR 1-27DX2UY (48 * 1.28f = 61.44f)
#define MINI_STATUS_BAR_HEIGHT		64 ////PSR 1-27DX2UY(32 * 2.0f = 64f)
#define MULTI_XS_STATUS_BAR_HEIGHT	48 //PSR 1-27DX2UY (48 * 1.0f = 48)
#define MINI_EZ_STATUS_BAR_HEIGHT	32
//#define MULTI_PC_STATUS_BAR_HEIGHT	48 //PAR#:1-28F7Q82 kranti
#define MULTI_PC_STATUS_BAR_HEIGHT	64 //PAR#:1-28F7Q82 kranti
//#define MINI_PC_STATUS_BAR_HEIGHT	32 //PAR 1-1GQGTQR
#define MINI_PC_STATUS_BAR_HEIGHT	64////PAR 1-1GQGTQR
///===============================================================================
/// SCRIPTS
///===============================================================================
const int MAX_SCRIPT_TIMERS = 20;
///===============================================================================
/// Comms
///===============================================================================
const int MAX_COMMS_VARS = 96; ///< Total number of cummunications variables that can be set
///===============================================================================
/// Groups
///===============================================================================
/// Identifier for the different Pen groups, 0 = All, 1 to 6 are configurable lists
typedef enum {
	PEN_GROUP_NONE = 0,	///< Pen group 0, pen does not belong to another group
	PEN_GROUP_ALL = 0,				///< Pen group 0 includes all enabled pens
	PEN_GROUP_1 = 1,				///< Pen groups 1 to 6
	PEN_GROUP_2 = 2,
	PEN_GROUP_3 = 3,
	PEN_GROUP_4 = 4,
	PEN_GROUP_5 = 5,
	PEN_GROUP_6 = 6,
	PEN_GROUP_MAX,	///< Max number of Pen groups, ** always at end of groups **
	NO_GROUP_SINGLE_PEN	///< Indicates no all or groups but a single pen required
} T_PEN_GROUPS;
///===============================================================================
/// PENS
///===============================================================================
const int NORMAL_PENS = 48;	///< Up to 48 Normal pens, i.e. 1 pen per available analogue in or out
const int EXTRA_PENS = 48;	///< up to 48 Extra pens, defined by options codes
const int V6_MAX_PENS = NORMAL_PENS + EXTRA_PENS;	///< Maximum number of Pens normal + extra
//const int MAX_REPLAY_PENS = 16;						///< Number of pens used in replay,
const int MAX_REPLAY_PENS = 18;				///< Number of pens used in replay,
const int MAX_MM_REPLAY_PENS = MAX_REPLAY_PENS * 2;	///< Number of pens used in DIT for replay, Max replay Pens * 2 ( 1 max, 1 min)
const int EXTRA_PENS_MINI = 16;				///< Soft limit, extra pens for mini
const int EXTRA_PENS_EZTREND = 12;		///< Soft limit, extra pens for eztrend
// Pen base definition, used in system to indicate if penNumber is 1 or 0 based.
// typically 0 based internally but 1 based when being logged, on screen, over comms etc..
typedef enum penBase {
	ZERO_BASED = 0, ONE_BASED = 1
} T_PENBASE;
/// Will convert to a zero based pen if penNumber and it's base T_PENBASE is passed
#define		PEN_TO_ZERO_BASED(pen,base)	(pen-base)		///< Macro to convert pen to Zero base
#define		PEN_TO_ONE_BASED(pen,base)	(pen+(1-base))	///< Macro to convert pen to One base
const int PROCESS_TICKS_PER_SECOND = 100;		///< Number of processing ticks per second (processing resolution)
const int DEFAULT_PEN_RATE = PROCESS_TICKS_PER_SECOND / 2;		///< Deafult Pen rate in ticks per second
const int TICK_RATE_5Hz = PROCESS_TICKS_PER_SECOND / 5;	///< Available tick rate 5Hz
const int FASTEST_TICK_RATE = PROCESS_TICKS_PER_SECOND / 50;	///< Fastest available tick rate 50Hz
const int SLOWEST_TICK_RATE = DEFAULT_PEN_RATE;		///< Slowest tick rate 2Hz
const int MAX_V6_USER_VARS = 32;	///< User defianble variables UV1 to UV32
const int MAX_V6_PEN_GROUPS = 6;			///< Toatl number of pen groups
///===============================================================================
/// Events
///===============================================================================
const int V6_MAX_EVENTS = 20;			///< Currently 20 events, must match V6Config.xls for Event block structure
const int V6_USER_COUNTERS = 16;				///< Number of user counters
///===============================================================================
/// Message lists
///===============================================================================
const int MAX_MESSAGE_LISTS = 10;				///< Maximum number of message lists (used for queue/status allocation)
///===============================================================================
/// ALARMS
///===============================================================================
const int V6_MAX_ALARMS = 6;		///< Max number of alarms per pen
DWORD RGB(UINT8 r, UINT8 g, UINT8 b);
// Default colours for alarms
const COLORREF ALM_IN_NOT_ACK_COL = RGB(255, 255, 0); // Magenta
const COLORREF ALM_IN_ACK_COL = RGB(192, 192, 0);			// Yellow
const COLORREF ALM_OUT_NOT_ACK_COL = RGB(0, 150, 192);	// Cyan
const COLORREF ALM_OUT_COL = RGB(128, 128, 128);			// Grey
const COLORREF ALM_FLASH_OFF_COL = RGB(0, 0, 0);			// Inter-flash col
const int PRE_TRIGGER_MAX_MINUTES = 10;	// Maximum number of minutes for pre-trigger
const int POST_TRIGGER_MAX_SECONDS = 3600;
const int MAX_PRETRIGGER_INSTANCE = 16;	/// Maximum pen instance (one-based) that is capable of storing pre-trigger data
///===============================================================================
/// CHARTS
///===============================================================================
const COLORREF CHT_BACK_NORMAL_COL = RGB(255, 255, 255);	// Chart background normal colour
const COLORREF CHT_BACK_ALM_COL = RGB(255, 255, 200);	// Chart background alarm colour
const COLORREF CHT_GRADS_COL = RGB(200, 200, 200);	// Chart graduations colour
const COLORREF CHT_TIMESTAMP_COL = RGB(0, 0, 0);	// Chart timestamp text colour
const COLORREF CHT_MARKER_COL = RGB(0, 0, 0);		// Chart marker text colour
#define	MAX_USER_DIVISIONS	200.0F		//MarkD: cap number of divisions drawn, to avoid excessive processing time
///===============================================================================
/// QUEUE LIMITS
///===============================================================================
// Number of Pre Process Queues required for each recorder type
// Please Note: Analogue / Pulse are made up of Analogue, HiPulse and LoPulse( Digital Pulse )
const USHORT MULTI_MAX_ANALOGUE_PULSE_PREPROCESSQ = 60;	///< Max Analogue/Pulse Pre Process Queues for a multi trend
const USHORT MINI_MAX_ANALOGUE_PULSE_PREPROCESSQ = 20;	///< Max Analogue/Pulse Pre Process Queues for a mini trend
const USHORT EZTREND_MAX_ANALOGUE_PULSE_PREPROCESSQ = 20;///< Max Analogue/Pulse Pre Process Queues for an EZTrend trend
const USHORT PC_MAX_ANALOGUE_PULSE_PREPROCESSQ = 60;	///< Max Analogue/Pulse Pre Process Queues for the PC
const USHORT MULTI_MAX_DIGITAL_PREPROCESSQ = 3;	///< Max Digital Pre Process Queues for a multi trend
const USHORT MINI_MAX_DIGITAL_PREPROCESSQ = 1;	///< Max Digital Pre Process Queues for a mini trend
const USHORT EZTREND_MAX_DIGITAL_PREPROCESSQ = 1;	///< Max Digital Pre Process Queues for an EZTrend trend
const USHORT PC_MAX_DIGITAL_PREPROCESSQ = 3;	///< Max Digital Pre Process Queues for the PC
///===============================================================================
/// IO CHANNELS
///===============================================================================
//AI CARD Types
typedef enum T_AI_CARD_TYPE {
	AI_CARD_TYPE_INVALID = -1, AI_CARD_TYPE_V6AI = 0, AI_CARD_TYPE_V7AI, AI_CARD_TYPE_MAX,
};
// Analogue IO
const int MAX_ANALOGUE_CARDS = 6;	///< Maximum number of analogue I/O cards
const int MAX_AI_PER_CARD = 8;	///< Maximum number of analogue inputs per card
const int MAX_AO_PER_CARD = 4;	///< Maximum number of analogue outputs per card
const int MAX_ANALOGUE_IN = MAX_ANALOGUE_CARDS * MAX_AI_PER_CARD;///< Maximum number of analogue inputs 6 cards of 8 channels per card
const int MAX_ANALOGUE_OUT = MAX_ANALOGUE_CARDS * MAX_AO_PER_CARD;///< Maximum number of analogue outputs 6 cards of 4 channels per card
const int MAX_INTERNAL_CJC = MAX_ANALOGUE_CARDS;	///< Maximum number of internal CJCs, 1 CJC per card
// Digital IO
const int MAX_DIGITAL_CARDS = 3;		///< Maximum number of digital IO cards
const int MAX_DIG_IO_PER_CARD = 16;	///< Maximum number of digitalIO per card
const int MAX_DIGITAL_IO = (MAX_DIGITAL_CARDS * MAX_DIG_IO_PER_CARD);///< Maximum number of digital IO, 3 cards of 16 channels per card
const int DIGITAL_IO_INC_POWER_RELAY = (MAX_DIGITAL_IO + 1);
// Pulse
const int HIRES_PULSE_PER_CARD = MAX_AI_PER_CARD;	///< Maximum number of pulse counter on Pulse board
const int LORES_PULSE_PER_CARD = MAX_DIG_IO_PER_CARD;	///< Maximum number of pulse counters per digital cards
const int MAX_HIRES_PULSE = MAX_ANALOGUE_CARDS * HIRES_PULSE_PER_CARD;///< Maximum number of dedicated pulse input 0-25Khz in Top slots
const int MAX_LORES_PULSE = MAX_DIGITAL_CARDS * LORES_PULSE_PER_CARD;///< Maximum number of pulse counter on digital cards in bottom slots
const USHORT MAX_OF_ALL_16_CHANNELS = 0xffff;		///< All channels enabled
const USHORT EZ_BANK1_CHANNELS = 0x0007;		///< All bank 1 channels enabled
const USHORT EZ_BANK2_CHANNELS = 0x0038;		///< All bank 2 channels enabled
// DO channel types
const UCHAR DO_CHANNEL_LATCHED = 1;		// Digital out channel latched output
const UCHAR DO_CHANNEL_PULSE = 0;		// Digital out channel pulse output
// AI channel types
const UCHAR AI_CHANNEL_TYPE_LINEAR_VOLTS = 0;		// Linear volts channel specified
const UCHAR AI_CHANNEL_TYPE_LINEAR_AMPS = 1;		// Linear current channel specified
const UCHAR AI_CHANNEL_TYPE_LINEAR_OHMS = 2;	// Linear ohms channel specified
const UCHAR AI_CHANNEL_TYPE_RT = 3;					// RT channel specified
const UCHAR AI_CHANNEL_TYPE_TC = 4;					// TC channel specified
const UCHAR AI_CHANNEL_TYPE_ENG = 0xff;			// Engineering value selection
const UCHAR NO_CHAN_LINEARISATION = 0;			// No user linearisation table is seleted
typedef enum T_VOLTAGE_UNITS {
	vuMilliVolts = 0, vuVolts
};
const UCHAR LINEAR_CHANNEL_TYPE_TEMP = 0x10;			// Input type of temp
// Channel voltage ranges
const UCHAR LINEAR_VOLTS_50V = 0;
const UCHAR LINEAR_VOLTS_25V = 1;
const UCHAR LINEAR_VOLTS_12V = 2;
const UCHAR LINEAR_VOLTS_6V = 3;
const UCHAR LINEAR_VOLTS_3V = 4;
const UCHAR LINEAR_VOLTS_1_5V = 5;
const UCHAR LINEAR_VOLTS_0_6V = 6;
const UCHAR LINEAR_VOLTS_0_3V = 7;
const UCHAR LINEAR_VOLTS_1000mV = 8;
const UCHAR LINEAR_VOLTS_500mV = 9;
const UCHAR LINEAR_VOLTS_250mV = 10;
const UCHAR LINEAR_VOLTS_100mV = 11;
const UCHAR LINEAR_VOLTS_50mV = 12;
const UCHAR LINEAR_VOLTS_25mV = 13;
const UCHAR LINEAR_VOLTS_10mV = 14;
const UCHAR LINEAR_VOLTS_5mV = 15;
#define LAST_BASE_RANGE				LINEAR_VOLTS_5mV
#define BASE_LINEAR_VOLTS_COUNT				(LAST_BASE_RANGE + 1)
// Channel resitance ranges
const UCHAR LINEAR_200_OHM = 0;
const UCHAR LINEAR_500_OHM = 1;
const UCHAR LINEAR_1_KOHM = 2;
const UCHAR LINEAR_4_KOHM = 3;
const UCHAR LINEAR_10_OHM = 4;
const UCHAR LINEAR_2_KOHM = 5;
// Channel current ranges
#define		LINEAR_AMPS_0mA_20mA		0
#define		LINEAR_AMPS_4mA_20mA		1
// Thermocouple types for AI channels
#define AI_THERMO_RANGE_K				0		// Type K thermocouple
#define AI_THERMO_RANGE_R				1		// Type R thermocouple
#define AI_THERMO_RANGE_S				2		// Type S thermocouple
#define AI_THERMO_RANGE_B				3		// Type B thermocouple
#define AI_THERMO_RANGE_J				4		// Type J thermocouple
#define AI_THERMO_RANGE_T				5		// Type T thermocouple
#define AI_THERMO_RANGE_E				6		// Type E thermocouple
#define AI_THERMO_RANGE_N				7		// Type N thermocouple
#define AI_THERMO_RANGE_C				8		// Type C thermocouple
#define AI_THERMO_RANGE_W				9		// Type W thermocouple
#define AI_THERMO_RANGE_CHROMEL			10		// Chromel thermocouple
#define AI_THERMO_RANGE_L				11		// Type L thermocouple
#define AI_THERMO_RANGE_G				AI_THERMO_RANGE_W		// G is the new name for old type W
#define AI_THERMO_RANGE_M				12		// Type M thermocouple
#define AI_THERMO_RANGE_PLATINEL		13		// Patinel thermocouple
#define AI_THERMO_RANGE_D				14		// Type D thermocouple
#define AI_TOTAL_THERMOS				15
// RT types for AI channels
#define AI_RT_RANGE_PT100				0		// PT100
#define AI_RT_RANGE_PT200				1		// PT200
#define AI_RT_RANGE_CU10				2		// CU10
#define AI_RT_RANGE_CU53				3		// CU53
#define AI_RT_RANGE_NK120				4		// Nickel 120 ohm
#define AI_RT_RANGE_NI100				5		// Nickel 100 ohm
#define AI_RT_RANGE_PT1000				6		// PT1000
#define AI_RT_RANGE_PT500				7		// PT500
#define AI_RT_RANGE_PT400				8		// PT400
#define AI_RT_RANGE_PT2000				9		// PT2000
#define AI_TOTAL_RTS					10
// RT & TC calibration types
const USHORT V6_NO_OUTPUT_CAL = 0;			// No user output cal
const USHORT V6_SINGLE_POINT_CAL = 1;		// Single point output cal
const USHORT V6_DUAL_POINT_CAL = 2;			// Dual point output cal
const USHORT V6_MULTI_POINT_CAL = 3;		// Multi Point Cal (2 to 9 points)
const USHORT V6_MULTI_POINT_SIZE = 9;		// Size of the Multi Point Tables
const int V6_MP_MAX_ELEMENTS = 100;	// Generate at least a 100 point lookup table for the multi point cal
// AI board acqsition rate
const USHORT AI_ACQ_RATE_2HZ = 0;			// 2Hz acqusition rate
const USHORT AI_ACQ_RATE_5HZ = 1;			// 5Hz acqusition rate
const USHORT AI_ACQ_RATE_10HZ = 2;			// 10Hz acqusition rate
const USHORT AI_ACQ_RATE_50HZ = 3;			// 50Hz acqusition rate
typedef enum {
	PASSIVE = 0, ENABLED_WITHOUT_DIFFERENCE, ENABLED_WITH_DIFFERENCE, ENABLED_WITH_DIFF_POWER_OFF_IGNORE
} AI_ACTIVE_BURNOUT_SELECT;
#define DEFAULT_ACTIVE_BURNOUT_TYPE		ENABLED_WITH_DIFF_POWER_OFF_IGNORE
// AI misc
const UCHAR NO_TIED_TO_PEN = V6_MAX_PENS;			///< There is no tied to pen
// Pulse board acqsition rates
const USHORT PULSE_ACQ_RATE_1HZ = 0;			// 1Hz acqusition rate (used for frequency measurement)
const USHORT PULSE_ACQ_RATE_2HZ = 1;		// 2Hz acqusition rate
const USHORT PULSE_ACQ_RATE_5HZ = 2;		// 5Hz acqusition rate
const USHORT PULSE_ACQ_RATE_10HZ = 3;		// 10Hz acqusition rate
const USHORT PULSE_ACQ_RATE_NON_FREQ_MEASURE = PULSE_ACQ_RATE_1HZ;///< The rate of acqusition to use for non frequency measuring pulse channel selection
const USHORT PULSE_ACQ_RATE_FREQ_MEASURE = PULSE_ACQ_RATE_1HZ;///< The rate of acqusition to use for frequency measuring pulse channel selection
// AO board retransmission rate
const UCHAR AO_RETRANS_SLOW = 0;		// Slow retransmission rate
const UCHAR AO_RETRANS_NORM = 1;		// Normal retransmission rate
const UCHAR AO_RETRANS_FAST = 2;		// High retransmission rate
// Mains frequency
const USHORT MAINS_FREQ_50HZ = 0;		// 50Hz mains frequency
const USHORT MAINS_FREQ_60HZ = 1;		// 60Hz mains frequency
// Default I/O board serial number
const ULONG IO_DEFAULT_SERIAL_NUMBER = 0x1234abcd;		///< Default I/O board serial number
// Size of units
typedef enum {
	MEGA = 0, KILO = 1, UNITS = 2, MILLI = 3, MICRO = 4, NANO = 5, PICO = 6
} IO_MEASURE_UNITS;
// DNS Search order
typedef enum {
	D_M_W = 1,		// DNS -> MDNS -> WINS
	M_D_W,			// MDNS -> DNS -> WINS
	M_W_D,			// MDNS -> WINS -> DNS
	W_D_M,			// WINS -> DNS -> MDNS
	W_M_D,			// WINS -> MDNS -> DNS
	D_W_M			// DNS -> WINS -> MDNS
} NW_SEARCH_ORDER;
// File Extensions supported by OpPanel
const QString FILE_EXT_SETUP = ".set";
const QString FILE_EXT_AMS2750CAL=	".cal";
const QString FILE_EXT_LAYOUT=	".lay";
const QString FILE_EXT_CONFIG = ".cfg";
const QString FILE_EXT_TEMPLT = ".tpl";
const QString FILE_EXT_LIBRARY = ".lbr";
const QString  g_PASSWORD_FILE_EXT = ".pwd";
// Maximum length of a script block
const ULONG g_ulMAX_SCRIPT_LEN = 1000;
//Log rate constants
const ULONG RATE_2HZ_IN_MS = 5000;
const ULONG RATE_5HZ_IN_MS = 2000;
const ULONG RATE_10HZ_IN_MS = 1000;
const ULONG RATE_50HZ_IN_MS = 200;
const ULONG RATE_S_TO_MS_MULTIPLIER = 10000;
const ULONG RATE_M_TO_MS_MULTIPLIER = 600000;
const ULONG RATE_H_TO_MS_MULTIPLIER = 36000000;
// Border Width's
#ifdef UNDER_CE
const int g_iBORDER_SIZE = 3;
#else
const int g_iBORDER_SIZE = 3;
#endif
const ULONG g_ulNAN_TEST_VALUE = 0x7f800000;
/// Variable used as the maximum float that the user can enter
const float V6_FLT_MAX = 3.4000001E38f;
///===============================================================================
/// PASSWORD NETSYNC LIMITS
///===============================================================================
/// Const indicating the maximum number of password slaves allowable in a password netsync group
const ULONG g_ulMAX_SLAVES_PER_GROUP = 31;
///===============================================================================
/// AMS2750 Consts
///===============================================================================
// Consit indicating the start zero based index of any special zero-based pen instances used for the TUS screen
static const USHORT gs_usSPECIAL_TUS_PEN_START_INST = 62;
///===============================================================================
/// Maximum Thread Count
///===============================================================================
const int MAX_V6_THREAD_COUNT = 30;
//For WSD Certificate Installation
#define CERT_IMPORT_DLL "CertInstall.dll"
#define CERTCA_IMPORT_DLL "CertInstall.dll"
#define ROOT_CERT_CN "HoneywellTV2"
#define ROOT_CERT_CN_OLD "HoneywellTV"
#define WSDFILECOUNT 5 //WSD certificate file count
#define WSDCAFILECOUT 2// WSD certificate CA file count
static const QString WSDCERTFILES[WSDFILECOUNT] = { "Device.cer", "Device.pvk", "Root.cer", "Certificates.cab",
		"Certificates.cer" }; //WSD Certificate files
static const QString WSDCACERTFILES[WSDCAFILECOUT] = { "Device.pfx", "Root.cer" };
static const QString EMAILCERTFILES = "Root.cer";
typedef int (WINAPI*EXTRACTANDINSTALLCERTCAB)(QString certFile);
typedef int (WINAPI*CHECKROOTCERTIFICATE)(QString certFile);
typedef int (WINAPI*CHECKSERVERCACERTIFICATE)(QString certFile);
typedef int (WINAPI*INSTALLCACERTFILES)(QString certPfxFile, QString rootFile, QString deviceCerSub, QString rootCerSub,
		QString pfxPassword);
typedef void (WINAPI*DELETECERTFILES)(QString deviceCerSub, QString rootCerSub);
typedef void (WINAPI*DELETEROOTCERTFILE)(QString rootCerSub);
typedef int (WINAPI*CHECKCERTIFICATEVALIDITY)(QString certFile);
typedef int (WINAPI*IMPORTROOTCERTTOSTORE)(QString certFile, QString certSubject);
typedef int (WINAPI*IMPORTROOTCERTCATOSTORE)(LPWSTR certFile, LPWSTR certSub);
typedef int (WINAPI*INSTALLEMAILCERTFILES)(LPWSTR rootCertFile, LPWSTR rootCertSub);
typedef void (WINAPI*GETCERTIFICATEISSUERNAME)(QString certSubject, QString certIssuerSubject);
#endif // __V6DEFINES_H__

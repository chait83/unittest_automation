//************************************************************************************
// © Honeywell Technology Solutions Lab Pvt LTD Bangalore 
//************************************************************************************
// Module  ErrorCodes
// Filename  \Trendview_v6\code\header\ErrorCodes.h
// Description - This file contains all possible Error, Warning and Informative codes
//	and the corresponding messages.
//	Error codes will be represented by E_
//	Warning codes will be represented by W_
//	Informative codes will be represented by I_
//	For ease of access, three different range of codes will be used for each of the
//	category.
// 
//
//*** Revision History ***************************************************************
// $Log[2]:
// 3 Stability Project 1.0.1.1 7/2/2011 4:57:05 PM Hemant(HAIL) 
//  Stability Project: Recorder source has been upgraded from IL version
//  of firmware to JF version of firmware.
// 2 Stability Project 1.0.1.0 7/1/2011 4:27:01 PM Hemant(HAIL) 
//  Stability Project: Files has been checked in before the merging task.
//  The merging will be done between IL version of firmware and JF version
//  of firmware. 
// $
//************************************************************************************
#ifndef _ERROR_CODES_H
#define _ERROR_CODES_H
#define E_BASE 1000
#define E_EMPTY	E_BASE + 1
#define E_MDGEN_STARTED E_BASE + 2
#define E_MDGEN_ENDED E_BASE + 3
#define E_COMMENTED_STRUCT E_BASE + 4
#define E_COMMENTED_UNION E_BASE + 5
#define E_UNDEFINED_UDT E_BASE + 6
#define E_FIELDNAME_NOTFOUND E_BASE + 7
#define E_CSVFILE_NOTGENERATED E_BASE + 8
#define E_METADATAGEN_FAILED E_BASE + 9
#define E_UNHANDLED_ERROR E_BASE + 10
#define E_GENERATING_LOG E_BASE + 11
#define E_CRCGEN_FAILED E_BASE + 12
#define E_INVALID_DATATYPE E_BASE + 13
#define E_CRCUPD_FAILED E_BASE + 14
#define E_CL_INPUTFILE_NOTPROVIDED E_BASE + 15
#define E_MDGEN_COMPLETE E_BASE + 16
#endif

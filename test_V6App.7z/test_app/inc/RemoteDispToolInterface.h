/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  CERemoteDispToolSocket 
/// @n Filename:  CERemoteDispToolSocket.h
/// @n Description: 
///
// **************************************************************************
// Revision History
// **************************************************************************
#include "CERemoteDispToolSocket.h"
class CRemoteDispToolInterface {
public:
	CRemoteDispToolInterface();
	~CRemoteDispToolInterface();
	bool RemoteDispToolInterfaceFunc();
};

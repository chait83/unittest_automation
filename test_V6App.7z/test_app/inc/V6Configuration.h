/// @file 
/// ****************************************************************
/// ï¿½ Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Configuration
/// @n Filename: V6Configuration.h
/// @n Desc:	 Include V6config generated from xls and define the
///				 variable sized block identifiers
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  4 Stability Project 1.1.1.1 7/2/2011 5:02:41 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  3 Stability Project 1.1.1.0 7/1/2011 4:27:32 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  2 V6 Firmware 1.1 8/16/2006 4:10:23 PM  Andy Kassell  Add
//  suuport for variable sized e-mail blocks
//  1 V6 Firmware 1.0 6/14/2005 9:16:54 PM  Andy Kassell  
// $
//
// ****************************************************************
#ifndef __V6CONFIGURATION_H__
#define __V6CONFIGURATION_H__
#include "V6Config.h"
#define BLKVARIABLE_PENMATHS	(REF_BASE_VARIABLE_DATATYPE + 2)	/// Variable block for Pen Maths
#define BLKVARIABLE_EMAIL_MSG	(REF_BASE_VARIABLE_DATATYPE + 3)	/// Variable block for Free format E-mails
// Add extra pen block modifiers here.
#endif // __V6CONFIGURATION_H__

//////////////////////////////////////////////////////
// BootData.h : Bootlace non-volatile data structures
//
#if !defined(__BOOT_DATA_H_)
#define __BOOT_DATA_H_
#include "Defines.h"
#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
//////////////////////////////////////////////////////
// Touchscreen calibration gegistry keys
#define CAL_KEY		L"\\Hardware\\DeviceMap\	ouch"
#define CAL_SUBKEY	L"CalibrationData"
////////////////////////////////////////////////////////////////////////////////
// Bootlace FLASH structure
//
#define FOLDER_LEN	25
#define CAL_LEN		64
#define NOT_TESTED 0
#define TEST_FAILED 1
#define TEST_PASSED 2
#define FIRST_USB_FAILED	0x01
#define SECOND_USB_FAILED 0x02
#define FRONT_SD_FAILED	0x04
#define REAR_SD_FAILED	0x08
#define SPI_FAILED		0x10
#define TOUCH_CAL_FAILED	0x20
#define RS485_FAILED		0x40
#define ETHERNET_FAILED	0x80
#define NO_TOUCH_CAL		0x100
// Bootlace FLASH strucrure
//
// On start-up Bootlace will read this block, if the signature is incorrect the block will be initialised
// If the bootmode is set to "Customer" the AppFolder is valid, Bootlace will check the NV-RAM signature (below)
// If Bootlace is in "Debug" mode a list of available App builds will be presented
typedef struct BOOT_DATA {
	unsigned short BootMode;		// Boot mode; 0 = "Customer"; 1 = "Debug"
	unsigned short WatchDog;				// WatchDog mode: 0 = No watchdog
	unsigned short AppFolder;				// 0 = No default App, 1 = Primary App, 2 = Secondary App
	unsigned short HulkTestState;				// Hulk Test state (Un-Tested/Test Failed/Test Passed
	unsigned short HulkTestResult;		// Hulk test results
	unsigned short BoardTestState;			// Processor test state
	unsigned short BoardTestResult;			// Processor test results
} T_BOOT_DATA;
const USHORT FW_UPDATE_WCELOAD = 0xFA7B;			// Call WCELoad with FWCommand as filename
const USHORT FW_UPDATE_XLOADER = 0x196D;			// execute x loader with command line
const USHORT FW_PARAM_LEN = 50;
// Bootlace NV-RAM structure
//
// On start-up Bootlace *can* read this data and decide if the previous
// application launch was successfull, if so and Bootlace is in "Customer" mode
// the current "Active" app *can* be launched; If not Bootlace will enter "Debug" mode
typedef struct APP_CHECK {
	unsigned long RegionSignature;			// RAM region signature, used to detect first use
	unsigned long BootSignature;			// Boot signature, created by Bootlace on App start
	unsigned long BootCheck;			// Boot check , created by the App on successfull initialisation
	unsigned long BootStage;	// How far into the boot sequence the App got
	USHORT FWUpdateSig;					// Firmware update signature
	WCHAR FWCommand[FW_PARAM_LEN];		// FW Update command
} T_BOOT_CHECK;
#endif // !defined(__BOOT_DATA_H_)

//************************************************************************************
// Module  LCM
// Filename  LCMGlobal.h
/// **************************************************************************
/// @n Module: 	  LCM
/// @n Filename:  LCMGlobal.h
/// @n Description: Used by clients to get the status from LCM.
///
// **************************************************************************
// Revision History
// $Log[4]:
//  6 Stability Project 1.3.1.1 7/2/2011 4:58:18 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  5 Stability Project 1.3.1.0 7/1/2011 4:27:26 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  4 V6 Firmware 1.3 2/28/2006 11:52:50 AM  Shyam (HTSL)  
//  Added a MessageBox in UpdateLCF API to display sessions from LCF file
//  and Sequencer session if sessions are apart. Added a new error code
//  as LCM_WARNING_SESSIONS_APART after which no operation will be
//  further carried out in UpdateLCF API.
//  3 V6 Firmware 1.2 5/30/2005 10:34:44 AM  Shyam (HTSL)  
//  File headers comments added
// $
//
// ****************************************************************************************
/******************************************************************************************
 COPYRIGHT (c) 2004
 HONEYWELL INC.,
 ALL RIGHTS RESERVED
 This software is a copyrighted work and/or information protected
 as a trade secret. Legal rights of Honeywell Inc. in this
 software is distinct from ownership of any medium in which the
 software is embodied. Copyright or trade secret notices included
 must be reproduced in any copies authorized by Honeywell Inc.
 The information in this software is subject to change without
 notice and should not be considered as a commitment by Honeywell
 Inc.
 ******************************************************************************************/
#ifndef _INC_CLCFINDEXMANAGER_42087C6200A2B_INCLUDED
#define _INC_CLCFINDEXMANAGER_42087C6200A2B_INCLUDED
#include "Defines.h"
#include "CMMDefines.h"
typedef enum enumLCMERROR {
	LCM_SUCCESS = 0,						//0
	LCM_FAILED,
	LCM_INVALID_PARAMETER,
	LCM_UNINITIALISED,
	LCM_INVALID_FILE_NAME,
	LCM_INVALID_SESSION_ID,					//5
	LCM_INDEX_FILE_NOT_PRESENT,
	LCM_INSUFFICIENT_MEMORY,
	LCM_INDEX_CRC_FAILED,
	LCM_LCF_CRC_FAILED,
	LCM_CMM_FAILED,							//10
	LCM_CMM_INVALID_METADATA,
	LCM_CMM_INVALID_PARAMETER,
	LCM_CMM_INSUFFICIENT_MEMORY,
	LCM_CMM_NOT_INITIALIZED,
	LCM_CMM_VALUE_OUT_OF_RANGE,				//15
	LCM_CMM_INVALID_CONFIGURATION_ID,
	LCM_CMM_CONFIGURATION_UNAVAILABLE,
	LCM_CMM_CONFIGURATION_FILE_NOT_FOUND,
	LCM_CMM_CONFIGURATION_CORRUPT,
	LCM_CMM_INVALID_BLOCK_TYPE,				//20
	LCM_CMM_INVALID_INSTANCE,
	LCM_WARNING_SESSIONS_APART,
	LCM_UNDEFINED
} LCMERROR;
typedef struct stINDEX_RECORD {
	DATA_BLOCK_HEADER stBlockDetails;
	ULONG lOffset;						// Offset of block type in LCF.
	TV_BOOL bRecordRead;
} INDEX_RECORD;
typedef enum enumRecreate {
	LCF_RECREATE, LCF_IMPORT
} RECREATE;
typedef enum enumUpdateLCF {
	LCF_UPDATE, LCF_LOAD
} UPDATELCF;
#endif

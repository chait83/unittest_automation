#ifndef _V6ACTIVEMODULESERVICES_H
#define _V6ACTIVEMODULESERVICES_H
//#include "V6ActiveModule.h"
#include "Defines.h"
/// Return Values for CV6ActiveModule Member Functions, used to describe the type of 
/// success or failure.
/// 
typedef enum {
	V6AMSER_OK, V6AMSER_MODULE_CREATION_FAILED,
} T_V6AMSER_RETURN_VALUE;
/// A Enumeration for active modules
typedef enum E_V6AMSER_ACTIVE_MODULES {
	V6AMSER_IO_SCHEDULER, V6AMSER_DATA_PROCESSING,
	//V6AMSER_MESSAGE_LIST_PROCESSING,
	V6AMSER_MODBUS_MASTER,
	V6AMSER_MODBUS_SLAVE,
	V6AMSER_IO_SIMULATOR,
	V6AMSER_EXPORT_SCHEDULER,
	V6AMSER_AUTO_OPS,
	V6AMSER_P2P_ENGINE,
	V6AMSER_TUS_FILE_BUILDER,
#ifdef UNDER_CE 
	#ifndef DISABLE_WDT	
	//Watch Dog Timer is an Active module
	V6AMSER_WATCHDOG_TIMER,
	#endif
  #endif
	V6AMSER_NUM_OF_ACTIVE_MODULES
} T_V6AMSER_ACTIVE_MODULES;
#define ATEAMSER_NUM_OF_ACTIVE_MODULES	1
//**Class*********************************************************************
///
/// @brief Base Class for all Active Modules within V6
/// 
///
//****************************************************************************
class CV6ActiveModuleServices {
public:
	/// Constructor
	CV6ActiveModuleServices(void);
	/// Destructor
	virtual ~CV6ActiveModuleServices(void);
	/// Create all the active modules
	T_V6AMSER_RETURN_VALUE CreateActiveModules(void);
	/// Initialise the Active Modules
	T_V6AMSER_RETURN_VALUE InitialiseActiveModules(void);
	/// Delete all Active Modules
	T_V6AMSER_RETURN_VALUE DeleteActiveModules(void);
	/// Obtain a specific Active Module, return will need to cast to the relevant module
	class CV6ActiveModule& GetActiveModule(T_V6AMSER_ACTIVE_MODULES activeModule);
	bool DoesActiveModuleExist(T_V6AMSER_ACTIVE_MODULES activeModule);
private:
	class CV6ActiveModule *m_ActiveModule[V6AMSER_NUM_OF_ACTIVE_MODULES];
};
// End of Class Declaration
inline CV6ActiveModule& CV6ActiveModuleServices::GetActiveModule(T_V6AMSER_ACTIVE_MODULES activeModule) {
	return (*m_ActiveModule[activeModule]);
} // End of  
inline bool CV6ActiveModuleServices::DoesActiveModuleExist(T_V6AMSER_ACTIVE_MODULES activeModule) {
	return (m_ActiveModule[activeModule] != NULL);
} // End of  
#endif // _V6ACTIVEMODULESERVICES_H

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		WatchDogTimer
/// @n Filename:	ThreadInfo.h
/// @n Description: Class to manage WDT Functionality
///
#pragma once
#include "V6ActiveModule.h"
#ifndef TMPV5
#include "PassiveModule.h"
#include "V6defines.h"
#endif
#include <QMutex>
#include <map>
#define MIN_THREAD_COUNT 1
#define DEFAULT_THREAD_COUNT 0
/// A Enumeration for active modules
typedef enum E_ACTIVE_MODULES {
	AM_IO_SCHEDULER,
	AM_DATA_PROCESSING,
	AM_MODBUS_MASTER,
	AM_MODBUS_SLAVE,
	AM_IO_SIMULATOR,
	AM_EXPORT_SCHEDULER,
	AM_AUTO_OPS,
	AM_P2P_ENGINE,
	AM_TUS_FILE_BUILDER,
	AM_NOTIFICATION,
	AM_QMDISKSERVICES,
	AM_REPORT_GEN,
	AM_TIME_CHANGE_NOTIFY,
	AM_EMAIL_THREAD,
	AM_QAbstractSocket_READ_THREAD,
	AM_ACCEPT_THREAD,
	AM_PRINTER_THREAD,
	AM_TX_SCHEDULER_THREAD,
	AM_REQUESTHANDLER_THREAD,
	AM_OPC_INFO_THREAD,
	AM_OPC_UPDATE_THREAD,
	AM_OPC_SEND_MSG_THREAD,
	AM_TIMER_NOTIFICATION_THREAD,
	AM_P2PENGINE_ARBITRATOR_THREAD,
	AM_P2PENGINE_LISTEN_THREAD,
	AM_P2PENGINE_STATE_THREAD,
	AM_PASS_SYNC_ENGINE_LISTEN_THREAD,
	AM_PASS_SYNCENG_STARTUP_THREAD,
	AM_OPPANEL,
	AM_CTRLSEQUENCER,
	AM_LOGON_FAILURE_CHECKER_THREAD,
	NO_OF_ACTIVE_MODULES
} T_AM_ACTIVE_MODULES;
typedef enum {
	WATCH_DOG_KICKED = 0, ///< WatchDog was kicked and the recorder was not reset
	WATCH_DOG_NOT_KICKED, ///< WatchDog was not kicked and the recorder had reset
} T_WATCHDOG_STAT;
typedef struct WatchDogParams {
	int arrCurrThreadCount;
	bool threadExist;
} WATCHDOG_PARAMS;
#ifdef TMPV5
class CThreadInfo 
#else
class CThreadInfo: public CPassiveModule
#endif
//class CThreadInfo : public CPassiveModule
{
private:
	CThreadInfo(void);
	virtual ~CThreadInfo(void);
public:
	// Get pointer to the CThreadInfo singleton.
	static CThreadInfo* GetHandle();
	void UpdateThreadCounter(int modId);
	int GetThreadCounter(int modId);
	void ResetWatchDogCounter();
	void ShutdownOrdered(void);
	void ShutdownPreparation(void);
	BOOL IsShutdownPreparation(void);
	void CleanUp();
	void AddThreadInfo(int modId, bool bIsExist);
	void UpdateThreadInfo(int modId, bool bIsExist = false);
	void WriteThreadInfo();
	void ReadThreadInfo();
	void LogThreadInfoMessage(int modId);
	///Method called when Module wants to disable the watchdog at runTime
	void DisableWatchDog(BOOL bDisableWatchDog = FALSE);
	///Method called when the WatchDogTimerThread has to check if the WatchDog is disabled
	/// at runtime
	BOOL IsWatchDogDisabled();
	void SetWatchDogStatus(T_WATCHDOG_STAT status);
	void SetWatchMaxDogKickTime(DWORD maxWatchDogKickTime);
	BOOL IsThreadsAlive();
	void SetMemoryLow(BOOL bIsMemoryLow);
	BOOL IsMemoryLow();
	DWORD GetThreadRefreshTickCount(int modId);
	int m_MaxTimeTakenByThread;
	int m_ThreadIDTakingMaxTime;
private:
	static QMutex m_csActiveModList[NO_OF_ACTIVE_MODULES];
	// Mutex for ensuring only a single instance of peer services is used.
	static HANDLE m_hCreationMutex;
	// Singleton instance of the peer 2 peer services engine.
	static CThreadInfo *m_pInstance;
	BOOL m_ShutdownOrdered;
	BOOL m_DisableWatchDog;			/// Flag to decide if the WatchDog should
									/// be disabled at runtime
	BOOL m_ShutdownPrepare;
	WATCHDOG_PARAMS m_WatchDogParams[NO_OF_ACTIVE_MODULES];
	DWORD m_ThreadRefreshedTickCount[NO_OF_ACTIVE_MODULES];
	BOOL m_IsMemoryLow;				///Flag to check if watchdog should restart
									///if the virtual memory is low
};
void GlbUpdateThreadCount(int modId);
void GlbUpdateThreadInfo(int modId, bool bIsThreadExist);
//#ifdef __cplusplus
//}
//#endif
//

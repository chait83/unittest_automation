/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	Persist Manager
/// @n Filename: NVVariables.h
/// @n Desc:	Manages access and updates to non volatile variables
///				stored in the systems SRAM
///				
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 34	Aristos	1.30.1.1.1.0 9/19/2011 4:51:08 PM	Hemant(HAIL) 
//		Stability recorder source code (JI Release) updated for WatchDog
//		Timer functionality.
// 33	Stability Project 1.30.1.1	7/2/2011 4:59:08 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 32	Stability Project 1.30.1.0	7/1/2011 4:27:29 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 31	V6 Firmware 1.30		9/25/2009 3:20:01 PM	Binsy Pillai 
//		event cursor merging of code
// $
//
// ****************************************************************
#ifndef __NVVARS_H__
#define __NVVARS_H__
#include "DAL.h"	
#include "SRAM.h"
#include "V6defines.h"
#include "TVtime.h"
#include "PassiveModule.h"				// Passive Module Base Class
#include "V6types.h"
#include <QMutex>
// Need to Set to Pack 4, minimum access granularity for MIPSII
// also the SRAM is 16 bit so will no advantage from any greater alignment
#pragma pack(push)
#pragma pack(4)			
/// ******* ADD NEW NV VARS HERE ***********************************************************
/// NV Variable ident list, add identifier to end of list. List has to be maintained.
typedef enum {
	NVV_NOT_NV = 0,	///< Not an NV variable, used to indicate no NV variable used
//	NVV_NUMNV=0,											///< Number of NV variables.
	NVV_SESSION,											///< Session number
	NVV_PEN_SEQ_FIRST,						///< First sequence number holder
	NVV_PEN_SEQ_MAX = (NVV_PEN_SEQ_FIRST + V6_MAX_PENS),						///< Last sequence number + 1 
	NVV_MESSAGE_SEQ,						///< Global message sequence number
	NVV_PEN_TOTAL_FIRST,									///< First Totaliser
	NVV_PEN_TOTAL_MAX = (NVV_PEN_TOTAL_FIRST + V6_MAX_PENS),	///< Last totaliser + 1 (i.e. Max NV totaliser number)
	NVV_OGREALTIME,	///< On going process time in 1/100 tick and the process time in Tv5Time LONGLONG uSec
	NVV_TOTAL_TIME_ON,									///< Time on in seconds
	NVV_TOTAL_TIME_OFF,									///< Time off in seconds
	NVV_TOTAL_TIME_OFF_LITHIUM,	///< Time off in seconds resettable for lithium life							
	NVV_MAX_TIME_OFF,	///< Maximum time period switched off						
	NVV_BACKLIGHT_LIFE,	///< Backlight life used in seconds (depends on screen brightness & screen saver)
	NVV_LITHIUM_LIFE,					///< Lithium cell life used in seconds
	NVV_CJC_TEMP_MAX,		///< Maximum CJC temperature recorded inc time/date
	NVV_CJC_TEMP_MIN,		///< Minimum CJC temperature recorded inc time/date
	NVV_TOTAL_POWER_CYCLES,	///< Maximum Power cycles (include resets via reset button and watchdog T/O but not controlled)
	NVV_RELAY_OPS_FIRST,					///< First relay operation counter
	NVV_RELAY_OPS_MAX = (NVV_RELAY_OPS_FIRST + MAX_DIGITAL_IO),	///< Last relay operation counter + 1 (Max number)
	NVV_FRONTCF_INSERTS,				///< Total number of front CF insertions
	NVV_PEN_MAX_FIRST,										///< First Max
	NVV_PEN_MAX_MAX = (NVV_PEN_MAX_FIRST + V6_MAX_PENS),	///< Last Max + 1 
	NVV_PEN_MIN_FIRST,										///< First Min
	NVV_PEN_MIN_MAX = (NVV_PEN_MIN_FIRST + V6_MAX_PENS),	///< Last Min + 1 
	NVV_EXPORT_DEVICE,///< Scheduled export device ID - legacy code - DO NOT USE ANYMORE - use the profile data in the CMM
	NVV_EXPORT_INTERVAL,///< Scheduled export interval - legacy code - DO NOT USE ANYMORE - use the profile data in the CMM
	NVV_PEN_LOGGING_FIRST,						///< First pen logging enable
	NVV_PEN_LOGGING_MAX = (NVV_PEN_LOGGING_FIRST + V6_MAX_PENS), ///< Last pen logging enable + 1
	NVV_CURRENT_SCREEN,	///< Current screen number being displayed, restore on power on
	NVV_EXPORT_TIMER,							///< Export scheduler time count
	// Recording queue stats
	NVV_RECORDING_TIME,							///< recording time available
	NVV_BLOCKS_WAITING,					///< blocks waiting to be transferred
	NVV_LOG_QUEUE_BLOCKS,					///< total number of blocks allocated to the log queues
	NVV_BATCH_STATUS,							///< Status of the batch mode	
	NVV_MANUAL_TX_DEVICE,				///< Last manual data transfer device
	NVV_RELAY_OPS_POWER,				///< Power relay number of operations
	NVV_RELAY_STATE_BOARD1,		///< Persisted state of relay out for board 1
	NVV_RELAY_STATE_BOARD2,		///< Persisted state of relay out for board 2
	NVV_RELAY_STATE_BOARD3,		///< Persisted state of relay out for board 3
	NVV_RELAY_STATE_POWER,			///< Persisted state of power board relay
	// Message list oldest times
	NVV_MESSAGE_LIST_OLDEST_TIME_FIRST,			///< Oldest message list times
	NVV_MESSAGE_LIST_OLDEST_TIME_MAX = (NVV_MESSAGE_LIST_OLDEST_TIME_FIRST + MAX_MESSAGE_LISTS),///< End of the oldest message lists times
	NVV_EVENTS_FIRST,									///< First event NV data
	NVV_EVENTS_MAX = (NVV_EVENTS_FIRST + V6_MAX_EVENTS),									///< end of event NV data
	NVV_EVENTCOUNT_FIRST,								///< First event NV data
	NVV_EVENTCOUNT_MAX = (NVV_EVENTCOUNT_FIRST + V6_MAX_EVENTS),							///< end of event NV data
	NVV_USERCOUNT_FIRST,					///< First user counter NV data item
	NVV_USERCOUNT_MAX = (NVV_USERCOUNT_FIRST + V6_USER_COUNTERS),					///< end user counter NV data item
	NVV_LHWCOUNT_FIRST,					///< First low res counter NV data item
	NVV_LHWCOUNT_MAX = (NVV_LHWCOUNT_FIRST + MAX_LORES_PULSE),					///< end low res counter NV data item
	NVV_HHWCOUNT_FIRST,					///< First high res counter NV data item
	NVV_HHWCOUNT_MAX = (NVV_HHWCOUNT_FIRST + MAX_HIRES_PULSE),					///< end high res counter NV data item
	NVV_IOCOUNT_FIRST,						///< First IO counter NV data item
	NVV_IOCOUNT_MAX = (NVV_IOCOUNT_FIRST + DIGITAL_IO_INC_POWER_RELAY),	///< end IO counter NV data item + Power relay
	NVV_FTP_RECORDING_TIME,					///< FTP recording time available
	NVV_VOLUME_LEVEL,						///< The current level of the volume
	NVV_USER_VARS_FIRST,									///< User variables
	NVV_USER_VARS_MAX = (NVV_USER_VARS_FIRST + MAX_V6_USER_VARS),
	NVV_BATCH_VARS_FIRST,									///< Batch variables
	NVV_BATCH_VARS_MAX = (NVV_BATCH_VARS_FIRST + MAX_V6_PEN_GROUPS),
	NVV_BATCH_COUNT_FIRST,									///< Batch variables
	NVV_BATCH_COUNT_MAX = (NVV_BATCH_COUNT_FIRST + MAX_V6_PEN_GROUPS),
	NVV_PRETRIGGER_STATUS,								///< Pre-Trigger Status
	NVV_TCCALEXCLUDE,						///< TC Calibration adjust exclude
	NVV_WATCHDOG_STATUS,								///< Watch-Dog Status
	NVV_WATCHDOG_KICK_TIME,	/// <Max time taken by the WatchDog to get kicked
	NVV_THREAD_COUNT_FIRST,									///< Thread Count 
	NVV_THREAD_COUNT_MAX = (NVV_THREAD_COUNT_FIRST + MAX_V6_THREAD_COUNT),
	NVV_LOW_MEMORY,				///<Flag to indicate if the recorder restarted
								///< due to low memory
	NVV_TOTAL_VARS								/// ALWAYS AT END, total number of variables							
} NVVAR_IDENT;
///******************************************************************************************
// Bank identification
typedef enum {
	NV_BANK_ZERO = 0, NV_BANK_ONE = 1, NV_NUMBER_OF_BANKS								// Total number of banks
} T_BANK_IDENT;
/// Bank header, maintains the current active bank number, some additional integrity info to pad structure to even 4 bytes
typedef struct {
	USHORT bankToUpdate;		///< The bank 0 or 1 to update next, the alternate block is always latest and "valid"
	USHORT id;		///< the ID of the NV Variable that occupies tis slot, must match the NVVAR_IDENT or NV Vars invalid
} T_NVVAR_HEADER;
// Basic value comprising a header and a basic type in each bank
typedef struct {
	COMBO_VAR4 value;								///< Single value of composite type T_COMBO_VAR4 (use as required)
} T_BASIC_VALUE;
typedef struct {
	LONGLONG time;					///< TVTime in Microseconds, absolute or span (LONGLONG will be on 8 byte boundary
	COMBO_VAR4 value;								///< Single value of composite type T_COMBO_VAR4 (use as required)
} T_BASIC_WITH_TIME;
typedef struct {
	LONGLONG time;					///< TVTime in Microseconds, absolute or span (LONGLONG will be on 8 byte boundary
	COMBO_VAR8 value;								///< Single value of composite type T_COMBO_VAR8 (use as required)
} T_BASIC8_WITH_TIME;
typedef struct {
	LONGLONG startTime;			///< StartTime of totaliser
	float totalValue;			///< current toalisation value
	ULONG runTimeInSeconds;		///< Run time of totlaliser in seconds
	ULONG currentMode;			///< current totaliser mode
} T_NV_TOTALISER;
typedef struct {
	UCHAR alStatus[V6_MAX_ALARMS];		///< status for each pen alarm
	USHORT padding;
	float UserLevel[V6_MAX_ALARMS];		///< NV Level for each alarm
} T_NV_ALARMSTAT;
//**Class*********************************************************************
///
/// @brief Base class for the NV Variable block types
/// 
/// This class will maintain an Nv Variable block and provide the core functionality
/// derive a Type specific class from this to use
///
//****************************************************************************
class CNVVarBlockBase {
public:
	CNVVarBlockBase(USHORT size);
	BOOL checkIntegrityOK(USHORT id);
	void SetHeaderAddress(void *sramAddress) {
		m_pHeader = reinterpret_cast<T_NVVAR_HEADER*>(sramAddress);
	}
	;		///< Set header address in SRAM
	void SetBlockAddress(T_BANK_IDENT bank, void *sramAddress) {
		m_pDataBank[bank] = sramAddress;
	}
	;		///< Set block address in SRAM
	USHORT BankSize() {
		return m_structSize;
	}
	;			///< Get the banksize of the NV Variable block
protected:
	void* GetBankToUpdate() {
		return m_pDataBank[m_pHeader->bankToUpdate];
	}
	;
	void* GetBankToRead() {
		return m_pDataBank[1 - m_pHeader->bankToUpdate];
	}
	;
	void BankUpdated();
private:
	void CleardownNVVar(USHORT id);
private:
	T_NVVAR_HEADER *m_pHeader;				///< Ptr to the Headrer in NV Ram
	void *m_pDataBank[NV_NUMBER_OF_BANKS];	///< Ptrs to start of each NV bank
	USHORT m_structSize;			///< Size of each structure bank in block
};
//**Class*********************************************************************
/// NV variable class to handle the the Basic Combo variable type
//****************************************************************************
class CNVBasicVar: public CNVVarBlockBase {
public:
	CNVBasicVar() : CNVVarBlockBase(sizeof(T_BASIC_VALUE)) {
		;
	}
	;
	T_BASIC_VALUE* GetFromNV() {
		return reinterpret_cast<T_BASIC_VALUE*>(GetBankToRead());
	}
	;
	void SetToNV(COMBO_VAR4 value);
};
//**Class*********************************************************************
/// NV variable class to handle the the Basic Combo + time variable type
//****************************************************************************
class CNVBasicTimeVar: public CNVVarBlockBase {
public:
	CNVBasicTimeVar() : CNVVarBlockBase(sizeof(T_BASIC_WITH_TIME)) {
		;
	}
	;
	T_BASIC_WITH_TIME* GetFromNV() {
		return reinterpret_cast<T_BASIC_WITH_TIME*>(GetBankToRead());
	}
	;
	void SetToNV(COMBO_VAR4 value, LONGLONG time);
};
//**Class*********************************************************************
/// NV variable class to handle the the Basic Combo 8 + time variable type
//****************************************************************************
class CNVBasic8TimeVar: public CNVVarBlockBase {
public:
	CNVBasic8TimeVar() : CNVVarBlockBase(sizeof(T_BASIC8_WITH_TIME)) {
		;
	}
	;
	T_BASIC8_WITH_TIME* GetFromNV() {
		return reinterpret_cast<T_BASIC8_WITH_TIME*>(GetBankToRead());
	}
	;
	void SetToNV(COMBO_VAR8 value, LONGLONG time);
};
//**Class*********************************************************************
/// NV variable class to handle the a totaliser
//****************************************************************************
class CNVTotaliser: public CNVVarBlockBase {
public:
	CNVTotaliser() : CNVVarBlockBase(sizeof(T_NV_TOTALISER)) {
		;
	}
	;
	T_NV_TOTALISER* GetFromNV() {
		return reinterpret_cast<T_NV_TOTALISER*>(GetBankToRead());
	}
	;
	void SetAllNV(T_NV_TOTALISER &totalInfo);
	void SetOptimumNV(float value, ULONG timeInSeconds);
};
//**Class*********************************************************************
///
/// @brief Manage the NV Variable blocks
/// 
/// This class will maintain the Nv Variable blocks and associated lists
/// of NV Variables
///
//****************************************************************************
class CNVVariableBlockManager: public CPassiveModule {
public:		//Singleton 
	static CNVVariableBlockManager* GetHandle();
	void CleanUp();
private:	// Singleton
	CNVVariableBlockManager();
	~CNVVariableBlockManager() {
	}
	;	// Will never be called
	CNVVariableBlockManager(const CNVVariableBlockManager&);
	CNVVariableBlockManager& operator=(const CNVVariableBlockManager&) {
		return *this;
	}
	;
	static CNVVariableBlockManager *m_pInstance;
	static QMutex m_CreationMutex;
public:
	// API
	BOOL Initialise();
	/// Type specific object accessors ( add new types here )
	CNVBasicVar* GetBasicVarNVObject(NVVAR_IDENT id) {
		return reinterpret_cast<CNVBasicVar*>(m_pBlocks[id]);
	}
	;
	CNVBasicTimeVar* GetBasicTimeNVObject(NVVAR_IDENT id) {
		return reinterpret_cast<CNVBasicTimeVar*>(m_pBlocks[id]);
	}
	;
	CNVBasic8TimeVar* GetBasic8TimeNVObject(NVVAR_IDENT id) {
		return reinterpret_cast<CNVBasic8TimeVar*>(m_pBlocks[id]);
	}
	;
	CNVTotaliser* GetTotaliserNVObject(NVVAR_IDENT id) {
		return reinterpret_cast<CNVTotaliser*>(m_pBlocks[id]);
	}
	;
private:
	void AddNV(NVVAR_IDENT nvID, CNVVarBlockBase *pNVInst);
	void AddNVVariables();
private:
	BOOL m_Initilaised;				///< Guard against multiple initialisations
	CNVVarBlockBase *m_pBlocks[NVV_TOTAL_VARS];		///< Ptr to list of 
	CSRAMRegion *m_pNVArea;	///< Ptr to region class instance for NV Variables
	CSRAMManager *m_pSRAMManager;				///< Handle on SRAM manager 
	BYTE *m_pNVBaseAddress;				///< Ptr to base of NV Variables memory
	BYTE *m_pNVRunning;	///< Running Ptr to base of NV Variables as they are created
	ULONG m_NVByteCount;		///< total number of bytes used in NV Variables
	int m_VarsIntegrityOKCount;	///< Number of variables that passed the integrity check (i.e already created and okay)
	int m_VarsIntegrityFailedCount;	///< Number of variables that failed the integrity check (i.e. new or moved )
};
#pragma pack(pop)
#endif // __NVVARS_H__

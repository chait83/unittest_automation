// ErrorServices.cpp : Defines the entry point for the DLL application.
/// @file DataStore.cpp
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Script Services
/// @n Filename: ErrorServiec.cpp
/// @n Desc:	 Functions to set the error information
///
/******************************************************************************************
 COPYRIGHT (c) 2004
 HONEYWELL INC.,
 ALL RIGHTS RESERVED
 This software is a copyrighted work and/or information protected
 as a trade secret. Legal rights of Honeywell Inc. in this
 software is distinct from ownership of any medium in which the
 software is embodied. Copyright or trade secret notices included
 must be reproduced in any copies authorized by Honeywell Inc.
 The information in this software is subject to change without
 notice and should not be considered as a commitment by Honeywell
 Inc.
 /*****************************************************************************************/
//  ****************************************************************
//  Revision History
//  ****************************************************************
//  $Log[4]:
// 9   Stability Project 1.6.1.1  7/2/2011 4:57:06 PM   Hemant(HAIL) 
//    Stability Project: Recorder source has been upgraded from IL
//    version of firmware to JF version of firmware.
// 8   Stability Project 1.6.1.0  7/1/2011 4:26:40 PM   Hemant(HAIL) 
//    Stability Project: Files has been checked in before the merging
//    task. The merging will be done between IL version of firmware and JF
//    version of firmware. 
// 7   V6 Firmware 1.6    7/8/2005 1:24:00 PM   Shyam (HTSL) 
//    DllMain has been commented and GetV6String has been added
// 6   V6 Firmware 1.5    7/5/2005 3:02:18 PM   Shyam (HTSL) 
//    Modified to make the build go-on, Finally ErrorServices DLL will be
//    integrated with the Script services DLL and V6Resouce DLL will be
//    removed out. When ErrorServices is integrated with SS, GetV6String
//    method will be moved to ErrorServices.cpp and DllMain will be
//    commented out.
//  $
#include <stdlib.h>
#include <wchar.h>
#include "ErrorServices.h"
//#include "V6Resources.h"
void SET_ERR_INFO(V6ERRORINFO &pErrInfo, int nValue) {
	QString szBuf;
	szBuf = QString::number(nValue);
	if (MAX_MSG_LEN > pErrInfo.Info.length() + szBuf.length() + wcslen(DELIM)) {
		pErrInfo.Info += szBuf;
		pErrInfo.Info += QString::fromWCharArray(DELIM);
	}
}
void SET_ERR_INFO_PTR(V6ERRORINFO *pErrInfo, int nValue) {
	QString szBuf;
	szBuf = QString::number(nValue);
	if (MAX_MSG_LEN > pErrInfo->Info.length() + szBuf.length() + wcslen(DELIM)) {
		pErrInfo->Info += szBuf;
		pErrInfo->Info += QString::fromWCharArray(DELIM);
	}
}
void SET_ERR_INFO(V6ERRORINFO &pErrInfo, float fValue) {
	QString szBuf;
	szBuf = QString::number(fValue, 'g');
	if (MAX_MSG_LEN > pErrInfo.Info.length() + szBuf.length() + wcslen(DELIM)) {
		pErrInfo.Info += szBuf;
		pErrInfo.Info += QString::fromWCharArray(DELIM);
	}
}
void SET_ERR_INFO(V6ERRORINFO &pErrInfo, WCHAR *szValue) {
	if (MAX_MSG_LEN > pErrInfo.Info.length() + wcslen(szValue) + wcslen(DELIM)) {
		pErrInfo.Info += QString::fromWCharArray(szValue);
		pErrInfo.Info += QString::fromWCharArray(DELIM);
	}
}
BOOL GetV6String(int nCode, WCHAR *szString) {
	int nStringSize = 0;
	if (szString) {
		//		nStringSize = LoadString(0,nCode,szString,256); ///Load the string from the string table
		return TRUE;
	} else {
		return FALSE;
	}
}
void FormatMsg(V6ERRORINFO &pErrInfo, WCHAR *szMessage, int szMessageBufffSize) {
	WCHAR msg[MAX_MSG_LEN];
	LPVOID lpMsgBuf;
	WCHAR szInfo[MAX_INFO_STRINGS][MAX_MSG_LEN];
	DWORD_PTR args[MAX_INFO_STRINGS];
	size_t nInfLen, nLoopIndex;
	size_t nPrevLoc = 0, nBufCount = 0;
	if (!GetV6String(pErrInfo.Code, msg)) {
#if _MSC_VER < 1400 
		wcscpy(szMessage, msg);
#else
        wcscpy_s(szMessage,szMessageBufffSize ,msg);
#endif
		return;
	}
	for (nLoopIndex = 0; nLoopIndex < MAX_MSG_LEN; nLoopIndex++)  ///Count number of insertion strings
			{
		if (msg[nLoopIndex] == INS_CHAR_C) {
			nBufCount++;
		}
	}
	if (nBufCount > MAX_INFO_STRINGS) ///Validate  insertion string count. Less than 5
	{
		swprintf(szMessage, sizeof(szMessage), L"Invalid message format. Contains %d insertion strings (MAX is 5)",
				nBufCount);
		return;
	}
	nInfLen = pErrInfo.Info.length();
	nBufCount = 0;
	for (nLoopIndex = 0; (nLoopIndex < nInfLen) && (nBufCount < 5); nLoopIndex++) {
		if (pErrInfo.Info.at(nLoopIndex) == DELIM_C) {
#if _MSC_VER < 1400 
			szInfo[nBufCount], pErrInfo.Info + nPrevLoc, nLoopIndex - nPrevLoc
			);
#else
			wcsncpy_s(szInfo[nBufCount],sizeof(szInfo[nBufCount])/sizeof(WCHAR),pErrInfo.Info+nPrevLoc,nLoopIndex-nPrevLoc);
#endif
			szInfo[nBufCount][nLoopIndex - nPrevLoc] = '\0';
			nPrevLoc = nLoopIndex + 1; //+1 to skip the delimiter return itself
			args[nBufCount] = (DWORD_PTR) szInfo[nBufCount];
			nBufCount++;
		}
	}
	for (nLoopIndex = nBufCount; nLoopIndex < MAX_INFO_STRINGS; nLoopIndex++) {
#if _MSC_VER < 1400 
		wcscpy(szInfo[nLoopIndex], L"");
#else
        wcscpy_s(szInfo[nLoopIndex],sizeof(szInfo[nBufCount])/sizeof(WCHAR),"");
#endif
		args[nLoopIndex] = (DWORD_PTR) szInfo[nLoopIndex];
	}
/// TODO: Resolve this
	FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_STRING | FORMAT_MESSAGE_ARGUMENT_ARRAY, msg, 0,
			0, (QString) & lpMsgBuf, 0, (va_list*) args);
	if (szMessage != NULL) {
		if (lpMsgBuf) {
#if _MSC_VER < 1400 
			wcsncpy(szMessage, (WCHAR*) lpMsgBuf, MAX_MSG_LEN - 1);
			szMessage[MAX_MSG_LEN - 1] = '\0';
			wcscpy(szMessage, (WCHAR*) lpMsgBuf);
#else
            wcsncpy_s(szMessage, szMessageBufffSize,(QString )lpMsgBuf,MAX_MSG_LEN -1 );
            szMessage[MAX_MSG_LEN-1] = '\0';
            wcscpy_s(szMessage,szMessageBufffSize,(QString )lpMsgBuf);
#endif
		} else {
#if _MSC_VER < 1400 
			wcscpy(szMessage, L"Message not found");
#else
            wcscpy_s(szMessage,szMessageBufffSize,L"Message not found");
#endif
		}
	}
}

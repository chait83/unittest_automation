#if !defined(ERRORSERVICES_H__INCLUDED_)
#define ERRORSERVICES_H__INCLUDED_
// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the ERRORSERVICES_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// ERRORSERVICES_API functions as being imported from a DLL, wheras this DLL sees symbols
// defined with this macro as being exported.
#include "Defines.h"
//#include <stdlib.h>
//
#include "ErrorDefinitions.h"
#define ERRORSERVICES_API
#define MAX_INFO_STRINGS	5
#define MAX_MESSAGE_LENGTH	16
#define MAX_MSG_LEN			256
/******************************************************* Data Types *******************************************************/
enum V6_MODULE_TYPE {
	VT_MT_NULL,
	V6_MT_CONTROLSEQ,
	V6_MT_MEDIA_MGR,
	V6_MT_LOGGER,
	V6_MT_QUEUE_MGR,
	V6_MT_SCRIPT,
	V6_MT_FUNCPACK,
	V6_MT_PROCESSING,
	V6_MT_LXFACE
};
enum V6_ERROR_TYPES // There could be a redefinition of this (in Trace). Need to be checked and fixed
{
	V6_ET_NULL, V6_INFO, V6_WARNING, V6_ERROR
};
enum V6_EXTRAINO_DATATYPES {
	EI_INT, EI_FLOAT, EI_STRING
};
typedef struct tagV6ERRORINFO {
	V6_ERROR_TYPES Type;
	V6_MODULE_TYPE Module;
	DWORD Code;
	QString Info;
	USHORT sLineNo;
	USHORT sOffset;
} V6ERRORINFO, *PV6ERRORINFO;
/********************************************************** Macros *********************************************************/
#define DELIM L"|"
#define DELIM_C '|'
#define INS_CHAR_C '%'
#define SET_ERROR(err,module,type,code) \
			err.Module = module; \
			err.Type = type; \
			err.Code = code;  
#define SET_ERROR_PTR(err,module,type,code) \
			err->Module = module; \
			err->Type = type; \
			err->Code = code;  
#define CLEAR_ERROR(err) \
			err.Type = V6_ET_NULL; \
			err.Module = VT_MT_NULL; \
			err.Code = V6_E_SUCCESS; \
			err.Info[0] = 0;
#define CLEAR_ERROR_PTR(err) \
			err->Type = V6_ET_NULL; \
			err->Module = VT_MT_NULL; \
			err->Code = V6_E_SUCCESS; \
			err->Info[0] = 0;
#define DECLARE_V6_EXCEPTION \
	V6ERRORINFO l_err; \
	V6_MODULE_TYPE l_module; \
	CLEAR_ERROR(l_err) 
#define DECLARE_V6_EXCEPTION1 \
V6_MODULE_TYPE l_module; \
CLEAR_ERROR(m_err) 
#define DECLARE_V6_EXCEPTION_PTR \
V6_MODULE_TYPE l_module; \
CLEAR_ERROR_PTR(pErrInfo) 
#define BEGIN_EXCEPTION \
	try	\
	{
#define END_EXCEPTION \
	} 
#define THROW_EXCEPTION(x) \
	goto CleanUp; 
#define	CATCH_V6_EXCEPTION \
	catch(V6ERRORINFO) \
	{ \
		goto CleanUp;	\
	} 
#define CATCH_DEF_EXCEPTION_PTR \
	catch(...) \
	{	\
		SET_ERROR_PTR(pErrInfo,l_module,V6_ERROR,V6_E_UNHANDLED_EXCEPTION); \
		goto CleanUp;\
	}	
#define CATCH_DEF_EXCEPTION1 \
	catch(...) \
	{	\
		SET_ERROR(m_err,l_module,V6_ERROR,V6_E_UNHANDLED_EXCEPTION); \
		goto CleanUp;\
	}	
/*This macro is to be used only of DECLARE_V6_EXCEPTION is used. Otherwise will give a compilation error.*/
#define CATCH_DEF_EXCEPTION \
	catch(...) \
	{	\
		SET_ERROR(l_err,l_module,V6_ERROR,V6_E_UNHANDLED_EXCEPTION); \
		goto CleanUp;\
	}	
#define CATCH_AND_ASSIGN_V6_EXCEPTION(x) \
	catch(V6ERRORINFO err) \
	{ \
		x = err; \
		goto CleanUp;	\
	}
#define CLEANUP \
	CleanUp:
#define CATCH_CUSTOM_EXCEPTION(x) \
	catch(x) 
#define CATCH_BEGIN \
	{	
#define CATCH_END \
	}	
/********************************************************* Functions ********************************************************/
void ERRORSERVICES_API FormatMsg(V6ERRORINFO &pErrInfo, WCHAR *szMessage, int szMessageBufffSize);
void ERRORSERVICES_API SET_ERR_INFO(V6ERRORINFO &pErrInfo, float fValue);
void ERRORSERVICES_API SET_ERR_INFO(V6ERRORINFO &pErrInfo, int nValue);
void ERRORSERVICES_API SET_ERR_INFO_PTR(V6ERRORINFO *pErrInfo, int nValue);
void ERRORSERVICES_API SET_ERR_INFO(V6ERRORINFO &pErrInfo, WCHAR *szValue);
#endif

/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Battery
/// @n Filename: BatteryManager.h
/// @n Desc:	 Battery management
///				 
///
// ****************************************************************
// Revision History
// 
//	Sowmya Pothuri 12/Feb/2020 Battery Management
// ****************************************************************
#ifndef __BATTERY_MANAGER_H__
#define __BATTERY_MANAGER_H__
#include "TV6Timer.h"
#include "NVVariables.h"
#include "V6globals.h"
#include <QMutex>
typedef enum {
	BATTERY_MANAGER_OK, BATTERY_MANAGER_FAILED,
} T_BATTERY_MANAGER_RETURN;
//**Class*********************************************************************
///
/// @brief Manage Battery indication and counters within the recorder
/// 
/// Manage the entire battery system
///
/// This class is a singleton.
///
//****************************************************************************
class CBatteryManager {
public:		//Singleton 
	static CBatteryManager* GetHandle();
	void CleanUp();
private:	// Singleton
	CBatteryManager();
	~CBatteryManager() {
	}
	;	// Will never be called
	CBatteryManager(const CBatteryManager&);
	CBatteryManager& operator=(const CBatteryManager&) {
		return *this;
	}
	;
	BOOL PrepareToReset();
	BOOL TriggerAppShutdown();
	QString GetBatteryResetFileName();
	BOOL IsBatteryResetTriggered(QDateTime &stResetTriggerTime);
	BOOL ClearBatteryResetTrigger();
public:	// API methods
	// Initialise and shutdown of device abstraction
	T_BATTERY_MANAGER_RETURN Initialise();
	T_BATTERY_MANAGER_RETURN Process();
	ULONG GetTotalOnTimeInSeconds() {
		return m_TotalOnTimeSeconds.ul;
	}
	;
	ULONG GetTotalLithiumOnTimeInSeconds() {
		return m_TotalOnTimeSecondsLithium.ul;
	}
	;
	////Method that resets the battery life
	BOOL TriggerBatteryReset();
	void CheckAndPerformBatteryReset();
	void ResetBatteryLife();
	//Method that gives remining days left for lithium cell battery 
	long GetLithiumCellLife(bool &bIsLithiumShelfExpired);
	////Method that checks the battery life
	bool CheckLithiumCellLife();
	bool ReflashBatteryMessage();
	long GetLithiumPowerOffHrs() {
		return LITHIUM_LIFE_WHEN_POWER_OFF_HOURS;
	}
	long GetLithiumPowerOnHrs() {
		return LITHIUM_LIFE_WHEN_POWER_ON_HOURS;
	}
	quint64 GetReflashTimeInMilliSec() {
		return MESSAGE_REFLASH_TIME_IN_MILLI_SEC;
	}
	long GetTotalLithiumOnTimeDaysleft();
	BOOL IsBatteryResetPerformed() const {
		return m_bBatteryResetPerformed;
	}
private:	// Methods
private:	// Member variables
	static CBatteryManager *m_pBatManInstance;
	static QMutex m_CreationMutex;
	//30000 - without LDO
	//7920 - 11 months averaged out with LDO [12 months with 25uA and 10months with 30uA]
	static const long LITHIUM_LIFE_WHEN_POWER_OFF_HOURS = 7920;
	static const long LITHIUM_LIFE_WHEN_POWER_ON_HOURS = 5 * 365 * 24;	//shelf life of 5 years
	static const quint64 MESSAGE_REFLASH_TIME_IN_MILLI_SEC = (24 * 60 * 60) * 1000;//Reflash time for battery message warning (24 hrs)
	BOOL m_Initialised;					///< Indicates if the EventManager has been initialised
	CTV6Timer m_BLTimer;									///< Battery reflash timer
	// Pointers to Life history information
	CNVBasicVar *m_pNVTotalOnTime;							///< Total on time ptr to NV Variable
	COMBO_VAR4 m_TotalOnTimeSeconds;						///< counter for total on time in seconds
	CNVBasicVar *m_pNVTotalOnTimeLithium;///< Total on time ptr to NV Variable for lithium use(resettable on cell change)
	COMBO_VAR4 m_TotalOnTimeSecondsLithium;					///< counter for total on time in seconds for lithium use
	bool m_bBootUpLog;
	bool m_bBatteryResetPerformed;
public:
	//Public memebers
};
// Define global accessor within the EventManager rather then V6Globals to avoid adding to other projects
//extern CEventManager *pGlbEventManager;						///< Pointer to the event manager
//#define pEVENTS			pGlbEventManager					///< Event system global
#endif //__BATTERY_MANAGER_H__

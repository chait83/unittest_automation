/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  Modbus Wrapper Class
/// @n Filename:  ModbusWrapper.cpp
/// @n Description: Wrapper for the ModBus master and slave
///
//  **************************************************************************
//  Revision History
//  **************************************************************************
//  $Log[4]:
// 52  Aristos  1.46.1.3.1.0 9/19/2011 4:51:17 PM  Hemant(HAIL) 
//  Stability recorder source code (JI Release) updated for WatchDog
//  Timer functionality.
// 51  Stability Project 1.46.1.3 7/2/2011 4:58:52 PM Hemant(HAIL) 
//  Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
// 50  Stability Project 1.46.1.2 7/1/2011 4:38:31 PM Hemant(HAIL) 
//  Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
// 49  Stability Project 1.46.1.1 3/17/2011 3:20:30 PM  Hemant(HAIL) 
//  Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  $
//
//  **************************************************************************
// Wrapper.cpp: .
//
//////////////////////////////////////////////////////////////////////
// Include FieldTalk package header
#include "MbusRtuSlaveProtocol.hpp"
//#include "MbusAsciiSlaveProtocol.hpp"
#include "MbusTcpSlaveProtocol.hpp"
#include "DiagnosticDataTable.hpp"
// ModBus master schedule stuff, (this will drag in all additional headers)
#include "SlaveDevice.h"
#include "ModbusWrapper.h"
// General X-Series definitions and data items
#include "V6defines.h"
#include "V6globals.h"
#include "V6Config.h"
#include "TraceDefines.h"
#include "ThreadInfo.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
// IMPLEMENT_DYNCREATE( CModbusSlaveThread, QThread )
// IMPLEMENT_DYNCREATE( CModbusMasterThread, QThread )
const long SERVER_RESET_TIMEOUT = 1250000;		///< Time for server reset, 1 1/4 seconds
const long SERVER_RESET_TIMEOUT_NR = 500;			///< No response timout
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
// ModBus stats holder object,
// A singleton to hold and maintain ModBus communications stats and configuration,
// Allows the data to be shared between the ModBus object thread and the UI status display
CModBusStats *CModBusStats::pInstance = NULL;
QMutex CModBusStats::hCreationMutex ;
CModBusStats::CModBusStats() {
}
CModBusStats::~CModBusStats() {
}
//****************************************************************************
/// Modbus data wrapper: Create object/return current handle
///
/// @return	Pointer to the object/new object
///
/// @note
//****************************************************************************
CModBusStats* CModBusStats::GetHandle() {
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;
	if (NULL == pInstance) {

        waitSingleObjectResult = hCreationMutex.tryLock( g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);
		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:
			// Object was signaled
			if (NULL == pInstance) {
				pInstance = new CModBusStats;
				LOG_INFO( TRACE_TRANSFER, "CModBusStats new Instance created");
			}
            hCreationMutex.unlock();

			break;
		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
            V6WarningMessageBox(NULL, "CModBusStats WaitForSingleObject Error", "Error", MB_OK);
			break;
		}
		// Close the Mutex as no longer required

	}
	return pInstance;
}
//****************************************************************************
/// Modbus data wrapper: Initialise data wrapper
///
/// @return	None
///
/// @note None
//****************************************************************************
void CModBusStats::Initialise() {
	m_pCommunications = NULL;
	Clear();
}
//****************************************************************************
/// Modbus data wrapper: Clean-up prior to a shut-down
///
/// @return	None
///
/// @note None
//****************************************************************************
void CModBusStats::CleanUp() {
	m_pCommunications = NULL;
	delete pInstance;
	pInstance = NULL;
}
//****************************************************************************
/// Modbus data wrapper: Clear current stats
///
/// @return	None
///
/// @note None
//****************************************************************************
void CModBusStats::Clear() {
	m_ulGoodMessages = 0L;
	m_ulBadMessages = 0L;
	m_ulSystemErrors = 0L;
}
//****************************************************************************
/// Modbus data wrapper: Update the current configuration (after a config change)
///
/// @return	TRUE new configuration was found, else FALSE
///
/// @note
//****************************************************************************
BOOL CModBusStats::SetConfiguration() {
	CCommsSetupConfig *pNewConfig = pGlbSetup->GetCommsSetupConfig();
	m_pCommunications = pNewConfig->GetCommsBlock(CONFIG_COMMITTED);
	if (NULL != m_pCommunications)
		return TRUE;
	else
		return FALSE;
}
//****************************************************************************
/// Modbus data wrapper: check if ModBus is enabled
///
/// @return	TRUE if ModBus is enabled, else FALSE
///
/// @note None
//****************************************************************************
BOOL CModBusStats::IsEnabled() {
	BOOL bResult = FALSE;
	if (NULL != m_pCommunications) {
		if ( TRUE == m_pCommunications->ModbusSlave.Enabled)
			bResult = TRUE;
	}
	return bResult;
}
//****************************************************************************
/// Modbus data wrapper: check if ethernet comms are enabled
///
/// @return	TRUE if Ethernet is enabled, else FALSE
///
/// @note None
//****************************************************************************
BOOL CModBusStats::IsEthernet() {
	BOOL bResult = FALSE;
	if (NULL != m_pCommunications) {
		if (PORT_ETHER == m_pCommunications->ModbusSlave.Port)
			bResult = TRUE;
	}
	return bResult;
}
//////////////////////////////////////////////////////////////////////////////
// Modbus slave wrapper
//////////////////////////////////////////////////////////////////////////////
CModBusSlave::CModBusSlave(T_MODULE_ID moduleId) : CV6ActiveModule(moduleId) {
	SetSlaveState(TS_INITIALISE);
}
//****************************************************************************
/// Modbus wrapper: perform primary initialisation
///
/// @note ActiveModule method
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE CModBusSlave::PerformPrimaryInitialisation(void) {
	T_V6ACTMOD_RETURN_VALUE retVal = V6ACTMOD_OK;
	m_Slave.Enabled = FALSE;
	SetSlaveState(TS_INITIALISE);
	return retVal;
}
//****************************************************************************
/// Modbus wrapper: perform secondary initialisation
///
/// @note ActiveModule method
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE CModBusSlave::PerformSecondaryInitialisation(void) {
	T_V6ACTMOD_RETURN_VALUE retVal = V6ACTMOD_OK;
	return retVal;
}
//****************************************************************************
/// Modbus wrapper: perform normal operation
///
/// @note ActiveModule method
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE CModBusSlave::NormalOperation(void) {
	T_V6ACTMOD_RETURN_VALUE retVal = V6ACTMOD_OK;
#ifndef V6IOTEST
	SetSlaveState(TS_RUNNING);
#endif
	return retVal;
}
//****************************************************************************
/// Modbus wrapper: perform configuration change preperation
///
/// @note ActiveModule method
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE CModBusSlave::SetupConfigChangePreparation(void) {
	T_V6ACTMOD_RETURN_VALUE retVal = V6ACTMOD_OK;
	CModBusStats *pModBusStats = CModBusStats::GetHandle();
#ifndef V6IOTEST
	m_Slave.m_IsInIdleState = FALSE;
	SetSlaveState(TS_CONFIG_PREPARE);
#endif
	// Clear the current configuration during the configuration change
	pModBusStats->ClearConfiguration();
	return retVal;
}
//****************************************************************************
/// Modbus wrapper: perform configuration change
///
/// @note ActiveModule method
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE CModBusSlave::SetupConfigChangeComplete(void) {
	T_V6ACTMOD_RETURN_VALUE retVal = V6ACTMOD_OK;
	CModBusStats *pModBusStats = CModBusStats::GetHandle();
	// Pick-up a (possably) new configuration after the config change
	pModBusStats->SetConfiguration();
	pModBusStats->Clear();			// Clear current stats, config changed so (potentialy) no-longer have any meaning.
#ifndef V6IOTEST
	// Pass master and slave threads new configuration data
	m_Slave.m_IsInIdleState = FALSE;
	SetSlaveState(TS_CONFIGURE);
#endif
	return retVal;
}
//****************************************************************************
/// Modbus wrapper: perform shut-down preperation
///
/// @note ActiveModule method
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE CModBusSlave::ShutdownPreparation(void) {
	T_V6ACTMOD_RETURN_VALUE retVal = V6ACTMOD_OK;
#ifndef V6IOTEST
// Allow the thread to close
	m_Slave.m_IsInIdleState = FALSE;
	SetSlaveState(TS_IDLE);
#endif
	return retVal;
}
//****************************************************************************
/// Modbus wrapper: perform module shut-down
///
/// @note ActiveModule method
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE CModBusSlave::Shutdown(void) {
	T_V6ACTMOD_RETURN_VALUE retVal = V6ACTMOD_OK;
	SetSlaveState(TS_SHUTDOWN);
	CModBusStats *pModBusStats = CModBusStats::GetHandle();
	if (NULL != pModBusStats)
		pModBusStats->CleanUp();
	return retVal;
}
/////////////////////////////////////////
// Modbus slave thread
/////////////////////////////////////////
CModbusSlaveThread::CModbusSlaveThread() {
}
CModbusSlaveThread::~CModbusSlaveThread() {
}

UINT CModbusSlaveThread::ThreadFunc(LPVOID lpParam)
{
	//QString  strErrorMsg;
	//strErrorMsg.Format( L"CModbusSlaveThread ID: 0x%008X\n", 
	//									QThread::currentThreadId() );
	//
	//LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_INFO, strErrorMsg );
	CModBusSlave *pModBusWrapper = (CModBusSlave *)lpParam;
	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//after each iteration
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	//Notify that the WatchdogTimer that the ModbusSlave thread has 
	//started
	if(pThreadInfo != NULL)
	{
		pThreadInfo->UpdateThreadInfo(AM_MODBUS_SLAVE,true);
	}
#ifdef THREAD_ID_SERIAL_LOG
	WCHAR szDbgMsg[512];
	swprintf( szDbgMsg, L"CModbusSlaveThread::ThreadFunc-Thread id 0x%x, %lu ", GetThreadId(GetCurrentThread()), GetThreadId(GetCurrentThread()));
	OutputDebugString(szDbgMsg);
#endif
	while( TS_SHUTDOWN != pModBusWrapper->GetSlaveState() )
	{
		pModBusWrapper->EventMessageHandler( IGNORE );
		ProcessSlave( pModBusWrapper );
		if(pThreadInfo != NULL)
		{
			//Update the Thread Counter for the ModbusSlave
			//thread after each iteration
			pThreadInfo->UpdateThreadCounter(AM_MODBUS_SLAVE);
		}
	}
	//Update the info that the ModbusSlave thread is exiting
	//Hence this thread need not be considered to kick the 
	//watchdog
	if(pThreadInfo != NULL)
	{
		pThreadInfo->UpdateThreadInfo(AM_MODBUS_SLAVE);
	}
	return 0;
}
//****************************************************************************
/// Modbus process modbus slave time slice
///
///
/// @note --- Delete if not requried ---
//****************************************************************************
// private static
void CModbusSlaveThread::ProcessSlave(CModBusSlave *pModBusWrapper) {
	int result = FTALK_SUCCESS;
	static MbusSlaveServer *mbusServerPtr = NULL;
	static CTV6Timer *ElapseTimer = NULL;
	if (NULL == ElapseTimer) {
		ElapseTimer = new (CTV6Timer)(TIMER_HIGH_RES);
	}
	CModBusStats *pModBusStats = CModBusStats::GetHandle();
	switch (pModBusWrapper->GetSlaveState()) {
	case TS_INITIALISE:						// Thread initialisation
		sleep(100);
		break;
	case TS_IDLE:							// Thread idle (waiting)
		pModBusWrapper->m_Slave.m_IsInIdleState = TRUE;
		sleep(100);
		break;
	case TS_CONFIG_PREPARE:					// Prepare for config change
		if (mbusServerPtr != NULL) {
			mbusServerPtr->shutdownServer();
			delete (mbusServerPtr);
			mbusServerPtr = NULL;
		}
		pModBusWrapper->SetSlaveState(TS_IDLE);
		break;
	case TS_CONFIGURE:						// Thread configure/re-configure
		mbusServerPtr = CreateModbusSlave(&pModBusWrapper->m_Slave);
		pModBusWrapper->SetSlaveState(TS_IDLE);
		break;
	case TS_RUNNING:					// Thread running
		if (NULL != mbusServerPtr) {
			// Check if the ModBis Slave Server is running, an internal error can
			// cause the server to close without an error code.
			if ( FALSE == mbusServerPtr->isStarted()) {
				mbusServerPtr->shutdownServer();						// Server isn't started, destroy and re-create
				delete (mbusServerPtr);
				mbusServerPtr = CreateModbusSlave(&pModBusWrapper->m_Slave);
			} else {
				LONG lElapsed = 0L;
				ElapseTimer->StartTimer();
				result = mbusServerPtr->serverLoop();
				ElapseTimer->StopTimer();
				if (PORT_ETHER == pModBusWrapper->m_Slave.m_Port) {
					lElapsed = (LONG) ElapseTimer->GetTimeInMicroSec(TIMER_SINGLE);
					if ((SERVER_RESET_TIMEOUT < lElapsed || SERVER_RESET_TIMEOUT_NR > lElapsed)
							&& FTALK_SUCCESS == result) {
						// result = (FTALK_CONNECTION_WAS_CLOSED);
						// qDebug(" ServerLoop Reset %ld\n", lElapsed );
					}
				}
				//qDebug(" ServerLoop %ld\n", lElapsed );
				sleep(2);
				switch (result) {
				case (FTALK_ILLEGAL_STATE_ERROR):								// Server didn't start when requested
					pModBusStats->SystemMessage();
					break;
				case (FTALK_FILEDES_EXCEEDED):									// returned when we run-out of sockets
					pModBusStats->SystemMessage();
					break;
				case (FTALK_CONNECTION_WAS_CLOSED):	// Connection was closed, could be an internal error, or by the master
				{
					mbusServerPtr->shutdownServer();						// re-create and wait for another connection
					delete (mbusServerPtr);
					mbusServerPtr = CreateModbusSlave(&pModBusWrapper->m_Slave);
				}
					break;
				case (FTALK_IO_ERROR):											// General I/O Error
					pModBusStats->SystemMessage();
					break;
				case (FTALK_CHECKSUM_ERROR):				// Not currently returned on CE build, OK on the desktop??
					pModBusStats->BadMessage();
					break;
				case (FTALK_SUCCESS):												// Message received OK
					pModBusStats->GoodMessage();
					break;
				default:
					//				pModBusStats->BadMessage( );
					break;
				}
			}
		} else
			sleep(100);
		break;
	case TS_SHUTDOWN:					// Thread shut-down 
		if (NULL != pModBusStats) {
			pModBusStats->CleanUp();
			pModBusStats = NULL;
		}
		if (NULL != mbusServerPtr) {
			delete (mbusServerPtr);
			mbusServerPtr = NULL;
		}
		if (NULL != ElapseTimer) {
			delete (ElapseTimer);
			ElapseTimer = NULL;
		}
		break;
	}
}
//****************************************************************************
/// Modbus slave create
/// Creates and configures the required Modbus slave object
///
/// @param[in] 	 Slave - Modbus Slave shared data
///
/// returns pointer to the Modbus slave object or NULL if creation failed
///
/// @note --- Delete if not requried ---
//****************************************************************************
// Private Static
MbusSlaveServer* CModbusSlaveThread::CreateModbusSlave(MODBUS_SLAVE *Slave) {
	BOOL bSlaveEnabled = FALSE;
	int result = FTALK_SUCCESS;
	MbusSlaveServer *mbusServerPtr = NULL;
	CModBusStats *pModBusStats = CModBusStats::GetHandle();
	T_PCOMMUNICATIONS pCommunications = pModBusStats->CurrentConfiguration();
	if (NULL != pCommunications) {
		bSlaveEnabled = pCommunications->ModbusSlave.Enabled;
		if (NULL != pModBusStats && bSlaveEnabled) {
			Slave->m_Port = pCommunications->ModbusSlave.Port;
			switch (pCommunications->ModbusSlave.Port) {
			case PORT_SERIAL:
				sleep(1000);
				mbusServerPtr = new MbusRtuSlaveProtocol(&Slave->dataTable);
				if (NULL != mbusServerPtr) {
					WCHAR *PortName = L"COM1:";
					LONG BaudRate = 9600;
					int DataBits = 8;
					int StopBits = 1;
					int Parity = MbusSerialSlaveProtocol::SER_PARITY_NONE;
					switch (pCommunications->SerialPort.BaudRate) {
					case BD_2400:
						BaudRate = 2400;
						break;
					case BD_4800:
						BaudRate = 4800;
						break;
					case BD_9600:
						BaudRate = 9600;
						break;
					case BD_19200:
						BaudRate = 19200;
						break;
					case BD_38400:
						BaudRate = 38400;
						break;
					case BD_56700:
						BaudRate = 56700;
						break;
					case BD_115200:
						BaudRate = 115200;
						break;
					}
					switch (pCommunications->SerialPort.ByteOptions) {
					case N_8_1:
						DataBits = 8;
						Parity = MbusSerialSlaveProtocol::SER_PARITY_NONE;
						StopBits = 1;
						break;
					case E_8_1:
						DataBits = 8;
						Parity = MbusSerialSlaveProtocol::SER_PARITY_EVEN;
						StopBits = 1;
						break;
					case O_8_1:
						DataBits = 8;
						Parity = MbusSerialSlaveProtocol::SER_PARITY_ODD;
						StopBits = 1;
						break;
					case N_8_2:
						DataBits = 8;
						Parity = MbusSerialSlaveProtocol::SER_PARITY_NONE;
						StopBits = 2;
						break;
					}
					mbusServerPtr->setTimeout( MB_RS_SLAVE_TIMEOUT);
					result = ((MbusAsciiSlaveProtocol*) mbusServerPtr)->startupServer(
							pCommunications->ModbusSlave.Address, PortName, BaudRate, DataBits, StopBits, Parity);
				}
				break;
			case PORT_ETHER:
				// Configure and open the ethernet port
				mbusServerPtr = new MbusTcpSlaveProtocol(&Slave->dataTable);
				if (NULL != mbusServerPtr) {
					mbusServerPtr->setTimeout( MB_EN_SLAVE_TIMEOUT);
					((MbusTcpSlaveProtocol*) mbusServerPtr)->setPort(pCommunications->Ethernet.ModbusSocket);
					result = ((MbusTcpSlaveProtocol*) mbusServerPtr)->startupServer(
							pCommunications->ModbusSlave.Address);
				}
				break;
			default:
				mbusServerPtr = NULL;
				break;
			}
		} // SlaveEnabled
	}
	return mbusServerPtr;
}
///////////////////////////////////////////////
// Modbus master wrapper
//////////////////////////////////////////////////////////////////////////////
// Active module methods
CModBusMaster::CModBusMaster(T_MODULE_ID moduleId) : CV6ActiveModule(moduleId) {
	SetMasterState(TS_INITIALISE);
	ScheduleWrapper = CModBusSchedule::GetHandle();
}
//****************************************************************************
/// Modbus wrapper: perform primary initialisation
///
/// @note ActiveModule method
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE CModBusMaster::PerformPrimaryInitialisation(void) {
	T_V6ACTMOD_RETURN_VALUE retVal = V6ACTMOD_OK;
	m_Master.Enabled = FALSE;
	SetMasterState(TS_INITIALISE);
	return retVal;
}
//****************************************************************************
/// Modbus wrapper: perform secondary initialisation
///
/// @note ActiveModule method
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE CModBusMaster::PerformSecondaryInitialisation(void) {
	T_V6ACTMOD_RETURN_VALUE retVal = V6ACTMOD_OK;
	SetMasterState(TS_INITIALISE);
	return retVal;
}
//****************************************************************************
/// Modbus wrapper: perform normal operation
///
/// @note ActiveModule method
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE CModBusMaster::NormalOperation(void) {
	T_V6ACTMOD_RETURN_VALUE retVal = V6ACTMOD_OK;
#ifndef V6IOTEST
	SetMasterState(TS_RUNNING);
#endif
	return retVal;
}
//****************************************************************************
/// Modbus wrapper: perform configuration change preperation
///
/// @note ActiveModule method
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE CModBusMaster::SetupConfigChangePreparation(void) {
	T_V6ACTMOD_RETURN_VALUE retVal = V6ACTMOD_OK;
#ifndef V6IOTEST
	SetMasterState(TS_CONFIG_PREPARE);
#endif
	return retVal;
}
//****************************************************************************
/// Modbus wrapper: perform configuration change
///
/// @note ActiveModule method
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE CModBusMaster::SetupConfigChangeComplete(void) {
	T_V6ACTMOD_RETURN_VALUE retVal = V6ACTMOD_OK;
#ifndef V6IOTEST
	SetMasterState(TS_CONFIGURE);
#endif
	return retVal;
}
//****************************************************************************
/// Modbus wrapper: perform shut-down preperation
///
/// @note ActiveModule method
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE CModBusMaster::ShutdownPreparation(void) {
	T_V6ACTMOD_RETURN_VALUE retVal = V6ACTMOD_OK;
#ifndef V6IOTEST
	SetMasterState(TS_IDLE);
#endif
	return retVal;
}
//****************************************************************************
/// Modbus wrapper: perform module shut-down
///
/// @note ActiveModule method
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE CModBusMaster::Shutdown(void) {
	T_V6ACTMOD_RETURN_VALUE retVal = V6ACTMOD_OK;
	SetMasterState(TS_SHUTDOWN);
	return retVal;
}
/////////////////////////////////////////
// Modbus master thread
/////////////////////////////////////////
CModbusMasterThread::CModbusMasterThread() {
}
CModbusMasterThread::~CModbusMasterThread() {
}
//****************************************************************************
/// Modbus wrapper: message processing thread
///
/// @note ActiveModule method
//****************************************************************************

UINT CModbusMasterThread::ThreadFunc(LPVOID lpParam)
{
	/*QString  strErrorMsg;
	 strErrorMsg.Format( L"CModbusMasterThread ID: 0x%008X\n", 
	 QThread::currentThreadId() );
	 
	 LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_INFO, strErrorMsg );*/
	CModBusMaster *pModBusMasterWrapper = (CModBusMaster *)lpParam;
	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//after each iteration
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	//Notify that the WatchdogTimer that the ModbusMaster thread has 
	//started
	if(pThreadInfo != NULL)
	{
		pThreadInfo->UpdateThreadInfo(AM_MODBUS_MASTER,true);
	}
#ifdef THREAD_ID_SERIAL_LOG
	WCHAR szDbgMsg[512];
	swprintf( szDbgMsg, L"CModbusMasterThread::ThreadFunc-Thread id 0x%x, %lu ", GetThreadId(GetCurrentThread()), GetThreadId(GetCurrentThread()));
	OutputDebugString(szDbgMsg);
#endif
	while( TS_SHUTDOWN != pModBusMasterWrapper->GetMasterState() )
	{
		pModBusMasterWrapper->EventMessageHandler( IGNORE );
		ProcessMaster( pModBusMasterWrapper );
		//sleep(100);
		if(pThreadInfo != NULL)
		{
			//Update the Thread Counter for the ModbusMaster
			//after each iteration
			pThreadInfo->UpdateThreadCounter(AM_MODBUS_MASTER);
		}
	}
	//Update the info that the ModbusMaster thread is exiting
	//Hence this thread need not be considered to kick the 
	//watchdog
	if(pThreadInfo != NULL)
	{
		pThreadInfo->UpdateThreadInfo(AM_MODBUS_MASTER);
	}
	return 0;
}
//****************************************************************************
/// Modbus process modbus master time slice
///
///
/// @note --- Delete if not requried ---
//****************************************************************************
// private static
void CModbusMasterThread::ProcessMaster(CModBusMaster *pModBusMasterWrapper) {
	switch (pModBusMasterWrapper->GetMasterState()) {
	case TS_INITIALISE:						// Thread initialisation
		//qDebug("CModbusMasterThread::TS_INITIALISE.\n" );
		pModBusMasterWrapper->ScheduleWrapper->Initialise();
		pModBusMasterWrapper->SetMasterState(TS_IDLE);
		sleep(100);
		break;
	case TS_IDLE:							// Thread idle (waiting)
		//qDebug("CModbusMasterThread::TS_IDLE.\n" );
		sleep(100);
		break;
	case TS_CONFIG_PREPARE:					// Prepare for config change
		//qDebug("CModbusMasterThread::TS_CONFIG_PREPARE.\n" );
		pModBusMasterWrapper->ScheduleWrapper->CleanUp();
		pModBusMasterWrapper->SetMasterState(TS_IDLE);
		sleep(100);
		break;
	case TS_CONFIGURE:						// Thread configure/re-configure
		//qDebug("CModbusMasterThread::TS_CONFIGURE.\n" );
		//pModBusMasterWrapper->ScheduleWrapper.BuildTestData( );
		pModBusMasterWrapper->ScheduleWrapper->BuildSchedule();
		pModBusMasterWrapper->SetMasterState(TS_IDLE);
		break;
	case TS_RUNNING:					// Thread running
		//qDebug("CModbusMasterThread::TS_RUNNING.\n" );
		pModBusMasterWrapper->ScheduleWrapper->RunMasterSchedule();
		break;
	case TS_SHUTDOWN:					// Thread shut-down 
		//qDebug("CModbusMasterThread::TS_SHUTDOWN.\n" );
		pModBusMasterWrapper->ScheduleWrapper->CleanUp();
		pModBusMasterWrapper->ScheduleWrapper->Destroy();
		break;
	}
}

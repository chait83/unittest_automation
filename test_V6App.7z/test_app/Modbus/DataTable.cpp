/// @file 
/// *****************************************************************
///  Honeywell Trendview
/// *****************************************************************
/// @n Module  : ModBus Slave
/// @n FileName: DataTable.cpp
/// @n Desc  : ModBus data table
/// 
/// *****************************************************************
/// Revision History
/// *****************************************************************
/// $Log[4]:
///  60  Stability Project 1.55.1.3 7/2/2011 4:56:39 PM Hemant(HAIL) 
/// Stability Project: Recorder source has been upgraded from IL
/// version of firmware to JF version of firmware.
///  59  Stability Project 1.55.1.2 7/1/2011 4:38:13 PM Hemant(HAIL) 
/// Stability Project: Files has been checked in before the merging
/// task. The merging will be done between IL version of firmware and JF
/// version of firmware. 
///  58  Stability Project 1.55.1.1 3/17/2011 3:20:21 PM  Hemant(HAIL) 
/// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
/// new operator in DEBUG mode only. To detect memory leaks in files, use
/// it in preprocessor definition when in debug mode.
///  57  Stability Project 1.55.1.0 2/15/2011 3:02:54 PM  Hemant(HAIL) 
/// File updated during Heap Management. Call to the default behaviour
/// of new operator has been commented.
/// $
///
// Platform header
#include <stdio.h>
#include <string.h>
#include "MessageListServices.h"
#include "BrdInfo.h"
#include "TraceDefines.h"
#include "ModbusWrapper.h"
//
// Package header
#include "DataTable.hpp"
#include "PenManager.h"
/*****************************************************************************
 * DiagnosticMbusDataTable class declaration
 *****************************************************************************/
/*
 Overloads for the Modbus data item table.
 */
//extern CDataItemTable Glb_datatable; // Global datatable (for now)
/*******************************************************************************
 Description - Swap a Real (Float)
 Parameters	 -  Val, float to reorder
 Returns	 - Byte swapped Words.
 ********************************************************************************/
void MbusDataTable::ModFloatSwap(FLOAT_ORDER order, float &fIn, float &fOut) {
	ModSwap *pIn = (ModSwap*) &fIn;
	ModSwap *pOut = (ModSwap*) &fOut;
	switch (order) {
	case FP_B:					// 4,3,2,1
		fOut = fIn;
		break;
	case FP_BB:					// 3,4,1,2
		pOut->Byte[0] = pIn->Byte[3];
		pOut->Byte[1] = pIn->Byte[2];
		pOut->Byte[2] = pIn->Byte[1];
		pOut->Byte[3] = pIn->Byte[0];
		break;
	case FP_L:					// 1,2,3,4
		pOut->Byte[0] = pIn->Byte[1];
		pOut->Byte[1] = pIn->Byte[0];
		pOut->Byte[2] = pIn->Byte[3];
		pOut->Byte[3] = pIn->Byte[2];
		break;
	case FP_LB:					// 2,1,3,4
		pOut->Word[1] = pIn->Word[0];
		pOut->Word[0] = pIn->Word[1];
		break;
	}
}
//****************************************************************************
/// Message timeout handler
///		Currently just calls the DiagnosticDataTable default timeout handler.
///
/// @note --- Delete if not requried ---
//****************************************************************************	
void MbusDataTable::timeOutHandler() {
	MbusDataTableInterface::timeOutHandler();
}
//****************************************************************************
/// Read Modbus exception status
///		Currently just calls the DiagnosticDataTable default exception status handler.
///
/// @note --- Delete if not requried ---
//****************************************************************************	
char MbusDataTable::readExceptionStatus() {
	return MbusDataTableInterface::readExceptionStatus();
}
//****************************************************************************
/// Modbus Read Input Register
///
/// @param[in] 		StartRef Start register offset
/// @param[in] 		regArr[] Array to deposit the result	
/// @param[in] 		refCount Register count to return
///
/// @return 1 for success
///
/// @note Read pen value
//****************************************************************************
int MbusDataTable::readInputRegistersTable(int startRef, short regArr[], int refCnt) {
	return readHoldingRegistersTable(startRef, regArr, refCnt);
}
//****************************************************************************
/// Modbus Read Discrete Inputs
///
/// @param[in] 		StartRef Start register offset
/// @param[in] 		regArr[] Array to deposit the result	
/// @param[in] 		refCount Register count to return
///
/// @return 1 for success
///
/// @note Read analogue input
//****************************************************************************
int MbusDataTable::readInputDiscretesTable(int startRef, char bitArr[], int refCnt) {
	return readCoilsTable(startRef, bitArr, refCnt);
}
//****************************************************************************
/// Modbus Read Coil Table
///
/// @param[in] 		StartRef Start register offset
/// @param[in] 		regArr[] Array to deposit the result	
/// @param[in] 		refCount Register count to return
///
/// @return 1 for success
///
/// @note Read digital input
//****************************************************************************
int MbusDataTable::readCoilsTable(int startRef, char bitArr[], int refCnt) {
	T_PCOMMUNICATIONS pCommunications = NULL;
	CCommsSetupConfig *pNewConfig = pGlbSetup->GetCommsSetupConfig();
	pCommunications = pNewConfig->GetCommsBlock(CONFIG_COMMITTED);
	CDataItem *DataItem = NULL;
	CBrdInfo *pBoardInfo = CBrdInfo::GetHandle();
	for (int di = (startRef - 1); di < refCnt; di++) {
		if (di < (MOD_DIG_LEN - 1)) {
			if ( CHANNEL_DI == pBoardInfo->WhatModbusSelectedDigChannelType(di, ZERO_BASED) ||
			CHANNEL_DO == pBoardInfo->WhatModbusSelectedDigChannelType(di, ZERO_BASED)) {
				DataItem = (CDataItem*) pGlbDIT->GetDataItemPtr(DI_IO, DI_IO_DIGITAL, di);
				if (DataItem->GetFPValue() != 0)
					bitArr[di] = 1;
				else
					bitArr[di] = 0;
			} else
				bitArr[di] = 0;
		} else if (di == (MOD_DIG_LEN - 1)) {
			DataItem = (CDataItem*) pGlbDIT->GetDataItemPtr(DI_IO, DI_IO_MISC, DI_IO_DIG_POWERRELAY);
			if (DataItem->GetFPValue() != 0)
				bitArr[di] = 1;
			else
				bitArr[di] = 0;
		} else
			bitArr[di] = 0;
	}
	sleep(pCommunications->SerialPort.ReplyDelay);
	return 1;
}
//****************************************************************************
/// Modbus Write Coil Table
///
/// @param[in] 		StartRef Start register offset
/// @param[in] 		regArr[] Array of coil data	
/// @param[in] 		refCount Register count to return
///
/// @return 1 for success
///
/// @note Write digital output
//****************************************************************************
int MbusDataTable::writeCoilsTable(int startRef, const char bitArr[], int refCnt) {
	T_PCOMMUNICATIONS pCommunications = NULL;
//	CCommsSetupConfig *pNewConfig = pGlbSetup->GetCommsSetupConfig();
//	pCommunications = pNewConfig->GetCommsBlock( CONFIG_COMMITTED );
#if ! defined ( DOCVIEW ) && ! defined ( TTR6SETUP )
	CModBusStats *pModBusStats = CModBusStats::GetHandle();
	pCommunications = pModBusStats->CurrentConfiguration();
#endif
	int count = 0;
	CDataItem *DataItem = NULL;
	CBrdInfo *pBoardInfo = CBrdInfo::GetHandle();
	for (int di = (startRef - 1); di < (startRef + refCnt - 1); di++) {
		if (di < (MOD_DIG_LEN - 1)) {
			if ( CHANNEL_DO == pBoardInfo->WhatModbusSelectedDigChannelType(di, ZERO_BASED) ||
			CHANNEL_DI == pBoardInfo->WhatModbusSelectedDigChannelType(di, ZERO_BASED)) {
				DataItem = (CDataItem*) pGlbDIT->GetDataItemPtr(DI_IO, DI_IO_DIGITAL, di);
				if (bitArr[count] != 0)
					DataItem->SetValue(1.0);
				else
					DataItem->SetValue(0.0);
			}
		} else if (di == (MOD_DIG_LEN - 1)) {
			DataItem = (CDataItem*) pGlbDIT->GetDataItemPtr(DI_IO, DI_IO_MISC, DI_IO_DIG_POWERRELAY);
			if (bitArr[count] != 0)
				DataItem->SetValue(1.0);
			else
				DataItem->SetValue(0.0);
		}
	}
	sleep(pCommunications->SerialPort.ReplyDelay);
	return 1;
}
//****************************************************************************
/// Modbus Read Holding Register
///
/// @param[in] 		StartRef Start register offset
/// @param[in] 		regArr[] Array to deposit the result
/// @param[in] 		refCount Register count to return
///
/// @return 1 for success
///
/// @note Read comms variables
//****************************************************************************
int MbusDataTable::readHoldingRegistersTable(int startRef, short regArr[], int refCnt) {
	CBrdInfo *pBoardInfo = CBrdInfo::GetHandle();
	T_CONFIG_RETURN_VALUE retValue = CONFIG_OK;
	T_PCOMMUNICATIONS pCommunications = NULL;
//	CCommsSetupConfig *pNewConfig = pGlbSetup->GetCommsSetupConfig();
//	pCommunications = pNewConfig->GetCommsBlock( CONFIG_COMMITTED );
#if ! defined ( DOCVIEW ) && ! defined ( TTR6SETUP )
	CModBusStats *pModBusStats = CModBusStats::GetHandle();
	pCommunications = pModBusStats->CurrentConfiguration();
#endif
	if (pCommunications == NULL) {
		qDebug("NULL pointer returned for pCommunications in read = pNewConfig->GetCommsBlock \n");
		return (1);
	}
	FLOAT_ORDER byteOrder = FP_LB;
	if (PR_MODBUS == pCommunications->ModbusSlave.Protocol)
		byteOrder = FP_B;
	if (NULL != pCommunications) {
		// Analogue inputs
		if (startRef > MOD_ANALOGUE_START && startRef <= (MOD_ANALOGUE_START + MOD_ANALOGUE_LEN)) {
			float *fbuffer = (float*) &regArr[0];
			USHORT StartPen = ((startRef - (MOD_ANALOGUE_START + 1)) / 2);
			float Value = 0.0F;
			USHORT Count = 0;
			for (USHORT Instance = StartPen; Instance < StartPen + (refCnt / 2); Instance++) {
				if ( CHANNEL_AI == pBoardInfo->WhatModbusSelectedAnalChannelType(Instance, ZERO_BASED)
						&& Instance < (MOD_ANALOGUE_LEN / 2)) {
					CDataItem *DataItem = (CDataItem*) pGlbDIT->GetDataItemPtr(DI_IO, DI_IO_ANALOGUE, Instance);
					Value = DataItem->GetFPValue();
				} else {
					// Data is beyond the modbus map, just return 0.0
					Value = 0.0F;
				}
				ModFloatSwap(byteOrder, Value, fbuffer[Count]);
				Count++;
			}
		}
		// Comms variables
		else if (startRef > MOD_COMPEN_START && startRef <= (MOD_COMPEN_START + MOD_COMPEN_LEN)) {
			float *fbuffer = (float*) &regArr[0];
			USHORT StartPen = ((startRef - (MOD_COMPEN_START + 1)) / 2);
			float Value = 0.0F;
			USHORT Count = 0;
			for (USHORT Instance = StartPen; Instance < StartPen + (refCnt / 2); Instance++) {
				if (Instance < (MOD_COMPEN_LEN / 2)) {
					CDataItem *DataItem = (CDataItem*) pGlbDIT->GetDataItemPtr(DI_GENERAL, DI_GENTYPE_GENERAL,
							DI_GEN_COMMS_VAR_IN_FIRST + Instance);
					Value = DataItem->GetFPValue();
				} else {
					// Data is beyond the modbus map, just return 0.0
					Value = 0.0F;
				}
				ModFloatSwap(byteOrder, Value, fbuffer[Count]);
				Count++;
			}
		}
		// Pen values
		else if (startRef > MOD_PEN_START && startRef <= (MOD_PEN_START + MOD_PEN_LEN)) {
			float *fbuffer = (float*) &regArr[0];
			USHORT StartPen = ((startRef - (MOD_PEN_START + 1)) / 2);
			float Value = 0.0F;
			USHORT Count = 0;
			for (USHORT Instance = StartPen; Instance < StartPen + (refCnt / 2); Instance++) {
				if ( pSYSTEM_INFO->IsPenAvailable(Instance, ZERO_BASED) == TRUE && Instance < (MOD_PEN_LEN / 2)) {
					CDataItem *DataItem = (CDataItem*) pGlbDIT->GetDataItemPtr(DI_PEN, 0, Instance);
					Value = DataItem->GetFPValue();
				} else {
					// Data is beyond the modbus map, just return 0.0
					Value = 0.0F;
				}
				ModFloatSwap(byteOrder, Value, fbuffer[Count]);
				Count++;
			}
		}
		// Totals
		else if (startRef > MOD_TOTALS_START && startRef <= (MOD_TOTALS_START + MOD_TOTALS_LEN)) {
			float *fbuffer = (float*) &regArr[0];
			USHORT StartPen = ((startRef - (MOD_TOTALS_START + 1)) / 2);
			float Value = 0.0F;
			USHORT Count = 0;
			for (USHORT Instance = StartPen; Instance < StartPen + (refCnt / 2); Instance++) {
				if ( pSYSTEM_INFO->FWOptionTotalsAvailable() && Instance < (MOD_TOTALS_LEN / 2)) {
					CDataItem *DataItem = (CDataItem*) pGlbDIT->GetDataItemPtr(DI_TOTAL, DI_TOTAL_READING, Instance);
					Value = DataItem->GetFPValue();
				} else {
					// Data is beyond the modbus map, just return 0.0
					Value = 0.0F;
				}
				ModFloatSwap(byteOrder, Value, fbuffer[Count]);
				Count++;
			}
		}
		// Extended comms variables
		else if (startRef > MOD_EXCOMPEN_START && startRef <= (MOD_EXCOMPEN_START + MOD_EXCOMPEN_LEN)) {
			float *fbuffer = (float*) &regArr[0];
			USHORT StartPen = ((startRef - (MOD_EXCOMPEN_START + 1)) / 2);
			float Value = 0.0F;
			USHORT Count = 0;
			for (USHORT Instance = StartPen; Instance < StartPen + (refCnt / 2); Instance++) {
				if (Instance < (MOD_EXCOMPEN_LEN / 2)) {
					CDataItem *DataItem = (CDataItem*) pGlbDIT->GetDataItemPtr(DI_GENERAL, DI_GENTYPE_GENERAL,
							DI_GEN_COMMS_VAR_IN_FIRST + Instance);
					Value = DataItem->GetFPValue();
				} else {
					// Data is beyond the modbus map, just return 0.0
					Value = 0.0F;
				}
				ModFloatSwap(byteOrder, Value, fbuffer[Count]);
				Count++;
			}
		}
		// ModBus master Overlap transaction blocks
		else if (startRef > MOD_MASTER_START && startRef <= (MOD_MASTER_START + MOD_MASTER_LEN)) {
			// Translate start address into device and transaction address
			// USHORT Registers
//			USHORT Device = ( ((startRef-1) - MOD_MASTER_START) / MODBUSSLAVEDEV_TRANSACTIONS_SIZE );
//			USHORT Transaction = ( ((startRef-1) - MOD_MASTER_START) % MODBUSSLAVEDEV_TRANSACTIONS_SIZE );
			// float registers (ComServer compatability)
			USHORT Device = ((((startRef - 1) - MOD_MASTER_START) / 2) / MODBUSSLAVEDEV_TRANSACTIONS_SIZE);
			USHORT Transaction = ((((startRef - 1) - MOD_MASTER_START) / 2) % MODBUSSLAVEDEV_TRANSACTIONS_SIZE);
			// Read the data from the required transaction buffer
			float *pfbuffer = (float*) &regArr[0];
			float *pValue = NULL;
			float fDummyValue = 0.0F;
#ifndef V6IOTEST
			for (USHORT iValue = 0; iValue < refCnt; iValue++) {
				if (CModBusSchedule::IsMasterRegisterValid(Device + 1, Transaction + 1, iValue + 1)) {
					pValue = CModBusSchedule::ReadModBusDataItem(Device + 1, Transaction + 1, iValue + 1);
					if (NULL != pValue) {
						// Perform any byte swapping (as required by the ModBus Slave)
						memcpy((void*) &fDummyValue, pValue, sizeof(float));
						float fSwap;
						ModFloatSwap(byteOrder, fDummyValue, fSwap);
						memcpy(pfbuffer, (void*) &fSwap, sizeof(float));
					} else {
						float fSwap;
						ModFloatSwap(byteOrder, fDummyValue, fSwap);
						memcpy(pfbuffer, (void*) &fSwap, sizeof(float));
					}
				} else {
					// Register not valid, try to re-index
					Device = (((((startRef - 1) + iValue) - MOD_MASTER_START) / 2) / MODBUSSLAVEDEV_TRANSACTIONS_SIZE);
					Transaction = (((((startRef - 1) + iValue) - MOD_MASTER_START) / 2)
							% MODBUSSLAVEDEV_TRANSACTIONS_SIZE);
					if (CModBusSchedule::IsMasterRegisterValid(Device + 1, Transaction + 1, iValue + 1)) {
						// If it's now valid, continue
						pValue = CModBusSchedule::ReadModBusDataItem(Device + 1, Transaction + 1, iValue + 1);
						if (NULL != pValue) {
							// Perform any byte swapping (as required by the ModBus Slave)
							memcpy((void*) &fDummyValue, pValue, sizeof(float));
							float fSwap;
							ModFloatSwap(byteOrder, fDummyValue, fSwap);
							memcpy(pfbuffer, (void*) &fSwap, sizeof(float));
						} else {
							// Otherwise return invalid data marker
							float fSwap;
							ModFloatSwap(byteOrder, fDummyValue, fSwap);
							memcpy(pfbuffer, (void*) &fSwap, sizeof(float));
						}
					} else {
						// Error with register look-up, return invalid data marker
						float fSwap;
						ModFloatSwap(byteOrder, fDummyValue, fSwap);
						memcpy(pfbuffer, (void*) &fSwap, sizeof(float));
					}
				}
				pfbuffer++;
			}
#endif
		}
		// Device ID data (X-Series specific)
		else if (startRef > MOD_DEVICE_ID_START && startRef <= (MOD_DEVICE_ID_START + MOD_DEVICE_ID_LEN)) {
			float *fbuffer = (float*) &regArr[0];
			int Count = 0;
			float Value = 0.0F;
			for (ULONG iRegister = startRef; iRegister < (startRef + refCnt); iRegister += 2) {
				// Processed as a case statement to allow other parameters to be easily added later
				switch (iRegister) {
				case (MOD_DEVICE_ID_REG + 1):
					Value = (float) pSYSTEM_INFO->GetGeneralConfig()->ID;
					ModFloatSwap(byteOrder, Value, fbuffer[Count++]);
					break;
				case (MOD_DEVICE_SR_REG + 1):
					Value = (float) pGlbSysInfo->GetSerialNumber();
					ModFloatSwap(byteOrder, Value, fbuffer[Count++]);
					break;
				default:
					// todo: generate ModBus exception
					break;
				}
			}
		}
		// Alarm status for all pen alarms
		else if (startRef > MOD_ALARM_STATUS_START && startRef <= (MOD_ALARM_STATUS_START + MOD_ALARM_STATUS_LEN)) {
			// Get a USHORT based view on the modbus send buffer
			USHORT *fbuffer = (USHORT*) &regArr[0];
			// get the first pen alarm status in a possible sequential block on statuses
			USHORT StartAlarm = startRef - (MOD_ALARM_STATUS_START + 1);
			USHORT Count = 0;
			// Run though each Pen Alarm status block
			for (USHORT Instance = StartAlarm; Instance < StartAlarm + refCnt; Instance++) {
				// Build the bitfiled related message and return into correct buffer location
				fbuffer[Count] = BuildAlarmStatus(Instance);
				Count++;
			}
		}
		// Alarm level for all pen alarms
		else if (startRef > MOD_ALARM_LEVEL_START && startRef <= (MOD_ALARM_LEVEL_START + MOD_ALARM_LEVEL_LEN)) {
			// Derive start end end of required instances
			USHORT startInstance = ((startRef - (MOD_ALARM_LEVEL_START + 1)) / 2);
			USHORT endInstance = startInstance + (refCnt / 2);
			float Value = 0.0F;
			USHORT Count = 0;
			USHORT penNumber = 0;
			USHORT alarmNumber = 0;
			float *fbuffer = (float*) &regArr[0];
			// Run through all instances required, extractinf Pen and Alarm number, and getting Alarm level.
			for (USHORT Instance = startInstance; Instance < endInstance; Instance++) {
				// Get Pen an alarm number from instance
				if (GetPenAlarmInstancesForAlarmLevel(Instance, penNumber, alarmNumber) == TRUE) {
					// Get handle on Alarm Data Item and retreive alarm level
					CDataItemAlarm *pAlm = (CDataItemAlarm*) pDIT->GetDataItemPtr(DI_ALARM, alarmNumber, penNumber);
					Value = pAlm->GetFPValue();
				} else {
					// Alarm or Pen limits exceed from map, set to 0.
					Value = 0.0F;
				}
				// Set in map.
				ModFloatSwap(byteOrder, Value, fbuffer[Count]);
				Count++;
			}
		}
	}
	sleep(pCommunications->SerialPort.ReplyDelay);
	return (1);
}
//****************************************************************************
/// Modbus Write Holding Register
///
/// @param[in] 		StartRef Start register offset
/// @param[in] 		regArr[] Array of holding register data
/// @param[in] 		refCount Register count to return
///
/// @return 1 for success
///
/// @note Write comms variables
//****************************************************************************
int MbusDataTable::writeHoldingRegistersTable(int startRef, const short regArr[], int refCnt) {
	CBrdInfo *pBoardInfo = CBrdInfo::GetHandle();
	T_CONFIG_RETURN_VALUE retValue = CONFIG_OK;
	T_PCOMMUNICATIONS pCommunications = NULL;
//TM - by removing this call from the XSeries DLL build a whole load of unused functionality 
//can also be removed fro the XSeries project - it makes sense to do this here
#ifndef TTR6SETUP
	//TM - this appears to be unused but I'm not removing it as I may be wrong
	CMessageListServices *pMessageListService = CMessageListServices::GetHandle();
#endif
//	CCommsSetupConfig *pNewConfig = pGlbSetup->GetCommsSetupConfig();
//	pCommunications = pNewConfig->GetCommsBlock( CONFIG_COMMITTED );
#if ! defined ( DOCVIEW ) && ! defined ( TTR6SETUP )
	CModBusStats *pModBusStats = CModBusStats::GetHandle();
	pCommunications = pModBusStats->CurrentConfiguration();
#endif
	if (pCommunications == NULL) {
		qDebug("NULL pointer returned for write pCommunications = pNewConfig->GetCommsBlock \n");
		return (1);
	}
	FLOAT_ORDER byteOrder = FP_LB;
	if (PR_MODBUS == pCommunications->ModbusSlave.Protocol)
		byteOrder = FP_B;
	if (NULL != pCommunications) {
		// Check for ModBus mark on chart message
		if (startRef == INPUT_TEXT_START) {
			char *MessageSource = (char*) regArr;
			char MessageString[INPUT_TEXT_LEN + 1];
			UCHAR NumBytes = refCnt;	// read byte count
			LOG_INFO( TRACE_MODBUS, "Modbus: receive text message");
			if (NumBytes > INPUT_TEXT_LEN)		// truncate string if longer than max permitted
				NumBytes = INPUT_TEXT_LEN;
            swab((char*) regArr, MessageString, INPUT_TEXT_LEN + 1);
			WCHAR wszMessage[INPUT_TEXT_LEN + 1];
#if _MSC_VER < 1400 
			mbstowcs(wszMessage, MessageString, INPUT_TEXT_LEN);
#else
			size_t pNoOfChars;
			mbstowcs_s(&pNoOfChars, wszMessage, INPUT_TEXT_LEN+1, MessageString, INPUT_TEXT_LEN );
#endif
//TM - by removing this call from the XSeries DLL build a whole load of unused functionality 
//can also be removed fro the XSeries project - it makes sense to do this here
#ifndef TTR6SETUP
			LOG_USER_MESSAGE(MSGLISTSER_USER_MODBUS_MESSAGE, wszMessage);
#endif
		}
		// Check for chart contel events
		else if (startRef == CHART_CONTROL_REGISTER) {
			WORD Code = regArr[0];
#ifndef TTR6SETUP
			COpPanel *pOpPanel = reinterpret_cast<COpPanel*>(AfxGetApp()->GetMainWnd());
			switch (Code) {
			case 0x0100: 		// request for Fast Chart: data sent		0x0100
				pOpPanel->PostMessage(WM_OPPANEL_PREFILL_CHARTS, 0, 0);
				break;
			case 0x0300:		// request for Chart Freeze: data sent		0x0300
			case 0x0500:		// request to Pause Screen: data sent		0x0500
				pOpPanel->PostMessage(WM_OPPANEL_PAUSE_CHARTS, 0, 0);
				break;
			case 0x0200:		// request for Normal Chart: data sent		0x0200
			case 0x0600:		// request to Unpause Screen: data sent		0x0600
			case 0x0400:		// request for Chart Unfreeze and unstop: data sent			0x0400
			case 0x0a00:		// request to Resume all Charts and Acquisition: data sent	0x0a00
				pOpPanel->PostMessage(WM_OPPANEL_RESUME_CHARTS, 0, 0);
				break;
			case 0x0700:		// request to Clear all Charts: data sent	0x0700
				pOpPanel->PostMessage(WM_OPPANEL_CLEAR_CHARTS, 0, 0);
				break;
			case 0x0800:		// request to Clear all Messages: data sent 0x0800
				pOpPanel->PostMessage(WM_OPPANEL_CLEARMESSAGELIST, 0, 0);
				break;
			case 0x0900:		// request to Stop all Charts and Acquisition: data sent 0x0900
				pOpPanel->PostMessage(WM_OPPANEL_STOP_CHARTS, 0, 0);
				break;
			default:
				//QString  defMessage;
				//defMessage.Format( L"MB: Unknown chrt ctrl %d ", Code );
				//LOG_USER_MESSAGE( MSGLISTSER_USER_MODBUS_MESSAGE, defMessage );
				break;
			}
#endif
		}
		// Check for Comms variables block
		else if (startRef >= MOD_COMPEN_START && startRef < (MOD_COMPEN_START + MOD_COMPEN_LEN))
		{
			float *fbuffer = (float*) &regArr[0];
			USHORT StartPen = (startRef - MOD_COMPEN_START) - 1;
			float Value = 0.0F;
			USHORT Count = 0;
			LOG_INFO( TRACE_MODBUS, "Modbus: receive comms pen value");
			for (USHORT Instance = (StartPen / 2); Instance < ((StartPen + refCnt) / 2); Instance++) {
				if (Instance < (MOD_COMPEN_LEN / 2)) {
					Value = fbuffer[Count];
					CDataItem *DataItem = (CDataItem*) pGlbDIT->GetDataItemPtr(DI_GENERAL, DI_GENTYPE_GENERAL,
							DI_GEN_COMMS_VAR_IN_FIRST + Instance);
					float fValue;
					ModFloatSwap(byteOrder, Value, fValue);
					DataItem->SetValue(fValue);
				}
				Count++;
			}
		}
		// Check for extended comms variables block
		else if (startRef >= MOD_EXCOMPEN_START && startRef < (MOD_EXCOMPEN_START + MOD_EXCOMPEN_LEN)) {
			float *fbuffer = (float*) &regArr[0];
			USHORT StartPen = (startRef - MOD_EXCOMPEN_START) - 1;
			float Value = 0.0F;
			USHORT Count = 0;
			LOG_INFO( TRACE_MODBUS, "Modbus: receive comms pen value");
			for (USHORT Instance = (StartPen / 2); Instance < ((StartPen + refCnt) / 2); Instance++) {
				if (Instance < (MOD_EXCOMPEN_LEN / 2)) {
					Value = fbuffer[Count];
					CDataItem *DataItem = (CDataItem*) pGlbDIT->GetDataItemPtr(DI_GENERAL, DI_GENTYPE_GENERAL,
							DI_GEN_COMMS_VAR_IN_FIRST + Instance);
					float fValue;
					ModFloatSwap(byteOrder, Value, fValue);
					DataItem->SetValue(fValue);
				}
				Count++;
			}
		} else if (startRef > MOD_ALARM_LEVEL_START && startRef <= (MOD_ALARM_LEVEL_START + MOD_ALARM_LEVEL_LEN)) {
			// Derive start end end of required instances
			USHORT startInstance = ((startRef - (MOD_ALARM_LEVEL_START + 1)) / 2);
			USHORT endInstance = startInstance + (refCnt / 2);
			float Value = 0.0F;
			USHORT Count = 0;
			USHORT penNumber = 0;
			USHORT alarmNumber = 0;
			float *fbuffer = (float*) &regArr[0];
#ifndef TTR6SETUP
			CPenManager *pFPPenManager = CPenManager::GetHandle();// Get handle on Pen Manager for setting alarm levels
#endif
			// Run through all instances required, extractinf Pen and Alarm number, and getting Alarm level.
			for (USHORT Instance = startInstance; Instance < endInstance; Instance++) {
				Value = fbuffer[Count++];
				// Get Pen an alarm number from instance
				if (GetPenAlarmInstancesForAlarmLevel(Instance, penNumber, alarmNumber) == TRUE) {
					// Get handle on Alarm Data Item and and check to see if we are allowed to make dynamic changes
					CDataItemAlarm *pAlm = (CDataItemAlarm*) pDIT->GetDataItemPtr(DI_ALARM, alarmNumber, penNumber);
					if (pAlm->GetAlarmConfig()->ChangeAllow) {
						// Change allowed, swap the bytes to get in correct format to set float value
						float fValue;
						ModFloatSwap(byteOrder, Value, fValue);
						// Regsiter alarm change via the Pen Manager.
#ifndef TTR6SETUP
						pFPPenManager->PerformAlarmLevelUpdateSilent(penNumber, alarmNumber, fValue);
#endif
					}
				}
			}
		}
	}
	sleep(pCommunications->SerialPort.ReplyDelay);
	return (1);
}
//****************************************************************************
/// Modbus Report Slave ID (Honeywell specific)
///
/// @param[in] 		regArr[] Array to deposit the result	
///
/// @return 1 for success
///
/// @note This is a test/temp method until we get some real data
//****************************************************************************
int MbusDataTable::reportSlaveID(short regArr[]) {
	T_PCOMMUNICATIONS pCommunications = NULL;
//	CCommsSetupConfig *pNewConfig = pGlbSetup->GetCommsSetupConfig();
//	pCommunications = pNewConfig->GetCommsBlock( CONFIG_COMMITTED );
#if ! defined ( DOCVIEW ) && ! defined ( TTR6SETUP )
	CModBusStats *pModBusStats = CModBusStats::GetHandle();
	pCommunications = pModBusStats->CurrentConfiguration();
#endif
	unsigned int Ndevs = 0;
	unsigned char ByteCount = 20;
	unsigned char *szTarget = (unsigned char*) &regArr[0];
	unsigned int iOffset = 0;
	/*******************************************************************************
	 *
	 *	Counting the Function Code as byte 0 of the message, the offsets from there are:
	 *	0					Function code
	 *	1					byte count (BC)		= 21 + 5 * No. of data blocks
	 *	2					slave ID (SID)	= 05 by agreement
	 *	3					run indicator status (RIS)	0 (off) 1 (on)
	 *	4 to 19				Decription 16 characters, zero filled
	 *	20					ModelID
	 *	21					Device Class ID
	 *	22					Number of data blocks (NDB)
	 *	23 to  22 + 5*NDB	5 bytes per data block : Block code, Addr hi, Addr lo, Number hi, Number lo
	 *
	 *		N.B. byte count = no. of bytes of actual data following BC, not the total size of the 
	 *			message, that is it is the number of bytes from SID to before the CRC bytes, inclusive.
	 *
	 * Size will be ByteCount + 2, ie ByteCount + FC byte + BC byte
	 *
	 * Thus with 2 data blocks we would have BC = 31 as follows:
	 *
	 *		 | - - - - - - - - - - - - BC = 31 bytes - - - - - - - - - - - - - -|
	 *
	 * 0	1	2	3	4  -  19		20		21		22		23 - 27	  28 - 32		. . .
	 * FC	BC	SID	RIS	Description		ModelID	DevID	NDB		DB1		  DB2			. . .
	 *
	 *		 | - - - - - - -  fixed 21 bytes  - - - - - - | | - variable: 5 per data block - |
	 *
	 *********************************************************************************/
//	szTarget[0] = 17;
	szTarget[2] = 5;							// General V5/V6 recorder ID
	szTarget[3] = 0xff;							// Run indicator
	// Get device type
	memset((void*) &szTarget[4], '\0', 16);
	// Construct a ModBus device name from the OEM product range name and the OEM device name
	int iBufferSize = 256;
	WCHAR wcszDeviceName[256];
	memset(wcszDeviceName, '\0', iBufferSize * sizeof(WCHAR));
#if _MSC_VER < 1400 
	wcsncpy(wcszDeviceName, pGlbSysInfo->GetOEMProductRangeName(), 256);
	iBufferSize -= wcslen(wcszDeviceName);
	wcsncat(wcszDeviceName, L"-", iBufferSize);
	iBufferSize--;
	wcsncat(wcszDeviceName, pGlbSysInfo->GetOEMDeviceName(), iBufferSize);
#else
	wcsncpy_s( wcszDeviceName, 256, pGlbSysInfo->GetOEMProductRangeName(), _TRUNCATE );
	iBufferSize -= wcslen( wcszDeviceName );
	wcsncat( wcszDeviceName, 256, L"-", iBufferSize );
	iBufferSize--;
	wcsncat( wcszDeviceName, 256, pGlbSysInfo->GetOEMDeviceName(), iBufferSize );
#endif
	// Convert the name from WCHARS to chars
	char szTextBuffer[20];
	memset(szTextBuffer, '\0', 20);
#if _MSC_VER < 1400 
	wcstombs(szTextBuffer, wcszDeviceName, 16);
#else
	size_t pNoOfChars;
	wcstombs_s( &pNoOfChars, szTextBuffer, 20, wcszDeviceName, 16 );
#endif
	// Store the concatenated name in the message buffer
	swab(szTextBuffer, (char*) &szTarget[4], 16);
//	switch ( GlbDevCaps.GetDeviceType() )
//	{
//	case DEV_ARISTOS_MINITREND:
//		swab( "Minitrend QX", (char *)&szTarget[4], 11 );
//		//strcpy( (char *)&szTarget[4], "Minitrend " );
//		break;
//	case DEV_ARISTOS_MULTIPLUS:
//		swab( "Multitrend SX", (char *)&szTarget[4], 13 );
//		//strcpy( (char *)&szTarget[4], "Multitrend " );
//		break;
//	case DEV_EZTREND:
//		swab( "eZtrend ", (char *)&szTarget[4], 8 );
//		//strcpy( (char *)&szTarget[4], "eZtrend " );
//		break;
//	default:
//		swab( "Unknown ", (char *)&szTarget[4], 8 );
//		//strcpy( (char *)&szTarget[4], "Unknown " );
//		break;
//	}
	iOffset = 20;
	szTarget[iOffset++] = 0;					// Model ID
	szTarget[iOffset++] = 0;					// Device Class
	ByteCount += 2;
	szTarget[iOffset++] = 5;					// Number of data blocks
	ByteCount++;
	// 23-27 Type 0 Analogue inputs
	Ndevs = MOD_ANALOGUE_LEN / 2;
	szTarget[iOffset++] = 0;
	szTarget[iOffset++] = (UCHAR) (MOD_ANALOGUE_START / 256);
	szTarget[iOffset++] = (UCHAR) (MOD_ANALOGUE_START % 256);
	szTarget[iOffset++] = Ndevs / 256;
	szTarget[iOffset++] = Ndevs % 256;
	ByteCount += 5;
	// 28-32 Type 2 Digital inputs
	Ndevs = MOD_DIG_LEN / 2;
	szTarget[iOffset++] = 2;
	szTarget[iOffset++] = (UCHAR) (MOD_DIG_START / 256);		// return Dig In address as 00 00
	szTarget[iOffset++] = (UCHAR) (MOD_DIG_START % 256);
	szTarget[iOffset++] = Ndevs / 256;
	szTarget[iOffset++] = Ndevs % 256;
	ByteCount += 5;
	// 33-37 Type 3 Digital outputs
	Ndevs = MOD_DIG_LEN / 2;
	szTarget[iOffset++] = 3;
	szTarget[iOffset++] = (UCHAR) (MOD_DIG_START / 256);		// return Dig Out address as 00 00
	szTarget[iOffset++] = (UCHAR) (MOD_DIG_START % 256);
	szTarget[iOffset++] = Ndevs / 256;
	szTarget[iOffset++] = Ndevs % 256;
	ByteCount += 5;
	// 38-42 Type 6 Pens
	Ndevs = MOD_PEN_LEN / 2;
	szTarget[iOffset++] = 6;
	szTarget[iOffset++] = (UCHAR) (MOD_PEN_START / 256);
	szTarget[iOffset++] = (UCHAR) (MOD_PEN_START % 256);
	szTarget[iOffset++] = Ndevs / 256;
	szTarget[iOffset++] = Ndevs % 256;
	ByteCount += 5;
	// 43-47 Type 9 Totalisers
	Ndevs = MOD_TOTALS_LEN / 4;
	szTarget[iOffset++] = 9;
	szTarget[iOffset++] = (UCHAR) (MOD_TOTALS_START / 256);
	szTarget[iOffset++] = (UCHAR) (MOD_TOTALS_START % 256);
	szTarget[iOffset++] = Ndevs / 256;
	szTarget[iOffset] = (UCHAR) (Ndevs % 256);
	ByteCount += 5;
	szTarget[1] = ByteCount;
	sleep(pCommunications->SerialPort.ReplyDelay);
	return (1);
}
//****************************************************************************
/// Get the pen and alarm number derived from the flat map of instances 1 - 576
///
/// @param[in] 		instance, the Pen / alarm instance, 0 based.
.

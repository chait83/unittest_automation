/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Configuration
/// @n Filename: Layoutconfiguration.cpp 
/// @n Description: Layout configuration for OpPanel classes
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  30-Oct-14 Rajanbabu M  Fixed PAR:1-3KZWBIH-Load custom screen is not working in Multi and DRG2 Recorders
//  111  Stability Project 1.106.1.3  7/2/2011 4:58:17 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  110  Stability Project 1.106.1.2  7/1/2011 4:38:24 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  109  Stability Project 1.106.1.1  3/17/2011 3:20:26 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  108  Stability Project 1.106.1.0  2/15/2011 3:03:12 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
// 
//
// **************************************************************************
#include "LayoutConfiguration.h"
#include "TVTime.h"
#include "OpPanelIncludes.h"
#include "StringUtils.h"
#include "UISizeDefines.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
#define STRING_BLOCK_CHUNK 600 // 600 bytes to start with, then add in 600 byte chunks
// registered clipboard format
CLIPFORMAT cfLayout = (CLIPFORMAT) ::RegisterClipboardasprintf(_T("V6 Layout Items"));
BOOL CLayoutConfiguration::m_bCopySingleSel = FALSE;
CLayoutConfiguration *CLayoutConfiguration::m_pCopyLayout = NULL;
PASTE_DESCRIPTION CLayoutConfiguration::m_PasteDesc = PASTE_NULL;
T_LAYOUTITEM CLayoutConfiguration::m_LastPastedItemRef = { 0, 0 };
BOOL IsNull(T_LAYOUTITEM LayoutItem) {
	return !LayoutItem.CMM_Type || !LayoutItem.CMM_Inst; // return TRUE if either zero
}
void SetNull(T_LAYOUTITEM &LayoutItem) {
	LayoutItem.CMM_Type = 0;
	LayoutItem.CMM_Inst = 0;
}
BOOL IsEqual(T_LAYOUTITEM LayoutItem1, T_LAYOUTITEM LayoutItem2) {
	return LayoutItem1.CMM_Type == LayoutItem2.CMM_Type && LayoutItem1.CMM_Inst == LayoutItem2.CMM_Inst;
}
//****************************************************************************
///
/// Constructor
///
//****************************************************************************
CLayoutConfiguration::CLayoutConfiguration(BOOL IsCannedScreens/*=FALSE*/) {
	ResetInstNos(IsCannedScreens);
	SetCMMmode(CONFIG_COMMITTED); // default to comitted
	m_pOpPanel = NULL;
	m_IsCustomLayout = FALSE;
	m_ContainsBitmapObjects = FALSE;
	m_MissingBCF = FALSE;
}
CLayoutConfiguration::~CLayoutConfiguration(void) {
}
//****************************************************************************
///
/// Reset the instance numbers initially and after discard etc.
///
/// @return none
///
//****************************************************************************
void CLayoutConfiguration::ResetInstNos(BOOL IsCannedScreens) //=FALSE
		{
	// initialise all structure instances to 1 for Normal layouts
	// and a larger value for Canned Screens. (will help when debugging)
	int initval = 1;
	if (IsCannedScreens)
		initval = CANNED_SCREENS_INST;
	m_nextScreenInst = initval;
	m_nextTemplateInst = initval;
	m_nextWidgetInst = initval;
	for (int i = 0; i < SUPPORTED_OBJECT_TYPES; i++) {
		m_nextObjectInst[i] = initval; // same for all supported object types.
	}
}
//****************************************************************************
///
/// Create the empty configuration for Layout
///
/// @return creation success state
///
//****************************************************************************
T_CONFIG_RETURN_VALUE CLayoutConfiguration::CreateEmptyConfig(void) {
	CMMERROR err = CMM_FAILED;
	// Member Function Return Value 
	T_CONFIG_RETURN_VALUE retValue = CONFIG_CMM_HOLDER_COULD_NOT_BE_CREATED;
	// Create a CMM Configuration Holder
	retValue = CreateCMMConfiguration();
	if (CONFIG_OK == retValue) {
		BLOCK_INFO blockInfo;
		blockInfo.wBlockType = BLK_LAYOUT;
		blockInfo.wInstanceID = DEFAULT_LAYOUT_INST;
		blockInfo.pByBlock = NULL;
		blockInfo.dwBlockSize = 0;
		blockInfo.dwSessionNumber = 0;
		err = CreateDataBlock(GetConfigId(), &blockInfo);
		if (err == CMM_SUCCESS) {
			T_LAYOUT *pLayout = (T_LAYOUT*) blockInfo.pByBlock;
			// even though empty, set the type here.
			T_DEV_TYPE device = pDEVICE_INFO->GetDeviceType();
			pLayout->RecorderType = device;
			pLayout->IsValid = TRUE; // mark as valid			
			if (CONFIG_OK != CommitConfig()) {
				retValue = CONFIG_CMM_COMMIT_CONFIG_ERROR;
			} else {
				retValue = CONFIG_OK;
			} // End of IF
		}
	}
	if (CONFIG_OK == retValue || CONFIG_OK_VALIDATE_UPDATED_CMM == retValue) {
		CleanUpConfiguration( TRUE);
	} else {
		CleanUpConfiguration( FALSE);
	} // End of IF
	return (retValue);
} // End of CreateEmptyConfig()
//****************************************************************************
///
/// Create the default configuration for Layout
///
/// @return creation success state
///
//****************************************************************************
T_CONFIG_RETURN_VALUE CLayoutConfiguration::CreateDefaultConfig(void) {
	CMMERROR err = CMM_FAILED;
	// Member Function Return Value 
	T_CONFIG_RETURN_VALUE retValue = CONFIG_CMM_HOLDER_COULD_NOT_BE_CREATED;
	// Create a CMM Configuration Holder
	retValue = CreateCMMConfiguration();
	if (CONFIG_OK == retValue) {
		BLOCK_INFO blockInfo;
		blockInfo.wBlockType = BLK_LAYOUT;
		blockInfo.wInstanceID = DEFAULT_LAYOUT_INST;
		blockInfo.pByBlock = NULL;
		blockInfo.dwBlockSize = 0;
		blockInfo.dwSessionNumber = 0;
		err = CreateDataBlock(GetConfigId(), &blockInfo);
		if (err == CMM_SUCCESS) {
			T_LAYOUT *pLayout = (T_LAYOUT*) blockInfo.pByBlock;
			SecureZeroMemory((PVOID) &(pLayout->HotButtonList[0]), sizeof(T_HOTBUTTON)); SecureZeroMemory((PVOID) &(pLayout->HotButtonList[1]), sizeof(T_HOTBUTTON)); SecureZeroMemory((PVOID) &(pLayout->HotButtonList[2]), sizeof(T_HOTBUTTON)); SecureZeroMemory((PVOID) &(pLayout->HotButtonList[3]), sizeof(T_HOTBUTTON));
			QString strDefName;
			QString strDefNameasprintf;
			strDefNameasprintf = tr("HB %u");
			strDefName = QString::asprintf(strDefNameasprintf, 1);
			wmemcpy_s(pLayout->HotButtonList[0].Name, sizeof(pLayout->HotButtonList[0].Name) / sizeof(WCHAR),
					strDefName, strDefName.size());
			strDefName = QString::asprintf(strDefNameasprintf, 2);
			wmemcpy_s(pLayout->HotButtonList[1].Name, sizeof(pLayout->HotButtonList[0].Name) / sizeof(WCHAR),
					strDefName, strDefName.size());
			strDefName = QString::asprintf(strDefNameasprintf, 3);
			wmemcpy_s(pLayout->HotButtonList[2].Name, sizeof(pLayout->HotButtonList[0].Name) / sizeof(WCHAR),
					strDefName, strDefName.size());
			strDefName = QString::asprintf(strDefNameasprintf, 4);
			wmemcpy_s(pLayout->HotButtonList[3].Name, sizeof(pLayout->HotButtonList[0].Name) / sizeof(WCHAR),
					strDefName, strDefName.size());
			if (!pDEVICE_INFO->IsRecorderEzTrend()) {
				// now create a template and link it to the layout.	
				blockInfo.wInstanceID = DEFAULT_TEMPLATE_INST;
				blockInfo.pByBlock = NULL;
				blockInfo.wBlockType = BLK_SCRTEMPLATE;
				err = CreateDataBlock(GetConfigId(), &blockInfo);
			}
			if (err == CMM_SUCCESS) {
				if (!pDEVICE_INFO->IsRecorderEzTrend()) {
					// worked OK, 
					// configure T_SCRTEMPLATE (name and number)
					// set template number here (same as TemplateList index number (+1), so template[0] is number 1)
					T_SCRTEMPLATE *pTemplate = (T_SCRTEMPLATE*) blockInfo.pByBlock;
					pTemplate->Number = 1;
					swprintf(pTemplate->Name, L"Template %d", 1);
					// link Layout to template
					T_LAYOUTITEM templateRef = { BLK_SCRTEMPLATE, DEFAULT_TEMPLATE_INST };
					pLayout->TemplateList[0] = templateRef;
					pLayout->NumTemplates++;
				}
				T_DEV_TYPE device = pDEVICE_INFO->GetDeviceType();
				pLayout->RecorderType = device;
				pLayout->IsValid = TRUE; // mark as valid
				if (CONFIG_OK != CommitConfig()) {
					retValue = CONFIG_CMM_COMMIT_CONFIG_ERROR;
				} else {
					retValue = CONFIG_OK;
				} // End of IF
			}
		}
	}
	if (CONFIG_OK == retValue || CONFIG_OK_VALIDATE_UPDATED_CMM == retValue) {
		CleanUpConfiguration( TRUE);
	} else {
		CleanUpConfiguration( FALSE);
	} // End of IF
#ifndef DOCVIEW 
	// remove any .bcf file present (for recorder only)
	WCHAR BCFname[MAX_PATH];
	CBitmapCollectionFile::BuildFilename(BCFname); // form filename of the config bcf file
	CStorage bcfFile;
	if (bcfFile.exists(BCFname))
		bcfFile.remove(BCFname);
#endif  
	return (retValue);
} // End of CreateDefaultConfig()
//****************************************************************************
///
/// Create a 'special' Screen configuration used to display templates 
///
/// @return creation success state
///
//****************************************************************************
T_CONFIG_RETURN_VALUE CLayoutConfiguration::CreateTemplateScreenConfig(void) {
	T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;
	CMMERROR err = CMM_FAILED;
	// The 'special' Template screen will be found by looking for T_LAYOUTITEM of BLK_SCREEN 
	// and instance of TEMPLATE_SCREEN_INST
	// and the screen of TEMPLATE_SCREEN_NUMBER
	BLOCK_INFO blockInfo;
	blockInfo.wBlockType = BLK_SCREEN;
	blockInfo.wInstanceID = TEMPLATE_SCREEN_INST;
	blockInfo.pByBlock = NULL;
	blockInfo.dwBlockSize = 0;
	blockInfo.dwSessionNumber = 0;
	err = CreateDataBlock(GetConfigId(), &blockInfo);
	if (err == CMM_SUCCESS) {
		// modify default params
		T_SCREEN *pScreen = (T_SCREEN*) blockInfo.pByBlock;
		pScreen->Type = TPL_CUSTOM; // This screen uses a Custom (screen designed) template
		pScreen->Number = TEMPLATE_SCREEN_NUMBER;
		wcscpy_s(pScreen->Name, sizeof(pScreen->Name) / sizeof(WCHAR), L"Template Scrn");	/// @todo add to resources	
		pScreen->BackColour = 65528; // a pale yellowish
		pScreen->UseTmpltColour = FALSE;
		retValue = CONFIG_OK;
		// initialise the Screen's channel map
		// These entries are for channels 1001 to 1128
		// CHANNEL		INSTANCE
		// 0 (1001)			0
		// 1 (1002)			1
		// 2 (1003)			2
		// 3 (1004)			20  
		// 4 (1005)			15
		// 5 (1006)			10
		for (int i = 0; i < SCREEN_CHANNELMAP_SIZE; i++) {
			// set to uninitialised while on the template screen	
			pScreen->ChannelMap[i] = CScreen::ms_usUNINITIALISED_INSTANCE;
		}
	}
	return (retValue);
}
//****************************************************************************
///
/// Create a Replay screen configuration
///
/// @return creation success state
///
//****************************************************************************
T_CONFIG_RETURN_VALUE CLayoutConfiguration::CreateReplayScreenConfig(void) {
	T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;
	CMMERROR err = CMM_FAILED;
	// The Replay screen will be found by looking for T_LAYOUTITEM of BLK_SCREEN 
	// and instance of REPLAY_SCREEN_INST
	// and the screen of REPLAY_SCREEN_NUMBER
	BLOCK_INFO blockInfo;
	blockInfo.wBlockType = BLK_SCREEN;
	blockInfo.wInstanceID = REPLAY_SCREEN_INST;
	blockInfo.pByBlock = NULL;
	blockInfo.dwBlockSize = 0;
	blockInfo.dwSessionNumber = 0;
	err = CreateDataBlock(GetConfigId(), &blockInfo);
	if (err == CMM_SUCCESS) {
		// modify default params
		T_SCREEN *pScreen = (T_SCREEN*) blockInfo.pByBlock;
		pScreen->Type = TPL_REPLAY;
		pScreen->Number = REPLAY_SCREEN_NUMBER;
		wcscpy_s(pScreen->Name, sizeof(pScreen->Name) / sizeof(WCHAR), L"Replay Scrn");	/// @todo add to resources	
		pScreen->BackColour = 16359; // greeninsh
		pScreen->UseTmpltColour = FALSE;
		retValue = CONFIG_OK;
	}
	// here we create our replay screen 'template' to go with this screen.
	// This temporary template is added to the replay config (not the main layout config).
	blockInfo.wBlockType = BLK_SCRTEMPLATE;
	blockInfo.wInstanceID = REPLAY_SCREEN_INST;
	blockInfo.pByBlock = NULL;
	err = CreateDataBlock(GetConfigId(), &blockInfo);
	if (err == CMM_SUCCESS) {
		// created ok.
		T_SCRTEMPLATE *pTemplate = (T_SCRTEMPLATE*) blockInfo.pByBlock;
		pTemplate->Number = REPLAY_SCREEN_NUMBER;
		wcscpy_s(pTemplate->Name, sizeof(pTemplate->Name) / sizeof(WCHAR), L"Replay Template");
		pTemplate->StatusBar = FALSE;
		retValue = CONFIG_OK;
	}
	return (retValue);
}
//****************************************************************************
///
/// Create HotSoak screen configuration
///
/// @return creation success state
///
//****************************************************************************
T_CONFIG_RETURN_VALUE CLayoutConfiguration::CreateHotSoakScreenConfig(void) {
	T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;
	CMMERROR err = CMM_FAILED;
	// The HotSoak screen will be found by looking for T_LAYOUTITEM of BLK_SCREEN 
	// and instance of HOTSOAK_SCREEN_INST
	// and the screen of HOTSOAK_SCREEN_NUMBER
	BLOCK_INFO blockInfo;
	blockInfo.wBlockType = BLK_SCREEN;
	blockInfo.wInstanceID = HOTSOAK_SCREEN_INST;
	blockInfo.pByBlock = NULL;
	blockInfo.dwBlockSize = 0;
	blockInfo.dwSessionNumber = 0;
	err = CreateDataBlock(GetConfigId(), &blockInfo);
	if (err == CMM_SUCCESS) {
		// modify default params
		T_SCREEN *pScreen = (T_SCREEN*) blockInfo.pByBlock;
		pScreen->Type = TPL_HOTSOAK;
		pScreen->Number = HOTSOAK_SCREEN_NUMBER;
		wcscpy_s(pScreen->Name, sizeof(pScreen->Name) / sizeof(WCHAR), L"Hot Soak Test");	/// @todo add to resources	
		pScreen->BackColour = 16359; // greeninsh
		pScreen->UseTmpltColour = FALSE;
		pScreen->IsVert = FALSE;
		pScreen->Template.CMM_Type = BLK_SCRTEMPLATE;
		pScreen->Template.CMM_Inst = HOTSOAK_SCREEN_INST;
		retValue = CONFIG_OK;
	}
	// here we create our Hot Soak screen 'template' to go with this screen.
	// This temporary template is added to the hot soak config (not the main layout config).
	blockInfo.wBlockType = BLK_SCRTEMPLATE;
	blockInfo.wInstanceID = HOTSOAK_SCREEN_INST;
	blockInfo.pByBlock = NULL;
	err = CreateDataBlock(GetConfigId(), &blockInfo);
	if (err == CMM_SUCCESS) {
		// created ok.
		T_SCRTEMPLATE *pTemplate = (T_SCRTEMPLATE*) blockInfo.pByBlock;
		pTemplate->Number = HOTSOAK_SCREEN_NUMBER;
		wcscpy_s(pTemplate->Name, sizeof(pTemplate->Name) / sizeof(WCHAR), L"Hot Soak Template");
		retValue = CONFIG_OK;
	}
	return (retValue);
}
void GetScreenCountFromConfig(T_LAYOUT *pLayout, int &nProcessScreens, int &nNonProcessScreens) {
	nProcessScreens = 0;
	nNonProcessScreens = 0;
	for (int index = 0; index < pLayout->NumScreens; index++) {
		// Stability Project Fix:
		//Configuration ID for the screen is obtained from pGlbLayout->GetConfigId() 
		T_SCREEN *tempScreen = reinterpret_cast<T_SCREEN*>(CConfiguration::GetBlock(BLK_SCREEN,
				pLayout->ScreenList[index].CMM_Inst, pGlbLayout->GetConfigId(), CONFIG_MODIFIABLE));
		if (tempScreen->Type >= TPL_ALARM && tempScreen->Type < TPL_NP_LAST) {
			nNonProcessScreens++;
		} else
			nProcessScreens++;
	}
}
//****************************************************************************
///
/// Add a new Screen (based on the supplied template) to the Layout 
///
/// @param[in] templateRef	- refrence of template to base screen on
/// @param[in] blockInfo	- pointer to structure to populate
///
/// @return creation success state
///
//****************************************************************************
T_CONFIG_RETURN_VALUE CLayoutConfiguration::AddScreen(T_LAYOUTITEM *templateRef, BLOCK_INFO *blockInfo) {
	T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;
	CMMERROR err = CMM_FAILED;
	// check number of screens here
	int maxscreens = 0;
	T_DEV_TYPE devType = GetRecorderType();
	if (devType == DEV_ARISTOS_MULTIPLUS || devType == DEV_SCR_MINITREND)
		maxscreens = CScreen::ms_usMAX_MULTI_SCREENS;
	else if (devType == DEV_XS_MULTIPLUS)
		maxscreens = CScreen::ms_usMAX_XS_MULTI_SCREENS;
	else if (devType == DEV_ARISTOS_MINITREND)
		maxscreens = CScreen::ms_usMAX_MINI_SCREENS;
	else if (devType == DEV_XS_MINITREND)
		maxscreens = CScreen::ms_usMAX_XS_MINI_SCREENS;
	else
		maxscreens = CScreen::ms_usMAX_EZ_SCREENS;
	// firstly, find the Layout
	T_LAYOUTITEM layoutRef = { BLK_LAYOUT, DEFAULT_LAYOUT_INST };
	if (indexOfDataBlock(&layoutRef, blockInfo)) {
		// found ok. now check existing number of Screens
		T_LAYOUT *pLayout = (T_LAYOUT*) blockInfo->pByBlock;
//		if(pLayout->NumScreens>=LAYOUT_SCREENLIST_SIZE) // don't test against cmm limit
		if (pLayout->NumScreens >= maxscreens)	// use 'marketing' limits instead
				{
			retValue = CONFIG_NO_MORE_ROOM;
			return retValue;
		}
		// if OpPanel is not yet created then get screens from config
		//int nProcessScreens		= 0;
		//int nNonProcessScreens	= 0;
		//if ( m_pOpPanel == NULL )	
		//	GetScreenCountFromConfig(pLayout, nProcessScreens, nNonProcessScreens);
		//else
		//	m_pOpPanel->GetProcessScreenCount(nProcessScreens, nNonProcessScreens);
		//User is trying to add STD screen, deny if limit is reached... 
		//if ( templateRef != NULL && nProcessScreens >= maxscreens )
		//{
		//	retValue=CONFIG_NO_MORE_ROOM;
		//	return retValue; 
		//}
		//// : User should be able to add NPS even if he has reached limit for std screens
		//if( nProcessScreens >= maxscreens && nNonProcessScreens >= (CScreen::ms_usMAX_NON_PROCESS_SCREENS - maxscreens)) 
		//{
		//	retValue=CONFIG_NO_MORE_ROOM;
		//	return retValue; 
		//}
		//else if ( nProcessScreens + nNonProcessScreens >= LAYOUT_SCREENLIST_SIZE )
		//{
		//	retValue=CONFIG_NO_MORE_ROOM;
		//	return retValue; 
		//}
		// now add a new CMM screen entry
		// need to find first unused instance number.
		// start from m_nextScreenInst (slow the first time, but faster after that)
		T_LAYOUTITEM ScreenRef = { BLK_SCREEN, 0 };
		BOOL found = TRUE;
		do {
			ScreenRef.CMM_Inst = m_nextScreenInst;  // start from here
			found = indexOfDataBlock(&ScreenRef, blockInfo);
			m_nextScreenInst++;
		} while (found);
		// now create it
		err = CreateDataBlock(GetConfigId(), blockInfo);
		if (err == CMM_SUCCESS) {
			// created ok.
			T_SCREEN *pScreen = (T_SCREEN*) blockInfo->pByBlock;
			// if std scrrens limit is not reached create one with default std template
//			if ( nProcessScreens < maxscreens )
			{
				// link template into Screen - Template will be NULL for a canned screen
				if (templateRef) {
					pScreen->Template = *templateRef;
					pScreen->Type = TPL_CUSTOM;
				} else {
					// configure other Screen params for canned screens
					pScreen->Type = TPL_DPMS; // default to this for now.
				}
			}
			//else
			//{
			//	// std screen limit exhausted so create new non process screen as it's limit is not yet reached
			//	pScreen->Type=TPL_ALARM; 
			//}
			pScreen->UseTmpltColour = FALSE; // see screen backcolour
			// link Screen into Layout
			pLayout->ScreenList[pLayout->NumScreens] = ScreenRef;
			pLayout->NumScreens++;
			// set screen number here from the instance number 
			pScreen->Number = ScreenRef.CMM_Inst;
			WCHAR buff[SCREEN_NAME_LEN];
			if (pScreen->Type == TPL_CUSTOM) {
				//swprintf(pScreen->Name,L"Custom Screen %d",pScreen->Number); 
				::LoadString(AfxGetResourceHandle(), IDS_CUSTOM_SCREEN, buff, SCREEN_NAME_LEN);
			} else {
				//swprintf(pScreen->Name,L"Standard Screen %d",pScreen->Number); 
				::LoadString(AfxGetResourceHandle(), IDS_STANDARD_SCREEN, buff, SCREEN_NAME_LEN);
			}
			int len = wcslen(buff);
			swprintf(&buff[len], L" %d", pScreen->Number);
			CStringUtils::SafeWcsCpy(pScreen->Name, buff, SCREEN_NAME_LEN);
			retValue = CONFIG_OK;
		}
	}
	return retValue;
}
//****************************************************************************
///
/// Delete a Screen from the Layout 
///
/// @param[in] layoutItem	- refrence of screen to delete
///
/// @return creation success state
///
//****************************************************************************
T_CONFIG_RETURN_VALUE CLayoutConfiguration::DeleteScreen(T_LAYOUTITEM *layoutItem) {
	T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;
	CMMERROR err = CMM_FAILED;
	if (layoutItem->CMM_Type != BLK_SCREEN) // check it is a screen being deleted!
		return retValue;
	// remove it's link in the Layout
	T_LAYOUTITEM layoutRef = { BLK_LAYOUT, DEFAULT_LAYOUT_INST };
	BLOCK_INFO layblockInfo;
	if (indexOfDataBlock(&layoutRef, &layblockInfo)) {
		// found ok. now find the screen to delete in the layout
		// we also want to ensure we have no 'holes' in the layout, so move any above it in the array
		// down one slot.
		T_LAYOUT *pLayout = (T_LAYOUT*) layblockInfo.pByBlock;
		int scrSlot = 0;
		for (int scr = 0; scr < pLayout->NumScreens; scr++) {
			if (pLayout->ScreenList[scr].CMM_Inst == layoutItem->CMM_Inst) // match screen to delete
					{
				// found it, wipe it from the array
				ClearLayoutItem(&pLayout->ScreenList[scr]);
			} else {
				if (scrSlot < scr) {
					//copy,	dest<-source
					pLayout->ScreenList[scrSlot] = pLayout->ScreenList[scr];
					ClearLayoutItem(&pLayout->ScreenList[scr]);
				}
				scrSlot++;
			}
		}
		pLayout->NumScreens--; // one less screen now
		m_nextScreenInst = 1; // reset this here, so that when next screen is added it will find first gap.
	}
	// now remove the Screen block itself
	BLOCK_INFO scrblockInfo;
	if (indexOfDataBlock(layoutItem, &scrblockInfo)) {
		// found it, so delete it.
		err = DeleteDataBlock(GetConfigId(), &scrblockInfo);
		if (err == CMM_SUCCESS)
			retValue = CONFIG_OK;
	}
	return retValue;
}
//****************************************************************************
///
/// Add a new Template to the Layout
///
/// @param[in] blockInfo	- pointer to structure to populate
///
/// @return deletion success state
///
//****************************************************************************
T_CONFIG_RETURN_VALUE CLayoutConfiguration::AddTemplate(BLOCK_INFO *blockInfo, USHORT templateInst) //=0
		{
	T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;
	CMMERROR err = CMM_FAILED;
	// set max number of templates here
	int maxtemplates = 0;
	T_DEV_TYPE devType = GetRecorderType();
	if (devType == DEV_ARISTOS_MULTIPLUS || devType == DEV_SCR_MINITREND)
		maxtemplates = CScreen::ms_usMAX_MULTI_SCREENS;
	else if (devType == DEV_XS_MULTIPLUS)
		maxtemplates = CScreen::ms_usMAX_XS_MULTI_SCREENS;
	else if (devType == DEV_ARISTOS_MINITREND)
		maxtemplates = CScreen::ms_usMAX_MINI_SCREENS;
	else if (devType == DEV_XS_MINITREND)
		maxtemplates = CScreen::ms_usMAX_XS_MINI_SCREENS;
	else
		maxtemplates = CScreen::ms_usMAX_EZ_SCREENS;
	// firstly, find the Layout
	T_LAYOUTITEM layoutRef = { BLK_LAYOUT, DEFAULT_LAYOUT_INST };
	if (indexOfDataBlock(&layoutRef, blockInfo)) {
		T_LAYOUT *pLayout = (T_LAYOUT*) blockInfo->pByBlock;
		T_LAYOUTITEM TemplateRef = { BLK_SCRTEMPLATE, 0 };
		if (!templateInst) // supplied with instance to use?
		{
			// need to find first unused instance number.
			// start from m_nextTemplateInst (slow the first time, but faster after that)
			BOOL found = TRUE;
			do {
				TemplateRef.CMM_Inst = m_nextTemplateInst;  // start from here
				found = indexOfDataBlock(&TemplateRef, blockInfo);
				m_nextTemplateInst++;
			} while (found);
		} else {
			// here we have been supplied an instance number to use.
			// Check to see if it already exists. If it does we need to blank out it's settings and use it again
			TemplateRef.CMM_Inst = templateInst;
			if (indexOfDataBlock(&TemplateRef, blockInfo)) {
				// found it.
				// need to delete all the widgets & Objects below it and start afresh
				T_SCRTEMPLATE *pTemplate = (T_SCRTEMPLATE*) blockInfo->pByBlock;
				// delete widgets and objects below it...
				for (int w = 0; w < pTemplate->NumWidgets; w++) {
					DeleteWidgetandObjects(&pTemplate->WidgetList[w]);
					ClearLayoutItem(&pTemplate->WidgetList[w]); // blank out ready to reuse.
				}
				pTemplate->NumWidgets = 0;
				// already linked into Layout
				pTemplate->Number = 1; // just make non zero 
				// ready to use again.
				return CONFIG_OK;
			}
		}
		// here about to create a new one
		// check existing number of Templates
		//if(pLayout->NumTemplates>=LAYOUT_TEMPLATELIST_SIZE) // don't check against actual limit
		if (pLayout->NumTemplates >= maxtemplates) // use 'marketing' limits instead
				{
			retValue = CONFIG_NO_MORE_ROOM;
			return retValue;
		}
		// now create it
		err = CreateDataBlock(GetConfigId(), blockInfo);
		if (err == CMM_SUCCESS) {
			// created ok.
			// link Template into Layout
			pLayout->TemplateList[pLayout->NumTemplates] = TemplateRef;
			pLayout->NumTemplates++;
			T_SCRTEMPLATE *pTemplate = (T_SCRTEMPLATE*) blockInfo->pByBlock;
			// set template number here (same as TemplateList index number (+1), so template[0] is number 1)
			pTemplate->Number = pLayout->NumTemplates;
			swprintf(pTemplate->Name, L"Template %d", pTemplate->Number); /// @todo add to string table
			retValue = CONFIG_OK;
		}
	}
	return retValue;
}
//****************************************************************************
///
/// Delete a Template from the Layout. Any screens based on the Template 
/// should be deleted prior to this call
///
/// @param[in] layoutItem	- refrence of Template to delete
/// @param[in] bForce		- TRUE => delete even the last template!
///
/// @return deletion success state
///
//****************************************************************************
T_CONFIG_RETURN_VALUE CLayoutConfiguration::DeleteTemplate(T_LAYOUTITEM *layoutItem, BOOL bForce/*=FALSE*/) {
	T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;
	CMMERROR err = CMM_FAILED;
	if (layoutItem->CMM_Type != BLK_SCRTEMPLATE) // check it is a template being deleted!
		return retValue;
	// remove it's link in the Layout
	T_LAYOUTITEM layoutRef = { BLK_LAYOUT, DEFAULT_LAYOUT_INST };
	BLOCK_INFO layblockInfo;
	if (indexOfDataBlock(&layoutRef, &layblockInfo)) {
		// found ok. now find the template to delete in the layout
		// we also want to ensure we have no 'holes' in the layout, so move any above it in the array
		// down one slot.
		T_LAYOUT *pLayout = (T_LAYOUT*) layblockInfo.pByBlock;
		// are we trying to delete the last template?
		if (!bForce && pLayout->NumTemplates == 1)
			return retValue;  // must have AT LEAST one template in a layout
		int tptSlot = 0;
		for (int tem = 0; tem < pLayout->NumTemplates; tem++) {
			if (pLayout->TemplateList[tem].CMM_Inst == layoutItem->CMM_Inst) // match template to delete
					{
				// found it, wipe it from the array
				ClearLayoutItem(&pLayout->TemplateList[tem]);
			} else {
				if (tptSlot < tem) {
					//copy,	dest<-source
					pLayout->TemplateList[tptSlot] = pLayout->TemplateList[tem];
					ClearLayoutItem(&pLayout->TemplateList[tem]);
				}
				tptSlot++;
			}
		}
		pLayout->NumTemplates--; // one less template now
		m_nextTemplateInst = 1; // reset this here, so that when next template is added it will find first gap.
	}
	// now remove the Template block itself
	BLOCK_INFO temblockInfo;
	if (indexOfDataBlock(layoutItem, &temblockInfo)) {
		// found it,
		T_SCRTEMPLATE *pTemplate = (T_SCRTEMPLATE*) temblockInfo.pByBlock;
		// delete widgets and objects below it...
		for (int w = 0; w < pTemplate->NumWidgets; w++)
			DeleteWidgetandObjects(&pTemplate->WidgetList[w]);
		//now delete it.
		err = DeleteDataBlock(GetConfigId(), &temblockInfo);
		if (err == CMM_SUCCESS)
			retValue = CONFIG_OK;
	}
	return retValue;
}
//****************************************************************************
///
/// Add a new Widget to the specified template 
///
/// @param[in] templateRef	- refrence of template to add Widget to
/// @param[in] blockInfo	- pointer to structure to populate
///
/// @return creation success state
///
//****************************************************************************
T_CONFIG_RETURN_VALUE CLayoutConfiguration::AddWidget(T_LAYOUTITEM *templateRef, BLOCK_INFO *blockInfo) {
	T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;
	CMMERROR err = CMM_FAILED;
	if (templateRef->CMM_Type != BLK_SCRTEMPLATE)
		return retValue;
	// firstly, find the template
	if (indexOfDataBlock(templateRef, blockInfo)) {
		// found ok. now check existing number of Widgets
		T_SCRTEMPLATE *pTemplate = (T_SCRTEMPLATE*) blockInfo->pByBlock;
		if (pTemplate->NumWidgets >= SCRTEMPLATE_WIDGETLIST_SIZE) {
			retValue = CONFIG_NO_MORE_ROOM;
			return retValue;
		}
		// now add a new CMM widget entry
		// need to find first unused instance number.
		// start from m_nextWidgetInst (slow the first time, but faster after that)
		T_LAYOUTITEM widgetRef = { BLK_WIDGET, 0 };
		BOOL found = TRUE;
		do {
			widgetRef.CMM_Inst = m_nextWidgetInst;  // start from here
			found = indexOfDataBlock(&widgetRef, blockInfo);
			m_nextWidgetInst++;
		} while (found);
		// now create it
		err = CreateDataBlock(GetConfigId(), blockInfo);
		if (err == CMM_SUCCESS) {
			// created ok.
			// link Widget to template
			pTemplate->WidgetList[pTemplate->NumWidgets] = widgetRef;
			pTemplate->NumWidgets++;
			retValue = CONFIG_OK;
		}
	}
	return retValue;
}
//****************************************************************************
///
/// Delete a Widget from the Layout 
///
/// @param[in] layoutItem	- reference of widget to delete
///
/// @return deletion success state
///
//****************************************************************************
T_CONFIG_RETURN_VALUE CLayoutConfiguration::DeleteWidget(T_LAYOUTITEM *layoutItem) {
	T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;
	CMMERROR err = CMM_FAILED;
	if (layoutItem->CMM_Type != BLK_WIDGET) // check it is a widget being deleted!
		return retValue;
	// remove its link in the Layout
	T_LAYOUTITEM layoutRef = { BLK_LAYOUT, DEFAULT_LAYOUT_INST };
	BLOCK_INFO layblockInfo;
	if (indexOfDataBlock(&layoutRef, &layblockInfo)) {
		// found ok. now find the widget to delete in the layout
		// we also want to ensure we have no 'holes' in the layout, so move any above it in the array
		// down one slot.
		T_LAYOUT *pLayout = (T_LAYOUT*) layblockInfo.pByBlock;
		for (int tplt = 0; tplt < pLayout->NumTemplates; tplt++) {
			BLOCK_INFO tpltblockInfo;
			if (indexOfDataBlock(&pLayout->TemplateList[tplt], &tpltblockInfo)) {
				T_SCRTEMPLATE *pTemplate = (T_SCRTEMPLATE*) tpltblockInfo.pByBlock;
				int wgtSlot = 0;
				for (int wgt = 0; wgt < pTemplate->NumWidgets; wgt++) {
					if (pTemplate->WidgetList[wgt].CMM_Inst == layoutItem->CMM_Inst) // match widget to delete
							{
						// found it, wipe it from the array
						ClearLayoutItem(&pTemplate->WidgetList[wgt]);
					} else {
						if (wgtSlot < wgt) {
							//copy,	dest<-source
							pTemplate->WidgetList[wgtSlot] = pTemplate->WidgetList[wgt];
							ClearLayoutItem(&pTemplate->WidgetList[wgt]);
						}
						wgtSlot++;
					}
				}
				pTemplate->NumWidgets = wgtSlot;
				m_nextWidgetInst = 1; // reset this here, so that when next widget is added it will find first gap.
			}
		}
	}
	// now remove the Widget block and any objects below it..
	retValue = DeleteWidgetandObjects(layoutItem);
	return retValue;
}
//****************************************************************************
///
/// Delete Widget block and objects blcoks below it from the Layout 
///
/// @param[in] layoutItem	- reference of widget to start from
///
/// @return deletion success state
///
//****************************************************************************
T_CONFIG_RETURN_VALUE CLayoutConfiguration::DeleteWidgetandObjects(T_LAYOUTITEM *layoutItem) {
	T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;
	CMMERROR err = CMM_FAILED;
	BLOCK_INFO widgetblockInfo;
	if (indexOfDataBlock(layoutItem, &widgetblockInfo)) {
		// found it
		T_WIDGET *pWidget = (T_WIDGET*) widgetblockInfo.pByBlock;
		// delete objects below it...
		for (int ob = 0; ob < pWidget->NumObjects; ob++) {
			BLOCK_INFO objectblockInfo;
			if (indexOfDataBlock(&pWidget->ObjectList[ob], &objectblockInfo)) {
				T_BASEOBJECT *pObject = (T_BASEOBJECT*) objectblockInfo.pByBlock;
				// special processing for text and button objects - remove text from variable length CMM text block
				if (pObject->ObjectType == TextObject) {
					T_TEXTOBJECT *pTextObj = (T_TEXTOBJECT*) objectblockInfo.pByBlock;
					if (pTextObj->Offset > 0)
						SetTextString("", &pTextObj->Offset); // set its string to NULL. (removes it)
				}
				DeleteDataBlock(GetConfigId(), &objectblockInfo);
			}
		}
		// now delete the widget
		err = DeleteDataBlock(GetConfigId(), &widgetblockInfo);
	}
	if (err == CMM_SUCCESS)
		retValue = CONFIG_OK;
	return retValue;
}
//****************************************************************************
///
/// Add a new Object to the specified Widget 
///
/// @param[in] widgetRef	- refrence of template to base screen on
/// @param[in] ObjBlockType - BLK_xxxx CMM block type for Object
/// @param[in] blockInfo	- pointer to structure to populate
///
/// @return creation success state
///
//****************************************************************************
T_CONFIG_RETURN_VALUE CLayoutConfiguration::AddObject(T_LAYOUTITEM *widgetRef, T_BLOCKTYPE ObjBlockType,
		BLOCK_INFO *blockInfo) {
	T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;
	CMMERROR err = CMM_FAILED;
	if (widgetRef->CMM_Type != BLK_WIDGET)
		return retValue;
	// firstly, find the widget
	if (indexOfDataBlock(widgetRef, blockInfo)) {
		// found ok. now check existing number of Widgets
		T_WIDGET *pWidget = (T_WIDGET*) blockInfo->pByBlock;
		if (pWidget->NumObjects >= WIDGET_OBJECTLIST_SIZE) {
			retValue = CONFIG_NO_MORE_ROOM;
			return retValue;
		}
		// now add a new CMM derived object entry
		// need to find first unused instance number.
		// start from m_nextObjectInst[] (slow the first time, but faster after that)
		T_LAYOUTITEM objectRef;
		objectRef.CMM_Type = ObjBlockType; // set the actual derived object type we want to add
		int type = BlockTypeToObjectType(ObjBlockType);
		if (type == NoObject) {
			retValue = CONFIG_ERROR;
			return retValue;
		}
		BOOL found = TRUE;
		do {
			objectRef.CMM_Inst = m_nextObjectInst[type];  // start from here
			found = indexOfDataBlock(&objectRef, blockInfo);
			m_nextObjectInst[type]++;
		} while (found);
		// now create it
		err = CreateDataBlock(GetConfigId(), blockInfo);
		if (err == CMM_SUCCESS) {
			// created ok.
			// link object to widget
			pWidget->ObjectList[pWidget->NumObjects] = objectRef;
			pWidget->NumObjects++;
			retValue = CONFIG_OK;
		}
	}
	return retValue;
}
//****************************************************************************
///
/// Delete an Object from the Layout 
///
/// @param[in] layoutItem	- reference of object to delete
///
/// @return deletion success state
///
//****************************************************************************
T_CONFIG_RETURN_VALUE CLayoutConfiguration::DeleteObject(T_LAYOUTITEM *layoutItem) {
	T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;
	CMMERROR err = CMM_FAILED;
	T_OBJECT_TYPE ObjType = BlockTypeToObjectType((T_BLOCKTYPE) layoutItem->CMM_Type);
	if (ObjType == NoObject) // check it is an object being deleted!
		return retValue;
	// remove its link in the Layout
	T_LAYOUTITEM layoutRef = { BLK_LAYOUT, DEFAULT_LAYOUT_INST };
	BLOCK_INFO layblockInfo;
	if (indexOfDataBlock(&layoutRef, &layblockInfo)) {
		// found ok. now find the object to delete in the layout
		// we also want to ensure we have no 'holes' in the layout, so move any above it in the array
		// down one slot.
		T_LAYOUT *pLayout = (T_LAYOUT*) layblockInfo.pByBlock;
		for (int tplt = 0; tplt < pLayout->NumTemplates; tplt++) {
			BLOCK_INFO tpltblockInfo;
			if (indexOfDataBlock(&pLayout->TemplateList[tplt], &tpltblockInfo)) {
				T_SCRTEMPLATE *pTemplate = (T_SCRTEMPLATE*) tpltblockInfo.pByBlock;
				for (int wgt = 0; wgt < pTemplate->NumWidgets; wgt++) {
					BLOCK_INFO wgtblockInfo;
					if (indexOfDataBlock(&pTemplate->WidgetList[wgt], &wgtblockInfo)) {
						T_WIDGET *pWidget = (T_WIDGET*) wgtblockInfo.pByBlock;
						int objSlot = 0;
						// Remove the object to be deleted from the LinkedObj chain 
						T_BASEOBJECT *pPredLinkedObj = NULL; // predecessor object linked to us in LinkedObj chain
						for (int obj = 0; obj < pWidget->NumObjects; obj++) {
							BLOCK_INFO objblockInfo;
							if (indexOfDataBlock(&pWidget->ObjectList[obj], &objblockInfo)) {
								T_BASEOBJECT *pObject = (T_BASEOBJECT*) objblockInfo.pByBlock;
								if (pObject->LinkedObj.CMM_Type == layoutItem->CMM_Type
										&& pObject->LinkedObj.CMM_Inst == layoutItem->CMM_Inst)
									pPredLinkedObj = pObject; // set predecessor object linked to us in LinkedObj chain
							}
							if (pWidget->ObjectList[obj].CMM_Type == layoutItem->CMM_Type
									&& pWidget->ObjectList[obj].CMM_Inst == layoutItem->CMM_Inst) // match object to delete
											{
								BLOCK_INFO objblockInfo;
								if (indexOfDataBlock(&pWidget->ObjectList[obj], &objblockInfo)) {
									T_BASEOBJECT *pObject = (T_BASEOBJECT*) objblockInfo.pByBlock;
									if (pPredLinkedObj) // set predecessor object linked to us in LinkedObj chain to point to what we point to
									{
										pPredLinkedObj->LinkedObj.CMM_Type = pObject->LinkedObj.CMM_Type;
										pPredLinkedObj->LinkedObj.CMM_Inst = pObject->LinkedObj.CMM_Inst;
									}
								}
								// found it, wipe it from the array
								ClearLayoutItem(&pWidget->ObjectList[obj]);
							} else {
								if (objSlot < obj) {
									//copy,	dest<-source
									pWidget->ObjectList[objSlot] = pWidget->ObjectList[obj];
									ClearLayoutItem(&pWidget->ObjectList[obj]);
								}
								objSlot++;
							}
						}
						pWidget->NumObjects = objSlot;
						m_nextObjectInst[ObjType] = 1; // reset this here, so that when next object is added it will find first gap.
					}
				}
			}
		}
	}
	// now remove the Object block itself
	BLOCK_INFO objectblockInfo;
	if (indexOfDataBlock(layoutItem, &objectblockInfo)) {
		// found it, so delete it.
		// special processing for text and button objects - remove text from variable length CMM text block
		if (ObjType == TextObject) {
			T_TEXTOBJECT *pTextObj = (T_TEXTOBJECT*) objectblockInfo.pByBlock;
			if (pTextObj->Offset > 0)
				SetTextString("", &pTextObj->Offset); // set its string to NULL. (removes it)
		}
		err = DeleteDataBlock(GetConfigId(), &objectblockInfo);
		if (err == CMM_SUCCESS)
			retValue = CONFIG_OK;
	}
	return retValue;
}
//****************************************************************************
///
/// Add a Variable length string block to the Layout
///
/// @param[in] blockInfo	- pointer to structure to populate
///
/// @return success state
///
//****************************************************************************
T_CONFIG_RETURN_VALUE CLayoutConfiguration::CreateStringBlock(BLOCK_INFO *blockInfo) {
	T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;
	CMMERROR err = CMM_FAILED;
	blockInfo->dwBlockSize = STRING_BLOCK_CHUNK; // size of variable size block chunks
	err = CreateDataBlock(GetConfigId(), blockInfo);
	if (err == CMM_SUCCESS) {
		// created ok.
		retValue = CONFIG_OK;
	}
	return retValue;
}
//****************************************************************************
///
/// Enlarge the Variable length string block
///
/// @param[in] blockInfo	- pointer to structure with details of variable block
///
/// @return success state
///
//****************************************************************************
T_CONFIG_RETURN_VALUE CLayoutConfiguration::EnlargeStringBlock(BLOCK_INFO *blockInfo) {
	T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;
	CMMERROR err = CMM_FAILED;
	// add another STRING_BLOCK_CHUNK bytes.
	BYTE *pNewblock = new BYTE[blockInfo->dwBlockSize + STRING_BLOCK_CHUNK];
	if (pNewblock == NULL)
		return retValue; // no memory
	// default it all to 0's
	memset(pNewblock, 0, blockInfo->dwBlockSize + STRING_BLOCK_CHUNK);
	// copy existing data into it 
	memcpy(pNewblock, blockInfo->pByBlock, blockInfo->dwBlockSize);
	// and set as the blockinfo pblock
	blockInfo->pByBlock = pNewblock;
	blockInfo->dwBlockSize += STRING_BLOCK_CHUNK;
	int tempsize = blockInfo->dwBlockSize; // keep a copy of the requested size here
	err = ModifyDataBlock(GetConfigId(), blockInfo);
	if (err == CMM_SUCCESS) {
		// modified ok..
		// now need to get it again.
		err = GetDataBlock(GetConfigId(), blockInfo, m_CmmMode); // CONFIG_MODIFIABLE (=working) or CONFIG_COMMITTED (=current)
		if (err == CMM_SUCCESS) {
			//	if(tempsize!=blockInfo->dwBlockSize) // compare the size of what we get back with that requested
			//		DebugBreak();
			retValue = CONFIG_OK;
		}
	}
	delete[] pNewblock;
	return retValue;
}
//****************************************************************************
///
///	Gets a Text string from the Variable length text block in CMM.
/// If the block does not exist it is created.
///
/// @param[in] Offset	- Offset into the variable length text block
///
/// @return pointer to string or NULL pointer
/// 
//****************************************************************************
WCHAR* CLayoutConfiguration::GetTextString(short Offset) {
	T_LAYOUTITEM layoutItem;
	layoutItem.CMM_Type = BLK_VARIABLE_TEXT;		// look for the Variable length text block
	layoutItem.CMM_Inst = DEFAULT_VARBLOCK_INST;	// default instance
	BLOCK_INFO blockInfo;
	if (!indexOfDataBlock(&layoutItem, &blockInfo)) {
		// not found so create it 
		if (CreateStringBlock(&blockInfo) == CONFIG_OK) {
			QString text = (WCHAR*) blockInfo.pByBlock;
			// create a default text string at the start of the block.			
			wcscpy_s(text, wcslen(L"User Text") + 1/*blockInfo.dwBlockSize/sizeof(WCHAR)*/, L"User Text"); /// @todo add to resource file
			return text;
		}
	} else {
		// found ok - return pointer to offset within block.
		if (Offset == -1)
			return ""; // return pointer to null string here
		return &((WCHAR*) blockInfo.pByBlock)[Offset];
	}
	return NULL;
}
//****************************************************************************
///
///	Sets a Text string in the Variable length text block in CMM.
/// If the block does not exist it is created.
/// if the string is replacing an existing one the offset may or may not be
/// updated. The string block will be extended if it fills up.
///
/// @param[in] str			- pointer to string to store
/// @param[in,out] Offset	- Offset into the variable length text block
///
/// @return TRUE/FALSE
/// 
//****************************************************************************
BOOL CLayoutConfiguration::SetTextString(QString str, short *Offset) {
	T_LAYOUTITEM layoutItem;
	layoutItem.CMM_Type = BLK_VARIABLE_TEXT;		// look for the Variable length text block
	layoutItem.CMM_Inst = DEFAULT_VARBLOCK_INST;	// default instance
	BLOCK_INFO blockInfo;
	if (!indexOfDataBlock(&layoutItem, &blockInfo)) {
		// not found so create it 
		if (CreateStringBlock(&blockInfo) == CONFIG_OK) {
			QString text = (WCHAR*) blockInfo.pByBlock;
			// create a default text string at the start of the block.
			int iBuffLength = wcslen(L"User Text") + 1;
			if (iBuffLength > blockInfo.dwBlockSize / sizeof(WCHAR))
				iBuffLength = blockInfo.dwBlockSize / sizeof(WCHAR);
			wcscpy_s(text, iBuffLength/*blockInfo.dwBlockSize/sizeof(WCHAR)*/, L"User Text"); /// @todo add to resource file
		} else
			return FALSE; // not done
	}
	// found block, set up pointer to string data
	QString pVarblock = (WCHAR*) blockInfo.pByBlock;
	int strLen = (int) wcslen(str);
	if (*Offset > 0) // will be if we had a previous string and are updating.
			{
		QString pOldstr = &pVarblock[*Offset];	// get old string location
		int oldstrLen = (int) wcslen(pOldstr);
		if ((strLen > 0) && ((strLen == oldstrLen) || (strLen < oldstrLen - 1))) {
			// new string is equal or more than 1 char shorter in length, so just copy it in.
			wcscpy_s(pOldstr, oldstrLen + 1, str);
			int diffchars = oldstrLen - strLen - 1;
			if (diffchars > 0) {
				// set the extra part to all 0x0101 (leaving the terminator)
				memset(pOldstr + strLen + 1, 1, diffchars * 2);
				//see if we can coalesce strings...
				// Next only in this case
				if (pVarblock[*Offset + oldstrLen + 1] == 0x0101)
					pVarblock[*Offset + oldstrLen] = 0x0101; // next string is empty too. remove the null terminator
			}
			return TRUE;
		}
		// here we have a bigger string, which may/may not fit.
		// remove it here then re-add below.
		memset(pOldstr, 1, oldstrLen * 2); // set old string to all 0x0101 (leaving the terminator)
		// here look to see if we can coalesce strings...
		// previous?
		if (*Offset > 2) {
			if (pVarblock[*Offset - 2] == 0x0101)
				pVarblock[*Offset - 1] = 0x0101; // remove the null, since the string before is empty too!
		}
		// Next?
		if (pVarblock[*Offset + oldstrLen + 1] == 0x0101)
			pVarblock[*Offset + oldstrLen] = 0x0101; // next string is empty too. remove the null terminator
	}
	if (strLen == 0) {
		// NULL string passed.
		// we don't add this, we just set the Offset accordingly
		*Offset = -1; // special case
		return TRUE;
	}
	// adding a new string here
	QString ptext = pVarblock;
	short len = 0;
	short total = 0;
	do {
		len = (short) wcslen(ptext); // length of a string
		if (len) {
			// if this is an 'empty' string slot, and it's the exact size or more than 1 char bigger, then use it.
			if ((*ptext == 0x0101) && ((strLen == len) || (strLen < len - 1))) {
				// will fit.
				wcscpy_s(ptext, len + 1, str);
				*Offset = total;
				return TRUE;
			}
			ptext += len + 1; // move on to next, skipping the null terminator
			total += len + 1; // total size of all strings
		}
	} while (len);
	BOOL doConfigChange = FALSE;
	// ok, got to the end, and still not added string.
	// We must check the size of the block, to make sure there is room..
	if ((int) blockInfo.dwBlockSize < (total + strLen + 2) * 2) // plus 2 null wchar for testing 'next' above
			{
		// here we don't have enough space in the block, so we need to make a new bigger block !!
		if (EnlargeStringBlock(&blockInfo) == CONFIG_OK) {
			// enlarged ok
			pVarblock = (WCHAR*) blockInfo.pByBlock;
			doConfigChange = TRUE;
		} else {
			*Offset = 0; // use the default string at the start of the block.
			return FALSE;
		}
	}
	// ok here we can add the new string.
	*Offset = total;
	ptext = &pVarblock[*Offset];
	int iBuffLength = wcslen(str) + 1;
	if (iBuffLength > (blockInfo.dwBlockSize / sizeof(WCHAR)) - *Offset)
		iBuffLength = blockInfo.dwBlockSize / sizeof(WCHAR) - *Offset;
	wcsncpy_s(ptext,
			iBuffLength/*((blockInfo.dwBlockSize/ sizeof(WCHAR)) - *Offset)*//*(total+strLen+2)*2) /sizeof(WCHAR)*/,
			str, wcslen(str));
//	wcscpy(ptext, str); 
	//wcscpy(ptext, str); 
	if (doConfigChange) {
		if (pSYSTEM_INFO->IsInHotSoakTestMode() == TRUE) {
			if (m_pOpPanel->m_pHotSoakScreen) {
				m_pOpPanel->m_pHotSoakScreen->ConfigChange();
				m_pOpPanel->m_pHotSoakScreen->m_DoneInitalDraw = TRUE;
			}
		} else
			m_pOpPanel->ConfigChange();
	}
	return TRUE;
}
//****************************************************************************
///
/// Convert a BLK_xxx type to a T_OBJECT_TYPE
///
///	Although all configuration blocks can be identified by their BLK_xxx type
/// for derived Objects, we may need to convert it to it's type in the ObjectType
/// enumeration. this can then be used for indexing etc.
///
/// @return T_OBJECT_TYPE (ObjectType)
///
//****************************************************************************
T_OBJECT_TYPE CLayoutConfiguration::BlockTypeToObjectType(T_BLOCKTYPE ObjBlockType) {
	T_OBJECT_TYPE retval = NoObject;
	switch (ObjBlockType) {
	case BLK_EXAMPLEBAR:
		retval = ExampleBar;
		break;
	case BLK_BAROBJECT:
		retval = BarObject;
		break;
	case BLK_SCALEOBJECT:
		retval = ScaleObject;
		break;
	case BLK_PENPTRSOBJECT:
		retval = PenPointersObject;
		break;
	case BLK_ALARMMRKROBJECT:
		retval = AlarmMrkrObject;
		break;
	case BLK_DIGITALOBJECT:
		retval = DigitalObject;
		break;
	case BLK_TEXTOBJECT:
		retval = TextObject;
		break;
	case BLK_CHARTOBJECT:
		retval = ChartObject;
		break;
	case BLK_BITMAPOBJECT:
		retval = BitmapObject;
		break;
	case BLK_CURSOROBJECT:
		retval = CursorObject;
		break;
	case BLK_BUTTONOBJECT:
		retval = ButtonObject;
		break;
	case BLK_TABULAROBJECT:
		retval = TabularDisplayObject;
		break;
	case BLK_TUSOBJECT:
		retval = TUSObject;
		break;
	case BLK_CIRCCHARTOBJECT:
		retval = CircularChartObject;
		break;
	default:
		retval = NoObject;
		break;
	}
	if (retval >= SUPPORTED_OBJECT_TYPES)
		retval = NoObject;
	return retval;
}
//****************************************************************************
///
/// Check layout references - needs to be done on Working config
///
/// @param[in] blockInfo	- pointer to structure check
///
/// @return TRUE if OK, FALSE if not.
///
//****************************************************************************
BOOL CLayoutConfiguration::CheckLayoutRefs(BLOCK_INFO *blockInfo) {
	T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;
	CMMERROR err = CMM_FAILED;
	err = GetDataBlock(GetConfigId(), blockInfo, CONFIG_MODIFIABLE); // ALWAYS modifiable here 
	if (err == CMM_SUCCESS) {
		switch (blockInfo->wBlockType) {
		case BLK_LAYOUT: {
			// need to check our TemplateList and ScreenList
			// NB the array of templates may have 'holes' in it (null entries where type and inst are 0)
			// OR may have an entry that cannot be found. (to be 'cleared' here)
			T_LAYOUT *pLayout = (T_LAYOUT*) blockInfo->pByBlock;
			int tptSlot = 0;
			for (int tem = 0; (tptSlot < pLayout->NumTemplates) && (tem < LAYOUT_TEMPLATELIST_SIZE); tem++) {
				BLOCK_INFO tptBlockInfo;
				if (indexOfDataBlock(&pLayout->TemplateList[tem], &tptBlockInfo)) // populate the Block_Info					
						{
					if (tptSlot < tem) {
						//copy,	dest<-source
						pLayout->TemplateList[tptSlot] = pLayout->TemplateList[tem];
						ClearLayoutItem(&pLayout->TemplateList[tem]);
					}
					if (CheckLayoutRefs(&tptBlockInfo) == FALSE) // now check this template's refs
						DeleteDataBlock(GetConfigId(), &tptBlockInfo);
					else
						tptSlot++;
				} else
					ClearLayoutItem(&pLayout->TemplateList[tem]);
			}
			// update it with actual number of valid templates found 
			pLayout->NumTemplates = tptSlot;
			// NB the array of screens may have 'holes' in it (null entries where type and inst are 0)
			// OR may have an entry that cannot be found. (to be 'cleared' here)
			int scrSlot = 0;
			for (int scr = 0; (scrSlot < pLayout->NumScreens) && (scr < LAYOUT_SCREENLIST_SIZE); scr++) {
				BLOCK_INFO scrBlockInfo;
				if (indexOfDataBlock(&pLayout->ScreenList[scr], &scrBlockInfo)) // populate the Block_Info
						{
					if (scrSlot < scr) {
						//copy,	dest<-source
						pLayout->ScreenList[scrSlot] = pLayout->ScreenList[scr];
						ClearLayoutItem(&pLayout->ScreenList[scr]);
					}
					if (CheckLayoutRefs(&scrBlockInfo) == FALSE) // now check this Screen's refs						
						DeleteDataBlock(GetConfigId(), &scrBlockInfo);
					else
						scrSlot++;
				} else
					ClearLayoutItem(&pLayout->ScreenList[scr]);
			}
			// update it with actual total number of valid screens found 
			pLayout->NumScreens = scrSlot;
			return (pLayout->NumTemplates >= 0); // must have at least one template for layout to be valid
		}
			break;
		case BLK_SCRTEMPLATE: {
			T_SCRTEMPLATE *pTemplate = (T_SCRTEMPLATE*) blockInfo->pByBlock;
			// NB the array of widgets may have 'holes' in it (null entries where type and inst are 0)
			// OR may have an entry that cannot be found. (to be 'cleared' here)
			int wgtSlot = 0;
			for (int wgt = 0; (wgtSlot < pTemplate->NumWidgets) && (wgt < SCRTEMPLATE_WIDGETLIST_SIZE); wgt++) {
				BLOCK_INFO wgtBlockInfo;
				if (indexOfDataBlock(&pTemplate->WidgetList[wgt], &wgtBlockInfo)) // populate the Block_Info
						{
					if (wgtSlot < wgt) {
						//copy,	dest<-source
						pTemplate->WidgetList[wgtSlot] = pTemplate->WidgetList[wgt];
						ClearLayoutItem(&pTemplate->WidgetList[wgt]);
					}
					if (CheckLayoutRefs(&wgtBlockInfo) == FALSE) // now check this Widget's refs						
						DeleteDataBlock(GetConfigId(), &wgtBlockInfo);
					else
						wgtSlot++;
				} else
					ClearLayoutItem(&pTemplate->WidgetList[wgt]);
			}
			// update it with actual total number of valid widgets found 
			pTemplate->NumWidgets = wgtSlot;
			return TRUE; // even if non of the widgets are valid, still return empty template as ok.
		}
			break;
		case BLK_SCREEN: {
			// ensure the template exists. (ONLY for CUSTOM screens)
			T_SCREEN *pScreen = (T_SCREEN*) blockInfo->pByBlock;
			if (pScreen->Type == TPL_CUSTOM) {
				m_IsCustomLayout = TRUE; // so we know to check the valid flag
				BLOCK_INFO tptBlockInfo;
				return indexOfDataBlock(&pScreen->Template, &tptBlockInfo); // TRUE or FALSE
			} else
				return TRUE;
		}
			break;
		case BLK_WIDGET: {
			T_WIDGET *pWidget = (T_WIDGET*) blockInfo->pByBlock;
			// NB the array of objects may have 'holes' in it (null entries where type and inst are 0)
			// OR may have an entry that cannot be found. (to be 'cleared' here)
			int objSlot = 0;
			for (int obj = 0; (objSlot < pWidget->NumObjects) && (obj < WIDGET_OBJECTLIST_SIZE); obj++) {
				BLOCK_INFO objBlockInfo;
				if (indexOfDataBlock(&pWidget->ObjectList[obj], &objBlockInfo)) // populate the Block_Info
						{
					if (objSlot < obj) {
						//copy,	dest<-source
						pWidget->ObjectList[objSlot] = pWidget->ObjectList[obj];
						ClearLayoutItem(&pWidget->ObjectList[obj]);
					}
					objSlot++;
					if (objBlockInfo.wBlockType == BLK_BITMAPOBJECT)
						m_ContainsBitmapObjects = TRUE; // we should expect to find a .bcf file too
				} else
					ClearLayoutItem(&pWidget->ObjectList[obj]);
			}
			// update it with actual total number of valid objects found 
			pWidget->NumObjects = objSlot;
			return TRUE; // even if non of the Objects are valid, still return empty Widget as ok.
		}
		default:
			break;
		}
	}
	return FALSE;
}
//****************************************************************************
///
/// Setup the LayoutConfiguration so that blocks are acquired from the CMM as
/// 'current' or 'working'
///
///	NB: Persisted configs will be loaded into Current - these are OK.
///		New configs will be loaded into Working - these need to be 
/// checked before comitting (putting into current) and persisting.
///	
///		When OpPanel is running in 'designer mode' we need to be accessing
///		'working'. At other times we should access 'current' for efficiency.
///
/// @param[in] currentORworking	- new mode of operation
///
/// @return none
///
//****************************************************************************
void CLayoutConfiguration::SetCMMmode(REFERENCE currentORworking) {
#ifdef DOCVIEW  
	m_CmmMode=CONFIG_MODIFIABLE; // for Screen Designer, this is the ONLY option.
#else
	m_CmmMode = currentORworking;
#endif
}
REFERENCE CLayoutConfiguration::GetCMMmode() {
	return m_CmmMode;
}
//****************************************************************************
///
/// indexOf a Data block within the CMM matching a LayoutItem
///
/// @param[in] layoutItem	- pointer to T_LAYOUTITEM
/// @param[in] blockInfo	- pointer to structure to populate
///
/// @return TRUE/FALSE
///
//****************************************************************************
BOOL CLayoutConfiguration::indexOfDataBlock(T_LAYOUTITEM *layoutItem, BLOCK_INFO *blockInfo) {
	CMMERROR err = CMM_FAILED;
	// configure the BLOCK_INFO struct with what we do know.
	blockInfo->wInstanceID = layoutItem->CMM_Inst;
	blockInfo->wBlockType = layoutItem->CMM_Type;
	// unknown, so set to defaults
	blockInfo->dwSessionNumber = 0;
	blockInfo->dwBlockSize = 0;
	blockInfo->pByBlock = NULL;
	err = GetDataBlock(GetConfigId(), blockInfo, m_CmmMode); // CONFIG_MODIFIABLE (=working) or CONFIG_COMMITTED (=current)
	if (err == CMM_SUCCESS)
		return TRUE;
	return FALSE;
}
//****************************************************************************
///
/// clear a LayoutItem reference
///
/// @param[in] layoutItem	- pointer to T_LAYOUTITEM
///
/// @return none
///
//****************************************************************************
void CLayoutConfiguration::ClearLayoutItem(T_LAYOUTITEM *layoutItem) {
	layoutItem->CMM_Inst = 0;
	layoutItem->CMM_Type = 0;
}
//****************************************************************************
///
/// Gets a LayoutItem from a BLOCK_INFO struct
///
/// @param[in] blockinfo - BLOCK_INFO struct to extract layout info from
///
/// @return T_LAYOUTITEM
/// 
//****************************************************************************
T_LAYOUTITEM CLayoutConfiguration::BlockInfoToLayoutItem(BLOCK_INFO *blockinfo) {
	T_LAYOUTITEM layoutItem;
	layoutItem.CMM_Type = blockinfo->wBlockType;
	layoutItem.CMM_Inst = blockinfo->wInstanceID;
	return layoutItem;
}
//****************************************************************************
///
/// Gets the type of recorder that the layout was designed for 
///
/// @param none
///
/// @return T_DEV_TYPE
/// 
//****************************************************************************
T_DEV_TYPE CLayoutConfiguration::GetRecorderType() {
	T_LAYOUTITEM layoutItem;
	layoutItem.CMM_Type = BLK_LAYOUT;				// look for the Layout block
	layoutItem.CMM_Inst = DEFAULT_LAYOUT_INST;	// of the default instance
	BLOCK_INFO blockInfo;
	if (indexOfDataBlock(&layoutItem, &blockInfo)) {
		T_LAYOUT *pLyt = (T_LAYOUT*) blockInfo.pByBlock;
		return (T_DEV_TYPE) pLyt->RecorderType;
	}
	return DEV_UNKNOWN;
}
//****************************************************************************
///
/// Validate loaded Layout Configuration 
/// check it is a layout (doh!) and remove any 'holes'
///
/// @return T_LAYOUTITEM
/// 
//****************************************************************************
T_CONFIG_VALIDATE_RETURN CLayoutConfiguration::ValidateConfiguration(void) {
	T_CONFIG_VALIDATE_RETURN eRetVal = CONFIG_VALIDATE_NO_CHANGES;
	SetCMMmode(CONFIG_MODIFIABLE);
	T_LAYOUTITEM layoutItem;
	layoutItem.CMM_Type = BLK_LAYOUT;				// look for the Layout block
	layoutItem.CMM_Inst = DEFAULT_LAYOUT_INST;	// of the default instance
	BLOCK_INFO blockInfo;
	//The support is only available the X-series standard screens load in the GR-recorder only 
	//hence disabling the custom screens in the loaded layout
	//Added bool variables to disable the Custom screens in the Mini and Multitrend recorders.
	BOOL bX_Series_Lay_Load_In_Multi, bX_Series_Lay_Load_In_Mini;
	bX_Series_Lay_Load_In_Multi = FALSE;
	bX_Series_Lay_Load_In_Mini = FALSE;
	if (indexOfDataBlock(&layoutItem, &blockInfo)) {
		// found it ok, 
		// here check the type of the layout loaded.	
		T_LAYOUT *pLyt = (T_LAYOUT*) blockInfo.pByBlock;
		BOOL correctTypeAndValid = FALSE;
		T_DEV_TYPE devType = pDEVICE_INFO->GetDeviceType();
#ifndef DOCVIEW		
		if (((T_DEV_TYPE) pLyt->RecorderType == DEV_ARISTOS_MULTIPLUS || (T_DEV_TYPE) pLyt->RecorderType == DEV_PC_MULTI
				|| (T_DEV_TYPE) pLyt->RecorderType == DEV_SCR_MINITREND)
				&& (devType == DEV_ARISTOS_MULTIPLUS || devType == DEV_PC_MULTI || devType == DEV_SCR_MINITREND))
			correctTypeAndValid = TRUE;
		else if ((T_DEV_TYPE) pLyt->RecorderType == DEV_XS_MULTIPLUS
				&& (devType == DEV_XS_MULTIPLUS || devType == DEV_PC_MULTI))
			correctTypeAndValid = TRUE;
		else if ((T_DEV_TYPE) pLyt->RecorderType == DEV_ARISTOS_MINITREND
				&& (devType == DEV_ARISTOS_MINITREND || devType == DEV_PC_MINI))
			correctTypeAndValid = TRUE;
		else if ((T_DEV_TYPE) pLyt->RecorderType == DEV_XS_MINITREND
				&& (devType == DEV_XS_MINITREND || devType == DEV_PC_MINI))
			correctTypeAndValid = TRUE;
		else if (((T_DEV_TYPE) pLyt->RecorderType == DEV_XS_EZTREND)
				&& ((devType == DEV_XS_EZTREND) || (devType == DEV_PC_EZTREND)))
			correctTypeAndValid = TRUE;
		//ARISTOS QXe Device Type updates
		else if (((T_DEV_TYPE) pLyt->RecorderType == DEV_ARISTOS_EZTREND)
				&& ((devType == DEV_ARISTOS_EZTREND) || (devType == DEV_PC_EZTREND)))
			correctTypeAndValid = TRUE;
		//Kiran: Is added for the layout support from X to GR
		else if ((T_DEV_TYPE) pLyt->RecorderType == DEV_XS_MULTIPLUS
				&& (devType == DEV_ARISTOS_MULTIPLUS || devType == DEV_PC_MULTI || devType == DEV_SCR_MINITREND))
			correctTypeAndValid = TRUE;
		else if ((T_DEV_TYPE) pLyt->RecorderType == DEV_XS_MINITREND
				&& (devType == DEV_ARISTOS_MINITREND || devType == DEV_PC_MINI))
			correctTypeAndValid = TRUE;
		//PSR: Is added for the layout support from X to GR EZTrend
		else if (((T_DEV_TYPE) pLyt->RecorderType == DEV_XS_EZTREND)
				&& ((devType == DEV_ARISTOS_EZTREND) || (devType == DEV_PC_EZTREND)))
			correctTypeAndValid = TRUE;
		else if (((T_DEV_TYPE) pLyt->RecorderType == DEV_PC_MINI) && (devType == DEV_PC_MINI)) {
			correctTypeAndValid = TRUE;
		}
#else
		correctTypeAndValid=TRUE; // for screen designer, treat as ok.
#endif
		m_IsCustomLayout = FALSE; // set this here, will be updated in CheckLayoutRefs
		m_ContainsBitmapObjects = FALSE;
		m_MissingBCF = FALSE;
		BOOL IsOk = CheckLayoutRefs(&blockInfo);
		// check the number of screens and templates
		if (((T_DEV_TYPE) pLyt->RecorderType == DEV_ARISTOS_MULTIPLUS
				|| (T_DEV_TYPE) pLyt->RecorderType == DEV_SCR_MINITREND)
				&& (devType == DEV_ARISTOS_MULTIPLUS || devType == DEV_SCR_MINITREND)) // Added by kiran for lay out compatability						
				{
			if (pLyt->NumTemplates > CScreen::ms_usMAX_MULTI_SCREENS)
				pLyt->NumTemplates = CScreen::ms_usMAX_MULTI_SCREENS;
			if (pLyt->NumScreens > CScreen::ms_usMAX_MULTI_SCREENS)
				pLyt->NumScreens = CScreen::ms_usMAX_MULTI_SCREENS;
		} else if ((T_DEV_TYPE) pLyt->RecorderType == DEV_ARISTOS_MINITREND && devType == DEV_ARISTOS_MINITREND) // Added by kiran for lay out compatability
				{
			if (pLyt->NumTemplates > CScreen::ms_usMAX_MINI_SCREENS)
				pLyt->NumTemplates = CScreen::ms_usMAX_MINI_SCREENS;
			if (pLyt->NumScreens > CScreen::ms_usMAX_MINI_SCREENS)
				pLyt->NumScreens = CScreen::ms_usMAX_MINI_SCREENS;
		}
		//ARISTOS QXe Device Type updates
		else if (((T_DEV_TYPE) pLyt->RecorderType == DEV_XS_EZTREND)
				|| ((T_DEV_TYPE) pLyt->RecorderType == DEV_ARISTOS_EZTREND)) {
			if (pLyt->NumTemplates > CScreen::ms_usMAX_EZ_SCREENS)
				pLyt->NumTemplates = CScreen::ms_usMAX_EZ_SCREENS;
			if (pLyt->NumScreens > CScreen::ms_usMAX_EZ_SCREENS)
				pLyt->NumScreens = CScreen::ms_usMAX_EZ_SCREENS;
		} else if ((T_DEV_TYPE) pLyt->RecorderType == DEV_XS_MULTIPLUS && devType == DEV_XS_MULTIPLUS) // Added by kiran for lay out compatability
				{
			if (pLyt->NumTemplates > CScreen::ms_usMAX_XS_MULTI_SCREENS)
				pLyt->NumTemplates = CScreen::ms_usMAX_XS_MULTI_SCREENS;
			if (pLyt->NumScreens > CScreen::ms_usMAX_XS_MULTI_SCREENS)
				pLyt->NumScreens = CScreen::ms_usMAX_XS_MULTI_SCREENS;
		} else if ((T_DEV_TYPE) pLyt->RecorderType == DEV_XS_MINITREND && devType == DEV_XS_MINITREND) // Added by kiran for lay out compatability
				{
			if (pLyt->NumTemplates > CScreen::ms_usMAX_XS_MINI_SCREENS)
				pLyt->NumTemplates = CScreen::ms_usMAX_XS_MINI_SCREENS;
			if (pLyt->NumScreens > CScreen::ms_usMAX_XS_MINI_SCREENS)
				pLyt->NumScreens = CScreen::ms_usMAX_XS_MINI_SCREENS;
		}
		//added two conditions for the lay out compatability from V6 to GR.
		else if ((T_DEV_TYPE) pLyt->RecorderType == DEV_XS_MULTIPLUS
				&& (devType == DEV_ARISTOS_MULTIPLUS || devType == DEV_SCR_MINITREND)) // Added by kiran for lay out compatability
				{
			bX_Series_Lay_Load_In_Multi = TRUE;
			if (pLyt->NumTemplates > CScreen::ms_usMAX_MULTI_SCREENS)
				pLyt->NumTemplates = CScreen::ms_usMAX_MULTI_SCREENS;
			if (pLyt->NumScreens > CScreen::ms_usMAX_MULTI_SCREENS)
				pLyt->NumScreens = CScreen::ms_usMAX_MULTI_SCREENS;
		} else if ((T_DEV_TYPE) pLyt->RecorderType == DEV_XS_MINITREND && devType == DEV_ARISTOS_MINITREND) // Added by kiran for lay out compatability
				{
			bX_Series_Lay_Load_In_Mini = TRUE;
			if (pLyt->NumTemplates > CScreen::ms_usMAX_MINI_SCREENS)
				pLyt->NumTemplates = CScreen::ms_usMAX_MINI_SCREENS;
			if (pLyt->NumScreens > CScreen::ms_usMAX_MINI_SCREENS)
				pLyt->NumScreens = CScreen::ms_usMAX_MINI_SCREENS;
		}
#ifndef DOCVIEW
		if ((m_IsCustomLayout) || (pLyt->NumScreens > 0)) // not when we are loading a template (.tpl)
				{
			// if it is custom, it has to have been validated otherwise we won't load it.
			if (!pLyt->IsValid) {
				correctTypeAndValid = FALSE;
			} else {
				// loop through all the screen setting their states to disabled if showing a custom screen and the
				// custom screen firmware option is disabled
				eRetVal = CheckCustomScreens(pLyt);
				//Disable the customscreens if x-series layout is having and loading in the GR mini or multitrend recorder
				if (bX_Series_Lay_Load_In_Multi == TRUE || bX_Series_Lay_Load_In_Mini == TRUE) {
					correctTypeAndValid = DisableCustomScreensForXSeriesLayoutInGR(pLyt);
				}
			}
		} else {
			pLyt->IsValid = TRUE; // set it here for any non-custom layout we have 
			// loop through all the screen setting their states to disabled if showing a custom screen and the
			// custom screen firmware option is disabled
			eRetVal = CheckCustomScreens(pLyt);
			if (bX_Series_Lay_Load_In_Multi == TRUE || bX_Series_Lay_Load_In_Mini == TRUE) {
				correctTypeAndValid = DisableCustomScreensForXSeriesLayoutInGR(pLyt);
			}
		}
#endif
		if (IsOk && pLyt->IsValid) {
			// check circular chart screens are also allowed
			eRetVal = CheckCircularChartScreens(pLyt);
			// check if this is a AMS2750 TUS recorder in which case we must add a AMS2750 TUS screen
			// or disable them potnetially if the feature is not available
			eRetVal = CheckAMS2750TUSScreen(pLyt);
			// check process screens are also allowed
			eRetVal = CheckAMS2750ProcessScreen(pLyt);
		}
		if (!correctTypeAndValid) {
			eRetVal = CONFIG_VALIDATE_INVALID;
		} else if (IsOk) {
			eRetVal = CONFIG_VALIDATE_CHANGES_MADE; // just means ok, (may/maynot have made changes)
		} else {
			eRetVal = CONFIG_VALIDATE_INVALID;
		}
	} else {
		eRetVal = CONFIG_VALIDATE_INVALID;
	}
	return eRetVal;
} // End of ValidateConfiguration()
//****************************************************************************
// T_CONFIG_VALIDATE_RETURN CheckCustomScreens( T_LAYOUT *ptLayout )
///
/// Method that loops through all the screen setting their states to disabled if 
/// showing a custom screen and the custom screen firmware option is disabled
///
/// @param[in]	T_LAYOUT *ptLayout - Pointer to the modifiable layout
///
/// return CONFIG_VALIDATE_CHANGES_MADE if some custom screens were disabled else CONFIG_OK
///
//****************************************************************************
T_CONFIG_VALIDATE_RETURN CLayoutConfiguration::CheckCustomScreens(T_LAYOUT *ptLayout) {
	T_CONFIG_VALIDATE_RETURN eRetVal = CONFIG_VALIDATE_NO_CHANGES;
	// check if custom screens are allowed first
#ifdef UNDER_CE
	if( pSYSTEM_INFO->FWOptionCustomScreensAvailable() == FALSE )
#else
	if (( pSYSTEM_INFO->FWOptionCustomScreensAvailable() == FALSE) && (!CEmulator::m_SimulatorVol[0])) // if running as screen designer simulator, ignore the Options
#endif
			{
		// go through the screens disabling them if they are not canned one
		for (int iScreenNo = 0; iScreenNo < ptLayout->NumScreens; iScreenNo++) {
			BLOCK_INFO tBlockInfo;
			if (indexOfDataBlock(&ptLayout->ScreenList[iScreenNo], &tBlockInfo)) {
				T_PSCREEN ptScreen = reinterpret_cast<T_PSCREEN>(tBlockInfo.pByBlock);
				if ((ptScreen->Enabled == TRUE) && (ptScreen->Type >= TPL_LAST_CANNED)
						&& (ptScreen->Type <= TPL_CUSTOM)) {
					// Make sure that u dont disable non process screen
					if (ptScreen->Type < TPL_ALARM || ptScreen->Type > TPL_NP_LAST) {
						// this is a custom screen, therefore disable it
						ptScreen->Enabled = FALSE;
						// if this is the first screen to be changed then log a diagnostic message
						if (eRetVal == CONFIG_VALIDATE_NO_CHANGES) {
							LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR,
									"Custom Screen firmware option disabled - Custom screen(s) disabled");
							eRetVal = CONFIG_VALIDATE_CHANGES_MADE;
						}
					}
				}
			}
		}
	}
	return eRetVal;
}
//****************************************************************************
///
/// Method that loops through all the screens checking if they are circular chart screens
/// The screen will be disabled if it is a circular chart screen and the circular chart
/// feature is not available
///
/// @param[in]	T_LAYOUT *ptLayout - Pointer to the modifiable layout
///
/// return CONFIG_VALIDATE_CHANGES_MADE if circular chart screens were disabled else CONFIG_OK
///
//****************************************************************************
T_CONFIG_VALIDATE_RETURN CLayoutConfiguration::CheckCircularChartScreens(T_LAYOUT *ptLayout) {
	T_CONFIG_VALIDATE_RETURN eRetVal = CONFIG_VALIDATE_NO_CHANGES;
	// go through disabling circular chart screens if the circular chart mode is unavailable
	if (!pDEVICE_INFO->IsCircularChartModeAvailable()) {
		// go through the screens attempting to find the NADCAP process screens
		for (int iScreenNo = 0; iScreenNo < ptLayout->NumScreens; iScreenNo++) {
			BLOCK_INFO tBlockInfo;
			if (indexOfDataBlock(&ptLayout->ScreenList[iScreenNo], &tBlockInfo)) {
				T_PSCREEN ptScreen = reinterpret_cast<T_PSCREEN>(tBlockInfo.pByBlock);
				if ((ptScreen->Type == TPL_CIRC_CHRT_DPMS) && (ptScreen->Enabled == true)) {
					// this is a circular chart screen and it is still enabled thefore disable it
					ptScreen->Enabled = false;
					// display a message if this is the first time we have disabled a screen
					if (eRetVal == CONFIG_VALIDATE_NO_CHANGES) {
						LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR,
								"Circular chart process screen(s) disabled as the feature is not available");
					}
					eRetVal = CONFIG_VALIDATE_CHANGES_MADE;
				}
			}
		}
	}
	return eRetVal;
}
//****************************************************************************
///
/// Method that loops through all the screens checking if they are a TUS mode screen
/// Various actions are taken depending on the outcome of this test and the state of
/// the TUS mode firmware option
///
/// @param[in]	T_LAYOUT *ptLayout - Pointer to the modifiable layout
///
/// return CONFIG_VALIDATE_CHANGES_MADE if TUS screen was added or removed else CONFIG_OK
///
//****************************************************************************
T_CONFIG_VALIDATE_RETURN CLayoutConfiguration::CheckAMS2750TUSScreen(T_LAYOUT *ptLayout) {
	T_CONFIG_VALIDATE_RETURN eRetVal = CONFIG_VALIDATE_NO_CHANGES;
#ifndef DOCVIEW
	// do not show the TUS screen in screen designer
	if ( pSYSTEM_INFO->FWOptionTUSModeAvailable()) {
		bool bFoundTUS = false;
		// go through the screens attempting to find the TUS screen
		for (int iScreenNo = 0; iScreenNo < ptLayout->NumScreens; iScreenNo++) {
			BLOCK_INFO tBlockInfo;
			if (indexOfDataBlock(&ptLayout->ScreenList[iScreenNo], &tBlockInfo)) {
				T_PSCREEN ptScreen = reinterpret_cast<T_PSCREEN>(tBlockInfo.pByBlock);
				if (ptScreen->Type == TPL_AMS2750_TUS_SCREEN) {
					bFoundTUS = true;
					break;
				}
			}
		}
		// check if the screen was found
		if (!bFoundTUS) {
			BLOCK_INFO tBlockInfo;
			// no screen found so add it
			AddScreen(NULL, &tBlockInfo);
			T_PSCREEN ptScreen = reinterpret_cast<T_PSCREEN>(tBlockInfo.pByBlock);
			ptScreen->Type = TPL_AMS2750_TUS_SCREEN;
			ptScreen->Enabled = true;
			ptScreen->CannedPens[0].PenIndex = gs_usSPECIAL_TUS_PEN_START_INST;
			ptScreen->CannedPens[1].PenIndex = gs_usSPECIAL_TUS_PEN_START_INST + 1;
			ptScreen->CannedPens[0].Scale = TRUE;
			COLORREF crScreenBkgCol = QString(0, 0, 0);
			ptScreen->BackColour = static_cast<ULONG>(RGBtoRGB565(crScreenBkgCol));
			CStringUtils::SafeWcsCpy(ptScreen->Name, L"AMS2750 TUS", SCREEN_NAME_LEN);
			LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_INFO, L"TUS Screen added");
			eRetVal = CONFIG_VALIDATE_CHANGES_MADE;
		}
	} else {
		// TUS mode is not available therefore we must remove a TUS screen that maybe present
		// go through the screens attempting to find the TUS screen
		for (int iScreenNo = 0; iScreenNo < ptLayout->NumScreens; iScreenNo++) {
			BLOCK_INFO tBlockInfo;
			if (indexOfDataBlock(&ptLayout->ScreenList[iScreenNo], &tBlockInfo)) {
				T_PSCREEN ptScreen = reinterpret_cast<T_PSCREEN>(tBlockInfo.pByBlock);
				if (ptScreen->Type == TPL_AMS2750_TUS_SCREEN) {
					// found the TUS screen - remove it
					T_LAYOUTITEM tDeleteScreenLytData;
					tDeleteScreenLytData.CMM_Type = tBlockInfo.wBlockType;
					tDeleteScreenLytData.CMM_Inst = tBlockInfo.wInstanceID;
					DeleteScreen(&tDeleteScreenLytData);
					LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_WARNING,
							L"AMS2750 TUS Screen removed from the layout");
					eRetVal = CONFIG_VALIDATE_CHANGES_MADE;
					break;
				}
			}
		}
	}
#endif
	return eRetVal;
}
//****************************************************************************
///
/// Method that loops through all the screens checking if they are a AMS2750D process screens
/// Various actions are taken depending on the outcome of this test and the state of
/// the AMS2750D Nadcap mode firmware option
///
/// @param[in]	T_LAYOUT *ptLayout - Pointer to the modifiable layout
///
/// return CONFIG_VALIDATE_CHANGES_MADE if AMS2750D screens were disabled else CONFIG_OK
///
//****************************************************************************
T_CONFIG_VALIDATE_RETURN CLayoutConfiguration::CheckAMS2750ProcessScreen(T_LAYOUT *ptLayout) {
	T_CONFIG_VALIDATE_RETURN eRetVal = CONFIG_VALIDATE_NO_CHANGES;
	// go through dislabing NADCAP process screens if the fw option is not enabled
	if ( pSYSTEM_INFO->GetAMS2750Mode() != AMS2750_PROCESS) {
		// go through the screens attempting to find the NADCAP process screens
		for (int iScreenNo = 0; iScreenNo < ptLayout->NumScreens; iScreenNo++) {
			BLOCK_INFO tBlockInfo;
			if (indexOfDataBlock(&ptLayout->ScreenList[iScreenNo], &tBlockInfo)) {
				T_PSCREEN ptScreen = reinterpret_cast<T_PSCREEN>(tBlockInfo.pByBlock);
				if ((ptScreen->Type == TPL_AMS2750_PROCESS_SCREEN) && (ptScreen->Enabled == true)) {
					// this is a NADCAP screen and it is still enabled thefore disable it
					ptScreen->Enabled = false;
					// display a message if this is the first time we have disabled a screen
					if (eRetVal == CONFIG_VALIDATE_NO_CHANGES) {
						LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR,
								"AMS2750D NADCAP Process screen(s) disabled");
					}
					eRetVal = CONFIG_VALIDATE_CHANGES_MADE;
				}
			}
		}
	}
	return eRetVal;
}
//****************************************************************************
///
/// Change file extension to '.bcf'
///
/// @param[in] filename	- pointer layout filename
///
/// @return none
///
//****************************************************************************
void MakeDotBCF(QString filename) {
	int len = wcslen(filename);
	while (filename[len - 1] != L'.')
		len--;
	swprintf(&filename[len], L"bcf"); // add the extension.
}
//****************************************************************************
///
/// Load a Layout Configuration - and handle any bitmaps in .bcf
///
/// @param[in] fileToLoadConfig	- ref to QFile
/// @param[in] persistedLoad	- is this a persisted load?
///
/// @return T_CONFIG_RETURN_VALUE
///
//****************************************************************************
T_CONFIG_RETURN_VALUE CLayoutConfiguration::LoadConfig(QFile &fileToLoadConfig, const TV_BOOL persistedLoad) {
	T_CONFIG_RETURN_VALUE retval;
	retval = LoadConfigService(fileToLoadConfig, CONFIG_LAYOUT_FILE_TYPE, persistedLoad);
	if ((retval == CONFIG_OK_VALIDATE_UPDATED_CMM) || (retval == CONFIG_OK)) {
		// loaded ok, now check to see if there is a bitmap collection file to load (*.bcf)
#ifdef DOCVIEW
		if(!iscntrl(fileToLoadConfig.GetFileName().at(0))) // check it's not a control char (i.e. CMEMFILE!!!)
		{
			// see if there is a correcsponding .bcf file with the layout
			// if so need to load Dibs to screen designers library .bcf
			WCHAR bcf_filename[MAX_PATH];
			wcscpy(bcf_filename,fileToLoadConfig.GetFilePath());
			MakeDotBCF(bcf_filename); // change the extension to .bcf
			CStorage bcfFile;
			if(bcfFile.exists(bcf_filename))
			{
				// layout's BCF file exists - so update the screen designer library with the images	
				
				CBitmapCollectionFile bcfSource(bcf_filename,CBitmapCollectionFile::ReadOnly);
				WCHAR SDfilename[MAX_PATH];
				CBitmapCollectionFile::BuildFilename(SDfilename);
				CBitmapCollectionFile SDlib(SDfilename,CBitmapCollectionFile::ReadOnlyWrite);
				SDlib.UpdateCollection(&bcfSource,DEV_PC_SCREEN_DESIGNER);
			}
		}
#else
		if (!persistedLoad) {
			qDebug("~=~=~=~=~= NON-PERSISTED LOAD =~=~=~=~=~\n");
			// see if there is a correcsponding .bcf file with the layout
			WCHAR bcf_filename[MAX_PATH];
			wcscpy_s(bcf_filename, MAX_PATH, fileToLoadConfig.GetFilePath());
			MakeDotBCF(bcf_filename); // change the extension to .bcf
			// form filename of the DefaultLayoutConfig bcf file
			WCHAR BCFname[MAX_PATH];
			CBitmapCollectionFile::BuildFilename(BCFname);
			// for recorder we need to look for .bcf file with the same name as the layout, and copy
			// this to the config folder, renamed as 'DefaultLayoutConfig.bcf'
			CStorage bcfFile;
			if (bcfFile.exists(bcf_filename)) {
				// copy the file in as the new recorder bitmap collection
				QFile::copy(bcf_filename,BCFname); // and overwrite if exists
			} else {
				if (bcfFile.exists(BCFname))
					bcfFile.remove(BCFname); // delete any old DefaultLayoutConfig bcf file when new layout without bitmaps loaded
				// No bcf file, so check to see if the layout has any bitmaps in it and if it does tell the user they are being silly
				if (m_ContainsBitmapObjects == TRUE)
					m_MissingBCF = TRUE; // flag this here for later
			}
		} else {
			qDebug("~=~=~=~=~= PERSISTED LOAD =~=~=~=~=~\n");
			m_MissingBCF = FALSE; // can't be missing
		}
#endif
	}
	return retval;
}
//****************************************************************************
///
/// Save a Layout Configuration - and handle any bitmaps in .bcf
///
/// @param[in] fileToLoadConfig	- ref to QFile
/// @param[in] persistedSave	- is this a persisted save?
///
/// @return T_CONFIG_RETURN_VALUE
///
//****************************************************************************
T_CONFIG_RETURN_VALUE CLayoutConfiguration::SaveConfig(QFile &fileToSaveConfig, const TV_BOOL persistedSave) {
	CONFIGHEADERINFO configFileHeader;
	// Construct the Configuration File Header
	swprintf(configFileHeader.szFileName, L"%s", fileToSaveConfig.GetFileName());
	QTime ourTime;
	ourTime.TimeNow();
	configFileHeader.dtCreationDateTime = ourTime.GetMicroSecs();
	configFileHeader.szPassword[0] = L'\0';
	configFileHeader.wEncryption = 0;
	configFileHeader.wFileType = CONFIG_LAYOUT_FILE_TYPE;
	configFileHeader.dwSource = 0;
	configFileHeader.dwAction = 1;
	T_CONFIG_RETURN_VALUE retval = SaveConfigFile(fileToSaveConfig, configFileHeader);
	if (retval == CONFIG_OK) {
#ifdef DOCVIEW
		// here do bitmap stuff for screen designer
		if(!iscntrl(fileToSaveConfig.GetFileName().at(0))) // check it's not a control char (i.e. CMEMFILE!!!)
			SaveScreenDesignerDibs((WCHAR*)fileToSaveConfig.GetFilePath().GetString());
#else
		// do bitmap stuff for recorder
		// here we are saving the layout config
		if (persistedSave)
			qDebug("~=~=~=~=~= PERSISTED SAVE =~=~=~=~=~\n");
		else {
			qDebug("~=~=~=~=~= NON-PERSISTED SAVE =~=~=~=~=~\n");
			// see if there is a 'DefaultLayoutConfig.bcf' that needs to be saved with the layout
			// form filename of the config bcf file
			WCHAR BCFname[MAX_PATH];
			CBitmapCollectionFile::BuildFilename(BCFname);
			// does the file exists
			CStorage bcfFile;
			if (bcfFile.exists(BCFname)) {
				// yes, so copy it with the layout - renamed to match.
				WCHAR bcf_filename[MAX_PATH];
				wcscpy_s(bcf_filename, MAX_PATH, fileToSaveConfig.GetFilePath());
				MakeDotBCF(bcf_filename); // change the extension to .bcf
				// copy the file to the destination with the layout
				QFile::copy(BCFname,bcf_filename); // and overwrite if exists
			}
		}
#endif
	}
	return retval;
}
//****************************************************************************
///
/// Save bitmapObject's bitmaps from screen designer library to the layout's bcf
///
/// @param[in] pFilePath	- filename and path of layout file 
///
/// @return T/F
///
//****************************************************************************
#ifdef DOCVIEW
BOOL CLayoutConfiguration::SaveScreenDesignerDibs(QString pFilePath)
{
	BOOL found=FALSE; // none found so far

	// form filename of layouts bcf file
	WCHAR bcf_filename[MAX_PATH];
	wcscpy(bcf_filename,pFilePath);
	MakeDotBCF(bcf_filename); // change the extension to .bcf
	// if the file exists, delete it - the complete contents will be reformed below.
	CStorage temp;
	if(temp.exists(bcf_filename))
		temp.remove(bcf_filename);
		
	// get Screen designers library collection of Dibs
	WCHAR SDfilename[MAX_PATH];
	CBitmapCollectionFile::BuildFilename(SDfilename);
	CBitmapCollectionFile SDlib(SDfilename,CBitmapCollectionFile::ReadOnly);

	// start at the top of the layout - find all bitmap objects and check the Dibs
	T_LAYOUTITEM layoutRef={BLK_LAYOUT,DEFAULT_LAYOUT_INST}; 
	BLOCK_INFO layblockInfo;
	if(indexOfDataBlock(&layoutRef, &layblockInfo))
	{
		T_LAYOUT *pLayout=(T_LAYOUT*)layblockInfo.pByBlock;		
		for(int tplt=0; tplt<pLayout->NumTemplates; tplt++)
		{
			BLOCK_INFO tpltblockInfo;
			if(indexOfDataBlock(&pLayout->TemplateList[tplt], &tpltblockInfo))
			{
				T_SCRTEMPLATE *pTemplate=(T_SCRTEMPLATE*)tpltblockInfo.pByBlock;
				for(int wgt=0; wgt<pTemplate->NumWidgets; wgt++)
				{
					BLOCK_INFO wgtblockInfo;
					if(indexOfDataBlock(&pTemplate->WidgetList[wgt], &wgtblockInfo))
					{
						T_WIDGET *pWidget=(T_WIDGET*)wgtblockInfo.pByBlock;
						for(int obj=0; obj<pWidget->NumObjects; obj++)
						{
							BLOCK_INFO objblockInfo;
							if(indexOfDataBlock(&pWidget->ObjectList[obj], &objblockInfo))
							{
								T_BASEOBJECT *pObject=(T_BASEOBJECT*)objblockInfo.pByBlock;
								if(pObject->ObjectType==BitmapObject)
								{
									
									T_BITMAPOBJECT *pcmmdib=(T_BITMAPOBJECT*)pObject;
									if(pcmmdib->UniqueID)
									{
										// has an ID so should have a dib to go with it.
										CDib* pDib=SDlib.LoadDib(pcmmdib->UniqueID); // load the Dib from the Screen designer bcf library
										if(pDib)
										{
											
											found=TRUE; // got at least one.
											// get the actual size of the bitmap - gets saved in the size it is used at -> smaller file
											QRect clientRect=*(QRect*)&pcmmdib->Base.Bounds;
											if(pcmmdib->Base.Border.BorderUsed)
												InflateRect(&clientRect,-pcmmdib->Base.Border.BorderWidth,-pcmmdib->Base.Border.BorderWidth);
											
											
											// now add it to the layouts bcf file - but only if it is not already present (or bigger)
											CBitmapCollectionFile bcf(bcf_filename,CBitmapCollectionFile::ReadOnlyWrite);
											bcf.AddToCollection(&pDib,(T_DEV_TYPE)pLayout->RecorderType,_Width(clientRect),_Height(clientRect));
											delete pDib;
										}
										else
											pcmmdib->UniqueID=0; // not found, so fix bitmapObject
									}						
								}
							}
						}
					}
				}
			}
		}
	}
	return found; // if there are any dibs.
}
#endif
T_CONFIG_RETURN_VALUE CLayoutConfiguration::UpdateConfig(void) {
	return (CommitConfig());
}
void CLayoutConfiguration::SetConfigurationId(const DWORD configurationId) {
	SetConfigId(configurationId);
}
void CLayoutConfiguration::CopyObject(CDataItem &ar, BLOCK_INFO *blockInfo) {
	switch (blockInfo->wBlockType) {
	case BLK_TEXTOBJECT: {
		T_TEXTOBJECT *pObj = (T_TEXTOBJECT*) blockInfo->pByBlock;
		if (pObj->Offset > 0) // copy user-defined text from CMM text block
				{
			QString pwch = GetTextString(pObj->Offset);
			int nNumBytes = (int) ((wcslen(pwch) + 1) * sizeof(WCHAR)); // include null terminator
			ar << (WORD) nNumBytes;
			ar.Write(pwch, nNumBytes);
		}
		break;
	} // end, case BLK_TEXTOBJECT
	}
}
void CLayoutConfiguration::CopySelection(CSelectionList &SelectionList, CDataItem &ar, BOOL bUseClipboard/*=FALSE*/) {
	m_bCopySingleSel = SelectionList.size() == 1;
	m_pCopyLayout = this;
	// Serialize all the selected layout items to the archive. Store the
	// largest CMM block size of all selected items. This will be used to
	// allocate a buffer on the load side. A widget's CMM block is stored
	// before all of its objects' CMM blocks. The order of data on the
	// clipboard is as follows:
	// DWORD dwMaxSize			 - Size in bytes of the largest CMM block
	//							  on the clipboard. Used to allocate a
	//							  minimally sized buffer on the load side.
	// WORD wNumBlocks			 - The number of CMM blocks which follow.
	//							  Each CMM block is written as follows:
	// WORD wBlockType			 - T_BLOCKTYPE of this CMM block.
	//	WORD wInstanceID		 - Instance ID of this CMM block. This ID
	//							  along with the block type above can be
	//							  used as a key in a map (T_LAYOUTITEM)
	//							  to build the linked objects in a pasted
	//							  widget. The value associated with each
	//							  key in the map is its new T_LAYOUTITEM.
	// DWORD dwBlockSize		 - The size in bytes of the data which follows
	//							  for this CMM block.
	// BYTE byData[dwBlockSize] - The data for this CMM block.
	// WORD wFixTextSize		 - If wBlockType is BLK_TEXTOBJECT and FixText
	//							  is TRUE for the text object, then this
	//							  entry is present and specifies the size in
	//							  bytes of user-defined text for the text object
	//							  (includes the null terminator).
	// BYTE byFixText[wFixTextSize] - If wBlockType is BLK_TEXTOBJECT and FixText
	//							  is TRUE for the text object, then this
	//							  entry is present and specifies the user-defined
	//							  text for the text object (includes the null
	//							  terminator).
	// WORD wNumWidgets		 - If wBlockType is BLK_SCRTEMPLATE, then this
	//							  entry is present and specifies the number
	//							  of widget CMM blocks which follow for this
	//							  template. Each widget CMM block is followed
	//							  by the CMM blocks for its objects.
	// WORD wNumObjects		 - If wBlockType is BLK_WIDGET, then this
	//							  entry is present and specifies the number
	//							  of object CMM blocks which follow for
	//							  this widget.
	WORD wNumBlocks = 0; // number of CMM blocks to be written
	// Store the size of the largest CMM block.
	DWORD dwMaxSize = 0;
	POSITION pos = SelectionList.GetHeadPosition();
	while (pos) {
		T_LAYOUTITEM Item = SelectionList.GetNext(pos);
		// Check the size of this layout item first. This
		// can be an object, widget, template, or screen.
		BLOCK_INFO blockInfo;
		indexOfDataBlock(&Item, &blockInfo);
		if (blockInfo.dwBlockSize > dwMaxSize)
			dwMaxSize = blockInfo.dwBlockSize;
		// Dive into aggregrate layout items next (not objects or screens).
		switch (Item.CMM_Type) {
		case BLK_WIDGET: {
			// Check the sizes of the widget's objects.
			T_WIDGET *pWgt = (T_WIDGET*) blockInfo.pByBlock;
			for (int nObject = 0; nObject < pWgt->NumObjects; nObject++) {
				BLOCK_INFO objectBlockInfo;
				indexOfDataBlock(&pWgt->ObjectList[nObject], &objectBlockInfo);
				if (objectBlockInfo.dwBlockSize > dwMaxSize)
					dwMaxSize = objectBlockInfo.dwBlockSize;
			}
			// Add widget's object count to our CMM block count.
			wNumBlocks += pWgt->NumObjects;
			break;
		}
		case BLK_SCRTEMPLATE: {
			// Check the sizes of the template's widgets and their objects.
			T_SCRTEMPLATE *pTplt = (T_SCRTEMPLATE*) blockInfo.pByBlock;
			for (int nWidget = 0; nWidget < pTplt->NumWidgets; nWidget++) {
				BLOCK_INFO widgetBlockInfo;
				indexOfDataBlock(&pTplt->WidgetList[nWidget], &widgetBlockInfo);
				if (widgetBlockInfo.dwBlockSize > dwMaxSize)
					dwMaxSize = widgetBlockInfo.dwBlockSize;
				T_WIDGET *pWgt = (T_WIDGET*) widgetBlockInfo.pByBlock;
				for (int nObject = 0; nObject < pWgt->NumObjects; nObject++) {
					BLOCK_INFO objectBlockInfo;
					indexOfDataBlock(&pWgt->ObjectList[nObject], &objectBlockInfo);
					if (objectBlockInfo.dwBlockSize > dwMaxSize)
						dwMaxSize = objectBlockInfo.dwBlockSize;
				}
				// Add widget and widget's object count to our CMM block count.
				wNumBlocks += pWgt->NumObjects + 1;
			}
			break;
		} // end, case BLK_SCRTEMPLATE
		} // end, switch(Item.CMM_Type)
	} // end, while(pos)
	// Store the maximum CMM block size.
	ar << (DWORD) dwMaxSize;
	// Store the number of CMM blocks which follow.
	ar << (WORD) (wNumBlocks += (WORD) SelectionList.size());
	// Loop to store the individual CMM blocks of the selected items.
	pos = SelectionList.GetHeadPosition();
	while (pos) {
		T_LAYOUTITEM Item = SelectionList.GetNext(pos);
		// Store the block type of the CMM block.
		ar << (WORD) Item.CMM_Type;
		// Store the instance ID of the CMM block.
		ar << (WORD) Item.CMM_Inst;
		// Store the block size and data for the item's CMM block.
		// This can be for an object, widget, template, or screen.
		BLOCK_INFO blockInfo;
		indexOfDataBlock(&Item, &blockInfo);
		ar << (DWORD) blockInfo.dwBlockSize;
		ar.Write(blockInfo.pByBlock, blockInfo.dwBlockSize);
		// Copy any extra data for the object, widget, template, or screen.
		switch (Item.CMM_Type) {
		case BLK_WIDGET: {
			// Store the number of object CMM blocks.
			T_WIDGET *pWgt = (T_WIDGET*) blockInfo.pByBlock;
			ar << (WORD) pWgt->NumObjects;
			// Store the object CMM blocks next.
			for (int nObject = 0; nObject < pWgt->NumObjects; nObject++) {
				BLOCK_INFO objectBlockInfo;
				indexOfDataBlock(&pWgt->ObjectList[nObject], &objectBlockInfo);
				// Store the block type of the CMM block.
				ar << (WORD) objectBlockInfo.wBlockType;
				// Store the instance ID of the CMM block.
				ar << (WORD) objectBlockInfo.wInstanceID;
				// Store the block size and data for the object's CMM block.
				ar << (DWORD) objectBlockInfo.dwBlockSize;
				ar.Write(objectBlockInfo.pByBlock, objectBlockInfo.dwBlockSize);
				// Store any extra data for the object.
				CopyObject(ar, &objectBlockInfo);
			}
			break;
		} // end, case BLK_WIDGET
		case BLK_SCRTEMPLATE: {
			// Store the number of widget CMM blocks.
			T_SCRTEMPLATE *pTplt = (T_SCRTEMPLATE*) blockInfo.pByBlock;
			ar << (WORD) pTplt->NumWidgets;
			// Store the widget CMM blocks next.
			for (int nWidget = 0; nWidget < pTplt->NumWidgets; nWidget++) {
				BLOCK_INFO widgetBlockInfo;
				indexOfDataBlock(&pTplt->WidgetList[nWidget], &widgetBlockInfo);
				// Store the block type of the CMM block.
				ar << (WORD) widgetBlockInfo.wBlockType;
				// Store the instance ID of the CMM block.
				ar << (WORD) widgetBlockInfo.wInstanceID;
				// Store the block size and data for the widget's CMM block.
				ar << (DWORD) widgetBlockInfo.dwBlockSize;
				ar.Write(widgetBlockInfo.pByBlock, widgetBlockInfo.dwBlockSize);
				// Store the number of object CMM blocks.
				T_WIDGET *pWgt = (T_WIDGET*) widgetBlockInfo.pByBlock;
				ar << (WORD) pWgt->NumObjects;
				// Store the object CMM blocks next.
				for (int nObject = 0; nObject < pWgt->NumObjects; nObject++) {
					BLOCK_INFO objectBlockInfo;
					indexOfDataBlock(&pWgt->ObjectList[nObject], &objectBlockInfo);
					// Store the block type of the CMM block.
					ar << (WORD) objectBlockInfo.wBlockType;
					// Store the instance ID of the CMM block.
					ar << (WORD) objectBlockInfo.wInstanceID;
					// Store the block size and data for the object's CMM block.
					ar << (DWORD) objectBlockInfo.dwBlockSize;
					ar.Write(objectBlockInfo.pByBlock, objectBlockInfo.dwBlockSize);
					// Store any extra data for the object.
					CopyObject(ar, &objectBlockInfo);
				}
			}
			break;
		} // end, case BLK_SCRTEMPLATE
		case BLK_SCREEN:
			break;
		default: // object
		{
			if (BlockTypeToObjectType((T_BLOCKTYPE) Item.CMM_Type) != NoObject) {
				// Store any extra data for the object.
				CopyObject(ar, &blockInfo);
			} else
				// trying to copy an item other than a template, screen, widget or object
				assert(0); // shouldn't happen!
			break;
		} // end, default
		} // end, switch(Item.CMM_Type)
	} // end, while(pos)
	if (bUseClipboard) {
		CMemFile *pFile = (CMemFile*) ar.GetFile();
		ar.Close(); // must flush data to file before can get file length
		quint64 ulFileLength = pFile->GetLength();
		OpenClipboard (AfxGetMainWnd() -> m_hWnd);EmptyClipboard
		;
		HGLOBAL hData = GlobalAlloc(GMEM_MOVEABLE, (SIZE_T) ulFileLength);
		LPVOID pData = GlobalLock(hData);
		memcpy(pData, pFile->Detach(), (size_t) ulFileLength);
		GlobalUnlock(hData);
		SetClipboardData(cfLayout, hData);
		CloseClipboard();
	}
}
void CLayoutConfiguration::PasteTemplate(CDataItem &ar, BYTE *pbyCMMblock, int &nBlocksRead, PEXTRAPASTEINFO pExtra,
		COpPanel *pkOpPanel) {
	// Read this template's block size and block data
	// as well as the number of widgets it contains.
	DWORD dwBlockSize;
	ar >> dwBlockSize;
	ar.Read(pbyCMMblock, dwBlockSize);
	WORD wNumWidgets;
	ar >> wNumWidgets;
	// Bump nBlocksRead for the template block. PasteWidget
	// will bump nBlocksRead for widget and object blocks.
	nBlocksRead++;
	// Create the template first and then add the widgets to it.
	BLOCK_INFO templateBlockInfo;
	if (AddTemplate(&templateBlockInfo) == CONFIG_OK)
		if (templateBlockInfo.dwBlockSize == dwBlockSize) {
			// Save T_LAYOUTITEM of template added (useful for single selection paste).
			m_LastPastedItemRef = BlockInfoToLayoutItem(&templateBlockInfo);
			// Save away the template number because we'll need to restore it
			// after we copy over the copied template attributes into CMM block.
			T_SCRTEMPLATE *pTplt = (T_SCRTEMPLATE*) templateBlockInfo.pByBlock;
			int nTemplateNum = pTplt->Number;
			// Copy over the copied template attributes into the CMM block.
			memcpy(templateBlockInfo.pByBlock, pbyCMMblock, dwBlockSize);
			// Clear out the template's WidgetList and number of widgets.
			// Fields will be updated as the widgets are created next.
			pTplt->Number = nTemplateNum; // restore template number
			memset(pTplt->WidgetList, 0, sizeof(pTplt->WidgetList));
			pTplt->NumWidgets = 0;
			for (int nWidget = 0; nWidget < wNumWidgets; nWidget++) {
				// Verify a widget follows.
				WORD wBlockType;
				ar >> wBlockType;
				WORD wInstanceID;
				ar >> wInstanceID;
				if (wBlockType == BLK_WIDGET) {
					PasteWidget(ar, pbyCMMblock, nBlocksRead, BlockInfoToLayoutItem(&templateBlockInfo),
					TRUE /* template paste */, pExtra, pkOpPanel);
				} else {
					assert(0); // not a widget! something's wrong!
					break;
				}
			} // end, for(int nWidget=0; nWidget<wNumWidgets; nWidget++)
		} // end, if(widgetBlockInfo.dwBlockSize==dwBlockSize)
		else
			assert(0); // shouldn't happen!
}
void CLayoutConfiguration::PasteScreen(CDataItem &ar, BYTE *pbyCMMblock, int &nBlocksRead, PEXTRAPASTEINFO pExtra,
		COpPanel *pkOpPanel) {
	// Read this screen's block size and block data.
	DWORD dwBlockSize;
	ar >> dwBlockSize;
	ar.Read(pbyCMMblock, dwBlockSize);
	T_SCREEN *pScr = (T_SCREEN*) pbyCMMblock;
	// Bump nBlocksRead for the screen block.
	nBlocksRead++;
	T_LAYOUTITEM templateRef; // template to use for this screen
	if (m_pCopyLayout == this || pScr->Type < TPL_LAST_CANNED) {
		// Pasting screen to same layout or standard screen - use same template.
		// Template for a standard screen is NULL; we use the Type field instead.
		templateRef = pScr->Template;
	} else // Pasting screen to different layout
	{
		BOOL bUseSourceTemplate = TRUE; // default if pExtra or pExtra->pGetPasteScreenOption NULL 
		T_LAYOUTITEM DestinationTemplateRef;
		if (pExtra && pExtra->pOpPanel && pExtra->pGetPasteScreenOption)
			pExtra->pGetPasteScreenOption(pExtra->pOpPanel, pScr->Name, bUseSourceTemplate, DestinationTemplateRef);
		if (bUseSourceTemplate) // copy source template across
		{
			templateRef = pScr->Template;
			CSelectionList SelectionList;
			SelectionList.prepend(templateRef);
			CMemFile file;
			CDataItem store(&file, CDataItem::store);
			m_pCopyLayout->CopySelection(SelectionList, store);
			store.Close();
			file.seek(0);
			CDataItem load(&file, CDataItem::load);
			PasteSelection(load, pExtra, pkOpPanel);
			templateRef = m_LastPastedItemRef;
		} else
			// use specified template in this layout
			templateRef = DestinationTemplateRef;
	}
	// Create the screen.
	BLOCK_INFO screenBlockInfo;
	if (AddScreen(IsNull(templateRef) ? NULL : &templateRef, &screenBlockInfo) == CONFIG_OK)
		if (screenBlockInfo.dwBlockSize == dwBlockSize) {
			// Save T_LAYOUTITEM of screen added (useful for single selection paste).
			m_LastPastedItemRef = BlockInfoToLayoutItem(&screenBlockInfo);
			// Save away the screen number because we'll need to restore it
			// after we copy over the copied screen attributes into CMM block.
			T_SCREEN *pScr = (T_SCREEN*) screenBlockInfo.pByBlock;
			int nScreenNum = pScr->Number;
			// Save away the screen type. If the screen type is custom, then
			// set it to the index of the template being used in this layout.
			// This index might be different than the index of the template
			// we're copying over if we're copying over a custom screen between
			// layouts and also copying over its template.
			int nType = pScr->Type;
			BOOL bCustomTypeSetup = nType == TPL_CUSTOM;
			if (bCustomTypeSetup) {
				// Note that we can't use GetTemplateIndex on COpPanel because
				// the template list in COpPanel hasn't been updated yet with
				// this template pasted for the custom screen. We'll search the
				// template list in the layout for the template we've pasted.
				T_LAYOUTITEM layoutItem;
				layoutItem.CMM_Type = BLK_LAYOUT;				// look for the Layout block
				layoutItem.CMM_Inst = DEFAULT_LAYOUT_INST;	// of the default instance
				BLOCK_INFO blockInfo;
				if (indexOfDataBlock(&layoutItem, &blockInfo)) {
					T_LAYOUT *pLayout = (T_LAYOUT*) blockInfo.pByBlock;
					// Search for the template ref. If we can't find it,
					// then variable nType will remain set to TPL_CUSTOM.
					for (int nIndex = 0; nIndex < pLayout->NumTemplates; nIndex++)
						if (IsEqual(pLayout->TemplateList[nIndex], templateRef)) {
							nType = nIndex + TPL_LAST_CANNED;
							break;
						}
					if (nType == TPL_CUSTOM)
						assert(0); // couldn't find template in list!
				}
			}
			// Copy over the copied screen attributes into the CMM block.
			memcpy(screenBlockInfo.pByBlock, pbyCMMblock, dwBlockSize);
			pScr->Number = nScreenNum;	// restore screen number
			pScr->Template = templateRef;	// use the template ref we've set up
			if (bCustomTypeSetup)
				pScr->Type = nType;		// use the type we've set up
		} // end, if(widgetBlockInfo.dwBlockSize==dwBlockSize)
		else
			assert(0); // shouldn't happen!
}
void CLayoutConfiguration::PasteWidget(CDataItem &ar, BYTE *pbyCMMblock, int &nBlocksRead, T_LAYOUTITEM templateRef,
		BOOL bTemplatePaste, PEXTRAPASTEINFO pExtra, COpPanel *pkOpPanel) {
	// If bTemplatePaste is TRUE, then this means we're pasting this widget
	// as part of a template paste (pasting an entire template), in which
	// case we preserve the position of the widget being pasted. Otherwise,
	// we're pasting an individual widget, in which case we 1) use the paste
	// caret to position the pasted widget, 2) constrain the widget to the
	// bounds of the screen, and 3) update the paste caret.
	// Read this widget's block size and block data
	// as well as the number of objects it contains.
	DWORD dwBlockSize;
	ar >> dwBlockSize;
	ar.Read(pbyCMMblock, dwBlockSize);
	WORD wNumObjects;
	ar >> wNumObjects;
	nBlocksRead += wNumObjects + 1; // add one for widget block
	if (!bTemplatePaste) {
		// We're pasting this widget to the active screen. Only pasted
		// widget will be selected, not the currently selected widget.
		if (pExtra && !IsNull(pExtra->SelectedWidgetRef)) {
			BLOCK_INFO widgetBlockInfo;
			if (indexOfDataBlock(&pExtra->SelectedWidgetRef, &widgetBlockInfo)) {
				T_WIDGET *pWgt = (T_WIDGET*) widgetBlockInfo.pByBlock;
				pWgt->IsSelected = FALSE;
			}
		}
	}
	// Create the widget first and then add the objects to it.
	BLOCK_INFO widgetBlockInfo;
	if (AddWidget(&templateRef, &widgetBlockInfo) == CONFIG_OK) {
		if (widgetBlockInfo.dwBlockSize == dwBlockSize) {
			USHORT usLastIndex = 0;
			CScreen *pkScreen = NULL;
			// Save T_LAYOUTITEM of widget added (useful for single selection paste).
			if (IsNull(m_LastPastedItemRef))
				m_LastPastedItemRef = BlockInfoToLayoutItem(&widgetBlockInfo);
			// Copy over the copied widget attributes into the CMM block.
			memcpy(widgetBlockInfo.pByBlock, pbyCMMblock, dwBlockSize);
			// Clear out the widget's ObjectList and number of objects.
			// Fields will be updated as the objects are created next.
			T_WIDGET *pWgt = (T_WIDGET*) widgetBlockInfo.pByBlock;
			if (pkOpPanel != NULL) {
				// update the widget channel references to unique ones
				pkScreen = pkOpPanel->m_pActiveScreen;
				if ((pkScreen != NULL)) {
					USHORT usWidgetChanNo = 0;
					while ((pWgt->ChannelList[usWidgetChanNo] != CWidget::ms_usCHANNEL_SPARE)
							&& (usWidgetChanNo < WIDGET_CHANNELLIST_SIZE)) {
						// replace the current screeen channel reference with a unique one
						usLastIndex = CWidget::GetFreeScreenInstIndex(pkScreen, CScreen::ms_usUNINITIALISED_INSTANCE,
								false, ++usLastIndex);
						// now add the offset
						pWgt->ChannelList[usWidgetChanNo] = usLastIndex + CWidget::ms_usCHANNEL_OFFSET;
						++usWidgetChanNo;
					}
				}
			}
			pWgt->IsSelected = !bTemplatePaste && pExtra && pExtra->bSelectAfterPaste;
			memset(pWgt->ObjectList, 0, sizeof(pWgt->ObjectList));
			pWgt->NumObjects = 0;
			// The following variables are needed to position the
			// pasted widget at its new location if this paste is
			// not part of a template paste. For a template paste,
			// we preserve the positions of the widgets.
			int nOffsetX;
			int nOffsetY;
			QRect rcWidgetOld;
			QRect rcWidgetNew;
			if (!bTemplatePaste && pExtra) // we're pasting to active screen
					{
				// Update the position of the pasted widget. Each object to
				// be pasted in the widget will also be offset by the same
				// amount, so remember these offsets for pasting the objects.
				nOffsetX = pExtra->ptPasteCaret.x - pWgt->Bounds.left;
				nOffsetY = pExtra->ptPasteCaret.y - pWgt->Bounds.top;
				OffsetRect((QRect*) &pWgt->Bounds, nOffsetX, nOffsetY);
				rcWidgetOld = (QRect*) &pWgt->Bounds;
				// Check if the right side or bottom of the widget is outside the screen
				// and if either is then move them in, preserving the size of the widget.
				// If the widget cannot fit inside screen, then we must reduce its size.
				QRect rcScreen(pExtra->rcActiveScreenClient);
				if (pWgt->Bounds.right > rcScreen.right)
					OffsetRect((QRect*) &pWgt->Bounds, rcScreen.right - pWgt->Bounds.right, 0);
				if (pWgt->Bounds.bottom > rcScreen.bottom)
					OffsetRect((QRect*) &pWgt->Bounds, 0, rcScreen.bottom - pWgt->Bounds.bottom);
				// Constrain the widget to be inside the bounds of the screen.
				// We will constrain the objects inside the widget to be inside
				// the bounds of the widget in the loop below.
				IntersectRect((QRect*) &pWgt->Bounds, (QRect*) &pWgt->Bounds, rcScreen);
				rcWidgetNew = (QRect*) &pWgt->Bounds;
			}
			// Now loop over the object CMM blocks to create the objects.
			CLayoutItemMap TranslationMap; // for LinkedObj chain
			for (int nObject = 0; nObject < wNumObjects; nObject++) {
				// Read this object's block type, instance
				// ID, its block size, and its block data.
				WORD wBlockType;
				ar >> wBlockType;
				WORD wInstanceID;
				ar >> wInstanceID;
				DWORD dwBlockSize;
				ar >> dwBlockSize;
				ar.Read(pbyCMMblock, dwBlockSize);
				// Create the object in the widget using the T_LAYOUTITEM of the widget just created.
				T_LAYOUTITEM widgetRef = { widgetBlockInfo.wBlockType, widgetBlockInfo.wInstanceID };
				BLOCK_INFO objectBlockInfo;
				if (AddObject(&widgetRef, (T_BLOCKTYPE) wBlockType, &objectBlockInfo) == CONFIG_OK)
					if (objectBlockInfo.dwBlockSize == dwBlockSize) {
						// Add object's copied T_LAYOUTITEM and its pasted T_LAYOUTITEM
						// to the map so that we can form the widget's LinkedObj chain.
						// We need to add all objects first then form the LinkedObj chain
						// because the LinkedObj chain can have forward references in it.
						T_LAYOUTITEM CopiedLayoutItem = { wBlockType, wInstanceID };
						T_LAYOUTITEM PastedLayoutItem = { objectBlockInfo.wBlockType, objectBlockInfo.wInstanceID };
						TranslationMap[*(UINT*) &CopiedLayoutItem] = *(UINT*) &PastedLayoutItem;
						// Copy over the copied object attributes into the CMM block.
						memcpy(objectBlockInfo.pByBlock, pbyCMMblock, dwBlockSize);
						// check if any of the objects are referencing screen instances directly
						USHORT usNumChannels = 0;
						T_PCHANNELREF ptObjChanRef = CWidget::GetObjChanRef(
								reinterpret_cast<T_PBASEOBJECT>(objectBlockInfo.pByBlock), usNumChannels);
						if ((ptObjChanRef != NULL) && (ptObjChanRef->IndexChan >= CWidget::ms_usCHANNEL_OFFSET)) {
							if ((pkScreen != NULL)) {
								usLastIndex = CWidget::GetFreeScreenInstIndex(pkScreen,
										CScreen::ms_usUNINITIALISED_INSTANCE, false, ++usLastIndex);
								ptObjChanRef->IndexChan = usLastIndex + CWidget::ms_usCHANNEL_OFFSET;
								//Coverity issue fix --infinite loop
								for (USHORT usObjChanCount = 1; usObjChanCount < usNumChannels; usObjChanCount++) {
									ptObjChanRef[usObjChanCount].IndexChan = ptObjChanRef[0].IndexChan;
								}
							}
						}
						// Perform any special paste processing needed. An example is
						// that a pasted text object having user-defined text needs to
						// have its own copy of this user-defined text and not share
						// with the copied text object the same offset into the Variable
						// length text block in the CMM.
						PerformSpecialPasteProcessing(ar, &objectBlockInfo);
						if (!bTemplatePaste) // we're pasting to active screen
						{
							// Update the position of the pasted object based on its original offset and the difference between its shifted widget.
							T_BASEOBJECT *pObj = (T_BASEOBJECT*) objectBlockInfo.pByBlock;
							OffsetRect((QRect*) &pObj->Bounds, nOffsetX + rcWidgetNew.left - rcWidgetOld.left,
									nOffsetY + rcWidgetNew.top - rcWidgetOld.top);
							// Constrain the object to be inside the bounds of the widget.
							QRect rcObj((QRect*) &pObj->Bounds);
							if (!IntersectRect((QRect*) &pObj->Bounds, (QRect*) &pObj->Bounds,
									(QRect*) &pWgt->Bounds)) {
								// The intersection is empty. Force the object to be inside the bounds of the widget.
								// On the compass, the object can be N, NE, E, SE, S, SW, W, or NW of the widget.
								if (rcObj.right < pWgt->Bounds.left)
									// Object is left of widget. Align object's left edge with widget's left edge.
									rcObj.OffsetRect(pWgt->Bounds.left - rcObj.left, 0); // shift right (+) into widget
								else if (rcObj.left > pWgt->Bounds.right)
									// Object is right of widget. Align object's right edge with widget's right edge.
									rcObj.OffsetRect(pWgt->Bounds.right - rcObj.right, 0); // shift left (-) into widget
								if (rcObj.bottom < pWgt->Bounds.top)
									// Object is above widget. Align object's top edge with widget's top edge.
									rcObj.OffsetRect(0, pWgt->Bounds.top - rcObj.top); // shift down (+) into widget
								else if (rcObj.top > pWgt->Bounds.bottom)
									// Object is below widget. Align object's bottom edge with widget's bottom edge.
									rcObj.OffsetRect(0, pWgt->Bounds.bottom - rcObj.bottom); // shift up (-) into widget
								memcpy(&pObj->Bounds, &rcObj, sizeof(QRect));
							} // end, if(!IntersectRect((QRect*)&pObj->Bounds, (QRect*)&pObj->Bounds, (QRect*)&pWgt->Bounds))
						} // end, if(!bTemplatePaste) // we're pasting to active screen
					} // end, if(objectBlockInfo.dwBlockSize==dwBlockSize)
					else
						assert(0); // shouldn't happen!
			} // end, for(int nObject=0; nObject<wNumObjects; nObject++)
			// Loop over the pasted objects and update the widget's LinkedObj chain.
			// Loop over the map. For each value (NOT key) in the map, indexOfDataBlock
			// on it to get its CMM block. See what LinkedObj is in its CMM block.
			// Use the LinkedObj value as the key in the map to find out its new value.
			POSITION pos = TranslationMap.GetStartPosition();
			while (pos) {
				UINT uCopiedLayoutItem;
				UINT uPastedLayoutItem;
				TranslationMap.GetNextAssoc(pos, uCopiedLayoutItem, uPastedLayoutItem);
				BLOCK_INFO objectBlockInfo;
				if (indexOfDataBlock((T_LAYOUTITEM*) &uPastedLayoutItem, &objectBlockInfo)) {
					T_BASEOBJECT *pObj = (T_BASEOBJECT*) objectBlockInfo.pByBlock;
					if (pObj->LinkedObj.CMM_Type || pObj->LinkedObj.CMM_Inst) {
						TranslationMap.Lookup(*(UINT*) &pObj->LinkedObj, uPastedLayoutItem);
						pObj->LinkedObj = *(T_LAYOUTITEM*) &uPastedLayoutItem;
					}
				}
			}
			if (!bTemplatePaste && pExtra) // we're pasting to active screen
				pExtra->ptPasteCaret.Offset(20, 20);
		} // end, if(widgetBlockInfo.dwBlockSize==dwBlockSize)
		else
			assert(0); // shouldn't happen!
	}
}
void CLayoutConfiguration::PasteObject(CDataItem &ar, BYTE *pbyCMMblock, int &nBlocksRead, WORD wBlockType,
		PEXTRAPASTEINFO pExtra, COpPanel *pkOpPanel, USHORT &rusLastIndex) {
	// Read this object's block size and its block data.
	DWORD dwBlockSize;
	ar >> dwBlockSize;
	ar.Read(pbyCMMblock, dwBlockSize);
	nBlocksRead++;
	if (pExtra && !IsNull(pExtra->SelectedWidgetRef)) {
		BLOCK_INFO widgetBlockInfo;
		if (indexOfDataBlock(&pExtra->SelectedWidgetRef, &widgetBlockInfo)) {
			T_WIDGET *pWgt = (T_WIDGET*) widgetBlockInfo.pByBlock;
			// Only the pasted object will be selected, not the currently selected object.
			if (!IsNull(pExtra->SelectedObjectRef)) {
				BLOCK_INFO objectBlockInfo;
				if (indexOfDataBlock(&pExtra->SelectedObjectRef, &objectBlockInfo)) {
					T_BASEOBJECT *pObj = (T_BASEOBJECT*) objectBlockInfo.pByBlock;
					pObj->IsSelected = FALSE;
				}
			}
			// Need to set widget selected in CMM so can perform multiple pastes
			// after a copy. Selected widget determines what widget to paste to.
			// DKF: This is NOT necessary anymore. Just the opposite is required.
			// The widget needs to be NOT selected, otherwise multiple pastes after
			// a single object copy results in ALL of the pasted objects being
			// selected (their handles shown). When the widget is set NOT selected,
			// only the last object pasted is selected.
			pWgt->IsSelected = FALSE;
			BLOCK_INFO objectBlockInfo;
			if (AddObject(&pExtra->SelectedWidgetRef, (T_BLOCKTYPE) wBlockType, &objectBlockInfo) == CONFIG_OK)
				if (objectBlockInfo.dwBlockSize == dwBlockSize) {
					// Save T_LAYOUTITEM of object added (useful for single selection paste).
					if (IsNull(m_LastPastedItemRef))
						m_LastPastedItemRef = BlockInfoToLayoutItem(&objectBlockInfo);
					// Copy over the copied object attributes into the CMM block.
					memcpy(objectBlockInfo.pByBlock, pbyCMMblock, dwBlockSize);
					// Perform any special paste processing needed. An example is
					// that a pasted text object having user-defined text needs to
					// have its own copy of this user-defined text and not share
					// with the copied text object the same offset into the Variable
					// length text block in the CMM.
					UpdatePasteObjChanList(pkOpPanel, pWgt, reinterpret_cast<T_PBASEOBJECT>(objectBlockInfo.pByBlock),
							rusLastIndex);
					PerformSpecialPasteProcessing(ar, &objectBlockInfo);
					T_BASEOBJECT *pObj = (T_BASEOBJECT*) objectBlockInfo.pByBlock;
					pObj->IsSelected = pExtra->bSelectAfterPaste;
					SetNull(pObj->LinkedObj);
					// Update the position of the pasted object.
					OffsetRect((QRect*) &pObj->Bounds, pExtra->ptPasteCaret.x - pObj->Bounds.left,
							pExtra->ptPasteCaret.y - pObj->Bounds.top);
					// Check if the right side or bottom of the object is outside the widget
					// and if either is then move them in, preserving the size of the widget.
					// If the object cannot fit inside widget, then we must reduce its size.
					QRect rcWidget(pExtra->rcSelectedWidgetClient);
					if (pObj->Bounds.right > rcWidget.right)
						OffsetRect((QRect*) &pObj->Bounds, rcWidget.right - pObj->Bounds.right, 0);
					if (pObj->Bounds.bottom > rcWidget.bottom)
						OffsetRect((QRect*) &pObj->Bounds, 0, rcWidget.bottom - pObj->Bounds.bottom);
					// Constrain the object to be inside the bounds of the widget.
					IntersectRect((QRect*) &pObj->Bounds, (QRect*) &pObj->Bounds, rcWidget);
					pExtra->ptPasteCaret.Offset(20, 20);
				} // end, if(objectBlockInfo.dwBlockSize==dwBlockSize)
				else
					assert(0); // shouldn't happen!
		}
	} // end, if(pExtra && !IsNull(pExtra->SelectedWidgetRef))
}
//****************************************************************************
// void UpdatePasteObjChanList(	COpPanel *pkOpPanel,
//									T_PWIDGET ptWidget,
//									T_PBASEOBJECT ptBaseObject,
//									USHORT &rusLastIndex 
///
/// Method that updates a pasted pbjects channel list information
///
/// @param[in]			COpPanel *pkOpPanel - Pointer to the destination Op Panel
/// @param[in]			T_PWIDGET ptWidget - Pointer to the destination widget CMM object
/// @param[in]			T_PBASEOBJECT *ptBaseObject - Pointer to the new pasted CMM base object
/// @param[in/out]		USHORT &rusLastIndex - Varaible indicating the last used screen index
///
//****************************************************************************
void CLayoutConfiguration::UpdatePasteObjChanList(COpPanel *pkOpPanel, T_PWIDGET ptWidget, T_PBASEOBJECT ptBaseObject,
		USHORT &rusLastIndex) {
	// check if the object is referencing a screen instance directly
	if (pkOpPanel->m_pActiveScreen) {
		USHORT usNumChannels = 0;
		T_PCHANNELREF ptObjChanRef = CWidget::GetObjChanRef(ptBaseObject, usNumChannels);
		if ((ptObjChanRef != NULL) && (ptObjChanRef->IndexChan >= CWidget::ms_usCHANNEL_OFFSET)) {
			CScreen *pkScreen = pkOpPanel->m_pActiveScreen;
			if ((pkScreen != NULL)) {
				rusLastIndex = CWidget::GetFreeScreenInstIndex(pkScreen, CScreen::ms_usUNINITIALISED_INSTANCE, false,
						++rusLastIndex);
				ptObjChanRef->IndexChan = rusLastIndex + CWidget::ms_usCHANNEL_OFFSET;
				//Coverity issue fix --infinite loop
				for (USHORT usObjChanCount = 1; usObjChanCount < usNumChannels; usObjChanCount++) {
					ptObjChanRef[usObjChanCount].IndexChan = ptObjChanRef[0].IndexChan;
				}
			}
		} else if (ptObjChanRef != NULL) {
			CScreen *pkScreen = pkOpPanel->m_pActiveScreen;
			// check this widget has a channel configured
			if (ptWidget->ChannelList[ptObjChanRef->IndexChan] == CWidget::ms_usCHANNEL_SPARE) {
				ptObjChanRef->IndexChan = ptWidget->NumChannels;
				//Coverity issue fix --infinite loop
				for (USHORT usObjChanCount = 1; usObjChanCount < usNumChannels; usObjChanCount++) {
					ptObjChanRef[usObjChanCount].IndexChan = ptObjChanRef[0].IndexChan;
				}
				// the channel is not configured so we must create one in the earliest available
				// slot
				rusLastIndex = CWidget::GetFreeScreenInstIndex(pkScreen, CScreen::ms_usUNINITIALISED_INSTANCE, false,
						++rusLastIndex);
				ptWidget->ChannelList[ptWidget->NumChannels] = rusLastIndex + CWidget::ms_usCHANNEL_OFFSET;
				++ptWidget->NumChannels;
			}
		} else if (ptObjChanRef == NULL) {
			CScreen *pkScreen = pkOpPanel->m_pActiveScreen;
			// must be a pen pointers object - ensure we have at least 32 channels
			while (ptWidget->NumChannels < MAX_CHART_PENS) {
				rusLastIndex = CWidget::GetFreeScreenInstIndex(pkScreen, CScreen::ms_usUNINITIALISED_INSTANCE, false,
						++rusLastIndex);
				ptWidget->ChannelList[ptWidget->NumChannels] = rusLastIndex + CWidget::ms_usCHANNEL_OFFSET;
				++ptWidget->NumChannels;
			}
		}
	}
}
void CLayoutConfiguration::PasteSelection(CDataItem &ar, PEXTRAPASTEINFO pExtra/*=NULL*/, COpPanel *pkOpPanel) {
	m_PasteDesc = PASTE_NULL;		 // init to latch m_PasteDesc
	SetNull(m_LastPastedItemRef); // init to latch m_LastPastedItemRef
	// Allocate a buffer to store the largest CMM block size to be read in.
	DWORD dwMaxSize;
	ar >> dwMaxSize;
	BYTE *pbyCMMblock = new BYTE[dwMaxSize];
	// Read the number of CMM blocks.
	WORD wNumBlocks;
	ar >> wNumBlocks;
	// Loop to read in the CMM blocks. We can't have a simple for-
	// loop because we can read multiple blocks during one iteration
	// as is the case for reading the object CMM blocks of a widget.
	USHORT usLastIndex = 0;
	int nBlocksRead = 0;
	while (nBlocksRead < wNumBlocks) {
		// Read the block type.
		WORD wBlockType;
		ar >> wBlockType;
		// Read the instance ID.
		WORD wInstanceID;
		ar >> wInstanceID;
		switch (wBlockType) {
		case BLK_SCRTEMPLATE: {
			PasteTemplate(ar, pbyCMMblock, nBlocksRead, pExtra, pkOpPanel);
			m_PasteDesc = m_PasteDesc == PASTE_NULL ? PASTE_TEMPLATE : PASTE_SELECTION;
			if (pExtra)
				pExtra->TemplatesPasted.Add(m_LastPastedItemRef);
			break;
		}
		case BLK_SCREEN: {
			PasteScreen(ar, pbyCMMblock, nBlocksRead, pExtra, pkOpPanel);
			m_PasteDesc = m_PasteDesc == PASTE_NULL ? PASTE_SCREEN : PASTE_SELECTION;
			if (pExtra)
				pExtra->ScreensPasted.Add(m_LastPastedItemRef);
			break;
		}
		case BLK_WIDGET: {
			if (pExtra) {
				T_LAYOUTITEM templateRef = pExtra->ActiveScreenRef;
				if (templateRef.CMM_Type != BLK_SCRTEMPLATE) {
					BLOCK_INFO blockInfo;
					indexOfDataBlock(&templateRef, &blockInfo);
					T_SCREEN *pScr = (T_SCREEN*) blockInfo.pByBlock;
					templateRef = pScr->Template;
				}
				PasteWidget(ar, pbyCMMblock, nBlocksRead, templateRef,
				FALSE /* NOT template paste */, pExtra, pkOpPanel);
				m_PasteDesc = m_PasteDesc == PASTE_NULL ? PASTE_WIDGET : PASTE_SELECTION;
			}
			break;
		}
		default: // object
		{
			if (BlockTypeToObjectType((T_BLOCKTYPE) wBlockType) != NoObject) {
				PasteObject(ar, pbyCMMblock, nBlocksRead, wBlockType, pExtra, pkOpPanel, usLastIndex);
				m_PasteDesc = m_PasteDesc == PASTE_NULL ? PASTE_OBJECT : PASTE_SELECTION;
			} else
				// trying to paste an item other than a template, screen, widget or object
				assert(0); // shouldn't happen!
			break;
		}
		} // end, switch(wBlockType)
	} // end, while(nBlocksRead<wNumBlocks)
	CommitConfig();
	ValidateConfiguration();
	CommitConfig();
	delete pbyCMMblock;
}
//****************************************************************************
/// 
/// Perform any special paste processing needed. An example is that a pasted
/// text object having user-defined text needs to have its own copy of this
/// user-defined text and not share with the copied text object the same offset
/// into the Variable length text block in the CMM.
///
///	@param[in] ar - Archive containing copied information for layout item
/// being pasted. The archive is positioned at the extra data for the
/// item being pasted (e.g., at the user-defined text for a text object).
///	@param[in] blockInfo - Pointer to layout item block info being pasted
///
//****************************************************************************
void CLayoutConfiguration::PerformSpecialPasteProcessing(CDataItem &ar, BLOCK_INFO *blockInfo) {
	switch (blockInfo->wBlockType) {
	case BLK_TEXTOBJECT: {
		T_TEXTOBJECT *pTextObj = (T_TEXTOBJECT*) blockInfo->pByBlock;
		if (pTextObj->Offset > 0) // create own copy of user-defined text in CMM text block
				{
#define MAX_LENGTH 1024
			WCHAR TextStr[MAX_LENGTH];
			WORD wFixTextSize;
			ar >> wFixTextSize;
			ar.Read(TextStr, wFixTextSize);
			pTextObj->Offset = 0; // force new string to be allocated
			SetTextString(TextStr, &pTextObj->Offset);
		}
	}
		break;
	default:
		break;
	}
}
//****************************************************************************
/// 
/// Inserts the template residing in a template file into the layout.
///
///	@param[in] fileToLoadConfig - Template file to read
///
/// @return TRUE if inserted OK, FALSE if error
///
//****************************************************************************
BOOL CLayoutConfiguration::InsertTemplateFromFile(CStorage &fileToLoadConfig, PEXTRAPASTEINFO pExtra/*=NULL*/) {
	BOOL bRet = FALSE; // assume failure
	// Load file into a local layout and then copy
	// template from it and paste into this layout.
	CLayoutConfiguration lc;
	if (lc.CreateCMMHolder(1) == CONFIG_CMM_HOLDER_CREATED) {
		T_CONFIG_RETURN_VALUE tRetVal = lc.LoadConfig(fileToLoadConfig);
		if ((tRetVal == CONFIG_OK_VALIDATE_UPDATED_CMM) || (tRetVal == CONFIG_OK)) {
			T_CONFIG_VALIDATE_RETURN tValidateRetVal = lc.ValidateConfiguration();
			if (tValidateRetVal == CONFIG_VALIDATE_CHANGES_MADE) // i.e. not invalid
					{
				// Commit configuration to CMM Current
				lc.CommitConfig();
				T_LAYOUTITEM layoutItem;
				layoutItem.CMM_Type = BLK_LAYOUT;				// look for the Layout block
				layoutItem.CMM_Inst = DEFAULT_LAYOUT_INST;	// of the default instance
				BLOCK_INFO blockInfo;
				if (lc.indexOfDataBlock(&layoutItem, &blockInfo)) {
					T_LAYOUT *pLayout = (T_LAYOUT*) blockInfo.pByBlock;
					if (pLayout->NumTemplates > 0) {
						CSelectionList SelectionList;
						SelectionList.prepend(pLayout->TemplateList[0]);
						CMemFile file;
						CDataItem store(&file, CDataItem::store);
						lc.CopySelection(SelectionList, store);
						store.Close();
						file.seek(0);
						CDataItem load(&file, CDataItem::load);
						PasteSelection(load, pExtra);
						bRet = TRUE;
					}
				}
			}
		}
	}
	return bRet;
}
//****************************************************************************
/// 
/// Saves the specified template in the layout to a file.
///
///	@param[in] templateRef - Template in layout to save
///	@param[in] pConfigPathAndFileName - Template file to be created
///	@param[in] bIsValid - Is template valid? (e.g., no widgets offscreen)
///
/// @return TRUE if saved OK, FALSE if error
///
//****************************************************************************
BOOL CLayoutConfiguration::SaveTemplate(T_LAYOUTITEM *templateRef, const QString pConfigPathAndFileName,
		BOOL bIsValid/*=FALSE*/) {
	BOOL bRet = FALSE; // assume failure
	// Copy the template in this layout and paste it
	// to a local layout and then save local layout.
	CLayoutConfiguration lc;
	//if(lc.CreateCMMHolder(1)==CONFIG_CMM_HOLDER_CREATED)
	if (lc.CreateEmptyConfig() == CONFIG_OK) {
		CSelectionList SelectionList;
		SelectionList.prepend(*templateRef);
		CMemFile file;
		CDataItem store(&file, CDataItem::store);
		CopySelection(SelectionList, store);
		store.Close();
		file.seek(0);
		CDataItem load(&file, CDataItem::load);
		lc.PasteSelection(load);
		// We're going to save the layout, so set RecorderType, IsValid fields.
		T_LAYOUTITEM layoutItem;
		layoutItem.CMM_Type = BLK_LAYOUT;				// look for the Layout block
		layoutItem.CMM_Inst = DEFAULT_LAYOUT_INST;	// of the default instance
		BLOCK_INFO blockInfo;
		if (lc.indexOfDataBlock(&layoutItem, &blockInfo)) {
			T_LAYOUT *pLyt = (T_LAYOUT*) blockInfo.pByBlock;
			pLyt->RecorderType = GetRecorderType();
			pLyt->IsValid = bIsValid;
		}
		lc.CommitConfig();
		lc.SaveConfigUsingFileName(pConfigPathAndFileName);
		bRet = TRUE;
	}
	return bRet;
}
//****************************************************************************
/// 
/// Checks if any part of the specified widget is off the screen, taking into
/// account whether the status bar is present on the screen. A widget cannot
/// overlap the status bar if the status bar is present on the screen.
///
///	@param[in] pTplt - Template widget is on
///	@param[in] pWgt - Widget to check
///
/// @return TRUE if widget is off screen, else FALSE
///
//****************************************************************************
BOOL CLayoutConfiguration::IsOffScreen(T_SCRTEMPLATE *pTplt, T_WIDGET *pWgt) {
	// The status bar for the mini is 32 pixels high, for the multi it is 48.
	int nTop = 0;
	T_DEV_TYPE device = GetRecorderType();
	if (pTplt->StatusBar) {
		if (device == DEV_ARISTOS_MULTIPLUS || device == DEV_SCR_MINITREND)
			nTop = MULTI_STATUS_BAR_HEIGHT;
		else if (device == DEV_PC_MULTI)
			nTop = MULTI_PC_STATUS_BAR_HEIGHT;
		else if (device == DEV_XS_MULTIPLUS)
			nTop = MULTI_XS_STATUS_BAR_HEIGHT;
		else if (device == DEV_ARISTOS_MINITREND)
			nTop = MINI_STATUS_BAR_HEIGHT;
		else if (device == DEV_PC_MINI)
			nTop = MINI_PC_STATUS_BAR_HEIGHT;
		else
			// XS QX and new EZ hace same Status bar height
			nTop = MINI_EZ_STATUS_BAR_HEIGHT;
	}
	//E519766
	if (device == DEV_ARISTOS_MULTIPLUS || device == DEV_SCR_MINITREND)
		return pWgt->Bounds.left < 0 || pWgt->Bounds.right > ARISTOS_MULTI_SX_X || pWgt->Bounds.top < nTop
				|| pWgt->Bounds.bottom > ARISTOS_MULTI_SX_Y;
	if (device == DEV_PC_MULTI)
		return pWgt->Bounds.left < 0 || pWgt->Bounds.right > ARISTOS_PC_MULTI_SX_X || pWgt->Bounds.top < nTop
				|| pWgt->Bounds.bottom > ARISTOS_PC_MULTI_SX_Y;
	if (device == DEV_XS_MULTIPLUS)
		return pWgt->Bounds.left < 0 || pWgt->Bounds.right > X_SERIES_MULTI_SX_X || pWgt->Bounds.top < nTop
				|| pWgt->Bounds.bottom > X_SERIES_MULTI_SX_Y;
	else if (device == DEV_ARISTOS_MINITREND)
		return pWgt->Bounds.left < 0 || pWgt->Bounds.right > ARISTOS_MINI_QX_X || pWgt->Bounds.top < nTop
				|| pWgt->Bounds.bottom > ARISTOS_MINI_QX_Y;
	else if (device == DEV_PC_MINI)
		return pWgt->Bounds.left < 0 || pWgt->Bounds.right > ARISTOS_PC_MINI_QX_X || pWgt->Bounds.top < nTop
				|| pWgt->Bounds.bottom > ARISTOS_PC_MINI_QX_Y;
	else
		// XS QX and new EZ hace same resolution
		return pWgt->Bounds.left < 0 || pWgt->Bounds.right > ARISTOS_MINI_EZ_X || pWgt->Bounds.top < nTop
				|| pWgt->Bounds.bottom > ARISTOS_MINI_EZ_Y;
}
//****************************************************************************
/// 
/// Checks if any part of the specified widget overlaps another widget
/// on the specified template. Only widgets 'beneath' this widget are
/// checked for overlap so that we don't show duplicates to the user.
/// That is, if widget A and widget B overlap each other, and widget A
/// is on top, then only widget A will be flagged as overlapping.
///
///	@param[in] pTplt - Template widget is on
///	@param[in] nWidgetListIndex - Index of widget in template's WidgetList
///	@param[in] pWgt - Widget to check
///
/// @return TRUE if widget overlaps another widget, else FALSE
///
//****************************************************************************
BOOL CLayoutConfiguration::IsOverlapping(T_SCRTEMPLATE *pTplt, int nWidgetListIndex, T_WIDGET *pWgt) {
	BOOL bIsOverlapping = FALSE; // assume no overlap
	// Test for overlap in reverse WidgetList order (top of Z order on down).
	// If widget A is on top of and overlaps completely widget B, we want to
	// flag widget A as the widget that overlaps another.
	for (int nWidget = nWidgetListIndex - 1; nWidget >= 0; nWidget--) {
		BLOCK_INFO widgetBlockInfo;
		if (indexOfDataBlock(&pTplt->WidgetList[nWidget], &widgetBlockInfo)) {
			T_WIDGET *pOtherWgt = (T_WIDGET*) widgetBlockInfo.pByBlock;
			if (pOtherWgt != pWgt) {
				QRect rcIntersect;
				if (IntersectRect(rcIntersect, (QRect*) &pOtherWgt->Bounds, (QRect*) &pWgt->Bounds)) {
					bIsOverlapping = TRUE;
					break;
				}
			}
		}
	}
	return bIsOverlapping;
}
//****************************************************************************
/// 
/// Identifies any problems with the layout or the specified layout item
/// within the layout that would prevent it from running on the recorder.
///
///	@param[out] ProblemArray - Problems found with layout or the specified
///				layout item within the layout
///	@param[in] pLayoutItemToCheck - if non-NULL, a specific layout item
///				to check (such as a template) in the layout, else the entire
///				layout is checked
///
/// @return TRUE if layout is valid to run on recorder, FALSE if problems
///
//****************************************************************************
BOOL CLayoutConfiguration::IsValidToRun(CProblemArray &ProblemArray, T_LAYOUTITEM *pLayoutItemToCheck/*=NULL*/) {
	PROBLEM Problem;
	T_LAYOUTITEM layoutItem;
	layoutItem.CMM_Type = BLK_LAYOUT;				// look for the Layout block
	layoutItem.CMM_Inst = DEFAULT_LAYOUT_INST;	// of the default instance
	BLOCK_INFO blockInfo;
	if (indexOfDataBlock(&layoutItem, &blockInfo)) {
		T_LAYOUT *pLyt = (T_LAYOUT*) blockInfo.pByBlock;
		for (int nTemplate = 0; nTemplate < pLyt->NumTemplates; nTemplate++)
			// Check this template if we're to check the entire layout (pLayoutItemToCheck is NULL) or pLayoutItemToCheck is non-NULL and matches this template.
			if (!pLayoutItemToCheck
					|| (pLayoutItemToCheck->CMM_Type == BLK_SCRTEMPLATE
							&& pLayoutItemToCheck->CMM_Inst == pLyt->TemplateList[nTemplate].CMM_Inst)) {
				BLOCK_INFO templateBlockInfo;
				if (indexOfDataBlock(&pLyt->TemplateList[nTemplate], &templateBlockInfo)) {
					T_SCRTEMPLATE *pTplt = (T_SCRTEMPLATE*) templateBlockInfo.pByBlock;
					// Test if any widget is off screen or overlaps another widget on template.
					// Test for overlap in reverse WidgetList order (top of Z order on down).
					// If widget A is on top of and overlaps completely widget B, we want to
					// flag widget A as the widget that overlaps another.
					for (int nWidget = pTplt->NumWidgets - 1; nWidget >= 0; nWidget--) {
						BLOCK_INFO widgetBlockInfo;
						if (indexOfDataBlock(&pTplt->WidgetList[nWidget], &widgetBlockInfo)) {
							T_WIDGET *pWgt = (T_WIDGET*) widgetBlockInfo.pByBlock;
							if (IsOffScreen(pTplt, pWgt)) {
								Problem.Template = pLyt->TemplateList[nTemplate];
								Problem.LayoutItem = pTplt->WidgetList[nWidget];
								Problem.Problem = PROBLEM_WIDGET_OFFSCREEN;
								ProblemArray.Add(Problem);
							}
							if (IsOverlapping(pTplt, nWidget, pWgt)) {
								Problem.Template = pLyt->TemplateList[nTemplate];
								Problem.LayoutItem = pTplt->WidgetList[nWidget];
								Problem.Problem = PROBLEM_WIDGET_OVERLAPS;
								ProblemArray.Add(Problem);
							}
						} // end, if(indexOfDataBlock(&pTplt->WidgetList[nWidget], &widgetBlockInfo))
					} // end, for(int nWidget=pTplt->NumWidgets-1; nWidget>=0; nWidget--)
				} // end, if(indexOfDataBlock(&pLyt->TemplateList[nTemplate], &templateBlockInfo))
			} // end, if(!pLayoutItemToCheck || (pLayoutItemToCheck->CMM_Type==BLK_SCRTEMPLATE && pLayoutItemToCheck->CMM_Inst==pLyt->TemplateList[nTemplate]))
	} // end, if(indexOfDataBlock(&layoutItem, &blockInfo))
	return ProblemArray.GetSize() == 0; // return TRUE if no problems
}
//****************************************************************************
/// 
/// Method that gets the relevant group number for the passed in screen
///
///	@param[out] const USHORT usSCREEN_NO - The screen no that we want the group number of
///
/// @return The group number or PEN_GROUP_NONE if its not a group screen
///
//****************************************************************************
const T_PEN_GROUPS CLayoutConfiguration::GetScreenGroupNo(const USHORT usSCREEN_NO) {
	T_PEN_GROUPS ePEN_GROUP = PEN_GROUP_NONE;
	T_LAYOUTITEM layoutItem;
	layoutItem.CMM_Type = BLK_LAYOUT;				// look for the Layout block
	layoutItem.CMM_Inst = DEFAULT_LAYOUT_INST;	// of the default instance
	BLOCK_INFO blockInfo;
	if (indexOfDataBlock(&layoutItem, &blockInfo)) {
		// found it ok, 
		T_LAYOUT *ptLayout = reinterpret_cast<T_LAYOUT*>(blockInfo.pByBlock);
		// go through the screens disabling them if they are not canned one
		for (int iScreenNo = 0; iScreenNo < ptLayout->NumScreens; iScreenNo++) {
			BLOCK_INFO tBlockInfo;
			if (indexOfDataBlock(&ptLayout->ScreenList[iScreenNo], &tBlockInfo)) {
				T_PSCREEN ptScreen = reinterpret_cast<T_PSCREEN>(tBlockInfo.pByBlock);
				if (usSCREEN_NO == ptScreen->Number) {
					// check a pen group is configured
					if (ptScreen->UseGroups) {
						ePEN_GROUP = static_cast<T_PEN_GROUPS>(ptScreen->GroupIndex + 1);
					} else {
						ePEN_GROUP = PEN_GROUP_NONE;
					}
					// Break from the loop
					break;
				}
			}
		}
	}
	return ePEN_GROUP;
}
BOOL CLayoutConfiguration::DisableCustomScreensForXSeriesLayoutInGR(T_LAYOUT *ptLayout) {
	T_CONFIG_VALIDATE_RETURN eRetVal = CONFIG_VALIDATE_NO_CHANGES;
	BOOL correctTypeAndValid = TRUE;
	int nScreens = 0;
	// go through the screens disabling them if they are not canned one
	for (int iScreenNo = 0; iScreenNo < ptLayout->NumScreens; iScreenNo++) {
		BLOCK_INFO tBlockInfo;
		if (indexOfDataBlock(&ptLayout->ScreenList[iScreenNo], &tBlockInfo)) {
			T_PSCREEN ptScreen = reinterpret_cast<T_PSCREEN>(tBlockInfo.pByBlock);
			if ((ptScreen->Enabled == TRUE) && (ptScreen->Type >= TPL_LAST_CANNED) && (ptScreen->Type <= TPL_CUSTOM)) {
				// Make sure that u dont disable non process screen
				if (ptScreen->Type < TPL_ALARM || ptScreen->Type > TPL_NP_LAST) {
					// this is a custom screen, therefore disable it
					ptScreen->Enabled = FALSE;
					nScreens++;
					// if this is the first screen to be changed then log a diagnostic message
					if (eRetVal == CONFIG_VALIDATE_NO_CHANGES) {
						LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR,
								"Custom Screen option disabled for the X-Series layout- Custom screen(s) disabled");
						eRetVal = CONFIG_VALIDATE_CHANGES_MADE;
					}
				}
			}
		}
	}
	if (ptLayout->NumScreens == nScreens) {
		correctTypeAndValid = FALSE;
	}
	return correctTypeAndValid;
}
//****************************************************************************
/// 
/// Indicates the device is QVGA resolution (320*240)
///
/// @return true if the resolution is QVGA
///
//****************************************************************************
BOOL CLayoutConfiguration::IsQVGA() {
	T_DEV_TYPE eDeviceType = GetRecorderType();
	if ((eDeviceType == DEV_XS_MINITREND) || (eDeviceType == DEV_ARISTOS_EZTREND) || (eDeviceType == DEV_XS_EZTREND)
			|| (eDeviceType == DEV_PC_EZTREND)) {
		return TRUE;
	}
	return FALSE;
}
//****************************************************************************
/// 
/// Indicates the device is VGA resolution (640*480)
///
/// @return true if the resolution is VGA
///
//****************************************************************************
BOOL CLayoutConfiguration::IsVGA() {
	T_DEV_TYPE eDeviceType = GetRecorderType();
	if ((eDeviceType == DEV_ARISTOS_MINITREND) || (eDeviceType == DEV_PC_MINI)) {
		return TRUE;
	}
	return FALSE;
}
//****************************************************************************
/// 
/// Indicates the device is SVGA resolution (800*600)
///
/// @return true if the resolution is SVGA
///
//****************************************************************************
BOOL CLayoutConfiguration::IsSVGA() {
	T_DEV_TYPE eDeviceType = GetRecorderType();
	if (eDeviceType == DEV_XS_MULTIPLUS) {
		return TRUE;
	}
	return FALSE;
}
//****************************************************************************
/// 
/// Indicates the device is XVGA resolution (1024*768)
///
/// @return true if the resolution is XVGA
///
//****************************************************************************
BOOL CLayoutConfiguration::IsXVGA() {
	T_DEV_TYPE eDeviceType = GetRecorderType();
	if ((eDeviceType == DEV_ARISTOS_MULTIPLUS) || (eDeviceType == DEV_PC_MULTI) || (eDeviceType == DEV_SCR_MINITREND)) {
		return TRUE;
	}
	return FALSE;
}

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Configuration System
/// @n Filename:  CannedScrnData.h
/// @n Description: Definition for the CCannedScrnData class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  8 Stability Project 1.5.1.1 7/2/2011 4:55:53 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  7 Stability Project 1.5.1.0 7/1/2011 4:28:10 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  6 V6 Firmware 1.5 9/23/2008 3:09:20 PM  Build Machine 
//  AMS2750 Merge
//  5 V6 Firmware 1.4 3/9/2006 6:21:38 PM Roger Dawson  
//  Removed magic number for the number of canned pens available for each
//  template. Also fixed bug where minitrend was being configured like a
//  multitrend
// $
//
// **************************************************************************
#if !defined(AFX_CANNEDSCRNDATA_H__C0BD844F_8988_40C0_B881_801EEEED2B83__INCLUDED_)
#define AFX_CANNEDSCRNDATA_H__C0BD844F_8988_40C0_B881_801EEEED2B83__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "V6Config.h"
#include "ConfigData.h"
//**CCannedScrnData*********************************************************************
///
/// @brief Class containing information on canned screen setup data items
/// 
/// Class containing information on canned screen setup data items
///
//****************************************************************************
class CCannedScrnData: public CConfigData {
public:
	// Constructor
	CCannedScrnData(T_CANNEDPENS *pData, const T_CFG_DATA_TYPE eCFGDATA_TYPE, const T_TEMPLATE_TYPE eTEMPLATE_TYPE,
			const int iHELP_ID, const int iDESC_ID, const bool bUPDATE_TREE_ON_CHANGE);
	// Destructor
	~CCannedScrnData();
	// Method that returns a pointer to the data
	void* GetData() const {
		return m_pCannedScreenData;
	}
	// Method that returns the data as a string
	const QString GetDataAsString(const bool bDataForReplayMode = false);
	// Method that returns the template type
	const T_TEMPLATE_TYPE GetTemplateType() const {
		return m_eTEMPLATE_TYPE;
	}
	// Method that returns the maximum pen count based on the current screen template type
	static const USHORT GetMaxPenCount(const T_TEMPLATE_TYPE eTEMPLATE_TYPE);
	// E527303
	// Method that returns the maximum replay pen count based on the current recorder type
	static const USHORT GetMaxReplayPenCount();
	static const USHORT ms_usMAX_MINI_DPMS_PENS;
	static const USHORT ms_usMAX_MULTI_DPMS_PENS;
	static const USHORT ms_usMAX_MINI_DPMS_BARS;
	static const USHORT ms_usMAX_MULTI_DPMS_BARS;
	static const USHORT ms_usMAX_MINI_CHRT_DPMS;
	static const USHORT ms_usMAX_MULTI_CHRT_DPMS;
	static const USHORT ms_usMAX_CIRC_CHRT_DPMS;
	static const USHORT ms_usMAX_MINI_CHRT_BARS;
	static const USHORT ms_usMAX_MULTI_CHRT_BARS;
	static const USHORT ms_usMAX_MINI_CHRT_DPMS_BARS;
	static const USHORT ms_usMAX_MULTI_CHRT_DPMS_BARS;
	static const USHORT ms_usMAX_MINI_TABULAR_PENS;
	static const USHORT ms_usMAX_MULTI_TABULAR_PENS;
	// E527303[
	static const USHORT ms_usMAX_MINI_REPLAY_PENS;
	static const USHORT ms_usMAX_MULTI_REPLAY_PENS;
	//]
	static const USHORT ms_usMAX_MINI_NP_PENS;
	static const USHORT ms_usMAX_MULTI_NP_PENS;
	static const USHORT ms_usMAX_MINI_NP_USERVARIABLE_PENS;
	static const USHORT ms_usMAX_MULTI_NP_USERVARIABLE_PENS;
private:
	/// Pointer to the CMM canned screen setup data
	T_CANNEDPENS *m_pCannedScreenData;
	/// The type of canned screen e.g. charts and DPMS, DPMS and Bars etc
	const T_TEMPLATE_TYPE m_eTEMPLATE_TYPE;
};
#endif // !defined(AFX_CANNEDSCRNDATA_H__C0BD844F_8988_40C0_B881_801EEEED2B83__INCLUDED_)

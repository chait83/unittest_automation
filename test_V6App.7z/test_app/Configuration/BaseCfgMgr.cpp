/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Configuration System
/// @n Filename:  BaseCfgMgr.cpp
/// @n Description: Implementation for the CBaseCfgMgr class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  24  Stability Project 1.19.1.3 7/2/2011 4:55:36 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  23  Stability Project 1.19.1.2 7/1/2011 4:37:58 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  22  Stability Project 1.19.1.1 3/17/2011 3:20:10 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  21  Stability Project 1.19.1.0 2/15/2011 3:02:14 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// **************************************************************************
#include "BaseCfgMgr.h"
#include "ConfigBranch.h"
#include "ConfigItem.h"
#include "ConfigInterface.h"
#include "ConfigData.h"
#include "V6ResourceBase.h"
#include "V6UIResource.h"
#include "StringUtils.h"
#include <QWidget>
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
// Generic Key Names
// Number asprintf
const QString CBaseCfgMgr::ms_strNUM_FORMAT_KEY = QString::fromWCharArray(L"NUMF");
const QString CBaseCfgMgr::ms_strNUM_FORMAT_SCI_KEY = QString::fromWCharArray(L"SCI");
const QString CBaseCfgMgr::ms_strNUM_FORMAT_AUTO_KEY = QString::fromWCharArray(L"AUTO");
const QString CBaseCfgMgr::ms_strNUM_FORMAT_AD_KEY = QString::fromWCharArray(L"AD");
// Style key names
const QString CBaseCfgMgr::ms_strSTYLE_COLOUR_KEY = QString::fromWCharArray(L"COL");
const QString CBaseCfgMgr::ms_strSTYLE_THICKNESS_KEY = QString::fromWCharArray(L"THICK");
// Generic List Item Names
QString CBaseCfgMgr::ms_strEnabledList = "";
QString CBaseCfgMgr::ms_strNumasprintfSciList = "";
QString CBaseCfgMgr::ms_strNumasprintfAutoList = "";
// Static/const initialisation
const ULONG CBaseCfgMgr::ms_ulMaxColour = 0x00FFFFFF;
//****************************************************************************
// CBaseCfgMgr(void)
///
/// Constructor
///
//****************************************************************************
CBaseCfgMgr::CBaseCfgMgr(const T_CONFIG_TYPE eCONFIG_TYPE) : m_bModified(false), m_eCONFIG_TYPE(eCONFIG_TYPE), m_dwPOST_MESSAGE_WAIT_TIMEOUT(
		60000)
{
}
//****************************************************************************
// ~CBaseCfgMgr(void)
///
/// Destructor
///
//****************************************************************************
CBaseCfgMgr::~CBaseCfgMgr(void) {
}
//****************************************************************************
// void LoadStrings()
///
/// Method that loads all the title strings and listbox items into some static string 
/// objects. This is to decrease memory usage
/// 
//****************************************************************************
void CBaseCfgMgr::LoadStrings() {
	// only load the strings if there have nto already been loaded
	if (ms_strEnabledList == "") {
		// do not embed the control characters if this is screen designer
#ifndef DOCVIEW
		ResColour *pkColour = pSYSTEM_INFO->pOemInfo->GetColour( V6RES_COLOUR_BTNTRUETEXT);
		COLORREF crTrue = pkColour->pColor;
		QString strTrueColour(QString::fromWCharArray(L" "));
		strTrueColour = QString::asprintf("%u", crTrue);
		QString strFalseColour(QString::fromWCharArray(L" "));
		pkColour = pSYSTEM_INFO->pOemInfo->GetColour( V6RES_COLOUR_BTNFALSETEXT);
		COLORREF crFalse = pkColour->pColor;
		strFalseColour = QString::asprintf("%u", crFalse);
		ms_strEnabledList = QString::asprintf("%c%s%c%c|%c%s%c%c|", g_wcMOD_COLOUR, strFalseColour.toLocal8Bit().data(),
				g_wcMOD_COLOUR, g_wcCROSS, g_wcMOD_COLOUR, strTrueColour.toLocal8Bit().data(), g_wcMOD_COLOUR,
				g_wcTICK);
#else
		ms_strEnabledList = QString::asprintf( L"%c|%c|", g_wcCROSS, g_wcTICK );
#endif
		ms_strNumasprintfSciList = QWidget::tr("Normal|Scientific|");
		ms_strNumasprintfAutoList = QWidget::tr("User Defined|Auto|");
	}
}
//****************************************************************************
// void SetupStyleDetails( CConfigBranch *pkParent, T_PPEN ptPenData )
///
/// Method that sets up the style details for a particular pen
///
/// @param[in/out] 		CConfigBranch *pkParent - Pointer to the parent owner class
/// @param[in]			T_PPEN ptPenData - A pointer to the associated pen data
///
//****************************************************************************
void CBaseCfgMgr::SetupStyleDetails(CConfigBranch *pkParent, T_PLINESTYLE ptLineStyleData) {
	// Line Colour - this is a ULONG
	CULongData *pkColourData = new CULongData(&ptLineStyleData->Colour, 0, ULONG_MAX, 0, 0, true);
	QString strColour("");
	strColour = QWidget::tr("Color");
	CConfigItem *pkColour = new CConfigItem(ms_strSTYLE_COLOUR_KEY, strColour, strColour, ctItemButton, pkColourData,
			false, true, 0, false, pkParent);
	pkParent->AddChild(pkColour);
	// Line thickness - this is a USHORT
	CUShortData *pkThicknessData = new CUShortData(&ptLineStyleData->Thickness, 1, 7, 0, 0, true);
	QString strThickness("");
	strThickness = QWidget::tr("Trace Width");
	CConfigItem *pkThickness = new CConfigItem(ms_strSTYLE_THICKNESS_KEY, strThickness, strThickness, ctItemButton,
			pkThicknessData, false, true, 0, false, pkParent);
	pkParent->AddChild(pkThickness);
	/*
	 // Line style - this is a USHORT
	 CUShortData *pkStyleData = new CUShortData(	&ptLineStyleData->Style,
	 0,
	 255,
	 0,
	 0 );
	 QString   strLineStyle( "" );
	 strLineStyle.LoadString( IDS_CFG_STYLE_LINE_STYLE_TITLE );
	 CConfigItem *pkStyle = new CConfigItem(	ms_strSTYLE_LINESTYLE_KEY,
	 strLineStyle,
	 strLineStyle,						
	 ctItemButton,
	 pkStyleData,
	 false,
	 true,
	 0,
	 false,
	 pkParent );
	 pkParent->AddChild( pkStyle );
	 */
}
//****************************************************************************
// void SetupNumasprintf( CConfigBranch *pkParent, T_PNUMFORMAT ptNumasprintf, const bool bEnabled /* = true */ )
///
/// Method that sets up the number format for a particular item
///
/// @param[in/out] 		CConfigBranch *pkParent - Pointer to the parent owner class
/// @param[in]			T_PPEN ptPenData - A pointer to the associated number format data
///	@param[in]			const bool bEnabled - enabled / disable flag, defaulted true
///
//****************************************************************************
void CBaseCfgMgr::SetupNumasprintf(CConfigBranch *pkParent, T_PNUMFORMAT ptNumasprintf,
		const bool bEnabled /* = true */) {
	QString strNumasprintf("");
	QString strSubTitle("");
	QString strSci("");
	strSubTitle = CStringUtils::GetItemAtPos(ms_strNumasprintfSciList, ptNumasprintf->Scientific);
	strNumasprintf = QWidget::tr("Numb asprintf");
	CConfigBranch *pkNumasprintfParent = new CConfigBranch(ms_strNUM_FORMAT_KEY, strNumasprintf, strSubTitle,
			ctSubMenuButton, false, bEnabled, 0, false, pkParent);
	pkParent->AddChild(pkNumasprintfParent);
	// Scientific - this will be a bitfield
	CShortBitFieldData *pkSciData = new CShortBitFieldData(reinterpret_cast<USHORT*>(ptNumasprintf), 1, 11,
			ms_strNumasprintfSciList, bfeBool, 0, 0, true);
	strSci = QWidget::tr("Notation");
	CConfigItem *pkSci = new CConfigItem(ms_strNUM_FORMAT_SCI_KEY, strSci, strSubTitle, ctItemButton, pkSciData, false,
			true, 0, false, pkNumasprintfParent);
	pkNumasprintfParent->AddChild(pkSci);
	// Auto - this will be a bitfield
	QString strAuto("");
	strSubTitle = CStringUtils::GetItemAtPos(ms_strNumasprintfAutoList, ptNumasprintf->Auto);
	CShortBitFieldData *pkAutoData = new CShortBitFieldData(reinterpret_cast<USHORT*>(ptNumasprintf), 1, 0,
			ms_strNumasprintfAutoList, bfeBool, 0, 0, true);
	strAuto = QWidget::tr("Auto");
	CConfigItem *pkAuto = new CConfigItem(ms_strNUM_FORMAT_AUTO_KEY, strAuto, strSubTitle, ctItemButton, pkAutoData,
			false, true, 0, false, pkNumasprintfParent);
	pkNumasprintfParent->AddChild(pkAuto);
	// After decimal - this will be a USHORT although it is stored as a bitfield
	QString strAD("");
	CShortBitFieldData *pkADData = new CShortBitFieldData(reinterpret_cast<USHORT*>(ptNumasprintf), 4, 7, strAD,
			bfeNumerical, 0, 0, false, 0, 15);
	strAD = QWidget::tr("After Decimal");
	//MarkD: if in Auto, don't display a number of decimal places, as it isn't fixed
	//Unless set to Scientific, when Auto decimal places is set to 1
	if (ptNumasprintf->Auto) {
		if (ptNumasprintf->Scientific) {
			strSubTitle = QString::asprintf("1");	// auto scientific = 1
		} else {
			strSubTitle = QWidget::tr("Variable");
			//strSubTitle = QString::asprintf( L"Variable" );	// auto normal is variable - no entry
		}
	} else	// user defined - give the number set
	{
		strSubTitle = QString::asprintf("%d", ptNumasprintf->Ad);
	}
	CConfigItem *pkAfterDec = new CConfigItem(ms_strNUM_FORMAT_AD_KEY, strAD, strSubTitle, ctItemButton, pkADData,
			false, !ptNumasprintf->Auto, 0, false, pkNumasprintfParent);
	pkNumasprintfParent->AddChild(pkAfterDec);
}
//****************************************************************************
//	CConfigItem* indexOfChildByKey( const QString   &rstrKEY )
///
/// Method that finds the child that has the passed in key
///
/// @param[in] 		const QString   &rstrKEY - The key of the child we want to find
///
/// @return			Returns a pointer to the child or NULL if none found (error!)
///
//****************************************************************************
CConfigInterface* CBaseCfgMgr::indexOfChildByKey(const QString &rstrKEY, CConfigBranch *pkParent,
		const USHORT usSTART_KEY_POS) const {
	bool bFinished = false;
	USHORT usKeyPos = usSTART_KEY_POS;
	QString strCurrKey("");
	CConfigBranch *pkCurrParent = pkParent;
	CConfigInterface *pkCurrChild = NULL;
	// loop down the tree until we find the new item with our stored key name
	while (!bFinished) {
		strCurrKey = CStringUtils::GetItemAtPos(rstrKEY, usKeyPos);
		// loop through all the children available to this branch until a match is found
		pkCurrChild = pkCurrParent->GetFirstChild();
		do {
			QString strChildKey(pkCurrChild->GetKey());
			if (strCurrKey.compare(CStringUtils::GetItemAtPos(strChildKey, usKeyPos)) == 0) {
				// found a match, make this the parent
				pkCurrParent = static_cast<CConfigBranch*>(pkCurrChild);
				break;
			} else {
				// no match found yet therefore move onto the next child
				pkCurrChild = pkCurrParent->GetNextChild();
			}
		} while (pkCurrChild != NULL);
		// check how the above loop finished
		if (pkCurrChild == NULL) {
			// there has been a problem therefore drop out of the loop
			bFinished = true;
		} else {
			// compare the entire key of the current item
			if (rstrKEY.compare(pkCurrParent->GetKey()) == 0) {
				// this is a match therefore we have our item
				bFinished = true;
			} else {
				// no match found therefore repeat at the next level
				++usKeyPos;
			}
		}
	}
	return pkCurrChild;
}

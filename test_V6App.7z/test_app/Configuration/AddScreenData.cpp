/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Configuration System
/// @n Filename:  AddScreenData.cpp
/// @n Description: Implementation for the CAddScreenData class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  6 Stability Project 1.1.1.3 7/2/2011 4:55:13 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  5 Stability Project 1.1.1.2 7/1/2011 4:37:54 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  4 Stability Project 1.1.1.1 3/17/2011 3:20:07 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  3 Stability Project 1.1.1.0 2/15/2011 3:02:01 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// **************************************************************************
#include "AddScreenData.h"
#include "ConfigInterface.h"
#include "ConfigBranch.h"
#include "Screen.h"
#include "ScrnDesCfgMgr.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//****************************************************************************
// CAddScreenData(	const int iHELP_ID,
//					const int iDESC_ID )
///
/// Constructor
///
/// @param[in]			const int iHELP_ID - The resource ID of the associated help for
///						this item
/// @param[in]			const int iDESC_ID - The resource ID of the assocaited description for
///						this item
///
//****************************************************************************
CAddScreenData::CAddScreenData(const int iHELP_ID, const int iDESC_ID) : CConfigData(dtAddScreen, iHELP_ID, iDESC_ID,
		true) {
}
//****************************************************************************
// ~CAddScreenData(void)
///
/// Destructor
///
//****************************************************************************
CAddScreenData::~CAddScreenData() {
}
//****************************************************************************
// const QString   GetDataAsString( ) const
///
/// Method called to get the data as a string
///
/// @param[in]		const bool bINCLUDE_UNITS - Flag indicating the untis must be appended to
///					the end of the string - not used for this item
///
/// @return	The data as a string
///
//****************************************************************************
const QString CAddScreenData::GetDataAsString(const bool bINCLUDE_UNITS /* = false */) {
	QString strData("");
	strData = QWidget::tr("Add Screen");
	return strData;
}
//****************************************************************************
// void UpdateData( CConfigInterface *pkThisItem )
///
/// Method that updates the data e.g. a new screen is added to the layout 
///
/// @param[in]		CConfigInterface *pkThisItem - A pointer to the config control object
///					for this item. This is required when we insert the new screen into the
///					config heirarchy
///
//****************************************************************************
void CAddScreenData::UpdateData(CConfigInterface *pkThisItem) {
	CScrnDesCfgMgr *pkScrnDesCfgMgr = CScrnDesCfgMgr::Instance();
	COpPanel *pkOpPanel = static_cast<COpPanel*>(AfxGetApp()->m_pMainWnd);
	pkOpPanel->AddNewScreen(pGlbLayout, NULL);
	// we now need to add this screen into our list dynamically - get the parent first
	CConfigBranch *pkParent = static_cast<CConfigBranch*>(pkThisItem->GetParent());
	// create a screen config - get a pointer to the new screen C++ object - this will be the last in the list
	CScreen *pkLastScreen = pkOpPanel->m_pScreens;
	USHORT usScreenCount = 1;
	while (pkLastScreen->m_pNextScr != NULL) {
		pkLastScreen = pkLastScreen->m_pNextScr;
		++usScreenCount;
	}
	T_PSCREEN ptCMMScreen = pkLastScreen->GetCMMScreen();
	QString strKey("");
	QString strTitle("");
	strKey = QString::asprintf("%u", usScreenCount);
	strKey = CScrnDesCfgMgr::ms_strSCREEN_TITLE_KEY + strKey;
	QString strFormatString = "";
	strFormatString = QWidget::tr("Screen %u");
	strTitle = QString::asprintf(strFormatString, usScreenCount);
	CConfigBranch *pkNewScreenBranch = new CConfigBranch(strKey, strTitle, ptCMMScreen->Name, ctSubMenuButton, false,
			true, 0, false, pkParent);
	pkScrnDesCfgMgr->SetupScreenConfig(pkLastScreen, pkNewScreenBranch);
	// now we need to insert this new screen branhc into the parent list above the add screen option
	pkParent->InsertChild(pkNewScreenBranch, pkThisItem);
}

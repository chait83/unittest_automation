/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 Configuration
/// @n IOSetupConfig.cpp
/// @n implementation to handle creating default configurations
///  and getting CMM configuration for I/O boards.
/// @author GKW
/// @date 22/09/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
//  88  Stability Project 1.83.1.3 7/2/2011 4:58:02 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  87  Stability Project 1.83.1.2 7/1/2011 4:38:22 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  86  Stability Project 1.83.1.1 3/17/2011 3:20:26 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  85  Stability Project 1.83.1.0 2/15/2011 3:03:11 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////
#include "SlotMap.h"
#include "V6defines.h"
#include "CMMDefines.h"
#include "V6Config.h"
#include "IOSetupConfig.h"
#include "SetupConfiguration.h"
#include "V6ResourceBase.h"
#include "V6UIResource.h"
#include "V6globals.h"
#include "ATECal.h"
#include "AMS2750InputCalMgr.h"
#include "AMS2750ProcessCalFile.h"
#include "BrdInfo.h"
#include "DevCaps.h"
#include "InputConditioning.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
extern QMutex m_GlbSetupMutex;
CIOSetupConfig::CIOSetupConfig(void) {
//	qDebug("Create new CIOSetupConfig\n");
	m_pSlotMapObj = CSlotMap::GetHandle();
	// update the AMS2750 sensor information
	LoadAMS2750SensorBlockFromNV();
}
CIOSetupConfig::~CIOSetupConfig(void) {
//	qDebug("Deleting CIOSetupConfig class\n");
}
//******************************************************
///
/// Creates this services default configuration.
///
/// @return CONFIG_OK if succesful creation; otherwise CONFIG_ERROR
/// 
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::CreateServiceDefaultConfig(void) {
	T_CONFIG_RETURN_VALUE retValue = CONFIG_OK;
	retValue = CreateRecorderSlots();		// Create the recorder slots
	if (retValue == CONFIG_OK)
		retValue = CreateTopSlotRecorderCalInfo();		// Create the recorder calibration data
	return (retValue);
} // End of Member Function
//**********************************************************************
///
/// Function that is called immediately before a setup config is commited
/// to the CMM.
///
/// @return		T_CONFIG_RETURN_VALUE return value
/// 
//**********************************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::PreCommitProcessing(void) {
	QString strRenewalDateChangedMsg("");
	QString strCalDateChangedMsg("");
	QString strPrevDate("");
	QString strNewDate("");
	CTVtime kTime;
	// check for any differences between the AMS2750 sensor renewal dates and calibration dates
	for (USHORT usSensorCount = 0; usSensorCount < AMS2750SENSORS_SENSORS_SIZE; usSensorCount++) {
		T_AMS2750SENSOR *committedSensor = &m_AMS2750SensorsCommitted.Sensors[usSensorCount];
		T_AMS2750SENSOR *workingSensor = &m_AMS2750SensorsWorking.Sensors[usSensorCount];
		// check the renewal dates first
		if (committedSensor->DateRenewed != workingSensor->DateRenewed) {
			bool isTC = IsAnalogueSetupAsTC(usSensorCount);
#if (!defined DOCVIEW) && (!defined TTR6SETUP)
			// log a system message
			/// TODO : Uncomment DateAsString API in ctvtime
			kTime = static_cast<LONGLONG>(committedSensor->DateRenewed) * USEC_IN_A_SEC;
			kTime.DateAsString(strPrevDate);
			kTime = static_cast<LONGLONG>(workingSensor->DateRenewed) * USEC_IN_A_SEC;
			kTime.DateAsString(strNewDate);
			strRenewalDateChangedMsg = QString::asprintf(IDS_AMS2750_TC_STATUS_RENEWAL_DATE_CHANGED_MSG,
					CAMS2750TUSMgr::buildSensorName(usSensorCount + 1, isTC), strPrevDate, strNewDate);
			LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_INFORMATION, strRenewalDateChangedMsg);
#endif
		}
		// now check the renewal dates first
		if (committedSensor->NextCalibDate != workingSensor->NextCalibDate) {
			bool isTC = IsAnalogueSetupAsTC(usSensorCount);
#if (!defined DOCVIEW) && (!defined TTR6SETUP)
			// log a system message
			kTime = static_cast<LONGLONG>(committedSensor->NextCalibDate) * USEC_IN_A_SEC;
			kTime.DateAsString(strPrevDate);
			kTime = static_cast<LONGLONG>(workingSensor->NextCalibDate) * USEC_IN_A_SEC;
			kTime.DateAsString(strNewDate);
			strCalDateChangedMsg = QString::asprintf(IDS_AMS2750_TC_STATUS_CAL_DATE_CHANGED_MSG,
					CAMS2750TUSMgr::buildSensorName(usSensorCount + 1, isTC), strPrevDate, strNewDate);
			LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_INFORMATION, strCalDateChangedMsg);
#endif
		}
	}
	// update the committed AMS2750 sensor data
	UpdateAMS270SensorCommittedWithWorking();
	// update the NV Multi Point data
	T_PMPCALCHANNELS pWorkingMpChannelCal = GetMultiPointBlock(CONFIG_MODIFIABLE);
	T_PMPCALCHANNELS pCommittedMpChannelCal = GetMultiPointBlock(CONFIG_COMMITTED);
	CGeneralSetupConfig *pkGenCfg = pSETUP->GetGeneralSetupConfig();
	T_AMS2750CALCFG *ptCalConfig = pkGenCfg->GetAMS2750CalibrationBlock(CONFIG_MODIFIABLE);
	const ULONG lastInputCalTestDate = ptCalConfig->TestDate;
	// Check if block exists, if yes then update the NV copy
	if (pWorkingMpChannelCal != NULL) {
		// sanity check the multi-point cal elements as we've seen some invalid values
		for (USHORT usChanCount = 0; usChanCount < MPCALCHANNELS_CHANNEL_SIZE; usChanCount++) {
			T_MPCALCHANNEL *modifiableChannel = &pWorkingMpChannelCal->Channel[usChanCount];
			if (modifiableChannel->CalElements > MPCALCHANNEL_CALPOINTS_SIZE) {
				// this is an invalid value, report it and reset to 0
				QString errorMessage;
				errorMessage = QString::asprintf("Invalid multi-point cal. value for analogue input %d, defaulted",
						usChanCount + 1);
				LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, errorMessage);
				modifiableChannel->CalElements = 2;
				modifiableChannel->CalPoints[0].CalPoint = 0.0;
				modifiableChannel->CalPoints[0].Offset = 0.0;
				modifiableChannel->CalPoints[1].CalPoint = 1.0;
				modifiableChannel->CalPoints[1].Offset = 0.0;
			}
		}
		if (pCommittedMpChannelCal != NULL) {
			// check for any differences between the working and committed cals
			for (USHORT usChanCount = 0; usChanCount < MPCALCHANNELS_CHANNEL_SIZE; usChanCount++) {
				T_MPCALCHANNEL *committedChannel = &pCommittedMpChannelCal->Channel[usChanCount];
				T_MPCALCHANNEL *workingChannel = &pWorkingMpChannelCal->Channel[usChanCount];
				// check if any of the cal points have changed
				T_MPCALPOINT *committedCalPoints = committedChannel->CalPoints;
				float *committedPrevCalPoints = committedChannel->PrevCalPoints;
				T_MPCALPOINT *workingCalPoints = workingChannel->CalPoints;
				float *workingPrevCalPoints = workingChannel->PrevCalPoints;
				for (int calPointIndex = 0; calPointIndex < MPCALCHANNEL_CALPOINTS_SIZE; calPointIndex++) {
					// only perform this check if the input cal dates match which implies this is not following an
					// input calibration or the dates don't match but the new cal date is not the same as the last overall
					// input cal date which implies the user has manaully changed the cal date
					if ((pCommittedMpChannelCal->LastCalDate[usChanCount]
							== pWorkingMpChannelCal->LastCalDate[usChanCount])
							|| (pWorkingMpChannelCal->LastCalDate[usChanCount] != lastInputCalTestDate)) {
						// check this point is even valid
						if ((int) workingChannel->CalElements > calPointIndex) {
							// find the current cal point in the working, find a match in the committed, then check
							// to see if they've changed. If yes the copy the current committed cal point to the 
							// previous cal point in the working
							for (int commCalPointIndex = 0; commCalPointIndex < MPCALCHANNEL_CALPOINTS_SIZE;
									commCalPointIndex++) {
								if ((int) committedChannel->CalElements > commCalPointIndex) {
									if (committedCalPoints[commCalPointIndex].CalPoint
											== workingCalPoints[calPointIndex].CalPoint) {
										// this is a match, check if the offset has changed
										if (committedCalPoints[commCalPointIndex].Offset
												== workingCalPoints[calPointIndex].Offset) {
											// the offset's match so no change - replace previous with the existing previous which it
											// probably is anyway unless a load of inserts and removes of the same values took place
											workingPrevCalPoints[calPointIndex] =
													committedPrevCalPoints[commCalPointIndex];
										} else {
											// the offset's don't match so copy the previous offset to the working previous
											workingPrevCalPoints[calPointIndex] =
													committedCalPoints[commCalPointIndex].Offset;
										}
										// exit this inner loop as a match was found
										break;
									}
								} else {
									// we've exceeded the cal points and thus won't find a match - ensure the previous is 0.0
									workingPrevCalPoints[calPointIndex] = 0.0F;
									// break from this inner loop as no more readings to check
									break;
								}
							}
						} else {
							// we've exceeded the cal points so just ensure the previous cal point is zero in this case
							workingPrevCalPoints[calPointIndex] = 0.0F;
						}
					}
				}
			}
		}
		UpdateMultiPointNVFromCMM(pWorkingMpChannelCal);
	}
#if (!defined DOCVIEW) && (!defined TTR6SETUP)
	// check the in-memory/saved calibration matches the new config
	ValidateAMS2750Calibration();
#endif
	return CONFIG_OK;
}
#if (!defined DOCVIEW) && (!defined TTR6SETUP)
//*************************************************************************************
///
/// Validates the AMS2750 calibration against any newly modified changes to the cal
///
//*************************************************************************************
void CIOSetupConfig::ValidateAMS2750Calibration() {
	// check this recorder is configured for AMS2750
	if (pSYSTEM_INFO->GetAMS2750Mode() != AMS2750_NONE) {
		CAMS2750InputCalMgr *pkCalMgr = new CAMS2750InputCalMgr();
		pkCalMgr->PrecommitValidateCal();
		delete pkCalMgr;
	}
}
#endif
//*************************************************************************************
/// Determine if the analogue input is a TC
///
///
/// @return T_CONFIG_RETURN_VALUE indicating status of call
/// 
//*************************************************************************************
bool CIOSetupConfig::IsAnalogueSetupAsTC(const USHORT usSensorCount) {
	USHORT usSlotNo = 0;
	USHORT usBoardChanNum = 0;
	// check the slot number and board channel number are okay and that an analogue input card exists in this slot
	if (indexOfBoardSlotAndChannel(usSensorCount + 1, &usSlotNo, &usBoardChanNum)) {
		// Get the pen data structure
		T_PAICHANNEL ptAnalogueData = NULL;
		ptAnalogueData = GetAnalogueInput(usSlotNo, usBoardChanNum, CONFIG_MODIFIABLE);
		// Check we managed to obtain a pen
		if (ptAnalogueData != NULL) {
			if (ptAnalogueData->Type != AI_CHANNEL_TYPE_TC) {
				return false;
			}
		}
	}
	return true;
}
//*************************************************************************************
/// Validate the configuration items when a config has been loaded and is about to be commited
///
///
/// @return T_CONFIG_RETURN_VALUE indicating status of call
/// 
//*************************************************************************************
T_CONFIG_VALIDATE_RETURN CIOSetupConfig::ValidateServiceConfig(void) {
	T_CONFIG_VALIDATE_RETURN retValue = CONFIG_VALIDATE_NO_CHANGES;
	CDeviceCaps PrevDevCaps;
	T_DEVICECAPS PrevDevCapsData;
	// Get the previous recorder configuration
	GetPreviousRecorderConfig(&PrevDevCapsData);
	PrevDevCaps.SetPtrToDeviceCaps(&PrevDevCapsData);
	// Run through and align IO configurtion with actual IO hardware in system
#ifndef DOCVIEW
#ifndef TTR6SETUP
	// update the CMM with the NVRAM calibration data 
	CPPIOServiceManager *pkServiceManagerObj = NULL; ///< Service manager
	CInputConditioning *pkICService = NULL; ///< Input conditioning service
	pkServiceManagerObj = CPPIOServiceManager::GetHandle();
	if (pkServiceManagerObj != NULL) {
		pkICService = pkServiceManagerObj->GetICService();
		// make sure we have the NV data loaded and is valid (which it won't be on first time run)
		if (pkICService->IOCalLoad()) {
			// now update the CMM with the NVRAM data
			pkICService->RecorderCalCMMDump();
		}
	}
#endif
#endif
	for (USHORT slotNo = 0; slotNo < GlbDevCaps.GetIOCardInfo(); slotNo++) {
		// Run validate and modify routine, if any changes are made set the return value to indicate this
		// note: do not set return value directly as this would overwrite possible changes.
		if (ValidateAndAlignBoardCMM(slotNo, &PrevDevCaps) == CONFIG_VALIDATE_CHANGES_MADE) {
			retValue = CONFIG_VALIDATE_CHANGES_MADE;
		}
	}
#ifndef DOCVIEW
	// Check the CMM I/O calibration structures
	if (ResetProcessedCMMToUserCalSet() == CONFIG_VALIDATE_CHANGES_MADE) {
		retValue = CONFIG_VALIDATE_CHANGES_MADE;
	}
	// check if in AMS2750 TUS mode or process mode
	if ( pSYSTEM_INFO->FWOptionAMS2750ProcessAvailable()) {
		bool bSensorChanged = false;
		// we are in process mode therefore we need to reset the TUS flags in the AMS2750 sensor configurations
		// in order to simplify the TC AMS2750 status code
		for (USHORT usSensor = 0; usSensor < AMS2750SENSORS_SENSORS_SIZE; usSensor++) {
			// check if this TC is configured to be a TUS TC
			if (m_AMS2750SensorsWorking.Sensors[usSensor].TUSTC) {
				m_AMS2750SensorsWorking.Sensors[usSensor].TUSTC = FALSE;
				bSensorChanged = true;
			}
		}
		// check if we had to change any of the sensor information
		if (bSensorChanged) {
			// update the committed structure and the NV
			UpdateAMS270SensorCommittedWithWorking();
		}
	} else if ( pSYSTEM_INFO->FWOptionTUSModeAvailable()) {
		bool bSensorChanged = false;
		// we are in TUS mode therefore we need to reset the load flags in the AMS2750 sensor configurations
		// in order to simplify the TC AMS2750 status code
		for (USHORT usSensor = 0; usSensor < AMS2750SENSORS_SENSORS_SIZE; usSensor++) {
			// check if this TC is configured to be a load TC
			if (m_AMS2750SensorsWorking.Sensors[usSensor].LoadTC) {
				m_AMS2750SensorsWorking.Sensors[usSensor].LoadTC = FALSE;
				bSensorChanged = true;
			}
		}
		// check if we had to change any of the sensor information
		if (bSensorChanged) {
			// update the committed structure and the NV
			UpdateAMS270SensorCommittedWithWorking();
		}
	}
#endif
	// Validate the recorder calibration block block
	T_PRECORDERCAL pRecCal = GetTopSlotRecorderCalInfo(CONFIG_MODIFIABLE);
	// Check if block exists, if not create
	if (pRecCal == NULL) {
		// Block does not exist so create and update the structure
		CreateTopSlotRecorderCalInfo();
		retValue = CONFIG_VALIDATE_CHANGES_MADE;
	}
	// validate the multipoint cal block
	T_PMPCALCHANNELS pMPChannelCal = GetMultiPointBlock(CONFIG_MODIFIABLE);
	// Check if block exists, if not create, otherwise check for any compatablility issues	
	if (pMPChannelCal == NULL) {
		// Block does not exist so create
		pMPChannelCal = CreateTCMultipointCalBlock();
		if (pMPChannelCal == NULL) {
			// the config didn't get created properly
			retValue = CONFIG_VALIDATE_INVALID;
		} else {
#ifndef TTR6SETUP
			// ensure the cal reflects the cal in NV
			UpdateMultiPointCMMFromNV(pMPChannelCal);
#endif
		}
		retValue = CONFIG_VALIDATE_CHANGES_MADE;
	} else
#ifndef TTR6SETUP
		// ensure the cal reflects the cal in NV
		UpdateMultiPointCMMFromNV(pMPChannelCal);
#endif
	return (retValue);
}
//******************************************************
// GetPreviousRecorderConfig()
///
/// Obtain the saved Device Caps from the CMM.
///
/// @return creation sucess state
/// 
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::GetPreviousRecorderConfig(const T_DEVICECAPS *const pPrevDevCaps) {
	BLOCK_INFO blockInfo;
	T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;
	CMMERROR err = CMM_FAILED;
	// Update CMM default device capabilities
	blockInfo.wInstanceID = ONLY_ONE_INST;
	blockInfo.wBlockType = BLK_DEVICECAPS;
	/// TODO : Implementation of GetDataBlock
	err = GetDataBlock(m_ConfigurationId, &blockInfo, CONFIG_MODIFIABLE);
	if (err == CMM_SUCCESS) {
		// Copy over the previous I/O board device capabilities
		memcpy((void*) pPrevDevCaps, (void*) blockInfo.pByBlock, (size_t) blockInfo.dwBlockSize);
		retValue = CONFIG_OK;
	}
	return retValue;
}
//******************************************************
// AnyEnabledEvents()
///
/// Are there any enabled events configured in the CMM.
///
/// @return TRUE if there is at least a single event enabled; otherwise FALSE
/// 
//******************************************************
BOOL CIOSetupConfig::AnyEnabledEvents() {
	class CEventSetupConfig *pEventConfig = NULL;
	T_EVENTSYSTEM *pEventBlk = NULL;
	T_PEVENT pEvent = NULL;
	USHORT usEventNo = 0;
	BOOL retValue = FALSE;
	pEventConfig = pSETUP->GetEventSetupConfig();
	pEventBlk = pEventConfig->GetEventBlock(CONFIG_COMMITTED);
	for (usEventNo = 0; usEventNo < V6_MAX_EVENTS; usEventNo++) {
		pEvent = &pEventBlk->Event[usEventNo];
		if ((pEvent != NULL) && (TRUE == pEvent->Enabled)) {
			// Register and leave if any event is enabled
			retValue = TRUE;
			break;
		}
	}
	return retValue;
}
//******************************************************
// CreateRecorderSlots()
///
/// Create the default configuration for an Analogue Input channel in the CMM.
/// @todo: Update the board and channel labels from resource table
///
/// @return creation sucess state
/// 
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::CreateRecorderSlots(void) {
	T_CONFIG_RETURN_VALUE ret = CONFIG_ERROR;
	T_CONFIG_RETURN_VALUE retValue = CONFIG_OK;
	CMMERROR err = CMM_FAILED;
	BLOCK_INFO blockInfo;
	USHORT slotNo = RECORDER_SLOT_A;
	USHORT chanNumber = SLOT_CHANNEL_0;
	// Create a default recorder config for each slot
	do {
		ret = CreateDefaultBoard(slotNo);
		if (ret == CONFIG_OK) {
			if ( DEVICE_INFO.GetSlotPosition(slotNo) == SLOT_TOP) {
				// Top slot cards being created
				// Update the run-time parameters for the AI channel
				for (chanNumber = SLOT_CHANNEL_0; chanNumber < TOPSLOT_AICHAN_SIZE; chanNumber++) {
					ret = CreateDefAIChan(slotNo, chanNumber);
					if (ret != CONFIG_OK)
						retValue = ret;
				}
				// Update the run-time parameters for the AO channel
				for (chanNumber = SLOT_CHANNEL_0; chanNumber < TOPSLOT_AOCHAN_SIZE; chanNumber++) {
					ret = CreateDefAOChan(slotNo, chanNumber);
					if (ret != CONFIG_OK)
						retValue = ret;
				}
				// Update the run-time parameters for the pulse channel on top slot boards
				for (chanNumber = SLOT_CHANNEL_0; chanNumber < TOPSLOT_PULSECHAN_SIZE; chanNumber++) {
					ret = CreateDefTopPulseChan(slotNo, chanNumber);
					if (ret != CONFIG_OK)
						retValue = ret;
				}
			} else if ( DEVICE_INFO.GetSlotPosition(slotNo) == SLOT_BOTTOM) {
				// Bottom slot cards being created
				// Update the run-time parameters for the digital channel
				for (chanNumber = SLOT_CHANNEL_0; chanNumber < BOTTOMSLOT_DIGCHAN_SIZE; chanNumber++) {
					ret = CreateDefDigitalChan(slotNo, chanNumber);
					if (ret != CONFIG_OK)
						retValue = ret;
				}
			}
			slotNo++;
		}
	} while ((slotNo <= RECORDER_SLOT_I) && (ret == CONFIG_OK));
	if (ret == CONFIG_OK) {
		// Update CMM default device capabilities
		blockInfo.wInstanceID = ONLY_ONE_INST;
		blockInfo.wBlockType = BLK_DEVICECAPS;
		err = GetDataBlock(m_ConfigurationId, &blockInfo, CONFIG_MODIFIABLE);
		if (err == CMM_SUCCESS) {
			// Populate the CMM default device capabilities with real value from the global device capabilities
			memcpy((void*) blockInfo.pByBlock, (void*) DEVICE_INFO.GetPtrToDeviceCaps(),
					(size_t) blockInfo.dwBlockSize);
			err = ModifyDataBlock(m_ConfigurationId, &blockInfo);
		}
	}
	// Default config was not generated
	if ((err != CMM_SUCCESS) || (retValue != CONFIG_OK))
		return CONFIG_ERROR;
	return CONFIG_OK;
}
//******************************************************
// CreateDefAIChan()
///
/// Create the default configuration for an Analogue Input channel in the CMM.
/// @param[in] slotNumber - The recorder I/O board slot number.
/// @param[in] chanNumber - The recorder based channel number.
///
/// @return creation sucess state
/// 
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::CreateDefAIChan(const USHORT slotNumber, const USHORT chanNumber) {
	T_PTOPSLOT pTopSlot = NULL;
	T_PAICHANNEL pAIChan = NULL;
	T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;
	class CSlotMap *pSlotMap = NULL;
	pTopSlot = GetTopSlot(slotNumber, CONFIG_MODIFIABLE);
	if (pTopSlot != NULL) {
		pAIChan = static_cast<T_PAICHANNEL>(&pTopSlot->AIChan[chanNumber]);
		pSlotMap = CSlotMap::GetHandle();
		if (pSlotMap != NULL) {
			// Allocate the pen with the correct instance, default label and tie to relevant pen
			pAIChan->Instance = pSlotMap->GetSysChannelFromAnaInChannel(slotNumber, chanNumber, ONE_BASED) - 1;
			swprintf(pAIChan->Label, AOCHANNEL_LABEL_LEN, L"A%d", pAIChan->Instance + 1);
			pAIChan->TiedTo = pAIChan->Instance;
			retValue = CONFIG_OK;
		}
	}
	return retValue;
}
//******************************************************
// CreateDefAOChan()
///
/// Create the default configuration for an Analogue Input channel in the CMM.
/// @param[in] slotNumber - The recorder I/O board slot number.
/// @param[in] chanNumber - The recorder based channel number.
///
/// @return creation sucess state
/// 
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::CreateDefAOChan(const USHORT slotNumber, const USHORT chanNumber) {
	T_PTOPSLOT pTopSlot = NULL;
	T_PAOCHANNEL pAOChan = NULL;
	T_PPEN pPen = NULL;
	T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;
	class CSlotMap *pSlotMap = NULL;
	USHORT penNo = 0;
	pTopSlot = GetTopSlot(slotNumber, CONFIG_MODIFIABLE);
	if (pTopSlot != NULL) {
		pAOChan = static_cast<T_PAOCHANNEL>(&pTopSlot->AOChan[chanNumber]);
		pSlotMap = CSlotMap::GetHandle();
		if (pSlotMap != NULL) {
			for (penNo = 0; penNo < V6_MAX_PENS; penNo++) {
				pPen = NULL;
				if ( pSYSTEM_INFO->IsPenAvailable(penNo, ZERO_BASED) == TRUE) {
					CSingleLock lock(&m_GlbSetupMutex);
					lock.Lock();
					pPen = pGlbSetup->GetPenSetupConfig()->GetPen(penNo, ZERO_BASED, CONFIG_MODIFIABLE);
					lock.Unlock();
				}
				if ((pPen != NULL) && (pPen->Enabled == TRUE)) {
					pAOChan->PenNo = penNo;								///< Retransmit the first available pen
					break;												///< Look no further
				}
			}
			pAOChan->Instance = pSlotMap->GetSysChannelFromAnaOutChannel(slotNumber, chanNumber, ONE_BASED) - 1;
			swprintf(pAOChan->Label, AOCHANNEL_LABEL_LEN, L"AO%d", pAOChan->Instance + 1);
			retValue = CONFIG_OK;
		}
	}
	return retValue;
}
//******************************************************
// CreateDefDigitalChan()
///
/// Create the default configuration for an Digital channel in the CMM.
/// @param[in] slotNumber - The recorder I/O board slot number.
/// @param[in] chanNumber - The recorder based channel number.
///
/// @return creation sucess state
/// 
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::CreateDefDigitalChan(const USHORT slotNumber, const USHORT chanNumber) {
	T_PBOTTOMSLOT pBottomSlot = NULL;
	T_PDIGCHANNEL pDigitalChan = NULL;
	T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;
	class CSlotMap *pSlotMap = NULL;
	pBottomSlot = GetBottomSlot(slotNumber, CONFIG_MODIFIABLE);
	if (pBottomSlot != NULL) {
		pDigitalChan = static_cast<T_PDIGCHANNEL>(&pBottomSlot->DigChan[chanNumber]);
		pSlotMap = CSlotMap::GetHandle();
		if (pSlotMap != NULL) {
			pDigitalChan->Instance = pSlotMap->GetSysChannelFromDigIOChannel(slotNumber, chanNumber, ONE_BASED) - 1;
			swprintf(pDigitalChan->Label, AOCHANNEL_LABEL_LEN, L"D%d", pDigitalChan->Instance + 1);
			retValue = CONFIG_OK;
		}
	}
	return retValue;
}
//******************************************************
// CreateDefTopPulseChan()
///
/// Create the default configuration for a Pulse Input channel in the CMM.
/// @param[in] slotNumber - The recorder I/O board slot number.
/// @param[in] chanNumber - The recorder based channel number.
///
/// @return creation sucess state
/// 
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::CreateDefTopPulseChan(const USHORT slotNumber, const USHORT chanNumber) {
	T_PTOPSLOT pTopSlot = NULL;
	T_PPULSECHANNEL pPulseChan = NULL;
	T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;
	class CSlotMap *pSlotMap = NULL;
	pTopSlot = GetTopSlot(slotNumber, CONFIG_MODIFIABLE);
	if (pTopSlot != NULL) {
		pPulseChan = static_cast<T_PPULSECHANNEL>(&pTopSlot->PulseChan[chanNumber]);
		pSlotMap = CSlotMap::GetHandle();
		if (pSlotMap != NULL) {
			pPulseChan->Instance = pSlotMap->GetSysChannelFromDedicatedPulseChannel(slotNumber, chanNumber, ONE_BASED)
					- 1;
			swprintf(pPulseChan->Label, AOCHANNEL_LABEL_LEN, L"PI%d", pPulseChan->Instance + 1);
			retValue = CONFIG_OK;
		}
	}
	return retValue;
}
//******************************************************
// CreateDefaultBoard()
///
/// Create a default CMM configuration in a specified recorder slot,
/// using the slot information from the device capabilities table.
/// @param[in] slotNumber - The recorder I/O board slot number.
///
/// @return channel type creation sucess state
/// 
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::CreateDefaultBoard(const USHORT slotNumber) {
	USHORT chanNo;
	T_PTOPSLOT pTopSlot = NULL;
	T_PBOTTOMSLOT pBottomSlot = NULL;
	T_CONFIG_RETURN_VALUE retValue = CONFIG_OK;
	if ( DEVICE_INFO.GetSlotPosition(slotNumber) == SLOT_TOP) {
		// Top slot cards being accessed
		pTopSlot = CreateTopSlot(slotNumber);
		if (pTopSlot == NULL) {
			retValue = CONFIG_ERROR;
		} else {
			pTopSlot->SlotNumber = slotNumber;
			// Use the device capabilities table to create the safest channel set
			// Nothing special is required for AO & Pulse cards
			for (chanNo = 0; chanNo < TOPSLOT_AICHAN_SIZE; chanNo++) {
				switch (DEVICE_INFO.GetSlotType(slotNumber)) {
				case BOARD_AI:
				case BOARD_EZ_AI:
					// Make all AI board channels for reading volts
					pTopSlot->AIChan[chanNo].Type = AI_CHANNEL_TYPE_LINEAR_VOLTS;
					break;
				}
			}
		}
	} else if ( DEVICE_INFO.GetSlotPosition(slotNumber) == SLOT_BOTTOM) {
		// Bottom slot cards being accessed
		pBottomSlot = CreateBottomSlot(slotNumber);
		if (pBottomSlot == NULL) {
			retValue = CONFIG_ERROR;
		} else {
			pBottomSlot->SlotNumber = slotNumber;
			// Use the device capabilities table to create the safest channel set
			for (chanNo = 0; chanNo < BOTTOMSLOT_DIGCHAN_SIZE; chanNo++) {
				switch (DEVICE_INFO.GetSlotType(slotNumber)) {
				case BOARD_AR:
				case BOARD_DIO:
					// Make all digital board channels latched outputs
					pBottomSlot->DigChan[chanNo].DigO.OPLatched = DO_CHANNEL_LATCHED;
					break;
				}
			}
		}
	}
	return retValue;
}
//******************************************************
///
/// Check the CMM I/O calibration structure for a calibration required.
///
/// @return CONFIG_VALIDATE_CHANGES_MADE if any calibration required otherwise CONFIG_VALIDATE_NO_CHANGES.
/// 
//******************************************************
T_CONFIG_VALIDATE_RETURN CIOSetupConfig::CheckCMMForUserCalSet(void) {
	USHORT slotNo = 0;
	USHORT rangeNo = 0;
	USHORT chanNo = 0;
	T_RECORDERCAL *pCMMRecorderCal = NULL;
	T_CONFIG_VALIDATE_RETURN retValue = CONFIG_VALIDATE_NO_CHANGES;
	pCMMRecorderCal = GetTopSlotRecorderCalInfo(CONFIG_MODIFIABLE);
	if (pCMMRecorderCal != NULL) {
		for (slotNo = 0; slotNo < RECORDERCAL_RECORDERCALS_SIZE; slotNo++) {
			if (retValue == CONFIG_VALIDATE_CHANGES_MADE)
				break;
			// @todo: Only check the number of avaialable channels on each board actually fitted
			for (chanNo = 0; chanNo < IORANGECAL_CHANNEL_SIZE; chanNo++) {
				if (retValue == CONFIG_VALIDATE_CHANGES_MADE)
					break;
				for (rangeNo = 0; rangeNo < BOARDCALS_RANGECALS_SIZE; rangeNo++) {
					if (retValue == CONFIG_VALIDATE_CHANGES_MADE)
						break;
					// Check the range calibration selection
					if (pCMMRecorderCal->RecorderCals[slotNo].RangeCals[rangeNo].Channel[chanNo]
							== CInputConditioning::V6_IO_USER_AND_RECALIBRATE) {
						retValue = CONFIG_VALIDATE_CHANGES_MADE;
					}
				}
				// Check the channel single/dual point cals
				if (pCMMRecorderCal->RecorderCals[slotNo].ChanCals[chanNo].PointCals.CalType
						== CInputConditioning::V6_IO_USER_AND_RECALIBRATE) {
					retValue = CONFIG_VALIDATE_CHANGES_MADE;
				}
			}
		}
	}
	return retValue;
}
//******************************************************
///
/// Limit the CMM I/O calibration structure for a calibration required.
/// Check and remove from CMM calibration structure any 'illegal' user & calibration selections
/// these should never be persisted, but is so we need to remove them before loading configuration to the I/O board(s)
///
/// @return CONFIG_VALIDATE_CHANGES_MADE if changes were made otherwise CONFIG_VALIDATE_NO_CHANGES.
/// 
//******************************************************
T_CONFIG_VALIDATE_RETURN CIOSetupConfig::ResetProcessedCMMToUserCalSet(void) {
	USHORT slotNo = 0;
	USHORT rangeNo = 0;
	USHORT chanNo = 0;
	T_RECORDERCAL *pCMMRecorderCal = NULL;
	T_CONFIG_VALIDATE_RETURN retValue = CONFIG_VALIDATE_NO_CHANGES;
	pCMMRecorderCal = GetTopSlotRecorderCalInfo(CONFIG_MODIFIABLE);
	if (pCMMRecorderCal != NULL) {
		for (slotNo = 0; slotNo < RECORDERCAL_RECORDERCALS_SIZE; slotNo++) {
			// @todo: Only check the number of avaialable channels on each board actually fitted
			for (chanNo = 0; chanNo < IORANGECAL_CHANNEL_SIZE; chanNo++) {
				for (rangeNo = 0; rangeNo < BOARDCALS_RANGECALS_SIZE; rangeNo++) {
					// Check the range calibration selection
					if (pCMMRecorderCal->RecorderCals[slotNo].RangeCals[rangeNo].Channel[chanNo]
							== CInputConditioning::V6_IO_USER_AND_RECALIBRATE) {
						// Uploaded user calibration data to AI board so start using
						pCMMRecorderCal->RecorderCals[slotNo].RangeCals[rangeNo].Channel[chanNo] =
								CInputConditioning::V6_IO_FACTORY_CALIBRATION;
						retValue = CONFIG_VALIDATE_CHANGES_MADE;
					}
				}
			}
		}
	}
	return retValue;
}
//***************************************************************************
///
/// Validate the CMM configuration in a specified recorder slot, with the
/// actual hardware using the slot information from the device capabilities table.
/// Make any adjustments necessary to the CMM to aligh its config with the device capabilities table
///
/// @param[in] slotNumber - The recorder I/O board slot number.
///
/// @return board & CMM validation sucess state
/// 
//***************************************************************************
T_CONFIG_VALIDATE_RETURN CIOSetupConfig::ValidateAndAlignBoardCMM(const USHORT slotNumber,
		const class CDeviceCaps *const pPrevDevCaps) {
	T_CONFIG_VALIDATE_RETURN retValue = CONFIG_VALIDATE_NO_CHANGES;
#ifndef DOCVIEW
//TM removed	pAIRangeInfo = CAIRanges::GetHandle();
	class CBrdInfo *pBrdInfo = NULL;
	USHORT chanNo;
	USHORT penNo;
	BOOL boardChangeReported = FALSE;
	T_PTOPSLOT pTopSlot = NULL;
	T_PBOTTOMSLOT pBottomSlot = NULL;
	USHORT sysChanNo = 0;
	WCHAR slotNoStr[4];
	QString newSlotBrdStr("");
	QString oldSlSl

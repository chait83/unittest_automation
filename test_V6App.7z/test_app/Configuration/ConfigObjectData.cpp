/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Configuration System
/// @n Filename:  ConfigObjectData.cpp
/// @n Description: Implementation for the CConfigObjectData class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  21  Stability Project 1.16.1.3 7/2/2011 4:56:17 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  20  Stability Project 1.16.1.2 7/1/2011 4:38:08 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  19  Stability Project 1.16.1.1 3/17/2011 3:20:17 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  18  Stability Project 1.16.1.0 2/15/2011 3:02:40 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// **************************************************************************
#include "ConfigObjectData.h"
#include "LayoutConfiguration.h"
#include "DataItemBase.h"
#include "DataItemIO.h"
#include "V6UIResource.h"
#include "V6ResourceBase.h"
#include "DataItemMaxMinAve.h"
#include "Widget.h"
#include "Screen.h"
#include "V6globals.h"
#include "BaseObject.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
//****************************************************************************
// CConfigObjectData(	T_BASEOBJECT *ptObject,
//						CWidget *pkWidget,
//						const int iHELP_ID,
//						const int iDESC_ID,
//						const bool bUPDATE_TREE_ON_CHANGE,
//						const T_CFG_DATA_TYPE eDATA_TYPE )
///
/// Constructor
///
///	@param[in]			T_BASEOBJECT *ptBaseObject - Pointer to the base object data in the CMM
///	@param[in]			CWidget *pkWidget - Pointer to the c++ widget that this object is on
/// @param[in]			const int iHELP_ID - The resource ID of the assocaited help for
///						this item
/// @param[in]			const int iDESC_ID - The resource ID of the assocaited description for
///						this item
/// @param[in]			const bool bUPDATE_TREE_ON_CHANGE - Flag indicating if this item requires
///						the config tree to be rebuilt when it changes
/// @param[in]			const T_CFG_DATA_TYPE eDATA_TYPE - The object data type
///
//****************************************************************************
CConfigObjectData::CConfigObjectData(T_BASEOBJECT *ptObject, CWidget *pkWidget, const int iHELP_ID, const int iDESC_ID,
		const bool bUPDATE_TREE_ON_CHANGE, const T_CFG_DATA_TYPE eDATA_TYPE) : CConfigData(eDATA_TYPE, iHELP_ID,
		iDESC_ID, bUPDATE_TREE_ON_CHANGE), m_ptBaseObject(ptObject), m_pkWidget(pkWidget) {
}
//****************************************************************************
// ~CConfigObjectData()
///
/// Destructor
///
//****************************************************************************
CConfigObjectData::~CConfigObjectData(void) {
}
//****************************************************************************
// void UpdateData( const WCHAR* const pwcDATA )
///
/// Method that updates an item's associated data
///
//****************************************************************************
void CConfigObjectData::UpdateData(const QString pwcDATA) {
}
//****************************************************************************
// const QString   GetDataAsString( const bool bINCLUDE_UNITS /* = false */ )
///
/// Method that gets the data as a string
///
/// @return String containing the data
///
//****************************************************************************
const QString CConfigObjectData::GetDataAsString(const bool bINCLUDE_UNITS /* = false */) {
	QString strData("");
	T_CHANNELREF *ptObjChanRef = NULL;
	T_ALARMMRKROBJECT *ptAlarmMrkr = NULL;
	// determine the object type and get a pointer to the channel ref data
	switch (m_ptBaseObject->ObjectType) {
	case DigitalObject: {
		T_DIGITALOBJECT *ptDig = reinterpret_cast<T_DIGITALOBJECT*>(m_ptBaseObject);
		ptObjChanRef = &ptDig->ChannelInfo;
	}
		break;
	case BarObject: {
		T_BAROBJECT *ptBar = reinterpret_cast<T_BAROBJECT*>(m_ptBaseObject);
		ptObjChanRef = &ptBar->ChannelInfo;
	}
		break;
	case TextObject: {
		T_TEXTOBJECT *ptText = reinterpret_cast<T_TEXTOBJECT*>(m_ptBaseObject);
		ptObjChanRef = &ptText->ChannelInfo;
	}
		break;
	case ScaleObject: {
		T_SCALEOBJECT *ptScale = reinterpret_cast<T_SCALEOBJECT*>(m_ptBaseObject);
		ptObjChanRef = &ptScale->ChannelInfo;
	}
		break;
	case ButtonObject: {
		T_BUTTONOBJECT *ptButton = reinterpret_cast<T_BUTTONOBJECT*>(m_ptBaseObject);
		ptObjChanRef = &ptButton->ChannelInfo;
	}
		break;
	case ChartObject:
	case PenPointersObject:
	case TabularDisplayObject:
	case CircularChartObject: {
		// chart objects or pen pointer are usually reflected by the number of pens in the widget channel list
		// loop though the widget channel list getting the maximum number of pens
		USHORT usMaxChannels;
		T_DEV_TYPE devType = pDEVICE_INFO->GetDeviceType();
		// check if this is a minitrend 
		if ( pDEVICE_INFO->IsRecorderMini() || pDEVICE_INFO->IsRecorderEzTrend()) {
			usMaxChannels = CBaseObject::ms_usMAX_MINITREND_CHART_PENS;
		} else if ( pDEVICE_INFO->IsRecorderMulti()) {
			usMaxChannels = CBaseObject::ms_usMAX_MULTITREND_CHART_PENS;
		} else if (devType == DEV_PC_SCREEN_DESIGNER) {
			T_DEV_TYPE recorderType = m_pkWidget->m_pConfig->GetRecorderType();
			// need to get the information from the layout file
			if (recorderType == DEV_ARISTOS_MULTIPLUS || recorderType == DEV_SCR_MINITREND) {
				usMaxChannels = CBaseObject::ms_usMAX_MULTITREND_CHART_PENS;
			} else {
				// must be a mini
				usMaxChannels = CBaseObject::ms_usMAX_MINITREND_CHART_PENS;
			}
		} else {
			// should not happen but set to one
			usMaxChannels = 1;
		}
		// assume all widget channels are pens, no mixes of types allowed when displaying chart objects
		T_PWIDGET ptWidget = m_pkWidget->GetCMMWidget();
		CScreen *pkScreen = m_pkWidget->GetScreen();
		USHORT usInstanceNo = 0;
		QString strInstanceNo("");
		for (USHORT usWidgetChanCount = 0; usWidgetChanCount < usMaxChannels; usWidgetChanCount++) {
			// check the number of channels this widget thinks it has is not exceeded - this can happen
			// with older widgets that have been taken from a mini and dropped on a multi
			if (usWidgetChanCount < ptWidget->NumChannels) {
				usInstanceNo = pkScreen->ChannelToInstance(ptWidget->ChannelList[usWidgetChanCount]);
				// check the instance no is okay as it could be uninitialised
				if (usInstanceNo != pkScreen->ms_usUNINITIALISED_INSTANCE) {
					strInstanceNo = QString::asprintf("%u, ", usInstanceNo + 1);
					strData += strInstanceNo;
				}
			}
		}
		// check that at least one instance no is valid
		if (strData != "") {
			// remove the trailing ", "
			strData.remove(strData.size() - 2, 2);
		} else {
			// show the not set string
            strData = QWidget::tr("None Set");
		}
	}
		break;
	case AlarmMrkrObject: {
		ptAlarmMrkr = reinterpret_cast<T_ALARMMRKROBJECT*>(m_ptBaseObject);
		ptObjChanRef = &ptAlarmMrkr->ChannelInfo[0];
	}
		break;
	case ExampleBar:
		break;
	case BitmapObject:
		strData = "None";
		break;
	case TUSObject:
		strData = "None";
		break;
	case NoObject:
		break;
	default:
		break;
	}
	// check we found a valid channel ref data pointer
	if (ptObjChanRef != NULL) {
		// get the type name - this will be something like pen
		strData = GetTypeName(ptObjChanRef->ItemType, ptObjChanRef->SubType);
		strData += L" ";
		// now add the instance number if necessary
		if ((ptObjChanRef->ItemType != DI_IO)
				|| ((ptObjChanRef->SubType != DI_IO_MISC) && (ptObjChanRef->SubType != DI_IO_CJC_MULTI_CHAN))) {
			USHORT usCurrInstance = 0;
			CScreen *pkScreen = m_pkWidget->GetScreen();
			T_PSCREEN ptCMMScreen = pkScreen->GetCMMScreen();
			if (ptObjChanRef->IndexChan < CWidget::ms_usCHANNEL_OFFSET) {
				T_WIDGET *ptWidget = m_pkWidget->GetCMMWidget();
				const USHORT usWIDGET_CHANNEL = ptWidget->ChannelList[ptObjChanRef->IndexChan];
				// the widget channel system is based at CWidget::ms_usCHANNEL_OFFSET therefore minus CWidget::ms_usCHANNEL_OFFSET first
				usCurrInstance = ptCMMScreen->ChannelMap[usWIDGET_CHANNEL - CWidget::ms_usCHANNEL_OFFSET];
			} else {
				// the widget channel system is based at CWidget::ms_usCHANNEL_OFFSET therefore minus CWidget::ms_usCHANNEL_OFFSET first
				usCurrInstance = ptCMMScreen->ChannelMap[ptObjChanRef->IndexChan - CWidget::ms_usCHANNEL_OFFSET];
			}
			QString strInstanceNo("");
			if (usCurrInstance != CScreen::ms_usUNINITIALISED_INSTANCE) {
				strInstanceNo = QString::asprintf("%u", usCurrInstance + 1);
			} else {
                strInstanceNo = QWidget::tr("None Set");
			}
			strData += strInstanceNo;
            strData += " ";
		}
		// Check if this is an alarm marker object
		if (ptAlarmMrkr == NULL) {
			// get the sub type name
			strData += GetSubTypeName(ptObjChanRef->ItemType, ptObjChanRef->SubType);
		} else {
			// the curr alarm subtype can be a number of alarms
			QString strAlarms("");
			QString strAlarm("");
			for (USHORT usCount = 0; usCount < ALARMMRKROBJECT_CHANNELINFO_SIZE; usCount++) {
				// we must now loop through each channel checking if the alarm is enabled
				if (ptAlarmMrkr->ChannelInfo[usCount].Enabled == TRUE) {
					strAlarm = QString::asprintf("%u, ", usCount + 1);
					strAlarms += strAlarm;
				}
			}
			// check if any alarms are activated
			if (strAlarms != "") {
				// delete the remaining , and space
				strAlarms.remove(strAlarms.size() - 2, 2);
			} else {
				// replace with none
                strAlarms = QWidget::tr("None");
			}
            strAlarm = QWidget::tr("Alarm No. %u");
			strAlarm.remove(strAlarm.size() - 2, 2);
			strData += strAlarm + L" " + strAlarms;
		}
	}
	return strData;
}
//****************************************************************************
// const QString   Get GetTypeName(	const USHORT usTYPE,
//									const USHORT usSUB_TYPE )
///
/// Method that gets the type name of an objects current channel configuration
///
/// @param[in]			The channel type of the object
/// @param[in]			The channel subtype of the object
///
/// @return String containing the type name
///
//****************************************************************************
const QString CConfigObjectData::GetTypeName(const USHORT usTYPE, const USHORT usSUB_TYPE) {
	QString strTypeName("");
	// check if IO e.g. digital input/output, pulse, analogue etc
	if (usTYPE == DI_IO) {
		// need to delve further into the type
		// need to check for analogue etc by checking the subtype
		switch (static_cast<T_DATA_ITEM_IO_LIST>(usSUB_TYPE)) {
		case DI_IO_ANALOGUE:
		case DI_IO_ANALOGUE_RAW:
            strTypeName = QWidget::tr("Analog In No.");
			break;
		case DI_IO_RT_COMP:
		case DI_IO_RT_CAL:
			break;
		case DI_IO_DIGITAL:
            strTypeName = QWidget::tr("Dig Input No.");
			break;
		case DI_IO_HIPULSE:
		case DI_IO_LOPULSE:
            strTypeName = QWidget::tr("Pulse Input No.");
			break;
		case DI_IO_MISC:
			break;
		case DI_IO_CJC_MULTI_CHAN:
			break;
		case DI_IO_MAX_TYPES:
			break;
		}
	} else if (usTYPE == DI_COUNTER) {
	} else if (CWidget::IsPenCompatibleType(usTYPE)) {
		// must be pen related
        strTypeName = QWidget::tr("Pen No.");
	}
	return strTypeName;
}
//****************************************************************************
// const QString   Get GetSubTypeName(	const USHORT usTYPE,
//										const USHORT usSUB_TYPE )
///
/// Method that gets the subtype name of an objects current channel configuration
///
/// @param[in]			The channel type of the object
/// @param[in]			The channel subtype of the object
///
/// @return String containing the subtype name
///
//****************************************************************************
const QString CConfigObjectData::GetSubTypeName(const USHORT usTYPE, const USHORT usSUB_TYPE) {
	QString strSubTypeName("");
	// sub types are only relevant to pens and alarms at the moment
	if (usTYPE == DI_MMA) {
		switch (static_cast<T_DATA_ITEM_MMA_TYPES>(usSUB_TYPE)) {
		case DI_MMA_MAX_USER:
            strSubTypeName = QWidget::tr("Max User Def");
			break;
		case DI_MMA_MIN_USER:
            strSubTypeName = QWidget::tr("Min User Def");
			break;
		case DI_MMA_AVE_USER:
            strSubTypeName = QWidget::tr("Avg User Def");
			break;
		}
	} else if (usTYPE == DI_PEN) {
		// must be pen reading so return nothing
	} else if (usTYPE == DI_TOTAL) {
		// must be pen total therefore add the totals title
        strSubTypeName = QWidget::tr("Total");
	} else if (usTYPE == DI_ALARM) {
		// must be pen alarm therefore add the alarm number
		QString strFormatString("");
        strFormatString = QWidget::tr("Alarm No. %u");
		strSubTypeName = QString::asprintf(strFormatString, usSUB_TYPE + 1);
	}
	return strSubTypeName;
}
//****************************************************************************
// const QString   Get GetObjectName()
///
/// Method that returns the objects name
///
/// @return String containing the object name
///
//****************************************************************************
const QString CConfigObjectData::GetObjectName() {
	return m_pkWidget->GetObjectName(m_ptBaseObject);
}

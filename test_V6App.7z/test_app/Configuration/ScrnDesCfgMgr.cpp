/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Configuration System
/// @n Filename:  ScrnDesCfgMgr.cpp
/// @n Description: Implementation for the CScrnDesCfgMgr class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  113  Stability Project 1.108.2.3  7/2/2011 5:01:05 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  112  Stability Project 1.108.2.2  7/1/2011 4:38:54 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  111  Stability Project 1.108.2.1  3/17/2011 3:20:46 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  110  Stability Project 1.108.2.0  2/15/2011 3:03:55 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// **************************************************************************
#include "ScrnDesCfgMgr.h"
#include "ConfigBranch.h"
#include "ConfigItem.h"
#include "ConfigInterface.h"
#include "ConfigData.h"
#include "V6globals.h"
#include "LayoutConfiguration.h"
#include <float.h>
#include "StringUtils.h"
#include "ConfigObjectData.h"
#include <map>
#include "OpPanelIncludes.h"
#include <algorithm>
#include "CannedScrnData.h"
#include "AddScreenData.h"
#include "DeleteScreenData.h"
#include "ConfigItem.h"
#include "LayoutItem.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
std::unique_ptr<CScrnDesCfgMgr> CScrnDesCfgMgr::ms_kConfigSysMgr;
// BASE OBJECT
// Base Object key names
const QString CScrnDesCfgMgr::ms_strLYT_IS_ADV_DRAW_KEY = QString::fromWCharArray(L"ADV_DRAW");
const QString CScrnDesCfgMgr::ms_strLYT_IS_BUFF_KEY = QString::fromWCharArray(L"BUFF");
const QString CScrnDesCfgMgr::ms_strLYT_IS_TRANS_KEY = QString::fromWCharArray(L"TRANS");
const QString CScrnDesCfgMgr::ms_strLYT_ALPHA_BLEND_KEY = QString::fromWCharArray(L"ALPHA");
const QString CScrnDesCfgMgr::ms_strLYT_PRI_DIR_KEY = QString::fromWCharArray(L"PRI_DIR");
const QString CScrnDesCfgMgr::ms_strLYT_IS_PERM_KEY = QString::fromWCharArray(L"PERM");
const QString CScrnDesCfgMgr::ms_strLYT_PERM_VALID_KEY = QString::fromWCharArray(L"PERM_VAL");
const QString CScrnDesCfgMgr::ms_strLYT_IS_BKG_KEY = QString::fromWCharArray(L"BKG");
const QString CScrnDesCfgMgr::ms_strLYT_FORE_COLOUR_KEY = QString::fromWCharArray(L"F_COL");
const QString CScrnDesCfgMgr::ms_strLYT_FIX_FORE_COLOUR_KEY = QString::fromWCharArray(L"FIX_FORE");
const QString CScrnDesCfgMgr::ms_strLYT_BACK_COLOUR_KEY = QString::fromWCharArray(L"B_COL");
const QString CScrnDesCfgMgr::ms_strLYT_FIX_BACK_COLOUR_KEY = QString::fromWCharArray(L"FIX_BCK");
// Common Key Names
const QString CScrnDesCfgMgr::ms_strLYT_ORIENTATION_KEY = QString::fromWCharArray(L"ORIEN");
// Rect Key Names
const QString CScrnDesCfgMgr::ms_strRECT_KEY = QString::fromWCharArray(L"QRect");
const QString CScrnDesCfgMgr::ms_strRECT_LEFT_KEY = QString::fromWCharArray(L"LEFT");
const QString CScrnDesCfgMgr::ms_strRECT_TOP_KEY = QString::fromWCharArray(L"TOP");
const QString CScrnDesCfgMgr::ms_strRECT_RIGHT_KEY = QString::fromWCharArray(L"RIGHT");
const QString CScrnDesCfgMgr::ms_strRECT_BOTTOM_KEY = QString::fromWCharArray(L"BOT");
// Border Key Names
const QString CScrnDesCfgMgr::ms_strBORDER_KEY = QString::fromWCharArray(L"BDR");
const QString CScrnDesCfgMgr::ms_strBORDER_STYLE_KEY = QString::fromWCharArray(L"STYLE");
const QString CScrnDesCfgMgr::ms_strBORDER_WIDTH_KEY = QString::fromWCharArray(L"WIDTH");
const QString CScrnDesCfgMgr::ms_strBORDER_COL_KEY = QString::fromWCharArray(L"COL");
const QString CScrnDesCfgMgr::ms_strBORDER_USED_KEY = QString::fromWCharArray(L"USED");
// Border List Names
QString CScrnDesCfgMgr::ms_strBorderStyleList = "";
QString CScrnDesCfgMgr::ms_strZOrderList = "";
QString CScrnDesCfgMgr::ms_strBufferingList = "";
// Font Key Names
const QString CScrnDesCfgMgr::ms_strFONT_KEY = QString::fromWCharArray(L"FONT");
const QString CScrnDesCfgMgr::ms_strFONT_HEIGHT_KEY = QString::fromWCharArray(L"HGT");
const QString CScrnDesCfgMgr::ms_strFONT_FACE_KEY = QString::fromWCharArray(L"FACE");
const QString CScrnDesCfgMgr::ms_strFONT_QUALITY_KEY = QString::fromWCharArray(L"QUAL");
const QString CScrnDesCfgMgr::ms_strFONT_WEIGHT_KEY = QString::fromWCharArray(L"WGT");
// Font List Names
QString CScrnDesCfgMgr::ms_strFontFaceList = "";
QString CScrnDesCfgMgr::ms_strFontQualityList = "";
QString CScrnDesCfgMgr::ms_strFontWeightList = "";
// Example Bar key names
const QString CScrnDesCfgMgr::ms_strEX_BAR_TITLE_KEY = QString::fromWCharArray(L"EX_BAR");
// Bar Object key names
const QString CScrnDesCfgMgr::ms_strBAR_OBJ_TITLE_KEY = QString::fromWCharArray(L"BAR_OBJ");
const QString CScrnDesCfgMgr::ms_strBAR_TOP_LIMIT_KEY = QString::fromWCharArray(L"BAR_TOP_LIMIT");
const QString CScrnDesCfgMgr::ms_strBAR_BOTTOM_LIMIT_KEY = QString::fromWCharArray(L"BAR_BOTTOM_LIMIT");
const QString CScrnDesCfgMgr::ms_strBAR_GRADFILL_CLR_KEY = QString::fromWCharArray(L"BAR_GRADFILL_CLR");
const QString CScrnDesCfgMgr::ms_strBAR_TYPE_KEY = QString::fromWCharArray(L"BAR_TYPE");
const QString CScrnDesCfgMgr::ms_strBAR_STYLE_KEY = QString::fromWCharArray(L"BAR_STYLE");
const QString CScrnDesCfgMgr::ms_strBAR_LEVELCAP_KEY = QString::fromWCharArray(L"BAR_LEVELCAP");
const QString CScrnDesCfgMgr::ms_strBAR_LEVELCAP_COL_KEY = QString::fromWCharArray(L"BAR_LEVELCAP_COL");
const QString CScrnDesCfgMgr::ms_strBAR_LIMITS_KEY = QString::fromWCharArray(L"BAR_LIMITS");
const QString CScrnDesCfgMgr::ms_strBAR_BASEPOINT_KEY = QString::fromWCharArray(L"BAR_BASEPOINT");
const QString CScrnDesCfgMgr::ms_strBAR_BREAKPONT_AMBER_KEY = QString::fromWCharArray(L"BAR_BREAKPOINT_AMBER");
const QString CScrnDesCfgMgr::ms_strBAR_BREAKPONT_GREEN_KEY = QString::fromWCharArray(L"BAR_BREAKPOINT_GREEN");
const QString CScrnDesCfgMgr::ms_strBAR_BREAKPONT_DYNAMBER_KEY = QString::fromWCharArray(L"BAR_BREAKPOINT_DYNAMBER");
const QString CScrnDesCfgMgr::ms_strBAR_BREAKPONT_DYNGREEN_KEY = QString::fromWCharArray(L"BAR_BREAKPOINT_DYNGREEN");
const QString CScrnDesCfgMgr::ms_strBAR_FIX_ABOVE_CLR_KEY = QString::fromWCharArray(L"BAR_FIX_ABOVE_CLR");
const QString CScrnDesCfgMgr::ms_strBAR_FIX_BELOW_CLR_KEY = QString::fromWCharArray(L"BAR_FIX_BELOW_CLR");
const QString CScrnDesCfgMgr::ms_strBAR_FIX_BOTTOMLIMIT_KEY = QString::fromWCharArray(L"BAR_FIX_BOTTOMLIMIT");
const QString CScrnDesCfgMgr::ms_strBAR_FIX_TOPLIMIT_KEY = QString::fromWCharArray(L"BAR_FIX_TOPLIMIT");
const QString CScrnDesCfgMgr::ms_strBAR_GRAD_START_CLR_KEY = QString::fromWCharArray(L"BAR_GRAD_START_CLR");
const QString CScrnDesCfgMgr::ms_strBAR_GRAD_END_CLR_KEY = QString::fromWCharArray(L"BAR_GRAD_END_CLR");
const QString CScrnDesCfgMgr::ms_strBAR_GRAD_START_END_CLR_KEY = QString::fromWCharArray(L"BAR_GRAD_START_END_CLR");
const QString CScrnDesCfgMgr::ms_strBAR_MRKR_CLR_KEY = QString::fromWCharArray(L"BAR_MRKR_CLR");
const QString CScrnDesCfgMgr::ms_strBAR_RESET_MRKRS_KEY = QString::fromWCharArray(L"BAR_RESET_MRKRS");
const QString CScrnDesCfgMgr::ms_strBAR_SHOW_MN_MRKR_KEY = QString::fromWCharArray(L"BAR_SHOW_MN_MRKR");
const QString CScrnDesCfgMgr::ms_strBAR_SHOW_MX_MRKR_KEY = QString::fromWCharArray(L"BAR_SHOW_MX_MRKR");
const QString CScrnDesCfgMgr::ms_strBAR_SHOW_MXMN_MRKR_KEY = QString::fromWCharArray(L"BAR_SHOW_MXMN_MRKR");
const QString CScrnDesCfgMgr::ms_strBAR_SOLID_BELOW_CLR_KEY = QString::fromWCharArray(L"BAR_SOLID_ABOVECLR");
const QString CScrnDesCfgMgr::ms_strBAR_SOLID_ABOVE_CLR_KEY = QString::fromWCharArray(L"BAR_SOLID_BELOWCLR");
const QString CScrnDesCfgMgr::ms_strBAR_MXMN_MRKR_KEY = QString::fromWCharArray(L"BAR_MXMN_MRKR");
const QString CScrnDesCfgMgr::ms_strBAR_ERR_INDICATOR_KEY = QString::fromWCharArray(L"BAR_ERR_INDICATOR");
const QString CScrnDesCfgMgr::ms_strBAR_OVRNG_CLR1_KEY = QString::fromWCharArray(L"BAR_OVRNG_CLR1");
const QString CScrnDesCfgMgr::ms_strBAR_OVRNG_CLR2_KEY = QString::fromWCharArray(L"BAR_OVRNG_CLR2");
const QString CScrnDesCfgMgr::ms_strBAR_UNDERRNG_CLR1_KEY = QString::fromWCharArray(L"BAR_UNDERRNG_CLR1");
const QString CScrnDesCfgMgr::ms_strBAR_UNDERRNG_CLR2_KEY = QString::fromWCharArray(L"BAR_UNDERRNG_CLR2");
const QString CScrnDesCfgMgr::ms_strBAR_INVALIDRDNG_CLR1_KEY = QString::fromWCharArray(L"BAR_INVALIDRDNG_CLR1");
const QString CScrnDesCfgMgr::ms_strBAR_INVALIDRDNG_CLR2_KEY = QString::fromWCharArray(L"BAR_INVALIDRDNG_CLR2");
const QString CScrnDesCfgMgr::ms_strBAR_UPSC_BURNOUT_CLR1_KEY = QString::fromWCharArray(L"BAR_UPSC_BURNOUT_CLR1");
const QString CScrnDesCfgMgr::ms_strBAR_UPSC_BURNOUT_CLR2_KEY = QString::fromWCharArray(L"BAR_UPSC_BURNOUT_CLR2");
const QString CScrnDesCfgMgr::ms_strBAR_DNSC_BURNOUT_CLR1_KEY = QString::fromWCharArray(L"BAR_DNSC_BURNOUT_CLR1");
const QString CScrnDesCfgMgr::ms_strBAR_DNSC_BURNOUT_CLR2_KEY = QString::fromWCharArray(L"BAR_DNSC_BURNOUT_CLR2");
QString CScrnDesCfgMgr::ms_strOrientationList = "";
QString CScrnDesCfgMgr::ms_strBarStyleListUpDown = "";
QString CScrnDesCfgMgr::ms_strBarStyleListBased = "";
QString CScrnDesCfgMgr::ms_strBarTypeList = "";
QString CScrnDesCfgMgr::ms_strBarGradFillClrList = "";
// PenPointers Object key names
const QString CScrnDesCfgMgr::ms_strPENPOINTERS_OBJ_TITLE_KEY = QString::fromWCharArray(L"PENPOINTERS_OBJ");
const QString CScrnDesCfgMgr::ms_strPENPTRS_FGALARM_COL_KEY = QString::fromWCharArray(L"PENPTRS_FGALARM_COL");
const QString CScrnDesCfgMgr::ms_strPENPTRS_FLASH_FG_ONALARM_KEY = QString::fromWCharArray(L"PENPTRS_FLASH_FG_ONALARM");
const QString CScrnDesCfgMgr::ms_strPENPTRS_FIX_FG_ALARM_COL_KEY = QString::fromWCharArray(L"PENPTRS_FIX_FG_ALARM_COL");
const QString CScrnDesCfgMgr::ms_strPENPTRS_HEIGHT_KEY = QString::fromWCharArray(L"PENPTRS_HEIGHT");
// Tabular display Object key names
const QString CScrnDesCfgMgr::ms_strTAB_DISP_OBJ_TITLE_KEY = QString::fromWCharArray(L"PENPOINTERS_OBJ");
const QString CScrnDesCfgMgr::ms_strTAB_DISP_FGALARM_COL_KEY = QString::fromWCharArray(L"PENPTRS_FGALARM_COL");
const QString CScrnDesCfgMgr::ms_strTAB_DISP_FLASH_FG_ONALARM_KEY = QString::fromWCharArray(
		L"PENPTRS_FLASH_FG_ONALARM");
const QString CScrnDesCfgMgr::ms_strTAB_DISP_FIX_FG_ALARM_COL_KEY = QString::fromWCharArray(
		L"PENPTRS_FIX_FG_ALARM_COL");
// Button Object key names
const QString CScrnDesCfgMgr::ms_strBUTTON_OBJ_TITLE_KEY = QString::fromWCharArray(L"BTN_OBJ");
const QString CScrnDesCfgMgr::ms_strBUTTON_TEXT_TITLE_KEY = QString::fromWCharArray(L"BTN_TXT");
// AlarmMarker Object key names
const QString CScrnDesCfgMgr::ms_strALARMMRKR_OBJ_TITLE_KEY = QString::fromWCharArray(L"ALARMMRKR_OBJ");
const QString CScrnDesCfgMgr::ms_strALARM_INALARM_NOTACK_KEY = QString::fromWCharArray(L"ALARM_INALARM_NOTACK");
const QString CScrnDesCfgMgr::ms_str_ALARM_HEIGHT_KEY = QString::fromWCharArray(L"ALARM_HEIGHT");
const QString CScrnDesCfgMgr::ms_strALARM_INALARM_ACK_KEY = QString::fromWCharArray(L"ALARM_INALARM_ACK");
const QString CScrnDesCfgMgr::ms_strALARM_OUTALARM_NOTACK_KEY = QString::fromWCharArray(L"ALARM_OUTALARM_NOTACK");
const QString CScrnDesCfgMgr::ms_strALARM_HIDE_INACTIVE_ALARM_KEY = QString::fromWCharArray(
		L"ALARM_HIDE_INACTIVE_ALARM");
const QString CScrnDesCfgMgr::ms_strALARM_USE_GLOBAL_FLASHCLR_KEY = QString::fromWCharArray(L"ALARM_GLOBAL_FLASH_CLR");
const QString CScrnDesCfgMgr::ms_strALARM_INALARM_NOACK_FLASHCLR_KEY = QString::fromWCharArray(
		L"ALARM_INAL_NOACK_FLSHCOL");
const QString CScrnDesCfgMgr::ms_strALARM_INALARM_ACK_FLASHCLR_KEY = QString::fromWCharArray(L"ALARM_INAL_ACK_FLSHCOL");
const QString CScrnDesCfgMgr::ms_strALARM_OUTALARM_NOACK_FLASHCLR_KEY = QString::fromWCharArray(
		L"ALARM_OUTAL_NOACK_FLSHCOL");
const QString CScrnDesCfgMgr::ms_strALARM_OUTALARM_FLASHCLR_KEY = QString::fromWCharArray(L"ALARM_OUTAL_FLSHCOL");
// Scale Object key names
const QString CScrnDesCfgMgr::ms_strSCALE_OBJ_TITLE_KEY = QString::fromWCharArray(L"SCALE_OBJ");
const QString CScrnDesCfgMgr::ms_strSCALE_AUTO_SCALE_KEY = QString::fromWCharArray(L"SCALE_AUTO_SCALE");
const QString CScrnDesCfgMgr::ms_strSCALE_BASELINE_COL_KEY = QString::fromWCharArray(L"SCALE_BASELINE_COL");
const QString CScrnDesCfgMgr::ms_strSCALE_BASELINE_KEY = QString::fromWCharArray(L"SCALE_BASELINE");
const QString CScrnDesCfgMgr::ms_strSCALE_FULLWIDTH_KEY = QString::fromWCharArray(L"SCALE_FULLWIDTH");
const QString CScrnDesCfgMgr::ms_strSCALE_GRADS_COL_KEY = QString::fromWCharArray(L"SCALE_GRADS_COL");
const QString CScrnDesCfgMgr::ms_strSCALE_GRADS_DIR_KEY = QString::fromWCharArray(L"SCALE_GRADS_DIR");
const QString CScrnDesCfgMgr::ms_strSCALE_LABEL_LIMITS_KEY = QString::fromWCharArray(L"SCALE_LABEL_LIMITS");
const QString CScrnDesCfgMgr::ms_strSCALE_LABEL_MAJORS_KEY = QString::fromWCharArray(L"SCALE_LABEL_MAJORS");
const QString CScrnDesCfgMgr::ms_strSCALE_LABEL_POSITION_KEY = QString::fromWCharArray(L"SCALE_LABEL_POSITION");
const QString CScrnDesCfgMgr::ms_strSCALE_LABELS_KEY = QString::fromWCharArray(L"SCALE_LABELS");
const QString CScrnDesCfgMgr::ms_strSCALE_LEFT_JUSTIFY_KEY = QString::fromWCharArray(L"SCALE_LEFT_JUSTIF");
const QString CScrnDesCfgMgr::ms_strSCALE_MAJOR_GRADS_KEY = QString::fromWCharArray(L"SCALE_MAJOR_GRADS");
const QString CScrnDesCfgMgr::ms_strSCALE_MAJOR_LENGTH_KEY = QString::fromWCharArray(L"SCALE_MAJOR_LENGTH");
const QString CScrnDesCfgMgr::ms_strSCALE_MINOR_GRADS_KEY = QString::fromWCharArray(L"SCALE_MINOR_GRADS");
const QString CScrnDesCfgMgr::ms_strSCALE_MINOR_LENGTH_KEY = QString::fromWCharArray(L"SCALE_MINOR_LENGTH");
const QString CScrnDesCfgMgr::ms_strSCALE_LIMIT_FONT_HEIGHT_KEY = QString::fromWCharArray(L"L_FONT");
const QString CScrnDesCfgMgr::ms_strSCALE_MAJOR_FONT_HEIGHT_KEY = QString::fromWCharArray(L"M_FONT");
const QString CScrnDesCfgMgr::ms_strSCALE_FIXGRADS_CLR_KEY = QString::fromWCharArray(L"SCALE_FIXGRADS_CLR");
const QString CScrnDesCfgMgr::ms_strSCALE_GRADS_CLR_KEY = QString::fromWCharArray(L"SCALE_GRADS_CLR");
const QString CScrnDesCfgMgr::ms_strSCALE_FIXBASELINE_CLR_KEY = QString::fromWCharArray(L"SCALE_FIXBASELINE_CLR");
const QString CScrnDesCfgMgr::ms_strSCALE_BASELINE_CLR_KEY = QString::fromWCharArray(L"SCALE_BASELINE_CLR");
const QString CScrnDesCfgMgr::ms_strSCALE_FIX_NUMFORMAT_KEY = QString::fromWCharArray(L"SCALE_FIX_NUMFORMAT");
QString CScrnDesCfgMgr::ms_strScaleUpDownList = "";
QString CScrnDesCfgMgr::ms_strScaleleftrightList = "";
QString CScrnDesCfgMgr::ms_strScaleTopBottomList = "";
QString CScrnDesCfgMgr::ms_strScalerightleftList = "";
//Digital
const QString CScrnDesCfgMgr::ms_strDIGITAL_OBJ_TITLE_KEY = QString::fromWCharArray(L"DIGITAL_OBJ");
const QString CScrnDesCfgMgr::ms_strDIGITAL_FLASH_FG_ONALARM_KEY = QString::fromWCharArray(L"DIGITAL_FLASH_FG_ONALARM");
const QString CScrnDesCfgMgr::ms_strDIGITAL_FLASH_BG_ONALARM_KEY = QString::fromWCharArray(L"DIGITAL_FLASH_BG_ONALARM");
const QString CScrnDesCfgMgr::ms_strDIGITAL_FIX_NUMFORMAT_KEY = QString::fromWCharArray(L"DIGITAL_FIX_NUMFORMAT");
const QString CScrnDesCfgMgr::ms_strDIGITAL_CHG_FG_ONALARM_KEY = QString::fromWCharArray(L"DIGITAL_CHG_FG_ONALARM");
const QString CScrnDesCfgMgr::ms_strDIGITAL_FG_ALARM_COL_KEY = QString::fromWCharArray(L"DIGITAL_FG_ALARM_COL");
const QString CScrnDesCfgMgr::ms_strDIGITAL_ENABLE_ALARM_KEY = QString::fromWCharArray(L"DIGITAL_ENABLE_ALARM");
//Text
const QString CScrnDesCfgMgr::ms_strTEXT_OBJ_TITLE_KEY = QString::fromWCharArray(L"TEXT_OBJ");
const QString CScrnDesCfgMgr::ms_strTEXT_FIXTEXT_KEY = QString::fromWCharArray(L"TEXT_FIXTEXT");
const QString CScrnDesCfgMgr::ms_strTEXT_WORDWRAP_KEY = QString::fromWCharArray(L"TEXT_WORDWRAP");
const QString CScrnDesCfgMgr::ms_strTEXT_ISTAG_KEY = QString::fromWCharArray(L"TEXT_ISTAG");
const QString CScrnDesCfgMgr::ms_strTEXT_ISDESC_KEY = QString::fromWCharArray(L"TEXT_ISDESC");
const QString CScrnDesCfgMgr::ms_strTEXT_ISUNITS_KEY = QString::fromWCharArray(L"TEXT_ISUNITS");
const QString CScrnDesCfgMgr::ms_strTEXT_CENTER_KEY = QString::fromWCharArray(L"TEXT_CENTER");
const QString CScrnDesCfgMgr::ms_strTEXT_OFFSET_KEY = QString::fromWCharArray(L"TEXT_OFFSET");
const QString CScrnDesCfgMgr::ms_strTEXT_FIX_TEXT_KEY = QString::fromWCharArray(L"FIX_TEXT");
// Widget Key Names
const QString CScrnDesCfgMgr::ms_strWIDGET_TITLE_KEY = QString::fromWCharArray(L"WDGT");
const QString CScrnDesCfgMgr::ms_strWIDGET_NAME_KEY = QString::fromWCharArray(L"NAME");
const QString CScrnDesCfgMgr::ms_strWIDGET_CATEGORY_KEY = QString::fromWCharArray(L"CATEGORY");
const QString CScrnDesCfgMgr::ms_strWIDGET_TYPE_KEY = QString::fromWCharArray(L"TYPE");
const QString CScrnDesCfgMgr::ms_strWIDGET_CHANNELS_KEY = QString::fromWCharArray(L"CHAN");
const QString CScrnDesCfgMgr::ms_strWIDGET_PARENT_CHAN_KEY = QString::fromWCharArray(L"PARENT");
// Template Key Names
const QString CScrnDesCfgMgr::ms_strTEMPLATE_TITLE_KEY = QString::fromWCharArray(L"TEMPLATE");
const QString CScrnDesCfgMgr::ms_strTEMPLATE_NAME_KEY = QString::fromWCharArray(L"NAME");
const QString CScrnDesCfgMgr::ms_strTEMPLATE_STATUS_BAR_KEY = QString::fromWCharArray(L"STATUS_BAR");
const QString CScrnDesCfgMgr::ms_strTEMPLATE_REPLAY_ORIENTATION_KEY = QString::fromWCharArray(L"REPLAY_ORIENTATION");
// Screen Key Names
const QString CScrnDesCfgMgr::ms_strSCREEN_TITLE_KEY = QString::fromWCharArray(L"SCRN");
const QString CScrnDesCfgMgr::ms_strSCREEN_NAME_KEY = QString::fromWCharArray(L"NAME");
const QString CScrnDesCfgMgr::ms_strSCREEN_ENABLED_KEY = QString::fromWCharArray(L"EN");
const QString CScrnDesCfgMgr::ms_strSCREEN_TYPE_KEY = QString::fromWCharArray(L"TYPE");
const QString CScrnDesCfgMgr::ms_strSCREEN_VERTICAL_BARS_KEY = QString::fromWCharArray(L"V_BAR");
const QString CScrnDesCfgMgr::ms_strSCREEN_ROTATE_BARS_KEY = QString::fromWCharArray(L"R_BAR");
const QString CScrnDesCfgMgr::ms_strSCREEN_POINTER_KEY = QString::fromWCharArray(L"P_OR_B");
const QString CScrnDesCfgMgr::ms_strSCREEN_ROTATE_SCREEN_KEY = QString::fromWCharArray(L"ROT_S");
const QString CScrnDesCfgMgr::ms_strSCREEN_USE_TEMPLATE_BKG_COL_KEY = QString::fromWCharArray(L"TMP");
const QString CScrnDesCfgMgr::ms_strSCREEN_BKG_COL_KEY = QString::fromWCharArray(L"BKG");
const QString CScrnDesCfgMgr::ms_strSCREEN_CANNED_PENS_SETUP_KEY = QString::fromWCharArray(L"CAN");
const QString CScrnDesCfgMgr::ms_strSCREEN_ADD_SCREEN_KEY = QString::fromWCharArray(L"ADD");
const QString CScrnDesCfgMgr::ms_strSCREEN_DELETE_SCREEN_KEY = QString::fromWCharArray(L"DEL");
const QString CScrnDesCfgMgr::ms_strSCREEN_USE_GROUP_KEY = QString::fromWCharArray(L"USE_GRP");
const QString CScrnDesCfgMgr::ms_strSCREEN_GROUP_SEL_KEY = QString::fromWCharArray(L"GRP_NO");
const QString CScrnDesCfgMgr::ms_strSCREEN_GROUP_USE_MAX_MINS_KEY = QString::fromWCharArray(L"MAX_MIN");
const QString CScrnDesCfgMgr::ms_strSCREEN_GROUP_USE_TOTALS_KEY = QString::fromWCharArray(L"TOTALS");
const QString CScrnDesCfgMgr::ms_strSCREEN_GROUP_USE_SCALES_KEY = QString::fromWCharArray(L"SCALES");
const QString CScrnDesCfgMgr::ms_strSCREEN_REPLAY_PENS_SETUP_KEY = QString::fromWCharArray(L"REP_PEN");
// Screen List Names
QString CScrnDesCfgMgr::ms_strScreenUseGroupList = "";
QString CScrnDesCfgMgr::ms_strGroupList = "";
// Screen Lists
QString CScrnDesCfgMgr::ms_strScreenTypeList = "";
QString CScrnDesCfgMgr::ms_strNPScreenTypeList = "";
QString CScrnDesCfgMgr::ms_strNPMSGScreenTypeList = "";
QString CScrnDesCfgMgr::ms_strScreenOrientationList = "";
QString CScrnDesCfgMgr::ms_strScreenScaleIndicatorList = "";
QString CScrnDesCfgMgr::ms_strCustomScreenTypeList = "";
QString CScrnDesCfgMgr::ms_strCustomMsgScreenTypeList = "";
// Chart Object Key Names
const QString CScrnDesCfgMgr::ms_strCHART_OBJ_TITLE_KEY = QString::fromWCharArray(L"TITLE");
// Circular Chart Object Key Names
const QString CScrnDesCfgMgr::ms_strCIRC_CHART_OBJ_TITLE_KEY = QString::fromWCharArray(L"CCHRT");
// Strip and Circular Chart Object Key Names
const QString CScrnDesCfgMgr::ms_strCHART_OBJ_FIX_ALARM_COL_KEY = QString::fromWCharArray(L"F_ALM");
const QString CScrnDesCfgMgr::ms_strCHART_OBJ_ALARM_COL_KEY = QString::fromWCharArray(L"ALM_COL");
const QString CScrnDesCfgMgr::ms_strCHART_OBJ_FIX_MESSAGE_COL_KEY = QString::fromWCharArray(L"F_MSG");
const QString CScrnDesCfgMgr::ms_strCHART_OBJ_MESSAGE_COL_KEY = QString::fromWCharArray(L"MSG_COL");
const QString CScrnDesCfgMgr::ms_strCHART_OBJ_FIX_FONT_COL_KEY = QString::fromWCharArray(L"F_FONT");
const QString CScrnDesCfgMgr::ms_strCHART_OBJ_FONT_COL_KEY = QString::fromWCharArray(L"FONT_COL");
const QString CScrnDesCfgMgr::ms_strCHART_OBJ_CHART_SPEED_KEY = QString::fromWCharArray(L"SPD");
// Chart Object List Names
QString CScrnDesCfgMgr::ms_strChartObjChartSpeedList = "";
// Layout Settings Key Names
const QString CScrnDesCfgMgr::ms_strSETTINGS_KEY = QString::fromWCharArray(L"SET");
const QString CScrnDesCfgMgr::ms_strSETTINGS_ROTATE_ENABLED_KEY = QString::fromWCharArray(L"ROT_EN");
const QString CScrnDesCfgMgr::ms_strSETTINGS_ROTATE_SCREENS_KEY = QString::fromWCharArray(L"ROT_SCR");
const QString CScrnDesCfgMgr::ms_strSETTINGS_ROTATE_INTERVAL_KEY = QString::fromWCharArray(L"ROT_INT");
const QString CScrnDesCfgMgr::ms_strSETTINGS_MANUAL_INTERVENTION_KEY = QString::fromWCharArray(L"MAN_INT");
const QString CScrnDesCfgMgr::ms_strSETTINGS_ALARM_SCREEN_ENABLED_KEY = QString::fromWCharArray(L"ALM_SCR_EN");
const QString CScrnDesCfgMgr::ms_strSETTINGS_ALARM_SCREEN_NAME_KEY = QString::fromWCharArray(L"ALM_SCR_NAME");
const QString CScrnDesCfgMgr::ms_strSETTINGS_REPLAY_SCREEN_TIMEOUT_EN_KEY = QString::fromWCharArray(L"RPL_T_EN");
const QString CScrnDesCfgMgr::ms_strSETTINGS_REPLAY_SCREEN_TIMEOUT_KEY = QString::fromWCharArray(L"RPLY_TIME");
const QString CScrnDesCfgMgr::ms_strSETTINGS_HIDE_STATUS_BAR_KEY = QString::fromWCharArray(L"HIDE_SB");
const QString CScrnDesCfgMgr::ms_strSETTINGS_HIDE_STATUS_BAR_TIMEOUT_KEY = QString::fromWCharArray(L"SB_TO");
const QString CScrnDesCfgMgr::ms_strSETTINGS_HOUR_TIMESTAMPS_KEY = QString::fromWCharArray(L"HOUR_STAMP");
//const QString   CScrnDesCfgMgr::ms_strSETTINGS_SHOW_NONPROCESSSCREEN_KEY = QString   ::fromWCharArray(L"NPS_EN");
//added by nilesh for Displaying Chart Start/Stop Messages
//[
const QString CScrnDesCfgMgr::ms_strSETTINGS_SHOW_START_STOP_MESSAGES_KEY = QString::fromWCharArray(L"START_STOP");
//]
const QString CScrnDesCfgMgr::ms_strHOTBUTTON_TITLE_KEY = QString::fromWCharArray(L"HOT_BTN");
const QString CScrnDesCfgMgr::ms_strHOTBUTTON_NAME_KEY = QString::fromWCharArray(L"HB_NAME");
const QString CScrnDesCfgMgr::ms_strHOTBUTTON_ENABLED_KEY = QString::fromWCharArray(L"HB_EN");
// Layout Appearance Key Names
const QString CScrnDesCfgMgr::ms_strAPPEARANCE_KEY = QString::fromWCharArray(L"APPEAR");
const QString CScrnDesCfgMgr::ms_strAPPEARANCE_ALM_IN_NACK_FCOL_KEY = QString::fromWCharArray(L"ALM_IN_NA_F");
const QString CScrnDesCfgMgr::ms_strAPPEARANCE_ALM_IN_NACK_BCOL_KEY = QString::fromWCharArray(L"ALM_IN_NA_B");
const QString CScrnDesCfgMgr::ms_strAPPEARANCE_ALM_IN_ACK_FCOL_KEY = QString::fromWCharArray(L"ALM_IN_A_F");
const QString CScrnDesCfgMgr::ms_strAPPEARANCE_ALM_IN_ACK_BCOL_KEY = QString::fromWCharArray(L"ALM_IN_A_B");
const QString CScrnDesCfgMgr::ms_strAPPEARANCE_ALM_OUT_NACK_FCOL_KEY = QString::fromWCharArray(L"ALM_OUT_NA_F");
const QString CScrnDesCfgMgr::ms_strAPPEARANCE_ALM_OUT_NACK_BCOL_KEY = QString::fromWCharArray(L"ALM_OUT_NA_B");
const QString CScrnDesCfgMgr::ms_strAPPEARANCE_ALM_OUT_FCOL_KEY = QString::fromWCharArray(L"ALM_OUT_F");
const QString CScrnDesCfgMgr::ms_strAPPEARANCE_ALM_OUT_BCOL_KEY = QString::fromWCharArray(L"ALM_OUT_B");
const QString CScrnDesCfgMgr::ms_strAPPEARANCE_ALM_OVERVIEW_FCOL_KEY = QString::fromWCharArray(L"ALM_OV_F");
const QString CScrnDesCfgMgr::ms_strAPPEARANCE_ALM_OVERVIEW_BCOL_KEY = QString::fromWCharArray(L"ALM_OV_B");
const QString CScrnDesCfgMgr::ms_strAPPEARANCE_CHART_NORMAL_FCOL_KEY = QString::fromWCharArray(L"CHT_NORM_F");
const QString CScrnDesCfgMgr::ms_strAPPEARANCE_CHART_NORMAL_BCOL_KEY = QString::fromWCharArray(L"CHT_NORM_B");
const QString CScrnDesCfgMgr::ms_strAPPEARANCE_CHART_ALM_NORMAL_FCOL_KEY = QString::fromWCharArray(L"CHT_N_ALM_F");
const QString CScrnDesCfgMgr::ms_strAPPEARANCE_CHART_ALM_NORMAL_BCOL_KEY = QString::fromWCharArray(L"CHT_N_ALM_B");
const QString CScrnDesCfgMgr::ms_strAPPEARANCE_CHART_REPLAY_FCOL_KEY = QString::fromWCharArray(L"CHT_RPL_F");
const QString CScrnDesCfgMgr::ms_strAPPEARANCE_CHART_REPLAY_BCOL_KEY = QString::fromWCharArray(L"CHT_RPL_B");
const QString CScrnDesCfgMgr::ms_strAPPEARANCE_CHART_ALM_REPLAY_FCOL_KEY = QString::fromWCharArray(L"CHT_R_ALM_F");
const QString CScrnDesCfgMgr::ms_strAPPEARANCE_CHART_ALM_REPLAY_BCOL_KEY = QString::fromWCharArray(L"CHT_R_ALM_B");
const QString CScrnDesCfgMgr::ms_strAPPEARANCE_CHART_TEXT_FCOL_KEY = QString::fromWCharArray(L"CHT_TXT_F");
const QString CScrnDesCfgMgr::ms_strAPPEARANCE_CHART_TEXT_BCOL_KEY = QString::fromWCharArray(L"CHT_TXT_B");
// Layout Settings Lists
QString CScrnDesCfgMgr::ms_strScreenList = "";
//Aditya - Non process screens shouldn't be there for SD , but should be there for Recorder.
bool CScrnDesCfgMgr::m_bIsScreenDesigner = false;
//****************************************************************************
// CScrnDesCfgMgr(void)
///
/// Constructor
///
//****************************************************************************
CScrnDesCfgMgr::CScrnDesCfgMgr(void) : CBaseCfgMgr(CBaseCfgMgr::ctLayout) {
#ifndef DOCVIEW
	m_ModuleMessageManagerClient.MMMClientRegister(MODULE_LAYOUT_CFG_MGR, MODULE_SEND_ONLY, CAMQ_QUEUE_WRAP_DISABLED);
#endif
	LoadStrings();
}
//****************************************************************************
// ~CScrnDesCfgMgr(void)
///
/// Destructor
///
//****************************************************************************
CScrnDesCfgMgr::~CScrnDesCfgMgr(void) {
}
//****************************************************************************
// CScrnDesCfgMgr* Instance()
///
/// Singleton Accessor/Creator
///
/// @return A pointer to the singleton instance of the class
/// 
//****************************************************************************
CScrnDesCfgMgr* CScrnDesCfgMgr::Instance() {
	// check if the pointer exists yet
	if (ms_kConfigSysMgr.get() == NULL) {
		// not been created yet therefore create one now
		std::unique_ptr<CScrnDesCfgMgr> kNewConfigSysMgr(new CScrnDesCfgMgr);
		ms_kConfigSysMgr = kNewConfigSysMgr;
	}
	return ms_kConfigSysMgr.get();
}
//****************************************************************************
// void LoadStrings()
///
/// Static method that loads the titles
/// 
//****************************************************************************
void CScrnDesCfgMgr::LoadStrings() {
	CBaseCfgMgr::LoadStrings();
	// BASE OBJECT List Names
	ms_strBufferingList = tr("Unbuffered|Double Buffered|");
	ms_strZOrderList = tr("Background|Foreground|");
	ms_strBorderStyleList = tr("Flat|Raised|Inset|");
	ms_strFontFaceList = tr("Arial|Times New Roman|Courier New|Tahoma|");
	ms_strFontQualityList = tr("Default|Antialiased|Cleartype|");
	ms_strFontWeightList = tr("Normal|Medium|Semi-Bold|Bold|");
	ms_strOrientationList = tr("Horizontal|Vertical|");
	ms_strBarStyleListUpDown = tr("Solid|Fade|Dynamic|Traffic Light|");
	ms_strBarStyleListBased = tr("Solid|Fade|Dynamic|");
	ms_strBarTypeList = tr("None|Up|Down|Based|");
	ms_strBarGradFillClrList = tr("Grey|Red|Blue|Green|Magenta|Cyan|Yellow|");
	ms_strScaleUpDownList = tr("Up|Down|");
	ms_strScaleleftrightList = tr("left|right|");
	ms_strScaleTopBottomList = tr("Top|Bottom|");
	ms_strScalerightleftList = tr("right|left|");
	ms_strScreenTypeList =
			tr(
					"DPMs|DPMs and Bars|Chart and DPMs|Chart and Scales|Chart, DPMs and Scales|Tabular|AMS2750 Process|AMS2750 TUS|Circular Chart and DPMs|");
	ms_strNPScreenTypeList = tr("Alarms|MaxMin|User Variables|Script Timers|User Counters|Status|Totals|Messages|");
	ms_strNPMSGScreenTypeList = tr("All|Alarms|System|Diagnostics|Security|User|");
	ms_strScreenOrientationList = tr("Horizontal|Vertical|");
	ms_strScreenScaleIndicatorList = tr("Bars|Pointers|");
	ms_strChartObjChartSpeedList = tr("Fast|Medium|Slow|");
	ms_strScreenUseGroupList = tr("Pen|Group|");
}
//****************************************************************************
// CConfigInterface *CreateBasePropsConfigData(	T_BASEOBJECT* pkBaseObject, 
//													CConfigBranch *pkParent,
//													const bool bINCLUDE_TRANSPARENCY /* = true */ )
///
/// Method that creates the base object properties config hierarchy
///
/// @param[in]		T_BASEOBJECT* pkBaseObject - pointer to the base object data
/// @param[in]		CConfigBranch *pkParent - pointer to the parent config branch
/// @param[in]		const bool bINCLUDE_TRANSPARENCY - FLag indicating if the transparency
///					field should be included
/// @param[in]		const bool bINCLUDE_COLOURS - FG or BG colours included
///
//****************************************************************************
void CScrnDesCfgMgr::CreateBasePropsConfigData(T_BASEOBJECT *pkBaseObject, CConfigBranch *pkParent,
		const bool bINCLUDE_TRANSPARENCY, /* = true */
		const bool bINCLUDE_COLOURS /* = true */) {
	QString strTitle("");
	QString strSubTitle("");
	// need to draw the buffering information first - check if this is an advanced draw object as this requires different 
	// properties
	if (!pkBaseObject->IsAdvancedDraw) {
		// Standard draw
		bool bBufferingEnabled = true;
		// Before we add the properties to the parent we need to check if the alpha-blending or
		// transparency flags are set in which case we require double buffering
		if (pkBaseObject->IsAlphaBlend || pkBaseObject->IsTransparent) {
			// change to double buffering
			pkBaseObject->IsBuffered = lbtDoubleBuffered;
			// disable the control too so the user cannot change it
			bBufferingEnabled = false;
		}
		// Add the buffered bitfield
		CShortBitFieldData *pkIsBuffData = new CShortBitFieldData(reinterpret_cast<USHORT*>(pkBaseObject), 1, 2,
				ms_strBufferingList, bfeSingleSelList, 0, IDS_ISBUF_DESCR, false);
		strSubTitle = pkIsBuffData->GetDataAsString();
		strTitle = tr("Buffering");
		CConfigItem *pkIsBuff = new CConfigItem(ms_strLYT_IS_BUFF_KEY, strTitle, strSubTitle, ctItemButton,
				pkIsBuffData, false, bBufferingEnabled, 0, false, pkParent);
		pkParent->AddChild(pkIsBuff);
	} else {
		// Advanced draw 
		/*
		 // Add the primary direct bitfield
		 CShortBitFieldData *pkIsPriDirData = new CShortBitFieldData(	reinterpret_cast< USHORT* >( pkBaseObject ),
		 1,
		 5,
		 ms_strEnabledList,
		 bfeBool,
		 0,
		 IDS_ISPRIMDIR_DESCR,
		 false );
		 strSubTitle = CStringUtils::GetItemAtPos( ms_strEnabledList, pkBaseObject->IsPrimaryDirect );
		 strTitle = tr("Direct Primary");
		 CConfigItem *pkIsPriDir = new CConfigItem(	ms_strLYT_PRI_DIR_KEY,
		 strTitle,
		 strSubTitle,						
		 ctItemButton,
		 pkIsPriDirData,
		 false,
		 true,
		 0,
		 false,
		 pkParent );
		 pkParent->AddChild( pkIsPriDir );
		 // Add the is permament bitfield
		 CShortBitFieldData *pkIsPermData = new CShortBitFieldData(	reinterpret_cast< USHORT* >( pkBaseObject ),
		 1,
		 6,
		 ms_strEnabledList,
		 bfeBool,
		 0,
		 IDS_ISPERM_DESCR,
		 true );
		 strSubTitle = CStringUtils::GetItemAtPos( ms_strEnabledList, pkBaseObject->IsPermanent );
		 strTitle = tr("No Overlay");
		 CConfigItem *pkIsPerm = new CConfigItem(	ms_strLYT_IS_PERM_KEY,
		 strTitle,
		 strSubTitle,						
		 ctItemButton,
		 pkIsPermData,
		 false,
		 true,
		 0,
		 false,
		 pkParent );
		 pkParent->AddChild( pkIsPerm );
		 // Add the is background bitfield
		 CShortBitFieldData *pkIsBkgData = new CShortBitFieldData(	reinterpret_cast< USHORT* >( pkBaseObject ),
		 1,
		 8,
		 ms_strZOrderList,
		 bfeSingleSelList,
		 0,
		 IDS_ISBKGRND_DESCR,
		 false );
		 strSubTitle = pkIsBkgData->GetDataAsString();
		 strTitle = tr("Z-Order");
		 CConfigItem *pkIsBkg = new CConfigItem(	ms_strLYT_IS_BKG_KEY,
		 strTitle,
		 strSubTitle,						
		 ctItemButton,
		 pkIsBkgData,
		 false,
		 ( pkBaseObject->IsPermanent == TRUE ),
		 0,
		 false,
		 pkParent );
		 pkParent->AddChild( pkIsBkg );
		 */
	}
	if (bINCLUDE_TRANSPARENCY) {
		// Add the transparent bitfield
		CShortBitFieldData *pkIsTransData = new CShortBitFieldData(reinterpret_cast<USHORT*>(pkBaseObject), 1, 3,
				ms_strEnabledList, bfeBool, 0, IDS_ISTRNSP_DESCR, true);
		strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, pkBaseObject->IsTransparent);
		strTitle = tr("Transparency");
		CConfigItem *pkIsTrans = new CConfigItem(ms_strLYT_IS_TRANS_KEY, strTitle, strSubTitle, ctItemButton,
				pkIsTransData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkIsTrans);
	}
	// Add the alpha blending bitfield
	CShortBitFieldData *pkIsAlphaData = new CShortBitFieldData(reinterpret_cast<USHORT*>(pkBaseObject), 1, 4,
			ms_strEnabledList, bfeBool, 0, IDS_ISALPBLEND_DESCR, true);
	strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, pkBaseObject->IsAlphaBlend);
	strTitle = tr("Alpha Blending");
	CConfigItem *pkIsAlpha = new CConfigItem(ms_strLYT_ALPHA_BLEND_KEY, strTitle, strSubTitle, ctItemButton,
			pkIsAlphaData, false, true, 0, false, pkParent);
	pkParent->AddChild(pkIsAlpha);
	if (bINCLUDE_COLOURS) {
		// Add the fix foreground colour flag
		CBoolData *pkFixForeColourData = new CBoolData(&pkBaseObject->FixForeColour, 0, IDS_FIXFORECLR_DESCR, true);
		strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, pkBaseObject->FixForeColour);
		strTitle = tr("Fix Foreground Color");
		CConfigItem *pkFixForeColour = new CConfigItem(ms_strLYT_FIX_FORE_COLOUR_KEY, strTitle, strSubTitle,
				ctItemButton, pkFixForeColourData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkFixForeColour);
		// check if the foreground colour is fixed
		if (pkBaseObject->FixForeColour == TRUE) {
			// Add the foreground colour - this is a ULONG
			CULongData *pkForeColData = new CULongData(&pkBaseObject->ForeColour, 0, ms_ulMaxColour, 0,
					IDS_FORECLR_DESCR, false, dtColour);
			strSubTitle = pkForeColData->GetDataAsString();
			strTitle = tr("Foreground Color");
			CConfigItem *pkForeCol = new CConfigItem(ms_strLYT_FORE_COLOUR_KEY, strTitle, strSubTitle, ctItemButton,
					pkForeColData, false, true, 0, false, pkParent);
			pkParent->AddChild(pkForeCol);
		}
		// Add the fix background colour flag
		CBoolData *pkFixBackColourData = new CBoolData(&pkBaseObject->FixBackColour, 0, IDS_FIXBKCLR_DESCR, true);
		strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, pkBaseObject->FixBackColour);
		strTitle = tr("Fix BackColor");
		CConfigItem *pkFixBackColour = new CConfigItem(ms_strLYT_FIX_BACK_COLOUR_KEY, strTitle, strSubTitle,
				ctItemButton, pkFixBackColourData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkFixBackColour);
		// check if the background colour is fixed
		if (pkBaseObject->FixBackColour == TRUE) {
			// Add the background colour - this is a ULONG
			CULongData *pkBkgColData = new CULongData(&pkBaseObject->BackColour, 0, ms_ulMaxColour, 0,
					IDS_BACKCLR_DESCR, false, dtColour);
			strSubTitle = pkBkgColData->GetDataAsString();
			strTitle = tr("Background Color");
			CConfigItem *pkBkgCol = new CConfigItem(ms_strLYT_BACK_COLOUR_KEY, strTitle, strSubTitle, ctItemButton,
					pkBkgColData, false, true, 0, false, pkParent);
			pkParent->AddChild(pkBkgCol);
		}
	}
}
//****************************************************************************
// CConfigInterface *CreateBaseSubMenuPropsConfigData( T_BASEOBJECT* pkBaseObject, 
//														CConfigBranch *pkParent )
///
/// Method that creates a base object submenu properties config hierarchy
///
/// @param[in]		T_BASEOBJECT* pkBaseObject - pointer to the base object data
/// @param[in]		CConfigBranch *pkParent - pointer to the parent config branch
///
//****************************************************************************
void CScrnDesCfgMgr::CreateBaseSubMenuPropsConfigData(T_BASEOBJECT *pkBaseObject, CConfigBranch *pkParent) {
	// Add the TV_RECT details
	SetupRectDetails(&pkBaseObject->Bounds, pkParent);
	// Add the BORDER details
	SetupBorderDetails(&pkBaseObject->Border, pkParent);
}
//****************************************************************************
// void SetupRectDetails( T_TV_RECT *ptRect, CConfigBranch *pkParent )
///
/// Method that creates and adds a TV_RECT heirarchy to a branch
///
/// @param[in]		TV_RECT *ptRect - pointer to the TV_RECT data
/// @param[in]		CConfigBranch *pkParent - pointer to the parent config branch
///
//****************************************************************************
void CScrnDesCfgMgr::SetupRectDetails(T_TV_RECT *ptRect, CConfigBranch *pkParent) {
	// Create the submenu button then add the individual buttons
	QString strSubTitle("");
	QString strBounds("");
	strBounds = tr("Rect Dimensions");
	strSubTitle = QString::asprintf("%d, %d - %d, %d", ptRect->left, ptRect->top, ptRect->right, ptRect->bottom);
	CConfigBranch *pkRectParent = new CConfigBranch(ms_strRECT_KEY, strBounds, strSubTitle, ctSubMenuButton, false,
			true, 0, false, pkParent);
	pkParent->AddChild(pkRectParent);
	// Create the left data item
	CLongData *pkleftData = new CLongData(&ptRect->left, 0, LONG_MAX, 0, IDS_FRAMELEFT_DESCR, true);
	QString strleft("");
	strleft = tr("left");
	CConfigItem *pkleft = new CConfigItem(ms_strRECT_LEFT_KEY, strleft, pkleftData->GetDataAsString(), ctItemButton,
			pkleftData, false, true, 0, false, pkRectParent);
	pkRectParent->AddChild(pkleft);
	// Create the top data item
	CLongData *pkTopData = new CLongData(&ptRect->top, 0, LONG_MAX, 0, IDS_FRAMETOP_DESCR, true);
	QString strTop("");
	strTop = tr("Top");
	CConfigItem *pkTop = new CConfigItem(ms_strRECT_TOP_KEY, strTop, pkTopData->GetDataAsString(), ctItemButton,
			pkTopData, false, true, 0, false, pkRectParent);
	pkRectParent->AddChild(pkTop);
	// Create the right data item
	CLongData *pkrightData = new CLongData(&ptRect->right, 0, LONG_MAX, 0, IDS_FRAMERT_DESCR, true);
	QString strright("");
	strright = tr("right");
	CConfigItem *pkright = new CConfigItem(ms_strRECT_RIGHT_KEY, strright, pkrightData->GetDataAsString(), ctItemButton,
			pkrightData, false, true, 0, false, pkRectParent);
	pkRectParent->AddChild(pkright);
	// Create the bottom data item
	CLongData *pkBottomData = new CLongData(&ptRect->bottom, 0, LONG_MAX, 0, IDS_FRAMEBOT_DESCR, true);
	QString strBottom("");
	strBottom = tr("Bottom");
	CConfigItem *pkBottom = new CConfigItem(ms_strRECT_BOTTOM_KEY, strBottom, pkBottomData->GetDataAsString(),
			ctItemButton, pkBottomData, false, true, 0, false, pkRectParent);
	pkRectParent->AddChild(pkBottom);
}
//****************************************************************************
// void SetupBorderDetails( T_BORDER *ptRect, CConfigBranch *pkParent )
///
/// Method that creates and adds a T_BORDER heirarchy to a branch
///
/// @param[in]		TV_BORDER *ptBorder - pointer to the TV_BORDER data
/// @param[in]		CConfigBranch *pkParent - pointer to the parent config branch
///
//****************************************************************************
void CScrnDesCfgMgr::SetupBorderDetails(T_BORDER *ptBorder, CConfigBranch *pkParent) {
	// Create the submenu button then add the individual buttons
	QString strTitle("");
	QString strSubTitle("");
	// check if this border is used
	if (ptBorder->BorderUsed == 1) {
		strTitle = CStringUtils::GetItemAtPos(ms_strBorderStyleList, ptBorder->BorderStyle);
	strSubTitle.(L"%s, %u, %d", strTitle, RGBtoRGB888(ptBorder->BorderColour), ptBorder->BorderWidth);
} else {
	strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptBorder->BorderUsed);
}
strTitle = tr("Border");
CConfigBranch *pkBorderParent = new CConfigBranch(ms_strBORDER_KEY, strTitle, strSubTitle, ctSubMenuButton, false, true,
		0, false, pkParent);
pkParent->AddChild(pkBorderParent);
// Add the is used field
CShortBitFieldData *pkIsUsedData = new CShortBitFieldData(reinterpret_cast<USHORT*>(ptBorder), 1, 12, ms_strEnabledList,
		bfeBool, 0, IDS_BORDERUSED_DESCR, true);
strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptBorder->BorderUsed);
strTitle = tr("Border On");
CConfigItem *pkIsUsed = new CConfigItem(ms_strBORDER_USED_KEY, strTitle, strSubTitle, ctItemButton, pkIsUsedData, false,
		true, 0, false, pkBorderParent);
pkBorderParent->AddChild(pkIsUsed);
// Add the border style field
CShortBitFieldData *pkBorderStyleData = new CShortBitFieldData(reinterpret_cast<USHORT*>(ptBorder), 8, 0,
		ms_strBorderStyleList, bfeSingleSelList, 0, IDS_BORDERSTL_DESCR, false);
strSubTitle = pkBorderStyleData->GetDataAsString();
strTitle = tr("Border Style");
CConfigItem *pkBorderStyle = new CConfigItem(ms_strBORDER_STYLE_KEY, strTitle, strSubTitle, ctItemButton,
		pkBorderStyleData, false, (ptBorder->BorderUsed == 1), 0, false, pkBorderParent);
pkBorderParent->AddChild(pkBorderStyle);
// Add the Border Colour - this is a ULONG
CULongData *pkColourData = new CULongData(&ptBorder->BorderColour, 0, ms_ulMaxColour, 0, IDS_BORDERCLR_DESCR, true,
		dtColour);
strTitle = tr("Border Color");
strSubTitle = pkColourData->GetDataAsString();
CConfigItem *pkColour = new CConfigItem(ms_strBORDER_COL_KEY, strTitle, strSubTitle, ctItemButton, pkColourData, false,
		(ptBorder->BorderUsed == 1), 0, false, pkBorderParent);
pkBorderParent->AddChild(pkColour);
// Add the border width field - need to specify a minimum of 1 here
CShortBitFieldData *pkBorderWidthData = new CShortBitFieldData(reinterpret_cast<USHORT*>(ptBorder), 4, 8, NULL,
		bfeNumerical, 0, IDS_BORDERWDTH_DESCR, false, 1, 15);
strTitle = tr("Border Width");
CConfigItem *pkBorderWidth = new CConfigItem(ms_strBORDER_WIDTH_KEY, strTitle, pkBorderWidthData->GetDataAsString(),
		ctItemButton, pkBorderWidthData, false, (ptBorder->BorderUsed == 1), 0, false, pkBorderParent);
pkBorderParent->AddChild(pkBorderWidth);
}
//****************************************************************************
// void SetupFontDetails(	T_FONT *ptFont, 
//							CConfigBranch *pkParent,
//							const QString   &rstrMENU_TITLE,
//							const bool bWORD_WRAP )
///
/// Method that creates and adds a T_FONT heirarchy to a branch
///
/// @param[in]		TV_FONT *ptFont - pointer to the TV_FONT data
/// @param[in]		CConfigBranch *pkParent - pointer to the parent config branch
/// @param[in]		const QString   &rstrMENU_TITLE - The title of the sub menu button
///	@param[in]		const bool bWORD_WRAP - Flag indicating if word wrap is on
///
//****************************************************************************
void CScrnDesCfgMgr::SetupFontDetails(T_FONT *ptFont, CConfigBranch *pkParent, const QString &rstrMENU_TITLE,
	const bool bWORD_WRAP) {
// Create the submenu button then add the individual buttons
QString strTitle("");
QString strSubTitle("");
QString strFaceSubTitle = CStringUtils::GetItemAtPos(ms_strFontFaceList, ptFont->Face);
strSubTitle = QString::asprintf("%s, %d", strFaceSubTitle, ptFont->Height);
strTitle = rstrMENU_TITLE;
CConfigBranch *pkFontParent = new CConfigBranch(ms_strFONT_KEY, strTitle, strSubTitle, ctSubMenuButton, false, true, 0,
		false, pkParent);
pkParent->AddChild(pkFontParent);
// Add the type face bitfield
CShortBitFieldData *pkFaceData = new CShortBitFieldData(reinterpret_cast<USHORT*>(ptFont), 3, 10, ms_strFontFaceList,
		bfeSingleSelList, 0, 0, true);
strSubTitle = pkFaceData->GetDataAsString();
strTitle = tr("Typeface");
CConfigItem *pkFace = new CConfigItem(ms_strFONT_FACE_KEY, strTitle, strFaceSubTitle, ctItemButton, pkFaceData, false,
		true, 0, false, pkFontParent);
pkFontParent->AddChild(pkFace);
// Add the height bitfield
CShortBitFieldData *pkHeightData = new CShortBitFieldData(reinterpret_cast<USHORT*>(ptFont), 10, 0, NULL, bfeNumerical,
		0, 0, true, 5, 600);
strTitle = tr("Height");
CConfigItem *pkHeight = new CConfigItem(ms_strFONT_HEIGHT_KEY, strTitle, pkHeightData->GetDataAsString(), ctItemButton,
		pkHeightData, false, bWORD_WRAP, 0, false, pkFontParent);
pkFontParent->AddChild(pkHeight);
// Add the quality bitfield
CShortBitFieldData *pkQualityData = new CShortBitFieldData(reinterpret_cast<USHORT*>(ptFont), 3, 13,
		ms_strFontQualityList, bfeSingleSelList, 0, 0, false);
strSubTitle = pkQualityData->GetDataAsString();
strTitle = tr("Quality");
CConfigItem *pkQuality = new CConfigItem(ms_strFONT_QUALITY_KEY, strTitle, strSubTitle, ctItemButton, pkQualityData,
		false, true, 0, false, pkFontParent);
pkFontParent->AddChild(pkQuality);
// Add the weight ushort
CShortBitFieldData *pkWeightData = new CShortBitFieldData(&ptFont->Weight, 2, 0, ms_strFontWeightList, bfeSingleSelList,
		0, 0, false);
strSubTitle = pkWeightData->GetDataAsString();
strTitle = tr("Weight");
CConfigItem *pkWeight = new CConfigItem(ms_strFONT_WEIGHT_KEY, strTitle, strSubTitle, ctItemButton, pkWeightData, false,
		true, 0, false, pkFontParent);
pkFontParent->AddChild(pkWeight);
}
//****************************************************************************
// CConfigInterface *RefreshConfigTree(	CConfigItem *pkModifiedItem,
//											CLayoutItem* pkCurrLayoutItem )
///
/// Method that refreshes the data for a particular branch of a configuration menu, usually 
/// following a change that requires the tree structure to be regenerated because it is different
///
/// @param[in] 		CConfigItem *pkModifiedItem - A pointer to the item that has been modified
/// @param[in] 		CLayoutItem* pkCurrLayoutItem - A pointer to the layout item being modified
///
//****************************************************************************
CConfigInterface* CScrnDesCfgMgr::RefreshConfigTree(CConfigItem *pkModifiedItem, CLayoutItem *pkCurrLayoutItem) {
return RefreshConfigTree(pkModifiedItem, pkCurrLayoutItem, false);
}
//****************************************************************************
// CConfigInterface *RefreshConfigTree(	CConfigItem *pkModifiedItem,
//											CLayoutItem* pkCurrLayoutItem,
//											const bool bEDIT_CHANNEL_MAP_DATA )
///
/// Method that refreshes the data for a particular branch of a configuration menu, usually 
/// following a change that requires the tree structure to be regenerated because it is different
///
/// @param[in] 		CConfigItem *pkModifiedItem - A pointer to the item that has been modified
/// @param[in] 		CLayoutItem* pkCurrLayoutItem - A pointer to the layout item being modified
/// @param[in]		const bool bEDIT_CHANNEL_MAP_DATA - Flag idnicating if we are editing channel
///					map information only
///
//****************************************************************************
CConfigInterface* CScrnDesCfgMgr::RefreshConfigTree(CConfigItem *pkModifiedItem, CLayoutItem *pkCurrLayoutItem,
	const bool bEDIT_CHANNEL_MAP_DATA) {
CConfigInterface *pkNewCfgItem = NULL;
CConfigBranch *pkNewCfgParent = NULL;
// Store the key name of this item
const QString strKEY(pkModifiedItem->GetKey());
// update the relevant structure
if (pkCurrLayoutItem == NULL) {
	// detemine the type of config item that has been modified
	QString strKey = pkModifiedItem->GetKey();
	int iDelimPos = strKey.indexOf(CConfigInterface::ms_wcDELIMITER, 0);
	// check the delimiter was found and it is not in position 0
	if (iDelimPos > 0) {
		QString strInitialKey = strKey.left(iDelimPos);
		if (strInitialKey.compare(ms_strSCREEN_TITLE_KEY) == 0) {
			// Must be a multiple screens configuration which requires different handling
			// We need to get the screen that was changed
			pkNewCfgParent = RefreshScreenConfigTree(pkModifiedItem);
		} else {
			// delete the existing list
			CConfigInterface *pkItemToDelete = pkModifiedItem;
			while (pkItemToDelete->GetParent() != NULL) {
				pkItemToDelete = pkItemToDelete->GetParent();
			}
			delete pkItemToDelete;
			// determine the type and create a configuration tree
			if (strInitialKey.compare(CScrnDesCfgMgr::ms_strSETTINGS_KEY) == 0) {
				// update the C++ screen objects rotating state
				COpPanel *pkOpPanel = reinterpret_cast<COpPanel*>(AfxGetApp()->m_pMainWnd);
				pkOpPanel->SetRotatingScreens(m_tRotScreenPickerData.ulScreenBitset);
				pkNewCfgParent = CreateSettingsConfig();
			} else if (strInitialKey.compare(CScrnDesCfgMgr::ms_strAPPEARANCE_KEY) == 0) {
				pkNewCfgParent = CreateAppearanceConfig();
			}
			/* ADD MORE HERE
			 else if( strInitialKey.compare( ms_strSETTINGS_KEY ) == 0 )
			 {
			 pkNewCfgParent = CreateSettingsConfig( );
			 }
			 */
		}
	} else {
		// Must be a multiple screens configuration which requires different handling
		// We need to get the screen that was changed
		pkNewCfgParent = RefreshScreenConfigTree(pkModifiedItem);
	}
} else {
	CConfigInterface *pkItemToDelete = pkModifiedItem;
	while (pkItemToDelete->GetParent() != NULL) {
		pkItemToDelete = pkItemToDelete->GetParent();
	}
	delete pkItemToDelete;
	if (pkCurrLayoutItem->IsObject()) {
		T_BASEOBJECT *ptCMMBaseObject = reinterpret_cast<T_BASEOBJECT*>(pkCurrLayoutItem->GetCMMInfo().pByBlock);
		// get a pointer to the widget
		CBaseObject *pkBaseObject = static_cast<CBaseObject*>(pkCurrLayoutItem);
		CWidget *pkParentWidget = pkBaseObject->GetWidget();
		switch (ptCMMBaseObject->ObjectType) {
		case DigitalObject: {
			pkNewCfgParent = CreateDigObjConfig(ptCMMBaseObject, pkParentWidget);
		}
			break;
		case BarObject: {
			pkNewCfgParent = CreateBarObjConfig(ptCMMBaseObject, pkParentWidget);
		}
			break;
		case TextObject: {
			pkNewCfgParent = CreateTextObjConfig(ptCMMBaseObject, pkCurrLayoutItem);
		}
			break;
		case ScaleObject: {
			pkNewCfgParent = CreateScaleObjConfig(ptCMMBaseObject, pkParentWidget);
		}
			break;
		case BitmapObject: {
			pkNewCfgParent = CreateBitmapObjConfig(ptCMMBaseObject, pkParentWidget);
		}
			break;
		case ChartObject: {
			pkNewCfgParent = CreateChartObjConfig(ptCMMBaseObject, pkParentWidget);
		}
			break;
		case PenPointersObject: {
			pkNewCfgParent = CreatePenPointersObjConfig(ptCMMBaseObject, pkParentWidget);
		}
			break;
		case AlarmMrkrObject: {
			pkNewCfgParent = CreateAlarmMrkrObjConfig(ptCMMBaseObject, pkParentWidget);
		}
			break;
		case ButtonObject: {
#ifdef _DEBUG
						pkNewCfgParent = CreateButtonObjConfig( ptCMMBaseObject, pkParentWidget );
#endif
		}
			break;
		case TabularDisplayObject: {
#ifdef _DEBUG
						pkNewCfgParent = CreateTabularDisplayObjConfig( ptCMMBaseObject, pkParentWidget );
#endif
		}
			break;
		case TUSObject: {
#ifdef _DEBUG
						pkNewCfgParent = CreateTUSObjConfig( ptCMMBaseObject, pkParentWidget );
#endif
		}
			break;
		case CircularChartObject: {
			pkNewCfgParent = CreateCircularChartObjConfig(ptCMMBaseObject, pkParentWidget);
		}
			break;
		case NoObject:
			//	do nothing as this is an error condition
			break;
		default:
			//	do nothing as this is an error condition
			break;
		}
	} else if (pkCurrLayoutItem->IsWidget()) {
		if (!bEDIT_CHANNEL_MAP_DATA) {
			pkNewCfgParent = CreateWidgetConfig(static_cast<CWidget*>(pkCurrLayoutItem));
		} else {
			pkNewCfgParent = CreateWidgetChannelMapConfig(static_cast<CWidget*>(pkCurrLayoutItem));
		}
	} else if (pkCurrLayoutItem->IsScreen()) {
		// a change has occured on the screen. 
		CScreen *pkScreen = static_cast<CScreen*>(pkCurrLayoutItem);
		// if this is a canned screen set the flag
		// we will then build it afresh from the new screen config data.
		if (pkScreen->IsCannedScreen())
			pkScreen->m_CannedScreenChanged = TRUE;
		pkNewCfgParent = CreateScreenConfig(static_cast<CScreen*>(pkCurrLayoutItem));
	}
}
pkNewCfgItem = indexOfChildByKey(strKEY, pkNewCfgParent, 1);
if (pkNewCfgItem == NULL) {
	// set to the parent instead
	pkNewCfgItem = pkNewCfgParent;
}
return pkNewCfgItem;
}
//****************************************************************************
//	void CommitChanges()
///
/// Method that commits recorder setup changes to the CMM
///
//****************************************************************************
void CScrnDesCfgMgr::CommitChanges() {
m_bModified = false;
#ifndef DOCVIEW
T_MOD_CFG_CHG_MSGDATA msg;
msg.TypeOfConfigChange = MOD_CFG_CHG_LAYOUT;
msg.configChangeSystemAction = MOD_SYS_CFG_CHG_NORMAL_OPERATION;
msg.ConfigChangeAction = MOD_CFG_CHG_ACTION_UPDATE;
m_ModuleMessageManagerClient.MMMClientPostIntMsgAndWait( INFINITE, m_dwPOST_MESSAGE_WAIT_TIMEOUT,
		MODULE_CONTROL_SEQUENCER, // Destination
		MODULE_LAYOUT_CFG_MGR, // Sender
		MOD_CONFIG_CHANGE, sizeof(T_MOD_CFG_CHG_MSGDATA), (BYTE*) &msg);
#endif
}
//****************************************************************************
//	void DiscardChanges()
///
/// Method that discards layout changes from the CMM
///
//****************************************************************************
void CScrnDesCfgMgr::DiscardChanges() {
m_bModified = false;
#ifndef DOCVIEW
T_CONFIG_RETURN_VALUE eErrVal = pGlbLayout->DiscardConfigurationChanges();
#endif
}
//****************************************************************************
// CConfigInterface *CreateBarObjConfig(	T_BASEOBJECT* pkBaseObject,
//											CWidget *pkParentWidget );
///
/// Method that creates a example bar config hierarchy
///
/// @param[in]			T_BASEOBJECT* pkBaseObject - Pointer to the base object we 
///						are creating the configuration tree for
/// @param[in]			CWidget *pkParentWidget - Pointer to the widget this object is on
///
/// @return Pointer to the top-level parent of a example bar config hierarchy
///
//****************************************************************************
CConfigBranch* CScrnDesCfgMgr::CreateBarObjConfig(T_BASEOBJECT *pkBaseObject, CWidget *pkParentWidget) {
CConfigBranch *pkParent = NULL;
// firstly create the top level config interface class
QString strBarObjectTitle("");
strBarObjectTitle = pkParentWidget->GetObjectName(pkBaseObject);
pkParent = new CConfigBranch(ms_strBAR_OBJ_TITLE_KEY, strBarObjectTitle, strBarObjectTitle, ctMainMenuButton, false,
		true, 0, false, NULL);
// Add the general base object properties
CreateBasePropsConfigData(pkBaseObject, pkParent);
//create General BarObject specific properties
//bar type field
QString strTitle("");
QString strSubTitle("");
strTitle = tr("Showing");
// add the object channel map
CreateObjectChannelMap(pkBaseObject, pkParent, strTitle, pkParentWidget);
T_BAROBJECT *pkBarObject = reinterpret_cast<T_BAROBJECT*>(pkBaseObject);
unsigned char *pucBarObject = reinterpret_cast<unsigned char*>(pkBarObject);
ULONG *ptBarLongBitField = reinterpret_cast<ULONG*>(pucBarObject + sizeof(T_BASEOBJECT));
//bar type	
CLongBitFieldData *pkBarTypeData = new CLongBitFieldData(ptBarLongBitField, 2, 1, ms_strBarTypeList, bfeSingleSelList,
		0, IDS_BARTYPE_DESCR, true);
strSubTitle = pkBarTypeData->GetDataAsString();
strTitle = tr("Bar Type");
CConfigItem *pkBarType = new CConfigItem(ms_strBAR_TYPE_KEY, strTitle, strSubTitle, ctItemButton, pkBarTypeData, false,
		true, 0, false, pkParent);
pkParent->AddChild(pkBarType);
//bar style field
QString csStyle = (pkBarObject->BarType != Based) ? ms_strBarStyleListUpDown : ms_strBarStyleListBased;
CLongBitFieldData *pkBarStyleData = new CLongBitFieldData(ptBarLongBitField, 3, 3, csStyle, bfeSingleSelList, 0,
		IDS_BARSTYLE_DESCR, true);
strSubTitle = pkBarStyleData->GetDataAsString();
strTitle = tr("Bar Style");
CConfigItem *pkBarStyle = new CConfigItem(ms_strBAR_STYLE_KEY, strTitle, strSubTitle, ctItemButton, pkBarStyleData,
		false, (pkBarObject->BarType != None), 0, false, pkParent);
pkParent->AddChild(pkBarStyle);
//base point. This is a good spot for this item as the next 4 items after this one are 
//dependent upon the value of this item
if ((pkBarObject->BarType == Based) && (pkBarObject->BarStyle != BAR_STYLE_TRAFFICLIGHT)) {
	CFloatData *pkBasePointData = new CFloatData(&pkBarObject->BasePoint, 0, V6_FLT_MAX, 0, IDS_BASEPT_DESCR, true,
			dtFloat, TEMP_DEG_C);
	strTitle = tr("Base Point");
	CConfigItem *pkBasePoint = new CConfigItem(ms_strBAR_BASEPOINT_KEY, strTitle, pkBasePointData->GetDataAsString(),
			ctItemButton, pkBasePointData, false, true, 0, false, pkParent);
	pkParent->AddChild(pkBasePoint);
}
if ((pkBarObject->BarStyle == BAR_STYLE_TRAFFICLIGHT)) {
//breakpoint green
	CFloatData *pkBreakPointGreenData = new CFloatData(&pkBarObject->BreakPtGreen, 0, V6_FLT_MAX, 0,
			IDS_BKPT_GREEN_DESCR, true, dtFloat, TEMP_DEG_C);
	strTitle = tr("Traffic Breakpoint Green");
	CConfigItem *pkBreakPointGreen = new CConfigItem(ms_strBAR_BREAKPONT_GREEN_KEY, strTitle,
			pkBreakPointGreenData->GetDataAsString(), ctItemButton, pkBreakPointGreenData, false,
			((pkBarObject->BarType != None) && (pkBarObject->BarType != Based)), 0, false, pkParent);
	pkParent->AddChild(pkBreakPointGreen);
//breakpoint amber
	CFloatData *pkBreakPointAmberData = new CFloatData(&pkBarObject->BreakPtAmber, 0, V6_FLT_MAX, 0,
			IDS_BKPT_AMBER_DESCR, true, dtFloat, TEMP_DEG_C);
	strTitle = tr("Traffic Breakpoint Amber");
	CConfigItem *pkBreakPointAmber = new CConfigItem(ms_strBAR_BREAKPONT_AMBER_KEY, strTitle,
			pkBreakPointAmberData->GetDataAsString(), ctItemButton, pkBreakPointAmberData, false,
			((pkBarObject->BarType != None) && (pkBarObject->BarType != Based)), 0, false, pkParent);
	pkParent->AddChild(pkBreakPointAmber);
}
if (pkBarObject->BarStyle == BAR_STYLE_DYNAMIC)	//if based bar type, BarStyle is 2, else 3
		{
//breakpointdynGreen
	CFloatData *pkBreakPointDynGreenData = new CFloatData(&pkBarObject->BrkPtDynGreen, 0, V6_FLT_MAX, 0,
			IDS_BKPT_DYNGREEN_DESCR, true, dtFloat, TEMP_DEG_C);
	strTitle = tr("Dynamic Breakpoint Green");
	CConfigItem *pkBreakPointDynGreen = new CConfigItem(ms_strBAR_BREAKPONT_DYNGREEN_KEY, strTitle,
			pkBreakPointDynGreenData->GetDataAsString(), ctItemButton, pkBreakPointDynGreenData, false,
			(pkBarObject->BarType != None), 0, false, pkParent);
	pkParent->AddChild(pkBreakPointDynGreen);
//breakpointDynAmber
	CFloatData *pkBreakPointDynAmberData = new CFloatData(&pkBarObject->BrkPtDynAmber, 0, V6_FLT_MAX, 0,
			IDS_BKPT_DYNAMBER_DESCR, true, dtFloat, TEMP_DEG_C);
	strTitle = tr("Dynamic Breakpoint Amber");
	CConfigItem *pkBreakPointDynAmber = new CConfigItem(ms_strBAR_BREAKPONT_DYNAMBER_KEY, strTitle,
			pkBreakPointDynAmberData->GetDataAsString(), ctItemButton, pkBreakPointDynAmberData, false,
			(pkBarObject->BarType != None), 0, false, pkParent);
	pkParent->AddChild(pkBreakPointDynAmber);
}
//solid above colour, below clr, fix above/below clr
if ((pkBarObject->BarStyle == BAR_STYLE_SOLID) && (pkBarObject->BarType == Based)) {
	CBoolData *pkFixAboveClrData = new CBoolData(&pkBarObject->FixAboveColour, 0, 0, true);
	strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, pkBarObject->FixAboveColour);
	strTitle = tr("Fix Above Color");
	CConfigItem *pkFixAboveClr = new CConfigItem(ms_strBAR_FIX_ABOVE_CLR_KEY, strTitle, strSubTitle, ctItemButton,
			pkFixAboveClrData, false, true, 0, false, pkParent);
	pkParent->AddChild(pkFixAboveClr);
	// check if the above clr is fixed 
	if (pkBarObject->FixAboveColour == TRUE) {
		// Add the Above Colour item
		CULongData *pkSolidAboveColData = new CULongData(&pkBarObject->SldAboveClr, 0, ms_ulMaxColour, 0,
				IDS_ABOVECLR_DESCR, false, dtColour);
		strSubTitle = pkSolidAboveColData->GetDataAsString();
		strTitle = tr("Solid Above Color");
		CConfigItem *pkSolidAboveCol = new CConfigItem(ms_strBAR_SOLID_ABOVE_CLR_KEY, strTitle, strSubTitle,
				ctItemButton, pkSolidAboveColData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkSolidAboveCol);
	}
	CBoolData *pkFixBelowClrData = new CBoolData(&pkBarObject->FixBelowColour, 0, 0, true);
	strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, pkBarObject->FixBelowColour);
	strTitle = tr("Fix Below Color");
	CConfigItem *pkFixBelowClr = new CConfigItem(ms_strBAR_FIX_BELOW_CLR_KEY, strTitle, strSubTitle, ctItemButton,
			pkFixBelowClrData, false, true, 0, false, pkParent);
	pkParent->AddChild(pkFixBelowClr);
	// check if the below clr is fixed
	if (pkBarObject->FixBelowColour == TRUE) {
		// Add the Below Colour item
		CULongData *pkSolidBelowColData = new CULongData(&pkBarObject->SldBelowClr, 0, ms_ulMaxColour, 0,
				IDS_BELOWCLR_DESCR, false, dtColour);
		strSubTitle = pkSolidBelowColData->GetDataAsString();
		strTitle = tr("Solid Below Color");
		CConfigItem *pkSolidBelowCol = new CConfigItem(ms_strBAR_SOLID_BELOW_CLR_KEY, strTitle, strSubTitle,
				ctItemButton, pkSolidBelowColData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkSolidBelowCol);
	}
}
//Fade type handle
//Fade bar type-gradient clr properties
if (pkBarObject->BarStyle == BAR_STYLE_FADE) {
//gradient start/end clr
	CLongBitFieldData *pkGradStartEndClrData = new CLongBitFieldData(ptBarLongBitField, 1, 9, ms_strEnabledList,
			bfeBool, 0, IDS_USERDEF_GRADIENTCOLOURS_DESCR, true);
	strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, pkBarObject->GradStrtEndClr);
	strTitle = tr("Gradient Start/End Clr Select");
	CConfigItem *pkGradStartEndClr = new CConfigItem(ms_strBAR_GRAD_START_END_CLR_KEY, strTitle, strSubTitle,
			ctItemButton, pkGradStartEndClrData, false, true, 0, false, pkParent);
	pkParent->AddChild(pkGradStartEndClr);
	if (pkBarObject->GradStrtEndClr != TRUE) {
		//enter grad fill colour, gradStartEndClr
		CLongBitFieldData *pkGradFillClrData = new CLongBitFieldData(ptBarLongBitField, 3, 18, ms_strBarGradFillClrList,
				bfeSingleSelList, 0, IDS_GRADFILLCLR_DESCR, true);
		strSubTitle = pkGradFillClrData->GetDataAsString();
		strTitle = tr("Gradient Fill Color");
		CConfigItem *pkGradFillClr = new CConfigItem(ms_strBAR_GRADFILL_CLR_KEY, strTitle, strSubTitle, ctItemButton,
				pkGradFillClrData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkGradFillClr);
	} else {
//grad start clr
		CULongData *pkGradStartColData = new CULongData(&pkBarObject->GradStartClr, 0, ms_ulMaxColour, 0,
				IDS_GRADSTARTCLR_DESCR, false, dtColour);
		strSubTitle = pkGradStartColData->GetDataAsString();
		strTitle = tr("Gradient Start Color");
		CConfigItem *pkGradStartCol = new CConfigItem(ms_strBAR_GRAD_START_CLR_KEY, strTitle, strSubTitle, ctItemButton,
				pkGradStartColData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkGradStartCol);
//grad end clr
		CULongData *pkGradEndColData = new CULongData(&pkBarObject->GradEndClr, 0, ms_ulMaxColour, 0,
				IDS_GRADENDCLR_DESCR, false, dtColour);
		strSubTitle = pkGradEndColData->GetDataAsString();
		strTitle = tr("Gradient End Color");
		CConfigItem *pkGradEndCol = new CConfigItem(ms_strBAR_GRAD_END_CLR_KEY, strTitle, strSubTitle, ctItemButton,
				pkGradEndColData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkGradEndCol);
	}
}
//orientation
CLongBitFieldData *pkBarOrientationData = new CLongBitFieldData(ptBarLongBitField, 1, 0, ms_strOrientationList,
		bfeSingleSelList, 0, IDS_BARORIENT_DESCR, true);
strSubTitle = pkBarOrientationData->GetDataAsString();
strTitle = tr("Orientation");
CConfigItem *pkBarOrientation = new CConfigItem(ms_strLYT_ORIENTATION_KEY, strTitle, strSubTitle, ctItemButton,
		pkBarOrientationData, false, true, 0, false, pkParent);
pkParent->AddChild(pkBarOrientation);
//levelcap on/off flag
CBoolData *pkLevelCapData = new CBoolData(&pkBarObject->LevelCap, 0, IDS_LEVELCAP_DESCR, true);
strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, pkBarObject->LevelCap);
strTitle = tr("LevelCap");
CConfigItem *pkLevelCap = new CConfigItem(ms_strBAR_LEVELCAP_KEY, strTitle, strSubTitle, ctItemButton, pkLevelCapData,
		false, true, 0, false, pkParent);
pkParent->AddChild(pkLevelCap);
//levelcap colour
if (pkBarObject->LevelCap == TRUE) {
	// Add the levelcap Colour - this is a USHORT
	CULongData *pkLevelCapColourData = new CULongData(&pkBarObject->LevelCapClr, 0, ms_ulMaxColour, 0,
			IDS_LEVELCPCLR_DESCR, false, dtColour);
	strTitle = tr("Level Cap Color");
	strSubTitle = pkLevelCapColourData->GetDataAsString();
	CConfigItem *pkLevelCapColour = new CConfigItem(ms_strBAR_LEVELCAP_COL_KEY, strTitle, strSubTitle, ctItemButton,
			pkLevelCapColourData, false, true, 0, false, pkParent);
	pkParent->AddChild(pkLevelCapColour);
}
//fix top limit flag
CBoolData *pkFixTopLimitData = new CBoolData(&pkBarObject->FixTopLimit, 0, IDS_FIX_TOPLMT_DESCR, true);
strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, pkBarObject->FixTopLimit);
strTitle = tr("Fix TopLimit");
CConfigItem *pkFixTopLimit = new CConfigItem(ms_strBAR_FIX_TOPLIMIT_KEY, strTitle, strSubTitle, ctItemButton,
		pkFixTopLimitData, false, true, 0, false, pkParent);
pkParent->AddChild(pkFixTopLimit);
// check if the toplimit is fixed
if (pkBarObject->FixTopLimit == TRUE) {
	// Add the TopLimit item
	CFloatData *pkTopLimitData = new CFloatData(&pkBarObject->TopLimit, 0, V6_FLT_MAX, 0, IDS_TOPLMT_DESCR, true,
			dtFloat, TEMP_DEG_C);
	strTitle = tr("Top Limit");
	CConfigItem *pkTopLimit = new CConfigItem(ms_strBAR_TOP_LIMIT_KEY, strTitle, pkTopLimitData->GetDataAsString(),
			ctItemButton, pkTopLimitData, false, true, 0, false, pkParent);
	pkParent->AddChild(pkTopLimit);
}
//fix bottom limit flag
CBoolData *pkFixBottomLimitData = new CBoolData(&pkBarObject->FixBotLimit, 0, IDS_FIX_BTMLIMIT_DESCR, true);
strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, pkBarObject->FixBotLimit);
strTitle = tr("Fix BottomLimit");
CConfigItem *pkFixBottomLimit = new CConfigItem(ms_strBAR_FIX_BOTTOMLIMIT_KEY, strTitle, strSubTitle, ctItemButton,
		pkFixBottomLimitData, false, true, 0, false, pkParent);
pkParent->AddChild(pkFixBottomLimit);
// check if the bottomlimit is fixed
if (pkBarObject->FixBotLimit == TRUE) {
	// Add the TopLimit item
	CFloatData *pkBottomLimitData = new CFloatData(&pkBarObject->BotLimit, 0, V6_FLT_MAX, 0, IDS_BOTTOMLMT_DESCR, true,
			dtFloat, TEMP_DEG_C);
	strTitle = tr("Bottom Limit");
	CConfigItem *pkBottomLimit = new CConfigItem(ms_strBAR_BOTTOM_LIMIT_KEY, strTitle,
			pkBottomLimitData->GetDataAsString(), ctItemButton, pkBottomLimitData, false, true, 0, false, pkParent);
	pkParent->AddChild(pkBottomLimit);
}
//Error Indicators
//	strSubTitle="");
//	QString   strErrIndicators( "Error Indicators" );
//	CConfigBranch *pkErrIndicatorsBranch = new CConfigBranch(	ms_strBAR_ERR_INDICATOR_KEY,
//														strErrIndicators,
//														strSubTitle,
//														ctSubMenuButton,
//														false,
//														true,
//														0,
//														false,
//														pkParent );	
//	pkParent->AddChild( pkErrIndicatorsBranch );
////overrange error Flash Col1
//	CULongData *pkOvRngFlshColData = new CULongData(	&pkBarObject->ErrIndFlsClr[OVER_RNG_ERR],
//													0,
//													ms_ulMaxColour,
//													0,
//													IDS_OVRRNG_TRI_FLSHCLR1_DESCR,
//													false,
//													dtColour );
//
//		strSubTitle = pkOvRngFlshColData->GetDataAsString( );
//		strTitle = tr("Over Range Triangle FlashClr1");
//		CConfigItem *pkOvRngFlshCol = new CConfigItem(	ms_strBAR_OVRNG_CLR1_KEY,
//													strTitle,
//													strSubTitle,						
//													ctItemButton,
//													pkOvRngFlshColData,
//													false,
//													true,
//													0,
//													false,
//													pkParent/*pkErrIndicatorsBranch*/ );
////		pkErrIndicatorsBranch->AddChild( pkOvRngFlshCol );
//		pkParent->AddChild( pkOvRngFlshCol );
////overrange error Flash Col2
//	CULongData *pkOvRngInterFlshColData = new CULongData(	&pkBarObject->ErrIndIntFlsClr[OVER_RNG_ERR],
//													0,
//													ms_ulMaxColour,
//													0,
//													IDS_OVRRNG_TRFLSHCLR2_DESCR,
//													false,
//													dtColour );
//
//		strSubTitle = pkOvRngInterFlshColData->GetDataAsString( );
//		strTitle = tr("Over Range Triangle FlashClr2");
//		CConfigItem *pkOvRngInterFlshCol = new CConfigItem(	ms_strBAR_OVRNG_CLR2_KEY,
//													strTitle,
//													strSubTitle,						
//													ctItemButton,
//													pkOvRngInterFlshColData,
//													false,
//													true,
//													0,
//													false,
//													pkParent/*pkErrIndicatorsBranch*/ );
////		pkErrIndicatorsBranch->AddChild( pkOvRngInterFlshCol );
//		pkParent->AddChild( pkOvRngInterFlshCol );
//
//
////Underrange error Flash Col1
//	CULongData *pkUnderRngFlshColData = new CULongData(	&pkBarObject->ErrIndFlsClr[UNDER_RNG_ERR],
//													0,
//													ms_ulMaxColour,
//													0,
//													IDS_OVRRNG_TRI_FLSHCLR1_DESCR,
//													false,
//													dtColour );
//
//		strSubTitle = pkUnderRngFlshColData->GetDataAsString( );
//		strTitle = tr("Under Range Triangle FlashClr1");
//		CConfigItem *pkUnderRngFlshCol = new CConfigItem(	ms_strBAR_UNDERRNG_CLR1_KEY,
//													strTitle,
//													strSubTitle,						
//													ctItemButton,
//													pkUnderRngFlshColData,
//													false,
//													true,
//													0,
//													false,
//													pkParent/*pkErrIndicatorsBranch*/ );
////		pkErrIndicatorsBranch->AddChild( pkUnderRngFlshCol );
//		pkParent->AddChild( pkUnderRngFlshCol );
//
//
////Underrange error Flash Col2
//	CULongData *pkUnderRngInterFlshColData = new CULongData(	&pkBarObject->ErrIndIntFlsClr[UNDER_RNG_ERR],
//													0,
//													ms_ulMaxColour,
//													0,
//													IDS_OVRRNG_TRFLSHCLR2_DESCR,
//													false,
//													dtColour );
//
//		strSubTitle = pkUnderRngInterFlshColData->GetDataAsString( );
//		strTitle = tr("Under Range Triangle FlashClr2");
//		CConfigItem *pkUnderRngInterFlshCol = new CConfigItem(	ms_strBAR_UNDERRNG_CLR2_KEY,
//													strTitle,
//													strSubTitle,						
//													ctItemButton,
//													pkUnderRngInterFlshColData,
//													false,
//													true,
//													0,
//													false,
//													pkParent/*pkErrIndicatorsBranch*/ );
////		pkErrIndicatorsBranch->AddChild( pkUnderRngInterFlshCol );
//		pkParent->AddChild( pkUnderRngInterFlshCol );
//	CULongData *pkInvalidRdngFlshColData = new CULongData(	&pkBarObject->ErrIndFlsClr[INVALID_READING],
//													0,
//													ms_ulMaxColour,
//													0,
//													IDS_ASTERISK_FLSHCLR1_DESCR,
//													false,
//													dtColour );
//
//		strSubTitle = pkInvalidRdngFlshColData->GetDataAsString( );
//		strTitle = tr("Inaval Reading FlashClr1");
//	CConfigItem *pkInvalidRdngFlshCol = new CConfigItem(	ms_strBAR_INVALIDRDNG_CLR1_KEY,
//													strTitle,
//													strSubTitle,						
//													ctItemButton,
//													pkInvalidRdngFlshColData,
//													false,
//													true,
//													0,
//													false,
//													pkParent/*pkErrIndicatorsBranch*/ );
////		pkErrIndicatorsBranch->AddChild( pkInvalidRdngFlshCol );
//		pkParent->AddChild( pkInvalidRdngFlshCol );
//
////Invalid Reading Flash Col2
//	CULongData *pkInvalidRdngInterFlshColData = new CULongData(	&pkBarObject->ErrIndIntFlsClr[INVALID_READING],
//													0,
//													ms_ulMaxColour,
//													0,
//													IDS_ASTERISK_FLSHCLR2_DESCR,
//													false,
//													dtColour );
//
//		strSubTitle = pkInvalidRdngInterFlshColData->GetDataAsString( );
//		strTitle = tr("Inval Reading FlashClr2");
//		CConfigItem *pkInvalidRdngInterFlshCol = new CConfigItem(	ms_strBAR_INVALIDRDNG_CLR2_KEY,
//													strTitle,
//													strSubTitle,						
//													ctItemButton,
//													pkInvalidRdngInterFlshColData,
//													false,
//													true,
//													0,
//													false,
//													pkParent/*pkErrIndicatorsBranch*/ );
////		pkErrIndicatorsBranch->AddChild( pkInvalidRdngInterFlshCol );
//		pkParent->AddChild( pkInvalidRdngInterFlshCol );
//
////Upscale Burnout Flash Col1
//	CULongData *pkUpscBurnoutFlshColData = new CULongData(	&pkBarObject->ErrIndFlsClr[UPSCALE_BURNOUT],
//													0,
//													ms_ulMaxColour,
//													0,
//													IDS_OVRRNG_TRI_FLSHCLR1_DESCR,
//													false,
//													dtColour );
//
//		strSubTitle = pkUpscBurnoutFlshColData->GetDataAsString( );
//		strTitle = tr("Upscale Burnout FlashClr1");
//		CConfigItem *pkUpscBurnoutFlashCol = new CConfigItem(	ms_strBAR_UPSC_BURNOUT_CLR1_KEY,
//													strTitle,
//													strSubTitle,						
//													ctItemButton,
//													pkUpscBurnoutFlshColData,
//													false,
//													true,
//													0,
//													false,
//													pkParent/*pkErrIndicatorsBranch*/ );
////		pkErrIndicatorsBranch->AddChild( pkUpscBurnoutFlashCol );
//		pkParent->AddChild( pkUpscBurnoutFlashCol );
//
////Upscale Burnout Flash Col2
//	CULongData *pkUpscBurnoutInterFlshColData = new CULongData(	&pkBarObject->ErrIndIntFlsClr[UPSCALE_BURNOUT],
//													0,
//													ms_ulMaxColour,
//													0,
//													IDS_OVRRNG_TRFLSHCLR2_DESCR,
//													false,
//													dtColour );
//
//		strSubTitle = pkUpscBurnoutInterFlshColData->GetDataAsString( );
//		strTitle = tr("Upscale Burnout FlashClr2");
//		CConfigItem *pkUpscBurnoutInterFlshCol = new CConfigItem(	ms_strBAR_UPSC_BURNOUT_CLR2_KEY,
//													strTitle,
//													strSubTitle,						
//													ctItemButton,
//													pkUpscBurnoutInterFlshColData,
//													false,
//													true,
//													0,
//													false,
//													pkParent/*pkErrIndicatorsBranch*/ );
////		pkErrIndicatorsBranch->AddChild( pkUpscBurnoutInterFlshCol );
//		pkParent->AddChild( pkUpscBurnoutInterFlshCol );
//
////Downscale Burnout Flash Col1
//	CULongData *pkDownscBurnoutFlshColData = new CULongData(	&pkBarObject->ErrIndFlsClr[DOWNSCALE_BURNOUT],
//													0,
//													ms_ulMaxColour,
//													0,
//													IDS_OVRRNG_TRI_FLSHCLR1_DESCR,
//													false,
//													dtColour );
//
//		strSubTitle = pkDownscBurnoutFlshColData->GetDataAsString( );
//		strTitle = tr("Downscale Burnout FlashClr1");
//		CConfigItem *pkDownscBurnoutFlshCol = new CConfigItem(	ms_strBAR_DNSC_BURNOUT_CLR1_KEY,
//													strTitle,
//													strSubTitle,						
//													ctItemButton,
//													pkDownscBurnoutFlshColData,
//													false,
//													true,
//													0,
//													false,
//													pkParent/*pkErrIndicatorsBranch*/ );
////		pkErrIndicatorsBranch->AddChild( pkDownscBurnoutFlshCol );
//		pkParent->AddChild( pkDownscBurnoutFlshCol );
////Downscale Burnout Flash Col2
//	CULongData *pkDownscBurnoutInterFlshColData = new CULongData(	&pkBarObject->ErrIndIntFlsClr[DOWNSCALE_BURNOUT],
//													0,
//													ms_ulMaxColour,
//													0,
//													IDS_OVRRNG_TRFLSHCLR2_DESCR,
//													false,
//													dtColour );
//
//		strSubTitle = pkDownscBurnoutInterFlshColData->GetDataAsString( );
//		strTitle = tr("Downscale Burnout FlashClr2");
//		CConfigItem *pkDownscBurnoutInteFlsCol = new CConfigItem(	ms_strBAR_DNSC_BURNOUT_CLR2_KEY,
//													strTitle,
//													strSubTitle,						
//													ctItemButton,
//													pkDownscBurnoutInterFlshColData,
//													false,
//													true,
//													0,
//													false,
//													pkParent/*pkErrIndicatorsBranch*/ );
////		pkErrIndicatorsBranch->AddChild( pkDownscBurnoutInteFlsCol );
//		pkParent->AddChild( pkDownscBurnoutInteFlsCol );
// Add the submenu/category base object properties
CreateBaseSubMenuPropsConfigData(pkBaseObject, pkParent);
//maxmin markers
if ((pkBarObject->ShowMaxMrkr == TRUE) && (pkBarObject->ShowMinMrkr == TRUE)) {
	strSubTitle = tr("Max/Min");
} else if (pkBarObject->ShowMaxMrkr == TRUE) {
	strSubTitle = tr("Max");
} else if (pkBarObject->ShowMinMrkr == TRUE) {
	strSubTitle = tr("Min");
} else {
	strSubTitle = tr("None");
}
strTitle = tr("Markers");
CConfigBranch *pkMxMnMrkrBranch = new CConfigBranch(ms_strBAR_MXMN_MRKR_KEY, strTitle, strSubTitle, ctSubMenuButton,
		false, true, 0, false, pkParent);
pkParent->AddChild(pkMxMnMrkrBranch);
//show max marker
CLongBitFieldData *pkShowMxMrkrData = new CLongBitFieldData(ptBarLongBitField, 1, 6, ms_strEnabledList, bfeBool, 0,
		IDS_MAXMRKR_DESCR, true);
strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, pkBarObject->ShowMaxMrkr);
strTitle = tr("Show Max Marker");
CConfigItem *pkShowMxMrkr = new CConfigItem(ms_strBAR_SHOW_MX_MRKR_KEY, strTitle, strSubTitle, ctItemButton,
		pkShowMxMrkrData, false, (pkBarObject->ChannelInfo.ItemType == DI_PEN), 0, false, pkMxMnMrkrBranch);
pkMxMnMrkrBranch->AddChild(pkShowMxMrkr);
//show min marker
CLongBitFieldData *pkShowMnMrkrData = new CLongBitFieldData(ptBarLongBitField, 1, 7, ms_strEnabledList, bfeBool, 0,
		IDS_MINMRKR_DESCR, true);
strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, pkBarObject->ShowMinMrkr);
strTitle = tr("Show Min Marker");
CConfigItem *pkShowMnMrkr = new CConfigItem(ms_strBAR_SHOW_MN_MRKR_KEY, strTitle, strSubTitle, ctItemButton,
		pkShowMnMrkrData, false, (pkBarObject->ChannelInfo.ItemType == DI_PEN), 0, false, pkMxMnMrkrBranch);
pkMxMnMrkrBranch->AddChild(pkShowMnMrkr);
//reset markers
//marker colour
bool bMarkerEnabled = (pkBarObject->ShowMaxMrkr == TRUE) || (pkBarObject->ShowMinMrkr == TRUE);
CLongBitFieldData *pkResetMrkrsData = new CLongBitFieldData(ptBarLongBitField, 1, 9, ms_strEnabledList, bfeBool, 0,
		IDS_RESETMRKR_DESCR, true);
strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, pkBarObject->ResetMarkers);
strTitle = tr("Reset Markers");
CConfigItem *pkResetMrkrs = new CConfigItem(ms_strBAR_RESET_MRKRS_KEY, strTitle, strSubTitle, ctItemButton,
		pkResetMrkrsData, false, bMarkerEnabled, 0, false, pkMxMnMrkrBranch);
pkMxMnMrkrBranch->AddChild(pkResetMrkrs);
// Add the marker colour - this is a ULONG
CULongData *pkMrkrColData = new CULongData(&pkBarObject->MarkerClr, 0, ms_ulMaxColour, 0, IDS_MRKRCLR_DESCR, false,
		dtColour);
strSubTitle = pkMrkrColData->GetDataAsString();
strTitle = tr("Marker Color");
CConfigItem *pkMrkrCol = new CConfigItem(ms_strBAR_MRKR_CLR_KEY, strTitle, strSubTitle, ctItemButton, pkMrkrColData,
		false, bMarkerEnabled, 0, false, pkMxMnMrkrBranch);
pkMxMnMrkrBranch->AddChild(pkMrkrCol);
return pkParent;
}
//****************************************************************************
// CConfigInterface *CreateScaleObjConfig( T_BASEOBJECT* pkBaseObject,
//											CWidget *pkParentWidget );
///
/// Method that creates a example bar config hierarchy
///
/// @param[in]			T_BASEOBJECT* pkBaseObject - Pointer to the base object we 
///						are creating the configuration tree for
/// @param[in]			CWidget *pkParentWidget - Pointer to the widget this object is on
///
/// @return Pointer to the top-level parent of a example bar config hierarchy
///
//****************************************************************************
CConfigBranch* CScrnDesCfgMgr::CreateScaleObjConfig(T_BASEOBJECT *pkBaseObject, CWidget *pkParentWidget) {
CConfigBranch *pkParent = NULL;
// firstly create the top level config interface class
QString strScaleObjectTitle("");
strScaleObjectTitle = pkParentWidget->GetObjectName(pkBaseObject);
pkParent = new CConfigBranch(ms_strSCALE_OBJ_TITLE_KEY, strScaleObjectTitle, strScaleObjectTitle, ctMainMenuButton,
		false, true, 0, false, NULL);
// Add the general base object properties
CreateBasePropsConfigData(pkBaseObject, pkParent);
//scaleObj specific data
QString strTitle("");
QString strSubTitle("");
strTitle = tr("Showing");
// add the object channel map
CreateObjectChannelMap(pkBaseObject, pkParent, strTitle, pkParentWidget);
T_SCALEOBJECT *pkScaleObject = reinterpret_cast<T_SCALEOBJECT*>(pkBaseObject);
unsigned char *pucScaleObject = reinterpret_cast<unsigned char*>(pkScaleObject);
USHORT *ptScaleShortBitField = reinterpret_cast<USHORT*>(pucScaleObject + sizeof(T_BASEOBJECT));
////AutoScale	
//	CShortBitFieldData *pkAutoScaleData = new CShortBitFieldData(ptScaleShortBitField,
//																1,
//																7,
//																ms_strEnabledList,
//																bfeBool,
//																0,
//																IDS_AUTOSCALE,/*@todo add correct description to string table*/
//																true );
//	strSubTitle = CStringUtils::GetItemAtPos( ms_strEnabledList, pkScaleObject->Autoscale );
//	strTitle = tr("AutoScale");
//
//	CConfigItem *pkAutoScale = new CConfigItem(	ms_strSCALE_AUTO_SCALE_KEY,
//												strTitle,
//												strSubTitle,						
//												ctItemButton,
//												pkAutoScaleData,
//												false,
//												true,
//												0,
//												false,
//												pkParent );
//	pkParent->AddChild( pkAutoScale );
//BaseLine
CShortBitFieldData *pkBaseLineData = new CShortBitFieldData(ptScaleShortBitField, 1, 6, ms_strEnabledList, bfeBool, 0,
		IDS_BASELINE,/*@todo add correct description to string table*/
		true);
strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, pkScaleObject->Baseline);
strTitle = tr("BaseLine");
CConfigItem *pkBaseLine = new CConfigItem(ms_strSCALE_BASELINE_KEY, strTitle, strSubTitle, ctItemButton, pkBaseLineData,
		false, true, 0, false, pkParent);
pkParent->AddChild(pkBaseLine);
//Fix BaseLine Colour
CBoolData *pkFixBaseLineClrData = new CBoolData(&pkScaleObject->FixBaselineClr, 0, IDS_FIXBASELINE_CLR,	//@todo, add the right description
		true);
strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, pkScaleObject->FixBaselineClr);
strTitle = tr("Fix BaseLine Clr");
CConfigItem *pkFixBaseLineClr = new CConfigItem(ms_strSCALE_FIXBASELINE_CLR_KEY, strTitle, strSubTitle, ctItemButton,
		pkFixBaseLineClrData, false, true, 0, false, pkParent);
pkParent->AddChild(pkFixBaseLineClr);
//BaseLine Colour
CULongData *pkBaselineColourData = new CULongData(&pkScaleObject->BaselineColour, 0, ms_ulMaxColour, 0,
		IDS_BASELINE_CLR,/*@todo add correct description to string table*/
		false, dtColour);
strTitle = tr("BaseLine Color");
strSubTitle = pkBaselineColourData->GetDataAsString();
CConfigItem *pkBaselineColour = new CConfigItem(ms_strSCALE_BASELINE_COL_KEY, strTitle, strSubTitle, ctItemButton,
		pkBaselineColourData, false, (pkScaleObject->Baseline == TRUE), 0, false, pkParent);
pkParent->AddChild(pkBaselineColour);
//Full Width
CShortBitFieldData *pkFullWidthData = new CShortBitFieldData(ptScaleShortBitField, 1, 1, ms_strEnabledList, bfeBool, 0,
		IDS_FULLWIDTH,/*@todo add correct description to string table*/
		true);
strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, pkScaleObject->FullWidth);
strTitle = tr("Full Width");
CConfigItem *pkFullWidth = new CConfigItem(ms_strSCALE_FULLWIDTH_KEY, strTitle, strSubTitle, ctItemButton,
		pkFullWidthData, false, true, 0, false, pkParent);
pkParent->AddChild(pkFullWidth);
//FixGradsColour
CBoolData *pkFixGradsClrData = new CBoolData(&pkScaleObject->FixGradsColour, 0, IDS_FIXGRADS_CLR,//@todo, add the right description
		true);
strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, pkScaleObject->FixGradsColour);
strTitle = tr("Fix Grads Clr");
CConfigItem *pkFixGradsClr = new CConfigItem(ms_strSCALE_FIXGRADS_CLR_KEY, strTitle, strSubTitle, ctItemButton,
		pkFixGradsClrData, false, true, 0, false, pkParent);
pkParent->AddChild(pkFixGradsClr);
//GradsColour
CULongData *pkGradsColourData = new CULongData(&pkScaleObject->GradsColour, 0, ms_ulMaxColour, 0, IDS_GRADS_CLR,/*@todo add correct description to string table*/
false, dtColour);
strTitle = tr("Grads Color");
strSubTitle = pkGradsColourData->GetDataAsString();
CConfigItem *pkGradsColour = new CConfigItem(ms_strSCALE_GRADS_COL_KEY, strTitle, strSubTitle, ctItemButton,
		pkGradsColourData, false, true, 0, false, pkParent);
pkParent->AddChild(pkGradsColour);
//GradsDir
QString csDir = (pkScaleObject->Orientation == OBJECT_HORIZONTAL) ? ms_strScaleUpDownList : ms_strScalerightleftList;
CShortBitFieldData *pkGradsDirData = new CShortBitFieldData(ptScaleShortBitField, 1, 8, csDir, bfeSingleSelList, 0,
		IDS_GRADSDIR,/*@todo add correct description to string table*/
		true);
strSubTitle = pkGradsDirData->GetDataAsString();
strTitle = tr("Grads Direction");
CConfigItem *pkGradsDir = new CConfigItem(ms_strSCALE_GRADS_DIR_KEY, strTitle, strSubTitle, ctItemButton,
		pkGradsDirData, false, true, 0, false, pkParent);
pkParent->AddChild(pkGradsDir);
//LabelLimits
CShortBitFieldData *pkLabelLimitsData = new CShortBitFieldData(ptScaleShortBitField, 1, 2, ms_strEnabledList, bfeBool,
		0, IDS_LABELLIMITS,/*@todo add correct description to string table*/
		true);
strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, pkScaleObject->LabelLimits);
strTitle = tr("Label Limits");
CConfigItem *pkLabelLimits = new CConfigItem(ms_strSCALE_LABEL_LIMITS_KEY, strTitle, strSubTitle, ctItemButton,
		pkLabelLimitsData, false, true, 0, false, pkParent);
pkParent->AddChild(pkLabelLimits);
//Label Majors
CShortBitFieldData *pkLabelMajorsData = new CShortBitFieldData(ptScaleShortBitField, 1, 3, ms_strEnabledList, bfeBool,
		0, IDS_LABELMAJORS,/*@todo add correct description to string table*/
		true);
strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, pkScaleObject->LabelMajors);
strTitle = tr("Label Majors");
CConfigItem *pkLabelMajors = new CConfigItem(ms_strSCALE_LABEL_MAJORS_KEY, strTitle, strSubTitle, ctItemButton,
		pkLabelMajorsData, false, true, 0, false, pkParent);
pkParent->AddChild(pkLabelMajors);
//Label Position
csDir = (pkScaleObject->Orientation == OBJECT_HORIZONTAL) ? ms_strScaleTopBottomList : ms_strScalerightleftList;
CShortBitFieldData *pkLabelPositionData = new CShortBitFieldData(ptScaleShortBitField, 1, 10, csDir, bfeSingleSelList,
		0, IDS_LABELPOSITION,/*@todo add correct description to string table*/
		true);
strSubTitle = pkLabelPositionData->GetDataAsString();
strTitle = tr("Label Position");
CConfigItem *pkLabelPosition = new CConfigItem(ms_strSCALE_LABEL_POSITION_KEY, strTitle, strSubTitle, ctItemButton,
		pkLabelPositionData, false, true, 0, false, pkParent);
pkParent->AddChild(pkLabelPosition);
////Labels
//	CShortBitFieldData *pkLabelsData = new CShortBitFieldData(ptScaleShortBitField,
//																1,
//																9,
//																ms_strEnabledList,
//																bfeBool,
//																0,
//																IDS_LABELS,/*@todo add correct description to string table*/
//																true );
//	strSubTitle = CStringUtils::GetItemAtPos( ms_strEnabledList, pkScaleObject->Labels );
//	strTitle = tr("Labels");
//
//	CConfigItem *pkLabels = new CConfigItem(	ms_strSCALE_LABELS_KEY,
//												strTitle,
//												strSubTitle,						
//												ctItemButton,
//												pkLabelsData,
//												false,
//												true,
//												0,
//												false,
//												pkParent );
//	pkParent->AddChild( pkLabels );
////left Justify
//	CShortBitFieldData *pkleftJustifyData = new CShortBitFieldData(ptScaleShortBitField,
//																1,
//																0,
//																ms_strEnabledList,
//																bfeBool,
//																0,
//																IDS_LEFTJUSTIFY,/*@todo add correct description to string table*/
//																true );
//	strSubTitle = CStringUtils::GetItemAtPos( ms_strEnabledList, pkScaleObject->leftJustify );
//	strTitle = tr("left Justify");
//	strTitle = "left Justify");
//
//	CConfigItem *pkleftJustify = new CConfigItem(	ms_strSCALE_LEFT_JUSTIFY_KEY,
//												strTitle,
//												strSubTitle,						
//												ctItemButton,
//												pkleftJustifyData,
//												false,
//												true,
//												0,
//												false,
//												pkParent );
//	pkParent->AddChild( pkleftJustify );
//MajorGrads
CShortBitFieldData *pkMajorGradsData = new CShortBitFieldData(ptScaleShortBitField, 1, 4, ms_strEnabledList, bfeBool, 0,
		IDS_MAJORGRADS,/*@todo add correct description to string table*/
		true);
strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, pkScaleObject->MajorGrads);
strTitle = tr("Major Graduations");
CConfigItem *pkMajorGrads = new CConfigItem(ms_strSCALE_MAJOR_GRADS_KEY, strTitle, strSubTitle, ctItemButton,
		pkMajorGradsData, false, true, 0, false, pkParent);
pkParent->AddChild(pkMajorGrads);
//MajorLength
CUShortData *pkMajorLengthData = new CUShortData(&pkScaleObject->MajorLength, 0, USHRT_MAX, 0, IDS_MAJOR_LENGTH,/*@todo add correct description to string table*/
false);
strTitle = tr("Major Grad Length");
CConfigItem *pkMajorLength = new CConfigItem(ms_strSCALE_MAJOR_LENGTH_KEY, strTitle,
		pkMajorLengthData->GetDataAsString(), ctItemButton, pkMajorLengthData, false,
		(pkScaleObject->MajorGrads == TRUE), 0, false, pkParent);
pkParent->AddChild(pkMajorLength);
//Minor Grads
CShortBitFieldData *pkMinorGradsData = new CShortBitFieldData(ptScaleShortBitField, 1, 5, ms_strEnabledList, bfeBool, 0,
		IDS_MINORGRADS,/*@todo add correct description to string table*/
		true);
strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, pkScaleObject->MinorGrads);
strTitle = tr("Minor Graduations");
CConfigItem *pkMinorGrads = new CConfigItem(ms_strSCALE_MINOR_GRADS_KEY, strTitle, strSubTitle, ctItemButton,
		pkMinorGradsData, false, true, 0, false, pkParent);
pkParent->AddChild(pkMinorGrads);
//Minor Length
CUShortData *pkMinorLengthData = new CUShortData(&pkScaleObject->MinorLength, 0, USHRT_MAX, 0, IDS_MINOR_LENGTH,/*@todo add correct description to string table*/
false);
strTitle = tr("Minor Grad Length");
CConfigItem *pkMinorLength = new CConfigItem(ms_strSCALE_MINOR_LENGTH_KEY, strTitle,
		pkMinorLengthData->GetDataAsString(), ctItemButton, pkMinorLengthData, false,
		(pkScaleObject->MinorGrads == TRUE), 0, false, pkParent);
pkParent->AddChild(pkMinorLength);
//Orientation
CShortBitFieldData *pkOrientationData = new CShortBitFieldData(ptScaleShortBitField, 1, 11, ms_strOrientationList,
		bfeSingleSelList, 0, IDS_ORIENTATION, true);
strSubTitle = pkOrientationData->GetDataAsString();
strTitle = tr("Orientation");
CConfigItem *pkOrientation = new CConfigItem(ms_strLYT_ORIENTATION_KEY, strTitle, strSubTitle, ctItemButton,
		pkOrientationData, false, true, 0, false, pkParent);
pkParent->AddChild(pkOrientation);
//Major Font Height
CShortBitFieldData *pkMajorHeightData = new CShortBitFieldData(reinterpret_cast<USHORT*>(&pkScaleObject->MajorFont), 10,
		0, NULL, bfeNumerical, 0, 0, true, 5, 600);
strTitle = tr("Major Font Height");
CConfigItem *pkMajorHeight = new CConfigItem(ms_strSCALE_LIMIT_FONT_HEIGHT_KEY, strTitle,
		pkMajorHeightData->GetDataAsString(), ctItemButton, pkMajorHeightData, false, true, 0, false, pkParent);
pkParent->AddChild(pkMajorHeight);
//Limit Font Height
CShortBitFieldData *pkLimitHeightData = new CShortBitFieldData(reinterpret_cast<USHORT*>(&pkScaleObject->LimitFont), 10,
		0, NULL, bfeNumerical, 0, 0, true, 5, 600);
strTitle = tr("Limit Font Height");
CConfigItem *pkLimitHeight = new CConfigItem(ms_strSCALE_MAJOR_FONT_HEIGHT_KEY, strTitle,
		pkLimitHeightData->GetDataAsString(), ctItemButton, pkLimitHeightData, false, true, 0, false, pkParent);
pkParent->AddChild(pkLimitHeight);
//FixNumasprintf
CBoolData *pkFixNumasprintfData = new CBoolData(&pkScaleObject->FixNumasprintf, 0, IDS_FIX_NUMFORMAT,//@todo, add the right description
		true);
strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, pkScaleObject->FixNumasprintf);
strTitle = tr("Fix Number asprintf");
CConfigItem *pkFixNumasprintf = new CConfigItem(ms_strSCALE_FIX_NUMFORMAT_KEY, strTitle, strSubTitle, ctItemButton,
		pkFixNumasprintfData, false, true, 0, false, pkParent);
pkParent->AddChild(pkFixNumasprintf);
if (pkScaleObject->FixNumasprintf)
	SetupNumasprintf(pkParent, &pkScaleObject->Numasprintf);
// Add the submenu/category base object properties
CreateBaseSubMenuPropsConfigData(pkBaseObject, pkParent);
return pkParent;
}
//****************************************************************************
// CConfigInterface *CreatePenPointersObjConfig(	T_BASEOBJECT* pkBaseObject,
//													CWidget *pkParentWidget);
///
/// Method that creates a example bar config hierarchy
///
/// @param[in]			T_BASEOBJECT* pkBaseObject - Pointer to the base object we 
///						are creating the configuration tree for
/// @param[in]			CWidget *pkParentWidget - Pointer to the widget this object is on
///
/// @return Pointer to the top-level parent of a example bar config hierarchy
///
//****************************************************************************
CConfigBranch* CScrnDesCfgMgr::CreatePenPointersObjConfig(T_BASEOBJECT *pkBaseObject, CWidget *pkParentWidget) {
CConfigBranch *pkParent = NULL;
// firstly create the top level config interface class
QString strPenPointersObjectTitle("");
strPenPointersObjectTitle = pkParentWidget->GetObjectName(pkBaseObject);
pkParent = new CConfigBranch(ms_strPENPOINTERS_OBJ_TITLE_KEY, strPenPointersObjectTitle, strPenPointersObjectTitle,
		ctMainMenuButton, false, true, 0, false, NULL);
// Add the general base object properties
CreateBasePropsConfigData(pkBaseObject, pkParent);
//pen pointers object specific
QString strTitle("");
QString strSubTitle("");
strTitle = tr("Showing");
// add the object channel map
CreateObjectChannelMap(pkBaseObject, pkParent, strTitle, pkParentWidget);
T_PENPTRSOBJECT *pkPenPtrsObject = reinterpret_cast<T_PENPTRSOBJECT*>(pkBaseObject);
unsigned char *pucPenPtrsObject = reinterpret_cast<unsigned char*>(pkPenPtrsObject);
USHORT *ptPenPtrsShortBitField = reinterpret_cast<USHORT*>(pucPenPtrsObject + sizeof(T_BASEOBJECT));
//FGAlCol
CULongData *pkFGAlColData = new CULongData(&pkPenPtrsObject->FGAlarmCol, 0, ms_ulMaxColour, 0, IDS_FGALARM_CLR,/*@todo add correct description to string table*/
false, dtColour);
strTitle = tr("ForeGround Alarm Color");
strSubTitle = pkFGAlColData->GetDataAsString();
CConfigItem *pkFGAlCol = new CConfigItem(ms_strPENPTRS_FGALARM_COL_KEY, strTitle, strSubTitle, ctItemButton,
		pkFGAlColData, false, true, 0, false, pkParent);
pkParent->AddChild(pkFGAlCol);
//FlshFGonAl
CBoolData *pkFlshFGOnAlData = new CBoolData(&pkPenPtrsObject->FlshFGonAlarm, 0, IDS_FLASH_FG_ONALARM,/*@todo add correct description to string table*/
true);
strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, pkPenPtrsObject->FlshFGonAlarm);
strTitle = tr("Flash Foreground On Alarm");
CConfigItem *pkFlshFGOnAl = new CConfigItem(ms_strPENPTRS_FLASH_FG_ONALARM_KEY, strTitle, strSubTitle, ctItemButton,
		pkFlshFGOnAlData, false, true, 0, false, pkParent);
pkParent->AddChild(pkFlshFGOnAl);
//FixFGAlCol
CBoolData *pkFixFGAlColData = new CBoolData(&pkPenPtrsObject->FixFGAlarmCol, 0, IDS_FIX_FG_ALARM_COL,/*@todo add correct description to string table*/
true);
strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, pkPenPtrsObject->FixFGAlarmCol);
strTitle = tr("Fix Foreground Alarm Color");
CConfigItem *pkFixFGAlCol = new CConfigItem(ms_strPENPTRS_FIX_FG_ALARM_COL_KEY, strTitle, strSubTitle, ctItemButton,
		pkFixFGAlColData, false, true, 0, false, pkParent);
pkParent->AddChild(pkFixFGAlCol);
//Height
CUShortData *pkHeightData = new CUShortData(&pkPenPtrsObject->Height, 0, USHRT_MAX, 0, IDS_HEIGHT,/*@todo add correct description to string table*/
false);
strTitle = tr("Height");
CConfigItem *pkHeight = new CConfigItem(ms_strPENPTRS_HEIGHT_KEY, strTitle, pkHeightData->GetDataAsString(),
		ctItemButton, pkHeightData, false, true, 0, false, pkParent);
pkParent->AddChild(pkHeight);
//Orientation
CShortBitFieldData *pkOrientationData = new CShortBitFieldData(ptPenPtrsShortBitField, 1, 0, ms_strOrientationList,
		bfeSingleSelList, 0, IDS_ORIENTATION, true);
strSubTitle = pkOrientationData->GetDataAsString();
strTitle = tr("Orientation");
CConfigItem *pkOrientation = new CConfigItem(ms_strLYT_ORIENTATION_KEY, strTitle, strSubTitle, ctItemButton,
		pkOrientationData, false, true, 0, false, pkParent);
pkParent->AddChild(pkOrientation);
// Add the submenu/category base object properties
CreateBaseSubMenuPropsConfigData(pkBaseObject, pkParent);
return pkParent;
}
//****************************************************************************
///
/// Method that creates a tabular display object config hierarchy
///
/// @param[in]			T_BASEOBJECT* pkBaseObject - Pointer to the base object we 
///						are creating the configuration tree for
/// @param[in]			CWidget *pkParentWidget - Pointer to the widget this object is on
///
/// @return Pointer to the top-level parent of a tabular display object config hierarchy
///
//****************************************************************************
CConfigBranch* CScrnDesCfgMgr::CreateTabularDisplayObjConfig(T_BASEOBJECT *pkBaseObject, CWidget *pkParentWidget) {
CConfigBranch *pkParent = NULL;
// firstly create the top level config interface class
QString strTabularDisplayObjectTitle("");
strTabularDisplayObjectTitle = pkParentWidget->GetObjectName(pkBaseObject);
pkParent = new CConfigBranch(ms_strTAB_DISP_OBJ_TITLE_KEY, strTabularDisplayObjectTitle, strTabularDisplayObjectTitle,
		ctMainMenuButton, false, true, 0, false, NULL);
// Add the general base object properties
CreateBasePropsConfigData(pkBaseObject, pkParent);
// tabular display object specific
QString strTitle("");
strTitle = tr("Showing");
// add the object channel map
CreateObjectChannelMap(pkBaseObject, pkParent, strTitle, pkParentWidget);
T_TABULAROBJECT *pkTabularDisplayObject = reinterpret_cast<T_TABULAROBJECT*>(pkBaseObject);
unsigned char *pucTabularDisplayObject = reinterpret_cast<unsigned char*>(pkTabularDisplayObject);
USHORT *ptTabDispShortBitField = reinterpret_cast<USHORT*>(pucTabularDisplayObject + sizeof(T_BASEOBJECT));
//FlshFGonAl
CShortBitFieldData *pkFlshFGOnAlData = new CShortBitFieldData(ptTabDispShortBitField, 1, 1, ms_strEnabledList, bfeBool,
		0, 0, true);
strTitle = tr("Flash Foreground On Alarm");
CConfigItem *pkFlshFGOnAl = new CConfigItem(ms_strTAB_DISP_FLASH_FG_ONALARM_KEY, strTitle,
		pkFlshFGOnAlData->GetDataAsString(), ctItemButton, pkFlshFGOnAlData, false, true, 0, false, pkParent);
pkParent->AddChild(pkFlshFGOnAl);
if (pkTabularDisplayObject->FlshFGonAlarm) {
	//FixFGAlCol
	CShortBitFieldData *pkFixFGAlColData = new CShortBitFieldData(ptTabDispShortBitField, 1, 0, ms_strEnabledList,
			bfeBool, 0, 0, true);
	strTitle = tr("Fix Foreground Alarm Color");
	CConfigItem *pkFixFGAlCol = new CConfigItem(ms_strTAB_DISP_FIX_FG_ALARM_COL_KEY, strTitle,
			pkFixFGAlColData->GetDataAsString(), ctItemButton, pkFixFGAlColData, false, true, 0, false, pkParent);
	pkParent->AddChild(pkFixFGAlCol);
	if (pkTabularDisplayObject->FixFGAlarmCol) {
		//FGAlCol
		CULongData *pkFGAlColData = new CULongData(&pkTabularDisplayObject->FGAlarmCol, 0, ms_ulMaxColour, 0,
				IDS_FGALARM_CLR,/*@todo add correct description to string table*/
				false, dtColour);
		strTitle = tr("ForeGround Alarm Color");
		CConfigItem *pkFGAlCol = new CConfigItem(ms_strTAB_DISP_FGALARM_COL_KEY, strTitle,
				pkFGAlColData->GetDataAsString(), ctItemButton, pkFGAlColData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkFGAlCol);
	}
}
// Use pens colours for text
CShortBitFieldData *pkUsePenColData = new CShortBitFieldData(ptTabDispShortBitField, 1, 2, ms_strEnabledList, bfeBool,
		0, 0, true);
//strTitle.LoadString( IDS_LYT_TABULAR_OBJ_USE_PEN_COL_TITLE );
strTitle = QString::fromWCharArray(L"Use Pen Colours");
CConfigItem *pkUsePenCol = new CConfigItem(ms_strTAB_DISP_FIX_FG_ALARM_COL_KEY, strTitle,
		pkUsePenColData->GetDataAsString(), ctItemButton, pkUsePenColData, false, true, 0, false, pkParent);
pkParent->AddChild(pkUsePenCol);
// Add the submenu/category base object properties
CreateBaseSubMenuPropsConfigData(pkBaseObject, pkParent);
return pkParent;
}
//****************************************************************************
///
/// Method that creates a TUS object config hierarchy
///
/// @param[in]			T_BASEOBJECT* pkBaseObject - Pointer to the base object we 
///						are creating the configuration tree for
/// @param[in]			CWidget *pkParentWidget - Pointer to the widget this object is on
///
/// @return Pointer to the top-level parent of a TUS object config hierarchy
///
//****************************************************************************
CConfigBranch* CScrnDesCfgMgr::CreateTUSObjConfig(T_BASEOBJECT *pkBaseObject, CWidget *pkParentWidget) {
CConfigBranch *pkParent = NULL;
// firstly create the top level config interface class
QString strTUSObjectTitle("");
strTUSObjectTitle = pkParentWidget->GetObjectName(pkBaseObject);
pkParent = new CConfigBranch(ms_strTAB_DISP_OBJ_TITLE_KEY, strTUSObjectTitle, strTUSObjectTitle, ctMainMenuButton,
		false, true, 0, false, NULL);
// Add the general base object properties
CreateBasePropsConfigData(pkBaseObject, pkParent);
// Add the submenu/category base object properties
CreateBaseSubMenuPropsConfigData(pkBaseObject, pkParent);
return pkParent;
}
//****************************************************************************
// CConfigInterface *CreateButtonObjConfig(	T_BASEOBJECT* pkBaseObject,
//												CWidget *pkParentWidget );
///
/// Method that creates a button object config hierarchy
///
/// @param[in]			T_BASEOBJECT* pkBaseObject - Pointer to the base object we 
///						are creating the configuration tree for
/// @param[in]			CWidget *pkParentWidget - Pointer to the widget this object is on
///
/// @return Pointer to the top-level parent of a button object config hierarchy
///
//****************************************************************************
CConfigBranch* CScrnDesCfgMgr::CreateButtonObjConfig(T_BASEOBJECT *pkBaseObject, CWidget *pkParentWidget) {
CConfigBranch *pkParent = NULL;
// firstly create the top level config interface class
QString strButtonObjectTitle("");
strButtonObjectTitle = pkParentWidget->GetObjectName(pkBaseObject);
pkParent = new CConfigBranch(ms_strBUTTON_OBJ_TITLE_KEY, strButtonObjectTitle, strButtonObjectTitle, ctMainMenuButton,
		false, true, 0, false, NULL);
// Add the general base object properties
CreateBasePropsConfigData(pkBaseObject, pkParent);
//create General button specific properties
QString strTitle("");
QString strSubTitle("");
strTitle = tr("Showing");
// add the object channel map
CreateObjectChannelMap(pkBaseObject, pkParent, strTitle, pkParentWidget);
T_BUTTONOBJECT *pkButtonObject = reinterpret_cast<T_BUTTONOBJECT*>(pkBaseObject);
unsigned char *pucButtonObject = reinterpret_cast<unsigned char*>(pkButtonObject);
USHORT *ptButtonShortBitField = reinterpret_cast<USHORT*>(pucButtonObject + sizeof(T_BASEOBJECT));
// Text - WCHAR edit
CStringCfgData
*pkTextData = new CStringCfgData(pkButtonObject->Text,
		BUTTONOBJECT_TEXT_LEN, dtString, 0, 0, false);
strTitle = QString::fromWCharArray(L"Text");
CConfigItem *pkText = new CConfigItem(ms_strBUTTON_TEXT_TITLE_KEY, strTitle, pkTextData->GetDataAsString(),
		ctItemButton, pkTextData, false, true, 0, false, pkParent);
pkParent->AddChild(pkText);
// Add the submenu/category base object properties
CreateBaseSubMenuPropsConfigData(pkBaseObject, pkParent);
return pkParent;
}
//****************************************************************************
// CConfigInterface *CreateAlarmMrkrObjConfig( T_BASEOBJECT* pkBaseObject,
//												CWidget *pkParentWidget );
///
/// Method that creates a example bar config hierarchy
///
/// @param[in]			T_BASEOBJECT* pkBaseObject - Pointer to the base object we 
///						are creating the configuration tree for
/// @param[in]			CWidget *pkParentWidget - Pointer to the widget this object is on
///
/// @return Pointer to the top-level parent of a example bar config hierarchy
///
//****************************************************************************
CConfigBranch* CScrnDesCfgMgr::CreateAlarmMrkrObjConfig(T_BASEOBJECT *pkBaseObject, CWidget *pkParentWidget) {
CConfigBranch *pkParent = NULL;
// firstly create the top level config interface class
QString strAlarmMrkrObjectTitle("");
strAlarmMrkrObjectTitle = pkParentWidget->GetObjectName(pkBaseObject);
pkParent = new CConfigBranch(ms_strALARMMRKR_OBJ_TITLE_KEY, strAlarmMrkrObjectTitle, strAlarmMrkrObjectTitle,
		ctMainMenuButton, false, true, 0, false, NULL);
// Add the general base object properties
CreateBasePropsConfigData(pkBaseObject, pkParent);
//create General AlarmMarker specific properties
QString strTitle("");
QString strSubTitle("");
strTitle = tr("Showing");
// add the object channel map
CreateObjectChannelMap(pkBaseObject, pkParent, strTitle, pkParentWidget);
T_ALARMMRKROBJECT *pkAlarmObject = reinterpret_cast<T_ALARMMRKROBJECT*>(pkBaseObject);
unsigned char *pucAlarmObject = reinterpret_cast<unsigned char*>(pkAlarmObject);
USHORT *ptAlarmShortBitField = reinterpret_cast<USHORT*>(pucAlarmObject + sizeof(T_BASEOBJECT));
//height
CUShortData *pkHeightData = new CUShortData(&pkAlarmObject->Height, 0, USHRT_MAX, 0, IDS_HEIGHT_DESCR, false);
strTitle = tr("Height");
CConfigItem *pkHeight = new CConfigItem(ms_str_ALARM_HEIGHT_KEY, strTitle, pkHeightData->GetDataAsString(),
		ctItemButton, pkHeightData, false, true, 0, false, pkParent);
pkParent->AddChild(pkHeight);
//InAlNoAckFlshCol
CULongData *pkInAlNoAckFlColourData = new CULongData(&pkAlarmObject->InAlNoAckFlCol, 0, ms_ulMaxColour, 0,
		IDS_INALARM_NOTACKED_FLASHCLR_DESCR, false, dtColour);
strTitle = tr("In Alarm Not Acked FlashClr");
strSubTitle = pkInAlNoAckFlColourData->GetDataAsString();
CConfigItem *pkInAlNoAckFlColour = new CConfigItem(ms_strALARM_INALARM_NOACK_FLASHCLR_KEY, strTitle, strSubTitle,
		ctItemButton, pkInAlNoAckFlColourData, false, true, 0, false, pkParent);
pkParent->AddChild(pkInAlNoAckFlColour);
//InAlAckFlshCol
CULongData *pkInAlAckFlColourData = new CULongData(&pkAlarmObject->InAlAckFlCol, 0, ms_ulMaxColour, 0,
		IDS_INALARM_ACKED_FLASHCLR_DESCR, false, dtColour);
strTitle = tr("In Alarm Acked FlashClr");
strSubTitle = pkInAlAckFlColourData->GetDataAsString();
CConfigItem *pkInAlAckFlColour = new CConfigItem(ms_strALARM_INALARM_ACK_FLASHCLR_KEY, strTitle, strSubTitle,
		ctItemButton, pkInAlAckFlColourData, false, true, 0, false, pkParent);
pkParent->AddChild(pkInAlAckFlColour);
//OutAlNoAckFlCol
CULongData *pkOutAlNoAckFlColourData = new CULongData(&pkAlarmObject->OutAlNoAckFlCol, 0, ms_ulMaxColour, 0,
		IDS_OUTALARM_NOTACKED_FLASHCLR_DESCR, false, dtColour);
strTitle = tr("Out of Alarm NotAcked FlashClr");
strSubTitle = pkOutAlNoAckFlColourData->GetDataAsString();
CConfigItem *pkOutAlNoAckFlColour = new CConfigItem(ms_strALARM_OUTALARM_NOACK_FLASHCLR_KEY, strTitle, strSubTitle,
		ctItemButton, pkOutAlNoAckFlColourData, false, true, 0, false, pkParent);
pkParent->AddChild(pkOutAlNoAckFlColour);
//OutAlFlCol
CULongData *pkOutAlAckFlColourData = new CULongData(&pkAlarmObject->OutAlFlCol, 0, ms_ulMaxColour, 0,
		IDS_OUTALARM_FLASHCLR_DESCR, false, dtColour);
strTitle = tr("Out of Alarm Acked FlashClr");
strSubTitle = pkOutAlAckFlColourData->GetDataAsString();
CConfigItem *pkOutAlAckFlColour = new CConfigItem(ms_strALARM_OUTALARM_FLASHCLR_KEY, strTitle, strSubTitle,
		ctItemButton, pkOutAlAckFlColourData, false, true, 0, false, pkParent);
pkParent->AddChild(pkOutAlAckFlColour);
//orientation
CShortBitFieldData *pkOrientationData = new CShortBitFieldData(ptAlarmShortBitField, 1, 0, ms_strOrientationList,
		bfeSingleSelList, 0, IDS_ORIENTATION, true);
strSubTitle = pkOrientationData->GetDataAsString();
strTitle = tr("Orientation");
CConfigItem *pkOrientation = new CConfigItem(ms_strLYT_ORIENTATION_KEY, strTitle, strSubTitle, ctItemButton,
		pkOrientationData, false, true, 0, false, pkParent);
pkParent->AddChild(pkOrientation);
//////////////
//InAlNotAckFlash
CShortBitFieldData *pkInAlarmNotAckData = new CShortBitFieldData(ptAlarmShortBitField, 1, 1, ms_strEnabledList, bfeBool,
		0, IDS_INALARM_NOTACKED_FLASH_DESCR, true);
strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, pkAlarmObject->InAlNotAckFlsh);
strTitle = tr("In Alarm Not Acked Flashing");
CConfigItem *pkpkInAlarmNotAck = new CConfigItem(ms_strALARM_INALARM_NOTACK_KEY, strTitle, strSubTitle, ctItemButton,
		pkInAlarmNotAckData, false, true, 0, false, pkParent);
pkParent->AddChild(pkpkInAlarmNotAck);
//InAlAckFlash
CShortBitFieldData *pkInAlarmAckData = new CShortBitFieldData(ptAlarmShortBitField, 1, 2, ms_strEnabledList, bfeBool, 0,
		IDS_INALARM_ACKED_FLASH_DESCR, true);
strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, pkAlarmObject->InAlAckedFlsh);
strTitle = tr("In Alarm Acked Flashing");
CConfigItem *pkpkInAlarmAck = new CConfigItem(ms_strALARM_INALARM_ACK_KEY, strTitle, strSubTitle, ctItemButton,
		pkInAlarmAckData, false, true, 0, false, pkParent);
pkParent->AddChild(pkpkInAlarmAck);
//OutAlNotAckFlash
CShortBitFieldData *pkOutAlarmNotAckData = new CShortBitFieldData(ptAlarmShortBitField, 1, 3, ms_strEnabledList,
		bfeBool, 0, IDS_OUTALARM_NOTACKED_FLASH_DESCR, true);
strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, pkAlarmObject->OutAlNoAckFlsh);
strTitle = tr("Out of Alarm Not Acked Flashing");
CConfigItem *pkpkOutAlarmNotAck = new CConfigItem(ms_strALARM_OUTALARM_NOTACK_KEY, strTitle, strSubTitle, ctItemButton,
		pkOutAlarmNotAckData, false, true, 0, false, pkParent);
pkParent->AddChild(pkpkOutAlarmNotAck);
//HideInactiveAlarm
CShortBitFieldData *pkHideInactiveAlData = new CShortBitFieldData(ptAlarmShortBitField, 1, 4, ms_strEnabledList,
		bfeBool, 0, IDS_HIDE_INACTIVE_ALARM_DESCR, true);
strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, pkAlarmObject->HideInactiveAl);
strTitle = tr("Hide Inactive Alarm");
CConfigItem *pkHideInactiveAl = new CConfigItem(ms_strALARM_HIDE_INACTIVE_ALARM_KEY, strTitle, strSubTitle,
		ctItemButton, pkHideInactiveAlData, false, true, 0, false, pkParent);
pkParent->AddChild(pkHideInactiveAl);
//Use global flash colour
CShortBitFieldData *pkFlashClrSelectData = new CShortBitFieldData(ptAlarmShortBitField, 1, 5, ms_strEnabledList,
		bfeBool, 0, IDS_FLASHCLR_SELECT_DESCR, true);
strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, pkAlarmObject->FlashClrSelect);
strTitle = tr("Select Flash Color Source");
CConfigItem *pkFlashClrSelect = new CConfigItem(ms_strALARM_USE_GLOBAL_FLASHCLR_KEY, strTitle, strSubTitle,
		ctItemButton, pkFlashClrSelectData, false, true, 0, false, pkParent);
pkParent->AddChild(pkFlashClrSelect);
// Add the submenu/category base object properties
CreateBaseSubMenuPropsConfigData(pkBaseObject, pkParent);
return pkParent;
}
#ifndef DOCVIEW
//****************************************************************************
//	const bool LoadConfiguration( const QString   &rstrFILE_NAME )
///
/// Method that loads a new layout
///
//****************************************************************************
const bool CScrnDesCfgMgr::LoadConfiguration(const QString &rstrFILE_NAME) {
QString strTemplateExt("");
strTemplateExt = tr("tpl");
bool bReturn = false;
// check if this is a template file or not
if (rstrFILE_NAME.indexOf(strTemplateExt) == -1) {
	// layout
	T_MOD_CFG_CHG_MSGDATA msg;
	msg.TypeOfConfigChange = MOD_CFG_CHG_LAYOUT;
	msg.configChangeSystemAction = MOD_SYS_CFG_CHG_NORMAL_OPERATION;
	msg.ConfigChangeAction = MOD_CFG_CHG_ACTION_LOAD_NEW;
	CStringUtils::SafeWcsCpy(msg.fileNameAndPath, rstrFILE_NAME, MAX_PATH);
	if (MMMCLIENT_MESSAGE_COMPLETED
			== m_ModuleMessageManagerClient.MMMClientPostIntMsgAndWait( INFINITE, m_dwPOST_MESSAGE_WAIT_TIMEOUT,
					MODULE_CONTROL_SEQUENCER, MODULE_LAYOUT_CFG_MGR, MOD_CONFIG_CHANGE, sizeof(T_MOD_CFG_CHG_MSGDATA),
					(BYTE*) &msg)) {
		bReturn = true;
	}
} else {
	// templates
	CStorage kTemplateFile(rstrFILE_NAME, QFile::ReadOnly);
	COpPanel *pkOpPanel = reinterpret_cast<COpPanel*>(AfxGetApp()->m_pMainWnd);
	pkOpPanel->EnterDesignerMode();
	bReturn = (pGlbLayout->InsertTemplateFromFile(kTemplateFile) == TRUE);
	CScrnDesCfgMgr *pkConfigSysMgr = CScrnDesCfgMgr::Instance();
	pkConfigSysMgr->SetModified(true);
	pkOpPanel->LeaveDesignerMode();
}
return bReturn;
}
#endif
//****************************************************************************
//	T_CONFIG_RETURN_VALUE SaveConfiguration( const QString   &rstrFILE_NAME ) const
///
/// Method that saves the current layout
///
//****************************************************************************
T_CONFIG_RETURN_VALUE CScrnDesCfgMgr::SaveConfiguration(const QString &rstrFILE_NAME) const {
CStorage kConfigFile;
kConfigFile.Open(rstrFILE_NAME, | QFile::WriteOnly);
T_CONFIG_RETURN_VALUE eRetVal = CONFIG_ERROR;
if (pGlbLayout != NULL) {
	pGlbLayout->SaveConfig(kConfigFile);
}
kConfigFile.Close();
return eRetVal;
}
//****************************************************************************
// CConfigInterface *CreateDigObjConfig(	T_BASEOBJECT* pkBaseObject,
//											CWidget *pkParentWidget );
///
/// Method that creates a Digital Object config hierarchy
///
/// @param[in]			T_BASEOBJECT* pkBaseObject - Pointer to the base object we 
///						are creating the configuration tree for
/// @param[in]			CWidget *pkParentWidget - Pointer to the widget this object is on
///
/// @return Pointer to the top-level parent of a example bar config hierarchy
///
//****************************************************************************
CConfigBranch* CScrnDesCfgMgr::CreateDigObjConfig(T_BASEOBJECT *pkBaseObject, CWidget *pkParentWidget) {
CConfigBranch *pkParent = NULL;
// firstly create the top level config interface class
QString strDigObjectTitle("");
strDigObjectTitle = pkParentWidget->GetObjectName(pkBaseObject);
pkParent = new CConfigBranch(ms_strDIGITAL_OBJ_TITLE_KEY, strDigObjectTitle, strDigObjectTitle, ctMainMenuButton, false,
		true, 0, false, NULL);
// Add the general base object properties
CreateBasePropsConfigData(pkBaseObject, pkParent);
QString strTitle("");
QString strSubTitle("");
strTitle = tr("Showing");
// add the object channel map
CreateObjectChannelMap(pkBaseObject, pkParent, strTitle, pkParentWidget);
T_DIGITALOBJECT *pkDigObject = reinterpret_cast<T_DIGITALOBJECT*>(pkBaseObject);
unsigned char *pucDigObject = reinterpret_cast<unsigned char*>(pkDigObject);
USHORT *ptDigitalShortBitField = reinterpret_cast<USHORT*>(pucDigObject + sizeof(T_BASEOBJECT));
// EnableAlarm 
CShortBitFieldData *pkEnableAlarmData = new CShortBitFieldData(ptDigitalShortBitField, 1, 1, ms_strEnabledList, bfeBool,
		0, IDS_FIX_NUMFORMAT, /// @todo - Add IDS_ENABLE_ALARM here
		true);
strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, pkDigObject->EnableAlarm);
//	strTitle.LoadString( IDS)ENABLE_ALARM );												/// @todo - Add IDS_ENABLE_ALARM here
strTitle = QString::fromWCharArray(L"Enable Alarm");
CConfigItem *pkEnableAlarm = new CConfigItem(ms_strDIGITAL_ENABLE_ALARM_KEY, strTitle, strSubTitle, ctItemButton,
		pkEnableAlarmData, false, true, 0, false, pkParent);
pkParent->AddChild(pkEnableAlarm);
//FlashFGOnAl
CShortBitFieldData *pkFlashFGOnAlData = new CShortBitFieldData(ptDigitalShortBitField, 1, 2, ms_strEnabledList, bfeBool,
		0, IDS_FLASH_FG_ONALARM,/*@todo add correct description to string table*/
		false);
strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, pkDigObject->FlshFGonAlarm);
strTitle = tr("Flash Foreground On Alarm");
CConfigItem *pkFlashFGOnAl = new CConfigItem(ms_strDIGITAL_FLASH_FG_ONALARM_KEY, strTitle, strSubTitle, ctItemButton,
		pkFlashFGOnAlData, false, pkDigObject->EnableAlarm == TRUE, 0, false, pkParent);
pkParent->AddChild(pkFlashFGOnAl);
//FlashBGOnAl
CShortBitFieldData *pkFlashBGOnAlData = new CShortBitFieldData(ptDigitalShortBitField, 1, 3, ms_strEnabledList, bfeBool,
		0, IDS_FLASH_BG_ONALARM,/*@todo add correct description to string table*/
		false);
strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, pkDigObject->FlshBGonAlarm);
strTitle = tr("Flash Bkground on Alarm");
CConfigItem *pkFlashBGOnAl = new CConfigItem(ms_strDIGITAL_FLASH_BG_ONALARM_KEY, strTitle, strSubTitle, ctItemButton,
		pkFlashBGOnAlData, false, pkDigObject->EnableAlarm == TRUE, 0, false, pkParent);
pkParent->AddChild(pkFlashBGOnAl);
//ChgFGOnAlarm
CShortBitFieldData *pkChgFGOnAlarmData = new CShortBitFieldData(ptDigitalShortBitField, 1, 4, ms_strEnabledList,
		bfeBool, 0, IDS_CHANGE_FG_ONALARM,/*@todo add correct description to string table*/
		false);
strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, pkDigObject->ChgFGonAlarm);
strTitle = tr("Change ForeClr On Alarm");
CConfigItem *pkChgFGOnAlarm = new CConfigItem(ms_strDIGITAL_CHG_FG_ONALARM_KEY, strTitle, strSubTitle, ctItemButton,
		pkChgFGOnAlarmData, false, pkDigObject->EnableAlarm == TRUE, 0, false, pkParent);
pkParent->AddChild(pkChgFGOnAlarm);
//FGAlarmCol
// Add the marker colour - this is a ULONG
CULongData *pkFGAlarmColData = new CULongData(&pkDigObject->FGAlarmCol, 0, ms_ulMaxColour, 0, IDS_FG_ALARMCLR_DESCR,
		false, dtColour);
strSubTitle = pkFGAlarmColData->GetDataAsString();
strTitle = tr("Foreground Alarm Clr");
CConfigItem *pkFGAlarmCol = new CConfigItem(ms_strDIGITAL_FG_ALARM_COL_KEY, strTitle, strSubTitle, ctItemButton,
		pkFGAlarmColData, false, true, 0, false, pkParent);
pkParent->AddChild(pkFGAlarmCol);
//FixNumasprintf
CShortBitFieldData *pkFixNumasprintfData = new CShortBitFieldData(ptDigitalShortBitField, 1, 0, ms_strEnabledList,
		bfeBool, 0, IDS_FIX_NUMFORMAT, true);
strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, pkDigObject->FixNumasprintf);
strTitle = tr("Fix Number asprintf");
CConfigItem *pkFixNumasprintf = new CConfigItem(ms_strDIGITAL_FIX_NUMFORMAT_KEY, strTitle, strSubTitle, ctItemButton,
		pkFixNumasprintfData, false, true, 0, false, pkParent);
pkParent->AddChild(pkFixNumasprintf);
if (pkDigObject->FixNumasprintf)
	SetupNumasprintf(pkParent, &pkDigObject->Numformat);
// Add the submenu/category base object properties
CreateBaseSubMenuPropsConfigData(pkBaseObject, pkParent);
return pkParent;
}
//****************************************************************************
// CConfigInterface *CreateTextObjConfig(	T_BASEOBJECT* pkBaseObject, 
//											CLayoutItem *pkLayoutItem );
///
/// Method that creates a Text Object config hierarchy
///
/// @param[in]		T_BASEOBJECT* ptCMMBaseObject - Pointer to the CMM base object
/// @param[in]		CLayoutItem *pkLayoutItem - Pointer to the C++ object
///
/// @return Pointer to the top-level parent of a example bar config hierarchy
///
//****************************************************************************
CConfigBranch* CScrnDesCfgMgr::CreateTextObjConfig(T_BASEOBJECT *ptCMMBaseObject, CLayoutItem *pkLayoutItem) {
CConfigBranch *pkParent = NULL;
QString strTitle("");
QString strSubTitle("");
// get a pointer to the widget
CBaseObject *pkBaseObject = static_cast<CBaseObject*>(pkLayoutItem);
CWidget *pkParentWidget = pkBaseObject->GetWidget();
// firstly create the top level config interface class
QString strTextObjectTitle("");
strTextObjectTitle = pkParentWidget->GetObjectName(ptCMMBaseObject);
pkParent = new CConfigBranch(ms_strTEXT_OBJ_TITLE_KEY, strTextObjectTitle, strTextObjectTitle, ctMainMenuButton, false,
		true, 0, false, NULL);
// Add the general base object properties
CreateBasePropsConfigData(ptCMMBaseObject, pkParent);
strTitle = tr("Showing");
// add the object channel map
CreateObjectChannelMap(ptCMMBaseObject, pkParent, strTitle, pkParentWidget);
T_TEXTOBJECT *pkTextObject = reinterpret_cast<T_TEXTOBJECT*>(ptCMMBaseObject);
unsigned char *pucTextObject = reinterpret_cast<unsigned char*>(pkTextObject);
USHORT *ptTextShortBitField = reinterpret_cast<USHORT*>(pucTextObject + sizeof(T_BASEOBJECT));
//FixText
CShortBitFieldData *pkFixTextData = new CShortBitFieldData(ptTextShortBitField, 1, 0, ms_strEnabledList, bfeBool, 0,
		IDS_FIXTEXT,	//@todo, add to string table
		true);
strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, pkTextObject->FixText);
strTitle = tr("Fix Text Objects String");
CConfigItem *pkFixText = new CConfigItem(ms_strTEXT_FIXTEXT_KEY, strTitle, strSubTitle, ctItemButton, pkFixTextData,
		false, true, 0, false, pkParent);
pkParent->AddChild(pkFixText);
// if fix text then we need to get text string
if (pkTextObject->FixText) {
	CTextObject *pkTextObj = reinterpret_cast<CTextObject*>(pkLayoutItem);
	CStringCfgData
	*pkNameData = new CStringCfgData(pkTextObj->GetTextString(),
			CTextObject::ms_usMAX_TEXT_STRING_LENGTH, dtString, 0, 0, true);
	strTitle = tr("Fix Text");
	CConfigItem *pkName = new CConfigItem(ms_strTEXT_FIX_TEXT_KEY, strTitle,
			reinterpret_cast<WCHAR*>(pkNameData->GetData()), ctItemButton, pkNameData, false, true, 0, false, pkParent);
	pkParent->AddChild(pkName);
}
//wordwrap
CShortBitFieldData *pkWordWrapData = new CShortBitFieldData(ptTextShortBitField, 1, 1, ms_strEnabledList, bfeBool, 0,
		IDS_WORDWRAP, true);
strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, pkTextObject->Wordwrap);
strTitle = tr("WordWrap");
CConfigItem *pkWordWrap = new CConfigItem(ms_strTEXT_WORDWRAP_KEY, strTitle, strSubTitle, ctItemButton, pkWordWrapData,
		false, true, 0, false, pkParent);
pkParent->AddChild(pkWordWrap);
//IsTag
CShortBitFieldData *pkIsTagData = new CShortBitFieldData(ptTextShortBitField, 1, 3, ms_strEnabledList, bfeBool, 0,
		IDS_ISTAG_DESCR,	//@todo, add to string table
		true);
strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, pkTextObject->IsTag);
strTitle = tr("IsTag");
CConfigItem *pkIsTag = new CConfigItem(ms_strTEXT_ISTAG_KEY, strTitle, strSubTitle, ctItemButton, pkIsTagData, false,
		(pkTextObject->FixText == FALSE) && (pkTextObject->IsUnits != TRUE) && (pkTextObject->IsDescription != TRUE), 0,
		false, pkParent);
pkParent->AddChild(pkIsTag);
//IsDescription
CShortBitFieldData *pkIsDescData = new CShortBitFieldData(ptTextShortBitField, 1, 5, ms_strEnabledList, bfeBool, 0,
		IDS_ISDESC_DESCR, true);
strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, pkTextObject->IsDescription);
strTitle = tr("Is Description");
CConfigItem *pkIsDesc = new CConfigItem(ms_strTEXT_ISDESC_KEY, strTitle, strSubTitle, ctItemButton, pkIsDescData, false,
		(pkTextObject->FixText == FALSE) && (pkTextObject->IsUnits != TRUE) && (pkTextObject->IsTag != TRUE), 0, false,
		pkParent);
pkParent->AddChild(pkIsDesc);
//IsUnits
CShortBitFieldData *pkIsUnitsData = new CShortBitFieldData(ptTextShortBitField, 1, 4, ms_strEnabledList, bfeBool, 0,
		IDS_ISUNITS_DESCR, //@todo, add to string table
		true);
strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, pkTextObject->IsUnits);
strTitle = tr("IsUnits");
CConfigItem *pkIsUnits = new CConfigItem(ms_strTEXT_WORDWRAP_KEY, strTitle, strSubTitle, ctItemButton, pkIsUnitsData,
		false,
		(pkTextObject->FixText == FALSE) && (pkTextObject->IsTag != TRUE) && (pkTextObject->IsDescription != TRUE), 0,
		false, pkParent);
pkParent->AddChild(pkIsUnits);
//Center
CShortBitFieldData *pkCenterData = new CShortBitFieldData(ptTextShortBitField, 1, 2, ms_strEnabledList, bfeBool, 0,
		IDS_CENTER_DESCR, //@todo, add right descr to string table
		true);
strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, pkTextObject->Center);
strTitle = tr("Center");
CConfigItem *pkCenter = new CConfigItem(ms_strTEXT_CENTER_KEY, strTitle, strSubTitle, ctItemButton, pkCenterData, false,
		true, 0, false, pkParent);
pkParent->AddChild(pkCenter);
// Add the submenu/category base object properties
CreateBaseSubMenuPropsConfigData(ptCMMBaseObject, pkParent);
// Add the font submenu data
strTitle = tr("Font");
SetupFontDetails(&pkTextObject->Font, pkParent, strTitle, (pkTextObject->Wordwrap == TRUE));
return pkParent;
}
//****************************************************************************
// CConfigInterface *CreateBitmapObjConfig(T_BASEOBJECT* pkBaseObject,
//											CWidget *pkParentWidget)
///
///											
/// Method that creates a Bitmap Object config hierarchy
///
/// @param[in]		T_BASEOBJECT* ptCMMBaseObject - Pointer to the CMM base object
/// @param[in]		CWidget *pkParentWidget - Pointer to the widget this object is on
///
/// @return Pointer to the top-level parent of a bitmap config hierarchy
///
//****************************************************************************
CConfigBranch* CScrnDesCfgMgr::CreateBitmapObjConfig(T_BASEOBJECT *ptCMMBaseObject, CWidget *pkParentWidget)
{
CConfigBranch *pkParent = NULL;
QString strTitle("");
QString strTextObjectTitle("");
strTextObjectTitle = pkParentWidget->GetObjectName(ptCMMBaseObject);
pkParent = new CConfigBranch(ms_strTEXT_OBJ_TITLE_KEY, strTextObjectTitle, strTextObjectTitle, ctMainMenuButton, false,
		true, 0, false, NULL);
// Add the general base object properties
CreateBasePropsConfigData(ptCMMBaseObject, pkParent, false, false); // false = transparency , false = colours
strTitle = tr("Showing");
T_BITMAPOBJECT *pkBitmapObject = reinterpret_cast<T_BITMAPOBJECT*>(ptCMMBaseObject);
unsigned char *pucBitmapObject = reinterpret_cast<unsigned char*>(pkBitmapObject);
// Name, WCHAR edit
CStringCfgData
*pkNameData = new CStringCfgData(pkBitmapObject->Name,
		BITMAPOBJECT_NAME_LEN, dtString, 0, 0, true);
strTitle = tr("Name");
CConfigItem *pkName = new CConfigItem(ms_strWIDGET_NAME_KEY, strTitle, pkBitmapObject->Name, ctItemButton, pkNameData,
		false, true, 0, false, pkParent);
pkParent->AddChild(pkName);
// Add the submenu/category base object properties
CreateBaseSubMenuPropsConfigData(ptCMMBaseObject, pkParent);
return pkParent;
}
//****************************************************************************
// CConfigInterface *CreateChartObjConfig( T_BASEOBJECT* pkBaseObject,
//											CWidget *pkParentWidget);
///
/// Method that creates a Chart Object config hierarchy
///
/// @param[in]			T_BASEOBJECT* pkBaseObject - Pointer to the base object we 
///						are creating the configuration tree for
/// @param[in]			CWidget *pkParentWidget - Pointer to the widget this object is on
///
/// @return Pointer to the top-level parent of a chart object config hierarchy
///
/// @todo Add the chart specfic object properties
///
//****************************************************************************
CConfigBranch* CScrnDesCfgMgr::CreateChartObjConfig(T_BASEOBJECT *pkBaseObject, CWidget *pkParentWidget) {
CConfigBranch *pkParent = NULL;
T_CHARTOBJECT *ptChartObject = reinterpret_cast<T_CHARTOBJECT*>(pkBaseObject);
// firstly create the top level config interface class
QString strTitle("");
strTitle = pkParentWidget->GetObjectName(pkBaseObject);
pkParent = new CConfigBranch(ms_strCHART_OBJ_TITLE_KEY, strTitle, strTitle, ctMainMenuButton, false, true, 0, false,
NULL);
// Add the general base object properties
CreateBasePropsConfigData(pkBaseObject, pkParent, false);
strTitle = tr("Showing");
// add the object channel map
CreateObjectChannelMap(pkBaseObject, pkParent, strTitle, pkParentWidget);
// Orientation - TV_BOOL but treat as a USHORT bitfield
CShortBitFieldData *pkOrientationData = new CShortBitFieldData(&ptChartObject->IsVertical, 1, 0, ms_strOrientationList,
		bfeSingleSelList, 0, IDS_ORIENTATION, false);
strTitle = tr("Orientation");
CConfigItem *pkOrientation = new CConfigItem(ms_strLYT_ORIENTATION_KEY, strTitle, pkOrientationData->GetDataAsString(),
		ctItemButton, pkOrientationData, false, true, 0, false, pkParent);
pkParent->AddChild(pkOrientation);
// Add the chart speed - USHORT but treat as a bitfield
CShortBitFieldData *pkChartSpeedData = new CShortBitFieldData(&ptChartObject->ChartSpeed, 2, 0,
		ms_strChartObjChartSpeedList, bfeSingleSelList, 0, 0, false);
strTitle = tr("Chart Speed");
CConfigItem *pkChartSpeed = new CConfigItem(ms_strCHART_OBJ_CHART_SPEED_KEY, strTitle,
		pkChartSpeedData->GetDataAsString(), ctItemButton, pkChartSpeedData, false, true, 0, false, pkParent);
pkParent->AddChild(pkChartSpeed);
// Add the fix alarm colour flag
CShortBitFieldData *pkFixAlarmColourData = new CShortBitFieldData(&ptChartObject->FixBGAlarmCol, 1, 0,
		ms_strEnabledList, bfeBool, 0, 0, true);
strTitle = tr("Fix Alarm Color");
CConfigItem *pkFixAlarmColour = new CConfigItem(ms_strCHART_OBJ_FIX_ALARM_COL_KEY, strTitle,
		pkFixAlarmColourData->GetDataAsString(), ctItemButton, pkFixAlarmColourData, false, true, 0, false, pkParent);
pkParent->AddChild(pkFixAlarmColour);
// check if the alarm colour is fixed
if (ptChartObject->FixBGAlarmCol == TRUE) {
	// Add the alarm colour - this is a ULONG
	CULongData *pkAlarmColourData = new CULongData(&ptChartObject->BGAlarmCol, 0, ms_ulMaxColour, 0, 0, false,
			dtColour);
	strTitle = tr("Bkg Alarm Color");
	CConfigItem *pkAlarmColour = new CConfigItem(ms_strCHART_OBJ_ALARM_COL_KEY, strTitle,
			pkAlarmColourData->GetDataAsString(), ctItemButton, pkAlarmColourData, false, true, 0, false, pkParent);
	pkParent->AddChild(pkAlarmColour);
}
// Add the fix message colour flag
CShortBitFieldData *pkFixMsgColourData = new CShortBitFieldData(&ptChartObject->FixMessageCol, 1, 0, ms_strEnabledList,
		bfeBool, 0, 0, true);
strTitle = tr("Fix Message Color");
CConfigItem *pkFixMsgColour = new CConfigItem(ms_strCHART_OBJ_FIX_MESSAGE_COL_KEY, strTitle,
		pkFixMsgColourData->GetDataAsString(), ctItemButton, pkFixMsgColourData, false, true, 0, false, pkParent);
pkParent->AddChild(pkFixMsgColour);
// check if the message colour is fixed
if (ptChartObject->FixMessageCol == TRUE) {
	// Add the message colour - this is a ULONG
	CULongData *pkMsgColourData = new CULongData(&ptChartObject->MessageCol, 0, ms_ulMaxColour, 0, 0, false, dtColour);
	strTitle = tr("Message Color");
	CConfigItem *pkMsgColour = new CConfigItem(ms_strCHART_OBJ_MESSAGE_COL_KEY, strTitle,
			pkMsgColourData->GetDataAsString(), ctItemButton, pkMsgColourData, false, true, 0, false, pkParent);
	pkParent->AddChild(pkMsgColour);
}
// Add the fix font colour flag
CShortBitFieldData *pkFixFontColourData = new CShortBitFieldData(&ptChartObject->FixFontCol, 1, 0, ms_strEnabledList,
		bfeBool, 0, 0, true);
strTitle = tr("Fix Font Color");
CConfigItem *pkFixFontColour = new CConfigItem(ms_strCHART_OBJ_FIX_FONT_COL_KEY, strTitle,
		pkFixFontColourData->GetDataAsString(), ctItemButton, pkFixFontColourData, false, true, 0, false, pkParent);
pkParent->AddChild(pkFixFontColour);
// check if the font colour is fixed
if (ptChartObject->FixFontCol == TRUE) {
	// Add the font colour - this is a ULONG
	CULongData *pkFontColourData = new CULongData(&ptChartObject->FontColour, 0, ms_ulMaxColour, 0, 0, false, dtColour);
	strTitle = tr("Font Color");
	CConfigItem *pkFontColour = new CConfigItem(ms_strCHART_OBJ_FONT_COL_KEY, strTitle,
			pkFontColourData->GetDataAsString(), ctItemButton, pkFontColourData, false, true, 0, false, pkParent);
	pkParent->AddChild(pkFontColour);
}
// Add the height bitfield
CUShortData *pkHeightData = new CUShortData(&ptChartObject->FontHeight, 11, 50, 0, 0, false);
strTitle = tr("Height");
CConfigItem *pkHeight = new CConfigItem(ms_strFONT_HEIGHT_KEY, strTitle, pkHeightData->GetDataAsString(), ctItemButton,
		pkHeightData, false, true, 0, false, pkParent);
pkParent->AddChild(pkHeight);
// Add the submenu/category base object properties
CreateBaseSubMenuPropsConfigData(pkBaseObject, pkParent);
return pkParent;
}
//****************************************************************************
///
/// Method that creates a Circular Chart Object config hierarchy
///
/// @param[in]			T_BASEOBJECT* pkBaseObject - Pointer to the base object we 
///						are creating the configuration tree for
/// @param[in]			CWidget *pkParentWidget - Pointer to the widget this object is on
///
/// @return Pointer to the top-level parent of a circular chart object config hierarchy
///
/// @todo Add the circular chart specfic object properties
///
//****************************************************************************
CConfigBranch* CScrnDesCfgMgr::CreateCircularChartObjConfig(T_BASEOBJECT *pkBaseObject, CWidget *pkParentWidget) {
CConfigBranch *pkParent = NULL;
T_CIRCCHARTOBJECT *ptCircChartObject = reinterpret_cast<T_CIRCCHARTOBJECT*>(pkBaseObject);
// firstly create the top level config interface class
QString strTitle("");
strTitle = pkParentWidget->GetObjectName(pkBaseObject);
pkParent = new CConfigBranch(ms_strCIRC_CHART_OBJ_TITLE_KEY, strTitle, strTitle, ctMainMenuButton, false, true, 0,
		false, NULL);
// Add the general base object properties
CreateBasePropsConfigData(pkBaseObject, pkParent, false);
strTitle = tr("Showing");
// add the object channel map
CreateObjectChannelMap(pkBaseObject, pkParent, strTitle, pkParentWidget);
// Add the submenu/category base object properties
CreateBaseSubMenuPropsConfigData(pkBaseObject, pkParent);
return pkParent;
}
//****************************************************************************
// CConfigInterface *CreateWidgetConfig(	CWidget *pkWidget )
///
/// Method that creates a widget config hierarchy
///
/// @return Pointer to the top-level parent of a widget config heirarchy
///
//****************************************************************************
CConfigBranch* CScrnDesCfgMgr::CreateWidgetConfig(CWidget *pkWidget) {
CConfigBranch *pkParent = NULL;
T_WIDGET *ptCMMWidget = pkWidget->GetCMMWidget();
// firstly create the top level config interface class
QString strTitle("");
QString strSubTitle("");
strTitle = tr("Widget");
pkParent = new CConfigBranch(ms_strWIDGET_TITLE_KEY, ptCMMWidget->Name, ptCMMWidget->Name, ctMainMenuButton, false,
		true, 0, false, NULL);
// Name, WCHAR edit
CStringCfgData
*pkNameData = new CStringCfgData(ptCMMWidget->Name,
		WIDGET_NAME_LEN, dtString, 0, 0, true);
strTitle = tr("Name");
CConfigItem *pkName = new CConfigItem(ms_strWIDGET_NAME_KEY, strTitle, ptCMMWidget->Name, ctItemButton, pkNameData,
		false, true, 0, false, pkParent);
pkParent->AddChild(pkName);
// Category, WCHAR edit
CStringCfgData
*pkCatData = new CStringCfgData(ptCMMWidget->Category,
		WIDGET_CATEGORY_LEN, dtString, 0, 0, true);
strTitle = tr("Category");
CConfigItem *pkCat = new CConfigItem(ms_strWIDGET_CATEGORY_KEY, strTitle, ptCMMWidget->Category, ctItemButton,
		pkCatData, false, true, 0, false, pkParent);
pkParent->AddChild(pkCat);
// Type, WCHAR edit
CStringCfgData
*pkTypeData = new CStringCfgData(ptCMMWidget->Type,
		WIDGET_TYPE_LEN, dtString, 0, 0, true);
strTitle = tr("Type");
CConfigItem *pkType = new CConfigItem(ms_strWIDGET_TYPE_KEY, strTitle, ptCMMWidget->Type, ctItemButton, pkTypeData,
		false, true, 0, false, pkParent);
pkParent->AddChild(pkType);
// Add the background colour - this is a ULONG
CUShortData *pkBkgColData = new CUShortData(&ptCMMWidget->BackColour, 0, USHRT_MAX, 0, IDS_BACKCLR_DESCR, false,
		dt16Colour);
strSubTitle = pkBkgColData->GetDataAsString();
strTitle = tr("Background Color");
CConfigItem *pkBkgCol = new CConfigItem(ms_strLYT_BACK_COLOUR_KEY, strTitle, strSubTitle, ctItemButton, pkBkgColData,
		false, true, 0, false, pkParent);
pkParent->AddChild(pkBkgCol);
// create the widget channel information (if necessary)
SetupWidgetChannelMapData(pkWidget, pkParent);
// Add the TV_RECT details
SetupRectDetails(&ptCMMWidget->Bounds, pkParent);
// Add the BORDER details
SetupBorderDetails(&ptCMMWidget->Border, pkParent);
return pkParent;
}
//****************************************************************************
// CConfigBranch *CreateWidgetChannelMapConfig(	CWidget *pkWidget )
///
/// Method that creates a widget channel map only config hierarchy
///
/// @return Pointer to the top-level parent of a widget channel map only config heirarchy
///
//****************************************************************************
CConfigBranch* CScrnDesCfgMgr::CreateWidgetChannelMapConfig(CWidget *pkWidget) {
CConfigBranch *pkParent = NULL;
T_WIDGET *ptCMMWidget = pkWidget->GetCMMWidget();
// firstly create the top level config interface class
QString strTitle("");
QString strSubTitle("");
strTitle = tr("Widget");
pkParent = new CConfigBranch(ms_strWIDGET_TITLE_KEY, ptCMMWidget->Name, ptCMMWidget->Name, ctMainMenuButton, false,
		true, 0, false, NULL);
// create the widget channel information (if necessary)
SetupWidgetChannelMapData(pkWidget, pkParent);
return pkParent;
}
//****************************************************************************
// void SetupWidgetChannelDetails( T_WIDGET *ptWidget,
//									CConfigBranch *pkParent )
///
/// Method that creates and adds a channel heirarchy to a branch
///
/// @param[in]			CWidget *pkWidget - Pointer to the widget object
/// @param[in]			CConfigBranch *pkParent - Pointer to the parent branch
///
//****************************************************************************
void CScrnDesCfgMgr::SetupWidgetChannelDetails(CWidget *pkWidget, CConfigBranch *pkParent) {
// Create the submenu button then add the individual buttons
QString strTitle("");
QString strSubTitle("");
QString strChannelsSubTitle("");
strTitle = tr("Channels");
CConfigBranch *pkWidgetParent = new CConfigBranch(ms_strWIDGET_CHANNELS_KEY, strTitle, strSubTitle, ctSubMenuButton,
		false, true, 0, false, pkParent);
pkParent->AddChild(pkWidgetParent);
// list to hold the objects
std::vector<CBaseObject*> kObjList;
CBaseObject *pkObjects = pkWidget->m_pObjects;
while (pkObjects != NULL) {
	kObjList.push_back(pkObjects);
	pkObjects = pkObjects->m_pNextObj;
}
// sort them based on their layout item instance number
std::sort(kObjList.begin(), kObjList.end(), SortLowestInstFirst);
// now create the object channel data
std::vector<CBaseObject*>::const_iterator kCurr = kObjList.begin();
std::vector<CBaseObject*>::const_iterator kEnd = kObjList.end();
while (kCurr != kEnd) {
	T_BASEOBJECT *ptBaseObject = reinterpret_cast<T_BASEOBJECT*>((*kCurr)->GetCMMInfo().pByBlock);
	strTitle = pkWidget->GetObjectName(ptBaseObject);
	// create the object channel leaf
	CreateObjectChannelMap(ptBaseObject, pkWidgetParent, strTitle, pkWidget);
	// add this object name to the channel title
	strChannelsSubTitle += strTitle + L", "
	);
	++kCurr;
}
// check if there were any objects inside this widget
if (strChannelsSubTitle != "") {
	// remove the trailing ", "
	strChannelsSubTitle.remove(strChannelsSubTitle.size() - 2, 2);
} else {
	// replace with the phrase 'no objects'
	strChannelsSubTitle = tr("No Objects");
}
// replace the existing title
pkWidgetParent->SetSubTitle(strChannelsSubTitle);
}
//****************************************************************************
// void SetupWidgetChannelDetails( T_PBASEOBJECT *ptBaseObject,
//									CConfigBranch *pkParent,
//									const QString   &rstrTITLE )
///
/// Method that creates a object map leaf
///
/// @param[in]			T_PBASEOBJECT *ptBaseObject - Pointer to the base object the channel map is for
/// @param[in]			CConfigBranch *pkParent - Pointer to the parent branch
/// @param[in]			const QString   &rstrTITLE - The object title
/// @param[in]			CWidget *pkWidget - Pointer to the parent widget
///
//****************************************************************************
void CScrnDesCfgMgr::CreateObjectChannelMap(T_PBASEOBJECT ptBaseObject, CConfigBranch *pkParent,
	const QString &rstrTITLE, CWidget *pkWidget) {
CScreen *pkScreen = pkWidget->GetScreen();
// only show the channel map information if this is not the template screen
if (pkScreen->GetLayoutItem().CMM_Inst != TEMPLATE_SCREEN_INST) {
	CConfigObjectData *pkObjectData = new CConfigObjectData(ptBaseObject, pkWidget, 0, 0, true, dtObject);
	CConfigItem *pkObject = new CConfigItem(ms_strWIDGET_CHANNELS_KEY + L"_" + rstrTITLE, rstrTITLE,
			pkObjectData->GetDataAsString(), ctItemButton, pkObjectData, false, true, 0, false, pkParent);
	pkParent->AddChild(pkObject);
}
}
//****************************************************************************
// CConfigBranch* CreateTemplateConfig( CTemplate *pkTemplate )
///
/// Method that creates a template config hierarchy for a single template 
///
/// @param[in]		CTemplate *pkTemplate - pointer to the template C++ object
///
/// @return Pointer to the top-level parent of a template config hierarchy
///
//****************************************************************************
CConfigBranch* CScrnDesCfgMgr::CreateTemplateConfig(CTemplate *pkTemplate) {
CConfigBranch *pkParent = NULL;
T_SCRTEMPLATE *ptCMMTemplate = pkTemplate->m_pCMMtemplate;
// firstly create the top level config interface class
QString strTitle("");
QString strSubTitle("");
strTitle = tr("Template");
pkParent = new CConfigBranch(ms_strTEMPLATE_TITLE_KEY, ptCMMTemplate->Name, ptCMMTemplate->Name, ctMainMenuButton,
		false, true, 0, false, NULL);
// Name, WCHAR edit
CStringCfgData
*pkNameData = new CStringCfgData(ptCMMTemplate->Name,
		SCRTEMPLATE_NAME_LEN, dtString, 0, 0, true);
strTitle = tr("Name");
CConfigItem *pkName = new CConfigItem(ms_strTEMPLATE_NAME_KEY, strTitle, ptCMMTemplate->Name, ctItemButton, pkNameData,
		false, true, 0, false, pkParent);
pkParent->AddChild(pkName);
// Add the status bar flag
CBoolData *pkStatusBarData = new CBoolData(&ptCMMTemplate->StatusBar, 0, IDS_STATUS_BAR_DESCR, true);
strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptCMMTemplate->StatusBar);
strTitle = tr("Menu Bar");
CConfigItem *pkStatusBar = new CConfigItem(ms_strTEMPLATE_STATUS_BAR_KEY, strTitle, strSubTitle, ctItemButton,
		pkStatusBarData, false, true, 0, false, pkParent);
pkParent->AddChild(pkStatusBar);
// Add the status bar flag
// EDF Enhancement 07: Ability to select horizontal or vertical 
// replay display for screens configured as Bars or Digital
// Replay Orientation - TV_BOOL but treat as a USHORT bitfield
CShortBitFieldData *pkReplayOrientationData = new CShortBitFieldData(&ptCMMTemplate->ReplyOrentation, 1, 0,
		ms_strOrientationList, bfeSingleSelList, 0, IDS_REPLAY_ORIENTATION, false);
strTitle = tr("Replay Orientation");
CConfigItem *pkReplayOrientation = new CConfigItem(ms_strTEMPLATE_REPLAY_ORIENTATION_KEY, strTitle,
		pkReplayOrientationData->GetDataAsString(), ctItemButton, pkReplayOrientationData, false, true, 0, false,
		pkParent);
pkParent->AddChild(pkReplayOrientation);
return pkParent;
}
//****************************************************************************
// CConfigBranch* CreateScreenConfig( CScreen *pkScreen )
///
/// Method that creates a screen config heirarchy for a single or multiple screens 
///
/// @param[in]		CScreen *pkScreen - pointer the screen C++ object
///
/// @return Pointer to the top-level parent of a screen config hierarchy
///
//****************************************************************************
CConfigBranch* CScrnDesCfgMgr::CreateScreenConfig(CScreen *pkScreen) {
// if the screen pointer is NULL we need to create a config tree or all the screens within
// the layout file - this would imply the user clicked the edit layout facility from the menu
// rather than selecting a screen in designer mode (or in screen designer) 
CConfigBranch *pkParent = NULL;
// firstly create the top level config interface class
QString strTitle("");
QString strSubTitle("");
QString strGroup("");
// erase the existing group list and setup with the new names
ms_strGroupList = "";
T_PGENERALCONFIG ptGeneralData = pSETUP->GetGeneralSetupConfig()->GetSystemGeneralBlock(CONFIG_MODIFIABLE);
// loop through the groups inserting their number and name
for (USHORT usGroupCount = 0; usGroupCount < GENERALCONFIG_GROUPNAME_SIZE; usGroupCount++) {
	strGroup = QString::asprintf("%s|", ptGeneralData->GroupName[usGroupCount]);
	ms_strGroupList += strGroup;
}
if (pkScreen != NULL) {
	COpPanel *pkOpPanel = pkScreen->m_pOpPanel;
	// setup the list of templates
	ms_strCustomScreenTypeList = ms_strScreenTypeList;
	ms_strCustomScreenTypeList += pkOpPanel->GetTemplateList();
	// update the list, removing unnecessary screens etc
	MakeScreenTemplateListNonSequential();
	T_PSCREEN ptCMMScreen = pkScreen->GetCMMScreen();
	pkParent = new CConfigBranch(ms_strSCREEN_TITLE_KEY, ptCMMScreen->Name, ptCMMScreen->Name, ctMainMenuButton, false,
			true, 0, false, NULL);
	SetupScreenConfig(pkScreen, pkParent);
} else {
	// get the screen list from the OpPanel - this option should only be possible on the
	// recorder, not screen designer
	COpPanel *pkOpPanel = reinterpret_cast<COpPanel*>(AfxGetApp()->m_pMainWnd);
	// setup the list of templates
	ms_strCustomScreenTypeList = ms_strScreenTypeList;
	ms_strCustomScreenTypeList += pkOpPanel->GetTemplateList();
	// update the list, removing unnecessary screens etc
	MakeScreenTemplateListNonSequential();
	pkScreen = pkOpPanel->m_pScreens;
	USHORT usScreenCount = 0;
	QString strKey("");
	strTitle = tr("Screens");
	pkParent = new CConfigBranch(ms_strSCREEN_TITLE_KEY, strTitle, L"MULTIPLE SCREEN PARENT", ctMainMenuButton, false,
			true, 0, false, NULL);
	// loop through all the screens
	while (pkScreen != NULL) {
		++usScreenCount;
		T_PSCREEN ptCMMScreen = pkScreen->GetCMMScreen();
		strKey = QString::asprintf("%u", usScreenCount);
		strKey = ms_strSCREEN_TITLE_KEY + strKey;
		QString strFormatString("");
		strFormatString = tr("Screen %u");
		strTitle = QString::asprintf(strFormatString, usScreenCount);
		CConfigBranch *pkIndScreenBranch = new CConfigBranch(strKey, strTitle, ptCMMScreen->Name, ctSubMenuButton,
				false, true, 0, false, pkParent);
		SetupScreenConfig(pkScreen, pkIndScreenBranch);
		pkParent->AddChild(pkIndScreenBranch);
		pkScreen = pkScreen->m_pNextScr;
	}
	// now add the 'AddScreen' option
	CConfigItem *pkAddScreen = CreateAddScreenItem(pkParent, usScreenCount);
	pkParent->AddChild(pkAddScreen);
	// now add the 'DeleteScreen' option
	CConfigItem *pkDeleteScreen = CreateDeleteScreenItem(pkParent, usScreenCount);
	pkParent->AddChild(pkDeleteScreen);
}
return pkParent;
}
//****************************************************************************
// void SetupHotButtonConfig( T_HOTBUTTON *pkHotButton, CConfigBranch *pkParent )
///
/// Method that creates a hot button config heirarchy for an individual hot button
///
/// @param[in]			T_HOTBUTTON *pkHotButton - pointer the hotbutton C++ object
/// @param[in/out]		CConfigBranch *pkParent - The parent branch
///
//****************************************************************************
void CScrnDesCfgMgr::SetupHotButtonConfig(T_HOTBUTTON *pkHotButton, CConfigBranch *pkParent) {
QString strTitle("");
QString strSubTitle("");
// Name, WCHAR edit
CStringCfgData
*pkNameData = new CStringCfgData(_wcsupr(pkHotButton->Name),		//kranti
		HOTBUTTON_NAME_LEN, dtString, 0, 0, true);
strTitle = tr("Name");
CConfigItem *pkName = new CConfigItem(ms_strHOTBUTTON_NAME_KEY, strTitle, _wcsupr(pkHotButton->Name),//kranti					
ctItemButton, pkNameData, false, true, 0, false, pkParent);
pkParent->AddChild(pkName);
CShortBitFieldData *pkEnData = new CShortBitFieldData(reinterpret_cast<USHORT*>(pkHotButton), 1, 0, ms_strEnabledList,
		bfeBool, 0, 0, true);
strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, pkHotButton->Enabled);
strTitle = tr("Enabled");
CConfigItem *pkEn = new CConfigItem(ms_strHOTBUTTON_ENABLED_KEY, strTitle, strSubTitle, ctItemButton, pkEnData, false,
		1, 0, false, pkParent);
pkParent->AddChild(pkEn);
}
//****************************************************************************
// void SetupScreenConfig( CScreen *pkScreen, CConfigBranch *pkParent )
///
/// Method that creates a screen config heirarchy for an individual screen
///
/// @param[in]			CScreen *pkScreen - pointer the screen C++ object
/// @param[in/out]		CConfigBranch *pkParent - The parent branch
///
//****************************************************************************
void CScrnDesCfgMgr::SetupScreenConfig(CScreen *pkScreen, CConfigBranch *pkParent) {
QString strTitle("");
QString strSubTitle("");
T_PSCREEN ptCMMScreen = pkScreen->GetCMMScreen();
// Name, WCHAR edit
CStringCfgData
*pkNameData = new CStringCfgData(ptCMMScreen->Name,
		SCREEN_NAME_LEN, dtString, 0, 0, true);
strTitle = tr("Name");
CConfigItem *pkName = new CConfigItem(ms_strSCREEN_NAME_KEY, strTitle, ptCMMScreen->Name, ctItemButton, pkNameData,
		false, true, 0, false, pkParent);
pkParent->AddChild(pkName);
// check this recorder is still capable of showing AMS2750 process screens - usually this wouldn't 
// be ncessary but unfortunately because screen designer allows setups to be loaded/unloaded without 
// restarting then we can end up with process screens enabled when they shouldn't be
if (( pSYSTEM_INFO->GetAMS2750Mode() != AMS2750_PROCESS) && (ptCMMScreen->Type == TPL_AMS2750_PROCESS_SCREEN)) {
	ptCMMScreen->Enabled = FALSE;
}
// if this is the TUS screen then do not allow it to be disabled by not showing this field at all
if (ptCMMScreen->Type != TPL_AMS2750_TUS_SCREEN) {
	CShortBitFieldData *pkEnData = new CShortBitFieldData(reinterpret_cast<USHORT*>(ptCMMScreen), 1, 0,
			ms_strEnabledList, bfeBool, 0, 0, true);
	strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptCMMScreen->Enabled);
	strTitle = tr("Enabled");
	CConfigItem *pkEn = new CConfigItem(ms_strSCREEN_ENABLED_KEY, strTitle, strSubTitle, ctItemButton, pkEnData, false,
			(( pSYSTEM_INFO->GetAMS2750Mode() == AMS2750_PROCESS) || (ptCMMScreen->Type != TPL_AMS2750_PROCESS_SCREEN)),
			0, false, pkParent);
	pkParent->AddChild(pkEn);
}
// Add the type USHORT - treat as a bitfield
COpPanel *pkOpPanel = pkScreen->GetOpPanel();
// check if this is a custom template that has nto been initialised
if (ptCMMScreen->Type == TPL_CUSTOM) {
	ptCMMScreen->Type = pkOpPanel->GetTemplateIndex(&ptCMMScreen->Template);
}
if (ptCMMScreen->Type >= TPL_LAST_CANNED && ptCMMScreen->Type > TPL_NP_LAST) // Modified as NP screen types start at 1500;
		{
	ptCMMScreen->Template.CMM_Type = BLK_SCRTEMPLATE;
	ptCMMScreen->Template.CMM_Inst = ptCMMScreen->Type - TPL_LAST_CANNED + 1;
}
// check this is not the automatically created NADCAP TUS mode screen
bool bTemplateTypeEnabled = (ptCMMScreen->Enabled == TRUE);
if (ptCMMScreen->Type == TPL_AMS2750_TUS_SCREEN) {
	// this is the TUS mode screen therefore do not allow the type to be modified
	bTemplateTypeEnabled = false;
}
// check if we need to use the original canned screen list - this would be necessary where we
// want to show an AMS2750 TUS screen or when someone unloads an AMS setup but we still have AMS2750
// process screens present
bool bUseOriginalCannedList = false;
if ((ptCMMScreen->Type == TPL_AMS2750_TUS_SCREEN)
		|| ((ptCMMScreen->Type == TPL_AMS2750_PROCESS_SCREEN) && !bTemplateTypeEnabled)) {
	bUseOriginalCannedList = true;
}
CShortBitFieldData *pkTemplateTypeData = new CShortBitFieldData(&ptCMMScreen->Type, 7, 0,
		bUseOriginalCannedList ? ms_strScreenTypeList : ms_strCustomScreenTypeList, bfeSingleSelList, 0, 0, true);
// If it's a nonprocess MSG template type then pkTemplateTypeData->GetDataAsString() will fail and return NA
// as the non process msg telmplate types in ms_strCustomMSGScreenTypeList 
if (ptCMMScreen->Type >= TPL_MSG_ALL && ptCMMScreen->Type <= TPL_MSG_USER) {
	// we are re-using the IDS_CFG_EVENT_EFFECT_MSG_SEL_TITLE string here as it is also set to "Messages"
	strSubTitle = tr("Messages");
} else {
	strSubTitle = pkTemplateTypeData->GetDataAsString();
}
strTitle = tr("Template Type");
CConfigItem *pkTemplateType = new CConfigItem(ms_strSCREEN_TYPE_KEY, strTitle, strSubTitle, ctItemButton,
		pkTemplateTypeData, false, bTemplateTypeEnabled, 0, false, pkParent);
pkParent->AddChild(pkTemplateType);
// For non process message screens add one more button to select messages types...
if (ptCMMScreen->Type >= TPL_MSG_ALL && ptCMMScreen->Type <= TPL_MSG_USER) {
	CShortBitFieldData *pkTemplateTypeData = new CShortBitFieldData(&ptCMMScreen->Type, 7, 0,
			ms_strCustomMsgScreenTypeList, bfeSingleSelList, 0, 0, true);
	strSubTitle = pkTemplateTypeData->GetDataAsString();
	strTitle = tr("Message Type");
	CConfigItem *pkTemplateType = new CConfigItem(ms_strSCREEN_TYPE_KEY, strTitle, strSubTitle, ctItemButton,
			pkTemplateTypeData, false, bTemplateTypeEnabled, 0, false, pkParent);
	pkParent->AddChild(pkTemplateType);
}
// Add Groups/Pen selection to Alarms and max min non process screens
if (ptCMMScreen->Type == TPL_ALARM || ptCMMScreen->Type == TPL_MAXMIN) {
	bool bBatchEnabled = ( pSYSTEM_INFO->FWOptionBatchAvailable() == TRUE);
	bool bDisableBatchField = false;
	if (!bBatchEnabled) {
		ptCMMScreen->UseGroups = FALSE;
		// don't allow this option to be enabled
		bDisableBatchField = true;
	}
	CShortBitFieldData *pkUseGroupData = new CShortBitFieldData(reinterpret_cast<USHORT*>(ptCMMScreen), 1, 6,
			ms_strScreenUseGroupList, bfeSingleSelList, 0, 0, true);
	strTitle = tr("Select By");
	CConfigItem *pkUseGroup = new CConfigItem(ms_strSCREEN_USE_GROUP_KEY, strTitle, pkUseGroupData->GetDataAsString(),
			ctItemButton, pkUseGroupData, false, (ptCMMScreen->Enabled == TRUE) && !bDisableBatchField, 0, false,
			pkParent);
	pkParent->AddChild(pkUseGroup);
	if (ptCMMScreen->UseGroups == FALSE) {
		CCannedScrnData *pkCannedScrnSetupData = new CCannedScrnData(ptCMMScreen->CannedPens, dtCannedScreenSetup,
				static_cast<T_TEMPLATE_TYPE>(ptCMMScreen->Type), 0, 0, true);
		strSubTitle = pkCannedScrnSetupData->GetDataAsString();
		strTitle = tr("Showing (Pens)");
		CConfigItem *pkCannedScrnSetup = new CConfigItem(ms_strSCREEN_CANNED_PENS_SETUP_KEY, strTitle, strSubTitle,
				ctItemButton, pkCannedScrnSetupData, false, (ptCMMScreen->Enabled == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkCannedScrnSetup);
	} else {
		CShortBitFieldData *pkGrpData = new CShortBitFieldData(reinterpret_cast<USHORT*>(ptCMMScreen), 3, 7,
				ms_strGroupList, bfeSingleSelList, 0, 0, true);
		strTitle = tr("Group Name");
		CConfigItem *pkGroup = new CConfigItem(ms_strSCREEN_GROUP_SEL_KEY, strTitle, pkGrpData->GetDataAsString(),
				ctItemButton, pkGrpData, false, bBatchEnabled && (ptCMMScreen->Enabled == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkGroup);
	}
}
if (ptCMMScreen->Type == TPL_SCRIPT_TIMERS || ptCMMScreen->Type == TPL_USER_VARS) {
	CCannedScrnData *pkCannedScrnSetupData = new CCannedScrnData((T_CANNEDPENS*) &ptCMMScreen->NPItems,
			dtCannedScreenSetup, static_cast<T_TEMPLATE_TYPE>(ptCMMScreen->Type), 0, 0, true);
	T_CFG_DATA_TYPE dt = dtMultipleUserVars;
	USHORT usMaxnoOfSelections = MAX_V6_USER_VARS;
	if (ptCMMScreen->Type == TPL_SCRIPT_TIMERS) {
		usMaxnoOfSelections = MAX_SCRIPT_TIMERS;
		dt = dtMultipleTimers;
	}
	CPickerData kPickerData((USHORT*) &ptCMMScreen->NPItems, dt, 0, 0, false, 0, usMaxnoOfSelections, 0);
	strSubTitle = kPickerData.GetDataAsString();
	//strSubTitle = pkCannedScrnSetupData->GetDataAsString();
	//strTitle = tr("Showing (Pens)");
	if (ptCMMScreen->Type == TPL_SCRIPT_TIMERS)
		strTitle = tr("Showing (Timers)");
	//= L"Showing (Timers)...");
	else if (ptCMMScreen->Type == TPL_USER_VARS)
		strTitle = tr("Showing (User variables)");
	//= L"Showing (User Vars)...");
	CConfigItem *pkCannedScrnSetup = new CConfigItem(ms_strSCREEN_CANNED_PENS_SETUP_KEY, strTitle, strSubTitle,
			ctItemButton, pkCannedScrnSetupData, false, (ptCMMScreen->Enabled == TRUE), 0, false, pkParent);
	pkParent->AddChild(pkCannedScrnSetup);
}
// if we need to add msg type selection on screen then modify code here
// only show the orientation, scale indicator and rotating scale options if a canned screen is selected
// but not the TUS screen
if ((ptCMMScreen->Type < TPL_LAST_CANNED) && (ptCMMScreen->Type != TPL_AMS2750_TUS_SCREEN)) {
	// offer the user the choice of groups or batch if the batch firmware option is enabled
	bool bBatchEnabled = ( pSYSTEM_INFO->FWOptionBatchAvailable() == TRUE);
	// varaible used to disable the batch/group field is certain criteria are met
	bool bDisableBatchField = false;
	if (ptCMMScreen->Type == TPL_AMS2750_PROCESS_SCREEN) {
		// force to the group/batch option when showing the AMS2750 field
		ptCMMScreen->UseGroups = TRUE;
		// don't allow this option to be disabled
		bDisableBatchField = true;
	}
	// force back to pen if the batch credit option is disabled
	else if (!bBatchEnabled) {
		ptCMMScreen->UseGroups = FALSE;
		// don't allow this option to be enabled
		bDisableBatchField = true;
	}
	CShortBitFieldData *pkUseGroupData = new CShortBitFieldData(reinterpret_cast<USHORT*>(ptCMMScreen), 1, 6,
			ms_strScreenUseGroupList, bfeSingleSelList, 0, 0, true);
	strTitle = tr("Select By");
	CConfigItem *pkUseGroup = new CConfigItem(ms_strSCREEN_USE_GROUP_KEY, strTitle, pkUseGroupData->GetDataAsString(),
			ctItemButton, pkUseGroupData, false, (ptCMMScreen->Enabled == TRUE) && !bDisableBatchField, 0, false,
			pkParent);
	pkParent->AddChild(pkUseGroup);
	if (ptCMMScreen->UseGroups == FALSE) {
		CCannedScrnData *pkCannedScrnSetupData = new CCannedScrnData(ptCMMScreen->CannedPens, dtCannedScreenSetup,
				static_cast<T_TEMPLATE_TYPE>(ptCMMScreen->Type), 0, 0, true);
		strSubTitle = pkCannedScrnSetupData->GetDataAsString();
		strTitle = tr("Showing (Pens)");
		CConfigItem *pkCannedScrnSetup = new CConfigItem(ms_strSCREEN_CANNED_PENS_SETUP_KEY, strTitle, strSubTitle,
				ctItemButton, pkCannedScrnSetupData, false, (ptCMMScreen->Enabled == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkCannedScrnSetup);
//E527303[
#ifdef DOCVIEW
			//----------------------------------------------------------------------------------------------
			// CannedScreen Data for Replay Mode
			CCannedScrnData *pkCannedScrnSetupDataRM = new CCannedScrnData(	ptCMMScreen->ReplayPens,
																			dtReplayPenSeletionScrn,
																			static_cast< T_TEMPLATE_TYPE >( ptCMMScreen->Type ),
																			0,
																			0,
																			true );
			// Sub Title For Replay Mode Pens
			strSubTitle = pkCannedScrnSetupDataRM->GetDataAsString(true);
  QString   strNone;
			strNone.LoadStringW(IDS_PICKER_NONE_TITLE);
			if(strSubTitle.CompareNoCase(strNone) == 0)
			{
				for( USHORT usPenCount = 0; usPenCount < SCREEN_CANNEDPENS_SIZE; usPenCount++ )
				{
					ptCMMScreen->ReplayPens[usPenCount] = ptCMMScreen->CannedPens[usPenCount];
					
				}
				strSubTitle = pkCannedScrnSetupDataRM->GetDataAsString(true);
			}
			// Title for showing pens in replay mode
	strTitle = tr("Showing Replay Pens");
			CConfigItem *pkCannedScrnSetupRM = new CConfigItem(ms_strSCREEN_REPLAY_PENS_SETUP_KEY,
																strTitle,
																strSubTitle,						
																ctItemButton,
																pkCannedScrnSetupDataRM,
																false,
																( ptCMMScreen->Enabled == TRUE ),
																0,
																false,
																pkParent );
			// Add new child for Show Replay Mode Pens
			pkParent->AddChild( pkCannedScrnSetupRM );
			//----------------------------------------------------------------------------------------------
#endif
//]
	} else {
		// groups therefore show the group picker
		CShortBitFieldData *pkGrpData = new CShortBitFieldData(reinterpret_cast<USHORT*>(ptCMMScreen), 3, 7,
				ms_strGroupList, bfeSingleSelList, 0, 0, true);
		strTitle = tr("Group Name");
		CConfigItem *pkGroup = new CConfigItem(ms_strSCREEN_GROUP_SEL_KEY, strTitle, pkGrpData->GetDataAsString(),
				ctItemButton, pkGrpData, false, bBatchEnabled && (ptCMMScreen->Enabled == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkGroup);
		// now show the additiona fields like max/mins, totals and scales based on the canned screen type
		switch (ptCMMScreen->Type) {
		case TPL_CHRT_BARS:
		case TPL_CHRT_DPMS_BARS:
		case TPL_AMS2750_PROCESS_SCREEN: {
			if ((ptCMMScreen->Type != TPL_AMS2750_PROCESS_SCREEN) || CBaseObject::IsSXRecorder()) {
				// use scales
				CShortBitFieldData *pkUseScalesData = new CShortBitFieldData(reinterpret_cast<USHORT*>(ptCMMScreen), 1,
						12, ms_strEnabledList, bfeBool, 0, 0, true);
				strTitle = tr("Show Scales");
				CConfigItem *pkUseScales = new CConfigItem(ms_strSCREEN_GROUP_USE_SCALES_KEY, strTitle,
						pkUseScalesData->GetDataAsString(), ctItemButton, pkUseScalesData, false,
						bBatchEnabled && (ptCMMScreen->Enabled == TRUE), 0, false, pkParent);
				pkParent->AddChild(pkUseScales);
			}
		}
			break;
		case TPL_CHRT_DPMS:
		case TPL_TABULAR_SCREEN:
		case TPL_CIRC_CHRT_DPMS:
			// do nothing
			break;
		case TPL_DPMS_BARS:
		case TPL_DPMS: {
			// use max mins
			CShortBitFieldData *pkUseMaxMinData = new CShortBitFieldData(reinterpret_cast<USHORT*>(ptCMMScreen), 1, 10,
					ms_strEnabledList, bfeBool, 0, 0, true);
			strTitle = tr("Show Max Mins");
			CConfigItem *pkUseMaxMin = new CConfigItem(ms_strSCREEN_GROUP_USE_MAX_MINS_KEY, strTitle,
					pkUseMaxMinData->GetDataAsString(), ctItemButton, pkUseMaxMinData, false,
					bBatchEnabled && (ptCMMScreen->Enabled == TRUE), 0, false, pkParent);
			pkParent->AddChild(pkUseMaxMin);
			// use totals
			CShortBitFieldData *pkUseTotalsData = new CShortBitFieldData(reinterpret_cast<USHORT*>(ptCMMScreen), 1, 11,
					ms_strEnabledList, bfeBool, 0, 0, true);
			strTitle = tr("Show Totals");
			CConfigItem *pkUseTotals = new CConfigItem(ms_strSCREEN_GROUP_USE_TOTALS_KEY, strTitle,
					pkUseTotalsData->GetDataAsString(), ctItemButton, pkUseTotalsData, false,
					bBatchEnabled && (ptCMMScreen->Enabled == TRUE), 0, false, pkParent);
			pkParent->AddChild(pkUseTotals);
		}
			break;
		default:
			break;
		}
	}
	if ((ptCMMScreen->Type != TPL_DPMS) && (ptCMMScreen->Type != TPL_TABULAR_SCREEN)
			&& (ptCMMScreen->Type != TPL_CIRC_CHRT_DPMS)) {
		//orientation
		if ((ptCMMScreen->Type != TPL_AMS2750_PROCESS_SCREEN) || CBaseObject::IsSXRecorder()) {
			CShortBitFieldData *pkOrientationData = new CShortBitFieldData(reinterpret_cast<USHORT*>(ptCMMScreen), 1, 1,
					ms_strScreenOrientationList, bfeBool, 0, 0, true);
			strSubTitle = pkOrientationData->GetDataAsString();
			strTitle = tr("Orientation");
			CConfigItem *pkOrientation = new CConfigItem(ms_strSCREEN_VERTICAL_BARS_KEY, strTitle, strSubTitle,
					ctItemButton, pkOrientationData, false, (ptCMMScreen->Enabled == TRUE), 0, false, pkParent);
			pkParent->AddChild(pkOrientation);
		}
	}
	//TODO RD CHART - do we need to do anything here
	if ((ptCMMScreen->Type == TPL_CHRT_BARS) || (ptCMMScreen->Type == TPL_CHRT_DPMS_BARS)
			|| (ptCMMScreen->Type == TPL_AMS2750_PROCESS_SCREEN)) {
		if ((ptCMMScreen->Type != TPL_AMS2750_PROCESS_SCREEN) || CBaseObject::IsSXRecorder()) {
			// rotating scales
			CShortBitFieldData *pkRotScaleData = new CShortBitFieldData(reinterpret_cast<USHORT*>(ptCMMScreen), 1, 2,
					ms_strEnabledList, bfeBool, 0, 0, true);
			strSubTitle = pkRotScaleData->GetDataAsString();
			strTitle = tr("Cycle Scales");
			CConfigItem *pkRotScale = new CConfigItem(ms_strSCREEN_ROTATE_BARS_KEY, strTitle, strSubTitle, ctItemButton,
					pkRotScaleData, false, (ptCMMScreen->Enabled == TRUE), 0, false, pkParent);
			pkParent->AddChild(pkRotScale);
			// scale indicator type
			CShortBitFieldData *pkScaleIndData = new CShortBitFieldData(reinterpret_cast<USHORT*>(ptCMMScreen), 1, 3,
					ms_strScreenScaleIndicatorList, bfeBool, 0, 0, true);
			strSubTitle = pkScaleIndData->GetDataAsString();
			strTitle = tr("Scale Indicator");
			CConfigItem *pkScaleInd = new CConfigItem(ms_strSCREEN_POINTER_KEY, strTitle, strSubTitle, ctItemButton,
					pkScaleIndData, false, (ptCMMScreen->Enabled == TRUE), 0, false, pkParent);
			pkParent->AddChild(pkScaleInd);
		}
	}
	if (ptCMMScreen->Type == TPL_TABULAR_SCREEN) {
		// show the fix pen colour option
		CShortBitFieldData *pkFixForeColourData = new CShortBitFieldData(reinterpret_cast<USHORT*>(ptCMMScreen), 1, 13,
				ms_strEnabledList, bfeBool, 0, IDS_FIXFORECLR_DESCR, true);
		strTitle = tr("Fix Foreground Color");
		CConfigItem *pkFixForeColour = new CConfigItem(ms_strLYT_FIX_FORE_COLOUR_KEY, strTitle,
				pkFixForeColourData->GetDataAsString(), ctItemButton, pkFixForeColourData, false, true, 0, false,
				pkParent);
		pkParent->AddChild(pkFixForeColour);
		// check if the foreground colour is fixed
		if (ptCMMScreen->FixForeColour == TRUE) {
			// Add the foreground colour - this is a ULONG
			CULongData *pkForeColData = new CULongData(&ptCMMScreen->ForeColour, 0, ms_ulMaxColour, 0,
					IDS_FORECLR_DESCR, true, dtColour);
			strTitle = tr("Foreground Color");
			CConfigItem *pkForeCol = new CConfigItem(ms_strLYT_FORE_COLOUR_KEY, strTitle,
					pkForeColData->GetDataAsString(), ctItemButton, pkForeColData, false, true, 0, false, pkParent);
			pkParent->AddChild(pkForeCol);
		}
	}
}
/*
 // Rotating screen
 CShortBitFieldData *pkRotScrnData = new CShortBitFieldData(	reinterpret_cast< USHORT* >( ptCMMScreen ),
 1,
 4,
 ms_strEnabledList,
 bfeBool,
 0,
 0,
 true );
 strSubTitle = pkRotScrnData->GetDataAsString();
 strTitle = tr("Rotate Screen");
 CConfigItem *pkRotScrn = new CConfigItem(	ms_strSCREEN_ROTATE_SCREEN_KEY,
 strTitle,
 strSubTitle,						
 ctItemButton,
 pkRotScrnData,
 false,
 ( ptCMMScreen->Enabled == TRUE ),
 0,
 false,
 pkParent );
 pkParent->AddChild( pkRotScrn );
 */
/*
 // use template screen colour
 CShortBitFieldData *pkUseTmpColData = new CShortBitFieldData(	reinterpret_cast< USHORT* >( ptCMMScreen ),
 1,
 5,
 ms_strEnabledList,
 bfeBool,
 0,
 0,
 true );
 strSubTitle = pkUseTmpColData->GetDataAsString();
 strTitle = tr("Use Template Col");
 CConfigItem *pkUseTmpCol = new CConfigItem(	ms_strSCREEN_USE_TEMPLATE_BKG_COL_KEY,
 strTitle,
 strSubTitle,						
 ctItemButton,
 pkUseTmpColData,
 false,
 ( ptCMMScreen->Enabled == TRUE ),
 0,
 false,
 pkParent );
 pkParent->AddChild( pkUseTmpCol );
 */
// only show the background colour on custom screens as you will never see the background
// on a canned screen	
if (ptCMMScreen->Type >= TPL_LAST_CANNED && (ptCMMScreen->Type < TPL_ALARM || ptCMMScreen->Type > TPL_NP_LAST)) //E374454 -Fix for 1-3DOOZFO -> To Show Replay mode option for custom screens.
		//if( ptCMMScreen->Type == TPL_LAST_CANNED || ptCMMScreen->Type > TPL_NP_LAST ) //modified condition to fix reply mode pens 1-1NB0LVU 
		// Modified NP screen will have default backgoround
		{
	// Add the background colour - this is a ULONG
	CUShortData *pkBkgColData = new CUShortData(&ptCMMScreen->BackColour, 0, USHRT_MAX, 0, IDS_BACKCLR_DESCR, false,
			dt16Colour);
	strSubTitle = pkBkgColData->GetDataAsString();
	strTitle = tr("Background Color");
	CConfigItem *pkBkgCol = new CConfigItem(ms_strSCREEN_BKG_COL_KEY, strTitle, strSubTitle, ctItemButton, pkBkgColData,
			false, (ptCMMScreen->Enabled == TRUE) && (ptCMMScreen->UseTmpltColour != TRUE), 0, false, pkParent);
	pkParent->AddChild(pkBkgCol);
//E527303[
#ifdef DOCVIEW
			//----------------------------------------------------------------------------------------------
			// CannedScreen Data for Replay Mode
			CCannedScrnData *pkCannedScrnSetupDataRM = new CCannedScrnData(	ptCMMScreen->ReplayPens,
																			dtReplayPenSeletionScrn,
																			static_cast< T_TEMPLATE_TYPE >( ptCMMScreen->Type ),
																			0,
																			0,
																			true );
			// Sub Title For Replay Mode Pens
			strSubTitle = pkCannedScrnSetupDataRM->GetDataAsString(true);
			// Title for showing pens in replay mode
	strTitle = tr("Showing Replay Pens");
			CConfigItem *pkCannedScrnSetupRM = new CConfigItem(ms_strSCREEN_REPLAY_PENS_SETUP_KEY,
																strTitle,
																strSubTitle,						
																ctItemButton,
																pkCannedScrnSetupDataRM,
																false,
																( ptCMMScreen->Enabled == TRUE ),
																0,
																false,
																pkParent );
			// Add new child for Show Replay Mode Pens
			pkParent->AddChild( pkCannedScrnSetupRM );
			//----------------------------------------------------------------------------------------------
#endif
//]
}
}
//****************************************************************************
// CConfigItem* CreateAddScreenItem( CConfigBranch *pkParent, const USHORT usSCREEN_COUNT )
///
/// Method that creates an add screen option for a multi screen confg tree
///
/// @param[in/out]		CConfigBranch *pkParent - The parent branch
/// @param[in]			const USHORT usSCREEN_COUNT - The currnet number of screens in this layout
///
/// @return			A pointer to the add screen config item
///
//****************************************************************************
CConfigItem* CScrnDesCfgMgr::CreateAddScreenItem(CConfigBranch *pkParent, const USHORT usSCREEN_COUNT) {
CAddScreenData *pkAddScreenData = new CAddScreenData(0, 0);
USHORT usMaxScreens = 0;
if ( pDEVICE_INFO->IsRecorderMulti()) {
	usMaxScreens = CScreen::ms_usMAX_MULTI_SCREENS;
} else if ( pDEVICE_INFO->IsRecorderMini()) {
	usMaxScreens = CScreen::ms_usMAX_MINI_SCREENS;
} else {
	usMaxScreens = CScreen::ms_usMAX_EZ_SCREENS;
}
CConfigItem *pkAddScreen = new CConfigItem(ms_strSCREEN_ADD_SCREEN_KEY, "", pkAddScreenData->GetDataAsString(),
		ctItemButton, pkAddScreenData, false, (usSCREEN_COUNT < usMaxScreens), 0, false, pkParent);
return pkAddScreen;
}
//****************************************************************************
// CConfigItem* CreateDeleteScreenItem( CConfigBranch *pkParent, const USHORT usSCREEN_COUNT )
///
/// Method that deletes a selected screen for a multi screen confg tree
///
/// @param[in/out]		CConfigBranch *pkParent - The parent branch
/// @param[in]			const USHORT usSCREEN_COUNT - The currnet number of screens in this layout
///
/// @return			A pointer to the delete screen config item
///
//****************************************************************************
CConfigItem* CScrnDesCfgMgr::CreateDeleteScreenItem(CConfigBranch *pkParent, const USHORT usSCREEN_COUNT) {
//not used in TTR6SETUP so return NULL for that option, otherwise create the Screen etc etc
#ifdef TTR6SETUP
	return NULL;
#else
CDeleteScreenData *pkDeleteScreenData = new CDeleteScreenData(0, 0);
CConfigItem *pkDeleteScreen = new CConfigItem(ms_strSCREEN_DELETE_SCREEN_KEY, "", pkDeleteScreenData->GetDataAsString(),
		ctItemButton, pkDeleteScreenData, false, (usSCREEN_COUNT > 1), 0, false, pkParent);
return pkDeleteScreen;
#endif
return NULL;
}
//****************************************************************************
// CConfigBranch *RefreshScreenConfigTree( CConfigItem *pkModifiedItem )
///
/// Method that updates an individual screen within a multiple screen heirarchy
///
/// @param[in]		CConfigItem *pkConfigItem - The particular config item that has 
///					been modified
///
/// @return		A pointer to the parent config item (for the enitire tree, not a screen)
///
//****************************************************************************
CConfigBranch* CScrnDesCfgMgr::RefreshScreenConfigTree(CConfigItem *pkModifiedItem) {
QString strKey = pkModifiedItem->GetKey();
int iDelimPos = strKey.indexOf(CConfigInterface::ms_wcDELIMITER, 0);
// get the parent
CConfigInterface *pkParent = pkModifiedItem;
while (pkParent->GetParent() != NULL) {
	pkParent = pkParent->GetParent();
}
// replace this particular screen config tree
CConfigBranch *pkParentBranch = static_cast<CConfigBranch*>(pkParent);
// check the delimiter was found and it is not in position 0
if (iDelimPos > 0) {
	QString strInitialKey(strKey.left(iDelimPos));
	if (strInitialKey.compare(ms_strSCREEN_TITLE_KEY) == 0) {
		// remove up to the first delimiter thus leaving us with the string
		// SCREENXXX|XXXXX|XXXX
		strKey.remove(0, iDelimPos + 1);
		iDelimPos = strKey.indexOf(CConfigInterface::ms_wcDELIMITER, 0);
		if (iDelimPos) {
			QString strScreenNoKey = strKey.left(iDelimPos);
			// check if this is the add item option by checking its key
			if ((strScreenNoKey != ms_strSCREEN_ADD_SCREEN_KEY) && (strScreenNoKey != ms_strSCREEN_DELETE_SCREEN_KEY)) {
				// normal screen option
				strScreenNoKey.remove(0, ms_strSCREEN_TITLE_KEY.size());
				const USHORT usSCREEN_NO = static_cast<USHORT>(QString::number(strScreenNoKey));
				// get this screen number within the op panel screen list and create its config tree
				COpPanel *pkOpPanel = reinterpret_cast<COpPanel*>(AfxGetApp()->m_pMainWnd);
				CScreen *pkScreen = pkOpPanel->m_pScreens;
				// go to the child tree corresponding to the screen number above - this will be
				// the child item that we must replace - make sure we don't exceed our number of
				// screens either (should never happen)
				USHORT usCurrScreenNo = 1;
				while (pkScreen != NULL) {
					// check if there is a match
					if (usCurrScreenNo == usSCREEN_NO) {
						// yes there is a match so drop out
						break;
					}
					pkScreen = pkScreen->m_pNextScr;
					usCurrScreenNo++;
				}
				// if the screen template type is NOn process screen
				// Delete screen here . sendmsg to Oppanel WM_DELETE_SCREEN 
				// Delete Config tree of screen and regenerate ...
				// if this is a canned screen set the flag
				// we will then build it afresh from the new screen config data.
				if (pkScreen->IsCannedScreen())
					pkScreen->m_CannedScreenChanged = TRUE;
				T_PSCREEN ptCMMScreen = pkScreen->GetCMMScreen();
				QString strTitle("");
				strKey = QString::asprintf("%u", usSCREEN_NO);
				strKey = ms_strSCREEN_TITLE_KEY + strKey;
				QString strFormatString("");
				strFormatString = tr("Screen %u");
				strTitle = QString::asprintf(strFormatString, usSCREEN_NO);
				CConfigBranch *pkIndScreenBranch = new CConfigBranch(strKey, strTitle, ptCMMScreen->Name,
						ctSubMenuButton, false, true, 0, false, pkParentBranch);
				SetupScreenConfig(pkScreen, pkIndScreenBranch);
				pkParentBranch->ReplaceChild(pkIndScreenBranch);
			} else if (strScreenNoKey == ms_strSCREEN_ADD_SCREEN_KEY) {
				// update the add screen option - this is necessary in case we have reached our screen limit
				// now add the 'AddScreen' option
				CConfigItem *pkAddScreen = CreateAddScreenItem(pkParentBranch,
						static_cast<USHORT>(pkParentBranch->GetNumberOfChildren() - 2));
				pkParentBranch->ReplaceChild(pkAddScreen);
			} else {
				// rebuilding the entire config tree is easier here
				// delete the existing branch first
				delete pkParentBranch;
				pkParentBranch = CreateScreenConfig(NULL);
			}
		}
	}
}
return pkParentBranch;
}
//****************************************************************************
// const QString   GetWidgetParentInstTitle( CWidget *pkWidget ) const
///
/// Method that gets a title for the widget instance field e.g. pen, analogue etc
///
/// @param[in]		CWidget *pkWidget - Pointer to the widget
///
/// @return String containing the parent instance no title
///
//****************************************************************************
const QString CScrnDesCfgMgr::GetWidgetParentInstTitle(CWidget *pkWidget) const {
QString strTitle("");
T_CHANNELREF *ptObjChanRef = NULL;
// loop through all the objects until we find one using the parent
for (int iCount = 0; iCount < WIDGET_OBJECTLIST_SIZE; iCount++) {
	BLOCK_INFO tBlockInfo;
	if (pkWidget->GetObjectConfig(iCount, &tBlockInfo)) {
		T_BASEOBJECT *ptBaseObject = reinterpret_cast<T_BASEOBJECT*>(tBlockInfo.pByBlock);
		switch (ptBaseObject->ObjectType) {
		case DigitalObject: {
			T_DIGITALOBJECT *ptDig = reinterpret_cast<T_DIGITALOBJECT*>(ptBaseObject);
			ptObjChanRef = &ptDig->ChannelInfo;
		}
			break;
		case BarObject: {
			T_BAROBJECT *ptBar = reinterpret_cast<T_BAROBJECT*>(ptBaseObject);
			ptObjChanRef = &ptBar->ChannelInfo;
		}
			break;
		case TextObject: {
			T_TEXTOBJECT *ptText = reinterpret_cast<T_TEXTOBJECT*>(ptBaseObject);
			ptObjChanRef = &ptText->ChannelInfo;
		}
			break;
		case ScaleObject: {
			T_SCALEOBJECT *ptScale = reinterpret_cast<T_SCALEOBJECT*>(ptBaseObject);
			ptObjChanRef = &ptScale->ChannelInfo;
		}
			break;
		case ChartObject: {
			T_CHARTOBJECT *ptChart = reinterpret_cast<T_CHARTOBJECT*>(ptBaseObject);
			strTitle = CConfigObjectData::GetTypeName(DI_PEN, 0);
		}
			break;
		case PenPointersObject: {
			T_PENPTRSOBJECT *ptPenPtr = reinterpret_cast<T_PENPTRSOBJECT*>(ptBaseObject);
			strTitle = CConfigObjectData::GetTypeName(DI_PEN, 0);
		}
			break;
		case AlarmMrkrObject: {
			T_ALARMMRKROBJECT *ptAlarmMrkr = reinterpret_cast<T_ALARMMRKROBJECT*>(ptBaseObject);
			ptObjChanRef = &ptAlarmMrkr->ChannelInfo[0];
		}
			break;
		case ExampleBar:
			break;
		case BitmapObject:
			break;
		case TabularDisplayObject: {
			T_TABULAROBJECT *ptTabDispPtr = reinterpret_cast<T_TABULAROBJECT*>(ptBaseObject);
			strTitle = CConfigObjectData::GetTypeName(DI_PEN, 0);
		}
			break;
		case TUSObject:
			break;
		case CircularChartObject: {
			T_CIRCCHARTOBJECT *ptChart = reinterpret_cast<T_CIRCCHARTOBJECT*>(ptBaseObject);
			strTitle = CConfigObjectData::GetTypeName(DI_PEN, 0);
		}
			break;
		case NoObject:
			break;
		default:
			break;
		}
	}
	// exit from the loop if we have set the title field - would imply there is a chart
	if (strTitle != "") {
		break;
	}
	// check if set to use parent
	if ((ptObjChanRef != NULL) && (ptObjChanRef->IndexChan == 0)) {
		// using parent therefore get this objects type and possibly subtype
		strTitle = CConfigObjectData::GetTypeName(ptObjChanRef->ItemType, ptObjChanRef->SubType);
		// found an instance therefore drop out
		break;
	}
	ptObjChanRef = NULL;
}
return strTitle;
}
//****************************************************************************
// void SetupWidgetChannelMapData( CWidget *pkWidget, CConfigBranch *pkParent )
///
/// Method that creates all the widget channel map data
///
/// @param[in]			CWidget *pkWidget - Pointer to the widget
/// @param[in/out]		CConfigBranch *pkParent - Pointer to the parent branch
///
///
//****************************************************************************
void CScrnDesCfgMgr::SetupWidgetChannelMapData(CWidget *pkWidget, CConfigBranch *pkParent) {
// add the instance number button first, followed by the channels button
// need to get the screen channel instance location - the first item in the widget list is the parent
// channel
QString strTitle("");
QString strSubTitle("");
USHORT usChanType = 0xFFFF;
USHORT usChanSubType = 0;
pkWidget->GetWidgetChannelType(usChanType, usChanSubType, CWidget::ms_usPARENT_INDEX);
CScreen *pkScreen = pkWidget->GetScreen();
T_SCREEN *ptScreen = reinterpret_cast<T_PSCREEN>(pkScreen->GetCMMInfo().pByBlock);
T_WIDGET *ptCMMWidget = pkWidget->GetCMMWidget();
// only show the channel map information if this is not the template screen
if (pkScreen->GetLayoutItem().CMM_Inst != TEMPLATE_SCREEN_INST) {
	// Parent instance no - this will create a pick list
	// check a valid picker was chosen which implies we have some objects
	if ((usChanType != 0xFFFF) && !pkWidget->ContainsMultiPenObj()
			&& ptCMMWidget->ChannelList[CWidget::ms_usPARENT_INDEX] >= CWidget::ms_usCHANNEL_OFFSET) {
		// add the instance and channels buttons
		T_CFG_DATA_TYPE eDataType = dtNone;
		if ((usChanType == DI_PEN) || (usChanType == DI_MMA) || (usChanType == DI_ALARM)) {
			eDataType = dtSinglePen;
		} else if (usChanType == DI_IO) {
			if (usChanSubType == DI_IO_ANALOGUE) {
				eDataType = dtSingleAnalogueIn;
			} else if (usChanSubType == DI_IO_DIGITAL) {
				eDataType = dtSingleDigIn;
			} else if (usChanSubType == DI_IO_HIPULSE) {
				eDataType = dtSingleHiPulseIn;
			} else if (usChanSubType == DI_IO_LOPULSE) {
				eDataType = dtSingleLoPulseIn;
			} else {
				// @todo add more data item types here
			}
		} else {
			// @todo add more data item types here
		}
		CPickerData *pkInstanceNoData = new CPickerData(
				reinterpret_cast<USHORT*>(&ptScreen->ChannelMap[ptCMMWidget->ChannelList[CWidget::ms_usPARENT_INDEX]
						- CWidget::ms_usCHANNEL_OFFSET]), eDataType, 0, 0, true, 1, 1);
		// we no need to set an appropriate title based on the first object that is using a pen
		strTitle = GetWidgetParentInstTitle(pkWidget);
		strSubTitle = pkInstanceNoData->GetDataAsString();
		CConfigItem *pkInstanceNo = new CConfigItem(L"INST", strTitle, strSubTitle, ctItemButton, pkInstanceNoData,
				false, true, 0, false, pkParent);
		pkParent->AddChild(pkInstanceNo);
		SetupWidgetChannelDetails(pkWidget, pkParent);
	} else if (pkWidget->ContainsMultiPenObj()) {
		// Setup channel details only - no parent picker
		SetupWidgetChannelDetails(pkWidget, pkParent);
	}
}
}
//****************************************************************************
// CConfigBranch* CScrnDesCfgMgr::CreateSettingsConfig()
///
/// Method that creates a screen settings config heirarchy
///
/// @return Pointer to the layout settings config hierarchy
///
//****************************************************************************
CConfigBranch* CScrnDesCfgMgr::CreateSettingsConfig() {
CConfigBranch *pkParent = NULL;
QString strTitle("");
COpPanel *pkOpPanel = reinterpret_cast<COpPanel*>(AfxGetApp()->m_pMainWnd);
T_LAYOUT *ptCMMLayout = pkOpPanel->m_pCMMlayout;
// check the layout data is valid
if (ptCMMLayout != NULL) {
	strTitle = tr("Layout Settings");
	pkParent = new CConfigBranch(ms_strSETTINGS_KEY, strTitle, strTitle, ctSubMenuButton, false, true, 0, false, NULL);
	// rotate screens enable - this will be a boolean bitfield
	CShortBitFieldData *pkRotateEnData = new CShortBitFieldData(reinterpret_cast<USHORT*>(ptCMMLayout), 1, 0,
			ms_strEnabledList, bfeBool, 0, 0, true);
	strTitle = tr("Cycle Screens");
	CConfigItem *pkRotateEn = new CConfigItem(ms_strSETTINGS_ROTATE_ENABLED_KEY, strTitle,
			pkRotateEnData->GetDataAsString(), ctItemButton, pkRotateEnData, false, true, 0, false, pkParent);
	pkParent->AddChild(pkRotateEn);
	// screen picker
	// setup and initialise the rotating screens bitfield and screen list - enabled screens only
	COpPanel *pkOpPanel = reinterpret_cast<COpPanel*>(AfxGetApp()->m_pMainWnd);
	m_tRotScreenPickerData.ulScreenBitset = pkOpPanel->GetRotatingScreensBitfield();
	m_tRotScreenPickerData.strScreenList = pkOpPanel->GetScreenList();
	CPickerData *pkScreenPickerData = new CPickerData(reinterpret_cast<USHORT*>(&m_tRotScreenPickerData), dtScreens, 0,
			0, true, // update tree so the C++ screen objects CMM data is updated
			1,
			LAYOUT_SCREENLIST_SIZE);
	strTitle = tr("Cycle List");
	CConfigItem *pkScreenPicker = new CConfigItem(ms_strSETTINGS_ROTATE_SCREENS_KEY, strTitle,
			pkScreenPickerData->GetDataAsString(), ctItemButton, pkScreenPickerData, false,
			(ptCMMLayout->RotateScreens == TRUE), 0, false, pkParent);
	pkParent->AddChild(pkScreenPicker);
	// rotate interval in seconds
	QString strSeconds("");
	strSeconds = tr("Secs.");
	CUShortData *pkRotIntervalData = new CUShortData(&ptCMMLayout->RotateTime, 5, 3600, 0, 0, false, dtUnsignedShort,
			strSeconds);
	strTitle = tr("Cycle Interval");
	CConfigItem *pkRotInterval = new CConfigItem(ms_strSETTINGS_ROTATE_INTERVAL_KEY, strTitle,
			pkRotIntervalData->GetDataAsString(true), ctItemButton, pkRotIntervalData, false,
			(ptCMMLayout->RotateScreens == TRUE), 0, false, pkParent);
	pkParent->AddChild(pkRotInterval);
	// manual intervention in seconds
	CUShortData *pkManIntData = new CUShortData(&ptCMMLayout->ManIntervTime, 0, 3600, 0, 0, false, dtUnsignedShort,
			strSeconds);
	strTitle = tr("Screen Hold");
	CConfigItem *pkManInt = new CConfigItem(ms_strSETTINGS_MANUAL_INTERVENTION_KEY, strTitle,
			pkManIntData->GetDataAsString(true), ctItemButton, pkManIntData, false,
			(ptCMMLayout->RotateScreens == TRUE), 0, false, pkParent);
	pkParent->AddChild(pkManInt);
	// alarm screen enabled - this will be a boolean bitfield
	CShortBitFieldData *pkAlarmSrcEnData = new CShortBitFieldData(reinterpret_cast<USHORT*>(ptCMMLayout), 1, 1,
			ms_strEnabledList, bfeBool, 0, 0, true);
	strTitle = tr("Alarm Screen");
	CConfigItem *pkAlarmSrcEn = new CConfigItem(ms_strSETTINGS_ALARM_SCREEN_ENABLED_KEY, strTitle,
			pkAlarmSrcEnData->GetDataAsString(), ctItemButton, pkAlarmSrcEnData, false, true, 0, false, pkParent);
	pkParent->AddChild(pkAlarmSrcEn);
	// alarm screen - this will be a single selection list
	// get the latest screen list - do not include disabled screens and embed the screen ID's
	ms_strScreenList = pkOpPanel->GetScreenList(false, true);
	CShortBitFieldData *pkAlarmScreenListData = new CShortBitFieldData(reinterpret_cast<USHORT*>(ptCMMLayout), 8, 2,
			ms_strScreenList, bfeSingleSelList, 0, 0, false);
	strTitle = tr("Alarm Scrn Name");
	CConfigItem *pkAlarmScreenList = new CConfigItem(ms_strSETTINGS_ALARM_SCREEN_NAME_KEY, strTitle,
			pkAlarmScreenListData->GetDataAsString(), ctItemButton, pkAlarmScreenListData, false,
			(ptCMMLayout->AlarmScreen == TRUE), 0, false, pkParent);
	pkParent->AddChild(pkAlarmScreenList);
	// Replay screen timeout enabled - this will be a boolean bitfield
	CShortBitFieldData *pkReplaySrcTimeoutEnData = new CShortBitFieldData(reinterpret_cast<USHORT*>(ptCMMLayout), 1, 10,
			ms_strEnabledList, bfeBool, 0, 0, true);
	strTitle = tr("Replay Scrn TO");
	CConfigItem *pkReplaySrcTimeoutEn = new CConfigItem(ms_strSETTINGS_REPLAY_SCREEN_TIMEOUT_EN_KEY, strTitle,
			pkReplaySrcTimeoutEnData->GetDataAsString(), ctItemButton, pkReplaySrcTimeoutEnData, false, true, 0, false,
			pkParent);
	pkParent->AddChild(pkReplaySrcTimeoutEn);
	QString strMinutes("");
	strMinutes = tr("Mins.");
	CUShortData *pkReplayTimeoutData = new CUShortData(&ptCMMLayout->RplyTimeout, 1, 60, 0, 0, false, dtUnsignedShort,
			strMinutes);
	strTitle = tr("Replay Timeout");
	CConfigItem *pkReplayTimeout = new CConfigItem(ms_strSETTINGS_REPLAY_SCREEN_TIMEOUT_KEY, strTitle,
			pkReplayTimeoutData->GetDataAsString(true), ctItemButton, pkReplayTimeoutData, false,
			(ptCMMLayout->RplScrnTimeout == TRUE), 0, false, pkParent);
	pkParent->AddChild(pkReplayTimeout);
	/* REMOVED FOR NOW AS JP BELIEVES THIS OPTION IS UNECESSARY
	 // Hide status bar timeout enabled - this will be a boolean bitfield
	 CShortBitFieldData *pkHideStatusBarData = new CShortBitFieldData(	reinterpret_cast< USHORT* >( ptCMMLayout ),
	 1,
	 11,
	 ms_strEnabledList,
	 bfeBool,
	 0,
	 0,
	 true );
	 strTitle = tr("Hide Menu Bar");
	 CConfigItem *pkHideStatusBar = new CConfigItem(	ms_strSETTINGS_HIDE_STATUS_BAR_KEY,
	 strTitle,
	 pkHideStatusBarData->GetDataAsString(),						
	 ctItemButton,
	 pkHideStatusBarData,
	 false,
	 true,
	 0,
	 false,
	 pkParent );
	 pkParent->AddChild( pkHideStatusBar );
	 */
	// hide status bar timeout in seconds
	CUShortData *pkHideStatusBarTimeoutData = new CUShortData(&ptCMMLayout->StatBarTimeout, 5, 3600, 0, 0, false,
			dtUnsignedShort, strSeconds);
	strTitle = tr("Menu Bar TO");
	CConfigItem *pkHideStatusBarTimeout = new CConfigItem(ms_strSETTINGS_HIDE_STATUS_BAR_TIMEOUT_KEY, strTitle,
			pkHideStatusBarTimeoutData->GetDataAsString(true), ctItemButton, pkHideStatusBarTimeoutData, false, true,// removed for now - see comment above( ptCMMLayout->HideStatusBar == TRUE ),
			0, false, pkParent);
	pkParent->AddChild(pkHideStatusBarTimeout);
// Hour Stamps (for EDF) enabled - this will be a boolean bitfield
	CShortBitFieldData *pkHourStamps = new CShortBitFieldData(reinterpret_cast<USHORT*>(ptCMMLayout), 1, 12,
			ms_strEnabledList, bfeBool, 0, 0, false);
	strTitle = tr("Hourly Stamps");
	CConfigItem *pkHourstamping = new CConfigItem(ms_strSETTINGS_HOUR_TIMESTAMPS_KEY, strTitle,
			pkHourStamps->GetDataAsString(), ctItemButton, pkHourStamps, false, true, 0, false, pkParent);
	pkParent->AddChild(pkHourstamping);
	//added by nilesh for Displaying Chart Start/Stop Messages
	//[
	// Display Chart Start Stop Messages enabled - this will be a boolean bitfield
	CShortBitFieldData *pkStartStopMessages = new CShortBitFieldData(reinterpret_cast<USHORT*>(ptCMMLayout), 1, 13,
			ms_strEnabledList, bfeBool, 0, 0, false);
	strTitle = tr("Show Chart Start/Stop Messages");
	CConfigItem *pkStartStopMessagesStamping = new CConfigItem(ms_strSETTINGS_SHOW_START_STOP_MESSAGES_KEY, strTitle,
			pkStartStopMessages->GetDataAsString(), ctItemButton, pkStartStopMessages, false, true, 0, false, pkParent);
	pkParent->AddChild(pkStartStopMessagesStamping);
	//]
	// create Hot buttons config......
	for (int i = 0; i < LAYOUT_HOTBUTTONLIST_SIZE; i++) {
		if ( pDEVICE_INFO->IsMultiScreen() == FALSE && i > 1) {
			break;	// DO not show 3rd and 4th hot button on mini trend or eztrend 
		}
		if ((pDEVICE_INFO->IsRecorderEzTrend() || pDEVICE_INFO->GetDeviceType() == DEV_PC_MINI) && i == 1)
			break; // Only one Hot button for Ez.... 
		T_PHOTBUTTON ptHotButton = &ptCMMLayout->HotButtonList[i];
		QString strKey;
		strKey = QString::asprintf("%u", i);
		strKey = ms_strHOTBUTTON_TITLE_KEY + strKey;
		strTitle = tr("Hot Btn");
		QString strasprintf = "";
		strasprintf = QString::asprintf(" %u", i + 1);
		strTitle = strTitle + strasprintf;
		CConfigBranch *pkIndHotButtonBranch = new CConfigBranch(strKey, strTitle,
				_wcsupr(ptCMMLayout->HotButtonList[i].Name), //kranti
				ctSubMenuButton, false, true, 0, false, pkParent);
		SetupHotButtonConfig(ptHotButton, pkIndHotButtonBranch);
		pkParent->AddChild(pkIndHotButtonBranch);
	}
}
return pkParent;
}
//****************************************************************************
// CConfigBranch* CreateAppearanceConfig()
///
/// Method that creates a layout appearance config heirarchy
///
/// @return Pointer to the layout appearance config hierarchy
///
//****************************************************************************
CConfigBranch* CScrnDesCfgMgr::CreateAppearanceConfig() {
CConfigBranch *pkParent = NULL;
QString strTitle("");
QString strSubTitle("");
QString strColourInfo("");
COpPanel *pkOpPanel = reinterpret_cast<COpPanel*>(AfxGetApp()->m_pMainWnd);
T_LAYOUT *ptCMMLayout = pkOpPanel->m_pCMMlayout;
// check the layout data is valid
if (ptCMMLayout != NULL) {
	strTitle = tr("Appearance");
	pkParent = new CConfigBranch(ms_strAPPEARANCE_KEY, strTitle, strTitle, ctSubMenuButton, false, true, 0, false,
	NULL);
	strTitle = tr("Chart");
	// Chart Normal Foreground Colour
	CULongData *pkChartNormForeData = new CULongData(&ptCMMLayout->ChartNormalFCol, 0, ms_ulMaxColour, 0, 0, true,
			dtColour);
	strSubTitle = tr("Graduations");
	strSubTitle = pkChartNormForeData->GetDataAsString() + strSubTitle;
	CConfigItem *pkChartNormFore = new CConfigItem(ms_strAPPEARANCE_CHART_NORMAL_FCOL_KEY, strTitle, strSubTitle,
			ctItemButton, pkChartNormForeData, false, true, 0, false, pkParent);
	pkParent->AddChild(pkChartNormFore);
	// Chart Normal background colour
	CULongData *pkChartNormBackData = new CULongData(&ptCMMLayout->ChartNormalBCol, 0, ms_ulMaxColour, 0, 0, true,
			dtColour);
	strSubTitle = tr("Color");
	strSubTitle = pkChartNormBackData->GetDataAsString() + strSubTitle;
	CConfigItem *pkChartNormBack = new CConfigItem(ms_strAPPEARANCE_CHART_NORMAL_BCOL_KEY, strTitle, strSubTitle,
			ctItemButton, pkChartNormBackData, false, true, 0, false, pkParent);
	pkParent->AddChild(pkChartNormBack);
	/* This colour is not used at the moment
	 // Chart Normal Alarm foreground colour
	 CULongData *pkChartNormAlmForeData = new CULongData(	&ptCMMLayout->ChartAlarmFCol,
	 0,
	 ms_ulMaxColour,
	 0,
	 0,
	 false,
	 dtColour );
	 strTitle = tr("Chart Alm Fore Col");
	 CConfigItem *pkChartNormAlmFore = new CConfigItem(	ms_strAPPEARANCE_CHART_ALM_NORMAL_FCOL_KEY,
	 strTitle,
	 pkChartNormAlmForeData->GetDataAsString( ),						
	 ctItemButton,
	 pkChartNormAlmForeData,
	 false,
	 true,
	 0,
	 false,
	 pkParent );
	 pkParent->AddChild( pkChartNormAlmFore );
	 */
	// Chart Normal Alarm background colour
	CULongData *pkChartNormAlmBackData = new CULongData(&ptCMMLayout->ChartAlarmBCol, 0, ms_ulMaxColour, 0, 0, true,
			dtColour);
	strSubTitle = tr("Alarm");
	strSubTitle = pkChartNormAlmBackData->GetDataAsString() + strSubTitle;
	CConfigItem *pkChartNormAlmBack = new CConfigItem(ms_strAPPEARANCE_CHART_ALM_NORMAL_BCOL_KEY, strTitle, strSubTitle,
			ctItemButton, pkChartNormAlmBackData, false, true, 0, false, pkParent);
	pkParent->AddChild(pkChartNormAlmBack);
	strTitle = tr("Replay");
	// Chart Replay Foreground Colour
	CULongData *pkChartReplayForeData = new CULongData(&ptCMMLayout->ChartReplayFCol, 0, ms_ulMaxColour, 0, 0, true,
			dtColour);
	strSubTitle = tr("Graduations");
	strSubTitle = pkChartReplayForeData->GetDataAsString() + strSubTitle;
	CConfigItem *pkChartReplayFore = new CConfigItem(ms_strAPPEARANCE_CHART_REPLAY_FCOL_KEY, strTitle, strSubTitle,
			ctItemButton, pkChartReplayForeData, false, true, 0, false, pkParent);
	pkParent->AddChild(pkChartReplayFore);
	// Chart Replay background colour
	CULongData *pkChartReplayBackData = new CULongData(&ptCMMLayout->ChartReplayBCol, 0, ms_ulMaxColour, 0, 0, true,
			dtColour);
	strSubTitle = tr("Color");
	strSubTitle = pkChartReplayBackData->GetDataAsString() + strSubTitle;
	CConfigItem *pkChartReplayBack = new CConfigItem(ms_strAPPEARANCE_CHART_REPLAY_BCOL_KEY, strTitle, strSubTitle,
			ctItemButton, pkChartReplayBackData, false, true, 0, false, pkParent);
	pkParent->AddChild(pkChartReplayBack);
	/* This colour is not used at the moment
	 // Chart Replay Alarm foreground colour
	 CULongData *pkChartReplayAlmForeData = new CULongData(	&ptCMMLayout->ChartRplAlmFCol,
	 0,
	 ms_ulMaxColour,
	 0,
	 0,
	 false,
	 dtColour );
	 strTitle = tr("Replay Alm Fore Col");
	 CConfigItem *pkChartReplayAlmFore = new CConfigItem(	ms_strAPPEARANCE_CHART_ALM_REPLAY_FCOL_KEY,
	 strTitle,
	 pkChartReplayAlmForeData->GetDataAsString( ),						
	 ctItemButton,
	 pkChartReplayAlmForeData,
	 false,
	 true,
	 0,
	 false,
	 pkParent );
	 pkParent->AddChild( pkChartReplayAlmFore );
	 */
	// Chart Replay Alarm background colour
	CULongData *pkChartReplayAlmBackData = new CULongData(&ptCMMLayout->ChartRplAlmBCol, 0, ms_ulMaxColour, 0, 0, true,
			dtColour);
	strSubTitle = tr("Alarm");
	strSubTitle = pkChartReplayAlmBackData->GetDataAsString() + strSubTitle;
	CConfigItem *pkChartReplayAlmBack = new CConfigItem(ms_strAPPEARANCE_CHART_ALM_REPLAY_BCOL_KEY, strTitle,
			strSubTitle, ctItemButton, pkChartReplayAlmBackData, false, true, 0, false, pkParent);
	pkParent->AddChild(pkChartReplayAlmBack);
	// Chart Text foreground colour
	CULongData *pkChartTextForeData = new CULongData(&ptCMMLayout->ChartTextFCol, 0, ms_ulMaxColour, 0, 0, false,
			dtColour);
	strTitle = tr("Timestamp");
	CConfigItem *pkChartTextFore = new CConfigItem(ms_strAPPEARANCE_CHART_TEXT_FCOL_KEY, strTitle,
			pkChartTextForeData->GetDataAsString(), ctItemButton, pkChartTextForeData, false, true, 0, false, pkParent);
	pkParent->AddChild(pkChartTextFore);
	// Chart text background colour
	CULongData *pkChartTextBackData = new CULongData(&ptCMMLayout->ChartTextBCol, 0, ms_ulMaxColour, 0, 0, false,
			dtColour);
	strTitle = tr("Marker Color");
	CConfigItem *pkChartTextBack = new CConfigItem(ms_strAPPEARANCE_CHART_TEXT_BCOL_KEY, strTitle,
			pkChartTextBackData->GetDataAsString(), ctItemButton, pkChartTextBackData, false, true, 0, false, pkParent);
	pkParent->AddChild(pkChartTextBack);
	/* REMOVED UNTIL SOME DECENT SHORT NAMES CAN BE THOUGHT OF
	 // In alarm not acknowldged foreground colour
	 CULongData *pkInAlmNackForeData = new CULongData(	&ptCMMLayout->AlmInNAckFCol,
	 0,
	 ms_ulMaxColour,
	 0,
	 0,
	 false,
	 dtColour );
	 strTitle = tr("In Alm Nack Fore Col");
	 CConfigItem *pkInAlmNackFore = new CConfigItem(	ms_strAPPEARANCE_ALM_IN_NACK_FCOL_KEY,
	 strTitle,
	 pkInAlmNackForeData->GetDataAsString( ),						
	 ctItemButton,
	 pkInAlmNackForeData,
	 false,
	 true,
	 0,
	 false,
	 pkParent );
	 pkParent->AddChild( pkInAlmNackFore );
	 // In alarm not acknowldged background colour
	 CULongData *pkInAlmNackBackData = new CULongData(	&ptCMMLayout->AlmInNAckBCol,
	 0,
	 ms_ulMaxColour,
	 0,
	 0,
	 false,
	 dtColour );
	 strTitle = tr("In Alm Nack Back Col");
	 CConfigItem *pkInAlmNackBack = new CConfigItem(	ms_strAPPEARANCE_ALM_IN_NACK_BCOL_KEY,
	 strTitle,
	 pkInAlmNackBackData->GetDataAsString( ),						
	 ctItemButton,
	 pkInAlmNackBackData,
	 false,
	 true,
	 0,
	 false,
	 pkParent );
	 pkParent->AddChild( pkInAlmNackBack );
	 // In alarm acknowldged foreground colour
	 CULongData *pkInAlmAckForeData = new CULongData(	&ptCMMLayout->AlmInAckFCol,
	 0,
	 ms_ulMaxColour,
	 0,
	 0,
	 false,
	 dtColour );
	 strTitle = tr("In Alm Ack Fore Col");
	 CConfigItem *pkInAlmAckFore = new CConfigItem(	ms_strAPPEARANCE_ALM_IN_ACK_FCOL_KEY,
	 strTitle,
	 pkInAlmAckForeData->GetDataAsString( ),						
	 ctItemButton,
	 pkInAlmAckForeData,
	 false,
	 true,
	 0,
	 false,
	 pkParent );
	 pkParent->AddChild( pkInAlmAckFore );
	 // In alarm acknowldged background colour
	 CULongData *pkInAlmAckBackData = new CULongData(	&ptCMMLayout->AlmInAckBCol,
	 0,
	 ms_ulMaxColour,
	 0,
	 0,
	 false,
	 dtColour );
	 strTitle = tr("In Alm Ack Back Col");
	 CConfigItem *pkInAlmAckBack = new CConfigItem(	ms_strAPPEARANCE_ALM_IN_ACK_BCOL_KEY,
	 strTitle,
	 pkInAlmAckBackData->GetDataAsString( ),						
	 ctItemButton,
	 pkInAlmAckBackData,
	 false,
	 true,
	 0,
	 false,
	 pkParent );
	 pkParent->AddChild( pkInAlmAckBack );
	 // Out alarm not acknowldged foreground colour
	 CULongData *pkOutAlmNackForeData = new CULongData(	&ptCMMLayout->AlmOutNAckFCol,
	 0,
	 ms_ulMaxColour,
	 0,
	 0,
	 false,
	 dtColour );
	 strTitle = tr("Out Alm Nack Fore Col");
	 CConfigItem *pkOutAlmNackFore = new CConfigItem(	ms_strAPPEARANCE_ALM_OUT_NACK_FCOL_KEY,
	 strTitle,
	 pkOutAlmNackForeData->GetDataAsString( ),						
	 ctItemButton,
	 pkOutAlmNackForeData,
	 false,
	 true,
	 0,
	 false,
	 pkParent );
	 pkParent->AddChild( pkOutAlmNackFore );
	 // Out alarm not acknowldged background colour
	 CULongData *pkOutAlmNackBackData = new CULongData(	&ptCMMLayout->AlmOutNAckBCol,
	 0,
	 ms_ulMaxColour,
	 0,
	 0,
	 false,
	 dtColour );
	 strTitle = tr("Out Alm Nack Back Col");
	 CConfigItem *pkOutAlmNackBack = new CConfigItem(	ms_strAPPEARANCE_ALM_OUT_NACK_BCOL_KEY,
	 strTitle,
	 pkOutAlmNackBackData->GetDataAsString( ),						
	 ctItemButton,
	 pkOutAlmNackBackData,
	 false,
	 true,
	 0,
	 false,
	 pkParent );
	 pkParent->AddChild( pkOutAlmNackBack );
	 // Out alarm foreground colour
	 CULongData *pkOutAlmForeData = new CULongData(	&ptCMMLayout->AlmOutFCol,
	 0,
	 ms_ulMaxColour,
	 0,
	 0,
	 false,
	 dtColour );
	 strTitle = tr("Out Alm Fore Col");
	 CConfigItem *pkOutAlmFore = new CConfigItem(	ms_strAPPEARANCE_ALM_OUT_FCOL_KEY,
	 strTitle,
	 pkOutAlmForeData->GetDataAsString( ),						
	 ctItemButton,
	 pkOutAlmForeData,
	 false,
	 true,
	 0,
	 false,
	 pkParent );
	 pkParent->AddChild( pkOutAlmFore );
	 // Out alarm background colour
	 CULongData *pkOutAlmBackData = new CULongData(	&ptCMMLayout->AlmOutBCol,
	 0,
	 ms_ulMaxColour,
	 0,
	 0,
	 false,
	 dtColour );
	 strTitle = tr("Out Alm Back Col");
	 CConfigItem *pkOutAlmBack = new CConfigItem(	ms_strAPPEARANCE_ALM_OUT_BCOL_KEY,
	 strTitle,
	 pkOutAlmBackData->GetDataAsString( ),						
	 ctItemButton,
	 pkOutAlmBackData,
	 false,
	 true,
	 0,
	 false,
	 pkParent );
	 pkParent->AddChild( pkOutAlmBack );
	 // Alarm overview foreground colour
	 CULongData *pkAlmOverviewForeData = new CULongData(	&ptCMMLayout->AlmOverviewFCol,
	 0,
	 ms_ulMaxColour,
	 0,
	 0,
	 false,
	 dtColour );
	 strTitle = tr("Alm Overview Fore Col");
	 CConfigItem *pkAlmOverviewFore = new CConfigItem(	ms_strAPPEARANCE_ALM_OVERVIEW_FCOL_KEY,
	 strTitle,
	 pkAlmOverviewForeData->GetDataAsString( ),						
	 ctItemButton,
	 pkAlmOverviewForeData,
	 false,
	 true,
	 0,
	 false,
	 pkParent );
	 pkParent->AddChild( pkAlmOverviewFore );
	 // Alarm overview background colour
	 CULongData *pkAlmOverviewBackData = new CULongData(	&ptCMMLayout->AlmOverviewBCol,
	 0,
	 ms_ulMaxColour,
	 0,
	 0,
	 false,
	 dtColour );
	 strTitle = tr("Alm Overview Back Col");
	 CConfigItem *pkAlmOverviewBack = new CConfigItem(	ms_strAPPEARANCE_ALM_OVERVIEW_BCOL_KEY,
	 strTitle,
	 pkAlmOverviewBackData->GetDataAsString( ),						
	 ctItemButton,
	 pkAlmOverviewBackData,
	 false,
	 true,
	 0,
	 false,
	 pkParent );
	 pkParent->AddChild( pkAlmOverviewBack );
	 */
}
return pkParent;
}
//****************************************************************************
///
/// Method that turns the screen template list into a non-sequential list, removing the AMS2750 options
/// as necessary
///
//****************************************************************************
void CScrnDesCfgMgr::MakeScreenTemplateListNonSequential() {
// we need to change the screen type list to a non-sequential list because of the
// AMS2750 templates shouldn't be shown if the AMS2750 options aren't selected
QString strScreenTemplateList("");
QString strScreenTemplateName("");
USHORT usScreenTemplateIndex = 0;
QString strNonSequentialName("");
// get the existing list, sequential list with all the templates present
strScreenTemplateList = ms_strCustomScreenTypeList;
ms_strCustomScreenTypeList = "";
strScreenTemplateName = CStringUtils::GetItemAtPos(strScreenTemplateList, usScreenTemplateIndex);
while (strScreenTemplateName != "") {
	// add the index to the end of the screen template name along with its delimitters
	strNonSequentialName = QString::asprintf("%s%c%u%c|", strScreenTemplateName, g_wcEMBEDDED_INFO_DELIM,
			usScreenTemplateIndex, g_wcEMBEDDED_INFO_DELIM);
	// check if this is the AMS2750 process or TUS screens
	if (usScreenTemplateIndex == TPL_AMS2750_PROCESS_SCREEN) {
		// check the firmware option is okay before adding
		if ( pSYSTEM_INFO->GetAMS2750Mode() == AMS2750_PROCESS) {
			ms_strCustomScreenTypeList += strNonSequentialName;
		}
	} else if (usScreenTemplateIndex == TPL_AMS2750_TUS_SCREEN) {
		// never add this option to the screen list 
	}
	//PSR Fix for PAR # 1-3JLZOK8 - Remove Circular chart from Multi and Mini Recorder begin
	///Remove the Circular chart option from the Template type list if the 
	//Circular chart feature is not available
	else if (usScreenTemplateIndex == TPL_CIRC_CHRT_DPMS) {
		if ( TRUE == GlbDevCaps.IsCircularChartModeAvailable()) {
			ms_strCustomScreenTypeList += strNonSequentialName;
		}
	}
	//PSR Fix for PAR # 1-3JLZOK8 - Remove Circular chart from Multi and Mini Recorder end
	else {
		// this must be a non-AMS2750 canned screen or a custom template so always add it
		ms_strCustomScreenTypeList += strNonSequentialName;
	}
	// move onto the next item
	++usScreenTemplateIndex;
	// get the next screen name - this might be blank if we are at the end of the list
	strScreenTemplateName = CStringUtils::GetItemAtPos(strScreenTemplateList, usScreenTemplateIndex);
}
//Aditya - Non process screens shouldn't be there for SD , but should be there for Recorder.
if (m_bIsScreenDesigner == false) {
	// Add NON process screens here......
	//Aditya
	//Non processing screens are not required to be displayed in properties dropdown list when screen is selected
	usScreenTemplateIndex = 0;
	strScreenTemplateList = ms_strNPScreenTypeList;
	strScreenTemplateName = CStringUtils::GetItemAtPos(strScreenTemplateList, usScreenTemplateIndex);
	while (strScreenTemplateName != "") {
		// add the index to the end of the screen template name along with its delimitters
		strNonSequentialName = QString::asprintf("%s%c%u%c|", strScreenTemplateName, g_wcEMBEDDED_INFO_DELIM,
				usScreenTemplateIndex + TPL_ALARM, g_wcEMBEDDED_INFO_DELIM);
		ms_strCustomScreenTypeList += strNonSequentialName;
		// move onto the next item
		++usScreenTemplateIndex;
		// get the next screen name - this might be blank if we are at the end of the list
		strScreenTemplateName = CStringUtils::GetItemAtPos(strScreenTemplateList, usScreenTemplateIndex);
	}
}
// Add NON process MSG screens here......
usScreenTemplateIndex = 0;
ms_strCustomMsgScreenTypeList = "";
strScreenTemplateList = ms_strNPMSGScreenTypeList;
strScreenTemplateName = CStringUtils::GetItemAtPos(strScreenTemplateList, usScreenTemplateIndex);
while (strScreenTemplateName != "") {
	// add the index to the end of the screen template name along with its delimitters
	strNonSequentialName = QString::asprintf("%s%c%u%c|", strScreenTemplateName, g_wcEMBEDDED_INFO_DELIM,
			usScreenTemplateIndex + TPL_MSG_ALL, g_wcEMBEDDED_INFO_DELIM);
	ms_strCustomMsgScreenTypeList += strNonSequentialName;
	// move onto the next item
	++usScreenTemplateIndex;
	// get the next screen name - this might be blank if we are at the end of the list
	strScreenTemplateName = CStringUtils::GetItemAtPos(strScreenTemplateList, usScreenTemplateIndex);
}
}
QString CScrnDesCfgMgr::GetNPScrnTypes() {
return ms_strNPScreenTypeList;
}

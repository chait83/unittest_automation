/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Configuration System
/// @n Filename:  ConfigData.h
/// @n Description: Implementation for the CConfigData base class and its inherited classes
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  105  Stability Project 1.100.1.3  7/2/2011 4:56:15 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  104  Stability Project 1.100.1.2  7/1/2011 4:38:07 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  103  Stability Project 1.100.1.1  3/17/2011 3:20:16 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  102  Stability Project 1.100.1.0  2/15/2011 3:02:39 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
//
// **************************************************************************
#include "ConfigData.h"
#include "math.h"
#include "limits.h"
#include "OEMInfo.h"
#include "BaseCfgMgr.h"
#include "StringUtils.h"
#include "Scripts.h"
#include "V6MessageBoxDlg.h"
//#include "CfgBrightnessDlg.h"
//#include "Crypto.h"
#include "TVtime.h"
#include "EUDCDefs.h"
#include "V6defines.h"
#include "MathUtils.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
extern QMutex m_GlbSetupMutex;
/// Static intialisation
CConfigData *CConfigData::ms_pkEditData = NULL;
//****************************************************************************
// CConfigData(	const T_CFG_DATA_TYPE eDATA_TYPE,
//					const int iHELP_ID,
//					const int iDESC_ID,
//					const bool bUPDATE_TREE_ON_CHANGE,
//					const bool bREQUIRES_RESTART /* = false */ )
///
/// Constructor
///
/// @param[in] 			const T_CFG_DATA_TYPE eDATA_TYPE - The type of variable being stored
/// @param[in]			const int iHELP_ID - The resource ID of the assocaited help for
///						this item
/// @param[in]			const int iDESC_ID - The resource ID of the assocaited description for
///						this item
/// @param[in]			const bool bUPDATE_TREE_ON_CHANGE - Flag indicating if this item requires
///						the config tree to be rebuilt when it changes
/// @param[in]			const bool bREQUIRES_RESTART - Flag indicating if this item requires a restart
/// @param[in]			const QString   &rstrUNITS - The units that need to be displayed after the string
///
//****************************************************************************
CConfigData::CConfigData(const T_CFG_DATA_TYPE eDATA_TYPE, const int iHELP_ID, const int iDESC_ID,
		const bool bUPDATE_TREE_ON_CHANGE, const bool bREQUIRES_RESTART /* = false */, const QString &rstrUNITS) : m_eDATA_TYPE(
		eDATA_TYPE), m_bUPDATE_TREE_ON_CHANGE(bUPDATE_TREE_ON_CHANGE), m_bREQUIRES_RESTART(bREQUIRES_RESTART), m_strUNITS(
		rstrUNITS) {
}
//****************************************************************************
// ~CConfigData()
///
/// Destructor
///
//****************************************************************************
CConfigData::~CConfigData(void) {
}
//****************************************************************************
// CBoolData(	TV_BOOL* pbData,
//				const int iHELP_ID,
//				const int iDESC_ID,
//				const bool bUPDATE_TREE_ON_CHANGE )
///
/// Constructor
///
///	@param[in]			TV_BOOL* pbDATA - Pointer to the actual data
/// @param[in]			const int iHELP_ID - The resource ID of the assocaited help for
///						this item
/// @param[in]			const int iDESC_ID - The resource ID of the assocaited description for
///						this item
/// @param[in]			const bool bUPDATE_TREE_ON_CHANGE - Flag indicating if this item requires
///						the config tree to be rebuilt when it changes
///
//****************************************************************************
CBoolData::CBoolData(TV_BOOL *pbData, const int iHELP_ID, const int iDESC_ID, const bool bUPDATE_TREE_ON_CHANGE) : CConfigData(
		dtBool, iHELP_ID, iDESC_ID, bUPDATE_TREE_ON_CHANGE) {
	m_pbData = pbData;
}
//****************************************************************************
// ~CBoolData(void)
///
/// Destructor
///
//****************************************************************************
CBoolData::~CBoolData(void) {
}
//****************************************************************************
// void UpdateData( TV_BOOL bTRUE )
///
/// Method that updates an item's associated data
///
//****************************************************************************
void CBoolData::UpdateData(TV_BOOL bTRUE) {
	*m_pbData = bTRUE;
}
//****************************************************************************
// void UpdateData( const WCHAR* const pwcDATA )
///
/// Method that updates an item's associated data
///
//****************************************************************************
void CBoolData::UpdateData(const QString pwcDATA) {
	if (*pwcDATA == 0x0E042) {
		*m_pbData = TRUE;
	} else {
		*m_pbData = FALSE;
	}
}
//****************************************************************************
// const QString   GetDataAsString( const bool bINCLUDE_UNITS /* = false */ )
///
/// Method that returns the data as a string
///
/// @return			The data item represented by the boolean value - "" if there was a problem
///
//****************************************************************************
const QString CBoolData::GetDataAsString(const bool bINCLUDE_UNITS /* = false */) {
	QString strData("");
	strData = CStringUtils::GetItemAtPos(CBaseCfgMgr::ms_strEnabledList, *m_pbData);
	return strData;
}
//****************************************************************************
// CFloatData( float* pfDATA,
//				const float fLOWER,
//				const float fUPPER,
//				const int iHELP_ID,
//				const int iDESC_ID,
//				const bool bUPDATE_TREE_ON_CHANGE,
//				const T_CFG_DATA_TYPE eDATA_TYPE /* = dtFloat */,
//				const T_TEMP_UNIT eTEMP_UNIT /* = TEMP_DEG_C */,
//				const QString   strUNITS /* = QString   ::fromWCharArray("") */,
//				const T_PNUMFORMAT ptNUM_FORMAT = NULL )
///
/// Constructor
///
///	@param[in]			float* pfDATA - Pointer to the actual data
///	@param[in]			const float fLOWER - the lower limit of this value
///	@param[in]			const float fUPPER - the upper limit of this value
/// @param[in]			const int iHELP_ID - The resource ID of the assocaited help for
///						this item
/// @param[in]			const int iDESC_ID - The resource ID of the assocaited description for
///						this item
/// @param[in]			const bool bUPDATE_TREE_ON_CHANGE - Flag indicating if this item requires
///						the config tree to be rebuilt when it changes
/// @param[in]			const T_CFG_DATA_TYPE eDATA_TYPE - The float data type - temperature or
///						not specified
/// @param[in]			const T_TEMP_TYPE eTEMP_UNIT - The temp units the data must be displayed in
/// @param[in]			const QString   strUNITS - The units that need to be displayed after the string
/// @param[in]			const T_PNUMFORMAT ptNUM_FORMAT - Pointer to the associated num format structure (if any)
///
//****************************************************************************
CFloatData::CFloatData(float *pfDATA, const float fLOWER, const float fUPPER, const int iHELP_ID, const int iDESC_ID,
		const bool bUPDATE_TREE_ON_CHANGE, const T_CFG_DATA_TYPE eDATA_TYPE /* = dtFloat */,
		const T_TEMP_UNIT eTEMP_UNIT /* = TEMP_DEG_C */, const QString strUNITS /* = QString   ::fromWCharArray("") */,
		const T_PNUMFORMAT ptNUM_FORMAT /* = NULL */) : CConfigData(eDATA_TYPE, iHELP_ID, iDESC_ID,
		bUPDATE_TREE_ON_CHANGE, false, strUNITS), m_eDISP_TEMP_UNIT(eTEMP_UNIT), m_ptNUM_FORMAT(ptNUM_FORMAT) {
	m_pfData = pfDATA;
	m_fLower = fLOWER;
	m_fUpper = fUPPER;
}
//****************************************************************************
// ~CFloatData(void)
///
/// Destructor
///
//****************************************************************************
CFloatData::~CFloatData(void) {
}
//****************************************************************************
// void UpdateData( )
///
/// Method that updates a an item's associated data
///
/// @todo Reformat the passed in string to get rid of any unwanted characters after the decimal point
//****************************************************************************
void CFloatData::UpdateData(const QString pwcDATA) {
	// convert the string to a number	
	QString pwcStopChar = NULL;
	float fNewValue = static_cast<float>(wcstod(pwcDATA, &pwcStopChar));
	// convert the value if this is temperature and the display units are not degrees C
	if (((m_eDATA_TYPE == dtTemperature) || (m_eDATA_TYPE == dtTempRelative)) && (m_eDISP_TEMP_UNIT != TEMP_DEG_C)) {
		T_TEMP_COVERT_TYPE tempType = CONVERT_ABSOLUTE;
		if (m_eDATA_TYPE == dtTempRelative) {
			tempType = CONVERT_RELATIVE;
		}
		fNewValue = TempToDegC(m_eDISP_TEMP_UNIT, fNewValue, tempType);
	}
	// now setup a pointer to this item
	memcpy(m_pfData, &fNewValue, sizeof(float));
}
//****************************************************************************
// bool ValidateData( const WCHAR* const pwcDATA )
///
/// Method called to validate data entered by a user
///
/// @param[in]			const WCHAR* const pwcDATA - Pointer to the data entered
///						by the user
///
/// @returns	True if the data is valid
//****************************************************************************
bool CFloatData::ValidateData(const QString pwcDATA) {
	bool bValid = false;
	// check the string is valid
	if (pwcDATA != NULL) {
		// convert the string to a number	
		QString pwcStopChar = NULL;
		float fNewValue = static_cast<float>(wcstod(pwcDATA, &pwcStopChar));
		// check the conversion didnot stop prematurely e.g. on an invalid character
		if ((*pwcStopChar == '\0') && (fNewValue >= m_fLower) && (fNewValue <= m_fUpper)) {
			bValid = true;
		} else {
			QString strTitle("");
			QString strMsg("");
			strTitle = QString::asprintf("User Error");
			if (*pwcStopChar == '\0') {
				if (m_ptNUM_FORMAT == NULL) {
					// use a default number format
					T_NUMFORMAT tNumasprintf;
					tNumasprintf.Auto = TRUE;
					tNumasprintf.Base = FALSE;
					tNumasprintf.Zpad = FALSE;
					tNumasprintf.Scientific = FALSE;
					strMsg = QString::asprintf("The value entered must be between %s and %s.",
							CStringUtils::asprintfFloat(tNumasprintf, m_fLower),
							CStringUtils::asprintfFloat(tNumasprintf, m_fUpper));
				} else {
					strMsg = QString::asprintf("The value entered must be between %s and %s.",
							CStringUtils::asprintfFloat(*m_ptNUM_FORMAT, m_fLower),
							CStringUtils::asprintfFloat(*m_ptNUM_FORMAT, m_fUpper));
				}
			} else {
				strMsg = QWidget::tr(
						"Invalid number format. Exponential numbers must be entered in the format 1.23E-12.");
			}
			CV6MessageBoxDlg kErrDialog(strTitle, strMsg);
		}
	}
	return bValid;
}
//****************************************************************************
// const QString   GetDataAsString( const bool bINCLUDE_UNITS /* = false */ )
///
/// Method called to get the data as a string, converted to display units if necessary
///
/// @param[in]		const bool bINCLUDE_UNITS - Flag indicating the untis must be appended to
///					the end of the string
///
/// @returns	The data as a string
//****************************************************************************
const QString CFloatData::GetDataAsString(const bool bINCLUDE_UNITS /* = false */) {
	QString strFloatData("");
	if ((m_eDATA_TYPE == dtFloat) || (m_eDISP_TEMP_UNIT == TEMP_DEG_C)) {
		if (m_ptNUM_FORMAT == NULL) {
			// use a default number format
			T_NUMFORMAT tNumasprintf;
			tNumasprintf.Auto = TRUE;
			tNumasprintf.Base = FALSE;
			tNumasprintf.Zpad = FALSE;
			tNumasprintf.Scientific = FALSE;
			// now format
			strFloatData = CStringUtils::asprintfFloat(tNumasprintf, *m_pfData);
		} else {
			// format using the available format structure
			strFloatData = CStringUtils::asprintfFloat(*m_ptNUM_FORMAT, *m_pfData);
		}
	} else {
		T_TEMP_COVERT_TYPE tempType = CONVERT_ABSOLUTE;
		if (m_eDATA_TYPE == dtTempRelative) {
			tempType = CONVERT_RELATIVE;
		}
		// must be Deg F or Kelvin temeprature therefore return the converted temperature
		float fConvTemp = TempFromDegC(m_eDISP_TEMP_UNIT, *m_pfData, tempType);
		// use a default number format
		T_NUMFORMAT tNumasprintf;
		tNumasprintf.Auto = TRUE;
		tNumasprintf.Base = FALSE;
		tNumasprintf.Zpad = FALSE;
		tNumasprintf.Scientific = FALSE;
		// now format
		strFloatData = CStringUtils::asprintfFloat(tNumasprintf, fConvTemp);
	}
	// add the units if necessary
	if (bINCLUDE_UNITS && (m_strUNITS != "")) {
		strFloatData += " " + m_strUNITS;
	}
	return strFloatData;
}
//****************************************************************************
// CLongData(	long *plData,
//				const long lLOWER,
//				const long lUPPER,
//				const int iHELP_ID,
//				const int iDESC_ID,
//				const bool bUPDATE_TREE_ON_CHANGE )
///
/// Constructor
///
///	@param[in]			long* plData - Pointer to the actual data
///	@param[in]			const long lLOWER - the lower limit of this data
///	@param[in]			const long lUPPER - the upper limit of this data
/// @param[in]			const int iHELP_ID - The resource ID of the assocaited help for
///						this item
/// @param[in]			const int iDESC_ID - The resource ID of the assocaited description for
///						this item
/// @param[in]			const bool bUPDATE_TREE_ON_CHANGE - Flag indicating if this item requires
///						the config tree to be rebuilt when it changes
///
//****************************************************************************
CLongData::CLongData(long *plData, const long lLOWER, const long lUPPER, const int iHELP_ID, const int iDESC_ID,
		const bool bUPDATE_TREE_ON_CHANGE) : CConfigData(dtLong, iHELP_ID, iDESC_ID, bUPDATE_TREE_ON_CHANGE) {
	m_plData = plData;
	m_lLower = lLOWER;
	m_lUpper = lUPPER;
}
//****************************************************************************
// ~CLongConfigData(void)
///
/// Destructor
///
//****************************************************************************
CLongData::~CLongData(void) {
}
//****************************************************************************
// void UpdateData( )
///
/// Method that updates a an item's associated data
///
//****************************************************************************
void CLongData::UpdateData(const QString pwcDATA) {
	// convert the string to a number	
	QString pwcStopChar = NULL;
	long lNewValue = wcstol(pwcDATA, &pwcStopChar, 10);
	// now setup a pointer to this item
	memcpy(m_plData, &lNewValue, sizeof(long));
}
//****************************************************************************
// bool ValidateData( const WCHAR* const pwcDATA )
///
/// Method called to validate data entered by a user
///
/// @param[in]			const WCHAR* const pwcDATA - Pointer to the data entered
///						by the user
///
/// @returns	True if the data is valid
//****************************************************************************
bool CLongData::ValidateData(const QString pwcDATA) {
	QString title("");
	QString Msg("");
	QString OKButt("");		// Use the default OK button
	bool bValid = false;
	// check the string is valid
	if (pwcDATA != NULL) {
		// convert the string to a number	
		QString pwcStopChar = NULL;
		long lNewValue = wcstol(pwcDATA, &pwcStopChar, 10);
		// check the conversion didnot stop prematurely e.g. on an invalid character
		if ((*pwcStopChar == '\0') && (lNewValue >= m_lLower) && (lNewValue <= m_lUpper)) {
			bValid = true;
		} else {
			title = QString::asprintf("User Error");
			Msg = QString::asprintf("The value entered must be between %d and %d.", m_lLower, m_lUpper);
			CV6MessageBoxDlg kErrDialog(title, Msg, NULL, OKButt);
		}
	}
	return bValid;
}
//****************************************************************************
// const QString   GetDataAsString( const bool bINCLUDE_UNITS /* = false */ )
///
/// Method called to get the data as a string, converted to display units if necessary
///
/// @returns	The data as a string
//****************************************************************************
const QString CLongData::GetDataAsString(const bool bINCLUDE_UNITS /* = false */) {
	QString strLongData("");
	strLongData = QString::asprintf("%d", *m_plData);
	return strLongData;
}
//****************************************************************************
// CULongData( ULONG *pulDATA,
//				const ULONG ulLOWER,
//				const ULONG ulUPPER,
//				const int iHELP_ID,
//				const int iDESC_ID,
//				const bool bUPDATE_TREE_ON_CHANGE,
//				const T_CFG_DATA_TYPE eDATA_TYPE,
//				const QString   strUNITS /* = QString   ::fromWCharArray("") */,
//				const bool bREQUIRES_RESTART /* = false */)
///
/// Constructor
///
///	@param[in]			TV_BOOL* pbDATA - Pointer to the actual data
/// @param[in]			const ULONG ulLOWER - the lower limit of this data
/// @param[in]			const ULONG ulUPPER - the upper limit of this data
/// @param[in]			const int iHELP_ID - The resource ID of the assocaited help for
///						this item
/// @param[in]			const int iDESC_ID - The resource ID of the assocaited description for
///						this item
/// @param[in]			const bool bUPDATE_TREE_ON_CHANGE - Flag indicating if this item requires
///						the config tree to be rebuilt when it changes
/// @param[in]			const T_CFG_DATA_TYPE eDATA_TYPE - The data type - colour or ULONG
/// @param[in]			const QString   strUNITS - The units that need to be displayed after the string
/// @param[in]			const bool bREQUIRES_RESTART - Flag indicating if a restart is required after modifying this
///						variable
///
//****************************************************************************
CULongData::CULongData(ULONG *pulDATA, const ULONG ulLOWER, const ULONG ulUPPER, const int iHELP_ID, const int iDESC_ID,
		const bool bUPDATE_TREE_ON_CHANGE, const T_CFG_DATA_TYPE eDATA_TYPE /* = dtUnsignedLong */,
		const QString strUNITS /* = QString   ::fromWCharArray("") */, const bool bREQUIRES_RESTART /* = false */) : CConfigData(
		eDATA_TYPE, iHELP_ID, iDESC_ID, bUPDATE_TREE_ON_CHANGE, bREQUIRES_RESTART, strUNITS) {
	m_pulData = pulDATA;
	m_ulLower = ulLOWER;
	m_ulUpper = ulUPPER;
}
//****************************************************************************
// ~CULongData(void)
///
/// Destructor
///
//****************************************************************************
CULongData::~CULongData(void) {
}
//****************************************************************************
// void UpdateData( )
///
/// Method that updates a an item's associated data
///
//****************************************************************************
void CULongData::UpdateData(const QString pwcDATA) {
	// convert the string to a number	
	QString pwcStopChar = NULL;
	unsigned long ulNewValue = 0;
	switch (m_eDATA_TYPE) {
	case dtIPAddr:
		ulNewValue = CStringUtils::IPv4StrToPackedIPv4(pwcDATA);
		break;
	case dtColour:
		ulNewValue = wcstoul(pwcDATA, &pwcStopChar, 16);
		ulNewValue = RGBtoRGB888(ulNewValue);
		break;
	case dtDateTime:
	case dtDate:
	case dtTimeOfDay:
	case dtInterval:
	default:
		ulNewValue = wcstoul(pwcDATA, &pwcStopChar, 10);
		break;
	}
	// now setup a pointer to this item
	memcpy(m_pulData, &ulNewValue, sizeof(unsigned long));
}
//****************************************************************************
// bool ValidateData( const WCHAR* const pwcDATA )
///
/// Method called to validate data entered by a user
///
/// @param[in]			const WCHAR* const pwcDATA - Pointer to the data entered
///						by the user
///
/// @returns	True if the data is valid
//****************************************************************************
bool CULongData::ValidateData(const QString pwcDATA) {
	bool bValid = false;
	// check the string is valid
	if (pwcDATA != NULL) {
		// check if this is an IP address
		if (m_eDATA_TYPE != dtIPAddr) {
			// convert the string to a number	
			QString pwcStopChar = NULL;
			// set the base
			int iBase = 10;
			if (m_eDATA_TYPE == dtColour) {
				// set to hexadecimal
				iBase = 16;
			}
			unsigned long ulNewValue = wcstoul(pwcDATA, &pwcStopChar, iBase);
			// check the conversion did not stop prematurely e.g. on an invalid character
			if ((*pwcStopChar == '\0') && (ulNewValue >= m_ulLower) && (ulNewValue <= m_ulUpper)
					&& (pwcDATA[0] != '-')) {
				// check if this is a firmware pen item in which case we must carry out some additional validation
				if (m_eDATA_TYPE == dtFWPens) {
					// extra pens therefore we must validate the additional pens
					USHORT usCreditsInUse = 0;
					if ( pSYSTEM_INFO->ValidateFWOptions(CSysInfo::fwoExtraPens, usCreditsInUse, ulNewValue)) {
						bValid = true;
					} else {
						QString strTitle("");
						QString strMsg("");
						strTitle = QString::asprintf("User Error");
						strMsg =
								QString::asprintf(
										"There are insufficient credits available to enable more pens. Every %u additional pens shall require a credit.",
										CSysInfo::ms_usNO_PENS_PER_CREDIT);
						CV6MessageBoxDlg kErrDialog(strTitle, strMsg, NULL);
					}
				} else {
					// normal ULONG therefore it is valid
					bValid = true;
				}
			} else {
				// normal ULONG that is invalid
				QString strTitle("");
				QString strMsg("");
				strTitle = QString::asprintf("User Error");
				strMsg = QString::asprintf("The value entered must be between %u and %u.", m_ulLower, m_ulUpper);
				CV6MessageBoxDlg kErrDialog(strTitle, strMsg, NULL);
			}
		} else {
			// this is an IP address therefore we need to strip out the address
			bValid = (INADDR_NONE != CStringUtils::IPv4StrToPackedIPv4(pwcDATA));
			// put up an error message if the IP address is invalid
			if (!bValid) {
				QString strTitle("");
				QString strMsg("");
				strTitle = QString::asprintf("User Error");
				strMsg = QString::asprintf(
						"IP Addresses must be in the format X.X.X.X where X is a number between 0 and 255.");
				CV6MessageBoxDlg kErrDialog(strTitle, strMsg, NULL);
			}
		}
	}
	return bValid;
}
//****************************************************************************
// const QString   GetDataAsString( const bool bINCLUDE_UNITS /* = false */ )
///
/// Method called to get the data as a string, converted to display units if necessary
///
/// @param[in]		const bool bINCLUDE_UNITS - Flag indicating the untis must be appended to
///					the end of the string
///
/// @returns	The data as a string
//****************************************************************************
const QString CULongData::GetDataAsString(const bool bINCLUDE_UNITS /* = false */) {
	QString strULongData("");
	switch (m_eDATA_TYPE) {
	case dtIPAddr:
		// must be an IP address
		strULongData = CStringUtils::PackedIPv4ULongToStr(*m_pulData);
		break;
	case dtColour: {
		ULONG ulCol = *m_pulData;
		strULongData = QString::asprintf("%c%u%c%c", g_wcMOD_COLOUR, ulCol, g_wcMOD_COLOUR, g_wcSMALLSQUARE);
	}
		break;
	case dtDateTime: {
		// convert the ulong into a valid date/time string
		quint64 ullDateTime = *m_pulData;
		ullDateTime *= 1000000;
		QTime kTime(ullDateTime);
		kTime.ShortTimeAsString(strULongData);
		// now add the date
		QString strDate("");
		kTime.DateAsString(strDate);
		strULongData += " " + strDate;
	}
		break;
	case dtTimeOfDay: {
		// convert the ulong into a valid date/time string but only return the time portion
		QTime kTime(static_cast<_int64>(*m_pulData) * 1000000);
		kTime.ShortTimeAsString(strULongData);
	}
		break;
	case dtDate: {
		// convert the ulong into a valid date string
		quint64 ullDateTime = *m_pulData;
		ullDateTime *= 1000000;
		CTVtime kTime(ullDateTime);
		// now retrieve the date
		kTime.DateAsString(strULongData);
	}
		break;
	case dtInterval: {
		// check it is greater than 1 second
		if (*m_pulData == 0) {
			// default to 1 second
			*m_pulData = 1;
		}
		// convert the value into hour mins seconds etc
		strULongData = CStringUtils::GetAutoDDHHMMSSspanFromSeconds(*m_pulData);
	}
		break;
	default:
		strULongData = QString::asprintf("%u", *m_pulData);
		// not a colour or IP address so add the units if necessary
		if (bINCLUDE_UNITS && (m_strUNITS != "")) {
			strULongData += " " + m_strUNITS;
		}
		break;
	}
	return strULongData;
}
//****************************************************************************
// const USHORT GetDataLength()
///
/// Method that returns the maximum allowable length of the data as a string
///
/// @return		The max length of the data as a string
///
//****************************************************************************
const USHORT CULongData::GetDataLength() const {
	USHORT usMaxStrLen = 0;
	if (m_eDATA_TYPE == dtIPAddr) {
		usMaxStrLen = 15;
	} else if (m_eDATA_TYPE == dtColour) {
		usMaxStrLen = 6;
	} else {
		usMaxStrLen = g_usMAX_LONG_STR_LEN;
	}
	return usMaxStrLen;
}
//****************************************************************************
// CShortData( short *psDATA,
//				const short sLOWER,
//				const short sUPPER,
//				const int iHELP_ID,
//				const int iDESC_ID,
//				const bool bUPDATE_TREE_ON_CHANGE,
//				const QString   strUNITS /* = QString   ::fromWCharArray("") */ )
///
/// Constructor
///
///	@param[in]			short* psDATA - Pointer to the actual data
///	@param[in]			const short sLOWER - The lower limit of this data
///	@param[in]			const short sUPPER - The upper limit of this data
/// @param[in]			const int iHELP_ID - The resource ID of the assocaited help for
///						this item
/// @param[in]			const int iDESC_ID - The resource ID of the assocaited description for
///						this item
/// @param[in]			const bool bUPDATE_TREE_ON_CHANGE - Flag indicating if this item requires
///						the config tree to be rebuilt when it changes
/// @param[in]			const QString   strUNITS - The units that need to be displayed after the string
///
//****************************************************************************
CShortData::CShortData(short *psDATA, const short sLOWER, const short sUPPER, const int iHELP_ID, const int iDESC_ID,
		const bool bUPDATE_TREE_ON_CHANGE, const QString strUNITS /* = QString   ::fromWCharArray("") */) : CConfigData(
		dtShort, iHELP_ID, iDESC_ID, bUPDATE_TREE_ON_CHANGE, false, strUNITS) {
	m_psData = psDATA;
	m_sLower = sLOWER;
	m_sUpper = sUPPER;
}
//****************************************************************************
// ~CShortData(void)
///
/// Destructor
///
//****************************************************************************
CShortData::~CShortData(void) {
}
//****************************************************************************
// void UpdateData( )
///
/// Method that updates a an item's associated data
///
//****************************************************************************
void CShortData::UpdateData(const QString pwcDATA) {
	// convert the string to a number	
	QString pwcStopChar = NULL;
	short sNewValue = static_cast<short>(wcstol(pwcDATA, &pwcStopChar, 10));
	// now setup a pointer to this item
	memcpy(m_psData, &sNewValue, sizeof(short));
}
//****************************************************************************
// bool ValidateData( const WCHAR* const pwcDATA )
///
/// Method called to validate data entered by a user
///
/// @param[in]			const WCHAR* const pwcDATA - Pointer to the data entered
///						by the user
///
/// @returns	True if the data is valid
//****************************************************************************
bool CShortData::ValidateData(const QString pwcDATA) {
	bool bValid = false;
	// check the string is valid
	if (pwcDATA != NULL) {
		// convert the string to a number	
		QString pwcStopChar = NULL;
		long lNewValue = wcstol(pwcDATA, &pwcStopChar, 10);
		// check the value is within a valid short range
		if ((lNewValue >= SHRT_MIN) && (lNewValue <= SHRT_MAX)) {
			// okay to cast to a short
			short sNewValue = static_cast<short>(lNewValue);
			// check the conversion did not stop prematurely e.g. on an invalid character
			if ((*pwcStopChar == '\0') && (sNewValue >= m_sLower) && (sNewValue <= m_sUpper)) {
				bValid = true;
			} else {
				QString strTitle("");
				QString strMsg("");
				strTitle = QString::asprintf("User Error");
				strMsg = QString::asprintf("The value entered must be between %d and %d.", m_sLower, m_sUpper);
				CV6MessageBoxDlg kErrDialog(strTitle, strMsg, NULL);
			}
		} else {
			QString strTitle("");
			QString strMsg("");
			strTitle = QString::asprintf("User Error");
			strMsg = QString::asprintf("The value entered must be between %d and %d.", m_sLower, m_sUpper);
			CV6MessageBoxDlg kErrDialog(strTitle, strMsg, NULL);
		}
	}
	return bValid;
}
//****************************************************************************
// const QString   GetDataAsString( const bool bINCLUDE_UNITS /* = false */ )
///
/// Method called to get the data as a string
///
/// @param[in]		const bool bINCLUDE_UNITS - Flag indicating the untis must be appended to
///					the end of the string
///
/// @returns	The data as a string
//****************************************************************************
const QString CShortData::GetDataAsString(const bool bINCLUDE_UNITS /* = false */) {
	QString strShortData("");
	strShortData = QString::asprintf("%d", *m_psData);
	// add the units if necessary
	if (bINCLUDE_UNITS && (m_strUNITS != "")) {
		strShortData += " " + m_strUNITS;
	}
	return strShortData;
}
//****************************************************************************
// CUShortData(	USHORT *pusDATA,
//					const USHORT usLOWER,
//					const USHORT usUPPER,
//					const int iHELP_ID,
//					const int iDESC_ID,
//					const bool bUPDATE_TREE_ON_CHANGE,
//					const QString   strUNITS /* = QString   ::fromWCharArray("") */,
//					const bool bREQUIRES_RESTART /* = false */ )
///
/// Constructor
///
///	@param[in]			TV_BOOL* pbDATA - Pointer to the actual data
///	@param[in]			const USHORT usLOWER - The lower limit of this data
///	@param[in]			const USHORT usUPPER - The upper limit of this data
/// @param[in]			const int iHELP_ID - The resource ID of the assocaited help for
///						this item
/// @param[in]			const int iDESC_ID - The resource ID of the associated description for
///						this item
/// @param[in]			const bool bUPDATE_TREE_ON_CHANGE - Flag indicating if this item requires
///						the config tree to be rebuilt when it changes
/// @param[in]			const QString   strUNITS - The units that need to be displayed after the string
/// @param[in]			const bool bREQUIRES_RESTART - Flag indicating if a restart is required after modifying this
///						variable
///
//****************************************************************************
CUShortData::CUShortData(USHORT *pusDATA, const USHORT usLOWER, const USHORT usUPPER, const int iHELP_ID,
		const int iDESC_ID, const bool bUPDATE_TREE_ON_CHANGE, const T_CFG_DATA_TYPE eDATA_TYPE /* = dtUnsignedShort */,
		const QString strUNITS /* = QString   ::fromWCharArray("") */, const bool bREQUIRES_RESTART /* = false */) : CConfigData(
		eDATA_TYPE, iHELP_ID, iDESC_ID, bUPDATE_TREE_ON_CHANGE, bREQUIRES_RESTART, strUNITS) {
	m_pusData = pusDATA;
	/// the upper and lower limits required to validate a USHORT
	m_usLower = usLOWER;
	m_usUpper = usUPPER;
}
//****************************************************************************
// ~CUShortData(void)
///
/// Destructor
///
//****************************************************************************
CUShortData::~CUShortData(void) {
}
//****************************************************************************
// void UpdateData( )
///
/// Method that updates an item's associated data
///
//****************************************************************************
void CUShortData::UpdateData(const QString pwcDATA) {
	// convert the string to a number	
	QString pwcStopChar = NULL;
	USHORT usNewValue = 0;
	if ((m_eDATA_TYPE == dtUnsignedShort) || (m_eDATA_TYPE == dtBrightness)) {
		usNewValue = static_cast<USHORT>(wcstoul(pwcDATA, &pwcStopChar, 10));
	} else {
		// color is displayed as 32 bit and converted to 16 bit
		ULONG ulCol = 0;
		ulCol = wcstoul(pwcDATA, &pwcStopChar, 16);
		ulCol = RGBtoRGB888(ulCol);
		usNewValue = RGBtoRGB565(ulCol);
	}
	// now setup a pointer to this item
	memcpy(m_pusData, &usNewValue, sizeof(USHORT));
}
//****************************************************************************
// const bool ShowSlider( const QString   &rstrTITLE, CWidget *pkWnd )
///
/// Method that shows the brightness slider and allows the user to adjust it
///
//****************************************************************************
const bool CUShortData::ShowSlider(const QString &rstrTITLE, CWidget *pkWnd) {
	bool bUpdate = false;
#ifndef TTR6SETUP
	CCfgBrightnessDlg kBrightnessEditor(rstrTITLE, *m_pusData, m_usLower, m_usUpper, pkWnd);
	if (kBrightnessEditor.exec() == IDOK) {
		// get the brightness set by the user
		*m_pusData = kBrightnessEditor.GetScreenBrightess();
		bUpdate = true;
	}
	// restore the stored modifiable brightness
	T_PRECPROFILE ptModifiableProfile = pSETUP->GetGeneralSetupConfig()->GetProfileBlock(CONFIG_MODIFIABLE);
	pDALGLB->SetScreenBrightness(ptModifiableProfile->ScreenSaver.NormalBright);
#endif
	return bUpdate;
}
//****************************************************************************
// bool ValidateData( const WCHAR* const pwcDATA )
///
/// Method called to validate data entered by a user
///
/// @param[in]			const WCHAR* const pwcDATA - Pointer to the data entered
///						by the user
///
/// @returns	True if the data is valid
//****************************************************************************
bool CUShortData::ValidateData(const QString pwcDATA) {
	bool bValid = false;
	// check the string is valid
	if (pwcDATA != NULL) {
		// convert the string to a number	
		QString pwcStopChar = NULL;
		if (m_eDATA_TYPE != dt16Colour) {
			ULONG ulNewValue = wcstoul(pwcDATA, &pwcStopChar, 10);
			// check the value is within a valid short range
			if ((ulNewValue >= 0) && (ulNewValue <= USHRT_MAX)) {
				// okay to cast to a short
				USHORT usNewValue = static_cast<USHORT>(ulNewValue);
				// check the conversion did not stop prematurely e.g. on an invalid character
				if ((*pwcStopChar == '\0') && (usNewValue >= m_usLower) && (usNewValue <= m_usUpper)
						&& (pwcDATA[0] != '-')) {
					bValid = true;
				} else {
					QString strTitle("");
					QString strMsg("");
					strTitle = QString::asprintf("User Error");
					strMsg = QString::asprintf("The value entered must be between %u and %u.", m_usLower, m_usUpper);
					CV6MessageBoxDlg kErrDialog(strTitle, strMsg, NULL);
				}
			} else {
				QString strTitle("");
				QString strMsg("");
				strTitle = QString::asprintf("User Error");
				strMsg = QString::asprintf("The value entered must be between %u and %u.", m_usLower, m_usUpper);
				CV6MessageBoxDlg kErrDialog(strTitle, strMsg, NULL);
			}
		} else {
			// must be a 16 bit colour - set to hexadecimal
			ULONG ulNewValue = wcstoul(pwcDATA, &pwcStopChar, 16);
			// check the value is within a valid MAX COLOUR range - should always be because we use
			// the colour picker now
			if ((ulNewValue >= 0) && (ulNewValue <= 0x00FFFFFF)) {
				bValid = true;
			}
		}
	}
	return bValid;
}
//****************************************************************************
// const QString   GetDataAsString( const bool bINCLUDE_UNITS /* = false */ )
///
/// Method called to get the data as a string, converted to display units if necessary
///
/// @param[in]		const bool bINCLUDE_UNITS - Flag indicating the untis must be appended to
///					the end of the string
///
/// @returns	The data as a string
//****************************************************************************
const QString CUShortData::GetDataAsString(const bool bINCLUDE_UNITS /* = false */) {
	QString strUShortData("");
	if ((m_eDATA_TYPE == dtUnsignedShort) || (m_eDATA_TYPE == dtBrightness)) {
		strUShortData = QString::asprintf("%u", *m_pusData);
		// not a colour so add the units if necessary
		if (bINCLUDE_UNITS && (m_strUNITS != "")) {
			strUShortData += " " + m_strUNITS;
		}
	} else {
		ULONG ulCol = *m_pusData;
		ulCol = RGB565toRGB(ulCol);
		strUShortData = QString::asprintf("%c%u%c%c", g_wcMOD_COLOUR, ulCol, g_wcMOD_COLOUR, g_wcSMALLSQUARE);
	}
	return strUShortData;
}
//****************************************************************************
// CBitFieldData(	const T_CFG_DATA_TYPE eDATA_TYPE,
//					const USHORT usNUM_OF_BITS,
//					const USHORT usSTART_BIT,
//					const QString   &rstrLIST_BOX_ITEMS,
//					const BitFieldEditor eEDITOR_TYPE,
//					const int iHELP_ID,
//					const int iDESC_ID,
//					const bool bUPDATE_TREE_ON_CHANGE,
//					const bool bREQUIRES_RESTART /* = false */ )
///
/// Constructor
///
/// @param[in]			const T_CFG_DATA_TYPE - The bitfield data type - short or long
/// @param[in]			const USHORT usNUM_OF_BITS - The number of bits in the bitfield
/// @param[in]			const USHORT usSTART_BIT - The start bit of the bitfield within the USHORT
///	@param[in]			const QString   &rstrLIST_BOX_ITEMS - The assciated pick list (if any) for this bitfield
/// @param[in]			const int iHELP_ID - The resource ID of the assocaited help for
///						this item
/// @param[in]			const int iDESC_ID - The resource ID of the associated description for
///						this item
/// @param[in]			const bool bUPDATE_TREE_ON_CHANGE - Flag indicating if this item requires
///						the config tree to be rebuilt when it changes
/// @param[in]			const bool bREQUIRES_RESTART - Flag indicating if a restart is required after modifying this
///						variable
/// @param[in]			const QString   &rstrUNITS - The units that need to be displayed after the string
///
//****************************************************************************
CBitFieldData::CBitFieldData(const T_CFG_DATA_TYPE eDATA_TYPE, const USHORT usNUM_OF_BITS, const USHORT usSTART_BIT,
		const QString pwcLIST_BOX_ITEMS, const BitFieldEditor eEDITOR_TYPE, const int iHELP_ID,
		const int iDESC_ID, const bool bUPDATE_TREE_ON_CHANGE, const bool bREQUIRES_RESTART /* = false */,
		const QString &rstrUNITS /* = QString   ::fromWCharArray("") */) : CConfigData(eDATA_TYPE, iHELP_ID, iDESC_ID,
		bUPDATE_TREE_ON_CHANGE, bREQUIRES_RESTART, rstrUNITS), m_pwcLIST_BOX_ITEMS(pwcLIST_BOX_ITEMS), m_eEDITOR_TYPE(
		eEDITOR_TYPE) {
	m_usNumOfBits = usNUM_OF_BITS; // 1 - 16(Short) or 32(long)
	m_usStartBit = usSTART_BIT;	// 0 based index, 0 - 15(short) or 31(long)
}
//****************************************************************************
// ~CBitFieldData(void)
///
/// Destructor
///
//****************************************************************************
CBitFieldData::~CBitFieldData(void) {
}
//****************************************************************************
// USHORT GetPosOfItem( const WCHAR* const pwcDATA ) const
///
/// Method that cross-references the text with the drop down list text and gets the position number
/// accordingly
///
/// @param[in]		const T_CFG_DATA_TYPE - The bitfield data type - short or long
///
/// @return			The position of the current item within the list string
///
//****************************************************************************
USHORT CBitFieldData::GetPosOfItem(const QString pwcDATA) const {
	USHORT usBitData = 0;
	QString strTestText("");
	QString strSelText(pwcDATA);
	bool bContinue = true;
	do {
		strTestText = CStringUtils::GetItemAtPos(this->m_pwcLIST_BOX_ITEMS, static_cast<USHORT>(usBitData));
		if (((m_eDATA_TYPE != dtFWOptBitField) && strTestText.compare(strSelText) == 0)
				|| ((m_eDATA_TYPE == dtFWOptBitField) && (strTestText.indexOf(pwcDATA, 0) != -1))) {
			bContinue = false;
		} else {
			++usBitData;
		}
	} while (bContinue == true);
	return usBitData;
}
//****************************************************************************
// void RemoveEmbeddedControlInfo( QString   &rstrItem )
///
/// Method that removes any embedded control characters from the passed in string
///
/// @param[in/out]		const QString   &rstrItem - The string we wish to remove the embedded 
///						control characters from
///
//****************************************************************************
void CBitFieldData::RemoveEmbeddedControlInfo(QString &rstrItem) const {
	int iStartPos = 0;
	// check for an embedded control characters
	while ((iStartPos = rstrItem.indexOf(g_wcEMBEDDED_INFO_DELIM, 0)) != -1) {
		int iEndPos = rstrItem.indexOf(g_wcEMBEDDED_INFO_DELIM, iStartPos + 1);
		// check an end character was found
		if (iEndPos != -1) {
			// start and end found - strip the information out of the string
			rstrItem.remove(iStartPos, (iEndPos - iStartPos) + 1);
		} else {
			// should never happen unless there has been a coding error or the user has somehow
			// embedded a control character into the string names
			DebugBreak();
			break;
		}
	}
}
//****************************************************************************
// const USHORT ConvertIndexToActualVal( const USHORT usINDEX )
///
/// Method that converts the index of an item into it's actual associated value e.g. screens have
/// a number, and when setting things like the alarm screen you need to set this value, not the index
///
/// @param[in]		const USHORT usINDEX - The index of the selected item (within m_pwcLIST_BOX_ITEMS)
///
/// @return			The actual value associated to the index'ed item (usually this will be the same)
///
//****************************************************************************
const USHORT CBitFieldData::ConvertIndexToActualVal(const USHORT usINDEX) {
	USHORT usActualValue = 0;
	QString strSelectedItem(CStringUtils::GetItemAtPos(m_pwcLIST_BOX_ITEMS, usINDEX));
	QString strDelimiter;
	strDelimiter = g_wcEMBEDDED_INFO_DELIM;
	QString strNumber(CStringUtils::GetItemAtPos(strSelectedItem, 1, strDelimiter));
	// check a value was obtained 
	if (strNumber != "") {
		// convert into a number
		QString pwcStopChar = NULL;
		usActualValue = static_cast<USHORT>(wcstoul(strNumber, &pwcStopChar, 10));
	} else {
		usActualValue = usINDEX;
	}
	return usActualValue;
}
//****************************************************************************
// CShortBitFieldData(	USHORT *pusDATA,
//						const USHORT usNUM_OF_BITS,
//						const USHORT usSTART_BIT,
//						const QString   &rstrLIST_BOX_ITEMS,
//						const BitFieldEditor eEDITOR_TYPE,
//						const int iHELP_ID,
//						const int iDESC_ID,
//						const bool bUPDATE_TREE_ON_CHANGE,
//						const bool bREQUIRES_RESTART )
///
/// Constructor
///
///	@param[in]			USHORT* pusDATA - Pointer to the actual data
/// @param[in]			const USHORT usNUM_OF_BITS - The number of bits in the bitfield
/// @param[in]			const USHORT usSTART_BIT - The start bit of the bitfield within the USHORT
///	@param[in]			const WCHAR* const pwcLIST_BOX_ITEMS - The associated pick list (if any) for 
///						this bitfield - NOTE: THIS MUST QPoint TO A STATIC LIST, NOT A LOCAL ONE THAT 
///						CAN GO OUT OF SCOPE
/// @param[in]			const int iHELP_ID - The resource ID of the assocaited help for
///						this item
/// @param[in]			const int iDESC_ID - The resource ID of the associated description for
///						this item
/// @param[in]			const bool bUPDATE_TREE_ON_CHANGE - Flag indicating if this item requires
///						the config tree to be rebuilt when it changes
///	@param[in]			const USHORT usLOWER - The lower limit of this data
///	@param[in]			const USHORT usUPPER - The upper limit of this data
/// @param[in]			const bool bREQUIRES_RESTART - Flag indicating if a restart is required after modifying this
///						variable
///
//****************************************************************************
CShortBitFieldData::CShortBitFieldData(USHORT *pusDATA, const USHORT usNUM_OF_BITS, const USHORT usSTART_BIT,
		const QString pwcLIST_BOX_ITEMS, const BitFieldEditor eEDITOR_TYPE, const int iHELP_ID,
		const int iDESC_ID, const bool bUPDATE_TREE_ON_CHANGE, const USHORT usLOWER /* = 0 */,
		const USHORT usUPPER /* = USHRT_MAX */, const bool bREQUIRES_RESTART /* = false */,
		const QString &rstrUNITS /* = QString   ::fromWCharArray("") */) : CBitFieldData(dtShortBitField, usNUM_OF_BITS,
		usSTART_BIT, pwcLIST_BOX_ITEMS, eEDITOR_TYPE, iHELP_ID, iDESC_ID, bUPDATE_TREE_ON_CHANGE, bREQUIRES_RESTART,
		rstrUNITS), m_usLOWER(usLOWER), m_usUPPER(usUPPER) {
	m_pusData = pusDATA;
}
//****************************************************************************
// ~CShortBitFieldData(void)
///
/// Destructor
///
//****************************************************************************
CShortBitFieldData::~CShortBitFieldData(void) {
}
//****************************************************************************
// USHORT BitFieldToUShort( )
///
/// Method that converts a bitfield into a USHORT (usually for display purposes)
///
//****************************************************************************
USHORT CShortBitFieldData::BitFieldToUShort() const {
	USHORT usBitFieldAsShort = 0;
	// copy the bitfield data
	usBitFieldAsShort = *m_pusData;
	// shift the short right until the first bit is the start of our bitfield
	usBitFieldAsShort >>= m_usStartBit;
	// now mask all the higher bits - create the mask first
	double dMaskVal = pow(static_cast<double>(2), static_cast<int>(m_usNumOfBits));
	USHORT usBitFieldMask = static_cast<USHORT>(dMaskVal);
	usBitFieldMask -= 1;
	usBitFieldAsShort &= usBitFieldMask;
	return usBitFieldAsShort;
}
//****************************************************************************
// void UpdateData( const WCHAR* const pwcDATA )
///
/// Method that updates an item's associated data
///
/// @param[in]			const WCHAR* const pwcDATA - A pointer to the new data
///
//****************************************************************************
void CShortBitFieldData::UpdateData(const QString pwcDATA) {
	USHORT usBitData = 0;
	if (m_eEDITOR_TYPE == bfeNumerical) {
		QString pwcStopChar = NULL;
		usBitData = static_cast<USHORT>(wcstoul(pwcDATA, &pwcStopChar, 10));
	} else {
#ifdef DOCVIEW
		// We need to get the index value from the non-sequential list if there are
		// embedded characters
		QString   strList( QString   ::fromWCharArray("") );
		strList = m_pwcLIST_BOX_ITEMS;
		if( strList.indexOf( g_wcEMBEDDED_INFO_DELIM ) != -1 )
		{
			// a character was found therefore find the shortened string
			QString   strData( QString   ::fromWCharArray("") );
			strData = QString::asprintf( L"%s%c", pwcDATA, g_wcEMBEDDED_INFO_DELIM );
			int iStartPos = strList.indexOf( strData );
			if( iStartPos >=0 )
			{
				// check if the start pos found is zero which implies this is the first canned screen
				if( iStartPos == 0 )
				{
					// we have our index so don't continue
					usBitData = 0;
				}
				else
				{
					// not the first canned screen so add a start delimitter onto the
					// selected item so finding the item will be much more accurate i.e.
					// it will ignore strings that are very similar suck as MyTemplate1 
					// and Template1 which could give an incorrect hit
					strData.insert( 0, L"|");
					iStartPos = strList.indexOf( strData );
					// move to the end of the found string
					iStartPos += strData.size();
					// get the end delimitter
					int iEndPos = strList.indexOf( g_wcEMBEDDED_INFO_DELIM, iStartPos );
					
					// check they are both valid
					if( iEndPos > iStartPos )
					{	
						// extract the number between the two embedded characters
						strData = strList.mid( iStartPos, ( iEndPos - iStartPos ) );
						// turn into a number and that we have our index
						QString pwcStopChar = NULL;
						usBitData = static_cast< USHORT >( wcstoul( strData, &pwcStopChar, 10 ) );
					}
					else
					{
						// game over at this point - something badly wrong so do nothing
					}
				}
			}
			else
			{
				// game over at this point - something badly wrong so do nothing
			}
		}
		else
		{
			// no embedded characters so just do the update normally
			usBitData = GetPosOfItem( pwcDATA );
		}
#else
		usBitData = GetPosOfItem(pwcDATA);
#endif
	}
	// shift the data left by the number of bits it is offset by
	usBitData <<= m_usStartBit;
	// now we must mask the existing data and overwrite it with this new data
	USHORT usBitMask = static_cast<USHORT>(pow(static_cast<double>(2), static_cast<int>(m_usNumOfBits))) - 1;
	usBitMask <<= m_usStartBit;
	// invert it
	usBitMask = ~usBitMask;
	// mask the existing data
	*m_pusData &= usBitMask;
	// now OR with the new data
	*m_pusData |= usBitData;
}
//****************************************************************************
// void UpdateData( )
///
/// Method that updates an item's associated data
///
//****************************************************************************
void CShortBitFieldData::UpdateData(const USHORT usBIT_VALUE) {
	USHORT usBitData = ConvertIndexToActualVal(usBIT_VALUE);
	// shift the data left by the number of bits it is offset by
	usBitData <<= m_usStartBit;
	// now we must mask the existing data and overwrite it with this new data
	USHORT usBitMask = static_cast<USHORT>(pow(static_cast<double>(2), static_cast<int>(m_usNumOfBits))) - 1;
	usBitMask <<= m_usStartBit;
	// invert it
	usBitMask = ~usBitMask;
	// mask the existing data
	*m_pusData &= usBitMask;
	// now OR with the new data
	*m_pusData |= usBitData;
}
//****************************************************************************
// bool ValidateData( const WCHAR* const pwcDATA )
///
/// Method called to validate data entered by a user
///
/// @param[in]			const WCHAR* const pwcDATA - Pointer to the data entered
///						by the user
///
/// @returns	True if the data is valid
//****************************************************************************
bool CShortBitFieldData::ValidateData(const QString pwcDATA) {
	bool bValid = false;
	// only need to validate numerical entries for now
	if (m_eEDITOR_TYPE == bfeNumerical) {
		// firstly check the string is a valid USHORT
		if (pwcDATA != NULL) {
			// convert the string to a number	
			QString pwcStopChar = NULL;
			ULONG ulNewValue = wcstoul(pwcDATA, &pwcStopChar, 10);
			// get the maximum value based on the number of bits of the bit field
			ULONG ulMaxBitFieldValue = static_cast<ULONG>(pow(static_cast<double>(2), static_cast<int>(m_usNumOfBits)));
			// check the value is within a valid short range
			if ((ulNewValue >= 0) && (ulNewValue <= USHRT_MAX) && (ulNewValue >= m_usLOWER)
					&& (ulNewValue <= m_usUPPER)) {
				// okay to cast to a short
				USHORT usNewValue = static_cast<USHORT>(ulNewValue);
				// check the conversion did not stop prematurely e.g. on an invalid character
				// and the value does not exceed our limit
				if ((*pwcStopChar == '\0') && (usNewValue < ulMaxBitFieldValue)) {
					bValid = true;
				} else {
					QString strTitle("");
					QString strMsg("");
					strTitle = QString::asprintf("User Error");
					strMsg = QString::asprintf("The value entered must be between %u and %u.", m_usLOWER, m_usUPPER);
					CV6MessageBoxDlg kErrDialog(strTitle, strMsg, NULL);
				}
			} else {
				QString strTitle("");
				QString strMsg("");
				strTitle = QString::asprintf("User Error");
				strMsg = QString::asprintf("The value entered must be between %u and %u.", m_usLOWER, m_usUPPER);
				CV6MessageBoxDlg kErrDialog(strTitle, strMsg, NULL);
			}
		}
	} else {
		bValid = true;
	}
	return bValid;
}
//****************************************************************************
// void ToggleData( )
///
/// Method that toggles boolean data as a quick method of editing
///
//****************************************************************************
void CShortBitFieldData::ToggleData() {
	// check this is a boolean
	if (IsBoolean()) {
		USHORT usData = BitFieldToUShort();
		if (usData == 0) {
			usData = 1;
		} else {
			usData = 0;
		}
		UpdateData(usData);
	} else {
		// Error condition
		qDebug("CShortBitFieldData::ToggleData - Toggle being called on non-boolean data");
	}
}
//****************************************************************************
// const QString   GetDataAsString( const bool bINCLUDE_UNITS /* = false */ )
///
/// Method that returns the data as a string
///
/// @return			The data item represented by the bitfield value
///
//****************************************************************************
const QString CShortBitFieldData::GetDataAsString(const bool bINCLUDE_UNITS /* = false */) {
	QString strData("");
	// check this is a boolean
	if (IsBoolean()) {
		strData = CStringUtils::GetItemAtPos(m_pwcLIST_BOX_ITEMS, BitFieldToUShort());
	} else if (IsSingleSelList()) {
		// check if this is a non-sequential list by looking for embedded control characters
		QString strDelimiter;
		strDelimiter = g_wcEMBEDDED_INFO_DELIM;
		if (CStringUtils::InstanceOfStr(m_pwcLIST_BOX_ITEMS, strDelimiter) < 2) {
			// normal sequential list so just get the data
			strData = CStringUtils::GetItemAtPos(m_pwcLIST_BOX_ITEMS, BitFieldToUShort());
		} else {
			// non-sequential list so we need to test all the strings in the list to see if
			// they contain the value indicated within the CMM data
			USHORT usListCount = 0;
			QString strStringToindexOf("");
			strStringToindexOf = QString::asprintf("%c%u%c", g_wcEMBEDDED_INFO_DELIM, BitFieldToUShort(),
					g_wcEMBEDDED_INFO_DELIM);
			while ((strData = CStringUtils::GetItemAtPos(m_pwcLIST_BOX_ITEMS, usListCount)) != "") {
				// see if this string occurs in the list
				if (strData.indexOf(strStringToindexOf, 0) != -1) {
					// found our match - drop out of the loop
					break;
				}
				// move onto the next item
				++usListCount;
			}
			// check something was found
			if (strData == "") {
				// set to NA
				strData = QWidget::tr("NA");
				// also embed red characters around it to highlight the problem
				QString strasprintftedSQWidget::tr("");
				// add the embedded control characters around this item top make it red
				QString strFalseColour(L" ");
				ResColour *pkColour = pSYSTEM_INFO->pOemInfo->GetColour( V6RES_COLOUR_BTNFALSETEXT);
				COLORREF crFalse = pkColour->pColor;
				strFalseColour = QString::asprintf("%u", crFalse);
				strasprintftedStr = QString::asprintf("%c%s%c%s", g_wcMOD_COLOUR, strFalseColour, g_wcMOD_COLOUR,
						strData);
				strData = strasprintftedStr;
			}
		}
		// check the return string is valid
		if (strData == "") {
			// the return string is null - this would imply we have attempted to obtain
			// a value that is out of range. This would usually occur when a fields are reused e.g.
			// the user changes from TC's ( ~16 types ) to Amps ( 2 types )
			// In this isutation set the value back to 0 and get the string again - a value should
			// always be found in this situation
			const USHORT usNewValue = 0;
			UpdateData(usNewValue);
			// now get the data again - this should always return something
			strData = CStringUtils::GetItemAtPos(m_pwcLIST_BOX_ITEMS, BitFieldToUShort());
		}
	} else {
		// must be a numerical value
		strData = QString::asprintf("%u", BitFieldToUShort());
	}
	// add the units if necessary
	if (bINCLUDE_UNITS && (m_strUNITS != "")) {
		strData += " " + m_strUNITS;
	}
	// strip out any embedded control characters
	RemoveEmbeddedControlInfo(strData);
	return strData;
}
//****************************************************************************
// CLongBitFieldData(	ULONG *pulDATA,
//						const USHORT usNUM_OF_BITS,
//						const USHORT usSTART_BIT,
//						const WCHAR* const pwcLIST_BOX_ITEMS,
//						const int iHELP_ID,
//						const int iDESC_ID,
//						const bool bUPDATE_TREE_ON_CHANGE,
//						const T_CFG_DATA_TYPE eDATA_TYPE )
///
/// Constructor
///
///	@param[in]			ULONG* pulDATA - Pointer to the actual data
/// @param[in]			const USHORT usNUM_OF_BITS - The number of bits in the bitfield
/// @param[in]			const USHORT usSTART_BIT - The start bit of the bitfield within the USHORT
///	@param[in]			const WCHAR* const pwcLIST_BOX_ITEMS - The associated pick list (if any) for 
///						this bitfield - NOTE: THIS MUST QPoint TO A STATIC LIST, NOT A LOCAL ONE THAT 
///						CAN GO OUT OF SCOPE
/// @param[in]			const int iHELP_ID - The resource ID of the assocaited help for
///						this item
/// @param[in]			const int iDESC_ID - The resource ID of the associated description for
///						this item
/// @param[in]			const bool bUPDATE_TREE_ON_CHANGE - Flag indicating if this item requires
///						the config tree to be rebuilt when it changes
/// @param[in]			const T_CFG_DATA_TYPE eDATA_TYPE - Indicates the type of data the long bitfield
///						relates too
///	@param[in]			const bool bREQUIRES_RESTART - Flag indicating changing this variable requires a restart
/// @param[in]			const LONG lLOWER - Lower limit to test any numerical bitfields against
/// @param[in]			const LONG lUPPER - Upper limit to test any numerical bitfields against
/// @param[in]			const QString   &rstrUNITS - The units (if any) that we require to be appended
///
//****************************************************************************
CLongBitFieldData::CLongBitFieldData(ULONG *pulDATA, const USHORT usNUM_OF_BITS, const USHORT usSTART_BIT,
		const QString pwcLIST_BOX_ITEMS, const BitFieldEditor eEDITOR_TYPE, const int iHELP_ID,
		const int iDESC_ID, const bool bUPDATE_TREE_ON_CHANGE, const T_CFG_DATA_TYPE eDATA_TYPE /* = dtLongBitField */,
		const bool bREQUIRES_RESTART /* = false */, const ULONG ulLOWER /* = 0 */,
		const ULONG ulUPPER /* = ULONG_MAX */, const QString &rstrUNITS /* = QString   ::fromWCharArray("") */) : CBitFieldData(
		eDATA_TYPE, usNUM_OF_BITS, usSTART_BIT, pwcLIST_BOX_ITEMS, eEDITOR_TYPE, iHELP_ID, iDESC_ID,
		bUPDATE_TREE_ON_CHANGE, bREQUIRES_RESTART, rstrUNITS), m_ulUPPER(ulUPPER), m_ulLOWER(ulLOWER) {
	m_pulData = pulDATA;
}
//****************************************************************************
// ~CLongBitFieldData(void)
///
/// Destructor
///
//****************************************************************************
CLongBitFieldData::~CLongBitFieldData(void) {
}
//****************************************************************************
// USHORT BitFieldToULong( )
///
/// Method that converts a bitfield into a ULONG (usually for display purposes)
///
//****************************************************************************
ULONG CLongBitFieldData::BitFieldToULong() const {
	ULONG ulBitFieldAsLong = 0;
	// copy the bitfield data
	ulBitFieldAsLong = *m_pulData;
	// shift the short right until the first bit is the start of our bitfield
	ulBitFieldAsLong >>= m_usStartBit;
	// now mask all the higher bits - create the mask first
	double dMaskVal = pow(static_cast<double>(2), static_cast<int>(m_usNumOfBits));
	ULONG ulBitFieldMask = static_cast<ULONG>(dMaskVal);
	ulBitFieldMask -= 1;
	ulBitFieldAsLong &= ulBitFieldMask;
	return ulBitFieldAsLong;
}
//****************************************************************************
// void UpdateData( )
///
/// Method that updates a an item's associated data
///
/// @todo Code to be implemented
//****************************************************************************
void CLongBitFieldData::UpdateData(const QString pwcDATA) {
	ULONG ulBitData = 0;
	if (m_eEDITOR_TYPE == bfeNumerical) {
		QString pwcStopChar = NULL;
		ulBitData = wcstoul(pwcDATA, &pwcStopChar, 10);
	} else {
		ulBitData = GetPosOfItem(pwcDATA);
	}
	// shift the data left by the number of bits it is offset by
	ulBitData <<= m_usStartBit;
	// now we must mask the existing data and overwrite it with this new data
	ULONG ulBitMask = static_cast<USHORT>(pow(static_cast<double>(2), static_cast<int>(m_usNumOfBits))) - 1;
	ulBitMask <<= m_usStartBit;
	// invert it
	ulBitMask = ~ulBitMask;
	// mask the existing data
	*m_pulData &= ulBitMask;
	// now OR with the new data
	*m_pulData |= ulBitData;
}
//****************************************************************************
// void UpdateData( )
///
/// Method that updates an item's associated data
///
//****************************************************************************
void CLongBitFieldData::UpdateData(const USHORT usBIT_VALUE) {
	ULONG ulBitData = static_cast<ULONG>(ConvertIndexToActualVal(usBIT_VALUE));
	// shift the data left by the number of bits it is offset by
	ulBitData <<= m_usStartBit;
	// now we must mask the existing data and overwrite it with this new data
	ULONG ulBitMask = static_cast<ULONG>(pow(static_cast<double>(2), static_cast<int>(m_usNumOfBits))) - 1;
	ulBitMask <<= m_usStartBit;
	// invert it
	ulBitMask = ~ulBitMask;
	// mask the existing data
	*m_pulData &= ulBitMask;
	// now OR with the new data
	*m_pulData |= ulBitData;
}
//****************************************************************************
// bool ValidateData( const WCHAR* const pwcDATA )
///
/// Method called to validate data entered by a user
///
/// @param[in]			const WCHAR* const pwcDATA - Pointer to the data entered
///						by the user
///
/// @returns	True
///
/// @todo Code to be implemented
///
//****************************************************************************
bool CLongBitFieldData::ValidateData(const QString pwcDATA) {
	bool bValid = false;
	// only need to validate numerical entries for now
	if (m_eEDITOR_TYPE == bfeNumerical) {
		// firstly check the string is a valid USHORT
		if (pwcDATA != NULL) {
			// convert the string to a number	
			QString pwcStopChar = NULL;
			ULONG ulNewValue = wcstoul(pwcDATA, &pwcStopChar, 10);
			// get the maximum value based on the number of bits of the bit field
			ULONG ulMaxBitFieldValue = static_cast<ULONG>(pow(static_cast<double>(2), static_cast<int>(m_usNumOfBits)));
			// check the value is within a valid short range
			if ((ulNewValue >= 0) && (ulNewValue <= ULONG_MAX)) {
				// check the conversion did not stop prematurely e.g. on an invalid character
				// and the value does not exceed our limit
				if ((*pwcStopChar == '\0') && (ulNewValue < ulMaxBitFieldValue) && (ulNewValue >= m_ulLOWER)
						&& (ulNewValue <= m_ulUPPER)) {
					bValid = true;
				} else {
					QString strTitle("");
					QString strMsg("");
					strTitle = QString::asprintf("User Error");
					strMsg = QString::asprintf("The value entered must be between %u and %u.", m_ulLOWER, m_ulUPPER);
					CV6MessageBoxDlg kErrDialog(strTitle, strMsg, NULL);
				}
			} else {
				QString strTitle("");
				QString strMsg("");
				strTitle = QString::asprintf("User Error");
				strMsg = QString::asprintf("The value entered must be between %u and %u.", m_ulLOWER, m_ulUPPER);
				CV6MessageBoxDlg kErrDialog(strTitle, strMsg, NULL);
			}
		}
	} else if (IsFwOptBitField()) {
		// Firmware options, therefore we need to validate against the firmware credits
		CSysInfo::T_FIRMWARE_OPT eFWOpt = GetFirmwareOption(GetPosOfItem(pwcDATA));
		USHORT usCreditsInUse = 0;
		if ( pSYSTEM_INFO->ValidateFWOptions(eFWOpt, usCreditsInUse)) {
			bValid = true;
		} else {
			QString strTitle("");
			QString strMsg("");
			USHORT usNoOfCredits = 0;
			pSYSTEM_INFO->GetOptionInfo(eFWOpt, strTitle, usNoOfCredits);
			strTitle = QString::asprintf("User Error");
			strMsg =
					QString::asprintf(
							"There are insufficient credits available to enable this function. This function requires %u credits.",
							usNoOfCredits);
			CV6MessageBoxDlg kErrDialog(strTitle, strMsg, NULL);
		}
	} else {
		bValid = true;
	}
	return bValid;
}
//****************************************************************************
// T_FIRMWARE_OPT GetFirmwareOption( const USHORT usCURR_SEL ) const
///
/// Method that returns the current firmware option this bitfield relates to
///
/// @param[in]		const USHORT usCURR_SEL - The current selection number
///
/// @returns		An enum equating to the firmware option this bitfield relates to
///
//****************************************************************************
CSysInfo::T_FIRMWARE_OPT CLongBitFieldData::GetFirmwareOption(const USHORT usCURR_SEL) const {
	CSysInfo::T_FIRMWARE_OPT eFWOpt = CSysInfo::fwoNoneRequired;
	// only check further if the user is requesting more credits rather than less
	if (usCURR_SEL != 0) {
		switch (m_usStartBit) {
		case 0:
			if (usCURR_SEL == MATH_OPTION_FULL_BLOCK) {
				eFWOpt = CSysInfo::fwoMathsFullBlock;
			} else if (usCURR_SEL == MATH_OPTION_FULL_SCRIPT) {
				eFWOpt = CSysInfo::fwoMathsFullScript;
			}
			break;
		case 2:
			eFWOpt = CSysInfo::fwoEvents;
			break;
		case 3:
			eFWOpt = CSysInfo::fwoFastScan;
			break;
		case 4:
			eFWOpt = CSysInfo::fwoTotals;
			break;
		case 5:
			eFWOpt = CSysInfo::fwoCustomScrn;
			break;
		case 6:
			eFWOpt = CSysInfo::fwoReports;
			break;
		case 7:
			eFWOpt = CSysInfo::fwoNADCAPRecorder;
			break;
		case 8:
			eFWOpt = CSysInfo::fwoMaintenance;
			break;
		case 9:
			eFWOpt = CSysInfo::fwoPrintSupport;
			break;
		case 10:
			eFWOpt = CSysInfo::fwoTUSMode;
			break;
		case 11:
			eFWOpt = CSysInfo::fwoControlLoops;
			break;
		case 14:
			eFWOpt = CSysInfo::fwoBatch;
			break;
		case 15:
			eFWOpt = CSysInfo::fwoCounters;
			break;
		case 16:
			// NOT USED ANYMORE - CAN BE REPLACED
			//eFWOpt = CSysInfo::fwoGroups;
			break;
		case 17:
			eFWOpt = CSysInfo::fwoModbusMaster;
			break;
		case 18:
			eFWOpt = CSysInfo::fwoRemoteViewer;
			break;
		case 19:
			eFWOpt = CSysInfo::fwoTrendBus;
			break;
		case 20:
			eFWOpt = CSysInfo::fwoEmail;
			break;
		case 23:
			eFWOpt = CSysInfo::fwoPwdNetSync;
		case 24:
			//eFWOpt = CSysInfo::fwoOPC;
			break;
		case 25:
			eFWOpt = CSysInfo::fwoExtSD;
			break;
		case 26:
			eFWOpt = CSysInfo::fwoSecureWSD;
			break;
		case 27:
			eFWOpt = CSysInfo::fwoRTDataBus;
			break;
		case 28:
			eFWOpt = CSysInfo::fwoHWLock;
			break;
		case 30:
			eFWOpt = CSysInfo::fwoOpcUaServer;
			break;
			break;
		}
	}
	return eFWOpt;
}
//****************************************************************************
// void ToggleData( )
///
/// Method that toggles boolean data as a quick method of editing
///
//****************************************************************************
void CLongBitFieldData::ToggleData() {
	// check this is a boolean
	if (IsBoolean()) {
		ULONG ulData = BitFieldToULong();
		if (ulData == 0) {
			ulData = 1;
		} else {
			ulData = 0;
		}
		UpdateData(static_cast<USHORT>(ulData));
	} else {
		// Error condition
		qDebug("CLongBitFieldData::ToggleData - Toggle being called on non-boolean data");
	}
}
//****************************************************************************
// const QString   GetDataAsString( const bool bINCLUDE_UNITS /* = false */ )
///
/// Method that returns the data as a string
///
/// @return			The data item represented by the boolean value - "" if there was a problem
///
//****************************************************************************
const QString CLongBitFieldData::GetDataAsString(const bool bINCLUDE_UNITS /* = false */) {
	QString strData("");
	// check this is a boolean
	if (IsBoolean()) {
		strData = CStringUtils::GetItemAtPos(m_pwcLIST_BOX_ITEMS, static_cast<USHORT>(BitFieldToULong()));
	} else if (IsSingleSelList()) {
		// check if this is a non-sequential list by looking for embedded control characters
		QString strDelimiter;
		strDelimiter = g_wcEMBEDDED_INFO_DELIM;
		if (CStringUtils::InstanceOfStr(m_pwcLIST_BOX_ITEMS, strDelimiter) < 2) {
			// normal sequential list so just get the data
			strData = CStringUtils::GetItemAtPos(m_pwcLIST_BOX_ITEMS, static_cast<USHORT>(BitFieldToULong()));
		} else {
			// non-sequential list so we need to test all the strings in the list to see if
			// they contain the value indicated within the CMM data
			USHORT usListCount = 0;
			QString strStringToindexOf("");
			strStringToindexOf = QString::asprintf("%c%u%c", g_wcEMBEDDED_INFO_DELIM, BitFieldToULong(),
					g_wcEMBEDDED_INFO_DELIM);
			while ((strData = CStringUtils::GetItemAtPos(m_pwcLIST_BOX_ITEMS, usListCount)) != "") {
				// see if this string occurs in the list
				if (strData.indexOf(strStringToindexOf, 0) != -1) {
					// found our match - drop out of the loop
					break;
				}
				// move onto the next item
				++usListCount;
			}
			// check something was found
			if (strData == "") {
				// set to NA
				strData = QWidget::tr("NA");
			}
		}
		// check the return string is valid
		if (strData == "") {
			// the return string is null - this would imply we have attempted to obtain
			// a value that is out of range. This would usually occur when a fields are reused e.g.
			// the user changes from TC's ( ~16 types ) to Amps ( 2 types )
			// In this isutation set the value back to 0 and get the string again - a value should
			// always be found in this situation
			const USHORT usNewValue = 0;
			UpdateData(usNewValue);
			// now get the data again - this should always return something
			strData = CStringUtils::GetItemAtPos(m_pwcLIST_BOX_ITEMS, static_cast<USHORT>(BitFieldToULong()));
		}
	} else {
		// must be a numerical value
		strData = QString::asprintf("%u", BitFieldToULong());
	}
	if (bINCLUDE_UNITS && (m_strUNITS != "")) {
		strData += " " + m_strUNITS;
	}
	// strip out any embedded control characters
	RemoveEmbeddedControlInfo(strData);
	return strData;
}
//****************************************************************************
// const QString   GetDataAsString( const bool bINCLUDE_UNITS /* = false */ )
///
/// Method that returns the data as a string
///
/// @return			The string
///
//****************************************************************************
const QString CfgData::GetDataAsString(const bool bINCLUDE_UNITS /* = false */) {
	QString strData("");
	// replace all the data with asterixes if a password field
	if (m_eDATA_TYPE == dtPassword) {
		CCrypto kCrypto;
		QString strDefaultPSWD;
		strDefaultPSWD = QWidget::tr("Not set");
		strData = m_pwcData;
		if (strDefaultPSWD.compare(strData) != 0) {
			strData = kCrypto.Decrypt(m_pwcData, m_usStringLength);
		}
		int iNoOfChars = strData.size();
		strData = "";
		for (int iCount = 0; iCount < iNoOfChars; iCount++) {
			strData += L"*";
		}
	} else {
		strData = QString::asprintf("%s", m_pwcData);
	}
	return strData;
}
//****************************************************************************
// CScriptData(	char* pcDATA,
//					const USHORT usSTRING_LENGTH,
//					const int iHELP_ID,
//					const int iDESC_ID,
//					const bool bUPDATE_TREE_ON_CHANGE )
///
/// Constructor for singleline script
///
///	@param[in]			char* pcDATA - Pointer to the actual data
///	@param[in]			const USHORT usSTRING_LENGTH - The length of the string
/// @param[in]			const int iHELP_ID - The resource ID of the assocaited help for
///						this item
/// @param[in]			const int iDESC_ID - The resource ID of the associated description for
///						this item
/// @param[in]			const bool bUPDATE_TREE_ON_CHANGE - Flag indicating if this item requires
///						the config tree to be rebuilt when it changes
///
//****************************************************************************
CScriptData::CScriptData(char *pcDATA, const USHORT usSTRING_LENGTH, const int iHELP_ID, const int iDESC_ID,
		const bool bUPDATE_TREE_ON_CHANGE) : CConfigData(dtSiLEScript, iHELP_ID, iDESC_ID, bUPDATE_TREE_ON_CHANGE), m_usSTRING_LENGTH(
		usSTRING_LENGTH), m_usINSTANCE_NUMBER(0), m_pcData(pcDATA) {
}
//****************************************************************************
// CScriptData(	char* pcDATA,
//					const USHORT usSTRING_LENGTH,
//					const USHORT usPEN_NUMBER,
//					const int iHELP_ID,
//					const int iDESC_ID,
//					const bool bUPDATE_TREE_ON_CHANGE )
///
/// Constructor for multiline script
///
///	@param[in]			char* pcDATA - Pointer to the actual data
///	@param[in]			const USHORT usSTRING_LENGTH - The length of the string
///	@param[in]			const USHORT usPEN_NUMBER - The one based number of the pen this data 
///						relates to - required by the update method
/// @param[in]			const int iHELP_ID - The resource ID of the assocaited help for
///						this item
/// @param[in]			const int iDESC_ID - The resource ID of the associated description for
///						this item
/// @param[in]			const bool bUPDATE_TREE_ON_CHANGE - Flag indicating if this item requires
///						the config tree to be rebuilt when it changes
///
//****************************************************************************
CScriptData::CScriptData(char *pcDATA, const USHORT usSTRING_LENGTH, const USHORT usPEN_NUMBER, const int iHELP_ID,
		const int iDESC_ID, const bool bUPDATE_TREE_ON_CHANGE) : CConfigData(dtMuLEPenScript, iHELP_ID, iDESC_ID,
		bUPDATE_TREE_ON_CHANGE), m_usSTRING_LENGTH(usSTRING_LENGTH), m_usINSTANCE_NUMBER(usPEN_NUMBER), m_pcData(pcDATA) {
}
//****************************************************************************
// CScriptData(	WCHAR* pcDATA,
//					const USHORT usSTRING_LENGTH,
//					const USHORT usEMAIL_INSTANCE,
//					const int iHELP_ID,
//					const int iDESC_ID,
//					const bool bUPDATE_TREE_ON_CHANGE )
///
/// Constructor for multiline script
///
///	@param[in]			WCHAR* pwcDATA - Pointer to the actual data
///	@param[in]			const USHORT usSTRING_LENGTH - The length of the string
///	@param[in]			const USHORT usEMAIL_INSTANCE - The zero based instance of the email template data
///						required for the update method
/// @param[in]			const int iHELP_ID - The resource ID of the associated help for
///						this item
/// @param[in]			const int iDESC_ID - The resource ID of the associated description for
///						this item
/// @param[in]			const bool bUPDATE_TREE_ON_CHANGE - Flag indicating if this item requires
///						the config tree to be rebuilt when it changes
///
//****************************************************************************
CScriptData::CScriptData(QString pwcDATA, const USHORT usSTRING_LENGTH, const USHORT usEMAIL_INSTANCE,
		const int iHELP_ID, const int iDESC_ID, const bool bUPDATE_TREE_ON_CHANGE) : CConfigData(dtMuLEEmailTemplate,
		iHELP_ID, iDESC_ID, bUPDATE_TREE_ON_CHANGE), m_usSTRING_LENGTH(usSTRING_LENGTH), m_usINSTANCE_NUMBER(
		usEMAIL_INSTANCE), m_pcData(reinterpret_cast<char*>(pwcDATA)) {
}
//****************************************************************************
// ~QString   CfgData(void)
///
/// Destructor
///
//****************************************************************************
CScriptData::~CScriptData(void) {
}
//****************************************************************************
// void UpdateData( )
///
/// Method that updates a an item's associated data
///
//****************************************************************************
void CScriptData::UpdateData(const QString pwcDATA) {
	// check which type of script we need to validate
	if (m_eDATA_TYPE == dtSiLEScript) {
		// single line therefore copy to the maths block
#if _MSC_VER < 1400 
		wcstombs(m_pcData, pwcDATA, m_usSTRING_LENGTH);
#else
		size_t pNoOfChars;
		wcstombs_s( &pNoOfChars, m_pcData, m_usSTRING_LENGTH, pwcDATA, m_usSTRING_LENGTH );
#endif
	} else if (m_eDATA_TYPE == dtMuLEPenScript) {
		// multiline therefore call the modify script block method
		char *pcData = new char[m_usSTRING_LENGTH + 1];
#if _MSC_VER < 1400 
		wcstombs(pcData, pwcDATA, m_usSTRING_LENGTH + 1);
#else
		size_t pNoOfChars;
		wcstombs_s ( &pNoOfChars, pcData, m_usSTRING_LENGTH + 1, pwcDATA, m_usSTRING_LENGTH + 1 );
#endif
		CPenSetupConfig *pkPenSetupCfg = pSETUP->GetPenSetupConfig();
		if (pkPenSetupCfg != NULL) {
			CMMERROR eErrVal = pkPenSetupCfg->ModifyScriptBlock(m_usINSTANCE_NUMBER, ZERO_BASED, pcData);
			if (eErrVal != CMM_SUCCESS) {
				qDebug("CMM Error Code %d", eErrVal);
			}
		}
		delete pcData;
		m_pcData = pkPenSetupCfg->GetPenScriptBlock(m_usINSTANCE_NUMBER, ZERO_BASED, CONFIG_MODIFIABLE);
	} else if (m_eDATA_TYPE == dtMuLEEmailTemplate) {
		// multiline therefore call the modify script block method
		CSingleLock lock(&m_GlbSetupMutex);
		lock.Lock();
		CCommsSetupConfig *pkCommsConfig = pGlbSetup->GetCommsSetupConfig();
		lock.Unlock();
		if (pkCommsConfig != NULL) {
			CMMERROR eErrVal = pkCommsConfig->ModifyEmailBlock(m_usINSTANCE_NUMBER, const_cast<WCHAR*>(pwcDATA));
			if (eErrVal != CMM_SUCCESS) {
				qDebug("CMM Error Code %d", eErrVal);
			}
		}
		m_pcData = reinterpret_cast<char*>(pkCommsConfig->GetEmailBlock(m_usINSTANCE_NUMBER, CONFIG_MODIFIABLE));
	}
}
//****************************************************************************
// bool ValidateData( const WCHAR* const pwcDATA )
///
/// Method called to validate data entered by a user
///
/// @param[in]			const WCHAR* const pwcDATA - Pointer to the data entered
///						by the user
///
/// @returns	True if the data is valid
//****************************************************************************
bool CScriptData::ValidateData(const QString pwcDATA) {
	bool bValid = false;
#ifndef DOCVIEW
	if (m_eDATA_TYPE == dtMuLEEmailTemplate) {
		// no 
		bValid = true;
	} else {
		CScriptInstance *pkInstance = new CScriptInstance();
		// see if the script has changed
		char *pcScriptData = new char[m_usSTRING_LENGTH + 1];
		// copy the wide string into our character array
#if _MSC_VER < 1400 
		wcstombs(pcScriptData, pwcDATA, m_usSTRING_LENGTH);
#else
		size_t pNoOfChars;
		wcstombs_s (&pNoOfChars, pcScriptData, m_usSTRING_LENGTH + 1, pwcDATA, m_usSTRING_LENGTH );
#endif
		T_MATH_TYPE eMathType;
		// check which math type this is
		if (m_eDATA_TYPE == dtSiLEScript) {
			eMathType = MATH_TYPE_BLOCK;
		} else {
			eMathType = MATH_TYPE_SCRIPTING;
		}
		if (pkInstance->BuildAutoScript(pcScriptData, eMathType, SCRIPT_PROVING)) {
			// compile the script and check it is okay
			V6ERRORINFO *eErrVal = pkInstance->CompileScript();
			//AMAR
			if (eErrVal->Code == V6_E_SUCCESS || eErrVal->Type == V6_ET_NULL) {
				// the script is okay
				bValid = true;
			} else {
				bValid = false;
			}
		} else {
			// the script has not changed - should never happen first time through the script instance code
			bValid = true;
		}
		delete pcScriptData;
		delete pkInstance;
	}
#endif
	return bValid;
}
//****************************************************************************
// const QString   GetDataAsString( const bool bINCLUDE_UNITS /* = false */ )
///
/// Method called to get the data as a string, converted to display units if necessary
///
/// @returns	The data as a string
//****************************************************************************
const QString CScriptData::GetDataAsString(const bool bINCLUDE_UNITS /* = false */) {
	QString strScriptData("");
	if (m_eDATA_TYPE == dtMuLEEmailTemplate) {
		strScriptData = reinterpret_cast<WCHAR*>(m_pcData);
	} else {
		QString pwcMathsBlock = new WCHAR[m_usSTRING_LENGTH];
#if _MSC_VER < 1400 
		mbstowcs(pwcMathsBlock, m_pcData, m_usSTRING_LENGTH);
#else
		size_t pNoOfChars;
		mbstowcs_s( &pNoOfChars, pwcMathsBlock, m_usSTRING_LENGTH, m_pcData, m_usSTRING_LENGTH );
#endif
		strScriptData = QString::asprintf("%s", pwcMathsBlock);
		delete[] pwcMathsBlock;
	}
	return strScriptData;
}
//****************************************************************************
// CPickerData(	USHORT *pusData,
//					const T_CFG_DATA_TYPE eDATA_TYPE,
//					const int iHELP_ID,
//					const int iDESC_ID,
//					const bool bUPDATE_TREE_ON_CHANGE,
//					const USHORT usMIN_NO_OF_SELECTIONS,
//					const USHORT usMAX_NO_OF_SELECTIONS,
//					const USHORT usINSTANCE_NO /* = 0 */ )
///
/// Constructor
///
///	@param[in]			USHORT *pusData - Pointer to the actual data
/// @param[in]			const T_CFG_DATA_TYPE eDATA_TYPE - The type of data being stored
/// @param[in]			const int iHELP_ID - The resource ID of the assocaited help for
///						this item
/// @param[in]			const int iDESC_ID - The resource ID of the associated description for
///						this item
/// @param[in]			const bool bUPDATE_TREE_ON_CHANGE - Flag indicating if this item requires
///						the config tree to be rebuilt when it changes
///	@param[in]			const USHORT usMIN_NO_OF_SELECTIONS - The minimum number of selections for this item
///	@param[in]			const USHORT usMAX_NO_OF_SELECTIONS - The maximum number of selections for this item
///	@param[in]			const USHORT usINSTANCE_NO - The instance number of this item
///
//****************************************************************************
CPickerData::CPickerData(USHORT *pusData, const T_CFG_DATA_TYPE eDATA_TYPE, const int iHELP_ID, const int iDESC_ID,
		const bool bUPDATE_TREE_ON_CHANGE, const USHORT usMIN_NO_OF_SELECTIONS, const USHORT usMAX_NO_OF_SELECTIONS,
		const USHORT usINSTANCE_NO /* = 255 */) : CConfigData(eDATA_TYPE, iHELP_ID, iDESC_ID, bUPDATE_TREE_ON_CHANGE), m_usINSTANCE_NO(
		usINSTANCE_NO), m_usMIN_NO_OF_SELECTIONS(usMIN_NO_OF_SELECTIONS), m_usMAX_NO_OF_SELECTIONS(
		usMAX_NO_OF_SELECTIONS) {
	m_pusData = pusData;
}
//****************************************************************************
// ~CPickerData(void)
///
/// Destructor
///
//****************************************************************************
CPickerData::~CPickerData(void) {
}
//****************************************************************************
// void SetupPickerMgr( CPickerMgr &rkPickerMgr )
///
/// Method that sets up the data within the picker manager class so it is ready
/// for display
///	
/// @param[out]			CPickerMgr &rkPickerMgr - The picker manager class to populate
///
//****************************************************************************
void CPickerData::SetupPickerMgr(CPickerMgr &rkPickerMgr) const {
	// setup the selections
	rkPickerMgr.SetMinNoOfSelections(m_usMIN_NO_OF_SELECTIONS);
	rkPickerMgr.SetMaxNoOfSelections(m_usMAX_NO_OF_SELECTIONS);
	switch (m_eDATA_TYPE) {
	case dtSinglePen:
		SetupSinglePenData(rkPickerMgr);
		break;
	case dtSinglePenIncNoneSel:
		SetupSinglePenData(rkPickerMgr, true);
		break;
	case dtSinglePenAlarm:
		SetupSinglePenAlarmData(rkPickerMgr);
		break;
	case dtSinglePenLatchedAlarm:
		SetupSinglePenLatchedAlarmData(rkPickerMgr);
		break;
	case dtMultiPen:
		SetupMultiPenData(rkPickerMgr, pptNoFilter);
		break;
	case dtSingleAlarm:
		SetupSingleAlarmData(rkPickerMgr);
		break;
	case dtMultiAlarm:
		SetupMultiAlarmData(rkPickerMgr);
		break;
	case dtMultiLatchedAlarm:
		SetupMultiLatchedAlarmData(rkPickerMgr);
		break;
	case dtMultiPenTotaliser:
		SetupMultiPenData(rkPickerMgr, pptTotalisers);
		break;
	case dtMultiPenLogging:
		SetupMultiPenData(rkPickerMgr, pptLogging);
		break;
	case dtSingleAnalogueIn:
		SetupSingleAnalogueInData(rkPickerMgr, aptALL);
		break;
	case dtSingleAnalogueRTIn:
		SetupSingleAnalogueInData(rkPickerMgr, aptRT);
		break;
	case dtSingleAnalogueTCIn:
		SetupSingleAnalogueInData(rkPickerMgr, aptTC);
		break;
	case dtMultiAnalogueIn:
		SetupMultiAnalogueInData(rkPickerMgr, aptALL);
		break;
	case dtMultiAnalogueRTIn:
		SetupMultiAnalogueInData(rkPickerMgr, aptRT);
		break;
	case dtMultiAnalogueTCIn:
		SetupMultiAnalogueInData(rkPickerMgr, aptTC);
		break;
	case dtMultiAnalogueTUSTCIn:
		SetupMultiAnalogueInData(rkPickerMgr, aptTUSSensor);
		break;
	case dtSingleDigIn:
		// setup a single digital input
		SetupDigData(rkPickerMgr, dtInput);
		break;
	case dtSingleLoPulseIn:
		// setup a single digital pulse input
		SetupDigData(rkPickerMgr, dtPulseInput);
		break;
	case dtSingleHiPulseIn:
		// setup a single pulse input
		rkPickerMgr.SetupPulsePicker(*m_pusData);
		break;
	case dtMultiDigIn:
		// setup multiple digital inputs
		SetupDigData(rkPickerMgr, dtInput);
		// set the maximum number of selections based on the number of normal items
		rkPickerMgr.SetupMaxSelectionsLimit();
		break;
	case dtSingleRelayOut:
		// setup a single relay output
		SetupDigData(rkPickerMgr, dtOutput);
		break;
	case dtMultiRelayOut:
		// setup multiple digital outputs
		SetupDigData(rkPickerMgr, dtOutput);
		// set the maximum number of selections based on the number of normal items
		rkPickerMgr.SetupMaxSelectionsLimit();
		break;
	case dtEmailRecipients:
		// setup multiple email recipients
		rkPickerMgr.SetupEmailPicker(*(reinterpret_cast<quint64*>(m_pusData)));
		break;
	case dtAllCounterTypes:
		// setup a multiple counter type picker
		rkPickerMgr.SetupAllCounterTypesPicker(*(reinterpret_cast<ULONG*>(m_pusData)));
		break;
	case dtMessageListTypes:
		// setup a multiple message list type picker
		rkPickerMgr.SetupAllMsgListTypesPicker(*(reinterpret_cast<ULONG*>(m_pusData)));
		break;
	case dtDaysOfTheWeek:
		// setup days of the week
		rkPickerMgr.SetupDOWPicker(*m_pusData);
		break;
	case dtScreens:
		// setup single screen picker
		rkPickerMgr.SetupScreensPicker((reinterpret_cast<T_STRING_PICKER_DATA*>(m_pusData)));
		break;
	case dtMultiPulseIn:
		// setup multiple pulse inputs
		rkPickerMgr.SetupMultiplePulsePicker((reinterpret_cast<ULONG*>(m_pusData)));
		break;
	case dtSingleEvent:
		// setup single event
		rkPickerMgr.SetupSingleEventPicker(*m_pusData);
		break;
	case dtMultiEvent:
		// setup multiple events
		rkPickerMgr.SetupMultiEventPicker((reinterpret_cast<ULONG*>(m_pusData)), m_usINSTANCE_NO);
		break;
	case dtSingleUserCounters:
		// setup single user counter
		rkPickerMgr.SetupSingleUserCounterPicker(*m_pusData);
		break;
	case dtMultiUserCounters:
		// setup multiple user counters
		rkPickerMgr.SetupMultiUserCountersPicker((reinterpret_cast<ULONG*>(m_pusData)));
		break;
	case dtSingleTimer:
		// setup single user counter
		rkPickerMgr.SetupSingleTimerPicker(*m_pusData);
		break;
	case dtMultipleTimers:
		// setup multiple user counters
		rkPickerMgr.SetupMultipleTimersPicker((reinterpret_cast<ULONG*>(m_pusData)));
		break;
	case dtMultipleUserVars:
		// setup multiple user counters
		rkPickerMgr.SetupMultipleUserVarsPicker((reinterpret_cast<ULONG*>(m_pusData)));
		break;
	default:
		DebugBreak();
		break;
	}
}
//****************************************************************************
// void SetupSinglePenData( CPickerMgr &rkPickerMgr ) const
///
/// Method that sets up the data required for a single pen picker
///	
/// @param[out]			CPickerMgr &rkPickerMgr - The picker manager class to populate
/// @param[in]			const bool bINCLUDE_NONE_SELECTION - Indicates if we should add the
///						'NONE' button selection
///
//****************************************************************************
void CPickerData::SetupSinglePenData(CPickerMgr &rkPickerMgr, const bool bINCLUDE_NONE_SELECTION /* = false */) const {
	// include the 'NONE' selection is required
	if (bINCLUDE_NONE_SELECTION) {
		QString strTitle("");
		CPickerItem::T_PICKER_ITEM_STATE eState = CPickerItem::pisNormal;
		strTitle = QWidget::tr("None");
		rkPickerMgr.AddItem(strTitle, eState, (*m_pusData == V6_MAX_PENS), V6_MAX_PENS);
	}
	rkPickerMgr.SetupPenPicker(m_pusData, m_usINSTANCE_NO);
}
//****************************************************************************
// void SetupSinglePenAlarmData( CPickerMgr &rkPickerMgr ) const
///
/// Method that sets up the data required for a single pen alarm picker
///	
/// @param[out]			CPickerMgr &rkPickerMgr - The picker manager class to populate
///
//****************************************************************************
void CPickerData::SetupSinglePenAlarmData(CPickerMgr &rkPickerMgr) const {
	rkPickerMgr.SetupPenPicker(m_pusData, m_usINSTANCE_NO, false, pptAlarms);
}
//****************************************************************************
// void SetupSinglePenLatchedAlarmData( CPickerMgr &rkPickerMgr ) const
///
/// Method that sets up the data required for a single pen latched alarm picker
///	
/// @param[out]			CPickerMgr &rkPickerMgr - The picker manager class to populate
///
//****************************************************************************
void CPickerData::SetupSinglePenLatchedAlarmData(CPickerMgr &rkPickerMgr) const {
	rkPickerMgr.SetupPenPicker(m_pusData, m_usINSTANCE_NO, false, pptLatchedAlarms);
}
//****************************************************************************
// void SetupSingleAlarmData( CPickerMgr &rkPickerMgr ) const
///
/// Method that sets up the data required for a single alarm picker
///	
/// @param[out]			CPickerMgr &rkPickerMgr - The picker manager class to populate
///
//****************************************************************************
void CPickerData::SetupSingleAlarmData(CPickerMgr &rkPickerMgr) const {
	rkPickerMgr.SetupAlarmPicker(*m_pusData, m_usINSTANCE_NO, false);
}
//****************************************************************************
// void SetupMultiAlarmData( CPickerMgr &rkPickerMgr ) const
///
/// Method that sets up the data required for a mutliple alarm picker
///	
/// @param[out]			CPickerMgr &rkPickerMgr - The picker manager class to populate
///
//****************************************************************************
void CPickerData::SetupMultiAlarmData(CPickerMgr &rkPickerMgr) const {
	rkPickerMgr.SetupAlarmPicker(*m_pusData, m_usINSTANCE_NO, true);
}
//****************************************************************************
// void SetupMultiLatchedAlarmData( CPickerMgr &rkPickerMgr ) const
///
/// Method that sets up the data required for a mutliple latched alarm picker
///	
/// @param[out]			CPickerMgr &rkPickerMgr - The picker manager class to populate
///
//****************************************************************************
void CPickerData::SetupMultiLatchedAlarmData(CPickerMgr &rkPickerMgr) const {
	rkPickerMgr.SetupAlarmPicker(*m_pusData, m_usINSTANCE_NO, true, true);
}
//****************************************************************************
// void SetupMultiPenData( CPickerMgr &rkPickerMgr, const T_PEN_PICKER_TYPES ePICKER_TYPES ) const
///
/// Method that sets up the data required for a single pen picker
///	
/// @param[out]			CPickerMgr &rkPickerMgr - The picker manager class to populate
/// @param[in]			const T_PEN_PICKER_TYPES ePICKER_TYPES - Indicates if we need to filter pens
///						for a particular function e.g. logging or totaliser
///
//****************************************************************************
void CPickerData::SetupMultiPenData(CPickerMgr &rkPickerMgr, const T_PEN_PICKER_TYPES ePICKER_TYPES) const {
	rkPickerMgr.SetupPenPicker(m_pusData, m_usINSTANCE_NO, true, ePICKER_TYPES);
}
//****************************************************************************
// void SetupSingleAnalogueInData( CPickerMgr &rkPickerMgr,
//									const T_AIN_PICKER_TYPES eAIN_PICKER_TYPE ) const
///
/// Method that sets up the data required for a single analogue input picker
///	
/// @param[out]			CPickerMgr &rkPickerMgr - The picker manager class to populate
/// @param[in]			const T_AIN_PICKER_TYPES eAIN_PICKER_TYPE - the AIN picker to implement
///
//****************************************************************************
void CPickerData::SetupSingleAnalogueInData(CPickerMgr &rkPickerMgr, const T_AIN_PICKER_TYPES eAIN_PICKER_TYPE) const {
	rkPickerMgr.SetupAnalogueInPicker(m_pusData, m_usINSTANCE_NO, eAIN_PICKER_TYPE, false);
}
//****************************************************************************
// void SetupMultiAnalogueInData(	CPickerMgr &rkPickerMgr,
//									const T_AIN_PICKER_TYPES eAIN_PICKER_TYPE) const
///
/// Method that sets up the data required for a multiple analogue input picker
///	
/// @param[out]			CPickerMgr &rkPickerMgr - The picker manager class to populate
/// @param[in]			const T_AIN_PICKER_TYPES eAIN_PICKER_TYPE - the AIN picker to implement
///
//****************************************************************************
void CPickerData::SetupMultiAnalogueInData(CPickerMgr &rkPickerMgr, const T_AIN_PICKER_TYPES eAIN_PICKER_TYPE) const {
	rkPickerMgr.SetupAnalogueInPicker(m_pusData, m_usINSTANCE_NO, eAIN_PICKER_TYPE, true);
}
//****************************************************************************
// void SetupMultiDigData( CPickerMgr &rkPickerMgr, const T_DIGIO_TYPES eDIG_IO_TYPE ) const
///
/// Method that sets up the data required for a multiple digital input/output/pulse picker
///	
/// @param[out]			CPickerMgr &rkPickerMgr - The picker manager class to populate
/// @param[in]			const T_DIGIO_TYPES eDIG_IO_TYPE - Variable indicating whether we are 
///						setting up digital inputs, outputs or pulse inputs
///
//****************************************************************************
void CPickerData::SetupDigData(CPickerMgr &rkPickerMgr, const T_DIGIO_TYPES eDIG_IO_TYPE) const {
	// check if showing multi digital information
	if ((m_eDATA_TYPE == dtMultiDigIn) || (m_eDATA_TYPE == dtMultiRelayOut)) {
		// showing multi so m_pusData is already pointing at a digital mask
		rkPickerMgr.SetupDigitalPicker(reinterpret_cast<T_PDIGITALMASK>(m_pusData), eDIG_IO_TYPE);
	} else {
		// this is single digital so we need to convert our instance number into a bitmask
		// see if in the high or low ULONG
		USHORT usTempInstance = *m_pusData;
		ULONG ulBitMask = 0x00000001;
		ULONG ulCurrULong = 0;
		T_DIGITALMASK tDigMask;
		tDigMask.L[0] = 0;
		tDigMask.L[1] = 0;
		if (usTempInstance > 31) {
			// move to the second ULONG in the digital mask structure
			ulCurrULong = 1;
			// normalise the current instance number wrt the current ULONG
			usTempInstance -= 32;
		}
		// continue while the instance number is greater than 1 - basically this willl shift the bitmask on
		// until it reaches the bit number corresponding to the current instance number
		while (usTempInstance > 0) {
			// shift left one bit
			ulBitMask <<= 1;
			--usTempInstance;
		}
		// set the digital mask to the bitmask
		tDigMask.L[ulCurrULong] = ulBitMask;
		// now show the data
		rkPickerMgr.SetupDigitalPicker(&tDigMask, eDIG_IO_TYPE);
	}
}
//****************************************************************************
// const QString   UpdateData( CPickerMgr &rkPickerMgr )
///
/// Method that updates the data using the picker manager class data
///	
/// @param[in]			CPickerMgr &rkPickerMgr - The picker manager class to extract the
///						information from
///
//****************************************************************************
const QString CPickerData::UpdateData(CPickerMgr &rkPickerMgr) {
	QString strSubTitle("");
	switch (m_eDATA_TYPE) {
	case dtSinglePen:
	case dtSinglePenIncNoneSel:
	case dtSinglePenAlarm:
	case dtSinglePenLatchedAlarm:
	case dtSingleAnalogueIn:
	case dtSingleAnalogueRTIn:
	case dtSingleAnalogueTCIn:
	case dtSingleDigIn:
	case dtSingleRelayOut:
	case dtSingleLoPulseIn:
	case dtSingleHiPulseIn:
	case dtSingleEvent:
	case dtSingleUserCounters:
	case dtSingleTimer:
		strSubTitle = UpdateSingleInstanceData(rkPickerMgr);
		break;
	case dtMultiDigIn:
	case dtMultiRelayOut:
	case dtMultiPen:
	case dtMultiPenTotaliser:
	case dtMultiPenLogging:
	case dtMultiAlarm:
	case dtMultiLatchedAlarm:
	case dtMultiAnalogueIn:
	case dtMultiAnalogueRTIn:
	case dtMultiAnalogueTCIn:
	case dtMultiAnalogueTUSTCIn:
	case dtEmailRecipients:
	case dtAllCounterTypes:
	case dtMessageListTypes:
	case dtScreens:
	case dtDaysOfTheWeek:
	case dtMultiPulseIn:
	case dtMultiEvent:
	case dtMultiUserCounters:
	case dtMultipleTimers:
	case dtMultipleUserVars:
		strSubTitle = UpdateMultiInstanceData(rkPickerMgr);
		break;
	default:
		DebugBreak();
		break;
	}
	return strSubTitle;
}
//****************************************************************************
// const QString  UpdateSingleInstanceData( CPickerMgr &rkPickerMgr )
///
/// Method that updates the data using the picker manager class data
///	
/// @param[in]			 CPickerMgr &rkPickerMgr - The picker manager class to extract the
///						information from
///
/// @return		A string containing the selected instance numbers
///
//****************************************************************************
const QString CPickerData::UpdateSingleInstanceData(CPickerMgr &rkPickerMgr) {
	CPickerItem *pkCurrItem = rkPickerMgr.GetFirstItem();
	bool bFoundSelInstance = false;
	while (pkCurrItem != NULL) {
		// check if this is the selected item
		if (pkCurrItem->GetSelected()) {
			// the selected item - set the data varaible
			*m_pusData = pkCurrItem->GetInstanceNo();
			bFoundSelInstance = true;
			break;
		}
		pkCurrItem = rkPickerMgr.GetNextItem();
	}
	// check a selected instance was found
	if (!bFoundSelInstance) {
		// no selected instance was found therefore set to the appropriate limit
		if ((m_eDATA_TYPE == dtSinglePen) || (m_eDATA_TYPE == dtSinglePenIncNoneSel)
				|| (m_eDATA_TYPE == dtSinglePenAlarm) || (m_eDATA_TYPE == dtSinglePenLatchedAlarm)) {
			*m_pusData = V6_MAX_PENS;
		} else if (m_eDATA_TYPE == dtSingleEvent) {
			*m_pusData = EVENTSYSTEM_EVENT_SIZE;
		} else if (m_eDATA_TYPE == dtSingleUserCounters) {
			*m_pusData = COUNTERS_COUNTER_SIZE;
		} else if (m_eDATA_TYPE == dtSingleTimer) {
			*m_pusData = MAX_SCRIPT_TIMERS;
		} else {
			*m_pusData = MAX_DIGITAL_IO;
		}
	}
	return GetDataAsString();
}
//****************************************************************************
// const QString  UpdateMultiInstanceData( CPickerMgr &rkPickerMgr )
///
/// Method that updates the data using the picker manager class data
///	
/// @param[in]			 CPickerMgr &rkPickerMgr - The picker manager class to extract the
///						information from
///
/// @return		A string containing the selected instance numbers
///
//****************************************************************************
const QString CPickerData::UpdateMultiInstanceData(CPickerMgr &rkPickerMgr) {
	CPickerItem *pkCurrItem = rkPickerMgr.GetFirstItem();
	USHORT usCurrUShort = 0;
	USHORT usBitMask = 0x0001;
	// erase the bitmask contents, thus resettting all the values - only selected items will be set again
	const USHORT usINSTANCES = GetNumberOfInstances();
	for (USHORT usCount = 0; usCount < usINSTANCES; usCount++) {
		usBitMask = CMathUtils::Get16BitMask(usCount, usCurrUShort);
		// set this bit to zero
		m_pusData[usCurrUShort] &= ~usBitMask;
	}
	while (pkCurrItem != NULL) {
		// check if the state of this item
		if (pkCurrItem->GetSelected()) {
			usBitMask = CMathUtils::Get16BitMask(pkCurrItem->GetInstanceNo(), usCurrUShort);
			m_pusData[usCurrUShort] |= usBitMask;
		} else {
			// make sure this value is not greater than 128 which would imply this is a 
			// padded button that has no corresponding pen that we wish to reset
			if (pkCurrItem->GetInstanceNo() < 128) {
				usBitMask = CMathUtils::Get16BitMask(pkCurrItem->GetInstanceNo(), usCurrUShort);
				// set this bit to zero
				m_pusData[usCurrUShort] &= ~usBitMask;
			}
		}
		pkCurrItem = rkPickerMgr.GetNextItem();
	}
	return GetDataAsString();
}
//****************************************************************************
// const QString   GetDataAsString( const bool bINCLUDE_UNITS /* = false */ )
///
/// Method that returns the data as a string
///
/// @return			A string representation of the selected items
///
/// @TODO - Once dtSingleRelayOut is in use, modify code so that the fixed relay
///			text is displayed for item 49
///
//****************************************************************************
const QString CPickerData::GetDataAsString(const bool bINCLUDE_UNITS /* = false */) {
	QString strData("");
	// required for the email recipient names if this is an email recipient picker
	T_EMAIL *ptEmail = NULL;
	// check this is a single selection
	if ((m_eDATA_TYPE == dtSinglePen) || (m_eDATA_TYPE == dtSinglePenIncNoneSel) || (m_eDATA_TYPE == dtSinglePenAlarm)
			|| (m_eDATA_TYPE == dtSinglePenLatchedAlarm) || (m_eDATA_TYPE == dtSingleAnalogueIn)
			|| (m_eDATA_TYPE == dtSingleAnalogueRTIn) || (m_eDATA_TYPE == dtSingleAnalogueTCIn)
			|| (m_eDATA_TYPE == dtSingleDigIn) || (m_eDATA_TYPE == dtSingleLoPulseIn)
			|| (m_eDATA_TYPE == dtSingleHiPulseIn) || (m_eDATA_TYPE == dtSingleRelayOut)
			|| (m_eDATA_TYPE == dtSingleEvent) || (m_eDATA_TYPE == dtSingleUserCounters)
			|| (m_eDATA_TYPE == dtSingleTimer)) {
		if (((m_eDATA_TYPE == dtSinglePen) && (*m_pusData == V6_MAX_PENS))
				|| ((m_eDATA_TYPE == dtSinglePenIncNoneSel) && (*m_pusData == V6_MAX_PENS))
				|| ((m_eDATA_TYPE == dtSinglePenAlarm) && (*m_pusData == V6_MAX_PENS))
				|| ((m_eDATA_TYPE == dtSinglePenLatchedAlarm) && (*m_pusData == V6_MAX_PENS))
				|| ((m_eDATA_TYPE == dtSingleAnalogueIn) && (*m_pusData == 48))
				|| ((m_eDATA_TYPE == dtSingleAnalogueRTIn) && (*m_pusData == 48))
				|| ((m_eDATA_TYPE == dtSingleAnalogueTCIn) && (*m_pusData == 48))
				|| ((m_eDATA_TYPE == dtSingleDigIn) && (*m_pusData == 48))
				|| ((m_eDATA_TYPE == dtSingleLoPulseIn) && (*m_pusData == 48))
				|| ((m_eDATA_TYPE == dtSingleHiPulseIn) && (*m_pusData == 48))
				|| ((m_eDATA_TYPE == dtSingleRelayOut) && (*m_pusData == 48))
				|| ((m_eDATA_TYPE == dtSingleEvent) && (*m_pusData == EVENTSYSTEM_EVENT_SIZE))
				|| ((m_eDATA_TYPE == dtSingleUserCounters) && (*m_pusData == COUNTERS_COUNTER_SIZE))
				|| ((m_eDATA_TYPE == dtSingleTimer) && (*m_pusData == MAX_SCRIPT_TIMERS))) {
			// set to none
			strData = QWidget::tr("None");
			// check if there should be at least one item selected
			if (m_usMIN_NO_OF_SELECTIONS > 0) {
				QString strasprintftedS = "";
				// add the embedded control characters around this item top make it red
				QString strFalseColour(L" ");
				ResColour *pkColour = pSYSTEM_INFO->pOemInfo->GetColour( V6RES_COLOUR_BTNFALSETEXT);
				COLORREF crFalse = pkColour->pColor;
				strFalseColour = QString::asprintf("%u", crFalse);
				strasprintftedStr = QString::asprintf("%c%s%c%s", g_wcMOD_COLOUR, strFalseColour, g_wcMOD_COLOUR,
						strData);
				strData = strasprintftedStr;
			}
		}
#ifndef TTR6SETUP
		else if (*m_pusData == CScreen::ms_usUNINITIALISED_INSTANCE) {
			strData = QWidget::tr("None Set");
		}
#endif
		else {
			// single selection - make one based
			strData = QString::asprintf("%u", (*m_pusData) + 1);
		}
	} else {
		USHORT usInstancesToCheck = GetNumberOfInstances();
		QString strStringList("");
		// setup a pointer to the email structure too if this is email so that we can retrieve
		// the email names
		if (m_eDATA_TYPE == dtEmailRecipients) {
			// setup the pointers to the email config data
			CSingleLock lock(&m_GlbSetupMutex);
			lock.Lock();
			CCommsSetupConfig *pkCommsConfig = pGlbSetup->GetCommsSetupConfig();
			lock.Unlock();
			T_PCOMMUNICATIONS ptCommsData = NULL;
			if (pkCommsConfig != NULL) {
				ptCommsData = pkCommsConfig->GetCommsBlock(CONFIG_MODIFIABLE);
			}
			if (ptCommsData != NULL) {
				ptEmail = &ptCommsData->Email;
			}
		} else if (m_eDATA_TYPE == dtDaysOfTheWeek) {
			strStringList = QWidget::tr("Sun|Mon|Tues|Weds|Thurs|Fri|Sat|");
		} else if (m_eDATA_TYPE == dtScreens) {
			strStringList = reinterpret_cast<T_STRING_PICKER_DATA*>(m_pusData)->strScreenList;
		} else if (m_eDATA_TYPE == dtAllCounterTypes) {
			strStringList = QWidget::tr("Alarm|User|Event|Digital Input|Relay Output|Pulse|");
		} else if (m_eDATA_TYPE == dtMessageListTypes) {
			strStringList = QWidget::tr("Alarm|System|Diagnostic|Security|User|");
		}
		// multiple instances selected therefore delimit with a comma
		USHORT usCount = 1;
		USHORT usCurrUShort = 0;
		USHORT usBitMask = 0x0001;
		QString strNo("");
		USHORT usSelectedItems = 0;
		// check all the instances available unless we reach the maximum alloweable number of items
		while ((usCount < (usInstancesToCheck + 1)) && (m_usMAX_NO_OF_SELECTIONS > usSelectedItems)) {
			// check if this is our selected item or disabled by seeing if the bit is set
			if ((m_pusData[usCurrUShort] & usBitMask) == usBitMask) {
				// if emal addresses then we must show the address rather than an index
				if ((m_eDATA_TYPE == dtEmailRecipients) && (ptEmail != NULL)) {
					// check the email address is still valid too
					if (ptEmail->EmailAddresses[usCount - 1][0] != '\0') {
						strNo = QString::asprintf("%s, ", ptEmail->EmailAddresses[usCount - 1]);
					} else {
						strNo = "";
					}
				} else if ((m_eDATA_TYPE == dtDaysOfTheWeek) || (m_eDATA_TYPE == dtScreens)
						|| (m_eDATA_TYPE == dtAllCounterTypes) || (m_eDATA_TYPE == dtMessageListTypes)) {
					strNo = CStringUtils::GetItemAtPos(strStringList, usCount - 1) + L", ";
				} else if (m_eDATA_TYPE == dtMultiPulseIn) {
					// multiple pulse inputs - preceed with a L or an H accordingly
					if (usCurrUShort >= 3) {
						// hi resolution pulse
						strNo = QString::asprintf("H%u, ", usCount - MAX_LORES_PULSE);
					} else {
						// lo resolution pulse
						strNo = QString::asprintf("L%u, ", usCount);
					}
				} else {
					// just show the instance number
					strNo = QString::asprintf("%u, ", usCount);
				}
				// check if this is not relay outputs or not the fixed relay which gets displayed later
				if ((m_eDATA_TYPE != dtMultiRelayOut) || (usCount != (MAX_DIGITAL_IO + 1))) {
					strData += strNo;
				}
				// increment the number of selected items
				++usSelectedItems;
			}
			usCount++;
			// shift the mask to the next bit
			usBitMask <<= 1;
			// check if our bitmask has reached the end of a ushort e.g. past the 15th bit
			if (usBitMask == 0) {
				usBitMask = 0x0001;
				// move the digital input mask item onto the next USHORT
				++usCurrUShort;
			}
		}
		// now check the power relay if necessary and if allowed
		if ((m_eDATA_TYPE == dtMultiRelayOut) &&
		pDEVICE_INFO->GetPowerRelay() && (m_usMAX_NO_OF_SELECTIONS > usSelectedItems)) {
			// we must now add the power relay to the list in the last position
			// set the bitmask to the 49th bit which is the power relay
			usBitMask = CPickerMgr::ms_usPOWER_RELAY_BITMASK;
			if (((m_pusData[3] & CPickerMgr::ms_usPOWER_RELAY_BITMASK) == CPickerMgr::ms_usPOWER_RELAY_BITMASK)) {
				strNo = QWidget::tr("Fixed");
				strData += strNo + L" ";
			}
		}
		// remove the comma and space if necessary
		if (strData != "") {
			strData.remove(strData.size() - 2);
		} else {
			// Get the none string
			strData = QWidget::tr("None");
			// check if there should be at least one item selected
			if (m_usMIN_NO_OF_SELECTIONS > 0) {
				QString strasprintftedSQWidget::tr("");
				// add the embedded control characters around this item top make it red
				QString strFalseColour(L" ");
				ResColour *pkColour = pSYSTEM_INFO->pOemInfo->GetColour( V6RES_COLOUR_BTNFALSETEXT);
				COLORREF crFalse = pkColour->pColor;
				strFalseColour = QString::asprintf("%u", crFalse);
				strasprintftedStr = QString::asprintf("%c%s%c%s", g_wcMOD_COLOUR, strFalseColour, g_wcMOD_COLOUR,
						strData);
				strData = strasprintftedStr;
			}
		}
	}
	return strData;
}
//****************************************************************************
// const USHORT CPickerData::GetNumberOfInstances( ) const
///
/// Method that returns the number of instances of the configured data type 
/// for this class	
///
/// @return			The number of instances
///
//****************************************************************************
const USHORT CPickerData::GetNumberOfInstances() const {
	USHORT usInstancesToCheck = 0;
	if ((m_eDATA_TYPE == dtMultiPen) || (m_eDATA_TYPE == dtMultiPenTotaliser) || (m_eDATA_TYPE == dtMultiPenLogging)) {
		usInstancesToCheck = V6_MAX_PENS;
	} else if ((m_eDATA_TYPE == dtMultiAlarm) || (m_eDATA_TYPE == dtMultiLatchedAlarm)) {
		usInstancesToCheck = V6_MAX_ALARMS;
	} else if (m_eDATA_TYPE == dtMultiDigIn) {
		usInstancesToCheck = MAX_DIGITAL_IO;
	} else if (m_eDATA_TYPE == dtMultiRelayOut) {
		// add the power relay
		usInstancesToCheck = MAX_DIGITAL_IO + 1;
	} else if (m_eDATA_TYPE == dtEmailRecipients) {
		usInstancesToCheck = EMAIL_EMAILADDRESSES_SIZE;
	} else if (m_eDATA_TYPE == dtAllCounterTypes) {
		usInstancesToCheck = g_usMAX_COUNTER_TYPES;
	} else if (m_eDATA_TYPE == dtMessageListTypes) {
		usInstancesToCheck = g_usMAX_SELECTABLE_MSG_LIST_TYPES;
	} else if (m_eDATA_TYPE == dtDaysOfTheWeek) {
		usInstancesToCheck = 7;
	} else if (m_eDATA_TYPE == dtScreens) {
		usInstancesToCheck = LAYOUT_SCREENLIST_SIZE;
	} else if (m_eDATA_TYPE == dtMultiEvent) {
		usInstancesToCheck = EVENTSYSTEM_EVENT_SIZE;
	} else if (m_eDATA_TYPE == dtMultiUserCounters) {
		usInstancesToCheck = COUNTERS_COUNTER_SIZE;
	} else if (m_eDATA_TYPE == dtMultipleTimers) {
		usInstancesToCheck = MAX_SCRIPT_TIMERS;
	} else if (m_eDATA_TYPE == dtMultipleUserVars) {
		usInstancesToCheck = MAX_V6_USER_VARS;
	} else if (m_eDATA_TYPE == dtMultiPulseIn) {
		usInstancesToCheck = MAX_HIRES_PULSE + MAX_LORES_PULSE;
	} else {
		// get the digital inputs
		usInstancesToCheck = MAX_DIGITAL_IO;
	}
	return usInstancesToCheck;
}
//****************************************************************************
// CByteData(	BYTE *pbyDATA,
//				const BYTE byLOWER,
//				const BYTE byUPPER,
//				const int iHELP_ID,
//				const int iDESC_ID,
//				const bool bUPDATE_TREE_ON_CHANGE,
//				const QString   strUNITS /* = QString   ::fromWCharArray("") */,
//				const bool bREQUIRES_RESTART /* = false */ )
///
/// Constructor
///
///	@param[in]			BYTE *pbyDATA - Pointer to the actual data
///	@param[in]			const BYTE byLOWER - The lower limit of this data
///	@param[in]			const BYTE byUPPER - The upper limit of this data
/// @param[in]			const int iHELP_ID - The resource ID of the assocaited help for
///						this item
/// @param[in]			const int iDESC_ID - The resource ID of the associated description for
///						this item
/// @param[in]			const bool bUPDATE_TREE_ON_CHANGE - Flag indicating if this item requires
///						the config tree to be rebuilt when it changes
/// @param[in]			const QString   strUNITS - The units that need to be displayed after the string
/// @param[in]			const bool bREQUIRES_RESTART - Flag indicating if a restart is required after modifying this
///						variable
///
//****************************************************************************
CByteData::CByteData(BYTE *pbyDATA, const BYTE byLOWER, const BYTE byUPPER, const int iHELP_ID, const int iDESC_ID,
		const bool bUPDATE_TREE_ON_CHANGE, const QString strUNITS /* = QString   ::fromWCharArray("") */,
		const bool bREQUIRES_RESTART /* = false */) : CConfigData(dtByte, iHELP_ID, iDESC_ID, bUPDATE_TREE_ON_CHANGE,
		bREQUIRES_RESTART, strUNITS),
/// the upper and lower limits required to validate a USHORT
m_byLOWER(byLOWER), m_byUPPER(byUPPER) {
	m_pbyData = pbyDATA;
}
//****************************************************************************
// ~CUShortData(void)
///
/// Destructor
///
//****************************************************************************
CByteData::~CByteData() {
}
//****************************************************************************
// void UpdateData( )
///
/// Method that updates an item's associated data
///
//****************************************************************************
void CByteData::UpdateData(const QString pwcDATA) {
	// convert the string to a number	
	QString pwcStopChar = NULL;
	BYTE byNewValue = 0;
	byNewValue = static_cast<BYTE>(wcstoul(pwcDATA, &pwcStopChar, 10));
	// now setup a pointer to this item
	memcpy(m_pbyData, &byNewValue, sizeof(BYTE));
}
//****************************************************************************
// bool ValidateData( const WCHAR* const pwcDATA )
///
/// Method called to validate data entered by a user
///
/// @param[in]			const WCHAR* const pwcDATA - Pointer to the data entered
///						by the user
///
/// @returns	True if the data is valid
//****************************************************************************
bool CByteData::ValidateData(const QString pwcDATA) {
	bool bValid = false;
	// check the string is valid
	if (pwcDATA != NULL) {
		// convert the string to a number	
		QString pwcStopChar = NULL;
		ULONG ulNewValue = wcstoul(pwcDATA, &pwcStopChar, 10);
		// check the value is within a valid short range
		if ((ulNewValue >= 0) && (ulNewValue <= UCHAR_MAX)) {
			// okay to cast to a short
			BYTE byNewValue = static_cast<BYTE>(ulNewValue);
			// check the conversion did not stop prematurely e.g. on an invalid character
			if ((*pwcStopChar == '\0') && (byNewValue >= m_byLOWER) && (byNewValue <= m_byUPPER)
					&& (pwcDATA[0] != '-')) {
				bValid = true;
			} else {
				QString strTitle("");
				QString strMsg("");
				strTitle = QString::asprintf("User Error");
				strMsg = QString::asprintf("The value entered must be between %u and %u.",
						static_cast<USHORT>(m_byLOWER), static_cast<USHORT>(m_byUPPER));
				CV6MessageBoxDlg kErrDialog(strTitle, strMsg, NULL);
			}
		} else {
			QString strTitle("");
			QString strMsg("");
			strTitle = QString::asprintf("User Error");
			strMsg = QString::asprintf("The value entered must be between %u and %u.", static_cast<USHORT>(m_byLOWER),
					static_cast<USHORT>(m_byUPPER));
			CV6MessageBoxDlg kErrDialog(strTitle, strMsg, NULL);
		}
	}
	return bValid;
}
//****************************************************************************
// const QString   GetDataAsString( const bool bINCLUDE_UNITS /* = false */ )
///
/// Method called to get the data as a string, converted to display units if necessary
///
/// @param[in]		const bool bINCLUDE_UNITS - Flag indicating the untis must be appended to
///					the end of the string
///
/// @returns	The data as a string
//****************************************************************************
const QString CByteData::GetDataAsString(const bool bINCLUDE_UNITS /* = false */) {
	QString strByteData("");
	strByteData = QString::asprintf("%u", *m_pbyData);
	// add the units if necessary
	if (bINCLUDE_UNITS && (m_strUNITS != "")) {
		strByteData += " " + m_strUNITS;
	}
	return strByteData;
}
//added by nilesh for SNTP
//[
//****************************************************************************
// CULongData( ULONG *pulDATA,
//				const ULONG ulLOWER,
//				const ULONG ulUPPER,
//				const int iHELP_ID,
//				const int iDESC_ID,
//				const bool bUPDATE_TREE_ON_CHANGE,
//				const T_CFG_DATA_TYPE eDATA_TYPE,
//				const QString   strUNITS /* = QString   ::fromWCharArray("") */,
//				const bool bREQUIRES_RESTART /* = false */)
///
/// Constructor
///
///	@param[in]			TV_BOOL* pbDATA - Pointer to the actual data
/// @param[in]			const ULONG ulLOWER - the lower limit of this data
/// @param[in]			const ULONG ulUPPER - the upper limit of this data
/// @param[in]			const int iHELP_ID - The resource ID of the assocaited help for
///						this item
/// @param[in]			const int iDESC_ID - The resource ID of the assocaited description for
///						this item
/// @param[in]			const bool bUPDATE_TREE_ON_CHANGE - Flag indicating if this item requires
///						the config tree to be rebuilt when it changes
/// @param[in]			const T_CFG_DATA_TYPE eDATA_TYPE - The data type - colour or ULONG
/// @param[in]			const QString   strUNITS - The units that need to be displayed after the string
/// @param[in]			const bool bREQUIRES_RESTART - Flag indicating if a restart is required after modifying this
///						variable
///
//****************************************************************************
CULongDataForSNTPThreshold::CULongDataForSNTPThreshold(ULONG *pulDATA, const ULONG ulLOWER, const ULONG ulUPPER,
		const int iHELP_ID, const int iDESC_ID, const bool bUPDATE_TREE_ON_CHANGE,
		const T_CFG_DATA_TYPE eDATA_TYPE /* = dtUnsignedLong */,
		const QString strUNITS /* = QString   ::fromWCharArray("") */, const bool bREQUIRES_RESTART /* = false */) : CConfigData(
		eDATA_TYPE, iHELP_ID, iDESC_ID, bUPDATE_TREE_ON_CHANGE, bREQUIRES_RESTART, strUNITS) {
	m_pulData = pulDATA;
	m_ulLower = ulLOWER;
	m_ulUpper = ulUPPER;
}
//****************************************************************************
// ~CULongData(void)
///
/// Destructor
///
//****************************************************************************
CULongDataForSNTPThreshold::~CULongDataForSNTPThreshold(void) {
}
//****************************************************************************
// void UpdateData( )
///
/// Method that updates a an item's associated data
///
//****************************************************************************
void CULongDataForSNTPThreshold::UpdateData(const QString pwcDATA) {
	// convert the string to a number	
	QString pwcStopChar = NULL;
	unsigned long ulNewValue = 0;
	switch (m_eDATA_TYPE) {
	case dtIPAddr:
		ulNewValue = CStringUtils::IPv4StrToPackedIPv4(pwcDATA);
		break;
	case dtColour:
		ulNewValue = wcstoul(pwcDATA, &pwcStopChar, 16);
		ulNewValue = RGBtoRGB888(ulNewValue);
		break;
	case dtDateTime:
	case dtDate:
	case dtTimeOfDay:
	case dtInterval:
	default:
		ulNewValue = wcstoul(pwcDATA, &pwcStopChar, 10);
		break;
	}
	// now setup a pointer to this item
	memcpy(m_pulData, &ulNewValue, sizeof(unsigned long));
}
//****************************************************************************
// bool ValidateData( const WCHAR* const pwcDATA )
///
/// Method called to validate data entered by a user
///
/// @param[in]			const WCHAR* const pwcDATA - Pointer to the data entered
///						by the user
///
/// @returns	True if the data is valid
//****************************************************************************
bool CULongDataForSNTPThreshold::ValidateData(const QString pwcDATA) {
	bool bValid = false;
	// check the string is valid
	if (pwcDATA != NULL) {
		// convert the string to a number	
		QString pwcStopChar = NULL;
		ULONG ulNewValue = wcstoul(pwcDATA, &pwcStopChar, 10);
		// check the value is within a valid short range
		if ((ulNewValue >= 0) && (ulNewValue <= ULONG_MAX)) {
			// okay to cast to a short
			//USHORT usNewValue = static_cast< USHORT >( ulNewValue ); 
			// check the conversion did not stop prematurely e.g. on an invalid character
			if ((*pwcStopChar == '\0') && (ulNewValue >= m_ulLower) && (ulNewValue <= m_ulUpper)
					&& (pwcDATA[0] != '-')) {
				QString strTitle("");
				QString strMsg("");
				if (ulNewValue > 3600) {
					strTitle = QString::asprintf(IDS_Warning_For_SNTP);
					strMsg = QString::asprintf(IDS_Warning_Threshold_For_SNTP);
					CV6MessageBoxDlg kErrDialog(strTitle, strMsg, NULL);
					return bValid = true;
				}
				return bValid = true;
			} else {
				QString strTitle("");
				QString strMsg("");
				strTitle = QString::asprintf("User Error");
				strMsg = QString::asprintf("The value entered must be between %u and %u.", m_ulLower, m_ulUpper);
				CV6MessageBoxDlg kErrDialog(strTitle, strMsg, NULL);
			}
		} else {
			QString strTitle("");
			QString strMsg("");
			strTitle = QString::asprintf("User Error");
			strMsg = QString::asprintf("The value entered must be between %u and %u.", m_ulLower, m_ulUpper);
			CV6MessageBoxDlg kErrDialog(strTitle, strMsg, NULL);
		}
	}
	return bValid;
}
//****************************************************************************
// const QString   GetDataAsString( const bool bINCLUDE_UNITS /* = false */ )
///
/// Method called to get the data as a string, converted to display units if necessary
///
/// @param[in]		const bool bINCLUDE_UNITS - Flag indicating the untis must be appended to
///					the end of the string
///
/// @returns	The data as a string
//****************************************************************************
const QString CULongDataForSNTPThreshold::GetDataAsString(const bool bINCLUDE_UNITS /* = false */) {
	QString strULongData("");
	switch (m_eDATA_TYPE) {
	case dtIPAddr:
		// must be an IP address
		strULongData = CStringUtils::PackedIPv4ULongToStr(*m_pulData);
		break;
	case dtColour: {
		ULONG ulCol = *m_pulData;
		strULongData = QString::asprintf("%c%u%c%c", g_wcMOD_COLOUR, ulCol, g_wcMOD_COLOUR, g_wcSMALLSQUARE);
	}
		break;
	case dtDateTime: {
		// convert the ulong into a valid date/time string
		quint64 ullDateTime = *m_pulData;
		ullDateTime *= 1000000;
		QTime kTime(ullDateTime);
		kTime.ShortTimeAsString(strULongData);
		// now add the date
		QString strDate("");
		kTime.DateAsString(strDate);
		strULongData += " " + strDate;
	}
		break;
	case dtTimeOfDay: {
		// convert the ulong into a valid date/time string but only return the time portion
		QTime kTime(static_cast<_int64>(*m_pulData) * 1000000);
		kTime.ShortTimeAsString(strULongData);
	}
		break;
	case dtDate: {
		// convert the ulong into a valid date string
		quint64 ullDateTime = *m_pulData;
		ullDateTime *= 1000000;
		QTime kTime(ullDateTime);
		// now retrieve the date
		kTime.DateAsString(strULongData);
	}
		break;
	case dtInterval: {
		// check it is greater than 1 second
		if (*m_pulData == 0) {
			// default to 1 second
			*m_pulData = 1;
		}
		// convert the value into hour mins seconds etc
		strULongData = CStringUtils::GetAutoDDHHMMSSspanFromSeconds(*m_pulData);
	}
		break;
	default:
		strULongData = QString::asprintf("%u", *m_pulData);
		// not a colour or IP address so add the units if necessary
		if (bINCLUDE_UNITS && (m_strUNITS != "")) {
			strULongData += " " + m_strUNITS;
		}
		break;
	}
	return strULongData;
}
//****************************************************************************
// const USHORT GetDataLength()
///
/// Method that returns the maximum allowable length of the data as a string
///
/// @return		The max length of the data as a string
///
//****************************************************************************
const USHORT CULongDataForSNTPThreshold::GetDataLength() const {
	USHORT usMaxStrLen = 0;
	if (m_eDATA_TYPE == dtIPAddr) {
		usMaxStrLen = 15;
	} else if (m_eDATA_TYPE == dtColour) {
		usMaxStrLen = 6;
	} else {
		usMaxStrLen = g_usMAX_LONG_STR_LEN;
	}
	return usMaxStrLen;
}
//****************************************************************************
// CUShortDataforSNTPUpdatePeriod(	USHORT *pusDATA,
//					const USHORT usLOWER,
//					const USHORT usUPPER,
//					const int iHELP_ID,
//					const int iDESC_ID,
//					const bool bUPDATE_TREE_ON_CHANGE,
//					const QString   strUNITS /* = QString   ::fromWCharArray("") */,
//					const bool bREQUIRES_RESTART /* = false */ )
///
/// Constructor
///
///	@param[in]			TV_BOOL* pbDATA - Pointer to the actual data
///	@param[in]			const USHORT usLOWER - The lower limit of this data
///	@param[in]			const USHORT usUPPER - The upper limit of this data
/// @param[in]			const int iHELP_ID - The resource ID of the assocaited help for
///						this item
/// @param[in]			const int iDESC_ID - The resource ID of the associated description for
///						this item
/// @param[in]			const bool bUPDATE_TREE_ON_CHANGE - Flag indicating if this item requires
///						the config tree to be rebuilt when it changes
/// @param[in]			const QString   strUNITS - The units that need to be displayed after the string
/// @param[in]			const bool bREQUIRES_RESTART - Flag indicating if a restart is required after modifying this
///						variable
///
//****************************************************************************
CUShortDataForSNTPUpdatePeriod::CUShortDataForSNTPUpdatePeriod(USHORT *pusDATA, const USHORT usLOWER,
		const USHORT usUPPER, const int iHELP_ID, const int iDESC_ID, const bool bUPDATE_TREE_ON_CHANGE,
		const T_CFG_DATA_TYPE eDATA_TYPE /* = dtUnsignedShort */,
		const QString strUNITS /* = QString   ::fromWCharArray("") */, const bool bREQUIRES_RESTART /* = false */) : CConfigData(
		eDATA_TYPE, iHELP_ID, iDESC_ID, bUPDATE_TREE_ON_CHANGE, bREQUIRES_RESTART, strUNITS) {
	m_pusData = pusDATA;
	/// the upper and lower limits required to validate a USHORT
	m_usLower = usLOWER;
	m_usUpper = usUPPER;
}
//****************************************************************************
// ~CUShortDataforSNTPThreshold(void)
///
/// Destructor
///
//****************************************************************************
CUShortDataForSNTPUpdatePeriod::~CUShortDataForSNTPUpdatePeriod(void) {
}
//]
bool CUShortDataForSNTPUpdatePeriod::ValidateData(const QString pwcDATA) {
	bool bValid = false;
	// check the string is valid
	if (pwcDATA != NULL) {
		// convert the string to a number	
		QString pwcStopChar = NULL;
		ULONG ulNewValue = wcstoul(pwcDATA, &pwcStopChar, 10);
		// check the value is within a valid short range
		if ((ulNewValue >= 0) && (ulNewValue <= USHRT_MAX)) {
			// okay to cast to a short
			USHORT usNewValue = static_cast<USHORT>(ulNewValue);
			// check the conversion did not stop prematurely e.g. on an invalid character
			if ((*pwcStopChar == '\0') && (usNewValue >= m_usLower) && (usNewValue <= m_usUpper)
					&& (pwcDATA[0] != '-')) {
				QString strTitle("");
				QString strMsg("");
				if (usNewValue < 600) {
					strTitle = QString::asprintf(IDS_Warning_For_SNTP);
					strMsg = QString::asprintf(IDS_Warning_Period_For_SNTP);
					CV6MessageBoxDlg kErrDialog(strTitle, strMsg, NULL);
					return bValid = true;
				}
				return bValid = true;
			}
			else {
				QString strTitle("");
				QString strMsg("");
				strTitle = QString::asprintf("User Error");
				strMsg = QString::asprintf("The value entered must be between %u and %u.", m_usLower, m_usUpper);
				CV6MessageBoxDlg kErrDialog(strTitle, strMsg, NULL);
			}
		} else {
			QString strTitle("");
			QString strMsg("");
			strTitle = QString::asprintf("User Error");
			strMsg = QString::asprintf("The value entered must be between %u and %u.", m_usLower, m_usUpper);
			CV6MessageBoxDlg kErrDialog(strTitle, strMsg, NULL);
		}
	}
	return bValid;
}
//****************************************************************************
// void UpdateData( )
///
/// Method that updates an item's associated data
///
//****************************************************************************
void CUShortDataForSNTPUpdatePeriod::UpdateData(const QString pwcDATA) {
	// convert the string to a number	
	QString pwcStopChar = NULL;
	USHORT usNewValue = 0;
	if ((m_eDATA_TYPE == dtUnsignedShort) || (m_eDATA_TYPE == dtBrightness)) {
		usNewValue = static_cast<USHORT>(wcstoul(pwcDATA, &pwcStopChar, 10));
	} else {
		// color is displayed as 32 bit and converted to 16 bit
		ULONG ulCol = 0;
		ulCol = wcstoul(pwcDATA, &pwcStopChar, 16);
		ulCol = RGBtoRGB888(ulCol);
		usNewValue = RGBtoRGB565(ulCol);
	}
	// now setup a pointer to this item
	memcpy(m_pusData, &usNewValue, sizeof(USHORT));
}
//****************************************************************************
// const bool ShowSlider( const QString   &rstrTITLE, CWidget *pkWnd )
///
/// Method that shows the brightness slider and allows the user to adjust it
///
//****************************************************************************
const bool CUShortDataForSNTPUpdatePeriod::ShowSlider(const QString &rstrTITLE, CWidget *pkWnd) {
	bool bUpdate = false;
#ifndef TTR6SETUP
	CCfgBrightnessDlg kBrightnessEditor(rstrTITLE, *m_pusData, m_usLower, m_usUpper, pkWnd);
	if (kBrightnessEditor.exec() == IDOK) {
		// get the brightness set by the user
		*m_pusData = kBrightnessEditor.GetScreenBrightess();
		bUpdate = true;
	}
	// restore the stored modifiable brightness
	T_PRECPROFILE ptModifiableProfile = pSETUP->GetGeneralSetupConfig()->GetProfileBlock(CONFIG_MODIFIABLE);
	pDALGLB->SetScreenBrightness(ptModifiableProfile->ScreenSaver.NormalBright);
#endif
	return bUpdate;
}
//****************************************************************************
// const QString   GetDataAsString( const bool bINCLUDE_UNITS /* = false */ )
///
/// Method called to get the data as a string, converted to display units if necessary
///
/// @param[in]		const bool bINCLUDE_UNITS - Flag indicating the untis must be appended to
///					the end of the string
///
/// @returns	The data as a string
//****************************************************************************
const QString CUShortDataForSNTPUpdatePeriod::GetDataAsString(const bool bINCLUDE_UNITS /* = false */) {
	QString strUShortData("");
	if ((m_eDATA_TYPE == dtUnsignedShort) || (m_eDATA_TYPE == dtBrightness)) {
		strUShortData = QString::asprintf("%u", *m_pusData);
		// not a colour so add the units if necessary
		if (bINCLUDE_UNITS && (m_strUNITS != "")) {
			strUShortData += " " + m_strUNITS;
		}
	} else {
		ULONG ulCol = *m_pusData;
		ulCol = RGB565toRGB(ulCol);
		strUShortData = QString::asprintf("%c%u%c%c", g_wcMOD_COLOUR, ulCol, g_wcMOD_COLOUR, g_wcSMALLSQUARE);
	}
	return strUShortData;
}
//]

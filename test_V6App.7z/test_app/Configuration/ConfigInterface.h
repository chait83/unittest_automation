/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Configuration System
/// @n Filename:  ConfigInterface.h
/// @n Description: Definition of the CConfigInterface class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  11  Stability Project 1.8.1.1 7/2/2011 4:56:16 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  10  Stability Project 1.8.1.0 7/1/2011 4:28:13 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  9 V6 Firmware 1.8 12/20/2006 3:39:03 PM  Roger Dawson  
//  Phase 3b merges into the main build. Attempted to reduce memory usage
//  by making the key create itself dynamically rather than store the
//  entire key all the time.
//  8 V6 Firmware 1.7 9/8/2006 12:55:40 PM  Roger Dawson  
//  Added code that makes all child config items 'enabled' state
//  dependant on their parent's enabled state also. This helps TMP where
//  it is possible to see the sub-menu item's for a disabled branch (e.g.
//  pen disabled but still posibble to view logging details). 
// $
//
// **************************************************************************
#pragma once
#include "Defines.h"
#include "ConfigSystemData.h"
//**CConfigInterface*********************************************************************
///
/// @brief	This is a virtual base class that provides the base information required for
///			the branches and leaves within a configuration hierarchy.
/// 
/// This is a virtual base class that provides the base information required for
///	the branches and leaves within a configuration hierarchy. It should not be instantiated
/// directly. This class contains base information common to ConfigBranches and CConfigItems
/// such as the Key, a title. These inherited classes will be used by GUI's to create a menu
/// interfaces and their associated items ( e.g. buttons, comboboxes ) or to populate editors 
/// that allows the items associated data to be modfied. Also refer to the CConfigItem and 
/// CConfigBranch classes for a broader view of how these classes are designed to operate.
///
//****************************************************************************
class CConfigInterface {
public:
	virtual ~CConfigInterface(void);
	// Delimiter used to seperate the individual KEYS or items within a list
	static const WCHAR ms_wcDELIMITER;
	// Global ENABLED flag to make properties read-only on a standard screen
	static BOOL ms_bENABLED;
	// Accessor Methods
	const T_CFG_INTERFACE_TYPE_ENUM GetCfgInterfaceType() const {
		return m_eCONFIG_INTERFACE_TYPE;
	}
	const QString GetKey() const;
	const ControlType GetControlType() const {
		return m_eCONTROL_TYPE;
	}
	const QString GetTitle() const {
		return m_strTITLE;
	}
	const QString GetSubTitle() const {
		return m_strSubTitle;
	}
	CConfigInterface* GetParent() const {
		return m_pkParent;
	}
	bool GetEnabled() const {
		return m_bEnabled && ((m_pkParent == NULL) || (m_pkParent->GetEnabled()));
	}
	bool GetLocked() const {
		return m_bLocked;
	}
	void SetSubTitle(const QString &rstrSUB_TITLE) {
		m_strSubTitle = rstrSUB_TITLE;
	}
protected:
	// Constructor
	CConfigInterface(const QString &rstrKEY, const QString &rstrTITLE, const QString &rstrSUB_TITLE,
			const ControlType eCONTROL_TYPE, const bool bMODIFIED, const bool bENABLED, const long lHELP_ID,
			const bool bLOCKED, CConfigInterface *const pkPARENT, const T_CFG_INTERFACE_TYPE_ENUM eCFG_TYPE);
	/// Enumerated variable indicating the type of the inherited class
	const T_CFG_INTERFACE_TYPE_ENUM m_eCONFIG_INTERFACE_TYPE;
	/// Enumerated variable reflecting the required control type e.g. button, list control etc
	const ControlType m_eCONTROL_TYPE;
	/// String containing the title to be displayed on the control
	const QString m_strTITLE;
	/// String containing the subtitle/summary to be displayed on the control
	QString m_strSubTitle;
private:
	/// Unique string identifying the data item type - includes parent Keys delimited by '|'
	const QString m_strKEY;
	/// A flag indicating if the variable has been modified but not applied
	bool m_bModified;
	/// A flag indicating if the control should be enabled or disabled
	bool m_bEnabled;
	/// A flag indicating if the variable is locked - this is usually when another UI is
	/// already editing the data and we are only allowed to view it
	bool m_bLocked;
	/// Pointer to the parent CConfigInterface class of tihs item - this will be NULL for the highest
	/// item in the heirarchy e.g. Pens or Alarms
	CConfigInterface *m_pkParent;
};

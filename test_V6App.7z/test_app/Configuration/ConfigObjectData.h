/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Configuration System
/// @n Filename:  ConfigObjectData.h
/// @n Description: Definition for the CConfigObjectData class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  9 Stability Project 1.6.1.1 7/2/2011 4:56:17 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  8 Stability Project 1.6.1.0 7/1/2011 4:28:11 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  7 V6 Firmware 1.6 1/6/2006 8:19:07 PM Roger Dawson  
//  Fixed user defined analogue range issues.
//  6 V6 Firmware 1.5 10/11/2005 2:11:48 PM  Tony Maycock  
//  #ifndef TTR6SETUP directives removed from files
// $
//
// **************************************************************************
#pragma once
#include "ConfigData.h"
class CWidget;
//**CConfigObjectData*********************************************************************
///
/// @brief Class containing information on screen designer object config data items
/// 
/// Class containing information on screen designer object config data items
///
//****************************************************************************
class CConfigObjectData: public CConfigData {
public:
	// Constructor
	CConfigObjectData(T_BASEOBJECT *ptObject, CWidget *pkWidget, const int iHELP_ID, const int iDESC_ID,
			const bool bUPDATE_TREE_ON_CHANGE, const T_CFG_DATA_TYPE eDATA_TYPE);
	// Destructor
	~CConfigObjectData(void);
	// Method called to validate data entered by a user
	bool ValidateData(const QString pwcDATA) {
		return true;
	}
	// Method that updates the data based on the passed in string
	void UpdateData(const QString pwcDATA);
	// Method that gets the data as a string - used for the subtitle information
	const QString GetDataAsString(const bool bINCLUDE_UNITS = false);
	// Method that gets the type name of an objects current channel configuration
	static const QString GetTypeName(const USHORT usTYPE, const USHORT usSUB_TYPE);
	// Method that gets the subtype name of an objects current channel configuration
	const QString GetSubTypeName(const USHORT usTYPE, const USHORT usSUB_TYPE);
	// Method that returns the objects name
	const QString GetObjectName();
	// Accessor Methods
	T_BASEOBJECT* GetBaseObject() {
		return m_ptBaseObject;
	}
	CWidget* GetWidget() {
		return m_pkWidget;
	}
private:
	/// Pointer to the base object data stored in the CMM
	T_BASEOBJECT *m_ptBaseObject;
	/// Pointer to the widget c++ object 
	CWidget *m_pkWidget;
};

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Configuration System
/// @n Filename:  CannedScrnData.cpp
/// @n Description: Implementation for the CCannedScrnData class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  30-Oct-14 Rajanbabu M  Fixed PAR:1-3KZWBIH-Load custom screen is not working in Multi and DRG2 Recorders
//  12  Stability Project 1.7.1.3 7/2/2011 4:55:52 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  11  Stability Project 1.7.1.2 7/1/2011 4:38:01 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  10  Stability Project 1.7.1.1 3/17/2011 3:20:12 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  9 Stability Project 1.7.1.0 2/15/2011 3:02:21 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// **************************************************************************
#include "V6globals.h"
#include "CannedScrnData.h"
#include "LayoutConfiguration.h"
#ifdef DOCVIEW
#include "EngWB.h"
#endif
// Static Initialisation
const USHORT CCannedScrnData::ms_usMAX_MINI_DPMS_PENS = 8;
const USHORT CCannedScrnData::ms_usMAX_MULTI_DPMS_PENS = 32;
const USHORT CCannedScrnData::ms_usMAX_MINI_DPMS_BARS = 8;
const USHORT CCannedScrnData::ms_usMAX_MULTI_DPMS_BARS = 16;
const USHORT CCannedScrnData::ms_usMAX_MINI_CHRT_DPMS = 8;
const USHORT CCannedScrnData::ms_usMAX_MULTI_CHRT_DPMS = 12;
const USHORT CCannedScrnData::ms_usMAX_CIRC_CHRT_DPMS = 8;
const USHORT CCannedScrnData::ms_usMAX_MINI_CHRT_BARS = 8;
const USHORT CCannedScrnData::ms_usMAX_MULTI_CHRT_BARS = 12;
const USHORT CCannedScrnData::ms_usMAX_MINI_CHRT_DPMS_BARS = 8;
const USHORT CCannedScrnData::ms_usMAX_MULTI_CHRT_DPMS_BARS = 12;
const USHORT CCannedScrnData::ms_usMAX_MINI_TABULAR_PENS = 18;
const USHORT CCannedScrnData::ms_usMAX_MULTI_TABULAR_PENS = SCREEN_CANNEDPENS_SIZE;
// E527303[
const USHORT CCannedScrnData::ms_usMAX_MINI_REPLAY_PENS = 8;
const USHORT CCannedScrnData::ms_usMAX_MULTI_REPLAY_PENS = 18;
//]
//pen count
const USHORT CCannedScrnData::ms_usMAX_MINI_NP_PENS = 16;
const USHORT CCannedScrnData::ms_usMAX_MULTI_NP_PENS = 24; //PAR 1-2KZJUXO: change from 32 to 24. Non process screen can only show 24 buttons and no need to allow user to configure more than 24 buttons.
const USHORT CCannedScrnData::ms_usMAX_MINI_NP_USERVARIABLE_PENS = 16;
const USHORT CCannedScrnData::ms_usMAX_MULTI_NP_USERVARIABLE_PENS = 24;
//****************************************************************************
// CCannedScrnData(	T_CANNEDPENS *pData,
//						const T_TEMPLATE_TYPE eTEMPLATE_TYPE,
//						const int iHELP_ID,
//						const int iDESC_ID,
//						const bool bUPDATE_TREE_ON_CHANGE )
///
/// Constructor
///
/// @param[in]			const T_CANNEDPENS pDATA - Pointer to the CMM canned screen config data
/// @param[in]			const T_CFG_DATA_TYPE eCFGDATA_TYPE - The config data type
///	@param[in]			const T_TEMPLATE_TYPE eTEMPLATE_TYPE - The type of canned screen template
///						currently selected
/// @param[in]			const int iHELP_ID - The resource ID of the associated help for
///						this item
/// @param[in]			const int iDESC_ID - The resource ID of the assocaited description for
///						this item
/// @param[in]			const bool bUPDATE_TREE_ON_CHANGE - Flag indicating if this item requires
///						the config tree to be rebuilt when it changes
///
//****************************************************************************
CCannedScrnData::CCannedScrnData(T_CANNEDPENS *pData, const T_CFG_DATA_TYPE eCFGDATA_TYPE,
		const T_TEMPLATE_TYPE eTEMPLATE_TYPE, const int iHELP_ID, const int iDESC_ID, const bool bUPDATE_TREE_ON_CHANGE) : CConfigData(
		eCFGDATA_TYPE, iHELP_ID, iDESC_ID, bUPDATE_TREE_ON_CHANGE), m_pCannedScreenData(pData), m_eTEMPLATE_TYPE(
		eTEMPLATE_TYPE) {
}
//****************************************************************************
// ~CCannedScrnData()
///
/// Destructor
///
//****************************************************************************
CCannedScrnData::~CCannedScrnData() {
	m_pCannedScreenData = NULL;
}
//****************************************************************************
// const QString   GetDataAsString( )
///
/// Method called to get the data as a string
///
/// @param[in]		const bool bDataForReplayMode - Flag indicating that the
///					data requested for Canned Pen Slection or Replay Pen Selection
///
/// @return	The data as a string
///
//****************************************************************************
const QString CCannedScrnData::GetDataAsString(const bool bDataForReplayMode /* = false */) {
	QString strCannedScrnData("");
	QString strPenNumber("");
	USHORT usTempVal = 0;
	// use this map to make sure we don't show duplicate instances
	QMap<USHORT, USHORT> kPenExistsMap;
	kPenExistsMap.InitHashTable( SCREEN_CANNEDPENS_SIZE);
	USHORT usMaxPenCount = GetMaxPenCount(m_eTEMPLATE_TYPE);
	// E527303[
	if (bDataForReplayMode == TRUE) {
		usMaxPenCount = GetMaxReplayPenCount();
	}
	//]
	for (USHORT usPenCount = 0; usPenCount < usMaxPenCount; usPenCount++) {
		// check if the screen pen number is initialised
		if (m_pCannedScreenData[usPenCount].PenIndex != CScreen::ms_usUNINITIALISED_INSTANCE) {
			// E527303[
			// If Replay pen data required
			if (bDataForReplayMode == TRUE) {
				// check this pen has not already been added
				if (kPenExistsMap.Lookup(m_pCannedScreenData[usPenCount].PenIndex, usTempVal) == 0) {
					// get the pen number and add it to our string - make the number one based
					strPenNumber = QString::asprintf("%u, ", m_pCannedScreenData[usPenCount].PenIndex + 1);
					strCannedScrnData += strPenNumber;
					// add it to our map
					kPenExistsMap[m_pCannedScreenData[usPenCount].PenIndex] = 0;
				}
			}			//]
			else {
				// check this pen has not already been added
				if (kPenExistsMap.Lookup(m_pCannedScreenData[usPenCount].PenIndex, usTempVal) == 0) {
					// get the pen number and add it to our string - make the number one based
					strPenNumber = QString::asprintf("%u, ", m_pCannedScreenData[usPenCount].PenIndex + 1);
					strCannedScrnData += strPenNumber;
					// add it to our map
					kPenExistsMap[m_pCannedScreenData[usPenCount].PenIndex] = 0;
				}
			}
		}
	}
	// check we found at least one pen
	if (strCannedScrnData == "") {
		T_TEMPLATE_TYPE tmpl = GetTemplateType();
		// E527303[
		if (tmpl >= TPL_LAST_CANNED && (tmpl < TPL_ALARM || tmpl > TPL_NP_LAST)) {
			// the string is empty so we need to insert the "All" string
			strCannedScrnData = QWidget::tr("All");
		}			//]
		else {
			// the string is empty so we need to insert the "None" string
			strCannedScrnData = QWidget::tr("None");
		}
	} else {
		// some data has been added so remove the last two characters
		strCannedScrnData.remove(strCannedScrnData.size() - 2, 2);
	}
	return strCannedScrnData;
}
//****************************************************************************
// const USHORT GetMaxPenCount( const T_TEMPLATE_TYPE eTEMPLATE_TYPE )
///
/// Method called to get the data as a string
///
/// @param[in]		 const T_TEMPLATE_TYPE eTEMPLATE_TYPE - The canned screen template type
///
/// @return	The max number of pens for the curent device and template type
///
//****************************************************************************
const USHORT CCannedScrnData::GetMaxPenCount(const T_TEMPLATE_TYPE eTEMPLATE_TYPE) {
	USHORT usMaxPenCount = 0;
	bool bMultiTrend = false;
	T_DEV_TYPE devType = pDEVICE_INFO->GetDeviceType();
	// check if this is a minitrend 
	if (devType == DEV_ARISTOS_MULTIPLUS || devType == DEV_PC_MULTI || devType == DEV_SCR_MINITREND) {
		bMultiTrend = true;
	} else if (devType == DEV_PC_SCREEN_DESIGNER) {
#ifdef DOCVIEW
		CEngWBDoc* pDoc = theApp.GetActiveDocument();
		COpPanelDVDoc *pkDoc = (COpPanelDVDoc*)pDoc;
		//If we Open the layout files having circular screen in SD, It will crash.
		if(pkDoc != NULL)
		{
			if( pkDoc->lc->GetRecorderType() == DEV_ARISTOS_MINITREND )
			{
				bMultiTrend = false;
			}
			else
			{
				bMultiTrend = true;
			}
		}
		#endif
	}
	switch (eTEMPLATE_TYPE) {
	case TPL_DPMS:
		usMaxPenCount = bMultiTrend ? ms_usMAX_MULTI_DPMS_PENS : ms_usMAX_MINI_DPMS_PENS;
		break;
	case TPL_DPMS_BARS:
		usMaxPenCount = bMultiTrend ? ms_usMAX_MULTI_DPMS_BARS : ms_usMAX_MINI_DPMS_BARS;
		break;
	case TPL_CHRT_DPMS:
		usMaxPenCount = bMultiTrend ? ms_usMAX_MULTI_CHRT_DPMS : ms_usMAX_MINI_CHRT_DPMS;
		break;
	case TPL_CIRC_CHRT_DPMS:
		usMaxPenCount = ms_usMAX_CIRC_CHRT_DPMS;
		break;
	case TPL_CHRT_BARS:
		usMaxPenCount = bMultiTrend ? ms_usMAX_MULTI_CHRT_BARS : ms_usMAX_MINI_CHRT_BARS;
		break;
	case TPL_CHRT_DPMS_BARS:
	case TPL_AMS2750_PROCESS_SCREEN:
		usMaxPenCount = bMultiTrend ? ms_usMAX_MULTI_CHRT_DPMS_BARS : ms_usMAX_MINI_CHRT_DPMS_BARS;
		break;
	case TPL_TABULAR_SCREEN:
		usMaxPenCount = bMultiTrend ? ms_usMAX_MULTI_TABULAR_PENS : ms_usMAX_MINI_TABULAR_PENS;
		break;
		// E527303[
	case TPL_LAST_CANNED:
		usMaxPenCount = bMultiTrend ? ms_usMAX_MULTI_REPLAY_PENS : ms_usMAX_MINI_REPLAY_PENS;
		break;
		//]
	case TPL_ALARM:
	case TPL_MAXMIN:
	case TPL_SCRIPT_TIMERS:
		usMaxPenCount = bMultiTrend ? ms_usMAX_MULTI_NP_PENS : ms_usMAX_MINI_NP_PENS;
		break;
		//For User variables screen , only max of 24 for MULTI and max of 16 for MINI should be there.
	case TPL_USER_VARS:
		usMaxPenCount = bMultiTrend ? ms_usMAX_MULTI_NP_USERVARIABLE_PENS : ms_usMAX_MINI_NP_USERVARIABLE_PENS;
		break;
	default:
		break;
	}
	return usMaxPenCount;
}
// E527303[
//****************************************************************************
// const USHORT GetMaxReplayPenCount( const T_TEMPLATE_TYPE eTEMPLATE_TYPE )
///
/// Method that returns the maximum replay pen count based on the current recorder type
///
///
/// @return	The max number of pens for the curent device and template type
///
//****************************************************************************
const USHORT CCannedScrnData::GetMaxReplayPenCount() {
	USHORT usMaxPenCount = 0;
	BOOL bMultiTrend = false;
	T_DEV_TYPE devType = pDEVICE_INFO->GetDeviceType();
	if (devType == DEV_ARISTOS_MULTIPLUS || devType == DEV_PC_MULTI || devType == DEV_SCR_MINITREND) {
		bMultiTrend = true;
	} else if (devType == DEV_PC_SCREEN_DESIGNER) {
#ifdef DOCVIEW
		CEngWBDoc* pDoc = theApp.GetActiveDocument();
		COpPanelDVDoc *pkDoc = (COpPanelDVDoc*)pDoc;
		if(pkDoc != NULL)
		{
			if( pkDoc->lc->GetRecorderType() == DEV_ARISTOS_MINITREND )
			{
				bMultiTrend = false;
			}
			else
			{
				bMultiTrend = true;
			}
		}
		#endif
	}
	usMaxPenCount = bMultiTrend ? ms_usMAX_MULTI_REPLAY_PENS : ms_usMAX_MINI_REPLAY_PENS;
	return usMaxPenCount;
}			//]

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Configuration System
/// @n Filename:  AddScreenData.h
/// @n Description: Definition for the CAddScreenData class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  4 Stability Project 1.1.1.1 7/2/2011 4:55:13 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  3 Stability Project 1.1.1.0 7/1/2011 4:28:10 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  2 V6 Firmware 1.1 1/9/2006 4:07:23 PM Roger Dawson  
//  Fixed screen designer problem caused by incorrect overriodden method
//  definition. Made base method purely virtual to avoid this situation
//  arising again.
//  1 V6 Firmware 1.0 9/27/2005 8:07:42 PM  Roger Dawson  
// $
//
// **************************************************************************
#if !defined(AFX_ADDSCREENDATA_H__A9601297_4899_4C9A_986E_C1FBA47BFA5B__INCLUDED_)
#define AFX_ADDSCREENDATA_H__A9601297_4899_4C9A_986E_C1FBA47BFA5B__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "ConfigData.h"
//**CConfigObjectData*********************************************************************
///
/// @brief Class that inserts a new screen into the screen list when selected by the user
/// 
/// Class that inserts a new screen into the screen list when selected by the user
///
//****************************************************************************
class CAddScreenData: public CConfigData {
public:
	// Constructor
	CAddScreenData(const int iHELP_ID, const int iDESC_ID);
	// Destructor
	virtual ~CAddScreenData();
	// Method that returns a pointer to the data
	void* GetData() const {
		return NULL;
	}
	// Method that returns the data as a string
	const QString GetDataAsString(const bool bINCLUDE_UNITS = false);
	// Method that updates the data e.g. a new screen is added to the layout 
	void UpdateData(CConfigInterface *pkThisItem);
private:
};
#endif // !defined(AFX_ADDSCREENDATA_H__A9601297_4899_4C9A_986E_C1FBA47BFA5B__INCLUDED_)

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  CProductionInterface 
/// @n Filename:  CProductionInterface.h
/// @n Description: Sets the of Production Information
///
// **************************************************************************
// Revision History
// **************************************************************************
#if !defined(AFX_FILETRANSFER_SERVICE_H__DEAC64AC_C034_4162_9C57_5C75CBEDE2BB__INCLUDED_)
#define AFX_FILETRANSFER_SERVICE_H__DEAC64AC_C034_4162_9C57_5C75CBEDE2BB__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
//#include "CEFileTransferSocket.h"
//#include "HTDataLink.h"
#include "CStorage.h"
class CFileTransferService {
public:
	CFileTransferService();
	~CFileTransferService();
	BOOL Start();
	BOOL Stop();
private:
	//CHTDataLink* m_pHTDataLink;
};
#endif //FILETRANSFER_SERVICE_H

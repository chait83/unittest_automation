/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  FileTransfer 
/// @n Filename:  HtDataCommand.cpp
/// @n Description: This file has the command hierarchy for HTDATA Commands
///
// **************************************************************************
// Revision History
// Shankar Rao P 16/Sep/2019 Initial Draft of HtData Commands and cmd structures
// **************************************************************************
#include "HtDataCommand.h"
#include "HtDataTransferEngine.h"
const USHORT CHtDataCmd::m_usCmdPckSize = sizeof(UHtdCmdGenericPkt);
const ULONG CHtDataCmd::m_ulCmdExpiryInMilliSeconds = 320000; //30000; //MILLI SECONDS time for any command
///**********Ht Data Cmd Base implementation **************////
CHtDataCmd::CHtDataCmd(EHtdCmdType eCmdType, ECmdDisha eCmdDisha) : m_eCmdType(eCmdType), m_eCmdDisha(eCmdDisha), m_eCmdState(
		CMD_ST_IDLE), m_eCmdRespStatus(CMD_RESP_ST_WAIT), m_pFile(NULL), m_cmdTimer(TIMER_NORMAL_RES)
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
, m_pDebugFileLogger(NULL)
#endif
{
	m_cmdTimer.StopTimer();
}
CHtDataCmd::~CHtDataCmd() {
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	if (m_pDebugFileLogger != NULL)
	{
		m_pDebugFileLogger = NULL;
	}
#endif
}
BOOL CHtDataCmd::ProcessRespCmd(CHtDataCmd *pRespCmd) {
	BOOL bRet = FALSE;
	if (NULL != pRespCmd) {
		//Refresh the Timer 
		RefreshTimer();
		//Begin incoming resp cmd
		bRet = pRespCmd->Begin();
	}
	return bRet;
}
BOOL CHtDataCmd::IsCompleted() {
	if ((CMD_ST_END == m_eCmdState) || (CMD_ST_REJECTED == m_eCmdState)) {
		return TRUE;
	}
	return FALSE;
}
BOOL CHtDataCmd::IsExpired() {
	BOOL bRet = FALSE;
	if (CMD_ST_EXPIRED == m_eCmdState) {
		bRet = TRUE;
	} else {
		quint64 ulExxpiredMilliSeconds = m_cmdTimer.ElapsedTimeInMilliSeconds();
		if (m_ulCmdExpiryInMilliSeconds < ulExxpiredMilliSeconds) {
			//Set Expired state
			m_eCmdState = CMD_ST_EXPIRED;
			bRet = TRUE;
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
			QString   strDbgMsg;
			strDbgMsg = QString::asprintf(_T("HtdCmd::IsExpired CMD type %d m_eCmdState %d ulExxpiredMilliSeconds %llu"), GetCmdType(), m_eCmdState, ulExxpiredMilliSeconds);
			LogDebugMessage(strDbgMsg);
			#endif
		}
	}
	return bRet;
}
BOOL CHtDataCmd::Begin() {
	BOOL bRet = FALSE;
	//Start the timer.
	m_cmdTimer.StartTimer();
	//Validate parameters
	if ( TRUE == Validate()) {
		//Start execution
		bRet = Execute();
	} else {
		Abort();
	}
	return bRet;
}
void CHtDataCmd::Abort() {
	End(CMD_ST_REJECTED);
	m_cmdTimer.StopTimer();
}
void CHtDataCmd::End() {
	End(CMD_ST_END);
	m_cmdTimer.StopTimer();
}
BOOL CHtDataCmd::End(ECmdState eCmdState) {
	BOOL bRet = TRUE;
	m_eCmdState = eCmdState;
	return bRet;
}
bool CHtDataCmd::Validate() {
	return true;
}
BOOL CHtDataCmd::PrepareHdr(UHtdCmdHeader *pCmdHeader) {
	BOOL bRet = TRUE;
	if (NULL != pCmdHeader) {
		pCmdHeader->sCmdHeader.byAppId = 1;
		pCmdHeader->sCmdHeader.byHtdCmdType = m_eCmdType;
		pCmdHeader->sCmdHeader.byExpectedRespType = 0;
		pCmdHeader->sCmdHeader.byEOT = 1;
		if (CMD_DISHA_OUTGOING == m_eCmdDisha) {
			pCmdHeader->sCmdHeader.uCmdPcktLen.ulLen = GetCmdPktLen();
		}
	}
	return bRet;
}
int CHtDataCmd::Send(CCESecureSocket *pSock) {
	int nByteSent = QAbstractSocket_ERROR;
	if (NULL != pSock) {
		if ( TRUE == Validate()) {
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
			QString   strDbgMsg;
			strDbgMsg = QString::asprintf(_T("HtdCmd::Send BEGIN CMD type %d m_eCmdState %d"), GetCmdType(), m_eCmdState);
			LogDebugMessage(strDbgMsg);
			#endif
			if ( TRUE == PrepareHdr(GetCmdHeader())) {
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
				strDbgMsg = QString::asprintf(_T("HtdCmd::Sending nByteSent %d"), GetCmdPktLen());
				LogDebugMessage(strDbgMsg);
#endif
				nByteSent = pSock->Send((char*) GetCmdPktBytes(), GetCmdPktLen());
			}
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
			strDbgMsg = QString::asprintf(_T("HtdCmd::Send END CMD type %d m_eCmdState %d nByteSent %d"), GetCmdType(), m_eCmdState, nByteSent);
			LogDebugMessage(strDbgMsg);
			#endif
		}
	}
	return nByteSent;
}
BOOL CHtDataCmd::WaitAndGetAck() {
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	QString   strDbgMsg;
	strDbgMsg = QString::asprintf(_T("FTS::WaitAndGetAck BEGIN CMD type %d m_eCmdState %d"), GetCmdType(), m_eCmdState);
	LogDebugMessage(strDbgMsg);
#endif
	BOOL bRet = FALSE;
	DWORD dwBaseWaitTimeInMs = 2000;
	DWORD dwRetryCnt = 1;
	while (dwRetryCnt < 4) {
		//Wait for the ACK from the recipent ..instead of sleep t synchronize the packet chunks				
		if ( TRUE == WaitForCmdResp(dwBaseWaitTimeInMs)) {
			if (CMD_RESP_ST_ACK == getCmdRespStatus()) {
				bRet = TRUE;
			}
			//Todo: handle NACK
			break;
		} else {
			//Todo::handle timeouts
			if (CMD_RESP_ST_TIMEOUT == getCmdRespStatus()) {
				dwRetryCnt++;
				dwBaseWaitTimeInMs *= dwRetryCnt;
				//need any retries?
			} else {
				//For now leave it to the END state wchich can be a 
				bRet = FALSE;
				break;
			}
		}
	}
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	strDbgMsg = QString::asprintf(_T("FTS::WaitAndGetAck END Cmd Type %d m_eCmdRespState %d bRet = %d "), GetCmdType(), m_eCmdRespStatus, bRet);
	LogDebugMessage(strDbgMsg);
#endif
	return bRet;
}
//****************************************************************************
/// WaitForCmdResp - Wait for the cmd response thru socket (onRecieve) from server
///
/// @param[in] DWORD dwTIMEOUT_FOR_WFMO - Wait Time
///
/// @return		true if connect successful
///
//****************************************************************************
BOOL CHtDataCmd::WaitForCmdResp(const DWORD dwTIMEOUT_FOR_WFMO) {
	BOOL bRet = FALSE;
	DWORD dwRet = WAIT_FAILED;
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	QString   strDbgMsg;
	strDbgMsg = QString::asprintf(_T("WaitForCmdResp BEGIN waititme: %lu CmdType %d m_eCmdState %d m_eCmdRespState %d "), dwTIMEOUT_FOR_WFMO, GetCmdType(), m_eCmdState, m_eCmdRespStatus);
	LogDebugMessage(strDbgMsg);
#endif
	CHtDataTransferEngine *pHtDTE = CHtDataTransferEngine::GetHandle();
	if (NULL != pHtDTE) {
		//wait for the list of events generated by the sockets
		dwRet = WaitForSingleObject(pHtDTE->GetCmdRespEvHandle(), dwTIMEOUT_FOR_WFMO);
		if (WAIT_TIMEOUT == dwRet) {
			m_eCmdRespStatus = CMD_RESP_ST_TIMEOUT;
			bRet = FALSE;
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
			strDbgMsg = QString::asprintf(_T(" ::WFCR WAIT_TIMEOUT CmdType %d m_eCmdState %d m_eCmdRespState %d "), GetCmdType(), m_eCmdState, m_eCmdRespStatus);
			LogDebugMessage(strDbgMsg);
	#endif
		} else if (WAIT_FAILED == dwRet) {
			m_eCmdRespStatus = CMD_RESP_ST_ABORTED;
			bRet = FALSE;
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
			strDbgMsg = QString::asprintf(_T(" ::WFCR WAIT_FAILED CmdType %d m_eCmdState %d m_eCmdRespState %d "), GetCmdType(), m_eCmdState, m_eCmdRespStatus);
			LogDebugMessage(strDbgMsg);
	#endif
		} else if (WAIT_OBJECT_0 == dwRet) {
			//Dont set here... the RESP State already get updated by RecevThread
			bRet = TRUE;
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
			strDbgMsg = QString::asprintf(_T(" ::WFCR WAIT_OBJECT_0 CmdType %d m_eCmdState %d m_eCmdRespState %d "), GetCmdType(), m_eCmdState, m_eCmdRespStatus);
			LogDebugMessage(strDbgMsg);
	#endif
		} else {
			m_eCmdRespStatus = CMD_RESP_ST_ABORTED;
			bRet = FALSE;
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
			strDbgMsg = QString::asprintf(_T(" ::WFCR UnknownErr %lu CmdType %d m_eCmdState %d m_eCmdRespState %d "), dwRet, GetCmdType(), m_eCmdState, m_eCmdRespStatus);
			LogDebugMessage(strDbgMsg);
	#endif
		}
	}
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	strDbgMsg = QString::asprintf(_T("WaitForCmdResp END bRet %d CmdType %d m_eCmdState %d m_eCmdRespState %d "), bRet, GetCmdType(), m_eCmdState, m_eCmdRespStatus);
	LogDebugMessage(strDbgMsg);
#endif
	return bRet;
}
int CHtDataCmd::SendRAck(const UHtdCmdRespAck *puCmdRAck) {
	int nBytesSent = QAbstractSocket_ERROR;
	if (NULL != puCmdRAck) {
		CHtDataTransferEngine *pHtDTE = CHtDataTransferEngine::GetHandle();
		CCmdRespAck cmdRAck(CHtDataCmd::CMD_DISHA_OUTGOING, puCmdRAck->sCmdRAck);
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
		cmdRAck.SetDebugLogger(m_pDebugFileLogger);
		#endif
		nBytesSent = cmdRAck.Send(pHtDTE->GetHtDataSock());
	}
	return nBytesSent;
}
int CHtDataCmd::SendRAck(CHtDataCmd::EHtdCmdRespCode eCmdRespCode, ULONG ulRepLen) {
	//Send Ack only for Resp Len Packet
	UHtdCmdRespAck uCmdRAck;
	memset(uCmdRAck.byBytes, 0, sizeof(uCmdRAck));
	CHtDataTransferEngine *pHtDTE = CHtDataTransferEngine::GetHandle();
	uCmdRAck.sCmdRAck.eCmdRespCode = eCmdRespCode;
	uCmdRAck.sCmdRAck.uTotalDataLen.ulLen = ulRepLen;
	CCmdRespAck cmdRAck(CHtDataCmd::CMD_DISHA_OUTGOING, uCmdRAck.sCmdRAck);
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	cmdRAck.SetDebugLogger(m_pDebugFileLogger);
#endif
	return cmdRAck.Send(pHtDTE->GetHtDataSock());
}
int CHtDataCmd::SendRData(char *pDataBuf, ULONG ulRepLen) {
	int nSentBytes = QAbstractSocket_ERROR;
	if (ulRepLen > HTD_RESP_CHUNK_SIZE) {
		CHtDataTransferEngine *pHtDTE = CHtDataTransferEngine::GetHandle();
		CCmdRespDataEx::UHtdCmdRespDataEx *puHtdCmdRespDataEx = NULL;
		puHtdCmdRespDataEx = pHtDTE->GetHtdCmdRespDataEx();
		memset(puHtdCmdRespDataEx->byBytes, 0, sizeof(CCmdRespDataEx::UHtdCmdRespDataEx));
		puHtdCmdRespDataEx->sCmdRData.uRDataLen.ulLen = ulRepLen;
		memcpy_s(puHtdCmdRespDataEx->sCmdRData.chDataBuf, ulRepLen, pDataBuf, ulRepLen);
		CCmdRespDataEx cmdRDataEx(CHtDataCmd::CMD_DISHA_OUTGOING, puHtdCmdRespDataEx);
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
		cmdRDataEx.SetDebugLogger(m_pDebugFileLogger);
		#endif
		nSentBytes = cmdRDataEx.Send(pHtDTE->GetHtDataSock());
	} else {
		//Send Ack only for Resp Len Packet
		CCmdRespData::UHtdCmdRespData uCmdRData;
		memset(uCmdRData.byBytes, 0, sizeof(uCmdRData));
		uCmdRData.sCmdRData.uRDataLen.ulLen = ulRepLen;
		memcpy_s(uCmdRData.sCmdRData.chDataBuf, ulRepLen, pDataBuf, ulRepLen);
		CCmdRespData cmdRData(CHtDataCmd::CMD_DISHA_OUTGOING, uCmdRData.sCmdRData);
		CHtDataTransferEngine *pHtDTE = CHtDataTransferEngine::GetHandle();
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
		cmdRData.SetDebugLogger(m_pDebugFileLogger);
	#endif
		nSentBytes = cmdRData.Send(pHtDTE->GetHtDataSock());
	}
	return nSentBytes;
}
void CHtDataCmd::EndAndNotify(bool bFileIsOpen, bool bNotify) {
	//Handle the file pointer
	if (NULL != m_pFile) {
		if (bFileIsOpen) {
			m_pFile->Close();
		}
		delete m_pFile;
		m_pFile = NULL;
	}
	if (bNotify) {
		CHtDataTransferEngine *pHtDTE = CHtDataTransferEngine::GetHandle();
		//Trigger the (set) event after sent everything
		SetEvent(pHtDTE->GetCmdRespEvHandle());
	}
}
void CHtDataCmd::RefreshTimer() {
	//Reset the timer
	m_cmdTimer.ResetAllTimers();
}
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
void CHtDataCmd::SetDebugLogger(CDebugFileLogger* pDbgFileLogger)
{
	m_pDebugFileLogger = pDbgFileLogger;
}
void CHtDataCmd::LogDebugMessage(QString   strDebugMsg)
{
	if( NULL != m_pDebugFileLogger )
	{
		QString   strDiagMsg;
		strDiagMsg = QString::asprintf(_T("HtdCmd - %s at GTC:%u\r\n"), strDebugMsg, GetTickCount());
		m_pDebugFileLogger->WriteToDebugLogFile(strDiagMsg);
	}
}
#endif
//*****End of HT DATA CMD Base ********************************///
//////////*****************Get File Request Cmd *******************///
CGetFileListRequestCmd::CGetFileListRequestCmd(ECmdDisha eCmdDisha,
		const UHtdGFLReqCmd::SHtdCmdGFLRequest &sCmdGFLRequest) : CHtDataCmd(HTD_CMD_GET_FILE_LIST_REQUEST, eCmdDisha), m_strFolderPath(
		_T("")) {
	ResetPkt();
	m_uFileListBytesExpected.ulLen = 0;
	m_uFileListBytesTransceived.ulLen = 0;
	memcpy_s(&m_uCmdGFLReq.sCmdGFLReq, sizeof(m_uCmdGFLReq), &sCmdGFLRequest, sizeof(sCmdGFLRequest));
	if (CMD_DISHA_OUTGOING == m_eCmdDisha) {
		PrepareHdr(&m_uCmdGFLReq.sCmdGFLReq.uCmdHeader);
	}
}
CGetFileListRequestCmd::CGetFileListRequestCmd(ECmdDisha eCmdDisha, QString strFolderPath) : CHtDataCmd(
		HTD_CMD_GET_FILE_LIST_REQUEST, eCmdDisha), m_strFolderPath(strFolderPath) {
	ResetPkt();
	m_uFileListBytesExpected.ulLen = 0;
	m_uFileListBytesTransceived.ulLen = 0;
	QString A
	remotefNameA;
#if defined ( _UNICODE )
	remotefNameA = CHtDataTransferEngine::ConvertUnicodeStrToMBCSStr(strFolderPath, MAX_HTD_FILE_PATH_LEN);
#else
	remotefNameA = strFolderPath;
#endif 
	memcpy_s(m_uCmdGFLReq.sCmdGFLReq.chFolderPath, MAX_HTD_FILE_PATH_LEN, remotefNameA, remotefNameA.size());
	if (CMD_DISHA_OUTGOING == m_eCmdDisha) {
		PrepareHdr(&m_uCmdGFLReq.sCmdGFLReq.uCmdHeader);
	}
}
CGetFileListRequestCmd::~CGetFileListRequestCmd() {
	ResetPkt();
}
CHtDataCmd::UHtdCmdHeader* CGetFileListRequestCmd::GetCmdHeader() {
	return &m_uCmdGFLReq.sCmdGFLReq.uCmdHeader;
}
ULONG CGetFileListRequestCmd::GetCmdPktLen() {
	return sizeof(UGetFileListRequestCmd);
}
const BYTE* CGetFileListRequestCmd::GetCmdPktBytes() {
	return m_uCmdGFLReq.byBytes;
}
void CGetFileListRequestCmd::ResetPkt() {
	memset(m_uCmdGFLReq.byBytes, 0, sizeof(m_uCmdGFLReq));
	memset(m_chDataChunk, 0, HTD_DATA_CHUNK_SIZE);
}
bool CGetFileListRequestCmd::Validate() {
	return true;
}
BOOL CGetFileListRequestCmd::Execute() {
	BOOL bRet = FALSE;
	//Set State to accepted
	m_eCmdState = CMD_ST_ACCEPTED;
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	QString   strDbgMsg;
	strDbgMsg = QString::asprintf(_T("GFLR::Execute BEGIN CmdType %d m_eCmdState %d ") , GetCmdType(), m_eCmdState);
	LogDebugMessage(strDbgMsg);
	#endif
#ifdef _UNICODE
	size_t szNumCharsRet = 0;
	WCHAR wcTmpBuf[MAX_HTD_FILE_PATH_LEN];
	wmemset(wcTmpBuf, L'\0', MAX_HTD_FILE_PATH_LEN);	
	mbstowcs_s(&szNumCharsRet, wcTmpBuf, sizeof(wcTmpBuf)/sizeof(WCHAR), m_uCmdGFLReq.sCmdGFLReq.chFolderPath, MAX_HTD_FILE_PATH_LEN);
	m_strFolderPath = QString::asprintf(_T("%s"), wcTmpBuf);
#else
	m_strFolderPath = QString::asprintf(_T("%s"), m_uCmdGFLReq.sCmdGFLReq.chFolderPath);
#endif
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	strDbgMsg = QString::asprintf(_T("GFLR::Execute m_strFolderPath %s CmdType %d m_eCmdState %d ") , m_strFolderPath, GetCmdType(), m_eCmdState);
	LogDebugMessage(strDbgMsg);
	#endif
	CHtDataTransferEngine *pHtDTE = CHtDataTransferEngine::GetHandle();
	if (NULL != pHtDTE) {
		if (CMD_DISHA_INCOMING == m_eCmdDisha) {
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
			strDbgMsg = QString::asprintf(_T("GFLR::Execute Post Send File List FolderPath %s CmdDISHA %d") , m_strFolderPath, m_eCmdDisha);
			LogDebugMessage(strDbgMsg);
			#endif
			//bRet = pHtDTE->PostHtdTransceiveMsg(WM_HTD_SEND_FILE_LIST, (WPARAM)this, (LPARAM)pHtDTE );
			bRet = PrepareToSend();
		} else {
			bRet = PrepareToReceive();
		}
	}
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	strDbgMsg = QString::asprintf(_T("GFLR::Execute END bRet %d CmdType %d m_eCmdState %d ") , bRet, GetCmdType(), m_eCmdState);
	LogDebugMessage(strDbgMsg);
	#endif
	return bRet;
}
BOOL CGetFileListRequestCmd::ProcessRespCmd(CHtDataCmd *pRespCmd) {
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	QString   strDbgMsg;
	strDbgMsg = QString::asprintf(_T("GFLR::ProcessRespCmd BEGIN CmdType %d m_eCmdState %d RespCmdType %d") , GetCmdType(), m_eCmdState, pRespCmd->GetCmdType());
	LogDebugMessage(strDbgMsg);
	#endif
	BOOL bRet = CHtDataCmd::ProcessRespCmd(pRespCmd);
	CHtDataTransferEngine *pHtDTE = CHtDataTransferEngine::GetHandle();
	if ( TRUE == bRet) {
		if (CMD_DISHA_INCOMING == m_eCmdDisha) {
			//Server Mode ..incoming
			if (HTD_CMD_RESP_ACK_DETAILS == pRespCmd->GetCmdType()) {
				//ToDo:: use dynamic cast
				CCmdRespAck *pCmdRAck = (CCmdRespAck*) pRespCmd;
				//if (CMD_ST_WAIT_ACK == m_eCmdState ) //Is This Really required?
				{
					CCmdRespAck::EHtdCmdRespCode eRespCode = pCmdRAck->GetCmdRespCode();
					if (CCmdRespAck::HTD_CMD_RESP_CODE_ACK == eRespCode) {
						m_eCmdRespStatus = CMD_RESP_ST_ACK;
						bRet = SendDataChunk();
						//while( (TRUE == bRet ) && (FALSE == IsCompleted() ) )
						//{
						//	bRet = SendDataChunk();
						//	sleep(50);//Have a nominal sleep to allow the receipent to act up on
						//}
					} else if (CCmdRespAck::HTD_CMD_RESP_CODE_NACK == eRespCode) {
						m_eCmdRespStatus = CMD_RESP_ST_NACK;
						Abort();
					} else {
						m_eCmdRespStatus = CMD_RESP_ST_ABORTED; //Not Expected
						Abort();
					}
				}
			} else {
				//Not Expected right now
			}
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
			strDbgMsg = QString::asprintf(_T(" ::ProcessRespCmd Set->CmdRespEvHandle CmdType %d m_eCmdState %d RespCmdType %d ") , GetCmdType(), m_eCmdState, pRespCmd->GetCmdType());
			LogDebugMessage(strDbgMsg);
			#endif
		} else {
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
			strDbgMsg = QString::asprintf(_T(" ::ProcessRespCmd call->RecvStateMachine CmdType %d m_eCmdState %d RespCmdType %d ") , GetCmdType(), m_eCmdState, pRespCmd->GetCmdType());
			LogDebugMessage(strDbgMsg);
			#endif
			//Outgoing (client mode)	
			RecvStateMachine(pRespCmd);
		}
	}
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	strDbgMsg = QString::asprintf(_T("GFLR::ProcessRespCmd END CmdType %d m_eCmdState %d RespCmdType %d bRet %d") , GetCmdType(), m_eCmdState, pRespCmd->GetCmdType(), bRet);
	LogDebugMessage(strDbgMsg);
	#endif
	if (IsCompleted()) {
		//This should be the last action of the command
		//After this the object may get destroyed
		EndAndNotify(false, true);
	}
	return bRet;
}
BOOL CGetFileListRequestCmd::PrepareToSend() {
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	QString   strDbgMsg;
	strDbgMsg = QString::asprintf(_T("CGFLRCmd::PrepareToSend BEGIN FolderPath %s"), m_strFolderPath);
	LogDebugMessage(strDbgMsg);
	#endif
	BOOL bRet = FALSE;
	m_strFileList = QString::asprintf(_T("SFL$"));
	const ULONG ulDefault_SFL_Len = m_strFileList.size();
	GetFileList(m_strFolderPath, m_strFileList, _T(" "));
	m_strFileList.Trimright();
	m_uFileListBytesExpected.ulLen = m_strFileList.size();
	m_uFileListBytesTransceived.ulLen = 0;
	if (ulDefault_SFL_Len == m_uFileListBytesExpected.ulLen) {
		SendRAck(HTD_CMD_RESP_CODE_NACK, m_uFileListBytesExpected.ulLen);
	} else {
		bRet = SendInitialPkt();
	}
	if ( FALSE == bRet) {
		Abort();
		m_eCmdRespStatus = CMD_RESP_ST_ABORTED;
	}
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	strDbgMsg = QString::asprintf(_T("CGFLRCmd::PrepareToSend END FolderPath = %s bRet %d "), m_strFolderPath, bRet);
	LogDebugMessage(strDbgMsg);
	#endif
	return bRet;
}
BOOL CGetFileListRequestCmd::SendInitialPkt() {
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	QString   strDbgMsg;
	strDbgMsg = QString::asprintf(_T("GFLR::SendInitialPkt BEGIN FolderPath %s"), m_strFolderPath);
	LogDebugMessage(strDbgMsg);
	#endif
	BOOL bRet = FALSE;
	char *sendData = NULL;	// pointer to buffer for sending data (memory is allocated after sending fileList size)
	ULONG ulChunkSize = m_uFileListBytesExpected.ulLen - m_uFileListBytesTransceived.ulLen;
	if (ulChunkSize > HTD_GFR_CHUNK_SIZE) {
		ulChunkSize = HTD_GFR_CHUNK_SIZE;
	}
	QString strChunk = m_strFileList.mid(m_uFileListBytesTransceived.ulLen, ulChunkSize);
	UHtdCmdRespAck uRAck;
	sendData = uRAck.sCmdRAck.chDataBuf; //Use the Ack Cmd buf
	memset(sendData, 0, HTD_GFR_CHUNK_SIZE);
#ifdef _UNICODE
	size_t szNumCharConverted = 0;
  errno_t nErr = wcstombs_s(&szNumCharConverted, sendData, HTD_GFR_CHUNK_SIZE, strChunk, _TRUNCATE);
	#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	strDbgMsg = QString::asprintf(_T("GFLR::SIP Converted to mbs szNumCharConverted = %d nErr %d"), szNumCharConverted, nErr);
	LogDebugMessage(strDbgMsg);
	#endif
	#endif	
	uRAck.sCmdRAck.eCmdRespCode = HTD_CMD_RESP_CODE_INITIAL_PKT;
	uRAck.sCmdRAck.uTotalDataLen.ulLen = m_uFileListBytesExpected.ulLen;
	uRAck.sCmdRAck.uCurChunkLen.ulLen = ulChunkSize;
	if (QAbstractSocket_ERROR != SendRAck(&uRAck)) {
		bRet = TRUE;
		m_uFileListBytesTransceived.ulLen += ulChunkSize;
	} else {
		Abort();
		m_eCmdRespStatus = CMD_RESP_ST_ABORTED;
	}
	if (m_uFileListBytesTransceived.ulLen >= m_uFileListBytesExpected.ulLen) {
		End();
		m_eCmdRespStatus = CMD_RESP_ST_ACK;
	}
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	strDbgMsg = QString::asprintf(_T("GFLR::SendInitialPkt END FolderPath = %s bRet %d "), m_strFolderPath, bRet);
	LogDebugMessage(strDbgMsg);
	#endif
	return bRet;
}
BOOL CGetFileListRequestCmd::SendDataChunk() {
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	QString   strDbgMsg;
	strDbgMsg = QString::asprintf(_T("CGFLRCmd::SendDataChunk BEGIN FolderPath %s"), m_strFolderPath);
	LogDebugMessage(strDbgMsg);
	#endif
	BOOL bRet = FALSE;
	char *sendData = NULL;	// pointer to buffer for sending data (memory is allocated after sending fileList size)
	ULONG ulChunkSize = m_strFileList.size() - m_uFileListBytesTransceived.ulLen;
	if (ulChunkSize > HTD_DATA_CHUNK_SIZE) {
		ulChunkSize = HTD_DATA_CHUNK_SIZE;
	}
	QString strChunk = m_strFileList.mid(m_uFileListBytesTransceived.ulLen, ulChunkSize);
	//sendData = new BYTE[ulChunkSize];
	sendData = m_chDataChunk;
	memset(sendData, 0, sizeof(m_chDataChunk));
#ifdef _UNICODE
	size_t szNumCharConverted = 0;
  errno_t nErr = wcstombs_s(&szNumCharConverted, sendData, ulChunkSize, strChunk, ulChunkSize);
	#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	strDbgMsg = QString::asprintf(_T(" ::SFL Converted to mbs szNumCharConverted = %d nErr %d"), szNumCharConverted, nErr);
	LogDebugMessage(strDbgMsg);
	#endif
	#endif	
	if (QAbstractSocket_ERROR != SendRData(sendData, ulChunkSize)) {
		bRet = TRUE;
		m_uFileListBytesTransceived.ulLen += ulChunkSize;
	} else {
		Abort();
		m_eCmdRespStatus = CMD_RESP_ST_ABORTED;
	}
	if (m_uFileListBytesTransceived.ulLen >= m_uFileListBytesExpected.ulLen) {
		End();
		m_eCmdRespStatus = CMD_RESP_ST_ACK;
	}
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	strDbgMsg = QString::asprintf(_T("CGFLRCmd::SendDataChunk END FolderPath = %s bRet %d "), m_strFolderPath, bRet);
	LogDebugMessage(strDbgMsg);
	#endif
	return bRet;
}
BOOL CGetFileListRequestCmd::GetFileList(QString strFolderPath, QString &strFileList, QString strDelim) {
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	QString   strDbgMsg;
	strDbgMsg = QString::asprintf(_T("CGFLRCmd::GetFileList BEGIN FolderPath %s"), strFolderPath);
	LogDebugMessage(strDbgMsg);
#endif
	BOOL bRet = TRUE;				// return value
	WIN32_FIND_DATA windexOfFileData;
	HANDLE hindexOf = NULL;
	hindexOf = CStorage::FindFirstFile(strFolderPath, &windexOfFileData);
	DWORD dwErr = 0;
	if ( INVALID_HANDLE_VALUE == hindexOf) {
		dwErr = ::GetLastError();
		hindexOf = NULL;
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
		strDbgMsg = QString::asprintf(_T(" ::GFL FolderPath returned error = %d"), dwErr);
		LogDebugMessage(strDbgMsg);
#endif
	} else {
		BOOL bContinue = TRUE;
		// Iterate through the files in the directory
		while (bContinue) {
			bool bAddFile = true;
			// Skip '.' and '..'
			if (0 == _tcscmp(windexOfFileData.cFileName, _T(".")) || 0 == _tcscmp(windexOfFileData.cFileName, _T(".."))
					|| 1 == (windexOfFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) {
				bAddFile = false;
			}
			if (bAddFile) {
				// Build list entry out of current file
				QString strFileName;
				strFileName = QString::asprintf(_T("%s"), windexOfFileData.cFileName);
				strFileList.Append(strFileName);
				strFileList.Append(strDelim);
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
				strDbgMsg = QString::asprintf(_T(" ::GFL CurFileList = %s"), strFileList);
				LogDebugMessage(strDbgMsg);
#endif
			}
			// If we hit the end of the directory, bail out
			bContinue = CStorage::FindNextFile(hindexOf, &windexOfFileData);
			dwErr = ::GetLastError();
		}
	}
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	strDbgMsg = QString::asprintf(_T("CGFLRCmd::GetFileList FolderPath = %s dwErr %d END"), strFolderPath, dwErr);
	LogDebugMessage(strDbgMsg);
#endif
	return bRet;
}
BOOL CGetFileListRequestCmd::PrepareToReceive() //CMD_DISHA_OUTGOING
{
	BOOL bRet = FALSE;
	m_uFileListBytesExpected.ulLen = 0;
	m_uFileListBytesTransceived.ulLen = 0;
	m_eCmdState = CMD_ST_IDLE; //Reset Cmd State
	CHtDataTransferEngine *pHtDTE = CHtDataTransferEngine::GetHandle();
	ResetEvent(pHtDTE->GetCmdRespEvHandle());
	m_eCmdState = CMD_ST_WAIT_ACK;
	int nBytesSent = Send(pHtDTE->GetHtDataSock());
	if (QAbstractSocket_ERROR != nBytesSent) {
		//Wait for COMPLETION directly
		bRet = WaitForCmdResp(120000L);
	} else {
		bRet = FALSE;
	}
	return bRet;
}
BOOL CGetFileListRequestCmd::RecvStateMachine(const CHtDataCmd *pRespCmd) {
	BOOL bRet = FALSE;
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	QString   strDbgMsg;
	strDbgMsg = QString::asprintf(_T("GFLR::RSM GFL BEGIN Cmd Type %d m_eCmdState %d "), GetCmdType(), m_eCmdState);
	LogDebugMessage(strDbgMsg);
#endif
	if (m_eCmdState == CMD_ST_WAIT_ACK) {
		bRet = ProcessCmdRAck(pRespCmd);
	} else if (m_eCmdState == CMD_ST_BEGIN) {
		if (HTD_CMD_RESP_DATA == pRespCmd->GetCmdType() || HTD_CMD_RESP_DATA_EX == pRespCmd->GetCmdType()) {
			const char *pDataBuf = NULL;
			ULONG ulLen = 0;
			if (HTD_CMD_RESP_DATA == pRespCmd->GetCmdType()) {
				CCmdRespData *pCmdRData = (CCmdRespData*) pRespCmd;
				pDataBuf = pCmdRData->GetRespDataBuf();
				ulLen = pCmdRData->GetRespDataLen();
			} else if (HTD_CMD_RESP_DATA_EX == pRespCmd->GetCmdType()) {
				CCmdRespDataEx *pCmdEx = (CCmdRespDataEx*) pRespCmd;
				pDataBuf = pCmdEx->GetRespDataBuf();
				ulLen = pCmdEx->GetRespDataLen();
			}
			RecvDataChunk(pDataBuf, ulLen);
		}
	}
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	strDbgMsg = QString::asprintf(_T("GFLR::RSM END CmdType %d m_eCmdState %d "), GetCmdType(), m_eCmdState);
	LogDebugMessage(strDbgMsg);
#endif
	return bRet;
}
BOOL CGetFileListRequestCmd::RecvDataChunk(const char *pDataBuf, ULONG ulLen) {
	BOOL bRet = TRUE;
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	QString   strDbgMsg;
	strDbgMsg = QString::asprintf(_T("GFLR::RecvDataChunk BEGIN curChunk %lu DataBytesRcvd %lu out of ExpectedBytes %lu m_eCmdState %d "),ulLen, m_uFileListBytesTransceived.ulLen, m_uFileListBytesExpected.ulLen, m_eCmdState);
	LogDebugMessage(strDbgMsg);
#endif
	QString strFileList;
#ifdef _UNICODE
	WCHAR wcBuf[HTD_DATA_CHUNK_SIZE];
	memset(wcBuf, 0, HTD_DATA_CHUNK_SIZE);
	size_t szNumCharsRet = 0;
	mbstowcs_s(&szNumCharsRet, wcBuf, ulLen, pDataBuf, ulLen);
	strFileList = QString::asprintf(_T("%s"), wcBuf);			
#else
	const char *pRecvBuf = pDataBuf;
	if (0 == m_uFileListBytesTransceived.ulLen) {
		//First chunk does have the "SFL$" as header in FileList Data
		QString strBuf(pRecvBuf + 4, ulLen - 4);
		strFileList = strBuf;
	} else {
		QString strBuf(pRecvBuf, ulLen);
		strFileList = strBuf;
	}
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	strDbgMsg = QString::asprintf(_T("::RSM GF strFileList %s DataBytesRcvd %lu out of ExpectedBytes %lu m_eCmdState %d "), strFileList, m_uFileListBytesTransceived.ulLen, m_uFileListBytesExpected.ulLen, m_eCmdState);
	LogDebugMessage(strDbgMsg);
#endif
#endif
	m_strFileList += strFileList;
	m_uFileListBytesTransceived.ulLen += ulLen;
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	strDbgMsg = QString::asprintf(_T("GFLR::RDC GF DataBytesRcvd %lu out of ExpectedBytes %lu m_eCmdState %d "), m_uFileListBytesTransceived.ulLen, m_uFileListBytesExpected.ulLen, m_eCmdState);
	LogDebugMessage(strDbgMsg);
#endif
	if (m_uFileListBytesExpected.ulLen <= m_uFileListBytesTransceived.ulLen) {
		//End the Sstate as all expected bytes received
		End();
	} else {
		SendRAck(HTD_CMD_RESP_CODE_ACK); //No More ACKs in between
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
		strDbgMsg = QString::asprintf(_T("GFLR::RDC No More ACKs in between Cmd Type %d m_eCmdState %d"), GetCmdType(), m_eCmdState);
		LogDebugMessage(strDbgMsg);
		#endif			
	}
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	strDbgMsg = QString::asprintf(_T("GFLR::RecvDataChunk END DataBytesRcvd %lu out of ExpectedBytes %lu m_eCmdState %d "), m_uFileListBytesTransceived.ulLen, m_uFileListBytesExpected.ulLen, m_eCmdState);
	LogDebugMessage(strDbgMsg);
#endif
	return bRet;
}
BOOL CGetFileListRequestCmd::RecvInitialPkt(const CCmdRespAck *pRespInitPkt) {
	BOOL bRet = FALSE;
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	QString   strDbgMsg;
	strDbgMsg = QString::asprintf(_T("GFLR::RecvInitialPkt BEGIN m_eCmdState %d pRespInitPkt->GetCmdType() "), m_eCmdState, pRespInitPkt->GetCmdType());
	LogDebugMessage(strDbgMsg);
#endif
	m_eCmdState = CMD_ST_BEGIN;
	const UHtdCmdRespAck &uRAck = pRespInitPkt->GetURAck();
	m_uFileListBytesExpected.ulLen = uRAck.sCmdRAck.uTotalDataLen.ulLen;
	m_uFileListBytesTransceived.ulLen = 0;
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	strDbgMsg = QString::asprintf(_T("GFLR::RIP ACCEPTED->BEGIN m_eCmdState %d Expected LenBytes %lu"), m_eCmdState, m_uFileListBytesExpected.ulLen);
	LogDebugMessage(strDbgMsg);
	#endif
	if (0 == m_uFileListBytesExpected.ulLen) {
		End();
	} else {
		bRet = TRUE;
		if (uRAck.sCmdRAck.uCurChunkLen.ulLen != 0) {
			RecvDataChunk(uRAck.sCmdRAck.chDataBuf, uRAck.sCmdRAck.uCurChunkLen.ulLen);
			if (!IsCompleted()) {
				m_eCmdState = CMD_ST_BEGIN;
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
				strDbgMsg = QString::asprintf(_T("GFLR::RIP SendACK m_eCmdState %d "), m_eCmdState);
				LogDebugMessage(strDbgMsg);
				#endif
				if (QAbstractSocket_ERROR == SendRAck(HTD_CMD_RESP_CODE_ACK)) {
					bRet = FALSE;
				}
			}
		}
	}
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	strDbgMsg = QString::asprintf(_T("GFLR::RecvInitialPkt END m_eCmdState %d pRespInitPkt->GetCmdType() "), m_eCmdState, pRespInitPkt->GetCmdType());
	LogDebugMessage(strDbgMsg);
#endif
	return bRet;
}
BOOL CGetFileListRequestCmd::ProcessCmdRAck(const CHtDataCmd *pRespCmd) {
	BOOL bRet = FALSE;
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	QString   strDbgMsg;
	strDbgMsg = QString::asprintf(_T("GFLR::ProcessCmdRAck BEGIN m_eCmdState %d pRespCmd->GetCmdType() "), m_eCmdState, pRespCmd->GetCmdType());
	LogDebugMessage(strDbgMsg);
#endif
	if (HTD_CMD_RESP_ACK_DETAILS == pRespCmd->GetCmdType()) {
		const CCmdRespAck *pCmdRAck = (CCmdRespAck*) pRespCmd;
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
		strDbgMsg = QString::asprintf(_T(" ::ProcessCmdRAck m_eCmdState %d StatusCode %d NWLenBytesRecvd %lu"), m_eCmdState, pCmdRAck->GetCmdRespCode(), pCmdRAck->GetRespDataLen());
		LogDebugMessage(strDbgMsg);
		#endif
		switch (pCmdRAck->GetCmdRespCode()) {
		case CCmdRespAck::HTD_CMD_RESP_CODE_ACK: {
			m_eCmdRespStatus = CMD_RESP_ST_ACK;
		}
			break;
		case CCmdRespAck::HTD_CMD_RESP_CODE_INITIAL_PKT: {
			m_eCmdRespStatus = CMD_RESP_ST_ACK;
			RecvInitialPkt(pCmdRAck);
		}
			break;
		case CCmdRespAck::HTD_CMD_RESP_CODE_NACK: {
			m_eCmdRespStatus = CMD_RESP_ST_NACK;
			Abort();
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
				strDbgMsg = QString::asprintf(_T(" ::ProcessCmdRAck REJECTED due to No ACK m_eCmdState %d "), m_eCmdState);
				LogDebugMessage(strDbgMsg);
#endif
			bRet = FALSE;
		}
			break;
		default: {
			m_eCmdRespStatus = CMD_RESP_ST_ABORTED;
			Abort();
			bRet = FALSE;
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
				strDbgMsg = QString::asprintf(_T(" ::ProcessCmdRAck REJECTED due toUnknown StatusCode m_eCmdState %d "), m_eCmdState);
				LogDebugMessage(strDbgMsg);
				#endif
		}
			break;
		} //End of Switch		
	}
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	strDbgMsg = QString::asprintf(_T("GFLR::ProcessCmdRAck END m_eCmdState %d pRespCmd->GetCmdType() "), m_eCmdState, pRespCmd->GetCmdType());
	LogDebugMessage(strDbgMsg);
#endif
	return bRet;
}
//////////*****************End of Get File List Request Cmd *******************///
//////////*****************Get File Request Cmd *******************///
CGetFileRequestCmd::CGetFileRequestCmd(ECmdDisha eCmdDisha, const UHtdGFReqCmd::SHtdCmdGFRequest &sCmdGFRequest) : CHtDataCmd(
		HTD_CMD_GET_FILE_REQUEST, eCmdDisha), m_strLocalFileName(_T("")), m_strRemoteFileName(_T("")), m_bOverWrite(
		false) {
	ResetPkt();
	m_uFileBytesTransceived.ulLen = 0;
	m_uFileBytesExpected.ulLen = 0;
	memcpy_s(&m_uCmdGFReq.sCmdGFReq, sizeof(m_uCmdGFReq), &sCmdGFRequest, sizeof(sCmdGFRequest));
	if (CMD_DISHA_OUTGOING == m_eCmdDisha) {
		PrepareHdr(&m_uCmdGFReq.sCmdGFReq.uCmdHeader);
	}
}
CGetFileRequestCmd::CGetFileRequestCmd(ECmdDisha eCmdDisha, QString remotefName, QString localfName, bool bOverWrite) : CHtDataCmd(
		HTD_CMD_GET_FILE_REQUEST, eCmdDisha), m_strLocalFileName(localfName), m_bOverWrite(bOverWrite) {
	ResetPkt();
	m_uFileBytesTransceived.ulLen = 0;
	m_uFileBytesExpected.ulLen = 0;
	QString A
	remotefNameA;
#if defined ( _UNICODE )
	remotefNameA = CHtDataTransferEngine::ConvertUnicodeStrToMBCSStr(remotefName, MAX_HTD_FILE_PATH_LEN);
#else
	remotefNameA = remotefName;
#endif 
	memcpy_s(m_uCmdGFReq.sCmdGFReq.chFilePath, MAX_HTD_FILE_PATH_LEN, remotefNameA, remotefNameA.size());
	if (CMD_DISHA_OUTGOING == m_eCmdDisha) {
		PrepareHdr(&m_uCmdGFReq.sCmdGFReq.uCmdHeader);
	}
}
CGetFileRequestCmd::~CGetFileRequestCmd() {
	ResetPkt();
	if (NULL != m_pFile) {
		m_pFile->Close();
		delete m_pFile;
		m_pFile = NULL;
	}
}
CHtDataCmd::UHtdCmdHeader* CGetFileRequestCmd::GetCmdHeader() {
	return &m_uCmdGFReq.sCmdGFReq.uCmdHeader;
}
ULONG CGetFileRequestCmd::GetCmdPktLen() {
	return sizeof(UGetFileRequestCmd);
}
const BYTE* CGetFileRequestCmd::GetCmdPktBytes() {
	return m_uCmdGFReq.byBytes;
}
void CGetFileRequestCmd::ResetPkt() {
	memset(m_uCmdGFReq.byBytes, 0, sizeof(m_uCmdGFReq));
	memset(m_chDataChunk, 0, HTD_DATA_CHUNK_SIZE);
}
bool CGetFileRequestCmd::Validate() {
	return true;
}
BOOL CGetFileRequestCmd::Execute() {
	BOOL bRet = FALSE;
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	QString   strDbgMsg;
	strDbgMsg = QString::asprintf(_T("GFR::Execute BEGIN CmdType %d m_eCmdState %d ") , GetCmdType(), m_eCmdState);
	LogDebugMessage(strDbgMsg);
	#endif
#ifdef _UNICODE
size_t szNumCharsRet = 0;
WCHAR wcTmTm
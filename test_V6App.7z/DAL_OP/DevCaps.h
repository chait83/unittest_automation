/// @file 
/// ****************************************************************
/// Honeywell Trendview
/// ****************************************************************
/// @n Module:	 System Absraction layer
/// @n Filename: DevCaps.h
/// @n Desc:	 Device capabilities information handler
///
//  ****************************************************************
//  Revision History
//  ****************************************************************
//  $Log[4]:
//   45    Stability Project 1.42.1.1     7/2/2011 4:56:44 PM     Hemant(HAIL) 
//          Stability Project: Recorder source has been upgraded from IL
//        version of firmware to JF version of firmware.
//   44    Stability Project 1.42.1.0     7/1/2011 4:27:01 PM     Hemant(HAIL) 
//          Stability Project: Files has been checked in before the merging
//        task. The merging will be done between IL version of firmware and JF
//        version of firmware. 
//   43    V6 Firmware 1.42         12/20/2006 3:28:54 PM   Roger Dawson   
//        Phase 3b merges into the main build. Removed dependancy on
//        V6Defines.h.
//   42    V6 Firmware 1.41         10/3/2006 8:54:29 PM    Graham Waterfield
//        TM to try - prevent fixed relay from being displayed in TMP
//  $
//
//  ****************************************************************


#ifndef __DEVCAPS_H__
#define __DEVCAPS_H__

#include "V6defines.h"
#include "V6Config.h"
#include "dal.h"
#include "TV6Timer.h"
#include "Conversion.h"

class CDeviceAbstraction;

//**Class*********************************************************************
///
/// @brief Manage the device capability information
/// 
/// This class manages all details of the capabilities of the device
/// an instance will be created for each device and held as a global in GlbDevCaps
/// although device capabilites will bee added to each generated setup
///
/// 
///
//****************************************************************************
class CDeviceCaps
{
public:		
	CDeviceCaps();					///<Constructor	

	void Initialise();	

	void SetPtrToDeviceCaps( T_PDEVICECAPS pDevCaps );	

	// Generate devcaps information
	void GenerateProcBoardCaps( );
	void SetPhysicalBoardPopulationCapability( );

	// Memory Information
	const ULONG GetMemoryStatus();
	float GetMemoryTotalPhysicalK()				{ return (float)BYTE_TO_KB(m_memStat.dwTotalPhys); };
	float GetMemoryAvailablePhysicalK()			{ return (float)BYTE_TO_KB(m_memStat.dwAvailPhys); };
	float GetMemoryTotalVirtualK()				{ return (float)BYTE_TO_KB(m_memStat.dwTotalVirtual); };
	float GetMemoryAvailableVirtualK()			{ return (float)BYTE_TO_KB(m_memStat.dwAvailVirtual ); };

	float GetMemoryLoadPercentage()				{ return (float)m_memStat.dwMemoryLoad; };
	const ULONG GetAvailableMemory()			{ GetMemoryStatus(); return (ULONG)m_memStat.dwAvailPhys; };

    void DisplayTraceMemoryStatus(QString  stageText);

	// Accessor for the device type
	const T_DEV_TYPE GetDeviceType() const	{ return static_cast<T_DEV_TYPE>(m_pdc->DevType); };		///< Get the device type, see DEV_XXX in hw_defs.h
	void SetDeviceType(T_DEV_TYPE type)		{ m_pdc->DevType = static_cast<USHORT>(type); m_pDal->SetDeviceType(type);};			///< Set the device type
	void SetRs485Fitted(){ m_pdc->Board.RS485fitted = m_pDal->GetRS485fitted(); };

	// Number of IO cards
	void SetIOCardInfo( UCHAR maxIOSlots );
	const UCHAR GetIOCardInfo( void ) const;

	// Create slot information
	BOOL SetSlotInfo( USHORT slotNumber, USHORT type, USHORT numChannels );

	//Accessors for the slot information
	const USHORT GetSlotType( USHORT slotNumber ) const;
	const USHORT GetPhysicalSlotType( USHORT slotNumber ) const;
	const T_SLOT_POSITION GetSlotPosition( USHORT slotNumber ) const;

	const USHORT GetSlotNumChannels( USHORT slotNumber ) const;
	const USHORT GetSlotMaxChannels( USHORT slotNumber ) const;
	
	const BOOL IsDemoBoard( const USHORT slotNumber ) const { return m_pdc->Slot[slotNumber].DemoBoard; };
	void SetDemoBoard( const USHORT slotNumber, const BOOL enabled ){ m_pdc->Slot[slotNumber].DemoBoard = enabled; }
	
	// Channel capabilities of a particular slot and channel
	BOOL SetChannelCaps( USHORT slotNumber, USHORT chanNumber, UCHAR chanCaps );
	UCHAR GetChannelCaps( USHORT slotNumber, USHORT chanNumber ) const;
	BOOL TestChannelCapability( USHORT slotNumber, USHORT chanNumber, UCHAR chanCap ) const;

	BOOL TestTopSlotChannelCapability( const USHORT sysChanNumber, UCHAR chanCap, const T_PENBASE base ) const;

	// Method that returns true if the slot contains an analogue input card and the channel exists on that card
	bool IsValidAIChannel(	const USHORT usSLOT_NO,
							const USHORT usCHANNEL_NO ) const;

	// Method that returns true if the slot contains an pulse card and the channel exists on that card
	bool IsValidPulseInputChannel(	const USHORT usSLOT_NO,
									const USHORT usCHANNEL_NO ) const;

	// Method that returns true if the slot contains an analogue output card and the channel exists on that card
	bool IsValidAOChannel(	const USHORT usSLOT_NO,
							const USHORT usCHANNEL_NO ) const;

	// Method that returns true if the slot contains a digital IO card and the channel exists on that card
	bool IsValidDigIOChannel(	const USHORT usSLOT_NO,
								const USHORT usCHANNEL_NO ) const;

	// Method that returns true if the slot contains a relay output card and the channel exists on that card
	bool IsValidRelayOutputChannel(	const USHORT usSLOT_NO,
									const USHORT usCHANNEL_NO ) const;

	BOOL IsMultiScreen()				{ return (GetScreenType() == SCRN_12_1); };	// Method to test screen type

	// Accessors for BOARDDETAILS structure
	const ULONG GetSignature()			{ return m_pdc->Board.Signature; };
	const ULONG GetSRAMSize()			{ return m_pdc->Board.SRAMSize; };
	const ULONG GetRamSize()			{ return m_pdc->Board.RamSize; };
	const ULONG GetFlashSize()			{ return m_pdc->Board.FlashSize; };
	const ULONG GetInternalCFSize()		{ return m_pdc->Board.InternalCFSize; };
	const T_VERSIONNUM GetBootVer()		{ return m_pdc->Board.BootVer; };
	const T_VERSIONNUM GetBSPVer()		{ return m_pdc->Board.BSPVer; };
	const USHORT GetBoardRev()			{ return m_pdc->Board.BoardRev; };
	const USHORT GetBoardBuildNo()		{ return m_pdc->Board.BoardBuildNo; };
	const USHORT GetCPLDFWVer()			{ return m_pdc->Board.CPLDFWVer; };
	const USHORT GetSPIProcFW()			{ return m_pdc->Board.SPIProcFW; };
	const USHORT GetScreenType()		{ return m_pdc->Board.ScreenType; };
	const USHORT GetMegahertz()			{ return m_pdc->Board.Megahertz; };
	const BOOL GetSpeaker()				{ return (BOOL)m_pdc->Board.Speaker; };
	const BOOL GetMicrophone()			{ return (BOOL)m_pdc->Board.Microphone; };
	const BOOL GetJumperJ5()			{ return (BOOL)m_pdc->Board.JumperJ5; };
	const BOOL GetEthernetBoot()		{ return (BOOL)m_pdc->Board.EthernetBoot; };
	const BOOL GetPowerRelay()			{ return (BOOL)m_pdc->Board.PowerRelay; };
	const BOOL Get485Fitted()			{ return (BOOL)m_pdc->Board.RS485fitted; };
	const USHORT GetFrontUSBSet()		{ return m_pdc->Board.FrontUSBSet; };
	const WCHAR * GetFirmwareVersion()	{ return m_pdc->AppVersion; };
	const BYTE GetFirmwareRelease()		{ return m_pdc->AppRelease; };
	const UCHAR GetMACAddressOct(UCHAR Index);	
	
	const int GetMaxSupportedPens();

//	BOOL IsPenAvailable(USHORT pen,  T_PENBASE base )		{ return FALSE; };

	int GetMaxExtrasPensForDevice();

	BOOL AIAcqRatePrimaryChannel( const USHORT cardNo, const USHORT usBoardChanNo,
								  USHORT *pPrimaryChanNo, USHORT *pBankNo ) const;

	CDeviceAbstraction * GetDalPtr()	{ return m_pDal; };		// Get pointer to DAL

	T_PDEVICECAPS GetPtrToDeviceCaps()			{ return m_pdc; };

	/// Accessor indicating if this is a new registry ( only valid during startup )
	const bool IsNewRegistry() const { return m_bNewRegistry; }

	// Accessor used to reset the new registry flag - called once the system is fully running
	void ResetNewRegistryFlag() { m_bNewRegistry = false; }

	BOOL IsRecorderEzTrend();				// Is this recorder an EzTrend
	BOOL IsRecorderMulti(T_DEV_TYPE* device = 0);				// Is recorder a Multiplus
	BOOL IsRecorderMini();					// Is recorder a Minitrend
	BOOL IsPowerRelayFitted();				// Is power relay relay fitted

	//PSR Fix for  PAR # 1-3JLZOK8 - Remove Circular chart from Multi and Mini Recorder begin
	BOOL IsRecorderDRG2() const;	///This is the name for the DEV_SCR_MINITREND device type
	//PSR Fix for  PAR # 1-3JLZOK8 - Remove Circular chart from Multi and Mini Recorder end

	/// Indicates if circular mode is available - should be updated to check credits, device type etc.
	/// in the event the circular chart mode is to be restricted
	const BOOL IsCircularChartModeAvailable() const;
	 
public:
	///@todo AK, accessors complete but used in BOOTLACE as globals
	T_PDEVICECAPS		m_pdc;				///< Pointer to device capabilites structure

private:

	/// flag indicating if this is a new registry (set on start until the system is fully started up)
	bool m_bNewRegistry;

	T_DEVICECAPS		m_dc;				///< Device capabilities structure

	SYSTEM_INFO m_sysInf;					///< Windows System information 
	MEMORYSTATUS m_memStat;					///< Windows Memory Status

	class CDeviceAbstraction *m_pDal;		///< Handle on Device abstraction
	class CSlotMap		*m_pSlotMap;		///< Slot map holder

	BOOL m_Initialised;						///< Indicator if devcaps has been initialised

	float m_lastMemoryLevel;				///< Last known memory level for trace statistics
	CTV6Timer m_StageTimer;					///< Stage timer for startup metrics
};


#endif	// __DEVCAPS_H__


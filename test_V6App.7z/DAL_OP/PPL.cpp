/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Porting layer
/// @n Filename: PPL.cpp
/// @n Desc:	 Routines to resolve any Product usage differences
///					between application dependents
///
// 
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  64  Stability Project 1.61.1.1 7/2/2011 4:59:46 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  63  Stability Project 1.61.1.0 7/1/2011 4:26:40 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  62  V6 Firmware 1.61 3/28/2008 2:55:39 PM  Hemant(HAIL)  
//  ReInitialiseDSTEvent() method updated to handle the SNTP Issue.
//  
//  The call to this function has been stopped as the thread responsible
//  for handling DST/SDT is now handled in WinCE OS 5.0
//  61  V6 Firmware 1.60 9/25/2006 4:58:19 PM  Roger Dawson  
//  Dialogs created using new in order to reduce the impact on the stack.
// $
//
// ****************************************************************

#include "V6globals.h"

#include "TraceDefines.h"
#include "ATECal.h"

#ifdef V6IOTEST
#include "USB2SerialBridgeComPort.h"
#endif

#ifndef DOCVIEW
#ifndef V6IOTEST
#ifndef TTR6SETUP

#include "PMMGlobal.h"
#include "CPasswordModule.h"
#include "PasswordInterfaceManager.h"
#include "PassAuthMgr.h"
#include "..\HelpViewerControl\Desktop\HelpViewerControlDlg.h"
#include "Registry.h"
#include "V6AppInterface.h"
#include "AnimatedProgressDlg.h"
#include "RecSetupCfgMgr.h"

#ifdef UNDER_CE
#include "DSTChangeNotificationThread.h"
#include "TimeChangeNotifyThread.h"
#endif

#endif //TTR6SETUP
#endif//V6IOTEST
#endif//DOCVIEW
#include "ppl.h"

#ifndef V6IOTEST
#include"ScrnDesCfgMgr.h"
#endif

#ifndef V6IOTEST
#ifndef TTR6SETUP
#include "OpPanelIncludes.h"
#endif//TTR6SETUP
#endif//V6IOTEST

#ifdef V6IOTEST
static QMutex csErrorFile;
static BOOL bErrorFileCsInit = FALSE;
#endif

/// #ifdef SCREEN_DESIGNER for screen deisnger specifics
/// #ifdef V6IOTEST for V6 IO ATE test kit
/// #ifdef TMP for Trend Manager Pro

/// For OS specifics use OPL.cpp
/// For Platform/Hardware specifics use DAL.cpp

static QMutex csPplFile;
static BOOL bFileCsInit = FALSE;
#define TOUCH_CAL_DATA_LEN 78

//**********************************************************************
/// Query whether software is running as part of ATE test equipment
///
/// @return  TRUE if is running as ATE equipment; otherwise FALSE
/// 
//**********************************************************************
BOOL IsRunningAsATEEquipment(void) {
	BOOL retValue = FALSE;

#ifdef V6IOTEST
	retValue = TRUE;
#endif

	return retValue;
}

//**********************************************************************
/// Populate the card number that is being tested on the ATE test equipment
/// @param[in] cardNo - The card slot number that is being ATE/internally calibrated.
///
/// @return  TRUE if is running as ATE equipment; otherwise FALSE
/// 
//**********************************************************************
BOOL SetATEUUTCardNo(UCHAR cardNo) {
	BOOL retValue = FALSE;
#ifdef V6IOTEST
	class CATECal *pCalStruct = NULL;
	
	pCalStruct = CATECal::GetHandle();
	retValue = pCalStruct->SelectATECardNo( cardNo );
#endif

	return retValue;
}

#ifdef V6IOTEST
//**********************************************************************
///	void WriteStringToErrorReportFile( LPCTSTR lpszasprintf )
///
/// Writes the passed string to the created / opened error log file
///	FOR TEST EQUIPMENT USE ONLY
///
/// @param[in]	LPCTSTR lpszasprintf - the error string to write to file
///
/// @return	 	None
//**********************************************************************
void WriteStringToErrorReportFile( LPCTSTR lpszasprintf )
{
	LPCTSTR lpsz = L"\r\n";
	//QString   strReport = L"\r\n";

	if (!bErrorFileCsInit)
	{
		QMutex* csErrorFile;
		bErrorFileCsInit = TRUE;
	}
	csErrorFile.lock();

	//strReport.asprintf(L"%s\r\n", lpszasprintf);
	try
	{
		//create the error file, or open if it exists already
		CStdioFile* pfIOFile = new CStdioFile(	errorFileName,
												 |
												QFile::Append | 
												QFile::shareExclusive | 
												QFile::ReadWrite | 
												QFile::typeText);

		//if we have a valid file ptr add the new error to the end of the file
		//close the file on completion
		if(NULL != pfIOFile)
		{
			pfIOFile->SeekToEnd();						//set file to end
			pfIOFile->WriteString(lpszasprintf);	//add the new string
			pfIOFile->WriteString(lpsz);
			pfIOFile->Close();							//close the open file
			delete pfIOFile;							//delete the file ptr
			pfIOFile = NULL;							//tidy up the file ptr
		}
	}

	catch(FileException* pEx)
	{
		pEx->ReportError();
		pEx->Delete();
	}

	csErrorFile.lock();
}
#endif

//**********************************************************************
/// Log text representation of system error log report
/// @param[in] lpszasprintf - As per printf.
/// 
//**********************************************************************
void AddSystemErrorToReport(LPCTSTR lpszasprintf, ...) {
#ifdef V6IOTEST
	WriteStringToErrorReportFile( lpszasprintf );
	qDebug(lpszasprintf);
#else
	LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_ERROR, lpszasprintf);
#endif
}

//**********************************************************************
/// Log text representation of system warning log report
/// @param[in] lpszasprintf - As per printf.
/// 
//**********************************************************************
void AddSystemWarningToReport(LPCTSTR lpszasprintf, ...) {
#ifdef V6IOTEST
	WriteStringToErrorReportFile( lpszasprintf );
	qDebug(lpszasprintf);
#else
	LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, lpszasprintf);
#endif
}

//**********************************************************************
/// Log text representation of system info log report
/// @param[in] lpszasprintf - As per printf.
/// 
//**********************************************************************
void AddSystemInfoToReport(LPCTSTR lpszasprintf, ...) {
#ifdef V6IOTEST
	WriteStringToErrorReportFile( lpszasprintf );
	qDebug(lpszasprintf);
#else
	LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_INFORMATION, lpszasprintf);
#endif
}

//**********************************************************************
/// Log text representation of error log report
/// @param[in] lpszasprintf - As per printf.
/// 
//**********************************************************************
void AddErrorToReport(LPCTSTR lpszasprintf, ...) {
#ifdef V6IOTEST
	WriteStringToErrorReportFile( lpszasprintf );
	qDebug(lpszasprintf);
#else
	if ((wcscmp(lpszasprintf, "") != 0)) //added by kranti to remove waited too long msg at startup.
		LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_INFO, lpszasprintf);
#endif
}

//**********************************************************************
/// Log text representation of error log report, logging as an actual error
/// rather than information
/// @param[in] lpszasprintf - As per printf.
/// 
//**********************************************************************
void AddErrorToReportAsError(LPCTSTR lpszasprintf, ...) {
#ifdef V6IOTEST
	WriteStringToErrorReportFile( lpszasprintf );
	qDebug(lpszasprintf);
#else
	if ((wcscmp(lpszasprintf, "") != 0)) //added by kranti to remove waited too long msg at startup.
		LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, lpszasprintf);
#endif
}

//**********************************************************************
/// Log text representation of error log report
/// @param[in] lpszasprintf - As per printf.
/// 
//**********************************************************************
void LogInternalError(char* lpszasprintf, ...) {
#ifdef V6IOTEST
	WriteStringToErrorReportFile( lpszasprintf );
	qDebug(lpszasprintf);
#else
	LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_INFO, lpszasprintf);
#endif
}

//**********************************************************************
///
/// indexOfs the comm port on the PC that the USB device is connected to.
///
/// @param[out] thePort - Comms port number.
///
/// @return	 	TRUE if the comm port number is found (or does not have to be found)
/// otherwise FALSE
//**********************************************************************
BOOL indexOfTestEquipmentCommPort(int &thePort) {
	BOOL retValue = FALSE;
#ifdef V6IOTEST

	USB2SerialBridgeComPort findCom;
	
	// Get com port from the registry for test equipment
	retValue = findCom.GetPort( thePort );
	if(retValue == FALSE )
	{
		if( findCom.GetPort( thePort ) == TRUE )
			retValue = findCom.GetPort( thePort );
	}
#endif

	return retValue;
}

//**********************************************************************
///
/// Qualifies the channel type with the actual I/O hardware.
///
/// @param[in] slotNumber - The recorder I/O board slot number.
/// @param[in] chanNumber - The board channel number.
/// @param[in] chanType - The channel type to be qualified.
///
/// @return	 	The channel type qualified with the hardware
//**********************************************************************
USHORT QualifyChanWithIOSchedHW(const USHORT slotNumber, const USHORT chanNumber, USHORT chanType) {
#ifndef TTR6SETUP
	class CBrdInfo *pBrdInfoObj = NULL;

	pBrdInfoObj = CBrdInfo::GetHandle();
	if (pBrdInfoObj != NULL) {
		// Now qualify it with the I/O card channel capabilities ifrom the actual hardware
		// Channel will still need qualifying if the bottom slot; the CMM may not match the CMM selection
		if ((chanType == CHANNEL_DI)
				&& !(pBrdInfoObj->WhatAvailableChannelType(slotNumber, chanNumber) & CHANNEL_CAP_DI)) {
			chanType = CHANNEL_MISTMATCH;
		} else if ((chanType == CHANNEL_DO)
				&& !(pBrdInfoObj->WhatAvailableChannelType(slotNumber, chanNumber) & CHANNEL_CAP_DO)) {
			chanType = CHANNEL_MISTMATCH;
		}
		if ((chanType == CHANNEL_DIG_PULSE)
				&& !(pBrdInfoObj->WhatAvailableChannelType(slotNumber, chanNumber) & CHANNEL_CAP_PULSE)) {
			chanType = CHANNEL_MISTMATCH;
		}
	}
#endif
	return chanType;
}
//****************************************************************************
// void FailedToLoadExtResPack()
///
/// Method is called when the system has failed to load the external resource pack
/// 
//****************************************************************************
void FailedToLoadExtResPack() {
#ifndef DOCVIEW
#ifndef V6IOTEST
#ifndef TTR6SETUP

	// display the error information
	pSYSTEM_INFO->AddStartupErr(L"System repair required");
	pSYSTEM_INFO->AddStartupErr(L"Missing or corrupted");
	pSYSTEM_INFO->AddStartupErr(L"Error! Failed to load OEM resource pack.");

	// now hang this thread as the integrity of the system cannot be guaranteed beyond this point
	while (1) {
		sleep(1000);
	}

#endif
#endif
#endif

}
//****************************************************************************
// BOOL AuthUserArea(T_AUTHENTICATION_AREAS Area)
///
/// Method is called to authenticate currently logged in user against permissions
/// 
//****************************************************************************
BOOL AuthUserArea(T_AUTHENTICATION_AREAS Area, CWidget *pkParent) {
#ifndef DOCVIEW
#ifndef V6IOTEST
#ifndef TTR6SETUP
	CPassAuthUI *pPass = CPassAuthUI::GetHandle();
	pPass->Initialise();
	return (BOOL) pPass->AuthenticateUserArea(Area, pkParent);
#else
		return TRUE;
	#endif
#else
		return TRUE;
	#endif
#else 
		return TRUE;
	#endif

}

//****************************************************************************
// BOOL HardwareSecurityLockEnabled(T_AUTHENTICATION_AREAS Area)
///
/// Method called if hardware security lock is enabled to avoid access for
// restricted area
/// 
//****************************************************************************
void HardwareSecurityLockEnabled(T_AUTHENTICATION_AREAS Area) {
#ifndef DOCVIEW
#ifndef V6IOTEST
#ifndef TTR6SETUP	

	//Check if the hardwarelock is disabled if yes 
	//then we do not allow the user to edit configuration
	CPassAuthUI *pAuthUIHandle = CPassAuthUI::GetHandle();
	BOOL bIsAreaUnrestricted = TRUE;

	if (pAuthUIHandle != NULL)
		bIsAreaUnrestricted = pAuthUIHandle->IsAreaUnRestricted(Area);

	//IsAreaAllowedWhenHLSet()
	//1) This function does check if the selected area is with in user Authentication list to proceed. 
	//2) There is an enum named "T_AUTHENTICATION_AREAS" which is used to set the selected area as secured.
	//3) Currently, both Hardware lock and User Authentication mechanism are tightly coupled to control the 
	//  areas by Setting the T_AUTHENTICATION_AREAS enum values.
	//4) This setting is done while starting of the each respective dialog is created. 
	//  There are some areas which requires User Authentication and also need to be allowed though hardware lock is set.
	//  As there is tightly coupled mechanism we had to identify a list of areas which requires user Authentication when 
	//  hardware lock is set and thus identified accordingly, those areas are listed in this function. When this function 
	//  returns true then it meant the area is allowable by prompting user authentication.
	//
	//For Ex: Menu>>Configure is allowable area when hardware lock is enabled. and in turn the behavior of this Configure 
	//area will remains same when password system is enabled or disabled. 

	if ((AUTHENTICATION_AREA_NO_AUTH != Area) && ( FALSE == pAuthUIHandle->IsAreaAllowedWhenHLSet(Area))) {
		if (!bIsAreaUnrestricted) {
			QString  strTitle("");
			strTitle = tr("Recorder Security");
			QString  strError("");
			strError = tr("Hardware Security Lock Enabled. Access denied.");
			CV6MessageBoxDlg kErrorDlg(strTitle, strError);
			kErrorDlg.exec();
		}
	}
#endif
#endif
#endif
}

//****************************************************************************
// void InitPassAuth()
///
/// Method is called to initialise the PassAuth singleton
/// 
//****************************************************************************
BOOL InitPassAuth() {
	BOOL Ret = TRUE;
#ifndef DOCVIEW
#ifndef V6IOTEST
#ifndef TTR6SETUP
	CPassAuthUI *pPass = CPassAuthUI::GetHandle();
	Ret = pPass->Initialise();
#endif
#endif
#endif
	return Ret;
}
//****************************************************************************
// void CleanUpPassAuth()
///
/// Method is called to destroy the PassAuth singleton cleanly
/// 
//****************************************************************************
void CleanUpPassAuth() {
#ifndef DOCVIEW
#ifndef V6IOTEST
#ifndef TTR6SETUP
	CPassAuthUI *pPass = CPassAuthUI::GetHandle();
	pPass->CleanUp();
#endif
#endif
#endif
}
void SetLayoutModified() {
#ifndef V6IOTEST
#ifndef TTR6SETUP
	CScrnDesCfgMgr *pkInstance = CScrnDesCfgMgr::Instance();
	pkInstance->SetModified(true); // mark as modified
#endif
#endif
}
const bool GetLayoutModified() {
	bool bRetVal = false;

#ifndef V6IOTEST
#ifndef TTR6SETUP
	CScrnDesCfgMgr *pkInstance = CScrnDesCfgMgr::Instance();
	bRetVal = pkInstance->GetModified(); // mark as modified
#endif
#endif
	return bRetVal;
}
void CommitLayoutChanges() {
#ifndef V6IOTEST
#ifndef TTR6SETUP
	CScrnDesCfgMgr *pkInstance = CScrnDesCfgMgr::Instance();
	pkInstance->CommitChanges();
#endif
#endif
}
void DiscardLayoutChanges() {
#ifndef V6IOTEST
#ifndef TTR6SETUP
	CScrnDesCfgMgr *pkInstance = CScrnDesCfgMgr::Instance();
	pkInstance->DiscardChanges();
#endif
#endif
}
//****************************************************************************
// const BOOL ShowHelp( CWidget *pkParentWnd, const QString   &rstrTOPIC, const QString   &rstrCHAPTER )
///
/// Method that shows the relevant help informartion based on the passed in chapter and topic
///
//****************************************************************************
const BOOL ShowHelp(CWidget *pkParentWnd, const QString  &rstrTOPIC, const QString  &rstrCHAPTER) {
	BOOL bRetVal = TRUE;

#ifndef DOCVIEW
#ifndef V6IOTEST
#ifndef TTR6SETUP

	CHelpViewerControlDlg *pkHelpDlg = new CHelpViewerControlDlg(pkParentWnd);

	// initialise the dialog, setting paths etc.
	pkHelpDlg->Initialize();

	// invoke the InvokeHelp method	
	bRetVal = pkHelpDlg->InvokeHelp(rstrTOPIC, rstrCHAPTER);

	delete pkHelpDlg;

#endif
#endif
#endif
	return bRetVal;
}
//****************************************************************************
// PMMSTATUS RemUsr(SHORT ID)
///
/// Method is called to remove a user from the PMM
/// 
//****************************************************************************
PMMSTATUS RemUsr(SHORT ID) {
	PMMSTATUS Ret = CSTATUS_OK;
#ifndef DOCVIEW
#ifndef V6IOTEST
#ifndef TTR6SETUP
	Ret = RemoveUser(ID);
#endif
#endif
#endif
	return Ret;
}
//****************************************************************************
// PMMSTATUS AddUsr(void* pData,SHORT* ID)
///
/// Method is called to Add a user to the PMM
/// 
//****************************************************************************
PMMSTATUS AddUsr(void *pData, SHORT *ID) {
	PMMSTATUS Ret = CSTATUS_OK;
#ifndef DOCVIEW
#ifndef V6IOTEST
#ifndef TTR6SETUP
	Ret = AddUser((T_USERDATA*) pData, ID);
#endif
#endif
#endif
	return Ret;
}
PMMSTATUS EnableFirstTimeUsr(BOOL bEn) {
	PMMSTATUS Ret = CSTATUS_OK;
#ifndef DOCVIEW
#ifndef V6IOTEST
#ifndef TTR6SETUP
	Ret = EnableFirstTimeUser((TV_BOOL) bEn);
#endif
#endif
#endif
	return Ret;
}
COEMInfo* GetOEMInfo(void) {

#ifdef TTR6SETUP
#ifdef DOCVIEW
#ifdef V6IOTEST
	return COEMInfo::Instance();
#endif
#endif
#endif

	return pSYSTEM_INFO->pOemInfo;
}

//****************************************************************************
// void ChangePassword()
///
/// Method is called to change a password in the PMM
/// 
//****************************************************************************
void ChangePassword(CWidget *pkParent) {
#ifndef DOCVIEW
#ifndef V6IOTEST
#ifndef TTR6SETUP
	CPassAuthUI *pPass = CPassAuthUI::GetHandle();
	QString  csPass;
	pPass->ChangePassword(csPass);
#endif
#endif
#endif
}
//****************************************************************************
// void LogOff()
///
/// Method is called to log off the PMM
/// 
//****************************************************************************
void PplLogOff() {
#ifndef DOCVIEW
#ifndef V6IOTEST
#ifndef TTR6SETUP
	CPassAuthUI *pAuth = CPassAuthUI::GetHandle();
	pAuth->LogOff();
#endif
#endif
#endif
}
//****************************************************************************
// TV_BOOL PplGetLoggedInUserName(QString   &csUser)
///
/// Method is called to find the text name of the currently logged in user
/// 
//****************************************************************************
BOOL PplGetLoggedInUserName(QString  &csUser) {
	BOOL Ret = FALSE;
#ifndef DOCVIEW
#ifndef V6IOTEST
#ifndef TTR6SETUP
	CPassAuthUI *pkUIInstance = CPassAuthUI::GetHandle();
	Ret = (BOOL) pkUIInstance->GetCurrentUserName(csUser);
#endif
#endif
#endif
	return Ret;
}
//****************************************************************************
// PMMSTATUS PplResetAccount(USHORT ID, WCHAR* strPwd,BOOL bReset)
///
/// Method is called to Reset the account of user after failed login attempts
/// 
//****************************************************************************
PMMSTATUS PplResetAccount(USHORT ID, QString strPwd, BOOL bReset) {
	PMMSTATUS Ret = CSTATUS_OK;
#ifndef DOCVIEW
#ifndef V6IOTEST
#ifndef TTR6SETUP
	Ret = ResetAccount(ID, strPwd, bReset);
#endif
#endif
#endif
	return Ret;
}
//****************************************************************************
// const bool GetNewRegistryStatus( )
///
/// Method that determines if the registry is new, usually following the NK.bin being updated
/// 
/// @return True is the registry is new
///
/// @NOTE	DO NOT CALL ME - USE DEVICE_INFO.IsNewRegistry() instead
///
//****************************************************************************
const bool GetNewRegistryStatus() {
	bool bNewRegistry = false;
#ifndef DOCVIEW
#ifndef V6IOTEST
#ifndef TTR6SETUP
	// get the registry status and reset the flag back to 'N' if it is 'Y'
	bNewRegistry = CRegistryKey::IsNewRegistry(true);
#endif
#endif
#endif
	return bNewRegistry;
}
//****************************************************************************
// void PasswordUpdateUserAccess( void )
///
/// Updates the user access on the PassAuthUI
/// 
/// @return none
///
//****************************************************************************
void PasswordUpdateUserAccess(void) {
#ifndef TTR6SETUP
#ifndef V6IOTEST
#ifndef DOCVIEW
	//get a ptr to the PassAuthUI 
	CPassAuthUI *pPass = CPassAuthUI::GetHandle();

	//let the password system know
	if ((pPass != NULL) && (((CPassAuthUI*) pPass)->IsInitialised())) {
		((CPassAuthUI*) pPass)->UpdateUserAccess();
	}
#endif
#endif
#endif
}

//****************************************************************************
// void RequestObjectUpdateOPCPenConfig( const short& sInstance )
///
/// Updates the OPC Pen config using the passed instance
/// 
/// @return none
///
//****************************************************************************
void RequestObjectUpdateOPCPenConfig(const short &sInstance) {
#ifndef TTR6SETUP
#ifndef V6IOTEST
#ifndef DOCVIEW
	//get a ptr to the PassAuthUI 
	CRequestObject::UpdateOPCPenConfig(sInstance);
#endif
#endif
#endif
}
//****************************************************************************
// BOOL PPLSetPolicy(void* pPolicy)
///
/// Sets the policy section of the PMM
/// 
/// @return TRUE if successful
///
//****************************************************************************
BOOL PPLSetPolicy(void *pPolicy) {
	PMMSTATUS ret = CSTATUS_OK;
#ifndef DOCVIEW
#ifndef V6IOTEST
#ifndef TTR6SETUP
	ret = SetPolicy((T_PMMPOLICYDATA*) pPolicy);
#endif
#endif
#endif
	if (CSTATUS_OK == ret)
		return TRUE;
	else
		return FALSE;

}
//****************************************************************************
// void ShowRestartDialog()
///
/// Method that shows the restart dialog on the recorder applications
///
//****************************************************************************
void ShowRestartDialog() {
#ifndef DOCVIEW
#ifndef V6IOTEST
#ifndef TTR6SETUP
	QString  strRestartTitle("");
	QString  strRestartUserText("");
	strRestartTitle = tr("Restart required");
	strRestartUserText = tr("Configuration changes require a restart, this will be performed automatically");

	CAnimatedProgressDlg kShutDownDlg(AfxGetApp()->m_pMainWnd, strRestartTitle, strRestartUserText, 5000, 500);
	kShutDownDlg.exec();
#endif
#endif
#endif
}

//****************************************************************************
// void ShowErrorDialog( const QString   &rstrTITLE, const QString   &rstrMESSAGE )
///
/// Method that shows an error dialog
///
/// @param[in]			const QString   &rstrTITLE - The title of the dialog
/// @param[in]			const QString   &rstrMESSAGE - The error message to display
/// @param[in]			CWidget *pkParent - Pointer ot the parent window
///
//****************************************************************************
void ShowErrorDialog(const QString  &rstrTITLE, const QString  &rstrMESSAGE, CWidget *pkParent) {
#ifndef DOCVIEW
#ifndef V6IOTEST
#ifndef TTR6SETUP
	CV6MessageBoxDlg kError(rstrTITLE, rstrMESSAGE, pkParent);
	kError.exec();
#endif
#endif
#endif
}

void UpdateOPCConfig(void) {
#ifndef TTR6SETUP
#ifndef DOCVIEW
#ifndef V6IOTEST
	CRequestObject::UpdateOPCGroupConfig();
#endif
#endif
#endif
}
//****************************************************************************
//	void UpdateTimeInformation()
///
/// Method that applies any time changes to the recorder only - ignored on the PC
///
//****************************************************************************
void UpdateTimeInformation() {
#ifdef UNDER_CE
#ifndef V6IOTEST
	// apply any changes that may require external data to be updated e.g. time zones and daylight saving
	CRecSetupCfgMgr *pkMgr = CRecSetupCfgMgr::Instance();
	pkMgr->UpdateTimeInformation();
	
#endif
#endif
}

//****************************************************************************
//	void GetV6LocalTime( const QDateTime* lpSystemTime )
///
/// Method that gets the local time on the PC or Desktop
///
//****************************************************************************
void GetV6LocalTime(QDateTime *lpSystemTime) {
	QTime tvTime;
	tvTime.TimeNow();
	tvTime.GetSYSTEMTIME(lpSystemTime);
}
//****************************************************************************
//	BOOL SetV6LocalTime( const QDateTime* lpSystemTime )
///
/// Method that sets the local time on the PC or Desktop
///
//****************************************************************************
BOOL SetV6LocalTime(const QDateTime *lpSystemTime) {
	LONGLONG llSetTime = 0;
	LONGLONG llTimeNow = 0;

	SystemTimeToFileTime(lpSystemTime, (FILETIME*) &llSetTime);

	BOOL bRetVal = SetLocalTime(lpSystemTime);

	sleep(500);

	QDateTime tLocalTimeNow;

	GetLocalTime(&tLocalTimeNow);

	SystemTimeToFileTime(&tLocalTimeNow, (FILETIME*) &llTimeNow);

	LONGLONG llDiff = (llSetTime - llTimeNow);
	// convert the time into seconds rather than nanseconds
	llDiff /= 10000000;

	// check if the time is greater than a minute out in which case we can assume daylight saving must have been
	// applied
	if ((llDiff > 60) || (llDiff < -60)) {
		// call the set time method again to get around any daylight saving problems
		bRetVal = SetLocalTime(lpSystemTime);
	}

	return bRetVal;
}
//****************************************************************************
//	BOOL SetV6SystemTime( const QDateTime* lpSystemTime )
///
/// Method that sets the system time on the PC or Desktop
///
//****************************************************************************
BOOL SetV6SystemTime(const QDateTime *lpSystemTime) {
	BOOL bRetVal = SetSystemTime(lpSystemTime);
#ifdef UNDER_CE
	
	// need to call this method to update the RTC on the embedded platform
	CDeviceAbstraction *pkDal = pDEVICE_INFO->GetDalPtr();

	pkDal->SyncTime();
#endif
	return bRetVal;
}
//****************************************************************************
//	void StartDaylightSavingThread()
///
/// Method that starts the daylight saving thread on a CE device
///
//****************************************************************************
void StartDaylightSavingThread() {
#ifdef UNDER_CE
#ifndef V6IOTEST
	QThread *pkThread = AfxBeginThread( CDSTChangeNotificationThread::DSTChangeNotificationFunc, 
											NULL, 
											THREAD_PRIORITY_NORMAL, 
											0, 
											CREATE_SUSPENDED, 
											NULL );

	pkThread->m_bAutoDelete = TRUE;
	pkThread->ResumeThread();
#endif
#endif
}
//****************************************************************************
//	void ShutdownDaylightSavingThread()
///
/// Method that shuts down the daylight saving thread on a CE device
///
//****************************************************************************
void ShutdownDaylightSavingThread() {
#ifdef UNDER_CE
#ifndef V6IOTEST
	CDSTChangeNotificationThread::ShutdownThread();
#endif
#endif
}
//****************************************************************************
//	void ReInitialiseDSTEvent()
///
/// Method that reinitialises the daylight saving event time
///
//****************************************************************************
void ReInitialiseDSTEvent() {
#ifdef UNDER_CE
#ifndef V6IOTEST
	// ----------------------------------------------------------------------------------------------------------
	// The call to this function has been stopped as the thread responsible for handling DST/SDT is now handled 
	// in WinCE OS ..
	// ----------------------------------------------------------------------------------------------------------
	//CDSTChangeNotificationThread::ReInitialiseEvent();

#endif
#else
	pSYSTIMER->RegisterATimeChange();
#endif
}
//****************************************************************************
//	void StartTimeChangeThread()
///
/// Method that starts the time change monitoring thread on a CE device
///
//****************************************************************************
void StartTimeChangeThread() {
#ifdef UNDER_CE
#ifndef V6IOTEST
	QThread *pkThread = AfxBeginThread( CTimeChangeNotifyThread::TimeChangeNotifyFunc, 
											NULL, 
											THREAD_PRIORITY_NORMAL, 
											0, 
											CREATE_SUSPENDED, 
											NULL );

	pkThread->m_bAutoDelete = TRUE;
	pkThread->ResumeThread();
#endif
#endif
}
//****************************************************************************
//	void ShutdownTimeChangeThread()
///
/// Method that shuts down the time change monitoring thread on a CE device
///
//****************************************************************************
void ShutdownTimeChangeThread() {
#ifdef UNDER_CE
#ifndef V6IOTEST
	CTimeChangeNotifyThread::ShutdownThread();
#endif
#endif
}

//****************************************************************************
// PMMSTATUS PPLUndoSetPolicy()
///
/// Method is called to undo a changes made to policy after a failed policy change
/// 
//****************************************************************************
PMMSTATUS PPLUndoSetPolicy() {
	PMMSTATUS Ret = CSTATUS_OK;
#ifndef DOCVIEW
#ifndef V6IOTEST
#ifndef TTR6SETUP
	Ret = UndoSetPolicy();
#endif
#endif
#endif
	return Ret;
}
//****************************************************************************
// BOOL PPLTestAreaUnrestricted()
///
/// Determine if an area has been marked as unrestricted
/// 
//****************************************************************************
BOOL PPLTestAreaUnrestricted(T_AUTHENTICATION_AREAS Area, bool *bRes) {
	BOOL Ret = FALSE;
#ifndef TTR6SETUP
#ifndef V6IOTEST
#ifndef DOCVIEW
	//get a ptr to the PassAuthUI 
	CPassAuthUI *pPass = CPassAuthUI::GetHandle();

	//let the password system know
	if ((pPass != NULL) && (pPass->IsInitialised())) {
		Ret = pPass->TestAreaUnrestricted(Area, bRes);
	}
#endif
#endif
#endif
	return Ret;

}
//****************************************************************************
// void PplEnterFileCS()
///
/// Enter the PPL file critical section (and initialise if not already)
/// 
//****************************************************************************
void PplEnterFileCS() {
#ifndef TTR6SETUP
#ifndef V6IOTEST
#ifndef DOCVIEW
	if (!bFileCsInit) {
		QMutex* csPplFile;
		bFileCsInit = TRUE;
	}
	csPplFile.lock();
#endif
#endif
#endif
}
//****************************************************************************
// void PplLeaveFileCS()
///
/// Leave the PPL file critical section
/// 
//****************************************************************************
void PplLeaveFileCS() {
#ifndef TTR6SETUP
#ifndef V6IOTEST
#ifndef DOCVIEW
	csPplFile.lock();
#endif
#endif
#endif
}
//****************************************************************************
// PMMSTATUS PplExpirePassword()
///
/// PMM wrapper to force a password expire
/// 
//****************************************************************************
PMMSTATUS PplExpirePassword(USHORT ID) {
	PMMSTATUS Ret = CSTATUS_OK;
#ifndef DOCVIEW
#ifndef V6IOTEST
#ifndef TTR6SETUP
	Ret = ExpirePassword(ID);
#endif
#endif
#endif
	return Ret;
}

//**********************************************************************
// void UpdateTouchscreenCalInfo()
///
/// Method that updates the touchscreen calibration information
/// Revision: Channabasavaraj R has modified this function to fix the initial
/// touch screen calibration problem - 1-1RLTOOO
//**********************************************************************
void UpdateTouchscreenCalInfo() {
#ifndef DOCVIEW
#ifndef V6IOTEST
#ifndef TTR6SETUP
	// WARNING: This method is called very early on - when code is added
	// please check any globals used have defintely been initialised

	// create the calibration filename
	WCHAR wcaCalibrationFileName[ MAX_PATH];
	int iPathLen = MAX_PATH;
	BOOLEAN isDeleteRequired = FALSE;
	pDALGLB->GetPath(static_cast<T_STORAGE_PATH>(IDS_INTERNAL_SD), wcaCalibrationFileName,
	MAX_PATH, &iPathLen);
	wcsncat(wcaCalibrationFileName, MAX_PATH, L"CalibrationData.dat", MAX_PATH - wcslen(wcaCalibrationFileName));
	CStorage kCalibrationFile;
	FileException kFileEx;

	// check if we have got new registry hive, if yes then update the registry calibration
	// settings, because the old settings will have bene wiped
	if ( DEVICE_INFO.IsNewRegistry()) {

		DWORD dwSize = 0;
		const int iCAL_DATA_LEN = 100;
		WCHAR wcaCalibrationData[iCAL_DATA_LEN];
		// check if a calibration file exists
		if (kCalibrationFile.FileExists(wcaCalibrationFileName)) {	//Do nothing
		} else {
			memset(wcaCalibrationData, 0, iCAL_DATA_LEN * sizeof(WCHAR));
			// Create the file and keep the default value
			T_DEV_TYPE devType = pDEVICE_INFO->GetDeviceType();

			if (devType == DEV_ARISTOS_MULTIPLUS) {	//GR Multi
													//If Big screen load the below default touch screen values
				wcscpy_s(wcaCalibrationData, _countof(wcaCalibrationData), L"492,497 212,766 215,222 773,233 765,767"); //776903 : Converity Fix - E374454
			} else if (devType == DEV_SCR_MINITREND) { //SCR MiniTrend (DRG2)
				wcscpy_s(wcaCalibrationData, _countof(wcaCalibrationData), L"509,520 243,791 243,253 775,251 775,788"); //776903 : Converity Fix - E374454
			} else { //GR Mini or Ez
				wcscpy_s(wcaCalibrationData, _countof(wcaCalibrationData), L"499,493 223,752 224,230 772,223 773,747"); //776903 : Converity Fix - E374454
			}
			if (kCalibrationFile.Open(wcaCalibrationFileName, CStorage::modeCreate | CStorage::WriteOnly, &kFileEx)) {
				//Converting the WCHAR to CHAR Len
				int tempCharLen = wcslen(wcaCalibrationData) * 2;

				if (kCalibrationFile.Write(wcaCalibrationData, tempCharLen) != ERROR_SUCCESS) {
					qDebug("Failed to update the touchscreen calibration file with the current calibration data\n");
				}
				kCalibrationFile.Close();
			} else {
				qDebug("Could not create/open the calibration file");
			}
		}

		// check if a calibration file exists
		if (kCalibrationFile.FileExists(wcaCalibrationFileName)) {
			// yes the file exists therefore update the registry with the saved information
			if (kCalibrationFile.Open(wcaCalibrationFileName, CStorage::ReadOnly, &kFileEx)) {
				// write the calibration information to the registry
				CRegistryKey kWriteCalRegKey;
				if (kWriteCalRegKey.OpenKey(L"HARDWARE\\DEVICEMAP\\TOUCH")) {
					memset(wcaCalibrationData, 0, iCAL_DATA_LEN * sizeof(WCHAR));
					const ULONG ulFILE_LENGTH = static_cast<ULONG>(kCalibrationFile.size());

					//assert( ( iCAL_DATA_LEN * sizeof( WCHAR ) ) > ulFILE_LENGTH );
					// if(ulFILE_LENGTH == TOUCH_CAL_DATA_LEN)
					{					//Check if the size of data not TOUCH_CAL_DATA_LEN
						if (kCalibrationFile.Read(wcaCalibrationData, ulFILE_LENGTH)) {
							DWORD dwType = REG_SZ;
							if (kWriteCalRegKey.WriteValue(L"CalibrationData", dwType,
									reinterpret_cast<BYTE*>(wcaCalibrationData), ulFILE_LENGTH)) {
								//kWriteCalRegKey.Flush();
							} else {
								qDebug("Failed to update touchscreen calibration information within the registry\n");
							}

						} else {
							// Failed to read the calibration file correctly
							qDebug("Failed to read the touchscreen calibration file correctly");
						}
					}
					/*else
					 {//The size cant be other than TOUCH_CAL_DATA_LEN, which means the file is modified. 
					 //Delete this file.
					 //The file will be created upon next restart OR Re-calibration
					 qDebug("Calibration file modified OR corrupted - re-calibration required" );
					 isDeleteRequired = TRUE;
					 }*/
					kWriteCalRegKey.Close();
				} else {
					qDebug("Could not open the touchscreen registration file");
				}
				// now close the file
				kCalibrationFile.Close();
				if (TRUE == isDeleteRequired) {
					kCalibrationFile.DeleteFileW(wcaCalibrationFileName);
				}
			} else {		//The file is already created, it should never come here, unless some error in creating file
				qDebug("Could not open the touchscreen calibration file for reading");
			}
		} else {
			qDebug("Could not open the touchscreen calibration file - It should never happen");
		}
	}
	// now save out the current calibration values
	if (kCalibrationFile.Open(wcaCalibrationFileName, CStorage::modeCreate | CStorage::WriteOnly, &kFileEx)) {
		// write the calibration information to this file
		CRegistryKey kReadCalRegKey;
		if (kReadCalRegKey.OpenKey(L"HARDWARE\\DEVICEMAP\\TOUCH")) {
			DWORD dwSize = 0;
			DWORD dwType = REG_SZ;
			// get the size of the data first
			kReadCalRegKey.ReadValue(L"CalibrationData", &dwType, NULL, &dwSize);

			int iStrLen = dwSize / sizeof(WCHAR);
			QString pwcCalibrationData = new WCHAR[iStrLen + 1];
			memset(pwcCalibrationData, 0, dwSize);
			if (kReadCalRegKey.ReadValue(L"CalibrationData", &dwType, reinterpret_cast<BYTE*>(pwcCalibrationData),
					&dwSize)) {
				if (kCalibrationFile.Write(pwcCalibrationData, dwSize) != ERROR_SUCCESS) {
					qDebug("Failed to update the touchscreen calibration file with the current calibration data\n");
				}
			} else {
				qDebug("Failed to read the touchscreen calibration information from the registry\n");
			}
			kReadCalRegKey.Close();
			delete[] pwcCalibrationData;
		} else {
			// failed to open the calibration registry key
			qDebug("Failed to open the touchscreen calibration registry key");
		}

		// now close the file
		kCalibrationFile.Close();
	} else {
		qDebug("Could not create/open the calibration file");
	}
#endif
#endif
#endif
}
//****************************************************************************
// const QString   GetScreenList(	const bool bINCLUDE_DISABLED /* = false */,
//									const bool bAPPEND_SCREEN_IDS /* = false */ ) const
///
/// Method that gets a delimited list of all the screen names
///
/// @param[in]		const bool bINCLUDE_DISABLED - Flag indicating if we want to include the disabled
///					screens in the list too
/// @param[in]		const bool bAPPEND_SCREEN_IDS - Flag indicating we want the screen ID's to be
///					embedded at the end of the screen name
///
/// @return		a Delimitted list containing the screen names
///
//****************************************************************************
const QString  GetScreenList(const bool bINCLUDE_DISABLED /* = false */, const bool bAPPEND_SCREEN_IDS /* = false */) {
	QString  strScreenList("");
#ifndef V6IOTEST
#ifndef TTR6SETUP
	COpPanel *pkOpPanel = reinterpret_cast<COpPanel*>(AfxGetApp()->m_pMainWnd);
	strScreenList = pkOpPanel->GetScreenList(bINCLUDE_DISABLED, bAPPEND_SCREEN_IDS);
#endif
#endif
	return strScreenList;
}


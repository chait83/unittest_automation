/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Porting layer
/// @n Filename: OPL.h
/// @n Desc:	 Routines to resolve any Product usage differences
///					between application dependents
// 
//  ****************************************************************
//  Revision History
//  ****************************************************************
//  $Log[4]:
// 40  Stability Project 1.37.1.1 7/2/2011 4:59:46 PM Hemant(HAIL) 
//  Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
// 39  Stability Project 1.37.1.0 7/1/2011 4:27:26 PM Hemant(HAIL) 
//  Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
// 38  V6 Firmware 1.37 9/1/2006 5:27:52 PM Roger Dawson 
//  Added code that allows print error messages to be displayed in a
//  thread safe manner. This was to prevent problems where print screen
//  error messages generated in a sepearate thread would lose focus and
//  disappear being the application.
// 37  V6 Firmware 1.36 8/16/2006 7:05:01 PM  Roger Dawson 
//  Added function for getting a delimitted list of the screen names.
//  $
//
//  ****************************************************************

#ifndef __PPL_H__
#define __PPL_H__
#include "PassAuthDefines.h"
#include "PassiveModule.h"
#include "PMMglobal.h"
#include "OEMInfo.h"
#include "Widget.h"

BOOL IsRunningAsATEEquipment(void);
BOOL SetATEUUTCardNo(UCHAR cardNo);
void AddSystemErrorToReport(LPCTSTR lpszFormat, ...);
void AddSystemWarningToReport(LPCTSTR lpszFormat, ...);
void AddSystemInfoToReport(LPCTSTR lpszFormat, ...);
void AddErrorToReport(LPCTSTR lpszFormat, ...);
void AddErrorToReportAsError(LPCTSTR lpszFormat, ...);
void LogInternalError(QString lpszFormat, ...);

#ifdef V6IOTEST
extern WCHAR errorFileName[];
void WriteStringToErrorReportFile( LPCTSTR lpszFormat );
#endif

// Method is called when the system has failed to load the external resource pack
void FailedToLoadExtResPack();

BOOL FindTestEquipmentCommPort(int &thePort);
USHORT QualifyChanWithIOSchedHW(const USHORT slotNumber, const USHORT chanNumber, USHORT chanType);
BOOL AuthUserArea(T_AUTHENTICATION_AREAS Area, CWidget *pkParent = NULL);

BOOL InitPassAuth(void);
void CleanUpPassAuth(void);

void SetLayoutModified();
const bool GetLayoutModified();
void CommitLayoutChanges();
void DiscardLayoutChanges();
PMMSTATUS RemUsr(SHORT ID);
PMMSTATUS AddUsr(void *pData, SHORT *ID);
void ChangePassword(CWidget *pkParent = NULL);

void PplLogOff();
PMMSTATUS PplResetAccount(USHORT ID, WCHAR *strPwd, BOOL bReset);
BOOL PplGetLoggedInUserName(QString  &csUser);
BOOL PPLSetPolicy(void *pPolicy);

COEMInfo* GetOEMInfo(void);

void PasswordUpdateUserAccess(void);
void RequestObjectUpdateOPCPenConfig(const short &sInstance);

/// Method that shows the relevant help informartion based on the passed in chapter and topic
const BOOL ShowHelp(CWidget *pkParentWnd, const QString  &rstrTOPIC, const QString  &rstrCHAPTER);

// Method that shows an error dialog
void ShowErrorDialog(const QString  &rstrTITLE, const QString  &rstrMESSAGE, CWidget *pkParent);

// Method that shows the restart dialog on the recorder applications
void ShowRestartDialog();

// method to update the OPC Group Config
void UpdateOPCConfig(void);

PMMSTATUS EnableFirstTimeUsr(BOOL bEn);

// Method that applies any time changes to the recorder only - ignored on the PC
void UpdateTimeInformation();

void GetV6LocalTime(QDateTime *lpSystemTime);

// Method that sets the local time on the PC or Desktop
BOOL SetV6LocalTime(const QDateTime *lpSystemTime);

// Method that sets the system time on the PC or Desktop
BOOL SetV6SystemTime(const QDateTime *lpSystemTime);

// Method that starts the daylight saving thread on a CE device
void StartDaylightSavingThread();

// Method that starts the daylight saving thread on a CE device
void ShutdownDaylightSavingThread();

// Method that reinitialises the daylight saving event time
void ReInitialiseDSTEvent();

// Method that starts the time change monitoring thread on a CE device
void StartTimeChangeThread();

// Method that shuts down the time change monitoring thread on a CE device
void ShutdownTimeChangeThread();

// Method is called to undo a changes made to policy after a failed policy change
PMMSTATUS PPLUndoSetPolicy();

// Enter the PPL file critical section (and initialise if not already)
void PplEnterFileCS();

// Leave the PPL file critical section
void PplLeaveFileCS();

// PMM wrapper to force a password expire
PMMSTATUS PplExpirePassword(USHORT ID);

// Determine if an area has been marked as unrestricted
BOOL PPLTestAreaUnrestricted(T_AUTHENTICATION_AREAS Area, bool *bRes);

// Method that updates the touchscreen calibration information
void UpdateTouchscreenCalInfo();

// Method that determines if the registry is new, usually following the NK.bin being updated
const bool GetNewRegistryStatus();

// Method that gets a delimited list of all the screen names
const QString  GetScreenList(const bool bINCLUDE_DISABLED = false, const bool bAPPEND_SCREEN_IDS = false);

//Method  called if hardware security lock is enabled to avoid access for
//  restricted area
void HardwareSecurityLockEnabled(T_AUTHENTICATION_AREAS Area);

#endif // __PPL_H__


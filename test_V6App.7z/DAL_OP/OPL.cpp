/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Porting layer
/// @n Filename: OPL.cpp
/// @n Desc:	 Routines to resolve any OS call difference between WinCE and Desktop Windows
///
// 
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  12  Stability Project 1.7.1.3 7/2/2011 4:59:18 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  11  Stability Project 1.7.1.2 7/1/2011 4:38:33 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  10  Stability Project 1.7.1.1 3/17/2011 3:20:32 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  9 Stability Project 1.7.1.0 2/15/2011 3:03:34 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// ****************************************************************

#include "opl.h"

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif

//****************************************************************************
//	void DoubleBufferStatusList()
///
/// To allow the updated status list items to be double buffered - ignored on the PC
///
//****************************************************************************
void DoubleBufferStatusList(QListView &rkStatusList) {
#ifdef CE_USE
	rkStatusList.SetExtendedStyle( LVS_EX_DOUBLEBUFFER | LVS_EX_FULLROWSELECT );
#else
	rkStatusList.SetExtendedStyle(LVS_EX_FULLROWSELECT);
#endif
}
#ifdef UNDER_CE

//****************************************************************************
///
//// Method that checks the length of a string safely - CE replacement for wcsnlen
///
/// @param[in]		const QString  const pwcBufferToTest - The strings who's length we wish to find
/// @param[in]		const USHORT usMAX_BUFF_LEN - The length of the passed in buffer
///
/// @return			The length of the string or max length is no NULL terminator was found
///
//****************************************************************************
const USHORT wcsnlen( const QString  const pwcBufferToTest, const USHORT usMAX_BUFF_LEN )
{
	USHORT usCount = 0;

	for(usCount = 0; usCount < usMAX_BUFF_LEN; usCount++ )
	{

		if( pwcBufferToTest[ usCount ] == L'\0' )
		{
			// we have found the null terminator therefore break from the loop
			break;
		}
	}

	return usCount;
}
#endif


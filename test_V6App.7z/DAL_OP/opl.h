/// @file 
/// ****************************************************************
/// Â© Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Porting layer
/// @n Filename: OPL.h
/// @n Desc:	 Routines to resolve any OS call difference between WinCE and Desktop Windows
///
// 
//  ****************************************************************
//  Revision History
//  ****************************************************************
//  $Log[4]:
// 10  Stability Project 1.7.1.1  7/2/2011 4:59:18 PM Hemant(HAIL) 
//  Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
// 9 Stability Project 1.7.1.0  7/1/2011 4:26:55 PM Hemant(HAIL) 
//  Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
// 8 V6 Firmware 1.7  10/3/2007 2:12:07 PM  Roger Dawson 
//  Added the wcsnlen function to the OPL as it does not exist in windows
//  CE. Required for a fix to the password system.
// 7 V6 Firmware 1.6  7/12/2006 5:57:56 PM  Roger Dawson 
//  Auto Ops/FTP additions.
//  $
//
//  ****************************************************************

#ifndef __OPL_H__
#define __OPL_H__

// Cause by #define EMULATOR in dal.h
// If running on a PC being compiled under visual studio the PC_USE define will be set. 
// This will use routines in OPL.cpp
#ifndef UNDER_CE
#define PC_USE				///< Set when being used on PC under desktop OS			
#else
#define CE_USE				///< Set when being used on PC under windows CE emulator		
#endif

#ifdef UNDER_CE
#if _WIN32_WCE < 500
#define DT_END_ELLIPSIS 0
#endif
#endif
#include <QListView>
/// Allows the updated status list items to be double buffered - ignored on the PC
void DoubleBufferStatusList(QListView &rkStatusList);

#ifdef UNDER_CE
/// Method that checks the length of a string safely - CE replacement for wcsnlen
const USHORT wcsnlen( const WCHAR * const pwcBufferToTest, const USHORT usMAX_BUFF_LEN );
#endif

#endif // __OPL_H__

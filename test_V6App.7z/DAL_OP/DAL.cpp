/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 System Absraction layer
/// @n Filename: DAL.cpp
/// @n Desc:	 Routines to wrap any hardware calls to allow emulator and
///				 recompilation on the PC under Visual Studio
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 18-09-15 Rajanbabu M Added method GetSecondaryProcFWVersion() to fetch secondary firmware version dynamically
// 05-11-14 Rajanbabu M Fixed PAR:1-3K94B3B - I/O inputs are not sensed and displayed on eZ Recorder.
// 20-10-14 Rajanbabu M Fixed PAR:1-3I2GTSM - WSD communication is not working on upgrading the firmware
//  139  Aristos  1.128.1.6.1.2 9/21/2011 2:51:42 PM  Hemant(HAIL)  
//  Resolved disable watchdog issue during firmware upgrade
//  138  Aristos  1.128.1.6.1.1 9/21/2011 12:52:01 PM  Hemant(HAIL)  
//  Error checking condition has been added for Disable WatchDog call.
//  137  Aristos  1.128.1.6.1.0 9/19/2011 4:51:10 PM  Hemant(HAIL)  
//  Stability recorder source code (JI Release) updated for WatchDog
//  Timer functionality.
//  136  Stability Project 1.128.1.6  7/4/2011 3:38:14 PM Hemant(HAIL) 
// Preprocessor definition added to access "storeapi.lib" from
//  different applications.
// $
//
// ****************************************************************

#include "dal.h"
#include "BootData.h"
#include "Sram.h"
#include "Tv6Timer.h"
#include "V6globals.h"
#include "CertSubjectsStore.h"
#include "..\Utilities\Crypto.h"
#ifdef UNDER_CE
#include "ntddndis.h"
#include "nuiouser.h"
#endif 
#ifndef IS_BOOTLACE_APP	// Bootlace app doesnt know about CSysInfo
#include "SysInfo.h"
extern CSysInfo *pGlbSysInfo;
#else
#include "BaseProtocol.h"
#endif
#define BOOT_FROM_SD 4

#include "BatteryManager.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif

HANDLE hCSPI;
//typedef HANDLE (*CSPIOPENHANDLE)(LPCWSTR lpDevName);
//typedef DWORD (*SPIWRITE) (HANDLE hCSPI, LPCVOID pBuffer, DWORD dwNumBytes, byte slotID);// typedefs move to dal.h
//typedef DWORD (*SPIREAD) (HANDLE hCSPI, LPCVOID pBuffer, DWORD* dwNumBytes, byte slotID);
SPIWRITE pfSPIWrite;
SPIREAD pfSPIRead;

//typedef BOOL (*CSPICLOSEHANDLE)(HANDLE spiDeviceHandle);

#define iMX53_GET_FW_VERSION 0xB1

#ifdef UNDER_CE
#include "Msgqueue.h"
//PSR - PrintCE SDK integration for PCL5 support begin
#include "PrintCEWrapper.h"
//PSR - PrintCE SDK integration for PCL5 support end
#endif // UNDER_CE

#define SHOW_IO_PROTOCOL_IN_DEBUG	0			// Display the IO protocol in dubug mode, if set to 1
QMutex m_hLEDIO;
const DWORD g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS = 5000;
CSPIOPENHANDLE pfCSPIOpenHandle;
CSPICLOSEHANDLE pfCSPICloseHandle;

#ifdef UNDER_CE

//Open interface for NOR Flash
typedef HANDLE (*InterfaceOpen)(void);
//Close interface for NOR Flash
typedef BOOL (*InterfaceClose)(HANDLE Interfacedll);
InterfaceOpen	 pfInterfaceOpen;
InterfaceClose	 pfInterfaceClose;
typedef BOOL (*WriteNORFlashBlock)(HANDLE h_Interface_g, PSPIFMD_BLOCK spiFmdBlock);
typedef BOOL (*ReadNORFlashBlock)(HANDLE h_Interface_g, PSPIFMD_BLOCK spiFmdBlock);
typedef BOOL (*NorFlashStoreSplashScreen)(HANDLE h_Interface_g, BYTE *pBuffer,ULONG sizeReq);
WriteNORFlashBlock		pfWriteNORFlashBlock;
ReadNORFlashBlock		pfReadNORFlashBlock;
NorFlashStoreSplashScreen pfNORFlashStoreSplashScreen;

typedef BOOL (*GetActiveImageVersion)(HANDLE h_Interface_g, PBSP_VERSION pBspVersion);
GetActiveImageVersion pfGetActiveImageVersion;

//PSR Fix for - 1-3DXWHML - QXe_General Status shows Expansion Board and Comms Board as connected though Support is removed begin
//This is new API added to InterfaceSDK.dll to get the status of the Backplane (Expansion) card. This is mostly for Ez recorder
//Because the Sx/QX always have the card fitted. For Ez alone this card is optional 
typedef BOOL (*GetBackPlaneBoardStatus) (HANDLE h_Interface_g, BYTE *bStatus);
GetBackPlaneBoardStatus pfGetBackPlaneBoardStatus;
//PSR Fix for - 1-3DXWHML - QXe_General Status shows Expansion Board and Comms Board as connected though Support is removed end

//PSR -Fix for 1-3E7Y0UX - SX/QX_"Common alarm" output configuration is missing from soft (pens) alarm begin
//Two more APIs added to InterfaceSdl.dll for addressing the Power relay in SX/QX
//This PAR will be addressed as part of SX/QX Maintainance PAR fixes. But OS changes received now.
typedef BOOL (*GetPowerRelayIOPinStatus) (HANDLE h_Interface_g, BYTE *bStatus);
typedef BOOL (*TogglePowerRelayIOPin) (HANDLE h_Interface_g);

//Global function pointers to get and set the PowerRelay pin status
GetPowerRelayIOPinStatus pfGetPowerRelayIOPinStatus;
TogglePowerRelayIOPin pfTogglePowerRelayIOPin;
//PSR -Fix for 1-3E7Y0UX - SX/QX_"Common alarm" output configuration is missing from soft (pens) alarm end

//Added for DRG1 Support
typedef BOOL (*SCRDisplayDetectionStatus)(HANDLE h_Interface_g, BYTE *bStatus);
SCRDisplayDetectionStatus pfSCRDisplayDetectionStatus;

#endif

// ************ Target Specific *************************************************************
#ifdef V6_TARGET	
#pragma message( "DAL V6 TARGET BUILD" )
#undef _MIPS_
#define _MIPS_ 1	///< Redefine MIPS to avoid problem in nkintr.h, see Topic 209 in V6 Firmware project in Starteam
// Platform includes
#include "ioctl.h"
#include "PwinUser.h"
#include "..\\..\\Tools\\asprintf\\asprintfdisk.h"
#include "..\\..\\Tools\\asprintf\\StoreMgr.h"

//
// Stability Project Fix:
//
#ifdef _LIB_FOR_V6APP_
#pragma comment(lib,"..\\..\\..\\Tools\\asprintf\\libs\\retail\\storeapi.lib")	// for V6App (default path)
#endif

#ifdef _LIB_FOR_FWUPGRADE_
#pragma comment(lib,"..\\..\\asprintf\\libs\\retail\\storeapi.lib")	// for FirmwareUpgrade
#endif

#ifdef _LIB_FOR_BOOTLACE_
#pragma comment(lib,"..\\asprintf\\libs\\retail\\storeapi.lib")	// For Bootlace
#endif


extern "C"
{
	BOOL KernelIoControl(DWORD, LPVOID, DWORD, LPVOID, DWORD, LPDWORD );
}

WCHAR V6internalCF[MAX_SD_VOLUME_LEN]	= (L"\\SDMemory\\");
WCHAR V6externalCF[MAX_SD_VOLUME_LEN]	= (L"\\SDMemory2\\");
WCHAR V6usbkey1[MAX_SD_VOLUME_LEN]	= (L"\\Hard Disk\\");
WCHAR V6usbkey2[MAX_SD_VOLUME_LEN]	= (L"\\Hard Disk2\\"); 
WCHAR V6ROOT[MAX_SD_VOLUME_LEN]	= (L"\\"); 


// ************ Emulator Specific *************************************************************
#else		
#ifdef ARISTOS
#include "ioctl.h"
#pragma message( "DAL V6 TARGET BUILD" )
#undef _MIPS_
#define _MIPS_ 1	///< Redefine MIPS to avoid problem in nkintr.h, see Topic 209 in V6 Firmware project in Starteam
// Platform includes
#include "ioctl.h"
#include "PwinUser.h"
//#include "asprintfdisk.h"
#include "StoreMgr.h"

//
// Stability Project Fix:
//
#ifdef _LIB_FOR_V6APP_
#pragma comment(lib,"..\\..\\Tools\\asprintf\\libs\\retail\\storeapi.lib")	// for V6App (default path)
#endif

#ifdef _LIB_FOR_FWUPGRADE_
#pragma comment(lib,"..\\..\\asprintf\\libs\\retail\\storeapi.lib")	// for FirmwareUpgrade
#endif

#ifdef _LIB_FOR_BOOTLACE_
#pragma comment(lib,"..\\asprintf\\libs\\retail\\storeapi.lib")	// For Bootlace
#endif


extern "C"
{
	BOOL KernelIoControl(DWORD, LPVOID, DWORD, LPVOID, DWORD, LPDWORD );
}
WCHAR V6internalSD[MAX_SD_VOLUME_LEN]	= (L"\\SDMemory\\"); // In Final Release this will be SDMemory
WCHAR V6externalSD[MAX_SD_VOLUME_LEN]	= (L"\\SDMemory2\\");
WCHAR V6usbkey1[MAX_SD_VOLUME_LEN]	= (L"\\Hard Disk\\");
WCHAR V6usbkey2[MAX_SD_VOLUME_LEN]	= (L"\\Hard Disk2\\"); 
WCHAR V6ROOT[MAX_SD_VOLUME_LEN]	= (L"\\"); 
#pragma message( "DAL ARISTOS BUILD" )
#endif
#pragma message( "DAL EMULATION BUILD" )
#endif	// PLATFORM
//************* End specifics *****************************************************************

CDeviceAbstraction *CDeviceAbstraction::m_pDALInstance = NULL;
QMutex m_CreationMutex;

QMutex CDeviceAbstraction::ms_kSPICritSect;
DWORD dwDisplayType = 0; //0 - 5.0, 1- 5.5
typedef struct {
	UINT8 ChannelSelect; //CS0, CS1, CS2, CS3
	UINT32 Freq;
	UINT32 BurstLength;  //bitcount, recommend 32bit as unit. 
	BOOL SSPOL;
	BOOL SCLKPOL;
	BOOL SCLKPHA;
	UINT8 DRCTL; //SPI_RDY enable
	BOOL usedma;
} CSPI_BUSCONFIG_T, *PCSPI_BUSCONFIG_T;

DWORD RxData[100];
HANDLE hEvent;
// eCSPI exchange packet
typedef struct {
	PCSPI_BUSCONFIG_T pBusCnfg;
	LPVOID pTxBuf;
	LPVOID pRxBuf;
	UINT32 xchCnt; //32bit unit; It must equal to BurstLength/32 or BurstLength/32 +1 (if BurstLength isn't integral multiple of 32bit)
	LPWSTR xchEvent;
	UINT32 xchEventLength;
} CSPI_XCH_PKT_T, *PCSPI_XCH_PKT_T;

CSPI_BUSCONFIG_T buscnfg = { 0x0,  // ecspi channel, 0 1 2 3
		2000000,  // ecspi work freq
		32, // burstlength
		FALSE,
		FALSE,
		TRUE, 0,
		TRUE  // usedma
		};

BOOL CSPIExchange(HANDLE hCSPI, PCSPI_XCH_PKT_T pCspiXchPkt);

#ifndef UNDER_CE
T_DEV_TYPE CDeviceAbstraction::ms_eDesktopDeviceType = /*DEV_PC_MULTI*/DEV_PC_MINI;
#endif

////#ifdef UNDER_CE
//T_DEV_TYPE CDeviceAbstraction::ms_eDesktopDeviceType = DEV_PC_MULTI;
//T_DEV_TYPE CDeviceAbstraction::ms_eDesktopDeviceType = DEV_PC_MINI;
//T_DEV_TYPE CDeviceAbstraction::ms_eDesktopDeviceType = DEV_PC_EZTREND;
//#endif
//**********************************************************************
/// CDeviceAbstraction constructor
///
//**********************************************************************
CDeviceAbstraction::CDeviceAbstraction()
#ifdef DBG_FILE_LOG_DAL_DBG_ENABLE
: m_debugFileLogger(L"\\SDMemory\\DalLogFile.txt", TRUE, (15*1024*1024) )
#endif
{
	// Set stream handles to NULL
	m_hLEDIO = NULL;
	m_hSpi = NULL;

	// Init SRAM details
	m_pSRAMBase = NULL;
	m_SRAMLength = 0;

	// Init watchdog info
	m_watchDogKicks = 0;
	m_watchDogMaxTime = 0;

	m_lastScreenBrightness = 0;		// Last screen brightness setting
	m_simulateSRAM = TRUE;			// SRAM always simulates unless it's a target board later then REV 2
	m_Initialised = FALSE;
	m_IOPortIgnore = FALSE;			// Don't ignore IO port unles specified

	// default board information
	m_clpdStatus = 0;
	m_screenType = SCRN_UNKNOWN;
	m_frontUSBSet = USB_FRONT_DEVICE;
	m_SPIProcFW = 0;
	m_secProcFWVer = 0;

	m_pPaths = NULL;

	m_lastIdleTimeTick = 0;
	m_lastSystemTimeTick = 0;

	m_ShutDownMode = SHUTDOWN_MODE_RESET;

	InitializeCriticalSection (&m_FlashCS);

	InitializeCriticalSection (&ms_kSPICritSect);

	ClearUserActivity();

	m_EthernetBoot = FALSE;

	m_pfSRAMClose = NULL;
	m_pfGetPointer = NULL;
	m_pfFreePointer = NULL;
	m_hInsSRamDLL = NULL;
	m_pfSRAMOPEN = NULL;
	m_hSramDriver = NULL;
}

//**********************************************************************
///
/// Instance creation of CDeviceAbstraction singleton
///
/// @return		pointer to single instance of CDeviceAbstraction
/// 
//**********************************************************************
CDeviceAbstraction* CDeviceAbstraction::GetHandle() {
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;
	if (NULL == m_pDALInstance) {
		// An instance has yet to be completed
		m_CreationMutex = CreateMutex(NULL,			// No security descriptor
				FALSE,			// Mutex object not owned
				TEXT("DAL"));	// Object name

		waitSingleObjectResult = m_CreationMutex.tryLock(g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);
		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:
			// Object was signaled
			if (NULL == m_pDALInstance) {
				m_pDALInstance = new CDeviceAbstraction;
			}
			if ( FALSE == m_CreationMutex.unlock()) {
				MessageBox(NULL, L"Failed to release DAL mutex", L"Error", MB_OK);
				DebugBreak();
			} // End of IF

			break;

		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
			MessageBox(NULL, L"DAL WaitForSingleObject Error", L"Error", MB_OK);
			DebugBreak();
			break;
		}
		// Close the Mutex as no longer required
		CloseHandle(m_CreationMutex);
	}
	return (m_pDALInstance);
}

//**********************************************************************
///
/// Deletes the instance of the singleton from memory
///
/// @return		Nothing
/// 
//**********************************************************************
void CDeviceAbstraction::CleanUp() {
	Shutdown();
	DeleteCriticalSection (&m_FlashCS);
	DeleteCriticalSection (&ms_kSPICritSect);

	delete m_pDALInstance;
	m_pDALInstance = NULL;
}
typedef BOOL (*CofigureFrontUSB_VBUS)(HANDLE h_Interface_g);

//**********************************************************************
///
/// Initialise the Device abstraction layer (DAL) 
///
/// @return		TRUE, if successful, FALSE if failed, Do not continue if failed
/// 
//**********************************************************************
BOOL CDeviceAbstraction::Initialise() {
	//CB: @delete
	CofigureFrontUSB_VBUS pfCofigureFrontUSB_VBUS;
	OutputDebugString(_T("CB:CDeviceAbstraction::Initialise() CHECK...\n"));
	if (m_Initialised == TRUE)
		return TRUE;
	//CB: @delete
	OutputDebugString(_T("CB:CDeviceAbstraction::Initialise() Start...\n"));
#ifdef V6_TARGET

	// Open a handle on the LED Driver
	m_hLEDIO = CreateFile((TEXT("LED1:")), GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, 0, NULL);
	if(m_hLEDIO == (HANDLE)-1) 
	{
		FatalError((L"DAL: LED1: driver could not be opened \n"));
		return FALSE;	// Fatal, we cannot proceed
	}
	//added by nilesh for USB reset
	//[
	//ClearUSB();
	//]
	// Open a handle on the SPI Driver
	m_hSpi = CreateFile((TEXT("SPI1:")), GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, 0, NULL);
	if(m_hSpi == (HANDLE)-1)
	{
		FatalError((L"DAL: SPI1: driver could not be opened \n"));
		return FALSE;	// Fatal, we cannot proceed
	}
#else	// Emulator

#ifdef ARISTOS
	// Open a handle on the LED Driver
	m_hLEDIO = CreateFile((TEXT("INT1:")), GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, 0, NULL);
	if(m_hLEDIO == (HANDLE)-1) 
	{
		FatalError((L"DAL: INT1: driver could not be opened \n"));
		return FALSE;	// Fatal, we cannot proceed
	}
	// Open a handle on the SPI Driver ()



	//m_hSpi = CreateFile((TEXT("SPI1:")), GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, 0, NULL);
	//if(m_hSpi == (HANDLE)-1)
	//{
	//	FatalError((L"DAL: SPI1: driver could not be opened \n"));
	//	return FALSE;	// Fatal, we cannot proceed
	//}


	m_hPHYIO =0;
	m_hPHYIO = CreateFile(TEXT("UIO1:"),GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, INVALID_HANDLE_VALUE); 

	//if((m_hPHYIO == (HANDLE)-1)& bCheckForDrivers) 
	//{ 
	//  //FatalError((L"DAL: UIO1: driver could not be opened \n")); 
	//  //return FALSE; // Fatal, we cannot proceed 
	//}

	// determines the model of the recorder i.e. Mini, Multi or Ez
	DetermineRecorderVariant();

	if( m_deviceType != DEV_ARISTOS_EZTREND && m_deviceType != DEV_XS_EZTREND ) //ARISTOS QXe Device Type updates
	{
		// load the mini/multi SPI dll
		m_hCSPISDK = LoadLibrary(L"ecspisdk.dll");		
	}
	else
	{
		// load the QXe SPI dll
		m_hCSPISDK = LoadLibrary(L"QXE_ecspisdk.dll"); 
	}

	if(m_hCSPISDK==NULL)
	{
		FatalError((L"DAL: Ecspisdk.dll fail to load DLL-\n"));
		return FALSE;
	}

	pfCSPIOpenHandle= (CSPIOPENHANDLE)GetProcAddress( m_hCSPISDK, L"CSPIOpenHandle");

	if(pfCSPIOpenHandle == NULL)
	{
		FatalError((L"DAL: Fail to the function CSPIOpenHandle()-\n"));
		// _tprintf(_T("-----Fail to the function pfCSPIOpenHandle()-\n\n"));

		return FALSE;
	}

	pfSPIWrite= (SPIWRITE)GetProcAddress( m_hCSPISDK, L"SPIWrite");

	if(pfSPIWrite == NULL)
	{
		FatalError((L"DAL: Fail to the function SPIWrite()-\n"));

		return FALSE;
	}

	pfSPIRead= (SPIREAD)GetProcAddress( m_hCSPISDK, L"SPIRead");

	if(pfSPIWrite == NULL)
	{
		FatalError((L"DAL: Fail to the function SPIRead()-\n"));

		return FALSE;
	}

	hCSPI = pfCSPIOpenHandle(CSPI_DEVICE_NAME);
	if(hCSPI == NULL)
	{
		FatalError((L"DAL: SPIOpenHandle() Failed-\n"));

		return FALSE;
	}

	pfCSPICloseHandle= (CSPICLOSEHANDLE)GetProcAddress( m_hCSPISDK, L"CSPICloseHandle");

	pfCofigureFrontUSB_VBUS = (CofigureFrontUSB_VBUS)GetProcAddress( m_hInstInterfaceSDK, L"CofigureFrontUSB_VBUS");
	if(pfCofigureFrontUSB_VBUS == NULL)
	{
		FatalError(L"-----Fail to the function pfCofigureFrontUSB_VBUS()-\n\n");
	}
	else
	{
		if( m_deviceType != DEV_ARISTOS_EZTREND && m_deviceType != DEV_XS_EZTREND ) //ARISTOS QXe Device Type updates
		{
			pfCofigureFrontUSB_VBUS(m_hInterfaceHandle);
		}
	}

	pfWriteNORFlashBlock	 = (WriteNORFlashBlock)GetProcAddress( m_hInstInterfaceSDK, L"WriteNORFlashBlock");

	if(pfWriteNORFlashBlock == NULL)
	{
		FatalError(L"DAL:Failed to the function WriteNORFlashBlock()-\n\n");
	}
	pfReadNORFlashBlock	 = (ReadNORFlashBlock)GetProcAddress( m_hInstInterfaceSDK, L"ReadNORFlashBlock");

	if(pfReadNORFlashBlock == NULL)
	{
		FatalError(L"DAL:Failed to the function ReadNORFlashBlock()-\n\n");		
	}

	pfNORFlashStoreSplashScreen	 = (NorFlashStoreSplashScreen)GetProcAddress( m_hInstInterfaceSDK, L"NorFlashStoreSplashScreen");

	if(pfNORFlashStoreSplashScreen == NULL)
	{
		FatalError(L"DAL:Failed to the function NorFlashStoreSplashScreen()-\n\n");		
	}


	pfInterfaceClose = (InterfaceClose)GetProcAddress( m_hInstInterfaceSDK, L"InterfaceClose");

	if(pfInterfaceClose == NULL)
	{
		FatalError(L"DAL:Failed to the function InterfaceClose()-\n\n");		
	}

	pfGetActiveImageVersion = (GetActiveImageVersion)GetProcAddress(m_hInstInterfaceSDK, L"GetActiveImageVersion");


	if(pfGetActiveImageVersion == NULL)
	{
		FatalError(L"DAL:Failed to the function GetActiveImageVersion()-\n\n");		
	}

	//PSR Fix for - 1-3DXWHML - QXe_General Status shows Expansion Board and Comms Board as connected though Support is removed begin
	pfGetBackPlaneBoardStatus = (GetBackPlaneBoardStatus)GetProcAddress(m_hInstInterfaceSDK, L"GetBackPlaneBoardStatus");

	if(pfGetBackPlaneBoardStatus == NULL)
	{
		FatalError(L"DAL:Failed to the function GetBackPlaneBoardStatus()-\n\n");		
	}
	//PSR Fix for - 1-3DXWHML - QXe_General Status shows Expansion Board and Comms Board as connected though Support is removed end

	//PSR -Fix for 1-3E7Y0UX - SX/QX_"Common alarm" output configuration is missing from soft (pens) alarm end
	//Initialize function pointers to get and set the PowerRelay pin status
	pfGetPowerRelayIOPinStatus = (GetPowerRelayIOPinStatus)GetProcAddress(m_hInstInterfaceSDK, L"GetPowerRelayIOPinStatus");
	if(pfGetPowerRelayIOPinStatus == NULL)
	{
		FatalError(L"DAL:Failed to the function GetPowerRelayIOPinStatus()-\n\n");		
	}

	pfTogglePowerRelayIOPin = (TogglePowerRelayIOPin )GetProcAddress(m_hInstInterfaceSDK, L"TogglePowerRelayIOPin");
	if(pfTogglePowerRelayIOPin == NULL)
	{
		FatalError(L"DAL:Failed to the function TogglePowerRelayIOPin()-\n\n");		
	}
	//PSR -Fix for 1-3E7Y0UX - SX/QX_"Common alarm" output configuration is missing from soft (pens) alarm end


#endif

#ifndef ARISTOS 
	if (m_emul.Initialise() == FALSE)
		return FALSE;
#endif

#endif

	GetBoardDetails();			// Get the details on the processor board.

	if (!InitialiseSRAM())			// SRAM initialisation, **** Must be done after GetBoardDetails() ***
	{
		DebugBreak();
	}
	m_Initialised = TRUE;		// dal.has been initialised

	// Create the storage paths object, no need for an Initialise.
	m_pPaths = CStoragePaths::GetHandle();
	m_pPaths->Initialise();

	GetTheIdleTimeInPercent();		// Force Idle time update, will populate registers

#ifdef UNDER_CE
	//PSR - PrintCE SDK integration for PCL5 support begin
	//Load Print CE library
#ifndef IS_BOOTLACE_APP
	BOOL bPrintCELibInit = FALSE;
	bPrintCELibInit = CPrintCEWrapper::LoadPrintLib();
	if( FALSE == bPrintCELibInit )
	{
		OutputDebugString(_T("DAL::Initialise() PrintCE init failed...\n"));
	}
	//PSR - PrintCE SDK integration for PCL5 support end
#endif
#endif

	//CB: @delete
	OutputDebugString(_T("CB:CDeviceAbstraction::Initialise() End...\n"));
	return TRUE;
}

//**********************************************************************
///
/// Shutdown the Device abstraction layer (DAL) 
///
/// @return		TRUE, if successful, FALSE if failed, Do not continue if failed
/// 
//**********************************************************************
BOOL CDeviceAbstraction::Shutdown() {

#ifdef ARISTOS
#define V6_TARGET
#endif//

#ifdef V6_TARGET

	//if( m_hLEDIO != NULL )
	//	//No need to close the mutex in Qt		// Close handle on the LED driver

	if( m_hSpi != NULL )
		//No need to close the mutex in Qt		// Close handle on the SPI driver
	//SPI 
	BOOL retVal;
	if(hCSPI != NULL)
		retVal = pfCSPI//No need to close the mutex in Qt

	if ( m_hCSPISDK )
	{
		FreeLibrary(m_hCSPISDK);
		m_hCSPISDK = 0;
	}
	if ( m_hPHYIO )
		//No need to close the mutex in Qt

	//SPI NOR


	if(m_hInstInterfaceSDK != NULL)
	{
		FreeLibrary(m_hInstInterfaceSDK);
		if(m_hInterfaceHandle != NULL)
		{
			//Commented out the pfInterfaceClose call since application is crashing.
			//retVal = pfInterfaceClose1(m_hInterfaceHandle);
			m_hInterfaceHandle = NULL;
		}
	}
#endif

#ifdef ARISTOS
	//m_emul.Shutdown();
#undef V6_TARGET
#endif

	m_Initialised = FALSE;
	// Clean-up the storage paths object
	m_pPaths->Cleanup();

	// if SRAM is simulated close this down, make sure the SRAM is saved out before being deleted 
	if (m_simulateSRAM) {
		if (m_pSRAMBase != NULL) {
			// Save SRAM so it persists
			SimulatedSRAMAccess( BF_WRITE);

			//free oss SRAM allocation
			delete[] m_pSRAMBase;
			m_pSRAMBase = NULL;
		}
	} else {
		//Take SRAM backup for Battery Reset operation.
		BackupSRAMToDiskCopy(BF_BLK_SRAM_BKP_ON_BAT_RESET);

		m_pfFreePointer (m_pSRAMBase);
		m_pfSRAMClose (m_hSramDriver);
		FreeLibrary (m_hInsSRamDLL);

		m_pfFreePointer = NULL;
		m_pfSRAMClose = NULL;
		m_pSRAMBase = NULL;
		m_hInsSRamDLL = NULL;
	}

	// Determine shutdown mode and take appropriate action
	switch (m_ShutDownMode) {
	// Reset the unit
	case SHUTDOWN_MODE_RESET:				// Run the reset line once the system has shutdown
	case SHUTDOWN_MODE_CONFIG_CHANGE:		// Config Change requires a restart
	{
		PerformReboot();		// Reboot the system now, OpPanel has completed and we know control sequencer is done
		// as we are in the same thread
		break;
	}
		// Pause unit shutdown
	case SHUTDOWN_MODE_STOP:				// Stop the system a display "safe to power off" dialog
	case SHUTDOWN_MODE_SAFE_TO_POWER_OFF:	// Safe to power down state
	{
#if (!defined IS_BOOTLACE_APP) && (defined UNDER_CE)
			QString   strTitle( _T("Battery Reset!!!"));
			QString   strMessage;
			strMessage.asprintf(_T("\nRecorder is ready for battery replacement!!!\n\n Power off the unit \n and replace the battery.\n ") );
			CV6MessageBoxDlg kMsgDlg( strTitle, strMessage );	
			kMsgDlg.ShowOkBtn(false);
			kMsgDlg.exec();
#endif

#ifdef V6_TARGET		
			// If we want the system to stop, loop forever, user will require to power cycle the unit
			// this is required on the target only when powering off a recorder gracefully.
			while(1)
			{
				sleep(100);
				KickWatchdog();
			}
#endif
		break;
	}
		// Exit application
	case SHUTDOWN_MODE_EXIT:						// Exit the application, for development only
		break;
	case SHUTDOWN_MODE_FW_UPDATE:				// Firmware Update shutdown mode
	{
		// delete the contents of the sounds directory as there may be sounds with new names
		WCHAR wcaSoundPath[ MAX_PATH];
		int iMaxPath = MAX_PATH;
		//_wcsnset_s( wcaSoundPath, MAX_PATH, 0, iMaxPath );
		SecureZeroMemory(wcaSoundPath, sizeof(wcaSoundPath));
		BuildPath(IDS_INTERNAL_SD, IDS_WAVS, L"*.wav", wcaSoundPath, iMaxPath);

		// now find and delete the sound file with this prefix
		WIN32_FIND_DATA tindexOfFileData;

		tindexOfFileData.cFileName[0] = '\0';
		HANDLE hindexOf = indexOfFirstFile(wcaSoundPath, &tindexOfFileData);
		QFile kFileToDelete;

		// insert the first valid filename found within the editbox
		while (hindexOf != INVALID_HANDLE_VALUE ) {
			BuildPath(IDS_INTERNAL_SD, IDS_WAVS, tindexOfFileData.cFileName, wcaSoundPath, MAX_PATH);

			BOOL writeableSuccess = FALSE;
			CFileStatus status;
			try {
				// Get current status
				if (QFile::GetStatus(wcaSoundPath, status) == TRUE) {
					// Clear read only status
					status.m_attribute &= ~QFile::readOnly;
					QFile::SetStatus(wcaSoundPath, status);

					try {
						// Attempt to delete the file
						QFile::Remove(wcaSoundPath);
					} catch (FileException *pEx) {
						// File could not be deleted, probably open as we have already set as writable
#ifdef _DEBUG
							DebugBreak();
#endif
						pEx->Delete();
					}

				}
			} catch (...) {
				// unhandled exception
#ifdef _DEBUG
					DebugBreak();
#endif
			}

			// now get the next file (if any)
			if (indexOfNextFile(hindexOf, &tindexOfFileData) == 0) {
				break;
			}
		}
		indexOfClose(hindexOf);
	}
		break;
	default: {
		break;
	}
	}

#ifdef UNDER_CE
	//PSR - PrintCE SDK integration for PCL5 support begin
	//UnLoad Print CE library
#ifndef IS_BOOTLACE_APP
	CPrintCEWrapper::UnloadPrintLib();
#endif
#endif

	return TRUE;
}

//=====================================================================================
// Identification
//=====================================================================================
//**********************************************************************
/// Is this a PC software build, not firmware 
///
/// @return		TRUE if a PC software build otherwise FALSE
//**********************************************************************
BOOL CDeviceAbstraction::IsPCSoftware() {
#ifdef TTR6SETUP	
	return TRUE;
#endif
	if (m_deviceType == DEV_PC_SCREEN_DESIGNER || m_deviceType == DEV_PC_TTR6SETUP || m_deviceType == DEV_TEST)
		return TRUE;
	else
		return FALSE;
}

//**********************************************************************
/// Is this a recorder firmware build either PC or Embedded
/// PC(V6Desktop) or Embedded(V6App)
///
/// @return		TRUE if a recorder firmware build otherwise FALSE
//**********************************************************************
BOOL CDeviceAbstraction::IsRecorderPCorEmbedded() {
#ifdef TTR6SETUP	
	return FALSE;
#endif
	//ARISTOS QXe Device Type updates
	if ((m_deviceType == DEV_ARISTOS_MINITREND) || (m_deviceType == DEV_ARISTOS_MULTIPLUS)
			|| (m_deviceType == DEV_ARISTOS_EZTREND) || (m_deviceType == DEV_SCR_MINITREND)
			|| (m_deviceType == DEV_XS_EZTREND) || (m_deviceType == DEV_PC_MINI) || (m_deviceType == DEV_PC_MULTI)
			|| (m_deviceType == DEV_PC_EZTREND)) {
		return TRUE;
	} else {
		return FALSE;
	}
}

//**********************************************************************
/// Is this a recorder firmware build only(V6App)
///
/// @return		TRUE if a recorder firmware embedded only build otherwise FALSE
//**********************************************************************
BOOL CDeviceAbstraction::IsRecorderEmbedded() {
	//ARISTOS QXe Device Type updates
	if ((m_deviceType == DEV_ARISTOS_MINITREND) || (m_deviceType == DEV_ARISTOS_MULTIPLUS)
			|| (m_deviceType == DEV_ARISTOS_EZTREND) || (m_deviceType == DEV_SCR_MINITREND)
			|| (m_deviceType == DEV_XS_EZTREND)) {
		return TRUE;
	}
	return FALSE;
}

//**********************************************************************
/// Is this a mini/multi recorder firmware build only(V6App)
///
/// @return		TRUE if a recorder firmware mini/multi only build otherwise FALSE
//**********************************************************************
BOOL CDeviceAbstraction::IsRecorderMiniMultiEmbedded() {
	if (m_deviceType == DEV_ARISTOS_MINITREND || m_deviceType == DEV_ARISTOS_MULTIPLUS
			|| m_deviceType == DEV_SCR_MINITREND) {
		return TRUE;
	} else {
		return FALSE;
	}
}

//**********************************************************************
/// Is this a eZ recorder build only(V6App)
///
/// @return		TRUE if a recorder firmware mini/multi only build otherwise FALSE
//**********************************************************************
BOOL CDeviceAbstraction::IsRecorderEzTrend() {
	if ((m_deviceType == DEV_PC_EZTREND) || (m_deviceType == DEV_ARISTOS_EZTREND) || (m_deviceType == DEV_XS_EZTREND)) {
		return TRUE;
	} else {
		return FALSE;
	}
}

//**********************************************************************
/// Is this a eZ recorder build only(V6App)
///
/// @return		TRUE if a recorder firmware mini/multi only build otherwise FALSE
//**********************************************************************
BOOL CDeviceAbstraction::IsRecorderMini() {
	if ((m_deviceType == DEV_ARISTOS_MINITREND) || (m_deviceType == DEV_PC_MINI)) {
		return TRUE;
	} else {
		return FALSE;
	}
}

//**********************************************************************
/// Is this a multi recorder build only(V6App)
///
/// @return		TRUE if a recorder firmware multi only build otherwise FALSE
//**********************************************************************
BOOL CDeviceAbstraction::IsRecorderMulti() {
	if (m_deviceType == DEV_ARISTOS_MULTIPLUS || m_deviceType == DEV_PC_MULTI || m_deviceType == DEV_SCR_MINITREND) {
		return TRUE;
	} else {
		return FALSE;
	}
}

//=====================================================================================
// FLASH HANDLING
//=====================================================================================

#define DAL_FLASH_LOCK_TIMEOUT	5000	///< 5 Second timeout for exclusive flash read/write

//**********************************************************************
///
/// Read/Write a block of boot flash, or from simulated flash on disk for emulation
///
/// @param[in]	flashWrite - set to BF_READ for reqad flash block and BF_WRITE for write flash block
/// @param[in]	blockNumber - Number of flash block see BK_BLK_
/// @param[in]	sizeReq - Number of bytes to read or write
/// @param[in,out]	pBuffer - ptr to buffer, data to write or buffer to read
/// @return		TRUE, if flash successful, FALSE if R/W failed or parameter check fails
/// 
//**********************************************************************
BOOL CDeviceAbstraction::RWBootFlashBlock(BOOL flashWrite, ULONG blockNumber, ULONG sizeReq, BYTE *pBuffer) {
#ifdef ARISTOS //commented out by kranti for qxe up
#define V6_TARGET
#endif//

	BOOL retVal = FALSE;

	// Check that the block requested is within valid range and that the number of bytes 
	// does not exceed a single block in size.
	if (blockNumber < BF_STARTBLOCK || blockNumber > BF_ENDBLOCK || sizeReq > BF_MAXSIZE) {
		FatalError((L"DAL:Flash param invalid, block(%d), Size req(%d) \r\n"), blockNumber, sizeReq);
		return FALSE;
	}

	EnterCriticalSection (&m_FlashCS);
#ifdef V6_TARGET

	DWORD sizeRet;

	// Read from or Write to BootFlash depending on flashWrite param
	if( flashWrite )
		retVal = KernelIoControl(IOCTL_WRITE_FLASH_PARAMBLOCK,&blockNumber,sizeof(ULONG),pBuffer,sizeReq,&sizeRet);
	else	
		retVal = KernelIoControl(IOCTL_READ_FLASH_PARAMBLOCK,&blockNumber,sizeof(ULONG),pBuffer,sizeReq,&sizeRet);

	spiFmdBlock.pBlockBuff = (LPBYTE)pBuffer;
	spiFmdBlock.dwBlockBuffSize = sizeReq; 
	spiFmdBlock.blockID = blockNumber;

	//Flash Write
	if( flashWrite )
	{
		retVal = pfWriteNORFlashBlock(m_hInterfaceHandle, &spiFmdBlock);
	}
	else
	{
		retVal = pfReadNORFlashBlock(m_hInterfaceHandle, &spiFmdBlock);
	}
#else	// Emulator

	//	 Retrive/write a flash block in simulated boot flash
	retVal = ReadWriteNV(flashWrite, sizeReq, (LPWORD) pBuffer, (UCHAR) blockNumber, BF_MAXSIZE);

#endif  //commented by kranti

	m_FlashCS.lock();
#ifdef ARISTOS
#undef V6_TARGET
#endif//

	return retVal;
}

//=====================================================================================
// GPIO Specific
//=====================================================================================

//**********************************************************************
///
/// Get the Status of the ethernet PHY
///
/// @return		PHY status in bottom 5 bits, use PHYSTAT_XXX macros in dal.h to decipher
/// 
//**********************************************************************
ULONG CDeviceAbstraction::GetPHYStatus(ULONG &ulLinkSpeed) {
#ifdef ARISTOS
#define V6_TARGET
#endif//

#ifdef V6_TARGET
DWORD dwOut = 0;
ULONG ulState = 0;
NIC_STATISTICS nicStat;

DeviceIoControl(m_hPHYIO, IOCTL_NDISUIO_OPEN_DEVICE, TEXT("FEC1"),wcslen(TEXT("FEC1"))*sizeof(TCHAR),NULL,0, &dwOut, NULL);

nicStat.ptcDeviceName =L"FEC1";
if(!DeviceIoControl(m_hPHYIO, IOCTL_NDISUIO_NIC_STATISTICS, NULL, 0,&nicStat, sizeof(NIC_STATISTICS), &dwOut, NULL))

{
	FatalError((L"DAL:Get PHY status failed \n"));
}
ulLinkSpeed = nicStat.LinkSpeed;
;

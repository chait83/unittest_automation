/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  ModBus Master
/// @n Filename:  SlaveDevice.cpp
/// @n Description: ModBus slave device wrapper
///
//  **************************************************************************
//  Revision History
//  **************************************************************************
//  $Log[4]:
// 23  Stability Project 1.18.1.3 7/2/2011 5:01:25 PM Hemant(HAIL) 
//  Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
// 22  Stability Project 1.18.1.2 7/1/2011 4:38:55 PM Hemant(HAIL) 
//  Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
// 21  Stability Project 1.18.1.1 3/17/2011 3:20:47 PM  Hemant(HAIL) 
//  Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
// 20  Stability Project 1.18.1.0 2/15/2011 3:03:57 PM  Hemant(HAIL) 
//  File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
//  $
//
//  **************************************************************************
//
// SlaveDevice.cpp: 
// A wrapper for a ModBus slave device, contains the required data
// and methods to allow (generic) communication with a slave device.
//
//////////////////////////////////////////////////////////////////////

#include "V6defines.h"
#include "V6globals.h"
#include "V6Config.h"

#include "TraceDefines.h"

#include "SlaveDevice.h"

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif

/////////////////////////////////////
// ModBus slave device wrapper
//
// Wraps up the functionality of a ModBus slave device.
//
// Note:
// For an RS485 device, one common protocol object is required.
// For Ethernet devices, each device will require it's own protocol object

static class MbusRtuMasterProtocol *g_pRS485Protocol = NULL;

//****************************************************************************
/// ModBus Slave Device Wrapper: class constructor
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
CModBusSlaveDevice::CModBusSlaveDevice() {
	Initialise();
}

//****************************************************************************
/// ModBus Slave Device Wrapper: class destructor
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
CModBusSlaveDevice::~CModBusSlaveDevice() {
	CleanUp();
}

//****************************************************************************
/// ModBus Slave Device Wrapper: class initialisation
///
/// @return			none
///
/// @note Creates new empty set of ModBus master device holders,
/// Initialisation needs to be called before any devices are used, this will,
/// initialise a shared protocol object pointer and must be used with care.
//****************************************************************************
void CModBusSlaveDevice::Initialise() {
	m_pEthernetProtocol = NULL;								// Ethernet protocol object pointer 

	m_Device.Used = FALSE;
	memset(m_Device.Name, '\0', 32);
	memset(m_Device.NetworkName, '\0', 32);
	m_Device.Port = eEthernet;
	m_Device.NetworkAddress = 0;
	m_Device.Protocol = eModBus;
	m_Device.ErrorState = e_OK;

	for (USHORT TransactionInstance = 0; TransactionInstance < MODBUSSLAVEDEV_TRANSACTIONS_SIZE;
			TransactionInstance++) {
		m_TransactionBuffer[TransactionInstance] = NULL;
	}
	m_BaseBuffer = NULL;
}

//****************************************************************************
/// ModBus Slave Device Wrapper: class clean-up
///
/// @return			none
///
/// @note Deletes any allocated memory prior to destruction/shut-down
/// CleanUp needs to be called when all devices are deleted, this will
/// delete a shared protocol object pointer and must be used with care.
//****************************************************************************
void CModBusSlaveDevice::CleanUp() {
	if (NULL != m_pEthernetProtocol) {
		// Close  Ethernet master protocol object
		delete m_pEthernetProtocol;
		m_pEthernetProtocol = NULL;
	}
	// If this is ann RS485 device
	else if (NULL != g_pRS485Protocol) {
		// This is a shared object, CleanUp can only be called for all devices.
		delete g_pRS485Protocol;
		g_pRS485Protocol = NULL;
	}
	m_Device.Used = FALSE;

	// Null out the individual transaction data buffers
	for (USHORT TransactionInstance = 0; TransactionInstance < MODBUSSLAVEDEV_TRANSACTIONS_SIZE;
			TransactionInstance++) {
		if (NULL != m_TransactionBuffer[TransactionInstance]) {
			m_TransactionBuffer[TransactionInstance] = NULL;
		}
	}
	// Now free the base data block
	free(m_BaseBuffer);
	m_BaseBuffer = NULL;
}

//****************************************************************************
/// ModBus Slave Device Wrapper: Port/Device open
///
/// @param[in] Port	-	Port type to be opened
//
/// @return				none
///
/// @note Opens/creates the required protocol object and initialises the connection
//****************************************************************************
BOOL CModBusSlaveDevice::Open() {
	return Open(Port());
}

//****************************************************************************
/// ModBus Slave Device Wrapper: Port/Device close
//
/// @return				none
///
/// @note Closes and destroys the required protocol object and initialises the connection
//****************************************************************************
void CModBusSlaveDevice::Close() {
	if (eEthernet == Port() && NULL != m_pEthernetProtocol) {
		((MbusTcpMasterProtocol*) m_pEthernetProtocol)->closeProtocol();
	}
}

//****************************************************************************
/// ModBus Slave Device Wrapper: Check if a port is open
//
/// @return		BOOL
///
/// @note 
//****************************************************************************
BOOL CModBusSlaveDevice::IsOpen() {
	BOOL bResult = FALSE;

	if (eRS485 == Port()) {
		if (NULL != g_pRS485Protocol &&
		TRUE == ((MbusSerialMasterProtocol*) g_pRS485Protocol)->isOpen()) {
			bResult = TRUE;
		}
	} else {
		if (NULL != m_pEthernetProtocol &&
		TRUE == ((MbusTcpMasterProtocol*) m_pEthernetProtocol)->isOpen()) {
			bResult = TRUE;
		}
	}
	return bResult;
}

//****************************************************************************
/// ModBus Slave Device Wrapper: Port/Device open
//
/// @return				none
///
/// @note Opens/creates the required protocol object and initialises the connection
//****************************************************************************
BOOL CModBusSlaveDevice::Open(T_eCommsPort Port) {
	BOOL bResult = TRUE;

	T_PCOMMUNICATIONS ptCommsData = NULL;
	CCommsSetupConfig *pkCommsConfig = pGlbSetup->GetCommsSetupConfig();

	if (pkCommsConfig != NULL) {
		ptCommsData = pkCommsConfig->GetCommsBlock(CONFIG_COMMITTED);
	}

	if (eRS485 == Port) {
		// Check if the protocol object has already been created
		if (NULL == g_pRS485Protocol) {
			// Create the protocol object
			g_pRS485Protocol = new MbusRtuMasterProtocol();

			if (NULL != g_pRS485Protocol) {
				long lBaudRate = 38400;
				switch (ptCommsData->SerialPort.BaudRate) {
				case 0: // 2400
					lBaudRate = 2400;
					break;
				case 1: // 4800
					lBaudRate = 4800;
					break;
				case 2: // 9600
					lBaudRate = 9600;
					break;
				case 3: // 19,200
					lBaudRate = 19200;
					break;
				case 4: // 38,400
					lBaudRate = 38400;
					break;
				case 5: // 56,700
					lBaudRate = 56700;
					break;
				case 6: // 115,200
					lBaudRate = 115200;
					break;
				}

				int iRTSDelay = ptCommsData->SerialPort.LineTurnAround;
				WCHAR *wcPortName = { L"COM1:" };

				int iDataBits = MbusSerialMasterProtocol::SER_DATABITS_8;
				int iStopBits = MbusSerialMasterProtocol::SER_STOPBITS_1;
				int iParrity = MbusSerialMasterProtocol::SER_PARITY_NONE;

				switch (ptCommsData->SerialPort.ByteOptions) {
				case 0: // N-8-1
					break;
				case 1: // E-8-1
					iParrity = MbusSerialMasterProtocol::SER_PARITY_EVEN;
					break;
				case 2: // O-8-1
					iParrity = MbusSerialMasterProtocol::SER_PARITY_ODD;
					break;
				case 3: // N-8-2
					iStopBits = 2;
					break;
				}

				((MbusSerialMasterProtocol*) g_pRS485Protocol)->enableRs485Mode(iRTSDelay);
				((MbusSerialMasterProtocol*) g_pRS485Protocol)->setTimeout( MB_RS_MASTER_TIMEOUT);
				((MbusSerialMasterProtocol*) g_pRS485Protocol)->setRetryCnt( MB_RETRY_COUNT);

				if (FTALK_SUCCESS
						!= ((MbusSerialMasterProtocol*) g_pRS485Protocol)->openProtocol(wcPortName, lBaudRate,
								iDataBits, iStopBits, iParrity)) {
					// Open failed, clean-up
					((MbusSerialMasterProtocol*) g_pRS485Protocol)->closeProtocol();
					bResult = FALSE;
					delete g_pRS485Protocol;
					g_pRS485Protocol = NULL;
				}
			} else {
				// Creation failed?
				bResult = FALSE;
			}
		}
	} else // Open Ethernet connection
	{
		// If the protocol object doesn't yet exist, create it
		if (NULL == m_pEthernetProtocol) {
			m_pEthernetProtocol = new MbusTcpMasterProtocol();
		}

		// If the protocol object exists, check if it's currently open
		if (NULL != m_pEthernetProtocol &&
		FALSE == ((MbusTcpMasterProtocol*) m_pEthernetProtocol)->isOpen()) {
			CCommsSetupConfig *pNewConfig = pGlbSetup->GetCommsSetupConfig();
			T_PCOMMUNICATIONS pCommunications = pNewConfig->GetCommsBlock(CONFIG_COMMITTED);

			int iSocket = pCommunications->Ethernet.ModbusSocket;

			m_pEthernetProtocol->setPollDelay( E_NET_POLL_DELAY);
			m_pEthernetProtocol->setRetryCnt( MB_RETRY_COUNT);
			m_pEthernetProtocol->setTimeout( MB_EN_MASTER_TIMEOUT);

			((MbusTcpMasterProtocol*) m_pEthernetProtocol)->setPort(iSocket);

			char pcaTemp[MAX_PATH];
#if _MSC_VER < 1400 
			wcstombs(pcaTemp, NetworkName(), MAX_PATH);
#else
			size_t mbSize;
			wcstombs_s(&mbSize, pcaTemp, MAX_PATH, NetworkName( ), MAX_PATH ); 
#endif

			int iTalkResult = (int) ((MbusTcpMasterProtocol*) m_pEthernetProtocol)->openProtocol(pcaTemp);

			if (FTALK_SUCCESS != iTalkResult) {
				// Open failed, clean-up
				((MbusTcpMasterProtocol*) m_pEthernetProtocol)->closeProtocol();
				bResult = FALSE;
			} else {
				if ( TRUE == pCommunications->ModbusMaster.LegacySettings) {
					sleep( LEGACY_EN_POST_OPEN_WAIT);
				} else {
					sleep( EN_POST_OPEN_WAIT);
				}
			}
		} else {
			// Creation failed ??
			//bResult = FALSE;
		}
	}
	return bResult;
}

//****************************************************************************
/// ModBus Slave Device Wrapper: device data read
///
/// @param[in] Type		-	Data request type (see T_eDataRequest for supported requests)
/// @param[in] Address	-	Data register address
/// @param[in] Size		-	Data size (depends on the request type, but generaly in registers)
/// @param[in] Buffer	-	Pointer to the target data buffer, caller MUST ensure this buffer is big enough
///
/// @return					TRUE if data request was OK, else FALSE
///
/// @note 
//****************************************************************************
BOOL CModBusSlaveDevice::Read(T_eDataRequest Type, USHORT Address, USHORT Size, void *Buffer) {
	BOOL bResult = FALSE;
	MbusMasterFunctions *pSlaveDevice = NULL;

	// Check if it's an Ethernet device
	if (NULL != m_pEthernetProtocol)
		pSlaveDevice = m_pEthernetProtocol;
	else
		pSlaveDevice = g_pRS485Protocol;

	// If the protocol object exists
	if (NULL != pSlaveDevice) {
		switch (Type) {
		case e_ReadCoils:
			if (FTALK_SUCCESS
					== pSlaveDevice->readCoils((int) NetworkAddress(), (int) Address, (int*) Buffer, (int) Size))
				bResult = TRUE;
			break;
		case e_ReadDiscreteInputs:
			if (FTALK_SUCCESS
					== pSlaveDevice->readInputDiscretes((int) NetworkAddress(), (int) Address, (int*) Buffer,
							(int) Size))
				bResult = TRUE;
			break;
		case e_ReadMultipleRegisters:
			if (FTALK_SUCCESS
					== pSlaveDevice->readMultipleRegisters((int) NetworkAddress(), (int) Address, (short*) Buffer,
							(int) Size))
				bResult = TRUE;
			break;
		case e_ReadInputRegisters:
			if (FTALK_SUCCESS
					== pSlaveDevice->readInputRegisters((int) NetworkAddress(), (int) Address, (short*) Buffer,
							(int) Size))
				bResult = TRUE;
			break;
		case e_ReadExceptionStatus:
			if (FTALK_SUCCESS == pSlaveDevice->readExceptionStatus((int) NetworkAddress(), (unsigned char*) Buffer))
				bResult = TRUE;
			break;
		case e_ReportSlaveID:
			if (FTALK_SUCCESS == pSlaveDevice->reportSlaveID((int) NetworkAddress(), (short*) Buffer))
				bResult = TRUE;
			break;
		default:
			bResult = FALSE;
			break;
		}
	}
	return bResult;
}

//****************************************************************************
/// ModBus Slave Device Wrapper: devioce data write
///
/// @param[in] Type		-	Data write type (see T_eDataRequest for supported types)
/// @param[in] Address	-	Data register address
/// @param[in] Size		-	Data size (depends on the request type, but generaly in registers)
/// @param[in] Buffer	-	Pointer to the source data buffer
///
/// @return					TRUE if data write was OK, else FALSE
///
/// @note 
//****************************************************************************
BOOL CModBusSlaveDevice::Write(T_eDataRequest Type, USHORT Address, USHORT Size, void *Buffer) {
	BOOL bResult = FALSE;
	MbusMasterFunctions *pSlaveDevice = NULL;

	// Check if it's an Ethernet device
	if (NULL != m_pEthernetProtocol)
		pSlaveDevice = m_pEthernetProtocol;
	else
		pSlaveDevice = g_pRS485Protocol;

	// If the protocol object exists...
	if (NULL != pSlaveDevice) {
		switch (Type) {
		case e_WriteCoils: {
			if (FTALK_SUCCESS == pSlaveDevice->writeCoil((int) NetworkAddress(), (int) Address, *(int*) Buffer))
				bResult = TRUE;
			break;
		}
		case e_WriteSingleRegister: {
			if (FTALK_SUCCESS
					== pSlaveDevice->writeSingleRegister((int) NetworkAddress(), (int) Address, *(int*) Buffer))
				bResult = TRUE;
			break;
		}
		case e_WriteMultipleRegisters:
			if (FTALK_SUCCESS
					== pSlaveDevice->writeMultipleRegisters((int) NetworkAddress(), (int) Address,
							(const short*) Buffer, (int) Size))
				bResult = TRUE;
			break;
		default:
			bResult = FALSE;
			break;
		}
	}
	return bResult;
}

//****************************************************************************
/// ModBus Slave Device Wrapper: Get data item value
///
/// @param[in] 
/// @param[in] 
///
/// @return					Value
///
/// @note 
//****************************************************************************
float* CModBusSlaveDevice::DataItem(USHORT Transaction, USHORT Instance) {
	float *pfReturn = NULL;

	// Sanity test
	if (NULL != m_TransactionBuffer) {
		if (Transaction < MODBUSSLAVEDEV_TRANSACTIONS_SIZE) {
			float *pValue = (float*) m_TransactionBuffer[Transaction];
			if (pValue != NULL) {
				pValue += Instance;
				pfReturn = pValue;
			}
		}
	}
	return pfReturn;
}

//****************************************************************************
/// ModBus Slave Device Wrapper: Set data item value
///
/// @param[in] 
/// @param[in] 
/// @param[in] 
///
/// @return					None
///
/// @note 
//****************************************************************************
void CModBusSlaveDevice::DataItem(USHORT Transaction, USHORT Instance, float Value) {
	// Sanity test
	if (NULL != m_TransactionBuffer) {
		if (Instance < MODBUSSLAVEDEV_TRANSACTIONS_SIZE) {
			float *pValue = (float*) m_TransactionBuffer[Transaction];
			pValue += Instance;
			*pValue = Value;
		}
	}
}

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  ModBus Master
/// @n Filename:  ScheduleWrapper.cpp
/// @n Description: ModBus schedule wrapper
///
//  **************************************************************************
//  Revision History
//  **************************************************************************
//  $Log[4]:
// 46  Aristos  1.40.1.3.1.0 10/4/2011 6:24:04 PM  Shripad(HAIL) Fix
//  for Modbus byte count issue.
// 45  Stability Project 1.40.1.3 7/2/2011 5:01:01 PM Hemant(HAIL) 
//  Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
// 44  Stability Project 1.40.1.2 7/1/2011 4:38:51 PM Hemant(HAIL) 
//  Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
// 43  Stability Project 1.40.1.1 3/17/2011 3:20:45 PM  Hemant(HAIL) 
//  Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  $
//
//  **************************************************************************
//
// ScheduleWrapper.cpp: 
// ModBus schedule wrapper, constructs a master communications schedule
// from the ModBus Device and Communications Variable assignment wrappers.
// The schedule constructor will attempt to minimise data requests to any
// given slave device by grouping data requests; also data reads will be
// performed before any data writes, this is to all the master to transfer
// data from one slave to another (read then write) in a perdictable manner.
//
//////////////////////////////////////////////////////////////////////

#include "V6defines.h"
#include "V6globals.h"
#include "V6Config.h"

#include "DataTable.hpp"

#include "TraceDefines.h"

#include "ScheduleWrapper.h"

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif

CModBusSchedule *CModBusSchedule::pInstance = NULL;
HANDLE CModBusSchedule::hCreationMutex = NULL;

//////////////////////////////////////
// ModBus schedule wrapper class
//
// Wraps up the data and control methods for the ModBus master schedule

//****************************************************************************
/// ModBus Master Schedule Wrapper: class singleton constructor
///
/// @return			new/existing class instance
///
/// @note --- Delete if not requried ---
//****************************************************************************
CModBusSchedule* CModBusSchedule::GetHandle() {
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;

	if (NULL == pInstance) {
		hCreationMutex = CreateMutex(NULL,						// No security descriptor
				FALSE,						// Mutex object not owned
				L"ModBusMasterSchedule");	// Object name

		waitSingleObjectResult = WaitForSingleObject(hCreationMutex, g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);

		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:
			// Object was signaled
			if (NULL == pInstance) {
				pInstance = new CModBusSchedule;
				LOG_INFO( TRACE_TRANSFER, "CModBusSchedule new Instance created");
			}
			if ( FALSE == ReleaseMutex(hCreationMutex)) {
				V6WarningMessageBox(NULL, L"Failed to release CModBusSchedule mutex", L"Error", MB_OK);
			} // End of IF

			break;

		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
			V6WarningMessageBox(NULL, L"CModBusSchedule WaitForSingleObject Error", L"Error", MB_OK);
			break;
		}
		// Close the Mutex as no longer required
		CloseHandle(hCreationMutex);
	}
	return pInstance;
}

//****************************************************************************
/// ModBus Master Schedule Wrapper: class constructor
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
CModBusSchedule::CModBusSchedule() {
	m_ScheduleTimer = NULL;
	Initialise();
}

//****************************************************************************
/// ModBus Master Schedule Wrapper: class destructor
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
CModBusSchedule::~CModBusSchedule() {

}

//****************************************************************************
/// ModBus Master Schedule Wrapper: Check if ModBus master is available and enabled
///
/// @return			TRUE/FALSE
///
/// @note --- Delete if not requried ---
//****************************************************************************
BOOL CModBusSchedule::IsEnabled() {
	BOOL bEnabled = FALSE;

	if ( TRUE == pSYSTEM_INFO->FWOptionModbusMasterAvailable()) {
		CCommsSetupConfig *pkCommsConfig = pGlbSetup->GetCommsSetupConfig();
		if (NULL != pkCommsConfig) {
			T_PCOMMUNICATIONS ptCommsData = pkCommsConfig->GetCommsBlock(CONFIG_COMMITTED);

			bEnabled = ptCommsData->ModbusMaster.Enabled;
		}
	}
	return bEnabled;
}

void CModBusSchedule::Destroy() {
	delete (m_ScheduleTimer);
	delete (pInstance);
}

//****************************************************************************
/// ModBus Master Schedule Wrapper: class clean-up
///
/// @return			none
///
/// @note			Cleans-up and allocated resource immediately before destruction
//****************************************************************************
void CModBusSchedule::CleanUp() {
	for (USHORT SlaveInstance = 0; SlaveInstance < MODBUSMASTER_SLAVE_SIZE; SlaveInstance++) {
		m_SlaveDevice[SlaveInstance].CleanUp();
	}
}

//****************************************************************************
/// ModBus Master Schedule Wrapper: class initialisation
///
/// @return			none
///
/// @note			Initialises a new schedule after construction
//****************************************************************************
void CModBusSchedule::Initialise() {
	m_pMasterConfig = NULL;

	for (USHORT SlaveInstance = 0; SlaveInstance < MODBUSMASTER_SLAVE_SIZE; SlaveInstance++) {
		m_SlaveDevice[SlaveInstance].Initialise();
	}
	if (NULL == m_ScheduleTimer) {
		m_ScheduleTimer = new (CTV6Timer)(TIMER_NORMAL_RES);
	}
}

//****************************************************************************
/// ModBus Master Schedule Wrapper: Schedule constructor
///
/// @return			none
///
/// @note			Construicts the master schedule after a configuration change
//****************************************************************************
void CModBusSchedule::BuildSchedule() {

	m_pMasterConfig = NULL;

	T_PCOMMUNICATIONS ptCommsData = NULL;

	CCommsSetupConfig *pkCommsConfig = pGlbSetup->GetCommsSetupConfig();

	if (pkCommsConfig != NULL) {
		ptCommsData = pkCommsConfig->GetCommsBlock(CONFIG_COMMITTED);
	}

	if (ptCommsData != NULL) {
		m_pMasterConfig = &ptCommsData->ModbusMaster;
	}

	// construct ModBus slave devices...
	if (NULL != m_pMasterConfig) {
		if ( TRUE == m_pMasterConfig->Enabled) {
			for (USHORT DeviceInstance = 0; DeviceInstance < MODBUSMASTER_SLAVE_SIZE; DeviceInstance++) {
				T_PMODBUSSLAVEDEV pSlaveData = &m_pMasterConfig->Slave[DeviceInstance];

				USHORT TransactionCount = 0;

				if ( TRUE == pSlaveData->Enabled) {
					m_SlaveDevice[DeviceInstance].Name(pSlaveData->FriendlyName);
					m_SlaveDevice[DeviceInstance].NetworkName(pSlaveData->NetworkName);
					m_SlaveDevice[DeviceInstance].NetworkAddress(pSlaveData->Address);
					m_SlaveDevice[DeviceInstance].Port((T_eCommsPort) pSlaveData->Port);
					m_SlaveDevice[DeviceInstance].Protocol((T_eProtocol) pSlaveData->Protocol);

					m_SlaveDevice[DeviceInstance].Used( TRUE);

					m_SlaveDevice[DeviceInstance].HasTalked( FALSE);
					m_SlaveDevice[DeviceInstance].HoldOff( FALSE);

					// Scan all the enabled transactions and total the required buffer space
					USHORT TransactionInstance = 0;
					USHORT TotalBuffer = 0;

					for (TransactionInstance = 0; TransactionInstance < MODBUSSLAVEDEV_TRANSACTIONS_SIZE;
							TransactionInstance++) {
						// Allocate the data buffer
						T_PMODBUSTX pSlaveTransaction = &pSlaveData->Transactions[TransactionInstance];

						// Check if the transaction is used
						if ( TRUE == pSlaveTransaction->Enabled) {
							TransactionCount++;
							TotalBuffer += pSlaveTransaction->NoOfItems;
						}
					}

					// Check if space is required...
					if (0 != TotalBuffer) {
						// Round up the allocated space to the nearest 16 floats, this (in theory) will reduce any memory fragmentation.
						//USHORT RoundUp = 16-(TotalBuffer % 16);
						USHORT RoundUp = (TotalBuffer / 16) + 1;
						RoundUp *= 16;

						//byte* DeviceBuffer = (byte *)malloc( (TotalBuffer+RoundUp) * sizeof( float) );
						byte *DeviceBuffer = (byte*) malloc(RoundUp * sizeof(float));
						m_SlaveDevice[DeviceInstance].BaseBuffer(DeviceBuffer);

						// Now divide the buffer between the individual transactions
						byte *BasePointer = DeviceBuffer;
						if (NULL != DeviceBuffer) {
							for (TransactionInstance = 0; TransactionInstance < MODBUSSLAVEDEV_TRANSACTIONS_SIZE;
									TransactionInstance++) {
								// Allocate the data buffer
								T_PMODBUSTX pSlaveTransaction = &pSlaveData->Transactions[TransactionInstance];

								// Check if the transaction is used
								if ( TRUE == pSlaveTransaction->Enabled) {
									m_SlaveDevice[DeviceInstance].SetTransactionBuffer(TransactionInstance,
											BasePointer);
									BasePointer += pSlaveTransaction->NoOfItems * sizeof(float);
								} // if
							} // for
						} // if
					} // if
				} // if
				else {
					m_SlaveDevice[DeviceInstance].Used( FALSE);
				}

				m_SlaveDevice[DeviceInstance].NumTransactions(TransactionCount);

				m_SlaveDevice[DeviceInstance].ClearErrorCount();
				m_SlaveDevice[DeviceInstance].ClearGoodCount();
				m_SlaveDevice[DeviceInstance].ClearOpenErrors();
				m_SlaveDevice[DeviceInstance].ClearReadFailures();
			} // for
		} // if
	} // if
}

//****************************************************************************
/// ModBus Master Schedule Wrapper: Execute master schedule
///
/// @return			none
///
/// @note			Perform a single pass of the Master Schedule
//****************************************************************************

void CModBusSchedule::RunMasterSchedule() {
	BOOL bEndFound = FALSE;

	if (NULL == m_pMasterConfig) {
		BuildSchedule();
		sleep(100);
	} else if (IsEnabled()) {
		// Get schedule start time
		m_ScheduleTimer->StartTimer();

		for (USHORT DeviceInstance = 0; DeviceInstance < MODBUSMASTER_SLAVE_SIZE; DeviceInstance++) {
			// Process slave device...
			T_PMODBUSSLAVEDEV pSlaveData = &m_pMasterConfig->Slave[DeviceInstance];

			m_SlaveDevice[DeviceInstance].TimeToService(0);
			ULONG DeviceStartTime = (ULONG) m_ScheduleTimer->ElapsedTimeInMilliSeconds();

			if ( TRUE == pSlaveData->Enabled) {
				// Check if the slave device is open
				BOOL bIsOpen = m_SlaveDevice[DeviceInstance].IsOpen();
				BOOL bHoldOff = FALSE;

				// Note:
				// If this is an Ethernet device, and the IP address is already in use we need to use the existing connection;
				// some older devices will only allow one host, creating a second won't work!
				if (eEthernet == m_SlaveDevice[DeviceInstance].Port()) {
					if ( TRUE == m_pMasterConfig->LegacySettings) {
						if ( FALSE == bIsOpen &&
						TRUE == m_SlaveDevice[DeviceInstance].HoldOff()) {
							bHoldOff = TRUE;
							m_SlaveDevice[DeviceInstance].HoldOff( FALSE);
						} else {
							m_SlaveDevice[DeviceInstance].HoldOff( TRUE);
						}
					}

					// Scan Other devices to see if connection has already been made
					for (USHORT OtherDevice = 0; OtherDevice < DeviceInstance; OtherDevice++) {
						if (m_SlaveDevice[OtherDevice].Port() == eEthernet) // only interested in ethernet ports (JLP)
								{
							if (0
									== wcscmp(m_SlaveDevice[OtherDevice].NetworkName(),
											m_SlaveDevice[DeviceInstance].NetworkName())) {
								// Found another connection to the same device
								if (m_SlaveDevice[OtherDevice].Connection() != NULL) // check valid before overwriting (JLP)
									m_SlaveDevice[DeviceInstance].Connection(m_SlaveDevice[OtherDevice].Connection());
							}
						}
					}
				}

				if ( FALSE == bHoldOff &&
				TRUE == m_SlaveDevice[DeviceInstance].Open()) {
					// If legacy ethernet is set, don't open and talk in the same pass (causes problems for V5's); this should have no effect on RS485 handling
					if (( FALSE == m_pMasterConfig->LegacySettings)
							|| ( TRUE == m_pMasterConfig->LegacySettings && TRUE == bIsOpen)) {
						for (USHORT TransactionInstance = 0; TransactionInstance < MODBUSSLAVEDEV_TRANSACTIONS_SIZE;
								TransactionInstance++) {
							// Process slave transaction...

							T_PMODBUSTX pSlaveTransaction = &pSlaveData->Transactions[TransactionInstance];

							if ( TRUE == pSlaveTransaction->Enabled) {
								if (0 == pSlaveTransaction->Dir) {
									// Read and process slave data
									SlaveRead(pSlaveData, DeviceInstance, TransactionInstance);
								} else  // Write data
								{
									// Build data and write to the slave
									SlaveWrite(pSlaveData, DeviceInstance, TransactionInstance);
								}
								//if ( eRS485 == m_SlaveDevice[DeviceInstance].Port( ) )
								{
									sleep( RS485_MESSAGE_SLEEP);
								}
							}
						}

						// Calculate and set device time to service
						m_SlaveDevice[DeviceInstance].TimeToService(
								(ULONG) m_ScheduleTimer->ElapsedTimeInMilliSeconds() - DeviceStartTime);

						if (eEthernet == m_SlaveDevice[DeviceInstance].Port()) {
							if ( TRUE == m_pMasterConfig->LegacySettings) {
								sleep( LEGACY_TRAFFIC_REDUCTION_TIME);
							}
							//else
							//{
							//	sleep( TRAFFIC_REDUCTION_TIME );
							//}
						}
					}
				} else {
					m_SlaveDevice[DeviceInstance].UpdateErrorCount();

					if (e_OK == m_SlaveDevice[DeviceInstance].ErrorState()) {
						m_SlaveDevice[DeviceInstance].ErrorState(e_CommsErrors);
					} else if (e_CommsErrors == m_SlaveDevice[DeviceInstance].ErrorState()) {
						m_SlaveDevice[DeviceInstance].ErrorState(e_OffLine);
					} else {
						m_SlaveDevice[DeviceInstance].UpdateReadFailures();

						if ( MB_MAX_FAILURES < m_SlaveDevice[DeviceInstance].ReadFailures()) {
							ReadError(pSlaveData, DeviceInstance);
						}
					}
				}
			}
		}

		// Get schedule end time
		m_ScheduleTimer->StopTimer();

		// Calculate required sleep time (if any)
		m_RunTime = (LONG) m_ScheduleTimer->ElapsedTimeInMilliSeconds();

		USHORT PollSeconds = m_pMasterConfig->PollRate;
		DWORD dwSleepTime = 0;

		if (m_RunTime > (ULONG) (PollSeconds * 1000)) {	// Default sleep
			m_OverRunTime = m_RunTime - (ULONG) (PollSeconds * 1000);
		} else {	// Scheduler over-run
			m_OverRunTime = 0L;
			dwSleepTime = (ULONG) (PollSeconds * 1000) - m_RunTime;
		}

		if ( SCHEDULER_MINIMUM_SLEEP > dwSleepTime) {
			dwSleepTime = SCHEDULER_MINIMUM_SLEEP;			// Minimum schedule sleep time
		}
		m_QuietTime = dwSleepTime;
		sleep(dwSleepTime);
	} else {
		sleep(1000);
	}
}

//****************************************************************************
/// ModBus Master Schedule Wrapper: read from slave device
///
/// @return	
///
/// @note			
//****************************************************************************
// private
void CModBusSchedule::SlaveRead(T_PMODBUSSLAVEDEV pSlaveData, USHORT DeviceInstance, USHORT TransactionInstance) {
	// Gather common data...
	T_PMODBUSTX pSlaveTransaction = &pSlaveData->Transactions[TransactionInstance];
	T_eDataRequest Request = e_ReadMultipleRegisters;
	USHORT DataType = pSlaveTransaction->DataType;
	USHORT Address = pSlaveTransaction->StartAddr;
	USHORT BlockSize = 0;

	// Calculate the block size
	if (0 == pSlaveTransaction->Map || 1 == pSlaveTransaction->Map) {
		BlockSize = pSlaveTransaction->NoOfItems;
	} else {
		switch (DataType) {
		case 0: // short
			BlockSize = pSlaveTransaction->NoOfItems;
			break;
		case 1: // ushort
			BlockSize = pSlaveTransaction->NoOfItems;
			break;
		case 2: // float
			BlockSize = pSlaveTransaction->NoOfItems * 2;
			break;
		default:
			break;
		}
	}

	if (0 < BlockSize)	// Sanity check
			{
		// Decide which register map to read
		switch (pSlaveTransaction->Map) {
		case 0: // Coil status
			Request = e_ReadCoils;
			break;
		case 1: // Input status
			Request = e_ReadDiscreteInputs;
			break;
		case 2: // Holding Register
			Request = e_ReadMultipleRegisters;
			break;
		case 3: // Input Register
			Request = e_ReadInputRegisters;
			break;
		}

		// Decide which register map to read
		switch (pSlaveTransaction->Map) {
		case 0: // Coil status
			Request = e_ReadCoils;
			break;
		case 1: // Input status
			Request = e_ReadDiscreteInputs;
			break;
		case 2: // Holding Register
			Request = e_ReadMultipleRegisters;
			break;
		case 3: // Input Register
			Request = e_ReadInputRegisters;
			break;
		}

		// Input transaction
		if ( TRUE == m_SlaveDevice[DeviceInstance].Read(Request, Address, BlockSize, (void*) m_Buffer)) {
			m_SlaveDevice[DeviceInstance].HasTalked( TRUE);

			//qDebug("Process Read Data.\n" );
			switch (Request) {
			case e_ReadCoils:
			case e_ReadDiscreteInputs: {
				float *pValue = (float*) m_SlaveDevice[DeviceInstance].GetTransactionBuffer(TransactionInstance);
				byte *pBuffer = (byte*) m_Buffer;
				USHORT Count = 0;

				do {
					byte Value = *pBuffer;

					for (USHORT Bit = 0; (Bit < 8) && (Count < BlockSize); Bit++) {
						float DigitalValue = 0.0F;
						if ((Value & 0x01) != 0) {
							DigitalValue = 1.0F;
						}
						memcpy(pValue, &DigitalValue, sizeof(float));
						Value >>= 1;
						pValue++;
						Count++;
					}
					pBuffer++;
				} while (Count < BlockSize);
			}
				break;
			case e_ReadMultipleRegisters:
			case e_ReadInputRegisters: {
				float *pValue = (float*) m_SlaveDevice[DeviceInstance].GetTransactionBuffer(TransactionInstance);
				byte *pBuffer = m_Buffer;

				for (USHORT Item = 0; Item < pSlaveTransaction->NoOfItems; Item++) {
					switch (DataType) {
					case 0: // Short
					{
						*pValue = *(short*) pBuffer;
						pValue++;
						pBuffer += sizeof(short);
						break;
					}
					case 1: // Ushort
					{
						*pValue = *(USHORT*) pBuffer;
						pValue++;
						pBuffer += sizeof(USHORT);
						break;
					}
					case 2: // Float
					{
						float fTemp = *(float*) pBuffer;
						if (eModBusX == m_SlaveDevice[DeviceInstance].Protocol()) {
							MbusDataTable::ModFloatSwap(FP_LB, fTemp, (float) *pValue);
						} else {
							MbusDataTable::ModFloatSwap(FP_B, fTemp, (float) *pValue);
						}
						pValue++;
						pBuffer += sizeof(float);
						break;
					}
					} // switch...
				} // for...
			} // case...
				break;
			} // switch

			m_SlaveDevice[DeviceInstance].UpdateGoodCount();

			if (e_OffLine == m_SlaveDevice[DeviceInstance].ErrorState()) {
				m_SlaveDevice[DeviceInstance].ErrorState(e_CommsErrors);
			} else if (e_CommsErrors == m_SlaveDevice[DeviceInstance].ErrorState()) {
				m_SlaveDevice[DeviceInstance].ErrorState(e_OK);
				m_SlaveDevice[DeviceInstance].ClearReadFailures();

			}
		} // if ( read(...
		else {
			if ( FALSE == m_SlaveDevice[DeviceInstance].HasTalked()) {
				m_SlaveDevice[DeviceInstance].ErrorState(e_OffLine);

				// Mark the value as bad
				float *pValue = (float*) m_SlaveDevice[DeviceInstance].GetTransactionBuffer(TransactionInstance);

				for (USHORT Item = 0; Item < pSlaveTransaction->NoOfItems; Item++) {
					(float) *pValue = MB_COMMS_NOT_STARTED;
					pValue++;
				} // for...
			}
			// Data read failed; this won't normaly happen, a connection loss would be trapped by the scheduler level.
			m_SlaveDevice[DeviceInstance].UpdateErrorCount();

			if (e_OK == m_SlaveDevice[DeviceInstance].ErrorState()) {
				m_SlaveDevice[DeviceInstance].ErrorState(e_CommsErrors);
			} else if (e_CommsErrors == m_SlaveDevice[DeviceInstance].ErrorState()) {
				m_SlaveDevice[DeviceInstance].UpdateReadFailures();

				if ( MB_MAX_FAILURES < m_SlaveDevice[DeviceInstance].ReadFailures()) {
					m_SlaveDevice[DeviceInstance].ErrorState(e_OffLine);

					// Mark the value as bad
					float *pValue = (float*) m_SlaveDevice[DeviceInstance].GetTransactionBuffer(TransactionInstance);

					for (USHORT Item = 0; Item < pSlaveTransaction->NoOfItems; Item++) {
						(float) *pValue = MB_COMMS_LOST;
						pValue++;
					} // for...
				}
			}
			m_SlaveDevice[DeviceInstance].Close();
			m_SlaveDevice[DeviceInstance].UpdateErrorCount();
		}
	}
}

//****************************************************************************
/// ModBus Master Schedule Wrapper: fill read request with an error code
///
/// @return	
///
/// @note			
//****************************************************************************
// private
void CModBusSchedule::ReadError(T_PMODBUSSLAVEDEV pSlaveData, USHORT DeviceInstance) {
	// Device is off-line, fill and transaction data reads with MB_NO_COMMS
	for (USHORT Transaction = 0; Transaction < MODBUSSLAVEDEV_TRANSACTIONS_SIZE; Transaction++) {
		T_PMODBUSTX pSlaveTransaction = &pSlaveData->Transactions[Transaction];

		// If the transaction is enabled
		if ( TRUE == pSlaveTransaction->Enabled) {
			// and it's a read
			if (0 == pSlaveTransaction->Dir) {
				// and there's data to read
				if (0 < pSlaveTransaction->NoOfItems) {
					// Mark the value as no comms
					float *pValue = (float*) m_SlaveDevice[DeviceInstance].GetTransactionBuffer(Transaction);

					for (USHORT Item = 0; Item < pSlaveTransaction->NoOfItems; Item++) {
						(float) *pValue = MB_NO_COMMS;
						pValue++;
					} // for...
				}
			}
		}
	}
}

//****************************************************************************
/// ModBus Master Schedule Wrapper: write to slave device
///
/// @return	
///
/// @note			
//****************************************************************************
// private
void CModBusSchedule::SlaveWrite(T_PMODBUSSLAVEDEV pSlaveData, USHORT DeviceInstance, USHORT TransactionInstance) {
	T_PMODBUSTX pSlaveTransaction = &pSlaveData->Transactions[TransactionInstance];
	USHORT DataType = pSlaveTransaction->DataType;
	USHORT BlockSize = 0;

	USHORT Address = pSlaveTransaction->StartAddr;
	T_eDataRequest Request = e_WriteMultipleRegisters;

	// Calculate the block size
	if (0 == pSlaveTransaction->Map || 1 == pSlaveTransaction->Map) {
		BlockSize = pSlaveTransaction->NoOfItems;
	} else {
		switch (DataType) {
		case 0: // short
			BlockSize = pSlaveTransaction->NoOfItems;
			break;
		case 1: // ushort]
			BlockSize = pSlaveTransaction->NoOfItems;
			break;
		case 2: // float
			BlockSize = pSlaveTransaction->NoOfItems * 2;
			break;
		default:
			break;
		}
	}
	// Gather and convert data
	//
	// Only writing float values (pens) is currently supported.
	//
	float *pValue = (float*) m_SlaveDevice[DeviceInstance].GetTransactionBuffer(TransactionInstance);
	// E528446[
	// To fix Modbus Byte count issue please comment out the following line
	// BlockSize = pSlaveTransaction->NoOfItems * sizeof( float );
	//]

	// Construct the data block
	for (USHORT PenInstance = (pSlaveTransaction->DataItemStart - 1);
			PenInstance < (pSlaveTransaction->NoOfItems + (pSlaveTransaction->DataItemStart - 1)); PenInstance++) {
		float Value = 0.0F;

		CDataItem *DataItem = (CDataItem*) pGlbDIT->GetDataItemPtr(DI_PEN, DI_IO_ANALOGUE, PenInstance);
		float fTemp = DataItem->GetFPValue();
		if (eModBusX == m_SlaveDevice[DeviceInstance].Protocol()) {
			MbusDataTable::ModFloatSwap(FP_LB, fTemp, Value);
		} else {
			MbusDataTable::ModFloatSwap(FP_B, fTemp, Value);
		}
		memcpy(pValue, (void*) &Value, sizeof(float));
		pValue++;
	}

	// Output transaction
	if ( TRUE
			== m_SlaveDevice[DeviceInstance].Write(Request, Address, BlockSize,
					(void*) m_SlaveDevice[DeviceInstance].GetTransactionBuffer(TransactionInstance))) {
		// Data write OK
		m_SlaveDevice[DeviceInstance].HasTalked( TRUE);

		m_SlaveDevice[DeviceInstance].UpdateGoodCount();

		if (e_OffLine == m_SlaveDevice[DeviceInstance].ErrorState()) {
			m_SlaveDevice[DeviceInstance].ErrorState(e_CommsErrors);
		} else if (e_CommsErrors == m_SlaveDevice[DeviceInstance].ErrorState()) {
			m_SlaveDevice[DeviceInstance].ErrorState(e_OK);
		}
	} else {
		// Data write failed
		m_SlaveDevice[DeviceInstance].UpdateErrorCount();

		if (e_OK == m_SlaveDevice[DeviceInstance].ErrorState()) {
			m_SlaveDevice[DeviceInstance].ErrorState(e_CommsErrors);
		} else if (e_CommsErrors == m_SlaveDevice[DeviceInstance].ErrorState()) {
			m_SlaveDevice[DeviceInstance].ErrorState(e_OffLine);
		}
		m_SlaveDevice[DeviceInstance].Close();
		m_SlaveDevice[DeviceInstance].UpdateErrorCount();
	}
}

//****************************************************************************
/// ModBus Master Schedule Wrapper: Read ModBus master value (static accessor)
///
/// @param[in] Device		- Slave device instance (0..(MODBUSMASTER_SLAVE_SIZE-1))
/// @param[in] Transaction	- Device transaction instance (0..(MODBUSSLAVEDEV_TRANSACTIONS_SIZE-1))
/// @param[in] Item			- Requested data item instance (0..)
///
/// @return		pointer to the value of NULL in event of an error
///
/// @note			
//****************************************************************************
//static
float* CModBusSchedule::ReadModBusDataItem(USHORT Device, USHORT Transaction, USHORT Item) {
	static CModBusSchedule *ScheduleSingleton = NULL;
	float *pfResult = NULL;

	if (NULL == ScheduleSingleton) {
		ScheduleSingleton = CModBusSchedule::GetHandle();
	} else {
		pfResult = ScheduleSingleton->ReadDataItem(Device - 1, Transaction - 1, Item - 1);
	}
	return pfResult;
}

//****************************************************************************
/// ModBus Master Schedule Wrapper: Read ModBus master value
///
/// @param[in] Device		- Slave device instance (0..(MODBUSMASTER_SLAVE_SIZE-1))
/// @param[in] Transaction	- Device transaction instance (0..(MODBUSSLAVEDEV_TRANSACTIONS_SIZE-1))
/// @param[in] Item			- Requested data item instance (0..)
///
/// @return		pointer to the value of NULL in event of an error
///
/// @note			
//****************************************************************************
float* CModBusSchedule::ReadDataItem(USHORT Device, USHORT Transaction, USHORT Item) {
	static float OffMapValue = MB_OUTSIDE_MAP;

	float *pfRetuen = &OffMapValue;

	// Sanity test
	if (Device < MODBUSMASTER_SLAVE_SIZE && Transaction < MODBUSSLAVEDEV_TRANSACTIONS_SIZE && NULL != m_pMasterConfig) {
		// Check is device and transaction are enabled
		T_PMODBUSSLAVEDEV pSlaveData = &m_pMasterConfig->Slave[Device];
		if ( TRUE == pSlaveData->Enabled) {
			T_PMODBUSTX pSlaveTransaction = &pSlaveData->Transactions[Transaction];

			if ( TRUE == pSlaveTransaction->Enabled) {
				// Check if the requested data item is within range
				if (Item < pSlaveTransaction->NoOfItems) {
					pfRetuen = m_SlaveDevice[Device].DataItem(Transaction, Item);
				}
			}
		}
	}
	return pfRetuen;
}

//****************************************************************************
/// ModBus Master Schedule Wrapper: Check if a ModBus master register is valid
///
/// @param[in] Device		- Slave device instance (0..(MODBUSMASTER_SLAVE_SIZE-1))
/// @param[in] Transaction	- Device transaction instance (0..(MODBUSSLAVEDEV_TRANSACTIONS_SIZE-1))
/// @param[in] Item			- Requested data item instance (0..)
///
/// @return		TRUE if valid, else FALSE
///
/// @note			
//****************************************************************************
BOOL CModBusSchedule::IsRegisterValid(USHORT Device, USHORT Transaction, USHORT Item) {
	BOOL bResult = FALSE;

	// Sanity test
	if (Device < MODBUSMASTER_SLAVE_SIZE && Transaction < MODBUSSLAVEDEV_TRANSACTIONS_SIZE && NULL != m_pMasterConfig) {
		// Check is device and transaction are enabled
		T_PMODBUSSLAVEDEV pSlaveData = &m_pMasterConfig->Slave[Device];
		if ( TRUE == pSlaveData->Enabled) {
			T_PMODBUSTX pSlaveTransaction = &pSlaveData->Transactions[Transaction];

			if ( TRUE == pSlaveTransaction->Enabled) {
				// Check if the requested data item is within range
				if (Item < pSlaveTransaction->NoOfItems) {
					bResult = TRUE;
				}
			}
		}
	}
	return bResult;
}

//****************************************************************************
/// ModBus Master Schedule Wrapper: Check if a ModBus master register is valid
///
/// @param[in] Device		- Slave device instance (1..(MODBUSMASTER_SLAVE_SIZE))
/// @param[in] Transaction	- Device transaction instance (1..(MODBUSSLAVEDEV_TRANSACTIONS_SIZE))
/// @param[in] Item			- Requested data item instance (1..)
///
/// @return		TRUE if valid, else FALSE
///
/// @note			
//****************************************************************************
// static
BOOL CModBusSchedule::IsMasterRegisterValid(USHORT Device, USHORT Transaction, USHORT Item) {
	static CModBusSchedule *ScheduleSingleton = NULL;
	BOOL bResult = FALSE;

	if (NULL == ScheduleSingleton) {
		ScheduleSingleton = CModBusSchedule::GetHandle();
	} else {
		bResult = ScheduleSingleton->IsRegisterValid(Device - 1, Transaction - 1, Item - 1);
	}
	return bResult;
}

//****************************************************************************
/// ModBus Master Schedule Wrapper: Read ModBus device error count
///
/// @param[in] Device		- Slave device instance (0..(MODBUSMASTER_SLAVE_SIZE-1))
///
/// @return		Current error count value
///
/// @note			
//****************************************************************************
ULONG CModBusSchedule::ReadErrorCount(USHORT Device) {
	ULONG lResult = 0L;

	lResult = m_SlaveDevice[Device].ErrorCount();

	return lResult;
}

//****************************************************************************
/// ModBus Master Schedule Wrapper: Read ModBus device Good Message count
///
/// @param[in] Device		- Slave device instance (0..(MODBUSMASTER_SLAVE_SIZE-1))
///
/// @return		Current error count value
///
/// @note			
//****************************************************************************
ULONG CModBusSchedule::ReadMessageCount(USHORT Device) {
	ULONG lResult = 0L;

	lResult = m_SlaveDevice[Device].GoodCount();

	return lResult;
}

//****************************************************************************
/// ModBus Master Schedule Wrapper: Build Test Data
///
/// @return			none
///
/// @note			Builds a simple set of test data
//****************************************************************************
void CModBusSchedule::BuildTestData() {
	USHORT Instance = 0;
	// Build a test device(s)

	/*
	 m_SlaveDevice[Instance].Name( L"UDC3200" );
	 m_SlaveDevice[Instance].NetworkName( L"None" );
	 m_SlaveDevice[Instance].Port( eRS485 );
	 m_SlaveDevice[Instance].NetworkAddress( 1 );
	 m_SlaveDevice[Instance].Protocol( eModBusX );
	 m_SlaveDevice[Instance].Used( TRUE );
	 Instance++;

	 m_SlaveDevice[Instance].Name( L"eZtrend" );
	 m_SlaveDevice[Instance].NetworkName( L"None" );
	 m_SlaveDevice[Instance].Port( eRS485 );
	 m_SlaveDevice[Instance].NetworkAddress( 2 );
	 m_SlaveDevice[Instance].Protocol( eModBusX );
	 m_SlaveDevice[Instance].Used( TRUE );
	 Instance++;


	 // Build test variable assignments
	 Instance = 0;
	 
	 // UDC3200
	 m_TransactionTable[Instance].RegisterType( e_ReadInputRegisters );
	 m_TransactionTable[Instance].RegisterAddress( 73 ); // Analogue input 1
	 m_TransactionTable[Instance].DateType( 

// SlaveDevice.h: ModBus slave wrapper.
//////////////////////////////////////////////////////////////////////

#if !defined(__SLAVEDEVICE_H__)
#define __SLAVEDEVICE_H__

#include "ModBusCommon.h"
#include "V6defines.h"
#include "V6globals.h"
#include "V6Config.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// Data structures:

// Slave device:
// Contains the data required to identify and communicate with a slave device.
typedef struct {
	BOOL Used;					// Device entry is in use
	WCHAR Name[32];				// Device name
	T_eCommsPort Port;					// Communications port
	WCHAR NetworkName[32];		// Network name/IP Address
	USHORT NetworkAddress;			// Device network address
	T_eProtocol Protocol;				// Communications protocol (ModBus/ModBus-X)
	T_eErrorState ErrorState;				// Current device error state
	ULONG ErrorCount;				// Count of failed messages
	ULONG GoodCount;				// Count of good messages
	ULONG OpenErrors;				// Count of failed open attempts
	ULONG TimeToService;			// Time to process device transactions (in ms)
	USHORT ReadFailures;			// Number of (successive) times a read has failed
	BOOL HasTalked;				// Device has responded to a data request (used for initial default value)
	BOOL HoldOff;				// Device is legacy and in an error state, hold-off the next poll
} T_MB_SLAVE_DEVICE;

// Wrapper for a ModBus slave device
class CModBusSlaveDevice {
public:		// methods
	CModBusSlaveDevice();
	~CModBusSlaveDevice();
	void Initialise();
	void CleanUp();
	BOOL Open();
	BOOL IsOpen();
	BOOL Open(T_eCommsPort Port);
	void Close();
	BOOL Read(T_eDataRequest Type, USHORT Address, USHORT Size, void *Buffer);
	BOOL Write(T_eDataRequest Type, USHORT Address, USHORT Size, void *Buffer);

	void Used(BOOL State) {
		m_Device.Used = State;
	}
	;
	BOOL Used() {
		return m_Device.Used;
	}
	;
	void Name(WCHAR *Name) {
#if _MSC_VER < 1400 
		wcsncpy(m_Device.Name, Name, 32);
#else
		wcsncpy_s( m_Device.Name, sizeof(m_Device.Name)/sizeof(WCHAR),Name, 32 ); 
#endif

	}
	;
	WCHAR* Name() {
		return m_Device.Name;
	}
	;
	void Port(T_eCommsPort Port) {
		m_Device.Port = Port;
	}
	;
	T_eCommsPort Port() {
		return m_Device.Port;
	}
	;
	void NetworkName(WCHAR *Name) {
#if _MSC_VER < 1400 
		wcsncpy(m_Device.NetworkName, Name, 32);
#else
		wcsncpy_s( m_Device.NetworkName,sizeof(m_Device.NetworkName)/sizeof(WCHAR), Name, 32 ); 
#endif

	}
	;
	WCHAR* NetworkName() {
		return m_Device.NetworkName;
	}
	;
	void NetworkAddress(USHORT Address) {
		m_Device.NetworkAddress = Address;
	}
	;
	USHORT NetworkAddress() {
		return m_Device.NetworkAddress;
	}
	;
	void Protocol(T_eProtocol Protocol) {
		m_Device.Protocol = Protocol;
	}
	;
	T_eProtocol Protocol() {
		return m_Device.Protocol;
	}
	;

	USHORT NumTransactions() {
		return m_NumTransactions;
	}
	;
	void NumTransactions(USHORT Number) {
		m_NumTransactions = Number;
	}
	;

	void ClearErrorCount() {
		m_Device.ErrorCount = 0L;
	}
	;
	void ClearGoodCount() {
		m_Device.GoodCount = 0L;
	}
	;
	void ClearOpenErrors() {
		m_Device.OpenErrors = 0L;
	}
	;
	ULONG ErrorCount() {
		return m_Device.ErrorCount;
	}
	;
	ULONG GoodCount() {
		return m_Device.GoodCount;
	}
	;
	void UpdateErrorCount() {
		m_Device.ErrorCount++;
	}
	;
	void UpdateGoodCount() {
		m_Device.GoodCount++;
	}
	;
	ULONG OpenErrors() {
		return m_Device.OpenErrors;
	}
	;
	void UpdateOpenErrors() {
		m_Device.OpenErrors++;
	}
	;

	void TimeToService(ULONG Time) {
		m_Device.TimeToService = Time;
	}
	;
	ULONG TimeToService() {
		return m_Device.TimeToService;
	}
	;

	void ErrorState(T_eErrorState State) {
		m_Device.ErrorState = State;
	}
	;
	T_eErrorState ErrorState() {
		return m_Device.ErrorState;
	}
	;

	void ClearReadFailures() {
		m_Device.ReadFailures = 0;
	}
	;
	void UpdateReadFailures() {
		m_Device.ReadFailures++;
	}
	;
	USHORT ReadFailures() {
		return m_Device.ReadFailures;
	}
	;

	BOOL HasTalked() {
		return m_Device.HasTalked;
	}
	;
	void HasTalked(BOOL State) {
		m_Device.HasTalked = State;
	}
	;

	BOOL HoldOff() {
		return m_Device.HoldOff;
	}
	;
	void HoldOff(BOOL State) {
		m_Device.HoldOff = State;
	}
	;

	// Individual transaction data buffers
	byte* GetTransactionBuffer(USHORT Transaction) {
		return m_TransactionBuffer[Transaction];
	}
	;
	void SetTransactionBuffer(USHORT Transaction, byte *Buffer) {
		m_TransactionBuffer[Transaction] = Buffer;
	}
	;

	// Base (total) transaction buffer
	byte* BaseBuffer() {
		return m_BaseBuffer;
	}
	;
	void BaseBuffer(byte *NewBuffer) {
		m_BaseBuffer = NewBuffer;
	}
	;

	// Individual data item accessors
	float* DataItem(USHORT Transaction, USHORT Instance);					// Read a ModBus data item
	void DataItem(USHORT Transaction, USHORT Instance, float Value);		// Set a ModBus data item

	class MbusMasterFunctions* Connection() {
		return m_pEthernetProtocol;
	}
	;
	void Connection(class MbusMasterFunctions *NewConnection) {
		m_pEthernetProtocol = NewConnection;
	}
	;

public:		// data

private:	// methods

private:	// data
//	static class MbusRtuMasterProtocol*	m_pRS485Protocol;
	class MbusMasterFunctions *m_pEthernetProtocol;
	T_MB_SLAVE_DEVICE m_Device;

	USHORT m_NumTransactions;
	byte *m_BaseBuffer;
	byte *m_TransactionBuffer[MODBUSSLAVEDEV_TRANSACTIONS_SIZE];
};

#endif // !defined(__SLAVEDEVICE_H__)

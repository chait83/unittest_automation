/****************************************************************************

 //    COPYRIGHT (c) 2020
 //   HONEYWELL INTERNATIONAL INC.
 //   ALL RIGHTS RESERVED

 // Legal rights of Honeywell Inc. in this software is distinct from
 // ownership of any medium in which the software is embodied. 
 // Copyright notices must be reproduced in any copies authorized by 
 // Honeywell International Inc.
 /*****************************************************************************/

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module:		FolderFilesHashGenerator
/// @n Filename:	FolderFilesHashGenerator.h
/// @n Description:	Contains class header of FolderFilesHashGenerator.
///
// **************************************************************************
#ifndef _INC_FOLDERFILESHASHUTILITY_H_INCLUDED
#define _INC_FOLDERFILESHASHUTILITY_H_INCLUDED

/** Revision History ********************************************************
 Author		Date		Notes
 ------ ------		------
 Usha		02.17.2020	Created
 Usha  02.28.2020 Added V6 Hash Code Method
 ***************************************************************************/
#include <string>
#include <vector>
#include "Defines.h"
using namespace std;

#include "FolderFilesHashUtility.h"

class CFolderFilesHashUtility {
public:
	CFolderFilesHashUtility() {
	}
	;
	~CFolderFilesHashUtility() {
	}
	;

	bool buildHashFile(TCHAR *input_dir_name, TCHAR *hash_file_name);
	bool checkHashFile(TCHAR *hash_file_name, bool isV6binaries = false);
	std::string getV6AppHashCode(TCHAR *hash_file_name);

private:
	bool processFiles(vector<wstring> &strwFiles, wstring strwHashFile);
	bool listFiles(wstring strwPath, wstring strwMask, vector<wstring> &strwFiles);
	string getCurrentBinariesPathName(const std::string &sFilePath, std::string sDirectoryPath);
};

#endif

/******************************************************************************************

 COPYRIGHT (c) 2004

 HONEYWELL INC.,

 ALL RIGHTS RESERVED

 This software is a copyrighted work and/or information protected

 as a trade secret. Legal rights of Honeywell Inc. in this

 software is distinct from ownership of any medium in which the

 software is embodied. Copyright or trade secret notices included

 must be reproduced in any copies authorized by Honeywell Inc.

 The information in this software is subject to change without

 notice and should not be considered as a commitment by Honeywell

 Inc.
 ******************************************************************************************
 Project : Debug Trace Logging Module
 Module  : 
 FileName : TraceLog.cpp
 Author(s)  : Martin M
 Description : Main trace logging class
 Date Of Creation : 12/07/2004
 Modification History : 
 Name					Date								Modifications
 ----					-----								-------------
 Martin M 12/07/2004 Created
 *******************************************************************************************/

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  Debug Trace Loging 
/// @n Filename: TraceLog.Cpp 
/// @n Description: Main trace log class 
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log:
//  8 Stability Project 1.3.1.3 7/2/2011 5:02:09 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  7 Stability Project 1.3.1.2 7/1/2011 4:39:02 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  6 Stability Project 1.3.1.1 3/17/2011 3:20:51 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  5 Stability Project 1.3.1.0 2/15/2011 3:04:05 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
//  4 V6 Firmware 1.3 4/20/2006 7:31:43 PM  Jason Parker  
//  corrected spelling
//  3 V6 Firmware 1.2 3/10/2006 6:13:01 PM  Roger Dawson  
//  Replaced INFINITE timeouts with globally defined timeout value.
//  2 V6 Firmware 1.1 10/20/2005 9:00:13 PM  Andy Kassell  Set
//  MessageBox to TOPMOST to ensure it is displayed on CE 5 application
//  1 V6 Firmware 1.0 8/12/2004 3:55:06 PM  Martin Miller  
// $
//
// **************************************************************************
// TraceLog.cpp: implementation of the CTraceLog class.
//
//////////////////////////////////////////////////////////////////////
#include "Stdio.h"
#include "StdArg.h"
#include "StdLib.h"

#include "Trace.h"
#include "V6defines.h"

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif

// Instance pointer (static)
CTraceLog *CTraceLog::m_pInstance = NULL;
QMutex hCreationMutex;
QMutex csTrace;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

//****************************************************************************
/// Instance provides access to and a constructor for the CTraceLog object 
///
/// @return A pointer to the current instance of the class or a pointer to the new one 
/// can also return NULL in event of a creation failure
//****************************************************************************

CTraceLog* CTraceLog::Instance() {
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;

	if (NULL == m_pInstance) {
		hCreationMutex = CreateMutex(NULL,					// No security descriptor
				FALSE,					// Mutex object not owned
				L"Trace");	// Object name

		waitSingleObjectResult = hCreationMutex.tryLock(g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);

		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:
			// Object was signaled
			if (NULL == m_pInstance) {
				m_pInstance = new CTraceLog();
			}
			if ( FALSE == hCreationMutex.unlock()) {
				MessageBox(NULL, L"Failed to release Trace mutex", L"Error", MB_OK);
				DebugBreak();
			} // End of IF

			break;

		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
			MessageBox(NULL, L"Trace WaitForSingleObject Error", L"Error", MB_OK);
			DebugBreak();
			break;
		}
		// Close the Mutex as no longer required
		CloseHandle (hCreationMutex);
	}

	return m_pInstance;
}

//****************************************************************************
/// Protected constructor, provides secondary initialisation on the new
///
//****************************************************************************

CTraceLog::CTraceLog() {
	m_FirstMessage = TRUE;
	InitializeCriticalSection (&csTrace);
}

//****************************************************************************
/// Class descructor, deletes the class instance and nulls the instance pointer
///
//****************************************************************************

CTraceLog::~CTraceLog() {
	// delete m_pInstance;	// Can't call delete here
	m_pInstance = NULL;
}

//****************************************************************************
/// Main message method, formats a message body
///
/// @param[in] 	  Message		- Trace message
/// @param[in] 	  ...			- Arguments to be expanded into the message
///
//****************************************************************************

void CTraceLog::Message(QString Message, ...) {
	// Filter unwanted messages
	if ((TRACE_FILTER & m_LastModule) == 0)
		return;

	EnterCriticalSection (&csTrace);

	va_list Args;
	QString pointer = m_Buffer;

	va_start(Args, Message);
	int noOfChars = vswprintf_s(m_Buffer, sizeof(m_Buffer) / sizeof(WCHAR), Message, Args);
	pointer += noOfChars;
	va_end(Args);

	// Append new line to the end of the message
	wcscat_s(pointer, (sizeof(m_Buffer) / sizeof(WCHAR)) - noOfChars, L"\r\n");
	pointer += wcslen(L"\r\n");

	Output( TRUE, m_LastLevel, m_Buffer);

	csTrace.lock();
}

//****************************************************************************
/// Message header method, formats the message header
///
/// @param[in] 	  Module		- Module ID (bit mask) used for filtering
/// @param[in] 	  Level		- Message level
/// @param[in] 	  File			- File name (may be null)
/// @param[in] 	  Function		- Function name (may be null)
/// @param[in] 	  Line			- Line number (0 if not wanted)
///
//****************************************************************************
void CTraceLog::Header(unsigned long Module, int Level, char *File, char *Function, short Line) {
	// Filter unwanted messages
	if ((TRACE_FILTER & Module) == 0)
		return;

	EnterCriticalSection (&csTrace);

	QString pointer = m_Buffer;
	QDateTime systemTime;

	m_LastModule = Module;
	m_LastLevel = Level;

	// If this is the first message, generate a log start and date message
	if ( TRUE == m_FirstMessage) {
		m_LastMessageTime.TimeNow();

		swprintf(m_Buffer, L"Log Started: %02d/%02d\r\n", m_LastMessageTime.GetDay(), m_LastMessageTime.GetMonth() + 1);
		Output( FALSE, Level, m_Buffer);
		m_FirstMessage = FALSE;
	}
	m_ThisMessageTime.TimeNow();

	// If the day has changed since the last message, write a new date message
	if (m_ThisMessageTime.GetDay() != m_LastMessageTime.GetDay()) {
		swprintf(m_Buffer, L"Date: %02d/%02d\r\n", m_ThisMessageTime.GetDay(), m_ThisMessageTime.GetMonth() + 1);
		Output( FALSE, Level, m_Buffer);
	}
	m_LastMessageTime = m_ThisMessageTime;

	// Construct the message time
	m_ThisMessageTime.GetSYSTEMTIME(&systemTime);
	pointer += swprintf(m_Buffer, L"%2d:%02d:%02d\t", systemTime.wHour, systemTime.wMinute, systemTime.wSecond);

	// if a file name has been supplied use it, else use "-fl- "
	if (File != NULL) {
		size_t pNoOfChars;
		mbstowcs_s(&pNoOfChars, pointer, pointer - m_Buffer, File, 100);
		wcscat_s(pointer, pointer - m_Buffer, L"\t");
		pointer += wcslen(pointer);

//		pointer += swprintf( pointer, L"%s\t", File );
	} else {
		wcscat_s(pointer, pointer - m_Buffer, L"-fl-\t");
		pointer += wcslen(L"-fl-\t");
	}

	// if a function name has been supplied use it, else use "-fn- "
	if (Function != NULL) {
		size_t pNoOfChars;
		mbstowcs_s(&pNoOfChars, pointer, pointer - m_Buffer, Function, 100);
		wcscat_s(pointer, pointer - m_Buffer, L"\t");
		pointer += wcslen(pointer);

//		pointer += swprintf( pointer, L"%s\t", Function );
	} else {
		wcscat_s(pointer, pointer - m_Buffer, L"-fn-\t");
		pointer += wcslen(L"-fn-\t");
	}

	// if a line number has been supplied use it, else use "-ln "
	if (Line > 0)
		pointer += swprintf(pointer, L"ln(%d)\t", Line);
	else {
		wcscat_s(pointer, pointer - m_Buffer, L"-ln-\t");
		pointer += wcslen(L"-ln-\t");
	}

	Output( FALSE, Level, m_Buffer);

	csTrace.lock();
}

//****************************************************************************
/// Output message method, decides what device to send each message type
///
/// @param[in] 	  Type		TRUE to perform critical test, FALSE for no critical test
/// @param[in] 	  Level	Message level
/// @param[in] 	  Text		Message text
///
//****************************************************************************
void CTraceLog::Output(char Type, char Level, QString Text) {
	switch (Level) {
	case LEVEL_INFO:							// Output INFO message
		DefaultOutput(Text);
		break;
	case LEVEL_TESTPOINT:						// Output TESTPOINT message
		DefaultOutput(Text);
		break;
	case LEVEL_WARNING:							// Output WARNING message
		DefaultOutput(Text);
		break;
	case LEVEL_ERROR:							// Output ERROR messages
		DefaultOutput(Text);
		break;
	case LEVEL_CRITICAL:						// Output CRITICAL messages
		DefaultOutput(Text);

		if (Type == TRUE) {
			MessageBox(NULL, L"Application Closing.", L"Critical Error.",
					MB_ICONWARNING | MB_OK | MB_SETFOREGROUND | MB_TOPMOST);
			ExitProcess(1);
		}
		break;

	default:
		break;
	}
}

//****************************************************************************
/// Default message output, Windows qDebug system
///
/// @param[in] 	  Text		Message text 
///
//****************************************************************************
void CTraceLog::DefaultOutput(QString  Text) {
	qDebug(Text);
}

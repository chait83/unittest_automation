/// @file 
/// *****************************************************************
/// © Honeywell Trendview
/// *****************************************************************
/// @n Module : Internal Message Queue ( IMQ )
/// @n FileName: InternalMessageQueue.cpp
/// @n Desc  : Class Implementation for the CInternalMessageQueue
///
/// *****************************************************************
/// @b Revision @b History
/// *****************************************************************
/// $Log[4]:
/// 15  Stability Project 1.10.1.3 7/2/2011 4:58:00 PM Hemant(HAIL) 
/// Stability Project: Recorder source has been upgraded from IL
///  version of firmware to JF version of firmware.
/// 14  Stability Project 1.10.1.2 7/1/2011 4:38:21 PM Hemant(HAIL) 
/// Stability Project: Files has been checked in before the merging
///  task. The merging will be done between IL version of firmware and JF
///  version of firmware. 
/// 13  Stability Project 1.10.1.1 3/17/2011 3:20:25 PM  Hemant(HAIL) 
/// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
///  new operator in DEBUG mode only. To detect memory leaks in files, use
///  it in preprocessor definition when in debug mode.
/// 12  Stability Project 1.10.1.0 2/15/2011 3:03:10 PM  Hemant(HAIL) 
/// File updated during Heap Management. Call to the default behaviour
///  of new operator has been commented.
/// $
///

#include "InternalMessageQueue.h"
#include "ModuleConstants.h"

#ifndef TTR6SETUP
extern HWND Glb_hWnd; // from OpPanel
#endif
QMutex CInternalMessageQueue::m_csMessageQueueCriticalSection;
//****************************************************************************
/// CInternalMessageQueue Constructor
///
//****************************************************************************
CInternalMessageQueue::CInternalMessageQueue() {
	//Initialise Critical Section for Queue Operation
	//

	m_FrontOfQueue = IMQ_DEFAULT_ZERO_VALUE;
	m_RearOfQueue = IMQ_MAX_MESSAGE_ITEMS - 1; // 0 to max - 1
	m_UserMaxNumOfMessageItems = IMQ_MAX_MESSAGE_ITEMS;
	m_NumOfItemsInQueueToProcess = IMQ_DEFAULT_ZERO_VALUE;

	for (USHORT itemIndex = IMQ_DEFAULT_ZERO_VALUE; itemIndex < IMQ_MAX_MESSAGE_ITEMS; itemIndex++) {
		m_MsgItem[itemIndex] = NULL;
	}

	m_hNewMessageEvent = NULL;
	m_NotificationMethod = IMQ_USE_MANUAL;
	m_DestinationThreadId = IMQ_DEFAULT_ZERO_VALUE;

} // End of Constructor

//****************************************************************************
/// CInternalMessageQueue Destructor 
///
//****************************************************************************
CInternalMessageQueue::~CInternalMessageQueue() {
	// Delete the Critical Section created for the Message Queue
	//
	//deletion of mutex not required

} // End of Destructor

//****************************************************************************
/// Initalise the Internal Message Queue to the user requirements, allowing
/// flexibility on the maximum number of messages allowed and the size of
/// heap memory to allocate for the Message Queue. A limit of 50 messages in
/// the queue at one time is specified, if the user enters a value greater than
/// 50, it will be reduced to 50. User can enter any number between 1 and 50. 
///
///
/// @param[in] numOfMessageItems	- Maximum number of message is the queue at one time
/// @param[in]	heapSize			- Size in Bytes of the Heap Memeory for the Queue
/// @param[in] threadIdToNotify	- Thread Id of the thread that will be reading from the queue
/// @param[in] notificationMethod	- Method the reader thread will be notified of new messages
///
/// @return IMQ_INITIALISED, IMQ_INITIALISATION_FAILED
///
/// @note Must be called before the Message Queue can be used,
///		 MAXIMUM Number of Messages allowed in the Queue is 50.
///
//****************************************************************************
T_IMQ_RETURN_VALUE CInternalMessageQueue::InitInternalMessageQueue(USHORT numOfMessageItems, USHORT heapSize,
		DWORD threadIdToNotify, T_IMQ_NEW_MESSAGE_NOTIFICATION notificationMethod) {
	T_IMQ_RETURN_VALUE retValue = IMQ_INITIALISED;
	m_NotificationMethod = notificationMethod;
	m_DestinationThreadId = threadIdToNotify;

	// Bounds check the numOfMessageItems for valid values
	//
	if (numOfMessageItems < IMQ_DEFAULT_ZERO_VALUE) {
		m_UserMaxNumOfMessageItems = IMQ_MIN_MESSAGE_ITEMS;
	} else if (numOfMessageItems > IMQ_MAX_MESSAGE_ITEMS) {
		m_UserMaxNumOfMessageItems = IMQ_MAX_MESSAGE_ITEMS;
	} else {
		m_UserMaxNumOfMessageItems = numOfMessageItems;
	}

	// Set Rear of queue to user settings
	//
	m_RearOfQueue = m_UserMaxNumOfMessageItems - 1; // 0 to max - 1

	if (IMQ_USE_EVENT == m_NotificationMethod) {
		m_hNewMessageEvent = CreateEvent(NULL, TRUE, FALSE, NULL);

	} // End of If 

	if (HEAPBIPBUFFER_HEAP_ALLOCATED != AllocatedHeapBipBuffer(heapSize)) {
		retValue = IMQ_INITIALISATION_FAILED;
	}

	return (retValue);

} // End of InitInternalMessageQueue()

//****************************************************************************
/// Posts an Internal Message to the associated Message Queue. Thread-safe
/// if used within the same process, not thread-safe across processes. 
///
/// @param[in] messageType	- Type of Message to be posted
/// @param[in]	dataLength	- Size of the data in Bytes
/// @param[in] pData		- The Actual Data to be posted.
///
/// @return IMQ_MESSAGE_POSTED, IMQ_BIP_BUFFER_FULL and IMQ_FULL
///
/// @note Uses a Critical Section to ensure items are not being remove, while
///		 a new message is being posted. 
//****************************************************************************
T_IMQ_RETURN_VALUE CInternalMessageQueue::PostInternalMessage(T_IMQ_MESSAGE_TYPE messageType, USHORT dataLength,
		BYTE *pData) {

	T_IMQ_RETURN_VALUE retValue = IMQ_ERROR;
	CInternalMessage *pMessage = NULL;
	BYTE *pCommitedMemory = NULL;

	// Message Structure contains first byte of the data, therefore this byte must be
	// removed from the data length to obtain the correct message size in bytes. 
	//
	USHORT messageLength = (USHORT) (sizeof(CInternalMessage) + (dataLength - 1));
	USHORT allocatedMessageLength = 0;

	// Obtain Access to the Message Queue
	//

	m_csMessageQueueCriticalSection.lock();

	retValue = InternalMessageQueueStatus();

	if (retValue != IMQ_FULL) {
		// Commit Heap Memory for the New Message
		//
		pCommitedMemory = CommitMemory(messageLength, allocatedMessageLength);

		if (pCommitedMemory != NULL) {
			m_NumOfItemsInQueueToProcess++;

			// Write Header
			//
			pMessage = (CInternalMessage*) pCommitedMemory;
			pMessage->m_MessageType = messageType;
			pMessage->m_MsgLength = allocatedMessageLength;
			pMessage->m_DataLength = dataLength;

			// Copy the data passed in, to the heap memory committed
			//
			memcpy(pMessage->m_MsgData, pData, pMessage->m_DataLength);

			// Move the Rear of the Queue on by one 
			//
			if ((m_RearOfQueue + 1) == m_UserMaxNumOfMessageItems) {
				m_RearOfQueue = IMQ_DEFAULT_ZERO_VALUE;
			} else {
				m_RearOfQueue++;
			}

			// Assign the Created Item to a item within the queue
			//
			m_MsgItem[m_RearOfQueue] = pMessage;

			SignalNewMessageAvailable();

			// Update Queue Statistics
			UpdateIMQueueStats();

			retValue = IMQ_MESSAGE_POSTED;
		} else {
			retValue = IMQ_BIP_BUFFER_FULL;

		} // End of If

	} // End of If

	m_csMessageQueueCriticalSection.lock();

	return (retValue);

} // End of PostInternalMessage()

//****************************************************************************
/// Reads an Internal Message from the front of the Message Queue, user is passed
/// a constant pointer to the message for efficiency and speed of operation.
/// Reading a message from the Message Queue, will not cause the message to
/// be released. The user must use RemoveInteralMessage to actually remove
/// the read item from the Message Queue. 
///
/// @param - None
///
/// @return NULL - if Message Queue is empty or CInternalMessage a message is available
///
/// @note Message is not removed from the Message Queue on a read operation
///
//****************************************************************************
const CInternalMessage* CInternalMessageQueue::ReadInternalMessage(void) {
	CInternalMessage *pRetValue = NULL;

	if (IMQ_EMPTY != InternalMessageQueueStatus()) {
		pRetValue = m_MsgItem[m_FrontOfQueue];
	}
	return (pRetValue);

} // End of ReadInternalMessage()

//****************************************************************************
/// Allows a Message Queue user to determine how many messages are within the 
/// Message Queue waiting to be processed. This operation is thread-safe if 
/// used within the same process. 
///
/// @param - None
///
/// @return Number of Messages within the Queue. 0 to Max Number of Items Allowed
///
//****************************************************************************
USHORT CInternalMessageQueue::GetNumberOfMessagesInQueue(void) {
	USHORT retValue = IMQ_DEFAULT_ZERO_VALUE;

	m_csMessageQueueCriticalSection.lock();

	// Obtain the current number of messages within the Queue itself
	//
	retValue = m_NumOfItemsInQueueToProcess;

	m_csMessageQueueCriticalSection.lock();

	return (retValue);

} // End of GetNumberOfMessagesInQueue()

//****************************************************************************
/// Returns the event handler for the message queue which informs reader threads
/// on new messages to read. The event is set if the user has initialised the 
/// message queue for event notification, whenever messages are added to a queue.
/// Users should use the handler in the WaitForSingleObject and WaitForMultipleObjects
/// to allow the reader thread to wait efficiently. 
///
/// @param - None
///
/// @return New Message Available Event Handler
///
/// @note Private Operation
//****************************************************************************
HANDLE CInternalMessageQueue::GetEventHandler(void) {
	return (m_hNewMessageEvent);

} // End of GetEventHandler()

//****************************************************************************
/// This method will signal the reader in the method that the user has specified
/// when initilising the Message Queue, whenever a message is added to the 
/// Message Queue. 
///
/// @param - None
///
/// @return New Message Available Event Handler
///
/// @note Private Operation
//****************************************************************************
T_IMQ_RETURN_VALUE CInternalMessageQueue::SignalNewMessageAvailable(void) {
	switch (m_NotificationMethod) {
	case IMQ_USE_MANUAL:
		break; // Do Nothing

	case IMQ_USE_EVENT:

		SetEvent(m_hNewMessageEvent);
		break;
	case IMQ_USE_POST_THREAD_MESSAGE:
#ifndef TTR6SETUP
		PostMessage(Glb_hWnd, WM_INTERNAL_MESSAGE_AVIALABLE, NULL, NULL);
#endif
		break;

	default:
		break; // Error has occurred

	} // End of Switch

	return (IMQ_MESSAGE_SIGNALLED);

} // End of SignalNewMessageAvailable()

//****************************************************************************
/// Checks and returns the current status of the Message Queue, in terms of
/// whether the queue is FULL, EMPTY or SPACE AVAILABLE. 
///
/// @param - None
///
/// @return IMQ_SPACE_AVAILABLE, IMQ_FULL and IMQ_EMPTY
///
/// @note Private Operation
//****************************************************************************
T_IMQ_RETURN_VALUE CInternalMessageQueue::InternalMessageQueueStatus(void) {
	USHORT numOfMsgItemAvailable = (USHORT) (m_UserMaxNumOfMessageItems - m_NumOfItemsInQueueToProcess);
	T_IMQ_RETURN_VALUE retValue = IMQ_SPACE_AVAILABLE;

	if (IMQ_DEFAULT_ZERO_VALUE == numOfMsgItemAvailable) {
		retValue = IMQ_FULL;
	} else if (m_UserMaxNumOfMessageItems == numOfMsgItemAvailable) {
		retValue = IMQ_EMPTY;
	}

	return (retValue);

} // End of InternalMessageQueueStatus()

//****************************************************************************
/// Removes the First Item in the Queue, this operation is thread-safe within
/// the same process. If there are no items in the Message Queue, this shall
/// be reported to the user. 
///
/// @param - None
///
/// @return IMQ_EMPTY or IMQ_MESSAGE_REMOVED
///
/// @note Function should be called, once a read operation has been undertaken.
//****************************************************************************
T_IMQ_RETURN_VALUE CInternalMessageQueue::RemoveInternalMessage(void) {
	T_IMQ_RETURN_VALUE retValue = IMQ_ERROR;

	// Important to block until the Item is removed
	//
	m_csMessageQueueCriticalSection.lock();

	retValue = InternalMessageQueueStatus();

	// Safety Check to ensure there is at least one item to remove
	//
	if (IMQ_EMPTY != retValue) {
		ReleaseCommittedMemory(m_MsgItem[m_FrontOfQueue]->m_MsgLength);

		// Reset the current item to NULL for safe operation
		//
		m_MsgItem[m_FrontOfQueue] = NULL;

		// Decrement the Number of messages to process
		//
		m_NumOfItemsInQueueToProcess--;

		// Update the Queue
		//
		if ((m_FrontOfQueue + 1) == m_UserMaxNumOfMessageItems) {
			m_FrontOfQueue = IMQ_DEFAULT_ZERO_VALUE;
		} else {
			m_FrontOfQueue++;
		}

		// Check to determine if the new message notification needs to be invoked
		// to allow the module to receive the next message in the queue.
		//
		if (IMQ_EMPTY == InternalMessageQueueStatus()) {
			if (IMQ_USE_EVENT == m_NotificationMethod) {
				// Reset the Event, to allow the thread waiting on the message
				// queue to wait for a new message to be added to the queue. 
				//
				ResetEvent(m_hNewMessageEvent);
			}
		}

		retValue = IMQ_MESSAGE_REMOVED;

	} // End of If

	m_csMessageQueueCriticalSection.lock();

	return (retValue);

} // End of RemoveInternalMessage()

//****************************************************************************
/// Returns the Current Queue Statistic to the User
///
/// @param - None
///
/// @return Current Queue Statistic
///
/// @note Thread-Safe within the same process
//****************************************************************************
CInternalMessageQueueStats CInternalMessageQueue::GetMessageQueueStats(void) {
	CInternalMessageQueueStats QueueStats;

	m_csMessageQueueCriticalSection.lock();

	QueueStats = m_QueueStats;

	m_csMessageQueueCriticalSection.lock();

	return (QueueStats);

} // End of GetMessageQueueStats()

//****************************************************************************
/// Update the Queue Statistic as required
///
/// @param - None
///
/// @return IMQ_QUEUE_STATS_UPDATED
///
/// @note Private Member
///  This function must be called inside a Critical Section block
//****************************************************************************
T_IMQ_RETURN_VALUE CInternalMessageQueue::UpdateIMQueueStats(void) {
	if (m_NumOfItemsInQueueToProcess > m_QueueStats.m_IMQueueLoad) {
		m_QueueStats.m_IMQueueLoad = m_NumOfItemsInQueueToProcess;
	}

	m_QueueStats.m_IMQTotalNumberOfMessagesProcessed++;

	return (IMQ_QUEUE_STATS_UPDATED);

} // End of UpdateIMQueueStats()

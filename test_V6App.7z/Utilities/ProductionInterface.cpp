/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Utilties
/// @n Filename: CProductionInterface.cpp
/// @n Desc:	Implementation of CProductionInterface
///
// ****************************************************************
// Revision History
//	1-Feb-2021 New port(2152) is assigned to Pu tool.
// ****************************************************************

#include "ProductionInterface.h"

//****************************************************************************
/// CProductionInterface - Constructor
///
/// @param n/a
///
/// @return		n/a
///
//****************************************************************************
CProductionInterface::CProductionInterface() {

} //end CProductionInterface()

//****************************************************************************
/// ~CProductionInterface - Destructor
///
/// @param n/a
///
/// @return		n/a
///
//****************************************************************************
CProductionInterface::~CProductionInterface() {

} //end ~CProductionInterface() 

//****************************************************************************
/// ProductionInterfaceFunc - Starts the thread for accepting connections
///
/// @param n/a
///
/// @return		true if successful
///
//****************************************************************************
bool CProductionInterface::ProductionInterfaceFunc() {
	CEProductionSocket *newsocket;
	newsocket = new CEProductionSocket();
	if (newsocket->Create() == false) {
		printf("Error");
		return false;
	}
	if (newsocket->Accept(2152, 1) == false) {

		return false;
	}
	return true;

} //end ProductionInterfaceFunc()

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	Utilities
/// @n Filename:	StringUtils.cpp
/// @n Description: Implementation of general utility class providing string functions
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 46	Stability Project 1.41.1.3	7/2/2011 5:01:57 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 45	Stability Project 1.41.1.2	7/1/2011 4:38:59 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 44	Stability Project 1.41.1.1	3/17/2011 3:20:48 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 43	Stability Project 1.41.1.0	2/15/2011 3:04:00 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
// **************************************************************************

#include "StringUtils.h"
#include "V6defines.h"
#include "V6Config.h"

#include <math.h>
#include "V6globals.h"
#include "EUDCDefs.h"

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif

/// Static Initialisation
const QString   CStringUtils::ms_strDELIMITTER = L"|";
const QString   CStringUtils::ms_strREPORTS_FILE_EXT = L"*.rtf";

//****************************************************************************
// CStringUtils( )
///
/// Constructor
///
//****************************************************************************
CStringUtils::CStringUtils(void) {
}
//****************************************************************************
// ~CStringUtils( )
///
/// Destructor
///
//****************************************************************************
CStringUtils::~CStringUtils(void) {
}
//****************************************************************************
// ULONG IPv4StrToPackedIPv4( const QString  &rstrIPAddress )
///
/// Converts string ip address to a ULONG
///
/// @param[in]		const QString  &rstrIPAddress - THe IP address to convert
///
/// @return			The converted IP address as a ULONG - 0 if a problem
///
//**************************************************************************** 
const ULONG CStringUtils::IPv4StrToPackedIPv4(const QString   &rstrIPAddress) {
	//	ip routine
	//	convert stored string ip address from n1.n2.n3.n4 to
	//	stored DWORD n4.n3.n2.n1

	//	test for validity
	const int iMAX_CHARS = 24;
	char caIPAddr[iMAX_CHARS];
	memset(caIPAddr, 0, iMAX_CHARS);

#if _MSC_VER < 1400 

	wcstombs(caIPAddr, rstrIPAddress, iMAX_CHARS);
#else
	size_t pNoOfChars;
	wcstombs_s( &pNoOfChars, caIPAddr, iMAX_CHARS, rstrIPAddress, iMAX_CHARS );
#endif

	ULONG ulIPAddr = inet_addr(caIPAddr);
	return ulIPAddr;
}
//****************************************************************************
// const ULONG PackedIPv4ULongToStr( const QString  &rstrIPAddress )
///
/// Converts ULONG ip address to a string
///
/// @param[in]		const ULONG ulIPADDR - The IP Address as a ULONG
///
/// @return			The converted IP address as a string
///
//**************************************************************************** 
const QString   CStringUtils::PackedIPv4ULongToStr(const ULONG ulIPADDR) {
	QString   strIPAddr("");
	T_IPADDRESS tIPAddr;
	tIPAddr.L = ulIPADDR;
	strIPAddr.asprintf(L"%u.%u.%u.%u", tIPAddr.B[0], tIPAddr.B[1], tIPAddr.B[2], tIPAddr.B[3]);
	return strIPAddr;
}

//****************************************************************************
/// Converts a span in seconds to HH:MM:SS span in format nnH:nnM:nnS
///
/// @param[in]		number of seconds as a long long
///
/// @return			The string in the format nnh:nnm:nns
///
//**************************************************************************** 
const QString   CStringUtils::GetHHMMSSspanFromSeconds(LONGLONG timeInSeconds) {
	ULONG Seconds = static_cast<ULONG>(timeInSeconds % SECONDS_IN_A_MINUTE);
	timeInSeconds -= Seconds;
	ULONG MinutesInSeconds = static_cast<ULONG>(timeInSeconds % SECONDS_IN_AN_HOUR);
	timeInSeconds -= MinutesInSeconds;

	QString   strHHMMSS("");
	strHHMMSS.asprintf(L"%dh:%02dm:%02ds", static_cast<ULONG>(timeInSeconds / SECONDS_IN_AN_HOUR),
			MinutesInSeconds / SECONDS_IN_A_MINUTE, Seconds);
	return strHHMMSS;
}

//****************************************************************************
/// Converts a span in seconds to an autoformatted value showing the highest relevant
/// value in nnd:nnh:nnm:nns, if there are no full days then will return nnh:nnm:nns
/// and if there are no full hours then will return nnm:nns
///
/// @param[in]		number of seconds as a long long
///	@param[in]		const bool bTRIM_ZERO_FIELDS - Indicates that any leasding or trailing times that
///					are zero should be trimmed out e.g. 0h:23m:00s would become 23m
///
/// @return			The string in the format nnd:nnh:nnm:nns	(inc days)
///											nnh:nnm:nns		(days = 0)
///											nnm:nns			(days and hours = 0)
///
//**************************************************************************** 
const QString   CStringUtils::GetAutoDDHHMMSSspanFromSeconds(LONGLONG timeInSeconds,
		const bool bTRIM_ZERO_FIELDS /* = false */) {

	ULONG Seconds = static_cast<ULONG>(timeInSeconds % SECONDS_IN_A_MINUTE);
	timeInSeconds -= Seconds;
	ULONG MinutesInSeconds = static_cast<ULONG>(timeInSeconds % SECONDS_IN_AN_HOUR);
	timeInSeconds -= MinutesInSeconds;

	ULONG DaysInSeconds = 0;
	ULONG HoursInSeconds = 0;
	if (timeInSeconds >= SECONDS_IN_A_DAY) {
		// At least 1 day span
		HoursInSeconds = static_cast<ULONG>(timeInSeconds % SECONDS_IN_A_DAY);
		timeInSeconds -= HoursInSeconds;
		DaysInSeconds = static_cast<ULONG>(timeInSeconds);
	} else {
		// less then a day
		HoursInSeconds = +static_cast<ULONG>(timeInSeconds);
	}

	// asprintf string depending on actual time span.
	QString   strDDHHMMSS("");

	const bool bINCLUDE_DAYS = (DaysInSeconds > 0);
	bool bIncludeHours = (HoursInSeconds > 0);
	bool bIncludeMinutes = (MinutesInSeconds > 0);
	const bool bINCLUDE_SECONDS = (Seconds > 0);

	if (bTRIM_ZERO_FIELDS) {
		QString   strasprintf("");
		QString   strAddString("");
		// check if days present
		if (bINCLUDE_DAYS) {
			strDDHHMMSS.asprintf(L"%dd", DaysInSeconds / SECONDS_IN_A_DAY);
		}
		// check if hours present or days present and minutes present
		if (bIncludeHours || (bINCLUDE_DAYS && bIncludeMinutes)) {
			strasprintf = bINCLUDE_DAYS ? L":%02dh" : L"%dh";
			strAddString.asprintf(strasprintf, (HoursInSeconds / SECONDS_IN_AN_HOUR));
			strDDHHMMSS += strAddString;
			bIncludeHours = true;
		}
		// check if minutes present or hours present and seconds
		if (bIncludeMinutes || (bIncludeHours && bINCLUDE_SECONDS)) {
			strasprintf = bIncludeHours ? L":%02dm" : L"%dm";
			strAddString.asprintf(strasprintf, (MinutesInSeconds / SECONDS_IN_A_MINUTE));
			strDDHHMMSS += strAddString;
			bIncludeMinutes = true;
		}
		if (bINCLUDE_SECONDS) {
			strasprintf = bIncludeMinutes ? L":%02ds" : L"%ds";
			strAddString.asprintf(strasprintf, Seconds);
			strDDHHMMSS += strAddString;
		}
	} else {
		if (bINCLUDE_DAYS) {
			// There are days, so fully formatted
			strDDHHMMSS.asprintf(L"%dd:%dh:%02dm:%02ds", DaysInSeconds / SECONDS_IN_A_DAY,
					HoursInSeconds / SECONDS_IN_AN_HOUR, MinutesInSeconds / SECONDS_IN_A_MINUTE, Seconds);

		} else if (bIncludeHours) {
			// No days but hours
			strDDHHMMSS.asprintf(L"%dh:%02dm:%02ds", HoursInSeconds / SECONDS_IN_AN_HOUR,
					MinutesInSeconds / SECONDS_IN_A_MINUTE, Seconds);

		} else {
			// No hours so just minutes and seconds 
			strDDHHMMSS.asprintf(L"%dm:%02ds", MinutesInSeconds / SECONDS_IN_A_MINUTE, Seconds);
		}
	}

	return strDDHHMMSS;
}
//****************************************************************************
/// Returns a formatted date/time string
///
/// @param[in]		const ULONG timeSinceEpochInSeconds - number of seconds since epoch
/// @param[in]		const bool timeFirst - indicates if the time should be displayed first
///
/// @return			The date/time as a string 
///
//**************************************************************************** 
const QString   CStringUtils::GetDateTime(const ULONG timeSinceEpochInSeconds, const bool timeFirst) {
	QString   strDateTime;

	ULONGLONG ullDateTime = timeSinceEpochInSeconds;
	ullDateTime *= 1000000;
	CTVtime kTime(ullDateTime);
	kTime.ShortTimeAsString(strDateTime);
	// now add the date
	QString   strDate("");
	kTime.DateAsString(strDate);

	if (timeFirst) {
		strDateTime += L" " + strDate;
	} else {
		strDateTime = strDate + L" " + strDateTime;
	}

	return strDateTime;
}

//****************************************************************************
/// Returns a formatted date string
///
/// @param[in]		number of seconds since epoch
///
/// @return			The date as a string 
///
//**************************************************************************** 
const QString   CStringUtils::GetDate(ULONG timeSinceEpochInSeconds) {
	QString   date;

	ULONGLONG ullDateTime = timeSinceEpochInSeconds;
	ullDateTime *= 1000000;
	CTVtime kTime(ullDateTime);
	kTime.DateAsString(date);

	return date;
}

//****************************************************************************
//	const QString  GetItemAtPos(	const QString  &rstrITEM,
//								const USHORT usITEM_POS ) const
///
/// Method that gets the item at a particlar position within a item list delimited by a '|'
///
/// @param[in] 		const QString  &rstrITEM - The item list to look within
/// @param[in] 		const USHORT usITEM_POS - The item item we want, zero based
///
/// @return			Returns the item at a particular position or an empty string if the item pos is
///					higher than the number of items within the list
///
//****************************************************************************
const QString   CStringUtils::GetItemAtPos(const QString   &rstrITEM_LIST, const USHORT usITEM_POS,
		const QString   &rstrDELIMITTER /* = L"|" */) {
	QString   strIndividualItem("");
	int iDelimPos = 0;
	USHORT usCurrItemPos = 0;
	// loop through the item list until we get to the item we want
	while ((usITEM_POS != usCurrItemPos) && (iDelimPos >= 0)) {
		iDelimPos = rstrITEM_LIST.indexOf(rstrDELIMITTER, iDelimPos + 1);
		++usCurrItemPos;
	}
	// check the delimiter was found and it is not in position 0
	if (iDelimPos >= 0) {
		int iPrevDelimPos = iDelimPos;
		iDelimPos = rstrITEM_LIST.indexOf(rstrDELIMITTER, iPrevDelimPos + 1);
		if (iDelimPos == -1) {
			iDelimPos = rstrITEM_LIST.size();
		}
		if (iPrevDelimPos != 0) {
			iPrevDelimPos += rstrDELIMITTER.size();
		}
		strIndividualItem = rstrITEM_LIST.mid(iPrevDelimPos, iDelimPos - iPrevDelimPos);

	}
	return strIndividualItem;
}
//****************************************************************************
///
/// Method that gets the item at a particlar non-sequential position within a item list delimited by a '|'
///
/// @param[in] 		const QString  &rstrITEM - The item list to look within
/// @param[in] 		const USHORT usITEM_POS - The item item we want, zero based
///
/// @return			Returns the item at a particular non-sequential position or an empty string if the item pos is
///					higher than the number of items within the list - it also strips out any embedded information
///
//****************************************************************************
const QString   CStringUtils::GetItemAtNonSequentialPos(const QString   &rstrITEM_LIST, const USHORT usITEM_POS,
		const QString   &rstrDELIMITTER /* = L"|" */) {
	QString   strIndividualItem("");

	// check if this is a non-sequential list by looking for embedded control characters
	QString   strNonSeqDelimiter("");
	strNonSeqDelimiter = g_wcEMBEDDED_INFO_DELIM;
	USHORT usCurrSearchItemNo = usITEM_POS;
	if (CStringUtils::InstanceOfStr(rstrITEM_LIST, strNonSeqDelimiter) >= 2) {
		// non-sequential list so we need to test all the strings in the list to see if
		// they contain the value indicated within the CMM data
		QString   strStringToindexOf("");
		QString   strStringToTest("");
		strStringToindexOf.asprintf(L"%c%u%c", g_wcEMBEDDED_INFO_DELIM, usCurrSearchItemNo, g_wcEMBEDDED_INFO_DELIM);
		usCurrSearchItemNo = 0;

		while ((strStringToTest = CStringUtils::GetItemAtPos(rstrITEM_LIST, usCurrSearchItemNo))
				!= "") {
			// see if this string occurs in the list
			if (strStringToTest.indexOf(strStringToindexOf, 0) != -1) {
				// found our match - drop out of the loop
				strIndividualItem = strStringToTest;
				break;
			}
			// move onto the next item
			++usCurrSearchItemNo;
		}
	} else {
		// no embedded characters so use the conventional method for getting the string item
		strIndividualItem = GetItemAtPos(rstrITEM_LIST, usITEM_POS, rstrDELIMITTER);
	}

	// strip out the control characters
	int iStartPos = 0;

	// check for an embedded control characters
	if ((iStartPos = strIndividualItem.indexOf(g_wcEMBEDDED_INFO_DELIM, 0)) != -1) {
		int iEndPos = strIndividualItem.indexOf(g_wcEMBEDDED_INFO_DELIM, iStartPos + 1);

		// check an end character was found
		if (iEndPos != -1) {
			// start and end found - strip the information out of the string
			strIndividualItem.Delete(iStartPos, (iEndPos - iStartPos) + 1);
		} else {
			// should never happen unless there has been a coding error or the user has somehow
			// embedded a control character into the string names
#ifdef _DEBUG
			DebugBreak();
#endif
		}
	}

	return strIndividualItem;
}
//****************************************************************************
//	const QString  asprintfFloat(	T_NUMFORMAT tNumberasprintf, 
//								const float fVALUE,
//								const float fRANGE /* = FLT_MAX */,
//								const bool bLOG_SCALE /* = false */,
//								const bool bAlarm_Email /*= false*/) const
///
/// Method that creates an appropriately formatted scale string
///
/// @param[in] 			T_NUMFORMAT tNumberasprintf - The number format structure
/// @param[in] 			const float fVALUE - The value to be converted to a string
/// @param[in]			const float fRANGE - The range the value is associated with
/// @param[in]			const bool bLOG_SCALE - Flag indicating if this item is part
///						of a logscale
/// @param[in]			const int iLimitDecimalsOnAuto - limits the decimals
/// 
/// @return				A string containing the formatted floating point value
///
//****************************************************************************
const QString   CStringUtils::asprintfFloat(T_NUMFORMAT tNumberasprintf, const float fVALUE,
		const float fRANGE /* = FLT_MAX */, const bool bLOG_SCALE /* = false */,
		const int iLimitDecimalsOnAuto /* = -1 */, const bool bAlarm_Email /*= false*/) {
	QString   strasprintftedValue("");
	QString   strasprintfString("");

	//MarkD: if set to FLT_MAX or -FLT_MAX, replace value with EUDC arrows
	if (fVALUE == FLT_MAX) {
		if (bAlarm_Email) {
            strasprintftedValue.asprintf("Outside Range High "));
		} else {
			strasprintftedValue.asprintf(L" %c%c%c%c", g_wcOVER_RANGE, g_wcOVER_RANGE, g_wcOVER_RANGE, g_wcOVER_RANGE);
		}
	} else if (fVALUE == -FLT_MAX) {
		if (bAlarm_Email) {
            strasprintftedValue.asprintf("Outside Range Low "));
		} else {
			strasprintftedValue.asprintf(L" %c%c%c%c", g_wcUNDER_RANGE, g_wcUNDER_RANGE, g_wcUNDER_RANGE,
					g_wcUNDER_RANGE);
		}
	} else {
		UINT uiErrorTest = *(reinterpret_cast<const UINT*>(&fVALUE)); // cast float to UINT.
		// Test the exponent to see if code is NAN
		if ((uiErrorTest & g_ulNAN_TEST_VALUE) == g_ulNAN_TEST_VALUE) {
			if (bAlarm_Email) {
                strasprintftedValue.asprintf("Invalid Reading "));
			} else {
				strasprintftedValue.asprintf(L" %c%c%c%c", g_wcINVALID, g_wcINVALID, g_wcINVALID, g_wcINVALID);
			}
		} else {
			float fConvertedValue = fVALUE;

			// if logscale, use 10^(value)
			if (bLOG_SCALE) {

				if (fVALUE < MAX_POWER_OF_10)	// trap for error 
						{
					fConvertedValue = pow((float) 10.0, fVALUE);
				} else {
					fConvertedValue = FLT_MAX;	// display max possible value
				}
			}

			if (tNumberasprintf.Auto) {
				//MarkD: if in scientific notation, Auto to 1 decimal place so the number can be read in DPMs
				if (tNumberasprintf.Scientific) {
					tNumberasprintf.Bd = 1;
					tNumberasprintf.Ad = 1;
				} else {
					// test for large value first, to set scientific if required, regardless of range setting
					const float fABS_VALUE = fabs(fConvertedValue);
					if (fABS_VALUE > 9999999.0) {
						tNumberasprintf.Scientific = TRUE;
						tNumberasprintf.Bd = 1;
						tNumberasprintf.Ad = 1;
					} else	// set decimal places to use
					{
						// base it on the scale details if they are provided
						if (fRANGE != FLT_MAX) {
							const float fABS_RANGE = fabs(fRANGE);
							if (fABS_RANGE < 1.0) {
								tNumberasprintf.Bd = 1;
								tNumberasprintf.Ad = 5;
							} else if (fABS_RANGE < 10.0) {
								tNumberasprintf.Bd = 1;
								tNumberasprintf.Ad = 4;
							} else if (fABS_RANGE < 100.0) {
								tNumberasprintf.Bd = 2;
								tNumberasprintf.Ad = 3;
							} else if (fABS_RANGE < 1000.0) {
								tNumberasprintf.Bd = 3;
								tNumberasprintf.Ad = 2;
							} else if (fABS_RANGE < 10000.0) {
								tNumberasprintf.Bd = 4;
								tNumberasprintf.Ad = 2;
							} else if (fABS_RANGE < 100000.0) {
								tNumberasprintf.Bd = 5;
								tNumberasprintf.Ad = 0;
							}
						} else {
							// just format to a reasonable length based on the size				
							if (fABS_VALUE < 1.0) {
								tNumberasprintf.Bd = 1;
								tNumberasprintf.Ad = 5;
							} else if (fABS_VALUE < 10.0) {
								tNumberasprintf.Bd = 1;
								tNumberasprintf.Ad = 4;
							} else if (fABS_VALUE < 100.0) {
								tNumberasprintf.Bd = 2;
								tNumberasprintf.Ad = 3;
							} else if (fABS_VALUE < 1000.0) {
								tNumberasprintf.Bd = 3;
								tNumberasprintf.Ad = 2;
							} else if (fABS_VALUE < 10000.0) {
								tNumberasprintf.Bd = 4;
								tNumberasprintf.Ad = 1;
							} else if (fABS_VALUE < 100000.0) {
								tNumberasprintf.Bd = 5;
								tNumberasprintf.Ad = 0;
							}
							//MarkD: ensure no decimal places on very large numbers also
							else if (fABS_VALUE >= 100000.0)	//Coverity- 2343027
									{
								tNumberasprintf.Ad = 0;
							}
						}
						if ((iLimitDecimalsOnAuto != -1) && (tNumberasprintf.Ad > iLimitDecimalsOnAuto)) {
							// override the maximum number of decimals
							tNumberasprintf.Ad = iLimitDecimalsOnAuto;
						}
					}
				}
			}

			if (tNumberasprintf.Base) // Hex?
			{
				strasprintfString = L"%%0x%X"; // treat the value as hex rather than float.
			} else {
				// only makes sense to set .Bd if you have .Zpad set to 1 since you will always get the
				// value displayed before the decimal point anyway (never truncated)

				if (tNumberasprintf.Zpad) {
					// for zero padding, we want to have at least Numberasprintf.Bd before the Decimal point
					// since the '.' counts as 1 char we need to add 1 to the minimum width specifier here.
					strasprintfString.asprintf(L"%%0%d.%df", 1 + tNumberasprintf.Bd + tNumberasprintf.Ad,
							tNumberasprintf.Ad);
				} else {
					if (tNumberasprintf.Scientific) {
						strasprintfString.asprintf(L"%%.%de", tNumberasprintf.Ad); // scientific notation here	(.bd always 1 anyway and no zpad)				
					} else {
						strasprintfString.asprintf(L"%%.%df", tNumberasprintf.Ad); // normal floating point
					}
				}
			}

			strasprintftedValue.asprintf(strasprintfString, fConvertedValue);

			// now remove any extra zero's after the decimal place (except the last one)
			if ((tNumberasprintf.Scientific == FALSE) && (tNumberasprintf.Auto == TRUE) && (tNumberasprintf.Ad > 1)) {
				int iDecimalPos = strasprintftedValue.indexOf(L".", 0);

				if (iDecimalPos != -1) {
					bool bContinue = true;
					while (bContinue) {
						// get the last character in the entire string and check it is a zero
						int iZeroPos = strasprintftedValue.indexOf(L"0", strasprintftedValue.size() - 1);

						if ((iZeroPos != -1) && (iZeroPos > (iDecimalPos + 1))) {
							strasprintftedValue.Delete(strasprintftedValue.size() - 1, 1);
						} else {
							// either not a zero or it is a zero adjacent to the decimal point so drop out of
							// the loop
							bContinue = false;
						}
					}
				}
			} else if (tNumberasprintf.Scientific) {
				strasprintftedValue.Delete((strasprintftedValue.size() - 3), 1);// MarkD: delete the third from last char
			}
		}
	}

	return strasprintftedValue;
}
//****************************************************************************
//	const bool LoadLangDLL( const T_LANGUAGES eLANG, QString  &rstrErrorMsg )
///
/// Method that loads the correct resource DLL based on the passed in language
///
/// @param[in] 			const T_LANGUAGES eLANG - The enum of the required language
/// @param[out] 		QString  &rstrErrorMsg - An error message if necessary
/// 
/// @return				True if there was no need to load a DLL or the DLL was loaded 
///						successfully
///
//****************************************************************************
const bool CStringUtils::LoadLangDLL(const T_LANGUAGES eLANG, QString   &rstrErrorMsg) {
	QString   strLanguageDLLName("");
	bool bSuccess = true;

	// get the language DLL name
	strLanguageDLLName = GetLangDLLName(eLANG);

	// check we need to load a DLL
	if (strLanguageDLLName != "") {
		HINSTANCE hRes = NULL;

		// add the CE firmware PATH if this an actual recorder
		const T_DEV_TYPE eDEV_TYPE = pDEVICE_INFO->GetDeviceType();
		if (eDEV_TYPE == DEV_ARISTOS_MINITREND || eDEV_TYPE == DEV_ARISTOS_MULTIPLUS || eDEV_TYPE == DEV_PC_TTR6SETUP
				|| eDEV_TYPE == DEV_SCR_MINITREND) {
			// add the firmware path
			int iPathLen = 260;
			QString  pwcStoragePathName = new WCHAR[iPathLen];
			QString  pwcFirmwarePathName = new WCHAR[iPathLen];

			pDALGLB->GetPath((T_STORAGE_PATH) IDS_INTERNAL_SD, pwcStoragePathName, iPathLen, &iPathLen);
			pDALGLB->GetPath(IDS_PRIMARY, pwcFirmwarePathName, iPathLen, &iPathLen);
			QString   strPath("");
			strPath.asprintf(L"%s%s", pwcStoragePathName, pwcFirmwarePathName);
			strLanguageDLLName = strPath + strLanguageDLLName;

			delete[] pwcFirmwarePathName;
			delete[] pwcStoragePathName;
		}

		//	hRes = LoadLibrary( strLanguageDLLName ); This Fails on CE 7 Use Following....
		hRes = LoadLibraryEx(strLanguageDLLName, NULL, LOAD_LIBRARY_AS_DATAFILE);
		if (hRes != NULL) {
			AfxSetResourceHandle(hRes);
		} else {
			// there has been an error - return an error message - no point in translating
			DWORD dw = GetLastError();
			dw++;
			rstrErrorMsg = L"Failed to load the selected lanaguage DLL";
			bSuccess = false;
		}
	}
	return bSuccess;
}
//****************************************************************************
//	const QString  GetLangDLLName( const T_LANGUAGES eLANG )
///
/// Method that gets the resource DLL name based on the passed in enum
///
/// @param[in] 			const T_LANGUAGES eLANG - The enum of the required language
/// 
/// @return				The name of the DLL or QString   ::fromWCharArray("") if none (e.g. English)
///
//****************************************************************************
const QString   CStringUtils::GetLangDLLName(const T_LANGUAGES eLANG) {


    return "";
}
//****************************************************************************
//	const USHORT InstanceOfStr( const QString  &rstrSTRING_TO_TEST, 
//								const QString  &rstrSTRING_TO_FIND );
///
/// Method that counts the instances of the passed in string within the test string
///
/// @param[in] 			const QString  &rstrSTRING_TO_TEST - The string to look in
/// @param[in] 			const QString  &rstrSTRING_TO_FIND - The string to llok for
/// 
/// @return				The number of occurances of the string we are looking for
///
//****************************************************************************
const USHORT CStringUtils::InstanceOfStr(const QString   &rstrSTRING_TO_TEST, const QString   &rstrSTRING_TO_FIND) {
	USHORT usOccurances = 0;
	short sStartPos = -1;
	while ((sStartPos = rstrSTRING_TO_TEST.indexOf(rstrSTRING_TO_FIND, sStartPos + 1)) != -1) {
		// increment the number of occurances
		++usOccurances;
	}
	return usOccurances;
}
//****************************************************************************
//	void SafeWcsCpy(	QString  pwcDest, 
//						const QString  pwcORIG, 
//						const USHORT usDEST_BUFF_LEN,
//						const bool bNULL_TERMINATE_BUFF_END /* = true */ )
///
/// Method that performs safe string copies - to replace calls to wcsncpy and wcscpy. This method
///	will copy the original over the destination upto the length specified by usDEST_BUFF_LEN. The
///	last character in the buffer will be set to NULL if the final flag is set (this is to overcome 
///	problems with wcsncpy)
///
/// @param[in] 			const QString  &rstrSTRING_TO_TEST - The string to look in
/// @param[in] 			const QString  &rstrSTRING_TO_FIND - The string to llok for
/// @param[in] 			const USHORT usDEST_BUFF_LEN - The length of the destination buffer including any
///						space for the null terminator
/// @param[in]			const bool bNULL_TERMINATE_BUFF_END - Flag indicating if the string must be
///						null terminated
///
//****************************************************************************
void CStringUtils::SafeWcsCpy(QString  pwcDest, const QString  pwcORIG, const USHORT usDEST_BUFF_LEN,
		const bool bNULL_TERMINATE_BUFF_END /* = true */) {
	// copy the strings
#if _MSC_VER < 1400 
	wcsncpy(pwcDest, pwcORIG, usDEST_BUFF_LEN);
#else
	int len = wcslen(pwcORIG);
	wcsncpy_s( pwcDest, usDEST_BUFF_LEN,pwcORIG, len<usDEST_BUFF_LEN?len:usDEST_BUFF_LEN-1 );
#endif

	// always set the last char to NULL
	if (bNULL_TERMINATE_BUFF_END) {
		pwcDest[usDEST_BUFF_LEN - 1] = 0;
	}
}
//****************************************************************************
//	const QString  StripColourInfo( const QString  &rstrUNICODE_SOURCE )
///
// Strip out any colour information that may be present
///
/// @param[in] 			const QString  &rstrTEXT_SOURCE - The original source string
/// 
/// @return				The string with all the colour information removed
///
//****************************************************************************
const QString   CStringUtils::StripColourInfo(const QString   &rstrTEXT_SOURCE) {
	int iModColourPos = 0;
	QString   strNewValue(rstrTEXT_SOURCE);
	if ((iModColourPos = strNewValue.indexOf(g_wcMOD_COLOUR)) != -1) {
		// there are some special characters which we must extract first
		int iModColourEndPos = strNewValue.indexOf(g_wcMOD_COLOUR, iModColourPos + 1);
		int iColourLen = (iModColourEndPos - iModColourPos);

		// delete the colour information and character from the string
		strNewValue.Delete(iModColourPos, iColourLen + 1);
	}

	return strNewValue;
}

//****************************************************************************
//	const QString  EncodeToUTF8( const QString  &rstrUNICODE_SOURCE )
///
/// Method used to convert unicode text into a UTF-8 representation (note: this will still need to
/// be converted using wcstombs
///
/// @param[in] 			const QString  &rstrUNICODE_SOURCE - The original unicode source string
/// 
/// @return				The string with all unicode characters converted to ascii/UTF-8 equivalents (note: this
///						string is still returned as WCHAR's although they will all be ascii values - call wcstombs
///						if you want ot convert this string in a normal character array)
///
//****************************************************************************
const QString   CStringUtils::EncodeToUTF8(const QString   &rstrUNICODE_SOURCE) {
	WORD ch;

	BYTE bt1, bt2, bt3, bt4, bt5, bt6;

	int n = 0;
	int nMax = rstrUNICODE_SOURCE.size();

	QString   sFinal, sTemp;

	for (n = 0; n < nMax; ++n) {
		ch = (WORD) rstrUNICODE_SOURCE.at(n);

    if (ch == '='))
	{
        sTemp.asprintf("=%02X"), ch);

		sFinal += sTemp;
	}
	else if (ch < 128)
	{
		sFinal += rstrUNICODE_SOURCE.at( n );
	}
	else if (ch <= 2047)
	{
		bt1 = (BYTE)(192 + (ch / 64));
		bt2 = (BYTE)(128 + (ch % 64));

        sTemp.asprintf("=%02X=%02X"), bt1, bt2);

		sFinal += sTemp;
	}
	else if (ch <= 65535)
	{
		bt1 = (BYTE)(224 + (ch / 4096));
		bt2 = (BYTE)(128 + ((ch / 64) % 64));
		bt3 = (BYTE)(128 + (ch % 64));

        sTemp.asprintf("=%02X=%02X=%02X"), bt1, bt2, bt3);

		sFinal += sTemp;
	}
	else if (ch <= 2097151)
	{
		bt1 = (BYTE)(240 + (ch / 262144));
		bt2 = (BYTE)(128 + ((ch / 4096) % 64));
		bt3 = (BYTE)(128 + ((ch / 64) % 64));
		bt4 = (BYTE)(128 + (ch % 64));

        sTemp.asprintf("=%02X=%02X=%02X=%02X"), bt1, bt2, bt3, bt4);
		sFinal += sTemp;
	}
	else if (ch <=67108863)
	{
		bt1 = (BYTE)(248 + (ch / 16777216));
		bt2 = (BYTE)(128 + ((ch / 262144) % 64));
		bt3 = (BYTE)(128 + ((ch / 4096) % 64));
		bt4 = (BYTE)(128 + ((ch / 64) % 64));
		bt5 = (BYTE)(128 + (ch % 64));

        sTemp.asprintf("=%02X=%02X=%02X=%02X=%02X"), bt1, bt2, bt3, bt4, bt5);
		sFinal += sTemp;
	}
	else if (ch <=2147483647)
	{
		bt1 = (BYTE)(252 + (ch / 1073741824));
		bt2 = (BYTE)(128 + ((ch / 16777216) % 64));
		bt3 = (BYTE)(128 + ((ch / 262144) % 64));
		bt4 = (BYTE)(128 + ((ch / 4096) % 64));
		bt5 = (BYTE)(128 + ((ch / 64) % 64));
		bt6 = (BYTE)(128 + (ch % 64));

        sTemp.asprintf("=%02X=%02X=%02X=%02X=%02X=%02X"),
				bt1, bt2, bt3, bt4, b

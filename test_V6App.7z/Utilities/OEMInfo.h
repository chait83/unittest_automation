/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	OEM Creator
/// @n Filename:	OEMInfo.h
/// @n Description: Definition of the COEMInfo class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//
//
// 30-Apr-2014	Rajanbabu M			Updated for Shallow Case Recorder DRG2

// 34	Stability Project 1.31.1.1	7/2/2011 4:59:09 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 33	Stability Project 1.31.1.0	7/1/2011 4:27:23 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 32	V6 Firmware 1.31		9/25/2009 3:20:01 PM	Binsy Pillai 
//		event cursor merging of code
// 31	V6 Firmware 1.30		9/23/2008 3:09:29 PM	Build Machine 
//		AMS2750 Merge
// $

// **************************************************************************

#ifndef __OEMINFO_H__
#define __OEMINFO_H__

#include <memory>
#include <QString>
#include <QImage>
#include "SIPGlobal.h"
#include "Defines.h"

#ifndef _TEST_APP
//#include <Afxtempl.h> //LTTS
#endif

#define V6_TOTAL_RESOURCES		5		// Total no of resource types.
#define RES_TOTAL_TEXT		50		// Max No. of Text Subsections.
#define RES_TOTAL_COLOURS	100		// Max No. of Color Subsections.
#define RES_TOTAL_GRAPHICS	500		// Max No. of Graphics Subsections.
#define RES_TOTAL_PANELS	50		// Max No. of Panels Subsections.
#define RES_TOTAL_SPLASH	1		// Max No. of Splash Subsections.

#define RES_MAX_TEXT_LEN	100		// Max length for the text section.

#define RES_TEXT		0			// Index for the Resource - Text.
#define RES_COLOURS		1			// Index for the Resource - Colour.
#define RES_GRAPHICS	2			// Index for the Resource - Graphics.
#define RES_PANELS		3			// Index for the Resource - Panels.
#define RES_SPLASH		4			// Index for the Resource - Splash.

//Text defines
#define RES_TEXT_CONAME			0		// Index for the TextResource - Company Name Field.
#define RES_TEXT_PRODGRPNAME	1		// Index for the TextResource - Product Group Name Field.
#define RES_TEXT_MULTIPRODNAME	2		// Index for the TextResource - Multi Product Name Field.
#define RES_TEXT_MINIPRODNAME	3		// Index for the TextResource - Mini Product Name Field.
#define RES_TEXT_EZPRODNAME		4		// Index for the TextResource - Ez Product Name Field.
#define RES_TEXT_WEBADDR		5		// Index for the TextResource - Web Address Field.
#define RES_TEXT_EMAIL			6		// Index for the TextResource - E-mail Field.

#define PCK_FILE_COUNT		5	// Total PCK files generated in build for GR 

#pragma pack(push, r1, 2) // n=2, pushed to stack

/// Header for the resource block.
struct V6ResBlockHeader {
	int OEMID;						// OEM id
	UCHAR Version;					// Version Number of the OEM resources
	long Jump[V6_TOTAL_RESOURCES];	// Jump table for Resources
};

/// Text Resources header
struct ResTextHeader {
	short Num;						// Total No. of Text Subsections
	long Jump[RES_TOTAL_TEXT];	// Jump table for each Subsection
};

/// Text Resources info
struct ResTextInfo {
	int nId;								// Id for each Text-Section.
	WCHAR szTextValue[RES_MAX_TEXT_LEN];	// Text Value.
};

/// Colour Resources header
struct ResColourHeader {
	short Num;						// Total Number of colours.
	short Jump[RES_TOTAL_COLOURS];	// Jump Table for each colour Information.
};

// Style of resource definitions
struct ResColour {
	int nId;				// Id for each Colour.
	COLORREF pColor;		// ColourRef information for each color.
};

/// Graphics Resources header
struct ResGraphicHeader {
	short Num;					// No of Images.
	short Jump[RES_TOTAL_GRAPHICS];	// Offset from bitmap res start to ResBitmaps array.
};

/// Graphics Resources info
struct ResGraphicInfo {
	UCHAR BitmapType;		// Single colour, Full colour
	int nId;				// Id for which this graphics is assigned for
	long Width;				// Width in Pixels of bitmap
	long Height;			// Height in pixels of Bitmap
	long Offset;			// Offset from Bitmap data base

	// Sunil : Added to store the size for the Image File.
	long size;			// Size of the Image
};

/// Input Panel Resources header
struct ResPanelHeader {
	short Num;					// No of Resource Panels
	long Jump[RES_TOTAL_PANELS];	// Jump Table for each Resource Panel.
};

/// Input Panel Resources info
struct ResPanel {
	int nId;				// Id for which this panel is assigned for
	UCHAR Type;			// Type of the resouce panel.
	ResGraphicInfo graUp; // For the Graphics Image.

	long lSPMapOffset;	// Offset for the Size and Position Map File.
	long lKeyMapOffset;	// Offset for the Keys Map File. 

};

#pragma pack(pop, r1 ) // restore original , stack popped

typedef struct _BitmapStore {
	QImage hBitmap;
	BITMAPINFO *ptBitmapInfo;
} T_BITMAP_STORE;

#ifndef _TEST_APP

//string used for setting the pck filepath for XSeries and Aristos resource pck
const QString   cs_PCK_NAME = QString ::fromWCharArray(L"\\XSResource.pck");
const QString   cs_PCK_NAME_ARISTOS = QString ::fromWCharArray(L"\\ARResource.pck");
const QString   CS_PCK_FILES[PCK_FILE_COUNT] = { QString ::fromWCharArray(L"MultiTrend.pck"), QString ::fromWCharArray(
		L"MiniTrend.pck"), QString ::fromWCharArray(L"eZTrend.pck"), QString ::fromWCharArray(L"DRG2.pck"),
		QString ::fromWCharArray(L"DRG1.pck") };

typedef QMap<ULONG, T_BITMAP_STORE> CBitmapMap;
#endif

//**COEMInfo*********************************************************************
///
/// @brief Singleton class that reads in a OEM creator resource file
/// 
/// Singleton class that reads in a OEM creator resource file. This class is used in the V6 project and
/// the OEM Creator project.
///
//****************************************************************************
class COEMInfo {
public:
	// Singleton Accessor/Creator
	static COEMInfo* Instance();

	// Destructor
	~COEMInfo();

	// Reader Routines

	// Get the ResTextInfo structure for the specified index.
	ResTextInfo* GetText(int nIndex);

	// Get the ResColour structure for the specified index.
	ResColour* GetColour(int nIndex);

	// Get the ResGraphicInfo structure for the specified index.
	ResGraphicInfo* GetGraphicInfo(int nIndex);

	// Get the Bitmap for the specified index.
	UCHAR* GetGraphic(int nIndex);

	// Get the ResPanel structure for the specified index.
	ResPanel* GetPanelInfo(int nIndex);

	// Get the Panel Image for the specified index.
	UCHAR* GetPanelUpImage(int nIndex);

	// Get the Size and Position Map for the specified index.
	UCHAR* GetPanelSPMap(int nIndex);

	// Get the Key Map for the specified index
	UCHAR* GetPanelKeyMap(int nIndex);

	// Get the Key Map for the specified index for multi language
	UCHAR* GetPanelKeyMapMultiLang(int nIndex);

	// Get the OEMId from the Resource Pack.
	int GetOEMId();

	// Gets the horizontal scrollbar bitmap dimensions
	const bool GetHorizSBDimensions(USHORT &rusHeight, USHORT &rusWidth);

	// Gets the vertical scrollbar bitmap dimensions
	const bool GetVerticalSBDimensions(USHORT &rusHeight, USHORT &rusWidth);

	// Accessor Methods
	const TCHAR* GetResFileName() const {
		return m_szResFileName;
	}

	void SetResFileName(TCHAR *szResFileName, int iLength) {
		memcpy(m_szResFileName, szResFileName, iLength);
	}

#ifdef TTR6SETUP
	// Method that loads the specified resource file
	void LoadResourceFileEx( QString  pwcFileName );
#endif

#ifdef _TEST_APP
	// Method that loads the specified resource file
	void LoadResourceFile( QString  pwcFileName );
#else
	// Get a handle to the passed in bitmap ID
	QImage GetBitmapHandle(const ULONG ulRESOURCE_ID);

	// Method that frees the memory allocated to the passed in bitmap handle
	void FreeBitmapHandle(const ULONG ulRESOURCE_ID);

	// Prepare the handle for the bitmap.
	QImage LoadDIBBitmap(void *pBmpFile, DWORD BufferLength, BITMAPINFO **rptBitmapInfo);

	// Map storing the bitmap resources obtained using GetBitmapHandle
	CBitmapMap m_kBitmapMap;
#endif
private:
	// Static singleton auto pointer
	static std::auto_ptr<COEMInfo> ms_kOEMInfo;

	// Handle to the creation mutex
	static HANDLE ms_hCreationMutex;

	// Constructor
	COEMInfo();

	// Method that initializes the Resource Headers.
	BOOL GfxResourceInit();
	//Remove other PCK files
	void RemovePCKFiles(int PCKIndex);

#ifndef _TEST_APP
	// Update any registry information
	void UpdateRegistry();

	// Method that updates the current system colours
	void UpdateSystemColours();
#endif

	unsigned char *m_lpBuffer;	/// To allocate the memory for reading the Pack File.

	WCHAR m_szResFileName[MAX_PATH];	/// To Store the Pack File Name.

	struct V6ResBlockHeader *m_pResBlkHdr;	/// Point to master header for the Resource Block.

	struct ResTextHeader *m_pResTxtHdr;		/// Pointer to Text header.
	struct ResTextInfo *m_pResTextInfo[RES_TOTAL_TEXT]; /// Array of pointers to pResTextInfo.

	struct ResColourHeader *m_pResColorHdr;	/// Pointer to the Colour header.
	struct ResColour *m_pResColorInfo[RES_TOTAL_COLOURS];	/// Array of pointers to Colourinfo.

	struct ResGraphicHeader *m_pResGraphHdr;	/// Pointer to Graphic header.
	struct ResGraphicInfo *m_pResGraphInfo[RES_TOTAL_GRAPHICS]; /// Array of Pointers to GraphicInfo.
	UCHAR *m_pBitmapData[RES_TOTAL_GRAPHICS]; /// Array of pointers to bitmaps.

	struct ResGraphicHeader *m_pResSplashHdr; /// Pointer to the Splash header.
	struct ResGraphicInfo *m_pResSplashInfo[RES_TOTAL_SPLASH]; /// Array of Pointers to GraphicInfo.
	UCHAR *m_pSplashBitmap[RES_TOTAL_SPLASH]; /// Array of Pointers to the Splash Image.

	struct ResPanelHeader *m_pResPanelHdr;		///	Pointer to the Panel header.
	struct ResPanel *m_pResPanelInfo[RES_TOTAL_PANELS]; /// Array of pointers to ResPanel.
	UCHAR *m_pPanelBitmap[RES_TOTAL_PANELS];	/// Array of Pointer to bitmaps.

	UCHAR *m_pSPMapdata[RES_TOTAL_PANELS];	/// Array of Pointers to SP Map data.
	UCHAR *m_pKeyMapdata[RES_TOTAL_PANELS];	/// Array of Pointers to Key map data.
	UCHAR *m_pKeyMapdataMultiLang[RES_TOTAL_PANELS];	/// Array of Pointers to Key map data.

};

#endif //__OEMINFO_H__

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 OEM Creator
/// @n Filename:  OEMInfo.cpp
/// @n Description: Implementation of the COEMInfo class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  59  Stability Project 1.54.1.3 7/2/2011 4:59:09 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  58  Stability Project 1.54.1.2 7/1/2011 4:38:32 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  57  Stability Project 1.54.1.1 3/17/2011 3:20:31 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  56  Stability Project 1.54.1.0 2/15/2011 3:03:30 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// **************************************************************************

#include <wchar.h>
#include "OEMInfo.h"
#include "V6crc.h"
#include "V6ResourceBase.h"
#include "V6_ErrorDefinitions.h"

#include "Registry.h"
#include "ConfigurationCommon.h"
#include "ppl.h"
#include "V6globals.h"
#include "dal.h"
#include "V6ResConstants.h"



/// Static/const initialisation
std::auto_ptr<COEMInfo> COEMInfo::ms_kOEMInfo;
QMutex ms_hCreationMutex;

#ifdef _TEST_APP
static const DWORD g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS = 5000;
#endif

//****************************************************************************
// COEMInfo()
///
/// Constructor
///
//****************************************************************************
COEMInfo::COEMInfo() {
	m_lpBuffer = NULL;
	m_pResBlkHdr = NULL;
	m_szResFileName[0] = 0;

	// if not the test application then specify the OEM package name for now
#ifndef _TEST_APP
#ifndef TTR6SETUP
	CDeviceAbstraction *pkDALInstance = CDeviceAbstraction::GetHandle();

	// concatanate the new OEM path with the internal compact flash path
    pkDALInstance->BuildPath(IDS_INTERNAL_SD, IDS_OEM_DATA, "", QString::fromWCharArray(m_szResFileName),
	MAX_PATH);

	QString   strObseleteResPackFileName("");

	// now add the file name
    // TODO : Get the device type from the system
	if (( pDEVICE_INFO->GetDeviceType() == DEV_PC_MULTI) || ( pDEVICE_INFO->GetDeviceType() == DEV_ARISTOS_MULTIPLUS)) {
#ifdef UNDER_CE
		// remove the other pck file from the recorder
		strObseleteResPackFileName.asprintf( L"%sMiniTrend.pck", m_szResFileName );
		CStorage kOEMFileToDelete;
		FileException kEx;
		// check the file exists
		if( kOEMFileToDelete.Open( strObseleteResPackFileName, CStorage::ReadOnly, &kEx ) != 0 )
		{
			// Set file attributes before trying to remove
			CFileStatus kOEMPackStatus; 

			// the file appears to exist - set to writeable and delete
			kOEMFileToDelete.GetStatus( kOEMPackStatus );
			kOEMPackStatus.m_attribute = 0x00;
			kOEMFileToDelete.Close();
			CStorage::SetStatus( strObseleteResPackFileName, kOEMPackStatus );

			DeleteFile( strObseleteResPackFileName );
		}
#endif

		// now setup the path for the resource pack we want to load
		wcscat_s(m_szResFileName, sizeof(m_szResFileName) / sizeof(WCHAR), L"MultiTrend.pck");
	} else if (( pDEVICE_INFO->GetDeviceType() == DEV_PC_MINI)
			|| ( pDEVICE_INFO->GetDeviceType() == DEV_ARISTOS_MINITREND)) {
#ifdef UNDER_CE
		// remove the other pck file from the recorder
		strObseleteResPackFileName.asprintf( L"%sMultiTrend.pck", m_szResFileName );

		CStorage kOEMFileToDelete;
		FileException kEx;
		// check the file exists
		if( kOEMFileToDelete.Open( strObseleteResPackFileName, CStorage::ReadOnly, &kEx ) != 0 )
		{
			// Set file attributes before trying to remove
			CFileStatus kOEMPackStatus; 

			// the file appears to exist - set to writeable and delete
			kOEMFileToDelete.GetStatus( kOEMPackStatus );
			kOEMPackStatus.m_attribute = 0x00;
			kOEMFileToDelete.Close();
			CStorage::SetStatus( strObseleteResPackFileName, kOEMPackStatus );

			DeleteFile( strObseleteResPackFileName );
		}
#endif

		// now setup the path for the resource pack we want to load
		wcscat_s(m_szResFileName, sizeof(m_szResFileName) / sizeof(WCHAR), L"MiniTrend.pck");
	} else	// This is ExTrend....
	{
		// We are not removing the other PCK files here....
		// now setup the path for the resource pack we want to load
		wcscat_s(m_szResFileName, sizeof(m_szResFileName) / sizeof(WCHAR), L"eZTrend.pck");
	}
#else
	{
		//get the working file path and remove the application name.
		//this is then replaced with the name of resource file used
		//for product name, description etc.
		TCHAR szCurDir[MAX_PATH];
		szCurDir[0] = 0;
		::GetModuleFileName(AfxGetApp()->m_hInstance, szCurDir, MAX_PATH);

		QString  csCurPck(szCurDir);

		int iPos = csCurPck.ReverseindexOf( '\\' );
		csCurPck.Delete(iPos, csCurPck.size() - iPos);		//strip out the product exe name
		csCurPck += cs_PCK_NAME;								//append the new resource name
		
		wcsncpy(m_szResFileName, (const WCHAR*)csCurPck, MAX_PATH);		//set the full resource path
	}
#endif
#endif

}
#ifdef _TEST_APP
//****************************************************************************
// LoadResourceFile( QString pwcFileName )
///
/// Method that loads the specified resource file
///
/// @param[in]		QString pwcFileName - The resource file name
///
//****************************************************************************
void COEMInfo::LoadResourceFile( QString pwcFileName )
{
	wcsncpy( m_szResFileName, pwcFileName, MAX_PATH );
	// release any existing memory
	if( m_lpBuffer != NULL )
	{
		::VirtualFree( m_lpBuffer, 0, MEM_RELEASE );
		m_lpBuffer = NULL;
	}

	if( m_szResFileName[0] != 0 )
	{
		GfxResourceInit();
	}
}
#endif
//****************************************************************************
// ~COEMInfo()
///
/// Destructor
///
//****************************************************************************
COEMInfo::~COEMInfo() {
#ifndef _TEST_APP
	POSITION tPos = m_kBitmapMap.GetStartPosition();
	ULONG ulKey = 0;
	T_BITMAP_STORE tValue;

	while (tPos != NULL) {
		m_kBitmapMap.GetNextAssoc(tPos, ulKey, tValue);
		::LocalFree(tValue.ptBitmapInfo);
		DeleteObject(tValue.hBitmap);
	}

	m_kBitmapMap.clear();
#endif
	::VirtualFree(m_lpBuffer, 0, MEM_RELEASE);
	for (int i = 0; i < RES_TOTAL_PANELS; i++) {
		if (NULL != m_pKeyMapdata[i]) {
			delete m_pKeyMapdata[i];
		}
	}
}
#ifndef _TEST_APP
//****************************************************************************
// void FreeBitmapHandle( const ULONG ulRESOURCE_ID )
///
/// Method that frees the memory allocated to the passed in bitmap handle
///
//****************************************************************************
void COEMInfo::FreeBitmapHandle(const ULONG ulRESOURCE_ID) {
	QImage hBitmap = NULL;
	T_BITMAP_STORE tBitmapStore;
	tBitmapStore.hBitmap = 0;
	if (tBitmapStore = m_kBitmapMap.value(ulRESOURCE_ID) != 0) {
		m_kBitmapMap.RemoveKey(ulRESOURCE_ID);

		::LocalFree(tBitmapStore.ptBitmapInfo);
		DeleteObject(tBitmapStore.hBitmap);
	}
	hBitmap = tBitmapStore.hBitmap;
}
#endif
//****************************************************************************
// COEMInfo* Instance()
///
/// Singleton Accessor/Creator
///
/// @return A pointer to the singleton instance of the class
/// 
//****************************************************************************
COEMInfo* COEMInfo::Instance() {
	if (ms_kOEMInfo.get() == NULL) {
		DWORD waitSingleObjectResult = WAIT_OBJECT_0;
		// An instance has yet to be completed
		ms_hCreationMutex = CreateMutex(NULL,					// No security descriptor
				FALSE,					// Mutex object not owned
				TEXT("COEMInfo"));		// Object name
		waitSingleObjectResult = ms_hCreationMutex.tryLock(g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);

		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:
			// Object was signaled
			if (NULL == ms_kOEMInfo.get()) {
				std::auto_ptr<COEMInfo> kNewOEMInfo(new COEMInfo);
				ms_kOEMInfo = kNewOEMInfo;
				COEMInfo *pkOEMInfo = ms_kOEMInfo.get();

				for (int nResItr = 0; nResItr < RES_TOTAL_PANELS; nResItr++) {
					pkOEMInfo->m_pKeyMapdata[nResItr] = NULL;
				}	//Yadav

				// initialise the resources
				if (pkOEMInfo->GfxResourceInit() == FALSE) {
#ifndef DOCVIEW
#ifndef _TEST_APP
#ifndef TTR6SETUP
					QString   strError("");
					strError.LoadString( V6_E_CANNOT_INIT_OEM_PACK);

					// unable to initialise the OEM resource pack
					LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "Unable to initialise the OEM resource pack");

					pSYSTEM_INFO->AddStartupErr(strError);

					while (1);
#endif
#endif
#endif
				}
#ifndef DOCVIEW
#ifndef _TEST_APP
#ifndef TTR6SETUP
				// do the version check
				if (sOEMID != pkOEMInfo->GetOEMId()) {
					// the versions are different
                    QString   strError= "";
                    QString   strasprintfString = "";
					strasprintfString.LoadString( V6_E_OEM_PACK_ID_MISMATCH);
					strError.asprintf(strasprintfString, sOEMID, pkOEMInfo->GetOEMId());

					LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
					pSYSTEM_INFO->AddStartupErr(strError);
				}

				// update the registry with some system settings such as scrollbar width
				pkOEMInfo->UpdateRegistry();

				// update the system colours to those specified with the resource file
				pkOEMInfo->UpdateSystemColours();
#else 
					// do the version check
					if( sOEMID != pkOEMInfo->GetOEMId() )
					{
						// the versions are different
						QString  strError( QString   ::fromWCharArray("") );
						QString  strasprintfString( QString   ::fromWCharArray("") );
						strasprintfString.LoadString( V6_E_OEM_PACK_ID_MISMATCH );
						strError.asprintf(	strasprintfString,
											sOEMID,
											pkOEMInfo->GetOEMId() );

						QMessageBox(strError);
					}
#endif
#endif
#endif
			}
			if ( FALSE == ms_hCreationMutex.unlock()) {
#ifndef _TEST_APP
				V6WarningMessageBox(NULL, L"Failed to release COEMInfo mutex", L"Error", MB_OK);
#endif
			}
			break;

		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
#ifndef _TEST_APP
			V6WarningMessageBox(NULL, L"COEMInfo WaitForSingleObject Error", L"Error", MB_OK);
#endif
			break;
		}
		// Close the Mutex as no longer required
		//No need to close the mutex in Qt
	}

	return ms_kOEMInfo.get();
}
//****************************************************************************
// BOOL GfxResourceInit()
///
/// Initialize the Headers for all the Readers routines.
///
/// @return True if the headers were initialised successfully
/// 
//****************************************************************************
// TOOD : Code rewrite
BOOL COEMInfo::GfxResourceInit() {
	BOOL bSuccess = FALSE;

	if (m_szResFileName[0] != '\0') {
		HANDLE hFile;
		DWORD dwSize = -1;
		DWORD dwRead = -1;

		//Open the Resource pack file
		hFile = CreateFile(m_szResFileName, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL,
				NULL);

		// Check a file was found
		if (hFile == INVALID_HANDLE_VALUE) {
#ifdef DOCVIEW
			return FALSE;
#endif
#ifndef _TEST_APP

			FailedToLoadExtResPack();

			// An OEM file does not exist therefore load the standard honeywell pack
			// get a handle to the file - this won't work on the recroder builds but the code
			// should never get this far as the above method will hand the system
			HRSRC hResHandle = indexOfResource(AfxGetApp()->m_hInstance, L"HoneywellPack", L"OEMInfo");
			HGLOBAL hGlob = LoadResource(AfxGetApp()->m_hInstance, hResHandle);
			hFile = (HANDLE) hGlob;
			// copy the file to the buffer
			dwSize = SizeofResource(AfxGetApp()->m_hInstance, hResHandle);
			SYSTEM_INFO tSysInfo;
			GetSystemInfo(&tSysInfo);
			m_lpBuffer = static_cast<unsigned char*>(::VirtualAlloc(NULL, dwSize + tSysInfo.dwPageSize, MEM_RESERVE,
					PAGE_NOACCESS));
			m_lpBuffer = static_cast<unsigned char*>(::VirtualAlloc(m_lpBuffer, dwSize + tSysInfo.dwPageSize,
					MEM_COMMIT, PAGE_READWRITE));
			unsigned char *pucData = (unsigned char*) ::LockResource(hGlob);
			memcpy(m_lpBuffer, pucData, dwSize);
			UnlockResource(hGlob);
			FreeResource(hGlob);

#endif
		} else {
			// copy the file to the buffer
			dwSize = GetFileSize(hFile, NULL);
#ifndef _TEST_APP
			if (dwSize == 0) {
				FailedToLoadExtResPack();
			}
#endif
			SYSTEM_INFO tSysInfo;
			GetSystemInfo(&tSysInfo);
			m_lpBuffer = static_cast<unsigned char*>(::VirtualAlloc(NULL, dwSize + tSysInfo.dwPageSize, MEM_RESERVE,
					PAGE_NOACCESS));
			m_lpBuffer = static_cast<unsigned char*>(::VirtualAlloc(m_lpBuffer, dwSize + tSysInfo.dwPageSize,
					MEM_COMMIT, PAGE_READWRITE));
			if (!ReadFile(hFile, (LPVOID) m_lpBuffer, dwSize, &dwRead, NULL)) {
#ifndef _TEST_APP
				// the versions are different
				QString   strError("");
				strError.asprintf( V6_E_OEM_PACK_READ_FAILURE, GetLastError());

				LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "Failed to read OEM resource pack");

				pSYSTEM_INFO->AddStartupErr(strError);
#endif
			}
			//No need to close the mutex in Qt
		}

		// check the buffer was found
		if (m_lpBuffer != NULL) {
			USHORT crcVal = CrcCalc(m_lpBuffer, (dwSize - 0x02));

			// Assign a Pointer to the CRC High Byte
			unsigned char *pCRCHighByte = (unsigned char*) (m_lpBuffer + (dwSize - 2));

			// Assign a Pointer to the CRC Low Byte
			unsigned char *pCRCLowByte = (unsigned char*) (m_lpBuffer + (dwSize - 1));

			// Shift CRC left by one byte
			unsigned short CRCShiftedleftByOneByte = (crcVal & 0xFF);

			// Shift CRC right by one byte to obtain the top byte, AND by 0xFF for compatiablity with processor's
			unsigned short CRCShiftedrightByOneByte = ((crcVal >> 8) & 0xFF);

			if ((CRCShiftedrightByOneByte != (*pCRCLowByte)) || (CRCShiftedleftByOneByte != (*pCRCHighByte))) {
#ifndef _TEST_APP
				QString   strError("");
				strError.LoadString( V6_E_OEM_PACK_CRC_FAILURE);

				// unable to initialise the OEM resource pack
				LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "OEM resource pack CRC failure");

				pSYSTEM_INFO->AddStartupErr(strError);
#endif

				return FALSE;
			}

			/******************************************************************************************/
			//Retrieve Block Header
			/******************************************************************************************/

			// Initialize the m_pResBlkHdr pointer with the m_lpBuffer. 
			m_pResBlkHdr = (V6ResBlockHeader*) m_lpBuffer;

			/******************************************************************************************/
			//Retrieve Information for the Text Section.
			/******************************************************************************************/

			// pResTxtHdr = starting address stored in m_lpBuffer + Jump address of the Text Section.
			m_pResTxtHdr = (ResTextHeader*) ((unsigned char*) m_lpBuffer + m_pResBlkHdr->Jump[RES_TEXT]);

			int i = 0;
			for (i = 0; i < m_pResTxtHdr->Num; i++) {
				// Get the addresses for the Text SubSections.
				m_pResTextInfo[i] = (ResTextInfo*) ((unsigned char*) m_pResTxtHdr + m_pResTxtHdr->Jump[i]);
			}

			/******************************************************************************************/
			//Retrieve Information for the Colour Section.
			/******************************************************************************************/

			// pResColorHdr = starting address stored in m_lpBuffer + Jump address of the COLOURS Section.
			m_pResColorHdr = (ResColourHeader*) ((unsigned char*) m_lpBuffer + m_pResBlkHdr->Jump[RES_COLOURS]);

			for (i = 0; i < m_pResColorHdr->Num; i++) {
				// Get the addresses for the Text SubSections.
				m_pResColorInfo[i] = (ResColour*) ((unsigned char*) m_pResColorHdr + m_pResColorHdr->Jump[i]);
			}

			/******************************************************************************************/
			//Retrieve Information for the Graphics Section.
			/******************************************************************************************/

			// pResGraphHdr = starting address stored in m_lpBuffer + Jump address of the Graphics Section.
			m_pResGraphHdr = (ResGraphicHeader*) ((unsigned char*) m_lpBuffer + m_pResBlkHdr->Jump[RES_GRAPHICS]);

			for (i = 0; i < m_pResGraphHdr->Num; i++) {
				// Get the addresses for the Graphics SubSections.
				m_pResGraphInfo[i] = (ResGraphicInfo*) ((unsigned char*) m_pResGraphHdr + m_pResGraphHdr->Jump[i]);

				// Get the pointers for the Bitmaps.
				m_pBitmapData[i] = (UCHAR*) ((unsigned char*) m_pResGraphHdr + m_pResGraphInfo[i]->Offset);
			}

			/******************************************************************************************/
			//Retrieve Information for the Panels Section.
			/******************************************************************************************/

			// pResPanelHdr = starting address stored in m_lpBuffer + Jump address of the Panels Section.
			m_pResPanelHdr = (ResPanelHeader*) ((unsigned char*) m_lpBuffer + m_pResBlkHdr->Jump[RES_PANELS]);

			for (i = 0; i < m_pResPanelHdr->Num; i++) {

				// Get the addresses for the Respanel Info.
				m_pResPanelInfo[i] = (ResPanel*) ((unsigned char*) m_pResPanelHdr + m_pResPanelHdr->Jump[i]);

				// Get the addresses for the Bitmaps.
				m_pPanelBitmap[i] = (UCHAR*) ((unsigned char*) m_pResPanelHdr + m_pResPanelInfo[i]->graUp.Offset);

				// Get the addresses for Size and Position Files.
				m_pSPMapdata[i] = (UCHAR*) ((unsigned char*) m_pResPanelHdr + m_pResPanelInfo[i]->lSPMapOffset);

				// Get the addresses for Keys Files.
#ifndef _TEST_APP
				//Get the current language
				int nLangOpt = 0;
				const T_PGENNONVOL ptGEN_NON_VOL = pGlbSysInfo->GetFactoryConfig();
				T_LANGUAGES eLang = static_cast<T_LANGUAGES>(ptGEN_NON_VOL->Language);//Get the current language from the global structure
				switch (i) {
				case V6RES_PANEL_GRAPHIC_FULLPANEL:
					switch (eLang) {
					case lngEnglish:
					case lngEngUS:
						nLangOpt = V6RES_PANEL_GRAPHIC_FULLPANEL_ENGLISH;
						break;

					case lngFra:
						nLangOpt = V6RES_PANEL_GRAPHIC_FULLPANEL_FRENCH;
						break;

					case lngGer:
						nLangOpt = V6RES_PANEL_GRAPHIC_FULLPANEL_GERMAN;
						break;

					case lngGrk:
						nLangOpt = V6RES_PANEL_GRAPHIC_FULLPANEL_GREEK;
						break;

					case lngRus:
						nLangOpt = V6RES_PANEL_GRAPHIC_FULLPANEL_RUSSIAN;
						break;
					case lngBulg:
						nLangOpt = V6RES_PANEL_GRAPHIC_FULLPANEL_BULGARIAN;
						break;
#if LangChinese == 1
					case lngChin:
						nLangOpt = V6RES_PANEL_GRAPHIC_FULLPANEL_ENGLISH;
						break;
#endif
#if LangJapanese == 1
					case lngJap:
						nLangOpt = V6RES_PANEL_GRAPHIC_FULLPANEL_ENGLISH;
						break;
#endif
#if LangKorean == 1
					case lngKor:
						nLangOpt = V6RES_PANEL_GRAPHIC_FULLPANEL_ENGLISH;
						break;
#endif
						/*case lngJap:
						 nLangOpt = V6RES_PANEL_GRAPHIC_FULLPANEL_JAPANESE;
						 break;*/
					}
					break;

				case V6RES_PANEL_GRAPHIC_MULEPANEL:
				case V6RES_PANEL_GRAPHIC_NUMPANEL:
					nLangOpt = V6RES_PANEL_GRAPHIC_NUMPANEL_DEFAULT;
					break;
				}
				stKeyMapInfo *KeyMapTmp = new stKeyMapInfo();	//Dynamically created for each panel
				//Convert from KeyMap[nLangOpt][nKeyItr] in stKeyMapInfoMultiLang to KeyMap[nKeyItr] in stKeyMapInfo
				for (int nKeyItr = 0; nKeyItr < MAXKMAPENTRY; nKeyItr++) {
					KeyMapTmp->KeyMap[nKeyItr] = ((stKeyMapInfoMultiLang*) ((UCHAR*) ((unsigned char*) m_pResPanelHdr
							+ m_pResPanelInfo[i]->lKeyMapOffset)))->KeyMap[nLangOpt][nKeyItr];
				}
				m_pKeyMapdata[i] = (UCHAR*) KeyMapTmp;
				KeyMapTmp->entry = ((stKeyMapInfoMultiLang*) ((UCHAR*) ((unsigned char*) m_pResPanelHdr
						+ m_pResPanelInfo[i]->lKeyMapOffset)))->entry;
#endif
				m_pKeyMapdataMultiLang[i] = (UCHAR*) ((unsigned char*) m_pResPanelHdr
						+ m_pResPanelInfo[i]->lKeyMapOffset);

			}
			bSuccess = TRUE;
		}

	}
#ifndef TTR6SETUP
#ifndef DOCVIEW
	else {
#ifndef _TEST_APP
		// invalid file name
		QString   strError("");
		strError.asprintf( V6_E_OEM_PACK_FILENAME_ERROR, GetLastError());

		LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "COEMInfo resource pack filename is NULL");

		pSYSTEM_INFO->AddStartupErr(strError);
#endif
	}
#endif
#endif

	return bSuccess;
}
//****************************************************************************
// ResColour* GetColour(int nIndex)
///
/// Get the ResColour structure for the specified index
///
/// @param[in]		int nIndex - The index (resource ID) of the required item
///
/// @return The ResColour information for the specified Index
/// 
//****************************************************************************
ResColour* COEMInfo::GetColour(int nIndex) {
	if (nIndex < m_pResColorHdr->Num)
		return m_pResColorInfo[nIndex];
	else
		return m_pResColorInfo[0]; //Once the default value is finalised, return that.
}
//****************************************************************************
// ResTextInfo* GetText(int nIndex)
///
/// Get the ResTextInfo structure for the specified index
///
/// @param[in]		int nIndex - The index (resource ID) of the required item
///
/// @return The text for the specified Index
/// 
//****************************************************************************
ResTextInfo* COEMInfo::GetText(int nIndex) {
	if (nIndex < m_pResTxtHdr->Num)
		return m_pResTextInfo[nIndex];
	else
		return m_pResTextInfo[0]; //Once the default value is finalised, return that.
}
//****************************************************************************
// ResGraphicInfo* GetGraphicInfo(int nIndex)
///
/// Get the ResGraphicInfo structure for the specified index.
///
/// @param[in]		int nIndex - The index (resource ID) of the required item
///
/// @return The address for the GraphicInfo for the specified Index
/// 
//****************************************************************************
ResGraphicInfo* COEMInfo::GetGraphicInfo(int nIndex) {
	if (nIndex < m_pResGraphHdr->Num)
		return m_pResGraphInfo[nIndex];
	else
		return m_pResGraphInfo[0]; //Once the default value is finalised, return that.
}
//****************************************************************************
// ResGraphicInfo* GetGraphicInfo(int nIndex)
///
/// Get the Bitmap for the specified index
///
/// @param[in]		int nIndex - The index (resource ID) of the required item
///
/// @return The address for the Bitmaps
/// 
//****************************************************************************
UCHAR* COEMInfo::GetGraphic(int nIndex) {
	if (nIndex < m_pResGraphHdr->Num)
		return m_pBitmapData[nIndex];
	else
		return m_pBitmapData[0];

}
//****************************************************************************
// ResPanel* GetPanelInfo(int nIndex)
///
/// Get the ResPanel structure for the specified index
///
/// @param[in]		int nIndex - The index (resource ID) of the required item
///
/// @return Returns the address for the SP information for the specified Index.
/// 
//****************************************************************************
ResPanel* COEMInfo::GetPanelInfo(int nIndex) {
	if (nIndex < m_pResPanelHdr->Num)
		return m_pResPanelInfo[nIndex];
	else
		return m_pResPanelInfo[0]; //Once the default value is finalised, return that.
}
//****************************************************************************
// UCHAR* GetPanelUpImage(int nIndex)
///
/// Get the Panel Image for the specified index
///
/// @param[in]		int nIndex - The index (resource ID) of the required item
///
/// @return Returns the address of Panel's Bitmap for the specified Index
/// 
//****************************************************************************
UCHAR* COEMInfo::GetPanelUpImage(int nIndex) {
	if (nIndex < m_pResPanelHdr->Num)
		return m_pPanelBitmap[nIndex];
	else
		return m_pPanelBitmap[0];
}
//****************************************************************************
// UCHAR* GetPanelSPMap(int nIndex)
///
/// Get the Size and Position Map for the specified index
///
/// @param[in]		int nIndex - The index (resource ID) of the required item
///
/// @return The address for the SP information for the specified Index
/// 
//****************************************************************************
UCHAR* COEMInfo::GetPanelSPMap(int nIndex) {
	if (nIndex < m_pResPanelHdr->Num)
		return m_pSPMapdata[nIndex];
	else
		return m_pSPMapdata[0];
}
//****************************************************************************
// UCHAR* GetPanelKeyMap(int nIndex)
///
/// Get the Key Map for the specified index
///
/// @param[in]		int nIndex - The index (resource ID) of the required item
///
/// @return The address for the Key information for the specified Index
/// 
//****************************************************************************
UCHAR* COEMInfo::GetPanelKeyMap(int nIndex) {
	if (nIndex < m_pResPanelHdr->Num)
		return m_pKeyMapdata[nIndex];
	else
		return m_pKeyMapdata[0];
}

//****************************************************************************
// UCHAR* GetPanelKeyMapMultiLang(int nIndex)
///
/// Get the Key Map for the specified index for all languages
///
/// @param[in]		int nIndex - The index (resource ID) of the required item
///
/// @return The address for the Key information for the specified Index
/// 
//****************************************************************************
UCHAR* COEMInfo::GetPanelKeyMapMultiLang(int nIndex) {
	if (nIndex < m_pResPanelHdr->Num)
		return m_pKeyMapdataMultiLang[nIndex];
	else
		return m_pKeyMapdataMultiLang[0];
}

//****************************************************************************
// int GetOEMId()
///
/// Get the OEMID for the current resource pack
///
/// @param[in]		void
///
/// @return the OEMID for the current resource pack.
/// 
//****************************************************************************
int COEMInfo::GetOEMId() {
	int iOEMID = -1;
	if (m_pResBlkHdr != NULL) {
		iOEMID = m_pResBlkHdr->OEMID;
	}
	return iOEMID;
}

#ifndef _TEST_APP
//****************************************************************************
// const bool GetHorizSBDimensions( USHORT &rusHeight, USHORT &rusWidth )
///
/// Method that gets the horizontal scrollbar bitmap dimensions
/// 
/// @param[out]			USHORT &rusHeight - The height of the scrollbar bitmap
/// @param[out]			USHORT &rusWidth - The width of the scrollbar bitmap
///
/// @return			True if the bitmap was found
///
//****************************************************************************
const bool COEMInfo::GetHorizSBDimensions(USHORT &rusHeight, USHORT &rusWidth) {
	ResGraphicInfo *ptDimensions = GetGraphicInfo( V6RES_GRAPHIC_HSCROLLBAR_DIMENSIONS_BMP);

	// check the bitmap was found okay
	if (ptDimensions != NULL) {
		rusHeight = static_cast<USHORT>(ptDimensions->Height);
		rusWidth = static_cast<USHORT>(ptDimensions->Width);
	}
	return (ptDimensions != NULL);
}
//****************************************************************************
// const bool GetVerticalSBDimensions( USHORT &rusHeight, USHORT &rusWidth )
///
/// Method that gets the vertical scrollbar bitmap dimensions
/// 
/// @param[out]			USHORT &rusHeight - The height of the scrollbar bitmap
/// @param[out]			USHORT &rusWidth - The width of the scrollbar bitmap
///
/// @return			True if the bitmap was found
///
//****************************************************************************
const bool COEMInfo::GetVerticalSBDimensions(USHORT &rusHeight, USHORT &rusWidth) {
	ResGraphicInfo *ptDimensions = GetGraphicInfo(V6RES_GRAPHIC_VSCROLLBAR_DIMENSIONS_BMP);

	// check the bitmap was found okay
	if (ptDimensions != NULL) {
		rusHeight = static_cast<USHORT>(ptDimensions->Height);
		rusWidth = static_cast<USHORT>(ptDimensions->Width);
	}

	return (ptDimensions != NULL);
}
//****************************************************************************
// void UpdateRegistryInfo()
///
/// Update any registry information
/// 
//****************************************************************************
void COEMInfo::UpdateRegistry() {
	T_CONFIG_RETURN_VALUE retValue = CONFIG_OK;
	CRegistryKey kRegKey;

	USHORT usHorizSBHeight = 25;
	USHORT usHorizSBWidth = 25;
	USHORT usVertSBHeight = 25;
	USHORT usVertSBWidth = 25;
	GetHorizSBDimensions(usHorizSBHeight, usHorizSBWidth);
	GetVerticalSBDimensions(usVertSBHeight, usVertSBWidth);

	// If the registry key doesn't exist
	if (!kRegKey.OpenKey(L"SYSTEM\\GWE")) {
		// create it
		if (!kRegKey.CreateKey(L"SYSTEM\\GWE")) {
			retValue = CONFIG_ERROR;
		}
	}
	// if the open/create was OK
	if (CONFIG_ERROR != retValue) {
		DWORD dwScrollBarHeight = 0;
		bool bModified = false;
		DWORD dwType = REG_DWORD;
		DWORD dwSize = sizeof(DWORD);
		kRegKey.ReadValue(L"cyVScr", &dwType, reinterpret_cast<BYTE*>(&dwScrollBarHeight), &dwSize);
		if (dwScrollBarHeight != usVertSBHeight) {
			dwScrollBarHeight = usVertSBHeight;
			kRegKey.WriteValue(L"cyVScr", dwScrollBarHeight);
			bModified = true;
		}

		DWORD dwScrollBarWidth = 0;
		kRegKey.ReadValue(L"cxHScr", &dwType, reinterpret_cast<BYTE*>(&dwScrollBarWidth), &dwSize);
		if (dwScrollBarWidth != usHorizSBWidth) {
			dwScrollBarWidth = usHorizSBWidth;
			kRegKey.WriteValue(L"cxHScr", dwScrollBarWidth);
			bModified = true;
		}

		dwScrollBarHeight = 0;
		kRegKey.ReadValue(L"cyHScr", &dwType, reinterpret_cast<BYTE*>(&dwScrollBarHeight), &dwSize);
		if (dwScrollBarHeight != usHorizSBHeight) {
			dwScrollBarHeight = usHorizSBHeight;
			kRegKey.WriteValue(L"cyHScr", dwScrollBarHeight);
			bModified = true;
		}

		dwScrollBarWidth = 0;
		kRegKey.ReadValue(L"cxVScr", &dwType, reinterpret_cast<BYTE*>(&dwScrollBarWidth), &dwSize);
		if (dwScrollBarWidth != usVertSBWidth) {
			dwScrollBarWidth = usVertSBWidth;
			kRegKey.WriteValue(L"cxVScr", dwScrollBarWidth);
			bModified = true;
		}

		// check if the registry has been modified
		if (bModified) {
			// persist the registry
			kRegKey.Flush();
		}
		kRegKey.Close();

	}

	// check if there was an error
	if (retValue != CONFIG_OK) {
		// problem writing to the registry
		LOG_ERR(CONFIG_qDebugR_MODE, ("Unable to initialise the OEM registry settings"));
	}
}
//****************************************************************************
// UpdateSystemColours()
///
/// Method that updates the current system colours
///
//****************************************************************************
void COEMInfo::UpdateSystemColours() {
#ifdef UNDER_CE
	int iaColourIDs[7] = {	COLOR_STATIC, 
							COLOR_SCROLLBAR, 
							COLOR_BTNFACE, 
							COLOR_3DDKSHADOW,
							COLOR_3DSHADOW,
							COLOR_3DHILIGHT,
							COLOR_3DLIGHT } ;

	COLORREF craSysColours[7];
	ResColour *pkColour = GetColour( V6RES_COLOUR_BKGCOLOUR );
	if( pkColour != NULL )
	{
		craSysColours[0] = pkColour->pColor;
	}
	else
	{
		craSysColours[0] = 0;
	}

	pkColour = GetColour( V6RES_COLOUR_SCROLLBAR_BKG );
	if( pkColour != NULL )
	{
		craSysColours[1] = pkColour->pColor;
	}
	else
	{
		craSysColours[1] = 0;
	}

	pkColour = GetColour( V6RES_COLOUR_BKGCOLOUR );
	if( pkColour != NULL )
	{
		craSysColours[2] = pkColour->pColor;
	}
	else
	{
		craSysColours[2] = 0;
	}
	
	pkColour = GetColour( V6RES_COLOUR_COLOR_3DDKSHADOW );
	if( pkColour != NULL )
	{
		craSysColours[3] = pkColour->pColor;
	}
	else
	{
		craSysColours[3] = 0;
	}

	pkColour = GetColour( V6RES_COLOUR_COLOR_3DSHADOW );
	if( pkColour != NULL )
	{
		craSysColours[4] = pkColour->pColor;
	}
	else
	{
		craSysColours[4] = 0;
	}

	pkColour = GetColour( V6RES_COLOUR_COLOR_3DHILIGHT );
	if( pkColour != NULL )
	{
		craSysColours[5] = pkColour->pColor;
	}
	else
	{
		craSysColours[5] = 0;
	}

	pkColour = GetColour( V6RES_COLOUR_COLOR_3DLIGHT );
	if( pkColour != NULL )
	{
		craSysColours[6] = pkColour->pColor;
	}
	else
	{
		craSysColours[6] = 0;
	}
		
	SetSysColors( sizeof( iaColourIDs ) / sizeof( int ), iaColourIDs, craSysColours );
#endif
}
//******************************************************
/// QImage GetBitmapHandle( const ULONG ulRESOURCE_ID )
///
/// Get a handle to the passed in bitmap ID
///
/// @param[in]			const ULONG ulRESOURCE_ID - The resource ID of the required bitmap
///
/// @return handle of the bitmap
///  
//******************************************************
QImage COEMInfo::GetBitmapHandle(const ULONG ulRESOURCE_ID) {
	QImage hBitmap = NULL;
	T_BITMAP_STORE tBitmapStore;
	tBitmapStore.hBitmap = 0;

	// check if this bitmap has already been loaded
	if (tBitmapStore = m_kBitmapMap.value(ulRESOURCE_ID) == 0) {
		ResGraphicInfo *pkGraphicInfo = /*pSYSTEM_INFO->pOemInfo->*/GetOEMInfo()->GetGraphicInfo(ulRESOURCE_ID);

		tBitmapStore.hBitmap = LoadDIBBitmap( /*pSYSTEM_INFO->pOemInfo->*/GetOEMInfo()->GetGraphic(ulRESOURCE_ID),
				pkGraphicInfo->size, &tBitmapStore.ptBitmapInfo);
		m_kBitmapMap[ulRESOURCE_ID] = tBitmapStore;
	}
	hBitmap = tBitmapStore.hBitmap;

	return hBitmap;
}
//******************************************************
/// QImage LoadDIBBitmap( void * pBmpFile, DWORD BufferLength, BITMAPINFO **rptBitmapInfo )
///
/// Prepare the handle for the bitmap.
///
/// @param[in]			void *pBmpFile - Pointer to the bitmap file
///	@param[in]			DWORD BufferLength - the size of the bitmap
/// @param[out]			BITMAPINFO **rptBitmapInfo - Pointer to the bitmap information passed by reference
///
/// @return handle of the bitmap for further use. 
///  
//******************************************************
QImage COEMInfo::LoadDIBBitmap(void *pBmpFile, DWORD dwBufferLength, BITMAPINFO **rptBitmapInfo) {
	QImage hBmp = NULL;
	LPVOID lpBits;
	// get a pointer to the bitmap information at the start of the file
	BITMAPFILEHEADER *pbmfHeader = reinterpret_cast<BITMAPFILEHEADER*>(pBmpFile);

	// Create a temporary pointer to the bitmap information
	void *pTempBmpFile = NULL;

	//The file type should be "BM" in the BITMAPFILEHEADER - drop out if not
	if (pbmfHeader->bfType == ((WORD) ('M' << 8) | 'B')) {
		//Allocate the memory for the BITMAPINFO structure
		*rptBitmapInfo = (BITMAPINFO*) ::LocalAlloc(LMEM_FIXED, sizeof(BITMAPINFO) + sizeof(RGBQUAD) * 256);

		// Check the specified memory was allocated okay
		if (NULL != *rptBitmapInfo) {
			// Maintain a pointer to the start of the bitmap file
			pTempBmpFile = pBmpFile;

			// Move the bitmap pointer past the bitmap file header information e.g. look at the actual bitmap data
			pBmpFile = reinterpret_cast<BYTE*>(pBmpFile) + sizeof(BITMAPFILEHEADER);

			int iTest = sizeof(BITMAPINFO) + sizeof(RGBQUAD) * 256;
			// Create the memory to store the bitmap pixel information
			memcpy(*rptBitmapInfo, pBmpFile, sizeof(BITMAPINFO) + sizeof(RGBQUAD) * 256);

			//Call the CreateDIBSection function to get the handle of the bitmap	
			hBmp = CreateDIBSection(NULL, *rptBitmapInfo, DIB_RGB_COLORS, &lpBits, NULL,
			RESETVALUE);

			//Store the information of the bitmap
			pTempBmpFile = (BYTE*) pTempBmpFile + pbmfHeader->bfOffBits;

			// check the memory was allocated okay
			if (lpBits != NULL) {
				memcpy(lpBits, pTempBmpFile, dwBufferLength - pbmfHeader->bfOffBits);
			} else {
				V6CriticalMessageBox(NULL, L"Out of memory - cannot create bitmap", L"Memory Error", MB_OK);
#ifndef _DEBUG
				// drop into an infinite while loop on release builds to prevent any damage being done
				while ( TRUE);
#endif
			}
		}
	} else {
		// invalid bitmap
		LOG_ERR(CONFIG_qDebugR_MODE, ("Invalid bitmap header specified within the OEM resource pack"));
	}

	//return the handle of the bitmap
	return hBmp;
}
#endif

/// @file
// **************************************************************************
/// © Honeywell Trendview
// **************************************************************************
/// @n Module:		I/O conditioning
/// @n Filename:	FFConversionInfo.cpp
/// @n Description: Interface to convert floating point values to and from Engineering 
///	and internal representations
// 
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 9	Stability Project 1.4.1.3	7/2/2011 4:57:12 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 8	Stability Project 1.4.1.2	7/1/2011 4:38:17 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 7	Stability Project 1.4.1.1	3/17/2011 3:20:24 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 6	Stability Project 1.4.1.0	2/15/2011 3:03:03 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
// **************************************************************************

#include <math.h>
#include "FFConversionInfo.h"

//**********************************************************************
///
/// Set the absolute limits for basis of all calculations
///
/// @param[in] ZeroSource	- Zero value of Source range
/// @param[in] SpanSource	- Span value of Source range
/// @param[in] ZeroDest		- Zero value of Destination range
/// @param[in] SpanDest		- Span value of Destination range
///
/// @return		Nothing
//**********************************************************************
void CFFConversionInfo::CalcFConvInfo(float ZeroSource, float SpanSource, float ZeroDest, float SpanDest) {
	float CurrentSourceSpan;
	float CurrentDestSpan;

	m_Zero.Source = ZeroSource;		// Source Zero and span
	m_Span.Source = SpanSource;

	m_Zero.Dest = ZeroDest;			// Destination Zero and Span
	m_Span.Dest = SpanDest;

	CurrentSourceSpan = m_Span.Source - m_Zero.Source;	// Current Source Span
	CurrentDestSpan = m_Span.Dest - m_Zero.Dest;	// Current Destination Span	

	m_SourcePerDest = CurrentSourceSpan / CurrentDestSpan;	// Engineering units per pixel

	//MarkD: prevent divide by zero
	if (CurrentSourceSpan != 0.0)
		m_DestPerSource = CurrentDestSpan / CurrentSourceSpan;	// Pixels per engineering unit
	else
		m_DestPerSource = CurrentDestSpan; // use any logical value

	m_SourceReverse = (BOOL)(m_Span.Source < m_Zero.Source);
	m_DestReverse = (BOOL)(m_Span.Dest < m_Zero.Dest);
}

//**********************************************************************
/// Get Destination scale value from a Source value
///
/// @param[in] Sourcepoint - Source Value.
///
/// @return		Dest value corresponding to Source input value
///
/// Rev History
/// @Version	@Date			@Author					@Remarks
/// 2.0			17/Apr/2019		Shankar Rao	Pendyala	Made it const function
//**********************************************************************
float CFFConversionInfo::CalcSourceToDest(float Sourcepoint) const {
	return ((((Sourcepoint - m_Zero.Source) * m_DestPerSource) + m_Zero.Dest));
}

//**********************************************************************
/// Get source scale value from a dest value
///
/// @param[in] Destpoint - Destination Value.
///
/// @return		Source value corresponding to destination input value 
///
/// Rev History
/// @Version	@Date			@Author					@Remarks
/// 2.0			17/Apr/2019		Shankar Rao	Pendyala	Made it const function
//**********************************************************************
float CFFConversionInfo::CalcDestToSource(float Destpoint) const {
	return ((((Destpoint - m_Zero.Dest) * m_SourcePerDest) + m_Zero.Source));
}

//**********************************************************************
/// Get destination magnitude from source
///
/// @param[in] SourceMagnitude - Source magnitude
///
/// @return	Destination magnitude
//**********************************************************************
float CFFConversionInfo::CalcDestMagnitude(float SourceMagnitude) {
	return (SourceMagnitude * m_DestPerSource);
}

//**********************************************************************
/// Get Destination scale value from a Source value but cap return to 
/// the limits set by the destination span
///
/// @param[in] Sourcepoint - Source Value.
///
/// @return		limit checked Dest value corresponding to Source input value
///				if Dest is outside of a limit then the limit is returned
//**********************************************************************
float CFFConversionInfo::CalcSourceToDestCapped(float Sourcepoint) {
	// Calculate value then check if it exceeeds limits
	float value = CalcSourceToDest(Sourcepoint);
	if (m_DestReverse) {
		// check for a breach of limits on a reversed scale, set to limit if breached
		if (value > m_Zero.Dest)
			value = m_Zero.Dest;
		else if (value < m_Span.Dest)
			value = m_Span.Dest;
	} else {
		// check for a breach of limits on a normal scale, set to limit if breached
		if (value > m_Span.Dest)
			value = m_Span.Dest;
		else if (value < m_Zero.Dest)
			value = m_Zero.Dest;
	}
	return value;	// Limit capped value
}

QString   CFFConversionInfo::GetConversionString() {
	QString   strConversionInfo;
	strConversionInfo.asprintf(
			L"FFConversionInfo:: m_Zero.Source %f m_Zero.Dest %f m_Span.Source %f m_Span.Dest %f m_SourcePerDest %f m_DestPerSource %f",
			m_Zero.Source, m_Zero.Dest, m_Span.Source, m_Span.Dest, m_SourcePerDest, m_DestPerSource);
	return strConversionInfo;
}


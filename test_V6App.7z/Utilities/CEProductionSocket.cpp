/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  CEProductionSocket 
/// @n Filename:  CEProductionSocket.cpp
/// @n Description: This class is responsible for communication of recorder and
/// Production Interface tool
///
// **************************************************************************
// Revision History
// 20-10-14 Rajanbabu M Fixed PAR:1-3I2GTSM - WSD communication is not working on upgrading the firmware
//	Swathi 07/23/2014 Fix for the par 1-3GM1NP1: Do not set the date when 
//					 requested for Recorder Model Number alone. This can
//				 be possible for Remote Display Tool
// Swathi 07/30/2014 Install Device Certificate when requested via Production Tool
// **************************************************************************

#include "CEProductionSocket.h"
#include "V6AppInterface.h"
#include "TopStatusBar.h"


#define MODEL_NO 01
#define SET_INFO 02
#define MODEL_TYPE 03
#define TRACE_ALLOW
// TODO : Porting of Socket interface
IV6AppInterface *g_pV6AppInterface = NULL;							 // V6AppInterface Pointer.
IV6TimeInterface *g_pV6TimeInterface = NULL;

QString   invalid = _T("invalid");

//****************************************************************************
/// CEProductionSocket - Constructor
///
/// @param n/a
///
/// @return		n/a
///
//****************************************************************************
CEProductionSocket::CEProductionSocket() {
	m_productionSocket = INVALID_SOCKET;
	m_productionReadThread = NULL;
	m_productionSocketState = NONE;
}							 //end CEProductionSocket()

//****************************************************************************
/// ~CEProductionSocket - Destructor
///
/// @param n/a
///
/// @return		n/a
///
//****************************************************************************
CEProductionSocket::~CEProductionSocket() {

}							 //end ~CEProductionSocket()

//****************************************************************************
/// Create - creates a new socket
///
/// @param n/a
///
/// @return		true if successful
///
//****************************************************************************

bool CEProductionSocket::Create() {
	return CCESocket::Create(SOCK_STREAM, 512);

}							 //end Create()

//****************************************************************************
/// OnAccept - Override to handle accept notifications
///
/// @param[in]	serviceSocket - QAbstractSocket to attach to new class instance
///
/// @return		false if new socket not handled by handler thread
///
//****************************************************************************
bool CEProductionSocket::OnAccept(QAbstractSocket serviceSocket) {
	bool ret = true;
	AcceptProductionSocket(serviceSocket);
	return ret;
}							 //end OnAccept()

//****************************************************************************
/// Accept - Override to start socket listening routine
///
/// @param[in]	LocalPort - port to listen on
/// @param[in] maxConn - max pending incoming connections to hold before 
///  connections are refused
///
/// @return		true - accept successful
///
//****************************************************************************
bool CEProductionSocket::Accept(UINT LocalPort, int maxConn) {
	bool bRet = CCESocket::Accept(LocalPort, maxConn);
	return bRet;

}							 //end Accept()

//****************************************************************************
/// OnClose - handler override for socket close
///
/// @param[in] closeEvent - reason close has been called
///
/// @return		n/a
///
//****************************************************************************
void CEProductionSocket::OnClose(int closeEvent) {
}							 //end OnClose()

//****************************************************************************
/// Disconnect - disconnect from remote host
///
/// @param n/a
///
/// @return		n/a
///
//****************************************************************************
void CEProductionSocket::Disconnect() {
	CCESocket::Disconnect();
	qDebug("Disconnect called\n");

}							 //end Disconnect()

//****************************************************************************
/// OnReceive - Receives data from client
///
/// @param [in] buf  Data buffer read over the socket connection
/// @param [in] bytesRead Number of bytes read  
///
/// @return		bool - Returns true as this method is used
///
//****************************************************************************
bool CEProductionSocket::OnReceive(char *buf, int bytesRead) {
	bool retVal = false;
	int size = 0;
	char DataBuffer[1024];
	char *token, Parameter[4];
	//token = strtok(buf,"$");

	if (buf != NULL) {
		token = strtok(buf, "$");
		if (token != NULL) {
			strcpy(Parameter, token);
			token = strtok(NULL, "$");
			if (token != NULL) {
				strcpy(buf, token);

				switch (atoi(Parameter)) {
				case MODEL_NO: {
					QString   Modelno("");
					//If ModelNo is requested then modelno is sent using GetModel() API.
					Modelno = GetModelNumber(buf);
					wcstombs(DataBuffer, Modelno.GetBuffer(Modelno.size()), Modelno.size() + 1);
					Send(DataBuffer, sizeof(DataBuffer));
					break;
				}
				case SET_INFO: {
					SetProductionInfo(buf);
					break;
				}
					//case MODEL_TYPE:	//This code is for RDT, no longer required here.
					//	{
					//		//Get model Number of the Recorder
					//		QString  Modelno(QString   ::fromWCharArray(""));
					//		Modelno = GetModelNumber();
					//		wcstombs(DataBuffer,Modelno.GetBuffer(Modelno.size()),Modelno.size()+1);
					//		Send(DataBuffer,sizeof(DataBuffer));					
					//		break;
					//	}
				default:
					qDebug("Received Data is not a Model Number\n");
					break;
				}
			}
			retVal = true;
		}
	}
	return retVal;

}				//end OnReceive()

//****************************************************************************
/// GetModelNumber - Returns the Model Number
///
/// @param [in] buf  Sets the time and date in the recorder
/// @return		QString  - Returns the model number of the recorder
///
//****************************************************************************
QString   CEProductionSocket::GetModelNumber(char *buf) {
	// Get the Model Number from the Recorder.
	QString   Modelno = GetModelNumber();

	//Set the Time and Date of the recorder.
	SetDate(buf);

	return Modelno;

}				//end GetModelNumber()

//****************************************************************************
/// GetModelNumber - Returns the Model Number
///
/// @return		QString  - Returns the model number of the recorder
///
//****************************************************************************
QString   CEProductionSocket::GetModelNumber() {

	HRESULT hResult = S_OK;

	hResult = CoCreateInstance(CLSID_V6AppInterface, NULL, CLSCTX_INPROC_SERVER, IID_IV6AppInterface,
			(void**) &g_pV6AppInterface);
	// Fails to Create the Instance.
	if (FAILED(hResult)) {
		QString   szErr;
		if (CO_E_SERVER_EXEC_FAILURE == hResult) {
			szErr = "Failed to Connect with Recorder.- Firmware not running!";
		} else {
			szErr = "Failed to Connect with Recorder.";
		}
		MessageBox(NULL, szErr, L"Production Interface - Error", MB_OK | MB_TOPMOST);
		CoUninitialize();
		return invalid;
	} else {
		if (g_pV6AppInterface == NULL) {
			MessageBox(NULL, _T("Failed to Connect with Recorder."), L"Production Interface - Error",
					MB_OK | MB_TOPMOST);
			CoUninitialize();
			return invalid;
		}
	}
	hResult = g_pV6AppInterface->QueryInterface(IID_IV6TimeInterface, (void**) &g_pV6TimeInterface);

	VARIANT vBstrModelNumber;
	VariantInit(&vBstrModelNumber);

	// Get the Model Number from the Recorder.
	hResult = g_pV6AppInterface->GetModelNumber(&vBstrModelNumber);
	QString   Modelno = vBstrModelNumber.bstrVal;

	return Modelno;

}				//end GetModelNumber()

//****************************************************************************
/// SetDate - Sets the recorder date
///
/// @param [in] buf  Sets the time and date in the recorder
/// @return		bool - Returns true if time and date is set successfully
///
//****************************************************************************
bool CEProductionSocket::SetDate(char *buf) {
	char wcTime[50];
	char wcDate[50];
	char *token;
	token = strtok(buf, "#");
	strcpy(wcTime, token);
	token = strtok(NULL, "#");
	strcpy(wcDate, token);
	BOOL bResult = TRUE;
	HRESULT hResult = E_FAIL;
	CComBSTR bstrVal;

	VARIANT vTimeDate;
	VariantInit(&vTimeDate);
	vTimeDate.vt = VT_ARRAY | VT_VARIANT;

	// SafeArray Bounds Declaration.
	SAFEARRAYBOUND aDataItemBounds[1];
	aDataItemBounds[0].lLbound = 0;
	aDataItemBounds[0].cElements = 2;

	// Create the one dimensional Safe Array of type VARIANTS.
	vTimeDate.parray = SafeArrayCreate(VT_VARIANT, 1, aDataItemBounds);

	VARIANT vValue;
	VariantInit(&vValue);
	vValue.vt = VT_BSTR;

	bstrVal = wcTime;
	vValue.bstrVal = bstrVal;
	LONG lIndex = 0;
	SafeArrayPutElement(vTimeDate.parray, &lIndex, &vValue);

	vValue.vt = VT_BSTR;
	bstrVal = wcDate;
	vValue.bstrVal = bstrVal;
	lIndex = 1;
	SafeArrayPutElement(vTimeDate.parray, &lIndex, &vValue);

	hResult = g_pV6TimeInterface->SetTimeDate(vTimeDate);

	return true;

}				//end SetDate()

//****************************************************************************
/// SetProductionInfo - Sets the production info in the recorder.
///
/// @param [in] buf  Sets the Production Info in the recorder.
/// @return		 bool - Returns true if production info is set successfully
///
//****************************************************************************
bool CEProductionSocket::SetProductionInfo(char *buf) {
	HRESULT hResult = S_OK;
	USES_CONVERSION;
	char *token = NULL;
	QString   xml_modelNo;
	QString   xml_serialNo;
	QString   xml_salesOrder;
	QString   xml_born;
	QString   xml_keyNumber;
	QString   xml_IOTOP;
	QString   xml_IOBOT;
	QString   xml_Power;
	QString   xml_Memory;
	QString   xml_Credits;
	QString   xml_Options;
	QString   xml_OEM;
	QString   xml_Warran;
	QString   xml_Repair;
	QString   xml_Upgrade1;
	QString   xml_Upgrade2;
	QString   xml_Upgrade3;
	QString   xml_OEMSerNum;
	QString   xml_first_octect;
	QString   xml_second_octect;
	QString   xml_third_octect;

	token = strtok(buf, "#");
	xml_modelNo = token;

	token = strtok(NULL, "#");
	xml_serialNo = token;

	token = strtok(NULL, "#");
	xml_salesOrder = token;

	token = strtok(NULL, "#");
	xml_born = token;

	token = strtok(NULL, "#");
	xml_keyNumber = token;

	token = strtok(NULL, "#");
	xml_IOTOP = token;

	token = strtok(NULL, "#");
	xml_IOBOT = token;

	token = strtok(NULL, "#");
	xml_Power = token;

	token = strtok(NULL, "#");
	xml_Memory = token;

	token = strtok(NULL, "#");
	xml_Credits = token;

	token = strtok(NULL, "#");
	xml_Options = token;

	token = strtok(NULL, "#");
	xml_OEM = token;

	token = strtok(NULL, "#");
	xml_Warran = token;

	token = strtok(NULL, "#");
	xml_Repair = token;

	token = strtok(NULL, "#");
	xml_Upgrade1 = token;

	token = strtok(NULL, "#");
	xml_Upgrade2 = token;

	token = strtok(NULL, "#");
	xml_Upgrade3 = token;

	token = strtok(NULL, "#");
	xml_OEMSerNum = token;

	token = strtok(NULL, "#");
	xml_first_octect = token;

	token = strtok(NULL, "#");
	xml_second_octect = token;

	token = strtok(NULL, "#");
	xml_third_octect = token;

	CComBSTR bstrVal, bstrVals;
	VARIANT vXMLInfo;
	VariantInit(&vXMLInfo);
	vXMLInfo.vt = VT_ARRAY | VT_VARIANT;

	// SafeArray Bounds Declaration.
	SAFEARRAYBOUND aDataItemBounds[1];
	aDataItemBounds[0].lLbound = 0;
	aDataItemBounds[0].cElements = 22;

	// Create the one dimensional Safe Array of type VARIANTS.
	vXMLInfo.parray = SafeArrayCreate(VT_VARIANT, 1, aDataItemBounds);

	VARIANT vValue;
	VariantInit(&vValue);

	// Model Number. (Index=0)
	vValue.vt = VT_BSTR;
	bstrVal = xml_modelNo;
	vValue.bstrVal = bstrVal;
	LONG lIndex = 0;
	SafeArrayPutElement(vXMLInfo.parray, &lIndex, &vValue);
	lIndex++;

	// OEMSerial Number. (Index=1)
	vValue.vt = VT_BSTR;
	bstrVal = xml_serialNo;
	vValue.bstrVal = bstrVal;
	if (hResult = SafeArrayPutElement(vXMLInfo.parray, &lIndex, &vValue)) {
		bstrVals.Detach();
		VariantClear(&vValue);
		SafeArrayDestroy(vXMLInfo.parray);
		return false;
	}
	lIndex++;

	// Sales Order. (Index=2)
	vValue.vt = VT_BSTR;
	bstrVal = xml_salesOrder;
	vValue.bstrVal = bstrVal;
	if (hResult = SafeArrayPutElement(vXMLInfo.parray, &lIndex, &vValue)) {
		bstrVals.Detach();
		VariantClear(&vValue);
		SafeArrayDestroy(vXMLInfo.parray);
		return false;
	}
	lIndex++;

	// Born. (Index=3)
	vValue.vt = VT_BSTR;
	bstrVal = xml_born;
	vValue.bstrVal = bstrVal;
	if (hResult = SafeArrayPutElement(vXMLInfo.parray, &lIndex, &vValue)) {
		bstrVals.Detach();
		VariantClear(&vValue);
		SafeArrayDestroy(vXMLInfo.parray);
		return false;
	}
	lIndex++;

	// Keynumber. (Index=4)
	vValue.vt = VT_BSTR;
	bstrVal = xml_keyNumber;
	vValue.bstrVal = bstrVal;
	if (hResult = SafeArrayPutElement(vXMLInfo.parray, &lIndex, &vValue)) {
		bstrVals.Detach();
		VariantClear(&vValue);
		SafeArrayDestroy(vXMLInfo.parray);
		return false;
	}
	lIndex++;

	// IOTOP. (Index=5)
	vValue.vt = VT_BSTR;
	bstrVal = xml_IOTOP;
	vValue.bstrVal = bstrVal;
	if (hResult = SafeArrayPutElement(vXMLInfo.parray, &lIndex, &vValue)) {
		bstrVals.Detach();
		VariantClear(&vValue);
		SafeArrayDestroy(vXMLInfo.parray);
		return false;
	}
	lIndex++;

	// IOBOT. (Index=6)
	vValue.vt = VT_BSTR;
	bstrVal = xml_IOBOT;
	vValue.bstrVal = bstrVal;
	if (hResult = SafeArrayPutElement(vXMLInfo.parray, &lIndex, &vValue)) {
		bstrVals.Detach();
		VariantClear(&vValue);
		SafeArrayDestroy(vXMLInfo.parray);
		return false;
	}
	lIndex++;

	// Power. (Index=7)
	vValue.vt = VT_BSTR;
	bstrVal = xml_Power;
	vValue.bstrVal = bstrVal;
	if (hResult = SafeArrayPutElement(vXMLInfo.parray, &lIndex, &vValue)) {
		bstrVals.Detach();
		VariantClear(&vValue);
		SafeArrayDestroy(vXMLInfo.parray);
		return false;
	}
	lIndex++;

	// Memory. (Index=8)
	vValue.vt = VT_BSTR;
	bstrVal = xml_Memory;
	vValue.bstrVal = bstrVal;
	if (hResult = SafeArrayPutElement(vXMLInfo.parray, &lIndex, &vValue)) {
		bstrVals.Detach();
		VariantClear(&vValue);
		SafeArrayDestroy(vXMLInfo.parray);
		return false;
	}
	lIndex++;

	// Credits. (Index=9)
	vValue.vt = VT_BSTR;
	bstrVal = xml_Credits;
	vValue.bstrVal = bstrVal;
	if (hResult = SafeArrayPutElement(vXMLInfo.parray, &lIndex, &vValue)) {
		bstrVals.Detach();
		VariantClear(&vValue);
		SafeArrayDestroy(vXMLInfo.parray);
		return false;
	}
	lIndex++;

	// Options. (Index=10)
	vValue.vt = VT_BSTR;
	bstrVal = xml_Options;
	vValue.bstrVal = bstrVal;
	if (hResult = SafeArrayPutElement(vXMLInfo.parray, &lIndex, &vValue)) {
		bstrVals.Detach();
		VariantClear(&vValue);
		SafeArrayDestroy(vXMLInfo.parray);
		return false;
	}
	lIndex++;

	// OEM. (Index=11)
	vValue.vt = VT_BSTR;
	bstrVal = xml_OEM;
	vValue.bstrVal = bstrVal;
	if (hResult = SafeArrayPutElement(vXMLInfo.parray, &lIndex, &vValue)) {
		bstrVals.Detach();
		VariantClear(&vValue);
		SafeArrayDestroy(vXMLInfo.parray);
		return false;
	}
	lIndex++;

	// Warranty.(Index=12)
	vValue.vt = VT_UI2;
	vValue.uiVal = _ttoi(xml_Warran);
	if (hResult = SafeArrayPutElement(vXMLInfo.parray, &lIndex, &vValue)) {
		bstrVals.Detach();
		VariantClear(&vValue);
		SafeArrayDestroy(vXMLInfo.parray);
		return false;
	}
	lIndex++;

	// Repaired (Index=13)
	vValue.vt = VT_UI2;
	vValue.uiVal = _ttoi(xml_Repair);
	if (hResult = SafeArrayPutElement(vXMLInfo.parray, &lIndex, &vValue)) {
		bstrVals.Detach();
		VariantClear(&vValue);
		SafeArrayDestroy(vXMLInfo.parray);
		return false;
	}
	lIndex++;

	// Upgrade1 (Index=14)
	vValue.vt = VT_UI2;
	vValue.uiVal = _ttoi(xml_Upgrade1);
	if (hResult = SafeArrayPutElement(vXMLInfo.parray, &lIndex, &vValue)) {
		bstrVals.Detach();
		VariantClear(&vValue);
		SafeArrayDestroy(vXMLInfo.parray);
		return false;
	}
	lIndex++;

	// Upgrade2 (Index=15)
	vValue.vt = VT_UI2;
	vValue.uiVal = _ttoi(xml_Upgrade2);
	if (hResult = SafeArrayPutElement(vXMLInfo.parray, &lIndex, &vValue)) {
		bstrVals.Detach();
		VariantClear(&vValue);
		SafeArrayDestroy(vXMLInfo.parray);
		return false;
	}
	lIndex++;

	// Upgrade3 (Index=16)
	vValue.vt = VT_UI2;
	vValue.uiVal = _ttoi(xml_Upgrade3);
	if (hResult = SafeArrayPutElement(vXMLInfo.parray, &lIndex, &vValue)) {
		bstrVals.Detach();
		VariantClear(&vValue);
		SafeArrayDestroy(vXMLInfo.parray);
		return false;
	}
	lIndex++;

	// Serial Number. (Index=17)
	vValue.vt = VT_UI4;
	vValue.ulVal = _ttol(xml_OEMSerNum);
	if (hResult = SafeArrayPutElement(vXMLInfo.parray, &lIndex, &vValue)) {
		bstrVals.Detach();
		VariantClear(&vValue);
		SafeArrayDestroy(vXMLInfo.parray);
		return false;
	}
	lIndex++;

	// MAC-Address - First Octet.(Index = 18)
	vValue.vt = VT_BSTR;
	bstrVals = xml_first_octect;
	vValue.bstrVal = bstrVals;
	if (hResult = SafeArrayPutElement(vXMLInfo.parray, &lIndex, &vValue)) {
		bstrVals.Detach();
		VariantClear(&vValue);
		SafeArrayDestroy(vXMLInfo.parray);
		return false;
	}
	lIndex++;

	// MAC-Address - Second Octet.(Index = 19)
	vValue.vt = VT_BSTR;
	bstrVals = xml_second_octect;
	vValue.bstrVal = bstrVals;
	if (hResult = SafeArrayPutElement(vXMLInfo.parray, &lIndex, &vValue)) {
		bstrVals.Detach();
		VariantClear(&vValue);
		SafeArrayDestroy(vXMLInfo.parray);
		return false;
	}
	lIndex++;

	// MAC-Address - Third Octet.(Index = 20)
	vValue.vt = VT_BSTR;
	bstrVals = xml_third_octect;
	vValue.bstrVal = bstrVals;
	if (hResult = SafeArrayPutElement(vXMLInfo.parray, &lIndex, &vValue)) {
		bstrVals.Detach();
		VariantClear(&vValue);
		SafeArrayDestroy(vXMLInfo.parray);
		return false;
	}

	hResult = g_pV6AppInterface->SetProductionInformation(vXMLInfo);
	if (FAILED(hResult)) {
		// MessageBox and Log Entry.
		//MessageBox (NULL, _T("Failed to Set the Production Info") , L"Production Interface - Error", MB_OK | MB_TOPMOST );
		LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "Failed to update the production information");
		return false;
	} else {
		//MessageBox ( NULL,_T("Recorder configured OK.") , L"Production Interface.",MB_OK | MB_TOPMOST );
		LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_INFO, L"Production information updated successfully");

		if (pSYSTEM_INFO->SoftwareUpdater()->IsCertPackageAvailable(IDS_INTERNAL_SD) == TRUE) {
			InstallDeviceCertificate();
		}
	}

	// Set the Recorder into the Test Mode.
	hResult = g_pV6AppInterface->SetRecorderInTestMode();

	return true;

} //end SetProductionInfo()

//****************************************************************************
/// Send - Sends the Model Number to the Production Interface tool
///
/// @param [in] buf - Holds the model number of the recorder
/// @return		 int - Returns number of bytes of data sent successfully
///
//****************************************************************************
int CEProductionSocket::Send(const char *buf, int len) {
	return SendProductionInfo(buf, len);

} //end Send()

//****************************************************************************
/// InstallDeviceCertificate - Installs Device Certificate.
///
//****************************************************************************
void CEProductionSocket::InstallDeviceCertificate() {
	// load CertInstall.DLL
	int iErrValue = 0;
	QLibrary hCertInstall = LoadLibrary(CERT_IMPORT_DLL);
	int iRet = E_FAIL;

	if (hCertInstall) {
#ifdef UNDER_CE
		CHECKROOTCERTIFICATE CheckRootCertificate = (CHECKROOTCERTIFICATE)GetProcAddress(hCertInstall, _T("CheckRootCertificate"));
	#else
		CHECKROOTCERTIFICATE CheckRootCertificate = (CHECKROOTCERTIFICATE) GetProcAddress(hCertInstall,
				"CheckRootCertificate");
#endif
		if (CheckRootCertificate) {
			OutputDebugString(_T("CheckRootCertificate..."));
			iRet = CheckRootCertificate(ROOT_CERT_CN) || CheckRootCertificate(ROOT_CERT_CN_OLD); // check for old CN value also
			if (iRet == 1) {
				TCHAR deviceSubjectName[MAX_PATH];
				QString   strCertSub;
				strCertSub.asprintf(_T("XS-%lu"), pGlbSysInfo->GetSerialNumber());
				_tcscpy_s(deviceSubjectName, 50, strCertSub.toLocal8Bit().data());
#ifdef UNDER_CE
				iRet = pGlbDal->CheckForServerCertificate(deviceSubjectName);
				#endif
			}
			if (iRet == 1) {
				// Root certificate is already installed.
				LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_ERROR, _T("Secure Self Certificates already installed."));
				iErrValue = 0;
			} else {
				if (pSYSTEM_INFO->SoftwareUpdater()->IsCertPackageAvailable(IDS_INTERNAL_SD) == TRUE) {
					OutputDebugString(_T("Secure WSD Certificate package found!"));

					// Package found. Install
#ifdef UNDER_CE
						EXTRACTANDINSTALLCERTCAB InstallCab = (EXTRACTANDINSTALLCERTCAB)GetProcAddress(hCertInstall, L"ExtractAndInstallCertCab");
					#else
					EXTRACTANDINSTALLCERTCAB InstallCab = (EXTRACTANDINSTALLCERTCAB) GetProcAddress(hCertInstall,
							"ExtractAndInstallCertCab");
#endif

					if (InstallCab) {
						OutputDebugString(_T("Secure WSD Installing certs....."));
						iRet = InstallCab((LPWSTR) pSYSTEM_INFO->SoftwareUpdater()->GetCertFileName());
					} else {
						//installing certs failed...
						iErrValue = 1;
					}
					// After searching and extract and install calls....
					if (ERROR_SUCCESS == iRet) {
						CV6MessageBoxDlg InstallCert(_T("Production Utility"),
								_T(
										"Recorder configured and Certificates installed successfully.\n Press OK to continue"),
								AfxGetApp()->m_pMainWnd, _T("OK"));
						// Certificate installed succesfully. 
						LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_INFORMATION,
								_T("Secure Self Certificates installed successfully."));
#ifdef UNDER_CE
						//Backup the WSD Certificates in Flash memory
						pDALGLB->BackupWSDCertificateToFlash();
#endif		
					} //if ( ERROR_SUCCESS == iRet )
					else {
						// cert installation failed
						iErrValue = 2;
					}

				} //if(pSYSTEM_INFO->SoftwareUpdater()->IsCertPackageAvailable(IDS_INTERNAL_SD) == TRUE )
				else {
					// Certificate package not found on external media
					iErrValue = 3;
				}
			} //else, if (iRet == 1)
		} //if (CheckRootCertificate)
		else {
			//Certificate checking on store failed
			iErrValue = 4;
		}
	} //if ( hCertInstall )
	else {
		// Unable to load critical component : CertInstall.dll
		iErrValue = 5;
	}

	// Free the CertInstall.DLL
	FreeLibrary(hCertInstall);

	//check for errors, if any
	if (iErrValue > 0) {
		LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_ERROR, _T("Secure Self Certificates installation failed."));

		//Show an indication to the user that certificate installation failed.
		CV6MessageBoxDlg LoadCertFailed(_T("Load Certificates"),
				_T("Secure Self Certificates installation failed. Please install manually."), AfxGetApp()->m_pMainWnd,
				_T("OK"));
		LoadCertFailed.exec();
		iErrValue = 0;
	}
}

int CEProductionSocket::SendProductionInfo(const char *buf, int len) {
	int dataPtr = 0;
	int sentBytes = 0;

	if (!m_bWSAStarted)
		return QAbstractSocket_ERROR;
	//Have we a valid buffer?
	if (!buf || len <= 0) {
		m_errorCode = WSAEFAULT;
		return QAbstractSocket_ERROR;
	}
	sentBytes = send(m_productionSocket, &buf[dataPtr], len, 0);
	if (sentBytes == QAbstractSocket_ERROR) {
		m_errorCode = WSAGetLastError();
		return QAbstractSocket_ERROR;
	}
	dataPtr += sentBytes;
	len -= sentBytes;
	return dataPtr;
}

void CEProductionSocket::AcceptProductionSocket(QAbstractSocket serviceSocket) {
	m_productionSocket = serviceSocket;
	m_productionSocketState = CONNECTED;
	m_productionReadThread = CreateThread(NULL, 0, StartProdInfoReadThread, this, 0, NULL);
}

DWORD WINAPI CEProductionSocket::StartProdInfoReadThread(LPVOID pParam) {
	CEProductionSocket *parent = (CEProductionSocket*) pParam;

	parent->ReadProdInfoThread();

	return 0;
}

//Reads the data to be set from the Production Interface tool
void CEProductionSocket::ReadProdInfoThread() {
	int bytesRead = 0;
	int bufSize = 0;
	char *buf = NULL;
	bufSize = m_recvBufSize;
	if (buf == NULL) {
		buf = new char[bufSize];
	}
	m_productionReadThreadState = RUNNING;
	do {
		memset(buf, 0, bufSize);
		//PSR - Fix 1-3H6YQ87 Recorder showing WDT17 Errors messages when accessed through Remote Display Tool begin
		bytesRead = recv(m_productionSocket, buf, bufSize, 0);

		//Check if the socket is closed other end and we are just reading with zero bytes
		if (bytesRead <= 0) {
			//Clear the buf
			if (NULL != buf) {
				delete[] buf;
				buf = NULL;
			}
			//The socket closed other end so no need of this thread
			m_productionReadThreadState = CLOSED;
			break;
		} else {
			OnReceive(buf, bytesRead);
		}
		bytesRead = 0;
		//Leave room to other threads on continuous recieving
		sleep(10);
		//PSR - Fix 1-3H6YQ87 Recorder showing WDT17 Errors messages when accessed through Remote Display Tool end
	} while (m_productionReadThreadState == RUNNING);

	if (m_productionSocketState > DISCONNECTING) {
		if (NULL != buf) {
			delete[] buf;
			buf = NULL;
		}

		if (m_productionSocket != INVALID_SOCKET) {
			shutdown(m_productionSocket, SD_BOTH);
			closesocket(m_productionSocket);
			m_productionSocket = INVALID_SOCKET;
		}

		m_productionSocketState = NONE;
	}

	if (NULL != m_productionReadThread) {
		//No need to close the mutex in Qt
		m_productionReadThread = NULL;
	}
}

/****************************************************************************

 //    COPYRIGHT (c) 2020
 //   HONEYWELL INTERNATIONAL INC.
 //   ALL RIGHTS RESERVED

 // Legal rights of Honeywell Inc. in this software is distinct from
 // ownership of any medium in which the software is embodied. 
 // Copyright notices must be reproduced in any copies authorized by 
 // Honeywell International Inc.
 /*****************************************************************************/

#include <stdio.h>
#include "V6CryptoHash.h"
#include "FolderFilesHashUtility.h"
#include <string>
#include <vector>
#include <stack>
#include <map>
#include <iostream>

using namespace std;

#define SEPARATOR "\\"

#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif

bool CFolderFilesHashUtility::buildHashFile(TCHAR *input_dir_name, TCHAR *hash_file_name) {
	TCHAR path[FILENAME_MAX];
	vector < wstring > files;
	bool isHashFileGenerated = false;

	_tcscpy(path, input_dir_name);
	if (path[_tcslen(path) - 1] == SEPARATOR[0])
		path[_tcslen(path) - 1] = '\0';
	wstring wfilename(&hash_file_name[0]);
	string sfilename(wfilename.begin(), wfilename.end());
#ifndef IS_BOOTLACE_APP
#ifndef UNDER_CE 
	remove(sfilename.c_str());
#endif
#endif

	if (listFiles(&input_dir_name[0], L"*", files)) {
		isHashFileGenerated = processFiles(files, &hash_file_name[0]);
	} else {
		isHashFileGenerated = false;
	}
	return isHashFileGenerated;
}

bool CFolderFilesHashUtility::processFiles(vector<wstring> &strwFiles, wstring strwHashFile) {
	std::string hash;
	v6crypto::errorinfo_t lasterror;
	std::string strHashFile(strwHashFile.begin(), strwHashFile.end());
	FILE *hash_file = fopen(strHashFile.c_str(), "w");
	if (NULL == hash_file) {
		return FALSE;
	}

	for (vector<wstring>::iterator it = strwFiles.begin(); it != strwFiles.end(); ++it) {
		v6crypto::sha256_helper_t hhelper;
		std::wstring wfilepath(it->c_str());
		std::string sfilepath(wfilepath.begin(), wfilepath.end());
		hash = hhelper.hexdigestfile(sfilepath);
		fprintf(hash_file, "%s %s\n", hash.c_str(), sfilepath.c_str());
	}

	fclose(hash_file);

	v6crypto::sha256_helper_t hhelper;
	hash = hhelper.hexdigestfile(strHashFile.c_str());
	hash_file = fopen(strHashFile.c_str(), "a");
	if (NULL == hash_file) {
		return FALSE;
	}
	fprintf(hash_file, "%s", hash.c_str());
	fclose(hash_file);
	return TRUE;
}

bool CFolderFilesHashUtility::listFiles(wstring strwPath, wstring strwMask, vector<wstring> &strwFiles) {
	HANDLE hindexOf = INVALID_HANDLE_VALUE;
	WIN32_FIND_DATA ffd;
	wstring spec;
	spec.clear();
	spec = strwPath + L"\\" + strwMask;
	hindexOf = indexOfFirstFile(spec.c_str(), &ffd);
	if (hindexOf == INVALID_HANDLE_VALUE) {
		return false;
	}

	do {
		if (wcscmp(ffd.cFileName, L".") != 0 && wcscmp(ffd.cFileName, L"..") != 0) {
			if (ffd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
				//not considering directories
			} else {
				strwFiles.push_back(strwPath + L"\\" + ffd.cFileName);
			}
		}
	} while (indexOfNextFile(hindexOf, &ffd) != 0);

	if (GetLastError() != ERROR_NO_MORE_FILES) {
		indexOfClose(hindexOf);
		return false;
	}

	indexOfClose(hindexOf);
	hindexOf = INVALID_HANDLE_VALUE;

	return true;
}

bool CFolderFilesHashUtility::checkHashFile(TCHAR *HashFilePath, bool isV6binaries) {
	try {
		FILE *HashFile = NULL;
		std::map < std::string, std::string > mFileHashForFile;
		wstring wHashFilePath(&HashFilePath[0]);
		string sHashFilePath(wHashFilePath.begin(), wHashFilePath.end());
		HashFile = fopen(sHashFilePath.c_str(), "r");
		if (HashFile == NULL) {
			return FALSE;
		}
		//Extract hash file directory path.

		char sep = '\\';
		string sDirectoryPath;
		size_t i = sHashFilePath.rfind(sep, sHashFilePath.length());
		if (i != string::npos) {
			sDirectoryPath = sHashFilePath.substr(0, i + 1);
		}
		string sHashFileHash;
		//read the file contents and store it in vectors.	
		for (;;) {
			char log_path[FILENAME_MAX];
			char log_hash[FILENAME_MAX];
			memset(log_path, '\0', MAX_PATH);
			memset(log_hash, '\0', MAX_PATH);
			int result = fscanf(HashFile, "%s %s", log_hash, log_path);
			if (result < 2) {
				sHashFileHash = &log_hash[0];
				break;
			}
			mFileHashForFile.insert(
					pair<std::string, std::string>(getCurrentBinariesPathName(&log_path[0], sDirectoryPath),
							&log_hash[0]));
		}
		fclose(HashFile);

		//read the hash value of the hash file and check hash file integrity.
		v6crypto::sha256_helper_t hhelper;
		string hashCalculated = hhelper.hexdigestfile(sHashFilePath, false, true);
		if ((hashCalculated.compare(sHashFileHash)) == 0) {
			if (isV6binaries) {
				//To check only specific binaries of V6App application.	
				std::vector < std::string > vV6FileNames;
				vV6FileNames.push_back("catmgr.exe");
				vV6FileNames.push_back("ccm.dll");
				vV6FileNames.push_back("CMM.dll");
				vV6FileNames.push_back("HtDataServer.exe");
				vV6FileNames.push_back("LCM.dll");
				vV6FileNames.push_back("MbusMaster.dll");
				vV6FileNames.push_back("MbusSlave.dll");
				vV6FileNames.push_back("OpcUaServer.exe");
				vV6FileNames.push_back("PMM.dll");
				vV6FileNames.push_back("RemoteDisplayServer.exe");
				vV6FileNames.push_back("RTFControl.dll");
				vV6FileNames.push_back("ScriptServices.dll");
				vV6FileNames.push_back("TraceFile.dll");
				vV6FileNames.push_back("V6App.exe");

				vector<std::string>::iterator itr;
				map<std::string, std::string>::iterator fileitr;
				for (itr = vV6FileNames.begin(); itr != vV6FileNames.end(); itr++) {
					std::string filename = *itr;
					std::string directoryPath = sDirectoryPath;
					std::string filepath = directoryPath.append(filename);
					hashCalculated = hhelper.hexdigestfile(filepath);
					fileitr = mFileHashForFile.find(filepath);
					if (fileitr != mFileHashForFile.end()) {
						string hash = fileitr->second;
						if (hashCalculated.compare(hash) != 0) {
							return FALSE;
						}
					}
				}
			} else {
				map<std::string, std::string>::iterator itr;
				for (itr = mFileHashForFile.begin(); itr != mFileHashForFile.end(); ++itr) {
					v6crypto::sha256_helper_t hhelper;
					hashCalculated = hhelper.hexdigestfile(itr->first);
					if (hashCalculated.compare(itr->second) != 0) {
						return FALSE;
					}
				}

			}
		} else {
			return FALSE;
		}
	} catch (...) {
		return FALSE;
	}

	return TRUE;
}

std::string CFolderFilesHashUtility::getCurrentBinariesPathName(const std::string &sFilePath,
		std::string sDirectoryPath) {
	char sep = '\\';
	string sFileName;
	size_t i = sFilePath.rfind(sep, sFilePath.length());
	if (i != string::npos) {
		sFileName = sFilePath.substr(i + 1, sFilePath.length() - i);
		string sNewFilePath = sDirectoryPath.append(sFileName);
		return sNewFilePath;
	}

	return ("");
}
std::string CFolderFilesHashUtility::getV6AppHashCode(TCHAR *HashFilePath) {
	string hash = "Invalid Hash Code";
	try {
		FILE *HashFile = NULL;
		std::map < std::string, std::string > mFileHashForFile;
		wstring wHashFilePath(&HashFilePath[0]);
		string sHashFilePath(wHashFilePath.begin(), wHashFilePath.end());
		HashFile = fopen(sHashFilePath.c_str(), "r");

		if (HashFile == NULL) {
			return hash;
		}
		//Extract hash file directory path.

		char sep = '\\';
		string sDirectoryPath;
		size_t i = sHashFilePath.rfind(sep, sHashFilePath.length());
		if (i != string::npos) {
			sDirectoryPath = sHashFilePath.substr(0, i + 1);
		}
		string sHashFileHash;
		//read the file contents and store it in vectors.	
		for (;;) {
			char log_path[FILENAME_MAX];
			char log_hash[FILENAME_MAX];
			memset(log_path, '\0', MAX_PATH);
			memset(log_hash, '\0', MAX_PATH);
			int result = fscanf(HashFile, "%s %s", log_hash, log_path);
			if (result < 2) {
				sHashFileHash = &log_hash[0];
				break;
			}
			//Get for the V6App Code
			string directoryPath = sDirectoryPath;
			string filepath = directoryPath.append("V6App.exe");
			if (filepath.compare(getCurrentBinariesPathName(&log_path[0], sDirectoryPath)) == 0) {
				hash = &log_hash[0];
				break;
			}
		}

		fclose(HashFile);
	} catch (...) {
	}
	return hash;
}

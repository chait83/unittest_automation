#ifndef __CERT_SUBJECT_H_INCLUDED__
#define __CERT_SUBJECT_H_INCLUDED__

#pragma once 

//**Class*********************************************************************
///
/// @brief CertSubject Store class
/// 
///
//****************************************************************************

class CCertSubjectsStore {
public:
	CCertSubjectsStore();
	~CCertSubjectsStore();

	BOOL CreateandUpdateRootSubjectKey(const LPCTSTR lRootSubjectName);
	BOOL CreateandUpdateServerSubjectKey(const LPCTSTR lDeviceSubjectName);
	BOOL CreateandUpdatePubRootCerticateKey(const LPCTSTR bPubKey);
	QString   GetRootSubjectKey();
	QString   GetServerSubjectKey();
	QString   GetPubRootCertificateKey();
	BOOL CreateandUpdateEmailRootSubjectKey(const LPCTSTR lRootEmailSubjectName);
	QString   GetEmailRootSubjectKey();

};

#endif // __CERT_SUBJECT_H_INCLUDED__

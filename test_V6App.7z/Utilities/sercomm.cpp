// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Utility
/// @n Filename: sercomm.cpp
/// @n Desc:	 Simple Serial communications class for Windows
///						
// 
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  19  Stability Project 1.14.1.3 7/2/2011 5:01:15 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  18  Stability Project 1.14.1.2 7/1/2011 4:38:55 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  17  Stability Project 1.14.1.1 3/17/2011 3:20:46 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  16  Stability Project 1.14.1.0 2/15/2011 3:03:55 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// ****************************************************************

#include "sercomm.h"

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif

//**********************************************************************
///
/// CSerialComms constructor
/// 
//**********************************************************************
CSerialComms::CSerialComms() {
//	qDebug("Creating new CSerialComms instance\n");

	m_hPort = NULL;
}

//**********************************************************************
///
/// CSerialComms destructor
/// 
//**********************************************************************
CSerialComms::~CSerialComms() {
//	qDebug("Deleting new CSerialComms instance\n");

	Close();
}

#define COMM_PORT_NAME_LEN		10
#define COMM_STATE_FAILURE		0

//**********************************************************************
///
/// Open a serial communication port
///
/// @param[in]	commPort - Comms port to open, see T_COMMPORT enum in sercomm.h
/// @param[int]	baudRate - Baud rate to set port to, see T_BAUDRATE enum in sercomm.h
/// @return		T_SERCOM_RESULT return result, see T_SERCOM_RESULT enum in sercomm.h
/// 
//**********************************************************************
T_SERCOM_RESULT CSerialComms::Open(T_COMMPORT commPort, T_BAUDRATE baudRate) {
	T_SERCOM_RESULT retVal = SC_OKAY;

	Close();		// Make sure port is closed

	// Generate comport name COM1: COM2: etc...
	WCHAR commPortName[COMM_PORT_NAME_LEN];
	swprintf(commPortName, L"\\\\.\\COM%d", commPort);

	// Open com port
	m_hPort = CreateFile(commPortName, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, 0, NULL);

	if (m_hPort == INVALID_HANDLE_VALUE) {
		retVal = SC_FAILED;
	} else {
		qDebug("COMPORT Opened on COM:%d \n ", commPort);

		// Initialize the DCBlength member. 
		m_DCB.DCBlength = sizeof(QIODevice);

		// Get the default port setting information.
		if (GetCommState(m_hPort, &m_DCB) != COMM_STATE_FAILURE) {
			// Change the QIODevice structure settings.
			m_DCB.BaudRate = baudRate;					// Set to specified baud rate 
			m_DCB.fBinary = TRUE;						// Binary mode; no EOF check 
			m_DCB.fParity = FALSE;						// Enable parity checking 
			m_DCB.fOutxCtsFlow = FALSE;					// No CTS output flow control 
			m_DCB.fOutxDsrFlow = FALSE;					// No DSR output flow control 
			m_DCB.fDtrControl = DTR_CONTROL_DISABLE;	// DTR flow control disabled
			m_DCB.fDsrSensitivity = FALSE;				// DSR sensitivity 
			m_DCB.fTXContinueOnXoff = TRUE;				// XOFF continues Tx 
			m_DCB.fOutX = FALSE;						// No XON/XOFF out flow control 
			m_DCB.fInX = FALSE;							// No XON/XOFF in flow control 
			m_DCB.fErrorChar = FALSE;					// Disable error replacement 
			m_DCB.fNull = FALSE;						// Disable null stripping 
			m_DCB.fRtsControl = RTS_CONTROL_DISABLE;	// No RTS flow control 
			m_DCB.fAbortOnError = FALSE;				// Do not abort reads/writes on error
			m_DCB.ByteSize = 8;							// Number of bits/byte, 4-8 
			m_DCB.Parity = NOPARITY;					// 0-4=no,odd,even,mark,space 
			m_DCB.StopBits = ONESTOPBIT;				// 0,1,2 = 1, 1.5, 2 

			// Configure the port according to the specifications of the QIODevice 
			// structure.
			if (!SetCommState(m_hPort, &m_DCB)) {
				HandleError(L"Open SetCommState");
				retVal = SC_FAILED;
				///@todo Improve error handling
			}
		} else {
			HandleError(L"Open GetCommState");
			retVal = SC_FAILED;
			///@todo Improve error handling
		}

		if (retVal == SC_OKAY) {
			// Retrieve the time-out parameters for all read and write operations
			// on the port. 
			if (GetCommTimeouts(m_hPort, &m_timeOuts) != COMM_STATE_FAILURE) {

				// Change the COMMTIMEOUTS structure settings.
				m_timeOuts.ReadIntervalTimeout = 10;
				m_timeOuts.ReadTotalTimeoutMultiplier = 0;
//				m_timeOuts.ReadTotalTimeoutMultiplier = MAXDWORD; 
				m_timeOuts.ReadTotalTimeoutConstant = 500;
				m_timeOuts.WriteTotalTimeoutMultiplier = 0;
				m_timeOuts.WriteTotalTimeoutConstant = 0;

				// Set the time-out parameters for all read and write operations
				// on the port. 
				if (SetCommTimeouts(m_hPort, &m_timeOuts) == COMM_STATE_FAILURE) {
					// Could not set the time-out parameters.
					HandleError(L"Open SetCommTO");
					retVal = SC_FAILED;
				}

				ClearAllBuffers();
			} else {
				// Could not set the time-out parameters.
				HandleError(L"Open GetCommTO");
				retVal = SC_FAILED;
			}

		}
	}
	return retVal;
}

//**********************************************************************
///
/// Read data from serail communication port
///
/// @param[out]	pBuffer - Pointer to buffer to read data into
/// @param[int,out]	pSize - ptr to Max size data to read, will be set to number of bytes read.
/// @return		T_SERCOM_RESULT return result, see T_SERCOM_RESULT enum in sercomm.h
/// 
//**********************************************************************
T_SERCOM_RESULT CSerialComms::Read(void *pBuffer, ULONG *pSize) {
	DWORD errors = 0;
	T_SERCOM_RESULT retVal = SC_OKAY;
	ClearCommError(m_hPort, &errors, &m_cstat);
//	if( m_cstat.cbInQue > 0 )		// Should not need this as readfile will timeout, so we could miss data using this check.
//	{
	if (ReadFile(m_hPort, pBuffer, *pSize, pSize, NULL) == FALSE) {
		HandleError(L"Read");
		retVal = SC_FAILED;
	}

//	}
	return retVal;
}

//**********************************************************************
///
/// Write data to serial communication port
///
/// @param[in]	pBuffer - Pointer to buffer of data to write
/// @param[int,out]	pSize - ptr to Max size data to written, will be set to number of bytes written.
/// @return		T_SERCOM_RESULT return result, see T_SERCOM_RESULT enum in sercomm.h
/// 
//**********************************************************************
T_SERCOM_RESULT CSerialComms::Write(void *pBuffer, ULONG *pSize) {
	DWORD errors = 0;
	T_SERCOM_RESULT retVal = SC_OKAY;
	// Check if there is any data current in the read buffer?
	ClearCommError(m_hPort, &errors, &m_cstat);
	if (m_cstat.cbInQue > 0) {
		// There is, so clear out as we are writing
		ClearAllBuffers();
	}
	if (WriteFile(m_hPort, pBuffer, *pSize, pSize, NULL) == FALSE) {
		HandleError(L"Write");
		retVal = SC_FAILED;
	}
	return retVal;
}

//**********************************************************************
///
/// Clears all internal comms buffers and and pending operations
///
/// @return		T_SERCOM_RESULT return result, see T_SERCOM_RESULT enum in sercomm.h
/// 
//**********************************************************************
T_SERCOM_RESULT CSerialComms::ClearAllBuffers() {
	T_SERCOM_RESULT retVal = SC_OKAY;

	if (PurgeComm(m_hPort, PURGE_TXABORT | PURGE_RXABORT | PURGE_TXCLEAR | PURGE_RXCLEAR) == FALSE) {
		HandleError(L"ClearBuffer");
		retVal = SC_FAILED;
	}

	return retVal;
}

//**********************************************************************
///
/// General error handler to tarce out comms errors and reset appropriate 
///
/// @return		nothing
/// 
//**********************************************************************
void CSerialComms::HandleError(QString pRoutine) {
	DWORD LastError = GetLastError();
	DWORD errors = 0;
	ClearCommError(m_hPort, &errors, &m_cstat);

	qDebug((L"S COMMS: %s failed with error %d CCE(%x) InQueue(%d)\n"), pRoutine, GetLastError(), m_cstat.cbInQue);

}

//**********************************************************************
///
/// Close the port if open
///
/// @return		T_SERCOM_RESULT return result, see T_SERCOM_RESULT enum in sercomm.h
/// 
//**********************************************************************
T_SERCOM_RESULT CSerialComms::Close() {
	if (m_hPort != NULL)
		//No need to close the mutex in Qt
	m_hPort = NULL;

	return SC_OKAY;
}

//**********************************************************************
///
/// Sends a test string of hello to specified com port at 9600 for
/// specified number of times at 1 second intervals
///
/// @return		T_SERCOM_RESULT return result, see T_SERCOM_RESULT enum in sercomm.h
/// 
//**********************************************************************
void CSerialComms::TestHelloToPortAt9600(T_COMMPORT commPort, int times) {
	ULONG size;
	CHAR buffer[100];

#if _MSC_VER < 1400 
	sprintf(buffer, "Hello\n\r");
#else
	sprintf_s(buffer, 100, "Hello\n\r");
#endif

	if (Open(commPort, BR_9600) == SC_FAILED) {
		qDebug((L"S COMMS: Open Failed on COM%d: \n"), commPort);
		return;
	}
	for (int i = 0; i < times; i++) {
		size = 7;
		if (Write(buffer, &size) == SC_FAILED) {
			qDebug((L"S COMMS: Write %d failed on COM%d: \n"), i, commPort);
			Close();
			return;
		}
		qDebug((L"S COMMS: Write HELLO(%d) on COM%d: \n"), i, commPort);
		sleep(1000);
	}
	Close();
}

//////////////////////////////////////////////////////////////////////
/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 Utilities
/// @n Registry.cpp
/// @n Registry wrapper class.
/// @author MM
/// @date 25/05/2005
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 03-Sep-15	Rajanbabu M		Updated Registry Entry AutoUpdate for SNTP
// 35	Stability Project 1.29.1.4	7/2/2011 5:00:19 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 34	Stability Project 1.29.1.3	7/1/2011 4:38:49 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 33	Stability Project 1.29.1.2	3/17/2011 3:20:41 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 32	Stability Project 1.29.1.1	2/15/2011 3:03:50 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////

#include "Registry.h"

#include "V6defines.h"
#include "V6globals.h"
#include "V6Config.h"
#include "GeneralSetupConfig.h"
#include "CommsSetupConfig.h"
#include "StringUtils.h"

//PSR _SNTP fix begin
#ifdef UNDER_CE
#include "Devload.h" 
#endif
//PSR _SNTP fix end

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif

//****************************************************************************
/// Registry key wrapper: class constructor
///
/// @note --- Delete if not requried ---
//****************************************************************************
CRegistryKey::CRegistryKey() {
//	m_pDAL = NULL;
	m_Key = NULL;
}

//****************************************************************************
/// Registry key wrapper: class destructor
///
/// @note --- Delete if not requried ---
//****************************************************************************
CRegistryKey::~CRegistryKey() {
	if (NULL != m_Key)
		Close();
}

//****************************************************************************
/// Registry key wrapper: Initialise if required
///
/// @note --- Delete if not requried ---
//****************************************************************************
void CRegistryKey::Initialise() {
//	if ( NULL == m_pDAL )
//	{
//		m_pDAL = CDeviceAbstraction::GetHandle();
//		m_pDAL->Initialise();
//	}
}

//****************************************************************************
/// Registry key wrapper: create new registry key
///
/// @param[in]	Name
///
/// @return		TRUE if all OK, else FALSE, use GetLastError() for an error code
///
/// @note For a CE build all keys are created under HKEY_LOCAL_MACHINE, 
/// for a PC build all keys are created under HKEY_CURRENT_USER\Honeywell
//****************************************************************************
BOOL CRegistryKey::CreateKey(const QString   const Name) {
	BOOL bResult = TRUE;
	WCHAR FullKey[MAX_PATH];

	Initialise();

#if _MSC_VER < 1400 
	wcscpy(FullKey, pDALGLB->BaseRegistryKey());
	wcscat(FullKey, Name);

#else
	wcscpy_s( FullKey, MAX_PATH, pDALGLB->BaseRegistryKey() );
	wcscat_s( FullKey, MAX_PATH, Name );

#endif

	if (RegCreateKeyEx( BASE_KEY, FullKey, 0, NULL, 0, KEY_ALL_ACCESS, NULL, &m_Key, NULL) != ERROR_SUCCESS)
		bResult = FALSE;

	return bResult;
}

//****************************************************************************
/// Registry key wrapper: delete existing registry key
///
/// @param[in]	Name
///
/// @return		TRUE if all OK, else FALSE, use GetLastError() for an error code
///
/// @note		Will only work if the key has been opened/created
//****************************************************************************
BOOL CRegistryKey::DeleteKey(QString   KeyName) {
	BOOL bResult = FALSE;

	if (NULL != m_Key) {
		if (RegDeleteKey(m_Key, KeyName) == ERROR_SUCCESS)
			bResult = TRUE;
	}
	return bResult;
}

//****************************************************************************
/// Registry key wrapper: delete existing registry key value
///
/// @param[in]	Name
///
/// @return		TRUE if all OK, else FALSE, use GetLastError() for an error code
///
/// @note		Will only work if the key has been opened/created
//****************************************************************************
BOOL CRegistryKey::DeleteValue(QString   ValueName) {
	BOOL bResult = FALSE;

	if (NULL != m_Key) {
		if (RegDeleteValue(m_Key, ValueName) == ERROR_SUCCESS)
			bResult = TRUE;
	}
	return bResult;
}

//****************************************************************************
/// Registry key wrapper: open a registry key
///
/// @param[in]	Name
///
/// @return		TRUE if all OK, else FALSE, use GetLastError() for an error code
///
/// @note --- Delete if not requried ---
//****************************************************************************
BOOL CRegistryKey::OpenKey(const QString   const Key) {
	BOOL bResult = TRUE;
	WCHAR FullKey[MAX_PATH];

	Initialise();

#if _MSC_VER < 1400 
	wcscpy(FullKey, pDALGLB->BaseRegistryKey());
	wcscat(FullKey, Key);

#else
	wcscpy_s( FullKey, MAX_PATH, pDALGLB->BaseRegistryKey() );
	wcscat_s( FullKey, MAX_PATH, Key );

#endif

#ifdef UNDER_CE
	DWORD LastError = RegOpenKeyEx( BASE_KEY, FullKey, 0, 0, &m_Key );
	#else
	DWORD LastError = RegOpenKeyEx(HKEY_CURRENT_USER, FullKey, 0, KEY_ALL_ACCESS, &m_Key);
#endif

	if (LastError != ERROR_SUCCESS) {
		bResult = FALSE;
	}

	return bResult;
}

//****************************************************************************
/// Registry key wrapper: close a previously opened registry key
///
/// @return		TRUE if all OK, else FALSE, use GetLastError() for an error code
///
/// @note --- Delete if not requried ---
//****************************************************************************
BOOL CRegistryKey::Close() {
	BOOL bResult = TRUE;

	////PSR - fix for the DST _Hang issue begin
	if (NULL != m_Key) {
		if (RegCloseKey(m_Key) != ERROR_SUCCESS)
			bResult = FALSE;
		else
			m_Key = NULL;
	} else {
		LOG_INFO(TRACE_ALWAYS, ("Regiztry key attempted to close with NULL key"));
		//::MessageBox(NULL, L"Regiztry key attempted cole with NULL key", L"RegKeyClose", MB_OK);
	}
	////PSR - fix for the DST _Hang issue end

	return bResult;
}

//****************************************************************************
/// Registry key wrapper: read a registry key value (and type)
///
/// @param[in]	ValueName
/// @param[out]	pType
/// @param[out]	pData
/// @param[out]	pSize
///
/// @return		TRUE if all OK, else FALSE, use GetLastError() for an error code
///
/// @note		Will only work if the key has been opened/created
//****************************************************************************
BOOL CRegistryKey::ReadValue(const QString   ValueName, LPDWORD pType, BYTE *pData, LPDWORD pSize) {
	BOOL bResult = FALSE;

	if (NULL != m_Key) {
		if (RegQueryValueEx(m_Key, ValueName, 0, pType, pData, pSize) == ERROR_SUCCESS)
			bResult = TRUE;
	}
	return bResult;
}
//****************************************************************************
/// Registry key wrapper: read a WCHAR string registry value
///
/// @param[in]	ValueName
/// @param[in]	rstrValue
/// @param[out]	pSize
/// @param[in]	dwType
///
/// @return		TRUE if all OK, else FALSE, use GetLastError() for an error code
///
/// @note		Will only work if the key has been opened/created
//****************************************************************************
BOOL CRegistryKey::ReadValue(const QString   ValueName, QString   &rstrValue, LPDWORD pSize, DWORD dwType) {
	BOOL bResult = FALSE;
	WCHAR wcaValue[260];
	*pSize = 260;
	memset(wcaValue, 0, 260 * sizeof(WCHAR));

	if (NULL != m_Key) {
		if (RegQueryValueEx(m_Key, ValueName, 0, &dwType, reinterpret_cast<BYTE*>(wcaValue), pSize) == ERROR_SUCCESS) {
			bResult = TRUE;

			// if a multi string then replace the null terminator delimiters with pipes
			if (dwType == REG_MULTI_SZ) {
				int iStrLen = *pSize / 2;
				iStrLen -= 2;
				for (int iCount = 0; iCount < iStrLen; iCount++) {
					if (wcaValue[iCount] == 0) {
						wcaValue[iCount] = '|';
					}
				}
			}
			rstrValue.asprintf(L"%s", wcaValue);
		}
	}
	return bResult;
}

//****************************************************************************
/// Registry key wrapper: write a registry key value (and type)
///
/// @param[in]	ValueName
/// @param[in]	Type
/// @param[in]	pData
/// @param[in]	Size
///
/// @return		TRUE if all OK, else FALSE, use GetLastError() for an error code
///
/// @note		Will only work if the key has been opened/created
//****************************************************************************
BOOL CRegistryKey::WriteValue(const QString   ValueName, DWORD Type, const BYTE *pData, DWORD Size) {
	BOOL bResult = FALSE;

	if (NULL != m_Key) {
		if (RegSetValueEx(m_Key, ValueName, 0, Type, pData, Size) == ERROR_SUCCESS)
			bResult = TRUE;
	}
	return bResult;
}

//****************************************************************************
/// Registry key wrapper: write a DWORD registry value
///
/// @param[in]	ValueName
/// @param[in]	Value
///
/// @return		TRUE if all OK, else FALSE, use GetLastError() for an error code
///
/// @note		Will only work if the key has been opened/created
//****************************************************************************
BOOL CRegistryKey::WriteValue(QString   ValueName, DWORD Value) {
	return WriteValue(ValueName, REG_DWORD, (BYTE*) &Value, sizeof(DWORD));
}

//****************************************************************************
/// Registry key wrapper: write a WCHAR string registry value
///
/// @param[in]	ValueName
/// @param[in]	Value
///
/// @return		TRUE if all OK, else FALSE, use GetLastError() for an error code
///
/// @note		Will only work if the key has been opened/created
//****************************************************************************
BOOL CRegistryKey::WriteValue(const QString   ValueName, const QString   Value) {
	//
	// Stability Project Fix:
	//
	// Checked the passed in pointer value for NULL.
	if (Value != NULL)
		return WriteValue(ValueName, REG_SZ, (BYTE*) Value, (DWORD) (wcslen(Value) + 1) * sizeof(WCHAR));
	else
		return FALSE;
}

//****************************************************************************
/// Registry key wrapper: write a binary registry value
///
/// @param[in]	ValueName
/// @param[in]	Value
/// @param[in]	Size
///
/// @return		TRUE if all OK, else FALSE, use GetLastError() for an error code
///
/// @note		Will only work if the key has been opened/created
//****************************************************************************
BOOL CRegistryKey::WriteValue(const QString   ValueName, const BYTE *Value, DWORD Size) {
	return WriteValue(ValueName, REG_BINARY, Value, Size);
}
//****************************************************************************
/// Registry key wrapper: compare WCHAR string registry value
///
/// @param[in]	ValueName
/// @param[in]	Value
///
/// @return		TRUE value matches, else FALSE
///
/// @note		Will only work if the key has been opened/created
//****************************************************************************
BOOL CRegistryKey::compare(QString   ValueName, QString   Value) {
	BOOL bResult = TRUE;
	DWORD dwSize = MAX_PATH * sizeof(WCHAR);
	DWORD dwType = REG_SZ;

	WCHAR Rval[MAX_PATH];

	if (ReadValue(ValueName, &dwType, (BYTE*) Rval, &dwSize)) {
		if (REG_SZ != dwType)
			bResult = FALSE;			// Value is a wrong type
		else if (0 != wcscmp(Rval, Value))
			bResult = FALSE;		// Values not the same
	} else
		bResult = FALSE;

	return bResult;
}

//****************************************************************************
/// Registry key wrapper: compare DWORD registry value
///
/// @param[in]	ValueName
/// @param[in]	Value
///
/// @return		TRUE value matches, else FALSE
///
/// @note		Will only work if the key has been opened/created
//****************************************************************************
BOOL CRegistryKey::compare(QString   ValueName, DWORD Value) {
	BOOL bResult = TRUE;
	DWORD dwSize = sizeof(DWORD);
	DWORD dwType = REG_DWORD;

	DWORD dwRval;

	if (ReadValue(ValueName, &dwType, (BYTE*) &dwRval, &dwSize)) {
		if (REG_DWORD != dwType)
			bResult = FALSE;			// Value is a wrong type
		else if (dwRval != Value)
			bResult = FALSE;		// Values not the same
	} else
		bResult = FALSE;

	return bResult;
}

//****************************************************************************
/// Registry key wrapper: compare binary registry value
///
/// @param[in]	ValueName
/// @param[in]	Value
/// @param[in] Size
/// @param[in]	const USHORT usSTART_INDEX -	The point within the binary array that we wish to start
///												the comparison from
///
/// @return		TRUE value matches, else FALSE
///
/// @note		Will only work if the key has been opened/created
//****************************************************************************
BOOL CRegistryKey::compare(QString   ValueName, BYTE *Value, DWORD Size, const USHORT usSTART_INDEX /* = 0 */) {
	BOOL bResult = TRUE;
	DWORD dwSize = MAX_PATH;
	DWORD dwType = REG_BINARY;

	WCHAR Rval[MAX_PATH];

	if (ReadValue(ValueName, &dwType, (BYTE*) Rval, &dwSize)) {
		if (REG_BINARY != dwType) {
			bResult = FALSE;			// Value is a wrong type
		} else {
			if ((dwSize - usSTART_INDEX) < Size) {
				bResult = FALSE;			// The array the data is going into is too short
			} else {
				if (0 != memcmp(reinterpret_cast<BYTE*>(Rval) + usSTART_INDEX, Value, Size)) {
					bResult = FALSE;		// Values not the same
				}
			}
		}
	} else {
		bResult = FALSE;
	}

	return bResult;
}

//****************************************************************************
/// Registry key wrapper: write an enumerated registry key value (and type)
///
/// @param[in]	ValueName
/// @param[in]	Index
/// @param[in]	Type
/// @param[in]	pData
/// @param[in]	Size
///
/// @return		TRUE if all OK, else FALSE, use GetLastError() for an error code
///
/// @note		Will only work if the key has been opened/created
//****************************************************************************
BOOL CRegistryKey::WriteEnumeratedValue(QString   ValueName, DWORD Index, DWORD Type, BYTE *pData, DWORD Size) {
	BOOL bResult = FALSE;
	DWORD dwLength = (DWORD) wcslen(ValueName) + 1;

	if (NULL != m_Key) {
		if (RegEnumValue(m_Key, Index, ValueName, &dwLength, NULL, &Type, pData, &Size) == ERROR_SUCCESS)
			bResult = TRUE;
	}
	return bResult;
}

//****************************************************************************
/// Registry key wrapper: flush any registry changes
///
/// @return		TRUE if all OK, else FALSE, use GetLastError() for an error code
///
/// @note --- Delete if not requried ---
//****************************************************************************
BOOL CRegistryKey::Flush() {
	BOOL bResult = TRUE;

	if (RegFlushKey( BASE_KEY) != ERROR_SUCCESS)
		bResult = FALSE;

	return bResult;
}

//****************************************************************************
/// Registry key utility: update the registry from a table
///
/// @param[in]	Table
/// @param[in]	size
///
/// @return		
///
/// @note --- Delete if not requried ---
//****************************************************************************
BOOL CRegistryKey::Update(T_REG_TABLE_ENTRY *Table) {
	BOOL bResult = FALSE;
	BOOL bComplete = FALSE;
	BOOL bIsFlushRequired = FALSE;
	BOOL btempParam = FALSE;

	for (int entry = 0; TRUE != bComplete; entry++) {
		T_REG_TABLE_ENTRY tableEntry = Table[entry];

		if (NULL == tableEntry.KeyName)
			bComplete = TRUE;
		else if (InterpretTableEntry(tableEntry, btempParam))
			bResult = TRUE;
		if (btempParam == TRUE) {
			bIsFlushRequired = TRUE;
		}
	}
	if (TRUE == bIsFlushRequired) {
		Flush();
	}

	// Causing the system to hang in startup
	// Hence commenting it out
	// Flush( );

	return bResult;
}

//****************************************************************************
/// Registry key utility: update the registry from a table entry
///
/// @param[in]	tableEntry
///
/// @return		
///
/// @note --- Delete if not requried ---
//****************************************************************************
BOOL CRegistryKey::InterpretTableEntry(T_REG_TABLE_ENTRY tableEntry, BOOL &bIsFlushRequired) {
	BOOL bRequiresReboot = FALSE;
	WCHAR wszValue[MAX_PATH];
	DWORD dwValue = 0;
	memset(wszValue, '\0', MAX_PATH * sizeof(WCHAR));
	in_addr address;

	bIsFlushRequired = FALSE;

	T_PCOMMUNICATIONS pCommunications = NULL;
	pCommunications = pGlbSetup->GetCommsSetupConfig()->GetCommsBlock(CONFIG_MODIFIABLE);

	T_PGENERALCONFIG pGeneral = NULL;
	pGeneral = pGlbSetup->GetGeneralSetupConfig()->GetSystemGeneralBlock(CONFIG_MODIFIABLE);

	//PSR - SNTP fix begin
	bool isUpdateRequired = true; //Default is true for existing functionlaity
	//PSR - SNTP fix end

	// locate the data item
	switch (tableEntry.Item) {
	case ITEM_IDENT_NAME:
//		wcscpy( wszValue, pGeneral->Name );
		swprintf(wszValue, L"XS-%06.6d", pGlbSysInfo->GetSerialNumber());
		break;
	case ITEM_IDENT_DESC:
#if _MSC_VER < 1400 
		wcscpy(wszValue, pGeneral->Description);
#else
		wcscpy_s( wszValue, MAX_PATH, pGeneral->Description );
#endif

		break;

	case ITEM_IP_ADDRESS:
		address.S_un.S_addr = pCommunications->Ethernet.IPAddress.L;
		AddresstoWchar(address, wszValue);
		break;
	case ITEM_SUBNET_MASK:
		address.S_un.S_addr = pCommunications->Ethernet.SubNetMask.L;
		AddresstoWchar(address, wszValue);
		break;
	case ITEM_DEFAULT_GATEWAY:
		address.S_un.S_addr = pCommunications->Ethernet.DefaultGateway.L;
		AddresstoWchar(address, wszValue);
		break;
	case ITEM_PRIMARY_DNS:
		address.S_un.S_addr = pCommunications->Ethernet.DNSServer[0].L;
		AddresstoWchar(address, wszValue);
		break;
	case ITEM_SECONDARY_DNS:
		address.S_un.S_addr = pCommunications->Ethernet.DNSServer[1].L;
		AddresstoWchar(address, wszValue);
		break;
	case ITEM_PRIMARY_WINS:
		address.S_un.S_addr = pCommunications->Ethernet.WINSServer[0].L;
		AddresstoWchar(address, wszValue);
		break;
	case ITEM_SECONDARY_WINS:
		address.S_un.S_addr = pCommunications->Ethernet.WINSServer[0].L;
		AddresstoWchar(address, wszValue);
		break;

	case ITEM_DHCP_ENABLE:
	case ITEM_AUTO_CONFIG:
		if (pCommunications->Ethernet.UseStaticIP)
			dwValue = FALSE;
		else
			dwValue = TRUE;
		break;

	case ITEM_DNS_ORDER:
		dwValue = pCommunications->Ethernet.DNSOrder;
		break;
	case ITEM_ENABLE_MDNS:
		dwValue = pCommunications->Ethernet.EnableMDNS;
		break;
	case ITEM_ENABLE_DNS:
		dwValue = pCommunications->Ethernet.EnableDNS;
		break;
	case ITEM_ENABLE_WINS:
		dwValue = pCommunications->Ethernet.EnableWINS;
		break;

	case ITEM_HTTP_PORT_1:
		// this is the web server port number
		// Note: This settings is probably obselete to the setting below
		dwValue = pCommunications->Ethernet.HTTPSocket;
		break;

	case ITEM_HTTP_PORT_2: {
		// this is the web server port number - it requires us to populate a specific
		// location within a binary array
		dwValue = pCommunications->Ethernet.HTTPSocket;

		// cast the dword value into two bytes - so it's easy to get the individual bytes out
		byte *pbyPortNumber = reinterpret_cast<byte*>(&dwValue);

		// swap the bytes around so they are correct when it comes to the comparison
		BYTE byTempByte = pbyPortNumber[0];
		pbyPortNumber[0] = pbyPortNumber[1];
		pbyPortNumber[1] = byTempByte;

		// if the key doesn't exist, create it
		if (!OpenKey(tableEntry.KeyName)) {
			CreateKey(tableEntry.KeyName);
		}

		// checkif our port number is the same as that stored in the registry	
		if ( FALSE == compare(tableEntry.ValueName, pbyPortNumber, sizeof(DWORD), 2)) {
			if (tableEntry.RebootRequired) {
#ifdef UNDER_CE
					bRequiresReboot = TRUE;
#endif
			}

			// we now need to read the entire value in, modify the relevant bytes
			// and the write it back to the registry
			BYTE abyEntireRegSetting[ MAX_PATH];
			DWORD dwLength = MAX_PATH;
			DWORD dwType = VALUE_BINARY;
			ReadValue(tableEntry.ValueName, &dwType, abyEntireRegSetting, &dwLength);

			abyEntireRegSetting[2] = pbyPortNumber[0];
			abyEntireRegSetting[3] = pbyPortNumber[1];
			WriteValue(tableEntry.ValueName, abyEntireRegSetting, dwLength);
			bIsFlushRequired = TRUE;

		}
	}
		break;
	case ITEM_FTP_PORT:
		dwValue = pCommunications->Ethernet.FTPSocket[0];
		break;
	case ITEM_HTTP_ENABLE:
		dwValue = pCommunications->Ethernet.EnableWeb;
		break;
	case ITEM_FTP_ENABLE:
		dwValue = pCommunications->FTP.EnableFTP;
		break;

		/*case ITEM_SNTP_CLIENT:
		 dwValue = pCommunications->TimeServer.ClientEnable;
		 break;*/
	case ITEM_SNTP_CLIENT:
		if (pCommunications->TimeServer.ClientEnable) {
			CStringUtils::SafeWcsCpy(wszValue, pCommunications->TimeServer.ServerName,
			SNTPSERVER_SERVERNAME_LEN);
		} else {
#if _MSC_VER < 1400 
			//_wcsnset( wszValue, 0, SNTPSERVER_SERVERNAME_LEN );
#else
			//_wcsnset_s( wszValue, sizeof(wszValue)/sizeof(WCHAR),0, SNTPSERVER_SERVERNAME_LEN );			
#endif
			if (OpenKey(tableEntry.KeyName)) {
				BOOL retStatus = DeleteValue(tableEntry.ValueName);
				Flush();
				Close();
				isUpdateRequired = false;
			}
		}
		break;
	case ITEM_SNTP_KEEP:
		// always keep this item on as this is this loads timescv.exe DLL which performs the daylight saving
		dwValue = 1;
		break;
	case ITEM_SNTP_SERVER:
		dwValue = pCommunications->TimeServer.ServerEnable;
		break;
	case ITEM_SNTP_REFRESH:
		dwValue = pCommunications->TimeServer.UpdatePeriod * 1000;
		break;
	case ITEM_SNTP_RECOVERY:
		//dwValue = 0x493e1;
		dwValue = pCommunications->TimeServer.UpdatePeriod * 500;
		break;
	case ITEM_SNTP_THRESHOLD:
		dwValue = pCommunications->TimeServer.UpdateThreshold * 1000;
		break;
	case ITEM_SNTP_TRUST_LOCAL_CLK:
		// always set this to one otherwise the SNTP server doesn't work too well
		dwValue = 1;
		break;

#ifdef UNDER_CE
	case ITEM_SNTP_FLAGS: //PSR - SNTP fix begin
		if( pCommunications->TimeServer.ClientEnable )
		{ 
			if ( OpenKey( tableEntry.KeyName ) )
			{
				//Client enable only requires this setting since the power on off calculation
				//is improper
				//Set the registry entry to not load the SNTP in boot time and application will load the service
				DWORD dwPrevValue = 0;
				DWORD dwPrevSize = sizeof(dwPrevValue);
				if ( ReadValue(tableEntry.ValueName, NULL, (BYTE*)(&dwPrevValue), &dwPrevSize) )
				{
					dwValue = dwPrevValue;
					if ( 0 != ( dwValue & DEVFLAGS_NOLOAD ) )
					{
						isUpdateRequired = false; //Do not update if already set
					}
					else
					{
						dwValue |= DEVFLAGS_NOLOAD ;
					}
				}
				else
				{
					dwValue = DEVFLAGS_LOAD_AS_USERPROC;					
					dwValue |= DEVFLAGS_NOLOAD; 					
				}				
				Close();
			}
			else
			{
				dwValue = DEVFLAGS_LOAD_AS_USERPROC;					
				dwValue |= DEVFLAGS_NOLOAD; 
			} 
		}
		else
		{
			if ( OpenKey( tableEntry.KeyName ) )
			{
				//Client enable only requires this setting since the power on off calculation
				//is improper
				//Set the registry entry to not load the SNTP in boot time and application will load the service
				DWORD dwPrevValue = 0;
				DWORD dwPrevSize = sizeof(dwPrevValue);
				if ( ReadValue(tableEntry.ValueName, NULL, (BYTE*)(&dwPrevValue), &dwPrevSize) )
				{
					dwValue = dwPrevValue;
					if ( 0 != ( dwValue & DEVFLAGS_NOLOAD ) ) //Chek if flag is set in regsitry value
					{
						dwValue ^= DEVFLAGS_NOLOAD ; //Unset the flag
					}
					else
					{
						isUpdateRequired = false; //Do not update if already unset
					}					
				}
				else
				{				
					isUpdateRequired = false;	
				}				
				Close();
			}
			else
			{
				isUpdateRequired = false;
			}
		}
		break;//PSR - SNTP fix end

		case ITEM_SNTP_AUTOUPDATE: 
		if(pCommunications->TimeServer.ClientEnable)
		{ 
			if(OpenKey(tableEntry.KeyName ) )
			{
				DWORD dwPrevValue = 0;
				DWORD dwPrevSize = sizeof(dwPrevValue);
				if(ReadValue(tableEntry.ValueName, NULL, (BYTE*)(&dwPrevValue), &dwPrevSize))
				{
					dwValue = dwPrevValue;
					if( 0 != dwValue)
					{
						isUpdateRequired = false; //Do not update if already set
					}
					else
					{
						dwValue = 1; 
					}
				}
				else
				{
					dwValue = 1; 					
				}				
				Close();
			}
			else
			{
				dwValue = 1; 
			} 
		}
		else
		{
			if(OpenKey(tableEntry.KeyName))
			{				
				DWORD dwPrevValue = 0;
				DWORD dwPrevSize = sizeof(dwPrevValue);
				if(ReadValue(tableEntry.ValueName, NULL, (BYTE*)(&dwPrevValue), &dwPrevSize))
				{
					dwValue = dwPrevValue;
					if( 1 != dwValue)
					{
						isUpdateRequired = false; //Do not update if already set
					}
					else
					{
						dwValue = 0;
					}
				}
				else
				{
					dwValue = 0; 					
				}				
				Close();
			}
			else
			{
				dwValue = 0; 
			} 
		}
		break;
#endif
	}

	// if the key doesn't exist, create it
	if (!OpenKey(tableEntry.KeyName))
		CreateKey(tableEntry.KeyName);

	// Write the value
	switch (tableEntry.Type) {
	case VALUE_DWORD:
		if ( FALSE == compare(tableEntry.ValueName, dwValue)) {
			//PSR - SNTP fix begin
			if (true == isUpdateRequired) //Update only when requires
					{
				if (tableEntry.RebootRequired) {
					bRequiresReboot = TRUE;
				}

				WriteValue(tableEntry.ValueName, dwValue);
				bIsFlushRequired = TRUE;
			}
			//PSR - SNTP fix end
		}
		break;
	case VALUE_STRING:
		if ( FALSE == compare(tableEntry.ValueName, wszValue)) {
			//PSR - SNTP fix begin
			if (true == isUpdateRequired) //Update only when requires
					{
				if (tableEntry.RebootRequired) {
					bRequiresReboot = TRUE;
				}

				WriteValue(tableEntry.ValueName, wszValue);
				bIsFlushRequired = TRUE;
			}
			//PSR - SNTP fix end
		}
		break;
	case VALUE_BINARY:
		// do nothing as it will have bene handled in its own special way
		break;
	}
	Close();

	return bRequiresReboot;
}

//****************************************************************************
/// Registry key utility: convert an IP address to a WCHAR string
///
/// @param[in]		address
/// @param[out]		wszValue
///
/// @return		
///
/// @note --- Delete if not requried ---
//****************************************************************************
void CRegistryKey::AddresstoWchar(in_addr address, QString   wszValue) {
	char *szString = NULL;

	szString = inet_ntoa(address);
	memset(wszValue, '\0', MAX_PATH * sizeof(WCHAR));
	if (NULL != szString) {

#if _MSC_VER < 1400 
		mbstowcs(wszValue, szString, MAX_PATH);
#else
		size_t mbSize;
		mbstowcs_s(&mbSize, wszValue, MAX_PATH, szString, MAX_PATH );
#endif

	}
}
//****************************************************************************
/// const GetDHCPIPAddress()
///
/// Method that gets the current IP address
///
/// @return		Returns a string containing the IP address
/// 
//****************************************************************************
const QString   CRegistryKey::GetDHCPIPAddress() {
	CRegistryKey kReg;
	QString   strIPAddress("");
	DWORD dwSize = strIPAddress.length();
	kReg.OpenKey(L"Comm\\FEC1\\Parms\	cpIp");
	kReg.ReadValue(L"DHCPIPAddress", strIPAddress, &dwSize, REG_SZ);
	return strIPAddress;
}
//****************************************************************************
/// const GetDHCPWINSIPAddress()
///
/// Method that gets the WINS IP Address
///
/// @return		Returns a string containing the IP address
/// 
//****************************************************************************
const QString   CRegistryKey::GetDHCPWINSIPAddress() {
	CRegistryKey kReg;
	QString   strIPAddress("");
	DWORD dwSize = strIPAddress.length();
	kReg.OpenKey(L"Comm\\FEC1\\Parms\	cpIp");
	kReg.ReadValue(L"DHCPWINS", strIPAddress, &dwSize, REG_MULTI_SZ);
	return strIPAddress;
}
//****************************************************************************
/// const GetDHCPDNSIPAddress()
///
/// Method that gets the DNS IP Address
///
/// @return		Returns a string containing the IP address
/// 
//****************************************************************************
const QString   CRegistryKey::GetDHCPDNSIPAddress() {
	CRegistryKey kReg;
	QString   strIPAddress("");
	DWORD dwSize = strIPAddress.length();
	kReg.OpenKey(L"Comm\\FEC1\\Parms\	cpIp");
	kReg.ReadValue(L"DHCPDNS", strIPAddress, &dwSize, REG_MULTI_SZ);
	return strIPAddress;
}
//****************************************************************************
/// const bool IsNewRegistry( const bool bRESET /* = false */ )
///
/// Method that checks if this is a new registry by the fact a key generated by
///	the app is not present
///
/// @param[in]		const bool bRESET - Flag indicating if we want the key reset back
///					to 'N'
///
/// @return		Returns true if this is a new registry
/// 
/// @NOTE	DO NOT CALL ME - USE DEVICE_INFO.IsNewRegistry() instead
///
//****************************************************************************
const bool CRegistryKey::IsNewRegistry(const bool bRESET /* = false */) {
	bool bNewRegistry = false;
	CRegistryKey kReg;
	QString   strNewReg("");
	DWORD dwSize = 0;

	// firstly attemp to open the registry key
	if (kReg.OpenKey(L"SOFTWARE\\V6APP")) {
		// the key exists so we are at least running the right NK.bin, now check 
		// if the key is set to 'Y' or 'N'
		if (kReg.ReadValue(L"NewReg", strNewReg, &dwSize, REG_SZ)) {
			if (strNewReg == L"Y") {
				// must be a new registry
				bNewRegistry = true;

				// set to N as the registry will have been setup now
				if (bRESET) {
					strNewReg = L"N";
					kReg.WriteValue(L"NewReg", strNewReg.GetBuffer(2));
				}
			} else {
				// must be 'N' so not a new registry
				bNewRegistry = false;
			}
		} else {
			// shouldn't really happen
			bNewRegistry = true;
		}

		// now close the registry key
		kReg.Close();
	} else {
		// shouldn't really happen
		bNewRegistry = true;
	}

	return bNewRegistry;
}

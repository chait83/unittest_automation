/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Utilities
/// @n Filename: TVtime.h
/// @n Desc:	 Common time routines
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  23  Stability Project 1.20.1.1 7/2/2011 5:02:13 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  22  Stability Project 1.20.1.0 7/1/2011 4:26:56 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  21  V6 Firmware 1.20 9/23/2008 3:09:34 PM  Build Machine 
//  AMS2750 Merge
//  20  V6 Firmware 1.19 4/30/2007 3:33:31 PM  Graham Waterfield
//  Improve comments and solve problem with alarm counter table viewing
// $
//
// ****************************************************************

#include "Defines.h"
#include <QDateTime>
#include <QLocale>
#include <QString>
#ifndef _TVTIME_H
#define _TVTIME_H

#ifdef WIN32 
#pragma pack( push, enter_tvtime_h ) // save current alignment on entry
#pragma pack(2) // specify byte alignment
// this is also set in the project settings but problems with the debugger
// occur unless it is specified here too.
#endif

// TV5 Time 
// this structure is used for both absolute times and time spans.
// for absolute times, the structure holds the number of seconds since 1970 

#ifndef __TV5TIME_C_STRUCTURES__
#define __TV5TIME_C_STRUCTURES__

typedef struct TV5Time {
	long Secs;  // whole seconds range (-68 years to +68 years from 1970)
	short Fracs;  // 10ths of ms range (-9999 to +9999)
} T_TV5TIME;

// these structures are copys of those in v4 common.h
// we cannot easily include that file here.

struct ltime_2 {
	USHORT sec :6;	///< seconds 0..59 
	USHORT month :4;	///< month  1..12 
	USHORT year :5;	///< year-1994 0=1994 .. 31=2025 
	USHORT istime :1;///< MSB must appear in most sig bit position!!! always 1 in logfile to indicate word is a time! (else interpreted as a level)
	USHORT min :6;	///< minutes 0..59
	USHORT hour :5;	///< hour  0..23 
	USHORT day :5;	///< day 1..31 
};

struct header_2 {
	USHORT dummy1 :8;
	USHORT frac_secs :4; ///< 16ths sec but likely only accurate to 1/4 sec if that
	USHORT dummy2 :4;
};

struct time_grad_2 {
	ltime_2 Time;
	header_2 Header;
};

struct realtime_2 {
	UCHAR dum1;
	UCHAR dum2;
	UCHAR dum3;
	ltime_2 Time;
	UCHAR frac_secs; ///< fracs sec 1/16ths 
};

// ANSI time functions use seconds from Jan 1st 1970.
// The TrendView Base date/time is 00:00:00 hours Jan 1st 1994, so a fixed offset 
// must be applied to any time values when using v4 date/times.

#define BASEOFFSET 757382400  ///< 1st Jan 1994
#define ENDOFTIME 2082758400  ///< applies to TV5Time Seconds

#endif __TV5TIME_C_STRUCTURES__

class CTVtime {
private:
	__int64 internalTime;				///< microseconds since 1st Jan 1970

	__int64 TV5TimeToMicroSecs(TV5Time *t);
    void InternaltoSYSTEMTIME(SYSTEMTIME *st) const;

public:

	// Constructors
	CTVtime();
	CTVtime(const CTVtime &t);
	CTVtime(__int64 microSec1970);

	// V5
	CTVtime(TV5Time &t);
	CTVtime(TV5Time *t);


	// V4
	CTVtime(time_grad_2 *ptv4time);
	CTVtime(realtime_2 *ptv4time);
	CTVtime(ltime_2 *ptv4time);
	
	int GetDateFormat(
        QLocale locale,
///@TODO Date flags,
        const SYSTEMTIME &st,
        QString format,
        char *dateStr,
        int cchDate
    )const;
	
	 int GetTimeFormat(
        QLocale locale,
///@TODO Time flags,
        SYSTEMTIME &st,
        QString format,
        char *timeStr,
        int cchTime
    )const;
	
    void SYSTEMTIMEtoInternal(SYSTEMTIME &st);

	void SetTime(const CTVtime &timeToCopy);

	void TimeNow();
	BOOL TimeEqApprox(TV5Time &t2, ULONG mstenths);
	TV5Time GetTV5Time();
	void GetTV5Time(TV5Time *t);
    void GetSYSTEMTIME(SYSTEMTIME *systemtime);
	__int64 GetSeconds();
	__int64 GetMicroSecs();
	__int64 GetmsTenths();

	USHORT GetMonthAndYear();
	void SetFirstTimeInMonth(USHORT mmyyy);
	USHORT GetDaysInMonth(USHORT mmyyy);

	// Method that retrieves the number of days in a month 
	static const USHORT GetDaysInMonth(const USHORT usMONTH, const USHORT usYEAR);

	USHORT GetHour();
	USHORT GetDay();
	USHORT GetDayOfWeek();
	USHORT GetMonth();
	CTVtime GetTimeOfDaySpan();
	void SetTimeSpan(USHORT Hours, USHORT Minutes, USHORT Secs, USHORT milliSec = 0, ULONG microSec = 0);

//	const QString  TimeToStringShort( ) const;

	void TimeToMinsSecsString(TCHAR *buff) const;
	void TimeToHourMinsSecsString(TCHAR *buff) const;
	void TimeToString(TCHAR *buff, int length) const;
	void TimeToStringShort(TCHAR *buff) const;
	void TimeDateToStringShort(TCHAR *buff) const;

	// Method that gets the date as a string in the format dd mmm yy
	void DateToStringShort(TCHAR *buff, const int iBUFF_LEN) const;

	// Method that gets the date as a string in the format dd mmm yy
//	const QString  DateToStringShort( ) const;

	// Method that gets the date as a string in the format dd mmm yyyy
	void DateToString(TCHAR *buff, const int iBUFF_LEN) const;

	// Method that gets the date as a string in the format dd mmm yyyy
//	const QString  DateToString( ) const;

	void TimeTemplateDateFirstString(TCHAR const *dateasprintf, TCHAR const *timeasprintf, TCHAR *buff) const;
	void TimeToStringNoFracs(TCHAR *buff) const;
	static const ULONG m_ulMAX_SHORT_TIME_DATE_BUFF_LEN;

	/// Variable indicating the max length required to hold all of a time/date (including milliseconds) string
	static const ULONG m_ulMAX_TIME_DATE_INC_MS_BUFF_LEN;

	/*
	 // Convert the Time (no date) to a QString   
	 void ShortTimeAsString( QString  &rstrTime ) const;

	 // Convert the date (no time) to a QString   
	 void DateAsString( QString  &rstrTime ) const;
	 */

	CTVtime operator+(TV5Time &t2);
	CTVtime operator+(CTVtime &t2);
	CTVtime operator+(long mstenths);
//	CTVtime operator+(__int64 microSecs);

	CTVtime operator-(TV5Time &t2);
	CTVtime operator-(CTVtime &t2);
	CTVtime operator-(long mstenths);
//	CTVtime operator-(__int64 microSecs);

	CTVtime operator/(USHORT div);

	void operator+=(TV5Time &t2);
	void operator+=(CTVtime &t2);
	void operator+=(long mstenths);
//	void	operator+=(__int64 microSecs);

	void operator-=(TV5Time &t2);
	void operator-=(CTVtime &t2);
	void operator-=(long mstenths);
//	void	operator-=(__int64 microSecs);

	BOOL operator>=(TV5Time &t2);
	BOOL operator>=(CTVtime &t2);

	BOOL operator>(TV5Time &t2);
	BOOL operator>(CTVtime &t2);

	BOOL operator<=(TV5Time &t2);
	BOOL operator<=(CTVtime &t2);

	BOOL operator<(TV5Time &t2);
	BOOL operator<(CTVtime &t2);

	BOOL operator==(TV5Time &t2);
	BOOL operator==(CTVtime &t2);
};

// Callback routine called by the SIP to validate seconds and minutes
BOOL WINAPI SecondsMinsValidateCallbackFunction(QString pBuffer);

// Callback routine called by the SIP to validate hours
BOOL WINAPI HoursValidateCallbackFunction(QString pBuffer);

// Callback routine called by the SIP to validate days
BOOL WINAPI DaysValidateCallbackFunction(QString pBuffer);

#ifdef WIN32  
#pragma pack( pop, enter_tvtime_h ) // restore original alignment on exit
#endif

#endif _TVTIME_H

/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Utilities
/// @n Filename: Demo waves.h
/// @n Desc:	 Provide demonstration waves for simulating input
///					used in demo channels and in Maths block
///				 
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  4 Stability Project 1.1.1.1 7/2/2011 4:56:43 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  3 Stability Project 1.1.1.0 7/1/2011 4:27:30 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  2 V6 Firmware 1.1 5/18/2005 10:07:44 PM  Andy Kassell  
//  Implement self configuration
//  1 V6 Firmware 1.0 5/18/2005 2:38:41 PM  Andy Kassell  
// $
//
// ****************************************************************

#ifndef __DEMOWAVES_H__
#define __DEMOWAVES_H__

#include "V6defines.h"
#include "FFConversionInfo.h"

const int PRE_CALC_SINE_STEPS = 2000;	// Number of step to precalculate the sine wave over
const float DEMO_PI = 3.14159265F;		// PI for Sine wave calculations

// Types of demo waves
typedef enum {
	DEMO_WAVE_NONE = 0,					// No wave, will always return 0
	DEMO_WAVE_SIN,						// Sine wave								
	DEMO_WAVE_RAMP_UP,					// Ramp up sawtooth
	DEMO_WAVE_RAMP_DOWN,				// Ramp Down sawtooth
	DEMO_WAVE_RAMP_UP_DOWN,				// Ramp up and down (triangle)
	DEMO_WAVE_SQUARE,					// Square wave
	DEMO_WAVE_DRIFT,					// Randon drift
	DEMO_WAVE_PULSE,					// Pulse input simulation (randon)				
	DEMO_WAVE_DIGITAL,					// Digital Input simulation (randon)				
	DEMO_WAVE_UI_AI,					// Take from user input selection for analogues
	DEMO_WAVE_UI_DI,					// Take from user input selection for digitals
} T_DEMOWAVE_TYPES;

//**Class*********************************************************************
///
/// @brief Demo waves
/// 
/// Provide a number of demonstration waves for demo channel and maths
///
//****************************************************************************
class CDemoWave {
public:
	CDemoWave();

public:		// API methods

	// Call to configure the Demo wave
	void ConfigureDemoWave(int chanNumber, USHORT slotNo, USHORT boardChanNo, float zero, float span, float noise,
			T_DEMOWAVE_TYPES waveType, int waveDuration, int sourceTickRate);

	// Call to get the demo value
	float GetDemoValue();

	static void SetDemoAnalogue(int analogueNumber, float analogueValue);
	static void SetDemoDigitalCard(int digitalCardNumber, USHORT digitalBitMask);

private:	// Methods

	float CalcSineWave();
	float CalcRamp();
	float CalcSquare();
	float CalcDrift();
	float CalcNoiseLevel();
	static void InitialiseSharedDemoWave();

private:	// Member variables

	static float m_UIAnalogues[MAX_ANALOGUE_IN];
	static USHORT m_UIDigitals[MAX_DIGITAL_CARDS];

	float m_zero;					// engineering zero
	float m_span;					// engineering span

	float m_noiseLevel;				// Noise level to apply in absolute engineering units
	float m_noiseFactor;			// Rand to noise factor

	float m_driftLevel;				// drift level to apply in absolute engineering units
	float m_driftFactor;			// Rand to drift factor

	CFFConversionInfo m_conv;		// Conversion info for scale conversions.
	int m_ticksPerCycle;			// number of ticks in a cycle of a demo wave

	float m_increment;				// Increment over time and unit
	float m_currentVal;				// Current Value

	int m_directChange;				// direction Change total cycle ticks / 2

	int m_chanNumber;				// Channel number
	float m_currentTickCount;		// Current tick count

	// AMS2750 demo mode
	const int m_NO_OF_SET_POINTS;
#ifdef CAL_MODE
	float m_setPointsAsPercent[6];
#else
	float m_setPointsAsPercent[3];
#endif
	int m_SOAK_PERIOD_IN_SECONDS;
	bool m_isTUSMode;
	int m_soakWaitPeriodCountInTicks;
	int m_currentSoakEndWaitCountInTick;
	int m_nextSetPoint;
	int m_slotNo;
	int m_boardChanNo;

	T_DEMOWAVE_TYPES m_waveType;	// wave type required

	static float m_preCalcSineTable[PRE_CALC_SINE_STEPS];

	static BOOL IsSharedDemoDataInitialised;	///< Flag to determine of demo data has been initialised
};

#endif //__DEMOWAVES_H__

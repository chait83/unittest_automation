/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
//
/// Note:
///	This class will only work for a CE build.

#include "Registry.h"
#include "CertSubjectsStore.h"
#include "V6globals.h"

//****************************************************************************
/// CFTPUser service: class constructor
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************

CCertSubjectsStore::CCertSubjectsStore() {

}

//****************************************************************************
/// CFTPUser service: class destructor
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
CCertSubjectsStore::~CCertSubjectsStore() {

}
BOOL CCertSubjectsStore::CreateandUpdatePubRootCerticateKey(const LPCTSTR bPubKey) {
	bool bKeyOpen = false;
#ifdef UNDER_CE	
		CRegistryKey kRegKey;
		

		if( !kRegKey.OpenKey( L"Ident" ) )
		{
			if( kRegKey.CreateKey( L"Ident" ) )
			{
				bKeyOpen = true;
			}
			else
			{
				bKeyOpen = false;
			}
		}
		else
		{
			bKeyOpen = true;
		}

		if( bKeyOpen )
		{
			kRegKey.WriteValue( L"PubRootCertificate", bPubKey);
			kRegKey.Flush();
			kRegKey.Close();
		}
#endif
	return bKeyOpen;
}

BOOL CCertSubjectsStore::CreateandUpdateRootSubjectKey(const LPCTSTR lRootSubjectName) {
	bool bKeyOpen = false;
#ifdef UNDER_CE	
		CRegistryKey kRegKey;
		

		if( !kRegKey.OpenKey( L"Ident" ) )
		{
			if( kRegKey.CreateKey( L"Ident" ) )
			{
				bKeyOpen = true;
			}
			else
			{
				bKeyOpen = false;
			}
		}
		else
		{
			bKeyOpen = true;
		}

		if( bKeyOpen )
		{
			kRegKey.WriteValue( L"RootCertSubject", lRootSubjectName );
			kRegKey.Flush();
			kRegKey.Close();
		}
#endif
	return bKeyOpen;
}

BOOL CCertSubjectsStore::CreateandUpdateServerSubjectKey(const LPCTSTR lDeviceSubjectName) {
	bool bKeyOpen = false;
#ifdef UNDER_CE	
		CRegistryKey kRegKey;
		

		if( !kRegKey.OpenKey( L"Ident" ) )
		{
			if( kRegKey.CreateKey( L"Ident" ) )
			{
				bKeyOpen = true;
			}
			else
			{
				bKeyOpen = false;
			}
		}
		else
		{
			bKeyOpen = true;
		}

		if( bKeyOpen )
		{
			kRegKey.WriteValue( L"ServerCertSubject", lDeviceSubjectName );
			kRegKey.Flush();
			kRegKey.Close();
		}
#endif
	return bKeyOpen;
}

QString   CCertSubjectsStore::GetRootSubjectKey() {
	QString   csRootCertSubj("");

#ifdef UNDER_CE
	CRegistryKey cCertStore;


	if ( cCertStore.OpenKey( L"Ident" ) )
	{

		DWORD dwType = REG_SZ;
		DWORD dwSize = MAX_PATH;

		cCertStore.ReadValue( L"RootCertSubject", csRootCertSubj, &dwSize, dwType );
		cCertStore.Close( );

	}
#endif
	return csRootCertSubj;
}
QString   CCertSubjectsStore::GetServerSubjectKey() {
	QString   csServerCertSubj("");

#ifdef UNDER_CE
	CRegistryKey cCertStore;


	if ( cCertStore.OpenKey( L"Ident" ) )
	{

		DWORD dwType = REG_SZ;
		DWORD dwSize = MAX_PATH;

		cCertStore.ReadValue( L"ServerCertSubject", csServerCertSubj, &dwSize, dwType );
		cCertStore.Close( );

	}
#endif
	return csServerCertSubj;
}

QString   CCertSubjectsStore::GetPubRootCertificateKey() {
	QString   csPubRootCertKey("");

#ifdef UNDER_CE
	CRegistryKey cCertStore;


	if ( cCertStore.OpenKey( L"Ident" ) )
	{

		DWORD dwType = REG_SZ;
		DWORD dwSize = MAX_PATH;

		cCertStore.ReadValue( L"PubRootCertificate", csPubRootCertKey, &dwSize, dwType );
		cCertStore.Close( );

	}
#endif
	return csPubRootCertKey;
}

BOOL CCertSubjectsStore::CreateandUpdateEmailRootSubjectKey(const LPCTSTR lRootEmailSubjectName) {
	bool bKeyOpen = false;
#ifdef UNDER_CE	
		CRegistryKey kRegKey;
		

		if( !kRegKey.OpenKey( L"Ident" ) )
		{
			if( kRegKey.CreateKey( L"Ident" ) )
			{
				bKeyOpen = true;
			}
			else
			{
				bKeyOpen = false;
			}
		}
		else
		{
			bKeyOpen = true;
		}

		if( bKeyOpen )
		{
			kRegKey.WriteValue( L"EmailRootCertSubject", lRootEmailSubjectName );
			kRegKey.Flush();
			kRegKey.Close();
		}
#endif
	return bKeyOpen;
}

QString   CCertSubjectsStore::GetEmailRootSubjectKey() {
	QString   csEmailRootCertSubj("");

#ifdef UNDER_CE
	CRegistryKey cCertStore;


	if ( cCertStore.OpenKey( L"Ident" ) )
	{

		DWORD dwType = REG_SZ;
		DWORD dwSize = MAX_PATH;

		cCertStore.ReadValue( L"EmailRootCertSubject", csEmailRootCertSubj, &dwSize, dwType );
		cCertStore.Close( );

	}
#endif
	return csEmailRootCertSubj;
}


/**********************************************************************************
 
 COPYRIGHT (c) 2001
 HONEYWELL LTD.
 ALL RIGHTS RESERVED
 
 This software is a copyrighted work and/or information protected as a
 trade secret. Legal rights of Honeywell Ltd. in this software is distinct
 from ownership of any medium in which the software is embodied. Copyright
 or trade secret notices included must be reproduced in any copies
 authorised by Honeywell Ltd.
 
 /////////////////////////////////////////////////////////////////////////////

 /////////////////////////////////////////////////////////////////////////////
 
 Ping.cpp : Implementation of class CPing (Using WINSOCK2).
 
 Revision History:
 
 Date Author			  Comments
 ---------	-------		  -----------------------------------------
 26/07/2006	Amey				Initial Version 

 *********************************************************************************/

#include "ping.h"

#define MIN_ICMP_PACKET_SIZE 8
#define MAX_ICMP_PACKET_SIZE 1024

BOOL CPing::sm_bAttemptedWinsock2Initialise = FALSE;
__int64 CPing::sm_TimerFrequency = 0;

void FillIcmpData(LPICMP_HEADER pIcmp, int nData);
BOOL DecodeResponse(char *pBuf, int nBytes, sockaddr_in *from);

/***********************************************************************

 Method Name : Initialise()

 Description : Initialise the Winsock2 stack and negotiate for version 2.2
 

 Parameters : Parameter		In/Out	Description

 ***********************************************************************/
BOOL CPing::Initialise() {
	if (!sm_bAttemptedWinsock2Initialise) {
		sm_bAttemptedWinsock2Initialise = TRUE;
		WSAData wsaData;
		//Negotiate for Version 2.2
		if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
			return false;
		}
		LARGE_INTEGER frequency;
		frequency.QuadPart = 0;
		if (QueryPerformanceFrequency(&frequency) != TRUE) {
			return false;
		}
		sm_TimerFrequency = frequency.QuadPart;
	}
	return TRUE;
}

//[
// return : -1 error in address , 0 - ping FALSE ; 1 - ping TRUE 
int CPing::Ping1(LPCTSTR Address, int &nErrCode, int iTtl, int iWaitTime) {

	int iRet = 1;
#ifdef UNDER_CE		

	nErrCode = 0;
	IPAddr  ipAddress ;
	IP_OPTION_INFORMATION ipInfo ;
	ICMP_ECHO_REPLY  icmpEcho;	
	HANDLE  hFile;	
	char strHost [ MAX_PATH ] ;
	//TCHAR szPCName [ MAX_PATH ] = { TEXT( "" ) } ;
	//int  iRet = -1 ;
	struct in_addr iaDest;		// Internet address structure
  LPHOSTENT pHost;			// Pointer to host entry structure

	//_tcscpy( szName , TEXT("") );
	WideCharToMultiByte( CP_ACP, 0, Address , -1, strHost, sizeof( strHost ), NULL, FALSE );
  ipAddress = inet_addr(strHost);
  iaDest.s_addr = inet_addr(strHost);
  if (iaDest.s_addr == INADDR_NONE)
	{
  pHost = gethostbyname(strHost);
	  if( pHost )
		{
			//char *pIP ;
			iaDest.S_un.S_addr = *(DWORD *)(*pHost->h_addr_list) ;
		//	pIP = inet_ntoa( iaDest ) ;
		  //if( strlen( pIP ) )
	 // MultiByteToWideChar( CP_ACP, 0, pIP , -1, szPCName, sizeof( szPCName ) );
		  //if( _tcslen( szPCName ) )
		 // _tcscpy( szName , szPCName );
		}
	}
  else
	{
  pHost = gethostbyaddr((const char *)&iaDest, 
  sizeof(struct in_addr), AF_INET);
	/*  if( pHost )
		{
	  MultiByteToWideChar( CP_ACP, 0, pHost->h_name , -1, szPCName, sizeof( szPCName ) );
		  if( _tcslen( szPCName ) )
		  _tcscpy( szName , szPCName );
		}*/
	}
	if( pHost )
		ipAddress = *(DWORD *)(*pHost->h_addr_list) ;
  if (ipAddress != INADDR_NONE)
	{	
		iRet = 0 ;
		hFile = IcmpCreateFile();
		
		// Set some reasonable default values
		ipInfo.Ttl  = iTtl ;
		ipInfo.Tos  = 0;
		ipInfo.Flags = 0;
		ipInfo.OptionsSize = 0 ;
		ipInfo.OptionsData = NULL ;
		icmpEcho.Status  = -1 ;
		icmpEcho.Data ;
		LPVOID lpBuff = (LPVOID) malloc (sizeof(ICMP_ECHO_REPLY ) + 8);
		
		DWORD dw = IcmpSendEcho( hFile , ipAddress , NULL , 0 ,
			 (PIP_OPTION_INFORMATION)&ipInfo,
			 lpBuff , sizeof(ICMP_ECHO_REPLY) +8 , iWaitTime ) ;	
		Icmp//No need to close the mutex in Qt ;
		

		if ( dw != 0)
		{
			memcpy((LPVOID)&icmpEcho, lpBuff, sizeof(ICMP_ECHO_REPLY));
			if ( icmpEcho.Status == IP_SUCCESS )
				iRet = 1 ;
		}
		if(lpBuff)
			free(lpBuff);
		//else
		//	nErrCode = dw;

		
		//*prtt = icmpEcho.RoundTripTime ;
	}

	#endif
	return iRet;
}
//]

/***********************************************************************

 Method Name : Ping()

 Description : This function is the thread routine for the Network 
 Monitoring thread.
 

 Parameters : Parameter		In/Out	Description
 pszHostName		In		Hostname to be pinged
 pr				Out		CPingReply structure containing
 reply information from ping
 nTTL				In				


 Return Type	: 	Zero	 - If Success
 Non-Zero - If Failed

 ***********************************************************************/

//BOOL CPing::Ping(LPCTSTR pszHostName, CPingReply& pr, UCHAR nTTL, DWORD dwTimeout, UCHAR nPacketSize) 
BOOL CPing::Ping(LPCTSTR pszHostName, CPingReply &pr, UCHAR nTTL, DWORD dwTimeout, UCHAR nPacketSize) {
	USES_CONVERSION;
	//Parameter validation
	if (nPacketSize > MAX_ICMP_PACKET_SIZE || nPacketSize < MIN_ICMP_PACKET_SIZE) {
		SetLastError (WSAENOBUFS);
		return FALSE;
	}

	sm_bAttemptedWinsock2Initialise = FALSE;
	if (!Initialise()) {
		return FALSE;
	}

	sockaddr_in dest;
	memset(&dest, 0, sizeof(dest));

	LPSTR lpszAscii = T2A(pszHostName);
	//LPCSTR lpszAscii = pszHostName.c_str();
	unsigned long addr = inet_addr(lpszAscii);
	if (addr == INADDR_NONE) {
		hostent *hostEnt = gethostbyname(lpszAscii);
		if (hostEnt) {
			memcpy(&dest.sin_addr, hostEnt->h_addr, hostEnt->h_length);
			dest.sin_family = hostEnt->h_addrtype;
		} else {
			//Could Not Resolve HostName
			return FALSE;
		}
	} else {
		dest.sin_addr.s_addr = addr;
		dest.sin_family = AF_INET;
	}

	//E528446[

	QAbstractSocket sockRaw = WSASocket(AF_INET, SOCK_RAW, IPPROTO_TCP, NULL, 0, 0); ////old

	//]

	if (sockRaw == INVALID_SOCKET) {
		LPVOID lpMsgBuf;
		//LPVOID lpDisplayBuf;

		DWORD dw = WSAGetLastError();
		asprintfMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS, NULL,
				dw, MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), (QString  ) & lpMsgBuf, 0, NULL);

		/* lpDisplayBuf = (LPVOID)LocalAlloc(LMEM_ZEROINIT, 
		 (lstrlen((LPCTSTR)lpMsgBuf) + 40) * sizeof(TCHAR)); 
		 StringCchPrintf((QString   )lpDisplayBuf, 
		 LocalSize(lpDisplayBuf) / sizeof(TCHAR),
		 TEXT("%s failed with error %d: %s"), 
		 lpszFunction, dw, lpMsgBuf);*/
		// MessageBox(NULL, (LPCTSTR)lpMsgBuf, TEXT("Error"), MB_OK); 
		return FALSE;
	}
	int nBufSize = nPacketSize + sizeof(IP_HEADER);
	//char* pICMP = new char[nBufSize];
	char pICMP[sizeof(IP_HEADER) + 32] = { '\x0' };

	FillIcmpData((LPICMP_HEADER) pICMP, nBufSize);

	LARGE_INTEGER TimerTick;
	VERIFY(QueryPerformanceCounter(&TimerTick));
	__int64 nStartTick = TimerTick.QuadPart;

	int nWrote = sendto(sockRaw, pICMP, nBufSize, 0, (sockaddr*) &dest, sizeof(dest));
	if (nWrote == QAbstractSocket_ERROR) {
		//delete [] pICMP;
		DWORD dwError = GetLastError();
		closesocket(sockRaw);
		SetLastError(dwError);
		return FALSE;
	}

	//char* pRecvBuf = new char[MAX_ICMP_PACKET_SIZE];

	char pRecvBuf[MAX_ICMP_PACKET_SIZE] = { '\x0' };
	sockaddr_in from;
	int nFromlen = sizeof(from);
	int nRead = 0;
	BOOL bReadable;

	//Allow the specified timeout
	if (IsSocketReadible(sockRaw, dwTimeout, bReadable)) {
		if (bReadable) {
			//Receive the response
			nRead = recvfrom(sockRaw, pRecvBuf, MAX_ICMP_PACKET_SIZE, 0, (sockaddr*) &from, &nFromlen);
		} else {
			closesocket(sockRaw);
			//delete [] pICMP;
			//delete [] pRecvBuf;
			//set the error to timed out
			SetLastError (WSAETIMEDOUT);
			return FALSE;
		}
	} else {
		//delete [] pICMP;
		//delete [] pRecvBuf;

		DWORD dwError = GetLastError();
		closesocket(sockRaw);
		SetLastError(dwError);
		return FALSE;
	}

	VERIFY(QueryPerformanceCounter(&TimerTick));

	if (nRead == QAbstractSocket_ERROR) {
		//delete [] pICMP;
		//#AP
		//delete [] pRecvBuf;
		DWORD dwError = GetLastError();
		closesocket(sockRaw);
		SetLastError(dwError);
		return FALSE;
	}

	BOOL bSuccess = DecodeResponse(pRecvBuf, nRead, &from);
	if (bSuccess) {
		pr.Address = from.sin_addr;
		pr.RTT = (ULONG)((TimerTick.QuadPart - nStartTick) * 1000 / sm_TimerFrequency);
	}

	closesocket(sockRaw);

	//Free up the memory we allocated
	//delete [] pICMP;
	//delete [] pRecvBuf;
	return bSuccess;

}

/***********************************************************************

 Method Name : GenerateIPChecksum()

 Description : Generate an IP checksum based on a given data buffer.
 
 

 Parameters : Parameter		In/Out	Description

 ***********************************************************************/

USHORT GenerateIPChecksum(USHORT *pBuffer, int nSize) {
	unsigned long cksum = 0;

	while (nSize > 1) {
		cksum += *pBuffer++;
		nSize -= sizeof(USHORT);
	}

	if (nSize)
		cksum += *(UCHAR*) pBuffer;

	cksum = (cksum >> 16) + (cksum & 0xffff);
	cksum += (cksum >> 16);
	return (USHORT)(~cksum);
}

/***********************************************************************

 Method Name : FillIcmpData()

 Description : Fill up the ICMP packet with defined values.
 
 

 Parameters : Parameter		In/Out	Description

 ***********************************************************************/

void FillIcmpData(LPICMP_HEADER pIcmp, int nData) {
	pIcmp->i_type = 8; //ICMP_ECHO type
	pIcmp->i_code = 0;
	pIcmp->i_id = (USHORT) getpid();
	pIcmp->i_seq = 0;
	pIcmp->i_cksum = 0;
	pIcmp->timestamp = GetTickCount();

	//Set up the data which will be sent
	int nHdrSize = sizeof(ICMP_HEADER);
	char *pData = ((char*) pIcmp) + nHdrSize;
	memset(pData, 'E', nData - nHdrSize);

	//Generate the checksum
	pIcmp->i_cksum = GenerateIPChecksum((USHORT*) pIcmp, nData);
}

/***********************************************************************

 Method Name : IsSocketReadible()

 Description : Check whether the socket is readable.
 
 

 Parameters : Parameter		In/Out	Description

 ***********************************************************************/

BOOL CPing::IsSocketReadible(QAbstractSocket socket, DWORD dwTimeout, BOOL &bReadible) {
	timeval timeout = { dwTimeout / 1000, dwTimeout % 1000 };
	fd_set fds;
	FD_ZERO(&fds);
	FD_SET(socket, &fds);
	int nStatus = select(0, &fds, NULL, NULL, &timeout);
	if (nStatus == QAbstractSocket_ERROR) {
		return FALSE;
	} else {
		bReadible = !(nStatus == 0);
		return TRUE;
	}
}

/***********************************************************************

 Method Name : DecodeResponse()

 Description : Decode the validity of the response received 
 from the host.
 
 

 Parameters : Parameter		In/Out	Description

 ***********************************************************************/

BOOL DecodeResponse(char *pBuf, int nBytes, sockaddr_in *from) {
	//Get the current tick count
	LARGE_INTEGER TimerTick;
	VERIFY(QueryPerformanceCounter(&TimerTick));

	LPIP_HEADER pIpHdr = (LPIP_HEADER) pBuf;
	int nIpHdrlen = pIpHdr->h_len * 4; //Number of 32-bit words*4 = bytes

	//Not enough data recieved
	if (nBytes < nIpHdrlen + MIN_ICMP_PACKET_SIZE) {
		qDebug(_T("Received too few bytes from %s\n"), inet_ntoa(from->sin_addr));
		SetLastError (ERROR_UNEXP_NET_ERR);
		return FALSE;
	}

	//Check it is an ICMP_ECHOREPLY packet
	LPICMP_HEADER pIcmpHdr = (LPICMP_HEADER)(pBuf + nIpHdrlen);
	if (pIcmpHdr->i_type != 0) //type ICMP_ECHOREPLY is 0
			{
		qDebug(_T("non-echo type %d recvd\n"), pIcmpHdr->i_type);
		SetLastError (ERROR_UNEXP_NET_ERR);
		return FALSE;
	}

	//Check it is the same id as we sent
	if (pIcmpHdr->i_id != (USHORT) getpid()) {
		qDebug(_T("Received someone else's packet!\n"));
		SetLastError (ERROR_UNEXP_NET_ERR);
		return FALSE;
	}

	return TRUE;
}


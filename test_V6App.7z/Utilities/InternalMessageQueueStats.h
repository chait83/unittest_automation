/// @file 
/// *****************************************************************
/// © Honeywell Trendview
/// *****************************************************************
/// @n Module : Module Message Manager (MMM )
/// @n FileName: InternalMessageQueueStats.cpp
/// @n Desc  : Declaration File for the CInternalMessageQueueStats Class
///  
/// *****************************************************************
/// @b Revision @b History
/// *****************************************************************
/// $Log[4]:
/// 4 Stability Project 1.1.1.1 7/2/2011 4:58:00 PM Hemant(HAIL) 
/// Stability Project: Recorder source has been upgraded from IL
///  version of firmware to JF version of firmware.
/// 3 Stability Project 1.1.1.0 7/1/2011 4:27:00 PM Hemant(HAIL) 
/// Stability Project: Files has been checked in before the merging
///  task. The merging will be done between IL version of firmware and JF
///  version of firmware. 
/// 2 V6 Firmware 1.1 8/25/2004 6:01:46 PM  Alistair Brugsch
///  Doxygen Updates
/// 1 V6 Firmware 1.0 8/24/2004 6:33:48 PM  Alistair Brugsch 
/// $
///

#ifndef _INTERNALMESSAGEQUEUESTATS_H
#define _INTERNALMESSAGEQUEUESTATS_H

//**Class*********************************************************************
///
/// @brief Data Storage Class for Internal Message Queue Statistical Data.  
/// 
/// Each Message Queue shall have the ability to record key information about 
/// the message queue operation. This will allow an insight to way in which 
/// the queue is being used within the system. This statistical data can be 
/// used to find problems within the system, and to fine tune the message queue 
/// to the way it is being used. A heavier used memory queue may require more 
/// heap memory to store messages, whereas message queue used infrequently may 
/// have lower memory requirements. 
///
/// @note Member variables declared public for speed of operation, recording
///		 statistic shall be as quick as possible to avoid loss of performance
///
//****************************************************************************
class CInternalMessageQueueStats {
public:

	/// Constructor
	CInternalMessageQueueStats(void);

	// Destructor
	virtual ~CInternalMessageQueueStats(void);

	ULONG m_IMQueueLoad;					 ///< Total Number of Messages in the Queue at any one time
	ULONG m_IMQTotalNumberOfMessagesProcessed; ///< Total Number of messages processed

};
// End of CInternalMessageQueueStats

#endif // _INTERNALMESSAGEQUEUESTATS_H

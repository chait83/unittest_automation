//////////////////////////////////////////////////////////////////////
/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Peer2Peer
/// @n Filename:  CESocket.cpp
/// @n Description: Implementation of the CCESocket class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log:
//  22  Aristos  1.12.1.6.1.1 9/23/2011 2:09:52 PM  Abhijeet(HAIL) 
//  Fixed firmware upgrade hang issue
//  21  Aristos  1.12.1.6.1.0 9/19/2011 4:51:10 PM  Hemant(HAIL)  
//  Stability recorder source code (JI Release) updated for WatchDog
//  Timer functionality.
//  20  Stability Project 1.12.1.6 8/10/2011 12:10:59 PM  Hemant(HAIL) 
// Fixed PAR # 1-KZRZXJ (Issue: SLowness in recorder app when sending
//  email)
//  19  Stability Project 1.12.1.5 7/11/2011 4:15:48 PM  Hemant(HAIL) 
// Files updated when fixing the Email Memory Leak Issue.
//  18  Stability Project 1.12.1.4 7/2/2011 4:55:58 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  17  Stability Project 1.12.1.3 7/1/2011 4:38:02 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  16  Stability Project 1.12.1.2 6/17/2011 7:08:18 PM  Hemant(HAIL) 
// Files updated for Email Memory Leak Issue.
//  (The issue has been found in MFC library when it is used in
//  application as a shared DLL and Thread(s) are ended with
//  ExitThread(). To fix this issue in email module, which creates and
//  ends the thread for each email, the email module does not end the
//  ReadThread and hence the memory drop is not observed) 
//  15  Stability Project 1.12.1.1 3/17/2011 3:20:13 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  14  Stability Project 1.12.1.0 2/15/2011 3:02:25 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
//  13  V6 Firmware 1.12 6/10/2010 12:47:12 PM  Karnav(HAIL)  
//  3136 - Removed initlaization and deletion of m_readLock critical
//  section from constructor and dctor.
//  12  V6 Firmware 1.11 5/25/2010 3:37:45 PM  Karnav(HAIL)  
//  Code uploaded as per andy's suggestion.
//  11  V6 Firmware 1.10 4/18/2010 2:21:54 PM  Nilesh(HAIL)  
//  Memory Leak while sending mail. This has fix proposed by both HAIL
//  and GA Digital
//  10  V6 Firmware 1.9 7/4/2007 5:11:32 PM Charles Boardman
//  Adding useful qDebug statements for identifying when a connect fails.
//  Can be turned on using TRACE_ALLOW.
//  9 V6 Firmware 1.8 6/19/2007 6:10:01 PM  Charles Boardman
//  Addressing build issues for TrendManager Suite.
//  8 V6 Firmware 1.7 6/18/2007 9:44:04 PM  Alistair Brugsch
//  added tracing and disable define
//  7 V6 Firmware 1.6 12/20/2006 5:00:44 PM  Roger Dawson  
//  Modified the connect call.
//  6 V6 Firmware 1.5 12/8/2006 8:56:31 PM  Alistair Brugsch
//  closed a shutdown memory leak if a packet has been received and not
//  picked up
//  5 V6 Firmware 1.4 11/28/2006 10:09:09 PM Alistair Brugsch
//  Tidied some CloseHandle()'s
//  4 V6 Firmware 1.3 11/21/2006 7:18:56 PM  Alistair Brugsch
//  removed un-necessary tracing
//  3 V6 Firmware 1.2 11/9/2006 4:38:39 PM  Charles Boardman
//  Improve string handling when deciding host name for internet
//  connection.
//  2 V6 Firmware 1.1 10/31/2006 10:19:48 PM Alistair Brugsch
//  modifications to support Peer to Peer and multcasting
//  1 V6 Firmware 1.0 7/12/2006 5:18:36 PM  Roger Dawson  no
//  comment!
// $
//
// **************************************************************************

// This Winsock Wrapper replaces all MFC socket classes (CSocket, CAsyncSocket
// CCeSocket). It offers async notifications, buffered read and easy data access
// functions.
//
// 
//
//////////////////////////////////////////////////////////////////////
//
//#include "ws2tcpip.h"

#include "CESocket.h"
#include <stdlib.h>

#include "ThreadInfo.h"
#include "..\SecureComm\V7TLSUtilities.h"

#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TRENDSERVERPRO ) )&& ( ! defined ( TRENDMANAGERPRO ) ) && ( ! defined ( P2P_WRAPPER ))
#include "StringUtils.h"
#endif

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif

//#define TRACE_ALLOW

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

//bool CCESocket::m_bWSAStarted = FALSE;
#ifdef _WCE_SECTION
	QMutex CCESocket::m_readLock;
#else
CCriticalSection CCESocket::m_readLock;
#endif

CCESocket::CCESocket() {
	WSADATA wsaData;

	s = INVALID_SOCKET;
	m_socketType = SOCK_STREAM;
	m_socketState = NONE;
	m_readThread = NULL;
	m_acceptThread = NULL;
	m_readThreadState = CLOSED;
	m_acceptThreadState = CLOSED;
	m_udpReadyToSend = FALSE;
	m_receiveAddrSz = sizeof(SOCKADDR_IN);
	m_eolasprintf = EOL_LFCR;
	m_errorCode = 0;
	m_recvBufSize = 0;
	m_ulPeer = 0;
	QMutex* m_csClosedown;
	m_hReadThreadEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
	m_availableData = 0;
	m_bIsDeleteCriticalSection = false;

	//
	// Stability Project Fix:
	//
	// This fix was done to avoid memory leak. The flags take care that the ReadThread does not exist
	// especially when messages like SendQuit are sent to the server and when we are creating the socket
	// The flag is set to false by default
	//
	m_bContinueReadThread = false;

	if (!m_bWSAStarted) {
		m_errorCode = WSAStartup(MAKEWORD(2, 2), &wsaData);
		if (m_errorCode == 0)
			m_bWSAStarted = TRUE;
	}
}

CCESocket::~CCESocket() {
	int watchDog;

//	HANDLE readThread, acceptThread;
// 	readThread = m_readThread;
// 	acceptThread = m_acceptThread;

	//
	// Stability Project Fix:
	//
	// Set the flag for continue read thread to false
	// The Read thread for email shall break when the destructor
	// for class CCESocket is called
	m_bContinueReadThread = false;

	//No need to close the mutex in Qt
	m_hReadThreadEvent = NULL;

	Disconnect();

	watchDog = 0;
	while (m_readThread) {
		SetThreadPriority(m_readThread, THREAD_PRIORITY_HIGHEST);
		if ((::WaitForSingleObject(m_readThread, 2000) != WAIT_TIMEOUT) || watchDog >= THREAD_TERMINATION_MAXWAIT) {
			m_csClosedown.lock();
			if (m_readThread) {
				//No need to close the mutex in Qt
				m_readThread = NULL;
			}
			m_csClosedown.lock();
		}
		watchDog++;
	}
	watchDog = 0;
	while (m_acceptThread) {
		SetThreadPriority(m_acceptThread, THREAD_PRIORITY_HIGHEST);
		if ((::WaitForSingleObject(m_acceptThread, 1000) != WAIT_TIMEOUT) || watchDog >= THREAD_TERMINATION_MAXWAIT) {
			m_csClosedown.lock();
			if (m_acceptThread) {
				//No need to close the mutex in Qt
				m_acceptThread = NULL;
			}
			m_csClosedown.lock();
		}
		watchDog++;
	}

#ifdef _WCE_SECTION
			EnterCriticalSection(&CCESocket::m_readLock);
#else
	CSingleLock csl(&CCESocket::m_readLock);
	csl.Lock();
#endif
	while (!m_ReadBuffer.IsEmpty()) {
		DataPacket *pPak = m_ReadBuffer.RemoveHead();
		delete[] pPak->buf;
		delete pPak;
	}
#ifdef _WCE_SECTION
			LeaveCriticalSection(&CCESocket::m_readLock);
#else
	csl.Unlock();
#endif
// 3136 - Deleted m_csClosedDown critical section

	//deletion of mutex not required
}

void CCESocket::SetBufferSize(int bufSize) {
	if (bufSize > 0)
		m_recvBufSize = bufSize;
}

bool CCESocket::Create(int socketType, int bufferSize) {
	BOOL dontLinger = TRUE;
	LINGER lingerOpt;

	//WSADATA wsaData;

	if (!m_bWSAStarted)
		return FALSE;

	//Exit if the socket has been already created
	if (s != INVALID_SOCKET) {
		m_errorCode = WSAEACCES;
		return FALSE;
	}

	switch (socketType) {
	case SOCK_STREAM:
		s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
		break;
	case SOCK_MCAST:
	case SOCK_DGRAM:
		s = socket(AF_INET, SOCK_DGRAM, 0);
		break;
	default:
		m_errorCode = WSAEINVAL;
		return FALSE;
	}

	if (s == INVALID_SOCKET) {
		m_errorCode = WSAGetLastError();
		return FALSE;
	}

	switch (socketType) {
	case SOCK_STREAM:
		lingerOpt.l_onoff = 0;
		lingerOpt.l_linger = 0;

		if (setsockopt(s, SOL_QAbstractSocket, SO_DONTLINGER, (char*) &dontLinger, sizeof(BOOL)) != 0) {
			m_errorCode = WSAGetLastError();
			closesocket(s);
			return FALSE;
		}

		if (setsockopt(s, SOL_QAbstractSocket, SO_LINGER, (char*) &lingerOpt, sizeof(LINGER)) != 0) {
			m_errorCode = WSAGetLastError();
			closesocket(s);
			return FALSE;
		}

		if (bufferSize == 0)
			bufferSize = TCPBUFFERSIZE;
		break;
	case SOCK_DGRAM:
	case SOCK_MCAST:
		if (bufferSize == 0)
			bufferSize = UDPBUFFERSIZE;
		m_udpReadyToSend = FALSE;
		break;
	}
	m_recvBufSize = bufferSize;

	while (!m_ReadBuffer.IsEmpty()) {
		DataPacket *pPak = m_ReadBuffer.RemoveHead();
		delete[] pPak->buf;
		delete pPak;
	}
	m_ReadBuffer.ClearData();
	m_availableData = 0;

	//OK, all done
	m_socketType = socketType;
	m_socketState = CREATED;
	return TRUE;
}

bool CCESocket::OnConnect(QString   &addr) {
	// Each derived object to implement 
	return (true);
}

//****************************************************************************
// bool CCESocket::Connect( QString  &addr, UINT remotePort)
///
/// ---Detailed Description of Member Function---
///
/// @param[in] 	  var1 - Brief Desciption in param
/// @param[in,out] var2 - Brief Desciption in out param
/// @param[out]  var3 - Brief Desciption, out param
///
/// @return ---Brief Desciption of Return Value---
/// 
/// @todo --- Add any todo's into the modules ---
///
/// @note --- Delete if not required ---
//****************************************************************************
bool CCESocket::Connect(QString   addr, UINT remotePort) {
	static const size_t MaxHostLen = 256;
	char hostStr[MaxHostLen + 1];
	ulong hostByIP;
	HOSTENT *hostByName;

	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//for the Email thread
#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TRENDSERVERPRO ) )&& ( ! defined ( TRENDMANAGERPRO ) ) && ( ! defined ( P2P_WRAPPER ))
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();

	if (pThreadInfo != NULL) {
		pThreadInfo->UpdateThreadCounter(AM_EMAIL_THREAD);
	}
#endif

	if (!m_bWSAStarted)
		return FALSE;

	//Make sure the socket was created
	if (s == INVALID_SOCKET) {
		m_errorCode = WSAENOTSOCK;
#if defined ( TRACE_ALLOW )
			qDebug( _T("(01) ERROR ERROR ERROR of (%d) in CCESocket::Connect\n"), m_errorCode );
#endif
		return FALSE;
	}

	//We cannot connect if the socket is already connected (TCP only)
	if (m_socketType == SOCK_STREAM && m_socketState > CREATED) {
		m_errorCode = WSAEISCONN;
#if defined ( TRACE_ALLOW )
			qDebug( _T("(02) ERROR ERROR ERROR of (%d) in CCESocket::Connect\n"), m_errorCode );
#endif
		return FALSE;
	}

	//We cannot connect if the socket is listening (UDP only)
	if ((m_socketType == SOCK_DGRAM || m_socketType == SOCK_MCAST) && m_socketState > CONNECTED) {
		m_errorCode = WSAEISCONN;
#if defined ( TRACE_ALLOW )
			qDebug( _T("(03) ERROR ERROR ERROR of (%d) in CCESocket::Connect\n"), m_errorCode );
#endif
		return FALSE;
	}

	//Check port values
	if (remotePort > 65535) {
		m_errorCode = WSAEINVAL;
#if defined ( TRACE_ALLOW )
			qDebug( _T("(04) ERROR ERROR ERROR of (%d) in CCESocket::Connect\n"), m_errorCode );
#endif
		return FALSE;
	}

#if defined ( _UNICODE )
	// Gets address string and convert it from unicode to multibyte
	int wHostLen;
	QString  wHost;

	wHostLen = addr.size();

	if ( wHostLen > MaxHostLen )
	{
		wHostLen = MaxHostLen;
	}
	wHost = addr.GetBuffer(wHostLen);

	// The Unicode way to do it.
	size_t pNoOfChars;
	wcstombs_s(&pNoOfChars, hostStr, sizeof(hostStr), wHost, MaxHostLen);
	addr.ReleaseBuffer();
#else
	// When not using Unicode a simple strcpy does the trick.
	strncpy(hostStr, addr, MaxHostLen);
#endif

	// The buffer with host string in gets terminated.
	hostStr[MaxHostLen] = 0;

	//Builds destination address
	memset(&m_remoteAddress, 0, sizeof(SOCKADDR_IN));
	m_remoteAddress.sin_family = AF_INET;
	m_remoteAddress.sin_port = htons(remotePort);

	hostByIP = inet_addr(hostStr);
	if (hostByIP == INADDR_NONE) {
		hostByName = gethostbyname(hostStr);
		if (hostByName == NULL) {
			m_errorCode = WSAGetLastError();
#if defined ( TRACE_ALLOW )
			qDebug( _T("(05) ERROR ERROR ERROR of (%d) in CCESocket::Connect\n"), m_errorCode );
#endif
			return FALSE;
		}
		m_remoteAddress.sin_addr = *((IN_ADDR*) hostByName->h_addr_list[0]);
	} else
		m_remoteAddress.sin_addr.s_addr = hostByIP;

	//Connects if TCP.
	//UDP is connectionless. However we'll use m_remoteAddress for sending data.
	if (m_socketType == SOCK_STREAM) {
		//Ignore the thread for Email as an incorrect remote address causes the 
		//Connect() call to wait till network timeout
#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TRENDSERVERPRO ) )&& ( ! defined ( TRENDMANAGERPRO ) ) && ( ! defined ( P2P_WRAPPER ))
		if (pThreadInfo != NULL) {
			pThreadInfo->UpdateThreadInfo(AM_EMAIL_THREAD, false);
		}
#endif
		if (connect(s, (SOCKADDR*) &m_remoteAddress, sizeof(SOCKADDR_IN)) != 0) {
			m_errorCode = WSAGetLastError();
#if defined ( TRACE_ALLOW )
			qDebug( _T("(06) ERROR ERROR ERROR of (%d) in CCESocket::Connect\n"), m_errorCode );
#endif
			//Ignore the thread for Email after connect as an incorrect remote address
			// can cause the Connect call to wait till network timeout
#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TRENDSERVERPRO ) )&& ( ! defined ( TRENDMANAGERPRO ) ) && ( ! defined ( P2P_WRAPPER ))
			if (pThreadInfo != NULL) {
				pThreadInfo->UpdateThreadInfo(AM_EMAIL_THREAD, true);
			}
#endif
			return FALSE;
		}

		if (OnConnect(addr) == false) {
			return FALSE;
		}

		//Consider the thread for Email after connect as an incorrect remote address
		// can cause the Connect call to wait till network timeout
#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TRENDSERVERPRO ) )&& ( ! defined ( TRENDMANAGERPRO ) ) && ( ! defined ( P2P_WRAPPER ))
		if (pThreadInfo != NULL) {
			pThreadInfo->UpdateThreadInfo(AM_EMAIL_THREAD, true);
		}
#endif
		m_socketState = CONNECTED;
		m_ulPeer = m_remoteAddress.sin_addr.S_un.S_addr;
		//TCP: Start reading thread
		//UDP: Can't start it now, we must first do a sendto to bind to a local port

		//
		// Stability Project Fix:
		//
		// Create a Read Thread only if no other ReadThread exists
		if (m_readThreadState == CLOSED) {
			m_readThreadState = RUNNING;
			m_readThread = CreateThread(NULL, 0, StartThread, this, 0, NULL);
		} else if (m_readThreadState == RUNNING) {
			//Signal the read thread to continue
			SetEvent(m_hReadThreadEvent);
		}
	} else {
		m_udpReadyToSend = TRUE;
		m_socketState = CONNECTED;
	}

	return TRUE;
}

void CCESocket::Disconnect() {
	if (!m_bWSAStarted || s == INVALID_SOCKET) {
		return;
	}
	//After a shutodown reading thread will self terminate
	//QString  csTmp;
	//csTmp.asprintf(_T("Disconnected from %X\n"),this->m_ulPeer);
	//qDebug(csTmp);
	m_socketState = DISCONNECTING;

	if (s != INVALID_SOCKET) {
		shutdown(s, SD_BOTH);
		closesocket(s);
		s = INVALID_SOCKET;
	}

	m_socketState = NONE;
	m_errorCode = 0;
	m_udpReadyToSend = FALSE;
}

//
// Stability Project Fix:
//
// This fix was done to avoid memory leak. The flags take care that the ReadThread does not exist
// especially when messages like SendQuit are sent to the server and when we are creating the socket
//
void CCESocket::SetSocketContinueReadThread(bool bContinueReadThread) {
	m_bContinueReadThread = bContinueReadThread;

}

//HAIL Addition
//[
void CCESocket::CloseConnection()

{
	int watchDog;
	watchDog = 0;

	while (m_readThread) {
		SetThreadPriority(m_readThread, THREAD_PRIORITY_HIGHEST);
		if ((::WaitForSingleObject(m_readThread, 2000) != WAIT_TIMEOUT) || watchDog >= THREAD_TERMINATION_MAXWAIT) {
			m_csClosedown.lock();
			if (m_readThread) {
				TerminateThread(m_readThread, NULL);
				//No need to close the mutex in Qt
				m_readThread = NULL;
			}

			m_csClosedown.lock();
		}
		watchDog++;
	}

	watchDog = 0;

	while (m_acceptThread) {
		SetThreadPriority(m_acceptThread, THREAD_PRIORITY_HIGHEST);
		if ((::WaitForSingleObject(m_acceptThread, 1000) != WAIT_TIMEOUT) || watchDog >= THREAD_TERMINATION_MAXWAIT) {
			m_csClosedown.lock();
			if (m_acceptThread) {
				TerminateThread(m_acceptThread, NULL);  //Coverity Fix: copy paste error
				//No need to close the mutex in Qt
				m_acceptThread = NULL;
			}

			m_csClosedown.lock();
		}
		watchDog++;
	}

}

//]

int CCESocket::Send(QString   &str) {
	int sentBytes, len;
	char *buf;
	QString   strBuf;

	len = str.size();
	strBuf = str.GetBuffer(len);
#ifdef _WIN32_WCE
	buf = new char[len];
	size_t pNoOfChars;
	wcstombs_s(&pNoOfChars,buf, len, strBuf, len);
#else
	buf = (char*) strBuf;
#endif

	sentBytes = Send(buf, len);

#ifdef _WIN32_WCE
	delete[] buf;
#endif

	return sentBytes;
}

int CCESocket::SendLine(QString   &str) {
	int sentBytes, len;
	char *buf;
	QString   strBuf;

	len = str.size();
	strBuf = str.GetBuffer(len);
	buf = new char[len + 2];
#ifdef _WIN32_WCE
	size_t pNoOfChars;
	wcstombs_s(&pNoOfChars ,buf, len+2, strBuf, len);
#else
	memcpy(buf, strBuf, len);
#endif

	switch (m_eolasprintf) {
	case EOL_LFCR:
		buf[len] = '\r';
		buf[len + 1] = '\n';
		sentBytes = Send(buf, len + 2);
		break;
	case EOL_CR:
		buf[len] = '\n';
		sentBytes = Send(buf, len + 1);
		break;
	case EOL_NULL:
		buf[len] = '\0';
		sentBytes = Send(buf, len + 1);
		break;
	}

	delete[] buf;
	return sentBytes;
}

int CCESocket::Send(const char *buf, int len) {
	int dataPtr = 0;
	int sentBytes = 0;
#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TRENDSERVERPRO ) )&& ( ! defined ( TRENDMANAGERPRO ) ) && ( ! defined ( P2P_WRAPPER ))
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
#endif
	if (!m_bWSAStarted)
		return QAbstractSocket_ERROR;

	//We cannot send data if the socket's not connected
	if (m_socketState < CONNECTED) {
		m_errorCode = WSAENOTCONN;
		return QAbstractSocket_ERROR;
	}

	//TCP listening socket cannot send data
	if (m_socketState == ACCEPTING && m_socketType == SOCK_STREAM) {
		m_errorCode = WSAENOTCONN;
		return QAbstractSocket_ERROR;
	}

	//Have we a valid buffer?
	if (!buf || len <= 0) {
		m_errorCode = WSAEFAULT;
		return QAbstractSocket_ERROR;
	}

	int cnt = 0;
	switch (m_socketType) {
	case SOCK_STREAM:
		while (len > 0) {
			// shankar for email - begin
#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TRENDSERVERPRO ) )&& ( ! defined ( TRENDMANAGERPRO ) ) && ( ! defined ( P2P_WRAPPER ))
			if (pThreadInfo != NULL) {
				pThreadInfo->UpdateThreadInfo(AM_EMAIL_THREAD, false);
				pThreadInfo->UpdateThreadInfo(AM_QAbstractSocket_READ_THREAD, false);
			}
#endif
			// shankar for email - end

			sentBytes = send(s, &buf[dataPtr], len, 0);

			// shankar for email - begin
#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TRENDSERVERPRO ) )&& ( ! defined ( TRENDMANAGERPRO ) ) && ( ! defined ( P2P_WRAPPER ))
			if (pThreadInfo != NULL) {
				pThreadInfo->UpdateThreadInfo(AM_EMAIL_THREAD, true);
				pThreadInfo->UpdateThreadInfo(AM_QAbstractSocket_READ_THREAD, true);
			}
#endif
			// shankar for email - end

			if (sentBytes == QAbstractSocket_ERROR) {
				m_errorCode = WSAGetLastError();
				return QAbstractSocket_ERROR;
			}
			dataPtr += sentBytes;
			len -= sentBytes;
#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TRENDSERVERPRO ) )&& ( ! defined ( TRENDMANAGERPRO ) ) && ( ! defined ( P2P_WRAPPER ))
			if (pThreadInfo != NULL) {
				//Update the counter for the Email thread and also
				//the Socket Read thread as this method is called
				//through both the threads
				pThreadInfo->UpdateThreadCounter(AM_EMAIL_THREAD);
				pThreadInfo->UpdateThreadCounter(AM_QAbstractSocket_READ_THREAD);
			}
#endif
		}
		break;
	case SOCK_MCAST:
	case SOCK_DGRAM:
		if (m_udpReadyToSend) {
			while (len > 0) {
				if (m_socketState == ACCEPTING && m_socketType == SOCK_DGRAM)
					sentBytes = sendto(s, &buf[dataPtr], len, 0, (SOCKADDR*) &m_localAddress, sizeof(m_localAddress));
				else
					sentBytes = sendto(s, &buf[dataPtr], len, 0, (SOCKADDR*) &m_remoteAddress, sizeof(m_remoteAddress));
				if (sentBytes == QAbstractSocket_ERROR) {
					m_errorCode = WSAGetLastError();
					return QAbstractSocket_ERROR;
				}
				dataPtr += sentBytes;
				len -= sentBytes;
#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TRENDSERVERPRO ) )&& ( ! defined ( TRENDMANAGERPRO ) ) && ( ! defined ( P2P_WRAPPER ))
				if (pThreadInfo != NULL) {
					//Update the counter for the Email thread and also
					//the Socket Read thread as this method is called
					//through both the threads
					pThreadInfo->UpdateThreadCounter(AM_EMAIL_THREAD);
					pThreadInfo->UpdateThreadCounter(AM_QAbstractSocket_READ_THREAD);
				}
#endif			
			}

			//In client mode: after the first sendto we can start the reading thread
			//because we now have an implicit bind on a local port
			//In server mode: the thread is already running so this if is never true.
			if (m_readThreadState == CLOSED) {
				m_readThreadState = RUNNING;
				m_readThread = CreateThread(NULL, 0, StartThread, this, 0, NULL);
			}
		}
	}

	return dataPtr;
}

bool CCESocket::Accept(UINT localPort, int maxConn, BOOL bSuspend) {
	if (!m_bWSAStarted)
		return FALSE;

	//Make sure the socket was created
	if (s == INVALID_SOCKET) {
		m_errorCode = WSAENOTSOCK;
		return FALSE;
	}

	//We cannot connect if the socket is already connected or accepting
	if (m_socketState > CREATED) {
		m_errorCode = WSAEISCONN;
		return FALSE;
	}

	//Check port values
	if (localPort > 65535) {
		m_errorCode = WSAEINVAL;
		return FALSE;
	}

	memset(&m_localAddress, 0, sizeof(SOCKADDR_IN));
	m_localAddress.sin_family = AF_INET;
	m_localAddress.sin_port = htons(localPort);
	m_localAddress.sin_addr.s_addr = htonl(INADDR_ANY);

	if (bind(s, (SOCKADDR*) &m_localAddress, sizeof(SOCKADDR_IN)) == QAbstractSocket_ERROR) {
		m_errorCode = WSAGetLastError();
		return FALSE;
	}

	//UDP needs only bind
	if (m_socketType == SOCK_DGRAM || m_socketType == SOCK_MCAST) {
		m_socketState = ACCEPTING;
		m_udpReadyToSend = FALSE;
		//Start reading thread
		m_readThread = CreateThread(NULL, 0, StartThread, this, (bSuspend) ? CREATE_SUSPENDED : 0, NULL);
		return TRUE;
	}

	//The following is TCP listen + accept code

	if (listen(s, maxConn) == QAbstractSocket_ERROR) {
		m_errorCode = WSAGetLastError();
		return FALSE;
	}

	m_socketState = ACCEPTING;
	m_acceptThread = CreateThread(NULL, 0, StartThread, this, (bSuspend) ? CREATE_SUSPENDED : 0, NULL);

	return TRUE;
}

void CCESocket::AcceptServiceSocket(QAbstractSocket serviceSocket, BOOL bSuspend) {
	SOCKADDR_IN peerName;
	int nameSize = sizeof(SOCKADDR_IN);

	//Is it a valid socket?
	if (serviceSocket == INVALID_SOCKET)
		return;

	//Is it connected?
	if (getpeername(serviceSocket, (SOCKADDR*) &peerName, &nameSize) == QAbstractSocket_ERROR) {
		shutdown(serviceSocket, SD_BOTH);
		closesocket(serviceSocket);
		return;
	}

	Disconnect();
	s = serviceSocket;

	if (m_recvBufSize == 0)
		m_recvBufSize = TCPBUFFERSIZE;

	m_socketState = CONNECTED;
	m_ulPeer = peerName.sin_addr.S_un.S_addr;
	m_readThread = CreateThread(NULL, 0, StartThread, this, (bSuspend) ? CREATE_SUSPENDED : 0, NULL);
}

DWORD WINAPI CCESocket::StartThread(LPVOID pParam) {
	CCESocket *parent = (CCESocket*) pParam;

	if (parent->m_socketState == ACCEPTING && parent->m_socketType == SOCK_STREAM)
		parent->AcceptThread();
	else
		parent->ReadThread();

	return 0;
}
void CCESocket::AcceptThread() {
	QAbstractSocket serviceSocket;

	m_acceptThreadState = RUNNING;

	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//after each iteration
#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TRENDSERVERPRO ) )&& ( ! defined ( TRENDMANAGERPRO ) ) && ( ! defined ( P2P_WRAPPER ))
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();

	if (pThreadInfo != NULL) {

		//Notify the WatchdogTimer that the Accept thread has 
		//started
		pThreadInfo->UpdateThreadInfo(AM_ACCEPT_THREAD, true);
		pThreadInfo->UpdateThreadCounter(AM_ACCEPT_THREAD);
	}
#endif
	do {
		memset(&m_remoteAddress, 0, sizeof(SOCKADDR_IN));
#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TRENDSERVERPRO ) )&& ( ! defined ( TRENDMANAGERPRO ) ) && ( ! defined ( P2P_WRAPPER ))
		if (pThreadInfo != NULL) {
			//Ignore the Accept thread after accept() as an incorrect remote address
			//can cause the Connect call to wait till network timeout
			pThreadInfo->UpdateThreadInfo(AM_ACCEPT_THREAD, false);
		}
#endif
		serviceSocket = accept(s, (SOCKADDR*) &m_remoteAddress, &m_receiveAddrSz);
#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TRENDSERVERPRO ) )&& ( ! defined ( TRENDMANAGERPRO ) ) && ( ! defined ( P2P_WRAPPER ))
		if (pThreadInfo != NULL) {
			//Consider the Accept thread after accept() as an incorrect remote address
			//can cause the Connect call to wait till network timeout
			pThreadInfo->UpdateThreadInfo(AM_ACCEPT_THREAD, true);
		}
#endif

		if (serviceSocket == QAbstractSocket_ERROR) {
			m_errorCode = WSAGetLastError();
#if defined ( TRACE_ALLOW )
			qDebug( _T("ERROR ERROR ERROR of (%d) in CCESocket::AcceptThread\n"), m_errorCode );
#endif
			break;
		}
#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TRENDSERVERPRO ) )&& ( ! defined ( TRENDMANAGERPRO ) ) && ( ! defined ( P2P_WRAPPER ))
		if (pThreadInfo != NULL) {
			//Update the Thread Counter for the Socket Accept
			//thread 
			pThreadInfo->UpdateThreadCounter(AM_ACCEPT_THREAD);
		}
#endif

		//Accepts a new connection
		if (!OnAccept(serviceSocket)) {
			shutdown(serviceSocket, SD_BOTH);
			closesocket(serviceSocket);
		}
#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TRENDSERVERPRO ) )&& ( ! defined ( TRENDMANAGERPRO ) ) && ( ! defined ( P2P_WRAPPER ))
		if (pThreadInfo != NULL) {
			//Update the Thread Counter for the Socket Accept
			//thread 
			pThreadInfo->UpdateThreadCounter(AM_ACCEPT_THREAD);
		}
#endif
	} while (m_acceptThreadState == RUNNING);

	m_acceptThreadState = CLOSING;
	if (m_socketState > DISCONNECTING) {
		Disconnect();
		OnClose(EVN_SERVERDOWN);
	}
	// Self terminate the thread
	m_acceptThreadState = CLOSED;
	m_csClosedown.lock();
	if (m_acceptThread) {
		//No need to close the mutex in Qt
		m_acceptThread = NULL;
	}
	m_csClosedown.lock();
	ExitThread (WM_QUIT);
#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TRENDSERVERPRO ) )&& ( ! defined ( TRENDMANAGERPRO ) ) && ( ! defined ( P2P_WRAPPER ))
	if (pThreadInfo != NULL) {
		//Update the Thread Counter for the Socket Accept
		//thread
		pThreadInfo->UpdateThreadInfo(AM_ACCEPT_THREAD, false);
	}
#endif
}
// Read any incoming data as well as detect the connected lost/reset
void CCESocket::ReadThread() {
	int bytesRead = 0;
	int bufSize = 0;
	DataPacket *data;
	char *buf = NULL;

	m_readThreadState = RUNNING;

	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//after each iteration
#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TRENDSERVERPRO ) )&& ( ! defined ( TRENDMANAGERPRO ) ) && ( ! defined ( P2P_WRAPPER ))
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();

	if (pThreadInfo != NULL) {

		//Notify the WatchdogTimer that the Socket Read thread has 
		//started
		pThreadInfo->UpdateThreadInfo(AM_QAbstractSocket_READ_THREAD, true);

		pThreadInfo->UpdateThreadCounter(AM_QAbstractSocket_READ_THREAD);
	}
#endif
	do
	{
		//m_recvBuffSize can change dynamically so we must track its changes
		bufSize = m_recvBufSize;
		if (buf == NULL) {
			buf = new char[bufSize];
		}
		//Blocking receive
		switch (m_socketType) {
		case SOCK_STREAM:
#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TRENDSERVERPRO ) )&& ( ! defined ( TRENDMANAGERPRO ) ) && ( ! defined ( P2P_WRAPPER ))
			if (pThreadInfo)
				pThreadInfo->UpdateThreadInfo(AM_QAbstractSocket_READ_THREAD, false);
#endif
			// Stability Project Fix: Email memory Issue
			if (m_socketState == CONNECTED)
				bytesRead = recv(s, buf, bufSize, 0);
			else
				bytesRead = 0;

			// shankar - UpdateThreadInfo after break is never going to work, moving it above break
#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TRENDSERVERPRO ) )&& ( ! defined ( TRENDMANAGERPRO ) ) && ( ! defined ( P2P_WRAPPER ))
			if (pThreadInfo)
				pThreadInfo->UpdateThreadInfo(AM_QAbstractSocket_READ_THREAD, true);
#endif
			break;
			//if ( pThreadInfo )
			//	pThreadInfo->UpdateThreadInfo(AM_QAbstractSocket_READ_THREAD,true);
		case SOCK_MCAST:
			m_udpReadyToSend = TRUE;
			//fallthrough intended here 
		case SOCK_DGRAM:
#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TRENDSERVERPRO ) )&& ( ! defined ( TRENDMANAGERPRO ) ) && ( ! defined ( P2P_WRAPPER ))
			if (pThreadInfo)
				pThreadInfo->UpdateThreadInfo(AM_QAbstractSocket_READ_THREAD, false);
#endif
			bytesRead = recvfrom(s, buf, bufSize, 0, (SOCKADDR*) &m_localAddress, &m_receiveAddrSz);
#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TRENDSERVERPRO ) )&& ( ! defined ( TRENDMANAGERPRO ) ) && ( ! defined ( P2P_WRAPPER ))
			if (pThreadInfo)
				pThreadInfo->UpdateThreadInfo(AM_QAbstractSocket_READ_THREAD, true);
#endif
			break;
		}
		//If there was an error exit thread and notify owner with OnClose
		if(bytesRead == QAbstractSocket_ERROR || bytesRead <= 0)
		{
			m_errorCode = WSAGetLastError();
#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TRENDSERVERPRO ) ) && ( ! defined ( TRENDMANAGERPRO ) ) &&  ( ! defined ( TRENDVIEWER ) ) && ( ! defined ( P2P_WRAPPER ) )
#ifdef TRACE_ALLOW
			QString  csAddr;
			csAddr = CStringUtils::PackedIPv4ULongToStr(m_ulPeer);
			qDebug("Socket Read error: %d on socket %s\n",m_errorCode,csAddr);
#endif
#endif
			m_udpReadyToSend = FALSE;
			//This happens when we try to sendto data to a client host that closed its receiving
			//port. In this case we restart revfrom preventing further sendto until a new
			//request from a client host.
			if ((m_socketType == SOCK_DGRAM || m_socketType == SOCK_MCAST) && m_errorCode == WSAECONNRESET
					&& m_socketState == ACCEPTING) {
				delete[] buf;
				buf = NULL;
				//Notify that a remote connection closed
				OnClose(EVN_CONNLOST);

				continue;
			}
			//
			// Stability Project Fix:
			//
			// This fix was done to avoid memory leak. The flags take care that the ReadThread does not exit
			// especially when messages like SendQuit are sent to the server and when we are creating the socket	
			if((m_bContinueReadThread == true))
			{
				if(m_socketState != CONNECTED)
				{
					//The socket is not connected hence we are not sending mails.
					//Wait till the socket is connected 
#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TRENDSERVERPRO ) )&& ( ! defined ( TRENDMANAGERPRO ) ) && ( ! defined ( P2P_WRAPPER ))
					if (pThreadInfo != NULL) {
						//Inform the WatchDogTimer to ignore the read thread as it
						//is waiting infinitely
						pThreadInfo->UpdateThreadInfo(AM_QAbstractSocket_READ_THREAD, false);
					}
#endif
					if(::WaitForSingleObject(m_hReadThreadEvent,INFINITE)== WAIT_OBJECT_0)
					{
						ResetEvent(m_hReadThreadEvent);
#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TRENDSERVERPRO ) )&& ( ! defined ( TRENDMANAGERPRO ) ) && ( ! defined ( P2P_WRAPPER ))
					if(pThreadInfo != NULL)
{
	//Inform the WatchDogTimer to consider the read thread as it
	//the e 
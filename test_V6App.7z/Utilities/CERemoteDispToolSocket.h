/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  CERemoteDispToolSocket 
/// @n Filename:  CERemoteDispToolSocket.h
/// @n Description: This class is responsible for communication of recorder and
/// RDT tool
///
// **************************************************************************

#include "CESocket.h"

class CERemoteDispToolSocket: public CCESocket {
public:
	CERemoteDispToolSocket();
	virtual ~CERemoteDispToolSocket();
	bool SendRDT();
	virtual bool OnAccept(QAbstractSocket serviceSocket);
	virtual void OnClose(int closeEvent);
	void Disconnect();

	int Send(const char *buf, int len);

	//!Starts the read thread for RDT
	void AcceptRdtSocket(QAbstractSocket serviceSocket);

private:
	QString   GetModelNumber();

protected:
	threadState m_rdtThreadState;
	QAbstractSocket m_rdtSocket;
	HANDLE m_rdtThread;
	socketState m_rdtsocketState;
	void RdtThread();static DWORD WINAPI StartRdtThread(LPVOID pParam);
};

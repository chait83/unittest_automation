/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	Utilities
/// @n Filename:	MathUtils.h
/// @n Description: Definition of general utility class providing math functions
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 3	Stability Project 1.0.1.1	7/2/2011 4:58:35 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 2	Stability Project 1.0.1.0	7/1/2011 4:27:32 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 1	V6 Firmware 1.0		6/8/2005 4:53:19 PM	Roger Dawson	
// $
//
// **************************************************************************

#pragma once

#include "V6defines.h"
#include "V6Config.h"

//**CMathUtils*********************************************************************
///
/// @brief General utility class containing static maths helper functions
/// 
/// General utility class containing static maths helper functions
///
//****************************************************************************
class CMathUtils {
public:
	// Constructor
	CMathUtils(void);

	// Destructor
	~CMathUtils(void);

	// Method that creates an appropriately formatted scale string
	static void InitNumberasprintf(T_NUMFORMAT &Numberasprintf, QString   pasprintfStr, INT pasprintfStrBuffSize,
			const T_SCALEINFO *const ScaleDetails);

	// Static helper method that returns a bit mask for a USHORT given the passed in instance number
	static const USHORT Get16BitMask(const USHORT usINSTANCE_NO, USHORT &rusUShortArrayPos);

	// Static helper method that returns a bit mask for a ULONG given the passed in instance number
	static const ULONG Get32BitMask(const USHORT usINSTANCE_NO, USHORT &rusULongArrayPos);
};

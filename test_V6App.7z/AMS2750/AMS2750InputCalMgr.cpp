/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 AMS2750 input calibration manager
/// @n Filename:  AMS2750InputCalMgr.cpp
/// @n Description: implementation of the AMS2750InputCalMgr class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:$
//
// **************************************************************************

#include "V6defines.h"
#include "AMS2750InputCalMgr.h"
#include "V6MessageBoxDlg.h"
#include "V6globals.h"
#include "ams2750InputCalDlg.h"
#include "StatusAMS2750Dlg.h"
#include "PPIOServiceManager.h"
#include "InputConditioning.h"
#include "AMS2750BuildCalFile.h"
#include "IOSetupConfig.h"
#include "StringUtils.h"

bool CAMS2750InputCalMgr::m_bInMemoryCalInit = false;
T_AMS2750GENCAL CAMS2750InputCalMgr::m_tGeneralCalData;
T_SENSORINPUTCALDATA CAMS2750InputCalMgr::m_tSensorInputCalData[NUM_TCS_PER_SOAK];

const int CAMS2750InputCalMgr::MIN_REQUIRED_SENSORS = 1;

//****************************************************************************
///
/// Constructor
///
/// @param[in]			CWidget* pParent - Pointer to the parent dialog
///
//****************************************************************************
CAMS2750InputCalMgr::CAMS2750InputCalMgr() {
}

//****************************************************************************
///
/// Destructor
///
//****************************************************************************
CAMS2750InputCalMgr::~CAMS2750InputCalMgr(void) {
}
//****************************************************************************
///
/// Initialises the sensor calibration structure (as used by the in-progress status list)
///
/// @param[in]			T_PAMS2750CALCFG ptModifiableCalConfig - the current modifiable calibration config
/// @param[in]			T_PAMS2750SENSORS ptModifiableSensors - the current modifiable sensor configuration
/// @param[in/out]		T_IN_PROGRESS_SENSOR_CAL_STATUS *ptCalStatus - the in-progress cal state to initialise
///
/// @returns			true if the initialisation was successful, false if not
///
//****************************************************************************
const bool CAMS2750InputCalMgr::InitSensorInputCalStruct(T_PAMS2750CALCFG ptModifiableCalConfig,
		T_PAMS2750SENSORS ptModifiableSensors, T_IN_PROGRESS_INPUT_CAL_STATUS *ptCalStatus) {
	bool initialised = true;

	CAMS2750TUSMgr *pkTUSMgr = CAMS2750TUSMgr::Instance();
	CPPIOServiceManager *pServiceManagerObj = CPPIOServiceManager::GetHandle();
	CInputConditioning *pICService = pServiceManagerObj->GetICService();

	T_AMS2750SENSORS *ptCommittedSensors = pSETUP->GetIOSetupConfig()->GetAMS2750SensorBlock(CONFIG_COMMITTED);

	// get the number of calibration points
	ptCalStatus->NoOfCalTemps = ptModifiableCalConfig->CalElements;
	ptCalStatus->NoOfCompleteCalTemps = 0;
	ptCalStatus->NoOfSensors = 0;

	ptCalStatus->analogueInDataItems = NULL;
	USHORT slotNo;
	USHORT chanNo;

	// loop through each sensor for each cal point
	for (USHORT sensorNo = 0; sensorNo < MAX_ANALOGUE_IN; sensorNo++) {
		T_AMS2750SENSOR *ptSensor = &(ptModifiableSensors->Sensors[sensorNo]);

		T_PAICHANNEL ptModifiableAnalogueData = GetAnalogueInput(sensorNo, CONFIG_MODIFIABLE, slotNo, chanNo);

		// check this is a working sensor and the type hasn't changed and it is currently configured for TUS or usage tracking
		if (SensorInputOkForCal(sensorNo, ptModifiableSensors, ptCommittedSensors)) {
			// this is another valid cal point
			ptCalStatus->NoOfSensors++;
		}
	}

	// before proceeding, check there is at least one sensor to calibrate
	if (ptCalStatus->NoOfSensors >= MIN_REQUIRED_SENSORS) {
		ptCalStatus->calTemps = new float[ptModifiableCalConfig->CalElements];

		ptCalStatus->analogueInDataItems = new CDataItem*[ptCalStatus->NoOfSensors];

		// allocate the correct cal status array size
		ptCalStatus->calStatusList = new T_INPUT_CAL_STATUS[ptCalStatus->NoOfSensors * ptCalStatus->NoOfCalTemps];

		T_INPUT_CAL_STATUS *ptCurrCalStatus = ptCalStatus->calStatusList;
		bool initialCalPoint = true;
		int penIndex = 0;

		// now go through it all again and populate the information
		// loop through all the cal points
		for (int calPoint = 0; calPoint < ptModifiableCalConfig->CalElements; calPoint++) {
			float calTemp = ptModifiableCalConfig->CalPoints[calPoint].CalPoint;

			// set the next cal point temperature
			ptCalStatus->calTemps[calPoint] = calTemp;

			for (USHORT sensorNo = 0; sensorNo < MAX_ANALOGUE_IN; sensorNo++) {
				// check this is a working sensor and the type hasn't changed and it is currently configured for TUS or usage tracking
				if (SensorInputOkForCal(sensorNo, ptModifiableSensors, ptCommittedSensors)) {
					// update the pen data item if this is the first cal point
					if (initialCalPoint) {
						if (pkTUSMgr->IsInDemoMode() == TRUE) {
							// Demo mode, take form Pen instead of AI.
							ptCalStatus->analogueInDataItems[penIndex] = pGlbDIT->GetDataItemPtr(DI_PEN, 0, sensorNo);
						} else {
							ptCalStatus->analogueInDataItems[penIndex] = pGlbDIT->GetDataItemPtr(DI_IO, DI_IO_ANALOGUE,
									sensorNo);
						}

						// move the pen index on
						penIndex++;
					}

					ptCurrCalStatus->sensorNo = sensorNo;
					ptCurrCalStatus->calTemperature = calTemp;

					// the next 4 values will all be using committed calibration values
					// get the input adjustment first (sensor compensation in the menu's, not AMS specific)
					float inputAdjustedReading = 0.0f;
					T_PAICHANNEL ptModifiableAnalogueData = GetAnalogueInput(sensorNo, CONFIG_MODIFIABLE, slotNo,
							chanNo);
					pICService->PerformOutputAdjust(ptCurrCalStatus->calTemperature, slotNo, chanNo,
							&inputAdjustedReading);

					// set the input adjustment
					ptCurrCalStatus->currInputAdjust = inputAdjustedReading - ptCurrCalStatus->calTemperature;

					float calAdjustedReading = pSYSTEM_INFO->GetDegCTempFromLocalRelative(
							pkTUSMgr->GetCalAdjustedSensorReadingUsingInstanceNo(ptCurrCalStatus->sensorNo,
							pSYSTEM_INFO->GetLocalTempFromDegC(ptCurrCalStatus->calTemperature)));

					// set the cal adjustment (TC cable)
					ptCurrCalStatus->currCalAdjust = calAdjustedReading - ptCurrCalStatus->calTemperature;

					ptCurrCalStatus->currTotalAdjust = ptCurrCalStatus->currInputAdjust
							+ ptCurrCalStatus->currCalAdjust;

					// now we are moving onto what will be the new values so simply set to the existing values for now so we can 
					// stop the cal before all cal temps complete in test mode
					ptCurrCalStatus->newInputAdjust = ptCurrCalStatus->currInputAdjust;
					ptCurrCalStatus->newTotalAdjust = ptCurrCalStatus->currTotalAdjust;
					ptCurrCalStatus->currMeasuredTemp = 0.0f;
					ptCurrCalStatus->currMeasuredTempRaw = 0.0f;
					ptCurrCalStatus->passed = false;

					++ptCurrCalStatus;
				}
			}
			initialCalPoint = false;
		}
	} else {
		// not enough sensors, do not proceed
		initialised = false;
	}
	return initialised;
}
//****************************************************************************
///
/// Confirms the sensor input can be cal'ed as an AMS2750 sensor
///
/// @param[in]			int sensorNo - the sensor number
/// @param[in]			T_PAMS2750SENSORS ptModifiableSensors - the current modifiable sensor configuration
/// @param[in]			T_PAMS2750SENSORS ptCommittedSensors - the current committed sensor configuration
///
//****************************************************************************
bool CAMS2750InputCalMgr::SensorInputOkForCal(int sensorNo, T_PAMS2750SENSORS ptModifiableSensors,
		T_PAMS2750SENSORS ptCommittedSensors) {
	USHORT slotNo, chanNo;

	T_AMS2750SENSOR *ptModifiableSensor = &(ptModifiableSensors->Sensors[sensorNo]);
	T_AMS2750SENSOR *ptCommittedSensor = &(ptCommittedSensors->Sensors[sensorNo]);
	T_PAICHANNEL ptModifiableAnalogueData = GetAnalogueInput(sensorNo, CONFIG_MODIFIABLE, slotNo, chanNo);
	T_PAICHANNEL ptCommittedAnalogueData = GetAnalogueInput(sensorNo, CONFIG_COMMITTED, slotNo, chanNo);

	const bool isProcessMode = pSYSTEM_INFO->FWOptionAMS2750ProcessAvailable();

	return (ptModifiableSensor != NULL) && (ptCommittedSensor != NULL) && (ptModifiableAnalogueData != NULL)
			&& (ptCommittedAnalogueData != NULL) && (ptModifiableAnalogueData->Enabled == TRUE)
			&& (ptCommittedAnalogueData->Enabled == TRUE)
			&& (ptCommittedAnalogueData->Type == ptModifiableAnalogueData->Type)
			&& (((ptCommittedAnalogueData->Type == AI_CHANNEL_TYPE_TC)
					&& (ptCommittedAnalogueData->TC.SelectedTC == ptModifiableAnalogueData->TC.SelectedTC))
					|| ((ptCommittedAnalogueData->Type == AI_CHANNEL_TYPE_RT)
							&& (ptCommittedAnalogueData->RT.SelectedRT == ptModifiableAnalogueData->RT.SelectedRT)))
			&& CAMS2750TUSMgr::CanBeConfiguredAsAMS2750Sensor(ptModifiableAnalogueData)
			&& CAMS2750TUSMgr::CanBeConfiguredAsAMS2750Sensor(ptCommittedAnalogueData)
			&& ((ptModifiableSensor->TUSTC == TRUE) || isProcessMode)
			&& ((ptCommittedSensor->TUSTC == TRUE) || isProcessMode);
}
//****************************************************************************
///
/// Method used to update the sensor input calibration values
///
/// @param[in]			T_IN_PROGRESS_SENSOR_CAL_STATUS *ptCalStatus - the in-progress cal state
///
//****************************************************************************
void CAMS2750InputCalMgr::UpdateSensorInputCalValues(T_IN_PROGRESS_INPUT_CAL_STATUS *ptCalStatus) {
	BOOL allSensorsPass = true;

	// we now need to loop through all the sensors updating their multi-point cal settings - also check for temperatures
	// in which case we need to update the previous values with the current

	T_AICHANNEL *ptModifiableAnalogueData = NULL;
	T_AICHANNEL *ptCommittedAnalogueData = NULL;
	USHORT usChanNo;
	USHORT usSlotNo;

	CTVtime currentTime;
	currentTime.TimeNow();
	ULONG calTimeInSeconds = (ULONG) currentTime.GetSeconds();

	// Get the demo channel information
	CIOSetupConfig *pkIOSetupCfg = pSETUP->GetIOSetupConfig();

	T_PMPCALCHANNELS ptModifiableMPChannels = pkIOSetupCfg->GetMultiPointBlock(CONFIG_MODIFIABLE);
	T_PMPCALCHANNELS ptCommittedMPChannels = pkIOSetupCfg->GetMultiPointBlock(CONFIG_COMMITTED);

	CGeneralSetupConfig *pkGenCfg = pSETUP->GetGeneralSetupConfig();
	T_AMS2750CALCFG *ptCalConfig = pkGenCfg->GetAMS2750CalibrationBlock(CONFIG_MODIFIABLE);

	// update the sensor calibration values with the new ones, updating the as found as left as appropriate
	// use the committed as found values
	for (int sensorIndex = 0; sensorIndex < ptCalStatus->NoOfSensors; sensorIndex++) {
		// get us pointing to the correct index for each sensor
		T_INPUT_CAL_STATUS *ptCurrCalStatus = ptCalStatus->calStatusList;
		ptCurrCalStatus += sensorIndex;
		int sensorNo = ptCurrCalStatus->sensorNo;

		// get the modifiable and committed sensor information
		ptModifiableAnalogueData = GetAnalogueInput(sensorNo, CONFIG_MODIFIABLE, usSlotNo, usChanNo);
		ptCommittedAnalogueData = GetAnalogueInput(sensorNo, CONFIG_COMMITTED, usSlotNo, usChanNo);
		T_PBOARDCALS ptModifiableBoardCals = pkIOSetupCfg->GetTopSlotBoardRangeCalInfo(usSlotNo, CONFIG_MODIFIABLE);
		T_PBOARDCALS ptCommittedBoardCals = pkIOSetupCfg->GetTopSlotBoardRangeCalInfo(usSlotNo, CONFIG_COMMITTED);

		// clear the existing modifiable board cals and ensure it's multipoint cal
		T_CHANCALPOINT *calPoint = &ptModifiableBoardCals->ChanCals[usChanNo].PointCals;
		calPoint->CalType = V6_MULTI_POINT_CAL;
		T_MPCALCHANNEL *ptModifiableMPChannel = &ptModifiableMPChannels->Channel[sensorNo];
		T_MPCALCHANNEL *ptCommittedMPChannel = &ptCommittedMPChannels->Channel[sensorNo];

		ptModifiableMPChannel->CalElements = ptCalStatus->NoOfCalTemps;

		// clear the unused elements
		for (int sensorCalPointIndex = ptModifiableMPChannel->CalElements;
				sensorCalPointIndex < MPCALCHANNEL_CALPOINTS_SIZE; sensorCalPointIndex++) {
			ptModifiableMPChannel->CalPoints[sensorCalPointIndex].Offset = 0.0f;
			ptModifiableMPChannel->PrevCalPoints[sensorCalPointIndex] = 0.0f;
		}

		for (int calPointIndex = 0; calPointIndex < ptCalStatus->NoOfCalTemps; calPointIndex++) {
			// get the new and old input adjust values
			float inputAdjust = ptCurrCalStatus->newInputAdjust;
			float prevInputAdjust = ptCurrCalStatus->currInputAdjust;

			// get the current calibration temperature
			float calTemp = ptCurrCalStatus->calTemperature;

			ptModifiableMPChannel->CalPoints[calPointIndex].CalPoint = calTemp;
			ptModifiableMPChannel->CalPoints[calPointIndex].Offset = inputAdjust;

			// Update the previous calibration point with the previous adjustment
			// regardless of whether it was an actual specified calibration offset
			// or an interpolated/extrapolated value
			ptModifiableMPChannel->PrevCalPoints[calPointIndex] = prevInputAdjust;

			// NO LONGER USE THE CODE BELOW - THIS WOULD HAVE TRIED TO GET A PREVIOUS CALIBRATION
			// OFFSET FOR THE SPECFIED TEMPERATURE BUT INSTEAD WE WILL NOT USE THE ACTUAL INPUT
			// CAL ADJUSTMENT WHICH MIGHT BE AN INTERPOLATED VALUE - CODE LEFT BEHIND IN CASE THIS
			// CHANGES
			//// check if there is a matching cal point temperature in the committed setup
			//float currCalOffset = indexOfPrevCalOffsetForTemp(ptCommittedMPChannel, calTemp);

			//// update the old offset with the current committed offset
			//ptModifiableMPChannel->PrevCalPoints[calPointIndex] = currCalOffset;

			// check if this sensor cal point passed
			if (!ptCurrCalStatus->passed) {
				allSensorsPass = false;
			}

			// now skip by the number of sensors so we end up with a pointer to the next cal point
			// for this sensor
			ptCurrCalStatus += ptCalStatus->NoOfSensors;
		}

		// update the cal time with the cal-time now
		ptModifiableMPChannels->LastCalDate[sensorNo] = calTimeInSeconds;
	}

	// now update the last and next cal dates
	ptCalConfig->TestDate = calTimeInSeconds;
	const ULONG secondsIn180Days = 15552000;

	ptCalConfig->NextCalDate = ptCalConfig->TestDate + secondsIn180Days;

	// finally update the call pass/fail setting
	ptCalConfig->CalPassed = allSensorsPass == TRUE;

	// set the modified flag
	CRecSetupCfgMgr *pkCfgMgr = CRecSetupCfgMgr::Instance();
	pkCfgMgr->SetModified(TRUE);

}
//****************************************************************************
///
/// Searches for a matching previous input adjustment temperature
///
/// @param[in]			T_MPCALCHANNEL *ptMPChannelCalInfo - the monitoring point channel cal information to check
///
/// @returns the previous temperature/offset or 0.0 if none found
///
//****************************************************************************
const float CAMS2750InputCalMgr::indexOfPrevCalOffsetForTemp(T_MPCALCHANNEL *ptMPChannelCalInfo, float tempToindexOf) {
	float prevTemp = 0.0f;
	int maxCalElementsToCheck = ptMPChannelCalInfo->CalElements;

	// sanity check cal elements
	if (maxCalElementsToCheck > MPCALCHANNEL_CALPOINTS_SIZE) {
		maxCalElementsToCheck = MPCALCHANNEL_CALPOINTS_SIZE;
	}

	for (int calPointIndex = 0; calPointIndex < maxCalElementsToCheck; calPointIndex++) {
		if (ptMPChannelCalInfo->CalPoints[calPointIndex].CalPoint == tempToindexOf) {
			// we've found a temperature, set the previous and exit
			prevTemp = ptMPChannelCalInfo->CalPoints[calPointIndex].Offset;
			break;
		}
	}

	return prevTemp;
}
//****************************************************************************
///
/// Returns the matching analogue input data for the specified sensor input number
///
/// @param[in]			int sensorNo - the sensor number
/// @param[in]			REFERENCE configType - the comitted or modifiable configuration
/// @param[out]			USHORT &rusSlotNo - the slot number for the specified analogue input number
/// @param[out]			USHORT &rusChanNo - the channel number for the specified analogue input number
///
//****************************************************************************
T_PAICHANNEL CAMS2750InputCalMgr::GetAnalogueInput(int sensorNo, REFERENCE configType, USHORT &rusSlotNo,
		USHORT &rusChanNo) const {
	T_PAICHANNEL ptAnalogueInput = NULL;

	// check the slot number and board channel number are okay and that an analogue input card exists in this slot
	if (CRecSetupCfgMgr::GetAnalogueChannelInfo(sensorNo + 1, rusSlotNo, rusChanNo)) {
		CIOSetupConfig *pkAnalogueSetupCfg = pSETUP->GetIOSetupConfig();

		// Get the analogue input data structure
		ptAnalogueInput = pkAnalogueSetupCfg->GetAnalogueInput(rusSlotNo, rusChanNo, configType);
	}

	return ptAnalogueInput;
}
//****************************************************************************
///
/// Persists the calibration results to internal storage
///
/// @param[in]			REFERENCE configType - the config type i.e. committed or modifiable
/// @param[in]			T_IN_PROGRESS_SENSOR_CAL_STATUS *ptCalStatus - the in-progress cal state
///
/// @returns true if the cal file was persisted to internal memory correctly, false if not
///
//****************************************************************************
const bool CAMS2750InputCalMgr::PersistAMS2750CalibrationToIntStorage(const REFERENCE configType,
		T_IN_PROGRESS_INPUT_CAL_STATUS *ptCalStatus) {
	bool success = false;

	CAMS2750BuildCalFile calFileBuilder;

	if (calFileBuilder.InitialiseCalFile(calFileBuilder.GetInternalCalFilename())) {
		calFileBuilder.ClearCalDataFile();

		m_tGeneralCalData = PopulateGenCalInfo(configType);

		calFileBuilder.AddGeneralCalibrationStructure(&m_tGeneralCalData);

		ResetInMemorySensorInputCal();

		// now loop through the sensors that were actually cal'ed and update them
		for (int sensorIndex = 0; sensorIndex < ptCalStatus->NoOfSensors; sensorIndex++) {
			T_INPUT_CAL_STATUS *ptCurrCalStatus = ptCalStatus->calStatusList;
			ptCurrCalStatus += sensorIndex;
			int sensorNo = ptCurrCalStatus->sensorNo;

			PopulateSensorInputCalResultsData(sensorIndex, configType, ptCalStatus, m_tSensorInputCalData[sensorNo]);

			calFileBuilder.AddSensorInputCalibrationStructure(&m_tSensorInputCalData[sensorNo], sensorNo);
		}

		// now update the header information
		calFileBuilder.UpdateHeaderCRC();
		calFileBuilder.WriteHeaderToDisk();

		success = true;
	}

	return success;
}
//****************************************************************************
///
/// Resets the in-memory sensor input cal
///
//****************************************************************************
void CAMS2750InputCalMgr::ResetInMemorySensorInputCal() {
	memset(m_tSensorInputCalData, 0, sizeof(T_SENSORINPUTCALDATA) * NUM_TCS_PER_SOAK);

	// initialise all sensor slots to a known value
	for (int sensorIndex = 0; sensorIndex < NUM_TCS_PER_SOAK; sensorIndex++) {
		m_tSensorInputCalData[sensorIndex].CalState = SCS_CAL_NOT_INIT;
	}
}
//****************************************************************************
///
/// Saves the calibration file to the specified path/filename
///
/// @param[in]	const QString   rstrRequiredFilename - the required filename for the cal file
///
/// @returns True if the cal file was saved, false if not
///
//****************************************************************************
const bool CAMS2750InputCalMgr::SaveAMS2750Calibration(QString  &rstrRequiredFilename) {
	bool copySuccess = false;

	// check a cal is available as a sanity check
	if (CalIsAvailable()) {
		// copy the file file from the internal storage to the external
		CStorage kFileCopy;

		CAMS2750BuildCalFile calFileBuilder;

		// copy the file, ignoring any overwrite errors as this should already be known to the user
		if (calFileBuilder.InitialiseCalFile(rstrRequiredFilename)) {
			calFileBuilder.ClearCalDataFile();

			// Convert output values into local temperature units if not deg C
			T_AMS2750GENCAL genCal = GetGenCalInLocalTempUnits();

			calFileBuilder.AddGeneralCalibrationStructure(&genCal);

			// now loop through the sensors that were actually cal'ed and update them
			for (int sensorIndex = 0; sensorIndex < NUM_TCS_PER_SOAK; sensorIndex++) {
				// check this sensor has some cal information intialised, even if it's invalid
				if (m_tSensorInputCalData[sensorIndex].CalState != SCS_CAL_NOT_INIT) {
					T_SENSORINPUTCALDATA sensorCalData = GetSensorInputCalInLocalTempUnits(sensorIndex);
					calFileBuilder.AddSensorInputCalibrationStructure(&sensorCalData, sensorIndex);
				}
			}

			// now update the header information
			calFileBuilder.UpdateHeaderCRC();
			calFileBuilder.WriteHeaderToDisk();

			copySuccess = true;
		}
	}
	return copySuccess;
}
//****************************************************************************
///
/// Indicates if a calibration is available (for export)
///
/// @returns True if a cal file can be saved
///
//****************************************************************************
const bool CAMS2750InputCalMgr::CalIsAvailable() const {
	return m_tGeneralCalData.CalState != GCS_NOT_CALED;
}
//****************************************************************************
///
/// Helper method used to populate the general cal information
///
/// @param[in] REFERENCE configType - the config type i.e. committed or modifiable
///
/// @returns The general cal information
///
//****************************************************************************
T_AMS2750GENCAL CAMS2750InputCalMgr::PopulateGenCalInfo(REFERENCE configType) {
	CGeneralSetupConfig *pkGenCfg = pSETUP->GetGeneralSetupConfig();
	T_PAMS2750CALCFG ptCalConfig = pkGenCfg->GetAMS2750CalibrationBlock(configType);

	T_PGENERALCONFIG ptGeneralDeviceData = pkGenCfg->GetSystemGeneralBlock(configType);

	T_PGENNONVOL ptFactory = pSYSTEM_INFO->GetFactoryConfig();

	T_AMS2750GENCAL genCal;

	memset(&genCal, 0, sizeof(T_AMS2750GENCAL));

	genCal.Id = ptGeneralDeviceData->ID;
	genCal.SerialNo = ptFactory->SerialNumber;
	CStringUtils::SafeWcsCpy(genCal.Name, ptGeneralDeviceData->Name, AMS2750GENCAL_RECORDER_NAME_LEN);

	genCal.CalElements = ptCalConfig->CalElements;

	if (ptCalConfig->CalPassed) {
		genCal.CalState = GCS_PASSED;
	} else {
		genCal.CalState = GCS_FAILED;
	}

	genCal.TestDate = ptCalConfig->TestDate;
	genCal.NextCalDate = ptCalConfig->NextCalDate;

	CStringUtils::SafeWcsCpy(genCal.CalibratorType, ptCalConfig->CalibratorType, AMS2750GENCAL_CALIBRATORTYPE_LEN);
	CStringUtils::SafeWcsCpy(genCal.CalibratorSerNo, ptCalConfig->CalibratorSerNo, AMS2750GENCAL_CALIBRATORSERNO_LEN);
	CStringUtils::SafeWcsCpy(genCal.TraceableTo, ptCalConfig->TraceableTo, AMS2750GENCAL_qDebugABLETO_LEN);
	CStringUtils::SafeWcsCpy(genCal.TechnicianId, ptCalConfig->TechnicianId, AMS2750GENCAL_TECHNICIANID_LEN);
	CStringUtils::SafeWcsCpy(genCal.CalPerformedBy, ptCalConfig->CalPerformedBy, AMS2750GENCAL_CALPERFORMEDBY_LEN);
	CStringUtils::SafeWcsCpy(genCal.CalPerformedFor, ptCalConfig->CalPerformedFor, AMS2750GENCAL_CALPERFORMEDFOR_LEN);
	CStringUtils::SafeWcsCpy(genCal.QualityOrg, ptCalConfig->QualityOrg, AMS2750GENCAL_QUALITYORG_LEN);

	for (int calTempIndex = 0; calTempIndex < AMS2750GENCAL_CALPOINTS_SIZE; calTempIndex++) {
		genCal.CalPoints[calTempIndex].CalPoint = ptCalConfig->CalPoints[calTempIndex].CalPoint;
		genCal.CalPoints[calTempIndex].Offset = ptCalConfig->CalPoints[calTempIndex].Offset;
	}

	genCal.Tempasprintf = ttDEG_C;

	if (pSYSTEM_INFO->GetAMS2750Mode() == AMS2750_TUS) {
		genCal.AMS2750Mode = 0;
	} else {
		genCal.AMS2750Mode = 1;
	}

	return genCal;
}
///****************************************************************************
///
/// Helper method used to populate the sensor cal information
///
/// @param[in] REFERENCE configType - the config type i.e. committed 
/// @param[in] const int sensorIndex - the sensor index
/// @param[in] T_IN_PROGRESS_SENSOR_CAL_STATUS *ptCalStatus - the in-progress cal state
/// @param[out] T_SENSORCALDATA &rtSensorCalData - the sensor cal data to populate
///
/// @returns The relevant sensor cal results structure
///
//****************************************************************************
void CAMS2750InputCalMgr::PopulateSensorInputCalResultsData(const int sensorIndex, REFERENCE configType,
		T_IN_PROGRESS_INPUT_CAL_STATUS *ptCalStatus, T_SENSORINPUTCALDATA &rtSensorCalData) {
	CIOSetupConfig *pkIOSetupCfg = pSETUP->GetIOSetupConfig();
	T_AMS2750SENSORS *ptSensors = pSETUP->GetIOSetupConfig()->GetAMS2750SensorBlock(configType);

	T_PMPCALCHANNELS ptMPChannels = pkIOSetupCfg->GetMultiPointBlock(configType);

	// get us pointing to the correct index for each sensor
	T_INPUT_CAL_STATUS *ptCurrCalStatus = ptCalStatus->calStatusList;
	ptCurrCalStatus += sensorIndex;
	USHORT usSlotNo;
	USHORT usChanNo;

	// get the modifiable and committed sensor information
	T_PAICHANNEL ptAnalogueData = GetAnalogueInput(ptCurrCalStatus->sensorNo, configType, usSlotNo, usChanNo);
	T_PAMS2750SENSOR ptSensor = &ptSensors->Sensors[ptCurrCalStatus->sensorNo];

	// populate the main sensor information
	rtSensorCalData.NoOfCalTemps = ptCalStatus->NoOfCalTemps;
	rtSensorCalData.LastCalDate = ptMPChannels->LastCalDate[ptCurrCalStatus->sensorNo];

	if (ptAnalogueData->Type == AI_CHANNEL_TYPE_TC) {
		rtSensorCalData.SensorType = ptAnalogueData->TC.SelectedTC;
		rtSensorCalData.Type = ptSensor->Type;
	} else if (ptAnalogueData->Type == AI_CHANNEL_TYPE_RT) {
		rtSensorCalData.SensorType = ptAnalogueData->RT.SelectedRT;
		rtSensorCalData.Type = ptSensor->Type + ttEXPENDABLE_RT;
	}

	// assume the cal passed, will be updated if it failed
	rtSensorCalData.CalState = SCS_PASSED;

	// that's the main sensor information complete, now update the calibration temperature results
	for (int calTempIndex = 0; calTempIndex < rtSensorCalData.NoOfCalTemps; calTempIndex++) {
		T_PSENSOR_INPUT_CALPOINTDATA ptCalPoint = &rtSensorCalData.CalPoints[calTempIndex];

		ptCalPoint->PrevInputAdjust = ptCurrCalStatus->currInputAdjust;
		ptCalPoint->NewInputAdjust = ptCurrCalStatus->newInputAdjust;
		ptCalPoint->MeasuredTemp = ptCurrCalStatus->currMeasuredTemp;
		ptCalPoint->NewMeasuredTemp = ptCurrCalStatus->newMeasuredTemp;

		if (ptCurrCalStatus->passed) {
			ptCalPoint->CalState = TCS_PASSED;
		} else {
			ptCalPoint->CalState = TCS_FAILED;
			rtSensorCalData.CalState = SCS_FAILED;
		}

		// now skip by the number of sensors so we end up with a pointer to the next cal temperature
		// for this sensor
		ptCurrCalStatus += ptCalStatus->NoOfSensors;
	}
}
///****************************************************************************
///
/// Helper method used to populate the current in-memory cal information with the current saved
/// cal file information
///
//****************************************************************************
void CAMS2750InputCalMgr::InitialiseInMemoryCalFromSavedCalFile() {
	if (!m_bInMemoryCalInit) {
		// ensure both structures are clear
		memset(&m_tGeneralCalData, 0, sizeof(T_AMS2750GENCAL));

		m_tGeneralCalData.CalState = GCS_NOT_CALED;

		ResetInMemorySensorInputCal();

		CGeneralSetupConfig *pkGenCfg = pSETUP->GetGeneralSetupConfig();
		T_AMS2750CALCFG *ptCalConfig = pkGenCfg->GetAMS2750CalibrationBlock(CONFIG_MODIFIABLE);

		if (ptCalConfig->TestDate != 0) {
			// there should be a cal, try and load it
			CAMS2750ProcessCalFile calFileBuilder;

			QString  internalCalFilename = calFileBuilder.GetInternalCalFilename();
			CStorage kCalFile;

			if (kCalFile.FileExists(internalCalFilename)) {
				kCalFile.Open(internalCalFilename, QFile::ReadOnly);

				UCHAR *pcDataFile = new UCHAR[kCalFile.size()];

				kCalFile.Read(pcDataFile, kCalFile.size());

				calFileBuilder.InitCalFile(pcDataFile);

				T_STRUCTURE_IDENT theStructureInError;
				int theInstanceInError;

				// Now we validate the file to check theat it's integrity is ok
				T_C2750PROCESSFILE_RES result = calFileBuilder.ValidateFile(theStructureInError, theInstanceInError);
				if (result == PF_OK) {
					// check the cal is not empty
					if (!calFileBuilder.CalIsEmpty()) {
						// populate the general cal structure
						calFileBuilder.GetGeneralCalibration(&m_tGeneralCalData);

						// now load in the sensor information
						for (int sensorNo = 0; sensorNo < NUM_TCS_PER_SOAK; sensorNo++) {
							if (calFileBuilder.GetSensorInputCalibrationResults(&m_tSensorInputCalData[sensorNo],
									sensorNo) != PF_STRUCTURE_NOT_FOUND) {
								// we don't actually care about the result here as the cal data will have been updated
								// which is all we wanted, if not populated then thats also fine
							}
						}
					}
					// we should have populated with whatever was saved/available at this point so take as initialised
					m_bInMemoryCalInit = true;
				} else {
					// this implies a load issue so we haven't actually initialised, next time this method get called
					// the init might work - delete the file for now
					if (result == PF_FILE_CORRUPT) {
						kCalFile.Close();
						kCalFile.DeleteFileW(internalCalFilename);
					}
				}
			} else {
				// no file present, must have been reset/deleted
				m_bInMemoryCalInit = true;
			}
		} else {
			// no cal file so nothing to initialise
			m_bInMemoryCalInit = true;
		}
	}
}
///****************************************************************************
///
/// Validates the AMS2750 calibration against any newly modified changes to the cal
///
//****************************************************************************
void CAMS2750InputCalMgr::PrecommitValidateCal() {
	InitialiseInMemoryCalFromSavedCalFile();

	// by this point, if there was a previous cal it should have been loaded, check this before proceeding
	// and do not perform validation on a failed cal
	if ( ( m_tGeneralCalData.CalState != GCS_NOT_CALED ) &&
			( m_tGeneralCalData.CalState != GCS_FAILED) )
	{
		USHORT slotNo;
		USHORT chanNo;

		// assume the cal passed, this will be invalidated during this validation process
		m_tGeneralCalData.CalState = GCS_PASSED;

		CIOSetupConfig *pkIOSetupCfg = pSETUP->GetIOSetupConfig();
		T_AMS2750SENSORS *ptModifiableAMSSensors = pkIOSetupCfg->GetAMS2750SensorBlock(CONFIG_MODIFIABLE);
		T_PMPCALCHANNELS ptModifiableMPChanCals = pkIOSetupCfg->GetMultiPointBlock(CONFIG_MODIFIABLE);

		const bool isProcessMode = pSYSTEM_INFO->FWOptionAMS2750ProcessAvailable();

		// loop through each sensor for each cal point
		for (USHORT sensorIndex = 0; sensorIndex < MAX_ANALOGUE_IN; sensorIndex++)
		{
			T_AMS2750SENSOR *ptSensor = &(ptModifiableAMSSensors->Sensors[sensorIndex]);

			T_PAICHANNEL ptModifiableAnalogueData = GetAnalogueInput(sensorIndex, CONFIG_MODIFIABLE, slotNo, chanNo);

			// get a pointer to the cal data
			T_SENSORINPUTCALDATA *ptSensorCalData = &m_tSensorInputCalData[sensorIndex];

			// see if this sensor was in the cal and it didn't fail 
			if ( ( ptSensorCalData->CalState != SCS_CAL_NOT_INIT) &&
					( ptSensorCalData->CalState != SCS_CAL_INPUT_NOT_CALED) &&
					( ptSensorCalData->CalState != SCS_FAILED) )
			{
				// assume the cal passed, this will be invalidated during this validation process
				ptSensorCalData->CalState = SCS_PASSED;

				// check it's still exists and is enabled
				if ( (ptModifiableAnalogueData != NULL ) && ptModifiableAnalogueData->Enabled )
				{
					// check it's still the same type of sensor
					if ( !SensorInputTypeChanged( ptModifiableAnalogueData, ptSensorCalData ) &&
							((ptSensor->TUSTC == TRUE) || isProcessMode))
					{
						// check the sensor is still the same type
						// the sensor is in the original cal, check it's state matches
						if (ptSensorCalData->LastCalDate != ptModifiableMPChanCals->LastCalDate[sensorIndex])
						{
							// the date has changed, thus the calibration is invalid
							ptSensorCalData->CalState = SCS_CAL_DATE_CHANGED;

							// mark the main cal state as invalid
							m_tGeneralCalData.CalState = GCS_INVALID;
						}
						else
						{
							// date is good, now check the cal itself
							T_PBOARDCALS ptModifiableBoardCals = pkIOSetupCfg->GetTopSlotBoardRangeCalInfo(slotNo, CONFIG_MODIFIABLE);
							T_PMPCALCHANNEL ptModifiableCalChan = &ptModifiableMPChanCals->Channel[sensorIndex];

							if (ValidateMultiPointCal(ptSensorCalData, &ptModifiableBoardCals->ChanCals[chanNo], ptModifiableCalChan, m_tGeneralCalData.CalPoints))
							{
								// if we got here then the cal config appears to match the cal that was performed
							}
						}
					}
					else
					{
						if (ptSensor->TUSTC == FALSE) {
							// no longer an AMS sensor so mark it as such but don't invalidate the entire cal
							ptSensorCalData->CalState = SCS_NO_LONGER_AMS_SENSOR;
						}
						e e

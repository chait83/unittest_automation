/// @file 
/// **************************************************************************
/// Ã¯¿½ Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 AMS2750 input calibration manager
/// @n Filename:  AMS2750InputCalMgr.h
/// @n Description: Definition of the AMS2750InputCalMgr class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:$
//
// **************************************************************************

#pragma once

#include "RecSetupCfgMgr.h"
#include "ams2750InputCalDlg.h"
#include "CMMDefines.h"

class CAMS2750InputCalMgr {
public:
	// Constructor
	CAMS2750InputCalMgr();

	// Destructor
	~CAMS2750InputCalMgr(void);

	// Saves the calibration file to the specified path/filename
	const bool SaveAMS2750Calibration(QString  &rstrRequiredFilename);

	// Indicates if a calibration is available (for export)
	const bool CalIsAvailable() const;

	// Validates the AMS2750 calibration against any newly modified changes to the cal
	void PrecommitValidateCal();

	// Gets a copy of the general cal.
	const T_AMS2750GENCAL GetGeneralCal();

	// Gets a copy of the specified sensor cal.
	const T_SENSORINPUTCALDATA GetSensorInputCal(const int sensorIndex);

	// Gets a copy of the general cal. in local temperature units
	T_AMS2750GENCAL GetGenCalInLocalTempUnits();

	// Gets a copy of the specified sensor cal. in local temperature units
	T_SENSORINPUTCALDATA GetSensorInputCalInLocalTempUnits(const int sensorIndex);

	// Initialises the sensor calibration structure (as used by the in-progress status list
	const bool InitSensorInputCalStruct(T_PAMS2750CALCFG ptCalConfig, T_PAMS2750SENSORS ptSensors,
			T_IN_PROGRESS_INPUT_CAL_STATUS *ptCalStatus);

	// Method used to update the sensor calibration values
	void UpdateSensorInputCalValues(T_IN_PROGRESS_INPUT_CAL_STATUS *ptCalStatus);

	// Persists the calibration results to internal storage
	const bool PersistAMS2750CalibrationToIntStorage(const REFERENCE configType,
			T_IN_PROGRESS_INPUT_CAL_STATUS *ptCalStatus);

	// The minimum number of sensors required when performing a cal.
	static const int MIN_REQUIRED_SENSORS;

	// Method used to calculate how many sensors cumulative calibration adjustments exceed the spec. for the specified oven type and setpoints
	const int GetNoOfSensorsOutsideFurnaceCal(const int furnaceClass,
			T_SETPOINT tSetpoints[FURNACESCONFIG_SETPOINTS_SIZE]) const;

	// Method used to determine if the input calibration has expired
	const bool InputCalExpired() const;

private:

	// Helper method used to populate the general cal information
	T_AMS2750GENCAL PopulateGenCalInfo(const REFERENCE configType);

	// Helper method used to populate the sensor input cal information
	void PopulateSensorInputCalResultsData(const int sensorIndex, REFERENCE configType,
			T_IN_PROGRESS_INPUT_CAL_STATUS *ptCalStatus, T_SENSORINPUTCALDATA &rtSensorCalData);

	// Resets the in-memory sensor cal
	void ResetInMemorySensorInputCal();

	// Confirms the sensor input can be cal'ed as an AMS2750 sensor
	bool SensorInputOkForCal(int sensorNo, T_PAMS2750SENSORS ptModifiableSensors, T_PAMS2750SENSORS ptCommittedSensors);

	// Gets the specified analogue input config structure
	T_PAICHANNEL GetAnalogueInput(int sensorNo, REFERENCE configType, USHORT &rusSlotNo, USHORT &rusChanNo) const;

	// Searches for a matching previous input adjustment temperature
	const float indexOfPrevCalOffsetForTemp(T_MPCALCHANNEL *ptMPChannelCalInfo, float tempToindexOf);

	// Helper method used to populate the current in-memory cal information
	void InitialiseInMemoryCalFromSavedCalFile();

	// Validates the sensor input calibration against any newly modified changes
	const bool SensorInputTypeChanged(T_PAICHANNEL ptModifiableAnalogueData, T_SENSORINPUTCALDATA *ptSensorCalData);

	// Validates the multi-point cal
	const bool ValidateMultiPointCal(T_SENSORINPUTCALDATA *ptSensorCalData, T_PCHANNELCALS ptChannelCal,
			T_PMPCALCHANNEL ptModifiableCalChan, T_AMS2750CALPOINTS taCalPoints[AMS2750GENCAL_CALPOINTS_SIZE]);

	// Method used to determine if the input calibration has expired
	const bool SensorsOutsideFurnaceCal(const float &setpointTemperature, const float &conditionedReading,
			const USHORT &furnaceClass) const;

	// Helper method used to compare two floats for equality from a cal. point of view
	const bool EssentiallyEqual(const float a, const float b, const float maxDiff = 0.001);

	/// An in-memory static copy of the current general calibration state
	static T_AMS2750GENCAL m_tGeneralCalData;

	/// An in-memory static copy of the current sensor input calibration states
	static T_SENSORINPUTCALDATA m_tSensorInputCalData[NUM_TCS_PER_SOAK];

	/// Flag indicating if the in-memory cal has been initialised (i.e. populated with the saved cal data on start-up)
	static bool m_bInMemoryCalInit;

};

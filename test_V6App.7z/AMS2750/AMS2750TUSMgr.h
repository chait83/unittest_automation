/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	AMS2750 data processing
/// @n Filename:	AMS2750TUSMgr.h
/// @n Description: Definition of the CAMS2750TUSMgr class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 3	Stability Project 1.0.1.1	7/2/2011 4:55:24 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 2	Stability Project 1.0.1.0	7/1/2011 4:27:53 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 1	V6 Firmware 1.0		9/23/2008 12:12:17 PM Build Machine 
// $
//
// **************************************************************************

#if !defined(AFX_AMS2750TUSMGR_H__FFCCD88F_227F_4A6F_BF8F_9F220D50C782__INCLUDED_)
#define AFX_AMS2750TUSMGR_H__FFCCD88F_227F_4A6F_BF8F_9F220D50C782__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AMS2750TUSMgr.h : header file
//
#include <QMutex>
#include "Defines.h"
#include "ModuleMsgManagerClient.h"
#include "AMS2750DataStruct.h"
#include "PipeProcess.h"
#include "LinearTable.h"
#include "AMS2750TimerCtrlMgr.h"
#include "AMS2750TCStatusMgr.h"
#include "DataItemPen.h"
#include "TV6Timer.h"
#include "DataItemGeneral.h"

#if defined (DBG_FILE_LOG_AMS_DBG_ENABLE) 
	#include "CStorage.h" //Veeru - Debug File Logger integration
#endif

const ULONG TUS_SRAM_SIGNATURE = 0x0D572; // Arbitary signature used for invalidating TUS SRAM, change this when altering the NV structures

const int TUS_NVLOG_STORE = 3;	//< Number of lines of readings to store in NV
const int TUS_NVLOG_STORE_TODISK = 2;	//< Number of lines of readings to accumulate before storing to disk
const int TUS_SECONDS_PER_READING = 120;	//< Seconds per reading for each TUS, 2 minutes = 120 seconds
const int TUS_AUTO_STABILITY_TIME = TUS_SECONDS_PER_READING; //< Automatic stability timer, same as reading interval at preset
const int TUS_SECONDS_POWER_OFF = 20 * 60; //< 20 minutes power threshold, if off for more the 20 mins do not resume a TUS
const int TUS_LOOKUP_ELEMENTS = 100; //< Generate at least a 100 point lookup table for the calibration system
const int TUS_DEMO_AUTO_STABILITY_TIME = 60; //< Automatic stability timer Demo time down to 60 seconds
const int TUS_DEMO_SOAK_TIME = 60; //< Soak time for demo - 60 seconds, not 30 minutes minimum
const int TUS_SENSORMASK = 4; //< Number of USHORTS i the sensor mask array 4 = 64 bits (48 required)
const int TUS_AUTOSTOP_DELAY_ON_FAIL_MIN = 60; //< Automatically stop after 60 minutes, if failure on last soak

// Information for furnace test intervals
const ULONG I_WEEKLY = 7;
const ULONG I_BIWEEKLY = 14;
const ULONG I_MONTHLY = 31;
const ULONG I_QUARTERLY = 91;
const ULONG I_SEMIANUALLY = 182;
const ULONG I_ANUALLY = 365;

typedef enum {
	TSM_RESUME_TUS = 0,						//< Resume a TUS after power fail.
	TSM_START_NEW_SOAK_DETECT,				//< Start detection for a new soak.
	TSM_ALL_TCS_OUT_OF_SOAK,			//< Soak detection started and in ramp.
	TSM_TCS_ENTERED_SOAK,						//< Some TC's have eneterd soak.
	TSM_ALL_TCS_IN_SOAK,	//< All TC's are within soak, but not yet stable.
	TSM_ENTER_STABILATY,						//< Enter stability
	TSM_ALL_TC_IN_SOAK_AND_STABLE,				//< All TC's In soak and stable.
	TSM_SOAK_FAILED,							//< Soak has failed.
	TSM_SOAK_PASSED,							//< Soak has passed.
	TSM_SOAK_EXIT,						//< Wait to exit the soak to start next
	TSM_SOAK_LASTPOINT,				//< Wait until next log point to pass test
	TSM_AUTO_STOP,	//< Automaitically stop the TUS - but delay if it's a fail

} T_TUS_STATE_MACHINE_STAGE;

typedef enum {
	TUS_GLOBAL_NOT_RUNNING = 0,					//< TUS is not running
	TUS_GLOBAL_RUNNING,							//< TUS is within a survey
	TSM_GLOBAL_SURVEY_COMPLETE_NO_EXPORT,							//< TUS survey completed but not exported
	TSM_GLOBAL_SURVEY_COMPLETE_EXPORT,	//< TUS survey completed and exported

} T_TUS_GLOBAL_STATUS;

// Overall TC status
typedef enum {
	TUS_TC_INVALID = 0,							//< Invalid status
	TUS_TC_NONE_IN_SOAK,		//< TC status where no TC's are within a soak
	TUS_TC_SOME_IN_SOAK,						//< Some TC's are within a soak
	TUS_TC_ALL_IN_SOAK,							//< All TC's are within the soak
	TUS_TC_BREACHED,							//< A TC has breached the soak.

} T_TUS_TC_STATUS;

// individual TC status
typedef enum {
	TUS_THIS_TC_OVER = 0,					//< The TC is over the soak range
	TUS_THIS_TC_UNDER,						//< The TC is under the soak range
	TUS_THIS_TC_IN_SOAK,					//< The TC is within the soak range
	TUS_THIS_TC_INVALID,			//< The TC is invalid due to break, failure

} T_TUS_THIS_TC_STATUS;

// Test Direction
typedef enum {
	TUS_DIRECTION_UP = 0,		//< The TC signals are ramping up into the soak
	TUS_DIRECTION_DOWN,	//< The TC signals are falling down into the soak
} T_TUS_TEST_DIRECTION;

// Main TUS information structure
typedef struct {
	ULONG signature;		//< Signature to indetify/invalidate NV structure
	T_TUS_GLOBAL_STATUS globalStatus;		//< TRUE if TUS is running , otherwise FALSE
	T_TUS_STATE_MACHINE_STAGE tusSM;			//< TUS State Machine state
	USHORT logSeqNumber;						//< Log Sequence Number 0 to 540
	USHORT logLineNumber;				//< Log Line number 0 to TUS_NVLOG_STORE
	USHORT currentSoak;					//< Number of current soak in progress
	USHORT TUScounter;					//< Count the number of surveys done, for report file differentiation
	BOOL CurrProcessOption;	//< Current setting of the AMS2750 process mode option code
	BOOL CurrTUSOption;	//< Current setting of the AMS2750 TUS mode option code
} T_TUS_MAIN;

// NV Based TUS runtime structure
typedef struct {
	T_TUS_MAIN main;							//< Main TUS information 
	T_TUSTESTDATA test;							//< Test data for the TUS
	T_TUSSOAKTEST soaks[NUM_SOAKS];			//< Status for each soak held in NV
	T_TUSDATAREADING line[TUS_NVLOG_STORE];	//< TUS data reading buffer before saving to file
	T_TUSSOAKDATA prevSoak;	//< Copy of previous soak completed, used for power fail integrity

	T_AMSTIMER_NV timers;						//< NV for AMS2750 timers
	T_TCUSAGE_NV TCTimers;						//< NV for AMS2750 TC timers

} T_TUS_INFO, *T_PTUS_INFO;

// Sensor information store, all relevant sensor details contained here
typedef struct {
	USHORT Index;								//< Sensor index (0-47).
	BOOL IsInSoak;				//< TRUE if sensor is in a soak, otherwise false
	CDataItemPen *DataItem;	//< Handle on the Data item for the pen corrisponding to the TC
	T_PAMS2750SENSOR SensorConfig;			//< Sensor configuration Information
	T_PAICHANNEL AnalogueConfig;		//< Analogue configuration information
	T_TCDATAFORSOAK SoakSensorData;				//< Soak Sensor data
	BOOL ISCalRequired;					//< Is Calibration of sensor required
	BOOL ISCalSingle;					//< Is it a single calibration(TRUE), or table based calibration (FALSE)
	float singleOffSet;							//< Single calibration offset
	CLinearTable calTable;				//< Table for multi point calibration
	CPipeProcess stabilityPipe;					//< Auto stability detect
	BOOL IsUserEnabled;							//< User can disable TC's 

} T_TUS_SENSOR_INFOMATION, *T_PTUS_SENSOR_INFOMATION;

typedef struct {
	USHORT Index;	//< The confiuration based index of soak (can be different to the active TUS soak index information)
	BOOL IsSoakToBeChecked;						//< Current soak to be checked
	float upperLimit;						//< Upper limit for fast comparisons
	float lowerLimit;					//< Lower limit for fast comparisions
	T_PTUSSOAKTEST snv;					//< Pointer to NV T_TUSSOAKTEST instance
} T_TUS_SOAK_INFORMATION, *T_PTUS_SOAK_INFORMATION;

//**CAMS2750TUSMgr***********************************************************
///
/// @brief Singleton class used to manage the AMS2750 TUS information and provide an 
/// interface between the data processing and UI
/// 
/// Singleton class used to manage the AMS2750 TUS information and provide an 
/// interface between the data processing and UI
///
//****************************************************************************
class CAMS2750TUSMgr {
public:

	/// Enum indicating the current state of the overall TUS
	enum T_AMS2750_TUS_STATE {
		tusSTOPPED, tusRUNNING
	//tusPASSED,
	//tusFAILED
	};

	// Method that creates and initialises the singleton
	static CAMS2750TUSMgr* Instance();

	// Destructor
	~CAMS2750TUSMgr() {
		delete[] m_taSensorsConfig;
	}

	// Initialise the TUS process singleton
	BOOL Initialise();

	// Perform a full reset on the TUS system
	void ResetTUSData();

	// Configure the TUS system
	void Configure();

	// Process the TUS, main State machine for survey control
	void ProcessTUS();

	// Ceck the thermocouples, depending on stage in state machine
	T_TUS_TC_STATUS CheckTCs(int &tcIndexPassBack);

	// Add a line of log readings (2 minute logs)
	void AddLogLine();

	// API methods for TUS Screen access and control
	// Accessor for a particular setpoint's test status
	const T_SOAK_STATUS GetSPStatus(const USHORT usSET_POINT_NO) const {
		return (T_SOAK_STATUS) m_pTUSNV->soaks[usSET_POINT_NO].soakStatus;
	}

	// Accessor for a particular setpoint's max TC name
	const QString  GetSPMaxTCName(const USHORT usSET_POINT_NO);

	// Accessor for a particular setpoint's max TC value in display temperature units
	const float GetSPMaxTCValue(const USHORT usSET_POINT_NO) const {
		return m_pTUSNV->soaks[usSET_POINT_NO].maxTCval;
	}

	// Accessor for a particular setpoint's min TC name
	const QString  GetSPMinTCName(const USHORT usSET_POINT_NO);

	// Accessor for a particular setpoint's min TC value in display temperature units
	const float GetSPMinTCValue(const USHORT usSET_POINT_NO) const {
		return m_pTUSNV->soaks[usSET_POINT_NO].minTCval;
	}

	// Accessor for a particular setpoint's max TC diff wrt its setpoint in display temperature units
	const QString  GetSPMaxTCDiffWrtSPName(const USHORT usSET_POINT_NO);

	// Accessor for a particular setpoint's max TC diff wrt its setpoint in display temperature units
	const float GetSPMaxTCDiffWrtSPValue(const USHORT usSET_POINT_NO) const {
		return m_pTUSNV->soaks[usSET_POINT_NO].maxTempDiffTCtoSetP;
	}

	// Accessor for a particular setpoint's max ramp overshoot TC name
	QString  GetSPMaxRampOvershootTCName(const USHORT usSET_POINT_NO);

	// Accessor for a particular setpoint's max ramp overshoot TC value in display temperature units
	float GetSPMaxRampOvershootTCValue(USHORT usSET_POINT_NO);

	// Accessor for a particular setpoint's ramp duration in complete minutes
	const long GetSPRampDuration(const USHORT usSET_POINT_NO) const {
		return (long) (USEC_TO_SEC(m_pTUSNV->soaks[usSET_POINT_NO].rampTime));
	}

	// Accessor for a particular setpoint's TC lag into the soak period in complete minutes
	const long GetSPTCLagIntoSoak(const USHORT usSET_POINT_NO) const {
		return (long) (USEC_TO_SEC(m_pTUSNV->soaks[usSET_POINT_NO].lagTime));
	}

	// Accessor for a particular setpoint's soak duration in complete minutes
	const long GetSPMaxTCSoakDuration(const USHORT usSET_POINT_NO) const {
		return (long) (USEC_TO_SEC(m_pTUSNV->soaks[usSET_POINT_NO].soakTime) / 60);
	}

	// Accessor for a particular setpoint's class of furnace that it meets
	const QString  GetSPFurnaceClassMet(const USHORT usSET_POINT_NO);

	// Method that determines the number of TC's configured for a TUS
	const USHORT GetNoOfTUSTCs() const {
		return m_numSensorsAdjusted;
	}

	// Method that determines the number of TC's configured for a TUS
	const USHORT GetTotalNoOfTUSTCs() const {
		return m_numSensors;
	}

	// Method that determines the control TC instance
	const bool DetermineControlTCInstance(USHORT &rusControlTCInstance) const;

	// Method that gets the control TC instance
	const bool GetControlTCInstance(USHORT &rusControlTCInstance) const;

	// Accessor for the current TUS state
	const T_AMS2750_TUS_STATE GetTUSState() const {
		return m_eTUSState;
	}

	const T_TUS_STATE_MACHINE_STAGE GetTUSStateMachine() const {
		return m_pTUSNV->main.tusSM;
	}
	;

	// Method used to start a TUS
	void StartTUS(const QString  &rstrNOTES);

	// Method used to stop a TUS
	void StopTUS(const QString  &rstrNOTES, T_TUS_TEST_STATUS defaultStatus = TUS_PASSED);

	// Method that indicates the manual TC stabilise button has been pressed
	void TCsStable();

	// Method that indicates the export TUS button has been pressed
	void ExportTUS();

	// Method that gets the current extra grid line values and setpoint - values set to FLT_MAX if none required
	void GetGridLineValues(float &rfGridLine1, float &rfGridLine2, float &rfSetpoint);

	// Method that gets the TUS engineer name
	const QString  GetEngineer();

	// Method that gets the TUS start time
	const QString  GetStartTime();

	// Method that gets the TUS elapsed name
	const QString  GetElapsedTime();

	// Method that gets the TUS stop time
	const QString  GetStopTime();

	// Checks if an update to the TUS screen is required
	BOOL IsUpdateRequired() {
		return m_UpdateTUSScreen;
	}
	;

	// Set the TUS screen update required flag
	void SetUpdateRequired(BOOL updateRequired) {
		m_UpdateTUSScreen = updateRequired;
	}
	;

	// Accessor method for the current soak tolerance
	const float GetSoakTolerance(const int iSETPOINT) const;

	// Accessor to make sure the TUS does not try a resume after power on
	void ResetTUSStatus() {
		m_ResetTUSStatus = TRUE;
	}
	;

	// Get the unique TUS report number
	const USHORT GetReportNumber() {
		return m_pTUSNV->main.TUScounter;
	}
	;

	// Get sensor calibrated reading using the internal sensor index as the reference
	float GetCalAdjustedSensorReadingUsingInternalRef(int internalSensorIndex, float inputReading);

	// Get sensor calibrated reading using the global zero-based analog input instance number as the reference
	float GetCalAdjustedSensorReadingUsingInstanceNo(int instanceNoZeroBased, float inputReading);

	// Access or if TUS system is active and running
	BOOL IsTUSActive() {
		return m_IsActive;
	}
	;

	// Get a handle on the NV for the timers
	T_AMSTIMER_NV* GetTimersNVPtr() {
		return &m_pTUSNV->timers;
	}
	;

	// Get a handle on the NV for the TC timers
	T_TCUSAGE_NV* GetTCTimersNVPtr() {
		return &m_pTUSNV->TCTimers;
	}
	;

	// Get time interval in seconds for next TUS or SAT test
	ULONG GetNextTestInterval(BOOL IsTUS, T_PFURNACE pFurnace);

	// Indicates if the AMS2750 is in demo mode
	BOOL IsInDemoMode() {
		return m_DemoMode;
	}
	;

	// Set the User disabled TC's
	void SetTCIgnore(USHORT *pMask);

	// Get min number of allowed TC's
	int GetMinTCAllowed();

	// Reset the current soak level
	void RestartCurrentSoak();

	// Sets up a mask of currently enabled sensors for use in TC disable picker
	void SetEnabledMask(USHORT *pBitStore);

	// The maximum number of TUS sensor permitted
	const USHORT m_usMAX_NO_OF_TUS_SENSORS;

	// Method that returns true if the last TUS has been exported (only valid when another TUS has not been started)
	const bool LastTUSFileExported() const {
		return (m_pTUSNV->main.globalStatus != TSM_GLOBAL_SURVEY_COMPLETE_NO_EXPORT);
	}

	// Method used to copy ASM2750 process information from one sensor to another
	static void CopyAMS2750ProcessTCInfo(const T_AMS2750SENSOR &SENSOR_TO_COPY, T_AMS2750SENSOR &sensorToOverwrite);

	// Method used to copy ASM2750 TUS information from one sensor to another
	static void CopyAMS2750TUSTCInfo(T_AMS2750SENSOR &SENSOR_TO_COPY, T_AMS2750SENSOR &sensorToOverwrite);

	// Method used to identify if the AI channel is configured as a TUS sensor
	static bool IsTUSSensor(T_PAICHANNEL paiChannel, T_AMS2750SENSOR &rtSensor);

	// Method used to identify if the AI channel can be configured as a valid AMS2750 sensor (doesn't mean it is an AMS sensor)
	static bool CanBeConfiguredAsAMS2750Sensor(T_PAICHANNEL paiChannel);

	// Method used to determine if an RT is a noble metal
	static bool IsNobleMetalRT(USHORT rtType);

	// Build the sensor Name for sensor Number 
	static const QString  buildSensorName(USHORT sensorNumber, bool isTC);

private:
	T_TUS_THIS_TC_STATUS IsInSoakLevel(T_PTUS_SENSOR_INFOMATION sensorToTest, float &theReading);
	void setStateMachine(T_TUS_STATE_MACHINE_STAGE newState) {
		m_pTUSNV->main.tusSM = newState;
	}
	;
	void SetDrawMaxMin();

	void TestOverShoot(T_PTUS_SENSOR_INFOMATION sensorToTest);

	// Method that updates the default soak tolerance given the current furnace type
	void UpdateFurnaceTolerance(const T_FURNACE_TYPE ePARTS_FURNACE, const USHORT usFURNACE_CLASS,
			const T_TEMPERATURE_TYPE eTEMP_UNITS);

	// Update the screen timers
	void UpdateWorkingTimers();

	// Geta validtaed reading for use in TUS
	float GetValidatedReading(T_PTUS_SENSOR_INFOMATION sensorToTest);

	// Method to round the input float value (if necessary)
	static float RoundTheReading(float num);

	// Inititlise the divide down counters
	void SetUpDivideDownCounters();

	// Return the time in string from a USEC time
	const QString  GetStringTimeFromUSECTime(LONGLONG USECTime);

	// Update elapsed timer
	void SetElapsedTimer();

	// Check the staibility of a signal
	float UpdatePipeStability();

	// Zoom in on a TUS chart
	void ZoomChart();

	// Restore the normal zoom on the chart
	void RestoreNormalChartZoom();

	// Closedown the current soak
	void CloseCurrentSoak();

	// Complete the soak and move on to next or complete test
	void CompleteSoak();

	// Update the max and min when in stability
	BOOL UpdateStabilityMaxMinDiff(int index);

	// Gte the tolerance for a required class of furnace
	float GetToleranceForClass(int furnaceClass, T_TEMPERATURE_TYPE eTEMP_UNITS);

	// Reset a soak to default
	void ResetSoak(int soakConfigIndex, int activeSoakIndex);

	// indexOf the class achieved for results of a soak
	USHORT GetBestClassForDeviation(float maxDev);

	// Setup a sensor calibration table
	void GenerateCalTable(T_PTUS_SENSOR_INFOMATION pSensor);

	// Get the adjust reading after claibration
	float GenerateCalAdjustedRecorderReading(USHORT sensorIndex, float inputReading);

	// Get the sensor calibrated reading
	static const float GetCalAdjustedSensorReading(T_TUS_SENSOR_INFOMATION *ptTusSensor, const float inputReading);

	// Misc bit handlers
	BOOL GetBit(int index, USHORT *pBitStore);
	void SetBit(int index, USHORT *pBitStore);
	void ClearBit(int index, USHORT *pBitStore);

	// retrive the rogue soot value
	float GetDefaultShootValue();

	T_TUS_SENSOR_INFOMATION* GetTUSSensorDetailsByInstanceNo(USHORT instanceNo);

private:

	CAMS2750TUSMgr();						// Constructor
	static std::auto_ptr<CAMS2750TUSMgr> ms_kAMS2750TUSMgr;	// Singleton auto pointer
	static QMutex ms_hCreationMutex;		// Handle to the creation mutex

	T_AMS2750_TUS_STATE m_eTUSState;		// Variable indicating the current TUS state

	BOOL m_IsInitialised;		// Flag to protect singleton from multiple initilisations			
	BOOL m_IsActive;		// Is the TUS mode active, i.e. are credits enabled to select TUS mode
	BOOL m_NVRecoveryAttempt;		// TRUE if part way though a TUS and we try to recover.
	BOOL m_ResetTUSStatus;		// TRUE if TUS to be reset to not running status after power on
	BOOL m_registerPowerFail;		// TRUE if a resume after power fail is started, flag for log line. 
	BOOL m_IsLastOneDiscard;	// TRUE if a soak is at Passed and this flag is used to discard extra record add log.
	BOOL m_IsAutoStop;// TRUE if soak AUTO stopped, handling to reset logSeqNumber=1,other wise next soak will start from previous number insted of 1.
	LONGLONG m_processCnt;		// Countdown for TUS processing , every second, aligned to a second
	LONGLONG m_processReload;		// Reload time for processing , every second in process ticks

	LONGLONG m_readingCnt;		// Countdown for readings , every 2 minutes aligned to the minute
	LONGLONG m_readingReload;	// Reload time for readings , every 2 minutes

	BOOL m_firstIn;	// First time into the TUS processing we need to setup timers.

	T_PTUS_INFO m_pTUSNV;					// Pointer to TUS NV Memory

	CIOSetupConfig *m_pkIOSetupCfg;	// Pointer to the IO Setup configuration manager
	T_PFURNACESCONFIG m_ptFurnaces;	// Pointer to the furnaces configurations 

	int m_numSensors;						// Total number of sensors in TUS
	int m_numSensorsAdjusted;						// Adjust to number of sensors to remove control TC if included
	T_TUS_SENSOR_INFOMATION m_Sensor[ AMS2750SENSORS_SENSORS_SIZE];	// Information for all sensors		

	int m_numSoaks;									// Total number of soaks
	T_TUS_SOAK_INFORMATION m_Soak[NUM_SOAKS];		// Informtion for all soaks
	T_PTUS_SOAK_INFORMATION m_pWorkSoak;		// easy pointer to current working soak

	float m_gridLineUpper;					// Upper gridline to draw on chart
	float m_gridLineLower;					// Lower gridline to draw on chart
	float m_soakLevel;						// Lower gridline to draw on chart

	// Timers
	CTV6Timer m_rampTimer;			// ramp timer where TC's ramp up into soak
	CTV6Timer m_lagTimer;			// Lag timer, difference between 1st TC entering soak and last
	CTV6Timer m_soakTimer;			// Soak timer, when stability achived must be at least 30 minutes
	CTV6Timer m_surveyTimer;				// total survey timer
	CTV6Timer m_stabilityTimer;				// timer to test stability
	CTV6Timer m_AutoStabTimer;				// Automatic stability test timer 
	CTV6Timer m_AutoStopTimer;				// Automatic stop timer

	CDataItemGeneral *m_MaxRunSensor;				// Data item of Max TC to be shown on the graph.
	CDataItemGeneral *m_MinRunSensor;				// Data Item for Min TC to be shown on the graph.
	CDataItemGeneral *m_diffTC;			// difference between max an min TC's

	CDataItemGeneral *m_pkElapsedTimeDIT;	// Elapsed Time data item
	CDataItemGeneral *m_pkTUSStartTime;		// Start Time data item

	T_TUS_TEST_DIRECTION m_Direction;		// Direction of the ramp for the next soak - up or down.

	BOOL m_UpdateTUSScreen;			// Flag to indicate a screen update required
	BOOL m_StabilityEnabled;			// Flag to indicate that stability is enabled (i.e. all TC's are within soak )
	BOOL m_lastSoakFailed;			// TRUE if last soak failed, otherwise false

	// Instance of a message manager client - this is required for sending data to the TUS file handling thread
	CModuleMsgManagerClient m_ModuleMsgMgrClient;

	// Structure containing the TUS test configuration data
	T_TUSTESTCONFIG m_tTestConfig;

	// Array of Structures containing the sensor configurations
	T_TUSSENSORCONFIG *m_taSensorsConfig;

	// Variable indicating the current default soak tolerance
	float m_CurrDefSoakTolerance;

	// Non-linear lookup for sensor calibration
	CLinearTable m_calTable;

	USHORT m_currlogSeqNumber;	// Current log sequence number when test passed

	BOOL m_DemoMode;	// TRUE if demo mode enabled, otherwise false for real TUS timing

	int m_StabilityTimeOutSeconds;	// time in seconds for stability to be achived

	float m_maxSoakTemp;			// Maximum temperature in the current soak

	const QString  m_nonExistantTCIdent;

	const QString  m_errorTCIdent;
};

#endif // !defined(AFX_AMS2750TUSMGR_H__FFCCD88F_227F_4A6F_BF8F_9F220D50C782__INCLUDED_)

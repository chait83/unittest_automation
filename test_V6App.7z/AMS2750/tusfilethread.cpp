/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 AMS2750 data processing
/// @n Filename:  TUSFileThread.h
/// @n Description: Implementation of the CTUSFileThread class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  6 Aristos  1.0.1.3.1.0 9/19/2011 4:51:06 PM  Hemant(HAIL)  
//  Stability recorder source code (JI Release) updated for WatchDog
//  Timer functionality.
//  5 Stability Project 1.0.1.3 7/2/2011 5:02:12 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  4 Stability Project 1.0.1.2 7/1/2011 4:39:03 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  3 Stability Project 1.0.1.1 3/17/2011 3:20:51 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
// $
//
// **************************************************************************

#include "..\V6App\V6App.h"
#include "tusfilethread.h"
#include "AMS2750BuildTUSFile.h"
#include "ThreadInfo.h"

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif

/////////////////////////////////////////////////////////////////////////////
// CTUSFileThread

// IMPLEMENT_DYNCREATE(CTUSFileThread, QThread)

//****************************************************************************
///
/// Constructor
///
//****************************************************************************
CTUSFileThread::CTUSFileThread()
{
}
//****************************************************************************
///
/// Destructor
///
//****************************************************************************
CTUSFileThread::~CTUSFileThread() {
}
//****************************************************************************
// BOOL InitInstance() 
///
/// InitInstance event handler
///
//****************************************************************************
BOOL CTUSFileThread::InitInstance() {
	// TODO: perform and per-thread initialization here
	return TRUE;
}
//****************************************************************************
// BOOL ExitInstance() 
///
/// ExitInstance event handler
///
//****************************************************************************
int CTUSFileThread::ExitInstance() {
	// TODO: perform any per-thread cleanup here
	return QThread::ExitInstance();
}

BEGIN_MESSAGE_MAP(CTUSFileThread, QThread)
//{{AFX_MSG_MAP(CTUSFileThread)
// NOTE - the ClassWizard will add and remove mapping macros here.
//}}AFX_MSG_MAP
END_MESSAGE_MAP()

//****************************************************************************
// UINT TimeChangeNotifyFunc(LPVOID lpParam)
///
/// Main thread function
///
//****************************************************************************
UINT CTUSFileThread::ThreadProc(LPVOID lpParam)
{

	qDebug("TUS FILE THREAD STARTING\n");

	// Constant to represent Thread Exit Code Successful
	const UINT uiTUS_FILE_BUILDER_THREAD_EXIT_SUCCESSFUL = 0x00;

	// Constant to represent Thread Exit Code failed
	const UINT uiTUS_FILE_BUILDER_THREAD_OPERATIONAL_FAILURE = 0xFF;

	// Thread Exit Code 
	UINT threadExitCode = uiTUS_FILE_BUILDER_THREAD_OPERATIONAL_FAILURE;

	// Pointer to the TUS file builder active module
	C2750BuildTUSFile *pkTUSFileBuilder = static_cast< C2750BuildTUSFile* >( lpParam );

	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//after each iteration
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();

	//Notify that the WatchdogTimer that the TUSFileBuilder thread has 
	//started
	if(pThreadInfo != NULL)
	{
		pThreadInfo->UpdateThreadInfo(AM_TUS_FILE_BUILDER,true);
	}

	// santy check
	if( NULL != pkTUSFileBuilder )
	{
		// Loop shall remain active until the automated operations thread is required to Exit
		while( tfbOPMODE_EXIT != pkTUSFileBuilder->GetOperationalState() )
		{

			if(pThreadInfo != NULL)
			{
				//Ignore the TUSFileBuilderThread for WatchDog
				//thread after the wait is complete
				pThreadInfo->UpdateThreadInfo(AM_TUS_FILE_BUILDER,false);
			}
			// Wait for a System Message
			switch( pkTUSFileBuilder->EventMessageHandler( INFINITE ) )
			{
				case V6ACTMOD_EVENT_TIMEOUT:
				// shouldn't really happen so we'll have to ignore it					
				//qDebug("TUS FILE THREAD TIMEOUT - SHOULD NOT HAPPEN SO PLEASE INVESTIGATE\n");
				break;
				case V6ACTMOD_OK:
				// message must have been received - do nothing as already handled in the EventMessageHandler method
				break;

				default: /* Do Nothing */break;

			} // End of SWITCH

			if(pThreadInfo != NULL)
			{
				//Start considering the TUSFileBuilderThread for WatchDog
				//thread after the wait is complete
				pThreadInfo->UpdateThreadInfo(AM_TUS_FILE_BUILDER,true);
				//Update the Thread Counter for the Tusfile
				//thread after each iteration
				pThreadInfo->UpdateThreadCounter(AM_TUS_FILE_BUILDER);
			}
		} // End of WHILE 

		// exiting but we have been running successfully
		threadExitCode = uiTUS_FILE_BUILDER_THREAD_EXIT_SUCCESSFUL;

		if(pThreadInfo != NULL)
		{
			//Notify that the TUS File Builder thread is exiting
			pThreadInfo->UpdateThreadInfo(AM_TUS_FILE_BUILDER,false);
		}

	} // End of IF

	qDebug("TUS FILE THREAD SHUTDOWN\n");

	return( threadExitCode );
}

//************************************************************************************
// Module  AMS2750
// Filename  AMS2750processTUSFile.h
// Copyright GA Digital 2008
/// **********************************************************************************
/// @n Module: 	  AMS2750 file processing
/// @n Filename:  AMS2750processTUSFile.h
/// @n Description: Process information in TUS file for use in report 
///
// ***********************************************************************************

#ifndef _AMS2750PROCFILE_H
#define _AMS2750PROCFILE_H

#include "AMS2750DataStruct.h"
#include "V6crc.h"
#include "Defines.h"

// return codes for C2750parseTUSFile API
typedef enum {
	PF_OK = 0,					// Generic ok, no errors
	PF_FAILED,					// Generic Failure

	PF_FILE_CORRUPT,			// CRC failed on file

	PF_STRUCTURE_FOUND,			// Structure type and/or instance found
	PF_STRUCTURE_NOT_FOUND,		// Structure type and/or instance not found
	PF_STRUCTURE_TOO_LARGE,	// Structure found but was too large (indicating a newer structure in file) so truncated to code structure size
	PF_STRUCTURE_TOO_SMALL,	// Structure found but was too small (indicating an older structure in file) so code structure zeroed and file struct copied into start

	PF_LOG_BLOCK_FOUND,			// Log block was found in list of log blocks		
	PF_LOG_BLOCK_NOT_FOUND,		// Log block not found in list of log blocks

} T_C2750PROCESSFILE_RES;

class C2750parseTUSFile {
protected:
	T_P2750FILEHEADEROVERLAY pTUSData;		// Pointer to data header at start of file
	T_P2750LOGDATAOVERLAY pTUSLog;			// Pointer to log data at end of file

public:
	C2750parseTUSFile();
	~C2750parseTUSFile() {
		if (pTUSData)
			delete pTUSData;
		pTUSLog = NULL;
	}

	// API methods

	// Initialise and validate
	void InitTUSFile(void *pFilePtr);
	T_C2750PROCESSFILE_RES ValidateFile(T_STRUCTURE_IDENT &errStruct, int &instance);

	// Data and configuration structure access methods
	T_C2750PROCESSFILE_RES getTUSHeader(T_P2750FILEHEADER pTUSHeader);
	T_C2750PROCESSFILE_RES getTestData(T_PTUSTESTDATA ptrTestData);
	T_C2750PROCESSFILE_RES getSoakData(T_PTUSSOAKDATA ptrSoakData, int soakNumber);
	T_C2750PROCESSFILE_RES getTestConfig(T_PTUSTESTCONFIG ptrTestConfig);
	T_C2750PROCESSFILE_RES getSensorConfig(T_PTUSSENSORCONFIG ptrSensorConfig, int SensorID);

	// Log Data access methods
	T_C2750PROCESSFILE_RES getLogHeader(T_PTUSDATAREADINGHEADER pLogHeader);
	T_C2750PROCESSFILE_RES getLogDataBlock(int seqNumber, T_PTUSDATAREADING pLogReading);

	void SetTUSDataPtr(T_P2750FILEHEADEROVERLAY ptFileHeader) {
		pTUSData = ptFileHeader;
		pTUSLog = NULL;
	}

protected:
	T_C2750PROCESSFILE_RES findStruct(T_STRUCTURE_IDENT sType, int sInstance, int &theIndex);
	T_C2750PROCESSFILE_RES getStruct(T_STRUCTURE_IDENT sType, int sInstance, void *structData, int structSize);

};

#endif //_AMS2750PROCFILE_H

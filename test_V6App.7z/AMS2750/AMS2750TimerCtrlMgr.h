/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 AMS2750 data processing
/// @n Filename:  AMS2750TimerCtrlMgr.h
/// @n Description: Definition of the CAMS2750TimerCtrlMgr class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  3 Stability Project 1.0.1.1 7/2/2011 4:55:23 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  2 Stability Project 1.0.1.0 7/1/2011 4:27:07 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  1 V6 Firmware 1.0 9/23/2008 12:12:17 PM  Build Machine  
// $
//
// **************************************************************************

#if !defined(AFX_AMS2750TIMERCTRLMGR_H__0995F250_3693_45AA_8571_50BF875654B4__INCLUDED_)
#define AFX_AMS2750TIMERCTRLMGR_H__0995F250_3693_45AA_8571_50BF875654B4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ams2750timerctrlmgr.h : header file
//
class CAMS2750TUSMgr;

const int AMS2750_TIMER_PROCESS_SECONDS = 1;		// Process the timers every 10 seconds

/// Enum indicating the AMS2750 timer types
typedef enum T_AMS2750_TIMER_TYPES {
	AMS2750_TIMER_TYPE_TUS = 0,
	AMS2750_TIMER_TYPE_SAT,
	AMS2750_TIMER_TYPE_INST_CAL,
	AMS2750_TIMER_TYPE_CONTROL_TC,
	AMS2750_TIMER_TYPE_MAX_TIMERS
} T_AMS2750_TIMER_TYPES;

// Structure for individual timers
typedef struct {
	ULONG dueDate;
	USHORT status;
	USHORT padding;

} T_AMSTIMER_INFO;

// Main time NV structure
typedef struct {
	T_AMSTIMER_INFO timer[BATCH_GROUPINFO_SIZE][AMS2750_TIMER_TYPE_MAX_TIMERS];
} T_AMSTIMER_NV;

//**CAMS2750TimerCtrlMgr***********************************************************
///
/// @brief Singleton class used to manage the AMS2750 Timer Status information and provide an 
/// interface between the data processing and UI
/// 
/// Singleton class used to manage the AMS2750 Timer Status information and provide an 
/// interface between the data processing and UI
///
//****************************************************************************
class CAMS2750TimerCtrlMgr {
public:

	/// Enum indicating the status of a AMS2750 Timer
	enum T_AMS2750_TIMER_STATUS {
		TIMER_DISABLED = 0, TIMER_GOOD, TIMER_WARNING, TIMER_EXPIRED
	};

	// Method that creates and initialises the singleton
	static CAMS2750TimerCtrlMgr* Instance();

	// Destructor
	~CAMS2750TimerCtrlMgr() {
		;
	}

	// Initialise the timers
	void Initialise();

	// Configure the timers
	void Configure();

	// Configure the timers
	void Process();

	// Method that returns the timers current status
	const T_AMS2750_TIMER_STATUS GetTimerStatus(const T_AMS2750_TIMER_TYPES eTIMER_TYPE,
			const USHORT usGROUP_NO) const {
		return (T_AMS2750_TIMER_STATUS) m_pTimerNV->timer[usGROUP_NO][eTIMER_TYPE].status;
	}

	// Method that returns the timers current cal date
	const ULONG GetTimerCalDate(const T_AMS2750_TIMER_TYPES eTIMER_TYPE, const USHORT usGROUP_NO) const {
		return m_pTimerNV->timer[usGROUP_NO][eTIMER_TYPE].dueDate;
	}

	// Method that sets the timers current cal date
	void SetTimerCalDate(const T_AMS2750_TIMER_TYPES eTIMER_TYPE, const USHORT usGROUP_NO, const ULONG ulNEW_CAL_DATE) {
		m_pTimerNV->timer[usGROUP_NO][eTIMER_TYPE].dueDate = ulNEW_CAL_DATE;
	}

	// Method that enables the selected timer
	void EnableTimer(const T_AMS2750_TIMER_TYPES eTIMER_TYPE, const USHORT usGROUP_NO);

	// Method that disables the selected timer
	void DisableTimer(const T_AMS2750_TIMER_TYPES eTIMER_TYPE, const USHORT usGROUP_NO);

	// Method that returns the number of days remaining until the calibration date
	const long GetDaysUntilCalExpiry(const T_AMS2750_TIMER_TYPES eTIMER_TYPE, const USHORT usGROUP_NO);

	// Accessor method that retunrs the minimum number of days allowable before calibration
	// expiry warnings are displayed
	const USHORT GetExpiryWarningCalibLimitDays(const USHORT usGROUP_NO) const {
		return m_usEXPIRY_WARNING_CALIB_LIMIT_DAYS;
	}

	// Get the next test interval
	ULONG GetNextTestInterval(BOOL IsTUS, T_PFURNACE pFurnace);

	// Post status change to event list and trigger event cause
	void PostStatusChange(int GroupIndex, T_AMS2750_TIMER_TYPES typeIndex, T_AMS2750_TIMER_STATUS status);

private:
	// Constructor
	CAMS2750TimerCtrlMgr();

	// Internal timer processing
	BOOL CAMS2750TimerCtrlMgr::ProcessTimers();

	// Singleton auto pointer
	static std::auto_ptr<CAMS2750TimerCtrlMgr> ms_kAMS2750TimerCtrlMgr;

	// Handle to the creation mutex
	static HANDLE ms_hCreationMutex;

	// Non volatile memory for timers
	T_AMSTIMER_NV *m_pTimerNV;

	// Variable indicating the minimum number of days allowable before calibration expiry warnings 
	// are displayed
	const USHORT m_usEXPIRY_WARNING_CALIB_LIMIT_DAYS;

	CAMS2750TUSMgr *m_pTUSMgr;

	BOOL m_IsActive;						// Is processing active
	int m_processCnt;					// Countdown for processing 
	int m_processReload;				// Reload time for processing

	int m_daysleft[BATCH_GROUPINFO_SIZE][AMS2750_TIMER_TYPE_MAX_TIMERS];

};

#endif // !defined(AFX_AMS2750TIMERCTRLMGR_H__0995F250_3693_45AA_8571_50BF875654B4__INCLUDED_)

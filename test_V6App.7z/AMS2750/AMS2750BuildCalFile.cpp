//************************************************************************************
// Module  AMS2750
// Filename  AMS2750BuildCalFile.cpp
// Copyright GA Digital 2021
/// **********************************************************************************
/// @n Module: 	  AMS2750 fie processing
/// @n Filename:  AMS2750BuildCalFile.cpp
/// @n Description: Build information into TUS data file 
///
// ***********************************************************************************

#include "AMS2750BuildCalFile.h"
#include "V6globals.h"

#if defined (DBG_FILE_LOG_AMS_DBG_ENABLE )
		CDebugFileLogger m_errorFileLogger1(L"\\SDMemory\\AMSCAL_BuildLogFile.txt", TRUE, (15*1024*1024)); //Veeru - DebugFile Logger integration
#endif

//****************************************************************************************
///
/// Constructor
///
//****************************************************************************************
CAMS2750BuildCalFile::CAMS2750BuildCalFile() : m_bInitialised(false) {
}
//****************************************************************************************
///
/// Destructor
///
//****************************************************************************************
CAMS2750BuildCalFile::~CAMS2750BuildCalFile() {
	SetCalDataPtr (NULL);
	if (m_bInitialised) {
		m_kCalDataFile.Close();
	}
}
//****************************************************************************
///
/// Method that validates (and creates if it does not exist) a cal data file
///
/// @[param[in] QString   rstrFilename - the required cal filename
///
/// @return true if the file was okay, false if the file couldn't be opened due to a problem
///
//****************************************************************************
const bool CAMS2750BuildCalFile::InitialiseCalFile(QString  &rstrFilename) {
	bool bSuccess = false;
	FileException kEx;

#if defined (DBG_FILE_LOG_AMS_DBG_ENABLE)
	QString   strLogMessage;
	strLogMessage.asprintf(L"CAMS2750BuildCalFile::InitialiseTUSFile - GTC:%d\r\n", GetTickCount());
	m_errorFileLogger1.WriteToDebugLogFile(strLogMessage);
#endif

	if (!m_kCalDataFile.FileExists(rstrFilename)) {
		// the file does not exist therefore create it
		// to avoid fragmentation this file is always present and is fixed in length
		if (m_kCalDataFile.Open(rstrFilename,  | QFile::ReadWrite, &kEx)) {
			bSuccess = true;

			// allocate the maximum file size
			m_kCalDataFile.SetLength(CAL_MAX_FILE_SIZE);

			// write the dummy data to the file so it is correctly populated
			ClearCalDataFile();
		} else {
			QString  strError("");
			// couldn't create the file and open the file for writing
			bSuccess = false;
			WCHAR wcaError[50];
			kEx.GetErrorMessage(wcaError, 50);
			CalDataFileError(wcaError, rstrFilename);
		}
	} else {
		// the file exists already so open it
		if (m_kCalDataFile.Open(rstrFilename, QFile::ReadWrite, &kEx)) {
			bSuccess = true;
		} else {
			// couldn't open the file for writing
			WCHAR wcaError[50];
			bSuccess = false;
			kEx.GetErrorMessage(wcaError, 50);
			CalDataFileError(wcaError, rstrFilename);
		}
	}

	if (bSuccess) {
		// if we get to this point then all should be well and we have the file open and readable
		// we must now validate the file contents so create a buffer bog enough to hold the entire file
		// contents
		const ULONG ulFILE_LENGTH = CAL_MAX_FILE_SIZE;
		UCHAR *pcCalDataFile = new UCHAR[ulFILE_LENGTH + 1];
		memset(pcCalDataFile, 0, ulFILE_LENGTH + 1);

		if (pcCalDataFile) {
			// proceeed with the validition
			m_kCalDataFile.seek(0);
			m_kCalDataFile.Read(pcCalDataFile, ulFILE_LENGTH);

			// update the file pointer so it looks at this memory based copy of the data
			InitCalFile(pcCalDataFile);

			// validate the file now
			T_C2750PROCESSFILE_RES result = PF_OK;
			T_STRUCTURE_IDENT errStruct;
			int iInstance;

			// validate the file - failures will not necessarily result in the file being wiped as some data is resent
			// by the cal manager
			result = ValidateCalFile(errStruct, iInstance);

			// check the validation result
			if (result == PF_OK) {
				// all good
			} else {
				// file corrupt - let the there has been a problem which will make is effectively restart the TUS
				LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR,
						L"AMS2750 ERROR - wiped calibration file due to corruption!!!");

				// write the empty data to the file so it is correctly populated
				ClearCalDataFile();

				// carry on normally though
				bSuccess = true;
			}

			// now free the memory used for the validation
			delete[] pcCalDataFile;
			SetCalDataPtr(&m_tFileHeader);

			// Copy the file header information into our copy of the header
			m_kCalDataFile.seek(0);
			m_kCalDataFile.Read(&m_tFileHeader, sizeof(T_2750FILEHEADEROVERLAY));
		} else {
			// couldn't create the memory based buffer
			LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR,
					L"AMS2750 ERROR - Could not validate the calibration data file!");
			V6CriticalMessageBox(NULL, L"Cannot validate calibration file as run out of memory", L"AMS2750 ERROR",
					MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST);
			bSuccess = false;
		}
	} else {
		// there was a problem opening or creating the cal file - this time we will fail and exit, but hopefully
		// the file will have been deleted so if this process is repeated then the file can be created and written to
	}

	// check everything has been successful
	if (bSuccess) {
		m_bInitialised = true;
	}

	return bSuccess;
}
//****************************************************************************************
///
/// Method that adds the specified structure to the calibration file
///
///	@param[in] void *structPtr - Pointer to the structure we wish to add
///	@param[in] int structSize - The length of the structure in bytes
///	@param[in] T_STRUCTURE_IDENT structIdent - The type of the structure
///	@param[in] int structInstance - The instance number of the structure
///
/// @return BF_OK if all went well, otherwise an error code 
///
//****************************************************************************************
T_C2750BUILDFILE_RES CAMS2750BuildCalFile::AddStruct(void *structPtr, int structSize, T_STRUCTURE_IDENT structIdent,
		int structInstance) {
	// don't proceed if not initialised
	if (!m_bInitialised) {
		return BF_NOT_INITIALISED;
	}

	int sIndex = m_tFileHeader.fh.numStructures;
	T_C2750BUILDFILE_RES retVal = BF_FAILED;
	if (sIndex < NUM_STRUCT_SLOTS) {
		// check to see if the file exists already
		int theIndex = 0;
		if (PF_STRUCTURE_FOUND == indexOfStruct(structIdent, structInstance, theIndex)) {
			T_PTUSSTRUCTIDENT ptrIndex = &m_tFileHeader.structList[theIndex];
			int copyLen = ptrIndex->length;
			// test for any size difference within structures
			if (ptrIndex->length < structSize) {
				// the source structure(file) is smaller then the current structure built in codebase, so this would
				// inducate that the source structure is older, so we return all we can and set the rest of the struct to 0
				memset(structPtr, 0, structSize);
				//retVal = PF_STRUCTURE_TOO_SMALL;
			} else if (ptrIndex->length > structSize) {
				// the source structure(file) is bigger then the current structure built in codebase, this would indicate that 
				// the source structure is newer, so we will truncate the source structure to fit in the destination.
				copyLen = structSize;// Set the copy length to struct size as previously it was set to larger source struct size
				//retVal = PF_STRUCTURE_TOO_LARGE;
			}
			// Copy the source structure to the destination
			m_kCalDataFile.Seek(ptrIndex->startPos, 0);
			m_kCalDataFile.Write(structPtr, copyLen);
			UpdateCRCOnStructure(theIndex, structPtr);									// Update the CRC in the table
		} else {
			// this is a new structure therefore insert
			// Get the start point for the new structure
			int structBase = sizeof(T_2750FILEHEADEROVERLAY);
			if (sIndex != 0) {
				// Not the first structure, so take from previous entry
				structBase = m_tFileHeader.structList[sIndex - 1].startPos
						+ m_tFileHeader.structList[sIndex - 1].length;
			}

			// Check if we have room to proceed and add structure
			if ((structBase + structSize) <= CAL_MAX_FILE_SIZE) {
				// Yes we have room, add the structure and update the table
				m_kCalDataFile.Seek(structBase, 0);
				m_kCalDataFile.Write(structPtr, structSize);

				m_tFileHeader.structList[sIndex].length = structSize;					// Set the structure table entry
				m_tFileHeader.structList[sIndex].startPos = structBase;
				m_tFileHeader.structList[sIndex].ident = structIdent;
				m_tFileHeader.structList[sIndex].instance = structInstance;
				m_tFileHeader.fh.offSetOfLogData = structBase + structSize;	// Set position where log data can be added
				UpdateCRCOnStructure(sIndex, structPtr);								// Update the CRC in the table
				retVal = BF_OK;
			} else {
				retVal = BF_STRCUTURE_MAP_FULL; // Structure map is full
			}
			m_tFileHeader.fh.numStructures++;		// Increment number of structures in table
			UpdateHeaderCRC();					// Update the CRC on the header after data added.
		}
	} else {
		retVal = BF_STRCUTURE_MAP_FULL;		// Structure map is full
	}
	return retVal;

}
//****************************************************************************************
///
/// Method that updates the CRC in the TUS file following the addition of a structure
///
///	@param[in] void *structPtr - the index point of the added structure
///	@param[in] void *structPtr - the structure to CRC
///
//****************************************************************************************
void CAMS2750BuildCalFile::UpdateCRCOnStructure(int sIndex, void *structPtr) {
	m_tFileHeader.structList[sIndex].crc = CrcCalc(reinterpret_cast<UCHAR*>(structPtr),
			m_tFileHeader.structList[sIndex].length);
}
//****************************************************************************************
///
/// Method that updates the CRC in the header of the TUS file
///
//****************************************************************************************
void CAMS2750BuildCalFile::UpdateHeaderCRC() {
	CrcInsert((UCHAR*) &m_tFileHeader, sizeof(T_2750FILEHEADER));
}
//****************************************************************************************
///
/// Method that adds the general calibration data structure to the file
///
/// @param[in]	T_PTUSSENSORCONFIG pStruct - Pointer to the general calibration data structure we wish to add
///
/// @return BF_OK if all went well, otherwise an error code 
///
//****************************************************************************************
T_C2750BUILDFILE_RES CAMS2750BuildCalFile::AddGeneralCalibrationStructure(T_PAMS2750GENCAL pStruct) {
	// Add the test data structure to the file space
	return AddStruct(pStruct, sizeof(T_AMS2750GENCAL), ST_AMSGENCALDATA, 0);
}
//****************************************************************************************
///
/// Method that adds a sensor input calibration results structure to a file (cal or tus file)
///
/// @param[in]	T_PSENSORCALDATA pStruct - Pointer to the sensor input calibration results
///					structure we wish to add
/// @param[in]	int instance - The zero-based instance number of the sensor input
///
/// @return BF_OK if all went well, otherwise an error code 
///
//****************************************************************************************
T_C2750BUILDFILE_RES CAMS2750BuildCalFile::AddSensorInputCalibrationStructure(T_PSENSORINPUTCALDATA pStruct,
		int instance) {
	// Add the sensor calibration results structure to the file space
	return AddStruct(pStruct, sizeof(T_SENSORINPUTCALDATA), ST_AMSSENSORINPUTCALDATA, instance);
}

//****************************************************************************
///
/// Method that clears the cal data file usually at the end of a cal
///
//****************************************************************************
void CAMS2750BuildCalFile::ClearCalDataFile() {
	// the file should already be open and of the correct length - we need to set all the structures back to default

	// Setup the header
	memset(&m_tFileHeader, 0, sizeof(T_2750FILEHEADEROVERLAY));

	m_tFileHeader.fh.version = TUSFILE_VERSION;
	m_tFileHeader.fh.reportNumber = 1;
	CTVtime aTime;
	aTime.TimeNow();
	m_tFileHeader.fh.timeOfReport = aTime.GetMicroSecs();

	SetCalDataPtr(&m_tFileHeader);

	// finally update the header
	UpdateHeaderCRC();
	WriteHeaderToDisk();
}
//****************************************************************************
///
/// Method that writes the header information to disk
///
//****************************************************************************
void CAMS2750BuildCalFile::WriteHeaderToDisk() {
	m_kCalDataFile.seek(0);
	m_kCalDataFile.Write(&m_tFileHeader, sizeof(T_2750FILEHEADEROVERLAY));
}
//****************************************************************************
///
/// Method that logs a file error and deletes the cal data file
///
/// param[in]	const QString   &rstrERROR - String containing a description of the error
/// param[in]	QString   &rstrFilename - the file to delete
/// 
//****************************************************************************
void CAMS2750BuildCalFile::CalDataFileError(const QString  &rstrERROR, QString  &rstrFilename) {
	// log the error message
	QString  errString;
	errString.asprintf(L"AMS2750 Data File Error - %s", rstrERROR);
	LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, errString);

	// close the file just in case it is still open
	m_kCalDataFile.Close();

	// delete the file
	m_kCalDataFile.DeleteFile(rstrFilename);

	// halt the program thus forcing a restart which should recreate the TUS data file
	V6CriticalMessageBox(NULL, rstrERROR, L"Calibration Data File Error", MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST);
}

//****************************************************************************************
/// API - Validates the file within the memory block, running though all available structures 
/// checking the CRC's, if a structure is found to be corrupted then the type of structure
/// and it's instance number will be passed back.
/// 
/// @param[out]	&errStruct - reference to T_STRUCTURE_IDENT used to identify type of corrupted structure
/// @param[out]	&instance - reference to int used to identify the instance number of the corrupted structure
///
/// @return		T_C2750PROCESSFILE_RES where	
///					PF_FILE_CORRUPT indicates corruption identified in structure on &errStruct and &instance
///					PF_OK file integrity ok, and can be used for further processing
//****************************************************************************************
T_C2750PROCESSFILE_RES CAMS2750BuildCalFile::ValidateCalFile(T_STRUCTURE_IDENT &errStruct, int &instance) {
	T_C2750PROCESSFILE_RES retVal = PF_OK;
	// First check the CRC of the header
	if (CrcTest((UCHAR*) m_pCalData, sizeof(T_2750FILEHEADER)) == CRC_TEST_PASSED) {
		int iFailedSoaks = 0;

		// Header CRC ok, Run though all available structures in list, check the CRC's
		for (int sIndex = 0; sIndex < m_pCalData->fh.numStructures; sIndex++) {
			// Check CRC's of structures in list. 
			if (CrcCalc((UCHAR*) m_pCalData + m_pCalData->structList[sIndex].startPos,
					m_pCalData->structList[sIndex].length) != m_pCalData->structList[sIndex].crc) {

				// CRC FAILED - check what exactly failed
				// Set information to show a structure in table is corrupted
				errStruct = (T_STRUCTURE_IDENT) m_pCalData->structList[sIndex].ident;
				instance = m_pCalData->structList[sIndex].instance;

				switch (errStruct) {
				case ST_TUSSOAKDATA:
				case ST_2750FILEHEADER:
				case ST_TUSTESTDATA:
				case ST_TUSTESTCONFIG:
				case ST_TUSSENSORCONFIG:
				case ST_TUSDATAREADINGHEADER:
				case ST_TUSDATAREADING:
					// shouldn't exist in this file
					LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR,
							L"AMS2750 WARNING - unnecessary data structure corrupt. Ignoring...");
					break;
				case ST_AMSGENCALDATA:
					LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR,
							L"AMS2750 ERROR - TUS general calibration data corrupted!!!");
					break;
				case ST_AMSSENSORINPUTCALDATA:
					LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR,
							L"AMS2750 ERROR - TUS sensor calibration data corrupted!!!");
					break;
				default:
					// must be an unknown structure therefore log the error but continue anyway
					LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_WARNING,
							L"AMS2750 WARNING - unknown data structure corrupt. Ignoring...");
					break;
				}
				// check if there has been a fatal error
				if (retVal == PF_FILE_CORRUPT) {
					break;
				}
			}
		}
	} else {
		// CRC FAILED, Set information to show header is corrupted
		errStruct = ST_2750FILEHEADER;		// Set an indication of the structure which has the problem.
		instance = 0;
		LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "AMS2750 ERROR - Calibration header corrupted!!!");
		retVal = PF_FILE_CORRUPT;
	}
	return retVal;
}


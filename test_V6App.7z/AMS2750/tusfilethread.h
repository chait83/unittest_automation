/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 AMS2750 data processing
/// @n Filename:  TUSFileThread.h
/// @n Description: Definition of the CTUSFileThread class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  3 Stability Project 1.0.1.1 7/2/2011 5:02:12 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  2 Stability Project 1.0.1.0 7/1/2011 4:27:59 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  1 V6 Firmware 1.0 9/23/2008 12:12:17 PM  Build Machine  
// $
//
// **************************************************************************

#if !defined(AFX_TUSFILETHREAD_H__7F345FF2_E468_4BD5_BAF0_389F4A9A7EEB__INCLUDED_)
#define AFX_TUSFILETHREAD_H__7F345FF2_E468_4BD5_BAF0_389F4A9A7EEB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// tusfilethread.h : header file
//

//**CTUSFileThread***********************************************************
///
/// @brief Thread class used to manage the TUS data file
/// 
/// Thread class used to manage the TUS data file
///
//****************************************************************************
class CTUSFileThread: public QThread {
	// DECLARE_DYNCREATE (CTUSFileThread)
protected:
	CTUSFileThread();  // protected constructor used by dynamic creation

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTUSFileThread)
public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

	// Thread function responsible for the managing the TUS file buildeer and the state of the thread
	static UINT ThreadProc(LPVOID lpParam);

// Implementation
protected:
	virtual ~CTUSFileThread();

	// Generated message map functions
	//{{AFX_MSG(CTUSFileThread)
	// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG



private:

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TUSFILETHREAD_H__7F345FF2_E468_4BD5_BAF0_389F4A9A7EEB__INCLUDED_)

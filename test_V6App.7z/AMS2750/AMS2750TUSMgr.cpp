/// @file 
/// **************************************************************************
/// ?Honeywell Trendview
/// **************************************************************************
/// @n Module: 	AMS2750 data processing
/// @n Filename:	AMS2750TUSMgr.cpp
/// @n Description: Implementation of the CAMS2750TUSMgr class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//	12	Aristos 102.6.02R and 200.1.01R 11/27/2017 10:00:00 AM Vedant (HTS)
//		Added TUS Event Triggers for Soak Started, Stability Achieved and Soak Complete
// 11	Aristos	1.4.1.3.1.1 9/21/2011 3:15:56 PM	Hemant(HAIL) 
//		Updated watchdog threadinfo call check
// 10	Aristos	1.4.1.3.1.0 9/19/2011 4:51:09 PM	Hemant(HAIL) 
//		Stability recorder source code (JI Release) updated for WatchDog
//		Timer functionality.
// 9	Stability Project 1.4.1.3	7/2/2011 4:55:23 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 8	Stability Project 1.4.1.2	7/1/2011 4:37:56 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// $
//
// **************************************************************************
#include <math.h>

#include "AMS2750TUSMgr.h"
///TODO : Uncomment the dlg include files
//#include "AlphaNumEditDlg.h"
#include "EventManager.h"
//#include "DeviceSelectionDlg.h"
#include "InputConditioning.h"
//#include "PPIOServiceManager.h"
#include "ThreadInfo.h"
//#include "AMS2750InputCalMgr.h"
#include "PPIOServiceManager.h"
#include "TVtime.h"
#if defined (DBG_FILE_LOG_AMS_DBG_ENABLE )
CDebugFileLogger m_errorFileLogger(L"\\SDMemory\\AMS_LogFile.txt", TRUE, (15*1024*1024)); //Veeru - DebugFile Logger integration
#endif
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif

#define MSX_ERROR_LOG_FILE_SIZE (15*1024*1024)//(20*1024*1024) //so mB file size for error log
//BOOL m_IsLastOneDiscard = FALSE; // Flag used for AMS 2 mins issue fix i.e to Discard Extra record from Addline.
// Static const/initialsation
std::auto_ptr<CAMS2750TUSMgr> CAMS2750TUSMgr::ms_kAMS2750TUSMgr;

//****************************************************************************
///
/// Singleton Accessor/Creator
///
/// @return A pointer to the singleton instance of the class
/// 
//****************************************************************************
CAMS2750TUSMgr* CAMS2750TUSMgr::Instance() {
	// check if the pointer exists yet
	if (ms_kAMS2750TUSMgr.get() == NULL) {
		DWORD waitSingleObjectResult = WAIT_OBJECT_0;
		// An instance has yet to be completed
		ms_hCreationMutex = CreateMutex(NULL,		// No security descriptor
				FALSE,						// Mutex object not owned
				TEXT("CAMS2750TUSMgr"));	// Object name
		waitSingleObjectResult = ms_hCreationMutex.tryLock(g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);

		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:
			// Object was signaled
			if (NULL == ms_kAMS2750TUSMgr.get()) {
				// not been created yet therefore create one now
				std::auto_ptr<CAMS2750TUSMgr> kAMS2750TUSMgr(new CAMS2750TUSMgr);
				ms_kAMS2750TUSMgr = kAMS2750TUSMgr;
			}
			if (FALSE == ms_hCreationMutex.unlock();)
				V6WarningMessageBox(NULL, L"Failed to create CAMS2750TUSMgr mutex", L"Error", MB_OK);
			break;

		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
			V6WarningMessageBox(NULL, L"CAMS2750TUSMgr WaitForSingleObject Error", L"Error", MB_OK);
			break;
		}
		// Close the Mutex as no longer required
		//No need to close the mutex in Qt
	}
	return ms_kAMS2750TUSMgr.get();
}
//****************************************************************************
///
/// Constructor
///
//****************************************************************************
CAMS2750TUSMgr::CAMS2750TUSMgr() : m_usMAX_NO_OF_TUS_SENSORS(41), m_CurrDefSoakTolerance(2.0), m_rampTimer(
		TIMER_HIGH_RES), m_lagTimer(TIMER_HIGH_RES), m_soakTimer(TIMER_HIGH_RES), m_surveyTimer(TIMER_HIGH_RES), m_stabilityTimer(
		TIMER_HIGH_RES), m_AutoStabTimer(TIMER_HIGH_RES), m_AutoStopTimer(TIMER_HIGH_RES), m_nonExistantTCIdent(L"TC0"), m_errorTCIdent(
		L"TCERR"), m_currlogSeqNumber(0) {
	// this will probably change to get the state from SRAM or the DIT
	m_eTUSState = tusSTOPPED;

	// Structure containing the TUS test configuration data
	memset(&m_tTestConfig, 0, sizeof(T_TUSTESTCONFIG));

	// Array of Structures containing the sensor configurations
	m_taSensorsConfig = new T_TUSSENSORCONFIG[m_usMAX_NO_OF_TUS_SENSORS];
	memset(m_taSensorsConfig, 0, sizeof(T_TUSSENSORCONFIG) * m_usMAX_NO_OF_TUS_SENSORS);

	//not used in TTR6SETUP code
#ifndef TTR6SETUP
	m_ModuleMsgMgrClient.MMMClientRegister(MODULE_TUS_MGR, MODULE_SEND_ONLY, CAMQ_QUEUE_WRAP_DISABLED);
#endif

	m_IsInitialised = FALSE;
	m_ResetTUSStatus = FALSE;
	m_registerPowerFail = FALSE;
	m_IsLastOneDiscard = FALSE;
	m_IsAutoStop = FALSE;
}

//****************************************************************************
/// Initialise the TUS Manager
/// 
/// @return TRUE is initialised OK, otherwise FALSE
//****************************************************************************	
BOOL CAMS2750TUSMgr::Initialise() {
	if (m_IsInitialised == FALSE) {
		// Get access to the tabular data in SRAM
		CSRAMManager *pSRAM = CSRAMManager::GetHandle();
		CSRAMRegion *pRegion = NULL;
		CSRAMManager::regionError requestReturn = pSRAM->RequestRegion(REGION_AMS2750, &pRegion);
		if (requestReturn != CSRAMManager::REGION_OKAY) {
			V6CriticalMessageBox(NULL, L"REGION_AMS2750 SRAM request failed", L"Init AMS2750 SRAM",
					MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST);
			return FALSE;
		}
		m_pTUSNV = reinterpret_cast<T_PTUS_INFO>(pRegion->GetAddress());

		// Check for reset on NV information
		if (m_pTUSNV->main.signature != TUS_SRAM_SIGNATURE ||		// Signature has changed
				SRAM_STATE_FIRSTUSE == pRegion->GetAutoState() ||		// First use in SRAM
				pSYSTEM_INFO->IsDataResetRequested() == TRUE ||		// Data reset required
				pSYSTEM_INFO->FWOptionAMS2750ProcessAvailable() != m_pTUSNV->main.CurrProcessOption ||	// Process mode option code changed
				pSYSTEM_INFO->FWOptionTUSModeAvailable() != m_pTUSNV->main.CurrTUSOption)// TUS mode option code changed
						{
			// Reset all TUS data
			ResetTUSData();
			m_pTUSNV->main.CurrTUSOption =
			pSYSTEM_INFO->FWOptionTUSModeAvailable();	// Set TUS mode option check
			m_pTUSNV->main.CurrProcessOption =
			pSYSTEM_INFO->FWOptionAMS2750ProcessAvailable();	// Set process mode option check
		}
		pRegion->SetAutoStateToNormal();
		qDebug("TUS size = %d", sizeof(T_TUS_INFO));

		m_IsInitialised = TRUE;		// Confirm initialisation has been done
	}
	// Check if we need to recover the NV from a power fail,
	if (m_pTUSNV->main.globalStatus == TUS_GLOBAL_RUNNING && m_ResetTUSStatus == FALSE) {
		// if was running and power was off for less then 20 minutes
		if ( pSYSTIMER->GetLastTimeOffInSeconds() > TUS_SECONDS_POWER_OFF) {
			QString  diagMessage;
			diagMessage.asprintf(IDS_TUS_MGR_TUS_STOPPED_ON_RESUME);
			LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, diagMessage);
			m_NVRecoveryAttempt = FALSE;					// TUS allowable
			m_pTUSNV->main.globalStatus = TUS_GLOBAL_NOT_RUNNING;					// Set status to not running
			m_pTUSNV->prevSoak.test.soakStatus = SOAK_STATUS_NOTSTARTED;// Invalidate copy of previous completed soak.
		} else {
			// Has the power been off for more then 20 mins?
			m_NVRecoveryAttempt = TRUE;
		}
	} else {
		m_NVRecoveryAttempt = FALSE;	// Do not attempt a recovery on reset.
		m_pTUSNV->main.globalStatus = TUS_GLOBAL_NOT_RUNNING;	// Set status to not running
		m_pTUSNV->prevSoak.test.soakStatus = SOAK_STATUS_NOTSTARTED;	// Invalidate copy of previous completed soak.
	}
	return TRUE;
}

//****************************************************************************
/// Initialise the TUS Manager
/// 
/// @return nothing
//****************************************************************************	
void CAMS2750TUSMgr::ResetTUSData() {
	// Reset the TUS data in NV
	memset(m_pTUSNV, 0, sizeof(T_TUS_INFO));		// Cleardown structure to 0
	m_pTUSNV->main.signature = TUS_SRAM_SIGNATURE;	// Setup signature
	qDebug("TUS : The TUS NV data was reset \n");
}

//****************************************************************************
/// Apply any configuration changes that are made on a configuration change
/// and at start-up.
///
/// @return nothing
//****************************************************************************
void CAMS2750TUSMgr::Configure() {
	// Check if "tusdemo.key" is present in keys directory on SD or USB
	if ( pSYSTEM_INFO->IsFunctionAvailable(FUNC_TUS_TEST_MODE, FALSE) == TRUE) {
		// Demo mode, reduced timings
		m_DemoMode = TRUE;
		m_StabilityTimeOutSeconds = TUS_DEMO_AUTO_STABILITY_TIME;
	} else {
		// Actual TUS mode, normal timings
		m_DemoMode = FALSE;
		m_StabilityTimeOutSeconds = TUS_AUTO_STABILITY_TIME;
	}

	// Check if TUS credit option is selected
	if ( pSYSTEM_INFO->GetAMS2750Mode() == AMS2750_TUS) {
		m_IsActive = TRUE;		// Yes, so set TUS mode as Active
	} else {
		m_IsActive = FALSE;		// No, do not activate or process TUS mode
	}

	// Get pointer to the Furnaces configuration for AMS2750
	CGeneralSetupConfig *pkGenCfg = pSETUP->GetGeneralSetupConfig();
	m_ptFurnaces = pkGenCfg->GetAMS2750FurnaceInfoBlock(CONFIG_COMMITTED);

	m_tTestConfig.recSerial = pSYSTEM_INFO->GetSerialNumber();
	m_tTestConfig.tempasprintf = pSYSTEM_INFO->GetDisplayTempUnits();
	m_tTestConfig.dataInterval = TUS_SECONDS_PER_READING;

	//< Test based content
	m_tTestConfig.Type = m_ptFurnaces->Furnaces[0].Type;
	m_tTestConfig.FurnaceClass = m_ptFurnaces->Furnaces[0].FurnaceClass + TUS_MIN_CLASS;
	m_tTestConfig.InstType = m_ptFurnaces->Furnaces[0].InstType;
	CStringUtils::SafeWcsCpy(m_tTestConfig.name, m_ptFurnaces->Furnaces[0].Name, TUSFURNACE_NAME_LEN);
	CStringUtils::SafeWcsCpy(m_tTestConfig.manufacturer, m_ptFurnaces->Furnaces[0].Manufacturer,
			TUSFURNACE_MANUFACTURER_LEN);
	CStringUtils::SafeWcsCpy(m_tTestConfig.modelNo, m_ptFurnaces->Furnaces[0].ModelNo, TUSFURNACE_MODELNO_LEN);
	CStringUtils::SafeWcsCpy(m_tTestConfig.surveyInst, L"Trendview Recorder", TUSFURNACE_SURVINST_LEN);

	m_tTestConfig.Shape = m_ptFurnaces->Furnaces[0].Shape;
	m_tTestConfig.MeasUnits = m_ptFurnaces->Furnaces[0].MeasUnits;

	DetermineControlTCInstance(m_tTestConfig.controlTCNumber);
	m_tTestConfig.numberOfSensors = 0;

	m_tTestConfig.height = m_ptFurnaces->Furnaces[0].Height;
	m_tTestConfig.width = m_ptFurnaces->Furnaces[0].Width;

	//E519766
	if (m_ptFurnaces->Furnaces[0].Shape == fsCYLINDRICAL) {
		//To calculate the volume of cylindrical shapes we
		//do not require depth. Hence set the value of depth as
		//1.So that the volume is calculated correctly.
		m_tTestConfig.depth = 1;
		m_tTestConfig.volume = (3.1415926 * m_tTestConfig.height * m_tTestConfig.width * m_tTestConfig.width
				* m_tTestConfig.depth) / 4;
	} else {
		m_tTestConfig.depth = m_ptFurnaces->Furnaces[0].Depth;
		m_tTestConfig.volume = m_tTestConfig.height * m_tTestConfig.width * m_tTestConfig.depth;
	}

	m_pkIOSetupCfg = pSETUP->GetIOSetupConfig();
	T_PAMS2750SENSORS ptSensors = m_pkIOSetupCfg->GetAMS2750SensorBlock(CONFIG_COMMITTED);
	T_PAICHANNEL ptAIChan = NULL;
	T_PMPCALCHANNELS pCommittedMpChannelCal = m_pkIOSetupCfg->GetMultiPointBlock(CONFIG_COMMITTED);

	m_numSensors = 0;
	// Update the sensor configurations
	for (USHORT usCount = 0; usCount < AMS2750SENSORS_SENSORS_SIZE; usCount++) {
		m_Sensor[usCount].calTable.FreeTables();		// Free any allocated cal tables

		memset(&m_Sensor[usCount], 0, sizeof(T_TUS_SENSOR_INFOMATION));
		// only send TUS TC's
		ptAIChan = m_pkIOSetupCfg->GetAnalogueInput(usCount, CONFIG_COMMITTED);

		CDataItemPen *pPenDIT = (CDataItemPen*) pGlbDIT->GetDataItemPtr(DI_PEN, 0, usCount);

		if ((ptAIChan != NULL) &&						// Include only if the
				(ptAIChan->Enabled == TRUE) &&	// Analogue channel enabled and
				(pPenDIT->IsEnabled() == TRUE) &&	// Corrisponding Pen is enabled
				IsTUSSensor(ptAIChan, ptSensors->Sensors[usCount]) &&	// It's a TC channel and
				(ptSensors->Sensors[usCount].TUSTC == TRUE))	// It's included in the TUS
				{
			// Configure the Sensor information structure
			T_PTUS_SENSOR_INFOMATION pSensor = &m_Sensor[m_numSensors];	// Get pointer to sensor information to populate
			pSensor->Index = usCount;		// Actual Sensor index
			pSensor->AnalogueConfig = m_pkIOSetupCfg->GetAnalogueInput(usCount, CONFIG_COMMITTED);

			pSensor->SensorConfig = &ptSensors->Sensors[usCount];
			pSensor->DataItem = pPenDIT;
			pSensor->IsUserEnabled = TRUE;		// Not user disabled during TUS

			// get the channel board cal information
			USHORT slotNo = 0;
			USHORT boardChanNo = 0;
			CSlotMap *pSlotMap = CSlotMap::GetHandle();
			pSlotMap->GetSlotAndChannelFromAnalSysChan(usCount, &slotNo, &boardChanNo, ZERO_BASED);

			T_PBOARDCALS ptBoardCals = m_pkIOSetupCfg->GetTopSlotBoardRangeCalInfo(slotNo, CONFIG_COMMITTED);
			T_PCHANCALPOINT ptCalPoints = &ptBoardCals->ChanCals[boardChanNo].PointCals;

			T_TUSMPCALCHANNEL *multiPointCal = &m_taSensorsConfig[m_tTestConfig.numberOfSensors].multiPointCal;
			T_MPCALCHANNEL *committedMultiPointCal = &pCommittedMpChannelCal->Channel[usCount];

			if (ptCalPoints->CalType == V6_MULTI_POINT_CAL) {
				multiPointCal->CalElements = committedMultiPointCal->CalElements;
			} else {
				// ignore single and dual point cal as shouldn't be used for AMS2750 because 3 points are required
				multiPointCal->CalElements = 0;
			}

			for (int calPointIndex = 0; calPointIndex < MPCALCHANNEL_CALPOINTS_SIZE; calPointIndex++) {
				if ((ptCalPoints->CalType == V6_MULTI_POINT_CAL) && (calPointIndex < multiPointCal->CalElements)) {
					// copy the existing multipoint cal.
					multiPointCal->CalPoints[calPointIndex].CalPoint =
					pSYSTEM_INFO->GetLocalTempFromDegC(committedMultiPointCal->CalPoints[calPointIndex].CalPoint);
					multiPointCal->CalPoints[calPointIndex].Offset =
					pSYSTEM_INFO->GetLocalTempFromDegCRelative(committedMultiPointCal->CalPoints[calPointIndex].Offset);
					multiPointCal->CalPoints[calPointIndex].PrevOffset =
					pSYSTEM_INFO->GetLocalTempFromDegCRelative(committedMultiPointCal->PrevCalPoints[calPointIndex]);
				} else {
					// indicate there are no calibration values - we can't do a memcpy here as there could be values
					// but they aren't being used as single point or dual point cal are selected so just ensure
					// the values are default
					multiPointCal->CalPoints[calPointIndex].CalPoint = 0.0F;
					multiPointCal->CalPoints[calPointIndex].Offset = 0.0F;
					multiPointCal->CalPoints[calPointIndex].PrevOffset = 0.0F;
				}
			}

			// Setup the Sensor configuration to be stored in file
			m_taSensorsConfig[m_tTestConfig.numberOfSensors].TCNumber = usCount + 1;
			CStringUtils::SafeWcsCpy(m_taSensorsConfig[m_tTestConfig.numberOfSensors].certNumber,
					pSensor->SensorConfig->CertNumber, TUSSENSOR_CERTNUMBER_LEN);
			CStringUtils::SafeWcsCpy(m_taSensorsConfig[m_tTestConfig.numberOfSensors].manufacturer,
					pSensor->SensorConfig->Manufacturer, TUSSENSOR_MANUFACTURER_LEN);
			CStringUtils::SafeWcsCpy(m_taSensorsConfig[m_tTestConfig.numberOfSensors].TCPosition,
					pSensor->SensorConfig->TCPosition, TUSSENSOR_TCPOSITION_LEN);

			if (pSensor->AnalogueConfig->Type == AI_CHANNEL_TYPE_TC) {
				m_taSensorsConfig[m_tTestConfig.numberOfSensors].type = pSensor->SensorConfig->Type;
			} else {
				// offset the type for RTs - this makes exporting to reports easier
				m_taSensorsConfig[m_tTestConfig.numberOfSensors].type = ttEXPENDABLE_RT + pSensor->SensorConfig->Type;
			}
			CStringUtils::SafeWcsCpy(m_taSensorsConfig[m_tTestConfig.numberOfSensors].serialNo,
					pSensor->SensorConfig->SerialNo, TUSSENSOR_SERIALNO_LEN);
			m_taSensorsConfig[m_tTestConfig.numberOfSensors].colour = *pSensor->DataItem->GetColour();

			// Setup rate of change pipes
			pSensor->stabilityPipe.CreatePipe(PIPE_RATE_OF_CHANGE, m_StabilityTimeOutSeconds, TRUE);

			// Setup the calibration table
			if (pSensor->SensorConfig->CalElements > 0) {
				pSensor->ISCalRequired = TRUE;
				// There is calibration to add to the sensor ranges
				if (pSensor->SensorConfig->CalElements == 1) {
					// it's a single point calibration only
					pSensor->ISCalSingle = TRUE;
					pSensor->singleOffSet =
					pSYSTEM_INFO->GetLocalTempFromDegCRelative(pSensor->SensorConfig->CalPoints[0].Offset);
				} else {
					// It's a multi point calibration, setup the calibration table
					GenerateCalTable(pSensor);
				}
			} else {
				pSensor->ISCalRequired = FALSE;
			}

			m_tTestConfig.numberOfSensors = ++m_numSensors;
			// check if we have reached the permitted number of TUS sensors
			if (m_tTestConfig.numberOfSensors == m_usMAX_NO_OF_TUS_SENSORS) {
				// we have therefore break out of the loop
				break;
			}
		}
	}
	// update the default soak tolerance given the furnace type
	UpdateFurnaceTolerance(static_cast<T_FURNACE_TYPE>(m_tTestConfig.Type), m_tTestConfig.FurnaceClass,
			static_cast<T_TEMPERATURE_TYPE>(m_tTestConfig.tempasprintf));

	// Calculate Adjhust number opf sensors (does not include control TC if enabled)
	m_numSensorsAdjusted = m_numSensors;
	if (m_tTestConfig.controlTCNumber != 0) {
		m_numSensorsAdjusted--;	// A Control TC is enabled so remove it from adjsuted count
	}

	// Update the soak configurations
	m_numSoaks = 0;
	m_maxSoakTemp = 0;
	for (USHORT usSoakCount = 0; usSoakCount < FURNACESCONFIG_SETPOINTS_SIZE; usSoakCount++) {
		memset(&m_Soak[usSoakCount], 0, sizeof(T_TUS_SOAK_INFORMATION));
		// only add enabled soaks
		if (m_ptFurnaces->Setpoints[usSoakCount].Enabled) {
			T_PTUS_SOAK_INFORMATION pSoak = &m_Soak[m_numSoaks++];
			pSoak->snv = &m_pTUSNV->soaks[usSoakCount];	// Ptr to NV for soak information
			pSoak->Index = usSoakCount;							// Index of soak

			// Check for reset of soak information
			BOOL clearThisSoak = FALSE;
			if (m_NVRecoveryAttempt == TRUE) {
				// we are trying to recover so this instance see if the current working instance is this soak
				if (pSoak->snv->Instance == m_pTUSNV->main.currentSoak + 1) {
					// This is the current soak, so we need to reset it, but only if it is part way though
					if (pSoak->snv->soakStatus == SOAK_STATUS_SOAK_DETECT
							|| pSoak->snv->soakStatus == SOAK_STATUS_IN_SOAK
							|| pSoak->snv->soakStatus == SOAK_STATUS_IN_STABILITY
							|| pSoak->snv->soakStatus == SOAK_STATUS_NOTSTARTED) {
						// Soak was mid run so we need to clear it down and allow it to be restarted
						clearThisSoak = TRUE;
					}
				} else {
					// add any sanity checks for this soak, either not started or complete
					if (pSoak->snv->soakStatus == SOAK_STATUS_NOTSTARTED) {
						// The soak has not been started so clear it down
						clearThisSoak = TRUE;
					}
				}
			} else {
				clearThisSoak = TRUE;
			}
			// Do we need to clear the current soak?
			if (clearThisSoak == TRUE) {
				// Yes, reset this soak NV
				ResetSoak(pSoak->Index, m_numSoaks - 1);
			}
			pSoak->lowerLimit = pSoak->snv->setPoint - pSoak->snv->tolerance;						// Lower soak limit
			pSoak->upperLimit = pSoak->snv->setPoint + pSoak->snv->tolerance;						// Upper soak limit

			if (m_maxSoakTemp < pSoak->upperLimit) {
				m_maxSoakTemp = pSoak->upperLimit;
			}
		} else {
			// Clear any soak status for soaks that have been might have been disabled
			m_pTUSNV->soaks[usSoakCount].soakStatus = SOAK_STATUS_NOTSTARTED;
		}
	}

	if (m_NVRecoveryAttempt == TRUE) {
		setStateMachine(TSM_RESUME_TUS);							// Resume the TUS after a power failure
		// Has it completed the last soak, and moved past.
		if (m_pTUSNV->main.currentSoak >= m_numSoaks) {
			// Yes so move back to lest soak
			m_pTUSNV->main.currentSoak = m_numSoaks - 1;
		}
	}

	m_pTUSNV->test.numSoaks = m_numSoaks;		// Setup number of soaks to NV
	m_firstIn = TRUE;							// It's the first time through

	m_pWorkSoak = &m_Soak[0];							// Setup convenient pointer to current working soak structure

	// Setup Data Items
	m_pkElapsedTimeDIT = static_cast<CDataItemGeneral*>( pDIT->GetDataItemPtr(DI_GENERAL, DI_GENTYPE_GENERAL,
			DI_GEN_AMS2750_TUS_ELAPSED_TIME));
	m_pkTUSStartTime = static_cast<CDataItemGeneral*>( pDIT->GetDataItemPtr(DI_GENERAL, DI_GENTYPE_GENERAL,
			DI_GEN_AMS2750_TUS_START_TIME));

	// Setup Max an MIn TC's

	m_MaxRunSensor = static_cast<CDataItemGeneral*>( pDIT->GetDataItemPtr(DI_GENERAL, DI_GENTYPE_GENERAL,
			DI_GEN_AMS2750_MAX_TC));
	m_MinRunSensor = static_cast<CDataItemGeneral*>( pDIT->GetDataItemPtr(DI_GENERAL, DI_GENTYPE_GENERAL,
			DI_GEN_AMS2750_MIN_TC));
	m_diffTC = static_cast<CDataItemGeneral*>( pDIT->GetDataItemPtr(DI_GENERAL, DI_GENTYPE_GENERAL,
			DI_GEN_AMS2750_TC_DIFF));

	m_gridLineUpper = FLT_MAX;
	m_gridLineLower = FLT_MAX;
	m_soakLevel = FLT_MAX;

	m_Direction = TUS_DIRECTION_UP;

	SetUpdateRequired(TRUE);

	// If there are no sensors or no soaks configured, do not run TUS process at all.
	if (m_numSensors == 0 || m_numSoaks == 0) {
		m_IsActive = FALSE;
	}
}

//****************************************************************************
/// Generate calibration table
/// 
/// @param[in]	pSensor - pointer to senors to setuop calibration table
///
/// @return nothing
//****************************************************************************	
void CAMS2750TUSMgr::GenerateCalTable(T_PTUS_SENSOR_INFOMATION pSensor) {

	pSensor->ISCalSingle = FALSE;

	T_IP_TABLE_ELEMENT destTable[AMS2750SENSOR_CALPOINTS_SIZE];

	for (int tabElement = 0; tabElement < pSensor->SensorConfig->CalElements; tabElement++) {
		destTable[tabElement].in = pSYSTEM_INFO->GetLocalTempFromDegC(
				pSensor->SensorConfig->CalPoints[tabElement].CalPoint);
		destTable[tabElement].out = pSYSTEM_INFO->GetLocalTempFromDegC(
				pSensor->SensorConfig->CalPoints[tabElement].CalPoint
						+ pSensor->SensorConfig->CalPoints[tabElement].Offset);
	}
	T_TABLE_RETURN tabResult = pSensor->calTable.GenerateTable(destTable, pSensor->SensorConfig->CalElements,
			TUS_LOOKUP_ELEMENTS, NORMAL_TABLE);
	if (tabResult != TABLE_OK) {
		// Error found, log the diagnostic error and disable the lookup table
		QString  diagMessage;
		diagMessage.asprintf(IDS_TUS_MGR_GEN_CAL_TABLE_ERROR, pSensor->Index + 1, tabResult);
		LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_ERROR, diagMessage);
		pSensor->ISCalRequired = FALSE;
	}

}

//****************************************************************************
/// Retrive a calibration adjusted recorder reading, from dual point or
//// single point calibrations
///
/// @param[in]		sensorIndex - zero based sensor number
/// @param[in]		inputReading - inpuit reading of sensor
///
/// @returns	adjusted reading of sensor from recorder cal
//****************************************************************************
float CAMS2750TUSMgr::GenerateCalAdjustedRecorderReading(USHORT sensorIndex, float inputReading) {
	float outReading = inputReading;

	// Get a handle on the IOServicesManager Singleton and use the single/dual point cal to get result
	CPPIOServiceManager *pServiceManagerObj = CPPIOServiceManager::GetHandle();

	// Get the slot and baord number from the zero based sensor number
	USHORT slotNo = 0;
	USHORT boardChanNo = 0;
	CSlotMap *pSlotMap = CSlotMap::GetHandle();
	pSlotMap->GetSlotAndChannelFromAnalSysChan(sensorIndex, &slotNo, &boardChanNo, ZERO_BASED);

	// Run the current value though the single/dual point cal for the AI
	pServiceManagerObj->GetICService()->PerformOutputAdjust(
	pSYSTEM_INFO->GetDegCTempFromLocal(inputReading), slotNo, boardChanNo, &outReading);

	outReading = pSYSTEM_INFO->GetLocalTempFromDegC(outReading);

	return outReading;
}

//****************************************************************************
/// Get sensor calibrated reading using the internal sensor index as the reference
///
/// @param[in]		internalSensorIndex - the internal zero based sensor index
/// @param[in]		inputReading - inpuit reading of sensor
///
/// @returns	adjusted reading of sensor
//****************************************************************************
float CAMS2750TUSMgr::GetCalAdjustedSensorReadingUsingInternalRef(int internalSensorIndex, float inputReading) {
	T_TUS_SENSOR_INFOMATION *ptTusSensor = &m_Sensor[internalSensorIndex];

	return GetCalAdjustedSensorReading(ptTusSensor, inputReading);
}
//****************************************************************************
/// Get sensor calibrated reading using the global zero-based analog input instance number as the reference
///
/// @param[in]		sensorIndex - zero based sensor instance
/// @param[in]		inputReading - inpuit reading of sensor
///
/// @returns	adjusted reading of sensor
//****************************************************************************
float CAMS2750TUSMgr::GetCalAdjustedSensorReadingUsingInstanceNo(int zeroBasedSensorIndex, float inputReading) {
	// get the TUS
	T_TUS_SENSOR_INFOMATION *ptTusSensor = GetTUSSensorDetailsByInstanceNo(zeroBasedSensorIndex + 1);

	return GetCalAdjustedSensorReading(ptTusSensor, inputReading);
}
//****************************************************************************
/// Retrive a calibration adjusted sensor reading, from either a single point offset
/// or a generated lookup table
///
/// @param[in]		T_TUS_SENSOR_INFOMATION *ptTusSensor - the tus sensor to use
/// @param[in]		inputReading - input reading of sensor
///
/// @returns	adjusted reading of sensor
///
//****************************************************************************
const float CAMS2750TUSMgr::GetCalAdjustedSensorReading(T_TUS_SENSOR_INFOMATION *ptTusSensor,
		const float inputReading) {
	float outReading = inputReading;

	// check a TUS sensor was found
	if (ptTusSensor != NULL) {
		// Is a calibration required for this sensor?
		if (ptTusSensor->ISCalRequired == TRUE) {
			// Yes, is it a single offset, or table lookup?
			if (ptTusSensor->ISCalSingle == TRUE) {
				// Single offset, simply add on the offset
				outReading += ptTusSensor->singleOffSet;
			} else {
				// Get adjusted reading from table lookup
				outReading = ptTusSensor->calTable.LookUpValue(inputReading);
			}
		}
	} else {
		// this is presuambly and RT or TC that hasn't been configured as a TUS sensor and thus has no TC/RT cal adjustment
	}

	return outReading;
}
//****************************************************************************
/// Reset the soak to a not start clear state
///
/// @param[in]		soakInstance - zero based soak instance in config structures
/// @param[in]		soakIndex - zero based soak instance in active soak structure
///
/// @returns	nothing
//****************************************************************************
void CAMS2750TUSMgr::ResetSoak(int soakConfigIndex, int activeSoakIndex) {
	T_PTUS_SOAK_INFORMATION pSoak = &m_Soak[activeSoakIndex];

	// first of all clear the structure so there aren't values from old tests present
	memset(pSoak->snv, 0, sizeof(T_TUSSOAKTEST));

	// enabled therefore update the information that we have available now
	pSoak->snv->Instance = activeSoakIndex + 1;
	pSoak->snv->setPoint = pSYSTEM_INFO->GetLocalTempFromDegC(m_ptFurnaces->Setpoints[soakConfigIndex].Level);
	pSoak->snv->soakStatus = SOAK_STATUS_NOTSTARTED;
	pSoak->snv->tolerance = GetSoakTolerance(soakConfigIndex);
	pSoak->snv->classMet = m_tTestConfig.FurnaceClass;

	pSoak->IsSoakToBeChecked = TRUE;	// Include this soak to beck checked
}

//****************************************************************************
/// Main TUS processing state machine
/// 
/// @return nothing
//****************************************************************************	
void CAMS2750TUSMgr::ProcessTUS() {

	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();

	if (pThreadInfo != NULL) {
		//Update the Thread Counter for the DataProcessing
		//thread after each iteration
		pThreadInfo->UpdateThreadCounter(AM_DATA_PROCESSING);
	}

	if (m_IsActive == TRUE) {
		SetDrawMaxMin();			// Set the max and min drawing Data Items

		if (m_pTUSNV->main.globalStatus == TUS_GLOBAL_RUNNING) {
			// TUS mode is active

			// Is this the first time we have entered the TUS process since configuration?
			if (m_firstIn == TRUE) {
				// Yes, preset the countdown timers and reload values
				SetUpDivideDownCounters();

				// First run configuration completed
				m_firstIn = FALSE;
			}

			if (m_processCnt-- <= 0) {
				// Process the TUS
				m_processCnt = m_processReload;	// Reload the process countdown

				T_TUS_TC_STATUS tcStatus = TUS_TC_INVALID;	// Default TC status for CheckTCs()
				int tcIndexPassBack = -1;	// Index of TC passed back from CheckTCs()
				switch (m_pTUSNV->main.tusSM) {
				case TSM_RESUME_TUS:
					// Cae for resuming a survey over a power fail, this is dropthough case
				{
					// Any post startup initialisation required as
					// Start TUS will not be run.
					QString  diagMessage;
					diagMessage.asprintf(IDS_TUS_MGR_RESUME_SOAK_AFTER_POWER_FAIL, m_pTUSNV->main.currentSoak + 1);
					LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_INFORMATION, diagMessage);

					QString  emptyStr("");
					StartTUS(emptyStr);	// Resume the TUS, no start string required

					m_NVRecoveryAttempt = FALSE;

				}
				case TSM_START_NEW_SOAK_DETECT:
					// Case to configuere a new soak ready for detection (of TC's entering) this is a drop though case
				{
#if defined (DBG_FILE_LOG_AMS_DBG_ENABLE)
  QString   strLogMessage;
  strLogMessage.asprintf(L"ProcessTUS - TSM_START_NEW_SOAK_DETECT m_pTUSNV->main.logSeqNumber = %d GTC:%d\r\n", m_pTUSNV->main.logSeqNumber, GetTickCount() );
  m_errorFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
					m_IsLastOneDiscard = FALSE;

					if (m_currlogSeqNumber > 0) {
						// Reset main.logSeqNumber =1,if it is from AUTO_STOP means Soak is completed or TUS Exported then new soak is going to start so rest to 1.
						if (FALSE == m_IsAutoStop) {
							m_pTUSNV->main.logSeqNumber = m_currlogSeqNumber;
						}
#if defined (DBG_FILE_LOG_AMS_DBG_ENABLE)
  QString   strLogMessage;
  strLogMessage.asprintf(L"ProcessTUS TSM_START_NEW_SOAK_DETECT- m_pTUSNV->main.logSeqNumber = %d GTC:%d\r\n", m_pTUSNV->main.logSeqNumber, GetTickCount() );
  m_errorFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
					}
					// Setup to point to the new soak to detect
					m_pWorkSoak = &m_Soak[m_pTUSNV->main.currentSoak];
					m_pWorkSoak->snv->soakStatus = SOAK_STATUS_SOAK_DETECT;

					// Reset all timers for new soak
					m_rampTimer.ResetAllTimers();
					m_lagTimer.ResetAllTimers();
					m_soakTimer.ResetAllTimers();
					m_stabilityTimer.ResetAllTimers();
					m_AutoStabTimer.ResetAllTimers();
					// Baseline soak timer
					m_soakTimer.StartTimer();
					m_soakTimer.StopTimer();

					// Start the ramp timer
					m_rampTimer.StartTimer();

					// restore the screen to its original zoom level
					RestoreNormalChartZoom();

					// Initialise TC's
					tcStatus = CheckTCs(tcIndexPassBack);

					setStateMachine(TSM_ALL_TCS_OUT_OF_SOAK);	// Set state machine to all out of soak
					m_IsAutoStop = FALSE; // going to reset, because if it coming from the state AUTO_STOP this flag is set as TRUE.
					// Log diagnosgtic message
					QString  diagMessage;
					diagMessage.asprintf(IDS_TUS_MGR_START_NEW_SOAK_DETECT, m_pWorkSoak->Index + 1,
							m_pWorkSoak->lowerLimit, m_pWorkSoak->upperLimit);
					LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_INFORMATION, diagMessage);
					// ** NOTE this is a fall though case **
				}
				case TSM_ALL_TCS_OUT_OF_SOAK: // Case will maintain state whilst all TC's are o outside of the soak
				{
					UpdateWorkingTimers();
					tcStatus = CheckTCs(tcIndexPassBack);

					if (tcStatus == TUS_TC_SOME_IN_SOAK) {
						// Some or all TC's have entered the soak, setup information to indicate soak has started
						m_lagTimer.StartTimer();										// Start the lag timer
						setStateMachine(TSM_TCS_ENTERED_SOAK);
						if (m_pTUSNV->main.logSeqNumber > 1) {
							if (m_pTUSNV->main.logSeqNumber == m_currlogSeqNumber) {
								m_pWorkSoak->snv->startSeqNo = m_pTUSNV->main.logSeqNumber;

							} else {
								m_pWorkSoak->snv->startSeqNo = m_pTUSNV->main.logSeqNumber - 1;	// Set the logging sequnce number for the new soak.
							}
#if defined (DBG_FILE_LOG_AMS_DBG_ENABLE)
  QString   strLogMessage;
  strLogMessage.asprintf(L"ProcessTUS m_pWorkSoak->snv->startSeqNo = %d GTC:%d\r\n", m_pWorkSoak->snv->startSeqNo, GetTickCount() );
  m_errorFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
						} else {
							m_pWorkSoak->snv->startSeqNo = 1;
						}
						m_pWorkSoak->snv->soakStatus = SOAK_STATUS_IN_SOAK;				// We are now in a soak

						// Zoom into soak on chart display
						ZoomChart();

						// Log diagnosgtic message
						QString  diagMessage;
						diagMessage.asprintf(IDS_TUS_MGR_NEW_SOAK_START, m_pWorkSoak->Index + 1,
								m_pWorkSoak->lowerLimit, m_pWorkSoak->upperLimit);
						LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_INFORMATION, diagMessage);
						// trigger any TUS Soak Started events RTVIEW-7
						pEVENTS->TUSEventTrigger(tusSOAK_STARTED);
					}
					break;
				}

				case TSM_TCS_ENTERED_SOAK:// Case will maintain state when some (but not all) TC's have entered the soak band
				{
					UpdateWorkingTimers();
					tcStatus = CheckTCs(tcIndexPassBack);

					if (tcStatus == TUS_TC_ALL_IN_SOAK) {
						// All of the TC's have entered soak
						// Stop the ramp timer, and store to NV
						m_rampTimer.StopTimer();
						m_pWorkSoak->snv->rampTime = m_rampTimer.GetTimeInMicroSec(TIMER_SINGLE);

						// Stop the lag timer, and store to NV
						m_lagTimer.StopTimer();
						m_pWorkSoak->snv->lagTime = m_lagTimer.GetTimeInMicroSec(TIMER_SINGLE);

						// Start the stability timer
						m_stabilityTimer.StartTimer();

						// Start the auto stability timer
						m_AutoStabTimer.StartTimer();

						// Set state machine and refresh chart area
						setStateMachine(TSM_ALL_TCS_IN_SOAK);
						ZoomChart();

						// Log diagnosgtic message
						QString  diagMessage;
						diagMessage.asprintf(IDS_TUS_MGR_ALL_TCS_IN_SOAK, m_pWorkSoak->Index + 1,
								(ULONG) USEC_TO_SEC(m_pWorkSoak->snv->rampTime),
								(ULONG) USEC_TO_SEC(m_pWorkSoak->snv->lagTime));
						LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_INFORMATION, diagMessage);

					} else if (tcStatus == TUS_TC_BREACHED) {
						// One of the TC's that was in soak has breached the limits
						setStateMachine(TSM_SOAK_FAILED);

						// Log diagnosgtic message
						QString  diagMessage;
						diagMessage.asprintf(IDS_TUS_MGR_BREACHED_BEFORE_SOAK, m_pWorkSoak->Index + 1,
								tcIndexPassBack + 1);
						LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_ERROR, diagMessage);
					}
					break;
				}

				case TSM_ALL_TCS_IN_SOAK:			// Case will maintain state when ALL TC's have entered the soak band
				{
					UpdateWorkingTimers();
					tcStatus = CheckTCs(tcIndexPassBack);

					if (tcStatus == TUS_TC_ALL_IN_SOAK) {
						m_StabilityEnabled = TRUE;

						// Check stability timer
						if (m_ptFurnaces->StabDetect.TimerEnable == TRUE) {
							if ( USEC_TO_SEC(
									m_stabilityTimer.RecordedTimeInMicroSeconds()) > MIN_TO_SEC(m_ptFurnaces->StabDetect.Time)) {
								// Stability timer has triggered, we can enter stability based on the timer
								m_pWorkSoak->snv->stabilityStatus = SOAK_STABILITY_TIMED;
								setStateMachine(TSM_ENTER_STABILATY);
								QString  strStabilityAchieved = "";
	strStabilityAchieved = tr("TUS - Timed Stability achieved");
								LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_INFORMATION, strStabilityAchieved);
								// trigger any TUS Stability Achieved events RTVIEW-7
								pEVENTS->TUSEventTrigger(tusSTABILITY_ACHIEVED);
#if defined (DBG_FILE_LOG_AMS_DBG_ENABLE)
  QString   strLogMessage;
  strLogMessage.asprintf(L"trigger any TUS Stability Achieved events RTVIEW-7 GTC:%d\r\n",GetTickCount() );
  m_errorFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
							}
						}
						if (m_ptFurnaces->StabDetect.AutoEnable == TRUE) {
#if defined (DBG_FILE_LOG_AMS_DBG_ENABLE)
  QString   strLogMessage;
  strLogMessage.asprintf(L"ProcessTUS - TSM_ALL_TCS_IN_SOAK m_ptFurnaces->StabDetect.AutoEnable GTC:%d\r\n", m_ptFurnaces->StabDetect.AutoEnable, GetTickCount() );
  m_errorFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
							// Run the stabiluty rate of change pipes
							float maxDeviation = UpdatePipeStability();
							// Only if the required time has passed to check stability
							LONGLONG stabTimeSoFar = USEC_TO_SEC(m_AutoStabTimer.RecordedTimeInMicroSeconds());
							if (stabTimeSoFar > m_StabilityTimeOutSeconds) {
								if (maxDeviation
										<= pSYSTEM_INFO->GetLocalTempFromDegCRelative(
												m_ptFurnaces->StabDetect.DegreeChange)) {
									// Stability timer has triggered, we can enter stability based on the timer
									m_pWorkSoak->snv->stabilityStatus = SOAK_STABILITY_AUTO;
									setStateMachine(TSM_ENTER_STABILATY);
									QString  strStabilityAchieved = "";
	strStabilityAchieved = tr("TUS - Auto Stability achieved");
									LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_INFORMATION, strStabilityAchieved);
									// trigger any TUS Stability Achieved events RTVIEW-7
									pEVENTS->TUSEventTrigger(tusSTABILITY_ACHIEVED);
								}
							}

						}
					} else if (tcStatus == TUS_TC_BREACHED) {
						setStateMachine(TSM_SOAK_FAILED);
						QString  diagMessage;
						diagMessage.asprintf(IDS_TUS_MGR_BREACHED_ALL_IN_SOAK, m_pWorkSoak->Index + 1,
								tcIndexPassBack + 1);
						LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_ERROR, diagMessage);
					} else if (tcStatus == TUS_TC_SOME_IN_SOAK) {
						// One or more TC's have fallen below level, still valid but reset any stability checks
						m_stabilityTimer.StartTimer();
						m_AutoStabTimer.StartTimer();
						m_StabilityEnabled = FALSE;
					}
					break;
				}
				case TSM_ENTER_STABILATY:// case is run when stability is enetered by timer, automatic detection or by manual intervention, dropthrough case
				{
					// Stabilty entered so baseline the max and min readings for each sensor
					for (int sensorIndex = 0; sensorIndex < m_numSensors; sensorIndex++) {
						m_Sensor[sensorIndex].SoakSensorData.maxInSoak =
								m_Sensor[sensorIndex].SoakSensorData.minInSoak = RoundTheReading(
										m_Sensor[sensorIndex].DataItem->GetFPValue());
#if defined (DBG_FILE_LOG_AMS_DBG_ENABLE)
  QString   strLogMessage;
  strLogMessage.asprintf(L"ProcessTUS - TSM_ENTER_STABILATY sensorIndex= %d m_numSensors = %d m_Sensor[sensorIndex].SoakSensorData.maxInSoak = %0.4f GTC:%d\r\n",sensorIndex,m_numSensors,m_Sensor[sensorIndex].SoakSensorData.maxInSoak,GetTickCount() );
  m_errorFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
					}
					m_pWorkSoak->snv->maxTCval = -FLT_MAX;
					m_pWorkSoak->snv->minTCval = FLT_MAX;
					m_pWorkSoak->snv->maxTCnum = m_pWorkSoak->snv->minTCnum = 0;

					// Start the soak timer
					m_soakTimer.StartTimer();
					setStateMachine(TSM_ALL_TC_IN_SOAK_AND_STABLE);
					m_pWorkSoak->snv->soakStatus = SOAK_STATUS_IN_STABILITY;
					m_pWorkSoak->snv->stabilityAchieved = pSYSTIMER->GetCurrentProcessTimeInMicroSec();
					// Refresh the page
					ZoomChart();
					/* This is a drop through case */;
				}
				case TSM_ALL_TC_IN_SOAK_AND_STABLE:	// Case maintains state when all TC are within soak and within stability
				{
					UpdateWorkingTimers();
					tcStatus = CheckTCs(tcIndexPassBack);

					if (tcStatus == TUS_TC_ALL_IN_SOAK) {
						ULONG secsToElapse = MIN_TO_SEC(m_ptFurnaces->Setpoints[m_pWorkSoak->Index].Time);
						if (m_DemoMode == TRUE) {
							secsToElapse = TUS_DEMO_SOAK_TIME;
						}
						// Check for the stability time completed
						if ( USEC_TO_SEC(m_soakTimer.ElapsedTimeInMicroSeconds()) > secsToElapse) {
							// Stability complete, but we need to wait for 1 more log point to be tracked for the completed soak
#if defined (DBG_FILE_LOG_AMS_DBG_ENABLE)
  QString   strLogMessage;
  strLogMessage.asprintf(L"ProcessTUS - Stability complete, but we need to wait for 1 more log point to be tracked for the completed soak GTC:%d\r\n",GetTickCount() );
  m_errorFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
							setStateMachine(TSM_SOAK_LASTPOINT);
							m_currlogSeqNumber = m_pTUSNV->main.logSeqNumber;
#if defined (DBG_FILE_LOG_AMS_DBG_ENABLE)
  //QString   strLogMessage;
  strLogMessage.asprintf(L"ProcessTUS - m_currlogSeqNumber = %d m_pTUSNV->main.logSeqNumber = %d GTC:%d\r\n",m_currlogSeqNumber,m_pTUSNV->main.logSeqNumber,GetTickCount() );
  m_errorFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
							m_soakTimer.StopTimer();
						}
					} else if (tcStatus == TUS_TC_BREACHED) {
						setStateMachine(TSM_SOAK_FAILED);
						m_soakTimer.StopTimer();
						QString  diagMessage;
						diagMessage.asprintf(IDS_TUS_MGR_BREACHED_ALL_IN_STABLE_SOAK, m_pWorkSoak->Index + 1,
								tcIndexPassBack + 1);
						LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_ERROR, diagMessage);
					}
					break;
				}
				case TSM_SOAK_LASTPOINT: {
					UpdateWorkingTimers();
					m_IsLastOneDiscard = TRUE;
					// Do not pass the soak until the final log reading has been put down.
					if (m_currlogSeqNumber != m_pTUSNV->main.logSeqNumber) {
						setStateMachine(TSM_SOAK_PASSED);
					}
					break;
				}
				case TSM_SOAK_FAILED:			// Case run when a soak fails due to TC breaching the tolerance
				{
					QString  diagMessage;
					diagMessage.asprintf(IDS_TUS_MGR_SOAK_FAILED, m_pWorkSoak->Index + 1);
					LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_ERROR, diagMessage);
#if defined (DBG_FILE_LOG_AMS_DBG_ENABLE)
  QString   strLogMessage;
  strLogMessage.asprintf(L"ProcessTUS in TSM_SOAK_FAILED- GTC:%d\r\n",GetTickCount() );
  m_errorFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
					// fail the test.
					m_pWorkSoak->snv->soakStatus = SOAK_STATUS_FAILED;
					CompleteSoak();
					break;
				}
				case TSM_SOAK_PASSED:			// Case run when a soak passes
				{
					QString  diagMessage;
					diagMessage.asprintf(IDS_TUS_MGR_SOAK_COMPLETED_OK, m_pWorkSoak->Index + 1);
					LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_INFORMATION, diagMessage);

					// Close off soak and move to next soak.
					m_pWorkSoak->snv->soakStatus = SOAK_STATUS_PASSED;

					CompleteSoak();

					break;
				}
				case TSM_SOAK_EXIT:	// Case will maintain state while TC's remain in a completed soak (passed or failed)
				{
					m_IsLastOneDiscard = TRUE;
					UpdateWorkingTimers();
#if defined (DBG_FILE_LOG_AMS_DBG_ENABLE)
  QString   strLogMessage;
  strLogMessage.asprintf(L"ProcessTUS :: TSM_SOAK_EXIT- tcIndexPassBack = %d GTC:%d\r\n",tcIndexPassBack,GetTickCount() );
  m_errorFileLogger.WriteToDebugLogFile(strLogMessage);
#endif

					// Check TC's to see if they remain within the current tolerance of the completed soak
					if (CheckTCs(tcIndexPassBack) == TUS_TC_NONE_IN_SOAK) {
						// TC's have exited completing soak tolerance, we can start the new soak.
#if defined (DBG_FILE_LOG_AMS_DBG_ENABLE)
  QString   strLogMessage;
  strLogMessage.asprintf(L"ProcessTUS :: TSM_SOAK_EXIT- TC's have exited completing soak tolerance, we can start the new soak tcIndexPassBack = %d GTC:%d\r\n",tcIndexPassBack,GetTickCount() );
  m_errorFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
						setStateMachine(TSM_START_NEW_SOAK_DETECT);
					}
					break;
				}
				case TSM_AUTO_STOP:			// Case will wait a time period on a failed TUS before stopping TUS
				{
					if (m_lastSoakFailed == TRUE) {
#if defined (DBG_FILE_LOG_AMS_DBG_ENABLE)
  QString   strLogMessage;
  strLogMessage.asprintf(L"ProcessTUS :: TSM_AUTO_STOP- lastSoakFailed GTC:%d\r\n",GetTickCount() );
  m_errorFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
						// Check for timeout to expire
						if ( USEC_TO_SEC(
								m_AutoStopTimer.RecordedTimeInMicroSeconds()) > MIN_TO_SEC( TUS_AUTOSTOP_DELAY_ON_FAIL_MIN )) {
							// Timeout has expired, so stop the TUS survey even though soak failed but enough time for user restart allowed
							m_lastSoakFailed = FALSE;
						}
					} else {
#if defined (DBG_FILE_LOG_AMS_DBG_ENABLE)
  QString   strLogMessage;
  strLogMessage.asprintf(L"ProcessTUS :: TSM_AUTO_STOP- Stop the TUS survey GTC:%d\r\n",GetTickCount() );
  m_errorFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
						// Stop the TUS survey
						QString  strEndReason;
						strEndReason.asprintf(L"All soaks have been completed the survey was stopped automatically");
						StopTUS(strEndReason);
					}
					m_IsAutoStop = TRUE; // It will help to reset main.logSeqNumber = 1 in TSM_START_NEW_SOAK_DETECT state after export 1st tus file.
					break;
				}

				}	// End of TUS state machine

				// Log the data readings
				if (m_readingCnt-- <= 0) {
					// Process a new reading
					m_readingCnt = m_readingReload;		// Reload the reading countdown
#if defined (DBG_FILE_LOG_AMS_DBG_ENABLE)
  QString   strLogMessage;
  strLogMessage.asprintf(L"End of TUS state machine -m_IsLastOneDiscard = %d m_currlogSeqNumber = %d m_pTUSNV->main.logSeqNumber = %d m_readingCnt = %ld GTC:%d\r\n",m_IsLastOneDiscard,m_currlogSeqNumber,m_pTUSNV->main.logSeqNumber ,m_readingCnt, GetTickCount());
  m_errorFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
					if (m_pTUSNV->main.logSeqNumber <= NUM_TOTAL_LOGS) {
						// Add a new log record
						if (TRUE != m_IsLastOneDiscard) {
#if defined (DBG_FILE_LOG_AMS_DBG_ENABLE)
  QString   strLogMessage;
  strLogMessage.asprintf(L"Calling AddLogLine GTC:%d\r\n",GetTickCount() );
  m_errorFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
							AddLogLine();
						}

						// Advance sequence Number and test for full log record (72 hour run)
						if (++m_pTUSNV->main.logSeqNumber > NUM_TOTAL_LOGS) {
							// Log records full, meaning the TUS has been running for over 72 hours, force abort on survey.
							QString  strEndReason;
							strEndReason.asprintf(L"TUS - Runtime exceeded 72 hours, stopped");
							StopTUS(strEndReason, TUS_FAIL_TIMEDOUT);
						}
					}
				}
				SetUpdateRequired(TRUE);
			}
		}
	}
}

//****************************************************************************
/// Zoom the chart object into the soak being processed
///
/// @returns	nothing
//****************************************************************************
void CAMS2750TUSMgr::ZoomChart() {
	m_gridLineLower = m_pWorkSoak->lowerLimit;
	m_gridLineUpper = m_pWorkSoak->upperLimit;
	m_soakLevel = m_pWorkSoak->snv->setPoint;
	// Message to chart for zoom
	float soakMargin = floor(m_pWorkSoak->snv->tolerance / 2);		// Margin is half the tolerance, rounded
	AfxGetApp()->GetMainWnd()->PostMessage(WM_OPPANEL_ZOOM_IN_VIEW_TUS_SCRN,
			(WPARAM)(m_pWorkSoak->lowerLimit - soakMargin), (LPARAM)(m_pWorkSoak->upperLimit + soakMargin));
}

//****************************************************************************
/// Closedown the current soak and save to report file
///
/// @returns	nothing
//****************************************************************************
void CAMS2750TUSMgr::CloseCurrentSoak() {
	UpdateWorkingTimers();
	// Close off the current soak
#if defined (DBG_FILE_LOG_AMS_DBG_ENABLE)
  QString   strLogMessage;
  strLogMessage.asprintf(L"CloseCurrentSoak - m_pTUSNV->main.logSeqNumber=%d GTC:%d\r\n",m_pTUSNV->main.logSeqNumber,GetTickCount() );
  m_errorFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
	if (m_pTUSNV->main.logSeqNumber > 1) {
		if (TRUE == m_IsLastOneDiscard) {
			m_pWorkSoak->snv->endSeqNo = m_pTUSNV->main.logSeqNumber - 2;
		} else {
			m_pWorkSoak->snv->endSeqNo = m_pTUSNV->main.logSeqNumber - 1;// Logging sequnce number at end of soak (provides coverage)
		}
#if defined (DBG_FILE_LOG_AMS_DBG_ENABLE)
  QString   strLogMessage;
  strLogMessage.asprintf(L"CloseCurrentSoak - m_pWorkSoak->snv->endSeqNo = %d GTC:%d\r\n",m_pWorkSoak->snv->endSeqNo,GetTickCount() );
  m_errorFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
	} else {
		m_pWorkSoak->snv->endSeqNo = 1;
	}

	// Get largest deviation in overshoot
	float maxDevOverSoak = fabs(m_pWorkSoak->snv->maxOvershootVal);
	// Check is deviation from setpoint was greater during stability
	if (maxDevOverSoak < m_pWorkSoak->snv->maxTempDiffTCtoSetP) {
		maxDevOverSoak = m_pWorkSoak->snv->maxTempDiffTCtoSetP; // Yes set as largest deviation
	}
	m_pWorkSoak->snv->classMet = GetBestClassForDeviation(maxDevOverSoak);

	memset(&m_pTUSNV->prevSoak, 0, sizeof(T_TUSSOAKDATA));

	// Setup the TC and Recorder accuracies (sensor offsets at set point)
	for (int sensorIndex = 0; sensorIndex < m_numSensors; sensorIndex++) {
		// Get difference between setpoint and sensor calibration at setpoint
		m_Sensor[sensorIndex].SoakSensorData.tcAccuracy = GetCalAdjustedSensorReadingUsingInternalRef(sensorIndex,
				m_pWorkSoak->snv->setPoint) - m_pWorkSoak->snv->setPoint;
		// Get difference between setpoint and Analogue input adjustment (dual or single point cal) at setpoint
		m_Sensor[sensorIndex].SoakSensorData.recAccuracy = GenerateCalAdjustedRecorderReading(sensorIndex,
				m_pWorkSoak->snv->setPoint) - m_pWorkSoak->snv->setPoint;
#if defined (DBG_FILE_LOG_AMS_DBG_ENABLE)
  QString   strLogMessage;
  strLogMessage.asprintf(L"CloseCurrentSoak sensorIndex = %d tcAccuracy = %0.4f recAccuracy = %0.4f - GTC:%d\r\n",sensorIndex,m_Sensor[sensorIndex].SoakSensorData.tcAccuracy,m_Sensor[sensorIndex].SoakSensorData.recAccuracy,GetTickCount() );
  m_errorFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
		// Ad readings into T_TUSSOAKDATA structure
		memcpy(&m_pTUSNV->prevSoak.tcData[m_Sensor[sensorIndex].Index], &m_Sensor[sensorIndex].SoakSensorData,
				sizeof(T_TCDATAFORSOAK));
	}

	// complete T_TUSSOAKDATA structure copy in NV from to T_TUSSOAKTEST structure in NV
	memcpy(&m_pTUSNV->prevSoak.test, m_pWorkSoak->snv, sizeof(T_TUSSOAKTEST));

	m_ModuleMsgMgrClient.MMMClientPostIntMsg( INFINITE, MODULE_TUS_FILE_BUILDER, // Destination
			MODULE_TUS_MGR, // Sender
			MOD_TUS_ADD_SOAK, sizeof(T_TUSSOAKDATA), reinterpret_cast<BYTE*>(&m_pTUSNV->prevSoak));

}

//****************************************************************************
/// Current soak has completed, move to next soak
///
/// @returns	nothing
//****************************************************************************
void CAMS2750TUSMgr::CompleteSoak() {
	// Closedown the current soak
	CloseCurrentSoak();

	// trigger any TUS Soak Complete events RTVIEW-7
	pEVENTS->TUSEventTrigger(tusSOAK_COMPLETE);

	// Set the failure status of the last soak
	if (m_pWorkSoak->snv->soakStatus == SOAK_STATUS_FAILED) {
		m_lastSoakFailed = TRUE;		// Failed
	} else {
		m_lastSoakFailed = FALSE;		// Passed
	}

	// Move to next soak.
	m_pTUSNV->main.currentSoak++;
	//m_IsLastOneDiscard = FALSE;

#if defined (DBG_FILE_LOG_AMS_DBG_ENABLE)
  QString   strLogMessage;
  strLogMessage.asprintf(L"CompleteSoak - m_IsLastOneDiscard = %d m_pTUSNV->main.currentSoak = %d m_numSoaks = %d GTC:%d\r\n",m_IsLastOneDiscard,m_pTUSNV->main.currentSoak,m_numSoaks,GetTickCount() );
  m_errorFileLogger.WriteToDebugLogFile(strLogMessage);
#endif

	if (m_pTUSNV->main.currentSoak >= m_numSoaks) {
		// We have reached the end of all soaks
		m_AutoStopTimer.ResetAllTimers();
		m_AutoStopTimer.StartTimer();
		setStateMachine(TSM_AUTO_STOP);
#if defined (DBG_FILE_LOG_AMS_DBG_ENABLE)
  QString   strLogMessage;
  strLogMessage.asprintf(L"CompleteSoak - Going to AUTO_STOP m_pWorkSoak->snv->endSeqNo = %d GTC:%d\r\n",m_pWorkSoak->snv->endSeqNo, GetTickCount() );
  m_errorFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
	} else {
		// There is another soak to go, idle until TC's have left current soak
		setStateMachine(TSM_SOAK_EXIT);
#if defined (DBG_FILE_LOG_AMS_DBG_ENABLE)
  QString   strLogMessage;
  strLogMessage.asprintf(L"CompleteSoak - Going to TSM_SOAK_EXIT m_pWorkSoak->snv->endSeqNo = %d GTC:%d\r\n",m_pWorkSoak->snv->endSeqNo,GetTickCount() );
  m_errorFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
	}
}

//****************************************************************************
/// Setup the divide down timers that allow us to run process TUS at
/// once per second and the logging each 2 minutes, also aligns the timers
/// to top of second and minute boundarys
///
/// @returns	nothing
//****************************************************************************
void CAMS2750TUSMgr::SetUpDivideDownCounters() {
	// Calculate the remainder of the second to process, and align the process counter with the start of the next second
	LONGLONG currTime = pSYSTIMER->GetCurrentProcessTimeInMicroSec();		// Get the current process time in mSec
	LONGLONG divTime = SEC_TO_USEC(1);
	LONGLONG procTime = divTime / pSYSTIMER->GetProcessSlicesPerSecond();	// time in millesecond per process slice
	LONGLONG timeleft = divTime - (currTime % divTime);			// timeleft contains the uSec left in the current Second
	m_processCnt = (timeleft / procTime) + 1;// Number of slice till end of second , rounded down so we need first in new second so add 1
	m_processReload = pSYSTIMER->GetProcessSlicesPerSecond() - 1;		// Reload, number of process slices per second.

	// Calculate the countdown for taking a reading to align to the top of the next even 2 minute period
	divTime = SEC_TO_USEC(TUS_SECONDS_PER_READING);
	timeleft = divTime - (currTime % divTime);				// Remaind of time in uSec until the next 2 minute period
	m_readingCnt = (timeleft / SEC_TO_USEC(1));				// Number of seconds remaining till the next 2 minute time
	m_readingReload = TUS_SECONDS_PER_READING - 1;							// Reload time of 1 second for each

}

//****************************************************************************
/// Build the sensor name from the index for display on the TUS screen
///
/// @param[in]		tcNumber - 1 based TC/RT number to build name for
/// @param[in]		isTC - flag indicating if the sensor is a TC (true) or an RT (false)
///
/// @returns	string in format "Sensor n" where n is the TC/RT number passed
//****************************************************************************
const QString  CAMS2750TUSMgr::buildSensorName(USHORT tcNumber, bool isTC) {
	QString  sensorStr;

	if (isTC) {
		sensorStr.asprintf(L"TC%d", tcNumber);		// Build TC number, all report side TC/RT references are 1 based
	} else {
		sensorStr.asprintf(L"RT%d", tcNumber);		// Build RT number, all report side TC/RT references are 1 based
	}
	return sensorStr;
}

//****************************************************************************
/// Update the timers so they can be displayed on the TUS screen
///
/// @returns	nothing
//****************************************************************************
void CAMS2750TUSMgr::UpdateWorkingTimers() {
	// Store the latest timers
	m_pWorkSoak->snv->rampTime = m_rampTimer.RecordedTimeInMicroSeconds();
	m_pWorkSoak->snv->lagTime = m_lagTimer.RecordedTimeInMicroSeconds();
	m_pWorkSoak->snv->soakTime = m_soakTimer.RecordedTimeInMicroSeconds();
	SetElapsedTimer();
}

//****************************************************************************
/// Adds a set of logged readings at the defined interval of 2 minutes, this
/// will then pass the completed record to the data writer for the TUS report file
///
/// @returns	nothing
//****************************************************************************
void CAMS2750TUSMgr::AddLogLine() {
	T_PTUSDATAREADING pLine = NULL;

	// Check if the reading buffer has rolled
	if (m_pTUSNV->main.logLineNumber >= TUS_NVLOG_STORE) {
		m_pTUSNV->main.logLineNumber = 0;
#if defined (DBG_FILE_LOG_AMS_DBG_ENABLE)
  QString   strLogMessage;
  strLogMessage.asprintf(L"AddLogLine in If - m_pTUSNV->main.logLineNumber = %d GTC:%d\r\n",m_pTUSNV->main.logLineNumber,GetTickCount() );
  m_errorFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
	}
	// Pointer to the reading line to populate
	pLine = &m_pTUSNV->line[m_pTUSNV->main.logLineNumber++];
#if defined (DBG_FILE_LOG_AMS_DBG_ENABLE)
  QString   strLogMessage;
  strLogMessage.asprintf(L"AddLogLine - m_pTUSNV->main.logLineNumber = %d GTC:%d\r\n",m_pTUSNV->main.logLineNumber,GetTickCount() );
  m_errorFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
	// Set status to log record being built, if power fail during build we can pick up an incomplete record.
	pLine->status = LOG_STATUS_INVALID;

	// Set all TC's to rogue value
	for (int tcEntry = 0; tcEntry < NUM_TCS_PER_SOAK; tcEntry++) {
		pLine->TCReading[tcEntry] = TUS_READING_ROGUE;
	}

	// Set information and readings for the line
	pLine->logTimeStamp = pSYSTIMER->GetCurrentProcessTimeInMicroSec();			// Set the current process Time
	pLine->sequenceNumber = m_pTUSNV->main.logSeqNumber;						// Assign the sequence number
#if defined (DBG_FILE_LOG_AMS_DBG_ENABLE)
  //QString   strLogMessage;
  strLogMessage.asprintf(L"AddLogLine - pLine->logTimeStamp = %lld pLine->sequenceNumber = %d GTC:%d\r\n",pLine->logTimeStamp,pLine->sequenceNumber,GetTickCount() );
  m_errorFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
	// Add in all readings
	for (int sensorIndex = 0; sensorIndex < m_numSensors; sensorIndex++) {
		pLine->TCReading[m_Sensor[sensorIndex].Index] =
				GetValidatedReading(&m_Sensor[sensorIndex]);	// Assign current value
#if defined (DBG_FILE_LOG_AMS_DBG_ENABLE)
  QString   strLogMessage;
  strLogMessage.asprintf(L"AddLogLine - pLine->TCReading[m_Sensor[%d].Index] = %0.4f GTC:%d\r\n",sensorIndex,pLine->TCReading[m_Sensor[sensorIndex].Index],GetTickCount() );
  m_errorFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
	}

	// Update status at end, so we know a record with this status is completed in NV over power fail
	if (m_registerPowerFail == TRUE) {
		// Resume after a restart, indicate this in 1st line to be logged after resume
		pLine->status = LOG_STATUS_RESTART;
		m_registerPowerFail = FALSE;
	} else {
		pLine->status = LOG_STATUS_NORMAL;
	}

	// Post log block to file write
	m_ModuleMsgMgrClient.MMMClientPostIntMsg( INFINITE, MODULE_TUS_FILE_BUILDER,				// Destination
			MODULE_TUS_MGR,							// Sender
			MOD_TUS_ADD_LOG_DATA, sizeof(T_TUSDATAREADING), reinterpret_cast<BYTE*>(pLine));
}

//****************************************************************************
/// Get the reading from the sensor but cap to reasonable limits
///
/// @param[in]		sensorToTest - pointer to the T_PTUS_SENSOR_INFOMATION for sensor to test
///
/// @returns	validated reading
//****************************************************************************
float CAMS2750TUSMgr::GetValidatedReading(T_PTUS_SENSOR_INFOMATION sensorToTest) {
	float valReading = RoundTheReading(sensorToTest->DataItem->GetFPValue());

	if (valReading > TUS_READING_ROGUE) {
		valReading = TUS_READING_ROGUE;			// Sensor reading is above limit, so cap
	} else if (valReading < -TUS_READING_ROGUE) {
		valReading = -TUS_READING_ROGUE;		// Sensor reading is below limit, so cap
	}
	return valReading;
}
//****************************************************************************
/// Method to round the input float value (if necessary)
///
/// @param[in]		num - the unrounded value
///
/// @returns	the rounded reading, as per the required standard
//****************************************************************************

//
float CAMS2750TUSMgr::RoundTheReading(float num) {
	const bool useASTM39Rounding = false;

	if (useASTM39Rounding) {
		// The below is a method to round the input float value as per the ASTM - 39 standard.
		// This rounding is no longer required for AMS2750F so it has been removed
		// WARNING: IF RE-ENABLING THIS CODE THEN THERE IS A BUG WITH THE ROUNDING FOR NEGATIVE
		// NUMBERS THAT MUST BE FIXED FIRST. THE ROUNDING VALUE APPEARS TO BE GETTING ADDED RATHER
		// THAN MINUSED SO YOU END UP WITH UNEXPECTED VALUES BEING PRODUCED
		//num = 1000.45012;
		QString  strValue;
		strValue.asprintf(_T("%.4f"), num);

		QString  strFraction;
		QString  strDecimal;
		strFraction = strValue.right(strValue.length() - 1 - strValue.indexOf(_T('.')));
		strDecimal = strValue.left(strValue.indexOf(_T('.')));
		int iSecondDigit = 0;
		int iFirstDigit = 0;

		//Get the fraction part
		int iFractionPart = _tstoi(strFraction.GetString());  //iInputValue % 100;

		//Get the decimal part of the input number
		int iDecimalPart = _tstoi(strDecimal.GetString());  //iInputValue / 100;

		//Get the second digit of the fraction part.
		if (strFraction.length() > 1) {
			iSecondDigit = _tstoi((QString  ) strFraction.at(1));  //iFractionPart % 10;
		}

		//Get the first digit of the fraction part.
		if (strFraction.length() > 0) {
			iFirstDigit = _tstoi((QString  ) strFraction.at(0));  //iFractionPart / 10;
		}

		float fResult = 0;
		float fTemp = 0;
		/*When the figure next beyond the last place to be retained is greater than 5,increase by 1 the figure in the last place retained.*/
		/* Example 45.76 = 45.8*/
		if (iSecondDigit > 5) {
			// If the first digit of the fraction part less than 9 then increase it by 1.
			/* Example 45.76 = 45.8*/
			if (iFirstDigit < 9) {
				iFirstDigit = iFirstDigit + 1;
				fTemp = (float) (iFirstDigit * 0.1);
			}
			/* Example 45.79 = 45.8*/
			else {
				// If the first digit of the fraction part is greater than 9 then increase the decimal part by 1
				iDecimalPart = iDecimalPart + 1;
				fTemp = 0;
			}
			fResult = iDecimalPart + fTemp;
		}
		/*When the figure next beyond the last place to be retained is less than 5,retain unchanged the figure in the last place retained.*/
		/* Example 45.71 = 45.7*/
		else if (iSecondDigit < 5) {

			fTemp = (float) (iFirstDigit * 0.1);

			fResult = iDecimalPart + fTemp;
		} else {
			/*When the next figure beyond the last place to be retained is 5 and there are no figures beyond this 5, or only zeros, increase the figure to be retained by 1 if it is odd.*/

			int irightValue = _tstoi(strFraction.GetString());
			bool bNonZero = false;
			if (strFraction.length() == 3) {
				if (strFraction.at(2) > 48) {
					bNonZero = true;
				}
			} else if (strFraction.length() == 4) {
				if (strFraction.at(2) > 48 || strFraction.at(3) > 48) {
					bNonZero = true;
				}
			} else if (strFraction.length() >= 5) {
				if (strFraction.at(2) > 48 || strFraction.at(3) > 48 || strFraction.at(4) > 48) {
					bNonZero = true;
				}
			}
			/*Increase the figure by 1 in the last place retained, if there are figures beyond this 5.*/
			/* Example 45.45105 = 45.5 */
			if (bNonZero) {
				if (iFirstDigit < 9) {
					iFirstDigit = iFirstDigit + 1;
					fTemp = (float) (iFirstDigit * 0.1);
				} else {
					iDecimalPart = iDecimalPart + 1;
					fTemp = 0;
				}

				fResult = iDecimalPart + fTemp;
			} else {
				/*Leave the figure unchanged if it is even*/
				/* Example 45.4500 = 45.4 */
				if (iFirstDigit % 2 == 0) {
					fTemp = (float) (iFirstDigit * 0.1);
					fResult = iDecimalPart + fTemp;
				} else {

					/* Example 45.7500 = 45.8 */
					if (iFirstDigit < 9) {
						iFirstDigit = iFirstDigit + 1;
						fTemp = (float) (iFirstDigit * 0.1);
					} else {
						iDecimalPart = iDecimalPart + 1;
						fTemp = 0;
					}
					fResult = iDecimalPart + fTemp;
				}
			}

		}
		return fResult;
	} else {
		// return the value as it is with no further rounding
		return num;
	}
}

//****************************************************************************
/// Check TC to see if it is within the required soak level, this will return
/// a reversed response if the signal fall into the soak rather then the normal rise into the soak.
///
/// @param[in]		sensorToTest - pointer to the T_PTUS_SENSOR_INFOMATION for sensor to test
/// @param[out]		theReading - the reading taken from the TC
///
/// @returns	T_TUS_THIS_TC_STATUS indicating if in soak or above or below
//****************************************************************************
T_TUS_THIS_TC_STATUS CAMS2750TUSMgr::IsInSoakLevel(T_PTUS_SENSOR_INFOMATION sensorToTest, float &theReading) {
	T_TUS_THIS_TC_STATUS retVal = TUS_THIS_TC_IN_SOAK;

	// Setup the level responses based on a normal upwardly going TUS
	T_TUS_THIS_TC_STATUS underRet = TUS_THIS_TC_UNDER;
	T_TUS_THIS_TC_STATUS overRet = TUS_THIS_TC_OVER;

	// If the signals are reversed and fall into the soak, reverse the response
	if (m_Direction == TUS_DIRECTION_DOWN) {
		underRet = TUS_THIS_TC_OVER;
		overRet = TUS_THIS_TC_UNDER;
	}

	// Test for the current reading to be within the limits of the specified soak
	theReading = GetValidatedReading(sensorToTest);

	if (theReading < m_pWorkSoak->lowerLimit) {
		// The TC is under the soak limit
		retVal = underRet;
	}
	if (theReading > m_pWorkSoak->upperLimit) {
		// The TC is over the soak limit
		retVal = overRet;
	}
	return retVal;
}

//****************************************************************************
/// Updates the data items used to draw the chart and DPM's onright of chart
/// Simply gets the max and min signal for the process slice, and sets the
/// max and min TC data items, also providing which TC's were max and min
/// as well as the differnece between the maxc and min
///
/// @returns	nothing
//****************************************************************************
void CAMS2750TUSMgr::SetDrawMaxMin() {
	int maxSensor = 0;
	int minSensor = 0;
	float sensorReading = 0;
	float maxThisPass = -TUS_READING_ROGUE;
	float minThisPass = TUS_READING_ROGUE;
	bool maxIsTC = false;
	bool minIsTC = false;

	// Run though all remaining sensors to find the max an min for this time slice
	for (int sensorIndex = 0; sensorIndex < m_numSensors; sensorIndex++) {
		if (m_Sensor[sensorIndex].IsUserEnabled == FALSE) {
			continue; // This sensor has been removed from the test, do not check it, move to next sensor
		}
		sensorReading = GetValidatedReading(&m_Sensor[sensorIndex]);
		if (sensorReading > maxThisPass) {
			// New max TC/RT and level
			maxSensor = m_Sensor[sensorIndex].Index + 1;
			maxThisPass = sensorReading;			// New Max
			maxIsTC = m_Sensor[sensorIndex].AnalogueConfig->Type == AI_CHANNEL_TYPE_TC;
		}
		if (sensorReading < minThisPass) {
			// New min TC/RT and level
			minSensor = m_Sensor[sensorIndex].Index + 1;
			minThisPass = sensorReading;			// New Min
			minIsTC = m_Sensor[sensorIndex].AnalogueConfig->Type == AI_CHANNEL_TYPE_TC;
		}
	}
	QString   strSensorName;
	buildSensorName(maxSensor, maxIsTC).toWCharArray(strSensorName);
	// Set the data items with the new max and min and their respective TC's
	m_MaxRunSensor->SetValue(maxThisPass);
	m_MaxRunSensor->SetGeneralDetails(0, 65535, strSensorName, L"");
	m_MinRunSensor->SetValue(minThisPass);
	buildSensorName(minSensor, minIsTC).toWCharArray(strSensorName);
	m_MinRunSensor->SetGeneralDetails(0, 65535, strSensorName, L"");
	// Set the diff between max and min
	m_diffTC->SetValue(maxThisPass - minThisPass);
}

//****************************************************************************
/// Update the automatic stability check, uses a rate of change pipe to
/// maintain the total rate of change over the auto stability check period
/// and returns the max deviation recorded for this cycle
///
/// @returns	max deviation found of all TC's over the specified time period
//****************************************************************************
float CAMS2750TUSMgr::UpdatePipeStability() {
	float maxRateDiff = 0;
	float thisRateDiff = 0;
	// Run though all remaining sensors to find the max an min for this time slice
	for (int sensorIndex = 0; sensorIndex < m_numSensors; sensorIndex++) {
		// Get the absolute rate of change for the previous period
		thisRateDiff = fabs(
				m_Sensor[sensorIndex].stabilityPipe.AddReadingForRateOfChange(
						m_Sensor[sensorIndex].DataItem->GetFPValue()));
		// Track the maximum rate difference over the rolling period
		if (thisRateDiff > maxRateDiff) {
			maxRateDiff = thisRateDiff;
		}
	}
	return maxRateDiff;
}

//****************************************************************************
/// indexOfs the max overshoot value for each TC and keeps a running MAX for the TC with the largest overshoot
/// based on m_Direction for bi-directional entry to soak.
///
/// @param[in]		sensorToTest - pointer to the T_PTUS_SENSOR_INFOMATION for sensor to test
///
/// @returns	nothing
//****************************************************************************
void CAMS2750TUSMgr::TestOverShoot(T_PTUS_SENSOR_INFOMATION sensorToTest) {
	float sensorReading = GetValidatedReading(sensorToTest);
	sensorReading = sensorReading - m_pWorkSoak->snv->setPoint;
	// Determine direction of soak
	if (m_Direction == TUS_DIRECTION_UP) {
		if (sensorReading >= sensorToTest->SoakSensorData.shootValue) {
			// Overshoot increased, record the new value
			sensorToTest->SoakSensorData.shootValue = sensorReading;
			// Check if this is the max overshoot we have seen so far
			if (sensorReading > m_pWorkSoak->snv->maxOvershootVal) {
				// Yes, it is so record level and which TC is max
				m_pWorkSoak->snv->maxOvershootVal = sensorReading;
				m_pWorkSoak->snv->overShootTCNum = sensorToTest->Index + 1;
			}
		}
	} else {
		// TC's are falling into a soak, so reverse the overshoot logic
		if (sensorReading <= sensorToTest->SoakSensorData.shootValue) {
			// Overshoot decreased, record the new value
			sensorToTest->SoakSensorData.shootValue = sensorReading;
			// Check if this is the max overshoot we have seen so far
			if (sensorReading < m_pWorkSoak->snv->maxOvershootVal) {
				// Yes, it is so record level and which TC is max
				m_pWorkSoak->snv->maxOvershootVal = sensorReading;
				m_pWorkSoak->snv->overShootTCNum = sensorToTest->Index + 1;
			}
		}
	}
}

//****************************************************************************
/// Check the sensor reading with the current max and min of the stability period
/// if this TC has the max or min reading so far, update the relevant holders
/// with the values and identity of the TC, if max or min has changed
/// update the diff between TC's and the diff between TC's and set point
///
/// @param[in]	index - The zero based index of TC to check
///
/// @returns	TRUE if max or min changed, otherwise FALSE
//****************************************************************************
BOOL CAMS2750TUSMgr::UpdateStabilityMaxMinDiff(int index) {
	BOOL mmUpdated = FALSE;
	float reading = GetValidatedReading(&m_Sensor[index]);
	// Update the overall Max and Min values
	if (reading >= m_pWorkSoak->snv->maxTCval) {
		m_pWorkSoak->snv->maxTCval = reading;
		m_pWorkSoak->snv->maxTCnum = m_Sensor[index].Index + 1;
		mmUpdated = TRUE;
	}
	if (reading <= m_pWorkSoak->snv->minTCval) {
		m_pWorkSoak->snv->minTCval = reading;
		m_pWorkSoak->snv->minTCnum = m_Sensor[index].Index + 1;
		mmUpdated = TRUE;
	}

	if (mmUpdated == TRUE) {
		// Calculate the biggest difference between max and min
		m_pWorkSoak->snv->maxTempDiffAcrossTCs = m_pWorkSoak->snv->maxTCval - m_pWorkSoak->snv->minTCval;
		// Calculate the largest different in deviation from the setpoint, this could be max or min
		// but will be shown in +ve units
		float maxDiffFromSetPoint = fabs(m_pWorkSoak->snv->setPoint - m_pWorkSoak->snv->maxTCval);	// Get diff for max
		float minDiffFromSetPoint = fabs(m_pWorkSoak->snv->setPoint - m_pWorkSoak->snv->minTCval);	// Get diff for min
		// If max differs more then min , use the max, otherwise use then min
		if (maxDiffFromSetPoint > minDiffFromSetPoint) {
			// Max is bigger, check it's bigger then current max deviation
			if (maxDiffFromSetPoint >= m_pWorkSoak->snv->maxTempDiffTCtoSetP) {
				m_pWorkSoak->snv->maxTempDiffTCtoSetP = maxDiffFromSetPoint;// Max is greater deviation from setpoint set value
				m_pWorkSoak->snv->maxTempDiffTCtoSetPNum = m_pWorkSoak->snv->maxTCnum;// and set corrisponding TC number
			}
		} else {
			// Min value is bigger deviation from setpoint, check it's bigger then current max deviation
			if (minDiffFromSetPoint >= m_pWorkSoak->snv->maxTempDiffTCtoSetP) {
				m_pWorkSoak->snv->maxTempDiffTCtoSetP = minDiffFromSetPoint;// min is greater deviation from setpoint set value
				m_pWorkSoak->snv->maxTempDiffTCtoSetPNum = m_pWorkSoak->snv->minTCnum; // and set corrisponding TC number
			}
		}
	}
	return mmUpdated;
}

//****************************************************************************
/// Get the default shoot value depending on direction, usually it's an overshoot
/// but on a -ve going soak it's an undershoot
///
/// @returns	default shoot level
//****************************************************************************
float CAMS2750TUSMgr::GetDefaultShootValue() {
	float retVal = -TUS_READING_ROGUE;
	if (m_Direction == TUS_DIRECTION_DOWN) {
		retVal = TUS_READING_ROGUE;		// Set overshoot to higher max value
	}
	return retVal;
}

//****************************************************************************
/// Check TC, will check the TC levels and determine the outcome based
/// on the current state of the state machine, this is the driving
/// method behind process TUS
///
/// @param[out]		USHORT &tcIndexPassBack - The zero based index of TC that caused issue, case dependent
///
/// @returns	T_TUS_TC_STATUS in relation to current state machine stage of T_TUS_STATE_MACHINE_STAGE
//****************************************************************************
T_TUS_TC_STATUS CAMS2750TUSMgr::CheckTCs(int &tcIndexPassBack) {
	T_TUS_TC_STATUS retVal = TUS_TC_INVALID;
	float sensorReading = TUS_READING_ROGUE;
	T_TUS_THIS_TC_STATUS sensorStatus;
	switch (m_pTUSNV->main.tusSM) {
	case TSM_START_NEW_SOAK_DETECT: {
		// Detect the direction of the soak, if TC's are above soak level is a downgoing direction
		// and logic will be reversed, otherwise it's an upgoing direction and logic will be normal
		m_Direction = TUS_DIRECTION_UP;
		m_pWorkSoak->snv->maxOvershootVal = GetDefaultShootValue();
		for (int sensorIndex = 0; sensorIndex < m_numSensors; sensorIndex++) {
			T_PTUS_SENSOR_INFOMATION testSensor = &m_Sensor[sensorIndex];		// Get a convenient test handle
			testSensor->stabilityPipe.ResetPipe();								// Reset the Auto Stability detect pipe
			memset(&testSensor->SoakSensorData, 0, sizeof(T_TCDATAFORSOAK));	// Reset Sensor data
			sensorStatus = IsInSoakLevel(testSensor, sensorReading);
#if defined (DBG_FILE_LOG_AMS_DBG_ENABLE)
  QString   strLogMessage;
  strLogMessage.asprintf(L" CheckTCs : TSM_START_NEW_SOAK_DETECT sensorIndex = %d sensorStatus = %d GTC:%d\r\n", sensorIndex, sensorStatus,GetTickCount() );
  m_errorFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
			if (sensorStatus == TUS_THIS_TC_OVER) {
				m_Direction = TUS_DIRECTION_DOWN;
				m_pWorkSoak->snv->maxOvershootVal = GetDefaultShootValue();
#if defined (DBG_FILE_LOG_AMS_DBG_ENABLE)
  QString   strLogMessage;
  strLogMessage.asprintf(L" CheckTCs : TSM_START_NEW_SOAK_DETECT m_pWorkSoak->snv->maxOvershootVal = %0.4f GTC:%d\r\n", m_pWorkSoak->snv->maxOvershootVal,GetTickCount() );
  m_errorFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
			}
		}
		break;
	}
	case TSM_ALL_TCS_OUT_OF_SOAK: {
		retVal = TUS_TC_NONE_IN_SOAK;
		// TC's are outside of the soaks, so we must run though all TC's and check their current levels
		// with each soak, if any TC falls within a valid soak then that soak becomes the target soak.
		for (int sensorIndex = 0; sensorIndex < m_numSensors; sensorIndex++) {
			T_PTUS_SENSOR_INFOMATION testSensor = &m_Sensor[sensorIndex];	// Get a convenient test handle
			if (testSensor->IsUserEnabled == FALSE) {
				continue;	// This sensor has been removed from the test, do not check it, move to next sensor
			}
			sensorStatus = IsInSoakLevel(testSensor, sensorReading);
			if (sensorStatus == TUS_THIS_TC_IN_SOAK) {
				// A TC has entered a the soak
				retVal = TUS_TC_SOME_IN_SOAK;		// Indicate soak in progress
				break;
			}
		}
		// Has a soak been entered?
		if (retVal == TUS_TC_SOME_IN_SOAK) {
			// yes, so run though the sensors and setup their base information within the now current working soak
			for (int sensorIndex = 0; sensorIndex < m_numSensors; sensorIndex++) {
				T_PTUS_SENSOR_INFOMATION testSensor = &m_Sensor[sensorIndex];	// Get a convenient test handle
				if (testSensor->IsUserEnabled == FALSE) {
					continue;	// This sensor has been removed from the test, do not check it, move to next sensor
				}
				sensorStatus = IsInSoakLevel(testSensor, sensorReading);
				if (sensorStatus == TUS_THIS_TC_IN_SOAK) {
					// The sensor has entered soak, indicate soak entered and setup overshoot start point
					testSensor->IsInSoak = TRUE;
					testSensor->SoakSensorData.shootValue = GetDefaultShootValue();
				} else {
					// Sensor not yet entered soak, set to still out of soak
					testSensor->IsInSoak = FALSE;
				}
			}
		}
		break;
	}
	case TSM_TCS_ENTERED_SOAK:			// One or more TC's are within the soak band
	{
		retVal = TUS_TC_ALL_IN_SOAK;
		for (int sensorIndex = 0; sensorIndex < m_numSensors; sensorIndex++) {
			T_PTUS_SENSOR_INFOMATION testSensor = &m_Sensor[sensorIndex];	// Get a convenient test handle
			if (testSensor->IsUserEnabled == FALSE) {
				continue;	// This sensor has been removed from the test, do not check it, move to next sensor
			}
			sensorStatus = IsInSoakLevel(testSensor, sensorReading);
			if (sensorStatus == TUS_THIS_TC_IN_SOAK) {
				// The sensor is within soak
				if (testSensor->IsInSoak == TRUE) {
					// Sensor was previously in soak, and is still in soak, test it's overshoot value and see if it has increased
					TestOverShoot(testSensor);
				} else {
					// The sensor has entered soak, indicate soak entered and setup overshoot start point
					testSensor->IsInSoak = TRUE;
					testSensor->SoakSensorData.shootValue = GetDefaultShootValue();
					TestOverShoot(testSensor);
				}

			} else {
				if (testSensor->IsInSoak == TRUE) {
					if (sensorStatus == TUS_THIS_TC_OVER) {
						// The sensor was previously in soak but has now gone above the soak, this is a failure
						retVal = TUS_TC_BREACHED;
						tcIndexPassBack = sensorIndex;
						break;
					}
				} else {
					// The sensor has not entered soak yet, indicate we don't have all sensors in soak.
					retVal = TUS_TC_SOME_IN_SOAK;
				}
			}
		}
		break;
	}
	case TSM_ALL_TCS_IN_SOAK:		// All TC's have gone into soak (some might have dropped below however )
	{
		retVal = TUS_TC_ALL_IN_SOAK;
		for (int sensorIndex = 0; sensorIndex < m_numSensors; sensorIndex++) {
			T_PTUS_SENSOR_INFOMATION testSensor = &m_Sensor[sensorIndex];	// Get a convenient test handle
			if (testSensor->IsUserEnabled == FALSE) {
				continue;	// This sensor has been removed from the test, do not check it, move to next sensor
			}
			sensorStatus = IsInSoakLevel(testSensor, sensorReading);
			if (sensorStatus == TUS_THIS_TC_IN_SOAK) {
				// Sensor in soak, test it's overshoot value and see if it has increased
				TestOverShoot(testSensor);
			} else {
				if (sensorStatus == TUS_THIS_TC_OVER) {
					// The sensor was previously in soak but has now gone outside of soak, this is a failure
					TestOverShoot(testSensor);
					retVal = TUS_TC_BREACHED;
					tcIndexPassBack = sensorIndex;
					break;
				} else {
					// The sensor has dropped out of soak, this is acceptable for going into stability mode
					retVal = TUS_TC_SOME_IN_SOAK;
					tcIndexPassBack = sensorIndex;
					break;
				}
			}
		}
		break;
	}
	case TSM_ALL_TC_IN_SOAK_AND_STABLE: {
		retVal = TUS_TC_ALL_IN_SOAK;
		for (int sensorIndex = 0; sensorIndex < m_numSensors; sensorIndex++) {
			T_PTUS_SENSOR_INFOMATION testSensor = &m_Sensor[sensorIndex];	// Get a convenient test handle
			if (testSensor->IsUserEnabled == FALSE) {
				continue;	// This sensor has been removed from the test, do not check it, move to next sensor
			}
			sensorStatus = IsInSoakLevel(testSensor, sensorReading);
			if (sensorStatus == TUS_THIS_TC_IN_SOAK) {
				// Update the Max an Min values for the TC
				// check max value and update is necessary
				if (sensorReading >= testSensor->SoakSensorData.maxInSoak) {
					// Max increased, record the new value
					testSensor->SoakSensorData.maxInSoak = sensorReading;
				}
				// check min valuse and update is necessary
				if (sensorReading <= testSensor->SoakSensorData.minInSoak) {
					// min decreased, record the new value
					testSensor->SoakSensorData.minInSoak = sensorReading;
				}
				// Update the overall max min and TC diffs
				UpdateStabilityMaxMinDiff(sensorIndex);
			} else {
				// The sensor has breached the tolerance band, determine upper or lower and set max and min respectivly
				UpdateStabilityMaxMinDiff(sensorIndex);
				retVal = TUS_TC_BREACHED;
				tcIndexPassBack = sensorIndex;
				break;
			}
		}
		break;
	}
	case TSM_SOAK_EXIT:	// The soak has completed (pass or fail), so we must check when TC's exit soak band before starting next soak
	{
		retVal = TUS_TC_NONE_IN_SOAK;
		for (int sensorIndex = 0; sensorIndex < m_numSensors; sensorIndex++) {
			T_PTUS_SENSOR_INFOMATION testSensor = &m_Sensor[sensorIndex];	// Get a convenient test handle
			if (testSensor->IsUserEnabled == FALSE) {
				continue;	// This sensor has been removed from the test, do not check it, move to next sensor
			}
			sensorStatus = IsInSoakLevel(testSensor, sensorReading);
			// Is the TC still in the soak
			if (sensorStatus == TUS_THIS_TC_IN_SOAK) {
				// Yes, indicate some TC's still in soak.
				retVal = TUS_TC_SOME_IN_SOAK;
				break;
			}
		}
		break;
	}
	}
	return retVal;
}

//****************************************************************************
///
/// Method that determines the control TC instance
///
/// @param[out]		USHORT &rusControlTCInstance - The zero based instance number of the control TC
///
/// @returns	Returns true if the control TC was found, is enabled and is of a compatible TC type
///
//****************************************************************************
const bool CAMS2750TUSMgr::DetermineControlTCInstance(USHORT &rusControlTCInstance) const {
	bool bFoundControlTC = false;

	// loop through the sensor configuration searching for the first control TC - any subsequent control TC's
	// shall be ignored as it will be assumed the user has made a configuration error
	CIOSetupConfig *pkIOSetupCfg = pSETUP->GetIOSetupConfig();

	T_PAICHANNEL ptAIChan = NULL;
	T_PAMS2750SENSORS ptSensors = pkIOSetupCfg->GetAMS2750SensorBlock(CONFIG_COMMITTED);

	for (USHORT usCount = 0; usCount < AMS2750SENSORS_SENSORS_SIZE; usCount++) {
		// check the analogue input is enabled and configured as a TC as well as the Control TC flag
		ptAIChan = pkIOSetupCfg->GetAnalogueInput(usCount, CONFIG_COMMITTED);

		if ((ptAIChan != NULL) && (ptAIChan->Enabled == TRUE) && (IsTUSSensor(ptAIChan, ptSensors->Sensors[usCount]))
				&& (ptSensors->Sensors[usCount].ControlTC == TRUE)) {
			// set the instance and success flag and then break from the loop as we do not need to continue
			// any further
			rusControlTCInstance = usCount + 1;
			bFoundControlTC = true;
			break;
		}
	}

	// check if a valid TC was found
	if (!bFoundControlTC) {
		// set to an out of range value
		rusControlTCInstance = 0;
	}

	return bFoundControlTC;
}

//****************************************************************************
///
/// Method that gets the control TC instance
///
/// @param[out]		USHORT &rusControlTCInstance - The zero based instance number of the control TC
///
/// @returns	Returns true if the control TC is valid
///
//****************************************************************************
const bool CAMS2750TUSMgr::GetControlTCInstance(USHORT &rusControlTCInstance) const {
	bool bControlTCValid = false;

	// set the passed in variable
	rusControlTCInstance = m_tTestConfig.controlTCNumber - 1;

	// check if the control TC is valid
	if (m_tTestConfig.controlTCNumber != 0) {
		// the control TC is valid
		bControlTCValid = true;
	} else {
		// not valid therefore return false
		bControlTCValid = false;
	}
	return bControlTCValid;
}

//****************************************************************************
///
/// Method used to start a TUS
///
/// @param[in]	const QString   &rstrNOTES - The entered notes
///
//****************************************************************************
void CAMS2750TUSMgr::StartTUS(const QString  &rstrNOTES) {
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();

	if (pThreadInfo != NULL) {
		//Update the Thread Counter for the DataProcessing
		//thread
		pThreadInfo->UpdateThreadCounter(AM_DATA_PROCESSING);
	}
#if defined (DBG_FILE_LOG_AMS_DBG_ENABLE)
  QString   strLogMessage;
  strLogMessage.asprintf(L"CAMS2750TUSMgr::StartTUS GTC:%d\r\n",GetTickCount() );
  m_errorFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
	// start the TUS unless we are already in this state
	if (m_eTUSState != tusRUNNING) {
		// Make sure the TC CAL Exclude is not enabled
		if ( pSYSTEM_INFO->AMS2750SensorCalIsExcluded()) {
			// TUS STarted so include TC Cal adjustments in readings
			pSYSTEM_INFO->IncludeAMS2750SensorCal();
		}

		// Increment number of TUS run so far and set the number in report header
		m_pTUSNV->main.TUScounter++;

		// Update TUS screen status
		QString  strRunning = "";
	strRunning = tr("Running");
		QString  strTimeNow = "";
		COMBO_VAR4 tVar;
		CTVtime kTimeNow;

		// On power fail recovery make sure we retsain the start time, if not a power fail then reset time form now
		if (m_NVRecoveryAttempt == TRUE) {
			kTimeNow = m_pTUSNV->test.startTime;							// Get previous start time
		} else {
			kTimeNow = pSYSTIMER->GetCurrentProcessTimeInMicroSec();	// Get current process time as start of survey
			// Generate next surevey date due
			m_pTUSNV->test.newSurveyDue =
					pSYSTIMER->GetCurrentProcessTimeInMicroSec() + SEC_TO_USEC(GetNextTestInterval( TRUE, &m_ptFurnaces->Furnaces[0] ));
		}
		tVar.ul = static_cast<ULONG>(kTimeNow.GetSeconds());
		strTimeNow = kTimeNow.TimeToStringShort();
		QString   wTime;
		strTimeNow.toWCharArray(wTime);
		QString   wRunning;
		strRunning.toWCharArray(wRunning)
		m_pkTUSStartTime->SetGeneralDetails(0, 0, wTime, wRunning);
		// calling the method below will cause the time to be recorder also
		m_pkTUSStartTime->SetValue(tVar);

		if (m_NVRecoveryAttempt == TRUE) {
			// If there was a copy of the previously completed soak, store it to the data file.
			if (m_pTUSNV->prevSoak.test.soakStatus == SOAK_STATUS_PASSED
					|| m_pTUSNV->prevSoak.test.soakStatus == SOAK_STATUS_FAILED) {
				// Last known soak stored, completed OK so send to data file to ensure written correctly
				m_ModuleMsgMgrClient.MMMClientPostIntMsg( INFINITE, MODULE_TUS_FILE_BUILDER, // Destination
						MODULE_TUS_MGR, // Sender
						MOD_TUS_ADD_SOAK, sizeof(T_TUSSOAKDATA), reinterpret_cast<BYTE*>(&m_pTUSNV->prevSoak));

			}
			// Check for the latest completed log line, and resend to data file to ensure full coverage
			int maxIndex = -1;
			int maxSeqNumber = -1;
			for (int logIndex = 0; logIndex < TUS_NVLOG_STORE; logIndex++) {
				// Check for invlaid log lines
				if (m_pTUSNV->line[logIndex].status != LOG_STATUS_INVALID) {
					// Log line valid, is it the most recent?
					if (m_pTUSNV->line[logIndex].sequenceNumber > maxSeqNumber) {
						// Most recent so far, so record the sequnce number and index
						maxSeqNumber = m_pTUSNV->line[logIndex].sequenceNumber;
						maxIndex = logIndex;
					}
				}
				if (pThreadInfo != NULL) {
					//Update the Thread Counter for the DataProcessing
					//thread
					pThreadInfo->UpdateThreadCounter(AM_DATA_PROCESSING);
				}
			}
			// check that the index is valid, so a log line is available for saving
			if (maxIndex != -1) {
				// Post log last good block to file write for intergrity
				m_ModuleMsgMgrClient.MMMClientPostIntMsg( INFINITE,
						MODULE_TUS_FILE_BUILDER,				// Destination
						MODULE_TUS_MGR,							// Sender
						MOD_TUS_ADD_LOG_DATA, sizeof(T_TUSDATAREADING),
						reinterpret_cast<BYTE*>(&m_pTUSNV->line[maxIndex]));
			}

			// Register this has been a power recovery to indiocate in next log line
			m_registerPowerFail = TRUE;
		} else {
			// Only perform the following when a new TUS has been started

			// Clear the NV line logs
			memset(&m_pTUSNV->line[0], 0, sizeof(T_TUSDATAREADING) * TUS_NVLOG_STORE);

			// trigger any TUS start events
			pEVENTS->TUSEventTrigger(tusSTART);

			// notify the TUS file builder thread we are about to start a TUS and want the file clearing
			m_ModuleMsgMgrClient.MMMClientPostIntMsg( INFINITE, MODULE_TUS_FILE_BUILDER, // Destination
					MODULE_TUS_MGR, // Sender
					MOD_TUS_CLEAR_TUS, 0, NULL);

			// pass the TUS file builder thread the test configuration
			m_ModuleMsgMgrClient.MMMClientPostIntMsg( INFINITE, MODULE_TUS_FILE_BUILDER, // Destination
					MODULE_TUS_MGR, // Sender
					MOD_TUS_ADD_TEST_CFG, sizeof(T_TUSTESTCONFIG), reinterpret_cast<BYTE*>(&m_tTestConfig));

			// pass the TUS file builder thread the sensor configurations
			CIOSetupConfig *pkIOSetupConfig = pSETUP->GetIOSetupConfig();
			T_PAMS2750SENSORS ptAMS2750Sensors = pkIOSetupConfig->GetAMS2750SensorBlock(CONFIG_COMMITTED);

			for (int iCount = 0; iCount < m_tTestConfig.numberOfSensors; iCount++) {
				// send the TUS TC configurations
				m_ModuleMsgMgrClient.MMMClientPostIntMsg( INFINITE,
						MODULE_TUS_FILE_BUILDER, // Destination
						MODULE_TUS_MGR, // Sender
						MOD_TUS_ADD_SENSOR_CFG, sizeof(T_TUSSENSORCONFIG),
						reinterpret_cast<BYTE*>(&m_taSensorsConfig[iCount]));
				if (pThreadInfo != NULL) {
					//Update the Thread Counter for the DataProcessing
					//thread
					pThreadInfo->UpdateThreadCounter(AM_DATA_PROCESSING);
				}
			}

			// now add the soak data
			for (int iSoakCount = 0; iSoakCount < m_pTUSNV->test.numSoaks; iSoakCount++) {
				ResetSoak(m_Soak[iSoakCount].Index, iSoakCount);

				// notify the TUS file builder thread we are starting the TUS - this effectively lets the TUS file builder
				// thread know there is no more configuration information to come
				m_ModuleMsgMgrClient.MMMClientPostIntMsg( INFINITE, MODULE_TUS_FILE_BUILDER, // Destination
						MODULE_TUS_MGR, // Sender
						MOD_TUS_ADD_SOAK, sizeof(T_TUSSOAKDATA), reinterpret_cast<BYTE*>(m_Soak[iSoakCount].snv));
				if (pThreadInfo != NULL) {
					//Update the Thread Counter for the DataProcessing
					//thread
					pThreadInfo->UpdateThreadCounter(AM_DATA_PROCESSING);
				}
			}

			CAMS2750InputCalMgr *pkInputCalMgr = new CAMS2750InputCalMgr();

			if (pkInputCalMgr->CalIsAvailable()) {
				// now add the general calibration data
				T_AMS2750GENCAL genCal = pkInputCalMgr->GetGenCalInLocalTempUnits();
				m_ModuleMsgMgrClient.MMMClientPostIntMsg(INFINITE, MODULE_TUS_FILE_BUILDER, // Destination
						MODULE_TUS_MGR, // Sender
						MOD_TUS_ADD_GENERAL_CAL, sizeof(T_AMS2750GENCAL), reinterpret_cast<BYTE*>(&genCal));

				// and now loop through each sensor input that was calibrated
				for (int sensorIndex = 0; sensorIndex < NUM_TCS_PER_SOAK; sensorIndex++) {
					T_SENSORINPUTCALDATA sensorCal = pkInputCalMgr->GetSensorInputCalInLocalTempUnits(sensorIndex);
					// check this sensor has some cal information intialised, even if it's invalid
					if (sensorCal.CalState != SCS_CAL_NOT_INIT) {
						// construct a data message
						T_SENSORINPUTCALDATAMSG sensorInputCalDataMsg;
						sensorInputCalDataMsg.sensorNo = sensorIndex;
						memcpy(&sensorInputCalDataMsg.sensorInputCal, &sensorCal, sizeof(T_SENSORINPUTCALDATA));

						m_ModuleMsgMgrClient.MMMClientPostIntMsg(INFINITE,
								MODULE_TUS_FILE_BUILDER, // Destination
								MODULE_TUS_MGR, // Sender
								MOD_TUS_ADD_SENSOR_INPUT_CAL, sizeof(T_SENSORINPUTCALDATAMSG),
								reinterpret_cast<BYTE*>(&sensorInputCalDataMsg));
					}
				}
			}

			delete pkInputCalMgr; //Coverity// CID: 1992657

			// update the test data
			CStringUtils::SafeWcsCpy(m_pTUSNV->test.startNotes, rstrNOTES, TUS_NOTES);
			m_pTUSNV->test.endTime = 0;
			m_pTUSNV->test.endNotes[0] = 0;
			CStringUtils::SafeWcsCpy(m_pTUSNV->test.userName, GetEngineer(), TUS_ENGINEER_NAME_LEN);

			// now send the start message with the test data
			m_ModuleMsgMgrClient.MMMClientPostIntMsg( INFINITE, MODULE_TUS_FILE_BUILDER, // Destination
					MODULE_TUS_MGR, // Sender
					MOD_TUS_START_TUS, sizeof(T_TUSTESTDATA), reinterpret_cast<BYTE*>(&m_pTUSNV->test));

			if (pThreadInfo != NULL) {
				//Update the Thread Counter for the DataProcessing
				//thread
				pThreadInfo->UpdateThreadCounter(AM_DATA_PROCESSING);
			}

			m_pTUSNV->test.startTime = pSYSTIMER->GetCurrentProcessTimeInMicroSec();
			m_pTUSNV->main.currentSoak = 0;
			m_pTUSNV->main.logSeqNumber = 1;
			m_IsAutoStop = TRUE;							 /// NP: To start next TUS from Index 1.
			m_registerPowerFail = FALSE;
#if defined (DBG_FILE_LOG_AMS_DBG_ENABLE)
  QString   strLogMessage;
  strLogMessage.asprintf(L"CAMS2750TUSMgr::StartTUS m_pTUSNV->main.logSeqNumber = %d GTC:%d\r\n", m_pTUSNV->main.logSeqNumber, GetTickCount() );
  m_errorFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
		}

		// Perform following for a new TUS or resuming a TUS on power fail
		m_pTUSNV->test.overallStatus = TUS_RUNNING;
		m_surveyTimer.StartTimer();
		SetElapsedTimer();
		m_pTUSNV->main.globalStatus = TUS_GLOBAL_RUNNING;
		setStateMachine(TSM_START_NEW_SOAK_DETECT);
		m_eTUSState = tusRUNNING;

		QString  diagMessage;
		diagMessage.asprintf(IDS_TUS_MGR_TUS_STARTED);
		LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_INFORMATION, diagMessage);
	}
}

//****************************************************************************
///
/// Method used to stop a TUS
///
/// @param[in]	&rstrNOTES - The stop tus notes for the report
/// @param[in]	defaultStatus - T_TUS_TEST_STATUS default status, set to other then TUS_PASSED to override auto check
///
//****************************************************************************
void CAMS2750TUSMgr::StopTUS(const QString  &rstrNOTES, T_TUS_TEST_STATUS defaultStatus) {
	// stop the TUS unless we are already in this state
	if (m_eTUSState != tusSTOPPED) {
		m_eTUSState = tusSTOPPED;

#if defined (DBG_FILE_LOG_AMS_DBG_ENABLE)
  QString   strLogMessage;
  strLogMessage.asprintf(L"CAMS2750TUSMgr::StopTUS - GTC:%d\r\n", GetTickCount() );
  m_errorFileLogger.WriteToDebugLogFile(strLogMessage);
#endif

		QString  strStopped("");
	strStopped = tr("Stopped");
		QString  strTimeNow("");
		strTimeNow = m_pkTUSStartTime->GetTag();
		m_pkTUSStartTime->SetGeneralDetails(0, 0, strTimeNow, strStopped);

		// restore the screen to its original zoom level
		RestoreNormalChartZoom();

		// trigger any TUS stop events
		pEVENTS->TUSEventTrigger(tusSTOP);

		// Set the end of test notes
		CStringUtils::SafeWcsCpy(m_pTUSNV->test.endNotes, rstrNOTES, TUS_NOTES);
		m_pTUSNV->test.endTime = pSYSTIMER->GetCurrentProcessTimeInMicroSec();

		// If the current soak had not finished, indicate by setting status to aborted.
		if (m_pWorkSoak->snv->soakStatus == SOAK_STATUS_SOAK_DETECT
				|| m_pWorkSoak->snv->soakStatus == SOAK_STATUS_IN_SOAK
				|| m_pWorkSoak->snv->soakStatus == SOAK_STATUS_IN_STABILITY) {
			m_pWorkSoak->snv->soakStatus = SOAK_STATUS_ABORTED;
		}

		m_pTUSNV->test.overallStatus = defaultStatus;
		// Run though all soaks, and check status to determine if TUS has failed and the reason for that failure
		// only check though if the TUS is set to have passed, an calling function can override reason by setting "defaultStatus" param
		if (m_pTUSNV->test.overallStatus == TUS_PASSED) {
			for (int soakIndex = 0; soakIndex < m_numSoaks; soakIndex++) {
				// Has the soak failed?
				if (m_Soak[soakIndex].snv->soakStatus == SOAK_STATUS_FAILED) {
					// Yes, set this as the reason for overall test failure
					m_pTUSNV->test.overallStatus = TUS_FAIL_SOAK_FAIL;
					break;
				}
				// Has the soak either not started, OR been aborted mid soak?
				if (m_Soak[soakIndex].snv->soakStatus == SOAK_STATUS_NOTSTARTED
						|| m_pWorkSoak->snv->soakStatus == SOAK_STATUS_ABORTED) {
					// Yes, this is a user selected abort
					m_pTUSNV->test.overallStatus = TUS_FAIL_USER_ABORT;
					break;
				}
			}
		}
		// Closedown the current soak
		CloseCurrentSoak();

		// notify the TUS file builder thread
		m_ModuleMsgMgrClient.MMMClientPostIntMsg( INFINITE, MODULE_TUS_FILE_BUILDER, // Destination
				MODULE_TUS_MGR, // Sender
				MOD_TUS_STOP_TUS, sizeof(T_TUSTESTDATA), reinterpret_cast<BYTE*>(&m_pTUSNV->test));

		// Indicate TUS has completed
		m_pTUSNV->main.globalStatus = TSM_GLOBAL_SURVEY_COMPLETE_NO_EXPORT;

		// Stop the survey timer and update elapsed timers
		m_surveyTimer.StopTimer();
		SetElapsedTimer();

		setStateMachine(TSM_START_NEW_SOAK_DETECT);		// Reset state machine

		// Reset all test sensors to be included
		for (int sensorIndex = 0; sensorIndex < m_numSensors; sensorIndex++) {
			m_Sensor[sensorIndex].IsUserEnabled = TRUE;
		}

#if defined (DBG_FILE_LOG_AMS_DBG_ENABLE)
  //QString   strLogMessage;
  strLogMessage.asprintf(L"CAMS2750TUSMgr::StopTUS m_pTUSNV->main.logSeqNumber = %d GTC:%d\r\n", m_pTUSNV->main.logSeqNumber, GetTickCount() );
  m_errorFileLogger.WriteToDebugLogFile(strLogMessage);
#endif

		// Diagnostic message for TUS complete
		QString  diagMessage;
		diagMessage.asprintf(IDS_TUS_MGR_TUS_STOPPED);
		LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_INFORMATION, diagMessage);

	}
}
//****************************************************************************
///
/// Method that indicates the manual TC stabilise button has been pressed
///
//****************************************************************************
void CAMS2750TUSMgr::TCsStable() {
	// Only allow manula stability if all TC's are currently within the soak
	if (m_pTUSNV->main.tusSM == TSM_ALL_TCS_IN_SOAK && m_StabilityEnabled) {
		// Stability timer has triggered, we can enter stability based on the timer
		m_pWorkSoak->snv->stabilityStatus = SOAK_STABILITY_MANUAL;
		setStateMachine(TSM_ENTER_STABILATY);
		QString  diagMessage;
		diagMessage.asprintf(IDS_TUS_MGR_MANUAL_STABILITY_SELECTED, m_pWorkSoak->Index + 1);
		LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_INFORMATION, diagMessage);
		// trigger any TUS Stability Achieved events RTVIEW-7
		pEVENTS->TUSEventTrigger(tusSTABILITY_ACHIEVED);
	}
}
//****************************************************************************
///
/// Method that indicates the export TUS button has been pressed
///
//****************************************************************************
void CAMS2750TUSMgr::ExportTUS() {
	// save to a file - present the 3 media choices and a filename selection dialog
	QString  strFileExt(L".tus");
	QString  strDefaultFilename("");
	CTVtime kTUSStartDate(m_pTUSNV->test.startTime);
#if defined (DBG_FILE_LOG_AMS_DBG_ENABLE)
  QString   strLogMessage;
  strLogMessage.asprintf(L"CAMS2750TUSMgr::ExportTUS m_pTUSNV->main.logSeqNumber = %d GTC:%d\r\n", m_pTUSNV->main.logSeqNumber, GetTickCount() );
  m_errorFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
	strDefaultFilename.asprintf(L"%s - %u - %s", m_ptFurnaces->Furnaces[0].Name, GetReportNumber(),
			kTUSStartDate.DateToStringShort());

	HBITMAP hBitmap = pSYSTEM_INFO->pOemInfo->GetBitmapHandle( V6RES_GRAPHIC_CONFIG_MENU_SAVE_ICON);
	ResGraphicInfo *pkGraphicInfo = pSYSTEM_INFO->pOemInfo->GetGraphicInfo( V6RES_GRAPHIC_CONFIG_MENU_SAVE_ICON);
	CDeviceSelectionDlg kDevSelection(CDeviceSelectionDlg::dstGenericSaveFile, mhpMainMenu, hBitmap,
			pkGraphicInfo->Width, pkGraphicInfo->Height, NULL, strFileExt, strDefaultFilename, true);
	if (kDevSelection.exec() == IDOK) {
		QString  strPathname(kDevSelection.GetSelectedFileName());
		// notify the TUS file builder thread
		m_ModuleMsgMgrClient.MMMClientPostIntMsg( INFINITE,
				MODULE_TUS_FILE_BUILDER, // Destination
				MODULE_TUS_MGR, // Sender
				MOD_TUS_EXPORT_TUS, (static_cast<USHORT>(strPathname.length()) + 1) * sizeof(WCHAR),
				reinterpret_cast<BYTE*>(strPathname.GetBuffer(0)));

		// Indicate user has exported the TUS report successfully.
		m_pTUSNV->main.globalStatus = TSM_GLOBAL_SURVEY_COMPLETE_EXPORT;

		// Diagnostic message for TUS complete
		QString  diagMessage;
		diagMessage.asprintf(IDS_TUS_MGR_TUS_EXPORTED);
		LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_INFORMATION, diagMessage);
#if defined (DBG_FILE_LOG_AMS_DBG_ENABLE)
  QString   strLogMessage;
  strLogMessage.asprintf(L"CAMS2750TUSMgr::ExportTUS ending m_pTUSNV->main.logSeqNumber = %d GTC:%d\r\n", m_pTUSNV->main.logSeqNumber, GetTickCount() );
  m_errorFileLogger.WriteToDebugLogFile(strLogMessage);
#endif

	}
}
//****************************************************************************
///
/// Method that gets the current extra grid line values and setpoint - values set to FLT_MAX if none required
///
//****************************************************************************
void CAMS2750TUSMgr::GetGridLineValues(float &rfGridLine1, float &rfGridLine2, float &rfSetpoint) {
	rfGridLine1 = m_gridLineLower;
	rfGridLine2 = m_gridLineUpper;
	rfSetpoint = m_soakLevel;
}

//****************************************************************************
///
/// Method that gets the current extra grid line values - values set to FLT_MAX if none required
///
/// @return	A string containing the engineer logged in during the TUS
///
//****************************************************************************
const QString  CAMS2750TUSMgr::GetEngineer() {
	CDataItemGeneral *pkLoggedInUserDIT = static_cast<CDataItemGeneral*>( pDIT->GetDataItemPtr(DI_GENERAL,
			DI_GENTYPE_GENERAL, DI_GEN_LOGGED_IN_USER));
	return QString  (pkLoggedInUserDIT->GetTag());
}
//****************************************************************************
///
/// Method that gets the TUS start time
///
/// @return	A string containing the start time
///
//****************************************************************************
const QString  CAMS2750TUSMgr::GetStartTime() {
	return GetStringTimeFromUSECTime(m_pTUSNV->test.startTime);
}
//****************************************************************************
///
/// Method that gets the TUS elapsed time
///
/// @return	A string containing the elapsed time
///
//****************************************************************************
const QString  CAMS2750TUSMgr::GetElapsedTime() {
	return QString  (m_pkElapsedTimeDIT->GetTag());
}
//****************************************************************************
///
/// Method that gets the TUS stop time
///
/// @return	A string containing the stop time
///
//****************************************************************************
const QString  CAMS2750TUSMgr::GetStopTime() {
	return GetStringTimeFromUSECTime(m_pTUSNV->test.endTime);
}

//****************************************************************************
/// Generate a TimeToStringShort CTVtime string from the USEC time
///
/// @param[in]	USECTime - time to convert to string time
///
/// @returns	CTVtime::TimeToStringShort formatted QString   
//****************************************************************************
const QString  CAMS2750TUSMgr::GetStringTimeFromUSECTime(LONGLONG USECTime) {
	// Convert time to String time using CTVtime
	QString  StrTime("");
	CTVtime theTime = USECTime;
	StrTime = theTime.TimeToStringShort();
	return StrTime;
}

//****************************************************************************
/// Set the elapsed time for a TUS
///
/// @returns	nothing
//****************************************************************************
void CAMS2750TUSMgr::SetElapsedTimer() {
	// Set the Elapsed time Data items
	m_pkElapsedTimeDIT->SetTag(
			CStringUtils::GetAutoDDHHMMSSspanFromSeconds(USEC_TO_SEC(m_surveyTimer.RecordedTimeInMicroSeconds()),
			TRUE));
	m_pkElapsedTimeDIT->SetValue((float) USEC_TO_SEC(m_surveyTimer.RecordedTimeInMicroSeconds()));
}

//****************************************************************************
///
/// Returns the class tolerance for required class and units
///
/// @param[in]	furnaceClass - the class type from 1 to 6
/// @param[in]	eTEMP_UNITS - Enum indicating the temperature units F or C
///
//****************************************************************************
float CAMS2750TUSMgr::GetToleranceForClass(int furnaceClass, T_TEMPERATURE_TYPE eTEMP_UNITS) {
	float retVal = 0;
	// If furnaceClass passed is outside limits set to the lowest class.
	if (furnaceClass < TUS_MIN_CLASS || furnaceClass > TUS_MAX_CLASS) {
		furnaceClass = TUS_MAX_CLASS;
	}
	if (eTEMP_UNITS == ttDEG_C) {
		retVal = TUS_FURNACE_CLASS_C[furnaceClass - 1];
	} else {
		retVal = TUS_FURNACE_CLASS_F[furnaceClass - 1];
	}
	return retVal;
}

//****************************************************************************
///
/// Method that updates the default soak tolerance given the current furnace type
///
/// @param[in]	const T_FURNACE_TYPE ePARTS_FURNACE - Enum indicating if this is a parts or raw material furnace
/// @param[in]	const USHORT usFURNACE_CLASS - Variable indicating the furance clas (1-6)
/// @param[in]	const T_TEMPERATURE_TYPE eTEMP_UNITS - Enum indicating the temperature units
///
//****************************************************************************
void CAMS2750TUSMgr::UpdateFurnaceTolerance(const T_FURNACE_TYPE ePARTS_FURNACE, const USHORT usFURNACE_CLASS,
		const T_TEMPERATURE_TYPE eTEMP_UNITS) {
	m_CurrDefSoakTolerance = GetToleranceForClass(m_tTestConfig.FurnaceClass, eTEMP_UNITS);
}

//****************************************************************************
///
/// Accessor method for the current soak tolerance
///
/// @param[in]	const int iSETPOINT - The setpoint we want the tolerance for
///
/// @return		The tolerance for the specified setpoint
///
//****************************************************************************
const float CAMS2750TUSMgr::GetSoakTolerance(const int iSETPOINT) const {
	float fSetpointTolerance = 0;
	if (m_ptFurnaces->Setpoints[iSETPOINT].TolOverride) {
		fSetpointTolerance = pSYSTEM_INFO->GetLocalTempFromDegCRelative(m_ptFurnaces->Setpoints[iSETPOINT].Tolerance);
	} else {
		fSetpointTolerance = m_CurrDefSoakTolerance;
	}
	return fSetpointTolerance;
}

//****************************************************************************
///
/// Get the best furnace class for a given tolerance
///
/// @param[in]	maxDev - Maximum Deviation in degrees in F or C to gte best class from
///
/// @return		the class from 1 to 6
///
//****************************************************************************
USHORT CAMS2750TUSMgr::GetBestClassForDeviation(float maxDev) {
	USHORT classMet = TUS_MAX_CLASS;
	maxDev = fabs(maxDev);		// Make sure the reading is absolute
	// Run through all classes starting with class 1 the most stringent until a class is found that the deviation is within.
	for (USHORT classIndex = TUS_MIN_CLASS; classIndex <= TUS_MAX_CLASS; classIndex++) {
		// Get the tolerance of the class to check
		float testTolerance = GetToleranceForClass(classIndex,
				static_cast<T_TEMPERATURE_TYPE>(m_tTestConfig.tempasprintf));
		if (maxDev <= testTolerance) {
			// The deviation is within the class tolerance, return this class
			classMet = classIndex;
			break;
		}
	}
	return classMet;
}

//****************************************************************************
///
/// Get the furnace class tolerance achieved for each soak.
///
/// @param[in]	usSET_POINT_NO - soak to get furnace class string for
///
/// @return		string for furnace class met of "1" to "6"
///
//****************************************************************************
const QString  CAMS2750TUSMgr::GetSPFurnaceClassMet(const USHORT usSET_POINT_NO) {
	// asprintf the current class met for display
	QString  classStr("");
	if (m_pTUSNV->soaks[usSET_POINT_NO].soakStatus == SOAK_STATUS_PASSED) {
		classStr.asprintf(L"%d", m_pTUSNV->soaks[usSET_POINT_NO].classMet);
	} else {
		classStr = L"--";
	}
	return classStr;
}

const float TUS_PARTS_INT[6][5] = { // A,			B,				C,				D,				E
		{ I_MONTHLY, I_MONTHLY, I_MONTHLY, I_MONTHLY, I_MONTHLY },	// Class 1
				{ I_MONTHLY, I_MONTHLY, I_MONTHLY, I_MONTHLY, I_MONTHLY },	// Class 2
				{ I_QUARTERLY, I_QUARTERLY, I_QUARTERLY, I_QUARTERLY, I_QUARTERLY },	// Class 3
				{ I_QUARTERLY, I_QUARTERLY, I_QUARTERLY, I_QUARTERLY, I_QUARTERLY },	// Class 4
				{ I_QUARTERLY, I_QUARTERLY, I_QUARTERLY, I_QUARTERLY, I_QUARTERLY },	// Class 5
				{ I_ANUALLY, I_ANUALLY, I_ANUALLY, I_ANUALLY, I_ANUALLY },	// Class 6
		};

const float TUS_RAW_INT[6][5] = { // A,				B,				C,				D,				E
		{ I_QUARTERLY, I_QUARTERLY, I_QUARTERLY, I_MONTHLY, I_QUARTERLY },	// Class 1
				{ I_MONTHLY, I_MONTHLY, I_MONTHLY, I_MONTHLY, I_MONTHLY },	// Class 2
				{ I_MONTHLY, I_MONTHLY, I_MONTHLY, I_MONTHLY, I_MONTHLY },	// Class 3
				{ I_SEMIANUALLY, I_SEMIANUALLY, I_SEMIANUALLY, I_QUARTERLY, I_SEMIANUALLY },	// Class 4
				{ I_SEMIANUALLY, I_SEMIANUALLY, I_SEMIANUALLY, I_QUARTERLY, I_SEMIANUALLY },	// Class 5
				{ I_ANUALLY, I_ANUALLY, I_ANUALLY, I_ANUALLY, I_ANUALLY },	// Class 6
		};

const float SAT_PARTS_INT[6][5] = { // A,			B,				C,				D,				E
		{ I_BIWEEKLY, I_WEEKLY, I_WEEKLY, I_WEEKLY, I_SEMIANUALLY }, // Class 1
				{ I_MONTHLY, I_BIWEEKLY, I_BIWEEKLY, I_WEEKLY, I_SEMIANUALLY }, // Class 2
				{ I_QUARTERLY, I_MONTHLY, I_MONTHLY, I_BIWEEKLY, I_SEMIANUALLY }, // Class 3
				{ I_QUARTERLY, I_MONTHLY, I_MONTHLY, I_BIWEEKLY, I_SEMIANUALLY }, // Class 4
				{ I_QUARTERLY, I_MONTHLY, I_MONTHLY, I_BIWEEKLY, I_SEMIANUALLY }, // Class 5
				{ I_SEMIANUALLY, I_SEMIANUALLY, I_SEMIANUALLY, I_SEMIANUALLY, I_SEMIANUALLY }, // Class 6
		};

const float SAT_RAW_INT[6][5] = {	// A,			B,				C,				D,				E
		{ I_MONTHLY, I_MONTHLY, I_MONTHLY, I_WEEKLY, I_SEMIANUALLY },	// Class 1
				{ I_MONTHLY, I_MONTHLY, I_MONTHLY, I_WEEKLY, I_SEMIANUALLY },	// Class 2
				{ I_MONTHLY, I_MONTHLY, I_MONTHLY, I_WEEKLY, I_SEMIANUALLY },	// Class 3
				{ I_QUARTERLY, I_QUARTERLY, I_QUARTERLY, I_MONTHLY, I_SEMIANUALLY },	// Class 4
				{ I_QUARTERLY, I_QUARTERLY, I_QUARTERLY, I_MONTHLY, I_SEMIANUALLY },	// Class 5
				{ I_SEMIANUALLY, I_SEMIANUALLY, I_SEMIANUALLY, I_SEMIANUALLY, I_SEMIANUALLY },	// Class 6
		};

//****************************************************************************
/// Get the furnace class tolerance achieved for each soak.
///
/// @param[in]	IsTUS - TRUE if required for TUS , otrherwise it's a SAT
/// @param[in]	pFurnace - pointer to furnace config for interval calculations
///
/// @return		Interval in seconds for next sat or tus
//****************************************************************************
ULONG CAMS2750TUSMgr::GetNextTestInterval(BOOL IsTUS, T_PFURNACE pFurnace) {
	ULONG intervalInSeconds = 0;

	if (IsTUS == TRUE) {
		if (pFurnace->Type == ftPARTS) {
			// TUS Parts Furnace
			intervalInSeconds = DAY_TO_SEC(TUS_PARTS_INT[pFurnace->FurnaceClass - 1][pFurnace->InstType]);
		} else {
			// TUS materials Furnace
			intervalInSeconds = DAY_TO_SEC(TUS_RAW_INT[pFurnace->FurnaceClass - 1][pFurnace->InstType]);
		}
	} else {
		if (pFurnace->Type == ftPARTS) {
			// Process Parts Furnace
			intervalInSeconds = DAY_TO_SEC(SAT_PARTS_INT[pFurnace->FurnaceClass - 1][pFurnace->InstType]);
		} else {
			// Process materials Furnace
			intervalInSeconds = DAY_TO_SEC(SAT_RAW_INT[pFurnace->FurnaceClass - 1][pFurnace->InstType]);
		}
	}
	return intervalInSeconds;
}

//****************************************************************************
///
/// Restore the normal zoom on the chart
///
//****************************************************************************
void CAMS2750TUSMgr::RestoreNormalChartZoom() {
	// Set gridline to display FULL trace
	m_gridLineUpper = FLT_MAX;
	m_gridLineLower = FLT_MAX;
	m_soakLevel = FLT_MAX;

	AfxGetApp()->GetMainWnd()->PostMessage(WM_OPPANEL_NORMAL_VIEW_TUS_SCRN, 0, 0);
}

//****************************************************************************
/// GetBit helper, return status of bit in USHORT array given index
///
/// @param[in]	index- 0 based index for TC number ( 0-47 )
/// @param[in]	pBitStore - pointer to USHORT array to hold bit status
///
/// @return		TRUE if bit set - otherwise FALSE
//****************************************************************************
BOOL CAMS2750TUSMgr::GetBit(int index, USHORT *pBitStore) {
	USHORT BitIndex = index >> 4;			// divide by 16 provides index into 16 bit
	USHORT BitBit = index & 0x0F;			// mask to find remainder gicing bit number 0-15
	return (BOOL) ((pBitStore[BitIndex] >> BitBit) & 0x01);	// Return status of bit
}

//****************************************************************************
/// SetBit helper, Sets a bit for the index bit of index
///
/// @param[in]	index- 0 based index for TC number ( 0-47 )
/// @param[in]	pBitStore - pointer to USHORT array to hold bit status
///
/// @return		nothing
//****************************************************************************
void CAMS2750TUSMgr::SetBit(int index, USHORT *pBitStore) {
	USHORT BitIndex = index >> 4;				// divide by 16 provides index into 16 bit
	USHORT BitBit = index & 0x0F;				// mask to find remainder gicing bit number 0-15
	pBitStore[BitIndex] |= (0x01 << BitBit);	// Or in bit to be set
}

//****************************************************************************
/// ClearBit helper, Clears a bit for the index bit of index
///
/// @param[in]	index- 0 based index for TC number ( 0-47 )
/// @param[in]	pBitStore - pointer to USHORT array to hold bit status
///
/// @return		nothing
//****************************************************************************
void CAMS2750TUSMgr::ClearBit(int index, USHORT *pBitStore) {
	USHORT BitIndex = index >> 4;			// divide by 16 provides index into 16 bit
	USHORT BitBit = index & 0x0F;			// mask to find remainder gicing bit number 0-15
	USHORT bitMask = ~(0x01 << BitBit);	// Create bitmask to clear bit
	pBitStore[BitIndex] &= bitMask;			// And bitmask to clear required bit
}

//****************************************************************************
/// Sets up a mask of currently enabled sensors for use in TC disable picker
///
/// @param[in]	pBitStore - pointer to USHORT array to hold enabled TC mask
///
/// @return		nothing
//****************************************************************************
void CAMS2750TUSMgr::SetEnabledMask(USHORT *pBitStore) {
	memset(pBitStore, 0, sizeof(USHORT) * TUS_SENSORMASK);		// Cleardown mask

	// Run though all enabled TC's and add them to mask, ignoring control TC
	for (int sensorIndex = 0; sensorIndex < m_numSensors; sensorIndex++) {
		if (m_Sensor[sensorIndex].IsUserEnabled == TRUE) {
			SetBit(m_Sensor[sensorIndex].Index, pBitStore);
		}
	}
}

//****************************************************************************
/// sets the TC's to be user disabled during a TUS inline with 3.5.16
/// of the MAS2750 spec
///
/// @param[in]	index- 0 based index for TC number ( 0-47 )
///
/// @return		nothing
//****************************************************************************
void CAMS2750TUSMgr::SetTCIgnore(USHORT *pMask) {
	BOOL bitStatus = FALSE;
	T_PTUS_SENSOR_INFOMATION pSensor = NULL;
	int numSensorsEnabled = 0;
	for (int sensorIndex = 0; sensorIndex < m_numSensors; sensorIndex++) {
		pSensor = &m_Sensor[sensorIndex];
		bitStatus = GetBit(pSensor->Index, pMask);
		// If the bit status is TRUE , sensor turned on so add to number of enabled sensors
		if (bitStatus == TRUE) {
			numSensorsEnabled++;
		}
		// If current enabled status of the TC is different to the requested, it's a chnage, notfiy message lists
		if (pSensor->IsUserEnabled != bitStatus) {
			// Status is different, notify message list of change
			if (bitStatus == TRUE) {
				// We are turning the TC back on
				QString  diagMessage;
				diagMessage.asprintf(IDS_TUS_MGR_REENABLE_TC, pSensor->Index + 1);
				LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, diagMessage);
			} else {
				// We are turning the TC Off
				QString  diagMessage;
				diagMessage.asprintf(IDS_TUS_MGR_DISABLE_TC, pSensor->Index + 1);
				LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, diagMessage);
			}
			pSensor->IsUserEnabled = bitStatus;
		}
	}
}

//****************************************************************************
/// Gets minimum number of TC's enabled during a TUS inline with 3.5.16
/// of the MAS2750 spec
///
/// @return		Minumum number of TC s allowed
//****************************************************************************
int CAMS2750TUSMgr::GetMinTCAllowed() {
	int numFailuresAllowed = 0;
	// If we are not setting, we are validating against table 3.5.16 in AMS2750 spec
	if ( pSYSTEM_INFO->GetDegCTempFromLocal(m_maxSoakTemp) >= 1093.0F) {
		// Test Temperature is or exceeds 2000F (1093C ), setup the number of failures allowed
		if (m_numSensorsAdjusted >= 40) {
			numFailuresAllowed = m_numSensorsAdjusted / 10;
		} else if (m_numSensorsAdjusted >= 24) {
			numFailuresAllowed = 4;
		} else if (m_numSensorsAdjusted >= 17) {
			numFailuresAllowed = 3;
		} else if (m_numSensorsAdjusted >= 10) {
			numFailuresAllowed = 2;
		} else if (m_numSensorsAdjusted >= 6) {
			numFailuresAllowed = 1;
		}
	} else {
		// Test Temperature is below 2000F (1093C ), setup the number of failures allowed
		if (m_numSensorsAdjusted >= 40) {
			numFailuresAllowed = m_numSensorsAdjusted / 10;
		} else if (m_numSensorsAdjusted >= 24) {
			numFailuresAllowed = 3;
		} else if (m_numSensorsAdjusted >= 17) {
			numFailuresAllowed = 2;
		} else if (m_numSensorsAdjusted >= 10) {
			numFailuresAllowed = 1;
		}
	}
	return m_numSensorsAdjusted - numFailuresAllowed;
}

//****************************************************************************
/// Reset the current soak, ready to start test of current soak again.
///
/// @return		nothing
//****************************************************************************
void CAMS2750TUSMgr::RestartCurrentSoak() {
	// A request from the user to restart current soak, is this the first soak
	if (m_pTUSNV->main.currentSoak > 0) {
		// Has it completed the last soak, and moved past.
		if (m_pTUSNV->main.currentSoak >= m_numSoaks) {
			// Yes so move back to last soak
			m_pTUSNV->main.currentSoak = m_numSoaks - 1;
		}
		// No, so previous soak might have failed and current is not started, meaning previous soak needs to be restarted
		if (m_Soak[m_pTUSNV->main.currentSoak].snv->soakStatus == SOAK_STATUS_NOTSTARTED
				&& m_Soak[m_pTUSNV->main.currentSoak - 1].snv->soakStatus == SOAK_STATUS_FAILED) {
			// Reset current undetected soak & roll back soak counter to previous
			ResetSoak(m_Soak[m_pTUSNV->main.currentSoak].Index, m_pTUSNV->main.currentSoak);
			m_pTUSNV->main.currentSoak--;
		}
	}
	// Reset soak and state machine
	ResetSoak(m_Soak[m_pTUSNV->main.currentSoak].Index, m_pTUSNV->main.currentSoak);
	setStateMachine(TSM_START_NEW_SOAK_DETECT);
	// Post message to inducate manual soak reset
	QString  diagMessage;
	diagMessage.asprintf(IDS_TUS_MGR_SOAK_MANUALLY_RESTARTED, m_pTUSNV->main.currentSoak + 1);
	LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, diagMessage);

}

//****************************************************************************
/// Get the current maximum overshoot value for the soak.
///
/// @param[in]	usSET_POINT_NO - soak to get overshoot for
///
/// @return		current value of the overshoot
//****************************************************************************
float CAMS2750TUSMgr::GetSPMaxRampOvershootTCValue(USHORT usSET_POINT_NO) {
	float retVal = m_pTUSNV->soaks[usSET_POINT_NO].maxOvershootVal;
	// If the overshoot is set to rogue value, return 0
	if (retVal == TUS_READING_ROGUE || retVal == -TUS_READING_ROGUE) {
		retVal = 0;		// Overshoot is rogue value, return 0 to display
	}
	return retVal;
}
//****************************************************************************
///
/// Method used to copy ASM2750 process information from one sensor to another
///
/// @param[in]			T_AMS2750SENSOR &SENSOR_TO_COPY - The sensor information we wish to copy
/// @param[out]			T_AMS2750SENSOR &sensorToOverwrite - The sensor information we wish to overwrite/copy to
///
//****************************************************************************
void CAMS2750TUSMgr::CopyAMS2750ProcessTCInfo(const T_AMS2750SENSOR &SENSOR_TO_COPY,
		T_AMS2750SENSOR &sensorToOverwrite) {
	// do not overwrite the control TC flag
	BOOL controlTC = sensorToOverwrite.ControlTC;
	memcpy(&sensorToOverwrite, &SENSOR_TO_COPY, sizeof(T_AMS2750SENSOR));
	sensorToOverwrite.ControlTC = controlTC;
}
//****************************************************************************
///
/// Method used to copy ASM2750 TUS information from one sensor to another
///
/// @param[in]			T_AMS2750SENSOR &SENSOR_TO_COPY - The sensor information we wish to copy
/// @param[out]			T_AMS2750SENSOR &sensorToOverwrite - The sensor information we wish to overwrite/copy to
///
//****************************************************************************
void CAMS2750TUSMgr::CopyAMS2750TUSTCInfo(T_AMS2750SENSOR &SENSOR_TO_COPY, T_AMS2750SENSOR &sensorToOverwrite) {
	// do not overwrite the control TC flag and TCPosition
	BOOL controlTC = sensorToOverwrite.ControlTC;
	WCHAR TCPosition[AMS2750SENSOR_TCPOSITION_LEN];
	memcpy(TCPosition, sensorToOverwrite.TCPosition, AMS2750SENSOR_TCPOSITION_LEN * sizeof(WCHAR));
	memcpy(&sensorToOverwrite, &SENSOR_TO_COPY, sizeof(T_AMS2750SENSOR));
	memcpy(sensorToOverwrite.TCPosition, TCPosition, AMS2750SENSOR_TCPOSITION_LEN * sizeof(WCHAR));
	sensorToOverwrite.ControlTC = controlTC;
}
//****************************************************************************
/// Method used to identify if the AI channel is configured as a TUS sensor
///
/// @param[in]	paiChannel - the AI channel configuration
/// @param[in]	ptSensor - the associated AMS2750 sensor
///
/// @return		true if this is configured as a valid TUS sensor
//****************************************************************************
bool CAMS2750TUSMgr::IsTUSSensor(T_PAICHANNEL paiChannel, T_AMS2750SENSOR &rtSensor) {
	if (CanBeConfiguredAsAMS2750Sensor(paiChannel)) {
		return rtSensor.TUSTC;
	}
	return false;
}
//****************************************************************************
/// Method used to identify if the AI channel can be configured as an AMS2750 sensor (doesn't mean it is one though)
///
/// @param[in]	paiChannel - the AI channel configuration
///
/// @return		true if this can be configured as a TUS sensor
//****************************************************************************
bool CAMS2750TUSMgr::CanBeConfiguredAsAMS2750Sensor(T_PAICHANNEL paiChannel) {
	if ((pSYSTEM_INFO->FWOptionTUSModeAvailable() || pSYSTEM_INFO->FWOptionAMS2750ProcessAvailable())
			&& ((paiChannel->Type == AI_CHANNEL_TYPE_TC)
					|| ((paiChannel->Type == AI_CHANNEL_TYPE_RT)
							&& (CAMS2750TUSMgr::IsNobleMetalRT(paiChannel->RT.SelectedRT))))) {
		return true;
	}
	return false;
}
//***************************************************************************
/// Method used to determine if an RT is a noble metal
///
/// @param[in/out] 		USHORT rtType - the RT type
///
//****************************************************************************
bool CAMS2750TUSMgr::IsNobleMetalRT(USHORT rtType) {
	if ((rtType == AI_RT_RANGE_PT100) || (rtType == AI_RT_RANGE_PT200) || (rtType == AI_RT_RANGE_PT400)
			|| (rtType == AI_RT_RANGE_PT500) || (rtType == AI_RT_RANGE_PT1000) || (rtType == AI_RT_RANGE_PT2000)) {
		return true;
	}
	return false;
}

//***************************************************************************
/// Accessor for a particular setpoint's max TC name
///
/// @param[in/out] 		USHORT usSET_POINT_NO - the set point number
///
//****************************************************************************
const QString  CAMS2750TUSMgr::GetSPMaxTCName(const USHORT usSET_POINT_NO) {
	if (m_pTUSNV->soaks[usSET_POINT_NO].maxTCnum != 0) {
		T_TUS_SENSOR_INFOMATION *sensorInfo = GetTUSSensorDetailsByInstanceNo(m_pTUSNV->soaks[usSET_POINT_NO].maxTCnum);

		if (sensorInfo != NULL) {
			bool isTC = sensorInfo->AnalogueConfig->Type == AI_CHANNEL_TYPE_TC;
			return buildSensorName(m_pTUSNV->soaks[usSET_POINT_NO].maxTCnum, isTC);
		}
		// something has gone wrong
		return m_errorTCIdent;
	}
	// return the default non-existant TC identifier
	return m_nonExistantTCIdent;
}
//***************************************************************************
/// Accessor for a particular setpoint's min TC name
///
/// @param[in/out] 		USHORT usSET_POINT_NO - the set point number
///
//****************************************************************************
const QString  CAMS2750TUSMgr::GetSPMinTCName(const USHORT usSET_POINT_NO) {
	if (m_pTUSNV->soaks[usSET_POINT_NO].minTCnum != 0) {
		T_TUS_SENSOR_INFOMATION *sensorInfo = GetTUSSensorDetailsByInstanceNo(m_pTUSNV->soaks[usSET_POINT_NO].minTCnum);

		if (sensorInfo != NULL) {
			bool isTC = sensorInfo->AnalogueConfig->Type == AI_CHANNEL_TYPE_TC;
			return buildSensorName(m_pTUSNV->soaks[usSET_POINT_NO].minTCnum, isTC);
		}
		// something has gone wrong
		return m_errorTCIdent;
	}
	// return the default non-existant TC identifier
	return m_nonExistantTCIdent;
}
//***************************************************************************
/// Accessor for a particular setpoint's max TC diff wrt its setpoint in display temperature units
///
/// @param[in/out] 		USHORT usSET_POINT_NO - the set point number
///
//****************************************************************************
const QString  CAMS2750TUSMgr::GetSPMaxTCDiffWrtSPName(const USHORT usSET_POINT_NO) {
	if (m_pTUSNV->soaks[usSET_POINT_NO].maxTempDiffTCtoSetPNum != 0) {
		T_TUS_SENSOR_INFOMATION *sensorInfo = GetTUSSensorDetailsByInstanceNo(
				m_pTUSNV->soaks[usSET_POINT_NO].maxTempDiffTCtoSetPNum);

		if (sensorInfo != NULL) {
			bool isTC = sensorInfo->AnalogueConfig->Type == AI_CHANNEL_TYPE_TC;
			return buildSensorName(m_pTUSNV->soaks[usSET_POINT_NO].maxTempDiffTCtoSetPNum, isTC);
		}
		// something has gone wrong
		return m_errorTCIdent;
	}
	// return the default non-existant TC identifier
	return m_nonExistantTCIdent;
}
//***************************************************************************
/// Accessor for a particular setpoint's max ramp overshoot TC name
///
/// @param[in/out] 		USHORT usSET_POINT_NO - the set point number
///
//****************************************************************************
QString  CAMS2750TUSMgr::GetSPMaxRampOvershootTCName(const USHORT usSET_POINT_NO) {
	if (m_pTUSNV->soaks[usSET_POINT_NO].overShootTCNum != 0) {
		T_TUS_SENSOR_INFOMATION *sensorInfo = GetTUSSensorDetailsByInstanceNo(
				m_pTUSNV->soaks[usSET_POINT_NO].overShootTCNum);

		if (sensorInfo != NULL) {
			bool isTC = sensorInfo->AnalogueConfig->Type == AI_CHANNEL_TYPE_TC;
			return buildSensorName(m_pTUSNV->soaks[usSET_POINT_NO].overShootTCNum, isTC);
		}
		// something has gone wrong
		return m_errorTCIdent;
	}
	// return the default non-existant TC identifier
	return m_nonExistantTCIdent;
}
//***************************************************************************
/// Helper method sued to get the sensor information for the passed in sensor instance number (not the same as the index)
///
/// @param[in] 		const USHORT instanceNo - the one based global channel or instance number
///
//****************************************************************************
T_TUS_SENSOR_INFOMATION* CAMS2750TUSMgr::GetTUSSensorDetailsByInstanceNo(const USHORT instanceNoOneBased) {
	T_TUS_SENSOR_INFOMATION *sensorInfo = NULL;

	USHORT zeroBasedInstanceNo = instanceNoOneBased - 1;

	for (int sensorIndex = 0; sensorIndex < AMS2750SENSORS_SENSORS_SIZE; sensorIndex++) {
		if ((m_Sensor[sensorIndex].AnalogueConfig != NULL)
				&& (m_Sensor[sensorIndex].AnalogueConfig->Instance == zeroBasedInstanceNo)) {
			sensorInfo = &(m_Sensor[sensorIndex]);
			break;
		}
	}

	return sensorInfo;
}

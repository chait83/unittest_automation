/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Configuration System
/// @n Filename:  AMS2750SensorCalData.cpp
/// @n Description: Implementation for the CAMS2750SensorCalData class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  5 Stability Project 1.0.1.3 7/2/2011 4:55:22 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  4 Stability Project 1.0.1.2 7/1/2011 4:37:56 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  3 Stability Project 1.0.1.1 3/17/2011 3:20:08 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  2 Stability Project 1.0.1.0 2/15/2011 3:02:07 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// **************************************************************************

#include "StringDefinitions.h"
#include "AMS2750SensorCalData.h"

//****************************************************************************
// CAMS2750SensorCalData(	T_PAMS2750SENSOR *ptSensor,
//							const USHORT usMAX_NO_OF_ELEMENTS )
///
/// Constructor
///
/// @param[in/out] 		T_PAMS2750SENSOR ptSensor - Pointer to the sensor calibration data we 
///						want to modify/view	
///
//****************************************************************************
CAMS2750SensorCalData::CAMS2750SensorCalData(T_PAMS2750SENSOR ptSensor) : CConfigData(dtAMS2750SensorCal, 0, 0, false), m_ptAMS2750Sensor(
		ptSensor) {

}
//****************************************************************************
// ~CAMS2750SensorCalData( )
///
/// Destructor
///
//****************************************************************************
CAMS2750SensorCalData::~CAMS2750SensorCalData() {

}
//****************************************************************************
// const QString   GetDataAsString( const bool bINCLUDE_UNITS )
///
/// Method that returns the data as a string
///
/// @return		A string containing the data
///
//****************************************************************************
const QString  CAMS2750SensorCalData::GetDataAsString(const bool bINCLUDE_UNITS) {
	QString  strTitle("");
	strTitle.asprintf(IDS_CFG_LINEARISATION_NO_OF_POINTS_SUBTITLE, m_ptAMS2750Sensor->CalElements);
	return strTitle;
}
//****************************************************************************
///
/// Method called to validate data entered by the user
///
/// @param[in]		const T_PAMS2750SENSOR ptNEW_SENSOR_DATA - The new linearisation data thast we need
///					to validate
/// @param[out]		USHORT &rusFailedValueZeroBased - The value that has failed, zero based
///
/// @return		True if the data validated okay
///
//****************************************************************************
const bool CAMS2750SensorCalData::ValidateData(const T_PAMS2750SENSOR ptNEW_SENSOR_DATA,
		USHORT &rusFailedValueZeroBased) {
	bool bOK = true;

	// run through the table checking for dog legs - firstly check which way we are
	// going if there are 2 or more elements
	if (ptNEW_SENSOR_DATA->CalElements >= 2) {
		bool bAscending = false;
		if (ptNEW_SENSOR_DATA->CalPoints[0].CalPoint < ptNEW_SENSOR_DATA->CalPoints[1].CalPoint) {
			// the X values are in ascending order
			bAscending = true;
		} else {
			// the X values are in descending order
			bAscending = false;
		}

		// loop through all the values checking if they are valid - don't check the first value as it can
		// only be checked against the next reading
		for (USHORT usCount = 1; usCount < ptNEW_SENSOR_DATA->CalElements; usCount++) {
			// check based on the ascending flag
			if (bAscending) {
				// the current must be greater than the previous
				if (ptNEW_SENSOR_DATA->CalPoints[usCount].CalPoint
						<= ptNEW_SENSOR_DATA->CalPoints[usCount - 1].CalPoint) {
					// the value is the same or going back on the previous therefore this is an error - set the
					// value that is in error and drop out of the loop
					rusFailedValueZeroBased = usCount;
					bOK = false;
					break;
				}
			} else {
				// the current must be less than the previous
				if (ptNEW_SENSOR_DATA->CalPoints[usCount].CalPoint
						>= ptNEW_SENSOR_DATA->CalPoints[usCount - 1].CalPoint) {
					// the value is the same or going back on the previous therefore this is an error - set the
					// value that is in error and drop out of the loop
					rusFailedValueZeroBased = usCount;
					bOK = false;
					break;
				}
			}
		}
	}

	return bOK;
}

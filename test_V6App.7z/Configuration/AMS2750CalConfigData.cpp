/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Configuration System
/// @n Filename:  AMS2750CalConfigData.cpp
/// @n Description: Implementation for the CAMS2750CalConfigData class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:$
//
// **************************************************************************


#include "AMS2750CalConfigData.h"

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif

//****************************************************************************
///
/// Constructor
///
/// @param[in/out] 		T_PAMS2750CALCFG ptCalConfig - Pointer to the calibration data we 
///						want to modify/view	
///
//****************************************************************************
CAMS2750CalConfigData::CAMS2750CalConfigData(T_PAMS2750CALCFG ptCalConfig) : CConfigData(dtAMS2750Cal, 0, 0, false), m_ptAMS2750CalConfig(
		ptCalConfig) {

}
//****************************************************************************
// ~CAMS2750CalConfigData( )
///
/// Destructor
///
//****************************************************************************
CAMS2750CalConfigData::~CAMS2750CalConfigData() {

}
//****************************************************************************
// const QString   GetDataAsString( const bool bINCLUDE_UNITS )
///
/// Method that returns the data as a string
///
/// @return		A string containing the data
///
//****************************************************************************
const QString  CAMS2750CalConfigData::GetDataAsString(const bool bINCLUDE_UNITS) {
	QString  strTitle("");
	strTitle.asprintf(IDS_CFG_LINEARISATION_NO_OF_POINTS_SUBTITLE, m_ptAMS2750CalConfig->CalElements);
	return strTitle;
}
//****************************************************************************
///
/// Method called to validate data entered by the user
///
/// @param[in]		const T_PAMS2750CALCFG ptNEW_CAL_DATA - The new linearisation data thast we need
///					to validate
/// @param[out]		USHORT &rusFailedValueZeroBased - The value that has failed, zero based
///
/// @return		True if the data validated okay
///
//****************************************************************************
const bool CAMS2750CalConfigData::ValidateData(const T_PAMS2750CALCFG ptNEW_CAL_DATA, USHORT &rusFailedValueZeroBased) {
	bool bOK = true;

	// run through the table checking for dog legs - firstly check which way we are
	// going if there are 2 or more elements
	if (ptNEW_CAL_DATA->CalElements >= 2) {
		bool bAscending = false;
		if (ptNEW_CAL_DATA->CalPoints[0].CalPoint < ptNEW_CAL_DATA->CalPoints[1].CalPoint) {
			// the X values are in ascending order
			bAscending = true;
		} else {
			// the X values are in descending order
			bAscending = false;
		}

		// loop through all the values checking if they are valid - don't check the first value as it can
		// only be checked against the next reading
		for (USHORT usCount = 1; usCount < ptNEW_CAL_DATA->CalElements; usCount++) {
			// check based on the ascending flag
			if (bAscending) {
				// the current must be greater than the previous
				if (ptNEW_CAL_DATA->CalPoints[usCount].CalPoint <= ptNEW_CAL_DATA->CalPoints[usCount - 1].CalPoint) {
					// the value is the same or going back on the previous therefore this is an error - set the
					// value that is in error and drop out of the loop
					rusFailedValueZeroBased = usCount;
					bOK = false;
					break;
				}
			} else {
				// the current must be less than the previous
				if (ptNEW_CAL_DATA->CalPoints[usCount].CalPoint >= ptNEW_CAL_DATA->CalPoints[usCount - 1].CalPoint) {
					// the value is the same or going back on the previous therefore this is an error - set the
					// value that is in error and drop out of the loop
					rusFailedValueZeroBased = usCount;
					bOK = false;
					break;
				}
			}
		}
	}

	return bOK;
}

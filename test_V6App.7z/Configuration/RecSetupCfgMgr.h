/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Configuration System
/// @n Filename:  RecSetupCfgMgr.cpp
/// @n Description: Definition for the CRecSetupCfgMgr class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  112  Stability Project 1.108.1.2  7/11/2011 7:14:48 PM  Hemant(HAIL) 
// Files has been updated for fixing issue of "Restrict Pen limit to
//  32 in a Group". This chnages has been done in TMS application. Source
//  files related to configuration are same in TMS and V6App.
//  111  Stability Project 1.108.1.1  7/2/2011 5:00:18 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  110  Stability Project 1.108.1.0  7/1/2011 4:28:12 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  109  V6 Firmware 1.108  11/20/2009 4:57:37 PM  Binsy Pillai  
//  precursur code
// $
//
// **************************************************************************

#ifndef __RECSETUPCFGMGR_H__
#define __RECSETUPCFGMGR_H__

#include <QMutex>
#include <memory>
#include "V6globals.h"
#include "V6Config.h"
#include "BaseCfgMgr.h"
#include<map>

class CConfigInterface;
class CConfigBranch;
class CConfigItem;
class CLayoutItem;

//**CRecSetupCfgMgr*********************************************************************
///
/// @brief Singleton class responsible for processing calls for a particular setup item and subsequently
///	creating the required configuration heirarchy
/// 
/// Singleton class responsible for processing calls for a particular setup item and subsequently
///	creating the required configuration heirarchy. Currently this class wil handle the creation of
/// setup heirarchies for the recorder setup.
///
//****************************************************************************
class CRecSetupCfgMgr: public CBaseCfgMgr {
public:

#ifdef TTR6SETUP
  // Stability Project Fix:
  // Fix for issue, restrict 32 pens in a group
  USHORT m_GrpPenCounter[PEN_GROUP_MAX];									  ///Array -to count no of pens in a Group
  USHORT SetGroupPenValue(int groupNumber);								  /// Set the number of pens in a group

  std::map<QString   ,USHORT>m_PenGroupMap;
  std::map<QString   ,USHORT>::iterator m_Iter;
#endif

	// Destructor
	~CRecSetupCfgMgr(void);

	// Singleton Accessor/Creator
	static CRecSetupCfgMgr* Instance();

	// Method that creates a pen config hierarchy
	CConfigInterface* CreatePenConfig();

	// Method that creates an analogue input config hierarchy
	CConfigInterface* CreateAnalogueInConfig();

	// Method that creates a screen saver config hierarchy
	CConfigBranch* CreateScreenSaverConfig();

	// Method that creates a chart config hierarchy
	CConfigBranch* CreateChartConfig();

	// Method that creates a tabular display config hierarchy
	CConfigBranch* CreateTabularDisplayConfig();

	// Method that creates an events config hierarchy
	CConfigBranch* CreateEventsConfig();

	// Method that creates a counters config hierarchy
	CConfigBranch* CreateCountersConfig();

	// Method that creates a printer config hierarchy
	CConfigBranch* CreatePrinterConfig();

	// Method that creates a printer config hierarchy
	CConfigBranch* CreateOPCUAConfig();

	// Method that creates a batch config hierarchy
	CConfigBranch* CreateBatchConfig();

	// Method that creates a export config hierarchy
	CConfigBranch* CreateRecordingExportConfig(BOOL bIsModifiedEncrypt = FALSE);

	// Method that sets up the general batch properties config branch
	void SetupBatchGeneralProps(CConfigBranch *pkParent, T_PBATCH ptBatch);

	// Method that sets up the group batch properties config branch
	void SetupBatchGroupProps(CConfigBranch *pkParent, T_PBATCH ptBatch, const USHORT usGROUP_INDEX);

	// Method that creates an error control config hierarchy
	CConfigBranch* CreateErrorControlConfig();

	// Method that creates a localisation config hierarchy
	CConfigBranch* CreateLocalisationConfig();

	// Method that creates a credits config hierarchy
	CConfigBranch* CreateCreditsConfig();

	// Method that creates a demo config hierarchy
	CConfigBranch* CreateDemoConfig();

	// Method that creates a production config hierarchy
	CConfigBranch* CreateProductionConfig();

	// Method that creates a TCPIP settings config hierarchy
	CConfigBranch* CreateTCPIPConfig();

	// Method that creates a Modbus Comms config hierarchy
	CConfigBranch* CreateModbusCommsConfig();

	// Method that creates a Modbus Slave config hierarchy
	CConfigBranch* CreateModbusSlaveConfig();

	// Method that creates a Modbus Master config hierarchy
	CConfigBranch* CreateModbusMasterConfig();

	// Method that creates the config branch for a modbus master slave device
	void SetupModbusMasterSlave(const USHORT usSLAVE_INDEX, CConfigBranch *pkSlaveParent, T_MODBUSSLAVEDEV *ptSlaveDev,
			const bool bEnabledSlaveUsingRS485);

	// Method that creates the config branch for a modbus master's slave transaction
	void SetupModbusMasterSlaveTransaction(const USHORT usTX_INDEX, CConfigBranch *pkTXParent, T_MODBUSTX *ptTX,
			const USHORT usSLAVE_INDEX);

	// Method that creates a SNTP config hierarchy
	CConfigBranch* CreateSNTPConfig();

	// Method that creates a Digital IO config hierarchy
	CConfigBranch* CreateDigitalIOConfig();

	// Method that creates a Pulse In config hierarchy
	CConfigBranch* CreatePulseInConfig();

	// Method that creates an analogue output config hierarchy
	CConfigBranch* CreateAnalogueOutputConfig();

	// Method that creates a linearisation config hierarchy
	CConfigBranch* CreateLinearisationConfig();

	// Method that creates a General Device Info heirarchy
	CConfigBranch* CreateGeneralDeviceConfig();

	// Method that creates the groups config heirarchy
	CConfigBranch* CreateGroupsConfig();

	// Method that creates the web config heirarchy
	CConfigBranch* CreateWebConfig();

	// Method that creates the email config heirarchy
	CConfigBranch* CreateEmailConfig();

	// Method that creates the network admin config heirarchy
	CConfigBranch* CreateNetworkAdminConfig();

	// Method that creates the scheduled recording config heirarchy
	CConfigBranch* CreateRecordingSchedConfig();

	// Method that creates the recording alarms config heirarchy
	CConfigBranch* CreateRecordingAlarmsConfig();

	// Method that creates the recording pretrigger heirarchy
	CConfigBranch* CreateRecordingPreTriggerConfig();

	// Method that creates the FTP config heirarchy
	CConfigBranch* CreateFTPConfig();

	// Method that creates the SecurityOptions config heirarchy
	CConfigBranch* CreateSecurityConfig();

	// Method that creates the P2P config heirarchy
	CConfigBranch* CreateP2PConfig();

	// Method that creates the preset markers config heirarchy
	CConfigBranch* CreatePresetMarkersConfig();

	// Method that creates the reports config heirarchy
	CConfigBranch* CreateReportsConfig();

	//TimeSync...
	// Method that creates the Time Sync config heirarchy
	CConfigBranch* CreateTimeSyncConfig();

	// Method that creates the general AMS2750 config heirarchy
	CConfigBranch* CreateAMS2750GeneralConfig();

	// Method that creates the AMS2750 calibration config heirarchy
	CConfigBranch* CreateAMS2750CalibrationConfig();

	// Method that creates the Load Save Config Hierarchy
	CConfigBranch* CreateLoadSaveConfig();

	// Method that refreshes the data for a particular branch of a configuration menu, usually
	// following a change that requires the tree structure to be regenerated because it is different
	CConfigInterface* RefreshConfigTree(CConfigItem *pkModifiedItem, CLayoutItem *pkCurrLayoutItem = NULL);

	// Method that commits recorder setup changes to the CMM
	void CommitChanges();

	// Method that commits recorder setup changes to the CMM
	void DiscardChanges();

	// Method that loads a new setup
	const bool LoadConfiguration(const QString  &rstrFILE_NAME);

	// Method that saves the current setup
	T_CONFIG_RETURN_VALUE SaveConfiguration(const QString  &rstrFILE_NAME) const;

	// Method that applies any time changes to the recorder
	void UpdateTimeInformation();

	// Method that loads a new setup
	const bool EnterCalMode();

	// Method that loads the sound filenames in
	void LoadSoundFileNames();

	// Accessor for the sound filename list
	const QString  GetSoundFileNamesList();

	//TM - compiled out as not used by TTR6SETUP
#ifndef TTR6SETUP 
	// Method that sends a message to the ATE cal informing it to carry out a positive
	// calibration on the relevant channels
	const bool InitiatePositiveCalibration(const USHORT usVOLTAGE_RANGE, const USHORT usCHANNEL_MASK);

	// Method that sends a message to the ATE cal informing it to carry out a negative
	// calibration on the relevant channels
	const bool InitiateNegativeCalibration(const USHORT usVOLTAGE_RANGE, const USHORT usCHANNEL_MASK);
#endif

	// Method that sends a message to the IO scheduler informing it to carry out any processing
	// required to finish calibration
	const bool FinishCalibration();

	// Method that clears the reboot message list, usually following a load config as any changes will
	// no longer be valid
	void ClearRebootList() {
		m_kReasonsForReboot.clear();
	}

	// Method that creates the delimitted export device list based on the current recorder type
	// and other configuration settings
	static const QString  CreateExportDevList(const REFERENCE eCFG_TYPE);

	// Method that obtains an AI channel slot and board channel number
	static bool GetAnalogueChannelInfo(const USHORT usANALOGUE_INPUT_NO, USHORT &rusSlotNo, USHORT &rusBoardChanNum);

	// GENERAL DEVICE Info
	static const QString  ms_strDEVICE_DETAILS;
	static const QString  ms_strDEVICE_NAME;
	static const QString  ms_strDEVICE_DESC;
	static const QString  ms_strDEVICE_ID;

	// PENS
	// Pen key names
	static const QString  ms_strPEN_KEY;
	static const QString  ms_strENABLED_KEY;
	static const QString  ms_strMATH_TYPE_KEY;
	static const QString  ms_strMATHS_EXPRESSION_KEY;
	static const QString  ms_strEDIT_SCRIPT_KEY;
	static const QString  ms_strGROUP_KEY;
	static const QString  ms_strTAG_KEY;
	static const QString  ms_strDESC_KEY;
	static const QString  ms_strSCALE_KEY;
	static const QString  ms_strTOT_KEY;
	static const QString  ms_strALM_KEY;
	static const QString  ms_strLOG_KEY;

	// Scale key names
	static const QString  ms_strZERO_KEY;
	static const QString  ms_strSPAN_KEY;
	static const QString  ms_strUNITS_KEY;
	static const QString  ms_strMAJOR_DIVS_KEY;
	static const QString  ms_strMINOR_DIVS_KEY;
	static const QString  ms_strSTART_DECADE_KEY;
	static const QString  ms_strNUM_DECADES_KEY;
	static const QString  ms_strAUTO_DIVS_KEY;
	static const QString  ms_strLOG_SCALE_KEY;

	// Totaliser key names
	static const QString  ms_strTOT_TYPE_KEY;
	static const QString  ms_strTOT_NO_BACK_FLOW_KEY;
	static const QString  ms_strTOT_BACK_FLOW_LEVEL_KEY;
	static const QString  ms_strTOT_RESTRICT_RANGE_KEY;
	static const QString  ms_strTOT_CARRY_ON_ROLL_KEY;
	static const QString  ms_strTOT_INCLUDE_COOL_KEY;
	static const QString  ms_strTOT_ADD_TO_MSG_LIST_KEY;
	static const QString  ms_strTOT_TEMP_INPUT_UNITS_KEY;
	static const QString  ms_strTOT_TAG_KEY;
	static const QString  ms_strTOT_MIN_RANGE_KEY;
	static const QString  ms_strTOT_MAX_RANGE_KEY;
	static const QString  ms_strTOT_TIME_FACTOR_KEY;
	static const QString  ms_strTOT_UNIT_FACTOR_KEY;
	static const QString  ms_strTOT_TEMP_START_KEY;
	static const QString  ms_strTOT_TEMP_REF_KEY;
	static const QString  ms_strTOT_ZFACTOR_KEY;
	static const QString  ms_strTOT_COMP_VAL_KEY;
	static const QString  ms_strTOT_UNITS_KEY;
	static const QString  ms_strTOT_RESET16MILLION_RANGE_KEY;

	// RAV key names
	static const QString  ms_strRAV_KEY;
	static const QString  ms_strRAV_SAMPLE_INTERVAL_KEY;
	static const QString  ms_strRAV_NO_OF_SAMPLES_KEY;
	static const QString  ms_strRAV_PREFILL_KEY;

	// Alarm key names
	static const QString  ms_strPEN_ALARM_ENABLE_TYPE_KEY;
	static const QString  ms_strPEN_ALARM_TYPE_KEY;
	static const QString  ms_strPEN_ALARM_LEVEL_KEY;
	static const QString  ms_strPEN_ALARM_DEV_LEVEL_KEY;
	static const QString  ms_strPEN_ALARM_HYST_LEVEL_KEY;
	static const QString  ms_strPEN_ALARM_LATCHED_KEY;
	static const QString  ms_strPEN_ALARM_USE_HYST_KEY;
	static const QString  ms_strPEN_ALARM_USE_DAMP_KEY;
	static const QString  ms_strPEN_ALARM_CHG_LOG_KEY;
	static const QString  ms_strPEN_ALARM_MARK_CHART_KEY;
	static const QString  ms_strPEN_ALARM_AS_EVENT_KEY;
	static const QString  ms_strPEN_ALARM_DEV_PEN_NO_KEY;
	static const QString  ms_strPEN_ALARM_DIG_EN_KEY;
	static const QString  ms_strPEN_ALARM_RELAY_OUT_KEY;
	static const QString  ms_strPEN_ALARM_DAMPING_TIME_KEY;
	static const QString  ms_strPEN_ALARM_CHANGE_ALLOW_KEY;
	static const QString  ms_strPEN_ALARM_USE_REFLASH_KEY;
	static const QString  ms_strPEN_ALARM_REFLASH_TIME_KEY;
	static const QString  ms_strPEN_ALARM_SEND_EMAIL_KEY;
	static const QString  ms_strPEN_ALARM_EMAIL_RECIPIENTS_KEY;
	static const QString  ms_strPEN_ALARM_RATE_OF_CHANGE_TIME_KEY;

	// Logging key names
	static const QString  ms_strPEN_LOG_LOG_TYPE_KEY;
	static const QString  ms_strPEN_LOG_STYLE_KEY;
	static const QString  ms_strPEN_LOG_RATE_UNITS_KEY;
	static const QString  ms_strPEN_LOG_RATE_KEY;
	static const QString  ms_strPEN_LOG_ALARM_RATE_UNITS_KEY;
	static const QString  ms_strPEN_LOG_ALARM_RATE_KEY;
	static const QString  ms_strPEN_LOG_PRETRIGGER_KEY;
	static const QString  ms_strPEN_LOG_ALIGN_KEY;
	static const QString  ms_strPEN_LOG_USE_FUZZY_AUTO_FIT_KEY;
	static const QString  ms_strPEN_LOG_FBAND1_KEY;
	static const QString  ms_strPEN_LOG_USE_FBAND2_KEY;
	static const QString  ms_strPEN_LOG_FBAND2_KEY;

	// Logging key list
	static QString  ms_strPenLogRateUnitsList;
	static QString  ms_strPenLogRateShortUnitsList;
	static QString  ms_strPenLogRateMsList;

	// ANALOGUE INPUTS
	// Analogue Input Keys
	static const QString  ms_strANALOGUE_IN_KEY;
	static const QString  ms_strANALOGUE_IN_TYPE_KEY;
	static const QString  ms_strANALOGUE_IN_SQRT_EXTRACT_KEY;
	static const QString  ms_strANALOGUE_IN_ACQ_RATE_KEY;
	static const QString  ms_strANALOGUE_IN_ENG_ZERO_KEY;
	static const QString  ms_strANALOGUE_IN_ENG_SPAN_KEY;
	static const QString  ms_strANALOGUE_IN_LABEL_KEY;
	static const QString  ms_strANALOGUE_IN_TIED_TO_KEY;
	static const QString  ms_strANALOGUE_IN_CALIBRATION_KEY;
	static const QString  ms_strANALOGUE_IN_DAMP_LEVEL_KEY;

	// Calibration Keys
	static const QString  ms_strANALOGUE_IN_CALIB_TYPE_KEY;
	static const QString  ms_strANALOGUE_IN_CALIB_SINGLE_POINT_KEY;
	static const QString  ms_strANALOGUE_IN_CALIB_DUAL_RANGE_KEY;
	static const QString  ms_strANALOGUE_IN_CALIB_MULTI_POINT_TABLE_KEY;
	static const QString  ms_strANALOGUE_IN_CALIB_MULTI_POINT_LAST_CAL_KEY;
	static const QString  ms_strANALOGUE_IN_CALIB_DUAL_PT1_ENG_KEY;
	static const QString  ms_strANALOGUE_IN_CALIB_DUAL_PT1_ADJ_KEY;
	static const QString  ms_strANALOGUE_IN_CALIB_DUAL_PT2_ENG_KEY;
	static const QString  ms_strANALOGUE_IN_CALIB_DUAL_PT2_ADJ_KEY;

	// Linear Channel Keys
	static const QString  ms_strANALOGUE_IN_LIN_MODE_KEY;
	static const QString  ms_strANALOGUE_IN_LIN_RANGE_PRESET_KEY;
	static const QString  ms_strANALOGUE_IN_LIN_UNITS_KEY;
	static const QString  ms_strANALOGUE_IN_LIN_USER_LOW_LIMIT_KEY;
	static const QString  ms_strANALOGUE_IN_LIN_USER_HIGH_LIM_KEY;
	static const QString  ms_strANALOGUE_IN_LIN_VOLTAGE_RANGE_KEY;
	static const QString  ms_strANALOGUE_IN_LINEARISATION_TABLE_KEY;

	// Linear Channel List
	static const QString  ms_strANALOGUE_IN_LIN_VOLTAGE_RANGE_LIST;

	// TC Channel Keys
	static const QString  ms_strANALOGUE_IN_TC_UP_SCALE_BURN_OUT_KEY;
	static const QString  ms_strANALOGUE_IN_TC_ACTIVE_BURN_OUT_KEY;
	static const QString  ms_strANALOGUE_IN_TC_TYPE_KEY;
	static const QString  ms_strANALOGUE_IN_TC_CJC_KEY;
	static const QString  ms_strANALOGUE_IN_TC_CJC_AIN_KEY;
	static const QString  ms_strANALOGUE_IN_TC_CJC_EXT_SPEC_KEY;

	// RT Channel Keys
	static const QString  ms_strANALOGUE_IN_RT_TYPE_KEY;

	// AMS2750 Sensor Keys
	static const QString  ms_strANALOGUE_IN_AMS2750_KEY;
	static const QString  ms_strANALOGUE_IN_AMS2750_TUS_TC_KEY;
	static const QString  ms_strANALOGUE_IN_AMS2750_CONTROL_TC_KEY;
	static const QString  ms_strANALOGUE_IN_AMS2750_USAGE_TRACK_KEY;
	static const QString  ms_strANALOGUE_IN_AMS2750_SERIAL_NO_KEY;
	static const QString  ms_strANALOGUE_IN_AMS2750_TC_POS_KEY;
	static const QString  ms_strANALOGUE_IN_AMS2750_TC_MANF_KEY;
	static const QString  ms_strANALOGUE_IN_AMS2750_TC_TYPE_KEY;
	static const QString  ms_strANALOGUE_IN_AMS2750_LOAD_TC_KEY;
	static const QString  ms_strANALOGUE_IN_AMS2750_TC_RENEW_DATE_KEY;
	static const QString  ms_strANALOGUE_IN_AMS2750_CAL_TRACK_KEY;
	static const QString  ms_strANALOGUE_IN_AMS2750_TC_NEXT_CALIB_DATE_KEY;
	static const QString  ms_strANALOGUE_IN_AMS2750_TC_SENSOR_CAL_TABLE_KEY;
	static const QString  ms_strANALOGUE_IN_AMS2750_TC_CERT_NO_KEY;

	// AMS2750 Sensor Lists
	static QString  ms_strAnalogueInAMS2750SensorTypeListKey;

	// Demo Channel Key Names
	static const QString  ms_strDEMO_CHAN_KEY;
	static const QString  ms_strDEMO_CHAN_WAVE_TYPE_KEY;
	static const QString  ms_strDEMO_CHAN_WAVE_DUR_KEY;
	static const QString  ms_strDEMO_CHAN_NOISE_KEY;

	// Events Properties
	static const QString  ms_strEVENTS_KEY;
	static const QString  ms_strEVENTS_ENABLED_KEY;
	static const QString  ms_strEVENTS_NAME_KEY;
	static const QString  ms_strEVENTS_CAUSES_KEY;
	static const QString  ms_strEVENTS_IND_CAUSE_KEY;
	static const QString  ms_strEVENTS_EFFECTS_KEY;
	static const QString  ms_strEVENTS_IND_EFFECT_KEY;

	// Event Cause Properties
	static const QString  ms_strEVENTS_CAUSE_ENABLED_KEY;
	static const QString  ms_strEVENTS_CAUSE_TYPE_KEY;
	static const QString  ms_strEVENTS_CAUSE_SUBTYPE_KEY;
	static const QString  ms_strEVENTS_CAUSE_DATA_KEY;
	static const QString  ms_strEVENTS_CAUSE_ALARM_DATA_KEY;
	static const QString  ms_strEVENTS_CAUSE_SCHED_DATE_TIME_KEY;
	static const QString  ms_strEVENTS_CAUSE_SCHED_PERIOD_KEY;
	static const QString  ms_strEVENTS_CAUSE_SCHED_ALIGN_KEY;
	static const QString  ms_strEVENTS_CAUSE_SCHED_DOW_KEY;
	static const QString  ms_strEVENTS_CAUSE_SCHED_COUNT_KEY;
	static const QString  ms_strEVENTS_CAUSE_COUNTER_TRIGGER_KEY;

	// Event Cause Lists
	static QString  ms_strEventsCauseTypesList;
	static QString  ms_strEventsCauseAlarmSubTypesList;
	static QString  ms_strEventsCauseTotaliserSubTypesList;
	static QString  ms_strEventsCauseDigInputsTypesList;
	static QString  ms_strEventsCauseSchedEventTypesList;
	static QString  ms_strEventsCauseSchedEventAlignList;
	static QString  ms_strEventsCauseSystemSubTypesList;
	static QString  ms_strEventsCauseUserActionSubTypesList;
	static QString  ms_strEventsCauseUserActionSubTypesListQx;
	static QString  ms_strEventsCauseUserActionSubTypesListEz;
	static QString  ms_strEventsCauseBatchSubTypesList;
	static QString  ms_strEventsCauseTUSSubTypesList;
	static QString  ms_strEventsCauseAMS2750TimersSubTypesList;
	static QString  ms_strEventsCauseAMS2750TimersAlertTypeList;

	// Event Effect Properties
	static const QString  ms_strEVENTS_EFFECT_ENABLED_KEY;
	static const QString  ms_strEVENTS_EFFECT_TYPE_KEY;
	static const QString  ms_strEVENTS_EFFECT_SUBTYPE_KEY;
	static const QString  ms_strEVENTS_EFFECT_DATA_KEY;
	static const QString  ms_strEVENTS_EFFECT_ALARM_DATA_KEY;
	static const QString  ms_strEVENTS_EFFECT_MARK_CHART_KEY;
	static const QString  ms_strEVENTS_EFFECT_DISPLAY_EVENT_KEY;
	static const QString  ms_strEVENTS_EFFECT_SCREEN_NAME_KEY;
	static const QString  ms_strEVENTS_EFFECT_SCREEN_BACKLIGHT_ON_OFF_KEY;
	static const QString  ms_strEVENTS_EFFECT_EMAIL_RECIPIENTS_KEY;
	static const QString  ms_strEVENTS_EFFECT_EMAIL_EMBED_SCREENSHOT_KEY;
	static const QString  ms_strEVENTS_EFFECT_EMAIL_MESSAGE_KEY;
	static const QString  ms_strEVENTS_EFFECT_COUNTER_RESET_OR_INC_KEY;
	static const QString  ms_strEVENTS_EFFECT_COUNTER_RESET_KEY;
	static const QString  ms_strEVENTS_EFFECT_COUNTER_INCREMENT_KEY;
	static const QString  ms_strEVENTS_EFFECT_DELAYED_EVENT_DELAY_TIME_KEY;
	static const QString  ms_strEVENTS_EFFECT_SOUND_PLAY_MODE_KEY;
	static const QString  ms_strEVENTS_EFFECT_MARKER_PRESET_SEL_KEY;
	static const QString  ms_strEVENTS_EFFECT_PEN_SEL_TYPE_KEY;
	static const QString  ms_strEVENTS_EFFECT_GROUP_SEL_KEY;
	static const QString  ms_strEVENTS_EFFECT_REPORT_SEL_KEY;
	static const QString  ms_strEVENTS_EFFECT_CLEAR_MSG_SEL_KEY;
	static const QString  ms_strEVENTS_EFFECT_PRINT_SCREEN_EXTERNAL_MEDIA_KEY;

	// Event Effects Lists
	static QString  ms_strEventsEffectsTypesList;
	static QString  ms_strEventsEffectsLoggingSubTypesList;
	static QString  ms_strEventsEffectsTotaliserSubTypesList;
	static QString  ms_strEventsEffectsDigOutputsSubTypesList;
	static QString  ms_strEventsEffectsEmailSubTypesList;
	static QString  ms_strEventsEffectsScreenChangeScreenList;
	static QString  ms_strEventsEffectsCountersSubTypesList;
	static QString  ms_strEventsEffectsCountersResetOrIncList;
	static QString  ms_strEventsEffectsChartControlSubTypeList;
	static QString  ms_strEventsEffectsTimersSubTypeList;
	static QString  ms_strEventsEffectsSoundSubTypeList;
	static QString  ms_strEventsEffectsSoundPlayModeList;
	static QString  ms_strEventsEffectsMarkerModeList;
	static QString  ms_strEventsEffectsMarkerPresetsList;
	static QString  ms_strEventsEffectsPenSelTypesList;
	static QString  ms_strEventsEffectsBatchSubTypeList;
	static QString  ms_strEventsEffectsAlarmSelTypesList;
	static QString  ms_strEventsEffectsChartControlSelTypesList;
	static QString  ms_strEventsEffectsReportNamesList;
	static QString  ms_strEventsEffectsPrintScreenSubTypeList;
	static QString  ms_strEventsEffectsPrintScreenExternalMediaList;
	static QString  ms_strEventsEffectsScreenSubTypeList;
	static QString  ms_strEventsEffectsScreenBacklightOnOffList;
	static QString  ms_strEventsEffectsMsgTypeList;

	// E528446
	static QString  ms_strEventsEffectChartspeedSubTypesList;
	//

	// Sounds List
	static QString  ms_strSoundList;

	// Counter Properties
	static const QString  ms_strCOUNTERS_KEY;
	static const QString  ms_strCOUNTERS_ENABLED_KEY;
	static const QString  ms_strCOUNTERS_NAME_KEY;
	static const QString  ms_strCOUNTERS_START_AT_KEY;
	static const QString  ms_strCOUNTERS_ROLLOVER_AT_KEY;

	// Screen Saver Properties
	static const QString  ms_strSCREEN_SAVER_KEY;
	static const QString  ms_strSCREEN_SAVER_ENABLED_KEY;
	static const QString  ms_strSCREEN_SAVER_MODE_KEY;
	static const QString  ms_strSCREEN_SAVER_TYPE_KEY;
	static const QString  ms_strSCREEN_SAVER_DIM_KEY;
	static const QString  ms_strSCREEN_SAVER_TIMEOUT_KEY;
	static const QString  ms_strSCREEN_SAVER_DIM_BRIGHT_KEY;
	static const QString  ms_strSCREEN_SAVER_MODE_TIMES_KEY;

	// Screen Chart Properties
	static const QString  ms_strSCREEN_CHART_KEY;
	static const QString  ms_strSCREEN_CHART_FAST_SPEED_KEY;
	static const QString  ms_strSCREEN_CHART_MED_SPEED_KEY;
	static const QString  ms_strSCREEN_CHART_SLOW_SPEED_KEY;
	static const QString  ms_strSCREEN_CIRC_CHART_FAST_SPEED_KEY;
	static const QString  ms_strSCREEN_CIRC_CHART_MED_SPEED_KEY;
	static const QString  ms_strSCREEN_CIRC_CHART_SLOW_SPEED_KEY;
	static const QString  ms_strSCREEN_CIRC_CHART_HOUR_ALIGNMENT_KEY;
	static const QString  ms_strSCREEN_CIRC_CHART_DAY_ALIGNMENT_KEY;
	static const QString  ms_strSCREEN_CHART_BIAS_KEY;

	// Screen Chart Lists
	static QString  ms_strScreenCircChartDayAlignmentList;

	// Screen Chart List
	static QString  ms_strScreenChartSpeedFastList;
	static QString  ms_strScreenChartSpeedMedList;
	static QString  ms_strScreenChartSpeedSlowList;
	static QString  ms_strScreenCircChartSpeedFastList;
	static QString  ms_strScreenCircChartSpeedMedList;
	static QString  ms_strScreenCircChartSpeedSlowList;

	// Screen Tabular Display Properties
	static const QString  ms_strSCREEN_TAB_DISP_KEY;
	static const QString  ms_strSCREEN_TAB_DISP_UPDATE_METHOD_KEY;
	static const QString  ms_strSCREEN_TAB_DISP_UPDATE_PERIOD_KEY;
	static const QString  ms_strSCREEN_TAB_DISP_ALIGN_KEY;

	// Screen Tabular Display List
	static QString  ms_strScreenTabDispUpdateMethodList;

	// Printer Properties
	static const QString  ms_strPRINTER_KEY;
	static const QString  ms_strPRINTER_ALLOW_PRINT_KEY;
	static const QString  ms_strPRINTER_LETTER_KEY;
	static const QString  ms_strPRINTER_PORTRAIT_KEY;
	static const QString  ms_strPRINTER_DEVICE_NAME_KEY;
	static const QString  ms_strPRINTER_COLOUR_PRINTER_KEY;
	static const QString  ms_strPRINTER_PCL_LANGUAGE_KEY;
	static const QString  ms_strPRINTER_PORT_KEY;
	static const QString  ms_strPRINTER_FIT_TO_PAGE_KEY;

	// Printer List
	static QString  ms_strPrinterSizeList;
	static QString  ms_strPrinterOrientationList;
	static QString  ms_strPrinterPclLanguageList;
	static QString  ms_strPrinterPortList;

	// Batch Properties
	static const QString  ms_strBATCH_KEY;
	static const QString  ms_strBATCH_GENERAL_KEY;
	static const QString  ms_strBATCH_GENERAL_PAUSE_CHART_KEY;
	static const QString  ms_strBATCH_GENERAL_START_LOGGING_KEY;
	static const QString  ms_strBATCH_GENERAL_STOP_LOGGING_KEY;
	static const QString  ms_strBATCH_GENERAL_DIRECT_INPUT_KEY;
	static const QString  ms_strBATCH_GENERAL_USE_USER_ID_KEY;
	static const QString  ms_strBATCH_GENERAL_USE_DESC_KEY;
	static const QString  ms_strBATCH_GENERAL_USE_COMMENT_KEY;
	static const QString  ms_strBATCH_GENERAL_USE_LOT_KEY;

	// Batch Name Branch Properties
	static const QString  ms_strBATCH_GENERAL_NAME_FIELD_KEY;
	static const QString  ms_strBATCH_GENERAL_NAME_FIELD_NAME_KEY;
	static const QString  ms_strBATCH_GENERAL_NAME_FIELD_NAME_LIST_KEY;

	// Batch User ID Branch Properties
	static const QString  ms_strBATCH_GENERAL_USER_ID_FIELD_KEY;
	static const QString  ms_strBATCH_GENERAL_USER_ID_FIELD_NAME_KEY;
	static const QString  ms_strBATCH_GENERAL_USER_ID_FIELD_USER_LIST_KEY;

	// Batch Description Branch Properties
	static const QString  ms_strBATCH_GENERAL_DESC_FIELD_KEY;
	static const QString  ms_strBATCH_GENERAL_DESC_FIELD_NAME_KEY;
	static const QString  ms_strBATCH_GENERAL_DESC_FIELD_DESC_LIST_KEY;

	// Batch Lot Number Branch Properties
	static const QString  ms_strBATCH_GENERAL_LOT_FIELD_KEY;
	static const QString  ms_strBATCH_GENERAL_LOT_FIELD_NAME_KEY;
	static const QString  ms_strBATCH_GENERAL_LOT_FIELD_LOT_NO_LIST_KEY;

	// Batch Comment Branch Properties
	static const QString  ms_strBATCH_GENERAL_COMMENT_FIELD_KEY;
	static const QString  ms_strBATCH_GENERAL_COMMENT_FIELD_NAME_KEY;
	static const QString  ms_strBATCH_GENERAL_COMMENT_FIELD_COMMENT_LIST_KEY;
	static const QString  ms_strBATCH_GENERAL_SSB_FIELD_KEY;

	// Group Centric Batch Fields
	static const QString  ms_strBATCH_GROUP_KEY;
	static const QString  ms_strBATCH_GROUP_CTR_START_KEY;
	static const QString  ms_strBATCH_GROUP_CTR_INC_KEY;
	static const QString  ms_strBATCH_GROUP_CTR_ROLLOVER_KEY;
	static const QString  ms_strBATCH_GROUP_AUTO_POP_KEY;
	static const QString  ms_strBATCH_GROUP_AUTO_POP_NAME_KEY;
	static const QString  ms_strBATCH_GROUP_ZERO_PAD_KEY;
	static const QString  ms_strBATCH_GROUP_SHOW_NAME_LIST_KEY;
	static const QString  ms_strBATCH_GROUP_SHOW_USER_LIST_KEY;
	static const QString  ms_strBATCH_GROUP_SHOW_LOT_NO_LIST_KEY;
	static const QString  ms_strBATCH_GROUP_SHOW_DESC_LIST_KEY;
	static const QString  ms_strBATCH_GROUP_SHOW_COMM_LIST_KEY;

	// Error Control Properties
	static const QString  ms_strERROR_CONTROL_KEY;
	static const QString  ms_strERROR_CONTROL_ERRORS_KEY;
	static const QString  ms_strERROR_CONTROL_ERRORS_CABLE_UNPLUGGED_KEY;
	static const QString  ms_strERROR_CONTROL_ERRORS_INT_MEM_LO_KEY;
	static const QString  ms_strERROR_CONTROL_ERRORS_EXP_MEM_LO_KEY;
	static const QString  ms_strERROR_CONTROL_ERRORS_EXP_MEDIA_MISSING_KEY;
	static const QString  ms_strERROR_CONTROL_ERRORS_FTP_MEM_LO_KEY;
	static const QString  ms_strERROR_CONTROL_ERRORS_CJC_MISSING_KEY;
	static const QString  ms_strERROR_CONTROL_ERRORS_BURNOUT_KEY;
	static const QString  ms_strERROR_CONTROL_BORDER_COL_KEY;
	static const QString  ms_strERROR_CONTROL_BKG_COL_KEY;
	static const QString  ms_strERROR_CONTROL_REFLASH_EN_KEY;
	static const QString  ms_strERROR_CONTROL_REFLASH_TIME_KEY;
	static const QString  ms_strERROR_CONTROL_AUTO_CLEAR_KEY;

	// Localisation Properties
	static const QString  ms_strLOCAL_KEY;
	static const QString  ms_strLOCAL_LANG_KEY;
	static const QString  ms_strLOCAL_TEMP_FORMAT_KEY;
	static const QString  ms_strLOCAL_TIME_ZONE_KEY;
	static const QString  ms_strLOCAL_MAINS_FREQ_KEY;
	static const QString  ms_strLOCAL_HELP_LANG_KEY;
	static const QString  ms_strLOCAL_TIME_DAYLIGHT_SAVING_KEY;

	// Credits Key Names
	static const QString  ms_strCREDITS_KEY;
	static const QString  ms_strCREDITS_OPT_KEY;
	static const QString  ms_strCREDITS_OPT_MATH_TYPE_KEY;
	static const QString  ms_strCREDITS_OPT_EVENTS_KEY;
	static const QString  ms_strCREDITS_OPT_FAST_SCAN_KEY;
	static const QString  ms_strCREDITS_OPT_TOTALS_KEY;
	static const QString  ms_strCREDITS_OPT_CUST_SCRN_KEY;
	static const QString  ms_strCREDITS_OPT_REPORTS_KEY;
	static const QString  ms_strCREDITS_OPT_NADCAP_RECORDER_KEY;
	static const QString  ms_strCREDITS_OPT_TUS_MODE_KEY;
	static const QString  ms_strCREDITS_OPT_MAINT_KEY;
	static const QString  ms_strCREDITS_OPT_BATCH_KEY;
	static const QString  ms_strCREDITS_OPT_COUNTERS_KEY;
	static const QString  ms_strCREDITS_OPT_MODBUS_MASTER_KEY;
	static const QString  ms_strCREDITS_OPT_REMOTE_VIEWER_KEY;
	static const QString  ms_strCREDITS_OPT_EMAIL_KEY;
	static const QString  ms_strCREDITS_OPT_PRINTER_KEY;
	static const QString  ms_strCREDITS_OPT_OPC_TITLE_KEY;
	static const QString  ms_strCREDITS_OPT_EXTSD_TITLE_KEY;
	static const QString  ms_strCREDITS_OPT_SECUREWSD_TITLE_KEY;
	static const QString  ms_strCREDITS_OPT_PWD_NET_SYNC_KEY;
	static const QString  ms_strCREDITS_OPT_EXTRA_PENS_KEY;
	static const QString  ms_strCREDITS_CREDITS_KEY;
	static const QString  ms_strCREDITS_SERIAL_NO_KEY;
	static const QString  ms_strCREDITS_OPTIONS_CODE_KEY;
	static const QString  ms_strCREDITS_OPT_RTDATABUS_TITLE_KEY;
	static const QString  ms_strCREDITS_OPT_HWLOCK_TITLE_KEY;
	static const QString  ms_strCREDITS_OPT_OPCUASERVER_TITLE_KEY;

	// Demo Key Names
	static const QString  ms_strDEMO_BOARDS_KEY;
	static const QString  ms_strDEMO_BOARDS_BOARD_KEY;

	// Production Key Names
	static const QString  ms_strPRODUCTION_KEY;
	static const QString  ms_strPRODUCTION_SERIAL_NO_KEY;

	// TCP/IP Keys
	static const QString  ms_strTCPIP_KEY;
	static const QString  ms_strTCPIP_USE_STATIC_IP_ADDR_KEY;
	static const QString  ms_strTCPIP_STATIC_IP_ADDR_KEY;
	static const QString  ms_strTCPIP_SUB_NET_MASK_KEY;
	static const QString  ms_strTCPIP_DEF_GATEWAY_KEY;
	static const QString  ms_strTCPIP_DNS_WINS_KEY;
	static const QString  ms_strTCPIP_QAbstractSocketS_KEY;
	static const QString  ms_strTCPIP_ENABLE_DNS_KEY;
	static const QString  ms_strTCPIP_DNS_PRI_ADDR_KEY;
	static const QString  ms_strTCPIP_DNS_SEC_ADDR_KEY;
	static const QString  ms_strTCPIP_WINS_PRI_ADDR_KEY;
	static const QString  ms_strTCPIP_WINS_SEC_ADDR_KEY;
	static const QString  ms_strTCPIP_ENABLE_WINS_KEY;
	static const QString  ms_strTCPIP_ENABLE_MDNS_KEY;

	//SecurityOptions Keys
	static const QString  ms_strSecurity_KEY;
	static const QString  ms_strSecurity_USE_GLOBAL_CA_KEY;
	static const QString  ms_strSecurity_USE_TLS_PROTOCOL_KEY;
	static const QString  ms_str_RDT_KEY;
	static const QString  ms_strSecurity_PfxPassword;

	// MODBUS Comms Keys
	static const QString  ms_strMODBUS_COMMS_KEY;
	static const QString  ms_strMODBUS_COMMS_BAUD_RATE_KEY;
	static const QString  ms_strMODBUS_COMMS_BYTE_OPT_KEY;
	static const QString  ms_strMODBUS_COMMS_LINE_TURN_AROUND_KEY;
	static const QString  ms_strMODBUS_COMMS_REPLY_DELAY_KEY;

	// MODBUS Slave Keys
	static const QString  ms_strMODBUS_SLAVE_KEY;
	static const QString  ms_strMODBUS_SLAVE_PORT_KEY;
	static const QString  ms_strMODBUS_SLAVE_PROTOCOL_KEY;
	static const QString  ms_strMODBUS_SLAVE_ADDR_KEY;
	static const QString  ms_strMODBUS_SLAVE_ENABLED_KEY;

	// MODBUS Master Keys
	static const QString  ms_strMODBUS_MASTER_KEY;
	static const QString  ms_strMODBUS_MASTER_ENABLED_KEY;
	static const QString  ms_strMODBUS_MASTER_POLL_RATE_KEY;
	static const QString  ms_strMODBUS_MASTER_LEGACY_ETHERNET_KEY;
	static const QString  ms_strMODBUS_MASTER_SLAVE_KEY;
	static const QString  ms_strMODBUS_MASTER_SLAVE_ID_KEYEY
	static const QString  ms_strMODBUS_MASTER_SLAVE_NETWORK_NAME_KEY;
	static const QString  ms_strMODBUS_MASTER_SLAVE_PORT_KEY;
	static const QString  ms_strMODBUS_MASTER_SLAVE_PROTOCOL_KEY;
	static const QString  ms_strMODBUS_MASTER_SLAVE_TX_ITEM_KEY;
	static const QString  ms_strMODBUS_MASTER_SLAVE_TX_ITEM_ENABLE_KEY;
	static const QString  ms_strMODBUS_MASTER_SLAVE_TX_ITEM_DIR_KEY;
	static const QString  ms_strMODBUS_MASTER_SLAVE_TX_ITEM_MAP_KEY;
	static const QString  ms_strMODBUS_MASTER_SLAVE_TX_DATA_TYPE_KEY;
	static const QString  ms_strMODBUS_MASTER_SLAVE_TX_DATA_ITEM_KEY;
	static const QString  ms_strMODBUS_MASTER_SLAVE_TX_ITEM_START_KEY;
	static const QString  ms_strMODBUS_MASTER_SLAVE_TX_DATA_ITEM_START_KEY;
	static const QString  ms_strMODBUS_MASTER_SLAVE_TX_ITEM_NO_OF_ITEMS_KEY;

	// Modbus Master Lists
	static QString  ms_strModbusMasterSlaveMapList;
	static QString  ms_strModbusMasterSlaveDirList;
	static QString  ms_strModbusMasterSlaveInsDataTypeList;
	static QString  ms_strModbusMasterSlaveOutsDataTypeList;

	// SNTP Keys
	static const QString  ms_strSNTP_KEY;
	static const QString  ms_strSNTP_CLIENT_ENABLE_KEY;
	static const QString  ms_strSNTP_SERVER_ENABLE_KEY;
	static const QString  ms_strSNTP_SERVER_NAME_KEY;
	static const QString  ms_strSNTP_CLIENT_UPDATE_PER_KEY;
	static const QString  ms_strSNTP_CLIENT_UPDATE_THRESH_KEY;

	// Socket Keys
	static const QString  ms_strTCPIP_SOCK_HTTP_KEY;
	static const QString  ms_strTCPIP_SOCK_FTP_DATA_KEY;
	static const QString  ms_strTCPIP_SOCK_FTP_CONTROL_KEY;
	static const QString  ms_strTCPIP_SOCK_MODBUS_KEY;
	static const QString  ms_strTCPIP_SOCK_TRENDBUS_KEY;

	// Email Keys
	static const QString  ms_strEMAIL_KEY;
	static const QString  ms_strEMAIL_SERVER_KEY;
	static const QString  ms_strEMAIL_PORT_KEY;
	static const QString  ms_strEMAIL_SECURE_MODE_KEY;
	static const QString  ms_strEMAIL_STARTTLS_KEY;
	static const QString  ms_strEMAIL_REQUIRES_AUTH_KEY;
	static const QString  ms_strEMAIL_USERNAME_KEY;
	static const QString  ms_strEMAIL_PASSWORD_KEY;
	static const QString  ms_strEMAIL_USER_ADDRESS_KEY;
	static const QString  ms_strEMAIL_ADDRESSES_KEY;
	static const QString  ms_strEMAIL_ADDRESS_KEY;
	static const QString  ms_strEMAIL_TEMPLATES_KEY;
	static const QString  ms_strEMAIL_IND_TEMPLATE_KEY;
	static const QString  ms_strEMAIL_SUBJECT_KEY;
	static const QString  ms_strEMAIL_MESSAGE_BODY_KEY;

	// Email Lists
	static QString  ms_strEventsEmailTemplateList;

	// Network Admin Keys
	static const QString  ms_strNETWORK_ADMIN_KEY;
	static const QString  ms_strNETWORK_ADMIN_USERNAME_KEY;
	static const QString  ms_strNETWORK_ADMIN_PASSWORD_KEY;
	static const QString  ms_strNETWORK_ADMIN_DOMAIN_KEY;
	static const QString  ms_strNETWORK_ADMIN_USE_SHARE_KEY;
	static const QString  ms_strNETWORK_ADMIN_SHARE_PATH_KEY;

	// Digital IO Keys
	static const QString  ms_strDIGIO_KEY;
	static const QString  ms_strDIGIO_IO_TYPE_KEY;
	static const QString  ms_strDIGIO_LABEL_KEY;
	static const QString  ms_strDIGIO_ACTIVE_LABEL_KEY;
	static const QString  ms_strDIGIO_INACTIVE_LABEL_KEY;
	static const QString  ms_strDIGIO_OUT_LATCHED_KEY;
	static const QString  ms_strDIGIO_OUT_FAILSAFE_KEY;
	static const QString  ms_strDIGIO_OUT_DURATION_KEY;
	static const QString  ms_strDIGIO_IO_NOTIFYTYPE_KEY;

	// Pulse In Keys
	static const QString  ms_strPULSE_IN_KEY;
	static const QString  ms_strPULSE_IN_MEASUREMENT_UPDATE_KEY;
	static const QString  ms_strPULSE_IN_LABEL_KEY;

	// Analogue Output Keys
	static const QString  ms_strANALOGUE_OUTPUT_KEY;
	static const QString  ms_strANALOGUE_OUTPUT_ALLOW_OVERRANGE_KEY;
	static const QString  ms_strANALOGUE_OUTPUT_RETRANS_PEN_KEY;
	static const QString  ms_strANALOGUE_OUTPUT_CURRENT_KEY;
	static const QString  ms_strANALOGUE_OUTPUT_LABEL_KEY;

	// Analogue Output List Names
	static QString  ms_strAnalogueOutputCurrentList;

	// Linearisation Keys
	const static QString  ms_strLINEARISATION_KEY;
	const static QString  ms_strLINEARISATION_TABLE_KEY;
	const static QString  ms_strLINEARISATION_TABLE_NAME_KEY;
	const static QString  ms_strLINEARISATION_TABLE_VALUES_KEY;

	// Group Keys
	static const QString  ms_strGROUPS_KEY;
	static const QString  ms_strGROUPS_GROUP_KEY;

	// Web Keys
	static const QString  ms_strWEB_KEY;

	// Scheduled Recording Keys
	static const QString  ms_strRECORDING_SCHED_KEY;
	static const QString  ms_strRECORDING_SCHED_DEVICE_KEY;
	static const QString  ms_strRECORDING_SCHED_TIME_KEY;
	static const QString  ms_strRECORDING_SCHED_LOG_MESSAGE_KEY;
	static const QString  ms_strRECORDING_SCHED_MARK_CHART_KEY;

	// Scheduled Recording List Keys
	static QString  ms_strRecordingSchedTimeList;
	static QString  ms_strRecordingSchedDeviceList;

	// Recording Alarm Keys
	static const QString  ms_strRECORDING_ALM_KEY;
	static const QString  ms_strRECORDING_ALM_INT_MEM_KEY;
	static const QString  ms_strRECORDING_ALM_EXP_MEDIA_KEY;
	static const QString  ms_strRECORDING_ALM_FTP_MEM_KEY;

	// Recording Pre-Trigger Keys
	static const QString  ms_strRECORDING_PRETRIGGER_KEY;
	static const QString  ms_strRECORDING_PRETRIGGER_TIME_KEY;
	static const QString  ms_strRECORDING_POSTTRIGGER_TIME_KEY;

	// Recording Export Keys
	static const QString  ms_strRECORDING_EXPORT_KEY;

	// FTP Keys
	static const QString  ms_strFTP_KEY;
	static const QString  ms_strSFT_KEY;
	static const QString  ms_strFTP_ALLOW_UPLOAD_KEY;
	static const QString  ms_strFTP_ALLOW_DOWNLOAD_KEY;
	static const QString  ms_strFTP_LOG_MESSAGE_KEY;
	static const QString  ms_strFTP_MARK_CHART_KEY;

	// OPC UA Keys
	static const QString  ms_strOPCUA_KEY;
	static const QString  ms_strOPCUA_PORT_KEY;

	// P2P Keys
	static const QString  ms_strP2P_KEY;
	static const QString  ms_strP2P_TCP_PORT_KEY;
	static const QString  ms_strP2P_UDP_PORT_KEY;
	static const QString  ms_strP2P_SET_NO_KEY;

	/// P2P Lists
	static QString  ms_strP2PSetNumbersList;

	// Preset Marker Keys
	static const QString  ms_strPRESET_MARKERS_KEY;
	static const QString  ms_strPRESET_MARKERS_MARKER_KEY;

	// Report Properties
	static const QString  ms_strREPORT_IND_KEY;
	static const QString  ms_strREPORT_IND_TYPE_KEY;
	static const QString  ms_strREPORT_IND_TRIGGER_KEY;
	static const QString  ms_strREPORT_IND_STYLE_KEY;
	static const QString  ms_strREPORT_IND_PEN_SEL_TYPE_KEY;
	static const QString  ms_strREPORT_IND_INC_CURR_PEN_KEY;
	static const QString  ms_strREPORT_IND_INC_MAX_MIN_KEY;
	static const QString  ms_strREPORT_IND_INC_AVERAGE_KEY;
	static const QString  ms_strREPORT_IND_INC_TOTALS_KEY;
	static const QString  ms_strREPORT_IND_INC_MESSAGE_KEY;
	static const QString  ms_strREPORT_IND_MSG_TYPES_KEY;
	static const QString  ms_strREPORT_IND_INC_CTR_KEY;
	static const QString  ms_strREPORT_IND_INC_DIG_IN_KEY;
	static const QString  ms_strREPORT_IND_INC_DIG_OUT_KEY;
	static const QString  ms_strREPORT_IND_GROUP_KEY;
	static const QString  ms_strREPORT_IND_EMAIL_KEY;
	static const QString  ms_strREPORT_IND_EXPORT_DEV_KEY;
	static const QString  ms_strREPORT_IND_PRINT_KEY;
	static const QString  ms_strREPORT_IND_PEN_PKR_KEY;
	static const QString  ms_strREPORT_IND_PEN_TOTALS_PKR_KEY;
	static const QString  ms_strREPORT_IND_TAG_KEY;
	static const QString  ms_strREPORT_IND_SCHEDULE_KEY;
	static const QString  ms_strREPORT_IND_SCHEDULE_SUB_TYPE_KEY;
	static const QString  ms_strREPORT_IND_EMAIL_RECIP_KEY;
	static const QString  ms_strREPORT_IND_FOOTER_KEY;

	//TimeSync... Properties
	static const QString  ms_strTIMESYNC_KEY;
	static const QString  ms_strTIMESYNC_ENABLED_KEY;
	static const QString  ms_strTIMESYNC_DIPICKER_KEY;
	static const QString  ms_strTIMESYNC_TRIGGER_KEY;
	static const QString  ms_strTIMESYNC_TIMESYNC_COND_KEY;

	// AMS2750 General Properties
	static const QString  ms_strAMS2750_GEN_PROCESS_KEY;
	static const QString  ms_strAMS2750_GEN_TUS_KEY;

	// AMS2750 Furnace Properties
	static const QString  ms_strAMS2750_FURNACE_IND_KEY;
	static const QString  ms_strAMS2750_FURNACE_NAME_KEY;
	static const QString  ms_strAMS2750_FURNACE_MANFACT_KEY;
	static const QString  ms_strAMS2750_FURNACE_MODEL_NO_KEY;
	static const QString  ms_strAMS2750_FURNACE_SERIAL_NO_KEY;
	static const QString  ms_strAMS2750_FURNACE_CLASS_KEY;
	static const QString  ms_strAMS2750_FURNACE_TYPE_KEY;
	static const QString  ms_strAMS2750_FURNACE_INST_TYPE_KEY;
	static const QString  ms_strAMS2750_FURNACE_SHAPE_KEY;
	static const QString  ms_strAMS2750_FURNACE_MEAS_UNITS_KEY;
	static const QString  ms_strAMS2750_FURNACE_HEIGHT_KEY;
	static const QString  ms_strAMS2750_FURNACE_WIDTH_KEY;
	static const QString  ms_strAMS2750_FURNACE_DEPTH_KEY;
	static const QString  ms_strAMS2750_FURNACE_HIGH_USE_TEMP_KEY;
	static const QString  ms_strAMS2750_FURNACE_LOW_USE_TEMP_KEY;

	// AMS2750 Furnace Lists
	static QString  ms_strAMS2750FurnaceClassList;
	static QString  ms_strAMS2750FurnaceTypeList;
	static QString  ms_strAMS2750FurnaceInstTypeList;
	static QString  ms_strAMS2750FurnaceShapeList;
	static QString  ms_strAMS2750FurnaceMeasUnitsList;

	// AMS2750 Setpoint Properties
	static const QString  ms_strAMS2750_SETPOINT_IND_KEY;
	static const QString  ms_strAMS2750_SETPOINT_ENABLED_KEY;
	static const QString  ms_strAMS2750_SETPOINT_SOAK_LEVEL_KEY;
	static const QString  ms_strAMS2750_SETPOINT_TIME_KEY;
	static const QString  ms_strAMS2750_SETPOINT_TOL_OVERRIDE_KEY;
	static const QString  ms_strAMS2750_SETPOINT_TOLERANCE_KEY;

	// AMS2750 Stability Detection Properties
	static const QString  ms_strAMS2750_STABILITY_DETECT_KEY;
	static const QString  ms_strAMS2750_STABILITY_DETECT_TIMER_EN_KEY;
	static const QString  ms_strAMS2750_STABILITY_DETECT_TIME_KEY;
	static const QString  ms_strAMS2750_STABILITY_DETECT_AUTO_EN_KEY;
	static const QString  ms_strAMS2750_STABILITY_DETECT_DEGREES_CHANGE_KEY;

	// AMS2750 Cal Properties
	static const QString  ms_strAMS2750_CAL_KEY;
	static const QString  ms_strAMS2750_CAL_CALIBRATOR_TYPE_KEY;
	static const QString  ms_strAMS2750_CAL_CALIBRATOR_SERIAL_NO_KEY;
	static const QString  ms_strAMS2750_CAL_qDebugABLE_TO_KEY;
	static const QString  ms_strAMS2750_CAL_TECHNICIAN_ID_KEY;
	static const QString  ms_strAMS2750_CAL_PERFORMED_BY_KEY;
	static const QString  ms_strAMS2750_CAL_PERFORMED_FOR_KEY;
	static const QString  ms_strAMS2750_CAL_QUALITY_ORG_KEY;
	static const QString  ms_strAMS2750_CAL_PASSED_KEY;
	static const QString  ms_strAMS2750_CAL_TEST_DATE_KEY;
	static const QString  ms_strAMS2750_CAL_NEXT_CAL_DATE_KEY;
	static const QString  ms_strAMS2750_CAL_MULTI_POINT_TABLE_KEY;

	// TimeSync Trigger List
	static QString  ms_strTriggerList;

	// Group Name List - used for various items including events
	static QString  ms_strGroupList;

	// Load Save config Properties
	static const QString  ms_strLOADSAVECONF_KEY;
	static const QString  ms_strLOADSAVECONF_SAVE_USB1_KEY;
	static const QString  ms_strLOADSAVECONF_LOAD_USB1_KEY;
	static const QString  ms_strLOADSAVECONF_SAVE_USB2_KEY;
	static const QString  ms_strLOADSAVECONF_LOAD_USB2_KEY;
	static const QString  ms_strLOADSAVECONF_SAVE_CF_KEY;
	static const QString  ms_strLOADSAVECONF_LOAD_CF_KEY;
	static const QString  ms_strLOADSAVECONF_SAVE_NAS_KEY;
	static const QString  ms_strLOADSAVECONF_LOAD_NAS_KEY;

	//Export csv data
	static const QString  ms_strEXPORT_CSV_GROUP_KEY;

private:
	// Constructor
	CRecSetupCfgMgr(void);

	// Method that loads all the title strings and listbox items into some static string
	// objects. This is to decrease memory usage
	void LoadStrings();

	// Method that sets up the details for a particular pen
	void SetupPenDetails(CConfigBranch *pkParent, T_PPEN ptPenData);

	// Method that sets up the scale details for a particular pen
	void SetupScaleDetails(CConfigBranch *pkParent, T_PPEN ptPenData);

	// Method that sets up the totaliser details for a particular pen
	void SetupTotaliserDetails(CConfigBranch *pkParent, T_PTOTAL pTotal);

	// Method that sets up the rolling average (RAV) details for a particular pen
	void SetupRAVDetails(CConfigBranch *pkParent, T_PROLLINGAVERAGES ptRAV, const bool bENABLED);

	// Method that sets up the alarm details for a particular pen
	void SetupAlarmDetails(CConfigBranch *pkParent, T_PPEN ptPenData);

	// Method that sets up the logging details for a particular pen log
	void SetupLoggingDetails(CConfigBranch *pkParent, T_PLOGGING ptLogData, bool bPreTriggerCapable);

	// Method that refreshes the data for a pen branch of a pen configuration menu, usually
	// following a change that requires the tree structure to be regenerated because it is different
	CConfigItem* RefreshPenConfigTree(CConfigItem *pkModifiedItem, const USHORT usPEN_NO);

	// Method that gets the analogue input channel title information for the submenu button
	void CreateAnalogueInputTitle(QString  &rstrIndAnalogueKey, QString  &rstrAnalogueName, QString  &rstrSubTitle,
			const QString  &rstrANALOGUE_TITLE, T_PAICHANNEL ptAnalogueData, const USHORT usANALOGUE_INSTANCE_NO) const;

	void AddTUSSensorMenuInfo(const USHORT &usANALOGUE_INSTANCE_NO, QString  &rstrSubTitle) const;

	// Method that sets up the details for a particular analogue input
	void SetupAnalogueInputDetails(CConfigBranch *pkParent, T_PAICHANNEL ptAnalogueDataconst, const USHORT usSLOT_NO,
			const USHORT usBOARD_CHAN_NO);

	// Method that sets up the AMS2750 details for a particular analogue input
	void SetupAMS2750SensorDetails(CConfigBranch *pkParent, T_PAICHANNEL ptAnalogueData);

	// Method that sets up the details for a particular digital input/output
	void SetupDigitalIODetails(CConfigBranch *pkParent, T_PDIGCHANNEL ptDigIOData, const USHORT usSLOT_NO,
			const USHORT usBOARD_CHAN_NO, const USHORT usCHANNEL_CAPS);

	// Method that sets up the details for a particular pulse input
	void SetupPulseInDetails(CConfigBranch *pkParent, T_PPULSECHANNEL ptPulseInData, const USHORT usSLOT_NO,
			const USHORT usBOARD_CHAN_NO);

	// Method that sets up the details for a particular analogue output
	void SetupAnalogueOutDetails(CConfigBranch *pkParent, T_PAOCHANNEL ptAnalogueOutData, const USHORT usSLOT_NO,
			const USHORT usBOARD_CHAN_NO);

	// Method that creates a single event config hierarchy
	void SetupEventDetails(CConfigBranch *pkParent, T_EVENT *ptEvent, const USHORT usEVENT_NO);

	// Method that creates an event title and subtitle
	void CreateEventTitles(const T_EVENT *const ptEVENT, const USHORT usEVENT_NO, QString  &rstrTitle,
			QString  &rstrSubTitle) const;

	// Method that creates a single cause config hierarchy
	void SetupEventCause(CConfigBranch *pkParent, T_PEVENTCAUSE ptCause, const USHORT usCAUSE_NO, const bool bENABLED);

	// Method that creates a single furnace config hierarchy
	void SetupFurnaceConfig(CConfigBranch *pkParent, T_PFURNACE ptFurnace, const USHORT usFURNACE_NO);

	// Method that creates a single setpoint config hierarchy
	void SetupSetpointConfig(CConfigBranch *pkParent, T_PSETPOINT ptSetpoint, const USHORT usSETPOINT_NO);

	// Method that creates the furnace stability detection config hierarchy
	void SetupStabilityDetectionConfig(CConfigBranch *pkParent, T_PSTABILITYDETECT ptStabDetect);

	// Const Variable used to indicate the unitialised state of the event subtypes
	const USHORT m_usEVENT_TYPE_NOT_INIT;

	// Variable used to store the current type states of the event causes - used to clear
	// the data as the event data field is reusued
	USHORT m_usaEventCauseTypes[ EVENTSYSTEM_EVENT_SIZE][ EVENT_CAUSE_SIZE];

	// Method that creates a single effect config hierarchy
	void SetupEventEffect(CConfigBranch *pkParent, T_PEVENTEFFECT ptEffect, const USHORT usEFFECT_NO,
			const bool bENABLED, const USHORT usEVENT_NO);

	// Method that sets up the scheduled event details
	void SetupScheduledEvent(CConfigBranch *pkParent, T_SCHEDEVENTDATA *ptSchedData,
			const T_SCHED_EVENT_SUBTYPE eSUB_TYPE, const bool bENABLED);

	// Variable used to store the current type states of the event effects - used to clear
	// the data as the event data field is reusued
	USHORT m_usaEventEffectTypes[ EVENTSYSTEM_EVENT_SIZE][ EVENT_EFFECT_SIZE];

	// Method that creates a single counter config hierarchy
	void SetupCounterDetails(CConfigBranch *pkParent, T_COUNTERSDATA *ptCounter, const USHORT usCOUNTER_NO);

	// Method that sets up the counter effect data items
	void SetupCounterEffects(CConfigBranch *pkParent, T_PEVENTEFFECT ptEffect, const QString  &rstrCOUNTER_SUBTYPE);

	// Method that creates a counter title and subtitle
	void CreateCounterTitle(const T_COUNTERSDATA *const ptCOUNTER, const USHORT usCOUNTER_NO, QString  &rstrTitle,
			QString  &rstrSubTitle) const;

	// Method that creates a single report config hierarchy
	void SetupReportDetails(CConfigBranch *pkParent, T_REPORTDATA *ptReport, const USHORT usREPORT_NO);

	// Method that creates a report title and subtitle
	void CreateReportTitle(const T_REPORTDATA *const ptREPORT, const USHORT usREPORT_NO, QString  &rstrTitle,
			QString  &rstrSubTitle) const;

	// Method that sets up the email templates
	void SetupEmailTemplates(CConfigBranch *pkParent, T_EMAIL *ptEmail);

	// Method that refreshes the data for an analogue input branch of an analogue configuration menu,
	// usually following a change that requires the tree structure to be regenerated because it is different
	CConfigItem* RefreshAnalogueInputConfigTree(CConfigItem *pkModifiedItem, const USHORT usAIN_NO);

	// Method that refreshes the data for an digital IO branch of an digital IO configuration menu,
	// usually following a change that requires the tree structure to be regenerated because it is different
	CConfigItem* RefreshDigitalIOConfigTree(CConfigItem *pkModifiedItem, const USHORT usDIG_IO_NO);

	// Method that refreshes the data for a pulse input branch of a pulse input configuration menu,
	// usually following a change that requires the tree structure to be regenerated because it is different
	CConfigItem* RefreshPulseInConfigTree(CConfigItem *pkModifiedItem, const USHORT usPULSE_IN_NO);

	// Method that refreshes the data for an analogue output branch of an analogue configuration menu,
	// usually following a change that requires the tree structure to be regenerated because it is different
	CConfigItem* RefreshAnalogueOutputConfigTree(CConfigItem *pkModifiedItem, const USHORT usAOUT_NO);

	// Method that refreshes the data for an event branch of an events configuration menu,
	// usually following a change that requires the tree structure to be regenerated because it is different
	CConfigItem* RefreshEventsConfigTree(CConfigItem *pkModifiedItem, const USHORT usEVENT_NO);

	// Method that refreshes the data for a counter branch of a counters configuration menu,
	// usually following a change that requires the tree structure to be regenerated because it is different
	CConfigItem* RefreshCountersConfigTree(CConfigItem *pkModifiedItem, const USHORT usCOUNTER_NO);

	// Method that refreshes the data for a slave branch of a modbus master configuration menu,
	// usually following a change to one of the slaves that requires the tree structure to be
	// regenerated because it is different
	CConfigItem* RefreshModbusMasterConfigTree(CConfigItem *pkModifiedItem, const USHORT usSLAVE_NO);

	// Method that refreshes the data for a report branch of a reports configuration menu,
	// usually following a change that requires the tree structure to be regenerated because it is different
	CConfigItem* RefreshReportConfigTree(CConfigItem *pkModifiedItem, const USHORT uREPORT_NO);

	// Method that obtains an Digital IO channel slot and board channel number
	bool GetDigitalIOChannelInfo(const USHORT usDIGITAL_IO_NO, USHORT &rusSlotNo, USHORT &rusBoardChanNum,
			USHORT &rusChannelCaps) const;

	// Method that gets the digital channel title information for the submenu button
	void CreateDigitalTitle(const USHORT usSLOT_NO, const USHORT usDIGIO_NO, const USHORT usCHANNEL_CAPS,
			T_PDIGCHANNEL ptDigitalIOData, QString  &rstrTitle, QString  &rstrSubTitle, QString  &rstrKey) const;

	// Method that obtains a pulse input channel slot and board channel number
	bool GetPulseInputChannelInfo(const USHORT usPULSE_IN_NO, USHORT &rusSlotNo, USHORT &rusBoardChanNum) const;

	// Method that obtains an AO channel slot and board channel number
	bool GetAnalogueOutputChannelInfo(const USHORT usANALOGUE_OUTPUT_NO, USHORT &rusSlotNo, USHORT &rusBoardChanNum);

	// Method that sets up demo board details
	void SetupDemoBoardDetails(CConfigBranch *pkParent, const USHORT usSLOT_NO, const USHORT usBOARD_CHAN_NO,
			const bool bENABLED);

	// Method that sets up the calibration details for an analogue input
	void SetupAICalibrationDetails(CConfigBranch *pkParent, const USHORT usSLOT_NO, const USHORT usCHANNEL_NO,
			float *pfEngZero, float *pfEngSpan, const bool bENABLED);

	// Method that sets up the firmware options heirarchy
	void SetupFirmwareOptions(CConfigBranch *pkParent, T_PFIRMOPTIONS ptFWOptions);

	// Method that sets up the demoboard enabled options
	void SetupDemoBoardEnabledOptions(CConfigBranch *pkParent, USHORT *pusDemoBoardEnabled);

	// Method that creates the required text for the alarm buttons
	const QString  CreateAlarmBtnTitle(T_PALARM ptAlarm, const USHORT usNO_OF_ALARMS);

	// Method that resets the default selection for a single selection event picker back to 'None'
	void ResetEventSelectionToNone(const bool bEVENT_EFFECT, const USHORT usEVENT_TYPE, T_PEVENTDATA ptEventData);

	// E528446
	// Method that ceates Chart Speed data
	void LoadSubTypesAsPerTheChartSpeed(CConfigBranch *pkParent, T_PEVENTEFFECT &ptEffect);

	QString  GetStripChartSpeed();

	QString  GetCircularChartSpeed();
	//

	// Singleton auto pointer
	static std::auto_ptr<CRecSetupCfgMgr> ms_kConfigSysMgr;

	// Handle to the creation mutex
	static QMutex ms_hCreationMutex;

	// Critical section used for operations such as updating the sound list
	QMutex m_kCriticalSection;

	// PENS
	// Pen List Item Names
	static QString  ms_strPenMathTypeList;
	static QString  ms_strPenLogLogTypeList;
	static QString  ms_strPenGroupList;
	static QString  ms_strPenLogScaleList;
	static QString  ms_strPenScaleAutoList;
	static QString  ms_strAlarmEnableTypeList;
	static QString  ms_strAlarmTypeList;
	static QString  ms_strPenLogStyleList;
	static QString  ms_strPenLogAlignList;

	// Totaliser List Names
	static QString  ms_strPenTotTypeList;
	static QString  ms_strPenTotTempUnitsList;

	// Analogue List Item Names
	static QString  ms_strAINTypeList;
	static QString  ms_strAINAcqRateList;
	static QString  ms_strEZAINAcqRateList;
	static QString  ms_strAINTCRTAcqRateList;
	static QString  ms_strAINLinModeList;
	static QString  ms_strAINRTTypeList;
	static QString  ms_strAINEZRTTypeList;
	static QString  ms_strAINUpScaleBurnOutList;
	static QString  ms_strAINBurnOutSelList;
	static QString  ms_strAINActiveBurnOutList;
	static QString  ms_strAINTCTypeList;
	static QString  ms_strAINCJCMethodList;
	static QString  ms_strAINSqrtExtractList;
	static QString  ms_strAINRangePresetVoltsList;
	static QString  ms_strAINRangePresetAmpsList;
	static QString  ms_strAINRangePresetOhmsList;
	static QString  ms_strAINCalibrationTypesList;
	static QString  ms_strAINTableGroupList;

	// Eztrend acqusition rate strings
	QString  ms_strAINEZFixedAcqRate[6][2];

	// Demo Channel List Names
	static QString  ms_strDemoWaveTypeList;

	// Screen List Names
	static QString  ms_strScreenSaverModeList;
	static QString  ms_strScreenSaverTypeList;
	static QString  ms_strScreenSaverDimList;

	//Localisation List Names
	static QString  ms_strLocalLangList;
	static QString  ms_strLocalTempasprintfList;
	static QString  ms_strLocalMainsFreqList;
	static QString  ms_strLocalHelpLangList;
	static QString  ms_strTimeZoneList;
	static CMap<USHORT, USHORT, QString  , QString  > ms_kTimeZoneRegKeyArr;

	// Credits List Names
	static QString  ms_strCreditsOptMathTypeList;

	// Demo board List Names
	static QString  ms_strDemoBoardEnabledList;

	// MODBUS List Names
	static QString  ms_strModbusPortList;
	static QString  ms_strModbusProtocolList;

	// Serial Port List Names
	static QString  ms_strSerPortBaudRateList;
	static QString  ms_strSerPortByteOptsList;

	//TLS Protocol
	static QString  ms_strTLSProtocolList;

	// Digital List Names
	static QString  ms_strDigioIOPulseTypeList;
	static QString  ms_strDigioIOTypeList;
	static QString  ms_strDigioIOOutputTypeList;
	static QString  ms_strDigioOutFailsafeList;
	static QString  ms_strDigioOutLatchedList;
	static QString  ms_strDigioIOReportTypeList;

	// Pulse In List Names
	//	static QString   ms_strPulseInMeasurementMethodList;
	static QString  ms_strPulseInMeasurementUpdateList;

	// Report Lists
	static QString  ms_strReportIndTypeList;
	static QString  ms_strReportIndTriggerList;
	static QString  ms_strReportIndStyleList;
	static QString  ms_strReportIndPenSelTypeList;
	static QString  ms_strReportIndSchedSubTypeList;
	static QString  ms_strReportIndPeriodList;
	static QString  ms_strReportIndAvgPeriodList;
	static QString  ms_strReportIndMsgPeriodList;
	static QString  ms_strReportIndIncCurrPenList;
	static QString  ms_strReportIndExportDevList;
	static QString  ms_strReportIndFooterList;

	///< Maximum number of characters for analogue range in top level menu (MarkD)
	static const int ms_iMAX_MENU_RANGE_CHARS;

	/// The format of the duration field number format
	T_NUMFORMAT m_tDurationNumasprintf;

	/// Const defining the minimum deviation level
	const float m_fMIN_DEV_LEVEL;
};

#endif //__RECSETUPCFGMGR_H__

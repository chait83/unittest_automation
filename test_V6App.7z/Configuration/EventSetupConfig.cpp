/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Configuration
/// @n Filename: EventSetupConfig.cpp
/// @n Desc:	 Handles all event setup configuration 
///				 
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  19  Stability Project 1.14.1.3 7/2/2011 4:57:09 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  18  Stability Project 1.14.1.2 7/1/2011 4:38:17 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  17  Stability Project 1.14.1.1 3/17/2011 3:20:24 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  16  Stability Project 1.14.1.0 2/15/2011 3:03:03 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// ****************************************************************

#include "V6defines.h"
#include "V6globals.h"
#include "V6Config.h"
#include "EventSetupConfig.h"
#include "V6ResourceBase.h"
#include "V6UIResource.h"
#include "StringUtils.h"
#include "Registry.h"
#include "LogDeviceStatus.h"

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif

CEventSetupConfig::CEventSetupConfig(void) {
	m_EventConfigChanged = FALSE;
}

CEventSetupConfig::~CEventSetupConfig(void) {
}

//*************************************************************************************
/// Create a default event configuration and initialise
///
/// @return T_CONFIG_RETURN_VALUE indicating status of call
//*************************************************************************************
T_CONFIG_RETURN_VALUE CEventSetupConfig::CreateServiceDefaultConfig(void) {
	T_CONFIG_RETURN_VALUE retValue = CONFIG_OK;

	T_PEVENTSYSTEM pEventBlock = NULL;
	pEventBlock = CreateEventBlock();
	if (pEventBlock == NULL) {
		retValue = CONFIG_ERROR;
	}

	// create the counters structure
	T_PCOUNTERS ptCounters = NULL;
	ptCounters = CreateCountersBlock();
	if (ptCounters == NULL) {
		retValue = CONFIG_ERROR;
	}

	// create the reports structure
	T_PREPORTS ptReports = NULL;
	ptReports = CreateReportsBlock();
	if (ptReports == NULL) {
		retValue = CONFIG_ERROR;
	}

	return (retValue);

} // End of Member Function
//**********************************************************************
//	T_CONFIG_RETURN_VALUE PreCommitProcessing( void )
///
/// Function that is called immediately before a setup config is commited
/// to the CMM. 
///
/// @return		T_CONFIG_RETURN_VALUE return value
/// 
//**********************************************************************
T_CONFIG_RETURN_VALUE CEventSetupConfig::PreCommitProcessing(void) {
	T_CONFIG_RETURN_VALUE eRetVal = CONFIG_OK;

	bool bKeyExists = true;
	CRegistryKey kRegKey;
	if (!kRegKey.OpenKey(L"Snd\\Event")) {
		// the reg key doesn't appear to exist so create it
		if (!kRegKey.CreateKey(L"Snd\\Event")) {
			// couldn't create the key therefore flag the error
			bKeyExists = false;
		}
	}

	// now check the key if it exists
	if (bKeyExists) {
		// read and check the relevant string value
		QString  strCurrVal("");
		DWORD dwSize = 0;
		const DWORD dwTYPE = REG_SZ;
		// try and read the current value - it might not exist but the string should just be null if
		// this is the case
		kRegKey.ReadValue(L".Scheme", strCurrVal, &dwSize, dwTYPE);

		// compare the current value against what we want and update if necessary
		if (strCurrVal != L".NoSounds") {
			// not currently set to no sounds so update it - technically we need to reboot the recorder
			// now but given this will only happen following a firmware update it is safe to assume the
			// recorder will reboot because of other registry changes (e.g. comms changes always cause
			// a reboot)
			kRegKey.WriteValue(L".Scheme", L".NoSounds");
		}
	} else {
		// the key still does not exist which should not happen
#ifdef _DEBUG
		DebugBreak();
#endif
	}

	return eRetVal;
}
//*************************************************************************************
/// Validate the configuration items when a config has been loaded and is about to be commited
///
///
/// @return T_CONFIG_RETURN_VALUE indicating status of call
/// 
//*************************************************************************************
T_CONFIG_VALIDATE_RETURN CEventSetupConfig::ValidateServiceConfig() {
	T_CONFIG_VALIDATE_RETURN retValue = CONFIG_VALIDATE_NO_CHANGES;

	T_PEVENTSYSTEM pEventBlock = GetEventBlock(CONFIG_MODIFIABLE);
	if (pEventBlock == NULL) {
		pEventBlock = CreateEventBlock();

		retValue = CONFIG_VALIDATE_CHANGES_MADE;
	}

	// check the counters structure exists and create it if it doesn't
	T_PCOUNTERS ptCounters = GetCountersBlock(CONFIG_MODIFIABLE);
	if (ptCounters == NULL) {
		ptCounters = CreateCountersBlock();

		retValue = CONFIG_VALIDATE_CHANGES_MADE;
	}

	// check the reports structure exists and create it if it doesn't
	T_PREPORTS ptReports = GetReportsBlock(CONFIG_MODIFIABLE);
	if (ptReports == NULL) {
		ptReports = CreateReportsBlock();

		retValue = CONFIG_VALIDATE_CHANGES_MADE;
	} else {
		// the report style has been moved from the Style bitfield to the ReportStyle USHORT as we
		// ran out of spare bits - check this field has been updated - also check the style is not TUS on a non-TUS recorder
		for (int iReportCount = 0; iReportCount < REPORTS_REPORT_SIZE; iReportCount++) {
			// check if it is non-zero which would imply it has not been moved yet
			if (ptReports->Report[iReportCount].Style > 0) {
				ptReports->Report[iReportCount].ReportStyle = ptReports->Report[iReportCount].Style;

				// set the style back to zero so this does not happen again
				ptReports->Report[iReportCount].Style = 0;

				// changes have now been made so notify the calling method of this
				retValue = CONFIG_VALIDATE_CHANGES_MADE;
			}

			// check for non TUS recorders
			if (!pSYSTEM_INFO->FWOptionTUSModeAvailable()) {
				// ensure the TUS report style is not set
				if (ptReports->Report[iReportCount].ReportStyle == rssTUS) {
					// this is set to TUS - revert to normal
					ptReports->Report[iReportCount].ReportStyle = rssNORMAL;
					// changes have now been made so notify the calling method of this
					retValue = CONFIG_VALIDATE_CHANGES_MADE;
				}
			}
		}
	}

	return (retValue);
}

//**********************************************************************
///
/// Function that is called immediately after a setup config is commited
/// to the CMM.
///
/// @return		T_CONFIG_RETURN_VALUE return value
/// 
//**********************************************************************
T_CONFIG_RETURN_VALUE CEventSetupConfig::PostCommitProcessing(void) {
	// Setup a flag to allow event system to reference a change in config over last setup change
	m_EventConfigChanged = CConfiguration::WasBlockModified(BLK_EVENTSYSTEM, 0, m_ConfigurationId);
	return CONFIG_OK;
}

//*************************************************************************************
/// Default the event block
///
/// @param[in] T_PEVENTSYSTEM pEventBlk - Pointer to the event block to default
/// 
//*************************************************************************************
void CEventSetupConfig::DefaultEventBlock(T_PEVENTSYSTEM pEventBlk) {
	for (int eventIndex = 0; eventIndex < V6_MAX_EVENTS; eventIndex++) {
		QString  strEventasprintf, strEventName;
		strEventasprintf = tr("Event %d");
		strEventName.asprintf(strEventasprintf, eventIndex + 1);
#if _MSC_VER < 1400 
		wcsncpy(pEventBlk->Event[eventIndex].Name, strEventName, EVENT_NAME_LEN);
#else
		wcsncpy_s( pEventBlk->Event[eventIndex].Name, sizeof(pEventBlk->Event[eventIndex].Name)/sizeof(WCHAR), strEventName, _TRUNCATE );
#endif

	}
}
//*************************************************************************************
/// Default the counters block
///
/// @param[in] T_PCOUNTER ptCountersBlk - Pointer to the counters block to default
/// 
//*************************************************************************************
void CEventSetupConfig::DefaultCountersBlock(T_PCOUNTERS ptCountersBlk) {
	for (int iCount = 0; iCount < COUNTERS_COUNTER_SIZE; iCount++) {
		// set the correct name
		QString  strCounterName("");
		strCounterName.asprintf(IDS_CFG_COUNTER_DEF_TITLE, iCount + 1);
		CStringUtils::SafeWcsCpy(ptCountersBlk->Counter[iCount].Tag, strCounterName, COUNTERSDATA_TAG_LEN);

		// set the rollover to a max float
		ptCountersBlk->Counter[iCount].RolloverAt = V6_FLT_MAX;
	}
}
//*************************************************************************************
/// Default the reports block
///
/// @param[in] T_PREPORTS ptReportsBlk - Pointer to the reports block to default
/// 
//*************************************************************************************
void CEventSetupConfig::DefaultReportsBlock(T_PREPORTS ptReportsBlk) {
	for (int iCount = 0; iCount < REPORTS_REPORT_SIZE; iCount++) {
		// set the correct name
		QString  strReportName("");
		strReportName.asprintf(IDS_CFG_REPORT_DEF_TITLE, iCount + 1);
		CStringUtils::SafeWcsCpy(ptReportsBlk->Report[iCount].Tag, strReportName, REPORTDATA_TAG_LEN);

		// always set the trigger to event for now
		ptReportsBlk->Report[iCount].Trigger = rstEVENT;

		ptReportsBlk->Report[iCount].ExportDev = LOGDEV_MAX_DEVICES;
	}
}
//*************************************************************************************
/// Get the Event block from the CMM.
///
/// @param[in] cfgType - The type of configuration to access.
///
/// @return Pointer to the change header block; otherwise NULL
/// 
//*************************************************************************************
T_PEVENTSYSTEM CEventSetupConfig::GetEventBlock(REFERENCE cfgType) {
	return reinterpret_cast<T_PEVENTSYSTEM>(CConfiguration::GetBlock(BLK_EVENTSYSTEM, 0, m_ConfigurationId, cfgType));
}
//*************************************************************************************
/// Get the Counters block from the CMM.
///
/// @param[in] cfgType - The type of configuration to access.
///
/// @return Pointer to the counters block; otherwise NULL
/// 
//*************************************************************************************
T_PCOUNTERS CEventSetupConfig::GetCountersBlock(REFERENCE cfgType) {
	return reinterpret_cast<T_PCOUNTERS>(CConfiguration::GetBlock(BLK_COUNTERS, 0, m_ConfigurationId, cfgType));
}
//*************************************************************************************
/// Get the Reports block from the CMM.
///
/// @param[in] cfgType - The type of configuration to access.
///
/// @return Pointer to the reports block; otherwise NULL
/// 
//*************************************************************************************
T_PREPORTS CEventSetupConfig::GetReportsBlock(REFERENCE cfgType) {
	return reinterpret_cast<T_PREPORTS>(CConfiguration::GetBlock(BLK_REPORTS, 0, m_ConfigurationId, cfgType));
}
//*************************************************************************************
/// Create an event block
///
/// @return Pointer to the CMM based event block; otherwise NULL
/// 
//*************************************************************************************
T_PEVENTSYSTEM CEventSetupConfig::CreateEventBlock() {
	T_PEVENTSYSTEM pEventBlock = NULL;
	pEventBlock =
			reinterpret_cast<T_PEVENTSYSTEM>(CConfiguration::CreateNewBlock(BLK_EVENTSYSTEM, 0, m_ConfigurationId));
	if (pEventBlock != NULL) {
		DefaultEventBlock(pEventBlock);
	}
	return pEventBlock;
}
//*************************************************************************************
/// Create an counter block
///
/// @return Pointer to the CMM based counter block; otherwise NULL
/// 
//*************************************************************************************
T_PCOUNTERS CEventSetupConfig::CreateCountersBlock() {
	T_PCOUNTERS pCountersBlock = NULL;
	pCountersBlock = reinterpret_cast<T_PCOUNTERS>(CConfiguration::CreateNewBlock(BLK_COUNTERS, 0, m_ConfigurationId));
	if (pCountersBlock != NULL) {
		DefaultCountersBlock(pCountersBlock);
	}
	return pCountersBlock;
}
//*************************************************************************************
/// Create an reports block
///
/// @return Pointer to the CMM based reports block; otherwise NULL
/// 
//*************************************************************************************
T_PREPORTS CEventSetupConfig::CreateReportsBlock() {
	T_PREPORTS pReportsBlock = NULL;
	pReportsBlock = reinterpret_cast<T_PREPORTS>(CConfiguration::CreateNewBlock(BLK_REPORTS, 0, m_ConfigurationId));
	if (pReportsBlock != NULL) {
		DefaultReportsBlock(pReportsBlock);
	}
	return pReportsBlock;
}

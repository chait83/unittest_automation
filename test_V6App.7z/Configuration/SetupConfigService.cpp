/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Configuration
/// @n Filename: SetupServiceConfig.cpp
/// @n Desc:	 Configuration services base class 
///				 
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  7 Stability Project 1.2.1.3 7/2/2011 5:01:16 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  6 Stability Project 1.2.1.2 7/1/2011 4:38:55 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  5 Stability Project 1.2.1.1 3/17/2011 3:20:47 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  4 Stability Project 1.2.1.0 2/15/2011 3:03:56 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// ****************************************************************

#include "SetupConfigService.h"

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif

CSetupConfigService::CSetupConfigService(void) : m_ConfigurationId(0) {
}

CSetupConfigService::~CSetupConfigService(void) {
}


/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 Configuration
/// @n PenSetupConfig.cpp
/// @n implementation to handle creating default configurations
///  and getting CMM configuration for pens.
/// @author GKW
/// @date 22/09/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
//  50  Stability Project 1.45.1.3 7/2/2011 4:59:41 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  49  Stability Project 1.45.1.2 7/1/2011 4:38:37 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  48  Stability Project 1.45.1.1 3/17/2011 3:20:34 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  47  Stability Project 1.45.1.0 2/15/2011 3:03:40 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////

#include "V6defines.h"
#include "V6globals.h"
#include "V6Configuration.h"
#include "PenSetupConfig.h"
#include "V6ResourceBase.h"
#include "V6UIResource.h"
//#include <iomanip> // CR3068

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif

const USHORT DEFAULT_SCRIPT_SIZE = 20;		// Default script being "Return An" where n=analogue number

const int MAX_DEFAULT_COLS = 48;

static const COLORREF defaultPenCols[] = { QString  (128, 128, 128),	// Pen 0 - Not a Pen
QString  (255, 0, 0),		// Pen 1
QString  (255, 0, 255),		// Pen 2
QString  (0, 128, 0),		// Pen 3
QString  (0, 0, 255),		// Pen 4
QString  (128, 0, 0),		// Pen 5
QString  (128, 0, 128),		// Pen 6
QString  (0, 74, 0),		// Pen 7
QString  (0, 0, 137),		// Pen 8
QString  (235, 39, 87),		// Pen 9
QString  (109, 81, 142),	// Pen 10
QString  (87, 146, 76),		// Pen 11
QString  (0, 94, 118),		// Pen 12
QString  (253, 85, 48),		// Pen 13
QString  (174, 116, 209),	// Pen 14
QString  (139, 168, 0),		// Pen 15
QString  (83, 174, 255),	// Pen 16
QString  (255, 39, 87),		// Pen 17
QString  (109, 81, 139),	// Pen 18
QString  (87, 146, 76),		// Pen 19
QString  (0, 94, 118),		// Pen 20
QString  (253, 83, 48),		// Pen 21
QString  (174, 113, 211),	// Pen 22
QString  (139, 168, 0),		// Pen 23
QString  (83, 174, 172),	// Pen 24
QString  (255, 100, 0),		// Pen 25
QString  (0, 231, 157),		// Pen 26
QString  (211, 148, 133),	// Pen 27
QString  (201, 144, 41),	// Pen 28
QString  (0, 59, 44),		// Pen 29
QString  (111, 255, 109),	// Pen 30
QString  (74, 74, 81),		// Pen 31
QString  (96, 0, 0),		// Pen 32
QString  (255, 39, 87),		// Pen 33
QString  (109, 81, 139),	// Pen 34
QString  (87, 146, 76),		// Pen 35
QString  (0, 94, 118),		// Pen 36
QString  (253, 83, 48),		// Pen 37
QString  (174, 113, 211),	// Pen 38
QString  (139, 168, 0),		// Pen 39
QString  (83, 174, 172),	// Pen 40
QString  (255, 100, 0),		// Pen 41
QString  (0, 231, 157),		// Pen 42
QString  (211, 148, 133),	// Pen 43
QString  (201, 144, 41),	// Pen 44
QString  (0, 59, 44),		// Pen 45
QString  (111, 255, 109),	// Pen 46
QString  (74, 74, 81),		// Pen 47
QString  (96, 0, 0)			// Pen 48										 
		};

static const COLORREF defaultPenColsEz[] = { QString  (128, 128, 128),	// Pen 0 - Not a Pen
QString  (255, 0, 0),		// Pen 1
QString  (255, 0, 255),		// Pen 2
QString  (0, 166, 0),		// Pen 3
QString  (0, 0, 255),		// Pen 4
QString  (166, 0, 0),		// Pen 5
QString  (166, 0, 166),		// Pen 6
QString  (0, 74, 0),		// Pen 7
QString  (0, 0, 137),		// Pen 8
QString  (209, 48, 144),	// Pen 9
QString  (139, 123, 163),	// Pen 10
QString  (103, 173, 141),	// Pen 11
QString  (0, 149, 163),		// Pen 12
QString  (253, 130, 58),	// Pen 13
QString  (174, 116, 209),	// Pen 14
QString  (139, 168, 0),		// Pen 15
QString  (83, 174, 255),	// Pen 16
QString  (255, 39, 87),		// Pen 17
QString  (109, 81, 139),	// Pen 18
QString  (87, 146, 76),		// Pen 19
QString  (0, 94, 118),		// Pen 20
QString  (253, 83, 48),		// Pen 21
QString  (174, 113, 211),	// Pen 22
QString  (139, 168, 0),		// Pen 23
QString  (83, 174, 172),	// Pen 24
QString  (255, 100, 0),		// Pen 25
QString  (0, 231, 157),		// Pen 26
QString  (211, 148, 133),	// Pen 27
QString  (201, 144, 41),	// Pen 28
QString  (0, 59, 44),		// Pen 29
QString  (111, 255, 109),	// Pen 30
QString  (74, 74, 81),		// Pen 31
QString  (96, 0, 0),		// Pen 32
QString  (255, 39, 87),		// Pen 33
QString  (109, 81, 139),	// Pen 34
QString  (87, 146, 76),		// Pen 35
QString  (0, 94, 118),		// Pen 36
QString  (253, 83, 48),		// Pen 37
QString  (174, 113, 211),	// Pen 38
QString  (139, 168, 0),		// Pen 39
QString  (83, 174, 172),	// Pen 40
QString  (255, 100, 0),		// Pen 41
QString  (0, 231, 157),		// Pen 42
QString  (211, 148, 133),	// Pen 43
QString  (201, 144, 41),	// Pen 44
QString  (0, 59, 44),		// Pen 45
QString  (111, 255, 109),	// Pen 46
QString  (74, 74, 81),		// Pen 47
QString  (96, 0, 0)			// Pen 48										 
		};

CPenSetupConfig::CPenSetupConfig(void) {
	// Cleardown the dummy Pen settings.
	memset(&m_dummyPen, 0, sizeof(T_PEN));
	m_dummyPen.Style.Colour = QString  (0, 0, 0); // black
	m_dummyPen.Scale.Span = 100;
	m_ChangesMade = FALSE;
}

CPenSetupConfig::~CPenSetupConfig(void) {
}

//**************************************************************************
///
/// Creates this services default configuration.
///
/// @return CONFIG_OK if succesful creation; otherwise CONFIG_ERROR
/// 
//**************************************************************************
T_CONFIG_RETURN_VALUE CPenSetupConfig::CreateServiceDefaultConfig(void) {
	T_CONFIG_RETURN_VALUE retValue = CONFIG_OK;

	// Create configuration for all possible pens
	for (USHORT penCreation = 0; penCreation < V6_MAX_PENS; penCreation++) {
		// Only create Pens in a default configuration that actually exist
		if ( pSYSTEM_INFO->IsPenAvailable(penCreation, ZERO_BASED) == TRUE) {
			// Pen is available so attempt to create
			if (CreatePen(penCreation, ZERO_BASED) == CONFIG_ERROR)
				retValue = CONFIG_ERROR;
		}
	}
	return (retValue);

} // End of Member Function

//*************************************************************************************
/// Validate the configuration items in the working config when a new config loaded,
/// but not yet commited
///
/// @return T_CONFIG_RETURN_VALUE indicating status of call
/// 
//*************************************************************************************
T_CONFIG_VALIDATE_RETURN CPenSetupConfig::ValidateServiceConfig(void) {
	T_CONFIG_VALIDATE_RETURN retValue = CONFIG_VALIDATE_NO_CHANGES;
	T_PPEN pPen = NULL;

	for (USHORT penCreation = 0; penCreation < V6_MAX_PENS; penCreation++) {
		// We only need to validate Pens that are available
		if ( pSYSTEM_INFO->IsPenAvailable(penCreation, ZERO_BASED) == TRUE) {
			pPen = GetPen(penCreation, ZERO_BASED, CONFIG_MODIFIABLE);
			if (pPen == NULL) {

				// No pen currently exists in this configuration but the pen is available in the system, so create one
				CreatePen(penCreation, ZERO_BASED);
				retValue = CONFIG_VALIDATE_CHANGES_MADE;

			} else {
				// Check any pen details to make sure they are in scope etc...
				// this section needs to be completed as required.
				// if changes are made use 
				// retValue = CONFIG_VALIDATE_CHANGES_MADE;

				// Check if pen configured for scripts BUT is being used in a system without scripts
				if (pPen->MathType == MATH_TYPE_SCRIPTING
						&& pSYSTEM_INFO->FWOptionMathsType() != MATH_OPTION_FULL_SCRIPT) {
					// Yes, mismatch occured, so warn user and make sure script are not run.
					QString  strErrorMessageasprintf;
					strErrorMessageasprintf = tr("Pen %d using scripts but option not available");

					QString  strErrorMessage;
					strErrorMessage.asprintf(strErrorMessageasprintf, pPen->Instance + 1);
					LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_ERROR, strErrorMessage);

					// Modify pen maths to use basic block not scripts.
					pPen->MathType = MATH_TYPE_BLOCK;
					retValue = CONFIG_VALIDATE_CHANGES_MADE;

				}

				// Create a script if not found (all pens should have one regardless of options)
				if (CreateScriptIfNotAvailable(penCreation, ZERO_BASED) == CONFIG_BLOCK_ADDED) {

					retValue = CONFIG_VALIDATE_CHANGES_MADE;	// Indicate a block was added
				}
			}

			// check if we are in TUS mode and iths is one of the special TUS pens 
			if (( pSYSTEM_INFO->FWOptionTUSModeAvailable())
					&& ((penCreation == gs_usSPECIAL_TUS_PEN_START_INST)
							|| (penCreation == gs_usSPECIAL_TUS_PEN_START_INST + 1))) {
				pPen = GetPen(penCreation, ZERO_BASED, CONFIG_MODIFIABLE);
				// these pens must always be enabled
				if (pPen->Enabled == FALSE) {
					pPen->Enabled = TRUE;

					retValue = CONFIG_VALIDATE_CHANGES_MADE;	// Indicate the pen data block has been changed

				}
				if (pPen->MathType != MATH_TYPE_BLOCK) {
					pPen->MathType = MATH_TYPE_BLOCK;
					retValue = CONFIG_VALIDATE_CHANGES_MADE;	// Indicate the pen data block has been changed

				}
				if (pPen->Scale.automaticDivs == TRUE || pPen->Scale.MajorDivs != 10) {
					pPen->Scale.automaticDivs = FALSE;
					pPen->Scale.MajorDivs = 10;
					pPen->Scale.Zero = 0;
					retValue = CONFIG_VALIDATE_CHANGES_MADE;	// Indicate the pen data block has been changed

				}
				// set the span to the highest configured setpoint
				if (SetSpanToHiSetpoint(pPen->Scale.Span) == CONFIG_VALIDATE_CHANGES_MADE) {
					retValue = CONFIG_VALIDATE_CHANGES_MADE;	// Indicate the pen data block has been changed

				}

				if (penCreation == gs_usSPECIAL_TUS_PEN_START_INST) {
					// Check the maths block for the Pen - we need to set it to the Max TC for the run
					if (strcmp(pPen->MathsBlock, "MAXTC") != 0) {
#if _MSC_VER < 1400 
						strcpy(pPen->MathsBlock, "MAXTC");
#else
						strcpy_s( pPen->MathsBlock, sizeof(pPen->MathsBlock)/sizeof(CHAR), "MAXTC" );
#endif

						retValue = CONFIG_VALIDATE_CHANGES_MADE;	// Indicate the pen data block has been changed

					}
					if (wcscmp(pPen->Tag, L"Max TUS TC") != 0) {
#if _MSC_VER < 1400 
						wcscpy(pPen->Tag, L"Max TUS TC");
#else
						wcscpy_s( pPen->Tag, sizeof(pPen->Tag)/sizeof(WCHAR),L"Max TUS TC" );
#endif

						retValue = CONFIG_VALIDATE_CHANGES_MADE;	// Indicate the pen data block has been changed

					}
					// Set Max pen colour to Red
					if (pPen->Style.Colour != QString  (255, 0, 0)) {
						pPen->Style.Colour = QString  (255, 0, 0);
						retValue = CONFIG_VALIDATE_CHANGES_MADE;	// Indicate the pen data block has been changed

					}
				}
				if (penCreation == gs_usSPECIAL_TUS_PEN_START_INST + 1) {
					// Check the maths block for the Pen - we need to set it to the Max TC for the run
					if (strcmp(pPen->MathsBlock, "MINTC") != 0) {
#if _MSC_VER < 1400 
						strcpy(pPen->MathsBlock, "MINTC");
#else
						strcpy_s( pPen->MathsBlock, sizeof(pPen->MathsBlock)/sizeof(CHAR),"MINTC" );
#endif

						retValue = CONFIG_VALIDATE_CHANGES_MADE;	// Indicate the pen data block has been changed

					}
					if (wcscmp(pPen->Tag, L"Min TUS TC") != 0) {
#if _MSC_VER < 1400 
						wcscpy(pPen->Tag, L"Min TUS TC");
#else
						wcscpy_s( pPen->Tag, sizeof(pPen->Tag)/sizeof(WCHAR),L"Min TUS TC" );
#endif

						retValue = CONFIG_VALIDATE_CHANGES_MADE;	// Indicate the pen data block has been changed

					}
					// Set Min Pen colour to Blue
					if (pPen->Style.Colour != QString  (0, 0, 255)) {
						pPen->Style.Colour = QString  (0, 0, 255);
						retValue = CONFIG_VALIDATE_CHANGES_MADE;	// Indicate the pen data block has been changed

					}
				}
			}
		}
	}
	return (retValue);
}

//*************************************************************************************
/// see if any changes to groups have been made in the pen Setup
///
/// @return T_CONFIG_RETURN_VALUE - CONFIG_OK
/// 
//*************************************************************************************
T_CONFIG_RETURN_VALUE CPenSetupConfig::PreCommitProcessing(void) {

	// here see if any changes to group have been made.
	// if so need to make changes to the layout.

	m_ChangesMade = FALSE;
	// reset group changed flags
	for (int g = 0; g < PEN_GROUP_MAX; g++) {
		m_GroupChanged[g] = FALSE;
		m_GroupUnused[g] = TRUE;  // keep track of any unused groups - any in use on a canned screen will be removed 
	}

	for (USHORT penIndex = 0; penIndex < V6_MAX_PENS; penIndex++) {
		T_PPEN pPenOld = NULL;
		T_PPEN pPenNew = NULL;

		USHORT OldGroup = 0;
		USHORT NewGroup = 0;

		pPenOld = GetPen(penIndex, ZERO_BASED, CONFIG_COMMITTED);
		pPenNew = GetPen(penIndex, ZERO_BASED, CONFIG_MODIFIABLE);

		if (pPenOld && pPenOld->Enabled)
			OldGroup = pPenOld->GroupNumber;

		if (pPenNew && pPenNew->Enabled)
			NewGroup = pPenNew->GroupNumber;

		m_GroupUnused[NewGroup] = FALSE; // this group is used in the new cofig

		if (NewGroup != OldGroup) {
			m_GroupChanged[NewGroup] = TRUE;
			m_GroupChanged[OldGroup] = TRUE;

			m_ChangesMade = TRUE; // a change has occurred here. OpPanel will check this flag
		}

		// check if this is one of the special TUS pens and we are in TUS mode
		if (((penIndex == gs_usSPECIAL_TUS_PEN_START_INST) || (penIndex == gs_usSPECIAL_TUS_PEN_START_INST + 1))
				&& ( pSYSTEM_INFO->FWOptionTUSModeAvailable()) && (pPenNew != NULL)) {
			// check if NADCAP TUS mode has been turned off
			T_PGENNONVOL ptGenNonVol = pSYSTEM_INFO->GetFactoryConfig();
			if (ptGenNonVol->FWOptions.AMS2750TUS == FALSE) {
#ifndef TTR6SETUP
				// TUS mode has been turned off therefore we need to disable the special TUS
				// pens
				if (pPenNew->Enabled == TRUE) {
					pPenNew->Enabled = FALSE;
					m_ChangesMade = TRUE;
				}
#endif
			} else {
				// set the span to the highest configured setpoint
				SetSpanToHiSetpoint(pPenNew->Scale.Span);
			}
		}
	}

	// Set the Pen Logging Pre-trigger Enable status to FALSE if the Export format selected is CSV
	// This is an workaround as Pre-trigger data export is not supported for CSV type

	// Get the CSV export variable from the setup configuration
	T_PRECPROFILE ptProfile = pSETUP->GetGeneralSetupConfig()->GetProfileBlock(CONFIG_MODIFIABLE);
	if (ptProfile->Logging.CSV) {
		// Traverse through all the PENs configured
		for (USHORT penIndex = 0; penIndex < V6_MAX_PENS; penIndex++) {
			// Get the PEN instances
			T_PPEN penConfig = GetPen(penIndex, ZERO_BASED, CONFIG_MODIFIABLE);

			// Check if it supports Pre-trigger
			if (penConfig && penConfig->Instance < MAX_PRETRIGGER_INSTANCE) {
				// Set to FALSE if in TRUE state
				if (TRUE == penConfig->PenLog.PretriggerEn) {
					penConfig->PenLog.PretriggerEn = FALSE;
				}
			}
		}
	}

	return CONFIG_OK;
}

//*****************************************************************************
///
/// Create the default configuration for a pen in the CMM.
/// @param[in] penNumber - The pen number (check with base)
/// @param[in] base - Base that penNumber is passed in ZERO_BASE or ONE_BASED. 
///
/// @return creation sucess state
/// 
//*****************************************************************************
T_CONFIG_RETURN_VALUE CPenSetupConfig::CreatePen(USHORT penNumber, T_PENBASE base) {
	T_PPEN pPen = NULL;
	T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;

	// All pen numbering from here on is one based
	USHORT penNumOneBased = PEN_TO_ONE_BASED(penNumber, base);

	pPen = reinterpret_cast<T_PPEN>(CConfiguration::CreateNewBlock(BLK_PEN, penNumOneBased, m_ConfigurationId));

	const USHORT usANA_NO_ONE_BASED = ((penNumOneBased - 1) % MAX_ANALOGUE_IN) + 1;

	if (pPen != NULL) {
		// Override some pen CMM defaults
		pPen->Instance = penNumOneBased - 1;
		if ( pDALGLB->IsRecorderEzTrend() == TRUE) {
			pPen->Style.Colour = defaultPenColsEz[((penNumOneBased) % MAX_DEFAULT_COLS)];/// Set pen colour for Eztrend
		} else {
			pPen->Style.Colour = defaultPenCols[((penNumOneBased) % MAX_DEFAULT_COLS)];	/// Set pen colour for Mini / Multi
		}

		QString  penStr;
		penStr = tr("Pen");
		swprintf(pPen->Tag, L"%s %d", penStr, penNumOneBased);

		if ( pDEVICE_INFO->TestTopSlotChannelCapability(penNumOneBased, CHANNEL_CAP_PULSE, ONE_BASED) == TRUE) {
			// A Pulse channel is available so default to pulse data item
#if _MSC_VER < 1400 
			sprintf(pPen->MathsBlock, "HPUL%d", usANA_NO_ONE_BASED);
#else
			sprintf_s( pPen->MathsBlock, sizeof(pPen->MathsBlock)/sizeof(CHAR), "HPUL%d", usANA_NO_ONE_BASED );		
#endif

		} else {
			// An analogue channel is available , default to analogue data item
#if _MSC_VER < 1400 
			sprintf(pPen->MathsBlock, "A%d", usANA_NO_ONE_BASED);
#else
			sprintf_s( pPen->MathsBlock, sizeof(pPen->MathsBlock)/sizeof(CHAR), "A%d", usANA_NO_ONE_BASED );		
#endif

		}

		// By default enable the Pen if it is available and is NOT an extra pen unless this is screen designer
		// in which case we enable extra pens too
		if (( pSYSTEM_INFO->IsPenAvailable(penNumOneBased, ONE_BASED) == TRUE) &&
#ifndef DOCVIEW
				(penNumOneBased <= MAX_ANALOGUE_IN))
#else
			TRUE )
#endif
				{
			pPen->Enabled = TRUE;
		}

		// Set up default alarm tags
		for (int alarmNumber = 0; alarmNumber < V6_MAX_ALARMS; alarmNumber++) {
			swprintf(pPen->Alm[alarmNumber].Tag, L"P%d Alm %d", penNumOneBased, alarmNumber + 1);
			// We want to change Pen 1 deviation channel not to look at itself but Pen 2
			if (pPen->Instance == 0) {
				pPen->Alm[alarmNumber].DevPenNum = 1;
			}
		}

		// Set up default totaliser tag
		QString  strTotal;
		strTotal = tr("Total");
		swprintf(pPen->Tot.Tag, L"%s %d", strTotal, penNumOneBased);

		// Check and create a script if not available
		retValue = CreateScriptIfNotAvailable(penNumber, base);
	}
	return retValue;
}

//*****************************************************************************
/// Create a default script block if one is not available
///
/// @param[in] penNumber - The pen number (check with base)
/// @param[in] base - Base that penNumber is passed in ZERO_BASE or ONE_BASED. 
///
/// @return creation sucess state
/// 
//*****************************************************************************
T_CONFIG_RETURN_VALUE CPenSetupConfig::CreateScriptIfNotAvailable(USHORT penNumber, T_PENBASE base) {
	T_CONFIG_RETURN_VALUE retValue = CONFIG_OK;

	char *pScriptBlock = GetPenScriptBlock(penNumber, base, CONFIG_MODIFIABLE);

	USHORT penNumZeroBased = PEN_TO_ZERO_BASED(penNumber, base);

	const USHORT usANA_NO_ONE_BASED = (penNumZeroBased % MAX_ANALOGUE_IN) + 1;

	if (pScriptBlock == NULL) {
		// No script block found for Pen, so create it and make sure it's one based.
		retValue = CONFIG_BLOCK_ADDED;
		char *pScriptBlock = reinterpret_cast<char*>(CConfiguration::CreateNewVariableSizedBlock( BLKVARIABLE_PENMATHS,
				penNumber + 1, DEFAULT_SCRIPT_SIZE, m_ConfigurationId));
		if (pScriptBlock != NULL) {
			char BaseScript[DEFAULT_SCRIPT_SIZE];
#if _MSC_VER < 1400 
			if (base == ZERO_BASED) {
				sprintf(BaseScript, "return A%d;", usANA_NO_ONE_BASED);
			} else {
				sprintf(BaseScript, "return A%d;", usANA_NO_ONE_BASED);
			}

#else
			if( base == ZERO_BASED )
			{
				sprintf_s(BaseScript, sizeof(BaseScript)/sizeof(CHAR), "return A%d;", usANA_NO_ONE_BASED );
			}
			else
			{
				sprintf_s(BaseScript, sizeof(BaseScript)/sizeof(CHAR),"return A%d;", usANA_NO_ONE_BASED );
			}

#endif

			if (ModifyScriptBlock(penNumber, base, BaseScript) != CMM_SUCCESS) {
				///< Log the error that occured
				retValue = CONFIG_ERROR;
			}
		} else {
			retValue = CONFIG_ERROR;
		}
	}
	return retValue;
}

//******************************************************
/// Get the current configuration for a pen from the CMM.
///
/// @param[in] penNumber - The pen number.
/// @param[in] base - Base that penNumber is passed in ZERO_BASE or ONE_BASED.
/// @param[in] cfgType - The type of configuration to access.
///
/// @return Pointer to the pen config structure, if valid; otherwise NULL
/// 
//******************************************************
T_PPEN CPenSetupConfig::GetPen(USHORT penNumber, T_PENBASE base, REFERENCE cfgType) {
	return reinterpret_cast<T_PPEN>(CConfiguration::GetBlock(BLK_PEN, PEN_TO_ONE_BASED(penNumber, base),
			m_ConfigurationId, cfgType));
}

//****************************************************************************
/// Get the current configuration for a pen maths block
///
/// @param[in] penNumber - The pen number.
/// @param[in] base - Base that penNumber is passed in ZERO_BASE or ONE_BASED.
/// @param[in] cfgType - The type of configuration to access.
///
/// @return Pointer to the pen config structure, if valid; otherwise NULL
/// 
//****************************************************************************
char* CPenSetupConfig::GetPenScriptBlock(USHORT penNumber, T_PENBASE base, REFERENCE cfgType) {
	return reinterpret_cast<char*>(CConfiguration::GetBlock( BLKVARIABLE_PENMATHS, PEN_TO_ONE_BASED(penNumber, base),
			m_ConfigurationId, cfgType));
}

//****************************************************************************
/// Modify a script Block
///
/// @param[in] penNumber - The pen number.
/// @param[in] base - Base that penNumber is passed in ZERO_BASE or ONE_BASED.
/// @param[in] pNewBlock - pointer to new script block to store (NULL terminated)
///
/// @return Pointer to the pen config structure, if valid; otherwise NULL
/// 
//****************************************************************************
CMMERROR CPenSetupConfig::ModifyScriptBlock(USHORT penNumber, T_PENBASE base, char *pNewBlock) {
	DWORD size = static_cast<DWORD>(strlen(pNewBlock)) + 1;		// Get string length including termination
	ALIGN_UP_4(size);
	return CConfiguration::ModifyVariableSizedBlock( BLKVARIABLE_PENMATHS, PEN_TO_ONE_BASED(penNumber, base), size,
			reinterpret_cast<BYTE*>(pNewBlock), m_ConfigurationId);
}

//******************************************************
///
/// Queries the pen zero & span in the CMM.
/// @param[in] cfgType - The type of configuration to access.
/// @param[in] PenNo - The pen number.
/// @param[out] pEngZero - The lower enginering value.
/// @param[out] pEngSpan - The upper engineering value.
///
/// @return CONFIG_OK if valid return; otherwise CONFIG_ERROR
/// 
//******************************************************
T_CONFIG_RETURN_VALUE CPenSetupConfig::GetPenLimits(REFERENCE cfgType, USHORT PenNo, float *pPenZero, float *pPenSpan) {
	T_PPEN pPen = NULL;
	T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;

	pPen = GetPen(PenNo, ZERO_BASED, cfgType);
	if (pPen != NULL) {
		// if pen is log, use log values for tied to scaling
		if (pPen->Scale.LogScale == TRUE) {
			*pPenZero = static_cast<float>(pPen->Scale.StartDecade);
			*pPenSpan = static_cast<float>(pPen->Scale.StartDecade + pPen->Scale.NumDecades);
		} else	// normal case
		{
			*pPenZero = pPen->Scale.Zero;
			*pPenSpan = pPen->Scale.Span;
		}
		retValue = CONFIG_OK;
	}

	return retValue;
}
//******************************************************
///
/// Method that sets the span to the highest configured setpoint - used in TUS mode
///
/// @param[in/out] float &rfSpan - The span we wish to update with the highest setpoint value
/// 
/// @return CONFIG_VALIDATE_CHANGES_MADE if the span had to be updated otherwise CONFIG_VALIDATE_NO_CHANGES
///
//******************************************************
const T_CONFIG_VALIDATE_RETURN CPenSetupConfig::SetSpanToHiSetpoint(float &rfSpan) {
	T_CONFIG_VALIDATE_RETURN eRetVal = CONFIG_VALIDATE_NO_CHANGES;
	const float fEXTRA_HEADROOM = 100;

	// get a pointer to the modifiable furnace block
	CGeneralSetupConfig *pkGenCfg = pSETUP->GetGeneralSetupConfig();

	T_PFURNACESCONFIG ptFurnacesCfg = pkGenCfg->GetAMS2750FurnaceInfoBlock(CONFIG_MODIFIABLE);

	if (ptFurnacesCfg != NULL) {
		float fHighestSetpoint = -FLT_MAX;
		for (int iSetpointCount = 0; iSetpointCount < FURNACESCONFIG_SETPOINTS_SIZE; iSetpointCount++) {
			// check the setpoint is enabeld and if the level is higher than our current value
			if (ptFurnacesCfg->Setpoints[iSetpointCount].Enabled
					&& ( pSYSTEM_INFO->GetLocalTempFromDegC(ptFurnacesCfg->Setpoints[iSetpointCount].Level)
							> fHighestSetpoint)) {
				// this setpoint is higher therefore update our high value
				fHighestSetpoint = pSYSTEM_INFO->GetLocalTempFromDegC(ptFurnacesCfg->Setpoints[iSetpointCount].Level);
			}
		}
		//CR3068[START]
		float fHighSetPt;
		//std::setprecision(4);
		fHighSetPt = fHighestSetpoint + fEXTRA_HEADROOM;
		//CR3068[END]

		// now we have the highest value, check it is not -FLT_MAX still which would imply the 
		// setpoints are all disabled
		if (fHighestSetpoint != -FLT_MAX) {
			// the highest setpoint value has changed and must therefore be valid - now check if
			// the high setpoint value is the same as our passed in pen span
			//if( rfSpan != ( fHighestSetpoint + fEXTRA_HEADROOM ) )
			if (rfSpan != (fHighSetPt)) //CR3068
					{
				// they are different therefore update the span and let the calling method 
				// know there has been a change
				rfSpan = fHighestSetpoint + fEXTRA_HEADROOM;
				eRetVal = CONFIG_VALIDATE_CHANGES_MADE;

			}
		}
	}

	return eRetVal;
}


/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Configuration System
/// @n Filename:  LinearisationData.h
/// @n Description: Declaration for the CLinearisationData class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  3 Stability Project 1.0.1.1 7/2/2011 4:58:21 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  2 Stability Project 1.0.1.0 7/1/2011 4:27:47 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  1 V6 Firmware 1.0 8/9/2006 4:24:11 PM Roger Dawson  
// $
//
// **************************************************************************

#if !defined(AFX_LINEARISATIONDATA_H__512E2755_3AE7_4FDA_942F_A2764228AD7D__INCLUDED_)
#define AFX_LINEARISATIONDATA_H__512E2755_3AE7_4FDA_942F_A2764228AD7D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ConfigData.h"
#include "V6Config.h"

//**CConfigData*********************************************************************
///
/// @brief Virtual base class for the config item data attributes
/// 
/// Virtual base class for the config item data attributes
///
//****************************************************************************
class CLinearisationData: public CConfigData {
public:
	// Constructor
	CLinearisationData(T_LOOKUPTABLE *ptTable);

	// Destructor
	virtual ~CLinearisationData();

	// Method called to validate data entered by a user - not used
	virtual bool ValidateData(const QString const pwcDATA) {
		return true;
	}

	// Method called to validate data entered by the user
	static const bool ValidateData(const T_PLOOKUPTABLE ptNEW_TABLE_DATA, USHORT &rusFailedValue);

	// Method that updates the data based on the passed in string - not used
	virtual void UpdateData(const QString const pwcDATA) {
		;
	}

	// Method that returns the data as a string
	virtual const QString  GetDataAsString(const bool bINCLUDE_UNITS = false);

	// Method that returns a pointer to the data
	virtual void* GetData() const {
		return m_ptLinearisationTable;
	}

private:

	/// Variable used to store a pointer to the table
	T_PLOOKUPTABLE m_ptLinearisationTable;
};

#endif // !defined(AFX_LINEARISATIONDATA_H__512E2755_3AE7_4FDA_942F_A2764228AD7D__INCLUDED_)

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	Configuration
/// @n Filename: Layoutconfiguration.h 
/// @n Description: Layout configuration for OpPanel classes
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 47	Stability Project 1.44.1.1	7/2/2011 4:58:17 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 46	Stability Project 1.44.1.0	7/1/2011 4:27:08 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 45	V6 Firmware 1.44		9/23/2008 3:09:28 PM	Build Machine 
//		AMS2750 Merge
// 44	V6 Firmware 1.43		12/20/2006 3:30:33 PM Roger Dawson 
//		Phase 3b merges into the main build. Removed dependancy on
//		V6defines.h.
// $
// 
//
// **************************************************************************

#ifndef _LAYOUTCONFIGURATION_H
#define _LAYOUTCONFIGURATION_H

#include "DataItemBase.h"
#include "Configuration.h"
#include "V6Config.h"
#include "V6ResConstants.h"
#include "hw_defs.h"

#define DEFAULT_LAYOUT_INST 1
#define DEFAULT_TEMPLATE_INST 1
#define DEFAULT_SCREEN_INST 1
#define DEFAULT_VARBLOCK_INST 1

#define BLK_VARIABLE_TEXT REF_BASE_VARIABLE_DATATYPE+1

#define TEMPLATE_SCREEN_NUMBER 255
#define TEMPLATE_SCREEN_INST TEMPLATE_SCREEN_NUMBER
#define TEMPLATE_SCREEN_CONFIG_ID 5002

#define CANNED_SCREENS_INST 1001
#define REPLAY_SCREEN_INST 1002

#define REPLAY_SCREEN_NUMBER 254
#define REPLAY_SCREEN_CONFIG_ID 5003

#define HOTSOAK_SCREEN_INST 1003
#define HOTSOAK_SCREEN_NUMBER 253
#define HOTSOAK_SCREEN_CONFIG_ID 5004

class COpPanel;

/**Enumeration for the Object types */
typedef enum ObjectType {
	NoObject = 0,
	ExampleBar,
	DigitalObject,
	BarObject,
	TextObject,
	ScaleObject,
	BitmapObject,
	ChartObject,
	PenPointersObject,
	AlarmMrkrObject,
	CursorObject,
	ButtonObject,
	TabularDisplayObject,
	TUSObject,
	CircularChartObject,

	SUPPORTED_OBJECT_TYPES // keep at end of list 
} T_OBJECT_TYPE;

/**Enumeration for the Template/Screen type */
typedef enum {
	TPL_DPMS = 0,
	TPL_DPMS_BARS,
	TPL_CHRT_DPMS,
	TPL_CHRT_BARS,
	TPL_CHRT_DPMS_BARS,
	TPL_TABULAR_SCREEN,
	TPL_AMS2750_PROCESS_SCREEN,
	TPL_AMS2750_TUS_SCREEN,
	TPL_CIRC_CHRT_DPMS,

	TPL_LAST_CANNED, // keep this at end of canned template/screen types.

	TPL_ALARM = 100,
	TPL_MAXMIN,
	TPL_USER_VARS,
	TPL_SCRIPT_TIMERS,
	TPL_USER_COUNTER,
	TPL_STATUS,
	TPL_TOTALS,
	TPL_MSG_ALL,
	TPL_MSG_ALARMS,
	TPL_MSG_SYSTEM,
	TPL_MSG_DIAGNOSTICS,
	TPL_MSG_SECURITY,
	TPL_MSG_USER,
	//TPL_PLAYBACK,

	TPL_NP_LAST,

	TPL_CUSTOM = 1000,
	TPL_REPLAY,
	TPL_HOTSOAK,

} T_TEMPLATE_TYPE;

// Copy/paste support of layout items
typedef enum // description of what was pasted
{
	PASTE_NULL, PASTE_OBJECT, PASTE_WIDGET, PASTE_TEMPLATE, PASTE_SCREEN, PASTE_SELECTION
} PASTE_DESCRIPTION;

extern CLIPFORMAT cfLayout;

typedef QVector<T_LAYOUTITEM> CLayoutItemArray;
typedef QList<T_LAYOUTITEM> CSelectionList;

// The following map is used during the paste of a widget to link the objects within
// the widget (the LinkedObj chain). The key is the copied T_LAYOUTITEM and the value
// is the pasted T_LAYOUTITEM. See CLayoutConfiguration::PasteSelection for details.

typedef QMap<UINT, UINT> CLayoutItemMap;

// The following structure is used by a UI (e.g., OpPanel within Screen Designer) to
// give context to normal user copy/paste operations (as opposed to internal layout
// operations which happen to use the copy/paste mechanism, like saving a template in
// a layout to a file). Internal layout operations shouldn't need to specify this
// structure to the CLayoutConfiguration::PasteSelection method and can pass in NULL.

#define GETPASTESCREENOPTIONCAST void(__cdecl*)(void*,WCHAR*,BOOL&,T_LAYOUTITEM&)

typedef struct _extrapasteinfo {
	BOOL bSelectAfterPaste;		///< [in] Used in widget/object paste
	T_LAYOUTITEM ActiveScreenRef;		///< [in] Used in widget/object paste
	QRect rcActiveScreenClient;	///< [in] Used in widget paste
	T_LAYOUTITEM SelectedWidgetRef;		///< [in] Used in widget/object paste
	QRect rcSelectedWidgetClient;	///< [in] Used in object paste
	T_LAYOUTITEM SelectedObjectRef;		///< [in] Used in object paste
	QPoint ptPasteCaret;			///< [in] Used in widget/object paste
									///< [in] Used in screen paste
	void *pOpPanel;								///< [in] Used in screen paste
	void (*pGetPasteScreenOption)(void *pOpPanel, QString   pScreenName, BOOL &bUseSourceTemplate,
			T_LAYOUTITEM &DestinationTemplateRef);
	CLayoutItemArray TemplatesPasted;	///< [out] Used in template/screen paste
	CLayoutItemArray ScreensPasted;			///< [out] Used in screen paste
} EXTRAPASTEINFO, *PEXTRAPASTEINFO;

BOOL IsNull(T_LAYOUTITEM LayoutItem);
void SetNull(T_LAYOUTITEM &LayoutItem);

// The following structure is returned in an array by method IsValidToRun and identifies
// a problem with a layout item that prevents the layout configuration from being run on
// the recorder.

typedef struct _problem {
	T_LAYOUTITEM Template;				///< Template having problem
	T_LAYOUTITEM LayoutItem;		///< Layout item on template having problem
	T_PROBLEM Problem;				///< Problem with layout item
} PROBLEM, *PPROBLEM;

typedef QVector<PROBLEM> CProblemArray;

//**Class*********************************************************************
///
/// @brief Layout Configuration class
/// 
/// This class creates default layout configurations and provides general
/// functions for dealing with the CMM
///
//****************************************************************************
class CLayoutConfiguration: public CConfiguration {
public:
	static CLayoutConfiguration *m_pCopyLayout;	///< Source layout copied
	static BOOL m_bCopySingleSel;			///< TRUE => Single selection copy

	static PASTE_DESCRIPTION m_PasteDesc;	///< Description of what was pasted
	static T_LAYOUTITEM m_LastPastedItemRef;	///< Contains the T_LAYOUTITEM of the last
												///< layout item pasted (template, screen,
												///< widget, object). Useful for a single
												///< selection paste where it is necessary
												///< to get the T_LAYOUTITEM of this item
												///< pasted.
private:
	USHORT m_nextScreenInst;
	USHORT m_nextTemplateInst;
	USHORT m_nextWidgetInst;
	USHORT m_nextObjectInst[SUPPORTED_OBJECT_TYPES];
	REFERENCE m_CmmMode;										///< CMM layout config data is from working or current

	BOOL m_IsCustomLayout;
	BOOL m_ContainsBitmapObjects;
	BOOL m_MissingBCF;

	T_CONFIG_RETURN_VALUE DeleteWidgetandObjects(T_LAYOUTITEM *layoutItem);

public:
	CLayoutConfiguration(BOOL IsCannedScreens = FALSE);
	virtual ~CLayoutConfiguration(void);

	void ResetInstNos(BOOL IsCannedScreens = FALSE);

	T_CONFIG_RETURN_VALUE CreateEmptyConfig(void);
	virtual T_CONFIG_RETURN_VALUE CreateDefaultConfig(void);
	virtual T_CONFIG_VALIDATE_RETURN ValidateConfiguration(void);
	BOOL IsValidToRun(CProblemArray &ProblemArray, T_LAYOUTITEM *pLayoutItemToCheck = NULL);
	BOOL IsOffScreen(T_SCRTEMPLATE *pTplt, T_WIDGET *pWgt);
	BOOL IsOverlapping(T_SCRTEMPLATE *pTplt, int nWidgetListIndex, T_WIDGET *pWgt);

	// Method that loops through all the screen setting their states to disabled if 
	// showing a custom screen and the custom screen firmware option is disabled
	T_CONFIG_VALIDATE_RETURN CheckCustomScreens(T_LAYOUT *ptLayout);
	BOOL DisableCustomScreensForXSeriesLayoutInGR(T_LAYOUT *ptLayout);

	// Method that loops through all the screens checking if they are circular chart screens
	// The screen will be disabled if it is a circular chart screen and the circular chart
	// feature is not available
	T_CONFIG_VALIDATE_RETURN CheckCircularChartScreens(T_LAYOUT *ptLayout);

	// Method that loops through all the screens checking if they are a TUS mode screen
	// Various actions are taken depending on the outcome of this test and the state of
	// the TUS mode firmware option
	T_CONFIG_VALIDATE_RETURN CheckAMS2750TUSScreen(T_LAYOUT *ptLayout);

	// Method that loops through all the screens checking if they are a AMS2750D process screens
	// Various actions are taken depending on the outcome of this test and the state of
	// the AMS2750D Nadcap mode firmware option
	T_CONFIG_VALIDATE_RETURN CheckAMS2750ProcessScreen(T_LAYOUT *ptLayout);

	T_CONFIG_RETURN_VALUE CreateTemplateScreenConfig(void);
	T_CONFIG_RETURN_VALUE CreateReplayScreenConfig(void);
	T_CONFIG_RETURN_VALUE CreateHotSoakScreenConfig(void);

	void SetCMMmode(REFERENCE currentORworking);
	REFERENCE GetCMMmode();
	COpPanel *m_pOpPanel;

	BOOL CheckLayoutRefs(BLOCK_INFO *blockInfo);
	BOOL indexOfDataBlock(T_LAYOUTITEM *layoutItem, BLOCK_INFO *blockDetails);
	void ClearLayoutItem(T_LAYOUTITEM *layoutItem);
	T_CONFIG_RETURN_VALUE CreateStringBlock(BLOCK_INFO *blockInfo);
	T_CONFIG_RETURN_VALUE EnlargeStringBlock(BLOCK_INFO *blockInfo);

	// Get a Text string in the variable length CMM block
	WCHAR* GetTextString(short Offset);

	// Set a Text string in the variable length CMM block
	BOOL SetTextString(QString   str, short *Offset);

	//BLOCK_INFO GetBlockInfo(T_LAYOUTITEM *layoutItem);
	T_LAYOUTITEM BlockInfoToLayoutItem(BLOCK_INFO *blockinfo);
	static T_OBJECT_TYPE BlockTypeToObjectType(T_BLOCKTYPE ObjBlockType);
	T_DEV_TYPE GetRecorderType();
	BOOL IsMissingBCF() {
		return m_MissingBCF;
	}

	// Indicates the device is QVGA resolution (320*240)
	BOOL IsQVGA();

	// Indicates the device is VGA resolution (640*480)
	BOOL IsVGA();

	// Indicates the device is SVGA resolution (800*600)
	BOOL IsSVGA();

	// Indicates the device is XVGA resolution (1024*768)
	BOOL IsXVGA();

	// Add using Defaults
	T_CONFIG_RETURN_VALUE AddTemplate(BLOCK_INFO *blockInfo, USHORT templateInst = 0);
	T_CONFIG_RETURN_VALUE AddScreen(T_LAYOUTITEM *templateRef, BLOCK_INFO *blockInfo);
	T_CONFIG_RETURN_VALUE AddWidget(T_LAYOUTITEM *templateRef, BLOCK_INFO *blockInfo);
	T_CONFIG_RETURN_VALUE AddObject(T_LAYOUTITEM *WidgetRef, T_BLOCKTYPE ObjBlockType, BLOCK_INFO *blockInfo);

	// Deletion methods
	T_CONFIG_RETURN_VALUE DeleteScreen(T_LAYOUTITEM *layoutItem);
	T_CONFIG_RETURN_VALUE DeleteTemplate(T_LAYOUTITEM *layoutItem, BOOL bForce =
	FALSE);
	T_CONFIG_RETURN_VALUE DeleteWidget(T_LAYOUTITEM *layoutItem);
	T_CONFIG_RETURN_VALUE DeleteObject(T_LAYOUTITEM *layoutItem);

	// Copy/paste methods using a CMemFile/CDataItem and optionally the clipboard
	void CopySelection(CSelectionList &SelectionList, CDataItem &ar, BOOL bUseClipboard = FALSE);///< handles copy of layout items to archive

	void PasteSelection(CDataItem &ar, PEXTRAPASTEINFO pExtra = NULL, COpPanel *pkOpPanel = NULL);///< handles paste of layout items from archive

	// Methods relying on copy/paste
	BOOL InsertTemplateFromFile(CStorage &fileToLoadConfig, PEXTRAPASTEINFO pExtra = NULL);
	BOOL SaveTemplate(T_LAYOUTITEM *templateRef, const QString   const pConfigPathAndFileName, BOOL bIsValid = FALSE);

	virtual T_CONFIG_RETURN_VALUE LoadConfig(QFile &fileToLoadConfig, const TV_BOOL persistedLoad = FALSE);
	virtual T_CONFIG_RETURN_VALUE SaveConfig(QFile &fileToSaveConfig, const TV_BOOL persistedSave = FALSE);

	// Method that gets the relevant group number for the passed in screen
	const T_PEN_GROUPS GetScreenGroupNo(const USHORT usSCREEN_NO);

#ifdef DOCVIEW
	BOOL SaveScreenDesignerDibs(QString   pFilePath);
#endif

	/// 
	virtual T_CONFIG_RETURN_VALUE UpdateConfig(void);

	virtual void SetConfigurationId(const DWORD configurationId);

protected:
	// Helper copy methods used by CopySelection (don't call directly)
	void CopyObject(CDataItem &ar, BLOCK_INFO *blockInfo);	///< handles copy of an object to archive 

	// Helper paste methods used by PasteSelection (don't call directly)
	void PasteTemplate(CDataItem &ar, BYTE *pbyCMMblock, int &nBlocksRead, PEXTRAPASTEINFO pExtra, COpPanel *pkOpPanel);///< handles paste of a template from archive

	void PasteScreen(CDataItem &ar, BYTE *pbyCMMblock, int &nBlocksRead, PEXTRAPASTEINFO pExtra, COpPanel *pkOpPanel);///< handles paste of a screen from archive

	void PasteWidget(CDataItem &ar, BYTE *pbyCMMblock, int &nBlocksRead, T_LAYOUTITEM templateRef, BOOL bTemplatePaste,
			PEXTRAPASTEINFO pExtra, COpPanel *pkOpPanel);	///< handles paste of a widget from archive

	void PasteObject(CDataItem &ar, BYTE *pbyCMMblock, int &nBlocksRead, WORD wBlockType, PEXTRAPASTEINFO pExtra,
			COpPanel *pkOpPanel, USHORT &rusLastIndex);	///< handles paste of an object from archive

	// Method that updates a pasted pbjects channel list information
	void UpdatePasteObjChanList(COpPanel *pkOpPanel, T_PWIDGET ptWidget, T_PBASEOBJECT ptBaseObject,
			USHORT &rusLastIndex);

	void PerformSpecialPasteProcessing(CDataItem &ar, BLOCK_INFO *blockInfo);

};
// End of Class Declaration

#endif

/// @file 
/// **************************************************************************
/// ? Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Configuration System
/// @n Filename:  RecSetupCfgMgr.cpp
/// @n Description: Implementation for the CRecSetupCfgMgr class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  322  Aristos  1.315.1.4.1.0 9/19/2011 4:51:07 PM  Hemant(HAIL)  
//  Stability recorder source code (JI Release) updated for WatchDog
//  Timer functionality.
//  321  Stability Project 1.315.1.4  7/11/2011 7:14:47 PM  Hemant(HAIL) 
// Files has been updated for fixing issue of "Restrict Pen limit to
//  32 in a Group". This chnages has been done in TMS application. Source
//  files related to configuration are same in TMS and V6App.
//  320  Stability Project 1.315.1.3  7/2/2011 5:00:18 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  319  Stability Project 1.315.1.2  7/1/2011 4:38:48 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
// $
//
// Vellaidurai V 2/07/2013  Fixed PAR - 1-2NCR8HB: Remove RT Databus from Credits as it is not supported for now
//		Kranti 		1-1VK5GH3		Recorder does not allow to configure SNTP synch period less than 10 minutes
//		PSR - Reverted the fix for 1-1VK5GH3		Recorder does not allow to configure SNTP synch period less than 10 minutes
// **************************************************************************

#include "RecSetupCfgMgr.h"
#include "ConfigInterface.h"
#include "ConfigBranch.h"
#include "ConfigItem.h"
#include "V6globals.h"
#include "ConfigData.h"
#include "V6ResourceBase.h"
#include "V6UIResource.h"
#include "SlotMap.h"
#include "V6Types.h"
#include "Conversion.h"
#include "StringUtils.h"
#include "Registry.h"
#include "ATECal.h"
#include "OPL.h"
#include <math.h>
#include "LogRec.h"
#include "LinearisationData.h"
#include "EventControl.h"
#include "LogDeviceStatus.h"
#include "BatchManager.h"
#include "PassSyncEngine.h"
#include "AMS2750SensorCalData.h"
#include "AMS2750CalConfigData.h"
#include "AMS2750TUSMgr.h"
#include "MultiPointCalData.h"
#include "ThreadInfo.h"

// E528446
#include "OpPanelIncludes.h"
//

extern CMutex m_GlbSetupMutex;

#if ! defined ( TTR6SETUP )
#include "PenManager.h"
#include "txscheduler.h"
#endif

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif

// Static const/initialsation
std::auto_ptr<CRecSetupCfgMgr> CRecSetupCfgMgr::ms_kConfigSysMgr;
QMutex ms_hCreationMutex;

// GENERAL DEVICE Info
const QString  CRecSetupCfgMgr::ms_strDEVICE_DETAILS = L"DEV_DET";
const QString  CRecSetupCfgMgr::ms_strDEVICE_NAME = L"DEV_NAME";
const QString  CRecSetupCfgMgr::ms_strDEVICE_DESC = L"DEV_DESC";
const QString  CRecSetupCfgMgr::ms_strDEVICE_ID = L"DEV_ID";

// Group Name List - used for various items including events
QString  CRecSetupCfgMgr::ms_strGroupList = "";

// PENS
// Pen key names
const QString  CRecSetupCfgMgr::ms_strPEN_KEY = L"PEN";
const QString  CRecSetupCfgMgr::ms_strENABLED_KEY = L"EN";
const QString  CRecSetupCfgMgr::ms_strMATH_TYPE_KEY = L"M_TYPE";
const QString  CRecSetupCfgMgr::ms_strMATHS_EXPRESSION_KEY = L"MATHS";
const QString  CRecSetupCfgMgr::ms_strEDIT_SCRIPT_KEY = L"SCRIPT";
const QString  CRecSetupCfgMgr::ms_strGROUP_KEY = L"GROUP";
const QString  CRecSetupCfgMgr::ms_strTAG_KEY = L"TAG";
const QString  CRecSetupCfgMgr::ms_strDESC_KEY = L"DESCRIPTION";
const QString  CRecSetupCfgMgr::ms_strSCALE_KEY = L"SCALE";
const QString  CRecSetupCfgMgr::ms_strTOT_KEY = L"TOT";
const QString  CRecSetupCfgMgr::ms_strALM_KEY = L"ALM";
const QString  CRecSetupCfgMgr::ms_strLOG_KEY = L"LOG";

// Pen Title Names

// Pen List Item Names
QString  CRecSetupCfgMgr::ms_strPenMathTypeList = "";
QString  CRecSetupCfgMgr::ms_strPenLogLogTypeList = "";
QString  CRecSetupCfgMgr::ms_strPenGroupList = "";
QString  CRecSetupCfgMgr::ms_strPenLogScaleList = "";
QString  CRecSetupCfgMgr::ms_strPenScaleAutoList = "";
QString  CRecSetupCfgMgr::ms_strAlarmEnableTypeList = "";
QString  CRecSetupCfgMgr::ms_strAlarmTypeList = "";
QString  CRecSetupCfgMgr::ms_strPenLogStyleList = "";
QString  CRecSetupCfgMgr::ms_strPenLogAlignList = "";

// Scale key names
const QString  CRecSetupCfgMgr::ms_strZERO_KEY = L"ZERO";
const QString  CRecSetupCfgMgr::ms_strSPAN_KEY = L"SPAN";
const QString  CRecSetupCfgMgr::ms_strUNITS_KEY = L"UNIT";
const QString  CRecSetupCfgMgr::ms_strMAJOR_DIVS_KEY = L"MJR_DIVS";
const QString  CRecSetupCfgMgr::ms_strMINOR_DIVS_KEY = L"MIN_DIVS";
const QString  CRecSetupCfgMgr::ms_strSTART_DECADE_KEY = L"START_DEC";
const QString  CRecSetupCfgMgr::ms_strNUM_DECADES_KEY = L"NUM_DEC";
const QString  CRecSetupCfgMgr::ms_strAUTO_DIVS_KEY = L"AUTO_DIVS";
const QString  CRecSetupCfgMgr::ms_strLOG_SCALE_KEY = L"LOG_SCALE";

// Totaliser key names
const QString  CRecSetupCfgMgr::ms_strTOT_TYPE_KEY = L"TYPE";
const QString  CRecSetupCfgMgr::ms_strTOT_NO_BACK_FLOW_KEY = L"NO_BACK";
const QString  CRecSetupCfgMgr::ms_strTOT_BACK_FLOW_LEVEL_KEY = L"BF_LEV";
const QString  CRecSetupCfgMgr::ms_strTOT_RESTRICT_RANGE_KEY = L"RESTRICT";
const QString  CRecSetupCfgMgr::ms_strTOT_CARRY_ON_ROLL_KEY = L"CARRY_ON";
const QString  CRecSetupCfgMgr::ms_strTOT_INCLUDE_COOL_KEY = L"INC_COOL";
const QString  CRecSetupCfgMgr::ms_strTOT_ADD_TO_MSG_LIST_KEY = L"ADD_TO";
const QString  CRecSetupCfgMgr::ms_strTOT_TEMP_INPUT_UNITS_KEY = L"TEMP_INP";
const QString  CRecSetupCfgMgr::ms_strTOT_TAG_KEY = L"TAG";
const QString  CRecSetupCfgMgr::ms_strTOT_MIN_RANGE_KEY = L"MIN_R";
const QString  CRecSetupCfgMgr::ms_strTOT_MAX_RANGE_KEY = L"MAX_R";
const QString  CRecSetupCfgMgr::ms_strTOT_TIME_FACTOR_KEY = L"TIME_F";
const QString  CRecSetupCfgMgr::ms_strTOT_UNIT_FACTOR_KEY = L"UNIT_F";
const QString  CRecSetupCfgMgr::ms_strTOT_TEMP_START_KEY = L"TEMP_S";
const QString  CRecSetupCfgMgr::ms_strTOT_TEMP_REF_KEY = L"TEMP_R";
const QString  CRecSetupCfgMgr::ms_strTOT_ZFACTOR_KEY = L"ZFACT";
const QString  CRecSetupCfgMgr::ms_strTOT_COMP_VAL_KEY = L"COMP_V";
const QString  CRecSetupCfgMgr::ms_strTOT_UNITS_KEY = L"UNITS";
const QString  CRecSetupCfgMgr::ms_strTOT_RESET16MILLION_RANGE_KEY = L"Reset at 16M";

// Totaliser List Names
QString  CRecSetupCfgMgr::ms_strPenTotTypeList = "";
QString  CRecSetupCfgMgr::ms_strPenTotTempUnitsList = "";

// RAV key names
const QString  CRecSetupCfgMgr::ms_strRAV_KEY = L"RAV";
const QString  CRecSetupCfgMgr::ms_strRAV_SAMPLE_INTERVAL_KEY = L"INT";
const QString  CRecSetupCfgMgr::ms_strRAV_NO_OF_SAMPLES_KEY = L"NO";
const QString  CRecSetupCfgMgr::ms_strRAV_PREFILL_KEY = L"PRE";

// Alarm key names
const QString  CRecSetupCfgMgr::ms_strPEN_ALARM_ENABLE_TYPE_KEY = L"EN_TYPE";
const QString  CRecSetupCfgMgr::ms_strPEN_ALARM_TYPE_KEY = L"TYPE";
const QString  CRecSetupCfgMgr::ms_strPEN_ALARM_LEVEL_KEY = L"LEV";
const QString  CRecSetupCfgMgr::ms_strPEN_ALARM_DEV_LEVEL_KEY = L"DEV_LEV";
const QString  CRecSetupCfgMgr::ms_strPEN_ALARM_LATCHED_KEY = L"LATCH";
const QString  CRecSetupCfgMgr::ms_strPEN_ALARM_USE_HYST_KEY = L"_USE_HYST";
const QString  CRecSetupCfgMgr::ms_strPEN_ALARM_HYST_LEVEL_KEY = L"_HYST";
const QString  CRecSetupCfgMgr::ms_strPEN_ALARM_USE_DAMP_KEY = L"DAMP";
const QString  CRecSetupCfgMgr::ms_strPEN_ALARM_CHG_LOG_KEY = L"CHG_LOG";
const QString  CRecSetupCfgMgr::ms_strPEN_ALARM_MARK_CHART_KEY = L"MARK";
const QString  CRecSetupCfgMgr::ms_strPEN_ALARM_AS_EVENT_KEY = L"EVENT";
const QString  CRecSetupCfgMgr::ms_strPEN_ALARM_DEV_PEN_NO_KEY = L"DEV_PEN";
const QString  CRecSetupCfgMgr::ms_strPEN_ALARM_DIG_EN_KEY = L"DIG_EN";
const QString  CRecSetupCfgMgr::ms_strPEN_ALARM_RELAY_OUT_KEY = L"RELAY";
const QString  CRecSetupCfgMgr::ms_strPEN_ALARM_DAMPING_TIME_KEY = L"DMP_TM";
const QString  CRecSetupCfgMgr::ms_strPEN_ALARM_CHANGE_ALLOW_KEY = L"CHG_ALW";
const QString  CRecSetupCfgMgr::ms_strPEN_ALARM_USE_REFLASH_KEY = L"USE_RF";
const QString  CRecSetupCfgMgr::ms_strPEN_ALARM_REFLASH_TIME_KEY = L"RF_TM";
const QString  CRecSetupCfgMgr::ms_strPEN_ALARM_SEND_EMAIL_KEY = L"EMAIL";
const QString  CRecSetupCfgMgr::ms_strPEN_ALARM_EMAIL_RECIPIENTS_KEY = L"RECIP";
const QString  CRecSetupCfgMgr::ms_strPEN_ALARM_RATE_OF_CHANGE_TIME_KEY = L"CHG_TIME";

// Logging key names
const QString  CRecSetupCfgMgr::ms_strPEN_LOG_LOG_TYPE_KEY = L"LTYPE";
const QString  CRecSetupCfgMgr::ms_strPEN_LOG_STYLE_KEY = L"STYLE";
const QString  CRecSetupCfgMgr::ms_strPEN_LOG_RATE_UNITS_KEY = L"R_UNITS";
const QString  CRecSetupCfgMgr::ms_strPEN_LOG_RATE_KEY = L"RATE";
const QString  CRecSetupCfgMgr::ms_strPEN_LOG_ALARM_RATE_UNITS_KEY = L"A_R_UNITS";
const QString  CRecSetupCfgMgr::ms_strPEN_LOG_ALARM_RATE_KEY = L"ALM_RATE";
const QString  CRecSetupCfgMgr::ms_strPEN_LOG_PRETRIGGER_KEY = L"PRETRIG";
const QString  CRecSetupCfgMgr::ms_strPEN_LOG_ALIGN_KEY = L"ALIGN";
const QString  CRecSetupCfgMgr::ms_strPEN_LOG_USE_FUZZY_AUTO_FIT_KEY = L"USE_FAUTO_FIT";
const QString  CRecSetupCfgMgr::ms_strPEN_LOG_FBAND1_KEY = L"FBAND1";
const QString  CRecSetupCfgMgr::ms_strPEN_LOG_USE_FBAND2_KEY = L"USE_FBAND2";
const QString  CRecSetupCfgMgr::ms_strPEN_LOG_FBAND2_KEY = L"FBAND2";

// Logging key list
QString  CRecSetupCfgMgr::ms_strPenLogRateUnitsList = "";
QString  CRecSetupCfgMgr::ms_strPenLogRateShortUnitsList = "";
QString  CRecSetupCfgMgr::ms_strPenLogRateMsList = "";

// ANALOGUE INPUTS
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_KEY = L"A_IN";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_TYPE_KEY = L"TYPE";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_SQRT_EXTRACT_KEY = L"SQRT";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_ACQ_RATE_KEY = L"ACQ";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_ENG_ZERO_KEY = L"ZERO";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_ENG_SPAN_KEY = L"SPAN";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_LABEL_KEY = L"LAB";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_TIED_TO_KEY = L"TIED";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_CALIBRATION_KEY = L"CAL";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_DAMP_LEVEL_KEY = L"DMP_LEV";

// Calibration Keys
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_CALIB_TYPE_KEY = L"TYP";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_CALIB_SINGLE_POINT_KEY = L"SING";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_CALIB_DUAL_RANGE_KEY = L"DRGE";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_CALIB_MULTI_POINT_TABLE_KEY = L"MULT";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_CALIB_MULTI_POINT_LAST_CAL_KEY = L"CALD";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_CALIB_DUAL_PT1_ENG_KEY = L"PT1_ENG";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_CALIB_DUAL_PT1_ADJ_KEY = L"PT1_ADJ";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_CALIB_DUAL_PT2_ENG_KEY = L"PT2_ENG";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_CALIB_DUAL_PT2_ADJ_KEY = L"PT2_ADJ";

// Analogue Input List Names
QString  CRecSetupCfgMgr::ms_strAINTypeList = "";
QString  CRecSetupCfgMgr::ms_strAINAcqRateList = "";
QString  CRecSetupCfgMgr::ms_strEZAINAcqRateList = "";
QString  CRecSetupCfgMgr::ms_strAINTCRTAcqRateList = "";
QString  CRecSetupCfgMgr::ms_strAINLinModeList = "";
QString  CRecSetupCfgMgr::ms_strAINRTTypeList = "";
QString  CRecSetupCfgMgr::ms_strAINEZRTTypeList = "";
QString  CRecSetupCfgMgr::ms_strAINUpScaleBurnOutList = "";
QString  CRecSetupCfgMgr::ms_strAINBurnOutSelList = "";
QString  CRecSetupCfgMgr::ms_strAINActiveBurnOutList = "";
QString  CRecSetupCfgMgr::ms_strAINTCTypeList = "";
QString  CRecSetupCfgMgr::ms_strAINCJCMethodList = "";
QString  CRecSetupCfgMgr::ms_strAINSqrtExtractList = "";
QString  CRecSetupCfgMgr::ms_strAINRangePresetVoltsList = "";
QString  CRecSetupCfgMgr::ms_strAINRangePresetAmpsList = "";
QString  CRecSetupCfgMgr::ms_strAINRangePresetOhmsList = "";
QString  CRecSetupCfgMgr::ms_strAINCalibrationTypesList = "";
QString  CRecSetupCfgMgr::ms_strAINTableGroupList = "";

// Linear Channel Keys
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_LIN_MODE_KEY = L"MODE";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_LIN_RANGE_PRESET_KEY = L"PRE";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_LIN_UNITS_KEY = L"UNIT";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_LIN_USER_LOW_LIMIT_KEY = L"LO";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_LIN_USER_HIGH_LIM_KEY = L"HI";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_LIN_VOLTAGE_RANGE_KEY = L"V_RGE";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_LINEARISATION_TABLE_KEY = L"LIN_TBL";
// Linear Channel List
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_LIN_VOLTAGE_RANGE_LIST = L"mV|V|";

// TC Channel Keys
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_TC_UP_SCALE_BURN_OUT_KEY = L"UP";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_TC_ACTIVE_BURN_OUT_KEY = L"ACT";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_TC_TYPE_KEY = L"CT_TYPE";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_TC_CJC_KEY = L"CJC";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_TC_CJC_AIN_KEY = L"CJC_AIN";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_TC_CJC_EXT_SPEC_KEY = L"CJC_EXT";

// RT Channel Keys
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_RT_TYPE_KEY = L"RT_TYPE";

// AMS2750 Sensor Keys
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_AMS2750_KEY = L"AMS";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_AMS2750_TUS_TC_KEY = L"TUS";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_AMS2750_CONTROL_TC_KEY = L"CTRL";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_AMS2750_USAGE_TRACK_KEY = L"TRK";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_AMS2750_SERIAL_NO_KEY = L"SNO";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_AMS2750_TC_POS_KEY = L"POS";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_AMS2750_TC_MANF_KEY = L"MANF";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_AMS2750_TC_TYPE_KEY = L"TYPE";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_AMS2750_LOAD_TC_KEY = L"LOAD";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_AMS2750_TC_RENEW_DATE_KEY = L"RENEW";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_AMS2750_CAL_TRACK_KEY = L"CAL";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_AMS2750_TC_NEXT_CALIB_DATE_KEY = L"NEXT";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_AMS2750_TC_SENSOR_CAL_TABLE_KEY = L"SENS";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_IN_AMS2750_TC_CERT_NO_KEY = L"CERT";

// AMS2750 Sensor Lists
QString  CRecSetupCfgMgr::ms_strAnalogueInAMS2750SensorTypeListKey = "";

// Demo Channel List Names
QString  CRecSetupCfgMgr::ms_strDemoWaveTypeList = "";

// Demo Channel Key Names
const QString  CRecSetupCfgMgr::ms_strDEMO_CHAN_KEY = L"DEMO";
const QString  CRecSetupCfgMgr::ms_strDEMO_CHAN_WAVE_TYPE_KEY = L"TYPE";
const QString  CRecSetupCfgMgr::ms_strDEMO_CHAN_WAVE_DUR_KEY = L"DUR";
const QString  CRecSetupCfgMgr::ms_strDEMO_CHAN_NOISE_KEY = L"NOISE";

// Events Properties
const QString  CRecSetupCfgMgr::ms_strEVENTS_KEY = L"EVENTS";
const QString  CRecSetupCfgMgr::ms_strEVENTS_ENABLED_KEY = L"EN";
const QString  CRecSetupCfgMgr::ms_strEVENTS_NAME_KEY = L"NAME";
const QString  CRecSetupCfgMgr::ms_strEVENTS_CAUSES_KEY = L"CAUSES";
const QString  CRecSetupCfgMgr::ms_strEVENTS_IND_CAUSE_KEY = L"IND_C";
const QString  CRecSetupCfgMgr::ms_strEVENTS_EFFECTS_KEY = L"EFFECTS";
const QString  CRecSetupCfgMgr::ms_strEVENTS_IND_EFFECT_KEY = L"IND_E";

// Event Cause Properties
const QString  CRecSetupCfgMgr::ms_strEVENTS_CAUSE_ENABLED_KEY = L"EN";
const QString  CRecSetupCfgMgr::ms_strEVENTS_CAUSE_TYPE_KEY = L"TYPE";
const QString  CRecSetupCfgMgr::ms_strEVENTS_CAUSE_SUBTYPE_KEY = L"SUBT";
const QString  CRecSetupCfgMgr::ms_strEVENTS_CAUSE_DATA_KEY = L"DATA";
const QString  CRecSetupCfgMgr::ms_strEVENTS_CAUSE_ALARM_DATA_KEY = L"ALM";
const QString  CRecSetupCfgMgr::ms_strEVENTS_CAUSE_SCHED_DATE_TIME_KEY = L"DATE";
const QString  CRecSetupCfgMgr::ms_strEVENTS_CAUSE_SCHED_PERIOD_KEY = L"PER";
const QString  CRecSetupCfgMgr::ms_strEVENTS_CAUSE_SCHED_ALIGN_KEY = L"ALGN";
const QString  CRecSetupCfgMgr::ms_strEVENTS_CAUSE_SCHED_DOW_KEY = L"DOW";
const QString  CRecSetupCfgMgr::ms_strEVENTS_CAUSE_SCHED_COUNT_KEY = L"CNT";
const QString  CRecSetupCfgMgr::ms_strEVENTS_CAUSE_COUNTER_TRIGGER_KEY = L"TRIG";

// Event Cause Lists
QString  CRecSetupCfgMgr::ms_strEventsCauseTypesList = "";
QString  CRecSetupCfgMgr::ms_strEventsCauseAlarmSubTypesList = "";
QString  CRecSetupCfgMgr::ms_strEventsCauseTotaliserSubTypesList = "";
QString  CRecSetupCfgMgr::ms_strEventsCauseDigInputsTypesList = "";
QString  CRecSetupCfgMgr::ms_strEventsCauseSchedEventTypesList = "";
QString  CRecSetupCfgMgr::ms_strEventsCauseSchedEventAlignList = "";
QString  CRecSetupCfgMgr::ms_strEventsCauseSystemSubTypesList = "";
QString  CRecSetupCfgMgr::ms_strEventsCauseUserActionSubTypesList = "";
QString  CRecSetupCfgMgr::ms_strEventsCauseUserActionSubTypesListQx = "";
QString  CRecSetupCfgMgr::ms_strEventsCauseUserActionSubTypesListEz = "";
QString  CRecSetupCfgMgr::ms_strEventsCauseBatchSubTypesList = "";
QString  CRecSetupCfgMgr::ms_strEventsCauseTUSSubTypesList = "";
QString  CRecSetupCfgMgr::ms_strEventsCauseAMS2750TimersSubTypesList = "";
QString  CRecSetupCfgMgr::ms_strEventsCauseAMS2750TimersAlertTypeList = "";

// Event Effect Properties
const QString  CRecSetupCfgMgr::ms_strEVENTS_EFFECT_ENABLED_KEY = L"EN";
const QString  CRecSetupCfgMgr::ms_strEVENTS_EFFECT_TYPE_KEY = L"TYPE";
const QString  CRecSetupCfgMgr::ms_strEVENTS_EFFECT_SUBTYPE_KEY = L"SUBT";
const QString  CRecSetupCfgMgr::ms_strEVENTS_EFFECT_DATA_KEY = L"DATA";
const QString  CRecSetupCfgMgr::ms_strEVENTS_EFFECT_ALARM_DATA_KEY = L"ALM";
const QString  CRecSetupCfgMgr::ms_strEVENTS_EFFECT_DISPLAY_EVENT_KEY = L"DISP";
const QString  CRecSetupCfgMgr::ms_strEVENTS_EFFECT_MARK_CHART_KEY = L"MARK";
const QString  CRecSetupCfgMgr::ms_strEVENTS_EFFECT_SCREEN_NAME_KEY = L"SCRN";
const QString  CRecSetupCfgMgr::ms_strEVENTS_EFFECT_SCREEN_BACKLIGHT_ON_OFF_KEY = L"BACK";
const QString  CRecSetupCfgMgr::ms_strEVENTS_EFFECT_EMAIL_RECIPIENTS_KEY = L"RECIP";
const QString  CRecSetupCfgMgr::ms_strEVENTS_EFFECT_EMAIL_EMBED_SCREENSHOT_KEY = L"EMBED";
const QString  CRecSetupCfgMgr::ms_strEVENTS_EFFECT_EMAIL_MESSAGE_KEY = L"MSG";
const QString  CRecSetupCfgMgr::ms_strEVENTS_EFFECT_COUNTER_RESET_OR_INC_KEY = L"RST_INC";
const QString  CRecSetupCfgMgr::ms_strEVENTS_EFFECT_COUNTER_RESET_KEY = L"RST";
const QString  CRecSetupCfgMgr::ms_strEVENTS_EFFECT_COUNTER_INCREMENT_KEY = L"INC";
const QString  CRecSetupCfgMgr::ms_strEVENTS_EFFECT_DELAYED_EVENT_DELAY_TIME_KEY = L"TIME";
const QString  CRecSetupCfgMgr::ms_strEVENTS_EFFECT_SOUND_PLAY_MODE_KEY = L"SND";
const QString  CRecSetupCfgMgr::ms_strEVENTS_EFFECT_MARKER_PRESET_SEL_KEY = L"PRE_S";
const QString  CRecSetupCfgMgr::ms_strEVENTS_EFFECT_PEN_SEL_TYPE_KEY = L"PEN_S";
const QString  CRecSetupCfgMgr::ms_strEVENTS_EFFECT_GROUP_SEL_KEY = L"GRP";
const QString  CRecSetupCfgMgr::ms_strEVENTS_EFFECT_REPORT_SEL_KEY = L"REP";
const QString  CRecSetupCfgMgr::ms_strEVENTS_EFFECT_CLEAR_MSG_SEL_KEY = L"MSG_TYP";
const QString  CRecSetupCfgMgr::ms_strEVENTS_EFFECT_PRINT_SCREEN_EXTERNAL_MEDIA_KEY = L"E_MED";

// Event Effect Lists
QString  CRecSetupCfgMgr::ms_strEventsEffectsTypesList = "";
QString  CRecSetupCfgMgr::ms_strEventsEffectsLoggingSubTypesList = "";
QString  CRecSetupCfgMgr::ms_strEventsEffectsTotaliserSubTypesList = "";
QString  CRecSetupCfgMgr::ms_strEventsEffectsDigOutputsSubTypesList = "";
QString  CRecSetupCfgMgr::ms_strEventsEffectsEmailSubTypesList = "";
QString  CRecSetupCfgMgr::ms_strEventsEffectsScreenChangeScreenList = "";
QString  CRecSetupCfgMgr::ms_strEventsEffectsCountersSubTypesList = "";
QString  CRecSetupCfgMgr::ms_strEventsEffectsCountersResetOrIncList = "";
QString  CRecSetupCfgMgr::ms_strEventsEffectsChartControlSubTypeList = "";
QString  CRecSetupCfgMgr::ms_strEventsEffectsTimersSubTypeList = "";
QString  CRecSetupCfgMgr::ms_strEventsEffectsSoundSubTypeList = "";
QString  CRecSetupCfgMgr::ms_strEventsEffectsSoundPlayModeList = "";
QString  CRecSetupCfgMgr::ms_strEventsEffectsMarkerModeList = "";
QString  CRecSetupCfgMgr::ms_strEventsEffectsMarkerPresetsList = "";
QString  CRecSetupCfgMgr::ms_strEventsEffectsPenSelTypesList = "";
QString  CRecSetupCfgMgr::ms_strEventsEffectsBatchSubTypeList = "";
QString  CRecSetupCfgMgr::ms_strEventsEffectsAlarmSelTypesList = "";
QString  CRecSetupCfgMgr::ms_strEventsEffectsChartControlSelTypesList = "";
QString  CRecSetupCfgMgr::ms_strEventsEffectsReportNamesList = "";
QString  CRecSetupCfgMgr::ms_strEventsEffectsPrintScreenSubTypeList = "";
QString  CRecSetupCfgMgr::ms_strEventsEffectsPrintScreenExternalMediaList = "";
QString  CRecSetupCfgMgr::ms_strEventsEffectsScreenSubTypeList = "";
QString  CRecSetupCfgMgr::ms_strEventsEffectsScreenBacklightOnOffList = "";
QString  CRecSetupCfgMgr::ms_strEventsEffectsMsgTypeList = "";

// E528446
QString  CRecSetupCfgMgr::ms_strEventsEffectChartspeedSubTypesList = "";
//

// Sounds List
QString  CRecSetupCfgMgr::ms_strSoundList = "";

// Counter Properties
const QString  CRecSetupCfgMgr::ms_strCOUNTERS_KEY = L"CTRS";
const QString  CRecSetupCfgMgr::ms_strCOUNTERS_ENABLED_KEY = L"EN";
const QString  CRecSetupCfgMgr::ms_strCOUNTERS_NAME_KEY = L"NAME";
const QString  CRecSetupCfgMgr::ms_strCOUNTERS_START_AT_KEY = L"START";
const QString  CRecSetupCfgMgr::ms_strCOUNTERS_ROLLOVER_AT_KEY = L"ROLL";

// Screen Saver Properties
const QString  CRecSetupCfgMgr::ms_strSCREEN_SAVER_KEY = L"SVR";
const QString  CRecSetupCfgMgr::ms_strSCREEN_SAVER_ENABLED_KEY = L"SVR_EN";
const QString  CRecSetupCfgMgr::ms_strSCREEN_SAVER_MODE_KEY = L"SVR_MODE";
const QString  CRecSetupCfgMgr::ms_strSCREEN_SAVER_TYPE_KEY = L"SVR_TYPE";
const QString  CRecSetupCfgMgr::ms_strSCREEN_SAVER_DIM_KEY = L"SVR_DIM";
const QString  CRecSetupCfgMgr::ms_strSCREEN_SAVER_TIMEOUT_KEY = L"SVR_TIME";
const QString  CRecSetupCfgMgr::ms_strSCREEN_SAVER_DIM_BRIGHT_KEY = L"SVR_DIM_B";
const QString  CRecSetupCfgMgr::ms_strSCREEN_SAVER_MODE_TIMES_KEY = L"SVR_TIME";

// Screen Chart Properties
const QString  CRecSetupCfgMgr::ms_strSCREEN_CHART_KEY = L"SCRN_CHART";
const QString  CRecSetupCfgMgr::ms_strSCREEN_CHART_FAST_SPEED_KEY = L"SFAST";
const QString  CRecSetupCfgMgr::ms_strSCREEN_CHART_MED_SPEED_KEY = L"SMED";
const QString  CRecSetupCfgMgr::ms_strSCREEN_CHART_SLOW_SPEED_KEY = L"SSLOW";
const QString  CRecSetupCfgMgr::ms_strSCREEN_CIRC_CHART_FAST_SPEED_KEY = L"CFAST";
const QString  CRecSetupCfgMgr::ms_strSCREEN_CIRC_CHART_MED_SPEED_KEY = L"CMED";
const QString  CRecSetupCfgMgr::ms_strSCREEN_CIRC_CHART_SLOW_SPEED_KEY = L"CSLOW";
const QString  CRecSetupCfgMgr::ms_strSCREEN_CIRC_CHART_HOUR_ALIGNMENT_KEY = L"CHA";
const QString  CRecSetupCfgMgr::ms_strSCREEN_CIRC_CHART_DAY_ALIGNMENT_KEY = L"CDA";
const QString  CRecSetupCfgMgr::ms_strSCREEN_CHART_BIAS_KEY = L"BIAS";

// Screen Chart Lists
QString  CRecSetupCfgMgr::ms_strScreenChartSpeedFastList = "";
QString  CRecSetupCfgMgr::ms_strScreenChartSpeedMedList = "";
QString  CRecSetupCfgMgr::ms_strScreenChartSpeedSlowList = "";
QString  CRecSetupCfgMgr::ms_strScreenCircChartSpeedFastList = "";
QString  CRecSetupCfgMgr::ms_strScreenCircChartSpeedMedList = "";
QString  CRecSetupCfgMgr::ms_strScreenCircChartSpeedSlowList = "";
QString  CRecSetupCfgMgr::ms_strScreenCircChartDayAlignmentList = "";

// Screen Tabular Display Properties
const QString  CRecSetupCfgMgr::ms_strSCREEN_TAB_DISP_KEY = L"TAB_DISP";
const QString  CRecSetupCfgMgr::ms_strSCREEN_TAB_DISP_UPDATE_METHOD_KEY = L"TAB_METH";
const QString  CRecSetupCfgMgr::ms_strSCREEN_TAB_DISP_UPDATE_PERIOD_KEY = L"TAB_PER";
const QString  CRecSetupCfgMgr::ms_strSCREEN_TAB_DISP_ALIGN_KEY = L"TAB_ALIGN";

// Screen Tabular Display List
QString  CRecSetupCfgMgr::ms_strScreenTabDispUpdateMethodList = "";

// Printer Properties
const QString  CRecSetupCfgMgr::ms_strPRINTER_KEY = L"PRN";
const QString  CRecSetupCfgMgr::ms_strPRINTER_ALLOW_PRINT_KEY = L"ALW";
const QString  CRecSetupCfgMgr::ms_strPRINTER_LETTER_KEY = L"LET";
const QString  CRecSetupCfgMgr::ms_strPRINTER_PORTRAIT_KEY = L"POR";
const QString  CRecSetupCfgMgr::ms_strPRINTER_DEVICE_NAME_KEY = L"NAME";
const QString  CRecSetupCfgMgr::ms_strPRINTER_COLOUR_PRINTER_KEY = L"COL";
const QString  CRecSetupCfgMgr::ms_strPRINTER_PCL_LANGUAGE_KEY = L"PCL";
const QString  CRecSetupCfgMgr::ms_strPRINTER_PORT_KEY = L"PRT";
const QString  CRecSetupCfgMgr::ms_strPRINTER_FIT_TO_PAGE_KEY = L"FIT";

// Printer Lists
QString  CRecSetupCfgMgr::ms_strPrinterSizeList = "";
QString  CRecSetupCfgMgr::ms_strPrinterOrientationList = "";
QString  CRecSetupCfgMgr::ms_strPrinterPclLanguageList = "";
QString  CRecSetupCfgMgr::ms_strPrinterPortList = "";

// Batch Properties
const QString  CRecSetupCfgMgr::ms_strBATCH_KEY = L"BATCH";
const QString  CRecSetupCfgMgr::ms_strBATCH_GENERAL_KEY = L"GEN";
const QString  CRecSetupCfgMgr::ms_strBATCH_GENERAL_PAUSE_CHART_KEY = L"PAUSE";
const QString  CRecSetupCfgMgr::ms_strBATCH_GENERAL_START_LOGGING_KEY = L"START_L";
const QString  CRecSetupCfgMgr::ms_strBATCH_GENERAL_STOP_LOGGING_KEY = L"STOP_L";
const QString  CRecSetupCfgMgr::ms_strBATCH_GENERAL_DIRECT_INPUT_KEY = L"DIR";
const QString  CRecSetupCfgMgr::ms_strBATCH_GENERAL_USE_USER_ID_KEY = L"USER";
const QString  CRecSetupCfgMgr::ms_strBATCH_GENERAL_USE_DESC_KEY = L"DESC";
const QString  CRecSetupCfgMgr::ms_strBATCH_GENERAL_USE_COMMENT_KEY = L"COMM";
const QString  CRecSetupCfgMgr::ms_strBATCH_GENERAL_USE_LOT_KEY = L"LOT";

// Batch Name Branch Properties
const QString  CRecSetupCfgMgr::ms_strBATCH_GENERAL_NAME_FIELD_KEY = L"NAME";
const QString  CRecSetupCfgMgr::ms_strBATCH_GENERAL_NAME_FIELD_NAME_KEY = L"NAME_F";
const QString  CRecSetupCfgMgr::ms_strBATCH_GENERAL_NAME_FIELD_NAME_LIST_KEY = L"NAME%u";

// Batch User ID Branch Properties
const QString  CRecSetupCfgMgr::ms_strBATCH_GENERAL_USER_ID_FIELD_KEY = L"USER";
const QString  CRecSetupCfgMgr::ms_strBATCH_GENERAL_USER_ID_FIELD_NAME_KEY = L"USER_F";
const QString  CRecSetupCfgMgr::ms_strBATCH_GENERAL_USER_ID_FIELD_USER_LIST_KEY = L"USER%u";

// Batch Description Branch Properties
const QString  CRecSetupCfgMgr::ms_strBATCH_GENERAL_DESC_FIELD_KEY = L"DESC";
const QString  CRecSetupCfgMgr::ms_strBATCH_GENERAL_DESC_FIELD_NAME_KEY = L"DESC_F";
const QString  CRecSetupCfgMgr::ms_strBATCH_GENERAL_DESC_FIELD_DESC_LIST_KEY = L"DESC%u";

// Batch Lot Number Branch Properties
const QString  CRecSetupCfgMgr::ms_strBATCH_GENERAL_LOT_FIELD_KEY = L"LOT";
const QString  CRecSetupCfgMgr::ms_strBATCH_GENERAL_LOT_FIELD_NAME_KEY = L"LOT_F";
const QString  CRecSetupCfgMgr::ms_strBATCH_GENERAL_LOT_FIELD_LOT_NO_LIST_KEY = L"LOT%u";

// Batch Comment Branch Properties
const QString  CRecSetupCfgMgr::ms_strBATCH_GENERAL_COMMENT_FIELD_KEY = L"COM";
const QString  CRecSetupCfgMgr::ms_strBATCH_GENERAL_COMMENT_FIELD_NAME_KEY = L"COM_F";
const QString  CRecSetupCfgMgr::ms_strBATCH_GENERAL_COMMENT_FIELD_COMMENT_LIST_KEY = L"COM%u";
const QString  CRecSetupCfgMgr::ms_strBATCH_GENERAL_SSB_FIELD_KEY = L"SSB";

// Group Centric Batch Fields
const QString  CRecSetupCfgMgr::ms_strBATCH_GROUP_KEY = L"GRP%u";
const QString  CRecSetupCfgMgr::ms_strBATCH_GROUP_CTR_START_KEY = L"START";
const QString  CRecSetupCfgMgr::ms_strBATCH_GROUP_CTR_INC_KEY = L"INC";
const QString  CRecSetupCfgMgr::ms_strBATCH_GROUP_CTR_ROLLOVER_KEY = L"ROLL";
const QString  CRecSetupCfgMgr::ms_strBATCH_GROUP_AUTO_POP_KEY = L"AUTO";
const QString  CRecSetupCfgMgr::ms_strBATCH_GROUP_AUTO_POP_NAME_KEY = L"NAME";
const QString  CRecSetupCfgMgr::ms_strBATCH_GROUP_ZERO_PAD_KEY = L"ZPAD";
const QString  CRecSetupCfgMgr::ms_strBATCH_GROUP_SHOW_NAME_LIST_KEY = L"N_LIST";
const QString  CRecSetupCfgMgr::ms_strBATCH_GROUP_SHOW_USER_LIST_KEY = L"U_LIST";
const QString  CRecSetupCfgMgr::ms_strBATCH_GROUP_SHOW_LOT_NO_LIST_KEY = L"L_LIST";
const QString  CRecSetupCfgMgr::ms_strBATCH_GROUP_SHOW_DESC_LIST_KEY = L"D_LIST";
const QString  CRecSetupCfgMgr::ms_strBATCH_GROUP_SHOW_COMM_LIST_KEY = L"C_LIST";

// Screen List Names
QString  CRecSetupCfgMgr::ms_strScreenSaverModeList = "";
QString  CRecSetupCfgMgr::ms_strScreenSaverTypeList = "";
QString  CRecSetupCfgMgr::ms_strScreenSaverDimList = "";

// Error Control Properties
const QString  CRecSetupCfgMgr::ms_strERROR_CONTROL_KEY = L"ERR";
const QString  CRecSetupCfgMgr::ms_strERROR_CONTROL_ERRORS_KEY = L"ERRORS";
const QString  CRecSetupCfgMgr::ms_strERROR_CONTROL_ERRORS_CABLE_UNPLUGGED_KEY = L"CABLE";
const QString  CRecSetupCfgMgr::ms_strERROR_CONTROL_ERRORS_INT_MEM_LO_KEY = L"MEM_LO";
const QString  CRecSetupCfgMgr::ms_strERROR_CONTROL_ERRORS_EXP_MEM_LO_KEY = L"EXP_LO";
const QString  CRecSetupCfgMgr::ms_strERROR_CONTROL_ERRORS_EXP_MEDIA_MISSING_KEY = L"MEDIA";
const QString  CRecSetupCfgMgr::ms_strERROR_CONTROL_ERRORS_FTP_MEM_LO_KEY = L"FTP_LO";
const QString  CRecSetupCfgMgr::ms_strERROR_CONTROL_ERRORS_CJC_MISSING_KEY = L"CJC";
const QString  CRecSetupCfgMgr::ms_strERROR_CONTROL_ERRORS_BURNOUT_KEY = L"BURN";
const QString  CRecSetupCfgMgr::ms_strERROR_CONTROL_BORDER_COL_KEY = L"B_COL";
const QString  CRecSetupCfgMgr::ms_strERROR_CONTROL_BKG_COL_KEY = L"BKG_COL";
const QString  CRecSetupCfgMgr::ms_strERROR_CONTROL_REFLASH_EN_KEY = L"RFLSH";
const QString  CRecSetupCfgMgr::ms_strERROR_CONTROL_REFLASH_TIME_KEY = L"RFLSH_T";
const QString  CRecSetupCfgMgr::ms_strERROR_CONTROL_AUTO_CLEAR_KEY = L"A_CLR";

// Localisation Properties
const QString  CRecSetupCfgMgr::ms_strLOCAL_KEY = L"LOCAL";
const QString  CRecSetupCfgMgr::ms_strLOCAL_LANG_KEY = L"LANG";
const QString  CRecSetupCfgMgr::ms_strLOCAL_TEMP_FORMAT_KEY = L"TEMP";
const QString  CRecSetupCfgMgr::ms_strLOCAL_TIME_ZONE_KEY = L"ZONE";
const QString  CRecSetupCfgMgr::ms_strLOCAL_MAINS_FREQ_KEY = L"MAINS";
const QString  CRecSetupCfgMgr::ms_strLOCAL_HELP_LANG_KEY = L"HELP";
const QString  CRecSetupCfgMgr::ms_strLOCAL_TIME_DAYLIGHT_SAVING_KEY = L"DAY";

//Localisation List Names
QString  CRecSetupCfgMgr::ms_strLocalLangList = "";
QString  CRecSetupCfgMgr::ms_strLocalTempasprintfList = "";
QString  CRecSetupCfgMgr::ms_strLocalMainsFreqList = "";
QString  CRecSetupCfgMgr::ms_strLocalHelpLangList = "";
QString  CRecSetupCfgMgr::ms_strTimeZoneList = "";
QMap< USHORT, USHORT, QString  , QString  > CRecSetupCfgMgr::ms_kTimeZoneRegKeyArr;

// Credits Key Names
const QString  CRecSetupCfgMgr::ms_strCREDITS_KEY = L"CRED";
const QString  CRecSetupCfgMgr::ms_strCREDITS_OPT_KEY = L"OPT";
const QString  CRecSetupCfgMgr::ms_strCREDITS_OPT_MATH_TYPE_KEY = L"MATH";
const QString  CRecSetupCfgMgr::ms_strCREDITS_OPT_EVENTS_KEY = L"EVT";
const QString  CRecSetupCfgMgr::ms_strCREDITS_OPT_FAST_SCAN_KEY = L"SCAN";
const QString  CRecSetupCfgMgr::ms_strCREDITS_OPT_TOTALS_KEY = L"TOT";
const QString  CRecSetupCfgMgr::ms_strCREDITS_OPT_CUST_SCRN_KEY = L"SCRN";
const QString  CRecSetupCfgMgr::ms_strCREDITS_OPT_REPORTS_KEY = L"REP";
const QString  CRecSetupCfgMgr::ms_strCREDITS_OPT_NADCAP_RECORDER_KEY = L"NAD";
const QString  CRecSetupCfgMgr::ms_strCREDITS_OPT_TUS_MODE_KEY = L"TUS";
const QString  CRecSetupCfgMgr::ms_strCREDITS_OPT_MAINT_KEY = L"MAINT";
const QString  CRecSetupCfgMgr::ms_strCREDITS_OPT_BATCH_KEY = L"BATCH";
const QString  CRecSetupCfgMgr::ms_strCREDITS_OPT_COUNTERS_KEY = L"CNTR";
const QString  CRecSetupCfgMgr::ms_strCREDITS_OPT_MODBUS_MASTER_KEY = L"MOD_M";
const QString  CRecSetupCfgMgr::ms_strCREDITS_OPT_REMOTE_VIEWER_KEY = L"RMT";
const QString  CRecSetupCfgMgr::ms_strCREDITS_OPT_EMAIL_KEY = L"EMAIL";
const QString  CRecSetupCfgMgr::ms_strCREDITS_OPT_PRINTER_KEY = L"PRN";
const QString  CRecSetupCfgMgr::ms_strCREDITS_OPT_OPC_TITLE_KEY = L"OPC";
const QString  CRecSetupCfgMgr::ms_strCREDITS_OPT_EXTSD_TITLE_KEY = L"ExtSD";
const QString  CRecSetupCfgMgr::ms_strCREDITS_OPT_SECUREWSD_TITLE_KEY = L"SWSD";
const QString  CRecSetupCfgMgr::ms_strCREDITS_OPT_PWD_NET_SYNC_KEY = L"SYNC";
const QString  CRecSetupCfgMgr::ms_strCREDITS_OPT_EXTRA_PENS_KEY = L"X_PENS";
const QString  CRecSetupCfgMgr::ms_strCREDITS_CREDITS_KEY = L"CRED";
const QString  CRecSetupCfgMgr::ms_strCREDITS_SERIAL_NO_KEY = L"SER";
const QString  CRecSetupCfgMgr::ms_strCREDITS_OPTIONS_CODE_KEY = L"OPT_CODE";
const QString  CRecSetupCfgMgr::ms_strCREDITS_OPT_RTDATABUS_TITLE_KEY = L"RTDATABUS";
const QString  CRecSetupCfgMgr::ms_strCREDITS_OPT_HWLOCK_TITLE_KEY = L"HWLOCK";
const QString  CRecSetupCfgMgr::ms_strCREDITS_OPT_OPCUASERVER_TITLE_KEY = L"OPCUA";

// Factory List Names
QString  CRecSetupCfgMgr::ms_strCreditsOptMathTypeList = "";

// Demo board List Names
QString  CRecSetupCfgMgr::ms_strDemoBoardEnabledList = "";

// Demo Key Names
const QString  CRecSetupCfgMgr::ms_strDEMO_BOARDS_KEY = L"DEMO";
const QString  CRecSetupCfgMgr::ms_strDEMO_BOARDS_BOARD_KEY = L"BRD";

// Production Key Names
const QString  CRecSetupCfgMgr::ms_strPRODUCTION_KEY = L"PROD";
const QString  CRecSetupCfgMgr::ms_strPRODUCTION_SERIAL_NO_KEY = L"SER";

// TCP/IP Keys
const QString  CRecSetupCfgMgr::ms_strTCPIP_KEY = L"TCP";
const QString  CRecSetupCfgMgr::ms_strTCPIP_USE_STATIC_IP_ADDR_KEY = L"USE_IP";
const QString  CRecSetupCfgMgr::ms_strTCPIP_STATIC_IP_ADDR_KEY = L"IP_ADDR";
const QString  CRecSetupCfgMgr::ms_strTCPIP_SUB_NET_MASK_KEY = L"MASK";
const QString  CRecSetupCfgMgr::ms_strTCPIP_DEF_GATEWAY_KEY = L"DEF_GW";
const QString  CRecSetupCfgMgr::ms_strTCPIP_DNS_WINS_KEY = L"DNS_WINS";
const QString  CRecSetupCfgMgr::ms_strTCPIP_QAbstractSocketS_KEY = L"SOCK";
const QString  CRecSetupCfgMgr::ms_strTCPIP_ENABLE_DNS_KEY = L"EN_DNS";
const QString  CRecSetupCfgMgr::ms_strTCPIP_DNS_PRI_ADDR_KEY = L"DNS_P";
const QString  CRecSetupCfgMgr::ms_strTCPIP_DNS_SEC_ADDR_KEY = L"DNS_S";
const QString  CRecSetupCfgMgr::ms_strTCPIP_WINS_PRI_ADDR_KEY = L"WINS_P";
const QString  CRecSetupCfgMgr::ms_strTCPIP_WINS_SEC_ADDR_KEY = L"WINS_S";
const QString  CRecSetupCfgMgr::ms_strTCPIP_ENABLE_WINS_KEY = L"EN_WINS";
const QString  CRecSetupCfgMgr::ms_strTCPIP_ENABLE_MDNS_KEY = L"EN_MDNS";

//SecurityOptions
const QString  CRecSetupCfgMgr::ms_strSecurity_KEY = L"SecurityOptions";
const QString  CRecSetupCfgMgr::ms_strSecurity_USE_GLOBAL_CA_KEY = L"USE_GLOBALCA";
const QString  CRecSetupCfgMgr::ms_strSecurity_USE_TLS_PROTOCOL_KEY = L"TLS PROTOCOL";
const QString  CRecSetupCfgMgr::ms_str_RDT_KEY = L"RDT";
const QString  CRecSetupCfgMgr::ms_strSecurity_PfxPassword = L"PFXPWD";

// MODBUS Comms Keys
const QString  CRecSetupCfgMgr::ms_strMODBUS_COMMS_KEY = L"COMMS";
const QString  CRecSetupCfgMgr::ms_strMODBUS_COMMS_BAUD_RATE_KEY = L"BAUD";
const QString  CRecSetupCfgMgr::ms_strMODBUS_COMMS_BYTE_OPT_KEY = L"BYTE";
const QString  CRecSetupCfgMgr::ms_strMODBUS_COMMS_LINE_TURN_AROUND_KEY = L"TURN";
const QString  CRecSetupCfgMgr::ms_strMODBUS_COMMS_REPLY_DELAY_KEY = L"REP_D";

// MODBUS Slave Keys
const QString  CRecSetupCfgMgr::ms_strMODBUS_SLAVE_KEY = L"SLV";
const QString  CRecSetupCfgMgr::ms_strMODBUS_SLAVE_PORT_KEY = L"PORT";
const QString  CRecSetupCfgMgr::ms_strMODBUS_SLAVE_PROTOCOL_KEY = L"PROTO";
const QString  CRecSetupCfgMgr::ms_strMODBUS_SLAVE_ADDR_KEY = L"ADDR";
const QString  CRecSetupCfgMgr::ms_strMODBUS_SLAVE_ENABLED_KEY = L"EN";

// MODBUS List Names
QString  CRecSetupCfgMgr::ms_strModbusPortList = "";
QString  CRecSetupCfgMgr::ms_strModbusProtocolList = "";

// MODBUS Master Keys
const QString  CRecSetupCfgMgr::ms_strMODBUS_MASTER_KEY = L"MAST";
const QString  CRecSetupCfgMgr::ms_strMODBUS_MASTER_ENABLED_KEY = L"EN";
const QString  CRecSetupCfgMgr::ms_strMODBUS_MASTER_POLL_RATE_KEY = L"POLL";
const QString  CRecSetupCfgMgr::ms_strMODBUS_MASTER_LEGACY_ETHERNET_KEY = L"LEG";
const QString  CRecSetupCfgMgr::ms_strMODBUS_MASTER_SLAVE_KEY = L"SLV%u";
const QString  CRecSetupCfgMgr::ms_strMODBUS_MASTER_SLAVE_ID_KEY = L"ID";
const QString  CRecSetupCfgMgr::ms_strMODBUS_MASTER_SLAVE_FRIENDLY_NAME_KEY = L"F_NAME";
const QString  CRecSetupCfgMgr::ms_strMODBUS_MASTER_SLAVE_NETWORK_NAME_KEY = L"N_NAME";
const QString  CRecSetupCfgMgr::ms_strMODBUS_MASTER_SLAVE_PORT_KEY = L"PORT";
const QString  CRecSetupCfgMgr::ms_strMODBUS_MASTER_SLAVE_PROTOCOL_KEY = L"PROT";
const QString  CRecSetupCfgMgr::ms_strMODBUS_MASTER_SLAVE_TX_ITEM_KEY = L"TX%u";
const QString  CRecSetupCfgMgr::ms_strMODBUS_MASTER_SLAVE_TX_ITEM_ENABLE_KEY = L"EN";
const QString  CRecSetupCfgMgr::ms_strMODBUS_MASTER_SLAVE_TX_ITEM_DIR_KEY = L"DIR";
const QString  CRecSetupCfgMgr::ms_strMODBUS_MASTER_SLAVE_TX_ITEM_MAP_KEY = L"MAP";
const QString  CRecSetupCfgMgr::ms_strMODBUS_MASTER_SLAVE_TX_DATA_TYPE_KEY = L"TYPE";
const QString  CRecSetupCfgMgr::ms_strMODBUS_MASTER_SLAVE_TX_DATA_ITEM_KEY = L"ITEM";
const QString  CRecSetupCfgMgr::ms_strMODBUS_MASTER_SLAVE_TX_ITEM_START_KEY = L"START";
const QString  CRecSetupCfgMgr::ms_strMODBUS_MASTER_SLAVE_TX_DATA_ITEM_START_KEY = L"DATA_S";
const QString  CRecSetupCfgMgr::ms_strMODBUS_MASTER_SLAVE_TX_ITEM_NO_OF_ITEMS_KEY = L"NUMB";

// Modbus Master Lists
QString  CRecSetupCfgMgr::ms_strModbusMasterSlaveMapList = "";
QString  CRecSetupCfgMgr::ms_strModbusMasterSlaveDirList = "";
QString  CRecSetupCfgMgr::ms_strModbusMasterSlaveInsDataTypeList = "";
QString  CRecSetupCfgMgr::ms_strModbusMasterSlaveOutsDataTypeList = "";

// Serial Port List Names
QString  CRecSetupCfgMgr::ms_strSerPortBaudRateList = "";
QString  CRecSetupCfgMgr::ms_strSerPortByteOptsList = "";

//TLS Protocol
QString  CRecSetupCfgMgr::ms_strTLSProtocolList = "";

// SNTP Keys
const QString  CRecSetupCfgMgr::ms_strSNTP_KEY = L"SNTP";
const QString  CRecSetupCfgMgr::ms_strSNTP_CLIENT_ENABLE_KEY = L"CLNT";
const QString  CRecSetupCfgMgr::ms_strSNTP_SERVER_ENABLE_KEY = L"SERV";
const QString  CRecSetupCfgMgr::ms_strSNTP_SERVER_NAME_KEY = L"S_NAME";
const QString  CRecSetupCfgMgr::ms_strSNTP_CLIENT_UPDATE_PER_KEY = L"UPD_P";
const QString  CRecSetupCfgMgr::ms_strSNTP_CLIENT_UPDATE_THRESH_KEY = L"UPD_T";

// Socket Keys
const QString  CRecSetupCfgMgr::ms_strTCPIP_SOCK_HTTP_KEY = L"HTTP";
const QString  CRecSetupCfgMgr::ms_strTCPIP_SOCK_FTP_DATA_KEY = L"FTP_D";
const QString  CRecSetupCfgMgr::ms_strTCPIP_SOCK_FTP_CONTROL_KEY = L"FTP_C";
const QString  CRecSetupCfgMgr::ms_strTCPIP_SOCK_MODBUS_KEY = L"MOD";
const QString  CRecSetupCfgMgr::ms_strTCPIP_SOCK_TRENDBUS_KEY = L"TREND";

// Email Keys
const QString  CRecSetupCfgMgr::ms_strEMAIL_KEY = L"EMAIL";
const QString  CRecSetupCfgMgr::ms_strEMAIL_SERVER_KEY = L"SVR";
const QString  CRecSetupCfgMgr::ms_strEMAIL_PORT_KEY = L"PORT"; //TVR200 - Making port configurable
const QString  CRecSetupCfgMgr::ms_strEMAIL_SECURE_MODE_KEY = L"SMode";
const QString  CRecSetupCfgMgr::ms_strEMAIL_STARTTLS_KEY = L"STARTTLS";
const QString  CRecSetupCfgMgr::ms_strEMAIL_REQUIRES_AUTH_KEY = L"AUTH";
const QString  CRecSetupCfgMgr::ms_strEMAIL_USERNAME_KEY = L"USER";
const QString  CRecSetupCfgMgr::ms_strEMAIL_PASSWORD_KEY = L"PWD";
const QString  CRecSetupCfgMgr::ms_strEMAIL_USER_ADDRESS_KEY = L"U_ADDR";
const QString  CRecSetupCfgMgr::ms_strEMAIL_ADDRESSES_KEY = L"ADDRS";
const QString  CRecSetupCfgMgr::ms_strEMAIL_ADDRESS_KEY = L"ADDR%u";
const QString  CRecSetupCfgMgr::ms_strEMAIL_TEMPLATES_KEY = L"TPL";
const QString  CRecSetupCfgMgr::ms_strEMAIL_IND_TEMPLATE_KEY = L"TPL_%u";
const QString  CRecSetupCfgMgr::ms_strEMAIL_SUBJECT_KEY = L"SUBJ";
const QString  CRecSetupCfgMgr::ms_strEMAIL_MESSAGE_BODY_KEY = L"MSG";

// Email Lists
QString  CRecSetupCfgMgr::ms_strEventsEmailTemplateList = "";

// Network Admin Keys
const QString  CRecSetupCfgMgr::ms_strNETWORK_ADMIN_KEY = L"N_ADMIN";
const QString  CRecSetupCfgMgr::ms_strNETWORK_ADMIN_USERNAME_KEY = L"USER";
const QString  CRecSetupCfgMgr::ms_strNETWORK_ADMIN_PASSWORD_KEY = L"PWD";
const QString  CRecSetupCfgMgr::ms_strNETWORK_ADMIN_DOMAIN_KEY = L"DMN";
const QString  CRecSetupCfgMgr::ms_strNETWORK_ADMIN_USE_SHARE_KEY = L"USE_S";
const QString  CRecSetupCfgMgr::ms_strNETWORK_ADMIN_SHARE_PATH_KEY = L"SHARE";

// Digital IO Keys
const QString  CRecSetupCfgMgr::ms_strDIGIO_KEY = L"DIGIO";
const QString  CRecSetupCfgMgr::ms_strDIGIO_IO_TYPE_KEY = L"IO_TYPE";
const QString  CRecSetupCfgMgr::ms_strDIGIO_LABEL_KEY = L"LABEL";
const QString  CRecSetupCfgMgr::ms_strDIGIO_ACTIVE_LABEL_KEY = L"ACT";
const QString  CRecSetupCfgMgr::ms_strDIGIO_INACTIVE_LABEL_KEY = L"INACT";
const QString  CRecSetupCfgMgr::ms_strDIGIO_OUT_LATCHED_KEY = L"LATCH";
const QString  CRecSetupCfgMgr::ms_strDIGIO_OUT_FAILSAFE_KEY = L"FSAFE";
const QString  CRecSetupCfgMgr::ms_strDIGIO_OUT_DURATION_KEY = L"DUR";
const QString  CRecSetupCfgMgr::ms_strDIGIO_IO_NOTIFYTYPE_KEY = L"DNOT";

// Digital List Names
QString  CRecSetupCfgMgr::ms_strDigioIOPulseTypeList = "";
QString  CRecSetupCfgMgr::ms_strDigioIOTypeList = "";
QString  CRecSetupCfgMgr::ms_strDigioIOOutputTypeList = "";
QString  CRecSetupCfgMgr::ms_strDigioOutFailsafeList = "";
QString  CRecSetupCfgMgr::ms_strDigioOutLatchedList = "";
QString  CRecSetupCfgMgr::ms_strDigioIOReportTypeList = "";

// Pulse In Keys
const QString  CRecSetupCfgMgr::ms_strPULSE_IN_KEY = L"PULSE";
const QString  CRecSetupCfgMgr::ms_strPULSE_IN_MEASUREMENT_UPDATE_KEY = L"UPD";
const QString  CRecSetupCfgMgr::ms_strPULSE_IN_LABEL_KEY = L"LABEL";

// Pulse In List Names
//QString   CRecSetupCfgMgr::ms_strPulseInMeasurementMethodList = QString   ::fromWCharArray("");
QString  CRecSetupCfgMgr::ms_strPulseInMeasurementUpdateList = "";

// Analogue Output Keys
const QString  CRecSetupCfgMgr::ms_strANALOGUE_OUTPUT_KEY = L"AOUT";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_OUTPUT_ALLOW_OVERRANGE_KEY = L"OVRG";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_OUTPUT_RETRANS_PEN_KEY = L"PEN";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_OUTPUT_CURRENT_KEY = L"C_OUT";
const QString  CRecSetupCfgMgr::ms_strANALOGUE_OUTPUT_LABEL_KEY = L"LABEL";

// Analogue Output List Names
QString  CRecSetupCfgMgr::ms_strAnalogueOutputCurrentList = "";

// Linearisation Keys
const QString  CRecSetupCfgMgr::ms_strLINEARISATION_KEY = L"LIN";
const QString  CRecSetupCfgMgr::ms_strLINEARISATION_TABLE_KEY = L"TAB_%u";
const QString  CRecSetupCfgMgr::ms_strLINEARISATION_TABLE_NAME_KEY = L"NAME";
const QString  CRecSetupCfgMgr::ms_strLINEARISATION_TABLE_VALUES_KEY = L"VAL";

// Group Keys
const QString  CRecSetupCfgMgr::ms_strGROUPS_KEY = L"GRPS";
const QString  CRecSetupCfgMgr::ms_strGROUPS_GROUP_KEY = L"GRP_%u";

// Web Keys
const QString  CRecSetupCfgMgr::ms_strWEB_KEY = "";

// Scheduled Recording Keys
const QString  CRecSetupCfgMgr::ms_strRECORDING_SCHED_KEY = L"REC_SCH";
const QString  CRecSetupCfgMgr::ms_strRECORDING_SCHED_DEVICE_KEY = L"DEV";
const QString  CRecSetupCfgMgr::ms_strRECORDING_SCHED_TIME_KEY = L"TIME";
const QString  CRecSetupCfgMgr::ms_strRECORDING_SCHED_LOG_MESSAGE_KEY = L"LOG";
const QString  CRecSetupCfgMgr::ms_strRECORDING_SCHED_MARK_CHART_KEY = L"MARK";

// Scheduled Recording List Keys
QString  CRecSetupCfgMgr::ms_strRecordingSchedTimeList = "";
QString  CRecSetupCfgMgr::ms_strRecordingSchedDeviceList = "";

// Recording Alarm Keys
const QString  CRecSetupCfgMgr::ms_strRECORDING_ALM_KEY = L"REC_ALM";
const QString  CRecSetupCfgMgr::ms_strRECORDING_ALM_INT_MEM_KEY = L"INT";
const QString  CRecSetupCfgMgr::ms_strRECORDING_ALM_EXP_MEDIA_KEY = L"EXP";
const QString  CRecSetupCfgMgr::ms_strRECORDING_ALM_FTP_MEM_KEY = L"FTP";

// Recording Pre-Trigger Keys
const QString  CRecSetupCfgMgr::ms_strRECORDING_PRETRIGGER_KEY = L"PRE_TRIG";
const QString  CRecSetupCfgMgr::ms_strRECORDING_PRETRIGGER_TIME_KEY = L"PRE_TIME";
const QString  CRecSetupCfgMgr::ms_strRECORDING_POSTTRIGGER_TIME_KEY = L"POST_TIME";

//Recording Export Keys
const QString  CRecSetupCfgMgr::ms_strRECORDING_EXPORT_KEY = L"REC_EXPORT";

// FTP Keys
const QString  CRecSetupCfgMgr::ms_strFTP_KEY = L"FTP";
const QString  CRecSetupCfgMgr::ms_strSFT_KEY = L"SFT";
const QString  CRecSetupCfgMgr::ms_strFTP_ALLOW_UPLOAD_KEY = L"UP";
const QString  CRecSetupCfgMgr::ms_strFTP_ALLOW_DOWNLOAD_KEY = L"DOWN";
const QString  CRecSetupCfgMgr::ms_strFTP_LOG_MESSAGE_KEY = L"LOG";
const QString  CRecSetupCfgMgr::ms_strFTP_MARK_CHART_KEY = L"MARK";

// OPC UA Keys
const QString  CRecSetupCfgMgr::ms_strOPCUA_KEY = L"OPC UA";
const QString  CRecSetupCfgMgr::ms_strOPCUA_PORT_KEY = L"PORT";

// P2P Keys
const QString  CRecSetupCfgMgr::ms_strP2P_KEY = L"P2P";
const QString  CRecSetupCfgMgr::ms_strP2P_TCP_PORT_KEY = L"TCP";
const QString  CRecSetupCfgMgr::ms_strP2P_UDP_PORT_KEY = L"UDP";
const QString  CRecSetupCfgMgr::ms_strP2P_SET_NO_KEY = L"SET";

/// P2P Lists
QString  CRecSetupCfgMgr::ms_strP2PSetNumbersList = L"1|2|3|4|5|6|7|8|";

// Preset Marker Keys
const QString  CRecSetupCfgMgr::ms_strPRESET_MARKERS_KEY = L"MKRS";
const QString  CRecSetupCfgMgr::ms_strPRESET_MARKERS_MARKER_KEY = L"MKR%u";

// Report Properties
const QString  CRecSetupCfgMgr::ms_strREPORT_IND_KEY = L"REP";
const QString  CRecSetupCfgMgr::ms_strREPORT_IND_TYPE_KEY = L"TYPE";
const QString  CRecSetupCfgMgr::ms_strREPORT_IND_STYLE_KEY = L"STYLE";
const QString  CRecSetupCfgMgr::ms_strREPORT_IND_TRIGGER_KEY = L"TRIG";
const QString  CRecSetupCfgMgr::ms_strREPORT_IND_PEN_SEL_TYPE_KEY = L"PEN";
const QString  CRecSetupCfgMgr::ms_strREPORT_IND_INC_CURR_PEN_KEY = L"CURR";
const QString  CRecSetupCfgMgr::ms_strREPORT_IND_INC_MAX_MIN_KEY = L"MAX";
const QString  CRecSetupCfgMgr::ms_strREPORT_IND_INC_AVERAGE_KEY = L"AVG";
const QString  CRecSetupCfgMgr::ms_strREPORT_IND_INC_TOTALS_KEY = L"TOT";
const QString  CRecSetupCfgMgr::ms_strREPORT_IND_INC_MESSAGE_KEY = L"MSG";
const QString  CRecSetupCfgMgr::ms_strREPORT_IND_MSG_TYPES_KEY = L"MSG_T";
const QString  CRecSetupCfgMgr::ms_strREPORT_IND_INC_CTR_KEY = L"CTR";
const QString  CRecSetupCfgMgr::ms_strREPORT_IND_INC_DIG_IN_KEY = L"IN";
const QString  CRecSetupCfgMgr::ms_strREPORT_IND_INC_DIG_OUT_KEY = L"OUT";
const QString  CRecSetupCfgMgr::ms_strREPORT_IND_GROUP_KEY = L"GRP";
const QString  CRecSetupCfgMgr::ms_strREPORT_IND_EMAIL_KEY = L"EML";
const QString  CRecSetupCfgMgr::ms_strREPORT_IND_EXPORT_DEV_KEY = L"DEV";
const QString  CRecSetupCfgMgr::ms_strREPORT_IND_PRINT_KEY = L"PRN";
const QString  CRecSetupCfgMgr::ms_strREPORT_IND_PEN_PKR_KEY = L"PEN_PKR";
const QString  CRecSetupCfgMgr::ms_strREPORT_IND_PEN_TOTALS_PKR_KEY = L"TOT_PKR";
const QString  CRecSetupCfgMgr::ms_strREPORT_IND_TAG_KEY = L"TAG";
const QString  CRecSetupCfgMgr::ms_strREPORT_IND_SCHEDULE_KEY = L"SCH";
const QString  CRecSetupCfgMgr::ms_strREPORT_IND_SCHEDULE_SUB_TYPE_KEY = L"SUB";
const QString  CRecSetupCfgMgr::ms_strREPORT_IND_EMAIL_RECIP_KEY = L"RECIP";
const QString  CRecSetupCfgMgr::ms_strREPORT_IND_FOOTER_KEY = L"FOOT";

// Report Lists
QString  CRecSetupCfgMgr::ms_strReportIndTypeList = "";
QString  CRecSetupCfgMgr::ms_strReportIndTriggerList = "";
QString  CRecSetupCfgMgr::ms_strReportIndStyleList = "";
QString  CRecSetupCfgMgr::ms_strReportIndPenSelTypeList = "";
QString  CRecSetupCfgMgr::ms_strReportIndSchedSubTypeList = "";
QString  CRecSetupCfgMgr::ms_strReportIndPeriodList = "";
QString  CRecSetupCfgMgr::ms_strReportIndAvgPeriodList = "";
QString  CRecSetupCfgMgr::ms_strReportIndMsgPeriodList = "";
QString  CRecSetupCfgMgr::ms_strReportIndIncCurrPenList = "";
QString  CRecSetupCfgMgr::ms_strReportIndExportDevList = "";
QString  CRecSetupCfgMgr::ms_strReportIndFooterList = "";

//TimeSync... Properties
const QString  CRecSetupCfgMgr::ms_strTIMESYNC_KEY = L"TIMESYNC";
const QString  CRecSetupCfgMgr::ms_strTIMESYNC_ENABLED_KEY = L"EN";
const QString  CRecSetupCfgMgr::ms_strTIMESYNC_DIPICKER_KEY = L"DIPICK";
const QString  CRecSetupCfgMgr::ms_strTIMESYNC_TRIGGER_KEY = L"TRIG";
const QString  CRecSetupCfgMgr::ms_strTIMESYNC_TIMESYNC_COND_KEY = L"COND";

// TimeSync Trigger List
QString  CRecSetupCfgMgr::ms_strTriggerList = "";

// AMS2750 General Properties
const QString  CRecSetupCfgMgr::ms_strAMS2750_GEN_PROCESS_KEY = L"AMSPRO";
const QString  CRecSetupCfgMgr::ms_strAMS2750_GEN_TUS_KEY = L"AMSTUS";

// AMS2750 Furnace Properties
const QString  CRecSetupCfgMgr::ms_strAMS2750_FURNACE_IND_KEY = L"FURN%u";
const QString  CRecSetupCfgMgr::ms_strAMS2750_FURNACE_NAME_KEY = L"NAME";
const QString  CRecSetupCfgMgr::ms_strAMS2750_FURNACE_MANFACT_KEY = L"MANF";
const QString  CRecSetupCfgMgr::ms_strAMS2750_FURNACE_MODEL_NO_KEY = L"MOD";
const QString  CRecSetupCfgMgr::ms_strAMS2750_FURNACE_SERIAL_NO_KEY = L"SER";
const QString  CRecSetupCfgMgr::ms_strAMS2750_FURNACE_CLASS_KEY = L"CLS";
const QString  CRecSetupCfgMgr::ms_strAMS2750_FURNACE_TYPE_KEY = L"TYPE";
const QString  CRecSetupCfgMgr::ms_strAMS2750_FURNACE_INST_TYPE_KEY = L"INST";
const QString  CRecSetupCfgMgr::ms_strAMS2750_FURNACE_SHAPE_KEY = L"SHA";
const QString  CRecSetupCfgMgr::ms_strAMS2750_FURNACE_MEAS_UNITS_KEY = L"UNIT";
const QString  CRecSetupCfgMgr::ms_strAMS2750_FURNACE_HEIGHT_KEY = L"HGT";
const QString  CRecSetupCfgMgr::ms_strAMS2750_FURNACE_WIDTH_KEY = L"WTH";
const QString  CRecSetupCfgMgr::ms_strAMS2750_FURNACE_DEPTH_KEY = L"DTH";
const QString  CRecSetupCfgMgr::ms_strAMS2750_FURNACE_HIGH_USE_TEMP_KEY = L"HI";
const QString  CRecSetupCfgMgr::ms_strAMS2750_FURNACE_LOW_USE_TEMP_KEY = L"LO";

// AMS2750 Furnace Lists
QString  CRecSetupCfgMgr::ms_strAMS2750FurnaceClassList = "";
QString  CRecSetupCfgMgr::ms_strAMS2750FurnaceTypeList = "";
QString  CRecSetupCfgMgr::ms_strAMS2750FurnaceInstTypeList = "";
QString  CRecSetupCfgMgr::ms_strAMS2750FurnaceShapeList = "";
QString  CRecSetupCfgMgr::ms_strAMS2750FurnaceMeasUnitsList = "";

// AMS2750 Setpoint Properties
const QString  CRecSetupCfgMgr::ms_strAMS2750_SETPOINT_IND_KEY = L"SOAK%u";
const QString  CRecSetupCfgMgr::ms_strAMS2750_SETPOINT_ENABLED_KEY = L"EN";
const QString  CRecSetupCfgMgr::ms_strAMS2750_SETPOINT_SOAK_LEVEL_KEY = L"LEV";
const QString  CRecSetupCfgMgr::ms_strAMS2750_SETPOINT_TIME_KEY = L"TIME";
const QString  CRecSetupCfgMgr::ms_strAMS2750_SETPOINT_TOL_OVERRIDE_KEY = L"EN_TOL";
const QString  CRecSetupCfgMgr::ms_strAMS2750_SETPOINT_TOLERANCE_KEY = L"TOLER";

// AMS2750 Stability Detect Properties
const QString  CRecSetupCfgMgr::ms_strAMS2750_STABILITY_DETECT_KEY = L"STAB";
const QString  CRecSetupCfgMgr::ms_strAMS2750_STABILITY_DETECT_TIMER_EN_KEY = L"T_EN";
const QString  CRecSetupCfgMgr::ms_strAMS2750_STABILITY_DETECT_TIME_KEY = L"TIME";
const QString  CRecSetupCfgMgr::ms_strAMS2750_STABILITY_DETECT_AUTO_EN_KEY = L"A_EN";
const QString  CRecSetupCfgMgr::ms_strAMS2750_STABILITY_DETECT_DEGREES_CHANGE_KEY = L"DEG";

// AMS2750 Cal Properties
const QString  CRecSetupCfgMgr::ms_strAMS2750_CAL_KEY = L"AMSCAL";
const QString  CRecSetupCfgMgr::ms_strAMS2750_CAL_CALIBRATOR_TYPE_KEY = L"CAL_TYPE";
const QString  CRecSetupCfgMgr::ms_strAMS2750_CAL_CALIBRATOR_SERIAL_NO_KEY = L"CAL_SN";
const QString  CRecSetupCfgMgr::ms_strAMS2750_CAL_qDebugABLE_TO_KEY = L"TRAC";
const QString  CRecSetupCfgMgr::ms_strAMS2750_CAL_TECHNICIAN_ID_KEY = L"TECH_ID";
const QString  CRecSetupCfgMgr::ms_strAMS2750_CAL_PERFORMED_BY_KEY = L"PERF_BY";
const QString  CRecSetupCfgMgr::ms_strAMS2750_CAL_PERFORMED_FOR_KEY = L"PERF_FOR";
const QString  CRecSetupCfgMgr::ms_strAMS2750_CAL_QUALITY_ORG_KEY = L"QUAL";
const QString  CRecSetupCfgMgr::ms_strAMS2750_CAL_PASSED_KEY = L"PASS";
const QString  CRecSetupCfgMgr::ms_strAMS2750_CAL_TEST_DATE_KEY = L"TEST_DT";
const QString  CRecSetupCfgMgr::ms_strAMS2750_CAL_NEXT_CAL_DATE_KEY = L"NEXT_DT";
const QString  CRecSetupCfgMgr::ms_strAMS2750_CAL_MULTI_POINT_TABLE_KEY = L"MULT";

const int CRecSetupCfgMgr::ms_iMAX_MENU_RANGE_CHARS = 10;

//Load save Conf properties
const QString  CRecSetupCfgMgr::ms_strLOADSAVECONF_KEY = L"LOADSV";
const QString  CRecSetupCfgMgr::ms_strLOADSAVECONF_SAVE_USB1_KEY = L"SUSB1";
const QString  CRecSetupCfgMgr::ms_strLOADSAVECONF_LOAD_USB1_KEY = L"LUSB1";
const QString  CRecSetupCfgMgr::ms_strLOADSAVECONF_SAVE_USB2_KEY = L"SUSB2";
const QString  CRecSetupCfgMgr::ms_strLOADSAVECONF_LOAD_USB2_KEY = L"LUSB2";
const QString  CRecSetupCfgMgr::ms_strLOADSAVECONF_SAVE_CF_KEY = L"SCF";
const QString  CRecSetupCfgMgr::ms_strLOADSAVECONF_LOAD_CF_KEY = L"LCF";
const QString  CRecSetupCfgMgr::ms_strLOADSAVECONF_SAVE_NAS_KEY = L"SNAS";
const QString  CRecSetupCfgMgr::ms_strLOADSAVECONF_LOAD_NAS_KEY = L"LNAS";

//Export Recorded data
const QString  CRecSetupCfgMgr::ms_strEXPORT_CSV_GROUP_KEY = L"GRP";

//const WCHAR* g_wcaLOTNO_REG_DIR					= L"SOFTWARE\\Honeywell\\TVV6\\LotNo"; //commented by kranti
//const WCHAR* g_wcaLOTNO_REG_LOT_NO_KEY			= L"LotNo";

//****************************************************************************
// CRecSetupCfgMgr(void)
///
/// Constructor
///
//****************************************************************************
CRecSetupCfgMgr::CRecSetupCfgMgr(void) : CBaseCfgMgr(ctSetup), m_usEVENT_TYPE_NOT_INIT(32), m_fMIN_DEV_LEVEL(0.0000001f) {
//not used in TTR6SETUP code
	OutputDebugString(_T("CRecSetupCfgMgr::CRecSetupCfgMgr...Start!\n"));
#ifndef TTR6SETUP
	m_ModuleMessageManagerClient.MMMClientRegister(MODULE_SETUP_CFG_MGR, MODULE_SEND_ONLY, CAMQ_QUEUE_WRAP_DISABLED);
#endif

	QMutex* m_kCriticalSection;

	LoadStrings();

	// setup the default for the duration number format
	m_tDurationNumasprintf.Auto = FALSE;
	// limit to one decimal place
	m_tDurationNumasprintf.Ad = 1;
	m_tDurationNumasprintf.Bd = 4;
	m_tDurationNumasprintf.Scientific = FALSE;
	m_tDurationNumasprintf.Zpad = FALSE;
	m_tDurationNumasprintf.Base = FALSE;

	for (USHORT usCount = 0; usCount < EVENTSYSTEM_EVENT_SIZE; usCount++) {
		m_usaEventEffectTypes[usCount][0] = m_usEVENT_TYPE_NOT_INIT;
		m_usaEventEffectTypes[usCount][1] = m_usEVENT_TYPE_NOT_INIT;
		m_usaEventCauseTypes[usCount][0] = m_usEVENT_TYPE_NOT_INIT;
		m_usaEventCauseTypes[usCount][1] = m_usEVENT_TYPE_NOT_INIT;
	}
#ifdef TTR6SETUP	
	// Stability Project Fix: for issue, restrict 32 pens in a group
	memset(m_GrpPenCounter,0,sizeof(m_GrpPenCounter));
#endif
	OutputDebugString(_T("CRecSetupCfgMgr::CRecSetupCfgMgr...End!\n"));
}
//****************************************************************************
// ~CRecSetupCfgMgr(void)
///
/// Destructor
///
//****************************************************************************
CRecSetupCfgMgr::~CRecSetupCfgMgr(void) {
	ms_kTimeZoneRegKeyArr.clear();

	//deletion of mutex not required
}
//****************************************************************************
// CRecSetupCfgMgr* Instance()
///
/// Singleton Accessor/Creator
///
/// @return A pointer to the singleton instance of the class
/// 
//****************************************************************************
CRecSetupCfgMgr* CRecSetupCfgMgr::Instance() {
	// check if the pointer exists yet
	if (ms_kConfigSysMgr.get() == NULL) {
		DWORD waitSingleObjectResult = WAIT_OBJECT_0;
		// An instance has yet to be completed
		ms_hCreationMutex = CreateMutex(NULL,						// No security descriptor
				FALSE,						// Mutex object not owned
				TEXT("CRecSetupCfgMgr"));	// Object name
		waitSingleObjectResult = ms_hCreationMutex.tryLock(g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);

		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:
			// Object was signaled
			if (NULL == ms_kConfigSysMgr.get()) {
				// not been created yet therefore create one now
				std::auto_ptr<CRecSetupCfgMgr> kNewConfigSysMgr(new CRecSetupCfgMgr);
				ms_kConfigSysMgr = kNewConfigSysMgr;
			}
			if ( FALSE == ms_hCreationMutex.unlock())
				V6WarningMessageBox(NULL, L"Failed to release CRecSetupCfgMgr mutex", L"Error", MB_OK);
			break;

		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
			V6WarningMessageBox(NULL, L"CRecSetupCfgMgr WaitForSingleObject Error", L"Error", MB_OK);
			break;
		}
		// Close the Mutex as no longer required
		//No need to close the mutex in Qt
	}
	return ms_kConfigSysMgr.get();
}
//****************************************************************************
// void LoadStrings()
///
/// Method that loads all the title strings and listbox items into some static string 
/// objects. This is to decrease memory usage
/// 
//****************************************************************************
void CRecSetupCfgMgr::LoadStrings() {
	CBaseCfgMgr::LoadStrings();

	ms_strPenLogLogTypeList = tr("Continuous|Fuzzy|");

	T_PGENERALCONFIG ptGeneralData = pSETUP->GetGeneralSetupConfig()->GetSystemGeneralBlock(CONFIG_MODIFIABLE);
	QString  strGroup("");
	ms_strPenGroupList = tr("No Group|");

	// loop through the groups inserting their number and name
	for (USHORT usGroupCount = 0; usGroupCount < GENERALCONFIG_GROUPNAME_SIZE; usGroupCount++) {
		strGroup.asprintf(L"%s|", ptGeneralData->GroupName[usGroupCount]);
		ms_strPenGroupList += strGroup;
	}

	ms_strPenLogScaleList = tr("Linear|Log|");
	ms_strPenScaleAutoList = tr("User Defined|Auto|");
	ms_strAlarmEnableTypeList = tr("Disabled|Enabled Always|Dig Enabled|");
	ms_strAlarmTypeList = tr("High|Low|Deviation|Rate Up|Rate Down|");
	ms_strPenLogStyleList = tr("Sample|Average|Max/Min|");
	ms_strPenLogAlignList = tr("None|Second|Minute|15 Minute|Hour|");
	ms_strPenTotTypeList = tr("Normal|Sterilization|");
	ms_strPenTotTempUnitsList = tr("Celsius|Fahrenheit|Kelvin|");

	ms_strPenLogRateUnitsList = tr("Milliseconds|Seconds|Minutes|Hours|");
	ms_strPenLogRateShortUnitsList = tr("ms|Sec|Min|Hr|");
	ms_strPenLogRateMsList = tr("500ms (2Hz)|200ms (5Hz)|100ms (10Hz)|20ms (50Hz)|");

	// check if we are not allowing fast scan
	if (!pSYSTEM_INFO->FWOptionFastScanAvailable()) {
		// remove the last option (50Hz) from the list
		QString  str50HertzOption = CStringUtils::GetItemAtPos(ms_strPenLogRateMsList, lmr50Hertz);
		// add the delimiter
		str50HertzOption += L"|";
		ms_strPenLogRateMsList.Delete(ms_strPenLogRateMsList.size() - str50HertzOption.size(),
				str50HertzOption.size());
	}

	ms_strAINTypeList = tr("Volts|Amps|Ohms|RT|TC|");
	ms_strAINAcqRateList = tr("2Hz (500ms)|5Hz (200ms)|10Hz (100ms)|50Hz (20ms)|");
	ms_strEZAINAcqRateList = tr("2Hz (500ms)|5Hz (200ms)|");

	// check if we are not allowing fast scan
	if (!pSYSTEM_INFO->FWOptionFastScanAvailable()) {
		// remove the last option (50Hz) from the list
		QString  str50HertzOption = CStringUtils::GetItemAtPos(ms_strAINAcqRateList, AI_ACQ_RATE_50HZ);
		// add the delimiter
		str50HertzOption += L"|";
		ms_strAINAcqRateList.Delete(ms_strAINAcqRateList.size() - str50HertzOption.size(),
				str50HertzOption.size());
	}

	ms_strAINTCRTAcqRateList = tr("2Hz (500ms)|5Hz (200ms)|10Hz (100ms)|");
	ms_strAINLinModeList = tr("Preset|User Defined|");
	ms_strAINEZRTTypeList = tr("PT100©0©|PT200©1©|Nickel 120 OHM©4©|Nickel 100 OHM©5©|PT1000©6©|PT500©7©|");
	ms_strAINRTTypeList = tr("PT100|PT200|CU10|CU53|Nickel 120 OHM|Nickel 100 OHM|PT1000|PT500|");
	ms_strAINUpScaleBurnOutList = tr("Downscale|Upscale|");
	ms_strAINBurnOutSelList.LoadString(IDS_CFG_AIN_LIN_TC_BURN_OUT_SEL_LIST);
	ms_strAINActiveBurnOutList = tr("Passive|Active|");
	ms_strAINTCTypeList =
			tr(
					"Type K|Type R|Type S|Type B|Type J|Type T|Type E|Type N|Type C|Type G (W)|Chromel/Copel|Type L|Type M|Platinel|Type D|");
	ms_strAINCJCMethodList = tr("Int Automatic|Ext 0 Deg C|Ext with Spec Temp|Ext Input|");
	ms_strAINSqrtExtractList = tr("Off|On|");

	ms_strAINRangePresetVoltsList = tr(
			"©50V|©25V|©12V|©6V|©3V|©1.5V|©0.6V|©0.3V|©1000mV|©500mV|©250mV|©100mV|©50mV|©25mV|©10mV|©5mV|");
	ms_strAINRangePresetAmpsList = tr("0-20mA|4-20mA|");
	ms_strAINRangePresetOhmsList = tr("200|500|1K|4K|");

	ms_strAINCalibrationTypesList = tr("None|Single Point|Dual Point|Multi Point|");

	ms_strAnalogueInAMS2750SensorTypeListKey = tr("Expendable|Non-expendable|");

	ms_strDemoWaveTypeList = tr(
			"None|Sin Wave|Ramp Up|Ramp Down|Ramp Up/Down|Square Wave|Drift|Pulse|Digital|UI AI|UI DI|");

	// Event Cause Lists
	ms_strEventsCauseTypesList =
			tr(
					"Alarms|Totalizers|Digital Inputs|TC Burn Out|Scheduled|User Counters|Max Mins (Reset)|System|User Action|Batch|TUS|AMS2750 Timer|TC Health Monitor|");
	ms_strEventsCauseAlarmSubTypesList = tr("Into Alarm|Out of Alarm|Ack. Alarm|");
	ms_strEventsCauseTotaliserSubTypesList = tr("Start|Stop|Reset|Rollover|");
	ms_strEventsCauseDigInputsTypesList = tr("On|Off|State Change|");

	// Event Effects Lists
	ms_strEventsEffectsTypesList =
			tr(
					"Mark Chart|Logging|Totalizer|Digital Outputs|Alarm Ack|Email|Screen Change|Print Screen|Counters|Max Mins (Reset)|Chart Control|Clear Messages|Delayed Event|Script Timers|Play Sound|Display Alert|Batch|Reports|Update Tabular Readings|Enter Replay Screen|Exit Replay Screen|Change Chart Speed|");
	ms_strEventsEffectsLoggingSubTypesList = tr("Start|Stop|");
	ms_strEventsEffectsTotaliserSubTypesList = tr("Start|Stop|Reset|Reset and Start|");
	ms_strEventsEffectsDigOutputsSubTypesList = tr("On|Off|");
	ms_strEventsEffectsEmailSubTypesList = tr("Auto|Single Line User|Multiline User|");
	ms_strEventsEffectsCountersSubTypesList = tr("User|Pulse|Events|Digital Inputs|Relay Outputs|Alarms|");
	ms_strEventsEffectsCountersResetOrIncList = tr("Reset|Increment|");

	// Screen List Names
	ms_strScreenSaverModeList = tr("Between Hours on Days|");
	ms_strScreenSaverTypeList = tr("Normal|Shift|");
	ms_strScreenSaverDimList = tr("Off Always|Use Saver Brightness|");
	ms_strScreenChartSpeedFastList = tr("6000mm/h|1200mm/h|600mm/h|300mm/h|120mm/h|60mm/h|");
	ms_strScreenChartSpeedMedList = tr("120mm/h|60mm/h|30mm/h|20mm/h|10mm/h|");
	ms_strScreenChartSpeedSlowList = tr("20mm/h©3©|10mm/h©0©|5mm/h©1©|1mm/h©2©|");

	ms_strScreenCircChartSpeedFastList = tr("15 mins|30 mins|1 hour|4 hours|8 hours|");
	ms_strScreenCircChartSpeedMedList = tr("4 hours|8 hours|12 hours|1 day|2 days|");
	ms_strScreenCircChartSpeedSlowList = tr("2 days|5 days|1 week|2 weeks|4 weeks|");
	ms_strScreenCircChartDayAlignmentList = tr("Sun|Mon|Tues|Weds|Thurs|Fri|Sat|");

	// Screen Tabular Display Names
	ms_strScreenTabDispUpdateMethodList = tr("Event|Periodic|");

	// Printer List Names
	ms_strPrinterSizeList = tr("A4|Letter|");
	ms_strPrinterOrientationList = tr("Landscape|Portrait|");
	ms_strPrinterPclLanguageList = tr("PCL3|PCL3GUI|PCL5|");
	ms_strPrinterPortList = tr("USB|Network|");

	//Localisation List Names
	//#if LangAll == 1 kiran
	ms_strLocalLangList =
			tr(
					"English (UK)|English (US)|French|German|Italian|Spanish|Brazilian|Polish|Hungarian|Slovakian|Czech|Turkish|Romanian|Russian|Portuguese|Greek|Bulgarian|Korean|Chinese|Japanese|");
	//#endif
	//#if LangChinese == 1
	//	ms_strLocalLangList = tr("English (UK)|English (US)|French|German|Italian|Spanish|Brazilian|Polish|Hungarian|Slovakian|Czech|Turkish|Romanian|Russian|Portuguese|Greek|Bulgarian|Chinese|");
	//#endif
	//#if LangJapanese == 1
	//	ms_strLocalLangList = tr("English (UK)|English (US)|French|German|Italian|Spanish|Brazilian|Polish|Hungarian|Slovakian|Czech|Turkish|Romanian|Russian|Portuguese|Greek|Bulgarian|Japanese|");
	//#endif
	//#if LangKorean == 1
	//	ms_strLocalLangList = tr("English (UK)|English (US)|French|German|Italian|Spanish|Brazilian|Polish|Hungarian|Slovakian|Czech|Turkish|Romanian|Russian|Portuguese|Greek|Bulgarian|Korean|");
	//#endif

	// check this is a Honeywell build rather than an OEM - if it is not Honeywell then we
	// must remove the Greek language option
	QString  strCompanyName("");
	strCompanyName = pSYSTEM_INFO->pOemInfo->GetText( V6RES_TEXT_CONAME)->szTextValue;
	if (strCompanyName.indexOf(L"Honeywell") == -1) {
		QString  strNonSeqLangList("");
		// loop through all the languages and turn the list into a non-sequential list with
		// Greek removed	
		for (USHORT usCount = 0; usCount < lngMaxLangs; usCount++) {
			// test for Greek
			if (static_cast<T_LANGUAGES>(usCount) != lngGrk) {
				QString  strLang("");
				strLang.asprintf(L"%s%c%u%c%s", CStringUtils::GetItemAtPos(ms_strLocalLangList, usCount),
						g_wcEMBEDDED_INFO_DELIM, usCount, g_wcEMBEDDED_INFO_DELIM, CStringUtils::ms_strDELIMITTER);
				strNonSeqLangList += strLang;
			} else {
				// Greek so do nothing
			}
		}
		// copy the new non-sequnetial list to the existing one
		ms_strLocalLangList = strNonSeqLangList;
	}

	ms_strLocalTempasprintfList = tr("Deg C|Deg F|Kelvin|");
	ms_strLocalMainsFreqList = tr("50Hz|60Hz|");
	ms_strLocalHelpLangList = tr("English|French|German|Italian|Spanish|");

	// Credits List Names
	ms_strCreditsOptMathTypeList = tr("Basic Maths|Full Maths|Scripting|");

	// remove the scripting option if this is an eZTrend
	if (GlbDevCaps.IsRecorderEzTrend()) {
		QString  strTempList(
				CStringUtils::GetItemAtPos(ms_strCreditsOptMathTypeList, 0) + CStringUtils::ms_strDELIMITTER);
		strTempList += CStringUtils::GetItemAtPos(ms_strCreditsOptMathTypeList, 1) + CStringUtils::ms_strDELIMITTER;
		ms_strCreditsOptMathTypeList = strTempList;
	}

	// Demo boards List Names
	ms_strDemoBoardEnabledList = tr("No Simulation|Sim. if board not fitted|");

	// Modbus List Names
	ms_strModbusPortList = tr("RS-485|Ethernet|");
	ms_strModbusProtocolList = tr("Modbus (FPLB)|Modbus-X (FP B)|");

	// Modbus Master List Names
	ms_strModbusMasterSlaveMapList = tr("Coil Status(1)|Input Status(2)|Holding Registers(3)|Input Registers(4)|");
	ms_strModbusMasterSlaveDirList = tr("In|Out|");
	ms_strModbusMasterSlaveInsDataTypeList = tr("signed 16-bit int|unsigned 16-bit int|IEEE float|");
	ms_strModbusMasterSlaveOutsDataTypeList = tr("Pens|");

	// Serial Port List Names
	ms_strSerPortBaudRateList = tr("2400|4800|9600|19200|38400|57600|115200|");
	ms_strSerPortByteOptsList = tr("N-8-1|E-8-1|O-8-1|N-8-2|");

	//TLS Protocol List Names
	ms_strTLSProtocolList = tr("TLS 1.0|TLS 1.1|TLS 1.2|");

	// Digital List Names
	ms_strDigioIOPulseTypeList = tr("Input|Output|Pulse Input|");
	ms_strDigioIOTypeList = tr("Input|Output|");
	ms_strDigioIOOutputTypeList = tr("Output");
	ms_strDigioOutFailsafeList = tr("Off|On|");
	ms_strDigioOutLatchedList = tr("Single Pulse|Latched|");
	ms_strDigioIOReportTypeList = tr("None|User Messages|User Messages and Chart|");

	// Pulse Input List Names
//	ms_strPulseInMeasurementMethodList.LoadString( IDS_CFG_PULSE_MEASUREMENT_METHOD_LIST );
	ms_strPulseInMeasurementUpdateList = tr("1HZ|");

	// Analogue Output List Names
	ms_strAnalogueOutputCurrentList = tr("4-20mA|0-20mA|");

	// Time zones list
	ms_strTimeZoneList = L"(GMT-12:00) International Date Line West|"
			L"(GMT-11:00) midway Island, Samoa|"
			L"(GMT-10:00) Hawaii|"
			L"(GMT-09:00) Alaska|"
			L"(GMT-08:00) Pacific Time (US & Canada); Tijuana|"
			L"(GMT-07:00) Arizona|"
			L"(GMT-07:00) Mountain Time (US & Canada)|"
			L"(GMT-07:00) Chihuahua, La Paz, Mazatlan|"
			L"(GMT-06:00) Central America|"
			L"(GMT-06:00) Guadalajara, Mexico City, Monterrey|"
			L"(GMT-06:00) Central Time (US & Canada)|"
			L"(GMT-06:00) Saskatchewan|"
			L"(GMT-05:00) Indiana (East)|"
			L"(GMT-05:00) Bogota, Lima, Quito|"
			L"(GMT-05:00) Eastern Time (US & Canada)|"
			L"(GMT-04:00) Caracas, La Paz|"
			L"(GMT-04:00) Santiago|"
			L"(GMT-04:00) Atlantic Time (Canada)|"
			L"(GMT-03:30) Newfoundland|"
			L"(GMT-03:00) Buenos Aires, Georgetown|"
			L"(GMT-03:00) Brasilia|"
			L"(GMT-03:00) Greenland|"
			L"(GMT-02:00) mid-Atlantic|"
			L"(GMT-01:00) Cape Verde Is.|"
			L"(GMT-01:00) Azores|"
			L"(GMT) Greenwich Mean Time : Dublin, Edinburgh, Lisbon, London|"
			L"(GMT) Casablanca, Monrovia|"
			L"(GMT+01:00) Belgrade, Bratislava, Budapest, Ljubljana, Prague|"
			L"(GMT+01:00) Sarajevo, Skopje, Warsaw, Zagreb|"
			L"(GMT+01:00) West Central Africa|"
			L"(GMT+01:00) Amsterdam, Berlin, Bern, Rome, Stockholm, Vienna|"
			L"(GMT+01:00) Brussels, Copenhagen, Madrid, Paris|"
			L"(GMT+02:00) Harare, Pretoria|"
			L"(GMT+02:00) Bucharest|"
			L"(GMT+02:00) Helsinki, Kyiv, Riga, Sofia, Tallinn, Vilnius|"
			L"(GMT+02:00) Athens, Istanbul, Minsk|"
			L"(GMT+02:00) Jerusalem|"
			L"(GMT+02:00) Cairo|"
			L"(GMT+03:00) Moscow, St. Petersburg, Volgograd|"
			L"(GMT+03:00) Nairobi|"
			L"(GMT+03:00) Baghdad|"
			L"(GMT+03:00) Kuwait, Riyadh|"
			L"(GMT+03:30) Tehran|"
			L"(GMT+04:00) Baku, Tbilisi, Yerevan|"
			L"(GMT+04:00) Abu Dhabi, Muscat|"
			L"(GMT+04:30) Kabul|"
			L"(GMT+05:00) Islamabad, Karachi, Tashkent|"
			L"(GMT+05:00) Ekaterinburg|"
			L"(GMT+05:30) Chennai, Kolkata, Mumbai, New Delhi|"
			L"(GMT+05:45) Kathmandu|"
			L"(GMT+06:00) Almaty, Novosibirsk|"
			L"(GMT+06:00) Astana, Dhaka|"
			L"(GMT+06:00) Sri Jayawardenepura|"
			L"(GMT+06:30) Rangoon|"
			L"(GMT+07:00) Bangkok, Hanoi, Jakarta|"
			L"(GMT+07:00) Krasnoyarsk|"
			L"(GMT+08:00) Perth|"
			L"(GMT+08:00) Taipei|"
			L"(GMT+08:00) Beijing, Chongqing, Hong Kong, Urumqi|"
			L"(GMT+08:00) Irkutsk, Ulaan Bataar|"
			L"(GMT+08:00) Kuala Lumpur, Singapore|"
			L"(GMT+09:00) Yakutsk|"
			L"(GMT+09:00) Seoul|"
			L"(GMT+09:00) Osaka, Sapporo, Tokyo|"
			L"(GMT+09:30) Adelaide|"
			L"(GMT+09:30) Darwin|"
			L"(GMT+10:00) Canberra, Melbourne, Sydney|"
			L"(GMT+10:00) Guam, Port Moresby|"
			L"(GMT+10:00) Vladivostok|"
			L"(GMT+10:00) Brisbane|"
			L"(GMT+10:00) Hobart|"
			L"(GMT+11:00) Magadan, Solomon Is., New Caledonia|"
			L"(GMT+12:00) Auckland, Wellington|"
			L"(GMT+12:00) Fiji, Kamchatka, Marshall Is.|"
			L"(GMT+13:00) Nuku'alofa|";

	// loop through setting up the registry key map
	USHORT usCurrZone = 0;
	QString  strCurrZone = CStringUtils::GetItemAtPos(ms_strTimeZoneList, usCurrZone);

	ms_kTimeZoneRegKeyArr.InitHashTable(89);
	do {
		switch (usCurrZone) {
		case 0:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Dateline Standard Time";
			break;
		case 1:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Samoa Standard Time";
			break;
		case 2:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Hawaiian Standard Time";
			break;
		case 3:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Alaskan Standard Time";
			break;
		case 4:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Pacific Standard Time";
			break;
		case 5:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\US Mountain Standard Time";
			break;
		case 6:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Mountain Standard Time";
			break;
		case 7:
			//PSR - fix for the DST_Hung issue
			//ms_kTimeZoneRegKeyArr[ usCurrZone ] = L"Time Zones\\Mexico Standard Time 2";
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Mountain Standard Time (Mexico)";

			break;
		case 8:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Central America Standard Time";
			break;
		case 9:
			//PSR - fix for the DST_Hung issue
			//ms_kTimeZoneRegKeyArr[ usCurrZone ] = L"Time Zones\\Mexico Standard Time";
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Central Standard Time (Mexico)";

			break;
		case 10:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Central Standard Time";
			break;
		case 11:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Canada Central Standard Time";
			break;
		case 12:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\US Eastern Standard Time";
			break;
		case 13:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\SA Pacific Standard Time";
			break;
		case 14:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Eastern Standard Time";
			break;
		case 15:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\SA Western Standard Time";
			break;
		case 16:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Pacific SA Standard Time";
			break;
		case 17:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Atlantic Standard Time";
			break;
		case 18:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Newfoundland Standard Time";
			break;
		case 19:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\SA Eastern Standard Time";
			break;
		case 20:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\E. South America Standard Time";
			break;
		case 21:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Greenland Standard Time";
			break;
		case 22:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\mid-Atlantic Standard Time";
			break;
		case 23:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Cape Verde Standard Time";
			break;
		case 24:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Azores Standard Time";
			break;
		case 25:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\GMT Standard Time";
			break;
		case 26:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Greenwich Standard Time";
			break;
		case 27:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Central Europe Standard Time";
			break;
		case 28:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Central European Standard Time";
			break;
		case 29:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\W. Central Africa Standard Time";
			break;
		case 30:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\W. Europe Standard Time";
			break;
		case 31:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Romance Standard Time";
			break;
		case 32:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\South Africa Standard Time";
			break;
		case 33:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\E. Europe Standard Time";
			break;
		case 34:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\FLE Standard Time";
			break;
		case 35:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\GTB Standard Time";
			break;
		case 36:
			//PSR - fix for the DST_Hung issue
			//ms_kTimeZoneRegKeyArr[ usCurrZone ] = L"Time Zones\\Jerusalem Standard Time";
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Israel Standard Time";
			break;
		case 37:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Egypt Standard Time";
			break;
		case 38:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Russian Standard Time";
			break;
		case 39:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\E. Africa Standard Time";
			break;
		case 40:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Arabic Standard Time";
			break;
		case 41:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Arab Standard Time";
			break;
		case 42:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Iran Standard Time";
			break;
		case 43:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Caucasus Standard Time";
			break;
		case 44:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Arabian Standard Time";
			break;
		case 45:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Afghanistan Standard Time";
			break;
		case 46:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\West Asia Standard Time";
			break;
		case 47:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Ekaterinburg Standard Time";
			break;
		case 48:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\India Standard Time";
			break;
		case 49:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Nepal Standard Time";
			break;
		case 50:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\N. Central Asia Standard Time";
			break;
		case 51:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Central Asia Standard Time";
			break;
		case 52:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Sri Lanka Standard Time";
			break;
		case 53:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Myanmar Standard Time";
			break;
		case 54:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\SE Asia Standard Time";
			break;
		case 55:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\North Asia Standard Time";
			break;
		case 56:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\W. Australia Standard Time";
			break;
		case 57:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Taipei Standard Time";
			break;
		case 58:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\China Standard Time";
			break;
		case 59:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\North Asia East Standard Time";
			break;
		case 60:
			//PSR - fix for the DST_Hung issue
			//ms_kTimeZoneRegKeyArr[ usCurrZone ] = L"Time Zones\\Malay Peninsula Standard Time";
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Singapore Standard Time";
			break;
		case 61:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Yakutsk Standard Time";
			break;
		case 62:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Korea Standard Time";
			break;
		case 63:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Tokyo Standard Time";
			break;
		case 64:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Cen. Australia Standard Time";
			break;
		case 65:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\AUS Central Standard Time";
			break;
		case 66:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\AUS Eastern Standard Time";
			break;
		case 67:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\West Pacific Standard Time";
			break;
		case 68:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Vladivostok Standard Time";
			break;
		case 69:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\E. Australia Standard Time";
			break;
		case 70:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Tasmania Standard Time";
			break;
		case 71:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Central Pacific Standard Time";
			break;
		case 72:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\New Zealand Standard Time";
			break;
		case 73:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Fiji Standard Time";
			break;
		case 74:
			ms_kTimeZoneRegKeyArr[usCurrZone] = L"Time Zones\\Tonga Standard Time";
			break;
		}

		// move on the next zone
		++usCurrZone;
		strCurrZone = CStringUtils::GetItemAtPos(ms_strTimeZoneList, usCurrZone);
	} while (strCurrZone != "");

	ms_strRecordingSchedTimeList = tr("10 Minutes|30 Minutes|1 Hour|2Hours|12 Hours|24 Hours|");

	ms_strEventsCauseSchedEventTypesList = tr("Once|Interval|Specific Days|Month End|");
	ms_strEventsCauseSchedEventAlignList = tr("None|Minute|Hour|Day|");
	ms_strEventsEffectsChartControlSubTypeList = tr("Pause|Stop|Resume|Clear|Prefill|");
	ms_strEventsCauseSystemSubTypesList = tr("Power On|Setup Change|Int. Mem. Low|Exp. Mem. Lo|FTP Mem. Lo|");
#ifdef XSERIESSETUP
	ms_strEventsCauseUserActionSubTypesList = tr("Mark Chart| Hot Button|");
#else
	ms_strEventsCauseUserActionSubTypesList = tr("Mark Chart|Hot Button 1|Hot Button 2|Hot Button 3|Hot Button 4|");
	ms_strEventsCauseUserActionSubTypesListQx = tr("Mark Chart|Hot Button 1|Hot Button 2|");
	ms_strEventsCauseUserActionSubTypesListEz = tr("Mark Chart| Hot Button|");
#endif
	ms_strEventsCauseBatchSubTypesList = tr("Start|Stop|Pause|");
	ms_strEventsCauseTUSSubTypesList = tr("Start|Stop|Soak Started|Stability Achieved|Soak Complete|");
	ms_strEventsCauseAMS2750TimersSubTypesList = tr("TC/RT Timers|Process Timers|");
	ms_strEventsCauseAMS2750TimersAlertTypeList = tr("Warning|Expired|");

	ms_strEventsEffectsTimersSubTypeList = tr("Start|Stop|Reset|Reset and Start|");
	ms_strEventsEffectsSoundSubTypeList = tr("Start|Stop|");
	ms_strEventsEffectsSoundPlayModeList = tr("Continuous|Single Shot|");
	ms_strEventsEffectsMarkerModeList = tr("User Defined|Preset|");
	ms_strEventsEffectsPenSelTypesList = tr("Multiple Pens|Pen Group|All Pens|");
	ms_strEventsEffectsBatchSubTypeList = tr("Start|Stop|Pause|");
	ms_strEventsEffectsAlarmSelTypesList = tr("Single Pen|Pen Group|All Pens|");
	ms_strEventsEffectsChartControlSelTypesList = tr("All Groups|Single Group|");
	ms_strEventsEffectsPrintScreenSubTypeList = tr("Printer|External Media|");
	ms_strEventsEffectsScreenSubTypeList = tr("Change Screen|Backlight On/Off|");
	ms_strEventsEffectsScreenBacklightOnOffList = tr("Off|On|");

	// Rahul do loadstring ....
	//ms_strEventsEffectsMsgTypeList = L"All|Alarm|System|Diagnostic|Security|User|";
	ms_strEventsEffectsMsgTypeList = tr("All|Alarm|System|Diagnostic|Security|User|");
	ms_strReportIndTypeList = tr("Single Shot|Continuous|");
	ms_strReportIndTriggerList = tr("Manual|Schedule|Event|Batch|");
	ms_strReportIndStyleList = tr("Normal|Batch|TUS|");

	// remove TUS report style if not a TUS recorder
	if (!pSYSTEM_INFO->FWOptionTUSModeAvailable()) {
		// delete the string by gettings its length + 1 so as to include the delimitter
		const int iCHARS_TO_DELETE = CStringUtils::GetItemAtPos(ms_strReportIndStyleList, rssTUS).GetLength() + 1;
		ms_strReportIndStyleList.Delete(ms_strReportIndStyleList.size() - iCHARS_TO_DELETE, iCHARS_TO_DELETE);
	}
	ms_strReportIndPenSelTypeList = tr("Multiple Pens|Pen Group|All Pens|");
	ms_strReportIndSchedSubTypeList = tr("Once|Interval|Specific Days|Month End|");
	ms_strReportIndPeriodList = tr("Do not include|Hour|Day|Week|Month|Current|");
	ms_strReportIndAvgPeriodList = tr("Do not include|Hour|Day|Week|Month|");
	ms_strReportIndMsgPeriodList = tr("Do not include|Last Hour|Last Day|Last Week|Last Month|All|");
	ms_strReportIndIncCurrPenList = tr("Do Not Include|Included|");
	ms_strReportIndFooterList = tr("Two Lines|Single Line|");

	// Load TimeSync Trigger List
	ms_strTriggerList = tr("OFF|ON|");

	// AMS2750 Furnace Lists
	ms_strAMS2750FurnaceClassList = tr("1|2|3|4|5|6|");
	ms_strAMS2750FurnaceTypeList = tr("Parts|Raw Materials|");
	ms_strAMS2750FurnaceInstTypeList = tr("A|B|C|D|E|");
	ms_strAMS2750FurnaceShapeList = tr("Rectangular|Cylindrical|Other|");
	ms_strAMS2750FurnaceMeasUnitsList = tr("Metres|Feet|Millimetres|Inches|");

	// load the sound filenames
	LoadSoundFileNames();
}
//****************************************************************************
// const QString   GetSoundFileNamesList( )
///
/// Method used to get hold of the filename list
///
/// @return		String containing the delimitted filename list
///
//****************************************************************************
const QString  CRecSetupCfgMgr::GetSoundFileNamesList() {
	m_kCriticalSection.lock();

	QString  strSoundList(ms_strSoundList);

	m_kCriticalSection.lock();

	return strSoundList;
}
//****************************************************************************
// void LoadSoundFileNames( )
///
/// Method that loads the sound filenames in
///
//****************************************************************************
void CRecSetupCfgMgr::LoadSoundFileNames() {
	m_kCriticalSection.lock();

	HANDLE hindexOf;
	WIN32_FIND_DATA indexOfFileData;
	// create an array of filenames - it must be twice the max sounds though as we need to read
	// all posibilities from the custom and default sound directories
	QString  strFileNames[g_usMAX_SOUNDS * 2];
	USHORT usFileNameCount = 0;

	indexOfFileData.cFileName[0] = '\0';
	WCHAR wcaWavsPath[ MAX_PATH];
	WCHAR wcaExtension[6] = L"*.wav";
	memset(wcaWavsPath, 0, sizeof(WCHAR) * MAX_PATH);

	// search the custom wavs directory first
	pDALGLB->BuildPath(IDS_INTERNAL_SD, IDS_CUSTOM_WAVS, wcaExtension, wcaWavsPath, MAX_PATH);

	hindexOf = indexOfFirstFile(wcaWavsPath, &indexOfFileData);

	// loop round the file names getting the names
	if (hindexOf != INVALID_HANDLE_VALUE) {
		// loop though all the files that are present
		do {
			// get the file name
			strFileNames[usFileNameCount] = indexOfFileData.cFileName;

			// check the first character is an uppercase S
			if (strFileNames[usFileNameCount][0] == L's') {
				// change to an uppercase one
				strFileNames[usFileNameCount].SetAt(0, L'S');
			}

			// increment the filename count
			++usFileNameCount;
		} while ((indexOfNextFile(hindexOf, &indexOfFileData) != 0) && (usFileNameCount < g_usMAX_SOUNDS));
	}

	// close the handle to the files
	indexOfClose(hindexOf);

	// now search the default wavs directory
	pDALGLB->BuildPath(IDS_INTERNAL_SD, IDS_WAVS, wcaExtension, wcaWavsPath, MAX_PATH);

	hindexOf = indexOfFirstFile(wcaWavsPath, &indexOfFileData);

	// loop round the file names getting the names
	if (hindexOf != INVALID_HANDLE_VALUE) {
		// loop though all the files that are present
		do {
			// get the file name
			strFileNames[usFileNameCount] = indexOfFileData.cFileName;

			// check the first character is an uppercase S
			if (strFileNames[usFileNameCount][0] == L's') {
				// change to an uppercase one
				strFileNames[usFileNameCount].SetAt(0, L'S');
			}

			// increment the filename count
			++usFileNameCount;
		} while ((indexOfNextFile(hindexOf, &indexOfFileData) != 0) && (usFileNameCount < (g_usMAX_SOUNDS * 2)));
	}

	// close the handle to the files
	indexOfClose(hindexOf);

	QString  strSearchString("");
	QString  strSoundName("");

	// erase the contents of the current list
	ms_strSoundList = "";

	// loop through all the sound filenames we picked out - as the custom filenames
	// always come first we can rest assured the custom filename will be picked up first and thus
	// the default one will be ignored.
	for (USHORT usCount = 0; usCount < g_usMAX_SOUNDS; usCount++) {
		strSearchString.asprintf(L"S%u-", usCount + 1);
		strSoundName = "";
		// get the relevant file name
		for (usFileNameCount = 0; usFileNameCount < (g_usMAX_SOUNDS * 2); usFileNameCount++) {
			// check if this is the start of the string
			if (strFileNames[usFileNameCount].indexOf(strSearchString) == 0) {
				// we have found the sound so use this file name
				strSoundName = strFileNames[usFileNameCount] + CStringUtils::ms_strDELIMITTER;
				break;
			}
		}
		// check a sound was found - as we have the custom and default directories the code below 
		// should not actually be required anymore - however, I'll leave it in anyway for safety
		if (strSoundName == "") {
			strSoundName = tr("Missing");
			strSoundName += CStringUtils::ms_strDELIMITTER;
		}

		ms_strSoundList += strSoundName;
	}

	m_kCriticalSection.lock();
}
//****************************************************************************
// CConfigInterface *CreatePenConfig( )
///
/// Method that creates a pen config hierarchy
///
/// @return Pointer to the top-level parent of a pen config hierarchy
///
//****************************************************************************
CConfigInterface* CRecSetupCfgMgr::CreatePenConfig() {
	CConfigBranch *pkPenParent = NULL;

	// setup the group names again
	T_PGENERALCONFIG ptGeneralData = pSETUP->GetGeneralSetupConfig()->GetSystemGeneralBlock(CONFIG_MODIFIABLE);
	QString  strGroup("");
	// erase the existing group list
	ms_strPenGroupList = tr("No Group|");

	// loop through the groups inserting their number and name
	for (USHORT usGroupCount = 0; usGroupCount < GENERALCONFIG_GROUPNAME_SIZE; usGroupCount++) {
		strGroup.asprintf(L"%s|", ptGeneralData->GroupName[usGroupCount]);
		ms_strPenGroupList += strGroup;
	}

	// if full script is avaialbe then leave the lust unaffected
	const T_MATH_TYPE_OPTION eMATH_TYPE = pSYSTEM_INFO->FWOptionMathsType();

	if (eMATH_TYPE != MATH_OPTION_FULL_SCRIPT) {
		// full script is not available - check if full block is unavailable before removing it from the list
		if (eMATH_TYPE != MATH_OPTION_FULL_BLOCK) {
			// full block is unavailable too so set the string to basic block only
			ms_strPenMathTypeList = CStringUtils::GetItemAtPos(ms_strCreditsOptMathTypeList, MATH_OPTION_BASIC_BLOCK);
		} else {
			// full block avaialabe so set the string to full block only
			ms_strPenMathTypeList = CStringUtils::GetItemAtPos(ms_strCreditsOptMathTypeList, MATH_OPTION_FULL_BLOCK);
		}
		// add the delimitter
		ms_strPenMathTypeList += L"|";
	} else {
		// full script available therefore we need to allow full block or full script
		ms_strPenMathTypeList = CStringUtils::GetItemAtPos(ms_strCreditsOptMathTypeList, MATH_OPTION_FULL_BLOCK);
		// add the delimitter
		ms_strPenMathTypeList += L"|";

		ms_strPenMathTypeList += CStringUtils::GetItemAtPos(ms_strCreditsOptMathTypeList, MATH_OPTION_FULL_SCRIPT);
		// add the delimitter
		ms_strPenMathTypeList += L"|";
	}

	// Check the pen setup class exists
	CPenSetupConfig *pkPenSetupCfg = pSETUP->GetPenSetupConfig();
	if (pkPenSetupCfg != NULL) {

		// firstly create the top level config interface class
		const USHORT usNO_OF_PENS = V6_MAX_PENS;
		bool bPenConfigEnabled = true;
		QString  strPensTitle("");
		strPensTitle = tr("Pens");
		QString  strPenTitle("");
		strPenTitle = tr("Pen");

		pkPenParent = new CConfigBranch(ms_strPEN_KEY, strPensTitle, strPensTitle, ctMainMenuButton, false, true, 0,
				false, NULL);
#ifdef TTR6SETUP
		// Stability Project Fix: for issue, restrict 32 pens in a group
		//Initialise m_GrpPenCounter
		memset(m_GrpPenCounter,0,sizeof(m_GrpPenCounter));
#endif
		// now create a load of children Pens and add them to the parent
		for (USHORT usCount = 0; usCount < usNO_OF_PENS; usCount++) {
			if ( pSYSTEM_INFO->IsPenAvailable(usCount, ZERO_BASED)) {
				// Get the pen data structure
				T_PPEN ptPenData = NULL;
#ifdef TTR6SETUP
				USHORT 	NewGroup=0;
#endif				

				ptPenData = pkPenSetupCfg->GetPen(usCount, ZERO_BASED, CONFIG_MODIFIABLE);
#ifdef TTR6SETUP				
				// Stability Project Fix: for issue, restrict 32 pens in a group
				//Association of pen and Group
				//map<QString   ,int>Pen_GroupMapping;
				//1-57LYVYJ:Windows10_TMS crash when add recorder in TMS for offline recorder configuration
				if (ptPenData != NULL)
				{
					QString   strPenKey(QString   ::fromWCharArray(""));
					strPenKey.asprintf(L"Pen %d",ptPenData->Instance+1);
					m_PenGroupMap[strPenKey]=ptPenData->GroupNumber;
					//Calculate no of pens for all group.
					if(ptPenData && ptPenData->Enabled)
					{
						NewGroup=ptPenData->GroupNumber;
						m_GrpPenCounter[NewGroup]= SetGroupPenValue(NewGroup);
					}
				}
#endif				
				// Check we managed to obtain a pen
				if (ptPenData != NULL) {
					QString  strIndividualPenKey("");
					strIndividualPenKey.asprintf(L"%s%d", ms_strPEN_KEY, usCount + 1);
					QString  strPenName("");
					QString  strSubTitle("");
					strPenName.asprintf(L"%s %d", strPenTitle, usCount + 1);

					QString  strToTitle("");
					strToTitle = tr("to");

					// check if log scale or not
					if (!ptPenData->Scale.LogScale) {
						strSubTitle.asprintf(L"%s, %.2f %s %.2f %s", ptPenData->Tag, ptPenData->Scale.Zero, strToTitle,
								ptPenData->Scale.Span, ptPenData->Units);
					} else {
						short sEndDecade = ptPenData->Scale.StartDecade + ptPenData->Scale.NumDecades;
						strSubTitle.asprintf(L"%s, E%d %s E%d %s", ptPenData->Tag, ptPenData->Scale.StartDecade,
								strToTitle, sEndDecade, ptPenData->Units);
					}
					strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptPenData->Enabled) + L" "
							+ strSubTitle;

					// check if this pen is a special TUS mode pen - if yes then we must disable the ability
					// to modify its configuration as it is being used for controlling the TUS
					if (!pSYSTEM_INFO->FWOptionTUSModeAvailable()
							|| ((usCount != gs_usSPECIAL_TUS_PEN_START_INST)
									&& (usCount != gs_usSPECIAL_TUS_PEN_START_INST + 1))) {
						bPenConfigEnabled = true;
					} else {
						bPenConfigEnabled = false;
					}
					CConfigBranch *pkPen = new CConfigBranch(strIndividualPenKey, strPenName, strSubTitle,
							ctSubMenuButton, false, bPenConfigEnabled, 0, false, pkPenParent);

					// setup the individual pen data
					SetupPenDetails(pkPen, ptPenData);
					pkPenParent->AddChild(pkPen);
				}
			}
		}
	}
	return pkPenParent;
}
//****************************************************************************
// void SetupPenDetails( CConfigBranch *pkParent, T_PPEN ptPenData )
///
/// Method that sets up the details for a particular pen
///
/// @param[in/out] 		CConfigBranch *pkParent - Pointer to the parent owner class
/// @param[in]		T_PPEN ptPenData - A pointer to the associated pen data
///
/// @todo Finish the edit script item button
//****************************************************************************
void CRecSetupCfgMgr::SetupPenDetails(CConfigBranch *pkParent, T_PPEN ptPenData) {
	// we now need to create all the individual components of a pen
	// Enabled - this will be a boolean type bitfield
	QString  strEnabled("");
	CShortBitFieldData *pkEnData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptPenData), 1, 0,
			ms_strEnabledList, bfeBool, 0, 0, true);
	QString  strSubTitle = pkEnData->GetDataAsString();
	strEnabled = tr("Enabled");
	CConfigItem *pkEnabled = new CConfigItem(ms_strENABLED_KEY, strEnabled, strSubTitle, ctItemButton, pkEnData, false,
			true, 0, false, pkParent);
	pkParent->AddChild(pkEnabled);

	// Tag - Pen Tag Label, WCHAR edit
	QString   CfgData *pkTagData = new QString   CfgData(reinterpret_cast<WCHAR*>(&ptPenData->Tag),
	PEN_TAG_LEN, dtString, 0, 0, true);
	QString  strTag("");
	strTag = tr("Tag");
	CConfigItem *pkTag = new CConfigItem(ms_strTAG_KEY, strTag, ptPenData->Tag, ctItemButton, pkTagData, false,
			(ptPenData->Enabled == TRUE), 0, false, pkParent);
	pkParent->AddChild(pkTag);

// Description - Pen Description Label, WCHAR edit
	QString   CfgData *pkDescData = new QString   CfgData(reinterpret_cast<WCHAR*>(&ptPenData->Description),
	PEN_DESCRIPTION_LEN, dtString, 0, 0, true);
	QString  strDesc("");
	strDesc = tr("Description");
	CConfigItem *pkDesc = new CConfigItem(ms_strDESC_KEY, strDesc, ptPenData->Description, ctItemButton, pkDescData,
			false, (ptPenData->Enabled == TRUE), 0, false, pkParent);
	pkParent->AddChild(pkDesc);

	// Math Type - 0 = Block, 1 = Scripting - also dependso on available firmware options
	QString  strMathType("");
	CShortBitFieldData *pkMathTypeData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptPenData), 2, 1,
			ms_strPenMathTypeList, bfeSingleSelList, 0, 0, true);
	strSubTitle = pkMathTypeData->GetDataAsString();
	strMathType = tr("Maths Type");
	CConfigItem *pkMathType = new CConfigItem(ms_strMATH_TYPE_KEY, strMathType, strSubTitle, ctItemButton,
			pkMathTypeData, false, (ptPenData->Enabled == TRUE), 0, false, pkParent);
	pkParent->AddChild(pkMathType);

	CScriptData *pkScriptData = NULL;
	// Single Line Math Expression which may be single or multiline
	if (ptPenData->MathType == MATH_TYPE_BLOCK) {
		// Edit single line Script - string contained within the pen structure
		pkScriptData = new CScriptData(ptPenData->MathsBlock,
		PEN_MATHSBLOCK_LEN, 0, 0, false);
	} else {
		// Edit multiline script - contained outside ofd the pen structure in a variable size block
		char *pcMultiLineScript = NULL;
		CPenSetupConfig *pkPenSetupCfg = pSETUP->GetPenSetupConfig();
		pcMultiLineScript = pkPenSetupCfg->GetPenScriptBlock(ptPenData->Instance, ZERO_BASED, CONFIG_MODIFIABLE);

		if (pcMultiLineScript != NULL) {
			pkScriptData = new CScriptData(pcMultiLineScript, g_ulMAX_SCRIPT_LEN, ptPenData->Instance, 0, 0, false);
			strSubTitle = L"MULTI";
		} else {
			qDebug("Multiline Script block invalid");
		}
	}
	// only add if the script block is valid
	if (pkScriptData != NULL) {
		strSubTitle = pkScriptData->GetDataAsString();

		// now remove all control characters (specifically carriage return and line feed)
		strSubTitle.Replace(L"\r", L" ");

		strSubTitle.Replace(L"\n", L" ");

		strSubTitle.Replace(L"\t", L" ");

		QString  strScriptData("");
		strScriptData = tr("Edit Maths");
		CConfigItem *pkScript = new CConfigItem(ms_strEDIT_SCRIPT_KEY, strScriptData, strSubTitle, ctItemButton,
				pkScriptData, false, (ptPenData->Enabled == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkScript);
	}

	// Scale - Scale struct, menu item
	QString  strScale("");
	strScale = tr("to");
	// check if log scale or not
	if (!ptPenData->Scale.LogScale) {
		// use a default number format
		T_NUMFORMAT tNumasprintf;
		tNumasprintf.Auto = TRUE;
		tNumasprintf.Base = FALSE;
		tNumasprintf.Zpad = FALSE;
		tNumasprintf.Scientific = FALSE;

		// now format
		QString  strZero(CStringUtils::asprintfFloat(tNumasprintf, ptPenData->Scale.Zero));
		QString  strSpan(CStringUtils::asprintfFloat(tNumasprintf, ptPenData->Scale.Span));

		strSubTitle.asprintf(L"%s %s %s %s", strZero, strScale, strSpan, ptPenData->Units);
	} else {
		short sEndDecade = ptPenData->Scale.StartDecade + ptPenData->Scale.NumDecades;
		strSubTitle.asprintf(L"E%d %s E%d %s", ptPenData->Scale.StartDecade, strScale, sEndDecade, ptPenData->Units);
	}
	strScale = tr("Scale");
	CConfigBranch *pkScale = new CConfigBranch(ms_strSCALE_KEY, strScale, strSubTitle, ctSubMenuButton, false,
			(ptPenData->Enabled == TRUE), 0, false, pkParent);
	pkParent->AddChild(pkScale);

	// setup the individual scale data if the pen is enabled
	if ((ptPenData->Enabled == TRUE) || ( pDALGLB->IsPCSoftware())) {
		SetupScaleDetails(pkScale, ptPenData);
	}

	// PenLog - Pen Logging normal instance and alarm instance, menu item
	QString  strLogging("");
	strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptPenData->PenLog.Enabled);
	// check if logging is enabled
	if (ptPenData->PenLog.Enabled == TRUE) {
		// check if milliseconds
		if (ptPenData->PenLog.RateUnits == lruMilliseconds) {
			// check if we can't do fast scan
			if (!pSYSTEM_INFO->FWOptionFastScanAvailable()) {
				// if the current option is set to the fastest then back it off by one
				if (ptPenData->PenLog.RateMS == lmr50Hertz) {
					ptPenData->PenLog.RateMS -= 1;
				}
			}
			// get the selection from the milliseconds list
			strSubTitle += L" " + CStringUtils::GetItemAtPos(ms_strPenLogRateMsList, ptPenData->PenLog.RateMS);
		} else {
			// get the rate units and then add the relevant units
			QString  strRate("");
			strRate.asprintf(L" %u %s", ptPenData->PenLog.Rate,
					CStringUtils::GetItemAtPos(ms_strPenLogRateShortUnitsList, ptPenData->PenLog.RateUnits));
			strSubTitle += strRate;
		}

		// now add if continuous or fuzzy
		strLogging = CStringUtils::GetItemAtPos(ms_strPenLogLogTypeList, ptPenData->PenLog.LogType);
		// check the text is not too long
		if (strLogging.size() > 5) {
			// cap to 4 characters
			strLogging = strLogging.left(4);
		}
		strSubTitle += L" " + strLogging;
	}
	strLogging = tr("Logging");
	CConfigBranch *pkLogging = new CConfigBranch(ms_strLOG_KEY, strLogging, strSubTitle, ctSubMenuButton, false,
			(ptPenData->Enabled == TRUE), 0, false, pkParent);

	pkParent->AddChild(pkLogging);

	// setup the individual logging data if the pen is enabled
	if ((ptPenData->Enabled == TRUE) || ( pDALGLB->IsPCSoftware())) {
		SetupLoggingDetails(pkLogging, &ptPenData->PenLog, (ptPenData->Instance < MAX_PRETRIGGER_INSTANCE));
	}

	// Alm - Alarms struct, menu item
	QString  strAlarms("");
	strAlarms = tr("Alarms");

	// obtain the alarm types which must be displayed on the button
	strSubTitle = CreateAlarmBtnTitle(ptPenData->Alm, V6_MAX_ALARMS);

	CConfigBranch *pkAlarms = new CConfigBranch(ms_strALM_KEY, strAlarms, strSubTitle, ctSubMenuButton, false,
			(ptPenData->Enabled == TRUE), 0, false, pkParent);
	pkParent->AddChild(pkAlarms);

	// setup the individual alarm data if the pen is enabled
	if ((ptPenData->Enabled == TRUE) || ( pDALGLB->IsPCSoftware())) {
		SetupAlarmDetails(pkAlarms, ptPenData);
	}

	// Tot - Totaliser struct, menu item
	QString  strTotaliser("");
	strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptPenData->Tot.Enabled);

	// add more detail if the totaliser is enabled
	if (ptPenData->Tot.Enabled == TRUE) {
		strSubTitle += L" " + CStringUtils::GetItemAtPos(ms_strPenTotTypeList, ptPenData->Tot.Type);
	}

	strTotaliser = tr("Totaliser");
	CConfigBranch *pkTotaliser = new CConfigBranch(ms_strTOT_KEY, strTotaliser, strSubTitle, ctSubMenuButton, false,
			(ptPenData->Enabled == TRUE) && pSYSTEM_INFO->FWOptionTotalsAvailable(), 0, false, pkParent);
	pkParent->AddChild(pkTotaliser);

	// setup the individual totaliser data if the pen is enabled
	if ((ptPenData->Enabled == TRUE) || ( pDALGLB->IsPCSoftware())) {
		SetupTotaliserDetails(pkTotaliser, &ptPenData->Tot);
	}

	// Setup the RAV data
	SetupRAVDetails(pkParent, &ptPenData->RAV, ptPenData->Enabled);

	// GroupNumber - integer in the range 0 - 6 - maybe use a list box?
	QString  strGroup("");
	CShortBitFieldData *pkGrpData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptPenData), 6, 3,
			ms_strPenGroupList, bfeSingleSelList, 0, 0, false);
	strSubTitle = pkGrpData->GetDataAsString();
	strGroup = tr("Group");
	CConfigItem *pkGroup = new CConfigItem(ms_strGROUP_KEY, strGroup, strSubTitle, ctItemButton, pkGrpData, false,
			( pSYSTEM_INFO->FWOptionBatchAvailable() == TRUE) && (ptPenData->Enabled == TRUE), 0, false, pkParent);
	pkParent->AddChild(pkGroup);

	// Line Colour - this is a ULONG
	CULongData *pkColourData = new CULongData(&ptPenData->Style.Colour, 0, ms_ulMaxColour, 0, 0, false, dtColour);
	QString  strColour("");
	strSubTitle = pkColourData->GetDataAsString();
	strColour = tr("Color");
	CConfigItem *pkColour = new CConfigItem(ms_strSTYLE_COLOUR_KEY, strColour, strSubTitle, ctItemButton, pkColourData,
			false, (ptPenData->Enabled == TRUE), 0, false, pkParent);
	pkParent->AddChild(pkColour);

	// Line thickness - this is a USHORT
	CUShortData *pkThicknessData = new CUShortData(&ptPenData->Style.Thickness, 1, 7, 0, 0, false);
	QString  strThickness("");
	strSubTitle.asprintf(L"%u", ptPenData->Style.Thickness);
	strThickness = tr("Trace Width");
	CConfigItem *pkThickness = new CConfigItem(ms_strSTYLE_THICKNESS_KEY, strThickness, strSubTitle, ctItemButton,
			pkThicknessData, false, (ptPenData->Enabled == TRUE), 0, false, pkParent);
	pkParent->AddChild(pkThickness);

}
//****************************************************************************
// const QString   CreateAlarmBtnTitle( T_PALARM ptAlarm )
///
/// Method that creates the required text for the alarm buttons
///
/// @param[in] 		T_PALARM *ptAlarm - Pointer to the parent alarm structures
///
/// @return			A string containing the button title text
///
//****************************************************************************
const QString  CRecSetupCfgMgr::CreateAlarmBtnTitle(T_PALARM ptAlarm, const USHORT usNO_OF_ALARMS) {
	QString  strAlarmText("");

	// loop around the alarms determining their state - currently there are five states
	// and they are as follows: atHigh, atLow, atDeviation, atRateUp and atRateDown
	// we shall create an array with elements corresping to each of these five values 
	// and increment each accordingly
	USHORT *ausAlarmType = new USHORT[ALARM_TYPE_MAX_NUMBER];
	memset(ausAlarmType, 0, sizeof( USHORT ) * ALARM_TYPE_MAX_NUMBER);

	for (int iCount = 0; iCount < usNO_OF_ALARMS; iCount++) {
		// check the alarm is enabled
		if (ptAlarm[iCount].EnableType != ALARM_DISABLED) {
			if (ptAlarm[iCount].Type >= ALARM_TYPE_MAX_NUMBER) {
				// the alarm type is out of range - log an error and default back to 0
				QString  strError("");
				strError.asprintf(L"Alarm type invalid for alarm %u - defaulting to HI alarm", iCount + 1);
				LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
				ptAlarm[iCount].Type = ALARM_TYPE_HIGH;
			}
			ausAlarmType[ptAlarm[iCount].Type]++;
		}
	}

	QString  strDelimiter("");
	// now loop through the results updating the alarm text as appropriate
	for (int iAlarmType = 0; iAlarmType < ALARM_TYPE_MAX_NUMBER; iAlarmType++) {
		// check if there are any alarms of this type
		if (ausAlarmType[iAlarmType] != 0) {
			QString  strCurrAlarm("");
			QString  strCurrAlarmName("");
			// add the comma to the end of the string - this will be an empty string first time around
			strAlarmText += strDelimiter;
			// get the name of the current alarm type
			switch (iAlarmType) {
			case ALARM_TYPE_HIGH:
				strCurrAlarmName = tr("Hi");
				break;
			case ALARM_TYPE_LOW:
				strCurrAlarmName = tr("Lo");
				break;
			case ALARM_TYPE_DEVIATION:
				strCurrAlarmName = tr("Dev");
				break;
			case ALARM_TYPE_RATEUP:
				strCurrAlarmName = tr("R Up");
				break;
			case ALARM_TYPE_RATEDOWN:
				strCurrAlarmName = tr("R Dw");
				break;
			default:
				break;
			}
			/// add to the alarm text
			// only add the text, not the number if therev is only one alarm
			if (usNO_OF_ALARMS == 1) {
				// add the level and tag also
				if ((ptAlarm->Type == ALARM_TYPE_HIGH) || (ptAlarm->Type == ALARM_TYPE_LOW)) {
					strCurrAlarm.asprintf(L"%s (%.02f), %s", strCurrAlarmName, ptAlarm->Level, ptAlarm->Tag);
				} else if (ptAlarm->Type == ALARM_TYPE_DEVIATION) {
					strCurrAlarm.asprintf(L"%s (%.02f), %s", strCurrAlarmName, ptAlarm->DevLevel, ptAlarm->Tag);
				} else {
					// must be rate up or rate down
					strCurrAlarm.asprintf(L"%s (%.02f/%u secs), %s", strCurrAlarmName, ptAlarm->DevLevel,
							ptAlarm->DampSecs, ptAlarm->Tag);
				}
			} else {
				// multiple alarms therefore add the number too
				strCurrAlarm.asprintf(L"%d %s", ausAlarmType[iAlarmType], strCurrAlarmName);
			}
			strAlarmText += strCurrAlarm;

			// we need to add a comma and a space to any future text
			strDelimiter = ", ";
		}
	}

	delete[] ausAlarmType;

	// check that at least one alarm is on
	if (strAlarmText == "") {
		// none set therefore change to NONE if multiple pens or Not Set if a single pen
		if (usNO_OF_ALARMS == 0) {
			strAlarmText = tr("Not Set");
		} else {
			strAlarmText = tr("None");
		}
	}

	return strAlarmText;
}
//****************************************************************************
// void SetupScaleDetails( CConfigBranch *pkParent, T_PPEN ptPenData )
///
/// Method that sets up the scale details for a particular pen
///
/// @param[in/out] 		CConfigBranch *pkParent - Pointer to the parent owner class
/// @param[in]		T_PPEN ptPenData - A pointer to the associated pen data
///
//****************************************************************************
void CRecSetupCfgMgr::SetupScaleDetails(CConfigBranch *pkParent, T_PPEN ptPenData) {
	T_PSCALEINFO ptScaleInfo = &ptPenData->Scale;
	QString  strTitle("");
	QString  strSubTitle(ptPenData->Units);

	// Units - Pen Units Label, WCHAR edit
	QString   CfgData *pkUnitsData = new QString   CfgData(reinterpret_cast<WCHAR*>(&ptPenData->Units),
	PEN_UNITS_LEN, dtString, 0, 0, true);
	strTitle = tr("Units");
	CConfigItem *pkUnits = new CConfigItem(ms_strUNITS_KEY, strTitle, strSubTitle, ctItemButton, pkUnitsData, false,
			true, 0, false, pkParent);
	pkParent->AddChild(pkUnits);

	// we now need to create all the individual components of a pen
	// Span - this will be a float type data field

	// check if we are showing the actual span which the user can edit or whether we
	// are showing the uneditable start and end decades
	QString  strSpanSubTitle("");
	QString  strZeroSubTitle("");

	CFloatData *pkSpanData = new CFloatData(&ptScaleInfo->Span, -V6_FLT_MAX, V6_FLT_MAX, 0, 0, true);

	// Zero - this will be a float type data field
	CFloatData *pkZeroData = new CFloatData(&ptScaleInfo->Zero, -V6_FLT_MAX, V6_FLT_MAX, 0, 0, true);

	if (ptScaleInfo->LogScale == FALSE) {
		strSpanSubTitle = pkSpanData->GetDataAsString();
		strZeroSubTitle = pkZeroData->GetDataAsString();
	} else {
		strSpanSubTitle.asprintf(L"E%d", ptScaleInfo->StartDecade + ptScaleInfo->NumDecades);
		strZeroSubTitle.asprintf(L"E%d", ptScaleInfo->StartDecade);
	}

	strTitle = tr("Span");
	CConfigItem *pkSpan = new CConfigItem(ms_strSPAN_KEY, strTitle, strSpanSubTitle, ctItemButton, pkSpanData, false,
			(ptScaleInfo->LogScale == FALSE), 0, false, pkParent);
	pkParent->AddChild(pkSpan);

	strTitle = tr("Zero");
	CConfigItem *pkZero = new CConfigItem(ms_strZERO_KEY, strTitle, strZeroSubTitle, ctItemButton, pkZeroData, false,
			(ptScaleInfo->LogScale == FALSE), 0, false, pkParent);
	pkParent->AddChild(pkZero);

	// Log scale - this will be a bitfield
	QString  strLogScale("");
	CShortBitFieldData *pkLogScaleData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptScaleInfo), 1, 1,
			ms_strPenLogScaleList, bfeBool, 0, 0, true);
	strSubTitle = CStringUtils::GetItemAtPos(ms_strPenLogScaleList, ptScaleInfo->LogScale);
	strLogScale = tr("Scale Type");
	CConfigItem *pkLogScale = new CConfigItem(ms_strLOG_SCALE_KEY, strLogScale, strSubTitle, ctItemButton,
			pkLogScaleData, false, true, 0, false, pkParent);
	pkParent->AddChild(pkLogScale);

	if (ptScaleInfo->LogScale == FALSE) {
		// Auto divisions - this will be a bitfield
		QString  strAutoDiv("");
		strSubTitle = CStringUtils::GetItemAtPos(ms_strPenScaleAutoList, ptScaleInfo->automaticDivs);
		CShortBitFieldData *pkAutoData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptScaleInfo), 1, 0,
				ms_strPenScaleAutoList, bfeBool, 0, 0, true);
		strAutoDiv = tr("Divs Select");
		CConfigItem *pkAutoDiv = new CConfigItem(ms_strAUTO_DIVS_KEY, strAutoDiv, strSubTitle, ctItemButton, pkAutoData,
				false, true, 0, false, pkParent);
		pkParent->AddChild(pkAutoDiv);

		// check if we are running with auto divs turned on
		if (ptScaleInfo->automaticDivs) {
			// auto divs set therefore we must set the divs so we get 6 majors and 21 minors
			float fMajors = fabs(ptScaleInfo->Span - ptScaleInfo->Zero) / 5;

			float fMinors = fabs(ptScaleInfo->Span - ptScaleInfo->Zero) / 20;

			/// now see if they are different
			if ((fMajors != ptScaleInfo->MajorDivs) || (fMinors != ptScaleInfo->MinorDivs)) {
				// as the only way these values can change is if we have changed the current
				// scale or set to auto divs we can safely assume the config modifed flag has
				// already been set and thus does not need to be done again - another reason
				// we don't want to set the flag is comparing floats can sometimes be a bit suspect
				// whereby two seemingly identical floats could come up as different
				ptScaleInfo->MajorDivs = fMajors;
				ptScaleInfo->MinorDivs = fMinors;
			}
		}
		// MajorDivs - this will be a float type data field
		CFloatData *pkMjrDivsData = new CFloatData(&ptScaleInfo->MajorDivs, -V6_FLT_MAX, V6_FLT_MAX, 0, 0, true);
		QString  strMajorDivs("");
		if (ptScaleInfo->MajorDivs != 0) {
			strSubTitle = pkMjrDivsData->GetDataAsString();
		} else {
			strSubTitle = tr("None");
		}
		strMajorDivs = tr("Major Divs");
		CConfigItem *pkMajorDivs = new CConfigItem(ms_strMAJOR_DIVS_KEY, strMajorDivs, strSubTitle, ctItemButton,
				pkMjrDivsData, false, (ptScaleInfo->automaticDivs == FALSE), 0, false, pkParent);
		pkParent->AddChild(pkMajorDivs);

		// MinorDivs - this will be a float type data field
		CFloatData *pkMnrDivsData = new CFloatData(&ptScaleInfo->MinorDivs, -V6_FLT_MAX, V6_FLT_MAX, 0, 0, true);
		QString  strMinorDivs("");
		if (ptScaleInfo->MinorDivs != 0) {
			strSubTitle = pkMnrDivsData->GetDataAsString();
		} else {
			strSubTitle = tr("None");
		}
		strMinorDivs = tr("Minor Divs");
		CConfigItem *pkMinorDivs = new CConfigItem(ms_strMINOR_DIVS_KEY, strMinorDivs, strSubTitle, ctItemButton,
				pkMnrDivsData, false, (ptScaleInfo->automaticDivs == FALSE), 0, false, pkParent);
		pkParent->AddChild(pkMinorDivs);
	} else {
		// Start decade - this will be a short type data field
		CShortData *pkStartDecData = new CShortData(&ptScaleInfo->StartDecade, -100, 100, 0, 0, true);
		QString  strStartDecade("");
		strStartDecade = tr("Start Decade");
		CConfigItem *pkStartDecade = new CConfigItem(ms_strSTART_DECADE_KEY, strStartDecade,
				pkStartDecData->GetDataAsString(), ctItemButton, pkStartDecData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkStartDecade);

		// Number of decades - this will be an USHORT type data field
		CShortData *pkNumDecsData = new CShortData(&ptScaleInfo->NumDecades, 1, 20, 0, 0, true);
		QString  strNumDecades("");
		strNumDecades = tr("No. Decades");
		CConfigItem *pkNumDecades = new CConfigItem(ms_strNUM_DECADES_KEY, strNumDecades,
				pkNumDecsData->GetDataAsString(), ctItemButton, pkNumDecsData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkNumDecades);
	}
	SetupNumasprintf(pkParent, &ptScaleInfo->NumF);
}
//****************************************************************************
// void SetupTotaliserDetails( CConfigBranch *pkParent, T_PTOTAL pTotal )
///
/// Method that sets up the totaliser details for a particular pen
///
/// @param[in/out] 		CConfigBranch *pkParent - Pointer to the parent owner class
/// @param[in]			T_PTOTAL ptTotal - A pointer to the associated totaliser data
///
//****************************************************************************
void CRecSetupCfgMgr::SetupTotaliserDetails(CConfigBranch *pkParent, T_PTOTAL ptTotal) {
	QString  strTitle("");
	QString  strSubTitle("");

	// Enabled - this will be a boolean type bitfield
	CShortBitFieldData *pkEnData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptTotal), 1, 0, ms_strEnabledList,
			bfeBool, 0, 0, true);
	strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptTotal->Enabled);
	strTitle = tr("Enabled");
	CConfigItem *pkEnabled = new CConfigItem(ms_strENABLED_KEY, strTitle, strSubTitle, ctItemButton, pkEnData, false,
			true, 0, false, pkParent);
	pkParent->AddChild(pkEnabled);

	// Type - this will be a list type bitfield
	CShortBitFieldData *pkTypeData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptTotal), 2, 1,
			ms_strPenTotTypeList, bfeSingleSelList, 0, 0, true);
	strSubTitle = pkTypeData->GetDataAsString();
	strTitle = tr("Type");
	CConfigItem *pkType = new CConfigItem(ms_strTOT_TYPE_KEY, strTitle, strSubTitle, ctItemButton, pkTypeData, false,
			(ptTotal->Enabled == TRUE), 0, false, pkParent);
	pkParent->AddChild(pkType);

	// Tag - Totaliser Tag Label, WCHAR edit
	QString   CfgData *pkTagData = new QString   CfgData(reinterpret_cast<WCHAR*>(&ptTotal->Tag),
	TOTAL_TAG_LEN, dtString, 0, 0, false);
	strTitle = tr("Tag");
	CConfigItem *pkTag = new CConfigItem(ms_strTOT_TAG_KEY, strTitle, ptTotal->Tag, ctItemButton, pkTagData, false,
			(ptTotal->Enabled == TRUE), 0, false, pkParent);
	pkParent->AddChild(pkTag);

	// Add to msg list - this will be a boolean type bitfield
	CShortBitFieldData *pkAddToMsgListData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptTotal), 1, 7,
			ms_strEnabledList, bfeBool, 0, 0, true);
	strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptTotal->AddToMsgList);
	strTitle = tr("Add to Msgs");
	CConfigItem *pkAddToMsgList = new CConfigItem(ms_strTOT_ADD_TO_MSG_LIST_KEY, strTitle, strSubTitle, ctItemButton,
			pkAddToMsgListData, false, (ptTotal->Enabled == TRUE), 0, false, pkParent);
	pkParent->AddChild(pkAddToMsgList);

	// check if this is normal or sterlisation
	if (ptTotal->Type == TOTAL_TYPE_STANDARD) {
		// Normal
		// Totaliser Units - WCHAR edit
		QString   CfgData *pkUnitsData = new QString   CfgData(reinterpret_cast<WCHAR*>(&ptTotal->Units),
		TOTAL_UNITS_LEN, dtString, 0, 0, false);
		strTitle = tr("Units");
		CConfigItem *pkUnits = new CConfigItem(ms_strTOT_UNITS_KEY, strTitle, ptTotal->Units, ctItemButton, pkUnitsData,
				false, (ptTotal->Enabled == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkUnits);

		// Time factor - this will be a float type data field
		CFloatData *pkTimeFactorData = new CFloatData(&ptTotal->TimeFactor, -V6_FLT_MAX, V6_FLT_MAX, 0, 0, false);
		strTitle = tr("Time Factor");
		CConfigItem *pkTimeFactor = new CConfigItem(ms_strTOT_TIME_FACTOR_KEY, strTitle,
				pkTimeFactorData->GetDataAsString(), ctItemButton, pkTimeFactorData, false, (ptTotal->Enabled == TRUE),
				0, false, pkParent);
		pkParent->AddChild(pkTimeFactor);

		// Unit factor - this will be a float type data field
		CFloatData *pkUnitFactorData = new CFloatData(&ptTotal->UnitFactor, -V6_FLT_MAX, V6_FLT_MAX, 0, 0, false);
		strTitle = tr("Unit Factor");
		CConfigItem *pkUnitFactor = new CConfigItem(ms_strTOT_UNIT_FACTOR_KEY, strTitle,
				pkUnitFactorData->GetDataAsString(), ctItemButton, pkUnitFactorData, false, (ptTotal->Enabled == TRUE),
				0, false, pkParent);
		pkParent->AddChild(pkUnitFactor);

		// No back flow - this will be a boolean type bitfield
		CShortBitFieldData *pkNoBackflowData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptTotal), 1, 3,
				ms_strEnabledList, bfeBool, 0, 0, true);
		strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptTotal->NoBackflow);
		strTitle = tr("No Backflow");
		CConfigItem *pkNoBackflow = new CConfigItem(ms_strTOT_NO_BACK_FLOW_KEY, strTitle, strSubTitle, ctItemButton,
				pkNoBackflowData, false, (ptTotal->Enabled == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkNoBackflow);

		// BackFlow level - this will be a float type data field
		CFloatData *pkBackFlowLevelData = new CFloatData(&ptTotal->BackFlowLevel, -V6_FLT_MAX, V6_FLT_MAX, 0, 0, false);
		strSubTitle = pkBackFlowLevelData->GetDataAsString();
		strTitle = tr("Backflow Level");
		CConfigItem *pkBackFlowLevel = new CConfigItem(ms_strTOT_BACK_FLOW_LEVEL_KEY, strTitle, strSubTitle,
				ctItemButton, pkBackFlowLevelData, false, (ptTotal->Enabled == TRUE) && (ptTotal->NoBackflow == TRUE),
				0, false, pkParent);
		pkParent->AddChild(pkBackFlowLevel);

		// Restrict Range - this will be a boolean type bitfield
		CShortBitFieldData *pkRestrictRangeData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptTotal), 1, 4,
				ms_strEnabledList, bfeBool, 0, 0, true);
		strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptTotal->RestrictRange);
		strTitle = tr("Restrict Range");
		CConfigItem *pkRestrictRange = new CConfigItem(ms_strTOT_RESTRICT_RANGE_KEY, strTitle, strSubTitle,
				ctItemButton, pkRestrictRangeData, false, (ptTotal->Enabled == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkRestrictRange);

		// set this flag so the next fields can be shown in grey if restrict range is not set
		bool bRestrictRange = (ptTotal->RestrictRange == TRUE) && (ptTotal->Enabled == TRUE);
		// Min Range - this will be a float type data field
		CFloatData *pkMinRangeData = new CFloatData(&ptTotal->MinRange, -V6_FLT_MAX, V6_FLT_MAX, 0, 0, false);
		strTitle = tr("Min Range");
		CConfigItem *pkMinRange = new CConfigItem(ms_strTOT_MIN_RANGE_KEY, strTitle, pkMinRangeData->GetDataAsString(),
				ctItemButton, pkMinRangeData, false, (ptTotal->Enabled == TRUE) && (ptTotal->RestrictRange == TRUE), 0,
				false, pkParent);
		pkParent->AddChild(pkMinRange);

		// Max Range - this will be a float type data field
		CFloatData *pkMaxRangeData = new CFloatData(&ptTotal->MaxRange, -V6_FLT_MAX, V6_FLT_MAX, 0, 0, false);
		strTitle = tr("Max Range");
		CConfigItem *pkMaxRange = new CConfigItem(ms_strTOT_MAX_RANGE_KEY, strTitle, pkMaxRangeData->GetDataAsString(),
				ctItemButton, pkMaxRangeData, false, (ptTotal->Enabled == TRUE) && (ptTotal->RestrictRange == TRUE), 0,
				false, pkParent);
		pkParent->AddChild(pkMaxRange);

		// Carry on roll - this will be a boolean type bitfield
		CShortBitFieldData *pkCarryOnRollData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptTotal), 1, 5,
				ms_strEnabledList, bfeBool, 0, 0, false);
		strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptTotal->CarryOnRoll);
		strTitle = tr("Use Remainder");
		CConfigItem *pkCarryOnRoll = new CConfigItem(ms_strTOT_CARRY_ON_ROLL_KEY, strTitle, strSubTitle, ctItemButton,
				pkCarryOnRollData, false, bRestrictRange, 0, false, pkParent);
		pkParent->AddChild(pkCarryOnRoll);

		//Added the radio button to reset totaliser after 16 millon 

		CShortBitFieldData *pkResetAfter16MillonData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptTotal), 1,
				10, ms_strEnabledList, bfeBool, 0, 0, true);
		strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptTotal->Reset16Millon);
		strTitle = tr("Reset at 16M");
		CConfigItem *pkResetAfter16Millon = new CConfigItem(ms_strTOT_RESET16MILLION_RANGE_KEY, strTitle, strSubTitle,
				ctItemButton, pkResetAfter16MillonData, false, (ptTotal->Enabled == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkResetAfter16Millon);

	} else {
		// Sterilisation
		// Temperature input units - this will be a list type bitfield
		CShortBitFieldData *pkTempInputUnitsData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptTotal), 2, 8,
				ms_strPenTotTempUnitsList, bfeSingleSelList, 0, 0, true);
		strSubTitle = pkTempInputUnitsData->GetDataAsString();
		strTitle = tr("Temp Input Units");
		CConfigItem *pkTempInputUnits = new CConfigItem(ms_strTOT_TEMP_INPUT_UNITS_KEY, strTitle, strSubTitle,
				ctItemButton, pkTempInputUnitsData, false, (ptTotal->Enabled == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkTempInputUnits);

		const T_TEMP_UNIT eTEMP_UNIT(static_cast<T_TEMP_UNIT>(ptTotal->TempInputUnits));

		// Temp start - this will be a float type data field
		CFloatData *pkTempStartData = new CFloatData(&ptTotal->TempStart, -V6_FLT_MAX, V6_FLT_MAX, 0, 0, false,
				dtTemperature, eTEMP_UNIT);
		strTitle = tr("Start Temperature");
		CConfigItem *pkTempStart = new CConfigItem(ms_strTOT_TEMP_START_KEY, strTitle,
				pkTempStartData->GetDataAsString(), ctItemButton, pkTempStartData, false, (ptTotal->Enabled == TRUE), 0,
				false, pkParent);
		pkParent->AddChild(pkTempStart);

		// Temp ref - this will be a float type data field
		CFloatData *pkTempRefData = new CFloatData(&ptTotal->TempRef, -V6_FLT_MAX, V6_FLT_MAX, 0, 0, false,
				dtTemperature, eTEMP_UNIT);
		strTitle = tr("Reference Temp.");
		CConfigItem *pkTempRef = new CConfigItem(ms_strTOT_TEMP_REF_KEY, strTitle, pkTempRefData->GetDataAsString(),
				ctItemButton, pkTempRefData, false, (ptTotal->Enabled == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkTempRef);

		// ZFactor - this will be a float type data field
		CFloatData *pkZFactorData = new CFloatData(&ptTotal->Zfactor, -V6_FLT_MAX, V6_FLT_MAX, 0, 0, false,
				dtTempRelative, eTEMP_UNIT);
		strTitle = tr("Z Factor Temp.");
		CConfigItem *pkZFactor = new CConfigItem(ms_strTOT_ZFACTOR_KEY, strTitle, pkZFactorData->GetDataAsString(),
				ctItemButton, pkZFactorData, false, (ptTotal->Enabled == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkZFactor);

		// Include cooling - this will be a list type bitfield
		CShortBitFieldData *pkIncCoolData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptTotal), 1, 6,
				ms_strEnabledList, bfeBool, 0, 0, true);
		strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptTotal->IncludeCool);
		strTitle = tr("Include Cooling");
		CConfigItem *pkIncCool = new CConfigItem(ms_strTOT_INCLUDE_COOL_KEY, strTitle, strSubTitle, ctItemButton,
				pkIncCoolData, false, (ptTotal->Enabled == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkIncCool);

		// Complete Val - this will be a float type data field
		CFloatData *pkCompleteValData = new CFloatData(&ptTotal->CompleteVal, -V6_FLT_MAX, V6_FLT_MAX, 0, 0, false);
		strTitle = tr("Completion Value");
		CConfigItem *pkCompleteVal = new CConfigItem(ms_strTOT_COMP_VAL_KEY, strTitle,
				pkCompleteValData->GetDataAsString(), ctItemButton, pkCompleteValData, false,
				(ptTotal->Enabled == TRUE) && (ptTotal->IncludeCool == FALSE), 0, false, pkParent);

		pkParent->AddChild(pkCompleteVal);

	}
	// Number format for totaliser - structure
	SetupNumasprintf(pkParent, &ptTotal->NumF, (ptTotal->Enabled == TRUE));
}
//****************************************************************************
// void SetupRAVDetails(	CConfigBranch *pkParent, 
//							T_PROLLINGAVERAGES ptRAV,
//							const bool bENABLED )
///
/// Method that sets up the rolling average (RAV) details for a particular pen
///
/// @param[in/out] 		CConfigBranch *pkParent - Pointer to the parent owner class
/// @param[in]			T_PROLLINGAVERAGES ptRAV - A pointer to the associated RAV data
/// @param[in]			const bool bENABLED - Flag indicating if the submenu items is to be enabled
///
//****************************************************************************
void CRecSetupCfgMgr::SetupRAVDetails(CConfigBranch *pkParent, T_PROLLINGAVERAGES ptRAV, const bool bENABLED) {
	QString  strTitle("");
	QString  strSubTitle("");
	QString  strSeconds("");
	strSeconds = tr("Secs.");

	// RAV Submenu item
	strTitle = tr("RAV");

	strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptRAV->Enabled);

	// add more detail if the totaliser is enabled
	if (ptRAV->Enabled == TRUE) {
		QString  strAdditionalInfo("");
		strAdditionalInfo.asprintf(IDS_CFG_RAV_SUBTITLE, ptRAV->NoOfSamples, ptRAV->SampleInterval, strSeconds);
		strSubTitle += strAdditionalInfo;
	}

	CConfigBranch *pkRAVParent = new CConfigBranch(ms_strRAV_KEY, strTitle, strSubTitle, ctSubMenuButton, false,
			bENABLED, 0, false, pkParent);
	pkParent->AddChild(pkRAVParent);

	// now add the submenu item if the pen is enabled - this will save processing time as we won't be
	// creating the tree when it can't be accessed
	if (bENABLED || pDALGLB->IsPCSoftware()) {
		// Enabled - this will be a boolean type bitfield
		CShortBitFieldData *pkEnData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptRAV), 1, 0,
				ms_strEnabledList, bfeBool, 0, 0, true);
		strTitle = tr("Enabled");
		CConfigItem *pkEnabled = new CConfigItem(ms_strENABLED_KEY, strTitle, pkEnData->GetDataAsString(), ctItemButton,
				pkEnData, false, bENABLED, 0, false, pkRAVParent);
		pkRAVParent->AddChild(pkEnabled);

		// no of samples
		CUShortData *pkNoOfSamplesData = new CUShortData(&ptRAV->NoOfSamples, 2, 1440, 0, 0, true);

		strTitle = tr("No. of Samples");

		CConfigItem *pkNoOfSamples = new CConfigItem(ms_strRAV_NO_OF_SAMPLES_KEY, strTitle,
				pkNoOfSamplesData->GetDataAsString(), ctItemButton, pkNoOfSamplesData, false,
				bENABLED && (ptRAV->Enabled == TRUE), 0, false, pkRAVParent);
		pkRAVParent->AddChild(pkNoOfSamples);

		// sample interval in seconds
		CUShortData *pkSampleIntervalData = new CUShortData(&ptRAV->SampleInterval, 1, 3600, 0, 0, true,
				dtUnsignedShort, strSeconds);

		strTitle = tr("Sample Interval");

		CConfigItem *pkSampleInterval = new CConfigItem(ms_strRAV_SAMPLE_INTERVAL_KEY, strTitle,
				pkSampleIntervalData->GetDataAsString(true), ctItemButton, pkSampleIntervalData, false,
				bENABLED && (ptRAV->Enabled == TRUE), 0, false, pkRAVParent);
		pkRAVParent->AddChild(pkSampleInterval);

		// Prefill - this will be a boolean type bitfield
		CShortBitFieldData *pkPrefillData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptRAV), 1, 1,
				ms_strEnabledList, bfeBool, 0, 0, false);
		strTitle = tr("Prefill");
		CConfigItem *pkPrefill = new CConfigItem(ms_strRAV_PREFILL_KEY, strTitle, pkPrefillData->GetDataAsString(),
				ctItemButton, pkPrefillData, false, bENABLED && (ptRAV->Enabled == TRUE), 0, false, pkRAVParent);
		pkRAVParent->AddChild(pkPrefill);
	}
}
//****************************************************************************
// void SetupAlarmDetails( CConfigBranch *pkParent, T_PPEN ptPenData )
///
/// Method that sets up the alarm details for a particular pen
///
/// @param[in/out] 		CConfigBranch *pkParent - Pointer to the parent owner class
/// @param[in]			T_PPEN ptPenData - A pointer to the associated pen data
/// 
//****************************************************************************
void CRecSetupCfgMgr::SetupAlarmDetails(CConfigBranch *pkParent, T_PPEN ptPenData) {
	QString  strPenUnits("");
	strPenUnits.asprintf(L"%s", ptPenData->Units);

	// we now need to create all the individual components of a pen alarm
	for (USHORT usCount = 0; usCount < V6_MAX_ALARMS; usCount++) {
		QString  strTitle("");
		QString  strSubTitle("");
		bool bEnabled = (ptPenData->Alm[usCount].EnableType != ALARM_DISABLED);
		QString  strIndividualPenAlarmKey("");
		strIndividualPenAlarmKey.asprintf(L"%s%d", ms_strALM_KEY, usCount + 1);
		QString  strPenAlarmName("");
		QString  strPenName("");
		strPenName = tr("Alarm");
		strPenAlarmName.asprintf(L"%s %d", strPenName, usCount + 1);

		// obtain the alarm type for this item
		strSubTitle = CreateAlarmBtnTitle(&ptPenData->Alm[usCount], 1);

		CConfigBranch *pkAlarmParent = new CConfigBranch(strIndividualPenAlarmKey, strPenAlarmName, strSubTitle,
				ctSubMenuButton, false, true, 0, false, pkParent);
		pkParent->AddChild(pkAlarmParent);

		// Enable Type - this will be a USHORT bitfield
		QString  strEnableType("");

		CShortBitFieldData *pkEnTypeData = new CShortBitFieldData(
				reinterpret_cast< USHORT*>(&ptPenData->Alm[usCount].EnableType), 2, 0, ms_strAlarmEnableTypeList,
				bfeSingleSelList, 0, 0, true);
		strSubTitle = pkEnTypeData->GetDataAsString();

		strEnableType = tr("Enabled");
		CConfigItem *pkEnabled = new CConfigItem(ms_strPEN_ALARM_ENABLE_TYPE_KEY, strEnableType, strSubTitle,
				ctItemButton, pkEnTypeData, false, true, 0, false, pkAlarmParent);
		pkAlarmParent->AddChild(pkEnabled);

		// display the digital enable type if this is enabled by digital
		if (ptPenData->Alm[usCount].EnableType == ALARM_ENABLED_BY_DI) {
			// DIG EN Picker - create a pen pick list
			CPickerData *pkDigEnData = new CPickerData(reinterpret_cast< USHORT*>(&ptPenData->Alm[usCount].DigInEnable),
					dtMultiDigIn, 0, 0, false, 1, MAX_DIGITAL_IO);
			QString  strDigEn("");
			strDigEn = tr("Enabled by Dig");
			strSubTitle = pkDigEnData->GetDataAsString();
			CConfigItem *pkDigEn = new CConfigItem(ms_strPEN_ALARM_DIG_EN_KEY, strDigEn, strSubTitle, ctItemButton,
					pkDigEnData, false, bEnabled, 0, false, pkAlarmParent);
			pkAlarmParent->AddChild(pkDigEn);
		}

		// Type - this will be an USHORT field but we will interpret it
		// as a bitfield to make the code simpler
		QString  strType("");

		CShortBitFieldData *pkTypeData = new CShortBitFieldData(&ptPenData->Alm[usCount].Type, 3, 0,
				ms_strAlarmTypeList, bfeSingleSelList, 0, 0, true);

		strSubTitle = pkTypeData->GetDataAsString();
		strType = tr("Type");
		CConfigItem *pkType = new CConfigItem(ms_strPEN_ALARM_TYPE_KEY, strType, strSubTitle, ctItemButton, pkTypeData,
				false, bEnabled, 0, false, pkAlarmParent);
		pkAlarmParent->AddChild(pkType);

		if ((ptPenData->Alm[usCount].Type == ALARM_TYPE_LOW) || (ptPenData->Alm[usCount].Type == ALARM_TYPE_HIGH)) {
			// Level - this will be a float type field
			CFloatData *pkLevelData = new CFloatData(&ptPenData->Alm[usCount].Level, -V6_FLT_MAX, V6_FLT_MAX, 0, 0,
					true, dtFloat, TEMP_DEG_C, strPenUnits);
			QString  strLevel("");
			strLevel = tr("Level");

			QString  strLevelData("");
			// add explanatory notes for log scale units
			if (ptPenData->Scale.LogScale == TRUE) {
				strLevelData += pkLevelData->GetDataAsString(false);
				strLevelData += (L" ( 10^" + pkLevelData->GetDataAsString(true) + L" )");
			} else {
				strLevelData += pkLevelData->GetDataAsString(true);
			}

			CConfigItem *pkLevel = new CConfigItem(ms_strPEN_ALARM_LEVEL_KEY, strLevel, strLevelData, ctItemButton,
					pkLevelData, false, bEnabled, 0, false, pkAlarmParent);
			pkAlarmParent->AddChild(pkLevel);
		} else {
			// Dev Level or rate of change level (still call deviation level though) - this will 
			// be a float type field
			CFloatData *pkDevLevelData = new CFloatData(&ptPenData->Alm[usCount].DevLevel, m_fMIN_DEV_LEVEL, V6_FLT_MAX,
					0, 0, true, dtFloat, TEMP_DEG_C, strPenUnits);
			QString  strDevLevel("");
			strDevLevel = tr("Dev. Level");

			QString  strDevLevelData("");
			// add explanatory notes for log scale units
			if (ptPenData->Scale.LogScale == TRUE) {
				strDevLevelData += pkDevLevelData->GetDataAsString(false);
				strDevLevelData += (L" ( 10^" + pkDevLevelData->GetDataAsString(true) + L" )");
			} else {
				strDevLevelData += pkDevLevelData->GetDataAsString(true);
			}

			CConfigItem *pkDevLevel = new CConfigItem(ms_strPEN_ALARM_DEV_LEVEL_KEY, strDevLevel, strDevLevelData,
					ctItemButton, pkDevLevelData, false, bEnabled, 0, false, pkAlarmParent);
			pkAlarmParent->AddChild(pkDevLevel);

			// only show deviation pen for deviation alasrms, not rate of change ones
			if (ptPenData->Alm[usCount].Type == ALARM_TYPE_DEVIATION) {
				// Dev Pen No - this will create a pen pick list
				CPickerData *pkDevPenNoData = new CPickerData(
						reinterpret_cast< USHORT*>(&ptPenData->Alm[usCount].DevPenNum), dtSinglePen, 0, 0, false, 1, 1,
						ptPenData->Instance);
				QString  strDevPenNo("");
				strDevPenNo = tr("Ref Pen");
				strSubTitle = pkDevPenNoData->GetDataAsString();
				CConfigItem *pkDevPenNo = new CConfigItem(ms_strPEN_ALARM_DEV_PEN_NO_KEY, strDevPenNo, strSubTitle,
						ctItemButton, pkDevPenNoData, false, bEnabled, 0, false, pkAlarmParent);
				pkAlarmParent->AddChild(pkDevPenNo);
			} else {
				// rate of change alarm therefore show the time over which a change must occur
				strTitle = tr("Secs.");
				CUShortData *pkTimePeriodData = new CUShortData(&ptPenData->Alm[usCount].DampSecs, 1, 3600, 0, 0, true,
						dtUnsignedShort, strTitle);

				strTitle = tr("Time Period");
				CConfigItem *pkTimePeriod = new CConfigItem(ms_strPEN_ALARM_RATE_OF_CHANGE_TIME_KEY, strTitle,
						pkTimePeriodData->GetDataAsString(true), ctItemButton, pkTimePeriodData, false, bEnabled, 0,
						false, pkAlarmParent);
				pkAlarmParent->AddChild(pkTimePeriod);
			}
		}

		// alarm tag, WCHAR
		QString   CfgData *pkTagData = new QString   CfgData(reinterpret_cast<WCHAR*>(&ptPenData->Alm[usCount].Tag),
		ALARM_TAG_LEN, dtString, 0, 0, true);
		strTitle = tr("Tag");
		CConfigItem *pkTag = new CConfigItem(ms_strTAG_KEY, strTitle, pkTagData->GetDataAsString(), ctItemButton,
				pkTagData, false, bEnabled, 0, false, pkAlarmParent);
		pkAlarmParent->AddChild(pkTag);

		// change allow alarm - this will be a USHORT bitfield
		CShortBitFieldData *pkChangeAllowData = new CShortBitFieldData(
				reinterpret_cast< USHORT*>(&ptPenData->Alm[usCount]), 1, 13, ms_strEnabledList, bfeBool, 0, 0, false);
		strSubTitle = pkChangeAllowData->GetDataAsString();
		strTitle = tr("Allow Change");
		CConfigItem *pkChangeAllow = new CConfigItem(ms_strPEN_ALARM_CHANGE_ALLOW_KEY, strTitle, strSubTitle,
				ctItemButton, pkChangeAllowData, false, bEnabled, 0, false, pkAlarmParent);
		pkAlarmParent->AddChild(pkChangeAllow);

		// Relay out - this will create a pen pick list
		CPickerData *pkRelayOutData = new CPickerData(reinterpret_cast< USHORT*>(&ptPenData->Alm[usCount].RelayOuts),
				dtMultiRelayOut, 0, 0, false, 0, MAX_DIGITAL_IO);
		QString  strRelayOut("");
		strRelayOut = tr("Relays Out");
		strSubTitle = pkRelayOutData->GetDataAsString();
		CConfigItem *pkRelayOut = new CConfigItem(ms_strPEN_ALARM_RELAY_OUT_KEY, strRelayOut, strSubTitle, ctItemButton,
				pkRelayOutData, false, bEnabled, 0, false, pkAlarmParent);
		pkAlarmParent->AddChild(pkRelayOut);

		// Latched - this will be a USHORT bitfield
		QString  strLatched("");
		CShortBitFieldData *pkLatchedData = new CShortBitFieldData(reinterpret_cast< USHORT*>(&ptPenData->Alm[usCount]),
				1, 7, ms_strEnabledList, bfeBool, 0, 0, false);
		strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptPenData->Alm[usCount].Latched);
		strLatched = tr("Latched");
		CConfigItem *pkLatched = new CConfigItem(ms_strPEN_ALARM_LATCHED_KEY, strLatched, strSubTitle, ctItemButton,
				pkLatchedData, false, bEnabled, 0, false, pkAlarmParent);
		pkAlarmParent->AddChild(pkLatched);

		// Change log - this will be a USHORT bitfield
		QString  strChangeLog("");
		CShortBitFieldData *pkChgLogData = new CShortBitFieldData(reinterpret_cast< USHORT*>(&ptPenData->Alm[usCount]),
				1, 10, ms_strEnabledList, bfeBool, 0, 0, false);
		strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptPenData->Alm[usCount].ChangeLog);
		strChangeLog = tr("Change Log");
		CConfigItem *pkChangeLog = new CConfigItem(ms_strPEN_ALARM_CHG_LOG_KEY, strChangeLog, strSubTitle, ctItemButton,
				pkChgLogData, false,
				bEnabled && (ptPenData->PenLog.PretriggerEn == FALSE)
						&& (ptPenData->PenLog.LogStyle == LOGSTYLE_SAMPLE), 0, false, pkAlarmParent);
		pkAlarmParent->AddChild(pkChangeLog);

		// Mark Chart - this will be a USHORT bitfield
		QString  strMarkChart("");
		CShortBitFieldData *pkMarkChartData = new CShortBitFieldData(
				reinterpret_cast< USHORT*>(&ptPenData->Alm[usCount]), 1, 11, ms_strEnabledList, bfeBool, 0, 0, false);
		strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptPenData->Alm[usCount].MarkChart);
		strMarkChart = tr("Mark Chart");
		CConfigItem *pkMarkChart = new CConfigItem(ms_strPEN_ALARM_MARK_CHART_KEY, strMarkChart, strSubTitle,
				ctItemButton, pkMarkChartData, false, bEnabled, 0, false, pkAlarmParent);
		pkAlarmParent->AddChild(pkMarkChart);

		if ( pSYSTEM_INFO->FWOptionEmailAvailable() == FALSE) {
			ptPenData->Alm[usCount].EmailAlarm = false;
		}
		// Send email - this will be a USHORT bitfield
		CShortBitFieldData *pkSendEmailData = new CShortBitFieldData(
				reinterpret_cast< USHORT*>(&ptPenData->Alm[usCount]), 1, 6, ms_strEnabledList, bfeBool, 0, 0, true);
		strTitle = tr("Email Alarm");
		CConfigItem *pkSendEmail = new CConfigItem(ms_strPEN_ALARM_SEND_EMAIL_KEY, strTitle,
				pkSendEmailData->GetDataAsString(), ctItemButton, pkSendEmailData, false,
				bEnabled && ( pSYSTEM_INFO->FWOptionEmailAvailable() == TRUE), 0, false, pkAlarmParent);
		pkAlarmParent->AddChild(pkSendEmail);

		// email recipients - this will be a ulong type field
		if ( pSYSTEM_INFO->FWOptionEmailAvailable() == TRUE) {
			QString  strTitle("");
			strTitle = tr("Recipients");

			CPickerData *pkEmailRecipientsData = new CPickerData(
					reinterpret_cast< USHORT*>(&ptPenData->Alm[usCount].EmailAddBitMask), dtEmailRecipients, 0, 0,
					false, 1,
					EMAIL_EMAILADDRESSES_SIZE);

			CConfigItem *pkEmailRecipients = new CConfigItem(ms_strPEN_ALARM_EMAIL_RECIPIENTS_KEY, strTitle,
					pkEmailRecipientsData->GetDataAsString(), ctItemButton, pkEmailRecipientsData, false,
					bEnabled && (ptPenData->Alm[usCount].EmailAlarm == TRUE), 0, false, pkAlarmParent);
			pkAlarmParent->AddChild(pkEmailRecipients);
		}

		/*
		 // As Event - this will be a USHORT bitfield
		 QString   strAsEvent( "");
		 CShortBitFieldData *pkAsEventData = new CShortBitFieldData(	reinterpret_cast< USHORT* >( &ptPenData->Alm[ usCount ]),
		 1,
		 12,
		 ms_strEnabledList,
		 bfeBool,
		 0,
		 0,
		 false );
		 strSubTitle = CStringUtils::GetItemAtPos( ms_strEnabledList, ptPenData->Alm[ usCount ].AsEvent );
		 strAsEvent = tr("Use as Event");
		 CConfigItem *pkAsEvent = new CConfigItem(	ms_strPEN_ALARM_AS_EVENT_KEY,
		 strAsEvent,
		 strSubTitle,
		 ctItemButton,
		 pkAsEventData,
		 false,
		 bEnabled,
		 0,
		 false,
		 pkAlarmParent );
		 pkAlarmParent->AddChild( pkAsEvent );
		 */

		// do not show hysteresis for deviation alarms
		if (ptPenData->Alm[usCount].Type != ALARM_TYPE_DEVIATION) {
			// Use Hysteresis - this will be a USHORT bitfield
			QString  strUseHyst("");
			CShortBitFieldData *pkUseHystData = new CShortBitFieldData(
					reinterpret_cast< USHORT*>(&ptPenData->Alm[usCount]), 1, 8, ms_strEnabledList, bfeBool, 0, 0, true);
			strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptPenData->Alm[usCount].UseHyst);
			strUseHyst = tr("Hysteresis");
			CConfigItem *pkUseHyst = new CConfigItem(ms_strPEN_ALARM_USE_HYST_KEY, strUseHyst, strSubTitle,
					ctItemButton, pkUseHystData, false, bEnabled, 0, false, pkAlarmParent);
			pkAlarmParent->AddChild(pkUseHyst);

			// Hyst Level - this will be a float type field
			if (ptPenData->Alm[usCount].UseHyst == TRUE) {
				CFloatData *pkHystLevelData = new CFloatData(&ptPenData->Alm[usCount].HystLevel, 0, 100, 0, 0, false,
						dtFloat, TEMP_DEG_C, L"%");
				QString  strHystLevel("");
				strHystLevel = tr("Hyst Level");
				CConfigItem *pkHystLevel = new CConfigItem(ms_strPEN_ALARM_HYST_LEVEL_KEY, strHystLevel,
						pkHystLevelData->GetDataAsString(true), ctItemButton, pkHystLevelData, false, bEnabled, 0,
						false, pkAlarmParent);
				pkAlarmParent->AddChild(pkHystLevel);
			}
		}

		if ((ptPenData->Alm[usCount].Type != ALARM_TYPE_RATEUP)
				&& (ptPenData->Alm[usCount].Type != ALARM_TYPE_RATEDOWN)) {
			// Use Damping - this will be a USHORT bitfield
			QString  strUseDamping("");
			CShortBitFieldData *pkUseDampingData = new CShortBitFieldData(
					reinterpret_cast< USHORT*>(&ptPenData->Alm[usCount]), 1, 9, ms_strEnabledList, bfeBool, 0, 0, true);
			strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptPenData->Alm[usCount].UseDamp);
			strUseDamping = tr("Damping");
			CConfigItem *pkUseDamping = new CConfigItem(ms_strPEN_ALARM_USE_DAMP_KEY, strUseDamping, strSubTitle,
					ctItemButton, pkUseDampingData, false, bEnabled, 0, false, pkAlarmParent);
			pkAlarmParent->AddChild(pkUseDamping);

			// Damping in seconds - this will be a ushort type field
			if (ptPenData->Alm[usCount].UseDamp == TRUE) {
				QString  strDampingUnits("");
				strDampingUnits = tr("Secs.");
				CUShortData *pkDampingData = new CUShortData(&ptPenData->Alm[usCount].DampSecs, 1, 64800, 0, 0, false,
						dtUnsignedShort, strDampingUnits);
				QString  strDamping("");
				strDamping = tr("Damping Time");
				CConfigItem *pkDamping = new CConfigItem(ms_strPEN_ALARM_DAMPING_TIME_KEY, strDamping,
						pkDampingData->GetDataAsString(true), ctItemButton, pkDampingData, false, bEnabled, 0, false,
						pkAlarmParent);
				pkAlarmParent->AddChild(pkDamping);
			}
		}

		// Use reflash - this will be a USHORT bitfield
		CShortBitFieldData *pkUseReflashData = new CShortBitFieldData(
				reinterpret_cast< USHORT*>(&ptPenData->Alm[usCount]), 1, 14, ms_strEnabledList, bfeBool, 0, 0, true);
		strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptPenData->Alm[usCount].UseReflash);
		strTitle = tr("Reflash");
		CConfigItem *pkUseReflash = new CConfigItem(ms_strPEN_ALARM_USE_REFLASH_KEY, strTitle, strSubTitle,
				ctItemButton, pkUseReflashData, false, bEnabled, 0, false, pkAlarmParent);
		pkAlarmParent->AddChild(pkUseReflash);

		// Reflash in seconds - this will be a ushort type field
		if (ptPenData->Alm[usCount].UseReflash == TRUE) {
			QString  strReflashUnits("");
			strReflashUnits = tr("Secs.");
			CULongData *pkReflashData = new CULongData(&ptPenData->Alm[usCount].ReflashSecs, 1, 86400, 0, 0, false,
					dtUnsignedLong, strReflashUnits);
			strTitle = tr("Reflash Time");
			CConfigItem *pkReflash = new CConfigItem(ms_strPEN_ALARM_REFLASH_TIME_KEY, strTitle,
					pkReflashData->GetDataAsString(true), ctItemButton, pkReflashData, false, bEnabled, 0, false,
					pkAlarmParent);
			pkAlarmParent->AddChild(pkReflash);
		}
	}
}
//****************************************************************************
// void SetupLoggingDetails( CConfigBranch *pkParent, T_PLOGGING ptLogData )
///
/// Method that sets up the logging details for a particular pen
///
/// @param[in/out] 		CConfigBranch *pkParent - Pointer to the parent owner class
/// @param[in]			T_PLOGGING ptLogData - A pointer to the associated log data
/// @param[in]			bool bPreTriggerCapable - flag indicating if this pen is capable
///						of storing pre-trigger data is pre-trigger is restricted to pens 1-16
///
///	@todo Add pen alarm logging here when it is finally implemented
///	@todo Pen log rate needs to change to a special control type
///
//****************************************************************************
void CRecSetupCfgMgr::SetupLoggingDetails(CConfigBranch *pkParent, T_PLOGGING ptLogData, bool bPreTriggerCapable) {
	const bool bFUZZY = (ptLogData->LogType == 1);

	QString  strTitle("");
	QString  strSubTitle("");
	// we now need to create all the individual components of a pen log
	// Enabled - this will be a boolean type bitfield
	QString  strEnabled("");
	strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptLogData->Enabled);
	CShortBitFieldData *pkEnData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptLogData), 1, 0,
			ms_strEnabledList, bfeBool, 0, 0, true);
	strEnabled = tr("Enabled");
	CConfigItem *pkEnabled = new CConfigItem(ms_strENABLED_KEY, strEnabled, strSubTitle, ctItemButton, pkEnData, false,
			true, 0, false, pkParent);
	pkParent->AddChild(pkEnabled);

	// Log Type - this will be a USHORT type bitfield
	QString  strLogType("");
	strSubTitle = CStringUtils::GetItemAtPos(ms_strPenLogLogTypeList, ptLogData->LogType);
	CShortBitFieldData *pkLogTypeData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptLogData), 4, 12,
			ms_strPenLogLogTypeList, bfeBool, 0, 0, true);
	strLogType = tr("Type");
	CConfigItem *pkType = new CConfigItem(ms_strPEN_LOG_LOG_TYPE_KEY, strLogType, strSubTitle, ctItemButton,
			pkLogTypeData, false, (ptLogData->Enabled == TRUE), 0, false, pkParent);
	pkParent->AddChild(pkType);

	// logging rate units
	CLongBitFieldData *pkRateUnitsData = new CLongBitFieldData(reinterpret_cast<ULONG*>(ptLogData), 3, 16,
			ms_strPenLogRateUnitsList, bfeSingleSelList, 0, 0, true);
	strTitle = tr("Rate Units");
	CConfigItem *pkRateUnits = new CConfigItem(ms_strPEN_LOG_RATE_UNITS_KEY, strTitle,
			pkRateUnitsData->GetDataAsString(), ctItemButton, pkRateUnitsData, false, (ptLogData->Enabled == TRUE), 0,
			false, pkParent);
	pkParent->AddChild(pkRateUnits);

	// check if milliseconds which requires a list rather than a numerical entry
	if (ptLogData->RateUnits == lruMilliseconds) {
		// logging rate units 
		// check if we can't do fast scan
		if (!pSYSTEM_INFO->FWOptionFastScanAvailable()) {
			// if the current option is set to the fastest then back it off by one
			if (ptLogData->RateMS == lmr50Hertz) {
				ptLogData->RateMS -= 1;
			}
		}

		CLongBitFieldData *pkRateData = new CLongBitFieldData(reinterpret_cast<ULONG*>(ptLogData), 3, 22,
				ms_strPenLogRateMsList, bfeSingleSelList, 0, 0, true);
		strTitle = tr("Rate");
		CConfigItem *pkRate = new CConfigItem(ms_strPEN_LOG_RATE_KEY, strTitle, pkRateData->GetDataAsString(),
				ctItemButton, pkRateData, false, (ptLogData->Enabled == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkRate);
	} else {
		// Rate - this will be a USHORT type
		CUShortData *pkRateData = new CUShortData(&ptLogData->Rate, 1, 60, 0, 0, true, dtUnsignedShort,
				CStringUtils::GetItemAtPos(ms_strPenLogRateShortUnitsList, ptLogData->RateUnits));
		QString  strRate("");
		strRate = tr("Rate");
		CConfigItem *pkRate = new CConfigItem(ms_strPEN_LOG_RATE_KEY, strRate, pkRateData->GetDataAsString(true),
				ctItemButton, pkRateData, false, (ptLogData->Enabled == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkRate);
	}

	if (!bFUZZY) {
		// alarm logging rate units
		CLongBitFieldData *pkAlmRateUnitsData = new CLongBitFieldData(reinterpret_cast<ULONG*>(ptLogData), 3, 19,
				ms_strPenLogRateUnitsList, bfeSingleSelList, 0, 0, true);
		strEnabled = tr("Alarm Rate Units");
		CConfigItem *pkAlmRateUnits = new CConfigItem(ms_strPEN_LOG_ALARM_RATE_UNITS_KEY, strEnabled,
				pkAlmRateUnitsData->GetDataAsString(), ctItemButton, pkAlmRateUnitsData, false,
				(ptLogData->Enabled == TRUE) && (ptLogData->LogStyle == LOGSTYLE_SAMPLE), 0, false, pkParent);
		pkParent->AddChild(pkAlmRateUnits);

		// check if milliseconds which requires a list rather than a numerical entry
		if (ptLogData->AlarmRateUnits == lruMilliseconds) {
			// logging rate units
			// check if we can't do fast scan
			if (!pSYSTEM_INFO->FWOptionFastScanAvailable()) {
				// if the current option is set to the fastest then back it off by one
				if (ptLogData->AlarmRateMS == lmr50Hertz) {
					ptLogData->AlarmRateMS -= 1;
				}
			}
			CLongBitFieldData *pkRateData = new CLongBitFieldData(reinterpret_cast<ULONG*>(ptLogData), 3, 25,
					ms_strPenLogRateMsList, bfeSingleSelList, 0, 0, false);
			strTitle = tr("Alarm Rate");
			CConfigItem *pkRate = new CConfigItem(ms_strPEN_LOG_ALARM_RATE_KEY, strTitle, pkRateData->GetDataAsString(),
					ctItemButton, pkRateData, false,
					(ptLogData->Enabled == TRUE) && (ptLogData->LogStyle == LOGSTYLE_SAMPLE), 0, false, pkParent);
			pkParent->AddChild(pkRate);
		} else {
			// Alarm Rate - this will be a USHORT type
			CUShortData *pkAlmRateData = new CUShortData(&ptLogData->AlarmRate, 1, 60, 0, 0, true, dtUnsignedShort,
					CStringUtils::GetItemAtPos(ms_strPenLogRateShortUnitsList, ptLogData->AlarmRateUnits));
			QString  strRate("");
			strRate = tr("Alarm Rate");
			CConfigItem *pkAlmRate = new CConfigItem(ms_strPEN_LOG_ALARM_RATE_KEY, strRate,
					pkAlmRateData->GetDataAsString(true), ctItemButton, pkAlmRateData, false,
					(ptLogData->Enabled == TRUE) && (ptLogData->LogStyle == LOGSTYLE_SAMPLE), 0, false, pkParent);
			pkParent->AddChild(pkAlmRate);
		}

		// check if pre-trigger capable and add the enabled/disabled field if it is
		if (bPreTriggerCapable) {

			CLongBitFieldData *pkPreTriggerEnData = new CLongBitFieldData(reinterpret_cast<ULONG*>(ptLogData), 1, 28,
					ms_strEnabledList, bfeBool, 0, 0, true);
			strEnabled = tr("Pre-Trigger");
			T_PRECPROFILE ptProfile = pSETUP->GetGeneralSetupConfig()->GetProfileBlock(CONFIG_MODIFIABLE);
			if (ptProfile->Logging.CSV) {
				CConfigItem *pkPreTriggerEn = new CConfigItem(ms_strPEN_LOG_PRETRIGGER_KEY, strEnabled,
						pkPreTriggerEnData->GetDataAsString(), ctItemButton, pkPreTriggerEnData, false, false, 0, false,
						pkParent);
				pkParent->AddChild(pkPreTriggerEn);
			} else {
				CConfigItem *pkPreTriggerEn = new CConfigItem(ms_strPEN_LOG_PRETRIGGER_KEY, strEnabled,
						pkPreTriggerEnData->GetDataAsString(), ctItemButton, pkPreTriggerEnData, false,
						(ptLogData->Enabled == TRUE) && (ptLogData->LogStyle == LOGSTYLE_SAMPLE), 0, false, pkParent);
				pkParent->AddChild(pkPreTriggerEn);
			}
		}

		// Style - this will be a USHORT type bitfield
		QString  strStyle("");

		CShortBitFieldData *pkStyleData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptLogData), 4, 8,
				ms_strPenLogStyleList, bfeSingleSelList, 0, 0, true);

		strSubTitle = pkStyleData->GetDataAsString();
		strStyle = tr("Method");
		CConfigItem *pkStyle = new CConfigItem(ms_strPEN_LOG_STYLE_KEY, strStyle, strSubTitle, ctItemButton,
				pkStyleData, false, (ptLogData->Enabled == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkStyle);

		// Align - this will be a USHORT type - treat as a bitfield for ease of use though
		QString  strAlign("");

		CShortBitFieldData *pkAlignData = new CShortBitFieldData(&ptLogData->Align, 3, 0, ms_strPenLogAlignList,
				bfeSingleSelList, 0, 0, false);

		strSubTitle = pkAlignData->GetDataAsString();

		strAlign = tr("Align");
		CConfigItem *pkAlign = new CConfigItem(ms_strPEN_LOG_ALIGN_KEY, strAlign, strSubTitle, ctItemButton,
				pkAlignData, false, (ptLogData->Enabled == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkAlign);

	} else {
		// Use Fuzzy Auto Fit - this will be a boolean type bitfield
		QString  strUseFAutoFit("");
		strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptLogData->UseFuzzyAutoFit);
		CShortBitFieldData *pkUseFAutoFitData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptLogData), 1, 2,
				ms_strEnabledList, bfeBool, 0, 0, true);
		strUseFAutoFit = tr("Auto Fit");
		CConfigItem *pkUseFAutoFit = new CConfigItem(ms_strPEN_LOG_USE_FUZZY_AUTO_FIT_KEY, strUseFAutoFit, strSubTitle,
				ctItemButton, pkUseFAutoFitData, false, (ptLogData->Enabled == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkUseFAutoFit);

		// Fuzzy Band 1 - this will be a FLOAT type
		CFloatData *pkFBand1Data = new CFloatData(&ptLogData->FBand1, 0, 100, 0, 0, false);
		QString  strFBand1("");
		strFBand1 = tr("Band 1 %");
		CConfigItem *pkFBand1 = new CConfigItem(ms_strPEN_LOG_FBAND1_KEY, strFBand1, pkFBand1Data->GetDataAsString(),
				ctItemButton, pkFBand1Data, false, (ptLogData->Enabled == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkFBand1);

		// Use Fuzzy Band 2 - this will be a boolean type bitfield
		QString  strUseFBand2("");
		strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptLogData->UseFuzzyBand2);
		CShortBitFieldData *pkUseFBand2Data = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptLogData), 1, 3,
				ms_strEnabledList, bfeBool, 0, 0, true);
		strUseFBand2 = tr("Fuzzy Band 2");
		CConfigItem *pkUseFBand2 = new CConfigItem(ms_strPEN_LOG_USE_FBAND2_KEY, strUseFBand2, strSubTitle,
				ctItemButton, pkUseFBand2Data, false, (ptLogData->Enabled == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkUseFBand2);

		// Fuzzy Band 2 - this will be a FLOAT type
		CFloatData *pkFBand2Data = new CFloatData(&ptLogData->FBand2, 0, 100, 0, 0, false);
		QString  strFBand2("");
		const bool bFBAND2_ENABLED = (ptLogData->Enabled == TRUE) && (ptLogData->UseFuzzyBand2 == TRUE);
		strFBand2 = tr("Band 2 %");
		CConfigItem *pkFBand2 = new CConfigItem(ms_strPEN_LOG_FBAND2_KEY, strFBand2, pkFBand2Data->GetDataAsString(),
				ctItemButton, pkFBand2Data, false, bFBAND2_ENABLED, 0, false, pkParent);
		pkParent->AddChild(pkFBand2);

		// fuzzy logging so disable pretrigger as it is not allowed in this situation
		ptLogData->PretriggerEn = FALSE;
	}
}

//****************************************************************************
// CConfigItem *RefreshPenConfigTree( CConfigItem *pkModifiedItem )
///
/// Method that refreshes the data for a pen branch of a pen configuration menu, usually 
/// following a change that requires the tree structure to be regenerated because it is different
///
/// @param[in] 		CConfigItem *pkModifiedItem - A pointer to the item that has been modified - this item
///					gets destroyed
/// @param[in] 		const USHORT usPEN_NO - The number of the pen that has changed (1 based)
///
/// @return			A pointer to the new config item (it will have the same key as the modified item
///
//****************************************************************************
CConfigItem* CRecSetupCfgMgr::RefreshPenConfigTree(CConfigItem *pkModifiedItem, const USHORT usPEN_NO) {
	CConfigItem *pkNewCfgItem = NULL;
	CConfigInterface *pkTopParent = NULL;

	// Store the key name of this item
	const QString  strKEY(pkModifiedItem->GetKey());

	CConfigInterface *pkPenParent = pkModifiedItem;

	// get the top level parent
	while (pkPenParent->GetParent() != NULL) {
		pkPenParent = pkPenParent->GetParent();
	}

	// Get the pen data structure
	T_PPEN ptPenData = NULL;
	CPenSetupConfig *pkPenSetupCfg = pSETUP->GetPenSetupConfig();
	if (pkPenSetupCfg != NULL) {
		ptPenData = pkPenSetupCfg->GetPen(usPEN_NO, ONE_BASED, CONFIG_MODIFIABLE);
	}

	// Check we managed to obtain a pen
	if (ptPenData != NULL) {
		// recreate a pen branch for this item
		QString  strIndividualPenKey("");
		strIndividualPenKey.asprintf(L"%s%d", ms_strPEN_KEY, usPEN_NO);
		QString  strPenName("");
		QString  strPenTitle("");
		strPenTitle = tr("Pen");
		strPenName.asprintf(L"%s %d", strPenTitle, usPEN_NO);

		QString  strSubTitle("");

		// check if log scale or not

		QString  strToTitle("");
		strToTitle = tr("to");

		if (!ptPenData->Scale.LogScale) {
			strSubTitle.asprintf(L"%s, %.2f %s %.2f %s", ptPenData->Tag, ptPenData->Scale.Zero, strToTitle,
					ptPenData->Scale.Span, ptPenData->Units);
		} else {
			short sEndDecade = ptPenData->Scale.StartDecade + ptPenData->Scale.NumDecades;
			strSubTitle.asprintf(L"%s, E%d %s E%d %s", ptPenData->Tag, ptPenData->Scale.StartDecade, strToTitle,
					sEndDecade, ptPenData->Units);
		}
		strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptPenData->Enabled) + L" " + strSubTitle;

		CConfigBranch *pkNewPen = new CConfigBranch(strIndividualPenKey, strPenName, strSubTitle, ctSubMenuButton,
				false, true, 0, false, pkPenParent);

		// setup the individual pen data
		SetupPenDetails(pkNewPen, ptPenData);
		CConfigBranch *pkBranch = static_cast<CConfigBranch*>(pkPenParent);
		pkBranch->ReplaceChild(pkNewPen);

		// we now need to get the new child for the particular item that was being modified
		pkNewCfgItem = static_cast<CConfigItem*>(indexOfChildByKey(strKEY, pkNewPen, 2));
	} else {
		// there has been a problem
		pkNewCfgItem = static_cast<CConfigItem*>(pkTopParent);
	}

	return pkNewCfgItem;
}
//****************************************************************************
// CConfigInterface *CreateAnalogueInConfig( )
///
/// Method that creates a analogue input config hierarchy
///
/// @return			Pointer to the top-level parent of an analogue config hierarchy
///
//****************************************************************************
CConfigInterface* CRecSetupCfgMgr::CreateAnalogueInConfig() {
	CConfigBranch *pkAnalogueParent = NULL;
	T_PGENERALCONFIG ptGeneralData = pSETUP->GetGeneralSetupConfig()->GetSystemGeneralBlock(CONFIG_MODIFIABLE);
	QString  strGroup("");

	// erase the existing group list
	ms_strAINTableGroupList = tr("No Tables|");

	// loop through the table groups inserting their number and name
	for (USHORT usGroupCount = 0; usGroupCount < GENERALCONFIG_USERTABLE_SIZE; usGroupCount++) {
		strGroup.asprintf(L"%s|", ptGeneralData->UserTable[usGroupCount].Name);
		ms_strAINTableGroupList += strGroup;
	}

	// Check the analogue input setup class exists
	CIOSetupConfig *pkAnalogueSetupCfg = pSETUP->GetIOSetupConfig();
	CSlotMap *pkSlotMap = CSlotMap::GetHandle();
	if ((pkAnalogueSetupCfg != NULL) && (pkSlotMap != NULL)) {

		// firstly create the top level config interface class
		const USHORT usNO_OF_ANALOGUES = MAX_ANALOGUE_IN;
		QString  strAnalogueTitle("");

		// display different text if this is in AMS2750 mode
		if (!pSYSTEM_INFO->FWOptionTUSModeAvailable() && !pSYSTEM_INFO->FWOptionAMS2750ProcessAvailable()) {
			strAnalogueTitle = tr("Analog In");
		} else {
			strAnalogueTitle = tr("Sensors");
		}

		pkAnalogueParent = new CConfigBranch(ms_strANALOGUE_IN_KEY, strAnalogueTitle, strAnalogueTitle,
				ctMainMenuButton, false, true, 0, false, NULL);

		// now create a load of child analogue inputs and add them to the parent
		for (USHORT usCount = 0; usCount < usNO_OF_ANALOGUES; usCount++) {
			USHORT usSlotNo = 0;
			USHORT usBoardChanNum = 0;
			// check the slot number and board channel number are okay and that an analogue input card exists in this slot
			if (CRecSetupCfgMgr::GetAnalogueChannelInfo(usCount + 1, usSlotNo, usBoardChanNum)) {
				// Get the pen data structure
				T_PAICHANNEL ptAnalogueData = NULL;

				ptAnalogueData = pkAnalogueSetupCfg->GetAnalogueInput(usSlotNo, usBoardChanNum, CONFIG_MODIFIABLE);
				// Check we managed to obtain a pen
				if (ptAnalogueData != NULL) {
					QString  strIndAnalogueKey("");
					QString  strAnalogueName("");
					QString  strSubTitle("");

					// update this text if in AMS2750 mode
					if ( pSYSTEM_INFO->FWOptionTUSModeAvailable() || pSYSTEM_INFO->FWOptionAMS2750ProcessAvailable()) {
						strAnalogueTitle = tr("Sensor");
					}

					CreateAnalogueInputTitle(strIndAnalogueKey, strAnalogueName, strSubTitle, strAnalogueTitle,
							ptAnalogueData, usCount);

					CConfigBranch *pkAnalogue = new CConfigBranch(strIndAnalogueKey, strAnalogueName, strSubTitle,
							ctSubMenuButton, false, true, 0, false, pkAnalogueParent);

					// setup the individual pen data
					SetupAnalogueInputDetails(pkAnalogue, ptAnalogueData, usSlotNo, usBoardChanNum);
					pkAnalogueParent->AddChild(pkAnalogue);
				}
			}
		}
	}
	return pkAnalogueParent;
}
//****************************************************************************
// void CRecSetupCfgMgr::CreateAnalogueInputTitle(	QString   &rstrIndAnalogueKey,
//													QString   &rstrAnalogueName,
//													QString   &rstrSubTitle,
//													const QString   &rstrANALOGUE_TITLE,
//													T_PAICHANNEL ptAnalogueData,
//													const USHORT usANALOGUE_INSTANCE_NO ) const
///
/// Method that gets the analogue input channel title information for the submenu button
///
///
//****************************************************************************
void CRecSetupCfgMgr::CreateAnalogueInputTitle(QString  &rstrIndAnalogueKey, QString  &rstrAnalogueName,
		QString  &rstrSubTitle, const QString  &rstrANALOGUE_TITLE, T_PAICHANNEL ptAnalogueData,
		const USHORT usANALOGUE_INSTANCE_NO) const {
	class CSlotMap *pSlotMap = NULL;
	class CBrdInfo *pBrdInfo = NULL;

	pSlotMap = CSlotMap::GetHandle();
	pBrdInfo = CBrdInfo::GetHandle();
	// this is a valid AI card therefore add on to the config tree
	rstrIndAnalogueKey.asprintf(L"%s%d", ms_strANALOGUE_IN_KEY, usANALOGUE_INSTANCE_NO + 1);

	rstrAnalogueName.asprintf(L"%s %d", rstrANALOGUE_TITLE, usANALOGUE_INSTANCE_NO + 1);

	rstrSubTitle = ptAnalogueData->Label;
	rstrSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptAnalogueData->Enabled) + L" " + rstrSubTitle;
	rstrSubTitle += L", " + CStringUtils::GetItemAtPos(ms_strAINTypeList, ptAnalogueData->Type);

	// check if this is a TC in which case we must add the TC type
	if (AI_CHANNEL_TYPE_TC == ptAnalogueData->Type) {
		// add the TC type
		//MarkD: some names are too long, and need shortening for menu display
		QString  strTCType("");
		strTCType = CStringUtils::GetItemAtPos(ms_strAINTCTypeList, ptAnalogueData->TC.SelectedTC);

		if (strTCType.size() > ms_iMAX_MENU_RANGE_CHARS) {
			// trim the length of the TC type
			strTCType.Delete(ms_iMAX_MENU_RANGE_CHARS + 1, strTCType.size() - ms_iMAX_MENU_RANGE_CHARS);
			strTCType += L"..";
		}
		rstrSubTitle += L" (" + strTCType + L")";

		AddTUSSensorMenuInfo(usANALOGUE_INSTANCE_NO, rstrSubTitle);

	} else if (AI_CHANNEL_TYPE_LINEAR_VOLTS == ptAnalogueData->Type) {
		// add the volts range (MarkD)
		if ( USE_PRESET_LIMITS == ptAnalogueData->Linear.Mode) {
			QString  strPresetRange(
					CStringUtils::GetItemAtPos(ms_strAINRangePresetVoltsList, ptAnalogueData->Linear.RangePreset));
			// cehck we have not got an invalid range
			if (strPresetRange == "") {
				// reset back to zero and get the string again
				ptAnalogueData->Linear.RangePreset = 0;
				strPresetRange = CStringUtils::GetItemAtPos(ms_strAINRangePresetVoltsList,
						ptAnalogueData->Linear.RangePreset);
			}
			rstrSubTitle += L" (" + strPresetRange + L")";
		} else {
			QString  strSubTitleUser("");
			strSubTitleUser = tr("User");
			rstrSubTitle += L" (" + strSubTitleUser + L")";
		}
	} else if (AI_CHANNEL_TYPE_LINEAR_OHMS == ptAnalogueData->Type) {
		// add the ohms range (MarkD)
		if ( USE_PRESET_LIMITS == ptAnalogueData->Linear.Mode) {
			QString  strPresetRange = "";
			QString  strTempTypeSelection(
					CStringUtils::GetItemAtPos(ms_strAINRangePresetOhmsList, ptAnalogueData->Linear.RangePreset));
			// check we have not got an invalid range
			if (strTempTypeSelection == "") {
				// reset back to zero and get the string again
				ptAnalogueData->Linear.RangePreset = 0;
				strTempTypeSelection = CStringUtils::GetItemAtPos(ms_strAINRangePresetOhmsList,
						ptAnalogueData->Linear.RangePreset);
			}
			strPresetRange.asprintf(L"%s%c", strTempTypeSelection, g_wcOMEGA);
			rstrSubTitle += L" (" + strPresetRange + L")";
		} else {
			QString  strSubTitleUser("");
			strSubTitleUser = tr("User");
			rstrSubTitle += L" (" + strSubTitleUser + L")";
		}
	} else if (AI_CHANNEL_TYPE_RT == ptAnalogueData->Type) {
		// add the RT type (MarkD)
		// Remove 'OHM' from type name to fit on Minitrend
		QString  strRangeType("");
		strRangeType = CStringUtils::GetItemAtPos(ms_strAINRTTypeList, ptAnalogueData->RT.SelectedRT);
		if (strRangeType.size() > ms_iMAX_MENU_RANGE_CHARS) {
			// trim the length of the OHM type
			strRangeType.Delete(ms_iMAX_MENU_RANGE_CHARS + 1, strRangeType.size() - ms_iMAX_MENU_RANGE_CHARS);
			strRangeType += L"..";
		}
		rstrSubTitle += L" (" + strRangeType + L")";

		AddTUSSensorMenuInfo(usANALOGUE_INSTANCE_NO, rstrSubTitle);
	} else if (AI_CHANNEL_TYPE_LINEAR_AMPS == ptAnalogueData->Type) {
		// add the amps range (MarkD)
		if (ptAnalogueData->Linear.Mode == USE_PRESET_LIMITS) {
			QString  strPresetRange(
					CStringUtils::GetItemAtPos(ms_strAINRangePresetAmpsList, ptAnalogueData->Linear.RangePreset));
			// check we have not got an invalid range
			if (strPresetRange == "") {
				// reset back to zero and get the string again
				ptAnalogueData->Linear.RangePreset = 0;
				strPresetRange = CStringUtils::GetItemAtPos(ms_strAINRangePresetAmpsList,
						ptAnalogueData->Linear.RangePreset);
			}
			rstrSubTitle += L" (" + strPresetRange + L")";
		} else {
			QString  strSubTitleUser("");
			strSubTitleUser = tr("User");
			rstrSubTitle += L" (" + strSubTitleUser + L")";
		}
	}

	// check if this is a linear channel and fast scan is disabled
	// if the current option is set to the fastest then back it off by one
	if ((pBrdInfo->IsAIChannelLinear(ptAnalogueData->Type) == TRUE) && !pSYSTEM_INFO->FWOptionFastScanAvailable()
			&& (AI_ACQ_RATE_50HZ == ptAnalogueData->AcqRate)) {
		// back it off by one e.g. no longer fastscan
		ptAnalogueData->AcqRate -= 1;
	}

	USHORT slotNo;
	USHORT slotChanNo;
	if (pSlotMap != NULL)
		pSlotMap->GetSlotAndChannelFromAnalSysChan(usANALOGUE_INSTANCE_NO, &slotNo, &slotChanNo, ZERO_BASED);

	// check if this channel on an EZ set to 10Hz or 50Hz - if so back it off to 5Hz
	if (GlbDevCaps.GetSlotType(slotNo) == BOARD_EZ_AI) {
		if (AI_ACQ_RATE_50HZ == ptAnalogueData->AcqRate) {
			// back it off to 5Hz
			ptAnalogueData->AcqRate -= 2;
		} else if (AI_ACQ_RATE_10HZ == ptAnalogueData->AcqRate) {
			// back it off to 5Hz
			ptAnalogueData->AcqRate -= 1;
		}
	}

	USHORT AIAcqRate;
	CIOSetupConfig *pkAINSetupCfg = pSETUP->GetIOSetupConfig();
	if ((pkAINSetupCfg->QueryAIAcqRateStatus(CONFIG_MODIFIABLE, slotNo, slotChanNo, &AIAcqRate) == TRUE)
			|| (GlbDevCaps.GetSlotType(slotNo) != BOARD_EZ_AI)) {
		// Only display the acqusition rate, as part of the summary, if the channel is a primary channel
		// i.e. the acqusition rate of the channel can be directly set.
		QString  strAcqRate("");
		strAcqRate = CStringUtils::GetItemAtPos(ms_strAINAcqRateList, AIAcqRate);
		int ileftBrace = 0;
		int irightBrace = 0;
		ileftBrace = strAcqRate.indexOf(L"(", 0);
		if (ileftBrace >= 0) {
			irightBrace = strAcqRate.indexOf(L")", ileftBrace + 1);
			if (irightBrace >= 0) {
				strAcqRate.Delete(ileftBrace, irightBrace + 1 - ileftBrace);
			}
		}

		rstrSubTitle += L", " + strAcqRate;
	}
}
//****************************************************************************
///
/// Helper method used to populate the TUS sensor menu information
///
/// @param[in] 		CConfigBranch *pkParent - Pointer to the parent owner class
/// @param[in]		T_PAICHANNEL ptAnalogueData - A pointer to the associated analogue data
/// @param[in]		const USHORT usSLOT_NO - The slot number of the board this analogue input is on
///
//****************************************************************************
void CRecSetupCfgMgr::AddTUSSensorMenuInfo(const USHORT &usANALOGUE_INSTANCE_NO, QString  &rstrSubTitle) const {
	// add the AMS2750 TUS information if necessary
	if (pSYSTEM_INFO->FWOptionTUSModeAvailable()) {
		T_PAMS2750SENSORS ptSensors = pSETUP->GetIOSetupConfig()->GetAMS2750SensorBlock(CONFIG_MODIFIABLE);

		T_AMS2750SENSOR *ptSensor = &(ptSensors->Sensors[usANALOGUE_INSTANCE_NO]);

		// being a TUS sensor overrides any text to indicate the TC is tracked (real-estate is limited)
		if (ptSensor->TUSTC) {
			// TUS TC therefore add to the subtitle
			QString  strTUSTitle("");
			strTUSTitle = tr("TUS");
			rstrSubTitle += L" " + strTUSTitle;
		} else if (ptSensor->UsageTrack) {
			// Usage tracked therefore add to the subtitle
			QString  strTrackTitle("");
			strTrackTitle = tr("Track");
			rstrSubTitle += L" " + strTrackTitle;
		}
	} else if (pSYSTEM_INFO->FWOptionAMS2750ProcessAvailable()) {
		// this is an AMS2750 process recorder therefore check if the TC is usage tracked
		T_PAMS2750SENSORS ptSensors = pSETUP->GetIOSetupConfig()->GetAMS2750SensorBlock(CONFIG_MODIFIABLE);

		T_AMS2750SENSOR *ptSensor = &(ptSensors->Sensors[usANALOGUE_INSTANCE_NO]);

		if (ptSensor->UsageTrack) {
			// Usage tracked therefore add to the subtitle
			QString  strTrackTitle("");
			strTrackTitle = tr("Track");
			rstrSubTitle += L" " + strTrackTitle;
		}
	}
}
//****************************************************************************
// void SetupAnalogueInputDetails( CConfigBranch *pkParent, 
//									T_PAICHANNEL ptAnalogueData,
//									const USHORT usSLOT_NO,
//									const USHORT usBOARD_CHAN_NO )
///
/// Method that sets up the details for a particular analogue input
///
/// @param[in] 		CConfigBranch *pkParent - Pointer to the parent owner class
/// @param[in]		T_PAICHANNEL ptAnalogueData - A pointer to the associated analogue data
/// @param[in]		const USHORT usSLOT_NO - The slot number of the board this analogue input is on
///
//****************************************************************************
void CRecSetupCfgMgr::SetupAnalogueInputDetails(CConfigBranch *pkParent, T_PAICHANNEL ptAnalogueData,
		const USHORT usSLOT_NO, const USHORT usBOARD_CHAN_NO) {
	class CBrdInfo *pBrdInfo = NULL;
	class CSlotMap *pSlotMap = NULL;
	QString  strSubTitle("");
	QString  strTitle("");
	// we now need to create all the individual components of a analogue
	// Enabled - this will be a boolean type bitfield
	QString  strEnabled("");

	pBrdInfo = CBrdInfo::GetHandle();
	pSlotMap = CSlotMap::GetHandle();
	const bool bLINEAR_MODE = pBrdInfo->IsAIChannelLinear(ptAnalogueData->Type);

	strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptAnalogueData->Enabled);
	CShortBitFieldData *pkEnData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptAnalogueData), 1, 3,
			ms_strEnabledList, bfeBool, 0, 0, true);
	strEnabled = tr("Enabled");
	CConfigItem *pkEnabled = new CConfigItem(ms_strENABLED_KEY, strEnabled, strSubTitle, ctItemButton, pkEnData, false,
			true, 0, false, pkParent);
	pkParent->AddChild(pkEnabled);

	// Type - Volts, Amps, Ohms, RT or TC - this is a USHORT bitfield
	QString  strType("");
	CShortBitFieldData *pkTypeData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptAnalogueData), 3, 0,
			ms_strAINTypeList, bfeSingleSelList, 0, 0, true);
	strSubTitle = pkTypeData->GetDataAsString();
	strType = tr("Type");
	CConfigItem *pkType = new CConfigItem(ms_strANALOGUE_IN_TYPE_KEY, strType, strSubTitle, ctItemButton, pkTypeData,
			false, (ptAnalogueData->Enabled == TRUE), 0, false, pkParent);
	pkParent->AddChild(pkType);
#if (!defined DOCVIEW) && (!defined TTR6SETUP)
	// now add the AMS2750 sensor information if this recorder is configured to do so
	if (CAMS2750TUSMgr::CanBeConfiguredAsAMS2750Sensor(ptAnalogueData)) {
		SetupAMS2750SensorDetails(pkParent, ptAnalogueData);
	}
#endif
	CConfigItem *pkAcqRate = NULL;
	BOOL isPrimaryChannel = TRUE;
	USHORT sysPrimaryChanNo;
	USHORT PrimaryChanNo;
	USHORT BankNo;

	// Acquisition rate - this will be a USHORT bitfield
	QString  strAcqRate("");
	strAcqRate = tr("Sample Rate");

	const USHORT usSLOT_TYPE = GlbDevCaps.GetSlotType(usSLOT_NO);

	if ( BOARD_EZ_AI == usSLOT_TYPE) {
		// eZtrend AI board with channel bank operation
		// indexOf out whether channel is a primary channel in channel
		isPrimaryChannel = GlbDevCaps.AIAcqRatePrimaryChannel(usSLOT_NO, usBOARD_CHAN_NO, &PrimaryChanNo, &BankNo);
		if ( FALSE == isPrimaryChannel) {
			// Refers to primary channel, so cannot edit
			sysPrimaryChanNo = pSlotMap->GetSysChannelFromAnaInChannel(usSLOT_NO, PrimaryChanNo, ZERO_BASED);
			ms_strAINEZFixedAcqRate[usSLOT_NO][BankNo].asprintf(IDS_CFG_AIN_ACQ_NON_PRIMARY_BANK, sysPrimaryChanNo + 1);
			QString   CfgData *pkAcqRateData = new QString   CfgData(ms_strAINEZFixedAcqRate[usSLOT_NO][BankNo].GetBuffer(0),
					ms_strAINEZFixedAcqRate[usSLOT_NO][BankNo].GetLength(), dtString, 0, 0, false);
			pkAcqRate = new CConfigItem(ms_strANALOGUE_IN_ACQ_RATE_KEY, strAcqRate, pkAcqRateData->GetDataAsString(),
					ctItemButton, pkAcqRateData, false, (ptAnalogueData->Enabled == TRUE), 0, true, pkParent);
		} else {
			// Can edit, this channel is a primary channel
			CShortBitFieldData *pkAcqRateData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptAnalogueData), 3, 5,
					ms_strEZAINAcqRateList, bfeSingleSelList, 0, 0, true);

			pkAcqRate = new CConfigItem(ms_strANALOGUE_IN_ACQ_RATE_KEY, strAcqRate, pkAcqRateData->GetDataAsString(),
					ctItemButton, pkAcqRateData, false, (ptAnalogueData->Enabled == TRUE), 0, false, pkParent);
		} // end if( FALSE == isPrimaryChannel )
	} else // if( BOARD_EZ_AI != GlbDevCaps.GetSlotType( usSLOT_NO ) )
	{
		// Normal mini/multi AI card
		if (bLINEAR_MODE) {
			CShortBitFieldData *pkAcqRateData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptAnalogueData), 3, 5,
					ms_strAINAcqRateList, bfeSingleSelList, 0, 0, true);

			pkAcqRate = new CConfigItem(ms_strANALOGUE_IN_ACQ_RATE_KEY, strAcqRate, pkAcqRateData->GetDataAsString(),
					ctItemButton, pkAcqRateData, false, (ptAnalogueData->Enabled == TRUE), 0, false, pkParent);
		} else // if( !bLINEAR_MODE )
		{
			// Acquisition rate - this will be a USHORT bitfield
			CShortBitFieldData *pkAcqRateData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptAnalogueData), 3, 5,
					ms_strAINTCRTAcqRateList, bfeSingleSelList, 0, 0, true);
			pkAcqRate = new CConfigItem(ms_strANALOGUE_IN_ACQ_RATE_KEY, strAcqRate, pkAcqRateData->GetDataAsString(),
					ctItemButton, pkAcqRateData, false, (ptAnalogueData->Enabled == TRUE), 0, false, pkParent);
		} // end if( !bLINEAR_MODE )
	} // end if( BOARD_EZ_AI == GlbDevCaps.GetSlotType( usSLOT_NO ) )
	pkParent->AddChild(pkAcqRate);

	// get the units sorted now as we will need them in a couple of places (for RT's and TC's at least)
	// Units, WCHAR edit
	QString   CfgData *pkUnitsData = new QString   CfgData(reinterpret_cast<WCHAR*>(&ptAnalogueData->Linear.Units),
	LINEARCHAN_UNITS_LEN, dtString, 0, 0, true);
	bool bUnitsEnabled = false;
	QString  strUnitsSubTitle("");
	if (bLINEAR_MODE) {
		strUnitsSubTitle = pkUnitsData->GetDataAsString();
		bUnitsEnabled = (ptAnalogueData->Enabled == TRUE);
	} else {
		bUnitsEnabled = false;
		// get the current temperature units
		const T_TEMP_UNIT eSYS_UNITS = pSYSTEM_INFO->GetDisplayTempUnits();
		QString  strTempList("");
		strTempList = tr("Deg C|Deg F|Kelvin|");
		strUnitsSubTitle = CStringUtils::GetItemAtPos(strTempList, static_cast< USHORT >(eSYS_UNITS));
	}

	// we now need to add the data values particular to the analogue input type
	// we have chosen - volts, ohms and amps use the same structure althoguh some data is different
	// RT and TC use different structures
	if (bLINEAR_MODE) {
		QString  strMode("");
		CShortBitFieldData *pkModeData = new CShortBitFieldData(reinterpret_cast< USHORT*>(&ptAnalogueData->Linear), 1,
				0, ms_strAINLinModeList, bfeBool, 0, 0, true);
		strSubTitle = CStringUtils::GetItemAtPos(ms_strAINLinModeList, ptAnalogueData->Linear.Mode);
		strMode = tr("Range");
		CConfigItem *pkMode = new CConfigItem(ms_strANALOGUE_IN_LIN_MODE_KEY, strMode, strSubTitle, ctItemButton,
				pkModeData, false, (ptAnalogueData->Enabled == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkMode);

		// only add the range preset if preset
		if (ptAnalogueData->Linear.Mode == USE_PRESET_LIMITS) {
			// Range presets - particular to whether volts,current or ohms
			QString  strRangePreset("");
			const QString pwcRangePreset = NULL;
			if (ptAnalogueData->Type == AI_CHANNEL_TYPE_LINEAR_VOLTS) {
				pwcRangePreset = ms_strAINRangePresetVoltsList.GetBuffer(0);
			} else if (ptAnalogueData->Type == AI_CHANNEL_TYPE_LINEAR_AMPS) {
				pwcRangePreset = ms_strAINRangePresetAmpsList.GetBuffer(0);
			} else {
				pwcRangePreset = ms_strAINRangePresetOhmsList.GetBuffer(0);
			}

			// this data item is actually a short but it will make life easier for us to treat it as a bitfield
			CShortBitFieldData *pkRangePresetData = new CShortBitFieldData(
					reinterpret_cast< USHORT*>(&ptAnalogueData->Linear), 8, 1, pwcRangePreset, bfeSingleSelList, 0, 0,
					true);
			strSubTitle = pkRangePresetData->GetDataAsString();
			strRangePreset = tr("Range Type");
			CConfigItem *pkRangePresetType = new CConfigItem(ms_strANALOGUE_IN_LIN_RANGE_PRESET_KEY, strRangePreset,
					strSubTitle, ctItemButton, pkRangePresetData, false, (ptAnalogueData->Enabled == TRUE), 0, false,
					pkParent);
			pkParent->AddChild(pkRangePresetType);

		} else {
			float fUpperLimit = 0;
			float fLowerLimit = 0;

			// calculate the units we need to display
			QString  strUnits("");
			switch (ptAnalogueData->Type) {
			case AI_CHANNEL_TYPE_LINEAR_VOLTS: {
				// add the volts/millivolts selection
				CShortBitFieldData *pkVoltageRangeData = new CShortBitFieldData(
						reinterpret_cast< USHORT*>(&ptAnalogueData->Linear), 1, 9,
						ms_strANALOGUE_IN_LIN_VOLTAGE_RANGE_LIST, bfeSingleSelList, 0, 0, true);
				strSubTitle = pkVoltageRangeData->GetDataAsString();
				strTitle = tr("Voltage Units");
				CConfigItem *pkVoltageRange = new CConfigItem(ms_strANALOGUE_IN_LIN_VOLTAGE_RANGE_KEY, strTitle,
						strSubTitle, ctItemButton, pkVoltageRangeData, false, (ptAnalogueData->Enabled == TRUE), 0,
						false, pkParent);
				pkParent->AddChild(pkVoltageRange);

				// extract mV or V depending on the voltage range selected
				strUnits = pkVoltageRangeData->GetDataAsString();

				// check if the units selected are in millivolts
				if (ptAnalogueData->Linear.UserVoltUnits == vuMilliVolts) {
					fUpperLimit = 1000;
					fLowerLimit = -1000;
				} else {
					fUpperLimit = 50;
					fLowerLimit = -50;
				}

			}
				break;
			case AI_CHANNEL_TYPE_LINEAR_AMPS:
				fUpperLimit = 20;
				fLowerLimit = 0;
				strUnits = L"mA";
				break;
			case AI_CHANNEL_TYPE_LINEAR_OHMS:
				fUpperLimit = 4000;
				fLowerLimit = 0;
				strUnits = L"Ohms";
				break;
			default:
				// do nothing
				break;
			}

			// make sure the current setup has not caused our user limits to exceed the channel capabilities
			// no need to set the modified flag the setup must have already been modified for this situation to
			// arise
			if (ptAnalogueData->Linear.UserHighLim > fUpperLimit) {
				ptAnalogueData->Linear.UserHighLim = fUpperLimit;
			} else if (ptAnalogueData->Linear.UserHighLim < fLowerLimit) {
				ptAnalogueData->Linear.UserHighLim = fLowerLimit;
			}

			if (ptAnalogueData->Linear.UserLowLim > fUpperLimit) {
				ptAnalogueData->Linear.UserLowLim = fUpperLimit;
			} else if (ptAnalogueData->Linear.UserLowLim < fLowerLimit) {
				ptAnalogueData->Linear.UserLowLim = fLowerLimit;
			}

			// User high limit - this will be a float type data field
			CFloatData *pkHiLimitData = new CFloatData(&ptAnalogueData->Linear.UserHighLim, fLowerLimit, fUpperLimit, 0,
					0, false, dtFloat, TEMP_DEG_C, strUnits);
			QString  strHiLimit("");
			strHiLimit = tr("High Limit");

			CConfigItem *pkHiLimit = new CConfigItem(ms_strANALOGUE_IN_LIN_USER_HIGH_LIM_KEY, strHiLimit,
					pkHiLimitData->GetDataAsString(true), ctItemButton, pkHiLimitData, false,
					(ptAnalogueData->Enabled == TRUE), 0, false, pkParent);
			pkParent->AddChild(pkHiLimit);

			// User Low Limit - this will be a float type data field
			CFloatData *pkLoLimitData = new CFloatData(&ptAnalogueData->Linear.UserLowLim, fLowerLimit, fUpperLimit, 0,
					0, false, dtFloat, TEMP_DEG_C, strUnits);
			QString  strLoLimit("");
			strLoLimit = tr("Lower Limit");

			CConfigItem *pkLoLimit = new CConfigItem(ms_strANALOGUE_IN_LIN_USER_LOW_LIMIT_KEY, strLoLimit,
					pkLoLimitData->GetDataAsString(true), ctItemButton, pkLoLimitData, false,
					(ptAnalogueData->Enabled == TRUE), 0, false, pkParent);
			pkParent->AddChild(pkLoLimit);
		}
	}

	// Analgue channel damping level
	CFloatData *pkDampLevelData = new CFloatData(&ptAnalogueData->DampLev, -V6_FLT_MAX, V6_FLT_MAX, 0, 0, false);
	QString  strDampLevel("");
	strDampLevel = tr("Damp Level");
	CConfigItem *pkDampLevel = new CConfigItem(ms_strANALOGUE_IN_DAMP_LEVEL_KEY, strDampLevel,
			pkDampLevelData->GetDataAsString(true), ctItemButton, pkDampLevelData, false,
			(ptAnalogueData->Enabled == TRUE), 0, false, pkParent);
	pkParent->AddChild(pkDampLevel);

	if (bLINEAR_MODE) {
		// User linearisation table
		QString  strGroup("");
		CShortBitFieldData *pkTblData = new CShortBitFieldData(reinterpret_cast< USHORT*>(&ptAnalogueData->Linear), 3,
				10, ms_strAINTableGroupList, bfeSingleSelList, 0, 0, true);

		strSubTitle = CStringUtils::GetItemAtPos(ms_strAINTableGroupList, ptAnalogueData->Linear.UserLinTable);
		strGroup = tr("Linearization Table");

		CConfigItem *pkGroup = new CConfigItem(ms_strANALOGUE_IN_LINEARISATION_TABLE_KEY, strGroup, strSubTitle,
				ctItemButton, pkTblData, false, (ptAnalogueData->Enabled == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkGroup);
	} else if (AI_CHANNEL_TYPE_RT == ptAnalogueData->Type) {
		// this only contains a list of possible RT's, nothing else
		QString  strRTType("");
		// this data item is actually a short but it will make life easier for us to treat it as a bitfield
		CShortBitFieldData *pkRTTypeData = NULL;
		if ( BOARD_EZ_AI == GlbDevCaps.GetSlotType(usSLOT_NO)) {
			pkRTTypeData = new CShortBitFieldData(&ptAnalogueData->RT.SelectedRT, 16, 0, ms_strAINEZRTTypeList,
					bfeSingleSelList, 0, 0, true);
		} else {
			pkRTTypeData = new CShortBitFieldData(&ptAnalogueData->RT.SelectedRT, 16, 0, ms_strAINRTTypeList,
					bfeSingleSelList, 0, 0, true);
		}
		strSubTitle = pkRTTypeData->GetDataAsString();
		strRTType = tr("RT Type");
		CConfigItem *pkRTType = new CConfigItem(ms_strANALOGUE_IN_RT_TYPE_KEY, strRTType, strSubTitle, ctItemButton,
				pkRTTypeData, false, (ptAnalogueData->Enabled == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkRTType);
	} else {
		// this must be TC

		// Active Burn Out - this will be a boolean bitfield
		QString  strActiveBurnOut("");
		CShortBitFieldData *pkActiveBurnOutData = new CShortBitFieldData(
				reinterpret_cast< USHORT*>(&ptAnalogueData->TC), 1, 10, ms_strAINActiveBurnOutList, bfeBool, 0, 0,
				false);
		strSubTitle = CStringUtils::GetItemAtPos(ms_strAINActiveBurnOutList, ptAnalogueData->TC.ActiveBurnout);
		strActiveBurnOut = tr("Burnout Type");
		CConfigItem *pkActiveBurnOut = new CConfigItem(ms_strANALOGUE_IN_TC_ACTIVE_BURN_OUT_KEY, strActiveBurnOut,
				strSubTitle, ctItemButton, pkActiveBurnOutData, false, (ptAnalogueData->Enabled == TRUE), 0,
				(DEVICE_INFO.GetSlotType(usSLOT_NO) == BOARD_EZ_AI), pkParent);
		pkParent->AddChild(pkActiveBurnOut);

		// Up scale burn out - this will be a boolean bitfield
		QString  strUpScaleBurnOut("");
		CShortBitFieldData *pkUpScaleBurnOutData = new CShortBitFieldData(
				reinterpret_cast< USHORT*>(&ptAnalogueData->TC), 1, 0, ms_strAINUpScaleBurnOutList, bfeBool, 0, 0,
				false);
		strSubTitle = CStringUtils::GetItemAtPos(ms_strAINUpScaleBurnOutList, ptAnalogueData->TC.UpScaleBurnOut);
		strUpScaleBurnOut = tr("Show Burnout");
		CConfigItem *pkUpScaleBurnOut = new CConfigItem(ms_strANALOGUE_IN_TC_UP_SCALE_BURN_OUT_KEY, strUpScaleBurnOut,
				strSubTitle, ctItemButton, pkUpScaleBurnOutData, false, (ptAnalogueData->Enabled == TRUE), 0, false,
				pkParent);
		pkParent->AddChild(pkUpScaleBurnOut);

		// TC types - this will be a bitfield list
		QString  strTCType("");
		CShortBitFieldData *pkTCTypeData = new CShortBitFieldData(reinterpret_cast< USHORT*>(&ptAnalogueData->TC), 6, 2,
				ms_strAINTCTypeList, bfeSingleSelList, 0, 0, true);
		strSubTitle = pkTCTypeData->GetDataAsString();
		strTCType = tr("TC Type");
		CConfigItem *pkTCType = new CConfigItem(ms_strANALOGUE_IN_TC_TYPE_KEY, strTCType, strSubTitle, ctItemButton,
				pkTCTypeData, false, (ptAnalogueData->Enabled == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkTCType);

		// CJC Method this will be a bitfield list
		QString  strCJCMethod("");
		CShortBitFieldData *pkCJCMethData = new CShortBitFieldData(reinterpret_cast< USHORT*>(&ptAnalogueData->TC), 2,
				8, ms_strAINCJCMethodList, bfeSingleSelList, 0, 0, true);
		strSubTitle = pkCJCMethData->GetDataAsString();
		strCJCMethod = tr("CJ Comp.");
		CConfigItem *pkCJCMethod = new CConfigItem(ms_strANALOGUE_IN_TC_CJC_KEY, strCJCMethod, strSubTitle,
				ctItemButton, pkCJCMethData, false, (ptAnalogueData->Enabled == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkCJCMethod);

		// only show if external input selected
		if (ptAnalogueData->TC.CJCompMethod == AIN_CJC_EXT_INPUT) {
			// AIN Picker - this will create an analogue in pick list
			CPickerData *pkCJCompAINData = new CPickerData(&ptAnalogueData->TC.CJCompAI, dtSingleAnalogueRTIn, 0, 0,
					false, 1, 1, ptAnalogueData->Instance);
			QString  strCJCompAIN("");
			strCJCompAIN = tr("External Input");
			strSubTitle = pkCJCompAINData->GetDataAsString();
			CConfigItem *pkCJCompAIN = new CConfigItem(ms_strANALOGUE_IN_TIED_TO_KEY, strCJCompAIN, strSubTitle,
					ctItemButton, pkCJCompAINData, false, (ptAnalogueData->Enabled == TRUE), 0, false, pkParent);
			pkParent->AddChild(pkCJCompAIN);
		}
		// only show if external temp selected
		else if (AIN_CJC_EXT_SPEC_TEMP == ptAnalogueData->TC.CJCompMethod) {
			T_PGENNONVOL ptGenNonVol = pSYSTEM_INFO->GetFactoryConfig();

			// Ext specified temp - this will be a float type data field
			CFloatData *pkExtSpecTempData = new CFloatData(&ptAnalogueData->TC.ExtSpecifiedCJ, -V6_FLT_MAX, V6_FLT_MAX,
					0, 0, false, dtTemperature, static_cast<T_TEMP_UNIT>(ptGenNonVol->Localisation.Tempasprintf),
					strUnitsSubTitle);

			strSubTitle = pkExtSpecTempData->GetDataAsString(true);
			strTitle = tr("Ext CJ temp");
			CConfigItem *pkExtSpecTemp = new CConfigItem(ms_strANALOGUE_IN_TC_CJC_EXT_SPEC_KEY, strTitle, strSubTitle,
					ctItemButton, pkExtSpecTempData, false, (ptAnalogueData->Enabled == TRUE), 0, false, pkParent);
			pkParent->AddChild(pkExtSpecTemp);
		}
	}

	// Only display use pen scale if channel is volts or amps and there is no linearisation table selected
	if (((AI_CHANNEL_TYPE_LINEAR_VOLTS == (ptAnalogueData->Type))
			|| (AI_CHANNEL_TYPE_LINEAR_AMPS == (ptAnalogueData->Type)))
			&& (NO_CHAN_LINEARISATION == (ptAnalogueData->Linear.UserLinTable))) {
		// Tied To Pen - this will create a pen pick list
		CPickerData *pkTiedToData = new CPickerData(&ptAnalogueData->TiedTo, dtSinglePenIncNoneSel, 0, 0, true, 0, 1,
				255);
		QString  strTiedToPen("");
		strTiedToPen = tr("Use pen scale");
		strSubTitle = pkTiedToData->GetDataAsString();
		CConfigItem *pkTiedToPen = new CConfigItem(ms_strANALOGUE_IN_TIED_TO_KEY, strTiedToPen, strSubTitle,
				ctItemButton, pkTiedToData, false, (ptAnalogueData->Enabled == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkTiedToPen);
	}

	// Only display Engineering conversion if scaled values used and input is not tied to a pen
//	if( (AI_CHANNEL_TYPE_RT != ptAnalogueData->Type) && (AI_CHANNEL_TYPE_TC != ptAnalogueData->Type) &&
//		(AI_CHANNEL_TYPE_LINEAR_OHMS != ptAnalogueData->Type) && ( NO_TIED_TO_PEN == ptAnalogueData->TiedTo ) )
	if (((AI_CHANNEL_TYPE_LINEAR_VOLTS == (ptAnalogueData->Type))
			|| (AI_CHANNEL_TYPE_LINEAR_AMPS == (ptAnalogueData->Type)))
			&& (NO_CHAN_LINEARISATION == (ptAnalogueData->Linear.UserLinTable)
					&& (NO_TIED_TO_PEN == ptAnalogueData->TiedTo))) {
		// Span - this will be a float type data field
		CFloatData *pkSpanData = new CFloatData(&ptAnalogueData->EngSpan, -V6_FLT_MAX, V6_FLT_MAX, 0, 0, true);
		QString  strSpan("");
		strSpan = tr("Eng. Span");
		CConfigItem *pkSpan = new CConfigItem(ms_strANALOGUE_IN_ENG_SPAN_KEY, strSpan, pkSpanData->GetDataAsString(),
				ctItemButton, pkSpanData, false, (ptAnalogueData->Enabled == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkSpan);

		// Zero - this will be a float type data field
		CFloatData *pkZeroData = new CFloatData(&ptAnalogueData->EngZero, -V6_FLT_MAX, V6_FLT_MAX, 0, 0, true);
		QString  strZero("");
		strZero = tr("Eng. Zero");
		CConfigItem *pkZero = new CConfigItem(ms_strANALOGUE_IN_ENG_ZERO_KEY, strZero, pkZeroData->GetDataAsString(),
				ctItemButton, pkZeroData, false, (ptAnalogueData->Enabled == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkZero);
	}

	// Units, WCHAR edit
	QString  strUnits("");
	strUnits = tr("Units");

	CConfigItem *pkUnits = new CConfigItem(ms_strANALOGUE_IN_LIN_UNITS_KEY, strUnits, strUnitsSubTitle, ctItemButton,
			pkUnitsData, false, bUnitsEnabled, 0, false, pkParent);
	pkParent->AddChild(pkUnits);

	// Label, WCHAR edit
	QString   CfgData *pkLabelData = new QString   CfgData(reinterpret_cast<WCHAR*>(&ptAnalogueData->Label),
	AICHANNEL_LABEL_LEN, dtString, 0, 0, true);
	QString  strLabel("");
	strLabel = tr("Label");
	CConfigItem *pkLabel = new CConfigItem(ms_strANALOGUE_IN_LABEL_KEY, strLabel, pkLabelData->GetDataAsString(),
			ctItemButton, pkLabelData, false, (ptAnalogueData->Enabled == TRUE), 0, false, pkParent);
	pkParent->AddChild(pkLabel);

	if (((ptAnalogueData->Type == AI_CHANNEL_TYPE_LINEAR_VOLTS) || (ptAnalogueData->Type == AI_CHANNEL_TYPE_LINEAR_AMPS))
			&& (NO_CHAN_LINEARISATION == (ptAnalogueData->Linear.UserLinTable))) {
		// Sqrt extraction on/off - USHORT boolean bitfield
		QString  strSqrtExtract("");
		CShortBitFieldData *pkSqrtData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptAnalogueData), 1, 4,
				ms_strAINSqrtExtractList, bfeBool, 0, 0, false);
		strSubTitle = CStringUtils::GetItemAtPos(ms_strAINSqrtExtractList, ptAnalogueData->SqrtExtract);
		strSqrtExtract = tr("SQRT Extract");
		CConfigItem *pkSQRT = new CConfigItem(ms_strANALOGUE_IN_SQRT_EXTRACT_KEY, strSqrtExtract, strSubTitle,
				ctItemButton, pkSqrtData, false, (ptAnalogueData->Enabled == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkSQRT);
	}

	// get the pen scale if necessary
	CPenSetupConfig *pkPenSetupCfg = pSETUP->GetPenSetupConfig();
	if ((ptAnalogueData->TiedTo != NO_TIED_TO_PEN) && (pkPenSetupCfg != NULL)) {
		// Get the pen data structure
		T_PPEN ptPenData = NULL;

		ptPenData = pkPenSetupCfg->GetPen(ptAnalogueData->TiedTo, ZERO_BASED, CONFIG_MODIFIABLE);

		if (ptPenData != NULL) {
			ptAnalogueData->EngZero = ptPenData->Scale.Zero;
			ptAnalogueData->EngSpan = ptPenData->Scale.Span;
		} else {
			// leave the zero and span unchanged - the AI calibration code will need to use the 
			// engineering zero and span too in this case
		}
	}

	// setup the analogue calibration data items
	SetupAICalibrationDetails(pkParent, usSLOT_NO, usBOARD_CHAN_NO, &ptAnalogueData->EngZero, &ptAnalogueData->EngSpan,
			(ptAnalogueData->Enabled == TRUE));

	// check if this board is a demo one
	if ( DEVICE_INFO.IsDemoBoard(usSLOT_NO)) {
		// Demo board therefore add the demo board data items
		SetupDemoBoardDetails(pkParent, usSLOT_NO, usBOARD_CHAN_NO, (ptAnalogueData->Enabled == TRUE));
	}

}
//***************************************************************************
/// Method that sets up the calibration details for an analogue input
///
/// @param[in/out] 		CConfigBranch *pkParent - Pointer to the parent owner class
/// @param[in]			T_PAICHANNEL ptAnalogueData - The analogue data
///
//****************************************************************************
void CRecSetupCfgMgr::SetupAMS2750SensorDetails(CConfigBranch *pkParent, T_PAICHANNEL ptAnalogueData) {
	QString  strTitle("");
	QString  strSubTitle("");

	const USHORT usINSTANCE_NO = ptAnalogueData->Instance;

	bool bAMS2750TUS = ( pSYSTEM_INFO->FWOptionTUSModeAvailable() == TRUE);

	T_PAMS2750SENSORS ptSensors = pSETUP->GetIOSetupConfig()->GetAMS2750SensorBlock(CONFIG_MODIFIABLE);

	T_AMS2750SENSOR *ptSensor = &(ptSensors->Sensors[usINSTANCE_NO]);

	QString  strTUSTCTitle("");
	strTUSTCTitle = tr("TUS Sensor");

	QString  strUsageTrackTitle("");
	strUsageTrackTitle = tr("Track Usage");

	strTitle = tr("AMS2750 Info");

	if (!bAMS2750TUS) {
		// not TUS mode show just show the usage state
		strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptSensor->UsageTrack);
		strSubTitle += strUsageTrackTitle;
	} else if ((ptSensor->TUSTC && ptSensor->UsageTrack) || (!ptSensor->TUSTC && !ptSensor->UsageTrack)) {
		// insert a tick or cross along with both descriptions
		strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptSensor->TUSTC);
		strSubTitle += strTUSTCTitle + L"/" + strUsageTrackTitle;
	} else if (ptSensor->TUSTC) {
		// insert a tick along with the description and its value
		strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptSensor->TUSTC);
		strSubTitle += strTUSTCTitle;
	} else if (ptSensor->UsageTrack) {
		// insert a tick along with the description and its value
		strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptSensor->UsageTrack);
		strSubTitle += strUsageTrackTitle;
	}

	CConfigBranch *pkAMS2750Parent = new CConfigBranch(ms_strANALOGUE_IN_AMS2750_KEY, strTitle, strSubTitle,
			ctSubMenuButton, false, (ptAnalogueData->Enabled == TRUE), 0, false, pkParent);
	pkParent->AddChild(pkAMS2750Parent);

	// to save processing only draw the rest of the config items if the analogue input is enabled
	if (ptAnalogueData->Enabled == TRUE) {

		bool bAllowUsageTrack = false;
		if ((ptAnalogueData->Type == AI_CHANNEL_TYPE_TC)
				&& ((ptAnalogueData->TC.SelectedTC == AI_THERMO_RANGE_K)
						|| (ptAnalogueData->TC.SelectedTC == AI_THERMO_RANGE_J)
						|| (ptAnalogueData->TC.SelectedTC == AI_THERMO_RANGE_T)
						|| (ptAnalogueData->TC.SelectedTC == AI_THERMO_RANGE_N)
						|| (ptAnalogueData->TC.SelectedTC == AI_THERMO_RANGE_E)
						|| (ptAnalogueData->TC.SelectedTC == AI_THERMO_RANGE_M))) {
			bAllowUsageTrack = true;
		}

		if (bAMS2750TUS) {
			// TUS TC/RTD
			CShortBitFieldData *pkTUSTCData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptSensor), 1, 0,
					ms_strEnabledList, bfeBool, 0, 0, true);

			CConfigItem *pkTUSTC = new CConfigItem(ms_strANALOGUE_IN_AMS2750_TUS_TC_KEY, strTUSTCTitle,
					pkTUSTCData->GetDataAsString(), ctItemButton, pkTUSTCData, false, true, 0, false, pkAMS2750Parent);
			pkAMS2750Parent->AddChild(pkTUSTC);

			// Control TC selection
			// set to false if not a TUS TC/RTD
			if (ptSensor->TUSTC == FALSE) {
				ptSensor->ControlTC = FALSE;
			}
			CShortBitFieldData *pkControlSensorData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptSensor), 1, 3,
					ms_strEnabledList, bfeBool, 0, 0, false);

			strTitle = tr("Control Sensor");

			CConfigItem *pkControlSensor = new CConfigItem(ms_strANALOGUE_IN_AMS2750_CONTROL_TC_KEY, strTitle,
					pkControlSensorData->GetDataAsString(), ctItemButton, pkControlSensorData, false,
					(ptSensor->TUSTC == TRUE), 0, false, pkAMS2750Parent);
			pkAMS2750Parent->AddChild(pkControlSensor);
		}

		// Track TC Usage - only allowed for certain TC's
		if (!bAllowUsageTrack) {
			// Disable the usage tracking field and set to no tracking
			ptSensor->UsageTrack = FALSE;
		}
		CShortBitFieldData *pkUsageTrackData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptSensor), 1, 1,
				ms_strEnabledList, bfeBool, 0, 0, true);

		CConfigItem *pkUsageTrack = new CConfigItem(ms_strANALOGUE_IN_AMS2750_USAGE_TRACK_KEY, strUsageTrackTitle,
				pkUsageTrackData->GetDataAsString(), ctItemButton, pkUsageTrackData, false, bAllowUsageTrack, 0, false,
				pkAMS2750Parent);
		pkAMS2750Parent->AddChild(pkUsageTrack);

		if (bAMS2750TUS) {
			// Serial No.
			QString   CfgData *pkSerialNoData = new QString   CfgData(ptSensor->SerialNo,
			AMS2750SENSOR_SERIALNO_LEN, dtString, 0, 0, false);
			strTitle = tr("Serial No.");

			CConfigItem *pkSerialNo = new CConfigItem(ms_strANALOGUE_IN_AMS2750_SERIAL_NO_KEY, strTitle,
					pkSerialNoData->GetDataAsString(), ctItemButton, pkSerialNoData, false, true, 0, false,
					pkAMS2750Parent);
			pkAMS2750Parent->AddChild(pkSerialNo);

			// Position
			QString   CfgData *pkPositionData = new QString   CfgData(ptSensor->TCPosition,
			AMS2750SENSOR_TCPOSITION_LEN, dtString, 0, 0, false);
			strTitle = tr("Position");

			CConfigItem *pkPosition = new CConfigItem(ms_strANALOGUE_IN_AMS2750_TC_POS_KEY, strTitle,
					pkPositionData->GetDataAsString(), ctItemButton, pkPositionData, false, true, 0, false,
					pkAMS2750Parent);
			pkAMS2750Parent->AddChild(pkPosition);

			// Manufacturer
			QString   CfgData *pkManufacturerData = new QString   CfgData(ptSensor->Manufacturer,
			AMS2750SENSOR_MANUFACTURER_LEN, dtString, 0, 0, false);
			strTitle = tr("Manufacturer");

			CConfigItem *pkManufacturer = new CConfigItem(ms_strANALOGUE_IN_AMS2750_TC_MANF_KEY, strTitle,
					pkManufacturerData->GetDataAsString(), ctItemButton, pkManufacturerData, false, true, 0, false,
					pkAMS2750Parent);
			pkAMS2750Parent->AddChild(pkManufacturer);

		}

		// Expendable or non-expendable TC or RT type
		CShortBitFieldData *pkTypeData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptSensor), 1, 2,
				ms_strAnalogueInAMS2750SensorTypeListKey, bfeSingleSelList, 0, 0, false);
		strTitle = tr("Type");

		CConfigItem *pkType = new CConfigItem(ms_strANALOGUE_IN_AMS2750_TC_TYPE_KEY, strTitle,
				pkTypeData->GetDataAsString(), ctItemButton, pkTypeData, false, true, 0, false, pkAMS2750Parent);
		pkAMS2750Parent->AddChild(pkType);

		// add the load TC/RTD option if not a TUS recorder
		if (!bAMS2750TUS) {
			CShortBitFieldData *pkLoadSensorData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptSensor), 1, 4,
					ms_strEnabledList, bfeBool, 0, 0, false);

			strTitle = tr("Load Sensor");

			CConfigItem *pkLoadSensor = new CConfigItem(ms_strANALOGUE_IN_AMS2750_LOAD_TC_KEY, strTitle,
					pkLoadSensorData->GetDataAsString(), ctItemButton, pkLoadSensorData, false, true, 0, false,
					pkAMS2750Parent);
			pkAMS2750Parent->AddChild(pkLoadSensor);

		} else {
			// this is a TUS recorder therefore not allowed load sensors
			ptSensor->LoadTC = FALSE;
		}

		// Renewal Date
		CULongData *pkRenewalDateData = new CULongData(&ptSensor->DateRenewed, 1136073600, ULONG_MAX, 0, 0, false,
				dtDate);
		strTitle = tr("Renewed On");

		CConfigItem *pkRenewalDate = new CConfigItem(ms_strANALOGUE_IN_AMS2750_TC_RENEW_DATE_KEY, strTitle,
				pkRenewalDateData->GetDataAsString(), ctItemButton, pkRenewalDateData, false, true, 0, false,
				pkAMS2750Parent);
		pkAMS2750Parent->AddChild(pkRenewalDate);

		CShortBitFieldData *pkCalTrackData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptSensor), 1, 5,
				ms_strEnabledList, bfeBool, 0, 0, true);

		strTitle = tr("Track Cal.");
		CConfigItem *pkCalTrack = new CConfigItem(ms_strANALOGUE_IN_AMS2750_CAL_TRACK_KEY, strTitle,
				pkCalTrackData->GetDataAsString(), ctItemButton, pkCalTrackData, false, true, 0, false,
				pkAMS2750Parent);
		pkAMS2750Parent->AddChild(pkCalTrack);

		// Next calibration date
		CULongData *pkCalibrationDateData = new CULongData(&ptSensor->NextCalibDate, 1136073600, ULONG_MAX, 0, 0, false,
				dtDate);
		strTitle = tr("Next Cal. Date");

		CConfigItem *pkCalibrationDate = new CConfigItem(ms_strANALOGUE_IN_AMS2750_TC_NEXT_CALIB_DATE_KEY, strTitle,
				pkCalibrationDateData->GetDataAsString(), ctItemButton, pkCalibrationDateData, false,
				(ptSensor->CalTrack == TRUE), 0, false, pkAMS2750Parent);
		pkAMS2750Parent->AddChild(pkCalibrationDate);

#ifndef TTR6SETUP
		if (bAMS2750TUS) {
			// now create the sensor cal edit menu item
			CAMS2750SensorCalData *pkSensorCalData = new CAMS2750SensorCalData(ptSensor);

			strTitle = tr("Cal. Adjust");
			CConfigItem *pkSensorCal = new CConfigItem(ms_strANALOGUE_IN_AMS2750_TC_SENSOR_CAL_TABLE_KEY, strTitle,
					pkSensorCalData->GetDataAsString(), ctItemButton, pkSensorCalData, false, true, 0, false,
					pkAMS2750Parent);
			pkAMS2750Parent->AddChild(pkSensorCal);
		}
#endif
		// certificate number
		QString   CfgData *pkCertNoData = new QString   CfgData(ptSensor->CertNumber,
		AMS2750SENSOR_CERTNUMBER_LEN, dtString, 0, 0, false);
		strTitle = tr("Cert. No.");

		CConfigItem *pkCertNo = new CConfigItem(ms_strANALOGUE_IN_AMS2750_TC_CERT_NO_KEY, strTitle,
				pkCertNoData->GetDataAsString(), ctItemButton, pkCertNoData, false, true, 0, false, pkAMS2750Parent);
		pkAMS2750Parent->AddChild(pkCertNo);
	}
}
//****************************************************************************
// void SetupAICalibrationDetails( CConfigBranch *pkParent, 
//									const USHORT usSLOT_NO,
//									const USHORT usCHANNEL_NO,
//									float *pfEngZero,
//									float *pfEngSpan,
//									const bool bENABLED )
///
/// Method that sets up the calibration details for an analogue input
///
/// @param[in/out] 		CConfigBranch *pkParent - Pointer to the parent owner class
/// @param[in]			const USHORT usSLOT_NO - The slot number of this AI board
/// @param[in]			const USHORT usCHANNEL_NO - The channel number of this AI channel
/// @param[in]			float *pfEngZero - Pointer to the engineering zero
/// @param[in]			float *pfEngSpan - Pointer to the engineering span
/// @param[in]			const bool bENABLED - Flag indicating if this item is enabled or disabled
///
//****************************************************************************
void CRecSetupCfgMgr::SetupAICalibrationDetails(CConfigBranch *pkParent, const USHORT usSLOT_NO,
		const USHORT usCHANNEL_NO, float *pfEngZero, float *pfEngSpan, const bool bENABLED) {
	QString  strTitle("");
	QString  strSubTitle("");
	T_AICHANNEL *ptAnalogueData = NULL;
	USHORT chanType;

	// Get the demo channel information
	CIOSetupConfig *pkIOSetupCfg = pSETUP->GetIOSetupConfig();
	ptAnalogueData = pkIOSetupCfg->GetAnalogueInput(usSLOT_NO, usCHANNEL_NO, CONFIG_MODIFIABLE);
	chanType = ptAnalogueData->Type;
	T_PBOARDCALS ptBoardCals = pkIOSetupCfg->GetTopSlotBoardRangeCalInfo(usSLOT_NO, CONFIG_MODIFIABLE);

	// check the channel board cal information is valid
	if (ptBoardCals != NULL) {
		T_PCHANCALPOINT ptCalPoints = &ptBoardCals->ChanCals[usCHANNEL_NO].PointCals;
		strTitle = tr("Sensor comp.");
		strSubTitle = CStringUtils::GetItemAtPos(ms_strAINCalibrationTypesList, ptCalPoints->CalType);
		CConfigBranch *pkCalParent = new CConfigBranch(ms_strANALOGUE_IN_CALIBRATION_KEY, strTitle, strSubTitle,
				ctSubMenuButton, false, bENABLED, 0, false, pkParent);
		pkParent->AddChild(pkCalParent);

		// Calibration type
		CShortBitFieldData *pkCalTypeData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptCalPoints), 2, 0,
				ms_strAINCalibrationTypesList, bfeSingleSelList, 0, 0, true);
		strSubTitle = pkCalTypeData->GetDataAsString();
		strTitle = tr("Comp Type");
		CConfigItem *pkCalType = new CConfigItem(ms_strANALOGUE_IN_CALIB_TYPE_KEY, strTitle, strSubTitle, ctItemButton,
				pkCalTypeData, false, true, 0, false, pkCalParent);
		pkCalParent->AddChild(pkCalType);

		const bool bENABLED = (ptCalPoints->CalType != V6_NO_OUTPUT_CAL);

		// check if this is a dual point cal
		if (ptCalPoints->CalType == V6_DUAL_POINT_CAL) {
			// dual point cal

			/* REMOVED UNTIL PHASE 2
			 // Show extended range
			 CShortBitFieldData *pkExtendedRangeData = new CShortBitFieldData(	reinterpret_cast< USHORT* >( ptCalPoints ),
			 1,
			 2,
			 ms_strEnabledList,
			 bfeBool,
			 0,
			 0,
			 true );
			 strSubTitle = pkExtendedRangeData->GetDataAsString();
			 strTitle = tr("Full range");
			 CConfigItem *pkExtendedRange = new CConfigItem(	ms_strANALOGUE_IN_CALIB_DUAL_RANGE_KEY,
			 strTitle,
			 strSubTitle,						
			 ctItemButton,
			 pkExtendedRangeData,
			 false,
			 bENABLED,
			 0,
			 false,
			 pkCalParent );
			 pkCalParent->AddChild( pkExtendedRange );
			 */

			// get the dual point values
			CFloatData *pkDualPt1Data = NULL;
			CFloatData *pkDualPt2Data = NULL;

			/* REMOVED UNTIL PHASE 2
			 if( ptCalPoints->DualRangeExtend == V6_DUAL_POINT_CAL_BETWEEN_POINTS )
			 */
			{
				if ((AI_CHANNEL_TYPE_RT == chanType) || (AI_CHANNEL_TYPE_TC == chanType)) {
					// not extended range so use the cal points
					pkDualPt1Data = new CFloatData(&ptCalPoints->DPCal1, -V6_FLT_MAX, V6_FLT_MAX, 0, 0, false,
							dtTemperature, pGlbSysInfo->GetDisplayTempUnits());
					pkDualPt2Data = new CFloatData(&ptCalPoints->DPCal2, -V6_FLT_MAX, V6_FLT_MAX, 0, 0, false,
							dtTemperature, pGlbSysInfo->GetDisplayTempUnits());
				} else {
					// not extended range so use the cal points
					pkDualPt1Data = new CFloatData(&ptCalPoints->DPCal1, -V6_FLT_MAX, V6_FLT_MAX, 0, 0, false);
					pkDualPt2Data = new CFloatData(&ptCalPoints->DPCal2, -V6_FLT_MAX, V6_FLT_MAX, 0, 0, false);
				}
			}
			/* REMOVED UNTIL PHASE 2
			 else
			 {
			 if( (AI_CHANNEL_TYPE_RT == chanType) || (AI_CHANNEL_TYPE_TC == chanType) )
			 {
			 // extended range so use the AI slot zero and span
			 pkDualPt1Data = new CFloatData(	pfEngZero,
			 -V6_FLT_MAX,
			 V6_FLT_MAX,
			 0,
			 0,
			 false,
			 dtTemperature,
			 pGlbSysInfo->GetDisplayTempUnits() );
			 pkDualPt2Data = new CFloatData(	pfEngSpan,
			 -V6_FLT_MAX,
			 V6_FLT_MAX,
			 0,
			 0,
			 false,
			 dtTemperature,
			 pGlbSysInfo->GetDisplayTempUnits() );
			 }
			 else
			 {
			 // extended range so use the AI slot zero and span
			 pkDualPt1Data = new CFloatData(	pfEngZero,
			 -V6_FLT_MAX,
			 V6_FLT_MAX,
			 0,
			 0,
			 false );
			 pkDualPt2Data = new CFloatData(	pfEngSpan,
			 -V6_FLT_MAX,
			 V6_FLT_MAX,
			 0,
			 0,
			 false );
			 }
			 }
			 */

			strTitle = tr("Low Eng");
			strSubTitle = pkDualPt1Data->GetDataAsString();
			CConfigItem *pkDualPt1 = new CConfigItem(ms_strANALOGUE_IN_CALIB_DUAL_PT1_ENG_KEY, strTitle, strSubTitle,
					ctItemButton, pkDualPt1Data, false,
					bENABLED/* && ( ptCalPoints->DualRangeExtend == V6_DUAL_POINT_CAL_BETWEEN_POINTS )*/, 0, false,
					pkCalParent);
			pkCalParent->AddChild(pkDualPt1);

			CFloatData *pkDualPt1AdjData = NULL;
			if ((AI_CHANNEL_TYPE_RT == chanType) || (AI_CHANNEL_TYPE_TC == chanType)) {
				// dual point 1 adj
				pkDualPt1AdjData = new CFloatData(&ptCalPoints->DPCal1Adj, -V6_FLT_MAX, V6_FLT_MAX, 0, 0, true,
						dtTempRelative, pGlbSysInfo->GetDisplayTempUnits());
			} else {
				// dual point 1 adj
				pkDualPt1AdjData = new CFloatData(&ptCalPoints->DPCal1Adj, -V6_FLT_MAX, V6_FLT_MAX, 0, 0, true);
			}
			strTitle = tr("Low offset");
			strSubTitle = pkDualPt1AdjData->GetDataAsString();
			CConfigItem *pkDualPt1Adj = new CConfigItem(ms_strANALOGUE_IN_CALIB_DUAL_PT1_ADJ_KEY, strTitle, strSubTitle,
					ctItemButton, pkDualPt1AdjData, false, bENABLED, 0, false, pkCalParent);
			pkCalParent->AddChild(pkDualPt1Adj);

			strTitle = tr("High Eng");
			strSubTitle = pkDualPt2Data->GetDataAsString();
			CConfigItem *pkDualPt2 = new CConfigItem(ms_strANALOGUE_IN_CALIB_DUAL_PT2_ENG_KEY, strTitle, strSubTitle,
					ctItemButton, pkDualPt2Data, false,
					bENABLED/* && ( ptCalPoints->DualRangeExtend == V6_DUAL_POINT_CAL_BETWEEN_POINTS )*/, 0, false,
					pkCalParent);
			pkCalParent->AddChild(pkDualPt2);

			CFloatData *pkDualPt2AdjData = NULL;
			if ((AI_CHANNEL_TYPE_RT == chanType) || (AI_CHANNEL_TYPE_TC == chanType)) {
				// dual point 2 adj
				pkDualPt2AdjData = new CFloatData(&ptCalPoints->DPCal2Adj, -V6_FLT_MAX, V6_FLT_MAX, 0, 0, true,
						dtTempRelative, pGlbSysInfo->GetDisplayTempUnits());
			} else {
				// dual point 2 adj
				pkDualPt2AdjData = new CFloatData(&ptCalPoints->DPCal2Adj, -V6_FLT_MAX, V6_FLT_MAX, 0, 0, true);
			}
			strTitle = tr("High offset");
			strSubTitle = pkDualPt2AdjData->GetDataAsString();
			CConfigItem *pkDualPt2Adj = new CConfigItem(ms_strANALOGUE_IN_CALIB_DUAL_PT2_ADJ_KEY, strTitle, strSubTitle,
					ctItemButton, pkDualPt2AdjData, false, bENABLED, 0, false, pkCalParent);
			pkCalParent->AddChild(pkDualPt2Adj);
		} else if (ptCalPoints->CalType == V6_MULTI_POINT_CAL) {
			// now create the sensor cal edit menu item
			T_PMPCALCHANNELS ptMultiPointChannels = pkIOSetupCfg->GetMultiPointBlock(CONFIG_MODIFIABLE);
			CMultiPointCalData *pkMpCalData = new CMultiPointCalData(
					&(ptMultiPointChannels->Channel[ptAnalogueData->Instance]),
					(AI_CHANNEL_TYPE_RT == chanType) || (AI_CHANNEL_TYPE_TC == chanType));

			strTitle = tr("Values");
			CConfigItem *pkMultiPointCal = new CConfigItem(ms_strANALOGUE_IN_CALIB_MULTI_POINT_TABLE_KEY, strTitle,
					pkMpCalData->GetDataAsString(), ctItemButton, pkMpCalData, false, true, 0, false, pkCalParent);
			pkCalParent->AddChild(pkMultiPointCal);

			if ((pSYSTEM_INFO->GetAMS2750Mode() != AMS2750_NONE)
					&& ((AI_CHANNEL_TYPE_RT == chanType) || (AI_CHANNEL_TYPE_TC == chanType))) {
				// Last calibration test date
				CULongData *pkLastCalDateData = new CULongData(
						&ptMultiPointChannels->LastCalDate[ptAnalogueData->Instance], 1577836800, ULONG_MAX, 0, 0,
						false, dtDateTime);
				strTitle = tr("Last Cal. Date");

				CConfigItem *pkLastCalDate = new CConfigItem(ms_strANALOGUE_IN_CALIB_MULTI_POINT_LAST_CAL_KEY, strTitle,
						pkLastCalDateData->GetDataAsString(), ctItemButton, pkLastCalDateData, false, true, 0, false,
						pkCalParent);

				pkCalParent->AddChild(pkLastCalDate);
			}
		} else {
			CFloatData *pkSinglePtData = NULL;

			if ((AI_CHANNEL_TYPE_RT == chanType) || (AI_CHANNEL_TYPE_TC == chanType)) {
				// disabled or a single point cal therefore show the single point cal information
				pkSinglePtData = new CFloatData(&ptCalPoints->SingleCal, -V6_FLT_MAX, V6_FLT_MAX, 0, 0, true,
						dtTempRelative, pGlbSysInfo->GetDisplayTempUnits());
			} else {
				// disabled or a single point cal therefore show the single point cal information
				pkSinglePtData = new CFloatData(&ptCalPoints->SingleCal, -V6_FLT_MAX, V6_FLT_MAX, 0, 0, true);
			}
			strTitle = tr("Eng Offset");
			strSubTitle = pkSinglePtData->GetDataAsString();
			CConfigItem *pkSinglePt = new CConfigItem(ms_strANALOGUE_IN_CALIB_SINGLE_POINT_KEY, strTitle, strSubTitle,
					ctItemButton, pkSinglePtData, false, bENABLED, 0, false, pkCalParent);
			pkCalParent->AddChild(pkSinglePt);
		}

	}
}
//****************************************************************************
// CConfigItem *RefreshAnalogueInputConfigTree(	CConfigItem *pkModifiedItem,
//													const USHORT usAIN_NO )
///
/// Method that refreshes the data for an analogue input branch of an analogue configuration menu,
/// usually following a change that requires the tree structure to be regenerated because it is different
///
/// @param[in] 		CConfigItem *pkModifiedItem - A pointer to the item that has been modified - this will
///					be destroyed
/// @param[in] 		const USHORT usAIN_NO - The number of the AIN that has changed (1 based)
///
/// @return			A pointer to the new config item (it will have the same key as the modified item)
///
//****************************************************************************
CConfigItem* CRecSetupCfgMgr::RefreshAnalogueInputConfigTree(CConfigItem *pkModifiedItem, const USHORT usAIN_NO) {
	CConfigItem *pkNewCfgItem = NULL;
	CConfigInterface *pkTopParent = NULL;

	// Store the key name of this item
	const QString  strKEY(pkModifiedItem->GetKey());

	CConfigInterface *pkAINParent = pkModifiedItem;

	// get the top level parent
	while (pkAINParent->GetParent() != NULL) {
		pkAINParent = pkAINParent->GetParent();
	}
	pkTopParent = pkAINParent->GetParent();

	// Get the pen data structure
	T_PAICHANNEL ptAINData = NULL;

	CIOSetupConfig *pkAINSetupCfg = pSETUP->GetIOSetupConfig();

	USHORT usSlotNumber = 0;
	USHORT usBoardChanNumber = 0;

	if (GetAnalogueChannelInfo(usAIN_NO, usSlotNumber, usBoardChanNumber)) {
		if (pkAINSetupCfg != NULL) {
			ptAINData = pkAINSetupCfg->GetAnalogueInput(usSlotNumber, usBoardChanNumber, CONFIG_MODIFIABLE);
		}

		// Check we managed to obtain a AIN
		if (ptAINData != NULL) {
			QString  strIndividualAINKey("");
			QString  strAINName("");
			QString  strSubTitle("");
			QString  strAINTitle("");

			// display different text if this is in AMS2750 mode
			if (!pSYSTEM_INFO->FWOptionTUSModeAvailable() && !pSYSTEM_INFO->FWOptionAMS2750ProcessAvailable()) {
				strAINTitle = tr("Analog In");
			} else {
				strAINTitle = tr("Sensor");
			}

			CreateAnalogueInputTitle(strIndividualAINKey, strAINName, strSubTitle, strAINTitle, ptAINData,
					usAIN_NO - 1);

			CConfigBranch *pkNewAIN = new CConfigBranch(strIndividualAINKey, strAINName, strSubTitle, ctSubMenuButton,
					false, true, 0, false, pkAINParent);

			// setup the individual AIN data
			SetupAnalogueInputDetails(pkNewAIN, ptAINData, usSlotNumber, usBoardChanNumber);
			CConfigBranch *pkBranch = static_cast<CConfigBranch*>(pkAINParent);
			pkBranch->ReplaceChild(pkNewAIN);

			// we now need to get the new child for the particular item that was being modified
			pkNewCfgItem = static_cast<CConfigItem*>(indexOfChildByKey(strKEY, pkNewAIN, 2));
		}
	} else {
		// there has been a problem
		pkNewCfgItem = static_cast<CConfigItem*>(pkTopParent);
	}

	return pkNewCfgItem;
}
//****************************************************************************
//	void GetAnalogueChannelInfo(	const USHORT usANALOGUE_INPUT_NO,
//									USHORT &rusSlotNo,
//									USHORT &rusBoardChanNum )
///
/// Method that obtains an AI channel slot and board channel number
///
/// @param[in] 				const USHORT usANALOGUE_INPUT_NO - The analogue number from 1 - 48
//	@param[out]				USHORT &rusSlotNo - The slot number from 1 - 6
//	@param[out]				USHORT &rusBoardChanNum - The board channel number from 0 - 7
///
/// @return					True if this analogue input is valid
//****************************************************************************
bool CRecSetupCfgMgr::GetAnalogueChannelInfo(const USHORT usANALOGUE_INPUT_NO,
USHORT &rusSlotNo,
USHORT &rusBoardChanNum) {
	bool bValid = false;
	CSlotMap *pkSlotMap = CSlotMap::GetHandle();

	// we need to get the slot and board channel number for all the analogue inputs
	const UCHAR ucSLOT_NO = pkSlotMap->GetAnaInChannelSlotNo(usANALOGUE_INPUT_NO, ONE_BASED);

	const UCHAR ucBOARD_CHAN_NUM = pkSlotMap->GetBoardChannelFromAnaInChannel(usANALOGUE_INPUT_NO, ONE_BASED);

	// check the slot number and board channel number are okay
	if ((ucSLOT_NO != SMAP_ILLEGAL_INDEX) && (ucBOARD_CHAN_NUM != SMAP_ILLEGAL_INDEX)) {
		// now confirm if this analogue input exists
		if ( DEVICE_INFO.IsValidAIChannel(static_cast< USHORT >(ucSLOT_NO), static_cast< USHORT >(ucBOARD_CHAN_NUM))) {
			bValid = true;
			rusSlotNo = ucSLOT_NO;
			rusBoardChanNum = ucBOARD_CHAN_NUM;
		}
	}
	return bValid;
}
//****************************************************************************
// CConfigItem *RefreshDigitalIOConfigTree(	CConfigItem *pkModifiedItem,
//												const USHORT usDIG_IO_NO )
///
/// Method that refreshes the data for an digital IO branch of a digital IO configuration menu,
/// usually following a change that requires the tree structure to be regenerated because it is different
///
/// @param[in] 		CConfigItem *pkModifiedItem - A pointer to the item that has been modified - this will
///					be destroyed
/// @param[in] 		const USHORT usDIG_IO_NO - The number of the digital IO that has changed (1 based)
///
/// @return			A pointer to the new config item (it will have the same key as the modified item)
///
//****************************************************************************
CConfigItem* CRecSetupCfgMgr::RefreshDigitalIOConfigTree(CConfigItem *pkModifiedItem, const USHORT usDIG_IO_NO) {
	CConfigItem *pkNewCfgItem = NULL;
	CConfigInterface *pkTopParent = NULL;

	// Store the key name of this item
	const QString  strKEY(pkModifiedItem->GetKey());

	CConfigInterface *pkDigitalIOParent = pkModifiedItem;

	// get the top level parent
	while (pkDigitalIOParent->GetParent() != NULL) {
		pkDigitalIOParent = pkDigitalIOParent->GetParent();
	}
	pkTopParent = pkDigitalIOParent->GetParent();

	// Get the pen data structure
	T_PDIGCHANNEL ptDigitalIOData = NULL;

	CIOSetupConfig *pkDigialIOSetupCfg = pSETUP->GetIOSetupConfig();

	USHORT usSlotNumber = 0;
	USHORT usBoardChanNumber = 0;

	USHORT usChannelCaps = 0;

	if (GetDigitalIOChannelInfo(usDIG_IO_NO, usSlotNumber, usBoardChanNumber, usChannelCaps)) {
		if (pkDigialIOSetupCfg != NULL) {
			ptDigitalIOData = pkDigialIOSetupCfg->GetDigital(usSlotNumber, usBoardChanNumber, CONFIG_MODIFIABLE);
		}

		// Check we managed to obtain a digital IO
		if (ptDigitalIOData != NULL) {
			QString  strTitle("");
			QString  strSubTitle("");
			QString  strKey("");

			CreateDigitalTitle(usSlotNumber, usDIG_IO_NO, usChannelCaps, ptDigitalIOData, strTitle, strSubTitle,
					strKey);

			CConfigBranch *pkNewDigIO = new CConfigBranch(strKey, strTitle, strSubTitle, ctSubMenuButton, false, true,
					0, false, pkDigitalIOParent);

			// setup the individual DIO data
			SetupDigitalIODetails(pkNewDigIO, ptDigitalIOData, usSlotNumber, usBoardChanNumber, usChannelCaps);

			CConfigBranch *pkBranch = static_cast<CConfigBranch*>(pkDigitalIOParent);
			pkBranch->ReplaceChild(pkNewDigIO);

			// we now need to get the new child for the particular item that was being modified
			pkNewCfgItem = static_cast<CConfigItem*>(indexOfChildByKey(strKEY, pkNewDigIO, 2));
		}
	} else {
		// there has been a problem
		pkNewCfgItem = static_cast<CConfigItem*>(pkTopParent);
	}

	return pkNewCfgItem;
}

//****************************************************************************
// void CRecSetupCfgMgr::CreateDigitalTitle(	const USHORT usSLOT_NO,
//												const USHORT usDIGIO_NO,
//												const USHORT usCHANNEL_CAPS,
//												T_PDIGCHANNEL ptDigitalIOData,
//												QString   &rstrTitle,
//												QString   &rstrSubTitle,
//												QString   &rstrKey ) const
///
/// Method that gets the digital channel title information for the submenu button
///
///
//****************************************************************************
void CRecSetupCfgMgr::CreateDigitalTitle(const USHORT usSLOT_NO, const USHORT usDIGIO_NO, const USHORT usCHANNEL_CAPS,
		T_PDIGCHANNEL ptDigitalIOData, QString  &rstrTitle, QString  &rstrSubTitle, QString  &rstrKey) const {
	const UCHAR ucBOARD_TYPE = static_cast<UCHAR>(GlbDevCaps.GetSlotType(usSLOT_NO));

	// recreate a AIN branch for this item
	rstrKey.asprintf(L"%s%d", ms_strDIGIO_KEY, usDIGIO_NO);
	QString  strDigIOTitle("");

	//MarkD: only append I/O when there is an input possible, otherwise specify 'Out'
	// specify DIO as 'Digital' and AR and 'Alarm'
	if (ucBOARD_TYPE == BOARD_DIO) {
		strDigIOTitle = tr("Digital");

		// but allow for future variations
		if (usCHANNEL_CAPS == CHANNEL_CAP_DO)	// output only - not currently used
		{
			QString  strDigOut("");
			strDigOut = tr("Out");
			strDigIOTitle += L" " + strDigOut;
		} else if (usCHANNEL_CAPS == CHANNEL_CAP_DI)	// input only - not currently used
		{
			QString  strDigIn("");
			strDigIn = tr("In");
			strDigIOTitle += L" " + strDigIn;
		} else {
			QString  strDigIO("");
			strDigIO = tr("I/O");
			strDigIOTitle += L" " + strDigIO;
		}
	} else if (ucBOARD_TYPE == BOARD_AR) {
		strDigIOTitle = tr("Alarm");
		if (usCHANNEL_CAPS == CHANNEL_CAP_DO)	// output only
		{
			QString  strAlmOut("");
			strAlmOut = tr("Out");
			strDigIOTitle += L" " + strAlmOut;
		} else if (usCHANNEL_CAPS == CHANNEL_CAP_DI)	// input only - not currently used
		{
			QString  strAlmIn("");
			strAlmIn = tr("In");
			strDigIOTitle += L" " + strAlmIn;
		} else	// input and output
		{
			QString  strAlmIO("");
			strAlmIO = tr("I/O");
			strDigIOTitle += L" " + strAlmIO;
		}
	}

	rstrTitle.asprintf(L"%s %d", strDigIOTitle, usDIGIO_NO);
	QString  strTempList("");
	rstrSubTitle = ptDigitalIOData->Label;
	rstrSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptDigitalIOData->Enabled) + L" " + rstrSubTitle;
	//rstrSubTitle += L", " + CStringUtils::GetItemAtPos( ms_strDigioIOTypeList, ptDigitalIOData->Type ) + L" ";
	rstrSubTitle += L", " + CStringUtils::GetItemAtPos(ms_strDigioIOPulseTypeList, ptDigitalIOData->Type) + L" ";

	//MarkD: if set to output, specify whether 24V or Power type
	if (ptDigitalIOData->Type == dtOutput) {
		QString  strRelay("");
		strRelay = tr("Relay");
		QString  strContactRating("");

		if (ucBOARD_TYPE == BOARD_DIO) {
			strContactRating = tr("24V");
		} else {
			strContactRating = tr("Power");
		}
		rstrSubTitle += strRelay + L" (" + strContactRating + L")";
	} else if (ptDigitalIOData->Type == dtPulseInput) {
		//MarkD: append (Hz)
		QString  strSubTitleHz("");
		strSubTitleHz = tr("Hz");
		rstrSubTitle += L" (" + strSubTitleHz + L")";
	}
}

//****************************************************************************
//	void GetDigitalIOChannelInfo(	const USHORT usDIGITAL_IO_NO,
//									USHORT &rusSlotNo,
//									USHORT &rusBoardChanNum,
//									const USHORT usCHANNEL_CAPS ) const
///
/// Method that obtains an Digital IO channel slot and board channel number
///
/// @param[in] 				const USHORT usDIGITAL_IO_NO - The digital number from 1 - 48
///	@param[out]				USHORT &rusSlotNo - The slot number from 1 - 3
///	@param[out]				USHORT &rusBoardChanNum - The board channel number from 0 - 15
/// @param[out]				USHORT &rusChannelCaps - Variable indicating the capabilites
///							of this digital channel
///
/// @return					True if this digital IO is valid
//****************************************************************************
bool CRecSetupCfgMgr::GetDigitalIOChannelInfo(const USHORT usDIGITAL_IO_NO,
USHORT &rusSlotNo,
USHORT &rusBoardChanNum,
USHORT &rusChannelCaps) const {
	bool bValid = false;
	CSlotMap *pkSlotMap = CSlotMap::GetHandle();

	// we need to get the slot and board channel number for all the digital inputs and check they are okay
	if (pkSlotMap->GetSlotAndChannelFromDigitalSysChan(usDIGITAL_IO_NO, rusSlotNo, rusBoardChanNum, ONE_BASED)) {
		// now confirm if this digital IO exists
		if ( DEVICE_INFO.IsValidDigIOChannel(static_cast< USHORT >(rusSlotNo),
				static_cast< USHORT >(rusBoardChanNum))) {
			bValid = true;
			rusChannelCaps = DEVICE_INFO.GetChannelCaps(rusSlotNo, rusBoardChanNum);
		} else if ( DEVICE_INFO.IsValidRelayOutputChannel(static_cast< USHORT >(rusSlotNo),
				static_cast< USHORT >(rusBoardChanNum))) {
			bValid = true;
			rusChannelCaps = DEVICE_INFO.GetChannelCaps(rusSlotNo, rusBoardChanNum);
		}
	}
	return bValid;
}
//****************************************************************************
// CConfigItem *RefreshPulseInConfigTree(	CConfigItem *pkModifiedItem,
//											const USHORT usPULSE_NO )
///
/// Method that refreshes the data for a pulse input branch of a pulse input configuration menu,
/// usually following a change that requires the tree structure to be regenerated because it is different
///
/// @param[in] 		CConfigItem *pkModifiedItem - A pointer to the item that has been modified - this will
///					be destroyed
/// @param[in] 		const USHORT usPULSE_IN_NO - The number of the pulse input that has changed (1 based)
///
/// @return			A pointer to the new config item (it will have the same key as the modified item)
///
//****************************************************************************
CConfigItem* CRecSetupCfgMgr::RefreshPulseInConfigTree(CConfigItem *pkModifiedItem, const USHORT usPULSE_IN_NO) {
	CConfigItem *pkNewCfgItem = NULL;
	CConfigInterface *pkTopParent = NULL;

	// Store the key name of this item
	const QString  strKEY(pkModifiedItem->GetKey());

	CConfigInterface *pkPulseInParent = pkModifiedItem;

	// get the top level parent
	while (pkPulseInParent->GetParent() != NULL) {
		pkPulseInParent = pkPulseInParent->GetParent();
	}
	pkTopParent = pkPulseInParent->GetParent();

	// Get the pen data structure
	T_PPULSECHANNEL ptPulseInData = NULL;

	CIOSetupConfig *pkPulseInSetupCfg = pSETUP->GetIOSetupConfig();

	USHORT usSlotNumber = 0;
	USHORT usBoardChanNumber = 0;

	if (GetPulseInputChannelInfo(usPULSE_IN_NO, usSlotNumber, usBoardChanNumber)) {
		if (pkPulseInSetupCfg != NULL) {
			ptPulseInData = pkPulseInSetupCfg->GetPulseInput(usSlotNumber, usBoardChanNumber, CONFIG_MODIFIABLE);
		}

		// Check we managed to obtain a pulse input
		if (ptPulseInData != NULL) {
			// recreate a pulse input branch for this item
			QString  strIndividualPulseInKey("");
			strIndividualPulseInKey.asprintf(L"%s%d", ms_strPULSE_IN_KEY, usPULSE_IN_NO);
			QString  strPulseInName("");
			QString  strPulseInTitle("");
			strPulseInTitle = tr("Pulse Input");
			strPulseInName.asprintf(L"%s %d", strPulseInTitle, usPULSE_IN_NO);
			QString  strTempList("");
			QString  strSubTitle(ptPulseInData->Label);
			strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptPulseInData->Enabled) + L" " + strSubTitle;
//			strSubTitle += L", " + CStringUtils::GetItemAtPos( ms_strPulseInMeasurementMethodList, ptPulseInData->FreqMeasure );

			CConfigBranch *pkNewPulseIn = new CConfigBranch(strIndividualPulseInKey, strPulseInName, strSubTitle,
					ctSubMenuButton, false, true, 0, false, pkPulseInParent);

			// setup the individual Pulse Input data
			SetupPulseInDetails(pkNewPulseIn, ptPulseInData, usSlotNumber, usBoardChanNumber);
			CConfigBranch *pkBranch = static_cast<CConfigBranch*>(pkPulseInParent);
			pkBranch->ReplaceChild(pkNewPulseIn);

			// we now need to get the new child for the particular item that was being modified
			pkNewCfgItem = static_cast<CConfigItem*>(indexOfChildByKey(strKEY, pkNewPulseIn, 2));
		}
	} else {
		// there has been a problem
		pkNewCfgItem = static_cast<CConfigItem*>(pkTopParent);
	}

	return pkNewCfgItem;
}
//****************************************************************************
//	void GetPulseInputChannelInfo(	const USHORT usPULSE_IN_NO,
//								USHORT &rusSlotNo,
//								USHORT &rusBoardChanNum ) const
///
/// Method that obtains a pulse input channel slot and board channel number
///
/// @param[in] 				const USHORT usPULSE_IN_NO - The pulse input number from 1 - 48 except 
///							we are not allowed 1-4, 9-12 etc because of the strange numbering system
//	@param[out]				USHORT &rusSlotNo - The slot number from 1 - 6
//	@param[out]				USHORT &rusBoardChanNum - The board channel number from 0 - 3
///
/// @return					True if this pulse input is valid
//****************************************************************************
bool CRecSetupCfgMgr::GetPulseInputChannelInfo(const USHORT usPULSE_IN_NO,
USHORT &rusSlotNo,
USHORT &rusBoardChanNum) const {
	bool bValid = false;
	CSlotMap *pkSlotMap = CSlotMap::GetHandle();

	// we need to get the slot and board channel number for all the pulse inputs and check they are okay
	if (pkSlotMap->GetSlotAndChannelFromDedicatedPulseSysChan(usPULSE_IN_NO, rusSlotNo, rusBoardChanNum, ONE_BASED)) {
		// now confirm if this pulse input exists
		if ( DEVICE_INFO.IsValidPulseInputChannel(static_cast< USHORT >(rusSlotNo),
				static_cast< USHORT >(rusBoardChanNum))) {
			bValid = true;
		}
	}
	return bValid;
}
//****************************************************************************
// void SetupDemoBoardDetails(	CConfigBranch *pkParent, 
//								const USHORT usSLOT_NO,
//								const USHORT usBOARD_CHAN_NO )
///
/// Method that sets up demo board details
///
/// @param[in] 		CConfigBranch *pkParent - A pointer to the parent the items must be added too
/// @param[in]		const USHORT usSLOT_NO - The slot number of the board
/// @param[in]		const USHORT usBOARD_CHAN_NO - THe board cahnnel number
/// @param[in]		const bool bENABLED - Flag indicating if this item is enabled or disabled
///
//****************************************************************************
void CRecSetupCfgMgr::SetupDemoBoardDetails(CConfigBranch *pkParent, const USHORT usSLOT_NO,
		const USHORT usBOARD_CHAN_NO, const bool bENABLED) {
	QString  strTitle("");
	QString  strSubTitle("");

	// Get the demo channel information
	CIOSetupConfig *pkIOSetupCfg = pSETUP->GetIOSetupConfig();
	T_PDEMOCHANNEL ptDemoChannel = pkIOSetupCfg->GetDemoChannel(usSLOT_NO, usBOARD_CHAN_NO, CONFIG_MODIFIABLE);

	// check the demo channel information is valid
	if (ptDemoChannel != NULL) {
		strTitle = tr("Demo Setup");
		CConfigBranch *pkDemoChannelParent = new CConfigBranch(ms_strDEMO_CHAN_KEY, strTitle, strSubTitle,
				ctSubMenuButton, false, bENABLED, 0, false, pkParent);
		pkParent->AddChild(pkDemoChannelParent);

		// Add the wave type field - this is a 6 bit bitfield although it is represented by a list
		CLongBitFieldData *pkWaveTypeData = new CLongBitFieldData(reinterpret_cast<ULONG*>(ptDemoChannel), 6, 0,
				ms_strDemoWaveTypeList, bfeSingleSelList, 0, 0, true);
		strSubTitle = pkWaveTypeData->GetDataAsString();
		strTitle = tr("Demo Type");
		CConfigItem *pkWaveType = new CConfigItem(ms_strDEMO_CHAN_WAVE_TYPE_KEY, strTitle, strSubTitle, ctItemButton,
				pkWaveTypeData, false, true, 0, false, pkDemoChannelParent);
		pkDemoChannelParent->AddChild(pkWaveType);

		// Add the wave duration - this is a 10 bit bitfield
		QString  strSecs("");
		strSecs = tr("Secs.");
		CLongBitFieldData *pkWaveDurData = new CLongBitFieldData(reinterpret_cast<ULONG*>(ptDemoChannel), 10, 6, NULL,
				bfeNumerical, 0, 0, true, dtLongBitField, false, 1, 1023, strSecs);
		strTitle = tr("Cycle Time");
		CConfigItem *pkWaveDur = new CConfigItem(ms_strDEMO_CHAN_WAVE_DUR_KEY, strTitle,
				pkWaveDurData->GetDataAsString(true), ctItemButton, pkWaveDurData, false, true, 0, false,
				pkDemoChannelParent);
		pkDemoChannelParent->AddChild(pkWaveDur);

		// Add the noise - this is a 6 bit bitfield
		CLongBitFieldData *pkNoiseData = new CLongBitFieldData(reinterpret_cast<ULONG*>(ptDemoChannel), 6, 16, NULL,
				bfeNumerical, 0, 0, true, dtLongBitField, false, 0, 63, L"%");
		strTitle = tr("Add Noise");
		CConfigItem *pkNoise = new CConfigItem(ms_strDEMO_CHAN_NOISE_KEY, strTitle, pkNoiseData->GetDataAsString(true),
				ctItemButton, pkNoiseData, false, true, 0, false, pkDemoChannelParent);
		pkDemoChannelParent->AddChild(pkNoise);

		// now setup the demo submenu button subtitle
		strSubTitle = pkWaveDurData->GetDataAsString(true);
		strSubTitle += L" ";
		strSubTitle += pkWaveTypeData->GetDataAsString();

		pkDemoChannelParent->SetSubTitle(strSubTitle);
	}
}
//****************************************************************************
// CConfigBranch *CreateEventsConfig( )
///
/// Method that creates an events config hierarchy
///
/// @return Pointer to the events config hierarchy
///
//****************************************************************************
CConfigBranch* CRecSetupCfgMgr::CreateEventsConfig() {
	CConfigBranch *pkEventParent = NULL;

	CEventSetupConfig *pkEventCfg = pSETUP->GetEventSetupConfig();
	T_PEVENTSYSTEM ptEventsSystem = pkEventCfg->GetEventBlock(CONFIG_MODIFIABLE);

	// update the group name list
	T_PGENERALCONFIG ptGeneralData = pSETUP->GetGeneralSetupConfig()->GetSystemGeneralBlock(CONFIG_MODIFIABLE);
	QString  strGroup("");

	// loop through the groups inserting their number and name
	ms_strGroupList = "";
	for (USHORT usGroupCount = 0; usGroupCount < GENERALCONFIG_GROUPNAME_SIZE; usGroupCount++) {
		strGroup.asprintf(L"%s|", ptGeneralData->GroupName[usGroupCount]);
		ms_strGroupList += strGroup;
	}

	// update the report name list
	T_PREPORTS ptReports = pSETUP->GetEventSetupConfig()->GetReportsBlock(CONFIG_MODIFIABLE);

	ms_strEventsEffectsReportNamesList = "";
	QString  strReportName("");
	for (USHORT usReportCount = 0; usReportCount < REPORTS_REPORT_SIZE; usReportCount++) {
		if (ptReports->Report[usReportCount].Enabled)	//&&
		// ALL REPORTS CAN NOW BE CONFIGURED BY AN EVENT IN ORDER TO SIMPLIFY THE REQUIREMENTS
		//( ptReports->Report[ usReportCount ].Trigger == rstEVENT ) )
		{
			strReportName.asprintf(L"%s%c%u%c%s", ptReports->Report[usReportCount].Tag, g_wcEMBEDDED_INFO_DELIM,
					usReportCount, g_wcEMBEDDED_INFO_DELIM, CStringUtils::ms_strDELIMITTER);
			ms_strEventsEffectsReportNamesList += strReportName;
		}
	}

	// get the external media options
	ms_strEventsEffectsPrintScreenExternalMediaList = CreateExportDevList(CONFIG_MODIFIABLE);

	if (ptEventsSystem != NULL) {
		// reset the event cause/effect subtype information
		for (USHORT usCount = 0; usCount < EVENTSYSTEM_EVENT_SIZE; usCount++) {
			for (USHORT usCauseCount = 0; usCauseCount < EVENT_CAUSE_SIZE; usCauseCount++) {
				m_usaEventCauseTypes[usCount][usCauseCount] = m_usEVENT_TYPE_NOT_INIT;
			}
			for (USHORT usEventCount = 0; usEventCount < EVENT_EFFECT_SIZE; usEventCount++) {
				m_usaEventEffectTypes[usCount][usEventCount] = m_usEVENT_TYPE_NOT_INIT;
			}
		}

		// get the latest screen list - do not include disabled screens and embed the screen ID's
		// This is required for the screen change event effect
		ms_strEventsEffectsScreenChangeScreenList = GetScreenList(false, true);

		// get the latest email templates list
		// erase the existing group list
		ms_strEventsEmailTemplateList = "";

		CSingleLock lock(&m_GlbSetupMutex);
		lock.Lock();
		CCommsSetupConfig *pkCommsConfig = pGlbSetup->GetCommsSetupConfig();
		lock.Unlock();
		T_PCOMMUNICATIONS ptCommsData = NULL;
		if (pkCommsConfig != NULL) {
			ptCommsData = pkCommsConfig->GetCommsBlock(CONFIG_MODIFIABLE);
		}

		if (ptCommsData != NULL) {
			T_EMAIL *ptEmail = &ptCommsData->Email;

			QString  strTemplate("");

			// loop through the templates inserting the subject lines
			for (USHORT usTemplateCount = 0; usTemplateCount < EMAIL_TEMPLATES_SIZE; usTemplateCount++) {
				// check there is some text in the subject line
				if (ptEmail->Templates[usTemplateCount] != '\0') {
					// insert the subject line
					strTemplate.asprintf(L"%s|", ptEmail->Templates[usTemplateCount]);
				} else {
					// subject is blank so insert the template numbre instead
					strTemplate.asprintf(IDS_CFG_EMAIL_IND_TEMPLATE_TITLE, usTemplateCount + 1);
				}

				ms_strEventsEmailTemplateList += strTemplate;
			}
		}

		// get the latest preset markers list
		CGeneralSetupConfig *pkGenCfg = pSETUP->GetGeneralSetupConfig();
		T_PGENERALCONFIG ptGenCfg = pkGenCfg->GetSystemGeneralBlock(CONFIG_MODIFIABLE);
		QString  strPresetMarkerText("");

		ms_strEventsEffectsMarkerPresetsList = "";
		for (USHORT usPresetMarkerCount = 0; usPresetMarkerCount < GENERALCONFIG_PRESETMARKERS_SIZE;
				usPresetMarkerCount++) {
			// marker 
			if (ptGenCfg->PresetMarkers[usPresetMarkerCount][0] != L'\0') {
				// get the text
				strPresetMarkerText.asprintf(L"%s%c%u%c%s", ptGenCfg->PresetMarkers[usPresetMarkerCount],
						g_wcEMBEDDED_INFO_DELIM, usPresetMarkerCount, g_wcEMBEDDED_INFO_DELIM,
						CStringUtils::ms_strDELIMITTER);
				// now add it to the list
				ms_strEventsEffectsMarkerPresetsList += strPresetMarkerText;
			}
		}

		QString  strTitle("");
		strTitle = tr("Events");
		QString  strSubTitle(strTitle);

		// Create the top level parent
		pkEventParent = new CConfigBranch(ms_strEVENTS_KEY, strTitle, strSubTitle, ctMainMenuButton, false, true, 0,
				false, NULL);

		// loop creating all the individual events
		for (USHORT usEventCount = 0; usEventCount < EVENTSYSTEM_EVENT_SIZE; usEventCount++) {
			QString  strKey("");
			strKey.asprintf(L"%s%d", ms_strEVENTS_KEY, usEventCount);

			// get the title and subtitle
			CreateEventTitles(&ptEventsSystem->Event[usEventCount], usEventCount, strTitle, strSubTitle);

			// create the individual event parent first
			CConfigBranch *pkNewEvent = new CConfigBranch(strKey, strTitle, strSubTitle, ctSubMenuButton, true, true, 0,
					false, pkEventParent);

			// now setup the event details
			SetupEventDetails(pkNewEvent, &ptEventsSystem->Event[usEventCount], usEventCount);

			pkEventParent->AddChild(pkNewEvent);
		}
	}

	return pkEventParent;
}
//****************************************************************************
// void SetupEventDetails( CConfigBranch *pkParent, T_EVENT *ptEvent, const USHORT usEVENT_NO )
///
/// Method that creates a single event config hierarchy
///
/// @param[in/out]			CConfigBranch *pkParent - The parent branch
///	@param[in]				T_EVENT *ptEvent - Pointer to the event data
///	@param[in]				const USHORT usEVENT_NO - The event no - zero based
///
//****************************************************************************
void CRecSetupCfgMgr::SetupEventDetails(CConfigBranch *pkParent, T_EVENT *ptEvent, const USHORT usEVENT_NO) {
	QString  strTitle("");
	QString  strSubTitle("");
	const bool bEVENT_ENABLED = (ptEvent->Enabled == TRUE);

	// Event enabled
	CShortBitFieldData *pkEnabledData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptEvent), 1, 0,
			ms_strEnabledList, bfeBool, 0, 0, true);

	strTitle = tr("Enabled");
	CConfigItem *pkEnabled = new CConfigItem(ms_strEVENTS_ENABLED_KEY, strTitle, pkEnabledData->GetDataAsString(),
			ctItemButton, pkEnabledData, false, true, 0, false, pkParent);
	pkParent->AddChild(pkEnabled);

	// Name - WCHAR edit
	QString   CfgData *pkTagData = new QString   CfgData(ptEvent->Name,
	EVENT_NAME_LEN, dtString, 0, 0, true);
	strTitle = tr("Tag");
	CConfigItem *pkTag = new CConfigItem(ms_strEVENTS_NAME_KEY, strTitle, pkTagData->GetDataAsString(), ctItemButton,
			pkTagData, false, bEVENT_ENABLED, 0, false, pkParent);
	pkParent->AddChild(pkTag);

	// create the event cause branch - count the number of causes enabled
	USHORT usCausesEnabled = 0;
	USHORT usCauseCount = 0;

	for (usCauseCount = 0; usCauseCount < EVENT_CAUSE_SIZE; usCauseCount++) {
		if (ptEvent->Cause[usCauseCount].Enabled) {
			++usCausesEnabled;
		}
	}

	strTitle = tr("Causes");
	strSubTitle.asprintf(IDS_CFG_EVENT_CAUSES_SUBTITLE, usCausesEnabled);
	CConfigBranch *pkEventCauseParent = new CConfigBranch(ms_strEVENTS_CAUSES_KEY, strTitle, strSubTitle,
			ctSubMenuButton, false, bEVENT_ENABLED, 0, false, pkParent);
	pkParent->AddChild(pkEventCauseParent);

	// add the causes
	for (usCauseCount = 0; usCauseCount < EVENT_CAUSE_SIZE; usCauseCount++) {
		// check if the subtype has changed
		if (m_usaEventCauseTypes[usEVENT_NO][usCauseCount] == m_usEVENT_TYPE_NOT_INIT) {
			// just update as this is the first time through
			m_usaEventCauseTypes[usEVENT_NO][usCauseCount] = ptEvent->Cause[usCauseCount].Type;
		} else {
			// up-to-date so now check if it has changed from its previous value
			if (m_usaEventCauseTypes[usEVENT_NO][usCauseCount] != ptEvent->Cause[usCauseCount].Type) {
				// erase the data fields
				ResetEventSelectionToNone(false, ptEvent->Cause[usCauseCount].Type, &ptEvent->Cause[usCauseCount].Data);

				// update with the latest type
				m_usaEventCauseTypes[usEVENT_NO][usCauseCount] = ptEvent->Cause[usCauseCount].Type;
			}
		}

		// setup the cause
		SetupEventCause(pkEventCauseParent, &ptEvent->Cause[usCauseCount], usCauseCount, (ptEvent->Enabled == TRUE));
	}

	// create the event effect branch
	USHORT usEffectsEnabled = 0;

	USHORT usEffectCount = 0;
	for (usEffectCount = 0; usEffectCount < EVENT_EFFECT_SIZE; usEffectCount++) {
		if (ptEvent->Effect[usEffectCount].Enabled) {
			++usEffectsEnabled;
		}
	}

	strTitle = tr("Effects");
	strSubTitle.asprintf(IDS_CFG_EVENT_EFFECTS_SUBTITLE, usEffectsEnabled);
	CConfigBranch *pkEventEffectParent = new CConfigBranch(ms_strEVENTS_EFFECTS_KEY, strTitle, strSubTitle,
			ctSubMenuButton, false, bEVENT_ENABLED, 0, false, pkParent);
	pkParent->AddChild(pkEventEffectParent);

	// add the effects
	for (usEffectCount = 0; usEffectCount < EVENT_EFFECT_SIZE; usEffectCount++) {
		// check if the subtype has changed
		if (m_usaEventEffectTypes[usEVENT_NO][usEffectCount] == m_usEVENT_TYPE_NOT_INIT) {
			// just update as this is the first time through
			m_usaEventEffectTypes[usEVENT_NO][usEffectCount] = ptEvent->Effect[usEffectCount].Type;
		} else {
			// up-to-date so now check if it has changed from its previous value
			if (m_usaEventEffectTypes[usEVENT_NO][usEffectCount] != ptEvent->Effect[usEffectCount].Type) {
				// erase the data fields
				ResetEventSelectionToNone(true, ptEvent->Effect[usEffectCount].Type,
						&ptEvent->Effect[usEffectCount].Data);

				// update with the latest type
				m_usaEventEffectTypes[usEVENT_NO][usEffectCount] = ptEvent->Effect[usEffectCount].Type;
			}
		}

		// setup the event effect
		SetupEventEffect(pkEventEffectParent, &ptEvent->Effect[usEffectCount], usEffectCount,
				(ptEvent->Enabled == TRUE), usEVENT_NO);
	}
}
//****************************************************************************
// void ResetEventSelectionToNone( const bool bEVENT_EFFECT, 
//									const USHORT usEVENT_TYPE,
//									T_PEVENTDATA ptEventData )
///
/// Method that resets the default selection for a single selection event picker back to 'None'
///
/// @param[in]			const bool bEVENT_EFFECT - True if this is an event effect, false if a cause
///	@param[in]			const USHORT usEVENT_TYPE - The current type of event - depends on the boolean above
///	@param[in/out]		T_PEVENTDATA ptEventData - Pointer to the event data we must reset
///
//****************************************************************************
void CRecSetupCfgMgr::ResetEventSelectionToNone(const bool bEVENT_EFFECT, const USHORT usEVENT_TYPE,
		T_PEVENTDATA ptEventData) {
	// check the event type first
	if (bEVENT_EFFECT) {
		switch (usEVENT_TYPE) {
		case eetCounters:
			// set to none by setting to a number outside of the possible counter values
			ptEventData->S[USER_COUNTER_NO] = COUNTERS_COUNTER_SIZE;
			break;
		case eetEmailEvent:
			// reset the data - as this is a single selection we will end up with
			// email template 1 and recipient 1 being chosen - these will always exist
			// so it is okay to leave these selected as the default
			memset(ptEventData, 0, sizeof(T_EVENTDATA));
			break;
		case eetScreenChange:
			// reset the data and leave as 0
			memset(ptEventData, 0, sizeof(T_EVENTDATA));
			break;
		case eetBatch:
			// reset the data and leave as 0 - e.g. Batch/Group 1
			memset(ptEventData, 0, sizeof(T_EVENTDATA));
			break;
		case eetSound:
			// there are always sounds in the system therefore reset - the default sound
			// will therefore become sound no 1 as the system is zero based
			memset(ptEventData, 0, sizeof(T_EVENTDATA));
			// set to play once
			ptEventData->S[EVENT_EFFECT_SOUND_PLAY_ONCE_INDEX] = spmSINGLE_SHOT;
			break;
		case eetDelayedEvent:
			// reset as these are multiple choice selections
			memset(ptEventData, 0, sizeof(T_EVENTDATA));
			// also make sure the delay time is set to a default of 10 seconds
			ptEventData->S[EVENT_EFFECT_DELAYED_EVENT_DELAY_TIME_USHORT_INDEX] = 10;
			break;
		case eetLogging:
		case eetTotaliser:
		case eetDigitalOutput:
		case eetMaxMins:
		case eetTimers:
			// reset as these are multiple choice selections
			memset(ptEventData, 0, sizeof(T_EVENTDATA));
			break;
		case eetMarkChart:
			// reset as these are two choices - use presets or user defined markers
			memset(ptEventData, 0, sizeof(T_EVENTDATA));
			break;
		case eetAlarmAck:
			// do nothing as this event uses a seperate structure
			break;
		case eetChartControl:
			// reset as the group selection type could end up out of bounds otherwise
			memset(ptEventData, 0, sizeof(T_EVENTDATA));
			break;
		case eetPrintScreen:
			// reset as the device and media types could end up out of bounds otherwise
			memset(ptEventData, 0, sizeof(T_EVENTDATA));
			break;
		case eetClearMessages:
			memset(ptEventData, 0, sizeof(T_EVENTDATA));
			break;
		case eetDisplayDialog:
			// reset as these are two choices - use presets or user defined
			memset(ptEventData, 0, sizeof(T_EVENTDATA));
			break;
		case eetReports:
			// reset to 0
			memset(ptEventData, 0, sizeof(T_EVENTDATA));
			break;
			//E528446
		case eetChartSpeed:
			// reset as these are three choices - 
			memset(ptEventData, 0, sizeof(T_EVENTDATA));
			break;
			//

		default:
			// do nothing
			break;
		}

	} else {
		// must be an event cause
		switch (usEVENT_TYPE) {

		case ectUserCounters:
			// set to none by setting to a number outside of the possible counter values
			ptEventData->S[USER_COUNTER_NO] = COUNTERS_COUNTER_SIZE;
			break;
		case ectAlarm:
			// do nothing as this event uses a seperate structure
			break;
		case ectTotaliser:
		case ectDigitalInput:
		case ectTCBurnOut:
		case ectMaxMins:
			// reset as these are multiple choice selections
			memset(ptEventData, 0, sizeof(T_EVENTDATA));
			break;
		case ectBatch:
			// reset the data and leave as 0 e.g. batch/group 1
			memset(ptEventData, 0, sizeof(T_EVENTDATA));
			break;
		case ectAMS2750Timers:
			// reset the data and leave as 0 e.g. warning messages
			memset(ptEventData, 0, sizeof(T_EVENTDATA));
			break;
		case ectTUS:
		case ectSystem:
		case ectUserAction:
			// do nothing as these items do not use the data structure
			break;
		case ectScheduledEvent:
			// do nothing as this event uses a seperate structure
		default:
			break;
		}
	}
}

// E528446

// E528446
// Fill the Chart Speed list
QString  CRecSetupCfgMgr::GetStripChartSpeed() {
	// Get chart Speed list (Fast|Medium|slow)
	QString  strCompleteSpeedList("");
	QString  strSpeedList("");
	strSpeedList = tr("Fast|Medium|Slow|");
	QString  strSpeedsAvailable("");
	T_PRECPROFILE ptProfile = NULL;
	ptProfile = pSETUP->GetGeneralSetupConfig()->GetProfileBlock(CONFIG_MODIFIABLE);

	if (!ptProfile)
		return strCompleteSpeedList;

	//Get active Screen number
	COpPanel *pOpPanel = NULL;
	USHORT usSCREEN_NO = 0;
	USHORT usChartIndex = 0;
	pOpPanel = reinterpret_cast<COpPanel*>(AfxGetApp()->m_pMainWnd);

	if (!pOpPanel)
		return strCompleteSpeedList;

	usSCREEN_NO = pOpPanel->m_pActiveScreen->m_pCMMscreen->Number - 1;

	for (int iCount = 0; iCount < NUM_CHART_SPEEDS; iCount++) {
		// get the start of the string
		strCompleteSpeedList += CStringUtils::GetItemAtPos(strSpeedList, iCount);
		strCompleteSpeedList += " (";

		switch (iCount) {
		case SPEED_FAST: {
			strSpeedsAvailable = tr("6000mm/h|1200mm/h|600mm/h|300mm/h|120mm/h|60mm/h|");
			const USHORT usMAX_SPEEDS = CStringUtils::InstanceOfStr(strSpeedsAvailable, L"|");
			if (ptProfile->Chart.FastSpeed > usMAX_SPEEDS) {
				ptProfile->Chart.FastSpeed = 0;
			}
			// add the current speed string
			strCompleteSpeedList += CStringUtils::GetItemAtPos(strSpeedsAvailable, ptProfile->Chart.FastSpeed);
		}
			break;

		case SPEED_MEDIUM: {
			strSpeedsAvailable = tr("120mm/h|60mm/h|30mm/h|20mm/h|10mm/h|");
			const USHORT usMAX_SPEEDS = CStringUtils::InstanceOfStr(strSpeedsAvailable, L"|");
			if (ptProfile->Chart.MedSpeed > usMAX_SPEEDS) {
				ptProfile->Chart.MedSpeed = 0;
			}
			// add the current speed string
			strCompleteSpeedList += CStringUtils::GetItemAtPos(strSpeedsAvailable, ptProfile->Chart.MedSpeed);
		}
			break;
		case SPEED_SLOW: {
			strSpeedsAvailable = tr("20mm/h©3©|10mm/h©0©|5mm/h©1©|1mm/h©2©|");
			const USHORT usMAX_SPEEDS = CStringUtils::InstanceOfStr(strSpeedsAvailable, L"|");
			if (ptProfile->Chart.SlowSpeed > usMAX_SPEEDS) {
				ptProfile->Chart.SlowSpeed = 0;
			}
			// add the current speed string
			strCompleteSpeedList += CStringUtils::GetItemAtNonSequentialPos(strSpeedsAvailable,
					ptProfile->Chart.SlowSpeed);
		}
			break;
		}

		// now add the delimitter
		strCompleteSpeedList += L")|";
	}

	return strCompleteSpeedList;
}

// Fill the Chart Speed list
void CRecSetupCfgMgr::LoadSubTypesAsPerTheChartSpeed(CConfigBranch *pkParent, T_PEVENTEFFECT &ptEffect) {
	// Add Chart speed data
	CShortBitFieldData *pkChartSpeedData = new CShortBitFieldData(
			&ptEffect->Data.S[SCREEN_EFFECT_CHART_SPEED]/*&usNewSpeed*/, 4, 0,
			ms_strEventsEffectChartspeedSubTypesList/*strCompleteSpeedList*/, bfeSingleSelList, 0, 0, false);

	QString  strSubTitle = pkChartSpeedData->GetDataAsString();
	QString  strTitle;
	strTitle = tr("Sub Type");
	CConfigItem *pkchartspeed = new CConfigItem(
			ms_strEventsEffectChartspeedSubTypesList/*L"changeChartspeed"*//*strCompleteSpeedList*/, strTitle,
			strSubTitle, ctItemButton, pkChartSpeedData, false, true, 0, false, pkParent);

	pkParent->AddChild(pkchartspeed);
}
//
//****************************************************************************
// void SetupEventCause(	CConfigBranch *pkParent, 
//							T_PEVENTCAUSE ptCause,
//							const USHORT usCAUSE_NO,
//							const bool bENABLED )
///
/// Method that creates a single cause config hierarchy
///
/// @param[in/out]			CConfigBranch *pkParent - The parent branch
///	@param[in]				T_PEVENTCAUSE ptCause - Pointer to the event cuase data
///	@param[in]				const USHORT usCAUSE_NO - The cause no - zero based
/// @param[in]				const bool bENABLED - Flag indicating if the event is enabled
///
//****************************************************************************
void CRecSetupCfgMgr::SetupEventCause(CConfigBranch *pkParent, T_PEVENTCAUSE ptCause, const USHORT usCAUSE_NO,
		const bool bENABLED) {
	QString  strasprintfCause("");
	strasprintfCause = tr("Cause %d");
	QString  strKey("");
	QString  strTitle("");
	QString  strSubTitle("");
	// create the individual cause branch first
	strKey.asprintf(L"%s%d", ms_strEVENTS_IND_CAUSE_KEY, usCAUSE_NO);

	strTitle.asprintf(strasprintfCause, usCAUSE_NO + 1);

	strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptCause->Enabled);

	if (ptCause->Enabled == TRUE) {
		// now add the correct type
		strSubTitle += CStringUtils::GetItemAtPos(ms_strEventsCauseTypesList, ptCause->Type);
	}

	CConfigBranch *pkCauseParent = new CConfigBranch(strKey, strTitle, strSubTitle, ctSubMenuButton, true, bENABLED, 0,
			false, pkParent);

	pkParent->AddChild(pkCauseParent);

	// now create the sub items
	// Event cause enabled
	CShortBitFieldData *pkEnCauseData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptCause), 1, 0,
			ms_strEnabledList, bfeBool, 0, 0, true);

	strTitle = tr("Enabled");
	CConfigItem *pkEnCause = new CConfigItem(ms_strEVENTS_CAUSE_ENABLED_KEY, strTitle, pkEnCauseData->GetDataAsString(),
			ctItemButton, pkEnCauseData, false, true, 0, false, pkCauseParent);
	pkCauseParent->AddChild(pkEnCause);

	// Cause Type - USHORT but treat as a btifield
	CShortBitFieldData *pkTypeData = new CShortBitFieldData(reinterpret_cast< USHORT*>(&ptCause->Type), 5, 0,
			ms_strEventsCauseTypesList, bfeSingleSelList, 0, 0, true);
	strTitle = tr("Type");
	CConfigItem *pkType = new CConfigItem(ms_strEVENTS_CAUSE_TYPE_KEY, strTitle, pkTypeData->GetDataAsString(),
			ctItemButton, pkTypeData, false, (ptCause->Enabled == TRUE), 0, false, pkCauseParent);
	pkCauseParent->AddChild(pkType);

	// Cause Sub Type - only show in certain cases
	CShortBitFieldData *pkSubTypeData = NULL;

	QString  strEventCauseUserActionSubTypeList;
#ifdef XSERIESSETUP
		strEventCauseUserActionSubTypeList = ms_strEventsCauseUserActionSubTypesList;
	#else
	const T_DEV_TYPE eDEV_TYPE = pDEVICE_INFO->GetDeviceType();
	switch (eDEV_TYPE) {
	//case for DEV_XS_MULTIPLUS and DEV_XS_MINITREND is fix for High par in TMS and it will not effect the firmware code.//Usha
	// Need to show 4 Hot button for SCR as it is having Multiscreen.
	case DEV_XS_MULTIPLUS:
	case DEV_ARISTOS_MULTIPLUS:
	case DEV_SCR_MINITREND:
		strEventCauseUserActionSubTypeList = ms_strEventsCauseUserActionSubTypesList;
		break;

	case DEV_XS_MINITREND:
	case DEV_ARISTOS_MINITREND:
		strEventCauseUserActionSubTypeList = ms_strEventsCauseUserActionSubTypesListQx;
		break;
	case DEV_ARISTOS_EZTREND: //ARISTOS QXe Device Type updates
	case DEV_XS_EZTREND:
		strEventCauseUserActionSubTypeList = ms_strEventsCauseUserActionSubTypesListEz;
		break;
	}
#endif

	switch (ptCause->Type) {
	case ectAlarm:
		pkSubTypeData = new CShortBitFieldData(reinterpret_cast< USHORT*>(&ptCause->SubType), 16, 0,
				ms_strEventsCauseAlarmSubTypesList, bfeSingleSelList, 0, 0, true);
		break;
	case ectTotaliser:
		pkSubTypeData = new CShortBitFieldData(reinterpret_cast< USHORT*>(&ptCause->SubType), 16, 0,
				ms_strEventsCauseTotaliserSubTypesList, bfeSingleSelList, 0, 0, false);
		break;
	case ectDigitalInput:
		pkSubTypeData = new CShortBitFieldData(reinterpret_cast< USHORT*>(&ptCause->SubType), 16, 0,
				ms_strEventsCauseDigInputsTypesList, bfeSingleSelList, 0, 0, false);
		break;
	case ectScheduledEvent:
		pkSubTypeData = new CShortBitFieldData(reinterpret_cast< USHORT*>(&ptCause->SubType), 16, 0,
				ms_strEventsCauseSchedEventTypesList, bfeSingleSelList, 0, 0, true);
		break;
	case ectSystem:
		pkSubTypeData = new CShortBitFieldData(reinterpret_cast< USHORT*>(&ptCause->SubType), 16, 0,
				ms_strEventsCauseSystemSubTypesList, bfeSingleSelList, 0, 0, true);
		break;
	case ectUserAction:
		pkSubTypeData = new CShortBitFieldData(reinterpret_cast< USHORT*>(&ptCause->SubType), 16, 0,
				strEventCauseUserActionSubTypeList, bfeSingleSelList, 0, 0, true);
		break;
	case ectBatch:
		pkSubTypeData = new CShortBitFieldData(&ptCause->SubType, 16, 0, ms_strEventsCauseBatchSubTypesList,
				bfeSingleSelList, 0, 0, false);
		break;
	case ectTUS:
		pkSubTypeData = new CShortBitFieldData(&ptCause->SubType, 16, 0, ms_strEventsCauseTUSSubTypesList,
				bfeSingleSelList, 0, 0, false);
		break;
	case ectAMS2750Timers:
		pkSubTypeData = new CShortBitFieldData(&ptCause->SubType, 16, 0, ms_strEventsCauseAMS2750TimersSubTypesList,
				bfeSingleSelList, 0, 0, false);
		break;
	case ectTCBurnOut:
	case ectMaxMins:
	case ectUserCounters:
	default:
		pkSubTypeData = NULL;
		break;
	}

	// only create the sub type if neccessary
	if (pkSubTypeData != NULL) {

		strTitle = tr("Sub Type");
		CConfigItem *pkSubType = new CConfigItem(ms_strEVENTS_CAUSE_SUBTYPE_KEY, strTitle,
				pkSubTypeData->GetDataAsString(), ctItemButton, pkSubTypeData, false, (ptCause->Enabled == TRUE), 0,
				false, pkCauseParent);
		pkCauseParent->AddChild(pkSubType);
	}

	// now create the relevant pickers

	switch (ptCause->Type) {
	case ectAlarm: {
		// add the pen picker first

		// check the pen picker does not exceed the maximum number of pens
		if (ptCause->AlarmData.PenNo > V6_MAX_PENS) {
			// reset back to pen 1
			ptCause->AlarmData.PenNo = 0;
		}

		// now add the pen and alarm pickers - check if an ack alarm in which case we must only show
		// latched alarms
		T_CFG_DATA_TYPE ePenCfgType = dtSinglePenAlarm;
		T_CFG_DATA_TYPE eAlarmCfgType = dtMultiAlarm;

		if (ptCause->SubType == evtCauseAlarmACK) {
			// only enable latched alarms if alarm ack
			ePenCfgType = dtSinglePenLatchedAlarm;
			eAlarmCfgType = dtMultiLatchedAlarm;
		}

		CPickerData *pkPenData = new CPickerData(&ptCause->AlarmData.PenNo, ePenCfgType, 0, 0, true, 1, 1);
		strTitle = tr("Pen");
		CConfigItem *pkPen = new CConfigItem(ms_strEVENTS_CAUSE_DATA_KEY, strTitle, pkPenData->GetDataAsString(),
				ctItemButton, pkPenData, false, (ptCause->Enabled == TRUE), 0, false, pkCauseParent);
		pkCauseParent->AddChild(pkPen);

		CPickerData *pkAlmData = new CPickerData(&ptCause->AlarmData.AlarmMask, eAlarmCfgType, 0, 0, false, 1,
				V6_MAX_ALARMS, ptCause->AlarmData.PenNo);
		strTitle = tr("Alarms");
		CConfigItem *pkAlm = new CConfigItem(ms_strEVENTS_CAUSE_ALARM_DATA_KEY, strTitle, pkAlmData->GetDataAsString(),
				ctItemButton, pkAlmData, false, (ptCause->Enabled == TRUE), 0, false, pkCauseParent);
		pkCauseParent->AddChild(pkAlm);
	}
		break;
	case ectTotaliser: {
		CPickerData *pkPenData = new CPickerData(reinterpret_cast< USHORT*>(&ptCause->Data), dtMultiPenTotaliser, 0, 0,
				false, 1, V6_MAX_PENS);
		strTitle = tr("Pens");
		CConfigItem *pkPen = new CConfigItem(ms_strEVENTS_CAUSE_DATA_KEY, strTitle, pkPenData->GetDataAsString(),
				ctItemButton, pkPenData, false, (ptCause->Enabled == TRUE), 0, false, pkCauseParent);
		pkCauseParent->AddChild(pkPen);
	}
		break;
	case ectDigitalInput: {
		CPickerData *pkDigData = new CPickerData(reinterpret_cast< USHORT*>(&ptCause->Data), dtMultiDigIn, 0, 0, false,
				1, MAX_DIGITAL_IO);
		strTitle = pkTypeData->GetDataAsString();
		CConfigItem *pkDig = new CConfigItem(ms_strEVENTS_CAUSE_DATA_KEY, strTitle, pkDigData->GetDataAsString(),
				ctItemButton, pkDigData, false, (ptCause->Enabled == TRUE), 0, false, pkCauseParent);
		pkCauseParent->AddChild(pkDig);
	}
		break;
	case ectTCBurnOut: {
		CPickerData *pkTCData = new CPickerData(reinterpret_cast< USHORT*>(&ptCause->Data), dtMultiAnalogueTCIn, 0, 0,
				false, 1, MAX_ANALOGUE_IN);
		strTitle = tr("Analog Inputs");
		CConfigItem *pkTC = new CConfigItem(ms_strEVENTS_CAUSE_DATA_KEY, strTitle, pkTCData->GetDataAsString(),
				ctItemButton, pkTCData, false, (ptCause->Enabled == TRUE), 0, false, pkCauseParent);
		pkCauseParent->AddChild(pkTC);
	}
		break;
	case ectScheduledEvent:
		// setup the scheduled event details
		SetupScheduledEvent(pkCauseParent, &ptCause->SchedEvent, static_cast<T_SCHED_EVENT_SUBTYPE>(ptCause->SubType),
				(ptCause->Enabled == TRUE));
		break;
	case ectUserCounters: {
		// setup the single instance user counter picker
		CPickerData *pkUserCounterData = new CPickerData(reinterpret_cast< USHORT*>(&ptCause->Data.S[USER_COUNTER_NO]),
				dtSingleUserCounters, 0, 0, false, 1, 1);
		strTitle = tr("User Counters");
		CConfigItem *pkUserCounter = new CConfigItem(ms_strEVENTS_CAUSE_DATA_KEY, strTitle,
				pkUserCounterData->GetDataAsString(), ctItemButton, pkUserCounterData, false,
				(ptCause->Enabled == TRUE) && ( pSYSTEM_INFO->FWOptionCountersAvailable() == TRUE), 0, false,
				pkCauseParent);
		pkCauseParent->AddChild(pkUserCounter);

		// show the trigger at data
		CFloatData *pkTriggerData = new CFloatData(&ptCause->TriggerAt, -V6_FLT_MAX, V6_FLT_MAX, 0, 0, false);
		strTitle = tr("Trigger At");
		CConfigItem *pkTrigger = new CConfigItem(ms_strEVENTS_CAUSE_COUNTER_TRIGGER_KEY, strTitle,
				pkTriggerData->GetDataAsString(), ctItemButton, pkTriggerData, false,
				(ptCause->Enabled == TRUE) && ( pSYSTEM_INFO->FWOptionCountersAvailable() == TRUE), 0, false,
				pkCauseParent);
		pkCauseParent->AddChild(pkTrigger);
	}
		break;
	case ectMaxMins: {
		CPickerData *pkPenData = new CPickerData(reinterpret_cast< USHORT*>(&ptCause->Data), dtMultiPen, 0, 0, false, 1,
				V6_MAX_PENS);
		strTitle = tr("Pens");
		CConfigItem *pkPen = new CConfigItem(ms_strEVENTS_CAUSE_DATA_KEY, strTitle, pkPenData->GetDataAsString(),
				ctItemButton, pkPenData, false, (ptCause->Enabled == TRUE), 0, false, pkCauseParent);
		pkCauseParent->AddChild(pkPen);
	}
		break;
	case ectBatch: {
		CShortBitFieldData *pkGrpData = new CShortBitFieldData(
				&ptCause->Data.S[MARKER_EVENT_CAUSE_GROUP_SEL_USHORT_INDEX], 16, 0, ms_strGroupList, bfeSingleSelList,
				0, 0, false);
		strTitle = tr("Group Name");
		CConfigItem *pkGroup = new CConfigItem(ms_strGROUP_KEY, strTitle, pkGrpData->GetDataAsString(), ctItemButton,
				pkGrpData, false, ( pSYSTEM_INFO->FWOptionBatchAvailable() == TRUE) && (ptCause->Enabled == TRUE), 0,
				false, pkCauseParent);
		pkCauseParent->AddChild(pkGroup);
	}
		break;
	case ectAMS2750Timers: {
		CShortBitFieldData *pkAlertTypeData = new CShortBitFieldData(
				&ptCause->Data.S[AMS2750_TIMER_CAUSE_ALERT_TYPE_USHORT_INDEX], 16, 0,
				ms_strEventsCauseAMS2750TimersAlertTypeList, bfeSingleSelList, 0, 0, false);
		strTitle = tr("Alert Type");
		CConfigItem *pkAlertType = new CConfigItem(ms_strEVENTS_CAUSE_DATA_KEY, strTitle,
				pkAlertTypeData->GetDataAsString(), ctItemButton, pkAlertTypeData, false, (ptCause->Enabled == TRUE), 0,
				false, pkCauseParent);
		pkCauseParent->AddChild(pkAlertType);
	}
		break;
	case ectTCHealthMonitor: {
		CPickerData *pkTCData = new CPickerData(reinterpret_cast< USHORT*>(&ptCause->Data), dtMultiAnalogueTCIn, 0, 0,
				false, 1, MAX_ANALOGUE_IN);
		strTitle = tr("Analog Inputs");
		CConfigItem *pkTC = new CConfigItem(ms_strEVENTS_CAUSE_DATA_KEY, strTitle, pkTCData->GetDataAsString(),
				ctItemButton, pkTCData, false, (ptCause->Enabled == TRUE), 0, false, pkCauseParent);
		pkCauseParent->AddChild(pkTC);
	}
		break;
	case ectTUS:
	default:
		break;
	}
}
//****************************************************************************
// void SetupScheduledEvent(	CConfigBranch *pkParent, 
//								T_SCHEDEVENTDATA *ptSchedData,
//								const T_SCHED_EVENT_SUBTYPE eSUB_TYPE,
//								const bool bENABLED )
///
/// Method that sets up the scheduled event details
///
/// @param[in/out]			CConfigBranch *pkParent - The parent branch
///	@param[in]				T_SCHEDEVENTDATA *ptSchedData - pointer to the schedule data
///	@param[in]				const T_SCHED_EVENT_SUBTYPE eSUB_TYPE - The schedule subtype
/// @param[in]				const bool bENABLED - Flag indicating if these items are enabled
///
//****************************************************************************
void CRecSetupCfgMgr::SetupScheduledEvent(CConfigBranch *pkParent, T_SCHEDEVENTDATA *ptSchedData,
		const T_SCHED_EVENT_SUBTYPE eSUB_TYPE, const bool bENABLED) {
	QString  strTitle("");

	// show the fields that are specific given the subtype
	switch (eSUB_TYPE) {
	case sesOnce: {
		// show a date/time field
		CULongData *pkDateTimeData = new CULongData(&ptSchedData->DateTime, 0, ULONG_MAX, 0, 0, false, dtDateTime);
		strTitle = tr("Date/Time");
		CConfigItem *pkDateTime = new CConfigItem(ms_strEVENTS_CAUSE_SCHED_DATE_TIME_KEY, strTitle,
				pkDateTimeData->GetDataAsString(), ctItemButton, pkDateTimeData, false, bENABLED, 0, false, pkParent);
		pkParent->AddChild(pkDateTime);
	}
		break;
	case sesInterval: {
		// show period
		CULongData *pkPeriodData = new CULongData(&ptSchedData->IntervalPeriod, 0, ULONG_MAX, 0, 0, false, dtInterval);
		strTitle = tr("Period");
		CConfigItem *pkPeriod = new CConfigItem(ms_strEVENTS_CAUSE_SCHED_PERIOD_KEY, strTitle,
				pkPeriodData->GetDataAsString(), ctItemButton, pkPeriodData, false, bENABLED, 0, false, pkParent);
		pkParent->AddChild(pkPeriod);

		// Alignment - this is a bitfield
		CShortBitFieldData *pkAlignData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptSchedData), 4, 0,
				ms_strEventsCauseSchedEventAlignList, bfeSingleSelList, 0, 0, false);

		strTitle = tr("Alignment");
		CConfigItem *pkAlign = new CConfigItem(ms_strEVENTS_CAUSE_SCHED_ALIGN_KEY, strTitle,
				pkAlignData->GetDataAsString(), ctItemButton, pkAlignData, false, bENABLED, 0, false, pkParent);
		pkParent->AddChild(pkAlign);

	}
		break;
	case sesSpecDays: {
		// show day of the week picker
		CPickerData *pkDOWData = new CPickerData(&ptSchedData->WeekDay, dtDaysOfTheWeek, 0, 0, false, 1, 7);
		strTitle = tr("Day(s) of Week");
		CConfigItem *pkDOW = new CConfigItem(ms_strEVENTS_CAUSE_SCHED_DOW_KEY, strTitle, pkDOWData->GetDataAsString(),
				ctItemButton, pkDOWData, false, bENABLED, 0, false, pkParent);
		pkParent->AddChild(pkDOW);

		// show a time data field
		CULongData *pkTimeData = new CULongData(&ptSchedData->DateTime, 0, ULONG_MAX, 0, 0, false, dtTimeOfDay);
		strTitle = tr("Time Of Day");
		CConfigItem *pkTime = new CConfigItem(ms_strEVENTS_CAUSE_SCHED_DATE_TIME_KEY, strTitle,
				pkTimeData->GetDataAsString(), ctItemButton, pkTimeData, false, bENABLED, 0, false, pkParent);
		pkParent->AddChild(pkTime);
	}
		break;
	case sesMonthEnd:
		// do nothing for this one - count is the only other variable but that is dealt with seperately
		break;
	default:
		break;
	}

	// show the count variable if this is not a do once@data/time event
	if (eSUB_TYPE != sesOnce) {
		CUShortData *pkCountData = new CUShortData(&ptSchedData->TriggerCount, 0, USHRT_MAX, 0, 0, true);
		// if the count is 0 then this actually means continuous or repeat - show this
		// text instead
		QString  strCount("");
		if (ptSchedData->TriggerCount == 0) {
			strCount = pkCountData->GetDataAsString() + L" (Repeat)";
		} else {
			strCount = pkCountData->GetDataAsString();
		}

		strTitle = tr("Count");
		CConfigItem *pkCount = new CConfigItem(ms_strEVENTS_CAUSE_SCHED_COUNT_KEY, strTitle, strCount, ctItemButton,
				pkCountData, false, bENABLED, 0, false, pkParent);
		pkParent->AddChild(pkCount);
	}
}
//****************************************************************************
// void SetupEventEffect(	CConfigBranch *pkParent, 
//							T_PEVENTEFFECT ptEffect,
//							const USHORT usEFFECT_NO,
//							const bool bENABLED,
//							const USHORT usEVENT_NO )
///
/// Method that creates a single effect config hierarchy
///
/// @param[in/out]			CConfigBranch *pkParent - The parent branch
///	@param[in]				T_PEVENTEFFECT ptEFFECT - Pointer to the event effect data
///	@param[in]				const USHORT usEFFECT_NO - The effect no - zero based
/// @param[in]				const bool bENABLED - Flag indicating if the event is enabled
/// @param[in]				const USHORT usEVENT_NO - The event number of this item
///
//****************************************************************************
void CRecSetupCfgMgr::SetupEventEffect(CConfigBranch *pkParent, T_PEVENTEFFECT ptEffect, const USHORT usEFFECT_NO,
		const bool bENABLED, const USHORT usEVENT_NO) {
	QString  strasprintfEffect("");
	strasprintfEffect = tr("Effect %d");
	QString  strKey("");
	QString  strTitle("");
	QString  strSubTitle("");
	// create the individual effect branch first
	strKey.asprintf(L"%s%d", ms_strEVENTS_IND_EFFECT_KEY, usEFFECT_NO);

	strTitle.asprintf(strasprintfEffect, usEFFECT_NO + 1);

	strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptEffect->Enabled);

	if (ptEffect->Enabled == TRUE) {
		// now add the correct type
		strSubTitle += CStringUtils::GetItemAtPos(ms_strEventsEffectsTypesList, ptEffect->Type);
	}

	CConfigBranch *pkEffectParent = new CConfigBranch(strKey, strTitle, strSubTitle, ctSubMenuButton, true, bENABLED, 0,
			false, pkParent);

	pkParent->AddChild(pkEffectParent);

	// now create the sub items
	// Event cause enabled
	CShortBitFieldData *pkEnEffectData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptEffect), 1, 0,
			ms_strEnabledList, bfeBool, 0, 0, true);

	strTitle = tr("Enabled");
	CConfigItem *pkEnEffect = new CConfigItem(ms_strEVENTS_EFFECT_ENABLED_KEY, strTitle,
			pkEnEffectData->GetDataAsString(), ctItemButton, pkEnEffectData, false, true, 0, false, pkEffectParent);
	pkEffectParent->AddChild(pkEnEffect);

	// Effect Type - USHORT but treat as a btifield
	CShortBitFieldData *pkTypeData = new CShortBitFieldData(reinterpret_cast< USHORT*>(&ptEffect->Type), 16, 0,
			ms_strEventsEffectsTypesList, bfeSingleSelList, 0, 0, true);
	strTitle = tr("Type");
	CConfigItem *pkType = new CConfigItem(ms_strEVENTS_EFFECT_TYPE_KEY, strTitle, pkTypeData->GetDataAsString(),
			ctItemButton, pkTypeData, false, (ptEffect->Enabled == TRUE), 0, false, pkEffectParent);
	pkEffectParent->AddChild(pkType);

	// Effect Sub Type - only show in certain cases
	CShortBitFieldData *pkSubTypeData = NULL;

	bool bSubTypeEnabled = (ptEffect->Enabled == TRUE);

	switch (ptEffect->Type) {
	case eetLogging:
		pkSubTypeData = new CShortBitFieldData(reinterpret_cast< USHORT*>(&ptEffect->SubType), 16, 0,
				ms_strEventsEffectsLoggingSubTypesList, bfeSingleSelList, 0, 0, false);
		break;
	case eetTotaliser:
		pkSubTypeData = new CShortBitFieldData(reinterpret_cast< USHORT*>(&ptEffect->SubType), 16, 0,
				ms_strEventsEffectsTotaliserSubTypesList, bfeSingleSelList, 0, 0, false);
		break;
	case eetDigitalOutput:
		pkSubTypeData = new CShortBitFieldData(reinterpret_cast< USHORT*>(&ptEffect->SubType), 16, 0,
				ms_strEventsEffectsDigOutputsSubTypesList, bfeSingleSelList, 0, 0, false);
		break;
	case eetEmailEvent:
		pkSubTypeData = new CShortBitFieldData(reinterpret_cast< USHORT*>(&ptEffect->SubType), 16, 0,
				ms_strEventsEffectsEmailSubTypesList, bfeSingleSelList, 0, 0, true);
		// check if the printing FW options is enabled
		bSubTypeEnabled = bSubTypeEnabled && ( pSYSTEM_INFO->FWOptionEmailAvailable() == TRUE);

		break;
	case eetCounters: {
		// check the counting firmware option is enabled
		bSubTypeEnabled = bSubTypeEnabled && ( pSYSTEM_INFO->FWOptionCountersAvailable() == TRUE);

		// check if increment is selected
		if (ptEffect->Data.S[RESET_OR_INC_COUNTER] == TRUE) {
			// increment is selected therefore ensure the current subtype is forced to be user counter
			ptEffect->SubType = ceeUSER;
		}

		// check if this is a counter event in which case we need the increment/reset field
		CShortBitFieldData *pkIncResetData = new CShortBitFieldData(
				reinterpret_cast< USHORT*>(&ptEffect->Data.S[RESET_OR_INC_COUNTER]), 1, 0,
				ms_strEventsEffectsCountersResetOrIncList, bfeSingleSelList, 0, 0, true);
		strTitle = tr("Event Action");
		CConfigItem *pkIncReset = new CConfigItem(ms_strEVENTS_EFFECT_COUNTER_RESET_OR_INC_KEY, strTitle,
				pkIncResetData->GetDataAsString(), ctItemButton, pkIncResetData, false, bSubTypeEnabled, 0, false,
				pkEffectParent);
		pkEffectParent->AddChild(pkIncReset);

		// now setup the subtype
		pkSubTypeData = new CShortBitFieldData(reinterpret_cast< USHORT*>(&ptEffect->SubType), 16, 0,
				ms_strEventsEffectsCountersSubTypesList, bfeSingleSelList, 0, 0, true);
	}
		break;
	case eetChartControl:
		pkSubTypeData = new CShortBitFieldData(reinterpret_cast< USHORT*>(&ptEffect->SubType), 16, 0,
				ms_strEventsEffectsChartControlSubTypeList, bfeSingleSelList, 0, 0, true);
		break;
	case eetTimers:
		pkSubTypeData = new CShortBitFieldData(reinterpret_cast< USHORT*>(&ptEffect->SubType), 16, 0,
				ms_strEventsEffectsTimersSubTypeList, bfeSingleSelList, 0, 0, false);
		break;
	case eetSound:
		pkSubTypeData = new CShortBitFieldData(reinterpret_cast< USHORT*>(&ptEffect->SubType), 16, 0,
				ms_strEventsEffectsSoundSubTypeList, bfeSingleSelList, 0, 0, true);
		break;
	case eetMarkChart:
	case eetDisplayDialog:
		/// Show the marker mode
		pkSubTypeData = new CShortBitFieldData(&ptEffect->SubType, 16, 0, ms_strEventsEffectsMarkerModeList,
				bfeSingleSelList, 0, 0, true);
		break;
	case eetBatch:
		pkSubTypeData = new CShortBitFieldData(&ptEffect->SubType, 16, 0, ms_strEventsEffectsBatchSubTypeList,
				bfeSingleSelList, 0, 0, false);
		break;
	case eetPrintScreen:
		pkSubTypeData = new CShortBitFieldData(&ptEffect->SubType, 16, 0, ms_strEventsEffectsPrintScreenSubTypeList,
				bfeSingleSelList, 0, 0, true);
		break;
	case eetScreenChange:
		pkSubTypeData = new CShortBitFieldData(&ptEffect->SubType, 16, 0, ms_strEventsEffectsScreenSubTypeList,
				bfeSingleSelList, 0, 0, true);
		break;

		// E528446
		// Sub Type data for Chart speed
	case eetChartSpeed:
		ms_strEventsEffectChartspeedSubTypesList = GetStripChartSpeed();
		break;
	case eetAlarmAck:
	case eetMaxMins:
	case eetClearMessages:
	case eetDelayedEvent:
	case eetReports:
	case eetEnterReplayScreen:
	case eetExitReplayScreen:
	default:
		// no subtype so do nothing here
		pkSubTypeData = NULL;
		break;
	}

	// only create the sub type if neccessary
	if (pkSubTypeData != NULL) {
		// check if chart control
		if ((ptEffect->Type != eetChartControl) && (ptEffect->Type != eetMarkChart)
				&& (ptEffect->Type != eetDisplayDialog)) {
			// not chart control so load the generic sub type title
			strTitle = tr("Sub Type");
		} else if (ptEffect->Type == eetMarkChart) {
			strTitle = tr("Marker Type");
		} else if (ptEffect->Type == eetDisplayDialog) {
			strTitle = tr("Message Type");
		} else {
			// chart control so load the specific sub type string
			strTitle = tr("Chart Action");
		}

		// check if the type is counter and increment is selected
		if ((ptEffect->Type == eetCounters) && (ptEffect->Data.S[RESET_OR_INC_COUNTER] == TRUE)) {
			// disable the control always so it is always locked at user 
			CConfigItem *pkSubType = new CConfigItem(ms_strEVENTS_EFFECT_SUBTYPE_KEY, strTitle,
					pkSubTypeData->GetDataAsString(), ctItemButton, pkSubTypeData, false, false, 0, false,
					pkEffectParent);
			pkEffectParent->AddChild(pkSubType);
		} else {
			CConfigItem *pkSubType = new CConfigItem(ms_strEVENTS_EFFECT_SUBTYPE_KEY, strTitle,
					pkSubTypeData->GetDataAsString(), ctItemButton, pkSubTypeData, false, bSubTypeEnabled, 0, false,
					pkEffectParent);
			pkEffectParent->AddChild(pkSubType);
		}
	}
	// show the pen selection type for all relevant event effects
	if ((ptEffect->Type == eetLogging) || (ptEffect->Type == eetTotaliser) || (ptEffect->Type == eetAlarmAck)
			|| (ptEffect->Type == eetMaxMins)) {
		CShortBitFieldData *pkPenSelTypeData = NULL;
		if (ptEffect->Type != eetAlarmAck) {
			pkPenSelTypeData = new CShortBitFieldData(
					reinterpret_cast< USHORT*>(&ptEffect->Data.S[MARKER_EVENT_EFFECT_PEN_SEL_TYPE_USHORT_INDEX]), 16, 0,
					ms_strEventsEffectsPenSelTypesList, bfeSingleSelList, 0, 0, true);
		} else {
			pkPenSelTypeData = new CShortBitFieldData(
					reinterpret_cast< USHORT*>(&ptEffect->Data.S[MARKER_EVENT_EFFECT_PEN_SEL_TYPE_USHORT_INDEX]), 16, 0,
					ms_strEventsEffectsAlarmSelTypesList, bfeSingleSelList, 0, 0, true);
		}
		strTitle = tr("Selection Type");

		CConfigItem *pkPenSelType = new CConfigItem(ms_strEVENTS_EFFECT_PEN_SEL_TYPE_KEY, strTitle,
				pkPenSelTypeData->GetDataAsString(), ctItemButton, pkPenSelTypeData, false, (ptEffect->Enabled == TRUE),
				0, false, pkEffectParent);
		pkEffectParent->AddChild(pkPenSelType);
	}

	// now create the relevant pickers or string editor in the case of mark chart
	switch (ptEffect->Type) {
	case eetAlarmAck: {
		// add the pen picker first
		if (ptEffect->Data.S[MARKER_EVENT_EFFECT_PEN_SEL_TYPE_USHORT_INDEX] == epsINDIVIDUAL_SELS) {
			// check the pen picker does not exceed the maximum number of pens
			if (ptEffect->AlarmData.PenNo > V6_MAX_PENS) {
				// reset back to pen 1
				ptEffect->AlarmData.PenNo = 0;
			}

			CPickerData *pkPenData = new CPickerData(&ptEffect->AlarmData.PenNo, dtSinglePenLatchedAlarm, 0, 0, true, 1,
					1);
			strTitle = tr("Pen");
			CConfigItem *pkPen = new CConfigItem(ms_strEVENTS_EFFECT_DATA_KEY, strTitle, pkPenData->GetDataAsString(),
					ctItemButton, pkPenData, false, (ptEffect->Enabled == TRUE), 0, false, pkEffectParent);
			pkEffectParent->AddChild(pkPen);

			// now add the alarm picker
			CPickerData *pkAlmData = new CPickerData(&ptEffect->AlarmData.AlarmMask, dtMultiLatchedAlarm, 0, 0, false,
					1, V6_MAX_ALARMS, ptEffect->AlarmData.PenNo);
			strTitle = tr("Alarms");
			CConfigItem *pkAlm = new CConfigItem(ms_strEVENTS_EFFECT_ALARM_DATA_KEY, strTitle,
					pkAlmData->GetDataAsString(), ctItemButton, pkAlmData, false, (ptEffect->Enabled == TRUE), 0, false,
					pkEffectParent);
			pkEffectParent->AddChild(pkAlm);
		} else if (ptEffect->Data.S[MARKER_EVENT_EFFECT_PEN_SEL_TYPE_USHORT_INDEX] == epsPEN_GROUP) {
			CShortBitFieldData *pkGrpData = new CShortBitFieldData(
					&ptEffect->Data.S[MARKER_EVENT_EFFECT_GROUP_SEL_USHORT_INDEX], 16, 0, ms_strGroupList,
					bfeSingleSelList, 0, 0, false);
			strTitle = tr("Group Name");
			CConfigItem *pkGroup = new CConfigItem(ms_strEVENTS_EFFECT_GROUP_SEL_KEY, strTitle,
					pkGrpData->GetDataAsString(), ctItemButton, pkGrpData, false,
					( pSYSTEM_INFO->FWOptionBatchAvailable() == TRUE) && (ptEffect->Enabled == TRUE), 0, false,
					pkEffectParent);
			pkEffectParent->AddChild(pkGroup);
		} else {
			// must be all therefore do nothing
		}
	}
		break;
	case eetTotaliser:
	case eetLogging:
	case eetMaxMins: {
		if (ptEffect->Data.S[MARKER_EVENT_EFFECT_PEN_SEL_TYPE_USHORT_INDEX] == epsINDIVIDUAL_SELS) {
			T_CFG_DATA_TYPE eCfgType = dtMultiPen;
			if (ptEffect->Type == eetLogging) {
				eCfgType = dtMultiPenLogging;
			} else if (ptEffect->Type == eetTotaliser) {
				eCfgType = dtMultiPenTotaliser;
			}

			CPickerData *pkPenData = new CPickerData(reinterpret_cast< USHORT*>(&ptEffect->Data), eCfgType, 0, 0, false,
					1, V6_MAX_PENS);
			strTitle = tr("Pens");
			CConfigItem *pkPen = new CConfigItem(ms_strEVENTS_EFFECT_DATA_KEY, strTitle, pkPenData->GetDataAsString(),
					ctItemButton, pkPenData, false, (ptEffect->Enabled == TRUE), 0, false, pkEffectParent);
			pkEffectParent->AddChild(pkPen);
		} else if (ptEffect->Data.S[MARKER_EVENT_EFFECT_PEN_SEL_TYPE_USHORT_INDEX] == epsPEN_GROUP) {
			CShortBitFieldData *pkGrpData = new CShortBitFieldData(
					&ptEffect->Data.S[MARKER_EVENT_EFFECT_GROUP_SEL_USHORT_INDEX], 16, 0, ms_strGroupList,
					bfeSingleSelList, 0, 0, false);
			strTitle = tr("Group Name");
			CConfigItem *pkGroup = new CConfigItem(ms_strEVENTS_EFFECT_GROUP_SEL_KEY, strTitle,
					pkGrpData->GetDataAsString(), ctItemButton, pkGrpData, false,
					( pSYSTEM_INFO->FWOptionBatchAvailable() == TRUE) && (ptEffect->Enabled == TRUE), 0, false,
					pkEffectParent);
			pkEffectParent->AddChild(pkGroup);
		} else {
			// must be all therefore do nothing
		}
	}
		break;
	case eetDigitalOutput: {
		CPickerData *pkDigData = new CPickerData(reinterpret_cast< USHORT*>(&ptEffect->Data), dtMultiRelayOut, 0, 0,
				false, 1, MAX_DIGITAL_IO + 1);
		strTitle = pkTypeData->GetDataAsString();
		CConfigItem *pkDig = new CConfigItem(ms_strEVENTS_EFFECT_DATA_KEY, strTitle, pkDigData->GetDataAsString(),
				ctItemButton, pkDigData, false, (ptEffect->Enabled == TRUE), 0, false, pkEffectParent);
		pkEffectParent->AddChild(pkDig);
	}
		break;
	case eetDisplayDialog:
	case eetMarkChart: {
		// either show the marker text entry or the preset list depending on the mode
		if (ptEffect->SubType == mcmUSER_DEFINED) {
			// Mark chart - WCHAR edit field
			QString   CfgData *pkMarkChartData = new QString   CfgData(ptEffect->Mark,
			EVENTEFFECT_MARK_LEN, dtString, 0, 0, false);

			CConfigItem *pkMarkChart = NULL;
			if (ptEffect->Type == eetDisplayDialog) {
				strTitle = tr("Message Text");

				pkMarkChart = new CConfigItem(ms_strEVENTS_EFFECT_DISPLAY_EVENT_KEY, strTitle,
						pkMarkChartData->GetDataAsString(), ctItemButton, pkMarkChartData, false, bSubTypeEnabled, 0,
						false, pkEffectParent);
			} else {
				strTitle = tr("Mark Chart Text");
				pkMarkChart = new CConfigItem(ms_strEVENTS_EFFECT_MARK_CHART_KEY, strTitle,
						pkMarkChartData->GetDataAsString(), ctItemButton, pkMarkChartData, false, bSubTypeEnabled, 0,
						false, pkEffectParent);
			}

			pkEffectParent->AddChild(pkMarkChart);
		} else {
			CShortBitFieldData *pkPresetData = new CShortBitFieldData(
					reinterpret_cast< USHORT*>(&ptEffect->Data.S[MARKER_EVENT_CAUSE_PRESET_SEL_INDEX]), 5, 0,
					ms_strEventsEffectsMarkerPresetsList, bfeSingleSelList, 0, 0, false);
			strTitle = tr("Preset Text");

			CConfigItem *pkPreset = NULL;
			if (ptEffect->Type == eetDisplayDialog) {
				pkPreset = new CConfigItem(ms_strEVENTS_EFFECT_DISPLAY_EVENT_KEY, strTitle,
						pkPresetData->GetDataAsString(), ctItemButton, pkPresetData, false, bSubTypeEnabled, 0, false,
						pkEffectParent);
			} else {
				pkPreset = new CConfigItem(ms_strEVENTS_EFFECT_MARKER_PRESET_SEL_KEY, strTitle,
						pkPresetData->GetDataAsString(), ctItemButton, pkPresetData, false, bSubTypeEnabled, 0, false,
						pkEffectParent);
			}

			pkEffectParent->AddChild(pkPreset);

		}
	}
		break;
	case eetEmailEvent: {
		// firstly come up with the list of email recipients
		QString  strTitle("");
		strTitle = tr("Recipients");

		CPickerData *pkEmailRecipientsData = new CPickerData(
				reinterpret_cast< USHORT*>(&ptEffect->Data.L[EMAIL_EFFECT_RECIPIENTS_INDEX_NUMBER]), dtEmailRecipients,
				0, 0, false, 1,
				EMAIL_EMAILADDRESSES_SIZE);

		CConfigItem *pkEmailRecipients = new CConfigItem(ms_strEVENTS_EFFECT_EMAIL_RECIPIENTS_KEY, strTitle,
				pkEmailRecipientsData->GetDataAsString(), ctItemButton, pkEmailRecipientsData, false, bSubTypeEnabled,
				0, false, pkEffectParent);
		pkEffectParent->AddChild(pkEmailRecipients);

		// add the embed screen shot option
		CShortBitFieldData *pkEmbedScreenShotData = new CShortBitFieldData(
				reinterpret_cast< USHORT*>(&ptEffect->Data.S[EMAIL_EFFECT_ATTACH_SCREENSHOT]), 16, 0, ms_strEnabledList,
				bfeBool, 0, 0, false);
		strTitle = tr("Embed Screenshot");
		CConfigItem *pkEmbedScreenShot = new CConfigItem(ms_strEVENTS_EFFECT_EMAIL_EMBED_SCREENSHOT_KEY, strTitle,
				pkEmbedScreenShotData->GetDataAsString(), ctItemButton, pkEmbedScreenShotData, false, bSubTypeEnabled,
				0, false, pkEffectParent);
		pkEffectParent->AddChild(pkEmbedScreenShot);

		// only do this next operation if single or multi line user defined message - auto does
		// not require any additional fields
		if (ptEffect->SubType == eeeSINGLE_LINE_USER) {
			// Single line user define email (reuse the mark chart field) - WCHAR edit field
			QString   CfgData *pkMarkChartData = new QString   CfgData(ptEffect->Mark,
			EVENTEFFECT_MARK_LEN, dtString, 0, 0, false);
			strTitle = tr("Email Text");
			CConfigItem *pkMarkChart = new CConfigItem(ms_strEVENTS_EFFECT_EMAIL_MESSAGE_KEY, strTitle,
					pkMarkChartData->GetDataAsString(), ctItemButton, pkMarkChartData, false, bSubTypeEnabled, 0, false,
					pkEffectParent);
			pkEffectParent->AddChild(pkMarkChart);
		} else if (ptEffect->SubType == eeeMULTI_LINE_USER) {
			// Multi line user defined email - show a single selection list
			CShortBitFieldData *pkEmailTemplatesData = new CShortBitFieldData(
					reinterpret_cast< USHORT*>(&ptEffect->Data.S[EMAIL_EFFECT_TEMPLATES_INDEX_NUMBER]), 16, 0,
					ms_strEventsEmailTemplateList, bfeSingleSelList, 0, 0, false);

			strTitle = tr("Email Template");
			CConfigItem *pkEmailTemplates = new CConfigItem(ms_strEVENTS_EFFECT_EMAIL_MESSAGE_KEY, strTitle,
					pkEmailTemplatesData->GetDataAsString(), ctItemButton, pkEmailTemplatesData, false, bSubTypeEnabled,
					0, false, pkEffectParent);
			pkEffectParent->AddChild(pkEmailTemplates);

		}
	}
		break;
	case eetScreenChange: {
		if (ptEffect->SubType == seeCHANGE_SCREEN) {
			// needs a screen picker
			CShortBitFieldData *pkChangeScreenData = new CShortBitFieldData(
					reinterpret_cast< USHORT*>(&ptEffect->Data.S[SCREEN_EFFECT_CHANGE_SCREEN_INDEX_NO]), 6, 0,
					ms_strEventsEffectsScreenChangeScreenList, bfeSingleSelList, 0, 0, false);

			strTitle = tr("Screen Name");
			CConfigItem *pkChangeScreen = new CConfigItem(ms_strEVENTS_EFFECT_SCREEN_NAME_KEY, strTitle,
					pkChangeScreenData->GetDataAsString(), ctItemButton, pkChangeScreenData, false,
					(ptEffect->Enabled == TRUE), 0, false, pkEffectParent);
			pkEffectParent->AddChild(pkChangeScreen);
		} else {
			// backlight on/off - needs a on/off boolean
			CShortBitFieldData *pkBacklightData = new CShortBitFieldData(
					&ptEffect->Data.S[SCREEN_EFFECT_BACKLIGHT_ON_OFF_STATE], 16, 0,
					ms_strEventsEffectsScreenBacklightOnOffList, bfeBool, 0, 0, false);
			strTitle = tr("Backlight");
			CConfigItem *pkBacklight = new CConfigItem(ms_strEVENTS_EFFECT_SCREEN_BACKLIGHT_ON_OFF_KEY, strTitle,
					pkBacklightData->GetDataAsString(), ctItemButton, pkBacklightData, false,
					(ptEffect->Enabled == TRUE), 0, false, pkEffectParent);
			pkEffectParent->AddChild(pkBacklight);
		}
	}
		break;
	case eetPrintScreen: {
		// check if the subtype is external device in which case we need to show the media options
		if (ptEffect->SubType == pceEXTERNAL_MEDIA) {
			// Print screen export device
			CShortBitFieldData *pkExternalMediaData = new CShortBitFieldData(
					&ptEffect->Data.S[PRINT_SCREENSHOT_EFFECT_EXT_MEDIA_USHORT_INDEX], 16, 0,
					ms_strEventsEffectsPrintScreenExternalMediaList, bfeSingleSelList, 0, 0, false);
			strTitle = tr("Export Device");
			CConfigItem *pkExternalMedia = new CConfigItem(ms_strEVENTS_EFFECT_PRINT_SCREEN_EXTERNAL_MEDIA_KEY,
					strTitle, pkExternalMediaData->GetDataAsString(), ctItemButton, pkExternalMediaData, false,
					(ptEffect->Enabled == TRUE), 0, false, pkEffectParent);
			pkEffectParent->AddChild(pkExternalMedia);
		}
	}
		break;
	case eetCounters:
		SetupCounterEffects(pkEffectParent, ptEffect, pkSubTypeData->GetDataAsString());
		break;
	case eetDelayedEvent: {
		// setup the multiple instance event picker
		CPickerData *pkEventPickerData = new CPickerData(reinterpret_cast< USHORT*>(&ptEffect->Data), dtMultiEvent, 0,
				0, false, 1,
				EVENTSYSTEM_EVENT_SIZE, usEVENT_NO);
		strTitle = tr("Events");
		CConfigItem *pkEventPicker = new CConfigItem(ms_strEVENTS_EFFECT_DATA_KEY, strTitle,
				pkEventPickerData->GetDataAsString(), ctItemButton, pkEventPickerData, false,
				(ptEffect->Enabled == TRUE), 0, false, pkEffectParent);
		pkEffectParent->AddChild(pkEventPicker);

		QString  strSeconds("");
		strSeconds = tr("Secs.");

		// now add the delay time
		CUShortData *pkDelayTimeData = new CUShortData(
				&ptEffect->Data.S[EVENT_EFFECT_DELAYED_EVENT_DELAY_TIME_USHORT_INDEX], 1, 3600, 0, 0, false,
				dtUnsignedShort, strSeconds);

		strTitle = tr("Delay Time");
		CConfigItem *pkDelayTime = new CConfigItem(ms_strEVENTS_EFFECT_DELAYED_EVENT_DELAY_TIME_KEY, strTitle,
				pkDelayTimeData->GetDataAsString(true), ctItemButton, pkDelayTimeData, false,
				(ptEffect->Enabled == TRUE), 0, false, pkEffectParent);
		pkEffectParent->AddChild(pkDelayTime);
	}
		break;
	case eetTimers: {
		// setup the multiple instance timer picker
		CPickerData *pkTimerPickerData = new CPickerData(reinterpret_cast< USHORT*>(&ptEffect->Data), dtMultipleTimers,
				0, 0, false, 1, MAX_SCRIPT_TIMERS);
		strTitle = tr("Timers");
		CConfigItem *pkTimerPicker = new CConfigItem(ms_strEVENTS_EFFECT_DATA_KEY, strTitle,
				pkTimerPickerData->GetDataAsString(), ctItemButton, pkTimerPickerData, false,
				(ptEffect->Enabled == TRUE), 0, false, pkEffectParent);
		pkEffectParent->AddChild(pkTimerPicker);
	}
		break;
	case eetSound:
		if (ptEffect->SubType == sndSTART_SOUND) {
			// give the user the choice of the various sounds
			CShortBitFieldData *pkSoundData = new CShortBitFieldData(&ptEffect->Data.S[EVENT_EFFECT_SOUND_USHORT_INDEX],
					16, 0, ms_strSoundList, bfeSingleSelList, 0, 0, false);
			strTitle = tr("Sound Name");
			CConfigItem *pkSound = new CConfigItem(ms_strEVENTS_EFFECT_DATA_KEY, strTitle,
					pkSoundData->GetDataAsString(), ctItemButton, pkSoundData, false, (ptEffect->Enabled == TRUE), 0,
					false, pkEffectParent);
			pkEffectParent->AddChild(pkSound);

			// select whether to play once or continuously
			CShortBitFieldData *pkPlayModeData = new CShortBitFieldData(
					&ptEffect->Data.S[EVENT_EFFECT_SOUND_PLAY_ONCE_INDEX], 16, 0, ms_strEventsEffectsSoundPlayModeList,
					bfeSingleSelList, 0, 0, false);

			strTitle = tr("Play Mode");
			CConfigItem *pkPlayMode = new CConfigItem(ms_strEVENTS_EFFECT_SOUND_PLAY_MODE_KEY, strTitle,
					pkPlayModeData->GetDataAsString(), ctItemButton, pkPlayModeData, false, (ptEffect->Enabled == TRUE),
					0, false, pkEffectParent);
			pkEffectParent->AddChild(pkPlayMode);
		}
		break;
	case eetBatch: {
		CShortBitFieldData *pkGrpData = new CShortBitFieldData(
				&ptEffect->Data.S[MARKER_EVENT_EFFECT_GROUP_SEL_USHORT_INDEX], 16, 0, ms_strGroupList, bfeSingleSelList,
				0, 0, false);
		strTitle = tr("Group Name");
		CConfigItem *pkGroup = new CConfigItem(ms_strEVENTS_EFFECT_GROUP_SEL_KEY, strTitle,
				pkGrpData->GetDataAsString(), ctItemButton, pkGrpData, false,
				( pSYSTEM_INFO->FWOptionBatchAvailable() == TRUE) && (ptEffect->Enabled == TRUE), 0, false,
				pkEffectParent);
		pkEffectParent->AddChild(pkGroup);
	}
		break;
	case eetChartControl:
		// only show these next field is this is a pause or resume command
		if ((ptEffect->SubType == ccePAUSE) || (ptEffect->SubType == cceRESUME)) {
			CShortBitFieldData *pkSelTypeData = new CShortBitFieldData(
					reinterpret_cast< USHORT*>(&ptEffect->Data.S[MARKER_EVENT_EFFECT_PEN_SEL_TYPE_USHORT_INDEX]), 16, 0,
					ms_strEventsEffectsChartControlSelTypesList, bfeSingleSelList, 0, 0, true);
			strTitle = tr("Selection Type");

			CConfigItem *pkSelType = new CConfigItem(ms_strEVENTS_EFFECT_PEN_SEL_TYPE_KEY, strTitle,
					pkSelTypeData->GetDataAsString(), ctItemButton, pkSelTypeData, false, (ptEffect->Enabled == TRUE),
					0, false, pkEffectParent);
			pkEffectParent->AddChild(pkSelType);

			if (ptEffect->Data.S[MARKER_EVENT_EFFECT_CHART_CONTROL_GROUP_SEL_USHORT_INDEX] == ecgINDIVIDUAL_GROUP) {
				CShortBitFieldData *pkGrpData = new CShortBitFieldData(
						&ptEffect->Data.S[MARKER_EVENT_EFFECT_GROUP_SEL_USHORT_INDEX], 16, 0, ms_strGroupList,
						bfeSingleSelList, 0, 0, false);
				strTitle = tr("Group Name");
				CConfigItem *pkGroup = new CConfigItem(ms_strEVENTS_EFFECT_GROUP_SEL_KEY, strTitle,
						pkGrpData->GetDataAsString(), ctItemButton, pkGrpData, false,
						( pSYSTEM_INFO->FWOptionBatchAvailable() == TRUE) && (ptEffect->Enabled == TRUE), 0, false,
						pkEffectParent);
				pkEffectParent->AddChild(pkGroup);
			} else {
				// must be all therefore do nothing
			}
		}
		break;
	case eetReports: {
		CShortBitFieldData *pkReportData = new CShortBitFieldData(
				&ptEffect->Data.S[REPORT_NO_EVENT_EFFECT_USHORT_INDEX], 16, 0, ms_strEventsEffectsReportNamesList,
				bfeSingleSelList, 0, 0, false);
		strTitle = tr("Report Name");
		CConfigItem *pkReport = new CConfigItem(ms_strEVENTS_EFFECT_REPORT_SEL_KEY, strTitle,
				pkReportData->GetDataAsString(), ctItemButton, pkReportData, false,
				( pSYSTEM_INFO->FWOptionReportsAvailable() == TRUE) && (ptEffect->Enabled == TRUE), 0, false,
				pkEffectParent);
		pkEffectParent->AddChild(pkReport);
	}
		break;

		// E528446
	case eetChartSpeed:
		// Get the current chart speed and add it to the strSubTypeList pkCauseParent
		LoadSubTypesAsPerTheChartSpeed(pkEffectParent, ptEffect);
		break;
		//
	case eetClearMessages: {
		QString  strMsgTypes = ms_strEventsEffectsMsgTypeList;
		// Add Chart speed data
		CShortBitFieldData *pkMsgTypeData = new CShortBitFieldData(
				&ptEffect->Data.S[SCREEN_EFFECT_CHART_SPEED]/*&usNewSpeed*/, 8, 0, strMsgTypes/*strCompleteSpeedList*/,
				bfeSingleSelList, 0, 0, false);

		QString  strSubTitle = pkMsgTypeData->GetDataAsString();
		QString  strTitle;
		strTitle = tr("Messages");
		CConfigItem *pkMsgTypes = new CConfigItem(
				ms_strEVENTS_EFFECT_CLEAR_MSG_SEL_KEY/*L"changeChartspeed"*//*strCompleteSpeedList*/, strTitle,
				strSubTitle, ctItemButton, pkMsgTypeData, false, true, 0, false, pkEffectParent);

		pkEffectParent->AddChild(pkMsgTypes);
	}

		break;
	default:
		break;
	}
}
//****************************************************************************
// void SetupCounterEffects(	CConfigBranch *pkParent, 
//								T_PEVENTEFFECT ptEffect,
//								const QString   &rstrCOUNTER_SUBTYPE)
///
/// Method that sets up the counter effect data items
///
/// @param[in/out]			CConfigBranch *pkParent - The parent branch
///	@param[in]				T_PEVENTEFFECT ptEffect - Pointer to the event effect data
/// @param[in]				const QString   &rstrCOUNTER_SUBTYPE - The name of the subtype item 
///							that is currently selcted
///
//****************************************************************************
void CRecSetupCfgMgr::SetupCounterEffects(CConfigBranch *pkParent, T_PEVENTEFFECT ptEffect,
		const QString  &rstrCOUNTER_SUBTYPE) {
	bool bEnabled = (ptEffect->Enabled == TRUE) && ( pSYSTEM_INFO->FWOptionCountersAvailable() == TRUE);

	QString  strTitle("");
	switch (ptEffect->SubType) {
	case ceeALARMS: {
		// add the pen picker first
		// check the pen picker does not exceed the maximum number of pens
		if (ptEffect->AlarmData.PenNo > V6_MAX_PENS) {
			// reset back to pen 1
			ptEffect->AlarmData.PenNo = 0;
		}

		CPickerData *pkPenData = new CPickerData(&ptEffect->AlarmData.PenNo, dtSinglePenAlarm, 0, 0, true, 1, 1);
		strTitle = tr("Pen");
		CConfigItem *pkPen = new CConfigItem(ms_strEVENTS_EFFECT_DATA_KEY, strTitle, pkPenData->GetDataAsString(),
				ctItemButton, pkPenData, false, bEnabled, 0, false, pkParent);
		pkParent->AddChild(pkPen);

		// now add the alarm picker
		CPickerData *pkAlmData = new CPickerData(&ptEffect->AlarmData.AlarmMask, dtMultiAlarm, 0, 0, false, 1,
				V6_MAX_ALARMS, ptEffect->AlarmData.PenNo);
		strTitle = tr("Alarms");
		CConfigItem *pkAlm = new CConfigItem(ms_strEVENTS_EFFECT_ALARM_DATA_KEY, strTitle, pkAlmData->GetDataAsString(),
				ctItemButton, pkAlmData, false, bEnabled, 0, false, pkParent);
		pkParent->AddChild(pkAlm);
	}
		break;
	case ceeEVENTS: {
		// setup the multiple instance event counter picker
		CPickerData *pkEventCounterData = new CPickerData(reinterpret_cast< USHORT*>(&ptEffect->Data), dtMultiEvent, 0,
				0, false, 1,
				EVENTSYSTEM_EVENT_SIZE);

		CConfigItem *pkEventCounter = new CConfigItem(ms_strEVENTS_EFFECT_DATA_KEY, rstrCOUNTER_SUBTYPE,
				pkEventCounterData->GetDataAsString(), ctItemButton, pkEventCounterData, false, bEnabled, 0, false,
				pkParent);
		pkParent->AddChild(pkEventCounter);
	}
		break;
	case ceeUSER: {
		// setup the single instance user counter picker
		CPickerData *pkUserCounterData = new CPickerData(reinterpret_cast< USHORT*>(&ptEffect->Data.S[USER_COUNTER_NO]),
				dtSingleUserCounters, 0, 0, false, 1, 1);
		strTitle = tr("User Counters");
		CConfigItem *pkUserCounter = new CConfigItem(ms_strEVENTS_EFFECT_DATA_KEY, strTitle,
				pkUserCounterData->GetDataAsString(), ctItemButton, pkUserCounterData, false, bEnabled, 0, false,
				pkParent);
		pkParent->AddChild(pkUserCounter);

		if (ptEffect->Data.S[RESET_OR_INC_COUNTER] == FALSE) {
			// user counters therefore show the reset to and increment by fields
			CFloatData *pkResetToData = new CFloatData(&ptEffect->ResetTo, -V6_FLT_MAX, V6_FLT_MAX, 0, 0, false);
			strTitle = tr("Reset To");
			CConfigItem *pkResetTo = new CConfigItem(ms_strEVENTS_EFFECT_COUNTER_RESET_KEY, strTitle,
					pkResetToData->GetDataAsString(), ctItemButton, pkResetToData, false, bEnabled, 0, false, pkParent);
			pkParent->AddChild(pkResetTo);
		} else {
			CFloatData *pkIncrementByData = new CFloatData(&ptEffect->IncrementBy, 0.00001F, V6_FLT_MAX, 0, 0, false);
			strTitle = tr("Increment By");
			CConfigItem *pkIncrementBy = new CConfigItem(ms_strEVENTS_EFFECT_COUNTER_INCREMENT_KEY, strTitle,
					pkIncrementByData->GetDataAsString(), ctItemButton, pkIncrementByData, false, bEnabled, 0, false,
					pkParent);
			pkParent->AddChild(pkIncrementBy);
		}
	}
		break;
	case ceeDIGITAL_INPUTS: {
		CPickerData *pkDigData = new CPickerData(reinterpret_cast< USHORT*>(&ptEffect->Data), dtMultiDigIn, 0, 0, false,
				1, MAX_DIGITAL_IO);

		CConfigItem *pkDig = new CConfigItem(ms_strEVENTS_EFFECT_DATA_KEY, rstrCOUNTER_SUBTYPE,
				pkDigData->GetDataAsString(), ctItemButton, pkDigData, false, bEnabled, 0, false, pkParent);
		pkParent->AddChild(pkDig);
	}
		break;
	case ceeRELAY_OUTPUTS: {
		CPickerData *pkDigData = new CPickerData(reinterpret_cast< USHORT*>(&ptEffect->Data), dtMultiRelayOut, 0, 0,
				false, 1, MAX_DIGITAL_IO + 1);

		CConfigItem *pkDig = new CConfigItem(ms_strEVENTS_EFFECT_DATA_KEY, rstrCOUNTER_SUBTYPE,
				pkDigData->GetDataAsString(), ctItemButton, pkDigData, false, bEnabled, 0, false, pkParent);
		pkParent->AddChild(pkDig);
	}
		break;
	case ceeHARDWARE: {
		CPickerData *pkPulseData = new CPickerData(reinterpret_cast< USHORT*>(&ptEffect->Data), dtMultiPulseIn, 0, 0,
				false, 1, MAX_HIRES_PULSE + MAX_LORES_PULSE);

		CConfigItem *pkPulse = new CConfigItem(ms_strEVENTS_EFFECT_DATA_KEY, rstrCOUNTER_SUBTYPE,
				pkPulseData->GetDataAsString(), ctItemButton, pkPulseData, false, bEnabled, 0, false, pkParent);
		pkParent->AddChild(pkPulse);
	}
		break;
	default:
		break;
	}
}
//****************************************************************************
// CConfigItem *CRecSetupCfgMgr::RefreshEventsConfigTree(	CConfigItem *pkModifiedItem,
//															const USHORT usEVENT_NO )
///
// Method that refreshes the data for an event branch of an events configuration menu,
// usually following a change that requires the tree structure to be regenerated because it is different
///
/// @param[in]		CConfigItem *pkModifiedItem - The modified data item
/// @param[in]		const USHORT usEVENT_NO - The event number to replace - zero based
///
/// @return Pointer to the events config hierarchy
///
//****************************************************************************
CConfigItem* CRecSetupCfgMgr::RefreshEventsConfigTree(CConfigItem *pkModifiedItem, const USHORT usEVENT_NO) {
	CConfigItem *pkNewCfgItem = NULL;
	CConfigInterface *pkTopParent = NULL;

	// Store the key name of this item
	const QString  strKEY(pkModifiedItem->GetKey());

	CConfigInterface *pkEventParent = pkModifiedItem;

	// get the top level parent
	while (pkEventParent->GetParent() != NULL) {
		pkEventParent = pkEventParent->GetParent();
	}

	CEventSetupConfig *pkEventCfg = pSETUP->GetEventSetupConfig();
	T_PEVENTSYSTEM ptEventsSystem = pkEventCfg->GetEventBlock(CONFIG_MODIFIABLE);

	// create the modified event again and replace it within the config tree
	if (ptEventsSystem != NULL) {
		T_EVENT *ptEvent = &ptEventsSystem->Event[usEVENT_NO];

		QString  strKey("");
		strKey.asprintf(L"%s%d", ms_strEVENTS_KEY, usEVENT_NO);

		QString  strTitle("");
		QString  strSubTitle("");

		// get the title and subtitle
		CreateEventTitles(ptEvent, usEVENT_NO, strTitle, strSubTitle);

		// create the individual event parent first
		CConfigBranch *pkNewEvent = new CConfigBranch(strKey, strTitle, strSubTitle, ctSubMenuButton, true, true, 0,
				false, pkEventParent);

		// now setup the event details
		SetupEventDetails(pkNewEvent, ptEvent, usEVENT_NO);

		// replace the existing event with this new one
		CConfigBranch *pkBranch = static_cast<CConfigBranch*>(pkEventParent);
		pkBranch->ReplaceChild(pkNewEvent);

		// we now need to get the new child for the particular item that was being modified
		pkNewCfgItem = static_cast<CConfigItem*>(indexOfChildByKey(strKEY, pkNewEvent, 2));
	} else {
		// there has been a problem
		pkNewCfgItem = static_cast<CConfigItem*>(pkTopParent);
	}

	return pkNewCfgItem;
}
//****************************************************************************
// void CRecSetupCfgMgr::CreateEventTitle(	const T_EVENT* const ptEVENT, 
//											const USHORT usEVENT_NO,
//											QString   &rstrTitle,
//											QString   &rstrSubTitle ) const
///
/// Method that creates an event title
///
///	@param[in]				T_EVENT *ptEvent - Pointer to the event data
///	@param[in]				const USHORT usEVENT_NO - The event no - zero based
/// @param[out]				QString   &rstrTitle - The event title
/// @param[out]				QString   &rstrSubTitle - The event subtitle
///
//****************************************************************************
void CRecSetupCfgMgr::CreateEventTitles(const T_EVENT *const ptEVENT, const USHORT usEVENT_NO, QString  &rstrTitle,
		QString  &rstrSubTitle) const {
	QString  strasprintf("");
	strasprintf = tr("Event %d");
	rstrTitle.asprintf(strasprintf, usEVENT_NO + 1);

	strasprintf = L"%s %s";
	rstrSubTitle.asprintf(strasprintf, CStringUtils::GetItemAtPos(ms_strEnabledList, ptEVENT->Enabled), ptEVENT->Name);
}

//****************************************************************************
// CConfigBranch *CreateCountersConfig( )
///
/// Method that creates a counters config hierarchy
///
/// @return Pointer to the counters config hierarchy
///
//****************************************************************************
CConfigBranch* CRecSetupCfgMgr::CreateCountersConfig() {
	CConfigBranch *pkCountersParent = NULL;

	CEventSetupConfig *pkEventCfg = pSETUP->GetEventSetupConfig();
	T_PCOUNTERS ptCounters = pkEventCfg->GetCountersBlock(CONFIG_MODIFIABLE);

	if (ptCounters != NULL) {
		QString  strTitle("");
		strTitle = tr("Counters");
		QString  strSubTitle(strTitle);

		// Create the top level parent
		pkCountersParent = new CConfigBranch(ms_strCOUNTERS_KEY, strTitle, strSubTitle, ctMainMenuButton, false, true,
				0, false, NULL);

		// loop creating all the individual events
		for (USHORT usCount = 0; usCount < COUNTERS_COUNTER_SIZE; usCount++) {
			QString  strKey("");
			strKey.asprintf(L"%s%d", ms_strCOUNTERS_KEY, usCount);

			// get the title and subtitle
			CreateCounterTitle(&ptCounters->Counter[usCount], usCount, strTitle, strSubTitle);

			// create the individual event parent first
			CConfigBranch *pkNewCounter = new CConfigBranch(strKey, strTitle, strSubTitle, ctSubMenuButton, true, true,
					0, false, pkCountersParent);

			// now setup the counter details
			SetupCounterDetails(pkNewCounter, &ptCounters->Counter[usCount], usCount);

			pkCountersParent->AddChild(pkNewCounter);
		}
	}

	return pkCountersParent;
}
//****************************************************************************
// void SetupCounterDetails(	CConfigBranch *pkParent, 
//								T_COUNTERSDATA *ptCounter, 
//								const USHORT usCOUNTER_NO )
///
/// Method that creates a single counter config hierarchy
///
/// @param[in/out]			CConfigBranch *pkParent - The parent branch
///	@param[in]				T_COUNTER *ptCounter - Pointer to the counter data
///	@param[in]				const USHORT usCOUNTER_NO - The counter no - zero based
///
//****************************************************************************
void CRecSetupCfgMgr::SetupCounterDetails(CConfigBranch *pkParent, T_COUNTERSDATA *ptCounter,
		const USHORT usCOUNTER_NO) {
	QString  strTitle("");

	// Counter enabled
	CShortBitFieldData *pkEnabledData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptCounter), 1, 0,
			ms_strEnabledList, bfeBool, 0, 0, true);

	strTitle = tr("Enabled");
	CConfigItem *pkEnabled = new CConfigItem(ms_strCOUNTERS_ENABLED_KEY, strTitle, pkEnabledData->GetDataAsString(),
			ctItemButton, pkEnabledData, false, true, 0, false, pkParent);
	pkParent->AddChild(pkEnabled);

	// Name - WCHAR edit
	QString   CfgData *pkTagData = new QString   CfgData(ptCounter->Tag,
	EVENT_NAME_LEN, dtString, 0, 0, true);
	strTitle = tr("Name");
	CConfigItem *pkTag = new CConfigItem(ms_strCOUNTERS_NAME_KEY, strTitle, pkTagData->GetDataAsString(), ctItemButton,
			pkTagData, false, (ptCounter->Enabled == TRUE), 0, false, pkParent);
	pkParent->AddChild(pkTag);

	// Start At Value
	CFloatData *pkStartAtData = new CFloatData(&ptCounter->StartAt, -V6_FLT_MAX, V6_FLT_MAX, 0, 0, false);

	strTitle = tr("Start At");
	CConfigItem *pkStartAt = new CConfigItem(ms_strCOUNTERS_START_AT_KEY, strTitle, pkStartAtData->GetDataAsString(),
			ctItemButton, pkStartAtData, false, (ptCounter->Enabled == TRUE), 0, false, pkParent);
	pkParent->AddChild(pkStartAt);

	// Rollover At Value
	CFloatData *pkRolloverAtData = new CFloatData(&ptCounter->RolloverAt, -V6_FLT_MAX, V6_FLT_MAX, 0, 0, false);

	strTitle = tr("Rollover At");
	CConfigItem *pkRolloverAt = new CConfigItem(ms_strCOUNTERS_ROLLOVER_AT_KEY, strTitle,
			pkRolloverAtData->GetDataAsString(), ctItemButton, pkRolloverAtData, false, (ptCounter->Enabled == TRUE), 0,
			false, pkParent);
	pkParent->AddChild(pkRolloverAt);
}
//****************************************************************************
// void CreateCounterTitle(	const T_COUNTERSDATA* const ptCOUNTER, 
//								const USHORT usCOUNTER_NO,
//								QString   &rstrTitle,
//								QString   &rstrSubTitle ) const
///
/// Method that creates a counter title
///
///	@param[in]				const T_COUNTERSDATA* const ptCOUNTER - Pointer to the 
///							counter data
///	@param[in]				const USHORT usCOUNTER_NO - The counter no - zero based
/// @param[out]				QString   &rstrTitle - The counter title
/// @param[out]				QString   &rstrSubTitle - The counter subtitle
///
//****************************************************************************
void CRecSetupCfgMgr::CreateCounterTitle(const T_COUNTERSDATA *const ptCOUNTER, const USHORT usCOUNTER_NO,
		QString  &rstrTitle, QString  &rstrSubTitle) const {
	QString  strasprintf("");
	strasprintf = tr("Counter %u");
	rstrTitle.asprintf(strasprintf, usCOUNTER_NO + 1);

	strasprintf = L"%s %s";
	rstrSubTitle.asprintf(strasprintf, CStringUtils::GetItemAtPos(ms_strEnabledList, ptCOUNTER->Enabled), ptCOUNTER->Tag);
}
//****************************************************************************
// CConfigItem *CRecSetupCfgMgr::RefreshCountersConfigTree(	CConfigItem *pkModifiedItem,
//																const USHORT usCOUNTER_NO )
///
// Method that refreshes the data for a counter branch of a counter configuration menu,
// usually following a change that requires the tree structure to be regenerated because it is different
///
/// @param[in]		CConfigItem *pkModifiedItem - The modified data item
/// @param[in]		const USHORT usCOUNTER_NO - The counter number to replace - zero based
///
/// @return Pointer to the counter config hierarchy
///
//****************************************************************************
CConfigItem* CRecSetupCfgMgr::RefreshCountersConfigTree(CConfigItem *pkModifiedItem, const USHORT usCOUNTER_NO) {
	CConfigItem *pkNewCfgItem = NULL;
	CConfigInterface *pkTopParent = NULL;

	// Store the key name of this item
	const QString  strKEY(pkModifiedItem->GetKey());

	CConfigInterface *pkCounterParent = pkModifiedItem;

	// get the top level parent
	while (pkCounterParent->GetParent() != NULL) {
		pkCounterParent = pkCounterParent->GetParent();
	}

	CEventSetupConfig *pkEventCfg = pSETUP->GetEventSetupConfig();
	T_PCOUNTERS ptCounters = pkEventCfg->GetCountersBlock(CONFIG_MODIFIABLE);

	// create the modified counter again and replace it within the config tree
	if (ptCounters != NULL) {
		T_COUNTERSDATA *ptCounter = &ptCounters->Counter[usCOUNTER_NO];

		QString  strKey("");
		strKey.asprintf(L"%s%d", ms_strCOUNTERS_KEY, usCOUNTER_NO);

		QString  strTitle("");
		QString  strSubTitle("");

		// get the title and subtitle
		CreateCounterTitle(ptCounter, usCOUNTER_NO, strTitle, strSubTitle);

		// create the individual counter parent first
		CConfigBranch *pkNewCounter = new CConfigBranch(strKey, strTitle, strSubTitle, ctSubMenuButton, true, true, 0,
				false, pkCounterParent);

		// now setup the counter details
		SetupCounterDetails(pkNewCounter, ptCounter, usCOUNTER_NO);

		// replace the existing event with this new one
		CConfigBranch *pkBranch = static_cast<CConfigBranch*>(pkCounterParent);
		pkBranch->ReplaceChild(pkNewCounter);

		// we now need to get the new child for the particular item that was being modified
		pkNewCfgItem = static_cast<CConfigItem*>(indexOfChildByKey(strKEY, pkNewCounter, 2));
	} else {
		// there has been a problem
		pkNewCfgItem = static_cast<CConfigItem*>(pkTopParent);
	}

	return pkNewCfgItem;
}
//****************************************************************************
// CConfigBranch *CreateScreenSaverConfig( )
///
/// Method that creates a screen saver config hierarchy
///
/// @return Pointer to the screen saver config hierarchy
///
/// @todo Add CConfigData inherited class for the Week/Day config item
///
//****************************************************************************
CConfigBranch* CRecSetupCfgMgr::CreateScreenSaverConfig() {
	CConfigBranch *pkParent = NULL;

	T_PRECPROFILE ptProfile = pSETUP->GetGeneralSetupConfig()->GetProfileBlock(CONFIG_MODIFIABLE);

	if (ptProfile != NULL) {
		// firstly create the top level config interface class
		QString  strTitle("");
		QString  strSubTitle("");

		strTitle = tr("Screen Saver");

		pkParent = new CConfigBranch(ms_strSCREEN_SAVER_KEY, strTitle, strSubTitle, ctMainMenuButton, false, true, 0,
				false, NULL);

		// now add the children
		// Screen saver enabled
		CShortBitFieldData *pkSaverEnabledData = new CShortBitFieldData(
				reinterpret_cast< USHORT*>(&ptProfile->ScreenSaver), 1, 0, ms_strEnabledList, bfeBool, 0, 0, true);
		strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptProfile->ScreenSaver.Enabled);
		strTitle = tr("Enabled");
		CConfigItem *pkSaverEnabled = new CConfigItem(ms_strSCREEN_SAVER_ENABLED_KEY, strTitle, strSubTitle,
				ctItemButton, pkSaverEnabledData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkSaverEnabled);

		// Screen saver timeout
		QString  strMinutes("");
		strMinutes = tr("Mins.");
		CUShortData *pkSaverTimeoutData = new CUShortData(&ptProfile->ScreenSaver.Timeout, 1, 720, 0, 0, false,
				dtUnsignedShort, strMinutes);
		strTitle = tr("Timeout");
		CConfigItem *pkSaverTimeout = new CConfigItem(ms_strSCREEN_SAVER_TIMEOUT_KEY, strTitle,
				pkSaverTimeoutData->GetDataAsString(true), ctItemButton, pkSaverTimeoutData, false,
				(ptProfile->ScreenSaver.Enabled == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkSaverTimeout);

		// Screen saver type - this will be a bitfield list - set ot locked until the 'shift' type is implemented
		CShortBitFieldData *pkSaverTypeData = new CShortBitFieldData(
				reinterpret_cast< USHORT*>(&ptProfile->ScreenSaver), 3, 4, ms_strScreenSaverTypeList, bfeSingleSelList,
				0, 0, false);
		strSubTitle = pkSaverTypeData->GetDataAsString();
		strTitle = tr("Saver Type");
		CConfigItem *pkSaverType = new CConfigItem(ms_strSCREEN_SAVER_TYPE_KEY, strTitle, strSubTitle, ctItemButton,
				pkSaverTypeData, false, (ptProfile->ScreenSaver.Enabled == TRUE), 0, true, pkParent);
		pkParent->AddChild(pkSaverType);

		// Screen saver mode - this will be a bitfield list
		CShortBitFieldData *pkSaverModeData = new CShortBitFieldData(
				reinterpret_cast< USHORT*>(&ptProfile->ScreenSaver), 3, 1, ms_strScreenSaverModeList, bfeSingleSelList,
				0, 0, true);
		strSubTitle = pkSaverModeData->GetDataAsString();
		strTitle = tr("Shift Mode");

		CConfigItem *pkSaverMode = new CConfigItem(ms_strSCREEN_SAVER_MODE_KEY, strTitle, strSubTitle, ctItemButton,
				pkSaverModeData, false,
				(ptProfile->ScreenSaver.Enabled == TRUE) && (ptProfile->ScreenSaver.SaverType == 1), 0, false,
				pkParent);
		pkParent->AddChild(pkSaverMode);

		// Todo - Screen saver week/day times - this will require a special dialog and config data class
		// ms_strSCREEN_SAVER_MODE_TIMES_KEY

		// Dim screen saver
		CShortBitFieldData *pkSaverDimData = new CShortBitFieldData(reinterpret_cast< USHORT*>(&ptProfile->ScreenSaver),
				1, 7, ms_strScreenSaverDimList, bfeSingleSelList, 0, 0, true);
		strSubTitle = pkSaverDimData->GetDataAsString();
		strTitle = tr("Dim Saver");
		CConfigItem *pkSaverDim = new CConfigItem(ms_strSCREEN_SAVER_DIM_KEY, strTitle, strSubTitle, ctItemButton,
				pkSaverDimData, false, (ptProfile->ScreenSaver.Enabled == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkSaverDim);

		// Dim screen saver percentage - this will be a bitfield list
		bool bShowDimBrightness = (ptProfile->ScreenSaver.Enabled == TRUE) && (ptProfile->ScreenSaver.DimSaver);
		CUShortData *pkDimBrightnessData = new CUShortData(&ptProfile->ScreenSaver.SaverBright, 10, 80, 0, 0, false,
				dtBrightness, L"%");

		strTitle = tr("Saver Level");
		CConfigItem *pkDimBrightness = new CConfigItem(ms_strSCREEN_SAVER_DIM_BRIGHT_KEY, strTitle,
				pkDimBrightnessData->GetDataAsString(true), ctItemButton, pkDimBrightnessData, false,
				bShowDimBrightness, 0, false, pkParent);
		pkParent->AddChild(pkDimBrightness);
	}
	return pkParent;
}
//****************************************************************************
// CConfigBranch *CreateChartConfig( )
///
/// Method that creates a chart config hierarchy
///
/// @return Pointer to the chart config hierarchy
///
//****************************************************************************
CConfigBranch* CRecSetupCfgMgr::CreateChartConfig() {
	CConfigBranch *pkParent = NULL;

	T_PRECPROFILE ptProfile = pSETUP->GetGeneralSetupConfig()->GetProfileBlock(CONFIG_MODIFIABLE);

	if (ptProfile != NULL) {
		// firstly create the top level config interface class
		QString  strTitle("");
		QString  strSubTitle("");

		strTitle = tr("Charts");

		pkParent = new CConfigBranch(ms_strSCREEN_CHART_KEY, strTitle, strSubTitle, ctMainMenuButton, false, true, 0,
				false, NULL);

		// now add the children
		// Strip Fast Chart Speed
		CShortBitFieldData *pkStripFastData = new CShortBitFieldData(&ptProfile->Chart.FastSpeed, 4, 0,
				ms_strScreenChartSpeedFastList, bfeSingleSelList, 0, 0, false);
		strSubTitle = pkStripFastData->GetDataAsString();
		strTitle = tr("Strip Fast Speed");
		CConfigItem *pkStripFast = new CConfigItem(ms_strSCREEN_CHART_FAST_SPEED_KEY, strTitle, strSubTitle,
				ctItemButton, pkStripFastData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkStripFast);

		// Strip Medium Chart Speed
		CShortBitFieldData *pkStripMedData = new CShortBitFieldData(&ptProfile->Chart.MedSpeed, 4, 0,
				ms_strScreenChartSpeedMedList, bfeSingleSelList, 0, 0, false);
		strSubTitle = pkStripMedData->GetDataAsString();
		strTitle = tr("Strip Medium Speed");
		CConfigItem *pkStripMed = new CConfigItem(ms_strSCREEN_CHART_MED_SPEED_KEY, strTitle, strSubTitle, ctItemButton,
				pkStripMedData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkStripMed);

		// Strip Slow Chart Speed
		CShortBitFieldData *pkStripSlowData = new CShortBitFieldData(&ptProfile->Chart.SlowSpeed, 4, 0,
				ms_strScreenChartSpeedSlowList, bfeSingleSelList, 0, 0, false);
		strSubTitle = pkStripSlowData->GetDataAsString();
		strTitle = tr("Strip Slow Speed");
		CConfigItem *pkStripSlow = new CConfigItem(ms_strSCREEN_CHART_SLOW_SPEED_KEY, strTitle, strSubTitle,
				ctItemButton, pkStripSlowData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkStripSlow);

		//PSR Fix for PAR # 1-3JLZOK8 - Remove Circular chart from Multi and Mini Recorder begin
		//Enable the circular chart configuration only if the feature is available
		if ( TRUE == GlbDevCaps.IsCircularChartModeAvailable()) {
			// Circular Fast Chart Speed
			CShortBitFieldData *pkCircFastData = new CShortBitFieldData(&ptProfile->Chart.CircFastSpeed, 4, 0,
					ms_strScreenCircChartSpeedFastList, bfeSingleSelList, 0, 0, false);
			strSubTitle = pkCircFastData->GetDataAsString();
			strTitle = tr("Circ Fast Speed");
			CConfigItem *pkCircFast = new CConfigItem(ms_strSCREEN_CIRC_CHART_FAST_SPEED_KEY, strTitle, strSubTitle,
					ctItemButton, pkCircFastData, false, true, 0, false, pkParent);
			pkParent->AddChild(pkCircFast);

			// Circular Medium Chart Speed
			CShortBitFieldData *pkCircMedData = new CShortBitFieldData(&ptProfile->Chart.CircMedSpeed, 4, 0,
					ms_strScreenCircChartSpeedMedList, bfeSingleSelList, 0, 0, false);
			strSubTitle = pkCircMedData->GetDataAsString();
			strTitle = tr("Circ Med Speed");
			CConfigItem *pkCircMed = new CConfigItem(ms_strSCREEN_CIRC_CHART_MED_SPEED_KEY, strTitle, strSubTitle,
					ctItemButton, pkCircMedData, false, true, 0, false, pkParent);
			pkParent->AddChild(pkCircMed);

			// Circular Slow Chart Speed
			CShortBitFieldData *pkCircSlowData = new CShortBitFieldData(&ptProfile->Chart.CircSlowSpeed, 4, 0,
					ms_strScreenCircChartSpeedSlowList, bfeSingleSelList, 0, 0, false);
			strSubTitle = pkCircSlowData->GetDataAsString();
			strTitle = tr("Circ Slow Speed");
			CConfigItem *pkCircSlow = new CConfigItem(ms_strSCREEN_CIRC_CHART_SLOW_SPEED_KEY, strTitle, strSubTitle,
					ctItemButton, pkCircSlowData, false, true, 0, false, pkParent);
			pkParent->AddChild(pkCircSlow);

			// Circular Charts hour alignment
			CLongBitFieldData *pkCircHourAlignmentData = new CLongBitFieldData(
					reinterpret_cast<ULONG*>(&ptProfile->Chart), 5, 0, NULL, bfeNumerical, 0, 0, false, dtLongBitField,
					false, 0, 23, "");

			strSubTitle = pkCircHourAlignmentData->GetDataAsString();
			strTitle = tr("Hour Alignment");
			CConfigItem *pkCircHourAlignment = new CConfigItem(ms_strSCREEN_CIRC_CHART_HOUR_ALIGNMENT_KEY, strTitle,
					strSubTitle, ctItemButton, pkCircHourAlignmentData, false, true, 0, false, pkParent);
			pkParent->AddChild(pkCircHourAlignment);

			// Circular Charts day alignment
			CLongBitFieldData *pkCircDayAlignmentData = new CLongBitFieldData(
					reinterpret_cast<ULONG*>(&ptProfile->Chart), 3, 5, ms_strScreenCircChartDayAlignmentList,
					bfeSingleSelList, 0, 0, false);

			strTitle = tr("Day Alignment");
			CConfigItem *pkCircDayAlignment = new CConfigItem(ms_strSCREEN_CIRC_CHART_DAY_ALIGNMENT_KEY, strTitle,
					pkCircDayAlignmentData->GetDataAsString(), ctItemButton, pkCircDayAlignmentData, false, true, 0,
					false, pkParent);
			pkParent->AddChild(pkCircDayAlignment);
		}
		//PSR Fix for PAR # 1-3JLZOK8 - Remove Circular chart from Multi and Mini Recorder end
	}

	return pkParent;
}
//****************************************************************************
// CConfigBranch *CreateTabularDisplayConfig( )
///
/// Method that creates a tabular display config hierarchy
///
/// @return Pointer to the tabular display config hierarchy
///
//****************************************************************************
CConfigBranch* CRecSetupCfgMgr::CreateTabularDisplayConfig() {
	CConfigBranch *pkParent = NULL;

	T_PRECPROFILE ptProfile = pSETUP->GetGeneralSetupConfig()->GetProfileBlock(CONFIG_MODIFIABLE);

	if (ptProfile != NULL) {
		// firstly create the top level config interface class
		QString  strTitle("");
		QString  strSubTitle("");
		QString  strSeconds("");
		strSeconds = tr("Secs.");

		strTitle = tr("Tabular Disp.");

		pkParent = new CConfigBranch(ms_strSCREEN_TAB_DISP_KEY, strTitle, strSubTitle, ctMainMenuButton, false, true, 0,
				false, NULL);

		// Update method
		CShortBitFieldData *pkUpdateMethodData = new CShortBitFieldData(
				reinterpret_cast< USHORT*>(&ptProfile->TabularDisp), 1, 0, ms_strScreenTabDispUpdateMethodList,
				bfeSingleSelList, 0, 0, true);
		strTitle = tr("Update Method");
		CConfigItem *pkUpdateMethod = new CConfigItem(ms_strSCREEN_TAB_DISP_UPDATE_METHOD_KEY, strTitle,
				pkUpdateMethodData->GetDataAsString(), ctItemButton, pkUpdateMethodData, false, true, 0, false,
				pkParent);
		pkParent->AddChild(pkUpdateMethod);

		// update interval in seconds
		CULongData *pkUpdateIntervalData = new CULongData(&ptProfile->TabularDisp.UpdatePeriod, 10, 86400, 0, 0, true,
				dtUnsignedShort, strSeconds);

		strTitle = tr("Update Period");

		CConfigItem *pkUpdateInterval = new CConfigItem(ms_strSCREEN_TAB_DISP_UPDATE_PERIOD_KEY, strTitle,
				pkUpdateIntervalData->GetDataAsString(true), ctItemButton, pkUpdateIntervalData, false,
				(ptProfile->TabularDisp.UpdateMethod == tbumPERIODIC), 0, false, pkParent);
		pkParent->AddChild(pkUpdateInterval);

		// Align 
		CShortBitFieldData *pkAlignData = new CShortBitFieldData(reinterpret_cast< USHORT*>(&ptProfile->TabularDisp), 1,
				1, ms_strEnabledList, bfeBool, 0, 0, false);

		strTitle = tr("Alignment");
		CConfigItem *pkAlign = new CConfigItem(ms_strSCREEN_TAB_DISP_ALIGN_KEY, strTitle,
				pkAlignData->GetDataAsString(), ctItemButton, pkAlignData, false,
				(ptProfile->TabularDisp.UpdateMethod == tbumPERIODIC), 0, false, pkParent);
		pkParent->AddChild(pkAlign);
	}

	return pkParent;
}
//****************************************************************************
// CConfigBranch *CreatePrinterConfig( )
///
/// Method that creates a printer config hierarchy
///
/// @return Pointer to the printer config hierarchy
///
//****************************************************************************
CConfigBranch* CRecSetupCfgMgr::CreatePrinterConfig() {
	CConfigBranch *pkParent = NULL;

	// Get the general device data structure
	T_PGENERALCONFIG ptGeneralData = pSETUP->GetGeneralSetupConfig()->GetSystemGeneralBlock(CONFIG_MODIFIABLE);

	if (ptGeneralData != NULL) {
		// firstly create the top level config interface class
		QString  strTitle("");
		QString  strSubTitle("");

		strTitle = tr("Printer");

		pkParent = new CConfigBranch(ms_strPRINTER_KEY, strTitle, strSubTitle, ctMainMenuButton, false, true, 0, false,
				NULL);

		// Allow print - this will be a boolean type bitfield
		CShortBitFieldData *pkAllowPrintData = new CShortBitFieldData(
				reinterpret_cast< USHORT*>(&ptGeneralData->Printer), 1, 0, ms_strEnabledList, bfeBool, 0, 0, true);
		strSubTitle = pkAllowPrintData->GetDataAsString();
		strTitle = tr("Allow Printing");
		CConfigItem *pkAllowPrint = new CConfigItem(ms_strPRINTER_ALLOW_PRINT_KEY, strTitle, strSubTitle, ctItemButton,
				pkAllowPrintData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkAllowPrint);

		// Paper Size - this will be a boolean type bitfield
		CShortBitFieldData *pkPaperSizeData = new CShortBitFieldData(
				reinterpret_cast< USHORT*>(&ptGeneralData->Printer), 1, 1, ms_strPrinterSizeList, bfeBool, 0, 0, false);
		strSubTitle = pkPaperSizeData->GetDataAsString();
		strTitle = tr("Paper Size");
		CConfigItem *pkPaperSize = new CConfigItem(ms_strPRINTER_LETTER_KEY, strTitle, strSubTitle, ctItemButton,
				pkPaperSizeData, false, (ptGeneralData->Printer.AllowPrint == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkPaperSize);

		// Paper Orientation - this will be a boolean type bitfield
		CShortBitFieldData *pkOrientationData = new CShortBitFieldData(
				reinterpret_cast< USHORT*>(&ptGeneralData->Printer), 1, 2, ms_strPrinterOrientationList, bfeBool, 0, 0,
				false);
		strSubTitle = pkOrientationData->GetDataAsString();
		strTitle = tr("Orientation");
		CConfigItem *pkOrientation = new CConfigItem(ms_strPRINTER_PORTRAIT_KEY, strTitle, strSubTitle, ctItemButton,
				pkOrientationData, false, (ptGeneralData->Printer.AllowPrint == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkOrientation);

		// Printer Port - this will be a bitfield list
		CShortBitFieldData *pkPrinterPortData = new CShortBitFieldData(
				reinterpret_cast< USHORT*>(&ptGeneralData->Printer), 5, 9, ms_strPrinterPortList, bfeSingleSelList, 0,
				1, false);

		strSubTitle = pkPrinterPortData->GetDataAsString();
		strTitle = tr("Port Type");
		CConfigItem *pkPrinterPort = new CConfigItem(ms_strPRINTER_PORT_KEY, strTitle, strSubTitle, ctItemButton,
				pkPrinterPortData, false, (ptGeneralData->Printer.AllowPrint == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkPrinterPort);

		// Printer Name - WCHAR edit
		QString   CfgData *pkPrinterNameData = new QString   CfgData(ptGeneralData->Printer.deviceName,
		PRINTERSET_DEVICENAME_LEN, dtString, 0, 0, false);
		strTitle = tr("Printer Name");

		// Available if port is Network.
		CConfigItem *pkPrinterName = new CConfigItem(ms_strPRINTER_DEVICE_NAME_KEY, strTitle,
				pkPrinterNameData->GetDataAsString(), ctItemButton, pkPrinterNameData, false,
				(ptGeneralData->Printer.AllowPrint == TRUE)/* && 
				 ( ptGeneralData->Printer.PrinterPort == 1 )*/, 0, false, pkParent);
		pkParent->AddChild(pkPrinterName);

// PCL Language - this will be a bitfield list

		CShortBitFieldData *pkPclLanguageData = new CShortBitFieldData(
				reinterpret_cast< USHORT*>(&ptGeneralData->Printer), 5, 4, ms_strPrinterPclLanguageList,
				bfeSingleSelList, 0, 2, false);

		strSubTitle = pkPclLanguageData->GetDataAsString();
		strTitle = tr("Protocol (PCL)");
		CConfigItem *pkPclLanguage = new CConfigItem(ms_strPRINTER_PCL_LANGUAGE_KEY, strTitle, strSubTitle,
				ctItemButton, pkPclLanguageData, false, (ptGeneralData->Printer.AllowPrint == TRUE), 0, false,
				pkParent);
		pkParent->AddChild(pkPclLanguage);

		// Colour Printer - this will be a boolean type bitfield
		CShortBitFieldData *pkColourPrnData = new CShortBitFieldData(
				reinterpret_cast< USHORT*>(&ptGeneralData->Printer), 1, 3, ms_strEnabledList, bfeBool, 0, 1, false);

		strTitle = tr("Color Printer");
		CConfigItem *pkColourPrn = new CConfigItem(ms_strPRINTER_COLOUR_PRINTER_KEY, strTitle,
				pkColourPrnData->GetDataAsString(), ctItemButton, pkColourPrnData, false,
				(ptGeneralData->Printer.AllowPrint == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkColourPrn);

		// Fit To Page - this will be a boolean type bitfield
		CShortBitFieldData *pkFitToPageData = new CShortBitFieldData(
				reinterpret_cast< USHORT*>(&ptGeneralData->Printer), 1, 14, ms_strEnabledList, bfeBool, 0, 1, false);

		strTitle = tr("Fit To Page");
		CConfigItem *pkFitToPage = new CConfigItem(ms_strPRINTER_FIT_TO_PAGE_KEY, strTitle,
				pkFitToPageData->GetDataAsString(), ctItemButton, pkFitToPageData, false,
				(ptGeneralData->Printer.AllowPrint == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkFitToPage);

	}

	return pkParent;
}
//****************************************************************************
// CConfigBranch *CreateBatchConfig( )
///
/// Method that creates a batch config hierarchy
///
/// @return Pointer to the batch config hierarchy
///
//****************************************************************************
CConfigBranch* CRecSetupCfgMgr::CreateBatchConfig() {
	CConfigBranch *pkParent = NULL;

	// Get the general device data structure
	T_PGENERALCONFIG ptGeneralData = pSETUP->GetGeneralSetupConfig()->GetSystemGeneralBlock(CONFIG_MODIFIABLE);

	if (ptGeneralData != NULL) {
		// firstly create the top level config interface class
		QString  strTitle("");
		QString  strSubTitle("");

		strTitle = tr("Batch");

		pkParent = new CConfigBranch(ms_strBATCH_KEY, strTitle, strSubTitle, ctMainMenuButton, false, true, 0, false,
				NULL);

		// Setup the general batch properties branch 
		SetupBatchGeneralProps(pkParent, &ptGeneralData->Batch);

		// now add the group branches
		for (USHORT usCount = 0; usCount < BATCH_GROUPINFO_SIZE; usCount++) {
			SetupBatchGroupProps(pkParent, &ptGeneralData->Batch, usCount);
		}
	}

	return pkParent;
}

//****************************************************************************
// void SetupBatchGeneralProps( CConfigBranch *pkParent,
//								 T_PBATCH ptBatch )
///
/// Method that sets up the general batch properties config branch
///
/// @param[in/out] 		CConfigBranch *pkParent - Pointer to the parent owner class
/// @param[in]			T_PBATCH ptBatch - Pointer to the batch configuration
///
//****************************************************************************
void CRecSetupCfgMgr::SetupBatchGeneralProps(CConfigBranch *pkParent, T_PBATCH ptBatch) {
	QString  strTitle("");
	QString  strSubTitle("");

	// now add the general branch
	strTitle = tr("General");
	strSubTitle = tr("General Batch Properties");
	CConfigBranch *pkGeneralParent = new CConfigBranch(ms_strBATCH_GENERAL_KEY, strTitle, strSubTitle, ctSubMenuButton,
			false, true, 0, false, pkParent);
	pkParent->AddChild(pkGeneralParent);

	// Pause chart on batch stop - this will be a boolean type bitfield
	CShortBitFieldData *pkPauseChartData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptBatch), 1, 6,
			ms_strEnabledList, bfeBool, 0, 0, false);
	strTitle = tr("Pause Chart @ Finish");
	CConfigItem *pkPauseChart = new CConfigItem(ms_strBATCH_GENERAL_PAUSE_CHART_KEY, strTitle,
			pkPauseChartData->GetDataAsString(), ctItemButton, pkPauseChartData, false, true, 0, false,
			pkGeneralParent);
	pkGeneralParent->AddChild(pkPauseChart);

	// Start logging on batch start - this will be a boolean type bitfield
	CShortBitFieldData *pkStartLoggingData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptBatch), 1, 7,
			ms_strEnabledList, bfeBool, 0, 0, false);
	strTitle = tr("Start Log @ Start");
	CConfigItem *pkStartLogging = new CConfigItem(ms_strBATCH_GENERAL_START_LOGGING_KEY, strTitle,
			pkStartLoggingData->GetDataAsString(), ctItemButton, pkStartLoggingData, false, true, 0, false,
			pkGeneralParent);
	pkGeneralParent->AddChild(pkStartLogging);

	// Stop logging on batch stop - this will be a boolean type bitfield
	CShortBitFieldData *pkStopLoggingData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptBatch), 1, 8,
			ms_strEnabledList, bfeBool, 0, 0, false);
	strTitle = tr("Stop Log @ Finish");
	CConfigItem *pkStopLogging = new CConfigItem(ms_strBATCH_GENERAL_STOP_LOGGING_KEY, strTitle,
			pkStopLoggingData->GetDataAsString(), ctItemButton, pkStopLoggingData, false, true, 0, false,
			pkGeneralParent);
	pkGeneralParent->AddChild(pkStopLogging);

	// Allow direct input - this will be a boolean type bitfield
	CShortBitFieldData *pkDirectInputData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptBatch), 1, 4,
			ms_strEnabledList, bfeBool, 0, 0, true);
	strSubTitle = pkDirectInputData->GetDataAsString();
	strTitle = tr("Allow Direct Input");
	CConfigItem *pkDirectInput = new CConfigItem(ms_strBATCH_GENERAL_DIRECT_INPUT_KEY, strTitle, strSubTitle,
			ctItemButton, pkDirectInputData, false, true, 0, false, pkGeneralParent);
	pkGeneralParent->AddChild(pkDirectInput);

	// add the branch for the batch name
	strTitle = tr("Name Props.");
	strSubTitle = ptBatch->FieldNames[bflNAME];
	CConfigBranch *pkGeneralNameParent = new CConfigBranch(ms_strBATCH_GENERAL_NAME_FIELD_KEY, strTitle, strSubTitle,
			ctSubMenuButton, false, true, 0, false, pkGeneralParent);
	pkGeneralParent->AddChild(pkGeneralNameParent);

	// Batch Name WCHAR
	QString   CfgData *pkBatchNameData = new QString   CfgData(ptBatch->FieldNames[bflNAME],
	BATCH_FIELDNAMES_LEN, dtString, 0, 0, true);
	strTitle = tr("Display Name");
	CConfigItem *pkBatchName = new CConfigItem(ms_strBATCH_GENERAL_NAME_FIELD_NAME_KEY, strTitle,
			pkBatchNameData->GetDataAsString(), ctItemButton, pkBatchNameData, false, true, 0, false,
			pkGeneralNameParent);
	pkGeneralNameParent->AddChild(pkBatchName);

	// now loop around adding the list of pre-defined batch names
	USHORT usListItemCount = 0;
	QString  strKey("");
	for (usListItemCount = 0; usListItemCount < BATCH_BATCHNAMES_SIZE; usListItemCount++) {
		// batch names list WCHAR
		QString   CfgData *pkBatchNamesListData = new QString   CfgData(ptBatch->BatchNames[usListItemCount],
		BATCH_BATCHNAMES_LEN, dtString, 0, 0, true);
		strTitle.asprintf(IDS_CFG_BATCH_GENERAL_PROPS_LIST_ITEM_TITLE, usListItemCount + 1);
		strKey.asprintf(ms_strBATCH_GENERAL_NAME_FIELD_NAME_LIST_KEY, usListItemCount);
		CConfigItem *pkBatchListName = new CConfigItem(strKey, strTitle, pkBatchNamesListData->GetDataAsString(),
				ctItemButton, pkBatchNamesListData, false, true, 0, false, pkGeneralNameParent);
		pkGeneralNameParent->AddChild(pkBatchListName);
	}

	// add the branch for the user ID
	strTitle = tr("User ID Props.");
	strSubTitle.asprintf(L"%s %s", CStringUtils::GetItemAtPos(ms_strEnabledList, ptBatch->BSUserID),
			ptBatch->FieldNames[bflUSER_ID]);
	CConfigBranch *pkGeneralUserIDParent = new CConfigBranch(ms_strBATCH_GENERAL_USER_ID_FIELD_KEY, strTitle,
			strSubTitle, ctSubMenuButton, false, true, 0, false, pkGeneralParent);
	pkGeneralParent->AddChild(pkGeneralUserIDParent);

	// User ID required - this will be a boolean type bitfield
	CShortBitFieldData *pkUserIDReqData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptBatch), 1, 0,
			ms_strEnabledList, bfeBool, 0, 0, true);
	strTitle = tr("User ID Req.");
	CConfigItem *pkUserIDReq = new CConfigItem(ms_strBATCH_GENERAL_USE_USER_ID_KEY, strTitle,
			pkUserIDReqData->GetDataAsString(), ctItemButton, pkUserIDReqData, false, true, 0, false,
			pkGeneralUserIDParent);
	pkGeneralUserIDParent->AddChild(pkUserIDReq);

	// Batch User ID WCHAR
	QString   CfgData *pkUserIDData = new QString   CfgData(ptBatch->FieldNames[bflUSER_ID],
	BATCH_FIELDNAMES_LEN, dtString, 0, 0, true);
	strTitle = tr("Display Name");
	CConfigItem *pkUserID = new CConfigItem(ms_strBATCH_GENERAL_USER_ID_FIELD_NAME_KEY, strTitle,
			pkUserIDData->GetDataAsString(), ctItemButton, pkUserIDData, false, (ptBatch->BSUserID == TRUE), 0, false,
			pkGeneralUserIDParent);
	pkGeneralUserIDParent->AddChild(pkUserID);

	for (usListItemCount = 0; usListItemCount < BATCH_USERNAMES_SIZE; usListItemCount++) {
		// User ID List WCHAR's - cap the length to the user name length in the password system for now
		QString   CfgData *pkUserIDListData = new QString   CfgData(ptBatch->UserNames[usListItemCount],
		USERINFO_NAME_LEN, dtString, 0, 0, true);
		strTitle.asprintf(IDS_CFG_BATCH_GENERAL_PROPS_LIST_ITEM_TITLE, usListItemCount + 1);
		strKey.asprintf(ms_strBATCH_GENERAL_USER_ID_FIELD_USER_LIST_KEY, usListItemCount);
		CConfigItem *pkUserIDList = new CConfigItem(strKey, strTitle, pkUserIDListData->GetDataAsString(), ctItemButton,
				pkUserIDListData, false, (ptBatch->BSUserID == TRUE), 0, false, pkGeneralUserIDParent);
		pkGeneralUserIDParent->AddChild(pkUserIDList);
	}

	// add the branch for the lot no
	strTitle = tr("Field 1 Props.");
	strSubTitle.asprintf(L"%s %s", CStringUtils::GetItemAtPos(ms_strEnabledList, ptBatch->BSLot),
			ptBatch->FieldNames[bflLOT_NO]);
//#ifdef XSERIESSETUP //this line commented by kranti
	CConfigBranch *pkGeneralLotNoParent = new CConfigBranch(ms_strBATCH_GENERAL_LOT_FIELD_KEY, strTitle, strSubTitle,
			ctSubMenuButton, false, true, 0, false, pkGeneralParent);
	pkGeneralParent->AddChild(pkGeneralLotNoParent);

	// Lot No required- this will be a boolean type bitfield
	CShortBitFieldData *pkLotNoReqData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptBatch), 1, 3,
			ms_strEnabledList, bfeBool, 0, 0, true);
	strTitle = tr("Field 1 Req.");
	CConfigItem *pkLotNoReq = new CConfigItem(ms_strBATCH_GENERAL_USE_LOT_KEY, strTitle,
			pkLotNoReqData->GetDataAsString(), ctItemButton, pkLotNoReqData, false, true, 0, false,
			pkGeneralLotNoParent);
	pkGeneralLotNoParent->AddChild(pkLotNoReq);

	// Batch Lot No WCHAR
	QString   CfgData *pkLotNoData = new QString   CfgData(ptBatch->FieldNames[bflLOT_NO],
	BATCH_FIELDNAMES_LEN, dtString, 0, 0, true);
	strTitle = tr("Display Name");
	CConfigItem *pkLotNo = new CConfigItem(ms_strBATCH_GENERAL_LOT_FIELD_NAME_KEY, strTitle,
			pkLotNoData->GetDataAsString(), ctItemButton, pkLotNoData, false, (ptBatch->BSLot == TRUE), 0, false,
			pkGeneralLotNoParent);
	pkGeneralLotNoParent->AddChild(pkLotNo);

	for (usListItemCount = 0; usListItemCount < BATCH_LOTNONAMES_SIZE; usListItemCount++) {
		// Lot No List WCHAR's
		QString   CfgData *pkLotNoListData = new QString   CfgData(ptBatch->LotNoNames[usListItemCount],
		BATCH_LOTNONAMES_LEN, dtString, 0, 0, true);
		strTitle.asprintf(IDS_CFG_BATCH_GENERAL_PROPS_LIST_ITEM_TITLE, usListItemCount + 1);
		strKey.asprintf(ms_strBATCH_GENERAL_LOT_FIELD_LOT_NO_LIST_KEY, usListItemCount);
		CConfigItem *pkLotNoList = new CConfigItem(strKey, strTitle, pkLotNoListData->GetDataAsString(), ctItemButton,
				pkLotNoListData, false, (ptBatch->BSLot == TRUE), 0, false, pkGeneralLotNoParent);
		pkGeneralLotNoParent->AddChild(pkLotNoList);
	}
//#else //this whole code is commented by kranti
//	CConfigBranch *pkGeneralLotNoParent = new CConfigBranch(	ms_strBATCH_GENERAL_LOT_FIELD_KEY,
//																strTitle,
//																strSubTitle,
//																ctSubMenuButton,													
//																false,
//																false,
//																0,
//																false,
//																pkGeneralParent );
//	pkGeneralParent->AddChild( pkGeneralLotNoParent );
//#endif

	// add the branch for the description
	strTitle = tr("Field 2 Props.");
	strSubTitle.asprintf(L"%s %s", CStringUtils::GetItemAtPos(ms_strEnabledList, ptBatch->BSDesc),
			ptBatch->FieldNames[bflDESCRIPTION]);
	CConfigBranch *pkGeneralDescParent = new CConfigBranch(ms_strBATCH_GENERAL_DESC_FIELD_KEY, strTitle, strSubTitle,
			ctSubMenuButton, false, true, 0, false, pkGeneralParent);
	pkGeneralParent->AddChild(pkGeneralDescParent);

	// Description required- this will be a boolean type bitfield
	CShortBitFieldData *pkDescReqData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptBatch), 1, 1,
			ms_strEnabledList, bfeBool, 0, 0, true);
	strTitle = tr("Field 2 Req.");
	CConfigItem *pkDescReq = new CConfigItem(ms_strBATCH_GENERAL_USE_DESC_KEY, strTitle,
			pkDescReqData->GetDataAsString(), ctItemButton, pkDescReqData, false, true, 0, false, pkGeneralDescParent);
	pkGeneralDescParent->AddChild(pkDescReq);

	// Batch Description WCHAR
	QString   CfgData *pkDescriptionData = new QString   CfgData(ptBatch->FieldNames[bflDESCRIPTION],
	BATCH_FIELDNAMES_LEN, dtString, 0, 0, true);
	strTitle = tr("Display Name");
	CConfigItem *pkDescription = new CConfigItem(ms_strBATCH_GENERAL_DESC_FIELD_NAME_KEY, strTitle,
			pkDescriptionData->GetDataAsString(), ctItemButton, pkDescriptionData, false, (ptBatch->BSDesc == TRUE), 0,
			false, pkGeneralDescParent);
	pkGeneralDescParent->AddChild(pkDescription);

	for (usListItemCount = 0; usListItemCount < BATCH_DESCNAMES_SIZE; usListItemCount++) {
		// Description List WCHAR's
		QString   CfgData *pkDescListData = new QString   CfgData(ptBatch->DescNames[usListItemCount],
		BATCH_DESCNAMES_LEN, dtString, 0, 0, true);
		strTitle.asprintf(IDS_CFG_BATCH_GENERAL_PROPS_LIST_ITEM_TITLE, usListItemCount + 1);
		strKey.asprintf(ms_strBATCH_GENERAL_DESC_FIELD_DESC_LIST_KEY, usListItemCount);
		CConfigItem *pkDescList = new CConfigItem(strKey, strTitle, pkDescListData->GetDataAsString(), ctItemButton,
				pkDescListData, false, (ptBatch->BSDesc == TRUE), 0, false, pkGeneralDescParent);
		pkGeneralDescParent->AddChild(pkDescList);
	}

	// add the branch for the comment
	strTitle = tr("Field 3 Props.");
	strSubTitle.asprintf(L"%s %s", CStringUtils::GetItemAtPos(ms_strEnabledList, ptBatch->BSComment),
			ptBatch->FieldNames[bflCOMMENT]);
	CConfigBranch *pkGeneralCommentParent = new CConfigBranch(ms_strBATCH_GENERAL_COMMENT_FIELD_KEY, strTitle,
			strSubTitle, ctSubMenuButton, false, true, 0, false, pkGeneralParent);
	pkGeneralParent->AddChild(pkGeneralCommentParent);

	// Comment required- this will be a boolean type bitfield
	CShortBitFieldData *pkCommReqData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptBatch), 1, 2,
			ms_strEnabledList, bfeBool, 0, 0, true);
	strTitle = tr("Field 3 Req.");
	CConfigItem *pkCommReq = new CConfigItem(ms_strBATCH_GENERAL_USE_COMMENT_KEY, strTitle,
			pkCommReqData->GetDataAsString(), ctItemButton, pkCommReqData, false, true, 0, false,
			pkGeneralCommentParent);
	pkGeneralCommentParent->AddChild(pkCommReq);

	// Batch Comment WCHAR
	QString   CfgData *pkCommentData = new QString   CfgData(ptBatch->FieldNames[bflCOMMENT],
	BATCH_FIELDNAMES_LEN, dtString, 0, 0, true);
	strTitle = tr("Display Name");
	CConfigItem *pkComment = new CConfigItem(ms_strBATCH_GENERAL_COMMENT_FIELD_NAME_KEY, strTitle,
			pkCommentData->GetDataAsString(), ctItemButton, pkCommentData, false, (ptBatch->BSComment == TRUE), 0,
			false, pkGeneralCommentParent);
	pkGeneralCommentParent->AddChild(pkComment);

	for (usListItemCount = 0; usListItemCount < BATCH_COMMENTNAMES_SIZE; usListItemCount++) {
		// Comment List WCHAR's
		QString   CfgData *pkCommListData = new QString   CfgData(ptBatch->CommentNames[usListItemCount],
		BATCH_COMMENTNAMES_LEN, dtString, 0, 0, true);
		strTitle.asprintf(IDS_CFG_BATCH_GENERAL_PROPS_LIST_ITEM_TITLE, usListItemCount + 1);
		strKey.asprintf(ms_strBATCH_GENERAL_COMMENT_FIELD_COMMENT_LIST_KEY, usListItemCount);
		CConfigItem *pkCommList = new CConfigItem(strKey, strTitle, pkCommListData->GetDataAsString(), ctItemButton,
				pkCommListData, false, (ptBatch->BSComment == TRUE), 0, false, pkGeneralCommentParent);
		pkGeneralCommentParent->AddChild(pkCommList);
	}

	// Add wizard
#ifndef XSERIESSETUP
	CShortBitFieldData *pkSSBData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptBatch), 1, 9, ms_strEnabledList,
			bfeBool, 0, 0, false);
	strTitle = tr("Single Screen Batch");
	CConfigItem *pkSSB = new CConfigItem(ms_strBATCH_GENERAL_SSB_FIELD_KEY, strTitle, pkSSBData->GetDataAsString(),
			ctItemButton, pkSSBData, false, true, 0, false, pkGeneralParent);
	pkGeneralParent->AddChild(pkSSB);
#endif

}
//****************************************************************************
// void SetupBatchGroupProps(	CConfigBranch *pkParent,
//								T_PBATCH ptBatch,
//								const USHORT usGROUP_INDEX)
///
/// Method that sets up the group batch properties config branch
///
/// @param[in/out] 		CConfigBranch *pkParent - Pointer to the parent owner class
/// @param[in]			T_PBATCH ptBatch - Pointer to the batch configuration
/// @param[in]			const USHORT usGROUP_INDEX - The index of the group we are setting up
///
//****************************************************************************
void CRecSetupCfgMgr::SetupBatchGroupProps(CConfigBranch *pkParent, T_PBATCH ptBatch, const USHORT usGROUP_INDEX) {
	QString  strTitle("");
	QString  strSubTitle("");
	QString  strKey("");

	// now add the group specific branch
	strTitle.asprintf(IDS_CFG_BATCH_GROUP_TITLE, usGROUP_INDEX + 1);
	strSubTitle = ptBatch->GroupInfo[usGROUP_INDEX].AutoBatchName;
	strKey.asprintf(ms_strBATCH_GROUP_KEY, usGROUP_INDEX);
	CConfigBranch *pkGroupParent = new CConfigBranch(strKey, strTitle, strSubTitle, ctSubMenuButton, false, true, 0,
			false, pkParent);
	pkParent->AddChild(pkGroupParent);

	// Populate the batch wizard with the auto batch name - this will be a boolean type bitfield
	CShortBitFieldData *pkAutoPopData = new CShortBitFieldData(
			reinterpret_cast< USHORT*>(&ptBatch->GroupInfo[usGROUP_INDEX]), 1, 0, ms_strEnabledList, bfeBool, 0, 0,
			true);
	strTitle = tr("Auto Pop. Wiz.");
	CConfigItem *pkAutoPop = new CConfigItem(ms_strBATCH_GROUP_AUTO_POP_KEY, strTitle, pkAutoPopData->GetDataAsString(),
			ctItemButton, pkAutoPopData, false, true, 0, false, pkGroupParent);
	pkGroupParent->AddChild(pkAutoPop);

	// Auto Batch Name WCHAR
	QString   CfgData *pkAutoNameData = new QString   CfgData(ptBatch->GroupInfo[usGROUP_INDEX].AutoBatchName,
	GROUPINFO_AUTOBATCHNAME_LEN, dtString, 0, 0, true);
	strTitle = tr("Auto Pop. Name");
	CConfigItem *pkAutoName = new CConfigItem(ms_strBATCH_GROUP_AUTO_POP_NAME_KEY, strTitle,
			pkAutoNameData->GetDataAsString(), ctItemButton, pkAutoNameData, false, true, 0, false, pkGroupParent);
	pkGroupParent->AddChild(pkAutoName);

	// Zero pad the batch count - this will be a boolean type bitfield
	CShortBitFieldData *pkZeroPadData = new CShortBitFieldData(
			reinterpret_cast< USHORT*>(&ptBatch->GroupInfo[usGROUP_INDEX]), 1, 1, ms_strEnabledList, bfeBool, 0, 0,
			false);
	strTitle = tr("Zero Pad Count");
	CConfigItem *pkZeroPad = new CConfigItem(ms_strBATCH_GROUP_ZERO_PAD_KEY, strTitle, pkZeroPadData->GetDataAsString(),
			ctItemButton, pkZeroPadData, false, true, 0, false, pkGroupParent);
	pkGroupParent->AddChild(pkZeroPad);

	// Group Counter Start
	CULongData *pkCtrStartData = new CULongData(&ptBatch->GroupInfo[usGROUP_INDEX].GroupCtrStart, 0, ULONG_MAX - 1, 0,
			0, false);
	strTitle = tr("Ctr. Start");
	CConfigItem *pkCtrStart = new CConfigItem(ms_strBATCH_GROUP_CTR_START_KEY, strTitle,
			pkCtrStartData->GetDataAsString(), ctItemButton, pkCtrStartData, false, true, 0, false, pkGroupParent);

	pkGroupParent->AddChild(pkCtrStart);

	// Group Counter Increment
	CULongData *pkCtrIncData = new CULongData(&ptBatch->GroupInfo[usGROUP_INDEX].GroupCtrInc, 1, ULONG_MAX - 1, 0, 0,
			false);
	strTitle = tr("Ctr. Increment");
	CConfigItem *pkCtrInc = new CConfigItem(ms_strBATCH_GROUP_CTR_INC_KEY, strTitle, pkCtrIncData->GetDataAsString(),
			ctItemButton, pkCtrIncData, false, true, 0, false, pkGroupParent);

	pkGroupParent->AddChild(pkCtrInc);

	// Group Counter Rollover
	CULongData *pkCtrRolloverData = new CULongData(&ptBatch->GroupInfo[usGROUP_INDEX].GroupCtrRoll, 1, ULONG_MAX - 1, 0,
			0, false);
	strTitle = tr("Ctr. Rollover");
	CConfigItem *pkCtrRollover = new CConfigItem(ms_strBATCH_GROUP_CTR_ROLLOVER_KEY, strTitle,
			pkCtrRolloverData->GetDataAsString(), ctItemButton, pkCtrRolloverData, false, true, 0, false,
			pkGroupParent);

	pkGroupParent->AddChild(pkCtrRollover);

	// Show the batch name list - this will be a boolean type bitfield
	if (ptBatch->GroupInfo[usGROUP_INDEX].AutoPopWizard == FALSE) {
		CShortBitFieldData *pkShowBatchNameListData = new CShortBitFieldData(
				reinterpret_cast< USHORT*>(&ptBatch->GroupInfo[usGROUP_INDEX]), 1, 2, ms_strEnabledList, bfeBool, 0, 0,
				false);
		strTitle.asprintf(IDS_CFG_BATCH_GROUP_SHOW_NAME_TITLE, ptBatch->FieldNames[bflNAME]);
		CConfigItem *pkShowBatchNameList = new CConfigItem(ms_strBATCH_GROUP_SHOW_NAME_LIST_KEY, strTitle,
				pkShowBatchNameListData->GetDataAsString(), ctItemButton, pkShowBatchNameListData, false, true, 0,
				false, pkGroupParent);
		pkGroupParent->AddChild(pkShowBatchNameList);
	}

	// Show the user ID list - this will be a boolean type bitfield
	CShortBitFieldData *pkShowUserIDListData = new CShortBitFieldData(
			reinterpret_cast< USHORT*>(&ptBatch->GroupInfo[usGROUP_INDEX]), 1, 3, ms_strEnabledList, bfeBool, 0, 0,
			false);
	strTitle.asprintf(IDS_CFG_BATCH_GROUP_SHOW_USER_ID_TITLE, ptBatch->FieldNames[bflUSER_ID]);
	CConfigItem *pkShowUserIDList = new CConfigItem(ms_strBATCH_GROUP_SHOW_USER_LIST_KEY, strTitle,
			pkShowUserIDListData->GetDataAsString(), ctItemButton, pkShowUserIDListData, false,
			(ptBatch->BSUserID == TRUE), 0, false, pkGroupParent);
	pkGroupParent->AddChild(pkShowUserIDList);

	// Show the lot no list - this will be a boolean type bitfield
	CShortBitFieldData *pkShowLotNoListData = new CShortBitFieldData(
			reinterpret_cast< USHORT*>(&ptBatch->GroupInfo[usGROUP_INDEX]), 1, 4, ms_strEnabledList, bfeBool, 0, 0,
			false);
	strTitle.asprintf(IDS_CFG_BATCH_GROUP_SHOW_LOT_NO_TITLE, ptBatch->FieldNames[bflLOT_NO]);
#ifdef XSERIESSETUP
	CConfigItem *pkShowLotNoList = new CConfigItem(	ms_strBATCH_GROUP_SHOW_LOT_NO_LIST_KEY,
													strTitle,
													pkShowLotNoListData->GetDataAsString(),						
													ctItemButton,
													pkShowLotNoListData,
													false,
													( ptBatch->BSLot == TRUE ),
													0,
													false,
													pkGroupParent );
	pkGroupParent->AddChild( pkShowLotNoList );
#else
	CConfigItem *pkShowLotNoList = new CConfigItem(ms_strBATCH_GROUP_SHOW_LOT_NO_LIST_KEY, strTitle,
			pkShowLotNoListData->GetDataAsString(), ctItemButton, pkShowLotNoListData, false,
			//false,//( ptBatch->BSLot == TRUE ),
			(ptBatch->BSLot == TRUE), // changed by kranti from false
			0, false, pkGroupParent);
	pkGroupParent->AddChild(pkShowLotNoList);
#endif

	// Show the description list - this will be a boolean type bitfield
	CShortBitFieldData *pkShowDescListData = new CShortBitFieldData(
			reinterpret_cast< USHORT*>(&ptBatch->GroupInfo[usGROUP_INDEX]), 1, 5, ms_strEnabledList, bfeBool, 0, 0,
			false);
	strTitle.asprintf(IDS_CFG_BATCH_GROUP_SHOW_DESC_TITLE, ptBatch->FieldNames[bflDESCRIPTION]);
	CConfigItem *pkShowDescList = new CConfigItem(ms_strBATCH_GROUP_SHOW_DESC_LIST_KEY, strTitle,
			pkShowDescListData->GetDataAsString(), ctItemButton, pkShowDescListData, false, (ptBatch->BSDesc == TRUE),
			0, false, pkGroupParent);
	pkGroupParent->AddChild(pkShowDescList);

	// Show the comment list - this will be a boolean type bitfield
	CShortBitFieldData *pkShowCommListData = new CShortBitFieldData(
			reinterpret_cast< USHORT*>(&ptBatch->GroupInfo[usGROUP_INDEX]), 1, 6, ms_strEnabledList, bfeBool, 0, 0,
			false);
	strTitle.asprintf(IDS_CFG_BATCH_GROUP_SHOW_COMM_TITLE, ptBatch->FieldNames[bflCOMMENT]);
	CConfigItem *pkShowCommList = new CConfigItem(ms_strBATCH_GROUP_SHOW_COMM_LIST_KEY, strTitle,
			pkShowCommListData->GetDataAsString(), ctItemButton, pkShowCommListData, false,
			(ptBatch->BSComment == TRUE), 0, false, pkGroupParent);
	pkGroupParent->AddChild(pkShowCommList);
}
//****************************************************************************
// CConfigBranch *CreateErrorControlConfig( )
///
/// Method that creates an error control config hierarchy
///
/// @return Pointer to the error control config hierarchy
///
//****************************************************************************
CConfigBranch* CRecSetupCfgMgr::CreateErrorControlConfig() {
	CConfigBranch *pkParent = NULL;

	T_PGENERALCONFIG ptGeneralData = pSETUP->GetGeneralSetupConfig()->GetSystemGeneralBlock(CONFIG_MODIFIABLE);

	if (ptGeneralData != NULL) {
		// firstly create the top level config interface class
		QString  strTitle("");
		QString  strSubTitle("");

		strTitle = tr("Error Alert");

		pkParent = new CConfigBranch(ms_strERROR_CONTROL_KEY, strTitle, strTitle, ctMainMenuButton, false, true, 0,
				false, NULL);

		// Error types - this will be a branch
		strTitle = tr("Error Types");
		ULONG ulNoOfErrors = 0;
		// count the number of errors that are set
		if (ptGeneralData->ErrorControl.NetworkDiscon) {
			++ulNoOfErrors;
		}
		if (ptGeneralData->ErrorControl.CJCMissing) {
			++ulNoOfErrors;
		}
		if (ptGeneralData->ErrorControl.ExportMedMiss) {
			++ulNoOfErrors;
		}
		if (ptGeneralData->ErrorControl.ExportMemLo) {
			++ulNoOfErrors;
		}
		if (ptGeneralData->ErrorControl.FTPMemLo) {
			++ulNoOfErrors;
		}
		if (ptGeneralData->ErrorControl.IntMemLo) {
			++ulNoOfErrors;
		}
		if (ptGeneralData->ErrorControl.TCBurnout) {
			++ulNoOfErrors;
		}
		strSubTitle.asprintf(IDS_CFG_ERROR_CTRL_ERROR_TYPES_SUBTITLE, ulNoOfErrors);

		CConfigBranch *pkTypesParent = new CConfigBranch(ms_strERROR_CONTROL_ERRORS_KEY, strTitle, strSubTitle,
				ctSubMenuButton, false, true, 0, false, pkParent);
		pkParent->AddChild(pkTypesParent);

		// network cable unplugged - boolean
		CShortBitFieldData *pkNetCableData = new CShortBitFieldData(
				reinterpret_cast< USHORT*>(&ptGeneralData->ErrorControl), 1, 2, ms_strEnabledList, bfeBool, 0, 0, true);
		strTitle = tr("Network Unplugged");
		CConfigItem *pkNetCable = new CConfigItem(ms_strERROR_CONTROL_ERRORS_CABLE_UNPLUGGED_KEY, strTitle,
				pkNetCableData->GetDataAsString(), ctItemButton, pkNetCableData, false, true, 0, false, pkTypesParent);
		pkTypesParent->AddChild(pkNetCable);

		// internal memory low - boolean
		CShortBitFieldData *pkIntMemLoData = new CShortBitFieldData(
				reinterpret_cast< USHORT*>(&ptGeneralData->ErrorControl), 1, 3, ms_strEnabledList, bfeBool, 0, 0, true);
		strTitle = tr("Int. Mem. Alarm");
		CConfigItem *pkIntMemLo = new CConfigItem(ms_strERROR_CONTROL_ERRORS_INT_MEM_LO_KEY, strTitle,
				pkIntMemLoData->GetDataAsString(), ctItemButton, pkIntMemLoData, false, true, 0, false, pkTypesParent);
		pkTypesParent->AddChild(pkIntMemLo);

		// external export memory low - boolean
		CShortBitFieldData *pkExpMemLoData = new CShortBitFieldData(
				reinterpret_cast< USHORT*>(&ptGeneralData->ErrorControl), 1, 4, ms_strEnabledList, bfeBool, 0, 0, true);
		strTitle = tr("Export Alarm");
		CConfigItem *pkExpMemLo = new CConfigItem(ms_strERROR_CONTROL_ERRORS_EXP_MEM_LO_KEY, strTitle,
				pkExpMemLoData->GetDataAsString(), ctItemButton, pkExpMemLoData, false, true, 0, false, pkTypesParent);
		pkTypesParent->AddChild(pkExpMemLo);

		// external media missing - boolean
		CShortBitFieldData *pkMediaMissingData = new CShortBitFieldData(
				reinterpret_cast< USHORT*>(&ptGeneralData->ErrorControl), 1, 6, ms_strEnabledList, bfeBool, 0, 0, true);
		strTitle = tr("Media Missing");
		CConfigItem *pkMediaMissing = new CConfigItem(ms_strERROR_CONTROL_ERRORS_EXP_MEDIA_MISSING_KEY, strTitle,
				pkMediaMissingData->GetDataAsString(), ctItemButton, pkMediaMissingData, false, true, 0, false,
				pkTypesParent);
		pkTypesParent->AddChild(pkMediaMissing);

		// FTP export memory low - boolean
		CShortBitFieldData *pkFTPMemLoData = new CShortBitFieldData(
				reinterpret_cast< USHORT*>(&ptGeneralData->ErrorControl), 1, 5, ms_strEnabledList, bfeBool, 0, 0, true);
		strTitle = tr("FTP Mem. Lo");
		CConfigItem *pkFTPMemLo = new CConfigItem(ms_strERROR_CONTROL_ERRORS_FTP_MEM_LO_KEY, strTitle,
				pkFTPMemLoData->GetDataAsString(), ctItemButton, pkFTPMemLoData, false, true, 0, false, pkTypesParent);
		pkTypesParent->AddChild(pkFTPMemLo);

		// CJC Missing - boolean
		CShortBitFieldData *pkCJCMissingData = new CShortBitFieldData(
				reinterpret_cast< USHORT*>(&ptGeneralData->ErrorControl), 1, 7, ms_strEnabledList, bfeBool, 0, 0, true);
		strTitle = tr("CJC Missing");
		CConfigItem *pkCJCMissing = new CConfigItem(ms_strERROR_CONTROL_ERRORS_CJC_MISSING_KEY, strTitle,
				pkCJCMissingData->GetDataAsString(), ctItemButton, pkCJCMissingData, false, true, 0, false,
				pkTypesParent);
		pkTypesParent->AddChild(pkCJCMissing);

		// TC Burnout - boolean
		CShortBitFieldData *pkTCBurnoutData = new CShortBitFieldData(
				reinterpret_cast< USHORT*>(&ptGeneralData->ErrorControl), 1, 8, ms_strEnabledList, bfeBool, 0, 0, true);
		strTitle = tr("TC Burnout");
		CConfigItem *pkTCBurnout = new CConfigItem(ms_strERROR_CONTROL_ERRORS_BURNOUT_KEY, strTitle,
				pkTCBurnoutData->GetDataAsString(), ctItemButton, pkTCBurnoutData, false, true, 0, false,
				pkTypesParent);
		pkTypesParent->AddChild(pkTCBurnout);

		// Border colour - this is a ULONG
		CULongData *pkBorderColData = new CULongData(&ptGeneralData->ErrorControl.BorderColour, 0, ms_ulMaxColour, 0, 0,
				false, dtColour);
		strTitle = tr("Border Color");
		CConfigItem *pkBorderCol = new CConfigItem(ms_strERROR_CONTROL_BORDER_COL_KEY, strTitle,
				pkBorderColData->GetDataAsString(), ctItemButton, pkBorderColData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkBorderCol);

		// Background colour - this is a ULONG
		CULongData *pkBkgColData = new CULongData(&ptGeneralData->ErrorControl.BkgColour, 0, ms_ulMaxColour, 0, 0,
				false, dtColour);
		strTitle = tr("Bkg Color");
		CConfigItem *pkBkgCol = new CConfigItem(ms_strERROR_CONTROL_BKG_COL_KEY, strTitle,
				pkBkgColData->GetDataAsString(), ctItemButton, pkBkgColData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkBkgCol);

		// Auto clear - boolean
		CShortBitFieldData *pkAutoClrData = new CShortBitFieldData(
				reinterpret_cast< USHORT*>(&ptGeneralData->ErrorControl), 1, 0, ms_strEnabledList, bfeBool, 0, 0,
				false);
		strTitle = tr("Auto Clear");
		CConfigItem *pkAutoClr = new CConfigItem(ms_strERROR_CONTROL_AUTO_CLEAR_KEY, strTitle,
				pkAutoClrData->GetDataAsString(), ctItemButton, pkAutoClrData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkAutoClr);

		// Enable reflash - boolean
		CShortBitFieldData *pkEnReflashData = new CShortBitFieldData(
				reinterpret_cast< USHORT*>(&ptGeneralData->ErrorControl), 1, 1, ms_strEnabledList, bfeBool, 0, 0, true);
		strTitle = tr("Enable Reflash");
		CConfigItem *pkEnReflash = new CConfigItem(ms_strERROR_CONTROL_REFLASH_EN_KEY, strTitle,
				pkEnReflashData->GetDataAsString(), ctItemButton, pkEnReflashData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkEnReflash);

		// reflash time
		QString  strReflashUnits("");
		strReflashUnits = tr("Mins.");
		CUShortData *pkReflashData = new CUShortData(&ptGeneralData->ErrorControl.ReflashTime, 1, 1440, 0, 0, false,
				dtUnsignedShort, strReflashUnits);
		strTitle = tr("Reflash Time");
		CConfigItem *pkReflash = new CConfigItem(ms_strERROR_CONTROL_REFLASH_TIME_KEY, strTitle,
				pkReflashData->GetDataAsString(true), ctItemButton, pkReflashData, false,
				(ptGeneralData->ErrorControl.EnableReflash != FALSE), 0, false, pkParent);
		pkParent->AddChild(pkReflash);
	}
	return pkParent;
}
//****************************************************************************
// CConfigBranch *CreateLocalisationConfig( )
///
/// Method that creates a localisation config hierarchy
///
/// @return Pointer to the localisation config hierarchy
///
//****************************************************************************
CConfigBranch* CRecSetupCfgMgr::CreateLocalisationConfig() {
	CConfigBranch *pkParent = NULL;

	T_PGENNONVOL ptGenNonVol = pSYSTEM_INFO->GetFactoryConfig();

	if (ptGenNonVol != NULL) {
		// firstly create the top level config interface class
		QString  strTitle("");
		QString  strSubTitle("");

		strTitle = tr("Localization");

		pkParent = new CConfigBranch(ms_strLOCAL_KEY, strTitle, strSubTitle, ctMainMenuButton, false, true, 0, false,
				NULL);

		// now add the children
		// Language - although this is a ushort we will treat it as a bitfield list
		CShortBitFieldData *pkLanguageData = new CShortBitFieldData(&ptGenNonVol->Language, 16, 0, ms_strLocalLangList,
				bfeSingleSelList, 0, 0, false, 0, USHRT_MAX, true);
		strSubTitle = pkLanguageData->GetDataAsString();
		strTitle = tr("Language");
		CConfigItem *pkLanguage = new CConfigItem(ms_strLOCAL_LANG_KEY, strTitle, strSubTitle, ctItemButton,
				pkLanguageData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkLanguage);

		// Help Language - although this is a ushort we will treat it as a bitfield list
		CShortBitFieldData *pkHelpLangData = new CShortBitFieldData(
				reinterpret_cast< USHORT*>(&ptGenNonVol->Localisation), 5, 5, ms_strLocalHelpLangList, bfeSingleSelList,
				0, 0, false);
		strSubTitle = pkHelpLangData->GetDataAsString();
		strTitle = tr("Help Language");
		CConfigItem *pkHelpLang = new CConfigItem(ms_strLOCAL_HELP_LANG_KEY, strTitle, strSubTitle, ctItemButton,
				pkHelpLangData, false, true, 0, true, // @todo LOCK FOR NOW - will need to change once the other help languages are done								
				pkParent);
		pkParent->AddChild(pkHelpLang);

		// Time Zone
		CShortBitFieldData *pkTimeZoneData = new CShortBitFieldData(
				reinterpret_cast< USHORT*>(&ptGenNonVol->Localisation.TimeZone), 7, 0, ms_strTimeZoneList,
				bfeSingleSelList, 0, 0, false);
		strSubTitle = pkTimeZoneData->GetDataAsString();
		strTitle = tr("Time Zone");
		CConfigItem *pkTimeZone = new CConfigItem(ms_strLOCAL_TIME_ZONE_KEY, strTitle, strSubTitle, ctItemButton,
				pkTimeZoneData, false, true, 0, false, pkParent);

		pkParent->AddChild(pkTimeZone);

		CShortBitFieldData *pkDaylightSavingData = new CShortBitFieldData(
				reinterpret_cast< USHORT*>(&ptGenNonVol->Localisation), 1, 0, ms_strEnabledList, bfeBool, 0, 0, true);
		strSubTitle = pkDaylightSavingData->GetDataAsString();
		strTitle = tr("Daylight Saving");
		CConfigItem *pkDaylightSaving = new CConfigItem(ms_strLOCAL_TIME_DAYLIGHT_SAVING_KEY, strTitle, strSubTitle,
				ctItemButton, pkDaylightSavingData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkDaylightSaving);

		// Temp asprintf - although this is a ushort we will treat it as a bitfield list
		CShortBitFieldData *pkTempasprintfData = new CShortBitFieldData(
				reinterpret_cast< USHORT*>(&ptGenNonVol->Localisation), 2, 2, ms_strLocalTempasprintfList,
				bfeSingleSelList, 0, 0, false);
		strSubTitle = pkTempasprintfData->GetDataAsString();
		strTitle = tr("Temp. Units");
		CConfigItem *pkTempasprintf = new CConfigItem(ms_strLOCAL_TEMP_FORMAT_KEY, strTitle, strSubTitle, ctItemButton,
				pkTempasprintfData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkTempasprintf);

		// Mains Frequency - although this is a ushort we will treat it as a bitfield list
		CShortBitFieldData *pkMainsFreqData = new CShortBitFieldData(
				reinterpret_cast< USHORT*>(&ptGenNonVol->Localisation), 1, 4, ms_strLocalMainsFreqList,
				bfeSingleSelList, 0, 0, false);
		strSubTitle = pkMainsFreqData->GetDataAsString();
		strTitle = tr("Line Hz");
		CConfigItem *pkMainsFreq = new CConfigItem(ms_strLOCAL_MAINS_FREQ_KEY, strTitle, strSubTitle, ctItemButton,
				pkMainsFreqData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkMainsFreq);

		T_PGENERALCONFIG ptGeneralData = pSETUP->GetGeneralSetupConfig()->GetSystemGeneralBlock(CONFIG_MODIFIABLE);

		if (ptGeneralData != NULL) {
			// Paper Size - this will be a boolean type bitfield
			CShortBitFieldData *pkPaperSizeData = new CShortBitFieldData(
					reinterpret_cast< USHORT*>(&ptGeneralData->Printer), 1, 1, ms_strPrinterSizeList, bfeBool, 0, 0,
					false);
			strSubTitle = pkPaperSizeData->GetDataAsString();
			strTitle = tr("Paper Size");
			CConfigItem *pkPaperSize = new CConfigItem(ms_strPRINTER_LETTER_KEY, strTitle, strSubTitle, ctItemButton,
					pkPaperSizeData, false, true, 0, false, pkParent);
			pkParent->AddChild(pkPaperSize);
		}
	}
	return pkParent;
}
//****************************************************************************
// CConfigBranch *CreateCreditsConfig( )
///
/// Method that creates a credits config hierarchy
///
/// @return Pointer to the credits hierarchy
///
//****************************************************************************
CConfigBranch* CRecSetupCfgMgr::CreateCreditsConfig() {
	CConfigBranch *pkParent = NULL;

	T_PGENNONVOL ptFactory = pSYSTEM_INFO->GetFactoryConfig();

	if (ptFactory != NULL) {
		// firstly create the top level config interface class
		QString  strTitle("");
		strTitle = tr("Credits");
		QString  strSubTitle("");

		pkParent = new CConfigBranch(ms_strCREDITS_KEY, strTitle, strSubTitle, ctMainMenuButton, false, true, 0, false,
				NULL);

		// Serial number - this is a ULONG
		CULongData *pkSerialNoData = new CULongData(&ptFactory->SerialNumber, 0, ULONG_MAX, 0, 0, false);
		strTitle = tr("Serial No.");
		CConfigItem *pkSerialNo = new CConfigItem(ms_strCREDITS_SERIAL_NO_KEY, strTitle,
				pkSerialNoData->GetDataAsString(), ctItemButton, pkSerialNoData, false, true, 0, true, pkParent);
		pkParent->AddChild(pkSerialNo);

		// Credits - this is a ULONG - This will be read only
		CULongData *pkCreditsData = new CULongData(&ptFactory->Credits, 0, ULONG_MAX, 0, 0, false);
		strTitle = tr("Credits");
		CConfigItem *pkCredits = new CConfigItem(ms_strCREDITS_CREDITS_KEY, strTitle, pkCreditsData->GetDataAsString(),
				ctItemButton, pkCreditsData, false, true, 0, true, pkParent);
		pkParent->AddChild(pkCredits);

		// Options code - this is a autogenerated string
		QString   CfgData *pkOptionsCodeData = new QString   CfgData(ptFactory->OptionsCode,
		GENNONVOL_OPTIONSCODE_LEN, dtOptionsCode, 0, 0, true);
		strTitle = tr("Options Code");
		CConfigItem *pkOptionsCode = new CConfigItem(ms_strCREDITS_OPTIONS_CODE_KEY, strTitle,
				pkOptionsCodeData->GetDataAsString(), ctItemButton, pkOptionsCodeData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkOptionsCode);

		// Set the firmware options
		SetupFirmwareOptions(pkParent, &ptFactory->FWOptions);

	}

	return pkParent;
}
//****************************************************************************
// void SetupFirmwareOptions( CConfigBranch *pkParent, T_PFIRMOPTIONS ptFWOptions )
///
/// Method that sets up the firmware options heirarchy
///
/// @param[in/out] 		CConfigBranch *pkParent - Pointer to the parent owner class
/// @param[in]			T_PFIRMOPTIONS ptFWOptions - Pointer to the firmware options
///
//****************************************************************************
void CRecSetupCfgMgr::SetupFirmwareOptions(CConfigBranch *pkParent, T_PFIRMOPTIONS ptFWOptions) {
	QString  strTitle("");
	QString  strSubTitle("");
	USHORT usCreditsReqByOpt = 0;
	QString  strFWCredits("");

	strTitle = tr("Credits in Use");
	USHORT usCreditsInUse = 0;
	pSYSTEM_INFO->ValidateFWOptions(CSysInfo::fwoNoneRequired, usCreditsInUse);
	strSubTitle.asprintf(L"%u ", usCreditsInUse);
	strSubTitle += strTitle;
	strTitle = tr("Options");
	CConfigBranch *pkOptionsParent = new CConfigBranch(ms_strCREDITS_OPT_KEY, strTitle, strSubTitle, ctSubMenuButton,
			false, true, 0, false, pkParent);
	pkParent->AddChild(pkOptionsParent);

	// Math type - this will be a btifield list
	CLongBitFieldData *pkMathTypeData = new CLongBitFieldData(reinterpret_cast<ULONG*>(ptFWOptions), 2, 0,
			ms_strCreditsOptMathTypeList, bfeSingleSelList, 0, 0, true, dtFWOptBitField, true);
	strTitle = tr("Maths");
	// now add the credits for full maths and scripting
	pSYSTEM_INFO->GetOptionInfo(CSysInfo::fwoMathsFullBlock, strFWCredits, usCreditsReqByOpt);

	// don't show scripting if an eZTrend
	if (!GlbDevCaps.IsRecorderEzTrend()) {
		strFWCredits.asprintf(L" (%u/", usCreditsReqByOpt);
		strTitle += strFWCredits;
		pSYSTEM_INFO->GetOptionInfo(CSysInfo::fwoMathsFullScript, strFWCredits, usCreditsReqByOpt);
		strFWCredits.asprintf(L"%u)", usCreditsReqByOpt);
	} else {
		strFWCredits.asprintf(L" (%u)", usCreditsReqByOpt);
	}

	strTitle += strFWCredits;

	CConfigItem *pkMathType = new CConfigItem(ms_strCREDITS_OPT_MATH_TYPE_KEY, strTitle,
			pkMathTypeData->GetDataAsString(), ctItemButton, pkMathTypeData, false, true, 0, false, pkOptionsParent);
	pkOptionsParent->AddChild(pkMathType);

	// Events - this will be a boolean type bitfield
	CLongBitFieldData *pkEventsData = new CLongBitFieldData(reinterpret_cast<ULONG*>(ptFWOptions), 1, 2,
			ms_strEnabledList, bfeBool, 0, 0, true, dtFWOptBitField);
	strTitle = tr("Events");

	pSYSTEM_INFO->GetOptionInfo(CSysInfo::fwoEvents, strFWCredits, usCreditsReqByOpt);
	strFWCredits.asprintf(L" (%u)", usCreditsReqByOpt);
	strTitle += strFWCredits;

	CConfigItem *pkEvents = new CConfigItem(ms_strCREDITS_OPT_EVENTS_KEY, strTitle, pkEventsData->GetDataAsString(),
			ctItemButton, pkEventsData, false, true, 0, false, pkOptionsParent);
	pkOptionsParent->AddChild(pkEvents);

	// need to do a check here in case the fastscan has changed
	ms_strPenLogRateMsList = tr("500ms (2Hz)|200ms (5Hz)|100ms (10Hz)|20ms (50Hz)|");
	ms_strAINAcqRateList = tr("2Hz (500ms)|5Hz (200ms)|10Hz (100ms)|50Hz (20ms)|");

//#ifndef TTR6SETUP
	if (ptFWOptions->FastScan == FALSE) {
		// remove the last option (50Hz) from the logging list
		QString  str50HertzOption = CStringUtils::GetItemAtPos(ms_strPenLogRateMsList, lmr50Hertz);
		// add the delimiter
		str50HertzOption += L"|";
		ms_strPenLogRateMsList.Delete(ms_strPenLogRateMsList.size() - str50HertzOption.size(),
				str50HertzOption.size());

		// remove the last option (50Hz) from the analogue aquisition list
		str50HertzOption = CStringUtils::GetItemAtPos(ms_strAINAcqRateList, AI_ACQ_RATE_50HZ);
		// add the delimiter
		str50HertzOption += L"|";
		ms_strAINAcqRateList.Delete(ms_strAINAcqRateList.size() - str50HertzOption.size(),
				str50HertzOption.size());
	}
//#endif

	// only show fast scan if not an eZTrend
	if (!GlbDevCaps.IsRecorderEzTrend()) {
		// Fast Scan - this will be a boolean type bitfield
		CLongBitFieldData *pkFastScanData = new CLongBitFieldData(reinterpret_cast<ULONG*>(ptFWOptions), 1, 3,
				ms_strEnabledList, bfeBool, 0, 0, true, dtFWOptBitField);

		strTitle = tr("Fast Scan");

		pSYSTEM_INFO->GetOptionInfo(CSysInfo::fwoFastScan, strFWCredits, usCreditsReqByOpt);
		strFWCredits.asprintf(L" (%u)", usCreditsReqByOpt);
		strTitle += strFWCredits;

		CConfigItem *pkFastScan = new CConfigItem(ms_strCREDITS_OPT_FAST_SCAN_KEY, strTitle,
				pkFastScanData->GetDataAsString(), ctItemButton, pkFastScanData, false, true, 0, false,
				pkOptionsParent);
		pkOptionsParent->AddChild(pkFastScan);
	}

	// totals - this will be a boolean type bitfield
	CLongBitFieldData *pkTotalsData = new CLongBitFieldData(reinterpret_cast<ULONG*>(ptFWOptions), 1, 4,
			ms_strEnabledList, bfeBool, 0, 0, true, dtFWOptBitField);
	strTitle = tr("Totals");

	pSYSTEM_INFO->GetOptionInfo(CSysInfo::fwoTotals, strFWCredits, usCreditsReqByOpt);
	strFWCredits.asprintf(L" (%u)", usCreditsReqByOpt);
	strTitle += strFWCredits;

	CConfigItem *pkTotals = new CConfigItem(ms_strCREDITS_OPT_TOTALS_KEY, strTitle, pkTotalsData->GetDataAsString(),
			ctItemButton, pkTotalsData, false, true, 0, false, pkOptionsParent);
	pkOptionsParent->AddChild(pkTotals);

	// Only show custom screens if the device is not an eztrend
	T_DEV_TYPE devType = GlbDevCaps.GetDeviceType();

	if (!GlbDevCaps.IsRecorderEzTrend()) {
		// Custom screens - this will be a boolean type bitfield
		CLongBitFieldData *pkCustomScrnData = new CLongBitFieldData(reinterpret_cast<ULONG*>(ptFWOptions), 1, 5,
				ms_strEnabledList, bfeBool, 0, 0, true, dtFWOptBitField, true);
		strTitle = tr("Custom Scrn");

		pSYSTEM_INFO->GetOptionInfo(CSysInfo::fwoCustomScrn, strFWCredits, usCreditsReqByOpt);
		strFWCredits.asprintf(L" (%u)", usCreditsReqByOpt);
		strTitle += strFWCredits;

		CConfigItem *pkCustomScrn = new CConfigItem(ms_strCREDITS_OPT_CUST_SCRN_KEY, strTitle,
				pkCustomScrnData->GetDataAsString(), ctItemButton, pkCustomScrnData, false, true, 0, false,
				pkOptionsParent);
		pkOptionsParent->AddChild(pkCustomScrn);
	} else {
		// set the option to false just in case it is enabled
		ptFWOptions->CustomScreens = FALSE;
	}

	// Reports - this will be a boolean type bitfield
	CLongBitFieldData *pkReportsData = new CLongBitFieldData(reinterpret_cast<ULONG*>(ptFWOptions), 1, 6,
			ms_strEnabledList, bfeBool, 0, 0, true, dtFWOptBitField);
	strTitle = tr("Reports");

	pSYSTEM_INFO->GetOptionInfo(CSysInfo::fwoReports, strFWCredits, usCreditsReqByOpt);
	strFWCredits.asprintf(L" (%u)", usCreditsReqByOpt);
	strTitle += strFWCredits;

	CConfigItem *pkReports = new CConfigItem(ms_strCREDITS_OPT_REPORTS_KEY, strTitle, pkReportsData->GetDataAsString(),
			ctItemButton, pkReportsData, false, true, 0, false, pkOptionsParent);
	pkOptionsParent->AddChild(pkReports);

	// Maintenance - this will be a boolean type bitfield
	CLongBitFieldData *pkMaintData = new CLongBitFieldData(reinterpret_cast<ULONG*>(ptFWOptions), 1, 8,
			ms_strEnabledList, bfeBool, 0, 0, true, dtFWOptBitField);
	strTitle = tr("Maintenance");

	pSYSTEM_INFO->GetOptionInfo(CSysInfo::fwoMaintenance, strFWCredits, usCreditsReqByOpt);
	strFWCredits.asprintf(L" (%u)", usCreditsReqByOpt);
	strTitle += strFWCredits;

	CConfigItem *pkMaint = new CConfigItem(ms_strCREDITS_OPT_MAINT_KEY, strTitle, pkMaintData->GetDataAsString(),
			ctItemButton, pkMaintData, false, true, 0, false, pkOptionsParent);
	pkOptionsParent->AddChild(pkMaint);

	// Printer - this will be a boolean type bitfield
	CLongBitFieldData *pkPrinterData = new CLongBitFieldData(reinterpret_cast<ULONG*>(ptFWOptions), 1, 9,
			ms_strEnabledList, bfeBool, 0, 0, true, dtFWOptBitField);
	strTitle = tr("Printing");

	pSYSTEM_INFO->GetOptionInfo(CSysInfo::fwoPrintSupport, strFWCredits, usCreditsReqByOpt);
	strFWCredits.asprintf(L" (%u)", usCreditsReqByOpt);
	strTitle += strFWCredits;

	CConfigItem *pkPrinter = new CConfigItem(ms_strCREDITS_OPT_PRINTER_KEY, strTitle, pkPrinterData->GetDataAsString(),
			ctItemButton, pkPrinterData, false, true, 0, false, pkOptionsParent);
	pkOptionsParent->AddChild(pkPrinter);

	// Batch - this will be a boolean type bitfield
	// check that AMS2750 process isn't enabled which automatically enables batch
	bool bBatchFieldDisabled = false;
	if (ptFWOptions->AMS2750Process == TRUE) {
		// disable the batch field and deselect the credit
		bBatchFieldDisabled = true;
		ptFWOptions->Batch = FALSE;
	}

	CLongBitFieldData *pkBatchData = new CLongBitFieldData(reinterpret_cast<ULONG*>(ptFWOptions), 1, 14,
			ms_strEnabledList, bfeBool, 0, 0, true, dtFWOptBitField);
	strTitle = tr("Batch");

	pSYSTEM_INFO->GetOptionInfo(CSysInfo::fwoBatch, strFWCredits, usCreditsReqByOpt);
	strFWCredits.asprintf(L" (%u)", usCreditsReqByOpt);
	strTitle += strFWCredits;

	CConfigItem *pkBatch = new CConfigItem(ms_strCREDITS_OPT_BATCH_KEY, strTitle, pkBatchData->GetDataAsString(),
			ctItemButton, pkBatchData, false, !bBatchFieldDisabled, 0, false, pkOptionsParent);
	pkOptionsParent->AddChild(pkBatch);

	// Counters - this will be a boolean type bitfield
	CLongBitFieldData *pkCounterData = new CLongBitFieldData(reinterpret_cast<ULONG*>(ptFWOptions), 1, 15,
			ms_strEnabledList, bfeBool, 0, 0, true, dtFWOptBitField);
	strTitle = tr("Counters");

	pSYSTEM_INFO->GetOptionInfo(CSysInfo::fwoCounters, strFWCredits, usCreditsReqByOpt);
	strFWCredits.asprintf(L" (%u)", usCreditsReqByOpt);
	strTitle += strFWCredits;

	CConfigItem *pkCounter = new CConfigItem(ms_strCREDITS_OPT_COUNTERS_KEY, strTitle, pkCounterData->GetDataAsString(),
			ctItemButton, pkCounterData, false, true, 0, false, pkOptionsParent);
	pkOptionsParent->AddChild(pkCounter);

	// MODBUS Master - this will be a boolean type bitfield
	CLongBitFieldData *pkModbusMasterData = new CLongBitFieldData(reinterpret_cast<ULONG*>(ptFWOptions), 1, 17,
			ms_strEnabledList, bfeBool, 0, 0, true, dtFWOptBitField, false);
	strTitle = tr("Modbus Master");

	pSYSTEM_INFO->GetOptionInfo(CSysInfo::fwoModbusMaster, strFWCredits, usCreditsReqByOpt);
	strFWCredits.asprintf(L" (%u)", usCreditsReqByOpt);
	strTitle += strFWCredits;

	CConfigItem *pkModbusMaster = new CConfigItem(ms_strCREDITS_OPT_MODBUS_MASTER_KEY, strTitle,
			pkModbusMasterData->GetDataAsString(), ctItemButton, pkModbusMasterData, false, true, 0, false,
			pkOptionsParent);
	pkOptionsParent->AddChild(pkModbusMaster);

	// Remote Viewer - this will be a boolean type bitfield
	CLongBitFieldData *pkRemoteViewerData = new CLongBitFieldData(reinterpret_cast<ULONG*>(ptFWOptions), 1, 18,
			ms_strEnabledList, bfeBool, 0, 0, true, dtFWOptBitField, true);
	strTitle = tr("Remote View");

	pSYSTEM_INFO->GetOptionInfo(CSysInfo::fwoRemoteViewer, strFWCredits, usCreditsReqByOpt);
	strFWCredits.asprintf(L" (%u)", usCreditsReqByOpt);
	strTitle += strFWCredits;

	CConfigItem *pkRemoteViewer = new CConfigItem(ms_strCREDITS_OPT_REMOTE_VIEWER_KEY, strTitle,
			pkRemoteViewerData->GetDataAsString(), ctItemButton, pkRemoteViewerData, false, true, 0, false,
			pkOptionsParent);
	pkOptionsParent->AddChild(pkRemoteViewer);

	// Email - this will be a boolean type bitfield
	CLongBitFieldData *pkEmailData = new CLongBitFieldData(reinterpret_cast<ULONG*>(ptFWOptions), 1, 20,
			ms_strEnabledList, bfeBool, 0, 0, true, dtFWOptBitField);
	strTitle = tr("Email");

	pSYSTEM_INFO->GetOptionInfo(CSysInfo::fwoEmail, strFWCredits, usCreditsReqByOpt);
	strFWCredits.asprintf(L" (%u)", usCreditsReqByOpt);
	strTitle += strFWCredits;

	CConfigItem *pkEmail = new CConfigItem(ms_strCREDITS_OPT_EMAIL_KEY, strTitle, pkEmailData->GetDataAsString(),
			ctItemButton, pkEmailData, false, true, 0, false, pkOptionsParent);
	pkOptionsParent->AddChild(pkEmail);

	// Set up OPC UA entry
	CLongBitFieldData *pkOpcUaServerData = new CLongBitFieldData(reinterpret_cast<ULONG*>(ptFWOptions), 1, 30,
			ms_strEnabledList, bfeBool, 0, 0, true, dtFWOptBitField, true);

	strTitle = tr("OPC UA");

	pSYSTEM_INFO->GetOptionInfo(CSysInfo::fwoOpcUaServer, strFWCredits, usCreditsReqByOpt);
	strFWCredits.asprintf(L" (%u)", usCreditsReqByOpt);
	strTitle += strFWCredits;

	CConfigItem *pkOpcUaServer = new CConfigItem(ms_strCREDITS_OPT_OPCUASERVER_TITLE_KEY, strTitle,
			pkOpcUaServerData->GetDataAsString(), ctItemButton, pkOpcUaServerData, false, true, 0, false,
			pkOptionsParent);
	pkOptionsParent->AddChild(pkOpcUaServer);

	// OPC - this will be a boolean type bitfield
	/*	CLongBitFieldData *pkOPCData = new CLongBitFieldData(	reinterpret_cast< ULONG* >( ptFWOptions ),
	 1,
	 24,
	 ms_strEnabledList,
	 bfeBool,
	 0,
	 0,
	 true,
	 dtFWOptBitField,
	 true );

	 strTitle = tr("OPC");

	 pSYSTEM_INFO->GetOptionInfo( CSysInfo::fwoOPC, strFWCredits, usCreditsReqByOpt );
	 strFWCredits.asprintf( L" (%u)", usCreditsReqByOpt );
	 strTitle += strFWCredits;

	 CConfigItem *pkOPC = new CConfigItem(	ms_strCREDITS_OPT_OPC_TITLE_KEY,
	 strTitle,
	 pkOPCData->GetDataAsString(),						
	 ctItemButton,
	 pkOPCData,
	 false,
	 true,
	 0,
	 false,
	 pkOptionsParent );
	 pkOptionsParent->AddChild( pkOPC );*/
#ifndef XSERIESSETUP
	if (pGlbDal->IsRecorderEzTrend()) {
		// External SD for EzTrend
		CLongBitFieldData *pkExtSDData = new CLongBitFieldData(reinterpret_cast<ULONG*>(ptFWOptions), 1, 25,
				ms_strEnabledList, bfeBool, 0, 0, true, dtFWOptBitField);

		strTitle = tr("External SD");

		pSYSTEM_INFO->GetOptionInfo(CSysInfo::fwoExtSD, strFWCredits, usCreditsReqByOpt);
		strFWCredits.asprintf(L" (%u)", usCreditsReqByOpt);
		strTitle += strFWCredits;

		CConfigItem *pkExtSD = new CConfigItem(ms_strCREDITS_OPT_EXTSD_TITLE_KEY, strTitle,
				pkExtSDData->GetDataAsString(), ctItemButton, pkExtSDData, false, true, 0, false, pkOptionsParent);
		pkOptionsParent->AddChild(pkExtSD);
	}
//// Secure WSD //////////////////////////////////////////

#ifdef TTR6SETUP
		CLongBitFieldData *pkSWSDData = new CLongBitFieldData(	reinterpret_cast< ULONG* >( ptFWOptions ),
			1,
			27,
			ms_strEnabledList,
			bfeBool,
			0,
			0,
			true,
			dtFWOptBitField,
			true);

	strTitle = tr("Secure WSD");

		pSYSTEM_INFO->GetOptionInfo( CSysInfo::fwoSecureWSD, strFWCredits, usCreditsReqByOpt );
		usCreditsReqByOpt = 3;
		strFWCredits.asprintf( L" (%u)", usCreditsReqByOpt );
		
		strTitle += strFWCredits;

		CConfigItem *pkSecureWSD = new CConfigItem(	ms_strCREDITS_OPT_SECUREWSD_TITLE_KEY,
			strTitle,
			pkSWSDData->GetDataAsString(),						
			ctItemButton,
			pkSWSDData,
			false,
			true,
			0,
			false,
			pkOptionsParent );
		pkOptionsParent->AddChild( pkSecureWSD );

#endif
//PAR - 1-2NCR8HB : Remove RT Databus from Credits as it is not supported for now
//Removing this button, as this feature is not supported for this release
//In order to enable RTDATABUS in future, uncomment the following code.
///// RTDATABUS //////////////////////////////////////////
//CLongBitFieldData *pkRTBusData = new CLongBitFieldData(	reinterpret_cast< ULONG* >( ptFWOptions ),
//			1,
//			28,
//			ms_strEnabledList,
//			bfeBool,
//			0,
//			0,
//			true,
//			dtFWOptBitField,
//			true);
//
	//		strTitle = tr("RTData Bus");
//
//		pSYSTEM_INFO->GetOptionInfo( CSysInfo::fwoRTDataBus, strFWCredits, usCreditsReqByOpt );
//		strFWCredits.asprintf( L" (%u)", usCreditsReqByOpt );
//		strTitle += strFWCredits;
//
//		CConfigItem *pkRTDataBus = new CConfigItem(	ms_strCREDITS_OPT_RTDATABUS_TITLE_KEY,
//			strTitle,
//			pkRTBusData->GetDataAsString(),						
//			ctItemButton,
//			pkRTBusData,
//			false,
//			true,
//			0,
//			false,
//			pkOptionsParent );
//		pkOptionsParent->AddChild( pkRTDataBus );

	CLongBitFieldData *pkHWlockData = new CLongBitFieldData(reinterpret_cast<ULONG*>(ptFWOptions), 1, 29,
			ms_strEnabledList, bfeBool, 0, 0, true, dtFWOptBitField, true);

	strTitle = tr("Hardware Lock");

	pSYSTEM_INFO->GetOptionInfo(CSysInfo::fwoHWLock, strFWCredits, usCreditsReqByOpt);
	strFWCredits.asprintf(L" (%u)", usCreditsReqByOpt);
	strTitle += strFWCredits;

	CConfigItem *pkHWLock = new CConfigItem(ms_strCREDITS_OPT_HWLOCK_TITLE_KEY, strTitle,
			pkHWlockData->GetDataAsString(), ctItemButton, pkHWlockData, false, true, 0, false, pkOptionsParent);
	pkOptionsParent->AddChild(pkHWLock);

///////////////////////////////////////////////////////////
#endif
	// Password Net Sync - this will be a boolean type bitfield
#ifndef NO_PASSWORD_NET
	CLongBitFieldData *pkPwdNetData = new CLongBitFieldData(reinterpret_cast<ULONG*>(ptFWOptions), 1, 23,
			ms_strEnabledList, bfeBool, 0, 0, true, dtFWOptBitField, true);
	strTitle = tr("Pwd Net Sync");

	// get the currnet password netsync state of this recorder as if it is not a
	// standalone recorder then we cannot allow this device to have its netsync
	// firmware option disabled
	T_PASS_SYNC_STATES eNetSyncState = PASS_STATE_INDIVIDUAL;

#if ! defined ( TTR6SETUP )
	if (CPassSyncEngine::IsInstantiated()) {
		eNetSyncState = CPassSyncEngine::GetHandle()->GetState();
	}
#endif

	pSYSTEM_INFO->GetOptionInfo(CSysInfo::fwoPwdNetSync, strFWCredits, usCreditsReqByOpt);
	strFWCredits.asprintf(L" (%u)", usCreditsReqByOpt);
	strTitle += strFWCredits;

	CConfigItem *pkPwdNet = new CConfigItem(ms_strCREDITS_OPT_PWD_NET_SYNC_KEY, strTitle,
			pkPwdNetData->GetDataAsString(), ctItemButton, pkPwdNetData, false,
			(eNetSyncState != PASS_STATE_SLAVE_STATE) && (eNetSyncState != PASS_STATE_MASTER_STATE), 0, false,
			pkOptionsParent);
	pkOptionsParent->AddChild(pkPwdNet);
#endif // NO_PASSWORD_NET

	// NADCAP Recorder - this will be a boolean type bitfield
	CLongBitFieldData *pkNADCAPData = new CLongBitFieldData(reinterpret_cast<ULONG*>(ptFWOptions), 1, 7,
			ms_strEnabledList, bfeBool, 0, 0, true, dtFWOptBitField, true);
	strTitle = tr("AMS2750 Process");

	pSYSTEM_INFO->GetOptionInfo(CSysInfo::fwoNADCAPRecorder, strFWCredits, usCreditsReqByOpt);
	strFWCredits.asprintf(L" (%u)", usCreditsReqByOpt);
	strTitle += strFWCredits;

	CConfigItem *pkNADCAP = new CConfigItem(ms_strCREDITS_OPT_NADCAP_RECORDER_KEY, strTitle,
			pkNADCAPData->GetDataAsString(), ctItemButton, pkNADCAPData, false, (ptFWOptions->AMS2750TUS == FALSE), 0,
			false, pkOptionsParent);
	pkOptionsParent->AddChild(pkNADCAP);

	// TUS Mode - this will be a boolean type bitfield only available on an SX recorder
	const T_DEV_TYPE eDEV_TYPE = pDALGLB->GetDeviceType();
	if (eDEV_TYPE == DEV_ARISTOS_MULTIPLUS || eDEV_TYPE == DEV_PC_MULTI || eDEV_TYPE == DEV_SCR_MINITREND) {
		CLongBitFieldData *pkTUSModeData = new CLongBitFieldData(reinterpret_cast<ULONG*>(ptFWOptions), 1, 10,
				ms_strEnabledList, bfeBool, 0, 0, true, dtFWOptBitField, true);
		strTitle = tr("AMS2750 TUS");

		pSYSTEM_INFO->GetOptionInfo(CSysInfo::fwoTUSMode, strFWCredits, usCreditsReqByOpt);
		strFWCredits.asprintf(L" (%u)", usCreditsReqByOpt);
		strTitle += strFWCredits;

		CConfigItem *pkTUSMode = new CConfigItem(ms_strCREDITS_OPT_TUS_MODE_KEY, strTitle,
				pkTUSModeData->GetDataAsString(), ctItemButton, pkTUSModeData, false,
				(ptFWOptions->AMS2750Process == FALSE), 0, false, pkOptionsParent);
		pkOptionsParent->AddChild(pkTUSMode);
	}

	// Extra pens - this is a special ULONG which requires slightly different validation
	CULongData *pkExPensData = new CULongData(&ptFWOptions->ExtraPens, 0,
	pDEVICE_INFO->GetMaxExtrasPensForDevice(), 0, 0, true, dtFWPens, "", true);
	strTitle = tr("Extra Pens");

	pSYSTEM_INFO->GetOptionInfo(CSysInfo::fwoExtraPens, strFWCredits, usCreditsReqByOpt);
	strFWCredits.asprintf(L" (%u)", usCreditsReqByOpt);
	strTitle += strFWCredits;

	CConfigItem *pkExPens = new CConfigItem(ms_strCREDITS_OPT_EXTRA_PENS_KEY, strTitle, pkExPensData->GetDataAsString(),
			ctItemButton, pkExPensData, false, true, 0, false, pkOptionsParent);
	pkOptionsParent->AddChild(pkExPens);

}
//****************************************************************************
// CConfigBranch *CreateDemoConfig( )
///
/// Method that creates a demo config hierarchy
///
/// @return Pointer to the demo hierarchy
///
//****************************************************************************
CConfigBranch* CRecSetupCfgMgr::CreateDemoConfig() {
	CConfigBranch *pkParent = NULL;

	T_PGENNONVOL ptFactory = pSYSTEM_INFO->GetFactoryConfig();

	if (ptFactory != NULL) {
		// firstly create the top level config interface class
		QString  strTitle("");
		strTitle = tr("Demo Traces");
		QString  strSubTitle("");

		pkParent = new CConfigBranch(ms_strDEMO_BOARDS_KEY, strTitle, strSubTitle, ctMainMenuButton, false, true, 0,
				false, NULL);

		// Set the demoboard enabled options
		SetupDemoBoardEnabledOptions(pkParent, ptFactory->IsDemoBoard);
	}

	return pkParent;
}
//****************************************************************************
// void SetupDemoBoardEnabledOptions( CConfigBranch *pkParent, USHORT usDemoBoard )
///
/// Method that sets up the demoboard enabled options
///
/// @param[in/out] 		CConfigBranch *pkParent - Pointer to the parent owner class
/// @param[in]			USHORT *pusDemoBoardEnabled - Pointer to the demoboard enabled array
///
//****************************************************************************
void CRecSetupCfgMgr::SetupDemoBoardEnabledOptions(CConfigBranch *pkParent,
USHORT *pusDemoBoardEnabled) {
	QString  strTitle("");
	QString  strSubTitle("");
	USHORT usNO_ENABLED = 0;
	USHORT usCount = 0;
	WCHAR wcSlotName(L'A');
	QString  strSlotName("");

	// loop through all the demoboards
	const USHORT usNO_OF_SLOTS =
			(GlbDevCaps.IsRecorderMulti() && GlbDevCaps.GetDeviceType() != DEV_SCR_MINITREND) ? 6 : 2;

	for (usCount = 0; usCount < usNO_OF_SLOTS; usCount++) {
		// IsDemoBoard USHORT - treat as a bitfield
		CShortBitFieldData *pkDemoBoardData = new CShortBitFieldData(&pusDemoBoardEnabled[usCount], 16, 0,
				ms_strDemoBoardEnabledList, bfeSingleSelList, 0, 0, true, 0, USHRT_MAX, true);
		strSubTitle = pkDemoBoardData->GetDataAsString();
		strTitle = tr("Demo Board");
		strSlotName.asprintf(L" %c", wcSlotName);
		strTitle += strSlotName;
		CConfigItem *pkDemoBoard = new CConfigItem(ms_strDEMO_BOARDS_BOARD_KEY, strTitle, strSubTitle, ctItemButton,
				pkDemoBoardData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkDemoBoard);

		// increment the slot by 1
		wcSlotName += 1;
	}
}
//****************************************************************************
// CConfigBranch *CreateProductionConfig( )
///
/// Method that creates a production config hierarchy
///
/// @return Pointer to the production hierarchy
///
//****************************************************************************
CConfigBranch* CRecSetupCfgMgr::CreateProductionConfig() {
	CConfigBranch *pkParent = NULL;

	T_PGENNONVOL ptFactory = pSYSTEM_INFO->GetFactoryConfig();

	if (ptFactory != NULL) {
		// firstly create the top level config interface class
		QString  strTitle("");
		strTitle = tr("Production");
		QString  strSubTitle("");

		pkParent = new CConfigBranch(ms_strPRODUCTION_KEY, strTitle, strSubTitle, ctMainMenuButton, false, true, 0,
				false, NULL);

		// Serial number - this is a ULONG
		CULongData *pkSerialNoData = new CULongData(&ptFactory->SerialNumber, 100000, 999999, 0, 0, false);
		strTitle = tr("Serial No.");
		CConfigItem *pkSerialNo = new CConfigItem(ms_strPRODUCTION_SERIAL_NO_KEY, strTitle,
				pkSerialNoData->GetDataAsString(), ctItemButton, pkSerialNoData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkSerialNo);
	}

	return pkParent;
}
//****************************************************************************
// CConfigBranch *CreateTCPIPConfig( )
///
/// Method that creates a TCPIP settings config hierarchy
///
/// @return Pointer to the TCPIP settings config hierarchy
///
//****************************************************************************
CConfigBranch* CRecSetupCfgMgr::CreateTCPIPConfig() {
	QString  strTitle("");
	QString  strSubTitle("");
	CConfigBranch *pkParent = NULL;
	CSingleLock lock(&m_GlbSetupMutex);
	lock.Lock();
	CCommsSetupConfig *pkCommsConfig = pGlbSetup->GetCommsSetupConfig();
	lock.Unlock();

	T_PCOMMUNICATIONS ptCommsData = NULL;
	if (pkCommsConfig != NULL) {
		ptCommsData = pkCommsConfig->GetCommsBlock(CONFIG_MODIFIABLE);
	}

	if (ptCommsData != NULL) {
		T_NETWORK *ptEthernet = &ptCommsData->Ethernet;
		strTitle = tr("TCP/IP Settings");
		pkParent = new CConfigBranch(ms_strTCPIP_KEY, strTitle, strSubTitle, ctSubMenuButton, false, true, 0, false,
				NULL);

		// Use Static IP Address - this will be a boolean bitfield
		CShortBitFieldData *pkUseStaticIPData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptEthernet), 1, 0,
				ms_strEnabledList, bfeBool, 0, 0, true, 0, USHRT_MAX, true);
		strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptEthernet->UseStaticIP);
		strTitle = tr("Static IP");
		CConfigItem *pkUseStaticIP = new CConfigItem(ms_strTCPIP_USE_STATIC_IP_ADDR_KEY, strTitle, strSubTitle,
				ctItemButton, pkUseStaticIPData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkUseStaticIP);

		CULongData *pkIPAddrData = new CULongData(&ptEthernet->IPAddress.L, 0, ULONG_MAX, 0, 0, false, dtIPAddr,
				"", true);

		// show the configured IP address if static or the address given by the DHCP server if dynamic
		if (ptEthernet->UseStaticIP) {
			strSubTitle = pkIPAddrData->GetDataAsString();
		} else {
			strSubTitle = CRegistryKey::GetDHCPIPAddress();
		}
		strTitle = tr("IP Address");
		CConfigItem *pkIPAddr = new CConfigItem(ms_strTCPIP_STATIC_IP_ADDR_KEY, strTitle, strSubTitle, ctItemButton,
				pkIPAddrData, false, (ptEthernet->UseStaticIP == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkIPAddr);

		// subnet mask
		CULongData *pkSNMaskData = new CULongData(&ptEthernet->SubNetMask.L, 0, ULONG_MAX, 0, 0, false, dtIPAddr,
				"", true);

		strSubTitle = pkSNMaskData->GetDataAsString();
		strTitle = tr("Sub Net Mask");
		CConfigItem *pkSNMask = new CConfigItem(ms_strTCPIP_SUB_NET_MASK_KEY, strTitle, strSubTitle, ctItemButton,
				pkSNMaskData, false, (ptEthernet->UseStaticIP == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkSNMask);

		// Default gateway
		CULongData *pkDefGateData = new CULongData(&ptEthernet->DefaultGateway.L, 0, ULONG_MAX, 0, 0, false, dtIPAddr,
				"", true);

		strSubTitle = pkDefGateData->GetDataAsString();
		strTitle = tr("Gateway");
		CConfigItem *pkDefGate = new CConfigItem(ms_strTCPIP_DEF_GATEWAY_KEY, strTitle, strSubTitle, ctItemButton,
				pkDefGateData, false, (ptEthernet->UseStaticIP == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkDefGate);

		QString  strPriDNSAddr("");
		QString  strSecDNSAddr("");
		QString  strPriWINSAddr("");
		QString  strSecWINSAddr("");
		strSubTitle = "";
		strTitle = tr("DNS/WINS/MDNS");

		// Primary DNS
		CULongData *pkPriDNSData = new CULongData(&ptEthernet->DNSServer[0].L, 0, ULONG_MAX, 0, 0, false, dtIPAddr,
				"", true);

		// Secondary DNS
		CULongData *pkSecDNSData = new CULongData(&ptEthernet->DNSServer[1].L, 0, ULONG_MAX, 0, 0, false, dtIPAddr,
				"", true);

		// Primary WINS
		CULongData *pkPriWINSData = new CULongData(&ptEthernet->WINSServer[0].L, 0, ULONG_MAX, 0, 0, false, dtIPAddr,
				"", true);

		// Secondary WINS
		CULongData *pkSecWINSData = new CULongData(&ptEthernet->WINSServer[1].L, 0, ULONG_MAX, 0, 0, false, dtIPAddr,
				"", true);

		if (ptEthernet->EnableDNS == FALSE) {
			QString  strEnableDNS("");
			strEnableDNS = tr("DNS");
			strSubTitle = strEnableDNS + L"/";
			strPriDNSAddr = pkPriDNSData->GetDataAsString();
			strSecDNSAddr = pkSecDNSData->GetDataAsString();
		} else {
			// get the DNS addresses - should be two strings delimited by a null character
			QString  strDNSAddrs(CRegistryKey::GetDHCPDNSIPAddress());
			int iDelimPos = strDNSAddrs.indexOf(L"|", 0);
			if (iDelimPos > 0) {
				strPriDNSAddr = strDNSAddrs.left(iDelimPos);
				strSecDNSAddr = strDNSAddrs.right(strDNSAddrs.size() - (iDelimPos + 1));
			}
		}
		if (ptEthernet->EnableWINS == FALSE) {
			QString  strEnableWINS("");
			strEnableWINS = tr("WINS");
			strSubTitle += strEnableWINS + L"/";
			strPriWINSAddr = pkPriWINSData->GetDataAsString();
			strSecWINSAddr = pkSecWINSData->GetDataAsString();
		} else {
			// get the WINS addresses - should be two strings delimited by a null character
			QString  strWINSAddrs(CRegistryKey::GetDHCPWINSIPAddress());
			int iDelimPos = strWINSAddrs.indexOf(L"|", 0);
			if (iDelimPos > 0) {
				strPriWINSAddr = strWINSAddrs.left(iDelimPos);
				strSecWINSAddr = strWINSAddrs.right(strWINSAddrs.size() - (iDelimPos + 1));
			}
		}
		if (ptEthernet->EnableMDNS == FALSE) {
			QString  strEnableMDNS("");
			strEnableMDNS = tr("MDNS");
			strSubTitle += strEnableMDNS + L"/";
		}
		// check ifv the string is empty still
		if (strSubTitle == "") {
			// add the none string
			strSubTitle = tr("Automatic");
		} else {
			// remove the last character which should be a '/'
			strSubTitle.Delete(strSubTitle.size() - 1, 1);
		}
		CConfigBranch *pkDNSWINSParent = new CConfigBranch(ms_strTCPIP_DNS_WINS_KEY, strTitle, strSubTitle,
				ctSubMenuButton, false, true, 0, false, pkParent);
		pkParent->AddChild(pkDNSWINSParent);

		// Enable DNS - this will be a boolean bitfield
		CShortBitFieldData *pkEnDNSData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptEthernet), 1, 1,
				ms_strEnabledList, bfeBool, 0, 0, true, 0, 1, true);
		strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptEthernet->EnableDNS);
		strTitle = tr("Auto DNS");
		CConfigItem *pkEnDNS = new CConfigItem(ms_strTCPIP_ENABLE_DNS_KEY, strTitle, strSubTitle, ctItemButton,
				pkEnDNSData, false, true, 0, false, pkDNSWINSParent);
		pkDNSWINSParent->AddChild(pkEnDNS);

		// Primary DNS
		strTitle = tr("Pri. DNS Addr");
		CConfigItem *pkPriDNS = new CConfigItem(ms_strTCPIP_DNS_PRI_ADDR_KEY, strTitle, strPriDNSAddr, ctItemButton,
				pkPriDNSData, false, (ptEthernet->EnableDNS == FALSE), 0, false, pkDNSWINSParent);
		pkDNSWINSParent->AddChild(pkPriDNS);

		// Secondary DNS
		strTitle = tr("Sec. DNS Addr");
		CConfigItem *pkSecDNS = new CConfigItem(ms_strTCPIP_DNS_SEC_ADDR_KEY, strTitle, strSecDNSAddr, ctItemButton,
				pkSecDNSData, false, (ptEthernet->EnableDNS == FALSE), 0, false, pkDNSWINSParent);
		pkDNSWINSParent->AddChild(pkSecDNS);

		// Enable WINS - this will be a boolean bitfield
		CShortBitFieldData *pkEnWINSData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptEthernet), 1, 3,
				ms_strEnabledList, bfeBool, 0, 0, true, 0, 1, true);
		strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptEthernet->EnableWINS);
		strTitle = tr("Auto WINS");
		CConfigItem *pkEnWINS = new CConfigItem(ms_strTCPIP_ENABLE_WINS_KEY, strTitle, strSubTitle, ctItemButton,
				pkEnWINSData, false, true, 0, false, pkDNSWINSParent);
		pkDNSWINSParent->AddChild(pkEnWINS);

		// Primary WINS
		strTitle = tr("Pri. WINS Addr");
		CConfigItem *pkPriWINS = new CConfigItem(ms_strTCPIP_WINS_PRI_ADDR_KEY, strTitle, strPriWINSAddr, ctItemButton,
				pkPriWINSData, false, (ptEthernet->EnableWINS == FALSE), 0, false, pkDNSWINSParent);
		pkDNSWINSParent->AddChild(pkPriWINS);

		// Secondary WINS
		strTitle = tr("Sec. WINS Addr");
		CConfigItem *pkSecWINS = new CConfigItem(ms_strTCPIP_WINS_SEC_ADDR_KEY, strTitle, strSecWINSAddr, ctItemButton,
				pkSecWINSData, false, (ptEthernet->EnableWINS == FALSE), 0, false, pkDNSWINSParent);
		pkDNSWINSParent->AddChild(pkSecWINS);

		// Enable MDNS - this will be a boolean bitfield
		CShortBitFieldData *pkEnMDNSData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptEthernet), 1, 2,
				ms_strEnabledList, bfeBool, 0, 0, true, 0, 1, true);
		strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptEthernet->EnableMDNS);
		strTitle = tr("Auto MDNS");
		CConfigItem *pkEnMDNS = new CConfigItem(ms_strTCPIP_ENABLE_MDNS_KEY, strTitle, strSubTitle, ctItemButton,
				pkEnMDNSData, false, true, 0, false, pkDNSWINSParent);
		pkDNSWINSParent->AddChild(pkEnMDNS);

		// Sockets Sub menu
		strTitle = tr("Ports");
		strSubTitle.asprintf(L"%u, %u", ptEthernet->HTTPSocket, ptEthernet->ModbusSocket);
		CConfigBranch *pkSockParent = new CConfigBranch(ms_strTCPIP_QAbstractSocketS_KEY, strTitle, strSubTitle, ctSubMenuButton,
				false, true, 0, false, pkParent);
		pkParent->AddChild(pkSockParent);

		// HTTP Socket
		CUShortData *pkHTTPSockData = new CUShortData(&ptEthernet->HTTPSocket, 1, USHRT_MAX, 0, 0, true,
				dtUnsignedShort, "", true);
		strTitle = tr("HTTP");
		CConfigItem *pkHTTPSock = new CConfigItem(ms_strTCPIP_SOCK_HTTP_KEY, strTitle,
				pkHTTPSockData->GetDataAsString(), ctItemButton, pkHTTPSockData, false, true, 0, false, pkSockParent);
		pkSockParent->AddChild(pkHTTPSock);

		/*
		 // FTP Data Socket
		 CUShortData *pkFTPDataSockData = new CUShortData(	&ptEthernet->FTPSocket[0],
		 0,
		 USHRT_MAX,
		 0,
		 0,
		 true,
		 dtUnsignedShort,
		 QString   ::fromWCharArray(""),
		 true );
		 strTitle = tr("FTP Data");
		 CConfigItem *pkFTPDataSock = new CConfigItem(	ms_strTCPIP_SOCK_FTP_DATA_KEY,
		 strTitle,
		 pkFTPDataSockData->GetDataAsString(),
		 ctItemButton,
		 pkFTPDataSockData,
		 false,
		 true,
		 0,
		 false,
		 pkSockParent );
		 pkSockParent->AddChild( pkFTPDataSock );

		 // FTP Control Socket
		 CUShortData *pkFTPConSockData = new CUShortData(	&ptEthernet->FTPSocket[1],
		 0,
		 USHRT_MAX,
		 0,
		 0,
		 true );

		 strTitle = tr("FTP Control");
		 CConfigItem *pkFTPConSock = new CConfigItem(	ms_strTCPIP_SOCK_FTP_CONTROL_KEY,
		 strTitle,
		 pkFTPConSockData->GetDataAsString(),						
		 ctItemButton,
		 pkFTPConSockData,
		 false,
		 true,
		 0,
		 false,
		 pkSockParent );
		 pkSockParent->AddChild( pkFTPConSock );
		 */

		// MODBUS Socket
		CUShortData *pkModbusSockData = new CUShortData(&ptEthernet->ModbusSocket, 1, USHRT_MAX, 0, 0, true);

		strTitle = tr("Modbus");
		CConfigItem *pkModbusSock = new CConfigItem(ms_strTCPIP_SOCK_MODBUS_KEY, strTitle,
				pkModbusSockData->GetDataAsString(), ctItemButton, pkModbusSockData, false, true, 0, false,
				pkSockParent);
		pkSockParent->AddChild(pkModbusSock);

		/* REMOVED AS THIS FUNCTIONAILITY WILL NOT BE INCLUDED FOR SOME TIME
		 // Trendbus Socket
		 CUShortData *pkTrendSockData = new CUShortData(	&ptEthernet->TrendbusSocket,
		 0,
		 USHRT_MAX,
		 0,
		 0,
		 false );

		 strSubTitle.asprintf( L"%u", ptEthernet->TrendbusSocket );
		 strTitle = tr("Trendbus");
		 CConfigItem *pkTrendSock = new CConfigItem(	ms_strTCPIP_SOCK_TRENDBUS_KEY,
		 strTitle,
		 strSubTitle,						
		 ctItemButton,
		 pkTrendSockData,
		 false,
		 true,
		 0,
		 false,
		 pkSockParent );
		 pkSockParent->AddChild( pkTrendSock );
		 */
	}
	return pkParent;
}

//****************************************************************************
// CConfigBranch *CreateSecurityConfig( )
///
/// Method that creates a SecurityOptions Comms config hierarchy
///
/// @return Pointer to the SecurityOptions Comms config hierarchy
///
//****************************************************************************
CConfigBranch* CRecSetupCfgMgr::CreateSecurityConfig() {
	WCHAR szDbgMsg[512];
	QString  strTitle("");
	QString  strSubTitle("");
	CConfigBranch *pkParent = NULL;
	CSingleLock lock(&m_GlbSetupMutex);
	lock.Lock();
	CCommsSetupConfig *pkCommsConfig = pGlbSetup->GetCommsSetupConfig();
	lock.Unlock();
	T_PCOMMUNICATIONS ptCommsData = NULL;
	if (pkCommsConfig != NULL) {
		ptCommsData = pkCommsConfig->GetCommsBlock(CONFIG_MODIFIABLE);
	}

	if (ptCommsData != NULL) {
		T_SECURITYOPTIONS *ptSecurity = &ptCommsData->SecurityOptions;

		strTitle = tr("Security Options");
		pkParent = new CConfigBranch(ms_strSecurity_KEY, strTitle, strSubTitle, ctSubMenuButton, false, true, 0, false,
				NULL);

/////////////////////////////////////////////////////////////////////////////////////////////

		CShortBitFieldData *pkTLSPROTOCOLDATA = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptSecurity), 4, 0,
				ms_strTLSProtocolList, bfeSingleSelList, 0, 0, false, 0, 0, false);
		strSubTitle = pkTLSPROTOCOLDATA->GetDataAsString();
		strTitle = tr("TLS Version");
		//strStrTLSList = tr("TLS 1.0|TLS 1.1|TLS 1.2|");
		CConfigItem *pkUSETLSPROTOCOL = new CConfigItem(ms_strSecurity_USE_TLS_PROTOCOL_KEY, strTitle, strSubTitle,
				ctItemButton, pkTLSPROTOCOLDATA, false, false, 0, false, pkParent);

		pkParent->AddChild(pkUSETLSPROTOCOL);
		swprintf(szDbgMsg, L"CRecSetupCfgMgr::CreateSecurityConfig : TLS %d\n", ptSecurity->TLSProtocol);
		OutputDebugString(szDbgMsg);
///////////////////////////////////////////////////////////////////////////////////////////////

		CShortBitFieldData *pkGlobalCAData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptSecurity), 1, 4,
				ms_strEnabledList, bfeBool, 0, 0, true, 0, 1, true);
		//strSubTitle = CStringUtils::GetItemAtPos( ms_strEnabledList, ptSecurity->CACertificate );
		strTitle = tr("Custom Certificate");
		CConfigItem *pkUseGLOBALCA = new CConfigItem(ms_strSecurity_USE_GLOBAL_CA_KEY, strTitle,
				pkGlobalCAData->GetDataAsString(), ctItemButton, pkGlobalCAData, false, true, 0, false, pkParent);
		//strSubTitle = CStringUtils::GetItemAtPos( ms_strEnabledList, ptSecurity->CACertificate );
		pkParent->AddChild(pkUseGLOBALCA);

		swprintf(szDbgMsg, L"CRecSetupCfgMgr::CreateSecurityConfig : GblobalCA %d\n", ptSecurity->CACertificate);
		OutputDebugString(szDbgMsg);

		// now add the password path field
		QString   CfgData *pkPfxPassword = new QString   CfgData(ptSecurity->CertPfxPassword,
		SECURITYOPTIONS_CERTPFXPASSWORD_LEN,
		/*dtString,*/dtPassword, 0, 0, false);
		strTitle = tr("CERT Password");

		CConfigItem *pkPassword = new CConfigItem(ms_strSecurity_PfxPassword, strTitle,
				pkPfxPassword->GetDataAsString(), ctItemButton, pkPfxPassword, false,
				(ptSecurity->CACertificate != FALSE), 0, false, pkParent);
		pkParent->AddChild(pkPassword);

		CShortBitFieldData *pkRDTEnData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptSecurity), 1, 5,
				ms_strEnabledList, bfeBool, 0, 0, false, true, 1, true);
		strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptSecurity->RDT);
		strTitle = tr("RDT");
		CConfigItem *pkRDTEn = new CConfigItem(ms_str_RDT_KEY, strTitle, strSubTitle, ctItemButton, pkRDTEnData, true,
				true, 0, false, pkParent);

		swprintf(szDbgMsg, L"CRecSetupCfgMgr::CreateSecurityConfig : RDT %d\n", ptSecurity->RDT);
		OutputDebugString(szDbgMsg);
		pkParent->AddChild(pkRDTEn);

		///swprintf( szDbgMsg, L"CRecSetupCfgMgr::CreateSecurityConfig : RDT %d\n",ptSecurity->RDT);
		//OutputDebugString(szDbgMsg);
////////////////////////////////////////////////////////////////////////////////////////////////
	}
	return pkParent;
}

//****************************************************************************
// CConfigBranch *CreateModbusCommsConfig( )
///
/// Method that creates a Modbus Comms config hierarchy
///
/// @return Pointer to the Modbus Comms config hierarchy
///
//****************************************************************************
CConfigBranch* CRecSetupCfgMgr::CreateModbusCommsConfig() {
	CConfigBranch *pkParent = NULL;
	QString  strTitle("");
	QString  strSubTitle("");

	CSingleLock lock(&m_GlbSetupMutex);
	lock.Lock();
	CCommsSetupConfig *pkCommsConfig = pGlbSetup->GetCommsSetupConfig();
	lock.Unlock();
	T_PCOMMUNICATIONS ptCommsData = NULL;
	if (pkCommsConfig != NULL) {
		ptCommsData = pkCommsConfig->GetCommsBlock(CONFIG_MODIFIABLE);
	}

	if (ptCommsData != NULL) {
		T_MODBUSDEVICE *ptModbus = &ptCommsData->ModbusSlave;
		strTitle = tr("RS485");
		pkParent = new CConfigBranch(ms_strMODBUS_COMMS_KEY, strTitle, strTitle, ctSubMenuButton, false, true, 0, false,
				NULL);

		T_RS485PORT *ptSerialPort = &ptCommsData->SerialPort;

		// Baud Rate - this will be a bitfield list
		CShortBitFieldData *pkBaudRateData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptSerialPort), 4, 0,
				ms_strSerPortBaudRateList, bfeSingleSelList, 0, 0, false);
		strSubTitle = pkBaudRateData->GetDataAsString();
		strTitle = tr("Baud Rate");
		CConfigItem *pkBaudRate = new CConfigItem(ms_strMODBUS_COMMS_BAUD_RATE_KEY, strTitle, strSubTitle, ctItemButton,
				pkBaudRateData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkBaudRate);

		// Byte Options - this will be a numerical bitfield even though it is a BYTE
		CShortBitFieldData *pkByteOptsData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptSerialPort), 4, 4,
				ms_strSerPortByteOptsList, bfeSingleSelList, 0, 0, false);
		strSubTitle = pkByteOptsData->GetDataAsString();
		strTitle = tr("Byte Options");
		CConfigItem *pkByteOpts = new CConfigItem(ms_strMODBUS_COMMS_BYTE_OPT_KEY, strTitle, strSubTitle, ctItemButton,
				pkByteOptsData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkByteOpts);

		// Line Turn around - this will be a bitfield list
		QString  strMilliseconds("");
		strMilliseconds = tr("ms");

		// Reply Delay - this will be a bitfield list
		CByteData *pkLineTurnData = new CByteData(&ptSerialPort->LineTurnAround, 1, UCHAR_MAX, 0, 0, false,
				strMilliseconds);

		strTitle = tr("Line Turn Around");
		CConfigItem *pkLineTurn = new CConfigItem(ms_strMODBUS_COMMS_LINE_TURN_AROUND_KEY, strTitle,
				pkLineTurnData->GetDataAsString(true), ctItemButton, pkLineTurnData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkLineTurn);

		// Reply Delay - this will be a bitfield list
		CByteData *pkReplayDelayData = new CByteData(&ptSerialPort->ReplyDelay, 0, 100, 0, 0, false, strMilliseconds);
		strTitle = tr("Reply Delay");
		CConfigItem *pkReplayDelay = new CConfigItem(ms_strMODBUS_COMMS_REPLY_DELAY_KEY, strTitle,
				pkReplayDelayData->GetDataAsString(true), ctItemButton, pkReplayDelayData, false, true, 0, false,
				pkParent);
		pkParent->AddChild(pkReplayDelay);
	}
	return pkParent;
}
//****************************************************************************
// CConfigBranch *CreateModbusSlaveConfig( )
///
/// Method that creates a Modbus Slave config hierarchy
///
/// @return Pointer to the Modbus Slave config hierarchy
///
//****************************************************************************
CConfigBranch* CRecSetupCfgMgr::CreateModbusSlaveConfig() {
	CConfigBranch *pkParent = NULL;
	QString  strTitle("");

	CSingleLock lock(&m_GlbSetupMutex);
	lock.Lock();
	CCommsSetupConfig *pkCommsConfig = pGlbSetup->GetCommsSetupConfig();
	lock.Unlock();
	T_PCOMMUNICATIONS ptCommsData = NULL;
	if (pkCommsConfig != NULL) {
		ptCommsData = pkCommsConfig->GetCommsBlock(CONFIG_MODIFIABLE);
	}

	if (ptCommsData != NULL) {
		T_MODBUSDEVICE *ptModbus = &ptCommsData->ModbusSlave;
		strTitle = tr("Slave");
		pkParent = new CConfigBranch(ms_strMODBUS_SLAVE_KEY, strTitle, strTitle, ctSubMenuButton, false, true, 0, false,
				NULL);

		// Modbus enable - this will be a boolean bitfield
		CShortBitFieldData *pkModbusEnData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptModbus), 1, 0,
				ms_strEnabledList, bfeBool, 0, 0, true);
		strTitle = tr("Enabled");
		CConfigItem *pkModbusEn = new CConfigItem(ms_strMODBUS_SLAVE_ENABLED_KEY, strTitle,
				pkModbusEnData->GetDataAsString(), ctItemButton, pkModbusEnData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkModbusEn);

		// check if the any of the masters slaves are set to RS485 - if yes then we must force this slave
		// to the ethernet port as we are not allowed both configured to the same port
		// loop through all the master slaves - if any have ethernet specified 
		bool bEnabledMasterSlaveUsingRS485 = false;
		for (USHORT usSlaveCount = 0; usSlaveCount < MODBUSMASTER_SLAVE_SIZE; usSlaveCount++) {
			// check if it is enabled and which port it is using
			if (( pSYSTEM_INFO->FWOptionModbusMasterAvailable() == TRUE) && (ptCommsData->ModbusMaster.Enabled == TRUE)
					&& (ptCommsData->ModbusMaster.Slave[usSlaveCount].Enabled == TRUE)
					&& (ptCommsData->ModbusMaster.Slave[usSlaveCount].Port == PORT_SERIAL)) {
				// using RS485 therefore set the flag to true and break from the loop
				bEnabledMasterSlaveUsingRS485 = true;
				break;
			}
		}

		// TAC ISSUE -: EDF Issue with Qxe - Firmware Solution for 
		// Modbus Communication via Ethernet on Qxe having no RS 485 Port.

		// Check if Rs485 board fitted in QXe if not display ethernet port only.

		// check if the master slaves are using the RS485 port and the recorder slave is too
		if (((bEnabledMasterSlaveUsingRS485 && (ptCommsData->ModbusSlave.Port == PORT_SERIAL))
				|| pDALGLB->GetRS485fitted() == FALSE)) {
			// both using RS485 therefore force this to ethernet
			ptCommsData->ModbusSlave.Port = PORT_ETHER;
		}

		// Modbus port - this will be a bitfield list
		CShortBitFieldData *pkModbusPortData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptModbus), 2, 1,
				ms_strModbusPortList, bfeSingleSelList, 0, 0, true);
		strTitle = tr("Port");
		CConfigItem *pkModbusPort = new CConfigItem(ms_strMODBUS_SLAVE_PORT_KEY, strTitle,
				pkModbusPortData->GetDataAsString(), ctItemButton, pkModbusPortData, false, (ptModbus->Enabled == TRUE),
				0, bEnabledMasterSlaveUsingRS485 || (pDALGLB->GetRS485fitted() == FALSE), pkParent);
		pkParent->AddChild(pkModbusPort);

		// Modbus protocol - this will be a bitfield list
		CShortBitFieldData *pkModbusProtoData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptModbus), 2, 3,
				ms_strModbusProtocolList, bfeSingleSelList, 0, 0, false);
		strTitle = tr("Protocol");
		CConfigItem *pkModbusProto = new CConfigItem(ms_strMODBUS_SLAVE_PROTOCOL_KEY, strTitle,
				pkModbusProtoData->GetDataAsString(), ctItemButton, pkModbusProtoData, false,
				(ptModbus->Enabled == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkModbusProto);

		// Address - this will be a BYTE
		CByteData *pkAddrData = new CByteData(&ptModbus->Address, 1, UCHAR_MAX, 0, 0, false);
		strTitle = tr("Slave ID");
		CConfigItem *pkAddr = new CConfigItem(ms_strMODBUS_SLAVE_ADDR_KEY, strTitle, pkAddrData->GetDataAsString(),
				ctItemButton, pkAddrData, false, (ptModbus->Enabled == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkAddr);
	}
	return pkParent;
}
//****************************************************************************
// CConfigBranch *CreateModbusMasterConfig( )
///
/// Method that creates a Modbus Master config hierarchy
///
/// @return Pointer to the Modbus Master config hierarchy
///
//****************************************************************************
CConfigBranch* CRecSetupCfgMgr::CreateModbusMasterConfig() {
	CConfigBranch *pkParent = NULL;

	QString  strTitle("");
	QString  strSubTitle("");
	QString  strSeconds("");
	strSeconds = tr("Secs.");

	CSingleLock lock(&m_GlbSetupMutex);
	lock.Lock();
	CCommsSetupConfig *pkCommsConfig = pGlbSetup->GetCommsSetupConfig();
	lock.Unlock();

	T_PCOMMUNICATIONS ptCommsData = NULL;
	if (pkCommsConfig != NULL) {
		ptCommsData = pkCommsConfig->GetCommsBlock(CONFIG_MODIFIABLE);
	}

	if (ptCommsData != NULL) {
		T_MODBUSMASTER *ptModbus = &ptCommsData->ModbusMaster;
		strTitle = tr("Master");
		strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptModbus->Enabled);
		pkParent = new CConfigBranch(ms_strMODBUS_MASTER_KEY, strTitle, strSubTitle, ctSubMenuButton, false, true, 0,
				false, NULL);

		// Modbus master enable - this will be a boolean bitfield
		CShortBitFieldData *pkModbusEnData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptModbus), 1, 0,
				ms_strEnabledList, bfeBool, 0, 0, true);
		strTitle = tr("Enabled");
		CConfigItem *pkModbusEn = new CConfigItem(ms_strMODBUS_MASTER_ENABLED_KEY, strTitle, strSubTitle, ctItemButton,
				pkModbusEnData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkModbusEn);

		// Poll Rate - this will be a ushort
		CUShortData *pkPollRateData = new CUShortData(&ptModbus->PollRate, 1, 60, 0, 0, false, dtUnsignedShort,
				strSeconds);

		strTitle = tr("Poll Rate");
		CConfigItem *pkPollRate = new CConfigItem(ms_strMODBUS_MASTER_POLL_RATE_KEY, strTitle,
				pkPollRateData->GetDataAsString(true), ctItemButton, pkPollRateData, false, (ptModbus->Enabled == TRUE),
				0, false, pkParent);
		pkParent->AddChild(pkPollRate);

		// Legacy ethernet settings enable - this will be a boolean bitfield
		CShortBitFieldData *pkLegacyEtherData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptModbus), 1, 1,
				ms_strEnabledList, bfeBool, 0, 0, false);
		strTitle = tr("Legacy Ether.");
		CConfigItem *pkLegacyEther = new CConfigItem(ms_strMODBUS_MASTER_LEGACY_ETHERNET_KEY, strTitle,
				pkLegacyEtherData->GetDataAsString(), ctItemButton, pkLegacyEtherData, false,
				(ptModbus->Enabled == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkLegacyEther);

		// check if the slave is set to RS485 - if yes then we must force all the master's slaves
		// to use the ethernet port as we are not allowed both configured to the same port
		bool bEnabledSlaveUsingRS485 = false;
		// check if it is enabled and which port it is using
		if (( pSYSTEM_INFO->FWOptionModbusSlaveAvailable() == TRUE) && (ptCommsData->ModbusSlave.Enabled == TRUE)
				&& (ptCommsData->ModbusSlave.Port == PORT_SERIAL)) {
			// using RS485 therefore set the flag to true
			bEnabledSlaveUsingRS485 = true;
		}

		QString  strSlaveKey("");
		// now add the individual slaves
		for (USHORT usCount = 0; usCount < MODBUSMASTER_SLAVE_SIZE; usCount++) {
			strTitle.asprintf(IDS_CFG_COMMS_SVC_MODBUS_MENU_MASTER_SLAVE_TITLE, usCount + 1);
			strSlaveKey.asprintf(ms_strMODBUS_MASTER_SLAVE_KEY, usCount);
			strSubTitle.asprintf(L"%s %s",
					CStringUtils::GetItemAtPos(ms_strEnabledList, ptModbus->Slave[usCount].Enabled),
					ptModbus->Slave[usCount].FriendlyName);
			CConfigBranch *pkSlave = new CConfigBranch(strSlaveKey, strTitle, strSubTitle, ctSubMenuButton, false,
					(ptModbus->Enabled == TRUE), 0, false, pkParent);

			pkParent->AddChild(pkSlave);

			// add the slave information IF the modbus master is enabled as there is no point in adding
			// the sub menu data if the user can't even get to it because the button is disabled
			if (ptModbus->Enabled == TRUE) {
				// set the indivudal slave
				SetupModbusMasterSlave(usCount, pkSlave, &ptModbus->Slave[usCount], bEnabledSlaveUsingRS485);

			}
		}
	}

	return pkParent;
}
//****************************************************************************
// CConfigItem *RefreshModbusMasterConfigTree(	CConfigItem *pkModifiedItem,
//												const USHORT usSLAVE_NO )
///
// Method that refreshes the data for a slave branch of a modbus master configuration menu,
// usually following a change to one of the slaves that requires the tree structure to be 
// regenerated because it is different
///
/// @param[in]		CConfigItem *pkModifiedItem - The modified data item
/// @param[in]		const USHORT usSLAVE_NO - The slave number to replace - zero based
///
/// @return Pointer to the new slave config hierarchy
///
//****************************************************************************
CConfigItem* CRecSetupCfgMgr::RefreshModbusMasterConfigTree(CConfigItem *pkModifiedItem, const USHORT usSLAVE_NO) {
	CConfigItem *pkNewCfgItem = NULL;
	CConfigInterface *pkTopParent = NULL;

	// Store the key name of this item
	const QString  strKEY(pkModifiedItem->GetKey());

	CConfigInterface *pkSlaveParent = pkModifiedItem;

	// get the top level parent
	while (pkSlaveParent->GetParent() != NULL) {
		pkSlaveParent = pkSlaveParent->GetParent();
	}

	CSingleLock lock(&m_GlbSetupMutex);
	lock.Lock();
	CCommsSetupConfig *pkCommsConfig = pGlbSetup->GetCommsSetupConfig();
	lock.Unlock();
	T_PCOMMUNICATIONS ptCommsData = NULL;
	if (pkCommsConfig != NULL) {
		ptCommsData = pkCommsConfig->GetCommsBlock(CONFIG_MODIFIABLE);
	}

	if (ptCommsData != NULL) {
		T_MODBUSMASTER *ptModbus = &ptCommsData->ModbusMaster;

		QString  strSlaveKey("");
		QString  strTitle("");
		QString  strSubTitle("");

		strTitle.asprintf(IDS_CFG_COMMS_SVC_MODBUS_MENU_MASTER_SLAVE_TITLE, usSLAVE_NO + 1);
		strSlaveKey.asprintf(ms_strMODBUS_MASTER_SLAVE_KEY, usSLAVE_NO);
		strSubTitle.asprintf(L"%s %s", CStringUtils::GetItemAtPos(ms_strEnabledList, ptModbus->Slave[usSLAVE_NO].Enabled),
				ptModbus->Slave[usSLAVE_NO].FriendlyName);
		CConfigBranch *pkNewSlave = new CConfigBranch(strSlaveKey, strTitle, strSubTitle, ctSubMenuButton, false,
				(ptModbus->Enabled == TRUE), 0, false, pkSlaveParent);

		// add the slave information IF the modbus master is enabled as there is no point in adding
		// the sub menu data if the user can't even get to it because the button is disabled
		if (ptModbus->Enabled == TRUE) {
			// check if the slave is set to RS485 - if yes then we must force all the master's slaves
			// to use the ethernet port as we are not allowed both configured to the same port
			bool bEnabledSlaveUsingRS485 = false;
			// check which port it is using
			if (( pSYSTEM_INFO->FWOptionModbusSlaveAvailable() == TRUE) && (ptCommsData->ModbusSlave.Enabled == TRUE)
					&& (ptCommsData->ModbusSlave.Port == PORT_SERIAL)) {
				// using RS485 therefore set the flag to true
				bEnabledSlaveUsingRS485 = true;
			}

			// set the indivudal slave
			SetupModbusMasterSlave(usSLAVE_NO, pkNewSlave, &ptModbus->Slave[usSLAVE_NO], bEnabledSlaveUsingRS485);

		}

		// replace the existing event with this new one
		CConfigBranch *pkBranch = static_cast<CConfigBranch*>(pkSlaveParent);
		pkBranch->ReplaceChild(pkNewSlave);

		// we now need to get the new child for the particular item that was being modified
		pkNewCfgItem = static_cast<CConfigItem*>(indexOfChildByKey(strKEY, pkNewSlave, 2));
	} else {
		// there has been a problem
		pkNewCfgItem = static_cast<CConfigItem*>(pkTopParent);
	}

	return pkNewCfgItem;
}
//****************************************************************************
//	void SetupModbusMasterSlave(	const USHORT usSLAVE_INDEX,
//									CConfigBranch *pkSlaveParent,
//									T_MODBUSSLAVEDEV *ptSlaveDev,
//									const bool bEnabledSlaveUsingRS485 )
///
/// Method that creates the config branch for a modbus master slave device
///
/// @param[in]		const USHORT usSLAVE_NO - The index of the slave in the modbus master config structure
/// @param[in/out]	CConfigBranch *pkSlaveParent - Pointer to the slave devices parent config branch
/// @param[in]		T_MODBUSSLAVEDEV *ptSlaveDev - Pointer to the slave devices configuration structure
/// @param[in]		const bool bEnabledSlaveUsingRS485 - Flag indicating if the MODBUS slave (not this master slave) 
///					is configured to use the RS485 port
///
//****************************************************************************
void CRecSetupCfgMgr::SetupModbusMasterSlave(const USHORT usSLAVE_INDEX, CConfigBranch *pkSlaveParent,
		T_MODBUSSLAVEDEV *ptSlaveDev, const bool bEnabledSlaveUsingRS485) {
	bool bSlaveEnabled = (ptSlaveDev->Enabled == TRUE);
	QString  strTitle("");

	// slave enable - this will be a boolean bitfield
	CShortBitFieldData *pkSlaveEnData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptSlaveDev), 1, 0,
			ms_strEnabledList, bfeBool, 0, 0, true);
	strTitle = tr("Enabled");
	CConfigItem *pkSlaveEn = new CConfigItem(ms_strMODBUS_MASTER_ENABLED_KEY, strTitle,
			pkSlaveEnData->GetDataAsString(), ctItemButton, pkSlaveEnData, false, true, 0, false, pkSlaveParent);
	pkSlaveParent->AddChild(pkSlaveEn);

	// friendly name
	QString   CfgData *pkFriendlyNameData = new QString   CfgData(ptSlaveDev->FriendlyName,
	MODBUSSLAVEDEV_FRIENDLYNAME_LEN, dtString, 0, 0, true);
	strTitle = tr("Friendly Name");
	CConfigItem *pkFriendlyName = new CConfigItem(ms_strMODBUS_MASTER_SLAVE_FRIENDLY_NAME_KEY, strTitle,
			pkFriendlyNameData->GetDataAsString(), ctItemButton, pkFriendlyNameData, false, bSlaveEnabled, 0, false,
			pkSlaveParent);
	pkSlaveParent->AddChild(pkFriendlyName);

	// Address - this will be a BYTE
	CByteData *pkAddrData = new CByteData(&ptSlaveDev->Address, 1, UCHAR_MAX, 0, 0, false);
	strTitle = tr("ID");
	CConfigItem *pkAddr = new CConfigItem(ms_strMODBUS_MASTER_SLAVE_ID_KEY, strTitle, pkAddrData->GetDataAsString(),
			ctItemButton, pkAddrData, false, bSlaveEnabled, 0, false, pkSlaveParent);
	pkSlaveParent->AddChild(pkAddr);

	// TAC ISSUE -: EDF Issue with Qxe - Firmware Solution for 
	// Modbus Communication via Ethernet on Qxe having no RS 485 Port.

	// Check if Rs485 board fitted in QXe if not display ethernet port only.

	// check if the recorder slave is using the RS485 port and this master slave is too
	if ((bEnabledSlaveUsingRS485 && (ptSlaveDev->Port == PORT_SERIAL)) || pDALGLB->GetRS485fitted() == FALSE) {
		// both using RS485 therefore force this to ethernet
		ptSlaveDev->Port = PORT_ETHER;
	}

	// Modbus port - this will be a bitfield list
	CShortBitFieldData *pkModbusPortData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptSlaveDev), 2, 1,
			ms_strModbusPortList, bfeSingleSelList, 0, 0, true);
	strTitle = tr("Port");
	CConfigItem *pkModbusPort = new CConfigItem(ms_strMODBUS_MASTER_SLAVE_PORT_KEY, strTitle,
			pkModbusPortData->GetDataAsString(), ctItemButton, pkModbusPortData, false, bSlaveEnabled, 0,
			bEnabledSlaveUsingRS485 || (pDALGLB->GetRS485fitted() == FALSE), pkSlaveParent);
	pkSlaveParent->AddChild(pkModbusPort);

	// if etherenet port then add the network name/ip address
	if (ptSlaveDev->Port == PORT_ETHER) {
		// network name
		QString   CfgData *pkNetworkNameData = new QString   CfgData(ptSlaveDev->NetworkName,
		MODBUSSLAVEDEV_NETWORKNAME_LEN, dtString, 0, 0, false);
		strTitle = tr("Network Name");
		CConfigItem *pkNetworkName = new CConfigItem(ms_strMODBUS_MASTER_SLAVE_NETWORK_NAME_KEY, strTitle,
				pkNetworkNameData->GetDataAsString(), ctItemButton, pkNetworkNameData, false, bSlaveEnabled, 0, false,
				pkSlaveParent);
		pkSlaveParent->AddChild(pkNetworkName);
	}

	// Modbus protocol - this will be a bitfield list
	CShortBitFieldData *pkModbusProtoData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptSlaveDev), 2, 3,
			ms_strModbusProtocolList, bfeSingleSelList, 0, 0, false);
	strTitle = tr("Protocol");
	CConfigItem *pkModbusProto = new CConfigItem(ms_strMODBUS_MASTER_SLAVE_PROTOCOL_KEY, strTitle,
			pkModbusProtoData->GetDataAsString(), ctItemButton, pkModbusProtoData, false, bSlaveEnabled, 0, false,
			pkSlaveParent);
	pkSlaveParent->AddChild(pkModbusProto);

	// now add the individual transactions
	QString  strKey("");
	QString  strSubTitle("");

	for (USHORT usCount = 0; usCount < MODBUSSLAVEDEV_TRANSACTIONS_SIZE; usCount++) {
		T_MODBUSTX *ptTX = &ptSlaveDev->Transactions[usCount];
		// add the individual transactions sub menu item
		strTitle.asprintf(IDS_CFG_COMMS_SVC_MODBUS_MENU_MASTER_SLAVE_TX_ITEM_TITLE, usCount + 1);
		if (ptTX->Enabled) {
			if (ptTX->Dir == mttIN) {
				strSubTitle.asprintf(L"%s %u %u", CStringUtils::GetItemAtPos(ms_strModbusMasterSlaveDirList, ptTX->Dir),
						ptTX->StartAddr, ptTX->NoOfItems);
			} else {
				QString  strAdditionalInfo("");
				if (ptTX->NoOfItems > 1) {
					strAdditionalInfo.asprintf(L" - %u", ptTX->DataItemStart + (ptTX->NoOfItems - 1));
				}
				strSubTitle.asprintf(IDS_CFG_COMMS_SVC_MODBUS_MENU_MASTER_SLAVE_TX_ITEM_OUTS_SUBTITLE,
						CStringUtils::GetItemAtPos(ms_strModbusMasterSlaveDirList, ptTX->Dir), ptTX->DataItemStart,
						strAdditionalInfo);
			}
		} else {
			strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptTX->Enabled);
		}
		strKey.asprintf(ms_strMODBUS_MASTER_SLAVE_TX_ITEM_KEY, usCount);
		CConfigBranch *pkTXParent = new CConfigBranch(strKey, strTitle, strSubTitle, ctSubMenuButton, false,
				bSlaveEnabled, 0, false, pkSlaveParent);

		pkSlaveParent->AddChild(pkTXParent);

		// setup the individual transaction if the transaction
		SetupModbusMasterSlaveTransaction(usCount, pkTXParent, ptTX, usSLAVE_INDEX);

	}
}
//****************************************************************************
//	void SetupModbusMasterSlaveTransaction(	const USHORT usTX_INDEX,
//											CConfigBranch *pkTXParent,
//											T_MODBUSTX *ptTX,
//											const USHORT usSLAVE_INDEX )
///
/// Method that creates the config branch for a modbus master's slave transaction
///
/// @param[in]		const USHORT usTX_INDEX - The index of the transaction in the slave config structure
/// @param[in/out]	CConfigBranch *pkTXParent - Pointer to the TX parent config branch
/// @param[in]		T_MODBUSTX *ptTX - Pointer to the transacion configuration structure
/// @param[in]		const USHORT usSLAVE_INDEX - The index number of the slave within the config structures
///
//****************************************************************************
void CRecSetupCfgMgr::SetupModbusMasterSlaveTransaction(const USHORT usTX_INDEX, CConfigBranch *pkTXParent,
		T_MODBUSTX *ptTX, const USHORT usSLAVE_INDEX) {
	bool bTXEnabled = (ptTX->Enabled == TRUE);
	QString  strTitle("");
	QString  strSubTitle("");

	// Transaction enable - this will be a boolean bitfield
	CShortBitFieldData *pkTXEnData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptTX), 1, 0, ms_strEnabledList,
			bfeBool, 0, 0, true);
	strTitle = tr("Enabled");
	CConfigItem *pkTXEn = new CConfigItem(ms_strMODBUS_MASTER_SLAVE_TX_ITEM_ENABLE_KEY, strTitle,
			pkTXEnData->GetDataAsString(), ctItemButton, pkTXEnData, false, true, 0, false, pkTXParent);
	pkTXParent->AddChild(pkTXEn);

	// direction - this will be a boolean bitfield
	CShortBitFieldData *pkDirectionData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptTX), 1, 1,
			ms_strModbusMasterSlaveDirList, bfeSingleSelList, 0, 0, true);
	strTitle = tr("Direction");
	CConfigItem *pkDirection = new CConfigItem(ms_strMODBUS_MASTER_SLAVE_TX_ITEM_DIR_KEY, strTitle,
			pkDirectionData->GetDataAsString(), ctItemButton, pkDirectionData, false, bTXEnabled, 0, false, pkTXParent);
	pkTXParent->AddChild(pkDirection);

	strTitle = tr("Command");
	// command - this will be a single selection list
	if (ptTX->Dir == mttIN) {
		CShortBitFieldData *pkMapData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptTX), 2, 2,
				ms_strModbusMasterSlaveMapList, bfeSingleSelList, 0, 0, false);

		CConfigItem *pkMap = new CConfigItem(ms_strMODBUS_MASTER_SLAVE_TX_ITEM_MAP_KEY, strTitle,
				pkMapData->GetDataAsString(), ctItemButton, pkMapData, false, bTXEnabled, 0, false, pkTXParent);
		pkTXParent->AddChild(pkMap);
	} else {
		strSubTitle = tr("Preset Multiple Regs(16)");
		CConfigItem *pkMap = new CConfigItem(ms_strMODBUS_MASTER_SLAVE_TX_ITEM_MAP_KEY, strTitle, strSubTitle,
				ctItemButton, NULL, false, bTXEnabled, 0, true, pkTXParent);
		pkTXParent->AddChild(pkMap);
	}

	// there can be a few different data types - show the types as a single selection list
	// force outs to float always
	if (ptTX->Dir == mttOUT) {
		ptTX->DataType = midFLOAT;
	}
	CShortBitFieldData *pkDataTypeData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptTX), 4, 4,
			ms_strModbusMasterSlaveInsDataTypeList, bfeSingleSelList, 0, 0, false);
	strTitle = tr("Data Type");
	CConfigItem *pkDataType = new CConfigItem(ms_strMODBUS_MASTER_SLAVE_TX_DATA_TYPE_KEY, strTitle,
			pkDataTypeData->GetDataAsString(), ctItemButton, pkDataTypeData, false, bTXEnabled, 0,
			(ptTX->Dir == mttOUT), // lock the item if this is an out
			pkTXParent);
	pkTXParent->AddChild(pkDataType);

	// make the type dependant on the direction
	if (ptTX->Dir == mttOUT) {
		// type is output - this will only be pens for now
		CShortBitFieldData *pkDataTypeData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptTX), 3, 11,
				ms_strModbusMasterSlaveOutsDataTypeList, bfeSingleSelList, 0, 0, false);
		strTitle = tr("Data Item");
		CConfigItem *pkDataType = new CConfigItem(ms_strMODBUS_MASTER_SLAVE_TX_DATA_ITEM_KEY, strTitle,
				pkDataTypeData->GetDataAsString(), ctItemButton, pkDataTypeData, false, bTXEnabled, 0, false,
				pkTXParent);
		pkTXParent->AddChild(pkDataType);

		// Start Address - this will be a USHORT
		CUShortData *pkStartAddrData = new CUShortData(&ptTX->DataItemStart, 1, V6_MAX_PENS, 0, 0, true);

		strTitle = tr("Start Pen");
		CConfigItem *pkStartAddr = new CConfigItem(ms_strMODBUS_MASTER_SLAVE_TX_DATA_ITEM_START_KEY, strTitle,
				pkStartAddrData->GetDataAsString(true), ctItemButton, pkStartAddrData, false, bTXEnabled, 0, false,
				pkTXParent);
		pkTXParent->AddChild(pkStartAddr);

	}

	// Start Address - this will be a USHORT
	CUShortData *pkStartAddrData = new CUShortData(&ptTX->StartAddr, 1, 0xFFFF, 0, 0, true);

	strTitle = tr("Dec. Start Addr");
	CConfigItem *pkStartAddr = new CConfigItem(ms_strMODBUS_MASTER_SLAVE_TX_ITEM_START_KEY, strTitle,
			pkStartAddrData->GetDataAsString(true), ctItemButton, pkStartAddrData, false, bTXEnabled, 0, false,
			pkTXParent);
	pkTXParent->AddChild(pkStartAddr);

	CByteData *pkNoOfItemsData = new CByteData(&ptTX->NoOfItems, 1, 128, 0, 0, true);
	strTitle = tr("No. Of Items");

	// add the maths/SVC information if this is an input
	if (ptTX->Dir == mttIN) {
		if (ptTX->NoOfItems == 1) {
			strSubTitle.asprintf(L"%s  SCV[%u,%u,1]", pkNoOfItemsData->GetDataAsString(), usSLAVE_INDEX + 1,
					usTX_INDEX + 1);
		} else {
			strSubTitle.asprintf(L"%s  SCV[%u,%u,1] - SCV[%u,%u,%u]", pkNoOfItemsData->GetDataAsString(),
					usSLAVE_INDEX + 1, usTX_INDEX + 1, usSLAVE_INDEX + 1, usTX_INDEX + 1, ptTX->NoOfItems);
		}
	} else {
		// this is an out so simply display the number
		strSubTitle = pkNoOfItemsData->GetDataAsString();
	}

	CConfigItem *pkNoOfItems = new CConfigItem(ms_strMODBUS_MASTER_SLAVE_TX_ITEM_NO_OF_ITEMS_KEY, strTitle, strSubTitle,
			ctItemButton, pkNoOfItemsData, false, bTXEnabled, 0, false, pkTXParent);
	pkTXParent->AddChild(pkNoOfItems);

}
//****************************************************************************
// CConfigBranch *CreateSNTPConfig( )
///
/// Method that creates a SNTP config hierarchy
///
/// @return Pointer to the SNTP config hierarchy
///
//****************************************************************************
CConfigBranch* CRecSetupCfgMgr::CreateSNTPConfig() {
	CConfigBranch *pkParent = NULL;
	QString  strTitle("");
	QString  strSubTitle("");

	CSingleLock lock(&m_GlbSetupMutex);
	lock.Lock();
	CCommsSetupConfig *pkCommsConfig = pGlbSetup->GetCommsSetupConfig();
	lock.Unlock();
	T_PCOMMUNICATIONS ptCommsData = NULL;
	if (pkCommsConfig != NULL) {
		ptCommsData = pkCommsConfig->GetCommsBlock(CONFIG_MODIFIABLE);
	}

	if (ptCommsData != NULL) {
		T_SNTPSERVER *ptSNTP = &ptCommsData->TimeServer;
		strTitle = tr("SNTP");

		// check the SNTP state
		if (ptSNTP->ClientEnable && ptSNTP->ServerEnable) {
			QString  strTemp("");
			strSubTitle = tr("Client");
			strTemp = tr("Server");
			strSubTitle += L"/" + strTemp;
		} else if (ptSNTP->ClientEnable) {
			strSubTitle = tr("Client");
		} else if (ptSNTP->ServerEnable) {
			strSubTitle = tr("Server");
		} else {
			// nethier enabled so just use the cross symbol
			strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, 0);
		}
		pkParent = new CConfigBranch(ms_strSNTP_KEY, strTitle, strSubTitle, ctSubMenuButton, false, true, 0, false,
				NULL);

		// SNTP Server enable - this will be a boolean bitfield
		CShortBitFieldData *pkServerEnData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptSNTP), 1, 0,
				ms_strEnabledList, bfeBool, 0, 0, false, 0, 1, true);
		strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptSNTP->ServerEnable);
		strTitle = tr("Server Enable");
		CConfigItem *pkServerEn = new CConfigItem(ms_strSNTP_SERVER_ENABLE_KEY, strTitle, strSubTitle, ctItemButton,
				pkServerEnData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkServerEn);

		// SNTP Client enable - this will be a boolean bitfield
		CShortBitFieldData *pkClientEnData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptSNTP), 1, 1,
				ms_strEnabledList, bfeBool, 0, 0, true, 0, 1, true);
		strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptSNTP->ClientEnable);
		strTitle = tr("Client Enable");
		CConfigItem *pkClientEn = new CConfigItem(ms_strSNTP_CLIENT_ENABLE_KEY, strTitle, strSubTitle, ctItemButton,
				pkClientEnData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkClientEn);

		// Server name - this will be a string
		QString   CfgData *pkServerNameData = new QString   CfgData(ptSNTP->ServerName,
		SNTPSERVER_SERVERNAME_LEN, dtString, 0, 0, false);
		strTitle = tr("Server Name");
		CConfigItem *pkServerName = new CConfigItem(ms_strSNTP_SERVER_NAME_KEY, strTitle,
				pkServerNameData->GetDataAsString(), ctItemButton, pkServerNameData, false,
				(ptSNTP->ClientEnable == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkServerName);

		QString  strSeconds("");
		strSeconds = tr("Secs.");

		// Client update period - this will be a USHORT
		//The lower limit value has been restricted to 600 for this release as per the OS limitations.
		CUShortDataForSNTPUpdatePeriod *pkUpdatePerData = new CUShortDataForSNTPUpdatePeriod(&ptSNTP->UpdatePeriod, 600, //310, //Reverted the fix for - 1-1VK5GH3 Recorder does not allow to configure SNTP synch period less than 10 minutes 
				3600, 0, 0, false, dtUnsignedShort, strSeconds);

		strTitle = tr("Period");
		CConfigItem *pkUpdatePer = new CConfigItem(ms_strSNTP_CLIENT_UPDATE_PER_KEY, strTitle,
				pkUpdatePerData->GetDataAsString(true), ctItemButton, pkUpdatePerData, false,
				(ptSNTP->ClientEnable == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkUpdatePer);

		// Client update threshold - this will be a ULONG
		CULongDataForSNTPThreshold *pkUpdateThreshData = new CULongDataForSNTPThreshold(&ptSNTP->UpdateThreshold, 10,
				108000, 0, 0, false, dtUnsignedLong, strSeconds);

		strTitle = tr("Threshold");
		CConfigItem *pkUpdateThresh = new CConfigItem(ms_strSNTP_CLIENT_UPDATE_THRESH_KEY, strTitle,
				pkUpdateThreshData->GetDataAsString(true), ctItemButton, pkUpdateThreshData, false,
				(ptSNTP->ClientEnable == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkUpdateThresh);

	}
	return pkParent;
}
//****************************************************************************
// CConfigBranch* CreateDigitalIOConfig( )
///
/// Method that creates a Digital IO config hierarchy
///
/// @return			Pointer to the top-level parent of an digital IO config hierarchy
///
//****************************************************************************
CConfigBranch* CRecSetupCfgMgr::CreateDigitalIOConfig() {
	CConfigBranch *pkDigitalIOParent = NULL;

	// Check the digtial setup class exists
	CIOSetupConfig *pkDigitalIOSetupCfg = pSETUP->GetIOSetupConfig();
	CSlotMap *pkSlotMap = CSlotMap::GetHandle();
	if ((pkDigitalIOSetupCfg != NULL) && (pkSlotMap != NULL)) {

		// firstly create the top level config interface class
		const USHORT usNO_OF_DIGITALS = MAX_DIGITAL_IO;
		QString  strTitle("");
		strTitle = tr("Alarm/Digital IO");

		pkDigitalIOParent = new CConfigBranch(ms_strDIGIO_KEY, strTitle, strTitle, ctMainMenuButton, false, true, 0,
				false, NULL);

		// now create a load of child digital inputs/outputs and add them to the parent
		for (USHORT usCount = 0; usCount < usNO_OF_DIGITALS; usCount++) {
			USHORT usSlotNo = 0;
			USHORT usBoardChanNum = 0;

			USHORT usChannelCaps = 0;

			// check the slot number and board channel number are okay and that an analogue input card exists in this slot
			if (GetDigitalIOChannelInfo(usCount + 1, usSlotNo, usBoardChanNum, usChannelCaps)) {
				// Get the digitial IO data structure
				T_PDIGCHANNEL ptDigitalIOData = NULL;

				ptDigitalIOData = pkDigitalIOSetupCfg->GetDigital(usSlotNo, usBoardChanNum, CONFIG_MODIFIABLE);
				// Check we managed to obtain a digital
				if (ptDigitalIOData != NULL) {
					QString  strTitle("");
					QString  strSubTitle("");
					QString  strKey("");

					CreateDigitalTitle(usSlotNo, usCount + 1, usChannelCaps, ptDigitalIOData, strTitle, strSubTitle,
							strKey);

					CConfigBranch *pkDigitalIO = new CConfigBranch(strKey, strTitle, strSubTitle, ctSubMenuButton,
							false, true, 0, false, pkDigitalIOParent);

					// setup the individual pen data
					SetupDigitalIODetails(pkDigitalIO, ptDigitalIOData, usSlotNo, usBoardChanNum, usChannelCaps);
					pkDigitalIOParent->AddChild(pkDigitalIO);
				}
			}
		}
	}

	return pkDigitalIOParent;
}
//****************************************************************************
// void SetupDigitalIODetails( CConfigBranch *pkParent, 
//								T_PDIGCHANNEL ptDigIOData, 
//								const USHORT usSLOT_NO,
//								const USHORT usBOARD_CHAN_NO,
//								const USHORT usCHANNEL_CAPS )
///
/// Method that sets up the details for a particular digital input/output or relay
///
/// @param[in] 		CConfigBranch *pkParent - Pointer to the parent owner class
/// @param[in]		T_PDIGCHANNEL ptDigIOData - A pointer to the associated analogue data
/// @param[in]		const USHORT usSLOT_NO - The slot number of the board this analogue input is on
/// @param[in]		const USHORT usBOARD_CHAN_NO - The boarnd channel number of the board this
///					digital input/output is on
/// @param[in]		const USHORT usCHANNEL_CAPS - Variable indicating the capabilities of this channel
///
//****************************************************************************
void CRecSetupCfgMgr::SetupDigitalIODetails(CConfigBranch *pkParent, T_PDIGCHANNEL ptDigIOData, const USHORT usSLOT_NO,
		const USHORT usBOARD_CHAN_NO, const USHORT usCHANNEL_CAPS) {
	QString  strTitle("");
	QString  strSubTitle("");
	// we now need to create all the individual components of a digital IO
	// Enabled - this will be a boolean type bitfield
	strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptDigIOData->Enabled);
	CShortBitFieldData *pkEnData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptDigIOData), 1, 0,
			ms_strEnabledList, bfeBool, 0, 0, true);
	strTitle = tr("Enabled");
	CConfigItem *pkEnabled = new CConfigItem(ms_strENABLED_KEY, strTitle, strSubTitle, ctItemButton, pkEnData, false,
			true, 0, false, pkParent);
	pkParent->AddChild(pkEnabled);

	// Type - this will be a single selection list bitfield
	CShortBitFieldData *pkTypeData = NULL;

	// check if this is an channel from 1-4 on the card in which case it is capable of
	// digital output

	if ((usCHANNEL_CAPS & CHANNEL_CAP_PULSE) == CHANNEL_CAP_PULSE) {
		pkTypeData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptDigIOData), 2, 1, ms_strDigioIOPulseTypeList,
				bfeSingleSelList, 0, 0, true);
	} else {
		// make sure this card is not set to pulse input accidentally
		if (ptDigIOData->Type == dtPulseInput) {
			// set back to an input
			ptDigIOData->Type = dtInput;
			m_bModified = true;
		}

		pkTypeData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptDigIOData), 1, 1, ms_strDigioIOTypeList,
				bfeBool, 0, 0, true);
	}
	// set the item to locked if the capabilities are restricted to digital input or output
	bool bLockInputItem = (usCHANNEL_CAPS == CHANNEL_CAP_DI) || (usCHANNEL_CAPS == CHANNEL_CAP_DO);

	strTitle = tr("Digital Type");
	strSubTitle = pkTypeData->GetDataAsString();

	UCHAR ucBoardType = BOARD_INVALID;

	ucBoardType = static_cast<UCHAR>(GlbDevCaps.GetSlotType(usSLOT_NO));

	//MarkD: if set to output, specify whether 24V or Power type
	if (ptDigIOData->Type == dtOutput) {
		QString  strContactTitle("");
		QString  strContactRating("");
		strContactTitle = tr("Relay contact");
		if (ucBoardType == BOARD_DIO) {
			strContactRating = tr("24V");
		} else {
			strContactRating = tr("Power");
		}
		strContactTitle += L" (" + strContactRating + L")";
		strSubTitle += L" " + strContactTitle;
	} else if (ptDigIOData->Type == dtPulseInput) {
		//MarkD: append (Hz)
		QString  strSubTitleHz("");
		strSubTitleHz = tr("Hz");
		strSubTitle += L" (" + strSubTitleHz + L")";
	}

	CConfigItem *pkType = new CConfigItem(ms_strDIGIO_IO_TYPE_KEY, strTitle, strSubTitle, ctItemButton, pkTypeData,
			false, (ptDigIOData->Enabled == TRUE), 0, bLockInputItem, pkParent);
	pkParent->AddChild(pkType);

	// check if this is a digital output which requires us to add some additional fields
	if (ptDigIOData->Type == dtOutput) {
		// Output latched - this will be a bool
		CShortBitFieldData *pkLatchData = new CShortBitFieldData(reinterpret_cast< USHORT*>(&ptDigIOData->DigO), 1, 0,
				ms_strDigioOutLatchedList, bfeBool, 0, 0, true);
		strTitle = tr("Output");
		strSubTitle = CStringUtils::GetItemAtPos(ms_strDigioOutLatchedList, ptDigIOData->DigO.OPLatched);
		CConfigItem *pkLatch = new CConfigItem(ms_strDIGIO_OUT_LATCHED_KEY, strTitle, strSubTitle, ctItemButton,
				pkLatchData, false, (ptDigIOData->Enabled == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkLatch);

		// Duration - this will be a USHORT
		bool bDurationEnabled = (ptDigIOData->Enabled == TRUE) && (ptDigIOData->DigO.OPLatched == FALSE);
		QString  strSeconds("");
		strSeconds = tr("Secs.");

		// make sure the data is in units of 0.1 and rounded correctly
		ULONG ulTempDuration = static_cast<ULONG>((ptDigIOData->DigO.Duration + 0.05) * 10);
		ptDigIOData->DigO.Duration = static_cast<float>(ulTempDuration) / 10;

		CFloatData *pkDurationData = new CFloatData(&ptDigIOData->DigO.Duration, 0.1F, 6553, 0, 0, true, dtFloat,
				TEMP_DEG_C, strSeconds, &m_tDurationNumasprintf);

		strTitle = tr("Pulse Duration");
		CConfigItem *pkDuration = new CConfigItem(ms_strDIGIO_OUT_DURATION_KEY, strTitle,
				pkDurationData->GetDataAsString(true), ctItemButton, pkDurationData, false, bDurationEnabled, 0, false,
				pkParent);
		pkParent->AddChild(pkDuration);

		// Failsafe - this will be a bool
		CShortBitFieldData *pkFailsafeData = new CShortBitFieldData(reinterpret_cast< USHORT*>(&ptDigIOData->DigO), 1,
				3, ms_strDigioOutFailsafeList, bfeBool, 0, 0, false);
		strTitle = tr("Failsafe");
		strSubTitle = CStringUtils::GetItemAtPos(ms_strDigioOutFailsafeList, ptDigIOData->DigO.FailSafe);
		CConfigItem *pkFailsafe = new CConfigItem(ms_strDIGIO_OUT_FAILSAFE_KEY, strTitle, strSubTitle, ctItemButton,
				pkFailsafeData, false, (ptDigIOData->Enabled == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkFailsafe);

	}

	// Label - WCHAR edit
	QString   CfgData *pkLabelData = new QString   CfgData(reinterpret_cast<WCHAR*>(&ptDigIOData->Label),
	DIGCHANNEL_LABEL_LEN, dtString, 0, 0, true);
	strTitle = tr("Label");
	CConfigItem *pkLabel = new CConfigItem(ms_strDIGIO_LABEL_KEY, strTitle, ptDigIOData->Label, ctItemButton,
			pkLabelData, false, (ptDigIOData->Enabled == TRUE), 0, false, pkParent);
	pkParent->AddChild(pkLabel);

	if (ptDigIOData->Type != dtPulseInput) {
		// Active - WCHAR edit
		QString   CfgData *pkActiveData = new QString   CfgData(reinterpret_cast<WCHAR*>(&ptDigIOData->Active),
		DIGCHANNEL_ACTIVE_LEN, dtString, 0, 0, true);
		strTitle = tr("Active Label");
		CConfigItem *pkActive = new CConfigItem(ms_strDIGIO_ACTIVE_LABEL_KEY, strTitle, ptDigIOData->Active,
				ctItemButton, pkActiveData, false, (ptDigIOData->Enabled == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkActive);

		// InActive - WCHAR edit
		QString   CfgData *pkInActiveData = new QString   CfgData(reinterpret_cast<WCHAR*>(&ptDigIOData->InActive),
		DIGCHANNEL_INACTIVE_LEN, dtString, 0, 0, true);
		strTitle = tr("Inactive Label");
		CConfigItem *pkInActive = new CConfigItem(ms_strDIGIO_INACTIVE_LABEL_KEY, strTitle, ptDigIOData->InActive,
				ctItemButton, pkInActiveData, false, (ptDigIOData->Enabled == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkInActive);

		CShortBitFieldData *pkReportTypeData = NULL;

		// Active -	Choose report method
		pkReportTypeData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptDigIOData), 2, 3,
				ms_strDigioIOReportTypeList, bfeSingleSelList, 0, 0, true);

		strTitle = tr("Reports To");
		strSubTitle = pkReportTypeData->GetDataAsString();
		CConfigItem *pkType = new CConfigItem(ms_strDIGIO_IO_NOTIFYTYPE_KEY, strTitle, strSubTitle, ctItemButton,
				pkReportTypeData, false, (ptDigIOData->Enabled == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkType);
	}
}
//****************************************************************************
// CConfigBranch* CreatePulseInConfig( )
///
/// Method that creates a pulse input config hierarchy
///
/// @return			Pointer to the top-level parent of a pulse input config hierarchy
///
//****************************************************************************
CConfigBranch* CRecSetupCfgMgr::CreatePulseInConfig() {
	CConfigBranch *pkPulseInParent = NULL;

	// Check the pulse input setup class exists
	CIOSetupConfig *pkPulseInSetupCfg = pSETUP->GetIOSetupConfig();
	CSlotMap *pkSlotMap = CSlotMap::GetHandle();
	if ((pkPulseInSetupCfg != NULL) && (pkSlotMap != NULL)) {

		// firstly create the top level config interface class
		const USHORT usNO_OF_PULSE = MAX_HIRES_PULSE;
		QString  strTitle("");
		strTitle = tr("Pulse Input");

		pkPulseInParent = new CConfigBranch(ms_strPULSE_IN_KEY, strTitle, strTitle, ctMainMenuButton, false, true, 0,
				false, NULL);

		// now create a load of child pulse inputs and add them to the parent
		USHORT usSysChanNum = 0;
		for (USHORT usCount = 0; usCount < usNO_OF_PULSE; usCount++) {
			USHORT usSlotNo = 0;
			USHORT usBoardChanNum = 0;

			// the system channel number needs to go 1-4, 9-12 etc 
			usSysChanNum = usCount + 1;

			usSysChanNum += (4 * (usCount / 4));

			// check the slot number and board channel number are okay and that a pulse input
			// card exists in this slot
			if (GetPulseInputChannelInfo(usSysChanNum, usSlotNo, usBoardChanNum)) {
				// Get the pulse input data structure
				T_PPULSECHANNEL ptPulseInData = NULL;

				ptPulseInData = pkPulseInSetupCfg->GetPulseInput(usSlotNo, usBoardChanNum, CONFIG_MODIFIABLE);
				// Check we managed to obtain a pulse
				if (ptPulseInData != NULL) {
					// this is a valid pulse input card therefore add on to the config tree
					QString  strIndPulseInKey("");
					strIndPulseInKey.asprintf(L"%s%d", ms_strPULSE_IN_KEY, usSysChanNum);
					QString  strPulseInName("");
					strPulseInName.asprintf(L"%s %d", strTitle, usSysChanNum);

					QString  strSubTitle(ptPulseInData->Label);
					strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptPulseInData->Enabled) + L" "
							+ strSubTitle;
//					strSubTitle += L", " + CStringUtils::GetItemAtPos( ms_strPulseInMeasurementMethodList, ptPulseInData->FreqMeasure );
					//MarkD: append Hz
//					QString   strSubTitleHz(QString   ::fromWCharArray(""));
					//					strSubTitleHz = tr("Hz");
//					strSubTitle += L" " + strSubTitleHz;
					//strSubTitle += L" Hz";	// Hz is a name, so should not need translating?

					CConfigBranch *pkPulseIn = new CConfigBranch(strIndPulseInKey, strPulseInName, strSubTitle,
							ctSubMenuButton, false, true, 0, false, pkPulseInParent);

					// setup the individual pulse data
					SetupPulseInDetails(pkPulseIn, ptPulseInData, usSlotNo, usBoardChanNum);
					pkPulseInParent->AddChild(pkPulseIn);
				}
			}
		}
	}

	return pkPulseInParent;
}
//****************************************************************************
// void SetupPulseInDetails(	CConfigBranch *pkParent, 
//								T_PPULSECHANNEL ptPulseInData, 
//								const USHORT usSLOT_NO,
//								const USHORT usBOARD_CHAN_NO
///
/// Method that sets up the details for a particular pulse input
///
/// @param[in] 		CConfigBranch *pkParent - Pointer to the parent owner class
/// @param[in]		T_PPULSECHANNEL ptPulseInData - A pointer to the associated pulse data
/// @param[in]		const USHORT usSLOT_NO - The slot number of the board this pulse input is on
/// @param[in]		const USHORT usBOARD_CHAN_NO - The boarnd channel number of the board this
///					pulse input
///
//****************************************************************************
void CRecSetupCfgMgr::SetupPulseInDetails(CConfigBranch *pkParent, T_PPULSECHANNEL ptPulseInData,
		const USHORT usSLOT_NO, const USHORT usBOARD_CHAN_NO) {
	QString  strTitle("");
	QString  strSubTitle("");

	// we now need to create all the individual components of a pulse input
	// Enabled - this will be a boolean type bitfield
	strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptPulseInData->Enabled);
	CShortBitFieldData *pkEnData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptPulseInData), 1, 0,
			ms_strEnabledList, bfeBool, 0, 0, true);
	strTitle = tr("Enabled");
	CConfigItem *pkEnabled = new CConfigItem(ms_strENABLED_KEY, strTitle, strSubTitle, ctItemButton, pkEnData, false,
			true, 0, false, pkParent);
	pkParent->AddChild(pkEnabled);

	/*
	 // measurement method - this will be a single selection list bitfield
	 CShortBitFieldData *pkMeasurementData = new CShortBitFieldData(	reinterpret_cast< USHORT* >( ptPulseInData ),
	 1,
	 1,
	 ms_strPulseInMeasurementMethodList,
	 bfeBool,
	 0,
	 0,
	 true );
	 strTitle = tr("Hertz");
	 strSubTitle = CStringUtils::GetItemAtPos( ms_strPulseInMeasurementMethodList, ptPulseInData->FreqMeasure );
	 //MarkD: append '(Hz)'
	 QString   strSubTitleHz(QString   ::fromWCharArray(""));
	 strSubTitleHz = tr("Hz");
	 strSubTitle += L" (" + strSubTitleHz + L")";
	 //strSubTitle += L" (Hz)";	// Hz is a name, so should not need translating?
	 CConfigItem *pkMeasurement = new CConfigItem(	ms_strPULSE_IN_MEASUREMENT_METHOD_KEY,
	 strTitle,
	 strSubTitle,
	 ctItemButton,
	 pkMeasurementData,
	 false,
	 ( ptPulseInData->Enabled == TRUE ),
	 0,
	 //false,	//MarkD: no choice of pulse count in phase 1
	 true,		// block selection
	 pkParent );
	 pkParent->AddChild( pkMeasurement );
	 */
	//MarkD: add a box offering acquisition rate ready for phase 2
	// in phase 1, this does add information on update rate - it shows it's 1Hz fixed
#ifndef TTR6SETUP
	CShortBitFieldData *pkRateData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptPulseInData), 1, 1,
	// needs a new list offering 1Hz, 2Hz, 5Hz, 10Hz
			ms_strPulseInMeasurementUpdateList, bfeBool, 0, 0, true);
#else
	///	added for TTR6SETUP DLL to ensure that 1Hz is displayed as the update rate @todo TM
	CShortBitFieldData *pkRateData = new CShortBitFieldData(	reinterpret_cast< USHORT* >( ptPulseInData ),
																0,
																0,
																// needs a new list offering 1Hz, 2Hz, 5Hz, 10Hz
																ms_strPulseInMeasurementUpdateList,														
																bfeBool,
																0,
																0,
																true );
#endif
	strTitle = (L"Update Rate");	///@todo: get from string list
	//strTitle.LoadString( IDS_CFG_UPDATE_RATE_METHOD_TITLE );
	//strSubTitle = CStringUtils::GetItemAtPos( ms_strPulseInMeasurementMethodList, ptPulseInData->FreqMeasure );
	strSubTitle = (L"1");
	// later (phase 2) this must pick up the selected acquisition rate, which needs adding to 
	// ptPulseInData (T_PPULSECHANNEL). 
	// Use 3 of the spare (unused) bits to specify 1Hz, 2Hz, 5Hz, 10Hz with room for expansion.
	strSubTitle += (L" Hz");	// Hz is a name, so should not need translating
	CConfigItem *pkRate = new CConfigItem(ms_strPULSE_IN_MEASUREMENT_UPDATE_KEY, strTitle, strSubTitle, ctItemButton,
			pkRateData, false, (ptPulseInData->Enabled == TRUE), 0,
			//false,	//MarkD: no choice of update rate in phase 1
			true,// block selection
			pkParent);

	pkParent->AddChild(pkRate);
	// No doubt the details in the CConfigItem calls will change - but for now, 
	// my only aim is to get something looking how it should

	// Label - WCHAR edit
	QString   CfgData *pkLabelData = new QString   CfgData(reinterpret_cast<WCHAR*>(&ptPulseInData->Label),
	PULSECHANNEL_LABEL_LEN, dtString, 0, 0, true);
	strTitle = tr("Label");
	CConfigItem *pkLabel = new CConfigItem(ms_strPULSE_IN_LABEL_KEY, strTitle, ptPulseInData->Label, ctItemButton,
			pkLabelData, false, (ptPulseInData->Enabled == TRUE), 0, false, pkParent);
	pkParent->AddChild(pkLabel);
}
//****************************************************************************
// CConfigBranch* CreateAnalogueOutputConfig( )
///
/// Method that creates an analogue output config hierarchy
///
/// @return			Pointer to the top-level parent of an analogue output config hierarchy
///
//****************************************************************************
CConfigBranch* CRecSetupCfgMgr::CreateAnalogueOutputConfig() {
	CConfigBranch *pkAnalogueOutputParent = NULL;

	// Check the analogue output setup class exists
	CIOSetupConfig *pkAnalogueOutputSetupCfg = pSETUP->GetIOSetupConfig();
	CSlotMap *pkSlotMap = CSlotMap::GetHandle();
	if ((pkAnalogueOutputSetupCfg != NULL) && (pkSlotMap != NULL)) {

		// firstly create the top level config interface class
		const USHORT usNO_OF_AOUT = MAX_ANALOGUE_OUT;
		QString  strTitle("");
		strTitle = tr("Ana. Out");

		pkAnalogueOutputParent = new CConfigBranch(ms_strANALOGUE_OUTPUT_KEY, strTitle, strTitle, ctMainMenuButton,
				false, true, 0, false, NULL);

		// now create a load of child analogue outputs and add them to the parent
		USHORT usSysChanNum = 0;
		for (USHORT usCount = 0; usCount < usNO_OF_AOUT; usCount++) {
			USHORT usSlotNo = 0;
			USHORT usBoardChanNum = 0;

			// the system channel number needs to go 1-4, 9-12 etc 
			usSysChanNum = usCount + 1;

			usSysChanNum += (4 * (usCount / 4));

			// check the slot number and board channel number are okay and that a pulse input
			// card exists in this slot
			if (GetAnalogueOutputChannelInfo(usSysChanNum, usSlotNo, usBoardChanNum)) {
				// Get the analogue output data structure
				T_PAOCHANNEL ptAnalogueOutputData = NULL;

				ptAnalogueOutputData = pkAnalogueOutputSetupCfg->GetAnalogueOutput(usSlotNo, usBoardChanNum,
						CONFIG_MODIFIABLE);
				// Check we managed to obtain an analogue output
				if (ptAnalogueOutputData != NULL) {
					// this is a valid analogue output card therefore add on to the config tree
					QString  strIndAnalogueOutputKey("");
					strIndAnalogueOutputKey.asprintf(L"%s%u", ms_strANALOGUE_OUTPUT_KEY, usSysChanNum);
					QString  strAnalogueOutputName("");
					strAnalogueOutputName.asprintf(L"%s %u", strTitle, usSysChanNum);

					QString  strSubTitle(ptAnalogueOutputData->Label);
					strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptAnalogueOutputData->Enabled) + L" "
							+ strSubTitle;
					QString  strPenNo("");
					strPenNo = tr("Pen No.");
					strSubTitle += L", " + strPenNo + L" ";
					strPenNo.asprintf(L"%u, ", ptAnalogueOutputData->PenNo + 1);
					strSubTitle += strPenNo;

					strSubTitle += CStringUtils::GetItemAtPos(ms_strAnalogueOutputCurrentList,
							ptAnalogueOutputData->ZeroOutput);

					CConfigBranch *pkAnalogueOutput = new CConfigBranch(strIndAnalogueOutputKey, strAnalogueOutputName,
							strSubTitle, ctSubMenuButton, false, true, 0, false, pkAnalogueOutputParent);

					// setup the individual analogue output data
					SetupAnalogueOutDetails(pkAnalogueOutput, ptAnalogueOutputData, usSlotNo, usBoardChanNum);
					pkAnalogueOutputParent->AddChild(pkAnalogueOutput);
				}
			}
		}
	}

	return pkAnalogueOutputParent;
}
//****************************************************************************
// void SetupAnalogueOutDetails(	CConfigBranch *pkParent, 
//									T_PAOCHANNEL ptAnalogueOutData, 
//									const USHORT usSLOT_NO,
//									const USHORT usBOARD_CHAN_NO )
///
/// Method that sets up the details for a particular analogue output
///
/// @param[in] 		CConfigBranch *pkParent - Pointer to the parent owner class
/// @param[in]		T_PAOCHANNEL ptAnalogueOutData - A pointer to the associated analogue output data
/// @param[in]		const USHORT usSLOT_NO - The slot number of the board this analogue output is on
/// @param[in]		const USHORT usBOARD_CHAN_NO - The boarnd channel number of the board this
///					analogue output
///
//****************************************************************************
void CRecSetupCfgMgr::SetupAnalogueOutDetails(CConfigBranch *pkParent, T_PAOCHANNEL ptAnalogueOutData,
		const USHORT usSLOT_NO, const USHORT usBOARD_CHAN_NO) {
	QString  strTitle("");
	QString  strSubTitle("");

	// we now need to create all the individual components of an analogue output
	// Enabled - this will be a boolean type bitfield
	strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptAnalogueOutData->Enabled);
	CShortBitFieldData *pkEnData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptAnalogueOutData), 1, 6,
			ms_strEnabledList, bfeBool, 0, 0, true);
	strTitle = tr("Enabled");
	CConfigItem *pkEnabled = new CConfigItem(ms_strENABLED_KEY, strTitle, strSubTitle, ctItemButton, pkEnData, false,
			true, 0, false, pkParent);
	pkParent->AddChild(pkEnabled);

	// Allow Overrange
	CShortBitFieldData *pAllowOverrangeData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptAnalogueOutData), 1,
			7, ms_strEnabledList, bfeBool, 0, 0, false);
	strTitle = tr("Allow Overrge");
	strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptAnalogueOutData->Overrange);
	CConfigItem *pkAllowOverrange = new CConfigItem(ms_strANALOGUE_OUTPUT_ALLOW_OVERRANGE_KEY, strTitle, strSubTitle,
			ctItemButton, pAllowOverrangeData, false, (ptAnalogueOutData->Enabled == TRUE), 0, false, pkParent);
	pkParent->AddChild(pkAllowOverrange);

	// Retransmit Pen No - this will create a pen pick list
	CPickerData *pkRetransmitPenNoData = new CPickerData(&ptAnalogueOutData->PenNo, dtSinglePen, 0, 0, true, 1, 1);
	strTitle = tr("Transmit Pen");
	CConfigItem *pkRetransmitPenNo = new CConfigItem(ms_strANALOGUE_OUTPUT_RETRANS_PEN_KEY, strTitle,
			pkRetransmitPenNoData->GetDataAsString(), ctItemButton, pkRetransmitPenNoData, false,
			(ptAnalogueOutData->Enabled == TRUE), 0, false, pkParent);
	pkParent->AddChild(pkRetransmitPenNo);

	// Output Current
	CShortBitFieldData *pOutputCurrentData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptAnalogueOutData), 1,
			10, ms_strAnalogueOutputCurrentList, bfeSingleSelList, 0, 0, true);
	strTitle = tr("Output");
	CConfigItem *pOutputCurrent = new CConfigItem(ms_strANALOGUE_OUTPUT_CURRENT_KEY, strTitle,
			pOutputCurrentData->GetDataAsString(), ctItemButton, pOutputCurrentData, false,
			(ptAnalogueOutData->Enabled == TRUE), 0, false, pkParent);
	pkParent->AddChild(pOutputCurrent);

	// Label - WCHAR edit
	QString   CfgData *pkLabelData = new QString   CfgData(reinterpret_cast<WCHAR*>(&ptAnalogueOutData->Label),
	AOCHANNEL_LABEL_LEN, dtString, 0, 0, true);
	strTitle = tr("Label");
	CConfigItem *pkLabel = new CConfigItem(ms_strANALOGUE_OUTPUT_LABEL_KEY, strTitle, ptAnalogueOutData->Label,
			ctItemButton, pkLabelData, false, (ptAnalogueOutData->Enabled == TRUE), 0, false, pkParent);
	pkParent->AddChild(pkLabel);

}
//****************************************************************************
// CConfigItem *RefreshAnalogueOutputConfigTree(	CConfigItem *pkModifiedItem,
//													const USHORT usAOUT_NO )
///
/// Method that refreshes the data for an analogue output branch of an analogue configuration menu,
/// usually following a change that requires the tree structure to be regenerated because it is different
///
/// @param[in] 		CConfigItem *pkModifiedItem - A pointer to the item that has been modified - this will
///					be destroyed
/// @param[in] 		const USHORT usAOUT_NO - The number of the AOUT that has changed (1 based)
///
/// @return			A pointer to the new config item (it will have the same key as the modified item)
///
//****************************************************************************
CConfigItem* CRecSetupCfgMgr::RefreshAnalogueOutputConfigTree(CConfigItem *pkModifiedItem, const USHORT usAOUT_NO) {
	CConfigItem *pkNewCfgItem = NULL;
	CConfigInterface *pkTopParent = NULL;

	// Store the key name of this item
	const QString  strKEY(pkModifiedItem->GetKey());

	CConfigInterface *pkAOUTParent = pkModifiedItem;

	// get the top level parent
	while (pkAOUTParent->GetParent() != NULL) {
		pkAOUTParent = pkAOUTParent->GetParent();
	}
	pkTopParent = pkAOUTParent->GetParent();

	// Get the pen data structure
	T_PAOCHANNEL ptAOUTData = NULL;

	CIOSetupConfig *pkAOSetupCfg = pSETUP->GetIOSetupConfig();

	USHORT usSlotNumber = 0;
	USHORT usBoardChanNumber = 0;

	if (GetAnalogueOutputChannelInfo(usAOUT_NO, usSlotNumber, usBoardChanNumber)) {
		if (pkAOSetupCfg != NULL) {
			ptAOUTData = pkAOSetupCfg->GetAnalogueOutput(usSlotNumber, usBoardChanNumber, CONFIG_MODIFIABLE);
		}

		// Check we managed to obtain a AOUT
		if (ptAOUTData != NULL) {
			// recreate a AOUT branch for this item
			QString  strIndividualAOUTKey("");
			strIndividualAOUTKey.asprintf(L"%s%d", ms_strANALOGUE_OUTPUT_KEY, usAOUT_NO);
			QString  strAOUTName("");
			QString  strAOUTTitle("");
			strAOUTTitle = tr("Ana. Out");
			strAOUTName.asprintf(L"%s %d", strAOUTTitle, usAOUT_NO);

			QString  strSubTitle(ptAOUTData->Label);
			strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptAOUTData->Enabled) + L" " + strSubTitle;
			QString  strPenNo("");
			strPenNo = tr("Pen No.");
			strSubTitle += L", " + strPenNo + L" ";
			strPenNo.asprintf(L"%u, ", ptAOUTData->PenNo + 1);
			strSubTitle += strPenNo;

			strSubTitle += CStringUtils::GetItemAtPos(ms_strAnalogueOutputCurrentList, ptAOUTData->ZeroOutput);

			CConfigBranch *pkNewAOUT = new CConfigBranch(strIndividualAOUTKey, strAOUTName, strSubTitle,
					ctSubMenuButton, false, true, 0, false, pkAOUTParent);

			// setup the individual AOUT data
			SetupAnalogueOutDetails(pkNewAOUT, ptAOUTData, usSlotNumber, usBoardChanNumber);
			CConfigBranch *pkBranch = static_cast<CConfigBranch*>(pkAOUTParent);
			pkBranch->ReplaceChild(pkNewAOUT);

			// we now need to get the new child for the particular item that was being modified
			pkNewCfgItem = static_cast<CConfigItem*>(indexOfChildByKey(strKEY, pkNewAOUT, 2));
		}
	} else {
		// there has been a problem
		pkNewCfgItem = static_cast<CConfigItem*>(pkTopParent);
	}

	return pkNewCfgItem;
}
//****************************************************************************
// CConfigBranch* CreateLimearisationConfig( )
///
/// Method that creates a linearisation config hierarchy
///
/// @return			Pointer to the top-level parent of a linearisation config hierarchy
///
//****************************************************************************
CConfigBranch* CRecSetupCfgMgr::CreateLinearisationConfig() {
	CConfigBranch *pkParent = NULL;

	// Check the linearisation setup structure exists
	T_PGENERALCONFIG ptGeneralData = pSETUP->GetGeneralSetupConfig()->GetSystemGeneralBlock(CONFIG_MODIFIABLE);
	if (ptGeneralData != NULL) {
		CConfigBranch *pkTableParent = NULL;
		QString  strKey("");
		QString  strTitle("");
		QString  strSubTitle("");

		// firstly create the top level config interface class
		strTitle = tr("Linearization");

		pkParent = new CConfigBranch(ms_strLINEARISATION_KEY, strTitle, strTitle, ctMainMenuButton, false, true, 0,
				false, NULL);

		// now create a load of child linearisation tables and add them to the parent
		for (USHORT usCount = 0; usCount < GENERALCONFIG_USERTABLE_SIZE; usCount++) {
			// create the linearisation branch first
			strKey.asprintf(ms_strLINEARISATION_TABLE_KEY, usCount);
			strTitle.asprintf(IDS_CFG_LINEARISATION_TABLE_TITLE, usCount + 1);
			strSubTitle = ptGeneralData->UserTable[usCount].Name;
			pkTableParent = new CConfigBranch(strKey, strTitle, strSubTitle, ctSubMenuButton, false, true, 0, false,
					pkParent);

			pkParent->AddChild(pkTableParent);

			// now create the table name
			QString   CfgData *pkTableNameData = new QString   CfgData(ptGeneralData->UserTable[usCount].Name,
			LOOKUPTABLE_NAME_LEN, dtString, 0, 0, true);

			strTitle = tr("Name");
			CConfigItem *pkTableName = new CConfigItem(ms_strLINEARISATION_TABLE_NAME_KEY, strTitle,
					pkTableNameData->GetDataAsString(), ctItemButton, pkTableNameData, false, true, 0, false,
					pkTableParent);
			pkTableParent->AddChild(pkTableName);

			// now create the table edit menu item
			CLinearisationData *pkTableValuesData = new CLinearisationData(&ptGeneralData->UserTable[usCount]);

			strTitle = tr("Values");
			CConfigItem *pkTableValues = new CConfigItem(ms_strLINEARISATION_TABLE_VALUES_KEY, strTitle,
					pkTableValuesData->GetDataAsString(), ctItemButton, pkTableValuesData, false, true, 0, false,
					pkTableParent);
			pkTableParent->AddChild(pkTableValues);
		}
	}

	return pkParent;
}
//****************************************************************************
// CConfigBranch *CreateGeneralDeviceConfig( )
///
/// Method that creates the general device config heirarchy
///
/// @return Pointer to the general device config hierarchy
///
//****************************************************************************
CConfigBranch* CRecSetupCfgMgr::CreateGeneralDeviceConfig() {
	CConfigBranch *pkGeneralDeviceParent = NULL;

	// Check the general device data class exists
	CGeneralSetupConfig *pkGeneralDeviceSetupCfg = pSETUP->GetGeneralSetupConfig();

	if (pkGeneralDeviceSetupCfg != NULL) {
		QString  strTitle("");
		strTitle = tr("Ident");

		pkGeneralDeviceParent = new CConfigBranch(ms_strDEVICE_DETAILS, strTitle, strTitle, ctMainMenuButton, false,
				true, 0, false, NULL);

		// Get the general device data structure
		T_PGENERALCONFIG ptGeneralDeviceData = NULL;

		ptGeneralDeviceData = pkGeneralDeviceSetupCfg->GetSystemGeneralBlock(CONFIG_MODIFIABLE);

		// Check we managed to obtain an General Device Setup block
		if (ptGeneralDeviceData != NULL) {

			//now create the child items to be displayed in the tree
			QString  strTitle("");
			QString  strSubTitle("");

			// we now need to create all the individual components for the general device information
			// Device Name
			QString   CfgData *pkNameData = new QString   CfgData(ptGeneralDeviceData->Name,
			GENERALCONFIG_NAME_LEN, dtString, 0, 0, false);
			strTitle = tr("Name");
			CConfigItem *pkName = new CConfigItem(ms_strDEVICE_NAME, strTitle, pkNameData->GetDataAsString(),
					ctItemButton, pkNameData, false, true, 0, false, pkGeneralDeviceParent);

			pkGeneralDeviceParent->AddChild(pkName);

			// Device Description
			QString   CfgData *pDescData = new QString   CfgData(reinterpret_cast<WCHAR*>(ptGeneralDeviceData->Description),
			GENERALCONFIG_DESCRIPTION_LEN, dtString, 0, 0, false);
			strTitle = tr("Description");
			CConfigItem *pkDesc = new CConfigItem(ms_strDEVICE_DESC, strTitle, ptGeneralDeviceData->Description,
					ctItemButton, pDescData, false, ( TRUE), 0, false, pkGeneralDeviceParent);

			pkGeneralDeviceParent->AddChild(pkDesc);

			// Device ID
			CULongData *pkIDData = new CULongData(&ptGeneralDeviceData->ID, 1,			// min recorder ID, can't be 0
					9999,					//max recorder ID
					0, 0, true);
			strTitle = tr("ID");
			CConfigItem *pkID = new CConfigItem(ms_strDEVICE_ID, strTitle, pkIDData->GetDataAsString(), ctItemButton,
					pkIDData, false, ( TRUE), 0, false, pkGeneralDeviceParent);

			pkGeneralDeviceParent->AddChild(pkID);
		}

	}

	return pkGeneralDeviceParent;
}
//****************************************************************************
// CConfigBranch *CreateGroupsConfig( )
///
/// Method that creates the groups config heirarchy
///
/// @return Pointer to the group config hierarchy
///
//****************************************************************************
CConfigBranch* CRecSetupCfgMgr::CreateGroupsConfig() {
	CConfigBranch *pkParent = NULL;
	QString  strTitle("");
	QString  strKey("");
	QString  strSubTitle("");
	QString  strTitleasprintfString("");

	T_PGENERALCONFIG ptGeneralData = pSETUP->GetGeneralSetupConfig()->GetSystemGeneralBlock(CONFIG_MODIFIABLE);

	if (ptGeneralData != NULL) {
		strTitle = tr("Groups");

		pkParent = new CConfigBranch(ms_strGROUPS_KEY, strTitle, strSubTitle, ctSubMenuButton, false, true, 0, false,
				NULL);

		// get the group name format string now
		strTitleasprintfString = tr("Group");

		// now loop through and add all the groups
		for (USHORT usCount = 0; usCount < GENERALCONFIG_GROUPNAME_SIZE; usCount++) {
			// Group Name, WCHAR edit
			QString   CfgData *pkGroupNameData = new QString   CfgData(
					reinterpret_cast<WCHAR*>(&ptGeneralData->GroupName[usCount]),
					GENERALCONFIG_GROUPNAME_LEN, dtString, 0, 0, false);

			strTitle.asprintf(strTitleasprintfString + L" %u", usCount + 1);
			strKey.asprintf(ms_strGROUPS_GROUP_KEY, usCount);
			CConfigItem *pkGroupName = new CConfigItem(strKey, strTitle, pkGroupNameData->GetDataAsString(),
					ctItemButton, pkGroupNameData, false, true, 0, false, pkParent);
			pkParent->AddChild(pkGroupName);
		}
	}
	return pkParent;
}
//****************************************************************************
// CConfigBranch *CreateWebConfig( )
///
/// Method that creates the web config heirarchy
///
/// @return Pointer to the web config hierarchy
///
//****************************************************************************
CConfigBranch* CRecSetupCfgMgr::CreateWebConfig() {
	CConfigBranch *pkParent = NULL;

	QString  strTitle("");
	QString  strKey("");
	QString  strSubTitle("");

	CSingleLock lock(&m_GlbSetupMutex);
	lock.Lock();
	CCommsSetupConfig *pkCommsConfig = pGlbSetup->GetCommsSetupConfig();
	lock.Unlock();
	T_PCOMMUNICATIONS ptCommsData = NULL;
	if (pkCommsConfig != NULL) {
		ptCommsData = pkCommsConfig->GetCommsBlock(CONFIG_MODIFIABLE);
	}

	if (ptCommsData != NULL) {
		T_NETWORK *ptEthernet = &ptCommsData->Ethernet;

		strTitle = tr("Web");
		strSubTitle = strTitle;

		pkParent = new CConfigBranch(ms_strWEB_KEY, strTitle, strSubTitle, ctSubMenuButton, false, true, 0, false,
				NULL);

		// now add the web enabled field
		CShortBitFieldData *pkEnData = new CShortBitFieldData(reinterpret_cast< USHORT*>(&ptEthernet->EnableWeb), 1, 0,
				ms_strEnabledList, bfeBool, 0, 0, false, 0, USHRT_MAX, true);
		strTitle = tr("Enabled");
		CConfigItem *pkEnabled = new CConfigItem(ms_strENABLED_KEY, strTitle, pkEnData->GetDataAsString(), ctItemButton,
				pkEnData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkEnabled);

	}

	return pkParent;
}
//****************************************************************************
// CConfigBranch *CreateEmailConfig( )
///
/// Method that creates the email config heirarchy
///
/// @return Pointer to the email config hierarchy
///
//****************************************************************************
CConfigBranch* CRecSetupCfgMgr::CreateEmailConfig() {
	CConfigBranch *pkParent = NULL;

	QString  strTitle("");
	QString  strSubTitle("");

	CSingleLock lock(&m_GlbSetupMutex);
	lock.Lock();
	CCommsSetupConfig *pkCommsConfig = pGlbSetup->GetCommsSetupConfig();
	lock.Unlock();
	T_PCOMMUNICATIONS ptCommsData = NULL;
	if (pkCommsConfig != NULL) {
		ptCommsData = pkCommsConfig->GetCommsBlock(CONFIG_MODIFIABLE);
	}

	if (ptCommsData != NULL) {
		T_EMAIL *ptEmail = &ptCommsData->Email;

		strTitle = tr("Email");
		strSubTitle = strTitle;

		pkParent = new CConfigBranch(ms_strEMAIL_KEY, strTitle, strSubTitle, ctSubMenuButton, false, true, 0, false,
				NULL);

		// now add the server name field
		QString   CfgData *pkServerNameData = new QString   CfgData(ptEmail->ServerName,
		EMAIL_SERVERNAME_LEN, dtString, 0, 0, false);
		strTitle = tr("Server Name");
		CConfigItem *pkServerName = new CConfigItem(ms_strEMAIL_SERVER_KEY, strTitle,
				pkServerNameData->GetDataAsString(), ctItemButton, pkServerNameData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkServerName);

		// Add Port - this will be a bitfield (defaulted to 25)
		CUShortData *pkPortData = new CUShortData(&ptEmail->Port, 1, USHRT_MAX, 0, 0, false, dtUnsignedShort,
				"", true);
		//strTitle.LoadString( IDS_CFG_EMAIL_PORT_TITLE );

		strTitle = L"Port";					////TVR200 - Making port configurable
		CConfigItem *pkPort = new CConfigItem(ms_strEMAIL_PORT_KEY, strTitle, pkPortData->GetDataAsString(),
				ctItemButton, pkPortData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkPort);

		// Requires authentication - this will be a bitfield
		CShortBitFieldData *pkReqSecurityMode = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptEmail), 1, 1,
				ms_strEnabledList, bfeBool, 0, 0, false, 0, USHRT_MAX, true);
		strTitle = tr("Secure Communication");
		CConfigItem *pkReqSMode = new CConfigItem(ms_strEMAIL_SECURE_MODE_KEY, strTitle,
				pkReqSecurityMode->GetDataAsString(), ctItemButton, pkReqSecurityMode, false, true, 0, false, pkParent);
		pkParent->AddChild(pkReqSMode);

		// Requires STARTTLS support - this will be a bitfield
		CShortBitFieldData *pkReqSTARTTLSSupportData = new CShortBitFieldData(reinterpret_cast<USHORT*>(ptEmail), 1, 2,
				ms_strEnabledList, bfeBool, 0, 0, false, 0, USHRT_MAX, false);
		strTitle = tr("STARTTLS Support");
		CConfigItem *pkReqSTARTTLSSupport = new CConfigItem(ms_strEMAIL_STARTTLS_KEY, strTitle,
				pkReqSTARTTLSSupportData->GetDataAsString(), ctItemButton, pkReqSTARTTLSSupportData, false, true, 0,
				false, pkParent);
		pkParent->AddChild(pkReqSTARTTLSSupport);

		// Requires authentication - this will be a bitfield
		CShortBitFieldData *pkReqAuthData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptEmail), 1, 0,
				ms_strEnabledList, bfeBool, 0, 0, true);
		strTitle = tr("Authentication");
		CConfigItem *pkReqAuth = new CConfigItem(ms_strEMAIL_REQUIRES_AUTH_KEY, strTitle,
				pkReqAuthData->GetDataAsString(), ctItemButton, pkReqAuthData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkReqAuth);

		// now add the username field if authentication is required 
		QString   CfgData *pkUserNameData = new QString   CfgData(ptEmail->Username,
		EMAIL_USERNAME_LEN, dtString, 0, 0, false);
		strTitle = tr("Username");
		CConfigItem *pkUserName = new CConfigItem(ms_strEMAIL_USERNAME_KEY, strTitle, pkUserNameData->GetDataAsString(),
				ctItemButton, pkUserNameData, false, (ptEmail->ServerReqAuth == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkUserName);

		// now add the password field if authentication is required 
		QString   CfgData *pkPasswordData = new QString   CfgData(ptEmail->Password,
		EMAIL_PASSWORD_LEN, dtPassword, 0, 0, false);
		strTitle = tr("Password");
		CConfigItem *pkPassword = new CConfigItem(ms_strEMAIL_PASSWORD_KEY, strTitle, pkPasswordData->GetDataAsString(),
				ctItemButton, pkPasswordData, false, (ptEmail->ServerReqAuth == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkPassword);

		// now add the user address field
		QString   CfgData *pkUserAddrData = new QString   CfgData(ptEmail->UserAddress,
		EMAIL_USERADDRESS_LEN, dtEmailAddr, 0, 0, false);
		strTitle = tr("User Address");
		CConfigItem *pkUserAddr = new CConfigItem(ms_strEMAIL_USER_ADDRESS_KEY, strTitle,
				pkUserAddrData->GetDataAsString(), ctItemButton, pkUserAddrData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkUserAddr);

		// now add the recipient addresses submenu item and the address fields themselves
		strTitle = tr("Recipient's Email");
		CConfigBranch *pkAddrParent = new CConfigBranch(ms_strEMAIL_ADDRESSES_KEY, strTitle, strTitle, ctSubMenuButton,
				false, true, 0, false, pkParent);
		pkParent->AddChild(pkAddrParent);

		// loop through adding each indiivdual address
		QString  strAddrKey("");
		for (USHORT usCount = 0; usCount < EMAIL_EMAILADDRESSES_SIZE; usCount++) {
			// now add the user address field
			QString   CfgData *pkRecipAddrData = new QString   CfgData(ptEmail->EmailAddresses[usCount],
			EMAIL_USERADDRESS_LEN, dtEmailAddr, 0, 0, false);

			// check if the email address field is 0 which implies it is uninitialised
			if (pkRecipAddrData->GetDataAsString() == L"0") {
				// set it to NULL
				ptEmail->EmailAddresses[usCount][0] = '\0';
			}

			strTitle.asprintf(IDS_CFG_RECIPIENT_ADDRESS_TITLE, usCount + 1);
			strAddrKey.asprintf(ms_strEMAIL_ADDRESS_KEY, usCount + 1);
			CConfigItem *pkRecipAddr = new CConfigItem(strAddrKey, strTitle, pkRecipAddrData->GetDataAsString(),
					ctItemButton, pkRecipAddrData, false, true, 0, false, pkAddrParent);
			pkAddrParent->AddChild(pkRecipAddr);
		}

		// now add the email templates submenu item and the template fields themselves
		strTitle = tr("Templates");
		CConfigBranch *pkTemplateParent = new CConfigBranch(ms_strEMAIL_TEMPLATES_KEY, strTitle, strTitle,
				ctSubMenuButton, false, true, 0, false, pkParent);
		pkParent->AddChild(pkTemplateParent);

		// setup the templates
		SetupEmailTemplates(pkTemplateParent, ptEmail);
	}

	return pkParent;
}
//****************************************************************************
// void SetupEmailTemplates( CConfigBranch *pkParent, T_EMAIL *ptEmail )
///
/// Method that sets up the email templates
///
/// @param[in/out] 		CConfigBranch *pkParent - Pointer to the parent owner class
/// @param[in]			T_EMAIL *ptEmail- Pointer to the email structure
///
//****************************************************************************
void CRecSetupCfgMgr::SetupEmailTemplates(CConfigBranch *pkParent, T_EMAIL *ptEmail) {
	// loop through adding each individual templates
	QString  strTemplateKey("");
	QString  strTitle("");
	QString  strSubTitle("");

	CSingleLock lock(&m_GlbSetupMutex);
	lock.Lock();
	CCommsSetupConfig *pkCommsConfig = pGlbSetup->GetCommsSetupConfig();
	lock.Unlock();

	for (USHORT usCount = 0; usCount < EMAIL_TEMPLATES_SIZE; usCount++) {
		strTitle.asprintf(IDS_CFG_EMAIL_IND_TEMPLATE_TITLE, usCount + 1);

		strSubTitle = ptEmail->Templates[usCount];

		strTemplateKey.asprintf(ms_strEMAIL_IND_TEMPLATE_KEY, usCount);

		// setup the individual template parents
		CConfigBranch *pkIndTemplateParent = new CConfigBranch(strTemplateKey, strTitle, strSubTitle, ctSubMenuButton,
				false, true, 0, false, pkParent);
		pkParent->AddChild(pkIndTemplateParent);

		// now add the subject field
		QString   CfgData *pkSubjectData = new QString   CfgData(ptEmail->Templates[usCount],
		EMAIL_TEMPLATES_LEN, dtString, 0, 0, true);

		// check if the email address field is 0 which implies it is uninitialised
		if (pkSubjectData->GetDataAsString() == L"0") {
			// set it to NULL
			ptEmail->Templates[usCount][0] = '\0';
		}

		strTitle = tr("Subject");
		CConfigItem *pkSubject = new CConfigItem(ms_strEMAIL_SUBJECT_KEY, strTitle, pkSubjectData->GetDataAsString(),
				ctItemButton, pkSubjectData, false, true, 0, false, pkIndTemplateParent);
		pkIndTemplateParent->AddChild(pkSubject);

		QString pkMessageBody = pkCommsConfig->GetEmailBlock(usCount, CONFIG_MODIFIABLE);

		if (pkMessageBody != NULL) {
			CScriptData *pkMultiLineTemplateData = new CScriptData(pkMessageBody, g_ulMAX_SCRIPT_LEN, usCount, 0, 0,
					false);

			strSubTitle = pkMultiLineTemplateData->GetDataAsString();

			// now remove all control characters (specifically carriage return and line feed)
			strSubTitle.Replace(L"\r", L" ");

			strSubTitle.Replace(L"\n", L" ");

			strSubTitle.Replace(L"\t", L" ");

			strTitle = tr("Message Body");

			CConfigItem *pkMultiLineTemplate = new CConfigItem(ms_strEMAIL_MESSAGE_BODY_KEY, strTitle, strSubTitle,
					ctItemButton, pkMultiLineTemplateData, false, true, 0, false, pkIndTemplateParent);
			pkIndTemplateParent->AddChild(pkMultiLineTemplate);
		} else {
			qDebug("Multiline email template block invalid");
			DebugBreak();
		}
	}
}
//****************************************************************************
// CConfigBranch *CreateNetworkAdminConfig( )
///
/// Method that creates the network admin config heirarchy
///
/// @return Pointer to the network admin config hierarchy
///
//****************************************************************************
CConfigBranch* CRecSetupCfgMgr::CreateNetworkAdminConfig() {
	CConfigBranch *pkParent = NULL;
	BOOL bScheduledexport = FALSE;
	QString  strTitle("");
	QString  strSubTitle("");

	//Added for Scheduled Export if scheduled export is enabled for Shared path then do not allow to change the path
	//Uncomment if 	u want to gray out UseShare and Sharepath while Export is going
	/*T_PRECPROFILE ptProfile = pSETUP->GetGeneralSetupConfig()->GetProfileBlock(CONFIG_MODIFIABLE);

	 if( ptProfile != NULL )
	 {
	 T_LOGGINGINFO *ptLogging = &ptProfile->Logging;
	 if(ptLogging != NULL) 
	 if( TRUE == ptLogging->DoSchedExport )
	 {
	 if(ptLogging->SchedExportDev == LOGDEV_SHARE)
	 {
	 bScheduledexport= TRUE;
	 }
	 }
	 }*/
	//end
	CSingleLock lock(&m_GlbSetupMutex);
	lock.Lock();
	CCommsSetupConfig *pkCommsConfig = pGlbSetup->GetCommsSetupConfig();
	lock.Unlock();
	T_PCOMMUNICATIONS ptCommsData = NULL;
	if (pkCommsConfig != NULL) {
		ptCommsData = pkCommsConfig->GetCommsBlock(CONFIG_MODIFIABLE);
	}

	if (ptCommsData != NULL) {
		T_LANINFO *ptLanInfo = &ptCommsData->LanInfo;

		strTitle = tr("Network Admin");
		strSubTitle = strTitle;

		pkParent = new CConfigBranch(ms_strNETWORK_ADMIN_KEY, strTitle, strSubTitle, ctSubMenuButton, false, true, 0,
				false, NULL);

		// now add the username field
		QString   CfgData *pkUserNameData = new QString   CfgData(ptLanInfo->user,
		LANINFO_USER_LEN, dtString, 0, 0, false);
		strTitle = tr("Username");
		CConfigItem *pkUserName = new CConfigItem(ms_strNETWORK_ADMIN_USERNAME_KEY, strTitle,
				pkUserNameData->GetDataAsString(), ctItemButton, pkUserNameData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkUserName);

		// now add the password field
		QString   CfgData *pkPasswordData = new QString   CfgData(ptLanInfo->password,
		LANINFO_PASSWORD_LEN, dtPassword, 0, 0, false);
		strTitle = tr("Password");
		CConfigItem *pkPassword = new CConfigItem(ms_strNETWORK_ADMIN_PASSWORD_KEY, strTitle,
				pkPasswordData->GetDataAsString(), ctItemButton, pkPasswordData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkPassword);

		// now add the domain name field
		QString   CfgData *pkDomainData = new QString   CfgData(ptLanInfo->domain,
		LANINFO_DOMAIN_LEN, dtString, 0, 0, false);
		strTitle = tr("Domain");
		CConfigItem *pkDomain = new CConfigItem(ms_strNETWORK_ADMIN_DOMAIN_KEY, strTitle,
				pkDomainData->GetDataAsString(), ctItemButton, pkDomainData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkDomain);

		// NETWORK SHARE FOR LOGGING NOT TO BE INCLUDED FOR NOW DUE TO THE COMPLICATIONS THAT
		// COULD ARISE BECAUSE OF IT - E.G. MULTIPLE FILE ACCESS, UNABLE TO DETECT DISK FULL
		// Use share - this will be a bitfield
		CShortBitFieldData *pkUseShareData = new CShortBitFieldData(reinterpret_cast< USHORT*>(&ptLanInfo->UseShare), 1,
				0, ms_strEnabledList, bfeBool, 0, 0, true);
		strTitle = tr("Use Share Path");
		CConfigItem *pkUseShare = new CConfigItem(ms_strNETWORK_ADMIN_USE_SHARE_KEY, strTitle,
				pkUseShareData->GetDataAsString(), ctItemButton, pkUseShareData, false, !bScheduledexport, 0, false,
				pkParent);
		pkParent->AddChild(pkUseShare);

		// now add the share path field
		QString   CfgData *pkShareData = new QString   CfgData(ptLanInfo->sharePath,
		LANINFO_SHAREPATH_LEN,
		/*dtString,*/dtSharePath, 0, 0, false);
		strTitle = tr("Share Path");

		CConfigItem *pkShare = new CConfigItem(ms_strNETWORK_ADMIN_SHARE_PATH_KEY, strTitle,
				pkShareData->GetDataAsString(), ctItemButton, pkShareData, false,
				(ptLanInfo->UseShare != FALSE && !bScheduledexport), 0, false, pkParent);
		pkParent->AddChild(pkShare);
	}

	return pkParent;
}
//****************************************************************************
// CConfigBranch *CreateRecordingSchedConfig( )
///
/// Method that creates the scheduled recording config heirarchy
///
/// @return Pointer to the scheduled recording config hierarchy
///
//****************************************************************************
CConfigBranch* CRecSetupCfgMgr::CreateRecordingSchedConfig() {
	CConfigBranch *pkParent = NULL;

	QString  strTitle("");

	// setup the device names which can include the NAS share name if one has been specified
	ms_strRecordingSchedDeviceList = CreateExportDevList(CONFIG_MODIFIABLE);

	// now setup the actual schedule export fields
	T_PRECPROFILE ptProfile = pSETUP->GetGeneralSetupConfig()->GetProfileBlock(CONFIG_MODIFIABLE);

	if (ptProfile != NULL) {
		T_LOGGINGINFO *ptLogging = &ptProfile->Logging;

		strTitle = tr("Scheduled");

		pkParent = new CConfigBranch(ms_strRECORDING_SCHED_KEY, strTitle, strTitle, ctSubMenuButton, false, true, 0,
				false, NULL);

		// Perform scheduled export - this will be a boolean type bitfield
		CShortBitFieldData *pkEnData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptLogging), 1, 0,
				ms_strEnabledList, bfeBool, 0, 0, true);
		strTitle = tr("Schedule Export");
		CConfigItem *pkEnabled = new CConfigItem(ms_strENABLED_KEY, strTitle, pkEnData->GetDataAsString(), ctItemButton,
				pkEnData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkEnabled);

		// Scheduled export device
		CShortBitFieldData *pkLogDeviceData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptLogging), 3, 1,
				ms_strRecordingSchedDeviceList, bfeSingleSelList, 0, 0, false);
		strTitle = tr("Export Device");
		CConfigItem *pkLogDevice = new CConfigItem(ms_strRECORDING_SCHED_DEVICE_KEY, strTitle,
				pkLogDeviceData->GetDataAsString(), ctItemButton, pkLogDeviceData, false,
				(ptLogging->DoSchedExport == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkLogDevice);

		// Scheduled export time
		CShortBitFieldData *pkLogUpdatePeriodData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptLogging), 4, 4,
				ms_strRecordingSchedTimeList, bfeSingleSelList, 0, 0, false);
		strTitle = tr("Update Period");
		CConfigItem *pkLogUpdatePeriod = new CConfigItem(ms_strRECORDING_SCHED_TIME_KEY, strTitle,
				pkLogUpdatePeriodData->GetDataAsString(), ctItemButton, pkLogUpdatePeriodData, false,
				(ptLogging->DoSchedExport == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkLogUpdatePeriod);

		// Scheduled export log message
		CShortBitFieldData *pkLogMsgData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptLogging), 1, 9,
				ms_strEnabledList, bfeBool, 0, 0, true);
		strTitle = tr("Log Messages");
		CConfigItem *pkLogMsg = new CConfigItem(ms_strRECORDING_SCHED_LOG_MESSAGE_KEY, strTitle,
				pkLogMsgData->GetDataAsString(), ctItemButton, pkLogMsgData, false, (ptLogging->DoSchedExport == TRUE),
				0, false, pkParent);
		pkParent->AddChild(pkLogMsg);

		// Scheduled export mark chart - only enable the control if log message is selected
		CShortBitFieldData *pkMarkChartData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptLogging), 1, 10,
				ms_strEnabledList, bfeBool, 0, 0, false);
		strTitle = tr("Mark Chart");
		CConfigItem *pkMarkChart = new CConfigItem(ms_strRECORDING_SCHED_MARK_CHART_KEY, strTitle,
				pkMarkChartData->GetDataAsString(), ctItemButton, pkMarkChartData, false,
				(ptLogging->DoSchedExport == TRUE) && (ptLogging->LogMessage == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkMarkChart);
	}

	return pkParent;
}
//****************************************************************************
// const QString   CreateExportDevList( const REFERENCE eCFG_TYPE ) const
///
/// Method that creates the delimitted export device list based on the current recorder type
/// and other configuration settings
///
/// @param[in]		const REFERENCE eCFG_TYPE - The config to look at
///
/// @return A string containing the delimitted lists of export devices
///
//****************************************************************************
const QString  CRecSetupCfgMgr::CreateExportDevList(const REFERENCE eCFG_TYPE) {
	QString  strExportDevList("");

	// setup the device names which can include the NAS share name if one has been specified
#ifdef XSERIESSETUP
	strExportDevList = tr("Front CF|USB1|USB2|");
#else
	strExportDevList = tr("Front SD|USB1|USB2|");
#endif
	CSingleLock lock(&m_GlbSetupMutex);
	lock.Lock();
	T_PCOMMUNICATIONS ptCommsData = pGlbSetup->GetCommsSetupConfig()->GetCommsBlock(eCFG_TYPE);

	//For configuring Storage devices
	T_PGENERALCONFIG ptGeneralConfigData = pGlbSetup->GetGeneralSetupConfig()->GetSystemGeneralBlock(eCFG_TYPE);
	lock.Unlock();

	//End
	if (ptCommsData != NULL) {

#ifndef TTR6SETUP
		QString  strSharePath("");
		strSharePath = ptCommsData->LanInfo.sharePath;
		if (ptCommsData->LanInfo.UseShare == TRUE) {
			// check the name is not empty and contains some forward slashes
			if ((strSharePath != "") && (strSharePath.indexOf(L"\\\\", 0) != -1)) {
				strExportDevList += strSharePath + L"|";
			}
		}
#endif

		// if this is an EZTrend then we need to recreate the recording device list, removing the 
		// front SD option from the list and adding the embedded index numbers because this list
		// will now be out of sequence
		USHORT usDevCount = LOGDEV_EXT_SD;
		if (GlbDevCaps.IsRecorderEzTrend() && !pGlbSysInfo->FWOptionExtSDAvailable()) {
			// start with the first USB port
			usDevCount = LOGDEV_USB1;
		}
		QString  strTempList("");
		QString  strDevice("");
		QString  strListItem("");
		for ( /* do nothing as already set */; usDevCount <= LOGDEV_SHARE; usDevCount++) {
			if ((/*ptGeneralConfigData->LoadSaveMedia.LoadCF == 0 && */
			ptGeneralConfigData->LoadSaveMedia.SaveCF == 0) && usDevCount == LOGDEV_EXT_SD) {
				continue;
			}
			if ((/*ptGeneralConfigData->LoadSaveMedia.LoadUsb1 == 0 &&*/
			ptGeneralConfigData->LoadSaveMedia.SaveUsb1 == 0) && usDevCount == LOGDEV_USB1) {
				continue;
			}

			//PSR - fix for 1-3DXWHML QXe_General Status shows Expansion Board and Comms Board as connected though Support is removed
			//The USB2 is not part of AristosEzrecorder so remove from UI exportdevice list
			if ((/*ptGeneralConfigData->LoadSaveMedia.LoadUsb2 == 0 && */
			ptGeneralConfigData->LoadSaveMedia.SaveUsb2 == 0 || GlbDevCaps.IsRecorderEzTrend())
					&& usDevCount == LOGDEV_USB2) {
				continue;
			}

			if ((/*ptGeneralConfigData->LoadSaveMedia.LoadNAS == 0 &&*/
			ptGeneralConfigData->LoadSaveMedia.SaveNAS == 0) && usDevCount == LOGDEV_SHARE) {
				continue;
			}
			strDevice = CStringUtils::GetItemAtPos(strExportDevList, usDevCount);

			// check there is something to read
			if (strDevice != "") {
				strListItem.asprintf(L"%s%c%u%c%c", strDevice, g_wcEMBEDDED_INFO_DELIM, usDevCount,
						g_wcEMBEDDED_INFO_DELIM, CConfigInterface::ms_wcDELIMITER);

				// add it to the new list
				strTempList += strListItem;

			} else {
				// must be the share drive, skip this item
			}
		}
		// copy over to the list
		strExportDevList = strTempList;
	}
	return strExportDevList;
}
//****************************************************************************
// CConfigBranch *CreateRecordingAlarmsConfig( )
///
/// Method that creates the recording alarms config heirarchy
///
/// @return Pointer to the recording alarms config hierarchy
///
//****************************************************************************
CConfigBranch* CRecSetupCfgMgr::CreateRecordingAlarmsConfig() {
	CConfigBranch *pkParent = NULL;

	QString  strTitle("");
	QString  strHours("");
	strHours = tr("Hrs.");

	static T_NUMFORMAT s_tNumasprintf;
	s_tNumasprintf.Ad = 1;
	s_tNumasprintf.Bd = 0;
	s_tNumasprintf.Auto = FALSE;
	s_tNumasprintf.Scientific = FALSE;
	s_tNumasprintf.Zpad = FALSE;

	// setup the parent
	strTitle = tr("Storage Alarm");

	pkParent = new CConfigBranch(ms_strRECORDING_ALM_KEY, strTitle, strTitle, ctSubMenuButton, false, true, 0, false,
			NULL);

	// setup the internal and export memory fields first
	T_PRECPROFILE ptProfile = pSETUP->GetGeneralSetupConfig()->GetProfileBlock(CONFIG_MODIFIABLE);

	if (ptProfile != NULL) {
		T_LOGGINGINFO *ptLogging = &ptProfile->Logging;

		// add the internal memory first
		CFloatData *pkIntMemData = new CFloatData(&ptLogging->IntMemAlmTime, 0.5, 48, 0, 0, false, dtFloat, TEMP_DEG_C,
				strHours, &s_tNumasprintf);

		strTitle = tr("Int. Memory");
		CConfigItem *pkIntMem = new CConfigItem(ms_strRECORDING_ALM_INT_MEM_KEY, strTitle,
				pkIntMemData->GetDataAsString(true), ctItemButton, pkIntMemData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkIntMem);

		// now do the export media
		CFloatData *pkExpMediaData = new CFloatData(&ptLogging->ExpMediaAlmTime, 0.5, 48, 0, 0, false, dtFloat,
				TEMP_DEG_C, strHours, &s_tNumasprintf);

		strTitle = tr("Export Media");
		CConfigItem *pkExpMedia = new CConfigItem(ms_strRECORDING_ALM_EXP_MEDIA_KEY, strTitle,
				pkExpMediaData->GetDataAsString(true), ctItemButton, pkExpMediaData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkExpMedia);

	}

	// now setup the FTP memory
	CSingleLock lock(&m_GlbSetupMutex);
	lock.Lock();
	T_PCOMMUNICATIONS ptCommsData = pGlbSetup->GetCommsSetupConfig()->GetCommsBlock(CONFIG_MODIFIABLE);
	lock.Unlock();

	if (ptCommsData != NULL) {
		// now do the FTP memory
		CFloatData *pkFTPMemData = new CFloatData(&ptCommsData->FTP.FTPMemAlmTime, 0.5, 48, 0, 0, false, dtFloat,
				TEMP_DEG_C, strHours, &s_tNumasprintf);

		strTitle = tr("FTP Memory");
		CConfigItem *pkFTPMem = new CConfigItem(ms_strRECORDING_ALM_FTP_MEM_KEY, strTitle,
				pkFTPMemData->GetDataAsString(true), ctItemButton, pkFTPMemData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkFTPMem);

	}

	return pkParent;
}
//****************************************************************************
// CConfigBranch *CreateRecordingPreTriggerConfig( )
///
/// Method that creates the recording pretrigger config heirarchy
///
/// @return Pointer to the recording pretrigger config hierarchy
///
//****************************************************************************
CConfigBranch* CRecSetupCfgMgr::CreateRecordingPreTriggerConfig() {
	CConfigBranch *pkParent = NULL;

	QString  strTitle("");
	QString  strMinutes("");
	strMinutes = tr("Mins.");

	QString  strSeconds("");
	strSeconds = tr("Secs.");

	// setup the parent
	strTitle = tr("Pre-Trigger");

	pkParent = new CConfigBranch(ms_strRECORDING_PRETRIGGER_KEY, strTitle, strTitle, ctSubMenuButton, false, true, 0,
			false, NULL);

	// setup the pretrigger time field
	T_PRECPROFILE ptProfile = pSETUP->GetGeneralSetupConfig()->GetProfileBlock(CONFIG_MODIFIABLE);

	if (ptProfile != NULL) {
		T_LOGGINGINFO *ptLogging = &ptProfile->Logging;

		// setup the pre-trigger time
		CUShortData *pkPretriggerTimeData = new CUShortData(&ptLogging->PretriggerTime, 1, PRE_TRIGGER_MAX_MINUTES, 0,
				0, false, dtUnsignedShort, strMinutes);

		strTitle = tr("Pre-Trigger Time");
		CConfigItem *pkPretriggerTime = new CConfigItem(ms_strRECORDING_PRETRIGGER_TIME_KEY, strTitle,
				pkPretriggerTimeData->GetDataAsString(true), ctItemButton, pkPretriggerTimeData, false, true, 0, false,
				pkParent);
		pkParent->AddChild(pkPretriggerTime);

		// setup the post-trigger time
		CUShortData *pkPostTriggerTimeData = new CUShortData(&ptLogging->PostTriggerTime, 0, POST_TRIGGER_MAX_SECONDS,
				0, 0, false, dtUnsignedShort, strSeconds);

		strTitle = tr("Post-Trigger Time");
		CConfigItem *pkPostTriggerTime = new CConfigItem(ms_strRECORDING_POSTTRIGGER_TIME_KEY, strTitle,
				pkPostTriggerTimeData->GetDataAsString(true), ctItemButton, pkPostTriggerTimeData, false, true, 0,
				false, pkParent);
		pkParent->AddChild(pkPostTriggerTime);

	}

	return pkParent;
}
//****************************************************************************
// CConfigBranch *CreateFTPConfig( )
///
/// Method that creates the FTP config heirarchy
///
/// @return Pointer to the FTP config hierarchy
///
//****************************************************************************
CConfigBranch* CRecSetupCfgMgr::CreateFTPConfig() {
	WCHAR szDbgMsg[512];
	CConfigBranch *pkParent = NULL;

	QString  strTitle("");

	CSingleLock lock(&m_GlbSetupMutex);
	lock.Lock();
	T_PCOMMUNICATIONS ptCommsData = pGlbSetup->GetCommsSetupConfig()->GetCommsBlock(CONFIG_MODIFIABLE);
	lock.Unlock();

	if (ptCommsData != NULL) {
		T_FTP *ptFTP = &ptCommsData->FTP;

		strTitle = tr("FTP");

		pkParent = new CConfigBranch(ms_strFTP_KEY, strTitle, strTitle, ctSubMenuButton, false, true, 0, false, NULL);

		// FTP Enabled - this will be a boolean type bitfield
		CShortBitFieldData *pkEnData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptFTP), 1, 0,
				ms_strEnabledList, bfeBool, 0, 0, true, 0, USHRT_MAX, true);
		strTitle = tr("FTP");
		CConfigItem *pkEnabled = new CConfigItem(ms_strENABLED_KEY, strTitle, pkEnData->GetDataAsString(), ctItemButton,
				pkEnData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkEnabled);

		swprintf(szDbgMsg, L"CRecSetupCfgMgr::CreateFTPConfig %d\n", ptFTP->EnableFTP);
		OutputDebugString(szDbgMsg);

		// SFT Enabled - this will be a boolean type bitfield
		CShortBitFieldData *pk_SFT_EnData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptFTP), 1, 5,
				ms_strEnabledList, bfeBool, 0, 0, true, 0, USHRT_MAX, true);
		strTitle = tr("Secure FT");
		CConfigItem *pk_SFT_Enabled = new CConfigItem(ms_strSFT_KEY, strTitle, pk_SFT_EnData->GetDataAsString(),
				ctItemButton, pk_SFT_EnData, false, true, 0, false, pkParent);
		pkParent->AddChild(pk_SFT_Enabled);

		// Allow FTP upload - this will be a boolean type bitfield
		CShortBitFieldData *pkUploadData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptFTP), 1, 1,
				ms_strEnabledList, bfeBool, 0, 0, false);
		strTitle = tr("Allow Upload");
		CConfigItem *pkUpload = new CConfigItem(ms_strFTP_ALLOW_UPLOAD_KEY, strTitle, pkUploadData->GetDataAsString(),
				ctItemButton, pkUploadData, false, (ptFTP->EnableFTP == TRUE) || (ptFTP->SecureFTP == TRUE), 0, false,
				pkParent);
		pkParent->AddChild(pkUpload);

		// Allow FTP download - this will be a boolean type bitfield
		CShortBitFieldData *pkDownloadData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptFTP), 1, 2,
				ms_strEnabledList, bfeBool, 0, 0, false);
		strTitle = tr("Allow Download");
		CConfigItem *pkDownload = new CConfigItem(ms_strFTP_ALLOW_DOWNLOAD_KEY, strTitle,
				pkDownloadData->GetDataAsString(), ctItemButton, pkDownloadData, false,
				(ptFTP->EnableFTP == TRUE) || (ptFTP->SecureFTP == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkDownload);

		// FTP data download log message
		CShortBitFieldData *pkLogMsgData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptFTP), 1, 3,
				ms_strEnabledList, bfeBool, 0, 0, true);
		strTitle = tr("Log Messages");
		CConfigItem *pkLogMsg = new CConfigItem(ms_strFTP_LOG_MESSAGE_KEY, strTitle, pkLogMsgData->GetDataAsString(),
				ctItemButton, pkLogMsgData, false, (ptFTP->EnableFTP == TRUE) || (ptFTP->SecureFTP == TRUE), 0, false,
				pkParent);
		pkParent->AddChild(pkLogMsg);

		// FTP data download mark chart - only enable the control if log message is selected
		CShortBitFieldData *pkMarkChartData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptFTP), 1, 4,
				ms_strEnabledList, bfeBool, 0, 0, false);
		strTitle = tr("Mark Chart");
		CConfigItem *pkMarkChart = new CConfigItem(ms_strFTP_MARK_CHART_KEY, strTitle,
				pkMarkChartData->GetDataAsString(), ctItemButton, pkMarkChartData, false,
				((ptFTP->EnableFTP == TRUE) || (ptFTP->SecureFTP == TRUE)) && (ptFTP->LogMessage == TRUE), 0, false,
				pkParent);
		pkParent->AddChild(pkMarkChart);
//************************************************************************************************************8

		/*swprintf( szDbgMsg, L"CRecSetupCfgMgr::CreateFTPConfig %d\n",ptFTP->SecureFTP);
		 OutputDebugString(szDbgMsg);*/
	}

	return pkParent;
}

//****************************************************************************
// CConfigBranch *CreateOPCUAConfig( )
///
/// Method that creates the OPC UA config heirarchy
///
/// @return Pointer to the OPC UA config hierarchy
///
//****************************************************************************
CConfigBranch* CRecSetupCfgMgr::CreateOPCUAConfig() {
	CConfigBranch *pkParent = NULL;

	QString  strTitle("");

	CSingleLock lock(&m_GlbSetupMutex);
	lock.Lock();
	T_PCOMMUNICATIONS ptCommsData = pGlbSetup->GetCommsSetupConfig()->GetCommsBlock(CONFIG_MODIFIABLE);
	lock.Unlock();

	if (ptCommsData != NULL) {
		T_OPCUA *ptOPCUA = &ptCommsData->OPCUA;

		strTitle = tr("OPC UA");
		pkParent = new CConfigBranch(ms_strOPCUA_KEY, strTitle, strTitle, ctSubMenuButton, false, true, 0, false, NULL);

		// OPCUA Enabled - this will be a boolean type bitfield
		CShortBitFieldData *pkEnData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptOPCUA), 1, 0,
				ms_strEnabledList, bfeBool, 0, 0, true, 0, USHRT_MAX, true);
		strTitle = tr("Enabled");
		CConfigItem *pkEnabled = new CConfigItem(ms_strENABLED_KEY, strTitle, pkEnData->GetDataAsString(), ctItemButton,
				pkEnData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkEnabled);
		CUShortData *pkPortData = new CUShortData(&ptOPCUA->Port, 1, USHRT_MAX, 0, 0, false, dtUnsignedShort,
				"", true);
		strTitle = tr("Port");

		CConfigItem *pkPort = new CConfigItem(ms_strOPCUA_PORT_KEY, strTitle, pkPortData->GetDataAsString(),
				ctItemButton, pkPortData, false, (ptOPCUA->Enabled == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkPort);
	}

	return pkParent;
}

//****************************************************************************
// CConfigBranch *CreateP2PConfig( )
///
/// Method that creates the P2P config heirarchy
///
/// @return Pointer to the P2P config hierarchy
///
//****************************************************************************
CConfigBranch* CRecSetupCfgMgr::CreateP2PConfig() {
	CConfigBranch *pkParent = NULL;

	QString  strTitle("");

	CSingleLock lock(&m_GlbSetupMutex);
	lock.Lock();
	T_PCOMMUNICATIONS ptCommsData = pGlbSetup->GetCommsSetupConfig()->GetCommsBlock(CONFIG_MODIFIABLE);
	lock.Unlock();

	if (ptCommsData != NULL) {
		T_P2P *ptP2P = &ptCommsData->P2P;

		strTitle = tr("Peers");

		pkParent = new CConfigBranch(ms_strP2P_KEY, strTitle, strTitle, ctSubMenuButton, false, true, 0, false, NULL);

		// P2P Enabled - this will be a boolean type bitfield
		CShortBitFieldData *pkEnData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptP2P), 1, 0,
				ms_strEnabledList, bfeBool, 0, 0, true, 0, USHRT_MAX, true);
		strTitle = tr("Enabled");
		CConfigItem *pkEnabled = new CConfigItem(ms_strENABLED_KEY, strTitle, pkEnData->GetDataAsString(), ctItemButton,
				pkEnData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkEnabled);

		// Set Number - this will be a boolean type bitfield
		CShortBitFieldData *pkSetNoData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptP2P), 4, 1,
				ms_strP2PSetNumbersList, bfeSingleSelList, 0, 0, false, 0, USHRT_MAX, true);
		strTitle = tr("Set Number");
		CConfigItem *pkSetNo = new CConfigItem(ms_strP2P_SET_NO_KEY, strTitle, pkSetNoData->GetDataAsString(),
				ctItemButton, pkSetNoData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkSetNo);

		// TCP Socket
		CUShortData *pkTCPSockData = new CUShortData(&ptP2P->TCPPort, 1, USHRT_MAX - (CP2PEngine::m_usMAX_SETS * 2), 0,
				0, true, dtUnsignedShort, "", true);
		strTitle = tr("Start Port");
		CConfigItem *pkTCPSock = new CConfigItem(ms_strP2P_TCP_PORT_KEY, strTitle, pkTCPSockData->GetDataAsString(),
				ctItemButton, pkTCPSockData, false, (ptP2P->Enabled == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkTCPSock);

		// UDP Socket - now highjacked to show the end port number
		ptP2P->UDPPort = ptP2P->TCPPort + (CP2PEngine::m_usMAX_SETS * 2) - 1;

		CUShortData *pkUDPSockData = new CUShortData(&ptP2P->UDPPort, 1, USHRT_MAX, 0, 0, false, dtUnsignedShort,
				"", true);
		strTitle = tr("End Port");

		// override the text string and display the end port instead
		CConfigItem *pkUDPSock = new CConfigItem(ms_strP2P_UDP_PORT_KEY, strTitle, pkUDPSockData->GetDataAsString(),
				ctItemButton, pkUDPSockData, false, false, 0, true, pkParent);
		pkParent->AddChild(pkUDPSock);

	}
	return pkParent;
}
//****************************************************************************
// CConfigBranch *CreatePresetMarkersConfig( )
///
/// Method that creates the preset markers config heirarchy
///
/// @return Pointer to the preset markers config hierarchy
///
//****************************************************************************
CConfigBranch* CRecSetupCfgMgr::CreatePresetMarkersConfig() {
	CConfigBranch *pkParent = NULL;

	QString  strTitle("");
	QString  strKey("");

	CGeneralSetupConfig *pkGenCfg = pSETUP->GetGeneralSetupConfig();
	T_PGENERALCONFIG ptGenCfg = pkGenCfg->GetSystemGeneralBlock(CONFIG_MODIFIABLE);

	if (ptGenCfg != NULL) {
		strTitle = tr("Preset Markers");

		pkParent = new CConfigBranch(ms_strPRESET_MARKERS_KEY, strTitle, strTitle, ctSubMenuButton, false, true, 0,
				false, NULL);

		// loop round adding all the preset markers
		for (USHORT usCount = 0; usCount < GENERALCONFIG_PRESETMARKERS_SIZE; usCount++) {
			// marker 
			QString   CfgData *pkMarkerData = new QString   CfgData(
					reinterpret_cast<WCHAR*>(&ptGenCfg->PresetMarkers[usCount]),
					GENERALCONFIG_PRESETMARKERS_LEN, dtString, 0, 0, false);
			strTitle.asprintf(IDS_CFG_PRESET_MARKERS_MARKER_TITLE, usCount + 1);
			strKey.asprintf(ms_strPRESET_MARKERS_MARKER_KEY, usCount);
			CConfigItem *pkMarker = new CConfigItem(strKey, strTitle, pkMarkerData->GetDataAsString(), ctItemButton,
					pkMarkerData, false, true, 0, false, pkParent);
			pkParent->AddChild(pkMarker);
		}
	}
	return pkParent;
}
//****************************************************************************
// CConfigBranch *CreateReportsConfig( )
///
/// Method that creates the reports config heirarchy
///
/// @return Pointer to the reports config hierarchy
///
//****************************************************************************
CConfigBranch* CRecSetupCfgMgr::CreateReportsConfig() {
	CConfigBranch *pkParent = NULL;

	QString  strTitle("");
	QString  strKey("");
	QString  strDoNotInclude("");

	// get the export device list
	ms_strReportIndExportDevList = CreateExportDevList(CONFIG_MODIFIABLE);

	// now add the do not include option to the end and set it to max devices
	strDoNotInclude = tr("Do not export");
	strTitle.asprintf(L"%s%c%u%c%c", strDoNotInclude, g_wcEMBEDDED_INFO_DELIM, LOGDEV_MAX_DEVICES,
			g_wcEMBEDDED_INFO_DELIM, CConfigInterface::ms_wcDELIMITER);

	// add it to the new list
	ms_strReportIndExportDevList = strTitle + ms_strReportIndExportDevList;

	CEventSetupConfig *pkEventCfg = pSETUP->GetEventSetupConfig();
	T_PREPORTS ptReports = pkEventCfg->GetReportsBlock(CONFIG_MODIFIABLE);

	if (ptReports != NULL) {
		QString  strTitle("");
		strTitle = tr("Reports");
		QString  strSubTitle(strTitle);

		// Create the top level parent
		pkParent = new CConfigBranch(ms_strREPORT_IND_KEY, strTitle, strSubTitle, ctMainMenuButton, false, true, 0,
				false, NULL);

		// loop round adding all the reports
		for (USHORT usCount = 0; usCount < REPORTS_REPORT_SIZE; usCount++) {
			// add the individual report item
			QString  strKey("");
			strKey.asprintf(L"%s%d", ms_strREPORT_IND_KEY, usCount);

			// get the title and subtitle
			CreateReportTitle(&ptReports->Report[usCount], usCount, strTitle, strSubTitle);

			// create the individual event parent first
			CConfigBranch *pkNewReport = new CConfigBranch(strKey, strTitle, strSubTitle, ctSubMenuButton, true, true,
					0, false, pkParent);

			// now setup the report details
			SetupReportDetails(pkNewReport, &ptReports->Report[usCount], usCount);

			pkParent->AddChild(pkNewReport);
		}
	}
	return pkParent;
}
//****************************************************************************
// void SetupReportDetails(	CConfigBranch *pkParent, 
//								T_REPORTDATA *ptReport, 
//								const USHORT usREPORT_NO )
///
/// Method that creates a single report config hierarchy
///
/// @param[in/out]			CConfigBranch *pkParent - The parent branch
///	@param[in]				T_REPORT *ptReport - Pointer to the report data
///	@param[in]				const USHORT usREPORT_NO - The report no - zero based
///
//****************************************************************************
void CRecSetupCfgMgr::SetupReportDetails(CConfigBranch *pkParent, T_REPORTDATA *ptReport, const USHORT usREPORT_NO) {
	QString  strTitle("");

	bool bENABLED = (ptReport->Enabled == TRUE);

	// Report enabled
	CLongBitFieldData *pkEnabledData = new CLongBitFieldData(reinterpret_cast<ULONG*>(ptReport), 1, 0,
			ms_strEnabledList, bfeBool, 0, 0, true);

	strTitle = tr("Enabled");
	CConfigItem *pkEnabled = new CConfigItem(ms_strENABLED_KEY, strTitle, pkEnabledData->GetDataAsString(),
			ctItemButton, pkEnabledData, false, true, 0, false, pkParent);
	pkParent->AddChild(pkEnabled);

	// Name - WCHAR edit
	QString   CfgData *pkTagData = new QString   CfgData(ptReport->Tag,
	REPORTDATA_TAG_LEN, dtString, 0, 0, true);
	strTitle = tr("Name");
	CConfigItem *pkTag = new CConfigItem(ms_strREPORT_IND_TAG_KEY, strTitle, pkTagData->GetDataAsString(), ctItemButton,
			pkTagData, false, bENABLED, 0, false, pkParent);
	pkParent->AddChild(pkTag);

	/* REMOVED FOR NOW AS ALWAYS FIXED TO SINGLE SHOT
	 // Report type - lock this item to single short as continuous is going to be implemented later
	 CLongBitFieldData *pkTypeData = new CLongBitFieldData(	reinterpret_cast< ULONG* >( ptReport ),
	 2,
	 1,
	 ms_strReportIndTypeList,
	 bfeSingleSelList,
	 0,
	 0,
	 true );

	 strTitle = tr("Type");
	 CConfigItem *pkType = new CConfigItem(	ms_strREPORT_IND_TYPE_KEY,
	 strTitle,
	 pkTypeData->GetDataAsString(),
	 ctItemButton,
	 pkTypeData,
	 false,
	 bENABLED,
	 0,
	 true,
	 pkParent );
	 pkParent->AddChild( pkType );
	 */

	// make sure the trigger is fixed as an event for now until the code is enhanced
	if (ptReport->Trigger != rstEVENT) {
		// force to an event
		ptReport->Trigger = rstEVENT;
	}

	/* FIXED TO EVENT FOR NOW
	 // Report trigger
	 CLongBitFieldData *pkTriggerData = new CLongBitFieldData(	reinterpret_cast< ULONG* >( ptReport ),
	 3,
	 3,
	 ms_strReportIndTriggerList,
	 bfeSingleSelList,
	 0,
	 0,
	 true );

	 strTitle = tr("Trigger");
	 CConfigItem *pkTrigger = new CConfigItem(	ms_strREPORT_IND_TRIGGER_KEY,
	 strTitle,
	 pkTriggerData->GetDataAsString(),
	 ctItemButton,
	 pkTriggerData,
	 false,
	 bENABLED,
	 0,
	 true,// LOCK THIS CONTROL AS IT IS TO BE FIXED TO EVENT FOR NOW
	 pkParent );
	 pkParent->AddChild( pkTrigger );
	 */

	// Report style
	CShortBitFieldData *pkStyleData = new CShortBitFieldData(&ptReport->ReportStyle, 16, 0, ms_strReportIndStyleList,
			bfeSingleSelList, 0, 0, true);

	strTitle = tr("Style");
	CConfigItem *pkStyle = new CConfigItem(ms_strREPORT_IND_STYLE_KEY, strTitle, pkStyleData->GetDataAsString(),
			ctItemButton, pkStyleData, false, bENABLED, 0, false, pkParent);
	pkParent->AddChild(pkStyle);

	/* REMOVED FOR NOW AS THE EVENT SYSTEM CAN BE USED TO GENERATE ALL TYPES OF REPORT
	 // check if this is a schedule report
	 if( ptReport->Trigger == rstSCHEDULE )
	 {
	 strTitle = tr("Schedule");

	 // Create the schedule parent
	 CConfigBranch *pkScheduleParent = new CConfigBranch(	ms_strREPORT_IND_SCHEDULE_KEY,
	 strTitle,
	 CStringUtils::GetItemAtPos( ms_strReportIndSchedSubTypeList, ptReport->SchedSubType ),
	 ctSubMenuButton,
	 false,
	 true,
	 0,
	 false,
	 pkParent );

	 pkParent->AddChild( pkScheduleParent );

	 // setup the menu subtype selection
	 CLongBitFieldData *pkSchedSubTypeData = new CLongBitFieldData(	reinterpret_cast< ULONG* >( ptReport ),
	 2,
	 28,
	 ms_strReportIndSchedSubTypeList,
	 bfeSingleSelList,
	 0,
	 0,
	 true );

	 strTitle = tr("Sched. Type");
	 CConfigItem *pkSchedSubType = new CConfigItem(	ms_strREPORT_IND_SCHEDULE_SUB_TYPE_KEY,
	 strTitle,
	 pkSchedSubTypeData->GetDataAsString(),
	 ctItemButton,
	 pkSchedSubTypeData,
	 false,
	 bENABLED,
	 0,
	 false,
	 pkScheduleParent );
	 pkScheduleParent->AddChild( pkSchedSubType );

	 // now setup the reset of the submenu data
	 SetupScheduledEvent(	pkScheduleParent,
	 &ptReport->Schedule,
	 static_cast< T_SCHED_EVENT_SUBTYPE >( ptReport->SchedSubType ),
	 bENABLED );
	 }
	 */

	// don't show all the fields for TUS reports as the data is fixed for TUS
	if (ptReport->ReportStyle != rssTUS) {
		// only show this choice if normal is selected
		if (ptReport->ReportStyle == rssNORMAL) {
			// Pen selection type
			CLongBitFieldData *pkPenSelTypeData = new CLongBitFieldData(reinterpret_cast<ULONG*>(ptReport), 2, 6,
					ms_strReportIndPenSelTypeList, bfeSingleSelList, 0, 0, true);

			strTitle = tr("Selection Type");
			CConfigItem *pkPenSelType = new CConfigItem(ms_strREPORT_IND_PEN_SEL_TYPE_KEY, strTitle,
					pkPenSelTypeData->GetDataAsString(), ctItemButton, pkPenSelTypeData, false, bENABLED, 0, false,
					pkParent);
			pkParent->AddChild(pkPenSelType);
		}

		// check if groups
		if ((ptReport->PenSelType == epsPEN_GROUP) || (ptReport->ReportStyle == rssBATCH)) {
			// loop through the groups inserting their number and name
			QString  strGroup("");
			T_PGENERALCONFIG ptGeneralData = pSETUP->GetGeneralSetupConfig()->GetSystemGeneralBlock(CONFIG_MODIFIABLE);

			ms_strGroupList = "";
			for (USHORT usGroupCount = 0; usGroupCount < GENERALCONFIG_GROUPNAME_SIZE; usGroupCount++) {
				strGroup.asprintf(L"%s|", ptGeneralData->GroupName[usGroupCount]);
				ms_strGroupList += strGroup;
			}

			// Group selection
			CLongBitFieldData *pkGroupData = new CLongBitFieldData(reinterpret_cast<ULONG*>(ptReport), 3, 20,
					ms_strGroupList, bfeSingleSelList, 0, 0, false);

			strTitle = tr("Group");
			CConfigItem *pkGroup = new CConfigItem(ms_strREPORT_IND_GROUP_KEY, strTitle, pkGroupData->GetDataAsString(),
					ctItemButton, pkGroupData, false, bENABLED, 0, false, pkParent);
			pkParent->AddChild(pkGroup);
		}

		// Current Pen Data
		CLongBitFieldData *pkCurrPenData = new CLongBitFieldData(reinterpret_cast<ULONG*>(ptReport), 1, 8,
				ms_strReportIndIncCurrPenList, bfeSingleSelList, 0, 0, true);

		strTitle = tr("Curr. Pen Value");
		CConfigItem *pkCurrPen = new CConfigItem(ms_strREPORT_IND_INC_CURR_PEN_KEY, strTitle,
				pkCurrPenData->GetDataAsString(), ctItemButton, pkCurrPenData, false, bENABLED, 0, false, pkParent);
		pkParent->AddChild(pkCurrPen);

		// Include max/mins
		CLongBitFieldData *pkMaxMinData = new CLongBitFieldData(reinterpret_cast<ULONG*>(ptReport), 4, 9,
				(ptReport->ReportStyle == rssBATCH) ? ms_strReportIndIncCurrPenList : ms_strReportIndPeriodList,
				bfeSingleSelList, 0, 0, true);

		strTitle = tr("Max/Mins");
		CConfigItem *pkMaxMin = new CConfigItem(ms_strREPORT_IND_INC_MAX_MIN_KEY, strTitle,
				pkMaxMinData->GetDataAsString(), ctItemButton, pkMaxMinData, false, bENABLED, 0, false, pkParent);
		pkParent->AddChild(pkMaxMin);

		// Include averages but only if the report style is normal as we can't show system/user averages on batch
		if (ptReport->ReportStyle == rssNORMAL) {
			CShortBitFieldData *pkAvgData = new CShortBitFieldData(&ptReport->IncAverages, 16, 0,
					ms_strReportIndAvgPeriodList, bfeSingleSelList, 0, 0, true);

			strTitle = tr("Averages");
			CConfigItem *pkAvg = new CConfigItem(ms_strREPORT_IND_INC_AVERAGE_KEY, strTitle,
					pkAvgData->GetDataAsString(), ctItemButton, pkAvgData, false, bENABLED, 0, false, pkParent);
			pkParent->AddChild(pkAvg);
		}

		// check the pen selection type is set to multiple pens this is not configured for groups and that
		// either current pen value or max min is selected
		if ((ptReport->PenSelType == epsINDIVIDUAL_SELS) && (ptReport->ReportStyle == rssNORMAL)) {
			const bool bENABLE_PICKER = bENABLED
					&& ((ptReport->IncCurrPenVal == TRUE) || (ptReport->IncMaxMins != rftNONE)
							|| (ptReport->IncAverages != rftNONE));
			// Include the pen picker
			CPickerData *pkPenData = new CPickerData(reinterpret_cast< USHORT*>(&ptReport->Pens), dtMultiPen, 0, 0,
					false, 1, V6_MAX_PENS);
			strTitle = tr("Pens");
			CConfigItem *pkPen = new CConfigItem(ms_strREPORT_IND_PEN_PKR_KEY, strTitle, pkPenData->GetDataAsString(),
					ctItemButton, pkPenData, false, bENABLE_PICKER, 0, false, pkParent);
			pkParent->AddChild(pkPen);
		}

		// Include totals
		CLongBitFieldData *pkTotalsData = new CLongBitFieldData(reinterpret_cast<ULONG*>(ptReport), 4, 13,
				(ptReport->ReportStyle == rssBATCH) ? ms_strReportIndIncCurrPenList : ms_strReportIndPeriodList,
				bfeSingleSelList, 0, 0, true);

		strTitle = tr("Totals");
		CConfigItem *pkTotals = new CConfigItem(ms_strREPORT_IND_INC_TOTALS_KEY, strTitle,
				pkTotalsData->GetDataAsString(), ctItemButton, pkTotalsData, false,
				bENABLED && pSYSTEM_INFO->FWOptionTotalsAvailable(), 0, false, pkParent);
		pkParent->AddChild(pkTotals);

		// check the pen selection type is set to multiple pens this is not configured for groups
		if ((ptReport->PenSelType == epsINDIVIDUAL_SELS) && (ptReport->ReportStyle == rssNORMAL)) {
			// Include the pen totals picker
			CPickerData *pkPenTotalsData = new CPickerData(reinterpret_cast< USHORT*>(&ptReport->PenTotals),
					dtMultiPenTotaliser, 0, 0, false, 1, V6_MAX_PENS);
			strTitle = tr("Totalizer Pens");
			CConfigItem *pkPenTotals = new CConfigItem(ms_strREPORT_IND_PEN_TOTALS_PKR_KEY, strTitle,
					pkPenTotalsData->GetDataAsString(), ctItemButton, pkPenTotalsData, false,
					bENABLED && (ptReport->IncTotals != rftNONE) && pSYSTEM_INFO->FWOptionTotalsAvailable(), 0, false,
					pkParent);
			pkParent->AddChild(pkPenTotals);
		}

		// Include message list - only include this option when not batch - if batch then we want all messages
		// for the duration for the batch assuming the message lists have been selected in the following 
		// configuration item (i.e. the message list picker)
		if (ptReport->ReportStyle == rssNORMAL) {
			CLongBitFieldData *pkMessagesData = new CLongBitFieldData(reinterpret_cast<ULONG*>(ptReport), 3, 17,
					ms_strReportIndMsgPeriodList, bfeSingleSelList, 0, 0, true);

			strTitle = tr("Messages");
			CConfigItem *pkMessages = new CConfigItem(ms_strREPORT_IND_INC_MESSAGE_KEY, strTitle,
					pkMessagesData->GetDataAsString(), ctItemButton, pkMessagesData, false, bENABLED, 0, false,
					pkParent);
			pkParent->AddChild(pkMessages);
		}

		// Message list picker - this will be a picker
		CPickerData *pkMessageTypesData = new CPickerData(reinterpret_cast< USHORT*>(&ptReport->IncMsgListTypes),
				dtMessageListTypes, 0, 0, false, 0, g_usMAX_SELECTABLE_MSG_LIST_TYPES);

		strTitle = tr("Message Lists");
		CConfigItem *pkMessageTypes = new CConfigItem(ms_strREPORT_IND_MSG_TYPES_KEY, strTitle,
				pkMessageTypesData->GetDataAsString(), ctItemButton, pkMessageTypesData, false,
				bENABLED && ((ptReport->ReportStyle == rssBATCH) || (ptReport->IncMessages != rftNONE)), 0, false,
				pkParent);
		pkParent->AddChild(pkMessageTypes);

		// Include counters - this will be a picker
		CPickerData *pkCountersData = new CPickerData(reinterpret_cast< USHORT*>(&ptReport->IncCounters),
				dtAllCounterTypes, 0, 0, false, 0, g_usMAX_COUNTER_TYPES);

		strTitle = tr("Counters");
		CConfigItem *pkCounters = new CConfigItem(ms_strREPORT_IND_INC_CTR_KEY, strTitle,
				pkCountersData->GetDataAsString(), ctItemButton, pkCountersData, false,
				bENABLED && ( pSYSTEM_INFO->FWOptionCountersAvailable() == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkCounters);

		// Include digital inputs
		CLongBitFieldData *pkDigInData = new CLongBitFieldData(reinterpret_cast<ULONG*>(ptReport), 1, 31,
				ms_strReportIndIncCurrPenList, bfeSingleSelList, 0, 0, false);

		strTitle = tr("Inc. Dig. In");
		CConfigItem *pkDigIn = new CConfigItem(ms_strREPORT_IND_INC_DIG_IN_KEY, strTitle,
				pkDigInData->GetDataAsString(), ctItemButton, pkDigInData, false, bENABLED, 0, false, pkParent);
		pkParent->AddChild(pkDigIn);

		// Include digital outputs
		CShortBitFieldData *pkDigOutData = new CShortBitFieldData(&ptReport->IncDigOutputs, 16, 0,
				ms_strReportIndIncCurrPenList, bfeSingleSelList, 0, 0, false);

		strTitle = tr("Inc. Dig. Outs");
		CConfigItem *pkDigOut = new CConfigItem(ms_strREPORT_IND_INC_DIG_OUT_KEY, strTitle,
				pkDigOutData->GetDataAsString(), ctItemButton, pkDigOutData, false, bENABLED, 0, false, pkParent);
		pkParent->AddChild(pkDigOut);

	}

	// Include dual line or single line footer
	CShortBitFieldData *pkFooterData = new CShortBitFieldData(&ptReport->ReportFooter, 16, 0, ms_strReportIndFooterList,
			bfeSingleSelList, 0, 0, false);

	strTitle = tr("Footer Style");
	CConfigItem *pkFooter = new CConfigItem(ms_strREPORT_IND_FOOTER_KEY, strTitle, pkFooterData->GetDataAsString(),
			ctItemButton, pkFooterData, false, bENABLED, 0, false, pkParent);
	pkParent->AddChild(pkFooter);

	// Send email
	if ( pSYSTEM_INFO->FWOptionEmailAvailable() == FALSE) {
		ptReport->Email = false;
	}
	CLongBitFieldData *pkEmailData = new CLongBitFieldData(reinterpret_cast<ULONG*>(ptReport), 1, 23, ms_strEnabledList,
			bfeBool, 0, 0, true);

	strTitle = tr("Email");
	CConfigItem *pkEmail = new CConfigItem(ms_strREPORT_IND_EMAIL_KEY, strTitle, pkEmailData->GetDataAsString(),
			ctItemButton, pkEmailData, false, bENABLED && ( pSYSTEM_INFO->FWOptionEmailAvailable() == TRUE), 0, false,
			pkParent);
	pkParent->AddChild(pkEmail);

	// Email recipients - only display the recipients of the option is avaialable
	if ( pSYSTEM_INFO->FWOptionEmailAvailable()) {
		CPickerData *pkEmailRecipientsData = new CPickerData(reinterpret_cast< USHORT*>(&ptReport->EmailRecipients),
				dtEmailRecipients, 0, 0, false, 1,
				EMAIL_EMAILADDRESSES_SIZE);

		strTitle = tr("Recipients");
		CConfigItem *pkEmailRecipients = new CConfigItem(ms_strREPORT_IND_EMAIL_RECIP_KEY, strTitle,
				pkEmailRecipientsData->GetDataAsString(), ctItemButton, pkEmailRecipientsData, false,
				bENABLED && (ptReport->Email == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkEmailRecipients);
	}

	// Print
	if (!pSETUP->GetGeneralSetupConfig()->PrintingIsAllowed()) {
		ptReport->Print = false;
	}
	CLongBitFieldData *pkIncPrintData = new CLongBitFieldData(reinterpret_cast<ULONG*>(ptReport), 1, 27,
			ms_strEnabledList, bfeBool, 0, 0, false);

	strTitle = tr("Print");
	CConfigItem *pkIncPrint = new CConfigItem(ms_strREPORT_IND_PRINT_KEY, strTitle, pkIncPrintData->GetDataAsString(),
			ctItemButton, pkIncPrintData, false, bENABLED && ( pSETUP->GetGeneralSetupConfig()->PrintingIsAllowed()), 0,
			false, pkParent);
	pkParent->AddChild(pkIncPrint);

	// Export Device
	CLongBitFieldData *pkExportDevData = new CLongBitFieldData(reinterpret_cast<ULONG*>(ptReport), 3, 24,
			ms_strReportIndExportDevList, bfeSingleSelList, 0, 0, false);

	strTitle = tr("Export Device");
	CConfigItem *pkExportDev = new CConfigItem(ms_strREPORT_IND_EXPORT_DEV_KEY, strTitle,
			pkExportDevData->GetDataAsString(), ctItemButton, pkExportDevData, false, bENABLED, 0, false, pkParent);
	pkParent->AddChild(pkExportDev);
}
//****************************************************************************
// void CreateReportTitle(	const T_REPORTDATA* const ptREPORT, 
//								const USHORT usREPORT_NO,
//								QString   &rstrTitle,
//								QString   &rstrSubTitle ) const
///
/// Method that creates a report title and subtitle
///
///	@param[in]				const T_REPORTDATA* const ptREPORT - Pointer to the 
///							report data
///	@param[in]				const USHORT usREPORT_NO - The report no - zero based
/// @param[out]				QString   &rstrTitle - The report title
/// @param[out]				QString   &rstrSubTitle - The report subtitle
///
//****************************************************************************
void CRecSetupCfgMgr::CreateReportTitle(const T_REPORTDATA *const ptREPORT, const USHORT usREPORT_NO,
		QString  &rstrTitle, QString  &rstrSubTitle) const {
	QString  strasprintf("");
	strasprintf = tr("Report %u");
	rstrTitle.asprintf(strasprintf, usREPORT_NO + 1);

	strasprintf = L"%s %s";
	rstrSubTitle.asprintf(strasprintf, CStringUtils::GetItemAtPos(ms_strEnabledList, ptREPORT->Enabled), ptREPORT->Tag);
}
//****************************************************************************
// CConfigItem *CRecSetupCfgMgr::RefreshReportsConfigTree(	CConfigItem *pkModifiedItem,
//															const USHORT usREPORT_NO )
///
/// Method that refreshes the data for a report branch of a reports configuration menu,
/// usually following a change that requires the tree structure to be regenerated because it is different
///
/// @param[in]		CConfigItem *pkModifiedItem - The modified data item
/// @param[in]		const USHORT usREPORT_NO - The report number to replace - zero based
///
/// @return Pointer to the report config hierarchy
///
//****************************************************************************
CConfigItem* CRecSetupCfgMgr::RefreshReportConfigTree(CConfigItem *pkModifiedItem, const USHORT usREPORT_NO) {
	CConfigItem *pkNewCfgItem = NULL;
	CConfigInterface *pkTopParent = NULL;

	// Store the key name of this item
	const QString  strKEY(pkModifiedItem->GetKey());

	CConfigInterface *pkReportParent = pkModifiedItem;

	// get the top level parent
	while (pkReportParent->GetParent() != NULL) {
		pkReportParent = pkReportParent->GetParent();
	}

	CEventSetupConfig *pkEventCfg = pSETUP->GetEventSetupConfig();
	T_PREPORTS ptReports = pkEventCfg->GetReportsBlock(CONFIG_MODIFIABLE);

	// create the modified report again and replace it within the config tree
	if (ptReports != NULL) {
		T_REPORTDATA *ptReportData = &ptReports->Report[usREPORT_NO];

		QString  strKey("");
		strKey.asprintf(L"%s%d", ms_strREPORT_IND_KEY, usREPORT_NO);

		QString  strTitle("");
		QString  strSubTitle("");

		// get the title and subtitle
		CreateReportTitle(ptReportData, usREPORT_NO, strTitle, strSubTitle);

		// create the individual report parent first
		CConfigBranch *pkNewReport = new CConfigBranch(strKey, strTitle, strSubTitle, ctSubMenuButton, true, true, 0,
				false, pkReportParent);

		// now setup the report details
		SetupReportDetails(pkNewReport, ptReportData, usREPORT_NO);

		// replace the existing event with this new one
		CConfigBranch *pkBranch = static_cast<CConfigBranch*>(pkReportParent);
		pkBranch->ReplaceChild(pkNewReport);

		// we now need to get the new child for the particular item that was being modified
		pkNewCfgItem = static_cast<CConfigItem*>(indexOfChildByKey(strKEY, pkNewReport, 2));
	} else {
		// there has been a problem
		pkNewCfgItem = static_cast<CConfigItem*>(pkTopParent);
	}

	return pkNewCfgItem;
}

//****************************************************************************
//	void GetAnalogueOutputChannelInfo(	const USHORT usANALOGUE_OUTPUT_NO,
//										USHORT &rusSlotNo,
//										USHORT &rusBoardChanNum )
///
/// Method that obtains an analogue output channel slot and board channel number
///
/// @param[in] 				const USHORT usANALOGUE_OUTPUT_NO - The analogue number from 1 - 48
//	@param[out]				USHORT &rusSlotNo - The slot number from 1 - 6
//	@param[out]				USHORT &rusBoardChanNum - The board channel number from 0 - 3
///
/// @return					True if this analogue output is valid
//****************************************************************************
bool CRecSetupCfgMgr::GetAnalogueOutputChannelInfo(const USHORT usANALOGUE_OUTPUT_NO,
USHORT &rusSlotNo,
USHORT &rusBoardChanNum) {
	bool bValid = false;
	CSlotMap *pkSlotMap = CSlotMap::GetHandle();

	// we need to get the slot and board channel number for all the analogue outputs
	const UCHAR ucSLOT_NO = pkSlotMap->GetAnaOutChannelSlotNo(usANALOGUE_OUTPUT_NO, ONE_BASED);

	const UCHAR ucBOARD_CHAN_NUM = pkSlotMap->GetBoardChannelFromAnaOutChannel(usANALOGUE_OUTPUT_NO, ONE_BASED);

	// check the slot number and board channel number are okay
	if ((ucSLOT_NO != SMAP_ILLEGAL_INDEX) && (ucBOARD_CHAN_NUM != SMAP_ILLEGAL_INDEX)) {
		// now confirm if this analogue input exists
		if ( DEVICE_INFO.IsValidAOChannel(static_cast< USHORT >(ucSLOT_NO), static_cast< USHORT >(ucBOARD_CHAN_NUM))) {
			bValid = true;
			rusSlotNo = ucSLOT_NO;
			rusBoardChanNum = ucBOARD_CHAN_NUM;
		}
	}
	return bValid;
}
//****************************************************************************
// CConfigBranch *CreateAMS2750GeneralConfig( )
///
/// Method that creates the general AMS2750 config heirarchy
///
/// @return Pointer to the AMS2750 general config hierarchy
///
//****************************************************************************
CConfigBranch* CRecSetupCfgMgr::CreateAMS2750GeneralConfig() {
	CConfigBranch *pkParent = NULL;

	QString  strTitle("");
	QString  strKey("");

	CGeneralSetupConfig *pkGenCfg = pSETUP->GetGeneralSetupConfig();
	T_PFURNACESCONFIG ptFurnaceInfo = pkGenCfg->GetAMS2750FurnaceInfoBlock(CONFIG_MODIFIABLE);

	if (ptFurnaceInfo != NULL) {
		QString  strTitle(L"AMS2750");
		QString  strSubTitle(strTitle);
		QString  strKey("");

		// Create the top level parent - set the key to AMS2750 process or TUS so the help page displayed
		// will be more relevant
		if ( pSYSTEM_INFO->FWOptionAMS2750ProcessAvailable()) {
			strKey = ms_strAMS2750_GEN_PROCESS_KEY;
		} else {
			strKey = ms_strAMS2750_GEN_TUS_KEY;
		}
		pkParent = new CConfigBranch(strKey, strTitle, strSubTitle, ctMainMenuButton, false, true, 0, false, NULL);

		// menu varies according to whether we are showing AMS2750 process items 
		// or the TUS item
		if ( pSYSTEM_INFO->FWOptionAMS2750ProcessAvailable()) {
			// showing the process mode therefore we just need to show the furnaces
			// loop round adding all the reports
			for (USHORT usCount = 0; usCount < FURNACESCONFIG_FURNACES_SIZE; usCount++) {
				strKey.asprintf(ms_strAMS2750_FURNACE_IND_KEY, usCount);

				strTitle.asprintf(IDS_CFG_AMS2750_FURNACE_TITLE, usCount + 1);

				strSubTitle = ptFurnaceInfo->Furnaces[usCount].Name;

				// create the sub menu item before creating the branch
				CConfigBranch *pkFurnaceParent = new CConfigBranch(strKey, strTitle, strSubTitle, ctSubMenuButton,
						false, true, 0, false, pkParent);

				pkParent->AddChild(pkFurnaceParent);

				// now setup the furnace information
				SetupFurnaceConfig(pkFurnaceParent, &ptFurnaceInfo->Furnaces[usCount], usCount);
			}
		} else {
			// must be showing TUS mode therefore show 1 furnace and all the set points
			strKey.asprintf(ms_strAMS2750_FURNACE_IND_KEY, 0);

			strTitle.asprintf(IDS_CFG_AMS2750_FURNACE_TITLE, 1);

			strSubTitle = ptFurnaceInfo->Furnaces[0].Name;

			// create the furnace sub menu item before creating the branch
			CConfigBranch *pkFurnaceParent = new CConfigBranch(strKey, strTitle, strSubTitle, ctSubMenuButton, false,
					true, 0, false, pkParent);

			pkParent->AddChild(pkFurnaceParent);

			// now setup the furnace information
			SetupFurnaceConfig(pkFurnaceParent, &ptFurnaceInfo->Furnaces[0], 0);

			// setup the stability detection settings
			SetupStabilityDetectionConfig(pkParent, &ptFurnaceInfo->StabDetect);

			// we need a default number format
			T_NUMFORMAT tNumasprintf;
			tNumasprintf.Auto = TRUE;
			tNumasprintf.Base = FALSE;
			tNumasprintf.Zpad = FALSE;
			tNumasprintf.Scientific = FALSE;

			// now loop through creating the setpoints
			for (USHORT usCount = 0; usCount < FURNACESCONFIG_SETPOINTS_SIZE; usCount++) {
				QString  strLevel("");

				// we need to display the level in the correct display units
				strLevel.asprintf(L"%s %s", CStringUtils::asprintfFloat(tNumasprintf,
				pSYSTEM_INFO->GetLocalTempFromDegC(ptFurnaceInfo->Setpoints[usCount].Level)),
						CStringUtils::GetItemAtPos(ms_strLocalTempasprintfList,
								static_cast< USHORT >( pSYSTEM_INFO->GetDisplayTempUnits())));

				strKey.asprintf(ms_strAMS2750_SETPOINT_IND_KEY, usCount);

				strTitle.asprintf(IDS_CFG_AMS2750_SETPOINT_TITLE, usCount + 1);

				strSubTitle.asprintf(L"%s %s",
						CStringUtils::GetItemAtPos(ms_strEnabledList, ptFurnaceInfo->Setpoints[usCount].Enabled),
						strLevel);

				// create the sub menu item before creating the branch
				CConfigBranch *pkSetpointParent = new CConfigBranch(strKey, strTitle, strSubTitle, ctSubMenuButton,
						false, true, 0, false, pkParent);

				pkParent->AddChild(pkSetpointParent);

				// now setup the furnace information
				SetupSetpointConfig(pkSetpointParent, &ptFurnaceInfo->Setpoints[usCount], usCount);
			}
		}
	}
	return pkParent;
}
//****************************************************************************
//
/// Method that creates a single furnace config hierarchy
///
/// @param[in/out]			CConfigBranch *pkParent - The parent branch
///	@param[in]				T_PFURNACE ptfurnace - Pointer to the furnace data
///	@param[in]				const USHORT usFURNACE_NO - The furnace no - zero based
///
//****************************************************************************
void CRecSetupCfgMgr::SetupFurnaceConfig(CConfigBranch *pkParent, T_PFURNACE ptFurnace, const USHORT usFURNACE_NO) {
	QString  strTitle("");

	// furnace name
	QString   CfgData *pkNameData = new QString   CfgData(ptFurnace->Name,
	FURNACE_NAME_LEN, dtString, 0, 0, true);
	strTitle = tr("Name");

	CConfigItem *pkName = new CConfigItem(ms_strAMS2750_FURNACE_NAME_KEY, strTitle, pkNameData->GetDataAsString(),
			ctItemButton, pkNameData, false, true, 0, false, pkParent);
	pkParent->AddChild(pkName);

	// manufacturer name
	QString   CfgData *pkManfData = new QString   CfgData(ptFurnace->Manufacturer,
	FURNACE_MANUFACTURER_LEN, dtString, 0, 0, false);
	strTitle = tr("Manufacturer");

	CConfigItem *pkManf = new CConfigItem(ms_strAMS2750_FURNACE_MANFACT_KEY, strTitle, pkManfData->GetDataAsString(),
			ctItemButton, pkManfData, false, true, 0, false, pkParent);
	pkParent->AddChild(pkManf);

	// model number
	QString   CfgData *pkModelData = new QString   CfgData(ptFurnace->ModelNo,
	FURNACE_MODELNO_LEN, dtString, 0, 0, false);
	strTitle = tr("Model No.");

	CConfigItem *pkModel = new CConfigItem(ms_strAMS2750_FURNACE_MODEL_NO_KEY, strTitle, pkModelData->GetDataAsString(),
			ctItemButton, pkModelData, false, true, 0, false, pkParent);
	pkParent->AddChild(pkModel);

	/*
	 // serial number
	 QString   CfgData *pkSerialData = new QString   CfgData(	ptFurnace->SerialNo,
	 FURNACE_SERIALNO_LEN,
	 dtString,
	 0,
	 0,
	 false );
	 strTitle = tr("Serial No.");

	 CConfigItem *pkSerial = new CConfigItem(	ms_strAMS2750_FURNACE_SERIAL_NO_KEY,
	 strTitle,
	 pkSerialData->GetDataAsString(),						
	 ctItemButton,
	 pkSerialData,
	 false,
	 true,
	 0,
	 false,
	 pkParent );
	 pkParent->AddChild( pkSerial );*/

	// Furnace Class
	CShortBitFieldData *pkClassData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptFurnace), 3, 10,
			ms_strAMS2750FurnaceClassList, bfeSingleSelList, 0, 0, false);
	strTitle = tr("Class");

	CConfigItem *pkClass = new CConfigItem(ms_strAMS2750_FURNACE_CLASS_KEY, strTitle, pkClassData->GetDataAsString(),
			ctItemButton, pkClassData, false, true, 0, false, pkParent);
	pkParent->AddChild(pkClass);

	// Furnace Type
	CShortBitFieldData *pkTypeData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptFurnace), 2, 0,
			ms_strAMS2750FurnaceTypeList, bfeSingleSelList, 0, 0, false);
	strTitle = tr("Mat. Type");

	CConfigItem *pkType = new CConfigItem(ms_strAMS2750_FURNACE_TYPE_KEY, strTitle, pkTypeData->GetDataAsString(),
			ctItemButton, pkTypeData, false, true, 0, false, pkParent);
	pkParent->AddChild(pkType);

	// only display certain items if a TUS recorder or AMS2750 process recorder
	if ( pSYSTEM_INFO->FWOptionTUSModeAvailable()) {
		// Furnace Shape
		CShortBitFieldData *pkShapeData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptFurnace), 2, 6,
				ms_strAMS2750FurnaceShapeList, bfeSingleSelList, 0, 0, true);
		strTitle = tr("Shape");

		CConfigItem *pkShape = new CConfigItem(ms_strAMS2750_FURNACE_SHAPE_KEY, strTitle,
				pkShapeData->GetDataAsString(), ctItemButton, pkShapeData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkShape);

		// Furnace Measured Units
		CShortBitFieldData *pkMeasUnitsData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptFurnace), 2, 8,
				ms_strAMS2750FurnaceMeasUnitsList, bfeSingleSelList, 0, 0, true);
		strTitle = tr("Meas. Units");

		CConfigItem *pkMeasUnits = new CConfigItem(ms_strAMS2750_FURNACE_MEAS_UNITS_KEY, strTitle,
				pkMeasUnitsData->GetDataAsString(), ctItemButton, pkMeasUnitsData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkMeasUnits);

		// Height
		CFloatData *pkHeightData = new CFloatData(&ptFurnace->Height, 0.5, 2000, 0, 0, false, dtFloat, TEMP_DEG_C, // irrelevant
				pkMeasUnitsData->GetDataAsString());

		strTitle = tr("Height");

		CConfigItem *pkHeight = new CConfigItem(ms_strAMS2750_FURNACE_HEIGHT_KEY, strTitle,
				pkHeightData->GetDataAsString(true), ctItemButton, pkHeightData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkHeight);

		// Width
		CFloatData *pkWidthData = new CFloatData(&ptFurnace->Width, 0.5, 2000, 0, 0, false, dtFloat, TEMP_DEG_C, // irrelevant
				pkMeasUnitsData->GetDataAsString());

		// check if this is a cyclinder shaped furnace
		if (ptFurnace->Shape == fsCYLINDRICAL) {
			strTitle = tr("Diameter");
		} else {
			strTitle = tr("Width");
		}

		CConfigItem *pkWidth = new CConfigItem(ms_strAMS2750_FURNACE_WIDTH_KEY, strTitle,
				pkWidthData->GetDataAsString(true), ctItemButton, pkWidthData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkWidth);

		// Depth
		CFloatData *pkDepthData = new CFloatData(&ptFurnace->Depth, 0.5, 2000, 0, 0, false, dtFloat, TEMP_DEG_C, // irrelevant
				pkMeasUnitsData->GetDataAsString());

		strTitle = tr("Depth");

		CConfigItem *pkDepth = new CConfigItem(ms_strAMS2750_FURNACE_DEPTH_KEY, strTitle,
				pkDepthData->GetDataAsString(true), ctItemButton, pkDepthData, false,
				(ptFurnace->Shape != fsCYLINDRICAL), // disable if cylindrical
				0, false, pkParent);
		pkParent->AddChild(pkDepth);
	}

	// Furnace Instrument Type
	CShortBitFieldData *pkInstTypeData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptFurnace), 4, 2,
			ms_strAMS2750FurnaceInstTypeList, bfeSingleSelList, 0, 0, false);
	strTitle = tr("Inst. Type");

	CConfigItem *pkInstType = new CConfigItem(ms_strAMS2750_FURNACE_INST_TYPE_KEY, strTitle,
			pkInstTypeData->GetDataAsString(), ctItemButton, pkInstTypeData, false, true, 0, false, pkParent);
	pkParent->AddChild(pkInstType);

	// high use temp
	CFloatData *pkHighUseTempData = new CFloatData(&ptFurnace->HighUseTemp, -V6_FLT_MAX, V6_FLT_MAX, 0, 0, false,
			dtTemperature,
			pSYSTEM_INFO->GetDisplayTempUnits(),
			CStringUtils::GetItemAtPos(ms_strLocalTempasprintfList,
					static_cast< USHORT >( pSYSTEM_INFO->GetDisplayTempUnits())));

	strTitle = tr("Into cycle at");

	CConfigItem *pkHighUseTemp = new CConfigItem(ms_strAMS2750_FURNACE_HIGH_USE_TEMP_KEY, strTitle,
			pkHighUseTempData->GetDataAsString(true), ctItemButton, pkHighUseTempData, false, true, 0, false, pkParent);
	pkParent->AddChild(pkHighUseTemp);

	// low use temp
	CFloatData *pkLowUseTempData = new CFloatData(&ptFurnace->LowUseTemp, -V6_FLT_MAX, V6_FLT_MAX, 0, 0, false,
			dtTemperature,
			pSYSTEM_INFO->GetDisplayTempUnits(),
			CStringUtils::GetItemAtPos(ms_strLocalTempasprintfList,
					static_cast< USHORT >( pSYSTEM_INFO->GetDisplayTempUnits())));

	strTitle = tr("Out of cycle at");

	CConfigItem *pkLowUseTemp = new CConfigItem(ms_strAMS2750_FURNACE_LOW_USE_TEMP_KEY, strTitle,
			pkLowUseTempData->GetDataAsString(true), ctItemButton, pkLowUseTempData, false, true, 0, false, pkParent);
	pkParent->AddChild(pkLowUseTemp);
}
//****************************************************************************
//
/// Method that creates a single setpoint config hierarchy
///
/// @param[in/out]			CConfigBranch *pkParent - The parent branch
///	@param[in]				T_PSETPOINT ptSetpoint - Pointer to the setpoint data
///	@param[in]				const USHORT usFURNACE_NO - The setpoint no - zero based
///
//****************************************************************************
void CRecSetupCfgMgr::SetupSetpointConfig(CConfigBranch *pkParent, T_PSETPOINT ptSetpoint, const USHORT usSETPOINT_NO) {
	QString  strTitle("");

	CShortBitFieldData *pkEnData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptSetpoint), 1, 0,
			ms_strEnabledList, bfeBool, 0, 0, true);
	strTitle = tr("Enabled");
	CConfigItem *pkEnabled = new CConfigItem(ms_strAMS2750_SETPOINT_ENABLED_KEY, strTitle, pkEnData->GetDataAsString(),
			ctItemButton, pkEnData, false, true, 0, false, pkParent);
	pkParent->AddChild(pkEnabled);

	// temperature level
	CFloatData *pkLevelData = new CFloatData(&ptSetpoint->Level, -V6_FLT_MAX, V6_FLT_MAX, 0, 0, true, dtTemperature,
	pSYSTEM_INFO->GetDisplayTempUnits(),
			CStringUtils::GetItemAtPos(ms_strLocalTempasprintfList,
					static_cast< USHORT >( pSYSTEM_INFO->GetDisplayTempUnits())));

	strTitle = tr("Setpoint");

	CConfigItem *pkLevel = new CConfigItem(ms_strAMS2750_SETPOINT_SOAK_LEVEL_KEY, strTitle,
			pkLevelData->GetDataAsString(true), ctItemButton, pkLevelData, false, (ptSetpoint->Enabled == TRUE), 0,
			false, pkParent);
	pkParent->AddChild(pkLevel);

	// Soak Time
	QString  strMinutes("");
	strMinutes = tr("Mins.");
	CULongData *pkTimeData = new CULongData(&ptSetpoint->Time, 30, 4320, 0, 0, false, dtUnsignedLong, strMinutes);

	strTitle = tr("Stable Soak Time");

	CConfigItem *pkTime = new CConfigItem(ms_strAMS2750_SETPOINT_TIME_KEY, strTitle, pkTimeData->GetDataAsString(true),
			ctItemButton, pkTimeData, false, (ptSetpoint->Enabled == TRUE), 0, false, pkParent);
	pkParent->AddChild(pkTime);

	// tolerance override
	CShortBitFieldData *pkTolOverrideData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptSetpoint), 1, 1,
			ms_strEnabledList, bfeBool, 0, 0, true);
	strTitle = tr("Tolerance Override");
	CConfigItem *pkTolOverride = new CConfigItem(ms_strAMS2750_SETPOINT_TOL_OVERRIDE_KEY, strTitle,
			pkTolOverrideData->GetDataAsString(), ctItemButton, pkTolOverrideData, false, (ptSetpoint->Enabled == TRUE),
			0, false, pkParent);
	pkParent->AddChild(pkTolOverride);

	// tolerance override level
	CFloatData *pkToleranceData = new CFloatData(&ptSetpoint->Tolerance, 0, 60.0, 0, 0, true, dtTempRelative,
	pSYSTEM_INFO->GetDisplayTempUnits(),
			CStringUtils::GetItemAtPos(ms_strLocalTempasprintfList,
					static_cast< USHORT >( pSYSTEM_INFO->GetDisplayTempUnits())));

	strTitle = tr("Tolerance");

	CConfigItem *pkTolerance = new CConfigItem(ms_strAMS2750_SETPOINT_TOLERANCE_KEY, strTitle,
			pkToleranceData->GetDataAsString(true), ctItemButton, pkToleranceData, false,
			((ptSetpoint->Enabled == TRUE) && (ptSetpoint->TolOverride == TRUE)), 0, false, pkParent);
	pkParent->AddChild(pkTolerance);
}
//****************************************************************************
//
/// Method that creates the furnace stability detection config hierarchy
///
/// @param[in/out]			CConfigBranch *pkParent - The parent branch
///	@param[in]				T_PSTABILITYDETECT ptStabDetect - Pointer to the stability detection structure
///
//****************************************************************************
void CRecSetupCfgMgr::SetupStabilityDetectionConfig(CConfigBranch *pkParent, T_PSTABILITYDETECT ptStabDetect) {
	QString  strTitle("");
	strTitle = tr("Stability Detect");

	QString  strSubTitle("");

	QString  strMinutes("");
	strMinutes = tr("Mins.");

	QString  strTempUnits("");
	strTempUnits = CStringUtils::GetItemAtPos(ms_strLocalTempasprintfList,
			static_cast< USHORT >( pSYSTEM_INFO->GetDisplayTempUnits()));

	// setup the time subtitle information
	QString  strTimeSubTitle("");
	if (ptStabDetect->TimerEnable) {
		strTimeSubTitle.asprintf(L" (%u %s)", ptStabDetect->Time, strMinutes);
	}
	QString  strTimerEnTitle("");
	strTimerEnTitle = tr("Timer Enable");

	// setup the degrees change subtitle information
	QString  strDegreesChangeSubTitle("");
	if (ptStabDetect->AutoEnable) {
		strDegreesChangeSubTitle.asprintf(L" (%0.2f %s)",
		pSYSTEM_INFO->GetLocalTempFromDegCRelative(ptStabDetect->DegreeChange), strTempUnits);
	}
	QString  strAutoEnTitle("");
	strAutoEnTitle = tr("Auto Enable");

	if ((ptStabDetect->TimerEnable && ptStabDetect->AutoEnable)
			|| (!ptStabDetect->TimerEnable && !ptStabDetect->AutoEnable)) {
		// insert a tick or cross along with both descriptions
		strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptStabDetect->TimerEnable);
		strSubTitle += strTimerEnTitle + L"/" + strAutoEnTitle;
	} else if (ptStabDetect->TimerEnable) {
		// insert a tick along with the description and its value
		strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptStabDetect->TimerEnable);
		strSubTitle += strTimerEnTitle + strTimeSubTitle;
	} else if (ptStabDetect->AutoEnable) {
		// insert a tick along with the description and its value
		strSubTitle = CStringUtils::GetItemAtPos(ms_strEnabledList, ptStabDetect->AutoEnable);
		strSubTitle += strAutoEnTitle + strDegreesChangeSubTitle;
	}

	// create the sub menu item before creating the branch
	CConfigBranch *pkStabDetectParent = new CConfigBranch(ms_strAMS2750_STABILITY_DETECT_KEY, strTitle, strSubTitle,
			ctSubMenuButton, false, true, 0, false, pkParent);
	pkParent->AddChild(pkStabDetectParent);

	// Timer enable
	CShortBitFieldData *pkTimerEnData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptStabDetect), 1, 0,
			ms_strEnabledList, bfeBool, 0, 0, true);

	CConfigItem *pkTimerEn = new CConfigItem(ms_strAMS2750_STABILITY_DETECT_TIMER_EN_KEY, strTimerEnTitle,
			pkTimerEnData->GetDataAsString(), ctItemButton, pkTimerEnData, false, true, 0, false, pkStabDetectParent);
	pkStabDetectParent->AddChild(pkTimerEn);

	// Time
	CUShortData *pkTimeData = new CUShortData(&ptStabDetect->Time, 1, 120, 0, 0, true, dtUnsignedShort, strMinutes);

	strTitle = tr("Time");

	CConfigItem *pkTime = new CConfigItem(ms_strAMS2750_STABILITY_DETECT_TIME_KEY, strTitle,
			pkTimeData->GetDataAsString(true), ctItemButton, pkTimeData, false, (ptStabDetect->TimerEnable == TRUE), 0,
			false, pkStabDetectParent);
	pkStabDetectParent->AddChild(pkTime);

	// Auto enable
	CShortBitFieldData *pkAutoEnData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptStabDetect), 1, 1,
			ms_strEnabledList, bfeBool, 0, 0, true);
	CConfigItem *pkAutoEn = new CConfigItem(ms_strAMS2750_STABILITY_DETECT_AUTO_EN_KEY, strAutoEnTitle,
			pkAutoEnData->GetDataAsString(), ctItemButton, pkAutoEnData, false, true, 0, false, pkStabDetectParent);
	pkStabDetectParent->AddChild(pkAutoEn);

	// degrees change - relative temperature
	CFloatData *pkDegreesChangeData = new CFloatData(&ptStabDetect->DegreeChange, 0, 2, 0, 0, true, dtTempRelative,
	pSYSTEM_INFO->GetDisplayTempUnits(), strTempUnits);

	strTitle = tr("Degree Change");

	CConfigItem *pkDegreesChange = new CConfigItem(ms_strAMS2750_STABILITY_DETECT_DEGREES_CHANGE_KEY, strTitle,
			pkDegreesChangeData->GetDataAsString(true), ctItemButton, pkDegreesChangeData, false,
			(ptStabDetect->AutoEnable == TRUE), 0, false, pkStabDetectParent);

	pkStabDetectParent->AddChild(pkDegreesChange);
}

//****************************************************************************
///
/// Method that creates the AMS2750 calibration config heirarchy
///
/// @return Pointer to the AMS2750 calibration config hierarchy
///
//****************************************************************************
CConfigBranch* CRecSetupCfgMgr::CreateAMS2750CalibrationConfig() {
	CConfigBranch *pkParent = NULL;

	QString  strTitle("");
	QString  strKey("");

	CGeneralSetupConfig *pkGenCfg = pSETUP->GetGeneralSetupConfig();
	T_PAMS2750CALCFG ptCalConfig = pkGenCfg->GetAMS2750CalibrationBlock(CONFIG_MODIFIABLE);

	if (ptCalConfig != NULL) {
		// this is the title displayed at the top of the data driven dialog - hard code to AMS2750 rather
		// than make it as resource as this is the standard and it's therefore unnecessary
		QString  strTitle(L"AMS2750");
		QString  strSubTitle(strTitle);
		QString  strKey("");

		// Create the top level parent 
		pkParent = new CConfigBranch(ms_strAMS2750_CAL_KEY, strTitle, strSubTitle, ctMainMenuButton, false, true, 0,
				false, NULL);

		// now create the cal configuration edit menu item
		CAMS2750CalConfigData *pkCalConfigData = new CAMS2750CalConfigData(ptCalConfig);

		strTitle = tr("Cal. Points");
		CConfigItem *pkCalConfig = new CConfigItem(ms_strAMS2750_CAL_MULTI_POINT_TABLE_KEY, strTitle,
				pkCalConfigData->GetDataAsString(), ctItemButton, pkCalConfigData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkCalConfig);

		// passed or failed last cal
		CShortBitFieldData *pkPassedLastCalData = new CShortBitFieldData(reinterpret_cast<USHORT*>(ptCalConfig), 1, 0,
				ms_strEnabledList, bfeBool, 0, 0, false);

		strTitle = tr("Last Cal. Passed");

		CConfigItem *pkPassedLastCal = new CConfigItem(ms_strAMS2750_CAL_PASSED_KEY, strTitle,
				pkPassedLastCalData->GetDataAsString(), ctItemButton, pkPassedLastCalData, false, true, 0, true,
				pkParent);
		pkParent->AddChild(pkPassedLastCal);

		// Test Date
		CULongData *pkTestDateData = new CULongData(&ptCalConfig->TestDate, 1577836800, ULONG_MAX, 0, 0, false,
				dtDateTime);
		strTitle = tr("Last Calibration");

		CConfigItem *pkTestDate = new CConfigItem(ms_strAMS2750_CAL_TEST_DATE_KEY, strTitle,
				pkTestDateData->GetDataAsString(), ctItemButton, pkTestDateData, false, true, 0, true, pkParent);

		pkParent->AddChild(pkTestDate);

		// Next calibration date
		CULongData *pkNextCalDateData = new CULongData(&ptCalConfig->NextCalDate, 1577836800, ULONG_MAX, 0, 0, false,
				dtDateTime);
		strTitle = tr("Next Calibration");

		CConfigItem *pkNextCalDate = new CConfigItem(ms_strAMS2750_CAL_NEXT_CAL_DATE_KEY, strTitle,
				pkNextCalDateData->GetDataAsString(), ctItemButton, pkNextCalDateData, false, true, 0, true, pkParent);

		pkParent->AddChild(pkNextCalDate);

		// calibrator type
		QString   CfgData *pkCalibratorTypeData = new QString   CfgData(ptCalConfig->CalibratorType,
		AMS2750CALCFG_CALIBRATORTYPE_LEN, dtString, 0, 0, false);
		strTitle = tr("Calibrator Type");

		CConfigItem *pkCalibratorType = new CConfigItem(ms_strAMS2750_CAL_CALIBRATOR_TYPE_KEY, strTitle,
				pkCalibratorTypeData->GetDataAsString(), ctItemButton, pkCalibratorTypeData, false, true, 0, false,
				pkParent);
		pkParent->AddChild(pkCalibratorType);

		// calibrator serial number
		QString   CfgData *pkCalibratorSerNoData = new QString   CfgData(ptCalConfig->CalibratorSerNo,
		AMS2750CALCFG_CALIBRATORSERNO_LEN, dtString, 0, 0, false);
		strTitle = tr("Calibrator Serial No.");

		CConfigItem *pkCalibratorSerNo = new CConfigItem(ms_strAMS2750_CAL_CALIBRATOR_SERIAL_NO_KEY, strTitle,
				pkCalibratorSerNoData->GetDataAsString(), ctItemButton, pkCalibratorSerNoData, false, true, 0, false,
				pkParent);
		pkParent->AddChild(pkCalibratorSerNo);

		// traceable to
		QString   CfgData *pkTraceableToData = new QString   CfgData(ptCalConfig->TraceableTo, AMS2750CALCFG_qDebugABLETO_LEN,
				dtString, 0, 0, false);
		strTitle = tr("Traceable To");

		CConfigItem *pkTraceableTo = new CConfigItem(ms_strAMS2750_CAL_qDebugABLE_TO_KEY, strTitle,
				pkTraceableToData->GetDataAsString(), ctItemButton, pkTraceableToData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkTraceableTo);

		// technician id
		QString   CfgData *pkTechnicianIdData = new QString   CfgData(ptCalConfig->TechnicianId,
		AMS2750CALCFG_TECHNICIANID_LEN, dtString, 0, 0, false);
		strTitle = tr("Technician Id");

		CConfigItem *pkTechnicianId = new CConfigItem(ms_strAMS2750_CAL_TECHNICIAN_ID_KEY, strTitle,
				pkTechnicianIdData->GetDataAsString(), ctItemButton, pkTechnicianIdData, false, true, 0, false,
				pkParent);
		pkParent->AddChild(pkTechnicianId);

		// performed by
		QString   CfgData *pkPerformedByData = new QString   CfgData(ptCalConfig->CalPerformedBy,
		AMS2750CALCFG_CALPERFORMEDBY_LEN, dtString, 0, 0, false);
		strTitle = tr("Cal. Performed By");

		CConfigItem *pkPerformedBy = new CConfigItem(ms_strAMS2750_CAL_PERFORMED_BY_KEY, strTitle,
				pkPerformedByData->GetDataAsString(), ctItemButton, pkPerformedByData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkPerformedBy);

		// performed for
		QString   CfgData *pkPerformedForData = new QString   CfgData(ptCalConfig->CalPerformedFor,
		AMS2750CALCFG_CALPERFORMEDFOR_LEN, dtString, 0, 0, false);
		strTitle = tr("Cal. Performed For");

		CConfigItem *pkPerformedFor = new CConfigItem(ms_strAMS2750_CAL_PERFORMED_FOR_KEY, strTitle,
				pkPerformedForData->GetDataAsString(), ctItemButton, pkPerformedForData, false, true, 0, false,
				pkParent);
		pkParent->AddChild(pkPerformedFor);

		// Quality organisation
		QString   CfgData *pkQualityOrgData = new QString   CfgData(ptCalConfig->QualityOrg,
		AMS2750CALCFG_QUALITYORG_LEN, dtString, 0, 0, false);
		strTitle = tr("Quality Organisation");

		CConfigItem *pkQualityOrg = new CConfigItem(ms_strAMS2750_CAL_QUALITY_ORG_KEY, strTitle,
				pkQualityOrgData->GetDataAsString(), ctItemButton, pkQualityOrgData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkQualityOrg);
	}
	return pkParent;
}
//****************************************************************************
// CConfigInterface *RefreshConfigTree( CConfigItem *pkModifiedItem
//										CLayoutItem* pkCurrLayoutItem /* = NULL */ )
///
/// Method that refreshes the data for a particular branch of a configuration menu, usually 
/// following a change that requires the tree structure to be regenerated because it is different
///
/// @param[in] 		CConfigItem *pkModifiedItem - A pointer to the item that has been modified
/// @param[in]		CLayoutItem* pkCurrLayoutItem - Not used in this class
///
//****************************************************************************
CConfigInterface* CRecSetupCfgMgr::RefreshConfigTree(CConfigItem *pkModifiedItem,
		CLayoutItem *pkCurrLayoutItem /* = NULL */) {
	CConfigInterface *pkNewCfgItem = NULL;

	// detemine the type of config item that has been modified
	QString  strKey = pkModifiedItem->GetKey();
	int iDelimPos = strKey.indexOf(CConfigInterface::ms_wcDELIMITER, 0);
	// check the delimiter was found and it is not in position 0
	if (iDelimPos > 0) {
		QString  strInitialKey = strKey.left(iDelimPos);
		if (strInitialKey.compare(ms_strPEN_KEY) == 0) {
			// remove up to the first delimiter thus leaving us with the string
			// PENXXX|XXXXX|XXXX
			strKey.Delete(0, iDelimPos + 1);
			iDelimPos = strKey.indexOf(CConfigInterface::ms_wcDELIMITER, 0);
			if (iDelimPos) {
				QString  strPenNoKey = strKey.left(iDelimPos);
				strPenNoKey.Delete(0, ms_strPEN_KEY.size());
				const USHORT usPEN_NO = static_cast< USHORT >(_wtol(strPenNoKey));
				// this is a pen item
				pkNewCfgItem = RefreshPenConfigTree(pkModifiedItem, usPEN_NO);
			}
		} else if (strInitialKey.compare(ms_strANALOGUE_IN_KEY) == 0) {
			// remove up to the first delimiter thus leaving us with the string
			// ANALOGUE_INXXX|XXXXX|XXXX
			strKey.Delete(0, iDelimPos + 1);
			iDelimPos = strKey.indexOf(CConfigInterface::ms_wcDELIMITER, 0);
			if (iDelimPos) {
				QString  strAINNoKey = strKey.left(iDelimPos);
				strAINNoKey.Delete(0, ms_strANALOGUE_IN_KEY.size());
				const USHORT usAIN_NO = static_cast< USHORT >(_wtol(strAINNoKey));
				// this is an analogue item
				pkNewCfgItem = RefreshAnalogueInputConfigTree(pkModifiedItem, usAIN_NO);
			}
		} else if (strInitialKey.compare(ms_strDIGIO_KEY) == 0) {
			// remove up to the first delimiter thus leaving us with the string
			// DIGIO_XXX|XXXXX|XXXX
			strKey.Delete(0, iDelimPos + 1);
			iDelimPos = strKey.indexOf(CConfigInterface::ms_wcDELIMITER, 0);
			if (iDelimPos) {
				QString  strDigIONoKey = strKey.left(iDelimPos);
				strDigIONoKey.Delete(0, ms_strDIGIO_KEY.size());
				const USHORT usDIG_IO_NO = static_cast< USHORT >(_wtol(strDigIONoKey));
				// this is a digital item
				pkNewCfgItem = RefreshDigitalIOConfigTree(pkModifiedItem, usDIG_IO_NO);
			}
		} else if (strInitialKey.compare(ms_strPULSE_IN_KEY) == 0) {
			// remove up to the first delimiter thus leaving us with the string
			// PULSE_IN_XXX|XXXXX|XXXX
			strKey.Delete(0, iDelimPos + 1);
			iDelimPos = strKey.indexOf(CConfigInterface::ms_wcDELIMITER, 0);
			if (iDelimPos) {
				QString  strPulseInNoKey = strKey.left(iDelimPos);
				strPulseInNoKey.Delete(0, ms_strPULSE_IN_KEY.size());
				const USHORT usPULSE_IN_NO = static_cast< USHORT >(_wtol(strPulseInNoKey));
				// this is a digital item
				pkNewCfgItem = RefreshPulseInConfigTree(pkModifiedItem, usPULSE_IN_NO);
			}
		} else if (strInitialKey.compare(ms_strANALOGUE_OUTPUT_KEY) == 0) {
			// remove up to the first delimiter thus leaving us with the string
			// AOUTXXX|XXXXX|XXXX
			strKey.Delete(0, iDelimPos + 1);
			iDelimPos = strKey.indexOf(CConfigInterface::ms_wcDELIMITER, 0);
			if (iDelimPos) {
				QString  strAOUTNoKey = strKey.left(iDelimPos);
				strAOUTNoKey.Delete(0, ms_strANALOGUE_OUTPUT_KEY.size());
				const USHORT usAOUT_NO = static_cast< USHORT >(_wtol(strAOUTNoKey));
				// this is an analogue item
				pkNewCfgItem = RefreshAnalogueOutputConfigTree(pkModifiedItem, usAOUT_NO);
			}
		} else if (strInitialKey.compare(ms_strEVENTS_KEY) == 0) {
			// remove up to the first delimiter thus leaving us with the string
			// EVENTXXX|XXXXX|XXXX
			strKey.Delete(0, iDelimPos + 1);
			iDelimPos = strKey.indexOf(CConfigInterface::ms_wcDELIMITER, 0);
			if (iDelimPos) {
				QString  strEventNoKey = strKey.left(iDelimPos);
				strEventNoKey.Delete(0, ms_strEVENTS_KEY.size());
				const USHORT usEVENT_NO = static_cast< USHORT >(_wtol(strEventNoKey));
				// this is an analogue item
				pkNewCfgItem = RefreshEventsConfigTree(pkModifiedItem, usEVENT_NO);
			}
		} else if (strInitialKey.compare(ms_strCOUNTERS_KEY) == 0) {
			// remove up to the first delimiter thus leaving us with the string
			// COUNTERXXX|XXXXX|XXXX
			strKey.Delete(0, iDelimPos + 1);
			iDelimPos = strKey.indexOf(CConfigInterface::ms_wcDELIMITER, 0);
			if (iDelimPos) {
				QString  strCounterNoKey = strKey.left(iDelimPos);
				strCounterNoKey.Delete(0, ms_strCOUNTERS_KEY.size());
				const USHORT usCOUNTER_NO = static_cast< USHORT >(_wtol(strCounterNoKey));
				// this is an analogue item
				pkNewCfgItem = RefreshCountersConfigTree(pkModifiedItem, usCOUNTER_NO);
			}
		} else if (strInitialKey.compare(ms_strMODBUS_MASTER_KEY) == 0) {
			// The MODBUS master item requires special treatement - it has quite a large
			// tree and takes a while to rebuild - unfortunately branches stemming from
			// the top level are not all of the same type. This means we need to check the
			// key to see if it is a sub-branch that we can update by itself or if it is something
			// that requires us to rebuild the entire tree (e.g. enable modbus master).

			// remove upto the first delimiter this leaving us with the following strings:
			// EN| or SLVX|XXXX (POLL doesn't cause the whole tree to be rebuilt at the moment
			strKey.Delete(0, iDelimPos + 1);
			// now check for the slave key - if found then it will be a slave device that has 
			// been changed which means we onyl have to update one of the sub branches
			iDelimPos = strKey.indexOf(CConfigInterface::ms_wcDELIMITER, 0);

			if (strKey.indexOf(ms_strMODBUS_MASTER_SLAVE_KEY.left(3)) == -1) {
				// now slave key found therefore the whole tree will need updating - get the original
				// key as this will be required later
				strKey = pkModifiedItem->GetKey();
				CConfigInterface *pkItemToDelete = pkModifiedItem;
				while (pkItemToDelete->GetParent() != NULL) {
					pkItemToDelete = pkItemToDelete->GetParent();
				}
				delete pkItemToDelete;

				CConfigBranch *pkNewCfgBranch = NULL;

				// none found therefore update the whole tree
				pkNewCfgBranch = CreateModbusMasterConfig();

				// check the branch was updated okay
				if (pkNewCfgBranch != NULL) {
					pkNewCfgItem = static_cast<CConfigItem*>(indexOfChildByKey(strKey, pkNewCfgBranch, 1));
				} else {
#ifdef _DEBUG
					DebugBreak();	
#endif
				}
			} else {
				// we found a slave key - determine the branch and replace it
				iDelimPos = strKey.indexOf(CConfigInterface::ms_wcDELIMITER, 0);
				if (iDelimPos) {
					QString  strSlaveNoKey = strKey.left(iDelimPos);
					strSlaveNoKey.Delete(0, 3);
					const USHORT usSLAVE_NO = static_cast< USHORT >(_wtol(strSlaveNoKey));
					pkNewCfgItem = RefreshModbusMasterConfigTree(pkModifiedItem, usSLAVE_NO);
				}
			}
		} else if (strInitialKey.compare(ms_strREPORT_IND_KEY) == 0) {
			// remove up to the first delimiter thus leaving us with the string
			// REPXXX|XXXXX|XXXX
			strKey.Delete(0, iDelimPos + 1);
			iDelimPos = strKey.indexOf(CConfigInterface::ms_wcDELIMITER, 0);
			if (iDelimPos) {
				QString  strReportNoKey = strKey.left(iDelimPos);
				strReportNoKey.Delete(0, ms_strREPORT_IND_KEY.size());
				const USHORT usREPORT_NO = static_cast< USHORT >(_wtol(strReportNoKey));
				// this is an analogue item
				pkNewCfgItem = RefreshReportConfigTree(pkModifiedItem, usREPORT_NO);
			}
		}
		/*
		 else if( add more here )
		 {


		 }
		 */
		else {
			// must be an type where the entire tree is updated which simplifies the processing somewhat
			// delete the existing list
			CConfigInterface *pkItemToDelete = pkModifiedItem;
			bool bIsModifiedEncrypt = FALSE;
			if (pkModifiedItem->GetTitle() == L"TV Encrypt") {
				bIsModifiedEncrypt = TRUE;
			}
			while (pkItemToDelete->GetParent() != NULL) {
				pkItemToDelete = pkItemToDelete->GetParent();
			}
			delete pkItemToDelete;

			CConfigBranch *pkNewCfgBranch = NULL;

			// determine the type and create a configuration tree
			if (strInitialKey.compare(ms_strSCREEN_SAVER_KEY) == 0) {
				pkNewCfgBranch = CreateScreenSaverConfig();
			} else if (strInitialKey.compare(ms_strSCREEN_CHART_KEY) == 0) {
				pkNewCfgBranch = CreateChartConfig();
			} else if (strInitialKey.compare(ms_strEVENTS_KEY) == 0) {
				pkNewCfgBranch = CreateEventsConfig();
			} else if (strInitialKey.compare(ms_strBATCH_KEY) == 0) {
				pkNewCfgBranch = CreateBatchConfig();
			} else if (strInitialKey.compare(ms_strPRINTER_KEY) == 0) {
				pkNewCfgBranch = CreatePrinterConfig();
			} else if (strInitialKey.compare(ms_strERROR_CONTROL_KEY) == 0) {
				pkNewCfgBranch = CreateErrorControlConfig();
			} else if (strInitialKey.compare(ms_strLOCAL_KEY) == 0) {
				pkNewCfgBranch = CreateLocalisationConfig();
			} else if (strInitialKey.compare(ms_strCREDITS_KEY) == 0) {
				pkNewCfgBranch = CreateCreditsConfig();
			} else if (strInitialKey.compare(ms_strDEMO_BOARDS_KEY) == 0) {
				pkNewCfgBranch = CreateDemoConfig();
			} else if (strInitialKey.compare(ms_strPRODUCTION_KEY) == 0) {
				pkNewCfgBranch = CreateProductionConfig();
			} else if (strInitialKey.compare(ms_strTCPIP_KEY) == 0) {
				pkNewCfgBranch = CreateTCPIPConfig();
			} else if (strInitialKey.compare(ms_strSecurity_KEY) == 0) {
				pkNewCfgBranch = CreateSecurityConfig();
			} else if (strInitialKey.compare(ms_strMODBUS_COMMS_KEY) == 0) {
				pkNewCfgBranch = CreateModbusCommsConfig();
			} else if (strInitialKey.compare(ms_strMODBUS_SLAVE_KEY) == 0) {
				pkNewCfgBranch = CreateModbusSlaveConfig();
			}
			/*
			 else if( strInitialKey.compare( ms_strMODBUS_MASTER_KEY ) == 0 )
			 {
			 pkNewCfgBranch = CreateModbusMasterConfig( );
			 }*/
			else if (strInitialKey.compare(ms_strSNTP_KEY) == 0) {
				pkNewCfgBranch = CreateSNTPConfig();
			} else if (strInitialKey.compare(ms_strDEVICE_DETAILS) == 0) {
				pkNewCfgBranch = CreateGeneralDeviceConfig();
			} else if (strInitialKey.compare(ms_strGROUP_KEY) == 0) {
				pkNewCfgBranch = CreateGroupsConfig();
			} else if (strInitialKey.compare(ms_strWEB_KEY) == 0) {
				pkNewCfgBranch = CreateWebConfig();
			} else if (strInitialKey.compare(ms_strEMAIL_KEY) == 0) {
				pkNewCfgBranch = CreateEmailConfig();
			} else if (strInitialKey.compare(ms_strNETWORK_ADMIN_KEY) == 0) {
				pkNewCfgBranch = CreateNetworkAdminConfig();
			} else if (strInitialKey.compare(ms_strRECORDING_SCHED_KEY) == 0) {
				pkNewCfgBranch = CreateRecordingSchedConfig();
			} else if (strInitialKey.compare(ms_strRECORDING_ALM_KEY) == 0) {
				pkNewCfgBranch = CreateRecordingAlarmsConfig();
			} else if (strInitialKey.compare(ms_strRECORDING_PRETRIGGER_KEY) == 0) {
				pkNewCfgBranch = CreateRecordingPreTriggerConfig();
			} else if (strInitialKey.compare(ms_strFTP_KEY) == 0) {
				pkNewCfgBranch = CreateFTPConfig();
			} else if (strInitialKey.compare(ms_strP2P_KEY) == 0) {
				pkNewCfgBranch = CreateP2PConfig();
			} else if (strInitialKey.compare(ms_strLINEARISATION_KEY) == 0) {
				pkNewCfgBranch = CreateLinearisationConfig();
			} else if (strInitialKey.compare(ms_strTIMESYNC_KEY) == 0) {
				//TimeSync...
				pkNewCfgBranch = CreateTimeSyncConfig();
			} else if (strInitialKey.compare(ms_strSCREEN_TAB_DISP_KEY) == 0) {
				// Tabular screen
				pkNewCfgBranch = CreateTabularDisplayConfig();
			} else if ((strInitialKey.compare(ms_strAMS2750_GEN_PROCESS_KEY) == 0)
					|| (strInitialKey.compare(ms_strAMS2750_GEN_TUS_KEY) == 0)) {
				// General AMS2750 config heirarchy
				pkNewCfgBranch = CreateAMS2750GeneralConfig();
			} else if (strInitialKey.compare(ms_strAMS2750_CAL_KEY) == 0) {
				// General AMS2750 calibration config heirarchy
				pkNewCfgBranch = CreateAMS2750CalibrationConfig();
			} else if (strInitialKey.compare(ms_strLOADSAVECONF_KEY) == 0) {
				// Load Save config
				pkNewCfgBranch = CreateLoadSaveConfig();
			} else if (strInitialKey.compare(ms_strRECORDING_EXPORT_KEY) == 0) {
				pkNewCfgBranch = CreateRecordingExportConfig(bIsModifiedEncrypt);
			} else if (strInitialKey.compare(ms_strOPCUA_KEY) == 0) {
				pkNewCfgBranch = CreateOPCUAConfig();
			}
			/*
			 else if( add more here )
			 {	
			 }
			 */
			if (pkNewCfgBranch != NULL) {
				pkNewCfgItem = static_cast<CConfigItem*>(indexOfChildByKey(strKey, pkNewCfgBranch, 1));
			} else {
#ifdef _DEBUG
				DebugBreak();	
#endif
				/*
				 // just add a dummy parent and child to stop if falling over
				 CConfigBranch *pkDummyParent = new CConfigBranch(	ms_strPEN_KEY,
				 L"Error Condition",
				 L"Refresh Tree Error",
				 ctMainMenuButton,													
				 false,
				 true,
				 0,
				 false,
				 NULL );
				 CConfigItem *pkDummyItem = new CConfigItem( ms_strPEN_KEY,
				 L"Error Condition",
				 L"Refresh Tree Error",
				 ctMainMenuButton,
				 NULL,
				 false,
				 false,
				 0,
				 false,
				 pkDummyParent );

				 
				 pkNewCfgItem = pkDummyItem;
				 */
				if (pkNewCfgItem == NULL) {
					// set to the parent instead
					pkNewCfgItem = pkNewCfgBranch;
				}
			}
		}
	} else {
		// shouldn't really happen but in this situation do nothing and return the passed in pointer
		pkNewCfgItem = pkModifiedItem;
	}

	return pkNewCfgItem;
}

//****************************************************************************
//	void CommitChanges()
///
/// Method that commits recorder setup changes to the CMM
///
//****************************************************************************
void CRecSetupCfgMgr::CommitChanges() {

	m_bModified = false;
#if ! defined ( TTR6SETUP )
	qDebug("Attempt to Start Commit\n");
	EnterCriticalSection(&CTxSchedule::m_ExportCS);
	qDebug("Start Commit in CS\n");
#endif

	// add the reasons for reboot to the reboot handler method
	std::vector<QString>::iterator kCurr = m_kReasonsForReboot.begin();
	std::vector<QString>::iterator kEnd = m_kReasonsForReboot.end();

	while (kCurr != kEnd) {
		pSETUP->RequestUnitResetAfterConfigChange((*kCurr));
		++kCurr;
	}

	T_MOD_CFG_CHG_MSGDATA msg;
	msg.TypeOfConfigChange = MOD_CFG_CHG_SETUP;
	msg.configChangeSystemAction = MOD_SYS_CFG_CHG_NORMAL_OPERATION;
	msg.ConfigChangeAction = MOD_CFG_CHG_ACTION_UPDATE;

	QString  strSetupChanged("");
	strSetupChanged = tr("Setup Changed");

#if ! defined ( TTR6SETUP )

	// stop any batches that may be running - this action will have already been 
	// authorised earlier
	CBatchManager *pkBatchManager = CBatchManager::Instance();
	pkBatchManager->StopAllBatches();

	// also stop any TUS's - this action wil have been authorised earlier
	CAMS2750TUSMgr *pkTUSMgr = CAMS2750TUSMgr::Instance();
	pkTUSMgr->StopTUS(strSetupChanged);

	// reset the pre-trigger state also
	CPenManager *pPenManager = CPenManager::GetHandle();
	if ((pPenManager->GetPreTriggerStatus() == PRE_TRIGGER_READY_FOR_PROCESSING)
			|| (pPenManager->GetPreTriggerStatus() == PRE_TRIGGER_READY_FOR_EXPORT)) {
		pPenManager->SetPreTriggerStatus(PRE_TRIGGER_READY_FOR_RESTART);
	}

	// Perform Any LCF cleanup that is required
	CTxSchedule *pTxScheduler = CTxSchedule::GetHandle();
	pTxScheduler->CheckAndCleanLCF();

#endif

	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	//Ignore the Main thread for watchdog as we have to wait infinitely
	if (pThreadInfo != NULL) {
		pThreadInfo->UpdateThreadInfo(AM_OPPANEL, false);
	}

	// do not wait if a restart is required as the restart code attempts to show a modal dialog from a 
	// different thread which appears to hang the system
	if (!pSETUP->IsResetRequired()) {

		m_ModuleMessageManagerClient.MMMClientPostIntMsgAndWait( INFINITE, m_dwPOST_MESSAGE_WAIT_TIMEOUT,
				MODULE_CONTROL_SEQUENCER, // Destination
				MODULE_SETUP_CFG_MGR, // Sender
				MOD_CONFIG_CHANGE, sizeof(T_MOD_CFG_CHG_MSGDATA), (BYTE*) &msg);

	} else {
		m_ModuleMessageManagerClient.MMMClientPostIntMsg( INFINITE, MODULE_CONTROL_SEQUENCER, // Destination
				MODULE_SETUP_CFG_MGR, // Sender
				MOD_CONFIG_CHANGE, sizeof(T_MOD_CFG_CHG_MSGDATA), (BYTE*) &msg);
	}

	//Consider the Main thread as the wait is over
	if (pThreadInfo != NULL) {
		pThreadInfo->UpdateThreadInfo(AM_OPPANEL, true);
	}

	// log setup change event
	LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_INFORMATION, strSetupChanged);	// Log setup changed message

#if !defined ( TTR6SETUP )	
	qDebug("Complete Commit CS\n");
	LeaveCriticalSection(&CTxSchedule::m_ExportCS);
#endif
}

#define FILETIME_TO_MINUTES ((__int64)600000000L)

//****************************************************************************
//	void UpdateTimeInformation()
///
/// Method that applies any time changes to the recorder
///
//****************************************************************************
void CRecSetupCfgMgr::UpdateTimeInformation() {
	// only do this on the recorder
	const T_DEV_TYPE eDEV_TYPE = pDEVICE_INFO->GetDeviceType();
	if (eDEV_TYPE == DEV_ARISTOS_MINITREND || eDEV_TYPE == DEV_ARISTOS_MULTIPLUS || eDEV_TYPE == DEV_SCR_MINITREND
			|| eDEV_TYPE == DEV_ARISTOS_EZTREND) //ARISTOS QXe Device Type updates
					{
		T_PGENNONVOL ptGenNonVol = pSYSTEM_INFO->GetFactoryConfig();

		if (ptGenNonVol != NULL) {
			// check the daylight saving field
			TIME_ZONE_INFORMATION tTimeZone;
			DWORD dwTimeType = GetTimeZoneInformation(&tTimeZone);

			CRegistryKey kRegKey;
			bool bSuccess = true;

			// If the registry key exists
			if (kRegKey.OpenKey(L"SOFTWARE\\Microsoft\\Clock")) {
				DWORD dwType = REG_DWORD;
				DWORD dwSize = sizeof(DWORD);
				DWORD dwAutoDST = 0;
				bool bForceUpdate = false;

				if (!kRegKey.ReadValue(L"AutoDST", &dwType, reinterpret_cast<BYTE*>(&dwAutoDST), &dwSize)) {
					bForceUpdate = true;
				}

				// check the daylight saving flag - see if it matches our V6 config value
				if (bForceUpdate || (dwAutoDST != ptGenNonVol->Localisation.DayLightSaving)) {
					// the daylight saving mode has changed - we need to check the current time mode
					// and set the time accordingly
					if ((dwTimeType == TIME_ZONE_ID_DAYLIGHT) && !ptGenNonVol->Localisation.DayLightSaving) {
						// we were in daylight saving and daylight saving has just been turned off
						// therefore we need to set the time zone back 
					}

					dwAutoDST = ptGenNonVol->Localisation.DayLightSaving;
					kRegKey.WriteValue(L"AutoDST", dwAutoDST);

					ReInitialiseDSTEvent();

				}
				kRegKey.Close();
			}

			// now do the time zone	
			TIME_ZONE_INFORMATION tTimeInfo;
			DWORD dwTZID = GetTimeZoneInformation(&tTimeInfo);

			// Does the kernel think we're currently in DST?
			const bool bIN_DST = (TIME_ZONE_ID_DAYLIGHT == dwTZID);

			// does this time zone match our configured time zone
			const USHORT usTIME_ZONE = ptGenNonVol->Localisation.TimeZone;
			QString  strKey("");

			// open the correct registry
			if (strKey = ms_kTimeZoneRegKeyArr.value(usTIME_ZONE)) {
				QString  strStd("");
				QString  strDlt("");

				//PSR - fix for the DST_Hang issue begin
				if (kRegKey.OpenKey(strKey.GetBuffer(strKey.size()))) {
					// we must now copy the TZI structure into our time zone info structure and set it
					DWORD dwSize = sizeof(TIME_ZONE_INFORMATION);
					DWORD dwStdSize = 0;
					DWORD dwDltSize = 0;
					DWORD dwType = 0;

					// now copy the names for standard time and daylight time
					dwStdSize = sizeof(tTimeInfo.StandardName);
					kRegKey.ReadValue(L"Std", strStd, &dwStdSize, REG_SZ);

					dwDltSize = sizeof(tTimeInfo.DaylightName);
					kRegKey.ReadValue(L"Dlt", strDlt, &dwDltSize, REG_SZ);

					// compare the time zone information to the existing and change if different
					if ((strStd.compare(tTimeInfo.StandardName) != 0)
							|| (strDlt.compare(tTimeInfo.DaylightName) != 0)) {
						// store the old time zone information
						TIME_ZONE_INFORMATION tOldTZInfo = tTimeInfo;

						memset(tTimeInfo.StandardName, 0, dwStdSize);
						memcpy(tTimeInfo.StandardName, strStd, strStd.size() * sizeof(WCHAR));

						memset(tTimeInfo.DaylightName, 0, dwDltSize);
						memcpy(tTimeInfo.DaylightName, strDlt, strDlt.size() * sizeof(WCHAR));

						// now copy the TZI structure
						BYTE *pbyData = new BYTE[dwSize];

						kRegKey.ReadValue(L"TZI", &dwType, pbyData, &dwSize);

						// we must now copy the data from the registry information into the time zone information
						// structure - I think the structure is in the fllowing format:
						// Bias (4 bytes)
						// Standard Bias (4 bytes)
						// Daylight Bias (4 Bytes)
						// Standard Date (16 Bytes)
						// Daylight Date (16 Bytes)

						memcpy(&tTimeInfo.Bias, pbyData, sizeof(long));
						memcpy(&tTimeInfo.StandardBias, pbyData + 4, sizeof(long));
						memcpy(&tTimeInfo.DaylightBias, pbyData + 8, sizeof(long));
						memcpy(&tTimeInfo.StandardDate, pbyData + 12, sizeof(QDateTime));
						memcpy(&tTimeInfo.DaylightDate, pbyData + 28, sizeof(QDateTime));

						delete[] pbyData;

						kRegKey.Close();

						CRegistryKey kTZRegKey;
						BOOL bRegOpen = false;

						if (!(bRegOpen = kTZRegKey.OpenKey(L"Time"))) {
							// the registry key does not exist yet so create it
							if (!(bRegOpen = kTZRegKey.CreateKey(L"Time"))) {
								// we have big problems if this has happened
								LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR,
										"Could not create time zone registry entry");
							}
						}

						if (bRegOpen) {
							kTZRegKey.WriteValue(L"TimeZoneInformation", dwType, reinterpret_cast<BYTE*>(&tTimeInfo),
									sizeof(tTimeInfo));

							kTZRegKey.Close();
						}

						// calculate difference between Bias of previous & new timezones
						LONG lOldBias = tOldTZInfo.Bias + (bIN_DST ? tOldTZInfo.DaylightBias : tOldTZInfo.StandardBias);
						LONG lNewBias = tTimeInfo.Bias + (bIN_DST ? tTimeInfo.DaylightBias : tTimeInfo.StandardBias);

						// check if this is a new registry - if it is then we don't want to actually change the time
						// We should only need to update the time zone - this is rare and should only occur when the NK.bin
						// is modified to include a new registry
						if (GlbDevCaps.IsNewRegistry()) {
							QDateTime stOld;
							GetV6LocalTime(&stOld);
							// The time and time zone are updated anyways directly into registry in below code
							SetTimeZoneInformation(&tTimeInfo);
							// now update the clock
							SetV6LocalTime(&stOld);
							// a new registry so keep the time the same even though the time zone has changed
							LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_INFO,
									L"Time zone modified due to new registry");
						} else {
							// The time and time zone are updated anyways directly into registry in below code
							SetTimeZoneInformation(&tTimeInfo);
							sleep(1000);
							QDateTime stNew;
							GetV6LocalTime(&stNew);
							// now update the clock
							SetV6LocalTime(&stNew);

							LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_INFO,
									L"Time zone modified - local time also modifed");
						}
					} else {
						kRegKey.Close();
					}
				} else {
					LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_INFO,
							L"Time zone modified - Unable to open the registry key");
				}						//PSR - fix for the DST _Hang issue end
			}
		}
	}
}
//****************************************************************************
//	void DiscardChanges()
///
/// Method that discards recorder setup changes from the CMM
///
//****************************************************************************
void CRecSetupCfgMgr::DiscardChanges() {
	//Get Handle of the class CThreadInfo.
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	if (pThreadInfo != NULL) {
		//Set the function pointer for the global function
		//GlbUpdateThreadInfo
		SetThreadInfo(GlbUpdateThreadInfo);
	}

	// clear the reboot messages list
	m_kReasonsForReboot.clear();

	m_bModified = false;
	T_CONFIG_RETURN_VALUE eErrVal = pSETUP->DiscardConfigurationChanges();
	qDebug("%d", eErrVal);
	// restore the original committed screen brightness in case we have modfied ours
	T_PRECPROFILE ptCommittedProfile = pSETUP->GetGeneralSetupConfig()->GetProfileBlock(CONFIG_COMMITTED);
	pDALGLB->SetScreenBrightness(ptCommittedProfile->ScreenSaver.NormalBright);

	// Update General Non Volatile block in configuration
	CGeneralSetupConfig *pkGenCfg = pSETUP->GetGeneralSetupConfig();
	T_PGENNONVOL pGenNV = pkGenCfg->GetGenNonVolBlock(CONFIG_COMMITTED);
	if (pGenNV != NULL) {
		// Gen NV block exists in config, update it with latest in memory

		pkGenCfg->UpdateGenNonVolSystemFromCMM(pGenNV);
	}

	// discard the changes to AMS2750 snesor data too
	CIOSetupConfig *pkIOCfg = pSETUP->GetIOSetupConfig();
	pkIOCfg->UpdateAMS270SensorWorkingWithCommitted();
}

//****************************************************************************
//	const bool LoadConfiguration( const QString   &rstrFILE_NAME )
///
/// Method that loads a new setup
///
//****************************************************************************
const bool CRecSetupCfgMgr::LoadConfiguration(const QString  &rstrFILE_NAME) {
	// clear the reboot message list
	m_kReasonsForReboot.clear();

	bool bReturn = false;
	T_MOD_CFG_CHG_MSGDATA msg;
	msg.TypeOfConfigChange = MOD_CFG_CHG_SETUP;
	msg.configChangeSystemAction = MOD_SYS_CFG_CHG_NORMAL_OPERATION;
	msg.ConfigChangeAction = MOD_CFG_CHG_ACTION_LOAD_NEW;
	CStringUtils::SafeWcsCpy(msg.fileNameAndPath, rstrFILE_NAME, MAX_PATH);

	QString  strLoadConfig("");
	strLoadConfig = tr("Configuration Loaded");

#if ! defined ( TTR6SETUP )
	// stop any batches that may be running - this action will have already been 
	// authorised earlier
	CBatchManager *pkBatchManager = CBatchManager::Instance();
	pkBatchManager->StopAllBatches();

	// also stop any TUS's - this action wil have been authorised earlier
	CAMS2750TUSMgr *pkTUSMgr = CAMS2750TUSMgr::Instance();
	pkTUSMgr->StopTUS(strLoadConfig);
#endif

	if (MMMCLIENT_MESSAGE_COMPLETED
			== m_ModuleMessageManagerClient.MMMClientPostIntMsgAndWait( INFINITE, m_dwPOST_MESSAGE_WAIT_TIMEOUT,
					MODULE_CONTROL_SEQUENCER, MODULE_SETUP_CFG_MGR, MOD_CONFIG_CHANGE, sizeof(T_MOD_CFG_CHG_MSGDATA),
					(BYTE*) &msg)) {
		bReturn = true;
	}

	// log load config event
	LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_INFORMATION, strLoadConfig);	// Log setup changed message

	return bReturn;
}
//****************************************************************************
//	T_CONFIG_RETURN_VALUE SaveConfiguration( const QString   &rstrFILE_NAME ) const
///
/// Method that saves the current setup
///
//****************************************************************************
T_CONFIG_RETURN_VALUE CRecSetupCfgMgr::SaveConfiguration(const QString  &rstrFILE_NAME) const {
	CStorage kConfigFile;

	kConfigFile.Open(rstrFILE_NAME,  | QFile::WriteOnly);
	CSingleLock lock(&m_GlbSetupMutex);
	lock.Lock();
	T_CONFIG_RETURN_VALUE eRetVal = pGlbSetup->SaveConfig(kConfigFile);
	lock.Unlock();
	kConfigFile.Close();

	return eRetVal;
}

//****************************************************************************
//	const bool EnterCalMode( )
///
/// Method that sends a message to put the recorder into calibration mode
///
//****************************************************************************
const bool CRecSetupCfgMgr::EnterCalMode() {
	bool bReturn = false;

	if (MMMCLIENT_MESSAGE_COMPLETED
			== m_ModuleMessageManagerClient.MMMClientPostIntMsgAndWait( INFINITE, m_dwPOST_MESSAGE_WAIT_TIMEOUT,
					MODULE_CONTROL_SEQUENCER, MODULE_SETUP_CFG_MGR, MOD_ENTER_CAL_MODE, 0, NULL)) {
		bReturn = true;
	}
	return bReturn;
}
//TM - compiled out as not used by TTR6SETUP
#ifndef TTR6SETUP
//****************************************************************************
//	const bool InitiatePositiveCalibration( const USHORT us)
///
/// Method that sends a message to the ATE cal informing it to carry out a positive
/// calibration on the relevant channels
///
//****************************************************************************
const bool CRecSetupCfgMgr::InitiatePositiveCalibration(const USHORT usVOLTAGE_RANGE, const USHORT usCHANNEL_MASK) {
	bool bReturn = false;

	CATECal *pkATECal = CATECal::GetHandle();

	pkATECal->InitialiseBoardRangeCalMode(usVOLTAGE_RANGE, usCHANNEL_MASK);
	sleep(5000);
	pkATECal->PerformBoardRangeCal( TRUE, usCHANNEL_MASK);

	return bReturn;
}
//****************************************************************************
//	const bool InitiateNegativeCalibration( const USHORT us)
///
/// Method that sends a message to the ATE cal informing it to carry out a negative
/// calibration on the relevant channels
///
//****************************************************************************
const bool CRecSetupCfgMgr::InitiateNegativeCalibration(const USHORT usVOLTAGE_RANGE, const USHORT usCHANNEL_MASK) {
	bool bReturn = false;

	CATECal *pkATECal = CATECal::GetHandle();

	pkATECal->PerformBoardRangeCal( FALSE, usCHANNEL_MASK);

	// indexOf out whether calibration values read are succesful
	bReturn = static_cast<bool>(pkATECal->CheckUserCalibration());

	return bReturn;
}
#endif

//****************************************************************************
//	void FinishCalibration( )
///
/// Method that sends a message to the IO scheduler informing it to carry out any processing
/// required to finish calibration
///
//****************************************************************************
const bool CRecSetupCfgMgr::FinishCalibration() {
	bool bReturn = false;

	if (MMMCLIENT_MESSAGE_COMPLETED
			== m_ModuleMessageManagerClient.MMMClientPostIntMsgAndWait(INFINITE, m_dwPOST_MESSAGE_WAIT_TIMEOUT,
					MODULE_IO_SCHEDULER, MODULE_SETUP_CFG_MGR, MOD_CALIBRATION_FINISHED, 0, NULL)) {
		bReturn = true;
	}

	return bReturn;
}

//****************************************************************************
// CConfigBranch *CreateTimeSyncConfig( )
///
/// Method that creates the time sync config heirarchy
///
/// @return Pointer to the time sync config hierarchy
/////TimeSync...
//****************************************************************************
CConfigBranch* CRecSetupCfgMgr::CreateTimeSyncConfig() {
	CConfigBranch *pkParent = NULL;
	QString  strTitle("");

	CEventSetupConfig *pkEventCfg = pSETUP->GetEventSetupConfig();
	T_PEVENTSYSTEM ptEventsSystem = pkEventCfg->GetEventBlock(CONFIG_MODIFIABLE);

	if (ptEventsSystem != NULL) {
		//Time Sync on DI
		strTitle = tr("Time Sync on DI");

		pkParent = new CConfigBranch(ms_strTIMESYNC_KEY, strTitle, strTitle, ctMainMenuButton, false, true, 0, false,
				NULL);

		// Enabled - this will be a boolean type bitfield
		CShortBitFieldData *pkEnabledData = new CShortBitFieldData(
				reinterpret_cast< USHORT*>(&ptEventsSystem->TimeSync), 1, 0, ms_strEnabledList, bfeBool, 0, 0, true);
		//Enabled
		strTitle = tr("Enabled");

		CConfigItem *pkEnabled = new CConfigItem(ms_strTIMESYNC_ENABLED_KEY, strTitle, pkEnabledData->GetDataAsString(),
				ctItemButton, pkEnabledData, false, true, 0, false, pkParent);
		pkParent->AddChild(pkEnabled);

		// Trigger - this will be a boolean type bitfield
		// 1 = ON, 0 = OFF		
		CShortBitFieldData *pkTriggerValue = new CShortBitFieldData(
				reinterpret_cast< USHORT*>(&ptEventsSystem->TimeSync), 1, 1, ms_strTriggerList, bfeBool, 0, 0, false); // false
		//Trigger
		strTitle = tr("Trigger");

		CConfigItem *pkTrigger = new CConfigItem(ms_strTIMESYNC_TRIGGER_KEY, strTitle,
				pkTriggerValue->GetDataAsString(), ctItemButton, pkTriggerValue, false,
				(ptEventsSystem->TimeSync.Enabled == TRUE),		//true,
				0, false, pkParent);
		pkParent->AddChild(pkTrigger);

		// DI Picker - this will create a digital input pick list
		CPickerData *pkDigINData = new CPickerData(&ptEventsSystem->TimeSync.DigitalPicker, dtSingleDigIn, 0, 0, false,
				1, 1);

		//QString   strTitle (L"Digital Input");
		strTitle = tr("Digital Input");

		CConfigItem *pkDigIN = new CConfigItem(ms_strTIMESYNC_DIPICKER_KEY, strTitle, pkDigINData->GetDataAsString(),
				ctItemButton, pkDigINData, false, (ptEventsSystem->TimeSync.Enabled == TRUE), 0, false, pkParent);
		pkParent->AddChild(pkDigIN);
	}
	return pkParent;
}
//****************************************************************************
// CConfigBranch *CreateLoadSaveConfig( )
///
/// Method that creates a Load Save Config config hierarchy
///
/// @return Pointer to the Load Save config hierarchy
///
///
//****************************************************************************
CConfigBranch* CRecSetupCfgMgr::CreateLoadSaveConfig() {
	CConfigBranch *pkParent = NULL;

	T_PGENERALCONFIG ptGeneralData = pSETUP->GetGeneralSetupConfig()->GetSystemGeneralBlock(CONFIG_MODIFIABLE);

	QString  strLoad(""), strSave(""), strTemp("");
	strLoad = tr("Load");
	strSave = tr("Save");

	if (ptGeneralData != NULL) {
		// firstly create the top level config interface class
		QString  strTitle("");
		QString  strSubTitle("");

		strTitle = tr("Media Conf");

		pkParent = new CConfigBranch(ms_strLOADSAVECONF_KEY, strTitle, strSubTitle, ctMainMenuButton, false, true, 0,
				false, NULL);

		// now add the children
		// Load USB1
		CShortBitFieldData *pkLoadUsb1EnabledData = new CShortBitFieldData(
				reinterpret_cast< USHORT*>(&ptGeneralData->LoadSaveMedia), 1, 0, ms_strEnabledList, bfeBool, 0, 0,
				false);
		strTemp = tr("USB 1");
		strTitle.asprintf(TEXT("%s %s"), strLoad, strTemp);
		CConfigItem *pkLoadUsb1Enabled = new CConfigItem(ms_strLOADSAVECONF_LOAD_USB1_KEY, strTitle,
				pkLoadUsb1EnabledData->GetDataAsString(), ctItemButton, pkLoadUsb1EnabledData, false,
				TRUE, 0, false, pkParent);
		pkParent->AddChild(pkLoadUsb1Enabled);

		//Save USB1 Key
		CShortBitFieldData *pkSaveUsb1EnabledData = new CShortBitFieldData(
				reinterpret_cast< USHORT*>(&ptGeneralData->LoadSaveMedia), 1, 1, ms_strEnabledList, bfeBool, 0, 0,
				false);
		//strSubTitle = CStringUtils::GetItemAtPos( ms_strEnabledList, ptLoadSaveMedia->ScreenSaver.Enabled );
		strTemp = tr("USB 1");
		strTitle.asprintf(TEXT("%s %s"), strSave, strTemp);

		/*if(bISScheduledExport== TRUE && nExportDevice == LOGDEV_USB1 && pkSaveUsb1EnabledData->BitFieldToUShort == TRUE )
		 {
		 V6WarningMessageBox( NULL, L"This media( name of media) has already been configured in Scheduled export settings, User can not enable it.", L"Error", MB_OK );
		 }*/
		CConfigItem *pkSaveUsb1Enabled = new CConfigItem(ms_strLOADSAVECONF_SAVE_USB1_KEY, strTitle,
				pkSaveUsb1EnabledData->GetDataAsString(), ctItemButton, pkSaveUsb1EnabledData, false,
				TRUE, 0, false, pkParent);
		pkParent->AddChild(pkSaveUsb1Enabled);

		//PSR - fix for 1-3DXWHML QXe_General Status shows Expansion Board and Comms Board as connected though Support is removed 
		////The USB2 is not part of AristosEzrecorder so remove from UI LoadSave config.
		///The entry will still there in Configuration but not get displayed to the User (more or less similar to credit enabled/disabled)
		///Handling through Config (removing from config istelf) seems to error prone and difficult so handled this way
		//This approach looks better because FrontSD like devices are handled thorugh credit options. See next section for reference.

#ifndef XSERIESSETUP

		if (GlbDevCaps.IsRecorderEzTrend() == FALSE)
#endif
		{

			//Load Usb 2
			CShortBitFieldData *pkLoadUsb2EnabledData = new CShortBitFieldData(
					reinterpret_cast< USHORT*>(&ptGeneralData->LoadSaveMedia), 1, 2, ms_strEnabledList, bfeBool, 0, 0,
					false);
			//strSubTitle = CStringUtils::GetItemAtPos( ms_strEnabledList, ptLoadSaveMedia->ScreenSaver.Enabled );
			strTemp = tr("USB 2");
			strTitle.asprintf(TEXT("%s %s"), strLoad, strTemp);
			CConfigItem *pkLoadUsb2Enabled = new CConfigItem(ms_strLOADSAVECONF_LOAD_USB2_KEY, strTitle,
					pkLoadUsb2EnabledData->GetDataAsString(), ctItemButton, pkLoadUsb2EnabledData, false,
					TRUE, 0, false, pkParent);
			pkParent->AddChild(pkLoadUsb2Enabled);
			//Save Usb2
			CShortBitFieldData *pkSaveUsb2EnabledData = new CShortBitFieldData(
					reinterpret_cast< USHORT*>(&ptGeneralData->LoadSaveMedia), 1, 3, ms_strEnabledList, bfeBool, 0, 0,
					false);
			strTemp = tr("USB 2");
			strTitle.asprintf(TEXT("%s %s"), strSave, strTemp);
			CConfigItem *pkSaveUsb2Enabled = new CConfigItem(ms_strLOADSAVECONF_SAVE_USB2_KEY, strTitle,
					pkSaveUsb2EnabledData->GetDataAsString(), ctItemButton, pkSaveUsb2EnabledData, false,
					TRUE, 0, false, pkParent);
			pkParent->AddChild(pkSaveUsb2Enabled);
		}

		if (GlbDevCaps.IsRecorderEzTrend() == FALSE || pGlbSysInfo->FWOptionExtSDAvailable()) {
			//Load SD
			CShortBitFieldData *pkLoadCFEnabledData = new CShortBitFieldData(
					reinterpret_cast< USHORT*>(&ptGeneralData->LoadSaveMedia), 1, 4, ms_strEnabledList, bfeBool, 0, 0,
					false);
#ifndef XSERIESSETUP
			strTemp = tr("SD Card");
#else
	strTemp = tr("CF Card");
#endif
			strTitle.asprintf(TEXT("%s %s"), strLoad, strTemp);
			CConfigItem *pkLoadCFEnabled = new CConfigItem(ms_strLOADSAVECONF_LOAD_CF_KEY, strTitle,
					pkLoadCFEnabledData->GetDataAsString(), ctItemButton, pkLoadCFEnabledData, false,
					TRUE, 0, false, pkParent);
			pkParent->AddChild(pkLoadCFEnabled);
			//Save SD
			CShortBitFieldData *pkSaveCFEnabledData = new CShortBitFieldData(
					reinterpret_cast< USHORT*>(&ptGeneralData->LoadSaveMedia), 1, 5, ms_strEnabledList, bfeBool, 0, 0,
					false);
			strTitle.asprintf(TEXT("%s %s"), strSave, strTemp);
			CConfigItem *pkSaveCFEnabled = new CConfigItem(ms_strLOADSAVECONF_SAVE_CF_KEY, strTitle,
					pkSaveCFEnabledData->GetDataAsString(), ctItemButton, pkSaveCFEnabledData, false,
					TRUE, 0, false, pkParent);
			pkParent->AddChild(pkSaveCFEnabled);
		}

		CSingleLock lock(&m_GlbSetupMutex);
		lock.Lock();
		CCommsSetupConfig *pkCommsConfig = pGlbSetup->GetCommsSetupConfig();
		lock.Unlock();
		T_PCOMMUNICATIONS ptCommsData = NULL;
		if (pkCommsConfig != NULL) {
			ptCommsData = pkCommsConfig->GetCommsBlock(CONFIG_MODIFIABLE);
		}
		BOOL bSharePath = TRUE;
		if (ptCommsData != NULL) {
			bSharePath = ptCommsData->LanInfo.UseShare;
		}
		//Load NAS
		CShortBitFieldData *pkLoadNASEnabledData = new CShortBitFieldData(
				reinterpret_cast< USHORT*>(&ptGeneralData->LoadSaveMedia), 1, 6, ms_strEnabledList, bfeBool, 0, 0,
				false);
		if (bSharePath == FALSE)
			pkLoadNASEnabledData->UpdateData(bSharePath);

		strTemp = tr("NAS");
		strTitle.asprintf(TEXT("%s %s"), strLoad, strTemp);
		CConfigItem *pkLoadNASEnabled = new CConfigItem(ms_strLOADSAVECONF_LOAD_NAS_KEY, strTitle,
				pkLoadNASEnabledData->GetDataAsString(), ctItemButton, pkLoadNASEnabledData, false, bSharePath, 0,
				false, pkParent);
		pkParent->AddChild(pkLoadNASEnabled);

		//Save NAS
		CShortBitFieldData *pkSaveNASEnabledData = new CShortBitFieldData(
				reinterpret_cast< USHORT*>(&ptGeneralData->LoadSaveMedia), 1, 7, ms_strEnabledList, bfeBool, 0, 0,
				false);
		strTemp = tr("NAS");
		strTitle.asprintf(TEXT("%s %s"), strSave, strTemp);

		if (bSharePath == FALSE)
			pkSaveNASEnabledData->UpdateData(bSharePath);
		CConfigItem *pkSaveNASEnabled = new CConfigItem(ms_strLOADSAVECONF_SAVE_NAS_KEY, strTitle,
				pkSaveNASEnabledData->GetDataAsString(), ctItemButton, pkSaveNASEnabledData, false, bSharePath, 0,
				false, pkParent);
		pkParent->AddChild(pkSaveNASEnabled);

	}
	return pkParent;
}

#ifdef TTR6SETUP
// Stability Project Fix: for issue, restrict pen limit to 32 in a group
//
//******************************************************
/// Set the number of pens in a group
/// @param[in] groupNumber - The group number.

//******************************************************
USHORT CRecSetupCfgMgr::SetGroupPenValue(int groupNumber)
{
  USHORT NumEntries = m_GrpPenCounter[groupNumber];
  NumEntries++;
  m_GrpPenCounter[groupNumber] = NumEntries;
  return NumEntries;
}

#endif

//****************************************************************************
// CConfigBranch *CreateRecordingExportConfig( )
///
/// Method that creates the scheduled recording config heirarchy
///
/// @return Pointer to the scheduled recording config hierarchy
///
//****************************************************************************
CConfigBranch* CRecSetupCfgMgr::CreateRecordingExportConfig(BOOL bIsModifiedEncrypt) {
	CConfigBranch *pkParent = NULL;

	// now setup the actual schedule export fields
	T_PRECPROFILE ptProfile = pSETUP->GetGeneralSetupConfig()->GetProfileBlock(CONFIG_MODIFIABLE);

	if (ptProfile != NULL) {
		T_LOGGINGINFO *ptLogging = &ptProfile->Logging;

		//strTitle = tr("Scheduled");
		QString  strTitle("");

		strTitle = L"Export";

		pkParent = new CConfigBranch(ms_strRECORDING_EXPORT_KEY, strTitle, strTitle, ctSubMenuButton, false, true, 0,
				false, NULL);

		strTitle = L"TV Encrypt";

		bool bIsEncryptEnabled = FALSE;

		if (ptLogging->Encrypt == TRUE) {
			bIsEncryptEnabled = TRUE;
		} else if (ptLogging->Encrypt == FALSE && ptLogging->CSV == FALSE) {
			if (bIsModifiedEncrypt)

				bIsEncryptEnabled = FALSE;
			else
				bIsEncryptEnabled = TRUE;
		}

		ptLogging->Encrypt = bIsEncryptEnabled;

		// Perform export of encrypted data - this will be a boolean type bitfield
		CShortBitFieldData *pkEncryptData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptLogging), 1, 11,
				ms_strEnabledList, bfeBool, 0, 0, true);

		CConfigItem *pkLogEncrypt = new CConfigItem(ms_strENABLED_KEY, strTitle, pkEncryptData->GetDataAsString(),
				ctItemButton, pkEncryptData, false, bIsEncryptEnabled, 0, false, pkParent);
		pkParent->AddChild(pkLogEncrypt);

		bool bIsCSVEnabled = FALSE;

		if (ptLogging->CSV == TRUE) {
			bIsCSVEnabled = TRUE;
		} else if (ptLogging->Encrypt == FALSE && ptLogging->CSV == FALSE) {
			if (bIsModifiedEncrypt == FALSE)
				bIsCSVEnabled = FALSE;
			else
				bIsCSVEnabled = TRUE;
		}

		strTitle = L"CSV";

		ptLogging->CSV = bIsCSVEnabled;

		// CSV export
		CShortBitFieldData *pkLogCSVData = new CShortBitFieldData(reinterpret_cast< USHORT*>(ptLogging), 1, 12,
				ms_strEnabledList, bfeBool, 0, 0, true);

		CConfigItem *pkLogCSV = new CConfigItem(ms_strENABLED_KEY, strTitle, pkLogCSVData->GetDataAsString(),
				ctItemButton, pkLogCSVData, false, bIsCSVEnabled, 0, false, pkParent);
		pkParent->AddChild(pkLogCSV);

		/*<START> ANOOP commented. The group functionality is disabled for CSV export. The CSV export will be done for 
		 NO GROUP.Commenting the code to disable the CSV export option groupwise to reduce the scope in meeting the schedule. </START> 

		 //Batch Export 
		 //check if groups
		 //if(ptLogging->CSV == TRUE)
		 //{
		 //	// loop through the groups inserting their number and name
		 //	QString   strGroup( QString   ::fromWCharArray("") );
		 //	T_PGENERALCONFIG ptGeneralData = pSETUP->GetGeneralSetupConfig()->GetSystemGeneralBlock( CONFIG_MODIFIABLE );

		 //	//ms_strGroupList = QString   ::fromWCharArray("");
		 //	ms_strGroupList = tr("No Group|");
		 //	for( USHORT usGroupCount = 0; usGroupCount < GENERALCONFIG_GROUPNAME_SIZE ; usGroupCount++ )
		 //	{
		 //		strGroup.asprintf( L"%s|", ptGeneralData->GroupName[ usGroupCount ] );
		 //		ms_strGroupList += strGroup;
		 //	}

		 //	// Group selection
		 //	CShortBitFieldData *pkGrpData = new CShortBitFieldData(	reinterpret_cast< USHORT* >( ptLogging ),
		 //															3,
		 //															13,
		 //															ms_strGroupList,												
		 //															bfeSingleSelList,
		 //															0,
		 //															0,
		 //															true );

		 //	//strTitle = tr("Group");
		 //	strTitle = L"Batch";
		 //	CConfigItem *pkGroup = new CConfigItem(	ms_strEXPORT_CSV_GROUP_KEY,
		 //											strTitle,
		 //											pkGrpData->GetDataAsString(),
		 //											ctItemButton,
		 //											pkGrpData,
		 //											false,
		 //											bIsCSVEnabled,
		 //											0,
		 //											false,
		 //											pkParent );
		 //	pkParent->AddChild( pkGroup );
		 //}
		 <END> Commenting the code to disable the CSV export option groupwise to reduce the scope in meeting the schedule.
		 ANOOP commented </END> */

	}
	return pkParent;
}

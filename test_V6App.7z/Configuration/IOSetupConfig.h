/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 Configuration
/// @n IOSetupConfig.h
/// @n implementation to handle creating default configurations
///	and getting CMM I/O board configuration.
/// @author GKW
/// @date 22/09/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 28	Stability Project 1.25.1.1	7/2/2011 4:58:02 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 27	Stability Project 1.25.1.0	7/1/2011 4:28:15 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 26	V6 Firmware 1.25		9/23/2008 3:09:28 PM	Build Machine 
//		AMS2750 Merge
// 25	V6 Firmware 1.24		11/20/2006 8:55:56 PM Graham Waterfield
//		Check whether any events are enabled
// $
//
//////////////////////////////////////////////////////////////////////

#ifndef _IOSETUPCONFIG_H
#define _IOSETUPCONFIG_H

#include "SetupConfigService.h"
#include "DevCaps.h"
#include "V6Config.h"
#define USE_PRESET_LIMITS		0		// Use preset range default selected channel limits
#define USE_USER_LIMITS			1		// Use user selected channel range select limits

class CIOSetupConfig: public CSetupConfigService {
public:

	CIOSetupConfig(void);
	virtual ~CIOSetupConfig(void);

	T_CONFIG_RETURN_VALUE CreateServiceDefaultConfig(void);
	T_CONFIG_VALIDATE_RETURN ValidateServiceConfig(void);

	T_CONFIG_RETURN_VALUE PostCommitProcessing(void);
	T_CONFIG_RETURN_VALUE PreCommitProcessing(void);

	// Determine if the analogue input is a TC
	bool IsAnalogueSetupAsTC(const USHORT usSensorCount);

	T_CONFIG_RETURN_VALUE GetPreviousRecorderConfig(const T_DEVICECAPS *const pPrevDevCaps);

	T_CONFIG_RETURN_VALUE CreateDefaultBoard(const USHORT slotNumber);
	T_CONFIG_RETURN_VALUE CreateRecorderSlots(void);

	T_CONFIG_VALIDATE_RETURN ValidateAndAlignBoardCMM(const USHORT slotNumber,
			const class CDeviceCaps *const pPrevDevCaps);
	T_CONFIG_VALIDATE_RETURN ResetProcessedCMMToUserCalSet(void);
	T_CONFIG_VALIDATE_RETURN CheckCMMForUserCalSet(void);

	// Modify CMM setup to include defaults that cannot be set by the CMM via board and channel number
	T_CONFIG_RETURN_VALUE CreateDefAIChan(const USHORT slotNumber, const USHORT chanNumber);
	T_CONFIG_RETURN_VALUE CreateDefAOChan(const USHORT slotNumber, const USHORT chanNumber);
	T_CONFIG_RETURN_VALUE CreateDefDigitalChan(const USHORT slotNumber, const USHORT chanNumber);
	T_CONFIG_RETURN_VALUE CreateDefTopPulseChan(const USHORT slotNumber, const USHORT chanNumber);
	T_CONFIG_RETURN_VALUE CreateDefBottomPulseChan(const USHORT slotNumber, const USHORT chanNumber);
	T_CONFIG_RETURN_VALUE CreateTopSlotRecorderCalInfo(void);

	// Set the board and channel currently selected in CMM
	T_CONFIG_RETURN_VALUE SelectBoardType(const USHORT slotNumber, const USHORT boardType);

	BOOL AnyEnabledEvents();

	// Get CMM setup structures
	T_PCHANCALPOINT GetAnalogueOPCal(const USHORT slotNumber, const USHORT analNumber, REFERENCE cfgType);
	T_PCHANCJCCAL GetAnalogueCJCal(const USHORT slotNumber, const USHORT analNumber, const REFERENCE cfgType);
	T_PAICHANNEL GetAnalogueInput(const USHORT slotNumber, const USHORT analNumber, const REFERENCE cfgType);
	T_PAICHANNEL GetAnalogueInput(const USHORT usINSTANCE_NO, const REFERENCE cfgType);
	T_PAOCHANNEL GetAnalogueOutput(const USHORT slotNumber, const USHORT analNumber, const REFERENCE cfgType);
	T_PDIGCHANNEL GetDigital(const USHORT slotNumber, const USHORT digiNumber, const REFERENCE cfgType);
	T_PPULSECHANNEL GetPulseInput(const USHORT slotNumber, const USHORT digiNumber, const REFERENCE cfgType);
	T_PDEMOCHANNEL GetDemoChannel(const USHORT usSLOT_NO, const USHORT usBOARD_CHAN_NO, const REFERENCE eCFG_TYPE);

	// Query board and channel currently selected in CMM
	USHORT GetBoardType(const USHORT slotNumber, const REFERENCE cfgType) const;
	USHORT GetChannelSelectedType(const USHORT slotNumber, const USHORT chanNumber, const REFERENCE cfgType) const;
	USHORT GetTopSlotChannelSelectedType(const T_TOPSLOT *pTopSlot, const USHORT chanNumber) const;
	USHORT GetBottomSlotChannelSelectedType(const T_BOTTOMSLOT *pBottomSlot, const USHORT chanNumber) const;

	// Runtime change of AI CMM via system channel
	T_CONFIG_RETURN_VALUE SelectAcqRate(const USHORT sysChannelNo, const USHORT Rate);
	T_CONFIG_RETURN_VALUE SelectVoltageRange(const USHORT sysChannelNo, const USHORT Range);
	T_CONFIG_RETURN_VALUE SelectCurrentRange(const USHORT sysChannelNo, const USHORT Range);
	T_CONFIG_RETURN_VALUE SelectResistanceRange(const USHORT sysChannelNo, const USHORT Range);
	T_CONFIG_RETURN_VALUE SelectTCRange(const USHORT sysChannelNo, const USHORT Range);
	T_CONFIG_RETURN_VALUE SelectRTRange(const USHORT sysChannelNo, const USHORT Range);
	T_CONFIG_RETURN_VALUE SelectSlotEngValues(const USHORT sysChannelNo, const float EngZero, const float EngSpan);
	T_CONFIG_RETURN_VALUE SelectTiedToPen(const USHORT sysChannelNo, const USHORT PenNo);
	T_CONFIG_RETURN_VALUE SetSQRTExtractState(const USHORT sysChannelNo, const BOOL State);
	T_CONFIG_RETURN_VALUE SelectSlotUserDesiredRange(const USHORT sysChannelNo, const UCHAR Units, const float RngZero,
			const float RngSpan);

	// Runtime query of CMM via system channel
//	T_CONFIG_RETURN_VALUE QueryChannelSelectedType( const REFERENCE configType, const USHORT sysChannelNo, USHORT *pchanType);
	T_CONFIG_RETURN_VALUE QueryAIChannelSelection(const REFERENCE configType, const USHORT sysChannelNo,
			USHORT *pSelection);
	T_CONFIG_RETURN_VALUE QueryAIAcqRate(const REFERENCE configType, const USHORT cardNo, const USHORT cardChanNo,
			USHORT *pRate);
	T_CONFIG_RETURN_VALUE QueryAISysChanAcqRate(const REFERENCE configType, const USHORT sysChannelNo, USHORT *pRate);
	T_CONFIG_RETURN_VALUE QueryVoltageRange(const REFERENCE configType, USHORT sysChannelNo, USHORT *pRange);
	T_CONFIG_RETURN_VALUE QueryCurrentRange(const REFERENCE configType, USHORT sysChannelNo, USHORT *pRange);
	T_CONFIG_RETURN_VALUE QueryResistanceRange(const REFERENCE configType, USHORT sysChannelNo, USHORT *pRange);
	T_CONFIG_RETURN_VALUE QueryTCRange(const REFERENCE configType, USHORT sysChannelNo, USHORT *pRange);
	T_CONFIG_RETURN_VALUE QueryRTRange(const REFERENCE configType, USHORT sysChannelNo, USHORT *pRange);
	T_CONFIG_RETURN_VALUE QuerySlotEngValues(const REFERENCE configType, USHORT sysChannelNo, float *pEngZero,
			float *pEngSpan);
	T_CONFIG_RETURN_VALUE QueryTiedToPen(const REFERENCE configType, USHORT sysChannelNo, USHORT *pPenNo);
	T_CONFIG_RETURN_VALUE GetSQRTExtractState(const REFERENCE configType, USHORT sysChannelNo, BOOL *pState);

	USHORT GetAIChannelRateFromConfiguration(const UCHAR CMMSetting);
	BOOL QueryAIAcqRateStatus(const REFERENCE configType, const USHORT slotNo, const USHORT cardChanNo, USHORT *pRate);

	// Runtime query of CMM via card slot and card channel
	T_CONFIG_RETURN_VALUE QuerySlotAcqRate(const REFERENCE configType, const USHORT slotNo, const USHORT ChanNo,
			USHORT *pRate);
	T_CONFIG_RETURN_VALUE QuerySlotChannelSelectedType(const REFERENCE configType, const USHORT slotNo,
			const USHORT ChanNo, USHORT *pchanType);
	T_CONFIG_RETURN_VALUE QueryAISlotChannelSelection(const REFERENCE configType, const USHORT slotNo,
			const USHORT ChanNo, USHORT *pSelection);
	T_CONFIG_RETURN_VALUE QuerySlotVoltageRange(const REFERENCE configType, const USHORT slotNo, const USHORT ChanNo,
			USHORT *pRange);
	T_CONFIG_RETURN_VALUE QuerySlotCurrentRange(const REFERENCE configType, const USHORT slotNo, const USHORT ChanNo,
			USHORT *pRange);
	T_CONFIG_RETURN_VALUE QuerySlotResistanceRange(const REFERENCE configType, const USHORT slotNo, const USHORT ChanNo,
			USHORT *pRange);
	T_CONFIG_RETURN_VALUE QuerySlotTCRange(const REFERENCE configType, const USHORT slotNo, const USHORT ChanNo,
			USHORT *pRange);
	T_CONFIG_RETURN_VALUE QuerySlotRTRange(const REFERENCE configType, const USHORT slotNo, const USHORT ChanNo,
			USHORT *pRange);
	T_CONFIG_RETURN_VALUE QuerySlotEngValues(const REFERENCE configType, const USHORT slotNo, const USHORT chanNo,
			float *pEngZero, float *pEngSpan);
	T_CONFIG_RETURN_VALUE QuerySlotTiedToPen(const REFERENCE configType, const USHORT slotNo, const USHORT chanNo,
			USHORT *pPenNo);
	T_CONFIG_RETURN_VALUE GetSlotSQRTExtractState(const REFERENCE configType, const USHORT slotNo, USHORT chanNo,
			BOOL *pState);

	// Runtime change of CMM via card slot and card channel
	T_CONFIG_RETURN_VALUE SelectSlotEngValues(const USHORT slotNo, const USHORT chanNo, const float EngZero,
			const float EngSpan);
	T_CONFIG_RETURN_VALUE SelectSlotUserDesiredRange(const USHORT slotNo, const USHORT chanNo, const UCHAR Units,
			const float RngZero, const float RngSpan);

	// Get a complete CMM structure for boards
	T_PBOARDCALS GetTopSlotBoardRangeCalInfo(const USHORT slotNumber, const REFERENCE cfgType) const;
	T_PRECORDERCAL GetTopSlotRecorderCalInfo(const REFERENCE cfgType) const;

	// Method that gets the AMS2750 sensor block
	T_PAMS2750SENSORS GetAMS2750SensorBlock(REFERENCE cfgType);

	// Method that updates the working AMS2750 sensors with the committed copy - used when discarding
	// changes
	void UpdateAMS270SensorWorkingWithCommitted();

	// Method that updates the committed AMS2750 sensors with the working copy - used when committing
	// changes - also writes to flash
	void UpdateAMS270SensorCommittedWithWorking();

	// Method that gets the Multi Point Calibration block
	T_PMPCALCHANNELS GetMultiPointBlock(REFERENCE cfgType);

	// Method that resets any IO setup information that may be held in NV or somewhere
	// other than the setup file
	void ResetSetup();

private:

	// Runtime change of CMM via card slot and card channel
	T_CONFIG_RETURN_VALUE SelectSlotAcqRate(const USHORT slotNo, const USHORT ChanNo, const USHORT Rate);
	T_CONFIG_RETURN_VALUE SelectSlotTCRange(const USHORT slotNo, const USHORT ChanNo, const USHORT Range);
	T_CONFIG_RETURN_VALUE SelectSlotRTRange(const USHORT slotNo, const USHORT ChanNo, const USHORT Range);
	T_CONFIG_RETURN_VALUE SelectSlotTiedToPen(const USHORT slotNo, const USHORT chanNo, const USHORT PenNo);
	T_CONFIG_RETURN_VALUE SetSlotSQRTExtractState(const USHORT slotNo, const USHORT chanNo, const BOOL State);

	T_CONFIG_RETURN_VALUE SelectSlotRange(USHORT slotNo, USHORT chanNo, USHORT chanSelect, USHORT Range);

	BOOL indexOfBoardSlotAndChannel(const USHORT sysChannelNo, USHORT *pSlotNo, USHORT *pChanNo);

	class CSlotMap *m_pSlotMapObj;			///< Slot map holder

	T_PTOPSLOT CreateTopSlot(const USHORT slotNumber);
	T_PBOTTOMSLOT CreateBottomSlot(const USHORT slotNumber);

	// Get a complete CMM structure for boards
	T_PTOPSLOT GetTopSlot(const USHORT slotNumber, const REFERENCE cfgType) const;
	T_PBOTTOMSLOT GetBottomSlot(const USHORT slotNumber, const REFERENCE cfgType) const;

	// Save the calibration non vol structure into flash
	BOOL NVCalibrationSaveToFlash();

	// The working copy of the AMS2750 sensor block
	T_AMS2750SENSORS m_AMS2750SensorsWorking;

	// The committed copy of the AMS2750 sensor block
	T_AMS2750SENSORS m_AMS2750SensorsCommitted;

	// Method that loads the AMS2750 sensor configuration from NV
	void LoadAMS2750SensorBlockFromNV();

	// Method that defaults the AMS2750 sensors block
	void DefaultAMS2750SensorInfo(T_PAMS2750SENSORS pSensors);

	// Validates the AMS2750 calibration against any newly modified changes to the cal
	void ValidateAMS2750Calibration();

	/// Method that updates the Multi Point configuration from NV into the CMM block
	void UpdateMultiPointCMMFromNV(T_PMPCALCHANNELS pMPChannelCal);

	/// Method that saves the Multi Point configuration from the CMM block to NV
	void UpdateMultiPointNVFromCMM(T_PMPCALCHANNELS pMPChannelCal);

	/// Create a TC multipoint cal block within the CMM
	T_PMPCALCHANNELS CreateTCMultipointCalBlock();

	// Method that defaults a Multi Point Calibration block
	void DefaultMultiPointInfo(T_PMPCALCHANNELS pMPChannelCal);

};
// End of Class Declaration

#endif // _IOSETUPCONFIG_H

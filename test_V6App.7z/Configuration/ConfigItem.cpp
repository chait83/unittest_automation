/// @file 
/// **************************************************************************
/// Â© Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Configuration System
/// @n Filename:  ConfigItem.cpp
/// @n Description: Implementation for the CConfigItem class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  5 Stability Project 1.2.1.1 7/2/2011 4:56:16 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  4 Stability Project 1.2.1.0 7/1/2011 4:28:13 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  3 V6 Firmware 1.2 5/31/2005 7:16:50 PM  Roger Dawson  
//  Screen designer configuration changes.
//  2 V6 Firmware 1.1 4/28/2005 3:38:04 PM  Roger Dawson  
//  Modified the EditData method so it updates an items subtitle if
//  necessary. Also removed commented out code.
// $
//
// **************************************************************************

#include "ConfigItem.h"
#include "ConfigData.h"

#include <math.h>
#include <stdlib.h>

//****************************************************************************
// CConfigItem(	const QString   &rstrKEY,
//					const QString   &rstrTITLE,
//					const QString   &rstrSUB_TITLE,
//					const ControlType eCONTROL_TYPE,
//					CConfigData* const pkCONFIG_DATA,
//					const bool bMODIFIED,
//					const bool bENABLED,
//					const long lHELP_ID,
//					const bool bLOCKED,
//					CConfigInterface* const pkPARENT )
///
/// Constructor
///
/// @param[in] 			const QString   &rstrKEY - Unique Key used to identify the config item
/// @param[in] 			const QString   &rstrTITLE - Title string to be displayed on the control
/// @param[in] 			const QString   &rstrSUB_TITLE - Subtitle string to be displayed on the control
/// @param[in] 			const ControlType eCONTROL_TYPE - The type of control
/// @param[in] 			CConfigData* const pkCONFIG_DATA - Class containing information about the config data
/// @param[in] 			const bool bMODIFIED - Flag indicating if this item or any of its children have
///						been modified
/// @param[in] 			const bool bENABLED - Flag indicating if the config item is enabled
/// @param[in] 			const long lHELP_ID - The resource ID for a help string
/// @param[in] 			const bool bLOCKED - Flag indicating if the config item is editable or not - this is
///						to allow the user to browse the configuration structure but to not modify the data
/// @param[in] 			CConfigInterface* const pkPARENT - Pointer to the parent config branch class
///
//****************************************************************************
CConfigItem::CConfigItem(const QString  &rstrKEY, const QString  &rstrTITLE, const QString  &rstrSUB_TITLE,
		const ControlType eCONTROL_TYPE, CConfigData *const pkCONFIG_DATA, const bool bMODIFIED, const bool bENABLED,
		const long lHELP_ID, const bool bLOCKED, CConfigInterface *const pkPARENT) : CConfigInterface(rstrKEY,
		rstrTITLE, rstrSUB_TITLE, eCONTROL_TYPE, bMODIFIED, bENABLED, lHELP_ID, bLOCKED, pkPARENT, citConfigItem), m_pkConfigData(
		pkCONFIG_DATA) {
}
//****************************************************************************
// ~CConfigItem(void)
///
/// Destructor
///
//****************************************************************************
CConfigItem::~CConfigItem(void) {
	// delete the associated CConfigData class
	delete m_pkConfigData;
	m_pkConfigData = NULL;
}/*
 //****************************************************************************
 // bool EditData() 
 ///
 /// Method call to provide a facility for a user to edit an item
 ///
 //****************************************************************************
 bool CConfigItem::EditData() 
 { 
 QString   strTitle( m_strTITLE );
 bool bUpdateTree = m_pkConfigData->EditData( strTitle );
 // check if the trre is being updated
 if( !bUpdateTree )
 {
 // the tree is not to be updated - this means the strTitle string will have been modified
 // into the new sub title for this item therefore we must copy it
 m_strSubTitle = strTitle;
 }
 return bUpdateTree; 
 }
 */

/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 Configuration
/// @n Configuration.h
/// @n interface of the CConfiguration class.
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 35	Stability Project 1.32.1.1	7/2/2011 4:56:17 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 34	Stability Project 1.32.1.0	7/1/2011 4:27:02 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 33	V6 Firmware 1.32		8/9/2006 1:44:38 PM	Jason Parker 
//		persist flag passed to load and save configs
// 32	V6 Firmware 1.31		5/4/2006 5:23:42 PM	Andy Kassell	On
//		de-persist only modify change header if config has changed
// $
//
//////////////////////////////////////////////////////////////////////
#ifndef _CONFIGURATION_H
#define _CONFIGURATION_H

#include "CMMDefines.h"
#include "ConfigurationManager.h"

#include "ConfigurationCommon.h"

#include "StoragePaths.h"
#include "CStorage.h"
#include "Defines.h"

const USHORT CONFIG_CRC_LENGTH = 2;						///< CRC is two bytes
const USHORT CONFIG_WAIT = 50;						///< Time in ms to wait before testing for config availability
const USHORT CONFIG_CMM_CONVERSION_TIMEOUT_IN_SEC = 60;	///< CMM conversion Process timeout Value
const DWORD CONFIG_INVALID_CONFIGURATION_ID = 0;	///< Invalid Configuration ID

typedef enum _eConfigAction {
	CONFIG_CMM_LOAD_PERSISTED_CONFIG, CONFIG_CMM_LOAD_NEW_CONFIG, CONFIG_CMM_UPDATE_CONFIG

} T_CONFIG_CONFIGURATION_ACTION;

/// @todo Encrpyction and decryption needs to be added, need to investigate
///	the routines to use, available classes. 
///
class CConfiguration {
public:

	/// Constructor
	CConfiguration(void);

	/// Destructor
	virtual ~CConfiguration(void);

	// Static interfaces for CMM access
	static void* CreateNewBlock(WORD blockType, WORD instance, DWORD configID);
	static void* CreateNewVariableSizedBlock(WORD blockType, WORD instance, DWORD size, DWORD configID);
	static CMMERROR ModifyVariableSizedBlock(WORD blockType, WORD instance, DWORD size, BYTE *pNewBlock,
			DWORD configID);
	static void* GetBlock(WORD blockType, WORD instance, DWORD configID, REFERENCE cfgType);
	static BOOL WasBlockModified(WORD blockType, WORD instance, DWORD configID);

	/// Force impelementations in derived classes
	virtual T_CONFIG_RETURN_VALUE CreateDefaultConfig(void) = PURE_VIRTUAL_FUNCTION
	;
	virtual T_CONFIG_RETURN_VALUE LoadConfig(QFile &fileToLoadConfig,
			const TV_BOOL persistedLoad = FALSE) = PURE_VIRTUAL_FUNCTION
	;
	virtual T_CONFIG_RETURN_VALUE SaveConfig(QFile &fileToSaveConfig,
			const TV_BOOL persistedSave = FALSE) = PURE_VIRTUAL_FUNCTION
	;
	virtual T_CONFIG_RETURN_VALUE UpdateConfig(void) = PURE_VIRTUAL_FUNCTION
	;
	virtual T_CONFIG_VALIDATE_RETURN ValidateConfiguration(void) = PURE_VIRTUAL_FUNCTION
	;
	virtual void SetConfigurationId(const DWORD configurationId) = PURE_VIRTUAL_FUNCTION
	;

	/// Create a CMM Configuration 
	virtual T_CONFIG_RETURN_VALUE CreateCMMConfiguration(void);

	/// Load a Configuration File into the CMM Configuration 
	T_CONFIG_RETURN_VALUE LoadConfigUsingFileName(const QString  const pConfigPathAndFileName, TV_BOOL persistedLoad =
	FALSE);

	/// Save a Configuration from the CMM
	T_CONFIG_RETURN_VALUE SaveConfigFile(QFile &fileToSaveConfig, CONFIGHEADERINFO &configurationHeader);
	T_CONFIG_RETURN_VALUE SaveConfig(QFile *pFile);
	T_CONFIG_RETURN_VALUE SaveConfigUsingFileName(const QString  const pConfigPathAndFileName, TV_BOOL persistedSave =
	FALSE);

	/// Configuration Identification Number
	DWORD GetConfigId(void) {
		return (m_ConfigurationId);
	}
	void SetConfigId(const DWORD configurationId) {
		m_ConfigurationId = configurationId;
	}

	/// Get the Current Config Version Loaded into the CMM
	DWORD GetConfigVersion(void) {
		return (m_ConfigVersion);
	}

	/// Create and delete configurations
	T_CONFIG_RETURN_VALUE CreateCMMHolder(DWORD sessionNumber);
	T_CONFIG_RETURN_VALUE DeleteConfig(void);

	// Load the header of config file
	T_CONFIG_RETURN_VALUE LoadConfigHeader(QString  pConfigFileName);

	// Validate a configuration file
	BOOL ValidateConfigFile(QString  pConfigFileName, T_CONFIG_FILE_TYPE fileType);

	// Commit and discard configs
	T_CONFIG_RETURN_VALUE CommitConfig(void);
	T_CONFIG_RETURN_VALUE DiscardConfigurationChanges(void);

	BOOL ConversionHasBeenPerformed() {
		return m_ConversionPerformed;
	}
	;
	void SetConversionPerformed(BOOL performed) {
		m_ConversionPerformed = performed;
	}
	;
	DWORD ConvertedFromVersion() {
		return m_ConfigVersion;
	}
	;

	BOOL DepersistChangesMadeInConfig() {
		return m_configChangesMadeToDepersist;
	}
	;
	void SetDepersistChangesMade() {
		m_configChangesMadeToDepersist = TRUE;
	}
	;
	void ClearDepersistChangesMade() {
		m_configChangesMadeToDepersist = FALSE;
	}
	;

	T_CONFIG_RETURN_VALUE CleanUpConfiguration(const BOOL operationSuccessful);

protected:

	T_CONFIG_RETURN_VALUE LoadConfigService(QFile &fileToLoadConfig, const T_CONFIG_FILE_TYPE configFileType,
			const TV_BOOL persistedLoad);
	T_CONFIG_RETURN_VALUE ValidateConfigFileHeader(const CONFIGHEADERINFO &configurationHeader,
			const T_CONFIG_FILE_TYPE configFileType);
	T_CONFIG_RETURN_VALUE PerformLoadCMMConfiguration(const UINT configLenghtInBytesWithoutCRC, BYTE *pAllocatedBuffer,
			const BYTE *const pConfigFileBuffer, const TV_BOOL persistedLoad);

private:

	T_CONFIG_RETURN_VALUE LoadConfigFile(QFile &fileToLoadConfig, const T_CONFIG_FILE_TYPE configFileType,
			const TV_BOOL persistedLoad = FALSE);

	T_CONFIG_RETURN_VALUE WaitForConfigurationAvailability(WORD cmmSection);

	DWORD m_ConfigurationId;		///< Configuration Handler from the CMM 
	DWORD m_PreviousConfigurationId;		///< Previous Configuration Identification Number 
	DWORD m_ConfigVersion;		///< Version of Configuration loaded by the CMM

	BOOL m_ConversionPerformed;	///< Indicates if a conversion has been performed on a loaded config.

	BOOL m_configChangesMadeToDepersist;	///< Indicates that changes have been made to a depersisted configuration

};
// End of Class Declaration

#endif // _CONFIGURATION_H


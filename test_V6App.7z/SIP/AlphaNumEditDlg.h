/// @file
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Configuration System
/// @n Filename:  AlphaNumEditDlg.h
/// @n Description: Definition for the CAlphaNumEditDlg class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  7 Stability Project 1.4.1.1 7/2/2011 4:55:21 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  6 Stability Project 1.4.1.0 7/1/2011 4:26:33 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  5 V6 Firmware 1.4 3/14/2006 10:02:43 PM  Roger Dawson  
//  Fixed excessive memory usage by SIPs.
//  4 V6 Firmware 1.3 3/1/2006 6:26:41 PM Roger Dawson  
//  Modified the various edit panels so they are no longer singletons in
//  order to save memory.
// $
//
// **************************************************************************

#if !defined(AFX_ALPHANUMEDITDLG_H__2B49D3AA_81DD_4A76_A571_9286369132CC__INCLUDED_)
#define AFX_ALPHANUMEDITDLG_H__2B49D3AA_81DD_4A76_A571_9286369132CC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AlphaNumEditDlg.h : header file
//

#include "EditPanelDlg.h"

//**CAlphaNumEditDlg**********************************************************
///
/// @brief Dialog that displays the Alphanumeric SIP
/// 
/// Dialog class that displays the alphanumeric SIP.
///
//****************************************************************************
class CAlphaNumEditDlg: public CEditPanelDlg {
// Construction
public:
	CAlphaNumEditDlg(CWidget *pParent = NULL);  // standard constructor

	// Destructor
	virtual ~CAlphaNumEditDlg();

	// Method runs the numerical SIP and returns the entered data
	static const bool ShowSIP(const QString  &strTITLE, QString  &rstrEnteredText, const USHORT usMAX_DATA_LENGTH,
			glbpCallbackFunction pValidateFunc, const QString  &rstrHELP_TOPIC, const QString  &rstrHELP_CHAPTER);

// Dialog Data
	//{{AFX_DATA(CAlphaNumEditDlg)
	enum {
		IDD = IDD_ALPHA_NUM_SIP_DLG
	};
	// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAlphaNumEditDlg)
protected:
	virtual void DoDataExchange(CDataItem *pDX);  // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CAlphaNumEditDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG


private:
	// Method that initialises the edit panel member variables such as the bitmap and keymap
	void InitializeIP();

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ALPHANUMEDITDLG_H__2B49D3AA_81DD_4A76_A571_9286369132CC__INCLUDED_)

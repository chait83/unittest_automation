/// @file EditPanel.cpp
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 EditPanel
/// @n Filename: EditPanel.cpp
/// @n Desc:	 Call the single line edit panel with the appropriate
/// initialization parameters. Work as the test client.  
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  13  Stability Project 1.10.1.1 7/2/2011 4:56:59 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  12  Stability Project 1.10.1.0 7/1/2011 4:26:33 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  11  V6 Firmware 1.10 6/2/2005 8:29:36 PM Sanjeev (HTSL) 
//  Added one parameter pIsTimeOut and integrate the MuLE
//  10  V6 Firmware 1.9 5/19/2005 10:08:22 PM  Roger Dawson  
//  Removed memeory leak.
// $
//
// ****************************************************************
/******************************************************************************************
 COPYRIGHT (c) 2004
 HONEYWELL INC.,
 ALL RIGHTS RESERVED

 This software is a copyrighted work and/or information protected
 as a trade secret. Legal rights of Honeywell Inc. in this
 software is distinct from ownership of any medium in which the
 software is embodied. Copyright or trade secret notices included
 must be reproduced in any copies authorized by Honeywell Inc.
 The information in this software is subject to change without
 notice and should not be considered as a commitment by Honeywell
 Inc.
 ******************************************************************************************/

#include "EditPanel.h"
#include "EditPanelDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEditPanelApp
BOOL WINAPI CallbackFunction(QString pBuffer) {
	return TRUE;
}

BEGIN_MESSAGE_MAP(CEditPanelApp, CWinApp)
//{{AFX_MSG_MAP(CEditPanelApp)
// NOTE - the ClassWizard will add and remove mapping macros here.
//  DO NOT EDIT what you see in these blocks of generated code!
//}}AFX_MSG
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEditPanelApp construction

CEditPanelApp::CEditPanelApp()
: CWinApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CEditPanelApp object

CEditPanelApp theApp;

//**************************************************************
/// CEditPanel InitInstance()
///
/// Create the CEditPanelDlg object and call the 
/// InitializeIP() with first time initialization parameters
/// and ShowIP() with the run time initialization parameters 
///
/// @return FALSE to close the application otherwise TRUE
///  
//**************************************************************
BOOL CEditPanelApp::InitInstance() {
	// Standard initialization
	// If you are not using these features and wish to reduce the size
	// of your final executable, you should remove from the following
	// the specific initialization routines you do not need.

	QFile file;
	DWORD nLength;
	FileException e;
	BOOL returnValue;
	LPVOID pFileBuffer;

#ifdef UNDER_CE
	QString   strFileName = L"\\Compact Flash2\\Demopanel.bmp";
#else
	QString  strFileName = L"C:\\Product\\V6\\sw\\src\\binaries\\Bin\\Debug\\pc\\Demopanel.bmp";
#endif
	//Open the bitmap file from the current directory
	if (!file.Open(strFileName, QFile::ReadOnly, &e)) {
#ifdef _DEBUG
			 afxDump << "File could not be opened " << e.m_cause << "\n";
		 #endif
	}

	//Get the length of the file
	nLength = (DWORD) file.size();

	//Allocate the memory of the file length size
	pFileBuffer = malloc(nLength);

	// Store the file in the allocated memory
	if (file.Read((void*) pFileBuffer, nLength) != nLength)
		QMessageBox(_T("going wrong"));

	// Fill the POSITION_INFO structure
	POSITION_INFO PositionInfo;
	PositionInfo.XCoordinate = 0;	//x coordinate of the SIP
	PositionInfo.YCoordinate = 0;  //y coordinate of the SIP

	//size and position map information
	SIZE_POSITION sizePosition = { { { 61, 2, 20, 220, 20 }, { 62, 2, 0, 220, 20 }, { 63, 226, 2, 44, 30 }, { 64, 274,
			2, 44, 30 }, { 70, 224, 34, 30, 26 }, { 71, 256, 34, 30, 26 }, { 69, 288, 34, 30, 26 },
			{ 1, 0, 62, 30, 26 }, { 2, 32, 62, 30, 26 }, { 3, 64, 62, 30, 26 }, { 4, 96, 62, 30, 26 }, { 5, 128, 62, 30,
					26 }, { 6, 160, 62, 30, 26 }, { 7, 192, 62, 30, 26 }, { 8, 224, 62, 30, 26 },
			{ 9, 256, 62, 30, 26 }, { 10, 288, 62, 30, 26 }, { 11, 0, 92, 30, 26 }, { 12, 32, 92, 30, 26 }, { 13, 64,
					92, 30, 26 }, { 14, 96, 92, 30, 26 }, { 15, 128, 92, 30, 26 }, { 16, 160, 92, 30, 26 }, { 17, 192,
					92, 30, 26 }, { 18, 224, 92, 30, 26 }, { 19, 256, 92, 30, 26 }, { 20, 288, 92, 30, 26 }, { 21, 0,
					122, 30, 26 }, { 22, 32, 122, 30, 26 }, { 23, 64, 122, 30, 26 }, { 24, 96, 122, 30, 26 }, { 25, 128,
					122, 30, 26 }, { 26, 160, 122, 30, 26 }, { 27, 192, 122, 30, 26 }, { 28, 224, 122, 30, 26 }, { 29,
					256, 122, 30, 26 }, { 30, 288, 122, 30, 26 }, { 31, 0, 152, 30, 26 }, { 32, 32, 152, 30, 26 }, { 33,
					64, 152, 30, 26 }, { 34, 96, 152, 30, 26 }, { 35, 128, 152, 30, 26 }, { 36, 160, 152, 30, 26 }, {
					37, 192, 152, 30, 26 }, { 38, 224, 152, 30, 26 }, { 39, 256, 152, 30, 26 },
			{ 73, 288, 152, 30, 26 }, { 65, 0, 182, 30, 26 }, { 40, 32, 182, 30, 26 }, { 41, 64, 182, 30, 26 }, { 42,
					96, 182, 30, 26 }, { 43, 128, 182, 30, 26 }, { 44, 160, 182, 30, 26 }, { 45, 192, 182, 30, 26 }, {
					46, 224, 182, 30, 26 }, { 72, 256, 182, 62, 26 }, { 66, 0, 212, 30, 26 }, { 67, 32, 212, 30, 26 }, {
					68, 64, 212, 30, 26 }, { 74, 96, 212, 94, 26 }, { 47, 192, 212, 30, 26 }, { 48, 224, 212, 30, 26 },
			{ 49, 256, 212, 30, 26 }, { 50, 288, 212, 30, 26 }, }, 64 };

	//Key map information		
	KEY_MAP_INFO KeyMapInfo = { { { 1, 33, 33, 191, 191 }, { 2, 34, 34, 161, 161 }, { 3, 35, 35, 222, 254 }, { 4, 36,
			36, 162, 162 }, { 5, 37, 37, 163, 163 }, { 6, 43, 43, 165, 165 }, { 7, 39, 39, 167, 167 }, { 8, 42, 42, 176,
			176 }, { 9, 40, 40, 177, 200 }, { 10, 41, 41, 181, 201 }, { 11, 49, 49, 49, 49 }, { 12, 50, 50, 50, 50 }, {
			13, 51, 51, 51, 51 }, { 14, 52, 52, 52, 52 }, { 15, 53, 53, 53, 53 }, { 16, 54, 54, 54, 54 }, { 17, 55, 55,
			55, 55 }, { 18, 56, 56, 56, 56 }, { 19, 57, 57, 57, 57 }, { 20, 48, 48, 48, 48 },
			{ 21, 'q', 'Q', 224, 192 }, { 22, 'w', 'W', 225, 193 }, { 23, 'e', 'E', 226, 194 },
			{ 24, 'r', 'R', 227, 195 }, { 25, 't', 'T', 228, 196 }, { 26, 'y', 'Y', 229, 197 },
			{ 27, 'u', 'U', 230, 198 }, { 28, 'i', 'I', 231, 199 }, { 29, 'o', 'O', 232, 200 },
			{ 30, 'p', 'P', 233, 201 }, { 31, 'a', 'A', 234, 202 }, { 32, 's', 'S', 235, 203 },
			{ 33, 'd', 'D', 236, 204 }, { 34, 'f', 'F', 237, 205 }, { 35, 'g', 'G', 238, 206 },
			{ 36, 'h', 'H', 239, 207 }, { 37, 'j', 'J', 241, 209 }, { 38, 'k', 'K', 242, 210 },
			{ 39, 'l', 'L', 243, 211 }, { 40, 'z', 'Z', 244, 212 }, { 41, 'x', 'X', 245, 213 },
			{ 42, 'c', 'C', 246, 214 }, { 43, 'v', 'V', 248, 216 }, { 44, 'b', 'B', 249, 217 },
			{ 45, 'n', 'N', 250, 218 }, { 46, 'm', 'M', 251, 219 }, { 47, 91, 91, 91, 91 }, { 48, 93, 93, 93, 93 }, {
					49, 60, 44, 60, 44 }, { 50, 62, 46, 62, 46 }, }, 50 };

	//bitmap information
	BITMAP_INFO BitmapInfo;
	BitmapInfo.pBmp = pFileBuffer; //Bitmap file buffer pointer in the memory
	BitmapInfo.size = nLength; //Length of the bitmap file in bytes

	//Display information
	DISPLAY_INFO DisplayInfo;
	wcscpy(DisplayInfo.TextFontInfo.FontName, _T("Arial")); //SIP layout text font name
	DisplayInfo.TextFontInfo.FontSize = 16; //Font size of the text for the SIP layout 
	DisplayInfo.TextFontInfo.FontColor = 0x000000; //font color of text for the SIP layout

	wcscpy(DisplayInfo.EditFontInfo.FontName, _T("Arial")); // Edit box text font name
	DisplayInfo.EditFontInfo.FontSize = 16; //Font size of the text for the edit box 
	DisplayInfo.EditFontInfo.FontColor = 0xff0000; //Font color of text for the edit box

	wcscpy(DisplayInfo.DescriptionFontInfo.FontName, _T("Arial")); //Description field font name
	DisplayInfo.DescriptionFontInfo.FontSize = 12; //Font size of the text for the description field
	DisplayInfo.DescriptionFontInfo.FontColor = 0x0000ff; //Font color of text for description field

	DisplayInfo.OffsetInfo.XOffset = 2; //X coordinate offset value 
	DisplayInfo.OffsetInfo.YOffset = 2; //Y coordinate offset value
	DisplayInfo.Background = 0x00ff44; //Background color of the edit box

	CEditPanelDlg dlg; //Object of the SIP class
	m_pMainWnd = &dlg;
	QDialog *pDlg = &dlg;

	//Call the InitializeIP with the first time initialization parameters
	returnValue = dlg.InitializeIP(&PositionInfo, &sizePosition, &KeyMapInfo, &BitmapInfo, &DisplayInfo);

	//Runtime information
	BUFFERINFO BufferInfo;
	OTHERINFO OtherInfo;

	BufferInfo.pBuffer = (WCHAR*) malloc(162); //Buffer that can contain the 30 characters 
	wcscpy(BufferInfo.pBuffer, _T("Trendview"));
//	BufferInfo.pBuffer = _T("Trendview");
	BufferInfo.BufferLength = 80; //Buffer length is 30 characters
	BufferInfo.Limit = 80; //limit of the characters is 30 characters 
//	BufferInfo.IsUpdate		= 0;

	wcscpy(OtherInfo.Description, _T("Description")); //Description string
//	OtherInfo.HelpID		= 10; //HelpID
	OtherInfo.TimeOut = 50000; //Timeout value is 50 seconds
	OtherInfo.IsPassword = 0; // Parameter is not the password

	glbpCallbackFunction pFunctionPointer = CallbackFunction; //Validation function pointer

	BYTE IsUpdate;
	BYTE IsTimeOut;
	//Call the ShowIP function with run time initialization pointer
	dlg.ShowIP(&BufferInfo, pFunctionPointer, &OtherInfo, &IsUpdate, &IsTimeOut);

	free(BufferInfo.pBuffer);
	/* QString   c;
	 c.asprintf(_T("%d"),IsUpdate);
	 QMessageBox(c); */
	// Since the dialog has been closed, return FALSE so that we exit the
	// application, rather than start the application's message pump.
	return FALSE;
}

//******************************************************
/// CEditPanelApp Constructor()
///
/// Constructor - Default Constructor generated by MFC 
///  framework.
//******************************************************
BOOL CEditPanelApp() {
	return TRUE;
}


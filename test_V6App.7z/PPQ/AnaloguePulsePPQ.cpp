/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Pre Process Queues
/// @n Filename:	AnaloguePulsePPQ.cpp
/// @n Description: Analogue/Pulse Pre Process Queue Implementation
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 55	Stability Project 1.50.1.3	7/2/2011 4:55:25 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 54	Stability Project 1.50.1.2	7/1/2011 4:37:57 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 53	Stability Project 1.50.1.1	3/17/2011 3:20:09 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 52	Stability Project 1.50.1.0	2/15/2011 3:02:09 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
// **************************************************************************

#include "AnaloguePulsePPQ.h"
#include "TraceDefines.h"
#include "V6globals.h"

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif

//****************************************************************************
/// 
/// Constructor
///
//****************************************************************************
CAnaloguePulsePPQ::CAnaloguePulsePPQ(void) {
	QMutex * m_csAnalPulsePPQ;

	ResetPPQ();

} // End of Constructor

//****************************************************************************
///
/// Destructor
///
//****************************************************************************
CAnaloguePulsePPQ::~CAnaloguePulsePPQ(void) {
	//deletion of mutex not required
} // End of Destructor

//****************************************************************************
/// Initialise the Pre Process Queue for operation, and enable to allow the
/// Pre Process Queue to be used when calculating coverages. Although the 
/// PPQ is enabled the PPQ requires Synchronisation between the AI Card and 
/// System time before the PPQ is fully functional. 
///
/// @param[in] type		- Type of the Queue in terms of Analogue or Pulse
/// @param[in] reference	- Reference used to populate the Data Item Table
/// @param[in] acqusitionRate - Acquisition Rate of the Pre Process Queue
/// @param[in] clockTickRate - Analogue Card Tick Rate
///
/// @return APPPQ_OK - Pre Process Queue Enabled Successfully
/// 
//****************************************************************************								
T_APPPQ_RETURN_VALUE CAnaloguePulsePPQ::EnablePPQ(const T_PPQC_QUEUE_TYPE type, const USHORT reference,
		const T_PPQC_ACQUSITION_RATE acqusitionRate, const T_PPQC_APCARD_TICK_RATE clockTickRate) {
	m_Type = type;
	m_Reference = reference;
	m_AcquistionRate = acqusitionRate;
	m_Status = PPQC_STATUS_AWAITING_SYNC;
	m_APCardTickRate = clockTickRate;

	return (APPPQ_OK);

} // End of Member Function									

//****************************************************************************
/// Disable the Pre Process Queue, meaning that the PPQ will no longer be 
/// used when calculating the System Coverage. 
///
/// @param[in] - NONE
///
/// @return APPPQ_OK - Pre Process Queue Disabled Successfully
/// 
//**************************************************************************** 
T_APPPQ_RETURN_VALUE CAnaloguePulsePPQ::DisablePPQ(void) {
	m_Status = PPQC_STATUS_DISABLED;

	return (APPPQ_OK);

} // End of Member Function									

//****************************************************************************
/// Reset the Pre Process Queue to Default Values, this involves resetting all
/// member variables to their orginal default value.	
///
/// @param[in] - NONE
///
/// @return APPPQ_OK - Pre Process Queue Reset Successfully
/// 
//**************************************************************************** 
T_APPPQ_RETURN_VALUE CAnaloguePulsePPQ::ResetPPQ(void) {
	m_csAnalPulsePPQ.lock();

	m_Front = APPPQ_DEFAULT_ZERO;
	m_Rear = APPPQ_DEFAULT_ZERO;
	m_ItemCoverage = APPPQ_DEFAULT_ZERO;
	m_PredictedAPClockTick = APPPQ_DEFAULT_ZERO;

	m_MinCoverageTick = APPPQ_DEFAULT_ZERO;
	m_MaxCoverageTick = APPPQ_DEFAULT_ZERO;

	m_Type = PPQC_ANALOGUE;
	m_Reference = PPQC_INVALID_REFERENCE;
	m_AcquistionRate = PPQC_1HZ;
	m_APCardTickRate = PPQC_APCARD_TICK_RATE_400HZ;

	m_Status = PPQC_STATUS_DISABLED;

	m_PreviousPredictedAPClockTick = APPPQ_DEFAULT_ZERO;		//(MarkD)
	m_PreviousAnaloguePulseInputTick = APPPQ_DEFAULT_ZERO;		//(MarkD)
	m_PreviousSystemTime = pGlbSysTimer->GetCurrentSystemTimeTick100();	//(MarkD)
	m_RequestedTickCorrectionsHi = APPPQ_DEFAULT_ZERO;	//(MarkD)
	m_RequestedTickCorrectionsLo = APPPQ_DEFAULT_ZERO;	//(MarkD)
	m_PredictedTickRemainder = APPPQ_DEFAULT_ZERO;	//(MarkD)

	m_FirstRun = TRUE;	//MarkD

	m_pDataItem = NULL;

	// Reset the array of readings to Zero
	for (USHORT PPQIndex = APPPQ_DEFAULT_ZERO; PPQIndex < APPPQ_MAX_NUM_OF_READINGS; ++PPQIndex) {
		m_AnaloguePulseQueue[PPQIndex] = APPPQ_DEFAULT_ZERO;

	} // End of FOR

	m_csAnalPulsePPQ.lock();

	return (APPPQ_OK);

} // End of Member Function	

//****************************************************************************
/// To ensure the Pre Process Queue can operate correctly, the PPQ must be
/// Synchronised with the Analogue Input Card and System Tick. This member function
/// allows this synchronisation to take place. 
///
/// @param[in] inputCardTick - Analogue Input Card Tick
/// @param[in] systemTick	- System Tick
///
/// @return APPPQ_OK - Timestamped Reading added Successfully
/// 
//**************************************************************************** 
T_APPPQ_RETURN_VALUE CAnaloguePulsePPQ::SyncPPQ(const USHORT inputCardTick, const LONGLONG systemTick) {
	m_csAnalPulsePPQ.lock();

	m_PredictedAPClockTick = inputCardTick;
	m_MinCoverageTick = systemTick;

	//(MarkD)
	m_MaxCoverageTick = m_MinCoverageTick;
	//m_PreviousSystemTime = pGlbSysTimer->GetCurrentSystemTimeTick100();
	m_PreviousSystemTime = systemTick;
	m_PreviousPredictedAPClockTick = inputCardTick;
	m_PreviousAnaloguePulseInputTick = inputCardTick;

	m_FirstRun = TRUE;	//MarkD

	// Store the PPQ Information
	m_PPQInfo.m_InitialAITick = inputCardTick;
	m_PPQInfo.m_InitialMinSystemCoverage = systemTick;

	m_csAnalPulsePPQ.lock();

	return (APPPQ_OK);

} // End of Member Function									

//****************************************************************************
// GetDroppedReadingCount( void )
///
/// Get the number of dropped readings since the last power-on
///
/// @return The number of dropped readings
/// 
//**************************************************************************** 
ULONG CAnaloguePulsePPQ::GetDroppedReadingCount(void) {
	ULONG count;

	m_csAnalPulsePPQ.lock();
	count = m_PPQInfo.m_NumOfDroppedReadings;
	m_csAnalPulsePPQ.lock();

	return count;
}

//****************************************************************************
// GetInsertedReadingCount( void )
///
/// Get the number of readings that have been inserted since the last power-on
///
/// @return The number of inserted readings
/// 
//**************************************************************************** 
ULONG CAnaloguePulsePPQ::GetInsertedReadingCount(void) {
	ULONG count;

	m_csAnalPulsePPQ.lock();
	count = m_PPQInfo.m_NumOfAdditionalReadingInserted;
	m_csAnalPulsePPQ.lock();

	return count;
}

//****************************************************************************
// GetUnprocessedCoverage( void )
///
/// Get the amount of unprocessed coverage from the queue
///
/// @return The unprocessed coverage in the queue
/// 
//**************************************************************************** 
ULONG CAnaloguePulsePPQ::GetUnprocessedCoverage(void) {
	ULONG coverage = 0;

	m_csAnalPulsePPQ.lock();
	if (m_Rear >= m_Front)
		coverage = ((m_Rear - m_Front) * PPQC_SYSTEM_TICK_COVERAGE[m_AcquistionRate]) * 10;
	else
		coverage = (((APPPQ_MAX_NUM_OF_READINGS - m_Front) + m_Rear) * PPQC_SYSTEM_TICK_COVERAGE[m_AcquistionRate])
				* 10;
	m_csAnalPulsePPQ.lock();

	return coverage;
}

//****************************************************************************
/// 
///
/// @return State of PPQ
/// 
//**************************************************************************** 
UCHAR CAnaloguePulsePPQ::GetPPQOperationalState(void) {
	UCHAR state;

	m_csAnalPulsePPQ.lock();
	state = m_Status;
	m_csAnalPulsePPQ.lock();

	return state;
}

//****************************************************************************
/// 
///
/// @return Update time of PPQ
/// 
//**************************************************************************** 
LONGLONG CAnaloguePulsePPQ::GetPPQUpdateTime(void) {
	LONGLONG lastUpdate;

	m_csAnalPulsePPQ.lock();
	lastUpdate = m_MaxCoverageTick;
	m_csAnalPulsePPQ.lock();

	return lastUpdate;
}

//****************************************************************************
/// 
///
/// @return TRUE if Pre Process Queue Syncronised Successfully; otherwise FALSE
/// 
//**************************************************************************** 
BOOL CAnaloguePulsePPQ::IsPPQOperational(void) {
	BOOL QOperational = FALSE;

	m_csAnalPulsePPQ.lock();
	QOperational = static_cast<BOOL>(m_Status == PPQC_STATUS_OPERATIONAL);
	m_csAnalPulsePPQ.lock();

	return QOperational;
}

//****************************************************************************
/// 
///
/// @param[in] reading				- Reading to be Added
/// @param[in] analoguePulseInputTick - 
///
/// @return APPPQ_OK - Pre Process Queue Syncronised Successfully
/// 
//**************************************************************************** 
T_APPPQ_RETURN_VALUE CAnaloguePulsePPQ::AddTimeStampedReading(FLOAT reading, USHORT analoguePulseInputTick) {
	m_csAnalPulsePPQ.lock();

	// Calculate the Different between the Input Card Tick with the Predicted Input Card Tick
	SHORT tickDifference = CalculateAPTickDifference(analoguePulseInputTick);
//	const USHORT PPQ_NUMBER = 0;
//	USHORT difference = 0;

//	if( this->m_Rear > this->m_Front )
//	{
//		difference = this->m_Rear - this->m_Front;
//	}
//	else
//	{
//		difference = this->m_Front - this->m_Rear;
//	}

//	if( PPQ_NUMBER == m_Reference )
//	{
//	qDebug("TimeStamped Reading ->PPQ [%d], Predicted AI Tick: [%d], Actual AI Tick: [%d], Tick Difference: [%d]\n",
//										PPQ_NUMBER,m_PredictedAPClockTick, analoguePulseInputTick, tickDifference );
// } // End of IF

	// If required, scale the Tick Difference to 400HZ, determined by the clock tick rate
	// of the Input Card. ( i.e. Analogue Pulse Clock Rate = 200Hz )
	if (m_APCardTickRate != PPQC_APCARD_TICK_RATE_400HZ) {
		tickDifference *= PPQC_APCARD_TO_ANALOGCLKRATE_CNV[m_APCardTickRate];

	} // End of IF

	if (m_Status == PPQC_STATUS_AWAITING_SYNC) // is enable PPQ always called after resetPPQ?
			{
		m_PPQInfo.m_FirstTimestampedReadingAITick = analoguePulseInputTick;
		m_PPQInfo.m_FirstReadingTickDifference = tickDifference;

		//(MarkD)
		// m_MinCoverageTick is defined by the system time when the queue was synced
		// m_MaxCoverageTick is defaulted when synced, and only incremented when readings are added

		//tickDifference = APPPQ_DEFAULT_ZERO;				

		m_PPQInfo.m_MinCoverageAfterSync = m_MinCoverageTick;
		m_PPQInfo.m_PredictedAITickAfterSync = m_PredictedAPClockTick;

		// Set status to indicate that the Pre Process Queue has been synchronised
		m_Status = PPQC_STATUS_OPERATIONAL;

	} // End of IF

	// original code:
	/*
	 // Determine the action to be undertaken by analysising the tick difference against known values
	 if( tickDifference >= PPQC_APCARD_TICK_COVERAGE[m_AcquistionRate][PPQC_APCARD_TICK_RATE_400HZ] )
	 { 
	 //LOG_INFO(L"Additional Reading Added: Predicted AI Tick: %d, Actual AI Tick: %d, Tick Difference: %d\n",
	 //			m_PredictedAPClockTick, analoguePulseInputTick, tickDifference );
	 // The APCard tick has drifted by at least one whole tick period, therefore we need to add an
	 // additional reading together with the current reading. The additional reading added,
	 // will be calculated using the combine values of the previous and current reading. 
	 
	 // Add Additional Reading
	 AddReading( m_PreviousReading + ( ( reading - m_PreviousReading ) / APPPQ_TWO_READINGS ) ); 
	 
	 // Add Current Reading
	 AddReading( reading );
	 
	 ++m_PPQInfo.m_NumOfAdditionalReadingInserted;
	 
	 } 
	 else if ( tickDifference <= -( PPQC_APCARD_TICK_COVERAGE[m_AcquistionRate][PPQC_APCARD_TICK_RATE_400HZ] ) ) 
	 {
	 // The APCard tick is one time period less than the predicated clock tick, therefore we can 
	 // ignore the current reading, and increment the predicted clock tick according to the 
	 // Acqusition Rate of the Input Card.
	 //(removed MarkD)
	 //m_PredictedAPClockTick += PPQC_APCARD_TICK_COVERAGE[m_AcquistionRate][PPQC_APCARD_TICK_RATE_400HZ];
	 
	 ++m_PPQInfo.m_NumOfDroppedReadings;
	 } 
	 else
	 {
	 // The APCard Tick is within the tick period of the predicted clock tick
	 AddReading( reading );
	 
	 } // End of IF
	 */

	// (MarkD version)
	// Determine the action to be undertaken by analysising the tick difference against known values
	if (tickDifference >= PPQC_APCARD_TICK_COVERAGE[m_AcquistionRate][PPQC_APCARD_TICK_RATE_400HZ]) {
		// The APCard tick has got ahead by at least one whole tick period, therefore there is an extra 
		// reading supplied, and this reading should be dropped. However, the predicted tick period needs
		// to be incremented to catch up with the current board tick.
		// only action if true for APPQ_CORRECTION_REQ (10) times in row, as timestamps from data readings
		// aren't reliable in timing
		m_RequestedTickCorrectionsHi++;
		if (m_RequestedTickCorrectionsHi >= APPQ_CORRECTION_REQ) {
			m_PredictedAPClockTick += PPQC_APCARD_TICK_COVERAGE[m_AcquistionRate][m_APCardTickRate];
			m_PreviousPredictedAPClockTick += PPQC_APCARD_TICK_COVERAGE[m_AcquistionRate][m_APCardTickRate];
			++m_PPQInfo.m_NumOfDroppedReadings;
			m_RequestedTickCorrectionsHi = 0;	// reset to restart counting
		} else {
			AddReading(reading);	// treat as normal
		}

		// always reset any low correction requests if a high one is seen
		m_RequestedTickCorrectionsLo = 0;
	} else if (tickDifference <= -(PPQC_APCARD_TICK_COVERAGE[m_AcquistionRate][PPQC_APCARD_TICK_RATE_400HZ])) {
		// The APCard tick is at least one time period less than the predicted clock tick, 
		// therefore we need to add an extra reading which the card isn't going to supply.
		// The extra reading is an average of the previous and current reading.
		// We also add the current reading following this. 
		// Once the extra reading has been added, we need to decrement the predicted tick by one period
		// to get the system back in sync
		m_RequestedTickCorrectionsLo++;
		if (m_RequestedTickCorrectionsLo >= APPQ_CORRECTION_REQ) {
			// Add Additional Reading
			AddReading(reading);
//			AddReading( m_PreviousReading + ( ( reading - m_PreviousReading ) / APPPQ_TWO_READINGS ) ); 
			// Add Current Reading
			AddReading(reading);
			// correct the predicted tick by subtracting one period
			m_PredictedAPClockTick -= PPQC_APCARD_TICK_COVERAGE[m_AcquistionRate][m_APCardTickRate];
			m_PreviousPredictedAPClockTick -= PPQC_APCARD_TICK_COVERAGE[m_AcquistionRate][m_APCardTickRate];
			++m_PPQInfo.m_NumOfAdditionalReadingInserted;
			m_RequestedTickCorrectionsLo = 0;	// reset to restart counting
		} else {
			AddReading(reading);	// treat as normal
		}

		// always reset any high correction requests if a low one is seen
		m_RequestedTickCorrectionsHi = 0;
	} else {
		// The APCard Tick is within the tick period of the predicted clock tick
		AddReading(reading);
		m_RequestedTickCorrectionsHi = 0;	// reset count - not consecutive
		m_RequestedTickCorrectionsLo = 0;	// reset count - not consecutive

	} // End of IF

//	qDebug("Queue %d: %d items\n", m_Reference, difference);
	m_csAnalPulsePPQ.lock();

	return (APPPQ_OK);

} // End of Member Function	

/// Add a reading to the Digital Pre Process Queue 
T_APPPQ_RETURN_VALUE CAnaloguePulsePPQ::AddReading(FLOAT reading) {
	m_csAnalPulsePPQ.lock();

	T_APPPQ_RETURN_VALUE retValue = APPPQ_OK; // Member Function Return Value

	// Increment the Rear of the Queue
	++m_Rear;

	// Check and Handle Pre Process Queue Wrap
	if (m_Rear >= APPPQ_MAX_NUM_OF_READINGS) {
		m_Rear = APPPQ_DEFAULT_ZERO;

	} // End of IF

	// Check to determine if we are going to overwrite any data
	if (m_Rear == m_Front) {
		//qDebug("APPPQ - FATAL ERROR - DATA LOSS queue %d\n", m_Reference);
		//QString  strErrorMsg( QString   ::fromWCharArray("") );
		//strErrorMsg.asprintf( L"APPPQ - FATAL ERROR - DATA LOSS queue %d", m_Reference );
		//LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, strErrorMsg );
		retValue = APPPQ_FATAL_ERROR_DATA_LOSS;

	} // End of IF

	// Store the Current Reading as the previous reading, to be used if we need to 
	// insert an additional reading.
	m_PreviousReading = reading;

	// Store the Current Reading in the Queue, at the end of the Queue
	m_AnaloguePulseQueue[m_Rear] = reading;

	//( MarkD)
	// Increment Predicted Clock Tick according to the Acqusition rate and Input Card Tick Rate
	//m_PredictedAPClockTick += PPQC_APCARD_TICK_COVERAGE[ m_AcquistionRate ][ m_APCardTickRate ];

	// Increment the max system coverage according to the Acqusition Rate
	m_MaxCoverageTick += PPQC_SYSTEM_TICK_COVERAGE[m_AcquistionRate];

	m_csAnalPulsePPQ.lock();

	return (retValue);

} // End of Member Function									

/// Add a missed reading to the Analogue / Pulse Pre Process Queue
T_APPPQ_RETURN_VALUE CAnaloguePulsePPQ::AddMissedReading(void) {
//	QString  strErr = L"AddMissedReading";
////	strErr.asprintf(strErr, (int)numOfBlocksToWriteToPhysicalDisk);
//	LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_INFO, strErr);

	m_csAnalPulsePPQ.lock();
	T_APPPQ_RETURN_VALUE retValue;

	++m_PPQInfo.m_NumOfMissedReadings;

	retValue = (AddReading(m_PreviousReading));

	m_csAnalPulsePPQ.lock();

	return retValue;
} // End of Member Function 

/// Get a reading from the Pre Process Queue
T_APPPQ_RETURN_VALUE CAnaloguePulsePPQ::GetReading(FLOAT &reading, USHORT tickIncrement, BOOL firstRun) {
	m_csAnalPulsePPQ.lock();

	T_APPPQ_RETURN_VALUE retValue = APPPQ_GET_READING_FATAL_ERROR;

	// Check whether the existing reading can be used for the tick increment
	// required. 
	if (m_ItemCoverage >= tickIncrement) {
		m_ItemCoverage -= tickIncrement;
		if (firstRun == TRUE)	// avoid possibility of first data point being zero (from default)
		{
			retValue = APPPQ_READING_UPDATE_REQUIRED;
		} else {
			retValue = APPPQ_NO_UPDATE_REQUIRED;
		}
	} else {
		// Current Reading does not have the coverage required, increment to the
		// next reading and minus the current item coverage from the tick Increment
		tickIncrement -= m_ItemCoverage;

		// Increment the Front of the Queue by one
		IncrementFront(APPPQ_INCREMENT_BY_ONE);

		// Set the item coverage accoring the Acquisition Rate
		m_ItemCoverage = PPQC_SYSTEM_TICK_COVERAGE[m_AcquistionRate];

		// Check whether the new item has the coverage to fulfil the tickIncrement, if not
		// we can then calculate the required position in the Queue. 
		if (m_ItemCoverage >= tickIncrement) {
			m_ItemCoverage -= tickIncrement;
			retValue = APPPQ_READING_UPDATE_REQUIRED;
		} else {
			// Calculate the number of actual items we need to increment by, the calculation will always
			// round down, and must be taken care off using the MOD operator to determine the remainder. 
			USHORT numOfItemsToIncrement = static_cast<USHORT>(tickIncrement
					/ PPQC_SYSTEM_TICK_COVERAGE[m_AcquistionRate]);

			// Calculate the Remainder of the Above calculation, if Zero then we need to decrement the calculated
			// position, otherwise no adjustment is requried. A non zero value will be used to set the
			// item coverage of the calculated front position. 
			USHORT itemCoverageAdjustment = tickIncrement % PPQC_SYSTEM_TICK_COVERAGE[m_AcquistionRate];

			// Check whether the item Coverage Adjustment is zero, if so then we need to minus one
			// for the calculated Front Position, in order to take into account the current item. This
			// is similar to an array index starting at zero, increment the front position by 4 items,
			// means actually incrementing the number of items by 3( 0 to 3 ). In the case of the calculation
			// not equal to Zero, then we need to adjust the item coverage at the calculated front position. 
			if (APPPQ_DEFAULT_ZERO == itemCoverageAdjustment) {
				// Minus One from the calculation to ensure we count the current item as a valid reading.
				--numOfItemsToIncrement;

			} // End of IF

			// Set the Front Position of the Queue, to the calculated Position
			IncrementFront(numOfItemsToIncrement);

			// Set the Item Coverage, based on early calculations.
			if (APPPQ_DEFAULT_ZERO == itemCoverageAdjustment) {
				m_ItemCoverage = APPPQ_DEFAULT_ZERO;
			} else {
				m_ItemCoverage -= itemCoverageAdjustment;

			} // End of IF

			retValue = APPPQ_READING_UPDATE_REQUIRED;

		} // End of IF

	} // End of IF

	if (APPPQ_READING_UPDATE_REQUIRED == retValue) {
		reading = m_AnaloguePulseQueue[m_Front];

	} // End of IF 

	m_csAnalPulsePPQ.lock();

	return (retValue);

} // End of Member Function						

///< Get the Minimum System Tick Coverage
T_APPPQ_RETURN_VALUE CAnaloguePulsePPQ::GetMinSystemTickCoverage(LONGLONG &minCoverage) {
	minCoverage = m_MinCoverageTick;

	return (APPPQ_OK);

} // End of Member Function								

///< Get the Maximum System Tick Coverage
T_APPPQ_RETURN_VALUE CAnaloguePulsePPQ::GetMaxSystemTickCoverage(LONGLONG &maxCoverage) {
	maxCoverage = m_MaxCoverageTick;

	return (APPPQ_OK);

} // End of Member Function															

SHORT CAnaloguePulsePPQ::CalculateAPTickDifference(USHORT analoguePulseInputTick) {
	// MarkD version:
	SHORT APTickDifference = APPPQ_DEFAULT_ZERO; ///< Calculated Digital Input Tick Difference
	//LONG APTicksReceived = APPPQ_DEFAULT_ZERO;
	LONGLONG currentSystemTime = 0L;	// in 100Hz ticks
	LONGLONG elapsedSystemTime = 0L;
	USHORT elapsedCardTicks = APPPQ_DEFAULT_ZERO;

	// calculate number of input card ticks since last timestamped reading: 
	//if( analoguePulseInputTick < m_PreviousAnaloguePulseInputTick )	// if it's wrapped:
	//	APTicksReceived = PPQC_MAX_CLOCK_TICK + analoguePulseInputTick - m_PreviousAnaloguePulseInputTick; 
	//else	// normal case
	//	APTicksReceived = analoguePulseInputTick - m_PreviousAnaloguePulseInputTick;

	// calculate elapsed system time in 100Hz system ticks
	currentSystemTime = pGlbSysTimer->GetCurrentSystemTimeTick100();
	elapsedSystemTime = currentSystemTime - m_PreviousSystemTime;	// in 100Hz ticks

	// convert elapsed time to number of input card ticks at 400Hz
	elapsedCardTicks = (USHORT) (PPQC_SYSCLKRATE_TO_ANALOGCLKRATE_CNV * elapsedSystemTime);
	// if not at 400Hz, re-scale to the correct number of ticks (would not work reliably for AO, but doesn't matter)
	if (m_APCardTickRate != PPQC_APCARD_TICK_RATE_400HZ) {
		m_PredictedTickRemainder += elapsedCardTicks % PPQC_APCARD_TO_ANALOGCLKRATE_CNV[m_APCardTickRate];
		elapsedCardTicks = elapsedCardTicks / PPQC_APCARD_TO_ANALOGCLKRATE_CNV[m_APCardTickRate];
		if (m_PredictedTickRemainder >= PPQC_APCARD_TO_ANALOGCLKRATE_CNV[m_APCardTickRate]) {
			elapsedCardTicks++;
			m_PredictedTickRemainder -= PPQC_APCARD_TO_ANALOGCLKRATE_CNV[m_APCardTickRate];
		}
	}
	// calculate predicted card tick
	m_PredictedAPClockTick = m_PreviousPredictedAPClockTick + elapsedCardTicks;

	// Check to determine whether both the Input Card Tick and Predicted Tick have wrapped 
	if ((analoguePulseInputTick < m_PreviousAnaloguePulseInputTick)
			&& (m_PredictedAPClockTick < m_PreviousPredictedAPClockTick)) {
		// if both wrap, calculation is as if neither had wrapped
		APTickDifference = static_cast<SHORT>(analoguePulseInputTick - m_PredictedAPClockTick);
	}
	// Check to determine whether the Input Card tick (only) has wrapped 
	else if (analoguePulseInputTick < m_PreviousAnaloguePulseInputTick) {
		// Analogue/Pulse Input Clock has wrapped, adjust tick difference accordingly. 
		APTickDifference = static_cast<SHORT>(analoguePulseInputTick - m_PredictedAPClockTick + PPQC_MAX_CLOCK_TICK);
	} else if (m_PredictedAPClockTick < m_PreviousPredictedAPClockTick)	// Predicted Tick (only) wrapped
			{
		// Predicted Clock has wrapped, adjust tick difference accordingly. 
		APTickDifference = static_cast<SHORT>(analoguePulseInputTick - m_PredictedAPClockTick - PPQC_MAX_CLOCK_TICK);

	} else	// normal case - neither has wrapped
	{
		APTickDifference = static_cast<SHORT>(analoguePulseInputTick - m_PredictedAPClockTick);
	} // End of IF

	// update the saved states
	m_PreviousAnaloguePulseInputTick = analoguePulseInputTick;
	m_PreviousPredictedAPClockTick = m_PredictedAPClockTick;
	m_PreviousSystemTime = currentSystemTime;

	return (APTickDifference);

	// Original code:
	/*
	 SHORT APTickDifference = APPPQ_DEFAULT_ZERO;	///< Calculated Digital Input Tick Difference
	 
	 // Check to determine whether the Digital Input Clock has wrapped. 
	 if( analoguePulseInputTick < m_PredictedAPClockTick )
	 {
	 // Analogue/Pulse Input Clock has wrapped, adjust tick difference accordingly. 
	 APTickDifference 
	 = static_cast<SHORT>( PPQC_MAX_CLOCK_TICK - m_PredictedAPClockTick + analoguePulseInputTick );
	 }
	 else
	 {
	 // Digital Input Clock has NOT wrapped, calculate clock tick difference normally
	 APTickDifference = static_cast<SHORT>( analoguePulseInputTick - m_PredictedAPClockTick );
	 
	 } // End of IF
	 
	 return( APTickDifference );
	 */
} // End of Member Function		

T_APPPQ_RETURN_VALUE CAnaloguePulsePPQ::SetPosToBeginProcessing(LONGLONG systemTick) {
	FLOAT reading = 0;

	m_PPQInfo.m_SysTickToBeginProcess = systemTick;
	m_PPQInfo.m_SetPosTickIncrement = static_cast<USHORT>(systemTick - m_MinCoverageTick);

	// Locate the position in the queue for the initial tick to process. 
	GetReading(reading, static_cast<USHORT>(systemTick - m_MinCoverageTick),
	FALSE);

	return (APPPQ_OK);

} // End of Member Function	

void CAnaloguePulsePPQ::IncrementFront(USHORT incrementValue) {
	m_Front += incrementValue;

	// Check and Handle Pre Process Queue Wrap
	if (m_Front >= APPPQ_MAX_NUM_OF_READINGS) {
		//As Array size is 256,it is going beyond the limit and trying to access invalid memory. This leads to access violation.
		m_Front = (m_Front % APPPQ_MAX_NUM_OF_READINGS);

	} // End of IF 

} // End of Member Function	

void CAnaloguePulsePPQ::SavePPQInfoToFile(CStorage &PPQInfoFile) {

	m_PPQInfo.TracePPQInfoToFile(PPQInfoFile, GetType(), GetReference(), GetAcqusitionRate(), GetStatus());

} // End of Member Function


#pragma once

// CAsyncSocket
#include <Afxsock.h>

#include "PPQMessages.h"
#include "PPQCommon.h"

//#define PPQQAbstractSocket_ENABLED 1

// CPPQSocket command target

class CPPQSocket {
public:

	CPPQSocket();
	virtual ~CPPQSocket();

	static void CreateSocket();
	static void Connect();
	static void CloseSocket();

	static void SendEnablePPQMsg(T_PPQC_STATUS status, T_PPQC_QUEUE_TYPE type, USHORT reference,
			T_PPQC_ACQUSITION_RATE acqRate, T_PPQC_APCARD_TICK_RATE clockTickRate);

	static void SendSyncPPQMsg(USHORT reference, LONGLONG minSysCoverage, LONGLONG maxSysCoverage,
			T_PPQC_STATUS status);
	static void SendAddTimestampedReadingMsg(USHORT reference, USHORT lastPredictedAITick, USHORT lastActualAITick,
			SHORT lastTickDifference);

	static void SendAddReadingMsg(USHORT reference, USHORT rear, USHORT numOfReadings, FLOAT reading,
			LONGLONG maxSysCoverage);
	static void SendDisablePPQMsg(USHORT reference);

	static void SendGetReadingMsg(USHORT reference, USHORT front, USHORT numOfReadings);

	static void SendErrorMsg(USHORT reference, T_PPQUI_ERROR_CODE errorCode);

private:

	static CAsyncSocket *m_pSocket;
	static BYTE *m_pSendBuffer;
	static BYTE *m_pDataProcessingBuffer;

};

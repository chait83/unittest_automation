#ifndef _DIGITALDEMOCHANNEL_H
#define _DIGITALDEMOCHANNEL_H

class CDigitalDemoChannel {
public:

	CDigitalDemoChannel(void);
	virtual ~CDigitalDemoChannel(void);

private:

};
// End of Class Declaration

#endif // _DIGITALDEMOCHANNEL_H

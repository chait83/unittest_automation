/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	Pre-Process Queue
/// @n Filename:	DigitalPreProcessQueue.cpp
/// @n Description: --- Add File Description ---
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 29	Stability Project 1.24.1.3	7/2/2011 4:56:46 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 28	Stability Project 1.24.1.2	7/1/2011 4:38:14 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 27	Stability Project 1.24.1.1	3/17/2011 3:20:22 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 26	Stability Project 1.24.1.0	2/15/2011 3:02:58 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
// **************************************************************************

#include "DigitalPPQ.h"
#include "V6globals.h"
//#include "PPQManager.h"	//MarkD

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif

//****************************************************************************
// CDigitalPPQ( void )
///
/// ---Detailed Description of Member Function---
///
/// @return - No Return Value
///
//****************************************************************************
CDigitalPPQ::CDigitalPPQ(void) {
	QMutex * m_csDigitalPPQ;

	// Reset the Pre Process Queue to default state 
	ResetPPQ();

} // End of Constructor

//****************************************************************************
// ~CDigitalPPQ
///
/// ---Detailed Description of Member Function---
///
/// @return - No Return Value
///
//****************************************************************************
CDigitalPPQ::~CDigitalPPQ(void) {
	// Do Nothing
	//deletion of mutex not required

} // End of Destructor

//****************************************************************************
// GetLastResyncSystemTick( void )
///
/// Get the system tick that the Pre Process Queue was last resynced at
///
/// @return The system tick
/// 
//**************************************************************************** 
LONGLONG CDigitalPPQ::GetLastResyncSystemTick(void) {
	LONGLONG sysTick;
	m_csDigitalPPQ.lock();

	sysTick = m_LastSyncSystemTick;

	m_csDigitalPPQ.lock();

	return sysTick;
}

//****************************************************************************
// GetLastResyncDITick( void )
///
/// Get the I/O card tick that the Pre Process Queue was last synced at
///
/// @return The I/O card tick
/// 
//**************************************************************************** 
USHORT CDigitalPPQ::GetLastResyncDITick(void) {
	USHORT cardTick;
	m_csDigitalPPQ.lock();

	cardTick = m_LastDIClockTickAtResync;

	m_csDigitalPPQ.lock();

	return cardTick;
}

//****************************************************************************
// GetUnprocessedCoverage( void )
///
/// Get the amount of unprocessed coverage from the queue
///
/// @return The unprocessed coverage in the queue
/// 
//**************************************************************************** 
ULONG CDigitalPPQ::GetUnprocessedCoverage(void) {
	ULONG coverage = 0;

	m_csDigitalPPQ.lock();
	coverage = m_DigitalQueue[m_Rear].systemTickCoverage * 10;
	m_csDigitalPPQ.lock();

	return coverage;
}

//****************************************************************************
// T_DPPQ_RETURN_VALUE EnablePPQ( void )
///
/// Enable the Pre Process Queue 
///
/// @return ---Brief Desciption of Return Value---
/// 
//**************************************************************************** 
T_DPPQ_RETURN_VALUE CDigitalPPQ::EnablePPQ(T_PPQC_DIGITAL_PPQ_TYPE type, T_PPQC_ACQUSITION_RATE acqusitionRate) {
	m_Type = type;
	m_AcquistionRate = acqusitionRate;
	m_Status = PPQC_STATUS_AWAITING_SYNC;

	return (DPPQ_OK);

} // End of Member Function

//****************************************************************************
// T_DPPQ_RETURN_VALUE DisablePPQ( void )
///
/// Disable the Pre Process Queue 
///
/// @return ---Brief Desciption of Return Value---
/// 
//****************************************************************************	
T_DPPQ_RETURN_VALUE CDigitalPPQ::DisablePPQ(void) {
	m_Status = PPQC_STATUS_DISABLED;

	return (DPPQ_OK);

} // End of Member Function							

//****************************************************************************
// T_DPPQ_RETURN_VALUE ResetPPQ( void )
///
/// Resets the Pre Process Queue to a known default state 
///
/// @return ---Brief Desciption of Return Value---
/// 
//****************************************************************************	
T_DPPQ_RETURN_VALUE CDigitalPPQ::ResetPPQ(void) {
	m_Rear = DPPQ_DEFAULT_ZERO;
	m_Front = DPPQ_DEFAULT_ZERO;
	m_BaseDISyncTick = DPPQ_DEFAULT_ZERO;
	m_BaseSystemSyncTick = DPPQ_DEFAULT_ZERO;
	m_AccumulativeDITick = DPPQ_DEFAULT_ZERO;
	m_LastDIClockTick = DPPQ_DEFAULT_ZERO;
	m_LastDISyncTick = DPPQ_DEFAULT_ZERO;
	m_LastSyncSystemTick = DPPQ_DEFAULT_ZERO;
	m_LastDIClockTickAtResync = DPPQ_DEFAULT_ZERO;
	m_CardClockError = DPPQ_DEFAULT_ZERO;

	m_Type = PPQC_DIGITAL_SLOT_1;
	m_AcquistionRate = PPQC_1HZ;
	m_Status = PPQC_STATUS_DISABLED;

	m_RearWrapped = FALSE;	// MarkD

	for (USHORT index = DPPQ_DEFAULT_ZERO; index < DPPQ_MAX_NUM_OF_READINGS; ++index) {
		m_DigitalQueue[index].reading = DPPQ_DEFAULT_ZERO;
		m_DigitalQueue[index].systemTickCoverage = DPPQ_DEFAULT_ZERO;

	} // End of FOR

	// Reset Cached data item pointers 
	m_pCardDataItem = NULL;
	for (int digIndex = 0; digIndex < MAX_DIG_IO_PER_CARD; digIndex++) {
		m_pChannelDataItem[digIndex] = NULL;
		m_pDigCMMConfig[digIndex] = NULL;
	}
	return (DPPQ_OK);

} // End of Member Function

//****************************************************************************
// T_PPQ_RETURN_VALUE SyncPPQ( USHORT inputCardTick, LONGLONG systemTick )
///
/// ---Detailed Description of Member Function---
/// Synchronise the Queue with the Input Card Ticks and System Ticks
///
/// @param[in] 	inputCardTick - Brief Desciption in param
/// @param[in]	systemTick	- Brief Desciption in out param
///
/// @return ---Brief Desciption of Return Value---
/// 
//**************************************************************************** 
T_DPPQ_RETURN_VALUE CDigitalPPQ::SyncPPQ(USHORT inputCardTick, LONGLONG systemTick) {
	m_AccumulativeDITick = static_cast<LONGLONG>(inputCardTick * PPQC_DICLKRATE_TO_SYSCLKRATE_CNV);
	//m_AccumulativeDITick += static_cast<LONGLONG>( inputCardTick * PPQC_DICLKRATE_TO_SYSCLKRATE_CNV );
	//m_AccumulativeDITick += ( CalculateDITickDifference( inputCardTick ) * PPQC_DICLKRATE_TO_SYSCLKRATE_CNV );

	m_BaseDISyncTick = m_AccumulativeDITick;
	m_BaseSystemSyncTick = systemTick;
	m_LastSyncSystemTick = systemTick;
	m_LastDIClockTick = inputCardTick;
	m_LastDISyncTick = inputCardTick;
	m_LastDIClockTickAtResync = inputCardTick;

	m_DITickAndSysTickDifference = m_BaseDISyncTick - m_BaseSystemSyncTick;

	qDebug("(SyncPPQ) m_AccumulativeDITick = %d \n", (int) m_AccumulativeDITick);
	qDebug("(SyncPPQ) m_DITickAndSysTickDifference = %d \n", (int) m_DITickAndSysTickDifference);
	qDebug("(SyncPPQ) systemTick = %d \n", (int) systemTick);
	qDebug("(SyncPPQ) inputCardTick = %d \n", (int) inputCardTick);

	// Set the Pre Process Queue to indicate it is operational
	//m_Status = PPQC_STATUS_OPERATIONAL;	// wait till first data is obtained before doing this

	return (DPPQ_OK);

} // End of Member Function

//****************************************************************************
// LONG CalculateDITickDifference( USHORT digitalInputTick )
///
/// Calculate the difference between this the last known digital input tick 
/// (when a reading can in or from a periodic sync every 7 mins approx )
/// and the current tick reading
///
/// @param[in] digitalInputTick - Current digital inpuit card tick in DI input card ticks (1/50)
///
/// @return tick differemce between old and current in Digital crad ticks (1/50)
/// 
//****************************************************************************
LONG CDigitalPPQ::CalculateDITickDifference(USHORT digitalInputTick) {
	LONG DITickDifference = DPPQ_DEFAULT_ZERO; // Calculated Digital Input Tick Difference

	// Check to determine whether the Digital Input Clock has wrapped. 
	//MarkD	
	// as m_LastDIClockTick could wrap before digitalInputTick does, we need to test for either one wrapping first
	// could be wrap of digitalInputTick before m_LastDIClockTick, 
	// or slight advance of m_LastDIClockTick over digitalInputTick due to clock difference and delays
	// if calculated tick difference is very large, it's a slight advance of m_LastDIClockTick 		

	if (digitalInputTick < m_LastDIClockTick) {
		DITickDifference = (PPQC_MAX_CLOCK_TICK - m_LastDIClockTick) + digitalInputTick; // Digital Input Clock has wrapped, adjust tick difference accordingly. 
		if (DITickDifference > (PPQC_MAX_CLOCK_TICK / 2)) // if not due to wrap, this will be very large	
				{
			DITickDifference -= PPQC_MAX_CLOCK_TICK;
			// mismatch will never get this high, so it indicates digitalInputTick running behind m_LastDIClockTick
		}
	} else // wrap of m_LastDIClockTick first, or advance of digitalInputTick ahead of m_LastDIClockTick
	{
		DITickDifference = (digitalInputTick - m_LastDIClockTick); // Digital Input Clock has NOT wrapped, calculate clock tick difference normally
		if (DITickDifference > (PPQC_MAX_CLOCK_TICK / 2)) // if due to m_LastDIClockTick wrap, this will be very large	
				{
			DITickDifference -= PPQC_MAX_CLOCK_TICK;
			// mismatch will never get this high, so it indicates m_LastDIClockTick wrapped before digitalInputTick
			//NOTE - unless running in debug, when re-start of firmware will pick up any value board tick
			// this could also occur if software restarts itself, or reset button is pressed
		}

	}

	//qDebug("(CalculateDITickDifference) digitalInputTick = %d \n", (int) digitalInputTick );
	//qDebug("(CalculateDITickDifference) m_LastDIClockTick = %d \n", (int) m_LastDIClockTick );
	//qDebug("(CalculateDITickDifference) DITickDifference = %d \n", (int) DITickDifference );

	return ((LONG) DITickDifference);

} // End of Member Function

//****************************************************************************
// T_DPPQ_RETURN_VALUE ReSyncTicks( USHORT digitalInputTick, LONGLONG systemTick )
///
/// ---Detailed Description of Member Function---
///
/// @param[in] digitalInputTick - Brief Desciption in param
/// @param[in] systemTick	- Brief Desciption in out param
///
/// @return ---Brief Desciption of Return Value---
/// 
//****************************************************************************
T_DPPQ_RETURN_VALUE CDigitalPPQ::ReSyncPPQ(USHORT digitalInputTick, LONGLONG systemTick) {

	//m_pAPPQ = CPPQManager::GetHandle();	//MarkD

	m_csDigitalPPQ.lock();

	// Store digitalInputTick and systemTick
	m_LastDIClockTickAtResync = digitalInputTick;
	m_LastSyncSystemTick = systemTick;

	//LONGLONG	maxAPPQCoverage;
	//m_pAPPQ->GetMaxSystemAPPQTickCoverage( maxAPPQCoverage );
	//qDebug("(ReSyncPPQ) maxAPPQCoverage = %d \n", (int) maxAPPQCoverage );

	//qDebug("(ReSyncPPQ) m_DigitalQueue[%d].systemTickCoverage = %d \n", (int) m_Rear, (int) m_DigitalQueue[m_Rear].systemTickCoverage );
	//qDebug("(ReSyncPPQ) m_AccumulativeDITick = %d \n", (int) m_AccumulativeDITick );
	//qDebug("(ReSyncPPQ) Dig maxCoverage = %d \n", (int) (m_AccumulativeDITick - m_DITickAndSysTickDifference) );

	//qDebug("(ReSyncPPQ) m_LastSyncSystemTick = %d \n", (int) systemTick );
	//qDebug("(ReSyncPPQ) m_LastDIClockTickAtResync = %d \n", (int) digitalInputTick );

	//LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, L"DIGITAL RESYNC");		

	//m_Status = PPPQ_STATUS_RESYNC;

	m_csDigitalPPQ.lock();

	return (DPPQ_OK);

} // End of Member Function

//****************************************************************************
// T_DPPQ_RETURN_VALUE AddReading( USHORT reading, USHORT digitalInputTick )
///
/// ---Detailed Description of Member Function---
///
/// @param[in] reading		- Brief Desciption in param
/// @param[in] digitalInputTick - Brief Desciption in out param
///
/// @return ---Brief Desciption of Return Value---
/// 
//****************************************************************************
T_DPPQ_RETURN_VALUE CDigitalPPQ::AddReading(USHORT reading, USHORT digitalInputTick) {
	m_csDigitalPPQ.lock();

	T_DPPQ_RETURN_VALUE retValue = DPPQ_OK; // Member Function Return Value

	//MarkD:
	// calculate systemtick relating to this digitalInputTick based on advance since last sync
	SHORT DITickDifference = DPPQ_DEFAULT_ZERO;
	LONGLONG currentSystemTick = 0;

	//qDebug("(AddReading) digitalInputTick = %d \n", (int) digitalInputTick );

	//LONGLONG	coverageNow;
	//GetMaxSystemTickCoverage( coverageNow );
	//qDebug("(AddReading) MaxCoverage before = %d \n", (int) coverageNow );

	//@todo: consider race hazards
	if (digitalInputTick < m_LastDIClockTickAtResync)	// must have wrapped - tick only goes forwards
			{
		DITickDifference = (PPQC_MAX_CLOCK_TICK - m_LastDIClockTickAtResync) + digitalInputTick;
		// Digital Input Clock has wrapped, adjust tick difference accordingly. 
	} else	// no wrap
	{
		DITickDifference = digitalInputTick - m_LastDIClockTickAtResync;
		// Digital Input Clock has NOT wrapped, calculate clock tick difference normally
	}

	currentSystemTick = m_LastSyncSystemTick + (DITickDifference * PPQC_DICLKRATE_TO_SYSCLKRATE_CNV);

	//qDebug("(AddReading) currentSystemTick = %d \n", (int) currentSystemTick );

	// increase coverage of the old tick:
	long coverage = currentSystemTick + m_DITickAndSysTickDifference - m_AccumulativeDITick;

	//qDebug("(AddReading) coverage = %d \n", (int) coverage );

	m_DigitalQueue[m_Rear].systemTickCoverage += coverage;	// MarkD

	//if( m_DigitalQueue[m_Rear].systemTickCoverage < 0 )
	//	m_DigitalQueue[m_Rear].systemTickCoverage = 0;	// don't permit negative coverage?

	//qDebug("(AddReading) m_DigitalQueue[%d].systemTickCoverage = %d \n", (int) m_Rear, (int) m_DigitalQueue[m_Rear].systemTickCoverage );

	m_AccumulativeDITick += coverage;

	//GetMaxSystemTickCoverage( coverageNow );
	//qDebug("(AddReading) MaxCoverage after = %d \n", (int) coverageNow );

	m_LastDIClockTick += (float) coverage / PPQC_DICLKRATE_TO_SYSCLKRATE_CNV;
	if (m_LastDIClockTick >= PPQC_MAX_CLOCK_TICK)
		m_LastDIClockTick -= PPQC_MAX_CLOCK_TICK;

	// now increment pointer and set new coverage to zero:

	// Increment the Rear of the Queue
	++m_Rear;

	// Check and adjust for Pre Process Queue Wrap 
	if (m_Rear >= DPPQ_MAX_NUM_OF_READINGS) {
		m_Rear = DPPQ_DEFAULT_ZERO;
		m_RearWrapped = TRUE;
	} // End of IF

	// Check to ensure we are not overwriting the head item 
	if (m_Rear == m_Front) {
		qDebug("DPPQ - FATAL ERROR - DATA LOSS\n");
        LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, "DPPQ - FATAL ERROR - DATA LOSS");
		retValue = DPPQ_FATAL_ERROR_DATA_LOSS;

	} // End of IF

	// Add Reading to the rear of the Pre Process Queue
	m_DigitalQueue[m_Rear].reading = reading;

	// Default the system coverage to Zero
	//MarkD: restarts coverage with this value at zero time
	m_DigitalQueue[m_Rear].systemTickCoverage = DPPQ_DEFAULT_ZERO;

	// Set the Pre Process Queue to indicate it is operational
	m_Status = PPQC_STATUS_OPERATIONAL;

	m_csDigitalPPQ.lock();

	return (retValue);

} // End of Member Function

//****************************************************************************
// T_DPPQ_RETURN_VALUE GetReading( USHORT &reading, USHORT tickIncrement )
///
/// ---Detailed Description of Member Function---
///
/// @param[in,out] reading - Brief Desciption in param
/// @param[in]	tickIncrement - Brief Desciption in out param
///
/// @return ---Brief Desciption of Return Value---
/// 
//****************************************************************************
T_DPPQ_RETURN_VALUE CDigitalPPQ::GetReading(USHORT &reading, LONG tickIncrement) {
	m_csDigitalPPQ.lock();

	T_DPPQ_RETURN_VALUE retValue = DPPQ_NO_READING_AVAILABLE;

	//MarkD: if there is no reading available, better to return the current (latest) reading
	// rather than leave it to default zero. This should permit timestamp adjustments without
	// glitches to zero.
	reading = m_DigitalQueue[m_Front].reading; // establish a suitable default

	/*if( ((m_DigitalQueue[m_Front].systemTickCoverage % 20) == 0) || ((m_DigitalQueue[m_Front].systemTickCoverage % 19) == 0) 
	 || (m_DigitalQueue[m_Front].systemTickCoverage < 25) )
	 {
	 qDebug("(GetReading) m_DigitalQueue[%d].systemTickCoverage = %d \n", (int) m_Front, (int) m_DigitalQueue[m_Front].systemTickCoverage );
	 //qDebug("(GetReading) m_Front = %d \n", (int) m_Front );
	 }*/

	//MarkD
	// Check whether the tick required falls within the current queue item
	if (m_DigitalQueue[m_Front].systemTickCoverage >= tickIncrement) {
		// Return the reading of the Current Queue Item
		m_DigitalQueue[m_Front].systemTickCoverage -= tickIncrement;
		reading = m_DigitalQueue[m_Front].reading;

		retValue = DPPQ_NO_UPDATE_REQUIRED;
	} else {
		// Loop until we find the reading for the associated tick, or
		// until no more items are available to be checked. 

		BOOL keepLooping = TRUE;

		while (keepLooping == TRUE) {
			// MarkD: don't allow m_Front to get ahead of data
			if ((m_Front < m_Rear) || (m_RearWrapped == TRUE)) {
				// Decrement the tick increment by the system tick coverage
				tickIncrement -= m_DigitalQueue[m_Front].systemTickCoverage;
				// Increment the Head item, and check for wrap
				++m_Front;
				if (m_Front >= DPPQ_MAX_NUM_OF_READINGS)
					m_RearWrapped = FALSE;
				m_Front %= DPPQ_MAX_NUM_OF_READINGS;
			}

			// Check the head item in the queue to determine if the reading is valid
			// for the tick required. 
			//MarkD: this could miss a state change, if it's tick coverage is less than
			// tickIncrement
			if ((m_DigitalQueue[m_Front].systemTickCoverage >= tickIncrement)) {
				reading = m_DigitalQueue[m_Front].reading;
				m_DigitalQueue[m_Front].systemTickCoverage -= tickIncrement;
				retValue = DPPQ_READING_UPDATE_REQUIRED;
				keepLooping = FALSE;
			}

			//MarkD: if there was no coverage on this pass but m_Front is already as high as possible,
			// do not attempt any more runs
			if ((m_Front >= m_Rear) && (m_RearWrapped == FALSE) && (keepLooping == TRUE)) {
				// Cannot increment m_Front any more, so break instead
				retValue = DPPQ_NO_READING_AVAILABLE;
				keepLooping = FALSE;
				// consider zeroing any coverage, as coming here implies tickIncrement is in the future
				// we will return a value anyway, so least error is introduced by zeroing coverage
				// since coverage is signed, it is possible to decrement coverage into a negative number
				m_DigitalQueue[m_Front].systemTickCoverage -= tickIncrement;
				//m_DigitalQueue[m_Front].systemTickCoverage = 0;	// zero the coverage
				qDebug("(GetReading) m_DigitalQueue[%d].systemTickCoverage after decrement = %d \n", (int) m_Front,
						(int) m_DigitalQueue[m_Front].systemTickCoverage);

			} // End of IF

		} // End of WHILE

	} // End of IF

	m_csDigitalPPQ.lock();

	return (retValue);

} // End of Member Function

//****************************************************************************
// T_DPPQ_RETURN_VALUE SetLastReadingCoverage( LONGLONG systemTick )
///
/// ---Detailed Description of Member Function---
///
/// @param[in] systemTick - Brief Desciption in param
///
/// @return ---Brief Desciption of Return Value---
/// 
//****************************************************************************
T_DPPQ_RETURN_VALUE CDigitalPPQ::SetLastReadingCoverage(LONGLONG systemTick) {
	m_csDigitalPPQ.lock();

	//BOOL traceTick = FALSE; //MarkD

	long coverage = systemTick + m_DITickAndSysTickDifference - m_AccumulativeDITick;

	//qDebug("(SetLastReadingCoverage) coverage = %d \n", (int) coverage );

	//MarkD
	//qDebug(" m_LastDIClockTick before update (SetLast) = %d \n", (int) m_LastDIClockTick );	//MarkD
	//qDebug("(SetLastReadingCoverage)systemTick = %d\n", (int) systemTick );
	//qDebug(" m_DITickAndSysTickDifference = %d\n", (int) m_DITickAndSysTickDifference );
	//qDebug(" coverage = %d\n", coverage );
	//qDebug(" AccumulativeDITick = %d\n", (int) m_AccumulativeDITick );
	//qDebug(" BEFORE LRC: m_DigitalQueue[m_Rear].systemTickCoverage = %d\n", m_DigitalQueue[m_Rear].systemTickCoverage );

	//if( coverage < 0 )
	//	qDebug("(SetLastReadingCoverage) coverage = %d\n", coverage );

	// we don't want to decrement system coverage, so limit negatives to zero.
	if (coverage < 0)
		coverage = 0;

	//if( m_DigitalQueue[m_Rear].systemTickCoverage > 300 )
	//{
	//	qDebug("(SetLastReadingCoverage) coverage = %d\n", coverage );
	//	qDebug("(SetLastReadingCoverage) m_DigitalQueue[%d].systemTickCoverage = %d \n", (int) m_Rear, (int) m_DigitalQueue[m_Rear].systemTickCoverage );
	//}
	//else 
	//if( coverage > 200 )
	//	qDebug("(SetLastReadingCoverage) coverage = %d\n", coverage );

	m_DigitalQueue[m_Rear].systemTickCoverage += coverage;	// MarkD

	//qDebug("(SetLastReadingCoverage) m_DigitalQueue[%d].systemTickCoverage = %d \n", (int) m_Rear, (int) m_DigitalQueue[m_Rear].systemTickCoverage );
	//qDebug("(SetLastReadingCoverage) m_Rear = %d \n", (int) m_Rear );

	//if( m_DigitalQueue[m_Rear].systemTickCoverage < 0 )	// MarkD
	//	m_DigitalQueue[m_Rear].systemTickCoverage = 0;

	m_AccumulativeDITick += coverage;

	m_LastDIClockTick += (float) coverage / PPQC_DICLKRATE_TO_SYSCLKRATE_CNV;
	if (m_LastDIClockTick >= PPQC_MAX_CLOCK_TICK)
		m_LastDIClockTick -= PPQC_MAX_CLOCK_TICK;

	//m_Status = PPQC_STATUS_OPERATIONAL;	// wait till first data is obtained

	m_csDigitalPPQ.lock();

	return (DPPQ_OK);

} // End of Member Function

//****************************************************************************
// T_DPPQ_RETURN_VALUE SetPosToBeginProcessing( LONGLONG systemTick )
///
/// ---Detailed Description of Member Function---
///
/// @param[in] systemTick - Brief Desciption in param
///
/// @return ---Brief Desciption of Return Value---
/// 
//****************************************************************************
T_DPPQ_RETURN_VALUE CDigitalPPQ::SetPosToBeginProcessing(LONGLONG systemTick) {
	USHORT reading = 0;

	m_csDigitalPPQ.lock();

	//LONG	diff = systemTick - m_BaseSystemSyncTick;

	// Locate the position in the queue for the initial tick to process. 
	//MarkD send a long, not USHORT? Doesn't really matter as minCoverage is sent, which
	// will normally (perhaps always) be a low number - not on config downloads?
	//GetReading( reading, static_cast<USHORT>( systemTick - m_BaseSystemSyncTick ) );
	//GetReading( reading, static_cast<LONG>( systemTick - m_BaseSystemSyncTick ) );
	//MarkD: start getting readings 0.5S later to avoid glitch
	//GetReading( reading, static_cast<LONG>( (systemTick + 50) - m_BaseSystemSyncTick ) );
	//MarkD: 
	m_Front = m_Rear; // force front of queue - any old data will be lost
	//m_DigitalQueue[m_Rear].systemTickCoverage = DPPQ_DEFAULT_ZERO;	// zero the current coverage
	m_DigitalQueue[m_Rear].systemTickCoverage = m_AccumulativeDITick - m_DITickAndSysTickDifference - systemTick;// coverage is max minus min

	//qDebug("(SetPosToBeginProcessing) m_DITickAndSysTickDifference = %d \n", (int) m_DITickAndSysTickDifference );	
	//qDebug("(SetPosToBeginProcessing) m_AccumulativeDITick = %d \n", (int) m_AccumulativeDITick );
	//qDebug("(SetPosToBeginProcessing) systemTick = %d \n", (int) systemTick );
	//qDebug("(SetPosToBeginProcessing) m_DigitalQueue[%d].systemTickCoverage (m_Rear) = %d \n", (int) m_Rear, (int) m_DigitalQueue[m_Rear].systemTickCoverage );
	//qDebug("(SetPosToBeginProcessing) m_DigitalQueue[%d].systemTickCoverage (m_Front) = %d \n", (int) m_Front, (int) m_DigitalQueue[m_Front].systemTickCoverage );
	//qDebug("(SetPosToBeginProcessing) (max coverage) = %d \n", (int) (m_AccumulativeDITick - m_DITickAndSysTickDifference) );
	//qDebug("(SetPosToBeginProcessing) m_Front = %d \n", (int) m_Front );

	m_csDigitalPPQ.lock();

	return (DPPQ_OK);

} // End of Member Function

//****************************************************************************
// T_DPPQ_RETURN_VALUE GetMinSystemTickCoverage( LONGLONG &minCoverag )
///
/// Get the Minimum System Tick Coverage
///
/// @param[in,out] minCoverage - Brief Desciption in param
///
/// @return ---Brief Desciption of Return Value---
/// 
//****************************************************************************
T_DPPQ_RETURN_VALUE CDigitalPPQ::GetMinSystemTickCoverage(LONGLONG &minCoverage) {
	minCoverage = m_BaseSystemSyncTick;	// system time when first sync occurred

	//qDebug("(GetMinSystemTickCoverage) minCoverage = %d \n", (int) minCoverage );

	return (DPPQ_OK);

} // End of Member Function

//****************************************************************************
// T_DPPQ_RETURN_VALUE GetMaxSystemTickCoverage( LONGLONG &maxCoverage )
///
/// Get the Maximum System Tick Coverage
///
/// @param[in] maxCoverage - Brief Desciption in param
///
/// @return ---Brief Desciption of Return Value---
/// 
//****************************************************************************
T_DPPQ_RETURN_VALUE CDigitalPPQ::GetMaxSystemTickCoverage(LONGLONG &maxCoverage) {
	m_csDigitalPPQ.lock();

	maxCoverage = m_AccumulativeDITick - m_DITickAndSysTickDifference;

	//if( ((maxCoverage % 100) == 0) || ((maxCoverage % 101) == 0) )
	//if( (maxCoverage % 9) == 0 )
	//if( ((maxCoverage/1000)%10==0) )
	//	qDebug("(Digital GetMaxSystemTickCoverage) maxCoverage = %d \n", (int) maxCoverage );

	m_csDigitalPPQ.lock();

	return (DPPQ_OK);

} // End of Member Function

void CDigitalPPQ::SavePPQInfoToFile(CStorage &PPQInfoFile) {

	m_DigitalPPQInfo.TracePPQInfoToFile(PPQInfoFile, m_Type, m_AcquistionRate, m_Status);

} // End of Member Function

#ifndef _ANALOGUEPULSEPPQ_H
#define _ANALOGUEPULSEPPQ_H

#include "PPQCommon.h"

#include "AnaloguePulsePPQInfo.h"
#include "DataItemBase.h"

const USHORT APPPQ_DEFAULT_ZERO = 0;		///< Default Zero
//const USHORT APPPQ_BUFFER_SIZE		= 1024;	///< Size of the buffer for the queue to use in bytes
const USHORT APPPQ_BUFFER_SIZE = 2048;		///< Size of the buffer for the queue to use in bytes
const USHORT APPPQ_TWO_READINGS = 2;		///< Number of Readings to divide by to calculate additional reading

const USHORT APPPQ_INCREMENT_BY_ONE = 1;		///< Increment value of One

const USHORT APPQ_CORRECTION_REQ = 10;		///< (MarkD) number of times correction requests must be seen

/// Number of Readings based on the specified buffer and size of a single reading 
const USHORT APPPQ_MAX_NUM_OF_READINGS = APPPQ_BUFFER_SIZE / sizeof(FLOAT);

/// Return Values for CAnaloguePulsePPQ Member Functions, used to describe the type of 
/// success or failure.
/// 
typedef enum {
	APPPQ_OK,
	APPPQ_GET_READING_FATAL_ERROR,
	APPPQ_NO_UPDATE_REQUIRED,
	APPPQ_READING_UPDATE_REQUIRED,
	APPPQ_NO_COVERAGE_AVAILABLE,
	APPPQ_FATAL_ERROR_DATA_LOSS

} T_APPPQ_RETURN_VALUE;

//**Class*********************************************************************
///
/// @brief --- Brief Description --- 
/// 
/// --- Detailed Description --- 
///
//****************************************************************************
class CAnaloguePulsePPQ {
public:

	/// Constructor
	CAnaloguePulsePPQ(void);

	/// Destructor
	virtual ~CAnaloguePulsePPQ(void);

	/// Enable the Pre Process Queue for Operation									
	T_APPPQ_RETURN_VALUE EnablePPQ(const T_PPQC_QUEUE_TYPE type, const USHORT reference,
			const T_PPQC_ACQUSITION_RATE acqusitionRate, const T_PPQC_APCARD_TICK_RATE clockTickRate);

	/// Synchronise the Queue with the Input Card Ticks and System Ticks
	T_APPPQ_RETURN_VALUE SyncPPQ(const USHORT inputCardTick, const LONGLONG systemTick);

	/// Disable the Pre Process Queue 
	T_APPPQ_RETURN_VALUE DisablePPQ(void);

	/// Reset the Pre Process Queue
	T_APPPQ_RETURN_VALUE ResetPPQ(void);

	/// Add a reading to the Pre Process Queue with the Input Card Tick( timestamp )
	T_APPPQ_RETURN_VALUE AddTimeStampedReading(FLOAT reading, USHORT analoguePulseInputTick);

	/// Add a reading to the Analogue / Pulse Pre Process Queue 
	T_APPPQ_RETURN_VALUE AddReading(FLOAT reading);

	/// Add a missed reading to the Analogue / Pulse Pre Process Queue
	T_APPPQ_RETURN_VALUE AddMissedReading(void);

	/// Set Initial System Tick to begin processing
	T_APPPQ_RETURN_VALUE SetPosToBeginProcessing(LONGLONG systemTick);

	/// Get a reading from the Pre Process Queue
	T_APPPQ_RETURN_VALUE GetReading(FLOAT &reading, USHORT tickIncrement, BOOL firstRun);

	/// Get the Minimum System Tick Coverage
	T_APPPQ_RETURN_VALUE GetMinSystemTickCoverage(LONGLONG &minCoverage);

	/// Get the Maximum System Tick Coverage
	T_APPPQ_RETURN_VALUE GetMaxSystemTickCoverage(LONGLONG &maxCoverage);

	/// Get the Current Status of the Pre Process Queue
	T_PPQC_STATUS GetStatus(void) {
		return m_Status;
	}

	/// Get the Pre Process Queue Type
	T_PPQC_QUEUE_TYPE GetType(void) {
		return m_Type;
	}

	/// Get the Pre Process Queue Reference
	USHORT GetReference(void) {
		return m_Reference;
	}

	/// Get the Acqusition Rate of the Pre Process Queue
	T_PPQC_ACQUSITION_RATE GetAcqusitionRate(void) {
		return m_AcquistionRate;
	}

	BOOL GetFirstRun(void) {
		return m_FirstRun;
	} //MarkD
	void ResetFirstRun(void) {
		m_FirstRun = FALSE;
	} //MarkD

	/// 
	void SavePPQInfoToFile(CStorage &PPQInfoFile);

	BOOL IsPPQOperational(void);
	LONGLONG GetPPQUpdateTime(void);
	UCHAR GetPPQOperationalState(void);
	ULONG GetDroppedReadingCount(void);
	ULONG GetInsertedReadingCount(void);
	ULONG GetUnprocessedCoverage(void);

public:

	// @todo AK, optimise this in Phase 2, currently high risk to refactor this code
	CDataItem *m_pDataItem;					///< Cached data item pointer

private:

	// --- Private Member Functions --- //

	/// Calculates the difference between the Predicted APCard tick and current APCard tick
	SHORT CalculateAPTickDifference(USHORT analoguePulseInputTick);

	/// Increment Front of Queue by specified amount and handle queue wrap
	void CAnaloguePulsePPQ::IncrementFront(USHORT incrementValue);

	// --- Private Member Variables --- // 
	QMutex m_csAnalPulsePPQ;					///< Critical Section for Thread Safe Operation

	T_PPQC_QUEUE_TYPE m_Type;					///< Queue Type in relation to Analogue, Hi-Pulse or Lo-Pulse
	USHORT m_Reference;	///< Queue Reference for use with the Data Item Table
	T_PPQC_ACQUSITION_RATE m_AcquistionRate;	///< Acqusition Rate of the Incoming Readings
	T_PPQC_STATUS m_Status;						///< Queue Status

	USHORT m_Front;		///< Front of the Queue, Items will be Removed
	USHORT m_Rear;		///< Rear of the Queue, Items will be Inserted

	USHORT m_ItemCoverage; ///< The system coverage in ticks of the current item

	FLOAT m_AnaloguePulseQueue[APPPQ_MAX_NUM_OF_READINGS]; ///<	The queue to store the incoming readings
	FLOAT m_PreviousReading;				///< Stores the Previous Reading

	LONGLONG m_MinCoverageTick;		///< Min System Coverage Available
	LONGLONG m_MaxCoverageTick;		///< Max System Coverage Available

	USHORT m_PredictedAPClockTick;		///< Predicted Analogue/Pulse Input Card Clock Tick
	T_PPQC_APCARD_TICK_RATE m_APCardTickRate; ///< Analogue/Pulse Input Card Clock Tick Rate( 400HZ, 80HZ etc )

	USHORT m_PreviousPredictedAPClockTick; ///< last value of predicted tick used (MarkD)
	USHORT m_PreviousAnaloguePulseInputTick; ///< last value of analoguePulseInputTick used (MarkD)

	LONGLONG m_PreviousSystemTime;		///< last value of sysem time (MarkD)
	USHORT m_RequestedTickCorrectionsHi;		///< number of consecutive High correction requests (MarkD)
	USHORT m_RequestedTickCorrectionsLo;		///< number of consecutive Low correction requests (MarkD)
	USHORT m_PredictedTickRemainder;		///< avoid truncation on DIO (MarkD)

	CAnaloguePulsePPQInfo m_PPQInfo;

	BOOL m_FirstRun;		///< MarkD: for initialisation of data items first time through after power-on

};
// End of Class Declaration

#endif // _ANALOGUEPULSEPPQ_H

#include "PPQManager.h"
#include "limits.h"
//#include "PPQSocket.h"

#include "V6globals.h"	//MarkD

#include "dal.h"

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif

/// Static Variable Initialisation, these variables will remain for the
/// lifetime of the application
CPPQManager *CPPQManager::m_pInstance = NULL; ///< Singleton Module Message Manager Instance
QMutex m_CreationMutex;

CPPQManager::CPPQManager(void) {
	m_PPQsAlignmentStatus = PPQM_NOT_ALIGNED;
}

CPPQManager::~CPPQManager(void) {

	CStorage PPQInfoFile;

	// Unicode files are prefixed with two bytes at the start of the file, to ensure
	// we do not overwrite these bytes, offset the file write position by 2. 
	const USHORT APPQSER_PPQINFO_FILE_START_POS = 2;

	CDeviceAbstraction *pDal = CDeviceAbstraction::GetHandle();
	WCHAR PPQInfoPathAndFileName[MAX_PATH] = "";

#ifdef _DEBUG
	
	if( NULL != pDal )
	{
	pDal->BuildPath( IDS_EXTERNAL_SD, IDS_ROOT, L"AllPPQInfo.txt", PPQInfoPathAndFileName, MAX_PATH ); 
	
	FileException kEx;
	if( TRUE == PPQInfoFile.Open( PPQInfoPathAndFileName, QFile::WriteOnly, &kEx ) )
	{
			PPQInfoFile.Seek( APPQSER_PPQINFO_FILE_START_POS, QFile::begin );

			m_APPPQServices.SaveToFileAllPPQInfo(PPQInfoFile);
			
			m_DPPQServices.SaveToFileAllPPQInfo( PPQInfoFile );
			
			PPQInfoFile.Close(); 
	}
	}				

#endif
}

/// Obtain handler to the Module Message Manager
CPPQManager* CPPQManager::GetHandle(void) {
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;

	if (NULL == m_pInstance) {
		// An instance has yet to be completed
		//
		m_CreationMutex = CreateMutex(NULL,		// No security descriptor
				FALSE,					// Mutex object not owned
				TEXT("PreProcessQueueManager"));	// Object name

		waitSingleObjectResult = m_CreationMutex.tryLock(g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);

		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:

			// Object was signaled
			//
			if (NULL == m_pInstance) {
				m_pInstance = new CPPQManager;
			}
			if ( FALSE == m_CreationMutex.unlock())
				V6WarningMessageBox(NULL, L"Failed to release PreProcessQueueManager mutex", L"Error", MB_OK);
			break;

		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
			V6WarningMessageBox(NULL, L"PreProcessQueueManager WaitForSingleObject Error", L"Error", MB_OK);
			break;
		}

		// Close the Mutex as no longer required
		//
		//No need to close the mutex in Qt
	}

	return (m_pInstance);
}

T_PPQM_RETURN_VALUE CPPQManager::CleanUp(void) {
	if (NULL != m_pInstance) {
		delete (m_pInstance);
	}

#ifdef PPQQAbstractSocket_ENABLED
		CPPQSocket::CloseSocket();
	#endif

	return (PPQM_OK);

}

T_PPQM_RETURN_VALUE CPPQManager::Initialise(USHORT numOfAnalogusPulsePPQs, USHORT numOfDigitalPPQs) {

	m_APPPQServices.Initialise(numOfAnalogusPulsePPQs);
	m_DPPQServices.Initialise(numOfDigitalPPQs);

#ifdef PPQQAbstractSocket_ENABLED
	
		CPPQSocket::CreateSocket();
		CPPQSocket::Connect();

	#endif

	return (PPQM_OK);

} // End of Member Function

T_PPQM_RETURN_VALUE CPPQManager::ResetAllPPQsToDefault(void) {
	m_APPPQServices.ResetAllPPQs();
	m_DPPQServices.ResetAllPPQs();

	ResetToDefault();

	return (PPQM_OK);

} // End of Member Function

T_PPQM_RETURN_VALUE CPPQManager::GetMinSystemTickCoverage(LONGLONG &minCoverage) {
	T_PPQM_RETURN_VALUE retValue = PPQM_NO_COVERAGE_AVAILABLE;

	USHORT index = PPQM_DEFAULT_ZERO;
	BOOL coverageAvailable = TRUE;
	LONGLONG minPPQCoverage[PPQM_SER_NUM_OF_SERVICES];

	// Default the minimum coverage to zero
	minCoverage = PPQM_DEFAULT_ZERO;

	// Get the Min Coverage from each service 
	minPPQCoverage[PPQM_SER_ANALOGUE_PULSE] = m_APPPQServices.GetMinSysTickCoverage();
	minPPQCoverage[PPQM_SER_DIGITAL] = m_DPPQServices.GetMinSysTickCoverage();

	// Analysis the min coverage from each service to determine if coverage is avialable,
	// and the coverage to report. 
	while (coverageAvailable == TRUE && index < PPQM_SER_NUM_OF_SERVICES) {
		switch (minPPQCoverage[index]) {
		case PPQM_NO_ENABLED_PPQS:

			// --- Do Nothing --- // 

			break;

		case PPQM_NO_COVERAGE:

			coverageAvailable = FALSE;	// wait till later, so all queues are aligned
			minCoverage = PPQM_DEFAULT_ZERO;

			break;

		default:

			if (minPPQCoverage[index] > minCoverage) {
				minCoverage = minPPQCoverage[index];
			}

			break;

		} // End of Switch

		++index;

	} // End of WHILE

	if (minCoverage > PPQM_NO_COVERAGE) {
		if (PPQM_NOT_ALIGNED == m_PPQsAlignmentStatus) {
			// Align all the PPQs with the Min Coverage
			m_APPPQServices.SetTickToBeginProcessing(minCoverage);
			m_DPPQServices.SetTickToBeginProcessing(minCoverage);

			m_PPQsAlignmentStatus = PPQM_ALIGNED;

		} // End of IF

		retValue = PPQM_OK;

	} // End of IF

	return (retValue);

} // End of Member Function

//MarkD: get digital coverage only, to avoid automatic demo channels if no analagues enabled
T_PPQM_RETURN_VALUE CPPQManager::GetMinDigitalTickCoverage(LONGLONG &minCoverage) {
	T_PPQM_RETURN_VALUE retValue = PPQM_NO_COVERAGE_AVAILABLE;

	//USHORT index = PPQM_DEFAULT_ZERO; 
	//BOOL coverageAvailable = TRUE;
	LONGLONG minPPQCoverage[PPQM_SER_NUM_OF_SERVICES];

	// Default the minimum coverage to zero
	minCoverage = PPQM_DEFAULT_ZERO;

	// Get the Min Coverage from each service 
	//minPPQCoverage[PPQM_SER_ANALOGUE_PULSE] = m_APPPQServices.GetMinSysTickCoverage();
	minPPQCoverage[PPQM_SER_DIGITAL] = m_DPPQServices.GetMinSysTickCoverage();

	// Analysis the min coverage from each service to determine if coverage is avialable,
	// and the coverage to report. 
	//while( coverageAvailable == TRUE && index < PPQM_SER_NUM_OF_SERVICES )
	//{			
	switch (minPPQCoverage[PPQM_SER_DIGITAL]) {
	case PPQM_NO_ENABLED_PPQS:

		// --- Do Nothing --- // 

		break;

	case PPQM_NO_COVERAGE:

		//coverageAvailable = FALSE; //MarkD - want to be able to see digitals if all analogues are disabled
		minCoverage = PPQM_DEFAULT_ZERO;

		break;

	default:

		if (minPPQCoverage[PPQM_SER_DIGITAL] > minCoverage) {
			minCoverage = minPPQCoverage[PPQM_SER_DIGITAL];
		}

		break;

	} // End of Switch

	//++index;

	//} // End of IF

	if (minCoverage > PPQM_NO_COVERAGE) {
		if (PPQM_NOT_ALIGNED == m_PPQsAlignmentStatus) {
			// Align all the PPQs with the Min Coverage
			//m_APPPQServices.SetTickToBeginProcessing( minCoverage );
			m_DPPQServices.SetTickToBeginProcessing(minCoverage);

			m_PPQsAlignmentStatus = PPQM_ALIGNED;

		} // End of IF

		retValue = PPQM_OK;

	} // End of IF

	return (retValue);

} // End of Member Function

//MarkD: get APPQ max only
T_PPQM_RETURN_VALUE CPPQManager::GetMaxSystemAPPQTickCoverage(LONGLONG &maxCoverage) {

	LONGLONG maxAPPQCoverage;

	// Get the Min Coverage from each service 
	maxAPPQCoverage = m_APPPQServices.GetMaxSysTickCoverage();

	// Analysis the min coverage from each service to determine if coverage is avialable,
	// and the coverage to report. 
	switch (maxAPPQCoverage) {
	case PPQM_NO_ENABLED_PPQS:
	case PPQM_NO_COVERAGE:

		maxCoverage = (pGlbSysTimer->GetCurrentSystemTimeTick100() - 50);
		// MarkD: reduced by another half second for safety
		qDebug("(PPQManager) no coverage, so use %d\n", (int) maxCoverage);

		break;

	default:

		maxCoverage = maxAPPQCoverage;

		break;

	} // End of Switch

	return (PPQM_OK);

} // End of Member Function

T_PPQM_RETURN_VALUE CPPQManager::GetMaxSystemTickCoverage(LONGLONG &maxCoverage) {
	T_PPQM_RETURN_VALUE retValue = PPQM_NO_COVERAGE_AVAILABLE;

	USHORT index = PPQM_DEFAULT_ZERO;
	BOOL coverageAvailable = TRUE;
	BOOL firstPPQAvailable = FALSE;
	LONGLONG originalMaxCoverage = maxCoverage;
	BOOL noEnabledPPQs = FALSE;
	LONGLONG maxPPQCoverage[PPQM_SER_NUM_OF_SERVICES];

	// Default the minimum coverage to zero
	maxCoverage = _I64_MAX;

	// Get the Min Coverage from each service 
	maxPPQCoverage[PPQM_SER_ANALOGUE_PULSE] = m_APPPQServices.GetMaxSysTickCoverage();
	maxPPQCoverage[PPQM_SER_DIGITAL] = m_DPPQServices.GetMaxSysTickCoverage();

	// Analysis the min coverage from each service to determine if coverage is avialable,
	// and the coverage to report. 
	while (coverageAvailable == TRUE && index < PPQM_SER_NUM_OF_SERVICES) {
		switch (maxPPQCoverage[index]) {
		case PPQM_NO_ENABLED_PPQS: /* Do Nothing */

			//MarkD: do nothing if checking analogue PPQs (first time through)
			// but if checking digital, leave max coverage unchanged IF there was no coverage 
			// on analogues as well - but also return PPQM_NO_COVERAGE_AVAILABLE
			if ((index == PPQM_SER_DIGITAL) && (firstPPQAvailable == FALSE)) {
				maxCoverage = originalMaxCoverage;
				noEnabledPPQs = TRUE;
			}
			break;

		case PPQM_NO_COVERAGE:

			coverageAvailable = FALSE;
			maxCoverage = PPQM_DEFAULT_ZERO;
			firstPPQAvailable = TRUE;

			break;

		default:

			if (maxPPQCoverage[index] < maxCoverage) {
				maxCoverage = maxPPQCoverage[index];

			} // End of IF 
			firstPPQAvailable = TRUE;

			break;

		} // End of Switch

		++index;

	} // End of IF

	if ((maxCoverage > PPQM_NO_COVERAGE) && (noEnabledPPQs == FALSE)) {
		retValue = PPQM_OK;

	} // End of IF

	return (retValue);

} // End of Member Function

T_PPQC_ACQUSITION_RATE CPPQManager::GetMaxAcquisitionRate(void) {
	T_PPQC_ACQUSITION_RATE acqusitionRate = m_APPPQServices.GetMaxAcqusitionRate();

	if (m_DPPQServices.GetMaxAcqusitionRate() > acqusitionRate) {
		acqusitionRate = m_DPPQServices.GetMaxAcqusitionRate();

	} // End of IF

	return (acqusitionRate);

} // End of Member Function

T_PPQM_RETURN_VALUE CPPQManager::PopulateDataItemTable(USHORT tickIncrement) {
	m_APPPQServices.PopulateDataItemTable(tickIncrement);
	m_DPPQServices.PopulateDataItemTable(tickIncrement);

	return (T_PPQM_RETURN_VALUE());

} // End of Member Function

/// Reset the Pre Process Manager to Default
T_PPQM_RETURN_VALUE CPPQManager::ResetToDefault(void) {
	T_PPQM_RETURN_VALUE retValue = PPQM_OK; // Member Function Return Value 

	// Reset the Analogue Services
	m_APPPQServices.ResetToDefault();

	// Reset the Digital Services
	m_DPPQServices.ResetToDefault();

	// Reset PPQ Manager Alignment Status
	m_PPQsAlignmentStatus = PPQM_NOT_ALIGNED;

	return (retValue);

} // End of Member Function


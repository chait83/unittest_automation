/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Pre Process Queue Manager
/// @n Filename:	PPQService.h
/// @n Description: Abstract Base Class for Pre Process Queue Service classes
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 5	Stability Project 1.2.1.1	7/2/2011 4:59:47 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 4	Stability Project 1.2.1.0	7/1/2011 4:27:21 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 3	V6 Firmware 1.2		5/24/2005 1:22:23 PM	Alistair Brugsch
//		Added ResetToDefault as a default services that must be provided
// 2	V6 Firmware 1.1		3/2/2005 7:57:10 PM	Alistair Brugsch
//		Made changes due to code walkthrough, added Data Item Population
//		Functionality
// $
//
// **************************************************************************
#ifndef _PPQSERVICE_H 
#define _PPQSERVICE_H

#include "PPQCommon.h"
#include "V6defines.h"

/// Return Values for CPPQService Member Functions, used to describe the type of 
/// success or failure.
/// 
typedef enum {
	PPQSER_OK, PPQSER_CREATION_FAILED, PPQSER_NO_PPQ_AVAILABLE, PPQSER_INVALID_PPQ_HANDLE, PPQSER_NO_COVERAGE

} T_PPQSER_RETURN_VALUE;

//**Class*********************************************************************
///
/// @brief Abstract Base Class for Pre Process Queue Service classes
/// 
/// Provides the minimum set of functions that a service class managing
/// a number of Pre Process Queues must implement. The main purpose is to 
/// provide a common set of operations that can be carried out, across all
/// service classes that manage different sub sets of Pre Process Queues.	
///
//****************************************************************************
class CPPQService {
public:

	/// Constructor
	CPPQService(void);

	/// Destructor
	virtual ~CPPQService(void);

	/// Request a Pre Process Queue to use
	virtual T_PPQSER_RETURN_VALUE RequestPPQ(USHORT &hPPQ) = PURE_VIRTUAL_FUNCTION
	;

	/// Disable a Pre Process Queue
	virtual T_PPQSER_RETURN_VALUE DisablePPQ(USHORT hPPQ) = PURE_VIRTUAL_FUNCTION
	;

	/// Synchronise a Pre Process Queue
	virtual T_PPQSER_RETURN_VALUE SyncPPQ(USHORT hPPQ, USHORT inputCardTick,
			LONGLONG systemTick) = PURE_VIRTUAL_FUNCTION
	;

	/// Reset a Pre Process Queue
	virtual T_PPQSER_RETURN_VALUE ResetPPQ(USHORT hPPQ)= PURE_VIRTUAL_FUNCTION
	;

private:

	// --- Private Member Functions --- //

	/// Validate a Pre Process Queue Handler 
	virtual T_PPQSER_RETURN_VALUE ValidPPQHandler(USHORT hPPQ) = PURE_VIRTUAL_FUNCTION
	;

	/// Initialise the Pre Process Queue Service for operation
	virtual T_PPQSER_RETURN_VALUE Initialise(USHORT maxPPQsAvailable) = PURE_VIRTUAL_FUNCTION
	;

	/// Set all Pre Process Queues within Service to begin processing at the same system tick
	virtual T_PPQSER_RETURN_VALUE SetTickToBeginProcessing(LONGLONG initialSystemTick) = PURE_VIRTUAL_FUNCTION
	;

	/// Obtain Min Coverage available across all Pre Process Queues within Service
	virtual LONGLONG GetMinSysTickCoverage(void) = PURE_VIRTUAL_FUNCTION
	;

	/// Obtain Max Coverage available across allPre Process Queues within Service
	virtual LONGLONG GetMaxSysTickCoverage(void) = PURE_VIRTUAL_FUNCTION
	;

	/// Populate the Data Item Table for all Enables Pre Process Queues within Service 
	virtual T_PPQSER_RETURN_VALUE PopulateDataItemTable(USHORT tickIncrement) = PURE_VIRTUAL_FUNCTION
	;

	/// Return the max acqusition rate avialable across all Pre Process Queues
	virtual T_PPQC_ACQUSITION_RATE GetMaxAcqusitionRate(void) = PURE_VIRTUAL_FUNCTION
	;

	/// Reset All Pre Process Queues to default state
	virtual T_PPQSER_RETURN_VALUE ResetAllPPQs(void) = PURE_VIRTUAL_FUNCTION
	;

	/// Reset the Pre Process Queues to Default State
	virtual T_PPQSER_RETURN_VALUE ResetToDefault(void) = PURE_VIRTUAL_FUNCTION
	;

};
// End of Class Declaration

#endif _PPQSERVICE_H

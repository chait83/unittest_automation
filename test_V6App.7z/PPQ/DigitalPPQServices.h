#pragma once
#include "PPQService.h"
#include "DigitalPPQ.h"
#include "CStorage.h"
const USHORT DPPQSER_DEFAULT_ZERO = 0;
const SHORT DPPQSER_NO_ENABLED_PPQS = -1;
const USHORT DPPQSER_CHANNEL_SET_COMPARE_VALUE = 0x0001;
const USHORT DPPQSER_ONE_BIT = 1;

typedef enum {
	DPPQSER_OK, DPPQSER_INVALID_PPQ_HANDLE

} T_DPPQSER_RETURN_VALUE;

class CDigitalPPQServices: public CPPQService {
	friend class CPPQManager;

public:

	CDigitalPPQServices(void);

	virtual ~CDigitalPPQServices(void);

	virtual T_PPQSER_RETURN_VALUE RequestPPQ(USHORT &hPPQ);

	T_PPQSER_RETURN_VALUE EnablePPQ(USHORT hPPQ, T_PPQC_DIGITAL_PPQ_TYPE type, T_PPQC_ACQUSITION_RATE acqusitionRate,
			const USHORT chartReportMask, const USHORT msgReportMask, const USHORT IPMask,
			const USHORT numOfActiveChannels);

	virtual T_PPQSER_RETURN_VALUE DisablePPQ(USHORT hPPQ);

	virtual T_PPQSER_RETURN_VALUE SyncPPQ(USHORT hPPQ, USHORT inputCardTick, LONGLONG systemTick);

	virtual T_PPQSER_RETURN_VALUE ResetPPQ(USHORT hPPQ);

	T_PPQSER_RETURN_VALUE ReSyncPPQ(USHORT hPPQ, USHORT inputCardTick, LONGLONG systemTick);

	T_PPQSER_RETURN_VALUE AddReading(USHORT hPPQ, USHORT reading, USHORT digitalInputTick);

	T_PPQSER_RETURN_VALUE SetLastReadingCoverage(USHORT hPPQ, LONGLONG systemTick);

	USHORT GetNumOfEnabledPPQs(void);

	void SaveToFileAllPPQInfo(CStorage &PPQInfoFile);

	LONGLONG GetLastResyncSystemTick(USHORT hPPQ);
	USHORT GetLastResyncDITick(USHORT hPPQ);
	ULONG GetUnprocessedCoverage(USHORT hPPQ);

private:

	// --- Private Member Variable --- ///
	/// TODO
	CTypedPtrArray<QList, class CDigitalPPQ*> m_pDigitalPPQ;

	USHORT m_NextAvailablePPQ;
	USHORT m_MaxPPQsAvailable;

	USHORT m_chartReportMask[PPQC_NUM_OF_DIGITAL_PPQ_TYPES];
	USHORT m_msgReportMask[PPQC_NUM_OF_DIGITAL_PPQ_TYPES];
	USHORT m_IPMask[PPQC_NUM_OF_DIGITAL_PPQ_TYPES];
	USHORT m_NumOfActiveChannelsOnDICard[PPQC_NUM_OF_DIGITAL_PPQ_TYPES];

	T_PPQC_ACQUSITION_RATE m_MaxAcqusitionRate;

	USHORT m_NumOfEnabledPPQs;

	// --- Private Member Functions --- //

	virtual T_PPQSER_RETURN_VALUE ValidPPQHandler(USHORT hPPQ);

	virtual T_PPQSER_RETURN_VALUE Initialise(USHORT maxPPQsAvailable);
	virtual T_PPQSER_RETURN_VALUE SetTickToBeginProcessing(LONGLONG initialSystemTick);
	virtual LONGLONG GetMinSysTickCoverage(void);
	virtual LONGLONG GetMaxSysTickCoverage(void);
	virtual T_PPQSER_RETURN_VALUE PopulateDataItemTable(USHORT tickIncrement);
	virtual T_PPQC_ACQUSITION_RATE GetMaxAcqusitionRate(void);
	virtual T_PPQSER_RETURN_VALUE ResetAllPPQs(void);

	/// Reset the Pre Process Queues to Default State
	virtual T_PPQSER_RETURN_VALUE ResetToDefault(void);

};
// End of Class Declaration

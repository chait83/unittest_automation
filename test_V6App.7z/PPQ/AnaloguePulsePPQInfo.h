#ifndef _ANALOGUEPULSEPPQINFO_H
#define _ANALOGUEPULSEPPQINFO_H

#include "PPQCommon.h"
#include "CStorage.h"

class CAnaloguePulsePPQInfo {
public:

	CAnaloguePulsePPQInfo(void);
	virtual ~CAnaloguePulsePPQInfo(void);

	///< Trace the PPQ Info to a File for analysis
	void TracePPQInfoToFile(CStorage &PPQInfoFile, T_PPQC_QUEUE_TYPE type, USHORT reference,
			T_PPQC_ACQUSITION_RATE acquistionRate, T_PPQC_STATUS status);

	// For Speed and Efficiency and to avoid additional overheads these member are made
	// public. The member variables are used to store data for debug purposes. 

	LONGLONG m_InitialMinSystemCoverage;		///< Initial System Coverage
	USHORT m_InitialAITick;					///< Initial AI Tick

	USHORT m_FirstTimestampedReadingAITick;	///< First Reading Timestamp in AI Ticks 
	SHORT m_FirstReadingTickDifference;	///< First Reading Tick Difference between Initial AI Tick

	LONGLONG m_MinCoverageAfterSync;		///< Min System Coverage after Sync
	USHORT m_PredictedAITickAfterSync;		///< Predicted AI Tick After Sync

	LONGLONG m_SysTickToBeginProcess;		///< System Tick in which to begin processing
	USHORT m_SetPosTickIncrement;		///< Number of Ticks Increment to advance queue for processing to begin

	ULONG m_NumOfMissedReadings;		///< Number of Missed Readings Inserted
	ULONG m_NumOfAdditionalReadingInserted;	///< Number of Additional Reading Inserted
	ULONG m_NumOfDroppedReadings;			///< Number of Reading Dropped

};
// End of Class Declaration

#endif // _ANALOGUEPULSEPPQINFO_H

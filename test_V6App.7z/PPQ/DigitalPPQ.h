/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	--- Add Module Name ---
/// @n Filename:	--- Add Filename ---
/// @n Description: --- Add File Description ---
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 17	Stability Project 1.14.1.1	7/2/2011 4:56:47 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 16	Stability Project 1.14.1.0	7/1/2011 4:27:20 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 15	V6 Firmware 1.14		4/12/2006 6:06:58 PM	Roger Dawson 
//		Changed QFile to CStorage
// 14	V6 Firmware 1.13		3/22/2006 8:28:22 PM	Andy Kassell	Low
//		risk optimisation of digital PPQ, cache pointer to DIT and configs
// $
//
// **************************************************************************
#ifndef _DIGITALPPQ_H
#define _DIGITALPPQ_H

#include "PPQCommon.h"
#include "DigitalPPQInfo.h"
#include "DataItemBase.h"

const USHORT DPPQ_DEFAULT_ZERO = 0;	///< Default Zero 
const USHORT DPPQ_BUFFER_SIZE = 1024;	///< Size of the buffer for the queue to use in bytes
//const USHORT DPPQ_BUFFER_SIZE		= 2048;	///< Size of the buffer for the queue to use in bytes

/// Number of Readings based on the specified buffer and size of a single reading 
const USHORT DPPQ_MAX_NUM_OF_READINGS = DPPQ_BUFFER_SIZE / sizeof(USHORT);

/// Return Values for CDigitalPPQ Member Functions, used to describe the type of 
/// success or failure.
/// 
typedef enum {
	DPPQ_OK,
	DPPQ_ERROR,
	DPPQ_NO_UPDATE_REQUIRED,
	DPPQ_FATAL_ERROR_DATA_LOSS,
	DPPQ_NO_READING_AVAILABLE,
	DPPQ_READING_UPDATE_REQUIRED

} T_DPPQ_RETURN_VALUE;

/// An Analogue / Pulse Queue Item
typedef struct {
	USHORT reading;			///< A Single Input Card Reading
	LONG systemTickCoverage; ///< Amount of System Coverage item spans in System Ticks

} T_DPPQ_QUEUE_ITEM;

//**Class*********************************************************************
///
/// @brief ---Single line description---.
/// 
/// --- Detailed Description ---
///
//****************************************************************************
class CDigitalPPQ {
public:

	/// Constructor
	CDigitalPPQ(void);

	/// Destructor
	virtual ~CDigitalPPQ(void);

	/// Enable the Pre Process Queue for Operation									
	T_DPPQ_RETURN_VALUE EnablePPQ(T_PPQC_DIGITAL_PPQ_TYPE type, T_PPQC_ACQUSITION_RATE acqusitionRate);

	/// Disable the Pre Process Queue 
	T_DPPQ_RETURN_VALUE DisablePPQ(void);

	/// Reset the Pre Process Queue
	T_DPPQ_RETURN_VALUE ResetPPQ(void);

	/// Synchronise the Queue with the Input Card Ticks and System Ticks
	T_DPPQ_RETURN_VALUE SyncPPQ(USHORT inputCardTick, LONGLONG systemTick);

	/// ReSynchronise the Queue with the Input Card Ticks and System Ticks
	T_DPPQ_RETURN_VALUE ReSyncPPQ(USHORT inputCardTick, LONGLONG systemTick);

	/// Add a reading to the Digital Pre Process Queue 
	T_DPPQ_RETURN_VALUE AddReading(USHORT reading, USHORT digitalInputTick);

	/// Get a reading from the Pre Process Queue
	T_DPPQ_RETURN_VALUE GetReading(USHORT &reading, LONG tickIncrement);

	/// Set Last Reading Coverage, updates the queue with the last known time the GPIO was polled		
	T_DPPQ_RETURN_VALUE SetLastReadingCoverage(LONGLONG systemTick);

	/// Set Initial System Tick to begin processing
	T_DPPQ_RETURN_VALUE SetPosToBeginProcessing(LONGLONG systemTick);

	/// Get the Minimum System Tick Coverage
	T_DPPQ_RETURN_VALUE GetMinSystemTickCoverage(LONGLONG &minCoverage);

	/// Get the Maximum System Tick Coverage
	T_DPPQ_RETURN_VALUE GetMaxSystemTickCoverage(LONGLONG &maxCoverage);

	/// Get the Current Status of the Pre Process Queue
	T_PPQC_STATUS GetStatus(void) {
		return m_Status;
	}

	/// Get the Pre Process Queue Type
	T_PPQC_DIGITAL_PPQ_TYPE GetType(void) {
		return m_Type;
	}

	void SavePPQInfoToFile(CStorage &PPQInfoFile);

	LONGLONG GetLastResyncSystemTick(void);
	USHORT GetLastResyncDITick(void);
	ULONG GetUnprocessedCoverage(void);

public:
	CDataItem *m_pCardDataItem;
	CDataItem *m_pChannelDataItem[MAX_DIG_IO_PER_CARD];
	T_PDIGCHANNEL m_pDigCMMConfig[MAX_DIG_IO_PER_CARD];

private:

	// --- Private Member Functions --- //

	LONG CalculateDITickDifference(USHORT digitalInputTick);

	// --- Private Member Variables --- // 	

	QMutex m_csDigitalPPQ; ///< Critical Section for Thread Safe Operation

	class CPPQManager *m_pAPPQ;	///< Handle on Pre Process Queues

	T_DPPQ_QUEUE_ITEM m_DigitalQueue[DPPQ_MAX_NUM_OF_READINGS];

	LONGLONG m_BaseSystemSyncTick;
	LONGLONG m_BaseDISyncTick;
	LONGLONG m_AccumulativeDITick;

	float m_LastDIClockTick;

	USHORT m_LastDISyncTick;	//MarkD
	LONGLONG m_LastSyncSystemTick;	// MarkD
	USHORT m_LastDIClockTickAtResync; // MarkD
	//USHORT		m_LatestDILocalTick;	//MarkD
	float m_CardClockError;		//MarkD

	//LONG	m_DigItemCoverage[DPPQ_MAX_NUM_OF_READINGS];	//MarkD
	BOOL m_RearWrapped;	//MarkD

	//long m_DITickAndSysTickDifference; ///< Tick difference between the DI Tick in 100 Hz and System Tick in 100HZ
	LONGLONG m_DITickAndSysTickDifference;	//MarkD

	USHORT m_Front;				///< Front of the Queue, Items will be Removed
	USHORT m_Rear;				///< Rear of the Queue, Items will be Inserted
	USHORT m_LastUsed;

	T_PPQC_DIGITAL_PPQ_TYPE m_Type;						///<
	//USHORT m_Reference;							///<
	T_PPQC_ACQUSITION_RATE m_AcquistionRate;	///<
	T_PPQC_STATUS m_Status;						///< 

	CDigitalPPQInfo m_DigitalPPQInfo;

};
// End of Class Declaration

#endif // _DIGITALPPQ_H

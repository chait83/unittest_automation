#pragma once

// CDemoChannelThread

class CDemoChannelThread: public QThread {
	// DECLARE_DYNCREATE (CDemoChannelThread)

protected:
	CDemoChannelThread();  // protected constructor used by dynamic creation
	virtual ~CDemoChannelThread();

public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();

protected:()

public:
	static UINT ThreadFunc(LPVOID lpParam);

};


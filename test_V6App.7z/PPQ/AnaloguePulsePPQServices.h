/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	Pre Process Queues
/// @n Filename:	AnaloguePulsePPQServices.h
/// @n Description: Class Declaration for Analogue/Pulse Pre Process Queue
///				Services
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 13	Stability Project 1.10.1.1	7/2/2011 4:55:26 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 12	Stability Project 1.10.1.0	7/1/2011 4:27:20 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 11	V6 Firmware 1.10		4/19/2006 1:33:29 PM	Graham Waterfield
//		Bug fix to prevent disabled channels from causing weird offset
//		problems
// 10	V6 Firmware 1.9		4/12/2006 6:06:58 PM	Roger Dawson 
//		Changed QFile to CStorage
// $
//
// ***********************************************************************
#ifndef _ANALOGUEPULSEPPQSERVICES_H
#define _ANALOGUEPULSEPPQSERVICES_H

#include "PPQCommon.h"
#include "ppqservice.h"
#include "AnaloguePulsePPQ.h"
#include "afxtempl.h"		// Required for the use of CTypedPtrArray

const USHORT APPPQSER_ZERO = 0; ///< Value of Zero
const SHORT APPPQSER_NO_ENABLED_PPQS = -1; ///< Represents No Enabled Pre Process Queues

//**Class*********************************************************************
///
/// @brief Analogue / Pulse Pre Process Queue Services
/// 
/// This class provides the following functionality:
///	1) Request and Enable Pre Process Queues
///	2) Synchronised Pre Process Queues with the System and AI Card
///	3) Add Timestamped, Missed or Normal Readings
///	4) Disable Pre Process Queue and Reset them to Default.
///
/// The class also provides specific functionality exclusive to the Pre Process
/// Manager. This allows the Pre Process Manager to query the Pre Process Queues
/// to obtain data that allows Readings to be Processed. The class manages all
/// the enabled Pre Process Queues, and report back the max and min coverage available
/// across all enabled Pre Process Queues. This class is also responsible for
/// populating the Data Item Table with the correct reading for a given period of
/// time. 
//****************************************************************************
class CAnaloguePulsePPQServices: public CPPQService {
	/// Allow the PPQManager to access Private Members of this Class
	friend class CPPQManager;

public:

	/// Constructor
	CAnaloguePulsePPQServices(void);

	/// Destructor
	virtual ~CAnaloguePulsePPQServices(void);

	/// Request a Pre Process Queue for use 
	virtual T_PPQSER_RETURN_VALUE RequestPPQ(USHORT &hPPQ);

	/// Enable a Requested Pre Process Queue
	T_PPQSER_RETURN_VALUE EnablePPQ(USHORT hPPQ, T_PPQC_QUEUE_TYPE type, USHORT reference,
			T_PPQC_ACQUSITION_RATE acqusitionRate, T_PPQC_APCARD_TICK_RATE clockTickRate);

	/// Synchronise the Pre Process Queue with the Analogue/Pulse Card and System
	virtual T_PPQSER_RETURN_VALUE SyncPPQ(USHORT hPPQ, USHORT inputCardTick, LONGLONG systemTick);

	/// Add an Analogue / Pulse Reading to a specified Pre Process Queue
	T_PPQSER_RETURN_VALUE AddReading(USHORT hPPQ, FLOAT reading);

	/// Add an Analogue / Pulse Timestamped Reading to a specified Pre Process Queue
	T_PPQSER_RETURN_VALUE AddTimeStampedReading(USHORT hPPQ, FLOAT reading, USHORT analoguePulseInputTick);

	/// Add an Analogue / Pulse Missed Reading to a specified Pre Process Queue
	T_PPQSER_RETURN_VALUE AddMissedReading(USHORT hPPQ);

	/// Disable a Specified Pre Process Queue	
	virtual T_PPQSER_RETURN_VALUE DisablePPQ(USHORT hPPQ);

	/// Reset a Pre Process Queue to Default										
	virtual T_PPQSER_RETURN_VALUE ResetPPQ(USHORT hPPQ);

	///
	void SaveToFileAllPPQInfo(CStorage &PPQInfoFile);

	USHORT GetReference(USHORT hPPQ);
	BOOL IsPPQOperational(USHORT hPPQ);
	UCHAR GetPPQOperationalState(USHORT hPPQ);
	ULONG GetDroppedReadingCount(USHORT hPPQ);
	ULONG GetInsertedReadingCount(USHORT hPPQ);
	ULONG GetUnprocessedCoverage(USHORT hPPQ);

private:

	// --- Private Member Variable --- ///
	QMutex m_csAnalPulsePPQService; ///< Critical Section for Thread Safe Operation

	/// An Array of Analogue/Pulse Pre Process Queues
	CTypedPtrArray<QList, class CAnaloguePulsePPQ*> m_pAnaloguePulsePPQ;

	USHORT m_NextAvailablePPQ; ///< Next Available Pre Process Queue Number
	USHORT m_MaxPPQsAvailable; ///< Maximum Number of Pre Process Queues Available
	USHORT m_NumOfEnabledPPQs; ///< Number of Enabled Pre Process Queues

	T_PPQC_ACQUSITION_RATE m_MaxAcqusitionRate; ///< Maximum Acquistion Rate Available Across all PPQs

	// --- Private Member Functions --- //

	virtual T_PPQSER_RETURN_VALUE ValidPPQHandler(USHORT hPPQ);
	virtual T_PPQSER_RETURN_VALUE Initialise(USHORT maxPPQsAvailable);
	virtual T_PPQSER_RETURN_VALUE SetTickToBeginProcessing(LONGLONG initialSystemTick);
	virtual LONGLONG GetMinSysTickCoverage(void);
	virtual LONGLONG GetMaxSysTickCoverage(void);
	virtual T_PPQSER_RETURN_VALUE PopulateDataItemTable(USHORT tickIncrement);
	virtual T_PPQC_ACQUSITION_RATE GetMaxAcqusitionRate(void);
	virtual T_PPQSER_RETURN_VALUE ResetAllPPQs(void);

	/// Reset the Pre Process Queues to Default State
	virtual T_PPQSER_RETURN_VALUE ResetToDefault(void);

};
// End of Class Declaration

#endif // _ANALOGUEPULSEPPQSERVICES_H

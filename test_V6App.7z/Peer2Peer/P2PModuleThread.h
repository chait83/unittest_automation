/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Processing
/// @n Filename: ProcessingThread.h
/// @n Desc:	 Main Data processing thread 
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  3 Stability Project 1.0.1.1 7/2/2011 4:59:36 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  2 Stability Project 1.0.1.0 7/1/2011 4:27:49 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  1 V6 Firmware 1.0 11/7/2006 7:07:00 PM  Alistair Brugsch 
// $
//
// ****************************************************************

#ifndef __P2PMODULE_THREAD__
#define __P2PMODULE_THREAD__

//**Class*********************************************************************
///
/// @brief Main Data processing thread 
/// 
//****************************************************************************

// CP2PModuleThread

class CP2PModuleThread: public QThread {
	// DECLARE_DYNCREATE (CP2PModuleThread)

protected:
	CP2PModuleThread();  // protected constructor used by dynamic creation
	virtual ~CP2PModuleThread();

public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();

	static UINT ThreadFunc(LPVOID lpParam);

protected:()
};

#endif //__PROCESSING_THREAD__

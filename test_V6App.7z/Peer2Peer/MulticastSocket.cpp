//////////////////////////////////////////////////////////////////////
/// @file 
/// **************************************************************************
/// Ã¯¿½ Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Peer2Peer
/// @n Filename:  MulticastSocket.cpp
/// @n Description: Implementation of the CMulticastSocket class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log:
//  8 Stability Project 1.3.1.3 7/2/2011 4:58:57 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  7 Stability Project 1.3.1.2 7/1/2011 4:38:31 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  6 Stability Project 1.3.1.1 3/17/2011 3:20:30 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  5 Stability Project 1.3.1.0 2/15/2011 3:03:23 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
//  4 V6 Firmware 1.3 7/13/2007 1:59:32 PM  Charles Boardman
//  CR2979: Adding ability of Peer Services to work with a preferred
//  network adapter connection, so that when it can be properly used by
//  the Locate X Series Device dialog.
//  3 V6 Firmware 1.2 12/6/2006 7:26:24 PM  Alistair Brugsch
//  Added function UpdateBroadcastAddr
//  2 V6 Firmware 1.1 11/7/2006 6:30:34 PM  Alistair Brugsch
//  integrated P2P engine into V6App startup procedure. module now
//  availabe to app for use as a transport mechanism
//  1 V6 Firmware 1.0 10/31/2006 10:18:24 PM Alistair Brugsch 
// $
//
// **************************************************************************

//#include "p2ptestdoc.h"

#include "CESocket.h"
#include "MulticastSocket.h"
#include "Iphlpapi.h"

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif

#define MCAST_ADDR "255.255.255.255"
const ULONG LOOPBACK = 0x0100007f;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

//****************************************************************************
///
/// CMulticastSocket default Constructor
///
//****************************************************************************

CMulticastSocket::CMulticastSocket() {
	m_hParent = NULL;
	m_hCloseEvent = NULL;
#ifdef TMS_DYNAMICLOADING
	m_hmICmp = NULL;
#endif	

}
//****************************************************************************
///
/// CMulticastSocket Constructor
/// @param[in] parent - HWND of owner if messages are to be posted back
///
//****************************************************************************
CMulticastSocket::CMulticastSocket(HWND parent) {
	m_hParent = parent;
	m_hCloseEvent = NULL;
#ifdef TMS_DYNAMICLOADING
	m_hmICmp = NULL;
#endif	

}
//****************************************************************************
/// SetParent - Sets the HWND of the parent object to allow messages to be 
///				posted back
///
/// @param[in]		HWND - Parent
///
/// @return			void
///
//****************************************************************************
void CMulticastSocket::SetParent(HWND parent) {
	m_hParent = parent;
}
//****************************************************************************
///
/// CMulticastSocket default Destructor
///
//****************************************************************************
CMulticastSocket::~CMulticastSocket() {
#ifdef TMS_DYNAMICLOADING
	if (m_hmICmp != NULL)
	{
		FreeLibrary(m_hmICmp);
		m_hmICmp = NULL;
	}
#endif
}

#ifdef TMS_DYNAMICLOADING
///HTS - PCT fix begin
QLibrary CMulticastSocket::getIcmpLibray()
{
	if (m_hmICmp != NULL)
	{
		return m_hmICmp;
	}
	else
	{
		m_hmICmp = LoadLibrary("Iphlpapi.dll");
		if ( NULL == m_hmICmp )
		{
			m_hmICmp = LoadLibrary("Icmp.dll");
		}
		return m_hmICmp;
	}
}
///HTS - PCT fix end
#endif

//****************************************************************************
/// Create - Override of CCESocket::Create to specify multicast socket type
///				
/// @param[in]		n/a
///
/// @return		true if successful
///
//****************************************************************************
bool CMulticastSocket::Create() {
	bool bRet = CCESocket::Create(SOCK_MCAST);

	return bRet;
}

//****************************************************************************
/// Shutdown - leaves a multicast group and closes the socket down
///
/// @param	 n/a
///
/// @return	 false if socket is invalid or Winsock not initialised
///
//****************************************************************************
bool CMulticastSocket::Shutdown() {
	if (!m_bWSAStarted || s == INVALID_SOCKET)
		return false;

	//leave a group on shutdown
	setsockopt(s, IPPROTO_IP, IP_DROP_MEMBERSHIP, (char*) &m_mReq, sizeof(ip_mreq));
	Disconnect();
	//cleanup
	if (m_hEvent) {
		//No need to close the mutex in Qt
		m_hEvent = NULL;
	}
	if (m_hCloseEvent) {
		//No need to close the mutex in Qt
		m_hCloseEvent = NULL;
	}
	return true;
}
//****************************************************************************
/// OnReceive - Overrides the virtual OnRecieve notification handler
///
/// @param[in/out]		buf - buffer to recieve data
/// @param[in] len - length of buffer allocated in bytes
///
/// @return			FALSE - as this method is not used
///
//****************************************************************************
bool CMulticastSocket::OnReceive(char *buf, int len) {
//	if (m_hParent)
	return false;
//	else
//	{
	//deal with data

//		delete buf;
//		return true;
//	}
}
//****************************************************************************
/// OnReceive - Overrides the virtual OnRecieve notification handler
///
/// @param  n/a
///
/// @return			void
///
//****************************************************************************
void CMulticastSocket::OnReceive() {
	SetEvent(m_hEvent);
	//if window notifications are to be used, post messages here
//	if (m_hParent)
//		PostMessage(m_hParent,WM_MULTICAST_DATA,NULL,NULL);
}
//****************************************************************************
/// GetEventHandle - Gets the Handle of the receive event
///
/// @param n/a
///
/// @return			Event Handle for recieve events
///
//****************************************************************************
HANDLE CMulticastSocket::GetEventHandle() {
	return m_hEvent;
}

//****************************************************************************
/// Accept - Overrides the Accept base function. Determines netmask to find 
///			 Directed broadcast address for subnet
///
/// @param[in]	localPort - listening port to bind to
/// @param[in] ulPreferredAddr is the preferred connection to use.
///
/// @return			true if successful
///
//****************************************************************************
bool CMulticastSocket::Accept(USHORT localport, unsigned long ulPreferredAddr) {
	//call the base accept to call the bind which is required to 
	//set the IP_ADD_MEMBERSHIP
	bool bRet = CCESocket::Accept((UINT) localport, NULL, TRUE);
	if (bRet) {
#ifndef _MULTICAST
		//determine netmask

		PMIB_IPADDRTABLE pIpTab = NULL;
		DWORD dwSizeReq = 0;

#ifdef TMS_DYNAMICLOADING  
		BYTE *pbuff = NULL;

		QLibrary hm = NULL;
		
		hm = getIcmpLibray();
		
		if ( NULL != hm)
		{

			typedef DWORD (FAR PASCAL *PICMPGETIPADDRTABLE) (PMIB_IPADDRTABLE, PULONG, BOOL);
			PICMPGETIPADDRTABLE pIcmpGetIpAddrTable = NULL;

			(*(FARPROC*)&pIcmpGetIpAddrTable = GetProcAddress(hm, "GetIpAddrTable"));

			if ( NULL != pIcmpGetIpAddrTable )
			{
		
				DWORD dwRet = pIcmpGetIpAddrTable(pIpTab, &dwSizeReq, TRUE);
				if (ERROR_INSUFFICIENT_BUFFER != dwRet)
				{
					qDebug(_T("GetIpAddrTable 1st calling error : %d\n"),dwRet);
					return false;
				}

				qDebug(_T("need %d bytes to store the ip table\n"),dwSizeReq);
				pbuff = new BYTE[dwSizeReq];
				assert(pbuff);
				pIpTab = (PMIB_IPADDRTABLE) pbuff;

				dwRet = pIcmpGetIpAddrTable(pIpTab, &dwSizeReq, TRUE);
				if (NO_ERROR != dwRet) 
				{
					qDebug(_T("GetIpAddrTable 2nd calling error : %d\n"),dwRet);
					return false;
				}
			}
			else
			{
				qDebug(_T("GetIpAddrTable - GetProcAddress failed\n"));
				return false;
			}
		}
		else
		{
			qDebug(_T("GetIpAddrTable Load Library failed\n"));
			return false;
		}  
#else

		DWORD dwRet = GetIpAddrTable(pIpTab, &dwSizeReq, TRUE);
		if (ERROR_INSUFFICIENT_BUFFER != dwRet) {
			qDebug(_T("GetIpAddrTable 1st calling error : %d\n"), dwRet);
			return false;
		}

		qDebug(_T("need %d bytes to store the ip table\n"), dwSizeReq);
		BYTE *pbuff = new BYTE[dwSizeReq];
		assert(pbuff);
		pIpTab = (PMIB_IPADDRTABLE) pbuff;

		dwRet = GetIpAddrTable(pIpTab, &dwSizeReq, TRUE);
		if (NO_ERROR != dwRet) {
			qDebug(_T("GetIpAddrTable 2nd calling error : %d\n"), dwRet);
			return false;
		}
#endif		

		BOOL bFoundConnection = FALSE;

		for (DWORD IfNo = 0; IfNo < pIpTab->dwNumEntries; ++IfNo) {
			// We look for the preferred connection.
			if ((0 != ulPreferredAddr) && (LOOPBACK != ulPreferredAddr)
					&& (ulPreferredAddr == pIpTab->table[IfNo].dwAddr)) {
				bFoundConnection = TRUE;
				m_remoteAddress.sin_addr.S_un.S_addr = pIpTab->table[IfNo].dwAddr | ~(pIpTab->table[IfNo].dwMask);
				break;
			}
		}

		if ( FALSE == bFoundConnection) {
			// Did not find preferred connection. Go for first valid one that
			// we can find.
			for (DWORD IfNo = 0; IfNo < pIpTab->dwNumEntries; ++IfNo) {

				if ((LOOPBACK != pIpTab->table[IfNo].dwAddr) && (0 != pIpTab->table[IfNo].dwAddr)) {
					bFoundConnection = TRUE;
					m_remoteAddress.sin_addr.S_un.S_addr = pIpTab->table[IfNo].dwAddr | ~(pIpTab->table[IfNo].dwMask);
					break;
				}
			}
		}

		delete[] pbuff;
		/*
		 INTERFACE_INFO IfInf[10];
		 DWORD dwRet;
		 nRet = WSAIoctl(s,SIO_GET_INTERFACE_LIST,NULL,NULL,&IfInf,sizeof(IfInf),&dwRet,NULL,NULL);
		 if(QAbstractSocket_ERROR == nRet)
		 {
		 err = WSAGetLastError();
		 if(err)
		 {
		 QString  csTmp;
		 csTmp.asprintf(L"Socket error: %d",err);
		 qDebug((LPCTSTR)csTmp);
		 }
		 }
		 for (int index=0;index<10;index++)
		 {
		 if(AF_INET == IfInf[index].iiNetmask.AddressIn.sin_family)
		 {
		 m_remoteAddress.sin_addr.S_un.S_addr = 
		 IfInf[index].iiAddress.AddressIn.sin_addr.S_un.S_addr | ~(IfInf[index].iiNetmask.AddressIn.sin_addr.S_un.S_addr);
		 break;
		 }
		 }
		 */
		m_remoteAddress.sin_port = htons(localport);
		m_remoteAddress.sin_family = AF_INET;
#else
		int nRet;
		int err;

		m_remoteAddress.sin_addr.S_un.S_addr = inet_addr(MCAST_ADDR);
		m_mReq.imr_multiaddr.s_addr = inet_addr(MCAST_ADDR);//224.0.23.167");
		m_mReq.imr_interface.s_addr = INADDR_ANY;
		nRet = setsockopt(s,IPPROTO_IP,IP_ADD_MEMBERSHIP,(char*)&m_mReq,sizeof(ip_mreq));
		if(nRet)
		{
			err = WSAGetLastError();
			Disconnect();
			bRet = false;
		}
		else
		{
#endif
		m_hEvent = CreateEvent(NULL, FALSE, FALSE, NULL);//L"Multicast-Event"); removed name so multiple clients on one machine can exist
		m_hCloseEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
#ifdef _MULTICAST
			nRet = setsockopt(s, IPPROTO_IP, IP_MULTICAST_IF, (char *)&addr,sizeof(addr)); 
			if(nRet)
			{
				err = WSAGetLastError();
			}
			int TTL = 2 ; 
			nRet = setsockopt(s, IPPROTO_IP, IP_MULTICAST_TTL,(char*)&TTL, sizeof(TTL));
			if(nRet)
			{
				err = WSAGetLastError();
			}
//			int loop = 1;
//			nRet = setsockopt(s, IPPROTO_IP, IP_MULTICAST_LOOP,(char*)&loop, sizeof(loop));
//			if(nRet)
//			{
//				err = WSAGetLastError();
//				sleep(100);
//			}
		}
#endif
	}
	return bRet;
}
//****************************************************************************
/// StartAcceptThr - since the acept function starts its listen thread suspended,
///			 this func will resume the thread when called
///
/// @param  n/a
///
/// @return			true if thread resumes successfully
///
//****************************************************************************
bool CMulticastSocket::StartAcceptThr() {
	if (-1 != ResumeThread(m_readThread))
		return true;
	else
		return false;
}
//****************************************************************************
/// OnClose - Override handler notification when the socket is closed
///
/// @param[in]	closeEvent - CESocket close type
///
/// @return			FALSE - as this method is not used
///
//****************************************************************************
void CMulticastSocket::OnClose(int closeEvent) {
	//the only one we're interested in is server down, as it means the server didn't start
	if (CCESocket::EVN_SERVERDOWN == closeEvent) {
		SetEvent(m_hCloseEvent);
	}
}

//****************************************************************************
// bool ::UpdateBroadcastAddr( ULONG ulPreferredAddr )
///
/// Call this to get the multicast socket to update the broadcast address it
/// uses. The origin of this method is probably to allow for change of IP
/// address because of renewed lease from DHCP server. Without this, the 
/// broadcast might stop working if we have moved to a different subnet.
///
/// @param[in]	ulPreferredAddr is the preferred connection to make.
///
/// @return true upon success, false otherwise.
//****************************************************************************
bool CMulticastSocket::UpdateBroadcastAddr(ULONG ulPreferredAddr) {
	bool bRet = false;
#ifndef _MULTICAST
	//determine netmask
	PMIB_IPADDRTABLE pIpTab = NULL;
	DWORD dwSizeReq = 0;
#ifdef TMS_DYNAMICLOADING

	QLibrary hm = NULL;
	hm = getIcmpLibray();
		
	if ( NULL != hm)
	{
		typedef DWORD (FAR PASCAL *PICMPGETIPADDRTABLE) (PMIB_IPADDRTABLE, PULONG, BOOL);
		PICMPGETIPADDRTABLE pIcmpGetIpAddrTable = NULL;

		(*(FARPROC*)&pIcmpGetIpAddrTable = GetProcAddress(hm, "GetIpAddrTable"));

		if ( NULL != pIcmpGetIpAddrTable )
		{
			DWORD dwRet = pIcmpGetIpAddrTable(pIpTab, &dwSizeReq, TRUE);
#else
	DWORD dwRet = GetIpAddrTable(pIpTab, &dwSizeReq, TRUE);
#endif	
	if (ERROR_INSUFFICIENT_BUFFER != dwRet) {
		qDebug(_T("GetIpAddrTable 1st calling error : %d\n"), dwRet);
	} else {
		BYTE *pbuff = new BYTE[dwSizeReq];
		assert(pbuff);
		pIpTab = (PMIB_IPADDRTABLE) pbuff;
#ifdef TMS_DYNAMICLOADING
		dwRet = pIcmpGetIpAddrTable(pIpTab, &dwSizeReq, TRUE);
#else
		dwRet = GetIpAddrTable(pIpTab, &dwSizeReq, TRUE);
#endif		
		if (NO_ERROR != dwRet) {
			qDebug(_T("GetIpAddrTable 2nd calling error : %d\n"), dwRet);
		} else {
			// Look for the preferred connection in the table entries.
			for (DWORD IfNo = 0; IfNo < pIpTab->dwNumEntries; ++IfNo) {
				if ((0 != ulPreferredAddr) && (LOOPBACK != ulPreferredAddr)
						&& (ulPreferredAddr == pIpTab->table[IfNo].dwAddr)) {
					// Found the preferred connection.
					m_remoteAddress.sin_addr.S_un.S_addr = pIpTab->table[IfNo].dwAddr | ~(pIpTab->table[IfNo].dwMask);
					bRet = true;
					break;
				}
			}

			if (false == bRet) {
				// Not found the preferred connection, any valid one will do.
				for (DWORD IfNo = 0; IfNo < pIpTab->dwNumEntries; ++IfNo) {
					if ((LOOPBACK != pIpTab->table[IfNo].dwAddr) && (0 != pIpTab->table[IfNo].dwAddr)) {
						// This will do.
						m_remoteAddress.sin_addr.S_un.S_addr = pIpTab->table[IfNo].dwAddr
								| ~(pIpTab->table[IfNo].dwMask);
						bRet = true;
						break;
					}
				}
			}

			delete[] pbuff;
		}
	}
#ifdef TMS_DYNAMICLOADING

		}
		else
		{
			qDebug(_T("GetIpAddrTable - GetProcAddress failed\n"));
			return false;
		}
	}
	else
	{
		qDebug(_T("GetIpAddrTable - GetProcAddress failed\n"));
		return false;
	}
	#endif
#endif
	return bRet;
}

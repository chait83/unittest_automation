/****************************************************************************

 //    COPYRIGHT (c) 2014
 //   HONEYWELL INTERNATIONAL INC.
 //   ALL RIGHTS RESERVED

 // Legal rights of Honeywell Inc. in this software is distinct from
 // ownership of any medium in which the software is embodied. 
 // Copyright notices must be reproduced in any copies authorized by 
 // Honeywell International Inc.
 /*****************************************************************************/

/// @file
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module:		Peer2Peer
/// @n Filename:	PeerDetails.h
/// @n Description:	PeerDetails hierarchy and and applicable types and 
///					enumerations to the peer services module.
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[5]:
//  46  Stability Project JZ 7/2/2014 4:59:36 PM Shankar Rao(HTS) 
// Stability Project: Encapsulating the peer details into a seperate
//			class hierarchy to provide runtime support of different recorder 
//			variants version GR of firmware to JZ version of XS firmware.  
//  45  Stability Project 1.42.1.1 7/2/2011 4:59:36 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  44  Stability Project 1.42.1.0 7/1/2011 4:27:48 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  43  V6 Firmware 1.42 8/28/2007 9:03:36 PM  Roger Dawson  
//  Modified the code so it checks for a master but updates the password
//  on the slave regardless. Also added extra dialogs which will
//  hopefully make it clearer to the user what is happening as some of
//  the password netsync task can be very time consuming and trick the
//  user into thinking the recorder has crashed.
//  42  V6 Firmware 1.41 8/17/2007 3:12:27 PM  Charles Boardman
//  Addressing build error in Comms Server
// $
//
// **************************************************************************
#ifndef __TRENDVIEW_PEER_DETAILS_H__
#define __TRENDVIEW_PEER_DETAILS_H__

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// Do not #include v6Globals.h in Comms Server or TrendServer Pro otherwise 
// complications arise around resource redefinitions, e.g. IDD_ABOUTBOX, 
// IDR_MAINFRAME, IDS_GREEN, IDS_RED, IDS_NO and IDS_YES 
#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TRENDSERVERPRO )) && ( ! defined ( TRENDMANAGERPRO ))
#include "v6Globals.h"
#else
	#if ! defined ( GENERALCONFIG_NAME_LEN )
		#define GENERALCONFIG_NAME_LEN 32
	#endif
	#if ! defined ( PWDNETSYNCINFO_GROUPNAME_LEN )
		#define PWDNETSYNCINFO_GROUPNAME_LEN 32
	#endif
	// Diagnostic and P2P messages are not applicable to Comms Server and TrendServer
	// Preprocess them into oblivion.
	#define LOG_DIAGNOSTIC_MESSAGE //
	#define MSGLISTSER_DIAGNOSTIC_ERROR		0
	#define MSGLISTSER_DIAGNOSTIC_WARNING	1
	#define MSGLISTSER_DIAGNOSTIC_INFO		2

	#define LOG_P2P_MESSAGE //
	#define MSGLISTSER_P2P_ERROR		0
	#define MSGLISTSER_P2P_WARNING		1
	#define MSGLISTSER_P2P_INFO			2
	#if ! defined ( V6_RELEASE )
		#define V6_RELEASE 0
	#endif
	#if ! defined ( RELEASE_ALPHA )
		#define RELEASE_ALPHA 1
	#endif
#endif

#pragma message ( "In PeerDetails.h, specificying the structure packing momentarily." )
#if ! defined (UNDER_CE) 
#pragma pack (show)
#endif
#pragma pack( push, 4 )
#if ! defined (UNDER_CE) 
#pragma pack (show)
#endif

// Value of NUM_FW_LETTERS is changed according new firmware version naming convention.
const USHORT NUM_FW_LETTERS = 2;
const USHORT NUM_ARISTOS_FW_LETTERS = 13;
const USHORT NUM_MAC = 6;
const int MAX_P2P_INIT_TIMEOUT = 1500;

// (Initial) Version 0 of peer details. Deprecated.
typedef struct peer_details_v0 {
	ULONG ulAddr;
	WCHAR wcFirmware[NUM_FW_LETTERS];
	ULONG ulSerial;
	ULONG ulNameLen;
	BYTE bModbusSlaveID;
	BYTE Unused;
	USHORT usRecorderID;
	WCHAR pwcName[GENERALCONFIG_NAME_LEN];
	WCHAR pwcNetName[GENERALCONFIG_NAME_LEN];
} T_PEER_DETAILS_V0;

// Version 1 of peer details. Deprecated.
typedef struct peer_details_v1 {
	ULONG ulStrucVersion;
	ULONG ulAddr;
	WCHAR wcFirmware[NUM_FW_LETTERS];
	ULONG ulNameLen;					//NameLen kept in same position in structure as old version
	ULONG ulNetNameLen;

	ULONG ulSerial;
	BYTE bModbusSlaveID;
	BYTE unused;
	UCHAR ucMAC[NUM_MAC];		//final 3 octets of the MAC address
	USHORT usRecorderID;
	WCHAR pwcName[GENERALCONFIG_NAME_LEN];
	WCHAR pwcNetName[GENERALCONFIG_NAME_LEN];
} T_PEER_DETAILS_V1;

// Version 2 of peer details. Deprecated.
typedef struct peer_details_v2 {
	ULONG ulStrucVersion;
	ULONG ulAddr;
	WCHAR wcFirmware[NUM_FW_LETTERS];
	ULONG ulNameLen;					//NameLen kept in same position in structure as old version
	ULONG ulNetNameLen;
	ULONG ulGroupNameLen;
	ULONG ulSerial;
	BYTE bModbusSlaveID;
	BYTE unused;
	USHORT usRecorderID;
	USHORT usGroupState;
	UCHAR ucMAC[NUM_MAC];		//final 3 octets of the MAC address
	// add any fixed vars *BEFORE* pwcName
	WCHAR pwcName[GENERALCONFIG_NAME_LEN]; //this item used to calculate struct size up to strings
	WCHAR pwcNetName[GENERALCONFIG_NAME_LEN];
	WCHAR pwcGroupName[GENERALCONFIG_NAME_LEN]; //add any strings on end
} T_PEER_DETAILS_V2;

//PSR Fix for PAR #1-1VKZOAA - GR recorder password does not synchronise with X-series begin
//Design considerations for Part 1 of solution:
////////1. Encapsulate Peer Data from the client so that they do not depend on structure changes
////////2. Provide the details through public methods to get the data and display on list
////////3. Override the recorder specific behavior in few vritual functions
////////4. Ensure backward compatibility
////////5. Final target would be to make it as a seperate dll to use accorss the clients
////////6. Consider TMS like client changes
////////7. Minimal impact of existing logic

//Design considerations for Part2 of the solution
////////1. Ensure no future changes required in XS/GR to identify furture recorders
////////2. Maintain backward compatibility to show old recorders
////////3. New packet to should compatible with old and should suffice for furture packets
////////4. Caution: To recognize future version existing packet format should change. This will bring inconsistency with
////////	previously released stream versions (packets) and structure type
////////5. Recommendations: 
////////	a) Never modify the format of existing stream version
////////	b) Never reuse old streams with new packets
////////	c) Always create a new stream if any changes are done to structure
////////	d) Always create a new stream if introduce any new recorder to network/product line
////////	e) Keep up the backward compatibility of structures and packets.
////////	f) Never change header of the structure if changed never allow that recorder into old nettworks

typedef union peer_id {
	ULONG ulStrucVersion;
	USHORT usPktHeader[2]; ///Split ULONG into two shorts
} T_PEER_ID;

//The header details to maintain the existing communcation packet and recorder identification 
//Considering from the X-Series as base.
typedef struct peer_header {
	T_PEER_ID tPeerId;
	ULONG ulAddr;
	WCHAR wcFirmware[NUM_FW_LETTERS];
	ULONG ulNameLen;					//NameLen kept in same position in structure as old version
	ULONG ulNetNameLen;
	ULONG ulGroupNameLen;
	ULONG ulSerial;
	BYTE bModbusSlaveID;
	BYTE unused;
	USHORT usRecorderID;
	USHORT usGroupState;
	USHORT usActivatedModules; //a flag set to indicate what external modules are active, e.g Password net sync
	UCHAR ucMAC[NUM_MAC];		//final 3 octets of the MAC address
} T_PEER_HEADER;

const USHORT g_usPeerHeaderSize = 42;

//The stream version is very critical to the network packet so follo P2P design and usage guildelines before adding
// new strean version. No way recommened for changing the existing stream version unless reusing this code in a new product line
//These stream versions are being used by X-Series (till JY but safecheck hase been in JX) and GR-Series (100.1 ,100.2(10R) and GR EzTrend 990.13B
const ULONG Glb_STREAM_VERSION_XSERIES = 0xFFFF0003; //FFFF prefix ensures no confusion with IP addresses from unversioned structure
const ULONG Glb_STREAM_VERSION_ARISTOS = 0xFFFF0004; //FFFF prefix ensures no confusion with IP addresses from unversioned structure
//TMS needs no new version as it uses aristos and can be differentiated with firmware string (AA and AB)

//PSR Solution 2 - The streamversion now is started with new approach and contains only USHORT version along with USHORT packet length
//Engineering solution:
//		Root cuases:	Packet is tightly coupled with structure (Pv3 and PV4) which are coupled with XS and GR code
//						1. right now packet contains PV3 and PV4 details and tighly coupled to Xs and GR code accordingly
//						2. Packet does not contain length of the packet in it.
//						3. So when new packet comes into network or stream XS/GR does not know how to parse and traverse thriugh all
//							other recorder packets
//		Solution	: 1-Decouple the code with structures and with GR/XS/TMS variants. 2- Add length in the packet.
//						1. Part one of the solution (DECOUPLE) is addressed by class heirarchy approach of olde generation Peers CTVPeer, CXSPeer, CGRPeer and CTMSPeer
//						2. Including packet length inside a packet will disturb the old packet header which is a major risk of breaking the old logic.
//						3. So ulStrucVersion..which is the heart of the old genration peers has been identified to address the issue.
//						4. Excluding SV3 and SV4 (stream versions 0xFFFF0003 & 0xFFFF0004) which are there in network (i.e. released to market) we add new stream
//							version SV5 which will be the base for new generation peers
//						5. SV5 will be framed with Length+streamversion in its ULONG stream version i.e 
//								( ULONG (old/new stream version)= USHORT(pkt length + USHORT(stream version) ) this brings backward and farward compatibility
//						6. SV5 (stream version 5) starts from 0005 (and grows up to SV65535 - USHORT max) by giving (45-minimum to 65535-maximum packet length)
//						7. All old and new generation stream versions and Peers requires minimum of 45 character header to make compatible and get identified in n/w.
///Start with version 5 as 3 & 4 versions with full packet length are in network
//These stream versions will be for all future recorder variants and ensures backward compatibility of previous stream versions
const ULONG Glb_STREAM_VERSION_5 = 0X00000005; //(0000, 0005) - Zero length 5th stream version

//***************************Begin SV6 -This is added for testing Furture recorder version*************
//const ULONG Glb_STREAM_VERSION_6 = 0X00000006; //(0000, 0005) - Zero length 6th stream version
//***************************End of SV6 ***************************************************************

//TMS needs no new version as it uses aristos and can be differentiated with firmware string (AA and AB)

// Current implementation of the peer details structure.
//when peer details are laid into a data stream, the fixed length strings are made variable
//for this, the size of the structure is often calculated as (<instance>.pwcName - <&instance>)
//so when adding new vars, add new strings on end, and other fixed length vars before pwcName
//typedef struct peer_details_v3{
typedef struct peer_details_v3 {
	ULONG ulStrucVersion;
	ULONG ulAddr;
	WCHAR wcFirmware[NUM_FW_LETTERS];
	ULONG ulNameLen;					//NameLen kept in same position in structure as old version
	ULONG ulNetNameLen;
	ULONG ulGroupNameLen;
	ULONG ulSerial;
	BYTE bModbusSlaveID;
	BYTE unused;
	USHORT usRecorderID;
	USHORT usGroupState;
	USHORT usActivatedModules; //a flag set to indicate what external modules are active, e.g Password net sync
	UCHAR ucMAC[NUM_MAC];

	// add any fixed vars *BEFORE* pwcName
	WCHAR pwcName[GENERALCONFIG_NAME_LEN]; //this item used to calculate struct size up to strings
	WCHAR pwcNetName[GENERALCONFIG_NAME_LEN];
	WCHAR pwcGroupName[PWDNETSYNCINFO_GROUPNAME_LEN]; //add any strings on end
} T_PEER_DETAILS_V3;
//}T_PEER_DETAILS_V3;

// Aristos has new firware format which requires 13 chars.... as we have to keep ulNameLen variable at the same position in struct
// as mentioned ablve we can not extend wcFirmware member so instead we have added new mem variable at the end of the strucute....
typedef struct peer_details_v4 {
	T_PEER_DETAILS_V3 tPeerV3;
	WCHAR wcAristosFirmware[NUM_ARISTOS_FW_LETTERS];

} T_PEER_DETAILS_V4;

//PSR Fix for PAR #1-1VKZOAA - GR recorder password does not synchronise with X-series begin
//Design considerations:
////////1. Encapsulate Peer Data from the client so that they do not depend on structure changes
////////2. Provide the details through public methods to get the data and display on list
////////3. Override the recorder specific behavior in few vritual functions
////////4. Ensure backward compatibility
////////5. Final target would be to make it as a seperate dll to use accorss the clients
////////6. Consider TMS like client changes
////////7. Minimal impact of existing logic

enum TV_PEER_TYPE {
	TV_DUMMY_PEER = 0, TV_XS_PEER,		//Stream Version 3 (SV3) Peer with PV3 structure and NO LENGTH field in packet
	TV_GR_PEER,			//Stream Version 4 (SV4) Peer with PV4 structure and NO LENGTH field in packet
	TV_TMS_PEER,		//Stream Version 4 (SV4) Peer with PV4 structure and NO LENGTH field in packet
	TV_SV5_PEER,		//Stream Version 5 (SV5) Peer with PV4 structure and LENGTH field in packet
	//***************************Begin SV6 -This is added for testing Furture recorder version*************
	//TV_SV6_PEER,	//Added for test -so reuse for next
	//***************************End of SV6 ***************************************************************

	TV_PEER_TYPES
};

class CTVPeer: public CObject {
	DECLARE_DYNAMIC (CTVPeer);
public:
	CTVPeer(TV_PEER_TYPE ePeerType, T_PEER_DETAILS_V3 &tPeerV3);
	virtual ~CTVPeer();
	virtual void Initialize() = 0;
	virtual void Override(CTVPeer *pPeer) = 0;
	virtual BOOL IsEqual(CTVPeer *pPeer) = 0;

	TV_PEER_TYPE getPeerType() const {
		return m_ePeerType;
	}
	ULONG getStructVersion() const {
		return m_tPeerV3.ulStrucVersion;
	}

	BYTE getModbusSlaveID() const {
		return m_tPeerV3.bModbusSlaveID;
	}
	ULONG getAddress() const {
		return m_tPeerV3.ulAddr;
	}
	virtual const WCHAR* getFirmware() const {
		return m_tPeerV3.wcFirmware;
	}
	ULONG getSerial() const {
		return m_tPeerV3.ulSerial;
	}
	USHORT getRecorderID() const {
		return m_tPeerV3.usRecorderID;
	}
	USHORT getGroupState() const {
		return m_tPeerV3.usGroupState;
	}
	USHORT getActivatedModules() const {
		return m_tPeerV3.usActivatedModules;
	}
	UCHAR* getMAC() const {
		return m_tPeerV3.ucMAC;
	}
	BYTE getTLSFlag() {
		return m_tPeerV3.unused;
	}

	const WCHAR* getName() const;
	const WCHAR* getNetName() const;
	const WCHAR* getGroupName() const;

	void setModbusSlaveID(BYTE byModbusAddress);
	void setAddress(ULONG ulAddr);
	void setSerial(ULONG ulSerial);
	void setRecorderID(USHORT usRecorderID);
	void setGroupState(USHORT usGroupState);
	void setActivatedModules(USHORT usActiveModules);
	void setMAC(UCHAR *ucMAC);

	virtual void setName(const QString chBuf);
	virtual void setNetName(const char *chBuf);
	virtual void setGroupName(const QString chBuf, ULONG ulLen = PWDNETSYNCINFO_GROUPNAME_LEN);

	virtual char* setPeerDetails(char *pTmpPtr);

	ULONG getFixedSize();
	virtual ULONG getStructSize();
	virtual char* getPeerDetails(char **buf);

	void getPeerHeader(T_PEER_HEADER &tPeerHeader) const;

private:
	CTVPeer(const CTVPeer&);
	CTVPeer& operator =(const CTVPeer&);

protected:
	virtual char* setVariableContent(char *pTmpPtr) = 0;
	virtual char* getVariableContent(char **buf) = 0;

protected:
	TV_PEER_TYPE m_ePeerType;

private:
	T_PEER_DETAILS_V3 &m_tPeerV3;

};

//Validator class for the peer (packet) on network.
class CTVPeerValidator {
public:
	CTVPeerValidator(T_PEER_ID tPeerId);
	CTVPeerValidator(const char *chPacket);
	CTVPeerValidator(const CTVPeer *pPeer);
	~CTVPeerValidator();

	BOOL isNetworkAcceptable();
	BOOL isDisplayable();
	T_PEER_ID getPeerId() const;
	T_PEER_HEADER getPeerHeader() const;

private:
	CTVPeerValidator(const CTVPeerValidator&);
	CTVPeerValidator& operator =(const CTVPeerValidator&);
	void Reset();

private:
	T_PEER_HEADER m_tPeerHeader;
	BOOL m_bIsAcceptable;
	BOOL m_bIsDisplayable;
};

//Simple facytory methods to create a TV Peers
class CTVPeerFactory {
public:
	static CTVPeer* createTVPeer(TV_PEER_TYPE ePeerType, ULONG ulnStrucVersion);
	static CTVPeer* createTVPeer(const CTVPeerValidator &tvPeerValidator, char *pMsg);
	static CTVPeer* cloneTVPeer(CTVPeer *pTVPeer);
};

//Linked list of CTVPeer's
class CTVPeerList {
public:
	CTVPeerList();
	~CTVPeerList();

	void addPeer(CTVPeer *pPeer);
	void appendPeer(CTVPeer *pPeer);
	CTVPeer* getPeer() {
		return m_pPeer;
	}
	CTVPeerList* getNext() {
		return m_pNext;
	}

	CTVPeer* getPeer(USHORT usIndex);

private:
	CTVPeerList(const CTVPeerList&);
	CTVPeerList& operator =(const CTVPeerList&);

private:
	CTVPeer *m_pPeer;
	CTVPeerList *m_pNext;

};

class CXSPeer: public CTVPeer {
	DECLARE_DYNAMIC (CXSPeer);
public:
	explicit CXSPeer(ULONG ulnStrucVersion);
	CXSPeer(const CXSPeer &xsPeer);
	explicit CXSPeer(const T_PEER_DETAILS_V3 &tPeerDetails);
	virtual ~CXSPeer();

	CXSPeer& operator =(const CXSPeer &rhs);

	virtual void Initialize();
	virtual void Override(CTVPeer *pPeer);
	virtual BOOL IsEqual(CTVPeer *pPeer);

protected:
	virtual char* setVariableContent(char *pTmpPtr);
	virtual char* getVariableContent(char **buf);

	T_PEER_DETAILS_V3 m_tPeerDetails;
};

class CGRPeer: public CTVPeer {
	DECLARE_DYNAMIC (CGRPeer);
public:
	explicit CGRPeer(ULONG ulnStrucVersion);
	CGRPeer(const CGRPeer &grPeer);
	explicit CGRPeer(const T_PEER_DETAILS_V4 &tPeerDetails);

	virtual ~CGRPeer();
	CGRPeer& operator =(const CGRPeer &rhs);

	virtual void Initialize();
	virtual void Override(CTVPeer *pPeer);
	virtual BOOL IsEqual(CTVPeer *pPeer);

	virtual const WCHAR* getFirmware() const;

	virtual ULONG getStructSize();

protected:
	virtual char* setVariableContent(char *pTmpPtr);
	virtual char* getVariableContent(char **buf);

	T_PEER_DETAILS_V4 m_tPeerDetails;
};

class CTMSPeer: public CGRPeer {
	DECLARE_DYNAMIC (CTMSPeer)
public:
	explicit CTMSPeer(ULONG ulnStrucVersion);
	CTMSPeer(const CTMSPeer &tmsPeer);
	explicit CTMSPeer(const T_PEER_DETAILS_V4 &tPeerDetails);

	virtual ~CTMSPeer();
	CTMSPeer& operator =(const CTMSPeer &rhs);

	virtual void Initialize();

};

//This is the stream version 5 peer (SV5) which will become the BASE of all new generation peers.
///New generation peers can be identified by SV5 details provided they wont change packer header
//and packet formation and versioning guidelines

//Recommended naming convention for new generation peers is SV5..SV6(sample written for test) ...SV7....
//No need to differentiate like GR, XS and TMS like peers ..that headache is only for old generation peers.

class CSV5Peer: public CTVPeer {
	DECLARE_DYNAMIC (CSV5Peer);
public:
	explicit CSV5Peer(T_PEER_ID tPeerId);	//, T_PEER_TYPE tOldGenPeerType);
	CSV5Peer(const CSV5Peer &sv5Peer);
	void setNetName(const char *chBuf);
	void setGroupName(const QString chBuf, ULONG ulLen);
	void setName(const QString chBuf);

	virtual ~CSV5Peer();
	CSV5Peer& operator =(const CSV5Peer &rhs);

	virtual void Initialize();
	virtual void Override(CTVPeer *pPeer);
	virtual BOOL IsEqual(CTVPeer *pPeer);

	virtual const WCHAR* getFirmware() const;

	virtual ULONG getStructSize();

	virtual char* setPeerDetails(char *pTmpPtr);
	virtual char* getPeerDetails(char **buf);

	static T_PEER_ID getPeerId(USHORT usStreamVersion, USHORT usPacketLen);	//New generation Peer Id
	static T_PEER_ID getPeerId(ULONG ulStructVersion); //Old generation peer id

	T_PEER_ID getPeerId();

protected:
	virtual char* setVariableContent(char *pTmpPtr);
	virtual char* getVariableContent(char **buf);
	void RefreshPeerId();

	T_PEER_DETAILS_V4 m_tPV4;
	T_PEER_ID m_tPeerId;
	//T_PEER_TYPE m_tOldGenPeerType;
};

//PSR Fix for PAR #1-1VKZOAA - GR recorder password does not synchronise with X-series end

//***************************Begin SV6 -This is added for testing Furture recorder version*************
//Added for test -so reuse for next

/*
 //
 class CSV6Peer : public CSV5Peer
 {
 DECLARE_DYNAMIC(CSV6Peer);
 public:
 explicit CSV6Peer (T_PEER_ID tPeerId);//, T_PEER_TYPE tOldGenPeerType);
 CSV6Peer ( const CSV6Peer & sv5Peer);
 virtual ~CSV6Peer();
 CSV6Peer & operator = (const CSV6Peer & rhs);

 virtual void Initialize();
 //virtual void Override(CTVPeer* pPeer);
 //virtual BOOL IsEqual(CTVPeer* pPeer);

 ULONG getStructSize();
 
 protected:
 virtual char* setVariableContent(char* pTmpPtr);
 virtual char* getVariableContent(char** buf);

 WCHAR m_wcTestString[GENERALCONFIG_NAME_LEN];
 };
 */
//***************************End of SV6 ***************************************************************
#pragma pack( pop )
#if ! defined (UNDER_CE) 
#pragma pack( show )
#endif
#pragma message ( "Finished pragma pack In PeerDetails.h and reverted to previous packing." )

#endif // __TRENDVIEW_PEER_DETAILS_H__

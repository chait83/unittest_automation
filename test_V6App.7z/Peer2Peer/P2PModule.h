/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Processing
/// @n Filename: DataProcessing.h
/// @n Desc:	 Perform all major operation for data processing
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  6 Stability Project 1.3.1.1 7/2/2011 4:59:36 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  5 Stability Project 1.3.1.0 7/1/2011 4:27:48 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  4 V6 Firmware 1.3 7/16/2007 3:22:45 PM  Roger Dawson  
//  Added various bits of code in order to stop an access violation on
//  shutdown. This code does not directly fix any problem as far as I can
//  tell but did seem to make things better.
//  3 V6 Firmware 1.2 11/13/2006 8:19:05 PM  Alistair Brugsch
//  added TCP and UDP port confugurable
// $
//
// ****************************************************************

#ifndef __P2PMODULE_H__
#define __P2PMODULE_H__

//#include "QueueManager.h"
//#include "QMDataBlock.h"
//#include "ProcessingThread.h"
//#include "Scripts.h"
//#include "sram.h"
//#include "tv6timer.h"
//#include "PPQManager.h"
//#include "V6globals.h"
#include "v6ActiveModule.h"
//#include "PenManager.h"
//#include "EventManager.h"
//#include "P2PModuleThread.h"
#include "P2PEngine.h"

// Execution modes for the Data processing thread
typedef enum {
	PM_MODE_IDLE,		///< Idle mode, when not in run mode and config being changed etc..
	PM_MODE_RUN,		///< Run mode, system is configured and running, process data as normal
	PM_MODE_EXIT		///< Exit mode, shutdown requested, exit thread

} T_P2PMOD_MODE;
//
//
//const int NO_MIN_COVERGE = 0;							///< No min coverage available after timeout, failure
//const int TEST_FOR_MIN_COVERAGE_TIMEOUT_SLEEP = 100;	///< sleep for this number of mSec between tests for minimum coverage available
//const int TEST_FOR_MIN_COVERAGE_TIMEOUT = 100;			///< Number of times to test for min coverage, before failing
//

//**Class*********************************************************************
///
/// @brief Control operations for the data processing thread
/// 
/// This class performs all coordination of the data processing, coordinating
/// the Pen Evaluation and overall timeline control
/// Will populate Pens, MaxMins, Totals, Alarms, ARV & Delays, Logging.
///
//****************************************************************************
class CP2PModule: public CV6ActiveModule {
public:
	CP2PModule(T_MODULE_ID moduleId);

	// Destructor
	~CP2PModule();

private:	// Member variables

	//class CP2PModuleThread *m_pThread;			///< ActiveModule Thread object
	class CP2PEngine *m_pP2PEngine;
	//class CPPQManager *m_pPreProcQ;				///< Handle on Pre Process Queues
	//LONGLONG m_minCoverage;						///< current minimum PPQ coverage
	//LONGLONG m_maxCoverage;						///< current maximum PPQ coverage

	//class CPenManager *m_pPenManager;			///< Handle on Pen manager
	//class CEventManager *m_pEventManager;		///< Handle on Event manager

	T_P2PMOD_MODE m_DPMode;				///< Data Processing Mode

	BOOL m_bFirstRun;

public:		// API methods

	T_V6ACTMOD_RETURN_VALUE PerformPrimaryInitialisation(void);
	T_V6ACTMOD_RETURN_VALUE PerformSecondaryInitialisation(void);

	//LONGLONG WaitToStartProcessing();
	//void ProcessData( BOOL IsLastDataProcess );
	//void ProcessEvents();

	T_P2PMOD_MODE GetMode();

	T_P2P_INIT_RETURN InitP2P(USHORT usTcp, USHORT usUdp) {
		if (m_pP2PEngine)
			return m_pP2PEngine->InitP2P(usTcp, usUdp);
		else
			return P2P_INIT_NO_INSTANCE;
	}
	//void DummyPenDataItems();	// test Pen Items

private:	// Methods

	BOOL CleanUp(void);
	//BOOL RequestTimeSliceDITPopulation();
	//BOOL GetNewMaximumCoverage();

	// Message callbacks actioned by HandleMessage
	T_V6ACTMOD_RETURN_VALUE NormalOperation(void);
	T_V6ACTMOD_RETURN_VALUE SetupConfigChangePreparation(void);
	T_V6ACTMOD_RETURN_VALUE SetupConfigChangeComplete(void);
	T_V6ACTMOD_RETURN_VALUE ShutdownPreparation(void);
	T_V6ACTMOD_RETURN_VALUE Shutdown(void);

	//member variables
	//int m_processSlices;						///< Number of slices to process on a pass
	//int m_NoCoverageFoundCounter;				///< Counter to detect the lack of covereage found

	//int m_lastUpdateInElapsedSeconds;			///< Last time the processing loop was run and elapsed at least 1 second
	//CDataItemGeneral *m_pIdleTimer;				///< ptr to Idle time data item
	//CDataItemGeneral *m_pMemLoad;				///< ptr to Memory load as a percentage data item
	//CDataItemGeneral *m_pMemTotal;				///< ptr to Physical Memory total in K data item
	//CDataItemGeneral *m_pMemAvail;				///< ptr to Physical Memory available in K data item
	//CDataItemGeneral *m_pVMemTotal;				///< ptr to Virtual Memory total in K data item
	//CDataItemGeneral *m_pVMemAvail;				///< ptr to Virtual Memory available in K data item
	//CDataItemGeneral *m_pVMemLowest;			///< ptr to Virtual Memory available low tide in K data item

	//// Q debug stats
	//CDataItemGeneral *m_pQMCPanel;
	//CDataItemGeneral *m_pQMCMess;
	//CDataItemGeneral *m_pQMCChart;
	//CDataItemGeneral *m_pQMCLog;
	//CDataItemGeneral *m_pQMCOther;
	//CDataItemGeneral *m_pQMCBlkRel;
	//CDataItemGeneral *m_pQMCHeart;

};

#endif //__DATAPROCESSING_H__


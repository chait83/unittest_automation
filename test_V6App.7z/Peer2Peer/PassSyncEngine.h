// PassSyncEngine.h: interface for the CPassSyncEngine class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PASSSYNCENGINE_H__738362C0_B16F_4963_A9BA_BA8928E78E4D__INCLUDED_)
#define AFX_PASSSYNCENGINE_H__738362C0_B16F_4963_A9BA_BA8928E78E4D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "V7DbgLogDefines.h"
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
	#include "CStorage.h"
#endif

#include "Token.h"
#include "V6globals.h"
#include "P2PEngine.h"
#include "PWInteractionEvent.h"

//#include "PNSCommsEngine.h"

typedef enum main_password_state {
	PASS_STATE_INDIVIDUAL,
	PASS_STATE_SLAVE_STATE,
	PASS_STATE_MASTER_STATE,
	PASS_STATE_INDETERMINATE,
	PASS_STATE_MASTER_STARTUP
} T_PASS_SYNC_STATES;

typedef struct peer_item {
	ULONG ulAddr;
	ULONG ulSerial;
	T_PASS_SYNC_STATES eState;
	USHORT usID;
	WCHAR wcName[GENERALCONFIG_NAME_LEN];
	WCHAR wcNetName[GENERALCONFIG_NAME_LEN];
	WCHAR wcGroupName[PWDNETSYNCINFO_GROUPNAME_LEN];
} T_PEER_ITEM;

typedef enum user_msg_types {
	SIN_USER_NONE, SIN_USER_ADD, SIN_USER_DELETE, SIN_USER_UNLOCK, SIN_USER_CHANGE_PWD
} T_SIN_USER_MSG_TYPES;

//data format is:
//USER_ADD,USER_DELETE,USER_UNLOCK: WCHAR string UserName
//USER_CHANGE_PASSWORD: WCHAR string UserName, WCHAR string Password (encoded)
typedef struct user_msg_format {
	T_SIN_USER_MSG_TYPES Type;
	ULONG Len;
	BYTE dataStub;
} T_USER_MSG_FORMAT;

typedef enum pw_sync_msgs {
	PW_PING, PW_TOKEN,
	//PW_PW_STATE,
	PW_JOIN_GROUP,
	PW_LEAVE_GROUP,
	PW_MASTER_CHANGE,
	PW_PMM_DATA,
	PW_POLICY_DATA,
	PW_USER_DATA,
	PW_FULL_USER_DATA,
	PW_ATTEMPT_FAIL,
	PW_GROUP_LIST,
	PW_ATTEMPT_SUCCESS,
	PW_MEMBERSHIP_CONFIRM
//		PW_QUERY_GROUP_AFF
} T_PW_SYNC_MSGS;

typedef enum pw_ping_types {
	PW_PING_SEND, PW_PING_RESP
} T_PW_PING_TYPES;
typedef enum pw_token_types {
	PW_TOKEN_REQ, PW_TOKEN_GRANT, PW_TOKEN_STEAL, PW_TOKEN_INFORM, PW_TOKEN_RELEASE
} T_PW_TOKEN_TYPES;
//	typedef enum pw_state_types{
//		PW_STATE_REQ,
//		PW_STATE_RESP
//	}T_PW_STATE_TYPES;

typedef enum pw_join_gorup_types {
	PW_JOIN_GRP_REQ, PW_JOIN_GRP_ACC, PW_JOIN_GRP_DENY, PW_JOIN_GRP_INV
} T_PW_JOIN_GROUP_TYPES;

typedef enum pw_leave_group_types {
	PW_LV_GRP_REQ, PW_LV_GRP_ACC, PW_LV_GRP_PUSH
} T_PW_LEAVE_GROUP_TYPES;

typedef enum pw_master_types {
	PW_MAST_CHG_PROM, PW_MAST_CHG_INF, PW_MAST_CHG_OVTH, PW_MAST_CHG_ACC, PW_MAST_CHG_DENY
} T_PW_MASTER_TYPES;

typedef enum pw_pmm_types {
	PW_PMM_REQ, PW_PMM_SEND, PW_PMM_ACC, PW_PMM_DENY
} T_PW_PMM_TYPES;

typedef enum pw_policy_types {
	PW_POLICY_REQ, PW_POLICY_SEND, PW_POLICY_ACC, PW_POLICY_DENY
} T_PW_POLICY_TYPES;

typedef enum pw_user_types {
	PW_USER_REQ, PW_USER_SEND, PW_USER_ACC, PW_USER_DENY
} T_PW_USER_TYPES;

typedef enum pw_full_user_types {
	PW_FULL_USER_REQ, PW_FULL_USER_SEND, PW_FULL_USER_ACC, PW_FULL_USER_DENY,
} T_PW_FULL_USER_TYPES;

typedef enum pw_group_types {
	PW_GROUPLIST_REQ, PW_GROUPLIST_UPD, PW_GROUPLIST_ACC, PW_GROUPLIST_DENY
} T_PW_GROUP_TYPES;

typedef enum pw_membership_conf_types {
	PW_MEMBERSHIP_CONF_REQ, PW_MEMBERSHIP_CONFIRMED, PW_MEMBERSHIP_CONF_DENY
} T_PW_MEMB_CONF_TYPES;

typedef struct pw_mod_data_hdr {
	T_INTERACTION_ID ID;
	BYTE bMsgType;
	BYTE bSubType;
} T_PW_MSG_HDR;
typedef struct pw_nv_config {
	T_PASS_SYNC_STATES State;
	WCHAR wcGroupName[GENERALCONFIG_NAME_LEN];
	USHORT usMasterSeqNum;
} T_NV_CONFIG;

struct interaction_index {
	ULONG ulRecipient;
	USHORT usIntIndex;
};

//Predefine PNS Comms Engine
class CPNSCommsEngine;

class CPassSyncEngine {
private:
	CPassSyncEngine();
	virtual ~CPassSyncEngine();

	//statics:
	static HANDLE m_CreationMutex;
	static CPassSyncEngine *m_pInstance;

	//Normo Vars:
	T_PEER_ITEM m_OurPeerDetails;
	T_PEER_ITEM m_OurMaster;
	BOOL m_bInitialised;
	HANDLE m_hListenThread;
	HANDLE m_hRegHandle;
	HANDLE m_hShutdown;
	//volatile T_PASS_SYNC_STATES m_MasterState;
	//WCHAR m_strGroupAffiliation[GENERALCONFIG_NAME_LEN];
	CTList<CPWInteractionEvent*> m_InteractionList;
	QMutex m_csInteractionList;
	CTList<T_PEER_ITEM*> m_PwdPeerList;
	QMutex m_csPeerList;
	CTList<T_PEER_ITEM*> m_GroupList;
	//QMutex m_csGroupList;
	CTList<T_PEER_ITEM*> m_OrphanList;
	QMutex m_csOrphanList;
	CToken m_Token;
	std::list<interaction_index*> m_MasterIDpList;

	QMutex m_csMasterIdList;
	T_PWDNETSYNCINFO m_SyncInfo;
	volatile BOOL m_bTokenInUseByMaster;	//may be waited on and set by 2 different threads
	T_NV_CONFIG *m_pNvConfig;
	HANDLE m_hStartupThread;
	USHORT m_usMasterSeqNum;
	bool m_bConnectionToMaster;
	bool m_bInError;
	HANDLE m_hPromoteEvent;
	QMutex m_csCommit;
	bool m_bCommitInProg;

	CV6MessageBoxDlg *m_pkNetSyncInfoDlg;

	//Static Methods:
	static DWORD WINAPI ListenThread(LPVOID pParam);
	static DWORD WINAPI StartupThread(LPVOID pParam);

	//Normo methods
	BOOL FetchAndProcessNewData();
	bool SendData(ULONG ulPeer, char *pData, ULONG ulDataLen, BOOL bAlert = FALSE);
	void CleanTransactions();

	void BuildSlaveList(QString   &cstrSlaveList);

	QString   ConvertScenarioTypeEnumToString(T_SCENARIO_TYPE te);
	QString   ConvertTransEnumToString(T_EVENT_ACTION te);
	QString   ConvertStateEnumToString(T_PASS_SYNC_STATES eState);
	QString   ConvertPwdSyncMsgToString(BYTE byPwdSync);
	QString   ConvertPwdPMMTypeToString(T_PW_PMM_TYPES te);

public:
	//static vars:

	//normo vars:

	//static funcs:
	static CPassSyncEngine* GetHandle();
	static BOOL IsInstantiated() {
		return (m_pInstance) ? TRUE : FALSE;
	}
	;

	// Method that determines if the password net sync system is running and passwords
	// are enabled
	static const bool IsPwdNetSyncRunning();

	// Method that determines if the password net sync master is online
	const bool MasterAvailable();

	//normo funcs
	void InitPassSyncEngine();
	BOOL IsInitialised() {
		return m_bInitialised;
	}
	;
	void ShutDownEngine();
	T_PASS_SYNC_STATES GetState() const;
	bool InitiateHealthCheck();
	BOOL InitiateJoinGroup(); // args: group name or master address, Transaction ID
	BOOL InitiateLeaveGroup(); // args:Hmmmmmmm.....
	bool SendTokenMsg(T_PW_TOKEN_TYPES type, T_INTERACTION_ID *pID, ULONG ulAddr = NULL);
	bool SendJoinGroupMsg(T_PW_JOIN_GROUP_TYPES type, T_INTERACTION_ID *pID, QString   csGroup, ULONG ulAddr = NULL);
	bool SendLeaveGroupMsg(T_PW_LEAVE_GROUP_TYPES type, T_INTERACTION_ID *pID, ULONG ulAddr = NULL);
	bool SendHealthCheck(T_PW_PING_TYPES type, T_INTERACTION_ID *pID, ULONG ulAddr = NULL);
	bool SendMasterChangeMsg(T_PW_MASTER_TYPES type, T_INTERACTION_ID *pID, ULONG ulNewMaster, ULONG ulAddr = NULL);
	bool SendFullPmmMsg(T_PW_PMM_TYPES type, T_INTERACTION_ID *pID, T_PMMDATA *pPmmData, T_PMMPOLICYDATA *pPolicy,
			T_PMMNVDATA *pNvData, ULONG ulAddr = NULL);
	bool SendPolicyMsg(T_PW_POLICY_TYPES type, T_INTERACTION_ID *pID, BYTE *pPolicyData, ULONG policyLen, ULONG ulAddr =
			NULL);
	bool SendAllUserMsg(T_PW_FULL_USER_TYPES type, T_INTERACTION_ID *pID, BYTE *pUsersData, ULONG usersLen,
			ULONG ulAddr = NULL);
	bool SendSinUserMsg(T_PW_USER_TYPES type, T_INTERACTION_ID *pID, QString   csUsername, T_SIN_USER_MSG_TYPES MsgType,
			BYTE *pUserData, ULONG userLen, ULONG ulAddr = NULL);
	bool SendPwAttemptFail(T_INTERACTION_ID *pID, QString   csUsername, ULONG ulAddr = NULL);
	bool SendPwAttemptSuccess(T_INTERACTION_ID *pID, QString   csUsername, ULONG ulAddr = NULL);
	bool SendGrouplistMsg(T_PW_GROUP_TYPES type, T_INTERACTION_ID *pID, ULONG ulAddr = NULL);
	bool SendGroupConfirmMsg(T_PW_MEMB_CONF_TYPES type, T_INTERACTION_ID *pID, ULONG ulAddr = NULL);
	bool NewInteractID(T_INTERACTION_ID &ID);
	ULONG GetIPFromSerial(ULONG ulSerial);
	bool ReleaseToken();
	BOOL PromoteSlave();
	BOOL AddUniqueGroupTail(T_PEER_ITEM *pItem);
	//For the full list of available peers. like get heard peers but PW specific
	const WCHAR* GetGroupName() {
		return m_OurPeerDetails.wcGroupName;
	}
	;

	// Accessor for the master name
	const QString   GetMasterName();

	// Accessor for the master net name
	const QString   GetMasterNetName();

	BOOL UpdatePeersList(BOOL Rescan = FALSE, BOOL InitialScan = FALSE);
	BOOL UIGetPeerList(T_PEER_ITEM **pDestList, ULONG *pCount);
	//gets the list of peers in the group
	BOOL UIGetGroupList(T_PEER_ITEM **pDestList, ULONG *pCount);
	const QString   UIGetAvailableGroups();
	const QString   GetSlaveList();
	//will get the slave peers and the un associated peers
	BOOL GetSlaveList(T_PEER_ITEM **pDestList, ULONG *pCount);
	BOOL UIJoinGroup();
	BOOL UIBecomeMaster(); //standalone must provide group name, Slave takes over current group
	BOOL UIAddRemoveSlave(); //provide Slave identifier....
	BOOL UIResignFromGroup(); //provide Slave to promote. become Slave yes/no
	ULONG GetSerialFromNetName(const QString wstrNetName);
	TOKEN_STATE GetToken(USHORT *pID, DWORD dwWait) {
		return m_Token.PeerRequestToken(pID, dwWait);
	}
	;
	TOKEN_STATE FinishWithToken(USHORT ID) {
		return m_Token.PeerFinishedWithToken(ID);
	}
	;
	BOOL TransGetToken(ULONG ID, DWORD dwTimeout);
	ULONG TransFinishWithToken(ULONG ID);
	const bool MasterSlaveCommsFailure() const {
		return (!m_bConnectionToMaster && (m_OurPeerDetails.eState == PASS_STATE_SLAVE_STATE));
	}
	void EnterCommitCS() {
		m_csCommit.lock();
	}
	;
	void LeaveCommitCS() {
		m_csCommit.lock();
	}
	;

	//public, but only CToken to use
	bool RequestToken();

	const bool UpdatePwdInfo(QString   &rstrErrorReport, T_PWDNETSYNCINFO *ptCurrInfo);
	const bool ValidatePwdNetSyncInfo(const T_PWDNETSYNCINFO &rtMODIFIED_INFO, QString   &rstrErrorReport,
			CWidget *pkParent);
	BOOL SelectSlaveToPromote(CWidget *pkParent);
	BOOL PromoteMe(CWidget *pkParent);
	void SetPeerType(T_PASS_SYNC_STATES State);
	void SetGroup(const QString strGroup);

	// Method that create list of slaves
	const bool ShowSlavePicker(QString   &rstrSlaveNetName, QString   &rstrErrorReport, T_PEER_ITEM **pItem,
			CWidget *pkParent = NULL);

	// Method that returns an array containing the serial numbers of all recorders within our group
	const int GetSerialNoList(ULONG *pulSerialNoList);

	//PSR Fix for PAR #1-1VKZOAA - GR recorder password does not synchronise with X-series
	// Method that confirms if a firmware version is compatible with this recorders firmware version
	const bool FirmwareCompatible(const QString pwcFirmwareVer);

	// Method that shows the contacting master modeless dialog
	void ShowContactingMasterDlg(CWidget *pkParent);

	// Method that hides the contacting master modeless dialog
	void HideContactingMasterDlg();

	//SPNS - PNS to PNS COmms integration begin
	bool isThisPeerPartOfOurGroup(ULONG ulAddr);

	const T_PEER_ITEM& GetOurPeer();
	const T_PEER_ITEM& GetMasterPeer();
	//SPNS - PNS to PNS COmms integration End

#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
public:	
	void LogDebugMessage(QString  strDebugMessage);
	void SetDebugLogger(CDebugFileLogger* pDbgFileLogger);
#endif

private:
	//SPNS - PNS to PNS COmms integration begin
	//Data members
#ifdef SPNS_ENABLE
	CPNSCommsEngine* m_pPnsCommsEngine;
#endif
	//SPNS - PNS to PNS COmms integration End

#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
	static CDebugFileLogger m_debugFileLogger;
	CDebugFileLogger* m_pDebugFileLogger;
#endif

};
#endif

/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Processing
/// @n Filename: ProcessingThread.h
/// @n Desc:	 Main Data processing thread 
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  7 Aristos  1.1.1.3.1.0 9/19/2011 4:51:17 PM  Hemant(HAIL)  
//  Stability recorder source code (JI Release) updated for WatchDog
//  Timer functionality.
//  6 Stability Project 1.1.1.3 7/2/2011 4:59:36 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  5 Stability Project 1.1.1.2 7/1/2011 4:38:34 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  4 Stability Project 1.1.1.1 3/17/2011 3:20:32 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
// $
//
// ****************************************************************

#include "P2PModuleThread.h"
#include "P2PModule.h"
#include "ThreadInfo.h"

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif

// IMPLEMENT_DYNCREATE(CP2PModuleThread, QThread)

CP2PModuleThread::CP2PModuleThread()
{
}

CP2PModuleThread::~CP2PModuleThread() {
}

BOOL CP2PModuleThread::InitInstance() {
	// TODO: perform and per-thread initialization here
	return TRUE;
}

int CP2PModuleThread::ExitInstance() {
	// TODO: perform any per-thread cleanup here
	return QThread::ExitInstance();
}

BEGIN_MESSAGE_MAP(CP2PModuleThread, QThread)
END_MESSAGE_MAP()

const int IDLE_MODE_SLEEP_MS = 20;

// CP2PModuleThread message handlers
UINT CP2PModuleThread::ThreadFunc(LPVOID lpParam) {
	CP2PModule *pModule = (CP2PModule*) lpParam;

	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//after each iteration
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();

	//Notify that the WatchdogTimer that the P2PModule thread has 
	//started
	if (pThreadInfo != NULL) {
		pThreadInfo->UpdateThreadInfo(AM_P2P_ENGINE, true);
	}

	//pModule->InitP2P();

#ifdef THREAD_ID_SERIAL_LOG
	  WCHAR szDbgMsg[512];
		swprintf( szDbgMsg, L"CP2PModuleThread::ThreadFunc-Thread id 0x%x, %lu ", GetThreadId(GetCurrentThread()), GetThreadId(GetCurrentThread()));
		OutputDebugString(szDbgMsg);
#endif

	while (pModule->GetMode() != PM_MODE_EXIT) {
		switch (pModule->EventMessageHandler(1000)) {
		case V6ACTMOD_EVENT_TIMEOUT:
			break;
		case V6ACTMOD_OK:

			break;

		default: /* Do Nothing */
			break;

		} // End of SWITCH
		 // If mode is set to RUN 
//		if( pModule->GetMode() == PM_MODE_RUN )
//		{
		//this thread doesn't need to do anything as the module is self contained

		//// Run mode has been entered so wait on available data in the pre-process queues
		//if( pModule->WaitToStartProcessing() > 0 )
		//{
		//	// Data Available, continually process data until run mode is exited
		//	while( pModule->GetMode() == DP_MODE_RUN )
		//	{
		//		// pModule->ProcessEvents();	

		//		pModule->ProcessData(FALSE);

		//		// sleep for at least one process interval
		//		sleep(pSYSTIMER->GetDataProcesssleep());	
		//	}
		//}
		/*
		 else
		 {
		 // No pre-process data found, do dummy data in run mode
		 // @todo remove this as will not be needed in final system
		 while(pModule->GetMode() == DP_MODE_RUN)
		 { 
		 pModule->DummyPenDataItems();
		 }
		 }
		 */
//		}
		// Message in IDLE mode
//		while( pModule->GetMode() == DP_MODE_IDLE )
//		{
		//sleep(IDLE_MODE_SLEEP_MS);
//		}
		if (pThreadInfo != NULL) {
			//Update the Thread Counter for the P2PModule thread
			//thread after each iteration
			pThreadInfo->UpdateThreadCounter(AM_P2P_ENGINE);
		}
	}

	//Update the info that the P2PModule thread is exiting
	//Hence this thread need not be considered to kick the 
	//watchdog
	if (pThreadInfo != NULL) {
		pThreadInfo->UpdateThreadInfo(AM_P2P_ENGINE, false);
	}

	return 0;
}

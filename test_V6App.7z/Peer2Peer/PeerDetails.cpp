/****************************************************************************

 //    COPYRIGHT (c) 2014
 //   HONEYWELL INTERNATIONAL INC.
 //   ALL RIGHTS RESERVED

 // Legal rights of Honeywell Inc. in this software is distinct from
 // ownership of any medium in which the software is embodied. 
 // Copyright notices must be reproduced in any copies authorized by 
 // Honeywell International Inc.
 /*****************************************************************************/

#include "PeerDetails.h"

//PSR Fix for PAR #1-1VKZOAA - GR recorder password does not synchronise with X-series begin
//Design considerations for Part 1 of solution:
////////1. Encapsulate Peer Data from the client so that they do not depend on structure changes
////////2. Provide the details through public methods to get the data and display on list
////////3. Override the recorder specific behavior in few vritual functions
////////4. Ensure backward compatibility
////////5. Final target would be to make it as a seperate dll to use accorss the clients
////////6. Consider TMS like client changes
////////7. Minimal impact of existing logic

//Design considerations for Part2 of the solution
////////1. Ensure no future changes required in XS/GR to identify furture recorders
////////2. Maintain backward compatibility to show old recorders
////////3. New packet to should compatible with old and should suffice for furture packets
////////4. Caution: To recognize future version existing packet format should change. This will bring inconsistency with
////////	previously released stream versions (packets) and structure type
////////5. Recommendations: 
////////	a) Never modify the format of existing stream version
////////	b) Never reuse old streams with new packets
////////	c) Always create a new stream if any changes are done to structure
////////	d) Always create a new stream if introduce any new recorder to network/product line
////////	e) Keep up the backward compatibility of structures and packets.
////////	f) Never change header of the structure if changed never allow that recorder into old nettworks
////////	g) Add the new peertypes into CTVPeerFactory whenever new peer type defined or new stream version added to P2P system

//Implementation Simple facytory methods to create a TV Peers
CTVPeer* CTVPeerFactory::createTVPeer(TV_PEER_TYPE ePeerType, ULONG ulnStrucVersion) {
	CTVPeer *pPeer = NULL;
	switch (ePeerType) {
	case TV_XS_PEER: {
		pPeer = new CXSPeer(ulnStrucVersion);
		break;
	}
	case TV_GR_PEER: {
		pPeer = new CGRPeer(ulnStrucVersion);
		break;
	}
	case TV_TMS_PEER: {
		pPeer = new CTMSPeer(ulnStrucVersion);
		break;
	}
	case TV_SV5_PEER: {
		//This would be always from network so we get ULONG varinat of peer id.
		T_PEER_ID tPeerId = CSV5Peer::getPeerId(ulnStrucVersion);
		pPeer = new CSV5Peer(tPeerId);
		break;
	}
		//***************************Begin SV6 -This is added for testing Furture recorder version*************
		//Added for test -so reuse for next
		/*
		 case TV_SV6_PEER:
		 {
		 //This would be always from network so we get ULONG varinat of peer id.
		 T_PEER_ID tPeerId = CSV5Peer::getPeerId(ulnStrucVersion);
		 pPeer = new CSV6Peer(tPeerId);
		 break;
		 }
		 */
		//***************************End of SV6 ***************************************************************
	default:
		pPeer = NULL;
	}

	return pPeer;
}

CTVPeer* CTVPeerFactory::createTVPeer(const CTVPeerValidator &tvPeerValidator, char *pMsg) {
	CTVPeer *pNewPeer = NULL;

	T_PEER_HEADER tPeerHeader = tvPeerValidator.getPeerHeader();
	ULONG ulnStrucVersion = tPeerHeader.tPeerId.ulStrucVersion;

	TV_PEER_TYPE ePeerType = TV_DUMMY_PEER;

	//Segregate if it is a TMS PEER
	if ((tPeerHeader.usRecorderID == 0)
			&& ((Glb_STREAM_VERSION_XSERIES == ulnStrucVersion) || (Glb_STREAM_VERSION_ARISTOS == ulnStrucVersion))) {
		ePeerType = TV_TMS_PEER;
	} else if (Glb_STREAM_VERSION_XSERIES == ulnStrucVersion) //Check if it is V3 (XSereis pkt stream)
			{
		ePeerType = TV_XS_PEER;
	} else if (Glb_STREAM_VERSION_ARISTOS == ulnStrucVersion) //Check if it is V4 (ARISTOS pkt stream)
			{
		ePeerType = TV_GR_PEER;
	} else if (tPeerHeader.tPeerId.usPktHeader[0] >= Glb_STREAM_VERSION_5) //This is for all new generation peer until specific peer comes to n/w
			{
		//This is crtical in deciding the default Peer to be displayed
		ePeerType = TV_SV5_PEER; //The default new PEER would be SV5 for all new generation Peer
	}
	//***************************Begin SV6 -This is added for testing Furture recorder version*************
	//Added for test -so reuse for next
	/*
	 else if (tPeerHeader.tPeerId.usPktHeader[0] >= Glb_STREAM_VERSION_6 ) //This is for all new generation peer until specific peer comes to n/w
	 {
	 //This is crtical in deciding the default Peer to be displayed
	 ePeerType = TV_SV6_PEER; //The default new PEER would be SV5 for all new generation Peer
	 }
	 */
	//***************************End of SV6 ***************************************************************
	else {
		ePeerType = TV_DUMMY_PEER;
	}

	if (TV_DUMMY_PEER != ePeerType) {
		pNewPeer = createTVPeer(ePeerType, ulnStrucVersion);
		if (NULL != pNewPeer) {
			pNewPeer->setPeerDetails(pMsg);
		}
	}

	return pNewPeer;
}

CTVPeer* CTVPeerFactory::cloneTVPeer(CTVPeer *pTVPeer) {
	CTVPeer *pPeer = NULL;
	if (NULL != pTVPeer) {
		switch (pTVPeer->getPeerType()) {
		case TV_XS_PEER: {
			pPeer = new CXSPeer(*(DYNAMIC_DOWNCAST(CXSPeer, pTVPeer)));
			break;
		}
		case TV_GR_PEER: {
			pPeer = new CGRPeer(*(DYNAMIC_DOWNCAST(CGRPeer, pTVPeer)));
			break;
		}
		case TV_TMS_PEER: {
			pPeer = new CTMSPeer(*(DYNAMIC_DOWNCAST(CTMSPeer, pTVPeer)));
			break;
		}
		case TV_SV5_PEER: {
			pPeer = new CSV5Peer(*(DYNAMIC_DOWNCAST(CSV5Peer, pTVPeer)));
			break;
		}
			//***************************Begin SV6 -This is added for testing Furture recorder version*************
			//Added for test -so reuse for next
			/*
			 case TV_SV6_PEER:
			 {
			 pPeer = new CSV6Peer(*(DYNAMIC_DOWNCAST(CSV6Peer, pTVPeer)));
			 break;
			 }
			 */
			//***************************End of SV6 ***************************************************************
		default:
			pPeer = NULL;
		}
	}

	return pPeer;
}

//CTVPeerList Implementation
CTVPeerList::CTVPeerList() {
	m_pPeer = NULL;
	m_pNext = NULL;
}

CTVPeerList::~CTVPeerList() {
	if (NULL != m_pPeer) {
		delete m_pPeer;
		m_pPeer = NULL;
	}

	if (NULL != m_pNext) {
		delete m_pNext;
		m_pNext = NULL;
	}
}

void CTVPeerList::addPeer(CTVPeer *pPeer) {
	if (pPeer) {
		m_pPeer = CTVPeerFactory::cloneTVPeer(pPeer);
	}
}

void CTVPeerList::appendPeer(CTVPeer *pPeer) {
	if (pPeer) {
		CTVPeerList *pNext = new CTVPeerList();
		pNext->addPeer(pPeer);
		m_pNext = pNext;
	}
}

CTVPeer* CTVPeerList::getPeer(USHORT usIndex) {
	CTVPeer *pPeer = NULL;
	USHORT usPeerNum = 0;

	if (0 == usIndex) {
		pPeer = getPeer();
	} else {
		CTVPeerList *pNext = getNext();

		while (pNext != NULL) {
			++usPeerNum;
			if (usPeerNum == usIndex) {
				pPeer = pNext->getPeer();
				break;
			} else {
				pNext = pNext->getNext();
			}
		}
	}

	return pPeer;
}

//Implementation if PeerValidator class for validating the peer (packet) on network.

CTVPeerValidator::CTVPeerValidator(T_PEER_ID tPeerId) : m_bIsAcceptable(TRUE), m_bIsDisplayable(TRUE) {
	Reset();
	m_tPeerHeader.tPeerId = tPeerId;
}

CTVPeerValidator::CTVPeerValidator(const char *chPacket) : m_bIsAcceptable(TRUE), m_bIsDisplayable(TRUE) {
	if (NULL != chPacket) {
		//We need to check is there any way to find the length of the network packet that is having minimum header size
		memcpy(&m_tPeerHeader, chPacket, g_usPeerHeaderSize);

		//PSR if variable content length is out of memory limits then discard the packet
		if ((m_tPeerHeader.ulGroupNameLen < 0 || m_tPeerHeader.ulGroupNameLen > PWDNETSYNCINFO_GROUPNAME_LEN)
				|| (m_tPeerHeader.ulNameLen < 0 || m_tPeerHeader.ulNameLen > GENERALCONFIG_NAME_LEN)
				|| (m_tPeerHeader.ulNetNameLen < 0 || m_tPeerHeader.ulNetNameLen > GENERALCONFIG_NAME_LEN)) {
			m_bIsAcceptable = FALSE;
			m_bIsDisplayable = FALSE;
		}
	} else {
		m_bIsAcceptable = FALSE;
		m_bIsDisplayable = FALSE;
	}
}

CTVPeerValidator::CTVPeerValidator(const CTVPeer *pPeer) : m_bIsAcceptable(TRUE), m_bIsDisplayable(TRUE) {
	if (NULL != pPeer) {
		pPeer->getPeerHeader(m_tPeerHeader);
	} else {
		m_bIsAcceptable = FALSE;
		m_bIsDisplayable = FALSE;
	}
}

CTVPeerValidator::~CTVPeerValidator() {
}

void CTVPeerValidator::Reset() {
	m_tPeerHeader.tPeerId.ulStrucVersion = 0;
	m_tPeerHeader.ulAddr = 0;

	m_tPeerHeader.wcFirmware[0] = L'\0';

	m_tPeerHeader.ulNameLen = 0;
	m_tPeerHeader.ulNetNameLen = 0;
	m_tPeerHeader.ulGroupNameLen = 0;

	m_tPeerHeader.ulSerial = 0;
	m_tPeerHeader.bModbusSlaveID = 0;

	m_tPeerHeader.usRecorderID = 0;
	m_tPeerHeader.usGroupState = 0;
	m_tPeerHeader.usActivatedModules = 0;

	m_tPeerHeader.ucMAC[0] = L'\0';
}

BOOL CTVPeerValidator::isNetworkAcceptable() {
	if (TRUE == m_bIsAcceptable) {
		if (Glb_STREAM_VERSION_ARISTOS == m_tPeerHeader.tPeerId.ulStrucVersion
				|| Glb_STREAM_VERSION_XSERIES == m_tPeerHeader.tPeerId.ulStrucVersion
				|| Glb_STREAM_VERSION_5 <= m_tPeerHeader.tPeerId.usPktHeader[0]) {
			m_bIsAcceptable = TRUE;
		} else {
			m_bIsAcceptable = FALSE;
		}
	}

	return m_bIsAcceptable;
}

BOOL CTVPeerValidator::isDisplayable() {
	if (TRUE == m_bIsDisplayable) {
		//Only TMS should be excluded from display.
		//TMS will have ID as 0, this will decide whether to display or not in Peer list.
		if (m_tPeerHeader.usRecorderID == 0) {
			m_bIsDisplayable = FALSE;
		} else {
			m_bIsDisplayable = TRUE;
		}
	}

	return m_bIsDisplayable;
}

T_PEER_ID CTVPeerValidator::getPeerId() const {
	return m_tPeerHeader.tPeerId;
}

T_PEER_HEADER CTVPeerValidator::getPeerHeader() const {
	return m_tPeerHeader;
}

/////Base Peer implementation
IMPLEMENT_DYNAMIC(CTVPeer, CObject)

CTVPeer::CTVPeer(TV_PEER_TYPE ePeerType, T_PEER_DETAILS_V3 & tPeerV3)
: m_ePeerType(ePeerType)
, m_tPeerV3(tPeerV3)
{
	// Default IP address, serial number and modbus slave id
	m_tPeerV3.ulStrucVersion = 0;
	m_tPeerV3.ulAddr = NULL;
	m_tPeerV3.ulSerial = 0;
	m_tPeerV3.bModbusSlaveID = 0;
	m_tPeerV3.ulNameLen = 0;
	m_tPeerV3.ulNetNameLen = 0;
	m_tPeerV3.ulGroupNameLen = 0;
	m_tPeerV3.usGroupState = 0;
	m_tPeerV3.usActivatedModules = 0;

	m_tPeerV3.pwcName[0] = NULL;
	m_tPeerV3.pwcGroupName[0] = NULL;
	m_tPeerV3.pwcNetName[0] = NULL;
}

CTVPeer::~CTVPeer() {
}

void CTVPeer::getPeerHeader(T_PEER_HEADER &tPeerHeader) const {
	tPeerHeader.tPeerId.ulStrucVersion = m_tPeerV3.ulStrucVersion;
	tPeerHeader.ulAddr = m_tPeerV3.ulAddr;

	for (int nFWIndex = 0; nFWIndex < NUM_FW_LETTERS; ++nFWIndex) {
		tPeerHeader.wcFirmware[nFWIndex] = m_tPeerV3.wcFirmware[nFWIndex];
	}

	tPeerHeader.ulNameLen = m_tPeerV3.ulNameLen;
	tPeerHeader.ulNetNameLen = m_tPeerV3.ulNetNameLen;
	tPeerHeader.ulGroupNameLen = m_tPeerV3.ulGroupNameLen;

	tPeerHeader.ulSerial = m_tPeerV3.ulSerial;
	tPeerHeader.bModbusSlaveID = m_tPeerV3.bModbusSlaveID;
	//tPeerHeader.unused = m_tPeerV3.unused;

	tPeerHeader.usRecorderID = m_tPeerV3.usRecorderID;
	tPeerHeader.usGroupState = m_tPeerV3.usGroupState;
	tPeerHeader.usActivatedModules = m_tPeerV3.usActivatedModules;

	for (int nMacIndex = 0; nMacIndex < NUM_MAC; ++nMacIndex) {
		tPeerHeader.ucMAC[nMacIndex] = m_tPeerV3.ucMAC[nMacIndex];
	}
}

void CTVPeer::setModbusSlaveID(BYTE byModbusAddress) {
	m_tPeerV3.bModbusSlaveID = byModbusAddress;
}

void CTVPeer::setAddress(ULONG ulAddress) {
	m_tPeerV3.ulAddr = ulAddress;
}

void CTVPeer::setSerial(ULONG ulSerial) {
	m_tPeerV3.ulSerial = ulSerial;
}

void CTVPeer::setRecorderID(USHORT usRecorderID) {
	m_tPeerV3.usRecorderID = usRecorderID;
}

void CTVPeer::setGroupState(USHORT usGroupState) {
	m_tPeerV3.usGroupState = usGroupState;
}

void CTVPeer::setActivatedModules(USHORT usActiveModules) {
	m_tPeerV3.usActivatedModules = usActiveModules;
}

const WCHAR* CTVPeer::getName() const {
	return (const WCHAR*) (&m_tPeerV3.pwcName[0]);
}

const WCHAR* CTVPeer::getNetName() const {
	return (const WCHAR*) (&m_tPeerV3.pwcNetName[0]);
}

const WCHAR* CTVPeer::getGroupName() const {
	return (const WCHAR*) (&m_tPeerV3.pwcGroupName[0]);
}
void CTVPeer::setNetName(const char *chBuf) {
#if ( (_MSC_VER < 1400 ) || defined(P2P_XSERIES) || defined(P2P_TMS) )

	mbstowcs(m_tPeerV3.pwcNetName, chBuf, GENERALCONFIG_NAME_LEN);
#else
		size_t pNoOfChars;
		mbstowcs_s(&pNoOfChars, m_tPeerV3.pwcNetName, sizeof(m_tPeerV3.pwcNetName)/sizeof(WCHAR), chBuf, GENERALCONFIG_NAME_LEN);
	#endif

	m_tPeerV3.ulNetNameLen = (ULONG) wcslen(m_tPeerV3.pwcNetName);
}

void CTVPeer::setGroupName(const QString chBuf, ULONG ulLen) {
#if (!defined (P2P_TMS) )
	wcsncpy_s(m_tPeerV3.pwcGroupName, sizeof(m_tPeerV3.pwcGroupName) / sizeof(WCHAR), chBuf, _TRUNCATE);
	m_tPeerV3.ulGroupNameLen = wcslen(m_tPeerV3.pwcGroupName);
#endif
}

void CTVPeer::setName(const QString chBuf) {
#if (!defined (P2P_TMS) )
	wcsncpy_s(m_tPeerV3.pwcName, sizeof(m_tPeerV3.pwcName) / sizeof(WCHAR), chBuf, _TRUNCATE);
	m_tPeerV3.ulNameLen = (ULONG) wcslen(m_tPeerV3.pwcName);
#endif
}

ULONG CTVPeer::getFixedSize() {
	ULONG usStrcutSize = (ULONG)(((char*) &m_tPeerV3.pwcName) - ((char*) &m_tPeerV3));
	return usStrcutSize;
}

ULONG CTVPeer::getStructSize() {
	//Get Fixed size
	ULONG ulLen = getFixedSize();
	//Get Variable size
	ulLen += ((m_tPeerV3.ulNameLen + 1 + m_tPeerV3.ulNetNameLen + 1 + m_tPeerV3.ulGroupNameLen + 1) * sizeof(WCHAR));
	return ulLen;
}

char* CTVPeer::setPeerDetails(char *pTmpPtr) {
	//Old implementation
	//
	//This seems to be header size always
	USHORT usHeaderSize = getFixedSize();
	memcpy(&m_tPeerV3, pTmpPtr, usHeaderSize);
	char *pTmpNext = pTmpPtr + (usHeaderSize);

	return setVariableContent(pTmpNext);
}

char* CTVPeer::setVariableContent(char *pTmpPtr) {
	//new string storage
	//copy string
	memcpy(m_tPeerV3.pwcName, pTmpPtr, (m_tPeerV3.ulNameLen + 1) * sizeof(WCHAR));
	pTmpPtr += (m_tPeerV3.ulNameLen + 1) * sizeof(WCHAR);

	memcpy(m_tPeerV3.pwcNetName, pTmpPtr, (m_tPeerV3.ulNetNameLen + 1) * sizeof(WCHAR));
	pTmpPtr += (m_tPeerV3.ulNetNameLen + 1) * sizeof(WCHAR);

	memcpy(m_tPeerV3.pwcGroupName, pTmpPtr, (m_tPeerV3.ulGroupNameLen + 1) * sizeof(WCHAR));
	pTmpPtr += (m_tPeerV3.ulGroupNameLen + 1) * sizeof(WCHAR);

	return pTmpPtr;
}

char* CTVPeer::getPeerDetails(char **pBuf) {
	char *pReturn = NULL;
	if (NULL != pBuf) {
		USHORT usHeaderSize = getFixedSize();

		char *pTmpPtr = (*(pBuf));
		memcpy(pTmpPtr, &m_tPeerV3, usHeaderSize);

		char *pVaraible = pTmpPtr + usHeaderSize;

		pReturn = getVariableContent(&pVaraible);
	}
	return pReturn;
}

char* CTVPeer::getVariableContent(char **pBuf) {
	char *pReturn = NULL;
	if (NULL != pBuf) {
		char *pVaraible = (*(pBuf));

		ULONG ulLen = ((m_tPeerV3.ulNameLen + 1) * sizeof(WCHAR));
		memcpy(pVaraible, m_tPeerV3.pwcName, ulLen);

		pVaraible += ulLen;
		ulLen = ((m_tPeerV3.ulNetNameLen + 1) * sizeof(WCHAR));
		memcpy(pVaraible, m_tPeerV3.pwcNetName, ulLen);

		pVaraible += ulLen;
		ulLen = ((m_tPeerV3.ulGroupNameLen + 1) * sizeof(WCHAR));
		memcpy(pVaraible, m_tPeerV3.pwcGroupName, ulLen);

		pVaraible += ulLen;
		pReturn = pVaraible;
	}

	return pReturn;
}

/////X-Series Peer implementation
IMPLEMENT_DYNAMIC(CXSPeer, CTVPeer)

CXSPeer::CXSPeer(ULONG ulnStrucVersion)
: CTVPeer(TV_XS_PEER, m_tPeerDetails)
{
	// Default IP address, serial number and modbus slave id
	m_tPeerDetails.ulStrucVersion = ulnStrucVersion;
}

CXSPeer::CXSPeer(const CXSPeer &xsPeer) : CTVPeer(TV_XS_PEER, m_tPeerDetails) {
	memcpy(&m_tPeerDetails, &(xsPeer.m_tPeerDetails), sizeof(m_tPeerDetails));
}

CXSPeer::CXSPeer(const T_PEER_DETAILS_V3 &pPeerDetails) : CTVPeer(TV_XS_PEER, m_tPeerDetails) {
	memcpy(&m_tPeerDetails, &pPeerDetails, sizeof(pPeerDetails));
}

CXSPeer::~CXSPeer() {
}

CXSPeer& CXSPeer::operator =(const CXSPeer &rhs) {
	if (this == &rhs)
		return (*this);

	memcpy(&m_tPeerDetails, &(rhs.m_tPeerDetails), sizeof(m_tPeerDetails));
	return (*this);
}

void CXSPeer::Initialize() {
#if (! defined (P2P_TMS) ) && (! defined (P2P_WRAPPER))
	T_PGENERALCONFIG pGenCfg;
	pGenCfg = pSETUP->GetGeneralSetupConfig()->GetSystemGeneralBlock(CONFIG_COMMITTED);
	wcsncpy_s(m_tPeerDetails.pwcName, sizeof(m_tPeerDetails.pwcName) / sizeof(WCHAR), pGenCfg->Name, _TRUNCATE);
	m_tPeerDetails.ulSerial = pSYSTEM_INFO->GetSerialNumber();
	if (wcslen(pDEVICE_INFO->GetFirmwareVersion()) <= NUM_FW_LETTERS) {
		memcpy(m_tPeerDetails.wcFirmware, pDEVICE_INFO->GetFirmwareVersion(), NUM_FW_LETTERS * sizeof(WCHAR));
	}
	m_tPeerDetails.usRecorderID = (USHORT) pGenCfg->ID;
	m_tPeerDetails.ucMAC[0] = pDEVICE_INFO->GetMACAddressOct(0);
	m_tPeerDetails.ucMAC[1] = pDEVICE_INFO->GetMACAddressOct(1);
	m_tPeerDetails.ucMAC[2] = pDEVICE_INFO->GetMACAddressOct(2);
	m_tPeerDetails.ucMAC[3] = pDEVICE_INFO->GetMACAddressOct(3);
	m_tPeerDetails.ucMAC[4] = pDEVICE_INFO->GetMACAddressOct(4);
	m_tPeerDetails.ucMAC[5] = pDEVICE_INFO->GetMACAddressOct(5);

	// Fill the name, serial number and firmware version.
	// The name buffer has been populated just above.
	m_tPeerDetails.ulNameLen = (ULONG) wcslen(m_tPeerDetails.pwcName);
#endif
}

void CXSPeer::Override(CTVPeer *pTVPeer) {
	CXSPeer *pPeer = DYNAMIC_DOWNCAST(CXSPeer, pTVPeer);

	if (NULL != pPeer) {
		//the new peer details take precedence over existing details
		if (wcsncmp(this->m_tPeerDetails.pwcName, pPeer->m_tPeerDetails.pwcName, GENERALCONFIG_NAME_LEN)) {
#if _MSC_VER < 1400 
			wcsncpy(this->m_tPeerDetails.pwcName, pPeer->m_tPeerDetails.pwcName, GENERALCONFIG_NAME_LEN);
#else
			wcsncpy_s(this->m_tPeerDetails.pwcName, sizeof(this->m_tPeerDetails.pwcName)/sizeof(WCHAR) , pPeer->m_tPeerDetails.pwcName,_TRUNCATE);
	#endif

		}

		if (wcsncmp(this->m_tPeerDetails.pwcNetName, pPeer->m_tPeerDetails.pwcNetName, GENERALCONFIG_NAME_LEN)) {
#if _MSC_VER < 1400 
			wcsncpy(this->m_tPeerDetails.pwcNetName, pPeer->m_tPeerDetails.pwcNetName, GENERALCONFIG_NAME_LEN);
#else
			wcsncpy_s(this->m_tPeerDetails.pwcNetName, sizeof(this->m_tPeerDetails.pwcNetName)/sizeof(WCHAR), pPeer->m_tPeerDetails.pwcNetName,_TRUNCATE);
	#endif
		}
		if (wcsncmp(this->m_tPeerDetails.pwcGroupName, pPeer->m_tPeerDetails.pwcGroupName, GENERALCONFIG_NAME_LEN)) {
#if _MSC_VER < 1400 
			wcsncpy(this->m_tPeerDetails.pwcGroupName, pPeer->m_tPeerDetails.pwcGroupName, GENERALCONFIG_NAME_LEN);
#else
			wcsncpy_s(this->m_tPeerDetails.pwcGroupName, sizeof(this->m_tPeerDetails.pwcGroupName)/sizeof(WCHAR), pPeer->m_tPeerDetails.pwcGroupName,_TRUNCATE);
	#endif

		}
		this->m_tPeerDetails.bModbusSlaveID = pPeer->m_tPeerDetails.bModbusSlaveID;
		this->m_tPeerDetails.ulAddr = pPeer->m_tPeerDetails.ulAddr;
		this->m_tPeerDetails.ulNameLen = pPeer->m_tPeerDetails.ulNameLen;
		this->m_tPeerDetails.ulNetNameLen = pPeer->m_tPeerDetails.ulNetNameLen;
		this->m_tPeerDetails.ulGroupNameLen = pPeer->m_tPeerDetails.ulGroupNameLen;
		this->m_tPeerDetails.ulStrucVersion = pPeer->m_tPeerDetails.ulStrucVersion;
		this->m_tPeerDetails.usActivatedModules = pPeer->m_tPeerDetails.usActivatedModules;
		this->m_tPeerDetails.usGroupState = pPeer->m_tPeerDetails.usGroupState;
		this->m_tPeerDetails.usRecorderID = pPeer->m_tPeerDetails.usRecorderID;

		//Check for newer firmware version format also.
		this->m_tPeerDetails.wcFirmware[0] = pPeer->m_tPeerDetails.wcFirmware[0];
		this->m_tPeerDetails.wcFirmware[1] = pPeer->m_tPeerDetails.wcFirmware[1];
	}
}

BOOL CXSPeer::IsEqual(CTVPeer *pTVPeer) {
	BOOL bRet = FALSE;
	CXSPeer *pPeer = DYNAMIC_DOWNCAST(CXSPeer, pTVPeer);

	if (NULL != pPeer) {
		if (memcmp(&(this->m_tPeerDetails), &(pPeer->m_tPeerDetails), sizeof(this->m_tPeerDetails)) == 0) {
			bRet = TRUE;
		}
	}
	return bRet;
}

char* CXSPeer::setVariableContent(char *pTmpPtr) {
	return CTVPeer::setVariableContent(pTmpPtr);
}

char* CXSPeer::getVariableContent(char **pBuf) {
	return CTVPeer::getVariableContent(pBuf);
}

/////GR-Series Peer implementation
IMPLEMENT_DYNAMIC(CGRPeer, CTVPeer)

CGRPeer::CGRPeer(ULONG ulnStrucVersion)
: CTVPeer(TV_GR_PEER, m_tPeerDetails.tPeerV3)
{
	// Default IP address, serial number and modbus slave id
	m_tPeerDetails.tPeerV3.ulStrucVersion = ulnStrucVersion;
	m_tPeerDetails.wcAristosFirmware[0] = NULL;
}

CGRPeer::CGRPeer(const CGRPeer &grPeer) : CTVPeer(TV_GR_PEER, m_tPeerDetails.tPeerV3) {
	memcpy(&m_tPeerDetails, &(grPeer.m_tPeerDetails), sizeof(m_tPeerDetails));
}

CGRPeer::CGRPeer(const T_PEER_DETAILS_V4 &pPeerDetails) : CTVPeer(TV_GR_PEER, m_tPeerDetails.tPeerV3) {
	memcpy(&m_tPeerDetails, &pPeerDetails, sizeof(pPeerDetails));
}

CGRPeer::~CGRPeer() {
}

CGRPeer& CGRPeer::operator =(const CGRPeer &rhs) {
	if (this == &rhs)
		return (*this);

	memcpy(&m_tPeerDetails, &(rhs.m_tPeerDetails), sizeof(m_tPeerDetails));
	return (*this);
}

void CGRPeer::Initialize() {
#if (! defined (P2P_TMS) ) && (! defined (P2P_WRAPPER))
	T_PGENERALCONFIG pGenCfg;
	pGenCfg = pSETUP->GetGeneralSetupConfig()->GetSystemGeneralBlock(CONFIG_COMMITTED);
	wcsncpy_s(m_tPeerDetails.tPeerV3.pwcName, sizeof(m_tPeerDetails.tPeerV3.pwcName) / sizeof(WCHAR), pGenCfg->Name,
			_TRUNCATE);
	m_tPeerDetails.tPeerV3.ulSerial = pSYSTEM_INFO->GetSerialNumber();

	if (wcslen(pDEVICE_INFO->GetFirmwareVersion()) <= NUM_ARISTOS_FW_LETTERS) {
		memcpy(m_tPeerDetails.wcAristosFirmware, pDEVICE_INFO->GetFirmwareVersion(),
				NUM_ARISTOS_FW_LETTERS * sizeof(WCHAR));
	}
	m_tPeerDetails.tPeerV3.usRecorderID = (USHORT) pGenCfg->ID;
	m_tPeerDetails.tPeerV3.ucMAC[0] = pDEVICE_INFO->GetMACAddressOct(0);
	m_tPeerDetails.tPeerV3.ucMAC[1] = pDEVICE_INFO->GetMACAddressOct(1);
	m_tPeerDetails.tPeerV3.ucMAC[2] = pDEVICE_INFO->GetMACAddressOct(2);
	m_tPeerDetails.tPeerV3.ucMAC[3] = pDEVICE_INFO->GetMACAddressOct(3);
	m_tPeerDetails.tPeerV3.ucMAC[4] = pDEVICE_INFO->GetMACAddressOct(4);
	m_tPeerDetails.tPeerV3.ucMAC[5] = pDEVICE_INFO->GetMACAddressOct(5);

	// Fill the name, serial number and firmware version.
	// The name buffer has been populated just above.
	m_tPeerDetails.tPeerV3.ulNameLen = (ULONG) wcslen(m_tPeerDetails.tPeerV3.pwcName);
//	m_tPeerDetails.tPeerV3.unused = 1;
#endif
}

void CGRPeer::Override(CTVPeer *pTVPeer) {
	CGRPeer *pPeer = DYNAMIC_DOWNCAST(CGRPeer, pTVPeer);

	if (NULL != pPeer) {
		//the new peer details take precedence over existing details
		if (wcsncmp(this->m_tPeerDetails.tPeerV3.pwcName, pPeer->m_tPeerDetails.tPeerV3.pwcName,
				GENERALCONFIG_NAME_LEN)) {
#if ( (_MSC_VER < 1400) || defined (P2P_TMS) )
			wcsncpy(this->m_tPeerDetails.tPeerV3.pwcName, pPeer->m_tPeerDetails.tPeerV3.pwcName,
					GENERALCONFIG_NAME_LEN);
#else
			wcsncpy_s(this->m_tPeerDetails.tPeerV3.pwcName, sizeof(this->m_tPeerDetails.tPeerV3.pwcName)/sizeof(WCHAR) , pPeer->m_tPeerDetails.tPeerV3.pwcName,_TRUNCATE);
	#endif

		}

		if (wcsncmp(this->m_tPeerDetails.tPeerV3.pwcNetName, pPeer->m_tPeerDetails.tPeerV3.pwcNetName,
				GENERALCONFIG_NAME_LEN)) {
#if _MSC_VER < 1400 
			wcsncpy(this->m_tPeerDetails.tPeerV3.pwcNetName, pPeer->m_tPeerDetails.tPeerV3.pwcNetName,
					GENERALCONFIG_NAME_LEN);
#else
			wcsncpy_s(this->m_tPeerDetails.tPeerV3.pwcNetName, sizeof(this->m_tPeerDetails.tPeerV3.pwcNetName)/sizeof(WCHAR), pPeer->m_tPeerDetails.tPeerV3.pwcNetName,_TRUNCATE);
	#endif
		}
		if (wcsncmp(this->m_tPeerDetails.tPeerV3.pwcGroupName, pPeer->m_tPeerDetails.tPeerV3.pwcGroupName,
				GENERALCONFIG_NAME_LEN)) {
#if _MSC_VER < 1400 
			wcsncpy(this->m_tPeerDetails.tPeerV3.pwcGroupName, pPeer->m_tPeerDetails.tPeerV3.pwcGroupName,
					GENERALCONFIG_NAME_LEN);
#else
			wcsncpy_s(this->m_tPeerDetails.tPeerV3.pwcGroupName, sizeof(this->m_tPeerDetails.tPeerV3.pwcGroupName)/sizeof(WCHAR), pPeer->m_tPeerDetails.tPeerV3.pwcGroupName,_TRUNCATE);
	#endif

		}
		this->m_tPeerDetails.tPeerV3.bModbusSlaveID = pPeer->m_tPeerDetails.tPeerV3.bModbusSlaveID;
		this->m_tPeerDetails.tPeerV3.ulAddr = pPeer->m_tPeerDetails.tPeerV3.ulAddr;
		this->m_tPeerDetails.tPeerV3.ulNameLen = pPeer->m_tPeerDetails.tPeerV3.ulNameLen;
		this->m_tPeerDetails.tPeerV3.ulNetNameLen = pPeer->m_tPeerDetails.tPeerV3.ulNetNameLen;
		this->m_tPeerDetails.tPeerV3.ulGroupNameLen = pPeer->m_tPeerDetails.tPeerV3.ulGroupNameLen;
		this->m_tPeerDetails.tPeerV3.ulStrucVersion = pPeer->m_tPeerDetails.tPeerV3.ulStrucVersion;
		this->m_tPeerDetails.tPeerV3.usActivatedModules = pPeer->m_tPeerDetails.tPeerV3.usActivatedModules;
		this->m_tPeerDetails.tPeerV3.usGroupState = pPeer->m_tPeerDetails.tPeerV3.usGroupState;
		this->m_tPeerDetails.tPeerV3.usRecorderID = pPeer->m_tPeerDetails.tPeerV3.usRecorderID;

		//Check for newer firmware version format also.
		for (int index = 0; index < NUM_ARISTOS_FW_LETTERS; index++) {
			this->m_tPeerDetails.wcAristosFirmware[index] = pPeer->m_tPeerDetails.wcAristosFirmware[index];
		}
	}
}

BOOL CGRPeer::IsEqual(CTVPeer *pTVPeer) {
	BOOL bRet = FALSE;
	CGRPeer *pPeer = DYNAMIC_DOWNCAST(CGRPeer, pTVPeer);

	if (NULL != pPeer) {
		if (memcmp(&(this->m_tPeerDetails), &(pPeer->m_tPeerDetails), sizeof(this->m_tPeerDetails)) == 0) {
			bRet = TRUE;
		}
	}
	return bRet;
}

const WCHAR* CGRPeer::getFirmware() const {
	return (const WCHAR*) (&m_tPeerDetails.wcAristosFirmware[0]);
}

ULONG CGRPeer::getStructSize() {
	ULONG ulLen = CTVPeer::getStructSize();
	ulLen += (NUM_ARISTOS_FW_LETTERS * sizeof(WCHAR));

	return ulLen;
}

char* CGRPeer::setVariableContent(char *pTmpPtr) {
	//new string storage
	//copy string
	char *pGrPtr = CTVPeer::setVariableContent(pTmpPtr);

	memcpy(m_tPeerDetails.wcAristosFirmware, pGrPtr, NUM_ARISTOS_FW_LETTERS * sizeof(WCHAR));
	pGrPtr += NUM_ARISTOS_FW_LETTERS * sizeof(WCHAR);

	return pGrPtr;
}

char* CGRPeer::getVariableContent(char **pBuf) {
	char *pReturn = NULL;
	if (NULL != pBuf) {
		char *pVaraible = (*(pBuf));

		pReturn = CTVPeer::getVariableContent(&pVaraible);

		memcpy(pReturn, m_tPeerDetails.wcAristosFirmware, ((NUM_ARISTOS_FW_LETTERS) * sizeof(WCHAR)));

		pReturn += ((NUM_ARISTOS_FW_LETTERS) * sizeof(WCHAR));
	}

	return pReturn;
}

/////TMS Peer implementation
IMPLEMENT_DYNAMIC(CTMSPeer, CGRPeer)

CTMSPeer::CTMSPeer (ULONG ulnStrucVersion)
: CGRPeer(ulnStrucVersion)
{
	m_ePeerType = TV_TMS_PEER;
}

CTMSPeer::CTMSPeer(const CTMSPeer &tmsPeer) : CGRPeer(tmsPeer) {
	m_ePeerType = TV_TMS_PEER;
	//memcpy(&m_tPeerDetails, &(tmsPeer.m_tPeerDetails), sizeof(m_tPeerDetails));
}

CTMSPeer::CTMSPeer(const T_PEER_DETAILS_V4 &tPeerDetails) : CGRPeer(tPeerDetails) {
	m_ePeerType = TV_TMS_PEER;
}

CTMSPeer::~CTMSPeer() {
}

CTMSPeer& CTMSPeer::operator =(const CTMSPeer &rhs) {
	if (this == &rhs)
		return (*this);

	CGRPeer::operator =(rhs);

	//memcpy(&m_tPeerDetails, &(rhs.m_tPeerDetails), sizeof(m_tPeerDetails));
	return (*this);
}

void CTMSPeer::Initialize() {
#if defined ( TRENDSERVERPRO ) || defined ( COMMS_SERVER ) 
		LPCSTR strAppName = AfxGetAppName();
		if ( NULL == strAppName )
		{
			// Unable to determine application name.
			wcscpy( m_tPeerDetails.tPeerV3.pwcName, L"-" );
		}
		else
		{
			int nameLength = strlen( strAppName );

			// Make sure we do not try to use more memory than is available in the
			// buffer.
			if ( nameLength > ( GENERALCONFIG_NAME_LEN - 1 ) )
			{
				nameLength = GENERALCONFIG_NAME_LEN - 1;
			}

			if ( nameLength < 0 )
			{
				// Should never get here, but you never know.
				wcscpy( m_tPeerDetails.tPeerV3.pwcName, L"-" );
			}
			else
			{
				// Copy the program name.
				mbstowcs( m_tPeerDetails.tPeerV3.pwcName, strAppName, nameLength );

				// Ensure it is null terminated as we have only copied across the
				// number of chars in the string (and so not the terminator).
				m_tPeerDetails.tPeerV3.pwcName[ nameLength ] = L'\0';
			}
		}
		// Fill the name, serial number and firmware version.
		// The name buffer has been populated just above.
		m_tPeerDetails.tPeerV3.ulNameLen = (ULONG) wcslen(m_tPeerDetails.tPeerV3.pwcName);

	#endif

#if defined ( TRENDSERVERPRO ) || defined ( TRENDMANAGERPRO ) 
		// Check for TRENDSERVERPRO must come before check for COMMS_SERVER
		// because TSP uses both preprocessor definitions whereas the Comms Server
		// only uses COMMS_SERVER.
		// AB for TrendServerPro
		m_tPeerDetails.tPeerV3.wcFirmware[0] = L'A';
		m_tPeerDetails.tPeerV3.wcFirmware[1] = L'B';

		m_tPeerDetails.wcAristosFirmware[0]	= L'A';
		m_tPeerDetails.wcAristosFirmware[1]	= L'B';
		m_tPeerDetails.tPeerV3.usRecorderID = 0;
	#elif defined ( COMMS_SERVER )
		// AA for Comms Server.
		m_tPeerDetails.tPeerV3.wcFirmware[0] = L'A';
		m_tPeerDetails.tPeerV3.wcFirmware[1] = L'A';
		m_tPeerDetails.wcAristosFirmware[0]	= L'A';
		m_tPeerDetails.wcAristosFirmware[1]	= L'A';
		m_tPeerDetails.tPeerV3.usRecorderID = 0;
	#endif

}

//PSR Fix for PAR #1-1VKZOAA - GR recorder password does not synchronise with X-series end

////////////////Part 2 of the solution Solution - New generation PEER development begin
/////GR-Series Peer implementation
IMPLEMENT_DYNAMIC(CSV5Peer, CTVPeer)

CSV5Peer::CSV5Peer(T_PEER_ID tPeerId)//, T_PEER_TYPE tOldGenPeerType)
: CTVPeer(TV_SV5_PEER, m_tPV4.tPeerV3)
, m_tPeerId(tPeerId)
{
	// Default IP address, serial number and modbus slave id
	m_tPV4.tPeerV3.ulStrucVersion = m_tPeerId.ulStrucVersion;
	m_tPV4.wcAristosFirmware[0] = NULL;

	//m_tOldGenPeerType = tOldGenPeerType;
}

CSV5Peer::CSV5Peer(const CSV5Peer &grPeer) : CTVPeer(TV_SV5_PEER, m_tPV4.tPeerV3) {
	memcpy(&m_tPV4, &(grPeer.m_tPV4), sizeof(m_tPV4));
	m_tPeerId = getPeerId(m_tPV4.tPeerV3.ulStrucVersion);

	//set the packet length in the header so that it will get parsed into packet
	ULONG ulLen = CTVPeer::getStructSize();
	ulLen += (NUM_ARISTOS_FW_LETTERS * sizeof(WCHAR));
	m_tPeerId.usPktHeader[1] = ulLen;
	m_tPV4.tPeerV3.ulStrucVersion = m_tPeerId.ulStrucVersion;
	//This is safe calculation
	//RefreshPeerId();
}

CSV5Peer::~CSV5Peer() {
}

CSV5Peer& CSV5Peer::operator =(const CSV5Peer &rhs) {
	if (this == &rhs)
		return (*this);

	memcpy(&m_tPV4, &(rhs.m_tPV4), sizeof(m_tPV4));

	//This is safe calculation
	RefreshPeerId();
	return (*this);
}

void CSV5Peer::Initialize() {
#if (! defined (P2P_TMS) ) && (! defined (P2P_WRAPPER))
	T_PGENERALCONFIG pGenCfg;
	pGenCfg = pSETUP->GetGeneralSetupConfig()->GetSystemGeneralBlock(CONFIG_COMMITTED);
	wcsncpy_s(m_tPV4.tPeerV3.pwcName, sizeof(m_tPV4.tPeerV3.pwcName) / sizeof(WCHAR), pGenCfg->Name, _TRUNCATE);
	m_tPV4.tPeerV3.ulSerial = pSYSTEM_INFO->GetSerialNumber();

	//For X-Series firmaware versions
	if (wcslen(pDEVICE_INFO->GetFirmwareVersion()) <= NUM_FW_LETTERS) {
		memcpy(m_tPV4.tPeerV3.wcFirmware, pDEVICE_INFO->GetFirmwareVersion(), NUM_FW_LETTERS * sizeof(WCHAR));
		memcpy(m_tPV4.wcAristosFirmware, pDEVICE_INFO->GetFirmwareVersion(), NUM_FW_LETTERS * sizeof(WCHAR));
		//m_tPV4.wcAristosFirmware[NUM_FW_LETTERS] = L'\0'; //This will not be good for next gen Peers
	} else if (wcslen(pDEVICE_INFO->GetFirmwareVersion()) <= NUM_ARISTOS_FW_LETTERS) {
		memcpy(m_tPV4.wcAristosFirmware, pDEVICE_INFO->GetFirmwareVersion(), NUM_ARISTOS_FW_LETTERS * sizeof(WCHAR));
	}

	m_tPV4.tPeerV3.usRecorderID = (USHORT) pGenCfg->ID;
	m_tPV4.tPeerV3.ucMAC[0] = pDEVICE_INFO->GetMACAddressOct(0);
	m_tPV4.tPeerV3.ucMAC[1] = pDEVICE_INFO->GetMACAddressOct(1);
	m_tPV4.tPeerV3.ucMAC[2] = pDEVICE_INFO->GetMACAddressOct(2);
	m_tPV4.tPeerV3.ucMAC[3] = pDEVICE_INFO->GetMACAddressOct(3);
	m_tPV4.tPeerV3.ucMAC[4] = pDEVICE_INFO->GetMACAddressOct(4);
	m_tPV4.tPeerV3.ucMAC[5] = pDEVICE_INFO->GetMACAddressOct(5);

	// Fill the name, serial number and firmware version.
	// The name buffer has been populated just above.
	m_tPV4.tPeerV3.ulNameLen = (ULONG) wcslen(m_tPV4.tPeerV3.pwcName);
m_tPV4.tPeerV3.unused = 1;

#elif ( defined ( TRENDSERVERPRO ) || defined ( COMMS_SERVER ) )
LPCSTR strAppName = AfxGetAppName();
if ( NULL == strAppName )
{
	// Unable to determine application name.
	wcscpy( m_tPV4.tPeerV3.pwcName, L"-" );
}
else
{
	int nameLength = strlen( strAppName );

	// Make sure we do not try to use more memory than is available in the
	// buffer.
	if ( nameLength > ( GENERALCONFIG_NAME_LEN - 1 ) )
	{
		nameLength = GENERALCONFIG_NAME_LEN - 1;
	}

	if ( nameLength < 0 )
	{
		// Should never get here, but you never know.
		wcscpy( m_tPV4.tPeerV3.pwcName, L"-" );
	}
	else
	{
		// Copy the program name.
		mbstowcs( m_tPV4.tPeerV3.pwcName, strAppName, nameLength );

		// Ensure it is null terminated as we have only copied across the
		// number of chars in the string (and so not the terminator).
		m_tPV4.tPeerV3.pwcName[ nameLength ] = L'\0';
	}
}
// Fill the name, serial number and firmware version.
// The name buffer has been populated just above.
m_tPV4.t
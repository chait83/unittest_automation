//////////////////////////////////////////////////////////////////////
/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Peer2Peer
/// @n Filename:  CPNSCommsEngine.h
/// @n Description: Definition of the CPNSCommsEngine class
///
// **************************************************************************
// Revision History
// **************************************************************************
// Project		Date			Team/Person			Comments
//	TVR211		26-Aug-2019		Shankar Rao P		Initial Draft
//
// **************************************************************************

#if !defined(_PNS_COMMS_ENGINE_H_INCLUDED_)
#define _PNS_COMMS_ENGINE_H_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "winnt.h"

#include "P2PEngine.h"
#include "Tcpsocket.h"

#pragma message ( "In PNSCommsEngine.h, specificying the structure packing momentarily." )
#if ! defined (UNDER_CE) 
#pragma pack (show)
#endif
#pragma pack( push, 4 )
#if ! defined (UNDER_CE) 
#pragma pack (show)
#endif

typedef enum ESPnSCommsEvents {
	SPNS_TCP_ACCEPT_CONN, //  - must stay in this order
	SPNS_TCP_ACCEPT_CLOSE,  //  |  handles after PNPShuttdown closed by cleanup
	SPNS_SHUTDOWN,		 // -
	SPNS_TCP_CONN_CLOSE,
	SPNS_TCP_SERV_FAIL,
	SPNS_ADD_OUT_CONN,
	SPNS_NUM_EVENTS
} T_SPNS_COMMS_EVENT_LIST;

//** CPNSCommsEngine **************************************************************
///
/// @brief The main class behind the Passowrd NetSyn Communication thru secure sockets.
//****************************************************************************
class CPNSCommsEngine {
public:
	CPNSCommsEngine(); //Later deside on whether to make it singleton
	~CPNSCommsEngine();

public:
	T_SPNS_INIT_RETURNS InitPnSComms();
	void Start();

	HANDLE GetExtModuleNotificationHandle(T_EXT_MOD_REG mod) {
		return (m_haExtModules[mod]) ? m_haExtModules[mod] : NULL;
	}
	;
	BOOL GetExtModuleMsg(T_EXT_MOD_REG mod, T_EXT_MOD_DATA *pData);
	ULONG GetExtModMsgCount(T_EXT_MOD_REG mod) {
		return m_ExtModuleDataList[mod].GetNumEntries();
	}
	;
	bool SendSPNSExtModData(T_EXT_MOD_REG mod, ULONG ulPeer, char *pData, ULONG ulDataLen);

	bool SendData(char *pBuf, ULONG len, CTcpSocket *pSock);

	void ShutDownEngine();
#ifdef DBG_FILE_LOG_SPNS_ENABLE
	void LogDebugMessage(QString  strDebugMessage);
#endif
private:
	void EvaluatePNSStateChange();
	void ProcessNewConn();
	bool AddEvent(HANDLE hEv);
	bool DeleteEvent(HANDLE hEv);
	void ParseData(CP2PEngine::T_ConnData *pDat);
	T_PROC_DATA_RET ProcessIncomingData(ULONG index);

	void DeleteDataItem(CP2PEngine::T_ConnData *pData);
	void PurgeConnList();

	CP2PEngine::T_ConnData* CreateTcpConn(QString   &addr, UINT remotePort, CTcpSocket **pSockResult = NULL);
	void AddNewConnEvents();
	CP2PEngine::T_ConnData* GetConnection(ULONG ulAddr, BOOL bTestOnly = FALSE);

	BOOL CleanUp(void);

	static DWORD WINAPI ListenThread(LPVOID pParam);

public:
	bool EndConnection(ULONG ulPeer, const bool bFORCE_CLOSE = false);

#ifdef DBG_FILE_LOG_SPNS_ENABLE
	void SetDebugLogger(CDebugFileLogger* pDbgFileLogger);
#endif

private:
	// Mutex for ensuring only a single instance of peer services is used.
	//static HANDLE m_CreationMutex;

	// Mutex for ensuring that an instance of peer 2 peer engine is initalised
	// at most one time.
	HANDLE m_hPNSCommsInit;

	// The TCP port number to use for Secure PNS.
	const USHORT m_usTcpPort;

	//Do we need OurPeer? here? Or do we depend on PNS Engine?

	// TRUE if enhanced security system is enabled, FALSE otherwise.
	//BOOL m_bEssEnabled; //Get this from PNS why o we need it here?

	// Set up in InitPNSComms, these are events always there regardless of what 
	// connections there are.
	HANDLE m_Events[SPNS_NUM_EVENTS];

	// Critical section for accessing m_pEvents.
	QMutex m_csEvents;

	// Stores dynamically sized array for holding all the standard event plus
	// an event for every TCP connection.
	HANDLE *m_pEvents;

	// Current count of event handles of interest, including TCP connections.
	int m_iEventCount;

	// Event handle for accepting new connections.
	HANDLE m_hAcceptedEv;

	// Event handles for the extension modules. Initially this is relevant to
	// password net synch and enhanced security system (ess), although ess 
	// isn't actually an extenstion module so to speak.
	HANDLE m_haExtModules[NUM_EXT_MODULES];

	// Holder for message data for processing by extension modules.
	CTList<T_EXT_MOD_DATA*> m_ExtModuleDataList[NUM_EXT_MODULES];

	// Critical section for safe access to m_ExtModuleDataList.
	QMutex m_csExtModDataList[NUM_EXT_MODULES];

	// The listening thread.
	HANDLE m_hDispThread;

	// Accepts TCP connections.
	CTcpSocket m_ListenSock;

	// The list of TCP connections that we have.
	CTList<CP2PEngine::T_ConnData*> m_connList;

	// Critical section for safe access to m_connList.
	QMutex m_csConnList;

	// Event handle for telling incoming connections to back off in the case
	// where the maximum number of TCP connections are currently being 
	// processed.
	HANDLE m_hListenBackOffEv;

#ifdef DBG_FILE_LOG_SPNS_ENABLE
	CDebugFileLogger* m_pDebugFileLogger;
#endif

};

#pragma pack( pop )
#if ! defined (UNDER_CE) 
#pragma pack( show )
#endif
#pragma message ( "Finished pragma pack In PNSCommsEngine.h and reverted to previous packing." )

#endif //#ifdef _PNS_COMMS_ENGINE_H_INCLUDED_

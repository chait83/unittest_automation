/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module:		Peer2Peer
/// @n Filename:	P2PEngine.h
/// @n Description:	CP2PEngine class declaration and applicable types and 
///					enumerations to the peer services module.
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  45  Stability Project 1.42.1.1 7/2/2011 4:59:36 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  44  Stability Project 1.42.1.0 7/1/2011 4:27:48 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  43  V6 Firmware 1.42 8/28/2007 9:03:36 PM  Roger Dawson  
//  Modified the code so it checks for a master but updates the password
//  on the slave regardless. Also added extra dialogs which will
//  hopefully make it clearer to the user what is happening as some of
//  the password netsync task can be very time consuming and trick the
//  user into thinking the recorder has crashed.
//  42  V6 Firmware 1.41 8/17/2007 3:12:27 PM  Charles Boardman
//  Addressing build error in Comms Server
// $
//
// **************************************************************************

#if !defined(AFX_P2PENGINE_H__738362C0_B16F_4963_A9BA_BA8928E78E4D__INCLUDED_)
#define AFX_P2PENGINE_H__738362C0_B16F_4963_A9BA_BA8928E78E4D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "multicastsocket.h"
#include "Tcpsocket.h"

//PAR #1-1VKZOAA - GR recorder password does not synchronise with X-series
#include "PeerDetails.h"

#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TRENDSERVERPRO )) && ( ! defined ( TRENDMANAGERPRO ))&& ( ! defined ( P2P_WRAPPER ))
#include "PassSyncEngine.h"
#endif

#pragma message ( "In P2PEngine.h, specificying the structure packing momentarily." )
#if ! defined (UNDER_CE) 
#pragma pack (show)
#endif
#pragma pack( push, 4 )
#if ! defined (UNDER_CE) 
#pragma pack (show)
#endif

//PAR #1-1VKZOAA - GR recorder password does not synchronise with X-series
class CTVPeer;
// Default port connections
const USHORT P2P_SET1_UDP_PORT = 8956;
const USHORT P2P_SET1_TCP_PORT = 8955;

typedef enum registered_external_modules {
	//add new modules here
	P2P_EXT_MODULE_PASSWORDS,
	P2P_EXT_MODULE_ESS, //not actually an external module, but need to use a flag to indicate ESS in the stream
	NUM_EXT_MODULES,
} T_EXT_MOD_REG;

typedef struct ext_module_data_item {
	ULONG ulPeer;
	char *pMsg;
	ULONG MsgLen;
} T_EXT_MOD_DATA;

typedef enum find_peer_return {
	PEER_NOT_FOUND, PEER_INVALID = 0xffffffff,
} T_FIND_PEER_RETURN;

typedef enum discover_sub_command {
	DISC_PEER, DISC_ARB,
} T_DISC_TYPE;

typedef enum resolve_state {
	RESOLVE_STARTUP, RESOLVE_INPROGRESS, RESOLVE_COMPLETE, RESOLVE_UNKNOWN, RESOLVE_RESCAN
} T_RESOLVE_STATES;

typedef enum p2p_commands {
	P2P_CMD_START,			//placeholder to prevent use
	DISCOVER,
	ARB_DECLARE,
	ARB_ASSIGN,
	ARB_CONFER,
	DISC_RESP_NO_ARB,
	REQUEST_DETAILS,
	SEND_DETAILS,
	DETAIL_RESP_OK,
	DETAIL_RESP_MISMATCH,
	PEER_LIST_REQUEST,
	PEER_LIST_SEND,
	ARB_END,
	EXT_MODULE,
	MAX_P2P_CMDS
} T_P2P_COMMANDS;

typedef enum proc_data_return {
	PROC_RET_OK, PROC_RET_NO_RECV_HANDLE, PROC_RET_NO_MEMORY, PROC_RET_READ_FAILED
} T_PROC_DATA_RET;

typedef enum p2p_init_return {
	P2P_INIT_OK,
	P2P_INIT_WINSOCK_ERR,
	P2P_INIT_INSTANCE_EXISTS,
	P2P_INIT_TCP_LISTEN_FAILED,
	P2P_INIT_UDP_LISTEN_FAILED,
	P2P_INIT_GET_ADDRINFO_FAILED,
	P2P_INIT_NO_INSTANCE,
	P2P_NETWORK_UNAVAILABLE
} T_P2P_INIT_RETURN, T_SPNS_INIT_RETURNS;

// Useful debug strings for connection events.
static const QString ConnEventTraceStrs[] = { L"SEND_DETAILS_OK", L"SEND_DETAILS_NOTOK", L"SEND_ARB_CONFER",
		L"SEND_REQ_DETAILS", L"SEND_DETAILS", L"SEND_REQ_PEER_LIST", L"CN_EV_SEND_PEER_LIST", L"SEND_YOURE_ARB",
		L"SEND_END_ARBITRATION", L"SEND_IM_ARB", L"SEND_ARB_END", L"RECV_DETAILS_OK", L"RECV_DETAILS_NOTOK",
		L"RECV_ARB_CONFER", L"RECV_REQ_DETAILS", L"RECV_DETAILS", L"RECV_REQ_PEER_LIST", L"RECV_PEER_LIST",
		L"CN_EV_RECV_YOURE_ARB", L"RECV_END_ARBITRATION", L"RECV_IM_ARB", L"RECV_ARB_END" };

// Useful debug strings for connection states.
static const QString ConnStateTraceStrs[] = { L"CONN_INIT", L"CONN_PEER_WAIT_ARB_CALL", L"CONN_PEER_LIST_RECVD",
		L"CONN_ARB_INIT_WAIT", L"CONN_ARB_REQ_DETAILS_FROM_PEER", L"CONN_ARB_RECVD_PEER_DETAILS",
		L"CONN_ARB_PEER_INVALID", L"CONN_ARB_PEER_PLIST_REQUESTED", L"CONN_ARB_PEER_PLIST_RECVD",
		L"CONN_ARB_RECVD_ARB_CONFER", L"CONN_ARB_CONFER_PLIST_REQD", L"CONN_ARB_CONFER_PLIST_RECVD",
		L"CONN_ARB_DISTRIB_FINAL_PLIST", L"CONN_PRE_INC_WAIT", L"CONN_PRE_SEND_DETAILS", L"CONN_INCOMING_CONN_END",
		L"CONN_PEER_ARB_REQ_SENT", L"CONN_PEER_DETAIL_REQ_RECVD", L"CONN_PEER_PLIST_REQ_RECVD",
		L"CONN_PEER_DISCONNECT_WAIT", L"CONN_ARB_PEER_UPD_PLIST_SENT", L"CONN_ARB_ARBITRATION_END",
		L"CONN_ARB_CONFER_START", L"CONN_ARB_CONF_DET_MISMATCH_SENT", L"CONN_ARB_CONF_DET_OK_SENT",
		L"CONN_ARB_CONF_PLIST_REQ_RECVD", L"CONN_ARB_CONF_FPLIST_RECVD", L"CONN_NORMAL" };

// Useful debug strings for main p2p engine states.
static const QString P2PMainStateTraceStrs[] = { L"STATE_START", L"STATE_INITIATE_DISCOVERY",
		L"STATE_PEER_VALIDATE_DETAILS", L"STATE_PEER_ARBITRATED", L"STATE_PEER_ARBITRATED_DENIED",
		L"STATE_PEER_CALLBACK_WAIT", L"STATE_PEER_LIST_UPDATED", L"STATE_ARBITRATOR",
		L"STATE_ARBITRATOR_COLLECT_PEER_INFO", L"STATE_ARBITRATOR_CONFER_WITH_MASTER_ARB",
		L"STATE_ARBITRATOR_CONFER_WITH_SLAVE_ARBS", L"STATE_ARBITRATOR_DISPATCH_PEER_INFO", L"STATE_MAIN_PEER",
		L"STATE_LAST_STATE" };

// Useful debug strings for main p2p engine events.
static const QString P2PMainEventTraceStrs[] = { L"NO_EVENT", L"DISCOVER_FROM_PEER", L"DISCOVER_FROM_ARBITRATOR",
		L"DISCOVER_RESPONSE_PEER_TO_ARB", L"DISCOVER_RESPONSE_YOURE_ARB", L"DISCOVER_OTHER_ARBITRATORS",
		L"CONNECTED_TO_ARBITRATOR", L"RECVD_ARB_CONFER", L"SEND_ARB_CONFER", L"DETAILS_DENIED", L"DETAILS_CONFIRMED",
		L"ARB_DETAILS_IN_CONF", L"ARB_DETAILS_OUT_CONF", L"ARB_DETAILS_OUT_DENIED", L"BECOME_ARBITRATOR",
		L"RECVD_NEW_PEER_LIST", L"RECVD_FULL_PEER_LIST", L"PEER_LIST_SENT_TO_ARB", L"PEER_LIST_COLLECTION_COMPLETE",
		L"END_OF_ARBITRATION", L"SHUTTING_DOWN", L"MAX_STATE_EVENTS" };

//** CP2PEngine **************************************************************
///
/// @brief The main class behind the Peer to Peer services functionality.
//****************************************************************************
class CP2PEngine {
public: //Making public so as to use it for PNS Comms engine as well
	static const USHORT MSG_OVHD;
	static const char EOT;
	static const USHORT APP_ID;

	// Origins of a connection. Is it incoming or outgoing?
	typedef enum conn_orig {
		CONN_ORIG_IN, CONN_ORIG_OUT
	} T_ConnOrig;

	//typedef enum arbitrator_states{
	//	ARB_COLLECT,
	//	ARB_CONFER_START,
	//	ARB_CONFER_MASTER,
	//	ARB_CONFER_SLAVE,
	//	ARB_DISPATCH
	//}T_ArbStates;

	typedef enum conn_event { //events that affect the state of the connection
		CN_EV_SEND_DETAILS_OK,
		CN_EV_SEND_DETAILS_NOTOK,
		CN_EV_SEND_ARB_CONFER,
		CN_EV_SEND_REQ_DETAILS,
		CN_EV_SEND_DETAILS,
		CN_EV_SEND_REQ_PEER_LIST,
		CN_EV_SEND_PEER_LIST,
		CN_EV_SEND_YOURE_ARB,
		CN_EV_SEND_END_ARBITRATION,
		CN_EV_SEND_IM_ARB,
		CN_EV_SEND_ARB_END,
		CN_EV_RECV_DETAILS_OK,
		CN_EV_RECV_DETAILS_NOTOK,
		CN_EV_RECV_ARB_CONFER,
		CN_EV_RECV_REQ_DETAILS,
		CN_EV_RECV_DETAILS,
		CN_EV_RECV_REQ_PEER_LIST,
		CN_EV_RECV_PEER_LIST,
		CN_EV_RECV_YOURE_ARB,
		CN_EV_RECV_END_ARBITRATION,
		CN_EV_RECV_IM_ARB,
		CN_EV_RECV_ARB_END
	} T_ConnEvent;

	typedef enum conn_status {
		CONN_INIT, CONN_PEER_WAIT_ARB_CALL,	//incoming connections
		CONN_PEER_LIST_RECVD,
		CONN_ARB_INIT_WAIT,			//arbitrator talking to peer
		CONN_ARB_REQ_DETAILS_FROM_PEER,
		CONN_ARB_RECVD_PEER_DETAILS,
		CONN_ARB_PEER_INVALID,
		CONN_ARB_PEER_PLIST_REQUESTED,
		CONN_ARB_PEER_PLIST_RECVD,
		CONN_ARB_RECVD_ARB_CONFER,	//master arbitrator talking to arbitrator
		CONN_ARB_CONFER_PLIST_REQD,
		CONN_ARB_CONFER_PLIST_RECVD,
		CONN_ARB_DISTRIB_FINAL_PLIST,
		CONN_PRE_INC_WAIT,			//undecided
		CONN_PRE_SEND_DETAILS,
		CONN_INCOMING_CONN_END,		//separator
		CONN_PEER_ARB_REQ_SENT,		//outgoing connections, Peer
		CONN_PEER_DETAIL_REQ_RECVD,
		CONN_PEER_PLIST_REQ_RECVD,
		CONN_PEER_DISCONNECT_WAIT,
		CONN_ARB_PEER_UPD_PLIST_SENT,		//Arb calling back a peer with updated info
		CONN_ARB_ARBITRATION_END,
		CONN_ARB_CONFER_START,		//Arb contacting master arb for confer
//		CONN_ARB_CONF_DETAILS_RECVD,
		CONN_ARB_CONF_DET_MISMATCH_SENT,
		CONN_ARB_CONF_DET_OK_SENT,
		CONN_ARB_CONF_PLIST_REQ_RECVD, //superfluous
		CONN_ARB_CONF_FPLIST_RECVD,
		CONN_NORMAL
	} T_ConnStatus;

	typedef struct conn_data {
		CTcpSocket *pCSock;		//pointer to socket class instance
		bool bIncoming;	//marks as incoming connection e.g. accepted
		QAbstractSocket sock;		//raw socket handle (may not be needed)
		ULONG addr;		//address of remote peer
		HANDLE hEvent;		//handle for recieve event
		char *pBuf;		//pointer to buffer if receive incomplete 
		ULONG bufLen;		//length of data in buffer
		bool bDataWait;	//indicator that there is data still to come
		bool bNewOutConn;
		T_ConnOrig connInOut;
		T_ConnStatus conStatus;
	} T_ConnData;

	typedef struct transport_packet {
		USHORT usAppID;
		USHORT usLen;
		USHORT usMsgId;
		USHORT usSrcID;
	} T_DataHdr;

private:
	typedef struct wait_buf_info {
		char *pData;
		ULONG ulPeerAddr;
		int iLength;
	} T_MsgInfo;

	CP2PEngine();
	virtual ~CP2PEngine();

	void ProcessNewConn();
	bool AddEvent(HANDLE hEv);
	bool DeleteEvent(HANDLE hEv);
	void ParseData(T_ConnData *pDat);
	void ParseMulticast(ULONG peer);
	void ProcessMulticastData();
	void DeleteDataItem(T_ConnData *pData);
	void PurgeConnList();
	T_PROC_DATA_RET ProcessIncomingData(ULONG index);
	T_ConnData* CreateTcpConn(QString   &addr, UINT remotePort, CTcpSocket **pSockResult = NULL);
	void AddNewConnEvents();
	bool SendP2PDiscResp(ULONG addr);
	T_ConnData* GetConnection(ULONG ulAddr, BOOL bTestOnly = FALSE);
	bool SendP2PImArb(ULONG addr);
	bool SendP2PYoureArb(ULONG addr);
	bool SendP2PRequestDetails(ULONG addr);
	bool SendP2PDetails(ULONG addr);
	bool SendP2PDetailRespOk(ULONG addr);
	bool SendP2PDetailRespMismatch(ULONG addr);
	bool SendP2PListRequest(ULONG addr);
	bool SendP2PPeerList(ULONG addr);
	bool SendP2PArbConfer(ULONG addr);
	bool SendP2PArbEnd(ULONG addr);
	void TraceLists(void);

	QString   ConvertConnStatusToString(T_ConnStatus conStat);
	QString   ConvertSocketStateToString(int conStatus);

	typedef enum {
		MULTICAST_RECV_DATA, // -
		MULTICAST_CLOSE, //  |
		TCP_ACCEPT_CONN, //  - must stay in this order
		TCP_ACCEPT_CLOSE,  //  |  handles after P2PShuttdown closed by cleanup
		P2P_SHUTDOWN,		 // -
		TCP_CONN_CLOSE,
		TCP_SERV_FAIL,
		ADD_OUT_CONN,
		NUM_EVENTS
	} T_EVENT_LIST;

public:

	/// The maximum number of P2P 'sets' allowable
	static const USHORT m_usMAX_SETS;

	bool SendP2PDiscReq();		 //public for testing - move to private

	static DWORD WINAPI ListenThread(LPVOID pParam);

	// Get pointer to the Peer Services engine singleton.
	static CP2PEngine* GetHandle();

	// Close down Peer Services doing relevant tidy up.
	BOOL CleanUp(void);

	// Initialises the Peer Services engine.
	T_P2P_INIT_RETURN InitP2P(USHORT usTcpPort = P2P_SET1_TCP_PORT, USHORT usUdpPort = P2P_SET1_UDP_PORT,
			ULONG ulLocalIPOverride = 0);

	bool SendData(char *pBuf, ULONG len, CTcpSocket *pSock = NULL);
	CTcpSocket* indexOfPeer(ULONG ulAddr, QString   csAddr = QString  (""));
	ULONG GetHeardPeerCount();

	//PSR Fix for PAR #1-1VKZOAA - GR recorder password does not synchronise with X-series begin
	bool GetHeardPeers(CTVPeerList **pPeerList, ULONG *pCount);
	void FreeHeardPeerList(CTVPeerList *pPeerList, ULONG Count);
	//PSR Fix for PAR #1-1VKZOAA - GR recorder password does not synchronise with X-series end

	T_RESOLVE_STATES GetListStatus();
	static CP2PEngine* TestHandle() {
		return m_pInstance;
	}
	;
	bool RebuildLocalDetails();
	bool EndConnection(ULONG ulPeer, const bool bFORCE_CLOSE = false);
	ULONG GetConnCount() {
		return m_connList.GetNumEntries();
	}
	;

private:
	// Used for specifying limit to the number of incoming socket connections 
	// that can be queued up.
	static const int m_iMAX_CONNECTION_BACKLOG;

	// Mutex for ensuring only a single instance of peer services is used.
	static HANDLE m_CreationMutex;

	// Mutex for ensuring that an instance of peer 2 peer engine is initalised
	// at most one time.
	HANDLE m_hP2PInit;

	// InitP2P can accpet an override local IP address which helps Comms Server
	// or TrendServer
	ULONG m_ulLocalIPOverride;

	// Singleton instance of the peer 2 peer services engine.
	static CP2PEngine *m_pInstance;

	// TRUE if P2P has been initialised. FALSE otherwise.
	BOOL m_bInitialised;

	// The listening thread.
	HANDLE m_hDispThread;

	// Listens for broadcast events.
	CMulticastSocket m_MultiSock;

	// Accepts TCP connections.
	CTcpSocket m_ListenSock;

	// Holds local (this machine's) version 4 IP address.
	SOCKADDR_IN m_LocAddrV4;

	//PSR Fix for PAR #1-1VKZOAA - GR recorder password does not synchronise with X-series begin
	// Local connection details.
	//T_PEER_DETAILS m_LocalDetails;
	CTVPeer *m_pLocalDetails;
	//PSR Fix for PAR #1-1VKZOAA - GR recorder password does not synchronise with X-series end

	// Critical section for safe access to m_LocalDetails.
	QMutex m_csLocalDetails;

	// Set up in InitP2P, these are events always there regardless of what 
	// connections there are.
	HANDLE m_Events[NUM_EVENTS];

	// Critical section for accessing m_pEvents.
	QMutex m_csEvents;

	// Stores dynamically sized array for holding all the standard event plus
	// an event for every TCP connection.
	HANDLE *m_pEvents;

	// Current count of event handles of interest, including TCP connections.
	int m_iEventCount;

	// Event handle for accepting new connections.
	HANDLE m_hAcceptedEv;

	// The list of TCP connections that we have.
	CTList<T_ConnData*> m_connList;

	// Critical section for safe access to m_connList.
	QMutex m_csConnList;

	// Holds UDP messages to help process multicasts/broadcasts.
	CTList<T_MsgInfo*> m_msgList;

	// Critical section for safe access to m_msgList.
	QMutex m_csMsgList;

	// Buffer and length used for broadcast data.
	char *m_pMultiDataBuf;
	ULONG m_ulMultiBufLen;

	// The TCP and UDP port numbers to use for Peer2Peer.
	USHORT m_usTcpPort;
	USHORT m_usUdpPort;

	// Event handle for telling incoming connections to back off in the case
	// where the maximum number of TCP connections are currently being 
	// processed.
	HANDLE m_hListenBackOffEv;

	// TRUE if somewhere (doesn't have to be locally) a rescan is in progress, 
	// FALSE otherwise.
	BOOL bRescanProg;

	// TRUE if enhanced security system is enabled, FALSE otherwise.
	BOOL m_bEssEnabled;

	// Event handles for the extension modules. Initially this is relevant to
	// password net synch and enhanced security system (ess), although ess 
	// isn't actually an extenstion module so to speak.
	HANDLE m_haExtModules[NUM_EXT_MODULES];

	// Holder for message data for processing by extension modules.
	CTList<T_EXT_MOD_DATA*> m_ExtModuleDataList[NUM_EXT_MODULES];

	// Critical section for safe access to m_ExtModuleDataList.
	QMutex m_csExtModDataList[NUM_EXT_MODULES];

	// Critical section for accessing to name in local details.
	// It would seem this is initially used in only one place so might not be
	// very helpful.
	QMutex m_csLocalName;

	/// Peer to Peer discovery state releted stuff below
	typedef enum p2p_states {
		STATE_START,				//generate a random wait timeout and listen for peers
		STATE_INITIATE_DISCOVERY,	//timeout expires and request a peer discovery
		//we've become arbitrated so we need to send details to the arbitrator
		STATE_PEER_VALIDATE_DETAILS,//we've had a list from arbitrator, compare to internal list and send differences back
		STATE_PEER_ARBITRATED,		//we've heard another peer and selected them as arbitrator
		STATE_PEER_ARBITRATED_DENIED, //need to hunt for a new arbitrator
		STATE_PEER_CALLBACK_WAIT,
		STATE_PEER_LIST_UPDATED,

		STATE_ARBITRATOR,			//divider. do not use

		STATE_ARBITRATOR_COLLECT_PEER_INFO,			//listen for list updates from peers
		STATE_ARBITRATOR_CONFER_WITH_MASTER_ARB,
		STATE_ARBITRATOR_CONFER_WITH_SLAVE_ARBS,			//send the list to the peers and close connections
		STATE_ARBITRATOR_DISPATCH_PEER_INFO,			//find other arbitrators and exchange lists
		STATE_MAIN_PEER,			//arbitration period is now over, free communication is now available

		STATE_LAST_STATE,			//state to indicate shutdown and end of enum
	} T_P2P_STATES;

	typedef enum p2p_state_events { //not thread events....
		NO_EVENT,
		DISCOVER_FROM_PEER,
		DISCOVER_FROM_ARBITRATOR,
		DISCOVER_RESPONSE_PEER_TO_ARB,
		DISCOVER_RESPONSE_YOURE_ARB,
		DISCOVER_OTHER_ARBITRATORS,
		CONNECTED_TO_ARBITRATOR,
		RECVD_ARB_CONFER,
		SEND_ARB_CONFER,
		DETAILS_DENIED,
		DETAILS_CONFIRMED,
		ARB_DETAILS_IN_CONF,
		ARB_DETAILS_OUT_CONF,
		ARB_DETAILS_OUT_DENIED,
		BECOME_ARBITRATOR,
		RECVD_NEW_PEER_LIST,
		RECVD_FULL_PEER_LIST,  //unnecessary?
		PEER_LIST_SENT_TO_ARB,
		PEER_LIST_COLLECTION_COMPLETE,
		END_OF_ARBITRATION,
		SHUTTING_DOWN,
		MAX_STATE_EVENTS
	} T_P2P_EVENTS;

	typedef struct arbitrated_list_item {
		T_ConnData *pConn;
		ULONG ulAddr;
		BOOL bDetailsRequested;
		BOOL bDetailsRecvd;
		BOOL bArbPlistRequested;
		BOOL bArbPlistRecvd;
		BOOL bConnected;
	} T_ARB_LIST_ITEM;

	// A flag for each event from T_P2P_EVENTS for identifying what needs to
	// be processed.
	BOOL m_discoveryEvent[MAX_STATE_EVENTS];

	// The current discovery state of the Peer2Peer engine.
	T_P2P_STATES m_discoveryState;

	//event for thread to wait on
	HANDLE m_hStateChangeEvent;

	// The thread for main Peer2Peer state changes.
	HANDLE m_hStateThread;

	// FALSE if there are one or more events to be processed. TRUE otherwise.
	volatile BOOL m_EventProcessed;

	// IP address of our arbitrator when we are being arbitrated.
	ULONG m_ulArbitrator;

	// The list of devices being arbitrated if we are arbitrating and critical
	// section for coordinated safe access.
	CTList<T_ARB_LIST_ITEM*> m_ArbitratedList;
	QMutex m_csArbList;

	// Master list of arbitrators for when arbitrators need to confer and 
	// critical section for coordinated safe access.
	CTList<T_ARB_LIST_ITEM*> m_MasterArbList;
	QMutex m_csMasterArbList;

	//PSR Fix for PAR #1-1VKZOAA - GR recorder password does not synchronise with X-series begin
	// The list of peers that this device knows about and critical section for
	// safe coordinated access.
	CTList<CTVPeer*> m_PeerList;
	QMutex m_csPeerList;

	// Backup list of peers for when the main peer list is unavailable for 
	// access. This is most useful to GetHeardPeers. 
	CTList<CTVPeer*> m_BackupPeerList;

	// Critical section for safe coordinated access to m_BackupPeerList.
	QMutex m_csBackupPeerList;
	//PSR Fix for PAR #1-1VKZOAA - GR recorder password does not synchronise with X-series end

	// Event handle for a significant arbitration event.
	HANDLE m_hArbitratorEvent;

	// TRUE if details from all peers have been collected.
	volatile BOOL m_bAllPeersCollected;

	// Set to TRUE when a confer of arbitrator has been identified as occurring.
	volatile BOOL m_bArbConferConfirmed;

	// TRUE if rebuild local details is allowed.
	volatile BOOL m_bRebuildAllow;

	// Handle on the arbitration thread.
	HANDLE m_hArbThread;

	// Master arbitrator details.
	T_ARB_LIST_ITEM m_pMasterArbitrator;

	// Local device name.
	WCHAR m_wstrLocalName[GENERALCONFIG_NAME_LEN];

//-------- Private methods

	// Clear the main peer list, always deleting the memory except for first
	// entry which is address of a data member.
	void ClearPeerList(void);

	// Clear the back up peer list, always deleting the memory except for
	// first entry which is always address of a data member.
	void ClearBackupPeerList(void);

	// Make a deep copy of the main peer list into the backup.
	void DeepCopyBackupOfMainPeerList(void);

	//PSR Fix for PAR #1-1VKZOAA - GR recorder password does not synchronise with X-series
	bool AddPeerToList(CTVPeer *pPeer, BOOL bOverride = FALSE);
	//State Transition Functions

	static DWORD WINAPI StateThread(LPVOID pParam);

	BOOL SetStateEvent(T_P2P_EVENTS ev);
	DWORD ProcessStateEvent(T_P2P_EVENTS ev);

	void ChangeConnState(T_ConnEvent ev, T_ConnData *pConn, char *pMsg = NULL, ULONG len = 0);
	static DWORD WINAPI ArbitratorThread(LPVOID pParam);

public:
	HANDLE GetExtModuleNotificationHandle(T_EXT_MOD_REG mod) {
		return (m_haExtModules[mod]) ? m_haExtModules[mod] : NULL;
	}
	;
	BOOL GetExtModuleMsg(T_EXT_MOD_REG mod, T_EXT_MOD_DATA *pData);
	ULONG GetExtModMsgCount(T_EXT_MOD_REG mod) {
		return m_ExtModuleDataList[mod].GetNumEntries();
	}
	;
	bool SendP2PExtModData(T_EXT_MOD_REG mod, ULONG ulPeer, char *pData, ULONG ulDataLen);
	BOOL IsInitialised() {
		return m_bInitialised;
	}
	;
	BOOL InitiateRescan();
	void PreventRebuild() {
		m_bRebuildAllow = FALSE;
	}
	;
	void AllowRebuild() {
		m_bRebuildAllow = TRUE;
	}
	;

	BOOL IsPeerLegal(ULONG ulAddr);

#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TRENDSERVERPRO ) ) && (! defined (P2P_WRAPPER))
	// Method that updates the master information in the peer list - this will prevent the
	// password error dialog being displayed between creating a group and a rescan
	void UpdateMasterInfo(const ULONG ulMASTER_SERIAL_NO, const QString pwcGROUPNAME);
#endif

};

#if defined ( TTR6SETUP )
const USHORT CP2PEngine::m_usMAX_SETS = 8;
#endif

#pragma pack( pop )
#if ! defined (UNDER_CE) 
#pragma pack( show )
#endif
#pragma message ( "Finished pragma pack In P2PEngine.h and reverted to previous packing." )

#endif // !defined(AFX_P2PENGINE_H__738362C0_B16F_4963_A9BA_BA8928E78E4D__INCLUDED_)

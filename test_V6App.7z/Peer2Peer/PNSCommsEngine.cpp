//////////////////////////////////////////////////////////////////////
/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Peer2Peer
/// @n Filename:  PNSCommsEngine.cpp
/// @n Description: Implementation of the CPNSCommsEngine class
///
// **************************************************************************
// Revision History
// **************************************************************************
// Project		Date			Team/Person			Comments
//	TVR211		26-Aug-2019		Shankar Rao P		Initial Draft
//	TVR211		28-Aug-2019		Shankar Rao P		PNS Comms Engine Startup Sequence
//
// **************************************************************************

#include "PNSCommsEngine.h"
#include "ThreadInfo.h"
#include "PassSyncEngine.h"

#include "V7TLSUtilities.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CPNSCommsEngine::CPNSCommsEngine() : m_usTcpPort(5361) //Fixed port number for Secure PNS communicaton
#ifdef SPNS_NON_SECURE_MODE
, m_ListenSock() //Ensure Secure Mode
#else
		, m_ListenSock(CCESecureSocket::ST_MODE_SECURE) //Ensure Secure Mode
#endif
#ifdef DBG_FILE_LOG_SPNS_ENABLE
, m_pDebugFileLogger(NULL) //Sett he available static member by default
#endif
{
	m_pEvents = &m_Events[0];
	m_iEventCount = SPNS_NUM_EVENTS;

	m_hPNSCommsInit = NULL;
	m_hDispThread = NULL;
	m_hAcceptedEv = NULL;
	m_hListenBackOffEv = NULL;

	//Maintianig the connection list
	QMutex* m_csConnList;

	//Maintaining the QAbstractSocket/PNS events
	QMutex* m_csEvents;

	//Maintaing the PNSEngine/ESS Data Events
	for (int count = 0; count < NUM_EXT_MODULES; ++count) {
		//Initialize the event handle
		m_haExtModules[count] = NULL;
		//Init critical section
		InitializeCriticalSection(&m_csExtModDataList[count]);
	}
}

CPNSCommsEngine::~CPNSCommsEngine() {
	//deletion of mutex not required
	//deletion of mutex not required

	for (int count = 0; count < NUM_EXT_MODULES; ++count) {
		DeleteCriticalSection(&m_csExtModDataList[count]);
	}

	//If theyare not the predefined allocation, need to clean/delete memory
	if (m_pEvents != &m_Events[0]) {
		delete[] m_pEvents;
	}

	//PNS Shutdown event
	if (m_Events[SPNS_SHUTDOWN]) {
		CloseHandle(m_Events[SPNS_SHUTDOWN]);
		m_Events[SPNS_SHUTDOWN] = NULL;
	}

	if (m_Events[SPNS_TCP_CONN_CLOSE]) {
		CloseHandle(m_Events[SPNS_TCP_CONN_CLOSE]);
		m_Events[SPNS_TCP_CONN_CLOSE] = NULL;
	}

	//SECURE TCP SCCEPT CLOSED
	if (m_Events[SPNS_TCP_ACCEPT_CLOSE]) {
		CloseHandle(m_Events[SPNS_TCP_ACCEPT_CLOSE]);
		m_Events[SPNS_TCP_ACCEPT_CLOSE] = NULL;
	}

	//SECURE TCP SERV FAILED
	if (m_Events[SPNS_TCP_SERV_FAIL]) {
		CloseHandle(m_Events[SPNS_TCP_SERV_FAIL]);
		m_Events[SPNS_TCP_SERV_FAIL] = NULL;
	}

	//SECURE TCP OUT OF CONN
	if (m_Events[SPNS_ADD_OUT_CONN]) {
		CloseHandle(m_Events[SPNS_ADD_OUT_CONN]);
		m_Events[SPNS_ADD_OUT_CONN] = NULL;
	}
}

//****************************************************************************
/// InitPnSComms - Initialize the PNS communication engine
///
///
/// @return - nothing
/// 
//****************************************************************************
T_SPNS_INIT_RETURNS CPNSCommsEngine::InitPnSComms() {
#ifdef DBG_FILE_LOG_SPNS_ENABLE		
	QString  strLog;
	strLog.asprintf(_T("::InitPnSComms <ENTRY> "));
	LogDebugMessage(strLog);
	#endif	

	T_SPNS_INIT_RETURNS eRet = P2P_INIT_OK;

	//startup the secure sockets and TCP servers according PNS state (i.e. MASTER/SLAVE/SATNDALONE)
	WSADATA wsaData;
	int retVal;

	retVal = WSAStartup(0x0202, &wsaData);

	if (retVal) {
		//failure
		eRet = P2P_INIT_WINSOCK_ERR;
	} else {
		//Lets every(irrespective of MASTER or SLAVE state) PNS engine has one listen sock. Whoever comes into the network first 
		//i.e. if slaves joins the network, it will attempt to connect to its master
		//otherwise if master joins the network ,the master attempts to connect to its slave's server socket.
		//Every peer does have one server socket
		//Every slave may have once service socket of master or a client socket to the MASTER's server socket
		//Master will have list of connecions of its slaves (i.e service sockets (IN connection) + client sockets (OUT connection)
		bool bRet = m_ListenSock.Create();
		if (bRet) {
			//start the listening thread
			bRet = m_ListenSock.Accept(m_usTcpPort, 16);
#ifdef DBG_FILE_LOG_SPNS_ENABLE		
			strLog.asprintf(_T("InitPnsComms::start the listening thread "));
			LogDebugMessage(strLog);
			#endif
			if (bRet) {
				//setup all the RCP events
#ifdef DBG_FILE_LOG_SPNS_ENABLE		
				strLog.asprintf(_T("InitPnsComms::setup all the RCP events "));
				LogDebugMessage(strLog);
				#endif
				m_hListenBackOffEv = m_ListenSock.GetBackoffEvHandle();

				m_Events[SPNS_TCP_ACCEPT_CONN] = m_ListenSock.GetAcceptEvHandle();
				m_Events[SPNS_TCP_ACCEPT_CLOSE] = m_ListenSock.GetCloseEvHandle();
				m_hAcceptedEv = m_ListenSock.GetAcceptedEvHandle();

				m_Events[SPNS_TCP_SERV_FAIL] = CreateEvent(NULL, FALSE, FALSE, _T("SPNS_ServFail"));
				m_ListenSock.SetFailedServEvent(m_Events[SPNS_TCP_SERV_FAIL]);
			} else {
				eRet = P2P_INIT_TCP_LISTEN_FAILED;
				m_ListenSock.Disconnect();
			}
		} else {
			eRet = P2P_INIT_TCP_LISTEN_FAILED;
			int tmp = m_ListenSock.GetLastError();
		}

		//Start listen thread if no errors present so far
		if (eRet == P2P_INIT_OK) {
			//Common events for SLAVE/MASTER mode
#ifdef DBG_FILE_LOG_SPNS_ENABLE		
				strLog.asprintf(_T("InitPnsComms::Common events for SLAVE/MASTER mode "));
				LogDebugMessage(strLog);
			#endif
			m_Events[SPNS_SHUTDOWN] = CreateEvent(NULL, TRUE, FALSE, _T("SPNS_Shutdown"));
			m_Events[SPNS_TCP_CONN_CLOSE] = CreateEvent(NULL, FALSE, FALSE, _T("SPNS_ConnClose"));
			m_Events[SPNS_ADD_OUT_CONN] = CreateEvent(NULL, FALSE, FALSE, _T("SPNS_NewTcpConn"));

			//start the wait thread
#ifdef DBG_FILE_LOG_SPNS_ENABLE		
				strLog.asprintf(_T("CPNSCommsEngine::start the wait thread "));
				LogDebugMessage(strLog);
			#endif
			m_hDispThread = CreateThread(NULL, 0, CPNSCommsEngine::ListenThread, this, 0, NULL);
			m_ListenSock.ResumeAcceptThread();

			QString   csTmp;
			for (int count = 0; count < NUM_EXT_MODULES; ++count) {
				//PNSComms should have its own extern module notification events (P2P does have seperate)
				csTmp.asprintf(_T("SPNSExtModule%d-notification"), count);
				m_haExtModules[count] = CreateEvent(NULL, FALSE, FALSE, (LPCTSTR) csTmp);
#if defined ( TRACE_ALLOW )
				qDebug("Created event (%X) for PNS external module (%d) called (%s).\n", m_haExtModules[count], count, csTmp );
				#endif
			}
		}
	}

#ifdef DBG_FILE_LOG_SPNS_ENABLE	
	strLog.asprintf(_T("::InitPnSComms <END>"));
	LogDebugMessage(strLog);
	#endif

	return eRet;
}

//****************************************************************************
/// InitPnSComms - Evaluates the PNS engine State changes and atcs upon the Comms Layer accordingly
///
///
/// @return - nothing
/// 
//****************************************************************************
void CPNSCommsEngine::EvaluatePNSStateChange() {
}

//****************************************************************************
/// ListenThread - handles events generated by the sockets  
///
/// @param[in] 	LPVOID pParam - pointer to calling CP2PEngine Instance
///
/// @return - 0
///
/// @TODO handle error conditions in V6 friendly manner
/// 
//****************************************************************************
DWORD WINAPI CPNSCommsEngine::ListenThread(LPVOID pParam) {

	CPNSCommsEngine *parent = (CPNSCommsEngine*) pParam;
	BOOL run = TRUE;
	DWORD dwRet;

#ifdef DBG_FILE_LOG_SPNS_ENABLE		
	QString  strLog;
	strLog.asprintf(_T("::ListenThread: Start"));
	parent->LogDebugMessage(strLog);
	#endif

#ifdef TRACE_ALLOW
	qDebug("+++++Started listening thread\n");
#endif
#ifdef DBG_FILE_LOG_SPNS_ENABLE		
			strLog.asprintf(_T("ListenThread(): 1 "));
			parent->LogDebugMessage(strLog);
		#endif

#if ( !defined(P2P_XSERIES) ) && (! defined (P2P_WRAPPER))
	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//for P2PEngine listen thread
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();

	if (pThreadInfo != NULL) {
		//Notify the WatchdogTimer that the P2PEngine thread has 
		//started
#ifdef DBG_FILE_LOG_SPNS_ENABLE		
		strLog.asprintf(_T("ListenThread(): 2 "));
		parent->LogDebugMessage(strLog);
		#endif

		pThreadInfo->UpdateThreadInfo(AM_PASS_SYNC_ENGINE_LISTEN_THREAD, true);
		pThreadInfo->UpdateThreadCounter(AM_PASS_SYNC_ENGINE_LISTEN_THREAD);
	}
#endif

	while (run) {

		//wait for the list of events generated by the sockets
		const DWORD dwSPNS_TIMEOUT_FOR_WFMO = 30000;

#if ( !defined(P2P_XSERIES) ) && (! defined (P2P_WRAPPER))
		if (pThreadInfo != NULL) {
			//Notify the WatchdogTimer that the thread should be ignored
			//until it waits for multiple objects
			pThreadInfo->UpdateThreadInfo(AM_PASS_SYNC_ENGINE_LISTEN_THREAD, false);
		}
#endif
		dwRet = WaitForMultipleObjects(parent->m_iEventCount, parent->m_pEvents, FALSE, dwSPNS_TIMEOUT_FOR_WFMO);

#if ( !defined(P2P_XSERIES) ) && (! defined (P2P_WRAPPER))
		if (pThreadInfo != NULL) {
			//Notify the WatchdogTimer that the thread should be considered
			//as the waits for multiple objects is over
			pThreadInfo->UpdateThreadInfo(AM_PASS_SYNC_ENGINE_LISTEN_THREAD, true);
		}
#endif

		if ( WAIT_TIMEOUT == dwRet) {
			//Lest see if the any dependent functionalities left (like PNS init etc)
		} else if (WAIT_FAILED == dwRet) {
			//arse! 
			//TODO handle this outcome properly
			//handle may have been closed while waiting on it
			DWORD dwErr = GetLastError();
			QString   csErr;
			csErr.asprintf(_T("PNSCOmms Wait for multiple objects failed - err: %d"), dwErr);
			QMessageBox(csErr, MB_ICONEXCLAMATION | MB_OK);
			run = FALSE;
		} else if (dwRet < WAIT_OBJECT_0 + SPNS_NUM_EVENTS) {
			switch (dwRet - WAIT_OBJECT_0) {
			case SPNS_SHUTDOWN:

#ifdef DBG_FILE_LOG_SPNS_ENABLE		
				strLog.asprintf(_T("ListenThread(): SPNS_SHUTDOWN "));
				parent->LogDebugMessage(strLog);
		#endif
				run = FALSE;
				break;
			case SPNS_TCP_ACCEPT_CONN:
				//handle new inbound TCP connections

#ifdef DBG_FILE_LOG_SPNS_ENABLE		
				strLog.asprintf(_T("ListenThread():handle new inbound TCP connections"));
				parent->LogDebugMessage(strLog);
		#endif
				parent->ProcessNewConn();
#ifdef TRACE_ALLOW
				qDebug("New Conn added : count %d\n",parent->m_iEventCount);
#endif

#ifdef DBG_FILE_LOG_SPNS_ENABLE		
				strLog.asprintf(_T("ListenThread::New Conn added : count %d "), parent->m_iEventCount);
				parent->LogDebugMessage(strLog);
			#endif

				break;
			case SPNS_TCP_ACCEPT_CLOSE:
				break;
			case SPNS_TCP_CONN_CLOSE:

#ifdef DBG_FILE_LOG_SPNS_ENABLE		
				strLog.asprintf(_T("ListenThread():find any disconnected sockets and remove from list"));
				parent->LogDebugMessage(strLog);
				#endif

				//find any disconnected sockets and remove from list
				parent->PurgeConnList();

				break;
			case SPNS_ADD_OUT_CONN:

#ifdef DBG_FILE_LOG_SPNS_ENABLE		
				strLog.asprintf(_T("ListenThread::find new conns and add to the list "), parent->m_iEventCount);
				parent->LogDebugMessage(strLog);				
			#endif

				//find new conns and add to the list
				parent->AddNewConnEvents();

				break;
			case SPNS_TCP_SERV_FAIL: {
				//have to re-start the server

#ifdef DBG_FILE_LOG_SPNS_ENABLE		
				strLog.asprintf(_T("ListenThread():Server failed have to re-start the server"));
				parent->LogDebugMessage(strLog);
			#endif

				bool bRet = parent->m_ListenSock.Create();
				if (bRet) {
					bRet = parent->m_ListenSock.Accept(parent->m_usTcpPort, 15);
					if (bRet) {
						//old handle will be closed so need a new one
						parent->m_hAcceptedEv = parent->m_ListenSock.GetAcceptedEvHandle();
						//start the accept thread
						parent->m_ListenSock.ResumeAcceptThread();
					}
				}

				break;
			}
			default:
				break;
			}
		} else //no timeout to catch
		{
#ifdef TRACE_ALLOW
			qDebug("Handle Recieved data event:%d handle: %X\n",dwRet, parent->m_pEvents[dwRet]);
#endif
#ifdef DBG_FILE_LOG_SPNS_ENABLE		
				strLog.asprintf(_T("ListenThread(): before ProcessIncomingData"));
				parent->LogDebugMessage(strLog);
			#endif

			T_PROC_DATA_RET Res = parent->ProcessIncomingData(dwRet - WAIT_OBJECT_0);
			switch (Res) {
			case PROC_RET_OK:
#ifdef DBG_FILE_LOG_SPNS_ENABLE		
				strLog.asprintf(_T("ListenThread(): PROC_RET_OK res %d"), Res);
				parent->LogDebugMessage(strLog);
				#endif
				break;
				//TODO: need to handle error conditions - but how?
			case PROC_RET_NO_RECV_HANDLE:
			case PROC_RET_NO_MEMORY:
			case PROC_RET_READ_FAILED:
			default:
#ifdef DBG_FILE_LOG_SPNS_ENABLE		
				strLog.asprintf(_T("ListenThread(): default res %d"), Res);
				parent->LogDebugMessage(strLog);
			#endif
#ifdef TRACE_ALLOW
				qDebug("Handle Recieved data event %d, handle: %X failed\n",dwRet,parent->m_pEvents[dwRet]);
#endif
				break;
			}
		}

#if ( !defined(P2P_XSERIES) ) && (! defined (P2P_WRAPPER))
		if (pThreadInfo != NULL) {
			//Update the Thread Counter for the P2PEngine
			//thread after each iteration
			pThreadInfo->UpdateThreadCounter(AM_PASS_SYNC_ENGINE_LISTEN_THREAD);
		}
#endif

	}

#if ( !defined(P2P_XSERIES) )	&& (! defined (P2P_WRAPPER))
	if (pThreadInfo != NULL) {
		//Update the info that the P2PEngine listen thread is exiting
		//Hence this thread need not be considered to kick the 
		//watchdog
		pThreadInfo->UpdateThreadInfo(AM_PASS_SYNC_ENGINE_LISTEN_THREAD, false);
	}
#endif

	//QMessageBox(_T("PNSComms::ListenThread Finished"),MB_OK);
	return 0;
}

//****************************************************************************
// void ::ProcessNewConn()
///
/// Handler for a new incoming TCP connection, which has been signalled in
/// CTcpSocket::OnAccept by a SetEvent(m_hAcceptEv). Here we check that the
/// connection is on the same subnet as our preferred connection.
///
/// If not on the same subnet then close the socket and set the accepted event
/// so that CTcpSocket::OnAccept() can finish processing. The fact that we 
/// decide to close the socket at this point should not be a problem to anyone
/// and this is a much more straight forward mechanism than the alternative of
/// creating and processing a new connection refused event. It is also tidier
/// than continually backing off the connection request until the retry count
/// expires.
///
/// If the new connection that we are processing is on the same network then
/// great. Accept it if we have not already got at least 6 connections that we
/// are processing.
//****************************************************************************
void CPNSCommsEngine::ProcessNewConn() {
#ifdef TRACE_ALLOW
	qDebug("Incoming connection plop\n");
#endif
#ifdef DBG_FILE_LOG_SPNS_ENABLE	
	QString  strLog;
	strLog.asprintf(_T("ProcessNewConn::Incoming connection plop entry list %d "), m_connList.GetNumEntries());
	LogDebugMessage(strLog);
#endif
	SOCKADDR_IN sName;
	sName.sin_family = AF_INET;
	sName.sin_port = 0;
	sName.sin_addr.S_un.S_addr = ADDR_ANY;
	int siz = sizeof(sockaddr);

	// What is the socket connection that has come in.
	QAbstractSocket sockLastServiceSocket = m_ListenSock.GetLastServiceSock();

	getpeername(sockLastServiceSocket, (sockaddr*) &sName, &siz);

	ULONG ulPeerIP = sName.sin_addr.S_un.S_addr;
#ifdef DBG_FILE_LOG_SPNS_ENABLE	
	strLog.asprintf(_T("ProcessNewConn::ulPeerIP %lu"), ulPeerIP);
	LogDebugMessage(strLog);
	#endif
	CPassSyncEngine *pPNS = CPassSyncEngine::GetHandle();

//	//Check in PNS Group list otherwise .. ignore?
//	// The connection should be from the PNS Group.
//	if ( pPNS->isThisPeerPartOfOurGroup(ulPeerIP) )
//	{
//#if defined ( TRACE_ALLOW )
//		qDebug(	_T("Closing socket %d from %#x as it is on a different PNS Group. \n"),
//				sockLastServiceSocket,
//				ulPeerIP,
//				);
//#endif
//
//		#ifdef DBG_FILE_LOG_SPNS_ENABLE		
//				strLog.asprintf(L"CPNSCommsEngine::Closing socket %d from %#x as it is on a different PNS Group.\r\n",sockLastServiceSocket,ulPeerIP, GetTickCount());
//				LogDebugMessage(strLog);
//		#endif
//		// Close the socket just like CCESecureSocket would.
//		shutdown( sockLastServiceSocket, SD_BOTH );
//		closesocket( sockLastServiceSocket );
//
//		SetEvent(m_hAcceptedEv);
//	}
//	else 
	if (m_connList.GetNumEntries() < 6) //PSR - Why 6?
			{
		// create new connection meta data instance
		CP2PEngine::T_ConnData *conn = new CP2PEngine::T_ConnData;
		//create new socket for the connection
		conn->pBuf = NULL;
		conn->bufLen = 0;
		conn->bDataWait = false;
		conn->bNewOutConn = false;
		conn->connInOut = CP2PEngine::CONN_ORIG_IN;
		conn->conStatus = CP2PEngine::CONN_NORMAL;

#ifdef SPNS_NON_SECURE_MODE
		conn->pCSock = new CTcpSocket(); //Non-Secure
		conn->pCSock->SetBufferSize(SECURE_TCP_BUFFERSIZE);
		#if defined(DBG_FILE_LOG_SSL_DBG_ENABLE) && defined (DBG_FILE_LOG_STCPS_ENABLE)
		conn->pCSock->SetDebugLogger(m_pDebugFileLogger);
		#endif
#else
		//Secure Socket
		conn->pCSock = new CTcpSocket(m_ListenSock.GetLastServiceSock(), CV7SecureSocket::SocketServer,
				m_ListenSock.getCredHanle(), m_ListenSock.getContextHandle());

#if defined(DBG_FILE_LOG_SSL_DBG_ENABLE) && defined (DBG_FILE_LOG_STCPS_ENABLE)
		conn->pCSock->SetDebugLogger(m_pDebugFileLogger);
		#endif

		conn->pCSock->SetBufferSize(SECURE_TCP_BUFFERSIZE);

		m_ListenSock.EraseTLSSerOnceAccept();

#endif		

		//populate the structure
		conn->sock = m_ListenSock.GetLastServiceSock();
		//start the accepted socket
		conn->pCSock->AcceptServiceSocket(conn->sock, m_Events[SPNS_TCP_CONN_CLOSE]);

		conn->addr = conn->pCSock->GetPeerAddr();

		conn->conStatus = CP2PEngine::CONN_NORMAL;

		//get the event handle
		conn->hEvent = conn->pCSock->GetRecvEvHandle();
		//start the read thread

		//let the listening thread continue accepting conns

		//add the connection to a conn list
		m_csConnList.lock();
		m_connList.AddTail(conn);
		m_csConnList.lock();
		AddEvent(conn->hEvent);

		SetEvent(m_hAcceptedEv);
		sleep(10);
		conn->pCSock->ResumeReadThread();
		//qDebug("\nIncoming connection read thread started\n");
	} else {
		SetEvent(m_hListenBackOffEv);
	}
	//add the event handle to the event list
}

//****************************************************************************
/// GetConnection - get a connection pointer for a given peer IP address
///
/// @param ulAddr - ULONG format IP address
/// @param bTestOnly - flag to request only a check if a given peer is connected
///
/// @return - connection pointer or NULL if there is no connection available
/// 
//****************************************************************************
CP2PEngine::T_ConnData* CPNSCommsEngine::GetConnection(ULONG ulAddr, BOOL bTestOnly) {
#ifdef DBG_FILE_LOG_SPNS_ENABLE		
	QString  strLog;
	strLog.asprintf(_T("GetConnection:: <ENTRY> addr %lu "), ulAddr);
	LogDebugMessage(strLog);
#endif	

	CP2PEngine::T_ConnData *pData = NULL;
	CTcpSocket *pSock = NULL;
	BOOL bFound = FALSE;
	if (ulAddr) {
		//test addr in the connlist
		m_csConnList.lock();
		if (!m_connList.IsEmpty()) {
#ifdef DBG_FILE_LOG_SPNS_ENABLE	
			strLog.asprintf(_T("GetConnection: test addr in the connlist"));
			LogDebugMessage(strLog);
			#endif

			pData = m_connList.GetHead();
			bool bLast = false;
			while (!bLast && !bFound) {
				if (pData->addr == ulAddr && pData->pCSock->GetSocketState() >= CCESecureSocket::CONNECTED) {
					bFound = TRUE;
					pSock = pData->pCSock;
					bLast = true;
				} else {
					bLast = m_connList.IsLast();
					if (!bLast)
						pData = m_connList.GetNext();
					else
						pData = NULL;
				}
			}

			/*<START> ANOOP added logging for NETSYNC	*/
#ifdef DBG_FILE_LOG_SPNS_ENABLE		
			if(pData != NULL)
			{
				int nconStatus = pData->pCSock->GetSocketState();

				//QString  szSocketState;
				//szSocketState = ConvertSocketStateToString(nconStatus);				
				strLog.asprintf(_T("GetConnection:...QAbstractSocket STATE is %d.. "), nconStatus);
				LogDebugMessage(strLog);

			}
			#endif
			/*<END> added logging for NETSYNC */

		}
		m_csConnList.lock();
	}

#ifdef DBG_FILE_LOG_SPNS_ENABLE	
	strLog.asprintf(_T("GetConnection:..bFound is %d addr %lu"), bFound, ulAddr);
	LogDebugMessage(strLog);
	#endif

	if (!bTestOnly) //skip next section if we only want to know if a peer is in the conn list
	{
		//if address not found, create a connection to the machine
		if (!bFound || !pData) {
			//convert the address from ulong to UNICODE (annoying since it will only be converted back again...)
			in_addr InAdr;
			InAdr.S_un.S_addr = ulAddr;
			char *pcAddr = inet_ntoa(InAdr);
			size_t count = strlen(pcAddr) + 1;
			QString pwcAddr = new WCHAR[count];
			QString   csTmp;

#if ( (_MSC_VER < 1400 ) || defined(P2P_XSERIES) )
			mbstowcs(pwcAddr, pcAddr, count);
#else
		size_t pNoOfChars;
		mbstowcs_s(&pNoOfChars, pwcAddr, count, pcAddr,count);
#endif

			csTmp = pwcAddr;
			delete pwcAddr;
			//Only if this is slave then create and connect to master
			pData = CreateTcpConn(csTmp, m_usTcpPort, &pSock); //SPNS - Todo later

			//sleep(250);//allow the server to process the new connection before allowing data to be sent
			//if(!pData)
			//qDebug("Connection Not Established\n");
			//else
			//qDebug("New Connection created for: %X\n",ulAddr);

		}
		//else qDebug("Existing Connection Found\n");
	}

#ifdef DBG_FILE_LOG_SPNS_ENABLE		
		strLog.asprintf(_T("GetConnection <EXIT> addr %lu "), ulAddr);
		LogDebugMessage(strLog);
	#endif

	return pData;

}

//****************************************************************************
/// AddEvent - Add a connection read event to the event list that the thread waits on  
/// and resets the pointer to new data
///
/// @param[in] 	 HANDLE hEv - handle to be added
///
/// @return bool - false if new space cannot be allocated
/// 
//****************************************************************************
bool CPNSCommsEngine::AddEvent(HANDLE hEv) {
	//allocate space for the now larger event list
	HANDLE *hTmp = new HANDLE[++m_iEventCount];
	if (hTmp) {
		m_csEvents.lock();
		//copy old list to new list
		//Fixed the access violation issue in the memcpy.
		memcpy(hTmp, m_pEvents, (m_iEventCount - 1) * sizeof(HANDLE));
		//free old memory if it's not the original static list
		if (m_pEvents != &m_Events[0]) {
			delete[] m_pEvents;
		}
		//set the pointer for WaitForMultipleObjects
		m_pEvents = hTmp;
		//add new handle to end of list
		m_pEvents[m_iEventCount - 1] = hEv;
		m_csEvents.lock();

		return true;
	} else {
		return false;
	}
}

//****************************************************************************
/// DeleteEvent - remove an event from the event list  
///
/// @param[in] 	 HANDLE hEv - handle to be deleted
///
/// @return bool - false if new space cannot be allocated, or handle not in list
/// 
//****************************************************************************
bool CPNSCommsEngine::DeleteEvent(HANDLE hEv) {
	bool ret = true;
	//find event in list
	int index = 0;
	while (index < m_iEventCount) {
		if (hEv == m_pEvents[index]) {
			break;
		}
		++index;
	}
	if (index < m_iEventCount && index >= SPNS_NUM_EVENTS) {
		//we've got it
		m_csEvents.lock();
		if (--m_iEventCount == SPNS_NUM_EVENTS) {
			//switch back to original data
			HANDLE *pTmp = m_pEvents;
			m_pEvents = &m_Events[0];
			delete[] pTmp;
		} else {
			//need to re-allocate memory to avoid leaks
			HANDLE *phTmp = new HANDLE[m_iEventCount];
			if (phTmp) {
				//copy items below deleted item
				memcpy(phTmp, m_pEvents, index * sizeof(HANDLE));
				//copy items above deleted item
				memcpy(&phTmp[index], &m_pEvents[index + 1], (m_iEventCount - index) * sizeof(HANDLE));
				//decrement the count
				//--m_iEventCount //done in top statement
				//delete old data
				delete[] m_pEvents;
				m_pEvents = phTmp;
			} else //memory not available
			{
				ret = false;
			}
		}
		if (hEv) {
			//No need to close the mutex in Qt
		}
		m_csEvents.lock();
	}
	//handle not in variable list
	else {
		ret = false;
	}

	return ret;
}

//****************************************************************************
/// ProcessIncomingData - arrange incoming data into individual messages and then parse as necessary  
///
/// @param[in] 	ULONG index - index into event array to event handle that invoked
///
/// @return T_PROC_DATA_RET
/// 
//****************************************************************************
T_PROC_DATA_RET CPNSCommsEngine::ProcessIncomingData(ULONG index) {
#ifdef DBG_FILE_LOG_SPNS_ENABLE	
	QString  strLog;
	strLog.asprintf(_T("ProcessIncomingData:Begin find the event handle index %d in the list "), index);
	LogDebugMessage(strLog);
	#endif
	T_PROC_DATA_RET ret = PROC_RET_OK;
	//find the event handle in the list
	ULONG num = m_connList.GetNumEntries();
	CP2PEngine::T_ConnData *pConn;
	bool bFound = false;

#if ( !defined(P2P_XSERIES) ) && (! defined (P2P_WRAPPER))
	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//for the P2PEngine listen thread
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
#endif

	if (num) {
		m_csConnList.lock();
		pConn = m_connList.GetHead();
		if (pConn->hEvent != m_pEvents[index]) {
			//iterate the list

			while (!bFound && !m_connList.IsLast()) {
				pConn = m_connList.GetNext();
				if (pConn->hEvent == m_pEvents[index]) {
					bFound = true;
					break; //Though the condition is updated
				}
			}
		} else {
			bFound = true;
		}
		m_csConnList.lock();
		if (!bFound) {
			//we're buggered - all hope is lost!
			//QMessageBox(_T("can't find recv data event handle in list"),MB_ICONEXCLAMATION|MB_OK);
			ret = PROC_RET_NO_RECV_HANDLE;
#ifdef TRACE_ALLOW
			qDebug("Can't find event handle");
#endif
		} else {
			char *cBuf;
			int writePos = 0;
			//allocate memory for incoming data and existing data
			int iLen = pConn->pCSock->GetDataSize();
			while (iLen) {

#if ( !defined(P2P_XSERIES) ) && (! defined (P2P_WRAPPER))
				if (pThreadInfo != NULL) {
					//Update the Thread Counter for the P2PEngine Listen
					//thread after each iteration
					pThreadInfo->UpdateThreadCounter(AM_PASS_SYNC_ENGINE_LISTEN_THREAD);
				}
#endif
				if (pConn->pBuf)					//pConn->bDataWait && 
				{
					cBuf = new char[iLen + pConn->bufLen];
					if (!cBuf) {
						//it's all gone pete tong again!
						ret = PROC_RET_NO_MEMORY;
					} else {
						//copy previous data into new buffer
						writePos = pConn->bufLen;
						if (writePos) {
							memcpy(cBuf, pConn->pBuf, pConn->bufLen);
							delete[] pConn->pBuf;
						}
						pConn->pBuf = NULL;
						pConn->bufLen += iLen;
					}
				} else {
					//create empty buffer for new data
					cBuf = new char[iLen];
					//reset the writepos
					writePos = 0;
					if (!cBuf) {
						//we're out of memory!
						ret = PROC_RET_NO_MEMORY;
					} else {
						pConn->bufLen = iLen;
					}
				}

				if (PROC_RET_OK == ret) {
					pConn->pBuf = cBuf;

					//pointer arithmetic
					writePos *= sizeof(char);
					if (iLen != pConn->pCSock->Read(pConn->pBuf + writePos, iLen)) {
						//it's that pete tong again - time to investigate
#ifdef TRACE_ALLOW
						qDebug("Spurious return 1\n");
#endif
						ret = PROC_RET_READ_FAILED;
					} else {
						//wow made it through!now parse the data
#ifdef TRACE_ALLOW
						qDebug("Data going to be parsed handle: %X\n",pConn->hEvent);
#endif
						ParseData(pConn);
					}
					//check no more data has come in while we're waiting
					if (PROC_RET_OK == ret) {
						iLen = pConn->pCSock->GetDataSize();

#ifdef DBG_FILE_LOG_SPNS_ENABLE	
						strLog.asprintf(_T("PID:check no more data has come in while we're waiting %d"), iLen);
						LogDebugMessage(strLog);
						#endif
					}
				}
			}
		}
		//make sure nothing else has slipped in while we were waiting...
		//num = m_connList.GetNumEntries();
	}
	//else
	//{

	//	//nothing in the conn list.... odd
	//	QMessageBox(L"incoming data with no connections in list",MB_OK);
	//}

#ifdef DBG_FILE_LOG_SPNS_ENABLE	
	strLog.asprintf(_T("ProcessIncomingData:End processed the data ret %d"), ret);
	LogDebugMessage(strLog);
	#endif

	return ret;
}

//****************************************************************************
/// ParseData - split data into coherrent messages and dispatch  
///
/// @param[in] 	pDat - Pointer to T_ConnData that contains data to parse
///
/// @return void
/// @TODO return something useful
/// @TODO do some actual parsing
/// 
//****************************************************************************
void CPNSCommsEngine::ParseData(CP2PEngine::T_ConnData *pDat) {
	BOOL bHdr;
	BOOL bTail;
	char *pcBufTmp = NULL; //temporary working buffer to prevent misalignment issues
	char *pPos = pDat->pBuf;
	ULONG iTmpLen = pDat->bufLen;
	ULONG iMsgLen;

#ifdef DBG_FILE_LOG_SPNS_ENABLE
	QString  strLog;
	strLog.asprintf(_T("ParseData():BEGIN pDat->bufLen %lu"),iTmpLen); 
	LogDebugMessage(strLog);
	#endif

	//PrintHexDump(pDat->bufLen, pDat->pBuf, true);

#if ( !defined(P2P_XSERIES) ) && (! defined (P2P_WRAPPER))
	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//for the P2PEngine Listen thread
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
#endif

	BOOL DataEnd = FALSE;
	while(!DataEnd)
	{

#if ( !defined(P2P_XSERIES) ) && (! defined (P2P_WRAPPER))
		if (pThreadInfo != NULL) {
			//Update the Thread Counter for the PNS COMMS engine
			//thread after each iteration
			pThreadInfo->UpdateThreadCounter(AM_PASS_SYNC_ENGINE_LISTEN_THREAD);
		}
#endif

		//allocate a new space
		if (iTmpLen <= 0) {
			DebugBreak();
		}
		pcBufTmp = new char[iTmpLen];
		memcpy(pcBufTmp, pPos, iTmpLen);
		iMsgLen = ((CP2PEngine::T_DataHdr*) pcBufTmp)->usLen;
		pPos += iMsgLen; //ready for next iteration

		bHdr = (CP2PEngine::APP_ID == *(USHORT*) pDat->pBuf);

#ifdef DBG_FILE_LOG_SPNS_ENABLE
		strLog.asprintf(_T("ParseData(): isHdr %d iMsgLen:0x%x pDat->pBuf:0x%x APP_ID:0x%x "),bHdr,iMsgLen, *(USHORT*)pDat->pBuf, CP2PEngine::APP_ID); 
		LogDebugMessage(strLog);
		#endif

		if(bHdr)
		{
			if(iMsgLen <= iTmpLen)
			{
				//we have 1 or more messages
				bTail = (CP2PEngine::EOT == pcBufTmp[iMsgLen - 1]);
				if(bTail)
				{
					char *pTmpPtr = pcBufTmp + sizeof(CP2PEngine::T_DataHdr);

#ifdef DBG_FILE_LOG_SPNS_ENABLE	
					strLog.asprintf(_T("ParseData: Recvd data: command %d "),*pTmpPtr);
					LogDebugMessage(strLog);
					#endif
					//we can parse this message here
					if(*pTmpPtr < MAX_P2P_CMDS)
					{

						/*#ifdef DBG_FILE_LOG_SPNS_ENABLE		
						 QString  strLog;
						 strLog.asprintf(_T("ParseData:..Recvd data: command :%d.. "),*pTmpPtr);
						 LogDebugMessage(strLog);
						 #endif*/

#ifdef TRACE_ALLOW
						qDebug(csTmp);
#endif
						switch(*pTmpPtr)
						{
							case EXT_MODULE:
							{
								//module specific data to be passed out to ext apps
								T_EXT_MOD_DATA *pModData = new T_EXT_MOD_DATA;
								//don't include command or module bytes
								pModData->MsgLen = iMsgLen - CP2PEngine::MSG_OVHD - 2;
								pModData->pMsg = new char[pModData->MsgLen];
								memcpy(pModData->pMsg, pTmpPtr + 2, pModData->MsgLen);
								pModData->ulPeer = pDat->addr;
								T_EXT_MOD_REG mod = static_cast<T_EXT_MOD_REG>(*(pTmpPtr + 1));
#ifdef DBG_FILE_LOG_SPNS_ENABLE
								strLog.asprintf(_T("ParseData:..Before CS Entry..Msg :%d.. mod %d"),*pTmpPtr, mod);
								LogDebugMessage(strLog);
								#endif

								EnterCriticalSection(&m_csExtModDataList[mod]);
								m_ExtModuleDataList[mod].AddTail(pModData);
								LeaveCriticalSection(&m_csExtModDataList[mod]);

#ifdef DBG_FILE_LOG_SPNS_ENABLE		
								strLog.asprintf(_T("ParseData:..After CS Entry..msgcnt %d "), GetExtModMsgCount(mod));
								LogDebugMessage(strLog);
								#endif

							if(SetEvent(m_haExtModules[mod]))
							{
#ifdef DBG_FILE_LOG_SPNS_ENABLE		
								strLog.asprintf(_T("ParseData:..After SetEvent.."));
								LogDebugMessage(strLog);
#endif

#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TRENDSERVERPRO ) ) && ( ! defined ( TRENDMANAGERPRO ) ) && (! defined (P2P_WRAPPER))
								QString   csAddr;
								csAddr = CStringUtils::PackedIPv4ULongToStr(pDatat

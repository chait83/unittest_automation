/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Configuration system
/// @n Filename:  ScrnDesCfgDlg.h
/// @n Description: Definition of the screen layout data driven configuration dialog 
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  16  Stability Project 1.13.1.1   7/2/2011 5:01:05 PM   Hemant(HAIL) 
//     Stability Project: Recorder source has been upgraded from IL
//    version of firmware to JF version of firmware.
//  15  Stability Project 1.13.1.0   7/1/2011 4:27:31 PM   Hemant(HAIL) 
//     Stability Project: Files has been checked in before the merging
//    task. The merging will be done between IL version of firmware and JF
//    version of firmware. 
//  14  V6 Firmware 1.13     4/19/2007 3:39:36 PM  Roger Dawson  
//    Added code that allows special function to be tied to the bottom
//    middle button on the data driven menus.
//  13  V6 Firmware 1.12     11/9/2006 9:45:01 PM  Roger Dawson  
//    Added layout appearance settings. This lets users define global
//    colours such as chart backgrounds and grid colours.
// $
//
// **************************************************************************

#if !defined(AFX_ScrnDesCfgDlg_H__42CEA861_9419_4B58_9723_CCA8EE253C7E__INCLUDED_)
#define AFX_ScrnDesCfgDlg_H__42CEA861_9419_4B58_9723_CCA8EE253C7E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ScrnDesCfgDlg.h : header file
//

#include <vector>
#include <list>
#include "SIPGlobal.h"
#include "RecSetupDlg.h"

class CConfigInterface;
class CEditPanelDlg;
class CConfiguration;
class CLayoutItem;
class CConfigData;
class CV6BitmapButton;

//**CScrnDesCfgDlg*********************************************************************
///
/// @brief Dialog class responsible for managing the screen designer data driven configuration dialog
/// 
/// Dialog class responsible for managing the screen designer data driven configuration dialog
///
//****************************************************************************
class CScrnDesCfgDlg: public CRecSetupDlg {
// Construction
public:

	enum T_LAYOUT_SETUP_TYPES {
		lstOBJECTS, lstSETTINGS, lstAPPEARANCE
	};

	/*
	 // Singleton Accessor/Creator
	 static CScrnDesCfgDlg* Instance(	CLayoutItem *pkLayoutItem,
	 CWidget *pkParent = NULL,
	 const bool bEDIT_CHAN_MAP_DATA = false );
	 */

	// Constructor
	CScrnDesCfgDlg(CLayoutItem *pkLayoutItem, CWidget *pkParent = NULL, const bool bEDIT_CHAN_MAP_DATA = false,
			glbpSpecialBtnClickFunc pvSpecialBtnClick = NULL, glbpGetSpecialBtnTitle pvGetSpecialBtnTitle = NULL);

	// Alternate Constructor
	CScrnDesCfgDlg(const T_LAYOUT_SETUP_TYPES eLAYOUT_SETUP_TYPE, CWidget *pkParent = NULL,
			glbpSpecialBtnClickFunc pvSpecialBtnClick = NULL, glbpGetSpecialBtnTitle pvGetSpecialBtnTitle = NULL);

	// Destructor
	~CScrnDesCfgDlg();

	// Method that validates data entered from the SIP or someother entry point
	bool ValidateData(const QStringconst pwcDATA);

	// Accessor Methods
	const CLayoutItem* GetLayoutItem() const {
		return m_pkCurrLayoutItem;
	}

	// Method that shows the object channel map editor for the passed in object
	static void EditObjectChannelMap(CBaseObject *pkObject);

	// Method that shows the widget channel map data driven dialog for the passed in widget
	void EditWidgetChannelMap(CWidget *pkWidget);

// Dialog Data
	//{{AFX_DATA(CScrnDesCfgDlg)
	enum {
		IDD = IDD_CONFIG_DLG
	};
	CScrollBar m_kScrollBar;
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CScrnDesCfgDlg)
protected:
	virtual void DoDataExchange(CDataItem *pDX);  // DDX/DDV support
	virtual void PostNcDestroy();
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CScrnDesCfgDlg)
	//}}AFX_MSG

	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()

private:

	// Method that switches the current config item
	void SwitchLayoutItem( CLayoutItem *pkLayoutItem,
			const bool bEDIT_CHAN_MAP_DATA );

	// Method that lets the current object that its config has changed
	void ConfigChange();

	// Method that commits the changes to the CMM and closes the window
	void CommitChanges();

	// Accessor method for the config manager class
	CBaseCfgMgr* GetConfigSysMgr();

	// Method that creates the configuration tree for the currently selected object
	bool CreateObjectConfig(T_BASEOBJECT *pkBaseObject);

	// Method for discarding changes
	void DiscardChanges();

	// Method for parking changes and closing the window
	void CloseDialog(const bool bOK);

	// Method used to refresh a layout configuration tree
	CConfigInterface* RefreshConfigTree(CConfigItem *pkCfgItem);

	// Method that disables/enables the back button if the current config items parent is null
	// and we are showing multiple screens
	void SetupBackButton();

	// Method that indicates the user has selected a submenu button
	void SubMenuBtnClick();

	// Method that indicates the user has selected the back button
	void BackBtnClick();

	// Method that indicates the user has selected the finish button
	void FinishBtnClick();

	/// Auto pointer that stores the dialogs singleton pointer
	//static std::auto_ptr< CScrnDesCfgDlg > ms_kScrnDesCfgDlg;

	/// Pointer to the current layout item object
	CLayoutItem *m_pkCurrLayoutItem;

	/// Flag indicating if the user selected to edit channel map information only
	bool m_bEditChanMapData;

	const T_LAYOUT_SETUP_TYPES m_eLAYOUT_SETUP_TYPE;

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ScrnDesCfgDlg_H__42CEA861_9419_4B58_9723_CCA8EE253C7E__INCLUDED_)

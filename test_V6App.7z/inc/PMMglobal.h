/// @file Global.h
/// ***************************************************************************************
/// © Honeywell Trendview
/// ***************************************************************************************
/// @n Module	: Password Management Module.
/// @n Filename	: Global.h
/// @n Desc		: Enumerations and structures used globally.
///
// ***************************************************************************************
// Revision History
// ***************************************************************************************
// $Log[1]:
// 8	Stability Project 1.5.1.1	7/2/2011 4:59:43 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// $Log" from the functions
// $
//
// ***************************************************************************************
/******************************************************************************************
 COPYRIGHT (c) 2004
 HONEYWELL INC.,
 ALL RIGHTS RESERVED

 This software is a copyrighted work and/or information protected
 as a trade secret. Legal rights of Honeywell Inc. in this
 software is distinct from ownership of any medium in which the
 software is embodied. Copyright or trade secret notices included
 must be reproduced in any copies authorized by Honeywell Inc.
 The information in this software is subject to change without
 notice and should not be considered as a commitment by Honeywell
 Inc.
 ******************************************************************************************/

#ifndef __PMMGLOBAL__
#define __PMMGLOBAL__
#include "Defines.h"
//*************************************************************
// enum enumPOLICY_STATUS
///
/// The status of the any function from policy manager class.
///
//*************************************************************

typedef enum enumPOLICY_STATUS {

	P_STATUS_OK = 0,						///< Return Success

	P_STATUS_FAIL,							///< Failure from Policy manager.

	P_POLICY_NOT_INITIALISED,

	P_INVALID_POLICY,

	P_INVALID_PARAMETER

} POLICY_STATUS;

//*******************************************************
// enum enumPMMERROR
///
/// The status of the any function within the PMM.
///
//*******************************************************

typedef enum enumPMMERROR {
	PMM_SUCCESS = 0,

	PMM_FAILED,

	PMM_NO_USERS,

	PMM_USERNAME_PASSWORD_SAME,

	PMM_INVALID_CONFIGURATION_ID,

	PMM_INVALID_POLICY_DATA,

	PMM_INVALID_USER_ID,

	PMM_INVALID_PASSWORD,

	PMM_INVALID_USERNAME,

	PMM_INVALID_CMM_DLL,

	PMM_INVALID_LOGIN_DAY,

	PMM_INVALID_LOGIN_TIME,

	PMM_INVALID_GROUP_LEVEL,

	PMM_INVALID_OLD_PASSWORD,

	PMM_INVALID_PARAMETER,

	PMM_INVALID_SRAM_POINTER,

	PMM_INVALID_SRAM_HANDLE,

	PMM_VALID_DAY,

	PMM_NOT_CUSTOM_PERMISSION_USER,

	PMM_CANNOT_CHANGE_ADMIN_PERMISSION,				// Added

	PMM_WARNING_ACTIVATED,

	PMM_CHANGE_PASSWORD_FOR_LOGIN,

	PMM_BACKDOOR_USER_AUTHENTICATED,

	PMM_NO_USERS_LOGIN,

	PMM_USER_NOT_LOGIN,

	PMM_FIRST_TIME_USER_AUTHENTICATED,

	PMM_FIRST_TIME_USER_NOT_AUTHENTICATED,

	PMM_PASSWORD_EXPIRED,

	PMM_USER_SLOT_NOT_USED,

	PMM_INVALID_USERGROUP,

	PMM_USER_ACCESS_LOCKED,

	PMM_USER_LEVEL_DISALLOWED,

	PMM_DUPLICATE_USER,

	PMM_DUPLICATE_PASSWORD_IN_HISTORY,

	PMM_VALID_SLOT_FOUND,

	PMM_VALID_SLOT_NOT_FOUND,

	PMM_INSUFFICIENT_MEMORY,

	PMM_CMM_NOT_INITIALISED,

	PMM_CMM_INVALID_METADATA,

	PMM_CMM_FAILED,

	PMM_UNDEFINED,

} PMMERROR;

//*******************************************************
// enum enumPMMSTATUS
///
/// The status of the any function to external clients.
///
//*******************************************************

typedef enum enumPMMSTATUS {
	CSTATUS_OK = 0,							// 0

	CSTATUS_FAIL,

	CSTATUS_PMM_NOT_INITIALISED,

	CSTATUS_DUPLICATE_USER,

	CSTATUS_INVALID_CONFIGURATION_ID,

	CSTATUS_INVALID_USER_ID,				// 5		

	CSTATUS_INVALID_POLICY,

	CSTATUS_INVALID_PASSWORD,

	CSTATUS_INVALID_USERNAME,

	CSTATUS_INVALID_DAY_MASK,

	CSTATUS_INVALID_LOGIN_TIME,				// 10		

	CSTATUS_INVALID_USER_LEVEL,

	CSTATUS_INVALID_USERGROUP,

	CSTATUS_INVALID_PARAMETER,

	CSTATUS_INVALID_OLD_PASSWORD,

	CSTATUS_INVALID_SRAM_HANDLE,			// 15	

	CSTATUS_VALID_SLOT_NOT_FOUND,

	CSTATUS_USERNAME_AND_PASSWORD_SAME,

	CSTATUS_PASSWORD_EXPIRED,

	CSTATUS_PASSWORD_LOCKED,

	CSTATUS_USER_LEVEL_DISALLOWED,			// 20		

	CSTATUS_NO_MORE_USERS,

	CSTATUS_PASSWORD_IN_HISTORY,

	CSTATUS_INVALID_DLL,

	CSTATUS_UNDEFINED,

	CSTATUS_FIRST_TIME_USER_AUTHENTICATED,	// 25

	CSTATUS_BACKDOOR_USER_AUTHENTICATED,

	CSTATUS_FIRST_TIME_USER_NOT_ALLOWED,

	CSTATUS_NOT_CUSTOM_PERMISSION_USER,

	CSTATUS_CANNOT_CHANGE_ADMIN_PERMISSION,				// Added

	CSTATUS_CHANGE_PASSWORD_FOR_LOGIN,		// 30

	CSTATUS_EXPIRY_DAYS_WRN,

	CSTATUS_CMM_NOT_INITIALISED,

	CSTATUS_CMM_INVALID_METADATA,

	CSTATUS_CMM_FAILED,

	CSTATUS_CPWI_NOT_INITIALISED,			// 35			

	CSTATUS_CPWI_INVALID_USER,

	CSTATUS_CPWI_USER_NOT_LOGIN,

	CSTATUS_CPWI_INACTIVITY_TIMEOUT,

	CSTATUS_CPWI_FTP_DISABLED,

	CSTATUS_CPWI_WEB_DISABLED,				// 40

	CSTATUS_PASSWORD_NOT_ENABLED

} PMMSTATUS;

//STRUCTURES
//******************************************************
// typedef struct stSYSTEMSTATE
///
/// @brief --- Information containing PMM Status.
///
/// Contains the statistics related to total number of 
/// users login and the user access level allowed into system
//
//******************************************************
typedef struct stSYSTEMSTATE {
	BYTE LoginUsersCount;		///< Number of Users login.

	BYTE AccessLevel;			///< Access level set in the system.

} SYSTEMSTATE;

//******************************************************
// typedef struct LOGDETAIL
///
/// @brief --- Information containing User log detail.
///
/// Contains the information of last login time and number
/// of timer user has login.
//
//******************************************************
typedef struct _logdetails {

	LONGLONG LastLoginTime;	///< Time of last login

	WORD LoginCount;	///< Count of number of times user has logged in

} LOGDETAIL, *PLOGDETAIL;

#endif

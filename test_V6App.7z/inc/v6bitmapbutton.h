/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Configuration system
/// @n Filename:  V6BitmapButton.h
/// @n Description: Definition of the CV6BitmapButton class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  90  Stability Project 1.87.1.1   7/2/2011 5:02:39 PM   Hemant(HAIL) 
//     Stability Project: Recorder source has been upgraded from IL
//    version of firmware to JF version of firmware.
//  89  Stability Project 1.87.1.0   7/1/2011 4:27:32 PM   Hemant(HAIL) 
//     Stability Project: Files has been checked in before the merging
//    task. The merging will be done between IL version of firmware and JF
//    version of firmware. 
//  88  V6 Firmware 1.87     9/25/2009 3:20:21 PM  Binsy Pillai  
//    event cursor merging of code
//  87  V6 Firmware 1.86     9/23/2008 3:09:35 PM  Build Machine 
//    AMS2750 Merge
// $
//
// **************************************************************************

#if !defined(AFX_V6BITMAPBUTTON_H__97FCDE52_6A80_4B24_875D_CE54FE29087E__INCLUDED_)
#define AFX_V6BITMAPBUTTON_H__97FCDE52_6A80_4B24_875D_CE54FE29087E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "SIPGlobal.h"
#include <vector>
#include "PassAuthDefines.h"
#include "ppl.h"
#include <QPushButton>
#include "Defines.h"
// Callback function declaration 
typedef BOOL (WINAPI *glbpV6BtnCallbackFunction)(QString   &rstrTitleText, COLORREF &rcrBtnTextColour, bool &rbEnabled,
		const bool bFORCE_UPDATE);

//**CV6BitmapButton***********************************************************
///
/// @brief V6 Owner drawn button used for the various V6 menus
/// 
/// V6 Owner drawn button used for the various V6 menus
///
//****************************************************************************
class CV6BitmapButton: public QPushButton {
// Construction
public:

	/// Enum indicating the button styles for standard buttons
	enum T_BTN_STYLE {
		bsNone,
		bsMenu,
		bsBlankMenu,
		bsAdvancedMenu,
		bsAdvancedBackMenu,
		bsAdvancedFinishMenu,
		bsDDleft,
		bsDDright,
		bsDDBottom,
		bsHelp,
		bsHalf,
		bsHalfWidthLabel,
		bsThird,
		bsThirdWidthLabel,
		bsQuarter,
		bsFifth,
		bsSixth,
		bsSixthWidthLabel,
		bsDDTopHalfleft,
		bsDDTopThirdleft,
		bsDDTopQuarterleft,
		bsDDTopFifthleft,
		bsDDTopThirdmiddle,
		bsDDTopQuartermiddle,
		bsDDTopFifthmiddle,
		bsDDTopHalfright,
		bsDDTopThirdright,
		bsDDTopQuarterright,
		bsDDTopFifthright,
		bsDDTopFullWidth,
		bsPicker,
		bsPaddedPicker,
		bsListPicker,
		bsStringPicker,
		bsBlankAdvancedMenu,
		bsLargeWidthLabel,
		bsActionPicker,
		bsScreenDesignerSmallPicker,
		bsStatusBarMenu,
		bsStatusBarMenuControl,
		bsStatusBarOpenContextMenu,
		bsStatusBarEzOpenContextMenu,
		bsHotButton,
		bsStatusControl,
		bsSmallMenuBanner,
		bsCannedScrnRowTitle,
		bsCannedScrnRowEdit,
		bsMessageBoxBlankLabel,
		bsAICJCCalSetupTitle,
		bsAICJCCalSetupEdit,
		bsAICJCCalSetupNonEdit,
		bsFileSelectionTitle,
		bsFileSelectionEdit,
		bsLogOnOff,
		bsLinerisationTableSetupSmallTitle,
		bsLinerisationTableSetupLargeTitle,
		bsLinerisationTableSetupSmallEdit,
		bsLinerisationTableSetupLargeEdit,
		bsLinerisationTableSetupMediumTitle,
		bsLinerisationTableSetupMediumEdit

	};

	/// Enum indicating the button icon bitmap required
	enum T_BTN_BITMAP_TYPE {
		bbtNone,
		bbtMainMenu,
		bbtConfig,
		bbtAlarms,
		bbtScreen,
		bbtBatch,
		bbtRecording,
		bbtMessages,
		bbtProcess,
		bbtStatus,
		bbtFinish,
		bbtSetup,
		bbtLayout,
		bbtPasswords,
		bbtSettings,
		bbtSettingsTime,
		bbtSettingsVolume,
		bbtSettingsUpdateSounds,
		bbtSettingsAMS2750TCCalAdjustInclude,
		bbtSettingsAMS2750TCCalAdjustExclude,
		bbtSettingsBatteryReset,
		bbtBack,
		bbtSetupSpanner,
		bbtLoad,
		bbtSave,
		bbtChangePassword,
		bbtPasswordNetSync,
		bbtFieldIO,
		bbtPens,
		bbtCommsLead,
		bbtEventsCounters,
		bbtGeneral,
		bbtCfgRecording,
		bbtCfgReports,
		bbtAI,
		bbtAO,
		bbtDIO,
		bbtPulse,
		bbtCfgFieldIOLinearisation,
		bbtCfgFieldIOAMS2750General,
		bbtCfgLytScreens,
		bbtCfgLytSettings,
		bbtCfgLytAppearance,
		bbtCfgCommsServices,
		bbtModbus,
		bbtWeb,
		bbtEmail,
		bbtSNTP,
		bbtEthernet,
		bbtCfgOPCUA,
		bbtCfgFTP,
		bbtCfgP2P,
		bbtOPCUA,
		bbtCommsCfgNetworkAdmin,
		bbtCfgCommsServicesModbusMaster,
		bbtCfgCommsServicesModbusSlave,
		bbtCfgCommsServicesModbusComms,
		bbtScreenCfg,
		bbtScreenCfgScreenSaver,
		bbtScreenCfgBrightness,
		bbtScreenCfgChart,
		bbtScreenCfgTabularDisplay,
		bbtGenCfgPrinter,
		bbtGenCfgBatch,
		bbtGenCfgFactory,
		bbtGenCfgIdent,
		bbtGenCfgGroups,
		bbtGenCfgErrorControl,
		bbtRecCfgPretrigger,
		bbtRecCfgScheduled,
		bbtRecCfgStorageBias,
		bbtRecCfgStorageAlarm,
		bbtEventsCountersCfgEvents,
		bbtEventsCountersCfgCounters,
		bbtEventsCountersCfgMarkers,
		bbtCredits,
		bbtFWUpgrade,
		bbtDemo,
		bbtRecCfgReset,
		bbtRecCfgResetSetup,
		bbtRecCfgResetLayout,
		bbtRecCfgResetData,
		bbtRecCfgResetAll,
		bbtRecCfgReturnToCustomer,
		bbtRecCfgPrepareToShip,
		bbtProduction,
		bbtCalibration,
		bbtRecCfgFactLocale,
		bbtPark,
		bbtDiscard,
		bbtCommit,
		bbtCopyTo,
		bbtUserMessages,
		bbtSecurityMessages,
		bbtDiagMessages,
		bbtAlarmMessages,
		bbtSystemMessages,
		bbtAllMessages,
		bbtExcluded,
		bbtCFFront,
		bbtUSB,
		bbtNAS,
		bbtSystem,
		bbtOverview,
		bbtLogging,
		bbtDiagnostics,
		bbtMaintenance,
		bbtStatusAMS2750,
		bbtVersions,
		bbtOptions,
		bbtHardware,
		bbtMedia,
		bbtProcessCounters,
		bbtProcessTotals,
		bbtProcessMaxMin,
		bbtProcessUserVariables,
		bbtProcessScriptTimers,
		bbtProcessReports,
		bbtProcessReportsRun,
		bbtProcessReportsView,
		bbtProcessReportsResetAll,
		bbtExportNew,
		bbtExportAll,
		bbtActionAll,
		bbtActionGroup,
		bbtActionPen,
		bbtLoggingStart,
		bbtLoggingStop,
		bbtLoggingClear,
		bbtLoggingExportNow,
		bbtStatusBarLocked,
		bbtStatusBarUnlocked,
		bbtStatusBarAlarmOn,
		bbtStatusBarAlarmOff,
		bbtStatusBarAlarmActive,
		bbtStatusBarMessageNormal,
		bbtStatusBarMessageNormalIncBatchRunning,
		bbtStatusBarMessageNormalIncBatchPaused,
		bbtStatusBarMessageNormalIncBatchStopped,
		bbtStatusBarMessageWarning,
		bbtStatusBarMessageError,
		bbtStatusBarMessageErrorIncBatchRunning,
		bbtStatusBarMessageErrorIncBatchPaused,
		bbtStatusBarMessageErrorIncBatchStopped,
		bbtStatusBarMessageStartBatch,
		bbtStatusBarMessageStopBatch,
		bbtStatusBarMessagePauseBatch,
		bbtStatusBarMessageResumeBatch,
		bbtStatusBarMessageBatchDetails,
		bbtStatusBarMessageMarkChart,
		bbtStatusBarMemRecording,
		bbtStatusBarMemRecRecycle,
		bbtStatusBarMemStopped,
		bbtStatusBarScreen,
		bbtStatusBarEdit,
		bbtStatusBarHistoricalCircChart,
		bbtStatusBarRealtimeCircChart,
		bbtStatusBarReplay,
		bbtStatusBarList,
		bbtStatusBarPrev,
		bbtStatusBarNext,
		bbtStatusBarPrint,
		bbtStatusBarProp,
		bbtStatusBarExport,
		bbtStatusBarSnap,
		bbtStatusBarExit,
		bbtStatusBarAckAlarm,
		bbtStatusBarOpenAlarm,
		bbtStatusBarViewAlarm,
		bbtStatusBarOpenContextMenu,
		bbtTotalsMenuStart,
		bbtTotalsMenuStop,
		bbtTotalsMenuReset,
		bbtCountersMenuEvents,
		bbtCountersMenuAlarms,
		bbtCountersMenuUser,
		bbtCountersMenuDigitals,
		bbtCountersMenuRelayOutputs,
		bbtCountersMenuHardware,
		bbtCountersMenuResetAll,
		bbtCountersMenuResetIndividual,
		bbtCountersAlarmsMenuReset,
		bbtAlarmsMenuAckAlarm,
		bbtAlarmsMenuConfigure,
		bbtGroupsMenuGroup1,
		bbtGroupsMenuGroup2,
		bbtGroupsMenuGroup3,
		bbtGroupsMenuGroup4,
		bbtGroupsMenuGroup5,
		bbtGroupsMenuGroup6,
		bbtStatusBarChannelMap,
		bbtStatusBarExportOff,
		bbtStatusBarSnapOff,
		bbtMaxMinsResetBoth,
		bbtMaxMinsResetMax,
		bbtMaxMinsResetMin,
		bbtView,
		bbtUserCal,
		bbtCJCCal,
		bbtAMS2750Cal,
		bbtAMS2750CalSettings,
		bbtUserCalSlotA,
		bbtUserCalSlotB,
		bbtUserCalSlotC,
		bbtUserCalSlotD,
		bbtUserCalSlotE,
		bbtUserCalSlotF,
		bbtCJCCalSlotA,
		bbtCJCCalSlotB,
		bbtCJCCalSlotC,
		bbtCJCCalSlotD,
		bbtCJCCalSlotE,
		bbtCJCCalSlotF,
		bbtCalibFactory,
		bbtCalibUser,
		bbtCalibRecalibrate,
		bbtDefUsrTypes,
		bbtUserList,
		bbtPolicy,
		bbtOperator,
		bbtTechnician,
		bbtSupervisor,
		bbtEngineer,
		bbtStatusleftMove,
		bbtStatusrightMove,
		bbtStatusMoveUp,
		bbtStatusMoveDown,
		bbtStatusZoomInY,
		bbtStatusZoomOutY,
		bbtStatusZoomInTime,
		bbtStatusZoomOutTime,
		bbtStatusAction,
		bbtStatusLink,
		bbtStatusUnLink,
		bbtStatusSwap,
		bbtStatusDualCursors,
		bbtStatusSingleCursor,
		bbtStatusMessageSearch,
		bbtStatusleftMessage,
		bbtStatusrightMessage,
		bbtScreenList,
		bbtScreenReplay,
		bbtScreenEdit,
		bbtScreenClean,
		bbtScreenTouchCalib,
		bbtScreenTouchTest,
		bbtBatchStart,
		bbtBatchStop,
		bbtBatchPause,
		bbtBatchResume,
		bbtBatchAbort,
		bbtBatchComment,
		bbtSmallNext,
		bbtSmallPrev,
		bbtAdduser,
		bbtDelUser,
		bbtResetPassword,
		bbtUnlockUser,
		bbtLockUser,
		bbtLogOn,
		bbtLogOff,
		bbtEventsCountersCfgTimeSync,		//TimeSync...
		bbtRestart,
		bbtHotButton,
		BBTMediaConf,
		bbtSecurity,            //Security_btn
		bbtRecorderUpgrade,
		bbtIOUpgrade,
		bbtAMS2750StatusTCUsage,
		bbtAMS2750StatusSensorsCal,
		bbtAMS2750StatusGeneralCal,
		bbtAMS2750StatusExportCal,
	};

	/// Variable indicating the default font size - Note: Update the constructor with the value of this variable too
	static const USHORT ms_usDEFAULT_FONT_SIZE;

	// Defualt constructor - used for data driven buttons
	CV6BitmapButton();

	// Constructor for standard bitmap buttons like exit and help
	CV6BitmapButton(const T_BTN_STYLE eBTN_STYLE, const T_BTN_BITMAP_TYPE eBTN_BMP_TYPE = bbtNone,
			glbpV6BtnCallbackFunction pCallback = NULL, const int iInstance = 0, const bool bWORD_WRAP = false,
			const bool bLEFT_JUSTIFY = false,
			const USHORT usFONT_SIZE = 14 /* NOTE - must be the same as the default font size var above*/,
			const int iWEIGHT = QFont::Normal, const bool bINCLUDES_TAB_CHARS = false);

	// Method that checks the required animation state of advanced bitmap buttons
	void CheckButton(const bool bFORCE_UPDATE = false);

	// Method that fits the text ot the button rectangle
	void FitText(const QString   &rstrBTN_TEXT, const QRect &rtBTN_RECT, HDC hDC);

	// Accessor Methods
	void SetTextColour(const COLORREF crCOLOUR) {
		m_crTextCol = crCOLOUR;
	}

	const COLORREF GetTextColour() const {
		return m_crTextCol;
	}

	// method that returns the button bitmap details
	QImage GetButtonBitmapProps(long &rlWIDTH, long &rlHEIGHT) const;

	const long GetButtonWidth() const {
		return m_lWidth;
	}

	const long GetButtonHeight() const {
		return m_lHeight;
	}

	static const long GetButtonWidth(const CV6BitmapButton::T_BTN_STYLE eBTN_STYLE);

	static const long GetButtonHeight(const CV6BitmapButton::T_BTN_STYLE eBTN_STYLE);

	QImage GetButtonBitmap() {
		return m_hUpBitmap;
	}

	void SetLocked(const bool bLOCKED) {
		m_bLocked = bLOCKED;
	}

	const bool GetLocked() {
		return m_bLocked;
	}

	void SetSelected(const bool bSELECTED) {
		m_bSelected = bSELECTED;
	}

	const bool GetSelected() const {
		return m_bSelected;
	}

	// Method that sets a new button bitmap icon
	void SetNewButtonBmp(const T_BTN_BITMAP_TYPE eNewBtnBmp);

	void SetSecurityArea(T_AUTHENTICATION_AREAS Area);

	// Method that determines if this is a finish style advanced menu button
	const bool IsAdvFinishMenuBtn() const {
		return (CV6BitmapButton::bsAdvancedFinishMenu == m_eBtnStyle);
	}

	// Method that determines if this is a back style advanced menu button
	const bool IsAdvBackMenuBtn() const {
		return (CV6BitmapButton::bsAdvancedBackMenu == m_eBtnStyle);
	}
	void EnableButton(const BOOL bEnable, glbpV6BtnCallbackFunction pCallback = NULL);

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CV6BitmapButton)
public:
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
protected:
//	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
//	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CV6BitmapButton();

protected:
	//OEMinfo* - mainly for TTR6SETUP usage
	COEMInfo *m_pOEMInfo;

	/// Spare DC used for loading bitmaps
	HDC m_hDC;

	/// The width and height of the up bitmap and thus button
	long m_lHeight;
	long m_lWidth;

	// Method that copies a transparent bitmap to the main DC
	void CopyTransparentBitmap(HDC hDC, const ULONG ulSOURCE_WIDTH, const ULONG ulSOURCE_HEIGHT,
			const ULONG ulDEST_WIDTH, const ULONG ulDEST_HEIGHT, const long lDEST_X_START = 0,
			const long lDEST_Y_START = 0);

private:
	/// Pointer to a callback function that updates/animates the button - only used for
	/// special buttons
	/*const*/
	glbpV6BtnCallbackFunction m_pCALLBACK;

	/// The style of button
	T_BTN_STYLE m_eBtnStyle;

	/// The bitmap type to go on top of the button
	T_BTN_BITMAP_TYPE m_eBtnBmp;

	/// The new bitmap type to go on top of the button - this will replace m_eBtnBmpType and then be reset
	T_BTN_BITMAP_TYPE m_eNewBtnBmp;

	/// The subtitle text - only used for special buttons
	QString   m_strSubTitleText;

	/// The background colour of the button - unused?
	COLORREF m_crBkgCol;

	/// The text colour
	COLORREF m_crTextCol;

	/// The disabled text colour
	COLORREF m_crDisabledTextCol;

	/// The locked text colour
	COLORREF m_crLockedTextCol;

	/// Up/Down bitmap handles
	QImage m_hUpBitmap;
	QImage m_hDownBitmap;
	QImage m_hFocusBitmap;
	QImage m_hDisabledBitmap;

	/// Additional button bitmap - usually an icon and only used for special buttons
	QImage m_hForeGndBitmap;
	QImage m_hForeGndDisabledBitmap;

	/// The width and height of the foreground bitmap
	long m_lForeGndBmpHeight;
	long m_lForeGndBmpWidth;

	/// Flag indicating if the button should be locked e.g. disabled but not greyed out
	bool m_bLocked;

	/// Flag indicating if the button is to remain in a selected state
	bool m_bSelected;

	/// Flag indicating the text should be wrapped
	const bool m_bWORD_WRAP;

	// Flag indicating the text should be left justified rather than centered
	const bool m_bLEFT_JUSTIFY;

	/// Variable indicating the required button text format
	ULONG m_ulTextasprintf;

	/// Variable indicating the required font size
	/*const*/
	USHORT m_usFONT_SIZE;

	/// Variable indicating the required font weight
	const int m_iWEIGHT;

	/// Varaible indicating if the title text string includes tab characters - only applies to the data driven
	// left or right buttons at the moment
	const bool m_bINCLUDES_TAB_CHARS;

	/// variable indicating the security area the button belongs to
	T_AUTHENTICATION_AREAS m_SecurityArea;

	// Method that loads in the standard button colours
	void SetupSystemColours();

	/// Method that loads the appropropriate sized bitmap for the button
	void SetupBkGndBitmaps(const T_BTN_STYLE eBTN_STYLE);

	// Method that loads the foreground bitmap for the button
	void SetupForeGndBitmap(const T_BTN_BITMAP_TYPE eBTN_BMP_TYPE);

	// Method that copies a bitmap to the main DC
	void CopyBitmap(HDC hDC);

	// Method that draws a left or right data driven button which are a bit different to all the other buttons
	void DrawDataDrivenBtn(LPDRAWITEMSTRUCT lpDrawItemStruct);

	// Method that draws other types of button e.g. not data driven ones
	void DrawNormalBtn(LPDRAWITEMSTRUCT lpDrawItemStruct);

	// Generated message map functions
protected:
	//{{AFX_MSG(CV6BitmapButton)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG

DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnLButtonUp(UINT nFlags, QPoint point);
};

/// Typedef for bitmap buttons lists
typedef std::vector<CV6BitmapButton*> V6BitmapButtonList;

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_V6BITMAPBUTTON_H__97FCDE52_6A80_4B24_875D_CE54FE29087E__INCLUDED_)

#ifndef __TRANSFERDEVICE_H_INCLUDED__
#define __TRANSFERDEVICE_H_INCLUDED__

#include "TVtime.h"
#include "logrec.h"

#include "CStorage.h"
#include "LogDeviceStatus.h"

#include "StoragePaths.h"

//**Class*********************************************************************
///
/// @brief 
/// 
///
//****************************************************************************

class CTransferDevice {
public:
	CTransferDevice();
	~CTransferDevice();
	void Initialise();

	void SetID(T_LOG_DEVICE deviceID);					// Set device identification
	T_LOG_DEVICE GetID() const;							// Get log device identification

	WCHAR* GetDeviceName();								// Get device name (base folder)
	WCHAR* GetFolderName();								// Get full device and folder

	BOOL OpenDevice();										// Open a device prior to a data transfer
	BOOL CloseDevice();

    CStorage* OpenFile(QString  filename, UINT flags);		// Open/Create a file
	BOOL CloseFile(CStorage *file);						// Close a prteviously opened file
	BOOL Write(CStorage *file, void *buffer, UINT size);	// Write to a previously opened file
	BOOL Read(CStorage *file, void *buffer, UINT size);	// Read from a previously opened file
    void Delete(QString  filename);							// Delete a single file
    void DelTree(QString  path);							// Delete a complete file tree; use with care!

	T_QMC_FILE_BLOCK_TRANSACTION* GetTransferStatus(USHORT instance, T_STATUS_TYPE type);
	BOOL SetTransferStatus(USHORT instance, T_STATUS_TYPE type, T_QMC_FILE_BLOCK_TRANSACTION location);
	ULONG GetAvailableSpace();								// Get available device space (may not be free space)

	// get storage size of the device
	const ULONG GetDeviceSize() const;

	// get data transfer device used space
	const ULONG GetDeviceUsedSpace() const;

	// get data transfer device free space
	const ULONG GetDeviceFreeSpace() const;

	/// Variable used as a minimum when determining is there is any available disk space
	static const ULONG ms_ulFREE_SPACE_MIN_KB;

private:
	CLogDeviceStatus *m_pTransferStatus;
	T_LOG_DEVICE m_deviceID;

	WCHAR m_DeviceName[MAX_PATH];							/// Base device name
	WCHAR m_FolderName[MAX_PATH];							/// Full data extraction path and folder
};

#endif // __TRANSFERDEVICE_H_INCLUDED__

#ifndef _PPQMESSAGES_H
#define _PPQMESSAGES_H

#include "PPQCommon.h"

typedef enum {
	PPQUI_ANALOGUE_ENABLEPPQ,
	PPQUI_ANALOGUE_SYNCPPQ,
	PPQUI_ANALOGUE_ADDTIMESTAMPREADING,
	PPQUI_ANALOGUE_ADDREADING,
	PPQUI_ANALOGUE_GETREADING,
	PPQUI_REPORT_ERROR

} T_PPQUI_MSG_TYPE;

typedef enum {
	PPQUI_UNPROCESSED_DATA_OVERWRITTEN

} T_PPQUI_ERROR_CODE;

typedef struct {
	T_PPQUI_MSG_TYPE msgType;
	USHORT reference;
	USHORT msgLength;
	DWORD data[1];

} T_PPQUI_MSG;

typedef struct {
	T_PPQC_QUEUE_TYPE type;
	T_PPQC_ACQUSITION_RATE acquistionRate;
	T_PPQC_STATUS status;
	T_PPQC_APCARD_TICK_RATE clockTickRate;

} T_PPQUI_ANALOGUE_ENABLEPPQ_MSG;

typedef struct {
	LONGLONG minSysCoverage;
	LONGLONG maxSysCoverage;
	T_PPQC_STATUS status;

} T_PPQUI_ANALOGUE_SYNCPPQ_MSG;

typedef struct {
	USHORT lastPredictedAITick;
	USHORT lastActualAITick;
	SHORT lastTickDifference;

} T_PPQUI_ANALOGUE_ADDTIMESTAMPREADING_MSG;

typedef struct {
	USHORT rear;
	USHORT numOfReadings;
	FLOAT reading;
	LONGLONG maxSysCoverage;

} T_PPQUI_ANALOGUE_ADDREADING_MSG;

typedef struct {
	USHORT front;
	USHORT numOfReadings;

} T_PPQUI_ANALOGUE_GETREADING_MSG;

typedef struct {
	T_PPQUI_ERROR_CODE errorCode;

} T_PPQUI_ERROR_MSG;

#endif // _PPQMESSAGES_H

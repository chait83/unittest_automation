/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	Configuration Manager
/// @n Filename: CMMDefines.h
/// @n Desc:	Declarations of user defined datatypes common 
///				to CMM and its clients.
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[1]:
// 8	Stability Project 1.5.1.1	7/2/2011 4:56:09 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// $
//
// ****************************************************************
/******************************************************************************************
 COPYRIGHT (c) 2004
 HONEYWELL INC.,
 ALL RIGHTS RESERVED
 This software is a copyrighted work and/or information protected
 as a trade secret. Legal rights of Honeywell Inc. in this
 software is distinct from ownership of any medium in which the
 software is embodied. Copyright or trade secret notices included
 must be reproduced in any copies authorized by Honeywell Inc.
 The information in this software is subject to change without
 notice and should not be considered as a commitment by Honeywell
 Inc.
 ******************************************************************************************/
#ifndef CMMDEFINES_H
#define CMMDEFINES_H
#pragma once

//******************************************************
// typedef struct CONFIGLOG_RECORD
///
/// The data type to be used instead of BOOL in CMM.
///	(BOOL will not be used as "int" data type is to be
///	avoided.)
///
//******************************************************
#ifndef TV_BOOL							
typedef unsigned short TV_BOOL;
#endif
#include "Defines.h"

#define CLASS_STRUCTURE 1
#define CLASS_UNION 1
//ENUMERATIONS
//*******************************************************
// enum CMMERROR
///
/// Error codes to be returned to functions calling
///	CMM APIs.
///
//*******************************************************
typedef enum enumCMMERROR {
	CMM_SUCCESS = 0,
	CMM_FAILED,
	CMM_INVALID_METADATA,
	CMM_INVALID_PARAMETER,
	CMM_INSUFFICIENT_MEMORY,
	CMM_NOT_INITIALIZED,
	CMM_VALUE_OUT_OF_RANGE,
	CMM_INVALID_CONFIGURATION_ID,
	CMM_CONFIGURATION_UNAVAILABLE,
	CMM_CONFIGURATION_FILE_NOT_FOUND,
	CMM_CONFIGURATION_CORRUPT,
	CMM_INVALID_BLOCK_TYPE,
	CMM_INVALID_INSTANCE
} CMMERROR;
//*******************************************************
// enum REFERENCE
///
/// Indicates if a operation has to be carried out in 
///	the Working section or the Current section
///
//*******************************************************
typedef enum enumREFERENCE {
	CONFIG_MODIFIABLE = 0, CONFIG_COMMITTED
} REFERENCE;

typedef enum {
	CONFIG_LOAD = 0, CONFIG_SAVES, CONFIG_CHANGES, CONFIG_VERSION_UP, CONFIG_VERSION_DOWN
} OPERATIONS;
/*
 typedef enum {
 CSTATUS_OK = 0,
 CSTATUS_FAIL,
 CSTATUS_INVALID_PARAMETER,
 CSTATUS_METADATA_NOTINITIALIZED,
 CSTATUS_INVALID_CONFIGURATION,
 CSTATUS_INVALID_BLOCKTYPE,
 CSTATUS_INVALID_INSTANCE,
 CSTATUS_POINTER,
 CSTATUS_VALUE_OUT_OF_RANGE,
 CSTATUS_UNSUPPORTED_DATATYPE
 } CMMSTATUS;*/

typedef enum {
	INSTANCE_MODIFIED = 0, INSTANCE_DELETED, INSTANCE_NOT_AVAILABLE, INSTANCE_ADDED
} INSTANCE_DEF;

typedef enum {
	INCLUDE_ALL = 0, INCLUDE_NONE
} COMPUTE_INCLUDE;
//STRUCTURES
//******************************************************
// typedef struct CONFIGLOG_RECORD
///
/// @brief --- Log Information containing statistics.
///
/// Contains the statistics related to each operation
///	performed on a configuration.
///
//******************************************************
typedef struct stCONFIGLOG_RECORD {
	LONGLONG dtChangeDateTime;		//The Date/Time information for the record.
	DWORD dwSerialNumber;		//The Serial Number of the Recorder where the change was made.
	DWORD dwAction;						//An enumerated Action value
} CONFIGLOG_RECORD;
//******************************************************
// typedef struct CONFIGLOG_INFO
///
/// @brief --- Statistics on the various operations.
///
/// Statistics on the various operations performed on 
///	the configuration.
///
//******************************************************
typedef struct stCONFIGLOG_INFO {
	WORD wTotalLoad;	//The total number of times the configuration is loaded
	WORD wTotalSave;	//The total number of times the configuration is saved.
	WORD wTotalVersionUpgrade;	//The total number of times the version is upgraded.
	WORD wTotalVersionDowngrade;	//The total number of times the version is downgraded.
	WORD wTotalChanges;	//The total number of times the configuration is changed
	WORD wReserved;						//Reserved for future use.
	CONFIGLOG_RECORD ConfigRecord[100];	//The array of latest records maintained against the statistics of Load (10), Save (10), Version downgrade (20), Version upgrade (20) and Changes (40)
} CONFIGLOG_INFO;
//******************************************************
// typedef struct BLOCK_INFO
///
/// @brief --- Block Information structure.
///
/// THe structure to be used to pass information 
///	relating to data blocks, to and from CMM APIs.
///
//******************************************************
typedef struct stBLOCK_INFO {
	DWORD dwSessionNumber;	//The Session Number associated with a data block
	WORD wInstanceID;		//The instance ID to be associated with the block	
	WORD wBlockType;				//The type specifier for the block.
	DWORD dwBlockSize;			//The size of the block to be allocated -- DWORD assigned to 4 byte align the structure
	BYTE *pByBlock;	//The pointer to the block allocated of the specified size.		
} BLOCK_INFO;

/****START -- Config File Structures --******/

//******************************************************
// typedef struct CONFIGFILE_HEADER
///
/// @brief --- Config File Header
///
/// Contains the parameters to be stored in the
/// configuration file header.
///
//******************************************************
typedef struct stCONFIGFILE_HEADER {
	WCHAR szFileName[60];					//The configuration file name	
	LONGLONG dtCreationDateTime;					//The Creation Date/Time information of the configuration file.
	WCHAR szPassword[18];					//Password.
	WORD wEncryption;		//Flag to indicate if password has been encrypted	
	WORD wFileType;						//The configuration file type	
	DWORD dwSource;						//The Source of the Configuration File	
	LONG lMDOffset;				//Metadata offset within the configuration file
	LONG lDataOffset;		//Datablock offset within the configuration file	
	CONFIGLOG_INFO sConfigInfo;		//Contains statistics of reads and writes	
} CONFIGFILE_HEADER;
//******************************************************
// typedef struct DATA_BLOCK_HEADER
///
/// @brief --- Data Block Header
///
/// Structure of the Data block header.
///
//******************************************************
typedef struct stDATABLOCK_HEADER {
	WORD wBlockType;						//The block type of the datablock
	WORD wInstanceNumber;						//The instance number of the datablock.. MSB contains the Dirty Bit
	DWORD dwSessionId;		//Session id in which the record was modified last.
	DWORD dwBlockSize;		//Size of the datablock without the header -- DWORD assigned to 4 byte align the structure
	USHORT sBlockCRC;						//Data block CRC.
	USHORT sPadding;						//Padding for 4Byte alignment. 		
} DATA_BLOCK_HEADER;
/****END -- Config File Structures --******/

//******************************************************
// typedef struct CONFIGHEADERINFO 
///
/// @brief --- Structure to be sent in SetConfigLog API.
///
/// Parameters to be sent to be added to the configuration
///	header after a save.
///
//******************************************************
typedef struct stCONFIGFILE_HEADER_DETAILS {
	WCHAR szFileName[60];				//The configuration file name 
	LONGLONG dtCreationDateTime;				//The Creation Date/Time information of the configuration file. 
	WCHAR szPassword[18];				//Password. 
	WORD wEncryption;		//Flag to indicate if password has been encrypted 
	WORD wFileType;						//The configuration file type 
	DWORD dwSource;				//The Source of the Configuration File		
	DWORD dwAction;						//dwAction flag for save 
} CONFIGHEADERINFO;
#endif

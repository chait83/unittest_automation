/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	Op Panel
/// @n Filename: EUDCDefs.h
/// @n Description: PC and recorder defines for EUDC characters
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 13	Stability Project 1.10.1.1	7/2/2011 4:57:07 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 12	Stability Project 1.10.1.0	7/1/2011 4:27:44 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 11	V6 Firmware 1.10		4/4/2007 5:37:10 PM	Roger Dawson 
//		Added the ability to view reports that have been generated in RTF
//		format on the recorder.
// 10	V6 Firmware 1.9		2/21/2007 9:31:30 PM	Roger Dawson 
//		Added define for the SIP backspace character.
// $
//
// **************************************************************************

#ifndef _EUDCDEFS_H
#define _EUDCDEFS_H
#include "Defines.h"
// Const used to identify where the custom characters are located
const WCHAR g_wcSTART_OF_CUSTOM_CHARS = 0xE000;

const WCHAR g_wcTRI_FORWARD = 0xE020;
const WCHAR g_wcTRI_BACKWARD = 0xE021;
const WCHAR g_wcALARM_MKR_HI = 0xE022;
const WCHAR g_wcALARM_MKR_LO = 0xE023;
const WCHAR g_wcALARM_MKR_RT_DW = 0xE024;
const WCHAR g_wcALARM_MKR_RT_UP = 0xE025;
const WCHAR g_wcALARM_MKR_DEV = 0xE026;

const WCHAR g_wcTICK = 0xE042;
const WCHAR g_wcCROSS = 0xE043;

const WCHAR g_wcFULLSQUARE = 0xE040;
const WCHAR g_wcSMALLSQUARE = 0xE041;
const WCHAR g_wcSMALL_RIGHT_ARROW = 0xE007;

const WCHAR g_wcOVER_RANGE = 0x0E051;
const WCHAR g_wcUNDER_RANGE = 0x0E050;
const WCHAR g_wcINVALID = 0x0E027;

const WCHAR g_wcOMEGA = 0xE060;
const WCHAR g_wcBACKSPACE = 0xE061;

const WCHAR g_wcRECORDING = g_wcTICK;
const WCHAR g_wcREC_STOP = g_wcCROSS;

// special control characters used for embedding data in the strings
const WCHAR g_wcEMBEDDED_INFO_DELIM = L'¦';
const WCHAR g_wcMOD_COLOUR = 0xEFFF;

const WCHAR g_wcSTART_OF_TABLE_ROW = 0xEFF0;
const WCHAR g_wcEND_OF_TABLE_ROW = 0xEFF1;
const WCHAR g_wcEND_OF_TABLE_CELL = 0xEFF2;
const WCHAR g_wcSTART_OF_TABLE = 0xEFF3;
const WCHAR g_wcEND_OF_TABLE = 0xEFF4;

/// Message List Codes
const WCHAR g_wcINFO = 0xE070;
const WCHAR g_wcLOCK = 0xE071;
const WCHAR g_wcUNLOCK = 0xE072;
const WCHAR g_wcOUT_ALARM = 0xE073;
const WCHAR g_wcKEY = 0xE074;
const WCHAR g_wcOFF = 0xE075;
const WCHAR g_wcON = 0xE076;
const WCHAR g_wcPAUSE = 0xE077;
const WCHAR g_wcSTART = 0xE078;
const WCHAR g_wcSTOP = 0xE079;
const WCHAR g_wcWARNING = 0xE07A;
const WCHAR g_wcERROR = 0xE07B;
const WCHAR g_wcACCESS_DEN = 0xE07C;
const WCHAR g_wcMARK_CHART = 0xE07D;
const WCHAR g_wcIN_ALARM = 0xE07E;

#endif // _EUDCDEFS_H

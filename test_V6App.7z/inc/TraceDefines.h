#pragma once

#if !defined(_qDebugDEFINES_H_)
#define _qDebugDEFINES_H_

//Maximum length of the diagnostic messages.
#define MAX_MESSAGE_LEN	1024

// combinations of bits below (0-27) are to be given to the macros
// and must match the global mask bits (depending on any/all mode, except
// for TRACE_ALWAYS where match is not required)

#define TRACE_ALWAYS			0x00000001
#define TRACE_CMM				0x00000002
#define TRACE_PMM				0x00000004
#define TRACE_MM				0x00000008
#define TRACE_CTRL_SEQUENCER	0x00000010
#define TRACE_IO_SCHED			0x00000020
#define TRACE_MODBUS			0x00000040
#define TRACE_PROCESSING		0x00000080
#define TRACE_TRANSFER			0x00000100
#define TRACE_LOGGING			0x00000200
#define TRACE_OPPANEL			0x00000400
#define TRACE_MESSAGE_LIST		0x00000800
#define TRACE_PERSIST			0x00001000
#define TRACE_LCM				0x00002000
#define TRACE_CONFIG			0x00004000
#define TRACE_DEVICE			0x00008000
#define TRACE_QUEUE_MANAGER		0x00010000
#define TRACE_AUTO_OPS			0x00020000

#define TRACE_M18			0x00040000
#define TRACE_M19			0x00080000
#define TRACE_M20			0x00100000
#define TRACE_M21			0x00200000
#define TRACE_M22			0x00400000
#define TRACE_M23			0x00800000

#define TRACE_M24			0x01000000
#define TRACE_M25			0x02000000
#define TRACE_M26			0x04000000
#define TRACE_M27			0x08000000

// the bits below (28-31) are to be setup in the global mask
// macros do not use these bits

#define TRACE_RESV1			0x10000000
#define TRACE_RESV2			0x20000000
#define TRACE_REVS3			0x40000000
#define TRACE_2_FILE		0x80000000

typedef enum enumErrorType {
	TYPE_INFO = 1, TYPE_WARNING, TYPE_ERROR, TYPE_CRITICAL
} T_ENUMERRORTYPE;

//if qDebugALL defined then trace all level of trace.
#ifdef qDebugALL
#define LOG_TRACE_ENABLED
#define WARNING_TRACE_ENABLED
#define ERROR_TRACE_ENABLED
#define CRITICAL_TRACE_ENABLED
#endif

#include "TraceMsg.h"

#ifdef UNDER_CE
#if _MSC_VER < 1300
#define __FUNCTION__ QString  ("-")
#endif
#endif

#ifdef LOG_TRACE_ENABLED
#define LOG_INFO if (g_pTracer &&(g_pTracer->m_szFileName = __FILE__) \
			&& (g_pTracer->m_szFunctionName = __FUNCTION__ ) \
			&& (g_pTracer->m_iLineNo = __LINE__)	\
			&& (g_pTracer->m_enumLogLevel = TYPE_INFO)) g_pTracer->OutputDebugTrace
#else 
#define LOG_INFO 
#endif
#ifdef WARNING_TRACE_ENABLED
#define LOG_WRN if (g_pTracer &&(g_pTracer->m_szFileName = __FILE__) \
			&& (g_pTracer->m_szFunctionName = __FUNCTION__ ) \
			&& (g_pTracer->m_iLineNo = __LINE__)	\
			&& (g_pTracer->m_enumLogLevel = TYPE_WARNING)) g_pTracer->OutputDebugTrace
#else 
#define LOG_WRN 
#endif

#ifdef ERROR_TRACE_ENABLED
#define LOG_ERR if (g_pTracer &&(g_pTracer->m_szFileName = __FILE__) \
			&& (g_pTracer->m_szFunctionName = __FUNCTION__ ) \
			&& (g_pTracer->m_iLineNo = __LINE__)	\
			&& (g_pTracer->m_enumLogLevel = TYPE_ERROR)) g_pTracer->OutputDebugTrace
#else 
#define LOG_ERR 
#endif

#ifdef CRITICAL_TRACE_ENABLED
#define LOG_CRTL if (g_pTracer &&(g_pTracer->m_szFileName = __FILE__) \
			&& (g_pTracer->m_szFunctionName = __FUNCTION__ ) \
			&& (g_pTracer->m_iLineNo = __LINE__)	\
			&& (g_pTracer->m_enumLogLevel = TYPE_CRITICAL)) g_pTracer->OutputDebugTrace
#else 
#define LOG_CRTL 
#endif

#endif // _qDebugDEFINES_H_

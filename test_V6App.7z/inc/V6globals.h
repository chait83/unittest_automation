/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	Generic
/// @n Filename: V6globals.h
/// @n Desc:	All globals for V6 platform
///				
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 46	Stability Project 1.41.1.3	7/2/2011 5:02:42 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 45	Stability Project 1.41.1.2	7/1/2011 4:39:17 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 44	Stability Project 1.41.1.1	3/28/2011 3:06:59 PM	Hemant(HAIL) 
//		Updated: Thread Synchronization included in operator overloads.
// 43	Stability Project 1.41.1.0	2/15/2011 3:04:13 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
// ****************************************************************

#ifndef __V6GLOBALS_H__
#define __V6GLOBALS_H__

#include "NVVariables.h"
#include "DataItemTable.h"
#include "SetupConfiguration.h"
#include "PasswordConfiguration.h"
#include "SysTimer.h"
#include "SysInfo.h"
#include "MessageListServices.h"
#include "LayoutConfiguration.h"
#include "TVtime.h"
#include "TabularReadings.h"
#include "AMS2750TUSMgr.h"
#include "Defines.h"
#include <fstream>
using namespace std;

extern CDeviceAbstraction *pGlbDal;		///< Gloabl Ddevice abstraction layer
extern CDeviceCaps GlbDevCaps;	///< Device Capabilities instance for recorder
extern CDataItemManager *pGlbDIT;		///< Handle on Data Item Table singleton
extern CSetupConfiguration *pGlbSetup;		///< Pointer to Current Setup configuration
extern CPasswordConfiguration *pPwdSetup;		///< Pointer to Password Setup configuration
extern CV6SystemTimer *pGlbSysTimer;	///< Pointer to System Timer singleton
extern CSysInfo *pGlbSysInfo;			///< Pointer to System Info singleton
extern CMessageListServices *pGlbMsgListSer;			///< Pointer to Message List Services Singleton
extern CNVVariableBlockManager *pGlbNVVars;		///< Pointer to NV Variables
extern CLayoutConfiguration *pGlbLayout;		///< Pointer to the current layout configuration
extern CTabularReadings *pGlbTabReadings;	///< Pointer to the tabular readings
extern CAMS2750TUSMgr *pGlbTUSMgr;				///< Pointer to TUS Manager
//extern CSimpleLog logger;

extern BSP_VERSION g_BSPVersion; //Added by dharma kiran
extern QString  g_FormatType; //Added For the Fix for 1-1713TYI - GR_General Status shows "Internal Mem ID as 512(null)
// Semaphore for V6AppInterface access
typedef enum {
	APPACCESS_OK, APPACCESS_LOCKED, APPACCESS_SHUTDOWN

} T_APPINTERFACE_SEMAPHORE;

extern T_APPINTERFACE_SEMAPHORE volatile GlbAppStateSema; ///< Semaphore for AppInterface if it is safe to access system

// Log System Message to the Message List for Processing
const T_MSGLISTSER_RETURN_VALUE LogSystemMessage(const T_MSGLISTSER_SYSTEM_MSG_TYPE msgType, const QString  &rstrMESSAGE,
		const BYTE byMESSAGE_FLAGS = 0);

// Log Diagnostic Message to the Message List for Processing
const T_MSGLISTSER_RETURN_VALUE LogDiagnosticMessage(const T_MSGLISTSER_DIAGNOSTIC_MSG_TYPE msgType,
		const QString  rstrMESSAGE);

// Message List Defines for ease of use when logging Messages. 
#define LOG_SYSTEM_MESSAGE			LogSystemMessage

#if (! defined (P2P_WRAPPER))
#define LOG_DIAGNOSTIC_MESSAGE		LogDiagnosticMessage
#else
#define LOG_DIAGNOSTIC_MESSAGE		LogDummyMessage
#endif

#define LOG_SECURITY_MESSAGE		pGlbMsgListSer->LogSecurityMessage
#define LOG_ALARM_MESSAGE			pGlbMsgListSer->LogAlarmMessage
#define LOG_USER_MESSAGE			pGlbMsgListSer->LogUserMessageOnChart
#define LOG_BATCH_MESSAGE			pGlbMsgListSer->LogBatchMessage
#define LOG_DATA_MESSAGE			pGlbMsgListSer->LogUserMessageOnChart
#define LOG_DIGITAL_CHART_MESSAGE	pGlbMsgListSer->LogUserMessageOnChart
#define LOG_DIGITAL_MESSAGE			pGlbMsgListSer->LogUserMessageList
#define LOG_SMTP_MESSAGE			pGlbMsgListSer->LogSMTPMessage
#define LOG_FTP_MESSAGE				pGlbMsgListSer->LogFTPMessage

#if (! defined (P2P_WRAPPER))
#define LOG_P2P_MESSAGE				pGlbMsgListSer->LogP2PMessage
#else
#define LOG_P2P_MESSAGE				LogDummyMessage
#endif

#define ENTER_SECURE_ZONE			pGlbSysInfo->SetRecSecurityZone
#define LEAVE_SECURE_ZONE			pGlbSysInfo->SetRecSecurityZone

// Global access abstractions, must remain constant but allows changes to instances and locations
#define DEVICE_INFO		GlbDevCaps					///< Device capabilities
#define pDEVICE_INFO	(&GlbDevCaps)				///< Ptr to Device capabilities
#define pSYSTEM_INFO	pGlbSysInfo					///< System information base
#define pDIT			pGlbDIT						///< Data Item Table
#define pSYSTIMER		pGlbSysTimer				///< System Timer
#define pSETUP			pGlbSetup					///< Setup configuration
#define pPASSWORD		pPwdSetup					///< Password configuration
#define pOEM_INFO		pGlbSysInfo->pOemInfo		///< OEM information
#define pNV_VARS		pGlbNVVars					///< NV Variables
#define pDALGLB			pGlbDal						///< DAL
#define pSCRIPTS		pGlbScriptManager			///< Script Manager (Globals instance held in Scripts.cpp with extern in Scripts.h)
#define pMSG_SERVICES	pGlbMsgListSer				///< Message services pointer
#define pTABULAR		pGlbTabReadings				///< Tabular readings data
#define pTUSMGR			pGlbTUSMgr					///< TUS Manager

// Function prototypoes for V6Globals.cpp
BOOL InitGlobals();

// Prototypes for fucntion pointers into script services
extern "C" {
int LookUpRefForDITByVarname(char *pvarName);
float GetDITValueByRef(int ref);
}
;

#ifdef __IMPLMT_HEAP__
// ----------------------------------------------------------------------------------------------------------
// Globals for Heap Memory Management.
// -----------------------------------------------------------------------------------------------------------

//////////////////////////////////////////////////////////////////////////////
//
//	Global Members.
//
//////////////////////////////////////////////////////////////////////////////
#define INITIAL_HEAP_SIZE					0			// Initial heap size is 0
#define MAX_HEAP_SIZE						0			// Max heap size is zero (growing heap)
#define EXTRA_BYTES_FOR_HEAP_HANDLE			4			// 4 Bytes for storing heap handles.
#define EXTRA_BYTES_FOR_THREAD_HANDLE		4			// 4 Bytes for storing heap handles.
#define HEAP_ALLOC_THRESHOLD_1				36			// 36 Bytes
#define HEAP_ALLOC_THRESHOLD_2				1024		// 1024 Bytes
#define HEAP_ALLOC_THRESHOLD_3				20000		// 20000 Bytes

// forward declaration of global members....
// Handles for Heaps
extern HANDLE m_hHeap_1;
extern HANDLE m_hHeap_2;
extern HANDLE m_hHeap_3;
extern HANDLE m_hHeap_4;

extern QMutex csPrivateHeap;

//////////////////////////////////////////////////////////////////////////////
//
//	Global Functions.
//
//////////////////////////////////////////////////////////////////////////////
void* operator new( size_t nSize );
void* operator new[]( size_t nSize );
void operator delete( void *ptr );
void operator delete[]( void *ptr );

void GlobalHeapCreate();

#endif // __IMPLMT_HEAP__

#endif // __V6GLOBALS_H__

void BlockServicesError(const QString  strERROR);

void FreeBlockQueueError(const QString  strERROR);


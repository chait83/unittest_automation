/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Extension DLL
/// @n Filename: Extension.h
/// @n Desc:	 Allows App level access to OS level functionality.
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log:
//  3 Stability Project 1.0.1.1 7/2/2011 4:57:11 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  2 Stability Project 1.0.1.0 7/1/2011 4:27:27 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  1 V6 Firmware 1.0 4/21/2005 6:41:54 PM  Martin Miller  
// $
//
// ****************************************************************

#ifndef _EXTENSION_H_
#define _EXTENSION_H_
#include "Defines.h"
//
// asprintf return codes, move to common header.
//
#define UNFORMATED		0x8000
#define FORMAT_FAT_16	0x8001
#define FORMAT_TFAT_16	0x8002
#define FORMAT_FAT_32	0x8003
#define FORMAT_TFAT_32	0x8004

//
// Byte offsets
// This is a quick and dirty format check.
//
#define FAT_16_FORMAT	54
#define FAT_32_FORMAT	82
#define VOLUME_SIZE		11
#define FAT_16_VOLUME	43
#define FAT_32_VOLUME	71

#ifndef _DISKIO_H_
// App level stuff
extern "C" {
//	__declspec( dllimport )
unsigned short Volumeasprintf(QString  wszVolume, int iFAT, BOOL bTFAT, BOOL bFull, void Progress(DWORD dwPercent),
  BOOL Message(QString   szMessage, QString   szCaption, BOOL fYesNo));
//	__declspec( dllimport )
unsigned short VolumeScan(QString  wszVolume, void Progress(DWORD dwPercent),
  BOOL Message(QString   szMessage, QString   szCaption, BOOL fYesNo));
//	__declspec( dllimport )
unsigned short Reportasprintf(QString  wszVolume);
//	__declspec( dllimport )
unsigned short ReadVolume(QString  wszVolume, QString  wszName, unsigned short usSize);
//	__declspec( dllimport )
unsigned short WriteVolume(QString  wszVolume, QString  wszName);
//	__declspec( dllimport )
unsigned short CopyHive(QString  wszDestination1, QString  wszDestination2);
}
#else
// CE level stuff
extern "C"
{
	__declspec( dllexport )
  unsigned short Volumeasprintf( QString  wszVolume, int iFAT, BOOL bTFAT, BOOL bFull,
								 void Progress(DWORD dwPercent), 
   BOOL Message(QString   szMessage, QString   szCaption, BOOL fYesNo) );
	__declspec( dllexport )
  unsigned short VolumeScan( QString  wszVolume,
							  void Progress(DWORD dwPercent), 
  BOOL Message(QString   szMessage, QString   szCaption, BOOL fYesNo) );
	__declspec( dllexport )
  unsigned short Reportasprintf( QString  wszVolume );
	__declspec( dllexport )
  unsigned short ReadVolume( QString  wszVolume, QString  wszName, unsigned short usSize );
	__declspec( dllexport )
  unsigned short WriteVolume( QString  wszVolume, QString  wszName );
	__declspec( dllexport )
  unsigned short CopyHive( QString  wszDestination1, QString  wszDestination2 );
}
#endif

#endif // _EXTENSION_H_

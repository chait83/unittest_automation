#if !defined(AFX_REPLAYPENPICKERDLG_H__FCB62D51_1372_4CD2_9D89_DFFF5C9453D6__INCLUDED_)
#define AFX_REPLAYPENPICKERDLG_H__FCB62D51_1372_4CD2_9D89_DFFF5C9453D6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ReplayPenPickerDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CReplayPenPickerDlg dialog

#include "V6BitmapButton.h"
#include "PickerMgr.h"

// Forward Class Declaration
class CCannedScrnData;

//**CReplayPenPickerDlg*****************************************************************************
///
/// @brief Dialog class that allows users to choose replay mode pens
/// 
/// Dialog class that allows users to choose specific pens which needs to be shown in replay mode
///
//**************************************************************************************************
class CReplayPenPickerDlg: public QDialog {
// Construction
public:
	// Constructor
	CReplayPenPickerDlg(CPickerMgr &rkPickerMgr, CCannedScrnData &rkCannedScrnData, const USHORT usMIN_NO_OF_SELECTIONS,
			const USHORT usMAX_NO_OF_SELECTIONS, CWidget *pParent = NULL);

	// Destructor
	~CReplayPenPickerDlg();

// Dialog Data
	//{{AFX_DATA(CReplayPenPickerDlg)
	enum {
		IDD = IDD_REPLAY_PEN_PICKER_DLG
	};
	// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CReplayPenPickerDlg)
protected:
	virtual void DoDataExchange(CDataItem *pDX);  // DDX/DDV support
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CReplayPenPickerDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
DECLARE_MESSAGE_MAP()
private:

	/// Reference to a picker manager which has been populated elsewhere
	CPickerMgr &m_rkPickerMgr;

	/// Variable used to store the canned screen data pointer
	CCannedScrnData &m_rkCannedScrnData;

	/// Variable indicating the minimum number of selections the user can make
	const USHORT m_usMIN_NO_OF_SELECTIONS;

	/// Variable indicating the maximum number of selections the user can make
	const USHORT m_usMAX_NO_OF_SELECTIONS;

	/// List containing pointers to the dynamically created menu buttons
	std::vector<CV6BitmapButton*> m_kPickerButtonList;

	/// The banner button
	CV6BitmapButton *m_pkBannerButton;

	/// The OK button
	CV6BitmapButton *m_pkOKBtn;

	/// The cancel button
	CV6BitmapButton *m_pkCancelBtn;

	/// The clear button
	CV6BitmapButton *m_pkClearBtn;

	/// The ok/cancel/clear button style
	const CV6BitmapButton::T_BTN_STYLE m_eCONTROL_BTN_STYLE;

	/// The menu button style
	const CV6BitmapButton::T_BTN_STYLE m_eMENU_BTN_STYLE;

	/// The start position of the menu button IDs
	static const UINT ms_uiMENU_BTN_START_ID;

	/// The ID of the banner button
	static const UINT ms_uiBANNER_BTN_ID;

	/// The ID of the OK button
	static const UINT ms_uiOK_BTN_ID;

	/// The ID of the cancel button
	static const UINT ms_uiCANCEL_BTN_ID;

	/// The ID of the clear button
	static const UINT ms_uiCLEAR_BTN_ID;

	/// The ID of padded buttons
	static const UINT ms_uiPADDED_BTN_ID;

	/// Variable used to store the style of the button e.gh. owner drawn 
	static const DWORD ms_dwBTN_STYLE;

	/// Const used to store the required font size for the button text
	const USHORT m_usFONT_SIZE;

	// Method that draws the menu buttons
	void DrawMenuButtons();

	// Method that draws the picker buttons
	void DrawPickerButtons();

	// Validate the selection
	bool ValidateSelection();

	// Update the picker manager list with the current selections
	void UpdatePickerData();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_REPLAYPENPICKERDLG_H__FCB62D51_1372_4CD2_9D89_DFFF5C9453D6__INCLUDED_)

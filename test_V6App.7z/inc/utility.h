/// @file Utility.h
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	Utility
/// @n Filename: Utility.h
/// @n Desc:	Definitions of functions commonly used by both 
///				RequestHandler and Memory manager. 
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 9	Stability Project 1.5.1.2	7/2/2011 5:02:23 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 8	Stability Project 1.5.1.1	7/1/2011 4:39:06 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 7	Stability Project 1.5.1.0	1/12/2011 3:50:22 PM	Hemant(HAIL) 
//		File updated for Stability Project.
//		Please check the comment "Stability Project Fix:" for the changes
//		done to the source code in this file.
// 6	V6 Firmware 1.5		2/20/2006 4:18:02 PM	Shyam (HTSL) 
//		Added a method for bitfield validation and bitfields will be
//		validated as well.
// $
//
// ****************************************************************
/******************************************************************************************
 COPYRIGHT (c) 2004
 HONEYWELL INC.,
 ALL RIGHTS RESERVED

 This software is a copyrighted work and/or information protected
 as a trade secret. Legal rights of Honeywell Inc. in this
 software is distinct from ownership of any medium in which the
 software is embodied. Copyright or trade secret notices included
 must be reproduced in any copies authorized by Honeywell Inc.
 The information in this software is subject to change without
 notice and should not be considered as a commitment by Honeywell
 Inc.
 ******************************************************************************************/
#if !defined(AFX_CMMUTILITY_H__B62C0518_AD2C_4893_8B65_2D86B5E0A29E__INCLUDED_)
#define AFX_CMMUTILITY_H__B62C0518_AD2C_4893_8B65_2D86B5E0A29E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "CMMDefines.h"
#include "PMMglobal.h"
#include "Macro.h"
#include "Constants.h"
#include "TraceDefines.h"

typedef struct {
	value Lowlmt;
	value Hilmt;
	value vdefault;
	WORD wclass;
	WORD wDatatype;
	WORD wnumSubInst;
	WORD wnumInst;
	WORD Fieldname;
} IDENTIFIER_RECORD_INFO;
//******************************************************
// CCMMUtility
///
/// @brief Provides utility functions.
/// 
/// Provides functions commonly used by Request Handler,
///	Memory Manager and Version Converter.
//******************************************************
class CCMMUtility {
public:
	CCMMUtility();
	~CCMMUtility();

	CMMSTATUS BuildMetadataLookUp(BYTE *pvarMetadata, DWORD varConfigurationID, WORD *varVersion = NULL);

	CMMSTATUS UpdateConfigurationFileHeader(DWORD dwConfigurationId, WORD wOperation, DWORD dwAction,
			WORD *pwMetadataSize = NULL);

	CMMSTATUS UpdateConfigRecordStatistics(CONFIGLOG_INFO *pConfigInfo, WORD wOperation, DWORD dwAction);

	CMMSTATUS CreateDataBlock(DWORD dwConfigurationID, BLOCK_INFO *pBlockDetails);

	CMMSTATUS GetDataBlockAndInstanceInfoFromDataBlock(BYTE *pbyDataBlock, BLOCK_INFO *pBlockDetails);

	CMMSTATUS ValidateIntrinsicAndArrayDataType(IDENTIFIER_RECORD_INFO varIdentifierDetails, BYTE *pbyData,
			WORD *pwSize, WORD *pwStart = NULL, WORD wCopySize = 0, BOOL bUseAllInstances = TRUE);

	CMMSTATUS DefaultIntrinsicAndArrayDataType(IDENTIFIER_RECORD_INFO *varIdentifierDetails, BYTE *pbyData,
			WORD wInstanceId, WORD *pwSize, WORD *pwStart = NULL);

	CMMSTATUS DefaultDataBlock(DWORD dwConfigurationId, WORD wBlockType, BYTE *pbyData, WORD wInstanceId);

	WORD ComputeIdentifierSize(IDENTIFIER_RECORD_INFO *pIdentifierInfo, COMPUTE_INCLUDE nInclude = INCLUDE_ALL);

	void LoadTracerModule();

	void UnLoadTracerModule();

	CMMSTATUS ValidateBitFields(IDENTIFIER_RECORD_INFO *pIdentfierRecord, BYTE *pSrcPtr, WORD dwPosition,
			WORD wInstanceCount, WORD *wShiftPosition);
};

#endif // !defined(AFX_CMMUTILITY_H__B62C0518_AD2C_4893_8B65_2D86B5E0A29E__INCLUDED_)

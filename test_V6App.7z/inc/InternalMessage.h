#ifndef _INTERNALMESSAGE_H
#define _INTERNALMESSAGE_H

#include "Defines.h"
/// Message Types for message to be sent and received
typedef enum {
	IMQ_DATA, IMQ_COMMAND, IMQ_SHUTDOWN
} T_IMQ_MESSAGE_TYPE;

//**Class*********************************************************************
///
/// @brief An Internal Message Structure  
/// 
/// A Message Structure, thats contains the message header, and the first
/// byte of the message. This then allows the rest of the message to be
/// obtained through using the data length, as the location of the message
/// data is known. Will be used to cast the data in the heap buffer to 
/// represent a message.  
///
/// @note This has been declared as a structure to save the number of bytes
///  allocated for a message within the heap buffer. If a class was 
///  used then unnecessary bytes would be allocated. 
//****************************************************************************
typedef struct {
	T_IMQ_MESSAGE_TYPE m_MessageType;	///< Type of message.
	USHORT m_MsgLength;					///< Length of the Message including data
	USHORT m_DataLength;				///< Data Length of the message.
	BYTE m_MsgData[1];					///< Location of first byte of the message.

} CInternalMessage;

#endif // _INTERNALMESSAGE_H

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 UI Control
/// @n Filename:  V6MessageBoxDlg.h
/// @n Description: Definition of the CV6MessageBoxDlg class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  7   Stability Project 1.4.1.1   7/2/2011 5:02:43 PM   Hemant(HAIL) 
//     Stability Project: Recorder source has been upgraded from IL
//    version of firmware to JF version of firmware.
//  6   Stability Project 1.4.1.0   7/1/2011 4:27:41 PM   Hemant(HAIL) 
//     Stability Project: Files has been checked in before the merging
//    task. The merging will be done between IL version of firmware and JF
//    version of firmware. 
//  5   V6 Firmware 1.4     8/28/2007 9:03:36 PM  Roger Dawson  
//    Modified the code so it checks for a master but updates the password
//    on the slave regardless. Also added extra dialogs which will
//    hopefully make it clearer to the user what is happening as some of
//    the password netsync task can be very time consuming and trick the
//    user into thinking the recorder has crashed.
//  4   V6 Firmware 1.3     11/17/2006 6:04:42 PM  Roger Dawson  
//    Added code to resize the dialog should the displayed messaged be too
//    large for the standard size of the dialog.
// $
//
// **************************************************************************

#if !defined(AFX_V6MESSAGEBOXDLG_H__68F149B9_D5FD_4461_8DBE_E736D544D7B9__INCLUDED_)
#define AFX_V6MESSAGEBOXDLG_H__68F149B9_D5FD_4461_8DBE_E736D544D7B9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// V6MessageBoxDlg.h : header file
//

#include "v6bitmapbutton.h"
#include "baseeditdlg.h"
#include "Widget.h"

//**CV6MessageBoxDlg***********************************************************
///
/// @brief V6 Message Box Dialog - modal dialog that is consistent with the V6 theme
/// 
/// V6 Message Box Dialog - modal dialog that is consistent with the V6 theme
///
//****************************************************************************
class CV6MessageBoxDlg: public CBaseEditDlg {
// Construction
public:
	// Constructor
	CV6MessageBoxDlg(const QString   &rstrTITLE, const QString   &rstrMSG, CWidget *pParent = NULL,
			const QString   strOK_BTN_TEXT = QString  ::fromWCharArray(L""));

	CV6MessageBoxDlg(const QString   &rstrTITLE, const QString   &rstrMSG, const QString   &rstrOK_BTN_TEXT,
			const QString   &rstrCANCEL_BTN_TEXT, CWidget *pParent /* =NULL */);

	// Destructor
	~CV6MessageBoxDlg();

	// Method that disables the OK button
	void DisableOKBtn() {
		if (m_pkOKBtn != NULL) {
			m_pkOKBtn->EnableWindow( FALSE);
		}
	}
	void ShowOkBtn(bool bShowOrHide = true) {
		m_bShowOKbtn = bShowOrHide;
	}

// Dialog Data
	//{{AFX_DATA(CV6MessageBoxDlg)
	enum {
		IDD = IDD_V6_MESSAGE_BOX_DLG
	};
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CV6MessageBoxDlg)
protected:
	virtual void DoDataExchange(CDataItem *pDX);  // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CV6MessageBoxDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	//}}AFX_MSG
DECLARE_MESSAGE_MAP()
private:

	/// Variable used to store the message title
	const QString   m_strMESSAGE_TITLE;

	/// Variable used to store the message
	QString   m_strMessage;

	// Method that updates the config data
	void OnOK();

	bool m_bShowOKbtn;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_V6MESSAGEBOXDLG_H__68F149B9_D5FD_4461_8DBE_E736D544D7B9__INCLUDED_)

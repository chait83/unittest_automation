/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Media Manager
/// @n Filename:	StoragePaths.h
/// @n Description: Provides a storage path abstraction layer
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 20-10-14	Rajanbabu M			Fixed PAR:1-3I2GTSM - WSD communication is not working on upgrading the firmware
// 21	Stability Project 1.18.1.1	7/2/2011 5:01:57 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 20	Stability Project 1.18.1.0	7/1/2011 4:27:02 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 19	V6 Firmware 1.18		3/5/2007 3:09:45 PM	Roger Dawson 
//		CustomWavs directory created. All custom files will get dumped in
//		this directory and will be used in preference to the default wav
//		file(s). Also added the ability to delete custom wav files by
//		allowing the user to upload a wav file call SXX-Default.wav which
//		results in the custom file being delted but not replaced (e.g.
//		S1-Default.wav will delete any existing custom wav file called
//		S1-XXX.wav).
// 18	V6 Firmware 1.17		2/6/2007 7:50:49 PM	Graham Waterfield
//		Added reports to storage locations
// $
//
// **************************************************************************

// StoragePaths.h: interface for the CStoragePaths class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(__STORAGEPATHS_H__)
#define __STORAGEPATHS_H__

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include <QMutex>
#include "Defines.h"

typedef enum T_STORAGE_DEVICE {
	IDS_INTERNAL_SD = 0,			///< Internal compact flash
	IDS_EXTERNAL_SD,				///< External compact flash
	IDS_FIRST_USB,					///< First USB storage device inserted
	IDS_SECOND_USB,					///< Second USB storage device inserted
	IDS_ANY_DEVICE,				///< only used for transaction status searching
	IDS_FLASH,						///< only used for flash transaction status
	IDS_SHARE,						///< Network Share			
	IDS_FTP,						///< FTP directory area
	IDS_MAX_DEVICES					///< Max number of devices ** Always on end
} STORAGE_DEVICE;

typedef enum T_STORAGE_PATH {
//	IDS_INTERNAL_SD = 0,
//	IDS_EXTERNAL_SD,
//	IDS_FIRST_USB,
//	IDS_SECOND_USB,
//	IDS_ANY_DEVICE,
//	IDS_FLASH,
//	IDS_SHARE,
//	IDS_FTP,
	IDS_FIRMWARE = 8,
	IDS_LOG_DATA,
	IDS_OEM_DATA,
	IDS_CONFIG_DATA,
	IDS_LAYOUT_DATA,
	IDS_SCRIPT_DATA,
	IDS_UPGRADE,
	IDS_PLATFORM,
	IDS_EXT_CONFIG,
	IDS_SW_UPDATE,
	IDS_EXTRACT_DATA,
	IDS_AUTORUN,
	IDS_SCRIPT_MASK,
	IDS_LAYOUT_MASK,
	IDS_CONFIG_MASK,
	IDS_VOLUME,
	IDS_RAWVOLUME,
	IDS_ROOT,
	IDS_METADATA,
	IDS_PRIMARY,
	IDS_SECONDARY,
	IDS_APPEXE,
	IDS_FTP_BUFFER,
	IDS_NETWORK,					// Network file shares (base folder)
	IDS_FILE_SHARE,
	IDS_LCF_FILE,					// LCF File name
	IDS_HELP,
	IDS_AUTO_OPS,
	IDS_FTP_ROOT,
	IDS_FTP_UPLOAD,
	IDS_FTP_UPLOAD_CFG,
	IDS_FTP_DOWNLOAD,
	IDS_FTP_DOWNLOAD_CFG,
	IDS_FTP_DOWNLOAD_DATA,
	IDS_WAVS,
	IDS_CUSTOM_WAVS,
	IDS_REPORTS,
	IDS_CERTIFICATES,
	IDS_CERTIFICATESCA,
	IDS_EMAILCERTIFICATES
} STORAGE_PATH;

//**Class*********************************************************************
///
/// @brief ---Single line description---.
/// 
/// --- Detailed Description ---
///
//****************************************************************************

class CStoragePaths {
	friend class CDeviceAbstraction;

private:
	WCHAR* GetPath(T_STORAGE_DEVICE pathID, QString  pbuffer, int pbufferSize, int *pLength);
	BOOL BuildPath(T_STORAGE_DEVICE device, T_STORAGE_PATH path, const QString  const file, QString  buffer, USHORT size);
	static CStoragePaths* GetHandle();
	virtual ~CStoragePaths();
	void Cleanup();
	void Initialise();
	class CDeviceAbstraction *mpDAL;		///< Device abstraction layer class

protected:
	CStoragePaths();
	CStoragePaths(const CStoragePaths&);
	CStoragePaths& operator=(const CStoragePaths&);

private:
	static CStoragePaths *m_pInstance;		///< Single instance object pointer
	static QMutex hCreationMutex;					///< Object creation mutex
};

#endif // !defined(__STORAGEPATHS_H__)

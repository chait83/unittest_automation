/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Recorder Debug Logs
/// @n Filename: V7DbgLogDefines.h
/// @n Desc:	 All Dbg log definitions for V7 recorder
///				 
///
// ****************************************************************
// Revision History
// ****************************************************************
// 21-10-19 Shankar Rao Pendyala  Initial Debug Log Definitions
// $
//
// ****************************************************************

#ifndef __V7_DBG_LOG_DEFINES_H__
#define __V7_DBG_LOG_DEFINES_H__

///===============================================================================
/// DEBUG LOG DEfinitions
///===============================================================================
#ifdef UNDER_V6APP
#define DUMP_EXPORT_ENABLE					1
#define DBG_LOG_EXPORT_ENABLE				1

//#define DBL_AUTO_OPS_THREAD_HB	1
//#define DBL_STORAGE_CS_THREAD	1
//#define DBL_STORAGE_NO_CS_LOCK 1
//#define THREAD_ID_SERIAL_LOG				1

//#define STARTUP_LOGGING	1

//#define RDL_PAM_ENABLE						1	//Password Auth Mgr
//#define RDL_PIM_ENABLE						1	//Password Interface Mgr

//Todo: Make these settings project specific
#ifdef TV_ENABLE_LOG
//IO error Log Define
#define DBG_FILE_LOG_IO_ERR_ENABLE			1

//TLS Logs
#define DBG_FILE_LOG_SSL_DBG_ENABLE			1
#define DBG_FILE_LOG_TLS_CLNT_ENABLE		1
#define DBG_FILE_LOG_TLS_SERV_ENABLE		1
#define DBG_FILE_LOG_TLS_CERT_ENABLE		1

//PNS Dbg logs
#define DBG_FILE_LOG_NETSYNC_ENABLE			1
#define DBG_FILE_LOG_NETSYNC_X_ENABLE		1
#define DBG_FILE_LOG_STCPS_ENABLE			1
#define DBG_FILE_LOG_SPNS_ENABLE			1

//HT Data Server (WSD ALternate) log defines
#define DBG_FILE_LOG_HTD_DBG_ENABLE			1
#define DBG_FILE_LOG_FTS_DBG_ENABLE			1


//Active Module Debug Enable
#define RDL_V6AM_DBG_ENABLE					1
//Auto Ops
#define RDL_AUTO_OPS_DBG_ENABLE				1
//TX Scheduler
#define DBG_FILE_LOG_TXSCH_DBG_ENABLE		1

#define	DBG_FILE_LOG_MSG_DBG_ENABLE			1

#endif //TV_ENABLE_LOG

#endif //UNDER_V6APP

///////********************/////////////////

//Debug log settings for HtData Server 
#if defined(HTDT_SERVER) || defined (HTDATA_SERVER)
//TLS Logs
//#define DBG_FILE_LOG_SSL_DBG_ENABLE			1
//#define DBG_FILE_LOG_TLS_CLNT_ENABLE		1
//#define DBG_FILE_LOG_TLS_SERV_ENABLE		1
//#define DBG_FILE_LOG_TLS_CERT_ENABLE		1
////HT Data Server (WSD ALternate) log defines
//#define DBG_FILE_LOG_HTD_DBG_ENABLE			1
//#define DBG_FILE_LOG_FTS_DBG_ENABLE			1

#endif //HTDT_SERVER

///////********************/////////////////

///////********************/////////////////
#ifdef REMOTE_DISPLAY_SERVER
//#define DBG_FILE_LOG_SSL_DBG_ENABLE			1
//#define DBG_FILE_LOG_TLS_CLNT_ENABLE		1
//#define DBG_FILE_LOG_TLS_SERV_ENABLE		1
#endif //End of REMOTE_DISPLAY_SERVER

///////********************/////////////////

#ifdef IS_TMP_APP 
//TLS Logs
//#define DBG_FILE_LOG_SSL_DBG_ENABLE			1
//#define DBG_FILE_LOG_TLS_CLNT_ENABLE		1
//#define DBG_FILE_LOG_TLS_SERV_ENABLE		1
//#define DBG_FILE_LOG_TLS_CERT_ENABLE		1
////HT Data Server (WSD ALternate) log defines
//#define DBG_FILE_LOG_HTD_DBG_ENABLE			1
//#define DBG_FILE_LOG_FTS_DBG_ENABLE			1
#endif //End of IS_TMP_APP

///////********************/////////////////
#endif // __V7_DBG_LOG_DEFINES_H__


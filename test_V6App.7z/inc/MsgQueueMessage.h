/// @file 
/// *****************************************************************
/// © Honeywell Trendview
/// *****************************************************************
/// @n Module : Module Message Manager (MMM )
/// @n FileName: MsgQueueMessage.h
/// @n Desc	: Structure Declaration for the CMsgQueueMessage
///			
/// *****************************************************************
/// @b Revision @b History
/// *****************************************************************
/// $Log[4]:
/// 6	Stability Project 1.3.1.1	7/2/2011 4:58:53 PM	Hemant(HAIL) 
///		Stability Project: Recorder source has been upgraded from IL
///	version of firmware to JF version of firmware.
/// 5	Stability Project 1.3.1.0	7/1/2011 4:26:59 PM	Hemant(HAIL) 
///		Stability Project: Files has been checked in before the merging
///	task. The merging will be done between IL version of firmware and JF
///	version of firmware. 
/// 4	V6 Firmware 1.3		12/22/2004 4:11:04 PM Alistair Brugsch
///	changed BYTE[1] to DWORD[1] to solve datatype misalignment exception
///	produced on the MIPS
/// 3	V6 Firmware 1.2		9/8/2004 5:28:52 PM	Alistair Brugsch
///	Changed T_MODULE_MESSAGE_ID to USHORT, as the messages to be used
///	have been taken out of an enum and declared as constants for
///	clarification and usability.
/// $
///
#ifndef _MSGQUEUEMESSAGE_H
#define _MSGQUEUEMESSAGE_H

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ModuleConstants.h"

//**Class*********************************************************************
///
/// @brief A Message Structure 
///	
/// A Message Structure, thats contains the message header, and the first
/// byte of the message. This then allows the rest of the message to be
/// obtained through using the data length, as the location of the message
/// data is known. Will be used to cast the data in the heap buffer to 
/// represent a message. 
///
/// @note This has been declared as a structure to save the number of bytes
///	allocated for a message within the heap buffer. If a class was 
///	used then unnecessary bytes would be allocated. 
//****************************************************************************

typedef struct {
	ULONG m_IpAddress; ///< IP Address for the destination, 127.0.0.1 for internal messages.
	T_MODULE_ID m_DestinationModule;	///< Destination Module of the message.
	T_MODULE_ID m_SendingModule;		///< Module sending the message.
	T_MODULE_MSG_COMPLETION m_WaitForMsgCompletion; ///< Signal sending message once destination processes the message
	USHORT m_MsgSize;				///< Length of the Message including data
	USHORT m_DataLength;						///< Data Length of the message.
	USHORT m_MessageType;			///< Type of message.
	DWORD m_MsgData[1];				///< Location of first byte of the message.

} CMsgQueueMessage;

#endif // _MSGQUEUEMESSAGE_H

/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 Configuration
/// @n SetupConfiguration.h
/// @n interface of the CSetupConfiguration class.
/// @author GKW
/// @date 29/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 31	Stability Project 1.28.1.1	7/2/2011 5:01:17 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 30	Stability Project 1.28.1.0	7/1/2011 4:27:02 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 29	V6 Firmware 1.28		8/9/2006 1:44:38 PM	Jason Parker 
//		persist flag passed to load and save configs
// 28	V6 Firmware 1.27		5/4/2006 5:23:41 PM	Andy Kassell	On
//		de-persist only modify change header if config has changed
// $
//
//////////////////////////////////////////////////////////////////////
#ifndef _SETUPCONFIGURATION_H
#define _SETUPCONFIGURATION_H
#include <QFile>
#include "V6defines.h"
#include "CMMDefines.h"
#include "Configuration.h"
#include "V6Config.h"

// Service Class Include Files
#include "GeneralSetupConfig.h"
#include "PenSetupConfig.h"
#include "IOSetupConfig.h"
#include "CommsSetupConfig.h"
#include "EventSetupConfig.h"

#include "CStorage.h"

/// 
const USHORT SETUPCONFIG_ZERO = 0; ///< Constant to represent the value of Zero

/// Enumeration for the Type of Setup Configuration Services Classes Available
typedef enum {
	SETUPCONFIG_GENERAL_SERVICE,
	SETUPCONFIG_PEN_SERVICE,
	SETUPCONFIG_IO_SERVICE,
	SETUPCONFIG_COMMS_SERVICE,
	SETUPCONFIG_EVENT_SERVICE,

	SETUPCONFIG_NUM_OF_SERVICES

} T_SETUPCONFIG_SERVICES;

#define ONLY_ONE_INST	0
#define PERSIST_CONFIG L"DefaultSetupConfig.cfg"

//**Class*********************************************************************
///
/// @brief Setup Configuration Class
/// 
/// This Class Creates a Default Setup Configuration within the CMM and provides
/// functionality to Validate the Setup Configuration together with General 
/// functions for dealing with the CMM. 
///
//****************************************************************************
class CSetupConfiguration: public CConfiguration {
public:

	/// Constructor
	CSetupConfiguration(void);

	/// Destructor
	virtual ~CSetupConfiguration(void);

	/// Create a Deafult Configuration 
	virtual T_CONFIG_RETURN_VALUE CreateDefaultConfig(void);

	/// Validate a Configuration 
	virtual T_CONFIG_VALIDATE_RETURN ValidateConfiguration(void);

	/// Override Base Class Member Function
	T_CONFIG_RETURN_VALUE CreateCMMConfiguration(void);

	/// Obtain a Pointer to the General Setup Configuration 
	CGeneralSetupConfig* GetGeneralSetupConfig(void) const;

	/// Obtain a Pointer to the Pen Setup Configuration
	CPenSetupConfig* GetPenSetupConfig(void) const;

	/// Obtain a Pointer to the Input / Output Setup Configuration
	CIOSetupConfig* GetIOSetupConfig(void) const;

	/// Obtain a Pointer to the Communications Setup Configuration
	CCommsSetupConfig* GetCommsSetupConfig(void) const;

	/// Obtain a Pointer to the Event Setup Configuration
	CEventSetupConfig* GetEventSetupConfig(void) const;

	///
	virtual T_CONFIG_RETURN_VALUE LoadConfig(QFile &fileToLoadConfig, const TV_BOOL persistedLoad = FALSE);
	virtual T_CONFIG_RETURN_VALUE SaveConfig(QFile &fileToSaveConfig, const TV_BOOL persistedSave = FALSE);

	///												
	virtual T_CONFIG_RETURN_VALUE UpdateConfig(void);

	virtual void SetConfigurationId(const DWORD configurationId);

	void RequestUnitResetAfterConfigChange(const QString   reason);
	BOOL IsResetRequired() {
		return resetRequiredAfterCommit;
	}
	;
	void ClearResetRequired() {
		resetRequiredAfterCommit = FALSE;
	}
	;

	BOOL InDepersistMode() {
		return depersistMode;
	}
	;
	void ClearDepersistMode() {
		depersistMode = FALSE;
	}
	;

private:

	/// An Array of Setup Configuration Service Classes, to split the configuration into
	/// smaller managable sections. 
	CSetupConfigService *m_pSetupConfigService[SETUPCONFIG_NUM_OF_SERVICES];

	BOOL resetRequiredAfterCommit;	///< Indicates a reset is required after a commit

	BOOL depersistMode;	///< Indicates if a variable is in depersist Load config mode

};
// End of Class Declaration

/// @todo Review const correctness
inline CGeneralSetupConfig* CSetupConfiguration::GetGeneralSetupConfig(void) const {
	return (static_cast<CGeneralSetupConfig*>(m_pSetupConfigService[SETUPCONFIG_GENERAL_SERVICE]));

} // End of Member Function

/// @todo Review const correctness
inline CPenSetupConfig* CSetupConfiguration::GetPenSetupConfig(void) const {
	return (static_cast<CPenSetupConfig*>(m_pSetupConfigService[SETUPCONFIG_PEN_SERVICE]));

} // End of Member Function

/// @todo Review const correctness
inline CIOSetupConfig* CSetupConfiguration::GetIOSetupConfig(void) const {
	return (static_cast<CIOSetupConfig*>(m_pSetupConfigService[SETUPCONFIG_IO_SERVICE]));

} // End of Member Function

/// @todo Review const correctness
inline CCommsSetupConfig* CSetupConfiguration::GetCommsSetupConfig(void) const {
	return (static_cast<CCommsSetupConfig*>(m_pSetupConfigService[SETUPCONFIG_COMMS_SERVICE]));

} // End of Member Function

/// @todo Review const correctness
inline CEventSetupConfig* CSetupConfiguration::GetEventSetupConfig(void) const {
	return (static_cast<CEventSetupConfig*>(m_pSetupConfigService[SETUPCONFIG_EVENT_SERVICE]));

} // End of Member Function

#endif // _SETUPCONFIGURATION_H

/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	System Absraction layer
/// @n Filename: hw_defs.h
/// @n Desc:	defines for hardware specific access
///
// 
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 24	Stability Project 1.21.1.1	7/2/2011 4:57:56 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 23	Stability Project 1.21.1.0	7/1/2011 4:26:56 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 22	V6 Firmware 1.21		8/3/2006 8:11:35 PM	Graham Waterfield
//		Add ez comms and expansion board detect
// 21	V6 Firmware 1.20		7/31/2006 8:35:02 PM	Graham Waterfield
//		Allow digital/alarm board to operate on an eZ
// $
//
// ****************************************************************

#ifndef __HW_DEFS_H__
#define __HW_DEFS_H__
#include "Defines.h"
#define VALIDATION_SIG			0x1A2B3C4D			///< Validation signature, indicates struct/mem has been used

// Device Types
typedef enum {
	DEV_XS_MINITREND = 0,			///< Minitrend, 5.5" TFT with 16 Channels
	DEV_XS_MULTIPLUS,			///< MultiTrend Plus, 12.1" TFT with 48 Channels
	DEV_XS_EZTREND,				///< XSeries QXe Device Type updates duplicate

	DEV_ARISTOS_MINITREND,			///< Minitrend, 5.5" TFT with 16 Channels
	DEV_ARISTOS_MULTIPLUS,		///< MultiTrend Plus, 12.1" TFT with 48 Channels
	DEV_ARISTOS_EZTREND,					///< ARISTOS QXe Device Type updates

	DEV_PC_MINI,				///< PC BuildS of system for runtime checking
	DEV_PC_MULTI,
	DEV_PC_EZTREND,
	DEV_PC_SCREEN_DESIGNER,	///< Screen designer build - requires us to test the 
	DEV_PC_TTR6SETUP,

	///< layout configuration to determine the screen type
	DEV_TEST,										///< Test equipment	
	DEV_SCR_MINITREND,	//DRG2 12.1".The value of this enum is 12.Once reaches count 99, Please add new enum at the end.
	DEV_UNKNOWN = 99									///< Unknown device	
} T_DEV_TYPE;

// USB
#define USB_FRONT_HOST			0					///< Front USB set to Host connector
#define USB_FRONT_DEVICE		1					///< Front USB set to Device connector

// LED state
#define TURN_LED_ON				TRUE				///< Turn CF LED on
#define TURN_LED_OFF			FALSE				///< Turn CF LED off

// V6 Board revisions
#define PROCBRD_REV_1			1					///< First 5 built by IEL, Compact flash inverted, USB not working correctly, REV A silicon
#define PROCBRD_REV_2			2					///< Rev B from IEL, approx 25 Built, 256KSRAM and no AP8 SPI processor
#define PROCBRD_REV_3			3					///< 512K SRAM and AP8 SPI processor

// Boot flash programming defines
#define BF_STARTBLOCK			0					///< First available block in boot flash
#define BF_ENDBLOCK				31					///< Last available block in boot flash
#define BF_MAXSIZE				65536				///< Maximum block size in bytes

#define BF_READ					0					///< Read from flash block
#define BF_WRITE				1					///< Write to flash block

//#define BF_BLK_TEST				0					///< Block number available for testing
//#define BF_BLK_PASSWORDS		12					///< Password data
//#define BF_BLK_SPLASH_LO		13					///< Low 64K of 128K splash screen bitmap
//#define BF_BLK_SPALSH_HI		14					///< High 64K of 128K splash screen bitmap
//#define BF_BLK_IELPARAM			15					///< IEL paramerter Block

//#define BF_BLK_TEST				16					///< Block number available for testing
//#define BF_BLK_PASSWORDS		26					///< Password data
//#define BF_BLK_SPLASH_LO		13					///< Low 64K of 128K splash screen bitmap
//#define BF_BLK_SPALSH_HI		14					///< High 64K of 128K splash screen bitmap
#define BF_BLK_IELPARAM			31					///< IEL paramerter Block

#define BF_BLK_BACKUP			99					///< Backup block, always created when saving something to flash
#define BF_BLK_SRAM				55					///< Simulated SRAM block filename
#define BF_BLK_SRAM_BACKUP		66					///< BAckup of SRAM, used as snapshot of last session for debugging
#define BF_BLK_SRAM_FILE_Q_BACKUP		88			///< BAckup of SRAM, used to restore file queue headers when integrity fails
#define BF_BLK_SRAM_BKP_ON_BAT_RESET	166			///< BAckup of SRAM, used to restore the entire SRAM during Battery Reset

// Screen Types
#define SCRN_5_5				0					///< 5.5" NEC display
#define SCRN_12_1				1					///< 12.1" NEC display
#define SCRN_5_7				2					///< 5.7" PowerView display (EzTrend)
#define SCRN_UNKNOWN			0xF					///< Unknown screen type

// Screen backlight setting for application, 10% to 100% brightness
#define SCRN_BRIGHTEST_PC		100
#define SCRN_DIMMEST_PC			10
#define SCRN_BRIGHTNESS_RANGE	(SCRN_BRIGHTEST_PC-SCRN_DIMMEST_PC)
#define SCRN_BACKLIGHT_OFF		200					///< Use Rogue value for backlight off
#define SCREEN_BRIGHT_FAIL		-1					///< Set or get brightness failed.
#define SCRN_DEFAULT_PC			75					///< Default back-light level

// SPI defines
#define SPI_BAUD_RATE_HZ		1000000				///< SPI baud rate in Hz
#define SPI_INTERCHAR_TIMEOUT	10000				///< Inter character delay timout in uSec
#define SPI_DEVICE_CARD1		0					///< IO Card 1 
#define SPI_DEVICE_CARD2		1					///< IO Card 2 
#define SPI_DEVICE_CARD3		2					///< IO Card 3 
#define SPI_DEVICE_CARD4		3					///< IO Card 4 
#define SPI_DEVICE_CARD5		4					///< IO Card 5 
#define SPI_DEVICE_CARD6		5					///< IO Card 6 
#define SPI_DEVICE_CARD7		6					///< IO Card 7 
#define SPI_DEVICE_CARD8		7					///< IO Card 8 
#define SPI_DEVICE_CARD9		8					///< IO Card 9 
#define SPI_DEVICE_AP8_INFO		9					///< AP8 Information select
#define SPI_DEVICE_AP8_RESET	0x0A				///< AP8 Reset Select
#define SPI_DEVICE_AP8_ERASE	0x0B				///< AP8 Program Erase Select

#define SPI_DEVICE_RTC			0x0F					///< RTC

// Card slot defines with relation to back panel lettering
// Top 6 slots (analogue in/out Pulse Cards) or if using T_SLOT_POSITION will be SLOT_TOP
const USHORT RECORDER_SLOT_A = 0;
const USHORT RECORDER_SLOT_B = 1;
const USHORT RECORDER_SLOT_C = 2;
const USHORT RECORDER_SLOT_D = 3;
const USHORT RECORDER_SLOT_E = 4;
const USHORT RECORDER_SLOT_F = 5;

// Bottom 3 slots (digital) if using T_SLOT_POSITION will be SLOT_BOTTOM
const USHORT RECORDER_SLOT_G = 6;
const USHORT RECORDER_SLOT_H = 7;
const USHORT RECORDER_SLOT_I = 8;

const USHORT SLOT_CHANNEL_0 = 0;

// General slot positions available
typedef enum {
	SLOT_TOP,				///< Top slot for AI/AO and Pulse channels
	SLOT_BOTTOM,			///< Bottom slot for digitals, inc pulse
	SLOT_UNKNOWN			///< Unknown slot 
} T_SLOT_POSITION;

// AP8 SPI comms processor 
#define AP8_STATS_LEN			28			///< Length of AP8 processor stats, must match or exceed AP8_INFO_MAXLEN in drvhand.h in platform
#define AP8_SIG_LO				0xCD		///< Signature low byte value for value AP8
#define AP8_SIG_HI				0xAB		///< Signature high byte value for value AP8

#define AP8_STATS_SIG_LO		00			///< Signature word low byte 
#define AP8_STATS_SIG_HI		01			///< Signature word high byte 
#define AP8_STATS_VER_LO		02			///< Version number low byte
#define AP8_STATS_VER_HI		03			///< Version Number high byte

#define MAC_ADDRESS_LEN			6			///< Octets in mac address

// ****** MACROS *****

// Get Ethernet PHY status macros
#define PHYSTAT_10MEG(a)		((a&0x01))			///< 10 Meg link
#define PHYSTAT_FULLDUPLEX(a)	((a&0x02)>>1)		///< Full Duplex Link
#define PHYSTAT_ACIVITY(a)		((a&0x04)>>2)		///< Link Activity
#define PHYSTAT_100MEG(a)		((a&0x08)>>3)		///< 100 Meg link
#define PHYSTAT_TRANSMIT(a)		((a&0x10)>>4)		///< Transmit active
#define PHYSTAT_RECEIVE(a)		((a&0x20)>>5)		///< Receive active

// Get System revision from CPLD register 0x00
#define SYSREV_PCB(a)			((a&0xF000)>>12)	///< PCB Revision of CPU board(0=Rev A. 1=Rev B etc..) Bits 12-15
#define SYSREV_MHZ(a)			((a&0x0800)>>11)	///< Processor Speed Setting
#define SYSREV_BUILD(a)			((a&0x0700)>>8)		///< Build Revision of CPU card Bits 8-10
#define SYSREV_CPLD(a)			((a&0x00F0)>>4)		///< CPLD Firmware revision bits 4-7
#define SYSREV_JP5(a)			(a&0x000F)			///< Jumper JP5 Fitted? 0=Absent, 1=Fitted

// Get Screen type from CPLD register 0x10
#define SCRN_DISP0(a)			((a&0x2000)>>13)	///< DISP 0 line, bit 13, 0 = 5.5" display		
#define SCRN_DISP1(a)			((a&0x4000)>>14)	///< DISP 1 line, bit 14, 0 = 12.1" display 	

// Digital Input cards have data available, status line bits
#define DIG_IN_READY(a)			((a&0x0007)/*>>9*/)		///< Return INT0,INT1 and INT2 as bottom 3 bits, these give status of Digital Cards data pending
#define EZ_DIG_IN_READY(a)		((a&0x0002)<<1)			///< INT1 (bit 1) is the digital IO slot - it needs to be mapped to bit 3 though to mimic slot
///< slot G on a mini or a multi
// Old XSeries data ready macros
//#define DIG_IN_READY(a)			((a&0x0E00)>>9)		///< Return INT0,INT1 and INT2 as bottom 3 bits, these give status of Digital Cards data pending
//#define EZ_DIG_IN_READY(a)		((a&0x0030)>>5)		///< Return eZ INT1 as INT0 only as bottom bit

// Power relay Hardware definitions
// PSR Fix for - 1-3E7Y0UX - SX/QX_"Common alarm" output configuration is missing from soft (pens) alarm begin
//GR Series having API calls with return codes for Open and Close.. so no bitmasking is needed here
#define FIXED_RELAY_OPEN	0
#define FIXED_RELAY_CLOSE 1
// PSR Fix for - 1-3E7Y0UX - SX/QX_"Common alarm" output configuration is missing from soft (pens) alarm end

// EZ Hardware detect definitions
#define MOTHERBD_FITTED(a)		((a&0x0040)>>6)		///< Bit 6 is the Mother board detect line
#define COMMSBD_FITTED(a)		((a&0x0080)>>7)		///< Bit 7 is the comms board detect line

/// Storage identifier list
enum storageDeviceIdent {
	SD_INTERNAL_SD,					///< Internal compact flash card
	SD_EXTERNAL_SD,					///< External compact flash card
	SD_USB1,						///< USB pendrive 1
	SD_USB2,						///< USB pendrive 2
	NV,								///< Non-volatile memory simulator
	ROOT							///< Root directory of the recorder
};

#define MAX_SD_VOLUME_LEN		50	///< Maximum storage device volume length.

#endif // __HW_DEFS_H__

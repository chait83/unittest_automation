/// @file 
/// ****************************************************************
///  Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Processing
/// @n Filename: totals.h
/// @n Desc:	 Manage all aspects of totals within the system
///				 
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  19  Stability Project 1.16.1.1 7/2/2011 5:02:09 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  18  Stability Project 1.16.1.0 7/1/2011 4:27:28 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  17  V6 Firmware 1.16 5/19/2010 4:14:42 PM  Nilesh(HAIL)  
//  Totalizer Single Precision Issue
//  16  V6 Firmware 1.15 9/29/2008 1:25:39 PM  Vivek (HAIL)  Fix
//  given for: Reset and start event effect not responsive after adding
//  rollover event to totaliser.
// $
//
// ****************************************************************

#ifndef __TOTALS_H__
#define __TOTALS_H__

#include "V6defines.h"
#include "V6globals.h"
#include "V6Config.h"
#include "reportData.h"

// FLT_MAX
#include <float.h>

const float LARGEST_POS_TOTAL_NUMBER = 1e+38F;	// use a value close to actual maximum
const float LARGEST_NEG_TOTAL_NUMBER = -1e+38F;	// negative, not small value

const float LARGEST_FLOAT_PRECISION_NUMBER = 16777215;	// negative, not small value

/// Return types for totalser methods
typedef enum {
	RET_TOTAL_OKAY = 0,						///< Function completed okay
	RET_TOTAL_INIT_FAILED,					///< Alarm initialisation failed
	RET_TOTAL_CFG_FAILED					///< Alarm configuration failed

} T_TOTALS_RETURN;

/// Totaliser modes and actions
typedef enum {
	TOTAL_MODE_UNCHANGED = 0,					///< Mode unchanged from last itteration (when being used as action)
	TOTAL_MODE_RUN,							///< Run totals
	TOTAL_MODE_PAUSE,						///< Pause total (do not accumulate)
	TOTAL_MODE_RESET,						///< Reset total, to 0 
	TOTAL_MODE_ROLLOVER,					///< Roll0ver Totaliser
	TOTAL_MODE_RESET_START = TOTAL_MODE_ROLLOVER,	///< Reset and starts a totaliser in a single action
	//vivek:
	//{ 
	// Fix: Reset and start event effect not responsive after adding rollover event to totaliser. 
	// Set enum value of RESET_START to 4 because its stored in configuration with value 4
	// as same enum is used for cause/effect totaliser event.
	// Suggested by Graham, other solution is to create seperate enum for effect/cause
	//	or to modify PerformModeChangeAction, replace case TOTAL_MODE_RESET_START with 
	//	TOTAL_MODE_RESET_START: TOTAL_MODE_ROLLOVER:.
	//}
	TOTAL_MAX_MODES							///< Total number of totalsier modes **Always at end
} T_TOTAL_MODE;

typedef struct {
	LONGLONG startTime;			///< StartTime of totaliser
	double totalValue;			///< current toalisation value
	ULONG runTimeInSeconds;		///< Run time of totlaliser in seconds
	ULONG currentMode;			///< current totaliser mode
} T_DP_TOTALISER;

const int MAX_TOTALS = V6_MAX_PENS;

//**Class*********************************************************************
///
/// @brief totaliser processor
/// 
/// Process and individual totals for a Pen, maintiain DIT
///
//****************************************************************************
class CTotal {
public:
	CTotal();

public:		// API methods

	T_TOTALS_RETURN IntialiseTotal(USHORT penNumber, T_PEN_REPORT *pReport);
	T_TOTALS_RETURN SetTotalFromConfig(T_PPEN pPenCfg, int penRateInTicks);

	void RequestTotalMode(T_TOTAL_MODE newMode) {
		m_modeRequest = newMode;
	}
	;	///< Set totaliser mode, Run, Pause, Reset

	BOOL IsEnabled() {
		return m_Enabled;
	}
	;		///< Is the totlaiser enabled

	void ProcessTotal();								///< Process the totaliser		

	// Static event methods
	static void ClearEventCauseTriggers();

private:	// Methods

	void ClearDown();
	void ResetTotalReport();
	void StoreChangedTotaliser();
	void StoreNewTotaliser();
	T_TOTALS_RETURN PerformModeChangeAction(T_TOTAL_MODE mode);
	void LogMessage(T_MSGLISTSER_USER_MSG_TYPE type, UINT messID);
	void SetEventCauseTrigger(T_TOTAL_MODE mode);

	void SetRunMode();
	void SetPauseMode();
	void SetResetMode();

public:		// Static members

	static T_EVENTDATA actionMask[TOTAL_MAX_MODES];

private:	// Member variables

	int m_penNumber;						///< Number of pen that totlaiser belongs to 0-95

	BOOL m_Enabled;	///< Is total(and pen) currently enabled? if so should be processed depending on m_currentMode member

	T_TOTAL_MODE m_modeRequest;				///< Request to change mode of totaliser
	BOOL m_StartupRequestSet;///< Indicates that a action has been requested on startup so don't perform on first config

	T_PTOTAL m_pTotalCfg;					///< Pointer to totaliser configuration in CMM
	T_PPEN m_pPenCfg;						///< Pointer to the Pen config for the totaliser
	CDataItemPen *m_pPenDataItem;			///< Pointer to Pen Data Item
	CDataItemTotal *m_pTotalDataItem;		///< Pointer to total Data Item

	int m_countDownTimer;					///< Countdown timer to gear the total to 1 second executions
	int m_reloadCount;						///< reloader counter for m_countDownTimer timer

	double m_StdTotFactor;					///< Standard totaliser factor taking 

	double m_TempStart;						///< Start Temperature for sterilisation in Input units (C, F or K)
	double m_TempRef;						///< Reference temperature in Input units (C, F or K) 
	double m_Zfactor;		///< Z Factor, temp ( in C, F or K) required to bring about 10 fold change in death rate.

	CNVTotaliser *m_pTotalInNV;				///< Pointer to NV based totlaiser

	T_DP_TOTALISER m_totData;				///< Double precision totaliser data

	T_PSCALEINFO m_pScaleDetails;			///< total scale details, used to detect log scale

	T_PEN_REPORT *m_pReport;				///< Pen report, used for totaliser access
	double m_reportHourTot;					///< Hourly report totaliser

};

#endif //__TOTALS_H__

/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 UI Control
/// @n Filename: TopStatusBarControl.h
/// @n Desc:	 Functionality for the sub functionality of the status bar
///				 
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  26  Stability Project 1.23.1.1 7/2/2011 5:02:08 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  25  Stability Project 1.23.1.0 7/1/2011 4:27:40 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  24  V6 Firmware 1.23 9/25/2009 3:20:14 PM  Binsy Pillai  
//  event cursor merging of code
//  23  V6 Firmware 1.22 9/23/2008 3:09:34 PM  Build Machine 
//  AMS2750 Merge
// $
//
// ****************************************************************

#if !defined(AFX_TOPSTATUSCONTROL_H__570BC2F0_AC0B_485D_9E01_E0BA66378784__INCLUDED_)
#define AFX_TOPSTATUSCONTROL_H__570BC2F0_AC0B_485D_9E01_E0BA66378784__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TopStatusControl.h : header file
//
#include "Defines.h"
#include "TV6Timer.h"
#include "Widget.h"

const UINT WM_CHANGE_TOPBAR_MODE = WM_USER + 600;
const UINT WM_OPPANEL_SOFT_BTN_CLICK = WM_USER + 601;

typedef enum {
	CONTROLBAR_MODE_SCREEN,			///< Control Bar in Screen mode
	CONTROLBAR_MODE_ALARM,			///< Control bar in Alarm mode
	CONTROLBAR_MODE_MESSAGE,		///< Control bar in Messages mode
	CONTROLBAR_MODE_REPLAY_MODE,	///< Replay mode
} T_CONTROLBAR_MODE;

// Status Bar mode, Normal or Screen Edit
typedef enum {
	TOPBAR_MODE_NORMAL,					///< Normal mode showing main menu and std control buttons
	TOPBAR_MODE_SCREEN_EDIT,			///< Screen edit mode, showing Screen design tools
	TOPBAR_MODE_REPLAY,					///< Replay anaysis mode (bar at bottom of screen )
	TOPBAR_MODE_REPLAY_MODE,			///< Replay mode change *** used as message type only ***
	TOPBAR_MODE_HIDE,					///< Show the top status bar *** used as message type only ***
	TOPBAR_MODE_SHOW,					///< Hide the top status bar *** used as message type only ***
	TOPBAR_MODE_LOCK,					///< Lock top status bar *** used as message type only ***
	TOPBAR_MODE_UNLOCK,					///< UnLock top status bar *** used as message type only ***
	TOPBAR_MODE_CONTEXT_ON,				///< Display the context menu *** used as message type only ***
	TOPBAR_MODE_DOWNLOAD_DATA			///< Set/Reset the flag indicating an FTP download data op is in progress
} T_TOPBAR_MODE;

// Replay states for bar mode
typedef enum {
	TOPBARSTAT_REPLAY_NONE,				///< No display mode change
	TOPBARSTAT_REPLAY_NORMAL,			///< Normal replay mode (move cursor/chart and Rev FWD buttons)
	TOPBARSTAT_REPLAY_MESSAGE,			///< Jump to Message mode
	TOPBARSTAT_REPLAY_DUAL_CURSOR,		///< Dual cursor mode
	TOPBARSTAT_REPLAY_MAX_MODES			///< Maximum number fo mods, always at end
} T_TOPBARSTAT_REPLAY;

/////////////////////////////////////////////////////////////////////////////
// CTopStatusControl dialog

class CTopStatusControl: public QDialog {
// Construction
public:
	CTopStatusControl(CWidget *pParent = NULL);  // standard constructor

	// Destructor
	~CTopStatusControl();

	void ShowControlBar(T_CONTROLBAR_MODE mode);
	void HideControlBar();
	BOOL GetVisible() {
		return m_Visible;
	}
	void SizeControlBar();
	void LockStatusControlBar(bool Locked);

	void ReplayButtonCheckAndShow();

	void OnCancel();			// Overridden

	void SetTopBarWnd(CWidget *pWnd) {
		pTopBarWnd = pWnd;
	}
	;

	/// Static const used to store the button font size
	static const USHORT m_usBTN_FONT_SIZE;

	virtual void OnOK();


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTopStatusControl)
protected:
	virtual void DoDataExchange(CDataItem *pDX);  // DDX/DDV support
	virtual void PostNcDestroy();
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
protected:
	void OnStatcontBtn1();afx_msg
	void OnStatcontBtn2();afx_msg
	void OnStatcontBtn3();afx_msg
	void OnStatcontBtn4();afx_msg
	void OnStatcontOk();afx_msg
	void OnTimer(UINT nIDEvent);
	virtual BOOL OnInitDialog();afx_msg
	void OnStatcontBtn5();afx_msg
	HBRUSH OnCtlColor(CDC *pDC, CWidget *pWnd, UINT nCtlColor);afx_msg
	void OnStatcontBtn6();

private:

	BOOL MarkChartSIP( QString &strMarkOnChart );

private:

	BOOL m_Visible;					///< Is the control currently visible?
	T_CONTROLBAR_MODE m_mode;		///< What mode is the control bar in?

	QRect m_CBPos;					///< Control Bar position and limits
	CWidget *m_pParent;				///< Handle on parent windows (OPPanel)

	QBrush m_bgBrush;				///< New Background Brush
	COLORREF m_BackColour;			///< Background Colour of dialog
	COLORREF m_TextColour;			///< Text Colour for dialog
	CFont *m_pkMultiFont;

	CWidget *pTopBarWnd;				///< Handle on Top Bar Window
	int m_BarHeight;				///< Height of Status Bar
	int m_BarButtonHeight;			///< Height of buttons in bar
	int m_BarOffset;				///< Bar offset from Top Status bar

	COpPanel *m_pOpPanel;			///< Pointer to OpPanel

	// Method that updates the batch icon to reflect the state of the batch the screen 
	void UpdateBatchControlBtn();

	// Prints the current screen to a file or to a printer, based on the users selection
	void PrintScreen();

	CTV6Timer m_TOTimer;

	// Sets up button 2 when showing the screen menu - this is required because
	// the contexzt of button 2 changes depending on the screen being display
	void SetupButton2ForScreenMenu();

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TOPSTATUSCONTROL_H__570BC2F0_AC0B_485D_9E01_E0BA66378784__INCLUDED_)

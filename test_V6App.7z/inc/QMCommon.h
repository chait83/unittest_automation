#ifndef _QUEUEMAN_COMMON_H
#define _QUEUEMAN_COMMON_H

#include "CStorage.h"
#include "V6defines.h"
#include "Defines.h"

const USHORT QMC_END_OF_QUEUE = 0xFFFF;
const USHORT QMC_START_OF_QUEUE = 0xFFFF;
const USHORT QMC_MIN_WRITE_LIMIT = 2;
const USHORT QMC_BLOCK_SIZE = 512;
const USHORT QMC_FILE_HEADER_SIZE = 512;
const USHORT QMC_SIGNATURE = 0xAA55;
const USHORT QMC_ZERO = 0;
const USHORT QMC_INVALID_QUEUE = 0xFFFF;
const USHORT QMC_ONE_BLOCK = 1;
const USHORT QMC_ONE_FILE = 1;
const USHORT QMC_INVALID_FILE_NUMBER = 0xFFFF;
const USHORT QMC_INVALID_BLOCK_NUMBER = 0xFFFF;
const USHORT QMC_FIRST_BLOCK_IN_FILE = 0x0001;
const ULONG QMC_FILE_QUEUE_MISMATCH = 0xFFFFFFFF;

const USHORT QMC_MAX_BLOCKS_ALLOWED_FOR_ONE_REQUEST = 128;

const WCHAR DATA_BLOCK_FILE_NAME[] = L"data"; // i.e. File 0 would have the filename data0000.blk
const WCHAR DATA_BLOCK_FILE_EXTENSION[] = L".blk"; // Data Block File Extension	
const WCHAR DATA_BLOCK_SUBDIR_PREFIX[] = L"sdata";	// Subdirectory prefix

const int NUMBER_OF_FOLDER_SPREAD_OVER = 200;	// number of folders to spread the files over for faster access
const int DATA_FILES_PER_DIRECTORY = 120;			// Number of file per folder
const USHORT MAX_FILES = 1500;				// absolute maximum of created files

const USHORT QMC_MAX_TEMP_STORED_SIZE = 100;				//The maximum allowed temporary stored blocks

typedef enum {
	QMC_NUM_MSG_Q_READS_ALARMS = 3000,
	QMC_NUM_MSG_Q_READS_SYSTEM = 1000,
	QMC_NUM_MSG_Q_READS_USER = 3000,
	QMC_NUM_MSG_Q_READS_SECURITY = 3000,
	QMC_NUM_MSG_Q_READS_DIAGS = 500,
	QMC_NUM_MSG_Q_READS_ALARMS4CHART = 1000,
} T_QMC_NUM_MSG_Q_READS;

const USHORT QMC_NUM_MSG_Q_READS_ARRAY[] = { QMC_NUM_MSG_Q_READS_ALARMS, QMC_NUM_MSG_Q_READS_SYSTEM,
		QMC_NUM_MSG_Q_READS_USER, QMC_NUM_MSG_Q_READS_SECURITY, QMC_NUM_MSG_Q_READS_DIAGS,
		QMC_NUM_MSG_Q_READS_ALARMS4CHART, 0, 0, 0, 0 };
//////////////////////////////////////////////////////////////////////////////////
// Queue Manager System Structures and Enumerations
//////////////////////////////////////////////////////////////////////////////////

/// Enumeration which details the users of the Disk Services. 
typedef enum {
	USRREQSER_USER_OPPANEL, USRREQSER_USER_LOGGING, USRREQSER_USER_MESSAGE_SERVICES, USRREQSER_USER_CHART_LOCAL,

	USRREQSER_NUM_OF_USERS // Always at the End

} T_USRREQSER_USER;

typedef enum {
	QMC_CONFIRMATION_REQUIRED, QMC_CONFIRMATION_NOT_REQUIRED

} T_QMC_QUEUE_CONFIRMATION;

typedef enum {
	QMC_DEFAULT_INIT, QMC_NORMAL_INIT

} T_QMC_INITIALISATION_TYPE;

// Remember:
// These stati are stored in NV, Don't change existing values, just add new.
typedef enum {
	QMC_TRANS_INITIALISED = 0, // Transaction point initialised (used by chart queues)
	QMC_TRANS_NOTUSED,				// Transaction point not in use
	QMC_TRANS_INUSE,				// Transaction point in use
	QMC_TRANS_RECYCLED,				// Transaction point has been recycled
	QMC_TRANS_STICKY,				// Sticky transaction point (!):- Ignore first re-cycle and set to QMC_TRANS_INUSE
	QMC_TRANS_UPDATED,				// Transaction point has been updated, don't use for queue monitor calculations
	QMC_TRANS_ROLLBACK = 0x100,				// Saved transaction point, roll-back on power restore.

} T_QMC_RECYCLE_STATE;

typedef enum {
	QMC_QUEUE_EMPTY, QMC_QUEUE_HAS_DATA
} T_QMC_QUEUE_USED_STATUS;

typedef struct {
	USHORT numOfMessageQueues;
	USHORT maxNumOfPens;
	//USHORT numOfPensAvailable;
	// USHORT numOfQueuesPerPen;
	ULONG lengthOfMemoryInBytes;
	// ULONG diskSizeInBytes;
	ULONGLONG diskSizeInBytes;
	ULONGLONG fileSizeInBytes;

} T_QMC_SYSTEM_INFO, *T_PQMC_SYSTEM_INFO;

typedef struct {
	USHORT signature;
	USHORT status;
	ULONG numOfActiveQueues;
	USHORT numOfFiles;
	USHORT numOfBlocks;
	USHORT numOfQueues;
	USHORT numOfDataBlocksPerFile;

	T_QMC_SYSTEM_INFO systemInfo;

} T_QMC_DATA, *T_PQMC_DATA;

//////////////////////////////////////////////////////////////////////////////////
// Data Block Structures and Enumerations
//////////////////////////////////////////////////////////////////////////////////

typedef struct {
	USHORT fileId;
	USHORT blockId;
	SHORT numOfBlocksLastRequested;
	USHORT recycleState;

} T_QMC_FILE_BLOCK_TRANSACTION;

typedef enum {
	QMC_BLKQ_STATUS_QUEUE_SETUP,
	QMC_BLKQ_STATUS_QUEUE_NOT_SETUP,
	QMC_BLKQ_STATUS_ADD_NEW_BLOCK,
	QMC_BLKQ_STATUS_ADD_LINK_TO_TAIL,
	QMC_BLKQ_STATUS_REMOVE_BLKS,
	QMC_BLKQ_STATUS_RELEASE_BLOCK

} T_QMC_BLOCK_QUEUE_STATUS;

typedef enum {
	QMC_OK_NO_ACTION, QMC_OK_FLUSH_REQUIRED, QMC_ERROR_NO_BLOCKS_AVAILABLE

} T_QMC_QUEUE_STATUS;

///
typedef enum {
	QMC_BLKSTATUS_NOT_USED, QMC_BLKSTATUS_IN_USE, QMC_BLKSTATUS_COMPLETE, QMC_BLKSTATUS_WRITTEN

} T_QMC_BLOCK_STATUS;

const INT QMC_FILES_PER_CIRCULAR_CHART_QUEUE = 1;
const INT QMC_NO_OF_CIRCULAR_PEN_QUEUES_PER_PEN = 3;
const INT QMC_NO_OF_LEGACY_PEN_QUEUES = 4;
const INT QMC_TOTAL_NO_OF_CHART_QUEUES_PER_PEN = 6;
const INT QMC_TOTAL_NO_OF_QUEUES_PER_PEN = 7;

const INT QMC_TOTAL_NO_OF_PEN_QUEUES = V6_MAX_PENS * QMC_TOTAL_NO_OF_QUEUES_PER_PEN; // 672
//const INT QMC_TOTAL_NO_OF_PEN_QUEUES = 96 * QMC_TOTAL_NO_OF_QUEUES_PER_PEN; // 672

const int MESSAGE_LIST_QUEUE_START_ID = QMC_TOTAL_NO_OF_PEN_QUEUES; // 672

const int QMC_LAST_QUEUE_ID = MESSAGE_LIST_QUEUE_START_ID + 10; // Assume 10 message queues max

const USHORT QMC_INVALID_Q_ID = (QMC_LAST_QUEUE_ID + 100);
/// Enum used as an identifier but also equating to the index of each pen queue (i.e. 0-6 is pen 1, 
/// 7-13 is pen 2 etc) The message list enum at the end doesn't actually equate ot an index but 
/// rather is used as an identifier only
typedef enum {
	QMC_QUEUE_PEN_LOG,
	QMC_QUEUE_PEN_SCR_SLOW,
	QMC_QUEUE_PEN_SCR_MEDIUM,
	QMC_QUEUE_PEN_SCR_FAST,
	QMC_QUEUE_PEN_SCR_CIRC_SLOW,
	QMC_QUEUE_PEN_SCR_CIRC_MEDIUM,
	QMC_QUEUE_PEN_SCR_CIRC_FAST,
	QMC_QUEUE_MESSAGE

} T_QMC_QUEUE_TYPE;

///
typedef struct {
	USHORT Status;
	USHORT Head;
	USHORT Tail;
	USHORT NumOfBlocksInQueue;

} T_QMC_BLOCK_QUEUE, *T_PQMC_BLOCK_QUEUE;

///
typedef struct {
	USHORT Status;
	USHORT queueType;
	USHORT Head;
	USHORT Tail;
	USHORT NumOfBlocksInQueue;
	USHORT FlushToDiskLimit;
	USHORT QueueConfirmation;
	USHORT UserStatus;

} T_QMC_PERSIST_DATA_BLKQ, *T_PQMC_PERSIST_DATA_BLKQ;

///
typedef struct {
	USHORT blockId;
	USHORT QueueId;
	USHORT blockstatus;
	USHORT blockType;
	USHORT nextBlock;
	USHORT alignmentPadding;

} T_QMC_BLOCK_HEADER, *T_PQMC_BLOCK_HEADER;

///
typedef struct _structBlkHanBlock {
	T_QMC_BLOCK_HEADER blockHeader;
	BYTE blockData[QMC_BLOCK_SIZE];

} T_QMC_BLOCK, *T_PQMC_BLOCK;

//////////////////////////////////////////////////////////////////////////////////
// Data File Structures and Enumerations
//////////////////////////////////////////////////////////////////////////////////
typedef enum {
	QMC_DATAFILE_MODE_NORMAL, QMC_DATAFILE_MODE_RECYCLING,

} T_QMC_DATAFILE_MODE;

typedef enum {
	QMC_DATAFILE_MAX_REACHED, QMC_DATAFILE_MIN_NOT_REACHED, QMC_DATAFILE_MAX_EXCEEDED, QMC_DATAFILE_EMPTY

} T_QMC_PERSIST_DFQ_STATUS;

typedef enum {
	QMC_ERROR_NO_FILE,
	QMC_ERROR_INVALID_HEADER,
	QMC_FILE_AVAILABLE_NOT_USED,
	QMC_FILE_UNAVAILABLE,
	QMC_OPERATION_IN_PROGRESS,
	QMC_BLOCK_WRITTEN_TO_DISK,
	QMC_HEADER_UPDATE_IN_PROGRESS,
	QMC_OPERATION_COMPLETE

} T_QMC_FILE_STATUS;

///
typedef struct {
	USHORT fileId;
	USHORT fileStatus;
	USHORT queueId;
	USHORT fileMode;			// Normal, Recycling, Full 
	USHORT previousFile;
	USHORT nextFile;
	USHORT numOfDataBlocks;
	USHORT oldestBlockNumber;
	USHORT newestBlockNumber;
	USHORT alignmentPadding;

} T_QMC_DATAFILE_HEADER, *T_PQMC_DATAFILE_HEADER;

///
typedef struct {
	USHORT Status;
	USHORT Head;
	USHORT Tail;
	USHORT NumOfFilesInQueue;
	USHORT MaxFiles;
	USHORT MinFiles;

} T_QMC_PERSIST_DATAFILE_QUEUE, *T_PQMC_PERSIST_DATAFILE_QUEUE;

///
typedef struct {
	USHORT Status;
	USHORT Head;
	USHORT Tail;
	USHORT NumOfFilesInQueue;

} T_QMC_DATAFILE_QUEUE, *T_PQMC_DATAFILE_QUEUE;

typedef struct {
	//HANDLE hFile;
	BOOL bFileCreated;
	BOOL bFileCurrOpen;
	CStorage *pFile;
} T_QMC_DBFILES, *T_PQMC_DBFILES;

#endif // _QUEUEMAN_COMMON_H

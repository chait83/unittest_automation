#ifndef __PRINTCE_H__
#define __PRINTCE_H__

#pragma once

#ifndef PD_SELECTPORTRAIT
#include "Defines.h"
typedef UINT (APIENTRY *LPPRINTHOOKPROC) (HWND, UINT, WPARAM, LPARAM);
typedef struct tagPD {
	DWORD cbStruct;
	HWND hwndOwner;
	HDC hdc;
	DWORD dwFlags;
	QRect rcMinMargin;
	QRect rcMargin;
	HINSTANCE hinst;
	LPARAM lCustData;
	LPPRINTHOOKPROC pfnPrintHook;
	LPCTSTR pszPrintTemplateName;
	HGLOBAL hglbPrintTemplateResource;
} PRINTDLG, *LPPRINTDLG;
BOOL APIENTRY PrintDlg(LPPRINTDLG);

// Out only
#define PD_SELECTALLPAGES 0x00000001
#define PD_SELECTSELECTION  0x00000002
#define PD_SELECTDRAFTMODE  0x00000008
#define PD_SELECTA4  0x00000010
#define PD_SELECTLETTER  0x00000020
#define PD_SELECTINFRARED 0x00000040 
#define PD_SELECTSERIAL  0x00000080
// In only
#define PD_DISABLEPAPERSIZE  0x00000100
#define PD_DISABLEPRINTRANGE 0x00000200
#define PD_DISABLEMARGINS 0x00000400
#define PD_DISABLEORIENTATION 0x00000800
#define PD_RETURNDEFAULTDC  0x00002000
#define PD_ENABLEPRINTHOOK  0x00004000 // not supported
#define PD_ENABLEPRINTTEMPLATE  0x00008000 // not supported
#define PD_ENABLEPRINTTEMPLATEHANDLE 0x00010000 // not supported
#define PD_TITLE 0x00020000 // not supported
// In-Out
#define PD_SELECTPORTRAIT 0x00040000
#define PD_SELECTLANDSCAPE  0x00080000
#define PD_MARGINS  0x00100000
#define PD_INTHOUSANDTHSOFINCHES 0x00200000
#define PD_INHUNDREDTHSOFMILLIMETERS 0x00400000
#define PD_MINMARGINS 0x00800000 // not supported

#endif // PD_SELECTPORTRAIT

#ifndef PSD_DEFAULTMINMARGINS
typedef struct tagDEVNAMES {
	WORD wDriverOffset;
	WORD wDeviceOffset;
	WORD wOutputOffset;
	WORD wDefault;
} DEVNAMES;

typedef DEVNAMES *LPDEVNAMES;

#define DN_DEFAULTPRN 0x0001

DWORD APIENTRY CommDlgExtendedError(VOID);

typedef UINT (APIENTRY* LPPAGEPAINTHOOK)( HWND, UINT, WPARAM, LPARAM );
typedef UINT (APIENTRY* LPPAGESETUPHOOK)( HWND, UINT, WPARAM, LPARAM );

typedef struct tagPSDA {
	DWORD lStructSize;
	HWND hwndOwner;
	HGLOBAL hDevMode;
	HGLOBAL hDevNames;
	DWORD Flags;
	QPoint ptPaperSize;
	QRect rtMinMargin;
	QRect rtMargin;
	HINSTANCE hInstance;
	LPARAM lCustData;
	LPPAGESETUPHOOK lpfnPageSetupHook;
	LPPAGEPAINTHOOK lpfnPagePaintHook;
	LPCSTR lpPageSetupTemplateName;
	HGLOBAL hPageSetupTemplate;
} PAGESETUPDLGA, *LPPAGESETUPDLGA;

typedef struct tagPSDW {
	DWORD lStructSize;
	HWND hwndOwner;
	HGLOBAL hDevMode;
	HGLOBAL hDevNames;
	DWORD Flags;
	QPoint ptPaperSize; // ignored in CE
	QRect rtMinMargin;
	QRect rtMargin;
	HINSTANCE hInstance;
	LPARAM lCustData;
	LPPAGESETUPHOOK lpfnPageSetupHook;
	LPPAGEPAINTHOOK lpfnPagePaintHook; // ignored in CE
	LPCWSTR lpPageSetupTemplateName;
	HGLOBAL hPageSetupTemplate;
} PAGESETUPDLGW, *LPPAGESETUPDLGW;

#ifdef UNICODE
typedef PAGESETUPDLGW PAGESETUPDLG;
typedef LPPAGESETUPDLGW LPPAGESETUPDLG;
#else
typedef PAGESETUPDLGA PAGESETUPDLG;
typedef LPPAGESETUPDLGA LPPAGESETUPDLG;
#endif // UNICODE

BOOL APIENTRY PageSetupDlgA(LPPAGESETUPDLGA);
BOOL APIENTRY PageSetupDlgW(LPPAGESETUPDLGW);
#ifdef UNICODE
#define PageSetupDlg PageSetupDlgW
#else
#define PageSetupDlg PageSetupDlgA
#endif // UNICODE

#define PSD_DEFAULTMINMARGINS 0x00000000 // not supported
#define PSD_INWININIINTLMEASURE  0x00000000 // not supported
#define PSD_MINMARGINS  0x00000001 // not supported
#define PSD_MARGINS  0x00000002
#define PSD_INTHOUSANDTHSOFINCHES 0x00000004
#define PSD_INHUNDREDTHSOFMILLIMETERS 0x00000008
#define PSD_DISABLEMARGINS  0x00000010
#define PSD_DISABLEPRINTER  0x00000020
#define PSD_NOWARNING 0x00000080 // not supported
#define PSD_DISABLEORIENTATION  0x00000100
#define PSD_DISABLEPAPER 0x00000200
#define PSD_RETURNDEFAULT 0x00000400
#define PSD_SHOWHELP 0x00000800 // not supported
#define PSD_ENABLEPAGESETUPHOOK  0x00002000 // not supported
#define PSD_ENABLEPAGESETUPTEMPLATE  0x00008000 // not supported
#define PSD_ENABLEPAGESETUPTEMPLATEHANDLE 0x00020000 // not supported
#define PSD_ENABLEPAGEPAINTHOOK  0x00040000 // not supported
#define PSD_DISABLEPAGEPAINTING  0x00080000 // not supported
#define PSD_NONETWORKBUTTON  0x00200000 // not supported
#define PSD_DISABLEPRINTRANGE 0x10000000
#define PSD_RANGESELECTION  0x20000000

#endif // PSD_DEFAULTMINMARGINS

#ifndef SP_ERROR
#define SP_ERROR (-1)

#ifdef STRICT
typedef BOOL (CALLBACK* ABORTPROC)(HDC, int);
#else
typedef FARPROC ABORTPROC;
#endif //STRICT

typedef struct _DOCINFOA {
	int cbSize;
	LPCSTR lpszDocName;
	LPCSTR lpszOutput;
	LPCSTR lpszDatatype;
	DWORD fwType;
} DOCINFOA, *LPDOCINFOA;

typedef struct _DOCINFOW {
	int cbSize;
	LPCWSTR lpszDocName;
	LPCWSTR lpszOutput;
	LPCWSTR lpszDatatype;
	DWORD fwType;
} DOCINFOW, *LPDOCINFOW;

#ifdef UNICODE
typedef DOCINFOW DOCINFO;
typedef LPDOCINFOW LPDOCINFO;
#else
typedef DOCINFOA DOCINFO;
typedef LPDOCINFOA LPDOCINFO;
#endif // UNICODE
#endif // SP_ERROR

typedef struct _PRN_INFO {
	int printer;
	int port;
	int paper;
	SIZE paper_size;
	int color_mode;
	BOOL portrait;
	BOOL draft_mode;
	QRect user_margins;
	int start_page;
	int end_page;
} PRN_INFO;

// these defines used with PDC_GETSTATE
#define PRINT_STATE_PREPARE_PRINTING		0
#define PRINT_STATE_ESTABLISH_CONNECTION	1
#define PRINT_STATE_CONNECTED				2
#define PRINT_STATE_DISCONNECTED			3
#define PRINT_STATE_LOST_CONNECTION			4
#define PRINT_STATE_CLOSING_CONNECTION		5

// PDC API
typedef void (*FnpdcInit)(QString   );
typedef void (*FnpdcUnInit)();
typedef BOOL (*FnpdcPageSetupDlg)(LPPAGESETUPDLG);
typedef BOOL (*FnpdcPrintDlg)(LPPRINTDLG);
typedef BOOL (*FnpdcSilentPrintSetup)(HWND, PRN_INFO*);
typedef void (*FnpdcGetCurrentSetup)(PRN_INFO*);
typedef int (*FnpdcGetState)();
typedef int (*FnpdcIsConnection)();
typedef int (*FnpdcStartDoc)(HDC, const DOCINFO*);
typedef int (*FnpdcEndDoc)(HDC);
typedef int (*FnpdcStartPage)(HDC);
typedef int (*FnpdcEndPage)(HDC);
typedef HDC (*FnpdcGetPrinterDC)();
typedef BOOL (*FnpdcBitBlt)(HDC, int, int, int, int, HDC, int, int, DWORD);
typedef BOOL (*FnpdcStretchBlt)(HDC, int, int, int, int, HDC, int, int, int, int, DWORD);
typedef HGDIOBJ (*FnpdcSelectObject)(HDC, HGDIOBJ);
typedef HDC (*FnpdcCreateCompatibleDC)(HDC);
typedef int (*FnpdcGetDeviceCaps)(HDC, int);
typedef BOOL (*FnpdcDeleteDC)(HDC);
typedef int (*FnpdcDrawText)(HDC, LPCTSTR, int, LPRECT, UINT);
typedef int (*FnpdcDrawTextFlow)(HDC, LPCTSTR, LPRECT, UINT);
typedef int (*FnpdcGetTextFlowHeight)(HDC, LPCTSTR, int, UINT);
typedef BOOL (*FnpdcExtTextOut)(HDC, int, int, UINT, const QRect*, LPCTSTR, UINT, const int*);
typedef BOOL (*FnpdcGetTextExtentPoint)(HDC, LPCTSTR, int, LPSIZE);
typedef BOOL (*FnpdcGetTextExtentExPoint)(HDC, LPCTSTR, int, int, LPINT, LPINT, LPSIZE);
typedef BOOL (*FnpdcGetTextMetrics)(HDC, LPTEXTMETRIC);
typedef COLORREF (*FnpdcSetTextColor)(HDC, COLORREF);
typedef COLORREF (*FnpdcSetBkColor)(HDC, COLORREF);
typedef int (*FnpdcSetBkMode)(HDC, int);
typedef int (*FnpdcSetROP2)(HDC, int);
typedef BOOL (*FnpdcEllipse)(HDC, int, int, int, int);
typedef BOOL (*FnpdcDrawLine)(HDC, int, int, int, int);
typedef BOOL (*FnpdcPolyline)(HDC, const QPoint*, int);
typedef BOOL (*FnpdcRectangle)(HDC, int, int, int, int);
typedef BOOL (*FnpdcRoundRect)(HDC, int, int, int, int, int, int);
typedef int (*FnpdcGetVersion)();
typedef int (*FnpdcSetAbortProc)(HDC, ABORTPROC);
typedef void (*FnpdcSetSilentMode)(BOOL);
typedef int (*FnpdcGetSentBytes)();
typedef void (*FnpdcSetPDFFile)(LPCTSTR);
typedef void (*FnpdcSetLanguage)(int);
typedef void (*FnpdcSetPrnParam)(int, int);
typedef BOOL (*FnpdcPolygon)(HDC, const QPoint*, int);
typedef int (*FnpdcIntersectClipRect)(HDC, int, int, int, int);
typedef void (*FnpdcResetClipRect)(HDC);
typedef void (*FnpdcPdfDashPolyline)(HDC, const QPoint*, int, int, int, int);

typedef int (*FnpdcDrawCodaBar)(HDC, LPCTSTR, int, int, BOOL, int);
typedef int (*FnpdcDrawPostnet)(HDC, LPCTSTR, int, int, BOOL);
typedef int (*FnpdcDrawCode39)(HDC, LPCTSTR, int, int, BOOL, BOOL, int);
typedef int (*FnpdcDrawCode93)(HDC, LPCTSTR, int, int, BOOL, int);
typedef int (*FnpdcDrawEAN13)(HDC, LPCTSTR, LPCTSTR, int, int, BOOL, int);
typedef int (*FnpdcDrawEAN8)(HDC, LPCTSTR, LPCTSTR, int, int, BOOL, int);
typedef int (*FnpdcDrawUPCA)(HDC, LPCTSTR, LPCTSTR, int, int, BOOL, int);
typedef int (*FnpdcDrawUPCE)(HDC, LPCTSTR, LPCTSTR, int, int, BOOL, int);
typedef int (*FnpdcDraw2OF5)(HDC, LPCTSTR, int, int, BOOL, BOOL, int);
typedef int (*FnpdcDrawCode128)(HDC, LPCTSTR, int, int, BOOL, int);
typedef int (*FnpdcDrawUCC128)(HDC, LPCTSTR, int, int, BOOL, int);
typedef int (*FnpdcDrawMSI)(HDC, LPCTSTR, int, int, BOOL, int, int);
typedef int (*FnpdcDrawPDF417)(HDC, LPCTSTR, int, int, int, int, BOOL, BOOL);
typedef void (*FnpdcSetBarCodeHeight)(double);
typedef void (*FnpdcSetBarCodeScale)(double);
typedef void (*FnpdcSetBarCodeAngle)(int);
typedef void (*FnpdcSetNetworkAddr)(LPCTSTR);
typedef void (*FnpdcSetPdfPassword)(LPCTSTR);
typedef void (*FnpdcSetPdfEncodeMode)(int);
typedef void (*FnpdcSetPdfQuality)(int);
typedef void (*FnpdcPdfTextToImage)(int, int, HDC, QFont, LPCTSTR, SIZE*);
typedef void (*FnpdcSetGamma)(double);
typedef BOOL (*FnpdcSetPrinterDpi)(int, int, int);
typedef int (*FnpdcGetPrinterDpi)(int, BOOL);

// Simple API

typedef enum {
	kPixels = 0, kInches, kMillimeters, kCentimeters, kPoints
} MeasureUnit;

typedef enum {
	hleft = 0, hright, hCenter
} TextHorAlign;

typedef enum {
	vTop = 0, vBottom, vCenter
} TextVertAlign;

typedef void (*FnprnInit)(QString   );
typedef void (*FnprnUnInit)();
typedef BOOL (*FnprnSetupDlg)(HWND);
typedef BOOL (*FnprnSilentPrintSetup)(HWND, PRN_INFO*);
typedef void (*FnprnGetCurrentSetup)(PRN_INFO*);
typedef int (*FnprnGetState)();
typedef int (*FnprnIsConnection)();
typedef int (*FnprnStartDoc)();
typedef int (*FnprnStartPage)();
typedef int (*FnprnEndDoc)();
typedef void (*FnprnDrawText)(LPCTSTR, double, double);
typedef int (*FnprnDrawTextFlow)(LPCTSTR, double, double, double, double);
typedef double (*FnprnGetTextFlowHeight)(LPCTSTR, double);
typedef void (*FnprnDrawText2)(LPCTSTR, double, double, COLORREF);
typedef void (*FnprnDrawAlignedText)(LPCTSTR, double, double, TextHorAlign, TextVertAlign);
typedef void (*FnprnDrawEllipse)(double, double, double, double);
typedef void (*FnprnDrawCircle)(double, double, double);
typedef void (*FnprnDrawLine)(double, double, double, double);
typedef void (*FnprnDrawRect)(double, double, double, double);
typedef void (*FnprnDrawSolidRect)(double, double, double, double, COLORREF color);
typedef void (*FnprnDrawRoundRect)(double, double, double, double, double, double);
typedef BOOL (*FnprnDrawPicture)(TCHAR*, double, double, double, double, BOOL);
typedef BOOL (*FnprnDrawBitmap)(QImage, double, double, double, double, BOOL);
typedef BOOL (*FnprnGetPictureSize)(TCHAR*, double*, double*);
typedef double (*FnprnConvertValue)(double, MeasureUnit, MeasureUnit);
typedef void (*FnprnSetMeasureUnit)(int);
typedef int (*FnprnGetMeasureUnit)();
typedef void (*FnprnSetLineWidth)(double);
typedef double (*FnprnGetLineWidth)();
typedef void (*FnprnSetLineColor)(COLORREF);
typedef COLORREF (*FnprnGetLineColor)();
typedef void (*FnprnSetFillColor)(COLORREF);
typedef COLORREF (*FnprnGetFillColor)();
typedef void (*FnprnSetFillStyle)(int);
typedef int (*FnprnGetFillStyle)();
typedef void (*FnprnSetTextColor)(COLORREF);
typedef COLORREF (*FnprnGetTextColor)();
typedef void (*FnprnSetFontName)(TCHAR*);
typedef TCHAR* (*FnprnGetFontName)();
typedef void (*FnprnSetFontSize)(double);
typedef void (*FnprnSetFontSize2)(double, MeasureUnit);
typedef double (*FnprnGetFontSize)();
typedef double (*FnprnGetFontSize2)(MeasureUnit);
typedef void (*FnprnSetFontBold)(BOOL);
typedef BOOL (*FnprnGetFontBold)();
typedef void (*FnprnSetFontItalic)(BOOL);
typedef BOOL (*FnprnGetFontItalic)();
typedef void (*FnprnSetFontStrike)(BOOL);
typedef BOOL (*FnprnGetFontStrike)();
typedef void (*FnprnSetFontUnderline)(BOOL);
typedef BOOL (*FnprnGetFontUnderline)();
typedef double (*FnprnGetTextHeight)(TCHAR*);
typedef double (*FnprnGetTextWidth)(TCHAR*);
typedef double (*FnprnGetPageHeight)();
typedef double (*FnprnGetPageWidth)();
typedef double (*FnprnGetleftMargin)();
typedef void (*FnprnSetleftMargin)(double);
typedef double (*FnprnGetrightMargin)();
typedef void (*FnprnSetrightMargin)(double);
typedef double (*FnprnGetTopMargin)();
typedef void (*FnprnSetTopMargin)(double);
typedef double (*FnprnGetBottomMargin)();
typedef void (*FnprnSetBottomMargin)(double);
typedef int (*FnprnGetVersion)();
typedef int (*FnprnSetAbortProc)(ABORTPROC);
typedef void (*FnprnSetSilentMode)(BOOL);
typedef int (*FnprnGetSentBytes)();
typedef void (*FnprnSetTransparentTextBgr)(BOOL);
typedef void (*FnprnSetTextHorAlign)(TextHorAlign);
typedef void (*FnprnSetTextVertAlign)(TextVertAlign);
typedef void (*FnprnSetPDFFile)(LPCTSTR);
typedef void (*FnprnSetLanguage)(int);
typedef void (*FnprnSetPrnParam)(int, int);
typedef void (*FnprnSetFontAngle)(int);
typedef int (*FnprnGetFontAngle)();

typedef double (*FnprnDrawCodaBar)(LPCTSTR, double, double, BOOL, int);
typedef double (*FnprnDrawPostnet)(LPCTSTR, double, double, BOOL);
typedef double (*FnprnDrawCode39)(LPCTSTR, double, double, BOOL, BOOL, int);
typedef double (*FnprnDrawCode93)(LPCTSTR, double, double, BOOL, int);
typedef double (*FnprnDrawEAN13)(LPCTSTR, LPCTSTR, double, double, BOOL, int);
typedef double (*FnprnDrawEAN8)(LPCTSTR, LPCTSTR, double, double, BOOL, int);
typedef double (*FnprnDrawUPCA)(LPCTSTR, LPCTSTR, double, double, BOOL, int);
typedef double (*FnprnDrawUPCE)(LPCTSTR, LPCTSTR, double, double, BOOL, int);
typedef double (*FnprnDraw2OF5)(LPCTSTR, double, double, BOOL, BOOL, int);
typedef double (*FnprnDrawCode128)(LPCTSTR, double, double, BOOL, int);
typedef double (*FnprnDrawUCC128)(LPCTSTR, double, double, BOOL, int);
typedef double (*FnprnDrawMSI)(LPCTSTR, double, double, BOOL, int, int);
typedef double (*FnprnDrawPDF417)(LPCTSTR, double, double, int, int, BOOL, BOOL);
typedef void (*FnprnSetBarCodeHeight)(double);
typedef void (*FnprnSetBarCodeScale)(double);
typedef void (*FnprnSetBarCodeAngle)(int);
typedef void (*FnprnSetNetworkAddr)(LPCTSTR);
typedef void (*FnprnSetPdfPassword)(LPCTSTR);
typedef void (*FnprnSetPdfEncodeMode)(int);
typedef void (*FnprnSetPdfQuality)(int);
typedef void (*FnprnSetGamma)(double);
typedef BOOL (*FnprnSetPrinterDpi)(int, int, int);
typedef int (*FnprnGetPrinterDpi)(int, BOOL);

#endif //__PRINTCE_H__ 

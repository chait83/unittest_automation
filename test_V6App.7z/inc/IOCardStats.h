/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n IOCardStats.h
/// @n interface of the IOCardStats class.
/// @author GKW
/// @date 29/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 28	Stability Project 1.25.1.1	7/2/2011 4:58:01 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 27	Stability Project 1.25.1.0	7/1/2011 4:27:05 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 26	V6 Firmware 1.25		4/24/2007 7:22:52 PM	Graham Waterfield
//		Added AO load status indication
// 25	V6 Firmware 1.24		9/25/2006 2:48:39 PM	Graham Waterfield
//		Added ADC CHANS INIT error message as parameter version
// $
//
//////////////////////////////////////////////////////////////////////

#ifndef _CARDSTATS_H
#define _CARDSTATS_H

#include "CMMDefines.h"
#include "V6Config.h"

#undef V6AISPECIALCODES_H
#include "V6AISpecialCodes.H"

#include "V6IOConstraints.H"
#include "V6IOStats.H"

#include "InputConditioning.h"

// Error codes for IO Card response
// NOTE THESE NEED TO ALIGNED TO THE AP8 ERROR CODES (without AP8_ prefix) in oeminc.h
const UCHAR AP8_IOCARD_ERROR_OK = 0;		// AP8, No error reported
const UCHAR AP8_IOCARD_ERROR_SETLOC_FAILED = 1;	// AU1100 could not Set a location(in data) AP8 holding onto it
const UCHAR AP8_IOCARD_ERROR_MESS_TO_LONG = 2;	// Message trying to be sent to DP is too long
const UCHAR AP8_IOCARD_ERROR_AP8_NOT_READY = 3;	// AP8 not registering that it is ready to receive data
const UCHAR AP8_IOCARD_ERROR_TIMEOUT_AP8_SENDMESS = 4;// AU1100 timed out waiting for AP8 to sending a message to an IO Card
const UCHAR AP8_IOCARD_ERROR_TIMEOUT_AP8_GETMESS = 5;// AU1100 timed out waiting for AP8 to retreive message from card
const UCHAR AP8_IOCARD_ERROR_NO_MESSAGE_RXD = 6;	// No message was received from the IO Card
const UCHAR AP8_IOCARD_ERROR_FAILED_MESSAGE_RXD = 7;// Message was received but failed checksum from card several times
const UCHAR AP8_IOCARD_ERROR_UNKNOWN_RESPONSE_ON_READ = 8;// Unknown response on read message, command response in data
const UCHAR AP8_IOCARD_ERROR_MESS_IN_TO_LONG = 9;	// Incomming message too long according to header
const UCHAR AP8_IOCARD_ERROR_MESSAGE_IN_DP_FAILED = 10;	// AP8 CRC check on message in DP ram(from AU1100) failed
const UCHAR AP8_IOCARD_ERROR_SPI_NOT_READY = 11;		// SPI Not ready
const UCHAR AP8_IOCARD_ERROR_NO_DATA = 12;		// SPI data not returned
const UCHAR AP8_IOCARD_ERROR_PREAMBLE_FAIL = 13;		// Preamble returned form the card was too much
const UCHAR AP8_IOCARD_ERROR_COUNT = 14;		// Total number of codes returned by AP8

struct OverallBoardStats {
	USHORT BoardIdentified :1;	///< Board has been identified

	USHORT ChanFailed :1;	///< One or more channels have failed in service; includes RTCal & RTComp
	USHORT BoardFailed :1;		///< Board has failed in service
	USHORT CJFailed :1;			///< CJ has failed
};

struct GenBoardStats1 {
	USHORT CommandFailed :1;	///< Command has been retried	but still failed
	USHORT CommandRetried :1;		///< Command has been retried

	USHORT NoResponse :1;			///< No response from card error
	USHORT OutOfSequence :1;		///< Message sequence was incorrect
	USHORT UnknownFC :1;			///< Unknown command function code
	USHORT InvalidFC :1;			///< Invalid command function code
	USHORT CardBusy :1;			///< Card was busy when new command sent

	USHORT InitBoardFailed :1;	///< Board initialisation sequence failed
	USHORT GUIDFailed :1;			///< Configuration GUID on board does match

	USHORT GUIDUTD :1;	///< Unable to download Configuration GUID from board
	USHORT LifeHistoryUTD :1;	///< Unable to download life history from board
};

struct GenBoardStats2 {
	USHORT ReadingErrors :1;		///< One or more reading errors occurred
	USHORT CalibrationFailed :1;	///< Calibration command failed
	USHORT UserCalLost :1;		///< User calibration values have been lost
	USHORT FactoryCalLost :1;	///< Factory calibration values have been lost
	USHORT ReturnSize :1;		///< Message return would be too long for buffer

	USHORT ConfigUploadFail :1;	///< Config upload from board failed
	USHORT ConfigDownloadFail :1;	///< Config download to board failed

	USHORT NVReadFail :1;		///< I/O board Non Volatile memory read failure
	USHORT NVWriteFail :1;		///< I/O board Non Volatile memory write failure
	USHORT NVCRCFail :1;		///< I/O board Non Volatile memory CRC failure

	USHORT FieldFailed :1;		///< Field port on I/O board has failed
};

struct GenBoardStatus {
	struct OverallBoardStats Summary;		///< Summary of board failures
	struct GenBoardStats1 S1;
	struct GenBoardStats2 S2;

	//	Board History
	struct IOStats CommonStats;	///< Stats common to all I/O boards
};

struct AIChannelStatus {
	USHORT ChanFactoryCaled :1;		///< Channel has been factory calibrated
	USHORT ChanUserCaled :1;		///< Channel has been user calibrated

	USHORT AcqFailed :1;		///< ADC acqusition failed
	USHORT LostReading :1;		///< Channel reading lost
	USHORT ReadingFailed :1;		///< Channel reading failed
	USHORT RTCompFailed :1;		///< RT Comp not available
	USHORT RTCalFailed :1;		///< RT Cal not available

	USHORT RTCompRqd :1;		///< RT Comp reading required
	USHORT RTCalRqd :1;		///< RT Cal reading required
	USHORT ActiveBurnRqd :1;		///< Read the active burnout status required

	USHORT RTCompOverdue :1;		///< RT Comp reading overdue
	USHORT RTCalOverdue :1;		///< RT Cal reading overdue
	USHORT ReadingOverdue :1;		///< Channel reading failed
};

typedef struct _IOBoardTimeSync {
	USHORT IOQueueSyncTime;	///< Time of queue sync (in I/O card ticks)
	LONGLONG SysQueueSyncTime;	///< Time of queue sync (in system time)
} T_IOTIMESYNC, *T_PIOTIMESYNC;

typedef struct AIChannelStats {
	T_IOTIMESYNC QueueTS;			///< Queue time sync
	USHORT LastCardTS;			///< Last card timestamp for this reading batch
	USHORT NoOfReadings;		///< Number of readings obtained in this batch
	USHORT FirstCardTS;		///< First card timestamp for this reading batch
	USHORT PPQSysChan;			///< The system analogue/pulse channel number
	ULONG LostTimeTicks;		///< Time ticks from I/O board due to time loss
	ULONG GainTimeTicks;		///< Time ticks from I/O board due to time gain
	ULONG RTCalFailures;		///< Total number of RT cal errors (note errors will increase if I/P O/C)
	ULONG RTCompFailures;		///< Total number of RT comp errors (note errors will increase if I/P O/C)
	ULONG MissedReadings;		///< Total number of readings lost
	ULONG RepeatedReadings;	///< Total number of repeated readings
	ULONG TotalTransfers;		///< Total number of AI data transfers to date
	ULONG UnprocedCoverage;	///< Unprocessed coverage of chanel
	ULONG UserCalDate;	///< Date returned from AI card when last user calibration was performed
	UCHAR PPQOpStatus;		///< Current PPQ operational status
} AI_CHAN_STATS;

typedef struct AOChannelStats {
	float chanmA;			///< The mA currently being output by an AO channel
	BOOL OP_OC;				///< TRUE if O/P is O/C
} AO_CHAN_STATS;

typedef enum {
	WIRING_FAILED = 0,				///< Active burnout wiring test has been tested and failed
	WIRING_OK,		///< Active burnout wiring test has been tested and passed
	WIRING_NOT_TESTED		///< Active burnout wiring test is yet to be tested
} BRNOUT_WIRING_STATUS;

typedef struct ActiveBurnoutAIChannelStatus {
	BRNOUT_WIRING_STATUS WiringState;		///< T/C wiring status
	CInputConditioning::IO_BURNOUT_STATUS Status;		///< T/C burnout status
} ACTIVE_BURNOUT_STAT;

struct AIBoardStatus {
	USHORT CJCFailed :1;		///< CJC has not returned a valid reading
	USHORT CJCIFFailed :1;		///< The RS232 interface has failed to communicate with CJ device.
};

struct AIOverallStats {
	USHORT FatalError :1;	///< Fatal error has occurred during communication
	USHORT Warning :1;	///< A problem with one or more readings has occurred
};

typedef struct messagefailurelog {
	UCHAR failCount :6;	///< Number of times failure has occurred (max count 64)
	UCHAR exceededLogged :1;	///< Has the fact that a great number of errors been logged
} T_MESS_FAIL_LOG;

const UCHAR MAX_ERRORS = 255;	///< Maximum number of different error codes returned from I/O card

/// Defines to sequence error codes.
/// First location is for errors returned as part of command i.e. no parameters available
const USHORT ERR_HW_ID_CHECK_ERR_COUNT = 13 + 1;
const USHORT ERR_HW_ID_CHECK_START = 0;
const USHORT ERR_HW_ID_CHECK_END = ERR_HW_ID_CHECK_START + ERR_HW_ID_CHECK_ERR_COUNT;

const USHORT ERR_HW_OTHER_CHECK_ERR_COUNT = 5 + 1;
const USHORT ERR_HW_OTHER_CHECK_START = ERR_HW_ID_CHECK_END + 1;
const USHORT ERR_HW_OTHER_CHECK_END = ERR_HW_OTHER_CHECK_START + ERR_HW_OTHER_CHECK_ERR_COUNT;

const USHORT ERR_WRITING_VAL_SEQ_COUNT = 11 + 1;
const USHORT ERR_WRITING_VAL_ERR_COUNT = (ERR_WRITING_VAL_SEQ_COUNT + (6 * HW_ANA_IN_CHAN_PER_BOARD));
const USHORT ERR_WRITING_VAL_START = ERR_HW_ID_CHECK_END + 1;
const USHORT ERR_WRITING_VAL_END = ERR_WRITING_VAL_START + ERR_WRITING_VAL_ERR_COUNT;

const USHORT ERR_ARGS_INVALID_SEQ_COUNT = 6 + 1;
const USHORT ERR_ARGS_INVALID_ERR_COUNT = (ERR_ARGS_INVALID_SEQ_COUNT + (2 * HW_ANA_IN_CHAN_PER_BOARD));
const USHORT ERR_ARGS_INVALID_START = ERR_WRITING_VAL_END + 1;
const USHORT ERR_ARGS_INVALID_END = ERR_ARGS_INVALID_START + ERR_ARGS_INVALID_ERR_COUNT;

const USHORT ERR_RD_CONFIG_FAILED_ERR_COUNT = 4 + 1;
const USHORT ERR_RD_CONFIG_FAILED_START = ERR_ARGS_INVALID_END + 1;
const USHORT ERR_RD_CONFIG_FAILED_END = ERR_RD_CONFIG_FAILED_START + ERR_RD_CONFIG_FAILED_ERR_COUNT;

const USHORT ERR_WR_CONFIG_FAILED_SEQ_COUNT = 19 + 1;
const USHORT ERR_WR_CONFIG_FAILED_ERR_COUNT = (ERR_WR_CONFIG_FAILED_SEQ_COUNT + (2 * HW_ANA_IN_CHAN_PER_BOARD));
const USHORT ERR_WR_CONFIG_FAILED_START = ERR_RD_CONFIG_FAILED_END + 1;
const USHORT ERR_WR_CONFIG_FAILED_END = ERR_WR_CONFIG_FAILED_START + ERR_WR_CONFIG_FAILED_ERR_COUNT;

const USHORT ERR_RD_NV_FAILED_ERR_COUNT = 8 + 1;
const USHORT ERR_RD_NV_FAILED_START = ERR_WR_CONFIG_FAILED_START + 1;
const USHORT ERR_RD_NV_FAILED_END = ERR_RD_NV_FAILED_START + ERR_RD_NV_FAILED_ERR_COUNT;

const USHORT ERR_WR_NV_FAILED_ERR_COUNT = 22 + 1;
const USHORT ERR_WR_NV_FAILED_START = ERR_RD_NV_FAILED_END + 1;
const USHORT ERR_WR_NV_FAILED_END = ERR_WR_NV_FAILED_START + ERR_WR_NV_FAILED_ERR_COUNT;

const USHORT ERR_WRONG_MODE_ERR_COUNT = 8 + 1;
const USHORT ERR_WRONG_MODE_START = ERR_WR_NV_FAILED_END + 1;
const USHORT ERR_WRONG_MODE_END = ERR_WRONG_MODE_START + ERR_WRONG_MODE_ERR_COUNT;

const USHORT ERR_ADC_SELF_TEST_ERR_COUNT = 8 + 1;
const USHORT ERR_ADC_SELF_TEST_START = ERR_WRONG_MODE_END + 1;
const USHORT ERR_ADC_SELF_TEST_END = ERR_ADC_SELF_TEST_START + ERR_ADC_SELF_TEST_ERR_COUNT;

const USHORT ERR_LOST_DATA_ERR_COUNT = 8 + 1;
const USHORT ERR_LOST_DATA_START = ERR_ADC_SELF_TEST_END + 1;
const USHORT ERR_LOST_DATA_END = ERR_LOST_DATA_START + ERR_LOST_DATA_ERR_COUNT;

const USHORT ERR_INVALID_STATE_ERR_COUNT = 9 + 1;
const USHORT ERR_INVALID_STATE_START = ERR_LOST_DATA_END + 1;
const USHORT ERR_INVALID_STATE_END = ERR_INVALID_STATE_START + ERR_INVALID_STATE_ERR_COUNT;

const USHORT ERR_NO_CAN_DO_SEQ_COUNT = 8 + 1;
const USHORT ERR_NO_CAN_DO_ERR_COUNT = (ERR_NO_CAN_DO_SEQ_COUNT + (4 * HW_ANA_IN_CHAN_PER_BOARD));
const USHORT ERR_NO_CAN_DO_START = ERR_INVALID_STATE_END + 1;
const USHORT ERR_NO_CAN_DO_END = ERR_NO_CAN_DO_START + ERR_NO_CAN_DO_ERR_COUNT;
const USHORT PARAM_X_START = ERR_NO_CAN_DO_START + ERR_NO_CAN_DO_SEQ_COUNT;
const USHORT PARAM_X_END = PARAM_X_START + HW_ANA_IN_CHAN_PER_BOARD;
const USHORT PARAM_Y_START = PARAM_X_END + 1;
const USHORT PARAM_Y_END = PARAM_Y_START + HW_ANA_IN_CHAN_PER_BOARD;

const USHORT ERR_CJC_DRIVER_ERR_COUNT = 6 + 1;
const USHORT ERR_CJC_DRIVER_START = ERR_NO_CAN_DO_END + 1;
const USHORT ERR_CJC_DRIVER_END = ERR_CJC_DRIVER_START + ERR_CJC_DRIVER_ERR_COUNT;

const USHORT BUSY_PROCESSING_MSG_ERR_COUNT = 3 + 1;
const USHORT BUSY_PROCESSING_MSG_START = ERR_CJC_DRIVER_END + 1;
const USHORT BUSY_PROCESSING_MSG_END = BUSY_PROCESSING_MSG_START + BUSY_PROCESSING_MSG_ERR_COUNT;

const USHORT ERR_ADC_ENABLE_ERR_COUNT = 2 + 1;
const USHORT ERR_ADC_ENABLE_START = BUSY_PROCESSING_MSG_END + 1;
const USHORT ERR_ADC_ENABLE_END = ERR_ADC_ENABLE_START + ERR_ADC_ENABLE_ERR_COUNT;

const USHORT ERR_FACT_CAL_ERR_COUNT = 2 + 1;
const USHORT ERR_FACT_CAL_START = ERR_ADC_ENABLE_END + 1;
const USHORT ERR_FACT_CAL_END = ERR_FACT_CAL_START + ERR_FACT_CAL_ERR_COUNT;

const USHORT ERR_USER_CAL_ERR_COUNT = 2 + 1;
const USHORT ERR_USER_CAL_START = ERR_FACT_CAL_END + 1;
const USHORT ERR_USER_CAL_END = ERR_USER_CAL_START + ERR_USER_CAL_ERR_COUNT;

const USHORT ERR_NV_CRC_COUNT = 2 + 1;
const USHORT ERR_NV_CRC_START = ERR_USER_CAL_END + 1;
const USHORT ERR_NV_CRC_END = ERR_NV_CRC_START + ERR_NV_CRC_COUNT;

const USHORT ERR_MASTER_SPI_COUNT = 2 + 1;
const USHORT ERR_MASTER_SPI_START = ERR_NV_CRC_END + 1;
const USHORT ERR_MASTER_SPI_END = ERR_MASTER_SPI_START + ERR_MASTER_SPI_COUNT;

const USHORT ERR_ADC_CHANS_INIT_SEQ_COUNT = 5 + 1;
const USHORT ERR_ADC_CHANS_INIT_COUNT = (ERR_ADC_CHANS_INIT_SEQ_COUNT + (3 * HW_ANA_IN_CHAN_PER_BOARD));
const USHORT ERR_ADC_CHANS_INIT_START = ERR_MASTER_SPI_END + 1;
const USHORT ERR_ADC_CHANS_INIT_END = ERR_MASTER_SPI_START + ERR_ADC_CHANS_INIT_COUNT;

#define ERROR_REPORT_NONE			0
#define ERROR_REPORT_SINGLE			1
#define ERROR_REPORT_MANY			5
#define ERROR_REPORT_CONTINUOUS		20

typedef enum {
	EERS_NO_REPORT_RQD, EERS_REPORT_FIRST, EERS_REPORT_MANY, EERS_REPORT_CONTINUOUS
} E_ERROR_REPORT_STAT;

typedef enum {
	EERT_AP8_DRIVER, EERT_IO_READING_FAILURE, EERT_NON_PARAMETERISED, EERT_PARAMETERISED
} E_ERROR_TYPE;

#define IO_READING_CHAN_LOG		(IO_READING_ERROR_COUNT * TOPSLOT_AICHAN_SIZE)

struct BrdStatus {
	union BoardStats BrdSpecificHistory;		///< I/O board specific history
	USHORT AOFailureCount;	///< Number of AO failures downloaded from the board

	// AI board and channel status
	struct AIOverallStats StatSummary;				///< Board failure summary
	struct GenBoardStatus GenStat;				///< Board common board stats
	struct AIBoardStatus AIStat;					///< AI specific board stats
	struct AIChannelStatus ChanStat[TOPSLOT_AICHAN_SIZE];					///< AI specific channel stats
	AI_CHAN_STATS ChanStatMonitor[TOPSLOT_AICHAN_SIZE];	///< More AI specific stats
	AO_CHAN_STATS AOStats[TOPSLOT_AOCHAN_SIZE];	///< AO specific channel stats
	ACTIVE_BURNOUT_STAT ChanBrnSat[TOPSLOT_AICHAN_SIZE];	///< AI burnout specific stats

	// Failure message log failure status
	T_MESS_FAIL_LOG IOreading[IO_READING_CHAN_LOG];	///< I/O card reading failure log
	T_MESS_FAIL_LOG serialised[ERR_ADC_CHANS_INIT_END + 1];	///< Channel & parameter notified failures
	T_MESS_FAIL_LOG singleFail[MAX_ERRORS + 1];	///< I/O card specific failures that do not have a code or channel number
	T_MESS_FAIL_LOG AP8Failure[AP8_IOCARD_ERROR_COUNT + 1];	///< AP8 I/O card interface specific failures - Only on Rev C processor boards

	ULONG FactoryCalDate;				///< AI card Factory calibration date
	UCHAR rigID;						///< AI card Factory calibration rig ID
};

#endif

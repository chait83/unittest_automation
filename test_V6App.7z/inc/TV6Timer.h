/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	Utilties
/// @n Filename: TV6Timer.h
/// @n Desc:	Routines to provide timing, bioth std (mSec) and 
///				high performance (uSec)
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 7	Stability Project 1.4.1.1	7/2/2011 5:02:13 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 6	Stability Project 1.4.1.0	7/1/2011 4:27:08 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 5	V6 Firmware 1.4		9/23/2008 3:09:34 PM	Build Machine 
//		AMS2750 Merge
// 4	V6 Firmware 1.3		6/21/2006 3:17:15 PM	Andy Kassell	Add
//		rollover code to normal resolution timer
// $
//
// ****************************************************************

#ifndef __TV6TIMER_H__
#define __TV6TIMER_H__
#include "Defines.h"
#define MAX_LONGLONG		0x7FFFFFFFFFFFFFFF		///< Max LONGLONG

typedef enum timerRes {
	TIMER_HIGH_RES,					///< High reolution timer, results in uSec
	TIMER_NORMAL_RES			///< Normal resolution timer, results in mSec
} T_TIMER_RESOLUTION;

typedef enum timerTypes {
	TIMER_BASE = 0,						///< Baseline time
	TIMER_SINGLE,						///< Standard Timer
	TIMER_MAX,						///< Max Timer, performed on single timer
	TIMER_MIN,						///< Min Timer, performed on single timer
	TIMER_SPLIT1,						///< Split time 1	
	TIMER_SPLIT2,						///< Split time 2	
	TIMER_SPLIT3,						///< Split time 3	
	TIMER_SPLIT4,						///< Split time 4	
	TIMER_SPLIT5,						///< Split time 5
	TIMER_TOTAL_TIMERS					///< Total number of timers
} T_TIMER_TYPE;

//**Class*********************************************************************
///
/// @brief TV6Timer class, prviding timer routines
/// 
/// This class will provide methods to perform acurate timing within the system
/// be it delays, profiling, timeouts etc.. Using the High performance timers
/// within CE provided by the V6 Target this will achive uSec resolution.
/// 
///
//****************************************************************************
class CTV6Timer {
public:

	CTV6Timer(T_TIMER_RESOLUTION type);

	void ResetAllTimers();
	void ResetMaxMin();
	void StartTimer();
	void StopTimer();
	LONGLONG GetTimeInMilliSec(T_TIMER_TYPE timer);
	LONGLONG GetTimeInMicroSec(T_TIMER_TYPE timer);
	BOOL SetSplitTime(T_TIMER_TYPE splitTimer);
	void TraceTimer(char *pTimerName);

	LONGLONG ElapsedTimeInMicroSeconds();
	LONGLONG ElapsedTimeInMilliSeconds();

	LONGLONG RecordedTimeInMicroSeconds();
	LONGLONG RecordedTimeInMilliSeconds();

private:	// Methods
	DWORD GetTickCount();
	LONGLONG GetTimeOffSetFromBase();

private:	// Member variables

	ULONG m_clockFreq;	///< Clock Frequency queried for High Performance timers
	LARGE_INTEGER m_timer[TIMER_TOTAL_TIMERS];	///< usable timers, see T_TIMER_TYPE for timer info
	T_TIMER_RESOLUTION m_Type;	///< Timer type, High res uSec or Normal mSec

	double m_milliSecGearing;	///< Gearing for straight High perf clock to millisecond divide
	double m_microSecGearing;	///< Gearing for straight High perf clock to microsecond divide

	LARGE_INTEGER m_theTime;						///< ongoing timer
	DWORD m_LastTickTime;							///< Time of last tick count

	BOOL m_Running;					///< Flag to indicate if timer is running

};

void TestTV6Timer(void);

#endif //__TV6TIMER_H__


/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Battery
/// @n Filename: RTCSyncThread.h
/// @n Desc:	 To Sync External RTC time 
///				 
///
// ***********************************************************************
// Revision History
// 
//	Sowmya Pothuri 12/Feb/2021 external RTC time to sync with internal time
// ***********************************************************************

#ifndef __RTC_SYNC_THREAD_H__
#define __RTC_SYNC_THREAD_H__

#include "TV6Timer.h"
#include "V6globals.h"

#define DBG_FILE_LOG_RTCSYNC_THREAD_ENABLE 0

#ifdef DBG_FILE_LOG_RTCSYNC_THREAD_ENABLE
#include "CStorage.h"
#endif

#define SYNC_RTC_TIME_IN_MILLI_SEC (3*60)*1000 //time to sync 

//**Class*********************************************************************
///
/// @brief To Sync external RTC time to internal time in recorder
/// 
/// This class is a singleton.
///
//****************************************************************************
class CRTCSyncThread: public QThread {

public:		//Singleton 
	static CRTCSyncThread* GetHandle();
	void CleanUp();

	CRTCSyncThread();
	~CRTCSyncThread();	// Will never be called
	CRTCSyncThread(const CRTCSyncThread&);
	CRTCSyncThread& operator=(const CRTCSyncThread&) {
		return *this;
	}
	;

protected:

public:	// API methods

	// Initialise and shutdown of device abstraction
	void Initialise();
	int ReadRTCAndSyncTime();

#ifdef DBG_FILE_LOG_RTCSYNC_THREAD_ENABLE
	void LogDebugMessage(QString  strDebugMessage);
	void SetDebugLogger(CDebugFileLogger *pDbgFileLogger);
#endif

#ifdef DBG_FILE_LOG_RTCSYNC_THREAD_ENABLE
	static CDebugFileLogger m_debugFileLogger;
	CDebugFileLogger *m_pDebugFileLogger;
#endif

private:	// Methods

protected:

private:	// Member variables
	static CRTCSyncThread *m_pRTCManInstance;
	static HANDLE m_CreationMutex;

	CTV6Timer m_RCTimer;

public:
	//Public memebers
};

#endif


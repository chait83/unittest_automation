/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 UI Control
/// @n Filename:  SelectionDlg.h
/// @n Description: Definition for the CSelectionDlg class, custom colour 
///		pallete
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  8   Stability Project 1.5.1.1   7/2/2011 5:01:14 PM   Hemant(HAIL) 
//     Stability Project: Recorder source has been upgraded from IL
//    version of firmware to JF version of firmware.
//  7   Stability Project 1.5.1.0   7/1/2011 4:27:41 PM   Hemant(HAIL) 
//     Stability Project: Files has been checked in before the merging
//    task. The merging will be done between IL version of firmware and JF
//    version of firmware. 
//  6   V6 Firmware 1.5     1/9/2007 8:17:15 PM   Roger Dawson  
//    Added a border to the dialog when being displayed on MultiTrend's.
//  5   V6 Firmware 1.4     10/21/2005 8:20:41 PM  Roger Dawson  
//    Further multiplus size tweaks.
// $
//
// **************************************************************************

#if !defined(AFX_SELECTIONDLG_H__586D1E7C_366D_437A_9B45_005C4338657A__INCLUDED_)
#define AFX_SELECTIONDLG_H__586D1E7C_366D_437A_9B45_005C4338657A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Colourpicker.h"
#include "ColorBox.h"
#include "ColorTabCtrl.h"
#include "CustomSlider.h"		//custom slider control

#include "V6BitmapButton.h"
#include "V6ResourceBase.h"
#include "V6UIResource.h"

/////////////////////////////////////////////////////////////////////////////
// CSelectionDlg dialog
//******************************************************
// CSelectionDlg
///
/// @brief class implements the colour picker dialog
///
//******************************************************
class CSelectionDlg: public QDialog //QDialog
{
// Construction
public:
	void EditColourValue(colour btnselected);
	void GetNewColour(COLORREF &newcolour);
	void SetCurrentColour(COLORREF color);
	void UpdateColour();
	CSelectionDlg(CWidget *pParent = NULL);  // standard constructor
	COLORREF m_AllRecentColors[MAX_COLORS];
	COLORREF m_NewColorValue;
	COLORREF m_CurrentColorValue;
	BOOL SetNewColor(COLORREF color);

	// Dialog Data
	//{{AFX_DATA(CSelectionDlg)
	enum {
		IDD = IDD_COLOUR_DLG
	};
	CV6BitmapButton m_kNewLabel;
	CV6BitmapButton m_kCurrLabel;
	CV6BitmapButton m_kRedLabelBtn;
	CV6BitmapButton m_kGreenLabelBtn;
	CV6BitmapButton m_kBlueLabelBtn;
	CV6BitmapButton m_kRedBtn;
	CV6BitmapButton m_kGreenBtn;
	CV6BitmapButton m_kBlueBtn;
	CV6BitmapButton m_cancel;
	CV6BitmapButton m_ok;
	CColorTabCtrl m_TabColors;
	CCustomSlider m_SliderB;
	CCustomSlider m_SliderG;
	CCustomSlider m_SliderR;
	CColorBox m_CurrentColor;
	CColorBox m_NewColor;
	int m_SliderR_Value;
	int m_SliderG_Value;
	int m_SliderB_Value;
	//}}AFX_DATA

	COLORREF m_defultcolour;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSelectionDlg)
protected:
	virtual void DoDataExchange(CDataItem *pDX);  // DDX/DDV support
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL
	//virtual BOOL OnInitDialog();

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSelectionDlg)
	afx_msg
	void OnPaint();
	virtual void OnOK();
	virtual BOOL OnInitDialog();afx_msg
	void OnButtonB();afx_msg
	void OnButtonG();afx_msg
	void OnButtonR();afx_msg
	void OnCurrentColor();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	/// Font for the tab control
	CFont m_kFont;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SELECTIONDLG_H__586D1E7C_366D_437A_9B45_005C4338657A__INCLUDED_)

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  Control Sequencer
/// @n Filename:  SelfTest.h
/// @n Description: Class Declaration for Self Test
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  3 Stability Project 1.0.1.1 7/2/2011 5:01:15 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  2 Stability Project 1.0.1.0 7/1/2011 4:26:30 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  1 V6 Firmware 1.0 10/7/2004 8:15:14 PM  Alistair Brugsch 
// $
//

#ifndef _SELFTEST_H
#define _SELFTEST_H

/// Return Values for CSelfTest Member Functions, used to describe the type of 
/// success or failure.
//
typedef enum _eSelfTestReturnValue {
	SELFTEST_OK, SELFTEST_ERROR,

} T_SELFTEST_RETURN_VALUE;

//**Class*********************************************************************
///
/// @brief Carries out the action required for self test mode for the recorder
/// 
/// This class encapsulates all the functionality that is required for the Control
/// Sequencer to undertake when operating in Self-Test Mode. 
//****************************************************************************

class CSelfTest {
public:

	// Constructor
	CSelfTest(void);

	// Destructor
	virtual ~CSelfTest(void);

	// Carries out the associated actions for self test
	T_SELFTEST_RETURN_VALUE PerformSelfTest(void);

};
// End of Class Declaration

#endif // _SELFTEST_H

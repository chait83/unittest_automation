/// @file 
/// ****************************************************************
/// Ã¯¿½ Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Control Sequencer
/// @n Filename: NormalOperation.cpp
/// @n Desc: Handler for Normal operation in control sequence
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  55  Aristos  1.49.1.3.1.0 9/19/2011 4:51:11 PM  Hemant(HAIL)  
//  Stability recorder source code (JI Release) updated for WatchDog
//  Timer functionality.
//  54  Stability Project 1.49.1.3 7/2/2011 4:59:06 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  53  Stability Project 1.49.1.2 7/1/2011 4:38:32 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  52  Stability Project 1.49.1.1 3/17/2011 3:20:31 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
// $
//
// ****************************************************************

#include "NormalOperation.h"
#include "ModuleConstants.h"
#include "ModuleMsgManagerClient.h"
#include "SystemConfiguration.h"
#include "TraceDefines.h"
#include "V6globals.h"
#include "ATECal.h"
#include "ppl.h"

#include "LayoutConfiguration.h"
#include "IOScheduler.h"
#include "LCMGlobal.h"
#include "CLoggerModule.h"
#include "OpPanelIncludes.h"
//#include "V6MessageBoxDlg.h"
#include "SMTPThread.h"
#include "RecSetupCfgMgr.h"
#include "ScrnDesCfgMgr.h"
#include "TopStatusBar.h"
#include "ThreadInfo.h"

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif

//****************************************************************************
/// Class Constructor
//****************************************************************************
CNormalOperation::CNormalOperation(class CSystemConfiguration &systemConfiguration,
		class CV6ActiveModuleServices &activeModuleServices) : m_SystemConfiguration(systemConfiguration), m_AModSer(
		activeModuleServices) {

	m_InNormalOperation = FALSE;	// Not in normal operation yet

} // End of Constructor

//****************************************************************************
/// Class Destructor
//****************************************************************************
CNormalOperation::~CNormalOperation(void) {
} // End of Destructor

//****************************************************************************
/// This member funciton is called when a message is required to be processed,
/// from the Control Sequencer Message Queue. This function analysing the
/// messages and undertakes the required action on the system. The function
/// returns a value that specifies whether the operational state of the Control
/// Sequencer has to be changed, followed by a system restart, or a system restart
/// is required within an operational state change. 
/// 
/// @param[in] ctrlSeqMessageQueue - A Reference to the Control Sequencer MMM Client
///
/// @return NORMALOP_NORMAL_OPERATION - Continue with Normal Operation
/// @n  NORMALOP_CHANGE_STATE_TO_NORMAL_OP - Change operational state to Normal Operation
/// @n  NORMALOP_CHANGE_STATE_TO_SELF_TEST - Change operational state to Self Test
/// @n  NORMALOP_RESTART_SYSTEM - Restart of the System Required, no Operational State Change
/// 
//****************************************************************************
T_NORMALOP_RETURN_VALUE CNormalOperation::ProcessMessage(CModuleMsgManagerClient &ctrlSeqMessageQueue) {
	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//for the ControlSequencer thread
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	if (pThreadInfo != NULL) {
		pThreadInfo->UpdateThreadCounter(AM_CTRLSEQUENCER);
	}

	// const CMsgQueueMessage * const pMsg = NULL; // Message from the Control Sequencer Message Queue
	T_NORMALOP_RETURN_VALUE retValue = NORMALOP_NORMAL_OPERATION; // Member Function return value

	// Read Message from the Message Queue
	//pMsg = ctrlSeqMessageQueue.MMMClientReadMsg();
	const CMsgQueueMessage *const pMsg = ctrlSeqMessageQueue.MMMClientReadMsg();

	switch (pMsg->m_MessageType) {
	case MOD_SYSTEM_SHUTDOWN:
		retValue = ProcessSystemShutdown();
		break;
	case MOD_SELF_TEST:
		retValue = ProcessSelfTest();
		break;
	case MOD_END_SELF_TEST:
		retValue = EndSelfTest();
		break;
	case MOD_ENTER_CAL_MODE:
		retValue = ProcessEnterCalMode();
		break;
	case MOD_CONFIG_CHANGE: {
		retValue = ProcessConfigChange((T_PMOD_CFG_CHG_MSGDATA) (pMsg->m_MsgData));
		break;
	}
	default:
		LOG_ERR( TRACE_CTRL_SEQUENCER, "ProcessMessage - ERROR");
		break;

	} // End of Switch 

	if (pThreadInfo != NULL) {
		pThreadInfo->UpdateThreadCounter(AM_CTRLSEQUENCER);
	}

	// Remove the read message from the Control Sequencer Message Queue
	ctrlSeqMessageQueue.MMMClientRemoveMsg();

	return (retValue);

} // End of ProcessMessage()

//*****************************************************************************
// Private Member Functions
//*****************************************************************************

T_NORMALOP_RETURN_VALUE CNormalOperation::ApplyConfigChange(const T_MOD_CFG_CHG_MSGDATA *const configChangeMsgData) {
	T_NORMALOP_RETURN_VALUE retValue = NORMALOP_ERROR; // Member Function Return Value

	switch (configChangeMsgData->TypeOfConfigChange) {
	case MOD_CFG_CHG_SETUP:

		switch (configChangeMsgData->ConfigChangeAction) {
		case MOD_CFG_CHG_ACTION_UPDATE:

			if (CONFIG_OK == m_SystemConfiguration.PerformSetupConfigAction(SYSCONFIG_UPDATE_CONFIG)) {
				if (m_SystemConfiguration.GetCurrentSetupConfig()->IsResetRequired() == TRUE) {
					retValue = NORMALOP_RESTART_SYSTEM;
				} else {
					retValue = NORMALOP_OK;
				}

			} // End of IF

			break;

		case MOD_CFG_CHG_ACTION_LOAD_NEW:

			if (CONFIG_OK
					== m_SystemConfiguration.PerformSetupConfigAction(SYSCONFIG_LOAD_CONFIGURATION,
							configChangeMsgData->fileNameAndPath)) {
				retValue = NORMALOP_OK;

#ifndef V6IOTEST
				CRecSetupCfgMgr *pkInstance = CRecSetupCfgMgr::Instance();
				pkInstance->SetModified(false);
#endif

			} // End of IF

			break;

		default:
			retValue = NORMALOP_ERROR;
			break;

		} // End of Switch 

		break;

	case MOD_CFG_CHG_PASSWORD:
		m_SystemConfiguration.PerformPasswordUpdate();
		break;

	case MOD_CFG_CHG_LAYOUT:

		switch (configChangeMsgData->ConfigChangeAction) {
		case MOD_CFG_CHG_ACTION_UPDATE:

			if (CONFIG_OK == m_SystemConfiguration.PerformLayoutConfigAction(SYSCONFIG_UPDATE_CONFIG)) {
				retValue = NORMALOP_OK;

			} // End of IF

			break;

		case MOD_CFG_CHG_ACTION_LOAD_NEW:

			if (CONFIG_OK
					== m_SystemConfiguration.PerformLayoutConfigAction(SYSCONFIG_LOAD_CONFIGURATION,
							configChangeMsgData->fileNameAndPath)) {
				retValue = NORMALOP_OK;
#ifndef V6IOTEST
				// reset the modified flag
				CScrnDesCfgMgr *pkInstance = CScrnDesCfgMgr::Instance();
				pkInstance->SetModified(false);
#endif  
			} // End of IF

			break;

		default:
			retValue = NORMALOP_ERROR;
			break;

		} // End of Switch 

		break;

	default:
		retValue = NORMALOP_ERROR;
		break;

	} // End of Switch

	return (retValue);

} // End of Member Function

//****************************************************************************
/// Send out a message preparing the system for a configuration change
/// 
/// @param[in] configChangeType - Configuration change type
///
/// @return T_NORMALOP_RETURN_VALUE 
/// 
//****************************************************************************
T_NORMALOP_RETURN_VALUE CNormalOperation::PrepareForConfigChange(const T_MOD_CFG_CHG_TYPE configChangeType) {
	T_V6AMSER_ACTIVE_MODULES activeModule = V6AMSER_IO_SCHEDULER;

	GlbAppStateSema = APPACCESS_LOCKED;		// Indicate to V6AppInterface that the system is not safe to access

	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//for the ControlSequencer thread
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();

	for (USHORT activeModuleIndex = 0; activeModuleIndex < V6AMSER_NUM_OF_ACTIVE_MODULES; ++activeModuleIndex) {

		if (pThreadInfo != NULL) {
			pThreadInfo->UpdateThreadCounter(AM_CTRLSEQUENCER);
		}
		activeModule = static_cast<T_V6AMSER_ACTIVE_MODULES>(activeModuleIndex);

		m_AModSer.GetActiveModule(activeModule).PrepareForConfigChange(configChangeType);
	}

	m_InNormalOperation = FALSE;	// We are no longer in normal operation.

#ifndef V6IOTEST	
	if (configChangeType != MOD_CFG_CHG_PASSWORD) {
		((COpPanel*) (AfxGetApp()->m_pMainWnd))->m_pV6Module->SetupConfigChangePreparation();
	}
#endif 

	return (NORMALOP_OK);

} // End of Member Function

//****************************************************************************
/// Send out a message confirming a change has been completed 
/// 
/// @param[in] configChangeType - Configuration change type
///
/// @return T_NORMALOP_RETURN_VALUE 
/// 
//****************************************************************************
T_NORMALOP_RETURN_VALUE CNormalOperation::ConfigChangeComplete(const T_MOD_CFG_CHG_TYPE configChangeType) {
	T_NORMALOP_RETURN_VALUE retValue = NORMALOP_OK;

	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//for the ControlSequencer thread
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();

	pGlbDIT->ApplyConfig();		// Apply config change to Data Item Table

	T_V6AMSER_ACTIVE_MODULES activeModule = V6AMSER_IO_SCHEDULER;

	for (USHORT activeModuleIndex = 0; activeModuleIndex < V6AMSER_NUM_OF_ACTIVE_MODULES; ++activeModuleIndex) {
		if (pThreadInfo != NULL) {
			pThreadInfo->UpdateThreadCounter(AM_CTRLSEQUENCER);
		}

		activeModule = static_cast<T_V6AMSER_ACTIVE_MODULES>(activeModuleIndex);

		if (m_AModSer.DoesActiveModuleExist(activeModule))
			m_AModSer.GetActiveModule(activeModule).ConfigChangeComplete(configChangeType);

	} // End of FOR

#ifndef V6IOTEST	

	if (configChangeType == MOD_CFG_CHG_LAYOUT) {
		// for layouts, set the new layout
		//((COpPanel*)(AfxGetApp()->m_pMainWnd))->SetConfiguration(m_SystemConfiguration.GetCurrentLayoutConfig(),TRUE)

		// instead, post the new layout to OpPanel (safer)
		((COpPanel*) (AfxGetApp()->m_pMainWnd))->PostMessage(WM_OPPANEL_SETCONFIGURATION,
				(WPARAM) m_SystemConfiguration.GetCurrentLayoutConfig(), TRUE);
	} else if (configChangeType == MOD_CFG_CHG_SETUP) {
		//((COpPanel*)(AfxGetApp()->m_pMainWnd))->m_pV6Module->SetupConfigChangeComplete();
		((COpPanel*) (AfxGetApp()->m_pMainWnd))->PostMessage(WM_OPPANEL_CONFIGCHANGECOMPLETE, 0, 0);
	}

#endif 		

	GlbAppStateSema = APPACCESS_OK;		// Indicate to V6AppInterface that the system is not safe to access

	return (retValue);

} // End of Member Function

//****************************************************************************
/// Send out a message to perform a system action
/// 
/// @param[in] systemAction - action, norma operation or a shutdown
///
/// @return T_NORMALOP_RETURN_VALUE 
/// 
//****************************************************************************
T_NORMALOP_RETURN_VALUE CNormalOperation::PerformSystemAction(const T_MOD_SYS_CFG_CHG_ACTION systemAction) {
	T_NORMALOP_RETURN_VALUE retValue = NORMALOP_NORMAL_OPERATION;

	if (MOD_SYS_CFG_CHG_NORMAL_OPERATION == systemAction) {
		NormalOperation();
	} else {
		retValue = NORMALOP_RESTART_SYSTEM;
	} // End of IF

	return (retValue);

} // End of Member Function

//****************************************************************************
/// Activate normal operation
///
/// @return T_NORMALOP_RETURN_VALUE 
/// 
//****************************************************************************
T_NORMALOP_RETURN_VALUE CNormalOperation::NormalOperation(void) {
	T_NORMALOP_RETURN_VALUE retValue = NORMALOP_OK;
	T_V6AMSER_ACTIVE_MODULES activeModule = V6AMSER_IO_SCHEDULER;

	for (USHORT activeModuleIndex = 0; activeModuleIndex < V6AMSER_NUM_OF_ACTIVE_MODULES; ++activeModuleIndex) {
		activeModule = static_cast<T_V6AMSER_ACTIVE_MODULES>(activeModuleIndex);

		if (m_AModSer.DoesActiveModuleExist(activeModule)) {
			if (V6ACTMOD_ACTION_NOT_PERFORMED == m_AModSer.GetActiveModule(activeModule).PerformNormalOperation()) {
				retValue = NORMALOP_ERROR;
				LOG_ERR(TRACE_CTRL_SEQUENCER, "Module %d did not respond to Normal Operation", activeModuleIndex);

			}
		}
	}

	m_InNormalOperation = TRUE;		// Set we are now in Normal operation

	return (retValue);
}

//****************************************************************************
/// Sequence a configuration change
/// 
/// @param[in] configChangeType - Configuration change type
///
/// @return T_NORMALOP_RETURN_VALUE 
/// 
//****************************************************************************
T_NORMALOP_RETURN_VALUE CNormalOperation::ProcessConfigChange(const T_MOD_CFG_CHG_MSGDATA *const configChangeMsgData) {
	T_NORMALOP_RETURN_VALUE configApplyAction;

	// Step 1: Prepare the System for Configuration Change
	PrepareForConfigChange(configChangeMsgData->TypeOfConfigChange);

	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//for the ControlSequencer thread
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	if (pThreadInfo != NULL) {
		pThreadInfo->UpdateThreadCounter(AM_CTRLSEQUENCER);
		//Set the function pointer for the global function
		//GlbUpdateThreadCount
		SetThreadCounter(GlbUpdateThreadCount);
	}

	// Step 2: Apply the Configuration Change 
	configApplyAction = ApplyConfigChange(configChangeMsgData);

	if (pThreadInfo != NULL) {
		//Update the thread counter for the control sequencer thread
		pThreadInfo->UpdateThreadCounter(AM_CTRLSEQUENCER);
	}

	// Check if the configuration changes requires a system reset
	if (configApplyAction == NORMALOP_RESTART_SYSTEM && pDALGLB->IsRecorderPCorEmbedded()) {
		::PostMessage(AfxGetMainWnd()->m_hWnd, WM_OPPANEL_FORCE_REBOOT, 0, 0);

		// Set shutdown mode and Post shutdown request to OpPanel
		pDALGLB->SetShutDownMode(SHUTDOWN_MODE_CONFIG_CHANGE);

		// Set the action to normal, we don't want anything to happen but let OpPanel shut us down.
		configApplyAction = NORMALOP_OK;
	} else {
		// Step 3: Inform each Module that Configuration Change has been completed
		ConfigChangeComplete(configChangeMsgData->TypeOfConfigChange);

		if (pThreadInfo != NULL) {
			//Update the thread counter for the control sequencer thread
			pThreadInfo->UpdateThreadCounter(AM_CTRLSEQUENCER);
		}

		// Step 4: Carry out the actions required on the system
		configApplyAction = PerformSystemAction(configChangeMsgData->configChangeSystemAction);
	}

	return (configApplyAction);

}

//****************************************************************************
/// Process the system shutdown
///
/// @return T_NORMALOP_RETURN_VALUE 
/// 
//****************************************************************************
T_NORMALOP_RETURN_VALUE CNormalOperation::ProcessSystemShutdown() {
	GlbAppStateSema = APPACCESS_SHUTDOWN;

	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//for the ControlSequencer thread
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	if (pThreadInfo != NULL) {
		//Update the thread counter for the control sequencer thread
		pThreadInfo->UpdateThreadCounter(AM_CTRLSEQUENCER);
	}

	// Step 1: Prepare the System for Shutdown, only if modules currently in normal operation
	if ((m_InNormalOperation == TRUE) || (IsRunningAsATEEquipment() == TRUE)) {
		PrepareForShutdown();
	}

	// Step 2: Inform each module to Shutdown
	ShutdownSystem();

	return (NORMALOP_RESTART_SYSTEM);
}

//****************************************************************************
/// Send a "Prepare for shutdown" to all active modules
///
/// @return T_NORMALOP_RETURN_VALUE 
//****************************************************************************
T_NORMALOP_RETURN_VALUE CNormalOperation::PrepareForShutdown(void) {
	T_V6AMSER_ACTIVE_MODULES activeModule = V6AMSER_IO_SCHEDULER;

	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//for the ControlSequencer thread
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	if (pThreadInfo != NULL) {
		//Update the thread counter for the control sequencer thread
		pThreadInfo->UpdateThreadCounter(AM_CTRLSEQUENCER);
	}
	for (USHORT activeModuleIndex = 0; activeModuleIndex < V6AMSER_NUM_OF_ACTIVE_MODULES; ++activeModuleIndex) {
		activeModule = static_cast<T_V6AMSER_ACTIVE_MODULES>(activeModuleIndex);
		if (m_AModSer.DoesActiveModuleExist(activeModule))
			m_AModSer.GetActiveModule(activeModule).PrepareForShutdown();
		if (pThreadInfo != NULL) {
			//Update the thread counter for the control sequencer thread
			pThreadInfo->UpdateThreadCounter(AM_CTRLSEQUENCER);
		}
	}
	return (NORMALOP_OK);
}

//****************************************************************************
/// Send a "Shutdown" to all active modules
///
/// @return T_NORMALOP_RETURN_VALUE  
//****************************************************************************
T_NORMALOP_RETURN_VALUE CNormalOperation::ShutdownSystem(void) {
	// ----------------------------------------------------------------------------------------------------------
	// Shutdown the thread responsible for daylight saving.....
	//
	// The call to this function has been stopped as the event handling of the DST/SDT is handled by WinCE OS 
	// No need to handle this event through V6App.
	// Also call to the StartDaylightSavingThread() function has been stopped.
	// ----------------------------------------------------------------------------------------------------------
	//ShutdownDaylightSavingThread();	

	ShutdownTimeChangeThread();
	CSMTPThread::ShutdownThread();

	T_V6AMSER_ACTIVE_MODULES activeModule = V6AMSER_IO_SCHEDULER;

	for (USHORT activeModuleIndex = 0; activeModuleIndex < V6AMSER_NUM_OF_ACTIVE_MODULES; ++activeModuleIndex) {
		activeModule = static_cast<T_V6AMSER_ACTIVE_MODULES>(activeModuleIndex);
		if (m_AModSer.DoesActiveModuleExist(activeModule))
			m_AModSer.GetActiveModule(activeModule).PerformShutdown();
	}
	return (NORMALOP_OK);
}

//****************************************************************************

/// Process the self test
///
/// @return T_NORMALOP_RETURN_VALUE 
/// 
//****************************************************************************
T_NORMALOP_RETURN_VALUE CNormalOperation::ProcessSelfTest() {
	return (NORMALOP_OK);
}

//****************************************************************************
/// Exit self test
///
/// @return T_NORMALOP_RETURN_VALUE 
/// 
//****************************************************************************
T_NORMALOP_RETURN_VALUE CNormalOperation::EndSelfTest(void) {
	return (NORMALOP_CHANGE_STATE_TO_NORMAL_OP);
}

//****************************************************************************
/// Process enter Cal mode, so shutdown all active modules to a prepare for config change state
///
/// @return T_NORMALOP_RETURN_VALUE 
/// 
//****************************************************************************
T_NORMALOP_RETURN_VALUE CNormalOperation::ProcessEnterCalMode(void) {

	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	//Disable the WatchDog in ATECAL Mode as the recorder is
	//going to restart after config changes in this mode and all threads shall be 
	//stopped except the IOScheduler thread
	if (pThreadInfo != NULL) {
		pThreadInfo->DisableWatchDog(TRUE);
	}

	T_NORMALOP_RETURN_VALUE eRetValue = NORMALOP_OK;

	CATECal *pkATECal = CATECal::GetHandle();
	pkATECal->RegisterMMC();

	// put the IO scheduler into limited mode prior to closing down the other threads
	pkATECal->SetLimitedRunMode();

	// entering cal mode - we need to stop all the threads with the exception of the IO scheduler module
	T_V6AMSER_ACTIVE_MODULES activeModule = V6AMSER_DATA_PROCESSING;

	for (USHORT activeModuleIndex = 1; activeModuleIndex < V6AMSER_NUM_OF_ACTIVE_MODULES; ++activeModuleIndex) {
		activeModule = static_cast<T_V6AMSER_ACTIVE_MODULES>(activeModuleIndex);

		if (m_AModSer.DoesActiveModuleExist(activeModule))
			m_AModSer.GetActiveModule(activeModule).PrepareForConfigChange(MOD_CFG_CHG_SETUP);

	}

	return eRetValue;
}

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 V6 Active Module Base Class
/// @n Filename:  V6ActiveModule.h
/// @n Description: Class Declaration File for the V6 Active Module Base Class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  12  Stability Project 1.9.1.1 7/2/2011 5:02:27 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  11  Stability Project 1.9.1.0 7/1/2011 4:27:22 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  10  V6 Firmware 1.9 7/12/2006 5:57:57 PM  Roger Dawson  
//  Auto Ops/FTP additions.
//  9 V6 Firmware 1.8 11/22/2005 2:01:33 PM  Roger Dawson  
//  User calibration changes. Made message handler virtual in the base
//  class and added method to the IOScheduler child class so module
//  specific methods can be handled within the specific module rather
//  than writing code within the active module base class.
// $
//
// **************************************************************************
#ifndef _V6ACTIVEMODULE_H
#define _V6ACTIVEMODULE_H

#include "ModuleMsgManagerClient.h"
#include "MsgQueueMessage.h"
#include "V6defines.h"

#include "V7DbgLogDefines.h"
#ifdef RDL_V6AM_DBG_ENABLE
#include "CStorage.h"
#endif

/// Return Values for CV6ActiveModule Member Functions, used to describe the type of 
/// success or failure.
/// 
typedef enum {
	V6ACTMOD_OK,
	V6ACTMOD_ACTION_NOT_PERFORMED,
	V6ACTMOD_INITIALISATION_FAILED,
	V6ACTMOD_MODULE_THREAD_NOT_CREATED,
	V6ACTMOD_NO_MESSAGE_AVAILABLE,
	V6ACTMOD_EVENT_TIMEOUT,
	V6ACTMOD_EVENT_FAILED,
	V6ACTMOD_MESSAGE_NOT_HANDLED

} T_V6ACTMOD_RETURN_VALUE;

//**Class*********************************************************************
///
/// @brief Base Class for all Active Modules within V6
/// 
/// This class provides common functionality that will be available from all 
/// modules that operate within their own thread. Each method requiring the
/// module to undertake functionality, shall send a message to the module in
/// order for the actions to be undertaken in the correct thread. 
///
/// @note Modules that operate within their own thread are called Active Modules. 
///
/// @todo ProcessATECardChannels - Verify if needed for V6App
//****************************************************************************
class CV6ActiveModule {
public:

	/// Default Constructor
	CV6ActiveModule(T_MODULE_ID moduleId);

	/// Destructor   
	virtual ~CV6ActiveModule(void);

	/// Initialise the Active Module for use
	T_V6ACTMOD_RETURN_VALUE InitialiseActiveModule(T_MODULE_MSG_NOTIFICATION moduleNotification,
			AFX_THREADPROC pThreadFunc, LPVOID pParam, int threadPriority);

	T_V6ACTMOD_RETURN_VALUE InitialiseActiveModule(T_MODULE_MSG_NOTIFICATION moduleNotification,
			CRuntimeClass *pThreadClass, int threadPriority);

	/// Start Module Thread
	T_V6ACTMOD_RETURN_VALUE StartActiveModule(void);

	/// Primary Initialisation of the Module
	virtual T_V6ACTMOD_RETURN_VALUE PerformPrimaryInitialisation(void) = PURE_VIRTUAL_FUNCTION
	;

	/// Secondary Initialisation of the Module
	virtual T_V6ACTMOD_RETURN_VALUE PerformSecondaryInitialisation(void) = PURE_VIRTUAL_FUNCTION
	;

	/// Method called when Module goes into Normal Operation
	virtual T_V6ACTMOD_RETURN_VALUE NormalOperation(void) = PURE_VIRTUAL_FUNCTION
	;

	/// Method called when Module is to prepare for Setup Config Change 
	virtual T_V6ACTMOD_RETURN_VALUE SetupConfigChangePreparation(void) = PURE_VIRTUAL_FUNCTION
	;

	/// Method called when Module is to carry out Setup Change Completion
	virtual T_V6ACTMOD_RETURN_VALUE SetupConfigChangeComplete(void) = PURE_VIRTUAL_FUNCTION
	;

	/// Method called when a Module is to prepare for Shutdown
	virtual T_V6ACTMOD_RETURN_VALUE ShutdownPreparation(void) = PURE_VIRTUAL_FUNCTION
	;

	/// Method called when a Module is to Shutdown
	virtual T_V6ACTMOD_RETURN_VALUE Shutdown(void) = PURE_VIRTUAL_FUNCTION
	;

	/// Method called when Module is informed to Carry out Query Hardware
	virtual T_V6ACTMOD_RETURN_VALUE ATEQueryHardware(void);

	/// Method called when Module is informed to perform ATE Calibration
	virtual T_V6ACTMOD_RETURN_VALUE ATECalibration(void);

	/// Method called when Module is informed to perform ATE Test
	virtual T_V6ACTMOD_RETURN_VALUE ATETest(void);

	/// Method called when the Calibration Info has been updated, and can be processed
	virtual T_V6ACTMOD_RETURN_VALUE ProcessCalibrationInfo(void);

	/// Method called when the IO Scheduler is told to Process Card Readings - ATE Related and may need to be REVIEWED
	virtual T_V6ACTMOD_RETURN_VALUE ProcessATECardChannels(void);

	/// Message Handler for Modules Manually checking for Messages
	T_V6ACTMOD_RETURN_VALUE ManualMessageHandler(void);

	/// Message Handler for Modules that check for message using event mechasmisms
	T_V6ACTMOD_RETURN_VALUE EventMessageHandler(DWORD timeoutValue);

	/// Inform the Module to Perform Normal Operation and Wait until action has been undertaken
	T_V6ACTMOD_RETURN_VALUE PerformNormalOperation(void);

	/// Inform the Module to Prepare for a Configuration Change and Wait until action has been undertaken
	T_V6ACTMOD_RETURN_VALUE PrepareForConfigChange(T_MOD_CFG_CHG_TYPE typeOfConfigChange);

	/// Inform the Module to Prepare for a Configuration Change and Wait until action has been undertaken
	T_V6ACTMOD_RETURN_VALUE ConfigChangeComplete(T_MOD_CFG_CHG_TYPE typeOfConfigChange);

	/// Inform the Module to Prepare for Shutdown and Wait until action has been undertaken
	T_V6ACTMOD_RETURN_VALUE PrepareForShutdown(void);

	/// Inform the Module to Shutdown and Wait until action has been undertaken
	T_V6ACTMOD_RETURN_VALUE PerformShutdown(void);

#ifdef RDL_V6AM_DBG_ENABLE	
		void SetDebugLogger(CDebugFileLogger* pDbgFileLogger);
		virtual void LogDebugMessage(QString   & strDbgMsg);
	#endif

private:

	// --- Private Member Functions --- //

	// --- Private Member Variables --- //

	T_MODULE_ID m_ModuleId; ///< Module Identification 

protected:

	CModuleMsgManagerClient m_ModuleMsgManagerClient; ///< Module Message Manager Client to allow communication with other modules

	QThread *m_pThread; ///< Pointer to the Active Module Thread

	/// Carries out the desired functional when a message is received
	virtual T_V6ACTMOD_RETURN_VALUE ModuleMessageHandler(const CMsgQueueMessage *pMsg);

#ifdef RDL_V6AM_DBG_ENABLE
protected:
	CDebugFileLogger* m_pDebugFileLogger;
#endif
};
// End of Class Declaration

#endif // _V6ACTIVEMODULE_H

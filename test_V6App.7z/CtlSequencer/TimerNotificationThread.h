#pragma once

// CTimerNotificationThread

class CTimerNotificationThread: public QThread {
	// DECLARE_DYNCREATE (CTimerNotificationThread)

protected:
	CTimerNotificationThread();  // protected constructor used by dynamic creation
	virtual ~CTimerNotificationThread();

public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();

protected:()
public:
	static UINT TimerNotificationThreadFunc(LPVOID lpParam);
};


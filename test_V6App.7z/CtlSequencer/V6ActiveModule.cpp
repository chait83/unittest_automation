/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 V6 Active Module Base Class
/// @n Filename:  V6ActiveModule.cpp
/// @n Description: Class Implementation File for the V6 Active Module Base Class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  21  Aristos  1.15.1.3.1.0 9/19/2011 4:51:11 PM  Hemant(HAIL)  
//  Stability recorder source code (JI Release) updated for WatchDog
//  Timer functionality.
//  20  Stability Project 1.15.1.3 7/2/2011 5:02:27 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  19  Stability Project 1.15.1.2 7/1/2011 4:39:06 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  18  Stability Project 1.15.1.1 3/17/2011 3:20:54 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
// $
//
// **************************************************************************

#include "V6ActiveModule.h"
#include "ThreadInfo.h"
#include "MessageItemManager.h"
#include "V6globals.h"

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif

//****************************************************************************
// CV6ActiveModule( T_MODULE_ID moduleId, T_MODULE_MSG_NOTIFICATION moduleNotification )
///
/// Inform the Module via a Message to be perform normal operation, and wait
/// for the message to be processed by the module. 
///
/// @param[in] 	  moduleId  - Module Identification Number
/// @param[in] moduleNotification - Notification method for incoming messages
///
/// @return No Return Value
/// 
//****************************************************************************
CV6ActiveModule::CV6ActiveModule(T_MODULE_ID moduleId)
#ifdef RDL_V6AM_DBG_ENABLE
: m_pDebugFileLogger(NULL)
#endif
		{
	// Store the Module ID
	m_ModuleId = moduleId;

	m_pThread = NULL;

} // End of Constructor

CV6ActiveModule::~CV6ActiveModule(void) {
	if (NULL != m_pThread) {
		delete m_pThread;
		m_pThread = NULL;
	}

} // End of Destructor

T_V6ACTMOD_RETURN_VALUE CV6ActiveModule::InitialiseActiveModule(T_MODULE_MSG_NOTIFICATION moduleNotification,
		AFX_THREADPROC pThreadFunc, LPVOID pParam, int threadPriority) {
	T_V6ACTMOD_RETURN_VALUE retValue = V6ACTMOD_OK;

	// Register the Module with the Module Message Manager
	m_ModuleMsgManagerClient.MMMClientRegister(m_ModuleId, moduleNotification, CAMQ_QUEUE_WRAP_DISABLED);

	// Create the Module Thread
	m_pThread = AfxBeginThread(pThreadFunc, pParam, threadPriority, 0, CREATE_SUSPENDED, NULL);
	m_pThread->m_bAutoDelete = FALSE;

	if (NULL == m_pThread) {
		retValue = V6ACTMOD_MODULE_THREAD_NOT_CREATED;
	} else {
		qDebug("Module %d Thread ID: 0x%x, %lu\n", m_ModuleId, m_pThread->m_nThreadID, m_pThread->m_nThreadID);

#ifdef RDL_V6AM_DBG_ENABLE
			QString  strLogMsg;
			strLogMsg.asprintf(_T("Module %d Thread ID: 0x%x, %lu "),m_ModuleId, m_pThread->m_nThreadID, m_pThread->m_nThreadID );
			LogDebugMessage(strLogMsg);
		 #endif

		/*WCHAR strMsg[MAX_PATH] = { 0 };
		 swprintf(strMsg, L"Module %d Thread ID: 0x%x, %lu ",m_ModuleId, m_pThread->m_nThreadID, m_pThread->m_nThreadID );
		 LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_INFORMATION,strMsg);*/

	} // End of IF

	return (retValue);

} // End of Member Function

T_V6ACTMOD_RETURN_VALUE CV6ActiveModule::InitialiseActiveModule(T_MODULE_MSG_NOTIFICATION moduleNotification,
		CRuntimeClass *pThreadClass, int threadPriority) {
	T_V6ACTMOD_RETURN_VALUE retValue = V6ACTMOD_OK;

	// Register the Module with the Module Message Manager
	m_ModuleMsgManagerClient.MMMClientRegister(m_ModuleId, moduleNotification, CAMQ_QUEUE_WRAP_DISABLED);

	// Create the Module Thread
	m_pThread = AfxBeginThread(pThreadClass, threadPriority, 0, CREATE_SUSPENDED, NULL);
	m_pThread->m_bAutoDelete = FALSE;

	if (NULL == m_pThread) {
		retValue = V6ACTMOD_MODULE_THREAD_NOT_CREATED;
	} else {
		qDebug("Module %d Thread ID: 0x%x, %lu\n", m_ModuleId, m_pThread->m_nThreadID, m_pThread->m_nThreadID);
#ifdef RDL_V6AM_DBG_ENABLE
			QString  strLogMsg;
			strLogMsg.asprintf(_T("Module %d Thread ID: 0x%x, %lu "),m_ModuleId, m_pThread->m_nThreadID, m_pThread->m_nThreadID );
			LogDebugMessage(strLogMsg);
		 #endif

		/*WCHAR strMsg[MAX_PATH] = { 0 };
		 swprintf(strMsg, L"Module %d Thread ID: 0x%x, %lu ",m_ModuleId, m_pThread->m_nThreadID, m_pThread->m_nThreadID );
		 LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_INFORMATION,strMsg);*/

	} // End of IF

	return (retValue);

} // End of Member Function

/// Start Module Thread
T_V6ACTMOD_RETURN_VALUE CV6ActiveModule::StartActiveModule(void) {
	T_V6ACTMOD_RETURN_VALUE retValue = V6ACTMOD_MODULE_THREAD_NOT_CREATED;

	if (NULL != m_pThread) {
		m_pThread->ResumeThread();
		retValue = V6ACTMOD_OK;

	} // End of IF

	return (retValue);

} // End of Member Function

//****************************************************************************
// T_V6ACTMOD_RETURN_VALUE ManualMessageHandler( void )
///
///
///
/// @param[in] NONE
///
/// @return V6ACTMOD_OK   - Message Received, Processed and Associated Action Undertaken Sucessfully
/// @n V6ACTMOD_MESSAGE_NOT_HANDLED - No Message Avaiable
/// 
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE CV6ActiveModule::ManualMessageHandler(void) {
	T_V6ACTMOD_RETURN_VALUE retValue = V6ACTMOD_NO_MESSAGE_AVAILABLE;

	const CMsgQueueMessage *pMsg = m_ModuleMsgManagerClient.MMMClientReadMsg();

	if (NULL != pMsg) {

		ModuleMessageHandler(pMsg);
		m_ModuleMsgManagerClient.MMMClientRemoveMsg();

		retValue = V6ACTMOD_OK;

	} // End of IF

	return (retValue);

} // End of Member Function

//****************************************************************************
// T_V6ACTMOD_RETURN_VALUE EventMessageHandler( DWORD timeoutValue )
///
///
///
/// @param[in] 	  timeoutValue  - timeout value in Milliseconds to wait for a message
///
/// @return V6ACTMOD_OK  - Message Received and Processed Sucessfully
/// @n V6ACTMOD_EVENT_TIMEOUT  - No Message Received, Timeout occurred waiting for Message
/// @n V6ACTMOD_EVENT_FAILED - Failure has occurred with the event object
/// @n V6ACTMOD_NO_MESSAGE_AVAILABLE - Event object triggered but no message available in Message Queue
/// 
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE CV6ActiveModule::EventMessageHandler(DWORD timeoutValue) {
	T_V6ACTMOD_RETURN_VALUE retValue = V6ACTMOD_EVENT_TIMEOUT;
	const CMsgQueueMessage *pMsg = NULL;

	DWORD waitSingleObjectResult = WaitForSingleObject(m_ModuleMsgManagerClient.GetMessageQueueEventHandler(),
			timeoutValue);

	switch (waitSingleObjectResult) {
	case WAIT_OBJECT_0:

		pMsg = m_ModuleMsgManagerClient.MMMClientReadMsg();

		if (NULL != pMsg) {
			ModuleMessageHandler(pMsg);
			m_ModuleMsgManagerClient.MMMClientRemoveMsg();

			retValue = V6ACTMOD_OK;
		} else {
			retValue = V6ACTMOD_NO_MESSAGE_AVAILABLE;
		}

		break;

	case WAIT_TIMEOUT:
		retValue = V6ACTMOD_EVENT_TIMEOUT;
		break;

	case WAIT_ABANDONED:
	case WAIT_FAILED:
		retValue = V6ACTMOD_EVENT_FAILED;
		break;
		break;

	default:
		retValue = V6ACTMOD_EVENT_FAILED;
		break;

	} // End of switch	

	return (retValue);

} // End of Member Function

//****************************************************************************
// T_V6ACTMOD_RETURN_VALUE ModuleMessageHandler( const CMsgQueueMessage *pMsg )
///
///
///
/// @param[in] 	  timeoutValue  - timeout value in Milliseconds to wait for a message
///
/// @return V6ACTMOD_OK   - Associated Action with Received Message Undertaken Sucessfully
/// @n V6ACTMOD_MESSAGE_NOT_HANDLED - Message Received is not being handled
/// 
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE CV6ActiveModule::ModuleMessageHandler(const CMsgQueueMessage *pMsg) {
	T_V6ACTMOD_RETURN_VALUE retValue = V6ACTMOD_OK;

	switch (pMsg->m_MessageType) {
	case MOD_NORMAL_OPERATION:
		NormalOperation();
		break;
	case MOD_PREPARE_FOR_SETUP_CONFIG_CHANGE:
		SetupConfigChangePreparation();
		break;
	case MOD_SETUP_CONFIG_CHANGE_COMPLETE:
		SetupConfigChangeComplete();
		break;
	case MOD_PREPARE_SHUTDOWN:
		ShutdownPreparation();
		break;
	case MOD_SYSTEM_SHUTDOWN:
		Shutdown();
		break;
	case MOD_ATE_QUERY_HARDWARE:
		ATEQueryHardware();
		break;
	case MOD_ATE_CALIBRATION:
		ATECalibration();
		break;
	case MOD_ATE_TEST:
		ATETest();
		break;
	case MOD_CAL_INFO_UPDATED:
		ProcessCalibrationInfo();
		break;
	case MOD_PROCATE_CARD_CHANNELS:
		ProcessATECardChannels();
		break;

	default:
		qDebug("CV6ActiveModule: Unhandled Message %d from %d to %d\n", pMsg->m_MessageType, pMsg->m_SendingModule,
				pMsg->m_DestinationModule);
		retValue = V6ACTMOD_MESSAGE_NOT_HANDLED;
		break;

	} // End of SWITCH  

	return (retValue);

} // End of Member Function

//****************************************************************************
// T_V6ACTMOD_RETURN_VALUE CV6ActiveModule::PerformNormalOperation( void )
///
/// Inform the Module via a Message to be perform normal operation, and wait
/// for the message to be processed by the module. 
///
/// @param[in] 	  NONE
///
/// @return V6ACTMOD_OK  - Message sent and processed successfully
/// V6ACTMOD_ACTION_NOT_PERFORMED - Message failed to send, and/or message not processed
/// 
/// 
/// @todo  Implement timeout value instead of INFINITE once known 
///
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE CV6ActiveModule::PerformNormalOperation(void) {
	T_V6ACTMOD_RETURN_VALUE retValue = V6ACTMOD_ACTION_NOT_PERFORMED; // Member Function Return Value

	// Post the message to the Module, and wait for the message to be actioned and
	// remove from the module message queue. 
	if (MMMCLIENT_MESSAGE_COMPLETED
			== m_ModuleMsgManagerClient.MMMClientPostIntMsgAndWait( INFINITE, 5000, m_ModuleId, m_ModuleId,
					MOD_NORMAL_OPERATION, 0, NULL)) {

		retValue = V6ACTMOD_OK;

	} // End of IF     

	return (retValue);

} // End of Member Function

//****************************************************************************
// T_V6ACTMOD_RETURN_VALUE PrepareForConfigChange( T_TYPE_OF_CONFIG_CHANGE typeOfConfigChange )
///
/// Inform the Module via a Message to be Prepare for Configuration Change, and wait
/// for the message to be processed by the module.
///
/// @param[in] 	  typeOfConfigChange - Type of Configuration Change
///
/// @return V6ACTMOD_OK  - Message sent and processed successfully
/// V6ACTMOD_ACTION_NOT_PERFORMED - Message failed to send, and/or message not processed
/// 
/// 
/// @todo  Implement timeout value instead of INFINITE once known 
///
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE CV6ActiveModule::PrepareForConfigChange(T_MOD_CFG_CHG_TYPE typeOfConfigChange) {
	T_V6ACTMOD_RETURN_VALUE retValue = V6ACTMOD_ACTION_NOT_PERFORMED; // Member Function Return Value

	USHORT messageType = 0xFFFF;

	switch (typeOfConfigChange) {
	case MOD_CFG_CHG_SETUP:
		messageType = MOD_PREPARE_FOR_SETUP_CONFIG_CHANGE;
		break;

	case MOD_CFG_CHG_PASSWORD:

		break;

	case MOD_CFG_CHG_LAYOUT:

		break;

	default:
		break;

	} // End of SWITCH
#ifdef UNDER_CE
	CThreadInfo* pThreadInfo = CThreadInfo::GetHandle();
	//Ignore the ControlSeq thread for watchdog as we have to wait infinitely
	if(pThreadInfo != NULL)
	{

		pThreadInfo->UpdateThreadInfo(AM_CTRLSEQUENCER,false);	 
	 
	}
#endif	  
	// Post the message to the Module, and wait for the message to be actioned and
	// remove from the module message queue. 
	if ((0xFFFF == messageType)
			|| (MMMCLIENT_MESSAGE_COMPLETED == m_ModuleMsgManagerClient.MMMClientPostIntMsgAndWait( INFINITE,
			INFINITE, m_ModuleId, m_ModuleId, messageType, 0, NULL))) {

		retValue = V6ACTMOD_OK;

	} // End of IF 
#ifdef UNDER_CE
	 //Consider the ControlSeq thread as the wait is over
	if(pThreadInfo != NULL)
	{

	 pThreadInfo->UpdateThreadInfo(AM_CTRLSEQUENCER,true);	 
	 
	}
#endif  
	return (retValue);

} // End of Member Function

/// Inform the Module to Prepare for a Configuration Change and Wait until action has been undertaken
T_V6ACTMOD_RETURN_VALUE CV6ActiveModule::ConfigChangeComplete(T_MOD_CFG_CHG_TYPE typeOfConfigChange) {
	T_V6ACTMOD_RETURN_VALUE retValue = V6ACTMOD_ACTION_NOT_PERFORMED; // Member Function Return Value

	USHORT messageType = 0xFFFF;

	switch (typeOfConfigChange) {
	case MOD_CFG_CHG_SETUP:
		messageType = MOD_SETUP_CONFIG_CHANGE_COMPLETE;
		break;

	case MOD_CFG_CHG_PASSWORD:

		break;

	case MOD_CFG_CHG_LAYOUT:

		break;

	default:
		break;

	} // End of SWITCH

	// Post the message to the Module, and wait for the message to be actioned and
	// remove from the module message queue. 
	if ((0xFFFF == messageType)
			|| (MMMCLIENT_MESSAGE_COMPLETED == m_ModuleMsgManagerClient.MMMClientPostIntMsgAndWait( INFINITE,
			INFINITE, m_ModuleId, m_ModuleId, messageType, 0, NULL))) {

		retValue = V6ACTMOD_OK;

	} // End of IF     

	return (retValue);

} // End of Member Function

//****************************************************************************
// T_V6ACTMOD_RETURN_VALUE PrepareForShutdown( void )
///
/// Inform the Module via a Message to be Prepare for Shutdown, and wait
/// for the message to be processed by the module.
///
/// @param[in] 	  NONE
///
/// @return V6ACTMOD_OK  - Message sent and processed successfully
/// V6ACTMOD_ACTION_NOT_PERFORMED - Message failed to send, and/or message not processed
/// 
/// 
/// @todo  Implement timeout value instead of INFINITE once known 
///
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE CV6ActiveModule::PrepareForShutdown(void) {
	T_V6ACTMOD_RETURN_VALUE retValue = V6ACTMOD_ACTION_NOT_PERFORMED; // Member Function Return Value

	// Post the message to the Module, and wait for the message to be actioned and
	// remove from the module message queue. 
	if (MMMCLIENT_MESSAGE_COMPLETED == m_ModuleMsgManagerClient.MMMClientPostIntMsgAndWait( INFINITE,
	INFINITE, m_ModuleId, m_ModuleId, MOD_PREPARE_SHUTDOWN, 0, NULL)) {

		retValue = V6ACTMOD_OK;

	} // End of IF     

	return (retValue);

} // End of Member Function

//****************************************************************************
// T_V6ACTMOD_RETURN_VALUE PerformShutdown( void )
///
/// Inform the Module via a Message to Shutdown, and wait for the message to 
/// be processed by the module.
///
/// @param[in] 	  NONE
///
/// @return V6ACTMOD_OK  - Message sent and processed successfully
/// V6ACTMOD_ACTION_NOT_PERFORMED - Message failed to send, and/or message not processed
/// 
/// 
/// @todo  Implement timeout value instead of INFINITE once known 
///
//****************************************************************************
T_V6ACTMOD_RETURN_VALUE CV6ActiveModule::PerformShutdown(void) {
	T_V6ACTMOD_RETURN_VALUE retValue = V6ACTMOD_ACTION_NOT_PERFORMED; // Member Function Return Value

	// Post the message to the Module, and wait for the message to be actioned and
	// remove from the module message queue. 
	if (MMMCLIENT_MESSAGE_COMPLETED == m_ModuleMsgManagerClient.MMMClientPostIntMsgAndWait( INFINITE,
	INFINITE, m_ModuleId, m_ModuleId, MOD_SYSTEM_SHUTDOWN, 0, NULL)) {

		switch (WaitForSingleObject(m_pThread->m_hThread, 5000)) {
		case WAIT_OBJECT_0:
			qDebug("Module %d Thread Exited\n", m_ModuleId);
			retValue = V6ACTMOD_OK;
			break;

		case WAIT_TIMEOUT:
			qDebug("Module %d TIMEOUT\n", m_ModuleId);
			break;

		case WAIT_ABANDONED:
		case WAIT_FAILED:
			qDebug("ABORTED / FAILED\n");
			break;
			break;

		default:
			break;

		}; // End of SWITCH

	} // End of IF     

	return (retValue);

} // End of Member Function

/// Method called when Module is informed to Carry out Query Hardware
T_V6ACTMOD_RETURN_VALUE CV6ActiveModule::ATEQueryHardware(void) {
	qDebug("ATEQueryHardware BASE Member Called\n");

	return (V6ACTMOD_OK);

} // End of Member Function

/// Method called when Module is informed to perform ATE Calibration
T_V6ACTMOD_RETURN_VALUE CV6ActiveModule::ATECalibration(void) {
	qDebug("ATECalibration BASE Member Called\n");

	return (V6ACTMOD_OK);

} // End of Member Function

/// Method called when Module is informed to perform ATE Test
T_V6ACTMOD_RETURN_VALUE CV6ActiveModule::ATETest(void) {
	qDebug("ATETest BASE Member Called\n");

	return (V6ACTMOD_OK);

} // End of Member Function

/// Method called when the Calibration Info has been updated, and can be processed
T_V6ACTMOD_RETURN_VALUE CV6ActiveModule::ProcessCalibrationInfo(void) {
	qDebug("ProcessCalibrationInfo BASE Member Called\n");

	return (V6ACTMOD_OK);

} // End of Member Function

/// Method called when the IO Scheduler is told to Process Card Readings - ATE Related and may need to be REVIEWED
T_V6ACTMOD_RETURN_VALUE CV6ActiveModule::ProcessATECardChannels(void) {
	qDebug("ProcessATECardChannels BASE Member Called\n");

	return (V6ACTMOD_OK);

} // End of Member Function

#ifdef RDL_V6AM_DBG_ENABLE
void CV6ActiveModule::SetDebugLogger(CDebugFileLogger* pDbgFileLogger)
{
	m_pDebugFileLogger = pDbgFileLogger;
}

void CV6ActiveModule::LogDebugMessage(QString  & strDbgMsg)
{
	if( NULL != m_pDebugFileLogger )
	{
		QString  strDiagMsg;
		strDiagMsg.asprintf(_T("V6AM - %s at GTC:%u\r\n"), strDbgMsg, GetTickCount());
		m_pDebugFileLogger->WriteToDebugLogFile(strDiagMsg);
	}
}
#endif

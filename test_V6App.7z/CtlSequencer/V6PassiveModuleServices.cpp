/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Control sequencer
/// @n Filename: V6PassiveModuleServices.cpp
/// @n Desc:	 Passive modules
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  26  Aristos  1.20.1.3.1.0 9/19/2011 4:51:11 PM  Hemant(HAIL)  
//  Stability recorder source code (JI Release) updated for WatchDog
//  Timer functionality.
//  25  Stability Project 1.20.1.3 7/2/2011 5:02:45 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  24  Stability Project 1.20.1.2 7/1/2011 4:39:18 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  23  Stability Project 1.20.1.1 3/17/2011 3:20:55 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
// $
//
// ****************************************************************

#include "V6PassiveModuleServices.h"

#include "TraceDefines.h"  // Allows the use of LOG_ERR, LOG_INFO, LOG_CRTL Trace Messages

#include "SRAM.h"
#include "dal.h"
#include "ModuleMsgManager.h"
#include "PPQManager.h"
#include "PPIOServiceManager.h"
#include "SlotMap.h"
#include "BrdInfo.h"
#include "BrdStats.h"
#include "ATECal.h"
#include "AIRanges.h"
#include "ConfigManager.h"
#include "DataItemTable.h"
#include "SysTimer.h"
#include "PenManager.h"
#include "DataTransfer.h"
#include "SysInfo.h"
#include "QueueManager.h"
#include "MessageListServices.h"
#include "Scripts.h"
#include "flash.h"
#include "PMMGlobal.h"
#include "PasswordInterfaceManager.h"
#include "PassAuthmgr.h"
#include "EventManager.h"
#include "MediaManager.h"
#include "..\Printing\PrintManager.h"
#include "ThreadInfo.h"

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif

CV6PassiveModuleServices::CV6PassiveModuleServices(void) {
	InitialisePointersToDefault();

} // End of Constructor

CV6PassiveModuleServices::~CV6PassiveModuleServices(void) {

} // End of Destructor

/// Create all the active modules
T_V6PMSER_RETURN_VALUE CV6PassiveModuleServices::CreatePassiveModules(void) {
	T_V6PMSER_RETURN_VALUE retValue = V6PMSER_OK;

	m_PassiveModule[V6PMSER_MESSAGE_LIST] = CMessageListServices::GetHandle();
	m_PassiveModule[V6PMSER_SRAM] = CSRAMManager::GetHandle();
	m_PassiveModule[V6PMSER_NVVARIBALE] = CNVVariableBlockManager::GetHandle();
	m_PassiveModule[V6PMSER_SYSTIMER] = CV6SystemTimer::GetHandle();
	m_PassiveModule[V6PMSER_SYSINFO] = CSysInfo::GetHandle();
	m_PassiveModule[V6PMSER_MODMSGMAN] = CModuleMsgManager::GetHandle();
	m_PassiveModule[V6PMSER_PPQMAN] = CPPQManager::GetHandle();
	m_PassiveModule[V6PMSER_INP_CONDITIONING] = CPPIOServiceManager::GetHandle();
	m_PassiveModule[V6PMSER_SLOT_MAP] = CSlotMap::GetHandle();
	m_PassiveModule[V6PMSER_BRDINFO] = CBrdInfo::GetHandle();
	m_PassiveModule[V6PMSER_BRDSTATS] = CBrdStats::GetHandle();
	m_PassiveModule[V6PMSER_ATECAL] = CATECal::GetHandle();
	m_PassiveModule[V6PMSER_AIRANGES] = CAIRanges::GetHandle();
	m_PassiveModule[V6PMSER_CFGMANAGER] = CIOConfigManager::GetHandle();
	m_PassiveModule[V6PMSER_DIT] = CDataItemManager::GetHandle();
	m_PassiveModule[V6PMSER_PENMANAGER] = CPenManager::GetHandle();
	m_PassiveModule[V6PMSER_TRANSFER] = CDataTransfer::GetHandle();
	m_PassiveModule[V6PMSER_DQMANAGER] = CQueueManager::GetHandle();
	m_PassiveModule[V6PMSER_SCRIPTS] = CScriptManager::GetHandle();
	m_PassiveModule[V6PMSER_FLASH] = CFlashManager::GetHandle();
	m_PassiveModule[V6PMSER_EVTMANAGER] = CEventManager::GetHandle();
	m_PassiveModule[V6PMSER_MEDIA_MANAGER] = CMediaManager::GetHandle();
	m_PassiveModule[V6PMSER_PRINT_MANAGER] = CPrintManager::GetHandle();

#ifdef UNDER_CE 
		#ifndef DISABLE_WDT	
		//Get the instance for the singleton class CThreadInfo
		m_PassiveModule[V6PMSER_THREAD_INFO]		= CThreadInfo::GetHandle();
		#endif
	#endif

	// Check to ensure each module has been successfully created
	for (USHORT passiveModuleIndex = 0; passiveModuleIndex < V6PMSER_NUM_OF_PASSIVE_MODULES; ++passiveModuleIndex) {
		if (NULL == m_PassiveModule[passiveModuleIndex]) {
			retValue = V6PMSER_MODULE_CREATION_FAILED;
			LOG_CRTL(TRACE_CTRL_SEQUENCER, "One or More Passive Modules could not be created");

		} // End of IF

	} // End of FOR

	return (retValue);

} // End of Member Function  

T_V6PMSER_RETURN_VALUE CV6PassiveModuleServices::DeletePassiveModules(void) {
	T_V6PMSER_RETURN_VALUE retValue = V6PMSER_OK;

	// Kill the media manager first, it's self contained and may take time to clean-up
	((CMediaManager*) m_PassiveModule[V6PMSER_MEDIA_MANAGER])->CleanUp();
	((CDataTransfer*) m_PassiveModule[V6PMSER_TRANSFER])->CleanUp();
	((CModuleMsgManager*) m_PassiveModule[V6PMSER_MODMSGMAN])->CleanUp();
	((CPenManager*) m_PassiveModule[V6PMSER_PENMANAGER])->CleanUp();
	((CPPQManager*) m_PassiveModule[V6PMSER_PPQMAN])->CleanUp();
	((CPPIOServiceManager*) m_PassiveModule[V6PMSER_INP_CONDITIONING])->CleanUp();
	((CSlotMap*) m_PassiveModule[V6PMSER_SLOT_MAP])->CleanUp();
	((CBrdInfo*) m_PassiveModule[V6PMSER_BRDINFO])->CleanUp();
	((CBrdStats*) m_PassiveModule[V6PMSER_BRDSTATS])->CleanUp();
	((CATECal*) m_PassiveModule[V6PMSER_ATECAL])->CleanUp();
	((CAIRanges*) m_PassiveModule[V6PMSER_AIRANGES])->CleanUp();
	((CIOConfigManager*) m_PassiveModule[V6PMSER_CFGMANAGER])->CleanUp();
	((CDataItemManager*) m_PassiveModule[V6PMSER_DIT])->CleanUp();
	((CSysInfo*) m_PassiveModule[V6PMSER_SYSINFO])->CleanUp();
	((CMessageListServices*) m_PassiveModule[V6PMSER_MESSAGE_LIST])->CleanUp();
	((CV6SystemTimer*) m_PassiveModule[V6PMSER_SYSTIMER])->CleanUp();
	((CNVVariableBlockManager*) m_PassiveModule[V6PMSER_NVVARIBALE])->CleanUp();
	((CQueueManager*) m_PassiveModule[V6PMSER_DQMANAGER])->CleanUp();
	((CScriptManager*) m_PassiveModule[V6PMSER_SCRIPTS])->CleanUp();
	((CFlashManager*) m_PassiveModule[V6PMSER_FLASH])->CleanUp();
	((CSRAMManager*) m_PassiveModule[V6PMSER_SRAM])->CleanUp();
	((CEventManager*) m_PassiveModule[V6PMSER_EVTMANAGER])->CleanUp();
#ifdef UNDER_CE 
		#ifndef DISABLE_WDT	
		 //Cleanup the singleton class CThreadInfo
		((CThreadInfo*)m_PassiveModule[V6PMSER_THREAD_INFO])->CleanUp();
		#endif
	#endif

	delete m_PassiveModule[V6PMSER_PRINT_MANAGER];

	InitialisePointersToDefault();

	return (retValue);

} // End of Member Function

T_V6PMSER_RETURN_VALUE CV6PassiveModuleServices::InitialisePointersToDefault(void) {
	// Initialise Active Modules Pointer to NULL
	for (USHORT passiveModuleIndex = 0; passiveModuleIndex < V6PMSER_NUM_OF_PASSIVE_MODULES; ++passiveModuleIndex) {
		m_PassiveModule[passiveModuleIndex] = NULL;

	} // End of FOR 

	return (V6PMSER_OK);

} // End of Member Function

// TimerNotificationThread.cpp : implementation file
//

#include "TimerNotificationThread.h"
#include "InternalMessageQueue.h"
#include "ControlSequencer.h"
#include "Dal.h"
#include "ThreadInfo.h"

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif

// CTimerNotificationThread

// IMPLEMENT_DYNCREATE(CTimerNotificationThread, QThread)

CTimerNotificationThread::CTimerNotificationThread()
{
}

CTimerNotificationThread::~CTimerNotificationThread() {
}

BOOL CTimerNotificationThread::InitInstance() {
	// TODO: perform and per-thread initialization here
	return TRUE;
}

int CTimerNotificationThread::ExitInstance() {
	// TODO: perform any per-thread cleanup here
	return QThread::ExitInstance();
}

BEGIN_MESSAGE_MAP(CTimerNotificationThread, QThread)
END_MESSAGE_MAP()

// CTimerNotificationThread message handlers

UINT CTimerNotificationThread::TimerNotificationThreadFunc(LPVOID lpParam)
{
	CInternalMessageQueue *pInternalMessageQueue = (CInternalMessageQueue*)lpParam;
	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//for the TimerNotifcation thread
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();

#ifdef THREAD_ID_SERIAL_LOG
	  WCHAR szDbgMsg[512];
		swprintf( szDbgMsg, L"CTimerNotificationThread::TimerNotificationThreadFunc-Thread id 0x%x, %lu ", GetThreadId(GetCurrentThread()), GetThreadId(GetCurrentThread()));
		OutputDebugString(szDbgMsg);
  #endif

	if(pThreadInfo != NULL)
	{
		//Notify the WatchdogTimer that the TimerNotification thread has 
		//started
		pThreadInfo->UpdateThreadInfo(AM_TIMER_NOTIFICATION_THREAD,true);
	}

	DWORD waitResult = WAIT_OBJECT_0;
	DWORD scheduledTimerEvent = 0;
	CDeviceAbstraction *pDAL = CDeviceAbstraction::GetHandle();

	const USHORT TIMEOUTVALUE = 5000; // 5 Seconds
	const USHORT THIRTYSECONDS = 30000;// 30 Seconds 

	do
	{
		waitResult = WaitForSingleObject(pInternalMessageQueue->GetEventHandler(), TIMEOUTVALUE );

		switch( waitResult )
		{
			case WAIT_OBJECT_0:

			// Read Message

			break;

			case WAIT_TIMEOUT:

			// Perform events every five seconds
			// pDAL->KickWatchdog();

			//scheduledTimerEvent += TIMEOUTVALUE;

			//if( THIRTYSECONDS == scheduledTimerEvent )
			//{
			// scheduledTimerEvent = 0;
			// qDebug("Simulating SRAM Access\n");
			// pDAL->SimulatedSRAMAccess( BF_WRITE );
			//}

			break;

		} // End of Switch

		if(pThreadInfo != NULL)
		{
			//Update the Thread Counter for the Timer Notification
			//thread after each iteration
			pThreadInfo->UpdateThreadCounter(AM_TIMER_NOTIFICATION_THREAD);
		}

	}while( WAIT_OBJECT_0 != waitResult );

	//while( 1 )
	{
		// sleep( 1000 );
		// pControlSequencer->PerformScheduledEvents();

	} // End of While

	if(pThreadInfo != NULL)
	{

		//Update the info that the TimerNotification thread is exiting
		//Hence this thread need not be considered to kick the 
		//watchdog
		pThreadInfo->UpdateThreadInfo(AM_TIMER_NOTIFICATION_THREAD,false);
	}

	return 0x15;
}

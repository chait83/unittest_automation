/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Printing System
/// @n Filename:  PrintManager.cpp
/// @n Description: Implementation of the CPrintManager class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  8 Stability Project 1.3.1.3 7/2/2011 4:59:50 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  7 Stability Project 1.3.1.2 7/1/2011 4:38:41 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  6 Stability Project 1.3.1.1 3/17/2011 3:20:36 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  5 Stability Project 1.3.1.0 2/15/2011 3:03:42 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
//	6	Fix for PAR# 1-3KM3QKL - Print screen does not work in minitrend shows logon window while print *Shankar Rao*
// $
//
// **************************************************************************


#include "PrintManager.h"
#include "Printer.h"

//PSR Fix for PAR# 1-3KM3QKL - Print screen does not work in minitrend shows logon window while print begin
#include "MediaManager.h"
//PSR Fix for PAR# 1-3KM3QKL - Print screen does not work in minitrend shows logon window while print end

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif

CPrintManager *CPrintManager::m_pPrintMgrInstance = NULL;
QMutex m_CreationMutex;

//****************************************************************************
///
/// Constructor
///
//****************************************************************************
CPrintManager::CPrintManager() {
	QMutex* m_kCritSection;
}
//****************************************************************************
///
/// Destructor
///
//****************************************************************************
CPrintManager::~CPrintManager() {
	// ensure that there aren't still print jobs pending 
	m_kCritSection.lock();
	m_kCritSection.lock();

	//deletion of mutex not required
	// set the instance pointer to NULL
	m_pPrintMgrInstance = NULL;
}
//**********************************************************************
///
/// Instance creation of CPenManager singleton
///
/// @return		pointer to single instance of CPrintManager
/// 
//**********************************************************************
CPrintManager* CPrintManager::GetHandle() {
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;
	if (NULL == m_pPrintMgrInstance) {
		// An instance has yet to be completed
		m_CreationMutex = CreateMutex(NULL,			// No security descriptor
				FALSE,			// Mutex object not owned
				TEXT("PRINTMANAGER"));	// Object name

		waitSingleObjectResult = m_CreationMutex.tryLock(g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);
		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:
			// Object was signaled
			if (NULL == m_pPrintMgrInstance) {
				m_pPrintMgrInstance = new CPrintManager;
			}
			if ( FALSE == m_CreationMutex.unlock()) {
				V6WarningMessageBox(NULL, L"Failed to release PRINTMANAGER mutex", L"CPrintManager Error", MB_OK);
				DebugBreak();
			} // End of IF

			break;

		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
			V6WarningMessageBox(NULL, L"PRINTMANAGER WaitForSingleObject Error", L"CPrintManager Error", MB_OK);
			DebugBreak();
			break;
		}
		// Close the Mutex as no longer required
		//No need to close the mutex in Qt
	}
	return (m_pPrintMgrInstance);
}
//**********************************************************************
///
/// Method used for printing documents such as status lists, message lists or reports
///
/// @param[in]		CPrint *pkPrint - Pointer to the print object that will help us draw the
///					document onto the printer DC
///	@param[in]		const QString  &rstrTITLE - The title of the document
/// @param[in]		const bool bSHOW_ERRORS - A flag indicating if we wish to see an error message should
///					the print job have failed
/// @param[in]		const short sNO_OF_PAGES - The number of pages to print or -1 for all
/// @param[in]		HANDLE hCallingThreadHandle - A handle to the calling thread (we need to lower the priorty)
/// 
//**********************************************************************
void CPrintManager::PrintDoc(CPrint *pkPrint, const QString   &rstrTITLE, const bool bSHOW_ERRORS,
		const short sNO_OF_PAGES /* = -1 */, HANDLE hCallingThreadHandle /* = NULL */) {
	m_kCritSection.lock();

	// safe to get the printer DC and print the document so do so
	CPrinter kPrintWnd(pkPrint, hCallingThreadHandle);
	kPrintWnd.OnPrint(rstrTITLE, sNO_OF_PAGES, bSHOW_ERRORS);

	m_kCritSection.lock();
}
//**********************************************************************
///
/// Method used for printing the screen
///
///	@param[in]		const QString  &rstrTITLE - The title of the document
/// 
/// @return		The print status result
///
//**********************************************************************
const UINT CPrintManager::PrintScreen(const QString   &rstrTITLE) {
	m_kCritSection.lock();

	// safe to get the printer DC and print the document so do so
	CPrinter kPrintScreen;

	//PSR Fix for PAR# 1-3KM3QKL - Print screen does not work in minitrend shows logon window while print begin
	CMediaManager *pMediaManager = CMediaManager::GetHandle();
	if (NULL != pMediaManager) {
		pMediaManager->RunLogOnFailureChecker();
	}
	//PSR Fix for PAR# 1-3KM3QKL - Print screen does not work in minitrend shows logon window while print end

	UINT nPrintResult = kPrintScreen.PrintDesktopScreen(rstrTITLE);
	QString   szPrintStatus;
	if (nPrintResult) {
		szPrintStatus = _T("Successfully printed the requested data");
		LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_INFO, szPrintStatus);
	} else {
		// do nothing here as an error will already have been reported
	}

	m_kCritSection.lock();

	return nPrintResult;
}

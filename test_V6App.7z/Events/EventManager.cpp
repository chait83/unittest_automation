/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	Events
/// @n Filename: EventManager.cpp
/// @n Desc:	Main event manager and processor
///				
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 40	Aristos	1.32.1.3.1.2 9/21/2011 3:15:56 PM	Hemant(HAIL) 
//		Updated watchdog threadinfo call check
// 39	Aristos	1.32.1.3.1.1 9/21/2011 2:54:15 PM	Hemant(HAIL) 
//		Updated watchdog threadinfo call check
// 38	Aristos	1.32.1.3.1.0 9/19/2011 4:51:15 PM	Hemant(HAIL) 
//		Stability recorder source code (JI Release) updated for WatchDog
//		Timer functionality.
// 37	Stability Project 1.32.1.3	7/2/2011 4:57:08 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// $
//
// ****************************************************************

#include "EventManager.h"
#include "V6globals.h"
#include "ppl.h"
#include "Alarms.h"
#include "PassAuthMgr.h"
#include "StringUtils.h"
#include "TopStatusBar.h"
#include "ThreadInfo.h"
#include "InputConditioning.h"
#include "BatteryManager.h"

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif

CEventManager *CEventManager::m_pEventManInstance = NULL;
QMutex CEventManager::m_CreationMutex;

CEventManager *pGlbEventManager = NULL;		///< Pointer to the event manager

//**********************************************************************
/// CEventManager constructor
///
//**********************************************************************
CEventManager::CEventManager() : m_SSTimer(TIMER_HIGH_RES), m_ReplayTimer(TIMER_HIGH_RES) {
	m_Initialised = FALSE;
	ResetCauseQueue();
	CEventManager::ClearMask(&m_digitalCache);
	m_firstIn = TRUE;
	QMutex * m_accessQueue;
	m_BackLightOffByEvent = FALSE;
	m_BackLightOffByEventTriggered = FALSE;

}

//**********************************************************************
///
/// Instance creation of CEventManager singleton
///
/// @return		pointer to single instance of CEventManager
/// 
//**********************************************************************
CEventManager* CEventManager::GetHandle() {
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;
	if (NULL == m_pEventManInstance) {
		// An instance has yet to be completed

		waitSingleObjectResult = m_CreationMutex.tryLock(g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);
		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:
			// Object was signaled
			if (NULL == m_pEventManInstance) {
				m_pEventManInstance = new CEventManager;
				pGlbEventManager = m_pEventManInstance;		// Assign global
			}
            m_CreationMutex.unlock();

			break;
		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
			V6WarningMessageBox(NULL, L"EVENTMANAGER WaitForSingleObject Error", L"Event Manager Error", MB_OK);
			break;
		}
		// Close the Mutex as no longer required
		//No need to close the mutex in Qt
	}
	return (m_pEventManInstance);
}

//**********************************************************************
///
/// Deletes the instance of the singleton from memory
///
/// @return		Nothing
/// 
//**********************************************************************
void CEventManager::CleanUp() {
	//deletion of mutex not required
	SwitchOnSaver(FALSE);					// Switch off saver
	delete m_pEventManInstance;
	m_pEventManInstance = NULL;
}

//**********************************************************************
///
/// Initialise the Event Manager
///
/// @return		TRUE, if successful, FALSE if failed, Do not continue if failed
/// 
//**********************************************************************
T_EVENT_MANAGER_RETURN CEventManager::Initialise() {
	if (m_Initialised == TRUE)
		return EVENTMANAGER_OK;

	// Backlight for life history
	pNVBacklightLife = pNV_VARS->GetBasicVarNVObject(static_cast<NVVAR_IDENT>(NVV_BACKLIGHT_LIFE));
	m_backLightLifeInMins = pNVBacklightLife->GetFromNV()->value;

	// Do we need to reset the backlight life counter?
	if ( pSYSTEM_INFO->IsFunctionAvailable(FUNC_RESET_BACKLIGHTLIFE,
	TRUE) == TRUE) {
		// Encoded backlightr reset file is on front CF, reset the backlight time
		m_backLightLifeInMins.flt = 0;
		pNVBacklightLife->SetToNV(m_backLightLifeInMins);
	}
	CBatteryManager *pBatteryManager = CBatteryManager::GetHandle();
	pBatteryManager->Initialise();

	m_ScreenInSaveMode = FALSE;

	// Initialise all 
	int eventControlIndex = 0;
	for (eventControlIndex = 0; eventControlIndex < EVENTSYSTEM_EVENT_SIZE; eventControlIndex++) {
		m_evtControl[eventControlIndex].Initialise(eventControlIndex);
	}

	m_Initialised = TRUE;	// Event Manager has been initialised

	SystemEventTrigger(ecsPowerOn);

	return EVENTMANAGER_OK;
}

//**********************************************************************
/// Reset the list of pending causes
///
/// @return		nothing
//**********************************************************************
void CEventManager::ResetCauseQueue() {
	m_QueueNumItems = 0;
	m_QueueOldest = 0;
	m_QueueLatest = 0;
}

//**********************************************************************
///
/// Initialise the Event Manager
///
/// @return		TRUE, if successful, FALSE if failed, Do not continue if failed
/// 
//**********************************************************************
T_EVENT_MANAGER_RETURN CEventManager::ImplementConfiguration() {
	T_EVENT_MANAGER_RETURN retVal = EVENTMANAGER_OK;

	pEventConfig = pSETUP->GetEventSetupConfig()->GetEventBlock(CONFIG_COMMITTED);

	// Configure the User counters

	T_PCOUNTERS pCountersConfig =
	pSETUP->GetEventSetupConfig()->GetCountersBlock(CONFIG_COMMITTED);
	int userCounter = 0;
	for (userCounter = 0; userCounter < COUNTERS_COUNTER_SIZE; userCounter++) {
		m_UserCounter[userCounter].SetupCounter(&pCountersConfig->Counter[userCounter], userCounter);
	}

	// Reset the list of active events
	m_ActiveEvents.ResetList();

	int scheduleIndex = 0;
	for (scheduleIndex = 0; scheduleIndex < TOTAL_EVENT_SCHEDULES_CAUSES; scheduleIndex++) {
		m_pScheduleList[scheduleIndex] = NULL;
	}
	m_NumberOfSchedules = 0;

	// Reset the routine table list
	int typesIndex = 0;
	for (typesIndex = 0; typesIndex < ectMaxTypes; typesIndex++) {
		m_RoutineTable[typesIndex].ResetList();
	}

	m_totalNumberOfTiggerEffects = 0;	// Reset number of delayed event trigger configured
	int delayedEvtIndex = 0;
	for (delayedEvtIndex = 0; delayedEvtIndex < TOTAL_EVENT_EFFECTS; delayedEvtIndex++) {
		m_pEffectForLink[delayedEvtIndex] = NULL;
	}

	// Run through all event controls, passing though the new configuration and rebuilding the lists
	int eventControlIndex = 0;
	for (eventControlIndex = 0; eventControlIndex < EVENTSYSTEM_EVENT_SIZE; eventControlIndex++) {
		// Run configuration though each event control
		m_evtControl[eventControlIndex].SetupEventFromConfig(&pEventConfig->Event[eventControlIndex],
				&m_oldEventConfig.Event[eventControlIndex]);

		if (m_evtControl[eventControlIndex].IsEnabled()) {
			// Event is enabled so add it's control to active list
			m_ActiveEvents.AddControlToList(&m_evtControl[eventControlIndex]);
			// Run though all event types and build the routine table, each type (T_EVENT_CAUSE_TYPE) has a list
			// of pointers to events that have and enabled cause of that type.
			for (typesIndex = 0; typesIndex < ectMaxTypes; typesIndex++) {
				if (m_evtControl[eventControlIndex].HasActiveType(static_cast<T_EVENT_CAUSE_TYPE>(typesIndex))) {
					// Event has an enabled cause of type typesIndex, so add it to list
					m_RoutineTable[typesIndex].AddControlToList(&m_evtControl[eventControlIndex]);
				}
			}
		}
		// Build a list of all active schedules and a list for all counter causes
		int CauseIndex = 0;
		for (CauseIndex = 0; CauseIndex < EVENT_CAUSE_SIZE; CauseIndex++) {
			if (m_evtControl[eventControlIndex].IsScheduleActive(CauseIndex) == TRUE) {
				// Schedule is active, add it to list of active schedules for processing
				m_pScheduleList[m_NumberOfSchedules++] = m_evtControl[eventControlIndex].GetSchedulePtr(CauseIndex);
			}
		}
		int EffectIndex = 0;
		for (EffectIndex = 0; EffectIndex < EVENT_EFFECT_SIZE; EffectIndex++) {
			if (m_evtControl[eventControlIndex].GetEventEffectPtr(EffectIndex)->IsLinkEffect()) {
				// This is a delayed event link effect, add to list to process before events trigger
				m_pEffectForLink[m_totalNumberOfTiggerEffects++] = m_evtControl[eventControlIndex].GetEventEffectPtr(
						EffectIndex);
			}
		}
	}
	// Setup data item table access for digital IO processor
	int digIODIIndex = 0;
	m_pDigIODataItem[digIODIIndex++] = reinterpret_cast<CDataItemIO*>(pDIT->GetDataItemPtr(DI_IO, DI_IO_MISC,
			DI_IO_DIG_BITS_SLOT1));
	m_pDigIODataItem[digIODIIndex++] = reinterpret_cast<CDataItemIO*>(pDIT->GetDataItemPtr(DI_IO, DI_IO_MISC,
			DI_IO_DIG_BITS_SLOT2));
	m_pDigIODataItem[digIODIIndex++] = reinterpret_cast<CDataItemIO*>(pDIT->GetDataItemPtr(DI_IO, DI_IO_MISC,
			DI_IO_DIG_BITS_SLOT3));

	// Check to see if there are any digital causes configured
	if (m_RoutineTable[ectDigitalInput].NumEventControlsInList() > 0) {
		m_DigitalCauseEnabled = TRUE;	// A digital cause is enabled, we must check digital inputs in event processing
	} else {
		m_DigitalCauseEnabled = FALSE;		// No digital causes enabled, don't waste time checking for digital changes
	}

	// Screen saver configuration
#ifndef TTR6SETUP
	m_pOpPanel = reinterpret_cast<COpPanel*>(AfxGetApp()->m_pMainWnd);
#endif

	m_SSTimer.StartTimer();
	m_pSSConfig = &pSETUP->GetGeneralSetupConfig()->GetProfileBlock(CONFIG_COMMITTED)->ScreenSaver;
	SwitchOnSaver(FALSE);		// Switch off screen saver.

	m_normalBrightnessFactor = (float) m_pSSConfig->NormalBright / 100;	// Normal brightness %age
	m_saverBrightnessFactor = 0;	// save on brightness, 0 - unless dimsaver
	if (m_pSSConfig->DimSaver) {
		// Dimsaver
		m_saverBrightnessFactor = (float) m_pSSConfig->SaverBright / 100;
	}

	// the factors are current between 0 (off) and 1 (100%) where 75% = 0.75
	// in order to get the effect of time of backlight these are squared, so 75% brightness will last roughly twice as long as full brightness
	m_saverBrightnessFactor = (m_saverBrightnessFactor * m_saverBrightnessFactor) / 60;	// Store saver brightness as factor in minutes
	m_normalBrightnessFactor = (m_normalBrightnessFactor * m_normalBrightnessFactor) / 60;// Store normal brightness as factor in minutes

	// Store new event configuration.
	memcpy(&m_oldEventConfig, pEventConfig, sizeof(T_EVENTSYSTEM));

#ifndef V6IOTEST
	// reset the batch counters if they have changed
	CBatchManager *pkBatchMgr = CBatchManager::Instance();
	pkBatchMgr->ResetCounterIfConfigChanged();
#endif

	//TimeSync...
	// Get a handle on the Digital Data Item that is assigned to the time change
	pTimeSyncDataItem = dynamic_cast<CDataItemIO*>( pDIT->GetDataItemPtr(DI_IO, DI_IO_DIGITAL,
			pEventConfig->TimeSync.DigitalPicker));

	digTestFirstIn = TRUE;

	return retVal;
}

////**********************************************************************
/// Process any pending events
///
/// @return T_EVENT_MANAGER_RETURN as result of function
//**********************************************************************
T_EVENT_MANAGER_RETURN CEventManager::Process() {
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();

	// Check for any changes in the digitals state
	PerformDigitalIOCause();

	// Check for any expired schecduled events
	PerformScheduleEventCheck();

	// Check though the standlaone counter causes
	PerformCounterCauseCheck();

	// Check for any delayed events tiggereing
	PerformDelayedEventCheck();

	//TimeSync...
	// check and sync time on digital input..
	CheckAndSyncTimeOnDigital();

	// Check if there are any event causes in the queue
	if (GetNumberOfItemsInQueue() > 0) {
		// Run through events causes in queue, triggering any compliant causes
		int listIndex = 0;	///< Index for running through routine table list
		CEventControl *pEventControl = NULL;	///< Pointer to event control to perform
		T_EVENTQUEUE_ELEMENT nextEventCause;	///< holder for event cause from queue

		do {
			// Get the next cause from the queue
			GetEventCauseFromQueue(&nextEventCause);

			if (nextEventCause.causeType == ectInstantCause) {
				pEventControl = &m_evtControl[nextEventCause.data.L[0]];
				// This event will be triggered regardless if it is enabled
				if (pEventControl->IsEnabled() == TRUE) {
					pEventControl->TriggerFromCause(&nextEventCause);
				}
			} else {
				// Check to see if there are any dependent events in the routining table for this type of cause
				if (m_RoutineTable[nextEventCause.causeType].NumEventControlsInList() > 0) {
					// Loop through every event control that has a cause mathing the cause retreived from queue
					for (listIndex = 0; listIndex < m_RoutineTable[nextEventCause.causeType].NumEventControlsInList();
							listIndex++) {
						// Get the event control for the list that matches this cause type
						pEventControl = m_RoutineTable[nextEventCause.causeType].GetEntry(listIndex);
						// Trigger the event from the cause ( this will perform finer filtering before triggering effects )
						pEventControl->TriggerFromCause(&nextEventCause);
					}

				}
			}
			if (pThreadInfo != NULL) {
				//Update the Thread Counter for the DataProcessing
				//thread after each iteration
				pThreadInfo->UpdateThreadCounter(AM_DATA_PROCESSING);
			}
		} while (GetNumberOfItemsInQueue() > 0);
	}
	return EVENTMANAGER_OK;
}

//**********************************************************************
/// Go into or Out of screen save mode
///
/// @param[in]		SaveOn - TRUE to activate screen saver other FALSE to show screen
///
/// @return		nothing
//**********************************************************************
void CEventManager::SwitchOnSaver(BOOL SaveOn) {
	if (SaveOn) {
		if (m_BackLightOffByEvent == TRUE) {
			// Switch off backlight totally, as it's been forced by event
			pDALGLB->SetScreenBrightness( SCRN_BACKLIGHT_OFF);
			m_BackLightOffByEventTriggered = TRUE;
		} else {
			// Screen saver activated
			if (m_pSSConfig->DimSaver) {
				// Dimsave enabled, so dim to saver level.
				pDALGLB->SetScreenBrightness(m_pSSConfig->SaverBright);
			} else {
				// Normal screen save mode, switch off backlight totally
				pDALGLB->SetScreenBrightness( SCRN_BACKLIGHT_OFF);
			}
		}
	} else {
#ifndef V6IOTEST
		// Screen save off, so set to normal brightness with backlight on
		pDALGLB->SetScreenBrightness(m_pSSConfig->NormalBright);
#endif
		m_BackLightOffByEvent = FALSE;
		m_BackLightOffByEventTriggered = FALSE;
	}
	m_ScreenInSaveMode = SaveOn;
}

//**********************************************************************
/// Switch off backlight on event trigger
///
/// @return		nothing
//**********************************************************************
void CEventManager::EventTriggerBackLightOff() {
	m_BackLightOffByEvent = TRUE;
	m_BackLightOffByEventTriggered = FALSE;
}

//**********************************************************************
/// Switch On backlight on event trigger
///
/// @return		nothing
//**********************************************************************
void CEventManager::EventTriggerBackLightOn() {
	// Turn Backlight On from an event
	SwitchOnSaver(FALSE);
}

#ifndef TTR6SETUP
//**********************************************************************
/// Process screen saver
///
/// @return		nothing
//**********************************************************************
T_EVENT_MANAGER_RETURN CEventManager::ProcessScreenSaver() {
	// Perform Screen saver functions
	BOOL userActiviy = pDALGLB->GetUserActivity();
	CBatteryManager *pBatteryManager = CBatteryManager::GetHandle();

	if (userActiviy == TRUE) {
		pDALGLB->ClearUserActivity();	// Register we have seen user activity
		PasswordUpdateUserAccess();	// Update password timeout that user activity has occured
		ResetReplayTimeOut();			// Reset the replay timeout timer.
	}

	if ((m_pSSConfig->Enabled == TRUE) || (m_BackLightOffByEvent == TRUE)) {
#ifndef V6IOTEST
		// check no alarms and no alerts
		if ((pALARM_OVERVIEW->GetNumberOfAlarmsInAlarm() == 0)
				&& (CTopStatusBar::Instance()->IsErrorDlgActive() == FALSE)) {
			// Only run screen saver when process screens are being displayed
			if (m_pOpPanel->GetMode() == OPPANEL_MODE_PROCESS_SCREENS) {
				if (userActiviy == TRUE) {
					// There has been user activity since the last check
					if (m_ScreenInSaveMode) {
						// We are in Screen save mode already so reset
						SwitchOnSaver(FALSE);			// Switch off saver
					}
					m_SSTimer.StartTimer();				// Restart the timer
				}
				if (m_BackLightOffByEvent == TRUE && m_BackLightOffByEventTriggered == FALSE) {
					// Backlight event has fired to turn off backlight, and it hasn't been turned off yet.
					SwitchOnSaver(TRUE);				// Switch on screen saver - using event
				} else if ((m_pSSConfig->Enabled == TRUE) && (m_ScreenInSaveMode == FALSE)
						&& (MSEC_TO_SEC(m_SSTimer.ElapsedTimeInMilliSeconds()) > MIN_TO_SEC(m_pSSConfig->Timeout))) {
					// If screen saver is enabled and not on and timeout has elapsed in minutes, turn saver on
					SwitchOnSaver(TRUE);		// Switch on screen saver
				}
			} else {
				if (m_ScreenInSaveMode) {
					// We are in Screen save mode and not in process screen mode so display
					SwitchOnSaver(FALSE);			// Switch off saver
				}
				m_SSTimer.StartTimer();				// Restart the timer
			}
		} else {
			if (m_ScreenInSaveMode) {
				// We are in Screen save mode and not in process screen mode so display
				SwitchOnSaver(FALSE);			// Switch off saver
			}
			m_SSTimer.StartTimer();				// Restart the timer
		}
#endif
	}

	// Process the Backlight life counter, life is increased exponentially when brightness is decreased.
	if (m_ScreenInSaveMode) {
		m_backLightLifeInMins.flt += m_saverBrightnessFactor;
	} else {
		m_backLightLifeInMins.flt += m_normalBrightnessFactor;
	}

	// Store the counters back to NV
	pNVBacklightLife->SetToNV(m_backLightLifeInMins);

	pBatteryManager->Process();

//	qDebug("Life is now %f or %s\n", m_backLightLifeInMins.flt, CStringUtils::GetHHMMSSspanFromSeconds( m_backLightLifeInMins.flt * 60 ) );

	return EVENTMANAGER_OK;
}
#endif

//**********************************************************************
/// Prepare Events for a configuration Change
///
/// @return		T_PENMANAGER_RETURN 
//**********************************************************************
T_EVENT_MANAGER_RETURN CEventManager::PrepareForConfigChange() {

	return EVENTMANAGER_OK;
}

//**********************************************************************
/// Run though all active schedules checking for timeouts
///
/// @return		nothing 
//**********************************************************************
void CEventManager::PerformScheduleEventCheck() {
	int scheduleIndex = 0;
	CEventSchedule *pSchedule = NULL;
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	for (scheduleIndex = 0; scheduleIndex < m_NumberOfSchedules; scheduleIndex++) {
		pSchedule = m_pScheduleList[scheduleIndex];

		// If the time has changed, register with the schedule so it can be re-calculated
		if ( pSYSTIMER->HasTimeChangeOccured() == TRUE) {
			pSchedule->RegisterTimeChange();
		}

		T_EVENT_SCHEDULE_STATUS triggerRet = pSchedule->IsTriggered();
		// Check if the schedule has triggered
		if (triggerRet == SCHED_STATUS_TRIGGERED) {
			m_evtControl[pSchedule->GetEventIndex()].SetSchedCount(pSchedule->GetCauseIndex(),
					pSchedule->GetCountDown());
			DirectEventTrigger(pSchedule->GetEventIndex());
		}
		if (pThreadInfo != NULL) {
			//Update the Thread Counter for the DataProcessing
			//thread after each iteration
			pThreadInfo->UpdateThreadCounter(AM_DATA_PROCESSING);
		}
	}
}

//**********************************************************************
/// Run though all delayed events configured and check for timeouts
///
/// @return		nothing 
//**********************************************************************
void CEventManager::PerformDelayedEventCheck() {
	int delayedIndex = 0;
	CEventEffect *pEffect = NULL;
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	for (delayedIndex = 0; delayedIndex < m_totalNumberOfTiggerEffects; delayedIndex++) {
		pEffect = m_pEffectForLink[delayedIndex];
		if (pEffect != NULL) {
			pEffect->TestAndTriggerDelayedEvent();
		}
		if (pThreadInfo != NULL) {
			//Update the Thread Counter for the DataProcessing
			//thread after each iteration
			pThreadInfo->UpdateThreadCounter(AM_DATA_PROCESSING);
		}
	}
}

//**********************************************************************
/// Run though all counter causes checking for breach
///
/// @return		nothing 
//**********************************************************************
void CEventManager::PerformCounterCauseCheck() {
	// Are there any counter limit trigger causes configured
	if (m_RoutineTable[ectUserCounters].NumEventControlsInList() > 0) {
		// Yes, run though each of the Event controls with a counter cause
		for (int listIndex = 0; listIndex < m_RoutineTable[ectUserCounters].NumEventControlsInList(); listIndex++) {
			// Check counter and post in direct effect if triggered
			m_RoutineTable[ectUserCounters].GetEntry(listIndex)->TriggerFromCounterCheck();
		}
	}
}

//**********************************************************************
/// Check for digital IO changes, if found then post in a cause
///
/// @return		nothing 
//**********************************************************************
void CEventManager::PerformDigitalIOCause() {
	if (m_DigitalCauseEnabled == TRUE) {
		int digMaskIndex = 0;
		for (digMaskIndex = 0; digMaskIndex < MAX_DIGITAL_IO_MASKS; digMaskIndex++) {
			// Get the digital mask on the state of the card in the slot (16 bit's but in float form in DIT)
			m_workingDigMask[digMaskIndex] = static_cast<USHORT>(m_pDigIODataItem[digMaskIndex]->GetFPValue());
		}
		// Is this the first time the digital check has been done from startup
		if (m_firstIn) {
			// Yes, nothing to compare changes with so we don't want a spurious event, simply setup the data mask
			for (digMaskIndex = 0; digMaskIndex < MAX_DIGITAL_IO_MASKS; digMaskIndex++) {
				m_digitalCache.S[digMaskIndex] = m_workingDigMask[digMaskIndex];
			}
			m_firstIn = FALSE;			// Clear firstin, will not be set again until system restart
		} else {
			BOOL digitalChanged = FALSE;
			// No, Normal operation compare the current digital state and check for changes.
			for (digMaskIndex = 0; digMaskIndex < MAX_DIGITAL_IO_MASKS; digMaskIndex++) {
				// Check for a digital IO change in the slot
				if (m_workingDigMask[digMaskIndex] != m_digitalCache.S[digMaskIndex]) {
					// There is a change, we need to to find which, so create a mask of the changes bits using xor
					m_digitalCache.S[DIO_CAUSE_CHANGE_MASK_BASE + digMaskIndex] = m_workingDigMask[digMaskIndex]
							^ m_digitalCache.S[digMaskIndex];			// Set changed mask
					m_digitalCache.S[digMaskIndex] = m_workingDigMask[digMaskIndex];	// Set actual data
					digitalChanged = TRUE;
				} else {
					m_digitalCache.S[DIO_CAUSE_CHANGE_MASK_BASE + digMaskIndex] = 0;// clear the change mask, nothing happened this time round
				}
			}
			// If one or more digital IO have changed state in this process slice, add as a state change
			if (digitalChanged == TRUE) {
				// Build a digital IO cause and post into system for processing
				T_EVENTQUEUE_ELEMENT cause;
				cause.causeType = ectDigitalInput;
				cause.data = m_digitalCache;
				cause.subType = 0;	// No subtype, as it could be a mixture of on/off

				AddEventCauseToQueue(&cause);	// Add the cause to the queue for processing
			}
		}
	}
}

//**********************************************************************
/// Add an event cause element to the list of events for processing
///
/// @param[in]		pEventCause - ptr to event cause element to be added
///
/// @return T_EVENT_MANAGER_RETURN as result of function
//**********************************************************************
T_EVENT_MANAGER_RETURN CEventManager::AddEventCauseToQueue(T_EVENTQUEUE_ELEMENT *pEventCause) {
	T_EVENT_MANAGER_RETURN retVal = EVENTMANAGER_OK;

	m_accessQueue.lock();	// Exclusive access when adding event to a list

	// Add the new event cause into the queue at the newest position
	m_QueueNumItems++;
	m_evtQueue[m_QueueLatest++] = *pEventCause;

	if (m_QueueLatest >= MAX_EVENTLIST_ELEMENTS) {
		m_QueueLatest = 0;
	}

	// Check that the queue s not about to overflow
	if (m_QueueLatest == m_QueueOldest) {
		/// This queue is about to overflow, warn to use and remove the oldest message
		LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "Event System overflow-too many events in buffer");

		m_QueueOldest++;
		if (m_QueueOldest >= MAX_EVENTLIST_ELEMENTS) {
			m_QueueOldest = 0;
		}
		m_QueueNumItems--;

	}
	m_accessQueue.lock();

	return retVal;
}

//**********************************************************************
/// Get an event cause element from the list for processing
///
/// @param[in]		pEventCause - ptr to holder that event will copied into
///
/// @return number of events remaining in the list, or NOTHING_IN_EVENT_QUEUE if queue empty
//**********************************************************************
int CEventManager::GetEventCauseFromQueue(T_EVENTQUEUE_ELEMENT *pEventCause) {
	int retVal = NOTHING_IN_EVENT_QUEUE;

	m_accessQueue.lock();	// Exclusive access when geting event from queue

	// Only get an event cause if there are any in the queue
	if (m_QueueNumItems > 0) {
		// Get the oldest cause in the queue
		*pEventCause = m_evtQueue[m_QueueOldest++];

		// Check oldest index for rollover
		if (m_QueueOldest >= MAX_EVENTLIST_ELEMENTS) {
			m_QueueOldest = 0;
		}
		m_QueueNumItems--;

		retVal = m_QueueNumItems;
	}
	m_accessQueue.lock();

	return retVal;
}

//**********************************************************************
/// Totaliser Action caused
/// Send totaliser action to the event system
///
/// @param[in]	totalAction - type of totaliser action (type T_TOTAL_MODE)
/// @param[in]	pTotaliserMask - bitmask of affected totalisers in T_EVENTDATA format
///
/// @return		nothing
//**********************************************************************
void CEventManager::TotaliserActionCause(USHORT totalAction, T_EVENTDATA *pTotaliserMask) {
	T_EVENTQUEUE_ELEMENT cause;

	// Set totlaiser type and set the data as it will be compatable
	cause.causeType = ectTotaliser;
	cause.data = *pTotaliserMask;

	// The subtype for totaliser matches the T_TOTAL_MODE order, however TOTAL_MODE_RUN=1 where is START=0
	// so just subtract 1 from the subType being passed in and in totaliser co
	cause.subType = totalAction - 1;

	// Add the cause to the queue for processing
	AddEventCauseToQueue(&cause);
}

//**********************************************************************
/// MaxMin manual reset caused, send to event system
///
/// @param[in]	penNumber - zero based penNumber of MaxMin that was reset
///
/// @return		nothing
//**********************************************************************
void CEventManager::MaxMinResetCause(USHORT penNumber) {
	T_EVENTQUEUE_ELEMENT cause;

	cause.causeType = ectMaxMins;
	cause.data.S[0] = penNumber;
	cause.subType = 0; //coverity fix h350726 CID:770279

	// Add the cause to the queue for processing
	AddEventCauseToQueue(&cause);
}

//**********************************************************************
/// Alarm transition/acknowledge caused
///
/// @param[in]	PenNumber - Pen Number ZERO BASED 
/// @param[in]	AlarmNumber - Alarm number ZERO BASED
/// @param[in]	transitionType - T_EVENT_ALARM_CAUSE_SUBTYPE type of alarm transition, In, Out or Ack
///
/// @return		nothing
//**********************************************************************
void CEventManager::AlarmTransitionCause(USHORT PenNumber, USHORT AlarmNumber,
		T_EVENT_ALARM_CAUSE_SUBTYPE transitionType) {
	T_EVENTQUEUE_ELEMENT cause;

	// Set Alarm type and transition type
	cause.causeType = ectAlarm;
	cause.subType = transitionType;
	// Add the pen number and alarm number into the data structure
	cause.data.S[ALARM_EVENT_CAUSE_PENNUMBER_INDEX] = PenNumber;
	cause.data.S[ALARM_EVENT_CAUSE_ALARMNUMBER_INDEX] = AlarmNumber;

	// Add the cause to the queue for processing
	AddEventCauseToQueue(&cause);
}

//**********************************************************************
/// Burnout on analogue cause
///
/// @param[in]	AnalogueNumber - Analogue Number of TC burnout detected, ZERO BASED 
///
/// @return		nothing
//**********************************************************************
void CEventManager::TCBurnoutCause(USHORT AnalogueNumber) {
	T_EVENTQUEUE_ELEMENT cause;

	// Set TC Burnout type, no sub type
	cause.causeType = ectTCBurnOut;
	cause.subType = 0;
	// Set the analogue number that caused the burnout detection
	cause.data.S[TCBURNOUT_EVENT_CAUSE_ANANUMBER_INDEX] = AnalogueNumber;

	// Add the cause to the queue for processing
	AddEventCauseToQueue(&cause);
}

//**********************************************************************
/// Trigger an event explicitly
///
/// @param[in]	eventIndex - event to trigger, ZERO BASED 
///
/// @return		nothing
//**********************************************************************
void CEventManager::DirectEventTrigger(int eventIndex) {
	T_EVENTQUEUE_ELEMENT cause;

	// Only trigger a valid event
	if (eventIndex >= 0 && eventIndex < EVENTSYSTEM_EVENT_SIZE) {
		// Set as instant cause, no subtype, passing thouygh event index (zero based) to trigger
		cause.causeType = ectInstantCause;
		cause.subType = 0;
		cause.data.L[0] = eventIndex;

		// Add the cause to the queue for processing
		AddEventCauseToQueue(&cause);
	}
}

//**********************************************************************
/// Trigger an system based event (Power On, Setup Changed etc..)
///
/// @param[in]	sysType - is type of system event caused see T_SYSTEM_EVENT_SUBTYPE in types.h
///
/// @return		nothing
//**********************************************************************
void CEventManager::SystemEventTrigger(T_SYSTEM_EVENT_SUBTYPE sysType) {
	T_EVENTQUEUE_ELEMENT cause;

	// Set up as a system cause with relevant subtype
	cause.causeType = ectSystem;
	cause.subType = static_cast<USHORT>(sysType);

	// Add the cause to the queue for processing
	AddEventCauseToQueue(&cause);
}

//**********************************************************************
/// Trigger an user based event (Manual Mark Chart etc..)
///
/// @param[in]	userType - is type of user event caused see T_USER_EVENT_SUBTYPE in types.h
///
/// @return		nothing
//**********************************************************************
void CEventManager::UserActionEventTrigger(T_USER_EVENT_SUBTYPE userType) {
	T_EVENTQUEUE_ELEMENT cause;

	// Set up as a user action cause with relevant subtype
	cause.causeType = ectUserAction;
	cause.subType = static_cast<USHORT>(userType);

	// Add the cause to the queue for processing
	AddEventCauseToQueue(&cause);
}

//**********************************************************************
/// Trigger an batch event
///
/// @param[in]	batchOperation - start,stop or pause T_BATCH_EVENT_SUBTYPE in types.h
/// @param[in]	groupNumber - Zero based Number of group that caused the event, 0-5
///
/// @return		nothing
//*****************

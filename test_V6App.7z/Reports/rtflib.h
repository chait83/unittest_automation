#include "RTFStructures.h"
#include "RecorderStorage.h"

#if !defined(AFX_RTFLIB_H__E7EB2139_DD8B_433F_B20A_B22FB9761234__INCLUDED_)
#define AFX_RTFLIB_H__E7EB2139_DD8B_433F_B20A_B22FB9761234__INCLUDED_

class CRTFLib: public CRecorderStorage {
public:
	// Constructor - Use me when writing RTF files as I set the correct paper size
	CRTFLib(const bool bLETTER_PAGE_SIZE);

	// Default Constructor 
	CRTFLib();

	QString  m_strBUFFER;

	void tempwrite(const QString  &rstrADD_DATA);

	BOOL WriteBuffer();

	// RTF library interface
	int rtf_open(const QString  &rstrFILENAME, const QString  &rstrFONTS, const QString  &rstrCOLOURS); // Creates new RTF document
	int rtf_close();														// Closes created RTF document
	bool rtf_write_header();												// Writes RTF document header
	void rtf_init();														// Sets global RTF library params
	void rtf_set_fonttable(const QString  &FONTS);									// Sets new RTF document font table
	void rtf_set_colortable(const QString  &strCOLOURS);								// Sets new RTF document color table
	RTF_DOCUMENT_FORMAT* rtf_get_documentformat();							// Gets RTF document formatting properties
	void rtf_set_documentformat(RTF_DOCUMENT_FORMAT *df);					// Sets RTF document formatting properties
	bool rtf_write_documentformat();										// Writes RTF document formatting properties
	RTF_SECTION_FORMAT* rtf_get_sectionformat();							// Gets RTF section formatting properties
	void rtf_set_sectionformat(RTF_SECTION_FORMAT *sf);						// Sets RTF section formatting properties
	bool rtf_write_sectionformat();											// Writes RTF section formatting properties
	int rtf_start_section();												// Starts new RTF section
	RTF_PARAGRAPH_FORMAT* rtf_get_paragraphformat();						// Gets RTF paragraph formatting properties
	void rtf_set_paragraphformat(RTF_PARAGRAPH_FORMAT *pf);					// Sets RTF paragraph formatting properties
	bool rtf_write_paragraphformat();									// Writes RTF paragraph formatting properties
	int rtf_start_paragraph(const QString  &rstrTEXT, bool newPar);						// Starts new RTF paragraph
	int rtf_load_image(QString image, int width, int height);					// Loads image from file
	WCHAR* rtf_bin_hex_convert(QString binary, int size);				// Converts binary data to hex
	void rtf_set_defaultformat();											// Sets default RTF document formatting
	int rtf_start_tablerow();												// Starts new RTF table row
	int rtf_end_tablerow();													// Ends RTF table row
	int rtf_start_tablecell(int rightMargin);								// Starts new RTF table cell
	int rtf_end_tablecell();												// Ends RTF table cell
	RTF_TABLEROW_FORMAT* rtf_get_tablerowformat();							// Gets RTF table row formatting properties
	void rtf_set_tablerowformat(RTF_TABLEROW_FORMAT *rf);					// Sets RTF table row formatting properties
	RTF_TABLECELL_FORMAT* rtf_get_tablecellformat();						// Gets RTF table cell formatting properties
	void rtf_set_tablecellformat(RTF_TABLECELL_FORMAT *cf);					// Sets RTF table cell formatting properties
	const QString  rtf_get_bordername(int border_type);								// Gets border name
	const QString  rtf_get_shadingname(int shading_type, bool cell);					// Gets shading name

	// Method that converts any unicode characters into RTF compatible strings
	virtual const QString  ConvertUnicode(const QString pwcBUFFER);

	void EndHeader();

	void EndFooter();

	void StartTable();

	// Method that adds the table header cells
	void AddTableHeader(const QString  &rstrHEADERS);

	// Method that adds the table header cells - also supports variable row/cell widths
	void AddTableHeader(const QString  &rstrHEADERS, const int iaCELL_WIDTHS[]);

	// Method used to create equal width rows
	void StartRow(const int iNO_OF_COLS);

	// Method used to create variable width rows/cells
	void StartVarWidthRow(const int iNO_OF_COLS, const int iaCELL_WIDTHS[]);

	void EndTable();

	void AddTitle(const QString  &rstrTITLE);

	/// Method used to read RTF files
	const QString  ReadBuffer(QString  &rstrFULL_PATH_NAME);

	/// Const used to indicate the maximum length of the read buffer
	const ULONG m_ulMAX_READ_BUFF_LEN;

	/// Const used to store the standard maximum table width
	static const int ms_iMAX_CELL_WIDTH;

	/// Flag indicating the current page size selected is Letter (false implies A4)
	const bool m_bLetterPageSize;

	/// Consts used to store the A4 page dimensions in TWIPS
	const int m_iA4_WIDTH_IN_TWIPS;
	const int m_iA4_HEIGHT_IN_TWIPS;

	/// Consts used to store the Letter page dimnesions in TWIPS
	const int m_iLETTER_WIDTH_IN_TWIPS;
	const int m_iLETTER_HEIGHT_IN_TWIPS;

};
#endif

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Report system
/// @n Filename:  ReportGenThread.h
/// @n Description: Interface of the CReportGenThread class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  3 Stability Project 1.0.1.1 7/2/2011 5:00:24 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  2 Stability Project 1.0.1.0 7/1/2011 4:25:21 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  1 V6 Firmware 1.0 4/12/2007 3:47:30 PM  Roger Dawson  
// $
//
// **************************************************************************

#if !defined(AFX_REPORTGENTHREAD_H__48B37BC5_60CA_4F95_91A5_532657F9F522__INCLUDED_)
#define AFX_REPORTGENTHREAD_H__48B37BC5_60CA_4F95_91A5_532657F9F522__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

const int WM_GENERATE_REPORT = WM_APP + 60;	//PSR - Fix for 1-30DY01Q

//**CReportGenThread***********************************************************
///
/// @brief Thread Class used to carry out the generation of reports including
/// emailing, printing and exporting
/// 
/// Thread Class used to carry out the generation of reports including
/// emailing, printing and exporting
///
//**********************************************************************
class CReportGenThread: public QThread {
	// DECLARE_DYNCREATE (CReportGenThread)

protected:
	CReportGenThread();  // protected constructor used by dynamic creation

// Attributes
public:
	virtual ~CReportGenThread(); //PSR - Fix for 1-30DY01Q

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CReportGenThread)
public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	virtual BOOL PreTranslateMessage(MSG *pMsg);	//PSR - Fix for 1-30DY01Q
	//}}AFX_VIRTUAL

	//PSR - Fix for 1-30DY01Q begin
	// Thread function responsible for the generation of a report
	static UINT GenReport(LPVOID lpParam);
	//PSR - Fix for 1-30DY01Q end

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CReportGenThread)
	// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	
	void OnGenerateReport(WPARAM wParam, LPARAM lParam);	//PSR - Fix for 1-30DY01Q


};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_REPORTGENTHREAD_H__48B37BC5_60CA_4F95_91A5_532657F9F522__INCLUDED_)

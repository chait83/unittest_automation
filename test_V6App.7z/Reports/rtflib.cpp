#include "RTFErrors.h"
#include "RTFGlobals.h"
#include "rtflib.h"
#include "StringUtils.h"

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif

RTF_DOCUMENT_FORMAT rtfDocasprintf;					// RTF document formatting params
RTF_SECTION_FORMAT rtfSecasprintf;					// RTF section formatting params
RTF_PARAGRAPH_FORMAT rtfParasprintf;					// RTF paragraph formatting params
RTF_TABLEROW_FORMAT rtfRowasprintf;					// RTF table row formatting params
RTF_TABLECELL_FORMAT rtfCellasprintf;					// RTF table cell formatting params

// RTF library global params
WCHAR rtfFontTable[4096] = "";
WCHAR rtfColorTable[4096] = "";
IPicture *rtfPicture = NULL;
const int CRTFLib::ms_iMAX_CELL_WIDTH = 9000;

//****************************************************************************
// CRTFLib( const bool bLETTER_PAGE_SIZE )
///
/// Constructor - Use me when writing RTF files as I set the correct paper size
///
/// @param[in]		const bool bLETTER_PAGE_SIZE - Flag indicating the page is is letter (true)
///					or A4 (false)
///
//****************************************************************************
CRTFLib::CRTFLib(const bool bLETTER_PAGE_SIZE) : CRecorderStorage(), m_ulMAX_READ_BUFF_LEN(0xFFFF), m_bLetterPageSize(
		bLETTER_PAGE_SIZE), m_iA4_WIDTH_IN_TWIPS(11907), m_iA4_HEIGHT_IN_TWIPS(16840), m_iLETTER_WIDTH_IN_TWIPS(12240), m_iLETTER_HEIGHT_IN_TWIPS(
		15840) {
	memset(rtfFontTable, 0, sizeof(WCHAR) * 4096);
	memset(rtfColorTable, 0, sizeof(WCHAR) * 4096);
}
//****************************************************************************
// CRTFLib( )
///
/// Default Constructor
///
//****************************************************************************
CRTFLib::CRTFLib() : CRecorderStorage(), m_ulMAX_READ_BUFF_LEN(0xFFFF), m_bLetterPageSize(false), m_iA4_WIDTH_IN_TWIPS(
		11907), m_iA4_HEIGHT_IN_TWIPS(16840), m_iLETTER_WIDTH_IN_TWIPS(12240), m_iLETTER_HEIGHT_IN_TWIPS(15840) {

}
// Creates new RTF document
int CRTFLib::rtf_open(const QString  &rstrFILENAME, const QString  &rstrFONTS, const QString  &rstrCOLOURS) {
	// Set error flag
	int error = RTF_SUCCESS;

	// Initialize global params
	rtf_init();

	// Set RTF document font table
	if (rstrFONTS != _T(""))
		rtf_set_fonttable(rstrFONTS);

	// Set RTF document color table
	if (rstrCOLOURS != "")
		rtf_set_colortable(rstrCOLOURS);

	// Create RTF document
	Open(rstrFILENAME,  | QFile::WriteOnly);

	if (m_hFile != NULL) {
		// Write RTF document header
		if (!rtf_write_header())
			error = RTF_HEADER_ERROR;

		// Write RTF document formatting properties
		if (!rtf_write_documentformat())
			error = RTF_DOCUMENTFORMAT_ERROR;

		// Create first RTF document section with default formatting
		rtf_write_sectionformat();
	} else
		error = RTF_OPEN_ERROR;

	// Return error flag
	return error;
}

// Closes created RTF document
int CRTFLib::rtf_close() {
	// Set error flag
	int error = RTF_SUCCESS;

	// Write RTF document end part
	WCHAR rtfText[1024];
	wcscpy_s(rtfText, 1024, L"\n\\par}");
	tempwrite(rtfText);

	WriteBuffer();

	// Free IPicture object
	if (rtfPicture != NULL) {
		rtfPicture->Release();
		rtfPicture = NULL;
	}

	// Close RTF document
	Close();
	//	error = RTF_CLOSE_ERROR;

	// Return error flag
	return error;
}
BOOL CRTFLib::WriteBuffer() {
	size_t pNoOfChars;
	QString  strConvertedData = ConvertUnicode(m_strBUFFER);
	char *ptNewBuff = new char[strConvertedData.size() + 50];
	wcstombs_s(&pNoOfChars, ptNewBuff, strConvertedData.size() + 50, strConvertedData.GetBuffer(0),
			strConvertedData.size() + 50);
	Write(ptNewBuff, static_cast<UINT>(strlen(ptNewBuff)));

	delete[] ptNewBuff;

	return TRUE;
}

// Writes RTF document header
bool CRTFLib::rtf_write_header() {
	// Set error flag
	bool result = true;

	// Standard RTF document header
	WCHAR rtfText[8192];
	wcscpy_s(rtfText, 8192, L"{\\rtf1\\ansi\\ansicpg1252\\deff0{\\fonttbl");
	wcscat_s(rtfText, 8192, rtfFontTable);
	wcscat_s(rtfText, 8192, L"}{\\colortbl");
	wcscat_s(rtfText, 8192, rtfColorTable);
	wcscat_s(rtfText, 8192, L"}{\\*\\generator HonRTF ver. 1.0;}");
	wcscat_s(rtfText, 8192, L"\n{\\info{\\author HonRTF ver. 1.0}{\\company Honeywell.}}");

	// Writes standard RTF document header part
	//if ( fwrite( rtfText, 1, strlen(rtfText), rtfFile ) < strlen(rtfText) )
	tempwrite(rtfText);
	//result = false;

	// Return error flag
	return result;
}

// Sets global RTF library params
void CRTFLib::rtf_init() {
	// Set RTF document default font table
	wcscpy_s(rtfFontTable, sizeof(rtfFontTable) / sizeof(WCHAR), "");
	wcscat_s(rtfFontTable, sizeof(rtfFontTable) / sizeof(WCHAR), L"{\\f0\\froman\\fcharset0\\cpg1252 Times New Roman}");
	wcscat_s(rtfFontTable, sizeof(rtfFontTable) / sizeof(WCHAR), L"{\\f1\\fswiss\\fcharset0\\cpg1252 Arial}");
	wcscat_s(rtfFontTable, sizeof(rtfFontTable) / sizeof(WCHAR), L"{\\f2\\fmodern\\fcharset0\\cpg1252 Courier New}");
	wcscat_s(rtfFontTable, sizeof(rtfFontTable) / sizeof(WCHAR), L"{\\f3\\fscript\\fcharset0\\cpg1252 Cursive}");
	wcscat_s(rtfFontTable, sizeof(rtfFontTable) / sizeof(WCHAR), L"{\\f4\\fdecor\\fcharset0\\cpg1252 Old English}");
	wcscat_s(rtfFontTable, sizeof(rtfFontTable) / sizeof(WCHAR), L"{\\f5\\ftech\\fcharset0\\cpg1252 Symbol}");
	wcscat_s(rtfFontTable, sizeof(rtfFontTable) / sizeof(WCHAR), L"{\\f6\\fbidi\\fcharset0\\cpg1252 Miriam}");

	// Set RTF document default color table
	wcscpy_s(rtfColorTable, sizeof(rtfColorTable) / sizeof(WCHAR), "");
	wcscat_s(rtfColorTable, sizeof(rtfColorTable) / sizeof(WCHAR), L"\\red0\\green0\\blue0;");
	wcscat_s(rtfColorTable, sizeof(rtfColorTable) / sizeof(WCHAR), L"\\red255\\green0\\blue0;");
	wcscat_s(rtfColorTable, sizeof(rtfColorTable) / sizeof(WCHAR), L"\\red0\\green255\\blue0;");
	wcscat_s(rtfColorTable, sizeof(rtfColorTable) / sizeof(WCHAR), L"\\red0\\green0\\blue255;");
	wcscat_s(rtfColorTable, sizeof(rtfColorTable) / sizeof(WCHAR), L"\\red255\\green255\\blue0;");
	wcscat_s(rtfColorTable, sizeof(rtfColorTable) / sizeof(WCHAR), L"\\red255\\green0\\blue255;");
	wcscat_s(rtfColorTable, sizeof(rtfColorTable) / sizeof(WCHAR), L"\\red0\\green255\\blue255;");
	wcscat_s(rtfColorTable, sizeof(rtfColorTable) / sizeof(WCHAR), L"\\red255\\green255\\blue255;");
	wcscat_s(rtfColorTable, sizeof(rtfColorTable) / sizeof(WCHAR), L"\\red128\\green0\\blue0;");
	wcscat_s(rtfColorTable, sizeof(rtfColorTable) / sizeof(WCHAR), L"\\red0\\green128\\blue0;");
	wcscat_s(rtfColorTable, sizeof(rtfColorTable) / sizeof(WCHAR), L"\\red0\\green0\\blue128;");
	wcscat_s(rtfColorTable, sizeof(rtfColorTable) / sizeof(WCHAR), L"\\red128\\green128\\blue0;");
	wcscat_s(rtfColorTable, sizeof(rtfColorTable) / sizeof(WCHAR), L"\\red128\\green0\\blue128;");
	wcscat_s(rtfColorTable, sizeof(rtfColorTable) / sizeof(WCHAR), L"\\red0\\green128\\blue128;");
	wcscat_s(rtfColorTable, sizeof(rtfColorTable) / sizeof(WCHAR), L"\\red128\\green128\\blue128;");

	// Set default formatting
	rtf_set_defaultformat();
}

// Sets default RTF document formatting
void CRTFLib::rtf_set_defaultformat() {
	// Set default RTF document formatting properties
	RTF_DOCUMENT_FORMAT df = { RTF_DOCUMENTVIEWKIND_PAGE, 100, 12240, 15840, 1800, 1800, 1440, 1440, false, 0, false };

	// Set default RTF section formatting properties
	RTF_SECTION_FORMAT sf = { RTF_SECTIONBREAK_CONTINUOUS, false, true, 12240, 15840, 1800, 1800, 1440, 1440, 0, 720,
			720, false, 720, 720, false, 1, 720, false };

	// check if letter or A4
	if (m_bLetterPageSize) {
		df.paperWidth = 12240;
		df.paperHeight = 15840;
		sf.pageWidth = 12240;
		sf.pageHeight = 15840;
	} else {
		df.paperWidth = 11907;
		df.paperHeight = 16840;
		sf.pageWidth = 11907;
		sf.pageHeight = 16840;
	}

	rtf_set_documentformat(&df);
	rtf_set_sectionformat(&sf);

	// Set default RTF paragraph formatting properties
	//RTF_PARAGRAPH_FORMAT pf = {RTF_PARAGRAPHBREAK_NONE, false, true, RTF_PARAGRAPHALIGN_LEFT, 0, 0, 0, 0, 0, 0, QString   ::fromWCharArray(""), false, false, false, false, false, false};
	RTF_PARAGRAPH_FORMAT pf;
	pf.paragraphBreak = RTF_PARAGRAPHBREAK_NONE;
	pf.newParagraph = false;
	pf.newHeader = false;
	pf.newFooter = false;
	pf.defaultParagraph = true;
	pf.paragraphAligment = RTF_PARAGRAPHALIGN_LEFT;
	pf.firstLineIndent = 0;
	pf.leftIndent = 0;
	pf.rightIndent = 0;
	pf.spaceBefore = 0;
	pf.spaceAfter = 0;
	pf.lineSpacing = 0;
	pf.paragraphText = "";
	pf.tabbedText = false;
	pf.tableText = false;
	pf.bInsertPageNo = false;
	pf.paragraphTabs = false;
	pf.paragraphNums = false;
	pf.paragraphBorders = false;
	pf.paragraphShading = false;

	pf.BORDERS.borderColor = 0;
	pf.BORDERS.borderKind = RTF_PARAGRAPHBORDERKIND_NONE;
	pf.BORDERS.borderSpace = 0;
	pf.BORDERS.borderType = RTF_PARAGRAPHBORDERTYPE_STHICK;
	pf.BORDERS.borderWidth = 0;
	pf.CHARACTER.animatedCharacter = false;
	pf.CHARACTER.backgroundColor = 0;
	pf.CHARACTER.boldCharacter = false;
	pf.CHARACTER.capitalCharacter = false;
	pf.CHARACTER.doublestrikeCharacter = false;
	pf.CHARACTER.embossCharacter = false;
	pf.CHARACTER.engraveCharacter = false;
	pf.CHARACTER.expandCharacter = 0;
	pf.CHARACTER.fontNumber = 0;
	pf.CHARACTER.fontSize = 20;
	pf.CHARACTER.foregroundColor = 0;
	pf.CHARACTER.italicCharacter = false;
	pf.CHARACTER.kerningCharacter = 0;
	pf.CHARACTER.outlineCharacter = false;
	pf.CHARACTER.scaleCharacter = 100;
	pf.CHARACTER.shadowCharacter = false;
	pf.CHARACTER.smallcapitalCharacter = false;
	pf.CHARACTER.strikeCharacter = false;
	pf.CHARACTER.subscriptCharacter = false;
	pf.CHARACTER.superscriptCharacter = false;
	pf.CHARACTER.underlineCharacter = 0;
	pf.NUMS.numsChar = WCHAR(0x95);
	pf.NUMS.numsLevel = 11;
	pf.NUMS.numsSpace = 360;
	pf.SHADING.shadingBkColor = 0;
	pf.SHADING.shadingFillColor = 0;
	pf.SHADING.shadingIntensity = 0;
	pf.SHADING.shadingType = RTF_PARAGRAPHSHADINGTYPE_FILL;
	pf.TABS.tabKind = RTF_PARAGRAPHTABKIND_NONE;
	pf.TABS.tabLead = RTF_PARAGRAPHTABLEAD_NONE;
	pf.TABS.tabPosition = 0;
	rtf_set_paragraphformat(&pf);

	// Set default RTF table row formatting properties
	RTF_TABLEROW_FORMAT rf = { RTF_ROWTEXTALIGN_LEFT, 0, 0, 0, 0, 0, 0 };
	rtf_set_tablerowformat(&rf);

	// Set default RTF table cell formatting properties
	RTF_TABLECELL_FORMAT cf = { RTF_CELLTEXTALIGN_CENTER, 0, 0, 0, 0, RTF_CELLTEXTDIRECTION_LRTB, false };
	cf.SHADING.shadingBkColor = 0;
	cf.SHADING.shadingFillColor = 0;
	cf.SHADING.shadingIntensity = 0;
	cf.SHADING.shadingType = RTF_PARAGRAPHSHADINGTYPE_FILL;
	cf.borderBottom.border = false;
	cf.borderBottom.BORDERS.borderColor = 0;
	cf.borderBottom.BORDERS.borderKind = RTF_PARAGRAPHBORDERKIND_NONE;
	cf.borderBottom.BORDERS.borderSpace = 0;
	cf.borderBottom.BORDERS.borderType = RTF_PARAGRAPHBORDERTYPE_STHICK;
	cf.borderBottom.BORDERS.borderWidth = 5;
	cf.borderleft.border = false;
	cf.borderleft.BORDERS.borderColor = 0;
	cf.borderleft.BORDERS.borderKind = RTF_PARAGRAPHBORDERKIND_NONE;
	cf.borderleft.BORDERS.borderSpace = 0;
	cf.borderleft.BORDERS.borderType = RTF_PARAGRAPHBORDERTYPE_STHICK;
	cf.borderleft.BORDERS.borderWidth = 5;
	cf.borderright.border = false;
	cf.borderright.BORDERS.borderColor = 0;
	cf.borderright.BORDERS.borderKind = RTF_PARAGRAPHBORDERKIND_NONE;
	cf.borderright.BORDERS.borderSpace = 0;
	cf.borderright.BORDERS.borderType = RTF_PARAGRAPHBORDERTYPE_STHICK;
	cf.borderright.BORDERS.borderWidth = 5;
	cf.borderTop.border = false;
	cf.borderTop.BORDERS.borderColor = 0;
	cf.borderTop.BORDERS.borderKind = RTF_PARAGRAPHBORDERKIND_NONE;
	cf.borderTop.BORDERS.borderSpace = 0;
	cf.borderTop.BORDERS.borderType = RTF_PARAGRAPHBORDERTYPE_STHICK;
	cf.borderTop.BORDERS.borderWidth = 5;
	rtf_set_tablecellformat(&cf);
}

// Sets new RTF document font table
void CRTFLib::rtf_set_fonttable(const QString  &rstrFONTS) {
	// Clear old font table
	wcscpy_s(rtfFontTable, sizeof(rtfFontTable) / sizeof(WCHAR), "");

	// Set separator list
	//WCHAR separator[] = ";";

	// Create new RTF document font table
	int font_number = 0;

	/*WCHAR* token = strtok( rstrFONTS.GetBuffer( ), separator );
	 while ( token != NULL )
	 {
	 // asprintf font table entry
	 swprintf( font_table_entry, "{\\f%d\\fnil\\fWCHARset0\\cpg1252 %s}", font_number, token );
	 wcscat( rtfFontTable, font_table_entry );

	 // Get next font
	 token = strtok( NULL, separator );
	 font_number++;
	 }*/
	int iDelimPos = 0;
	QString  strFonts(rstrFONTS);
	QString  strFontTables("");
	QString  strFontTable("");
	while ((iDelimPos = strFonts.indexOf(L';')) != -1) {
		strFontTable.asprintf(L"{\\f%d\\fnil\\fcharset0\\cpg1252 %s}", font_number, strFonts.left(iDelimPos));
		strFontTables += strFontTable;
		strFonts.Delete(0, iDelimPos + 1);
		font_number++;
	}
	swprintf(rtfFontTable, strFontTables.GetBuffer(0));
}

// Sets new RTF document color table
void CRTFLib::rtf_set_colortable(const QString  &rstrCOLOURS) {
	// Clear old color table
	wcscpy_s(rtfColorTable, sizeof(rtfColorTable) / sizeof(WCHAR), "");

	// Set separator list
	WCHAR separator[] = L";";

	// Create new RTF document color table
	int color_number = 0;

	int iDelimPos = 0;
	QString  strColours(rstrCOLOURS);
	QString  strColourTables("");
	QString  strColourTable("");
	while ((iDelimPos = strColours.indexOf(L';')) != -1) {
		// Red
		strColourTable.asprintf(L"\\red%s", strColours.left(iDelimPos));
		strColourTables += strColourTable;

		strColours.Delete(0, iDelimPos + 1);

		// Green
		iDelimPos = strColours.indexOf(L';');
		if (iDelimPos != -1) {
			strColourTable.asprintf(L"\\green%s", strColours.left(iDelimPos));

			strColourTables += strColourTable;

			strColours.Delete(0, iDelimPos + 1);
		}

		// Blue
		iDelimPos = strColours.indexOf(L';');
		if (iDelimPos != -1) {
			strColourTable.asprintf(L"\\blue%s;", strColours.left(iDelimPos));

			strColourTables += strColourTable;

			strColours.Delete(0, iDelimPos + 1);
		}
		color_number++;
	}

	swprintf(rtfColorTable, strColourTables.GetBuffer(0));
	//wcscolor_table_entry, strColourTables.toLocal8Bit().data() );

	//wcstombs( color_table_entry, wcscolor_table_entry, 1024 ); 

	/*
	 WCHAR* token = strtok( rstrCOLOURS.toLocal8Bit().data(), separator );
	 while ( token != NULL )
	 {
	 // Red
	 sprintf( color_table_entry, "\\red%s", token );
	 wcscat( rtfColorTable, color_table_entry );

	 // Green
	 token = strtok( NULL, separator );
	 if ( token != NULL )
	 {
	 sprintf( color_table_entry, "\\green%s", token );
	 wcscat( rtfColorTable, color_table_entry );
	 }

	 // Blue
	 token = strtok( NULL, separator );
	 if ( token != NULL )
	 {
	 sprintf( color_table_entry, "\\blue%s;", token );
	 wcscat( rtfColorTable, color_table_entry );
	 }

	 // Get next color
	 token = strtok( NULL, separator );
	 color_number++;
	 }*/
}

// Sets RTF document formatting properties
void CRTFLib::rtf_set_documentformat(RTF_DOCUMENT_FORMAT *df) {
	// Set new RTF document formatting properties
	memcpy(&rtfDocasprintf, df, sizeof(RTF_DOCUMENT_FORMAT));
}

// Writes RTF document formatting properties
bool CRTFLib::rtf_write_documentformat() {
	// Set error flag
	bool result = true;

	// RTF document text
	WCHAR rtfText[1024];
	wcscpy_s(rtfText, sizeof(rtfText) / sizeof(WCHAR), "");

	swprintf(rtfText, L"\\viewkind%d\\viewscale%d\\paperw%d\\paperh%d\\margl%d\\margr%d\\margt%d\\margb%d\\gutter%d",
			rtfDocasprintf.viewKind, rtfDocasprintf.viewScale, rtfDocasprintf.paperWidth, rtfDocasprintf.paperHeight,
			rtfDocasprintf.marginleft, rtfDocasprintf.marginright, rtfDocasprintf.marginTop, rtfDocasprintf.marginBottom,
			rtfDocasprintf.gutterWidth);

	if (rtfDocasprintf.facingPages)
		wcscat_s(rtfText, sizeof(rtfText) / sizeof(WCHAR), L"\\facingp");
	if (rtfDocasprintf.readOnly)
		wcscat_s(rtfText, sizeof(rtfText) / sizeof(WCHAR), L"\\annotprot");

	// Writes RTF document formatting properties
	tempwrite(rtfText);
	//result = false;

	// Return error flag
	return result;
}

// Sets RTF section formatting properties
void CRTFLib::rtf_set_sectionformat(RTF_SECTION_FORMAT *sf) {
	// Set new RTF section formatting properties
	memcpy(&rtfSecasprintf, sf, sizeof(RTF_SECTION_FORMAT));
}

// Writes RTF section formatting properties
bool CRTFLib::rtf_write_sectionformat() {
	// Set error flag
	bool result = true;

	// RTF document text
	WCHAR rtfText[1024];
	wcscpy_s(rtfText, sizeof(rtfText) / sizeof(WCHAR), "");

	// asprintf new section
	WCHAR text[1024] = "", pgn[100] = "";
	if (rtfSecasprintf.newSection)
		wcscat_s(text, sizeof(rtfText) / sizeof(WCHAR), L"\\sect");
	if (rtfSecasprintf.defaultSection)
		wcscat_s(text, sizeof(rtfText) / sizeof(WCHAR), L"\\sectd");
	if (rtfSecasprintf.showPageNumber) {
		swprintf(pgn, L"\\pgnx%d\\pgny%d", rtfSecasprintf.pageNumberOffsetX, rtfSecasprintf.pageNumberOffsetY);
		wcscat_s(text, sizeof(text) / sizeof(WCHAR), pgn);
	}

	// asprintf section break
	WCHAR sbr[100] = "";
	switch (rtfSecasprintf.sectionBreak) {
	// Continuous break
	case RTF_SECTIONBREAK_CONTINUOUS:
		wcscat_s(sbr, sizeof(sbr) / sizeof(WCHAR), L"\\sbknone");
		break;

		// Column break
	case RTF_SECTIONBREAK_COLUMN:
		wcscat_s(sbr, sizeof(sbr) / sizeof(WCHAR), L"\\sbkcol");
		break;

		// Page break
	case RTF_SECTIONBREAK_PAGE:
		wcscat_s(sbr, sizeof(sbr) / sizeof(WCHAR), L"\\sbkpage");
		break;

		// Even-page break
	case RTF_SECTIONBREAK_EVENPAGE:
		wcscat_s(sbr, sizeof(sbr) / sizeof(WCHAR), L"\\sbkeven");
		break;

		// Odd-page break
	case RTF_SECTIONBREAK_ODDPAGE:
		wcscat_s(sbr, sizeof(sbr) / sizeof(WCHAR), L"\\sbkodd");
		break;
	}

	// asprintf section columns
	WCHAR cols[100] = "";
	if (rtfSecasprintf.cols == true) {
		// asprintf columns
		swprintf(cols, L"\\cols%d\\colsx%d", rtfSecasprintf.colsNumber, rtfSecasprintf.colsDistance);

		if (rtfSecasprintf.colsLineBetween)
			wcscat_s(cols, 100, L"\\linebetcol");
	}

	swprintf(rtfText,
			L"\n%s%s%s\\pgwsxn%d\\pghsxn%d\\marglsxn%d\\margrsxn%d\\margtsxn%d\\margbsxn%d\\guttersxn%d\\headery%d\\footery%d",
			text, sbr, cols, rtfSecasprintf.pageWidth, rtfSecasprintf.pageHeight, rtfSecasprintf.pageMarginleft,
			rtfSecasprintf.pageMarginright, rtfSecasprintf.pageMarginTop, rtfSecasprintf.pageMarginBottom,
			rtfSecasprintf.pageGutterWidth, rtfSecasprintf.pageHeaderOffset, rtfSecasprintf.pageFooterOffset);

	// Writes RTF section formatting properties
	tempwrite(rtfText);
//		result = false;

	// Return error flag
	return result;
}

// Starts new RTF section
int CRTFLib::rtf_start_section() {
	// Set error flag
	int error = RTF_SUCCESS;

	// Set new section flag
	rtfSecasprintf.newSection = true;

	// Starts new RTF section
	if (!rtf_write_sectionformat())
		error = RTF_SECTIONFORMAT_ERROR;

	// Return error flag
	return error;
}

// Sets RTF paragraph formatting properties
void CRTFLib::rtf_set_paragraphformat(RTF_PARAGRAPH_FORMAT *pf) {
	// Set new RTF paragraph formatting properties
	memcpy(&rtfParasprintf, pf, sizeof(RTF_PARAGRAPH_FORMAT));
}

// Writes RTF paragraph formatting properties
bool CRTFLib::rtf_write_paragraphformat() {
	// Set error flag
	bool result = true;

	// RTF document text
	WCHAR rtfText[4096];
	wcscpy_s(rtfText, sizeof(rtfText) / sizeof(WCHAR), "");

	// asprintf new paragraph
	WCHAR text[1024] = "";
	if (rtfParasprintf.newHeader) {
		wcscat_s(text, sizeof(text) / sizeof(WCHAR), L"{ \\header");
	}

	if (rtfParasprintf.newFooter) {
		wcscat_s(text, sizeof(text) / sizeof(WCHAR), L"{ \\footer");
	}

	if (rtfParasprintf.newParagraph)
		wcscat_s(text, sizeof(text) / sizeof(WCHAR), L"\\par");
	if (rtfParasprintf.defaultParagraph)
		wcscat_s(text, sizeof(text) / sizeof(WCHAR), L"\\pard");
	if (rtfParasprintf.tableText == false)
		wcscat_s(text, sizeof(text) / sizeof(WCHAR), L"\\plain");
	else
		wcscat_s(text, sizeof(text) / sizeof(WCHAR), L"\\intbl");

	switch (rtfParasprintf.paragraphBreak) {
	// No break
	case RTF_PARAGRAPHBREAK_NONE:
		break;

		// Page break;
	case RTF_PARAGRAPHBREAK_PAGE:
		wcscat_s(text, sizeof(text) / sizeof(WCHAR), L"\\page");
		break;

		// Column break;
	case RTF_PARAGRAPHBREAK_COLUMN:
		wcscat_s(text, sizeof(text) / sizeof(WCHAR), L"\\column");
		break;

		// Line break;
	case RTF_PARAGRAPHBREAK_LINE:
		wcscat_s(text, sizeof(text) / sizeof(WCHAR), L"\\line");
		break;
	}

	// asprintf aligment
	switch (rtfParasprintf.paragraphAligment) {
	// left aligned paragraph
	case RTF_PARAGRAPHALIGN_LEFT:
		wcscat_s(text, sizeof(text) / sizeof(WCHAR), L"\\ql");
		break;

		// Center aligned paragraph
	case RTF_PARAGRAPHALIGN_CENTER:
		wcscat_s(text, sizeof(text) / sizeof(WCHAR), L"\\qc");
		break;

		// right aligned paragraph
	case RTF_PARAGRAPHALIGN_RIGHT:
		wcscat_s(text, sizeof(text) / sizeof(WCHAR), L"\\qr");
		break;

		// Justified aligned paragraph
	case RTF_PARAGRAPHALIGN_JUSTIFY:
		wcscat_s(text, sizeof(text) / sizeof(WCHAR), L"\\qj");
		break;
	}

	// asprintf tabs
	if (rtfParasprintf.paragraphTabs == true) {
		// Set tab kind
		switch (rtfParasprintf.TABS.tabKind) {
		// No tab
		case RTF_PARAGRAPHTABKIND_NONE:
			break;

			// Centered tab
		case RTF_PARAGRAPHTABKIND_CENTER:
			wcscat_s(text, sizeof(text) / sizeof(WCHAR), L"\\tqc");
			break;

			// Flush-right tab
		case RTF_PARAGRAPHTABKIND_RIGHT:
			wcscat_s(text, sizeof(text) / sizeof(WCHAR), L"\\tqr");
			break;

			// Decimal tab
		case RTF_PARAGRAPHTABKIND_DECIMAL:
			wcscat_s(text, sizeof(text) / sizeof(WCHAR), L"\\tqdec");
			break;
		}

		// Set tab leader
		switch (rtfParasprintf.TABS.tabLead) {
		// No lead
		case RTF_PARAGRAPHTABLEAD_NONE:
			break;

			// Leader dots
		case RTF_PARAGRAPHTABLEAD_DOT:
			wcscat_s(text, sizeof(text) / sizeof(WCHAR), L"\\tldot");
			break;

			// Leader middle dots
		case RTF_PARAGRAPHTABLEAD_MDOT:
			wcscat_s(text, sizeof(text) / sizeof(WCHAR), L"\\tlmdot");
			break;

			// Leader hyphens
		case RTF_PARAGRAPHTABLEAD_HYPH:
			wcscat_s(text, sizeof(text) / sizeof(WCHAR), L"\\tlhyph");
			break;

			// Leader underline
		case RTF_PARAGRAPHTABLEAD_UNDERLINE:
			wcscat_s(text, sizeof(text) / sizeof(WCHAR), L"\\tlul");
			break;

			// Leader thick line
		case RTF_PARAGRAPHTABLEAD_THICKLINE:
			wcscat_s(text, sizeof(text) / sizeof(WCHAR), L"\\tlth");
			break;

			// Leader equal sign
		case RTF_PARAGRAPHTABLEAD_EQUAL:
			wcscat_s(text, sizeof(text) / sizeof(WCHAR), L"\\tleq");
			break;
		}

		// Set tab position
		WCHAR tb[10];
		swprintf(tb, L"\\tx%d", rtfParasprintf.TABS.tabPosition);
		wcscat_s(text, sizeof(text) / sizeof(WCHAR), tb);
	}

	// asprintf bullets and numbering
	if (rtfParasprintf.paragraphNums == true) {
		WCHAR nums[1024];
		swprintf(nums, L"{\\*\\pn\\pnlvl%d\\pnsp%d\\pntxtb %c}", rtfParasprintf.NUMS.numsLevel,
				rtfParasprintf.NUMS.numsSpace, rtfParasprintf.NUMS.numsChar);
		wcscat_s(text, sizeof(text) / sizeof(WCHAR), nums);
	}

	// asprintf paragraph borders
	if (rtfParasprintf.paragraphBorders == true) {
		WCHAR border[1024] = "";

		// asprintf paragraph border kind
		switch (rtfParasprintf.BORDERS.borderKind) {
		// No border
		case RTF_PARAGRAPHBORDERKIND_NONE:
			break;

			// Border top
		case RTF_PARAGRAPHBORDERKIND_TOP:
			wcscat_s(border, sizeof(border) / sizeof(WCHAR), L"\\brdrt");
			break;

			// Border bottom
		case RTF_PARAGRAPHBORDERKIND_BOTTOM:
			wcscat_s(border, sizeof(border) / sizeof(WCHAR), L"\\brdrb");
			break;

			// Border left
		case RTF_PARAGRAPHBORDERKIND_LEFT:
			wcscat_s(border, sizeof(border) / sizeof(WCHAR), L"\\brdrl");
			break;

			// Border right
		case RTF_PARAGRAPHBORDERKIND_RIGHT:
			wcscat_s(border, sizeof(border) / sizeof(WCHAR), L"\\brdrr");
			break;

			// Border box
		case RTF_PARAGRAPHBORDERKIND_BOX:
			wcscat_s(border, sizeof(border) / sizeof(WCHAR), L"\\box");
			break;
		}

		// asprintf paragraph border type
		QString  strBorder(rtf_get_bordername(rtfParasprintf.BORDERS.borderType));
		wcscat_s(border, sizeof(border) / sizeof(WCHAR), strBorder.GetBuffer(0));

		// Set paragraph border width
		WCHAR brd[100];
		swprintf(brd, L"\\brdrw%d\\brsp%d", rtfParasprintf.BORDERS.borderWidth, rtfParasprintf.BORDERS.borderSpace);
		wcscat_s(border, sizeof(border) / sizeof(WCHAR), brd);
		wcscat_s(text, sizeof(text) / sizeof(WCHAR), border);

		// Set paragraph border color
		WCHAR brdcol[100];
		swprintf(brdcol, L"\\brdrcf%d", rtfParasprintf.BORDERS.borderColor);
		wcscat_s(text, sizeof(text) / sizeof(WCHAR), brdcol);
	}

	// asprintf paragraph shading
	if (rtfParasprintf.paragraphShading == true) {
		WCHAR shading[100];
		swprintf(shading, L"\\shading%d", rtfParasprintf.SHADING.shadingIntensity);

		// asprintf paragraph shading
		QString  strShading = rtf_get_shadingname(rtfParasprintf.SHADING.shadingType, false);
		wcscat_s(text, sizeof(text) / sizeof(WCHAR), strShading.GetBuffer(0));

		// Set paragraph shading color
		WCHAR shcol[100];
		swprintf(shcol, L"\\cfpat%d\\cbpat%d", rtfParasprintf.SHADING.shadingFillColor,
				rtfParasprintf.SHADING.shadingBkColor);
		wcscat_s(text, sizeof(text) / sizeof(WCHAR), shcol);
	}

	// asprintf paragraph font
	WCHAR font[1024] = "";
	swprintf(font, L"\\animtext%d\\expndtw%d\\kerning%d\\charscalex%d\\f%d\\fs%d\\cf%d",
			rtfParasprintf.CHARACTER.animatedCharacter, rtfParasprintf.CHARACTER.expandCharacter,
			rtfParasprintf.CHARACTER.kerningCharacter, rtfParasprintf.CHARACTER.scaleCharacter,
			rtfParasprintf.CHARACTER.fontNumber, rtfParasprintf.CHARACTER.fontSize, rtfParasprintf.CHARACTER.foregroundColor);
	if (rtfParasprintf.CHARACTER.boldCharacter)
		wcscat_s(font, sizeof(font) / sizeof(WCHAR), L"\\b");
	else
		wcscat_s(font, sizeof(font) / sizeof(WCHAR), L"\\b0");
	if (rtfParasprintf.CHARACTER.capitalCharacter)
		wcscat_s(font, sizeof(font) / sizeof(WCHAR), L"\\caps");
	else
		wcscat_s(font, sizeof(font) / sizeof(WCHAR), L"\\caps0");
	if (rtfParasprintf.CHARACTER.doublestrikeCharacter)
		wcscat_s(font, sizeof(font) / sizeof(WCHAR), L"\\striked1");
	else
		wcscat_s(font, sizeof(font) / sizeof(WCHAR), L"\\striked0");
	if (rtfParasprintf.CHARACTER.embossCharacter)
		wcscat_s(font, sizeof(font) / sizeof(WCHAR), L"\\embo");
	if (rtfParasprintf.CHARACTER.engraveCharacter)
		wcscat_s(font, sizeof(font) / sizeof(WCHAR), L"\\impr");
	if (rtfParasprintf.CHARACTER.italicCharacter)
		wcscat_s(font, sizeof(font) / sizeof(WCHAR), L"\\i");
	else
		wcscat_s(font, sizeof(font) / sizeof(WCHAR), L"\\i0");
	if (rtfParasprintf.CHARACTER.outlineCharacter)
		wcscat_s(font, sizeof(font) / sizeof(WCHAR), L"\\outl");
	else
		wcscat_s(font, sizeof(font) / sizeof(WCHAR), L"\\outl0");
	if (rtfParasprintf.CHARACTER.shadowCharacter)
		wcscat_s(font, sizeof(font) / sizeof(WCHAR), L"\\shad");
	else
		wcscat_s(font, sizeof(font) / sizeof(WCHAR), L"\\shad0");
	if (rtfParasprintf.CHARACTER.smallcapitalCharacter)
		wcscat_s(font, sizeof(font) / sizeof(WCHAR), L"\\scaps");
	else
		wcscat_s(font, sizeof(font) / sizeof(WCHAR), L"\\scaps0");
	if (rtfParasprintf.CHARACTER.strikeCharacter)
		wcscat_s(font, sizeof(font) / sizeof(WCHAR), L"\\strike");
	else
		wcscat_s(font, sizeof(font) / sizeof(WCHAR), L"\\strike0");
	if (rtfParasprintf.CHARACTER.subscriptCharacter)
		wcscat_s(font, sizeof(font) / sizeof(WCHAR), L"\\sub");
	if (rtfParasprintf.CHARACTER.superscriptCharacter)
		wcscat_s(font, sizeof(font) / sizeof(WCHAR), L"\\super");

	// check if we must insert the page number
	if (rtfParasprintf.bInsertPageNo == true) {
		wcscat_s(font, sizeof(font) / sizeof(WCHAR), L"\\chpgn");
	}

	switch (rtfParasprintf.CHARACTER.underlineCharacter) {
	// None underline
	case 0:
		wcscat_s(font, sizeof(font) / sizeof(WCHAR), L"\\ulnone");
		break;

		// Continuous underline
	case 1:
		wcscat_s(font, sizeof(font) / sizeof(WCHAR), L"\\ul");
		break;

		// Dotted underline
	case 2:
		wcscat_s(font, sizeof(font) / sizeof(WCHAR), L"\\uld");
		break;

		// Dashed underline
	case 3:
		wcscat_s(font, sizeof(font) / sizeof(WCHAR), L"\\uldash");
		break;

		// Dash-dotted underline
	case 4:
		wcscat_s(font, sizeof(font) / sizeof(WCHAR), L"\\uldashd");
		break;

		// Dash-dot-dotted underline
	case 5:
		wcscat_s(font, sizeof(font) / sizeof(WCHAR), L"\\uldashdd");
		break;

		// Double underline
	case 6:
		wcscat_s(font, sizeof(font) / sizeof(WCHAR), L"\\uldb");
		break;

		// Heavy wave underline
	case 7:
		wcscat_s(font, sizeof(font) / sizeof(WCHAR), L"\\ulhwave");
		break;

		// Long dashed underline
	case 8:
		wcscat_s(font, sizeof(font) / sizeof(WCHAR), L"\\ulldash");
		break;

		// Thick underline
	case 9:
		wcscat_s(font, sizeof(font) / sizeof(WCHAR), L"\\ulth");
		break;

		// Thick dotted underline
	case 10:
		wcscat_s(font, sizeof(font) / sizeof(WCHAR), L"\\ulthd");
		break;

		// Thick dashed underline
	case 11:
		wcscat_s(font, sizeof(font) / sizeof(WCHAR), L"\\ulthdash");
		break;

		// Thick dash-dotted underline
	case 12:
		wcscat_s(font, sizeof(font) / sizeof(WCHAR), L"\\ulthdashd");
		break;

		// Thick dash-dot-dotted underline
	case 13:
		wcscat_s(font, sizeof(font) / sizeof(WCHAR), L"\\ulthdashdd");
		break;

		// Thick long dashed underline
	case 14:
		wcscat_s(font, sizeof(font) / sizeof(WCHAR), L"\\ulthldash");
		break;

		// Double wave underline
	case 15:
		wcscat_s(font, sizeof(font) / sizeof(WCHAR), L"\\ululdbwave");
		break;

		// Word underline
	case 16:
		wcscat_s(font, sizeof(font) / sizeof(WCHAR), L"\\ulw");
		break;

		// Wave underline
	case 17:
		wcscat_s(font, sizeof(font) / sizeof(WCHAR), L"\\ulwave");
		break;
	}

	WCHAR txt[20] = "";
	// Set paragraph tabbed text
	if (rtfParasprintf.tabbedText == false) {
		swprintf(rtfText, L"\n%s\\fi%d\\li%d\\ri%d\\sb%d\\sa%d\\sl%d%s %s", text, rtfParasprintf.firstLineIndent,
				rtfParasprintf.leftIndent, rtfParasprintf.rightIndent, rtfParasprintf.spaceBefore, rtfParasprintf.spaceAfter,
				rtfParasprintf.lineSpacing, font, rtfParasprintf.paragraphText);
	} else
		swprintf(rtfText, L"\\tab %s", rtfParasprintf.paragraphText);

	// Writes RTF paragraph formatting properties
	tempwrite(rtfText);
//		result = false;

	// Return error flag
	return result;
}

// Starts new RTF paragraph
int CRTFLib::rtf_start_paragraph(const QString  &rstrTEXT, bool newPar) {
	// Set error flag
	int error = RTF_SUCCESS;

	// Copy paragraph text
	rtfParasprintf.paragraphText = rstrTEXT;	//new WCHAR[strlen(text)];
//	wcscpy( rtfParasprintf.paragraphText, text );

	// Set new paragraph
	rtfParasprintf.newParagraph = newPar;

	// Starts new RTF paragraph
	if (!rtf_write_paragraphformat())
		error = RTF_PARAGRAPHFORMAT_ERROR;

	// Return error flag
	return error;
}

// Gets RTF document formatting properties
RTF_DOCUMENT_FORMAT* CRTFLib::rtf_get_documentformat() {
	// Get current RTF document formatting properties
	return &rtfDocasprintf;
}

// Gets RTF section formatting properties
RTF_SECTION_FORMAT* CRTFLib::rtf_get_sectionformat() {
	// Get current RTF section formatting properties
	return &rtfSecasprintf;
}

// Gets RTF paragraph formatting properties
RTF_PARAGRAPH_FORMAT* CRTFLib::rtf_get_paragraphformat() {
	// Get current RTF paragraph formatting properties
	return &rtfParasprintf;
}

// Loads image from file
int CRTFLib::rtf_load_image(QString image, int width, int height) {
	// Set error flag
	int error = RTF_SUCCESS;
	/*
	 // Free IPicture object
	 if ( rtfPicture != NULL )
	 {
	 rtfPicture->Release();
	 rtfPicture = NULL;
	 }

	 // Read image file
	 int imageFile = _open( image, _O_RDONLY | _O_BINARY );
	 struct _stat st;
	 _fstat( imageFile, &st );
	 DWORD nSize = st.st_size;
	 BYTE* pBuff = new BYTE[nSize];
	 _read( imageFile, pBuff, nSize );
	 // Alocate memory for image data
	 HGLOBAL hGlobal = GlobalAlloc(GMEM_MOVEABLE, nSize);
	 void* pData = GlobalLock(hGlobal);
	 memcpy(pData, pBuff, nSize);
	 GlobalUnlock(hGlobal);
	 // Load image using OLE
	 IStream* pStream = NULL;
	 if ( CreateStreamOnHGlobal(hGlobal, TRUE, &pStream) == S_OK )
	 {
	 HRESULT hr;
	 if ((hr = OleLoadPicture( pStream, nSize, FALSE, IID_IPicture, (LPVOID *)&rtfPicture)) != S_OK)
	 error = RTF_IMAGE_ERROR;

	 pStream->Release();
	 }
	 delete []pBuff;
	 _close(imageFile);

	 // If image is loaded
	 if ( rtfPicture != NULL )
	 {
	 // Calculate image size
	 long hmWidth;
	 long hmHeight;
	 rtfPicture->get_Width(&hmWidth);
	 rtfPicture->get_Height(&hmHeight);
	 int nWidth	= MulDiv( hmWidth, GetDeviceCaps(GetDC(NULL),LOGPIXE



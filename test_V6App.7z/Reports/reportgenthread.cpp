/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Report system
/// @n Filename:  ReportGenThread.cpp
/// @n Description: Implementation of the CReportGenThread class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  5 Stability Project 1.0.1.3 7/2/2011 5:00:24 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  4 Stability Project 1.0.1.2 7/1/2011 4:38:49 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  3 Stability Project 1.0.1.1 3/17/2011 3:20:41 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  2 Stability Project 1.0.1.0 2/15/2011 3:03:51 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// **************************************************************************

#include "..\V6App\V6App.h"
#include "reportgenthread.h"
#include "RTFLib.h"
#include "RTFGlobals.h"
#include "SMTPThread.h"
#include "ReportManager.h"

#include "..\\UIControl\\Printer.h"
#include "..\\UIControl\\Print.h"
#include "..\\UIControl\\EditPrint.h"

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif

// IMPLEMENT_DYNCREATE(CReportGenThread, QThread)

//****************************************************************************
// CReportGenThread( )
///
/// Constructor
///
//****************************************************************************
CReportGenThread::CReportGenThread()
{
}
//****************************************************************************
// ~CReportGenThread( )
///
/// Destructor
///
//****************************************************************************
CReportGenThread::~CReportGenThread() {
}
//****************************************************************************
// BOOL InitInstance()
///
/// InitInstance method
///
//****************************************************************************
BOOL CReportGenThread::InitInstance() {
	// TODO: perform and per-thread initialization here
	return TRUE;
}
//****************************************************************************
// int ExitInstance()
///
/// ExitInstance method
///
//****************************************************************************
int CReportGenThread::ExitInstance() {
	// TODO: perform any per-thread cleanup here
	return QThread::ExitInstance();
}

BEGIN_MESSAGE_MAP(CReportGenThread, QThread)
//{{AFX_MSG_MAP(CReportGenThread)
// NOTE - the ClassWizard will add and remove mapping macros here.
//}}AFX_MSG_MAP

//PSR - Fix for 1-30DY01Q
ON_THREAD_MESSAGE(WM_GENERATE_REPORT, OnGenerateReport)// from EventControl-Effect on trigger
END_MESSAGE_MAP()

//****************************************************************************
// UINT GenReport(LPVOID lpParam)
///
/// Main thread function
///
//****************************************************************************
UINT CReportGenThread::GenReport(LPVOID lpParam)
{
	// call the report manager
	CReportManager *pkReportMgr = CReportManager::GetHandle();
	QString  strReportName( "" );
	QString  strErrorMsg( "" );
	pkReportMgr->GenerateReport( reinterpret_cast< USHORT >( lpParam ), strReportName, strErrorMsg );
	return 0;
}

//PSR - Fix for 1-30DY01Q begin

////PreTranslateMessage to handle the messages before dispatch and forward to the default winproc is needed
BOOL CReportGenThread::PreTranslateMessage(MSG *pMsg) {
	// Is it the Message you want?  
	switch (pMsg->message) {
	case WM_GENERATE_REPORT: {
		OnGenerateReport(pMsg->wParam, pMsg->lParam);
		break;
	}
	default: {
		// Call MFC to have it continue processing the message
		return QThread::PreTranslateMessage(pMsg);
	}
	}
	return TRUE;
}

/****************************************************************************
 Description - Posted from EventControl-Effect when trigger caused for report
 Parameters - ReportIndex
 Returns - 0
 ****************************************************************************/
void CReportGenThread::OnGenerateReport(WPARAM wParam, LPARAM lParam) {
	// call the report manager
	CReportManager *pkReportMgr = CReportManager::GetHandle();
	QString  strReportName("");
	QString  strErrorMsg("");
	pkReportMgr->GenerateReport((USHORT) lParam, strReportName, strErrorMsg);
}
//PSR - Fix for 1-30DY01Q end
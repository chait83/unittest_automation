/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	I/O Scheduler
/// @n Filename: DeviceManager.h
/// @n Desc:	interface for the CDeviceManager class
///
// 
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 14	Stability Project 1.11.1.1	7/2/2011 4:56:45 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 13	Stability Project 1.11.1.0	7/1/2011 4:27:19 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 12	V6 Firmware 1.11		8/17/2006 8:21:21 PM	Graham Waterfield
//		Allow user linearisattion tables to be commited without the need to
//		restart the recorder
// 11	V6 Firmware 1.10		8/11/2006 1:42:14 PM	Graham Waterfield
//		Prevent user linearisation tables from being accessed in ATE build
// $
//
//////////////////////////////////////////////////////////////////////

#ifndef _DEVICEMANAGER_H
#define _DEVICEMANAGER_H

#if !defined(AFX_DEVICEMANAGER_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_)
#define AFX_DEVICEMANAGER_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_

#include "Device.h"

#ifdef DBG_FILE_LOG_DEV_MGR_DBG_ENABLE
	#include "CStorage.h" //PSR - DebugFile Logger integration
#endif

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//**Class*********************************************************************
///
/// @brief Manage the list of devices
/// 
/// This class manages all devices that cahn be associated with a recorder input or output
///
//****************************************************************************
class CDeviceManager {
public:
	CDeviceManager();
	virtual ~CDeviceManager();

	BOOL InitialiseLinerisationTableManager(void);
	BOOL CommitLinerisationTableManager(void);

	BOOL LookupTCLinerisationTable(const USHORT TCTableID, const BOOL CJLookup, const float SensorIn,
			float *pSensorOut) const;
	BOOL LookupRTLinerisationTable(const USHORT RTTableID, const float SensorIn, float *pSensorOut) const;
	BOOL LookupUserLinerisationTable(const USHORT TableID, const float SensorIn, float *pSensorOut) const;

	BOOL MarkUsedSensorDevice(const USHORT TCTableID, const BOOL Used);
	BOOL MarkUsedCJDevice(const USHORT TCTableID, const BOOL Used);

	BOOL QueryUserTableVaild(const USHORT TableID) const;

	const T_PDEVICETABLEHDR GetUserSensorDeviceHdr(const USHORT TableID) const;
	const T_PDEVICETABLEHDR GetRTSensorDeviceHdr(const USHORT RTTableID) const;
	const T_PDEVICETABLEHDR GetTCSensorDeviceHdr(const USHORT TCTableID) const;
	const T_PDEVICETABLEHDR GetTCCJDeviceHdr(const USHORT TCTableID) const;

#if defined (DBG_FILE_LOG_DEV_MGR_DBG_ENABLE)
		static void LogDbgMessageToFile(QString  strLogMessage);
		#endif

private:
	class CDevice m_TCDevices[AI_TOTAL_THERMOS];
	class CDevice m_RTDevices[AI_TOTAL_RTS];
	class CDevice m_UserDevices[GENERALCONFIG_USERTABLE_SIZE];
	T_DEVICETABLEHDR UserDeviceHdr[GENERALCONFIG_USERTABLE_SIZE];

	BOOL InitialiseUserLinerisationTable(const USHORT TCTableID);
	BOOL InitialiseTCLinerisationTable(const USHORT TCTableID);
	BOOL InitialiseRTLinerisationTable(const USHORT RTTableID);

#ifdef DBG_FILE_LOG_DEV_MGR_DBG_ENABLE
		static CDebugFileLogger m_debugFileLogger; //PSR - DebugFile Logger integration
#endif
};

#endif // !defined(AFX_DEVICEMANAGER_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_)

#endif		// _DEVICEMANAGER_H

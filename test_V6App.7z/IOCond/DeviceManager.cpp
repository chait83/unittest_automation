/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O conditioning
/// @n DeviceManager.cpp
/// @n implementation for the Device Manager class.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 33	Stability Project 1.28.1.3	7/2/2011 4:56:44 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 32	Stability Project 1.28.1.2	7/1/2011 4:38:14 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 31	Stability Project 1.28.1.1	3/17/2011 3:20:21 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 30	Stability Project 1.28.1.0	2/15/2011 3:02:56 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////

#include "V6AISpecialCodes.H"
#include "CMMDefines.h"
#include "V6Config.h"
#include "V6IOErrorCodes.H"
#include "TraceDefines.h"
#include "V6defines.h"
#include <math.h>

#include "InputConditioning.h"
#include "PPIOServiceManager.h"

#include "LinearTable.h"
#include "Device.h"
#include "DeviceManager.h"

#include "V6globals.h"

#include "V6ResourceBase.h"
#include "V6UIResource.h"
#include "ppl.h"

#ifndef __cplusplus
#define __cplusplus
#endif

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif

const float RT_OHMS_ERROR = 0.6F; ///< Allow for up to 0.6 ohms total inacurracy
const float TC_VOLTAGE_ERROR = 1.5F; ///< Allow for up to 1.5mV total inaccurracy

#ifdef DBG_FILE_LOG_DEV_MGR_DBG_ENABLE
CDebugFileLogger CDeviceManager::m_debugFileLogger(L"\\SDMemory\\IODeviceMgrDbgLog.txt", FALSE, 10*1024*1024 );
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CDeviceManager::CDeviceManager() {
//	qDebug("Create new CDeviceManager\n");
}

CDeviceManager::~CDeviceManager() {
//	qDebug("Delete CDeviceManager class\n");
}

//******************************************************
///
/// Initialises the IO conditioner internal linearisation tables.
/// Creates the device lookup tables
///
/// @return TRUE if all tables initialised OK otherwise FALSE.
/// 
//******************************************************
BOOL CDeviceManager::InitialiseLinerisationTableManager(void) {
	USHORT Device = 0;
	BOOL retValue = TRUE;

#ifdef DBG_FILE_LOG_DEV_MGR_DBG_ENABLE
	QString  strLogMessage;
	strLogMessage.asprintf(L"CDVMGR::InitialiseLinerisationTableManager begin");
	CDeviceManager::LogDbgMessageToFile(strLogMessage);
	#endif
	// First initialise the built in lineraisation tables
	// --------------------------------------------------

	// Loop for all thermocouple devices, and initialise
	for (Device = 0; Device < AI_TOTAL_THERMOS; Device++) {
#ifdef DBG_FILE_LOG_DEV_MGR_DBG_ENABLE
		strLogMessage.asprintf(L"CDVMGR::ILTM InitialiseTCLinerisationTable for Thermo Device %d", Device);
		CDeviceManager::LogDbgMessageToFile(strLogMessage);
		#endif
		if (InitialiseTCLinerisationTable(Device) == FALSE) {
			retValue = FALSE;

#ifdef DBG_FILE_LOG_DEV_MGR_DBG_ENABLE
			strLogMessage.asprintf(L"CDVMGR::ILTM InitialiseTCLinerisationTable for Thermo Device %d Failed", Device);
			CDeviceManager::LogDbgMessageToFile(strLogMessage);
			#endif
		}
	}

	// Loop for all resistive thermo devices, and initialise
	for (Device = 0; Device < AI_TOTAL_RTS; Device++) {
#ifdef DBG_FILE_LOG_DEV_MGR_DBG_ENABLE
		strLogMessage.asprintf(L"CDVMGR::ILTM InitialiseRTLinerisationTable for RTD Device %d", Device);
		CDeviceManager::LogDbgMessageToFile(strLogMessage);
		#endif

		if (InitialiseRTLinerisationTable(Device) == FALSE) {
			retValue = FALSE;

#ifdef DBG_FILE_LOG_DEV_MGR_DBG_ENABLE
			strLogMessage.asprintf(L"CDVMGR::ILTM InitialiseRTLinerisationTable for RTD Device %d Failed", Device);
			CDeviceManager::LogDbgMessageToFile(strLogMessage);
			#endif
		}
	}

	// then initialise all the user lineraisation tables
	// -------------------------------------------------
	for (Device = 0; Device < GENERALCONFIG_USERTABLE_SIZE; Device++) {
#ifdef DBG_FILE_LOG_DEV_MGR_DBG_ENABLE
		strLogMessage.asprintf(L"CDVMGR::ILTM InitialiseUserLinerisationTable for User Device %d", Device);
		CDeviceManager::LogDbgMessageToFile(strLogMessage);
		#endif

		if (InitialiseUserLinerisationTable(Device) == FALSE) {
			retValue = FALSE;

#ifdef DBG_FILE_LOG_DEV_MGR_DBG_ENABLE
			strLogMessage.asprintf(L"CDVMGR::ILTM InitialiseUserLinerisationTable for User Device %d Failed", Device);
			CDeviceManager::LogDbgMessageToFile(strLogMessage);
			#endif
		}
	}

#ifdef DBG_FILE_LOG_DEV_MGR_DBG_ENABLE
	strLogMessage.asprintf(L"CDVMGR::InitialiseLinerisationTableManager End");
	CDeviceManager::LogDbgMessageToFile(strLogMessage);
	#endif

	return retValue;
}

//******************************************************
///
/// Re-initialises the IO conditioner internal linearisation tables on a configuration change.
///
/// @return TRUE if all tables initialised OK otherwise FALSE.
/// 
//******************************************************
BOOL CDeviceManager::CommitLinerisationTableManager(void) {
	USHORT Device = 0;
	BOOL retValue = TRUE;

	// Reload all the user lineraisation tables
	// -------------------------------------------------
	for (Device = 0; Device < GENERALCONFIG_USERTABLE_SIZE; Device++) {
		if (InitialiseUserLinerisationTable(Device) == FALSE)
			retValue = FALSE;
	}

	return retValue;
}

//******************************************************
///
/// Initialises the IO conditioner internal linearisation tables.
/// Creates the device lookup tables
/// @param[in] RTTableID - The device ID to create the table for.
///
/// @return TRUE if initialised OK otherwise FALSE.
/// 
//******************************************************
BOOL CDeviceManager::InitialiseTCLinerisationTable(const USHORT TCTableID) {
	BOOL retValue = FALSE;

	switch (TCTableID) {
	case AI_THERMO_RANGE_B:
		retValue = m_TCDevices[TCTableID].InitialiseTypeBTC();
		break;
	case AI_THERMO_RANGE_C:
		retValue = m_TCDevices[TCTableID].InitialiseTypeCTC();
		break;
	case AI_THERMO_RANGE_D:
		retValue = m_TCDevices[TCTableID].InitialiseTypeDTC();
		break;
	case AI_THERMO_RANGE_E:
		retValue = m_TCDevices[TCTableID].InitialiseTypeETC();
		break;
	case AI_THERMO_RANGE_J:
		retValue = m_TCDevices[TCTableID].InitialiseTypeJTC();
		break;
	case AI_THERMO_RANGE_K: {
#ifdef DBG_FILE_LOG_DEV_MGR_DBG_ENABLE
			QString  strLogMessage;
			strLogMessage.asprintf(L"CDVMGR::InitialiseTCLinerisationTable InitialiseTypeKTC");
			CDeviceManager::LogDbgMessageToFile(strLogMessage);
			#endif

		retValue = m_TCDevices[TCTableID].InitialiseTypeKTC();
	}
		break;
	case AI_THERMO_RANGE_L:
		retValue = m_TCDevices[TCTableID].InitialiseTypeLTC();
		break;
	case AI_THERMO_RANGE_M:
		retValue = m_TCDevices[TCTableID].InitialiseTypeMTC();
		break;
	case AI_THERMO_RANGE_N:
		retValue = m_TCDevices[TCTableID].InitialiseTypeNTC();
		break;
	case AI_THERMO_RANGE_R:
		retValue = m_TCDevices[TCTableID].InitialiseTypeRTC();
		break;
	case AI_THERMO_RANGE_S:
		retValue = m_TCDevices[TCTableID].InitialiseTypeSTC();
		break;
	case AI_THERMO_RANGE_T:
		retValue = m_TCDevices[TCTableID].InitialiseTypeTTC();
		break;
	case AI_THERMO_RANGE_G:
		retValue = m_TCDevices[TCTableID].InitialiseTypeGTC();
		break;
	case AI_THERMO_RANGE_CHROMEL:
		retValue = m_TCDevices[TCTableID].InitialiseChromelCopel();
		break;
	case AI_THERMO_RANGE_PLATINEL:
		retValue = m_TCDevices[TCTableID].InitialisePlatinel();
		break;
	}

	return retValue;
}

//******************************************************
///
/// Initialises the IO conditioner internal linearisation tables.
/// Creates the device lookup tables
/// @param[in] RTTableID - The device ID to create the table for.
///
/// @return TRUE if initialised OK otherwise FALSE.
/// 
//******************************************************
BOOL CDeviceManager::InitialiseRTLinerisationTable(const USHORT RTTableID) {
	BOOL retValue = FALSE;

	switch (RTTableID) {
	case AI_RT_RANGE_PT100:
		retValue = m_RTDevices[RTTableID].InitialisePT100RT();
		break;
	case AI_RT_RANGE_PT200:
		retValue = m_RTDevices[RTTableID].InitialisePT200RT();
		break;
	case AI_RT_RANGE_PT400:
		retValue = m_RTDevices[RTTableID].InitialisePT400RT();
		break;
	case AI_RT_RANGE_PT500:
		retValue = m_RTDevices[RTTableID].InitialisePT500RT();
		break;
	case AI_RT_RANGE_CU10:
		retValue = m_RTDevices[RTTableID].InitialiseCU10RT();
		break;
	case AI_RT_RANGE_CU53:
		retValue = m_RTDevices[RTTableID].InitialiseCU53RT();
		break;
	case AI_RT_RANGE_NI100:
		retValue = m_RTDevices[RTTableID].InitialiseNi100RT();
		break;
	case AI_RT_RANGE_NK120:
		retValue = m_RTDevices[RTTableID].InitialiseNK120RT();
		break;
	case AI_RT_RANGE_PT1000:
		retValue = m_RTDevices[RTTableID].InitialisePT1000RT();
		break;
	case AI_RT_RANGE_PT2000:
		retValue = m_RTDevices[RTTableID].InitialisePT2000RT();
		break;
	}

	return retValue;
}

//******************************************************
///
/// Initialises the IO conditioner user configurable internal linearisation tables.
/// Creates the device lookup tables
/// @param[in] TableID - The device ID to create the table for.
///
/// @return TRUE if initialised OK otherwise FALSE.
/// 
//******************************************************
BOOL CDeviceManager::InitialiseUserLinerisationTable(const USHORT TableID) {
	T_PGENERALCONFIG pGenConfig = NULL;
	T_PLOOKUPTABLE pUserTable = NULL;
	QString   errorStr;
	BOOL retValue = TRUE;

	// Obtain device table from CMM
	pGenConfig = pSETUP->GetGeneralSetupConfig()->GetSystemGeneralBlock(CONFIG_COMMITTED);
	pUserTable = &(pGenConfig->UserTable[TableID]);

	// If there is at least on element defined then initialise table
	if (pUserTable->ElementCount > 0) {
		if (m_UserDevices[TableID].InitialiseUserTable(TableID, &UserDeviceHdr[TableID], &(pUserTable->LookupEntry[0]),
				pUserTable->ElementCount) == FALSE) {
			// Failure is likely to occur from an operator edit error, so report which table number(s) has failed
			errorStr.asprintf(IDS_USER_TABLE_ISSUE, TableID);
			AddErrorToReport(static_cast<LPCTSTR>(errorStr));
			retValue = FALSE;
		}
	}

	return retValue;
}

//******************************************************
///
/// Marks whether a Sensor linearisation table is used or not.
/// @param[in] RTTableID - The device ID to create the table for.
/// @param[in] Used - TRUE if the the sensor table if currently used
///
/// @return TRUE if table allocated OK otherwise FALSE.
/// 
//******************************************************
BOOL CDeviceManager::MarkUsedSensorDevice(const USHORT TCTableID, const BOOL Used) {
	BOOL retValue = FALSE;

	retValue = m_TCDevices[TCTableID].MarkSensorTableUsed(Used);

	return retValue;
}

//******************************************************
///
/// Marks whether a CJ linearisation table is used or not.
/// @param[in] RTTableID - The device ID to create the table for.
/// @param[in] Used - TRUE if the the sensor table if currently used
///
/// @return TRUE if table allocated OK otherwise FALSE.
/// 
//******************************************************
BOOL CDeviceManager::MarkUsedCJDevice(const USHORT TCTableID, const BOOL Used) {
	BOOL retValue = FALSE;

	retValue = m_TCDevices[TCTableID].MarkCJTableUsed(Used);

	return retValue;
}

//******************************************************
///
/// Queries the device header details for a user defined sensor.
/// @param[in] TableID - The device ID to create the table for.
///
/// @return Pointer to a sensor table header if fitted; otherwise NULL.
/// 
//******************************************************
const T_PDEVICETABLEHDR CDeviceManager::GetUserSensorDeviceHdr(const USHORT TableID) const {
	// Get the TC header, for any legal device
	if (TableID < GENERALCONFIG_USERTABLE_SIZE)
		return m_UserDevices[TableID].GetSensorDeviceHdr();

	return NULL;
}

//******************************************************
///
/// Queries the device header details for a RT sensor.
/// @param[in] RTTableID - The device ID to create the table for.
///
/// @return Pointer to a sensor table header if fitted; otherwise NULL.
/// 
//******************************************************
const T_PDEVICETABLEHDR CDeviceManager::GetRTSensorDeviceHdr(const USHORT RTTableID) const {
	// Get the TC header, for any legal device
	if (RTTableID < AI_TOTAL_RTS)
		return m_RTDevices[RTTableID].GetSensorDeviceHdr();

	return NULL;
}

//******************************************************
///
/// Queries the device header details for an TC sensor.
/// @param[in] TCTableID - The device ID to create the table for.
///
/// @return Pointer to a sensor table header if fitted; otherwise NULL.
/// 
//******************************************************
const T_PDEVICETABLEHDR CDeviceManager::GetTCSensorDeviceHdr(const USHORT TCTableID) const {
	// Get the TC header, for any legal device
	if (TCTableID < AI_TOTAL_THERMOS)
		return m_TCDevices[TCTableID].GetSensorDeviceHdr();

	return NULL;
}

//******************************************************
///
/// Queries the device header details for an TC CJ device.
/// @param[in] TCTableID - The device ID to create the table for.
///
/// @return Pointer to a sensor table header if fitted; otherwise NULL.
/// 
//******************************************************
const T_PDEVICETABLEHDR CDeviceManager::GetTCCJDeviceHdr(const USHORT TCTableID) const {
	T_PDEVICETABLEHDR pTCHdr = NULL;

	// Get the TC header, for any legal device
	if (TCTableID < AI_TOTAL_THERMOS)
		pTCHdr = m_TCDevices[TCTableID].GetCJDeviceHdr();

	if ((pTCHdr != NULL) && (pTCHdr->CJLookup == TRUE))
		return pTCHdr;

	return NULL;
}

//******************************************************
///
/// Looks up the Sensor linearisation table.
/// @param[in] RTTableID - The device ID to create the table for.
/// @param[in] CJLookup - The CJ lookup table is to be performed rather than the sensor.
/// @param[in] SensorIn - The device table I/P value.
/// @param[out] pSensorOut - The corresponding device table O/P value.
///
/// @return TRUE if lookup OK otherwise FALSE.
/// 
//******************************************************
BOOL CDeviceManager::LookupTCLinerisationTable(const USHORT TCTableID, const BOOL CJLookup, const float SensorIn,
		float *pSensorOut) const {
	class CPPIOServiceManager *pServiceManagerObj = NULL;	///< Service manager
	class CInputConditioning *pICService = NULL;	///< Input conditioning service
	T_PDEVICETABLEHDR pDeviceHdr = NULL;
	float DeviceIPRangeHigh = 0.0F;
	float DeviceIPRangeLow = 0.0F;
	BOOL retValue = FALSE;

	pServiceManagerObj = CPPIOServiceManager::GetHandle();
	if (pServiceManagerObj != NULL)
		pICService = pServiceManagerObj->GetICService();
	// Is it a voltage device i.e. voltage to temperature or sensor i.e. temperature to voltage
	if (CJLookup == TRUE) {
		// Convert temperature from a CJ device
		retValue = m_TCDevices[TCTableID].LookupCJTable(SensorIn, pSensorOut);
		if (retValue == FALSE) {
			// Error has occurred
			pDeviceHdr = GetTCCJDeviceHdr(TCTableID);
			if (NULL != pDeviceHdr) {
				if (SensorIn > pDeviceHdr->IPRangeHigh) {
					// Input is too high for device
					if (pICService != NULL)
						pICService->CreateFloatingPointRepresentation(
						IO_SCHED_CJC_ABOVE_TABLE, pSensorOut);
				}
			} else if (SensorIn < pDeviceHdr->IPRangeLow) {
				// Input is too low for device
				if (pICService != NULL)
					pICService->CreateFloatingPointRepresentation(
					IO_SCHED_CJC_BELOW_TABLE, pSensorOut);
			}
		}
	} else {
		// Get the device limits and allow for possible card error to assume a correct value
		// voltage does not go into over or under range error due to board tolerence
		pDeviceHdr = GetTCSensorDeviceHdr(TCTableID);
		if (NULL != pDeviceHdr) {
			DeviceIPRangeHigh = pDeviceHdr->IPRangeHigh + TC_VOLTAGE_ERROR;
			DeviceIPRangeLow = pDeviceHdr->IPRangeLow - TC_VOLTAGE_ERROR;
		}
		if (SensorIn > DeviceIPRangeHigh) {
			// Input is too high for device
			if (pICService != NULL)
				pICService->CreateFloatingPointRepresentation(
				IO_SCHED_ABOVE_TABLE, pSensorOut);
		} else if (SensorIn < DeviceIPRangeLow) {
			// Input is too low for device
			if (pICService != NULL)
				pICService->CreateFloatingPointRepresentation(
				IO_SCHED_BELOW_TABLE, pSensorOut);
		} else {
			// Convert for a TC by looking up the mV's.
			retValue = m_TCDevices[TCTableID].LookupSensorTable(SensorIn, pSensorOut);
		}
	}

	return retValue;
}

//******************************************************
///
/// Looks up the Sensor linearisation table.
/// @param[in] RTTableID - The device ID to create the table for.
/// @param[in] SensorIn - The device table I/P value.
/// @param[out] pSensorOut - The corresponding device table O/P value.
///
/// @return TRUE if lookup OK otherwise FALSE.
/// 
//******************************************************
BOOL CDeviceManager::LookupRTLinerisationTable(const USHORT RTTableID, const float SensorIn, float *pSensorOut) const {
	class CPPIOServiceManager *pServiceManagerObj = NULL;	///< Service manager
	class CInputConditioning *pICService = NULL;	///< Input conditioning service
	T_PDEVICETABLEHDR pDeviceHdr = NULL;
	float DeviceIPRangeHigh = 0.0F;
	float DeviceIPRangeLow = 0.0F;
	BOOL retValue = FALSE;

	pServiceManagerObj = CPPIOServiceManager::GetHandle();
	if (pServiceManagerObj != NULL)
		pICService = pServiceManagerObj->GetICService();

	// Get the device limits and allow for possible card error to assume a correct value
	// resistance does not go into over or under range error due to board tolerence
	pDeviceHdr = GetRTSensorDeviceHdr(RTTableID);
	if (NULL != pDeviceHdr) {
		DeviceIPRangeHigh = pDeviceHdr->IPRangeHigh + RT_OHMS_ERROR;
		DeviceIPRangeLow = pDeviceHdr->IPRangeLow - RT_OHMS_ERROR;
	}
	if (SensorIn > DeviceIPRangeHigh) {
		// Input is too high for device
		if (pICService != NULL)
			pICService->CreateFloatingPointRepresentation( IO_SCHED_ABOVE_TABLE, pSensorOut);
	} else if (SensorIn < DeviceIPRangeLow) {
		// Input is too low for device
		if (pICService != NULL)
			pICService->CreateFloatingPointRepresentation( IO_SCHED_BELOW_TABLE, pSensorOut);
	} else {
		// Convert for a RT by looking up the ohm's.
		retValue = m_RTDevices[RTTableID].LookupSensorTable(SensorIn, pSensorOut);
	}

	return retValue;
}

//******************************************************
///
/// Looks up the Sensor linearisation table - extrapolates if outside of table.
/// @param[in] RTTableID - The device ID to create the table for.
/// @param[in] SensorIn - The device table I/P value.
/// @param[out] pSensorOut - The corresponding device table O/P value.
///
/// @return TRUE if lookup OK otherwise FALSE.
/// 
//******************************************************
BOOL CDeviceManager::LookupUserLinerisationTable(const USHORT TableID, const float SensorIn, float *pSensorOut) const {
	BOOL retValue = FALSE;

	// Convert for a user table by looking up the sensor units.
	retValue = m_UserDevices[TableID].LookupSensorTable(SensorIn, pSensorOut);

	return retValue;
}

//******************************************************
///
/// Queries whether a user defined linearisation table is initialised.
/// @param[in] TableID - The device ID to create the table for.
///
/// @return TRUE if lookup OK otherwise FALSE.
/// 
//******************************************************
BOOL CDeviceManager::QueryUserTableVaild(const USHORT TableID) const {
	BOOL retValue = FALSE;

	// Convert for a user table by looking up the sensor units.
	retValue = m_UserDevices[TableID].QueryUserTableVaild();

	return retValue;
}

#if defined (DBG_FILE_LOG_DEV_MGR_DBG_ENABLE)
//**********************************************************************
/// Output debug info on Device Manager (for debug purposes only)
///
/// @param[in] pBuffer - Pointer to the data buffer			
/// @param[in]	size - pointer to the buffer size
///	@param[in]	IsAWrite - TRUE if "Write" FALSE if "Read"
/// @return	nothing 
/// 
//**********************************************************************
void CDeviceManager::LogDbgMessageToFile(QString  strLogMessage)
{
	QString  strDbgMessage;
	strDbgMessage.asprintf(L"%s - GTC:%d\r\n", strLogMessage, GetTickCount() );
	m_debugFileLogger.WriteToDebugLogFile(strDbgMessage);
}
#endif

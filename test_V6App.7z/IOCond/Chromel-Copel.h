/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	I/O Scheduler
/// @n Filename: Chromel-Copel.h
/// @n Desc:	Constant data for the Chromel Copel thermocouple
///
// 
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 4	Stability Project 1.1.1.1	7/2/2011 4:56:05 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 3	Stability Project 1.1.1.0	7/1/2011 4:27:23 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 2	V6 Firmware 1.1		8/12/2005 6:10:01 PM	Graham Waterfield
//		Correct typo
// 1	V6 Firmware 1.0		3/17/2005 5:41:52 PM	Graham Waterfield 
// $
//
//////////////////////////////////////////////////////////////////////

#ifndef _CHROMELCOPEL_H
#define _CHROMELCOPEL_H

#if !defined(AFX_CHROMELCOPEL_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_)
#define AFX_CHROMELCOPEL_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "LinearTable.h"

const T_IP_TABLE_ELEMENT ChromelCopelVoltage[] = {
		// mV,		TempC
		-3.11F, -50, -1.27F, -20, 0, 0, 2.66F, 40, 5.48F, 80, 6.95F, 100, 9.93F, 140, 13.03F, 180, 14.66F, 200, 17.95F,
		240, 21.25F, 280, 22.91F, 300, 26.31F, 340, 29.76F, 380, 31.49F, 400, 34.95F, 440, 38.42F, 480, 40.16F, 500,
		43.68F, 540, 47.23F, 580, 49.02F, 600 };

const T_IP_TABLE_ELEMENT ChromelCopelTemp[] = {
		// TempC,	mV
		-50, -3.11F, -20, -1.27F, 0, 0, 40, 2.66F, 80, 5.48F, 100, 6.95F, 140, 9.93F, 180, 13.03F, 200, 14.66F, 240,
		17.95F, 280, 21.25F, 300, 22.91F, 340, 26.31F, 380, 29.76F, 400, 31.49F, 440, 34.95F, 480, 38.42F, 500, 40.16F,
		540, 43.68F, 580, 47.23F, 600, 49.02F };

#endif // !defined(AFX_CHROMELCOPEL_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_)

#endif		// _CHROMELCOPEL_H

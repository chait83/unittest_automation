/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	I/O Scheduler
/// @n Filename: InputConditioning.h
/// @n Desc:	interface for the Input Conditioning class
///
// 
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 71	Stability Project 1.68.1.1	7/2/2011 4:57:58 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 70	Stability Project 1.68.1.0	7/1/2011 4:27:16 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 69	V6 Firmware 1.68		1/19/2007 5:07:01 PM	Graham Waterfield
//		Limit the maximum AO currrent output; dependant upon AO board
//		revision
// 68	V6 Firmware 1.67		11/22/2006 4:08:11 PM Graham Waterfield
//		Ensure that unplugged devices are not continually reported and allow
//		user calibration to be saved to the NV directly
// $
//
//////////////////////////////////////////////////////////////////////

#ifndef _INPUTCONDITIONING_H
#define _INPUTCONDITIONING_H

#if !defined(AFX_INPUTCONDITIONING_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_)
#define AFX_INPUTCONDITIONING_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//#include "ATECal.h"
#include "FFConversionInfo.h"
#include "V6AISpecialCodes.H"
#include "V6Config.h"
#include "DeviceManager.h"

#include "DataItemBase.h"

#include <float.h>

#if defined (DBG_FILE_LOG_IO_COND_ERR_ENABLE) || defined (DBG_FILE_LOG_IO_COND_DBG_ENABLE)
	#include "CStorage.h" //PSR - Debug File Logger integration
#endif

// const float IO_RANGE_MAX_FLOAT = FLT_MAX;
// const float IO_RANGE_MIN_FLOAT = -FLT_MAX;

const USHORT ADC_RAW_UNDER_RANGE_VALUE = 0x00;
const USHORT ADC_RAW_OVER_RANGE_VALUE = 0x0ffff;

const UINT NAN_EXPONENT = 0x7f800000;
const UINT QUIET_NAN = 0x00400000;
const UINT NAN_MANTISSA = 0x003fffff;

const float RT_I_MEASURE_R = 100.0;

// Limits for AO output
const float AO_OP_ZERO_TOO_HIGH = 0.0002F;

// CJC channel offsets
const float CH1_CJC_DEG_OFFSET = -0.18F;
const float CH2_CJC_DEG_OFFSET = 0.78F;
const float CH3_CJC_DEG_OFFSET = 0.71F;
const float CH4_CJC_DEG_OFFSET = 0.45F;
const float CH5_CJC_DEG_OFFSET = 0.3F;
const float CH6_CJC_DEG_OFFSET = 0.55F;
const float CH7_CJC_DEG_OFFSET = 0.96F;
const float CH8_CJC_DEG_OFFSET = 0.38F;

//const float V7AI_CJC_DEG_OFFSET = 0.0F;
const float V7AI_CH1_CJC_DEG_OFFSET = 0.0F;
const float V7AI_CH2_CJC_DEG_OFFSET = 0.0F;
const float V7AI_CH3_CJC_DEG_OFFSET = 0.0F;
const float V7AI_CH4_CJC_DEG_OFFSET = 0.0F;
const float V7AI_CH5_CJC_DEG_OFFSET = 0.0F;
const float V7AI_CH6_CJC_DEG_OFFSET = 0.0F;
const float V7AI_CH7_CJC_DEG_OFFSET = 0.0F;
const float V7AI_CH8_CJC_DEG_OFFSET = 0.0F;

typedef struct _aiwrkrtcurrent {
	BOOL useHighRTCal;
	BOOL highRTideal;
	BOOL lowRTideal;
	double highRTCurrent;
	double lowRTCurrent;
} T_AIWRKRTCURRENT, T_PAIWRKRTCURRENT;

// A single working channel info
typedef struct _wrkchancalpoint {
	float DPlowerCalPoint;					///< Eng value of lower cal point
	float DPupperCalPoint;					///< Eng value of upper cal point
	float DPlowerAdjPoint;				///< Adjusted value of lower cal point
	float DPupperAdjPoint;				///< Adjusted value of upper cal point
	float DPoutputOffset;							///< Adjustment of output
	float DPouputSlope;									///< Slope of output
	CLinearTable MPTable;					///< Multi Point calibration table
	UCHAR WrkCalType;					///< Working copy of calibration type
} T_WRKCHANCALPOINT, *T_PWRKCHANCALPOINT;

// A colection of working channel cal info (a card)
typedef struct _wrkchannelcals {
	T_WRKCHANCALPOINT PointCals[BOARDCALS_CHANCALS_SIZE];					///< Working channels for a card
} T_WRKCHANNELCALS, *T_PWRKCHANNELCALS;

// Working board structures
typedef struct _wrkboardstruct {
	T_WRKCHANNELCALS WrkBoardCals;					///< Board working channel calibrations structure
} T_WRKBOARDSTRUCT, *T_PWRKBOARDSTRUCT;

// Recorder set of working calibration structures
typedef struct _wrkrecordercal {
	T_WRKBOARDSTRUCT RecorderCals[RECORDERCAL_RECORDERCALS_SIZE];
} T_WRKRECORDERCAL, *T_PWRKRECORDERCAL;

// Recorder cal structure to be persisted in the CMM
typedef struct _persistrecordercal {
	T_RECORDERCAL CalPoints;		///< Additional board calibration points
} T_PERSISTRECORDERCAL, *T_PPERSISTRECORDERCAL;

#define V6_DUAL_POINT_CAL_BETWEEN_POINTS	0
#define V6_DUAL_POINT_CAL_WHOLE_RANGE		1

class CInputConditioning {
public:
	// Enums
	enum IO_CAL_OPTIONS {
		V6_IO_FACTORY_CALIBRATION = 0, V6_IO_USER_CALIBRATION, V6_IO_USER_AND_RECALIBRATE///< User calibration must be performed and is to be selected (should never be found in the persisted version)
	};

	enum IO_BURNOUT_STATUS {
		BURNOUT_DISABLED = 0x0,	///< Burnout disabled
		BURNOUT_OK,						///< Active burnout enabled, input OK
		BURNOUT_TC_DEGRADED, 				///< Thermocouple Degraded
		BURNOUT_TC_FAILING, 				///< Thermocouple is failing
		BURNOUT_TC_ALMOST_FAILED, 			///< Thermocouple Almost Failed
		BURNOUT_TC_OC_DETECTED,				///< Thermocouple O/C detected
		BURNOUT_TC_SC_DETECTED				///< Possible thermocouple wiring short circuit detected
	};

	CInputConditioning();
	virtual ~CInputConditioning();

	class CFFConversionInfo* GetBaseRangeConversionInfo(const UCHAR BaseRange, const UCHAR ucBoardRev);
	BOOL IOConditionerInitialise(void);
	BOOL IOConditionerCommit(void);

	BOOL ResetIllegalNVToFactoryCal(void);
	BOOL ResetProcessedNVToUserCalSet(void);

	BOOL SaveUserCalStatToNV(const USHORT slotNo, const USHORT chanNo, const USHORT rangeNo,
			const CInputConditioning::IO_CAL_OPTIONS state);

	BOOL ResetOutputAdjustCal(const USHORT cardNo, const USHORT chanNo);

	BOOL NormaliseExcitationCurrent(const USHORT chanNo, const T_RANGE_COUNTS rawValue, const BOOL highCurrentSet,
			float *pCurrent) const;

	ULONG SyncIOToPreProcessTimeLine(const USHORT timebase, const UCHAR PPGearingRatio);

	float ConvertToSQRTExtract(const float InpValue, const float EngZero, const float EngSpan);
	float ConvertTo52Law(const float InpValue) const;
	float ConvertTo32Law(const float InpValue) const;
	float ApplyGCADamping(const float newReading, const float prevReading, const float level);

	class CDeviceManager* GetDeviceManager(void);

	//This Function converts the EngValue returned from IO FW to Error Code bytes based on the board type
	BOOL ConvertEngValueToV6IOErrorCode(const UCHAR cardNo, const T_RANGE_COUNTS EngValue, COMBO_VAR4 &var4ErrCode,
			const USHORT chanType);

	T_DATAITEM_STATUS ConvertFloatErrorToDITStatus(const float floatVal);
	BOOL TestFloatLimitError(const float floatVal);
	BOOL TestFloatError(const float floatVal);
	static const BOOL CreateFloatingPointRepresentation(const T_RANGE_COUNTS EngValue, float *const pLimitedValue);

	BOOL ApplyTCPPQBurnout(const USHORT slotNo, const USHORT channel, const BOOL upscaleBurnout,
			float *const pLimitedValue);
	BOOL ApplyTCPassiveBurnout(const USHORT slotNo, const USHORT channel, const BOOL upscaleBurnout,
			const T_RANGE_COUNTS EngValue, float *const pLimitedValue);
	BOOL IsValueAScheduledMissing(const T_RANGE_COUNTS EngValue);
	BOOL LimitAnalogueChannel(const USHORT cardNo, const USHORT cardChanNo, const BOOL rawValue,
			const T_RANGE_COUNTS EngValue, float *pLimitedValue, const USHORT chanType);
	float RescaleValue(float EngValueIn, const IO_MEASURE_UNITS UnitsIn, const IO_MEASURE_UNITS UnitsOut);

	// I/O 'user' cal point methods
	BOOL CreateDefaultIOCal(const BOOL chan3CJ);
	BOOL IOBoardCalWrkCommit(void);
	BOOL IOCalSave(void);
	BOOL IOCalLoad(void);
	BOOL QueryValidIOCalPersisted(void) const;
	BOOL QueryIOCalPersistedState(void) const;
	BOOL QueryDefaultIOCalWriteRqd(void);
	BOOL IOBoardRangeCalCommit(const USHORT cardNo, const USHORT chanNo, const float zeroEng, const float spanEng);
	T_IORANGECAL* GetIOBoardCalInfo(const USHORT slotNo, const USHORT range);
	CInputConditioning::IO_CAL_OPTIONS QueryIOBoardChanRangeCalInfo(const USHORT slotNo, const USHORT chanNo,
			const USHORT range) const;
	CInputConditioning::IO_BURNOUT_STATUS ConvertStoreBurnoutResponse(const USHORT slotNo, const USHORT chanNo,
			const UCHAR protocolBurnoutValue) const;

	USHORT QuerySensorCompMethod(const USHORT cardNo, const USHORT chanNo);

	// RT comp methods
	float NormaliseRTComp(const USHORT slotNo, const T_RANGE_COUNTS rawValue, const BOOL highCurrentSet) const;
	BOOL LimitRTComp(const T_RANGE_COUNTS EngValue,
	T_RANGE_COUNTS *const pLimitedValue);

	// RT cal methods
	void SetRTCalSourceToDefault(const BOOL useHighRTCal);
	void AdjustRTCalSource(const BOOL useHighRTCal, const USHORT RTcalCount);

	float ConvertAOCountToDVMAmps(const USHORT AOCount);
	USHORT ConvertDVMAmpsToAOCount(float DVMAmps);

	BOOL QueryIsPenAlarmNotAcked(USHORT alarmNumber, USHORT penNumber);
	BOOL QueryIsPenAlarmInAlarm(USHORT alarmNumber, USHORT penNumber);

	BOOL SetCJCCalValueUsage(USHORT slotNumber, REFERENCE cfgType);
	BOOL GetAIChannelCJCFactoryCaledValue(const USHORT cardNo, const USHORT chanNo, float &factCJCValue) const;
	BOOL SetAIChannelCJCFactoryCalPoint(const USHORT cardNo, const USHORT chanNo, float factCJCOffset);
	BOOL SetAIChannelCJCUserCalPoint(const USHORT cardNo, const USHORT chanNo, float userCJCOffset);
	BOOL GetAIChannelCJCCalPoints(const USHORT cardNo, const USHORT chanNo, float &factCJCOffset,
			float &userCJCOffset) const;
	BOOL GetAIChannelCJCCaledValue(const USHORT cardNo, const USHORT chanNo, float &factCJCValue, float &userCJCValue,
			const REFERENCE cfgType) const;

	float PerformUserLinerisation(const USHORT UserTable, const float conditionedReading);
	float PerformTCCJTempConvert(const USHORT slotNo, const USHORT chanNo, const USHORT TCType, const float TCmV,
			const float CJTemp);
	//float PerformResistanceConvert( const USHORT slotNo, const float ResitormV, const float LeadmV, const float ExcitationmA );
	float PerformResistanceConvert(const USHORT slotNo, const float ResitormV, const float LeadmV,
			const float ExcitationmA, const USHORT cardSubType, const USHORT chanType);
	float PerformRTConvert(const USHORT slotNo, const USHORT chanNo, const USHORT RTType, const float RTmV,
			const float LeadmV, const float ExcitationmA, const USHORT cardSubType, const USHORT chanType);
	BOOL PerformOutputAdjust(const float EngValue, const USHORT cardNo, const USHORT chanNo, float *pCaledValue);
	// Provides a reverse adjustment on single, dual point or multipoint calibration output value.
	float ReverseOutputAdjust(const float conditionedReading, const USHORT cardNo, const USHORT chanNo);
	float PerformCJAdjust(const float EngValue, const USHORT cardNo, const USHORT chanNo);
	float PerformResistanceConvert(const USHORT slotNo, const float mV, const float mA, const USHORT cardSubType,
			const USHORT chanType);

	float LimitCurrentLoopmAOutput(const BOOL min4mA, const BOOL overRangeAllowed, const float mA);
	USHORT LimitCurrentLoopmAOutput(const USHORT slotNo, const BOOL min4mA, const BOOL overRangeAllowed,
			const USHORT mACount);

	T_RECORDERCAL* GetInputConditioningSelect(void);

	// Recorder calibration CMM transfer methods
	BOOL RecorderCalCMMDump(void);
	BOOL RecorderCalCMMReload(void);

	const T_RANGE_COUNTS GetErrorCodeForSlotType(const USHORT cardNo, const T_RANGE_COUNTS v6ErrorCode);

private:
	// Methods
	BOOL RangeInitialise(void);

	void ReportReadingError(const USHORT cardNo, const USHORT cardChanNo, const T_RANGE_COUNTS EngValue);

	float PerformRTConvert(const USHORT RTType, const float RTohms);
	float PerformTCCJmVConvert(const USHORT slotNo, const USHORT chanNo, const USHORT TCType, const float TCmV,
			const float CJmV);

	//Returns the RtComp High w.r.t to the Board Sub Type
	const class CFFConversionInfo* GetRTCompHigh(const USHORT slotNo) const;
	//Returns the RtComp High w.r.t to the Board Sub Type
	const class CFFConversionInfo* GetRTCompLow(const USHORT slotNo) const;

	static const float GetV7AICJCCalValue(const USHORT slotNo, const USHORT chanNo);

	static const float GetV6AICJCCalValue(const USHORT slotNo, const USHORT chanNo, BOOL chan3CJ);

	// Device table manager
	class CDeviceManager m_DevManager;

	// Input conditioning data
	T_PERSISTRECORDERCAL m_CalPointsToPersist;				///< Copy of board calibration data
	T_WRKRECORDERCAL m_WrkCalPoints;				///< Working copy of the dual point calibration points

	T_PMPCALCHANNELS m_pMultiPointConfig;	///< Multi Point cionfiguration Data

	T_AIWRKRTCURRENT m_RTwrkCurrent;		///< RT Cal info

	class CFFConversionInfo BaseVolts[AI_CARD_TYPE_MAX][BASE_LINEAR_VOLTS_COUNT];///< Channel base voltage for AI board types (V6AI and V7AI)

#ifdef DBG_FILE_LOG_IO_COND_ERR_ENABLE
		CDebugFileLogger m_errorFileLogger; //PSR - DebugFile Logger integration
		short m_usErrLogCount[IO_READING_ERROR_COUNT+1];
#endif
#ifdef DBG_FILE_LOG_IO_COND_DBG_ENABLE
		CDebugFileLogger m_debugFileLogger; //PSR - DebugFile Logger integration
#endif
};

#endif // !defined(AFX_INPUTCONDITIONING_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_)

#endif		// _INPUTCONDITIONING_H

/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O conditioning
/// @n InputConditioning.cpp
/// @n implementation for the Input Conditioning class.
/// @author GKW
/// @date 28/07/2004
///
/// The value NaN (Not a Number) is used to represent a value that does not represent a real number.
/// NaN's are represented by a bit pattern with an exponent of all 1s and a non-zero fraction.
/// There are two categories of NaN: QNaN (Quiet NaN) and SNaN (Signalling NaN).
/// We must use the Quiet NaN to denote indeterminate operations, rather than invalid operations
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 117 Stability Project 1.112.1.3	7/2/2011 4:57:58 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 116 Stability Project 1.112.1.2	7/1/2011 4:38:21 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 115 Stability Project 1.112.1.1	3/17/2011 3:20:25 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 114 Stability Project 1.112.1.0	2/15/2011 3:03:10 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////

#include "CMMDefines.h"
#include "V6Config.h"
#include "V6IOProtocol.h"
#include "V6AISpecialCodes.H"
#include "V6IOErrorCodes.H"
#include "TraceDefines.h"
#include "SysInfo.h"
#include "V6defines.h"
#include "V6globals.h"
#include "flash.h"
#include <math.h>

#include "Conversion.h"

#include "SlotMap.h"

#include "AIRanges.h"

#include "LinearTable.h"
#include "Device.h"
#include "DeviceManager.h"
#include "FFConversionInfo.h"
#include "BrdStats.h"
#include "ATECal.h"
#include "InputConditioning.h"

#include "BaseProtocol.h"
#include "Protocol.h"			// For the burnout status

#include "ConfigManager.h"

#include "ppl.h"

#include "AICard.h"

#ifndef __cplusplus
#define __cplusplus
#endif

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif

const float MAX_AO_CURRENT = 24.0;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CInputConditioning::CInputConditioning()
#ifdef DBG_FILE_LOG_IO_COND_ERR_ENABLE
	: m_errorFileLogger(L"\\SDMemory\\IOConditioningErrLog.txt", FALSE, 5*1024*1024 )//ErrorFile with huge size and no recycle
	#endif
#ifdef DBG_FILE_LOG_IO_COND_DBG_ENABLE
	: m_debugFileLogger(L"\\SDMemory\\IOConditioningDbgLog.txt", FALSE, 10*1024*1024 )//ErrorFile with huge size and with recycle
	#endif
{
#ifdef DBG_FILE_LOG_IO_COND_ERR_ENABLE
	//	qDebug("Create new CInputConditioning\n");
	//	CreateDefaultIOCal( FALSE );
	for( short errType=0; errType < (IO_READING_ERROR_COUNT+1); errType++ )
	{
		m_usErrLogCount[errType] = 0;
	}
#endif
}

CInputConditioning::~CInputConditioning() {
	//	qDebug("Delete CInputConditioning class\n");
}

//******************************************************
///
/// Get the reference to the UI menu selection for the Input Condition.
///
/// @return The pointer to the UI selection structure.
/// 
//******************************************************
T_RECORDERCAL* CInputConditioning::GetInputConditioningSelect(void) {
	return &m_CalPointsToPersist.CalPoints;
}

//******************************************************
///
/// Calculates the AO count value for a given current.
/// @param[in] DVMAmps - The current in mAmps to output.
///
/// @return The AO count required.
/// 
//******************************************************
USHORT CInputConditioning::ConvertDVMAmpsToAOCount(const float DVMAmps) {
	return static_cast<USHORT>((DVMAmps / MAX_AO_CURRENT) * 0xffff);
}

//******************************************************
///
/// Calculates the current value for a given AO count.
/// @param[in] AOCount - The AO count.
///
/// @return The current in mAmps.
/// 
//******************************************************
float CInputConditioning::ConvertAOCountToDVMAmps(const USHORT AOCount) {
	return static_cast<float>(AOCount * static_cast<float>(MAX_AO_CURRENT / 0xffff));
}

//******************************************************
///
/// Obtains the working copy of the I/O board calibration requirement/status info.
/// @param[in] slotNo - The slot number being queried.
///
/// @return The I/O board calibration structure.
/// 
//******************************************************
T_IORANGECAL* CInputConditioning::GetIOBoardCalInfo(const USHORT slotNo, const USHORT range) {
	return &m_CalPointsToPersist.CalPoints.RecorderCals[slotNo].RangeCals[range];	///< On board calibration selection
}

#define RT_CAL_UPPER_TOLERENCE 0.045F
#define RT_CAL_LOWER_TOLERENCE 0.5F

#define RT_CAL_HIGH_SCALE_FACTOR 0.00005F
#define RT_CAL_LOW_SCALE_FACTOR 0.00001F
//******************************************************
///
// Calculates the excitation current in mA.
/// @param[in] sysChanNo - System channel number identification.
/// @param[in] rawValue - The raw excitation current reading.
/// @param[in] highCurrentSet - TRUE if high excitation current setting is selected.
/// @param[out] pCurrent - The excitation current in mA.
///
/// @return TRUE if the value has been normalised; otherwise FALSE - out of tolerence.
/// 
//******************************************************
BOOL CInputConditioning::NormaliseExcitationCurrent(const USHORT sysChanNo, const T_RANGE_COUNTS rawValue,
		const BOOL highCurrentSet, float *pCurrent) const {
	E_ERROR_REPORT_STAT reportStat = EERS_NO_REPORT_RQD;
	class CBrdStats *pBrdStats = NULL;
	class CSlotMap *pSlotMap = NULL;
	UCHAR failCount = 0;
	USHORT slotNo = 0;
	USHORT cardChanNo = 0;
	QString   strasprintf = "";

	BOOL retValue = TRUE;
	USHORT errorCode = 0;
	USHORT element = 0;
	float exitationI = 0.0F;
	float highI = 0.0F;
	float lowI = 0.0F;
	QString   errStr = "";

	pSlotMap = CSlotMap::GetHandle();
	pBrdStats = CBrdStats::GetHandle();
	pSlotMap->GetSlotAndChannelFromAnalSysChan(sysChanNo, &slotNo, &cardChanNo, ONE_BASED);
	// No error codes are ever returned instead of an RT cal value
	if (highCurrentSet == TRUE) {
		// Test that the current is no more than 50% low or 4.5% high. If too high then upper
		// end of range could not be acheived
		highI = (DEFAULT_CONSTANT_CURRENT_HIGH_MA * RT_CAL_UPPER_TOLERENCE) + DEFAULT_CONSTANT_CURRENT_HIGH_MA;
		lowI = DEFAULT_CONSTANT_CURRENT_HIGH_MA - (DEFAULT_CONSTANT_CURRENT_HIGH_MA * RT_CAL_LOWER_TOLERENCE);
		exitationI = (static_cast<float>(rawValue) * RT_CAL_HIGH_SCALE_FACTOR);
		if (exitationI > highI) {
			// Problem with current source
			errorCode = IO_SCHED_HIGH_RT_CAL_HIGH;
			retValue = FALSE;
			if (IsRunningAsATEEquipment() == TRUE) {
				errStr.asprintf(L"Sys Chan %d High constant current source output too high @ %f", sysChanNo,
						exitationI);
				AddErrorToReport(static_cast<LPCTSTR>(errStr));
			}
		} else if (exitationI < lowI) {
			// Problem with current source; or RT unplugged
			retValue = FALSE;
			errorCode = IO_SCHED_HIGH_RT_CAL_LOW;
			if (IsRunningAsATEEquipment() == TRUE) {
				errStr.asprintf(L"Sys Chan %d High constant current source output too low @ %f", sysChanNo, exitationI);
				AddErrorToReport(static_cast<LPCTSTR>(errStr));
			}
			if (exitationI == 0.0F) {
				// Resistor is very likely unplugged
				errStr.asprintf(L"Sys Chan %d; check for unplugged device", sysChanNo);
			}
		}
	} else {
		// Test that the current is no more than 50% low or 4.5% high. If too high then upper
		// end of range could not be acheived
		highI = (DEFAULT_CONSTANT_CURRENT_LOW_MA * RT_CAL_UPPER_TOLERENCE) + DEFAULT_CONSTANT_CURRENT_LOW_MA;
		lowI = DEFAULT_CONSTANT_CURRENT_LOW_MA - (DEFAULT_CONSTANT_CURRENT_LOW_MA * RT_CAL_LOWER_TOLERENCE);
		exitationI = (static_cast<float>(rawValue) * RT_CAL_LOW_SCALE_FACTOR);
		if (exitationI > highI) {
			// Problem with current source
			retValue = FALSE;
			errorCode = IO_SCHED_LOW_RT_CAL_HIGH;
			if (IsRunningAsATEEquipment() == TRUE) {
				errStr.asprintf(L"Sys Chan %d Low constant current source output too high @ %f", sysChanNo, exitationI);
				AddErrorToReport(static_cast<LPCTSTR>(errStr));
			}
		} else if (exitationI < lowI) {
			// Problem with current source; or RT/resistor unplugged
			retValue = FALSE;
			errorCode = IO_SCHED_LOW_RT_CAL_LOW;
			if (IsRunningAsATEEquipment() == TRUE) {
				errStr.asprintf(L"Sys Chan %d Low constant current source output too low @ %f", sysChanNo, exitationI);
				AddErrorToReport(static_cast<LPCTSTR>(errStr));
			}

			if (exitationI == 0.0F) {
				// Resistor is very likely unplugged, if there is no current
				errStr.asprintf(L"Sys Chan %d; check for unplugged device", sysChanNo);
			}
		}
	}

	if (retValue == TRUE)
		*pCurrent = exitationI;

	//	if( (IsRunningAsATEEquipment() == FALSE) && (FALSE == retValue) )
	if ( FALSE == retValue) {
		element = cardChanNo * HW_ANA_IN_CHAN_PER_BOARD + errorCode;
		if ((pBrdStats->CheckFailCount(slotNo, EERT_IO_READING_FAILURE, element, &failCount) == TRUE)
				&& (failCount <= ERROR_REPORT_CONTINUOUS)) {
			pBrdStats->LogFailure(slotNo, EERT_IO_READING_FAILURE, element);
		}

		if (errStr.IsEmpty() == FALSE) {
			reportStat = pBrdStats->CheckReportStatus(slotNo, EERT_IO_READING_FAILURE, element);
			if (reportStat != EERS_NO_REPORT_RQD) {
				if (reportStat == EERS_REPORT_MANY) {
					if (exitationI != 0.0F) {
						// Don't bother reporting unplugged devices more than once
						strasprintf.asprintf(L"NormI>%d failures: %s",
						ERROR_REPORT_MANY, errStr);
						AddErrorToReport(static_cast<LPCTSTR>(strasprintf));
					}
				} else if (reportStat == EERS_REPORT_CONTINUOUS) {
					if (exitationI != 0.0F) {
						// Don't bother reporting unplugged devices more than once
						strasprintf.asprintf(L"NormI>%d failures: %s",
						ERROR_REPORT_CONTINUOUS, errStr);
						AddErrorToReport(static_cast<LPCTSTR>(strasprintf));
					}
				} else {
					strasprintf.asprintf(L"%s", errStr);
					AddErrorToReport(static_cast<LPCTSTR>(strasprintf));
				}
			}
		}
	}

	return retValue;
}

//******************************************************
///
/// Calculates the RT comp voltage in mV.
/// @param[in] slotNo - The card slot number.
/// @param[in] rawValue - The raw lead measurement reading.
/// @param[in] highCurrentSet - TRUE if high excitation current setting is selected.
///
/// @return The mV voltage drop in both leads.
/// 
/// Rev History
/// @Version	@Date			@Author					@Remarks
/// 2.0			17/Apr/2019		Shankar Rao	Pendyala	RtComp with New AI card (24Bit ADC/Channel Readings) and Old AI Card (16Bit)
/////////////////////////////////////////////////////
//
//******************************************************
float CInputConditioning::NormaliseRTComp(const USHORT slotNo, const T_RANGE_COUNTS rawValue,
		const BOOL highCurrentSet) const {
	class CBrdInfo *pBrdInfoObj = NULL;		///< Board info holder
	float leadmV = 0.0F;

	pBrdInfoObj = CBrdInfo::GetHandle();
	if (highCurrentSet == TRUE) {
		leadmV = GetRTCompHigh(slotNo)->CalcSourceToDest(static_cast<float>(rawValue));
	} else {
		leadmV = GetRTCompLow(slotNo)->CalcSourceToDest(static_cast<float>(rawValue));
	}

	return leadmV;
}

//******************************************************
///
/// Resyncs the I/O card local time stamp to that required by the pre-process queues.
/// @param[in] timebase - The I/O cards returned timebase (0-0xffff).
/// @param[in] PPGearingRatio - The pre-process queues gearing ratio.
///
/// @return The pre-process synced timeline.
/// 
//******************************************************
ULONG CInputConditioning::SyncIOToPreProcessTimeLine(const USHORT timebase, const UCHAR PPGearingRatio) {
	return static_cast<ULONG>(timebase * PPGearingRatio);
}

//******************************************************
///
/// Converts the InpValue to the Square root extracted interpretation.
/// Note that the output can never be less than 0mA.
/// @param[in] InpValue - The value to SQRT extract.
/// @param[in] EngZero - The channels sqrt extract zero value.
/// @param[in] EngSpan - The channels sqrt extract span value.
///
/// @return input value square root extracted.
/// 
//******************************************************
float CInputConditioning::ConvertToSQRTExtract(const float InpValue, const float EngZero, const float EngSpan) {
	float sqrtExtract = 0.0F;
	float InpSubRangeSpan = 0.0F;

	InpSubRangeSpan = EngSpan - EngZero;

	// Take the sqrt of the input scaled to 0-1
	sqrtExtract = sqrt((InpValue - EngZero) / InpSubRangeSpan);

	return sqrtExtract;
}

//******************************************************
///
/// Converts the InpValue to the 5/2 Law variation.
/// Note that the output can never be less than 0mA.
/// @param[in] InpValue - The value to have the law appiled to.
/// @param[in] - The channel user range selection.
/// @param[in] - The channels engineering values.
///
/// @return input value square root extracted.
/// 
//******************************************************
float CInputConditioning::ConvertTo52Law(const float InpValue) const {
	float ret52Law = 0.0F;

	return ret52Law;
}

//******************************************************
///
/// Converts the InpValue to the 5/2 Law variation.
/// Note that the output can never be less than 0mA.
/// @param[in] InpValue - The value to have the law appiled to.
/// @param[in] - The channel user range selection.
/// @param[in] - The channels engineering values.
///
/// @return input value square root extracted.
/// 
//******************************************************
float CInputConditioning::ConvertTo32Law(const float InpValue) const {
	float ret32Law = 0.0F;

	return ret32Law;
}

//******************************************************
///
/// Gets the handle to the device manager.
///
/// @return The device manager handle.
/// 
//******************************************************
class CDeviceManager* CInputConditioning::GetDeviceManager(void) {
	return &m_DevManager;
}

//******************************************************
///
/// Checks whether the main channel reading is missing for a scheduled reason.
/// @param[in] EngValue - The value to convert.
///
/// @return TRUE if a value is missing for a scheduled reason.
/// 
//******************************************************
BOOL CInputConditioning::IsValueAScheduledMissing(const T_RANGE_COUNTS EngValue) {
	USHORT Limited = EngValue;

	if ((EngValue == MISSING_RT_CAL) || (EngValue == MISSING_RT_COMP) || (EngValue == MISSING_ACTBNOUT))
		return TRUE;

	return FALSE;
}

//******************************************************
///
/// Rescale an input value into new units.
/// @param[in] EngValue - The value to rescale.
/// @param[in] UnitsIn - The input value units.
/// @param[in] UnitsOut - The output value units.
///
/// @return Rescaled value from input units to output units.
/// 
//******************************************************
float CInputConditioning::RescaleValue(float EngValueIn, const IO_MEASURE_UNITS UnitsIn,
		const IO_MEASURE_UNITS UnitsOut) {
	if (UnitsIn != UnitsOut) {
		// Rescale input to units
		switch (UnitsIn) {
		case MEGA:
			EngValueIn = EngValueIn / 1000000;
			break;
		case KILO:
			EngValueIn = EngValueIn / 1000;
			break;
		case UNITS:
			break;
		case MICRO:
			EngValueIn = EngValueIn * 1000;
		case MILLI:
			EngValueIn = EngValueIn * 1000;
			break;
			// Can't use with float precision
		case NANO:
			break;
		case PICO:
			break;
		};

		// Scale to new output units
		switch (UnitsOut) {
		case MEGA:
			EngValueIn = EngValueIn / 1000;
		case KILO:
			EngValueIn = EngValueIn / 1000;
		case UNITS:
			break;
		case MICRO:
			EngValueIn = EngValueIn * 1000;
		case MILLI:
			EngValueIn = EngValueIn * 1000;
			break;
			// Can't use with float precision
		case NANO:
			break;
		case PICO:
			break;
		};
	}

	return EngValueIn;
}

//******************************************************
///
/// Limits the RT Comp value to 0mV or positive.
/// @param[in] EngValue - The value to convert.
/// @param[out] pLimitedValue - The zero limited RT comp value.
///
/// @return TRUE if the RT comp value is legal (even if limited); otherwise FALSE.
/// 
/// Rev History
/// @Version	@Date			@Author					@Remarks
/// 2.0			17/Apr/2019		Shankar Rao	Pendyala	Function not used ...so no changes for RtComp with 
///														New AI card (24Bit ADC/Channel Readings) and Old AI Card (16Bit)
//******************************************************
BOOL CInputConditioning::LimitRTComp(const T_RANGE_COUNTS EngValue,
T_RANGE_COUNTS *const pLimitedValue) {
	BOOL retValue = TRUE;

	*pLimitedValue = EngValue;

	if (EngValue == NO_RTCOMP_READING) {
		//
		/// Issue a warning of missing RT Comp reading
		AddErrorToReport(L"Warning missing RT Comp reading");
		retValue = FALSE;
	}

	if ((EngValue == SCALED_VALUE_UNDER) || (EngValue == ADC_VALUE_UNDER) || (EngValue == NO_RTCOMP_READING)) {
		// Limit these special circumstances to 0mV
		*pLimitedValue = INTERN_CENTRE;
	} else if ((EngValue == SCALED_VALUE_OVER) || (EngValue == ADC_VALUE_OVER)) {
		// Set these special circumstances to highest output available
		*pLimitedValue = USHRT_MAX;
	} else if (EngValue < INTERN_CENTRE)
		*pLimitedValue = INTERN_CENTRE;			// Limit to 0mV
	else if (EngValue >= START_OF_SPECIAL_CODES) {
		*pLimitedValue = INTERN_CENTRE;

		/// Log unspecified error returned from I/O card
		LogInternalError("Unspecified RT reading error returned from I/O card");
		retValue = FALSE;
	}

	return retValue;
}

//******************************************************
///
/// Applies the TC passive burnout.
/// @param[in] upscaleBurnout - TRUE if upscale burnout.
/// @param[in] EngValue - The value to convert.
/// @param[in] upscaleBurnout - TRUE if upscale burnout.
/// @param[in] EngValue - The value to convert.
/// @param[out] pLimitedValue - The TC value to use.
///
/// @return TRUE if the T/C has burnt out; otherwise FALSE.
/// 
//******************************************************
BOOL CInputConditioning::ApplyTCPassiveBurnout(const USHORT slotNo, const USHORT channel, const BOOL upscaleBurnout,
		const T_RANGE_COUNTS EngValue, float *const pLimitedValue) {
	BOOL retValue = FALSE;

	if ((EngValue == SCALED_VALUE_UNDER) || (EngValue == ADC_VALUE_UNDER)) {
		retValue = ApplyTCPPQBurnout(slotNo, channel, upscaleBurnout, pLimitedValue);
	}

	return retValue;
}

//******************************************************
///
/// Applies the TC pre-process queue burnout.
/// @param[in] upscaleBurnout - TRUE if upscale burnout.
/// @param[in] EngValue - The value to convert.
/// @param[in] upscaleBurnout - TRUE if upscale burnout.
/// @param[out] pLimitedValue - The TC value to use.
///
/// @return TRUE if the T/C has burnt out; otherwise FALSE.
/// 
//******************************************************
BOOL CInputConditioning::ApplyTCPPQBurnout(const USHORT slotNo, const USHORT channel, const BOOL upscaleBurnout,
		float *const pLimitedValue) {
	BOOL retValue = FALSE;

	if (upscaleBurnout == TRUE)
		CreateFloatingPointRepresentation( IO_SCHED_BRNOUT_UPSCALE, pLimitedValue);
	else
		CreateFloatingPointRepresentation( IO_SCHED_BRNOUT_DOWNSCALE, pLimitedValue);

	retValue = TRUE;

	return retValue;
}

//******************************************************
///
/// Tests whether float value is a number or error (NAN).
/// @param[in] floatVal - The value to be tested.
///
/// @return TRUE if the value is an error code; otherwise FALSE.
/// 
//******************************************************
BOOL CInputConditioning::TestFloatError(const float floatVal) {
	BOOL retValue = FALSE;
	const UINT errorTest = *(reinterpret_cast<const UINT*>(&floatVal)); // cast float to UINT.

	// Test the exponent to see if code is NAN
	if ((errorTest & NAN_EXPONENT) == NAN_EXPONENT) {
		// Value is Not a Number (NaN), therefore is an error (Does not matter whether it is quiet or signal)
		retValue = TRUE;
	}

	return retValue;
}

//******************************************************
///
/// Tests whether float value is a number or error (NAN).
/// @param[in] floatVal - The value to be tested.
///
/// @return TRUE if the value is an error code; otherwise FALSE.
/// 
//******************************************************
BOOL CInputConditioning::TestFloatLimitError(const float floatVal) {
	BOOL retValue = FALSE;

	// Test the exponent to see if code is NAN
	if ((floatVal == FLT_MAX) || (floatVal == -FLT_MAX)) {
		// Value is Not a Number (NaN), therefore is an error
		retValue = TRUE;
	}

	return retValue;
}

//******************************************************
///
/// Queries whether user or factory calibration is selected for a given board channel
/// @param[in] slotNo - The card slot number.
/// @param[in] chanNo - The card channel number.
/// @param[in] rangeNo - Channel range selction.
///
/// @return whether factory or user calibration is selected
/// 
//******************************************************
CInputConditioning::IO_CAL_OPTIONS CInputConditioning::QueryIOBoardChanRangeCalInfo(const USHORT slotNo,
		const USHORT chanNo, const USHORT rangeNo) const {
	IO_CAL_OPTIONS calSel = V6_IO_FACTORY_CALIBRATION;

	calSel =
			static_cast<IO_CAL_OPTIONS>(m_CalPointsToPersist.CalPoints.RecorderCals[slotNo].RangeCals[rangeNo].Channel[chanNo]);

	return calSel;
}

#define MANTISSA_BIT_MASK	0xFFFF
//******************************************************
///
/// Converts input conditioning style NAN to status used by the Data Item Table.
/// @param[in] floatVal - The value containing the error code.
///
/// @return The DIT status of the reading.
/// @Note: Only the reading is being analysed in terms of NaN status
///		therefore the status returned is potentially only additional to any current DIT status
/// 
//******************************************************
T_DATAITEM_STATUS CInputConditioning::ConvertFloatErrorToDITStatus(const float floatVal) {
	BOOL retValue = FALSE;
	USHORT errorCode = 0;
	const UINT errorTest = *(reinterpret_cast<const UINT*>(&floatVal)); // cast float to UINT.
	T_DATAITEM_STATUS DITstatus = DISTAT_NORMAL;

	// Test the exponent to see if code is NAN
	if ((errorTest & NAN_EXPONENT) == NAN_EXPONENT) {
		// Value is Not a Number (NaN), therefore is an error

		// Get the mantissa containing error code
		errorCode = static_cast<USHORT>(errorTest & MANTISSA_BIT_MASK);

		// Realign to closest match in the Data Item Table status
		if (errorCode == IO_SCHED_BRNOUT_UPSCALE)
			DITstatus = DISTAT_INPUT_UPSCALE_BURNOUT;
		else if (errorCode == IO_SCHED_BRNOUT_DOWNSCALE)
			DITstatus = DISTAT_INPUT_DOWNSCALE_BURNOUT;
		else if (errorCode == SCALED_VALUE_OVER)
			DITstatus = DISTAT_INPUT_OVERRANGE;
		else if (errorCode == SCALED_VALUE_UNDER)
			DITstatus = DISTAT_INPUT_UNDERRANGE;
		else if (errorCode == ADC_VALUE_OVER)
			DITstatus = DISTAT_INPUT_OVERRANGE;
		else if (errorCode == ADC_VALUE_UNDER)
			DITstatus = DISTAT_INPUT_UNDERRANGE;
		else if (errorCode == IO_SCHED_ADC_VALUE_OVER)
			DITstatus = DISTAT_INPUT_OVERRANGE;
		else if (errorCode == IO_SCHED_ADC_VALUE_UNDER)
			DITstatus = DISTAT_INPUT_UNDERRANGE;
		else if (errorCode == IO_SCHED_ABOVE_TABLE)
			DITstatus = DISTAT_INPUT_OVERRANGE;
		else if (errorCode == IO_SCHED_BELOW_TABLE)
			DITstatus = DISTAT_INPUT_UNDERRANGE;
		else if (errorCode == IO_SCHED_MISSING_RT_COMP)
			DITstatus = DISTAT_INVALID;	///< Currently keep the same failure failure mode for compatability
		else if (errorCode == IO_SCHED_MISSING_RT_CAL)
			DITstatus = DISTAT_INVALID;	///< Currently keep the same failure failure mode for compatability
		else
			DITstatus = DISTAT_INVALID;
#ifdef DBG_FILE_LOG_IO_COND_ERR_ENABLE
		//// Errr log
		if( ( errorCode >= MISSING_RT_CAL ) || ( errorCode <= IO_SCHED_CHAN_US ) )
		{
			short errType = errorCode - MISSING_RT_CAL;
			short usErrLogCount = m_usErrLogCount[errType];
			usErrLogCount++;
			m_usErrLogCount[errType] = usErrLogCount;

			if( (usErrLogCount > 0) && (usErrLogCount < 300) )
			{
				QString  strLogMessage;
				strLogMessage.asprintf(L"CInputConditioning::ConvertFloatErrorToDITStatus ErrorCode(%d):Count(%d) - GTC:%d\r\n", errorCode, usErrLogCount, GetTickCount() );
				m_errorFileLogger.WriteToDebugLogFile(strLogMessage);
			}
			else
			{
				m_usErrLogCount[errType] = 0;
			}

		}
		else
		{
			short errType = IO_READING_ERROR_COUNT; //This can be a value of (64801 to 64999) or (>65025)
			short usErrLogCount = m_usErrLogCount[errType];
			usErrLogCount++;
			m_usErrLogCount[errType] = usErrLogCount;

			if( (usErrLogCount > 0) && (usErrLogCount < 1000) )
			{
				QString  strLogMessage;
				strLogMessage.asprintf(L"CInputConditioning::InvalidDITStatus ErrorCode(%d):Count(%d) - GTC:%d\r\n", errorCode, usErrLogCount, GetTickCount() );
				m_errorFileLogger.WriteToDebugLogFile(strLogMessage);
			}
		}
#endif
	}

	return DITstatus;
}

//******************************************************
///
/// Converts and stores the burnout status input from the protocol into that that is used throughout
/// the system for user notification.
/// @param[in] slotNo - The card slot number.
/// @param[in] chanNo - The card channel number.
/// @param[in] protocolBurnoutValue - The value containing the error code from the protocol.
///
/// @return The rolled up system status of the reading.
/// 
//******************************************************
CInputConditioning::IO_BURNOUT_STATUS CInputConditioning::ConvertStoreBurnoutResponse(const USHORT slotNo,
		const USHORT chanNo, const UCHAR protocolBurnoutValue) const {
	CBrdStats *pBrdStatsObj = NULL;
	IO_BURNOUT_STATUS burnoutStatus = BURNOUT_DISABLED;

	pBrdStatsObj = CBrdStats::GetHandle();
	switch (protocolBurnoutValue) {
	// Active burnout status (status code)
	case ABS_DISABLED:
		burnoutStatus = BURNOUT_DISABLED;
		break;
	case ABS_TC_OK:
		burnoutStatus = BURNOUT_OK;
		break;
	case ABS_TC_DEGRADED:
		burnoutStatus = BURNOUT_TC_DEGRADED;
		break;
	case ABS_TC_FAILING_DIFF:
		burnoutStatus = BURNOUT_TC_FAILING;
		break;
	case ABS_TC_ALMOST_FAILED_DIFF:
		burnoutStatus = BURNOUT_TC_ALMOST_FAILED;
		break;
	case ABS_TC_FAILING:
		burnoutStatus = BURNOUT_TC_FAILING;
		break;
	case ABS_TC_ALMOST_FAILED:
		burnoutStatus = BURNOUT_TC_ALMOST_FAILED;
		break;
	case ABS_TC_FAILED_NO_DATA:
		burnoutStatus = BURNOUT_TC_OC_DETECTED;
		break;
	case ABS_TC_FAILED_ACTIVE_ONLY:
		burnoutStatus = BURNOUT_TC_OC_DETECTED;
		break;
	case ABS_TC_FAILED_PASSIVE_AND_ACTIVE:
		burnoutStatus = BURNOUT_TC_OC_DETECTED;
		break;
	case ABS_TC_SC_DETECTED:
		burnoutStatus = BURNOUT_TC_SC_DETECTED;
		break;
	default:
		// Should never occur
		burnoutStatus = BURNOUT_DISABLED;
		break;
	}
	pBrdStatsObj->SetChanTCBurnoutState(slotNo, chanNo, burnoutStatus);

	return burnoutStatus;
}

//******************************************************
///
/// Creates a floating point representation of the engineering value passed in.
/// Note also I/O board errors checks and converts data error codes return is data stream and converts them to
/// their floating point representations
/// @param[in] EngValue - The value to convert.
/// @param[out] pLimitedValue - The channel value or error code encoded as a float.
///
/// @Note: Need to avoid creating NAN errors codes defined by the IEEE 754 floating point spec, unless they
/// have a simular meaning i.e. infinity etc.
/// @return TRUE if value is valid; otherwise FALSE if a special code.
/// 
//******************************************************
const BOOL CInputConditioning::CreateFloatingPointRepresentation(const T_RANGE_COUNTS EngValue,
		float *const pLimitedValue) {
	BOOL retValue = TRUE;
	UINT mantissa = static_cast<UINT>(EngValue); ///< mantissa containing error code
	UINT *const pErrorCode = (reinterpret_cast<UINT* const >(pLimitedValue)); // cast float to UINT.

	if (EngValue >= START_OF_SPECIAL_CODES) {
		*pErrorCode = NAN_EXPONENT | QUIET_NAN | mantissa;

		retValue = FALSE;
	} else {
		*pLimitedValue = static_cast<float>(EngValue);
	}

	return retValue;
}

//******************************************************
///
/// Checks for data error codes return in data stream and displays when approriate
/// @param[in] cardNo - Card slot number identification.
/// @param[in] cardChanNo - Card slot channel number identification.
/// @param[in] EngValue - The value to convert.
///
/// @return TRUE if value is valid; otherwise FALSE if a special code.
/// 
//******************************************************
void CInputConditioning::ReportReadingError(const USHORT cardNo, const USHORT cardChanNo,
		const T_RANGE_COUNTS EngValue) {
	USHORT Limited = EngValue;
	BOOL errFound = FALSE;
	UCHAR failCount;
	USHORT element = 0;
	E_ERROR_REPORT_STAT reportStat = EERS_NO_REPORT_RQD;
	CBrdStats *pBrdStatsObj = NULL;
	BOOL dontReport = FALSE;
	class CSlotMap *pSlotMap = NULL;
	WCHAR boardSlotStr[4];
	QString   errStr;
	QString   reportStr;

	pBrdStatsObj = CBrdStats::GetHandle();
	pSlotMap = CSlotMap::GetHandle();
	pSlotMap->GetSlotStrID(cardNo, boardSlotStr);

	// Check reading for error in data stream
	if (EngValue >= START_OF_SPECIAL_CODES) {
		if (EngValue == MISSING_ACTBNOUT)
			errStr.asprintf(L"MISSING ACTIVE BURNOUT");
		else if (EngValue == MISSING_INPUT)
			errStr.asprintf(L"MISSING INPUT");
		else if (EngValue == ACTBNOUT_OPEN)
			errStr.asprintf(L"ACTIVE BURNOUT OPEN");
		else if (EngValue == SCALED_VALUE_OVER)
			errStr.asprintf(L"SCALED VALUE OVER");
		else if (EngValue == SCALED_VALUE_UNDER)
			errStr.asprintf(L"SCALED_VALUE_UNDER");
		else if (EngValue == ADC_VALUE_OVER)
			errStr.asprintf(L"ADC VALUE OVER");
		else if (EngValue == ADC_VALUE_UNDER)
			errStr.asprintf(L"ADC VALUE UNDER");
		else if (EngValue == NO_RTCOMP_READING)
			errStr.asprintf(L"NO RTCOMP READING");

		// Check reading for morphed error
		else if (EngValue == IO_SCHED_MISSING_RT_COMP) {
			errStr.asprintf(L"I/O RT COMP VALUE MISSING");
			//			dontReport = TRUE;			///< Do not report this error - can already be found on the pen
		} else if (EngValue == IO_SCHED_MISSING_RT_CAL) {
			errStr.asprintf(L"I/O RT CAL VALUE MISSING");
			//			dontReport = TRUE;			///< Do not report this error - can already be found on the pen
		} else if (EngValue == IO_SCHED_ADC_VALUE_OVER) {
			errStr.asprintf(L"ADC VALUE OVER DURING CALIBRATION");
			//			dontReport = TRUE;			///< Do not report this error - can already be found on the pen
		} else if (EngValue == IO_SCHED_ADC_VALUE_UNDER) {
			errStr.asprintf(L"ADC VALUE UNDER DURING CALIBRATION");
			//			dontReport = TRUE;			///< Do not report this error - can already be found on the pen
		} else if (EngValue == IO_SCHED_MISSING_CJC) {
			errStr.asprintf(L"I/O CJC VALUE MISSING");
			//			dontReport = TRUE;			///< Do not report this error - can already be found on the pen
		} else if (EngValue == IO_SCHED_CHAN_US) {
			errStr.asprintf(L"I/O VALUE MISSING FROM I/O BOARD");
			//			dontReport = TRUE;			///< Do not report this error - can already be found on the pen
		}

		else {
			//			identifiedError = FALSE;
			errStr.asprintf(L"UNSPECIFIED ERROR %d", EngValue);
		}

		if (dontReport == FALSE) {
			element = cardChanNo * HW_ANA_IN_CHAN_PER_BOARD + EngValue;
			// Check on report status and report if its time
			if ((pBrdStatsObj->CheckFailCount(cardNo, EERT_IO_READING_FAILURE, EngValue, &failCount) == TRUE)
					&& (failCount <= ERROR_REPORT_CONTINUOUS)) {
				pBrdStatsObj->LogFailure(cardNo, EERT_IO_READING_FAILURE, EngValue);
			}

			reportStat = pBrdStatsObj->CheckReportStatus(cardNo, EERT_IO_READING_FAILURE, EngValue);
			if (reportStat != EERS_NO_REPORT_RQD) {
				if (reportStat == EERS_REPORT_MANY) {
					reportStr.asprintf(L">%d failures slot %d chan %d: %s",
					ERROR_REPORT_MANY, boardSlotStr, cardChanNo, errStr);
				} else if (reportStat == EERS_REPORT_CONTINUOUS) {
					reportStr.asprintf(L">%d failures slot %s chan %d: %s",
					ERROR_REPORT_CONTINUOUS, boardSlotStr, cardChanNo, errStr);
				} else {
					reportStr.asprintf(L" slot %s chan %d: %s", boardSlotStr, cardChanNo, errStr);
				}

				AddErrorToReport(static_cast<LPCTSTR>(reportStr));
			}
		}
	}
}

//******************************************************
// SetAIChannelCJCUserCalPoint()
///
/// Gets a channel calibration points.
/// @param[in] cardNo - The system card slot number.
/// @param[in] chanNo - The system channel number.
/// @param[in] userCJCOffset - The user cal offset of the channel.
///
/// @return TRUE if the given cal points could be obtained (i.e. channel is present
///		and currently selected as a TC; otherwise FALSE
///
//******************************************************
BOOL CInputConditioning::SetAIChannelCJCUserCalPoint(const USHORT cardNo, const USHORT chanNo, float userCJCOffset) {
	BOOL retValue = FALSE;

	m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].CJCCals.UserCal = userCJCOffset;
	retValue = TRUE;

	return retValue;
}

//******************************************************
// SetAIChannelCJCFactoryCalPoint()
///
/// Gets a channel calibration points.
/// @param[in] cardNo - The system card slot number.
/// @param[in] chanNo - The system channel number.
/// @param[in] factCJCOffset - The factory cal offset of the channel.
///
/// @return TRUE if the given cal points could be obtained (i.e. channel is present
///		and currently selected as a TC; otherwise FALSE
///
//******************************************************
BOOL CInputConditioning::SetAIChannelCJCFactoryCalPoint(const USHORT cardNo, const USHORT chanNo, float factCJCOffset) {
	BOOL retValue = FALSE;

	m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].CJCCals.FactCal = factCJCOffset;
	retValue = TRUE;

	return retValue;
}

//******************************************************
// GetAIChannelCJCCalPoints()
///
/// Gets a channel calibration points.
/// @param[in] cardNo - The system card slot number.
/// @param[in] chanNo - The system channel number.
/// @param[out] factCJCOffset - The factory cal offset of the channel.
/// @param[out] userCJCOffset - The user cal offset of the channel.
///
/// @return TRUE if the given cal points could be obtained (i.e. channel is present
///		and currently selected as a TC; otherwise FALSE
///
//******************************************************
BOOL CInputConditioning::GetAIChannelCJCCalPoints(const USHORT cardNo, const USHORT chanNo, float &factCJCOffset,
		float &userCJCOffset) const {
	BOOL retValue = FALSE;

	factCJCOffset = m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].CJCCals.FactCal;
	userCJCOffset = m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].CJCCals.UserCal;
	retValue = TRUE;

	return retValue;
}

//******************************************************
// GetAIChannelCJCFactoryCaledValue()
///
/// Gets a channel calibration points.
/// @param[in] cardNo - The system card slot number.
/// @param[in] chanNo - The system channel number.
/// @param[out] factCJCValue - The factory cal'ed CJ of the channel.
///
/// @return TRUE if the given cal points could be obtained (i.e. channel is present
///		and currently selected as a TC; otherwise FALSE
///
//******************************************************
BOOL CInputConditioning::GetAIChannelCJCFactoryCaledValue(const USHORT cardNo, const USHORT chanNo,
		float &factCJCValue) const {
	class CDataItem *pDataItem = NULL;
	class CSlotMap *pSlotMap = NULL;		// System slot map
	T_PCHANCJCCAL pChanCal = NULL;
	BOOL retValue = FALSE;
	USHORT CJCDegCNo = 0;
	float CJValue = 0.0F;

	// The user CJC calibration must be obtained from the committed CMM; the factory can never be overridden
	// so use the member variable values
	pSlotMap = CSlotMap::GetHandle();
	if (pSlotMap != NULL) {
		CJCDegCNo = CDataItemTypeIO::GetCJCDIRef(cardNo, chanNo, true);
		pDataItem = pDIT->GetDataItemPtr(DI_IO, DI_IO_CJC_MULTI_CHAN, CJCDegCNo);

		if (pDataItem != NULL) {
			factCJCValue = m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].CJCCals.FactCal
					+ pDataItem->GetFPValue();
			retValue = TRUE;
		}
	}

	return retValue;
}

//******************************************************
// SetCJCCalValueUsage()
///
/// Set the type current CMM configuration type for an analogue board.
/// @param[in] cardNo - The recorder I/O board slot number.
/// @param[in] cfgType - The type of configuration to access.
///
/// @return TRUE if the given cal points could be obtained; otherwise FALSE
///
//******************************************************
BOOL CInputConditioning::SetCJCCalValueUsage(USHORT cardNo, REFERENCE cfgType) {
	USHORT chanNo = 0;
	T_PCHANCJCCAL pChanCal = NULL;
	BOOL retValue = TRUE;

	for (chanNo = 0; chanNo < BOARDCALS_CHANCALS_SIZE; chanNo++) {
		pChanCal = pGlbSetup->GetIOSetupConfig()->GetAnalogueCJCal(cardNo, chanNo, cfgType);
		if (pChanCal != NULL) {
			m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].CJCCals.UserCal = pChanCal->UserCal;
		} else {
			retValue = FALSE;
		}
	}

	return retValue;
}

//******************************************************
// GetAIChannelCJCCaledValue()
///
/// Gets a channel calibration points.
/// @param[in] cardNo - The system card slot number.
/// @param[in] chanNo - The system channel number.
/// @param[out] factCJCValue - The factory cal'ed CJ of the channel.
/// @param[out] userCJCValue - The user cal'ed CJ of the channel.
/// @param[in] cfgType - The type of configuration to access.
///
/// @return TRUE if the given cal points could be obtained (i.e. channel is present
///		and currently selected as a TC; otherwise FALSE
///
//******************************************************
BOOL CInputConditioning::GetAIChannelCJCCaledValue(const USHORT cardNo, const USHORT chanNo, float &factCJCValue,
		float &userCJCValue, const REFERENCE cfgType) const {
	class CDataItem *pDataItem = NULL;
	class CSlotMap *pSlotMap = NULL;		// System slot map
	T_PCHANCJCCAL pChanCal = NULL;
	BOOL retValue = FALSE;
	USHORT CJCNo = 0;
	USHORT CJCDegCNo = 0;
	float CJValue = 0.0F;

	// The user CJC calibration must be obtained from the modifable CMM or committed CMM depending upon type being queried
	pChanCal = pGlbSetup->GetIOSetupConfig()->GetAnalogueCJCal(cardNo, chanNo, cfgType);
	if (pChanCal != NULL) {
		userCJCValue = pChanCal->UserCal;

		///< If the user calibrated temperature output is not Deg C, then convert
		//		userCJCValue = pSYSTEM_INFO->GetLocalTempFromDegC( userCJCValue );
	}

	pSlotMap = CSlotMap::GetHandle();
	if (pSlotMap != NULL) {
		if (pSlotMap->ObtainBoardsDICJCRef(cardNo, &CJCNo, &CJCDegCNo) == TRUE)
			pDataItem = pDIT->GetDataItemPtr(DI_IO, DI_IO_MISC, CJCDegCNo);
		if (pDataItem != NULL) {
			factCJCValue = pChanCal->FactCal + pDataItem->GetFPValue();

			///< If the factory calibration temperature output is not Deg C, then convert
			//			factCJCValue = pSYSTEM_INFO->GetLocalTempFromDegC( factCJCValue );
		}

		retValue = TRUE;
	}

	return retValue;
}

//******************************************************
///
/// Converts an error code into a V7 error code if the card is of that type
/// @param[in] cardNo - Card slot number identification.
/// @param[in] v6ErrorCode - the error code we might need to convert
///
/// @return the error code normalized for the particular card type in the slot
///
//******************************************************
const T_RANGE_COUNTS CInputConditioning::GetErrorCodeForSlotType(const USHORT cardNo,
		const T_RANGE_COUNTS v6ErrorCode) {
	T_RANGE_COUNTS aiCardTypeNormalizedErrorCode = v6ErrorCode;

	CBrdInfo *pBrdInfoObj = CBrdInfo::GetHandle();
	UCHAR ucBoardRev = V6AI_ISSUE_1;

	pBrdInfoObj->GetBoardHardwareRevision(cardNo, &ucBoardRev);
	UCHAR ucAICardSubType = CAICard::WhatBoardSubType(ucBoardRev);

	if (AI_CARD_TYPE_V7AI == ucAICardSubType) {
		// this is a V7 AI card so take off the V6 AI error code start range and add the V7 start range
		aiCardTypeNormalizedErrorCode = (v6ErrorCode - MISSING_RT_CAL) + V7IO_ERROR_CODE_START;
	}

	return aiCardTypeNormalizedErrorCode;
}

//******************************************************
///
/// Limits an analogue channel to legal values.
/// Checks for data error codes return is data stream and converts them to
/// their floating point representations
/// @param[in] cardNo - Card slot number identification.
/// @param[in] cardChanNo - Card slot channel number identification.
/// @param[in] rawValue - TRUE if raw mode readings are being provided; otherwise FALSE.
/// @param[in] EngValue - The value to convert.
/// @param[out] pLimitedValue - The channel value or error code encoded as a float.
///
/// @return TRUE if value is valid; otherwise FALSE if a special code.
///
/// Rev History
/// @Version	@Date			@Author					@Remarks
/// 2.0			02/Apr/2019		Shankar Rao	Pendyala	Error Code Compatibility with New AI card (24Bit ADC/Channel Readings) and Old AI Card (16Bit)
//******************************************************
BOOL CInputConditioning::LimitAnalogueChannel(const USHORT cardNo, const USHORT cardChanNo, const BOOL rawValue,
		const T_RANGE_COUNTS EngValue, float *const pLimitedValue, const USHORT chanType) {
	T_RANGE_COUNTS Limited = EngValue;
	BOOL errFound = FALSE;
	UCHAR errorCode;
	BOOL identifiedError = FALSE;
	UINT *const pErrorCode = (reinterpret_cast<UINT* const >(pLimitedValue)); // cast float to UINT.
	E_ERROR_REPORT_STAT reportStat = EERS_NO_REPORT_RQD;
	CBrdStats *pBrdStatsObj = NULL;

	if (rawValue == FALSE) /// Do not check in raw mode (any value can be returned)
	{
		//Get Error Code from Eng Value
		COMBO_VAR4 var4ErrCode;
		var4ErrCode.ul = 0L; //No error present

		if ( TRUE == ConvertEngValueToV6IOErrorCode(cardNo, EngValue, var4ErrCode, chanType)) {
			UINT mantissa = var4ErrCode.ul; ///< mantissa containing error code
			*pErrorCode = NAN_EXPONENT | QUIET_NAN | mantissa;
			errFound = TRUE;
			identifiedError = TRUE;

			pBrdStatsObj = CBrdStats::GetHandle();

			// Serailise the channel reading error
			if (identifiedError == TRUE)
				errorCode = (var4ErrCode.ul - MISSING_RT_CAL) + (cardChanNo * IO_READING_ERROR_COUNT);
			else
				errorCode = IO_READING_ERROR_COUNT + 1;

			//			ReportReadingError( cardNo, cardChanNo, EngValue );
		}
	}

	if (errFound == FALSE) {
		// Reading is legal; convert to a float
		*pLimitedValue = static_cast<float>(EngValue); // < All is OK with reading
	}

	return !errFound;
}

//******************************************************
///
/// Calculates the resistance from the source current, voltage drop across
/// the resistor and single RT lead and ohms law (3 wire measurement).
/// @param[in] slotNo - Card slot number identification.
/// @param[in] ResistorV - The V drop measured across the resistor.
/// @param[in] LeadV - The V drop measured in a single device lead.
/// @param[in] ExcitationA - The A being generated by the excitation current source.
///
/// @return The resistance measured.
///
//******************************************************
float CInputConditioning::PerformResistanceConvert(const USHORT slotNo, const float ResistorV, const float LeadV,
		const float ExcitationA, const USHORT cardSubType, const USHORT chanType) {
	class CBrdInfo *pBrdInfoObj = NULL;
	float measuredResistance = 0.0F;
	float leadResistance = 0.0F;

	pBrdInfoObj = CBrdInfo::GetHandle();

	if ((AI_CARD_TYPE_V7AI == cardSubType)
			&& ((AI_CHANNEL_TYPE_LINEAR_OHMS == chanType) || (AI_CHANNEL_TYPE_RT == chanType))) {
		leadResistance = 0;
		measuredResistance = ResistorV;
	} else {
		// Calculate the total lead resistance, for both leads
		if (ExcitationA > 0.0F) {
			measuredResistance = ResistorV / ExcitationA;

			if (pBrdInfoObj->WhatBoardType(slotNo) == BOARD_EZ_AI)
				leadResistance = (LeadV / ExcitationA);	///< Voltage drop was for both wires
			else
				leadResistance = (LeadV / ExcitationA) * 2;	///< Mini/multi board voltage drop was only for single lead
		}

		// Prevent lead resistance from going negative
		if (leadResistance < 0.0F) {
			leadResistance = 0.0F;
		}
	}
	// Remove the laed resistance from that measured
	return measuredResistance - leadResistance;
}

//******************************************************
///
/// Calculates the RT temperature from the source current voltage drop across
/// the RT and single RT lead and ohms law.
/// @param[in] slotNo - Card slot number identification.
/// @param[in] chanNo - Card slot channel number identification.
/// @param[in] RTType - The type of RT.
/// @param[in] RTmV - The mV drop measured across the RT device.
/// @param[in] LeadmV - The mV drop measured in a single device lead.
/// @param[in] ExcitationmA - The mA being generated by the excitation current source.
///
/// @return The temperature of the RT in Deg C.
///
//******************************************************
float CInputConditioning::PerformRTConvert(const USHORT slotNo, const USHORT chanNo, const USHORT RTType,
		const float RTmV, const float LeadmV, const float ExcitationmA, const USHORT cardSubType,
		const USHORT chanType) {
	T_PRECPROFILE ptProfile = pSYSTEM_INFO->GetProfileConfig();
	class CInputConditioning *pICService = NULL;	///< Input conditioning service
	class CPPIOServiceManager *pServiceManagerObj = NULL;	///< Service manager
	float RTresistance;
	float RTTemp = 0.0F;

	pServiceManagerObj = CPPIOServiceManager::GetHandle();
	if (NULL != pServiceManagerObj)
		pICService = pServiceManagerObj->GetICService();

	// Calculate the RT resitance
	RTresistance = PerformResistanceConvert(slotNo, RTmV, LeadmV, ExcitationmA, cardSubType, chanType);

	// Look up the corresponding temperature in the RT table
	RTTemp = PerformRTConvert(RTType, RTresistance);

	// Adjust the reading to the sensor compensation values (if required), and the reading is valid
	pICService->PerformOutputAdjust(RTTemp, slotNo, chanNo, &RTTemp);

	///< If the temperature output is not Deg C, then convert
	RTTemp = pSYSTEM_INFO->GetLocalTempFromDegC(RTTemp);

	return RTTemp;
}

//******************************************************
///
/// Initialises the range conversion info structures.
/// Creates the device lookup tables and the working calibration structure
///
/// @return TRUE if initialised OK otherwise FALSE.
///
/// Rev History
/// @Version	@Date			@Author					@Remarks
/// 2.0			28/Mar/2019		Shankar Rao	Pendyala	Compatibility with New AI card (24Bit ADC/Channel Readings) and Old AI Card (16Bit)
/// 3.0			17/Apr/2019		Shankar Rao	Pendyala	RtComp with New AI card (24Bit ADC/Channel Readings) and Old AI Card (16Bit)
/////////////////////////////////////////////////////
//
//******************************************************
BOOL CInputConditioning::RangeInitialise(void) {
	class CAIRanges *pAIBrdRangesObj = NULL;
	//	class CBrdInfo *pBrdInfoObj = NULL;		///< Board info holder
	UCHAR RangeRev = V6AI_ISSUE_1;		//V7AI_ISSUE_A;
	USHORT VoltageRange;
	T_RANGE_COUNTS intern0;
	T_RANGE_COUNTS intern0V;
	T_RANGE_COUNTS intern100;
	float out0;
	float out100;

#if defined ( DBG_FILE_LOG_IO_COND_DBG_ENABLE )
	QString  strLogMessage;
	strLogMessage.asprintf(L"CIPCOND::RangeInitialise - begin RangeRev %d GTC:%d\r\n", RangeRev, GetTickCount() );
	m_debugFileLogger.WriteToDebugLogFile(strLogMessage);
#endif

	pAIBrdRangesObj = CAIRanges::GetHandle();
	//	pBrdInfoObj = CBrdInfo::GetHandle();

	// @todo: If the voltage input range ever change this code will need modifying
	//	pBrdInfoObj->GetBoardRangeRevision( BoardSlotInstance(), &RangeRev );
	// Initialise each base voltage range conversion info structure
	for (USHORT usAICardType = AI_CARD_TYPE_V6AI; usAICardType < AI_CARD_TYPE_MAX; usAICardType++) {
		QString   strAICardType(QString ::fromWCharArray(L"V6AI"));
		//ISSUE and Range Rev is different for V7AI
		if (AI_CARD_TYPE_V7AI == usAICardType) {
			RangeRev = V7AI_ISSUE_A;
			strAICardType = QString ::fromWCharArray(L"V7AI");
		} else {
			RangeRev = V6AI_ISSUE_1;
		}
#if defined ( DBG_FILE_LOG_IO_COND_DBG_ENABLE )
		strLogMessage.asprintf(L"CIPCOND::RangeInitialise - Begin For AICardType %s RangeRev %d GTC:%d\r\n", strAICardType, RangeRev, GetTickCount() );
		m_debugFileLogger.WriteToDebugLogFile(strLogMessage);
#endif

		for (VoltageRange = 0; VoltageRange < BASE_LINEAR_VOLTS_COUNT; VoltageRange++) {
#if defined ( DBG_FILE_LOG_IO_COND_DBG_ENABLE )
			strLogMessage.asprintf(L"CIPCOND::RangeInitialise - for VoltageRange %d GTC:%d\r\n", VoltageRange, GetTickCount() );
			m_debugFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
			if (pAIBrdRangesObj->GetBaseInternValues(VoltageRange, RangeRev, &intern0, &intern0V, &intern100) == TRUE) {
#if defined ( DBG_FILE_LOG_IO_COND_DBG_ENABLE )
				strLogMessage.asprintf(L"CIPCOND::RangeInitialise - GetBaseInternValues : intern0 %d intern0V %d intern100 %d GTC:%d\r\n", intern0, intern0V, intern100, GetTickCount() );
				m_debugFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
				if (pAIBrdRangesObj->GetBaseNominalChannelRange(VoltageRange, RangeRev, &out100, &out0) == TRUE) {
#if defined ( DBG_FILE_LOG_IO_COND_DBG_ENABLE )
					strLogMessage.asprintf(L"CIPCOND::RangeInitialise - GetBaseNominalChannelRanges: out0 %f out100 %f GTC:%d\r\n", out0, out100, GetTickCount() );
					m_debugFileLogger.WriteToDebugLogFile(strLogMessage);
#endif

					BaseVolts[usAICardType][VoltageRange].CalcFConvInfo(static_cast<float>(intern0),
							static_cast<float>(intern100), out0, out100);

#if defined ( DBG_FILE_LOG_IO_COND_DBG_ENABLE )
					strLogMessage.asprintf(L"CIPCOND::RangeInitialise - BaseVolts:::CalcFConvInfo GetDestSpan %f GetSourceSpan %f GTC:%d\r\n", BaseVolts[usAICardType][VoltageRange].GetDestSpan(), BaseVolts[usAICardType][VoltageRange].GetSourceSpan(), GetTickCount() );
					m_debugFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
				}
			}
		}
#if defined ( DBG_FILE_LOG_IO_COND_DBG_ENABLE )
		strLogMessage.asprintf(L"CIPCOND::RangeInitialise - End For AICardType %s RangeRev %d GTC:%d\r\n", strAICardType, RangeRev, GetTickCount() );
		m_debugFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
	}

	// Initialise the RT Comp conversion info structures -- this is dynamic based on card sub type now

#if defined ( DBG_FILE_LOG_IO_COND_DBG_ENABLE )
	strLogMessage.asprintf(L"CIPCOND::RangeInitialise - End GTC:%d\r\n", GetTickCount() );
	m_debugFileLogger.WriteToDebugLogFile(strLogMessage);
#endif

	return TRUE;
}

//******************************************************
///
/// Obtains the base range conversion info for the raw readings.
/// @param[in] BaseRange - The base range number.
///
/// @return The conversion info structure.
///
//******************************************************
class CFFConversionInfo* CInputConditioning::GetBaseRangeConversionInfo(const UCHAR BaseRange, const UCHAR ucBoardRev) {
	if ( V7AI_ISSUE_A <= ucBoardRev) {
		if (BaseRange < BASE_LINEAR_VOLTS_COUNT) {
			return &BaseVolts[AI_CARD_TYPE_V7AI][BaseRange];
		}
	} else {
		if (BaseRange < BASE_LINEAR_VOLTS_COUNT) {
			return &BaseVolts[AI_CARD_TYPE_V6AI][BaseRange];
		}
	}

	return NULL;
}

//******************************************************
///
/// Checks whether there is a valid IO cal persisted and whether that version
/// is up to date with the working copy.
///
/// @return TRUE if persisted version exists, has valid CRC and is the same as the working copy; otherwise FALSE.
///
//******************************************************
BOOL CInputConditioning::QueryIOCalPersistedState(void) const {
	T_PERSISTRECORDERCAL tempCal;
	T_FLASH_STATUS flashStat;
	CFlashManager *pFlash;
	BOOL retValue = FALSE;

	pFlash = CFlashManager::GetHandle();

	flashStat = pFlash->ReadBlock(FLASH_BLK_IOCALS, &tempCal, sizeof(tempCal));
	if (flashStat == FLASH_STATUS_OKAY) {
		if (memcmp(&tempCal, &m_CalPointsToPersist, sizeof(m_CalPointsToPersist)) == 0)
			retValue = TRUE;
	}

	return retValue;
}

//******************************************************
///
/// Checks whether there is a valid IO cal persisted in flash.
///
/// @return TRUE if persisted version exists and has valid CRC; otherwise FALSE.
///
//******************************************************
BOOL CInputConditioning::QueryValidIOCalPersisted(void) const {
	T_PERSISTRECORDERCAL tempCal;
	T_FLASH_STATUS flashStat;
	CFlashManager *pFlash;
	BOOL retValue = FALSE;

	pFlash = CFlashManager::GetHandle();

	flashStat = pFlash->ReadBlock(FLASH_BLK_IOCALS, &tempCal, sizeof(tempCal));
	if (flashStat == FLASH_STATUS_OKAY)
		retValue = TRUE;

	return retValue;
}

//******************************************************
///
/// Checks whether to write default calibration to persisted flash.
///
/// @return TRUE if default requires writting; otherwise FALSE.
///
//******************************************************
BOOL CInputConditioning::QueryDefaultIOCalWriteRqd(void) {
	T_PERSISTRECORDERCAL tempCal;
	T_FLASH_STATUS flashStat;
	CFlashManager *pFlash;
	BOOL retValue = FALSE;

	pFlash = CFlashManager::GetHandle();

	flashStat = pFlash->ReadBlock(FLASH_BLK_IOCALS, &tempCal, sizeof(tempCal));
	if ((flashStat == FLASH_STATUS_FIRSTUSE) || (flashStat == FLASH_STATUS_CRCFAIL))
		retValue = TRUE;

	return retValue;
}

//******************************************************
///
/// Creates the default persistant I/O calibration structure.
/// @param[in] chan3CJ - TRUE if CJ is next to board channel 3.
///						FALSE if CJ is next to board channel 4.
///
/// @return TRUE if created OK; otherwise FALSE.
///
/// @return TRUE if error present.
/// Rev History
/// @Version	@Date			@Author					@Remarks
/// 2.0			23/Apr/2019		Shankar Rao	Pendyala	CJC offsets w.r.t V7AI
/////////////////////////////////////////////////////
//******************************************************
BOOL CInputConditioning::CreateDefaultIOCal(const BOOL chan3CJ) {
	USHORT cardNo = 0;
	USHORT chanNo = 0;
	USHORT rangeNo = 0;
	BOOL retValue = TRUE;

	m_RTwrkCurrent.highRTideal = TRUE;
	m_RTwrkCurrent.lowRTideal = TRUE;
	m_RTwrkCurrent.highRTCurrent = DEFAULT_CONSTANT_CURRENT_HIGH_MA;
	m_RTwrkCurrent.lowRTCurrent = DEFAULT_CONSTANT_CURRENT_LOW_MA;

	memset(&m_CalPointsToPersist, 0, sizeof(m_CalPointsToPersist));
	memset(&m_WrkCalPoints, 0, sizeof(m_WrkCalPoints));

	//Get the board info object to get board revision and board subtypes
	class CBrdInfo *pBrdInfoObj = NULL;
	pBrdInfoObj = CBrdInfo::GetHandle();

	// Load the 'factory' CJC channel calibration offsets
	for (cardNo = 0; cardNo < RECORDERCAL_RECORDERCALS_SIZE; cardNo++) {
		//Get the Board revision and Board Sub Type to apply CJC offsets accordingly
		UCHAR ucBoardRev = V6AI_ISSUE_1;
		pBrdInfoObj->GetBoardHardwareRevision(cardNo, &ucBoardRev);
		UCHAR ucAICardSubType = CAICard::WhatBoardSubType(ucBoardRev);

		// Update the range numbers for the AI board
		for (rangeNo = 0; rangeNo < BOARDCALS_RANGECALS_SIZE; rangeNo++) {
			// Update the range number
			m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].RangeCals[rangeNo].RangeType = rangeNo;
			// Set all channel ranges to default to factory calibration
			for (chanNo = 0; chanNo < BOARDCALS_CHANCALS_SIZE; chanNo++)
				m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].RangeCals[rangeNo].Channel[chanNo] =
						V6_IO_FACTORY_CALIBRATION;
		}

		// Load each channels factory CJ cal
		for (chanNo = 0; chanNo < BOARDCALS_CHANCALS_SIZE; chanNo++) {
			// Default to using factory calibration on all I/O cards
			m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].PointCals.CalType =
					V6_IO_FACTORY_CALIBRATION;
			m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].CJCCals.EnableUser =
			TRUE;
			m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].CJCCals.UserCal = 0.0F;

			if (AI_CARD_TYPE_V7AI == ucAICardSubType) {
				// Default the factory CJ 'calibration' offsets
				m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].CJCCals.FactCal =
						GetV7AICJCCalValue(cardNo, chanNo);
			} else {
				// Default the factory CJ 'calibration' offsets
				m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].CJCCals.FactCal =
						GetV6AICJCCalValue(cardNo, chanNo, chan3CJ);
			}
		}
	}

	return retValue;
}
//******************************************************
///
/// Gets the factory CJC cal offset for the specified V7 AI card channel nuumber
///
/// @return The factory cal offset
///
//******************************************************
const float CInputConditioning::GetV7AICJCCalValue(const USHORT slotNo, const USHORT chanNo) {
	float calValue = 0.0F;	//Coverity// CID: 1992663
	switch (chanNo) {
	case IO_CARD_CHANNEL_1:
		calValue = V7AI_CH1_CJC_DEG_OFFSET;
		break;
	case IO_CARD_CHANNEL_2:
		calValue = V7AI_CH2_CJC_DEG_OFFSET;
		break;
	case IO_CARD_CHANNEL_3:
		calValue = V7AI_CH3_CJC_DEG_OFFSET;
		break;
	case IO_CARD_CHANNEL_4:
		calValue = V7AI_CH4_CJC_DEG_OFFSET;
		break;
	case IO_CARD_CHANNEL_5:
		calValue = V7AI_CH5_CJC_DEG_OFFSET;
		break;
	case IO_CARD_CHANNEL_6:
		calValue = V7AI_CH6_CJC_DEG_OFFSET;
		break;
	case IO_CARD_CHANNEL_7:
		calValue = V7AI_CH7_CJC_DEG_OFFSET;
		break;
	case IO_CARD_CHANNEL_8:
		calValue = V7AI_CH8_CJC_DEG_OFFSET;
		break;
	}
	return calValue;
}

//******************************************************
///
/// Gets the factory CJC cal offset for the specified V6 AI card channel nuumber
///
/// @return The factory cal offset
///
//******************************************************
const float CInputConditioning::GetV6AICJCCalValue(const USHORT slotNo, const USHORT chanNo, BOOL chan3CJ) {
	float calValue = 0.0F;	//Coverity// CID: 1992654
	// Default the factory CJ 'calibration' offsets
	switch (chanNo) {
	case IO_CARD_CHANNEL_1:
		if ( TRUE == chan3CJ) {
			calValue = CH2_CJC_DEG_OFFSET;
		} else {
			calValue = CH1_CJC_DEG_OFFSET;
		}
		break;
	case IO_CARD_CHANNEL_2:
		if ( TRUE == chan3CJ) {
			calValue = CH3_CJC_DEG_OFFSET;
		} else {
			calValue = CH2_CJC_DEG_OFFSET;
		}
		break;
	case IO_CARD_CHANNEL_3:
		if ( TRUE == chan3CJ) {
			calValue = CH4_CJC_DEG_OFFSET;
		} else {
			calValue = CH3_CJC_DEG_OFFSET;
		}
		break;
	case IO_CARD_CHANNEL_4:
		if ( TRUE == chan3CJ) {
			calValue = CH5_CJC_DEG_OFFSET;
		} else {
			calValue = CH4_CJC_DEG_OFFSET;
		}
		break;
	case IO_CARD_CHANNEL_5:
		if ( TRUE == chan3CJ) {
			calValue = CH6_CJC_DEG_OFFSET;
		} else {
			calValue = CH5_CJC_DEG_OFFSET;
		}
		break;
	case IO_CARD_CHANNEL_6:
		if ( TRUE == chan3CJ) {
			calValue = CH7_CJC_DEG_OFFSET;
		} else {
			calValue = CH6_CJC_DEG_OFFSET;
		}
		break;
	case IO_CARD_CHANNEL_7:
		calValue = CH7_CJC_DEG_OFFSET;
		break;
	case IO_CARD_CHANNEL_8:
		calValue = CH8_CJC_DEG_OFFSET;
		break;
	}

	return calValue;
}

//******************************************************
///
/// Loads the working I/O calibration structure from flash.
///
/// @return TRUE if loaded OK; otherwise FALSE.
///
//******************************************************
BOOL CInputConditioning::IOCalLoad(void) {
	T_FLASH_STATUS flashStat;
	CFlashManager *pFlash;
	BOOL retValue = FALSE;

	pFlash = CFlashManager::GetHandle();

	flashStat = pFlash->ReadBlock(FLASH_BLK_IOCALS, &m_CalPointsToPersist, sizeof(m_CalPointsToPersist));
	if (flashStat == FLASH_STATUS_OKAY)
		retValue = TRUE;

	return retValue;
}

//******************************************************
///
/// Copies the recorder calibration to the CMM (not for export to another recorder).
///
/// @return TRUE if copied and peristed OK; otherwise FALSE.
///
//******************************************************
BOOL CInputConditioning::RecorderCalCMMDump(void) {
	class CIOSetupConfig *pIOModSetupConfig = NULL;
	T_PRECORDERCAL pCMMRecorderCal = NULL;
	T_RECORDERCAL *pNV = NULL;
	USHORT slotNo = 0;
	USHORT rangeNo = 0;
	USHORT chanNo = 0;
	BOOL retValue = TRUE;

	pIOModSetupConfig = pSETUP->GetIOSetupConfig();
	if (pIOModSetupConfig != NULL) {
		pCMMRecorderCal = pIOModSetupConfig->GetTopSlotRecorderCalInfo(CONFIG_MODIFIABLE);
		pNV = GetInputConditioningSelect();

		if ((pCMMRecorderCal != NULL) && (pNV != NULL)) {
			// Save the NV (copy) to the modifiable CMM - this will be comitted later
			memcpy(pCMMRecorderCal, pNV, sizeof(T_RECORDERCAL));	// Copy NV copy of all I/O boards to modifiable CMM
			retValue = TRUE;
		}
	}

	return retValue;
}

//******************************************************
///
/// Copies the recorder calibration from the CMM to NV.
///
/// @return TRUE if copied and peristed OK; otherwise FALSE.
///
//******************************************************
BOOL CInputConditioning::RecorderCalCMMReload(void) {
	class CIOSetupConfig *pIOModSetupConfig = NULL;
	T_PRECORDERCAL pCMMRecorderCal = NULL;
	T_RECORDERCAL *pNV = NULL;
	USHORT slotNo = 0;
	USHORT rangeNo = 0;
	USHORT chanNo = 0;
	BOOL retValue = TRUE;

	pIOModSetupConfig = pSETUP->GetIOSetupConfig();
	if (pIOModSetupConfig != NULL) {
		pCMMRecorderCal = pIOModSetupConfig->GetTopSlotRecorderCalInfo(CONFIG_MODIFIABLE);
		pNV = GetInputConditioningSelect();

		if ((pCMMRecorderCal != NULL) && (pNV != NULL)) {
			// Reload the NV (copy) from the modifiable CMM - this will be comitted later
			memcpy(pNV, pCMMRecorderCal, sizeof(T_RECORDERCAL));
			retValue = TRUE;
		}
	}

	return retValue;
}

//******************************************************
///
/// Saves the working I/O calibration structure to flash.
///
/// @return TRUE if saved OK; otherwise FALSE.
///
//******************************************************
BOOL CInputConditioning::IOCalSave(void) {
	T_FLASH_STATUS flashStat;
	CFlashManager *pFlash;
	BOOL retValue = FALSE;

	pFlash = CFlashManager::GetHandle();

	flashStat = pFlash->WriteBlock(FLASH_BLK_IOCALS, &m_CalPointsToPersist, sizeof(m_CalPointsToPersist));
	if (flashStat == FLASH_STATUS_OKAY)
		retValue = TRUE;

	return retValue;
}

//******************************************************
///
/// Limit the I/O calibration structure to legal values.
/// Check and remove from calibration structure any 'illegal' user & calibration selections
/// these should never be persisted, but is so we need to remove them before loading configuration to the I/O board(s)
///
/// @return TRUE if no problems were detected otherwise FALSE.
///
//******************************************************
BOOL CInputConditioning::ResetIllegalNVToFactoryCal(void) {
	USHORT slotNo = 0;
	USHORT rangeNo = 0;
	USHORT chanNo = 0;
	T_RECORDERCAL *pNV = NULL;
	BOOL retValue = TRUE;

	pNV = GetInputConditioningSelect();
	if (pNV != NULL) {
		for (slotNo = 0; slotNo < RECORDERCAL_RECORDERCALS_SIZE; slotNo++) {
			for (chanNo = 0; chanNo < IORANGECAL_CHANNEL_SIZE; chanNo++) {
				for (rangeNo = 0; rangeNo < BOARDCALS_RANGECALS_SIZE; rangeNo++) {
					// Check the range calibration selection
					if (pNV->RecorderCals[slotNo].RangeCals[rangeNo].Channel[chanNo]
							== CInputConditioning::V6_IO_USER_AND_RECALIBRATE) {
						// Revert to factory - only safe option
						pNV->RecorderCals[slotNo].RangeCals[rangeNo].Channel[chanNo] =
								CInputConditioning::V6_IO_FACTORY_CALIBRATION;
						retValue = FALSE;
					}
				}
			}
		}
	} else
		retValue = FALSE;

	return retValue;
}

//******************************************************
///
/// Save the calibration status to NV
/// @param[in] slotNo - Card slot number (0 based).
/// @param[in] chanNo - Channel number on card slot (zero based).
/// @param[in] rangeNo - Range number being calibrated.
/// @param[in] state - The new calibration state to be saved.
///
/// @return TRUE if no problems were detected otherwise FALSE.
///
//******************************************************
BOOL CInputConditioning::SaveUserCalStatToNV(const USHORT slotNo, const USHORT chanNo, const USHORT rangeNo,
		const CInputConditioning::IO_CAL_OPTIONS state) {
	T_RECORDERCAL *pNV = NULL;
	BOOL retValue = TRUE;

	pNV = GetInputConditioningSelect();
	if (pNV != NULL) {
		// Uploaded user calibration data to AI board so start using
		pNV->RecorderCals[slotNo].RangeCals[rangeNo].Channel[chanNo] = state;

		// make sure we have the NV data saved
		IOCalSave();
	} else
		retValue = FALSE;

	return retValue;
}

//******************************************************
///
/// Limit the processed I/O calibration structure to legal values.
/// Check and remove from calibration structure any 'illegal' user & calibration selections
/// these should never be persisted, but is so we need to remove them before loading configuration to the I/O board(s)
///
/// @return TRUE if no problems were detected otherwise FALSE.
///
//******************************************************
BOOL CInputConditioning::ResetProcessedNVToUserCalSet(void) {
	USHORT slotNo = 0;
	USHORT rangeNo = 0;
	USHORT chanNo = 0;
	T_RECORDERCAL *pNV = NULL;
	BOOL retValue = TRUE;

	pNV = GetInputConditioningSelect();
	if (pNV != NULL) {
		for (slotNo = 0; slotNo < RECORDERCAL_RECORDERCALS_SIZE; slotNo++) {
			for (chanNo = 0; chanNo < IORANGECAL_CHANNEL_SIZE; chanNo++) {
				for (rangeNo = 0; rangeNo < BOARDCALS_RANGECALS_SIZE; rangeNo++) {
					// Check the range calibration selection
					if (pNV->RecorderCals[slotNo].RangeCals[rangeNo].Channel[chanNo]
							== CInputConditioning::V6_IO_USER_AND_RECALIBRATE) {
						// Uploaded user calibration data to AI board so start using
						pNV->RecorderCals[slotNo].RangeCals[rangeNo].Channel[chanNo] =
								CInputConditioning::V6_IO_USER_CALIBRATION;
					}
				}
			}
		}
	} else
		retValue = FALSE;

	return retValue;
}

//******************************************************
///
/// Re-initialises the IO conditioner.
/// Creates the device lookup tables and the working calibration structure
///
/// @return TRUE if initialised OK otherwise FALSE.
///
//******************************************************
BOOL CInputConditioning::IOConditionerCommit(void) {
	BOOL retValue = TRUE;

	// Initialise the lineraisation tables
	retValue = m_DevManager.InitialiseLinerisationTableManager();

	return retValue;
}

//******************************************************
///
/// Initialises the IO conditioner.
/// Creates the device lookup tables and the working calibration structure
///
/// @return TRUE if initialised OK otherwise FALSE.
///
//******************************************************
BOOL CInputConditioning::IOConditionerInitialise(void) {
#if defined ( DBG_FILE_LOG_IO_COND_DBG_ENABLE )
	QString  strLogMessage;
	strLogMessage.asprintf(L"CIPCOND::Initialize - begin GTC:%d\r\n", GetTickCount() );
	m_debugFileLogger.WriteToDebugLogFile(strLogMessage);
#endif

	class CIOSetupConfig *pIOModSetupConfig = NULL;
	T_PRECORDERCAL pRecorderCal = NULL;
	T_RECORDERCAL *pNV = NULL;
	BOOL retValue = TRUE;

	// Initialise the lineraisation tables
	retValue = m_DevManager.InitialiseLinerisationTableManager();

	// Initialise the conversion info structures
	if (RangeInitialise() == FALSE)
		retValue = FALSE;

	if ((retValue == TRUE) && (IsRunningAsATEEquipment() == FALSE)) {
		// Check whether a first time write of the calibration structure is required
		if (QueryDefaultIOCalWriteRqd() == FALSE) {
			retValue = IOCalLoad();			///< Load the IO cal from NV
		}

		if ((QueryDefaultIOCalWriteRqd() == TRUE) || (pSYSTEM_INFO->IsFactoryResetRequested() == TRUE)
				|| (retValue == FALSE)) {
			// If a default write is required or the load failed then create the default
			LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_INFO, ("All recorder cals require defaulting"));
			// First time write of the calibration structure is required
			retValue = CreateDefaultIOCal( FALSE);
			if ( TRUE == retValue) {
				retValue = IOCalSave();		///< Save the IO cal to NV

				if (retValue == TRUE)
					retValue = RecorderCalCMMDump();
			}

			if (retValue == TRUE)
				LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_INFO, ("Recorder calibrations defaulted"));
		}
	}

	// Initialise the working channel cals from the saved (or newly defaulted)
	if ( TRUE == retValue)
		retValue = IOBoardCalWrkCommit();

#if defined ( DBG_FILE_LOG_IO_COND_DBG_ENABLE )
	strLogMessage.asprintf(L"CIPCOND::Initialize - End RetValue %d GTC:%d\r\n", retValue, GetTickCount() );
	m_debugFileLogger.WriteToDebugLogFile(strLogMessage);
#endif

	return retValue;
}

//******************************************************
///
/// Commits the I/O board range cal points (if required).
/// @param[in] cardNo - The card slot number.
/// @param[in] chanNo - The card channel number.
/// @param[in] zeroEng - The Pen zero engineering point.
/// @param[in] spanEng - The Pen span engineering point.
///
/// @return TRUE if dual point range cal need to be comitted and are comitted OK otherwise FALSE.
///
//******************************************************
BOOL CInputConditioning::IOBoardRangeCalCommit(const USHORT cardNo, const USHORT chanNo, const float zeroEng,
		const float spanEng) {
	BOOL retValue = FALSE;

	// Check whether full range is being used, if it is then the engineering values must used
	if ((V6_DUAL_POINT_CAL == m_WrkCalPoints.RecorderCals[cardNo].WrkBoardCals.PointCals[chanNo].WrkCalType)
			&& (V6_DUAL_POINT_CAL_WHOLE_RANGE
					== m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].PointCals.DualRangeExtend)) {
		// If dual point calibration over range is selected then use the engineering values comitted
		m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].PointCals.DPCal1 = zeroEng;
		m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].PointCals.DPCal2 = spanEng;
		retValue = TRUE;
	}

	return retValue;
}

//******************************************************
///
/// Commits the persisted I/O board calibration to the working table.
///
/// @note Points are stored in deg C not localised units when RT's & TC's are selected
/// @return TRUE if comitted OK otherwise FALSE.
///
/// Rev History
/// @Version	@Date			@Author					@Remarks
/// 2.0			23/Apr/2019		Shankar Rao	Pendyala	CJC offsets w.r.t V7AI
/////////////////////////////////////////////////////
//******************************************************
BOOL CInputConditioning::IOBoardCalWrkCommit(void) {
	class CIOSetupConfig *pIOSetupConfig = NULL;
	class CSlotMap *pSlotMap = NULL;
	class CAIConfig *pAIConfig = NULL;
	class CBrdInfo *pBrdInfo = NULL;
	USHORT cardType;
	USHORT chanType;
	USHORT cardNo;
	USHORT chanNo;
	USHORT sysChanNo;
	QString   strasprintf;
	float DPCal1 = 0.0;
	float DPCal2 = 0.0;
	float DPCal1Adj = 0.0;
	float DPCal2Adj = 0.0;
	BOOL retValue = TRUE;

	pSlotMap = CSlotMap::GetHandle();
	pBrdInfo = CBrdInfo::GetHandle();

	// Get pointer to the Multi point Cal Configuration block
	m_pMultiPointConfig = pSETUP->GetIOSetupConfig()->GetMultiPointBlock(CONFIG_COMMITTED);

	// Initialise the working channel cals from the saved (or newly defaulted)
	for (cardNo = 0; cardNo < RECORDERCAL_RECORDERCALS_SIZE; cardNo++) {
		cardType = DEVICE_INFO.GetSlotType(cardNo);
		if ((BOARD_AI == cardType) || (BOARD_EZ_AI == cardType)) {
			pIOSetupConfig = pSETUP->GetIOSetupConfig();
		}
		//Get the Board revision and Board Sub Type to apply CJC offsets accordingly
		UCHAR ucBoardRev = V6AI_ISSUE_1;
		pBrdInfo->GetBoardHardwareRevision(cardNo, &ucBoardRev);
		UCHAR ucAICardSubType = CAICard::WhatBoardSubType(ucBoardRev);

		for (chanNo = 0; chanNo < BOARDCALS_CHANCALS_SIZE; chanNo++) {
			sysChanNo = pSlotMap->GetSysChannelFromAnaInChannel(cardNo, chanNo, ONE_BASED);
			m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].CJCCals.EnableUser =
			TRUE;

			//Apply CJC fact calib to their required values - this will cover V6 and V7 AI cards being swapped around in the same slot
			//@Todo: reverrt these chnages once calib is implemented
			if (AI_CARD_TYPE_V7AI == ucAICardSubType) {
				m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].CJCCals.FactCal =
						GetV7AICJCCalValue(cardNo, chanNo);
			} else {
				m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].CJCCals.FactCal =
						GetV6AICJCCalValue(cardNo, chanNo, FALSE);
			}

			if (((BOARD_AI == cardType) || (BOARD_EZ_AI == cardType))
					&& (pIOSetupConfig->QueryAIChannelSelection(CONFIG_MODIFIABLE, sysChanNo, &chanType) == CONFIG_OK)) {
				DPCal1 = m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].PointCals.DPCal1;
				DPCal2 = m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].PointCals.DPCal2;
				DPCal1Adj = m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].PointCals.DPCal1Adj;
				DPCal2Adj = m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].PointCals.DPCal2Adj;
			}

			m_WrkCalPoints.RecorderCals[cardNo].WrkBoardCals.PointCals[chanNo].WrkCalType =
					m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].PointCals.CalType;

			if (m_WrkCalPoints.RecorderCals[cardNo].WrkBoardCals.PointCals[chanNo].WrkCalType == V6_DUAL_POINT_CAL) {
				m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].PointCals.DualRangeExtend =
				V6_DUAL_POINT_CAL_BETWEEN_POINTS;

				// Warn if the dual point calibrations are specified at the same point
				if (m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].PointCals.DPCal1
						== m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].PointCals.DPCal2) {
					if (IsRunningAsATEEquipment() == FALSE) {
						strasprintf.asprintf(IDS_DIAG_DUAL_POINT_COMP_FAIL, sysChanNo);
						AddErrorToReport(static_cast<LPCTSTR>(strasprintf));
					}
					m_WrkCalPoints.RecorderCals[cardNo].WrkBoardCals.PointCals[chanNo].DPouputSlope = 1.0F;
					m_WrkCalPoints.RecorderCals[cardNo].WrkBoardCals.PointCals[chanNo].DPlowerAdjPoint = DPCal1Adj;
				} else {
					// Check which point is higher
					if (m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].PointCals.DPCal1
							> m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].PointCals.DPCal2) {
						// Cal point 1 is higher than cal point 2
						m_WrkCalPoints.RecorderCals[cardNo].WrkBoardCals.PointCals[chanNo].DPlowerCalPoint = DPCal2;
						m_WrkCalPoints.RecorderCals[cardNo].WrkBoardCals.PointCals[chanNo].DPupperCalPoint = DPCal1;
						m_WrkCalPoints.RecorderCals[cardNo].WrkBoardCals.PointCals[chanNo].DPlowerAdjPoint = DPCal2Adj;
						m_WrkCalPoints.RecorderCals[cardNo].WrkBoardCals.PointCals[chanNo].DPupperAdjPoint = DPCal1Adj;
						m_WrkCalPoints.RecorderCals[cardNo].WrkBoardCals.PointCals[chanNo].DPoutputOffset = DPCal2Adj;

					} else if (m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].PointCals.DPCal1
							< m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].PointCals.DPCal2) {
						// Cal point 1 is lower than cal point 2
						m_WrkCalPoints.RecorderCals[cardNo].WrkBoardCals.PointCals[chanNo].DPupperCalPoint = DPCal2;
						m_WrkCalPoints.RecorderCals[cardNo].WrkBoardCals.PointCals[chanNo].DPlowerCalPoint = DPCal1;
						m_WrkCalPoints.RecorderCals[cardNo].WrkBoardCals.PointCals[chanNo].DPupperAdjPoint = DPCal2Adj;
						m_WrkCalPoints.RecorderCals[cardNo].WrkBoardCals.PointCals[chanNo].DPlowerAdjPoint = DPCal1Adj;
						m_WrkCalPoints.RecorderCals[cardNo].WrkBoardCals.PointCals[chanNo].DPoutputOffset = DPCal1Adj;
					}

					// Calculate the slope for the sensor
					m_WrkCalPoints.RecorderCals[cardNo].WrkBoardCals.PointCals[chanNo].DPouputSlope =
							((m_WrkCalPoints.RecorderCals[cardNo].WrkBoardCals.PointCals[chanNo].DPupperCalPoint
									+ m_WrkCalPoints.RecorderCals[cardNo].WrkBoardCals.PointCals[chanNo].DPupperAdjPoint)
									- (m_WrkCalPoints.RecorderCals[cardNo].WrkBoardCals.PointCals[chanNo].DPlowerCalPoint
											+ m_WrkCalPoints.RecorderCals[cardNo].WrkBoardCals.PointCals[chanNo].DPlowerAdjPoint))
									/ (m_WrkCalPoints.RecorderCals[cardNo].WrkBoardCals.PointCals[chanNo].DPupperCalPoint
											- m_WrkCalPoints.RecorderCals[cardNo].WrkBoardCals.PointCals[chanNo].DPlowerCalPoint);
				}
			}

			m_WrkCalPoints.RecorderCals[cardNo].WrkBoardCals.PointCals[chanNo].MPTable.FreeTables();

			if (m_WrkCalPoints.RecorderCals[cardNo].WrkBoardCals.PointCals[chanNo].WrkCalType == V6_MULTI_POINT_CAL) {
				int sysChanNoZeroBased = sysChanNo - 1;
				T_IP_TABLE_ELEMENT destTable[V6_MULTI_POINT_SIZE];

				if (m_pMultiPointConfig->Channel[sysChanNoZeroBased].CalElements > V6_MULTI_POINT_SIZE) {
					m_pMultiPointConfig->Channel[sysChanNoZeroBased].CalElements = V6_MULTI_POINT_SIZE;
				}

				for (int tabElement = 0; tabElement < m_pMultiPointConfig->Channel[sysChanNoZeroBased].CalElements;
						tabElement++) {
					destTable[tabElement].in =
							m_pMultiPointConfig->Channel[sysChanNoZeroBased].CalPoints[tabElement].CalPoint;
					destTable[tabElement].out =
							m_pMultiPointConfig->Channel[sysChanNoZeroBased].CalPoints[tabElement].CalPoint
									+ m_pMultiPointConfig->Channel[sysChanNoZeroBased].CalPoints[tabElement].Offset;
				}

				T_TABLE_RETURN tabResult =
						m_WrkCalPoints.RecorderCals[cardNo].WrkBoardCals.PointCals[chanNo].MPTable.GenerateTable(
								destTable, m_pMultiPointConfig->Channel[sysChanNoZeroBased].CalElements,
								V6_MP_MAX_ELEMENTS, NORMAL_TABLE);

				if (tabResult != TABLE_OK) {
					// Error found, log the diagnostic error and disable the lookup table
					QString   diagMessage;
					diagMessage.asprintf(IDS_TUS_MGR_GEN_CAL_TABLE_ERROR, sysChanNo, tabResult);
					LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_ERROR, diagMessage);
				}
			}
		}
	}

	return retValue;
}

//******************************************************
///
/// Queries what type of calibration adjust is selected for an output value.
/// @param[in] cardNo - The card slot position (1-6) only.
/// @param[in] chanNo - The channel number.
///
/// @return Status of comitted calibration
///
//******************************************************
USHORT CInputConditioning::QuerySensorCompMethod(const USHORT cardNo, const USHORT chanNo) {
	return m_WrkCalPoints.RecorderCals[cardNo].WrkBoardCals.PointCals[chanNo].WrkCalType;
}

//******************************************************
///
/// Provides a single, dual point or multipoint calibration adjust on an output value.
/// @param[in] EngValue - The origianl value to adjust.
/// @param[in] cardNo - The card slot position (1-6) only.
/// @param[in] chanNo - The channel number.
/// @param[out] pCaledValue - The calibrated value.
///
/// @return Status of calibration ; TRUE if OK otherwise FALSE if outside of dual point calibration points.
///
//******************************************************
BOOL CInputConditioning::PerformOutputAdjust(const float EngValue, const USHORT cardNo, const USHORT chanNo,
		float *pCaledValue) {
	BOOL retValue = TRUE;

	*pCaledValue = EngValue;
	//PSR - Coverity issue fix --#779818 #779507
	if (cardNo < RECORDERCAL_RECORDERCALS_SIZE) {

		switch (m_WrkCalPoints.RecorderCals[cardNo].WrkBoardCals.PointCals[chanNo].WrkCalType) {
		case V6_SINGLE_POINT_CAL: {
			// Single point calibration
			*pCaledValue = EngValue
					+ m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].PointCals.SingleCal;
			break;
		}
		case V6_DUAL_POINT_CAL: {
			// Dual Point Calibration
			if (m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].PointCals.DPCal1
					== m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].PointCals.DPCal2) {
				// The two cal points the same and has been warned about on a commit;
				// now treat as a single cal point
				*pCaledValue = EngValue
						+ m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].PointCals.DPCal1Adj;
			} else {
				// It's a dual point calibration, so perform calibration
				*pCaledValue = ((EngValue
						- m_WrkCalPoints.RecorderCals[cardNo].WrkBoardCals.PointCals[chanNo].DPlowerCalPoint)
						* m_WrkCalPoints.RecorderCals[cardNo].WrkBoardCals.PointCals[chanNo].DPouputSlope)
						+ m_WrkCalPoints.RecorderCals[cardNo].WrkBoardCals.PointCals[chanNo].DPlowerCalPoint
						+ m_WrkCalPoints.RecorderCals[cardNo].WrkBoardCals.PointCals[chanNo].DPlowerAdjPoint;
			}
			break;
		}
		case V6_MULTI_POINT_CAL: {
			// Multi Point Calibration, perform lookup of table
			*pCaledValue = m_WrkCalPoints.RecorderCals[cardNo].WrkBoardCals.PointCals[chanNo].MPTable.LookUpValue(
					EngValue);
			break;
		}
		}
	}

	return retValue;
}

//******************************************************
///
/// Provides a reverse adjustment on single, dual point or multipoint calibration output value.
///
/// @param[in] conditionedReading - The conditioned reading to return back to it's uncalibrated value
/// @param[in] cardNo - The card slot position (1-6) only.
/// @param[in] chanNo - The channel number.
///
/// @return Status of calibration ; TRUE if OK otherwise FALSE if outside of dual point calibration points.
///
//******************************************************
float CInputConditioning::ReverseOutputAdjust(const float conditionedReading, const USHORT cardNo,
		const USHORT chanNo) {
	float preCalValue = conditionedReading;

	//PSR - Coverity issue fix --#779818 #779507
	if (cardNo < RECORDERCAL_RECORDERCALS_SIZE) {

		switch (m_WrkCalPoints.RecorderCals[cardNo].WrkBoardCals.PointCals[chanNo].WrkCalType) {
		case V6_SINGLE_POINT_CAL: {
			// Single point calibration to be reversed
			preCalValue = conditionedReading
					- m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].PointCals.SingleCal;
			break;
		}
		case V6_DUAL_POINT_CAL: {
			// Dual Point Calibration
			if (m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].PointCals.DPCal1
					== m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].PointCals.DPCal2) {
				// The two cal points the same and has been warned about on a commit;
				// now treat as a single cal point calibration to be reversed
				preCalValue = conditionedReading
						- m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].PointCals.DPCal1Adj;
			} else {
				// It's a dual point calibration, so reverse the full calibration
				preCalValue = conditionedReading
						- m_WrkCalPoints.RecorderCals[cardNo].WrkBoardCals.PointCals[chanNo].DPlowerAdjPoint;
				preCalValue -= m_WrkCalPoints.RecorderCals[cardNo].WrkBoardCals.PointCals[chanNo].DPlowerCalPoint;
				preCalValue /= m_WrkCalPoints.RecorderCals[cardNo].WrkBoardCals.PointCals[chanNo].DPouputSlope;
				preCalValue += m_WrkCalPoints.RecorderCals[cardNo].WrkBoardCals.PointCals[chanNo].DPlowerCalPoint;
			}
			break;
		}
		case V6_MULTI_POINT_CAL: {
			// Multi Point Calibration, perform lookup of table
			preCalValue = m_WrkCalPoints.RecorderCals[cardNo].WrkBoardCals.PointCals[chanNo].MPTable.ReverseLookUpValue(
					conditionedReading);
			break;
		}
		default:
			// presumably the cal is set to none so let pass the original value through
			break;
		}
	}

	return preCalValue;
}

//******************************************************
///
/// Reset both the single and dual point calibration adjust on an output value.
/// @param[in] cardNo - The card slot position (1-6) only.
/// @param[in] chanNo - The channel number.
///
/// @return Status of calibration reset; TRUE if OK otherwise FALSE.
///
//******************************************************
BOOL CInputConditioning::ResetOutputAdjustCal(const USHORT cardNo, const USHORT chanNo) {
	BOOL retValue = FALSE;

	if (cardNo < RECORDERCAL_RECORDERCALS_SIZE) {
		// Reset the working calibration structure
		m_WrkCalPoints.RecorderCals[cardNo].WrkBoardCals.PointCals[chanNo].WrkCalType = V6_NO_OUTPUT_CAL;
		m_WrkCalPoints.RecorderCals[cardNo].WrkBoardCals.PointCals[chanNo].DPlowerCalPoint = 0;
		m_WrkCalPoints.RecorderCals[cardNo].WrkBoardCals.PointCals[chanNo].DPouputSlope = 0;
		m_WrkCalPoints.RecorderCals[cardNo].WrkBoardCals.PointCals[chanNo].DPoutputOffset = 0;

		// Reset the single point calibration
		m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].PointCals.SingleCal = 0;

		// Reset the dual point calibration
		//		m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].PointCals.DualRangeExtend = V6_DUAL_POINT_CAL_WHOLE_RANGE;
		m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].PointCals.DualRangeExtend =
		V6_DUAL_POINT_CAL_BETWEEN_POINTS;

		m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].PointCals.DPCal1 = 0;
		m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].PointCals.DPCal2 = 0;
		m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].PointCals.DPCal1Adj = 0;
		m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].PointCals.DPCal2Adj = 0;

		retValue = TRUE;
	}

	return retValue;
}

//******************************************************
///
/// Provides CJ value adjust.
/// @param[in] EngValue - The origianl value to adjust.
/// @param[in] cardNo - The card slot position (topslots 0-5) only.
/// @param[in] chanNo - The channel number.
///
/// @return The calibrated value.
///
//******************************************************
float CInputConditioning::PerformCJAdjust(const float EngValue, const USHORT cardNo, const USHORT chanNo) {
	float caledValue = 0.0F;

	if (cardNo < RECORDERCAL_RECORDERCALS_SIZE) {
		if (m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].CJCCals.EnableUser == TRUE) {
			// Always adjust CJC for factory channel calibration, and add the optional user calibration
			caledValue = EngValue + m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].CJCOffset
					+ m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].CJCCals.FactCal
					+ m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].CJCCals.UserCal;
		} else {
			// Always adjust CJC for factory channel calibration
			caledValue = EngValue + m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].CJCOffset
					+ m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].CJCCals.FactCal;
		}
	}

#if defined ( DBG_FILE_LOG_IO_COND_DBG_ENABLE )
	QString  strLogMessage;
	strLogMessage.asprintf(L"CIPCOND::PerformCJAdjust - Slot %d ChanNo %d EngValue %f CJCOffset %f FactCal %f UserCal %f caledValue %f GTC:%d\r\n", cardNo, chanNo,
						EngValue,
						m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].CJCOffset,
						m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].CJCCals.FactCal,
						m_CalPointsToPersist.CalPoints.RecorderCals[cardNo].ChanCals[chanNo].CJCCals.UserCal,
						caledValue, GetTickCount() );
	m_debugFileLogger.WriteToDebugLogFile(strLogMessage);
#endif

	return caledValue;
}

//******************************************************
///
/// Calculates the resistance from the source current and voltage drop across
/// the resistor and ohms law (2 wire measurement).
/// @param[in] slotNo - Card slot number identification.
/// @param[in] ResitormV - The mV drop measured across the resistor.
/// @param[in] ExcitationmA - The mA being generated by the excitation current source.
///
/// @return The resistance measured.
///
//******************************************************
float CInputConditioning::PerformResistanceConvert(const USHORT slotNo, const float ResitormV, const float ExcitationmA,
		const USHORT cardSubType, const USHORT chanType) {
	return PerformResistanceConvert(slotNo, ResitormV, 0.0, ExcitationmA, cardSubType, chanType);
}

//******************************************************
///
/// Calculates the RT temperature from the RT resistance measured.
/// @param[in] RTType - The type of RT.
/// @param[in] RTohms - The RT resistance.
///
/// @return The temperature of the RT in Deg C.
///
//******************************************************
float CInputConditioning::PerformRTConvert(const USHORT RTType, const float RTohms) {
	float RTTemp;

	m_DevManager.LookupRTLinerisationTable(RTType, RTohms, &RTTemp);

	return RTTemp;
}

//******************************************************
///
/// Limits the current in the current loop with the range limits.
/// @param[in] min4mA - Minimum of 4mA allowed as output.
/// @param[in] overRangeAllowed - 4% overrange (i.e. 20-21mA) allowed.
/// @param[in] mA - The original mA value to be set.
///
/// @return The mA limited to within range selection.
///
//******************************************************
float CInputConditioning::LimitCurrentLoopmAOutput(const BOOL min4mA, const BOOL overRangeAllowed, const float mA) {
	float limitedmA = mA;

	// If lower limit is 4 mA then ensure no lower current is output
	if (min4mA == TRUE) {
		// If 4mA is allowed
		if ((mA < 4.0F))
			limitedmA = 4.0F;
	} else {
		// Cannot source negative current
		if (mA < 0.0F)
			limitedmA = 0.0F;
	}

	// If upper limit is 21 mA then ensure no greater current is output
	if (overRangeAllowed == TRUE) {
		// If 4% overrange is allowed
		if ((mA > 21.0F))
			limitedmA = 21.0F;
	} else {
		// Otherise upper limit is 20 mA
		if ((mA > 20.0F))
			limitedmA = 20.0F;
	}

	return limitedmA;
}

//******************************************************
///
/// Limits the current in the current loop with the range limits.
/// @param[in] min4mA - Minimum of 4mA allowed as output.
/// @param[in] overRangeAllowed - 4% overrange (i.e. 20-21mA) allowed.
/// @param[in] mACount - The original mA count value to be set.
///
/// @return The mA limited count to within range selection.
///
//******************************************************
USHORT CInputConditioning::LimitCurrentLoopmAOutput(const USHORT slotNo, const BOOL min4mA, const BOOL overRangeAllowed,
		const USHORT mACount) {
	class CBrdInfo *pBrdInfoObj = NULL;
	USHORT limitedmACount = mACount;
	USHORT highLimit = 0;

	pBrdInfoObj = CBrdInfo::GetHandle();
	highLimit = pBrdInfoObj->HighestAllowedmAOutput(slotNo, overRangeAllowed);

	// If lower limit is 4 mA then ensure no lower current is output
	if (min4mA == TRUE) {
		// If 4mA is allowed
		if (mACount < AO_SELECT_4mA)
			limitedmACount = AO_SELECT_4mA;	// Tolerence of H/W will not guarantee 4mA is acheived exactly
	}

	// Check upper limit of 20mA & 21mA then ensure no greater current is output
	if (mACount > highLimit) {
		limitedmACount = highLimit;
	}

	return limitedmACount;
}

//******************************************************
///
/// Calculates the TC temperature from the TC mV & cold junction temperature.
/// @param[in] slotNo - The I/O card number.
/// @param[in] chanNo - The I/O card channel number.
/// @param[in] TCType - The type of thermocouple.
/// @param[in] TCmV - The mV developed by the thermocouple.
/// @param[in] CJmV - The mV compensation of the cold juction.
///
/// @return The temperature of the TC in Deg C.
///
//******************************************************
float CInputConditioning::PerformTCCJmVConvert(const USHORT slotNo, const USHORT chanNo, const USHORT TCType,
		const float TCmV, const float CJmV) {
#if defined ( DBG_FILE_LOG_IO_COND_DBG_ENABLE )
	QString  strLogMessage;
	strLogMessage.asprintf(L"CIPCOND::PerformTCCJmVConvert - begin Slot %d ChanNo %d TCType %d TCMv %f CJmV %f GTC:%d\r\n", slotNo, chanNo, TCType, TCmV, CJmV, GetTickCount() );
	m_debugFileLogger.WriteToDebugLogFile(strLogMessage);
#endif

	T_PRECPROFILE ptProfile = pSYSTEM_INFO->GetProfileConfig();
	class CInputConditioning *pICService = NULL;	///< Input conditioning service
	class CPPIOServiceManager *pServiceManagerObj = NULL;	///< Service manager
	float SensorTemp = 0;

	pServiceManagerObj = CPPIOServiceManager::GetHandle();
	if (NULL != pServiceManagerObj)
		pICService = pServiceManagerObj->GetICService();
	if (m_DevManager.LookupTCLinerisationTable(TCType, FALSE, TCmV + CJmV, &SensorTemp) == TRUE) {
#if defined ( DBG_FILE_LOG_IO_COND_DBG_ENABLE )
		strLogMessage.asprintf(L"CIPCOND::PerformTCCJmVConvert - LookupTCLinerisationTable Slot %d ChanNo %d TCType %d TCMv %f CJmV %f SensorTemp %f GTC:%d\r\n", slotNo, chanNo, TCType, TCmV, CJmV, SensorTemp, GetTickCount() );
		m_debugFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
		// Adjust the reading to the sensor compensation values (if required), and the reading is valid
		pICService->PerformOutputAdjust(SensorTemp, slotNo, chanNo, &SensorTemp);

#if defined ( DBG_FILE_LOG_IO_COND_DBG_ENABLE )
		strLogMessage.asprintf(L"CIPCOND::PerformTCCJmVConvert - PerformOutputAdjust Slot %d ChanNo %d TCType %d TCMv %f CJmV %f SensorTemp %f GTC:%d\r\n", slotNo, chanNo, TCType, TCmV, CJmV, SensorTemp, GetTickCount() );
		m_debugFileLogger.WriteToDebugLogFile(strLogMessage);
#endif

		///< If the temperature output is not Deg C, then convert, assumming we do not have an error
		SensorTemp = pSYSTEM_INFO->GetLocalTempFromDegC(SensorTemp);

#if defined ( DBG_FILE_LOG_IO_COND_DBG_ENABLE )
		strLogMessage.asprintf(L"CIPCOND::PerformTCCJmVConvert - GetLocalTempFromDegC Slot %d ChanNo %d TCType %d TCMv %f CJmV %f SensorTemp %f GTC:%d\r\n", slotNo, chanNo, TCType, TCmV, CJmV, SensorTemp, GetTickCount() );
		m_debugFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
	}

#if defined ( DBG_FILE_LOG_IO_COND_DBG_ENABLE )
	strLogMessage.asprintf(L"CIPCOND::PerformTCCJmVConvert - End Slot %d ChanNo %d TCType %d TCMv %f CJmV %f SensorTemp %f GTC:%d\r\n", slotNo, chanNo, TCType, TCmV, CJmV, SensorTemp, GetTickCount() );
	m_debugFileLogger.WriteToDebugLogFile(strLogMessage);
#endif

	return SensorTemp;
}

//******************************************************
///
/// Linearises the sensor value using a user linearisation table.
/// @param[in] UserTable - The ID of the user table.
/// @param[in] conditionedReading - The reading that requires linearisation.
///
/// @return The linearised reading.
///
//******************************************************
float CInputConditioning::PerformUserLinerisation(const USHORT UserTable, const float conditionedReading) {
	float retValue = conditionedReading;

	// @todo: Need to ensure that the table actually exists before performing a lookup
	if (m_DevManager.QueryUserTableVaild(UserTable) == TRUE) {
		m_DevManager.LookupUserLinerisationTable(UserTable, conditionedReading, &retValue);
	}

	return retValue;
}

//******************************************************
///
/// Damp the input signal x, referenceing previous reading y to a level of z using GCA
/// @param[in] newReading - The latest reading to be damped.
/// @param[in] prevReading - The previous reading.
/// @param[in] level - The level of damping that the reading requires.
///
/// @return The damped reading.
///
//******************************************************
float CInputConditioning::ApplyGCADamping(const float newReading, const float prevReading, const float level) {
	float factor = (newReading - prevReading) / level;
	return (prevReading + ((newReading - prevReading) / (1 + (100 / (1 + (factor * factor * factor * factor))))));
}

//******************************************************
///
/// Calculates the TC temperature from the TC & cold junction mV.
/// @param[in] slotNo - The I/O card number.
/// @param[in] chanNo - The I/O card channel number.
/// @param[in] TCType - The type of thermocouple.
/// @param[in] TCmV - The mV developed by the thermocouple.
/// @param[in] CJTemp - The temperature of the cold juction in Deg C.
///
/// @return The temperature of the TC in Deg C.
///
//******************************************************
float CInputConditioning::PerformTCCJTempConvert(const USHORT slotNo, const USHORT chanNo, const USHORT TCType,
		const float TCmV, const float CJTemp) {
#if defined ( DBG_FILE_LOG_IO_COND_DBG_ENABLE )
	QString  strLogMessage;
	strLogMessage.asprintf(L"CIPCOND::PerformTCCJTempConvert - begin Slot %d Chan N0 %d TCType %d TCMv %f CJTemp %f GTC:%d\r\n", slotNo, chanNo, TCType, TCmV, CJTemp, GetTickCount() );
	m_debugFileLogger.WriteToDebugLogFile(strLogMessage);
#endif

	float CJmV = 0.0F;
	float retValue = 0.0F;
	T_PDEVICETABLEHDR pDevHdr = NULL;
	BOOL useReverseLookup = FALSE;

	pDevHdr = m_DevManager.GetTCCJDeviceHdr(TCType);
	// Can only convert the CJ temperature to mV's if within the table limits
	// and a reverse lookup table exists; otherwise don't offset the CJ temperature
	if (pDevHdr != NULL) {
		if ((CJTemp >= pDevHdr->IPRangeLow) && (CJTemp <= pDevHdr->IPRangeHigh))
			useReverseLookup = TRUE;
	}

	// Get the CJ mV from the CJ temperature using reverse lookup
	if (useReverseLookup == TRUE) {
#if defined ( DBG_FILE_LOG_IO_COND_DBG_ENABLE )
		strLogMessage.asprintf(L"CIPCOND::PerformTCCJTempConvert - Reverse Lookup GTC:%d\r\n", GetTickCount() );
		m_debugFileLogger.WriteToDebugLogFile(strLogMessage);
#endif

		if (m_DevManager.LookupTCLinerisationTable(TCType, TRUE, CJTemp, &CJmV) == TRUE) {
#if defined ( DBG_FILE_LOG_IO_COND_DBG_ENABLE )
			strLogMessage.asprintf(L"CIPCOND::PerformTCCJTempConvert - LookupTCLinerisationTable CJTemp %f CJmV %f GTC:%d\r\n", CJTemp, CJmV, GetTickCount() );
			m_debugFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
			///< Lookup the temperature, assumming we do not have an error
			retValue = PerformTCCJmVConvert(slotNo, chanNo, TCType, TCmV, CJmV);

#if defined ( DBG_FILE_LOG_IO_COND_DBG_ENABLE )
			strLogMessage.asprintf(L"CIPCOND::PerformTCCJTempConvert - PerformTCCJmVConvert retValue %f TCmV %f CJmV %f GTC:%d\r\n", retValue, TCmV, CJmV, GetTickCount() );
			m_debugFileLogger.WriteToDebugLogFile(strLogMessage);
#endif
		} else {
			retValue = CJmV;
		}
	}

#if defined ( DBG_FILE_LOG_IO_COND_DBG_ENABLE )
	strLogMessage.asprintf(L"CIPCOND::PerformTCCJTempConvert - end Return Value %f GTC:%d\r\n", retValue, GetTickCount() );
	m_debugFileLogger.WriteToDebugLogFile(strLogMessage);
#endif

	// Otherwise ignore the CJ offset
	return retValue;
}

//******************************************************
///
/// Queries whether the pen alarm is currently in alarm.
/// @param[in] alarmNumber - The alarm number.
/// @param[in] penNumber - The pen number that the alarm is part of.
///
/// @return TRUE if the pen alarm is still in alarm condition; otherwise FALSE.
///
//******************************************************
BOOL CInputConditioning::QueryIsPenAlarmInAlarm( USHORT alarmNumber,
USHORT penNumber) {
	CDataItemAlarm *pAlarmDataItem = NULL;		///< Pointer to Alarm Data Item
	T_DATAITEM_STATUS status;
	BOOL inAlarm = FALSE;

	// Alarm is "in alarm state" irrespective whether it has been manually acknowledged or not
	pAlarmDataItem = (CDataItemAlarm*) pGlbDIT->GetDataItemPtr(DI_ALARM, alarmNumber, penNumber);
	status = pAlarmDataItem->GetStatus();
	if ((status == DISTAT_IN_ALARM_NOT_ACKED) || (status == DISTAT_IN_ALARM_ACKED))
		inAlarm = TRUE;

	return inAlarm;
}

//******************************************************
///
/// Queries whether the pen alarm has not been acknowledged.
/// @param[in] alarmNumber - The alarm number.
/// @param[in] penNumber - The pen number that the alarm is part of.
///
/// @return TRUE if the pen alarm has occurred and has not been manually acknowledged; otherwise FALSE.
///
//******************************************************
BOOL CInputConditioning::QueryIsPenAlarmNotAcked( USHORT alarmNumber,
USHORT penNumber) {
	CDataItemAlarm *pAlarmDataItem = NULL;		///< Pointer to Alarm Data Item
	T_DATAITEM_STATUS status;
	BOOL notAcked = FALSE;

	// Alarm is "in alarm state" and has not been manually acknowledged or
	// Alarm is now "out of alarm state" but wasn't acknowledged when in alarm, and was not auto
	pAlarmDataItem = (CDataItemAlarm*) pGlbDIT->GetDataItemPtr(DI_ALARM, alarmNumber, penNumber);
	status = pAlarmDataItem->GetStatus();
	if ((status == DISTAT_IN_ALARM_NOT_ACKED) || (status == DISTAT_OUT_OF_ALARM_NOT_ACKED))
		notAcked = TRUE;

	return notAcked;
}

/////////////////////////////////////////////////////
/// This Function converts the EngValue returned from IO FW to Error Code bytes based on the board type
/// @param[in] pCommonInfo - Common data processing parameters.
/// @param[in] pChanInfo - Channel specific data processing parameters.
///
/// @notes The readings timestamp cannot cross the timstamp rollover boundary more than once
///
/// @return TRUE if error present.
/// Rev History
/// @Version	@Date			@Author					@Remarks
/// 1.0			01/Apr/2019		Shankar Rao	Pendyala	Error Code Compatibility with New AI card (24Bit ADC/Channel Readings) and Old AI Card (16Bit)
/////////////////////////////////////////////////////
//
BOOL CInputConditioning::ConvertEngValueToV6IOErrorCode(const UCHAR cardNo, const T_RANGE_COUNTS EngValue,
		COMBO_VAR4 &var4ErrCode, const USHORT chanType) {
	BOOL bRet = FALSE;
	//Get the board info object to get board revision and board subtypes
	class CBrdInfo *pBrdInfoObj = NULL;
	pBrdInfoObj = CBrdInfo::GetHandle();
	UCHAR ucBoardRev = V6AI_ISSUE_1;
	pBrdInfoObj->GetBoardHardwareRevision(cardNo, &ucBoardRev);
	UCHAR ucAICardSubType = CAICard::WhatBoardSubType(ucBoardRev);

	////Compute the Error Code from EngValue returned from IO FW

	//1. Default do it in traditional way as V6IO does
	var4ErrCode.ul = static_cast<ULONG>(EngValue);

	//2. Handle if the board is of type V7AI (new AI) card
	if (AI_CARD_TYPE_V7AI == ucAICardSubType) {
		//2.1 Is error code present in Data Bytes?
		if ((AI_CHANNEL_TYPE_LINEAR_OHMS == chanType) || (AI_CHANNEL_TYPE_RT == chanType)) {
			if ((EngValue & V7IO_RTD_ERROR_CODE_START) == V7IO_RTD_ERROR_CODE_START) {
				//3. Get V7IO Error Code as a V6 error code by normlizing
				var4ErrCode.ul = CONVERT_V7IO_TO_V6_ERROR_CODE(EngValue & 0x00FFFFFF)
				;
			} else {
				var4ErrCode.ul = 0L;	//No error present
			}
		} else if (EngValue > V7IO_ERROR_CODE_START) {
			//3. Get V7IO Error Code as a V6 error code by normlizing
			var4ErrCode.ul = CONVERT_V7IO_TO_V6_ERROR_CODE(EngValue)
			;
		} else {
			var4ErrCode.ul = 0L;	//No error present
		}
	}

	if (var4ErrCode.ul >= START_OF_SPECIAL_CODES) {
		bRet = TRUE;
	}

	return bRet;
}

/////////////////////////////////////////////////////
/// This Function Returns the RtComp High w.r.t to the Board Sub Type
/// @param[in] Card No or Slot No.
///
///
/// @return Pointer To CFFConversionInfo (RTCompHigh Conversion) object .
/// Rev History
/// @Version	@Date			@Author					@Remarks
/// 1.0			17/Apr/2019		Shankar Rao	Pendyala	RtComp with New AI card (24Bit ADC/Channel Readings) and Old AI Card (16Bit)
/////////////////////////////////////////////////////
//
//
const CFFConversionInfo* CInputConditioning::GetRTCompHigh(const USHORT slotNo) const {
	//Get the board info object to get board revision and board subtypes
	class CBrdInfo *pBrdInfoObj = NULL;
	pBrdInfoObj = CBrdInfo::GetHandle();
	UCHAR ucBoardRev = V6AI_ISSUE_1;
	pBrdInfoObj->GetBoardHardwareRevision(slotNo, &ucBoardRev);
	UCHAR ucAICardSubType = CAICard::WhatBoardSubType(ucBoardRev);

	if (AI_CARD_TYPE_V7AI == ucAICardSubType) {
		return &BaseVolts[AI_CARD_TYPE_V7AI][LINEAR_VOLTS_100mV];
	} else {
		return &BaseVolts[AI_CARD_TYPE_V6AI][LINEAR_VOLTS_100mV];
	}
}

/////////////////////////////////////////////////////
/// This Function Returns the RtComp High w.r.t to the Board Sub Type
/// @param[in] Card No or Slot No.
///
///
/// @return Pointer To CFFConversionInfo (RTCompLow Conversion) object .
/// Rev History
/// @Version	@Date			@Author					@Remarks
/// 1.0			17/Apr/2019		Shankar Rao	Pendyala	RtComp with New AI card (24Bit ADC/Channel Readings) and Old AI Card (16Bit)
/////////////////////////////////////////////////////
//
//
const CFFConversionInfo* CInputConditioning::GetRTCompLow(const USHORT slotNo) const {
	//Get the board info object to get board revision and board subtypes
	class CBrdInfo *pBrdInfoObj = NULL;
	pBrdInfoObj = CBrdInfo::GetHandle();
	UCHAR ucBoardRev = V6AI_ISSUE_1;
	pBrdInfoObj->GetBoardHardwareRevision(slotNo, &ucBoardRev);
	UCHAR ucAICardSubType = CAICard::WhatBoardSubType(ucBoardRev);

	if (AI_CARD_TYPE_V7AI == ucAICardSubType) {
		return &BaseVolts[AI_CARD_TYPE_V7AI][LINEAR_VOLTS_25mV];
	} else {
		return &BaseVolts[AI_CARD_TYPE_V6AI][LINEAR_VOLTS_25mV];
	}
}

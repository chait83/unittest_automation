/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 I/O Scheduler
/// @n Filename: Ni100.h
/// @n Desc:	Constant data for the Nickel 100 RT
///
// 
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  4 Stability Project 1.1.1.1 7/2/2011 4:59:05 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  3 Stability Project 1.1.1.0 7/1/2011 4:27:23 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  2 V6 Firmware 1.1 3/9/2005 10:01:11 PM  Graham Waterfield
//  Correct Ni100 table
//  1 V6 Firmware 1.0 3/9/2005 8:50:18 PM Graham Waterfield 
// $
//
//////////////////////////////////////////////////////////////////////

#ifndef _NI100_H
#define _NI100_H

#if !defined(AFX_NI100_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_)
#define AFX_NI100_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

const T_IP_TABLE_ELEMENT Ni100Measurement[] = {
		// resistance,	 TempC
		69.5F, -60, 70.5F, -58, 72.2F, -54, 74.3F, -50, 75.2F, -48, 77.2F, -44, 79.1F, -40, 80.1F, -38, 82.1F, -34,
		84.2F, -30, 85.2F, -28, 87.2F, -24, 89.3F, -20, 90.3F, -18, 92.4F, -14, 94.6F, -10, 95.7F, -8, 97.8F, -4, 100,
		0, 102.2F, 4, 104.4F, 8, 105.6F, 10, 107.8F, 14, 110.1F, 18, 111.2F, 20, 113.6F, 24, 115.9F, 28, 117.1F, 30,
		119.4F, 34, 121.8F, 38, 123, 40, 125.4F, 44, 127.9F, 48, 129.1F, 50, 131.6F, 54, 134.1F, 58, 135.3F, 60, 137.9F,
		64, 140.4F, 68, 141.7F, 70, 144.3F, 74, 146.9F, 78, 148.3F, 80, 150.9F, 84, 153.6F, 88, 154.9F, 90, 157.7F, 94,
		160.4F, 98, 161.8F, 100, 164.6F, 104, 167.4F, 108, 168.8F, 110, 171.6F, 114, 174.5F, 118, 176, 120, 178.9F, 124,
		181.9F, 128, 183.3F, 130, 186.3F, 134, 189.4F, 138, 190.9F, 140, 194, 144, 197.1F, 148, 198.7F, 150, 201.8F,
		154, 205, 158, 206.6F, 160, 209.9F, 164, 213.2F, 168, 214.8F, 170, 218.1F, 174, 221.5F, 178, 223.2F, 180 };

#endif // !defined(AFX_NI1O0_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_)

#endif		// _NI100_H

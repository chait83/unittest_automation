/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O conditioning
/// @n Chromel-Copel.cpp
/// @n implementation for the Type B TC.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
//
//////////////////////////////////////////////////////////////////////

#include "CMMDefines.h"
#include "V6Config.h"
#include "V6IOErrorCodes.H"
#include "TraceDefines.h"
#include "V6defines.h"
#include <math.h>

#include "LinearTable.h"
#include "Device.h"

#include "Chromel-Copel.h"

#ifndef __cplusplus
#define __cplusplus
#endif

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif

T_DEVICETABLEHDR ChromelCopelVoltageHdr = { -3.11F,	///< Minimum table I/P value
		49.02F,										///< Maximum table I/P value
		-50,							///< Minimum table O/P value degrees C
		600,							///< Maximum table O/P value degrees C
		12,									///< The unique device identity ID
		12,											///< The device name
		0,	///< Number of readings to follow, must be set during initialisation
		FALSE,				///< This device table cannot be used as a CJ lookup
		FALSE,							///< This device table is not referenced
		AI_THERMO_RANGE_CHROMEL,					///< Type of device
		AI_CHANNEL_TYPE_LINEAR_VOLTS,	///< I/P channel type (ohms, volts etc.)
		MILLI,				///< What units the I/P table units in (m, u, n, p)
		0,											///< N/A
		LINEAR_CHANNEL_TYPE_TEMP,		///< O/P channel type (ohms, volts etc.)
		UNITS,				///< What units the O/P table units in (m, u, n, p)
		TEMP_DEG_C									///< Degrees C

		// Pointer to start of table
		};

T_DEVICETABLEHDR ChromelCopelTempHdr = { -50,									///< Minimum table I/P value degrees C
		600,							///< Maximum table I/P value degrees C
		-3.11F,										///< Minimum table O/P value
		49.02F,									///< Maximum table O/P value 
		12,									///< The unique device identity ID
		12,											///< The device name
		0,	///< Number of readings to follow, must be set during initialisation
		TRUE,				///< This device table can be used as a CJ lookup
		FALSE,							///< This device table is not referenced
		AI_THERMO_RANGE_CHROMEL,					///< Type of device
		LINEAR_CHANNEL_TYPE_TEMP,		///< I/P channel type (ohms, volts etc.)
		UNITS,				///< What units the I/P table units in (m, u, n, p)
		TEMP_DEG_C,									///< Degrees C
		AI_CHANNEL_TYPE_LINEAR_VOLTS,	///< O/P channel type (ohms, volts etc.)
		MILLI,				///< What units the O/P table units in (m, u, n, p)
		0											///< N/A

		// Pointer to start of table
		};

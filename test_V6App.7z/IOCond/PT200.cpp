/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O conditioning
/// @n PT200.cpp
/// @n implementation for the PT200 RT.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 10	Stability Project 1.5.1.3	7/2/2011 4:59:58 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 9	Stability Project 1.5.1.2	7/1/2011 4:38:41 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 8	Stability Project 1.5.1.1	3/17/2011 3:20:36 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 7	Stability Project 1.5.1.0	2/15/2011 3:03:44 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////

#include "CMMDefines.h"
#include "V6Config.h"
#include "V6IOErrorCodes.H"
#include "TraceDefines.h"
#include "V6defines.h"
#include <math.h>

#include "LinearTable.h"
#include "Device.h"

#include "PT200.h"

#ifndef __cplusplus
#define __cplusplus
#endif

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif

T_DEVICETABLEHDR PT200Hdr = { 37.0402F,				///< Minimum table I/P value
		780.9622F,									///< Maximum table I/P value
		-200,							///< Minimum table O/P value degrees C
		850,							///< Maximum table O/P value degrees C
		12,									///< The unique device identity ID
		12,											///< The device name
		0,	///< Number of readings to follow, must be set during initialisation
		FALSE,				///< This device table cannot be used as a CJ lookup
		FALSE,							///< This device table is not referenced
		AI_RT_RANGE_PT200,							///< Type of device
		AI_CHANNEL_TYPE_LINEAR_OHMS,	///< I/P channel type (ohms, volts etc.)
		UNITS,				///< What units the I/P table units in (m, u, n, p)
		0,											///< N/A
		LINEAR_CHANNEL_TYPE_TEMP,		///< O/P channel type (ohms, volts etc.)
		UNITS,				///< What units the O/P table units in (m, u, n, p)
		TEMP_DEG_C									///< Degrees C

		// Pointer to start of table
		};


/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	I/O Scheduler
/// @n Filename: PT400.h
/// @n Desc:	Constant data for the PT400 RT
///
// 
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 4	Stability Project 1.1.1.1	7/2/2011 4:59:59 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 3	Stability Project 1.1.1.0	7/1/2011 4:27:22 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 2	V6 Firmware 1.1		3/9/2005 8:17:05 PM	Graham Waterfield
//		Updated to use correct table
// 1	V6 Firmware 1.0		3/8/2005 9:46:55 PM	Graham Waterfield 
// $
//
//////////////////////////////////////////////////////////////////////

#ifndef _PT400_H
#define _PT400_H

#if !defined(AFX_PT400_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_)
#define AFX_PT400_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

const T_IP_TABLE_ELEMENT PT400Measurement[] = {
		// resistance,	TempC
		73.9592F, -200, 91.1992F, -190, 108.2992F, -180, 125.268F, -170, 142.114F, -160, 158.844F, -150, 175.4664F,
		-140, 191.988F, -130, 208.4148F, -120, 224.7536F, -110, 241.0096F, -100, 257.1884F, -90, 273.2952F, -80,
		289.334F, -70, 305.3088F, -60, 321.224F, -50, 337.0824F, -40, 352.8868F, -30, 368.64F, -20, 384.344F, -10, 400,
		0, 415.6096F, 10, 431.1724F, 20, 446.6892F, 30, 462.1592F, 40, 477.5828F, 50, 492.9604F, 60, 508.2912F, 70,
		523.5756F, 80, 538.8136F, 90, 554.0052F, 100, 569.15F, 110, 584.2488F, 120, 599.3008F, 130, 614.3068F, 140,
		629.266F, 150, 644.1792F, 160, 659.0456F, 170, 673.8656F, 180, 688.6392F, 190, 703.3664F, 200, 718.0468F, 210,
		732.6812F, 220, 747.2692F, 230, 761.8104F, 240, 776.3056F, 250, 790.754F, 260, 805.156F, 270, 819.5116F, 280,
		833.8208F, 290 };

#endif // !defined(AFX_PT400_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_)

#endif		// _PT400_H

/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	I/O Scheduler
/// @n Filename: Device.h
/// @n Desc:	interface for the CDevice class
///
// 
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 25	Stability Project 1.22.1.1	7/2/2011 4:56:44 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 24	Stability Project 1.22.1.0	7/1/2011 4:27:19 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 23	V6 Firmware 1.22		8/17/2006 8:21:21 PM	Graham Waterfield
//		Allow user linearisattion tables to be commited without the need to
//		restart the recorder
// 22	V6 Firmware 1.21		8/11/2006 1:42:14 PM	Graham Waterfield
//		Prevent user linearisation tables from being accessed in ATE build
// $
//
//////////////////////////////////////////////////////////////////////

#ifndef _DEVICE_H
#define _DEVICE_H

#if !defined(AFX_DEVICE_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_)
#define AFX_DEVICE_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_

#include "AIRanges.h"
#include "LinearTable.h"
#include "V6Config.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// Inbuilt RT tables
extern T_DEVICETABLEHDR PT100Hdr;
extern T_DEVICETABLEHDR PT200Hdr;
extern T_DEVICETABLEHDR PT400Hdr;
extern T_DEVICETABLEHDR PT500Hdr;
extern T_DEVICETABLEHDR PT1000Hdr;
extern T_DEVICETABLEHDR PT2000Hdr;
extern T_DEVICETABLEHDR Ni100Hdr;
extern T_DEVICETABLEHDR NK120Hdr;
extern T_DEVICETABLEHDR CU10Hdr;
extern T_DEVICETABLEHDR CU53Hdr;

// In built TC tables
extern T_DEVICETABLEHDR TypeBVoltageHdr;
extern T_DEVICETABLEHDR TypeBTempHdr;
extern T_DEVICETABLEHDR TypeCVoltageHdr;
extern T_DEVICETABLEHDR TypeCTempHdr;
extern T_DEVICETABLEHDR TypeDVoltageHdr;
extern T_DEVICETABLEHDR TypeDTempHdr;
extern T_DEVICETABLEHDR TypeEVoltageHdr;
extern T_DEVICETABLEHDR TypeETempHdr;
extern T_DEVICETABLEHDR TypeJVoltageHdr;
extern T_DEVICETABLEHDR TypeJTempHdr;
extern T_DEVICETABLEHDR TypeKVoltageHdr;
extern T_DEVICETABLEHDR TypeKTempHdr;
extern T_DEVICETABLEHDR TypeLVoltageHdr;
extern T_DEVICETABLEHDR TypeLTempHdr;
extern T_DEVICETABLEHDR TypeMVoltageHdr;
extern T_DEVICETABLEHDR TypeMTempHdr;
extern T_DEVICETABLEHDR TypeNVoltageHdr;
extern T_DEVICETABLEHDR TypeNTempHdr;
extern T_DEVICETABLEHDR TypeRVoltageHdr;
extern T_DEVICETABLEHDR TypeRTempHdr;
extern T_DEVICETABLEHDR TypeSVoltageHdr;
extern T_DEVICETABLEHDR TypeSTempHdr;
extern T_DEVICETABLEHDR TypeTVoltageHdr;
extern T_DEVICETABLEHDR TypeTTempHdr;
extern T_DEVICETABLEHDR WW26VoltageHdr;
extern T_DEVICETABLEHDR WW26TempHdr;
extern T_DEVICETABLEHDR ChromelCopelVoltageHdr;
extern T_DEVICETABLEHDR ChromelCopelTempHdr;
extern T_DEVICETABLEHDR PlatinelVoltageHdr;
extern T_DEVICETABLEHDR PlatinelTempHdr;

class CDevice {
public:
	CDevice();
	virtual ~CDevice();

	BOOL LookupSensorTable(const float SensorIn, float *const pSensorOut) const;
	BOOL LookupSensorLimitTable(const float SensorIn, float *const pSensorOut) const;
	BOOL LookupCJTable(const float CJIn, float *const pCJOut) const;

	const T_PDEVICETABLEHDR GetSensorDeviceHdr(void) const;
	const T_PDEVICETABLEHDR GetCJDeviceHdr(void) const;

	BOOL MarkCJTableUsed(const BOOL Used);
	BOOL MarkSensorTableUsed(const BOOL Used);

	BOOL QueryUserTableVaild() const;

	BOOL InitialiseTypeBTC(void);
	BOOL InitialiseTypeCTC(void);
	BOOL InitialiseTypeDTC(void);
	BOOL InitialiseTypeETC(void);
	BOOL InitialiseTypeJTC(void);
	BOOL InitialiseTypeKTC(void);
	BOOL InitialiseTypeLTC(void);
	BOOL InitialiseTypeMTC(void);
	BOOL InitialiseTypeNTC(void);
	BOOL InitialiseTypeRTC(void);
	BOOL InitialiseTypeSTC(void);
	BOOL InitialiseTypeTTC(void);
	BOOL InitialiseTypeGTC(void);
	BOOL InitialiseChromelCopel(void);
	BOOL InitialisePlatinel(void);

	BOOL InitialisePT100RT(void);
	BOOL InitialisePT200RT(void);
	BOOL InitialisePT400RT(void);
	BOOL InitialisePT500RT(void);
	BOOL InitialisePT1000RT(void);
	BOOL InitialisePT2000RT(void);
	BOOL InitialiseNK120RT(void);
	BOOL InitialiseNi100RT(void);
	BOOL InitialiseCU10RT(void);
	BOOL InitialiseCU53RT(void);

	BOOL InitialiseUserTable(const USHORT tableNo, T_PDEVICETABLEHDR pTableHdr, T_LTELEMENT *pSensorData,
			const USHORT noOfElements);
private:
	class CLinearTable m_Sensor;		///< Sensor linerised table
	class CLinearTable m_CJ;			///< CJ linearised table

	T_PDEVICETABLEHDR m_pSensorHdr;		///< Sensor linerised table header
	T_PDEVICETABLEHDR m_pCJHdr;			///< CJ linearised table header

	BOOL m_DeviceCreated;			///< TRUE if table header has been initialised (i.e. needs to be removed manually)
	BOOL m_SensorValid;			///< Is sensor linearised data & header valid
	BOOL m_CJValid;					///< Is CJ linerarised data & header valid
};

#endif // !defined(AFX_DEVICE_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_)

#endif		// _DEVICE_H

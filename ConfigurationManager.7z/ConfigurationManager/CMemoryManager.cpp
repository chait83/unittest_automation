/// @file CMemoryManager.cpp
/// ****************************************************************
/// Â© Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Memory Manager
/// @n Filename: CMemoryManager.cpp
/// @n Desc:	 Manages the in-memory data for storage and retrieval of the configuration data
///
//  ****************************************************************
//  Revision History
//  ****************************************************************
//  $Log[4]:
// 12  Stability Project 1.7.1.3  7/2/2011 4:56:08 PM Hemant(HAIL) 
//  Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
// 11  Stability Project 1.7.1.2  7/1/2011 4:38:06 PM Hemant(HAIL) 
//  Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
// 10  Stability Project 1.7.1.1  3/17/2011 3:20:16 PM  Hemant(HAIL) 
//  Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
// 9 Stability Project 1.7.1.0  2/15/2011 3:02:34 PM  Hemant(HAIL) 
//  File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
//  $
//
//  ***************************************************************************************
/******************************************************************************************
 COPYRIGHT (c) 2004
 HONEYWELL INC.,
 ALL RIGHTS RESERVED

 This software is a copyrighted work and/or information protected
 as a trade secret. Legal rights of Honeywell Inc. in this
 software is distinct from ownership of any medium in which the
 software is embodied. Copyright or trade secret notices included
 must be reproduced in any copies authorized by Honeywell Inc.
 The information in this software is subject to change without
 notice and should not be considered as a commitment by Honeywell
 Inc.
 //*****************************************************************************************/

#include "CMemoryManager.h"
#include "Macro.h"
#include "TraceDefines.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif

///******************************************************************************************
//  Function : CInstanceInfo::CInstanceInfo()
//  Logic : 
/// Usage : Construction of the InstanceInfo class
//  Author : [Rashmy Bharadawaj]
/// Returns : (none)
/// Exception/Error handling : (none)
/// Assumptions : (none)
//  Function parameters : (none)
//  Modification History :
//  Date   Modifications
//  ----   -------------
//  6/29/2004  Created
///******************************************************************************************
CInstanceInfo::CInstanceInfo() {
	pInstanceCommitted = NULL;
	pInstanceModifiable = NULL;
	nInstanceState = INSTANCE_NOT_AVAILABLE;
}

///******************************************************************************************
//  Function : CInstanceInfo::~CInstanceInfo()
//  Logic : Destructor
/// Usage : Uninstantiates the InstanceInfo class
//  Author : [Rashmy Bharadawaj]
/// Returns : (none)
/// Exception/Error handling : (none)
/// Assumptions : (none)
//  Function parameters : (none)
//  Modification History :
//  Date   Modifications
//  ----   -------------
//  6/29/2004  Created
///******************************************************************************************

CInstanceInfo::~CInstanceInfo() {
}

///******************************************************************************************
//  Function : CBlockTypeInfo::CBlockTypeInfo()
//  Logic : Default Constructor
/// Usage : Instantiates the CBlockTypeInfo class object
//  Author : [Rashmy Bharadawaj]
/// Returns : (none)
/// Exception/Error handling : (none)
/// Assumptions : (none)
//  Function parameters : (none)
//  Modification History :
//  Date   Modifications
//  ----   -------------
//  7/6/2004  Created
//*****************************************************************************************/
CBlockTypeInfo::CBlockTypeInfo() {
	nBlockState = BLOCK_CREATE;
}

///******************************************************************************************
//  Function : CBlockTypeInfo::~CBlockTypeInfo()
//  Logic :  Destructor
/// Usage : Uninstantiates the CBlockTypeInfo class object
//  Author : [Rashmy Bharadawaj]
/// Exception/Error handling : (none)
/// Assumptions : (none)
//  Function parameters : (none)
//  Modification History :
//  Date   Modifications
//  ----   -------------
//  7/6/2004  Created
//*****************************************************************************************/

CBlockTypeInfo::~CBlockTypeInfo() {

}

//Class CConfigurationInfo Implementation

///******************************************************************************************
//  Function : CConfigurationInfo::CConfigurationInfo()
//  Logic : Default Constructor 
/// Usage : Instantiates the CConfigurationInfo class object
//  Author : [Rashmy Bharadawaj]
/// Exception/Error handling : (none)
/// Assumptions : (none)
//  Function parameters : (none)
//  Modification History :
//  Date   Modifications
//  ----   -------------
//  6/29/2004  Created
//*****************************************************************************************/
CConfigurationInfo::CConfigurationInfo() {
	wAccessSpecifier = ALLOW_NONE;
	dwConfigSize = 0;
	wState = CONFIGURATION_INIT;
	pByConfigurationFile = NULL;
	lSessionNumber = NULL;
}

///******************************************************************************************
//  Function : CConfigurationInfo::~CConfigurationInfo()
//  Logic : Destructor 
/// Usage : Uninstantiates the CConfigurationInfo class object
//  Author : [Rashmy Bharadawaj]
/// Returns : (none)
/// Exception/Error handling : (none)
/// Assumptions : (none)
//  Function parameters : (none)
//  Modification History :
//  Date   Modifications
//  ----   -------------
//	6/29/2004  Created
//*****************************************************************************************/

CConfigurationInfo::~CConfigurationInfo() {

}

///******************************************************************************************
//  Function : CIdentifierInfo::CIdentifierInfo()
//  Logic : Default Constructor
/// Usage : Instantiates the CIdentifierInfo class object
//  Author : [Rashmy Bharadawaj]
/// Returns : (none)
/// Exception/Error handling : (none)
/// Assumptions : (none)
//  Function parameters : (none)
//  Modification History :
//  Date   Modifications
//  ----   -------------
//  09/15/2004  Created
//*****************************************************************************************/
CIdentifierInfo::CIdentifierInfo() {
	pIdentifierDetails = NULL;
}

///******************************************************************************************
//  Function : CIdentifierTypeInfo::~CIdentifierTypeInfo()
//  Logic :  Destructor
/// Usage : Uninstantiates the CIdentifierInfo class object
//  Author : [Rashmy Bharadawaj]
/// Returns : (none)
/// Exception/Error handling : (none)
/// Assumptions : (none)
//  Function parameters : (none)
//  Modification History :
//  Date   Modifications
//  ----   -------------
//  09/15/2004  Created
//*****************************************************************************************/

CIdentifierInfo::~CIdentifierInfo() {
}
//******************************************************************************************
//  Function : CMetadataInfo::CMetadataInfo()
//  Logic : Default Constructor
/// Usage : Instantiates the CMetadataInfo class object
//  Author : [Rashmy Bharadawaj]
/// Returns : (none)
/// Exception/Error handling : (none)
/// Assumptions : (none)
//  Function parameters : (none)
//  Modification History :
//  Date   Modifications
//  ----   -------------
//  6/30/2004  Created
//*****************************************************************************************/

CMetadataInfo::CMetadataInfo() {
	pBlockTypeDetails = NULL;
	bPositionComputed = FALSE;
	dwSize = 0;
}

//******************************************************************************************
//  Function : CMetadataInfo::~CMetadataInfo()
//  Logic : Destructor
/// Usage : Uninstantiates the CMetadataInfo class object
//  Author : [Rashmy Bharadawaj]
/// Returns : (none)
/// Exception/Error handling : (none)
/// Assumptions : (none)
//  Function parameters : (none)
//  Modification History :
//  Date   Modifications
//  ----   -------------
/// 6/30/2004  Created
//*****************************************************************************************/

CMetadataInfo::~CMetadataInfo() {
}

//******************************************************************************************
//  Function : CMemoryManager::CMemoryManager()
//  Logic : Default Constructor
/// Usage : Creates an object of the CMemoryManager class after performing object level initialization
//  Author : [Rashmy Bharadawaj]
/// Returns : (none)
/// Exception/Error handling : (none)
/// Assumptions : (none)
//  Function parameters : (none)
//  Modification History :
//  Date   Modifications
/// ----   -------------
/// 6/21/2004  Created
//*****************************************************************************************/

CMemoryManager::CMemoryManager() {
	LOG_INFO(CMM_qDebugR_MODE, ("CMemoryManager()  - Invoked"));

	/**Initialize the Members*/
	m_dwConfigIDCounter = 0;
	m_pBySystemMetadata = NULL;

	/**Initialize the CriticalSections*/
	QMutex* m_csConfigurationSync;
	QMutex* m_csMetadataSync;
}

//******************************************************************************************
//  Function : CMemoryManager::~CMemoryManager()
//  Logic : 
/// Usage : 
//  Author : [Rashmy Bharadawaj]
/// Returns : (none)
/// Exception/Error handling : (none)
/// Assumptions : 
//  Function parameters : 
//  Modification History :
//  Date   Modifications
//  ----   -------------
/// 6/21/2004  Created
//*****************************************************************************************/

CMemoryManager::~CMemoryManager() {
	LOG_INFO(CMM_qDebugR_MODE, ("~CMemoryManager()  - Invoked"));

	/**Cleanup*/
	ReleaseConfiguration();

	if (m_mapSystemMetadataLookup.size() > 0)
		m_mapSystemMetadataLookup.clear();

	/**Delete the CriticalSections*/
	//deletion of mutex not required;
	//deletion of mutex not required;
}

//******************************************************************************************
//  Function :  CMemoryManager::InitializeMetadata()
//  Logic : 
/// Usage : Creates In-memory data structures for persisting the metadata against the specified configuration ID.
//  Author : [Rashmy Bharadawaj]
/// Exception/Error handling : Structured Exception Handling Macros (Defined in Macro.h) 
/// Assumptions : 
//  Function parameters : 
/// @param[in]	dwConfigurationID - The id of the configuration to Initialize the Metadata
/// @param[in]	pbySystemMetadata - The System Metadata Buffer
/// @return		CMMSTATUS		  - Enumerated Status Code (Defined in Global.h)
//  Modification History :
//  Date   Modifications
//  ----   -------------
/// 6/28/2004  Created
//*****************************************************************************************/

CMMSTATUS CMemoryManager::InitializeMetadata(DWORD dwConfigurationID, BYTE *pbySystemMetadata) {
	LOG_INFO(CMM_qDebugR_MODE, ("InitializeMetadata()  - Invoked"));
	LOG_INFO(CMM_qDebugR_MODE, ("InitializeMetadata() - Configuration ID : %d"), dwConfigurationID);

	BEGIN__EXCEPTION__BLOCK__EX

	//Basic Validation
if	(dwConfigurationID < 0)
	RETURN__FAILURE__EX(CSTATUS_INVALID_CONFIGURATION)

	CONFIGMETADATA_MAP::iterator MetadataIterator;

	MetadataIterator = m_mapSystemMetadataLookup.find(dwConfigurationID);

	if(MetadataIterator != m_mapSystemMetadataLookup.end())
	RETURN__FAILURE__EX(CSTATUS_DUPLICATE_CONFIGURATION)

	/**Critical Code Starts*/
	m_csMetadataSync.lock();
	bMetadataCS = TRUE;

	/**Insert an empty METADATA_MAP*/
	METADATA_MAP mapSystemMetadata;

	pair<CONFIGMETADATA_MAP::iterator,bool>
	pairConfigMetadata = m_mapSystemMetadataLookup.insert(CONFIGMETADATA_MAP::value_type(dwConfigurationID,mapSystemMetadata));

	if(false == pairConfigMetadata.second)
	RETURN__FAILURE__EX(CSTATUS_FAIL)

	/**if this configuration is the system one*/
	if(SYSTEM_CONFIGURATION_ID == dwConfigurationID)
	{
		/** Validate the Metadata pointer*/
		CHECK_FOR_NULL(pbySystemMetadata)

		/** Update the Systeme metadata */
		m_pBySystemMetadata = pbySystemMetadata;
	}

	END__EXCEPTION__BLOCK__EX
	CATCH__EXCEPTION__EX
}

//******************************************************************************************
//  Function :  CMemoryManager::SetIdentifierBlock()
//  Logic : 
/// Usage : Creates and persists an identifier of the specific block type within the specified configuration 
//  Author : [Rashmy Bharadawaj]
/// Exception/Error handling : Structured Exception Handling Macros (Defined in Macro.h)
/// Assumptions : 
//  Function parameters : 
/// @param[in] dwConfigurationID	- The Configuration ID of the identifier being set
/// @param[in] wBlockType			- The Block type of the identifier being set
/// @param[in] pByBlockAddress		- The Location of the Block Details in the Metadata Buffer
/// @param[in] wIdentifierPosition	- The Position of the Identifier in the Block Declaration.
/// @param[in] pByIdentifierAddress - The Location of the Identifier in the Metadata Buffer
/// @return		CMMSTATUS		  - Enumerated Status Code (Defined in Global.h)
//  Modification History :
//  Date   Modifications
//  ----   -------------
//  6/28/2004  Created
//*****************************************************************************************/

CMMSTATUS CMemoryManager::SetIdentifierBlock(DWORD dwConfigurationID, WORD wBlockType, BYTE *pByBlockAddress,
		WORD wIdentifierPosition, BYTE *pByIdentifierAddress) {
	BEGIN__EXCEPTION__BLOCK__EX

	/**Basic Validation*/
if	(dwConfigurationID < 0)
	RETURN__FAILURE__EX(CSTATUS_INVALID_CONFIGURATION)

	if(wBlockType < 0)
	RETURN__FAILURE__EX(CSTATUS_INVALID_BLOCKTYPE)

	CHECK_FOR_NULL( pByIdentifierAddress )
	CHECK_FOR_NULL( pByBlockAddress )

	/**Lookup the configuration record*/
	CONFIGMETADATA_MAP::iterator ConfigurationIterator;

	ConfigurationIterator = m_mapSystemMetadataLookup.find(dwConfigurationID);

	if(ConfigurationIterator == m_mapSystemMetadataLookup.end())
	RETURN__FAILURE__EX(CSTATUS_METADATA_NOTINITIALIZED)

	/**Lookup the blocktype*/
	METADATA_MAP::iterator MetadataIterator;

	MetadataIterator = ConfigurationIterator->second.find(wBlockType);

	/**Critical Code Starts*/
	m_csMetadataSync.lock();
	bMetadataCS = TRUE;

	if(MetadataIterator == ConfigurationIterator->second.end()) /**If blockType not found, build one*/
	{
		/**Construct a new Metadata info*/
		METADATA_INFO objMetadataInfo;

		/**Set the member (s)*/
		objMetadataInfo.pBlockTypeDetails = pByBlockAddress;

		/**Create a new Identifier Info */
		IDENTIFIER_INFO objIdentifierInfo;
		objIdentifierInfo.pIdentifierDetails = (void*)pByIdentifierAddress;

		/**Create a new Identifier Map*/

		/**Insert the new IdentifierInfo structure to the IdentifierMap within the MetadataInfo*/
		pair<IDENTIFIER_MAP::iterator,bool> pairIdentifier = objMetadataInfo.IdentifierMap.insert(IDENTIFIER_MAP::value_type(wIdentifierPosition,objIdentifierInfo));

		if(false == pairIdentifier.second)
		RETURN__FAILURE__EX(CSTATUS_FAIL)

		/**Finally add it to the Metadata Structure*/
		pair<METADATA_MAP::iterator,bool> pairBlock = ConfigurationIterator->second.insert(METADATA_MAP::value_type(wBlockType,objMetadataInfo));

		if(false == pairBlock.second)
		RETURN__FAILURE__EX(CSTATUS_FAIL)

	}
	else
	{
		/**Lookup the BlockInfo structure contents*/
		IDENTIFIER_MAP::iterator mapIdentifier;
		mapIdentifier = MetadataIterator->second.IdentifierMap.find(wIdentifierPosition);

		if(mapIdentifier == MetadataIterator->second.IdentifierMap.end()) /**If the Identifier is not found */
		{
			IDENTIFIER_INFO objIdentifierInfo;
			objIdentifierInfo.pIdentifierDetails = (void*)pByIdentifierAddress;

			pair<IDENTIFIER_MAP::iterator,bool> pairIdentifier;
			pairIdentifier = MetadataIterator->second.IdentifierMap.insert(IDENTIFIER_MAP::value_type(wIdentifierPosition,objIdentifierInfo));

			if(false == pairIdentifier.second)
			RETURN__FAILURE__EX(CSTATUS_FAIL)
		}
		else /**If Identifier is found*/
		{
			/**Simply update the contents*/
			mapIdentifier->second.pIdentifierDetails = pByIdentifierAddress;
		}
	}

	END__EXCEPTION__BLOCK__EX
	CATCH__EXCEPTION__EX
}

//******************************************************************************************
//  Function :  CMemoryManager::GetIdentifierBlock()
//  Logic : 
/// Usage : Returns the Identifier based on the specified configuration ID,blocktype and Identifier name
//  Author : [Rashmy Bharadawaj]
/// Exception/Error handling : Structured Exception Handling Macros (Defined in Macro.h) 
/// Assumptions : 
//  Function parameters : 
/// @param[in] dwConfigurationID	 - The Configuration ID of the identifier to retrieve
/// @param[in] wBlockType			 - The Block type of the identifier to retrieve
/// @param[in] pszIdentifierName	 - The Name of the Identifier. Unique in a block
/// @param[out] pByIdentifierAddress - The Address of the Identifier in the Metadata Buffer
/// @param[out] pdwPosition			 - The Byte Location of the Identifier in the Metadata Buffer
/// @return		CMMSTATUS		 - Enumerated Status Code (Defined in Global.h)
//  Modification History :
//  Date   Modifications
//  ----   -------------
//  6/28/2004  Created
//*****************************************************************************************/

CMMSTATUS CMemoryManager::GetIdentifierBlock(DWORD dwConfigurationID, WORD wBlockType, char *pszIdentifierName,
		BYTE **pByIdentifierAddress, DWORD *pdwPosition) {
	BEGIN__EXCEPTION__BLOCK__EX

	/**Basic Validation*/
if	(dwConfigurationID < 0)
	RETURN__FAILURE__EX(CSTATUS_INVALID_CONFIGURATION)

	if(wBlockType < 0)
	RETURN__FAILURE__EX(CSTATUS_INVALID_BLOCKTYPE)

	CHECK_FOR_NULL( pdwPosition )
	CHECK_FOR_NULL( pszIdentifierName )
	CHECK_FOR_NULL( pByIdentifierAddress )

	/**Critical Code Starts*/
	m_csMetadataSync.lock();
	bMetadataCS = TRUE;

	/**Lookup the configuration record*/
	CONFIGMETADATA_MAP::iterator ConfigurationIterator;

	ConfigurationIterator = m_mapSystemMetadataLookup.find(dwConfigurationID);

	if(ConfigurationIterator == m_mapSystemMetadataLookup.end())
	RETURN__FAILURE__EX(CSTATUS_METADATA_NOTINITIALIZED)

	/**Lookup the blocktype*/
	METADATA_MAP::iterator MetadataIterator;

	MetadataIterator = ConfigurationIterator->second.find(wBlockType);

	if(MetadataIterator == ConfigurationIterator->second.end()) //If blockType not found, return an error
	RETURN__FAILURE__EX(CSTATUS_INVALID_BLOCKTYPE)

	/**Construct a string of the IdenfierName*/
	CHARSTRING sIdenfierNameParam(pszIdentifierName);
	CHARSTRING sIdentifierName;

	IDENTIFIER_RECORD_INFO *pIdentifierDetails;

	/**Lookup the Identifiermap*/
	IDENTIFIER_MAP::iterator mapIdentifier;
	for(mapIdentifier = MetadataIterator->second.IdentifierMap.begin();mapIdentifier != MetadataIterator->second.IdentifierMap.end();mapIdentifier++)
	{
		/**Fetch the details*/
		pIdentifierDetails = (IDENTIFIER_RECORD_INFO*) mapIdentifier->second.pIdentifierDetails;

		/**Read the name*/
		sIdentifierName = pIdentifierDetails->Fieldname;

		/**Compare*/
		if(sIdenfierNameParam == sIdentifierName)
		{
			/**Simply update the return contents*/
			*pByIdentifierAddress = (BYTE*) mapIdentifier->second.pIdentifierDetails;
			*pdwPosition = mapIdentifier->second.dwIdentifierPosition;
			break;
		}
	}

	if(*pByIdentifierAddress == NULL) /**If the Identifier is not found*/
	RETURN__FAILURE__EX(CSTATUS_INVALID_IDENTIFIER)

	END__EXCEPTION__BLOCK__EX
	CATCH__EXCEPTION__EX
}

//******************************************************************************************
//  Function :  CMemoryManager::GetBlock()
//  Logic : 
/// Usage : Returns the Specific block within the configuration ID
//  Author : [Rashmy Bharadawaj]
/// Exception/Error handling : Structured Exception Handling Macros (Defined in Macro.h) 
/// Assumptions : 
//  Function parameters : 
/// @param[in] dwConfigurationID	 - The Configuration ID of the Block to retrieve
/// @param[in] wBlockType			 - The Block type to retrieve
/// @param[out] pByBlockAddress		 - The Address of the Block in the Metadata Buffer
/// @return		CMMSTATUS		  - Enumerated Status Code (Defined in Global.h)
//  Modification History :
//  Date   Modifications
//  ----   -------------
/// 7/19/2004  Created
//*****************************************************************************************/

CMMSTATUS CMemoryManager::GetBlock(DWORD dwConfigurationID, WORD wBlockType, BYTE **pByBlockAddress) {
	BEGIN__EXCEPTION__BLOCK__EX

	/** Basic Validation*/
if	(dwConfigurationID < 0)
	RETURN__FAILURE__EX(CSTATUS_INVALID_CONFIGURATION)

	if(wBlockType < 0)
	RETURN__FAILURE__EX(CSTATUS_INVALID_BLOCKTYPE)

	CHECK_FOR_NULL( pByBlockAddress )

	/**Critical Code Starts*/
	m_csMetadataSync.lock();
	bMetadataCS = TRUE;

	/**Lookup the configuration record*/
	CONFIGMETADATA_MAP::iterator ConfigurationIterator;

	ConfigurationIterator = m_mapSystemMetadataLookup.find(dwConfigurationID);

	if(ConfigurationIterator == m_mapSystemMetadataLookup.end())
	RETURN__FAILURE__EX(CSTATUS_METADATA_NOTINITIALIZED)

	/**Lookup the blocktype*/
	METADATA_MAP::iterator MetadataIterator;

	MetadataIterator = ConfigurationIterator->second.find(wBlockType);

	if(MetadataIterator == ConfigurationIterator->second.end()) /**If blockType not found, return an error*/
	RETURN__FAILURE__EX(CSTATUS_INVALID_BLOCKTYPE)

	//Return the block address
	*pByBlockAddress = (BYTE*)MetadataIterator->second.pBlockTypeDetails;

	END__EXCEPTION__BLOCK__EX
	CATCH__EXCEPTION__EX
}

//******************************************************************************************
//  Function :  CMemoryManager::GetEnumIdentifier()
//  Logic : 
/// Usage : Returns the list of identifiers available within a configuration ID & Block type combination
//  Author : [Rashmy Bharadawaj]
/// Exception/Error handling : Structured Exception Handling Macros (Defined in Macro.h) 
/// Assumptions : 
//  Function parameters : 
/// @param[in]  dwConfigurationID	 - The Configuration ID of the Identifier list
/// @param[in]  wBlockType			 - The Block type of the Identifier list
/// @param[out] *pdwCount			 - The Number of Identifiers defined in the block
/// @param[out] ***pzIdentifierArray - The List of Identifier addresses in the block
/// @return		CMMSTATUS			 - Enumerated Status Code (Defined in Global.h)
//  Modification History :
//  Date   Modifications
//  ----   -------------
//  6/30/2004  Created
//*****************************************************************************************/

CMMSTATUS CMemoryManager::GetEnumIdentifier(DWORD dwConfigurationID, WORD wBlockType, DWORD *pdwCount,
		BYTE ***pzIdentifierArray) {
	BEGIN__EXCEPTION__BLOCK

	/**Basic Validation*/
if	(dwConfigurationID < 0)
	RETURN__FAILURE(CSTATUS_INVALID_CONFIGURATION)

	if(wBlockType < 0)
	RETURN__FAILURE(CSTATUS_INVALID_BLOCKTYPE)

	CHECK_FOR_NULL(pdwCount)

	/**Lookup the configuration record*/
	CONFIGMETADATA_MAP::iterator ConfigurationIterator;

	ConfigurationIterator = m_mapSystemMetadataLookup.find(dwConfigurationID);

	if(ConfigurationIterator == m_mapSystemMetadataLookup.end())
	RETURN__FAILURE(CSTATUS_METADATA_NOTINITIALIZED)

	/**Lookup the blocktype*/
	METADATA_MAP::iterator MetadataIterator;

	MetadataIterator = ConfigurationIterator->second.find(wBlockType);

	if(MetadataIterator == ConfigurationIterator->second.end()) /**If blockType not found, return an error*/
	RETURN__FAILURE(CSTATUS_INVALID_BLOCKTYPE)

	/**Get the count of identifiers*/
	DWORD dwTempCount = (DWORD) MetadataIterator->second.IdentifierMap.size();

	/**Allocate the memory for the array*/
	HLOCAL hMemory = NULL;

	if(!(hMemory = LocalAlloc(LPTR,(dwTempCount * sizeof(BYTE*)))))
	RETURN__FAILURE(CSTATUS_INSUFFICIENT_MEMORY)

	/**If you get less than you need,return an error*/
	if( LocalSize(hMemory) < (dwTempCount * sizeof(BYTE*)))
	{
		/**Free up the allocated memory*/
		if(hMemory)
		LocalFree(hMemory);

		RETURN__FAILURE(CSTATUS_INSUFFICIENT_MEMORY)
	}

	*pzIdentifierArray = (BYTE**) hMemory;

	/**Iterate through all the instances and fill up the array*/
	IDENTIFIER_MAP::iterator IdentifierIterator;
	int nIndex = 0;

	for(IdentifierIterator = MetadataIterator->second.IdentifierMap.begin();IdentifierIterator != MetadataIterator->second.IdentifierMap.end();IdentifierIterator++)
	{
		/**Copy the pointer*/
		*(*pzIdentifierArray + nIndex) = (BYTE*)IdentifierIterator->second.pIdentifierDetails;

		/**Increment the index*/
		nIndex++;
	}

	/**Finally return the count*/
	*pdwCount = dwTempCount;

	END__EXCEPTION__BLOCK
	CATCH__EXCEPTION
}

//******************************************************************************************
//  Function :  CMemoryManager::DeleteMetadata()
//  Logic : 
/// Usage : Deletes and de-allocates the metadata of the specified configuration
//  Author : [Rashmy Bharadawaj]
/// Exception/Error handling : Structured Exception Handling Macros (Defined in Macro.h) 
/// Assumptions : 
//  Function parameters : 
/// @param[in]  dwConfigurationID	 - The Configuration ID of the Metadata to delete from memory
/// @return		CMMSTATUS		  - Enumerated Status Code (Defined in Global.h)
//  Modification History :
//  Date   Modifications
//  ----   -------------
//  6/28/2004  Created
//*****************************************************************************************/

CMMSTATUS CMemoryManager::DeleteMetadata(DWORD dwConfigurationID) {
	BEGIN__EXCEPTION__BLOCK__EX

	/**Basic Validation*/
if	(dwConfigurationID < 0)
	RETURN__FAILURE__EX(CSTATUS_INVALID_CONFIGURATION)

	/**Critical Code Starts*/
	m_csMetadataSync.lock();
	bMetadataCS = TRUE;

	/**Lookup the configuration record*/
	CONFIGMETADATA_MAP::iterator ConfigurationIterator;

	ConfigurationIterator = m_mapSystemMetadataLookup.find(dwConfigurationID);

	if(ConfigurationIterator == m_mapSystemMetadataLookup.end())
	RETURN__FAILURE__EX(CSTATUS_METADATA_NOTINITIALIZED)

	/**Delete the structure completely*/
	m_mapSystemMetadataLookup.erase(ConfigurationIterator);

	END__EXCEPTION__BLOCK__EX
	CATCH__EXCEPTION__EX
}

//******************************************************************************************
//  Function :  CMemoryManager::ComputeMetadataSize()
//  Logic : 
/// Usage : Computes all the block sizes and the complete metadata size of the specified configuration
//  Author : [Rashmy Bharadawaj]
/// Exception/Error handling : Structured Exception Handling Macros (Defined in Macro.h) 
/// Assumptions : 
//  Function parameters : 
/// @param[in]  dwConfigurationID	 - The Configuration ID of the Metadata to compute.
/// @return		CMMSTATUS			 - Enumerated Status Code (Defined in Global.h)
//  Modification History :
//  Date   Modifications
//  ----   -------------
/// 7/1/2004  Created
//*****************************************************************************************/

CMMSTATUS CMemoryManager::ComputeMetadataSize(DWORD dwConfigurationID) {
	BEGIN__EXCEPTION__BLOCK__EX

	/**Basic Validation*/
if	(dwConfigurationID < 0)
	RETURN__FAILURE__EX(CSTATUS_INVALID_CONFIGURATION)

	/**Critical Code Starts*/
	m_csMetadataSync.lock();
	bMetadataCS = TRUE;

	/**Lookup the configuration record*/
	CONFIGMETADATA_MAP::iterator ConfigurationIterator;

	ConfigurationIterator = m_mapSystemMetadataLookup.find(dwConfigurationID);

	if(ConfigurationIterator == m_mapSystemMetadataLookup.end())
	RETURN__FAILURE__EX(CSTATUS_METADATA_NOTINITIALIZED)

	/**Start with the first level blocks*/
	METADATA_MAP::iterator MetadataIterator;

	IDENTIFIER_RECORD_INFO* pBlockDetails = NULL;

	for(MetadataIterator = ConfigurationIterator->second.begin();MetadataIterator != ConfigurationIterator->second.end();MetadataIterator++)
	{
		pBlockDetails = (IDENTIFIER_RECORD_INFO*) MetadataIterator->second.pBlockTypeDetails;
		MetadataIterator->second.dwSize = ComputeBlockSize(ConfigurationIterator, pBlockDetails);
	}

	END__EXCEPTION__BLOCK__EX
	CATCH__EXCEPTION__EX
}

//******************************************************************************************
//  Function :  CMemoryManager::GetBlockSize()
//  Logic : 
/// Usage : Returns the block size of the specified type within the configuration
//  Author : [Rashmy Bharadawaj]
/// Exception/Error handling : Structured Exception Handling Macros (Defined in Macro.h) 
/// Assumptions : 
//  Function parameters : 
/// @param[in]  dwConfigurationID	 - The Configuration ID of the Block to Lookup
/// @param[in]  wBlockType			 - The Block type of the block to lookup
/// @param[out] *pdwSize			 - The Size of the block
/// @return		CMMSTATUS		  - Enumerated Status Code (Defined in Global.h)
//  Modification History :
//  Date   Modifications
//  ----   -------------
//  7/1/2004  Created
//*****************************************************************************************/

CMMSTATUS CMemoryManager::GetBlockSize(DWORD dwConfigurationID, WORD wBlockType, DWORD *pdwSize) {
	BEGIN__EXCEPTION__BLOCK__EX

	/**Basic Validation*/
if	(dwConfigurationID < 0)
	RETURN__FAILURE__EX(CSTATUS_INVALID_CONFIGURATION)

	if(wBlockType < 0)
	RETURN__FAILURE__EX(CSTATUS_INVALID_BLOCKTYPE)

	CHECK_FOR_NULL(pdwSize)

	/**Critical Code Starts*/
	m_csMetadataSync.lock();
	bMetadataCS = TRUE;

	/**Lookup the configuration record*/
	CONFIGMETADATA_MAP::iterator ConfigurationIterator;

	ConfigurationIterator = m_mapSystemMetadataLookup.find(dwConfigurationID);

	if(ConfigurationIterator == m_mapSystemMetadataLookup.end())
	RETURN__FAILURE__EX(CSTATUS_METADATA_NOTINITIALIZED)

	/**Lookup the blocktype*/
	METADATA_MAP::iterator MetadataIterator;

	MetadataIterator = ConfigurationIterator->second.find(wBlockType);

	if(MetadataIterator == ConfigurationIterator->second.end()) //If blockType not found, return an error
	RETURN__FAILURE__EX(CSTATUS_INVALID_BLOCKTYPE)

	/**Return the size*/
	*pdwSize = MetadataIterator->second.dwSize;

	END__EXCEPTION__BLOCK__EX
	CATCH__EXCEPTION__EX
}

//******************************************************************************************
//  Function :  GetMetadataFile()
//  Logic : 
/// Usage : Returns the System Metadata File
//  Author : [Rashmy Bharadawaj]
/// Exception/Error handling : Structured Exception Handling Macros (Defined in Macro.h) 
/// Assumptions : 
//  Function parameters : 
/// @param[in]  dwConfigurationID	 - The Configuration ID of the Metadata file to Lookup
/// @param[out] *pbyMetadata		 - The Metadata buffer
/// @return		CMMSTATUS			 - Enumerated Status Code (Defined in Global.h)
//  Modification History :
//  Date   Modifications
//  ----   -------------
//  7/15/2004  Created
//*****************************************************************************************/

CMMSTATUS CMemoryManager::GetMetadataFile(DWORD dwConfigurationID, BYTE **pbyMetadata) {
	BEGIN__EXCEPTION__BLOCK__EX

	/**Basic Validation*/
if(dwConfigurationID < 0)
RETURN__FAILURE__EX(CSTATUS_INVALID_CONFIGURATION)

CHECK_FOR_NULL(pbyMetadata)

/**Critical Code Starts*/
m_csMetadataSync.lock();
bMetadataCS = TRUE;

/**Lookup the configuration record*/
CONFIGMETADATA_MAP::iterator ConfigurationIterator;

ConfigurationIterator = m_mapSystemMetadataLookup.finin

/// @file 
/// ****************************************************************
/// Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Configuration Manager
/// @n Filename: Macro.h
/// @n Desc:	 Macros used by modules in CMM
///
//  ****************************************************************
//  Revision History
//  ****************************************************************
//  $Log[4]:
// 11  Stability Project 1.8.1.1  7/2/2011 4:58:27 PM Hemant(HAIL) 
//  Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
// 10  Stability Project 1.8.1.0  7/1/2011 4:26:37 PM Hemant(HAIL) 
//  Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
// 9 V6 Firmware 1.8  9/14/2005 12:39:44 PM Shyam (HTSL) 
//  Removed ALIGN_4_BYTE macro, instaed used from conversion.h.
// 8 V6 Firmware 1.7  9/13/2005 3:59:26 PM  Andy Kassell 
//  Don't debug trace to file
//  $
//
//  ****************************************************************
/******************************************************************************************
  COPYRIGHT (c) 2004
 HONEYWELL INC.,
  ALL RIGHTS RESERVED
  This software is a copyrighted work and/or information protected
  as a trade secret. Legal rights of Honeywell Inc. in this
  software is distinct from ownership of any medium in which the
  software is embodied. Copyright or trade secret notices included
  must be reproduced in any copies authorized by Honeywell Inc.
  The information in this software is subject to change without
  notice and should not be considered as a commitment by Honeywell
  Inc.
******************************************************************************************/

#ifndef __MACRO_H_
#define __MACRO_H_
#include <stdint.h>
#include <QtGlobal>
typedef char CHAR;
typedef unsigned char UINT8;
typedef unsigned char TV_BOOL;
typedef wchar_t WCHAR;
typedef long __int64;
typedef bool BOOL, BOOLEAN;
typedef BOOL *PBOOL;
typedef char *_TCHAR;
typedef const char *PCSTR;
typedef const short SHORT;
typedef int INT32, *LPINT, *INT_PTR;
typedef unsigned int UINT32;
typedef unsigned short USHORT;
typedef unsigned short UINT16;
typedef unsigned long ULONG, *PULONG;
typedef ulong ULONG, DWORD, *DWORD_PTR, *PDWORD, *LPDWORD;
typedef uchar UCHAR;
typedef qint64 LONGLONG;
typedef unsigned int UINT, *UINT_PTR;
typedef quint64 ULONGLONG;
typedef wchar_t WCHAR;
typedef unsigned int WORD, *PWORD;
typedef long LONG;
typedef float FLOAT;
typedef  void* HLOCAL;
typedef char* LPTR;
#define OutputDebugString(x) printf(x)
// TODO: Validate this
#define LocalFree(y) malloc(sizeof(y))
#define LocalSize(y) sizeof(y)
#define LocalAlloc(x,y) x = malloc(y)

typedef unsigned char byte, BYTE, *PBYTE, *LPBYTE;
typedef char TCHAR; //LTTSR

#define TRACE_CMM  0x00000002
#define VARIABLE_BASE 50000 //50000 onwards may 20 of them will be used
#define CMM_qDebugR_MODE TRACE_CMM

const short REF_UNDTERMINED_DATATYPE = -3;
const short REF_UNION = -2;
const short REF_STRUCT = -1;
const short REF_TV_BOOL = 1;
const short REF_BYTE = 2;
const short REF_CHAR = 3;
const short REF_SHORT = 4;
const short REF_USHORT = 5;
const short REF_BUSHORT = 6;
const short REF_FLOAT = 7;
const short REF_DOUBLE = 8;
const short REF_WORD = 9;
const short REF_DWORD = 10;
const short REF_UCHAR = 11;
const short REF_BUCHAR = 12;
const short REF_LONG = 13;
const short REF_ULONG = 14;
const short REF_BULONG = 15;
const short REF_WCHAR = 16;
const short REF_TCHAR = 17;
const short REF_LONGLONG = 18;
const short REF_ULONGLONG = 19;

const short FILENAME_LEN = 40;
const short STR_LEN = 16;
typedef struct _Metadata_Header {
  wchar_t szFilename[FILENAME_LEN];
  WORD wVerNo;
  WORD wSize;
} Metadata_Header, *PMetadata_Header;
// TODO : indexOf alternative for GetLastError
#define GetLastError() 1

#define LOG_ERR
#define LOG_WRN
#ifdef UNDER_CE
	#define GETPROCADDRESSSTRING(x) _T(x)
#else
	#define GETPROCADDRESSSTRING(x) x 
#endif
#define LOG_INFO
#define BEGIN__EXCEPTION__BLOCK\
	CMMSTATUS sReturnValue = CSTATUS_OK;\
	try \
	{

#define	END__EXCEPTION__BLOCK\
		return sReturnValue; \
	}

#define RETURN__FAILURE(x)\
	{\
  LOG_ERR(TRACE_CMM,("(Error) - Exeption Code : %d"),x);\
		return x;\
	}

#define	CATCH__EXCEPTION\
	catch (CMMSTATUS x)\
	{ \
  LOG_ERR(TRACE_CMM,("(Exception) - Exeption Code : %d"),x);\
		return x;\
	}\
	catch(...) \
	{ \
  LOG_ERR(TRACE_CMM,("(Exception) - Exeption Code : %d"),GetLastError());\
  return CSTATUS_EXCEPTION;\
	}

#define	THROW__EXCEPTION(x) \
	throw x;

//Memory Manager specific macros handling critical section cleanup

#define BEGIN__EXCEPTION__BLOCK__EX\
  BOOL bMetadataCS = false;\
  BOOL bConfigCS = false;\
	try \
	{

#define	END__EXCEPTION__BLOCK__EX\
  if(bMetadataCS) m_csMetadataSync.lock();\
  if(bConfigCS) m_csConfigurationSync.lock();\
		return CSTATUS_OK; \
	}

#define RETURN__FAILURE__EX(x)\
	{\
  if(bMetadataCS) m_csMetadataSync.lock();\
  if(bConfigCS) m_csConfigurationSync.lock();\
  LOG_WRN(TRACE_CMM,("Error Code : %d"),x);\
		return x;\
	}



#define	CATCH__EXCEPTION__EX\
	catch (CMMSTATUS x)\
	{ \
  if(bMetadataCS) m_csMetadataSync.lock();\
  if(bConfigCS) m_csConfigurationSync.lock();\
  LOG_ERR(TRACE_CMM,("Exception Code : %d"),x);\
		return x;\
	}\
	catch(...) \
	{ \
  if(bMetadataCS) m_csMetadataSync.lock();\
  if(bConfigCS) m_csConfigurationSync.lock();\
  LOG_ERR(TRACE_CMM,("Exception Code : %d"),GetLastError());\
  return CSTATUS_EXCEPTION;\
	}

//Memory Manager and VersionConverter error checking
#define SAFE_CALL(x,y) if(x) y;

#define CHECK_FUNCTION(x) sReturnValue = x; \
	if(sReturnValue != CSTATUS_OK) \
			RETURN__FAILURE(sReturnValue); 

// TODO insert  LocalFree(y) below 195
#define CHECK_FUNCTION_EX(x,y) sReturnValue = x; \
	if(sReturnValue != CSTATUS_OK) \
	{\
		if(y)\
		RETURN__FAILURE(sReturnValue); \
	}

#define CHECK_FOR_NULL(x) if( x == NULL) \
		throw CSTATUS_POINTER; 

#define DATATYPE_FLOAT(x) (x == REF_FLOAT)  ? true:false
#define DATATYPE_DOUBLE(x) (x == REF_DOUBLE) ? true:false

#define DATATYPE_NUMERIC(x)\
	(  (x == REF_UCHAR)  || (x == REF_BYTE) ||(x == REF_LONGLONG)\
	|| (x == REF_ULONGLONG)|| (x == REF_SHORT)|| (x == REF_USHORT)\
	|| (x == REF_WORD) || (x == REF_DWORD)|| (x == REF_LONG)\
	|| (x == REF_ULONG)  || (x == REF_TV_BOOL)) ? true:false

#define DATATYPE_CHAR(x)\
	((x == REF_CHAR) || (x == REF_WCHAR) || (x == REF_TCHAR)) ? true:false

#define CHECK_BITTYPE(x)\
	((x == REF_BUSHORT) ||(x == REF_BULONG) ||(x == REF_BUCHAR)) ? true:false

#define INSTANCE_ID(x) (x & 0x7fff)
enum enumWCLASS {
  classStandard = 1, classUnique, classStruct, classUnion, classStructmember, classUnionmember, classAutoInitmember
};

#endif;

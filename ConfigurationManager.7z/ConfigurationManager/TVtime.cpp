/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Utilities
/// @n Filename: TVtime.cpp
/// @n Desc:	 Common time routines
///
//  ****************************************************************
//  Revision History
//  ****************************************************************
//  $Log[4]:
// 28  Stability Project 1.23.1.3 7/2/2011 5:02:13 PM Hemant(HAIL) 
//  Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
// 27  Stability Project 1.23.1.2 7/1/2011 4:39:03 PM Hemant(HAIL) 
//  Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
// 26  Stability Project 1.23.1.1 3/17/2011 3:20:52 PM  Hemant(HAIL) 
//  Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
// 25  Stability Project 1.23.1.0 2/15/2011 3:04:07 PM  Hemant(HAIL) 
//  File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
//  $
//
//  ****************************************************************

#include <QDateTime>
#include "TVtime.h"

static QLocale LOCALE_USER_DEFAULT(QLocale::system());
/* Magic number explanation:
 Both epochs are Gregorian. 1970 - 1601 = 369. Assuming a leap
 year every four years, 369 / 4 = 92. However, 1700, 1800, and 1900
 were NOT leap years, so 89 leap years, 280 non-leap years.
 89 * 366 + 280 * 365 = 134744 days between epochs. Of course
 60 * 60 * 24 = 86400 seconds per day, so 134744 * 86400 =
 11644473600 = SECS_BETWEEN_EPOCHS.

 This result is also confirmed in the MSDN documentation on how
 to convert a time_t value to a win32 FILETIME.
 */
__int64 SECS_BETWEEN_EPOCHS = 11644473600;

__int64 ms10ths_TO_MICROS = 100;
__int64 ms10ths_TO_100NS = 1000;
__int64 SECS_TO_ms10ths = 10000;
__int64 SECS_TO_MICROS = 1000000; /* 10^6 */
__int64 SECS_TO_100NS = 10000000; /* 10^7 */

__int64 NS100_BETWEEN_EPOCHS = SECS_BETWEEN_EPOCHS * SECS_TO_100NS;

/// Static initialisation
const ULONG CTVtime::m_ulMAX_TIME_DATE_INC_MS_BUFF_LEN = 35;
const ULONG CTVtime::m_ulMAX_SHORT_TIME_DATE_BUFF_LEN = 25;

//**********************************************************************
///
/// Convert TV5time to internal CTVtime form (microseconds since Jan 1st 1970)
///
/// @param[in]	t - pointer to TV5Time 
/// @return		microseconds
/// 
//**********************************************************************
__int64 CTVtime::TV5TimeToMicroSecs(TV5Time *t) {
	// TV5TIME FORMAT
	// 2.5555 stored as 2  and 5555
	//  -2.5555 stored as  -2  and  -5555
	//  -0.1234 stored as 0  and  -1234

	__int64 microSecs;

	if (t->Secs == 0) {
		microSecs = t->Fracs;
		microSecs *= ms10ths_TO_MICROS; // convert mstenths to microseconds
	} else // some seconds, +ve or -ve
	{
		microSecs = t->Secs;
		microSecs *= SECS_TO_ms10ths; // secs to mstenths

		if (t->Secs < 0) //if -ve will have -ve fracs : need to subtract!
			microSecs -= t->Fracs; // 'add on' -ve
		else
			microSecs += t->Fracs; // or add on +ve

		microSecs *= ms10ths_TO_MICROS; // convert mstenths to microseconds
	}

	return microSecs;
}

//**********************************************************************
///
/// Convert internalTime to SYSTEMTIME
///
/// @param[out]	st - pointer to SYSTEMTIME to fill
/// @return		none
/// 
//**********************************************************************
void CTVtime::InternaltoSYSTEMTIME(SYSTEMTIME *st)const {
  // Extract components and populate the SYSTEMTIME structure
  const QDateTime dateTime = QDateTime::currentDateTime();
  st->wYear = static_cast<WORD>(dateTime.date().year());
  st->wMonth = static_cast<WORD>(dateTime.date().month());
  st->wDay = static_cast<WORD>(dateTime.date().day());
  st->wHour = static_cast<WORD>(dateTime.time().hour());
  st->wMinute = static_cast<WORD>(dateTime.time().minute());
  st->wSecond = static_cast<WORD>(dateTime.time().second());
  st->wMilliseconds = static_cast<WORD>(dateTime.time().msec());
}

//**********************************************************************
///
/// Convert SYSTEMTIME to microseconds since 1970 and store as our internal time
///
/// @param[in,out]	st - SYSTEMTIME reference
/// @return		none
/// 
//**********************************************************************
void CTVtime::SYSTEMTIMEtoInternal(SYSTEMTIME &st) {
  // Convert SYSTEMTIME to FILETIME without using bias details etc.

	// here use LARGE_INTEGER instead of FILETIME struct.
  QDateTime dateTime(QDate(st.wYear, st.wMonth, st.wDay),
   QTime(st.wHour, st.wMinute, st.wSecond, st.wMilliseconds));

  // Convert QDateTime to epoch time in milliseconds
  internalTime = dateTime.toMSecsSinceEpoch();

	internalTime -= NS100_BETWEEN_EPOCHS; // take off our 1970 time as a filetime int64
// convert to microseconds.

	// this is now in microseconds, and effectively the same as a TV5Time, except with
	// a much bigger range. (and more accuracy)
}

//**********************************************************************
///
///	CTVtime default Constructor
///
//**********************************************************************
CTVtime::CTVtime() {
	internalTime = 0; // 1st Jan 1970.
}

//**********************************************************************
///
/// CTVtime Copy Constructor taking TV5Time
///
/// @param[in]	t - CTVtime reference
/// 
//**********************************************************************
CTVtime::CTVtime(const CTVtime &t) {
	// copy internal values
	internalTime = t.internalTime;
}

//**********************************************************************
///
/// CTVtime Constructor taking micorseconds
///
/// @param[in]	microSecs - Microseconds
/// 
//**********************************************************************
CTVtime::CTVtime(__int64 microSecs) {
	internalTime = microSecs;
}

//**********************************************************************
///
/// CTVtime Constructor TV5Time reference
///
/// @param[in]	t - TV5Time reference
/// 
//**********************************************************************
CTVtime::CTVtime(TV5Time &t) {
	internalTime = TV5TimeToMicroSecs(&t);
}

//**********************************************************************
///
/// CTVtime Constructor TV5Time pointer
///
/// @param[in]	t - TV5Time pointer
/// 
//**********************************************************************
CTVtime::CTVtime(TV5Time *t) {
	internalTime = TV5TimeToMicroSecs(t);
}

//**********************************************************************
///
/// CTVtime Constructor taking V4 Time
///
/// @param[in]	ptv4time - pointer to V4 time struct 
/// 
//**********************************************************************
CTVtime::CTVtime(time_grad_2 *ptv4time) {
  SYSTEMTIME st;
	st.wSecond = ptv4time->Time.sec;
	st.wMinute = ptv4time->Time.min;
	st.wHour = ptv4time->Time.hour;
	st.wDay = ptv4time->Time.day;
	st.wMonth = ptv4time->Time.month; // 1 to 12
	st.wYear = ptv4time->Time.year + 1994; // birth of V4 1994
	st.wMilliseconds = 0;
	st.wDayOfWeek = 0;

  // Convert SYSTEMTIME to our internalTime
	SYSTEMTIMEtoInternal(st);

	// now add on the fractions of a second
	internalTime += ptv4time->Header.frac_secs * 62500; //number of 1/16 sec intervals.
}
//**********************************************************************
///
/// Effectively copies the internal time of another CTVtime structure to this one
///
/// @param[in]	timeToCopy - the time we wish to copy/set to
/// 
//**********************************************************************
void CTVtime::SetTime(const CTVtime &timeToCopy) {
	internalTime = timeToCopy.internalTime;
}

//**********************************************************************
///
/// CTVtime Constructor taking V4 message time
///
/// @param[in]	ptv4time -pointer to V4 message time struct
/// 
//**********************************************************************
CTVtime::CTVtime(realtime_2 *ptv4time) {
  SYSTEMTIME st;
	st.wSecond = ptv4time->Time.sec;
	st.wMinute = ptv4time->Time.min;
	st.wHour = ptv4time->Time.hour;
	st.wDay = ptv4time->Time.day;
	st.wMonth = ptv4time->Time.month; // 1 to 12
	st.wYear = ptv4time->Time.year + 1994; // birth of V4 1994
	st.wMilliseconds = 0;
	st.wDayOfWeek = 0;

  // Convert SYSTEMTIME to our internalTime
	SYSTEMTIMEtoInternal(st);

	// now add on the fractions of a second...
	internalTime += ptv4time->frac_secs * 62500; //number of 1/16 sec intervals.
}

//**********************************************************************
///
/// CTVtime Constructor V4 time sync - used by all recorders to decode Trendbus time sync broadcasts
///
/// @param[in]	ptv4time -pointer to V4 time sync struct
/// 
//**********************************************************************
CTVtime::CTVtime(ltime_2 *ptv4time) {
	UCHAR intel[4];

	// time will initially be in V4 recorder (motorola) format.
	// re-arrange
	intel[0] = ((UCHAR*) ptv4time)[3];
	intel[1] = ((UCHAR*) ptv4time)[2];
	intel[2] = ((UCHAR*) ptv4time)[1];
	intel[3] = ((UCHAR*) ptv4time)[0];

	ptv4time = (ltime_2*) intel; // now point to our local re-aranged copy

  SYSTEMTIME st;
	st.wSecond = ptv4time->sec;
	st.wMinute = ptv4time->min;
	st.wHour = ptv4time->hour;
	st.wDay = ptv4time->day;
	st.wMonth = ptv4time->month; // 1 to 12
	st.wYear = ptv4time->year + 1994; // birth of V4 1994
	st.wMilliseconds = 0; // only to nearest second (no fracs broadcast)
	st.wDayOfWeek = 0;

  // Convert SYSTEMTIME to our internalTime
	SYSTEMTIMEtoInternal(st);
}

//**********************************************************************
///
/// Set this CTVtime to the local system time
///
//**********************************************************************
void CTVtime::TimeNow() {

	/*	how we used to do it:
 SYSTEMTIME st;
	 struct tm now;
	 GetLocalTime(&st); // gets the time from the O/S
	 // The local time is the time from the PC with the timezone selected in control panel.
	 // Also could have daylight saving enabled.

	 // we now put this into a tm structure, and make a time_t out of it.
	 // This will create a time with the UK timezone (no bias) and no daylight saving applied.
	 // Thus data recorded in the USA at 8 AM will be graphed at the same time as data 
	 // recorded in Australia at 8 AM.
	 
	 now.tm_sec=st.wSecond;	// seconds after the minute - [0,59] 
	 now.tm_min=st.wMinute;	// minutes after the hour - [0,59] 
	 now.tm_hour=st.wHour;	// hours since midnight - [0,23] 
	 now.tm_mday=st.wDay;	// day of the month - [1,31] 
	 now.tm_mon=st.wMonth-1;	// months since January - [0,11] 
	 now.tm_year=st.wYear-1900;  // years since 1900  still ok in year 2000 !! 
	 now.tm_wday=0;			// days since Sunday - [0,6] 
	 now.tm_yday=0;			// days since January 1 - [0,365] 
	 now.tm_isdst=0;			// daylight savings time flag 

	 Secs=mktime(&now);  
	 Fracs=st.wMilliseconds*10;
	 */

  SYSTEMTIME st;

  //TODO : indexOf qt alternative to get time
  //QDateTime st = QDateTime::currentDateTime();
//	GetLocalTime(&st);

  // Convert SYSTEMTIME to our internalTime
	SYSTEMTIMEtoInternal(st);

	// this is now in microseconds, and effectively the same as a TV5Time, except with
	// a much bigger range. (and more accuracy)		  
}

//**********************************************************************
///
/// Checks to see if this CTVtime is within mstenths of t2
///
/// @param[in]	t2 - TV5Time reference 
/// @param[in]	mstenths - millisecond tenths (up to 9999)
/// @return		T/F (T if it is within mstenths (either way) of t2)
/// 
//**********************************************************************
BOOL CTVtime::TimeEqApprox(TV5Time &t2, ULONG mstenths) {
	__int64 microSecs = mstenths;
	microSecs *= ms10ths_TO_MICROS; //convert mstenths to microseconds

	__int64 diff = internalTime - TV5TimeToMicroSecs(&t2);

	if (diff < 0)
		diff = -diff; // handle -ve difference

	return (diff < microSecs);
}

//**********************************************************************
///
/// Convert CTVtime to TV5Time
///
/// @return	TV5Time (will be all 0 if out of range)
/// 
//**********************************************************************
TV5Time CTVtime::GetTV5Time() {
	// TV5TIME FORMAT
	// 2.5555 stored as 2  and 5555
	//  -2.5555 stored as  -2  and  -5555
	//  -0.1234 stored as 0  and  -1234

	TV5Time result;
	__int64 seconds = internalTime / SECS_TO_MICROS;

	result.Secs = (long) seconds;
	if (seconds != result.Secs) // check to see if still the same (looking for overflow/underflow)
			{
		result.Secs = 0;
		result.Fracs = 0;
		return result; // out of range - all 0
	}

	__int64 fracs = internalTime / ms10ths_TO_MICROS; // to mstenths
	result.Fracs = (short) (fracs % SECS_TO_ms10ths);

	return result;
}

//**********************************************************************
///
/// Convert CTVtime to TV5Time
///
/// @param[in]	t - pointer to TV5Time struct to fill (all 0 if out of range)
/// @return		none
/// 
//**********************************************************************
void CTVtime::GetTV5Time(TV5Time *t) {

	// TV5TIME FORMAT
	// 2.5555 stored as 2  and 5555
	//  -2.5555 stored as  -2  and  -5555
	//  -0.1234 stored as 0  and  -1234

	__int64 seconds = internalTime / SECS_TO_MICROS;

	t->Secs = (long) seconds;
	if (seconds != t->Secs) // check to see if still the same (looking for overflow/underflow)
			{
		t->Secs = 0;
		t->Fracs = 0;
		return; // out of range - all 0
	}

	__int64 fracs = internalTime / ms10ths_TO_MICROS; // to mstenths
	t->Fracs = (short) (fracs % SECS_TO_ms10ths);
}

//**********************************************************************
///
/// Convert CTVtime to a SYSTEMTIME structure
///
/// @param[in]	systemtime - pointer to SYSTEMTIME to fill
/// @return		none
/// 
//**********************************************************************
void CTVtime::GetSYSTEMTIME(SYSTEMTIME *systemtime) {
	InternaltoSYSTEMTIME(systemtime);
}

//**********************************************************************
///
/// Gets the internal value of this CTVtime
///
/// @return		seconds
/// 
//**********************************************************************
__int64 CTVtime::GetSeconds() {
	return internalTime / SECS_TO_MICROS;
}

//**********************************************************************
///
/// Gets the internal value of this CTVtime
///
/// @return		microseconds
/// 
//**********************************************************************
__int64 CTVtime::GetMicroSecs() {
	return internalTime;
}

//**********************************************************************
///
/// Gets the internal value of this CTVtime as mstenths
///
/// @return		mstenths
/// 
//**********************************************************************
__int64 CTVtime::GetmsTenths() {
	return internalTime / ms10ths_TO_MICROS;
}

//**********************************************************************
///
/// Extracts the month number and year from a CTVtime
///
/// @return		packed Month and Year mmyyy  (yyy=098,099,100,101,102 etc)
/// 
//**********************************************************************
USHORT CTVtime::GetMonthAndYear() {

	/* how it was done:	
	 struct tm* thetime;
	 thetime=gmtime(&t1->Secs);
	 res[0]=thetime->tm_mon; // month is 0-11
	 res[1]=thetime->tm_year;  // years since 1900
	 */

	UCHAR res[2];
  SYSTEMTIME st;
	InternaltoSYSTEMTIME(&st);
	res[0] = st.wMonth - 1; // make it 0-11
	res[1] = st.wYear - 1900; // make it years since 1900

	return *((USHORT*) res);
}

//**********************************************************************
///
/// sets CTVtime to the earliest time in the month specified
///
/// @param[in]	mmyyy - packed Month and Year (mmyyy)
/// @return		none
/// 
//**********************************************************************
void CTVtime::SetFirstTimeInMonth(USHORT mmyyy) {
	// set up a time based on the month and year, and 1st day of the month, 00:00:00 hours
  SYSTEMTIME st;
	st.wSecond = 0;
	st.wMinute = 0;
	st.wHour = 0;
	st.wDay = 1;  // 1st day of the month 
	st.wMonth = ((UCHAR*) &mmyyy)[0] + 1;  // make it 1-12
	st.wYear = ((UCHAR*) &mmyyy)[1] + 1900; // add 1900 to get full year
	st.wMilliseconds = 0;
	st.wDayOfWeek = 0;

	SYSTEMTIMEtoInternal(st); // convert and store as internalTime	
}

//**********************************************************************
///
/// Extracts the number of days in the Month
///
/// @param[in]	mmyyy - packed Month and Year (mmyyy)
/// @return		Days in month 28-31
/// 
//**********************************************************************
USHORT CTVtime::GetDaysInMonth(USHORT mmyyy) {
	// this function does not use the internal CTVtime time
	// it is included here for completeness

	int monthdays[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

	int year = ((UCHAR*) &mmyyy)[1]; // years since 1900
	int month = ((UCHAR*) &mmyyy)[0]; // months since january

	year += 1900; // make into full year

	if (year % 4 == 0 && year % 100 != 0 || year % 400 == 0)
		monthdays[1] = 29; // change feb for leap year.

	return monthdays[month];
}
//**********************************************************************
//	const USHORT CTVtime::GetDaysInMonth(	const USHORT usMONTH,
//											const USHORT usYEAR )
///
/// Method that retrieves the number of days in a month 
///
/// @param[in]	const USHORT usMONTH - Month 1 - 12
/// @param[in]	const USHORT usYEAR - Year 2005+
///
/// @return		Days in month 28-31
/// 
//**********************************************************************
const USHORT CTVtime::GetDaysInMonth(const USHORT usMONTH, const USHORT usYEAR) {
	// this function does not use the internal CTVtime time
	// it is included here for completeness

	USHORT usMonthDays[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

	if (((usYEAR % 4) == 0) && ((usYEAR % 100) != 0) || ((usYEAR % 400 == 0))) {
		usMonthDays[1] = 29; // change feb for leap year.
	}

	return usMonthDays[usMONTH - 1];
}

//**********************************************************************
///
/// Extracts the Hour CTVtime
///
/// @return		Hour of day 
/// 
//**********************************************************************
USHORT CTVtime::GetHour() {
  SYSTEMTIME st;
	InternaltoSYSTEMTIME(&st);
	return st.wHour; // Hour
}

//**********************************************************************
///
/// Extracts the Day of the month from a CTVtime
///
/// @return		Day number (1-31)  
/// 
//**********************************************************************
USHORT CTVtime::GetDay() {
  SYSTEMTIME st;
	InternaltoSYSTEMTIME(&st);
	return st.wDay; // day of the month 1-31
}

//**********************************************************************
///
/// Extracts the Day of the week from a CTVtime
///
/// @return		Day of week (0=Sunday, 1=Monday ..... 6=Saturday)
/// 
//**********************************************************************
USHORT CTVtime::GetDayOfWeek() {
  SYSTEMTIME st;
	InternaltoSYSTEMTIME(&st);
	return st.wDayOfWeek;  // day of the week 0 to 6
}

//**********************************************************************
///
/// Extracts the Month number from a CTVtime
///
/// @return		Month number (0=Jan, 11=Dec)  
/// 
//**********************************************************************
USHORT CTVtime::GetMonth() {
  SYSTEMTIME st;
	InternaltoSYSTEMTIME(&st);
	return st.wMonth - 1;  // subtract 1 here to make the same as before
}

//**********************************************************************
///
/// Extracts the Time of day from a CTVtime as a time Span, From midnight on that day.
///
/// @return		CTVtime containing the time span from 00:00:00 hrs
/// 
//**********************************************************************
CTVtime CTVtime::GetTimeOfDaySpan() {
  SYSTEMTIME st;
	InternaltoSYSTEMTIME(&st);

	// calculate span: number of microseconds since midnight.
	CTVtime span;
	span.internalTime = (((__int64 ) (st.wHour * 60 + st.wMinute) * 60 + st.wSecond) * 1000 + st.wMilliseconds) * 1000;
	return span;
}

//**********************************************************************
///
/// Set the CTVTime to be a time span from 00:00:00.000000 hrs
///
/// @param[in]	Hours	- Hours of timespan
/// @param[in]	Minutes - Minutes of timespan
/// @param[in]	Secs	- Seconds of timespan
/// @param[in]	milliSec - Milliseconds of timespan
/// @param[in]	microSec - Microseconds of timespan
/// @return		None
/// 
//**********************************************************************
void CTVtime::SetTimeSpan(USHORT Hours, USHORT Minutes, USHORT Secs, USHORT milliSec, ULONG microSec) //milliSec=0, microSec=0
		{

	// set the span: number of microseconds since midnight.

	internalTime = (((__int64 ) (Hours * 60 + Minutes) * 60 + Secs) * 1000 + milliSec) * 1000 + microSec;
}

//**********************************************************************
//	const QString TimeToStringShort( ) const
///
/// Method that gets the time as a string
///
/// @return		Thne time
/// 
//**********************************************************************
/*const QString CTVtime::TimeToStringShort( ) const
 {
 QString strTime( __TEXT("") );
 TCHAR tcaTimeBuff[ m_ulMAX_SHORT_TIME_DATE_BUFF_LEN ];
 TimeToStringShort( tcaTimeBuff );
 strTime.asprintf( __TEXT("%s"), tcaTimeBuff );

 return strTime;
 }

 //**********************************************************************
 //	const QString DateToStringShort( ) const
 ///
 /// Method that gets the date as a string
 ///
 /// @return		The time in the format - ddd mmm yy
 /// 
 //**********************************************************************
 const QString CTVtime::DateToStringShort( ) const
 {
 QString strDate( __TEXT("") );
 TCHAR tcaDateBuff[ m_ulMAX_SHORT_TIME_DATE_BUFF_LEN ];
 DateToStringShort( tcaDateBuff, static_cast< int >( m_ulMAX_SHORT_TIME_DATE_BUFF_LEN ) );
 strDate.asprintf( __TEXT("%s"), tcaDateBuff );

 return strDate;
 }

 //**********************************************************************
 //	const QString DateToString( ) const
 ///
 /// Method that gets the date as a string
 ///
 /// @return		The time in the format - ddd mmm yyyy
 /// 
 //**********************************************************************
 const QString CTVtime::DateToString( ) const
 {
 QString strDate( __TEXT("") );
 TCHAR tcaDateBuff[ m_ulMAX_SHORT_TIME_DATE_BUFF_LEN  + 2 ];
 DateToString( tcaDateBuff, static_cast< int >( m_ulMAX_SHORT_TIME_DATE_BUFF_LEN + 2 ) );
 strDate.asprintf( __TEXT("%s"), tcaDateBuff );

 return strDate;
 }
 */
//**********************************************************************
///
/// Converts the internal time to a string
///
/// @param[in]	buff - pointer to buffer to fill (must be at least 35 characters)
/// @return		None
/// 
//**********************************************************************
void CTVtime::TimeToString(TCHAR *buff, int length) const {

//  ddd MMM dd HH:mm:ss.1234 yyyy full string format

// How it was done:
//  ctime exactly 26 characters and has the form:
//  Wed Jan 02 02:03:55 1980\n\0

//	However, to get use locale, we need strftime	
	/*	
	 char tbuff[30];
	 struct tm* xtime;
	 int fracspos;
	 
	 xtime=gmtime(&t1->Secs);
	 strftime(tbuff,30,"%a %b %d %H:%M:%S %Y",xtime);
	 fracspos=strlen(tbuff)-5;
	 tbuff[fracspos]=0;

	 sprintf(buff,"%s.%4.4d %s",tbuff, t1->Fracs, &tbuff[fracspos+1]);
	 */

  // make our internal time into a SYSTEMTIME
  QLocale LOCALE_USER_DEFAULT(QLocale::system());
  SYSTEMTIME st;
	LARGE_INTEGER li;
	li.QuadPart = internalTime;
	li.QuadPart *= 10; // convert to 100ns
	li.QuadPart += NS100_BETWEEN_EPOCHS; // add on our 1970 time 

  //FileTimeToSystemTime((FILETIME*) &(li.u), &st);

  if (GetDateasprintf(LOCALE_USER_DEFAULT, st, //  ddd MMM dd HH:mm:ss.1234 yyyy  full string format
  "ddd MMM dd   yyyy",  // leave space for time to be inserted
			buff, 50) > 18) {
  int timepos = strlen(buff) - 18; // see above for this calc. (start of HH:mm:ss)

  GetTimeasprintf(LOCALE_USER_DEFAULT, st, "HH':'mm':'ss", &buff[timepos], 9);

#if _MSC_VER < 1400 
  ///@Todo asprintf(&buff[timepos + 8], ".%4.4d", (li.QuadPart % SECS_TO_100NS) / 1000);
#else
		_stprintf_s(&buff[timepos+8], length - (timepos+8), __TEXT(".%4.4d"),(li.QuadPart%SECS_TO_100NS)/1000);
#endif

		buff[timepos + 13] = ' '; // replace the NULL with a space
	}

}

//**********************************************************************
///
/// Converts the internal time to a string with no fracs
///
/// @param[in]	buff - pointer to buffer to fill (must be at least 26 characters)
/// @return		None
/// 
//**********************************************************************
void CTVtime::TimeToStringNoFracs(TCHAR *buff) const {
  // make our internal time into a SYSTEMTIME

  SYSTEMTIME st;
	InternaltoSYSTEMTIME(&st);

	// shorter format - no fracs and year first

  if (GetDateasprintf(LOCALE_USER_DEFAULT, st, //  ddd MMM dd yyyy HH:mm:ss  full string format @todo check size of French months
  "ddd MMM dd yyyy ",  // date part
			buff, 50) > 0) {
  int timepos = strlen(buff); // find end of string to put time part

  GetTimeasprintf(LOCALE_USER_DEFAULT, st, "HH':'mm':'ss", &buff[timepos], 9);
	}
}

//**********************************************************************
///
/// Converts the internal time to a date first string according to the passed in date & time format picture string
///
/// @param[in]	dateasprintf - NULL if non required, otherwise pointer to a format picture string
///					to use to form the date string (as per GetDateasprintf).
/// @param[in]	timeasprintf - NULL if not required, otherwise pointer to a format picture string
///					to use to form the time string (as per GetTimeasprintf).
/// @param[in]	buff - pointer to buffer to fill (must be at least 26 characters)
/// @return		None
/// 
//**********************************************************************
void CTVtime::TimeTemplateDateFirstString(TCHAR const *dateasprintf, TCHAR const *timeasprintf, TCHAR *buff) const {
  // make our internal time into a SYSTEMTIME
  SYSTEMTIME st;
	InternaltoSYSTEMTIME(&st);
	int timepos = 0;

	if (dateasprintf != NULL) {
  if (GetDateasprintf(LOCALE_USER_DEFAULT, st, //  ddd MMM dd yyyy HH:mm:ss  full string format @todo check size of French months
				dateasprintf,  // date part 
				buff, 50) > 0) {
  timepos = strlen(buff); // find end of string to put time part
		}

	}

	if (timeasprintf != NULL) {
  GetTimeasprintf(LOCALE_USER_DEFAULT, st, timeasprintf, &buff[timepos], 9);
	}
}

//**********************************************************************
///
/// Converts the internal time to a string with no fracs
///
/// @param[in]	buff - pointer to buffer to fill (must be at least 26 characters)
/// @return		None
/// 
//**********************************************************************
void CTVtime::TimeToMinsSecsString(TCHAR *buff) const {
  // make our internal time into a SYSTEMTIME
  SYSTEMTIME st;
	InternaltoSYSTEMTIME(&st);

  GetTimeasprintf(LOCALE_USER_DEFAULT, st, "mm':'ss", buff, 9);
}

//**********************************************************************
///
/// Converts the internal time to a string with no fracs
///
/// @param[in]	buff - pointer to buffer to fill (must be at least 26 characters)
/// @return		None
/// 
//**********************************************************************
void CTVtime::TimeToHourMinsSecsString(TCHAR *buff) const {
  // make our internal time into a SYSTEMTIME
  SYSTEMTIME st;
	InternaltoSYSTEMTIME(&st);

  GetTimeasprintf(LOCALE_USER_DEFAULT, st, "HH':'mm':'ss", buff, 9);
}



//**********************************************************************
///
/// Converts the internal time to a string - no fractions or year
///
/// @param[in]	buff - pointer to buffer to fill (at least 25 characters)
/// @return		None
/// 
//**********************************************************************
void CTVtime::TimeToStringShort(TCHAR *buff) const {

	//  ddd MMM dd HH:mm:ss string format

	/* How it was done:
	 struct tm* xtime;
	 xtime=gmtime(&t1->Secs);
	 strftime(buff,30,"%a %b %d %H:%M:%S",xtime);  // short format - no fracs or year
	 */

  // make our internal time into a SYSTEMTIME
  SYSTEMTIME st;
	InternaltoSYSTEMTIME(&st);

	// short format - no fracs or year

  if (GetDateasprintf(LOCALE_USER_DEFAULT, st, //  ddd MMM dd HH:mm:ss full string format
  "ddd MMM dd ",  // date part
			buff, 50) > 0) {
  int timepos = strlen(buff); // find end of string to put time part

  GetTimeasprintf(LOCALE_USER_DEFAULT, st, "HH':'mm':'ss", &buff[timepos], 9);
	}
}

//**********************************************************************
///
/// Converts the internal time to a string - no fractions or year
///
/// @param[in]	buff - pointer to buffer to fill (at least 25 characters)
/// @return		None
/// 
//**********************************************************************
void CTVtime::TimeDateToStringShort(TCHAR *buff) const {

	//  ddd MMM dd HH:mm:ss string format

	/* How it was done:
	 struct tm* xtime;
	 xtime=gmtime(&t1->Secs);
	 strftime(buff,30,"%a %b %d %H:%M:%S",xtime);  // short format - no fracs or year
	 */

  // make our internal time into a SYSTEMTIME
  SYSTEMTIME st;
	InternaltoSYSTEMTIME(&st);

	// short format - no fracs or year

  if (GetDateasprintf(LOCALE_USER_DEFAULT, st, //  dd MMM yy HH:mm:ss full string format
  "dd MMM ",  // date part
			buff, 50) > 0) {
  int timepos = strlen(buff); // find end of string to put time part

  GetTimeasprintf(LOCALE_USER_DEFAULT, st, "HH':'mm':'ss", &buff[timepos], 9);
	}
}

//**********************************************************************
///
/// Method that gets the date as a string
///
/// @param[out]	buff - pointer to buffer to fill (at least 25 characters)
/// @param[in]	const int iBUFF_LEN - The length of the passed in buffer
/// 
//**********************************************************************
void CTVtime::DateToStringShort(TCHAR *buff, const int iBUFF_LEN) const {

	//  ddd MMM yy string format

  // make our internal time into a SYSTEMTIME

  SYSTEMTIME st;
	InternaltoSYSTEMTIME(&st);

	// short format - no fracs or year

  GetDateasprintf(LOCALE_USER_DEFAULT, st, //  ddd MMM dd HH:mm:ss full string format
  "dd MMM yy",  // date part
			buff, iBUFF_LEN);
}
//**********************************************************************
///
/// Method that gets the date as a string
///
/// @param[out]	buff - pointer to buffer to fill (at least 25 characters)
/// @param[in]	const int iBUFF_LEN - The length of the passed in buffer
/// 
//**********************************************************************
void CTVtime::DateToString(TCHAR *buff, const int iBUFF_LEN) const {

	//  ddd MMM yyyy string format

  // make our internal time into a SYSTEMTIME
  SYSTEMTIME st;
	InternaltoSYSTEMTIME(&st);

  GetDateasprintf(LOCALE_USER_DEFAULT, st,  //  dd MMM yyyy
  "dd MMM yyyy",  // date part
			buff, iBUFF_LEN);
}

//==============================================================================
//	Addition and Subtraction Operator Overloads
//==============================================================================

//**********************************************************************
///
/// Adds a TV5Time to a CTVtime
///
/// @param[in]	t2 - TV5Time reference
/// @return		CTVtime
/// 
//**********************************************************************
CTVtime CTVtime::operator+(TV5Time &t2) {
	//  return a CTVtime with sum
	return CTVtime(internalTime + TV5TimeToMicroSecs(&t2));
}

//**********************************************************************
///
/// Adds a CTVtime to a CTVtime
///
/// @param[in]	t2 - CTVtime reference
/// @return		CTVtime
/// 
//**********************************************************************
CTVtime CTVtime::operator+(CTVtime &t2) {
	//  return a CTVtime with sum
	return CTVtime(internalTime + t2.internalTime);
}

//**********************************************************************
///
/// Adds a SIGNED number of mstenths to a CTVtime
///
/// @param[in]	mstenths - Millisecond tenths
/// @return		CTVtime
/// 
//**********************************************************************
CTVtime CTVtime::operator+(long mstenths) {
	// mstenths CAN ONLY BE UP TO +/- 59.65 hours (eg in an adjust long control)

	__int64 microSecs = mstenths;
	microSecs *= ms10ths_TO_MICROS; //convert mstenths to microseconds

	//  return a CTVtime with sum
	return CTVtime(internalTime + microSecs);
}

//**********************************************************************
///
/// Operator : Adds a number of microseconds (+ve or -ve) to a CTVtime
///
/// @param[in]	microSecs
//**********************************************************************
int CTVtime::GetDateasprintf(
  QLocale locale,
//  int flags,
  const SYSTEMTIME &st,
  QString format,
  char *dateStr,
  int cchDate
)const {
  QDateTime dateTime(QDate(st.wYear, st.wMonth, st.wDay),
   QTime(st.wHour, st.wMinute, st.wSecond, st.wMilliseconds));
  QString formattedDate = locale.toString(dateTime, format);

  if (!formattedDate.isEmpty() && formattedDate.length() < cchDate) {
  // Convert QString to wchar_t and copy to dateStr
 QByteArray bytearray = formattedDate.toUtf8();
 strncpy(dateStr,bytearray.constData(),cchDate);
 dateStr[cchDate-1] = '\0';
  return formattedDate.length() + 1; // Return the actual length, including null-terminator
  }else{
  qDebug(" Buffer is too small or no matching flag");
  }

  
  return 0;
}
//**********************************************************************
/// getDateasprintf 

//**********************************************************************
int CTVtime::GetTimeasprintf(
  QLocale locale,
  SYSTEMTIME &st,
  QString format,
  char *timeStr,
  int cchTime
)const {
  QDateTime dateTime(QDate(st.wYear, st.wMonth, st.wDay),
   QTime(st.wHour, st.wMinute, st.wSecond, st.wMilliseconds));

  QString formattedTime = locale.toString(dateTime, format);

  if (!formattedTime.isEmpty() && formattedTime.length() < cchTime) {
  // Convert QString to wchar_t and copy to timeStr
 QByteArray bytearray = formattedTime.toUtf8();
  strncpy(timeStr,bytearray.constData(),cchTime);
  timeStr[cchTime-1] = '\0';
  return formattedTime.length() + 1; // Return the actual length, including null-terminator
  }

  // Buffer is too small or format string is empty
  return 0;
}
//**********************************************************************
/// getTimeasprintf 

//**********************************************************************

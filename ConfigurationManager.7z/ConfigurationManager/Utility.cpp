/// @file Utility.cpp
/// ****************************************************************
///  Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Utility
/// @n Filename: Utility.cpp
/// @n Desc:	 Implementation of functions commonly used by both 
///				 RequestHandler and Memory manager. 
///
//  ****************************************************************
//  Revision History
//  ****************************************************************
//  $Log[4]:
// 26  Stability Project 1.20.1.4   7/2/2011 5:02:23 PM   Hemant(HAIL) 
//    Stability Project: Recorder source has been upgraded from IL
//    version of firmware to JF version of firmware.
// 25  Stability Project 1.20.1.3   7/1/2011 4:39:05 PM   Hemant(HAIL) 
//    Stability Project: Files has been checked in before the merging
//    task. The merging will be done between IL version of firmware and JF
//    version of firmware. 
// 24  Stability Project 1.20.1.2   3/17/2011 3:20:53 PM  Hemant(HAIL) 
//    Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//    new operator in DEBUG mode only. To detect memory leaks in files, use
//    it in preprocessor definition when in debug mode.
// 23  Stability Project 1.20.1.1   2/15/2011 3:04:09 PM  Hemant(HAIL) 
//    File updated during Heap Management. Call to the default behaviour
//    of new operator has been commented.
//  $
//
//  ****************************************************************
/******************************************************************************************
            COPYRIGHT (c) 2004
             HONEYWELL INC.,
            ALL RIGHTS RESERVED

    This software is a copyrighted work and/or information protected
    as a trade secret. Legal rights of Honeywell Inc. in this
    software is distinct from ownership of any medium in which the
    software is embodied. Copyright or trade secret notices included
    must be reproduced in any copies authorized by Honeywell Inc.
    The information in this software is subject to change without
    notice and should not be considered as a commitment by Honeywell
    Inc.
******************************************************************************************/
#include "StdAfx.h"
#include "CMemoryManager.h"
#include "CRequestHandler.h"
#include "Utility.h"
#include "V6crc.h"
#include "TVtime.h"
#include "math.h"


#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif

/*********************Extern definitions*************************************/
extern CMemoryManager glbObjMemoryManager;		///<Global memory manager object
extern CRequestHandler glbObjRequestHandler;	///<Global Request Handler object
/*********************Extern definitions*************************************/

//******************************************************
//  CCMMUtility Constructor()
///
/// Constructor 
/// 
//******************************************************
CCMMUtility::CCMMUtility()
{
}
//******************************************************
//  CCMMUtility Destructor()
///
/// Destructor 
/// 
//******************************************************
CCMMUtility::~CCMMUtility()
{
}
//**********************************************************************
///
/// Dynamically loads the tracer module and initializes the
///	global function pointers.
///
//	Sai Krishnan	1/9/2004	Desktop project made UNICODE 
//								compliant. 
//**********************************************************************
void CCMMUtility::LoadTracerModule()
{
	/*
	TV_BOOL bLoadTracer = FALSE;
#ifdef qDebugR_ENABLE
	#ifdef INFO_TRACE_ENABLE
		bLoadTracer = TRUE;
	#endif;
	#ifdef ERROR_TRACE_ENABLE
		bLoadTracer = TRUE;
	#endif;
	#ifdef WARNING_TRACE_ENABLE
		bLoadTracer = TRUE;
	#endif;
#endif;

	if(TRUE==bLoadTracer)
	{
		//load the library only when any of the preprocessor definitions are defined.
		glbDllHandle = LoadLibrary(_T("TraceFile.dll"));
		if(NULL == glbDllHandle)
		{
			return;
		}

		TraceStart = (fnTraceStart) GetProcAddress (glbDllHandle,GETPROCADDRESSSTRING("TraceStart"));
		Trace = (fnTrace) GetProcAddress (glbDllHandle,GETPROCADDRESSSTRING("Trace"));
		TraceStop = (fnTraceStop) GetProcAddress (glbDllHandle,GETPROCADDRESSSTRING("TraceStop"));

		if(NULL != TraceStart)
		{
			TraceStart(_T("CMM_Log"));
			LOG_INFO(CMM_qDebugR_MODE,_T("CMM : CMMUtility::LoadTracerModule - Loaded Tracer"));
		}
	}else
	{
		glbDllHandle = NULL;
		TraceStart = NULL;
		Trace = NULL;
		TraceStop= NULL;
	}*/
	return;	
}
//**********************************************************************
///
/// Unloads the dynamically loaded tracer module.
///
//**********************************************************************
void CCMMUtility::UnLoadTracerModule()
{
	/*
	if(NULL != glbDllHandle)
	{
		LOG_INFO(CMM_qDebugR_MODE,_T("UnLoadTracerModule - Unloaded Tracer"));
		FreeLibrary (glbDllHandle);
		glbDllHandle = NULL;
	}	
	TraceStart = NULL;
	Trace = NULL;
	TraceStop = NULL;
	*/
	return;	
}
//**********************************************************************
///
/// Builds the lookup for the metadata file.
///
/// @param[in]	pByMetadata		 -  Buffer contains the metadata 
///
/// @param[in]	dwConfigurationID - The id of the configuration for 
///									which the metadata is to be used.
///									0 == System Metadata.
///
/// @param[in]	pwVersion		 -  The version of the metadata that 
///									has been parsed.
///									NULL can be sent if the version is
///									not required.
///										  
/// @return		Error code if failed, CSTATUS_OK if okay
/// 
//	Modification History
//	Sai Krishnan	20/8/2004	Datatype misalignment problem fixed.
//								All values written to the metadata 
//								file will be 4 byte aligned,including
//								CRC values added at the end of the 
//								metadata file.
//								Also, when default values of char/
//								wchar are encountered, the pointer
//								should be move forward to the next 4 
//								byte boundary after the default value.
//**********************************************************************
CMMSTATUS CCMMUtility::BuildMetadataLookUp(BYTE * pByMetadata,DWORD dwConfigurationID, WORD * pwVersion)
{
	
	LOG_INFO(CMM_qDebugR_MODE,("BuildMetadataLookUp - Start"));
#ifdef PWDLOGS_ENABLE
	WCHAR szDbgMsg[512];
	swprintf( szDbgMsg, L" CCMMUtility::BuildMetadataLookUp - Start GTC %d\n",GetTickCount());
	OutputDebugString(szDbgMsg);
#endif
	/**Step 0: Check the arguments*/
	/******************************/
	if(NULL == pByMetadata)	//version number is optional and will be checked at the end
	{
		LOG_ERR(CMM_qDebugR_MODE,("BuildMetadataLookUp - End - CSTATUS_INVALID_PARAMETER"));
#ifdef PWDLOGS_ENABLE
		swprintf( szDbgMsg, L" CCMMUtility::BuildMetadataLookUp- End - CSTATUS_INVALID_PARAMETER GTC %d\n",GetTickCount());
		OutputDebugString(szDbgMsg);
#endif
		return CSTATUS_INVALID_PARAMETER;
	}

	try
	{
		/**Step 1: Get the metadata header from the metadata stream*/
		/***********************************************************/
		Metadata_Header sMDHeader;	//Buffer to store the version number and 
									//size of metadata(size variable includes 
									//metadata header size)

		memcpy(&sMDHeader,pByMetadata,sizeof(sMDHeader));
		if(0>=sMDHeader.wSize )	//the size variable contains the metadata size with the header size
		{
			LOG_ERR(CMM_qDebugR_MODE,("BuildMetadataLookUp - End - Metadatasize <=0"));
#ifdef PWDLOGS_ENABLE			
			swprintf( szDbgMsg, L" CCMMUtility::BuildMetadataLookUp - - End - Metadatasize <=0 GTC %d\n",GetTickCount());
			OutputDebugString(szDbgMsg);
#endif
			return CSTATUS_INVALID_METADATA;
		}

		/**Step 2: Calculate CRC and verify integrity of Metadata*/
		/*********************************************************/
		//calculate CRC of metadata and check integrity
		/****************************************************************/
		//Note: The CRC for the metadata will be at the end of the meta-
		//Note: data. To avoid misalignment problem, the CRC will be 
		//Note: appended with padding bytes to make it 4 byte aligned.
		//Note: The CRC calculation will NOT include the Meta-
		//Note: Data header. The size of the stream will be taken from 
		//Note: the Metadata header and used for CRC computation.
		//Note: The size in the metadata header includes the metadata
		//Note: header + actual meta-data + CRC(2bytes) + Padding(2 bytes)
		/****************************************************************/
		unsigned short wCalcCRC=0;
		wCalcCRC = CrcCalc(pByMetadata + sizeof(sMDHeader),
							sMDHeader.wSize - sizeof(sMDHeader) - sizeof(unsigned long));	
		//sizeof(unsigned long) in the previous statement indicates the crc and the 2 byte padding

		//get the CRC stored in the file
		unsigned short wCRC=0;
		memcpy(&wCRC,
				pByMetadata + sMDHeader.wSize - sizeof(unsigned long),
				sizeof(unsigned short));
		//sizeof(unsigned short) in the previous statement indicates that the CRC immediately follows 
		//the metadata blocks and is followed by the 2 byte Padding.

		if(wCRC != wCalcCRC)
		{
			LOG_ERR(CMM_qDebugR_MODE,("BuildMetadataLookUp - End - Invalid Metadata - CRC failed"));
#ifdef PWDLOGS_ENABLE
			swprintf( szDbgMsg, L" CCMMUtility::BuildMetadataLookUp - End -- Invalid Metadata - CRC failed GTC %d\n",GetTickCount());
			OutputDebugString(szDbgMsg);
#endif
			return CSTATUS_INVALID_METADATA;
		}					

		/**Step 3: Initialize metadata.. Create a placeholder for the metadata*/
		/**********************************************************************/
		CMMSTATUS eCmmstatus=glbObjMemoryManager.InitializeMetadata (dwConfigurationID,
																		pByMetadata/*store the metadata file*/);
		if(CSTATUS_OK !=eCmmstatus)
		{
			LOG_ERR(CMM_qDebugR_MODE,("BuildMetadataLookUp - End - Initialize Metadata failed"));
#ifdef PWDLOGS_ENABLE
			swprintf( szDbgMsg, L" CCMMUtility::BuildMetadataLookUp - End -- Initialize Metadata failed GTC %d\n",GetTickCount());
			OutputDebugString(szDbgMsg);
#endif
			return CSTATUS_METADATA_NOTINITIALIZED;
		}

		/**Step 4: Parse through each of the block type*/
		/***********************************************/
		DWORD dwSize=0;		//Count to keep track of size of data parsed in the metadata stream..
							//(to avoid buffer overrun)
		TV_BOOL tvbFlag=TRUE;	//Flag to set if the parsing operation has to continue
		
		//move the pointer to point to the first block type
		BYTE * pByMDBufPos = pByMetadata + sizeof(sMDHeader);	
		//the pByMDBufPos pointer will be moved to point to the start of each block

		WORD wBlockType=0;		//buffer to store the block type of each record
		WORD wClass;			//buffer to identify if the current record is of type structure/union		
		BYTE * pByStructDefStart=NULL;		//pointer to start of the main structure def
		WORD wMemberNumber=0;	//counter which will count the number of members of a struct/union
		
		//loop through each of the block types until all records have been read.
		while(tvbFlag)
		{
			//get the size of the actual metadata block(excluding header + crc + crcpadding)
			//sizeof(unsigned long) in the foll. statement indicates the crc and the 2 byte padding
			if(dwSize >= sMDHeader.wSize - sizeof(sMDHeader) - sizeof(unsigned long))
			{
				//all records have been read.
				tvbFlag=FALSE;
				break;	//no more records to be read from the metadata. break out of the loop
			}

			MD * psMetadata;		//buffer to store the block type information
			psMetadata = (MD *)pByMDBufPos;

			/****************************************************************/
			//Note: Embedded structures will have the class variable set to 5.
			//Note: Embedded unions will have the class variable set to 6.
			/****************************************************************/						
			if(CLASS_STRUCTURE == psMetadata->wclass
				|| CLASS_UNION == psMetadata->wclass)
			{
				//if the block type is a structure/union.. the block type value has to be stored... 
				//the following records belong to this block type until another structure/union is read.
				wBlockType = psMetadata->wDatatype ;
				wClass = psMetadata->wclass;

				pByStructDefStart = pByMDBufPos;	//store the start of the structure main definition
				
				//move the buffer to point to the next record
				pByMDBufPos = pByMDBufPos + sizeof(MD);

				//update the size variable - used to check buffer overrun
				dwSize = dwSize + sizeof(MD);

				//reset the member counter to 1 (implies first member)
				wMemberNumber = 1;

				continue;//read the next record
			}
			
			//If the record read is not a structure/union, but a member of the structure/union

			/**Step 5: Update the MetadataLookup for each record*/
			/****************************************************/
			eCmmstatus=glbObjMemoryManager.SetIdentifierBlock (dwConfigurationID,
																wBlockType,																			
																pByStructDefStart,
																wMemberNumber,
																pByMDBufPos);

			if(CSTATUS_OK !=eCmmstatus)
			{
				LOG_ERR(CMM_qDebugR_MODE,("BuildMetadataLookUp - End - SetIdentifierBlock failed : %d"),eCmmstatus);
				//since the metadata has been stored, it can be deleted in case of error
				glbObjMemoryManager.DeleteMetadata (dwConfigurationID);
				return CSTATUS_METADATA_NOTINITIALIZED;
			}
			//increment member counter
			wMemberNumber ++ ;

			/**Step 6: Move the buffer to the next record*/
			/*********************************************/
			switch(psMetadata->wDatatype)
			{				
				case REF_WCHAR:				
				case REF_CHAR:				
					if(psMetadata->wnumInst>0)	//an array exists
					{
						/****************************************************************/
						//Note: Two dimensional Character arrays are allowed.
						//Note: But to optimize data storage, only one string
						//Note: (default value) will be stored at the end of the string 
						//Note: block type. The size of the string that follows will be 
						//Note: stored in "w" variable of the "vdefault" union within the 
						//Note: block type structure.
						//Note: The size will be in "Bytes" and will include the NULL
						//Note: string termination character.
						//Note: THe default value will be padded upto the next 4 byte 
						//Note: address.
						/****************************************************************/
						//move the pointer to point to the beginning of the default value
						pByMDBufPos = pByMDBufPos + sizeof(MD);													
						
						//if size of default value is not a multiple of 4, then additional
						//padding bytes will be present to align the default value
						//to a four byte boundary in the metadata 
						WORD wPaddingOffset=0;
						if(0 == ((psMetadata->vdefault.w)%sizeof(DWORD)))
						{
							//the default value is exactly 4 byte aligned
							wPaddingOffset=0;
						}else
						{
							//the default value is not 4 byte aligned
							wPaddingOffset=(sizeof(DWORD) - ((psMetadata->vdefault.w)%sizeof(DWORD)));
						}						
						//move the pointer to point past the default value to the next record
						pByMDBufPos = pByMDBufPos + psMetadata->vdefault.w
													+ wPaddingOffset;

						//update the size variable - used to check buffer overrun
						dwSize = dwSize + sizeof(MD) + psMetadata->vdefault.w
											+ wPaddingOffset;					
						break;
					}					
				default:
					/****************************************************************/
					//Note: For arrays of float,integer,long ,byte,etc, the default 
					//Note: value  is specified in the default parameter of the 
					//Note: metadata block. All the members of the array will be 
					//Note: filled with this value.No value follows the metadata 
					//Note: block
					/****************************************************************/
					pByMDBufPos = pByMDBufPos + sizeof(MD);	//move the pointer to point to the next record
					//update the size variable - used to check buffer overrun
					dwSize = dwSize + sizeof(MD);
					break;
			}//end of switch
		}//end of while loop
		
		//All records processed..

		/**Step 6: Request Memory Manager to compute the size of each block type in the lookup*/
		/**************************************************************************************/
		eCmmstatus=glbObjMemoryManager.ComputeMetadataSize (dwConfigurationID);
		if(CSTATUS_OK !=eCmmstatus)
		{
			LOG_ERR(CMM_qDebugR_MODE,("BuildMetadataLookUp - End - Compute metadata size failed : %d"),eCmmstatus);
#ifdef PWDLOGS_ENABLE
			swprintf( szDbgMsg, L" CCMMUtility::BuildMetadataLookUp - End -- Compute metadata size failed : %d GTC %d\n",eCmmstatus,GetTickCount());
			OutputDebugString(szDbgMsg);
#endif
			//since the metadata has been stored, it can be deleted in case of error
			glbObjMemoryManager.DeleteMetadata (dwConfigurationID);
			return CSTATUS_METADATA_NOTINITIALIZED;
		}

		/**Step 7: Return the version number*/
		/************************************/
		if(NULL != pwVersion)
		{
			LOG_INFO(CMM_qDebugR_MODE,("BuildMetadataLookUp - Metadata Version : %d"),sMDHeader.wVerNo);
#ifdef PWDLOGS_ENABLE
			swprintf( szDbgMsg, L" CCMMUtility::BuildMetadataLookUp - Metadata Version : %d GTC %d\n",sMDHeader.wVerNo,GetTickCount());
			OutputDebugString(szDbgMsg);
#endif
			//if version is required
			*pwVersion = sMDHeader.wVerNo ;
		}

		LOG_INFO(CMM_qDebugR_MODE,("BuildMetadataLookUp - CSTATUS_OK"));
#ifdef PWDLOGS_ENABLE
		swprintf( szDbgMsg, L" CCMMUtility::BuildMetadataLookUp -CSTATUS_OK GTC %d\n",GetTickCount());
		OutputDebugString(szDbgMsg);
#endif
		return CSTATUS_OK;
	}catch(...)
	{
		//TBD::add proper Exception Handling
		LOG_ERR(CMM_qDebugR_MODE,("BuildMetadataLookUp - Exception - LastError : %d"),GetLastError());
#ifdef PWDLOGS_ENABLE
		swprintf( szDbgMsg, L" CCMMUtility::BuildMetadataLookUp -- Exception - LastError : %d GTC %d\n",GetLastError(),GetTickCount());
		OutputDebugString(szDbgMsg);
#endif
		return CSTATUS_FAIL;
	}
}
//**********************************************************************
///
/// Updates the configuration header with the latest statistics.
///
/// @param[in]	dwConfigurationID - The id of the configuration for 
///									which the config header has to be
///									updated. 
///
/// @param[in]	wOperation		 -  THe operation for which the statistics
///									has to be updated.
///										  
/// @param[in]	dwAction		 -  The higher word of the value to be stored 
///									in the "dwAction" param of the Config 
///									Header Record.
///
/// @param[in]	pwMetadataSize	 -  Buffer contains the size of the system 
///									metadata including header.
///									Buffer to be sent only when 
///									wOperation = CONFIG_CHANGES
///									Can be NULL if 
///									wOperation != CONFIG_CHANGES
///
/// @return		Error code if failed, CSTATUS_OK if okay
/// 
//**********************************************************************
CMMSTATUS CCMMUtility::UpdateConfigurationFileHeader(DWORD dwConfigurationId,
													WORD wOperation,
													 DWORD dwAction,
													 WORD *pwMetadataSize)
{
	LOG_INFO(CMM_qDebugR_MODE,("UpdateConfigurationFileHeader - Start"));
#ifdef PWDLOGS_ENABLE
	WCHAR szDbgMsg[512];
	swprintf( szDbgMsg, L" CCMMUtility::UpdateConfigurationFileHeader - Start GTC %d\n",GetTickCount());
	OutputDebugString(szDbgMsg);
#endif
	CMMSTATUS eCmmStatus;
	BYTE *pByConfigFile = NULL;
	
	try
	{	
		//Get the configuration file from memory manager
		eCmmStatus = glbObjMemoryManager.GetConfigurationFile (dwConfigurationId,
																(BYTE **)&pByConfigFile);
													
		if(CSTATUS_OK != eCmmStatus)
		{
			LOG_ERR(CMM_qDebugR_MODE,("UpdateConfigurationFileHeader - Unable to get configuration : %d"),eCmmStatus);
#ifdef PWDLOGS_ENABLE
			swprintf( szDbgMsg, L" CCMMUtility::UpdateConfigurationFileHeader - Unable to get configuration : %dGTC %d\n",eCmmStatus,GetTickCount());
			OutputDebugString(szDbgMsg);
#endif
			return eCmmStatus;
		}

		CONFIGFILE_HEADER * pByConfigFileHeader=(CONFIGFILE_HEADER *)pByConfigFile ;

		/***********************************************************/	
		//Note : The foll. params will not be changed here.		
		//Note : pConfigHeader->szFileName;		 NEED NOT BE CHANGED
		//Note : pConfigHeader->szPassword[18];	 NEED NOT BE CHANGED					
		//Note : pConfigHeader->wEncryption;	 NEED NOT BE CHANGED					
		//Note : pConfigHeader->wFileType;		 NEED NOT BE CHANGED	
		//Note : pConfigHeader->CreationDateTime NEED NOT BE CHANGED	
		//Note : It can be changed through a call to 
		//Note : SetConfigurationLog API.
		/***********************************************************/

		CTVtime sTVTime;
		//based on the operation requested , update the header
		switch(wOperation)
		{
			case CONFIG_LOAD:
				/**********************************************************/
				//Note : This will be called when a LOAD is done
				/**********************************************************/
				//1 The "load" statistics has to be updated.
				pByConfigFileHeader->sConfigInfo.wTotalLoad += 1;	//increment coutner by 1

				//2 Update the ConfigRecord statistics
				//dwAction	= Persisted/Unpersisted source
				UpdateConfigRecordStatistics(&pByConfigFileHeader->sConfigInfo,
												wOperation,
												dwAction);
				break;
			case CONFIG_SAVES:
				/**********************************************************/
				//Note : This will be called when a SAVE is done
				//Note : THis operation will be performed by CMM
				//Note : during the API call SetConfigurationLog.
				/**********************************************************/
				//1 The "save" statistics has to be updated.
				pByConfigFileHeader->sConfigInfo.wTotalSave += 1;	//increment coutner by 1

				//2 Update the ConfigRecord statistics
				//dwAction	= As given by the user
				UpdateConfigRecordStatistics(&pByConfigFileHeader->sConfigInfo,
												wOperation,
												dwAction);
				break;
			case CONFIG_CHANGES:
				/**********************************************************/
				//Note : This will be called when a COMMIT is done
				/**********************************************************/
				//1. Metadata offset within the configuration file
				pByConfigFileHeader->lMDOffset = sizeof(CONFIGFILE_HEADER) + 
												sizeof(unsigned long)/*CRC + padding*/;						
				
				//2. Datablock offset within the configuration file
				pByConfigFileHeader->lDataOffset = pByConfigFileHeader->lMDOffset + 
													*pwMetadataSize;																	

				//3. Update the sConfigInfo structure for statistics			
				//3.1 The "changes" statistics has to be updated.
				pByConfigFileHeader->sConfigInfo.wTotalChanges += 1;	//increment coutner by 1

				//4. Update the ConfigRecord statistics
				//dwAction	= Number of modified instances
				UpdateConfigRecordStatistics(&pByConfigFileHeader->sConfigInfo,
												wOperation,
												dwAction);

				break;
			case CONFIG_VERSION_UP:
				/**********************************************************/
				//Note : This will be called when a LOAD occurs and it
				//Note : requires a version upgrade.
				/**********************************************************/
				//1 The "load" statistics has to be updated.
				pByConfigFileHeader->sConfigInfo.wTotalLoad += 1;	//increment coutner by 1

				//2 The "VersionUp" statistics has to be updated.
				pByConfigFileHeader->sConfigInfo.wTotalVersionUpgrade += 1;	//increment coutner by 1

				//3 Update the ConfigRecord statistics for Version Up
				//dwAction	= Version upgraded from
				UpdateConfigRecordStatistics(&pByConfigFileHeader->sConfigInfo,
												wOperation,
												dwAction);
				
				break;
			case CONFIG_VERSION_DOWN:
				/**********************************************************/
				//Note : This will be called when a LOAD occurs and it
				//Note : requires a version downgrade.
				/**********************************************************/
				//1 The "load" statistics has to be updated.
				pByConfigFileHeader->sConfigInfo.wTotalLoad += 1;	//increment counter by 1

				//2 The "VersionDown" statistics has to be updated.
				pByConfigFileHeader->sConfigInfo.wTotalVersionDowngrade += 1;	//increment counter by 1

				//3 Update the ConfigRecord statistics for Version Down
				//dwAction	= Version downgraded from								
				UpdateConfigRecordStatistics(&pByConfigFileHeader->sConfigInfo,
												wOperation,
												dwAction);
				break;
			default:
				//no updates to be done.
				return CSTATUS_OK;
		}//end of switch

		//recalculate CRC for the configuration file header.
		unsigned short wCalcCRC = CrcCalc( pByConfigFile , sizeof(CONFIGFILE_HEADER));
		
		/*************************************************/
		//Note: The CRC will immediately follow the config
		//Note: file header. This should be followed by
		//Note: a 2 byte padding to make the value 4 byte
		//Note: aligned. The padding will not be updated
		//Note: in this method.
		/*************************************************/

		//store the CRC in the config file at the end of the config file header.		
		memcpy(pByConfigFile + sizeof(CONFIGFILE_HEADER),
				&wCalcCRC,
				sizeof(unsigned short ));
			
		LOG_INFO(CMM_qDebugR_MODE,("UpdateConfigurationFileHeader - CSTATUS_OK"));
#ifdef PWDLOGS_ENABLE		
		swprintf( szDbgMsg, L" CCMMUtility::UpdateConfigurationFileHeader - CSTATUS_OK GTC %d\n",GetTickCount());
		OutputDebugString(szDbgMsg);
#endif
		return CSTATUS_OK;
	}catch(...)
	{
		LOG_ERR(CMM_qDebugR_MODE,("UpdateConfigurationFileHeader - Exception - LastError : %d"),GetLastError());
		return CSTATUS_FAIL;
	}
}
//**********************************************************************
///
/// Updates the configuration header with the latest statistics.
///
/// @param[in]	pConfigInfo		 -  Pointer to the statistics portion of 
///									the configuration header.
///
/// @param[in]	wOperation		 -  THe operation for which the statistics
///									has to be updated.
///										  
/// @param[in]	dwAction		 -  The higher word of the value to be
///									"dwAction" parameter of the config
///									header.
///
/// @return		Error code if failed, CSTATUS_OK if okay
/// 
///	@note 
///	Operation		Higher WORD        Lower WORD 
///	Load    Persisted/Unpersisted    Current Version 
///	Changes			Number of instances modified Current Version 
///	Version Up  Version converted from.    Version converted to
///	Version Down	Version converted from.    Version converted to
///	Saves     From Caller					 From Caller
//**********************************************************************
CMMSTATUS CCMMUtility::UpdateConfigRecordStatistics(CONFIGLOG_INFO * pConfigInfo,
														WORD wOperation,
														DWORD dwAction)
{
	LOG_INFO(CMM_qDebugR_MODE,("UpdateConfigRecordStatistics - Start"));
#ifdef PWDLOGS_ENABLE
	WCHAR szDbgMsg[512];
	swprintf( szDbgMsg, L" CCMMUtility::UpdateConfigRecordStatistics - Start GTC %d\n",GetTickCount());
	OutputDebugString(szDbgMsg);
#endif
	if(NULL == pConfigInfo)
	{
		LOG_ERR(CMM_qDebugR_MODE,("UpdateConfigRecordStatistics - End - Invalid Config info pointer"));
		return CSTATUS_INVALID_PARAMETER;
	}

	CONFIGLOG_RECORD sConfigRecord;
	memset(&sConfigRecord ,0, sizeof(sConfigRecord));

	//set the vales of the config record.
	CTVtime sTVTime;
	sTVTime.TimeNow();	//get the current time
	sConfigRecord.dtChangeDateTime = sTVTime.GetMicroSecs();			
	sConfigRecord.dwSerialNumber = glbObjRequestHandler.GetSerialNumber ();

	//set the dwAction parameter
	/************************************************************************/
	//	Note : dwAction parameter will be set as below
	//	Load    Persisted/Unpersisted    Current Version 
	//	Changes			Number of instances modified Current Version 
	//	Version Up  Version converted from.    Version converted to
	//	Version Down	Version converted from.    Version converted to 
	//	Saves     From Caller					 From Caller
	/************************************************************************/	
	//start a loop so that all the related fields are updated
	TV_BOOL bFlag = TRUE;
	while(bFlag)
	{
		switch(wOperation)
		{
			case CONFIG_SAVES:
				//the value given by the user will be copied as is.
				sConfigRecord.dwAction = dwAction;
				break;
			default:
				//value sent by the caller will be the higher word.
				sConfigRecord.dwAction = dwAction << (sizeof(WORD) * SIZE_OF_BYTE);
				//the current system version will be the lower word.
				sConfigRecord.dwAction = sConfigRecord.dwAction | 
												(glbObjRequestHandler.GetSystemMetadataVersion());
				break;
		};
		
		int nCounter=0;
		//pointer to the start of array of config record structures
		CONFIGLOG_RECORD * pConfigRecordStart = NULL;	
	
		switch(wOperation)
		{
			case CONFIG_LOAD:		
				/******************************/
				//Note : Load (10) Records 0-9
				/******************************/
				//pointing to record 0
				pConfigRecordStart = &(pConfigInfo->ConfigRecord[0]);	
				//move the stats 1-9 to the positions 2-10 of the 10 total records
				for(nCounter =9;nCounter >0;nCounter--)
				{				
					//moving the nth record to the n+1th record
					(pConfigRecordStart + nCounter)->dwAction = (pConfigRecordStart + nCounter -1)->dwAction;
					(pConfigRecordStart + nCounter)->dtChangeDateTime = (pConfigRecordStart + nCounter - 1)->dtChangeDateTime;				
					(pConfigRecordStart + nCounter)->dwSerialNumber = (pConfigRecordStart + nCounter -1)->dwSerialNumber;
				}
				//copy the newly created record as the 1st record
				memcpy(pConfigRecordStart,&sConfigRecord,sizeof(sConfigRecord ));
				bFlag= FALSE;
				break;
			case CONFIG_SAVES:
				/*******************************/
				//Note : Save (10) Records 10-19
				/*******************************/
				//pointing to record 10
				pConfigRecordStart = &(pConfigInfo->ConfigRecord[10]);	
				//move the stats 10-18 to the positions 11-19 of the 10 total records
				for(nCounter =9;nCounter >0;nCounter--)
				{				
					//moving the nth record to the n+1th record
					(pConfigRecordStart + nCounter)->dwAction = (pConfigRecordStart + nCounter -1)->dwAction;
					(pConfigRecordStart + nCounter)->dtChangeDateTime = (pConfigRecordStart + nCounter - 1)->dtChangeDateTime;				
					(pConfigRecordStart + nCounter)->dwSerialNumber = (pConfigRecordStart + nCounter -1)->dwSerialNumber;
				}
				//copy the newly created record as the 1st record
				memcpy(pConfigRecordStart,&sConfigRecord,sizeof(sConfigRecord ));
				bFlag= FALSE;
				break;
			case CONFIG_CHANGES:
				/***********************************/
				//Note : Changes (40) Records 20-59
				/***********************************/
				//pointing to record 20
				pConfigRecordStart = &(pConfigInfo->ConfigRecord[20]);	
				//move the stats 20-58 to the positions 21-59 of the 40 total records
				for(nCounter =39;nCounter >0;nCounter--)
				{				
					//moving the nth record to the n+1th record
					(pConfigRecordStart + nCounter)->dwAction = (pConfigRecordStart + nCounter -1)->dwAction;
					(pConfigRecordStart + nCounter)->dtChangeDateTime = (pConfigRecordStart + nCounter - 1)->dtChangeDateTime;				
					(pConfigRecordStart + nCounter)->dwSerialNumber = (pConfigRecordStart + nCounter -1)->dwSerialNumber;
				}
				//copy the newly created record as the 1st record
				memcpy(pConfigRecordStart,&sConfigRecord,sizeof(sConfigRecord ));

				bFlag= FALSE;
				break;
			case CONFIG_VERSION_UP:
				/******************************************/
				//Note : Version upgrade (20) Records 60-79
				/******************************************/
				//pointing to record 60
				pConfigRecordStart = &(pConfigInfo->ConfigRecord[60]);	
				//move the stats 60-78 to the positions 61-79 of the 20 total records
				for(nCounter =19;nCounter >0;nCounter--)
				{				
					//moving the nth record to the n+1th record
					(pConfigRecordStart + nCounter)->dwAction = (pConfigRecordStart + nCounter -1)->dwAction;
					(pConfigRecordStart + nCounter)->dtChangeDateTime = (pConfigRecordStart + nCounter - 1)->dtChangeDateTime;				
					(pConfigRecordStart + nCounter)->dwSerialNumber = (pConfigRecordStart + nCounter -1)->dwSerialNumber;
				}
				//copy the newly created record as the 1st record
				memcpy(pConfigRecordStart,&sConfigRecord,sizeof(sConfigRecord ));

				//another iteration is required to update the "Load" statistics
				bFlag= TRUE;
				//set the appropriate values
				wOperation = CONFIG_LOAD;
				//a TRUE is sent as the value of dwAction which implies
				//that the load is done from an unpersisted source which is
				//the case when a conversion is required.
				dwAction = TRUE;
				break;
			case CONFIG_VERSION_DOWN:
				/********************************************/
				//Note : Version downgrade (20) Records 80-99
				/********************************************/
				//pointing to record 80
				pConfigRecordStart = &(pConfigInfo->ConfigRecord[80]);	
				//move the stats 80-98 to the positions 81-99 of the 20 total records
				for(nCounter =19;nCounter >0;nCounter--)
				{				
					//moving the nth record to the n+1th record
					(pConfigRecordStart + nCounter)->dwAction = (pConfigRecordStart + nCounter -1)->dwAction;
					(pConfigRecordStart + nCounter)->dtChangeDateTime = (pConfigRecordStart + nCounter - 1)->dtChangeDateTime;				
					(pConfigRecordStart + nCounter)->dwSerialNumber = (pConfigRecordStart + nCounter -1)->dwSerialNumber;
				}
				//copy the newly created record as the 1st record
				memcpy(pConfigRecordStart,&sConfigRecord,sizeof(sConfigRecord ));

				//another iteration is required to update the "Load" statistics
				bFlag= TRUE;
				//set the appropriate values
				wOperation = CONFIG_LOAD;
				//a TRUE is sent as the value of dwAction which implies
				//that the load is done from an unpersisted source which is
				//the case when a conversion is required.
				dwAction = TRUE;
				break;
			default:
				//no updates to be done.
				LOG_INFO(CMM_qDebugR_MODE,("UpdateConfigRecordStatistics - CSTATUS_OK"));
#ifdef PWDLOGS_ENABLE				
				swprintf( szDbgMsg, L" CCMMUtility::UpdateConfigRecordStatistics - CSTATUS_OK - NO updates to be done GTC %d\n",GetTickCount());
				OutputDebugString(szDbgMsg);
#endif
				bFlag= FALSE;
				break;
		}
	}//end of while
	
	LOG_INFO(CMM_qDebugR_MODE,("UpdateConfigRecordStatistics - CSTATUS_OK"));
#ifdef PWDLOGS_ENABLE
	swprintf( szDbgMsg, L" CCMMUtility::UpdateConfigRecordStatistics - CSTATUS_OK GTC %d\n",GetTickCount());
	OutputDebugString(szDbgMsg);
#endif
	return CSTATUS_OK;
}
//**********************************************************************
///
/// Creates the block in the working section of the configuration for 
/// a given block type. 
///
/// @param[in]	dwConfigurationID - The id of the configuration for 
///									which the working section block 
///									is to be created. 
///
/// @param[in]	pBlockDetails->wBlockType  - The block type to be created.
///										  
/// @param[in]	pBlockDetails->wInstanceID - The id of the block to be 
///											 created.
///
/// @param[in] pBlockDetails->dwBlockSize  - The size of the data block. 
///											 (excluding the header size).
///
/// @return		Error code if failed, CSTATUS_OK if okay
///
///	@note	The function adds 12 bytes to the block that has been 
///			created to include the data block header.
/// 
//**********************************************************************
CMMSTATUS CCMMUtility::CreateDataBlock(DWORD dwConfigurationID, BLOCK_INFO* pBlockDetails)
{
	
	LOG_INFO(CMM_qDebugR_MODE,("CreateDataBlock - Start"));
#ifdef PWDLOGS_ENABLE	
	WCHAR szDbgMsg[512];
	swprintf( szDbgMsg, L" CCMMUtility::CreateDataBlock - Start GTC %d\n",GetTickCount());
	OutputDebugString(szDbgMsg);
#endif
	

	/**Step 0: Check the arguments*/
	/******************************/
	if(0 == dwConfigurationID)
	{
		LOG_ERR(CMM_qDebugR_MODE,("CreateDataBlock - End - Config id = 0"));
#ifdef PWDLOGS_ENABLE
		swprintf( szDbgMsg, L" CCMMUtility::CreateDataBlock - End - Config id = 0 GTC %d\n",GetTickCount());
		OutputDebugString(szDbgMsg);
#endif
		return CSTATUS_INVALID_CONFIGURATION;
	}	
	if(NULL == pBlockDetails
		|| 0 == pBlockDetails->dwBlockSize)
	{
		LOG_ERR(CMM_qDebugR_MODE,("CreateDataBlock - End - Invalid parameter"));
#ifdef PWDLOGS_ENABLE		
		swprintf( szDbgMsg, L" CCMMUtility::CreateDataBlock - End - Invalid parameter GTC %d\n",GetTickCount());
		OutputDebugString(szDbgMsg);
#endif
		return CSTATUS_INVALID_PARAMETER;
	}

	try
	{
		/**********************************************************/
		//Note : The pByBlock member of the argument variable
		//Note : pBlockDetails will NOT be updated after creating
		//Note : the new instance. The instance will be added to 
		//Note : the configuration lookup and the caller can then
		//Note : get its pointer from a call to GetModifiableBlock.
		//Note : The size member of the BLOCK_INFO structure, 
		//Note : should have the Datablock size without the size 
		//Note : of Data block Header
		/**********************************************************/

		/**Step 1: Create the data block for the given block type*/
		/*********************************************************/
		CMMSTATUS eCmmStatus=glbObjMemoryManager.CreateDataBlock (dwConfigurationID,
																	pBlockDetails->wBlockType,
																	pBlockDetails->wInstanceID,
																	pBlockDetails->dwBlockSize
																	+ sizeof(DATA_BLOCK_HEADER));
		if(CSTATUS_OK != eCmmStatus)
		{
			LOG_ERR(CMM_qDebugR_MODE,("CreateDataBlock - End - Create Datablock failed : %d"),eCmmStatus);
			return eCmmStatus;
		}				

		/**Step 2: Set the Instance State*/
		/*********************************/
		//an instance which didnt exist in current is created. Hence 
		//INSTANCE_ADDED state is added
		eCmmStatus= glbObjMemoryManager.SetInstanceState (dwConfigurationID,
															pBlockDetails->wBlockType,
															pBlockDetails->wInstanceID,
															INSTANCE_ADDED);

		LOG_INFO(CMM_qDebugR_MODE,("CreateDataBlock - Success : %d"),eCmmStatus);
#ifdef PWDLOGS_ENABLE
		swprintf( szDbgMsg, L" CCMMUtility::CreateDataBlock - End - Success : %d GTC %d\n",eCmmStatus,GetTickCount());
		OutputDebugString(szDbgMsg);
#endif
		return CSTATUS_OK;
	}catch(...)
	{
		//TBD::add proper Exception Handling
		LOG_ERR(CMM_qDebugR_MODE,("CreateDataBlock - Exception - LastError : %d"),GetLastError());
		return CSTATUS_FAIL;
	}
}
//**********************************************************************
///
/// Computes the size of the identifier in the metadata.
///
/// @param[in]	pIdentifierInfo	-	
///
/// @param[in]	nInclude		- 
///										  
/// @return		Error code if failed, CSTATUS_OK if okay
/// 
//**********************************************************************
WORD CCMMUtility::ComputeIdentifierSize(IDENTIFIER_RECORD_INFO *pIdentifierInfo,COMPUTE_INCLUDE nInclude)
{
	
	LOG_INFO(CMM_qDebugR_MODE,("ComputeIdentifierSize - Start"));
#ifdef PWDLOGS_ENABLE
	WCHAR szDbgMsg[512];
	swprintf( szDbgMsg, L" CCMMUtility::ComputeIdentifierSize - Start GTC %d\n",GetTickCount());
	OutputDebugString(szDbgMsg);
#endif
	WORD wSize = 0;																					//buffer to store the size based on the datatype and number of instances
	WORD wInstanceCount		= (pIdentifierInfo->wnumInst>0) ? pIdentifierInfo->wnumInst : 1;		//the number of instances or 1 
	WORD wSubInstanceCount	= (pIdentifierInfo->wnumSubInst>0) ? pIdentifierInfo->wnumSubInst : 1;	//number of subinstances or 1
	
	//Determine the class type
	switch(pIdentifierInfo->wclass)
	{
		case 5: //Structure
		case 6: //Union
			wSize = 0;
			break;
		default:
			switch(pIdentifierInfo->wDatatype)
			{
				case REF_BYTE:
					//TBD::not yet decided
					wSize=sizeof(BYTE);
					break;
				case REF_LONGLONG:
				case REF_ULONGLONG:
					wSize=sizeof(LONGLONG);
					break;
				case REF_SHORT:
				case REF_USHORT:
				case REF_BUSHORT:
					wSize=sizeof(SHORT);
					break;
				case REF_FLOAT:
					wSize=sizeof(float);
					break;
				case REF_DOUBLE:
					wSize=sizeof(double);
					break;
				case REF_WORD:
					wSize=sizeof(WORD);
					break;
				case REF_DWORD:
					wSize=sizeof(DWORD);
					break;
				case REF_UCHAR:
				case REF_CHAR:
				case REF_TCHAR:
				case REF_BUCHAR:
					wSize=sizeof(char);
					break;
				case REF_LONG:
				case REF_ULONG:
				case REF_BULONG:
					wSize=sizeof(long);
					break;
				case REF_TV_BOOL:
					wSize=sizeof(unsigned short);
					break;
				case REF_WCHAR:
					wSize=sizeof(WCHAR);
					break;
				default:
					wSize=0;
					break;
			}
			break;
	}

	//Check for other size inclusions
	switch(nInclude)
	{
		case INCLUDE_ALL:
			{
				switch(pIdentifierInfo->wDatatype)
				{
					case REF_UCHAR:
					case REF_CHAR:
					case REF_TCHAR:
					case REF_WCHAR:
							wSize = wSize * wInstanceCount * wSubInstanceCount;
						break;
					case REF_BUCHAR:
					case REF_BULONG:
					case REF_BUSHORT:
						break; //No change incase of bitfields
					default: //For all others
						wSize = wSize * wInstanceCount * wSubInstanceCount;
						break;
				}
			}
			break;
		case INCLUDE_NONE: //Nothing to do
		default:
			break;
	}
	LOG_INFO(CMM_qDebugR_MODE,("ComputeIdentifierSize - Success - Size : %d"),wSize );
#ifdef PWDLOGS_ENABLE	
	swprintf( szDbgMsg, L" CCMMUtility::ComputeIdentifierSize - Success - Size : %d GTC %d\n",wSize,GetTickCount());
	OutputDebugString(szDbgMsg);
#endif
	return wSize;
}
//**********************************************************************
///
/// Gets the block type and instance id from the data block header.
///
/// @param[in]	pbyDataBlock	-	Pointer to the data block including the  
///									header.
///
/// @param[out]	pBlockDetails->wBlockType  - The block type to be fetched.
///										  
/// @param[out]	pBlockDetails->wInstanceID - The id of the block to be 
///											 fetched.
///
/// @param[out]	pBlockDetails->pByBlock	 - Pointer to the data block 
///											 including the header.
///
/// @param[out] pBlockDetails->dwBlockSize  - The size of the data block. 
///
///
/// @return		Error code if failed, CSTATUS_OK if okay
/// 
//**********************************************************************
CMMSTATUS CCMMUtility::GetDataBlockAndInstanceInfoFromDataBlock(BYTE * pbyDataBlock,
																BLOCK_INFO * pBlockDetails)
{
	LOG_INFO(CMM_qDebugR_MODE,("GetDataBlockAndInstanceInfoFromDataBlock - Start"));
#ifdef PWDLOGS_ENABLE	
	WCHAR szDbgMsg[512];
	swprintf( szDbgMsg, L" CCMMUtility::GetDataBlockAndInstanceInfoFromDataBlock - Start GTC %d\n",GetTickCount());
	OutputDebugString(szDbgMsg);
#endif
	if(NULL == pbyDataBlock
		|| NULL == pBlockDetails)
	{
		LOG_ERR(CMM_qDebugR_MODE,("GetDataBlockAndInstanceInfoFromDataBlock - End - Invalid parameter"));
		return CSTATUS_INVALID_PARAMETER;
	}
	
	//map the header of the data block to a structure.
	DATA_BLOCK_HEADER stDataBlockHeader;
	memcpy(&stDataBlockHeader,pbyDataBlock,sizeof(DATA_BLOCK_HEADER));

	//fill the structure with the required details
	pBlockDetails->dwBlockSize = stDataBlockHeader.dwBlockSize ;
	pBlockDetails->dwSessionNumber = stDataBlockHeader.dwSessionId ;
	pBlockDetails->wBlockType = stDataBlockHeader.wBlockType ;
	//the MSB of the instance id word contains the dirty bit.. so it shouldnt be included
	//as the instance id.
	pBlockDetails->wInstanceID  =INSTANCE_ID(stDataBlockHeader.wInstanceNumber) ;
	pBlockDetails->pByBlock = pbyDataBlock;	//here the header is also included in the block

	LOG_INFO(CMM_qDebugR_MODE,("GetDataBlockAndInstanceInfoFromDataBlock - CSTATUS_OK"));
#ifdef PWDLOGS_ENABLE	
	swprintf( szDbgMsg, L" CCMMUtility:: GetDataBlockAndInstanceInfoFromDataBlock - CSTATUS_OK GTC %d\n",GetTickCount());
	OutputDebugString(szDbgMsg);
#endif
	return CSTATUS_OK;
}
//**********************************************************************
/// Validates the individual member values within a data block.
///
/// @param[in]	pIdentifierDetails - The details of the member variable
///									as defined in the system metadata.
///
/// @param[in]	pbyData		  - Buffer to the start of the member variable
///									within the data block in the 
///									configuration file.							
///
/// @param[out]	pwSize		 	  - Size of the member variable that has been
///									validated.
///
/// @param[out]	pwStart		 	  - The number of bits validated in case of 
///									bitfields. 
///									0 == all bits defaulted.
///									This parameter can be NULL when the datatype
///									is not a bitfield.
///	
///	@param[in] wCopySize		  - If the size of data to be validated is different
///									from the size in the sIdentifierDetails, pass
///									the size, else send 0.(This parameter will
///									be made use of By VersionConverted. Utility
///									object will not use it.)
///
/// @param[in] bUseAllInstances - Will indicate whether to check for all the 
///									instances of the identifier or the specific instance 
///									of the indentifier.
/// @return		Returns CSTATUS_OK on success, error code on failure
/// 
/// Modification History :
/// 
/// Shyam				 6th May 2005  - When a configuration is loaded from a 
///						 persisted source limit check fail case has been Fixed. A new 
///						 parameter bUseAllInstances is added to check if all the 
///						 instances needs to be verified for the range check or check 
///						 for the specific subinstance.
//**********************************************************************************************
CMMSTATUS CCMMUtility::ValidateIntrinsicAndArrayDataType(IDENTIFIER_RECORD_INFO sIdentifierDetails,
															BYTE * pbyData,
															WORD * pwSize,
															WORD * pwStart,
															WORD wCopySize,
															BOOL bUseAllInstances)
{
	LOG_INFO(CMM_qDebugR_MODE,("ValidateIntrinsicAndArrayDataType - Start"));
#ifdef PWDLOGS_ENABLE	
	WCHAR szDbgMsg[512];
	swprintf( szDbgMsg, L" CCMMUtility:: ValidateIntrinsicAndArrayDataType - Start GTC %d\n",GetTickCount());
	OutputDebugString(szDbgMsg);
#endif
	if(NULL == pbyData
		|| NULL == pwSize)
	{
		LOG_ERR(CMM_qDebugR_MODE,("ValidateIntrinsicAndArrayDataType - End - Invalid Parameter"));
		return CSTATUS_INVALID_PARAMETER;
	}

	TV_BOOL bValid=FALSE;	//flag to indicate if data type is valid or not.
	value varTemp;			//buffer to store the value of the member
	memset(&varTemp,0,sizeof(value));

	value vlLowLimit = sIdentifierDetails.Lowlmt ;	//stores the lower limit
	value vlHiLimit  = sIdentifierDetails.Hilmt ;		//stores the higher limit
	value vlBitField;	//value used in case of BITFIELDS
	memset(&vlBitField,0,sizeof(value));

	int nBitCount=0,nPos=1;//value used in case of BITFIELDS
	WORD wDataType = sIdentifierDetails.wDatatype ;	//stores the datatype	
	WORD wSubInstanceCount = (sIdentifierDetails.wnumSubInst>0)?sIdentifierDetails.wnumSubInst:1;
	WORD wSizeToCopy=wCopySize;	
	WORD wInstanceCount = 1;

	/* Will Check for all instances if TRUE, else check for a specific instance passed. */
	if(TRUE == bUseAllInstances)
		wInstanceCount = (sIdentifierDetails.wnumInst>0)?sIdentifierDetails.wnumInst:1;

	*pwSize=0;	//initialize size variable
	int nNumInstances=0;	//counter variable used in a for loop
	int nBufPos=0;		//offset variable to move the buffer position 

	switch(wDataType)
	{
		case REF_BYTE:
		case REF_UCHAR:
			//TBD::to be decided
			//for(nNumInstances;nNumInstances < (wInstanceCount * wSubInstanceCount);
			//		nNumInstances ++,nBufPos++)
			{
				//assign the value in the nNumInstances'th position
				wSizeToCopy = (wSizeToCopy > 0)?wSizeToCopy:sizeof(BYTE);
				memcpy(&(varTemp.b),pbyData+nBufPos,wSizeToCopy);
				//check if the value is within range
				if(varTemp.b <vlLowLimit.b 
				|| varTemp.b >vlHiLimit.b )
				{
					LOG_ERR(CMM_qDebugR_MODE,(	"ValidateIntrinsicAndArrayDataType - %s byte out of range (V:%u L:%u H:%u)" ),
												sIdentifierDetails.Fieldname,
												varTemp.b,
												vlLowLimit.b,
												vlHiLimit.b );
					//value out of range
					return CSTATUS_VALUE_OUT_OF_RANGE;			
				}				
			}//end of for loop			
			*pwSize+=sizeof(BYTE)*wInstanceCount * wSubInstanceCount;
			break;
		case REF_LONGLONG:			
			//for(nNumInstances;nNumInstances < (wInstanceCount * wSubInstanceCount);
			//		nNumInstances++, nBufPos+= sizeof(LONGLONG))
			{
				wSizeToCopy = (wSizeToCopy > 0)?wSizeToCopy:sizeof(LONGLONG);
				memcpy(&(varTemp.ll),pbyData+nBufPos,wSizeToCopy);
				//check if the value is within range
				if(varTemp.ll <vlLowLimit.ll
				|| varTemp.ll >vlHiLimit.ll )
				{
					LOG_ERR(CMM_qDebugR_MODE,("ValidateIntrinsicAndArrayDataType - %s longlong out of range"), sIdentifierDetails.Fieldname );
					//value out of range
					return CSTATUS_VALUE_OUT_OF_RANGE;			
				}				
			}//end of for loop
			*pwSize+=sizeof(LONGLONG)*wInstanceCount * wSubInstanceCount;
			break;
		case REF_ULONGLONG:
			//for(nNumInstances;nNumInstances < (wInstanceCount * wSubInstanceCount);
			//		nNumInstances++,nBufPos+= sizeof(ULONGLONG))
			{
				wSizeToCopy = (wSizeToCopy > 0)?wSizeToCopy:sizeof(ULONGLONG);
				memcpy(&(varTemp.ull),pbyData+nBufPos,wSizeToCopy);
				//check if the value is within range
				if(varTemp.ull <vlLowLimit.ull
				|| varTemp.ull >vlHiLimit.ull )
				{
					LOG_ERR(CMM_qDebugR_MODE,("ValidateIntrinsicAndArrayDataType - %s ulonglong out of range"), sIdentifierDetails.Fieldname );
					//value out of range
					return CSTATUS_VALUE_OUT_OF_RANGE;			
				}				
			}//end of for loop
			*pwSize+=sizeof(ULONGLONG)*wInstanceCount * wSubInstanceCount;
			break;
		case REF_SHORT:
		//case REF_USHORT:	
			//for(nNumInstances;nNumInstances < (wInstanceCount * wSubInstanceCount);
			//		nNumInstances++,nBufPos+= sizeof(USHORT))
			{
				wSizeToCopy = (wSizeToCopy > 0)?wSizeToCopy:sizeof(USHORT);
				memcpy(&(varTemp.s),pbyData+nBufPos,wSizeToCopy);
				//check if the value is within range
				if((varTemp.s) < (vlLowLimit.s)
				|| (varTemp.s) > (vlHiLimit.s) )
				{
					LOG_ERR(CMM_qDebugR_MODE,(	"ValidateIntrinsicAndArrayDataType - %s short/ushort out of range (V:%d L:%d H:%d)" ),
												sIdentifierDetails.Fieldname,
												varTemp.s,
												vlLowLimit.s,
												vlHiLimit.s );
					//value out of range
					return CSTATUS_VALUE_OUT_OF_RANGE;			
				}				
			}//end of for loop
			*pwSize+=sizeof(USHORT)*wInstanceCount * wSubInstanceCount;
			break;		

		case REF_FLOAT:					
			//for(nNumInstances;nNumInstances < (wInstanceCount * wSubInstanceCount);
			//		nNumInstances++,nBufPos+= sizeof(float))
			{
				wSizeToCopy = (wSizeToCopy > 0)?wSizeToCopy:sizeof(FLOAT);
				memcpy(&(varTemp.f),pbyData+nBufPos,wSizeToCopy);
				//check if the value is within range
				if(varTemp.f < 0)
				{					
					if( ( fabs(varTemp.f) < fabs(vlLowLimit.f)) 
					||  (varTemp.f > vlHiLimit.f) )
					{
						LOG_ERR(CMM_qDebugR_MODE,(	"ValidateIntrinsicAndArrayDataType - %s float out of range (V:%f L:%f H:%f)" ),
													sIdentifierDetails.Fieldname,
													varTemp.f,
													vlLowLimit.f,
													vlHiLimit.f );
						//value out of range
						return CSTATUS_VALUE_OUT_OF_RANGE;			
					}
				}
				else
				{
					if(varTemp.f < vlLowLimit.f
					|| varTemp.f > vlHiLimit.f )
					{
						LOG_ERR(CMM_qDebugR_MODE,(	"ValidateIntrinsicAndArrayDataType - %s float out of range (V:%f L:%f H:%f)" ),
													sIdentifierDetails.Fieldname,
													varTemp.f,
													vlLowLimit.f,
													vlHiLimit.f );
						//value out of range
						return CSTATUS_VALUE_OUT_OF_RANGE;			
					}
				}							
			}//end of for loop
			*pwSize+=sizeof(float)*wInstanceCount * wSubInstanceCount;
			break;
		case REF_DOUBLE:
			//for(nNumInstances;nNumInstances < (wInstanceCount * wSubInstanceCount);
			//		nNumInstances++,nBufPos+= sizeof(double))
			{
				wSizeToCopy = (wSizeToCopy > 0)?wSizeToCopy:sizeof(double);
				memcpy(&(varTemp.d),pbyData+nBufPos,wSizeToCopy);
				//check if the value is within range
				if(varTemp.d < 0)
				{
					//
					// Stability Project Fix:
					//
					// Instead of abs() use fabs() to avoid loss of data from converting from float
					//
					if( ( fabs(varTemp.d) < fabs(vlLowLimit.d)) 
					||  (varTemp.d > vlHiLimit.d) )
					{
						LOG_ERR(CMM_qDebugR_MODE,(	"ValidateIntrinsicAndArrayDataType - %s double out of range (V:%f L:%f H:%f)" ),
													sIdentifierDetails.Fieldname,
													varTemp.d,
													vlLowLimit.d,
													vlHiLimit.d );
						//value out of range
						return CSTATUS_VALUE_OUT_OF_RANGE;			
					}
				}
				else
				{
					if(varTemp.d <vlLowLimit.d
					|| varTemp.d >vlHiLimit.d )
					{
						LOG_ERR(CMM_qDebugR_MODE,(	"ValidateIntrinsicAndArrayDataType - %s double out of range (V:%f L:%f H:%f)" ),
													sIdentifierDetails.Fieldname,
													varTemp.d,
													vlLowLimit.d,
													vlHiLimit.d );
						//value out of range
						return CSTATUS_VALUE_OUT_OF_RANGE;			
					}
				}			
			}//end of for loop
			*pwSize+=sizeof(double)*wInstanceCount * wSubInstanceCount;
			break;
		case REF_WORD:		
			//for(nNumInstances;nNumInstances < (wInstanceCount * wSubInstanceCount);
			//		nNumInstances++,nBufPos+= sizeof(WORD))
			{
				wSizeToCopy = (wSizeToCopy > 0)?wSizeToCopy:sizeof(WORD);
				memcpy(&(varTemp.w),pbyData+nBufPos,wSizeToCopy);
				//check if the value is within range
				if(varTemp.w <vlLowLimit.w
				|| varTemp.w >vlHiLimit.w )
				{
					LOG_ERR(CMM_qDebugR_MODE,(	"ValidateIntrinsicAndArrayDataType - %s word out of range (V:%u L:%u H:%u)" ),
												sIdentifierDetails.Fieldname,
												varTemp.w,
												vlLowLimit.w,
												vlHiLimit.w );
					//value out of range
					return CSTATUS_VALUE_OUT_OF_RANGE;			
				}				
			}//end of for loop
			*pwSize+=sizeof(WORD)*wInstanceCount * wSubInstanceCount;
			break;
		case REF_USHORT:
			//for(nNumInstances;nNumInstances < (wInstanceCount * wSubInstanceCount);
			//		nNumInstances++,nBufPos+= sizeof(USHORT))
			{
				wSizeToCopy = (wSizeToCopy > 0)?wSizeToCopy:sizeof(USHORT);
				memcpy(&(varTemp.us),pbyData+nBufPos,wSizeToCopy);
				//check if the value is within range
				if(varTemp.us <vlLowLimit.us
				|| varTemp.us >vlHiLimit.us )
				{
					LOG_ERR(CMM_qDebugR_MODE,(	"ValidateIntrinsicAndArrayDataType - %s USHORT out of range (V:%u L:%u H:%u)" ),
												sIdentifierDetails.Fieldname,
												varTemp.us,
												vlLowLimit.us,
												vlHiLimit.us );
					//value out of range
					return CSTATUS_VALUE_OUT_OF_RANGE;			
				}				
			}//end of for loop
			*pwSize+=sizeof(USHORT)*wInstanceCount * wSubInstanceCount;
			break;
		case REF_ULONG:
			//for(nNumInstances;nNumInstances < (wInstanceCount * wSubInstanceCount);
			//		nNumInstances++,nBufPos+= sizeof(ULONG))
			{
				wSizeToCopy = (wSizeToCopy > 0)?wSizeToCopy:sizeof(ULONG);
				memcpy(&(varTemp.ul),pbyData+nBufPos,wSizeToCopy);
				//check if the value is within range
				if(varTemp.ul <vlLowLimit.ul
				|| varTemp.ul >vlHiLimit.ul )
				{
					LOG_ERR(CMM_qDebugR_MODE,(	"ValidateIntrinsicAndArrayDataType - %s ULONG out of range (V:%lu L:%lu H:%lu)" ),
												sIdentifierDetails.Fieldname,
												varTemp.ul,
												vlLowLimit.ul,
												vlHiLimit.ul );
					//value out of range
					return CSTATUS_VALUE_OUT_OF_RANGE;			
				}				
			}//end of for loop
			*pwSize+=sizeof(ULONG)*wInstanceCount * wSubInstanceCount;
			break;
		case REF_DWORD:			
			//for(nNumInstances;nNumInstances < (wInstanceCount * wSubInstanceCount);
			//		nNumInstances++,nBufPos+= sizeof(DWORD))
			{
				wSizeToCopy = (wSizeToCopy > 0)?wSizeToCopy:sizeof(DWORD);
				memcpy(&(varTemp.dw),pbyData+nBufPos,wSizeToCopy);
				//check if the value is within range
				if(varTemp.dw <vlLowLimit.dw
				|| varTemp.dw >vlHiLimit.dw )
				{
					LOG_ERR(CMM_qDebugR_MODE,(	"ValidateIntrinsicAndArrayDataType - %s dword out of range (V:%u L:%u H:%u)" ),
												sIdentifierDetails.Fieldname,
												varTemp.dw,
												vlLowLimit.dw,
												vlHiLimit.dw );
					//value out of range
					return CSTATUS_VALUE_OUT_OF_RANGE;			
				}				
			}//end of for loop
			*pwSize+=sizeof(DWORD)*wInstanceCount * wSubInstanceCount;
			break;
		case REF_LONG:
		//case REF_ULONG:			
			//for(nNumInstances;nNumInstances < (wInstanceCount * wSubInstanceCount);
			//		nNumInstances++,nBufPos+= sizeof(LONG))
			{
				wSizeToCopy = (wSizeToCopy > 0)?wSizeToCopy:sizeof(LONG);
				memcpy(&(varTemp.l),pbyData+nBufPos,wSizeToCopy);
				//check if the value is within range
				if(varTemp.l <vlLowLimit.l
				|| varTemp.l >vlHiLimit.l )
				{
					LOG_ERR(CMM_qDebugR_MODE,(	"ValidateIntrinsicAndArrayDataType - %s Long out of range V:%ld L:%ld H:%ld)" ),
												sIdentifierDetails.Fieldname,
												varTemp.l,
												vlLowLimit.l,
												vlHiLimit.l );
					//value out of range
					return CSTATUS_VALUE_OUT_OF_RANGE;			
				}				
			}//end of for loop
			*pwSize+=sizeof(LONG)*wInstanceCount * wSubInstanceCount;
			break;
		case REF_TV_BOOL:
			{
				wSizeToCopy = (wSizeToCopy > 0)?wSizeToCopy:sizeof(TV_BOOL);				
				memcpy(&(varTemp.dw),pbyData+nBufPos,wSizeToCopy);
				//check if the value is within range
				if(varTemp.s <vlLowLimit.s
				|| varTemp.s >vlHiLimit.s )
				{
					LOG_ERR(CMM_qDebugR_MODE,(	"ValidateIntrinsicAndArrayDataType - %s TV_BOOL out of range (V:%u L:%u H:%u)" ),
												sIdentifierDetails.Fieldname,
												varTemp.s,
												vlLowLimit.s,
												vlHiLimit.s );
					//value out of range
					return CSTATUS_VALUE_OUT_OF_RANGE;			
				}				
			}
			*pwSize+=sizeof(TV_BOOL)*wInstanceCount * wSubInstanceCount;
			break;
		case REF_WCHAR:																	
			*pwSize+=sizeof(WCHAR)*wInstanceCount * wSubInstanceCount;
			break;		
		case REF_CHAR:
		case REF_TCHAR:
			*pwSize+=sizeof(char)* wInstanceCount * wSubInstanceCount;
			break;
		case REF_BUSHORT:
			{
				//is a bit field....
				//The pwStart argument gives the start position and 
				//the wInstanceCount gives the number of bits to be used
				if(NULL == pwStart)
				{
					LOG_ERR(CMM_qDebugR_MODE,("ValidateIntrinsicAndArrayDataType - %s bushort invalid bit start value"), sIdentifierDetails.Fieldname);
					return CSTATUS_FAIL;
				}
				
				varTemp.us = 0;
				memcpy(&(varTemp.us),pbyData,sizeof(USHORT));					
				USHORT wMask = 1;

				// Mask is created.
				for(USHORT wCreateMask = 0; wCreateMask < wInstanceCount; wCreateMask++)
				{
					wMask = wMask | (1 << wCreateMask);
				}

				// Get Mask to exact position
				wMask = wMask << *pwStart;

				// Get value from Source, low limit and High limit.				
				value valSourceValue;				
								
				valSourceValue.us = varTemp.us & wMask;				
				valSourceValue.us = valSourceValue.us >> *pwStart;

				if(valSourceValue.us < vlLowLimit.us
				|| valSourceValue.us > vlHiLimit.us )
				{
					LOG_ERR(CMM_qDebugR_MODE,("ValidateIntrinsicAndArrayDataType - %s bushort out of range"), sIdentifierDetails.Fieldname );
					//value out of range
					*pwStart += wInstanceCount;
					return CSTATUS_VALUE_OUT_OF_RANGE;			
				}				

				//fill the pwStart to the start of the next bit location
				if(wInstanceCount + *pwStart >= sizeof(SHORT) * SIZE_OF_BYTE)
				{
					//Size of the buffer... This will be used to move the pointer 
					//ONLY after all the bitfields have been validated
					*pwSize+=sizeof(SHORT);			
					*pwStart =0;	//all the bitfields have been read
				}
				else
				{
					*pwStart += wInstanceCount;
				}
			}
			break;
		case REF_BUCHAR:
			{
				//is a bit field....
				//The pwStart argument gives the start position and 
				//the wInstanceCount gives the number of bits to be used
				if(NULL == pwStart)
				{
					LOG_ERR(CMM_qDebugR_MODE,("ValidateIntrinsicAndArrayDataType - %s buchar invalid bit start value"), sIdentifierDetails.Fieldname );
					return CSTATUS_FAIL;
				}
							
				varTemp.uc = 0;
				memcpy(&(varTemp.uc),pbyData,sizeof(char));								
					
				UCHAR wMask = 1;

				// Mask is created.
				for(USHORT wCreateMask = 0; wCreateMask < wInstanceCount; wCreateMask++)
				{
					wMask = wMask | (1 << wCreateMask);
				}

				// Get Mask to exact position
				wMask = wMask << *pwStart;

				// Get value from Source, low limit and High limit.				
				value valSourceValue;				
								
				valSourceValue.uc = varTemp.uc & wMask;				
				valSourceValue.uc = valSourceValue.uc >> *pwStart;

				if(valSourceValue.uc < vlLowLimit.uc
				|| valSourceValue.uc > vlHiLimit.uc )
				{
					LOG_ERR(CMM_qDebugR_MODE,("ValidateIntrinsicAndArrayDataType - %s bushort out of range"), sIdentifierDetails.Fieldname );
					//value out of range
					*pwStart += wInstanceCount;
					return CSTATUS_VALUE_OUT_OF_RANGE;			
				}				

				//fill the pwStart to the start of the next bit location
				if(wInstanceCount + *pwStart >= sizeof(UCHAR) * SIZE_OF_BYTE)
				{
					//Size of the buffer... This will be used to move the pointer 
					//ONLY after all the bitfields have been validated
					*pwSize+=sizeof(UCHAR);			
					*pwStart =0;	//all the bitfields have been read
				}
				else
				{
					*pwStart += wInstanceCount;
				}
			}
			break;
		case REF_BULONG:
			{
				//is a bit field....
				//The pwStart argument gives the start position and 
				//the wInstanceCount gives the number of bits to be used
				if(NULL == pwStart)
				{
					LOG_ERR(CMM_qDebugR_MODE,("ValidateIntrinsicAndArrayDataType - %s bulong invalid bit start value"), sIdentifierDetails.Fieldname );
					return CSTATUS_FAIL;
				}
				
				varTemp.l = 0;
				memcpy(&(varTemp.l),pbyData+nBufPos,sizeof(LONG));					
				ULONG wMask = 1;

				// Mask is created.
				for(USHORT wCreateMask = 0; wCreateMask < wInstanceCount; wCreateMask++)
				{
					wMask = wMask | (1 << wCreateMask);
				}

				// Get Mask to exact position
				wMask = wMask << *pwStart;

				// Get value from Source, low limit and High limit.				
				value valSourceValue;				
								
				valSourceValue.ul = varTemp.ul & wMask;				
				valSourceValue.ul = valSourceValue.ul >> *pwStart;

				if(valSourceValue.ul < vlLowLimit.ul
				|| valSourceValue.ul > vlHiLimit.ul )
				{
					LOG_ERR(CMM_qDebugR_MODE,("ValidateIntrinsicAndArrayDataType - %s bushort out of range"), sIdentifierDetails.Fieldname );
					//value out of range
					*pwStart += wInstanceCount;
					return CSTATUS_VALUE_OUT_OF_RANGE;			
				}				

				//fill the pwStart to the start of the next bit location
				if(wInstanceCount + *pwStart >= sizeof(ULONG) * SIZE_OF_BYTE)
				{
					//Size of the buffer... This will be used to move the pointer 
					//ONLY after all the bitfields have been validated
					*pwSize+=sizeof(ULONG);			
					*pwStart =0;	//all the bitfields have been read
				}
				else
				{
					*pwStart += wInstanceCount;
				}
			}
			break;
		default:					
			LOG_ERR(CMM_qDebugR_MODE,("ValidateIntrinsicAndArrayDataType - End - Unsupported data type"));
			return CSTATUS_UNSUPPORTED_DATATYPE;			
	}
	LOG_INFO(CMM_qDebugR_MODE,("ValidateIntrinsicAndArrayDataType - CSTATUS_OK"));
#ifdef PWDLOGS_ENABLE	
	swprintf( szDbgMsg, L" CCMMUtility:: ValidateIntrinsicAndArrayDataType - CSTATUS_OK GTC %d\n",GetTickCount());
	OutputDebugString(szDbgMsg);
#endif
	return CSTATUS_OK;
}
//**********************************************************************
/// Defaults the individual member values within a data block.
///
/// @param[in]	pIdentifierDetails - The details of the member variable
///									as defined in the system metadata.
///
/// @param[in]	pbyData		  - Buffer to the start of the member variable
///									within the data block in the 
///									configuration file.							
///
/// @param[in]	wInstanceId 	  - Instance id of the block.
///
/// @param[out]	pwSize		 	  - Size of the member variable that has been
///									defaulted.
///
/// @param[out]	pwStart		 	  - The number of bits defaulted in case of 
///									bitfields. 
///									0 == all bits defaulted.
///									This parameter can be NULL when the datatype
///									is not a bitfield.
///
/// @return		Returns CSTATUS_OK on success, error code on failure
/// 
//**********************************************************************
CMMSTATUS CCMMUtility::DefaultIntrinsicAndArrayDataType(IDENTIFIER_RECORD_INFO * pIdentifierDetails,
														  BYTE * pbyData,
														  WORD wInstanceId,
														  WORD * pwSize,
														  WORD * pwStart)
{
	LOG_INFO(CMM_qDebugR_MODE,("DefaultIntrinsicAndArrayDataType - Start"));
#ifdef PWDLOGS_ENABLE	
	WCHAR szDbgMsg[512];
	swprintf( szDbgMsg, L" CCMMUtility:: DefaultIntrinsicAndArrayDataType - Start GTC %d\n",GetTickCount());
	OutputDebugString(szDbgMsg);
#endif
	if(NULL == pIdentifierDetails
		|| NULL == pbyData
		|| NULL == pwSize)
	{
		LOG_ERR(CMM_qDebugR_MODE,("DefaultIntrinsicAndArrayDataType - Invalid parameter"));
		return CSTATUS_INVALID_PARAMETER;
	}

	TV_BOOL bValid=FALSE;	//flag to indicate if data type is valid or not.
	value vlDefault = pIdentifierDetails->vdefault ;	//stores the default value
	value varTemp;	//temp buffer used for BITFIELD
	memset(&varTemp,0,sizeof(value));

	int nBitCount=0;
	int nPos=0;
	WORD wCopyCount=0;	//used for CHAR/TCHAR/WCHAR copy
	WORD wDataType = pIdentifierDetails->wDatatype ;	//stores the datatype
	WORD wInstanceCount = (pIdentifierDetails->wnumInst>0)?pIdentifierDetails->wnumInst:1;		
	WORD wSubInstanceCount = (pIdentifierDetails->wnumSubInst>0)?pIdentifierDetails->wnumSubInst:1;

	*pwSize=0;	//initialize size variable
	int nNumInstances=0;	//counter variable used in a for loop
	int nBufPos=0;		//offset variable to move the buffer position 

	//Tuesday, April 26, 2005 6:56:19 PM - Amar
	//The variable is used to control auto init of WCHAR arrays.
  enumWCLASS AUTOINIT = classStandard;//classAutoInitmember;

	switch(wDataType)
	{
		case REF_BYTE:
		case REF_UCHAR:	
			for(nNumInstances;nNumInstances < (wInstanceCount * wSubInstanceCount);
					nNumInstances ++,nBufPos++)
			{
				//default the value in the nNumInstances'th position
				memset(pbyData+nBufPos,vlDefault.b,sizeof(BYTE));				
			}//end of for loop			
			*pwSize+=sizeof(BYTE)*wInstanceCount * wSubInstanceCount;
			break;
		case REF_LONGLONG:			
			for(nNumInstances;nNumInstances < (wInstanceCount * wSubInstanceCount);
					nNumInstances++, nBufPos+= sizeof(LONGLONG))
			{
				//default the value in the nNumInstances'th position
				memcpy(pbyData+nBufPos,&(vlDefault.ll),sizeof(LONGLONG));								
			}//end of for loop
			*pwSize+=sizeof(LONGLONG)*wInstanceCount * wSubInstanceCount;
			break;
		case REF_ULONGLONG:
			for(nNumInstances;nNumInstances < (wInstanceCount * wSubInstanceCount);
					nNumInstances++,nBufPos+= sizeof(ULONGLONG))
			{
				//default the value in the nNumInstances'th position
				memcpy(pbyData+nBufPos,&(vlDefault.ull),sizeof(ULONGLONG));				
			}//end of for loop
			*pwSize+=sizeof(ULONGLONG)*wInstanceCount * wSubInstanceCount;
			break;
		case REF_SHORT:
		case REF_USHORT:	
			for(nNumInstances;nNumInstances < (wInstanceCount * wSubInstanceCount);
					nNumInstances++,nBufPos+= sizeof(SHORT))
			{
				//default the value in the nNumInstances'th position
				memcpy(pbyData+nBufPos,&(vlDefault.s),sizeof(SHORT));					
			}//end of for loop
			*pwSize+=sizeof(SHORT)*wInstanceCount * wSubInstanceCount;
			break;					
		case REF_FLOAT:					
			for(nNumInstances;nNumInstances < (wInstanceCount * wSubInstanceCount);
					nNumInstances++,nBufPos+= sizeof(FLOAT))
			{
				//default the value in the nNumInstances'th position
				memcpy(pbyData+nBufPos,&(vlDefault.f),sizeof(float));					
			}//end of for loop
			*pwSize+=sizeof(FLOAT)*wInstanceCount * wSubInstanceCount;
			break;
		case REF_DOUBLE:
			for(nNumInstances;nNumInstances < (wInstanceCount * wSubInstanceCount);
					nNumInstances++,nBufPos+= sizeof(double))
			{
				//default the value in the nNumInstances'th position
				memcpy(pbyData+nBufPos,&(vlDefault.d),sizeof(double));					
			}//end of for loop
			*pwSize+=sizeof(double)*wInstanceCount * wSubInstanceCount;
			break;
		case REF_WORD:
			for(nNumInstances;nNumInstances < (wInstanceCount * wSubInstanceCount);
					nNumInstances++,nBufPos+= sizeof(WORD))
			{
				//default the value in the nNumInstances'th position
				memcpy(pbyData+nBufPos,&(vlDefault.w),sizeof(WORD));				
			}//end of for loop
			*pwSize+=sizeof(WORD)*wInstanceCount * wSubInstanceCount;
			break;
		case REF_DWORD:																
			for(nNumInstances;nNumInstances < (wInstanceCount * wSubInstanceCount);
					nNumInstances++,nBufPos+= sizeof(DWORD))
			{
				//default the value in the nNumInstances'th position
				memcpy(pbyData+nBufPos,&(vlDefault.dw),sizeof(DWORD));				
			}//end of for loop
			*pwSize+=sizeof(DWORD)*wInstanceCount * wSubInstanceCount;
			break;
		case REF_LONG:
		case REF_ULONG:			
			for(nNumInstances;nNumInstances < (wInstanceCount * wSubInstanceCount);
					nNumInstances++,nBufPos+= sizeof(LONG))
			{
				//default the value in the nNumInstances'th position
				memcpy(pbyData+nBufPos,&(vlDefault.l),sizeof(LONG));				
			}//end of for loop
			*pwSize+=sizeof(LONG)*wInstanceCount * wSubInstanceCount;
			break;
		case REF_TV_BOOL:
			for(nNumInstances;nNumInstances < (wInstanceCount * wSubInstanceCount);
					nNumInstances++,nBufPos+= sizeof(TV_BOOL))
			{
				//default the value in the nNumInstances'th position
				memcpy(pbyData+nBufPos,&(vlDefault.w),sizeof(TV_BOOL));					
			}//end of for loop
			*pwSize+=sizeof(TV_BOOL)*wInstanceCount * wSubInstanceCount;
			break;
		case REF_WCHAR:																	
			if(0 >= pIdentifierDetails->wnumInst) 
			{
				//implicit wcharacter type.. assign the default value directly from the Default variable
				memcpy(pbyData,&(pIdentifierDetails->vdefault.wc),sizeof(WCHAR));
				*pwSize+=sizeof(WCHAR);			
			}
			else if(0 < pIdentifierDetails->wnumInst  
				&& 0==pIdentifierDetails->wnumSubInst )
			{
				//initialize the character array to NULL
				memset(pbyData,0,(pIdentifierDetails->wnumInst)*sizeof(WCHAR));

				//array of wchar characters.. the default characters follow the block type 
				//structure in the metadata the default variable in this case contains the 
				//size of the default string(excluding NULL character) that follows the block
				//type structure in the metadata.NULL character is not stored in the string 
				//that follows the block in the metadata.
				//In case of a single dimensional array the instance id should be appended
				//to the default value if and only if, the size of the new string does not
				//exceed the size specified in the metadata. If size exceeds, then the default
				//value without the isntance number should be stored.

				//create a temporary buffer to store the default value
				//+5 to include the instance number and includes NULL
				WORD wStringSize = ((pIdentifierDetails->vdefault .w)/sizeof(WCHAR))+INSTANCE_LENGTH;
				if(0 != wStringSize)
				{
					QString szTemp = new WCHAR[wStringSize];
					memset(szTemp,0,wStringSize * sizeof(WCHAR));

					//copy the default string into the memory
					memcpy(szTemp,
								(BYTE *)pIdentifierDetails+sizeof(IDENTIFIER_RECORD_INFO),
								pIdentifierDetails->vdefault .w);													

					//1. Size of default value without appending instance
					//the number of characters to be copied should at the max be number of instances -1.
				
					if(wcslen(szTemp) < pIdentifierDetails->wnumInst)
					{
						//appended string can be written to the buffer
						//sztemp contains only the default value without instance number
						wCopyCount = (WORD)(wcslen(szTemp) * sizeof(WCHAR));	//should be converted into bytes for memcopy
					}else
					{
						wCopyCount = (pIdentifierDetails->wnumInst * sizeof(WCHAR)) - sizeof(WCHAR);
					}

					
					//2. Size of default value after appending instance
					//convert instance number to string
					//This is done only if the class type is auto init
					if(AUTOINIT == classAutoInitmember)
					{
						WCHAR szInstance[INSTANCE_LENGTH];
						memset(szInstance ,0,INSTANCE_LENGTH * sizeof(WCHAR));
#if _MSC_VER < 1400 
						_itow(wInstanceId,szInstance,10);
#else
						_itow_s(wInstanceId,szInstance, INSTANCE_LENGTH, 10);	//store the current instance number as a string
#endif
						
										
						//the number of characters to be copied should at the max be number of instances -1.
						if((wcslen(szTemp) + wcslen(szInstance)) < pIdentifierDetails->wnumInst)
						{
							//length of string including the instance is less that space available.
							//so append the instance number
#if _MSC_VER < 1400 
							wcscat(szTemp, szInstance);
#else
							wcscat_s(szTemp, wStringSize, szInstance);
#endif
						
							wCopyCount = (WORD)(wcslen(szTemp) * sizeof(WCHAR));
						}/*else
							leave the copy count as calculated in the first step.*/
					}
					
					if(0!=wCopyCount)
					{
						memcpy(pbyData,
								(BYTE *)szTemp,
								wCopyCount);			
					}

					//deleting the temporary buffer
					delete [] szTemp;
				}//end of wStringSize if
				*pwSize+=sizeof(WCHAR)*wInstanceCount * wSubInstanceCount;			
			}else
			{
				memset (pbyData, 0 , wInstanceCount * wSubInstanceCount * sizeof(WCHAR));
				//two dimesional array containing array of strings
				//create a temporary buffer to store the default value
				//+5 to include the instance counter and includes NULL
				WORD wStringSize = ((pIdentifierDetails->vdefault .w)/sizeof(WCHAR))+INSTANCE_LENGTH;
				QString szTemp = new WCHAR[wStringSize];
				memset(szTemp,0,wStringSize * sizeof(WCHAR));

				//loop through each of the instances
				for(nNumInstances;nNumInstances < wInstanceCount;
						nNumInstances++,nBufPos+= (sizeof(WCHAR)*wSubInstanceCount))
				{
					WCHAR szCount[INSTANCE_LENGTH];//9999 instances allowed
					memset(szCount ,0,INSTANCE_LENGTH  * sizeof(WCHAR));
#if _MSC_VER < 1400 
					_itow(nNumInstances+1, szCount, 10);	//store the current instance number as a string
#else
					_itow_s(nNumInstances+1, szCount, INSTANCE_LENGTH, 10);	//store the current instance number as a string
#endif
					
					//set all values in buffer to NULL character
					memset(szTemp,0,pIdentifierDetails->vdefault .w+(INSTANCE_LENGTH * sizeof(WCHAR)));	

					//copy the default value to the temporary buffer
					memcpy(szTemp,
							(BYTE *)pIdentifierDetails+sizeof(IDENTIFIER_RECORD_INFO),
							pIdentifierDetails->vdefault .w);

					//1. Size of default value without appending instance
					//the number of characters to be copied should at the max be number of sub instances -1.
					if(wcslen(szTemp) < pIdentifierDetails->wnumSubInst)
					{
						//appended string can be written to the buffer
						//sztemp contains only the default value without instance number
						wCopyCount = (WORD)(wcslen(szTemp) * sizeof(WCHAR));	//should be converted into bytes for memcopy
					}else
					{
						wCopyCount = (pIdentifierDetails->wnumSubInst * sizeof(WCHAR)) - sizeof(WCHAR);
					}

					//check if auto init of the WCHAR arrays is required
					if(/*pIdentifierDetails->wclass*/AUTOINIT == classAutoInitmember)
					{
						//the number of characters to be copied should at the max be number of instances -1.
						if((wcslen(szTemp) + wcslen(szCount)) < pIdentifierDetails->wnumSubInst)
						{
							//length of string including the instance is less that space available.
							//concatenate the instance count to the default value
#if _MSC_VER < 1400 
							wcscat(szTemp, szCount);
#else
							wcscat_s(szTemp, wStringSize, szCount);			
#endif

							wCopyCount = (WORD)(wcslen(szTemp) * sizeof(WCHAR));
						}/*else
							leave the copy count as calculated in the first step.*/
					}	
					if(0!=wCopyCount)
					{
						//default the value in temporary buffer to the varNumSubInstances'th position
						memcpy(pbyData+nBufPos,
								szTemp,
								wCopyCount);	
						
					}
					//since the buffer has been initialized with NULL characters, no need to explicity copy
					//the NULL character at the end of the string					
				}//end for loop
				
				//deleting the temporary buffer
				delete [] szTemp;
				*pwSize+=sizeof(WCHAR)*wInstanceCount * wSubInstanceCount;
			}
			
			break;		
		case REF_CHAR:
		case REF_TCHAR:
			if(0 >= pIdentifierDetails->wnumInst) 
			{
				//implicit wcharacter type.. assign the default value directly from the Default variable
				memcpy(pbyData,&(pIdentifierDetails->vdefault.c),sizeof(char));
				*pwSize+=sizeof(char);			
			}else if(0 < pIdentifierDetails->wnumInst  
				&& 0==pIdentifierDetails->wnumSubInst )
			{
				//initialize the character array to NULL
				memset(pbyData,0,(pIdentifierDetails->wnumInst)*sizeof(char));

				//array of wchar characters.. the default characters follow the block type 
				//structure in the metadata the default variable in this case contains the 
				//size of the default string(excluding NULL character) that follows the block
				//type structure in the metadata.NULL character is not stored in the string 
				//that follows the block in the metadata.
				//In case of a single dimensional array the instance id should be appended
				//to the default value if and only if, the size of the new string does not
				//exceed the size specified in the metadata. If size exceeds, then the default
				//value without the isntance number should be stored.

				//create a temporary buffer to store the default value
				//+5 to include the instance number and includes NULL
				WORD wStringSize = (pIdentifierDetails->vdefault .w)+INSTANCE_LENGTH;
				if(0 != wStringSize)
				{
					char *szTemp = new char[wStringSize];
					memset(szTemp,0,wStringSize * sizeof(char));

					//copy the default string into the memory
					memcpy(szTemp,
								(BYTE *)pIdentifierDetails+sizeof(IDENTIFIER_RECORD_INFO),
								pIdentifierDetails->vdefault .w);													

					//1. Size of default value without appending instance
					//the number of characters to be copied should at the max be number of instances -1.
					if(strlen(szTemp) < pIdentifierDetails->wnumInst)
					{
						//appended string can be written to the buffer
						//sztemp contains only the default value without instance number
						wCopyCount = (WORD)(strlen(szTemp) * sizeof(char));	//should be converted into bytes for memcopy
					}else
					{
						wCopyCount = (pIdentifierDetails->wnumInst * sizeof(char)) - sizeof(char);
					}

					//2. Size of default value after appending instance
					//convert instance number to string

					//check if auto init of the WCHAR arrays is required
					if(/*pIdentifierDetails->wclass*/AUTOINIT == classAutoInitmember)
					{
						char szInstance[INSTANCE_LENGTH];
						memset(szInstance ,0,INSTANCE_LENGTH * sizeof(char));
#if _MSC_VER < 1400 
						_itoa(wInstanceId,szInstance, 10);	//store the current instance number as a string
#else
						_itoa_s(wInstanceId,szInstance, INSTANCE_LENGTH, 10);	//store the current instance number as a string	
#endif
	
											
						//the number of characters to be copied should at the max be number of instances -1.
						if((strlen(szTemp) + strlen(szInstance)) < pIdentifierDetails->wnumInst)
						{
							//length of string including the instance is less that space available.
							//so append the instance number
#if _MSC_VER < 1400 
							strcat(szTemp, szInstance);	
#else
							strcat_s(szTemp, wStringSize, szInstance);	
#endif
	
							wCopyCount = (WORD)(strlen(szTemp) * sizeof(char));
						}/*else
							leave the copy count as calculated in the first step.*/
					}

					if(0!=wCopyCount)
					{
						memcpy(pbyData,
								(BYTE *)szTemp,
								wCopyCount);			
					}

					//deleting the temporary buffer
					delete [] szTemp;
				}//end of wStringSize if
				*pwSize+=sizeof(char)*wInstanceCount * wSubInstanceCount;
			}else
			{
				memset (pbyData, 0 , wInstanceCount * wSubInstanceCount * sizeof(char));

				//two dimesional array containing array of strings
				//create a temporary buffer to store the default value
				//+5 to include the instance counter and includes NULL
				char *szTemp = new char[pIdentifierDetails->vdefault .w+INSTANCE_LENGTH ];
				memset(szTemp,0,(pIdentifierDetails->vdefault .w+INSTANCE_LENGTH) * sizeof(char));

				//loop through each of the instances
				for(nNumInstances;nNumInstances < wInstanceCount;
						nNumInstances++,nBufPos+= (sizeof(char)*wSubInstanceCount))
				{
					char szCount[INSTANCE_LENGTH];//9999 instances allowed
					memset(szCount,0,(INSTANCE_LENGTH) * sizeof(char));
#if _MSC_VER < 1400 
					_itoa(nNumInstances+1,szCount,10);	//store the current instance number as a string	
#else
					_itoa_s(nNumInstances+1,szCount,INSTANCE_LENGTH, 10);	//store the current instance number as a string	
#endif					
	
					
					//set all values in buffer to NULL character
					memset(szTemp,0,pIdentifierDetails->vdefault .w+(INSTANCE_LENGTH * sizeof(char)));	

					//copy the default value to the temporary buffer
					memcpy(szTemp,
							(BYTE *)pIdentifierDetails+sizeof(IDENTIFIER_RECORD_INFO),
							pIdentifierDetails->vdefault .w);					

					//1. Size of default value without appending instance
					//the number of characters to be copied should at the max be number of sub instances -1.
					if(strlen(szTemp) < pIdentifierDetails->wnumSubInst)
					{
						//appended string can be written to the buffer
						//sztemp contains only the default value without instance number
						wCopyCount = (WORD)(strlen(szTemp) * sizeof(char));	//should be converted into bytes for memcopy
					}else
					{
						wCopyCount = (pIdentifierDetails->wnumSubInst * sizeof(char)) - sizeof(char);
					}
					
					//check if auto init of the WCHAR arrays is required
					if(/*pIdentifierDetails->wclass*/AUTOINIT == classAutoInitmember)
					{
						//the number of characters to be copied should at the max be number of instances -1.
						if((strlen(szTemp) + strlen(szCount)) < pIdentifierDetails->wnumSubInst)
						{
							//length of string including the instance is less that space available.
							//concatenate the instance count to the default value
#if _MSC_VER < 1400 
							strcat(szTemp,szCount);
#else
							strcat_s(szTemp,pIdentifierDetails->vdefault .w+INSTANCE_LENGTH,szCount);	
#endif
	
							wCopyCount = (WORD)(strlen(szTemp) * sizeof(char));
						}/*else
							leave the copy count as calculated in the first step.*/
					}

					if(0!=wCopyCount)
					{
						//default the value in temporary buffer to the varNumSubInstances'th position
						memcpy(pbyData+nBufPos,
								szTemp,
								wCopyCount);	

					}
					//since the buffer has been initialized with NULL characters, no need to explicity copy
					//the NULL character at the end of the string					
				}//end for loop

				//deleting the temporary buffer
				delete [] szTemp;
				
				*pwSize+=sizeof(char)*wInstanceCount * wSubInstanceCount;
			}
			break;
		case REF_BUSHORT:
		{
			//is a bit field....
			//The pwStart argument gives the start position and 
			//the wInstanceCount gives the number of bits to be defaulted
			if(NULL == pwStart)
			{
				LOG_ERR(CMM_qDebugR_MODE,("DefaultIntrinsicAndArrayDataType - invalid bushort bit start value"));
				return CSTATUS_FAIL;
			}
			
			varTemp.us = 0;
			//copy the currently availabe value for the entire bitfields shared withing a datatype
			memcpy(&(varTemp.us),pbyData,sizeof(USHORT));								

			USHORT wMask=0;
			nBitCount =0 ;
			for(nBitCount,nPos;nBitCount < wInstanceCount;nBitCount ++)
			{
				//create the mask for the number of bits required
				wMask = wMask | (1 << nBitCount);
				//so if 3 bit mask has to be created, it would be 0000 0111'b
			}
			
			//1.and it with bit mask to get exact number of bits
			//2.left shift the value to place it in the exact start location
			//3.OR it with the value currently stored in config memory to retain
			//  values previsoulty stored in other bit locations
			varTemp.us = ((vlDefault.us & wMask) << *pwStart) | varTemp.us	;						

			//Size of the buffer... This will be used to move the pointer 
			//ONLY after all the bitfields have been validated
			*pwSize+=sizeof(SHORT);

			memcpy(pbyData,&(varTemp.us),sizeof(USHORT));

			//fill the pwStart to the start of the next bit location
			if(wInstanceCount + *pwStart >= sizeof(SHORT) * SIZE_OF_BYTE)
				*pwStart =0;	//all the bitfields have been read
			else
				*pwStart += wInstanceCount;
			break;
		}
		case REF_BUCHAR:
		{
			//is a bit field....
			//The pwStart argument gives the start position and 
			//the wInstanceCount gives the number of bits to be defaulted
			if(NULL == pwStart)
			{
				LOG_ERR(CMM_qDebugR_MODE,("DefaultIntrinsicAndArrayDataType - invalid buchar bit start value"));
				return CSTATUS_FAIL;
			}
			
			varTemp.c = 0;
			memcpy(&(varTemp.c),pbyData,sizeof(char));							

			BYTE bMask=0;
			nBitCount =0 ;
			for(nBitCount,nPos;nBitCount < wInstanceCount;nBitCount ++)
			{
				//create the mask for the number of bits required
				bMask = bMask | (1 << nBitCount);
				//so if 3 bit mask has to be created, it would be 0000 0111'b
			}
			
			//1.and it with bit mask to get exact number of bits
			//2.left shift the value to place it in the exact start location
			//3.OR it with the value currently stored in config memory to retain
			//  values previsoulty stored in other bit locations
			varTemp.c = ((vlDefault.c  & bMask) << *pwStart) | varTemp.c	;						

			//Size of the buffer... This will be used to move the pointer 
			//ONLY after all the bitfields have been validated
			*pwSize+=sizeof(char);

			memcpy(pbyData,&(varTemp.c),sizeof(char));					

			//fill the pwStart to the start of the next bit location
			if(wInstanceCount + *pwStart >= sizeof(char) * SIZE_OF_BYTE)
				*pwStart =0;	//all the bitfields have been read
			else
				*pwStart += wInstanceCount;
			break;
		}
		case REF_BULONG:
		{
			//is a bit field....
			//The pwStart argument gives the start position and 
			//the wInstanceCount gives the number of bits to be defaulted
			if(NULL == pwStart)
			{
				LOG_ERR(CMM_qDebugR_MODE,("DefaultIntrinsicAndArrayDataType - invalid bulong bit start value"));
				return CSTATUS_FAIL;
			}
			
			varTemp.l = 0;
			//copy the currently availabe value for the entire bitfields shared withing a datatype
			memcpy(&(varTemp.l),pbyData,sizeof(LONG));								

			
			ULONG lMask=0;
			nBitCount =0 ;
			for(nBitCount,nPos;nBitCount < wInstanceCount;nBitCount ++)
			{
				//create the mask for the number of bits required
				lMask = lMask | (1 << nBitCount);
				//so if 3 bit mask has to be created, it would be 0000 0111'b
			}
			
			//1.and it with bit mask to get exact number of bits
			//2.left shift the value to place it in the exact start location
			//3.OR it with the value currently stored in config memory to retain
			//  values previsoulty stored in other bit locations
			varTemp.l = ((vlDefault.l & lMask) << *pwStart) | varTemp.l;							

			//Size of the buffer... This will be used to move the pointer 
			//ONLY after all the bitfields have been validated
			*pwSize+=sizeof(LONG);

			memcpy(pbyData,&(varTemp.l),sizeof(LONG));

			//fill the pwStart to the start of the next bit location
			if(wInstanceCount + *pwStart >= sizeof(LONG) * SIZE_OF_BYTE)
				*pwStart =0;	//all the bitfields have been read
			else
				*pwStart += wInstanceCount;
			break;
		}
		default:					
		{
			LOG_ERR(CMM_qDebugR_MODE,("DefaultIntrinsicAndArrayDataType - End - Unsupported data type"));
			return CSTATUS_UNSUPPORTED_DATATYPE;			
		}
	}
	LOG_INFO(CMM_qDebugR_MODE,("DefaultIntrinsicAndArrayDataType - CSTATUS_OK"));
#ifdef PWDLOGS_ENABLE	
	swprintf( szDbgMsg, L" CCMMUtility:: DefaultIntrinsicAndArrayDataType - CSTATUS_OK GTC %d\n",GetTickCount());
	OutputDebugString(szDbgMsg);
#endif
	return CSTATUS_OK;
}
//**********************************************************************
/// Defaults the data block by setting the values of members 
///	in the block to the values specified as default in the 
///	system metadata.
///
/// @param[in]	dwConfigurationId - The configuration id of the block 
///									which has to be validated.
///
/// @param[in]	wBlockType 		  - Block Type of the block to be 
///									validated.
///
/// @param[in]	pbyData		  - Buffer to the start of the data block
///									(without header) in the configuration
///									file.
/// @param[in]	wInstanceId 	  - Instance id of the block
///
/// @return		Returns CSTATUS_OK on success, error code on failure
/// 
//**********************************************************************
CMMSTATUS CCMMUtility::DefaultDataBlock(DWORD dwConfigurationId, 
										WORD wBlockType, 
										BYTE * pbyData,
										WORD wInstanceId)
{
	
	LOG_INFO(CMM_qDebugR_MODE,("DefaultDataBlock - Start"));
#ifdef PWDLOGS_ENABLE
	WCHAR szDbgMsg[512];
	swprintf( szDbgMsg, L" CCMMUtility::DefaultDataBlock - Start GTC %d\n",GetTickCount());
	OutputDebugString(szDbgMsg);
#endif
	CMMSTATUS eCmmStatus;	//buffer to store the status of the operations
	/**Step 0: Check the arguments*/
	/******************************/
	if(NULL == pbyData)
	{
		LOG_ERR(CMM_qDebugR_MODE,("DefaultDataBlock - End - Invalid Parameter"));
		return CSTATUS_INVALID_PARAMETER;
	}
	try
	{
		/**Step 1: Check if the block type is a structure/union/variable data type*/
		/**************************************************************************/
		//1. variable data type
		if(VARIABLE_BASE <= wBlockType)
		{
			//union/variable data type need not be defaulted. return success
			LOG_INFO(CMM_qDebugR_MODE,("DefaultDataBlock - Success - Variable Data Type"));
			return CSTATUS_OK;
		}

		BYTE * pBlockIdentifierDetails = NULL;
		//2. union data type
		eCmmStatus = glbObjMemoryManager .GetBlock (SYSTEM_CONFIGURATION_ID ,
																	wBlockType,
																	&pBlockIdentifierDetails);
		if(eCmmStatus != CSTATUS_OK)
		{
			LOG_INFO(CMM_qDebugR_MODE,("DefaultDataBlock - End - Unable to get main block info"));
			return eCmmStatus;
		}else
		{
			IDENTIFIER_RECORD_INFO * pDefinition = (IDENTIFIER_RECORD_INFO *) pBlockIdentifierDetails;
			if(classUnion == pDefinition->wclass)
			{
				//unions need not be defaulted. return success
				LOG_INFO(CMM_qDebugR_MODE,("DefaultDataBlock - Success - Union"));
#ifdef PWDLOGS_ENABLE
				swprintf( szDbgMsg, L" CCMMUtility::DefaultDataBlock - success - Union GTC %d\n",GetTickCount());
				OutputDebugString(szDbgMsg);
#endif
				return CSTATUS_OK;
			}
		}
		
		BYTE * pByDataBuffer = pbyData; //buffer to the first member past the datablock header
		
		/**Step 2: Get all the identifiers details of the block type*/
		/************************************************************/
		DWORD dwIdentifierCount=0;		//buffer to store the number of identifiers in given block
		BYTE ** ppByIdentifiersPos=NULL;	//buffer to store the pointer to the identifier details from metadata
		eCmmStatus = glbObjMemoryManager.GetEnumIdentifier (SYSTEM_CONFIGURATION_ID,
																wBlockType,
																&dwIdentifierCount,
																&ppByIdentifiersPos);
		if(CSTATUS_OK != eCmmStatus )
		{
			LOG_ERR(CMM_qDebugR_MODE,("DefaultDataBlock - End - Unable to get block types enumeration"));
			return eCmmStatus;
		}

		WORD wStart=0;	//used only for BITFIELDS

		/**Step 3: Get the datatype/range of each member and compare*/
		/************************************************************/
		for(DWORD dwNumIdentifiers=0;dwNumIdentifiers < dwIdentifierCount;dwNumIdentifiers++)
		{	
			BYTE * pByBuffer=NULL;	//temporary buffer			
			pByBuffer = ppByIdentifiersPos[dwNumIdentifiers];

			//copy the buffer to a structure
			IDENTIFIER_RECORD_INFO * pIdentifierDetails;
			pIdentifierDetails = (IDENTIFIER_RECORD_INFO *)pByBuffer;

			/**Step 4: For nested structures call the function recursively*/
			/**************************************************************/
			if(classUnionmember == pIdentifierDetails->wclass
				|| VARIABLE_BASE <= pIdentifierDetails->wDatatype )
			{
				//NOTE: variable data types have datatypes greater than 50000
				/**********************************************/
				//Note: Embedded Unions and variable data types
				//Note: need not be defaulted.
				/**********************************************/
				//implies nested objects - unions
				//There can be more than one instance of a structure..(SubInstance not applicable for structures)
				//buffer to store number of structure instances -- if equal to 0 => 1 instance
				WORD wInstanceCount = (pIdentifierDetails->wnumInst>0)?pIdentifierDetails->wnumInst:1;	
				//move the buffer pointer to point to the next structure 
				//get the size of the union object
				DWORD dwBlockSize=0;
				glbObjMemoryManager.GetBlockSize(SYSTEM_CONFIGURATION_ID,
													pIdentifierDetails ->wDatatype,
													&dwBlockSize);
				
				pByDataBuffer  = pByDataBuffer  + dwBlockSize*wInstanceCount;
				wStart=0;
				continue;
			}else if(classStructmember == pIdentifierDetails->wclass )
			{
				//implies nested objects - structures 
				//There can be more than one instance of a structure..(SubInstance not applicable for structures)
				//buffer to store number of structure instances -- if equal to 0 => 1 instance
				WORD wInstanceCount = (pIdentifierDetails->wnumInst>0)?pIdentifierDetails->wnumInst:1;	

				//get the size of a given block type
				DWORD dwBlockSize=0;
				glbObjMemoryManager.GetBlockSize(SYSTEM_CONFIGURATION_ID,
													pIdentifierDetails ->wDatatype,
													&dwBlockSize);

				//each instance of the structure has to be defaulted one by one
				for(int nNumInstance=0;nNumInstance < wInstanceCount;nNumInstance ++)
				{
					eCmmStatus = DefaultDataBlock(dwConfigurationId,
														pIdentifierDetails ->wDatatype, 
														pByDataBuffer,
														wInstanceId);

					if(CSTATUS_OK != eCmmStatus )
					{
						//TBD::Tracer log to be added here
						if(NULL!=ppByIdentifiersPos)
							LocalFree(ppByIdentifiersPos);				//delete the array of byte pointers

						LOG_ERR(CMM_qDebugR_MODE,("DefaultDataBlock - End - Embedded DefaultDataBlock failed : %d"),eCmmStatus);

						return eCmmStatus;
					}				
					//move the buffer pointer to point to the next structure 					
					pByDataBuffer = pByDataBuffer + dwBlockSize;

				}//end of for loop
				wStart=0;
			}else
			{
				/**Step 5: For intrinsic datatypes and arrays default one member at a time*/
				/**************************************************************************/
				WORD wBlockSize=0;		//buffer to store the block size, to move the pointer to the next block				
				/********************************************************************/
				//Note : The variable pwStart will be used by the function
				//Note : DefaultIntrinsicAndArrayDataType in case of BITField oprts.
				//Note : In that case the pointer should not be moved to the next 
				//Note : data member until the pwStart = 0
				/********************************************************************/
				//an array and intrinsic type
				eCmmStatus = DefaultIntrinsicAndArrayDataType(pIdentifierDetails,
																pByDataBuffer,
																wInstanceId,
																&wBlockSize,
																&wStart);				
				
				if(CSTATUS_OK != eCmmStatus )
				{
					//TBD::Tracer log to be added here
					if(NULL!=ppByIdentifiersPos)
						LocalFree(ppByIdentifiersPos);				//delete the array of byte pointers

					LOG_ERR(CMM_qDebugR_MODE,("DefaultDataBlock - DefaultInstrinsicandArraytypes failed : %d"),eCmmStatus);

					return eCmmStatus;
				}

				/**Step 6: Move the pointer to the next block member */
				/*****************************************************/
				if(0 == wStart)
					pByDataBuffer = pByDataBuffer + wBlockSize;
			}
		}//end of for loop

		/**Step 7: Cleanup memory allocated to store identifier*/
		/*******************************************************/
		if(NULL!=ppByIdentifiersPos)
		{			
			LocalFree(ppByIdentifiersPos);				//delete the array of byte pointers
		}
		LOG_INFO(CMM_qDebugR_MODE,("DefaultDataBlock - CSTATUS_OK"));
#ifdef PWDLOGS_ENABLE
		swprintf( szDbgMsg, L" CCMMUtility::DefaultDataBlock - CSTATUS_OK GTC %d\n",GetTickCount());
		OutputDebugString(szDbgMsg);
#endif
		return CSTATUS_OK;
	}catch(...)
	{
		//TBD::add proper Exception Handling
		LOG_ERR(CMM_qDebugR_MODE,("DefaultDataBlock - Exception - LastError : %d"),GetLastError());
		return CSTATUS_FAIL;
	}
}


CMMSTATUS CCMMUtility::ValidateBitFields(IDENTIFIER_RECORD_INFO* pIdentfierRecord, BYTE* pSrcPtr, WORD dwPosition, WORD wInstanceCount, WORD* wShiftPosition)
{
	value varTemp;

	switch(pIdentfierRecord->wDatatype)
	{
		case REF_BUSHORT:
		{				
			varTemp.us = 0;
			memcpy(&(varTemp.us),pSrcPtr,sizeof(USHORT));					
			USHORT wMask = 1;

			// Mask is created.
			for(USHORT wCreateMask = 0; wCreateMask < wInstanceCount; wCreateMask++)
			{
				wMask = wMask | (1 << wCreateMask);
			}

			// Get Mask to exact position
			wMask = wMask << dwPosition;

			// Get value from Source, low limit and High limit.			
			value valSourceValue;		
			
			valSourceValue.us = varTemp.us & wMask;				
			valSourceValue.us = valSourceValue.us >> dwPosition;			

			if(valSourceValue.us < pIdentfierRecord->Lowlmt.us
			|| valSourceValue.us > pIdentfierRecord->Hilmt.us )
			{
				LOG_ERR(CMM_qDebugR_MODE,("ValidateIntrinsicAndArrayDataType - bushort out of range"));
				*wShiftPosition = *wShiftPosition + wInstanceCount;
				//value out of range					
				return CSTATUS_VALUE_OUT_OF_RANGE;			
			}	
			break;
		}

		case REF_BULONG:
		{				
			varTemp.ul = 0;
			memcpy(&(varTemp.ul),pSrcPtr,sizeof(ULONG));					
			ULONG wMask = 1;

			// Mask is created.
			for(USHORT wCreateMask = 0; wCreateMask < wInstanceCount; wCreateMask++)
			{
				wMask = wMask | (1 << wCreateMask);
			}

			// Get Mask to exact position
			wMask = wMask << dwPosition;

			// Get value from Source, low limit and High limit.			
			value valSourceValue;		
			
			valSourceValue.ul = varTemp.ul & wMask;				
			valSourceValue.ul = valSourceValue.ul >> dwPosition;			

			if(valSourceValue.ul < pIdentfierRecord->Lowlmt.ul
			|| valSourceValue.ul > pIdentfierRecord->Hilmt.ul )
			{
				LOG_ERR(CMM_qDebugR_MODE,("ValidateIntrinsicAndArrayDataType - bushort out of range"));
				*wShiftPosition = *wShiftPosition + wInstanceCount;
				//value out of range					
				return CSTATUS_VALUE_OUT_OF_RANGE;			
			}	
			break;
		}

		case REF_BUCHAR:
		{				
			varTemp.uc = 0;
			memcpy(&(varTemp.uc),pSrcPtr,sizeof(UCHAR));					
			UCHAR wMask = 1;

			// Mask is created.
			for(USHORT wCreateMask = 0; wCreateMask < wInstanceCount; wCreateMask++)
			{
				wMask = wMask | (1 << wCreateMask);
			}

			// Get Mask to exact position
			wMask = wMask << dwPosition;

			// Get value from Source, low limit and High limit.			
			value valSourceValue;		
			
			valSourceValue.uc = varTemp.uc & wMask;				
			valSourceValue.uc = valSourceValue.uc >> dwPosition;			

			if(valSourceValue.uc < pIdentfierRecord->Lowlmt.uc
			|| valSourceValue.uc > pIdentfierRecord->Hilmt.uc )
			{
				LOG_ERR(CMM_qDebugR_MODE,("ValidateIntrinsicAndArrayDataType - bushort out of range"));
				*wShiftPosition = *wShiftPosition + wInstanceCount;
				//value out of range					
				return CSTATUS_VALUE_OUT_OF_RANGE;			
			}	
			break;
		}

		default:
			break;
	}

	return CSTATUS_OK;
}

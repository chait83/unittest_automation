/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Utility module
/// @n Filename: utility.h
/// @n Desc:	 Macro's and helpers for common conversion and tasks
///
// 
//  ****************************************************************
//  Revision History
//  ****************************************************************
//  $Log[4]:
// 4   Stability Project 1.1.1.1  7/2/2011 5:02:24 PM   Hemant(HAIL) 
//    Stability Project: Recorder source has been upgraded from IL
//    version of firmware to JF version of firmware.
// 3   Stability Project 1.1.1.0  7/1/2011 4:26:56 PM   Hemant(HAIL) 
//    Stability Project: Files has been checked in before the merging
//    task. The merging will be done between IL version of firmware and JF
//    version of firmware. 
// 2   V6 Firmware 1.1    5/13/2005 3:42:31 PM  Andy Kassell 
//    Remove all code from utility, this file will eventually be deleted
// 1   V6 Firmware 1.0    8/12/2004 4:54:21 PM  Andy Kassell  
//  $
//
//  ****************************************************************

#ifndef __UTILITY_H__
#define __UTILITY_H__

#endif // __UTILITY_H__

/// @file 
/// ****************************************************************
/// Â© Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Configuration Manager
/// @n Filename: ConfigurationManager.h
/// @n Desc:	 Function declarations of the exposed C APIs for 
///				 configuration management
///
//  ****************************************************************
//  Revision History
//  ****************************************************************
//  $Log[1]:
// 8 Aristos  1.4.1.1.1.0  9/19/2011 6:06:17 PM  Hemant(HAIL) 
//  Source updated for WDT functionality
//  $
//
//  ****************************************************************
/******************************************************************************************
 COPYRIGHT (c) 2004
 HONEYWELL INC.,
 ALL RIGHTS RESERVED
 This software is a copyrighted work and/or information protected
 as a trade secret. Legal rights of Honeywell Inc. in this
 software is distinct from ownership of any medium in which the
 software is embodied. Copyright or trade secret notices included
 must be reproduced in any copies authorized by Honeywell Inc.
 The information in this software is subject to change without
 notice and should not be considered as a commitment by Honeywell
 Inc.
 ******************************************************************************************/

// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the CONFIGURATIONMANAGER_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// CONFIGURATIONMANAGER_API functions as being imported from a DLL, wheras this DLL sees symbols
// defined with this macro as being exported.
#pragma once 
#ifdef __cplusplus
extern "C" {
#endif
#include "CMMDefines.h"
#define CMM_API
typedef void (*PFnUpdateThreadCounter)(int);
typedef void (*PFnUpdateThreadInfo)(int, bool);

CMMERROR CMM_API Initialize(QString tchHostType, ULONG lSerialNumber, BYTE *pByMetadata, DWORD *pdwSystemVersion);
CMMERROR CMM_API CreateConfiguration(DWORD *dwConfigurationID, DWORD *pdwSessionNumber);
CMMERROR CMM_API AllocateBuffer(DWORD dwConfigurationID, DWORD dwBufferSize, BYTE **pByBuffer);
CMMERROR CMM_API LoadConfiguration(DWORD dwConfigurationID, TV_BOOL bPersistedLoad, DWORD *pdwConfigVersion);
CMMERROR CMM_API CommitConfiguration(DWORD dwConfigurationID);
CMMERROR CMM_API ClearConfiguration(DWORD dwConfigurationID);
CMMERROR CMM_API DiscardChanges(DWORD dwConfigurationID);
CMMERROR CMM_API DeleteConfiguration(DWORD dwConfigurationID);
CMMERROR CMM_API IsConfigurationAvailable(DWORD dwConfigurationID, WORD wReference);
CMMERROR CMM_API GetConfiguration(DWORD dwConfigurationID, DWORD *pdwBufferSize, BYTE **pByBuffer);
CMMERROR CMM_API CreateDataBlock(DWORD dwConfigurationID, BLOCK_INFO *pBlockDetails);
CMMERROR CMM_API GetDataBlock(DWORD dwConfigurationID, BLOCK_INFO *pBlockDetails, WORD wReference);
CMMERROR CMM_API ModifyDataBlock(DWORD dwConfigurationID, BLOCK_INFO *pBlockDetails);
CMMERROR CMM_API SetBlockModified(DWORD dwConfigurationID, BLOCK_INFO *pBlockDetails);
CMMERROR CMM_API DeleteDataBlock(DWORD dwConfigurationID, BLOCK_INFO *pBlockDetails);
CMMERROR CMM_API GetCountByBlock(DWORD dwConfigurationID, WORD wBlockType, WORD wReference, DWORD *pdwBlockCount);
CMMERROR CMM_API GetBlockCount(DWORD dwConfigurationID, WORD wReference, DWORD *pdwBlockTypes);
CMMERROR CMM_API ValidateDataBlock(DWORD dwConfigurationID, BLOCK_INFO *pBlockDetails, TV_BOOL *pIsBlockValid,
		QString *pInvalidMemberName);
CMMERROR CMM_API GetNextChangeBlock(DWORD dwConfigurationID, WORD wIndex, BLOCK_INFO *pBlockDetails);
CMMERROR CMM_API SetConfigurationLog(DWORD dwConfigurationID, CONFIGHEADERINFO *pConfigDetails);
CMMERROR CMM_API GetSizeOfBlockType(WORD wBlockType, DWORD *pdwBlockSize);
CMMERROR CMM_API SetBlockToDefaults(DWORD dwConfigurationID, WORD wBlockType, WORD wInstanceId, BYTE *pByBlockData);

CMMERROR CMM_API ShutdownCMM();

//Sets the function pointer for function GlbUpdateThreadInfo
CMMERROR CMM_API SetThreadInfo(PFnUpdateThreadInfo pFnUpdateThreadInfo);
//Sets the function pointer for function GlbUpdateThreadCounter
CMMERROR CMM_API SetThreadCounter(PFnUpdateThreadCounter pFnUpdateThreadCounter);

#ifdef __cplusplus
}
#endif

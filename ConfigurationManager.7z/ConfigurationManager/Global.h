/// @file 
/// ****************************************************************
///  Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Configuration Manager
/// @n Filename: Global.h
/// @n Desc:	 Global definitions of variables commonly used by all 
///				 modules in CMM.
///
//  ****************************************************************
//  Revision History
//  ****************************************************************
//  $Log[4]:
// 6 Stability Project 1.3.1.1  7/2/2011 4:57:27 PM Hemant(HAIL) 
//  Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
// 5 Stability Project 1.3.1.0  7/1/2011 4:26:36 PM Hemant(HAIL) 
//  Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
// 4 V6 Firmware 1.3  10/27/2004 11:34:54 AM  Amar (HTSL) MFC
//  and Trace support 
// 3 V6 Firmware 1.2  10/11/2004 7:05:45 PM Vamshi (HTSL) CMM
//  Release 1.0
//  $
//
//  ****************************************************************
/******************************************************************************************
    COPYRIGHT (c) 2004
     HONEYWELL INC.,
    ALL RIGHTS RESERVED
  This software is a copyrighted work and/or information protected
  as a trade secret. Legal rights of Honeywell Inc. in this
  software is distinct from ownership of any medium in which the
  software is embodied. Copyright or trade secret notices included
  must be reproduced in any copies authorized by Honeywell Inc.
  The information in this software is subject to change without
  notice and should not be considered as a commitment by Honeywell
  Inc.
******************************************************************************************/
#pragma once
#include "ConfigDefines.h"
#include <vector>
#include <string>
const short STR_LEN = 16;
typedef union _value {
  BYTE b;
  char c;
  UCHAR uc;
  WCHAR wc;
  short s;
  USHORT us;
  long l;
  ULONG ul;
  WORD w;
  DWORD dw;
  float f;
  double d;
  LONGLONG ll;
  ULONGLONG ull;
} value;



typedef struct _MD {
  char Fieldname[STR_LEN]; // need not be wchar... ****16
  WORD wDatatype;          // ****2
  WORD wnumInst;           // ****2
  WORD wnumSubInst;          // ****2
  WORD wclass;           // ****2(has been shifted up)
  value vdefault;          // ****8
  value Lowlmt;          // ****8
  value Hilmt;           // ****8
} MD, *PMD;

typedef struct _MD IDENTIFIER_RECORD_INFO;

//***** START - constants used by CRequestHandler and CMemoryManager*****/
/// The configuration id of the system.
#define SYSTEM_CONFIGURATION_ID 0
/// Size of the buffer to store instance length
#define INSTANCE_LENGTH 5
/// Number of bits in a byte
#define SIZE_OF_BYTE 8
/// Size of CRC used in bytes.
#define CRC_SIZE 2
///	Size of the buffer to store member name(when validate fails)
#define MEMBER_LEN 512

const char PERIOD[] =".";
const char POINTER[] ="->";
//***** END - constants used by CRequestHandler and CMemoryManager*****/

//***** START - enumerations used by CRequestHandler and CMemoryManager*****/
//Instance State
//*******************************************************
//  enum enumINSTANCESTATE
///
/// Defines the state of an instance depending on its
///	availability in the Current and Working sections.
///
//*******************************************************
typedef enum enumINSTANCESTATE
{
	INSTANCE_NOT_AVAILABLE=0,
	INSTANCE_ADDED,
	INSTANCE_DELETED,
	INSTANCE_MODIFIED,
	INSTANCE_NOCHANGE
}INSTANCESTATE;
//*******************************************************
//  enum enumBLOCKSTATE
///
///	Defines the state of a block. The enumeration 
///	indicates if a block type exists and if it has been 
///	modified.
///
//*******************************************************
typedef enum enumBLOCKSTATE
{
	BLOCK_CREATE = 0,
	BLOCK_MODIFIED
}BLOCKSTATE;
//*******************************************************
//  enum enumDATATYPE
///
/// --- Add Enum Description ---
///
//*******************************************************
typedef enum enumDATATYPE
{
	DT_WORD = 1,
	DT_BOOL,
	DT_DWORD,
	DT_BYTE,
	DT_ULONG
}DATATYPE;
//*******************************************************
//  enum enumCMMSTATUS
///
/// The status of the any function within the CMM.
///
//*******************************************************
typedef enum enumCMMSTATUS
{
	CSTATUS_OK = 0,
	CSTATUS_FAIL,
	CSTATUS_POINTER,
	CSTATUS_EXCEPTION,
	CSTATUS_CRITICAL_BLOCKED,
	CSTATUS_INVALID_PARAMETER,
	CSTATUS_DUPLICATE_CONFIGURATION,
	CSTATUS_DUPLICATE_INSTANCE,
	CSTATUS_METADATA_NOTINITIALIZED,
	CSTATUS_ALREADY_INITIALIZED,
	CSTATUS_CONFIGURATION_NOTINITIALIZED,
	CSTATUS_CONFIGURATION_LOAD_FAILED,
	CSTATUS_INVALID_CONFIGURATION,
	CSTATUS_INVALID_BLOCKTYPE,
	CSTATUS_INVALID_IDENTIFIER,
	CSTATUS_INVALID_INSTANCE,
	CSTATUS_INVALID_SIZE,
	CSTATUS_INVALID_ACCESSTYPE,
	CSTATUS_INVALID_METADATA,
	CSTATUS_CONFIGURATION_UNAVAILABLE,
	CSTATUS_CONFIGURATION_CORRUPT,
	CSTATUS_FILE_NOTAVAILABLE,
	CSTATUS_DATABLOCK_NOTAVAILABLE,
	CSTATUS_VALUE_OUT_OF_RANGE,
	CSTATUS_UNSUPPORTED_DATATYPE,
	CSTATUS_INSUFFICIENT_MEMORY
}CMMSTATUS;
//*******************************************************
//  enum enumACCESS_SPECIFIER
///
/// The access level of a configuration.
///
//*******************************************************
typedef enum enumACCESS_SPECIFIER
{	
	ALLOW_MODIFIABLE=1,
	ALLOW_CURRENT,
	ALLOW_ALL,
	ALLOW_NONE,
	CONFIGURATION_CORRUPT
}ACCESS_SPECIFIER;
//*******************************************************
//  enum enumACCESS_SPECIFIER
///
/// The access level of a configuration.
///
//*******************************************************
typedef enum enumCONFIGURATION_STATE
{	
	CONFIGURATION_INIT = 0,
	CONFIGURATION_LOAD
}CONFIGURATION_STATE;
//*******************************************************
//  enum enumCLASS
///
/// Indicates the type of block.
///
//*******************************************************
typedef enum enumCLASS
{
	CLASS_STANDARD = 1,
	CLASS_RESERVE,
	CLASS_STRUCTURE,
	CLASS_UNION
}CLASS;
//*******************************************************
//  enum enumCONFIGLOGOpr
///
/// The enumeration indicates the operation that was 
/// performed on a configuration to be used while
///	updating the statistics in the config header.
///
//*******************************************************
typedef enum enumCONFIGLOGOpr
{
	CONFIG_LOAD =0,
	CONFIG_SAVES,
	CONFIG_CHANGES,
	CONFIG_VERSION_UP,
	CONFIG_VERSION_DOWN
};
//*******************************************************
//  enum InstanceCondition
///
/// --- Add Enum Description ---
///
//*******************************************************
typedef enum InstanceCondition
{
	INSTANCE_HIGHER = 1,
	INSTANCE_LOWER,
	INSTANCE_EQUAL
}INSTANCECONDITION;
//*******************************************************
//  enum SubInstanceCondition
///
/// --- Add Enum Description ---
///
//*******************************************************
typedef enum SubInstanceCondition
{
	SUBINSTANCE_HIGHER = 1,
	SUBINSTANCE_LOWER,
	SUBINSTANCE_EQUAL
}SUBINSTANCECONDITION;
//*******************************************************
//  enum ComputeInclude
///
/// --- Add Enum Description ---
///
//*******************************************************
typedef enum ComputeInclude
{
	INCLUDE_ALL = 1,
	INCLUDE_SUBINSTANCE,
	INCLUDE_NONE
}COMPUTE_INCLUDE;
//*******************************************************
//  enum Config_Operation
///
/// Indicates the operation that can be be performed 
///	in the CMM
///
//*******************************************************
typedef enum Config_Operation
{
	OPR_INITIALIZE,
	OPR_CREATECONF,
	OPR_ALLOCATE,
	OPR_LOAD,
	OPR_COMMIT,	
	OPR_DISCARD,
	OPR_CLEARCONF,
	OPR_DELETECONF,
	OPR_GETCONF,
	OPR_DELETEBLOCK,
	OPR_GETBLOCK,
	OPR_CREATEBLOCK,
	OPR_MODIFYBLOCK,
	OPR_SETBLOCK,
	OPR_GETNEXTBLOCK,
	OPR_VALIDATEBLOCK,
	OPR_GETBLOCKCOUNT,
	OPR_GETINSTANCECOUNT,
	OPR_SETCONFLOG,
	OPR_CONVERT
}CONFIGOPERATION;

//*******************************************************
//  enum enumCONFIGURATIONFILTER_TYPE
///
/// The filter to access the configuration
///
//*******************************************************
typedef enum enumCONFIGURATIONFILTER_TYPE
{	
	FILTER_MODIFIABLE = 0,
	FILTER_COMMITTED,
	FILTER_MODIFIED,
	FILTER_NONE
}CONFIGURATIONFILTER_TYPE;

//******************************************************
//  typedef struct ThreadParams
///
/// @brief --- Parameters to be sent to a new thread
///
/// Contains the parameters that are required for the 
///	new thread to start.
///
//******************************************************
typedef struct ThreadParams
{
	void * objReqHandler;		///< Pointer to the RequestHandler object
	DWORD dwConfigurationId;	///< Configuratio id 
	WORD wAccessFlag;			///< Access Flag of the configuration
	WORD wOperation;			///< Operation to perform
}DISCARD_THREAD_PARAMS;

//******************************************************
//  typedef struct stValidate
///
/// @brief --- Parameters to be sent for Validate
///
/// Contains the buffer to store the name of the
///	variable which is out of range.
///
//******************************************************
typedef struct stValidate
{
	char szMemberName[MEMBER_LEN];	///< Buffer to store member name
	TV_BOOL bFirstCall;				///< Flag to indicate recursive call
}Validate_Parameters;

//***** END - enumerations used by CRequestHandler and CMemoryManager*****/

typedef std::basic_string<char> CHARSTRING;
typedef std::vector<WORD> TEMPORARY_LIST;

/// @file CRequestHandlerUtilities.cpp
/// ****************************************************************
/// Â© Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Request Handler
/// @n Filename: CRequestHandlerUtilities.cpp
/// @n Desc:	 Implementation of the private functions for 
///				 CRequestHandler class.
///
//  ****************************************************************
//  Revision History
//  ****************************************************************
//  $Log[4]:
// 11  Stability Project 1.6.1.3  7/2/2011 4:56:25 PM   Hemant(HAIL) 
//    Stability Project: Recorder source has been upgraded from IL
//    version of firmware to JF version of firmware.
// 10  Stability Project 1.6.1.2  7/1/2011 4:38:10 PM   Hemant(HAIL) 
//    Stability Project: Files has been checked in before the merging
//    task. The merging will be done between IL version of firmware and JF
//    version of firmware. 
// 9   Stability Project 1.6.1.1  3/17/2011 3:20:19 PM  Hemant(HAIL) 
//    Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//    new operator in DEBUG mode only. To detect memory leaks in files, use
//    it in preprocessor definition when in debug mode.
// 8   Stability Project 1.6.1.0  2/15/2011 3:02:46 PM  Hemant(HAIL) 
//    File updated during Heap Management. Call to the default behaviour
//    of new operator has been commented.
//  $
//
//  ****************************************************************
/******************************************************************************************
 COPYRIGHT (c) 2004
 HONEYWELL INC.,
 ALL RIGHTS RESERVED
 This software is a copyrighted work and/or information protected
 as a trade secret. Legal rights of Honeywell Inc. in this
 software is distinct from ownership of any medium in which the
 software is embodied. Copyright or trade secret notices included
 must be reproduced in any copies authorized by Honeywell Inc.
 The information in this software is subject to change without
 notice and should not be considered as a commitment by Honeywell
 Inc.
 ******************************************************************************************/

#include "CMMDefines.h"
#include "Global.h"
#include "CMemoryManager.h"
#include "CRequestHandler.h"
#include "V6crc.h"

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif

/*********************Extern Definitions*************************************/
extern CMemoryManager glbObjMemoryManager;		///< Global memory manager object. (defined in Global.cpp)
/*********************Extern Definitions*************************************/

//**********************************************************************
/// Returns the Host type stored when CMM is initialized.
///
///
/// @return		Returns the Host type string 
/// 
//**********************************************************************
QString  CRequestHandler::GetHostType() {
	return m_tchHostType;
}

//**********************************************************************
/// Sets the host type of the module that loads the CMM
///
/// @param[in]	pszHostType		- Buffer containing the Host type string
///
/// @return		TRUE - when string stored successfully, 
///				FALSE - on error
/// 
//**********************************************************************
TV_BOOL CRequestHandler::SetHostType(QString pszHostType) {
	//check if a valid buffer is available
	if (NULL == pszHostType)
		return FALSE;		//return FALSE

	//store the pointer to the host type
	m_tchHostType = pszHostType;

	return TRUE;	//return TRUE
}

//**********************************************************************
/// Gets the Serial number of the module that initializes CMM.
///
/// @return		Returns the Serial Number
/// 
//**********************************************************************
ULONG CRequestHandler::GetSerialNumber() {
	return m_lSerialNumber;
}

//**********************************************************************
/// Sets the serial number of the module that initializes the CMM.
///
/// @param[in]	ulSerialNumber	- Serial Number of module that initializes
///									CMM.
///
/// @return		TRUE	- when serial number is returned.
///				FALSE	- when error occurs.
/// 
//**********************************************************************
TV_BOOL CRequestHandler::SetSerialNumber(ULONG ulSerialNumber) {
	//store the pointer to the host type
	m_lSerialNumber = ulSerialNumber;

	return TRUE;	//return TRUE
}

//**********************************************************************
/// Returns the flag which indicates if the CMM has been initialized or 
///	not.
///
/// @return		TRUE	- CMM Initialized.
///				FALSE	- CMM not initialized.
/// 
//**********************************************************************
TV_BOOL CRequestHandler::IsCMMInitialized() {
	return m_bInitialized;
}

//**********************************************************************
/// Sets the flag indicating that CMM has been initialized.
///
/// @param[in]	tvbCMMStatus	- TRUE	- CMM initialized
///								  FALSE - CMM not initialized
///
/// @return		TRUE	- Flag successfully set.
///				FALSE	- Error occured when setting flag
/// 
//**********************************************************************
TV_BOOL CRequestHandler::SetCMMInitialized(TV_BOOL tvbCMMStatus) {
	m_bInitialized = tvbCMMStatus;

	return TRUE;	//return TRUE
}
//**********************************************************************
/// Gets the version of the system metadata that the CMM was initialized
///	with.
///
///
/// @return		The System metadata version
/// 
//**********************************************************************
WORD CRequestHandler::GetSystemMetadataVersion() {
	return m_wVersion;
}
//**********************************************************************
/// Sets the version of the system metadata that the CMM is to be 
///	initialized with.
///
/// @param[in]	wVersion 	- Version of the metadata for the CMM to be 
///								  initialized with.
///
/// @return		TRUE - Succesfully stored the version of metadata.
///				FALSE - An error occured.
/// 
//**********************************************************************
TV_BOOL CRequestHandler::SetSystemMetadataVersion(WORD wVersion) {
	//check if the argument contains a valid version number. 0 is an invalid version number
	if (0 == wVersion)
		return FALSE; //success
#ifdef PWDLOGS_ENABLE
	WCHAR szDbgMsg[512];
	swprintf( szDbgMsg, L"CRequestHandler::version:%d GTC %d\n",wVersion,GetTickCount());
	OutputDebugString(szDbgMsg);
#endif
	m_wVersion = wVersion;
	return TRUE;
}
//**********************************************************************
/// Converts the CMMStatus error codes used within CMM to CMMError code
///	to be used by CMM users.
///
/// @param[in]	eCMMStatus 	- CMMStatus code.
///
/// @return		CMMERROR - CMMError code.
/// 
//	Modification History
//	Sai Krishnan	14/09/2004	CMM PCR No : 43
//								As per the original design there is no 
//								error called CMM_CONFIGURATION_UNAVAILABLE. 
//								This has been added as suggested above to 
//								give a better indication of the error.
//	Sai Krishnan	14/09/2004	CMM PCR No : 53
//								The CSTATUS to CMMERROR conversion has
//								been updated to provide consistent and
//								accurate error codes.
//**********************************************************************
CMMERROR CRequestHandler::ConvertStatusToErrorCode(CMMSTATUS eCMMStatus) {
	LOG_INFO(CMM_qDebugR_MODE, ("ConvertStatusToErrorCode - Start"));
	CMMERROR eCMMError;

	switch (eCMMStatus) {
	case CSTATUS_OK:
		//indicates function completed successfully
		eCMMError = CMM_SUCCESS;
		break;
	case CSTATUS_INVALID_PARAMETER:
		eCMMError = CMM_INVALID_PARAMETER;
		break;
	case CSTATUS_CONFIGURATION_NOTINITIALIZED:
		eCMMError = CMM_NOT_INITIALIZED;
		break;
	case CSTATUS_METADATA_NOTINITIALIZED:
		eCMMError = CMM_INVALID_METADATA;
		break;
	case CSTATUS_INVALID_CONFIGURATION:
	case CSTATUS_DUPLICATE_CONFIGURATION:
		eCMMError = CMM_INVALID_CONFIGURATION_ID;
		break;
	case CSTATUS_CONFIGURATION_UNAVAILABLE:
		eCMMError = CMM_CONFIGURATION_UNAVAILABLE;
		break;
	case CSTATUS_FILE_NOTAVAILABLE:
		eCMMError = CMM_CONFIGURATION_FILE_NOT_FOUND;
		break;
	case CSTATUS_CONFIGURATION_CORRUPT:
		eCMMError = CMM_CONFIGURATION_CORRUPT;
		break;
	case CSTATUS_INVALID_BLOCKTYPE:
		eCMMError = CMM_INVALID_BLOCK_TYPE;
		break;
	case CSTATUS_INVALID_INSTANCE:
	case CSTATUS_DUPLICATE_INSTANCE:
	case CSTATUS_DATABLOCK_NOTAVAILABLE:
		eCMMError = CMM_INVALID_INSTANCE;
		break;
	case CSTATUS_INSUFFICIENT_MEMORY:
		eCMMError = CMM_INSUFFICIENT_MEMORY;
		break;
	case CSTATUS_VALUE_OUT_OF_RANGE:
		eCMMError = CMM_VALUE_OUT_OF_RANGE;
		break;
	case CSTATUS_INVALID_IDENTIFIER:
	case CSTATUS_INVALID_SIZE:
	case CSTATUS_INVALID_ACCESSTYPE:
	case CSTATUS_INVALID_METADATA:
	case CSTATUS_UNSUPPORTED_DATATYPE:
	case CSTATUS_CRITICAL_BLOCKED:
	case CSTATUS_ALREADY_INITIALIZED:
	case CSTATUS_CONFIGURATION_LOAD_FAILED:
	case CSTATUS_POINTER:
	case CSTATUS_EXCEPTION:
	case CSTATUS_FAIL:
	default:
		//indicates function failed with unknown error
		eCMMError = CMM_FAILED;
		break;
	}
	LOG_INFO(CMM_qDebugR_MODE, ("ConvertStatusToErrorCode - Success - CMMStatus : %d - CMMError : %d"), eCMMStatus,
			eCMMError);
	return eCMMError;
}
//**********************************************************************
/// Validates the data block by checking if the values of instances 
///	in the block are within the high and low ranges specified in the 
///	system metadata.
///
/// @param[in]	dwConfigurationId - The configuration id of the block 
///									which has to be validated.
///
/// @param[in]	wBlockType 		  - Block Type of the block to be 
///									validated.
///
/// @param[in]	pbyData		  - Buffer to the start of the data block
///									(without header) in the configuration
///									file.
///
///	@param[in]	pValidateParams->bFirstCall	- Flag which indicates if the
///												function is called the 
///												first time or if it a 
///												recursive call.
///
///	@param[in,out]	pValidateParams->szMemberName - Buffer(512 bytes) to store
///												the name of the failed member.
///
/// @return		Returns CSTATUS_OK on success, error code on failure
/// 
//**********************************************************************
CMMSTATUS CRequestHandler::ValidateDataForRange(DWORD dwConfigurationId, WORD wBlockType, BYTE *pbyData,
		Validate_Parameters *pValidateParams) {
	LOG_INFO(CMM_qDebugR_MODE, ("ValidateDataForRange - Start"));
	/**Step 0: Check the arguments*/
	/******************************/
	if (NULL == pbyData || NULL == pValidateParams) {
		LOG_ERR(CMM_qDebugR_MODE, ("ValidateDataForRange - End - Invalid Parameter"));
		return CSTATUS_INVALID_PARAMETER;
	}

	CMMSTATUS eCmmStatus;	//buffer to store the status of the operations
	try {
		/**Step 1: Check if the block type is a structure/union/variable data type*/
		/**************************************************************************/
		//1. variable data type
		if (VARIABLE_BASE <= wBlockType) {
			//variable data type need not be defaulted. return success
			LOG_INFO(CMM_qDebugR_MODE, ("ValidateDataForRange - Success - Variable Data Type"));
			return CSTATUS_OK;
		}

		BYTE *pBlockIdentifierDetails = NULL;
		//2. union data type
		eCmmStatus = glbObjMemoryManager.GetBlock(SYSTEM_CONFIGURATION_ID, wBlockType, &pBlockIdentifierDetails);
		if (eCmmStatus != CSTATUS_OK) {
			LOG_ERR(CMM_qDebugR_MODE, ("ValidateDataForRange - End - Unable to get main block info : %d"), eCmmStatus);
			return eCmmStatus;
		} else {
			IDENTIFIER_RECORD_INFO *pDefinition = (IDENTIFIER_RECORD_INFO*) pBlockIdentifierDetails;
			if (classUnion == pDefinition->wclass) {
				//unions need not be defaulted. return success
				LOG_INFO(CMM_qDebugR_MODE, ("ValidateDataForRange - Success - Union"));
				return CSTATUS_OK;
			}
			if (pValidateParams->bFirstCall) {
#if _MSC_VER < 1400 
				//store the name of the structure 
				strcpy(pValidateParams->szMemberName, pDefinition->Fieldname);
				//append the indirection keyword, "->"
				strcat(pValidateParams->szMemberName, POINTER);

#else
				//store the name of the structure 
				strcpy_s(pValidateParams->szMemberName, sizeof(pValidateParams->szMemberName) , pDefinition->Fieldname);
				//append the indirection keyword, "->"
				strcat_s(pValidateParams->szMemberName, sizeof(pValidateParams->szMemberName) , POINTER);
		
#endif
			} else {
				//the name of the structure in this case will be copied
				//before the recursive call is made
				//append the indirection keyword, "."
#if _MSC_VER < 1400 
				strcat(pValidateParams->szMemberName, PERIOD);
#else
				strcat_s(pValidateParams->szMemberName, sizeof(pValidateParams->szMemberName) , PERIOD);
#endif

			}
		}

		BYTE *pByDataBuffer = pbyData;

		/**Step 2: Get all the identifiers of the block type*/
		/****************************************************/
		DWORD dwIdentifierCount = 0;		//buffer to store the number of identifiers in given block
		BYTE **ppByIdentifiersPos = NULL;	//buffer to store the pointer to the identifier details from metadata
		eCmmStatus = glbObjMemoryManager.GetEnumIdentifier(SYSTEM_CONFIGURATION_ID, wBlockType, &dwIdentifierCount,
				&ppByIdentifiersPos);
		if (CSTATUS_OK != eCmmStatus) {
			LOG_ERR(CMM_qDebugR_MODE, ("ValidateDataForRange - End - Unable to enumerate block types : %d"), eCmmStatus);
			return eCmmStatus;
		}

		WORD wStart = 0;	//used only for BITFIELDS

		/**Step 3: Get the datatype/range of each identifiers and compare*/
		/*****************************************************************/
		for (DWORD dwNumIdentifiers = 0; dwNumIdentifiers < dwIdentifierCount; dwNumIdentifiers++) {
			BYTE *pByMDBuffer = NULL;	//temporary buffer			
			pByMDBuffer = ppByIdentifiersPos[dwNumIdentifiers];

			//copy the buffer to a structure
			IDENTIFIER_RECORD_INFO *pIdentifierDetails;
			pIdentifierDetails = (IDENTIFIER_RECORD_INFO*) pByMDBuffer;

			/**Step 4: For nested structures call the function recursively*/
			/**************************************************************/
			if (classUnionmember == pIdentifierDetails->wclass || VARIABLE_BASE <= pIdentifierDetails->wDatatype) {
				//NOTE: variable data types have datatypes greater than 50000
				/**********************************************/
				//Note: Embedded Unions and variable data types
				//Note: need not be validated.
				/**********************************************/
				//implies nested objects - unions
				//There can be more than one instance of a structure..(SubInstance not applicable for structures)
				//buffer to store number of structure instances -- if equal to 0 => 1 instance
				WORD wInstanceCount = (pIdentifierDetails->wnumInst > 0) ? pIdentifierDetails->wnumInst : 1;
				//move the buffer pointer to point to the next structure 
				//get the size of the union object
				DWORD dwBlockSize = 0;
				glbObjMemoryManager.GetBlockSize(SYSTEM_CONFIGURATION_ID, pIdentifierDetails->wDatatype, &dwBlockSize);

				pByDataBuffer = pByDataBuffer + dwBlockSize * wInstanceCount;
				wStart = 0;
				continue;
			} else if (classStructmember == pIdentifierDetails->wclass) {
				//implies nested objects - structures 
				//There can be more than one instance of a structure..(SubInstance not applicable for structures)
				//buffer to store number of structure instances -- if equal to 0 => 1 instance
				WORD wInstanceCount = (pIdentifierDetails->wnumInst > 0) ? pIdentifierDetails->wnumInst : 1;

				//get the size of a given block type
				DWORD dwBlockSize = 0;
				glbObjMemoryManager.GetBlockSize(SYSTEM_CONFIGURATION_ID, pIdentifierDetails->wDatatype, &dwBlockSize);

				//each instance of the structure has to be validated one by one
				for (int nNumInstance = 0; nNumInstance < wInstanceCount; nNumInstance++) {
					//create a temporary place holder for the recursive call
					Validate_Parameters sValParams;
					memset(&sValParams, 0, sizeof(Validate_Parameters));
					sValParams.bFirstCall = FALSE;	//indicates its a recursive call
#if _MSC_VER < 1400 
					strcpy(sValParams.szMemberName, pIdentifierDetails->Fieldname);
#else
					strcpy_s(sValParams.szMemberName, sizeof(sValParams.szMemberName), pIdentifierDetails->Fieldname);
#endif

					eCmmStatus = ValidateDataForRange(dwConfigurationId, pIdentifierDetails->wDatatype, pByDataBuffer,
							&sValParams);

					if (CSTATUS_OK != eCmmStatus) {
						LOG_ERR(CMM_qDebugR_MODE, ("ValidateDataForRange - End - Embedded structure validation failed"));

						//append the name of the variable which has failed the range check
						if (CSTATUS_VALUE_OUT_OF_RANGE == eCmmStatus) {
#if _MSC_VER < 1400 
							strcat(pValidateParams->szMemberName, sValParams.szMemberName);
#else
							strcat_s(pValidateParams->szMemberName, sizeof(pValidateParams->szMemberName) , sValParams.szMemberName  );						
#endif

						}

						if (NULL != ppByIdentifiersPos)
							LocalFree(ppByIdentifiersPos);		//delete the array of byte pointers
						return eCmmStatus;
					}
					//move the buffer pointer to point to the next structure 					
					pByDataBuffer = pByDataBuffer + dwBlockSize;

				}		//end of for loop
				wStart = 0;
			} else {
				/**Step 5: For intrinsic datatypes and arrays validate one member at a time*/
				/***************************************************************************/
				WORD wBlockSize = 0;//buffer to store the block size, to move the pointer to the next block						
				/********************************************************************/
				//Note : The variable wStart will be used by the function
				//Note : ValidateIntrinsicAndArrayDataType in case of BITField oprts.
				//Note : In that case the pointer should not be moved to the next 
				//Note : data member until the wStart = 0
				/********************************************************************/
				CCMMUtility objUtility;	//object to execute utility functions
				//an array or intrinsic type
				eCmmStatus = objUtility.ValidateIntrinsicAndArrayDataType(*pIdentifierDetails, pByDataBuffer,
						&wBlockSize, &wStart);

				if (CSTATUS_OK != eCmmStatus) {
					LOG_ERR(CMM_qDebugR_MODE, ("ValidateDataForRange - End - Intrinsic data type validation failed"));

					//append the name of the variable which has failed the range check
					if (CSTATUS_VALUE_OUT_OF_RANGE == eCmmStatus) {
#if _MSC_VER < 1400 
						strcat(pValidateParams->szMemberName, pIdentifierDetails->Fieldname);
#else
						strcat_s (pValidateParams->szMemberName, sizeof(pValidateParams->szMemberName) , pIdentifierDetails ->Fieldname);								
#endif

					}

					if (NULL != ppByIdentifiersPos)
						LocalFree(ppByIdentifiersPos);		//delete the array of byte pointers
					return eCmmStatus;
				}

				/**Step 6: Move the pointer to the next block member */
				/*****************************************************/
				if (0 == wStart)
					pByDataBuffer = pByDataBuffer + wBlockSize;
			}
		}		//end of for loop

		/**Step 7: Cleanup memory allocated to store identifier names*/
		/*************************************************************/
		if (NULL != ppByIdentifiersPos)
			LocalFree(ppByIdentifiersPos);		//delete the array of byte pointers

		LOG_INFO(CMM_qDebugR_MODE, ("ValidateDataForRange - CSTATUS_OK"));
		return CSTATUS_OK;
	} catch (...) {
		//an exception has occured
		LOG_ERR(CMM_qDebugR_MODE, ("ValidateDataForRange - Exception - LastError : %d"), GetLastError());
		return CSTATUS_FAIL;
	}
}
//**********************************************************************
/// Gets the metadata version on which the configuration file has been
///	created.
///
/// @param[in]	dwConfigurationId - The configuration id whose version 
///									has to be found.
///
/// @param[in]	pwVersion 		  - Buffer in to which the version number
///									has to be stored.
///
/// @return		Returns CSTATUS_OK on success, error code on failure
/// 
//**********************************************************************
CMMSTATUS CRequestHandler::GetVersionFromConfigurationFile(DWORD dwConfigurationId, WORD *pwVersion) {

	LOG_INFO(CMM_qDebugR_MODE, ("GetVersionFromConfigurationFile - Start"));
#ifdef PWDLOGS_ENABLE
	WCHAR szDbgMsg[512];
	swprintf( szDbgMsg, L"CRequestHandlerUtilities::GetVersionFromConfigurationFile - Start GTC %d\n",GetTickCount());
	OutputDebugString(szDbgMsg);
#endif

	/**Step 0: Check the arguments*/
	/******************************/
	if (0 == dwConfigurationId) {
		LOG_ERR(CMM_qDebugR_MODE, ("GetVersionFromConfigurationFile - End - Config id = 0"));
#ifdef PWDLOGS_ENABLE
		swprintf( szDbgMsg, L"CRequestHandlerUtilities::GetVersionFromConfigurationFile - End - Config id = 0 GTC %d\n",GetTickCount());
		OutputDebugString(szDbgMsg);
#endif
		return CSTATUS_INVALID_CONFIGURATION;
	}
	if (0 == pwVersion) {
		LOG_ERR(CMM_qDebugR_MODE, ("GetVersionFromConfigurationFile - End - Invalid parameter"));
#ifdef PWDLOGS_ENABLE
		swprintf( szDbgMsg, L"CRequestHandlerUtilities::GetVersionFromConfigurationFile - End - Invalid parameter GTC %d\n",GetTickCount());
		OutputDebugString(szDbgMsg);
#endif
		return CSTATUS_INVALID_PARAMETER;
	}
	try {
		BYTE *pByConfigFile = NULL;		//buffer to store

		/**Step 1: Get the configuration file*/
		/*************************************/
		CMMSTATUS eCmmStatus = glbObjMemoryManager.GetConfigurationFile(dwConfigurationId, &pByConfigFile);
		if (CSTATUS_OK != eCmmStatus) {
			LOG_ERR(CMM_qDebugR_MODE, ("GetVersionFromConfigurationFile - GetConfig file failed : %d"), eCmmStatus);

#ifdef PWDLOGS_ENABLE
			swprintf( szDbgMsg, L"CRequestHandlerUtilities::GetVersionFromConfigurationFile - GetConfig file failed : %d GTC %d\n",eCmmStatus,GetTickCount());
			OutputDebugString(szDbgMsg);
#endif
			return eCmmStatus;
		}

		/**Step 2: Get the metadata portion from the config file*/
		/********************************************************/
		CONFIGFILE_HEADER *pConfigFileHeader = (CONFIGFILE_HEADER*) pByConfigFile;
		Metadata_Header *pMetadataHeader = (Metadata_Header*) (pByConfigFile + pConfigFileHeader->lMDOffset);

		/**Step 3: Save the version number from the metadata header*/
		/***********************************************************/
		*pwVersion = pMetadataHeader->wVerNo;

		LOG_INFO(CMM_qDebugR_MODE, ("GetVersionFromConfigurationFile - Success : Metadata version : %d"),
				pMetadataHeader->wVerNo);

#ifdef PWDLOGS_ENABLE
		swprintf( szDbgMsg, L"CRequestHandlerUtilities::GetVersionFromConfigurationFile - Success : Metadata version : %d GTC %d\n",pMetadataHeader->wVerNo,GetTickCount());
		OutputDebugString(szDbgMsg);
#endif

		return CSTATUS_OK;
	} catch (...) {
		//an exception has occured
		LOG_ERR(CMM_qDebugR_MODE, ("GetVersionFromConfigurationFile - Exception - LastError : %d"), GetLastError());
		return CSTATUS_FAIL;
	}
}
//**********************************************************************
/// Builds the configuration lookup for the configuration file. 
///	The lookups are created for the current/working section depending
/// on the source from which the configuration is loaded.
///
/// @param[in]	dwConfigurationId - The configuration id for which the 
///									lookup has to be created for each of the
///									instances in the configuration.
///
/// @param[in]	bPersistedLoad	  - TRUE - Persisted Source.. (Creates the 
///											lookup in the current section)
///									FALSE- UnPersisted Source.. (Creates 
///											the lookup in working section)
///
/// @return		Returns CSTATUS_OK on success, error code on failure
/// 
//**********************************************************************
CMMSTATUS CRequestHandler::BuildConfigurationLookUp(DWORD dwConfigurationId, TV_BOOL bPersistedLoad) {
	LOG_INFO(CMM_qDebugR_MODE, ("BuildConfigurationLookUp - Start"));
	DWORD dwFileSizeCount = 0;	//variable to keep track of configaration file parsing
	DWORD dwConfigFileSize = 0;	//buffer to store the size of the configuration file
	BYTE *pByConfigFile = NULL;	//pointer to the configuration file.
	TV_BOOL bFlag = TRUE;		//Flag to indicate if further data remains to be parsed in the config
#ifdef PWDLOGS_ENABLE
	WCHAR szDbgMsg[512];
#endif
	/**Step 1: Get the configuration file*/
	/*************************************/
	CMMSTATUS eCmmStatus = glbObjMemoryManager.GetConfigurationFile(dwConfigurationId, &pByConfigFile);
	if (CSTATUS_OK != eCmmStatus) {
		LOG_ERR(CMM_qDebugR_MODE, ("BuildConfigurationLookUp - End - GetConfig file failed : %d"), eCmmStatus);
		return eCmmStatus;
	}
	//get the configuration file size
	eCmmStatus = glbObjMemoryManager.GetConfigurationSize(dwConfigurationId, &dwConfigFileSize);
	if (CSTATUS_OK != eCmmStatus) {
		LOG_ERR(CMM_qDebugR_MODE, ("BuildConfigurationLookUp - End - GetConfig size failed : %d"), eCmmStatus);
		return eCmmStatus;
	}
	LOG_INFO(CMM_qDebugR_MODE, ("BuildConfigurationLookUp - Config Size : %d"), dwConfigFileSize);

	/**Step 2: Get the data portion from the config file*/
	/****************************************************/
	//this pointer will be moved forward to parse through each of the datablock
	BYTE *pDataBlock = NULL;		//pointer to the data block + header	

	CONFIGFILE_HEADER *pConfigFileHeader = (CONFIGFILE_HEADER*) pByConfigFile;
	pDataBlock = pByConfigFile + pConfigFileHeader->lDataOffset;

	dwFileSizeCount = (DWORD) (pDataBlock - pByConfigFile);	//calculate the buffer parsed through

	LOG_INFO(CMM_qDebugR_MODE, ("BuildConfigurationLookUp - Config Size without header and M.D. : %d"), dwFileSizeCount);

	while (bFlag) {
		//check if the entire file has been parsed.
		if (dwFileSizeCount >= dwConfigFileSize) {
			LOG_INFO(CMM_qDebugR_MODE, ("BuildConfigurationLookUp - Success : Parsed through %d bytes"),
					dwFileSizeCount);
#ifdef PWDLOGS_ENABLE
			swprintf( szDbgMsg, L"CRequestHandler::BuildConfigurationLookUp :: Success : Parsed through %d bytes GTC %d\n",dwFileSizeCount,GetTickCount());
			OutputDebugString(szDbgMsg);
#endif
			//completed parsing
			return CSTATUS_OK;
		}

		//parse the data block header and get the block type/instance
		BLOCK_INFO sBlockDetails;
		CCMMUtility objUtility;	//object to execute utility functions
		//the sBlockDetails contains the size of the datablock without the header
		eCmmStatus = objUtility.GetDataBlockAndInstanceInfoFromDataBlock(pDataBlock, &sBlockDetails);

		if (CSTATUS_OK != eCmmStatus) {
			LOG_ERR(CMM_qDebugR_MODE, ("BuildConfigurationLookUp - End - Invalid data block found : %d"), eCmmStatus);
#ifdef PWDLOGS_ENABLE
			swprintf( szDbgMsg, L"CRequestHandler::BuildConfigurationLookUp ::End - Invalid data block found GTC %d\n",GetTickCount());
			OutputDebugString(szDbgMsg);
#endif
			//invalid data block found.. so quit
			return eCmmStatus;
		}

		/**************************************************/
		//Note : A DataBlock consists of a header and data
		//Note : section. The size of the data section is 
		//Note : is available in the data block header.
		/**************************************************/
		// the pointer can be moved as it is copied into the sBlockDetails.pByBlock
		//move the pointer to the next data block header.
		pDataBlock = pDataBlock + sBlockDetails.dwBlockSize + sizeof(DATA_BLOCK_HEADER);

		//update the number of bytes that have been parsed through
		dwFileSizeCount = dwFileSizeCount + sBlockDetails.dwBlockSize + sizeof(DATA_BLOCK_HEADER);

		if (bPersistedLoad) {
			//configuration from a persisted source.. so has to be saved
			//as CURRENT_SECTION
			eCmmStatus = glbObjMemoryManager.SetCommittedDataBlock(dwConfigurationId, sBlockDetails.wBlockType,
					INSTANCE_ID(sBlockDetails.wInstanceID), sBlockDetails.pByBlock);
			//while setting commited section, the datablock INCLUDES the header
			if (CSTATUS_OK != eCmmStatus) {
				LOG_WRN(CMM_qDebugR_MODE,
						("BuildConfigurationLookUp - Unable to get commited block  : %d - Block : %d , Instance : %d"),
						eCmmStatus, sBlockDetails.wBlockType, INSTANCE_ID(sBlockDetails.wInstanceID));
				continue;	//unable to set block.. skip
			}

			/*****************************************************/
			//Note : Current section has an instance... Working 
			//Note : section does not have a copy. So the instace
			//Note : state is INSTANCE_NOT_AVAILABLE. (default)
			//Note : (Persisted Load).. When this function is 
			//Note : called after a commit, the state will be left
			//Note : to as it was before.
			/*****************************************************/
		} else {
			/*****************************************************/
			//Note : CreateDataBlock creates a new WORKING instance
			//Note : CreateDataBlock fn automatically 
			//Note : sets the state of the newly created instance
			//Note : to INSTANCE_ADDED
			//Note : For a load from unpersisted source to work
			//Note : the configuration should not have working
			//Note : section instances previsouly created.
			/*****************************************************/
			//as WORKING_SECTION
			//create a working section copy of the block
			CCMMUtility objUtility;	//object to execute utility functions
			eCmmStatus = objUtility.CreateDataBlock(dwConfigurationId, &sBlockDetails);
			if (CSTATUS_OK != eCmmStatus) {
				LOG_WRN(CMM_qDebugR_MODE,
						("BuildConfigurationLookUp - Unable to create block  : %d - Block : %d , Instance : %d"),
						eCmmStatus, sBlockDetails.wBlockType, INSTANCE_ID(sBlockDetails.wInstanceID));
				continue;	//unable to get newly created block.. skip
			}

			BYTE *pModifiableBlock = NULL;

			//get the newly created block from working section		
			eCmmStatus = glbObjMemoryManager.GetModifiableDataBlock(dwConfigurationId, sBlockDetails.wBlockType,
					INSTANCE_ID(sBlockDetails.wInstanceID), &pModifiableBlock);
			if (CSTATUS_OK != eCmmStatus) {
				LOG_WRN(CMM_qDebugR_MODE,
						("BuildConfigurationLookUp - Unable to get newly created block  : %d - Block : %d , Instance : %d"),
						eCmmStatus, sBlockDetails.wBlockType, INSTANCE_ID(sBlockDetails.wInstanceID));
				continue;	//unable to get newly created block.. skip
			}

			//here the newly created blocks header need not be updated as the
			//entire block will be copied from the already stored 
			//sBlockDetails.pByBlock 

			//copy the data from configuration to the newly created modifiable block
			memcpy(pModifiableBlock, sBlockDetails.pByBlock, sBlockDetails.dwBlockSize + sizeof(DATA_BLOCK_HEADER));

			//while setting modifiable section, the datablock INCLUDES the header			
		}			//end of else		
	}			//end of while

	LOG_INFO(CMM_qDebugR_MODE, ("BuildConfigurationLookUp - CSTATUS_OK"));
	return CSTATUS_OK;
}
//**********************************************************************
/// Calculates the size of the the buffer required to create a 
///	configuration with all the working section instances.
///
/// @param[in]	dwConfigurationId - The configuration id for which the 
///									size of the buffer required for the configuration 
///									with all the working section instances is to 
///									calculated.
///
/// @param[out]	pdwNewConfigFileSize - Size required to store the new 
///										configuration.
///
/// @return		Returns CSTATUS_OK on success, error code on failure.
/// 
//**********************************************************************
CMMSTATUS CRequestHandler::CalculateNewConfigurationSize(DWORD dwConfigurationID, DWORD *pdwNewConfigFileSize) {
	LOG_INFO(CMM_qDebugR_MODE, ("CalculateNewConfigurationSize - Start"));
	DWORD dwConfigSize = 0;		//buffer to calculate the required size of the new configuration
	*pdwNewConfigFileSize = 0;

	/**Step 0: Check the arguments*/
	/******************************/
if(NULL == pdwNewConfigFileSize)
{
	LOG_ERR(CMM_qDebugR_MODE,("CalculateNewConfigurationSize - End - Invalid parameter"));
	return CSTATUS_INVAVA

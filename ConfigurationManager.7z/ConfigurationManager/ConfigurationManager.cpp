/// @file 
/// ****************************************************************
/// Â© Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Configuration Manager
/// @n Filename: ConfigurationManager.cpp
/// @n Desc:	 Implementation of the exposed C APIs for 
///				 configuration management
///
//  ****************************************************************
//  Revision History
//  ****************************************************************
//  $Log[1]:
// 13  Aristos  1.7.1.3.1.0  9/19/2011 4:51:11 PM  Hemant(HAIL) 
//    Stability recorder source code (JI Release) updated for WatchDog
//    Timer functionality.
//  $
//
//  ****************************************************************
/******************************************************************************************
 COPYRIGHT (c) 2004
 HONEYWELL INC.,
 ALL RIGHTS RESERVED

 This software is a copyrighted work and/or information protected
 as a trade secret. Legal rights of Honeywell Inc. in this
 software is distinct from ownership of any medium in which the
 software is embodied. Copyright or trade secret notices included
 must be reproduced in any copies authorized by Honeywell Inc.
 The information in this software is subject to change without
 notice and should not be considered as a commitment by Honeywell
 Inc.
 ******************************************************************************************/

#include "CMMDefines.h"
#include "Global.h"
#include "ConfigurationManager.h"
#include "CRequestHandler.h"

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif

/*********************Extern Definitions*************************************/
//global Request Handler object declared in CRequestHandler.h
extern CRequestHandler glbObjRequestHandler;	///< Global Request Handler object. (defined in Global.cpp)
/*********************Extern Definitions*************************************/

//**********************************************************************
///
/// Initializes the CMM with the given metadata.
///
/// @param[in]	tchHostType		- Host type 
///
/// @param[in]	lSerialNumber	- Serial Number of Unit 
///
/// @param[in]	pByMetadata		- Buffer containing the metadata
///								  for the CMM to be initialized with.
///
///	@param[out]	pdwSystemVersion - The version of the system metadata.
///
/// @return		Error code if failed, CMM_SUCCESS if okay
/// 
///	@note	The buffer pByMetadata should NEVER be deleted, untill 
///	the CMM itself is unloaded from memory or the CMM is to be 
///	initialized with a new metadata.
//**********************************************************************
CMMERROR CMM_API Initialize(QString tchHostType, ULONG lSerialNumber, BYTE *pByMetadata, DWORD *pdwSystemVersion) {
	CMMSTATUS eCmmStatus;	///< Status of the operation
	eCmmStatus = glbObjRequestHandler.InitializeCMM(tchHostType, lSerialNumber, pByMetadata, pdwSystemVersion);

	return glbObjRequestHandler.ConvertStatusToErrorCode(eCmmStatus);
}

//**********************************************************************
///
/// Creates a new configuration id.
///
/// @param[out]	dwConfigurationID - Buffer to store the newly created 
///				  				 configuration's id.
///
/// @param[in]	pdwSessionNumber - Buffer containing the session 
///								 number. The value in the buffer
///								 will be affixed to the data blocks
///								 when the blocks are modified
///
///
/// @return		Error code if failed, CMM_SUCCESS if okay
/// 
///	@note	The values from the buffer pdwSessionNumber will be used in 
///	calls to CommitConfiguration,CreateDataBlock, SetBlockModified.
//**********************************************************************
CMMERROR CMM_API CreateConfiguration(DWORD *dwConfigurationID, DWORD *pdwSessionNumber) {
	CMMSTATUS eCmmStatus = glbObjRequestHandler.CreateConfiguration(dwConfigurationID, pdwSessionNumber);

	return glbObjRequestHandler.ConvertStatusToErrorCode(eCmmStatus);
}

//**********************************************************************
///
/// Allocates buffer to store the configuration file
///
/// @param[in]	dwConfigurationID - The id of the configuration for 
///									which the memory will be allocated.
///
///
/// @param[in]	dwBufferSize	  - Size of the memory to be allocated
///
/// @param[out]	pByBuffer		  - Pointer to the newly allocated buffer.
///
/// @return		Error code if failed, CMM_SUCCESS if okay
/// 
//**********************************************************************
CMMERROR CMM_API AllocateBuffer(DWORD dwConfigurationID, DWORD dwBufferSize, BYTE **pByBuffer) {

#ifdef PWDLOGS_ENABLE
	WCHAR szDbgMsg[512];
	swprintf( szDbgMsg, L"CMM_API AllocateBuffer:The id of the configuration for which the memory will be allocated -- dwConfigurationID: %ld GTC %d\n",dwConfigurationID,GetTickCount());
	OutputDebugString(szDbgMsg);
	swprintf( szDbgMsg, L"CMM_API AllocateBuffer: Size of the memory to be allocated-- dwBufferSize: %ld GTC %d\n",dwBufferSize,GetTickCount());
	OutputDebugString(szDbgMsg);
#endif

	CMMSTATUS eCmmStatus = glbObjRequestHandler.AllocateConfigurationBuffer(dwConfigurationID, dwBufferSize, pByBuffer);
#ifdef PWDLOGS_ENABLE
	swprintf( szDbgMsg, L"CMM_API AllocateBuffer: Allocates buffer to store the configuration file GTC %d\n",GetTickCount());
	OutputDebugString(szDbgMsg);
#endif

	return glbObjRequestHandler.ConvertStatusToErrorCode(eCmmStatus);
}

//**********************************************************************
///
/// Loads the configuration that has been saved in the allocated
///	buffer
///
///
/// @param[in]	dwConfigurationID - The id of the configuration which  
///									will be loaded
///
/// @param[in]	bPersistedLoad	  - Indicates if the configuration
///									to be loaded is from a persisted or
///									unpersisted source.
///									FALSE = Unpersisted
///									TRUE  = Persisted
///
///	@param[out]	pdwConfigVersion	- The version of the configuration
///										to be loaded.
///
/// @return		Error code if failed, CMM_SUCCESS if okay
///
///	@note	A separate thread will be created to complete the operation,
///			only if a conversion is required.
///	@note	The user is required to call IsConfigurationAvailable to 
///			check if the VersionConversion operation has completed.
///				For VersionConversion:
///				CMM_SUCCESS	- Thread completes successfully
///				CMM_CONFIGURATION_UNAVAILABLE - Thread not completed
///				CMM_CONFIGURATION_CORRUPT - Thread completed with an 
///											error. The working section
///											has been deleted.
///	@note	When loading from an unpersisted source, it should taken
///			care that no working section instances of the blocks 
///			exist. Otherwise, the load cannot proceed.
//**********************************************************************
CMMERROR CMM_API LoadConfiguration(DWORD dwConfigurationID, TV_BOOL bPersistedLoad, DWORD *pdwConfigVersion) {
	CMMSTATUS eCmmStatus = glbObjRequestHandler.LoadConfiguration(dwConfigurationID, bPersistedLoad, pdwConfigVersion);

	return glbObjRequestHandler.ConvertStatusToErrorCode(eCmmStatus);
}

//**********************************************************************
///
/// Commits the configuration taking all the instances in the working
/// section of CMM.
///
/// @param[in]	dwConfigurationID - The id of the configuration whose
///									working instances will be committed.
///
/// @return		Error code if failed, CMM_SUCCESS if okay
/// 
//**********************************************************************
CMMERROR CMM_API CommitConfiguration(DWORD dwConfigurationID) {
	CMMSTATUS eCmmStatus = glbObjRequestHandler.CommitConfiguration(dwConfigurationID);
	return glbObjRequestHandler.ConvertStatusToErrorCode(eCmmStatus);
}

//**********************************************************************
///
/// Deletes  all the working section instances of a configuration
///
/// @param[in]	dwConfigurationID - The id of the configuration whose
///									working instances will be deleted.
///
/// @return		Error code if failed, CMM_SUCCESS if okay
/// 
//**********************************************************************
CMMERROR CMM_API ClearConfiguration(DWORD dwConfigurationID) {
	CMMSTATUS eCmmStatus = glbObjRequestHandler.ClearConfiguration(dwConfigurationID);
	return glbObjRequestHandler.ConvertStatusToErrorCode(eCmmStatus);
}

//**********************************************************************
/// Added to cleanup the metadata MAP created 
/// during the time of initialise of CMM.
///
/// @return		Error code if failed, CMM_SUCCESS if okay
/// 
//**********************************************************************
CMMERROR CMM_API ShutdownCMM() {
	CMMSTATUS eCmmStatus = glbObjRequestHandler.UninitiliseLookup();
	return glbObjRequestHandler.ConvertStatusToErrorCode(eCmmStatus);
}

//**********************************************************************
///
/// Discards all the changes made to the working section instances of a 
///	configuration. All working section instances will be copied with
///	the committed instances if they exist. Otherwise they will be
///	deleted. The working section will exactly reflect the Current
///	section.
///
/// @param[in]	dwConfigurationID - The id of the configuration whose
///									changes in working instances will 
///									be discarded.
///
/// @return		Error code if failed, CMM_SUCCESS if okay
/// 
///	@note	A separate thread will be created to complete the operation.
///			The user is required to call IsConfigurationAvailable to 
///			check if the Discard operation has completed.
///				CMM_SUCCESS	- Thread completes successfully
///				CMM_CONFIGURATION_UNAVAILABLE - Thread not completed
///				CMM_CONFIGURATION_CORRUPT - Thread completed with an 
///											error. The working section
///											has been deleted.
//**********************************************************************
CMMERROR CMM_API DiscardChanges(DWORD dwConfigurationID) {
	//get the access flag of the configuration
	WORD wAccessFlag = ALLOW_CURRENT;
	CMMSTATUS eCmmStatus = glbObjRequestHandler.SetConfigurationAccess(dwConfigurationID, &wAccessFlag);
	if (CSTATUS_OK != eCmmStatus) {
		return glbObjRequestHandler.ConvertStatusToErrorCode(eCmmStatus);
	}

	//store the details in a temp structure created in the heap
	DISCARD_THREAD_PARAMS *pDiscardParms = new DISCARD_THREAD_PARAMS;
	//set the value of the current request handler object and config id,
	//to be passed to the new thread.
	pDiscardParms->objReqHandler = (void*) &glbObjRequestHandler;
	pDiscardParms->dwConfigurationId = dwConfigurationID;
	pDiscardParms->wAccessFlag = wAccessFlag;
	pDiscardParms->wOperation = OPR_DISCARD;

	DWORD dwThreadId;
	//start the new thread.
	HANDLE hDiscardThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE) CRequestHandler::ThreadStartFunction,
			pDiscardParms, 0, &dwThreadId);
	qDebug("CMM Discard Thread 1 ID: %u\n", dwThreadId);

	if (NULL == hDiscardThread) {
		//unable to create new thread.. send back failure message.
		delete pDiscardParms;
		return glbObjRequestHandler.ConvertStatusToErrorCode(CSTATUS_FAIL);
	} else {
		//thread successfully created.
		//thread handle no longer required.
		//No need to close the mutex in Qt;
		hDiscardThread = NULL;
		return glbObjRequestHandler.ConvertStatusToErrorCode(CSTATUS_OK);
	}
}
//**********************************************************************
///
/// Deletes  all the working and current section instances of a 
///	and deallocates all the memory allocated to the configuration.
///
/// @param[in]	dwConfigurationID - The id of the configuration whose
///									working instances will be deleted.
///
/// @return		Error code if failed, CMM_SUCCESS if okay
/// 
//**********************************************************************
CMMERROR CMM_API DeleteConfiguration(DWORD dwConfigurationID) {
	CMMSTATUS eCmmStatus = glbObjRequestHandler.DeleteConfiguration(dwConfigurationID);
	return glbObjRequestHandler.ConvertStatusToErrorCode(eCmmStatus);
}

//**********************************************************************
///
/// Checks if the working/current section of the configuration is 
///	currently in use by another thread.
///
/// @param[in]	dwConfigurationID - The id of the configuration whose
///									working instances will be deleted.
///
/// @param[in]	wReference		  - Indicates if the working section 
///									or the current section is to be 
///									checked.
///									CONFIG_MODIFIABLE = Working Section
///									CONFIG_COMMITTED  = Current Section
///
/// @return		Error code if failed, CMM_SUCCESS if access available
///				CMM_SUCCESS	- Config can be used.
///				CMM_CONFIGURATION_UNAVAILABLE - Another thread is working
///												on the configuration
///				CMM_CONFIGURATION_CORRUPT - The previous operation 
///											corrupted the configuration
///											and the working section
///											has been deleted.
///
//**********************************************************************
CMMERROR CMM_API IsConfigurationAvailable(DWORD dwConfigurationID, WORD wReference) {
	CMMSTATUS eCmmStatus = glbObjRequestHandler.IsConfigurationAvailable(dwConfigurationID, wReference);
	return glbObjRequestHandler.ConvertStatusToErrorCode(eCmmStatus);
}

//**********************************************************************
///
/// Gets the Current section configuration.
///
/// @param[in]	dwConfigurationID - The id of the configuration whose
///									configuration is to be fetched.
///
/// @param[out]	pdwBufferSize	  - Size of the memory to be configuration
///
/// @param[out]	pByBuffer		  - Pointer to the newly configuration.
///
/// @return		Error code if failed, CMM_SUCCESS if okay
/// 
//**********************************************************************
CMMERROR CMM_API GetConfiguration(DWORD dwConfigurationID, DWORD *pdwBufferSize, BYTE **pByBuffer) {
	CMMSTATUS eCmmStatus = glbObjRequestHandler.GetConfiguration(dwConfigurationID, pdwBufferSize, pByBuffer);
	return glbObjRequestHandler.ConvertStatusToErrorCode(eCmmStatus);
}

//**********************************************************************
///
/// Creates a new working section block for the given block type and
///	instance id.
///
/// @param[in]	dwConfigurationID - The id of the configuration for 
///									which a new working section block is
///									to be created. 
///
/// @param[in]	pBlockDetails->wBlockType  - The block type to be created
///										  
/// @param[in]	pBlockDetails->wInstanceID - The id of the block to be 
///											 created.
///
/// @param[out]	pBlockDetails->pByBlock	 - Pointer to the newly created
///											 block.
///
/// @param[in,out] pBlockDetails->dwBlockSize - The size of the block to 
///												be created.
///										[out] If the block type is 
///												defined using the DDP
///												Tool, the size of the created
///												block will be returned.
///										[in]	If the block type is of
///												variable data type, the size
///												given in this variable will
///												be used as the size of the 
///												data block to be created.
///
/// @return		Error code if failed, CMM_SUCCESS if okay
/// 
//**********************************************************************
CMMERROR CMM_API CreateDataBlock(DWORD dwConfigurationID, BLOCK_INFO *pBlockDetails) {
	CMMSTATUS eCmmStatus = glbObjRequestHandler.CreateDataBlock(dwConfigurationID, pBlockDetails);

	return glbObjRequestHandler.ConvertStatusToErrorCode(eCmmStatus);
}

//**********************************************************************
///
/// Gets the working/current section block for the given block type and
///	instance id.
///
/// @param[in]	dwConfigurationID - The id of the configuration for 
///									which the working/current section block 
///									is to be fetched. 
///
/// @param[in]	pBlockDetails->wBlockType  - The block type to be fetched.
///										  
/// @param[in]	pBlockDetails->wInstanceID - The id of the block to be 
///											 fetched.
///
/// @param[out]	pBlockDetails->pByBlock	 - Pointer to the required data 
///											 block.
///
/// @param[out] pBlockDetails->dwBlockSize - The size of the data block. 
///
/// @param[in]	wReference		  - Indicates if the working section 
///									or the current section of the data 
///									block is to be fetched.
///									CONFIG_MODIFIABLE = Working Section
///									CONFIG_COMMITTED  = Current Section
///
/// @return		Error code if failed, CMM_SUCCESS if okay
/// 
///	@note						When Current section exists and if the 
///								working section exists, working section 
///								will be copied with contents of the 
///								current section. If working doesnt exist, 
///								the working section will be 
///								created and copied with contents of the 
///								current section.
///	@note						When current section doesnt exist,
///								whatever is in the working section
///								will be returned as it is.
//**********************************************************************
CMMERROR CMM_API GetDataBlock(DWORD dwConfigurationID, BLOCK_INFO *pBlockDetails, WORD wReference) {
	CMMSTATUS eCmmStatus = glbObjRequestHandler.GetDataBlock(dwConfigurationID, pBlockDetails, wReference);
	return glbObjRequestHandler.ConvertStatusToErrorCode(eCmmStatus);
}

//**********************************************************************
///
/// Modifies the working section block with the given block type and
///	instance id.
///
/// @param[in]	dwConfigurationID - The id of the configuration for 
///									which the working/current section block 
///									is to be fetched. 
///
/// @param[in]	pBlockDetails->wBlockType  - The block type to be fetched.
///										  
/// @param[in]	pBlockDetails->wInstanceID - The id of the block to be 
///											 fetched.
///
/// @param[in]	pBlockDetails->pByBlock	 - Pointer to the modified data
///											 block.
///
/// @param[in] pBlockDetails->dwBlockSize  - The size of the data block. 
///										 	 If the block type is of
///										 	 variable data type, the size
///											 given in this variable will
///											 be used as the size of the 
///											 data block to be modified.
///
///
/// @return		Error code if failed, CMM_SUCCESS if okay
/// 
//**********************************************************************
CMMERROR CMM_API ModifyDataBlock(DWORD dwConfigurationID, BLOCK_INFO *pBlockDetails) {
	CMMSTATUS eCmmStatus = glbObjRequestHandler.SetDataBlock(dwConfigurationID, pBlockDetails);

	return glbObjRequestHandler.ConvertStatusToErrorCode(eCmmStatus);
}

//**********************************************************************
///
/// Sets the dirty of the data block to indicate that a change has been
///	done on the working section of the data block.
///
/// @param[in]	dwConfigurationID - The id of the configuration for 
///									which the working section data block 
///									is to be set as Modified.
///
/// @param[in]	pBlockDetails->wBlockType  - The block type to be fetched.
///										  
/// @param[in]	pBlockDetails->wInstanceID - The id of the block to be 
///											 fetched.
///
/// @param[out] pBlockDetails->dwSessionNumber  - The session number that
///										 		  was affixed to the data
///										 		  block after setting the
///												  dirty bit.
///
/// @return		Error code if failed, CMM_SUCCESS if okay
/// 
//**********************************************************************
CMMERROR CMM_API SetBlockModified(DWORD dwConfigurationID, BLOCK_INFO *pBlockDetails) {
	CMMSTATUS eCmmStatus = glbObjRequestHandler.SetBlockModified(dwConfigurationID, pBlockDetails);

	return glbObjRequestHandler.ConvertStatusToErrorCode(eCmmStatus);
}

//**********************************************************************
///
/// Deletes the working section of the given block type/instance id for
///	a given configuration.
///
/// @param[in]	dwConfigurationID - The id of the configuration for 
///									which the working section data block 
///									is to be deleted.
///
/// @param[in]	pBlockDetails->wBlockType  - The block type to be deleted.
///										  
/// @param[in]	pBlockDetails->wInstanceID - The id of the block to be 
///											 deleted.
///
///
/// @return		Error code if failed, CMM_SUCCESS if okay
/// 
//**********************************************************************
CMMERROR CMM_API DeleteDataBlock(DWORD dwConfigurationID, BLOCK_INFO *pBlockDetails) {
	CMMSTATUS eCmmStatus = glbObjRequestHandler.DeleteDataBlock(dwConfigurationID, pBlockDetails);

	return glbObjRequestHandler.ConvertStatusToErrorCode(eCmmStatus);
}

//**********************************************************************
///
/// Gets the count of the number of current/working section instances
///	for a given block type in a configuration
///
/// @param[in]	dwConfigurationID - The id of the configuration for 
///									which the number of instances of a
///									given block type is to be counted.
///
/// @param[in]	wBlockType		  - The block type to count the number of
///									instances
///
/// @param[in]	wReference		  - Indicates if the working section 
///									or the current section of the config
///									is to be counted.
///									CONFIG_MODIFIABLE = Working Section
///									CONFIG_COMMITTED  = Current Section
///										  
/// @param[out]	pdwBlockCount	  - The buffer into which the number of 
///									instances for a block type will be 
///									stored.
///
/// @return		Error code if failed, CMM_SUCCESS if okay
/// 
//**********************************************************************
CMMERROR CMM_API GetCountByBlock(DWORD dwConfigurationID, WORD wBlockType, WORD wReference, DWORD *pdwBlockCount) {
	CMMSTATUS eCmmStatus = glbObjRequestHandler.GetCountByBlock(dwConfigurationID, wBlockType, wReference,
			pdwBlockCount);
	return glbObjRequestHandler.ConvertStatusToErrorCode(eCmmStatus);
}

//**********************************************************************
///
/// Gets the count of the number of blocks in a configuration.	
///
/// @param[in]	dwConfigurationID - The id of the configuration for 
///									which the number of blocks is to be
///									counted.
///
/// @param[in]	wReference		  - Indicates if the working section 
///									or the current section of the config
///									is to be counted.
///									CONFIG_MODIFIABLE = Working Section
///									CONFIG_COMMITTED  = Current Section
///						  
/// @param[out]	pBlockCount		  - The buffer into which the number of 
///									blocks in a given configuration will 
///									be stored.
/// @return		Error code if failed, CMM_SUCCESS if okay
/// 
//**********************************************************************
CMMERROR CMM_API GetBlockCount(DWORD dwConfigurationID, WORD wReference, DWORD *pBlockCount) {
	CMMSTATUS eCmmStatus = glbObjRequestHandler.GetBlockCount(dwConfigurationID, wReference, pBlockCount);
	return glbObjRequestHandler.ConvertStatusToErrorCode(eCmmStatus);
}

//**********************************************************************
///
/// Validates a data block to check if all the values of the given block
///	are within the ranges specified in the structure declaration.
///
/// @param[in]	dwConfigurationID - The id of the configuration whose 
///									data block is to be validated.
///
/// @param[in]	pBlockDetails->wBlockType  - The block type to be validated.
///										  
/// @param[in]	pBlockDetails->wInstanceID - The id of the block to be 
///											 validated.
///
///	@param[out] pIsBlockValid	 -  Buffer into which the result of the 
///									validation will be stored.
///									TRUE	- Valid Data block
///									FALSE	- Invalid Data block
///
///	@param[out]	pInvalidMemberName	- Pointer to the buffer in which
///									  the name of the member which is 
///									  out of range will be stored. The
///									  memory will be created in the heap.
///									  The client has to deallocate the
///									  memory allocated in this call using
///									  a call to delete[]. The memory will
///									  be created only when the error is
///									  CSTATUS_VALUE_OUT_OF_RANGE.
///
/// @return		Error code if failed, CMM_SUCCESS if okay
///
///	@note:	 The memory(pInvalidMemberName) will be created in the heap.
///			 The client has to deallocate the memory 
///			 allocated in this call using a call to 
///			 delete[]. 
///
///	@note:	 The memory will be created only when the return value is
///			 CMM_VALUE_OUT_OF_RANGE.
///  
//	Modification History
//	Sai Krishnan	17/09/2004	CMM PCR No : 50
//								A new argument has been added which
//								will return the out of range member
//								name(As a UNICODE string)
//**********************************************************************
CMMERROR CMM_API ValidateDataBlock(DWORD dwConfigurationID, BLOCK_INFO *pBlockDetails, TV_BOOL *pIsBlockValid,
		QString *pInvalidMemberName) {
	CMMSTATUS eCmmStatus = glbObjRequestHandler.ValidateDataBlock(dwConfigurationID, pBlockDetails, pIsBlockValid,
			pInvalidMemberName);

	return glbObjRequestHandler.ConvertStatusToErrorCode(eCmmStatus);
}

//**********************************************************************
///
/// The function enumerates modified working section instances of the 
/// given block type within a configuration.
///
/// @param[in]	dwConfigurationID - The id of the configuration for 
///									which the next modified workingsection 
///									instance is to be fetched. 
///
/// @param[in]	wIndex		-	Index of the instance to retrieve. This 
///								parameter should be 1 for the first call
///								to this function and then incremented for 
///								subsequent calls. 
///
/// @param[in]	pBlockDetails->wBlockType  - The block type to be fetched.
///										  
/// @param[in]	pBlockDetails->wInstanceID - The id of the block to be 
///											 fetched.
///
/// @param[out]	pBlockDetails->pByBlock	 - Pointer to the required data 
///											 block.
///
/// @param[out] pBlockDetails->dwBlockSize - The size of the data block. 
///
/// @param[out] pBlockDetails->dwSessionNumber  - The session number that
///										 		  was affixed to the data
///										 		  block after setting the
///												  dirty bit.
///
/// @return		Error code if failed, CMM_SUCCESS if okay
/// 
//**********************************************************************
CMMERROR CMM_API GetNextChangeBlock(DWORD dwConfigurationID, WORD wIndex, BLOCK_INFO *pBlockDetails) {
	CMMSTATUS eCmmStatus = glbObjRequestHandler.GetNextChangeBlock(dwConfigurationID, pBlockDetails, wIndex);

	return glbObjRequestHandler.ConvertStatusToErrorCode(eCmmStatus);
}

//**********************************************************************
///
/// Updates the statistics in the Save section of the current section
///	configuration header.
///
/// @param[in]	nConfigurationID -  The configuration id whose 
///								  configuration header has to be 
///								  changed.
/// @param[in]	pConfigDetails	 -  Buffer containing the  
///								  the configuration header 
///								  structure
///
/// @return		Error code if failed, CMM_SUCCESS if okay
/// 
//**********************************************************************
CMMERROR CMM_API SetConfigurationLog(DWORD dwConfigurationID, CONFIGHEADERINFO *pConfigDetails) {
	CMMSTATUS eCmmStatus = glbObjRequestHandler.SetConfigurationLog(dwConfigurationID, pConfigDetails);

	return glbObjRequestHandler.ConvertStatusToErrorCode(eCmmStatus);
}
//**********************************************************************
///
/// Function returns the size of the block type as CMM would process it.
///
/// @param[in]	wBlockType - The block type whose size is to be 
///							 returned
///
/// @param[out]	pdwBlockSize - Size of the block									 
///
/// @return		Error code if failed, CSTATUS_OK if okay
/// 
//**********************************************************************
CMMERROR CMM_API GetSizeOfBlockType(WORD wBlockType, DWORD *pdwBlockSize) {
	CMMSTATUS eCmmStatus = glbObjRequestHandler.GetSizeOfBlockType(wBlockType, pdwBlockSize);
	return glbObjRequestHandler.ConvertStatusToErrorCode(eCmmStatus);
}
//**********************************************************************
///
/// Function returns the size of the block type as CMM would process it.
///
/// @param[in]	dwConfigurationID  - The configuration id of the block
///									 in	which to search for the block.
///
/// @param[in]	wBlockType - The block type of the block to be 
///							 defaulted. If only a nested structure
///								within the block is to be defaulted,
///								then the nested structure's block 
///								type should be sent.
///	
/// @param[in]	wInstanceId  - The instance id of the block to be 
///							  defaulted. If only a nested structure
///								within the block is to be defaulted,
///								then the nested structure's parent's
///								instance id should be sent.
///
///	@param[in]	pByBlockData -	The pointer to the start of the block.
///								If only a nested structure is to be 
///								defaulted, then the pointer should be
///								to the start of the nested structure
///								within the block.
///
/// @return		Error code if failed, CSTATUS_OK if okay
/// 
//**********************************************************************
CMMERROR CMM_API SetBlockToDefaults(DWORD dwConfigurationID, WORD wBlockType, WORD wInstanceId, BYTE *pByBlockData) {
	CMMSTATUS eCmmStatus = glbObjRequestHandler.SetBlockToDefaults(dwConfigurationID, wBlockType, wInstanceId,
			pByBlockData);
	return glbObjRequestHandler.ConvertStatusToErrorCode(eCmmStatus);
}

//**********************************************************************
///
/// Sets the function pointer for function GlbUpdateThreadInfo
///
/// @param[in]	PFnUpdateThreadInfo  - Function pointer of function 
///									 GlbUpdateThreadInfo
///
/// @return		Error code if failed, CSTATUS_OK if okay
/// 
//**********************************************************************
CMMERROR CMM_API SetThreadInfo(PFnUpdateThreadInfo pFnUpdateThreadInfo) {

	CMMSTATUS eCmmStatus = CSTATUS_OK;
	//Call to V6App global function 
	if (pFnUpdateThreadInfo != NULL) {
		eCmmStatus = glbObjRequestHandler.SetThreadInfo(pFnUpdateThreadInfo);
	}

	return glbObjRequestHandler.ConvertStatusToErrorCode(eCmmStatus);

}

//**********************************************************************
///
/// Sets the function pointer for function GlbUpdateThreadCounter
///
/// @param[in]	PFnUpdateThreadCounter  - Function pointer of function 
///									  GlbUpdateThreadCounter
///									 
///
/// @return		Error code if failed, CSTATUS_OK if okay
/// 
//**********************************************************************
CMMERROR CMM_API SetThreadCounter(PFnUpdateThreadCounter pFnUpdateThreadCounter) {

	CMMSTATUS eCmmStatus = CSTATUS_OK;
	//Call to V6App global function 
	if (pFnUpdateThreadCounter != NULL) {
		eCmmStatus = glbObjRequestHandler.SetThreadCounter(pFnUpdateThreadCounter);
	}

	return glbObjRequestHandler.ConvertStatusToErrorCode(eCmmStatus);
}


/// @file CVersionConvertor.h
/// ***************************************************************************************
/// Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Version Convertor
/// @n Filename: CVersionConvertor.h
/// @n Desc:	 Functions Definitions of the functionality of
///				 the version conversion class
///
//  ****************************************************************
//  Revision History
//  ****************************************************************
//  $Log[4]:
// 10  Stability Project 1.7.1.1  7/2/2011 4:56:28 PM Hemant(HAIL) 
//  Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
// 9 Stability Project 1.7.1.0  7/1/2011 4:26:36 PM Hemant(HAIL) 
//  Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
// 8 V6 Firmware 1.7  1/25/2006 4:14:14 PM  Shyam (HTSL) 
//  Enhancement request on CMM to retain bitfield values when upgraded. A
//  new method has been added to copy bit field values.
// 7 V6 Firmware 1.6  1/11/2006 3:08:39 PM  Shyam (HTSL) 
//  Reverted back parametr TV_BOOL
//  $
//
//  ***************************************************************************************
/******************************************************************************************
  COPYRIGHT (c) 2004
 HONEYWELL INC.,
  ALL RIGHTS RESERVED

  This software is a copyrighted work and/or information protected
  as a trade secret. Legal rights of Honeywell Inc. in this
  software is distinct from ownership of any medium in which the
  software is embodied. Copyright or trade secret notices included
  must be reproduced in any copies authorized by Honeywell Inc.
  The information in this software is subject to change without
  notice and should not be considered as a commitment by Honeywell
  Inc.
******************************************************************************************/


#ifndef _INC_CVERSIONCONVERTOR_409F624B0148_INCLUDED
#define _INC_CVERSIONCONVERTOR_409F624B0148_INCLUDED
#include "Global.h"
#include "Macro.h"
//******************************************************
//  CVersionConvertor
///
/// @brief Implements the Version Conversion Functionality
/// 
/// VersionConvertor services the forward and backward migration 
///	of configurations between versions
//******************************************************

class CVersionConvertor 
{
public:
	CVersionConvertor(WORD wVersion);
	~CVersionConvertor();
	CMMSTATUS Convert(DWORD nConfigurationID);
private:
	CMMSTATUS ConvertData(WORD wBlockType, BYTE *pSourceData, long lSourcePosition,BYTE *pByConvertedData,long lDestinationPosition);
	CMMSTATUS DimensionCheckAndConvert (IDENTIFIER_RECORD_INFO *pSrcIdentifierInfo, BYTE *pSource,IDENTIFIER_RECORD_INFO *pDestIdentifierInfo,BYTE *pDestination);
	CMMSTATUS BitFieldCopy (IDENTIFIER_RECORD_INFO *pSrcIdentifierInfo, BYTE *pSource,IDENTIFIER_RECORD_INFO *pDestIdentifierInfo,BYTE *pDestination, WORD *pwStart);
	CMMSTATUS CopyData(IDENTIFIER_RECORD_INFO *pSrcIdentifierInfo, BYTE *pSource,IDENTIFIER_RECORD_INFO *pDestIdentifierInfo,BYTE *pDestination,long *lSrcPosition,long *lDesPosition,BOOL *pBStatus);
  static CMMSTATUS FieldCopy (IDENTIFIER_RECORD_INFO *pSrcIdentifierInfo, BYTE *pSource,
											 IDENTIFIER_RECORD_INFO *pDestIdentifierInfo,BYTE *pDestination);
  static CMMSTATUS CopyBits(BYTE* pByPtr,	BYTE*, WORD wDataType,
									  WORD* wPosition,WORD wInstanceCount);

	BOOL ConversionAllowed (WORD pSrcDataType, WORD pDesDataType);

	WORD m_wSystemVersion;
	DWORD m_dwConfigurationID;	//The Configuration ID being converted.
};



#endif /* _INC_CVERSIONCONVERTOR_409F624B0148_INCLUDED */


/// @file CRequestHandler.cpp
/// ****************************************************************
/// Â© Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Request Handler
/// @n Filename: CRequestHandler.cpp
/// @n Desc:	 Implementation of the exposed C APIs for 
///				 configuration management
///
//  ****************************************************************
//  Revision History
//  ****************************************************************
//  $Log[4]:
// 23  Aristos  1.17.1.3.1.0 9/19/2011 4:51:10 PM  Hemant(HAIL) 
//    Stability recorder source code (JI Release) updated for WatchDog
//    Timer functionality.
// 22  Stability Project 1.17.1.3   7/2/2011 4:56:25 PM   Hemant(HAIL) 
//    Stability Project: Recorder source has been upgraded from IL
//    version of firmware to JF version of firmware.
// 21  Stability Project 1.17.1.2   7/1/2011 4:38:10 PM   Hemant(HAIL) 
//    Stability Project: Files has been checked in before the merging
//    task. The merging will be done between IL version of firmware and JF
//    version of firmware. 
// 20  Stability Project 1.17.1.1   3/17/2011 3:20:18 PM  Hemant(HAIL) 
//    Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//    new operator in DEBUG mode only. To detect memory leaks in files, use
//    it in preprocessor definition when in debug mode.
//  $
//
//  ****************************************************************
/******************************************************************************************
 COPYRIGHT (c) 2004
 HONEYWELL INC.,
 ALL RIGHTS RESERVED

 This software is a copyrighted work and/or information protected
 as a trade secret. Legal rights of Honeywell Inc. in this
 software is distinct from ownership of any medium in which the
 software is embodied. Copyright or trade secret notices included
 must be reproduced in any copies authorized by Honeywell Inc.
 The information in this software is subject to change without
 notice and should not be considered as a commitment by Honeywell
 Inc.
 ******************************************************************************************/

#include "CMMDefines.h"
#include "Global.h"
#include "CVersionConvertor.h"
#include "CMemoryManager.h"
#include "CRequestHandler.h"
#include "Conversion.h"
#include "V6crc.h"
#include "ThreadInfo.h"

#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif

/*********************Extern Definitions*************************************/
//global memory manager object declared in CMemoryManager.h
extern CMemoryManager glbObjMemoryManager;	///< Global memory manager object. (defined in Global.cpp)
/*********************Extern Definitions*************************************/

//******************************************************
//  CRequestHandler Constructor()
///
/// Constructor - Initializes the CMM parameters.
/// 
//******************************************************
CRequestHandler::CRequestHandler() : m_tchHostType(NULL), m_lSerialNumber(0), m_bInitialized(FALSE), m_wVersion(0), m_pFnUpdateThreadCounter(
		NULL), m_pFnUpdateThreadInfo(NULL) {
	//all members initialized with default values.
	//initialize Tracer module
	CCMMUtility objUtility;
	//CB: @delete
	OutputDebugString(_T("CB:CRequestHandler::CRequestHandler() Start...\n"));
	objUtility.LoadTracerModule();
	LOG_INFO(CMM_qDebugR_MODE, ("CRequestHandler - Initializing Request Handler"));
	//CB: @delete
	OutputDebugString(_T("CB:CRequestHandler::CRequestHandler() End...\n"));
}

//**********************************************************************
//  CRequestHandler Destructor()
///
/// Destructor
///	
//**********************************************************************
CRequestHandler::~CRequestHandler() {
	LOG_INFO(CMM_qDebugR_MODE, ("~CRequestHandler - Destroying Request Handler"));
	//close Tracer module if opened
	CCMMUtility objUtility;
	objUtility.UnLoadTracerModule();
}

//**********************************************************************
/// Initializes the CMM with the given metadata.
///
/// @param[in]	tchHostType		- Host type 
///
/// @param[in]	lSerialNumber	- Serial Number of Unit 
///
/// @param[in]	pByMetadata		- Buffer containing the metadata
///								  for the CMM to be initialized with.
///
///	@param[out]	pdwSystemVersion - The version of the system metadata.
///
/// @return		Error code if failed, CSTATUS_OK if okay
/// 
///	@note	The buffer pByMetadata should NEVER be deleted, untill 
///	the CMM itself is unloaded from memory or the CMM is to be 
///	initialized with a new metadata.
//**********************************************************************
CMMSTATUS CRequestHandler::InitializeCMM(QString tchHostType, ULONG lSerialNumber, BYTE *pByMetadata,
		DWORD *pdwSystemVersion) {

	LOG_INFO(CMM_qDebugR_MODE, ("InitializeCMM - Start"));
#ifdef PWDLOGS_ENABLE
	WCHAR szDbgMsg[512];
	swprintf( szDbgMsg, L"CRequestHandler::InitializeCMM - InitializeCMM - Start GTC %d\n",GetTickCount());
	OutputDebugString(szDbgMsg);
#endif
	/**Step 0: Check the arguments*/
	/******************************/
	if (NULL == tchHostType || NULL == pByMetadata || NULL == pdwSystemVersion) {
		// an error has occured
		LOG_ERR(CMM_qDebugR_MODE, ("InitializeCMM - End - CSTATUS_INVALID_PARAMETER"));
#ifdef PWDLOGS_ENABLE
		swprintf( szDbgMsg, L"CRequestHandler::InitializeCMM -  End - CSTATUS_INVALID_PARAMETER GTC %d\n",GetTickCount());
		OutputDebugString(szDbgMsg);
#endif
		return CSTATUS_INVALID_PARAMETER;
	}

	try {
		CMMSTATUS eCmmStatus;
		/**Step 1: Check if CMM has been initialized with metadata already*/
		/******************************************************************/
		if (TRUE == IsCMMInitialized()) {
			// an error has occured
			LOG_ERR(CMM_qDebugR_MODE, ("InitializeCMM - End - CSTATUS_ALREADY_INITIALIZED"));
#ifdef PWDLOGS_ENABLE
			swprintf( szDbgMsg, L"CRequestHandler::InitializeCMM -  End - CSTATUS_ALREADY_INITIALIZED GTC %d\n",GetTickCount());
			OutputDebugString(szDbgMsg);
#endif
			return CSTATUS_ALREADY_INITIALIZED;
		}

		/**Step 2: Create the lookup for metadata using the global function*/
		/*******************************************************************/
		WORD wVersion;	//buffer to store the version of the system metadata
		//check if the pdwSystemVersion is a valid pointer
		*pdwSystemVersion = 0;

		CCMMUtility objUtility;	//object to execute utility functions
		eCmmStatus = objUtility.BuildMetadataLookUp(pByMetadata, SYSTEM_CONFIGURATION_ID,/*System metadata id =0*/
		&wVersion);
		if (CSTATUS_OK != eCmmStatus) {
			LOG_ERR(CMM_qDebugR_MODE, ("InitializeCMM - End - Metadatalookup creation failed : %d"), eCmmStatus);
#ifdef PWDLOGS_ENABLE
			swprintf( szDbgMsg, L"CRequestHandler::InitializeCMM -  End - Metadatalookup creation failed : %d GTC %d\n",eCmmStatus,GetTickCount());
			OutputDebugString(szDbgMsg);
#endif
			SetCMMInitialized(FALSE);	//set CMM state as uninitialized
			SetHostType (NULL);			//reset Host Type member variable
			SetSerialNumber(0);			//reset Serial Number member variable
			SetSystemMetadataVersion(0);	//reset System Metadata version member variable
			return eCmmStatus;
		}

		/**Step 3: Set Host Type,serial no and version number as member variables*/
		/*************************************************************************/
		SetHostType(tchHostType);
		SetSerialNumber(lSerialNumber);
		SetSystemMetadataVersion(wVersion);
		*pdwSystemVersion = wVersion;

		/**Step 4: Set the initialized flag*/
		/***********************************/
		SetCMMInitialized(TRUE);	//set CMM state as initialized

		LOG_INFO(CMM_qDebugR_MODE, ("InitializeCMM - CSTATUS_OK"));
#ifdef PWDLOGS_ENABLE
		swprintf( szDbgMsg, L"CRequestHandler::InitializeCMM - CSTATUS_OK GTC %d\n",GetTickCount());
		OutputDebugString(szDbgMsg);
#endif
		return CSTATUS_OK;
	} catch (...) {
		LOG_ERR(CMM_qDebugR_MODE, ("InitializeCMM - Exception - GetLastError : %d"), GetLastError());
		return CSTATUS_FAIL;
	}
}

//**********************************************************************
///
/// Creates a new configuration id.
///
/// @param[out]	pdwConfigurationID - Buffer to store the newly created 
///				  				 configuration's id.
///
/// @param[in]	pdwSessionNumber - Buffer containing the session 
///								 number. The value in the buffer
///								 will be affixed to the data blocks
///								 when the blocks are modified
///
/// @return		Error code if failed, CSTATUS_OK if okay
/// 
//**********************************************************************
CMMSTATUS CRequestHandler::CreateConfiguration(DWORD *pdwConfigurationID, DWORD *pdwSessionNumber) {

	LOG_INFO(CMM_qDebugR_MODE, ("CreateConfiguration - Start"));
#ifdef PWDLOGS_ENABLE
	WCHAR szDbgMsg[512];
	swprintf( szDbgMsg, L" CRequestHandler::CreateConfiguration - Start , GTC %d\n",GetTickCount());
	OutputDebugString(szDbgMsg);
#endif
	/**Step 0: Check the arguments*/
	/******************************/

#ifdef PWDLOGS_ENABLE
	swprintf( szDbgMsg, L" CRequestHandler::CreateConfiguration - pdwConfigurationID : %ld , GTC %d\n",*pdwConfigurationID,GetTickCount());
	OutputDebugString(szDbgMsg);
	swprintf( szDbgMsg, L" CRequestHandler::CreateConfiguration - SessionNumber : %ld , GTC %d\n",*pdwSessionNumber,GetTickCount());
	OutputDebugString(szDbgMsg);
#endif

	if (NULL == pdwConfigurationID || NULL == pdwSessionNumber) {
		// an error has occured
		LOG_ERR(CMM_qDebugR_MODE, ("CreateConfiguration - End - CSTATUS_INVALID_PARAMETER"));
		return CSTATUS_INVALID_PARAMETER;
	}

	try {
		//check if session number pointer is valid. If it isnt, a CSTATUS_FAIL will be returned
		DWORD dwTempSessionNumber = *pdwSessionNumber;

		/**Step 1: Check if CMM has been initialized with metadata and lookups created*/
		/******************************************************************************/
		if (FALSE == IsCMMInitialized()) {
			// an error has occured
			LOG_ERR(CMM_qDebugR_MODE, ("CreateConfiguration - End - CSTATUS_CONFIGURATION_NOTINITIALIZED"));
			return CSTATUS_CONFIGURATION_NOTINITIALIZED;
		}

		/**Step 2: Invoke memory manager and initialize configuration (Create a configuration 
		 placeholder)*/
		/************************************************************************************/
		CMMSTATUS eCmmStatus;	//stores status of the InitializeConfiguration function call.
		eCmmStatus = glbObjMemoryManager.InitializeConfiguration(pdwSessionNumber, pdwConfigurationID);
		if (CSTATUS_OK != eCmmStatus) {
			// an error has occured
			LOG_ERR(CMM_qDebugR_MODE, ("CreateConfiguration - End - Initialize Configuration failed : %d"), eCmmStatus);
			return eCmmStatus;
		}

		/**Step 3: Set the accessibility to this configuration to  
		 ALLOW_ALL to allow modifiable blocks to be 
		 created for this configuration.
		 COMMITTED blocks can be accessed,but it might 
		 return a failure if it is not present,*/
		/************************************************************/
		eCmmStatus = glbObjMemoryManager.SetAccess(*pdwConfigurationID, ALLOW_ALL);

		//all steps completed successfully.
		LOG_INFO(CMM_qDebugR_MODE, ("CreateConfiguration - Success : %d"), eCmmStatus);
#ifdef PWDLOGS_ENABLE
		swprintf( szDbgMsg, L" CRequestHandler::CreateConfiguration - Success : %d , GTC %d\n",eCmmStatus,GetTickCount());
		OutputDebugString(szDbgMsg);
#endif
		return eCmmStatus;
	} catch (...) {
		//an exception has occured
		LOG_ERR(CMM_qDebugR_MODE, ("CreateConfiguration - Exception - GetLastError : %d"), GetLastError());
		return CSTATUS_FAIL;
	}
}

//**********************************************************************
///
/// Allocates buffer to store the configuration file
///
/// @param[in]	dwConfigurationID - The id of the configuration for 
///									which the memory will be allocated.
///
///
/// @param[in]	dwBufferSize	  - Size of the memory to be allocated
///
/// @param[out]	pByBuffer		  - Pointer to the newly allocated buffer.
///
/// @param[in]	wAccessFlag		  - Access level to be set to the configuration
///									after allocating buffer
///
/// @return		Error code if failed, CSTATUS_OK if okay
/// 
//**********************************************************************
CMMSTATUS CRequestHandler::AllocateConfigurationBuffer(DWORD dwConfigurationID, DWORD dwBufferSize, BYTE **pByBuffer,
		WORD wAccessFlag) {

	LOG_INFO(CMM_qDebugR_MODE, ("AllocateConfigurationBuffer - Start"));
#ifdef PWDLOGS_ENABLE
	WCHAR szDbgMsg[512];
	swprintf( szDbgMsg, L"CRequestHandler::AllocateConfigurationBuffer: AllocateConfigurationBuffer - Start GTC %d\n",GetTickCount());
	OutputDebugString(szDbgMsg);
#endif

	/**Step 0: Check the arguments*/
	/******************************/
	if (0 == dwConfigurationID) {
		LOG_ERR(CMM_qDebugR_MODE, ("AllocateConfigurationBuffer - End - Config Id = 0"));
#ifdef PWDLOGS_ENABLE
		swprintf( szDbgMsg, L"CRequestHandler::AllocateConfigurationBuffer: AllocateConfigurationBuffer - End - Config Id = 0 GTC %d\n",GetTickCount());
		OutputDebugString(szDbgMsg);
#endif
		return CSTATUS_INVALID_CONFIGURATION;
	}
	if (0 == dwBufferSize || NULL == pByBuffer) {
		LOG_ERR(CMM_qDebugR_MODE, ("AllocateConfigurationBuffer - End - CSTATUS_INVALID_PARAMETER"));
#ifdef PWDLOGS_ENABLE
		swprintf( szDbgMsg, L"CRequestHandler::AllocateConfigurationBuffer: AllocateConfigurationBuffer - End - CSTATUS_INVALID_PARAMETER GTC %d\n",GetTickCount());
		OutputDebugString(szDbgMsg);
#endif
		return CSTATUS_INVALID_PARAMETER;
	}

	try {
		/**Step 1: Check if CMM has been initialized with metadata and lookups created*/
		/******************************************************************************/
		if (FALSE == IsCMMInitialized()) {
			// an error has occured
			LOG_ERR(CMM_qDebugR_MODE, ("AllocateConfigurationBuffer - End - CSTATUS_CONFIGURATION_NOTINITIALIZED"));
#ifdef PWDLOGS_ENABLE
			swprintf( szDbgMsg, L"CRequestHandler::AllocateConfigurationBuffer: AllocateConfigurationBuffer - End - CSTATUS_CONFIGURATION_NOTINITIALIZED GTC %d\n",GetTickCount());
			OutputDebugString(szDbgMsg);
#endif
			return CSTATUS_CONFIGURATION_NOTINITIALIZED;
		}
		/**********************************************************/
		//Note : Build Configuration will delete the configuration
		//Note : if it already exists and reallocate the buffer of 
		//Note : the required size.
		/**********************************************************/

		/**Step 2: Invoke memory managers BuildConfiguration 
		 (Create memory for configuration file and update lookup)*/
		/********************************************************************/
		CMMSTATUS eCmmStatus;	//stores status of the Build COnfiguration function call.		
		eCmmStatus = glbObjMemoryManager.BuildConfiguration(dwConfigurationID, dwBufferSize, pByBuffer);
		if (CSTATUS_OK != eCmmStatus) {
			// an error has occured
			LOG_ERR(CMM_qDebugR_MODE, ("AllocateConfigurationBuffer - End - BuildConfig failed : %d"), eCmmStatus);
#ifdef PWDLOGS_ENABLE
			swprintf( szDbgMsg, L"CRequestHandler::AllocateConfigurationBuffer: AllocateConfigurationBuffer - End - BuildConfig failed : %d GTC %d\n",eCmmStatus,GetTickCount());
			OutputDebugString(szDbgMsg);
#endif
			return eCmmStatus;
		}

		/**********************************************************/
		//Note : The accessibility of the configuration will 
		//Note : remain as ALLOW_ALL. Only modifiable blocks
		//Note : can be created on the configuration until a Load 
		//Note : Configuration is done. 
		//Note : The AllocateBuffer can also be called From Request 
		//Note : Handlers CommitConfiguration. The accessibility
		//Note : has to be set ALLOW_NONE before this function is
		//Note : called during Commit.
		/**********************************************************/

		/**Step 3: Set the access of the configuration as requested
		 by caller*/
		/***********************************************************/
		eCmmStatus = glbObjMemoryManager.SetAccess(dwConfigurationID, wAccessFlag);
		if (CSTATUS_OK != eCmmStatus) {
			// an error has occured
			LOG_ERR(CMM_qDebugR_MODE, ("AllocateConfigurationBuffer - End - Unable to set access : %d"), eCmmStatus);
			return eCmmStatus;
		}

		/**********************************************************/
		//Note : When called by CMM client, the fn will set the
		//Note : accessibility to ALLOW_ALL.
		//Note : When called from with Request Handler, the fn 
		//Note : will set the accessibility as desired by the caller
		/**********************************************************/

		LOG_INFO(CMM_qDebugR_MODE, ("AllocateConfigurationBuffer - CSTATUS_OK"));
		return CSTATUS_OK;
	} catch (...) {
		LOG_ERR(CMM_qDebugR_MODE, ("AllocateConfigurationBuffer - Exception - GetLastError : %d"), GetLastError());
		return CSTATUS_FAIL;
	}
}
//**********************************************************************
///
/// Loads the configuration that has been saved in the allocated
///	buffer
///
///
/// @param[in]	dwConfigurationID - The id of the configuration which  
///									will be loaded
///
/// @param[in]	bPersistedLoad	  - Indicates if the configuration
///									to be loaded is from a persisted or
///									unpersisted source.
///									FALSE = Unpersisted
///									TRUE  = Persisted
///
///	@param[out]	pdwConfigVersion	- The version of the configuration
///										to be loaded.
///
/// @return		Error code if failed, CSTATUS_OK if okay
/// 
//	Modification History
//	Sai Krishnan	14/09/2004	CMM PCR No : 49
//								Before a load is started,
//								the configuration access should
//								be set so that no other operation
//								can be performed on the conf when
//								the load is being done. This has
//								been added. 
//
// Shyam		  14th July 05  Made Changes to load the configuration 
//								to working section of CMM.
//**********************************************************************
CMMSTATUS CRequestHandler::LoadConfiguration(DWORD dwConfigurationID, TV_BOOL bPersistedLoad, DWORD *pdwConfigVersion) {
#ifdef PWDLOGS_ENABLE
	WCHAR szDbgMsg[512];
#endif
	LOG_INFO(CMM_qDebugR_MODE, ("LoadConfiguration - Start"));

	/* Change Request - To always load the configuration in working section 
	 of CMM's memory */

	bPersistedLoad = CONFIG_MODIFIABLE;
	/**Step 0: Check the arguments*/
	/******************************/
	if (NULL == pdwConfigVersion) {
		LOG_ERR(CMM_qDebugR_MODE, ("LoadConfiguration - End - Invalid Parameter"));
		return CSTATUS_INVALID_PARAMETER;
	}
	if (0 == dwConfigurationID) {
		LOG_ERR(CMM_qDebugR_MODE, ("LoadConfiguration - End - Config Id=0"));
		return CSTATUS_INVALID_CONFIGURATION;
	}

	WORD wAccessFlag = 0;	//variable to store the current access level of the configuration

	try {
		/**Step 1: Check if CMM has been initialized with metadata and lookups created*/
		/******************************************************************************/
		if (FALSE == IsCMMInitialized()) {
			// an error has occured
			LOG_ERR(CMM_qDebugR_MODE, ("LoadConfiguration - End - CSTATUS_CONFIGURATION_NOTINITIALIZED"));
			return CSTATUS_CONFIGURATION_NOTINITIALIZED;
		}

		/**********************************************************/
		//Note : A Load Configuration will be allowed ONLY when 
		//Note : the accessibility flag is NOT set to "ALLOW_NONE".		
		/**********************************************************/

		CMMSTATUS eCmmStatus;
		/**Step 2: Check if the accessibility is ALLOW_NONE, so that no one else
		 performs an operation on the configuration.*/
		/************************************************************************/
		if (bPersistedLoad) {
			//persisted load only requires the current section
			eCmmStatus = IsOperationAllowed(dwConfigurationID, OPR_LOAD, &wAccessFlag);
		} else {
			//unpersisted load requires the working section
			eCmmStatus = IsOperationAllowed(dwConfigurationID, OPR_CONVERT, &wAccessFlag);
		}
		if (CSTATUS_OK != eCmmStatus) {
			LOG_ERR(CMM_qDebugR_MODE, ("LoadConfiguration - End - Access Denied : %d"), eCmmStatus);
			return eCmmStatus;
		} else {
			//Configuration lookup needs to be created.
			//Calculate the CRC for the configuration and check 
			//its integrity.
			eCmmStatus = CheckIntegrityOfConfiguration(dwConfigurationID);
			if (CSTATUS_OK != eCmmStatus) {
				LOG_ERR(CMM_qDebugR_MODE, ("LoadConfiguration - End - CRC of config failed"));
				//set access to corrupted state
				glbObjMemoryManager.SetAccess(dwConfigurationID, ALLOW_ALL);
				return eCmmStatus;
			}
		}

		/**Step 3: Get the System Metadata version and the metadata version
		 of the configuration file.*/
		/******************************************************************/
		//get the system metadata version
		WORD wSystemVersion = GetSystemMetadataVersion();
#ifdef PWDLOGS_ENABLE
		swprintf( szDbgMsg, L"CRequestHandler::LoadConfiguration :wSystemVersion: %d GTC %d\n",wSystemVersion,GetTickCount());
		OutputDebugString(szDbgMsg);
#endif
		WORD wConfigFileVersion = 0;		//buffer to store the configuration file version
		//get the version of the configuration
		eCmmStatus = GetVersionFromConfigurationFile(dwConfigurationID, &wConfigFileVersion);

		if (CSTATUS_OK != eCmmStatus) {
			LOG_ERR(CMM_qDebugR_MODE, ("LoadConfiguration - End - Unable to get version from config file"));
#ifdef PWDLOGS_ENABLE
			swprintf( szDbgMsg, L"CRequestHandler::LoadConfiguration - End - Unable to get version from config file GTC %d\n",GetTickCount());
			OutputDebugString(szDbgMsg);
#endif	
			//set access to as it was when load was called
			glbObjMemoryManager.SetAccess(dwConfigurationID, ALLOW_ALL);
			return eCmmStatus;
		}
		//store the version of the configuration to be loaded.
		*pdwConfigVersion = wConfigFileVersion;

		/**Step 4: Check if working section instances exist already*/
		/***********************************************************/
		if (FALSE == bPersistedLoad || wSystemVersion != wConfigFileVersion) {
			//if load is from unpersisted source or a version conversion is required.
			if (TRUE == IsWorkingSectionPresent(dwConfigurationID)) {
				LOG_ERR(CMM_qDebugR_MODE, ("LoadConfiguration - End - Working section already exists"));
#ifdef PWDLOGS_ENABLE
				swprintf( szDbgMsg, L"CRequestHandle::LoadConfiguration - End - Working section already exists GTC %d\n",GetTickCount());
				OutputDebugString(szDbgMsg);
#endif
				return CSTATUS_CONFIGURATION_LOAD_FAILED;
			}
		}

		/**********************************************************/
		//Note : Both Plain Load and Converted Load will set the 
		//Note : access flag to ALLOW_ALL.
		/**********************************************************/

		//Set the access to ALLOW_NONE before Loading
		eCmmStatus = glbObjMemoryManager.SetAccess(dwConfigurationID, ALLOW_NONE);
		if (CSTATUS_OK != eCmmStatus) {
			LOG_ERR(CMM_qDebugR_MODE, ("LoadConfiguration - End - Set Access Failed"));
			return eCmmStatus;
		}

		/**Step 5: Check if a plain load is required or a converted load and perform load*/
		/*********************************************************************************/
		if (wSystemVersion == wConfigFileVersion) {
			//a plain load is required
			eCmmStatus = BuildConfigurationLookUp(dwConfigurationID, bPersistedLoad);
			if (CSTATUS_OK == eCmmStatus) {
				/**Step 6: Update the statistics the configuration header*/
				/*********************************************************/
				CCMMUtility objUtility;	//object to execute utility functions
				eCmmStatus = objUtility.UpdateConfigurationFileHeader(dwConfigurationID, CONFIG_LOAD,
						(DWORD) bPersistedLoad);

				/**Step 7: Set access to ALLOW_ALL*/
				/**********************************/
				eCmmStatus = glbObjMemoryManager.SetAccess(dwConfigurationID, ALLOW_ALL);

				/**Step 8: Set access to CONFIGURATION_LOAD to indicate if a
				 current section config exists*/
				/***********************************************************/
				if (bPersistedLoad) {
					eCmmStatus = glbObjMemoryManager.SetState(dwConfigurationID, CONFIGURATION_LOAD);
				}
			} else {
				LOG_ERR(CMM_qDebugR_MODE, ("LoadConfiguration - Configuration lookup creation failed : %d"), eCmmStatus);
				//an error has occured while creating lookup
				if (bPersistedLoad) {
					//now the clear the current section configuration lookup
					glbObjMemoryManager.ClearCommittedConfiguration(dwConfigurationID);

					//lookup to current section failed.
					glbObjMemoryManager.SetAccess(dwConfigurationID, ALLOW_ALL);

					//set the config state as current config file not available
					glbObjMemoryManager.SetState(dwConfigurationID, CONFIGURATION_INIT);
				} else {
					//now the clear the configuration lookup
					//delete working section instances 
					glbObjMemoryManager.DeleteModifiableConfiguration(dwConfigurationID);
					//lookup to working section failed.
					glbObjMemoryManager.SetAccess(dwConfigurationID, CONFIGURATION_CORRUPT);
				}
			}
		} else {
			//a converted load is required
			//store the details in a temp structure created in the heap
			DISCARD_THREAD_PARAMS *pDiscardParms = new DISCARD_THREAD_PARAMS;
			//set the value of the current request handler object and config id,
			//to be passed to the new thread.
			pDiscardParms->objReqHandler = (void*) this;
			pDiscardParms->dwConfigurationId = dwConfigurationID;
			pDiscardParms->wAccessFlag = wAccessFlag;
			pDiscardParms->wOperation = OPR_CONVERT;

			DWORD dwThreadId;
			//start the new thread.
			HANDLE hDiscardThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE) CRequestHandler::ThreadStartFunction,
					pDiscardParms, 0, &dwThreadId);
			qDebug("CMM Discard Thread 2 ID: %u\n", dwThreadId);

			if (NULL == hDiscardThread) {
				//unable to create new thread.. send back failure message.
				delete pDiscardParms;
				return CSTATUS_FAIL;
			} else {
				//thread successfully created.
				//thread handle no longer required.
				//No need to close the mutex in Qt;
				hDiscardThread = NULL;
				return CSTATUS_OK;
			}
		}
		//return status of the operation
		LOG_INFO(CMM_qDebugR_MODE, ("LoadConfiguration - End : Status : %d"), eCmmStatus);
		return eCmmStatus;
	} catch (...) {
		LOG_ERR(CMM_qDebugR_MODE, ("LoadConfiguration - Exception - GetLastError : %d"), GetLastError());
		if (bPersistedLoad) {
			//now the clear the current section configuration lookup
			glbObjMemoryManager.ClearCommittedConfiguration(dwConfigurationID);

			//set the config state as current config file not available
			glbObjMemoryManager.SetState(dwConfigurationID, CONFIGURATION_INIT);
		} else {
			//now the clear the configuration lookup
			//delete working section instances 
			glbObjMemoryManager.DeleteModifiableConfiguration(dwConfigurationID);
		}
		//set access to as it was when load was called
		glbObjMemoryManager.SetAccess(dwConfigurationID, ALLOW_ALL);
		return CSTATUS_FAIL;
	}
}
//**********************************************************************
///
/// Commits the configuration taking all the instances in the working
/// section of CMM.
///
/// @param[in]	dwConfigurationID - The id of the configuration whose
///									working instances will be committed.
///
/// @return		Error code if failed, CSTATUS_OK if okay
/// 
//	Modification History
//	Sai Krishnan	20/8/2004	Datatype misalignment problem fixed.
//								CRC (a WORD variable) will be 4 byte 
//								aligned while creating the config file,
//								by padding additional bytes.
//**********************************************************************
CMMSTATUS CRequestHandler::CommitConfiguration(DWORD dwConfigurationID) {
	LOG_INFO(CMM_qDebugR_MODE, ("CommitConfiguration - Start"));
	WORD wAccessFlag = 0;	//variable to store the current access level of the configuration

	//Update the Thread count
	//Commit can take more than 30 secs 
	//(max time the watchdog waits before we reset the recorder)
	//Hence we kick the watchdog at intermittent steps during
	//commiting a configuration
	UpdateThreadCount(AM_OPPANEL);

	try
	{
		/**Step 0: Check if CMM has been initialized with metadata and lookups created*/
		/******************************************************************************/
		if (FALSE == IsCMMInitialized()) {
			// an error has occured
			LOG_ERR(CMM_qDebugR_MODE, ("CommitConfiguration - End - CSTATUS_CONFIGURATION_NOTINITIALIZED"));
			return CSTATUS_CONFIGURATION_NOTINITIALIZED;
		}

		/**Step 1: Check if the both committed and modifiable configurations 
		 are available for use*/
		/*******************************************************************/
		CMMSTATUS eCmmStatus;
		eCmmStatus = IsOperationAllowed(dwConfigurationID, OPR_COMMIT, &wAccessFlag);
		if (CSTATUS_OK != eCmmStatus) {
			LOG_ERR(CMM_qDebugR_MODE, ("CommitConfiguration - End - Access Denied : %d"), eCmmStatus);
			return eCmmStatus;
		}

		/**Step 2: Set access to ALLOW_NONE to restrict access to other users*/
		/*********************************************************************/
		eCmmStatus = glbObjMemoryManager.SetAccess(dwConfigurationID, ALLOW_NONE);
		if (CSTATUS_OK != eCmmStatus) {
			LOG_ERR(CMM_qDebugR_MODE, ("CommitConfiguration - End - Unable to lock configuration : %d"), eCmmStatus);
			return eCmmStatus;
		}

		/**Step 3: Get the Config file if config file exists and its size*/
		/*****************************************************************/
		BYTE *pByConfigFile = NULL;
		TV_BOOL bConfigFileExists = FALSE;
		DWORD dwConfigFileSize = 0;
		eCmmStatus = glbObjMemoryManager.GetConfigurationFile(dwConfigurationID, &pByConfigFile);
		if (CSTATUS_OK == eCmmStatus && NULL != pByConfigFile) {
			LOG_INFO(CMM_qDebugR_MODE, ("CommitConfiguration - Config File does exist"));
			//config file exists
			bConfigFileExists = TRUE;
		} else {
			LOG_INFO(CMM_qDebugR_MODE, ("CommitConfiguration - Config File does not exist"));
			//config file exists
			bConfigFileExists = FALSE;
		}

		if (TRUE == bConfigFileExists) {
			//if the file exists, get the size of the file.
			eCmmStatus = glbObjMemoryManager.GetConfigurationSize(dwConfigurationID, &dwConfigFileSize);
			if (CSTATUS_OK == eCmmStatus && 0 != dwConfigFileSize) {
				LOG_INFO(CMM_qDebugR_MODE, ("CommitConfiguration - Config File Size : %d"), dwConfigFileSize);
				//config file exists
				bConfigFileExists = TRUE;
			} else {
				LOG_INFO(CMM_qDebugR_MODE, ("CommitConfiguration - Config File Size : Not Known"));
				bConfigFileExists = FALSE;
			}

		}

		//save the configuration header... metadata will be saved later.
		CONFIGFILE_HEADER sConfigHeader;	//buffer to store the config file
		memset(&sConfigHeader, 0, sizeof(CONFIGFILE_HEADER));

		/**Step 4: Get the system metadata and metadata size*/
		/****************************************************/
		//buffer to store pointer to the entire system metadata
		BYTE *pByMetadata = NULL;
		eCmmStatus = glbObjMemoryManager.GetMetadataFile(SYSTEM_CONFIGURATION_ID, &pByMetadata);
		if (CSTATUS_OK != eCmmStatus) {
			LOG_ERR(CMM_qDebugR_MODE, ("CommitConfiguration - End - Unable to get system metadata file : %d"),
					eCmmStatus);

			//Set access to CONFIGURATION_LOAD to indicate if a
			//current section config doesnt exist
			glbObjMemoryManager.SetState(dwConfigurationID, CONFIGURATION_INIT);

			//set the access back to the access of configuration when commit was called.
			glbObjMemoryManager.SetAccess(dwConfigurationID, ALLOW_ALL);
			return eCmmStatus;
		}

		//save the metadata header		
		Metadata_Header *pMDHeader = (Metadata_Header*) pByMetadata;

		//size of metadata including header + data + crc + crcpadding(2bytes)
		WORD wMetadataSize = pMDHeader->wSize;

		/***************************************************************/
		//Note : If the configuration file exists, then the config 
		//Note : header will be taken from the file. Otherwise,
		//Note : an empty config header with statistics updada
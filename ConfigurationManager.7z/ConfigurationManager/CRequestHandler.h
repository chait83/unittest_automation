/// @file CRequestHandler.h
/// ****************************************************************
/// Â© Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Request Handler
/// @n Filename: CRequestHandler.h
/// @n Desc:	 Functions Definitions of the core functionality of
///				 the configuration management module
///
//  ****************************************************************
//  Revision History
//  ****************************************************************
//  $Log[4]:
// 8 Aristos  1.4.1.1.1.0  9/19/2011 6:06:18 PM  Hemant(HAIL) 
//  Source updated for WDT functionality
// 7 Stability Project 1.4.1.1  7/2/2011 4:56:25 PM Hemant(HAIL) 
//  Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
// 6 Stability Project 1.4.1.0  7/1/2011 4:26:35 PM Hemant(HAIL) 
//  Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
// 5 V6 Firmware 1.4  4/19/2005 3:11:30 PM  Shyam (HTSL) 
//  ShutdownCMM() API Added
//  $
//
//  ****************************************************************
/******************************************************************************************
 COPYRIGHT (c) 2004
 HONEYWELL INC.,
 ALL RIGHTS RESERVED

 This software is a copyrighted work and/or information protected
 as a trade secret. Legal rights of Honeywell Inc. in this
 software is distinct from ownership of any medium in which the
 software is embodied. Copyright or trade secret notices included
 must be reproduced in any copies authorized by Honeywell Inc.
 The information in this software is subject to change without
 notice and should not be considered as a commitment by Honeywell
 Inc.
 ******************************************************************************************/

// Copyright (C) 1991 - 1999 Rational Software Corporation
#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_CREQUESTHANDLER_40A9EA0902FD_INCLUDED
#define _INC_CREQUESTHANDLER_40A9EA0902FD_INCLUDED
#include "Defines.h"
typedef void (*PFnUpdateThreadCounter)(int);
typedef void (*PFnUpdateThreadInfo)(int, bool);
#include "CMMDefines.h"
//##ModelId=40A9EA0902FD
//******************************************************
//  CRequestHandler
///
/// @brief Implements the C style API functions
/// 
/// Request Handler acts as the core service layer
///	which implements the functionalities of the exposed
/// C style APIs.
//******************************************************
class CRequestHandler {
public:

	//Thread start function
	static void ThreadStartFunction(DISCARD_THREAD_PARAMS *pDiscardParams);

	//##ModelId=40AAE00100FA
	CMMSTATUS InitializeCMM(QString tchHostType, ULONG lSerialNumber, BYTE *pByMetadata, DWORD *pdwSystemVersion);

	//##ModelId=40AC807500CB
	CRequestHandler();

	//##ModelId=40AC808A0222
	~CRequestHandler();

	//##ModelId=40AAF3C90138
	CMMSTATUS CreateConfiguration(DWORD *pdwConfigurationID, DWORD *pdwSessionNumber = NULL);

	//##ModelId=40AAF66B0222
	CMMSTATUS AllocateConfigurationBuffer(DWORD dwConfigurationID, DWORD dwBufferSize, BYTE **pByBuffer,
			WORD wAccessFlag = ALLOW_ALL);

	//
	//If TRUE the configuration adheres to the current 
	//version and needs no conversion. Hence no processing is 
	//required and the same can be directly accessible by 
	//clients.
	//
	//If FALSE the configuration might  require version 
	//conversion since its not persist previously. Hence 
	//processing is required while loading the same. This 
	//configuration cannot be accessible by the clients 
	//unless an explicit commitance is rendered.

	//##ModelId=40AAFA03000F
	CMMSTATUS LoadConfiguration(DWORD dwConfigurationID, TV_BOOL bPersistedLoad, DWORD *pdwConfigVersion);

	//##ModelId=40AAFBAD00AB
	CMMSTATUS CommitConfiguration(DWORD dwConfigurationID);

	//##ModelId=40AAFE8902CE
	CMMSTATUS ClearConfiguration(DWORD dwConfigurationID);

	//##ModelId=40AAFF4E0000
	CMMSTATUS DiscardChanges(DWORD dwConfigurationID);

	//##ModelId=40AB00650128
	CMMSTATUS DeleteConfiguration(DWORD dwConfigurationID);

	//##ModelId=40AB051801E4
	CMMSTATUS IsConfigurationAvailable(DWORD dwConfigurationID, WORD wReference, WORD *pwAccessFlag = NULL);

	//##ModelId=40AB076B0222
	CMMSTATUS GetConfiguration(DWORD dwConfigurationID, DWORD *pdwBufferSize, BYTE **pByBuffer);

	CMMSTATUS CreateDataBlock(DWORD dwConfigurationID, BLOCK_INFO *pBlockDetails);

	//##ModelId=40AB189B030D
	CMMSTATUS GetDataBlock(DWORD dwConfigurationID, BLOCK_INFO *pBlockDetails, WORD wReference);

	//##ModelId=40AB38AD0186
	CMMSTATUS SetDataBlock(DWORD dwConfigurationID, BLOCK_INFO *pBlockDetails);

	//##ModelId=40AB463A030D
	CMMSTATUS SetBlockModified(DWORD dwConfigurationID, BLOCK_INFO *pBlockDetails);

	//##ModelId=40AB47590148
	CMMSTATUS DeleteDataBlock(DWORD dwConfigurationID, BLOCK_INFO *pBlockDetails);

	//##ModelId=40AB5236001F
	CMMSTATUS ValidateDataBlock(DWORD dwConfigurationID, BLOCK_INFO *pBlockDetails, TV_BOOL *pIsDataBlockValid,
			QString *pInvalidMemberName);

	//##ModelId=40AB5BF60271
	CMMSTATUS GetNextChangeBlock(DWORD dwConfigurationID, BLOCK_INFO *pBlockDetails, WORD wIndex = 0);

	//##ModelId=40AB5FC00186
	CMMSTATUS SetConfigurationLog(DWORD dwConfigurationID, CONFIGHEADERINFO *pConfigDetails);

	//##ModelId=40AC760701A5
	CMMSTATUS GetBlockCount(DWORD dwConfigurationID, WORD wConfigType, DWORD *pdwBlockCount);

	//##ModelId=40AB4DF003C8
	CMMSTATUS GetCountByBlock(DWORD dwConfigurationID, WORD wBlockType, WORD wConfigType, DWORD *pdwInstanceCount);

	CMMSTATUS GetSizeOfBlockType(WORD wBlockType, DWORD *pdwBlockSize);

	CMMSTATUS SetBlockToDefaults(DWORD dwConfigurationID, WORD wBlockType, WORD wInstanceId, BYTE *pByBlockData);

	ULONG GetSerialNumber();				// get Serial Number

	WORD GetSystemMetadataVersion();		//get system metadata version

	//converts the internall used Status Code to client understandable error code
	CMMERROR ConvertStatusToErrorCode(CMMSTATUS varCMMStatus);

	//function to set a access level to a configuration
	CMMSTATUS SetConfigurationAccess(DWORD dwConfigurationID, WORD *pwAccessFlag);

	CMMSTATUS UninitiliseLookup();

	CMMSTATUS SetThreadCounter(PFnUpdateThreadCounter pFnUpdateThreadCounter);

	CMMSTATUS SetThreadInfo(PFnUpdateThreadInfo pFnUpdateThreadInfo);

	void UpdateThreadCount(int modId);

	void UpdateThreadInfo(int modId, bool bIsThreadExist);

private:

	//##ModelId=40AC864100FA
	QString m_tchHostType;					///< stores the Host Type info of module loading CMM

	//##ModelId=40AC867401E4
	ULONG m_lSerialNumber;					///< stores the serial number	of the module loading CMM

	//##ModelId=40AC873E02DE
	TV_BOOL m_bInitialized;					///< flag to indicate if Metadata initialization has been done.

	WORD m_wVersion;						///< variable to store the version of the system metadata.

	//DWORD * m_pdwSessionNumber;				///< variable to store the buffer containing the session number.

	PFnUpdateThreadCounter m_pFnUpdateThreadCounter;  ///< variable to store the global function pointer to update
													  ///< thread count for watchdog timer

	PFnUpdateThreadInfo m_pFnUpdateThreadInfo;  ///< variable to store the global function pointer to update
												///< thread info for watchdog timer

	/*******Start***Get & Set Functions for member variables used by CRequestHandler***************/

	QString  GetHostType();													//get Host type
	TV_BOOL SetHostType(QString pszHostType);								//set Host type

	TV_BOOL SetSerialNumber(ULONG ulSerialNumber);							//set Serial Number

	TV_BOOL IsCMMInitialized();												//get CMM state.
	TV_BOOL SetCMMInitialized(TV_BOOL tvbCMMStatus);						//set CMM state.

	TV_BOOL SetSystemMetadataVersion(WORD wVersion);						//set system metadata version

	//DWORD GetSessionNumber();										//gets Session Number from the buffer
	//TV_BOOL SetSessionNumberBuffer(DWORD * pdwSessionNumber);		//stores the buffer containing session number

	/*******End***Get & Set Functions for member variables used by CRequestHandler***************/

	/*******Start***Functions internally used by CRequestHandler***************/

	CMMSTATUS CheckIntegrityOfConfiguration(DWORD dwConfigurationID);

	CMMSTATUS GetVersionFromConfigurationFile(DWORD dwConfigurationId, WORD *wVersion);

	CMMSTATUS BuildConfigurationLookUp(DWORD dwConfigurationId, TV_BOOL bPersistedLoad);

	CMMSTATUS CalculateNewConfigurationSize(DWORD dwConfigurationID, DWORD *dwNewConfigFileSize);

	DWORD CalculateInstanceSize(DWORD dwConfigurationID, WORD ushBlockType, WORD ushInstance, WORD wReference,
			BYTE **pByDataBlock = NULL);

	CMMSTATUS CommitInstancesToConfigurationFile(DWORD dwConfigurationID, BYTE *pByConfigFile,
			WORD *wNumInstancesModified);

	CMMSTATUS SetModifiableDataBlock(DWORD dwConfigurationID, BLOCK_INFO *pvarBlockDetails);

	CMMSTATUS ValidateDataForRange(DWORD dwConfigurationId, WORD dwBlockType, BYTE *pbyData,
			Validate_Parameters *pValidateParams);

	TV_BOOL IsWorkingSectionPresent(DWORD dwConfigurationID);

	CMMSTATUS IsOperationAllowed(DWORD dwConfigurationID, WORD wConfig_Operation, WORD *wAccessFlag = NULL,
			WORD wReference = 0);
	/*******End***Functions internally used by CRequestHandler***************/
};
#endif /* _INC_CREQUESTHANDLER_40A9EA0902FD_INCLUDED */

/// @file CMemoryManager.h
/// ****************************************************************
/// Â© Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Memory Manager
/// @n Filename: CMemoryManager.h
/// @n Desc:	 Functions Definitions of the core functionality of
///				 the memory management of the CMM
///
//  ****************************************************************
//  Revision History
//  ****************************************************************
//  $Log[4]:
// 6   Stability Project 1.3.1.1  7/2/2011 4:56:08 PM   Hemant(HAIL) 
//    Stability Project: Recorder source has been upgraded from IL
//    version of firmware to JF version of firmware.
// 5   Stability Project 1.3.1.0  7/1/2011 4:26:35 PM   Hemant(HAIL) 
//    Stability Project: Files has been checked in before the merging
//    task. The merging will be done between IL version of firmware and JF
//    version of firmware. 
// 4   V6 Firmware 1.3    10/27/2004 11:34:54 AM  Amar (HTSL)   MFC
//    and Trace support 
// 3   V6 Firmware 1.2    10/11/2004 7:05:37 PM Vamshi (HTSL) CMM
//    Release 1.0
//  $
//
//*****************************************************************************************
/******************************************************************************************
 COPYRIGHT (c) 2004
 HONEYWELL INC.,
 ALL RIGHTS RESERVED

 This software is a copyrighted work and/or information protected
 as a trade secret. Legal rights of Honeywell Inc. in this
 software is distinct from ownership of any medium in which the
 software is embodied. Copyright or trade secret notices included
 must be reproduced in any copies authorized by Honeywell Inc.
 The information in this software is subject to change without
 notice and should not be considered as a commitment by Honeywell
 Inc.
 ******************************************************************************************/

#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_CMEMORYMANAGER_40A9E9EC030D_INCLUDED
#define _INC_CMEMORYMANAGER_40A9E9EC030D_INCLUDED
#include "CMMDefines.h"
#include "Defines.h"
#include "PMMglobal.h"
//******************************************************
//  CInstanceInfo
///
/// @brief Implements the Instance Information structure which 
///		 forms the data part of the Instance map.
///
/// Blah Blah Blah
//******************************************************
typedef class CInstanceInfo {
public:
	//Methods
	CInstanceInfo();
	~CInstanceInfo();

	//Members
	void *pInstanceCommitted;///< Address of the memory location of the instance in the configuration file. The data referenced shall not be modifiable.
	void *pInstanceModifiable;			///< Pointer to modifiable copy of the configuration data.
	WORD nInstanceState;					///< The last modified state of the instance
} INSTANCE_INFO;

typedef std::map<WORD, INSTANCE_INFO> INSTANCE_MAP; //Instance ID & Instance Info

//******************************************************
//  CBlockTypeInfo
///
/// @brief Implements the Blocktype Information structure which 
///		 forms the data part of the Blocktype map.
//******************************************************
typedef class CBlockTypeInfo {
public:
	//Methods
	CBlockTypeInfo();
	~CBlockTypeInfo();

	//Members
	WORD nBlockState;	///< Specifies the current state of the block defined in the BLOCKSTATE enumeration
	INSTANCE_MAP InstanceMap;	///< The map of all the instances of the blocktype
} BLOCK_TYPE_INFO;

typedef std::map<WORD, BLOCK_TYPE_INFO> BLOCK_TYPE_MAP; //Block Type & Block Info

//******************************************************
//  CConfigurationInfo
///
/// @brief Implements the Configuration Information structure which 
///		 forms the data part of the Configuration map.
//******************************************************

typedef class CConfigurationInfo {
public:
	//Methods
	CConfigurationInfo();
	~CConfigurationInfo();

	//Members
	BYTE *pByConfigurationFile;	///< The memory location for accessing the complete configuration file.
	DWORD dwConfigSize;	///< Size of the complete configuration file. Fundamentally the sum of all the individual instances of all the block types.
	WORD wState;					///< A value that indicates the current status of the confifuration.
	WORD wAccessSpecifier;///< The Access specifier enumeration specifies the level of access allowed for the configuration.
	unsigned long *lSessionNumber;		///< The SessionID pointer available with the clients.
	BLOCK_TYPE_MAP BlockTypeMap;			///< Map of all the blocktypes belonging to the configuration.
} CONFIGURATION_INFO;

typedef std::map<DWORD, CONFIGURATION_INFO> CONFIGURATION_MAP;

//******************************************************
//  CIdentifierInfo
///
/// @brief Implements the Identifier Information structure which 
///		 forms the data part of the Identifier map.
//******************************************************
typedef class CIdentifierInfo {
public:
	//Methods
	CIdentifierInfo();
	~CIdentifierInfo();

	//Members
	DWORD dwIdentifierPosition;	///< Used for conversion optimization. The Byte position of the Identifier based on its position in the source.
	void *pIdentifierDetails;			///< The details of the Block itself.
} IDENTIFIER_INFO;

typedef std::map<WORD, IDENTIFIER_INFO> IDENTIFIER_MAP;

//******************************************************
//  CMetadataInfo
///
/// @brief Implements the Metadata Information structure which 
///		 forms the data part of the Metadata map.
//******************************************************
typedef class CMetadataInfo {
public:
	//Methods
	CMetadataInfo();
	~CMetadataInfo();

	//Members
	DWORD dwSize;				///< The Size required storing the block. Sum of all the member sizes.
	BOOL bPositionComputed;	///< Flag for maintaining the status of byte position computation. Optimization mechanism to avoid repeated computation.
	void *pBlockTypeDetails;	///< The details of the Block itself.
	IDENTIFIER_MAP IdentifierMap;	///< The map containing all the identifiers declared as members of the structure.
} METADATA_INFO;

typedef std::map<WORD, METADATA_INFO> METADATA_MAP;
typedef std::map<DWORD, METADATA_MAP> CONFIGMETADATA_MAP;

//******************************************************
//  CMemoryManager
///
/// @brief Implements the Memory Management Functionality
/// 
/// Manages the in-memory data for storage and retrieval 
/// of the configuration data
//******************************************************
class CMemoryManager {
public:
	CMemoryManager();

	~CMemoryManager();

	//Metadata Methods
	CMMSTATUS InitializeMetadata(DWORD dwConfigurationID, BYTE *pbySystemMetadata = NULL);

	CMMSTATUS GetMetadataFile(DWORD dwConfigurationID, BYTE **pbyMetadata);

	CMMSTATUS SetIdentifierBlock(DWORD dwConfigurationID, WORD wBlockType, BYTE *pByBlockAddress,
			WORD wIdentifierPosition, BYTE *pByIdentifierAddress);

	CMMSTATUS GetBlock(DWORD dwConfigurationID, WORD wBlockType, BYTE **pByBlockAddress);

	CMMSTATUS GetIdentifierBlock(DWORD dwConfigurationID, WORD wBlockType, char *pszIdentifierName,
			BYTE **pByIdentifierAddress, DWORD *pdwPosition);

	CMMSTATUS GetEnumIdentifier(DWORD dwConfigurationID, WORD wBlockType, DWORD *pdwCount, BYTE ***pzIdentifierArray);

	CMMSTATUS DeleteMetadata(DWORD dwConfigurationID);

	CMMSTATUS ComputeMetadataSize(DWORD dwConfigurationID);

	CMMSTATUS GetBlockSize(DWORD dwConfigurationID, WORD wBlockType, DWORD *pdwSize);

	CMMSTATUS ComputeIdentifierPosition(DWORD dwConfigurationID, WORD wBlockType);

	//Configuration Methods
	CMMSTATUS InitializeConfiguration(unsigned long *lSessionNumber, DWORD *dwConfigurationID);

	CMMSTATUS BuildConfiguration(DWORD dwConfigID, DWORD dwConfigSize, BYTE **pByConfigBuffer);

	CMMSTATUS CreateDataBlock(DWORD dwConfigurationID, WORD wBlockType, WORD wInstanceNumber, DWORD dwSize);

	CMMSTATUS DeleteDataBlock(DWORD dwConfigurationID, WORD wBlockType, WORD wInstanceNumber);

	CMMSTATUS SetCommittedDataBlock(DWORD dwConfigurationID, WORD wBlockType, WORD wInstanceNumber, BYTE *pByDataBlock);

	CMMSTATUS GetCommittedDataBlock(DWORD dwConfigurationID, WORD wBlockType, WORD wInstanceNumber,
			BYTE **pByDataBlock);

	CMMSTATUS SetModifiableDataBlock(DWORD dwConfigurationID, WORD wBlockType, WORD wInstanceNumber,
			BYTE *pByDataBlock);

	CMMSTATUS GetModifiableDataBlock(DWORD dwConfigurationID, WORD wBlockType, WORD wInstanceNumber,
			BYTE **pByDataBlock);

	CMMSTATUS SetAccess(DWORD dwConfigurationID, WORD dwAccessFlag);

	CMMSTATUS GetAccess(DWORD dwConfigurationID, WORD *pwAccessFlag);

	CMMSTATUS SetState(DWORD dwConfigurationID, WORD wState);

	CMMSTATUS GetState(DWORD dwConfigurationID, WORD *pwState);

	CMMSTATUS SetConfigurationSize(DWORD dwConfigurationID, DWORD dwSize);

	CMMSTATUS GetConfigurationSize(DWORD dwConfigurationID, DWORD *pdwSize);

	CMMSTATUS DeleteConfiguration(DWORD dwConfigurationID);

	CMMSTATUS DeleteModifiableConfiguration(DWORD dwConfigurationID);

	CMMSTATUS ClearCommittedConfiguration(DWORD dwConfigurationID);

	CMMSTATUS GetSessionNumber(DWORD dwConfigurationID, unsigned long *lSessionNumber);

	CMMSTATUS GetConfigurationFile(DWORD dwConfigurationID, BYTE **pByConfigurationFile);

	CMMSTATUS IsBlockPresent(DWORD dwConfigurationID, WORD wBlockType, TV_BOOL *bPresent);

	CMMSTATUS SetInstanceState(DWORD dwConfigurationID, WORD wBlockType, WORD wInstanceNumber, WORD wState);

	CMMSTATUS GetInstanceState(DWORD dwConfigurationID, WORD wBlockType, WORD wInstanceNumber, WORD *pwState);

	CMMSTATUS GetEnumBlock(DWORD dwConfigurationID, WORD wConfigurationType, DWORD *pdwCount,
			WORD **ppwBlockType = NULL);

	CMMSTATUS GetEnumInstance(DWORD dwConfigurationID, WORD wBlockType, WORD wConfigurationType, DWORD *pdwCount,
			WORD **ppwInstance = NULL);

private:
	//Members
	CONFIGURATION_MAP m_mapConfigurationLookup;	///< The Map to contain all the configuration Lookups for the recorder
	CONFIGMETADATA_MAP m_mapSystemMetadataLookup;	///< The Map to contain the Metadata Lookup of the recorder

	DWORD m_dwConfigIDCounter;						///< The Counter to hold the last generated Configuration ID

	BYTE *m_pBySystemMetadata;						///< The System Metadata Buffer

	QMutex m_csConfigurationSync;			///<  Critical Sections for synchronized Configuration access
	QMutex m_csMetadataSync;				///<  Critical Sections for synchronized metadata access

	//Methods
	CMMSTATUS ReleaseConfiguration();
	CMMSTATUS InternalGetEnumInstance(DWORD dwConfigurationID, WORD wBlockType, BOOL bDirty, BOOL bOnlyModifiable,
			DWORD *pdwCount, WORD **ppwInstance = NULL);
	CMMSTATUS InternalDeleteConfiguration(DWORD dwConfigurationID, BOOL bComplete);

	DWORD ComputeBlockSize(CONFIGMETADATA_MAP::iterator ConfigurationIterator,
			IDENTIFIER_RECORD_INFO *pBlockIdentifier);
	WORD GetInstanceCount(BLOCK_TYPE_MAP::iterator BlockTypeIterator, WORD wConfigurationType);
};

#endif /* _INC_CMEMORYMANAGER_40A9E9EC030D_INCLUDED */

/// @file CVersionConvertor.cpp
/// ****************************************************************
/// Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Version Convertor
/// @n Filename: CVersionConvertor.cpp
/// @n Desc: Class implements methods to perform the conversion between configuration 
///			 versions.
//  ****************************************************************
//  Revision History
//  ****************************************************************
//  $Log[4]:
// 30  Stability Project 1.25.1.3 7/2/2011 4:56:28 PM Hemant(HAIL) 
//  Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
// 29  Stability Project 1.25.1.2 7/1/2011 4:38:11 PM Hemant(HAIL) 
//  Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
// 28  Stability Project 1.25.1.1 3/17/2011 3:20:19 PM  Hemant(HAIL) 
//  Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
// 27  Stability Project 1.25.1.0 2/15/2011 3:02:50 PM  Hemant(HAIL) 
//  File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
//  $
//
//  ***************************************************************************************
/******************************************************************************************
  COPYRIGHT (c) 2004
   HONEYWELL INC.,
  ALL RIGHTS RESERVED

  This software is a copyrighted work and/or information protected
  as a trade secret. Legal rights of Honeywell Inc. in this
  software is distinct from ownership of any medium in which the
  software is embodied. Copyright or trade secret notices included
  must be reproduced in any copies authorized by Honeywell Inc.
  The information in this software is subject to change without
  notice and should not be considered as a commitment by Honeywell
  Inc.
******************************************************************************************
Project  : Configuration Management Module
Module : 
FileName : CVersionConvertor.cpp
Author(s)  : Rashmy Bharadwaj
Description  : Implementation of VersionConversion class
Date Of Creation : 6/22/2004
Modification History : 
Name					Date								Modifications
----					-----								-------------
Rashmy Bharadwaj		6/22/2004							Created
*******************************************************************************************/

#include "CMemoryManager.h"
#include "CVersionConvertor.h"
#include "CMMDefines.h"
#include <string.h>
/*********************Extern Definitions*************************************/
//global memory manager object declared in CMemoryManager.h
extern CMemoryManager glbObjMemoryManager;	///< Global memory manager object. (defined in Global.cpp)
/*********************Extern Definitions*************************************/

//******************************************************************************************
/// Function : CVersionConvertor::CVersionConvertor()
/// Logic : 
/// Usage : Constructs the version conversion class object.
//  Author : [Rashmy Bharadawaj]
/// Returns : <None>
/// Exception/Error handling : 
/// Assumptions : 
//  Function parameters : 
///						@param[in]	wVersion		- The version of the system metadata
//  Modification History :
/// Date Modifications
/// ---- -------------
/// 7/7/2004  Created
//******************************************************************************************
CVersionConvertor::CVersionConvertor(WORD wVersion)
{
	
	LOG_INFO(CMM_qDebugR_MODE,("CVersionConvertor()  - Invoked"));
	LOG_INFO(CMM_qDebugR_MODE,("CVersionConvertor() - System Version : %d"),wVersion);

#ifdef PWDLOGS_ENABLE
	WCHAR szDbgMsg[512];
	swprintf( szDbgMsg, L"CVersionConvertor()  - Invoked GTC %d\n",GetTickCount());
	OutputDebugString(szDbgMsg);
	swprintf( szDbgMsg, L"CVersionConvertor()  - System Version : %d GTC %d\n",wVersion,GetTickCount());
	OutputDebugString(szDbgMsg);
#endif
	m_wSystemVersion = wVersion;
	m_dwConfigurationID = 0;
}

//******************************************************************************************
/// Function : CVersionConvertor::~CVersionConvertor()
//  Logic : 
/// Usage : Orderly destruction of the version conversion class
//  Author : [Rashmy Bharadawaj]
/// Returns : <None>
/// Exception/Error handling : 
/// Assumptions : 
//  Function parameters : (none)
//  Modification History :
/// Date Modifications
/// ---- -------------
/// 7/7/2004  Created
//******************************************************************************************

CVersionConvertor::~CVersionConvertor()
{
	LOG_INFO(CMM_qDebugR_MODE,("~CVersionConvertor()  - Invoked"));
}

//******************************************************************************************
/// Function :  CVersionConvertor::Convert()
//  Logic : 
/// Usage : The Public method used for performing the version conversion operation
//  Author : [Rashmy Bharadawaj]
/// Exception/Error handling : Structured Exception Handling Macros (Defined in Macro.h) 
/// Assumptions : 
//  Function parameters : 
///					@param[in]	dwConfigurationID - The id of the configuration to convert
///					@return		CMMSTATUS		  - Enumerated Status Code (Defined in Global.h)
//  Modification History :
/// 7/7/2004  Created
//	June 8th 2005	Shyam	- Adds the CRC to the defaulted block, If the block is undergoing 
//							  any modifcation will be treated as a different session.

//******************************************************************************************/

CMMSTATUS CVersionConvertor::Convert(DWORD dwConfigurationID)
{
	BEGIN__EXCEPTION__BLOCK

	LOG_INFO(CMM_qDebugR_MODE,("Convert()  - Invoked"));
	LOG_INFO(CMM_qDebugR_MODE,("Convert() - Configuration ID : %d"),dwConfigurationID);
#ifdef PWDLOGS_ENABLE
	WCHAR szDbgMsg[512];
	swprintf( szDbgMsg, L"CVersionConvertor::Convert:- Invoked GTC %d\n",GetTickCount());
	OutputDebugString(szDbgMsg);

	swprintf( szDbgMsg, L"CVersionConvertor::Convert:- Configuration ID : %d GTC %d\n",dwConfigurationID,GetTickCount());
	OutputDebugString(szDbgMsg);
#endif

	/**Basic Validation*/
	if(!dwConfigurationID)
	{
		LOG_ERR(CMM_qDebugR_MODE,("Convert()  - Error : (Configuration ID Param) CSTATUS_INVALID_CONFIGURATION"));
#ifdef PWDLOGS_ENABLE
		swprintf( szDbgMsg, L"CVersionConvertor::Convert:- Error : (Configuration ID Param) CSTATUS_INVALID_CONFIGURATION GTC %d\n",GetTickCount());
		OutputDebugString(szDbgMsg);
#endif

		throw CSTATUS_INVALID_CONFIGURATION;
	}

	/**Update the member*/
	m_dwConfigurationID = dwConfigurationID;

	/**Instantiate the utility class*/
	CCMMUtility objUtil;

	/**Get the Configuration File from the Memory Manager*/
	BYTE* pByConfigurationFile = NULL;

	CHECK_FUNCTION( glbObjMemoryManager.GetConfigurationFile(m_dwConfigurationID,&pByConfigurationFile))

	/**Check the return value*/
	CHECK_FOR_NULL( pByConfigurationFile )

	/**Get the Configuration File size*/
	DWORD dwConfigFileSize = 0;
	
	CHECK_FUNCTION( glbObjMemoryManager.GetConfigurationSize(m_dwConfigurationID,&dwConfigFileSize) )

	if(!dwConfigFileSize)
	{
		LOG_ERR(CMM_qDebugR_MODE,("Convert()  - Error : (Configuration File Size) CSTATUS_INVALID_SIZE"));
		throw CSTATUS_INVALID_SIZE;
	}

	LOG_INFO(CMM_qDebugR_MODE,("Convert()  - Configuration File Size : %d"),dwConfigFileSize);
#ifdef PWDLOGS_ENABLE
	swprintf( szDbgMsg, L"CVersionConvertor::Convert:- Configuration File Size : %d GTC %d\n",dwConfigFileSize,GetTickCount());
	OutputDebugString(szDbgMsg);
#endif

	/**Read the Configuration File*/
	CONFIGFILE_HEADER * pConfigFileHeader = (CONFIGFILE_HEADER *) pByConfigurationFile;

	LOG_INFO(CMM_qDebugR_MODE,("Convert()  - Configuration Header Contents: Creation Date/Time - %d,\
			Data Offset - %d, Metadata Offset - %d, Encryption - %d, Filetype - %d, Source - %d"),\
			pConfigFileHeader->dtCreationDateTime,pConfigFileHeader->lDataOffset,\
			pConfigFileHeader->lMDOffset,pConfigFileHeader->wEncryption,pConfigFileHeader->wFileType,pConfigFileHeader->dwSource );
#ifdef PWDLOGS_ENABLE
	swprintf( szDbgMsg, L"CVersionConvertor::Convert:Configuration Header Contents: Creation Date/Time - %d,\nData Offset - %d,\n Metadata Offset - %d,\n Encryption - %d,\n Filetype - %d,\n Source - %d GTC %d\n",pConfigFileHeader->dtCreationDateTime,pConfigFileHeader->lDataOffset,pConfigFileHeader->lMDOffset,
		pConfigFileHeader->wEncryption,pConfigFileHeader->wFileType,pConfigFileHeader->dwSource,GetTickCount());
	OutputDebugString(szDbgMsg);
#endif

	/**Locate the Metadata in the configuration file*/
	BYTE *pByMetadataStart = pByConfigurationFile + pConfigFileHeader->lMDOffset;

	/**Create a Metadata lookup in the Memory*/
	WORD wVersion;

	CHECK_FUNCTION( objUtil.BuildMetadataLookUp(pByMetadataStart,m_dwConfigurationID,&wVersion) )
	
	LOG_INFO(CMM_qDebugR_MODE,("Convert()  - Metadata Build Succeeded..."));
#ifdef PWDLOGS_ENABLE
	swprintf( szDbgMsg, L"CVersionConvertor::Convert:-- Metadata Build Succeeded.. GTC %d\n",GetTickCount());
	OutputDebugString(szDbgMsg);
#endif
	//No need to check the return value

	BLOCK_INFO stSourceDataBlockInfo;
	BLOCK_INFO stDetinationBlockInfo;

	DATA_BLOCK_HEADER* pDestinationBlockHeader = NULL;
	
	/**Start the Parsing Logic	*/
	/**Move to the start of the data blocks*/
	BYTE * pByDataBlock = pByConfigurationFile + pConfigFileHeader->lDataOffset;	//pointer to the data block + header	

	BYTE *pByConvertedBlock = NULL; //pointer to the converted block;
	
	DWORD dwFileSizeCount;

	LOG_INFO(CMM_qDebugR_MODE,("Convert()  - Data block parse loop starts..."));

	while(1)	/**For all the data blocks*/
	{
		/**First check if all the blocks are done*/
		dwFileSizeCount = (DWORD) (pByDataBlock - pByConfigurationFile);

		LOG_INFO(CMM_qDebugR_MODE,("Convert()  - Parsed through - %d Bytes"), dwFileSizeCount);

		if(dwFileSizeCount >= dwConfigFileSize)
		{
			LOG_INFO(CMM_qDebugR_MODE,("Convert()  - Breaking out of parse loop"));
			break; //out of while
		}

		/**Fetch the Block Information*/
		CHECK_FUNCTION( objUtil.GetDataBlockAndInstanceInfoFromDataBlock(pByDataBlock ,&stSourceDataBlockInfo))

		LOG_INFO(CMM_qDebugR_MODE,("Convert()  - Source Data Block Info : Block Size - %d,\
															  		Session Number - %d, Block Type - %d, Instance ID - %d"),\
																		stSourceDataBlockInfo.dwBlockSize ,stSourceDataBlockInfo.dwSessionNumber ,\
																		stSourceDataBlockInfo.wBlockType ,stSourceDataBlockInfo.wInstanceID);
#ifdef PWDLOGS_ENABLE
		swprintf( szDbgMsg, L"CVersionConvertor::Convert:- Source Data Block Info : Block Size - %d,\
														Session Number - %d, Block Type - %d, Instance ID - %d GTC %d\n",\
														stSourceDataBlockInfo.dwBlockSize ,stSourceDataBlockInfo.dwSessionNumber ,\
														stSourceDataBlockInfo.wBlockType ,stSourceDataBlockInfo.wInstanceID,GetTickCount());
		OutputDebugString(szDbgMsg);
#endif
		/**Determine if this is a known block type*/
		WORD bKnownType = true;
		CHECK_FUNCTION( glbObjMemoryManager.IsBlockPresent(SYSTEM_CONFIGURATION_ID,stSourceDataBlockInfo.wBlockType, &bKnownType) )

		if(bKnownType)
		{
			LOG_INFO(CMM_qDebugR_MODE,("Convert()  - Its a known type..."));
#ifdef PWDLOGS_ENABLE
			swprintf( szDbgMsg, L"CVersionConvertor::Convert:-- Its a known type.. GTC %d\n",GetTickCount());
			OutputDebugString(szDbgMsg);
#endif

			/**Fetch the block size from the system metadata*/
			CHECK_FUNCTION(glbObjMemoryManager.GetBlockSize(SYSTEM_CONFIGURATION_ID, stSourceDataBlockInfo.wBlockType, &stDetinationBlockInfo.dwBlockSize))

			/**Check the size*/
			if(!stDetinationBlockInfo.dwBlockSize)
			{
				LOG_ERR(CMM_qDebugR_MODE,("Convert()  - Error : (Destination Block size) : CSTATUS_INVALID_SIZE"));
#ifdef PWDLOGS_ENABLE				
				swprintf( szDbgMsg, L"CVersionConvertor::Convert:-- Error : (Destination Block size) : CSTATUS_INVALID_SIZE GTC %d\n",GetTickCount());
				OutputDebugString(szDbgMsg);
#endif
				throw CSTATUS_INVALID_SIZE;
			}

			/**Update the rest of the destination block info details*/
			stDetinationBlockInfo.dwSessionNumber = stSourceDataBlockInfo.dwSessionNumber;
			stDetinationBlockInfo.pByBlock = NULL;
			stDetinationBlockInfo.wBlockType = stSourceDataBlockInfo.wBlockType ;
			stDetinationBlockInfo.wInstanceID = stSourceDataBlockInfo.wInstanceID ;

			LOG_INFO(CMM_qDebugR_MODE,("Convert()  - Destination Data Block Info : Block Size - %d,\
															  			 Session Number - %d, Block Type - %d, Instance ID - %d"),\
																			 stDetinationBlockInfo.dwBlockSize ,stDetinationBlockInfo.dwSessionNumber ,\
																			 stDetinationBlockInfo.wBlockType ,stDetinationBlockInfo.wInstanceID);
#ifdef PWDLOGS_ENABLE
			swprintf( szDbgMsg, L"CVersionConvertor::Convert:-- Destination Data Block  GTC %d\n",GetTickCount());
			OutputDebugString(szDbgMsg);
			swprintf( szDbgMsg, L"CVersionConvertor::Convert:-- Block Size - %d, Session Number - %d, Block Type - %d, Instance ID - %d GTC %d\n",\
																stDetinationBlockInfo.dwBlockSize ,stDetinationBlockInfo.dwSessionNumber ,\
																stDetinationBlockInfo.wBlockType ,stDetinationBlockInfo.wInstanceID,GetTickCount());
			OutputDebugString(szDbgMsg);
#endif
			/**Create a data block of the definition from the system's metadata. This takes of the header*/
			CHECK_FUNCTION(objUtil.CreateDataBlock(m_dwConfigurationID,&stDetinationBlockInfo))

			/**Now the data part*/

			/**Get the newly created block*/
			pByConvertedBlock=NULL;
			
			CHECK_FUNCTION( glbObjMemoryManager.GetModifiableDataBlock(m_dwConfigurationID,stDetinationBlockInfo.wBlockType,stDetinationBlockInfo.wInstanceID,&pByConvertedBlock) )

			CHECK_FOR_NULL(pByConvertedBlock) //Comes with the DATA_BLOCK_HEADER

			/**Set the data block header*/
			pDestinationBlockHeader = (DATA_BLOCK_HEADER*)pByConvertedBlock;
			pDestinationBlockHeader->dwBlockSize = stDetinationBlockInfo.dwBlockSize;
			pDestinationBlockHeader->dwSessionId = stDetinationBlockInfo.dwSessionNumber;
			pDestinationBlockHeader->wBlockType  = stDetinationBlockInfo.wBlockType;
			pDestinationBlockHeader->wInstanceNumber = stDetinationBlockInfo.wInstanceID;

			/**Default the newly created datablock*/
			objUtil.DefaultDataBlock(m_dwConfigurationID,stDetinationBlockInfo.wBlockType,pByConvertedBlock + sizeof(DATA_BLOCK_HEADER),stDetinationBlockInfo.wInstanceID);
			
			LOG_INFO(CMM_qDebugR_MODE,("Convert()  - Data block created and defaulted..."));
#ifdef PWDLOGS_ENABLE
			swprintf( szDbgMsg, L"CVersionConvertor::Convert:-- Data block created and defaulted..  GTC %d\n",GetTickCount());
			OutputDebugString(szDbgMsg);
#endif
			/**Invoke the recursive method for conversion;*/
			//Source and Destination Positions shall be 0 now.
			CHECK_FUNCTION( ConvertData(stDetinationBlockInfo.wBlockType, stSourceDataBlockInfo.pByBlock + sizeof(DATA_BLOCK_HEADER), 0, pByConvertedBlock + sizeof(DATA_BLOCK_HEADER),0) )
			
			/*****************************************************************/
			// Note : Change request - Shyam
			// Check CRC for data block 
			/*****************************************************************/
			DATA_BLOCK_HEADER* pDataBlockHeader = NULL;
			DATA_BLOCK_HEADER* sSrcDataBlockHeader = NULL;
			sSrcDataBlockHeader = (DATA_BLOCK_HEADER*)stSourceDataBlockInfo.pByBlock;
			pDataBlockHeader = (DATA_BLOCK_HEADER*)pByConvertedBlock;
			pDataBlockHeader->sBlockCRC = sSrcDataBlockHeader->sBlockCRC;
			unsigned short wCalcCRC = CrcCalc(pByConvertedBlock + sizeof(DATA_BLOCK_HEADER),
											  stDetinationBlockInfo.dwBlockSize);			
			
			if(pDataBlockHeader->sBlockCRC != wCalcCRC)
			{
				pDataBlockHeader->sBlockCRC = wCalcCRC;				
				glbObjMemoryManager.GetSessionNumber(m_dwConfigurationID,&(pDataBlockHeader->dwSessionId));				 
			}

			LOG_INFO(CMM_qDebugR_MODE,("Convert()  - Block converted, setting it back..."));
#ifdef PWDLOGS_ENABLE
			swprintf( szDbgMsg, L"CVersionConvertor::Convert:-- Block converted, setting it back... GTC %d\n",GetTickCount());
			OutputDebugString(szDbgMsg);
#endif

			/**Set the fully converted data to the configuration being converted*/
			CHECK_FUNCTION( glbObjMemoryManager.SetModifiableDataBlock(m_dwConfigurationID,stDetinationBlockInfo.wBlockType,stDetinationBlockInfo.wInstanceID,pByConvertedBlock) )
		}
		else
		{
			/**If the block is of a variable type, dont attempt conversion*/
			if(VARIABLE_BASE <= stSourceDataBlockInfo.wBlockType)
			{
				/**Create a data block of the definition from the source's block info*/
				CHECK_FUNCTION(objUtil.CreateDataBlock(m_dwConfigurationID,&stSourceDataBlockInfo))

				/**Now the data part*/
				pByConvertedBlock = NULL;

				/**Get the newly created block*/
				CHECK_FUNCTION( glbObjMemoryManager.GetModifiableDataBlock(m_dwConfigurationID,stSourceDataBlockInfo.wBlockType,stSourceDataBlockInfo.wInstanceID,&pByConvertedBlock) )

				CHECK_FOR_NULL(pByConvertedBlock) //Comes with the DATA_BLOCK_HEADER

				/**Set the data block header*/
				pDestinationBlockHeader = (DATA_BLOCK_HEADER*)pByConvertedBlock;
				pDestinationBlockHeader->dwBlockSize = stSourceDataBlockInfo.dwBlockSize;
				pDestinationBlockHeader->dwSessionId = stSourceDataBlockInfo.dwSessionNumber;
				pDestinationBlockHeader->wBlockType  = stSourceDataBlockInfo.wBlockType;
				pDestinationBlockHeader->wInstanceNumber = stSourceDataBlockInfo.wInstanceID;
				
				/**copy the source size of contents into the destination*/
				memcpy(pByConvertedBlock + sizeof(DATA_BLOCK_HEADER),stSourceDataBlockInfo.pByBlock + sizeof(DATA_BLOCK_HEADER),stSourceDataBlockInfo.dwBlockSize );
				/********************************************************/
				// Note: Change Request
				// Update CRC of the variable block
				// will be same as previous session				
				/********************************************************/
				unsigned short wCalcCRC = CrcCalc(pByConvertedBlock + sizeof(DATA_BLOCK_HEADER),
												  pDestinationBlockHeader->dwBlockSize);
				DATA_BLOCK_HEADER* pDataBlockHeader = NULL;
				pDataBlockHeader = (DATA_BLOCK_HEADER*)pByConvertedBlock;
				pDestinationBlockHeader->sBlockCRC	=	wCalcCRC;				
			}
		}

		/**Update the source pointer beyond the block.*/
		pByDataBlock += stSourceDataBlockInfo.dwBlockSize + sizeof(DATA_BLOCK_HEADER);

		LOG_INFO(CMM_qDebugR_MODE,("Convert()  - Moving to the next block..."));
#ifdef PWDLOGS_ENABLE
		swprintf( szDbgMsg, L"CVersionConvertor::Convert:-- Moving to the next block.. GTC %d\n",GetTickCount());
		OutputDebugString(szDbgMsg);
#endif
	}

	LOG_INFO(CMM_qDebugR_MODE,("Convert()  - Data block parse loop ends..."));
#ifdef PWDLOGS_ENABLE
	swprintf( szDbgMsg, L"CVersionConvertor::Convert:-- Data block parse loop ends..  GTC %d\n",GetTickCount());
	OutputDebugString(szDbgMsg);
#endif
	/**Now update the ConfigurationHeader*/
	if(wVersion > m_wSystemVersion) /**If Loaded configuration is of a higher version*/
	{
		CHECK_FUNCTION (objUtil.UpdateConfigurationFileHeader(m_dwConfigurationID,CONFIG_VERSION_UP,wVersion));
	}
	else
	{
		CHECK_FUNCTION (objUtil.UpdateConfigurationFileHeader(m_dwConfigurationID,CONFIG_VERSION_DOWN,wVersion));
	}

	LOG_INFO(CMM_qDebugR_MODE,("Convert()  - Updated Configuration Header Details..."));
#ifdef PWDLOGS_ENABLE
	swprintf( szDbgMsg, L"CVersionConvertor::Convert:-- Updated Configuration Header Details... GTC %d\n",GetTickCount());
	OutputDebugString(szDbgMsg);
#endif
	/**Cleanup the metadata lookup from memory*/
	CHECK_FUNCTION(glbObjMemoryManager.DeleteMetadata(m_dwConfigurationID))

	LOG_INFO(CMM_qDebugR_MODE,("Convert()  - Metadata cleaned from memory..."));	
#ifdef PWDLOGS_ENABLE
	swprintf( szDbgMsg, L"CVersionConvertor::Convert:-- Metadata cleaned from memory.. GTC %d\n",GetTickCount());
	OutputDebugString(szDbgMsg);

#endif
	END__EXCEPTION__BLOCK
	CATCH__EXCEPTION
}

//******************************************************************************************
/// Function :  CVersionConvertor::ConvertData()
//  Logic : 
/// Usage : The recursive method used for converting each data block
//  Author : [Rashmy Bharadawaj]
/// Exception/Error handling : Structured Exception Handling Macros (Defined in Macro.h) 
/// Assumptions : 
//  Function parameters : 
///					@param[in]		dwConfigurationID - The id of the configuration to convert
///					@param[in]		dwBlockType -  The Block type to convert
///					@param[in/out]	ppSourceData - Source data
///					@param[in]		lSourcePosition - The start position of the block in the immediate parent block
///					@param[in/out]	ppByConvertedData - Converted data
///					@param[in/out]	lDestinationPosition - The position of the destination to copy the converted data
///					@return			CMMSTATUS		  - Enumerated Status Code (Defined in Global.h)
//  Modification History :
//  Date Modifications
//  ---- -------------
//  7/7/2004  Created
//
//  04/07/2005		Added a condition check during version conversion 
//					Problem : Was Defaulting previous value if two same datatypes are in row.
//
//  14th Sep 2005 Shyam - When a bitfield instances has been changed the configuration data 
//					was getting corrupted. Refer to Defect Id: 155
//
//  27th Sep 2005	Shyam - Movement in the source position was wrong when a bitfield 
//					is encountered, was updating the source position each time an identifer 
//					of the same bitfield is encountered, modified to update the source position
//					only after the all the fields of the bitfields are passed.
//
// 11th Jan 2006	Shyam - Logic of parsing has compleatly been changed with structures, 
//					Added a saperate tracking mechanism to track source and destination 
//					parsing and size of source has been moved with proper size with the 
//					respective metadata due to which problems were occuring before.
//******************************************************************************************/
CMMSTATUS CVersionConvertor::ConvertData(WORD wBlockType, BYTE *pSourceData, long lSourcePosition,BYTE *pByConvertedData,long lDestinationPosition)
{
	BEGIN__EXCEPTION__BLOCK
#ifdef PWDLOGS_ENABLE
	WCHAR szDbgMsg[512];
#endif
	LOG_INFO(CMM_qDebugR_MODE,("ConvertData()  - Invoked"));
	LOG_INFO(CMM_qDebugR_MODE,("ConvertData() - Block Type : %d"),wBlockType);
#ifdef PWDLOGS_ENABLE
	swprintf( szDbgMsg, L"CVersionConvertor::ConvertData()  - Invoked  GTC %d\n",GetTickCount());
	OutputDebugString(szDbgMsg);

	swprintf( szDbgMsg, L"CVersionConvertor::ConvertData()  - Block Type : %d  GTC %d\n",wBlockType,GetTickCount());
	OutputDebugString(szDbgMsg);
#endif

	CHECK_FOR_NULL(pByConvertedData)

	//Instantiate the generic utility class
	CCMMUtility objUtil;
	
	DWORD dwIdentifierSize = 0;
	DWORD dwCount = 0;
	WORD  wBitSize = 0;
	// Used as flags to indicate whether the 
	// bitfields has been modified or not.
	bool bFlag = false;	
	// Bool Added to find if any of the new bitfirlds are added to the existing fields.
	bool bAddedField = false;
	WORD wShiftPosition = 0;
	// Will hold number of bits proceded.
	WORD wSize = 0; 	

	WORD wSrcIdentifierSize = 0;
	WORD wDesIdentifierSize = 0;
	WORD wStart = 0;	//Used for BITFIELD processing

	//Variables to maintain the position of the source and destination buffers
	DWORD dwIdentifierPosition = 0;
	long lCurrentDesPos = 0;

	BYTE **ppIdentifierDetails = NULL;
	BYTE *pSourceIdentifierBlock = NULL;

	IDENTIFIER_RECORD_INFO *pSourceIdentifierInfo = NULL;		//The Identifier Information of the source of the configuration.
	IDENTIFIER_RECORD_INFO *pDestinationIdentifierInfo = NULL; //The system's configuration information

	/**Check if the Blocktype being converted is a UNION type */
	CHECK_FUNCTION(glbObjMemoryManager.GetBlock(SYSTEM_CONFIGURATION_ID,wBlockType,(BYTE**)&pDestinationIdentifierInfo))
	CHECK_FUNCTION(glbObjMemoryManager.GetBlock(m_dwConfigurationID,wBlockType,(BYTE**)&pSourceIdentifierInfo))
	
	/**If the destination block is a UNION,very simple conversion*/
	if(classUnion == pDestinationIdentifierInfo->wclass)
	{
		DWORD dwSrcBlockSize,dwDesBlockSize;

		/**Compute the BlockSize*/
		CHECK_FUNCTION(glbObjMemoryManager.GetBlockSize(m_dwConfigurationID,wBlockType,&dwSrcBlockSize))
		CHECK_FUNCTION(glbObjMemoryManager.GetBlockSize(SYSTEM_CONFIGURATION_ID,wBlockType,&dwDesBlockSize))

		/**Check if the source is also a UNION and the sizes match*/
		if((classUnion == pSourceIdentifierInfo->wclass) && (dwSrcBlockSize == dwDesBlockSize) && (pDestinationIdentifierInfo->wDatatype == pSourceIdentifierInfo->wDatatype))
		{
			/**Copy the data*/
			BYTE* pSrc = pSourceData		+ lSourcePosition;
			BYTE* pDes = pByConvertedData	+ lDestinationPosition;
			memcpy(pDes,pSrc,dwSrcBlockSize);
			return CSTATUS_OK;
		}
		else /**Already defaulted*/
		{
			/**Done with the block, return*/
			return CSTATUS_OK;
		}
	}
	else /**Reset the variables*/
	{
		pSourceIdentifierInfo = NULL;
		pDestinationIdentifierInfo = NULL;
	}

	/**Get the Memory Manager compute the Byte locations of each Identifiers in the SOURCE for this block type*/
	CHECK_FUNCTION(glbObjMemoryManager.ComputeIdentifierPosition(m_dwConfigurationID,wBlockType))

	/**Fetch the List of Identifiers from the system metadata*/
	CHECK_FUNCTION(glbObjMemoryManager.GetEnumIdentifier(SYSTEM_CONFIGURATION_ID,wBlockType,&dwCount, &ppIdentifierDetails) )

	LOG_INFO(CMM_qDebugR_MODE,("ConvertData() - Identifier Count : %d"),dwCount);
	LOG_INFO(CMM_qDebugR_MODE,("ConvertData() - Identifier Loop starts"));
#ifdef PWDLOGS_ENABLE
	swprintf( szDbgMsg, L"CVersionConvertor::ConvertData()  -Identifier Count : %d  GTC %d\n",dwCount,GetTickCount());
	OutputDebugString(szDbgMsg);

	swprintf( szDbgMsg, L"CVersionConvertor::ConvertData()  -Identifier Loop starts  GTC %d\n",GetTickCount());
	OutputDebugString(szDbgMsg);
#endif
	wSize = 0;
	bFlag = false;
	bAddedField = false;
	
	/**Loop through the Identifier list and convert each element*/
	for(DWORD dwIndex = 0; dwIndex < dwCount;dwIndex++)
	{
		/**Get the First Identifier Block*/
		pDestinationIdentifierInfo = (IDENTIFIER_RECORD_INFO*) ppIdentifierDetails[dwIndex];

		LOG_INFO(CMM_qDebugR_MODE,("ConvertData()  - Destination Identifier Info: Identifier Index - %d,\
			Fieldname - %s, Hilimit - %d, Lowlimit - %d, Default - %d, Class - %d, Datatype - %d, Instances - %d, SubInstances - %d"),\
			dwIndex,pDestinationIdentifierInfo->Fieldname,pDestinationIdentifierInfo->Hilmt,\
			pDestinationIdentifierInfo->Lowlmt,pDestinationIdentifierInfo->vdefault,\
			pDestinationIdentifierInfo->wclass,pDestinationIdentifierInfo->wDatatype,\
			pDestinationIdentifierInfo->wnumInst,pDestinationIdentifierInfo->wnumSubInst);
#ifdef PWDLOGS_ENABLE
		/*swprintf( szDbgMsg, L"CVersionConvertor::ConvertData()  -Destination Identifier Info: GTC %d\n",GetTickCount());
		OutputDebugString(szDbgMsg);
		swprintf( szDbgMsg, L"CVersionConvertor::ConvertData()  -Identifier Index - %d,\
			\nFieldname - %s,\n Hilimit - %d,\n Lowlimit - %d,\n Default - %d,\n Class - %d,\n Datatype - %d,\n Instances - %d,\n SubInstances - %d GTC %d\n",
			dwIndex,pDestinationIdentifierInfo->Fieldname,pDestinationIdentifierInfo->Hilmt,\
			pDestinationIdentifierInfo->Lowlmt,pDestinationIdentifierInfo->vdefault,\
			pDestinationIdentifierInfo->wclass,pDestinationIdentifierInfo->wDatatype,\
			pDestinationIdentifierInfo->wnumInst,pDestinationIdentifierInfo->wnumSubInst,GetTickCount());
		OutputDebugString(szDbgMsg);*/
		
		qDebug("\n Field Name : %s block type :%d \n ",pDestinationIdentifierInfo->Fieldname,wBlockType);
#endif
		/**Fetch the Identifier details from the current Metadata*/
		//if(0 == strcmp(pDestinationIdentifierInfo->Fieldname,"GroupMask"))
		//	DebugBreak();

		/**If the Identifier is found in the current Metadata*/
		//CR 3090: Importing the recorder setup on Trend server pro having different configuration ID 
		//with different credit types, the TSP does not display credit information correctly.

		pSourceIdentifierBlock = NULL;

		if(CSTATUS_INVALID_IDENTIFIER != glbObjMemoryManager.GetIdentifierBlock(m_dwConfigurationID,wBlockType,pDestinationIdentifierInfo->Fieldname,&pSourceIdentifierBlock,&dwIdentifierPosition))
		{
			LOG_INFO(CMM_qDebugR_MODE,("ConvertData() - Identfier data located in current source at position : %d"),dwIdentifierPosition);
#ifdef PWDLOGS_ENABLE
			swprintf( szDbgMsg, L"CVersionConvertor::ConvertData()  -Identfier data located in current source at position : %d GTC %d\n",dwIdentifierPosition,GetTickCount());
			OutputDebugString(szDbgMsg);
#endif
			pSourceIdentifierInfo = (IDENTIFIER_RECORD_INFO*) pSourceIdentifierBlock;			
			
			/**Now starts the conversion logic*/

			/**If this identifier is a member struct/UNION,*/
			if(classStructmember == pDestinationIdentifierInfo->wclass || classUnionmember == pDestinationIdentifierInfo->wclass)
			{
				/**This is a UDT, hence use the precalculated block size for the current identifier.*/
				CHECK_FUNCTION_EX(glbObjMemoryManager.GetBlockSize(SYSTEM_CONFIGURATION_ID,pDestinationIdentifierInfo->wDatatype,&dwIdentifierSize),ppIdentifierDetails)

				/**Check if the source and destination have matching datatypes interms of structs/unions*/
				if(pDestinationIdentifierInfo->wDatatype == pSourceIdentifierInfo->wDatatype) //If datatypes match
				{
					/**Loop through the number of instances and recurse through each of them*/
					WORD  wDesInstanceCount = 0;
					WORD  wSrcInstanceCount = 0;
					WORD  wInstanceCount	= 0;
					// Check if the instance of the source and destination are same, if not check if the 
					// source instance is greater than the destination, if so loop through 
					// number of instances of destination.
					if((pDestinationIdentifierInfo->wnumInst == pSourceIdentifierInfo->wnumInst) ||
					 (pDestinationIdentifierInfo->wnumInst < pSourceIdentifierInfo->wnumInst)	)
					{						
						do
						{
							/** Recursive method*/
							LOG_INFO(CMM_qDebugR_MODE,("ConvertData() - Identifier is nested structure/union, recursing..."));
#ifdef PWDLOGS_ENABLE
							swprintf( szDbgMsg, L"CVersionConvertor::ConvertData()  -Identifier is nested structure/union, recursing. GTC %d\n",GetTickCount());
							OutputDebugString(szDbgMsg);
#endif
							CHECK_FUNCTION_EX( ConvertData(pDestinationIdentifierInfo->wDatatype, pSourceData, lSourcePosition + (long) dwIdentifierPosition, pByConvertedData,lDestinationPosition + lCurrentDesPos),ppIdentifierDetails )
						
							/**Now update the destination position*/
							//This is required to appropriately position the next identifier
							lCurrentDesPos += (long) dwIdentifierSize;
							
							/**Increment the instancecount and hence the source position*/
							if(wInstanceCount <= pSourceIdentifierInfo->wnumInst)
							{							
								//dwIdentifierPosition += dwIdentifierSize;
								DWORD dwSize = 0;
								CHECK_FUNCTION(glbObjMemoryManager.GetBlockSize(m_dwConfigurationID,pSourceIdentifierInfo->wDatatype,&dwSize))
								dwIdentifierPosition += dwSize;
								wInstanceCount++;
							}
							
						}while(wInstanceCount < pDestinationIdentifierInfo->wnumInst);
					}
					else
					{
						// If the number of instance of destination is more than the 
						// number of instance of the source then loop through the number 
						// of instances of source rest of the instances of destination will 
						// remain defaulted.
						if(pDestinationIdentifierInfo->wnumInst > pSourceIdentifierInfo->wnumInst)
						{
							//if(0 == strcmp(pDestinationIdentifierInfo->Fieldname,"Alm"))
							//	DebugBreak();

							do
							{
								/** Recursive method*/
								LOG_INFO(CMM_qDebugR_MODE,("ConvertData() - Identifier is nested structure/union, recursing..."));
								CHECK_FUNCTION_EX( ConvertData(pDestinationIdentifierInfo->wDatatype, pSourceData, lSourcePosition + (long) dwIdentifierPosition, pByConvertedData,lDestinationPosition + lCurrentDesPos),ppIdentifierDetails )
							
								/**Now update the destination position*/
								//This is required to appropriately position the next identifier
								lCurrentDesPos += (long) dwIdentifierSize;
								wDesInstanceCount++;
								/**Increment the instancecount and hence the source position*/
								//if(++wInstanceCount < pDestinationIdentifierInfo->wnumInst)
								//	dwIdentifierPosition += dwIdentifierSize;								

								if(wSrcInstanceCount <= (pSourceIdentifierInfo->wnumInst))
								{									
									//dwIdentifierPosition += dwIdentifierSize;
									DWORD dwSize = 0;
									CHECK_FUNCTION(glbObjMemoryManager.GetBlockSize(m_dwConfigurationID,pSourceIdentifierInfo->wDatatype,&dwSize))
									dwIdentifierPosition += dwSize;
									wSrcInstanceCount++;
								}								

							}while(wSrcInstanceCount < pSourceIdentifierInfo->wnumInst);

							lCurrentDesPos += (long)(dwIdentifierSize) * (pDestinationIdentifierInfo->wnumInst - wSrcInstanceCount);
						}
					}

				}
				else /**Else if Datatypes dont match*/
				{
					/**Since already defaulted, update position*/
					LOG_INFO(CMM_qDebugR_MODE,("ConvertData() - Mismatched struct/union Identifier cannot be converted,left defaulted..."));
#ifdef PWDLOGS_ENABLE
					swprintf( szDbgMsg, L"CVersionConvertor::ConvertData()  -Mismatched struct/union Identifier cannot be converted,left defaulted.. GTC %d\n",GetTickCount());
					OutputDebugString(szDbgMsg);
#endif
					lCurrentDesPos += (long) dwIdentifierSize;
				}
			}
			else if ((CHECK_BITTYPE(pDestinationIdentifierInfo->wDatatype)))	/**If this identifier is a bitfield, handle special*/
			{
				LOG_INFO(CMM_qDebugR_MODE,("ConvertData() - Identifier : Bitfield type..."));
#ifdef PWDLOGS_ENABLE				
				swprintf( szDbgMsg, L"CVersionConvertor::ConvertData()  -Identifier : Bitfield type..GTC %d\n",GetTickCount());
				OutputDebugString(szDbgMsg);
#endif
				/**Recalculate the source and destination sizes*/
				wSrcIdentifierSize = objUtil.ComputeIdentifierSize(pSourceIdentifierInfo,INCLUDE_NONE);
				wDesIdentifierSize = objUtil.ComputeIdentifierSize(pDestinationIdentifierInfo,INCLUDE_NONE);

				LOG_INFO(CMM_qDebugR_MODE,("ConvertData() - Source Size : %d, Destination Size : %d"),wSrcIdentifierSize,wDesIdentifierSize);
#ifdef PWDLOGS_ENABLE				
				swprintf( szDbgMsg, L"CVersionConvertor::ConvertData()  -Source Size : %d, Destination Size : %d GTC %d\n",wSrcIdentifierSize,wDesIdentifierSize,GetTickCount());
				OutputDebugString(szDbgMsg);
#endif
				/**If any change is detected in either datatype/number of bits per identifier, simply default*/
				/**If same datatype and same instance*/
				
				wSize = wSize + pDestinationIdentifierInfo->wnumInst;
				
				if((wSrcIdentifierSize == wDesIdentifierSize) && 
				  (pDestinationIdentifierInfo->wnumInst != pSourceIdentifierInfo->wnumInst))
				{						
					bFlag = true;
				}

				if(0 != strcmp(pDestinationIdentifierInfo->Fieldname,pSourceIdentifierInfo->Fieldname))
				{
					bAddedField = true;
					wShiftPosition = wShiftPosition + pDestinationIdentifierInfo->wnumInst;
				}

				//if( 0 == strcmp(pSourceIdentifierInfo->Fieldname, "BorderWidth"))
				//	DebugBreak();

				if((bFlag == true) && (wSize >= (wSrcIdentifierSize*8)))
				{
					/**Do nothing, since defaulted earlier*/
					/**Just move the pointer*/					
					lCurrentDesPos += (long) wDesIdentifierSize;	
					// Reset the size and the flag to be used if 
					// structure is an array of bitfields
					wSize = 0;
					bFlag = false;
				}
				else
				{
					if ( bFlag == false )
					{
						if( wSize >= (wSrcIdentifierSize*8) )
						{							
							//CHECK_FUNCTION_EX( FieldCopy (pSourceIdentifierInfo, pSourceData + lSourcePosition + (long) dwIdentifierPosition, pDestinationIdentifierInfo, pByConvertedData + lDestinationPosition + lCurrentDesPos),ppIdentifierDetails);
							if(CSTATUS_VALUE_OUT_OF_RANGE != objUtil.ValidateBitFields(pDestinationIdentifierInfo,pSourceData + lSourcePosition + (long) dwIdentifierPosition,(wSize - pDestinationIdentifierInfo->wnumInst), pDestinationIdentifierInfo->wnumInst, &wShiftPosition))
							{
								CHECK_FUNCTION_EX( CopyBits(pSourceData + lSourcePosition + (long) dwIdentifierPosition, 
													pByConvertedData + lDestinationPosition + lCurrentDesPos,
													pSourceIdentifierInfo->wDatatype,
													&wShiftPosition, pSourceIdentifierInfo->wnumInst),ppIdentifierDetails);												
							}		
						
							LOG_INFO(CMM_qDebugR_MODE,("ConvertData() - Data copied..."));
#ifdef PWDLOGS_ENABLE							
							swprintf( szDbgMsg, L"CVersionConvertor::ConvertData()  -Data copied...GTC %d\n",GetTickCount());
							OutputDebugString(szDbgMsg);
#endif

							/**move the pointer*/					
							lCurrentDesPos += (long) wDesIdentifierSize;	
							// Reset the size and the flag to be used if 
							// structure is an array of bitfields
							wSize = 0;
							bFlag = false;								
						}
						else if( false == bAddedField )
						{	
							if(CSTATUS_VALUE_OUT_OF_RANGE != objUtil.ValidateBitFields(pDestinationIdentifierInfo,pSourceData + lSourcePosition + (long) dwIdentifierPosition,(wSize - pDestinationIdentifierInfo->wnumInst), pDestinationIdentifierInfo->wnumInst, &wShiftPosition))
							{
								CHECK_FUNCTION_EX( CopyBits(pSourceData + lSourcePosition + (long) dwIdentifierPosition, 
													pByConvertedData + lDestinationPosition + lCurrentDesPos,
													pSourceIdentifierInfo->wDatatype,
													&wShiftPosition, pSourceIdentifierInfo->wnumInst),ppIdentifierDetails);												
							}						
						}						
					}
					
				}
			}
			else /**Not a bitfield operation. Could be a UNION/INTRINSIC Datatype*/
			{
				LOG_INFO(CMM_qDebugR_MODE,("ConvertData() - Identifier : NOT Bitfield type..."));
#ifdef PWDLOGS_ENABLE
				swprintf( szDbgMsg, L"CVersionConvertor::ConvertData()  -Identifier : NOT Bitfield type...GTC %d\n",GetTickCount());
							OutputDebugString(szDbgMsg);
#endif
				if(classUnionmember == pDestinationIdentifierInfo->wclass)
				{
					/**This is a UDT, hence use the precalculated block size for the current identifier.*/
					CHECK_FUNCTION_EX(glbObjMemoryManager.GetBlockSize(SYSTEM_CONFIGURATION_ID,pDestinationIdentifierInfo->wDatatype,&dwIdentifierSize),ppIdentifierDetails)
					wDesIdentifierSize = (WORD)dwIdentifierSize;
				}
				else	/**Else if Intrinsic Datatypes*/
					wDesIdentifierSize =  objUtil.ComputeIdentifierSize(pDestinationIdentifierInfo,INCLUDE_ALL);

				/**Check if the datatypes match or if conversion is allowed between the types*/
				if( (pSourceIdentifierInfo->wDatatype == pDestinationIdentifierInfo->wDatatype) ||\
					(ConversionAllowed(pSourceIdentifierInfo->wDatatype,pDestinationIdentifierInfo->wDatatype)))
				{
					if(0 == (strcmp(pSourceIdentifierInfo->Fieldname,pDestinationIdentifierInfo->Fieldname)))
					{
						LOG_INFO(CMM_qDebugR_MODE,("ConvertData() - Same datatypes / conversion allowed..."));
						CHECK_FUNCTION_EX( DimensionCheckAndConvert(pSourceIdentifierInfo, pSourceData + lSourcePosition + (long) dwIdentifierPosition, pDestinationIdentifierInfo, pByConvertedData + lDestinationPosition + lCurrentDesPos),ppIdentifierDetails)
					}
				}
				else /**Else if not compatible/convertible datatype*/
				{
					/**Leave defaulted*/
					LOG_INFO(CMM_qDebugR_MODE,("ConvertData() - Identifier cannot be converted,left defaulted..."));
#ifdef PWDLOGS_ENABLE					
					swprintf( szDbgMsg, L"CVersionConvertor::ConvertData()  -Identifier cannot be converted,left defaulted GTC %d\n",GetTickCount());
					OutputDebugString(szDbgMsg);
#endif
				}

				/**Now update the destination position, including all its instances/subinstances etc*/
				//This is required to appropriately position the next identifier
				lCurrentDesPos += wDesIdentifierSize;

				LOG_INFO(CMM_qDebugR_MODE,("ConvertData() - Updated Destination Position : %d"),lCurrentDesPos);
#ifdef PWDLOGS_ENABLE
				swprintf( szDbgMsg, L"CVersionConvertor::ConvertData()  -Updated Destination Position : %d GTC %d\n",lCurrentDesPos,GetTickCount());
				OutputDebugString(szDbgMsg);
#endif
			}
		}
		else /**Else if Identifier not fount in current metadata*/
		{
			LOG_INFO(CMM_qDebugR_MODE,("ConvertData() - Identifier not defined in current metadata,left defaulted..."));

			/**Determine the Destination position offset*/

			//If this identifier is a member struct/union
			if( (classStructmember == pDestinationIdentifierInfo->wclass) || (classUnionmember == pDestinationIdentifierInfo->wclass))
			{
				//This is a UDT, hence use the precalculated block size for the current identifier.
				CHECK_FUNCTION_EX(glbObjMemoryManager.GetBlockSize(SYSTEM_CONFIGURATION_ID,pDestinationIdentifierInfo->wDatatype,&dwIdentifierSize),ppIdentifierDetails)
				wDesIdentifierSize = (WORD)dwIdentifierSize;
			}
			else	//Intrinsic Datatypes
  wDesIdentifierSize =  objUtil.ComputeIdentifierSize(pDestinationIdentifierInfo,INCLUDE_ALL);

			/**Update destination position*/
			// Case1: Check if the identifier is a bitfield, If so check till all the 
			// fields of the bitfield are compleated once all the fields of bitfield 
			// are checked update the position to next identifier.
			//
			// Case2 : If not bitfield just move the source position by the size of 
			// identifier.
			//
			if((CHECK_BITTYPE(pDestinationIdentifierInfo->wDatatype)))			 
			{	
				wSize = wSize + pDestinationIdentifierInfo->wnumInst;
				if(wSize == (wDesIdentifierSize * 8))
				{
					lCurrentDesPos += (long) wDesIdentifierSize;
					wSize = 0;
				}
///<@todo the below commented code to be removed after verifying the above fix is working fine.
				/*if(wSize == (wDesIdentifierSize * 8))
				{
					lCurrentDesPos += (long) wDesIdentifierSize;
					wSize = 0;
				}
				else
				{
					wSize = wSize + pDestinationIdentifierInfo->wnumInst;
				}*/
			}
			else
			{
				lCurrentDesPos += (long) wDesIdentifierSize;
			}
		}
	}

	if(ppIdentifierDetails)
		LocalFree(ppIdentifierDetails);		/**Delete the array of byte pointers allocated by GetEnumIdentifiers method*/

	END__EXCEPTION__BLOCK
	CATCH__EXCEPTION
}

CMMSTATUS CVersionConvertor::CopyBits(BYTE* pByPtr,	BYTE* pByDestPtr, WORD wDataType, 
									  WORD *wPosition, WORD wInstanceCount)
{
	int nBitCount=0;

	value varValue;

	if(NULL == wPosition)
	{
		LOG_ERR(CMM_qDebugR_MODE,("DefaultIntrinsicAndArrayDataType - invalid bushort bit start value"));
		return CSTATUS_FAIL;
	}	
	
	switch(wDataType)
	{
		case REF_BUSHORT:
		{			
			varValue.us = 0;					

			USHORT wMask=0;
			nBitCount =0 ;

			// Create a mask for the bits that are required.
			for(nBitCount;nBitCount < wInstanceCount;nBitCount ++)
			{
				//create the mask for the number of bits required
				wMask = wMask | (1 << nBitCount);
				//so if 3 bit mask has to be created, it would be 0000 0111'b
			}

			USHORT wMaskInverted = 0;
			// Get to the position of the bit required.
			wMask = wMask << *wPosition;					

			// Get the config value from source
			SHORT *sConfPtr = (SHORT*)pByPtr;
			SHORT sConfData = *sConfPtr;
			
			// Get the bitfield value from source pointer
			varValue.us = (sConfData & wMask);			
			
			// Create an Inverted mask
			wMaskInverted = ~wMask;			

			// Get data From Destination
			SHORT *psDestPtr = (SHORT*)pByDestPtr;
			SHORT stemp = *psDestPtr;

			// AND it with inverted mask to get all other bits from destination.
			stemp = stemp & wMaskInverted;

			// OR with the value that has been extracted from source bitfield.
			*psDestPtr = stemp | varValue.us;
			
			// Get to the next bitfield position.
			*wPosition += wInstanceCount;

			break;
		}

		case REF_BUCHAR:
		{
			varValue.uc = 0;					

			UCHAR cMask=0;
			nBitCount =0 ;

			// Create a mask for the bits that are required.
			for(nBitCount;nBitCount < wInstanceCount;nBitCount ++)
			{
				//create the mask for the number of bits required
				cMask = cMask | (1 << nBitCount);
				//so if 3 bit mask has to be created, it would be 0000 0111'b
			}

			UCHAR cMaskInverted = 0;
			// Get to the position of the bit required.
			cMask = cMask << *wPosition;					

			// Get the config value from source
			UCHAR *cConfPtr = (UCHAR*)pByPtr;
			UCHAR cConfData = *cConfPtr;
			
			// Get the bitfield value from source pointer
			varValue.uc = (cConfData & cMask);			
			
			// Create an Inverted mask
			cMaskInverted = ~cMask;			

			// Get data From Destination
			UCHAR *pcDestPtr = (UCHAR*)pByDestPtr;
			UCHAR ctemp = *pcDestPtr;

			// AND it with inverted mask to get all other bits from destination.
			ctemp = ctemp & cMaskInverted;

			// OR with the value that has been extracted from source bitfield.
			*pcDestPtr = ctemp | varValue.uc;
			
			// Get to the next bitfield position.
			*wPosition += wInstanceCount;

			break;
		}

		case REF_BULONG:
		{
			varValue.ul = 0;					

			ULONG lMask=0;
			nBitCount =0 ;

			// Create a mask for the bits that are required.
			for(nBitCount;nBitCount < wInstanceCount;nBitCount ++)
			{
				//create the mask for the number of bits required
				lMask = lMask | (1 << nBitCount);
				//so if 3 bit mask has to be created, it would be 0000 0111'b
			}

			ULONG lMaskInverted = 0;
			// Get to the position of the bit required.
			lMask = lMask << *wPosition;					

			// Get the config value from source
			ULONG *lConfPtr = (ULONG*)pByPtr;
			ULONG lConfData = *lConfPtr;
			
			// Get the bitfield value from source pointer
			varValue.ul = (lConfData & lMask);			
			
			// Create an Inverted mask
			lMaskInverted = ~lMask;			

			// Get data From Destination
			ULONG *plDestPtr = (ULONG*)pByDestPtr;
			ULONG ltemp = *plDestPtr;

			// AND it with inverted mask to get all other bits from destination.
			ltemp = ltemp & lMaskInverted;

			// OR with the value that has been extracted from source bitfield.
			*plDestPtr = ltemp | varValue.ul;
			
			// Get to the next bitfield position.
			*wPosition += wInstanceCount;

			break;
		}

		default:
		{
			break;
		}
	}	

	return CSTATUS_OK;
}
//******************************************************************************************
/// Function :  CVersionConvertor::DimensionCheckAndConvert()
//  Logic : 
/// Usage : Iterates through the Instances and subinstances of the destination and copies the source contents.
//  Author : [Rashmy Bharadawaj]
/// Exception/Error handling : Structured Exception Handling Macros (Defined in Macro.h) 
/// Assumptions : 
//  Function parameters : 
///					@param[in]		pSrcIdentifierInfo - The source identifier's details
///					@param[in]		pSource -  The Block type to convert
///					@param[in]		pDestIdentifierInfo - The destination identifier's details
///					@param[in]		pDestination - The converted block
///					@return			CMMSTATUS		  - Enumerated Status Code (Defined in Global.h)
//  Modification History :
//  Date Modifications
//  ---- -------------
//  7/8/2004  Created
//******************************************************************************************/
CMMSTATUS CVersionConvertor::DimensionCheckAndConvert (IDENTIFIER_RECORD_INFO *pSrcIdentifierInfo, BYTE *pSource,IDENTIFIER_RECORD_INFO *pDestIdentifierInfo,BYTE *pDestination)
{
	BEGIN__EXCEPTION__BLOCK

	LOG_INFO(CMM_qDebugR_MODE,("DimensionCheckAndConvert()  - Invoked"));

	//Positions for instances/subinstances within an identifier
	long lSrcPosition = 0;
	long lDesPosition = 0;
	
	//CopyData status code
	BOOL bStatus = true;

	/**If the Identifier has 1 instance*/	
	if(!pDestIdentifierInfo->wnumInst)
	{
		/**Invoke CopyData*/
		LOG_INFO(CMM_qDebugR_MODE,("DimensionCheckAndConvert()  - 0 Instances in system definition..."));
		CopyData(pSrcIdentifierInfo,pSource,pDestIdentifierInfo,pDestination,&lSrcPosition,&lDesPosition,&bStatus);
	}
	else /**Else*/
	{
		/**indexOf the lower number of instances between src & dest*/
		WORD nInstanceCount = pDestIdentifierInfo->wnumInst <= pSrcIdentifierInfo->wnumInst ? pDestIdentifierInfo->wnumInst : pSrcIdentifierInfo->wnumInst;

		LOG_INFO(CMM_qDebugR_MODE,("DimensionCheckAndConvert()  - Lower number of instances between source and destination : %d"),nInstanceCount);

		/**Loop through the instances*/
		for(int nInstanceIndex = 0;nInstanceIndex < nInstanceCount;nInstanceIndex++)
		{
			LOG_INFO(CMM_qDebugR_MODE,("DimensionCheckAndConvert()  - Copying instance index : %d between from Source Position : %d to Destination Position : %d"),nInstanceIndex,lSrcPosition,lDesPosition);

			/**If 1 subinstances*/
			if(!pDestIdentifierInfo->wnumSubInst)
			{
				/**Invoke CopyData*/
				LOG_INFO(CMM_qDebugR_MODE,("DimensionCheckAndConvert()  - 0 Sub-Instances in system definition..."));
				CopyData(pSrcIdentifierInfo,pSource + lSrcPosition,pDestIdentifierInfo,pDestination + lDesPosition,&lSrcPosition,&lDesPosition,&bStatus);

				/**if Status is false, We can be sure that if the destination identifier's raw data size is lower than the source, copydata would have failed*/
				if(!bStatus)
					break;
			}
			else /**Else Loop through the subinstances*/
			{
				/**indexOf the lower number of subinstances between src & dest*/
				WORD nSubInstanceCount = pDestIdentifierInfo->wnumSubInst <= pSrcIdentifierInfo->wnumSubInst ? pDestIdentifierInfo->wnumSubInst : pSrcIdentifierInfo->wnumSubInst;

				LOG_INFO(CMM_qDebugR_MODE,("DimensionCheckAndConvert()  - Lower number of subinstances between source and destination : %d"),nSubInstanceCount);

				for(int nSubInstanceIndex = 0;nSubInstanceIndex < nSubInstanceCount;nSubInstanceIndex++)
				{
					/**Invoke CopyData*/
					LOG_INFO(CMM_qDebugR_MODE,("DimensionCheckAndConvert()  - Copying Subinstance index : %d between from Source Position : %d to Destination Position : %d"),nSubInstanceIndex,lSrcPosition,lDesPosition);
					CopyData(pSrcIdentifierInfo,pSource + lSrcPosition,pDestIdentifierInfo,pDestination + lDesPosition,&lSrcPosition,&lDesPosition,&bStatus);

					/**if Status is false, We can be sure that if the destination identifier's raw data size is lower than the source, copydata would have failed*/
					if(!bStatus)
						break;
				}
			}
		}
	}

	END__EXCEPTION__BLOCK
	CATCH__EXCEPTION
}

//******************************************************************************************
/// Function :  CVersionConvertor::ConversionAllowed()
//  Logic : 
/// Usage : Used to check if conversion can be allowed between two datatypes
//  Author : [Rashmy Bharadawaj]
/// Exception/Error handling : <None>
/// Assumptions : 
//  Function parameters : 
///					@param[in]		pSrcDataType - The source datatype
///					@param[in]		pDesDataType -  The destination datatype
///					@return			BOOL		  - true, if convertible datatypes & false if not
//  Modification History :
//  Date Modifications
//  ---- -------------
//  7/8/2004  Created
//******************************************************************************************/
BOOL CVersionConvertor::ConversionAllowed (WORD pSrcDataType, WORD pDesDataType)
{
	BOOL bAllowed = true;

	if((DATATYPE_FLOAT(pSrcDataType)) && (DATATYPE_FLOAT(pDesDataType)))
		bAllowed = true;
	else if((DATATYPE_NUMERIC(pSrcDataType)) && (DATATYPE_NUMERIC(pDesDataType)))
		bAllowed = true;
	else if( (DATATYPE_CHAR(pSrcDataType)) && (DATATYPE_CHAR(pDesDataType)) )
		bAllowed = true;
	else
		bAllowed = false;

	return bAllowed;
}


//******************************************************************************************
/// Function :  CVersionConvertor::CopyData()
/// Logic : Only lower/equal sized instances will be copied
/// Usage : Used for copying each instance/subinstance based on the individual instance size
//  Author : [Rashmy Bharadawaj]
/// Exception/Error handling : Structured Exception Handling Macros (Defined in Macro.h) 
/// Assumptions : 
//  Function parameters : 
///					@param[in]		pSrcIdentifierInfo	- The details of the source identifier
///					@param[in]		pSource				-  The Block type to convert
///					@param[in]		pDestIdentifierInfo - The details of the destination identifier
///					@param[in]		pDestination - Converted data
///					@param[in/out]	lSrcPosition - The start position of the source Identifier instance
///					@param[in/out]	lDesPosition - The start position of the destination Identifier instance
///					@param[in/out]	pBStatus	 - true/false depending on the copying status.
///					@return			CMMSTATUS	 - Enumerated Status Code (Defined in Global.h)
//  Modification History :
//  Date Modifications		Author 
//  ---- ------------- ------------
//  7/9/2004  Created				Rashmy
//  05/06/05		Modified			Shyam		Added parameter to ValidateIntrinsicAndArrayDataType method.
//*******************************************************************************************************************/
CMMSTATUS  CVersionConvertor::CopyData (IDENTIFIER_RECORD_INFO *pSrcIdentifierInfo, BYTE *pSource,IDENTIFIER_RECORD_INFO *pDestIdentifierInfo,BYTE *pDestination,long *lSrcPosition,long *lDesPosition,BOOL *pBStatus)
{

	BEGIN__EXCEPTION__BLOCK
#ifdef PWDLOGS_ENABLE
	WCHAR szDbgMsg[512];
#endif
	LOG_INFO(CMM_qDebugR_MODE,("CopyData()  - Invoked"));
#ifdef PWDLOGS_ENABLE
	swprintf( szDbgMsg, L"CVersionConvertor::CopyData  -Invoked GTC %d\n",GetTickCount());
	OutputDebugString(szDbgMsg);
#endif

	/**Compute the number of Bytes held by the subinstance of the destination*/
	CCMMUtility objUtil;

	WORD wDestinationSize = 0;
	WORD wSourceSize = 0;
	
	DWORD dwIdentifierSize = 0; 

	/**Get the instance Sizes from the source and destination information*/

	wDestinationSize =  objUtil.ComputeIdentifierSize(pDestIdentifierInfo,INCLUDE_NONE);
	wSourceSize =  objUtil.ComputeIdentifierSize(pSrcIdentifierInfo,INCLUDE_NONE);

	LOG_INFO(CMM_qDebugR_MODE,("CopyData()  - System Identifier Size (INCLUDE_NONE) : %d"),wDestinationSize);
	LOG_INFO(CMM_qDebugR_MODE,("CopyData()  - Current Identifier Size (INCLUDE_NONE) : %d"),wSourceSize);
#ifdef PWDLOGS_ENABLE
	swprintf( szDbgMsg, L"CVersionConvertor::CopyData  -System Identifier Size (INCLUDE_NONE) : %d GTC %d\n",wDestinationSize,GetTickCount());
	OutputDebugString(szDbgMsg);
	
	swprintf( szDbgMsg, L"CVersionConvertor::CopyData  -Current Identifier Size (INCLUDE_NONE) : %d GTC %d\n",wSourceSize,GetTickCount());
	OutputDebugString(szDbgMsg);
#endif
	/**Compare the datatype specific instance size*/
	INSTANCECONDITION nSizeComparison = (wDestinationSize > wSourceSize) ? INSTANCE_HIGHER : ((wDestinationSize == wSourceSize) ? INSTANCE_EQUAL : INSTANCE_LOWER);
	
	WORD wValidSize = 0;	//Returned from the Validate method
	
	CMMSTATUS ValidationResult = CSTATUS_OK;

	switch(nSizeComparison)
	{
		case INSTANCE_EQUAL:/**If Destination's instance size is Equal/Higher*/
		case INSTANCE_HIGHER:
				LOG_INFO(CMM_qDebugR_MODE,("CopyData()  - System Size > Current Size"));

				/**Validate with the Destination's info swapping with the source's datatype*/
				/** false added since all the instances of the identifier need not be verified 
				for the limit check, Since each time the outer loop takes care of incrementing 
				the data buffer to proper location*/
				if(CSTATUS_VALUE_OUT_OF_RANGE != objUtil.ValidateIntrinsicAndArrayDataType(*pDestIdentifierInfo,pSource,&wValidSize,0,wSourceSize, false))
				{
					LOG_INFO(CMM_qDebugR_MODE,("CopyData()  - Current Data Valid, copying..."));
#ifdef PWDLOGS_ENABLE
					swprintf( szDbgMsg, L"CVersionConvertor::CopyData  -Current Data Valid, copying.. GTC %d\n",GetTickCount());
					OutputDebugString(szDbgMsg);
#endif

					/**Copy source size of bytes to destination*/
					memcpy(pDestination,pSource,wSourceSize);

					/**Update the Positions since we have done something.*/
					*lSrcPosition = *lSrcPosition + wSourceSize;
					*lDesPosition = *lDesPosition + wDestinationSize;
					*pBStatus	  =	true;
					LOG_INFO(CMM_qDebugR_MODE,("CopyData()  - Updated Positions Source : %d, Destination : %d"),*lSrcPosition,*lDesPosition);
#ifdef PWDLOGS_ENABLE
					swprintf( szDbgMsg, L"CVersionConvertor::CopyData  -Updated Positions Source : %d, Destination : %d GTC %d\n",*lSrcPosition,*lDesPosition,GetTickCount());
					OutputDebugString(szDbgMsg);
#endif
				}
				else
				{
					*lSrcPosition = *lSrcPosition + wSourceSize;
					*lDesPosition = *lDesPosition + wDestinationSize;
					*pBStatus	  =	true;
				}
			break;
		case INSTANCE_LOWER:/**If Destination's instance size is lower, leave defaulted*/
			*pBStatus =	false;
			LOG_INFO(CMM_qDebugR_MODE,("CopyData()  - System Size < Current Size, Not copying..."));
			break;
	}

	END__EXCEPTION__BLOCK
	CATCH__EXCEPTION
}


CMMSTATUS  CVersionConvertor::FieldCopy (IDENTIFIER_RECORD_INFO *pSrcIdentifierInfo, BYTE *pSource,
										 IDENTIFIER_RECORD_INFO *pDestIdentifierInfo,BYTE *pDestination)
{
	BEGIN__EXCEPTION__BLOCK
	LOG_INFO(CMM_qDebugR_MODE,("FieldCopy()  - Invoked"));			
	
	/**Based on the destination datatype, switch operation*/
	switch(pDestIdentifierInfo->wDatatype)
	{
		case REF_BUSHORT:
			LOG_INFO(CMM_qDebugR_MODE,("FieldCopy()  - Datatype : REF_BUSHORT"));
			/**Update the 'value' members with source and destination*/		
			LOG_INFO(CMM_qDebugR_MODE,("FieldCopy()  - Source value : %d"),(short*)pSource);						
			/**copy the currently available value for the entire bitfields shared withing a datatype*/			
			memcpy(pDestination, pSource, sizeof(short) );
			break;
		case REF_BUCHAR:			
			LOG_INFO(CMM_qDebugR_MODE,("FieldCopy()  - Datatype : REF_CHAR"));
			/**Update the 'value' members with source and destination*/		
			LOG_INFO(CMM_qDebugR_MODE,("FieldCopy()  - Source value : %d"),(char*)pSource);						
			/**copy the currently available value for the entire bitfields shared withing a datatype*/			
			memcpy(pDestination, pSource, sizeof(char) );			
			break;
		case REF_BULONG:
			LOG_INFO(CMM_qDebugR_MODE,("FieldCopy()  - Datatype : REF_BULONG"));
			/**Update the 'value' members with source and destination*/		
			LOG_INFO(CMM_qDebugR_MODE,("FieldCopy()  - Source value : %d"),(long*)pSource);						
			/**copy the currently available value for the entire bitfields shared withing a datatype*/			
			memcpy(pDestination, pSource, sizeof(ULONG) );			
			break;
	}

	END__EXCEPTION__BLOCK
	CATCH__EXCEPTION
}

/// @file 
/// ****************************************************************************************
/// © Honeywell Trendview
/// ****************************************************************************************
/// @n Module:	 Password Management module
///
/// @n Filename: cUserValidation.cpp
///
/// @n Desc:	 validates the username and password against the policy data and initialises 
///				 the Password management module. Any modification to the User data will be 
///				 done in this module.
///
// ****************************************************************************************
// Revision History
// ****************************************************************************************
// $Log[1]:
//  26  Stability Project 1.21.1.3 7/2/2011 4:56:27 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
// $Log" for functions
// $
//
// ****************************************************************************************
/******************************************************************************************
 COPYRIGHT (c) 2004
 HONEYWELL INC.,
 ALL RIGHTS RESERVED
 This software is a copyrighted work and/or information protected
 as a trade secret. Legal rights of Honeywell Inc. in this
 software is distinct from ownership of any medium in which the
 software is embodied. Copyright or trade secret notices included
 must be reproduced in any copies authorized by Honeywell Inc.
 The information in this software is subject to change without
 notice and should not be considered as a commitment by Honeywell
 Inc.
 ******************************************************************************************/
/*************** Headers *********************************/
#include "CPolicyDataManager.h"
#include "CPasswordManager.h"
#include "CUserValidation.h"
#include "PWBackCoder.h"
#include "DAL.h"
#include "ConfigurationManager.h"
#include <stdlib.h>
#include "Defines.h"
#include "PMMdefines.h"
#include "AuthenticatePwd.h"
#include "TVtime.h"
/************** End of Headers ***************************/
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
/*********** Global Declarations ***********************/
//extern fnTrace			Trace ;							///< Global function pointer to log traces
//extern QLibrary			glbCMMHandle;					///< To hold CMM handle
//extern void UnLoadTracerModule ( ) ;					///< To unload DLL.
/************** End of Global Declaration***************/
//*************************************************************************************************
// CUserValidation :: CUserValidation()
//	 
///	Constructor of CUserValidation class. Initialises the DAL and updates 
///	the global variable which indicates the DAL status.
//**************************************************************************************************
//**********************************************************************************************
// Revision History
//**********************************************************************************************
// 
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad	  
//  
//
//**********************************************************************************************
//**********************************************************************************************
CUserValidation::CUserValidation() {
	/* m_DALSts = FALSE;
	 //m_pDeviceAbstraction = CDeviceAbstraction::GetHandle ();
	 //if(m_pDeviceAbstraction)
	 {
	 //	m_pDeviceAbstraction -> Initialise();
	 m_DALSts = TRUE;
	 }
	 else
	 {
	 m_DALSts = FALSE;
	 }
	 */
	LOG_INFO (PMM_qDebugR_MODE, ("PMM : ---------------------CUserValidation::CUserValidation --------------- Constructor"));
}
//*************************************************************************************************
// CUserValidation :: ~CUserValidation()	 
// 
///	Destructor of CUserValidation class.
//**************************************************************************************************
//**********************************************************************************************
// Revision History
//**********************************************************************************************
// 
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad	  
//  
//
//**********************************************************************************************
//**********************************************************************************************
CUserValidation::~CUserValidation() {
	LOG_INFO (PMM_qDebugR_MODE, ("PMM : ---------------------CUserValidation::CUserValidation ----------------- Destructor"));
	//UnLoadTracerModule ( ) ;
	// For Testing.
	// m_pDeviceAbstraction->Shutdown();
}
//***************************************************************************************
///
/// Converts the CMM status to the PMM understandable format.
///
/// @param[in] CMM_status	-	varPmmStatus returned by CMM.
///
/// @return		PMMERROR	-	Returns the varPmmStatus by converting to PMM format.	
/// 
/// @todo - 
///
//**************************************************************************************
// Revision History
// ************************************************************************************
// 
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad	  
//  
//
// ************************************************************************************
//**************************************************************************************
PMMERROR CUserValidation::GetCMMError(CMMERROR CMM_status) {
	PMMERROR varPmmStatus = PMM_SUCCESS;
	LOG_INFO (PMM_qDebugR_MODE, ("PMM : ----------------------CUserValidation::GetCMMError ----------------- SUCCESS"));
	switch (CMM_status) {
	case CMM_SUCCESS: {
		varPmmStatus = PMM_SUCCESS;
		LOG_INFO (PMM_qDebugR_MODE, ("PMM : CUserValidation::GetCMMError SUCCESS"));
		break;
	}
	case CMM_INVALID_CONFIGURATION_ID: {
		varPmmStatus = PMM_INVALID_CONFIGURATION_ID;
		break;
	}
	case CMM_FAILED: {
		varPmmStatus = PMM_CMM_FAILED;
		break;
	}
	case CMM_INSUFFICIENT_MEMORY: {
		varPmmStatus = PMM_INSUFFICIENT_MEMORY;
		break;
	}
	case CMM_NOT_INITIALIZED: {
		varPmmStatus = PMM_CMM_NOT_INITIALISED;
		break;
	}
	case CMM_INVALID_METADATA: {
		varPmmStatus = PMM_CMM_INVALID_METADATA;
		break;
	}
	case CMM_INVALID_PARAMETER: {
		varPmmStatus = PMM_INVALID_PARAMETER;
		break;
	}
	case CMM_VALUE_OUT_OF_RANGE:
	case CMM_INVALID_BLOCK_TYPE:
	case CMM_INVALID_INSTANCE: {
		varPmmStatus = PMM_FAILED;
		LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CUserValidation::GetCMMError - CMM FAILURE value = %d"), CMM_status);
		break;
	}
	default: {
		varPmmStatus = PMM_UNDEFINED;
		break;
	}
	}
	return varPmmStatus;
}
//***************************************************************************************
///
/// Removes the user of the lUserId.
///
/// @param[in]	lUserId		 -	ID of the user.
///
/// @return		PMMERROR -	Returns whether the user is removed from the user data or not.	
/// 
/// @todo - 
///
//**************************************************************************************
// Revision History
// ************************************************************************************
// 
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad	  
//  
//
//**************************************************************************************
//**************************************************************************************
PMMERROR CUserValidation::RemoveUserData(SHORT lUserId) {
	PMMERROR varPmmStatus;				// To store the varPmmStatus to be returned.
	LOG_INFO (PMM_qDebugR_MODE, ("PMM :-------------------------------- CUserValidation::RemoveUserData ----------------- "));
	// Since the array index starts from '0' reduce by one for the request sent 
	if (m_stUserDataCurrent->UserData[lUserId - ONESLOT].Used) {
		// If user has logged-in then deletion of user should not happen.
		if (!m_stLogDetails[lUserId - ONESLOT].LoginCount) {
			// Reset the user data of the lUserId specified.
			if (TRUE == m_DALSts) {
				memset((char*) &m_stUserDataWorking->UserData[lUserId - ONESLOT], ZERO, sizeof(T_USERDATA));
				LOG_INFO (PMM_qDebugR_MODE, ("PMM : CUserValidation::RemoveUserData SUCCESS : - Removed user data from database"));
				// Update the NVRAM entery for the user lUserId specified.		
				m_stNVData->RetryCount[lUserId - ONESLOT] = m_stPolicyDataCurrent->PwdPolicyData.MaxRetry;
				m_stNVData->PwdExpirySts[lUserId - ONESLOT] = FALSE;
				varPmmStatus = PMM_SUCCESS;
			} else {
				varPmmStatus = PMM_INVALID_SRAM_HANDLE;
				LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CUserValidation::RemoveUserData PMM_INVALID_SRAM_HANDLE"));
			}
		} else {
			varPmmStatus = PMM_FAILED;
		}
	} else {
		varPmmStatus = PMM_INVALID_USER_ID;
		LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CUserValidation::RemoveUserData PMM_INVALID_USER_ID"));
	}
	return varPmmStatus;
}
//***************************************************************************************
///
/// Resets all the UserData, NVRAM content, correspondent Class variables 
///	and Enables the first time User.
///
/// @param[in]	ConfigID -	Configuration lConfigurationId for the PMM.
///
/// @return		PMMERROR -	Error code if failed or PMM_SUCCESS.		
/// 
/// @todo - 
///
//**************************************************************************************
// Revision History
// ************************************************************************************
// 
//  1  V6 Firmware1	 6/29/2004		Shyam Prasad	  
//  
//Name Date  Modifications
//---- ----  -------------
//Shyam				 6/29/2004								Created
//******************************************************************************************/
// ************************************************************************************
//**************************************************************************************
PMMERROR CUserValidation::ResetAllUserData(DWORD lConfigId) {
	PMMERROR varPmmStatus = PMM_SUCCESS;			// To store the return status.
	LOG_INFO (PMM_qDebugR_MODE, ("PMM ------------------------ CUserValidation::ResetAllUserData -----------------------------------------"));
	if (lConfigId == m_ConfigId) {
		// Resets all the userdata in the Memory if the ConfigId matches.
		if (TRUE == m_DALSts) {
			memset((char*) &m_stUserDataWorking->UserData, ZERO, (sizeof(T_USERDATA) * MAX_USERS));
			// Reset all the NVRAM details of the Users.
			for (SHORT Users = ZERO; Users < MAX_USERS; Users++) {
				m_stNVData->PwdExpirySts[Users] = ZERO;
				m_stNVData->RetryCount[Users] = m_stPolicyDataCurrent->PwdPolicyData.MaxRetry;
			}
			LOG_INFO (PMM_qDebugR_MODE, ("PMM CUserValidation::ResetAllUserData : SUCCESS"));
			varPmmStatus = PMM_SUCCESS;
		} else {
			LOG_ERROR(PMM_qDebugR_MODE, ("PMM CUserValidation::ResetAllUserData : PMM_INVALID_SRAM_HANDLE"));
			varPmmStatus = PMM_INVALID_SRAM_HANDLE;
		}
	} else {
		varPmmStatus = PMM_INVALID_CONFIGURATION_ID;
		LOG_ERROR(PMM_qDebugR_MODE, ("PMM CUserValidation::ResetAllUserData : PMM_INVALID_CONFIGURATION_ID"));
	}
	return varPmmStatus;
}
//***************************************************************************************
// PMMERROR CUserValidation::GetWorkingCurrentPointers ( DWORD ConfigID) 
///
/// Gets the working and current pointers for the PMM user 
///	data and policy data from CMM.
///
/// @param[in]	ConfigID -	Configuration Id for the PMM.
///
/// @return		PMMERROR -	Error code if failed or PMM_SUCCESS.		
/// 
/// @todo - 
///
//**************************************************************************************
// Revision History
// ************************************************************************************
// 
//  1  V6 Firmware1	 6/29/2004		Shyam Prasad	  
//  
//Name Date  Modifications
//---- ----  -------------
//Shyam				 6/29/2004								Created
//******************************************************************************************/
// ************************************************************************************
//**************************************************************************************
PMMERROR CUserValidation::GetWorkingCurrentPointers(DWORD lConfigID) {
	PMMERROR varPmmStatus;						// To store the return value from PMM.
	CMMERROR CMM_status = CMM_SUCCESS;			// To store the return value from CMM.
	// Get the pointer for GetDataBlock pointer.
	LOG_INFO (PMM_qDebugR_MODE, ("PMM :--------------------------- CUserValidation::GetWorkingCurrentPointers -------------------------- "));
	//typedef int ( *GETDATABLOCK)  (DWORD ConfigID,				// PMM Configuration lConfigurationId
	//								 BLOCK_INFO *UdataBlockInfo,	// Block information with session number updated
	//								 TV_BOOL) ;						// Whether Commited or Working section of memory.
	//GETDATABLOCK GetDataBlockPtr;
	//GetDataBlockPtr = ( GETDATABLOCK) GetProcAddress ( glbCMMHandle,GETPROCADDRESSSTRING("GetDataBlock") ) ;		
	//if ( NULL != GetDataBlockPtr ) 
	//{	
	BLOCK_INFO *UdataBlockInfo;					// Block information for interacting with CMM.
	UdataBlockInfo = new BLOCK_INFO;
	if (NULL != UdataBlockInfo) {
		UdataBlockInfo->wInstanceID = TRUE;
		UdataBlockInfo->wBlockType = BLK_PMMDATA;
		UdataBlockInfo->dwBlockSize = sizeof(T_PMMDATA);
		UdataBlockInfo->dwSessionNumber = TRUE;
		UdataBlockInfo->pByBlock = FALSE;
		TV_BOOL CommitORWorking = CONFIG_MODIFIABLE;
		try {
			// Get All the Current and the working pointers of PMM user data and 
			// policy data from CMM.
			for (SHORT GetPointers = GET_USER_DATA_POINTER_WORKING;
					((GetPointers <= GET_POLICY_DATA_POINTER_CURRENT) && (CMM_status == CMM_SUCCESS)); GetPointers++) {
				//	Gets the Current and working copy of address of PMMData from CMM.
				switch (GetPointers) {
				case GET_USER_DATA_POINTER_WORKING: {
					// Get the Working User data pointer.
					LOG_INFO (PMM_qDebugR_MODE, ("PMM : CUserValidation::GetWorkingCurrentPointers - Get Working pointer of User data"));
					CMM_status = (CMMERROR) GetDataBlock(lConfigID,			// Configuration Id.
							UdataBlockInfo,		// Block info for obtaining working user data pointer.
							CommitORWorking);	// Working block
					if (CMM_SUCCESS == CMM_status) {
						m_stUserDataWorking = (T_PMMDATA*) UdataBlockInfo->pByBlock;
						LOG_INFO (PMM_qDebugR_MODE, ("PMM : CUserValidation::GetWorkingCurrentPointers - SUCCESS : obtained Working pointer of User data"));
						varPmmStatus = PMM_SUCCESS;
					} else {
						varPmmStatus = GetCMMError(CMM_status);
						LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CUserValidation::GetWorkingCurrentPointers - FAILURE : Working pointer of User data"));
					}
					break;
				}
				case GET_USER_DATA_POINTER_CURRENT: {
					// Get the Current User data pointer.
					LOG_INFO (PMM_qDebugR_MODE, ("PMM : CUserValidation::GetWorkingCurrentPointers - Get Current pointer of User data"));
					CommitORWorking = CONFIG_COMMITTED;
					UdataBlockInfo->pByBlock = ZERO;
					CMM_status = (CMMERROR) GetDataBlock(lConfigID,			// Configuration lConfigurationId.
							UdataBlockInfo,		// Block info for obtaining working user data pointer.
							CommitORWorking);	// Current block
					if (CMM_SUCCESS == CMM_status) {
						m_stUserDataCurrent = (T_PMMDATA*) UdataBlockInfo->pByBlock;
						LOG_INFO (PMM_qDebugR_MODE, ("PMM : CUserValidation::GetWorkingCurrentPointers - SUCCESS : obtained Current pointer of User data"));
						varPmmStatus = PMM_SUCCESS;
					} else
					// Check for error from CMM.
					{
						varPmmStatus = GetCMMError(CMM_status);
						LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CUserValidation::GetWorkingCurrentPointers - FAILURE : Current pointer of User data"));
					}
					break;
				}
				case GET_POLICY_DATA_POINTER_WORKING: {
					// Get the Working policy data pointer.		
					UdataBlockInfo->wInstanceID = TRUE;
					UdataBlockInfo->wBlockType = BLK_PMMPOLICYDATA;
					UdataBlockInfo->dwSessionNumber = TRUE;
					UdataBlockInfo->pByBlock = FALSE;
					UdataBlockInfo->dwBlockSize = sizeof(T_PMMPOLICYDATA);
					CommitORWorking = CONFIG_MODIFIABLE;
					LOG_INFO (PMM_qDebugR_MODE, ("PMM : CUserValidation::GetWorkingCurrentPointers - Get Working pointer of policy data"));
					CMM_status = (CMMERROR) GetDataBlock(lConfigID,			// Configuration lConfigurationId.
							UdataBlockInfo,		// Block info for obtaining working user data pointer.
							CommitORWorking);	// Working block
					if (CMM_SUCCESS == CMM_status) {
						m_stPolicyDataWorking = (T_PMMPOLICYDATA*) UdataBlockInfo->pByBlock;
						LOG_INFO (PMM_qDebugR_MODE, ("PMM : CUserValidation::GetWorkingCurrentPointers - SUCCESS : obtained Working pointer of policy data"));
						varPmmStatus = PMM_SUCCESS;
					} else {
						// Check for error from CMM.
						// Convert the error message into PMM understandable format.	
						varPmmStatus = GetCMMError(CMM_status);
						LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CUserValidation::GetWorkingCurrentPointers - FAILURE : Working pointer of policy data"));
					}
					break;
				}
				case GET_POLICY_DATA_POINTER_CURRENT: {
					// Get the Current policy data pointer.
					CommitORWorking = CONFIG_COMMITTED;
					UdataBlockInfo->pByBlock = ZERO;
					CMM_status = (CMMERROR) GetDataBlock(lConfigID,			// Configuration lConfigurationId.
							UdataBlockInfo,		// Block info for obtaining working user data pointer.
							CommitORWorking);	// Current block
					LOG_INFO (PMM_qDebugR_MODE, ("PMM : CUserValidation::GetWorkingCurrentPointers - Get Current pointer of Policy data"));
					if (CMM_SUCCESS == CMM_status) {
						m_stPolicyDataCurrent = (T_PMMPOLICYDATA*) UdataBlockInfo->pByBlock;
						varPmmStatus = PMM_SUCCESS;
						LOG_INFO (PMM_qDebugR_MODE, ("PMM : CUserValidation::GetWorkingCurrentPointers - SUCCESS : obtained Current pointer of policy data"));
					} else {
						varPmmStatus = GetCMMError(CMM_status);
						LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CUserValidation::GetWorkingCurrentPointers - FAILURE : Current pointer of User data"));
					}
					break;
				}
				default: {
					break;
				}
				}
			}
			if (UdataBlockInfo) {
				delete UdataBlockInfo;	// free the Block of memory allocated.
				UdataBlockInfo = NULL;
			}
		} catch (...) {
			LOG_INFO (PMM_qDebugR_MODE, ("PMM : CUserValidation::GetWorkingCurrentPointers - Exception block : PMM_FAILED"));
			if (UdataBlockInfo) {
				delete UdataBlockInfo;	// free the Block of memory allocated.
				UdataBlockInfo = NULL;
			}
			varPmmStatus = PMM_FAILED;
		}
	} else {
		varPmmStatus = PMM_INSUFFICIENT_MEMORY;
		LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CUserValidation::GetWorkingCurrentPointers : FAILED - PMM_INSUFFICIENT_MEMORY"));
	}
	//}
	//else
	//{
	//	varPmmStatus = PMM_INVALID_CMM_DLL;	
	//	LOG_ERROR ( PMM_qDebugR_MODE, ( "PMM : CUserValidation::GetWorkingCurrentPointers : FAILED - PMM_INVALID_CMM_DLL") ) ) 					
	//}
	return varPmmStatus;
}
//***************************************************************************************
//	PMMERROR CUserValidation::GetHandle ( ) 
///
/// Gets the handle to the SRAM. 
///
/// @return		PMMERROR -	Error code if failed or PMM_SUCCESS.		
/// 
/// @todo - 
///
//**************************************************************************************
// Revision History
// ************************************************************************************
// 
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad	  
//  
//
// ************************************************************************************
//**************************************************************************************
PMMERROR CUserValidation::GetHandle(void *NvPtr) {
	PMMERROR varPmmStatus = PMM_SUCCESS;		// To maintain return value
	LOG_INFO (PMM_qDebugR_MODE, ("PMM :----------------------------------- CUserValidation::GetHandle ------------------------------"));
	if (NvPtr) {
		m_DALSts = TRUE;
		m_stNVData = (T_PMMNVDATA*) NvPtr;
		/*if ( TRUE == m_DALSts ) 
		 {	
		 // Get the SRAM pointer from offset ZERO.
		 /*********************************************************************************************
		 SRAMREGION SRAMRegionMap[] = {
		 // Region ID			Start			End					Description
		 REGION_TEST,			0,				126, 				(L"Test"),			// 0-126
		 REGION_GENERAL,			128,			KB_TO_BYTE(2)-2, 	(L"General"),		// 128-2046
		 REGION_PASSWORD,		KB_TO_BYTE(2),	KB_TO_BYTE(3)-2,	(L"Password"),		// 2048 - 3070
		 REGION_TRANSACTION,		KB_TO_BYTE(3),	KB_TO_BYTE(3)+510,	(L"Transaction"),	// 3072 - 3582		
		 // End of list, ALWAYS keep at end
		 REGION_END,				0,				0,					(L"End")		
		 };
		 *********************************************************************************************/
		//m_stNVData = ( T_PMMNVDATA* ) m_pDeviceAbstraction -> GetPtrIntoSRAM ( KB_TO_BYTE ( 2 ) ) ;
		if (!m_stNVData) {
			varPmmStatus = PMM_INVALID_SRAM_POINTER;
			LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CUserValidation::GetHandle FAILURE : PMM_INVALID_SRAM_POINTER"));
		} else {
			LOG_INFO (PMM_qDebugR_MODE, ("PMM : CUserValidation::GetHandle - SUCCESS : Gets Handle "));
		}
	} else {
		varPmmStatus = PMM_INVALID_SRAM_HANDLE;
		LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CUserValidation::GetHandle - FAILURE : Get Handle Failed"));
	}
	return varPmmStatus;
}
//***************************************************************************************
//	PMMERROR CUserValidation::Resetm_stNVData ( TV_BOOL NewConfiguration) 
///
/// Verifies the password against the policy data present and returns the 
///	status of the user.
///
/// @param[in] NewConfiguration	-	Indicates whether configuration is new or the same 
///										recorder configuration. 
///
/// @return		PMMERROR			-	Returns Error code if failed or PMM_SUCCESS.		
/// 
/// @todo - 
///
//**************************************************************************************
// Revision History
// ************************************************************************************
// 
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad	  
//  
//
//**************************************************************************************
//**************************************************************************************
PMMERROR CUserValidation::ResetNVData(TV_BOOL NewConfiguration) {
	PMMERROR varPmmStatus = PMM_SUCCESS;
	// asprintf all the user information in NVRAM if the the 
	// configuration is new configuration.	
	if (NewConfiguration) {
		// Reset all the user data on The NVRAM and set the 
		// Retry of the user to the MAX allowed.
		LOG_INFO (PMM_qDebugR_MODE, ("PMM : ------------------------CUserValidation::ResetNVData -------------------"));
		if (TRUE == m_DALSts) {
			for (SHORT Users = ZERO; Users < MAX_USERS; Users++) {
				m_stNVData->PwdExpirySts[Users] = FALSE;
				m_stNVData->RetryCount[Users] = m_stPolicyDataCurrent->PwdPolicyData.MaxRetry;
			}
			LOG_INFO (PMM_qDebugR_MODE, ("PMM :CUserValidation::ResetNVData : SUCCESS - asprintf all NVDATA"));
		} else {
			varPmmStatus = PMM_INVALID_SRAM_HANDLE;
			LOG_ERROR(PMM_qDebugR_MODE, ("PMM :CUserValidation::ResetNVData : FAILURE - PMM_INVALID_SRAM_HANDLE"));
		}
	}
	return varPmmStatus;
}
//*********************************************************************************************************
// PMMERROR CUserValidation::InitialisePMM ( TV_BOOL ForceCFR,DWORD ConfigID,TV_BOOL NewConfiguration) 
//
/// Verifies the password against the policy data present and returns the 
///			ststus of the user.
///			STEP1 : Check for the valid configuration Id.
///			STEP2 : Get the Working and current pointers of User data and policy data.
///			STEP3 : Check the policy data obtained against the hard coded plicy data.
///			STEP4 : Get Handle to NVRAM.
///			STEP5 : Reset the NVRAM content if the configuration is new.			
///			STEP6 : Update the global variables and allow first time user access to the system.
///
/// @param[in]	ForceCFR		 -	To set the recorder in CFR or NonCFR mode. TRUE - CFR mode.
///
///	@param[in]	ConfigID		 -	Configuration Id for communication with CMM.
///
///	@param[in]	NewConfiguration -	Indicates whether the configuration loaded is a 
///									new configuration or related to the same recorder.
///
/// @return		PMMERROR -	Returns Error code if failed or PMM_SUCCESS.	
/// 
/// @todo - 
//********************************************************************************************************
// Revision History
//********************************************************************************************************
// 
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad	  
//  
//
// ************************************************************************************
//**************************************************************************************
//Name Date  Modifications
//---- ----  -------------
//Shyam				06/23/2004								Created
//Shyam				09/23/2004								lpolicySts Used to verify in the policy data 
//															whether proper mode is mensioned or not. 
//shyam				09/23/2004								gPolicySts used inorder to maintain the status 
//															of the previously initialised policy whether 
//															the policy is valid policy or not.
//******************************************************************************************/
PMMERROR CUserValidation::InitialisePMM(TV_BOOL lForceCFR,				// CFR or Non CFR mode
		DWORD lConfigID,				// Config lConfigurationId for PMM 
		ULONG lSerialNumber,			// Serial number of unit.
		TV_BOOL lNewConfiguration, 		// Whether New configuration or Not.
		void *NvPtr) {
	PMMERROR varPmmStatus = PMM_SUCCESS;									// Return varPmmStatus.
	LOG_INFO (PMM_qDebugR_MODE, ("PMM -------------------------------- InitPassword : Initialise PMM -----------------------"));
	if (lForceCFR <= TRUE) {
		BOOL lpolicySts = FALSE;
		//	Check if PMM is initialised with same configuration ID, 
		//	same Mode and is not a New Configuration.
		// Check for the Global Policy status bit whether PMM was initialised with valid policy or not.
		///todo - resolve isPMMInitialised()error
		if (( TRUE == IsPMMInitialised()) && (lConfigID == m_ConfigId) && (lForceCFR == m_Mode)
				&& ( FALSE == lNewConfiguration) && ( TRUE != m_gPolicySts)) {
			return PMM_SUCCESS;
			LOG_ERROR(PMM_qDebugR_MODE, ("PMM : InitPassword : Initialise PMM - Alraedy initialised."));
		}
		else {
			if (lConfigID) {
				// Store the ConfigId and the Mode in the global variable for future use.
				for (short CheckConditions = GET_POINTERS;
						((CheckConditions <= RESET_NVRAM_PMM_CONFIG) && (varPmmStatus == PMM_SUCCESS));
						CheckConditions++) {
					try {
						switch (CheckConditions) {
						case GET_POINTERS: {
							// Get the Working and current pointers of User data and policy data. 
							LOG_INFO (PMM_qDebugR_MODE, ("PMM API: InitPassword : Get all Pointers"));
							varPmmStatus = GetWorkingCurrentPointers(lConfigID);
							break;
						}
						case CHECK_POLICY: {
							// Check the policy data obtained against the hard coded plicy data.
							LOG_INFO (PMM_qDebugR_MODE, ("PMM API: InitPassword : Check for Policy"));
							if (( TRUE == IsPMMInitialised()) && (lConfigID == m_ConfigId) && (lForceCFR == m_Mode)) {
								POLICY_STATUS policySts;			// varPmmStatus from CheckPolicy.
								policySts = CheckPolicy(lForceCFR);
								varPmmStatus = GetPolicyError(policySts);
							}
							if (PMM_INVALID_POLICY_DATA == varPmmStatus) {
								m_gPolicySts = TRUE;
								varPmmStatus = PMM_SUCCESS;
							} else {
								m_gPolicySts = FALSE;
							}
							break;
						}
						case GET_NVRAM_HANDLE: {
							// Get Handle to NVRAM.
							LOG_INFO (PMM_qDebugR_MODE, ("PMM API: InitPassword : Get Handle to NVRAM"));
							varPmmStatus = GetHandle(NvPtr);
							break;
						}
						case RESET_NVRAM_PMM_CONFIG: {
							// Reset the NVARM content if the configuration is new.
							LOG_INFO (PMM_qDebugR_MODE, ("PMM API: InitPassword : Reset NVRAM details"));
							varPmmStatus = ResetNVData(lNewConfiguration);
							// Update the mode of the recorder in the policy data 
							// since the Default in Xls file may be defined wrongly.
							if (PMM_SUCCESS == varPmmStatus) {
								if (lForceCFR) {
									m_stPolicyDataWorking->GPolicyData.CFRmode = TRUE;
									m_stPolicyDataCurrent->GPolicyData.CFRmode = TRUE;
								} else {
									m_stPolicyDataWorking->GPolicyData.CFRmode = FALSE;
									m_stPolicyDataCurrent->GPolicyData.CFRmode = FALSE;
								}
							}
							break;
						}
						default: {
							break;
						}
						}			// End of Switch
					} catch (...) {
						varPmmStatus = PMM_FAILED;
						LOG_ERROR(PMM_qDebugR_MODE, ("PMM : InitPassword : Exception block"));
					}
				}					// End of For loop
				//	Update the Global Configuration Id, 
				//	mode of the recorder, Serial number of recorder and 
				//	Global initilise bit ot TRUE;	
				//	Allow First time user.
				if (PMM_SUCCESS == varPmmStatus) {
					m_ConfigId = lConfigID;
					m_SerialNumber = lSerialNumber;
					m_Mode = lForceCFR;
					m_PMMinitialise = TRUE;
					LOG_INFO (PMM_qDebugR_MODE, ("PMM : InitPassword : SUCCESS"));
					// If the policy is invalid and all the other conditions are satisfied then
					// PMM_INVALID_POLICY_DATA is returned, Where as PMM is initialised, All the global 
					// variables are updated.
					if (m_gPolicySts) {
						varPmmStatus = PMM_INVALID_POLICY_DATA;
					}
				} else {
					m_PMMinitialise = FALSE;
					LOG_ERROR(PMM_qDebugR_MODE, ("PMM : InitPassword : FAILED"));
				}
			} else {
				varPmmStatus = PMM_INVALID_CONFIGURATION_ID;
				LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CUserValidation::InitialisePMM - FAILURE : PMM_INVALID_CONFIGURATION_ID"));
			}
		}
	} else {
		varPmmStatus = PMM_INVALID_PARAMETER;
		LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CUserValidation::InitialisePMM - FAILURE : PMM_INVALID_PARAMETER"));
	}
	return varPmmStatus;
}
//***************************************************************************************
// PMMERROR CUserValidation::ValidatePassword ( QString Password) 
///
/// Verifies the password against the policy data present and returns the 
///	status of the user password.
///
/// @param[in] *Password -	Password to be verified.
///
/// @return		PMMERROR -	returns Error code if failed or PMM_SUCCESS.		
/// 
/// @todo - 
///
//**************************************************************************************
// Revision History
// ************************************************************************************
// 
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad	  
//  
//
// **************************************************************
//**************************************************************************************
PMMERROR CUserValidation::ValidatePassword(QString pPassword) {
	PMMERROR varPmmStatus = PMM_SUCCESS;		// Return status.
	SHORT space = ZERO;				// Keep the track of number of spaces in password.
	BYTE Alpha = (BYTE) ZERO,				// Keep the track of number of Alphabets in password.
			Num = (BYTE) ZERO,				// Keep the track of number of numerics in password.
			SplAlpha = (BYTE) ZERO;				// Keep the track of number of special characters in password.
	LOG_INFO ( PMM_qDebugR_MODE, ("PMM -------------------------- CUserValidation::ValidatePassword ---------------------"));
	// Check for the password whether satisfying the policy given.
	// Get all the Alphabets,Digits and Special character and verify aginst the Policy data.
	// If space is present in Password returns an invalid password.
	if (NULL != pPassword) {
		USHORT CheckCondition = 0;
		for (CheckCondition = ZERO; CheckCondition <= (wcslen(pPassword) - ONESLOT); CheckCondition++) {
			if (iswalpha(pPassword[CheckCondition])) {
				Alpha++;
			} else if (iswdigit(pPassword[CheckCondition])) {
				Num++;
			} else if (iswspace(pPassword[CheckCondition])) {
				space++;
				break;
			} else {
				SplAlpha++;
			}
		}
		if (!space) 		/// Space is not allowed in password
		{
			for (CheckCondition = CHECK_MAXIMUM_PASSWORD_LENGTH;
					((CheckCondition <= CHECK_PASSWORD_SPLALPHA) && (varPmmStatus == PMM_SUCCESS)); CheckCondition++) {
				switch (CheckCondition) {
				case CHECK_MAXIMUM_PASSWORD_LENGTH: {
					LOG_INFO ( PMM_qDebugR_MODE, ("PMM API: CUserValidation::ValidatePassword - CHECK_MAXIMUM_PASSWORD_LENGTH"));
					// Check for the Maximum Password length.
					if (m_stPolicyDataCurrent->PwdPolicyData.pwrdMaxLen == ZERO) {
						if ((SplAlpha + Num + Alpha) <= CFR_MAX_MAXPASSWORD_LENGTH) {
							LOG_INFO ( PMM_qDebugR_MODE, ("PMM API: CUserValidation::ValidatePassword : SUCCESS - CHECK_MAXIMUM_PASSWORD_LENGTH"));
							varPmmStatus = PMM_SUCCESS;
						} else {
							varPmmStatus = PMM_INVALID_PASSWORD;
							LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidatePassword - FAILURE : CHECK_MAXIMUM_PASSWORD_LENGTH"));
						}
					} else {
						if ((m_stPolicyDataCurrent->PwdPolicyData.pwrdMaxLen >= (SplAlpha + Num + Alpha))) {
							LOG_INFO ( PMM_qDebugR_MODE, ("PMM API: CUserValidation::ValidatePassword : SUCCESS - CHECK_MAXIMUM_PASSWORD_LENGTH"));
							varPmmStatus = PMM_SUCCESS;
						} else {
							varPmmStatus = PMM_INVALID_PASSWORD;
							LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidatePassword - FAILURE : CHECK_MAXIMUM_PASSWORD_LENGTH"));
						}
					}
					break;
				}
				case CHECK_MINIMUM_PASSWORD_LENGTH: {
					LOG_INFO ( PMM_qDebugR_MODE, ("PMM API: CUserValidation::ValidatePassword - CHECK_MINIMUM_PASSWORD_LENGTH"));
					// Check for the Minimum Password length.
					if (m_stPolicyDataCurrent->PwdPolicyData.PwrdMinLen == ZERO) {
						if ((SplAlpha + Num + Alpha) <= CFR_MAX_MAXPASSWORD_LENGTH) {
							LOG_INFO ( PMM_qDebugR_MODE, ("PMM API: CUserValidation::ValidatePassword : SUCCESS - CHECK_MINIMUM_PASSWORD_LENGTH"));
							varPmmStatus = PMM_SUCCESS;
						} else {
							varPmmStatus = PMM_INVALID_PASSWORD;
							LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidatePassword - FAILURE : CHECK_MINIMUM_PASSWORD_LENGTH"));
						}
					} else {
						if ((m_stPolicyDataCurrent->PwdPolicyData.PwrdMinLen <= (SplAlpha + Num + Alpha))) {
							LOG_INFO ( PMM_qDebugR_MODE, ("PMM API: CUserValidation::ValidatePassword : SUCCESS - CHECK_MINIMUM_PASSWORD_LENGTH"));
							varPmmStatus = PMM_SUCCESS;
						} else {
							varPmmStatus = PMM_INVALID_PASSWORD;
							LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidatePassword - FAILURE : CHECK_MINIMUM_PASSWORD_LENGTH"));
						}
					}
					break;
				}
				case CHECK_PASSWORD_ALPHA: {
					LOG_INFO ( PMM_qDebugR_MODE, ("PMM API: CUserValidation::ValidatePassword - CHECK_PASSWORD_ALPHA"));
					// Check for the maximum Alphabets in the password.
					if (m_stPolicyDataCurrent->PwdPolicyData.PwrdAlphabet == ZERO) {
						if (Alpha <= CFR_MAX_MAXPASSWORD_LENGTH) {
							LOG_INFO ( PMM_qDebugR_MODE, ("PMM API: CUserValidation::ValidatePassword : SUCCESS - CHECK_PASSWORD_ALPHA"));
							varPmmStatus = PMM_SUCCESS;
						} else {
							varPmmStatus = PMM_INVALID_PASSWORD;
							LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidatePassword - FAILURE : CHECK_PASSWORD_ALPHA"));
						}
					} else {
						if (m_stPolicyDataCurrent->PwdPolicyData.PwrdAlphabet <= Alpha) {
							LOG_INFO ( PMM_qDebugR_MODE, ("PMM API: CUserValidation::ValidatePassword : SUCCESS - CHECK_PASSWORD_ALPHA"));
							varPmmStatus = PMM_SUCCESS;
						} else {
							varPmmStatus = PMM_INVALID_PASSWORD;
							LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidatePassword - FAILURE : CHECK_PASSWORD_ALPHA"));
						}
					}
					break;
				}
				case CHECK_PASSWORD_SPLALPHA: {
					LOG_INFO ( PMM_qDebugR_MODE, ("PMM API: CUserValidation::ValidatePassword - CHECK_PASSWORD_SPLALPHA"));
					// Check for the Minimum Special characted for the Password.
					if (m_stPolicyDataCurrent->PwdPolicyData.PwrdSplchar == ZERO) {
						if (SplAlpha <= CFR_MAX_MAXPASSWORD_LENGTH) {
							LOG_INFO ( PMM_qDebugR_MODE, ("PMM API: CUserValidation::ValidatePassword : SUCCESS - CHECK_PASSWORD_SPLALPHA"));
							varPmmStatus = PMM_SUCCESS;
						} else {
							varPmmStatus = PMM_INVALID_PASSWORD;
							LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidatePassword - FAILURE : CHECK_PASSWORD_SPLALPHA"));
						}
					} else {
						if (m_stPolicyDataCurrent->PwdPolicyData.PwrdSplchar <= SplAlpha) {
							LOG_INFO ( PMM_qDebugR_MODE, ("PMM API: CUserValidation::ValidatePassword : SUCCESS - CHECK_PASSWORD_SPLALPHA"));
							varPmmStatus = PMM_SUCCESS;
						} else {
							varPmmStatus = PMM_INVALID_PASSWORD;
							LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidatePassword - FAILURE : CHECK_PASSWORD_SPLALPHA"));
						}
					}
					break;
				}
				case CHECK_PASSWORD_NUMERIC: {
					LOG_INFO ( PMM_qDebugR_MODE, ("PMM API: CUserValidation::ValidatePassword - CHECK_PASSWORD_NUMERIC"));
					// Check for the Minimum Numerics in the password.
					if (m_stPolicyDataCurrent->PwdPolicyData.PwrdNumeric == ZERO) {
						if (Num <= CFR_MAX_MAXPASSWORD_LENGTH) {
							LOG_INFO ( PMM_qDebugR_MODE, ("PMM API: CUserValidation::ValidatePassword : SUCCESS - CHECK_PASSWORD_NUMERIC"));
							varPmmStatus = PMM_SUCCESS;
						} else {
							varPmmStatus = PMM_INVALID_PASSWORD;
							LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidatePassword - FAILURE : CHECK_PASSWORD_NUMERIC"));
						}
					} else {
						if (m_stPolicyDataCurrent->PwdPolicyData.PwrdNumeric <= Num) {
							LOG_INFO ( PMM_qDebugR_MODE, ("PMM API: CUserValidation::ValidatePassword : SUCCESS - CHECK_PASSWORD_NUMERIC"));
							varPmmStatus = PMM_SUCCESS;
						} else {
							varPmmStatus = PMM_INVALID_PASSWORD;
							LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidatePassword - FAILURE : CHECK_PASSWORD_NUMERIC"));
						}
					}
					break;
				}
				default: {
					break;
				}
				}
			}
		} else		// if space in the password.
		{
			varPmmStatus = PMM_INVALID_PASSWORD;
			LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidatePassword - FAILURE : Space in password"));
		}
	} else {
		varPmmStatus = PMM_INVALID_PARAMETER;
		LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidatePassword - FAILURE : PMM_INVALID_PARAMETER"));
	}
	return varPmmStatus;
}
//***************************************************************************************
// PMMERROR CUserValidation::ValidateUsername ( QString UserName)
///
/// Verifies the User name against the policy data and returs whether to
///	User name is valid or not.
///
/// @param[in] *UserName - UserName to be verified against the policy.
///
/// @return		PMMERROR - Returns error codes if failed or returns PMM_SUCCESS.
///
/// @todo -
///
//**************************************************************************************
// Revision History
// ************************************************************************************
//
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad
//
//
// ************************************************************************************
//**************************************************************************************
PMMERROR CUserValidation::ValidateUsername(QString pUserName) {
	PMMERROR varPmmStatus = PMM_SUCCESS;
	SHORT space = ZERO;				// Keep the track of number of spaces in username.
	BYTE Alpha = ZERO,				// Keep the track of number of Alphabets in username.
			Num = ZERO,				// Keep the track of number of numerics in username.
			SplAlpha = ZERO,				// Keep the track of number of special characters in username.
			Totalchrs = ZERO;				// Total the user name characters except white spaces.
	LOG_INFO ( PMM_qDebugR_MODE, ("PMM : ----------------------- CUserValidation::ValidateUsername ---------------------"));
	// Check for the Username whether satisfying the policy given.
	// If space is present in Username return invalid Username.
	if (NULL != pUserName) {
		USHORT CheckCondition = 0;
		for (CheckCondition = ZERO; CheckCondition <= (wcslen(pUserName) - 1); CheckCondition++) {
			if (iswalpha(pUserName[CheckCondition])) {
				Alpha++;
			} else if (iswdigit(pUserName[CheckCondition])) {
				Num++;
				//break; //numerical chars allowed fixes CR:2739
			} else if (iswspace(pUserName[CheckCondition])) {
				space++;
				break; //break allowed here as no spaces are allowed
			} else {
				SplAlpha++;
				//break; //special chars allowed
			}
		}
		Totalchrs = Alpha + Num + SplAlpha;
		//Just do not allow if white space is found in user name
		if (!space) {
			for (CheckCondition = CHECK_MAXIMUM_USERNAME_LENGTH;
					((CheckCondition <= CHECK_MINIMUM_USERNAME_LENGTH) && (varPmmStatus == PMM_SUCCESS));
					CheckCondition++) {
				switch (CheckCondition) {
				case CHECK_MAXIMUM_USERNAME_LENGTH: {
					// Check for the Maximum Length of the Username.
					if (m_stPolicyDataCurrent->UserPolicyData.UmaxLen == ZERO) {
						if (Totalchrs <= CFR_MAX_MAXUSER_NAME_LENGTH) {
							LOG_INFO ( PMM_qDebugR_MODE, ("PMM API: CUserValidation::ValidateUsername : SUCCESS - CFR_MAX_MAXUSER_NAME_LENGTH"));
							varPmmStatus = PMM_SUCCESS;
						} else {
							varPmmStatus = PMM_INVALID_USERNAME;
							LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidateUsername - FAILURE : CHECK_MAXIMUM_USERNAME_LENGTH"));
						}
					} else {
						if (m_stPolicyDataCurrent->UserPolicyData.UmaxLen >= Totalchrs) {
							LOG_INFO ( PMM_qDebugR_MODE, ("PMM API: CUserValidation::ValidateUsername : SUCCESS - CFR_MAX_MAXUSER_NAME_LENGTH"));
							varPmmStatus = PMM_SUCCESS;
						} else {
							varPmmStatus = PMM_INVALID_USERNAME;
							LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidateUsername - FAILURE : CHECK_MAXIMUM_USERNAME_LENGTH"));
						}
					}
					break;
				}
				case CHECK_MINIMUM_USERNAME_LENGTH: {
					// Check for the Minimum length of the Username.
					if (m_stPolicyDataCurrent->UserPolicyData.UminLen == ZERO) {
						if (Totalchrs <= CFR_MAX_MAXUSER_NAME_LENGTH) {
							LOG_INFO ( PMM_qDebugR_MODE, ("PMM API: CUserValidation::ValidateUsername : SUCCESS - CHECK_MINIMUM_USERNAME_LENGTH"));
							varPmmStatus = PMM_SUCCESS;
						} else {
							varPmmStatus = PMM_INVALID_USERNAME;
							LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidateUsername - FAILURE : CHECK_MINIMUM_USERNAME_LENGTH"));
						}
					} else {
						if (m_stPolicyDataCurrent->UserPolicyData.UminLen <= Totalchrs) {
							LOG_INFO ( PMM_qDebugR_MODE, ("PMM API: CUserValidation::ValidateUsername : SUCCESS - CHECK_MINIMUM_USERNAME_LENGTH"));
							varPmmStatus = PMM_SUCCESS;
						} else {
							varPmmStatus = PMM_INVALID_USERNAME;
							LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidateUsername - FAILURE : CHECK_MINIMUM_USERNAME_LENGTH"));
						}
					}
					break;
				}
				} //SWITCH ends
			} //FOR loop ends
		} else {
			varPmmStatus = PMM_INVALID_USERNAME;
			LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidateUsername - FAILURE : PMM_INVALID_USERNAME"));
		}
	} else {
		varPmmStatus = PMM_INVALID_PARAMETER;
		LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidateUsername - FAILURE : PMM_INVALID_PARAMETER"));
	}
	return varPmmStatus;
}
//***************************************************************************************
//PMMERROR CUserValidation::GetExpiryDate ( __int64 *ExpiryDate)
///
/// Updates the password Expiry time of the user.
///
/// @param[in out] *ExpiryDate	- Contains the Expiry date field to be updated when a user is
///								 Added.
///
/// @return			PMMERROR	- PMM_SUCCESS.
///
/// @todo						-
///
//**************************************************************************************
// Revision History
// ************************************************************************************
//
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad
//
//
// ************************************************************************************
//**************************************************************************************
PMMERROR CUserValidation::GetExpiryDate(__int64 *pExpiryDate) {
	PMMERROR varPmmStatus = PMM_SUCCESS; // Status of return
	CTVtime time;						// for getting the System time for present.
	LOG_INFO ( PMM_qDebugR_MODE, ("PMM :--------------------- CUserValidation::GetExpiryDate --------------- "));
	if (NULL != pExpiryDate) {
		if (m_stPolicyDataCurrent->PwdPolicyData.expiryDays) {
			LONGLONG PresentTime;				// To hold present time in microSec.
			time.TimeNow();
			PresentTime = time.GetMicroSecs();
			LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::GetExpiryDate %d"), m_stPolicyDataCurrent->PwdPolicyData.expiryDays);
			PresentTime = PresentTime + ((m_stPolicyDataCurrent->PwdPolicyData.expiryDays) * DAYS_IN_MILLI_SEC);
			// Update in the user slot with expiry time.
			*pExpiryDate = PresentTime;
		} else {
			*pExpiryDate = ZERO;
			LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::GetExpiryDate %d"), m_stPolicyDataCurrent->PwdPolicyData.expiryDays);
		}
		//****************** Just for testing.**********************-------------------------------------------------------------
		//	SYSTEMTIME TimeNow;				// getting the present system time.
		//	CTVtime time1 ( PresentTime) ;
		//	time1.GetSYSTEMTIME ( &TimeNow) ;
		//	varPmmStatus = PMM_SUCCESS;
	} else {
		varPmmStatus = PMM_INVALID_PARAMETER;
		LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::GetExpiryDate : FAILED - PMM_INVALID_PARAMETER"));
	}
	return varPmmStatus;
}
//***************************************************************************************
// PMMERROR CUserValidation::ValidateTime ( SHORT slot)
///
/// Checks for the user START time and the END time and verifies that the user
///	is with in the specified time span. If the user tries to login after his
///	time span authentication will be failed.
///
/// @param[in]	slot	- User lConfigurationId of the user in the User data structure.
///
/// @return		PMMERROR- Returns Error code if failed or returns PMM_SUCCESS.
///
/// @todo -
///
//**************************************************************************************
// Revision History
// ************************************************************************************
//
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad
//
//
// ************************************************************************************
//**************************************************************************************
//**************************************************************************************
PMMERROR CUserValidation::ValidateTime(SHORT lslot) {
	PMMERROR varPmmStatus;									// Return status.
	__int64 timeNow;										// To store the present time in microsec.
	CTVtime CurrentTime;									// CTVtime class instantiation
	CurrentTime.TimeNow();								// Get the current system time.
	LOG_INFO ( PMM_qDebugR_MODE, ("PMM :------------------------- CUserValidation::ValidateTime --------------------"));
	CTVtime timeSpan = CurrentTime.GetTimeOfDaySpan();	// Get time span of day.
	timeNow = timeSpan.GetMicroSecs();
	// Check for the time span.
	if ((timeNow >= m_stUserDataCurrent->UserData[lslot].PwdInfo.ValidStartTime)
			&& (timeNow <= m_stUserDataCurrent->UserData[lslot].PwdInfo.ValidEndTime)) {
		LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidateTime : SUCCESS - Valid login time"));
		varPmmStatus = PMM_SUCCESS;
	} else {
		varPmmStatus = PMM_INVALID_LOGIN_TIME;
		LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidateTime - FAILURE : PMM_INVALID_LOGIN_TIME"));
	}
	return varPmmStatus;
}
//***************************************************************************************
// PMMERROR CUserValidation::GetSlotSts ( SHORT *lUserId)
///
/// Checks for the Empty slot for the new User and returns slot found.
///
/// @param[out]	slot	- lUserId of the user.
///
/// @return		PMMERROR- Returns Error code if failed or returns PMM_SUCCESS.
///
/// @todo -
///
//**************************************************************************************
// Revision History
// ************************************************************************************
//
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad
//
//
// ************************************************************************************
//**************************************************************************************
//**************************************************************************************
PMMERROR CUserValidation::GetSlotSts(SHORT *plslot) {
	PMMERROR varPmmStatus = PMM_VALID_SLOT_NOT_FOUND;					// Return status
	SHORT Users;						// Keep track of Slots and to iterate.
	LOG_INFO ( PMM_qDebugR_MODE, ("PMM : ------------------------ CUserValidation::GetSlotSts -------------------"));
	if (NULL != plslot) {
		//PSR - Coverity issue fix --#776852
		// If a valid slot is found Just break.
		for (Users = ZERO; ((Users < MAX_USERS) && (varPmmStatus == PMM_VALID_SLOT_NOT_FOUND));) {
			if (m_stUserDataWorking->UserData[Users].Used) {
				Users++;
				varPmmStatus = PMM_VALID_SLOT_NOT_FOUND;
				LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::GetSlotSts - FAILURE : PMM_VALID_SLOT_NOT_FOUND"));
			} else {
				// Return the slot for the user.
				*plslot = Users;
				LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::GetSlotSts : SUCCESS - PMM_VALID_SLOT_FOUND Slot = %d"), Users);
				varPmmStatus = PMM_VALID_SLOT_FOUND;
				break;
			}
		}
	} else {
		varPmmStatus = PMM_INVALID_PARAMETER;
		LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::GetSlotSts : FAILURE - PMM_INVALID_PARAMETER "));
	}
	return varPmmStatus;
}
//***************************************************************************************
// PMMERROR CUserValidation::CheckUser ( QString Username )
///
/// Checks the given UserName across all the UserName in the UserData and Checks if
///	any duplicate UserName is found, Returns PMM_SUCCESS if User with same name is
///	not found else returns appropriate Error code.
///
/// @param[in]	Username	- UserName to be verified in UserData.
///
/// @return		PMMERROR	- Returns Error code if failed or returns PMM_SUCCESS.
///
/// @todo -
///
//**************************************************************************************
// Revision History
// ************************************************************************************
//
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad
//
// ************************************************************************************
//**************************************************************************************
//**************************************************************************************
PMMERROR CUserValidation::CheckUser(QString pUsername) {
	SHORT Users;						// To iterate and keep track of users.
	PMMERROR varPmmStatus = PMM_SUCCESS;		// Return Value.
	LOG_INFO ( PMM_qDebugR_MODE, (" -----------------PMM : CUserValidation::CheckUser ------------------------------"));
	if (NULL != pUsername) {
		//PSR - Coverity issue fix --#776852 #779578
		for (Users = ZERO; Users < MAX_USERS;) {
			if (!(QString::compare(QString::fromWCharArray(pUsername),
					QString::fromWCharArray(m_stUserDataCurrent->UserData[Users].UsrInfo.Name), Qt::CaseInsensitive)
					== 0)) {
				LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::CheckUser : FAILURE - Duplicate User"));
				varPmmStatus = PMM_DUPLICATE_USER;
				break;
			} else {
				Users++;
			}
		}
	} else {
		varPmmStatus = PMM_INVALID_PARAMETER;
		LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::CheckUser : FAILURE - PMM_INVALID_PARAMETER"));
	}
	return varPmmStatus;
}
//*************************************************************************************
// PMMERROR AddUserData ( USERDATA *UserInfo, SHORT *lUsrID)
///
/// STEP1 : Checks for the valid slot.
///			STEP2 : Checks if user name and password are same.
///			STEP3 : Checks if the User name is "Admin"
///			STEP4 : compare the username in the database to find if any duplicate user is present.
///			STEP5 : Validate the password against the policy data.
///			STEP6 : Validate the Username against the policy data.
///			STEP7 : Update the Expiry time of the user.
///			STEP8 : If all conditions are met then update the userdata with new user.
///			STEP9 : Update the NVRAM Sts bit and retry count to as specified in policy.
///			STEP10: Check if the Added User is of ADMIN group. If User is ADMIN set the
///					Permission mask to TRUE.
///			STEP11: Return the User lUsrID for the user added for further correspondence.
///
/// @param[in]	*UserInfo	- User information to be added to the User data structure if a
///							 valid slot is found and the username and password are
///							 verifed against the policy.
///
/// @param[out] *lUsrID		- ID of the user. Next time any query about this user should be
///							 done by giving the lUsrID returned.
///
/// @return					- The varPmmStatus of the user whether the user is added to the database or not.
///
/// @todo
///
///	@Note	- *UserInfo and *lUsrID Memory should be allocated by the clients and should give the
///			  appropriate details of the user to be added. COMMIT configuration of CMM should be
///			  called in order to update the user in to the Current configuration.
///
//*******************************************************************************************************************
// Revision History
// *****************************************************************************************************************
//
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad
//
//	 2	 V6 Firmware1	 09/27/2004		Shyam Prasad	Check for the User if the user is
//														using the default group permission or the custom and the group
//														permission will be copied to the user permission if the user
//														is using default group permission
//
//	 3	 V6 Firmware1	 01/16/2006		Shyam - At the time of Adduser password will not be validated for the policy,
//										Instead NV flag will be SET which will prompt the user to change the password
//										by returning error code PMM_CHANGE_PASSWORD_FOR_LOGIN during validateLogin.
//										However SetPassword() API can be called and new password entered by user will be
//										validated against the policy data. This will help to retain the password
//										provided as default and "AddUser" API will be successful even if password is
//										not according to policy data.
// ******************************************************************************************************************
//*********************************************************************************************************************
PMMERROR CUserValidation::AddUserData(T_USERDATA *pUserInfo, SHORT *plUsrID) {
#ifdef PWDLOGS_ENABLE
  WCHAR szDbgMsg[512];
#endif
	SHORT slot = NULL;							// Store slot obtained for new user.
	PMMERROR varPmmStatus = PMM_SUCCESS;			// Return value.
	LOG_INFO ( PMM_qDebugR_MODE, ("------------------PMM : CUserValidation::AddUserData --------------- "));
#ifdef PWDLOGS_ENABLE
  swprintf( szDbgMsg, L"CUserVal::AddUserData GTC %d\n", GetTickCount());
  OutputDebugString(szDbgMsg);
#endif
	if (NULL == pUserInfo || NULL == plUsrID) {
		return PMM_INVALID_PARAMETER;
	}
	for (SHORT CheckCondition = GET_SLOT_DETAILS; ((CheckCondition <= INITIALISE) && (varPmmStatus == PMM_SUCCESS));
			CheckCondition++) {
		try {
			switch (CheckCondition) {
			case GET_SLOT_DETAILS: {
				// Get the empty slot for the new user.
				LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::AddUserData - Get the empty slot for new user"));
#ifdef PWDLOGS_ENABLE
  swprintf( szDbgMsg, L"CUserVal::AddUserData-AddUserData - Get the empty slot for new user GTC %d\n", GetTickCount());
  OutputDebugString(szDbgMsg);
#endif
				varPmmStatus = GetSlotSts(&slot);
				if (PMM_VALID_SLOT_FOUND == varPmmStatus) {
					varPmmStatus = PMM_SUCCESS;
					LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::AddUserData - GetSlotSts : SUCCESS"));
#ifdef PWDLOGS_ENABLE
  swprintf( szDbgMsg, L"CUserVal::AddUserData-AddUserData - GetSlotSts : SUCCESS,slot: %d GTC %d\n", slot,GetTickCount());
  OutputDebugString(szDbgMsg);
#endif
				}
				break;
			}
			case CHECK_PASSWORD_USERNAME: {
				// Check whether user name and password is same.
				LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::AddUserData - Check if password and Username are same"));
#ifdef PWDLOGS_ENABLE
  swprintf( szDbgMsg, L"CUserVal::AddUserData-AddUserData -Check if password and Username are same GTC %d\n", GetTickCount());
  OutputDebugString(szDbgMsg);
#endif
				CAuthenticatePwd userName(QString::fromWCharArray(pUserInfo->UsrInfo.Name));
				HASHDWSZ2BU_32 uHash;
				SALTDWSZ2BU_8 uSalt;
				memcpy(uHash.b, pUserInfo->PwdInfo.HSCurrentPwd.Hash, SECUREPWD_HASH_SIZE);
				memcpy(uSalt.b, pUserInfo->PwdInfo.HSCurrentPwd.Salt, SECUREPWD_SALT_SIZE);
				CAuthenticatePwd curPwd(uHash, uSalt);
				//if ( ! ( _wcsicmp ( pUserInfo -> UsrInfo.Name,pUserInfo -> PwdInfo.CurrentPassword) == ZERO) )
				if (!(userName == curPwd)) {
					LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::AddUserData - password and Username are not same"));
					varPmmStatus = PMM_SUCCESS;
				} else {
					varPmmStatus = PMM_USERNAME_PASSWORD_SAME;
					LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::AddUserData : FAILURE - CHECK_PASSWORD_USERNAME - Username and password same"));
				}
				break;
			}
			case CHECK_USER_FOR_ADMIN: {
				// Check username for "Admin"
				LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::AddUserData - Check if username is Admin"));
#ifdef PWDLOGS_ENABLE
  swprintf( szDbgMsg, L"CUserVal::AddUserData-AddUserData -Check if username is Admin GTC %d\n", GetTickCount());
  OutputDebugString(szDbgMsg);
#endif
				if ((QString::compare(QString::fromWCharArray(pUserInfo->UsrInfo.Name), "Admin", Qt::CaseInsensitive))
						== !0) {
					LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::AddUserData - Username is not Admin"));
#ifdef PWDLOGS_ENABLE
  swprintf( szDbgMsg, L"CUserVal::AddUserData-AddUserData - username is not Admin GTC %d\n", GetTickCount());
  OutputDebugString(szDbgMsg);
#endif
					varPmmStatus = PMM_SUCCESS;
				} else {
					varPmmStatus = PMM_INVALID_USERNAME;
					LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::AddUserData : FAILURE - CHECK_USER_FOR_ADMIN"));
				}
				break;
			}
			case CHECK_FOR_DUPLICATE_USER: {
				// Check Username in the user data.
				LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::AddUserData - Check if Username is present in Database"));
#ifdef PWDLOGS_ENABLE
  swprintf( szDbgMsg, L"CUserVal::AddUserData-AddUserData - Check if Username is present in Database GTC %d\n", GetTickCount());
  OutputDebugString(szDbgMsg);
#endif
				varPmmStatus = CheckUser(pUserInfo->UsrInfo.Name);
				break;
			}
			case CHECK_USERNAME: {
				// Validate the username against the policy.
				LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::AddUserData - Validate the Username"));
				varPmmStatus = ValidateUsername(pUserInfo->UsrInfo.Name);
				break;
			}
			case CHECK_USER_PASSWORD: {
				// Validate the password against policy.
				// Shyam Updated - Jan 16th 2006
				//
				// At the time of Adduser password will not be validated for the policy,
				// Instead NV flag will be SET which will prompt the user to change the password
				// by returning error code PMM_CHANGE_PASSWORD_FOR_LOGIN.
				//
				// However SetPassword() API can be called and new password entered by user will be
				// validated against the policy data.
				//
				//
				LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::AddUserData - Validate password"));
				//varPmmStatus = ValidatePassword ( pUserInfo -> PwdInfo.CurrentPassword) ;
				varPmmStatus = PMM_SUCCESS;
				break;
			}
			case CHECK_USER_LEVEL: {
				// Check for the Valid User level to be entered.
				LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::AddUserData - CHECK_USER_LEVEL "));
#ifdef PWDLOGS_ENABLE
  swprintf( szDbgMsg, L"CUserVal::AddUserData-AddUserData - CHECK_USER_LEVEL GTC %d\n", GetTickCount());
  OutputDebugString(szDbgMsg);
#endif
				if (pUserInfo->UsrInfo.UserGroup <= OPERATOR) {
					varPmmStatus = PMM_SUCCESS;
					LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::AddUserData UserGroup - SUCCESS "));
				} else {
					varPmmStatus = PMM_INVALID_GROUP_LEVEL;
					LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::AddUserData UserGroup FAILURE - PMM_INVALID_GROUP_LEVEL "));
				}
				break;
			}
			case UPDATE_USER_DATA: {
				// Update the userdata structure.
				LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::AddUserData - Add user to the database"));
				GetExpiryDate(reinterpret_cast<long*>(&pUserInfo->PwdInfo.ExpireDate));
				// If the Added user is "ADMIN" permission for the "ADMIN" is valid in all Areas.
				// So hardcode the permission of the "Admin" as soon as he is added.
				if ( ADMINISTRATOR == pUserInfo->UsrInfo.UserGroup) {// All the permission are given for "Administrator" group.
					for (SHORT BitMask = ZERO; BitMask < PERM_MASK_SIZE; BitMask++) {
						pUserInfo->PwdInfo.Perm[BitMask] = 0xFFFFFFFF;
					}
					LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::AddUserData - CHECK_USERGROUP = ADMIN"));
#ifdef PWDLOGS_ENABLE
  swprintf( szDbgMsg, L"CUserVal::AddUserData-AddUserData - CHECK_USERGROUP = ADMIN GTC %d\n", GetTickCount());
  OutputDebugString(szDbgMsg);
#endif
				} else {
					// Check if the user being added is using the Default permission.
					// If the user is using the default permission of the group,
					// Copy the group permision to the permission mask of the user.
					if ( TRUE != pUserInfo->UsrInfo.CustomOrDefault) {
						memcpy(pUserInfo->PwdInfo.Perm,
								(char*) &m_stUserDataCurrent->GroupPerm[pUserInfo->UsrInfo.UserGroup],
								(sizeof(DWORD) * PERM_MASK_SIZE));
					}
				}
				memcpy((char*) &m_stUserDataWorking->UserData[slot], (char*) pUserInfo, sizeof(T_USERDATA));
				m_stUserDataWorking->UserData[slot].Used = TRUE;		// Update the status of the slot used.
				LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::AddUserData - User lConfigurationId = %d"), slot);
				*plUsrID = slot + ONESLOT;						// Return the Slot allocated for the User to the client.
#ifdef PWDLOGS_ENABLE
  swprintf( szDbgMsg, L"CUserVal::AddUserData-AddUserData - User lConfigurationId = %d GTC %d\n",slot,GetTickCount());
  OutputDebugString(szDbgMsg);
  swprintf( szDbgMsg, L"CUserVal::AddUserData-AddUserData - Return the Slot allocated for the User to the client = %d GTC %d\n",*plUsrID,GetTickCount());
  OutputDebugString(szDbgMsg);
#endif
				break;
			}
			case INITIALISE: {
				// Initialise the dependent variables.
				// Since "Admin" can add the user to the system, If the recorder is in CFR mode or in Non CFR mode
				// when user tries to login Change password for next login Error code will be returned.
				LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::AddUserData - INITIALISE"));
#ifdef PWDLOGS_ENABLE
  swprintf( szDbgMsg, L"CUserVal::AddUserData-AddUserData - INITIALISE GTC %d\n",GetTickCount());
  OutputDebugString(szDbgMsg);
#endif
				m_stLogDetails[slot].LoginCount = ZERO;			// Login count of the User to ZERO.
				m_stLogDetails[slot].LastLoginTime = ZERO;
				m_stNVData->RetryCount[slot] = m_stPolicyDataCurrent->PwdPolicyData.MaxRetry; // NVRAM Retry count to be Reset.
				m_stNVData->PwdExpirySts[slot] = TRUE;
				break;
			}
			default: {
				break;
			}
			}
		} catch (...) {
			varPmmStatus = PMM_FAILED;
			LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::AddUserData FAILED : - Exception Block"));
		}
	}
	return varPmmStatus;
}
//***************************************************************************************
// PMMERROR CUserValidation::CheckPwrdHistoryAndUpdate ( SHORT lUserId, QString NewPassword)
///
/// Checks the user password history and current password against the new password
///	and updates the new password if not found in history.
///
/// @param[in]	lUserId		- User lUserId of the user.
///
/// @param[in]	NewPassword	- Password to be checked against the password history and if
///							 successful update the new password to the user information
///
/// @return		PMMERROR	- Returns SUCCESS or Error code if a error has occured.
///
/// @todo -
///
//**************************************************************************************
// Revision History
// ************************************************************************************
//
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad
//
//
// ************************************************************************************
//**************************************************************************************
PMMERROR CUserValidation::CheckPwrdHistoryAndUpdate(SHORT lUserId, QString pNewPassword) {
#ifdef PWDLOGS_ENABLE
  WCHAR szDbgMsg[512];
#endif
	PMMERROR varPmmStatus = PMM_SUCCESS;		// Return value.
	if (NULL != pNewPassword) {
		LOG_INFO ( PMM_qDebugR_MODE, ("PMM : ------------------------CUserValidation::CheckPwrdHistoryAndUpdate - ---------------------------------"));
		SHORT size;							// To obtain the size of the password history.
		SHORT MaxPassWordInHistory;
		if (m_stPolicyDataCurrent->PwdPolicyData.PreviousPwd) {
			// Get the size of password history to be copied on to temporary location.
			size = sizeof(m_stUserDataCurrent->UserData[lUserId - 1].PwdInfo.Password[ZERO])
					* (m_stPolicyDataCurrent->PwdPolicyData.PreviousPwd);
			MaxPassWordInHistory = m_stPolicyDataCurrent->PwdPolicyData.PreviousPwd - 1;
			LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::CheckPwrdHistoryAndUpdate "));
#ifdef PWDLOGS_ENABLE
  swprintf( szDbgMsg, L"CUserValidation::CheckPwrdHistoryAndUpdate: size of password history %d GTC %d\n",size,GetTickCount());
  OutputDebugString(szDbgMsg);
  swprintf( szDbgMsg, L"CUserValidation::CheckPwrdHistoryAndUpdate: no. of passwords in history %d GTC %d\n",MaxPassWordInHistory,GetTickCount());
  OutputDebugString(szDbgMsg);
#endif
		} else {
			//	If the number of history passwords to be saved is given as '0'
			//	in policy file allocate memory for 1 passwords to be saved.
			size = sizeof(m_stUserDataCurrent->UserData[lUserId - 1].PwdInfo.Password[ZERO]); // * (CFRMAX_PREVIOUS_PASSWORD - 1);
			MaxPassWordInHistory = 1; //CFRMAX_PREVIOUS_PASSWORD - 1;
		}
		// Check for the new password against the history of the password.
#ifdef PWDLOGS_ENABLE
  swprintf( szDbgMsg, L"CUserValidation::CheckPwrdHistoryAndUpdate: Check for the new password against the history of the password. GTC %d\n",GetTickCount());
  OutputDebugString(szDbgMsg);
#endif
		TV_BOOL bAddToHistory = TRUE;
		if (0 == QString::compare(QString::fromWCharArray(pNewPassword), "password")) {
			bAddToHistory = FALSE;
		}
		for (SHORT CheckPassword = ZERO; (CheckPassword <= MaxPassWordInHistory) && (varPmmStatus == PMM_SUCCESS);
				CheckPassword++) {
#ifdef PWDLOGS_ENABLE
  swprintf( szDbgMsg, L"CUserValidation::CheckPwrdHistoryAndUpdate: Password %d == %s GTC %d\n",CheckPassword,&m_stUserDataCurrent -> UserData[lUserId - ONESLOT].PwdInfo.HSPassword[CheckPassword],GetTickCount());
  OutputDebugString(szDbgMsg);
  swprintf( szDbgMsg, L" CUserValidation::CheckPwrdHistoryAndUpdate: total size %d GTC %d\n",size,GetTickCount());
  OutputDebugString(szDbgMsg);
  swprintf( szDbgMsg, L" CUserValidation::CheckPwrdHistoryAndUpdate: size %d GTC %d\n",sizeof (m_stUserDataCurrent -> UserData[lUserId-1].PwdInfo.HSPassword[ZERO]),GetTickCount());
  OutputDebugString(szDbgMsg);
#endif
			HASHDWSZ2BU_32 uHash;
			SALTDWSZ2BU_8 uSalt;
			memcpy(uHash.b, m_stUserDataCurrent->UserData[lUserId - ONESLOT].PwdInfo.HSPassword[CheckPassword].Hash,
			SECUREPWD_HASH_SIZE);
			memcpy(uSalt.b, m_stUserDataCurrent->UserData[lUserId - ONESLOT].PwdInfo.HSPassword[CheckPassword].Salt,
			SECUREPWD_SALT_SIZE);
			CAuthenticatePwd cPwd(uHash, uSalt);
			CAuthenticatePwd nwPwd(QString::fromWCharArray(pNewPassword), uSalt);
			//if ( ! ( _wcsicmp ( m_stUserDataCurrent -> UserData[lUserId - ONESLOT].PwdInfo.Password[CheckPassword],pNewPassword) ) )
			if (cPwd == nwPwd) {
				varPmmStatus = PMM_DUPLICATE_PASSWORD_IN_HISTORY;
				LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::CheckPwrdHistoryAndUpdate - FAILED : PMM_DUPLICATE_PASSWORD_IN_HISTORY"));
#ifdef PWDLOGS_ENABLE
  swprintf( szDbgMsg, L"CUserValidation::CheckPwrdHistoryAndUpdate: FAILED : PMM_DUPLICATE_PASSWORD_IN_HISTORY GTC %d\n",GetTickCount());
  OutputDebugString(szDbgMsg);
#endif
			} else {
				LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::CheckPwrdHistoryAndUpdate - Checking for password in password history"));
#ifdef PWDLOGS_ENABLE
  swprintf( szDbgMsg, L"CUserValidation::CheckPwrdHistoryAndUpdate: FAILED : Checking for password in password history GTC %d\n",GetTickCount());
  OutputDebugString(szDbgMsg);
#endif
				varPmmStatus = PMM_SUCCESS;
			}
		}
		// Allocate temporary location for storing the password history.
		if (PMM_DUPLICATE_PASSWORD_IN_HISTORY != varPmmStatus) {
			if (bAddToHistory != FALSE) {
				BYTE *PasswordHistory = NULL;	// Temp buffer for the History of the passwords.
				LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::CheckPwrdHistoryAndUpdate - Allocate memory for storing password history."));
				PasswordHistory = (BYTE*) LocalAlloc(LMEM_ZEROINIT, size);
				// Copy all the password history data to the allocated memory.
				if (NULL != PasswordHistory) {
					if (m_stPolicyDataCurrent->PwdPolicyData.PreviousPwd != ZERO) {
						// Copy the Current password on to the password allocated location.
						memcpy(PasswordHistory,
								&m_stUserDataCurrent->UserData[lUserId - ONESLOT].PwdInfo.HSPassword[ZERO],
								sizeof(m_stUserDataCurrent->UserData[lUserId - ONESLOT].PwdInfo.HSPassword[ZERO])
										* MaxPassWordInHistory);
						// Copy the New password as the current password for the user.
						LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::CheckPwrdHistoryAndUpdate - Update the New password to Current password"));
						CAuthenticatePwd newAuthPwd(QString::fromWCharArray(pNewPassword));
						HASHDWSZ2BU_32 uHash;
						SALTDWSZ2BU_8 uSalt;
						newAuthPwd.getHash(uHash);
						newAuthPwd.getSalt(uSalt);
						memcpy(m_stUserDataWorking->UserData[lUserId - 1].PwdInfo.HSCurrentPwd.Hash, uHash.b,
								sizeof(uHash));
						memcpy(m_stUserDataWorking->UserData[lUserId - 1].PwdInfo.HSCurrentPwd.Salt, uSalt.b,
								sizeof(uSalt));
						// Copy the new Current password as the First password history.
						memcpy(m_stUserDataWorking->UserData[lUserId - ONESLOT].PwdInfo.HSPassword[ZERO].Hash, uHash.b,
								sizeof(uHash));
						memcpy(m_stUserDataWorking->UserData[lUserId - ONESLOT].PwdInfo.HSPassword[ZERO].Salt, uSalt.b,
								sizeof(uSalt));
						//// Copy all the password history by incrementing History slot by 1.
						memcpy(&m_stUserDataWorking->UserData[lUserId - ONESLOT].PwdInfo.HSPassword[ONESLOT],
								PasswordHistory, size);
						//memcpy ( m_stUserDataWorking -> UserData[lUserId-1].PwdInfo.CurrentPassword,
						//		pNewPassword,
						//		sizeof ( m_stUserDataCurrent -> UserData[lUserId - ONESLOT].PwdInfo.Password[ZERO]) ) ;
						//// Copy the new Current password as the First password history.
						//memcpy ( ( char*) m_stUserDataWorking -> UserData[lUserId - ONESLOT].PwdInfo.Password[ZERO],
						//		pNewPassword,
						//		sizeof ( m_stUserDataCurrent -> UserData[lUserId - ONESLOT].PwdInfo.Password[ZERO]) ) ;
						//
						//// Copy all the password history by incrementing History slot by 1.
						//memcpy ( m_stUserDataWorking -> UserData[lUserId - ONESLOT].PwdInfo.Password[ONESLOT],
						//		PasswordHistory,
						//		size) ;
					}
					// If no password history has to be stored then just make a copy of newpassword.
					else {
						CAuthenticatePwd newAuthPwd(QString::fromWCharArray(pNewPassword));
						HASHDWSZ2BU_32 uHash;
						SALTDWSZ2BU_8 uSalt;
						newAuthPwd.getHash(uHash);
						newAuthPwd.getSalt(uSalt);
						memcpy(m_stUserDataWorking->UserData[lUserId - ONESLOT].PwdInfo.HSCurrentPwd.Hash, uHash.b,
								sizeof(uHash));
						memcpy(m_stUserDataWorking->UserData[lUserId - ONESLOT].PwdInfo.HSCurrentPwd.Salt, uSalt.b,
								sizeof(uSalt));
						// Copy the new Current password as the First password history.
						memcpy(m_stUserDataWorking->UserData[lUserId - ONESLOT].PwdInfo.HSPassword[ZERO].Hash, uHash.b,
								sizeof(uHash));
						memcpy(m_stUserDataWorking->UserData[lUserId - ONESLOT].PwdInfo.HSPassword[ZERO].Salt, uSalt.b,
								sizeof(uSalt));
						//memcpy ( m_stUserDataWorking -> UserData[lUserId-1].PwdInfo.CurrentPassword,
						//		pNewPassword,
						//		sizeof ( m_stUserDataCurrent -> UserData[lUserId - ONESLOT].PwdInfo.Password[ZERO]) ) ;
						//
						//// Copy the new Current password as the First password history.
						//memcpy ( ( char*) m_stUserDataWorking -> UserData[lUserId - ONESLOT].PwdInfo.Password[ZERO],
						//		pNewPassword,
						//		sizeof ( m_stUserDataCurrent -> UserData[lUserId - ONESLOT].PwdInfo.Password[ZERO]) ) ;
					}
					// Free the temp allocated memory for the Password history.
					if (PasswordHistory) {
						delete (PasswordHistory);
						PasswordHistory = NULL;
						LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::CheckPwrdHistoryAndUpdate - Free memory "));
					}
					// Reset the password expiry.
					LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::CheckPwrdHistoryAndUpdate - Update the Expiry time since password is changed"));
					//stamp the expiry time after new password change
					GetExpiryDate(
							reinterpret_cast<long*>(&m_stUserDataWorking->UserData[lUserId - ONESLOT].PwdInfo.ExpireDate));
				} else {
					varPmmStatus = PMM_INSUFFICIENT_MEMORY;
					LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::CheckPwrdHistoryAndUpdate - PMM_INSUFFICIENT_MEMORY "));
				}
			} else {
				CAuthenticatePwd newAuthPwd(QString::fromWCharArray(pNewPassword));
				HASHDWSZ2BU_32 uHash;
				SALTDWSZ2BU_8 uSalt;
				newAuthPwd.getHash(uHash);
				newAuthPwd.getSalt(uSalt);
				memcpy(m_stUserDataWorking->UserData[lUserId - 1].PwdInfo.HSCurrentPwd.Hash, uHash.b, sizeof(uHash));
				memcpy(m_stUserDataWorking->UserData[lUserId - 1].PwdInfo.HSCurrentPwd.Salt, uSalt.b, sizeof(uSalt));
				/*memcpy ( m_stUserDataWorking -> UserData[lUserId-1].PwdInfo.CurrentPassword,
				 pNewPassword,
				 sizeof ( m_stUserDataCurrent -> UserData[lUserId - ONESLOT].PwdInfo.Password[ZERO]) ) ;			*/
				GetExpiryDate(
						reinterpret_cast<long*>(&m_stUserDataWorking->UserData[lUserId - ONESLOT].PwdInfo.ExpireDate));
			}
		}
	} else {
		varPmmStatus = PMM_INVALID_PARAMETER;
		LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::CheckPwrdHistoryAndUpdate - PMM_INSUFFICIENT_MEMORY "));
	}
	return varPmmStatus;
}
//***************************************************************************************
//PMMERROR CUserValidation::ResetAccount ( SHORT lUserId,QString NewPassword,TV_BOOL Resetpassword)
///
/// Checks the user password history and current password against the new password
///	and updates the new password if not found in history.
///
/// @param[in]	lUserId		 - Id of the user.
///
/// @param[in]	NewPassword	 - New Password to be Updated.
///
/// @param[in]	Resetpassword - Whether the the new password has to be set as new current
///								password or to give the user one more chance to enter the
///								same old password.
///
/// @return		PMMERROR	 - Returns Error code if failed or PMM_SUCCESS.
///
/// @todo -
///
/// @note - COMMIT configuration of CMM has to be called to update the Change to the current
///			section of configuration.
///
//**************************************************************************************
// Revision History
// ************************************************************************************
//
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad
//
//	 2	 V6 Firmware1	 4/15/2006		Shyam Prasad	- Allow user to reset his password
//										only if that user is not login.
// ************************************************************************************
//**************************************************************************************
PMMERROR CUserValidation::ResetAccount(SHORT lUserId, QString pNewPassword, TV_BOOL Resetpassword) {
	PMMERROR varPmmStatus;		// Return value.
	LOG_INFO ( PMM_qDebugR_MODE, ("PMM : ------------------------------ CUserValidation::ResetAccount ----------------------"));
	if (NULL == pNewPassword) {
		return PMM_INVALID_PARAMETER;
		LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ResetAccount : FAILURE - PMM_INVALID_PARAMETER"));
	}
	if ((lUserId - ONESLOT) < MAX_USERS) 								// Checks whether the UserId is valid or not.
	{	//Change to Current
		try {
			if (m_stUserDataCurrent->UserData[lUserId - ONESLOT].Used) 	// Checks Whether the Slot is in use or not.
			{
				LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ResetAccount - Slot is in Use"));
				// Shyam - Added a condition to check if the user is login,
				// if user is login do not allow his password to be reset.
				if (!m_stLogDetails[lUserId - ONESLOT].LoginCount) {
					if (Resetpassword) {
						if ((QString::compare(QString::fromWCharArray(pNewPassword),
								QString::fromWCharArray(m_stUserDataCurrent->UserData[lUserId - ONESLOT].UsrInfo.Name),
								Qt::CaseSensitive) == ZERO)) {
							//varPmmStatus = ValidatePassword ( pNewPassword) ;	// Validate the Password against the Policy data present.
							varPmmStatus = PMM_SUCCESS;
						} else {
							varPmmStatus = PMM_INVALID_PASSWORD;
							LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ResetAccount - FAILURE - PMM_INVALID_PASSWORD"));
						}
						if (PMM_SUCCESS == varPmmStatus) {
							LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ResetAccount - New password validated"));
							varPmmStatus = CheckPwrdHistoryAndUpdate(lUserId, pNewPassword);
							//------------------ NVRAM Updates and reset retries and passwrd sts bit is SET.----------------------------------------
							if (PMM_SUCCESS == varPmmStatus) {
								LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ResetAccount - Checked password history and password not found in history"));
								// Indicates user should change his password on next login.
								m_stNVData->PwdExpirySts[lUserId - ONESLOT] = TRUE;
								// Reset the count to max retry once password has been validated.
								m_stNVData->RetryCount[lUserId - ONESLOT] =
										m_stPolicyDataCurrent->PwdPolicyData.MaxRetry;
								// Update the User login datails reset the Login count and Last login time..
								m_stLogDetails[lUserId - ONESLOT].LastLoginTime = ZERO;
								m_stLogDetails[lUserId - ONESLOT].LoginCount = ZERO;
							}
						}
					} else {
						// Increment the count of the password retry for giving the user one more retry;
						m_stNVData->RetryCount[lUserId - ONESLOT]++;
						varPmmStatus = PMM_SUCCESS;
						LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ResetAccount - SUCCESS - Give one more chance to login"));
					}
				} else {
					// Should come here only if user is currently logged-in and
					// trying to reset his own password.
					return PMM_FAILED;
				}
			} else {
				varPmmStatus = PMM_INVALID_USER_ID;
				LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ResetAccount - FAILED : PMM_INVALID_USER_ID"));
			}
		} catch (...) {
			varPmmStatus = PMM_FAILED;
			LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ResetAccount FAILED- Exception"));
		}
	} else {
		varPmmStatus = PMM_INVALID_USER_ID;
		LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ResetAccount - FAILED : PMM_INVALID_USER_ID"));
	}
	return varPmmStatus;
}
//***************************************************************************************
// PMMERROR CUserValidation::UseNewSetupFromCMM ( DWORD ConfigId)
///
/// Gets the Working and current pointers of the User data and policy data of
///	the configuartion loaded.Check the policy obtained against the hardcoded
///	policy.
///
/// @param[in]	ConfigId	- Configuration to obtain new configuration from CMM.
///
/// @todo -
///
//**************************************************************************************
// Revision History
// ************************************************************************************
//
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad
//
//
// ************************************************************************************
//**************************************************************************************
PMMERROR CUserValidation::UseNewSetupFromCMM(DWORD lConfigId) {
	PMMERROR varPmmStatus = PMM_SUCCESS;			// Return status
	POLICY_STATUS policySts;						// to get the policy error status.
	BOOL validatePolicy = FALSE;
	LOG_INFO ( PMM_qDebugR_MODE, ("PMM :---------------------------- CUserValidation::UseNewSetupFromCMM - -------------------------------"));
	// If a valid configId is obtained form the Client Get all the
	// Working and the Current pointers from the CMM and Store the
	// ConfigID in the Global variable for the Future use.
	if (lConfigId) {
		for (SHORT CheckConditions = GET_POINTERS;
				((CheckConditions <= RESET_NVRAM_PMM_CONFIG) && (varPmmStatus == PMM_SUCCESS)); CheckConditions++) {
			try {
				switch (CheckConditions) {
				case GET_POINTERS: {
					// Get Current and Working pointers of User data and policy data.
					LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::UseNewSetupFromCMM - Get Userdata and policy data Current and working from CMM"));
					varPmmStatus = GetWorkingCurrentPointers(lConfigId);
					break;
				}
				case CHECK_POLICY: {
					// Check policy against the Hardcoded policy data.
					LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::UseNewSetupFromCMM - Check for the policy data"));
					policySts = CheckPolicy(m_Mode);
					varPmmStatus = GetPolicyError(policySts);
					if (PMM_INVALID_POLICY_DATA == varPmmStatus) {
						varPmmStatus = PMM_SUCCESS;
						validatePolicy = TRUE;
					}
					break;
				}
				case RESET_NVRAM_PMM_CONFIG: {
					// Reset all the NVRAM data since configuration is new.
					LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::UseNewSetupFromCMM - Reset NVRAM details for New setup"));
					varPmmStatus = ResetNVData( TRUE);
					break;
				}
				default: {
					break;
				}
				}
			} catch (...) {
				varPmmStatus = PMM_FAILED;
				LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::UseNewSetupFromCMM FAILED - Exception handler"));
			}
		}
		if ((PMM_SUCCESS == varPmmStatus) && (TRUE == validatePolicy))
			varPmmStatus = PMM_INVALID_POLICY_DATA;
	} else {
		varPmmStatus = PMM_INVALID_CONFIGURATION_ID;
		LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::UseNewSetupFromCMM - FAILED : PMM_INVALID_CONFIGURATION_ID"));
	}
	return varPmmStatus;
}
//***************************************************************************************
//PMMERROR CUserValidation::ValidateBackDoorUser ( QString UserName,QString Password,SHORT *lUserId)
///
/// Invokes the Backdoor user algorithm and checks against the username and password.
///	Authenticates if the generated username and password are same as entered by user.
///
/// @param[in]	 *UserName	-	Username to be verified.
///
/// @param[in]	 *Password	-	password to be verified.
///
///	@param[out]	 *lUserId	-	Returns the lUserId of the Backdoor user if username and
///								password is authenticated.
///
/// @return		 PMMERROR	-	Returns PMM_BACKDOOR_USER_AUTHENTICATED if authenticated
///								or failure.
///
/// @todo -
///
//**************************************************************************************
// Revision History
// ************************************************************************************
//
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad
//
//
// ************************************************************************************
//**************************************************************************************
PMMERROR CUserValidation::ValidateBackDoorUser(QString pUserName, QString pPassword, SHORT *plUserId) {
	if ((NULL == pUserName) || (NULL == pPassword) || (NULL == plUserId)) {
		return PMM_INVALID_PARAMETER;
		LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidateBackDoorUser - FAILED : PMM_INVALID_PARAMETER"));
	}
	PMMERROR varPmmStatus;					// Return value
	USHORT lday,							// To store the day from system time.
			lmonth,							// To store the month from system time.
			lyear,							// To store the year from system time.
			lBackDoorSts;					// To store the status of Backdoor user
	CTVtime SystemTime;						// Invoke time routines.
	LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidateBackDoorUser - BackDoor user algo invoked"));
	long b_User,							// Convert username to long.
			b_Password;						// Convert Password to long.
	// Convert user name and password in long format.
	b_User = static_cast<long>(wcstol(pUserName, nullptr, 10));
	b_Password = static_cast<long>(wcstol(pPassword, nullptr, 10));
	// to store the system time.
	SYSTEMTIME Gettime;
	SystemTime.TimeNow();
	SystemTime.GetSYSTEMTIME(&Gettime);
	// Get the Day Month and Year in USHORT format.
	lday = (USHORT) Gettime.wDay;
	lmonth = (USHORT) Gettime.wMonth;
	lyear = ((USHORT) Gettime.wYear & 0x000F);
	// Validate the backdoor user and password.
	if ((NULL != b_User) || (NULL != b_Password)) {
		CPWBackCoder BackDoorUser;			// Invoke
		lBackDoorSts = BackDoorUser.Validate(m_SerialNumber, lday, lmonth, lyear, b_User, b_Password);
		if ( PWBD_OKAY == lBackDoorSts) {
			LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidateBackDoorUser - BackDoor user Authenticated"));
			// Update the UserId for the Back door user.
			*plUserId = BACKDOOR_USER_ID;
			varPmmStatus = PMM_BACKDOOR_USER_AUTHENTICATED;
		} else {
			varPmmStatus = PMM_FAILED;
			LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidateBackDoorUser  FAILED "));
		}
	} else {
		varPmmStatus = PMM_FAILED;
		LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidateBackDoorUser  FAILED "));
	}
	return varPmmStatus;
}
//***************************************************************************************
// PMMERROR CUserValidation::ValidateExpiryWarning ( SHORT UserId)
///
/// validates the expiry warning of the user. If the expiry waring is been
///	activated retuns the appropriate error code or returns SUCCESS,
///
/// @param[in] UserId	 -	ID of the user.
///
/// @return		PMMERROR -	returns whether the warning is activated for the user or not.
///
/// @todo -
///
//**************************************************************************************
// Revision History
// ************************************************************************************
//
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad
//
//
// ************************************************************************************
//**************************************************************************************
PMMERROR CUserValidation::ValidateExpiryWarning(SHORT lUserId) {
	PMMERROR varPmmStatus;					// Return status.
	LOG_INFO ( PMM_qDebugR_MODE, ("PMM : --------------------------CUserValidation::ValidateExpiryWarning ---------------------------------"));
	if (m_stPolicyDataCurrent->PwdPolicyData.expiryDays != ZERO) {
		if (m_stPolicyDataCurrent->PwdPolicyData.expiryWarning) {
			LONGLONG PresentTime;					// Present system time in millisec.
			LONGLONG DaysinMilliSec;				// Added Warning time to check the time limit for password expiry.
			CTVtime time;							// Invoke time routines.
			LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidateExpiryWarning - Expiry warning : %d"), m_stPolicyDataCurrent->PwdPolicyData.expiryWarning);
			time.TimeNow();
			// Get the present day time in microseconds.
			PresentTime = time.GetMicroSecs();
			DaysinMilliSec = (m_stUserDataCurrent->UserData[lUserId].PwdInfo.ExpireDate
					- (m_stPolicyDataCurrent->PwdPolicyData.expiryDays * DAYS_IN_MILLI_SEC));
			DaysinMilliSec = DaysinMilliSec
					+ ((m_stPolicyDataCurrent->PwdPolicyData.expiryDays
							- m_stPolicyDataCurrent->PwdPolicyData.expiryWarning) * DAYS_IN_MILLI_SEC);
			if (DaysinMilliSec > PresentTime) {
				LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidateExpiryWarning - SUCCESS : Expiry not activated"));
				varPmmStatus = PMM_SUCCESS;
			} else {
				varPmmStatus = PMM_WARNING_ACTIVATED;
				LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidateExpiryWarning  FAILED - PMM_WARNING_ACTIVATED"));
			}
		} else {
			varPmmStatus = PMM_SUCCESS;
			LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidateExpiryWarning :SUCCESS"));
		}
	} else {
		varPmmStatus = PMM_SUCCESS;
		LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidateExpiryWarning :SUCCESS"));
	}
	return varPmmStatus;
}
//***************************************************************************************
// PMMERROR CUserValidation::UpdateLogDetails ( SHORT UserCount,TV_BOOL DayOrExpiry)
///
/// Checks for the Expiry of the password or Verifies Whether the user is allowed
///	on the day by checking against the day mask. Updates the Class variables and
///	NVRAM details.
///
/// @param[in] UserId		-	Id of the User
///
/// @param[in] DayOrExpiry	-	Indicates whether to Check for the day mask or Expiry time.
///
/// @return		PMMERROR	-	returns the status of the Userdata whether the user is
///								is valid or not. returns the PMM_SUCCESS or PMM_FAILED.
///
/// @todo -
///
//**************************************************************************************
// Revision History
// ************************************************************************************
//
//  1  V6 Firmware1	 06/23/2004		Shyam Prasad
//
//	 2	 V6 Firmware1	 09/27/2004		Shyam prasad	"Admin" group day mask
//														 should not be checked.
// ************************************************************************************
//**************************************************************************************
PMMERROR CUserValidation::UpdateLogDetails(SHORT UserId, TV_BOOL DayOrExpiry) {
	PMMERROR varPmmStatus;
	LOG_INFO ( PMM_qDebugR_MODE, ("PMM ----------------------------- CUserValidation::UpdateLogDetails------------------------"));
	// Get the System time when the user is login and check against the Expiry time to validate the user.
	SYSTEMTIME TimeNow;
	CTVtime time;
	__int64 TestExpiryTime;
	// Get the present time of the system.
	time.TimeNow();
	time.GetSYSTEMTIME(&TimeNow);
	// Check for the Expiry time of the User against the Calculated expiry time for the User.
	TestExpiryTime = time.GetMicroSecs();
	if (DayOrExpiry) {
		if (m_stPolicyDataCurrent->PwdPolicyData.expiryDays) {
			LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::UpdateLogDetails - Check for the Expiry time"));
			if (TestExpiryTime < m_stUserDataCurrent->UserData[UserId].PwdInfo.ExpireDate) {
				LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::UpdateLogDetails - SUCCESS Password not expired"));
				varPmmStatus = PMM_SUCCESS;
			} else							// Indicates the user that the Password is expired.
			{
				LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::UpdateLogDetails - PMM_PASSWORD_EXPIRED "));
				varPmmStatus = PMM_PASSWORD_EXPIRED;
			}
		} else {
			varPmmStatus = PMM_SUCCESS;
		}
	} else {
		LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::UpdateLogDetailsAndNVRAM - Check for the day mask"));
		// If the user is "ADMIN" group day mask should not be checked.
		// "ADMIN" group should be allowed all the day irrespective of the day mask present in the UserData.
		if ( ADMINISTRATOR != m_stUserDataWorking->UserData[UserId].UsrInfo.UserGroup) {
			if (((m_stUserDataWorking->UserData[UserId].PwdInfo.DayOfWeekMask >> (TimeNow.wDayOfWeek)) & 0x01)) //- 1) ) & 0x01) )
			{
				LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::UpdateLogDetailsAndNVRAM - SUCCESS : VALID_LOGIN_DAY"));
				varPmmStatus = PMM_SUCCESS;
			} else {
				varPmmStatus = PMM_INVALID_LOGIN_DAY;
				LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::UpdateLogDetailsAndNVRAM - FAILED : PMM_INVALID_LOGIN_DAY"));
			}
		} else {
			varPmmStatus = PMM_SUCCESS;
		}
	}
	return varPmmStatus;
}
//*******************************************************************************************
// PMMERROR ValidateUserLogon ( QString UserName, QString Password, SHORT *lUserId)
///
/// Validates the user against the policy data present.
///				STEP1 : Checks whether the user is First time. If user is first time user
///						checks for the status of first time user to be validated or not.
///				STEP2 : Checks the Username against the policy data.
///				STEP3 : Checks the password against the policy data.
///				STEP4 : Checks the user for the day mask.
///				STEP5 : Checks for the login time.
///				STEP6 : Checks for the Access level of the user.
///				STEP7 : Checks whether the password account is locked or not.
///				STEP8 : Checks if the user has entered the warning period or not.
///				STEP9 : Checks whether the password is not expired and updates the NVRAM details.
///				STEP10 :If the user is not present in the user database then invoke
///						the BackDoor user algorithm.
///
/// @param[in]	*UserName - Username to be validated.
///
/// @param[in]	*Password - Password to be validated.
///
/// @param[out] *UserId	 - Id of the user.
///
/// @return		PMMERROR -	returns SUCCESS if all the conditions are satisfied.
///							Appropriate Error codes if the user authentication is failed.
///
/// @todo	-
//*******************************************************************************************
//*******************************************************************************************
// Revision History
// *****************************************************************************************
//
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad
//
//	 2	 V6 Firmware1	 1/16/2006		Shyam - Checks for the Username and password against
//										the policy information is commented, If the policy data
//										changes users configured for the previous policy will
//										be allowed to login and any changes to the policy after
//										the user has been added will come into effect once user
//										has changed his password.
// *****************************************************************************************
//*******************************************************************************************
PMMERROR CUserValidation::ValidateUserLogon(QString pUserName, QString pPassword, SHORT *plUserId) {
#ifdef PWDLOGS_ENABLE
  WCHAR szDbgMsg[512];
#endif
	PMMERROR varPmmStatus = PMM_FAILED;		// Return status
	BOOL UsrSts = FALSE;				// To keep track of user is present in User data or not
	BOOL PwdSts = FALSE;				// To keep track of password to be changed in the login.
	SHORT expirySts = FALSE;				// To keep track of Password expiry warning.
	//coverity fix expirySts = FALSE h350726 CID :768839
	LOG_INFO ( PMM_qDebugR_MODE, ("PMM ------------------------CUserValidation::ValidateUserLogon ---------------------------"));
	if ((NULL == pUserName) || (NULL == pPassword) || (NULL == plUserId)) {
		return PMM_INVALID_PARAMETER;
		LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidateUserLogon : FAILED - PMM_INVALID_PARAMETER"));
	}
#ifdef PWDLOGS_ENABLE
  swprintf( szDbgMsg, L"CUserVal::ValidateUserLogOn User %s Pwd %s GTC %d\n", pUserName, pPassword, GetTickCount());
  OutputDebugString(szDbgMsg);
#endif
	// Check for the First time User if User name is "Admin" and
	// Password is "No Password" and the status bit in NVRAM for
	// the first time User is SET.
	if (((QString::compare(QString::fromWCharArray(pUserName), "Admin") == ZERO)
			&& (QString::compare(QString::fromWCharArray(pPassword), "") == ZERO))) {
		if (m_stNVData->FirstTimeUser) {
			LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidateUserLogon - First time user Authenticated"));
			*plUserId = FIRST_TIME_USER_ID;
			varPmmStatus = PMM_FIRST_TIME_USER_AUTHENTICATED;
#ifdef PWDLOGS_ENABLE
  swprintf( szDbgMsg, L"CUserVal::ValidateUserLogOn First Time User GTC %d\n", GetTickCount());
  OutputDebugString(szDbgMsg);
#endif
		} else {
			LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidateUserLogon - FAILURE : PMM_FIRST_TIME_USER_NOT_AUTHENTICATED"));
			varPmmStatus = PMM_FIRST_TIME_USER_NOT_AUTHENTICATED;
#ifdef PWDLOGS_ENABLE
  swprintf( szDbgMsg, L"PMM : CUserValidation::ValidateUserLogon - FAILURE : PMM_FIRST_TIME_USER_NOT_AUTHENTICATED GTC %d\n", GetTickCount());
  OutputDebugString(szDbgMsg);
#endif
		}
	} else {
		LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidateUserLogon - Check for First time User Failed"));
		varPmmStatus = PMM_FAILED;
#ifdef PWDLOGS_ENABLE
  swprintf( szDbgMsg, L"PMM : CUserValidation::ValidateUserLogon - Check for First time User Failed GTC %d\n", GetTickCount());
  OutputDebugString(szDbgMsg);
#endif
	}
	/// indexOf the User and the password in the UserData structure.
	SHORT UserCount = ZERO;
	for (UserCount = ZERO; ((UserCount <= (MAX_USERS - 1)) && (varPmmStatus == PMM_FAILED)); UserCount++) {
		if (m_stUserDataCurrent->UserData[UserCount].Used) {
			varPmmStatus = PMM_SUCCESS;
			BYTE UserRetryCount = 0, UserPwdSts = 0;
			for (SHORT CheckCondition = VALIDATE_USERNAME;
					((CheckCondition <= VALIDATE_EXPIRY_TIME) && (varPmmStatus == PMM_SUCCESS)); CheckCondition++) {
				try {
					switch (CheckCondition) {
					case VALIDATE_USERNAME: {
						// Validate the username if present in user database.
						LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidateUserLogon - Validate User name"));
#ifdef PWDLOGS_ENABLE
  swprintf( szDbgMsg, L"PMM : CUserValidation::ValidateUserLogon - Validate User name GTC %d\n", GetTickCount());
  OutputDebugString(szDbgMsg);
#endif
						if (!(QString::compare(QString::fromWCharArray(pUserName),
								QString::fromWCharArray(m_stUserDataCurrent->UserData[UserCount].UsrInfo.Name)))) {
							*plUserId = UserCount + ONESLOT;
							UsrSts = TRUE; //user found in the database
							if (m_stPolicyDataCurrent->PwdPolicyData.MaxRetry) {
								if (m_stNVData->RetryCount[UserCount]) {
									m_stNVData->RetryCount[UserCount]--;
									varPmmStatus = PMM_SUCCESS;
								} else {
									varPmmStatus = PMM_USER_ACCESS_LOCKED;
									LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidateUserLogon - PMM_USER_ACCESS_LOCKED"));
#ifdef PWDLOGS_ENABLE
    swprintf( szDbgMsg, L"PMM : CUserValidation::ValidateUserLogon - PMM_USER_ACCESS_LOCKED GTC %d\n", GetTickCount());
    OutputDebugString(szDbgMsg);
#endif
								}
							} else {
								varPmmStatus = PMM_SUCCESS;
							}
						} else {
							UsrSts = FALSE;
							varPmmStatus = PMM_FAILED;
							LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidateUserLogon - FAILURE : PMM_INVALID_USERNAME"));
#ifdef PWDLOGS_ENABLE
  swprintf( szDbgMsg, L"PMM : CUserValidation::ValidateUserLogon - FAILURE : PMM_INVALID_USERNAME GTC %d\n", GetTickCount());
  OutputDebugString(szDbgMsg);
#endif
						}
						break;
					}
					case VALIDATE_PASSWORD: {
						// Validate the Password against the policy data.
						LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidateUserLogon - Validate Password"));
#ifdef PWDLOGS_ENABLE
  swprintf( szDbgMsg, L"PMM : CUserValidation::ValidateUserLogon - Validate Password GTC %d\n", GetTickCount());
  OutputDebugString(szDbgMsg);
#endif
						/*	if ( FALSE == m_Mode )		// Check if the recorder is running in NonCFR mode
						 {
						 if ( ! ( wcsicmp ( pPassword,m_stUserDataCurrent -> UserData[UserCount].PwdInfo.CurrentPassword) ) )
						 {
						 varPmmStatus = ValidatePassword ( m_stUserDataCurrent -> UserData[UserCount].PwdInfo.CurrentPassword) ;
						 }
						 else
						 {
						 varPmmStatus = PMM_FAILED;
						 LOG_ERROR ( PMM_qDebugR_MODE, ( "PMM : CUserValidation::ValidateUserLogon - FAILURE : PMM_INVALID_PASSWORD") ) )
						 }
						 }
						 else
						 {
						 */
						HASHDWSZ2BU_32 uHash;
						SALTDWSZ2BU_8 uSalt;
						memcpy(uHash.b, m_stUserDataCurrent->UserData[UserCount].PwdInfo.HSCurrentPwd.Hash,
						SECUREPWD_HASH_SIZE);
						memcpy(uSalt.b, m_stUserDataCurrent->UserData[UserCount].PwdInfo.HSCurrentPwd.Salt,
						SECUREPWD_SALT_SIZE);
						CAuthenticatePwd curPwd(uHash, uSalt);
						CAuthenticatePwd pPwd(QString::fromWCharArray(pPassword), uSalt);
#ifdef PWDLOGS_ENABLE
  CString sUserHash(_T(""));
  bool bRet =CAuthenticatePwd::hashToHexString(uHash, sUserHash);
  CString sUserSalt(_T(""));
  bRet=CAuthenticatePwd::saltToHexString( uSalt, sUserSalt);
  swprintf( szDbgMsg, L"CUserValidation::ValidateUserLogon - pwd Hash hex string : %s GTC %d\n",sUserHash, GetTickCount());
  OutputDebugString(szDbgMsg);
  swprintf( szDbgMsg, L"CUserValidation::ValidateUserLogon - pwd Salt hex string : %s GTC %d\n",sUserSalt, GetTickCount());
  OutputDebugString(szDbgMsg);
  swprintf( szDbgMsg, L"PMM : CUserValidation::ValidateUserLogon - secure Password hash %s, salt %s GTC %d\n",uHash.b, uSalt.b, GetTickCount());
  OutputDebugString(szDbgMsg);
#endif
						//if ( ! ( wcscmp ( pPassword,m_stUserDataCurrent -> UserData[UserCount].PwdInfo.CurrentPassword) ) )
						if ((curPwd == pPwd)) {
							//varPmmStatus = ValidatePassword ( m_stUserDataCurrent -> UserData[UserCount].PwdInfo.CurrentPassword) ;
							varPmmStatus = PMM_SUCCESS;
						} else {
							varPmmStatus = PMM_INVALID_PASSWORD;
							LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidateUserLogon - FAILURE : PMM_INVALID_PASSWORD"));
#ifdef PWDLOGS_ENABLE
  swprintf( szDbgMsg, L"PMM : CUserValidation::ValidateUserLogon - FAILURE : PMM_INVALID_PASSWORD GTC %d\n", GetTickCount());
  OutputDebugString(szDbgMsg);
#endif
						}
						break;
					}
					case VALIDATE_DAY_MASK: {
						// Validate for the present day permission
						LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidateUserLogon - Check for day mask"));
						varPmmStatus = UpdateLogDetails(UserCount, FALSE);
						break;
					}
					case VALIDATE_LOGIN_TIME: {
						// If admin is the user then the time check should not be done.
						// Check for the timespan of login for user.
						LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidateUserLogon - Validate Login time"));
						if ( ADMINISTRATOR != m_stUserDataCurrent->UserData[UserCount].UsrInfo.UserGroup) {
							varPmmStatus = ValidateTime(UserCount);
						} else {
							varPmmStatus = PMM_SUCCESS;
						}
						break;
					}
					case VALIDATE_ACCESS_LEVEL: {
						// Check for the user access level is allowed or not.
						LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidateUserLogon - Validate Access level"));
						if (m_stUserDataCurrent->UserData[UserCount].UsrInfo.UserGroup
								<= m_stLoginUsersInfo.AccessLevel) {
							varPmmStatus = PMM_SUCCESS;
						} else {
							varPmmStatus = PMM_USER_LEVEL_DISALLOWED;
							LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidateUserLogon - FAILURE : PMM_USER_LEVEL_DISALLOWED"));
						}
						break;
					}
					case VALIDATE_PASSWORD_RETRY_COUNT: {
						// Check for the user whether his account is locked or not.
						LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidateUserLogon - Check retry count of Password"));
#ifdef PWDLOGS_ENABLE
  swprintf( szDbgMsg, L"PMM : CUserValidation::ValidateUserLogon - Check retry count of Password GTC %d\n", GetTickCount());
  OutputDebugString(szDbgMsg);
#endif
						if ((m_stNVData->PwdExpirySts[UserCount])) {
							PwdSts = TRUE;
						}
						break;
					}
					case VALIDATE_EXPIRY_WARNING: {
						// Check if the warning for changing the password is activated or not.
						LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidateUserLogon - Check Expiry warning"));
						varPmmStatus = ValidateExpiryWarning(UserCount);
						if (varPmmStatus == PMM_WARNING_ACTIVATED) {
							expirySts = TRUE;
							varPmmStatus = PMM_SUCCESS;
							LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidateUserLogon - Waring activated"));
						} else {
							expirySts = FALSE;
							LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidateUserLogon - Waring not activated"));
						}
						break;
					}
					case VALIDATE_EXPIRY_TIME: {
						// Check whether the password is expired or not.
						// Update the last login time and login count and reset the NVRAM retry count to max.
						LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidateUserLogon - Check Expiry Time"));
						varPmmStatus = UpdateLogDetails(UserCount, TRUE);
						if (PMM_SUCCESS == varPmmStatus) {
							CTVtime time;
							__int64 TestExpiryTime;
							// Get the present time of the system.
							time.TimeNow();
							// Check for the Expiry time of the User against the Calculated expiry time for the User.
							TestExpiryTime = time.GetMicroSecs();
							m_stLogDetails[UserCount].LastLoginTime = TestExpiryTime;
							// Count of login is maintained for each user.
							m_stLogDetails[UserCount].LoginCount++;
						}
						break;
					}
					default: {
						break;
					}
					}  //SWITCH CLOSE
				}  //TRY CLOSE
				catch (...) {
					varPmmStatus = PMM_FAILED;
					LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidateUserLogon - Exception block"));
				}
			}  // user validation FOR loop end
			if (UsrSts) {
				if ((PMM_FAILED == varPmmStatus) || (PMM_USER_ACCESS_LOCKED == varPmmStatus)
						|| (PMM_INVALID_PASSWORD == varPmmStatus)) {
					// If policy states that the Maximum retry is unlimited PMM_USER_ACCESS_LOCKED
					// code will not be returned.
					// If policy states maximum retry and if all the chances for retries are tried
					// Then Locked out option is returned.
					if (m_stPolicyDataCurrent->PwdPolicyData.MaxRetry != ZERO) {
						if ( ZERO == m_stNVData->RetryCount[UserCount]) {
							varPmmStatus = PMM_USER_ACCESS_LOCKED;
						}
					}
				} else {
					// Will come here only if username and password is correct, for any other case like password expired,
					// password warning, invalid login time retry count will not be decremented.
					m_stNVData->RetryCount[UserCount] = m_stPolicyDataCurrent->PwdPolicyData.MaxRetry;
				}
				break;	//break out the main user loop, we have found a user and his status
			}
		} else {
			varPmmStatus = PMM_FAILED;
			LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidateUserLogon - Slot not in Use"));
		}
	}	//user database For loop end
	// Check for the expiry warning and Expiry time if both are validated return the warning activated.
	if (PMM_SUCCESS == varPmmStatus) {
		if (expirySts) {
			varPmmStatus = PMM_WARNING_ACTIVATED;
			LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidateUserLogon - PMM_WARNING_ACTIVATED"));
		}
		if (PwdSts) {
			varPmmStatus = PMM_CHANGE_PASSWORD_FOR_LOGIN;
			// Count of login is decremented if password change is required.
			if (m_stLogDetails[UserCount].LoginCount > ZERO)
				m_stLogDetails[UserCount].LoginCount--;
			LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidateUserLogon - PMM_CHANGE_PASSWORD_FOR_LOGIN"));
		}
	} else if ((varPmmStatus != PMM_FIRST_TIME_USER_NOT_AUTHENTICATED) && (!UsrSts)
			&& (varPmmStatus != PMM_FIRST_TIME_USER_AUTHENTICATED)) {
		LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::ValidateUserLogon - Invoke Backdoor user algorithm"));
		//*************** Invoke Back door Password Algorithm ********************//
		varPmmStatus = ValidateBackDoorUser(pUserName, pPassword, plUserId);
	}
	return varPmmStatus;
}
//***************************************************************************************
// PMMERROR CUserValidation::logoffUser ( SHORT lUserId)
///
/// An internal count is maintained number of times the user has login since
///	user can login using different sources.When the internal count is ZERO then
///	the user is complatly logout of the system.
///
/// @param[in]	lUserId	 -	lUserId of the user.
///
/// @return		PMMERROR -	returns the appropriate error code if failed or PMM_SUCCESS.
///
/// @todo -
///
//**************************************************************************************
// Revision History
// ************************************************************************************
//
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad
//
//
// ************************************************************************************
//**************************************************************************************
PMMERROR CUserValidation::logoffUser(SHORT lUserId) {
	PMMERROR varPmmStatus = PMM_SUCCESS;
	LOG_INFO ( PMM_qDebugR_MODE, ("PMM ---------------------------------- CUserValidation::logoffUser ------------------- "));
	// Check if the user is a special user.
	if (lUserId > MAX_USERS) {
		return PMM_SUCCESS;
	}
	if (m_stUserDataCurrent->UserData[lUserId - ONESLOT].Used) {
		LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::logoffUser - Slot is in Use"));
		// Check whether the User has login or not.
		if (m_stLogDetails[lUserId - ONESLOT].LoginCount) {
			LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::logoffUser - Login Count : %d"), m_stLogDetails[lUserId
					- 1].LoginCount);
			// If login Then Decrement the User count since the user can
			// login into the System through different sources.
			m_stLogDetails[lUserId - ONESLOT].LoginCount--;
			varPmmStatus = PMM_SUCCESS;
		} else {
			// Return the varPmmStatus of the User that the user has not
			// login to the system only.
			varPmmStatus = PMM_USER_NOT_LOGIN;
			LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::logoffUser - Login Count - PMM_USER_NOT_LOGIN"));
		}
	} else {
		varPmmStatus = PMM_INVALID_USER_ID;
		LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::logoffUser : PMM_INVALID_USER_ID"));
	}
	return varPmmStatus;
}
//***************************************************************************************
// PMMERROR CUserValidation::SetUserPassword ( SHORT lUserId,QString NewPassword,QString OldPassword)
///
/// Changes the password of the user if password is valid password.
///			STEP1 : Checks the password against the policy.
///			STEP2 : Updates the previous password to password history.
///			STEP3 : resets the expiry time of the user.
///
/// @param[in]	lUserId		 -	lUserId of the user.
///
///	@param[in]	*NewPassword -	New password to be changed for the user specifed.
///	@param[in]	*OldPassword -	Old password of the user.
///
/// @return		PMMERROR	 -	returns the appropriate error code if failed
///								or returns PMM_SUCCESS.
///
/// @todo -
//**************************************************************************************
// Revision History
// ************************************************************************************
//
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad
//
// ************************************************************************************
//**************************************************************************************
PMMERROR CUserValidation::SetUserPassword(SHORT lUserId, QString pNewPassword, QString pOldPassword) {
	WCHAR szDbgMsg[512];
	PMMERROR varPmmStatus = PMM_SUCCESS;
	CTVtime SystemTime;
	LOG_INFO ( PMM_qDebugR_MODE, ("PMM ------------------------------------ CUserValidation::SetPassword --------------------------------------"));
	if ((NULL == pNewPassword)) // || (NULL ==pOldPassword) //test removed to allow a new password to be set by PW net sync without the old password
	{
		return PMM_INVALID_PARAMETER;
		LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::SetPassword - PMM_INVALID_PARAMETER"));
	}
	if (m_stUserDataCurrent->UserData[lUserId - ONESLOT].Used /*&&
	 m_stNVData -> RetryCount[lUserId - ONESLOT] > 0*/) {
		LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::SetPassword - Valid user is obtained"));
#ifdef PWDLOGS_ENABLE
  swprintf( szDbgMsg, L"PMM : CUserValidation::ValidateUserLogon - SetPassword - Valid user is obtained %d GTC %d\n",m_stUserDataCurrent->UserData[lUserId - ONESLOT].Used, GetTickCount());
  OutputDebugString(szDbgMsg);
#endif
		// Check whether the old password is same as in user database.
		try {
			HASHDWSZ2BU_32 uHash;
			SALTDWSZ2BU_8 uSalt;
			memcpy(uHash.b, m_stUserDataCurrent->UserData[lUserId - ONESLOT].PwdInfo.HSCurrentPwd.Hash,
			SECUREPWD_HASH_SIZE);
			memcpy(uSalt.b, m_stUserDataCurrent->UserData[lUserId - ONESLOT].PwdInfo.HSCurrentPwd.Salt,
			SECUREPWD_SALT_SIZE);
			CAuthenticatePwd curPwd(uHash, uSalt);
			CAuthenticatePwd oldPwd(QString::fromWCharArray(pOldPassword), uSalt);
			//if ( (NULL == pOldPassword) || (! ( _wcsicmp ( pOldPassword,m_stUserDataCurrent -> UserData[lUserId - ONESLOT].PwdInfo.CurrentPassword) ) ) )
			if ((NULL == pOldPassword) || (oldPwd == curPwd)) {
				LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::SetPassword - SUCCESS : Password Verified against current password"));
				// Validate the new password against the policy data.
				varPmmStatus = ValidatePassword(pNewPassword);
				if (PMM_SUCCESS == varPmmStatus) {
					LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::SetPassword - SUCCESS : Password Validated"));
					// Check if the new password is in password history or not.
					// Update the NVRAM status bit and retry count of the user.
					varPmmStatus = CheckPwrdHistoryAndUpdate(lUserId, pNewPassword);
					if (PMM_SUCCESS == varPmmStatus) {
						LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::SetPassword - SUCCESS : Verified password History"));
						m_stNVData->PwdExpirySts[lUserId - ONESLOT] = FALSE;
						m_stNVData->RetryCount[lUserId - ONESLOT] = m_stPolicyDataCurrent->PwdPolicyData.MaxRetry;
					}
				}
			} else {
				varPmmStatus = PMM_INVALID_OLD_PASSWORD;
				LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::SetPassword - FAILURE : PMM_INVALID_OLD_PASSWORD"));
			}
		} catch (...) {
			varPmmStatus = PMM_FAILED;
			LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::SetPassword FAILED - Exception block"));
		}
	} else {
		varPmmStatus = PMM_INVALID_USER_ID;
		LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CUserValidation::SetPassword - FAILURE : PMM_INVALID_USER_ID"));
	}
	return varPmmStatus;
}
//***************************************************************************************
// PMMERROR CUserValidation::QueryStateOfPMM ( SYSTEMSTATE *SystemState)
///
/// Will return information on current password system state
///	Total number of logged in users ( unique users) Current access level.
///
/// @param[out] *SystemState -	returns the system status to the client.
///
/// @return		PMMERROR	 -	Returns Error codes if fails or retuns PMM_SUCCESS.
///
/// @todo -
//**************************************************************************************
// Revision History
//**************************************************************************************
//
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad
//
//
//**************************************************************************************
//**************************************************************************************
PMMERROR CUserValidation::QueryStateOfPMM(SYSTEMSTATE *pstSystemState) {
	PMMERROR varPmmStatus;
	SHORT Count = ZERO;
	LOG_INFO ( PMM_qDebugR_MODE, ("PMM : --------------------------CUserValidation::QueryStateOfPMM -----------------------------------"));
	// Update the Access level and the Count of number of users login in to the System.
	if (NULL != pstSystemState) {
		pstSystemState->AccessLevel = m_stLoginUsersInfo.AccessLevel;
		// Get the count of number of users have login to the sstem.
		for (SHORT Users = ZERO; Users < MAX_USERS; Users++) {
			if (m_stLogDetails[Users].LoginCount) {
				// Counts the number of users login at present.
				Count++;
			}
		}
		// If any Users have login then update the Count value.
		if (Count) {
			LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::QueryStateOfPMM - Users login count : %d"), Count);
			LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::QueryStateOfPMM - Users login count : %d"), pstSystemState->AccessLevel);
			pstSystemState->LoginUsersCount = (BYTE) Count;
			varPmmStatus = PMM_SUCCESS;
		} else {
			pstSystemState->LoginUsersCount = (BYTE) Count;
			varPmmStatus = PMM_NO_USERS_LOGIN;
			LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::QueryStateOfPMM - No Users login count = %d"), Count);
		}
	} else {
		varPmmStatus = PMM_INVALID_PARAMETER;
		LOG_INFO ( PMM_qDebugR_MODE, ("PMM : CUserValidation::QueryStateOfPMM FAILURE : PMM_INVALID_PARAMETER"));
	}
	return varPmmStatus;
}
//***************************************************************************************
// PMMERROR CUserValidation::FirstTimeUser ( TV_BOOL Enable)
///
/// Updates the NVRAM entry as given by the API.
///			if Enable SET ( TRUE)  - Indicates the First time user allowed.
///					RESET ( FALSE) - Indicates the First time user not aloowed.
///
/// @param[in]	Enable		-	Enable or diable First time user.
///
/// @return		PMMERROR	-	Returns Success.
///
/// @todo -
///
//**************************************************************************************
// Revision History
// ************************************************************************************
//
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad
//
//
// ************************************************************************************
//**************************************************************************************
PMMERROR CUserValidation::FirstTimeUser(TV_BOOL Enable) {
	PMMERROR varPmmStatus;
	LOG_INFO ( PMM_qDebugR_MODE, ("PMM :--------------------------------- CUserValidation::FirstTimeUser --------------------------------"));
	// If the Enable is TRUE then allow the first time user else
	// do not allow First time user to the system.
	if (NULL != m_stNVData) {
		m_stNVData->FirstTimeUser = Enable;
		varPmmStatus = PMM_SUCCESS;
		LOG_INFO ( PMM_qDebugR_MODE, ("PMM :CUserValidation::FirstTimeUser : ENABLE first time user"));
	} else {
		varPmmStatus = PMM_INVALID_SRAM_HANDLE;
		LOG_INFO ( PMM_qDebugR_MODE, ("PMM :CUserValidation::FirstTimeUser : FAILED : PMM_INVALID_SRAM_HANDLE"));
	}
	return PMM_SUCCESS;
}
//*********************************************************************************************
// PMMERROR CPasswordManager::DaysForPasswordExpiry ( SHORT UserId, WORD *Days )
///
/// Calculates the Number of remaining days for password to be expired.
///
/// @param[in]	UserId		- Id of the user.
///
/// @param[out]	*Days		- Days remaining for password to be expired.
///
/// @return		PMMERROR	- Returns PMM_SUCCESS if Successful else returns appropriate
///							 Error code.
///
/// @todo -
///
/// @Note - Memory for the WORD *Days should be allocated from client and pointer to the
///			allocated memory should be passed.
//**********************************************************************************************
//**********************************************************************************************
// Revision History
//**********************************************************************************************
//
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad
//
//
//**********************************************************************************************
//**********************************************************************************************
PMMERROR CUserValidation::DaysForPasswordExpiry(SHORT UserId, WORD *pDays) {
	PMMERROR varPmmStatus;
	LOG_INFO ( PMM_qDebugR_MODE, ("PMM -------------------------- CPasswordManager::DaysForPasswordExpiry -------------------------------"));
	try {
		if (m_stUserDataCurrent->UserData[UserId - ONESLOT].Used) {
			if (NULL != pDays) {
				__int64 TimeNow;
				CTVtime time;
				time.TimeNow();
				// Get the present system time;
				TimeNow = time.GetMicroSecs();
				if (m_stPolicyDataCurrent->PwdPolicyData.expiryDays) {
					// Get the remaining time in milli seconds.
					TimeNow = m_stUserDataCurrent->UserData[UserId - ONESLOT].PwdInfo.ExpireDate - TimeNow;
					if (TimeNow > ZERO) {
						// Convert the time in milliseconds to days.
						*pDays = (WORD) (TimeNow / DAYS_IN_MILLI_SEC);
						varPmmStatus = PMM_SUCCESS;
					} else {
						varPmmStatus = PMM_PASSWORD_EXPIRED;
						LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CPasswordManager::DaysForPasswordExpiry : PMM_PASSWORD_EXPIRED "));
					}
				} else {
					*pDays = ZERO;
					varPmmStatus = PMM_SUCCESS;
				}
			} else {
				varPmmStatus = PMM_INVALID_PARAMETER;
				LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CPasswordManager::DaysForPasswordExpiry : PMM_INVALID_PARAMETER "));
			}
		} else {
			varPmmStatus = PMM_INVALID_USER_ID;
			LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CPasswordManager::DaysForPasswordExpiry : PMM_INVALID_USER_ID "));
		}
	} catch (...) {
		LOG_ERROR ( PMM_qDebugR_MODE, ("PMM : CPasswordManager::DaysForPasswordExpiry : Exception block "));
		varPmmStatus = PMM_FAILED;
	}
	return varPmmStatus;
}
//*********************************************************************************************
// void CUserValidation::ReCalExpireDate()
// ::::ReCalculates the Expire Date when policy is changed::::
// When password change is done, the expire date is calculated based on the recorder's current configuration of "expiry date" in .
// And this is done in "Getexpiredate" function. But the need of recalculation for expire date rises, when the user changes the
// "expiry date" configuration in recorder after successfull login. In "Getexpiredate" function, the expire date is calculated
// on current configuration but now we need to do the calculation depending on working configuration, such that the expiry warning's
// will be popped up properly.
//
/// @param[in]	void
///
/// @param[out]	void
///
/// @return		void
///
/// @Does - Loops through all slots of users which are been used, such that recalculation
/// happens for the expire date according to the new policy changed with respect to Expire Date.
///Fix for 1-12FATJZ
//**********************************************************************************************
//**********************************************************************************************
// Revision History
//**********************************************************************************************
//
//  1  V6 Firmware1	 3/28/2014		Durgaprasad
//
//
//**********************************************************************************************
//**********************************************************************************************
void CUserValidation::ReCalculateExpireDate() {
	for (SHORT UserCount = ZERO; UserCount < MAX_USERS; UserCount++) {
		if (m_stUserDataCurrent->UserData[UserCount].Used) {
			if (m_stPolicyDataCurrent->PwdPolicyData.expiryDays > m_stPolicyDataWorking->PwdPolicyData.expiryDays)
				m_stUserDataWorking->UserData[UserCount].PwdInfo.ExpireDate -=
						(m_stPolicyDataCurrent->PwdPolicyData.expiryDays
								- m_stPolicyDataWorking->PwdPolicyData.expiryDays) * DAYS_IN_MILLI_SEC;
			else if (m_stPolicyDataCurrent->PwdPolicyData.expiryDays < m_stPolicyDataWorking->PwdPolicyData.expiryDays)
				m_stUserDataWorking->UserData[UserCount].PwdInfo.ExpireDate +=
						(m_stPolicyDataWorking->PwdPolicyData.expiryDays
								- m_stPolicyDataCurrent->PwdPolicyData.expiryDays) * DAYS_IN_MILLI_SEC;
		}
	}
}

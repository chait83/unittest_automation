/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Password
/// @n Filename: PWBackCoder.h
/// @n Desc:	 Generates and validates the backdoor username and password allowing 
///				 temporary access to recorder if user locked out
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  3 Stability Project 1.0.1.1 7/2/2011 4:59:59 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  2 Stability Project 1.0.1.0 7/1/2011 4:27:44 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  1 V6 Firmware 1.0 2/9/2006 3:29:43 PM Andy Kassell  
// $
//
// ****************************************************************
#ifndef __PWBACKCODER_H__
#define __PWBACKCODER_H__
#define		PWBD_USER_LEN	4				///< Max length of Username
#define		PWBD_USER_MAX	9999			///< Max value of username
#define		PWBD_PASS_LEN	5				///< Max length of password
#define		PWBD_PASS_MAX	99999			///< Max value of password
#define		PWBD_OKAY				0		///< BackDoor Password okay
#define		PWBD_VAL_USER_FAILED	1		///< Validation of username failed
#define		PWBD_VAL_PASS_FAILED	2		///< Validation of password failed
#define		PWBD_ERR_INVALID_DAY	10		///< Invalid day, outside 1-31
#define		PWBD_ERR_INVALID_MONTH	11		///< Invalid month, outside 1-12
#define		PWBD_ERR_INVALID_YEAR	12		///< Invalid year, outside 00-99
#define		PWBD_ERR_INVALID_SERIAL	13		///< Invalid serial number , outside 100000 - 999999
#define		PWBD_ERR_INVALID_USER	14		///< Invalid user, larger then PWBD_USER_MAX
#define		PWBD_ERR_INVALID_PASS	15		///< Invalid pass, larger then PWBD_PASS_MAX
#define		PWBD_MAX_SERIAL			999999	///< Max value of serial Number
#define		PWBD_MIN_SERIAL			100000	///< Min value of serial Number
//**Class*********************************************************************
///
/// @brief Backdoor coder generation and validation
/// 
/// This class will generate / validate the backdoor password for the V6 recorder
/// A password and username will be checked/generated using the serial number and 
/// current date to providing information unique to every recorder and expriring
/// every day.
///
//****************************************************************************
class CPWBackCoder {
public:
//	CPWBackCoder();
	///@todo AK, Add constructor.
	///@todo AK, Add support to detect numnber of logins.
	///@todo AK, Add an automated test function.
	USHORT Generate(long serialNumber, USHORT day, USHORT month, USHORT year, TCHAR *puser, TCHAR *ppass);///< Generate password and username
	USHORT Validate(long serialNumber, USHORT day, USHORT month, USHORT year, long user, long pass);///< Validate password and username
private:
	long m_userName;		///< Username Held as Number
	long m_password;		///< Password Held as Number
	USHORT m_timesUsed;		///< Number of times the backdoor username and password has been used
	USHORT m_day;			///< Day to base password and username on, 1-31
	USHORT m_month;			///< Month to base password and username on, 1-12
	USHORT m_year;			///< Year to base password and username on, 0-99
	long m_serialNumber;	///< Serial Number to base password and username on, 100000 to 999999
private:
	USHORT SetDate(USHORT day, USHORT month, USHORT year);	///< Set and validate the date.
	USHORT SetSerial(long serialNumber);						///< Set and validate the serial number.
	void GenerateUser();										///< Generate the username value (not string)
	void GeneratePassword();									///< Generate the password value (not string)
};
#endif // __PWBACKCODER_H__

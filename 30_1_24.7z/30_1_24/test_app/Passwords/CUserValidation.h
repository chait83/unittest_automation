/// @file CUserValidation.h
/// *************************************************************************************
/// © Honeywell Trendview
/// *************************************************************************************
/// @n Module	:	 Password Management Module.
/// @n Filename	:	 CUserValidation.h
/// @n Desc		:	 Functions Definitions of the core functionality of
///					 the Password management module
///
// *************************************************************************************
// Revision History
// *************************************************************************************
// $Log[1]:
//  6 Stability Project 1.3.1.1 7/2/2011 4:56:27 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
// $Log" for functions
// $
//
// **************************************************************************************
/******************************************************************************************
 COPYRIGHT (c) 2004
 HONEYWELL INC.,
 ALL RIGHTS RESERVED
 This software is a copyrighted work and/or information protected
 as a trade secret. Legal rights of Honeywell Inc. in this
 software is distinct from ownership of any medium in which the
 software is embodied. Copyright or trade secret notices included
 must be reproduced in any copies authorized by Honeywell Inc.
 The information in this software is subject to change without
 notice and should not be considered as a commitment by Honeywell
 Inc.
 ******************************************************************************************/
#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_CUSERVALIDATION_40D6CBF2031C_INCLUDED
#define _INC_CUSERVALIDATION_40D6CBF2031C_INCLUDED
#include "CPasswordManager.h"
#include "PMMglobal.h"
#include "V6Config.h"
//******************************************************
// CUserValidation
///
/// @brief Implements the C style API functions
/// 
/// CUserValidation acts as the core service layer and is 
///	derived from CPasswordManager and CPolicyDataManager class
///	which implements the functionalities of the exposed
/// C style APIs.
//******************************************************
#include "CPolicyDataManager.h"
class CUserValidation: public CPasswordManager, public CPolicyDataManager {
public:
	CUserValidation();
	~CUserValidation();
	PMMERROR RemoveUserData(SHORT);
	PMMERROR ResetAccount(SHORT, WCHAR*, TV_BOOL);
	PMMERROR UseNewSetupFromCMM(DWORD);
	PMMERROR ValidateUserLogon(WCHAR*, WCHAR*, SHORT*);
	PMMERROR logoffUser(SHORT);
	PMMERROR SetUserPassword(SHORT, WCHAR*, WCHAR*);
	PMMERROR QueryStateOfPMM(SYSTEMSTATE*);
	PMMERROR FirstTimeUser(TV_BOOL);
	PMMERROR InitialisePMM(TV_BOOL, DWORD, ULONG, TV_BOOL, void*);
	PMMERROR AddUserData(T_USERDATA*, SHORT*);
	PMMERROR ResetAllUserData(DWORD);
	PMMERROR DaysForPasswordExpiry(SHORT, WORD*);
	PMMERROR ValidatePassword(WCHAR*);
	//Fix for 1-12FATJZ Durgaprasad
	void ReCalculateExpireDate();
private:
	PMMERROR ValidateUsername(WCHAR*);
	PMMERROR ValidateTime(SHORT);
	PMMERROR GetWorkingCurrentPointers(DWORD);
	PMMERROR GetExpiryDate(__int64*);
	PMMERROR GetCMMError(CMMERROR);
	PMMERROR CheckPwrdHistoryAndUpdate(SHORT, WCHAR*);
	PMMERROR UpdateExpiryTime(SHORT);
	PMMERROR ValidateBackDoorUser(WCHAR*, WCHAR*, SHORT*);
	PMMERROR ValidateExpiryWarning(SHORT);
	PMMERROR UpdateLogDetails(SHORT, TV_BOOL);
	PMMERROR GetHandle(void*);
	PMMERROR ResetNVData(TV_BOOL);
	PMMERROR GetSlotSts(SHORT*);
	PMMERROR CheckUser(WCHAR*);
};
#endif 

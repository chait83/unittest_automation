/// @file PasswordInterfaceManager.cpp
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Client password Interface
/// @n Filename:	PasswordInterfaceManager.cpp
/// @n Description: Implementation file for the Class that provides information of
///					the policy data for the clients requesting the services. 
///					Some of the calls to PMM has been wrapped up in CPWI class.
///
/// @todo - __SHOW_MESSAGE Macro will be removed once CPWI is integrated with V6Desktop.
///			Need to do the changes as given below :
///			UnComment	-	V6globals.h
///			Comment		-	MessageListServices.h
///			Remove		-	#define __SHOW_MESSAGE
///			Messages needs to be moved to string table once the messages are fixed and integrated with V6Desktop.
///			Messages are temporarily hardcoded in the code.
///
/// @note - Message asprintf	-	Client - Username - Message
///						Ex	-	Client - FTP testUser Login Successful. 
///								Client - FTP testUser Login Failed. 
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 32	Stability Project 1.27.1.3	7/2/2011 4:59:37 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 31	Stability Project 1.27.1.2	7/1/2011 4:38:35 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 30	Stability Project 1.27.1.1	3/17/2011 3:20:33 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 29	Stability Project 1.27.1.0	2/15/2011 3:03:38 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
// **************************************************************************
/**************************************************************************************************************
 COPYRIGHT (c) 2005
 HONEYWELL INC.,
 ALL RIGHTS RESERVED
 This software is a copyrighted work and/or information protected
 as a trade secret. Legal rights of Honeywell Inc. in this
 software is distinct from ownership of any medium in which the
 software is embodied. Copyright or trade secret notices included
 must be reproduced in any copies authorized by Honeywell Inc.
 The information in this software is subject to change without
 notice and should not be considered as a commitment by Honeywell
 Inc.
 ******************************************************************************************/
#include "CMMDefines.h"
#include "V6Config.h"
#include "V6globals.h"
#include "MessageListServicesItem.h"
#include "ConfigurationManager.h"
#include "PasswordInterfaceManager.h"
#include "CPasswordModule.h"
//#include "OPL.h"
#include "PassAuthDefines.h"
#include <CTVtime>
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
//#define CPWI_TEST
#ifdef	CPWI_TEST
	#define LOG_SECURITY_MESSAGE	MessageBox(0,szMessage,0,MB_OK);
#endif
#define SECOND_TO_MILLI_SECONDS	1000*1000
PasswordInterfaceManager::PasswordInterfaceManager()
#ifdef RDL_PIM_ENABLE
: m_pDebugFileLogger(NULL)
#endif
{
	m_CPWIInit = FALSE;
	m_TotalUsers = 0;
	m_bMessageLog = TRUE;
}
PasswordInterfaceManager::~PasswordInterfaceManager() {
}
TV_BOOL PasswordInterfaceManager::IsCPWIInitialised() {
	return m_CPWIInit;
}
//*************************************************************************************
// PMMSTATUS PasswordInterfaceManager::IsPasswordEnabled()
//
/// IsPasswordEnabled checks whether the passwords enable or not 
/// 
/// @return		PMMSTATUS -	
/// 
/// @todo	-	
///		
//**************************************************************************************
PMMSTATUS PasswordInterfaceManager::IsPasswordEnabled() {
	if (!(pSYSTEM_INFO->ArePasswordsEnabled())) {
		return CSTATUS_PASSWORD_NOT_ENABLED;
	}
	return CSTATUS_OK;
}
//*************************************************************************************
// PMMSTATUS PasswordInterfaceManager::InitCPWI(CLIENTS eAccessClient)
//
/// InitCPWI is the first call to be made from the client. Initailises all the
///	class variables.
///
/// @param[in]	eAccessClient - Clients for which the object ownes.
///
/// @return		PMMSTATUS -	
/// 
/// @todo	-	
///		
//**************************************************************************************
//**************************************************************************************
// Revision History
// ************************************************************************************
// 
// 1 V6 Firmware1	06/01/2005		Shyam Prasad				
// 
//
// ************************************************************************************
//**************************************************************************************
PMMSTATUS PasswordInterfaceManager::InitCPWI(CLIENTS eAccessClient) {
	if (CSTATUS_OK != IsPasswordEnabled()) {
		return CSTATUS_PASSWORD_NOT_ENABLED;
	}
	if (CPWI_ALL_CLIENTS > eAccessClient) {
		m_UserClient = eAccessClient;
		m_CPWIInit = TRUE;
		return CSTATUS_OK;
	} else {
		return CSTATUS_FAIL;
	}
}
void PasswordInterfaceManager::AppendUserClientAndasprintfMessage(QString szUsername,
		T_MSGLISTSER_SECURITY_MSG_TYPE eMsgType, QString szMessage, const USHORT usDEST_BUFF_LEN, QString szArea) {
	QString csTmp; //temporary QString  for loading resource strings
	// clear the string before using
	memset(szMessage, 0, usDEST_BUFF_LEN * sizeof(WCHAR));
	const USHORT usMAX_BUFF_LEN = usDEST_BUFF_LEN - 1;
	// Step1 : Append Client information	
	switch (m_UserClient) {
	case CPWI_FTP: {
		csTmp = tr("FTP");
		wcsncat(szMessage, usDEST_BUFF_LEN, csTmp, usMAX_BUFF_LEN);
		break;
	}
	case CPWI_WEB: {
		csTmp = tr("WEB");
		wcsncat(szMessage, usDEST_BUFF_LEN, csTmp, usMAX_BUFF_LEN);
		break;
	}
	case CPWI_LOCAL_UI: {
		csTmp = tr("LOCAL UI");
		wcsncat(szMessage, usDEST_BUFF_LEN, csTmp, usMAX_BUFF_LEN);
		break;
	}
	default: {
		csTmp = tr("UNKNOWN CLIENT");
		wcsncat(szMessage, usDEST_BUFF_LEN, csTmp, usMAX_BUFF_LEN);
		break;
	}
	}
	// Step2 : Append Username information
	if (szUsername != NULL)
		wcsncat(szMessage, usDEST_BUFF_LEN, szUsername, usMAX_BUFF_LEN - wcsnlen(szMessage, usMAX_BUFF_LEN));
	// Step3 : Append Message information
	switch (eMsgType) {
	case MSGLISTSER_SECURITY_LOG_ON: {
		csTmp = tr("Login Successful");
		wcsncat(szMessage, usDEST_BUFF_LEN, csTmp, usMAX_BUFF_LEN - wcsnlen(szMessage, usMAX_BUFF_LEN));
		CDataItemGeneral *pkLoggedInUserDIT = static_cast<CDataItemGeneral*>( pDIT->GetDataItemPtr(DI_GENERAL,
				DI_GENTYPE_GENERAL, DI_GEN_LOGGED_IN_USER));
		pkLoggedInUserDIT->SetTag(szUsername);
		pkLoggedInUserDIT->RegisterChange();
		break;
	}
	case MSGLISTSER_SECURITY_TEMPORARY_USER_LOG_ON: {
		csTmp = tr("Temporary User Login Successful");
		wcsncat(szMessage, usDEST_BUFF_LEN, csTmp, usMAX_BUFF_LEN - wcsnlen(szMessage, usMAX_BUFF_LEN));
		CDataItemGeneral *pkLoggedInUserDIT = static_cast<CDataItemGeneral*>( pDIT->GetDataItemPtr(DI_GENERAL,
				DI_GENTYPE_GENERAL, DI_GEN_LOGGED_IN_USER));
		pkLoggedInUserDIT->SetTag(szUsername);
		pkLoggedInUserDIT->RegisterChange();
		break;
	}
	case MSGLISTSER_SECURITY_FIRSTTIME_USER_LOG_ON: {
		csTmp = tr("First Time User Login Successful");
		wcsncat(szMessage, usDEST_BUFF_LEN, csTmp, usMAX_BUFF_LEN - wcsnlen(szMessage, usMAX_BUFF_LEN));
		CDataItemGeneral *pkLoggedInUserDIT = static_cast<CDataItemGeneral*>( pDIT->GetDataItemPtr(DI_GENERAL,
				DI_GENTYPE_GENERAL, DI_GEN_LOGGED_IN_USER));
		pkLoggedInUserDIT->SetTag(szUsername);
		pkLoggedInUserDIT->RegisterChange();
		break;
	}
	case MSGLISTSER_SECURITY_LOGIN_WITH_DEFAULT_PASSOWRD: {
		csTmp = tr("Login Attempt With Default Password");
		wcsncat(szMessage, usDEST_BUFF_LEN, csTmp, usMAX_BUFF_LEN - wcsnlen(szMessage, usMAX_BUFF_LEN));
		break;
	}
	case MSGLISTSER_SECURITY_LOG_OFF: {
		csTmp = tr("Logoff Successful");
		wcsncat(szMessage, usDEST_BUFF_LEN, csTmp, usMAX_BUFF_LEN - wcsnlen(szMessage, usMAX_BUFF_LEN));
		CDataItemGeneral *pkLoggedInUserDIT = static_cast<CDataItemGeneral*>( pDIT->GetDataItemPtr(DI_GENERAL,
				DI_GENTYPE_GENERAL, DI_GEN_LOGGED_IN_USER));
		pkLoggedInUserDIT->SetTag(L"NA");
		pkLoggedInUserDIT->RegisterChange();
		break;
	}
	case MSGLISTSER_SECURITY_USERNAME_FAILURE: {
		csTmp = tr("Invalid Username");
		wcsncat(szMessage, usDEST_BUFF_LEN, csTmp, usMAX_BUFF_LEN - wcsnlen(szMessage, usMAX_BUFF_LEN));
		break;
	}
	case MSGLISTSER_SECURITY_DAYMASK_FAILURE: {
		csTmp = tr("Access Denied for the Day");
		wcsncat(szMessage, usDEST_BUFF_LEN, csTmp, usMAX_BUFF_LEN - wcsnlen(szMessage, usMAX_BUFF_LEN));
		break;
	}
	case MSGLISTSER_SECURITY_LOGINTIME_FAILURE: {
		csTmp = tr("Restricted Login Time");
		wcsncat(szMessage, usDEST_BUFF_LEN, csTmp, usMAX_BUFF_LEN - wcsnlen(szMessage, usMAX_BUFF_LEN));
		break;
	}
	case MSGLISTSER_SECURITY_USERLEVEL_FAILURE: {
		csTmp = tr("Insufficient Privileges");
		wcsncat(szMessage, usDEST_BUFF_LEN, csTmp, usMAX_BUFF_LEN - wcsnlen(szMessage, usMAX_BUFF_LEN));
		break;
	}
	case MSGLISTSER_SECURITY_PASSWORD_EXPIRED: {
		csTmp = tr("Password Expired");
		wcsncat(szMessage, usDEST_BUFF_LEN, csTmp, usMAX_BUFF_LEN - wcsnlen(szMessage, usMAX_BUFF_LEN));
		break;
	}
	case MSGLISTSER_SECURITY_PASSWORD_LOCKED: {
		csTmp = tr("Password Locked");
		wcsncat(szMessage, usDEST_BUFF_LEN, csTmp, usMAX_BUFF_LEN - wcsnlen(szMessage, usMAX_BUFF_LEN));
		break;
	}
	case MSGLISTSER_SECURITY_INVALID_USER_ID: {
		csTmp = tr("Invalid User ID");
		wcsncat(szMessage, usDEST_BUFF_LEN, csTmp, usMAX_BUFF_LEN - wcsnlen(szMessage, usMAX_BUFF_LEN));
		break;
	}
	case MSGLISTSER_SECURITY_VALID_AREA: {
		csTmp = tr("Valid Access to Area");
		wcsncat(szMessage, usDEST_BUFF_LEN, csTmp, usMAX_BUFF_LEN - wcsnlen(szMessage, usMAX_BUFF_LEN));
		if (NULL != szArea)
			wcsncat(szMessage, usDEST_BUFF_LEN, szArea, usMAX_BUFF_LEN - wcsnlen(szMessage, usMAX_BUFF_LEN));
		break;
	}
	case MSGLISTSER_SECURITY_INVALID_USER_AREA: {
		csTmp = tr("Access Denied to Area");
		wcsncat(szMessage, usDEST_BUFF_LEN, csTmp, usMAX_BUFF_LEN - wcsnlen(szMessage, usMAX_BUFF_LEN));
		if (NULL != szArea)
			wcsncat(szMessage, usDEST_BUFF_LEN, szArea, usMAX_BUFF_LEN - wcsnlen(szMessage, usMAX_BUFF_LEN));
		break;
	}
	case MSGLISTSER_SECURITY_PASSWORD_FAILURE: {
		csTmp = tr("Password Failure");
		wcsncat(szMessage, usDEST_BUFF_LEN, csTmp, usMAX_BUFF_LEN - wcsnlen(szMessage, usMAX_BUFF_LEN));
		break;
	}
	case MSGLISTSER_SECURITY_INACTIVITY_TIMEOUT: {
		csTmp = tr("Inactivity Timeout");
		wcsncat(szMessage, usDEST_BUFF_LEN, csTmp, usMAX_BUFF_LEN - wcsnlen(szMessage, usMAX_BUFF_LEN));
		break;
	}
	default: {
		csTmp = tr("Unknown Password Error");
		wcsncat(szMessage, usDEST_BUFF_LEN, csTmp, usMAX_BUFF_LEN - wcsnlen(szMessage, usMAX_BUFF_LEN));
		break;
	}
	}
}
PMMSTATUS PasswordInterfaceManager::GetUserGroup(SHORT UserId, DWORD *pGroup) {
	PMMSTATUS ePmmSts = CSTATUS_UNDEFINED;
	bool bFlag = FALSE;
	T_USERDATA UserData;
	if (CSTATUS_OK != IsPasswordEnabled()) {
		return CSTATUS_PASSWORD_NOT_ENABLED;
	}
	if (!IsCPWIInitialised()) {
		return CSTATUS_CPWI_NOT_INITIALISED;
	}
	bFlag = CheckForUserIdInList(UserId);
	if (TRUE != bFlag) {
		QString szUsername = NULL;
		WCHAR szMessage[ CPWI_MESSAGE_LENGTH] = { 0 };
		AppendUserClientAndasprintfMessage(szUsername, MSGLISTSER_SECURITY_INVALID_USER_ID, szMessage,
		CPWI_MESSAGE_LENGTH);
		LOG_SECURITY_MESSAGE(MSGLISTSER_SECURITY_INVALID_USER_ID, QString::fromWCharArray(szMessage));
		return CSTATUS_CPWI_INVALID_USER;
	}
	ePmmSts = GetUserById(UserId, &UserData);
	if (CSTATUS_OK != ePmmSts) {
		return ePmmSts;
	}
	*pGroup = UserData.UsrInfo.UserGroup;
	return CSTATUS_OK;
}
//*************************************************************************************
// PMMSTATUS PasswordInterfaceManager::Login(QString  szUsername,QString  szPassword, SHORT* UserId, WCHAR* szMessageBuffer)
//
/// Login will be called by the clients to validate the user, State of user will be 
///	mainatined as a list, User info will be added to list if the user is successfull 
/// in login, An appropiate message will be produced and will be logged by using 
/// LOG_SECURITY_MESSAGE macro.
///
/// @param[in]	szUsername			- Username to be validated.
///
/// @param[in]	szPassword			- Password to be validated.
///
/// @param[out]	UserId				- Will be filled by PMM and will be returned.
///
/// @param[in]	szMessageBuffer		- Message can be given from client, Will be 
///									appended to the message being logged.
///
/// @return		PMMSTATUS - Will return SUCCESS if user is successful in login, 
///									else returns respective error code.	
/// 
/// @todo	-	
///		
//**************************************************************************************
//**************************************************************************************
// Revision History
// ************************************************************************************
// 
// 1 V6 Firmware1	06/01/2005		Shyam Prasad				
// 
//	2	V6 Firmware	Jan 9th 2006	Shyam	-	Clubbed case CSTATUS_OK, CSTATUS_BACKDOOR_USER_AUTHENTICATED
//										CSTATUS_FIRST_TIME_USER_AUTHENTICATED to generate a 
//										success result in audit trial.
// ************************************************************************************
//**************************************************************************************
PMMSTATUS PasswordInterfaceManager::Login(QString szUsername, QString szPassword, SHORT *pUserId,
		QString szMessageBuffer) {
	PMMSTATUS ePmmSts = CSTATUS_UNDEFINED;
	WCHAR szMessage[CPWI_MESSAGE_LENGTH] = { 0 };
	if (CSTATUS_OK != IsPasswordEnabled()) {
		return CSTATUS_PASSWORD_NOT_ENABLED;
	}
	if (!IsCPWIInitialised()) {
		return CSTATUS_CPWI_NOT_INITIALISED;
	}
	ePmmSts = ValidateLogon(szUsername, szPassword, pUserId);
	CTVtime time;
	time.TimeNow();
	switch (ePmmSts) {
	case CSTATUS_OK:
	case CSTATUS_BACKDOOR_USER_AUTHENTICATED:
	case CSTATUS_FIRST_TIME_USER_AUTHENTICATED:
	case CSTATUS_EXPIRY_DAYS_WRN: {
		// Step1: Check if user is already added to list.			
		bool bCpwiSts = CheckForUserIdInList(*pUserId);
		// Step2: if not added to list Add the user to the list				
		if (bCpwiSts != TRUE) {
			UserList *UserInformation = new UserList;
			UserInformation->LoginTime = time.GetMicroSecs();
			UserInformation->LastAccessTime = time.GetMicroSecs();
			UserInformation->UserId = *pUserId;
			UserInformation->LoginCount = 1;
			m_list.push_back(UserInformation);
			m_TotalUsers = m_TotalUsers + 1;
		} else {
			UserList *UserInformation;
			bool bResult = GetUserInfoFromList(*pUserId, &UserInformation);
			if (TRUE == bResult) {
				UserInformation->LoginCount = UserInformation->LoginCount + 1;
				UserInformation->LoginTime = time.GetMicroSecs();
				UserInformation->LastAccessTime = time.GetMicroSecs();
			}
		}
		// Step3: asprintf the message to log						
		if (ePmmSts == CSTATUS_BACKDOOR_USER_AUTHENTICATED) {
			AppendUserClientAndasprintfMessage(szUsername, MSGLISTSER_SECURITY_TEMPORARY_USER_LOG_ON, szMessage,
			CPWI_MESSAGE_LENGTH);
			LOG_SECURITY_MESSAGE(MSGLISTSER_SECURITY_TEMPORARY_USER_LOG_ON, QString::fromWCharArray(szMessage));
		} else if (ePmmSts == CSTATUS_FIRST_TIME_USER_AUTHENTICATED) {
			AppendUserClientAndasprintfMessage(szUsername, MSGLISTSER_SECURITY_FIRSTTIME_USER_LOG_ON, szMessage,
			CPWI_MESSAGE_LENGTH);
			LOG_SECURITY_MESSAGE(MSGLISTSER_SECURITY_FIRSTTIME_USER_LOG_ON, QString::fromWCharArray(szMessage));
		} else {
			AppendUserClientAndasprintfMessage(szUsername, MSGLISTSER_SECURITY_LOG_ON, szMessage, CPWI_MESSAGE_LENGTH);
			LOG_SECURITY_MESSAGE(MSGLISTSER_SECURITY_LOG_ON, QString::fromWCharArray(szMessage));
		}
		break;
	}
	case CSTATUS_CHANGE_PASSWORD_FOR_LOGIN: {
		AppendUserClientAndasprintfMessage(szUsername, MSGLISTSER_SECURITY_LOGIN_WITH_DEFAULT_PASSOWRD, szMessage,
		CPWI_MESSAGE_LENGTH);
		LOG_SECURITY_MESSAGE(MSGLISTSER_SECURITY_LOGIN_WITH_DEFAULT_PASSOWRD, QString::fromWCharArray(szMessage));
		break;
	}
	case CSTATUS_FAIL: {
		AppendUserClientAndasprintfMessage(szUsername, MSGLISTSER_SECURITY_PASSWORD_FAILURE, szMessage,
		CPWI_MESSAGE_LENGTH);
		LOG_SECURITY_MESSAGE(MSGLISTSER_SECURITY_PASSWORD_FAILURE, QString::fromWCharArray(szMessage));
		break;
	}
	case CSTATUS_INVALID_PASSWORD: {
		AppendUserClientAndasprintfMessage(szUsername, MSGLISTSER_SECURITY_PASSWORD_FAILURE, szMessage,
		CPWI_MESSAGE_LENGTH);
		LOG_SECURITY_MESSAGE(MSGLISTSER_SECURITY_PASSWORD_FAILURE, QString::fromWCharArray(szMessage));
		break;
	}
	case CSTATUS_INVALID_USERNAME: {
		AppendUserClientAndasprintfMessage(szUsername, MSGLISTSER_SECURITY_USERNAME_FAILURE, szMessage,
		CPWI_MESSAGE_LENGTH);
		LOG_SECURITY_MESSAGE(MSGLISTSER_SECURITY_USERNAME_FAILURE, QString::fromWCharArray(szMessage));
		break;
	}
	case CSTATUS_INVALID_DAY_MASK: {
		AppendUserClientAndasprintfMessage(szUsername, MSGLISTSER_SECURITY_DAYMASK_FAILURE, szMessage,
		CPWI_MESSAGE_LENGTH);
		LOG_SECURITY_MESSAGE(MSGLISTSER_SECURITY_DAYMASK_FAILURE, QString::fromWCharArray(szMessage));
		break;
	}
	case CSTATUS_INVALID_LOGIN_TIME: {
		AppendUserClientAndasprintfMessage(szUsername, MSGLISTSER_SECURITY_LOGINTIME_FAILURE, szMessage,
		CPWI_MESSAGE_LENGTH);
		LOG_SECURITY_MESSAGE(MSGLISTSER_SECURITY_LOGINTIME_FAILURE, QString::fromWCharArray(szMessage));
		break;
	}
	case CSTATUS_INVALID_USER_LEVEL: {
		AppendUserClientAndasprintfMessage(szUsername, MSGLISTSER_SECURITY_USERLEVEL_FAILURE, szMessage,
		CPWI_MESSAGE_LENGTH);
		LOG_SECURITY_MESSAGE(MSGLISTSER_SECURITY_USERLEVEL_FAILURE, QString::fromWCharArray(szMessage));
		break;
	}
	case CSTATUS_PASSWORD_EXPIRED: {
		AppendUserClientAndasprintfMessage(szUsername, MSGLISTSER_SECURITY_PASSWORD_EXPIRED, szMessage,
		CPWI_MESSAGE_LENGTH);
		LOG_SECURITY_MESSAGE(MSGLISTSER_SECURITY_PASSWORD_EXPIRED, QString::fromWCharArray(szMessage));
		break;
	}
	case CSTATUS_PASSWORD_LOCKED: {
		AppendUserClientAndasprintfMessage(szUsername, MSGLISTSER_SECURITY_PASSWORD_LOCKED, szMessage,
		CPWI_MESSAGE_LENGTH);
		LOG_SECURITY_MESSAGE(MSGLISTSER_SECURITY_PASSWORD_LOCKED, QString::fromWCharArray(szMessage));
		break;
	}
	case CSTATUS_USER_LEVEL_DISALLOWED: {
		AppendUserClientAndasprintfMessage(szUsername, MSGLISTSER_SECURITY_USERLEVEL_FAILURE, szMessage,
		CPWI_MESSAGE_LENGTH);
		LOG_SECURITY_MESSAGE(MSGLISTSER_SECURITY_USERLEVEL_FAILURE, QString::fromWCharArray(szMessage));
		break;
	}
	default: {
		AppendUserClientAndasprintfMessage(szUsername, MSGLISTSER_SECURITY_PASSWORD_FAILURE, szMessage,
		CPWI_MESSAGE_LENGTH);
		LOG_SECURITY_MESSAGE(MSGLISTSER_SECURITY_PASSWORD_FAILURE, QString::fromWCharArray(szMessage));
		break;
	}
	}
	return ePmmSts;
}
bool PasswordInterfaceManager::CheckForUserIdInList(SHORT UserId) {
	POSITION Pos = m_list.GetHeadPosition();
	bool bElementFound = FALSE;
	while (Pos) {
		USER_LIST *UserInformation;
		UserInformation = m_list.GetNext(Pos);
		if (UserInformation->UserId == UserId) {
			bElementFound = TRUE;
			break;
		}
	}
	return bElementFound;
}
void PasswordInterfaceManager::RemoveUserInformation(SHORT UserId) {
	POSITION Pos = m_list.GetHeadPosition();
	POSITION prePOS = Pos;
	while (Pos) {
		prePOS = Pos;
		UserList *UserInformation = NULL;
		UserInformation = m_list.GetNext(Pos);
		if ((UserInformation != NULL) && (UserInformation->UserId == UserId)) {
			delete UserInformation;
			UserInformation = NULL;
			m_list.removeAt(prePOS);
			break;
		}
	}
}
bool PasswordInterfaceManager::GetUserInfoFromList(SHORT UserId, UserList **ppUserInformation) {
	POSITION Pos = m_list.GetHeadPosition();
	bool bElementFound = FALSE;
	while (Pos) {
		UserList *UserInfo = m_list.GetNext(Pos);
		if (UserInfo->UserId == UserId) {
			bElementFound = TRUE;
			*ppUserInformation = UserInfo;
			break;
		}
	}
	return bElementFound;
}
//*************************************************************************************
// PMMSTATUS PasswordInterfaceManager::Logoff(SHORT UserId, WCHAR* szMessageBuffer)	
//
/// Since the user can login multiple number of times a count is maintained, number of
///	times user is successful in login when the user count becomes ZERO user information
///	will be deleted from the linked list, Usercount will be decremented once the user 
///	is successfull in logoff, An appropiate message will be produced and will be logged 
///	by using LOG_SECURITY_MESSAGE macro.
///
/// @param[in]	UserId				- User id.
///
/// @param[in]	szMessageBuffer		- Message can be given from client, Will be 
///									appended to the message being logged.
///
/// @return		PMMSTATUS - Will return SUCCESS if user is successfully log-off, 
///									else returns appropriate error code.	
/// 
/// @todo	-	
///		
//**************************************************************************************
//**************************************************************************************
// Revision History
// ************************************************************************************
// 
// 1 V6 Firmware1	06/01/2005		Shyam Prasad				
// 
//
// ************************************************************************************
//**************************************************************************************
PMMSTATUS PasswordInterfaceManager::Logoff(SHORT UserId, QString szMessageBuffer) {
	if (CSTATUS_OK != IsPasswordEnabled()) {
		return CSTATUS_PASSWORD_NOT_ENABLED;
	}
	if (!IsCPWIInitialised()) {
		return CSTATUS_CPWI_NOT_INITIALISED;
	}
	QString szUsername = NULL;
	WCHAR szMessage[CPWI_MESSAGE_LENGTH] = { 0 };
	PMMSTATUS ePmmSts = CSTATUS_UNDEFINED;
	ePmmSts = logoff(UserId);
	switch (ePmmSts) {
	case CSTATUS_OK: {
		//POSITION pNodePos;	
		UserList *UserInformation = NULL;
		bool bCpwiSts = GetUserInfoFromList(UserId, &UserInformation);
		// Step1 : Check if user is present in List
		if (TRUE == bCpwiSts) {
			UserInformation->LoginCount = UserInformation->LoginCount - 1;
			if (!UserInformation->LoginCount) {
				RemoveUserInformation(UserId);
				m_TotalUsers = m_TotalUsers - 1;
			}
			// Step2 : Frame message and log
			if (UserId <= MAX_USERS) {
				T_USERDATA stUserData;
				memset((char*) &stUserData, 0, sizeof(T_USERDATA));
				ePmmSts = GetUserById(UserId, &stUserData);
				if (TRUE == m_bMessageLog) {
					AppendUserClientAndasprintfMessage(QString::fromWCharArray(stUserData.UsrInfo.Name),
							MSGLISTSER_SECURITY_LOG_OFF, szMessage,
							CPWI_MESSAGE_LENGTH);
					LOG_SECURITY_MESSAGE(MSGLISTSER_SECURITY_LOG_OFF, QString::fromWCharArray(szMessage));
				}
			} else {
				if (TRUE == m_bMessageLog) {
					QString csTmp;
					switch (UserId) {
					case FIRST_TIME_USER_ID: {
						csTmp = tr("First Time User");
						AppendUserClientAndasprintfMessage((WCHAR*) csTmp, MSGLISTSER_SECURITY_LOG_OFF,
								szMessage,
								CPWI_MESSAGE_LENGTH);
						LOG_SECURITY_MESSAGE(MSGLISTSER_SECURITY_LOG_OFF, QString::fromWCharArray(szMessage));
						break;
					}
					case BACKDOOR_USER_ID: {
						csTmp = tr("Temporary User");
						AppendUserClientAndasprintfMessage((WCHAR*) csTmp, MSGLISTSER_SECURITY_LOG_OFF,
								szMessage,
								CPWI_MESSAGE_LENGTH);
						LOG_SECURITY_MESSAGE(MSGLISTSER_SECURITY_LOG_OFF, QString::fromWCharArray(szMessage));
						break;
					}
					default:
						break;
					}
				}
			}
		} else {
			AppendUserClientAndasprintfMessage(szUsername, MSGLISTSER_SECURITY_INVALID_USER_ID, szMessage,
			CPWI_MESSAGE_LENGTH);
			LOG_SECURITY_MESSAGE(MSGLISTSER_SECURITY_INVALID_USER_ID, QString::fromWCharArray(szMessage));
			return CSTATUS_CPWI_INVALID_USER;
		}
		break;
	}
	case CSTATUS_INVALID_USER_ID: {
		AppendUserClientAndasprintfMessage(szUsername, MSGLISTSER_SECURITY_INVALID_USER_ID, szMessage,
		CPWI_MESSAGE_LENGTH);
		LOG_SECURITY_MESSAGE(MSGLISTSER_SECURITY_INVALID_USER_ID, QString::fromWCharArray(szMessage));
		break;
	}
	case CSTATUS_FAIL:
	default: {
		AppendUserClientAndasprintfMessage(szUsername, MSGLISTSER_SECURITY_INVALID_USER_ID, szMessage,
		CPWI_MESSAGE_LENGTH);
		LOG_SECURITY_MESSAGE(MSGLISTSER_SECURITY_INVALID_USER_ID, QString::fromWCharArray(szMessage));
		break;
	}
	}
	m_bMessageLog = TRUE;
	return ePmmSts;
}
//*************************************************************************************
// PMMSTATUS PasswordInterfaceManager::ValidateAreaNumber(SHORT AreaNumber,SHORT UserId,TV_BOOL *bResult,WCHAR* szMessageBuffer)
//
/// ValidateAreaNumber will call ValidateArea of PMM and get the status of the bit for the 
/// area number specified if bResult = TRUE user is a valid user and has an access to the area specified, 
/// if bResult = FALSE user access is denied to the area number specified.
///
/// @param[in]	AreaNumber			- Area number to be checked whether access is allowed or not.
///
/// @param[in] UserId				- User id.
///
/// @param[out] bResult				- TRUE - Valid area FALSE - Access denied.
///
/// @param[in]	szMessageBuffer		- Message can be given from client, Will be 
///									appended to the message being logged.
///
/// @return		PMMSTATUS - 
/// 
/// @todo	-	
///		
//**************************************************************************************
//**************************************************************************************
// Revision History
// ************************************************************************************
// 
// 1 V6 Firmware1	06/01/2005		Shyam 				
// 
//	2 V6 Firmware1	11/28/2005		Shyam	- Added a new Group to PMM module as 
//											"Unrestricted" and if the Area bit is TRUE 
//											in this group no further checks will be done,
//											user will be allowed to access that area 
//											even if the user is not logged-in to system. 
//											If the Area number in "Unrestricted" group 
//											is FALSE then regular algorithm will be used 
//											for validating the user area.	
//
//	3	V6 Firmware		Jan 9th 2006	Shyam	- Added a condition check if the Web inactivity 
//											timeout is SET to '0' then the logoff need 
//											not be called.
//
//	4	V6 Firmware		Jan 16th 2006	Shyam	- Added a condition to check if the 
//											client is web or UI to get the inactivity timeout. 
//											For FTP web timeout is considered.
// ************************************************************************************
//**************************************************************************************
PMMSTATUS PasswordInterfaceManager::ValidateAreaNumber(SHORT AreaNumber, SHORT UserId, TV_BOOL *bResult,
		QString szMessageBuffer) {
#ifdef RDL_PIM_ENABLE
  QString  strLog;
		strLog = QString::asprintf(_T(":ValidateAreaNumber....Entered"));
		LogDebugMessage(strLog);
	#endif
	if (CSTATUS_OK != IsPasswordEnabled()) {
#ifdef RDL_PIM_ENABLE
  QString  strLog;
		strLog = QString::asprintf(_T(":IsPasswordEnabled()..."));
		LogDebugMessage(strLog);
	#endif
		return CSTATUS_PASSWORD_NOT_ENABLED;
	}
	if (!IsCPWIInitialised()) {
#ifdef RDL_PIM_ENABLE
  QString  strLog;
		strLog = QString::asprintf(_T(":IsCPWIInitialised()..."));
		LogDebugMessage(strLog);
		#endif
		return CSTATUS_CPWI_NOT_INITIALISED;
	}
	WCHAR szMessage[CPWI_MESSAGE_LENGTH] = { 0 };
	PMMSTATUS ePmmSts = CSTATUS_UNDEFINED;
	// Step1 : Check if the user is successful in login
	/************************ Change Request **********************************************
	 // Change request from Andy: Add a new group as "Unrestricted" check for the permission 
	 // for the area number specified in this group, if the "Unrestricted" user area 
	 // permission bit is set to TRUE then we need not check if the user is logged-in or 
	 // not just autheticate the user without even calling validateArea method.
	 ***************************************************************************************/
	DWORD dwUnrestrictedGroupPerm[4] = { 0 };	// for 128 Bit permission mask.
	GetUserPermission(UNRESTRICTED_PERM, dwUnrestrictedGroupPerm);
	T_USERDATA stUserData;
	memset((char*) &stUserData, 0, sizeof(T_USERDATA));
	GetUserById(UserId, &stUserData);
	TV_BOOL Status = FALSE;
#ifdef RDL_PIM_ENABLE
		strLog = QString::asprintf(_T(":GetBitSts....Calling"));
		LogDebugMessage(strLog);
	#endif
	GetBitSts(AreaNumber, dwUnrestrictedGroupPerm, &Status);
#ifdef RDL_PIM_ENABLE
		strLog = QString::asprintf(_T(":GetBitSts....Called"));
		LogDebugMessage(strLog);
	#endif
	if (TRUE == Status) {
		*bResult = Status;
		//logs messages only for UI and Remote viewer page from WEB 
		if (m_TotalUsers > 0
				&& ((CPWI_LOCAL_UI == m_UserClient) || (AreaNumber == AUTHENTICATION_AREA_REMOTECONTROL))) {
#ifdef RDL_PIM_ENABLE
  QString  strLog;
  strLog = QString::asprintf(_T(":AppendUserClientAndasprintfMessage...calling"));
						LogDebugMessage(strLog);
				#endif
			AppendUserClientAndasprintfMessage(QString::fromWCharArray(stUserData.UsrInfo.Name),
					MSGLISTSER_SECURITY_VALID_AREA, szMessage,
					CPWI_MESSAGE_LENGTH, szMessageBuffer);
			LOG_SECURITY_MESSAGE(MSGLISTSER_SECURITY_VALID_AREA, QString::fromWCharArray(szMessage));
		}
		return CSTATUS_OK;
	}
	bool bValidUser = FALSE;
#ifdef RDL_PIM_ENABLE
		strLog = QString::asprintf(_T(":CheckForUserIdInList....Calling"));
		LogDebugMessage(strLog);
	#endif
	bValidUser = CheckForUserIdInList(UserId);
#ifdef RDL_PIM_ENABLE
		strLog = QString::asprintf(_T(":CheckForUserIdInList....Called"));
		LogDebugMessage(strLog);
	#endif
	if (!bValidUser) {
		//only for UI logs invalid user id message
		if (m_TotalUsers > 0 && CPWI_LOCAL_UI == m_UserClient) {
#ifdef RDL_PIM_ENABLE
  QString  strLog;
  strLog = QString::asprintf(_T(":AppendUserClientAndasprintfMessage...calling"));
						LogDebugMessage(strLog);
			#endif
			AppendUserClientAndasprintfMessage(QString::fromWCharArray(stUserData.UsrInfo.Name),
					MSGLISTSER_SECURITY_INVALID_USER_ID, szMessage,
					CPWI_MESSAGE_LENGTH);
			LOG_SECURITY_MESSAGE(MSGLISTSER_SECURITY_INVALID_USER_ID, QString::fromWCharArray(szMessage));
		}
		return CSTATUS_CPWI_USER_NOT_LOGIN;
	}
	// Step2 : Check user for Web inactivity time
	SHORT sLogoffTime = 0;
	if (CPWI_LOCAL_UI == m_UserClient) {
#ifdef RDL_PIM_ENABLE
  QString  strLog;
				strLog = QString::asprintf(_T(":GetUILogoffTime...calling"));
				LogDebugMessage(strLog);
		#endif
		ePmmSts = GetUILogoffTime(&sLogoffTime);
#ifdef RDL_PIM_ENABLE
				
				strLog = QString::asprintf(_T(":GetUILogoffTime...called ePmmSts = %d"), ePmmSts);
				LogDebugMessage(strLog);
		#endif
		if (CSTATUS_OK != ePmmSts)
			return ePmmSts;
	} else {
#ifdef RDL_PIM_ENABLE
  QString  strLog;
				strLog = QString::asprintf(_T(":GetWebLogOffTime...calling"));
				LogDebugMessage(strLog);
		#endif
		ePmmSts = GetWebLogOffTime(&sLogoffTime);
#ifdef RDL_PIM_ENABLE
				
				strLog = QString::asprintf(_T(":GetWebLogOffTime...called ePmmSts = %d"), ePmmSts);
				LogDebugMessage(strLog);
		#endif
		if (CSTATUS_OK != ePmmSts)
			return ePmmSts;
	}
	LONGLONG TimeNow = 0, LastAccessTime = 0;
#ifdef RDL_PIM_ENABLE
			
			strLog = QString::asprintf(_T(":GetLastAccessTime...calling"));
			LogDebugMessage(strLog);
	#endif
	ePmmSts = GetLastAccessTime(UserId, &LastAccessTime, &TimeNow);
#ifdef RDL_PIM_ENABLE
			
			strLog = QString::asprintf(_T(":GetLastAccessTime...called"));
			LogDebugMessage(strLog);
	#endif
	if (CSTATUS_OK != ePmmSts)
		return ePmmSts;
	// if web or UI Log-off inactivity time is Enabled then logoff automatically if Inactivity time is crossed.
	if (sLogoffTime) {
#ifdef RDL_PIM_ENABLE
  QString  strLog;
			strLog = QString::asprintf(_T(":if(sLogoffTime)...entered, sLogoffTime = %d"),sLogoffTime);
			LogDebugMessage(strLog);
		#endif
		if ((TimeNow - LastAccessTime) >= (ULONG) (sLogoffTime * SECOND_TO_MILLI_SECONDS)) {
			m_bMessageLog = FALSE;
			ePmmSts = Logoff(UserId);
			T_USERDATA stUserData;
			memset((char*) &stUserData, 0, sizeof(T_USERDATA));
			GetUserById(UserId, &stUserData);
			if (UserId > MAX_USERS) {
				QString csTmp;
				csTmp = tr("Temporary User");
				wcscpy_s(stUserData.UsrInfo.Name, sizeof(stUserData.UsrInfo.Name) / sizeof(WCHAR), csTmp);
			}
			AppendUserClientAndasprintfMessage(QString::fromWCharArray(stUserData.UsrInfo.Name),
					MSGLISTSER_SECURITY_INACTIVITY_TIMEOUT, szMessage,
					CPWI_MESSAGE_LENGTH);
			LOG_SECURITY_MESSAGE(MSGLISTSER_SECURITY_INACTIVITY_TIMEOUT, QString::fromWCharArray(szMessage));
			return CSTATUS_CPWI_INACTIVITY_TIMEOUT;
		}
	}
#ifdef RDL_PIM_ENABLE
		strLog = QString::asprintf(_T(":ValidateArea....Calling"));
		LogDebugMessage(strLog);
	#endif
	ePmmSts = ValidateArea(AreaNumber, UserId, bResult);
#ifdef RDL_PIM_ENABLE
		strLog = QString::asprintf(_T(":ValidateAreaNumber....Called ePmmSts = %d"),ePmmSts);
		LogDebugMessage(strLog);
	#endif
	switch (ePmmSts) {
	case CSTATUS_OK: {
		// If the slot is not used, default entry will be in username field.
		if (!stUserData.Used)
			wcscpy_s(stUserData.UsrInfo.Name, sizeof(stUserData.UsrInfo.Name) / sizeof(WCHAR), L"\0");
		QString csTmp = L"";
		switch (UserId) {
		case MAX_USERS + 1: {
			csTmp = tr("Temporary User");
			wcscpy_s(stUserData.UsrInfo.Name, sizeof(stUserData.UsrInfo.Name) / sizeof(WCHAR), csTmp);
			break;
		}
		case MAX_USERS + 2: {
			csTmp = tr("First Time User");
			wcscpy_s(stUserData.UsrInfo.Name, sizeof(stUserData.UsrInfo.Name) / sizeof(WCHAR), csTmp);
			break;
		}
		default:
			break;
		}
		if ( TRUE == *bResult) {
			//logs messages only for UI and Remote viewer page from WEB
			if (m_TotalUsers > 0
					&& ((CPWI_LOCAL_UI == m_UserClient) || (AreaNumber == AUTHENTICATION_AREA_REMOTECONTROL))) {
				AppendUserClientAndasprintfMessage(QString::fromWCharArray(stUserData.UsrInfo.Name),
						MSGLISTSER_SECURITY_VALID_AREA, szMessage,
						CPWI_MESSAGE_LENGTH, szMessageBuffer);
				LOG_SECURITY_MESSAGE(MSGLISTSER_SECURITY_VALID_AREA, QString::fromWCharArray(szMessage));
			}
			//Step4: Update Last access time
			UpdateLastAccessTime(UserId);
		} else {
			//logs messages only for UI and Remote viewer page from WEB
			if (m_TotalUsers > 0
					&& ((CPWI_LOCAL_UI == m_UserClient) || (AreaNumber == AUTHENTICATION_AREA_REMOTECONTROL))) {
				// Access to area denied.
#ifdef RDL_PIM_ENABLE
							strLog = QString::asprintf(_T(":Access to area denied..."));
							LogDebugMessage(strLog);
						#endif
				AppendUserClientAndasprintfMessage(QString::fromWCharArray(stUserData.UsrInfo.Name),
						MSGLISTSER_SECURITY_INVALID_USER_AREA, szMessage,
						CPWI_MESSAGE_LENGTH, szMessageBuffer);
				LOG_SECURITY_MESSAGE(MSGLISTSER_SECURITY_INVALID_USER_AREA, QString::fromWCharArray(szMessage));
			}
			//Step4: Update Last access time
#ifdef RDL_PIM_ENABLE
				strLog = QString::asprintf(_T(":UpdateLastAccessTime...calling"));
				LogDebugMessage(strLog);
				#endif
			UpdateLastAccessTime(UserId);
#ifdef RDL_PIM_ENABLE
				strLog = QString::asprintf(_T(":UpdateLastAccessTime...called"));
				LogDebugMessage(strLog);
				#endif
		}
		break;
	}
	case CSTATUS_INVALID_PARAMETER:
	case CSTATUS_FAIL:
	default: {
		//only for UI logs invalid user id message
		if (m_TotalUsers > 0 && CPWI_LOCAL_UI == m_UserClient) {
			AppendUserClientAndasprintfMessage(QString::fromWCharArray(stUserData.UsrInfo.Name),
					MSGLISTSER_SECURITY_INVALID_USER_ID, szMessage,
					CPWI_MESSAGE_LENGTH);
			LOG_SECURITY_MESSAGE(MSGLISTSER_SECURITY_INVALID_USER_ID, QString::fromWCharArray(szMessage));
		}
		break;
	}
	}
#ifdef RDL_PIM_ENABLE
		strLog = QString::asprintf(_T(":ValidateAreaNumber....Leaving"));
		LogDebugMessage(strLog);
	#endif
	return ePmmSts;
}
//*************************************************************************************
// PMMSTATUS PasswordInterfaceManager::GetUserNamePolicyDetails(T_USERPOLICY* pstUserDetails)
//
/// Will fill information about the username like maximum and minimum characters allowed in the username.
///
/// @param[out]	pstUserDetails		- Buffer to fill information of the user details.
///
/// @return		PMMSTATUS - Will return CSTATUS_OK if successfully obtained pointer
///							to the policy information else returns FAILED.
///
///	@todo	-
///
//**************************************************************************************
//**************************************************************************************
// Revision History
// ************************************************************************************
//
// 1 V6 Firmware1	06/01/2005		Shyam Prasad
//
//
// ************************************************************************************
//**************************************************************************************
PMMSTATUS PasswordInterfaceManager::GetUserNamePolicyDetails(T_USERPOLICY *pstUserDetails) {
	if (CSTATUS_OK != IsPasswordEnabled()) {
		return CSTATUS_PASSWORD_NOT_ENABLED;
	}
	if (!IsCPWIInitialised()) {
		return CSTATUS_CPWI_NOT_INITIALISED;
	}
	T_PMMPOLICYDATA stPolicyDetails = { 0 };
	PMMSTATUS ePmmSts = CSTATUS_UNDEFINED;
	ePmmSts = GetPolicy(&stPolicyDetails);
	if (ePmmSts == CSTATUS_OK) {
		memcpy(pstUserDetails, (char*) &stPolicyDetails.UserPolicyData, sizeof(T_USERPOLICY));
		return CSTATUS_OK;
	}
	return CSTATUS_FAIL;
}
//*************************************************************************************
// T_CPWI_RETURN_VALUE PasswordInterfaceManager::GetPasswordPolicyDetails(T_PWRDPOLICY* pstPwdPolicyDetails)
//
/// Will fill information about the password like maximum, minimum characters allowed
///	total number of retries, minimum number of special char,minimum numerics in the password.
///
/// @param[out]	pstPwdPolicyDetails	- Buffer to fill information of the password policy.
///
/// @return		PMMSTATUS - Will return CSTATUS_OK if successfully obtained pointer
///							to the policy information else returns FAILED.
///
///	@todo	-
///
//**************************************************************************************
//**************************************************************************************
// Revision History
// ************************************************************************************
//
// 1 V6 Firmware1	06/01/2005		Shyam Prasad
//
//
//**************************************************************************************
//**************************************************************************************
PMMSTATUS PasswordInterfaceManager::GetPasswordPolicyDetails(T_PWRDPOLICY *pstPwdPolicyDetails) {
	if (CSTATUS_OK != IsPasswordEnabled()) {
		return CSTATUS_PASSWORD_NOT_ENABLED;
	}
	if (!IsCPWIInitialised()) {
		return CSTATUS_CPWI_NOT_INITIALISED;
	}
	T_PMMPOLICYDATA stPolicyDetails = { 0 };
	PMMSTATUS ePmmSts = CSTATUS_UNDEFINED;
	ePmmSts = GetPolicy(&stPolicyDetails);
	if (ePmmSts == CSTATUS_OK) {
		memcpy(pstPwdPolicyDetails, (char*) &stPolicyDetails.PwdPolicyData, sizeof(T_PWRDPOLICY));
		return ePmmSts;
	}
	return ePmmSts;
}
PMMSTATUS PasswordInterfaceManager::GetPMMMode(TV_BOOL *bResult) {
	if (CSTATUS_OK != IsPasswordEnabled()) {
		return CSTATUS_PASSWORD_NOT_ENABLED;
	}
	if (!IsCPWIInitialised()) {
		return CSTATUS_CPWI_NOT_INITIALISED;
	}
	T_PMMPOLICYDATA stPolicyDetails = { 0 };
	PMMSTATUS ePmmSts = CSTATUS_UNDEFINED;
	ePmmSts = GetPolicy(&stPolicyDetails);
	if (ePmmSts == CSTATUS_OK) {
		*bResult = stPolicyDetails.GPolicyData.CFRmode;
		return ePmmSts;
	}
	return ePmmSts;
}
//*************************************************************************************
// T_CPWI_RETURN_VALUE PasswordInterfaceManager::GetUILogoffTime(short* pLogoffTime)
//
/// Will obtain information about the UI logoff time from the policy data present in PMM.
///
/// @param[out]	pLogoffTime	- UI inactivity logoff period in milliseconds.
///
/// @return		PMMSTATUS - Will return CSTATUS_OK if successfully obtained pointer
///							to the policy information else returns FAILED.
///
///	@todo	-
///
//**************************************************************************************
//**************************************************************************************
// Revision History
// ************************************************************************************
//
// 1 V6 Firmware1	06/01/2005		Shyam Prasad
//
//
// ************************************************************************************
//**************************************************************************************
PMMSTATUS PasswordInterfaceManager::GetUILogoffTime(short *pLogoffTime) {
	if (CSTATUS_OK != IsPasswordEnabled()) {
		return CSTATUS_PASSWORD_NOT_ENABLED;
	}
	if (!IsCPWIInitialised()) {
		return CSTATUS_CPWI_NOT_INITIALISED;
	}
	T_PMMPOLICYDATA stPolicyDetails = { 0 };
	PMMSTATUS ePmmSts = CSTATUS_UNDEFINED;
	ePmmSts = GetPolicy(&stPolicyDetails);
	if (ePmmSts == CSTATUS_OK) {
		*pLogoffTime = stPolicyDetails.GPolicyData.UILogOffTime;
		return ePmmSts;
	}
	return ePmmSts;
}
//*************************************************************************************
// PMMSTATUS PasswordInterfaceManager::GetWebLogOffTime(short* pLogoffTime)
//
/// Will obtain information about the WEB logoff time from the policy data present in PMM.
///
/// @param[out]	pLogoffTime	- Web inactivity logoff period in milliseconds.
///
/// @return		PMMSTATUS - Will return CSTATUS_OK if successfully obtained pointer
///							to the policy information else returns FAILED.
///
///	@todo	-
///
//**************************************************************************************
//**************************************************************************************
// Revision History
// ************************************************************************************
//
// 1 V6 Firmware1	06/01/2005		Shyam Prasad
//
//
// ************************************************************************************
//**************************************************************************************
PMMSTATUS PasswordInterfaceManager::GetWebLogOffTime(short *pLogoffTime) {
	if (CSTATUS_OK != IsPasswordEnabled()) {
		return CSTATUS_PASSWORD_NOT_ENABLED;
	}
	if (!IsCPWIInitialised()) {
		return CSTATUS_CPWI_NOT_INITIALISED;
	}
	T_PMMPOLICYDATA stPolicyDetails = { 0 };
	PMMSTATUS ePmmSts = CSTATUS_UNDEFINED;
	ePmmSts = GetPolicy(&stPolicyDetails);
	if ((ePmmSts == CSTATUS_OK)) {
		*pLogoffTime = stPolicyDetails.GPolicyData.WebLogoffTime;
		return ePmmSts;
	}
	return ePmmSts;
}
//*************************************************************************************
// PMMSTATUS PasswordInterfaceManager::UpdateLastAccessTime(SHORT UserId)
//
/// Will update the last access time in the list if the user is successfully log-in before.
/// Should be called by the client when any activity is done by the user on system.
///
/// @param[in]	UserId	- User identification number.
///
/// @return		PMMSTATUS -
///
///	@todo	-
///
//**************************************************************************************
//**************************************************************************************
// Revision History
// ************************************************************************************
//
// 1 V6 Firmware1	06/01/2005		Shyam Prasad
//
//
// ************************************************************************************
//**************************************************************************************
PMMSTATUS PasswordInterfaceManager::UpdateLastAccessTime(SHORT UserId) {
	bool bCpwiSts = CheckForUserIdInList(UserId);
	if (TRUE == bCpwiSts) {
		LONGLONG TimeNow = 0, LastAccessTime = 0;
		PMMSTATUS ePmmSts = CSTATUS_UNDEFINED;
		ePmmSts = GetLastAccessTime(UserId, &LastAccessTime, &TimeNow);
		if (CSTATUS_OK != ePmmSts)
			return ePmmSts;
		short sLogoffTime = 0;
		if (CPWI_LOCAL_UI == m_UserClient) {
			ePmmSts = GetUILogoffTime(&sLogoffTime);
			if (CSTATUS_OK != ePmmSts)
				return ePmmSts;
		} else if ((CPWI_WEB == m_UserClient) || (CPWI_FTP == m_UserClient)) {
			ePmmSts = GetWebLogOffTime(&sLogoffTime);
			if (CSTATUS_OK != ePmmSts)
				return ePmmSts;
		}
		if ((TimeNow - LastAccessTime) >= (ULONG) (sLogoffTime * SECOND_TO_MILLI_SECONDS)) {
			return CSTATUS_FAIL;
		} else {
			UserList *UserInformation;
			GetUserInfoFromList(UserId, &UserInformation);
			CTVtime time;
			time.TimeNow();
			UserInformation->LastAccessTime = time.GetMicroSecs();
			return CSTATUS_OK;
		}
	}
	return CSTATUS_FAIL;
}
//*************************************************************************************
// PMMSTATUS PasswordInterfaceManager::GetLastAccessTime(SHORT UserId, LONGLONG* pLastAccessTime)
//
/// Will obtain the latest time last user did some activity.
///
/// @param[in]	UserId			- User idendtication number
///
/// @param[out]	pLastAccessTime	- Obtains the Latest time user did some activity
///								from the list of users maintained.
///
/// @return		PMMSTATUS - Will return CSTATUS_OK if the user is successfully log-in to
///							the system else returns FAILURE.
///
///	@todo	-
///
//**************************************************************************************
//**************************************************************************************
// Revision History
// ************************************************************************************
//
// 1 V6 Firmware1	06/01/2005		Shyam Prasad
//
//
// ************************************************************************************
//**************************************************************************************
PMMSTATUS PasswordInterfaceManager::GetLastAccessTime(SHORT UserId, LONGLONG *pLastAccessTime, LONGLONG *pTimeNow) {
	bool bCpwiSts = CheckForUserIdInList(UserId);
	if (TRUE == bCpwiSts) {
		UserList *UserInformation;
		GetUserInfoFromList(UserId, &UserInformation);
		if ((pLastAccessTime) && (pTimeNow)) {
			*pLastAccessTime = UserInformation->LastAccessTime;
			CTVtime CurrentTime;
			CurrentTime.TimeNow();
			*pTimeNow = CurrentTime.GetMicroSecs();
			return CSTATUS_OK;
		} else {
			return CSTATUS_FAIL;
		}
	}
	return CSTATUS_FAIL;
}
//*************************************************************************************
// PMMSTATUS PasswordInterfaceManager::GetLoginTime(SHORT UserId,LONGLONG* pLoginTime)
//
/// Obtains the login time of the user id passed from the list of users maintained.
///
/// @param[in]	UserId		- User identification number
///
/// @param[out]	pLoginTime	- Last login time of the user
///
/// @return		PMMSTATUS - Will return CSTATUS_OK if the user is a valid user and
///							logged in successfully to the system else returns FAILED .
///
///	@todo	-
///
//**************************************************************************************
//**************************************************************************************
// Revision History
// ************************************************************************************
//
// 1 V6 Firmware1	06/01/2005		Shyam Prasad
//
//
// ************************************************************************************
//**************************************************************************************
PMMSTATUS PasswordInterfaceManager::GetLoginTime(SHORT UserId, LONGLONG *pLoginTime) {
	bool bCpwiSts = CheckForUserIdInList(UserId);
	if (TRUE == bCpwiSts) {
		UserList *UserInformation;
		GetUserInfoFromList(UserId, &UserInformation);
		*pLoginTime = UserInformation->LoginTime;
		return CSTATUS_OK;
	}
	return CSTATUS_FAIL;
}
//*************************************************************************************
// PMMSTATUS PasswordInterfaceManager::IsFTPEnabled(TV_BOOL* bResult)
//
/// Will obtain information whether FTP is enabled or not
///
/// @param[out]	bResult		- If TRUE - FTP enabled
///
/// @return		PMMSTATUS	- Will return CSTATUS_OK if successfully obtained pointer
///							to the policy information else returns FAILED.
///
///	@todo	-
///
//**************************************************************************************
//**************************************************************************************
// Revision History
// ************************************************************************************
//
// 1 V6 Firmware1	06/01/2005		Shyam Prasad
//
//
// ************************************************************************************
//**************************************************************************************
PMMSTATUS PasswordInterfaceManager::IsFTPEnabled(TV_BOOL *bResult) {
	if (CSTATUS_OK != IsPasswordEnabled()) {
		return CSTATUS_PASSWORD_NOT_ENABLED;
	}
	if (!IsCPWIInitialised()) {
		return CSTATUS_CPWI_NOT_INITIALISED;
	}
	T_PMMPOLICYDATA stPolicyDetails = { 0 };
	PMMSTATUS ePmmSts = CSTATUS_UNDEFINED;
	ePmmSts = GetPolicy(&stPolicyDetails);
	if (ePmmSts == CSTATUS_OK) {
		*bResult = stPolicyDetails.GPolicyData.ftpAccess;
		return ePmmSts;
	} else {
		ePmmSts = CSTATUS_CPWI_FTP_DISABLED;
	}
	return ePmmSts;
}
//*************************************************************************************
// PMMSTATUS PasswordInterfaceManager::IsWEBEnabled(TV_BOOL* bResult)
//
/// Will obtain information whether WEB is enabled or not
///
/// @param[out]	bResult		- If TRUE - WEB enabled
///
/// @return		PMMSTATUS	- Will return CSTATUS_OK if successfully obtained pointer
///							to the policy information else returns FAILED.
///
///	@todo	-
///
//**************************************************************************************
//**************************************************************************************
// Revision History
// ************************************************************************************
//
// 1 V6 Firmware1	06/01/2005		Shyam Prasad
//
//
// ************************************************************************************
//**************************************************************************************
PMMSTATUS PasswordInterfaceManager::IsWEBEnabled(TV_BOOL *bResult) {
	if (CSTATUS_OK != IsPasswordEnabled()) {
		return CSTATUS_PASSWORD_NOT_ENABLED;
	}
	if (!IsCPWIInitialised()) {
		return CSTATUS_CPWI_NOT_INITIALISED;
	}
	T_PMMPOLICYDATA stPolicyDetails = { 0 };
	PMMSTATUS ePmmSts = CSTATUS_UNDEFINED;
	ePmmSts = GetPolicy(&stPolicyDetails);
	if (ePmmSts == CSTATUS_OK) {
		*bResult = stPolicyDetails.GPolicyData.WebAccess;
		return ePmmSts;
	} else {
		ePmmSts = CSTATUS_CPWI_WEB_DISABLED;
	}
	return ePmmSts;
}
//******************************************************************************************
// PMMSTATUS PasswordInterfaceManager::IsAreaUnrestricted(SHORT AreaNumber,TV_BOOL* bResult)
/// Checks that access to a certain area is unrestricted.
/// @param[in] T_AUTHENTICATION_AREAS Area - Area to be authenticated
/// @return		PMMSTATUS	- Will return TRUE if Access to the area is unrestricted
///
///
//******************************************************************************************
TV_BOOL PasswordInterfaceManager::IsAreaUnrestricted(SHORT AreaNumber) {
	DWORD dwUnrestrictedGroupPerm[4] = { 0 };	// for 128 Bit permission mask.
	GetUserPermission(UNRESTRICTED_PERM, dwUnrestrictedGroupPerm);
	TV_BOOL Status = FALSE;
	GetBitSts(AreaNumber, dwUnrestrictedGroupPerm, &Status);
	return Status;
}
PMMSTATUS PasswordInterfaceManager::GetPwdSts(QString wUserName, TV_BOOL *pResult) {
	return GetPasswordStatus(wUserName, pResult);
}
#ifdef RDL_PIM_ENABLE
void PasswordInterfaceManager::SetDebugLogger(CDebugFileLogger* pDbgFileLogger)
{
	m_pDebugFileLogger = pDbgFileLogger;
}
void PasswordInterfaceManager::LogDebugMessage(QString  & strDbgMsg)
{
	if( NULL != m_pDebugFileLogger )
	{
  QString  strDiagMsg;
		strDiagMsg = QString::asprintf(_T("PIM - %s at GTC:%u\r\n"), strDbgMsg, GetTickCount());
		m_pDebugFileLogger->WriteToDebugLogFile(strDiagMsg);
	}
}
#endif

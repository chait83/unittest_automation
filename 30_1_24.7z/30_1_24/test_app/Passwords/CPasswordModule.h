/// @file CPasswordModule.h
/// ****************************************************************************************
/// © Honeywell Trendview
/// ****************************************************************************************
/// @n Module	:	Password Management Module.
/// @n Filename	:	CPasswordModule.h
/// @n Desc		:	Declaration of exposed API.
///
// ****************************************************************************************
// Revision History
// ****************************************************************************************
// $Log[1]:
// 9	Stability Project 1.6.1.1	7/2/2011 4:56:24 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// $Log" from the functions
// $
//
// ****************************************************************************************
/******************************************************************************************
 COPYRIGHT (c) 2004
 HONEYWELL INC.,
 ALL RIGHTS RESERVED
 This software is a copyrighted work and/or information protected
 as a trade secret. Legal rights of Honeywell Inc. in this
 software is distinct from ownership of any medium in which the
 software is embodied. Copyright or trade secret notices included
 must be reproduced in any copies authorized by Honeywell Inc.
 The information in this software is subject to change without
 notice and should not be considered as a commitment by Honeywell
 Inc.
 ******************************************************************************************/
// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the PASSWORDMODULE_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// PASSWORDMODULE_API functions as being imported from a DLL, wheras this DLL sees symbols
// defined with this macro as being exported.
#pragma once
#ifndef _INC_CUSERVALIDATION_40D6CBF2031H_INCLUDED
#define _INC_CUSERVALIDATION_40D6CBF2031H_INCLUDED
#define PMM_API
#include "PMMglobal.h"
#include "CMMDefines.h"
#include "V6Config.h"
void LoadTracerModule();
void UnLoadTracerModule();
/*********************Global Objects*****************************************/
//QLibrary glbDllHandle;						///< Global Tracer Handle
//Global Tracer functions
//fnTraceStart TraceStart = NULL;				///< Global function pointer to start Tracer Module
//fnTrace Trace = NULL;						///< Global function pointer to log traces
//fnTraceStop TraceStop = NULL;				///< Global function pointer to stop Tracer Module
/*************************************************************************/
//extern PMM_API int nPasswordModule;
#define PMM_API
//******************************************************
// CPasswordModule
///
/// @brief Implements the C style API functions
/// 
/// 
//******************************************************
PMM_API PMMSTATUS InitPassword(TV_BOOL ForceCFR, DWORD configID, ULONG serialNumber, TV_BOOL NewConfiguration,
		void *NvPtr);
PMM_API PMMSTATUS initialiseToDefault(TV_BOOL PolicyType);
PMM_API PMMSTATUS ResetUserData(DWORD ConfigId);
PMM_API PMMSTATUS AddUser(T_USERDATA *UserInfo, SHORT *ID);
PMM_API PMMSTATUS RemoveUser(SHORT ID);
PMM_API PMMSTATUS ModifyUser(SHORT ID, BYTE UserGroup, TV_BOOL CustomOrDefault);
PMM_API PMMSTATUS GetUser(SHORT *UserId, T_USERDATA *UserData);
PMM_API PMMSTATUS GetUserById(SHORT ID, T_USERDATA *UserData);
PMM_API PMMSTATUS GetUserPermission(SHORT ID, DWORD *perm);
PMM_API PMMSTATUS SetUserPermission(SHORT ID, DWORD *perm);
PMM_API PMMSTATUS ResetAccount(SHORT ID, QString NewPassword, BOOL ResetPassword);
PMM_API PMMSTATUS GetPolicy(T_PMMPOLICYDATA *PMMPolicyData);
PMM_API PMMSTATUS SetPolicy(T_PMMPOLICYDATA *PMMPolicyData);
PMM_API PMMSTATUS UndoSetPolicy();
PMM_API PMMSTATUS UseNewSetup(SHORT ConfigID);
PMM_API PMMSTATUS ValidateLogon(QString Username, QString Password, SHORT *ID);
PMM_API PMMSTATUS logoff(SHORT ID);
PMM_API PMMSTATUS SetUserPwd(SHORT ID, QString NewPassword, QString OldPassword);
PMM_API PMMSTATUS QueryPMMStatus(SYSTEMSTATE *systemState);
PMM_API PMMSTATUS QueryUser(SHORT ID, LOGDETAIL *UserLogDetails);
PMM_API PMMSTATUS ValidateArea(SHORT AreaNumber, SHORT ID, TV_BOOL *Result);
PMM_API PMMSTATUS SetMinimumAccessLevel(BYTE Level, SHORT *PrevLevel);
PMM_API PMMSTATUS ExpirePassword(SHORT ID);
PMM_API PMMSTATUS EnableFirstTimeUser(TV_BOOL Enable);
PMM_API PMMSTATUS DaysTillPasswordExpiry(SHORT ID, WORD *DaysToExpire);
PMM_API PMMSTATUS GetBitSts(SHORT AreaNumber, DWORD *PermPtr, TV_BOOL *pStatus);
PMM_API PMMSTATUS SetBitMask(SHORT AreaNumber, DWORD *PermPtr);
PMM_API PMMSTATUS ClearBitMask(SHORT AreaNumber, DWORD *PermPtr);
PMM_API PMMSTATUS GetPasswordStatus(QString szUsername, TV_BOOL *bResult);
PMM_API PMMSTATUS ValidatePasswordToPolicy(QString pPassword);
PMM_API PMMSTATUS GetPolicyRange(BYTE policytype, DWORD *dwHighLimit, DWORD *dwLowLimit);
#endif

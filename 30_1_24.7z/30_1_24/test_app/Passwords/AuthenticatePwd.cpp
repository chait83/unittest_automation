/****************************************************************************
 //										COPYRIGHT (c) 2017
 //								HONEYWELL INTERNATIONAL INC.
 //									ALL RIGHTS RESERVED
 //		Legal rights of Honeywell Inc. in this software is distinct from
 //	ownership of any medium in which the software is embodied. 
 //	Copyright notices must be reproduced in any copies authorized by 
 //	Honeywell International Inc.
 /*****************************************************************************/
/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module:		Authenticate Password
/// @n Filename:	AuthenticatePwd.cpp
/// @n Description:	Contains class implementation of Authentication of Password.
///
// **************************************************************************
/** Revision History ********************************************************
 Author		Date		Notes
 ------	------		------
 Usha		11.09.17	Created
 ***************************************************************************/
#include "AuthenticatePwd.h"
//#include "StringUtils.h"
//Authenticate Pwd Sha256 implementation
const DWORD MAX_INPUT_KEY_LEN = 256;
const DWORD MAX_HASH_LEN = 32;
const DWORD MIN_HASH_LEN = 8;
const QString CAuthenticatePwd::m_sSecureDelta = ("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"); //32 bit length
const DWORD CAuthenticatePwd::m_nSaltLength = sizeof(SALTDWSZ2BU_8);
const DWORD CAuthenticatePwd::m_nHashLength = sizeof(HASHDWSZ2BU_32);
CAuthenticatePwd::CAuthenticatePwd() : m_nHashBufferLength(m_nHashLength) {
	reset();
}
CAuthenticatePwd::CAuthenticatePwd(const CAuthenticatePwd &rhs) : m_nHashBufferLength(m_nHashLength) {
	if (rhs.isValid()) {
		rhs.getHash(m_uHash);
		rhs.getSalt(m_uSalt);
		m_bIsValid = true;
	}
}
CAuthenticatePwd::CAuthenticatePwd(const QString &strKeyPwd, const SALTDWSZ2BU_8 &uSalt) : m_nHashBufferLength(
		m_nHashLength) {
	reset();
	if ((true == isSaltValid(uSalt)) && (false == strKeyPwd.isEmpty())) {
		memcpy(m_uSalt.b, uSalt.b, m_nSaltLength);
		compute(strKeyPwd, false);
	}
}
CAuthenticatePwd::CAuthenticatePwd(const HASHDWSZ2BU_32 &uHash, const SALTDWSZ2BU_8 &uSalt) : m_nHashBufferLength(
		m_nHashLength) {
	reset();
	if (isHashValid(uHash) && isSaltValid(uSalt)) {
		memcpy(m_uHash.b, uHash.b, m_nHashBufferLength);
		memcpy(m_uSalt.b, uSalt.b, m_nSaltLength);
		m_bIsValid = true;
	}
}
CAuthenticatePwd::CAuthenticatePwd(const QString &strKeyPwd) : m_nHashBufferLength(m_nHashLength) {
	reset();
	if (false == strKeyPwd.isEmpty()) {
		compute(strKeyPwd, true);
	}
}
CAuthenticatePwd::~CAuthenticatePwd() {
	m_bIsValid = false;
}
void CAuthenticatePwd::operator =(const CAuthenticatePwd &rhs) {
	if (rhs.isValid()) {
		rhs.getHash(m_uHash);
		rhs.getSalt(m_uSalt);
		m_bIsValid = true;
	}
}
bool CAuthenticatePwd::operator ==(const CAuthenticatePwd &rhs) const {
	bool bIsEqual = false;
	if ((true == isValid()) && (true == rhs.isValid())) {
		if (memcmp(m_uHash.b, rhs.m_uHash.b, m_nHashBufferLength) == 0) {
			bIsEqual = true;
		}
	}
	return bIsEqual;
}
bool CAuthenticatePwd::isHashValid(const HASHDWSZ2BU_32 &uHash) {
	bool bRet = false;
	HASHDWSZ2BU_32 uDefHash;
	resetHash(uDefHash);
	if (memcmp(uHash.b, uDefHash.b, m_nHashLength) != 0) {
		bRet = true;
	}
	return bRet;
}
bool CAuthenticatePwd::isSaltValid(const SALTDWSZ2BU_8 &uSalt) {
	bool bRet = false;
	SALTDWSZ2BU_8 uDefSalt;
	resetSalt(uDefSalt);
	if (memcmp(uSalt.b, uDefSalt.b, m_nSaltLength) != 0) {
		bRet = true;
	}
	return bRet;
}
bool CAuthenticatePwd::compute(const QString &strKey, bool bGenerateSalt) {
	m_bIsValid = false;
	int nKeyLen = strKey.size();
	QString strPassword = EncodeToUTF8(strKey);
	QByteArray strPasswordA = strPassword.toUtf8();
	int nUtf8PwdLen = strPasswordA.length();
	BYTE pbPassword[MAX_INPUT_KEY_LEN];
	memset(pbPassword, 0, MAX_INPUT_KEY_LEN);
	UINT nAppendLength = 0;
	if (nUtf8PwdLen < m_nHashBufferLength) {
		nAppendLength = m_nHashBufferLength - nUtf8PwdLen - 1;
	} else if (nUtf8PwdLen < MAX_INPUT_KEY_LEN) {
		nAppendLength = MAX_INPUT_KEY_LEN - nUtf8PwdLen - 1;
	} else {
		//Are we getting Even more ?
	}
	QString strDef = EncodeToUTF8(m_sSecureDelta);
	QByteArray strDefA = strDef.toUtf8();
	strPasswordA.append(strDefA.right(nAppendLength));
	memcpy(pbPassword, strPasswordA.constData(), MAX_INPUT_KEY_LEN);
	if (computehash(m_uHash.b, &m_nHashBufferLength, pbPassword, strPasswordA.length(), m_uSalt.b, m_nSaltLength,
			bGenerateSalt)) {
		m_bIsValid = true;
	}
	return m_bIsValid;
}
bool CAuthenticatePwd::compare(const QString &strRegularPwd) {
	CAuthenticatePwd cAuthenticatePwd(strRegularPwd, m_uSalt);
	return (*this == cAuthenticatePwd);
}
void CAuthenticatePwd::getHash(HASHDWSZ2BU_32 &uHash) const {
	memcpy(uHash.b, m_uHash.b, m_nHashLength);
}
void CAuthenticatePwd::getSalt(SALTDWSZ2BU_8 &uSalt) const {
	memcpy(uSalt.b, m_uSalt.b, m_nSaltLength);
}
void CAuthenticatePwd::reset() {
	resetHash(m_uHash);
	resetSalt(m_uSalt);
	m_bIsValid = false;
}
void CAuthenticatePwd::resetHash(HASHDWSZ2BU_32 &uHash) {
	memset(uHash.b, 0x00, m_nHashLength);
}
void CAuthenticatePwd::resetSalt(SALTDWSZ2BU_8 &uSalt) {
	memset(uSalt.b, 0x00, m_nSaltLength);
}
bool CAuthenticatePwd::hashToHexString(const HASHDWSZ2BU_32 &uHash, QString &strHexString) {
	bool bRet = false;
	{
		bRet = byteArrayToHexString(uHash.b, m_nHashLength, strHexString);
	}
	return bRet;
}
bool CAuthenticatePwd::saltToHexString(const SALTDWSZ2BU_8 &uSalt, QString &strHexString) {
	bool bRet = false;
	{
		bRet = byteArrayToHexString(uSalt.b, m_nSaltLength, strHexString);
	}
	return bRet;
}
bool CAuthenticatePwd::hexStringToHash(const QString &strHexString, HASHDWSZ2BU_32 &uHash) {
	bool bRet = false;
	if (strHexString.length() == (m_nHashLength * 2)) {
		bRet = hexStringToByteArray(strHexString, uHash.b, m_nHashLength);
	}
	return bRet;
}
bool CAuthenticatePwd::hexStringToSalt(const QString &strHexString, SALTDWSZ2BU_8 &uSalt) {
	bool bRet = false;
	if (strHexString.length() == (m_nSaltLength * 2)) {
		bRet = hexStringToByteArray(strHexString, uSalt.b, m_nSaltLength);
	}
	return bRet;
}
bool CAuthenticatePwd::byteArrayToHexString(const BYTE *pbData, int nLen, QString &str) {
	bool bRet = false;
	if (NULL != pbData) {
		for (int i = 0; i < nLen; ++i) {
			QString hexS;
			hexS = QString::asprintf(("%02X"), pbData[i]);
			str += hexS;
		}
		if (str.length() == (2 * nLen)) {
			bRet = true;
		}
	}
	return bRet;
}
bool CAuthenticatePwd::hexStringToByteArray(const QString &strHexData, BYTE *pbData, int nLen) {
	bool bRet = false;
	if (NULL != pbData) {
		QByteArray strHex = QByteArray::fromHex(strHexData.toUtf8());
		int nHexLen = strHex.length();
		if (nLen == nHexLen) {
			//const wchar_t *pb = strHex.toLocal8Bit().data();
			for (int n = 0; n < nLen; n++) {
//				int nTest = -1;
//  swscanf_s(pb, ("%2x"), &nTest);
//				pb++;
//				pb++;
				pbData[n] = static_cast<BYTE>(strHex.at(n));
			}
			bRet = true;
		}
	}
	return bRet;
}
/****************************************************************************
 Method name: ComputeHash
 Description: Computes SHA256 hash of a given key. Salt can either be generated
 or be passed into the method.
 Parameters:
 BYTE *pbHashBuffer :OUTPUT: Buffer where the hash needs to be computed and filled. The hash buffer can be initialized before passing
 DWORD *pdwHashLen :INPUT/OUTPUT: Hash length size allocated for pbHashBuffer. The output will be the actual hash length
 const BYTE *pbKey :INPUT: key buffer that needs to be hashed
 DWORD dwKeyLength :INPUT: key length
 BYTE *pbSalt	:INPUT/OUTPUT: If bGenerateSalt is TRUE, this method generates the salt and stores here. Else, this is an input salt for hash calculation
 DWORD dwSaltLength :INPUT: Salt length
 BOOL bGenerateSalt : Flag to indicate if salt has to be generated and stored (TRUE) or existing salt has to be used (FALSE)at pbSalt. 
 Return:
 SUCCESS : 0 
 FAILURE : Error reason for failure
 ****************************************************************************/
BOOL CAuthenticatePwd::computehash(BYTE *pbHashBuffer, DWORD *pdwHashLen, const BYTE *pbKey, DWORD dwKeyLength,
		BYTE *pbSalt, DWORD dwSaltLength, BOOL bGenerateSalt) {
	//--------------------------------------------------------------------
	// Declare variables.
	HCRYPTPROV hCryptProv;
	HCRYPTHASH hHash;
	BOOL bErrorCode = TRUE;
	//Input Validations
	if (pbHashBuffer == NULL || pbKey == NULL || pbSalt == NULL) {
		bErrorCode = FALSE;
	}
	if (*pdwHashLen > MAX_HASH_LEN || *pdwHashLen < MIN_HASH_LEN) {
		bErrorCode = FALSE;
	}
	//--------------------------------------------------------------------
	// Get a handle to a cryptography provider context.
	if (CryptAcquireContext(&hCryptProv, NULL, NULL, PROV_RSA_AES, CRYPT_VERIFYCONTEXT)) {
		//("CryptAcquireContext complete.\n");
	} else {
		bErrorCode = FALSE;
		QString strError;
	}
	//--------------------------------------------------------------------
	// Acquire a hash object handle.
	if (CryptCreateHash(hCryptProv, CALG_SHA_256, 0, 0, &hHash)) {
		//("An empty hash object has been created. \n");
	} else {
		bErrorCode = FALSE;
	}
	//If salt generation requested, generate salt
	if (bGenerateSalt != FALSE) {
		if (CryptGenRandom(hCryptProv, dwSaltLength, pbSalt)) {
			//("Random sequence generated. \n");
		} else {
			bErrorCode = FALSE;
		}
	} else {
		//Else use salt sent by the caller
	}
	//Generate the hash for the key
	if (CryptHashData(hHash, pbKey, dwKeyLength, 0)) {
		//("The key has been added to the hash.\n");
	} else {
		bErrorCode = FALSE;
	}
	// Salt data has to be added by calling CryptHashData again.
	if (CryptHashData(hHash, pbSalt, dwSaltLength, 0)) {
		//("The salt has been added to the hash.\n");
	} else {
		bErrorCode = FALSE;
	}
	if (CryptGetHashParam(hHash, HP_HASHVAL, pbHashBuffer, pdwHashLen, 0)) {
	} else {
		bErrorCode = FALSE;
	}
	//--------------------------------------------------------------------
	// At this point, the content of pbKey and pbSalt has been added to the hash.
	if (hHash) {
		CryptDestroyHash(hHash);
	}
	//--------------------------------------------------------------------
	// After processing, hCryptProv and hHash must be released.
	if (hHash) {
		CryptDestroyHash(hHash);
	}
	if (hCryptProv) {
		CryptReleaseContext(hCryptProv, 0);
	}
	return bErrorCode;
}
//****************************************************************************
//	const QString   EncodeToUTF8( const QString   &rstrUNICODE_SOURCE )
///
/// Method used to convert unicode text into a UTF-8 representation (note: this will still need to
/// be converted using wcstombs
///
/// @param[in] 			const QString   &rstrUNICODE_SOURCE - The original unicode source string
/// 
/// @return				The string with all unicode characters converted to ascii/UTF-8 equivalents (note: this
///						string is still returned as WCHAR's although they will all be ascii values - call wcstombs
///						if you want ot convert this string in a normal character array)
///
//****************************************************************************
const QString CAuthenticatePwd::EncodeToUTF8(const QString &rstrUNICODE_SOURCE) {
	WORD ch;
	BYTE bt1, bt2, bt3, bt4, bt5, bt6;
	int n = 0;
	int nMax = rstrUNICODE_SOURCE.size();
	QString sFinal, sTemp;
	for (n = 0; n < nMax; ++n) {
		ch = (rstrUNICODE_SOURCE.at(n).unicode());
		if (ch == ('=')) {
			sTemp = QString::asprintf(("=%02X"), ch);
			sFinal += sTemp;
		} else if (ch < 128) {
			sFinal += rstrUNICODE_SOURCE.at(n);
		} else if (ch <= 2047) {
			bt1 = (BYTE) (192 + (ch / 64));
			bt2 = (BYTE) (128 + (ch % 64));
			sTemp = QString::asprintf(("=%02X=%02X"), bt1, bt2);
			sFinal += sTemp;
		} else if (ch <= 65535) {
			bt1 = (BYTE) (224 + (ch / 4096));
			bt2 = (BYTE) (128 + ((ch / 64) % 64));
			bt3 = (BYTE) (128 + (ch % 64));
			sTemp = QString::asprintf(("=%02X=%02X=%02X"), bt1, bt2, bt3);
			sFinal += sTemp;
		} else if (ch <= 2097151) {
			bt1 = (BYTE) (240 + (ch / 262144));
			bt2 = (BYTE) (128 + ((ch / 4096) % 64));
			bt3 = (BYTE) (128 + ((ch / 64) % 64));
			bt4 = (BYTE) (128 + (ch % 64));
			sTemp = QString::asprintf(("=%02X=%02X=%02X=%02X"), bt1, bt2, bt3, bt4);
			sFinal += sTemp;
		} else if (ch <= 67108863) {
			bt1 = (BYTE) (248 + (ch / 16777216));
			bt2 = (BYTE) (128 + ((ch / 262144) % 64));
			bt3 = (BYTE) (128 + ((ch / 4096) % 64));
			bt4 = (BYTE) (128 + ((ch / 64) % 64));
			bt5 = (BYTE) (128 + (ch % 64));
			sTemp = QString::asprintf(("=%02X=%02X=%02X=%02X=%02X"), bt1, bt2, bt3, bt4, bt5);
			sFinal += sTemp;
		} else if (ch <= 2147483647) {
			bt1 = (BYTE) (252 + (ch / 1073741824));
			bt2 = (BYTE) (128 + ((ch / 16777216) % 64));
			bt3 = (BYTE) (128 + ((ch / 262144) % 64));
			bt4 = (BYTE) (128 + ((ch / 4096) % 64));
			bt5 = (BYTE) (128 + ((ch / 64) % 64));
			bt6 = (BYTE) (128 + (ch % 64));
			sTemp = QString::asprintf(("=%02X=%02X=%02X=%02X=%02X=%02X"), bt1, bt2, bt3, bt4, bt5, bt6);
			sFinal += sTemp;
		}
	}
	return sFinal;
}

/******************************************************************************************
 /// @file CPolicyDataManager.cpp
 /// ***************************************************************************************
 /// © Honeywell Trendview
 /// ***************************************************************************************
 /// @n Module	:	 Password Management Module.
 /// @n Filename	:  CPolicyDataManager.cpp
 /// @n Desc		:	 CPolicyDataManager is a class which implements all 
 ///					 the methods related to Policy data Queries and modifications.
 ///
 // ***************************************************************************************
 // Revision History
 // ***************************************************************************************
 // $Log[1]:
 //  13  Stability Project 1.8.1.3 7/2/2011 4:56:24 PM Hemant(HAIL) 
 // Stability Project: Recorder source has been upgraded from IL
 //  version of firmware to JF version of firmware.
 // $Log" for functions
 // $
 //
 // ***************************************************************************************
 /******************************************************************************************
 COPYRIGHT (c) 2004
 HONEYWELL INC.,
 ALL RIGHTS RESERVED
 This software is a copyrighted work and/or information protected
 as a trade secret. Legal rights of Honeywell Inc. in this
 software is distinct from ownership of any medium in which the
 software is embodied. Copyright or trade secret notices included
 must be reproduced in any copies authorized by Honeywell Inc.
 The information in this software is subject to change without
 notice and should not be considered as a commitment by Honeywell
 Inc.
 ******************************************************************************************/
/**************** Headers Inclusion ***************/
#include "CPasswordManager.h"
#include "CPolicyDataManager.h"
#include "CUserValidation.h"
/*************** End of Header Declaration ********/
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
/*************** Global Declarations **************/
//extern CUserValidation	g_pmmData;
//extern QLibrary			glbDllHandle;			///< Global Tracer Handle
//Global Tracer functions
//extern fnTraceStart		TraceStart;				///< Global function pointer to start Tracer Module
//extern fnTrace			Trace;					///< Global function pointer to log traces
//extern fnTraceStop		TraceStop;				///< Global function pointer to stop Tracer Module
/**************End of Global Declaration************/
//*************************************************************************************************
// CPolicyDataManager :: CPolicyDataManager()	 
///
//**************************************************************************************************
//**********************************************************************************************
// Revision History
//**********************************************************************************************
// 
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad	  
//  
//
//**********************************************************************************************
//**********************************************************************************************
CPolicyDataManager::CPolicyDataManager() {
	LOG_INFO (PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CPolicyDataManager - Constructor"));
	InitialisePolicyData();
	m_gPolicySts = FALSE;
}
//*************************************************************************************************
// CPolicyDataManager :: ~CPolicyDataManager()	 
///
//**************************************************************************************************
//**********************************************************************************************
// Revision History
//**********************************************************************************************
// 
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad	  
//  
//
//**********************************************************************************************
//**********************************************************************************************
CPolicyDataManager::~CPolicyDataManager() {
	LOG_INFO (PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CPolicyDataManager - Destructor"));
}
//***************************************************************************************
// void CPolicyDataManager::InitialisePolicyData()
/// Initialises all the variables of the CFR and NonCFR mode.
/// 
/// @return		- NA - 
/// 
/// @todo - 
///
//**************************************************************************************
// Revision History
// ************************************************************************************
// 
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad	  
//  
//
// ************************************************************************************
//**************************************************************************************
void CPolicyDataManager::InitialisePolicyData() {
	/* For CFR mode Default policy type */
	LOG_INFO (PMM_qDebugR_MODE, ("PMM : ----------------------CPolicyDataManager::InitialisePolicyData -------------------------"));
	wcsncpy(m_stCFRBasedPolicy.GPolicyData.userLevelLables[0], L"Administrator", GENERALPOLICY_USERLEVELLABLES_LEN);
	wcsncpy(m_stCFRBasedPolicy.GPolicyData.userLevelLables[1], L"Supervisor", GENERALPOLICY_USERLEVELLABLES_LEN);
	wcsncpy(m_stCFRBasedPolicy.GPolicyData.userLevelLables[2], L"Engineer", GENERALPOLICY_USERLEVELLABLES_LEN);
	wcsncpy(m_stCFRBasedPolicy.GPolicyData.userLevelLables[3], L"Technician", GENERALPOLICY_USERLEVELLABLES_LEN);
	wcsncpy(m_stCFRBasedPolicy.GPolicyData.userLevelLables[4], L"Operator", GENERALPOLICY_USERLEVELLABLES_LEN);
	wcsncpy(m_stCFRBasedPolicy.GPolicyData.userLevelLables[5], L"Unrestricted", GENERALPOLICY_USERLEVELLABLES_LEN);
	m_stCFRBasedPolicy.PwdPolicyData.expiryDays = CFR_EXPIRY_DAYS;
	m_stCFRBasedPolicy.PwdPolicyData.expiryWarning = CFR_EXPIRY_WARNING;
	m_stCFRBasedPolicy.PwdPolicyData.MaxRetry = CFR_MAX_RETRY;
	m_stCFRBasedPolicy.PwdPolicyData.PreviousPwd = CFR_PREV_PWD;
	m_stCFRBasedPolicy.PwdPolicyData.PwrdAlphabet = CFR_MIN_ALPHA;
	m_stCFRBasedPolicy.PwdPolicyData.pwrdMaxLen = CFR_MAX_LENGTH;
	m_stCFRBasedPolicy.PwdPolicyData.PwrdNumeric = CFR_MIN_NUMBER;		// Indicates the maximum numbers allowed.
	m_stCFRBasedPolicy.PwdPolicyData.PwrdMinLen = CFR_MIN_LENGTH;
	m_stCFRBasedPolicy.PwdPolicyData.PwrdSplchar = CFR_MIN_NONALPHA;	// Special characters in password.
	m_stCFRBasedPolicy.UserPolicyData.UmaxLen = USER_MAX_LEN;		// Maximum length of Username.
	m_stCFRBasedPolicy.UserPolicyData.UminLen = USER_MIN_LENGTH;		// Minimum length of UserName.*/
	m_stCFRBasedPolicy.GPolicyData.CFRmode = CFRMODE;
	m_stCFRBasedPolicy.GPolicyData.ftpAccess = FTPACCESS;
	m_stCFRBasedPolicy.GPolicyData.UILogOffTime = CFR_UI_LOGOFF_TIME;
	m_stCFRBasedPolicy.GPolicyData.WebLogoffTime = CFR_WEB_LOGOFF_TIME;
	m_stCFRBasedPolicy.GPolicyData.Padding = 0;
	//m_stCFRBasedPolicy.GPolicyData.UnReserved		= 0;
	/* For NON-CFR mode Default policy type */
	m_stNONCFRPolicy.GPolicyData.CFRmode = NONCFRMODE;
	m_stNONCFRPolicy.GPolicyData.ftpAccess = FTPACCESS;
	m_stNONCFRPolicy.GPolicyData.UILogOffTime = NONCFR_UI_LOGOFF_TIME;
	m_stNONCFRPolicy.GPolicyData.WebLogoffTime = NONCFR_WEB_LOGOFF_TIME;
	wcsncpy(m_stNONCFRPolicy.GPolicyData.userLevelLables[0], L"Administrator", GENERALPOLICY_USERLEVELLABLES_LEN);
	wcsncpy(m_stNONCFRPolicy.GPolicyData.userLevelLables[1], L"Supervisor", GENERALPOLICY_USERLEVELLABLES_LEN);
	wcsncpy(m_stNONCFRPolicy.GPolicyData.userLevelLables[2], L"Engineer", GENERALPOLICY_USERLEVELLABLES_LEN);
	wcsncpy(m_stNONCFRPolicy.GPolicyData.userLevelLables[3], L"Technician", GENERALPOLICY_USERLEVELLABLES_LEN);
	wcsncpy(m_stNONCFRPolicy.GPolicyData.userLevelLables[4], L"Operator", GENERALPOLICY_USERLEVELLABLES_LEN);
	wcsncpy(m_stNONCFRPolicy.GPolicyData.userLevelLables[5], L"Unrestricted", GENERALPOLICY_USERLEVELLABLES_LEN);
	m_stNONCFRPolicy.PwdPolicyData.expiryDays = NONCFR_EXPIRY_DAYS;
	m_stNONCFRPolicy.PwdPolicyData.expiryWarning = NONCFR_EXPIRY_WARNING;
	m_stNONCFRPolicy.PwdPolicyData.MaxRetry = NONCFR_MAX_RETRY;
	m_stNONCFRPolicy.PwdPolicyData.PreviousPwd = NONCFR_PREV_PWD;
	m_stNONCFRPolicy.PwdPolicyData.PwrdAlphabet = NONCFR_MIN_ALPHA;
	m_stNONCFRPolicy.PwdPolicyData.pwrdMaxLen = NONCFR_MAX_LENGTH;
	m_stNONCFRPolicy.PwdPolicyData.PwrdNumeric = NONCFR_MIN_NUMBER;		// Indicates the maximum numbers allowed.
	m_stNONCFRPolicy.PwdPolicyData.PwrdMinLen = NONCFR_MIN_LENGTH;
	m_stNONCFRPolicy.PwdPolicyData.PwrdSplchar = NONCFR_MIN_NONALPHA;	// Special characters in password.
	m_stNONCFRPolicy.UserPolicyData.UmaxLen = NONCFR_USER_MAX_LEN;		// Maximum length of Username.
	m_stNONCFRPolicy.UserPolicyData.UminLen = NONCFR_USER_MIN_LENGTH;		// Minimum length of UserName.
	/* Initialise all the Pointers to ZERO */
	m_stPolicyDataWorking = NULL;
	m_stPolicyDataCurrent = NULL;
}
//***************************************************************************************
// PMMERROR CPolicyDataManager :: GetPolicyError(POLICY_STATUS sts)
///
/// Converts the policy error type to PMMERROR format.
///
/// @return	 PMMERROR - Returns appropriate error code.
/// 
/// @todo - 
///
//**************************************************************************************
// Revision History
// ************************************************************************************
// 
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad	  
//  
//
// ************************************************************************************
//**************************************************************************************
PMMERROR CPolicyDataManager::GetPolicyError(POLICY_STATUS sts) {
	PMMERROR varPmmStatus = PMM_FAILED; //coverity fix varPmmStatus = PMM_FAILED CID:774328
	LOG_INFO (PMM_qDebugR_MODE, ("PMM : ----------------------CPolicyDataManager::GetPolicyError----------------------"));
	switch (sts) {
	case P_STATUS_OK: {
		varPmmStatus = PMM_SUCCESS;
		break;
	}
	case P_STATUS_FAIL: {
		varPmmStatus = PMM_FAILED;
		break;
	}
	case P_INVALID_POLICY: {
		varPmmStatus = PMM_INVALID_POLICY_DATA;
		break;
	}
	case P_POLICY_NOT_INITIALISED: {
		varPmmStatus = PMM_FAILED;
		break;
	}
	default: {
		break;
	}
	}
	return varPmmStatus;
}
POLICY_STATUS CPolicyDataManager::CheckSplCondition(SHORT CheckPolicy) {
	POLICY_STATUS varPmmStatus = P_STATUS_OK;
	switch (CheckPolicy) {
	case MAX_USERNAME_PASSWORD_WARNING_CHECK: {
		if (m_stPolicyDataWorking->UserPolicyData.UmaxLen >= m_stPolicyDataWorking->UserPolicyData.UminLen) {
			if (m_stPolicyDataWorking->PwdPolicyData.pwrdMaxLen >= m_stPolicyDataWorking->PwdPolicyData.PwrdMinLen) {
				if (m_stPolicyDataWorking->PwdPolicyData.expiryDays != ZERO) {
					if (m_stPolicyDataWorking->PwdPolicyData.expiryDays
							>= m_stPolicyDataWorking->PwdPolicyData.expiryWarning) {
						LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager:: SUCCESS : CheckPolicy Check for CFR MAX_USERNAME_PASSWORD_CHECK"));
						varPmmStatus = P_STATUS_OK;
					} else {
						varPmmStatus = P_INVALID_POLICY;
						LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CheckPolicy FAILED : MAX_USERNAME_PASSWORD_CHECK"));
					}
				}
			} else {
				varPmmStatus = P_INVALID_POLICY;
				LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CheckPolicy FAILED : MAX_USERNAME_PASSWORD_CHECK"));
			}
		} else {
			varPmmStatus = P_INVALID_POLICY;
			LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CheckPolicy FAILED : MAX_USERNAME_PASSWORD_CHECK"));
		}
		break;
	}
	case CHECK_GROUP_NAMES_ARRAY_CHECK: {
		short Length = 0, row = 0;
		for (row = 0; ((row < GENERALPOLICY_USERLEVELLABLES_SIZE) && (varPmmStatus == P_STATUS_OK)); row++) {
			Length = wcslen((WCHAR*) m_stPolicyDataWorking->GPolicyData.userLevelLables[row]);
			if ((Length > (GENERALPOLICY_USERLEVELLABLES_LEN - 1)) || (Length == ZERO)) {
				LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CheckPolicy FAILED : CHECK_GROUP_NAMES_ARRAY_CHECK"));
				varPmmStatus = P_INVALID_POLICY;
			}
		}
		break;
	}
	case CHECK_PASSWORD_LENGTH: {
		if (m_stPolicyDataWorking->PwdPolicyData.pwrdMaxLen
				>= (m_stPolicyDataWorking->PwdPolicyData.PwrdAlphabet + m_stPolicyDataWorking->PwdPolicyData.PwrdNumeric
						+ m_stPolicyDataWorking->PwdPolicyData.PwrdSplchar)) {
			LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager:: SUCCESS : CheckPolicy Check for CFR CHECK_PASSWORD_LENGTH"));
			varPmmStatus = P_STATUS_OK;
		} else {
			varPmmStatus = P_INVALID_POLICY;
			LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CheckPolicy FAILED : CHECK_PASSWORD_LENGTH"));
		}
		break;
	}
	default: {
		LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CheckPolicy FAILED : UNHANDLED case"));
		break;
	}
	}
	return varPmmStatus;
}
//***************************************************************************************
// POLICY_STATUS CPolicyDataManager::CheckPolicy(TV_BOOL lModeOfRecorder) 
///
/// Check for all the Policy conditions against the Hardcoded policy in the PMM.
///	Returns P_STATUS_OK if Successful or returns appropriate Error code.
///
/// @param[in]	lModeOfRecorder	- Mode in which recorder is working.	
///
/// @return		POLICY_STATUS	- returns the appropriate error code if failed 
///								  or returns P_STATUS_OK.
/// 
/// @todo - 
///
//**************************************************************************************
// Revision History
// ************************************************************************************
// 
//  1  V6 Firmware1	 6/23/2004		Shyam Prasad	  
//  
//
// ************************************************************************************
//**************************************************************************************
POLICY_STATUS CPolicyDataManager::CheckPolicy(TV_BOOL lModeOfRecorder) {
	LOG_INFO(PMM_qDebugR_MODE, ("PMM :------------------------------ CPolicyDataManager::CheckPolicy ---------------------------------"));
	POLICY_STATUS varPmmStatus = P_STATUS_OK;
	try {
		for (SHORT CheckPolicy = UI_LOGOFF_TIME;
				((CheckPolicy <= CHECK_PASSWORD_LENGTH) && (varPmmStatus != P_INVALID_POLICY)); CheckPolicy++) {
			switch (CheckPolicy) {
			case UI_LOGOFF_TIME: {
				if (lModeOfRecorder) {
					LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CheckPolicy Check for UI_LOGOFF_TIME"));
					if ((m_stCFRBasedPolicy.GPolicyData.UILogOffTime == ZERO)
							&& (ZERO == m_stPolicyDataWorking->GPolicyData.UILogOffTime)) {
						LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager:: SUCCESS : CheckPolicy Check for CFR UI_LOGOFF_TIME"));
						varPmmStatus = P_STATUS_OK;
					} else if ((CFRMIN_UI_LOGOFF_TIME <= m_stPolicyDataWorking->GPolicyData.UILogOffTime)
							&& (m_stPolicyDataWorking->GPolicyData.UILogOffTime <= CFRMAX_UI_LOGOFF_TIME)) {
						LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager:: SUCCESS : CheckPolicy Check for CFR UI_LOGOFF_TIME"));
						varPmmStatus = P_STATUS_OK;
					} else {
						LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager:: FAILED : CFR UI_LOGOFF_TIME"));
						varPmmStatus = P_INVALID_POLICY;
					}
				} else {
					LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CheckPolicy Check for UI_LOGOFF_TIME"));
					if ((m_stNONCFRPolicy.GPolicyData.UILogOffTime == ZERO)
							&& (ZERO == m_stPolicyDataWorking->GPolicyData.UILogOffTime)) {
						LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager:: SUCCESS : CheckPolicy Check for CFR UI_LOGOFF_TIME"));
						varPmmStatus = P_STATUS_OK;
					} else if ((NONCFR_MIN_UI_LOGOFF_TIME <= m_stPolicyDataWorking->GPolicyData.UILogOffTime)
							&& (m_stPolicyDataWorking->GPolicyData.UILogOffTime <= NONCFR_MAX_UI_LOGOFF_TIME)) {
						LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager:: SUCCESS : CheckPolicy Check for CFR UI_LOGOFF_TIME"));
						varPmmStatus = P_STATUS_OK;
					} else {
						LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager:: FAILED : CFR UI_LOGOFF_TIME"));
						varPmmStatus = P_INVALID_POLICY;
					}
				}
				break;
			}
			case EXPIRY_DAYS: {
				LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CheckPolicy Check for CFR EXPIRY_DAYS"));
				if (lModeOfRecorder) {
					if ((CFRMIN_EXPIRY_DAYS <= m_stPolicyDataWorking->PwdPolicyData.expiryDays)
							&& (m_stPolicyDataWorking->PwdPolicyData.expiryDays <= CFRMAX_EXPIRY_DAYS)) {
						LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager:: SUCCESS : CheckPolicy Check for CFR EXPIRY_DAYS"));
						varPmmStatus = P_STATUS_OK;
					} else {
						LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager:: SUCCESS : FAILED : CFR EXPIRY_DAYS"));
						varPmmStatus = P_INVALID_POLICY;
					}
				} else {
					if ((NONCFR_MIN_EXPIRY_DAYS <= m_stPolicyDataWorking->PwdPolicyData.expiryDays)
							&& (m_stPolicyDataWorking->PwdPolicyData.expiryDays <= NONCFR_MAX_EXPIRY_DAYS)) {
						LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager:: SUCCESS : CheckPolicy Check for CFR EXPIRY_DAYS"));
						varPmmStatus = P_STATUS_OK;
					} else {
						LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager:: SUCCESS : FAILED : CFR EXPIRY_DAYS"));
						varPmmStatus = P_INVALID_POLICY;
					}
				}
				break;
			}
			case EXPIRY_WARNING: {
				LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CheckPolicy Check for CFR EXPIRY_WARNING"));
				if (lModeOfRecorder) {
					if ((CFRMIN_EXPIRY_WARNING <= m_stPolicyDataWorking->PwdPolicyData.expiryWarning)
							&& (m_stPolicyDataWorking->PwdPolicyData.expiryWarning <= CFRMAX_EXPIRY_WARNING)) {
						LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager:: SUCCESS : CheckPolicy Check for CFR EXPIRY_WARNING"));
						varPmmStatus = P_STATUS_OK;
					} else {
						varPmmStatus = P_INVALID_POLICY;
						LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CheckPolicy P_STATUS_FAIL : CFR EXPIRY_WARNING"));
					}
				} else {
					if ((NONCFR_MIN_EXPIRY_WARNING <= m_stPolicyDataWorking->PwdPolicyData.expiryWarning)
							&& (m_stPolicyDataWorking->PwdPolicyData.expiryWarning <= NONCFR_MAX_EXPIRY_WARNING)) {
						LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager:: SUCCESS : CheckPolicy Check for CFR EXPIRY_WARNING"));
						varPmmStatus = P_STATUS_OK;
					} else {
						varPmmStatus = P_INVALID_POLICY;
						LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CheckPolicy P_STATUS_FAIL : CFR EXPIRY_WARNING"));
					}
				}
				break;
			}
			case MAXIMUM_RETRY: {
				LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CheckPolicy Check for CFR MAXIMUM_RETRY"));
				if (lModeOfRecorder) {
					if ((CFRMIN_RETRY <= m_stPolicyDataWorking->PwdPolicyData.MaxRetry)
							&& (m_stPolicyDataWorking->PwdPolicyData.MaxRetry <= CFRMAX_RETRY)) {
						LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager:: SUCCESS : CheckPolicy Check for CFR MAXIMUM_RETRY"));
						varPmmStatus = P_STATUS_OK;
					} else {
						varPmmStatus = P_INVALID_POLICY;
						LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CheckPolicy FAILED : CFR MAXIMUM_RETRY"));
					}
				} else {
					if ((NONCFR_MIN_RETRY <= m_stPolicyDataWorking->PwdPolicyData.MaxRetry)
							&& (m_stPolicyDataWorking->PwdPolicyData.MaxRetry <= NONCFR_MAX_RETRY)) {
						LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager:: SUCCESS : CheckPolicy Check for CFR MAXIMUM_RETRY"));
						varPmmStatus = P_STATUS_OK;
					} else {
						varPmmStatus = P_INVALID_POLICY;
						LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CheckPolicy FAILED : CFR MAXIMUM_RETRY"));
					}
				}
				break;
			}
			case MINIMUM_PREVIOUS_PASSWORD: {
				LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CheckPolicy check for PREVIOUS_PASSWORD"));
				if (lModeOfRecorder) {
					if ((CFRMIN_PREVIOUS_PASSWORD <= m_stPolicyDataWorking->PwdPolicyData.PreviousPwd)
							&& (m_stPolicyDataWorking->PwdPolicyData.PreviousPwd <= CFRMAX_PREVIOUS_PASSWORD)) {
						LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager:: SUCCESS : CheckPolicy Check for CFR PREVIOUS_PASSWORD"));
						varPmmStatus = P_STATUS_OK;
					} else {
						varPmmStatus = P_INVALID_POLICY;
						LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CheckPolicy FAILED : PREVIOUS_PASSWORD"));
					}
				} else {
					if ((NONCFR_MIN_PREVIOUS_PASSWORD <= m_stPolicyDataWorking->PwdPolicyData.PreviousPwd)
							&& (m_stPolicyDataWorking->PwdPolicyData.PreviousPwd <= NONCFR_MAX_PREVIOUS_PASSWORD)) {
						LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager:: SUCCESS : CheckPolicy Check for CFR PREVIOUS_PASSWORD"));
						varPmmStatus = P_STATUS_OK;
					} else {
						varPmmStatus = P_INVALID_POLICY;
						LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CheckPolicy FAILED : PREVIOUS_PASSWORD"));
					}
				}
				break;
			}
			case MINIMUM_PASSWORD_ALPHA: {
				LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CheckPolicy Check for MINIMUM_PASSWORD_ALPHA"));
				if (lModeOfRecorder) {
					if ((CFRMIN_PASSWORD_ALPHA <= m_stPolicyDataWorking->PwdPolicyData.PwrdAlphabet)
							&& (m_stPolicyDataWorking->PwdPolicyData.PwrdAlphabet <= CFRMAX_PASSWORD_ALPHA)) {
						LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager:: SUCCESS : CheckPolicy Check for CFR MINIMUM_PASSWORD_ALPHA"));
						varPmmStatus = P_STATUS_OK;
					} else {
						varPmmStatus = P_INVALID_POLICY;
						LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CheckPolicy FAILED : MINIMUM_PASSWORD_ALPHA"));
					}
				} else {
					if ((NONCFR_MIN_PASSWORD_ALPHA <= m_stPolicyDataWorking->PwdPolicyData.PwrdAlphabet)
							&& (m_stPolicyDataWorking->PwdPolicyData.PwrdAlphabet <= NONCFR_MAX_PASSWORD_ALPHA)) {
						LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager:: SUCCESS : CheckPolicy Check for CFR MINIMUM_PASSWORD_ALPHA"));
						varPmmStatus = P_STATUS_OK;
					} else {
						varPmmStatus = P_INVALID_POLICY;
						LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CheckPolicy FAILED : MINIMUM_PASSWORD_ALPHA"));
					}
				}
				break;
			}
			case MIMIMUM_PASSWORD_NUMERICS: {
				LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CheckPolicy Check for MINIMUM_PASSWORD_NUMERICS"));
				if (lModeOfRecorder) {
					if ((CFR_MIN_PASSWORD_NUMERICS <= m_stPolicyDataWorking->PwdPolicyData.PwrdNumeric)
							&& (m_stPolicyDataWorking->PwdPolicyData.PwrdNumeric <= CFR_MAX_PASSWORD_NUMERICS)) {
						LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager:: SUCCESS : CheckPolicy Check for CFR MIMIMUM_PASSWORD_NUMERICS"));
						varPmmStatus = P_STATUS_OK;
					} else {
						varPmmStatus = P_INVALID_POLICY;
						LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CheckPolicy FAILED : MIMIMUM_PASSWORD_NUMERICS"));
					}
				} else {
					if ((NONCFR_MIN_PASSWORD_NUMERICS <= m_stPolicyDataWorking->PwdPolicyData.PwrdNumeric)
							&& (m_stPolicyDataWorking->PwdPolicyData.PwrdNumeric <= NONCFR_MAX_PASSWORD_NUMERICS)) {
						LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager:: SUCCESS : CheckPolicy Check for CFR MIMIMUM_PASSWORD_NUMERICS"));
						varPmmStatus = P_STATUS_OK;
					} else {
						varPmmStatus = P_INVALID_POLICY;
						LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CheckPolicy FAILED : MIMIMUM_PASSWORD_NUMERICS"));
					}
				}
				break;
			}
			case MINIMUM_PASSWORD_LENGTH: {
				LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CheckPolicy Check for MINIMUM_PASSWORD_LENGTH"));
				if (lModeOfRecorder) {
					if ((CFR_MIN_MINPASSWORD_LENGTH <= m_stPolicyDataWorking->PwdPolicyData.PwrdMinLen)
							&& (m_stPolicyDataWorking->PwdPolicyData.PwrdMinLen <= CFR_MAX_MINPASSWORD_LENGTH)) {
						LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager:: SUCCESS : CheckPolicy Check for CFR MINIMUM_PASSWORD_LENGTH"));
						varPmmStatus = P_STATUS_OK;
					} else {
						varPmmStatus = P_INVALID_POLICY;
						LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CheckPolicy FAILED : MINIMUM_PASSWORD_LENGTH"));
					}
				} else {
					if ((NONCFR_MIN_MINPASSWORD_LENGTH <= m_stPolicyDataWorking->PwdPolicyData.PwrdMinLen)
							&& (m_stPolicyDataWorking->PwdPolicyData.PwrdMinLen <= NONCFR_MAX_MINPASSWORD_LENGTH)) {
						LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager:: SUCCESS : CheckPolicy Check for CFR MINIMUM_PASSWORD_LENGTH"));
						varPmmStatus = P_STATUS_OK;
					} else {
						varPmmStatus = P_INVALID_POLICY;
						LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CheckPolicy FAILED : MINIMUM_PASSWORD_LENGTH"));
					}
				}
				break;
			}
			case MAXIMUM_PASSWORD_LENGTH: {
				LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CheckPolicy Check for MAXIMUM_PASSWORD_LENGTH"));
				if (lModeOfRecorder) {
					if ((CFR_MIN_MAXPASSWORD_LENGTH <= m_stPolicyDataWorking->PwdPolicyData.pwrdMaxLen)
							&& (m_stPolicyDataWorking->PwdPolicyData.pwrdMaxLen <= CFR_MAX_MAXPASSWORD_LENGTH)) {
						LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager:: SUCCESS : CheckPolicy Check for CFR MAXIMUM_PASSWORD_LENGTH"));
						varPmmStatus = P_STATUS_OK;
					} else {
						varPmmStatus = P_INVALID_POLICY;
						LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CheckPolicy FAILED : MAXIMUM_PASSWORD_LENGTH"));
					}
				} else {
					if ((NONCFR_MIN_MAXPASSWORD_LENGTH <= m_stPolicyDataWorking->PwdPolicyData.pwrdMaxLen)
							&& (m_stPolicyDataWorking->PwdPolicyData.pwrdMaxLen <= NONCFR_MAX_MAXPASSWORD_LENGTH)) {
						LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager:: SUCCESS : CheckPolicy Check for CFR MAXIMUM_PASSWORD_LENGTH"));
						varPmmStatus = P_STATUS_OK;
					} else {
						varPmmStatus = P_INVALID_POLICY;
						LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CheckPolicy FAILED : MAXIMUM_PASSWORD_LENGTH"));
					}
				}
				break;
			}
			case MINIMUM_SPECIAL_CHARACTER: {
				LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CheckPolicy Check for MINIMUM_SPECIAL_CHARACTER"));
				if (lModeOfRecorder) {
					if ((CFR_MIN_SPECIAL_CHARACTER <= m_stPolicyDataWorking->PwdPolicyData.PwrdSplchar)
							&& (m_stPolicyDataWorking->PwdPolicyData.PwrdSplchar <= CFR_MAX_SPECIAL_CHARACTER)) {
						LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager:: SUCCESS : CheckPolicy Check for CFR MINIMUM_SPECIAL_CHARACTER"));
						varPmmStatus = P_STATUS_OK;
					} else {
						varPmmStatus = P_INVALID_POLICY;
						LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CheckPolicy FAILED : MINIMUM_SPECIAL_CHARACTER"));
					}
				} else {
					if ((NONCFR_MIN_SPECIAL_CHARACTER <= m_stPolicyDataWorking->PwdPolicyData.PwrdSplchar)
							&& (m_stPolicyDataWorking->PwdPolicyData.PwrdSplchar <= NONCFR_MAX_SPECIAL_CHARACTER)) {
						LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager:: SUCCESS : CheckPolicy Check for CFR MINIMUM_SPECIAL_CHARACTER"));
						varPmmStatus = P_STATUS_OK;
					} else {
						varPmmStatus = P_INVALID_POLICY;
						LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CheckPolicy FAILED : MINIMUM_SPECIAL_CHARACTER"));
					}
				}
				break;
			}
			case MAXIMUM_USER_NAME_LENGTH: {
				LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CheckPolicy Check for MAXIMUM_USER_NAME_LENGTH"));
				if (lModeOfRecorder) {
					if ((CFR_MIN_MAXUSER_NAME_LENGTH <= m_stPolicyDataWorking->UserPolicyData.UmaxLen)
							&& (m_stPolicyDataWorking->UserPolicyData.UmaxLen <= CFR_MAX_MAXUSER_NAME_LENGTH)) {
						LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager:: SUCCESS : CheckPolicy Check for CFR MAXIMUM_USER_NAME_LENGTH"));
						varPmmStatus = P_STATUS_OK;
					} else {
						varPmmStatus = P_INVALID_POLICY;
						LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CheckPolicy FAILED : MAXIMUM_USER_NAME_LENGTH"));
					}
				} else {
					if ((NONCFR_MIN_MAXUSER_NAME_LENGTH <= m_stPolicyDataWorking->UserPolicyData.UmaxLen)
							&& (m_stPolicyDataWorking->UserPolicyData.UmaxLen <= NONCFR_MAX_MAXUSER_NAME_LENGTH)) {
						LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager:: SUCCESS : CheckPolicy Check for CFR MAXIMUM_USER_NAME_LENGTH"));
						varPmmStatus = P_STATUS_OK;
					} else {
						varPmmStatus = P_INVALID_POLICY;
						LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CheckPolicy FAILED : MAXIMUM_USER_NAME_LENGTH"));
					}
				}
				break;
			}
			case MINIMUM_USER_NAME_LENGTH: {
				LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CheckPolicy Check for MINIMUM_USER_NAME_LENGTH"));
				if (lModeOfRecorder) {
					if ((CFR_MIN_MINUSER_NAME_LENGTH <= m_stPolicyDataWorking->UserPolicyData.UminLen)
							&& (m_stPolicyDataWorking->UserPolicyData.UminLen <= CFR_MAX_MINUSER_NAME_LENGTH)) {
						LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager:: SUCCESS : CheckPolicy Check for CFR MINIMUM_USER_NAME_LENGTH"));
						varPmmStatus = P_STATUS_OK;
					} else {
						varPmmStatus = P_INVALID_POLICY;
						LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CheckPolicy FAILED : MINIMUM_USER_NAME_LENGTH"));
					}
				} else {
					if ((NONCFR_MIN_MINUSER_NAME_LENGTH <= m_stPolicyDataWorking->UserPolicyData.UminLen)
							&& (m_stPolicyDataWorking->UserPolicyData.UminLen <= NONCFR_MAX_MINUSER_NAME_LENGTH)) {
						LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager:: SUCCESS : CheckPolicy Check for CFR MINIMUM_USER_NAME_LENGTH"));
						varPmmStatus = P_STATUS_OK;
					} else {
						varPmmStatus = P_INVALID_POLICY;
						LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CheckPolicy FAILED : MINIMUM_USER_NAME_LENGTH"));
					}
				}
				break;
			}
			case WEB_LOGOFF_TIME: {
				LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CheckPolicy Check for WEB_LOGOFF_TIME"));
				if (lModeOfRecorder) {
					if ((m_stCFRBasedPolicy.GPolicyData.WebLogoffTime == ZERO)
							&& (ZERO == m_stPolicyDataWorking->GPolicyData.WebLogoffTime)) {
						LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager:: SUCCESS : CheckPolicy Check for CFR UI_LOGOFF_TIME"));
						varPmmStatus = P_STATUS_OK;
					} else if ((CFRMIN_WEB_LOGOFF_TIME <= m_stPolicyDataWorking->GPolicyData.WebLogoffTime)
							&& (m_stPolicyDataWorking->GPolicyData.WebLogoffTime <= CFRMAX_WEB_LOGOFF_TIME)) {
						LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager:: SUCCESS : CheckPolicy Check for CFR CFRMAX_MINIMUM_WEB_LOGOFF_TIME"));
						varPmmStatus = P_STATUS_OK;
					} else {
						varPmmStatus = P_INVALID_POLICY;
						LOG_ERROR(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager::CheckPolicy FAILED : WEB_LOGOFF_TIME"));
					}
				} else {
					if ((m_stNONCFRPolicy.GPolicyData.WebLogoffTime == ZERO)
							&& (ZERO == m_stPolicyDataWorking->GPolicyData.WebLogoffTime)) {
						LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager:: SUCCESS : CheckPolicy Check for CFR UI_LOGOFF_TIME"));
						varPmmStatus = P_STATUS_OK;
					} else if ((NONCFR_MIN_WEB_LOGOFF_TIME <= m_stPolicyDataWorking->GPolicyData.WebLogoffTime)
							&& (m_stPolicyDataWorking->GPolicyData.WebLogoffTime <= NONCFR_MAX_WEB_LOGOFF_TIME)) {
						LOG_INFO(PMM_qDebugR_MODE, ("PMM : CPolicyDataManager:: SUCCESS : CheckPolicy Check for CFR CFRMAX_MINIMUM_WEB_LOGOFF_TIME"));
						varPmmStatus = P_STATUS_OK;
					} else {
						varPmmStatus = P_INVALID_POLICY;
						LOG_ERROR(PMM_qDebugR_MODE), ("PMM : CPolicic");
					}
				}
			}
			}
		}
	} catch (...) {
	}
}

/// @file CPolicyDataManager.h
/// ****************************************************************************************
/// © Honeywell Trendview
/// ****************************************************************************************
/// @n Module	:	 Password Management module
/// @n Filename	:	 CPolicyDataManager.h
/// @n Desc		:	 CPolicyDataManager is a class which implements all 
///					 the methods related to Policy data Queries and modifications.
///
// ****************************************************************************************
// Revision History
// ****************************************************************************************
// $Log[1]:
//  5 Stability Project 1.2.1.1 7/2/2011 4:56:24 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
// $Log" for functions
// $
//
// ****************************************************************************************
/******************************************************************************************
 COPYRIGHT (c) 2004
 HONEYWELL INC.,
 ALL RIGHTS RESERVED
 This software is a copyrighted work and/or information protected
 as a trade secret. Legal rights of Honeywell Inc. in this
 software is distinct from ownership of any medium in which the
 software is embodied. Copyright or trade secret notices included
 must be reproduced in any copies authorized by Honeywell Inc.
 The information in this software is subject to change without
 notice and should not be considered as a commitment by Honeywell
 Inc.
 ******************************************************************************************/
#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_CPOLICYDATAMANAGER_40D6D02200FA_INCLUDED
#define _INC_CPOLICYDATAMANAGER_40D6D02200FA_INCLUDED
//******************************************************
// CPolicyDataManager
///
/// @brief Implements the C style API functions
/// 
/// CPolicyDataManager is a class which implements all 
///	the methods related to Policy data Queries and modifications.
//******************************************************
class CPolicyDataManager {
public:
	POLICY_STATUS initialiseToDefaultPolicy(TV_BOOL);
	POLICY_STATUS GetPolicyData(T_PMMPOLICYDATA*);
	POLICY_STATUS SetPolicyData(T_PMMPOLICYDATA*, TV_BOOL);
	POLICY_STATUS UndoSetPolicy();
	/*
	 POLICY_STATUS GetRange(BYTE policytype, DWORD * dwHighLimit,
	 DWORD *dwLowLimit,TV_BOOL lMode);
	 */
	CPolicyDataManager();
	~CPolicyDataManager();
protected:
	POLICY_STATUS CheckPolicy(TV_BOOL);
	PMMERROR GetPolicyError(POLICY_STATUS);
	void InitialisePolicyData();
	T_PMMPOLICYDATA m_stCFRBasedPolicy;			// Base level CFR policy.
	T_PMMPOLICYDATA m_stNONCFRPolicy;			// Base level NonCFR policy.
	T_PMMPOLICYDATA *m_stPolicyDataWorking,		// Pointer to the working section of policy data.
			*m_stPolicyDataCurrent;		// Pointer to the cudrrent section of policy data.	
	BOOL m_gPolicySts;					// Indicate during the time of initialise whether 
	// the policy is a valid policy or not.
	// 1 - Invalid policy. 0 - Valid policy. previously initialised.
private:
	POLICY_STATUS CheckSplCondition(SHORT CheckPolicy);
	/*
	 void GetExpiryRange(DWORD *dwHighLimit, DWORD *dwLowLimit,
	 TV_BOOL lModeOfRecorder);
	 void GetExpiryWarningRange(DWORD *dwHighLimit, DWORD *dwLowLimit,
	 TV_BOOL lModeOfRecorder);
	 void GetRetryCountRange(DWORD *dwHighLimit, DWORD *dwLowLimit,
	 TV_BOOL lModeOfRecorder);
	 void GetLogOffTimeRange(DWORD *dwHighLimit, DWORD *dwLowLimit,
	 TV_BOOL lModeOfRecorder);
	 void GetPasswordLockoutRange(DWORD *dwHighLimit, DWORD *dwLowLimit,
	 TV_BOOL lModeOfRecorder);
	 void GetPasswordALPHARange(DWORD *dwHighLimit, DWORD *dwLowLimit,
	 TV_BOOL lModeOfRecorder);
	 void GetPasswordNUMERICRange(DWORD *dwHighLimit, DWORD *dwLowLimit,
	 TV_BOOL lModeOfRecorder);
	 void GetPasswordMinLenCRange(DWORD *dwHighLimit, DWORD *dwLowLimit,
	 TV_BOOL lModeOfRecorder);
	 void GetPasswordMaxLenCRange(DWORD *dwHighLimit, DWORD *dwLowLimit,
	 TV_BOOL lModeOfRecorder);
	 void GetPasswordSplCharMinRange(DWORD *dwHighLimit, DWORD *dwLowLimit,
	 TV_BOOL lModeOfRecorder);
	 void GetUsernameMaxRange(DWORD *dwHighLimit, DWORD *dwLowLimit,
	 TV_BOOL lModeOfRecorder);
	 void GetUsernameMinRange(DWORD *dwHighLimit, DWORD *dwLowLimit,
	 TV_BOOL lModeOfRecorder);
	 void GetWebLogOffTimeRange(DWORD *dwHighLimit, DWORD *dwLowLimit,
	 TV_BOOL lModeOfRecorder);
	 */
};
#endif 

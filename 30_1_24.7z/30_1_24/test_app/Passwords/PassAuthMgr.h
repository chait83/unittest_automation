/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  Passwords
/// @n Filename:  CPassAuthMgr.h
/// @n Description: Class Declaration for the CPassAuthUI class. 
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  16  Stability Project 1.13.1.1 7/2/2011 4:59:37 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  15  Stability Project 1.13.1.0 7/1/2011 4:27:42 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  14  V6 Firmware 1.13 4/25/2006 8:57:41 PM  Alistair Brugsch
//  added functionality to check current logged in status and report the
//  username
//  13  V6 Firmware 1.12 4/25/2006 2:58:00 PM  Alistair Brugsch
//  Added new function to get the name of a currently logged in user
// $
//
// **************************************************************************
#pragma once
#ifndef _PASSAUTHMGR_H
#define _PASSAUTHMGR_H
#include "PassAuthDefines.h"
#include "PMMglobal.h"
#include "PasswordInterfaceManager.h"
#include "Widget.h"
#ifdef RDL_PAM_ENABLE
#include "CStorage.h"
#endif
//
//#include "AlphaNumEditDlg.h"
#include "PMMglobal.h"
//#include "SipGlobal.h"
#include "PasswordInterfaceManager.h"
//**Class*********************************************************************
///
/// @brief Provides a Password authentication and user setup Interface
/// 
/// This class is a singleton and will provide access to the user Auth dialogs
/// 
/// this class will manage the interface to the CPWI and the user authentication
/// through the UI. dialogs are available to prompt for usernames and passwords,
/// and also to administer the users and group permissions
/// 
/// 
///
//****************************************************************************
class CPassAuthUI: public CPassiveModule {
public:
	/// On First Call creates the Class Instance, otherwise returns a Pointer to the Class Instance
	static CPassAuthUI* GetHandle();
	/// Initialise the Message List Service for Operation
	BOOL Initialise(void);
	//supply an authentication requirement
	TV_BOOL AuthenticateUserArea(T_AUTHENTICATION_AREAS Area, CWidget *pkParent = NULL);
	//Prompt the user to log on
	T_PASS_AUTH_ACCESS LogOn(const QString csUser = "", const QString csPass = "", const TV_BOOL bQuiet = FALSE,
			CWidget *pkParent = NULL);
	//Log the current user off
	TV_BOOL LogOff();
	//change the password of a user
	TV_BOOL ChangePassword(QString &csNewPass, const QString csUser = "", const QString csPass = "", CWidget *pkParent =
			NULL);
	/// Perform a Controlled Shutdown of the Queue Manager
	BOOL Shutdown(void);
	///Determine the last logged in username
	TV_BOOL GetLoggedInUserName(QString &csData);
	//inform the PMM that the user is active
	void UpdateUserAccess(void);
	BOOL UserLoggedOn(void);
	BOOL GetCurrentUserName(QString &pstrName);
	BOOL TestAreaUnrestricted(T_AUTHENTICATION_AREAS Area, bool *bRes);
	/// Cleanup the Singleton
	BOOL CleanUp(void);
	// Accessor methods
	const bool IsInitialised() const {
		return m_bInitialised;
	}
	BOOL IsAreaUnRestricted(T_AUTHENTICATION_AREAS Area);
	BOOL IsAreaAllowedWhenHLSet(T_AUTHENTICATION_AREAS Area);
	//Masking Recorder when Remote user is Safe zone
	void MaskRecorder();
	//UnMask Recorder when Remote user Leaves Safe zone
	void UnMaskRecorder();
#ifdef RDL_PAM_ENABLE
		void LogDebugMessage(QString  & strDbgMsg);
		void SetDebugLogger(CDebugFileLogger* pDbgFileLogger);
	#endif
private: // -- Member Functions -- //  
	/// Constructor
	CPassAuthUI(void);
	/// Destructor
	virtual ~CPassAuthUI(void);
private: // -- Member Variables -- //
	static CPassAuthUI *m_pInstance;  ///< Pointer to the Created Instance;  
	static QMutex *m_CreationMutex;  ///< Mutex to ensure Creation is carried out once
	PasswordInterfaceManager m_PIM;  ///instance of the CPWI Wrapper
	USHORT m_LastUserID;
	/// Flag indicating of the queue manager has been intialiased yet
	bool m_bInitialised;
	CModuleMsgManagerClient m_ModuleMessageManagerClient;
#ifdef RDL_PAM_ENABLE
	static CDebugFileLogger m_debugFileLogger;
	CDebugFileLogger* m_pDebugFileLogger;
#endif
};
#endif //_PASSAUTHMGR_H

/// @file CPasswordManager.h
/// ****************************************************************************************
/// © Honeywell Trendview
/// ****************************************************************************************
/// @n Module	: Password Management Module.
/// @n Filename	: CPasswordManager.h
/// @n Desc		: Any Query about the User is implemented in theis module.
///
// ****************************************************************************************
// Revision History
// ****************************************************************************************
// $Log[1]:
//  7 Stability Project 1.4.1.1 7/2/2011 4:56:23 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
// $Log" for functions
// $
//
// ****************************************************************************************
/******************************************************************************************
 COPYRIGHT (c) 2004
 HONEYWELL INC.,
 ALL RIGHTS RESERVED
 This software is a copyrighted work and/or information protected
 as a trade secret. Legal rights of Honeywell Inc. in this
 software is distinct from ownership of any medium in which the
 software is embodied. Copyright or trade secret notices included
 must be reproduced in any copies authorized by Honeywell Inc.
 The information in this software is subject to change without
 notice and should not be considered as a commitment by Honeywell
 Inc.
 ******************************************************************************************/
#if defined (_MSC_VER) && (_MSC_VER >= 1000)
#pragma once
#endif
#ifndef _INC_CPASSWORDMANAGER_40D6CEEC02DE_INCLUDED
#define _INC_CPASSWORDMANAGER_40D6CEEC02DE_INCLUDED
//***********************************************************************
// CPasswordManager
///
/// @brief Implements the C style API functions
/// 
/// CPasswordManager is the class which handles all the API call 
///	related to Queries on the Existing user and all the NVRAM Access 
///	and modification is implemented in this class.
//**********************************************************************
#include "DAL.h"
#include "PMMglobal.h"
#include "V6Config.h"
#include "PMMdefines.h"
class CPasswordManager {
public:
	CPasswordManager();
	~CPasswordManager();
	PMMERROR ModifyUserGroup(SHORT, BYTE, TV_BOOL);
	PMMERROR GetUserData(SHORT*, T_USERDATA*);
	PMMERROR GetUserDataById(SHORT, T_USERDATA*);
	PMMERROR GetPermission(SHORT, DWORD*);
	PMMERROR SetPermission(SHORT, DWORD*);
	PMMERROR QueryUserInfo(SHORT, LOGDETAIL*);
	PMMERROR ValidateUserArea(SHORT, SHORT, TV_BOOL*);
	PMMERROR SetAccessLevel(SHORT, SHORT*);
	PMMERROR ExpireUserPassword(SHORT);
	PMMERROR GetUserPasswordStatus(QString szUsername, TV_BOOL *bResult);
	BOOL IsPMMInitialised();
	TV_BOOL IsCFRMode();
	BOOL IsDALInit();
protected:
	T_PMMDATA *m_stUserDataWorking,							// Pointer to the Working UserData.
			*m_stUserDataCurrent;							// Pointer to the Current UserData.
	SYSTEMSTATE m_stLoginUsersInfo;
	LOGDETAIL m_stLogDetails[MAX_USERS];					// Login details of all 50 Users.
	T_PMMNVDATA *m_stNVData;									// Pointer to the NVRAM password area.
	DWORD m_ConfigId;									// Global Configuration Id to Communicate with CMM module.
	TV_BOOL m_Mode;										// Mode of the Recorder. TRUE - CFR mode FALSE - NonCFR mode.
	long m_SerialNumber;								// Serial Number of the recorder.
	DWORD m_BackDoorUserPerm[USERPASSPERM_PERM_SIZE]; // Backdoor User permission.
	DWORD m_FirstTimeUserPerm[USERPASSPERM_PERM_SIZE]; // First time User permission 
	BOOL m_PMMinitialise;							// TRUE - Indicates PMM has been initialised.
	BOOL m_DALSts;									// TRUE - Obtained proper NVRAM handle to the password Area.
	//CDeviceAbstraction *m_pDeviceAbstraction;					// Device abstraction Layer(DAL). 
private:
	PMMERROR GetStatus(SHORT, SHORT, TV_BOOL*);
	BOOL SetStatus(SHORT, SHORT, TV_BOOL);
};
#endif 

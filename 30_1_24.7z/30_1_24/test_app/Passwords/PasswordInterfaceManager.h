/// @file PasswordInterfaceManager.h
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Client password Interface
/// @n Filename:	PasswordInterfaceManager.h
/// @n Description: Class contains the some of the calls to PMM being wrapped.
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 9	Stability Project 1.6.1.1	7/2/2011 4:59:38 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 8	Stability Project 1.6.1.0	7/1/2011 4:27:32 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 7	V6 Firmware 1.6		10/1/2007 7:35:22 PM	Roger Dawson 
//		Fixed a problem recorded by a customer in Germanty whereby the
//		recorder crashed when a user logged in. Improved the
//		PasswordInterfaceManager::AppendUserClientAndasprintfMessage method so
//		it does not cause buffer overrun's.
// 6	V6 Firmware 1.5		1/31/2006 12:02:01 PM Shyam (HTSL) 
//		Area names appended with the message for getting proper meaning.
// $
//
// **************************************************************************
/**************************************************************************************************************
 COPYRIGHT (c) 2005
 HONEYWELL INC.,
 ALL RIGHTS RESERVED
 This software is a copyrighted work and/or information protected
 as a trade secret. Legal rights of Honeywell Inc. in this
 software is distinct from ownership of any medium in which the
 software is embodied. Copyright or trade secret notices included
 must be reproduced in any copies authorized by Honeywell Inc.
 The information in this software is subject to change without
 notice and should not be considered as a commitment by Honeywell
 Inc.
 ******************************************************************************************/
#if !defined(AFX_CPWI_H__5B2371A5_1FF3_4C3A_B22D_20E5D8FDAC87__INCLUDED_)
#define AFX_CPWI_H__5B2371A5_1FF3_4C3A_B22D_20E5D8FDAC87__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#ifdef RDL_PIM_ENABLE
#include "CStorage.h"
#endif
#include "Defines.h"
#include <QList>
#include "PMMglobal.h"
#include "PMMdefines.h"
#include "V6Config.h"
#include "MessageListServicesItem.h"
/** Node added for each user */
typedef struct UserList {
	LONGLONG LoginTime;			///< Latest Login time
	LONGLONG LastAccessTime;	///<
	DWORD UserId;				///< 
	USHORT LoginCount;			///< Number of times user has login, 
								///< When count becomes '0' node will be deleted.		
} USER_LIST;
/** Maintained for the list of the users login to the recorder */
typedef QList<USER_LIST*> UserInfoList;
#define CPWI_MESSAGE_LENGTH		71
/** Clients of CPWI */
typedef enum clients			///< Clients of CPWI.
{
	CPWI_FTP, CPWI_WEB, CPWI_LOCAL_UI,
	CPWI_ALL_CLIENTS
} CLIENTS;
typedef enum _ePMMmode {
	PMM_NONCFR, PMM_CFR
} PMM_MODE;
class PasswordInterfaceManager {
public:
	PasswordInterfaceManager();
	~PasswordInterfaceManager();
	// checks whether the passwords enable or not 
	PMMSTATUS IsPasswordEnabled();
	/* Will basically update the Class variables and will register with the message manager */
	PMMSTATUS InitCPWI(CLIENTS eAccessClient);
	PMMSTATUS GetUserGroup(SHORT UserId, DWORD *Group);
	/* Obtain the UserGroup of the user being log-in */
	PMMSTATUS Login(QString Username = NULL, QString Password = NULL, SHORT *ID = NULL, QString MessageBuffer = NULL);/*
	 If the same user calls the ValidateLogin API multiple number of times, even though his first time call to PMM is successful, 
	 ValidateLogin of PMM will be called in successive calls also.	*/
	PMMSTATUS Logoff(SHORT ID, QString MessageBuffer = NULL);/*
	 Once the user is log-off user information from LL(Linked list) will be deleted.	*/
	PMMSTATUS ValidateAreaNumber(SHORT AreaNumber, SHORT ID, TV_BOOL *Result, QString MessageBuffer = NULL); /*
	 Checks if the user is already login, If the user is logged-in successfully 
	 ValidateArea will be called else appropriate error code will be returned.*/
	PMMSTATUS GetUserNamePolicyDetails(T_USERPOLICY*);/*
	 Obtains information of the Username from the policy data ( Like Max length, Min Length of username).	*/
	PMMSTATUS GetPasswordPolicyDetails(T_PWRDPOLICY*); /*
	 Obtains the information of the Password from the policy data 
	 ( Like Max length, Min numerics,Min Spl char, Min password length) */
	PMMSTATUS GetDaysBeforeExpiry(WORD*); /*
	 Obtains number of days for password to expire. 	*/
	PMMSTATUS GetPMMMode(TV_BOOL *Result);
	/*Whether CFR or NonCFR mode. 	*/
	PMMSTATUS GetUILogoffTime(short*);
	/* Get UI logoff time from the policy information. */
	PMMSTATUS GetWebLogOffTime(short*);
	/* Get Web Logoff time from the policy information. */
	PMMSTATUS GetMaxRetry(BYTE*);
	/* Get maximum number of retry before the user account is locked out. */
	PMMSTATUS UpdateLastAccessTime(SHORT UserId);
	/* Will indicate the CPWI to update the last Access time */
	PMMSTATUS GetLastAccessTime(SHORT UserId, LONGLONG *LastAccessTime, LONGLONG *pTimeNow);
	/* Will get the time of User */
	PMMSTATUS GetLoginTime(SHORT UserId, LONGLONG *LoginTime);
	PMMSTATUS IsFTPEnabled(TV_BOOL*);
	/* Obtain info from policy whether FTP is enabled or not.*/
	PMMSTATUS IsWEBEnabled(TV_BOOL*);
	TV_BOOL IsCPWIInitialised();
	//This function is used for the hardware security lock
	//The function will return TRUE if Access to the area is 
	//unrestricted
	TV_BOOL IsAreaUnrestricted(SHORT AreaNumber);
	PMMSTATUS GetPwdSts(QString wUserName, TV_BOOL *pResult);
#ifdef RDL_PIM_ENABLE
private:
  void LogDebugMessage(QString  & strDbgMsg);
public:
		void SetDebugLogger(CDebugFileLogger* pDbgFileLogger);
	#endif
private:
	bool GetUserInfoFromList(SHORT UserId, UserList **UserInformation);
	void CheckUserAndLogMessage(SHORT UserId, WCHAR*);
	bool CheckForUserIdInList(SHORT UserId);
	void RemoveUserInformation(SHORT UserId);
	void AppendUserClientAndasprintfMessage(QString szUsername, T_MSGLISTSER_SECURITY_MSG_TYPE eMsgType,
			QString szMessage, const USHORT usDEST_BUFF_LEN, QString szArea = NULL);
private:
	UserInfoList m_list;
	DWORD m_TotalUsers;
	CLIENTS m_UserClient;
	TV_BOOL m_CPWIInit;
	TV_BOOL m_bMessageLog;
#ifdef RDL_PIM_ENABLE
	CDebugFileLogger* m_pDebugFileLogger;
#endif
};
#endif

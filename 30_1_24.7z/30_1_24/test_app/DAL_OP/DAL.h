/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	System Absraction layer
/// @n Filename: dal.h
/// @n Desc:	Routines to wrap any hardware calls to allow emulator and
///				recompilation on the PC under Visual Studio
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 18-09-15	Rajanbabu M			Added method GetSecondaryProcFWVersion() to fetch secondary firmware version dynamically
// 20-10-14	Rajanbabu M			Fixed PAR:1-3I2GTSM - WSD communication is not working on upgrading the firmware
// 65	Aristos	1.61.1.1.1.0 9/19/2011 4:51:10 PM	Hemant(HAIL) 
//		Stability recorder source code (JI Release) updated for WatchDog
//		Timer functionality.
// 64	Stability Project 1.61.1.1	7/2/2011 4:56:29 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 63	Stability Project 1.61.1.0	7/1/2011 4:26:56 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 62	V6 Firmware 1.61		11/6/2008 3:10:02 PM	Nilesh(HAIL)	USB
//		Clear Function. This clears the USB to get detected.
// $
//
// ****************************************************************
//
// Check if build is using the emulator, if so define EMULATOR 
// to be used in all source files as _WIN32_WCE_CEPC may change
#ifndef __DAL_H__
#define __DAL_H__
#ifdef UNDER_CE
	#define ARMV4I
#endif
#ifdef ARMV4I
	//#define V6_TARGET				///< defined when running on V6 Target
	#define ARISTOS
#else
#define	EMULATOR				///< defined when running on PC and hardware requres emulation (see opl.h)		
#endif
#ifdef ARMV4I/*V6_TARGET*/
//#include "Pkfuncs.h"
//#include "oeminc.h"
#else
#include "emulator.h"
#endif
//
//#ifdef EMULATOR	//This is Emulator code running on Aristos.....
//	#ifdef UNDER_CE
//		#define ARISTOS
//	#endif
//#endif
#ifdef ARISTOS
//#include "Pkfuncs.h"
//#include "oeminc.h"
#endif
#ifdef V6IOTEST
#include "..\..	ools	estEquipment\V6MessageBoxDlg.h"
#else
#include "V6ResourceBase.h"
#include "V6UIResource.h"
#include "Defines.h"
#endif
/// IEEE allocated range of 00-D0-6E-xx-xx-xx
const UCHAR TRENDVIEW_MAC_OCTET1 = 0x00;
const UCHAR TRENDVIEW_MAC_OCTET2 = 0xD0;
const UCHAR TRENDVIEW_MAC_OCTET3 = 0x6E;
#include "V6defines.h"
#include "sercomm.h"
#include "PassiveModule.h"
#include "StoragePaths.h"
#include "hw_defs.h"
#include <QLibrary>
#ifdef DBG_FILE_LOG_DAL_DBG_ENABLE
#include "CStorage.h"
#endif
#define ETHERNET_10MB_PHY_BIT			0x1
#define ETHERNET_FULL_DUPLEX_PHY_BIT	0x2
#define ETHERNET_ACTIVITY_PHY_BIT		0x4
#define ETHERNET_100MB_PHY_BIT			0x8
#define ETHERNET_TX_PHY_BIT				0x10
#define ETHERNET_RX_PHY_BIT				0x20
#define ETHERNET_10MB_SPEED				100000
#define ETHERNET_100MB_SPEED			1000000
#define ETHERNET_STATE_DISCONNECTED		1
#define ETHERNET_STATE_CONNECTED		0
#define CSPI_DEVICE_NAME QString  ("SPI2:")
#define DAL_WATCHDOG_WARNING	20000	///< Set a watchdog warning if kick doesn't happen for this number of msec	
#define DAL_WATCHDOG_MAXTIME	180000	///< Set a watchdog warning if kick doesn't happen for this number of msec	
//typedef HANDLE (*CSPIOpenHandle)(LPCWSTR lpDevName);
//typedef DWORD (*SPIWrite) (HANDLE hCSPI, LPCVOID pBuffer, DWORD dwNumBytes);
//typedef DWORD (*SPIRead) (HANDLE hCSPI, LPCVOID pBuffer, DWORD* dwNumBytes);
//extern "C" HANDLE CSPIOpenHandle(LPCWSTR lpDevName);
//extern "C" DWORD SPIWrite (HANDLE hCSPI, LPCVOID pBuffer, DWORD dwNumBytes, UCHAR slotID);
//extern "C" DWORD SPIRead (HANDLE hCSPI, LPCVOID pBuffer, DWORD* dwNumBytes, UCHAR slotID);
typedef struct IOCARDError {
	USHORT ErrorNo;			///< Error Number (see oeminc.h) 
	USHORT ErrorData;			///< Data associated with error, see error type for details
	/*	USHORT	AP8Mess;			///< DP State AP8 message when error occurred (0x3fc)
	 USHORT	AUMess;				///< DP State AU1100 message when error occured (0x3fd)
	 USHORT	AP8CmdReady;		///< DP State AP8 Command ready state (0x3fe)
	 USHORT	AUCmdReady;			///< DP State AU1100 Command ready state (0x3ff)*/
} T_IOCARDERR;
typedef enum {
	SHUTDOWN_MODE_RESET,	///< Run the reset line once the system has shutdown
	SHUTDOWN_MODE_STOP,	///< Stop the system a display "safe to power off" dialog
	SHUTDOWN_MODE_EXIT,			///< Exit the application, for development only
	SHUTDOWN_MODE_FW_UPDATE,			///< Firmware Update shutdown mode
	SHUTDOWN_MODE_CONFIG_CHANGE,		///< Config Change requires a restart
	SHUTDOWN_MODE_SAFE_TO_POWER_OFF,	///< Safe to power down state
} T_SHUTDOWN_MODE;
typedef enum {
	IOCARD_EXT_OP_CLEARBUFFER, IOCARD_EXT_OP_GET_AP8_STATS,
} T_IOCARD_EXT_OPERATION;
// Repeat the IEL param Block here so we can use in Emulation builds
// this struct MUST match TVIEWV6_PARAMS in oeminc.h and built into platform (won't change unless BSP does)
//typedef struct {
//	unsigned long	Signature;			// 0x00
//	unsigned char	MacAddress[6];		// 0x04
//	unsigned short	USBConfig;			// 0x0A
//	unsigned short	DLSource;			// 0x0C
//
//} TVIEWV6_IEL_PARAMS, *PTVIEWV6_IEL_PARAMS;
typedef struct {
	DWORD Signature;			// 0x00
	unsigned char MacAddress[8];		// 0x04
	//unsigned short	USBConfig;			// 0x0A
	DWORD DLSource;			// 0x0C
} TVIEWV6_IEL_PARAMS, *PTVIEWV6_IEL_PARAMS;
// Verison information either BSP or Bootloader
typedef enum _versionInfoType {
	VER_BSP, VER_BOOTLOADER
} T_VERSION_TYPE;
typedef struct _SPIFMD_BLOCK {
	DWORD blockID;
	LPBYTE pBlockBuff;
	DWORD dwBlockBuffSize;
} SPIFMD_BLOCK, *PSPIFMD_BLOCK;
//Below structures is used to return BSP Version to Application.
typedef struct BSP_VERSION {
	unsigned short BootVerMSB;					// Bootloader Major Version
	unsigned short BootVerLSB;					// Bootloader Minor Version
	unsigned short BootVerLSBL;					// Bootloader Sub Minor Version
	unsigned short OSVerMSB;						// OS Image1 Major Version
	unsigned short OSVerLSB;						// OS Image1 Minor Version
	unsigned short OSVerLSBL;					// OS Image1 Sub Minor Version
} BSP_VERSION, *PBSP_VERSION;
//Open SRAM SDk Driver Handle
typedef HANDLE (*SRAMOpen)(LPCWSTR lpDevName);
//Close SRAM SDk Driver Handle
typedef BOOL (*SRAMClose)(HANDLE hSRAM);
//Get Virtual address of SRAM 
typedef LPVOID (*SRAMGetPointer)(HANDLE hSRAM);
//Free Virtual address of SRAM 
typedef BOOL (*SRAMFreePointer)(LPVOID lpBaseAddress);
///TODO change this as per linux
#define DEFAULT_FLASH_PFX_DEST_PATH_CERTCA	QString  ("/SDMemory/FlashPfxasprintf/")
#define DEFAULT_DEVICE_PFX_PATH_CERTCA	QString  ("/SDMemory/FlashPfxasprintf/Device.cer")
//spi dll
typedef HANDLE (*CSPIOPENHANDLE)(LPCWSTR lpDevName);
typedef DWORD (*SPIWRITE)(HANDLE hCSPI, LPCVOID pBuffer, DWORD dwNumBytes, byte slotID);	// typedefs move to dal.h
typedef DWORD (*SPIREAD)(HANDLE hCSPI, LPCVOID pBuffer, DWORD *dwNumBytes, byte slotID);
typedef BOOL (*CSPICLOSEHANDLE)(HANDLE spiDeviceHandle);
//**Class*********************************************************************
///
/// @brief Abstract the custom hardware
/// 
/// This class will provide access routines to all custom hardware for V6 application
/// abstracting the calls to the device drivers, enabling the calls to be made
/// regardless of host, PC, PC emulating CE or V6 Target hardware.
///
/// This class is a singleton.
///
//****************************************************************************
class CDeviceAbstraction: public CPassiveModule {
public:		//Singleton 
	static CDeviceAbstraction* GetHandle();
	void CleanUp();
#ifndef UNDER_CE
	/// Static variable used by the desktop build to determine if the system is required to run
	/// as a mintrend, multitrend, eztrend etc
	static T_DEV_TYPE ms_eDesktopDeviceType;
#endif
//#ifdef UNDER_CE
//	/// Static variable used by the desktop build to determine if the system is required to run
//	/// as a mintrend, multitrend, eztrend etc
//	static T_DEV_TYPE ms_eDesktopDeviceType;
//	
//#endif
private:	// Singleton
	CDeviceAbstraction();
	~CDeviceAbstraction() {
	}
	;	// Will never be called
	CDeviceAbstraction(const CDeviceAbstraction&);
	CDeviceAbstraction& operator=(const CDeviceAbstraction&) {
		return *this;
	}
	;
	static CDeviceAbstraction *m_pDALInstance;
	static QMutex m_CreationMutex;
	CStoragePaths *m_pPaths;
	/// SPI bus critical section required
	static QMutex ms_kSPICritSect;
	//CSPIOpenHandle m_pfunOpenHandle;
	/*SPIWrite m_pfunSpiWrite;
	 SPIRead m_pfunSpiRead;*/
	QLibrary m_hCSPISDK;
	HANDLE m_hPHYIO;
	HINSTANCE m_hInstInterfaceSDK;
	SRAMClose m_pfSRAMClose;
	SRAMGetPointer m_pfGetPointer;
	SRAMFreePointer m_pfFreePointer;
	HINSTANCE m_hInsSRamDLL;
	SRAMOpen m_pfSRAMOPEN;
	HANDLE m_hSramDriver;
public:	// API methods
	// Driver handles
	static HANDLE m_hLEDIO;						///< GPIO Handle
	BOOL IsDALInitialised() {
		return m_Initialised;
	}
	;		// Shows in DAL Initialised 
	HANDLE m_hInterfaceHandle;
	// Initialise and shutdown of device abstraction
	BOOL Initialise();
	BOOL Shutdown();
	// Flash access
	BOOL RWBootFlashBlock(BOOL flashWrite, ULONG blockNumber, ULONG sizeReq, BYTE *pBuffer);
	BOOL RWIELParameterBlock(PTVIEWV6_IEL_PARAMS pParamBlk, BOOL flashAction);
	// IEL parameter Block programming
	BOOL SetBootTypeType(USHORT BootType);
	BOOL SetFrontUSBType(USHORT USBConfiguration);
	BOOL SetMACAddress(UCHAR Octet4, UCHAR Octet5, UCHAR Octet6);
	void SetDeviceType(T_DEV_TYPE type) {
		m_deviceType = type;
	}
	;			///< Set the device type
	// GPIO Controlled functions
	ULONG GetPHYStatus(ULONG &ulLinkSpeed);
	BOOL SetCFLED(BOOL turnLEDOn);
	BOOL KickWatchdog();
	BOOL DisableWatchdog();
	static BOOL PerformReboot();
	//Added to do a secondary reset. Secondary processor is not responding at times.
	BOOL PerformSecondaryReset();
	void ResetUSB();
	//added by nilesh for usr clear
	//[
	void ClearUSB();
	//]
	// Backlight control
	short SetScreenBrightness(short pcLevel);
	short GetScreenBrightness();
	// SPI access
	UCHAR SPIGetDigitalCardStatus();
	// IO Card access
	BOOL IOCardInitialise(USHORT port);
	BOOL IOCardSelect(const USHORT device);
	BOOL IOCardRead(void *pBuffer, ULONG *pSize, UCHAR slotID);
	BOOL IOCardWrite(void *pBuffer, ULONG *pSize, UCHAR slotID);
	BOOL IOCardExtendedOperation(T_IOCARD_EXT_OPERATION extOp);
	BOOL IOSetPowerRelay(BOOL state);
	// SRAM access	
	BOOL SafeWriteToSRAM(long offset, long length, unsigned char *pBuffer);
	BOOL SafeReadFromSRAM(long offset, long length, unsigned char *pBuffer);
	CHAR* GetPtrIntoSRAM(long offset);
	BOOL ReadWriteNV(BOOL write, long sizeReq, WORD *pBuffer, UCHAR blockNumber, ULONG defSize,
			BOOL bNoEmptyNV = FALSE);
	void UpdateSRAM() {
		SimulatedSRAMAccess(BF_WRITE);
	}
	;				///< Make sure emulated SRAM is persisted.
	void BackupSRAMToDiskCopy(UCHAR ucBlockNumber = BF_BLK_SRAM_BACKUP);
	BOOL RestoreSRAMFromDiskCopy();
	// Storage devices
	QString GetVolumeName(storageDeviceIdent id, QString *volume, int pbufferSizeInWchar);
	HANDLE GetVolumeHandle(TCHAR *VolumeName);
	int ScanVolume(HANDLE VolumeHandle, DWORD *DataSize, void *ReturnData, unsigned long *ErrorCode);
	int QuickasprintfVolume(HANDLE VolumeHandle, DWORD *DataSize, void *ReturnData, unsigned long *ErrorCode);
	int FullasprintfVolume(HANDLE VolumeHandle, DWORD *DataSize, void *ReturnData, unsigned long *ErrorCode);
	BOOL QuickasprintfFrontSD();
	// RS458 access
	BOOL RS458SetTurnaround(DWORD turnAroundInms, HANDLE *p485Handle);
	// Get System information
	//int GetBoardRevision()		{ return SYSREV_PCB(m_clpdStatus)+1; };		// Board Revision 0=1, 1=2 etc...
	int GetBoardRevision();
	//int GetBoardBuild()			{ return SYSREV_BUILD(m_clpdStatus)+1; };	// Board Build number 0=1, 1=2 etc.. 
	//int GetCPLDVersion()		{ return SYSREV_CPLD(m_clpdStatus); };		// CPLD Firmware version
	int GetCPLDVersion();
	int GetProcSpeed() {
		return SYSREV_MHZ(m_clpdStatus);
	}
	;		// Processor Speed 336=0 or 500=1
	int GetJ5Status() {
		return SYSREV_JP5(m_clpdStatus);
	}
	;		// Is Jumper J5 set 0=No 1=Yes(jumpered)
	int GetScreenType() {
		return m_screenType;
	}
	;					// Screen type SCRN_5_5, SCRN_12_1 etc..
	int GetFrontUSBStatus() {
		return m_frontUSBSet;
	}
	;					// Front USB status, USB_FRONT_DEVICE or USB_FRONT_HOST
	int GetSPIProcFW() {
		return m_SPIProcFW;
	}
	;					// SPI processor(AP8) version number if fitted
	int GetSecondaryProcFWVersion();
	void SetSecondaryProcFWVersion(int secFWVer) {
		m_secProcFWVer = secFWVer;
	}
	int GetEthernetBoot() {
		return m_EthernetBoot;
	}
	;					// Startup status will platform attemp to boot from ethernet (Platbuilder)
	int GetRS485fitted() {
		return IsCommsBoardFitted();
	}
	;			// RS485 port Fitted 
	ULONG GetSRAMSize() {
		return m_SRAMLength;
	}
	;					// Size of SRAM(battery backed RAM) in bytes
	T_DEV_TYPE GetDeviceType() {
		return m_deviceType;
	}
	;					// Get the Device Type T_DEV_TYPE in hw_defs
	UCHAR* GetMACPtr() {
		return &m_MacAddress[0];
	}
	;				// Get ptr to 6 char mac address
	BOOL IsFrontCFSlotAvailable();		// Is the front compact flash available
	BOOL IsPowerRelayFitted();					// Is power relay always fitted
	BOOL IsMotherBoardFitted();					// Is mother board always fitted
	BOOL IsCommsBoardFitted();					// Is comms board always fitted
	BOOL IsPCSoftware();					// Is this a PC Build
	BOOL IsRecorderPCorEmbedded();					// Is this a recorder build PC(V6Desktop) or Embedded(V6App)
	BOOL IsRecorderEmbedded();				// Is this a recorder buld embedded
	BOOL IsRecorderMiniMultiEmbedded();	// Is this recorder mini or multi embedded
	BOOL IsRecorderEzTrend();				// Is this recorder an EzTrend
	BOOL IsRecorderMini();					// Is recorder a mini
	BOOL IsRecorderMulti();					// Is recorder a Multiplus
	// Method that determines if the network connection is running
	const bool IsNetworkRunning();
	// Bootlace interaction accessors
	const wchar_t* BaseRegistryKey();
	void AcknolegeBoot(BOOL BootOk);
	void SetFirmwareUpdateDetails(USHORT fwSignature, QString commandLine);
	void GetVersionInformation(T_VERSION_TYPE type, USHORT *pMajor, USHORT *pMinor);// Get version information of BSP or Bootloader
	BOOL SyncTime();	// Syncronises the platform RTC with the Windows Block
	float GetTheIdleTimeInPercent();	// Get and claculates the idle time as a percentage
	void FatalError(const QString asprintf, ...);	// Portable Fatal error message (doesn't need error services)
	void SetShutDownMode(T_SHUTDOWN_MODE mode) {
		m_ShutDownMode = mode;
	}
	;
	T_SHUTDOWN_MODE GetShutDownMode() {
		return m_ShutDownMode;
	}
	;
	// Wrappers for StoragePath friend methods
	QString GetPath(T_STORAGE_PATH pathID, QString *pBuffer, int pbufferSize, int *pLength) {
        /// TODO : Check this code.
//		return m_pPaths->GetPath(pathID, pBuffer, pbufferSize, pLength);
	}
	;
	BOOL BuildPath(T_STORAGE_DEVICE device, T_STORAGE_PATH path, const QString *file, QString *buffer, USHORT size) {
        return m_pPaths->BuildPath(device, path, file, buffer, size);
	}
	;
	void RegisterUserActivity() {
		UserActivityFlag = TRUE;
	}
	;
	void ClearUserActivity() {
		UserActivityFlag = FALSE;
	}
	;
	BOOL GetUserActivity() {
		return UserActivityFlag;
	}
	;
	BOOL CalibrateScreen();
	//This function checks if the hardware securityBlock is enabled
	BOOL IsHardwareLockEnabled();
	bool BackLightBrightnessTest();
	BSP_VERSION GetBSPVersion();
	const QString GetMediaasprintf();
//PSR Fix for PAR# 1-3M9770D - Bootlace changes for barcodeScan and SPI test begin
#ifndef IS_BOOTLACE_APP
	//This function checks the media format, and returns the format type. 
	//Fix for 1-1713TYI - GR_General Status shows "Internal Mem ID as 512(null)	
#ifdef UNDER_CE	
	void BackupWSDCertificateToFlash();
	void BackupWSDCACertificateToFlash();
	void RestoreWSDCertificate();
	void RestoreWSDCACertificates(LPWSTR wPassword);
	void InstallRootCertificate(BOOL isLatest);
	int	CheckForServerCertificate(TCHAR *certSubjectName);
	void CleanSelfSignedFromFlash();
	void CleanWSDCACertFromFlash();
	void CleanSecureEmailCertFromFlash();
	void BackupEmailCertificateToFlash();
	void RestoreEmailCertificate();
	int CheckCertificateValidity(BOOL isSelfSigned);
  QString GetCertificateIssuerName(BOOL isSelfSigned);
#endif	
#endif
//PSR Fix for PAR# 1-3M9770D - Bootlace changes for barcodeScan and SPI test end
private:	// Methods
	short SetScreenEscape(int escapeCode, int dataIn);	// Screen escape
	void GetBoardDetails();					// Get details on processor board
	void DetermineRecorderVariant();	// Get details on the recorder variant
	// Conversions for the native screen brightness setting in the driver escape
	// to be converted to and from 10%-100% range
	short ScrnBackLightOffNative() {
		return 0;
	}
	;
	short ScrnBrightPCFromNative(short nat) {
		return ((short) (nat * 100) / 63);
	}
	;	///< Conversion from native to 10%-100%
	short ScrnBrightNativeFromPC(short pc) {
		return ((short) (pc * 63) / 100);
	}
	;			///< Conversion from 10%-100% to native
	// SPI access
	BOOL SPISelectDevice(USHORT device);
	USHORT PerformSlotIdTranslation(USHORT slotId);
	BOOL SPISetSpeed(USHORT device, ULONG baudRate, ULONG byteDelay);
	ULONG SPIWriteToDevice(UCHAR *pWriteBuffer, ULONG bytesToWrite, UCHAR slotID);
	ULONG SPIReadFromDevice(UCHAR *pReadBuffer, ULONG bufLen, UCHAR slotID);
	void OutputProtocolToDebug(BYTE *pBuffer, ULONG size, BOOL IsAWrite);
	BOOL InitialiseSRAM();
	BOOL SimulatedSRAMAccess(BOOL write);
private:	// Member variables
	HANDLE m_hSpi;							///< SPI Handle 
	ULONG m_watchDogKicks;	///< Number of times the watchdog has been kicked
	DWORD m_watchDogMaxTime;		///< Max time in MSec between watchdog kicks
	short m_lastScreenBrightness;			///< Last screen brightness setting	
	BOOL m_Initialised;			///< Indicates if the dal.has been initialised
	CHAR *m_pSRAMBase;						///< Ptr to Base of SRAM
	long m_SRAMLength;						///< Length of SRAM in bytes
	BOOL m_simulateSRAM;			///< TRUE to simulate SRAM, otherwise false
	UCHAR m_AP8Stats[AP8_STATS_LEN];			///< Stats info for AP8 SPI comms processor
	static QMutex m_FlashCS;				///< Flash Critical section
	USHORT m_IOCardSelected;				///< Current IO card selected
	BOOL m_IOPortIgnore;			///< Ignore IO Port if no cards fitted on PC
	T_DEV_TYPE m_deviceType;				///< Device Type DEV_XXXX in hw_defs
	// Information on processor board
	ULONG m_clpdStatus;						///< CPLD information
	int m_screenType;						///< Type of screen
	int m_frontUSBSet;		///< Status of front USB port set to device or host
	int m_SPIProcFW;						///< SPI Processor version number 
	int m_secProcFWVer;				///< Secondary Processor firmware version
	UCHAR m_MacAddress[MAC_ADDRESS_LEN];	///< Mac address
	int m_EthernetBoot;						///< Boot from Ethernet
	ULONG m_lastIdleTimeTick;						///< last idle timer tick for idle time calculations in mSec
	ULONG m_lastSystemTimeTick;	///< last system tick foir idle time calculation
	T_SHUTDOWN_MODE m_ShutDownMode;			///< Shutdown mode for DAL
	BOOL UserActivityFlag;			///< Indicates there is user activity (used for PW and Screen saver timeouts)
	SPIFMD_BLOCK spiFmdlock;
#ifdef EMULATOR
	CEmulator m_emul;		///< Emulator object for PC desktop and CE emulator
	CSerialComms m_IOCardSCI;				///< SCI port for IO card
#endif
#ifdef DBG_FILE_LOG_DAL_DBG_ENABLE
	CDebugFileLogger m_debugFileLogger;
#endif
};
// test caddy proto
void DALTestCaddy();
#endif //__DAL_H__

/// @file
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 System Absraction layer
/// @n Filename: DAL.cpp
/// @n Desc:	 Routines to wrap any hardware calls to allow emulator and
///				 recompilation on the PC under Visual Studio
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 18-09-15 Rajanbabu M Added method GetSecondaryProcFWVersion() to fetch secondary firmware version dynamically
// 05-11-14 Rajanbabu M Fixed PAR:1-3K94B3B - I/O inputs are not sensed and displayed on eZ Recorder.
// 20-10-14 Rajanbabu M Fixed PAR:1-3I2GTSM - WSD communication is not working on upgrading the firmware
//  139  Aristos  1.128.1.6.1.2 9/21/2011 2:51:42 PM  Hemant(HAIL)  
//  Resolved disable watchdog issue during firmware upgrade
//  138  Aristos  1.128.1.6.1.1 9/21/2011 12:52:01 PM  Hemant(HAIL)  
//  Error checking condition has been added for Disable WatchDog call.
//  137  Aristos  1.128.1.6.1.0 9/19/2011 4:51:10 PM  Hemant(HAIL)  
//  Stability recorder source code (JI Release) updated for WatchDog
//  Timer functionality.
//  136  Stability Project 1.128.1.6  7/4/2011 3:38:14 PM Hemant(HAIL) 
// Preprocessor definition added to access "storeapi.lib" from
//  different applications.
// $
//
// ****************************************************************
#include "StringDefinitions.h"
#include "DAL.h"
#include "BootData.h"
#include "SRAM.h"
#include "TV6Timer.h"
#include "V6globals.h"
#include "CertSubjectsStore.h"
#include "Crypto.h"
#include "V6MessageBoxDlg.h"
#include <QMessageBox>
#ifndef IS_BOOTLACE_APP	// Bootlace app doesnt know about CSysInfo
#include "SysInfo.h"
extern CSysInfo *pGlbSysInfo;
#else
#include "BaseProtocol.h"
#endif
#define BOOT_FROM_SD 4
#include "BatteryManager.h"
#include <QDirIterator>
#include <QDir>
HANDLE hCSPI;
//typedef HANDLE (*CSPIOPENHANDLE)(LPCWSTR lpDevName);
//typedef DWORD (*SPIWRITE) (HANDLE hCSPI, LPCVOID pBuffer, DWORD dwNumBytes, byte slotID);// typedefs move to DAL.h
//typedef DWORD (*SPIREAD) (HANDLE hCSPI, LPCVOID pBuffer, DWORD* dwNumBytes, byte slotID);
SPIWRITE pfSPIWrite;
SPIREAD pfSPIRead;
//typedef BOOL (*CSPICLOSEHANDLE)(HANDLE spiDeviceHandle);
#define iMX53_GET_FW_VERSION 0xB1
#define SHOW_IO_PROTOCOL_IN_DEBUG	0			// Display the IO protocol in dubug mode, if set to 1
QMutex m_hLEDIO;
const DWORD g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS = 5000;
CSPIOPENHANDLE pfCSPIOpenHandle;
CSPICLOSEHANDLE pfCSPICloseHandle;
#ifdef UNDER_CE
//Open interface for NOR Flash
typedef HANDLE (*InterfaceOpen)(void);
//Close interface for NOR Flash
typedef BOOL (*InterfaceClose)(HANDLE Interfacedll);
InterfaceOpen	 pfInterfaceOpen;
InterfaceClose	 pfInterfaceClose;
typedef BOOL (*WriteNORFlashBlock)(HANDLE h_Interface_g, PSPIFMD_BLOCK spiFmdBlock);
typedef BOOL (*ReadNORFlashBlock)(HANDLE h_Interface_g, PSPIFMD_BLOCK spiFmdBlock);
typedef BOOL (*NorFlashStoreSplashScreen)(HANDLE h_Interface_g, BYTE *pBuffer,ULONG sizeReq);
WriteNORFlashBlock		pfWriteNORFlashBlock;
ReadNORFlashBlock		pfReadNORFlashBlock;
NorFlashStoreSplashScreen pfNORFlashStoreSplashScreen;
typedef BOOL (*GetActiveImageVersion)(HANDLE h_Interface_g, PBSP_VERSION pBspVersion);
GetActiveImageVersion pfGetActiveImageVersion;
//PSR Fix for - 1-3DXWHML - QXe_General Status shows Expansion Board and Comms Board as connected though Support is removed begin
//This is new API added to InterfaceSDK.dll to get the status of the Backplane (Expansion) card. This is mostly for Ez recorder
//Because the Sx/QX always have the card fitted. For Ez alone this card is optional 
typedef BOOL (*GetBackPlaneBoardStatus) (HANDLE h_Interface_g, BYTE *bStatus);
GetBackPlaneBoardStatus pfGetBackPlaneBoardStatus;
//PSR Fix for - 1-3DXWHML - QXe_General Status shows Expansion Board and Comms Board as connected though Support is removed end
//PSR -Fix for 1-3E7Y0UX - SX/QX_"Common alarm" output configuration is missing from soft (pens) alarm begin
//Two more APIs added to InterfaceSdl.dll for addressing the Power relay in SX/QX
//This PAR will be addressed as part of SX/QX Maintainance PAR fixes. But OS changes received now.
typedef BOOL (*GetPowerRelayIOPinStatus) (HANDLE h_Interface_g, BYTE *bStatus);
typedef BOOL (*TogglePowerRelayIOPin) (HANDLE h_Interface_g);
//Global function pointers to get and set the PowerRelay pin status
GetPowerRelayIOPinStatus pfGetPowerRelayIOPinStatus;
TogglePowerRelayIOPin pfTogglePowerRelayIOPin;
//PSR -Fix for 1-3E7Y0UX - SX/QX_"Common alarm" output configuration is missing from soft (pens) alarm end
//Added for DRG1 Support
typedef BOOL (*SCRDisplayDetectionStatus)(HANDLE h_Interface_g, BYTE *bStatus);
SCRDisplayDetectionStatus pfSCRDisplayDetectionStatus;
#endif
// ************ Target Specific *************************************************************
#ifdef V6_TARGET	
#pragma message( "DAL V6 TARGET BUILD" )
#undef _MIPS_
#define _MIPS_ 1	///< Redefine MIPS to avoid problem in nkintr.h, see Topic 209 in V6 Firmware project in Starteam
// Platform includes
#include "ioctl.h"
#include "PwinUser.h"
#include "../../Tools/asprintf/asprintfdisk.h"
#include "../../Tools/asprintf/StoreMgr.h"
//
// Stability Project Fix:
//
#ifdef _LIB_FOR_V6APP_
#pragma comment(lib,"../../../Tools/asprintf/libs/retail/storeapi.lib")	// for V6App (default path)
#endif
#ifdef _LIB_FOR_FWUPGRADE_
#pragma comment(lib,"../../asprintf/libs/retail/storeapi.lib")	// for FirmwareUpgrade
#endif
#ifdef _LIB_FOR_BOOTLACE_
#pragma comment(lib,"../asprintf/libs/retail/storeapi.lib")	// For Bootlace
#endif

extern "C"
{
BOOL KernelIoControl(DWORD, LPVOID, DWORD, LPVOID, DWORD, LPDWORD );
}
QString V6internalCF	= "/SDMemory/");
QString V6externalCF	= "/SDMemory2/");
QString V6usbkey1	= "/Hard Disk/");
QString V6usbkey2	= "/Hard Disk2/");
QString V6ROOT	= "/");

// ************ Emulator Specific *************************************************************
#endif
#ifdef ARISTOS
#include <sys/ioctl.h>
#pragma message( "DAL V6 TARGET BUILD" )
#undef _MIPS_
#define _MIPS_ 1	///< Redefine MIPS to avoid problem in nkintr.h, see Topic 209 in V6 Firmware project in Starteam
// Platform includes
#include <sys/ioctl.h>
#endif
//
// Stability Project Fix:
//
#ifdef _LIB_FOR_V6APP_
#pragma comment(lib,"../../Tools/asprintf/libs/retail/storeapi.lib")	// for V6App (default path)
#endif
#ifdef _LIB_FOR_FWUPGRADE_
#pragma comment(lib,"../../asprintf/libs/retail/storeapi.lib")	// for FirmwareUpgrade
#endif
#ifdef _LIB_FOR_BOOTLACE_
#pragma comment(lib,"../asprintf/libs/retail/storeapi.lib")	// For Bootlace
#endif
QString V6internalSD = "/SDMemory/"; // In Final Release this will be SDMemory
QString V6externalSD = "/SDMemory2/";
QString V6usbkey1 = "/Hard Disk/";
QString V6usbkey2 = "/Hard Disk2/";
QString V6ROOT = "/";
//************* End specifics *****************************************************************
CDeviceAbstraction *CDeviceAbstraction::m_pDALInstance = NULL;
QMutex CDeviceAbstraction::m_CreationMutex;
QMutex CDeviceAbstraction::ms_kSPICritSect;
DWORD dwDisplayType = 0; //0 - 5.0, 1- 5.5
typedef struct {
	UINT8 ChannelSelect; //CS0, CS1, CS2, CS3
	UINT32 Freq;
	UINT32 BurstLength;  //bitcount, recommend 32bit as unit.
	BOOL SSPOL;
	BOOL SCLKPOL;
	BOOL SCLKPHA;
	UINT8 DRCTL; //SPI_RDY enable
	BOOL usedma;
} CSPI_BUSCONFIG_T, *PCSPI_BUSCONFIG_T;
DWORD RxData[100];
HANDLE hEvent;
// eCSPI exchange packet
typedef struct {
	PCSPI_BUSCONFIG_T pBusCnfg;
	LPVOID pTxBuf;
	LPVOID pRxBuf;
	UINT32 xchCnt; //32bit unit; It must equal to BurstLength/32 or BurstLength/32 +1 (if BurstLength isn't integral multiple of 32bit)
	LPWSTR xchEvent;
	UINT32 xchEventLength;
} CSPI_XCH_PKT_T, *PCSPI_XCH_PKT_T;
CSPI_BUSCONFIG_T buscnfg = { 0x0,  // ecspi channel, 0 1 2 3
		2000000,  // ecspi work freq
		32, // burstlength
		FALSE,
		FALSE,
		TRUE, 0,
		TRUE  // usedma
		};
BOOL CSPIExchange(HANDLE hCSPI, PCSPI_XCH_PKT_T pCspiXchPkt);
#ifndef UNDER_CE
T_DEV_TYPE CDeviceAbstraction::ms_eDesktopDeviceType = /*DEV_PC_MULTI*/DEV_PC_MINI;
#endif
QMutex CDeviceAbstraction::m_FlashCS;
////#ifdef UNDER_CE
//T_DEV_TYPE CDeviceAbstraction::ms_eDesktopDeviceType = DEV_PC_MULTI;
//T_DEV_TYPE CDeviceAbstraction::ms_eDesktopDeviceType = DEV_PC_MINI;
//T_DEV_TYPE CDeviceAbstraction::ms_eDesktopDeviceType = DEV_PC_EZTREND;
//#endif
//**********************************************************************
/// CDeviceAbstraction constructor
///
//**********************************************************************
CDeviceAbstraction::CDeviceAbstraction()
#ifdef DBG_FILE_LOG_DAL_DBG_ENABLE
    : m_debugFileLogger("/SDMemory/DalLogFile.txt", TRUE, (15*1024*1024) )
    #endif
{
	// Set stream handles to NULL
	m_hLEDIO = NULL;
	m_hSpi = NULL;
	// Init SRAM details
	m_pSRAMBase = NULL;
	m_SRAMLength = 0;
	// Init watchdog info
	m_watchDogKicks = 0;
	m_watchDogMaxTime = 0;
	m_lastScreenBrightness = 0;		// Last screen brightness setting
	m_simulateSRAM = TRUE;			// SRAM always simulates unless it's a target board later then REV 2
	m_Initialised = FALSE;
	m_IOPortIgnore = FALSE;			// Don't ignore IO port unles specified
	// default board information
	m_clpdStatus = 0;
	m_screenType = SCRN_UNKNOWN;
	m_frontUSBSet = USB_FRONT_DEVICE;
	m_SPIProcFW = 0;
	m_secProcFWVer = 0;
	m_pPaths = NULL;
	m_lastIdleTimeTick = 0;
	m_lastSystemTimeTick = 0;
	m_ShutDownMode = SHUTDOWN_MODE_RESET;
	ClearUserActivity();
	m_EthernetBoot = FALSE;
	m_pfSRAMClose = NULL;
	m_pfGetPointer = NULL;
	m_pfFreePointer = NULL;
	m_hInsSRamDLL = NULL;
	m_pfSRAMOPEN = NULL;
	m_hSramDriver = NULL;
}
//**********************************************************************
///
/// Instance creation of CDeviceAbstraction singleton
///
/// @return		pointer to single instance of CDeviceAbstraction
/// 
//**********************************************************************
CDeviceAbstraction* CDeviceAbstraction::GetHandle() {
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;
	if (NULL == m_pDALInstance) {
		// An instance has yet to be completed
		waitSingleObjectResult = m_CreationMutex.tryLock(g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);
		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:
			// Object was signaled
			if (NULL == m_pDALInstance) {
				m_pDALInstance = new CDeviceAbstraction;
			}
			m_CreationMutex.unlock();
			break;
		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
			QMessageBox(QMessageBox::Information, "DAL WaitForSingleObject Error", "Error", QMessageBox::Ok).exec();
			DebugBreak();
			break;
		}
		// Close the Mutex as no longer required
		//No need to close the mutex in Qt;
	}
	return (m_pDALInstance);
}
//**********************************************************************
///
/// Deletes the instance of the singleton from memory
///
/// @return		Nothing
/// 
//**********************************************************************
void CDeviceAbstraction::CleanUp() {
	Shutdown();
	delete m_pDALInstance;
	m_pDALInstance = NULL;
}
typedef BOOL (*CofigureFrontUSB_VBUS)(HANDLE h_Interface_g);
//**********************************************************************
///
/// Initialise the Device abstraction layer (DAL) 
///
/// @return		TRUE, if successful, FALSE if failed, Do not continue if failed
/// 
//**********************************************************************
BOOL CDeviceAbstraction::Initialise() {
	//CB: @delete
	CofigureFrontUSB_VBUS pfCofigureFrontUSB_VBUS;
	OutputDebugString("CB:CDeviceAbstraction::Initialise() CHECK...\n");
	if (m_Initialised == TRUE)
		return TRUE;
	//CB: @delete
	OutputDebugString("CB:CDeviceAbstraction::Initialise() Start...\n");
	//CB: @delete
	OutputDebugString("CB:CDeviceAbstraction::Initialise() End...\n");
	return TRUE;
}
//**********************************************************************
///
/// Shutdown the Device abstraction layer (DAL) 
///
/// @return		TRUE, if successful, FALSE if failed, Do not continue if failed
/// 
//**********************************************************************
BOOL CDeviceAbstraction::Shutdown() {
#ifdef ARISTOS
#define V6_TARGET
#endif//
#ifdef V6_TARGET
    //if( m_hLEDIO != NULL )
    //	//No need to close the mutex in Qt		// Close handle on the LED driver
    if( m_hSpi != NULL )
        //No need to close the mutex in Qt		// Close handle on the SPI driver
        //SPI
        BOOL retVal;
#endif
#ifdef ARISTOS
    //m_emul.Shutdown();
#undef V6_TARGET
#endif
    m_Initialised = FALSE;
    // Clean-up the storage paths object
    m_pPaths->Cleanup();
    // if SRAM is simulated close this down, make sure the SRAM is saved out before being deleted
    if (m_simulateSRAM) {
        if (m_pSRAMBase != NULL) {
            // Save SRAM so it persists
            SimulatedSRAMAccess( BF_WRITE);
            //free oss SRAM allocation
            delete[] m_pSRAMBase;
            m_pSRAMBase = NULL;
        }
    } else {
        //Take SRAM backup for Battery Reset operation.
        BackupSRAMToDiskCopy(BF_BLK_SRAM_BKP_ON_BAT_RESET);
        m_pfFreePointer(m_pSRAMBase);
        m_pfSRAMClose(m_hSramDriver);
        FreeLibrary(m_hInsSRamDLL);
        m_pfFreePointer = NULL;
        m_pfSRAMClose = NULL;
        m_pSRAMBase = NULL;
        m_hInsSRamDLL = NULL;
    }
    // Determine shutdown mode and take appropriate action
    switch (m_ShutDownMode) {
    // Reset the unit
    case SHUTDOWN_MODE_RESET:				// Run the reset line once the system has shutdown
    case SHUTDOWN_MODE_CONFIG_CHANGE:		// Config Change requires a restart
    {
        PerformReboot();		// Reboot the system now, OpPanel has completed and we know control sequencer is done
        // as we are in the same thread
        break;
    }
        // Pause unit shutdown
    case SHUTDOWN_MODE_STOP:				// Stop the system a display "safe to power off" dialog
    case SHUTDOWN_MODE_SAFE_TO_POWER_OFF:	// Safe to power down state
    {
#if (!defined IS_BOOTLACE_APP) && (defined UNDER_CE)
        QString strTitle( "Battery Reset!!!");
        QString strMessage;
        strMessage = QString::asprintf("\nRecorder is ready for battery replacement!!!\n\n Power off the unit \n and replace the battery.\n ");
        CV6MessageBoxDlg kMsgDlg( strTitle, strMessage );
        kMsgDlg.ShowOkBtn(false);
        kMsgDlg.exec();
#endif
#ifdef V6_TARGET		
        // If we want the system to stop, loop forever, user will require to power cycle the unit
        // this is required on the target only when powering off a recorder gracefully.
        while(1)
        {
            sleep(100);
            KickWatchdog();
        }
#endif
        break;
    }
        // Exit application
    case SHUTDOWN_MODE_EXIT:						// Exit the application, for development only
        break;
    case SHUTDOWN_MODE_FW_UPDATE:				// Firmware Update shutdown mode
    {
        // delete the contents of the sounds directory as there may be sounds with new names
        QString wcaSoundPath = "";
        int iMaxPath = MAX_PATH;
        //_wcsnset_s( wcaSoundPath, MAX_PATH, 0, iMaxPath );
        SecureZeroMemory(wcaSoundPath, sizeof(wcaSoundPath));
        QString ext = "*.wav";
        BuildPath(IDS_INTERNAL_SD, IDS_WAVS, &ext, &wcaSoundPath, iMaxPath);
        // now find and delete the sound file with this prefix
        WIN32_FIND_DATA tindexOfFileData;
        tindexOfFileData.cFileName[0] = '\0';
        QFile kFileToDelete;
        QDirIterator it(wcaSoundPath, QStringList() << "", QDir::NoFilter, QDirIterator::Subdirectories);
        // insert the first valid filename found within the editbox
        while (it.hasNext()) {
            QString fileName = it.next();
            BuildPath(IDS_INTERNAL_SD, IDS_WAVS, &fileName, &wcaSoundPath, MAX_PATH);
            BOOL writeableSuccess = FALSE;
            CFileStatus status;
            try {
                // Get current status
                if (CStorage::GetStatus(wcaSoundPath, &status) == TRUE) {
                    // Clear read only status
                    status.m_attribute &= 1;
                    CStorage::SetStatus(wcaSoundPath, &status);
                    try {
                        // Attempt to delete the file
                        QFile::remove(wcaSoundPath);
                    } catch (std::exception *pEx) {
                        // File could not be deleted, probably open as we have already set as writable
                        delete pEx;
                    }
                }
            } catch (...) {
                // unhandled exception
#ifdef _DEBUG
                DebugBreak();
#endif
            }
        }
    }
        break;
    default: {
        break;
    }
    }
    return TRUE;
}
//=====================================================================================
// Identification
//=====================================================================================
//**********************************************************************
/// Is this a PC software build, not firmware 
///
/// @return		TRUE if a PC software build otherwise FALSE
//**********************************************************************
BOOL CDeviceAbstraction::IsPCSoftware() {
#ifdef TTR6SETUP	
    return TRUE;
#endif
    if (m_deviceType == DEV_PC_SCREEN_DESIGNER || m_deviceType == DEV_PC_TTR6SETUP || m_deviceType == DEV_TEST)
        return TRUE;
    else
        return FALSE;
}
//**********************************************************************
/// Is this a recorder firmware build either PC or Embedded
/// PC(V6Desktop) or Embedded(V6App)
///
/// @return		TRUE if a recorder firmware build otherwise FALSE
//**********************************************************************
BOOL CDeviceAbstraction::IsRecorderPCorEmbedded() {
#ifdef TTR6SETUP	
    return FALSE;
#endif
	//ARISTOS QXe Device Type updates
	if ((m_deviceType == DEV_ARISTOS_MINITREND) || (m_deviceType == DEV_ARISTOS_MULTIPLUS)
			|| (m_deviceType == DEV_ARISTOS_EZTREND) || (m_deviceType == DEV_SCR_MINITREND)
			|| (m_deviceType == DEV_XS_EZTREND) || (m_deviceType == DEV_PC_MINI) || (m_deviceType == DEV_PC_MULTI)
			|| (m_deviceType == DEV_PC_EZTREND)) {
		return TRUE;
	} else {
		return FALSE;
	}
}
//**********************************************************************
/// Is this a recorder firmware build only(V6App)
///
/// @return		TRUE if a recorder firmware embedded only build otherwise FALSE
//**********************************************************************
BOOL CDeviceAbstraction::IsRecorderEmbedded() {
	//ARISTOS QXe Device Type updates
	if ((m_deviceType == DEV_ARISTOS_MINITREND) || (m_deviceType == DEV_ARISTOS_MULTIPLUS)
			|| (m_deviceType == DEV_ARISTOS_EZTREND) || (m_deviceType == DEV_SCR_MINITREND)
			|| (m_deviceType == DEV_XS_EZTREND)) {
		return TRUE;
	}
	return FALSE;
}
//**********************************************************************
/// Is this a mini/multi recorder firmware build only(V6App)
///
/// @return		TRUE if a recorder firmware mini/multi only build otherwise FALSE
//**********************************************************************
BOOL CDeviceAbstraction::IsRecorderMiniMultiEmbedded() {
	if (m_deviceType == DEV_ARISTOS_MINITREND || m_deviceType == DEV_ARISTOS_MULTIPLUS
			|| m_deviceType == DEV_SCR_MINITREND) {
		return TRUE;
	} else {
		return FALSE;
	}
}
//**********************************************************************
/// Is this a eZ recorder build only(V6App)
///
/// @return		TRUE if a recorder firmware mini/multi only build otherwise FALSE
//**********************************************************************
BOOL CDeviceAbstraction::IsRecorderEzTrend() {
	if ((m_deviceType == DEV_PC_EZTREND) || (m_deviceType == DEV_ARISTOS_EZTREND) || (m_deviceType == DEV_XS_EZTREND)) {
		return TRUE;
	} else {
		return FALSE;
	}
}
//**********************************************************************
/// Is this a eZ recorder build only(V6App)
///
/// @return		TRUE if a recorder firmware mini/multi only build otherwise FALSE
//**********************************************************************
BOOL CDeviceAbstraction::IsRecorderMini() {
	if ((m_deviceType == DEV_ARISTOS_MINITREND) || (m_deviceType == DEV_PC_MINI)) {
		return TRUE;
	} else {
		return FALSE;
	}
}
//**********************************************************************
/// Is this a multi recorder build only(V6App)
///
/// @return		TRUE if a recorder firmware multi only build otherwise FALSE
//**********************************************************************
BOOL CDeviceAbstraction::IsRecorderMulti() {
	if (m_deviceType == DEV_ARISTOS_MULTIPLUS || m_deviceType == DEV_PC_MULTI || m_deviceType == DEV_SCR_MINITREND) {
		return TRUE;
	} else {
		return FALSE;
	}
}
//=====================================================================================
// FLASH HANDLING
//=====================================================================================
#define DAL_FLASH_LOCK_TIMEOUT	5000	///< 5 Second timeout for exclusive flash read/write
//**********************************************************************
///
/// Read/Write a Block of boot flash, or from simulated flash on disk for emulation
///
/// @param[in]	flashWrite - set to BF_READ for reqad flash Block and BF_WRITE for write flash Block
/// @param[in]	BlockNumber - Number of flash Block see BK_BLK_
/// @param[in]	sizeReq - Number of bytes to read or write
/// @param[in,out]	pBuffer - ptr to buffer, data to write or buffer to read
/// @return		TRUE, if flash successful, FALSE if R/W failed or parameter check fails
/// 
//**********************************************************************
BOOL CDeviceAbstraction::RWBootFlashBlock(BOOL flashWrite, ULONG BlockNumber, ULONG sizeReq, BYTE *pBuffer) {
#ifdef ARISTOS //commented out by kranti for qxe up
#define V6_TARGET
#endif//
	BOOL retVal = FALSE;
#ifndef DEMO_CODE
	// Check that the Block requested is within valid range and that the number of bytes
	// does not exceed a single Block in size.
	if (BlockNumber < BF_STARTBLOCK || BlockNumber > BF_ENDBLOCK || sizeReq > BF_MAXSIZE) {
		FatalError(("DAL:Flash param invalid, Block(%d), Size req(%d) \r\n"), BlockNumber, sizeReq);
		return FALSE;
	}
	m_FlashCS - Block();
#ifdef V6_TARGET
    DWORD sizeRet;
    // Read from or Write to BootFlash depending on flashWrite param
    /// TODO: Work on the IOCTL Code
    if( flashWrite )
        retVal = KernelIoControl(IOCTL_WRITE_FLASH_PARAMBLOCK,&BlockNumber,sizeof(ULONG),pBuffer,sizeReq,&sizeRet);
    else
        retVal = KernelIoControl(IOCTL_READ_FLASH_PARAMBLOCK,&BlockNumber,sizeof(ULONG),pBuffer,sizeReq,&sizeRet);
    spiFmdBlock.pBlockBuff = (LPBYTE)pBuffer;
    spiFmdBlock.dwBlockBuffSize = sizeReq;
    spiFmdBlock.BlockID = BlockNumber;
    //Flash Write
    if( flashWrite )
    {
        retVal = pfWriteNORFlashBlock(m_hInterfaceHandle, &spiFmdBlock);
    }
    else
    {
        retVal = pfReadNORFlashBlock(m_hInterfaceHandle, &spiFmdBlock);
    }
#else	// Emulator
	//	 Retrive/write a flash Block in simulated boot flash
	retVal = ReadWriteNV(flashWrite, sizeReq, (LPWORD) pBuffer, (UCHAR) BlockNumber, BF_MAXSIZE);
#endif  //commented by kranti
	m_FlashCSBlock();
#ifdef ARISTOS
#undef V6_TARGET
#endif//
#endif
	return retVal;
}
//=====================================================================================
// GPIO Specific
//=====================================================================================
//**********************************************************************
///
/// Get the Status of the ethernet PHY
///
/// @return		PHY status in bottom 5 bits, use PHYSTAT_XXX macros in DAL.h to decipher
/// 
//**********************************************************************
ULONG CDeviceAbstraction::GetPHYStatus(ULONG &ulLinkSpeed) {
#ifdef ARISTOS
#define V6_TARGET
#endif//
#ifndef DEMO_CODE
#ifdef V6_TARGET
    DWORD dwOut = 0;
    ULONG ulState = 0;
    NIC_STATISTICS nicStat;
    DeviceIoControl(m_hPHYIO, IOCTL_NDISUIO_OPEN_DEVICE, TEXT("FEC1"),wcslen(TEXT("FEC1"))*sizeof(TCHAR),NULL,0, &dwOut, NULL);
    nicStat.ptcDeviceName ="FEC1";
    if(!DeviceIoControl(m_hPHYIO, IOCTL_NDISUIO_NIC_STATISTICS, NULL, 0,&nicStat, sizeof(NIC_STATISTICS), &dwOut, NULL))
    {
        FatalError(("DAL:Get PHY status failed \n"));
    }
    ulLinkSpeed = nicStat.LinkSpeed;
    return(nicStat.MediaState);
#else
	// Emulated PHY status will set next bit each time routine called
	static ULONG PHYStatus = 0;
	PHYStatus++;
	return (1 << (PHYStatus % 5));
#endif
#ifdef ARISTOS
#undef V6_TARGET
#endif//
	//#ifdef V6_TARGET
	//	DWORD dwOut = 0;
	//	ULONG ulState = 0;
	//
	//	if(!DeviceIoControl(m_hLEDIO, IOCTL_LED_GET_PHYPLED, NULL, 0, &ulState, sizeof(ulState), &dwOut, NULL))
	//	{
	//		FatalError(("DAL:Get PHY status failed \n"));
	//	}
	//	return( ulState );
	//#else
	//	// Emulated PHY status will set next bit each time routine called
	//	static ULONG PHYStatus=0;
	//	PHYStatus++;
	//	return( 1 << (PHYStatus % 5) );
	//#endif
#endif
}
//**********************************************************************
///
/// Set the state of the Compact flash LED
///
/// @param[in]	turnLEDOn - use TURN_LED_ON to turn LED on, TURN_LED_OFF for off.
/// @return		TRUE if device call success, FALSE if failed
///
//**********************************************************************
BOOL CDeviceAbstraction::SetCFLED(BOOL turnLEDOn) {
#ifdef ARISTOS
#define V6_TARGET
#endif//
#ifdef V6_TARGET
    DWORD dwOut = 0;
    ULONG ulState = 0;
    char test;
    BYTE out;
    if( turnLEDOn )
    {
        // Turn LED On
        //	if(!DeviceIoControl(m_hLEDIO, IOCTL_LED_SET_CF, NULL, 0, NULL, 0, &dwOut, NULL))
        if (!DeviceIoControl(m_hLEDIO,   // file handle to the driver
                             IOCTL_LED_SET_CF,    // I/O control code
                             &test,      // in buffer
                             sizeof(test),   // in buffer size
                             NULL,         // out buffer
                             0,          // out buffer size
                             NULL,         // pointer to number of bytes returned
                             NULL))
        {
            FatalError(("DAL:Turn ON LED Failed \n"));
            return FALSE;
        }
    }
    else
    {
        // Turn LED off
        //if(!DeviceIoControl(m_hLEDIO, IOCTL_LED_CLR_CF, NULL, 0, NULL, 0, &dwOut, NULL))
        if (!DeviceIoControl(m_hLEDIO,   // file handle to the driver
                             IOCTL_LED_CLR_CF,    // I/O control code
                             &test,      // in buffer
                             sizeof(test),   // in buffer size
                             &out,         // out buffer
                             0,          // out buffer size
                             NULL,         // pointer to number of bytes returned
                             NULL))        // ignored (=NULL)
        {
            FatalError(("DAL:Turn OFF SD LED Failed \n"));
            return FALSE;
        }
    }
#else
	if (turnLEDOn)
		qDebug(("DAL : Turn ON SD LED\n"));
	else
		qDebug(("DAL : Turn OFF LED\n"));
#endif
#ifdef ARISTOS
#undef V6_TARGET
#endif//
	return ( TRUE);
}
//**********************************************************************
///
/// Reset the USB
///
/// @return		nothing
///
//**********************************************************************
void CDeviceAbstraction::ResetUSB() {
#ifdef V6_TARGET
    DWORD dwOut = 0;
    DeviceIoControl(m_hLEDIO, IOCTL_LED_MISC_GET_SYSTEM_REVISION+1, NULL, 0, NULL, 0, &dwOut, NULL);
    sleep(500);
    DeviceIoControl(m_hLEDIO, IOCTL_LED_MISC_GET_SYSTEM_REVISION+2, NULL, 0, NULL, 0, &dwOut, NULL);
#else
	qDebug(("DAL : Reset USB\n"));
#endif
}
//**********************************************************************
///
/// Kick the watchdog, must be reset less then every 30 seconds
///
/// @return		TRUE if device call success, FALSE if failed
///
//**********************************************************************
BOOL CDeviceAbstraction::KickWatchdog() {
#ifndef IS_BOOTLACE_APP
#ifndef DEBUG	// If we are in debug mode then we will be breakpointing so we don't want hardware watchdog running
	static DWORD lastTickCount = 0;
	DWORD thisTimeGap = 0;
	// Maintain m_watchDogMaxTime as the longest period in MSec between
	// watchdog resets, this figure should not get close to 30,000 Msec.
	if (lastTickCount > 0) {
		thisTimeGap = GetTickCount() - lastTickCount;
		if (thisTimeGap > m_watchDogMaxTime) {
			m_watchDogMaxTime = thisTimeGap;
			if (m_watchDogMaxTime > DAL_WATCHDOG_WARNING) {
				// Removed this Logs as this log is not exact and accurate.
				// Accurate log is added into the ThredInfo.cpp thread.
				// WCHAR strMsg[MAX_PATH] = { 0 };
				// swprintf(strMsg, "DAL: DANGER Watchdog %d secs from last reset(MAX 30)\n", MSEC_TO_SEC(m_watchDogMaxTime) );
				// LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_WARNING,  strMsg );
				// FatalError(("DAL: DANGER Watchdog %d secs from last reset(MAX 30)\n"),MSEC_TO_SEC(m_watchDogMaxTime) );
			}
		}
	}
	lastTickCount = GetTickCount();
	m_watchDogKicks++;	// Increment total number of watchdog kicks
#ifdef ARISTOS
#define V6_TARGET
#endif//
#ifdef V6_TARGET
    DWORD dwOut = 0;
    ULONG ulState = 0;
    // Kick the watchdog
    if(!DeviceIoControl(m_hLEDIO, IOCTL_LED_MISC_ACK_WATCHDOG, NULL, 0, NULL, 0, &dwOut, NULL))
    {
        // Added logs as this scenario has happend in some builds and we need more logs for it.
        LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR,  "FATAL_ERROR - DAL: Failed to Kick watchdog" );
        LPVOID lpMsgBuf;
        FormatMessage( FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
                         NULL, GetLastError(), 0, (LPTSTR) &lpMsgBuf,	0, NULL );
        // Display the string.
        LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR,  (LPCTSTR)lpMsgBuf );
        // Free the buffer.
        LocalFree( lpMsgBuf );
        // FatalError(("DAL: Failed to Kick watchdog \n"));
        return FALSE;
    }
#endif	// #ifdef V6_TARGET
#ifdef ARISTOS
#undef V6_TARGET
#endif//
	//	qDebug(("DAL : Kick Watchdog %d msec from last time\n"),m_watchDogMaxTime );
#endif	// #ifndef DEBUG
#endif  // #ifndef BOOTLACE_APP
	return TRUE;
}
//**********************************************************************
///
/// Disable the watchdog at runtime
///
/// @return		TRUE if device call success, FALSE if failed
///
//**********************************************************************
BOOL CDeviceAbstraction::DisableWatchdog() {
#ifndef DEBUG	// If we are in debug mode then we will be breakpointing so we don't want hardware watchdog running
#ifdef ARISTOS
    DWORD dwOut = 0;
    //Disable WatchDog
    if(!DeviceIoControl(m_hLEDIO, IOCTL_LED_DISABLE_WATCHDOG, NULL, 0, NULL, 0, &dwOut, NULL))
    {
        FatalError(("DAL: Failed to Disable watchdog \n"));
        return FALSE;
    }
#endif	// #ifdef V6_TARGET
#endif	// #ifndef DEBUG
	return TRUE;
}
//**********************************************************************
///
/// Clear the USB
///
/// @return		nothing
///
//**********************************************************************
void CDeviceAbstraction::ClearUSB() {
#ifdef V6_TARGET
    DWORD dwOut = 0;
    DeviceIoControl(m_hLEDIO, IOCTL_LED_MISC_GET_SYSTEM_REVISION+1, NULL, 0, NULL, 0, &dwOut, NULL);
    //sleep(500);
#else
	qDebug("DAL : Reset USB\n");
#endif
}
//**********************************************************************
///
/// Perform a cold boot on the system.
///
/// @return		FALSE if call Failed, otherwise TRUE but reset will happen by then
///
//**********************************************************************
BOOL CDeviceAbstraction::PerformReboot() {
	BOOL retVal = FALSE;
#ifdef ARISTOS
#define V6_TARGET
#endif//
#ifndef DEBUG	// Don't run reset line if we are in debug mode, more then likely EVC will be running and it will cause problems
#ifdef V6_TARGET
    SetCleanRebootFlag();		// Ensure cold start not warm
    //retVal = KernelIoControl(IOCTL_LED_HAL_REBOOT,NULL,0,NULL,0,NULL);
    char test;
    /// TODO: Change the reboot led
    /// Now reboot the system
#endif
#endif
#ifdef ARISTOS
#undef V6_TARGET
#endif//
	qDebug(("REBOOT REQUEST\n"));
	// If successful we won't get here for V6 Target, the unit will be resetting.
	return retVal;
}
//**********************************************************************
///
/// Perform a reset on the secondary processor
///
/// @return		FALSE if call Failed, otherwise TRUE but reset will happen by then
///
//**********************************************************************
BOOL CDeviceAbstraction::PerformSecondaryReset() {
	BOOL retVal = FALSE;
#ifdef ARISTOS
#define V6_TARGET
#endif//
#ifndef DEBUG	// Don't run reset line if we are in debug mode, more then likely EVC will be running and it will cause problems
#ifdef V6_TARGET
    //retVal = KernelIoControl(IOCTL_LED_HAL_REBOOT,NULL,0,NULL,0,NULL);
    char test;
    if(IsRecorderEzTrend())
    {
        return TRUE;
    }
/// TODO: Change the reboot led
/// Perform secondary porcessor reset.
#endif
#endif
#ifdef ARISTOS
#undef V6_TARGET
#endif//
	// If successful we won't get here for V6 Target, the unit will be resetting.
	return retVal;
}
//=====================================================================================
// Screen control
//=====================================================================================
//**********************************************************************
/// Call to run touch screen calibration
///
/// @return		TRUE if calibration completed ok, otherwise FALSE
///
//**********************************************************************
extern "C" BOOL TouchCalibrate(void);
BOOL CDeviceAbstraction::CalibrateScreen() {
	BOOL calibrateSuccess = FALSE;
#ifdef ARISTOS
#define V6_TARGET
#endif
#ifdef V6_TARGET
    calibrateSuccess = TouchCalibrate();
#endif
#ifdef ARISTOS
#undef V6_TARGET
#endif
	return calibrateSuccess;
}
//**********************************************************************
///
/// Send escape codes to screen driver
///
/// @param[in]	escapeCode - DRVESC_GETBACKLIGHTBRIGHTNESS or DRVESC_SETBACKLIGHTBRIGHTNESS
/// @param[in]	dataIn - The data required to send to the driver for the escape code
/// @return		SCREEN_BRIGHT_FAIL if failed or 0 to 255 for native brightness units
///
//**********************************************************************
short CDeviceAbstraction::SetScreenEscape(int escapeCode, int dataIn) {
#ifdef ARISTOS
#define V6_TARGET
#endif
	char retVal = 0;
#ifdef V6_TARGET
/// TODO: Send esc code to screen driver
#endif
#ifdef ARISTOS
#undef V6_TARGET
#endif
	return (short) retVal;
}
//**********************************************************************
///
/// Set screen brightness in % or turn off backlight
///
/// @param[in]	pcLevel - from SCRN_DIMMEST_PC to SCRN_BRIGHTEST_PC or to turn backlight off use SCRN_BACKLIGHT_OFF
/// @return		Level that was set as percentage
///
//**********************************************************************
short CDeviceAbstraction::SetScreenBrightness(short pcLevel) {
	//	pcLevel = pcLevel*63/100; // new brightness range 0 to 63
    //	pcLevel = pcLevel*63/100; // new brightness range 0 to 63
    short nativeLevel;		// Native screen level
    // Check if this needs to switch the backlight off, setting up nativeLevel accrodingly
    if( pcLevel == SCRN_BACKLIGHT_OFF )
    {
        nativeLevel = ScrnBackLightOffNative();
    }
    else
    {
        // Brightness setting required, check that it's withing the correct limits
        // if from 1 to 9%, then set to minimum of 10%
        if( pcLevel < SCRN_DIMMEST_PC )
            pcLevel = SCRN_DIMMEST_PC;
        // If over 100%, then set to 100%
        if( pcLevel > SCRN_BRIGHTEST_PC )
            pcLevel = SCRN_BRIGHTEST_PC;
        // Get nativeLevel of %age brightness
        nativeLevel = ScrnBrightNativeFromPC(pcLevel);
        m_lastScreenBrightness = nativeLevel;
    }
#ifdef ARISTOS
#define V6_TARGET
#endif
//#ifdef V6_TARGET
    /*if ( nativeLevel <= 20 )
    nativeLevel = 20;*/
    if( /*SetScreenEscape(DRVESC_SETBACKLIGHTBRIGHTNESS, nativeLevel) == SCREEN_BRIGHT_FAIL*/0 )
    {
        qDebug()<<"DAL: Screen brightness set FAILED \n";
        return -1;
    }
//#endif
#ifdef ARISTOS
#undef V6_TARGET
#endif
    return pcLevel;
}
//**********************************************************************
///
/// Get screen brightness in % or if the Backlight is Off
///
/// @return		Screen brightness as a percentage,SCRN_DIMMEST_PC to SCRN_BRIGHTEST_PC or
///				SCRN_BACKLIGHT_OFF if the backlight has been switched off,SCREEN_BRIGHT_FAIL if failed to set
///
//**********************************************************************
short CDeviceAbstraction::GetScreenBrightness() {
	short nativeLevel = SCREEN_BRIGHT_FAIL;
	short pcLevel = SCREEN_BRIGHT_FAIL;
	//#ifdef ARISTOS
	//	#define V6_TARGET
	//#endif
	//
#ifdef V6_TARGET
    nativeLevel = SetScreenEscape(DRVESC_GETBACKLIGHTBRIGHTNESS, 0);
#else
	nativeLevel = m_lastScreenBrightness;
#endif
	//#ifdef ARISTOS
	//	#undef V6_TARGET
	//#endif
	//
	// If the driver has return a valid value, check if it is backlight off or between a valid range
	if (nativeLevel != SCREEN_BRIGHT_FAIL) {
		// Report If the backlight is off
		if (nativeLevel == ScrnBackLightOffNative())
			pcLevel = SCRN_BACKLIGHT_OFF;
		else {
			// We have a valid range so convert from native to Percentage
			pcLevel = ScrnBrightPCFromNative(nativeLevel);
			qDebug(("DAL: Read Screen brightness is %d%%\n"), pcLevel);
		}
	}
	return pcLevel;
}
//=====================================================================================
// SPI Routines
//=====================================================================================
#define SPI_DEVICE_SELECT_FAIL	0xFFFFFFFF			///< Indicates that SPI device could not be selected
//**********************************************************************
///
/// Select an SPI Device
///
/// @param[in]	device - spi device to select, SPI_DEVICE_CARD1 to SPI_DEVICE_CARD9 or SPI_DEVICE_RTC
/// @return		TRUE if successful, FALSE for failure to select or Invalid device number
///
//**********************************************************************
BOOL CDeviceAbstraction::SPISelectDevice(USHORT device) {
	return TRUE;
	BOOL retVal = TRUE;
#ifdef ARISTOS
#define V6_TARGET
#endif//
#ifdef V6_TARGET
    ms_kSPICritSect.lock();
    // perform slot id remapping if necessary
    device = PerformSlotIdTranslation(device);
    /// TODO : Initialise SPI device
    ms_kSPICritSect.unlock();
#endif
#ifdef ARISTOS
#undef V6_TARGET
#endif//Rahul
	return retVal;
}
//**********************************************************************
///
/// Helper method used to remap slots if necessary (such as the Ez IO card slot)
///
/// @param[in]	device - spi device to select, SPI_DEVICE_CARD1 to SPI_DEVICE_CARD9 or SPI_DEVICE_RTC
/// @return		the slot id, remapped if necessary, otherwise left it was
///
/// @note from rev 3 boards onwards the direct SPI conection is replaced with Dual Port ram
///			being fed by a dedicated processor.
///
//**********************************************************************
USHORT CDeviceAbstraction::PerformSlotIdTranslation(USHORT slotId) {
	// if an Ez then we must set IO cards on the 2nd slot to the 3rd device card
	// instead of the 7th
	if (DEV_ARISTOS_EZTREND == m_deviceType || DEV_XS_EZTREND == m_deviceType)    //ARISTOS QXe Device Type updates
			{
		// this is an Ez, check the slot id
		if ( SPI_DEVICE_CARD7 == slotId) {
			// this is the digital IO slot, remap to the 3rd slot
			slotId = SPI_DEVICE_CARD3;
		}
	}
	return slotId;
}
//**********************************************************************
///
/// Setup the SPI baud rate and intercharacter delay timout
///
/// @param[in]	device - spi device to select, SPI_DEVICE_CARD1 to SPI_DEVICE_CARD9 or SPI_DEVICE_RTC
/// @param[in]	baudRate - speed of spi bus in Hz
/// @param[in]	byteDelay - max time between characters, in uSec
/// @return		TRUE if successful, FALSE for failure
///
/// @note from rev 3 boards onwards the direct SPI conection is replaced with Dual Port ram
///			being fed by a dedicated processor.
///
//**********************************************************************
BOOL CDeviceAbstraction::SPISetSpeed(USHORT device, ULONG baudRate, ULONG byteDelay) {
	return TRUE;
#ifdef ARISTOS
#define V6_TARGET
#endif//
#ifdef V6_TARGET
    ms_kSPICritSect.lock();
    // Select the device
    SPISelectDevice( device );
    // Set the intercharacter delay timout in uSec, this will act as interchacater delay for
    // reads to the RTC, or will act as a timeout for the IO cards as intercharacter delay
    // is controlled by the GPIO from the IO Card.
    /// TODO: Code to set speed
    if(!DeviceIoControl(m_hSpi, IOCTL_SPI_SET_BYTEDELAY, &byteDelay, sizeof(byteDelay), NULL, 0, NULL, NULL))
    {
        FatalError(("DAL: SPI failed to set Intercharacter delay\n"));
        return FALSE;
    }
    // Set the transfer speed of the SPI bus in Hz.
    if(!DeviceIoControl(m_hSpi, IOCTL_SPI_SET_BAUDRATE, &baudRate, sizeof(baudRate), NULL, 0, NULL, NULL))
    {
        FatalError(("DAL: SPI failed to set Baud Rate\n"));
        return FALSE;
    }
    ms_kSPICritSect.unlock();
#endif
#ifdef ARISTOS
#undef V6_TARGET
#endif//
	return TRUE;
}
//**********************************************************************
///
/// Write a byte stream to the SPI device currently selected
///
/// @param[in]	pWriteBuffer - ptr to buffer to write to SPI device
/// @param[in]	bytesToWrite - number of bytes to write to the SPI device
/// @return		number of bytes written, 0 if failed to write
///
//**********************************************************************
ULONG CDeviceAbstraction::SPIWriteToDevice(UCHAR *pWriteBuffer, ULONG bytesToWrite, UCHAR slotID) {
	//ULONG bytesWritten = 0;
	ULONG bytesWritten = bytesToWrite;
#ifdef ARISTOS
#define V6_TARGET
#endif//
#ifdef V6_TARGET
    // perform slot id remapping if necessary
    slotID = (UCHAR)PerformSlotIdTranslation(slotID);
    ms_kSPICritSect.lock();
    // Write bytestream to SPI device
    //	if(!WriteFile(m_hSpi, pWriteBuffer, bytesToWrite , &bytesWritten, NULL))
    if (!pfSPIWrite(hCSPI, pWriteBuffer, bytesToWrite, (byte)slotID))
        //
    {
        qDebug("SPI write failed for slot id 0x%X\n",slotID);
        bytesWritten = 0;
    }
    ms_kSPICritSect.unlock();
#endif
#ifdef ARISTOS
#undef V6_TARGET
#endif//
	return bytesWritten;
}
//**********************************************************************
///
/// Read a stream or bytes from an SPI device
///
/// @param[out]	pReadBuffer - ptr to buffer to read data into
/// @param[in]	bufLen - Number of bytes to read if RTC, otherwise 0 for all IO cards
/// @return		number of bytes read, 0 if failed to read
///
//**********************************************************************
ULONG CDeviceAbstraction::SPIReadFromDevice(UCHAR *pReadBuffer, ULONG bufLen, UCHAR slotID) {
	ULONG bytesRead = bufLen;
    QString commandText = "";
#ifdef ARISTOS
#define V6_TARGET
#endif//
#ifdef V6_TARGET
    // perform slot id remapping if necessary
    slotID = (UCHAR)PerformSlotIdTranslation(slotID);
    USHORT usMaxRetriesToRead = 1;
    ms_kSPICritSect.lock();
    DWORD dwRetStatus = FALSE;
    do
    {
        //	if(!ReadFile(m_hSpi, pReadBuffer, bufLen, &bytesRead, NULL))
        dwRetStatus = pfSPIRead(hCSPI, pReadBuffer, &bytesRead, (byte)slotID);
        if( (FALSE == dwRetStatus) || (pReadBuffer[0] == 0 ) )
        {
            commandText = QString::asprintf( "SPI read failed for slot id 0x%X and command =0x%X bytesRead(%d) GTC-%d\n", slotID, pReadBuffer[0], bytesRead, GetTickCount() );
            OutputDebugString(commandText.toLocal8Bit().data());
            if ( (bytesRead != 0) && /*(pReadBuffer[0] != 0 ) && */( (pReadBuffer[0] == pReadBuffer[1]) && (pReadBuffer[0] == pReadBuffer[2]) &&
                                                                     (pReadBuffer[0] == pReadBuffer[3]) && (pReadBuffer[0] == pReadBuffer[4]) && (pReadBuffer[0] == pReadBuffer[5]) ) )
            {
                //Data byte repeating --> Secondary SPI DR register stuck at one byte attempt to read it again and clear DR
                //Ex:"FD FD FD FD FD" - byte repeat sequence and lead TO UNKNOWN LM3S error if process further)
                --usMaxRetriesToRead;
                swprintf( commandText, "SPI read repeated bytes for slot id 0x%X and databyte =0x%X bytesRead(%d) GTC-%d\n", slotID, pReadBuffer[0], bytesRead, GetTickCount() );
                OutputDebugString(commandText.toLocal8Bit().data());
            }
            else
            {
                //Different error than >512 bytes due to Wrong Packet(like "FD FD FD FD FD")
                usMaxRetriesToRead = 0; //no need to read again
            }
            //Incase of FALSE return only makes the bytesRead zero otherwise dont touch..this to keep previous implemetation as-is
            if( FALSE == dwRetStatus )
            {
                bytesRead = 0;
            }
        }
        else
        {
            usMaxRetriesToRead = 0;
        }
    }
    while ( usMaxRetriesToRead > 0 );

    ms_kSPICritSect.unlock();
#endif
#ifdef ARISTOS
#undef V6_TARGET
#endif//
	return bytesRead;
}
//**********************************************************************
///
/// Get digital card status, see if any digital cards have data waiting
///
/// @return		Card status as bit, bit0=Card1, bit1=Card2, Bit2=Card3
///
//**********************************************************************
UCHAR CDeviceAbstraction::SPIGetDigitalCardStatus() {
	UCHAR digitalStatus = 0;
#ifdef ARISTOS
#define V6_TARGET
#endif//
#ifdef V6_TARGET
    DWORD dwOut = 0;
    ULONG ulStatus = 0;
    // Get the status of the Data ready status of the Digital Input boards
    if(!DeviceIoControl(m_hLEDIO, IOCTL_LED_IO_GET_MGPIO, NULL, 0, &ulStatus, sizeof(ulStatus), &dwOut, NULL))
    {
        FatalError(("DAL: Get IOCTL_LED_GET_MGPIO failed in SPIGetDigitalCardStatus\n"));
    }
    if( DEV_ARISTOS_EZTREND == m_deviceType || DEV_XS_EZTREND == m_deviceType )//ARISTOS QXe Device Type updates
    {
        digitalStatus = static_cast<UCHAR> (EZ_DIG_IN_READY(ulStatus));
    }
    else
    {
        digitalStatus = static_cast<UCHAR> (DIG_IN_READY(ulStatus));
        //QString Str;
        //Str = QString::asprintf("ulstatus=%x, digst=%x", ulStatus,digitalStatus );
        //LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR,Str);
    }
#endif
#ifdef ARISTOS
#undef V6_TARGET
#endif//
	return digitalStatus;
}
//**********************************************************************
///
/// Initialise the communications port
/// @param[in] port - COM Port when being used on PC see SCI_PORT_N , ignored on device
///
/// @return  TRUE if successful, FALSE for failure to select
///
//**********************************************************************
BOOL CDeviceAbstraction::IOCardInitialise(USHORT port) {
	BOOL retVal = FALSE;
	m_IOCardSelected = 0;
#ifdef ARISTOS
#define V6_TARGET
#endif//
#ifdef V6_TARGET
    //retVal = SPISetSpeed( SPI_DEVICE_CARD1, SPI_BAUD_RATE_HZ, SPI_INTERCHAR_TIMEOUT );
#else
	if (port != 0 && m_IOCardSCI.Open((T_COMMPORT) port, ATE_BAUD_RATE) == SC_OKAY) {
		retVal = TRUE;
	} else {
		m_IOPortIgnore = TRUE;
	}
#endif
#ifdef ARISTOS
#undef V6_TARGET
#endif//
	retVal = 1;
	return retVal;
}
//**********************************************************************
///
/// Select IO Card
///
/// @param[in] device - Device for selection use SPI_DEVICE_CARD1 to 9
/// @return  TRUE if successful, FALSE for failure to select
///
//**********************************************************************
BOOL CDeviceAbstraction::IOCardSelect(USHORT device) {
	m_IOCardSelected = device;
	BOOL retValue = FALSE;
#ifdef ARISTOS
#define V6_TARGET
#endif//
#ifdef V6_TARGET
    if( DEV_ARISTOS_EZTREND == m_deviceType || DEV_XS_EZTREND == m_deviceType )//ARISTOS QXe Device Type updates
    {
        // perform slot id remapping if necessary
        device = PerformSlotIdTranslation(device);
        switch( device )
        {
        case SPI_DEVICE_CARD1:
        case SPI_DEVICE_CARD2:
        case SPI_DEVICE_CARD3:
            retValue = SPISelectDevice( device );	// Select SPI card for communication
            break;
        default:
            retValue = TRUE;	// No device to select for PC, will be SCI port
        }
    }
    else
    {
        retValue = SPISelectDevice( device );	// Select SPI card for communication
    }
#else
	// Nothing required to be done in PC build
	retValue = TRUE;
#endif
#ifdef ARISTOS
#undef V6_TARGET
#endif//
	return retValue;	// No device to select for PC, will be SCI port
}
//**********************************************************************
/// Output debug info on IO board protocol, QUAD for debug purposes only
///
/// @param[in]  pBuffer - Pointer to the data buffer
/// @param[in]	size - pointer to the buffer size
///	@param[in]	IsAWrite - TRUE if "Write" FALSE if "Read"
/// @return   nothing
///
//**********************************************************************
void CDeviceAbstraction::OutputProtocolToDebug(BYTE *pBuffer, ULONG size, BOOL IsAWrite) {
#ifdef DEBUG						// Only do if debugging
#if SHOW_IO_PROTOCOL_IN_DEBUG		// and only if this is set to 1 at top of this routine
    static CTV6Timer timer(TIMER_HIGH_RES);
    timer.StopTimer();
    ULONG msecSinceLastMessage = (ULONG)timer.GetTimeInMilliSec(TIMER_SINGLE);
    const int PROT_OUT_LIMIT = 20;
    WCHAR commandText [40];
    ULONG byteNum = 0;				// Start at beginning of message
    // It's a command so decipher
    switch( *pBuffer )
    {
    case 0x02: swprintf( commandText, "GetBoardType" ); break;
    case 0x03: swprintf( commandText, "GetBoardId" ); break;
    case 0x04: swprintf( commandText, "GetTimeStamp" ); break;
    case 0x05: swprintf( commandText, "GetLifeHist" ); break;
    case 0x06: swprintf( commandText, "UpdateStats" ); break;
    case 0x07: swprintf( commandText, "GetVersion" ); break;
    case 0x08: swprintf( commandText, "GetIDVer" ); break;
    case 0x09: swprintf( commandText, "GetGUID" ); break;
    case 0x0a: swprintf( commandText, "ReportErrors" ); break;
    case 0x0b: swprintf( commandText, "SetBDTestData" ); break;
    case 0x0c: swprintf( commandText, "GetBDTestData" ); break;
    case 0x0d: swprintf( commandText, "SetGuid" ); break;
    case 0x0e: swprintf( commandText, "SetBoardId" ); break;
    case 0x0f: swprintf( commandText, "SetDiagInterva" ); break;
    case 0x10: swprintf( commandText, "GetTSBase" ); break;
    case 0x11: swprintf( commandText, "SetMainFreq" ); break;
    case 0x12: swprintf( commandText, "ResetBuffTS" ); break;
    case 0x13: swprintf( commandText, "WriteBoardSetup" ); break;
    case 0x14: swprintf( commandText, "ReadBoardSetup" ); break;
    case 0x15: swprintf( commandText, "ReadBoardCaps" ); break;
        // Analogue card
    case 0x30: swprintf( commandText, "ReadAICalRec" ); break;
    case 0x31: swprintf( commandText, "GetCJC" ); break;
    case 0x32: swprintf( commandText, "ReadAnalIn" ); break;
    case 0x33: swprintf( commandText, "ReadAnaBlock" ); break;
    case 0x34: swprintf( commandText, "AckGoodAIBlock" ); break;
    case 0x35: swprintf( commandText, "FactCalib" ); break;
    case 0x36: swprintf( commandText, "UserCalib" ); break;
    case 0x37: swprintf( commandText, "ReadFactCa" ); break;
    case 0x38: swprintf( commandText, "ReadUserCa" ); break;
    case 0x39: swprintf( commandText, "SetRawMode" ); break;
    case 0x3a: swprintf( commandText, "GetRTCa" ); break;
    case 0x3b: swprintf( commandText, "GetRTComp" ); break;
    case 0x3c: swprintf( commandText, "SetRange" ); break;
    case 0x3d: swprintf( commandText, "SetAcqFreq" ); break;
    case 0x3e: swprintf( commandText, "WriteAIChanConfig" ); break;
    case 0x3f: swprintf( commandText, "ReadAiChanConfig" ); break;
    case 0x40: swprintf( commandText, "WriteAIBoardConfig" ); break;
    case 0x41: swprintf( commandText, "ReadAIBoardConfig" ); break;
    case 0x42: swprintf( commandText, "SetActiveBurnout" ); break;
    case 0x43: swprintf( commandText, "GetBurnoutStatus" ); break;
    case 0x44: swprintf( commandText, "CheckBurnoutWiring" ); break;
    case 0x45: swprintf( commandText, "TurnRTCurrentOff" ); break;
        // Digital IO card
    case 0x68: swprintf( commandText, "ReadDigInBlock" ); break;
    case 0x69: swprintf( commandText, "AckGoodDigBlock" ); break;
    case 0x6a: swprintf( commandText, "ReadDigInput" ); break;
    case 0x6b: swprintf( commandText, "WriteDigOutput" ); break;
    case 0x6c: swprintf( commandText, "ReadPulseInBlock" ); break;
    case 0x6d: swprintf( commandText, "WriteDigConfig" ); break;
    case 0x6e: swprintf( commandText, "ReadDigConfig" ); break;
        // Analogue Output
    case 0x80: swprintf( commandText, "WriteAnalOutput" ); break;
    case 0x81: swprintf( commandText, "SetAORawMode" ); break;
    case 0x82: swprintf( commandText, "SetAOCalib" ); break;
    case 0x83: swprintf( commandText, "ReadAOCalib" ); break;
    case 0x84: swprintf( commandText, "WriteAOConfig" ); break;
    case 0x85: swprintf( commandText, "ReadAOConfig" ); break;
    case 0x86: swprintf( commandText, "GetAOStatus" ); break;
    case 0x87: swprintf( commandText, "ReadAOCalRec" ); break;
    default:
        swprintf( commandText, "Unknown command %d ",*pBuffer ); break;
    }
    //	byteNum+=2;
    //	pBuffer+=2;
    // Trace out leader
    qDebug("IOP %s(%d):%s(%d)  = ", IsAWrite ? "Write" : "Read ",m_IOCardSelected,commandText, size );
    // Trace out data characters
    for( /*byteNum already set */; byteNum < size /* && byteNum < PROT_OUT_LIMIT */; byteNum++ )
    {
        qDebug("%02x ",  *pBuffer++ );
    }
    qDebug("(%d msec)", msecSinceLastMessage );
    /// Finish off debug statement
    if( byteNum == PROT_OUT_LIMIT )
    {
        qDebug(" <Limited to %d>\n", PROT_OUT_LIMIT );
    }
    else
    {
        qDebug(" <End>\n" );
    }
    timer.StartTimer();		// Start the timer again.
#endif
#endif
}
//**********************************************************************
/// Read data from the currently selected IO Card
///
/// @param[out] pBuffer - Pointer to the data buffer
/// @param[in,out] pSize - pointer to the maximum buffer size, also used to return the number of bytes read
/// @return       TRUE if successful, FALSE for failure to select or Invalid device number
///
//**********************************************************************
BOOL CDeviceAbstraction::IOCardRead(void *pBuffer, ULONG *pSize, UCHAR slotID) {
	BOOL retVal = FALSE;
	//commented by kranti for qxe recorder up
#ifdef ARISTOS
#define V6_TARGET
#endif//
#ifdef V6_TARGET
    *pSize = SPIReadFromDevice((UCHAR *)pBuffer, *pSize, slotID);
    if( *pSize > 0 )
    {
#ifdef DEBUG						// Only do if debugging
#if SHOW_IO_PROTOCOL_IN_DEBUG		// and only if this is set to 1 at top of this routine
        OutputProtocolToDebug( static_cast<BYTE *>(pBuffer), *pSize, FALSE );
#endif
#endif
        retVal = TRUE;	// Check if any bytes read, if so success
    }
#else
	if (!m_IOPortIgnore) {
		if (m_IOCardSCI.Read(pBuffer, pSize) == SC_OKAY) {
			OutputProtocolToDebug(static_cast<BYTE*>(pBuffer), *pSize, FALSE);
			retVal = TRUE;
		}
	}
#endif
#ifdef ARISTOS
#undef V6_TARGET
#endif//
	return retVal;
}
//**********************************************************************
/// Write data to the currently selected IO Card
///
/// @param[in] pBuffer - Pointer to the data buffer
/// @param[in,out] pSize - number of bytes to write to the SPI device
/// @return       TRUE if successful, FALSE for failure to select or Invalid device number
///
//**********************************************************************
BOOL CDeviceAbstraction::IOCardWrite(void *pBuffer, ULONG *pSize, UCHAR slotID) {
	BOOL retVal = FALSE;
	//the below code is commented out by kranti, to resolve
#ifdef ARISTOS
#define V6_TARGET
#endif//
#ifdef V6_TARGET
    *pSize = SPIWriteToDevice((UCHAR *)pBuffer, *pSize, slotID);
    if( *pSize > 0 )
    {
#ifdef DEBUG						// Only do if debugging
#if SHOW_IO_PROTOCOL_IN_DEBUG		// and only if this is set to 1 at top of this routine
        OutputProtocolToDebug( static_cast<BYTE *>(pBuffer), *pSize, TRUE );
#endif
#endif
        retVal = TRUE;	// Check if any bytes written, if so success
    }
#else
	if (!m_IOPortIgnore) {
		if (m_IOCardSCI.Write(pBuffer, pSize) == SC_OKAY) {
			OutputProtocolToDebug(static_cast<BYTE*>(pBuffer), *pSize, TRUE);
			retVal = TRUE;
		}
	}
#endif
#ifdef ARISTOS
#undef V6_TARGET
#endif//
	return retVal; //modified by kranti
}
//**********************************************************************
/// Perform extended communications operations
///
/// @param[out] T_IOCARD_EXT_OPERATION - Extended operation to perform
/// @return   TRUE if successful, FALSE for failure
///
//**********************************************************************
BOOL CDeviceAbstraction::IOCardExtendedOperation(T_IOCARD_EXT_OPERATION extOp) {
	BOOL retVal = FALSE;
	switch (extOp) {
	/// Clear the comms buffer on a serial port
	case IOCARD_EXT_OP_CLEARBUFFER:
#ifdef EMULATOR
		retVal = m_IOCardSCI.ClearAllBuffers();
#endif
		break;
		/// Get the stats from an AP8
	case IOCARD_EXT_OP_GET_AP8_STATS:
#ifdef V6_TARGET
    {
        // Select to read the stats
        if( IOCardSelect( SPI_DEVICE_AP8_INFO ) == TRUE )
        {
            // Read the stats in
            DWORD maxLen = AP8_STATS_LEN;
            IOCardRead(m_AP8Stats, &maxLen);
            if( m_AP8Stats[AP8_STATS_SIG_LO] == AP8_SIG_LO && m_AP8Stats[AP8_STATS_SIG_HI] == AP8_SIG_HI )
                retVal = TRUE;
        }
    }
#endif
		break;
	default:
		FatalError(("DAL: IOCardExtendedOperation unknown operation(%d) \r\n"), extOp);
		break;
	}
	return retVal;
}
//**********************************************************************
///
/// Set the state of the power relay
///
/// @param[in]	state - TRUE to close relay, FALSE to open
/// @return		TRUE if device call success, FALSE if failed
///
//**********************************************************************
BOOL CDeviceAbstraction::IOSetPowerRelay(BOOL state) {
	BOOL bReturn = TRUE;
	// PSR Fix for - 1-3E7Y0UX - SX/QX_"Common alarm" output configuration is missing from soft (pens) alarm begin
	//Define V6_TARGET to enable this function. This is the approach followed for other functions in this class
#ifdef ARISTOS
#define V6_TARGET
#endif
	// PSR Fix for - 1-3E7Y0UX - SX/QX_"Common alarm" output configuration is missing from soft (pens) alarm end
#ifdef V6_TARGET
    // Note, the following code used was supplied by IEL, inputBuffer usage poor but no information
    // available to indicate why 8 bytes is required. To be safe leave as it maybe used in OS level.
    // PSR Fix for - 1-3E7Y0UX - SX/QX_"Common alarm" output configuration is missing from soft (pens) alarm begin
    if(state == TRUE)
    {
        state = FIXED_RELAY_OPEN;	// Open Relay
    }
    else
    {
        state = FIXED_RELAY_CLOSE;	// Close relay
    }
    BYTE dwBoardStatus = FALSE;
    if ( NULL != pfInterfaceOpen && NULL != pfGetPowerRelayIOPinStatus && NULL != pfTogglePowerRelayIOPin)
    {
        //The below checks are required because we have the API to toggle the status not to set the required state directly
        //So it it our responsibility to call the toggle or not
        //So first get the status fron the board through API then compare it with the requested state
        //Board Status #0 means LOW (OPEN Relay) and #1 means HIGH (CLOSED Relay)
        if ( pfGetPowerRelayIOPinStatus(m_hInterfaceHandle, &dwBoardStatus ) )
        {
            //Check the state to toggle or not
            if (  state != dwBoardStatus )
            {
                //Toggle the board status to OPEN the relay
                bReturn = pfTogglePowerRelayIOPin(m_hInterfaceHandle);
            }
        }
        else
        {
            bReturn = FALSE;
        }
    }
    else
    {
        bReturn = FALSE;
    }
#else
	if (state)
		qDebug(("DAL : Close Power relay \n"));
	else
		qDebug(("DAL : Open Power Relay \n"));
#endif
	// PSR Fix for - 1-3E7Y0UX - SX/QX_"Common alarm" output configuration is missing from soft (pens) alarm begin
	//Define V6_TARGET to enable this function. This is the approach followed for other functions in this class
#ifdef ARISTOS
#undef V6_TARGET
#endif//
	// PSR Fix for - 1-3E7Y0UX - SX/QX_"Common alarm" output configuration is missing from soft (pens) alarm end
	return (bReturn);
}
//=====================================================================================
// SRAM Routines
//=====================================================================================
const ULONG SRAM_TARGET_PHYS_1_2 = 0x0C300000;		///< Physical start address of SRAM REV A and B boards
const ULONG SRAM_TARGET_PHYS_3 = 0x0C400000;		///< Physical start address of SRA REV C onwards
const ULONG SRAM_REV_1_2 = 256 * 1024;			///< Rev A and B SRAM 256K
//const ULONG SRAM_REV_3				= 512*1024;			///< Rev C and above 512K (with expansion for extra 512K )
//Modified the code by Usha ( Kranthi please check while doing a firmware build)
#ifndef XSERIESSETUP
const ULONG SRAM_REV_3 = 1024 * 1024;///< Rev C and above 512K (with expansion for extra 512K )//changed by kranti to address 1mb instead of 512 kb
#else
const ULONG SRAM_REV_3     = 512*1024;
#endif
//const ULONG SRAM_REV_3					= 2*512*1024;			///< Rev C and above 512K (with expansion for extra 512K )
const ULONG SRAM_GLOBAL_SIGNATURE = 0x91268934;		///< Global SRAM signature, if changed will invalidate all of SRAM
//**********************************************************************
///
/// Initialise SRAM
///
/// @return		TRUE if SRAM initialise successfully, otherwise FALSE
///
//**********************************************************************
BOOL CDeviceAbstraction::InitialiseSRAM() {
#if 1
	BOOL retVal = TRUE;
	m_simulateSRAM = TRUE;
#ifdef ARISTOS
    // If on target and proc board is REV3 onwards, or it's an EzTrend
    //if( GetBoardRevision() >= PROCBRD_REV_3 || m_deviceType == DEV_EZTREND)
    m_simulateSRAM = FALSE;
#endif
	if (m_simulateSRAM) {
		// SRAM peristance is simulated by storing it to a file on local storage
		// A Block of memory SRAM sized is allocated and then the saved SRAM loaded into this Block
		// the memory copy used during the application run, at regular intervals or when the system is shutdown the
		// SRAM memory Block will be saved back to disk,
		// Allocate Block to mimic SRAM
		m_pSRAMBase = new CHAR[m_SRAMLength + 256];
		// Load saved SRAM if exists to simulate persistance
		SimulatedSRAMAccess( BF_READ);
	} else {
		// Don't simulate SRAM, map it in directly, but only on target
		//#ifdef V6_TARGET
		//PHYSICAL_ADDRESS sramAddr;
		//sramAddr.QuadPart = SRAM_TARGET_PHYS_3;
		// Map in the SRAM memory
		// ** Note if you link is failing here, you must add ceddk.lib to your
		// project->setting->link->general-> "Object/library modules", for MIPSII debug AND MISPII release (not emulator)
		//m_pSRAMBase = (char *)MmMapIoSpace( sramAddr, m_SRAMLength, FALSE );
		//SRAMClose pfSRAMClose;
		//SRAMGetPointer pfGetPointer;
		//SRAMFreePointer pfFreePointer;
#ifdef ARISTOS
  /// TOOD: Code to initialise SRAM
#endif
	}
	/// Cechk if SRAM  has failed to be allocated
	if (m_pSRAMBase == NULL) {
		retVal = FALSE;
		FatalError(("DAL: SRAM failed to be allocated\n"));
	} else {
		// SRAM configured, save out a backup of the SRAM Block, this will provide us snapshot of the SRAM for debug
		BackupSRAMToDiskCopy();
		// SRAM Base available, so set pointer into first 4 bytes and check for the signature
		// if the signature does not exist cleardown SRAM and alert via messagebox that SRAM has been cleared.
#if (!defined IS_BOOTLACE_APP) && (!defined  TTR6SETUP) && (defined  UNDER_CE)
        CBatteryManager* pBatMan = CBatteryManager::GetHandle();
        if( pBatMan != NULL )
        {
            pBatMan->CheckAndPerformBatteryReset();
        }
        ULONG *pSRAMSignature = reinterpret_cast<ULONG *>(m_pSRAMBase);
        if( *pSRAMSignature != SRAM_GLOBAL_SIGNATURE )
        {
            memset( m_pSRAMBase, 0, m_SRAMLength );		// Clear down all of SRAM
            *pSRAMSignature = SRAM_GLOBAL_SIGNATURE;	// Assign global signature
            SimulatedSRAMAccess(BF_WRITE);				// Write SRAM if simulated
            // Throw up message box, used initially in testing @todo AK remove
#ifdef ARISTOS
            // meesage for information...
            //MessageBox(NULL, "SRAM was cleared \n for first time usage" , "SRAM RESET", MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST );
#endif
        }
#endif //#ifndef IS_BOOTLACE_APP
	}
#endif
	return 1;
	//return retVal;
}
//**********************************************************************
///
/// Make a backup copy of the SRAM, this allows any issues to be examined if
/// integrity check fails or recorder crashes
///
/// @return		nothing
///
//**********************************************************************
void CDeviceAbstraction::BackupSRAMToDiskCopy(UCHAR ucBlockNumber) {
	// SRAM configured, save out a backup of the SRAM Block, this will provide us snapshot of the SRAM for debug
	ReadWriteNV( BF_WRITE, m_SRAMLength, (LPWORD) m_pSRAMBase, ucBlockNumber, m_SRAMLength);
}
//**********************************************************************
///
/// Restore SRAM, this allows smooth battery replacement for tge
///  GR series recorder
///
/// @return		nothing
///
//**********************************************************************
BOOL CDeviceAbstraction::RestoreSRAMFromDiskCopy() {
	return ReadWriteNV( BF_READ, m_SRAMLength, (LPWORD) m_pSRAMBase, BF_BLK_SRAM_BKP_ON_BAT_RESET, m_SRAMLength);
}
//**********************************************************************
///
/// Safe Write to SRAM, no direct memory access
///
/// @param[in]	offset - in bytes into SRAM Block
/// @param[in]	length - in bytes of data to write
/// @param[in]	pBuffer - pointer to buffer of data to Write to SRAM
/// @return		FALSE if any checks fail, other TRUE write to SRAM okay
///
//**********************************************************************
//BOOL CDeviceAbstraction::SafeWriteToSRAM( long offset, long length, short *pBuffer )
BOOL CDeviceAbstraction::SafeWriteToSRAM(long offset, long length, unsigned char *pBuffer) {
	if (offset + length > m_SRAMLength || pBuffer == NULL || m_pSRAMBase == NULL)
		return FALSE;
	else {
		//short *pDest = (short *)(m_pSRAMBase+offset);
		char *pDest = (char*) (m_pSRAMBase + offset);
		//for( long i=0; i < (length/2); i++ )
		//*pDest++ = *pBuffer++;
		*pDest = *pBuffer;
	}
	return TRUE;
}
//**********************************************************************
///
/// Safe read from SRAM, no direct memory access
///
/// @param[in]	offset - in bytes into SRAM Block
/// @param[in]	length - in bytes of data to read
/// @param[out]	pBuffer - pointer to buffer of to read into from SRAM
/// @return		FALSE if any checks fail, other TRUE read from SRAM okay
///
//**********************************************************************
//BOOL CDeviceAbstraction::SafeReadFromSRAM( long offset, long length, short *pBuffer )
BOOL CDeviceAbstraction::SafeReadFromSRAM(long offset, long length, unsigned char *pBuffer) {
	if (offset + length > m_SRAMLength || pBuffer == NULL || m_pSRAMBase == NULL)
		return FALSE;
	else {
		//short *pSource = (short *)(m_pSRAMBase+offset);
		char *pSource = (char*) (m_pSRAMBase + offset);
		//for( long i=0; i < (length/2); i++ )
		//{
		//*pBuffer++ = *pSource++;
		//}
		*pBuffer = *pSource;
	}
	return TRUE;
}
//**********************************************************************
///
/// Get pointer to Area in SRAM by offset
///
/// @param[in]	offset - in bytes into SRAM of required address
/// @return		ptr to area of SRAM, if NULL one ofthe checks has failed
///
//**********************************************************************
CHAR* CDeviceAbstraction::GetPtrIntoSRAM(long offset) {
	CHAR *address = NULL;
	if ((offset & 0x01) == 1)
		FatalError(("DAL: SRAM ERROR cannot access odd addresses\n"));
	else if (offset >= m_SRAMLength)
		FatalError(("DAL: SRAM ERROR offset beyond end of SRAM\n"));
	else
		address = m_pSRAMBase + offset;
	return address;
}
//**********************************************************************************
/// Perform a Load or Save to/from simulated SRAM
///
/// @param[in]	write - set to TRUE to write Block,  set to false to read Block(use BF_READ and BF_WRITE)
/// @return		TRUE if successful, FALSE if any initialisation fails
///
//**********************************************************************************
BOOL CDeviceAbstraction::SimulatedSRAMAccess(BOOL write) {
	if (m_simulateSRAM)
		return ReadWriteNV(write, m_SRAMLength, (LPWORD) m_pSRAMBase, BF_BLK_SRAM, m_SRAMLength);
	else
		return TRUE;
}
//**********************************************************************************
/// Emulate read and write to SRAM and FLASH using disk Blocks, this will be used for PC and emulator
/// also for Rev A and B boards with 256K of SRAM which was mapped per byte.
///
/// @param[in]		write - set to TRUE to write Block,  set to false to read Block(use BF_READ and BF_WRITE)
/// @param[in]		sizeReq - size of the SRAM Block
/// @param[in,out]	pBuffer - ptr to buffer, data to write or buffer to read
///	@param[in]		BlockNumber - NV Block number, see BF_BLK_ in hw_defs.h
///	@param[in]		defSize - default size in bytes of NV Block, 64K for flash and 512K for SRAM
/// @return		TRUE if successful, FALSE if any initialisation fails
///
//**********************************************************************************
BOOL CDeviceAbstraction::ReadWriteNV(BOOL write, long sizeReq, WORD *pBuffer, UCHAR BlockNumber, ULONG defSize,
		BOOL bNoEmptyNV) {
	BOOL bRet = TRUE;
	QString pRootVol;
	QString fileName;
	pRootVol = GetVolumeName(SD_INTERNAL_SD, NULL, 0);
	// Build filename and path for flash Blocks, the size of the NV is built into
	// the filename, this will allow testing with different sizes without conflict.
    fileName = QString::asprintf(("%sNV%04d.BIN"), pRootVol.toLocal8Bit().data(), BlockNumber);
    CStorage file;
	// Try to open the file for read/write access
    if (!file.Open(fileName.toLocal8Bit().data(), QFile::ReadWrite)) {
		// File failed to so may not exist, try to create
        if (!file.Open(fileName.toLocal8Bit().data(), QFile::Append | QFile::ReadWrite)) {
			return FALSE;
		}
		// File created, generate emtpy NV Block on Disk.
		char *pDefaultBlk = (char*) malloc(defSize + 1);	// Allocated a default Block
		if (pDefaultBlk == NULL) {
			FatalError(("DAL: NV Malloc for default Block failed"));
			file.close();
			return FALSE;
		}
		memset(pDefaultBlk, 0, defSize);			// Set defaut Block to 0
#if _MSC_VER < 1400
		sprintf(pDefaultBlk, "Empty NV file");		// Set identifier in Block for debug purposes
#else
        sprintf_s(pDefaultBlk, defSize+1, "Empty NV file");		// Set identifier in Block for debug purposes
#endif
		file.write(pDefaultBlk, defSize);
		free(pDefaultBlk);
		if ( TRUE == bNoEmptyNV) {
			//Do not treat Empty NV file as SUCCESS scenario
			bRet = FALSE;
		}
	}
	file.seek(0);	// Make sure file is at the beginning
	// Read or write flash info to the sram Block
	if (write) {	// Write to NV Block
        file.Write(pBuffer, sizeReq);
	} else {	// Read from NV Block
		file.Read(pBuffer, sizeReq);
	}
	file.close();
	return bRet;
}
//**********************************************************************
///
/// Query the status whether the power relay is fitted or not
///
/// @return		TRUE if the power relay is fitted; otherwise FALSE
///
//**********************************************************************
BOOL CDeviceAbstraction::IsPowerRelayFitted() {
	BOOL retValue = TRUE;		// Power relay always fitted, in mini/multi
	if (IsRecorderEzTrend() == TRUE)
		retValue = FALSE;		// Power relay not present in eZtrend
	return retValue;
}
//**********************************************************************
///
/// Query the status whether the mother board is fitted or not
///
/// @return		TRUE if the mother board is fitted; otherwise FALSE
///
//**********************************************************************
BOOL CDeviceAbstraction::IsMotherBoardFitted() {
	BOOL motherBdStatus = TRUE;		// Power relay always fitted, in mini/multi
	//Swathi - Fix for the par 1-3DXWHML
#ifdef ARISTOS
#define V6_TARGET
#endif
#ifdef V6_TARGET
    if( IsRecorderEzTrend() == TRUE )
    {
        //PSR Fix for - 1-3DXWHML - QXe_General Status shows Expansion Board and Comms Board as connected though Support is removed begin
        //This is new API added to InterfaceSDK.dll to get the status of the Backplane (Expansion) card. This is mostly for Ez recorder
        //Because the Sx/QX always have the card fitted. For Ez alone this card is optional .
        //Leaving the default status to TRUE (board fitted) for compatibility with SX/QX and previous code.
        if( NULL != m_hInterfaceHandle && NULL != pfGetBackPlaneBoardStatus )
        {
            BYTE byStatus = 0;
            if ( TRUE == pfGetBackPlaneBoardStatus(m_hInterfaceHandle, &byStatus) )
            {
                if ( 0 == byStatus )
                { motherBdStatus = TRUE; }
                else
                { motherBdStatus = FALSE; }
            }
        }		//The above call will succeed for GR EZTrend only, It will fail for other Recorder types. It returns TRUE.
    }
#endif
	//Swathi - Fix for the par 1-3DXWHML
#ifdef ARISTOS
#undef V6_TARGET
#endif
	return motherBdStatus;
}
//**********************************************************************
///
/// Query the status whether the comms board is fitted or not (RS485 & rear USB)
///
/// @return		TRUE if the comms board is fitted; otherwise FALSE
///
//**********************************************************************
BOOL CDeviceAbstraction::IsCommsBoardFitted() {
	BOOL commsBdStatus = TRUE;		// Power relay always fitted, in mini/multi
	//Swathi - Fix for the par 1-3DXTAVT
	//Comms board support removed in GR EZTrend Recorder.
	//Hence, returning false for GR EZTrend Recorder
	if (IsRecorderEzTrend() == TRUE)
		commsBdStatus = FALSE;
#ifdef V6_TARGET
    DWORD dwOut = 0;
    ULONG ulStatus;
    USHORT bitField = 0;
    if( IsRecorderEzTrend() == TRUE )
    {
        // Get the status of the Data ready status of the Digital Input boards
        if(!DeviceIoControl(m_hLEDIO, IOCTL_LED_IO_GET_MGPIO, NULL, 0, &ulStatus, sizeof(ulStatus), &dwOut, NULL))
        {
            FatalError(("DAL: Get IOCTL_LED_GET_MGPIO failed in SPIGetDigitalCardStatus\n"));
        }
        bitField = COMMSBD_FITTED(ulStatus);
        bitField ^= 1;									///< Active low, so invert
        commsBdStatus = static_cast<BOOL>  (bitField );
    }
#endif
	return commsBdStatus;
}
//**********************************************************************
///
/// Query the status whether the front compact flash hardware is fitted or not
///
/// @return		TRUE if the front SD socket is fitted; otherwise FALSE
///
//**********************************************************************
BOOL CDeviceAbstraction::IsFrontCFSlotAvailable() {
	BOOL retValue = TRUE;		// Front SD always fitted, in mini/multi but restricted by credits on an Ez, ignore
	// the credits for bootlace though
#ifndef IS_BOOTLACE_APP
	if (IsRecorderEzTrend() && (pGlbSysInfo && !pGlbSysInfo->FWOptionExtSDAvailable())) {
		retValue = FALSE;		// Front SD not permitted due to credits on this eZtrend
	}
#endif
	return retValue;
}
//**********************************************************************
///
/// Get volume name for storage device
///
/// @param[in]	id - storage device identifier of type storageDeviceIdent in hw_defs.h
/// @param[out]	pVolume - ptr to store volume information in, if NULL a pointer will be returned to const information
/// @return		ptr to const volume path for storeage device id, NULL if invalid id
///
//**********************************************************************
QString CDeviceAbstraction::GetVolumeName(storageDeviceIdent id, QString *pVolume, int pbufferSizeInWchar) {
	QString pVolumeConst = NULL;
#ifdef ARISTOS
#define V6_TARGET
#endif//
#ifdef V6_TARGET
    switch(id)
    {
    case SD_INTERNAL_SD:
        pVolumeConst = V6internalSD;
        break;
    case SD_EXTERNAL_SD:
        pVolumeConst = V6externalSD;
        break;
    case SD_USB1:
        pVolumeConst = V6usbkey1;
        break;
    case SD_USB2:
        pVolumeConst = V6usbkey2;
        break;
    case ROOT:
        pVolumeConst = V6ROOT;
        break;
    default:
        FatalError("DAL: Unknown storage id %d\n", id);
        break;
    }
#else
	pVolumeConst = m_emul.GetVolumeName(id, NULL, 0);
#endif
#ifdef ARISTOS
#undef V6_TARGET
#endif
	// If the passed in volume pointer is not null, then copy the volume path in
	if (pVolume != NULL && pVolumeConst != NULL) {
#if _MSC_VER < 1400
        *pVolume= pVolumeConst;
#else
        _tcscpy_s( pVolume,pbufferSizeInWchar, pVolumeConst );
#endif
	}
	return pVolumeConst;
}
//**********************************************************************
///
/// Read/Write the IEL parameter Block information from boot flash
///
/// @param[out,in]	*pParamBlk - ptr to IEL defined structure, see DAL.H
/// @param[in]		flashAction - BF_READ to read Block BF_WRITE to write
/// @return			TRUE if r/w okay, FALSE if failed
///
//**********************************************************************
BOOL CDeviceAbstraction::RWIELParameterBlock(PTVIEWV6_IEL_PARAMS pParamBlk, BOOL flashAction) {
#ifdef ARISTOS
#define V6_TARGET
#endif
	BOOL retVal = TRUE;
#ifdef V6_TARGET
    // If we are writing, always make sure validation signature has been set
    if( flashAction == BF_WRITE )
        /// TODO
        pParamBlk->Signature = TVIEWV6_SIGNATURE;
    retVal = RWBootFlashBlock( flashAction , BF_BLK_IELPARAM , sizeof(TVIEWV6_IEL_PARAMS) , (BYTE *)pParamBlk );
#else
	if (flashAction == BF_READ)
		memset(pParamBlk, 0, sizeof(TVIEWV6_IEL_PARAMS));
#endif
#ifdef ARISTOS
#undef V6_TARGET
#endif
	return retVal;
}
//*****************************************************************************************
///
/// Sets the bootloader mode to attempt an ethernet boot or boot directly from internal SD
///
/// @param[in]	EtherBoot - Set Boot from ethewrnet(0) or Direct from SD(1)
///
/// @return			TRUE if r/w okay, FALSE if failed
///
//*****************************************************************************************
BOOL CDeviceAbstraction::SetBootTypeType(USHORT BootType) {
	BOOL retVal = TRUE;
#ifdef V6_TARGET
    TVIEWV6_IEL_PARAMS paramBlk;
    RWIELParameterBlock( &paramBlk, BF_READ );		// Read in the parameter Block
    // Set the direction of the USB port HOST or DEVICE
    paramBlk.DLSource = BootType;
    retVal = RWIELParameterBlock( &paramBlk, BF_WRITE );
#endif
	return retVal;
}
//*****************************************************************************************
///
/// Sets the Front USB port to the HOST or DEVICE connector
///
/// @param[in]	USBConfiguration - Set connector on front to HOST(USB_FRONT_HOST=0) or DEVICE(USB_FRONT_DEVICE=1)
///
/// @return			TRUE if r/w okay, FALSE if failed
///
//*****************************************************************************************
BOOL CDeviceAbstraction::SetFrontUSBType(USHORT USBConfiguration) {
	BOOL retVal = TRUE;
#ifdef V6_TARGET
    TVIEWV6_IEL_PARAMS paramBlk;
    RWIELParameterBlock( &paramBlk, BF_READ );		// Read in the parameter Block
    // Set the direction of the USB port HOST or DEVICE
    paramBlk.USBConfig = USBConfiguration;
    retVal = RWIELParameterBlock( &paramBlk, BF_WRITE );
#endif
	return retVal;
}
//*****************************************************************************************
///
/// Set MAC Address, will preserve first 3 octets as these are 00-DE-6E
/// which are the
///
/// @param[in]	Octet4 - MAC address octet 4
/// @param[in]	Octet5 - MAC address octet 5
/// @param[in]	Octet6 - MAC address octet 6
///
/// @return			TRUE if r/w okay, FALSE if failed
///
//*****************************************************************************************
BOOL CDeviceAbstraction::SetMACAddress(UCHAR Octet4, UCHAR Octet5, UCHAR Octet6) {
#ifdef ARISTOS
#define V6_TARGET
#endif
	BOOL retVal = TRUE;
#ifdef V6_TARGET
    TVIEWV6_IEL_PARAMS paramBlk;
    RWIELParameterBlock( &paramBlk, BF_READ );		// Read in the parameter Block
    // First three octets are the trendview allocated range from IEEE NEVER CHANGE
    paramBlk.MacAddress[0] = TRENDVIEW_MAC_OCTET1;
    paramBlk.MacAddress[1] = TRENDVIEW_MAC_OCTET2;
    paramBlk.MacAddress[2] = TRENDVIEW_MAC_OCTET3;
    // Definable MAC addresses
    paramBlk.MacAddress[3] = Octet4;
    paramBlk.MacAddress[4] = Octet5;
    paramBlk.MacAddress[5] = Octet6;
    paramBlk.DLSource = BOOT_FROM_SD;
    retVal = RWIELParameterBlock( &paramBlk, BF_WRITE );
#endif
#ifdef ARISTOS
#undef V6_TARGET
#endif
	return retVal;
}
//**********************************************************************
///
/// Set's turnaround time on 485 port
///
/// @param[in]	turnAroundInms	- line turnaround in ms
/// @param[in]	p485Handle		- ptr to 485 handle opened by user
/// @return		TRUE if successful, otherwise FALSE
///
//**********************************************************************
BOOL CDeviceAbstraction::RS458SetTurnaround(DWORD turnAroundInms, HANDLE *p485Handle) {
	BOOL retVal = TRUE;
#ifdef V6_TARGET
    retVal = DeviceIoControl(*p485Handle, IOCTL_SERIAL_TVIEW_SET_TX_TURNAROUND_TIME, &turnAroundInms, sizeof(DWORD), NULL, 0, NULL, NULL);
#endif
	return retVal;
}
#define VER_CAP			100				///< For pre version numbered units, cap at 99 for each version number.
//**********************************************************************
///
/// Get the version of Bootloader or BSP (Board support pack and NK.BIN feature build)
///
/// @param[in]	type - type of version information required
///							VER_BSP for Board support and NK.BIN feature build
///							VER_BOOTLOADER for Bootloader version
/// @param[out]	pMajor - ptr to Major version number (0 if emulation or failure)
/// @param[out]	pMinor - ptr to Minor version number (0 if emulation or failure)
///
/// @return		nothing
///
//**********************************************************************
void CDeviceAbstraction::GetVersionInformation(T_VERSION_TYPE type, USHORT *pMajor, USHORT *pMinor) {
	*pMajor = *pMinor = 0;	// Clear down verison numbers
#ifdef V6_TARGET
    // Determin Bootloader and BSP versions
    VERSION_INFO vi;
    DWORD KIORet;
    if( KernelIoControl(IOCTL_TRENDVIEW_VERSION , &vi, sizeof(VERSION_INFO), &vi, sizeof(VERSION_INFO), &KIORet) )
    {
        if( type == VER_BOOTLOADER )
        {
            // Set Bootloader version if valid
            if(  vi.BootVerMSB < VER_CAP && vi.BootVerLSB < VER_CAP && vi.BootVerLSBL < VER_CAP )
            {
                // Valid boot version
                *pMajor = vi.BootVerMSB;
                *pMinor = vi.BootVerLSBL;
            }
            else
            {
                // Invalid boot version, must be pre 1.4 which is the first version that Boot version numbers were available
                *pMajor = 1;
                *pMinor = 3;
            }
        }
        if( type == VER_BSP )
        {
            // Set BSP version if Valid
            if(  vi.OSVerMSB < VER_CAP && vi.OSVerLSB < VER_CAP && vi.OSVerLSBL < VER_CAP )
            {
                // Valid BSP version
                *pMajor = vi.OSVerMSB;
                *pMinor = vi.OSVerLSBL;
            }
            else
            {
                // Invalid BSP version, must be pre 1.4 which is the first version that BSP version numbers were available
                *pMajor = 1;
                *pMinor = 3;
            }
        }
    }
#endif
}
//**********************************************************************
///
/// Get the board variant details
///
//**********************************************************************
void CDeviceAbstraction::DetermineRecorderVariant() {
#ifdef ARISTOS
    char temp;
    BYTE byteBoardType = 0;
    //This dll is needed much before to detectc the recorder variant. So moved here.
    //Initialise the  SPI NOR

    m_hInterfaceHandle = pfInterfaceOpen();

    if (DeviceIoControl(m_hLEDIO,		// file handle to the driver
                        IOCTL_BOARD_DETECTION_STATUS, // I/O control code
                        &temp,							// in buffer
                        sizeof(temp),					// in buffer size
                        &byteBoardType,       // out buffer
                        sizeof(byteBoardType),    // out buffer size
                        NULL,							// pointer to number of bytes returned
                        NULL))							// ignored (=NULL)
    {
        if(byteBoardType & (1<<7))  //Compare the upper nibble from CPLD value to detect the variant
        {
            //MSB is 1 for Multi/Mini/DRG2
            BYTE byteDispType = 0;
            if (DeviceIoControl(m_hLEDIO,			// file handle to the driver
                                IOCTL_LCD_DETECTION_STATUS,   // I/O control code
                                &temp,							// in buffer
                                sizeof(temp),					// in buffer size
                                &byteDispType,      // out buffer
                                sizeof(byteDispType),     // out buffer size
                                NULL,							// pointer to number of bytes returned
                                NULL))
            {
                //This flag should be 1 for Multi, Mini and DRG2 Recorder. 0 for EZ Trend recorder
                //As of now, no decision is made for DRG1.This should be properly set for DRG1
                m_SPIProcFW = 1;
                //Check the Display Bits.For Minitrend DISP0 = 1, DISP1 = 0
                if ( (byteDispType>>1) == 0x2)
                {
                    //MiniTrend
                    m_screenType = SCRN_5_5;
                    m_deviceType = DEV_ARISTOS_MINITREND;
                }
                //Check the Display Bits.For MultiTrend DISP0 = 0, DISP1 = 1
                else if ((byteDispType>>1) == 0x1 )
                {
                    //MultiTrend
                    m_screenType = SCRN_12_1;
                    m_deviceType = DEV_ARISTOS_MULTIPLUS;
                }
                //Check the Display Bits.For DRG2 DISP0 = 1, DISP1 = 1
                else if((byteDispType>>1) == 0x3)
                {
                    //DRG2 (12.1" Display)
                    m_screenType = SCRN_12_1;
                    m_deviceType = DEV_SCR_MINITREND;
                }
            }
        }
        else
        {
            //MSB is 0 for EZTrend and DRG1
            BYTE byteDispType = 0;
            BYTE bStatus = 1;
            bool ret = DeviceIoControl(m_hLEDIO, IOCTL_LCD_DETECTION_STATUS, &temp, sizeof(temp),
                                       &byteDispType, sizeof(byteDispType), NULL,NULL);
            pfSCRDisplayDetectionStatus = (SCRDisplayDetectionStatus)GetProcAddress(m_hInstInterfaceSDK, "SCRDisplayDetectionStatus");
            if(pfSCRDisplayDetectionStatus != NULL)
            {
                pfSCRDisplayDetectionStatus(m_hInterfaceHandle, &bStatus);
            }
            //If Disp0 and Disp1 bit is 1 or Jumper is placed then this is DRG1 recorder
            if(((byteDispType>>1) == 0x3) || bStatus == 0)
            {
                //DRG1 (10.4" Display)
                //Commented for Time being.This will be enables once hardware is ready for testing
                /*m_screenType = SCRN_10_4;
      m_deviceType = DEV_SCR_EZTREND;*/
            }
            else
            {
                //eZTrend
                m_screenType = SCRN_5_7;
                m_deviceType = DEV_ARISTOS_EZTREND;
                m_SPIProcFW = 0;
            }
        }
    }
#endif
}
//**********************************************************************
///
/// Get board details Board(CPLD, PCB Rev, Build Rev, speed etc..)
///
/// @return		Nothing
///
//**********************************************************************
void CDeviceAbstraction::GetBoardDetails() {
	m_SRAMLength = SRAM_REV_3;				// mimic REV3 SRAM size
#ifdef ARISTOS
    //#endif
    //
    //#ifdef V6_TARGET
    //
    //	DWORD dwOut = 0, dwIn = 0;
    //	ULONG ulStatus;
    //
    //	// Get System status register from CPLD 0x00
    //	if(!DeviceIoControl(m_hLEDIO, IOCTL_LED_MISC_GET_SYSTEM_REVISION, NULL, 0, &m_clpdStatus, sizeof(m_clpdStatus), &dwOut, NULL))
    //	{
    //		FatalError(("DAL: Get IOCTL_LED_MISC_GET_SYSTEM_REVISION failed \n"));
    //	}
    //
    //		// Get status of the front USB port setting
    //	if(!DeviceIoControl(m_hLEDIO, IOCTL_LED_MISC_GET_USB, NULL, 0, &ulStatus, sizeof(ulStatus), &dwOut, NULL))
    //	{
    //		FatalError(("DAL: Get IOCTL_LED_MISC_GET_USB failed \n"));
    //	}
    //	else
    //	{
    //		// Is the front USB set as "Device" or "Host" connector
    //		if( (ulStatus & 0x01) == USB_FRONT_DEVICE )
    //			m_frontUSBSet = USB_FRONT_DEVICE;
    //		else
    //			m_frontUSBSet = USB_FRONT_HOST;
    //	}
    //
    //	// Get the type of screen attached
    //	if(!DeviceIoControl(m_hLEDIO, IOCTL_LED_IO_GET_MGPIO, NULL, 0, &ulStatus, sizeof(ulStatus), &dwOut, NULL))
    //	{
    //		FatalError(("DAL: Get IOCTL_LED_GET_MGPIO failed in GetBoardDetails\n"));
    //	}
    //	else
    //	{
    //		// Test DISP0 and DISP1 lines on CPLD register 0-10 to determine screen type
    //		// 5.5" Minitrend =		Disp0=0 Disp1=1
    //		// 12.1" Multitrend =	Disp0=1 Disp1=0
    //		// 5" EzTrend =			Disp0=0 Disp1=0
    //		//
    //
    //
    //		if( SCRN_DISP0(ulStatus) == 0 )
    //		{
    //			m_screenType = SCRN_5_5;
    //			m_screenBright.Top = SCRN_5_5_TOP;
    //			m_screenBright.Bottom = SCRN_5_5_BOTTOM;
    //			m_deviceType = DEV_ARISTOS_MINITREND;
    //		}
    //		else if( SCRN_DISP1(ulStatus) == 0 )
    //		{
    //			m_screenType = SCRN_12_1;
    //			m_screenBright.Top = SCRN_12_1_TOP;
    //			m_screenBright.Bottom = SCRN_12_1_BOTTOM;
    //			m_deviceType = DEV_ARISTOS_MULTIPLUS;
    //		}
    //		else
    //		{
    //			m_screenType = SCRN_5;
    //			m_screenBright.Top = SCRN_5_TOP;
    //			m_screenBright.Bottom = SCRN_5_BOTTOM;
    //			m_deviceType = DEV_EZTREND;
    //		}
    //
    //		// Conversion factor to help convert from %age to native units
    //		m_screenBright.ConvFac = (m_screenBright.Top - m_screenBright.Bottom) / SCRN_BRIGHTNESS_RANGE;
    //	}
    //
    //	m_SPIProcFW = 0;						// No SPI processor fitted to pre-rev 3 boards.
    //	if(GetBoardRevision() >= PROCBRD_REV_3 && m_deviceType != DEV_EZTREND)
    //	{
    //		if( IOCardExtendedOperation(IOCARD_EXT_OP_GET_AP8_STATS) )
    //			m_SPIProcFW = m_AP8Stats[AP8_STATS_VER_LO]+(m_AP8Stats[AP8_STATS_VER_HI] << 8);
    //	}
    //
    //
    TVIEWV6_IEL_PARAMS ParamBlk;
    if( RWIELParameterBlock( &ParamBlk, BF_READ ) )
    {
        // Perform check to make sure the mac address(company part) is not invalid, if so change them
        if( ParamBlk.MacAddress[0] != TRENDVIEW_MAC_OCTET1 || ParamBlk.MacAddress[1] != TRENDVIEW_MAC_OCTET2 || ParamBlk.MacAddress[2] != TRENDVIEW_MAC_OCTET3 )
        {
            /* @todo LEAVE OUT FOR NOW UNLESS THE PROBLEM REOCCURS
    QString textMess;
    textMess = QString::asprintf("MAC Error %02x:%02x:%02x:%02x:%02x:%02x %x", ParamBlk.MacAddress[0], ParamBlk.MacAddress[1],ParamBlk.MacAddress[2],ParamBlk.MacAddress[3],ParamBlk.MacAddress[4],ParamBlk.MacAddress[5], ParamBlk.Signature );
    MessageBox(NULL, textMess , "Tell a softy that", MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST );
    */
            // Set the mac address passing the existing last 3 digits in , 1st 3 digits will be set automatically.
            SetMACAddress( ParamBlk.MacAddress[3], ParamBlk.MacAddress[4], ParamBlk.MacAddress[5] );
        }
        // Copy mac address from paramater Block.
        for( int mac_octet=0; mac_octet < MAC_ADDRESS_LEN; mac_octet++ )
        {
            m_MacAddress[mac_octet] = ParamBlk.MacAddress[mac_octet];
        }
        m_EthernetBoot = ParamBlk.DLSource;
        // Force USB to be in Host Mode
        if( m_frontUSBSet == USB_FRONT_DEVICE )
        {
            SetFrontUSBType( USB_FRONT_HOST );
        }
    }
#else
	// can be screen designer, pc or test equipment at this point
#ifdef DOCVIEW
    m_deviceType = DEV_PC_SCREEN_DESIGNER;
#else
	// can be pc or test equipment
#ifdef V6IOTEST
    // test equipment
    m_deviceType = DEV_TEST;
#else // must be the PC or Emulator
#ifdef TTR6SETUP
    // It's a V6 Setup DLL build
    m_deviceType = DEV_PC_TTR6SETUP;
#else
	/// @todo Ak Work out screen size for emulator
	if (ms_eDesktopDeviceType == DEV_PC_MULTI) {
		m_screenType = SCRN_12_1;
		m_deviceType = DEV_PC_MULTI;
#ifdef UNDER_CE
        m_deviceType = DEV_ARISTOS_MULTIPLUS;
#endif
	} else if (ms_eDesktopDeviceType == DEV_PC_MINI) {
		m_screenType = SCRN_5_5;
		m_deviceType = DEV_PC_MINI;
#ifdef UNDER_CE
        m_deviceType = DEV_ARISTOS_MINITREND;
#endif
	} else {
		// must be an EZTrend
		m_screenType = SCRN_5_7;
		m_deviceType = DEV_PC_EZTREND;
#ifdef UNDER_CE
        m_deviceType = DEV_ARSITOS_EZTREND; 	//ARISTOS QXe Device Type updates
#endif
	}
#endif	// end of if ttr6 setup
#endif	// end of if test equip or PC
#endif	// end of if screen designer, pc or test equipment
#endif	// end of if recorder, screen designer, pc or test equipment
}
///@ todo Doxygen following routines
//**********************************************************************
///
/// Get a handle to the volume requested
///
/// @param[in]	volumeName - ptr to string with Volume name required.
/// @return		Hndle on Volume, NULL if failed
///
//**********************************************************************
HANDLE CDeviceAbstraction::GetVolumeHandle(TCHAR *volumeName) {
	HANDLE retHandle = NULL;
#ifdef V6_TARGET
    retHandle =  CreateFile( volumeName,GENERIC_READ|GENERIC_WRITE,0,NULL,OPEN_EXISTING,0,NULL );
#endif
	return retHandle;
}
// Perform a volume integrity scan, minor errors are fixed, // details of any remaining errors (and media stats) are returned // in a structure pointed to by ReturnData.
int CDeviceAbstraction::ScanVolume(HANDLE VolumeHandle, DWORD *DataSize, void *ReturnData, unsigned long *ErrorCode) {
#ifdef V6_TARGET
    /*	if ( DeviceIoControl( VolumeHandle,IOCTL_DISK_SCAN_VOLUME, NULL, 0, ReturnData, *DataSize, DataSize, NULL ) == FALSE )
  {
  *ErrorCode = GetLastError();
  return FALSE;
  } */
#endif
	return TRUE;
}
// Perform a volume (default) quick re-format,
// details of any errors (and media stats) are returned
// in a structure pointed to by ReturnData.
int CDeviceAbstraction::QuickasprintfVolume(HANDLE VolumeHandle, DWORD *DataSize, void *ReturnData,
		unsigned long *ErrorCode) {
#ifdef V6_TARGET
    /*	if ( DeviceIoControl( VolumeHandle,IOCTL_DISK_FORMAT_VOLUME, NULL, 0, ReturnData, *DataSize, DataSize, NULL ) == FALSE )
  {
  *ErrorCode = GetLastError();
  return FALSE;
  } */
#endif
	return TRUE;
}
int CDeviceAbstraction::FullasprintfVolume(HANDLE VolumeHandle, DWORD *DataSize, void *ReturnData,
		unsigned long *ErrorCode) {
	/// @todo Create full format for media prepare utility,
	/// will probably require more parameters.
	return FALSE;
}
//**********************************************************************
/// callback Function for displaying message box for QuickasprintfCF below
///
/// @param[in]	szMessage	- message string
/// @param[in]	szTitle		- message title
/// @param[in]	fYesNo		- yes no flag
///
/// @return	 TRUE
///
//**********************************************************************
BOOL MessageFunc(TCHAR* szMessage, TCHAR* szTitle, BOOL fYesNo) {
    QMessageBox(NULL, szMessage, szTitle, MB_ICONINFORMATION);
	return TRUE;
}
//**********************************************************************
/// Quick format of the front SD card
///
/// @return	T/F
///
//**********************************************************************
BOOL CDeviceAbstraction::QuickasprintfFrontSD() {
	BOOL retval = FALSE;
#ifdef V6_TARGET
    HANDLE hDevice = NULL;
    STOREINFO store;
    store.cbSize = sizeof( STOREINFO );
    hDevice = OpenStore( "DSK2:" );
    if ( INVALID_HANDLE_VALUE != hDevice )
    {
        GetStoreInfo( hDevice, &store );
        if ( wcsstr( store.szStoreName, "PCMCIA" ) == NULL )
        {
            //No need to close the mutex in Qt;
            hDevice = OpenStore( "DSK3:" );
        }
    }
    // Check we have the correct device (just in case)
    if ( INVALID_HANDLE_VALUE != hDevice )
    {
        GetStoreInfo( hDevice, &store );
        if ( wcsstr( store.szStoreName, "PCMCIA" ) == NULL )
        {
            //No need to close the mutex in Qt;
            hDevice = INVALID_HANDLE_VALUE;
        }
    }
    if ( INVALID_HANDLE_VALUE != hDevice )
    {
        HANDLE hPartition = NULL;
        DismountStore( hDevice );
        hPartition = OpenPartition( hDevice, "Part00" );
        if ( INVALID_HANDLE_VALUE != hPartition )
        {
            FORMAT_OPTIONS fo = {0};
            fo.dwClusSize = 0;
            fo.dwRootEntries = DEFAULT_ROOT_ENTRIES;
            fo.dwFatVersion = 32;
            fo.dwNumFats = 1;
            fo.dwFlags = FATUTIL_DISABLE_MOUNT_CHK;

            HINSTANCE hDLL = NULL;
            hDLL = ::LoadLibrary( "FatUtil.dl" );
            if ( NULL != hDLL )
            {
                PFN_FORMATVOLUME pfn = NULL;
                pfn  = (PFN_FORMATVOLUME)::GetProcAddress( hDLL, "asprintfVolume" );
                if( pfn( hPartition,
                         NULL,
                         &fo,
                         NULL,
                         &MessageFunc ) != ERROR_SUCCESS )
                {
                    qDebug( "asprintf failed." );
                    MessageBox(NULL, "asprintf front SD", "asprintf failed", MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST );
                }
                else
                {
                    qDebug( "asprintf front SD done OK" );
                    retval=TRUE;
                    MountPartition( hPartition );
                }
                //
                // Stability Project Fix:
                //
                // Fixed memory leak, FreeLibrary() call was missing which was causing memory leak.
                //
                ::FreeLibrary(hDLL);
            }
            //No need to close the mutex in Qt;
        }
        else
        {
            MessageBox(NULL, "asprintf front SD", "asprintf failed", MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST );
        }
        //No need to close the mutex in Qt;
    }
#endif
	return retval;
}
#define DAL_FATAL_LEN 256	// Total length of Fatal error message
//**********************************************************************
///
/// Low Level Fatal error handler, use standalone to aid DAL Portability
/// also used by lower level
///
/// @param[in]	*asprintf,... - VARG List in wide printf format
/// @return		Nothing
///
//**********************************************************************
void CDeviceAbstraction::FatalError(const QString asprintf, ...) {
	WCHAR problemText[DAL_FATAL_LEN + 1];
	va_list Args;
	// Build formatted string for output
	va_start(Args, asprintf);
#if _MSC_VER < 1400
	vswprintf(&problemText[0], asprintf, Args);
#else
    vswprintf_s(&problemText[0], DAL_FATAL_LEN + 1, asprintf,Args);
#endif
	va_end(Args);
	MessageBox(NULL, &problemText[0], "Fatal Error", MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST);
	PerformReboot();
}
//**********************************************************************
//  void SyncTime( )
///
/// Syncronises the platform RTC with the Windows Block
///
/// @return		TRUE if all OK, else FALSE
///
//**********************************************************************
BOOL CDeviceAbstraction::SyncTime() {
	BOOL bResult = FALSE;
#ifdef ARISTOS
#define V6_TARGET
#endif//
#ifdef V6_TARGET
    ms_kSPICritSect.lock();
    bResult = DeviceIoControl(m_hSpi, IOCTL_SPI_SYNC_RTC, NULL, 0, NULL, 0, NULL, NULL);
    ms_kSPICritSect.unlock();
#endif
#ifdef ARISTOS
#undef V6_TARGET
#endif
	return bResult;
}
//**********************************************************************
///
/// Get the idle time as a percentage, this shows the percentage of idle
/// time since the last read
///
/// @return		milli seconds the system has been idle
///
//**********************************************************************
float CDeviceAbstraction::GetTheIdleTimeInPercent() {
	float idleTimePercent = 0;
#ifdef V6_TARGET
    // Get current idle and system ticks
    ULONG newIdleTick = GetIdleTime();
    ULONG newSystemTick = GetTickCount();
    // Calculate idle time percentage since last time this routine was called
    idleTimePercent = ((PERCENT_100*( newIdleTick - m_lastIdleTimeTick )) / ( newSystemTick - m_lastSystemTimeTick ));
    // We are seeing overranged values, IEL need to check this out.
    if( idleTimePercent >= PERCENT_100 )
    {
        idleTimePercent = 0;
        //		qDebug(" Idle = %f idle gap %d  tick gap %d \n ", idleTimePercent, newIdleTick - m_lastIdleTimeTick,  newSystemTick - m_lastSystemTimeTick );
    }

    // Update tick times ready for next call
    m_lastIdleTimeTick = newIdleTick;
    m_lastSystemTimeTick = newSystemTick;
#endif
	return idleTimePercent;
}
// Registry access key
#ifdef UNDER_CE
const WCHAR RegBase[] = ("/");
#else
const WCHAR RegBase[] = ("Honeywell/");
#endif
//**********************************************************************
//  const QString BaseRegistryKey()
///
/// Returns the base registry key for the relevant platform
///
/// @return		WCHAR Registry key base
///
//**********************************************************************
const QString CDeviceAbstraction::BaseRegistryKey() {
	return RegBase;
}
//**********************************************************************
/// Acknolege firmware has booted OK, informs BootLace thet the recorder
/// has stsrted OK; this sllows BootLace to control the boot process if something fails.
///
/// @param[in]	BootOk TRUE if the firmware has booted OK, else FALSE
///
/// @return		None
///
//**********************************************************************
void CDeviceAbstraction::AcknolegeBoot(BOOL BootOk) {
	CSRAMRegion *pBootRam = NULL;						///< Boot RAM region pointer
	T_BOOT_CHECK *bootram;
	CSRAMManager *pRAM = NULL;
	pRAM = CSRAMManager::GetHandle();
	pRAM->Initialise();
	CSRAMManager::regionError requestReturn = pRAM->RequestRegion(REGION_BOOT, &pBootRam);
	if (requestReturn == CSRAMManager::REGION_OKAY) {
		bootram = (T_BOOT_CHECK*) pBootRam->GetAddress();
		if (BootOk)
			bootram->BootCheck = bootram->BootSignature;
		else
			bootram->BootCheck = bootram->BootSignature + 1;
	}
	pRAM->ReleaseRegion(REGION_BOOT);
	return;
}
//**********************************************************************
/// Set Firmware Upgrade paramereters
///
/// @param[in]	fwSignature, FW_UPDATE_WCELOAD or FW_UPDATE_XLOADER for windows or custom loader
///
/// @return		None
//**********************************************************************
void CDeviceAbstraction::SetFirmwareUpdateDetails(USHORT fwSignature, QString commandLine) {
	CSRAMRegion *pBootRam = NULL;						///< Boot RAM region pointer
	T_BOOT_CHECK *bootram;
	CSRAMManager *pRAM = NULL;
	pRAM = CSRAMManager::GetHandle();
	pRAM->Initialise();
	CSRAMManager::regionError requestReturn = pRAM->RequestRegion(REGION_BOOT, &pBootRam);
	if (requestReturn == CSRAMManager::REGION_OKAY) {
		bootram = (T_BOOT_CHECK*) pBootRam->GetAddress();
		bootram->FWUpdateSig = fwSignature;
#if _MSC_VER < 1400
		wcsncpy(bootram->FWCommand, commandLine, FW_PARAM_LEN);
#else
        wcsncpy_s( bootram->FWCommand, sizeof(bootram->FWCommand)/sizeof(WCHAR), commandLine, _TRUNCATE );
#endif
		UpdateSRAM();
	}
	pRAM->ReleaseRegion(REGION_BOOT);
	return;
}
//**********************************************************************
//  void DALTestCaddy( )
///
/// Test caddy for DAL Functions
///
/// @return		Nothing
///
//**********************************************************************
void DALTestCaddy() {
	CDeviceAbstraction *pDAL = CDeviceAbstraction::GetHandle();
	qDebug(("\n********** Enter DAL test caddy ********* \n\n"));
	//*** TEST 1 Flash Block read/write test ***
#if 0
    qDebug(("\n ********** TEST 1 Flash Block read/write test *********\n"));
    BOOL retVal;
    char * pBuffer = (char *)malloc( BF_MAXSIZE + 100 );
    // Write out 64K of A5's
    memset( pBuffer, 0xA5, BF_MAXSIZE + 90 );
    retVal = pDAL->RWBootFlashBlock( BF_WRITE , BF_BLK_TEST , BF_MAXSIZE , pBuffer );
    // Clear buffer and read back in A5's
    memset( pBuffer, 0x00, BF_MAXSIZE + 90 );
    retVal = pDAL->RWBootFlashBlock( BF_READ , BF_BLK_TEST , BF_MAXSIZE , pBuffer );
    // Overwrite with 200 CC's
    memset( pBuffer, 0xCC, BF_MAXSIZE + 90 );
    retVal = pDAL->RWBootFlashBlock( BF_WRITE , BF_BLK_TEST , 200 , pBuffer );
    // Clear buffer and read back 300, should see CC's and A5's
    memset( pBuffer, 0x00, BF_MAXSIZE + 90 );
    retVal = pDAL->RWBootFlashBlock( BF_READ , BF_BLK_TEST , 300 , pBuffer );
    free(pBuffer);
#endif
	// **** TEST 2 PHY status register
#if	0
    qDebug(("\n ********** TEST 2 PHY status register *********\n"));
    ULONG phys,phyi;
    for(phyi=0;phyi<100;phyi++)
    {
        phys = pDAL->GetPHYStatus();
        qDebug(("PHYStatus 10Meg(%d) FullDx(%d) Activity(%d) 100Meg(%d) Tx(%d) Rx(%d)\n"),
               PHYSTAT_10MEG(phys),PHYSTAT_FULLDUPLEX(phys),PHYSTAT_ACIVITY(phys),PHYSTAT_100MEG(phys), PHYSTAT_TRANSMIT(phys),PHYSTAT_RECEIVE(phys) );
        sleep(10);
    }
#endif
	// **** TEST 3 Compact flash LED
#if	0
    qDebug(("\n ********** TEST 3 Compact flash LED *********\n"));
    ULONG ledflash;
    for(ledflash=0;ledflash<20;ledflash++)
    {
        pDAL->SetCFLED( TURN_LED_ON );
        sleep(500);
        pDAL->SetCFLED( TURN_LED_OFF );
        sleep(250);
    }
#endif
	// **** TEST 4 Watchdog test
#if	0
    qDebug(("\n ********** TEST 4 watchdog test *********\n"));
    qDebug(("NOTE, Unit will reset in a few minutes if test successful\n"));
    // Watchdog started and until will run for 100 seconds without reset
    qDebug(("Kick dog every 10 seconds\n"));
    for (int i=0; i < 10; i++)
    {
        pDAL->KickWatchdog();
        sleep( SEC_TO_MSEC(10) );
    }
    // Provoke warning that watchdog not being reset close to 30 seconds
    qDebug(("Kick dog but over 20 second period\n"));
    pDAL->KickWatchdog();
    sleep( SEC_TO_MSEC(25) );
    pDAL->KickWatchdog();
    qDebug(("Made it, but that was close, now it's going to timeout and reset\n"));
    // sleep to over 30 seconds, unit will reset
    sleep( SEC_TO_MSEC(35) );
#endif
	// **** TEST 5 Reboot unit
#if	0
    qDebug(("\n ********** TEST 5 Perform reboot *********\n"));
    qDebug(("Unit will be restarted in 10 seconds\n"));
    sleep( SEC_TO_MSEC(10) );
    pDAL->PerformReboot();
#endif
	// **** TEST 6 Brightness Test
#if	0
    qDebug(("\n ********** TEST 6 Screen brightness control *********\n"));
    short bright=0,l;
    for(l=10;l<=100;l++)
    {
        pDAL->SetScreenBrightness( l );
        sleep(50);
    }
    for(l=100;l>0;l--)
    {
        pDAL->SetScreenBrightness( l );
        sleep(50);
        if( l % 10 == 0 )
        {
            bright = pDAL->GetScreenBrightness();
            if( bright != l )
                qDebug(("*** Error brightness is different!!! \n "));
        }
    }
    sleep( SEC_TO_MSEC(2) );
    pDAL->SetScreenBrightness( SCRN_BACKLIGHT_OFF );
    qDebug(("*** Backlight off for 5 secs (%d)should be 0\n "),pDAL->GetScreenBrightness());
    sleep( SEC_TO_MSEC(4) );
    pDAL->SetScreenBrightness( 50 );
    qDebug(("*** Backlight on 50% (%d)should be 50\n "),pDAL->GetScreenBrightness());
    sleep( SEC_TO_MSEC(4) );
    pDAL->SetScreenBrightness( 10 );
    qDebug(("*** Backlight on 10% (%d)should be 10\n "),pDAL->GetScreenBrightness());
    sleep( SEC_TO_MSEC(4) );
    pDAL->SetScreenBrightness( 100 );
    qDebug(("*** Backlight on 100% (%d)should be 100\n "),pDAL->GetScreenBrightness());
    sleep( SEC_TO_MSEC(4) );
    pDAL->SetScreenBrightness( 5 );
    qDebug(("*** Backlight on 5% (%d)should be 10%\n "),pDAL->GetScreenBrightness());
    sleep( SEC_TO_MSEC(4) );
    pDAL->SetScreenBrightness( 105 );
    qDebug(("*** Backlight on 105% (%d)should be 100%\n "),pDAL->GetScreenBrightness());
    sleep( SEC_TO_MSEC(4) );
#endif
	// **** TEST 7 SPI Test
#if	0
    qDebug(("\n ********** TEST 7 SPI Test *********\n"));
    //		for(int i=0;i<20;i++)
    //		{
    pDAL->SPISelectDevice( SPI_DEVICE_CARD1 );	// Seek to test AP8 stuff.
    sleep(1000);
    //		}
#endif
#if 0
    qDebug(("\n ********** TEST 8 GetFile Paths *********\n"));
    const QString pTestVolume;
    WCHAR pscVolume[MAX_SD_VOLUME_LEN];
    pTestVolume = pDAL->GetVolumeName( SD_INTERNAL_CF, pscVolume );
    pTestVolume = pDAL->GetVolumeName( SD_EXTERNAL_CF, NULL );
    qDebug("intCF=%s extCF=%s \n",pscVolume, pTestVolume );
    pTestVolume = pDAL->GetVolumeName( SD_USB1, pscVolume );
    pTestVolume = pDAL->GetVolumeName( SD_USB2, NULL );
    qDebug("USB1=%s USB2=%s \n",pscVolume, pTestVolume );
    pTestVolume = pDAL->GetVolumeName( (enum storageDeviceIdent)1000, pscVolume );
    if( pTestVolume == NULL )
        qDebug(" COREECT: No such volume id\n");
    else
        qDebug(" ERROR: invalid volume returned non-null ptr \n");

#endif
	qDebug(("\n********** Exit DAL test caddy ********* \n\n"));
}
bool CDeviceAbstraction::BackLightBrightnessTest() {
	bool bReturn = true;
	CDeviceAbstraction *pDAL = CDeviceAbstraction::GetHandle();
	qDebug(("\n ********** TEST 6 Screen brightness control *********\n"));
	int retVal = 0;
	short bright = 0, l;
	for (l = 10; l <= 80; l++) {
		pDAL->SetScreenBrightness(l);
		sleep(50);
	}
	for (l = 80; l > 0; l--) {
		if (pDAL->SetScreenBrightness(l) == -1) {
			bReturn = false;
			return bReturn;
		}
		sleep(50);
		/*if( l % 10 == 0 )
		 {
		 bright = pDAL->GetScreenBrightness();
		 if( bright != l )
		 {
		 qDebug(("*** Error brightness is different!!! \n "));
		 bReturn = false;
		 }
		 }*/
	}
	sleep(SEC_TO_MSEC(2));
	retVal = pDAL->SetScreenBrightness( SCRN_BACKLIGHT_OFF);
	qDebug(("*** Backlight off for 5 secs (%d)should be 0\n "), pDAL->GetScreenBrightness());
	sleep(SEC_TO_MSEC(4));
	retVal = pDAL->SetScreenBrightness(50);
	qDebug(("*** Backlight on 50% (%d)should be 50\n "), pDAL->GetScreenBrightness());
	/*sleep( SEC_TO_MSEC(4) );
	 retVal = pDAL->SetScreenBrightness( 10 );
	 qDebug(("*** Backlight on 10% (%d)should be 10\n "),pDAL->GetScreenBrightness());
	 */
	/*sleep( SEC_TO_MSEC(4) );
	 retVal = pDAL->SetScreenBrightness( 100 );
	 qDebug(("*** Backlight on 100% (%d)should be 100\n "),pDAL->GetScreenBrightness());
	 */	//sleep( SEC_TO_MSEC(4) );
		//retVal = pDAL->SetScreenBrightness( 5 );
		//qDebug(("*** Backlight on 5% (%d)should be 10%\n "),pDAL->GetScreenBrightness());
		//sleep( SEC_TO_MSEC(4) );
	retVal = pDAL->SetScreenBrightness(105);
	qDebug(("*** Backlight on 105% (%d)should be 100%\n "), pDAL->GetScreenBrightness());
	sleep(SEC_TO_MSEC(4));
	if (retVal == -1) {
		bReturn = false;
	}
	return bReturn;
}
//**********************************************************************
///
/// Method that determines if the network connection is running
///
/// @return		true if the network connection is okay, false if it is not
///
//**********************************************************************
const bool CDeviceAbstraction::IsNetworkRunning() {
	ULONG ulPHYStatus = 0;
	ULONG ulLinkSpeed = 0;
	BOOL bConnectionActive = FALSE;
	BOOL bEthernet10MB = FALSE;
	BOOL bEthernet100MB = FALSE;
	/*ulPHYStatus = ~( GetPHYStatus() );
	 bEthernet10MB = ( ( ulPHYStatus & ETHERNET_10MB_PHY_BIT ) == ETHERNET_10MB_PHY_BIT );
	 bEthernet100MB = ( ( ulPHYStatus & ETHERNET_100MB_PHY_BIT ) == ETHERNET_100MB_PHY_BIT );*/
	ulPHYStatus = GetPHYStatus(ulLinkSpeed);
	if (ulPHYStatus == ETHERNET_STATE_DISCONNECTED)
		return false;
	bEthernet10MB = (ulLinkSpeed == ETHERNET_10MB_SPEED);
	bEthernet100MB = (ulLinkSpeed == ETHERNET_100MB_SPEED);
	const bool bLINK_OK = (bEthernet10MB || bEthernet100MB);
	return bLINK_OK;
}
//**********************************************************************
///
/// IsHardwareLockEnabled
///
/// @return		True if hardwareBlock is enabled
///
//**********************************************************************
BOOL CDeviceAbstraction::IsHardwareLockEnabled() {
	BYTE securityLockStatus = 1;
#ifdef UNDER_CE
#ifndef IS_BOOTLACE_APP
    //Fix for PAR #1-3ENG3D7 - Code refactoring for HardwareBlock fix RecSetupCfgMgr.cpp
    if ( pGlbSysInfo  )
    {
        //Get the HWLock status from COMMITED config section. Earlier code used get it from modfiable value
        BOOL bHWLock = pGlbSysInfo->IsHWLockCommited();
        if ( TRUE == bHWLock )
        {
            if (!DeviceIoControl(m_hLEDIO,   // file handle to the driver
                                 IOCTL_SECURITY_LOCK_STATUS,    // I/O control code
                                 NULL,      // in buffer
                                 NULL,   // in buffer size
                                 &securityLockStatus,         // out buffer
                                 sizeof(DWORD),          // out buffer size
                                 NULL,         // pointer to number of bytes returned
                                 NULL))        // ignored (=NULL)
            {
                //Close the Handle
                FatalError( ("DAL: Hardware configurationBlock IOCTL failed"));
            }
        }
    }
#endif
#endif
	return !(BOOL) securityLockStatus;
}
//**********************************************************************
///
/// GetBSPVersion
///
/// @return		The version of BSP
///
//**********************************************************************
BSP_VERSION CDeviceAbstraction::GetBSPVersion() {
	BSP_VERSION versionInfo;
	memset(&versionInfo, 0, sizeof(versionInfo));
#ifdef UNDER_CE
    BOOL retVal = pfGetActiveImageVersion(m_hInterfaceHandle,&versionInfo);
    if ( retVal )
    {
#ifndef IS_BOOTLACE_APP
        if ( pDEVICE_INFO )
        {
            pDEVICE_INFO->m_pdc->Board.BootVer.MajorRev = versionInfo.BootVerMSB;
            pDEVICE_INFO->m_pdc->Board.BootVer.MinorRev = versionInfo.BootVerLSB;
            pDEVICE_INFO->m_pdc->Board.BSPVer.MajorRev = versionInfo.OSVerMSB;
            pDEVICE_INFO->m_pdc->Board.BSPVer.MinorRev = versionInfo.OSVerLSB;
        }
#endif
    }
#endif
	return versionInfo;
}
/*
 Method  : GetSecondaryProcFWVersion
 Description : Get the Secondary firmware version
 */
int CDeviceAbstraction::GetSecondaryProcFWVersion() {
#ifdef IS_BOOTLACE_APP
    UCHAR txMessage[500];
    ULONG txSize = 0;
    BYTE fwVersion = 0;
    memset(txMessage, 0, sizeof(txMessage));
    UCHAR ch = '1';
    txMessage[TX_FUNCTION_CODE_BYTE] =  iMX53_GET_FW_VERSION;
    txMessage[TX_INV_FUNCTION_CODE_BYTE] = ~iMX53_GET_FW_VERSION;
    txMessage[TX_HIGH_BYTES_TO_FOLLOW_BYTE] = NO_MESSAGE_DATA_BYTES / MAX_BYTE_VALUE;
    txMessage[TX_LOW_BYTES_TO_FOLLOW_BYTE] = NO_MESSAGE_DATA_BYTES % MAX_BYTE_VALUE;
    txSize = STD_TX_MESS_LENGTH + NO_MESSAGE_DATA_BYTES;
    CrcInsert(static_cast<UCHAR *>(txMessage), txSize);
    BOOL status = IOCardWrite(txMessage, &txSize, ch);
    if(status)
    {
        UCHAR rxMessage[500];
        txSize = MAXBUFFERSIZE;
        memset(rxMessage, 0, sizeof(rxMessage));
        status = IOCardRead(rxMessage, &txSize, ch);
        if(status)
        {
            fwVersion = (BYTE)rxMessage[4];
        }
    }
    return fwVersion;
#else
	return m_secProcFWVer;
#endif
}
int CDeviceAbstraction::GetCPLDVersion() {
	BYTE out = 0;
#ifdef UNDER_CE
    char test;
    // Get the CPLD version
    if (!DeviceIoControl(m_hLEDIO,   // file handle to the driver
                         IOCTL_IOCTL_CPLD_FIMWARE_VERSION,    // I/O control code
                         &test,      // in buffer
                         sizeof(test),   // in buffer size
                         &out,         // out buffer
                         sizeof(out),          // out buffer size
                         NULL,         // pointer to number of bytes returned
                         NULL))        // ignored (=NULL)
    {
        FatalError(("DAL: Get IOCTL_IOCTL_CPLD_FIMWARE_VERSION failed in GetCPLDVersion\n"));
    }
    out = out & (0x7F); //rambabu input
#endif
	return out;
}
int CDeviceAbstraction::GetBoardRevision() {
	DWORD dwOut = 0;
#ifdef UNDER_CE
    if(!DeviceIoControl(m_hLEDIO,
                        IOCTL_LED_MISC_GET_SYSTEM_REVISION,
                        NULL,
                        NULL,
                        &dwOut,
                        sizeof(dwOut),
                        NULL,
                        NULL))
    {
        FatalError(("DAL: Get IOCTL_LED_MISC_GET_SYSTEM_REVISION failed in GetBoardRevision\n"));
    }
#endif
	return dwOut;
}
//**********************************************************************
///
/// GetmediaFormat
///
/// mediaFormat of Internal SD is set.
///
//**********************************************************************
const QString CDeviceAbstraction::GetmediaFormat() {
    QString mediaFormat = "U"; //U - Stands For UnknownFormat
#ifndef _DEBUG
#ifdef UNDER_CE
	CE_VOLUME_INFO viVolumeInfo;
	memset(&viVolumeInfo, 0, sizeof(CE_VOLUME_INFO));
	viVolumeInfo.cbSize = sizeof(CE_VOLUME_INFO);
    if (CeGetVolumeInfo("/SDMemory/", (CE_VOLUME_INFO_LEVEL)CeVolumeInfoLevelStandard, &viVolumeInfo) == FALSE)
	{}
	if(viVolumeInfo.dwFlags & CE_VOLUME_TRANSACTION_SAFE)
    mediaFormat = "TFAT";
#endif
#endif
    return mediaFormat;
}
//PSR Fix for PAR# 1-3M9770D - Bootlace changes for barcodeScan and SPI test begin
/// TODO: Uncomment this later
//#ifndef IS_BOOTLACE_APP
#ifdef UNDER_CE
/*
Method  : BackupWSDCertificateToFlash
Description : Take a backup of WSD certificate to FLASH during WSD installation.During firmware upgrade WSD certificate is
getting deleted.This will be restored from flash again.
Parameter : void
Return  : void
*/
void CDeviceAbstraction::BackupWSDCertificateToFlash()
{
    CStorage file;
    QString  fileName = QString::fromWCharArray(pSYSTEM_INFO->SoftwareUpdater()->GetCertFileName());
    QFileDevice::FileError ex;
    //BuildPath(IDS_INTERNAL_SD, IDS_CERTIFICATES, WSDCERTFILES[WSDFILECOUNT-1], fileName, MAX_PATH);
    if(file.Open(fileName, QFile::ReadOnly,&ex))
    {
        int fileSize = static_cast<int>(file.size());
        byte* pData = new byte[fileSize+4];
        file.seek(0);
        file.Read(pData, fileSize);
        file.close();
        //Call Flash method to write
        CFlashManager* pFlashMngr = CFlashManager::GetHandle();
        T_FLASH_STATUS status = pFlashMngr->WriteBlock((T_FLASH_BLOCK)FLASH_BLK_WSDCERTIFICATE_1, pData, fileSize);
        delete[] pData;
        pData = NULL;
    }
    QFile::remove(fileName);
    //Remove the Certificate files from SDMemory
    for(int index = 0; index < WSDFILECOUNT; index++)
    {
        BuildPath(IDS_INTERNAL_SD, IDS_CERTIFICATES, &WSDCERTFILES[index], &fileName, MAX_PATH);
        QFile::remove(fileName);
    }
    BuildPath(IDS_INTERNAL_SD, IDS_CERTIFICATES, NULL, &fileName, MAX_PATH);
    QDir rmdir(fileName);
	rmdir.removeRecursively();
}
/*
Method  : BackupWSDCACertificateToFlash
Description : Take a backup of WSD ca certificate to FLASH during WSD installation.During firmware upgrade WSD certificate is
getting deleted.This will be restored from flash again.
Parameter : void
Return  : void
*/
void CDeviceAbstraction::BackupWSDCACertificateToFlash()
{
    CStorage rootfile;
    CStorage devicefile;
    QString  fileRootName = QString::fromWCharArray(pSYSTEM_INFO->SoftwareUpdater()->GetCertCARootFileName());
    QFileDevice::FileError ex;
    if(rootfile.Open(fileRootName, QFile::ReadOnly,&ex))
    {
        ULONG fileSize = static_cast<ULONG>(rootfile.size());
        byte* pData = new byte[fileSize+4];
        rootfile.seek(0);
        rootfile.Read(pData, fileSize);
        rootfile.close();
        //Call Flash method to write
        CFlashManager* pFlashMngr = CFlashManager::GetHandle();
        T_FLASH_STATUS status = pFlashMngr->WriteBlock((T_FLASH_BLOCK)FLASH_BLK_ROOTCACERTIFICATE_2, pData, fileSize);
        delete[] pData;
        pData = NULL;
    }
    //QFile::remove(fileRootName);
    if(CStorage::CreateDirectory(DEFAULT_FLASH_PFX_DEST_PATH_CERTCA, NULL))
    {
        // Rename the .cer, device certificate file to .pfx
        if(!QFile::copy(QString::fromWCharArray(pSYSTEM_INFO->SoftwareUpdater()->GetCertCAServerFileName()), DEFAULT_DEVICE_PFX_PATH_CERTCA))
        {
            //return E_FAIL;
        }
    }
    else
    {
        if(!QFile::copy(QString::fromWCharArray(pSYSTEM_INFO->SoftwareUpdater()->GetCertCAServerFileName()), DEFAULT_DEVICE_PFX_PATH_CERTCA))
        {
            //return E_FAIL;
        }
    }
    QString strDeviceCertPath = "";
    WIN32_FIND_DATA			find_data;
    strDeviceCertPath=DEFAULT_DEVICE_PFX_PATH_CERTCA;
    if( INVALID_HANDLE_VALUE != CStorage::FindFirstFile(strDeviceCertPath, &find_data))
    {
        //QString  fileDeviceName = QString::fromWCharArray(pSYSTEM_INFO->SoftwareUpdater()->GetCertCAServerFileName());
        QFileDevice::FileError ex;
        if(devicefile.Open(strDeviceCertPath, QFile::ReadOnly,&ex))
        {
            ULONG fileSize = static_cast<ULONG>(devicefile.size());
            byte* pData = new byte[fileSize+4];
            devicefile.seek(0);
            devicefile.Read(pData, fileSize);
            devicefile.close();
            //Call Flash method to write
            CFlashManager* pFlashMngr = CFlashManager::GetHandle();
            T_FLASH_STATUS status = pFlashMngr->WriteBlock((T_FLASH_BLOCK)FLASH_BLK_DEVICECACERTIFICATE_3, pData, fileSize);
            delete[] pData;
            pData = NULL;
        }
        else
        {
        }
    }
    QFile::remove(DEFAULT_DEVICE_PFX_PATH_CERTCA);
    QDir rmdir(DEFAULT_FLASH_PFX_DEST_PATH_CERTCA);
	rmdir.removeRecursively();
}
/*
Method  : InstallRootCertificate
Description : Install 2048/1024 RootCertificate.During firmware upgrade we need to install 2048 Root Self Signed Certificate.
Parameter : void
Return  : void
*/
void CDeviceAbstraction::InstallRootCertificate(BOOL isLatest)
{
    /// TODO : Load certificate from shell command
    CStorage file;
    QString fileName = "";
    bool status = true;
    //Map to the public root certificate.
    if(isLatest)
    {
        BuildPath(IDS_INTERNAL_SD, IDS_PRIMARY, "Root_2048.cer", fileName, MAX_PATH);
    }
    else
    {
        BuildPath(IDS_INTERNAL_SD, IDS_PRIMARY, "Root_1024.cer", fileName, MAX_PATH);
    }
    if(status == true)
    {
        //Install Certificate
        hCertInstall = 1;
        if(hCertInstall)
        {
#ifdef UNDER_CE
            IMPORTROOTCERTTOSTORE ImportRootCertToStore = (IMPORTROOTCERTTOSTORE)GetProcAddress(hCertInstall, "ImportRootCertToStore"));
#else
            IMPORTROOTCERTTOSTORE ImportRootCertToStore = (IMPORTROOTCERTTOSTORE)GetProcAddress(hCertInstall, "ImportRootCertToStore"));
#endif
            if(ImportRootCertToStore)
            {
                //Pass empty string as already certificates are extracted in \SDMemory\Certificates
                if(isLatest)
                {
                    ret = ImportRootCertToStore(fileName,ROOT_CERT_CN);
                }
                else
                {
                    ret = ImportRootCertToStore(fileName,ROOT_CERT_CN_OLD);
                }
                if(ret == ERROR_SUCCESS)
                {
                    // Certificate installed successfully.
                    if(isLatest)
                    {
                        LOG_SYSTEM_MESSAGE( MSGLISTSER_SYSTEM_INFORMATION, "Self Root 2048 Certificate Installed Successfully.");
                    }
                    else
                    {
                        LOG_SYSTEM_MESSAGE( MSGLISTSER_SYSTEM_INFORMATION, "Self Root 1024 Certificate Installed Successfully.");
                    }
                    CCertSubjectsStore cCertSubjectsStore;
                    cCertSubjectsStore.CreateandUpdatePubRootCerticateKey("Y");
#ifdef DBG_FILE_LOG_DAL_DBG_ENABLE
                    strDiagMsg = QString::asprintf("DAL-RestoreWSDCertificate() - Secure WSD Certificate Installed Successfully at GTC:%u\r\n", ret, GetTickCount());
                    m_debugFileLogger.WriteToDebugLogFile(strDiagMsg);
#endif
                }
                else
                {
#ifdef DBG_FILE_LOG_DAL_DBG_ENABLE
                    strDiagMsg = QString::asprintf("DAL-RestoreWSDCertificate() - InstallCab failed return code %d at GTC:%u\r\n", ret, GetTickCount());
                    m_debugFileLogger.WriteToDebugLogFile(strDiagMsg);
#endif
                    status = false;	//Certificate installation failed
                }
            }
            else
            {
                status = false;
#ifdef DBG_FILE_LOG_DAL_DBG_ENABLE
                strDiagMsg = QString::asprintf("DAL-RestoreWSDCertificate() - GetProcAddress(ExtractAndInstallCertCab) failed at GTC:%u\r\n", GetTickCount());
                m_debugFileLogger.WriteToDebugLogFile(strDiagMsg);
#endif
            }
        }
        else
        {
#ifdef DBG_FILE_LOG_DAL_DBG_ENABLE
            strDiagMsg = QString::asprintf("DAL-RestoreWSDCertificate() - Falied to Load the CertInstall library at GTC:%u\r\n", GetTickCount());
            m_debugFileLogger.WriteToDebugLogFile(strDiagMsg);
#endif
            status = false; // Falied to Load the library
        }
    }
    if(status == false)
    {
        if(isLatest)
        {
            LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_ERROR, "Secure Self Root 2048 Certificate Installation Failed."));
        }
        else
        {
            LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_ERROR, "Secure Self Root 1024 Certificate Installation Failed."));
        }
        CCertSubjectsStore cCertSubjectsStore;
        cCertSubjectsStore.CreateandUpdatePubRootCerticateKey("N");
    }
}

/*
Method  : RestoreWSDCertificate
Description : Restore WSD Certificate.During firmware upgrade WSD certificate is getting deleted.This will be restored from flash again.
Parameter : void
Return  : void
*/
void CDeviceAbstraction::RestoreWSDCertificate()
{
    CStorage file;
    QString fileName = "";
    bool status = true;
#ifdef DBG_FILE_LOG_DAL_DBG_ENABLE
    QString strDiagMsg;
    strDiagMsg = QString::asprintf("DAL-RestoreWSDCertificate() - Begin at GTC:%u\r\n", GetTickCount());
    m_debugFileLogger.WriteToDebugLogFile(strDiagMsg);
#endif
    //Create Certificate directory in SDMemory, If not exist
    BuildPath(IDS_INTERNAL_SD, IDS_CERTIFICATES, NULL, &fileName, MAX_PATH);
    if(!CStorage::CreateDirectory(fileName, NULL))
    {
        DWORD dwError = GetLastError();
        if(ERROR_ALREADY_EXISTS != dwError && ERROR_FILE_EXISTS != dwError)
        {
            QString strError;
            strError = QString::asprintf( "Failed to create the folder,%d", dwError);
            status = false;
#ifdef DBG_FILE_LOG_DAL_DBG_ENABLE
            strDiagMsg = QString::asprintf("DAL-RestoreWSDCertificate() - Folder %s : %s at GTC:%u\r\n", fileName, strError, GetTickCount());
            m_debugFileLogger.WriteToDebugLogFile(strDiagMsg);
#endif
        }
    }
    if(status == true)
    {
        //Copy the Certificates.cer from flash to SDMemory
        BuildPath(IDS_INTERNAL_SD, IDS_CERTIFICATES, &WSDCERTFILES[WSDFILECOUNT-1], &fileName, MAX_PATH);
        QFileDevice::FileError ex;
        if(file.Open(fileName, QFile::WriteOnly  | QFile::Append,&ex))
        {
            CFlashManager* pFlashMngr = CFlashManager::GetHandle();
            ULONG fileSize = pFlashMngr->GetDataBlockSize((T_FLASH_BLOCK)FLASH_BLK_WSDCERTIFICATE_1);
            byte* pData = new byte[fileSize];
            //Call Flash method to read
            T_FLASH_STATUS status = pFlashMngr->ReadBlock((T_FLASH_BLOCK)FLASH_BLK_WSDCERTIFICATE_1, pData, fileSize);
#ifdef DBG_FILE_LOG_DAL_DBG_ENABLE
            strDiagMsg = QString::asprintf("DAL-RestoreWSDCertificate() - Read from flash %u bytes flash status %d at GTC:%u\r\n", fileSize, status, GetTickCount());
            m_debugFileLogger.WriteToDebugLogFile(strDiagMsg);
#endif
            file.Write(pData, fileSize);
            file.close();
            delete[] pData;
            pData = NULL;
        }
        else
        {
            status = false;
#ifdef DBG_FILE_LOG_DAL_DBG_ENABLE
            strDiagMsg = QString::asprintf("DAL-RestoreWSDCertificate() - Failed to open the file %s at GTC:%u\r\n", fileName, GetTickCount());
            m_debugFileLogger.WriteToDebugLogFile(strDiagMsg);
#endif
        }
        if(status == true)
        {
            //Install WSD Certificate
            HMODULE hCertInstall = LoadLibrary(CERT_IMPORT_DLL);
            int ret = E_FAIL;
            if(hCertInstall)
            {
#ifdef UNDER_CE
                EXTRACTANDINSTALLCERTCAB InstallCab = (EXTRACTANDINSTALLCERTCAB)GetProcAddress(hCertInstall, "ExtractAndInstallCertCab"));
#else
                EXTRACTANDINSTALLCERTCAB InstallCab = (EXTRACTANDINSTALLCERTCAB)GetProcAddress(hCertInstall, "ExtractAndInstallCertCab");
#endif
                if(InstallCab)
                {
                    //Pass empty string as already certificates are extracted in \SDMemory\Certificates
                    ret = InstallCab(fileName);
                    if(ret == ERROR_SUCCESS)
                    {
                        // Certificate installed successfully.
                        LOG_SYSTEM_MESSAGE( MSGLISTSER_SYSTEM_INFORMATION, "Secure Self Certificate Installed Successfully.") );
#ifdef DBG_FILE_LOG_DAL_DBG_ENABLE
                        strDiagMsg = QString::asprintf("DAL-RestoreWSDCertificate() - Secure WSD Certificate Installed Successfully at GTC:%u\r\n", ret, GetTickCount());
                        m_debugFileLogger.WriteToDebugLogFile(strDiagMsg);
#endif
                    }
                    else
                    {
#ifdef DBG_FILE_LOG_DAL_DBG_ENABLE
                        strDiagMsg = QString::asprintf("DAL-RestoreWSDCertificate() - InstallCab failed return code %d at GTC:%u\r\n", ret, GetTickCount());
                        m_debugFileLogger.WriteToDebugLogFile(strDiagMsg);
#endif
                        status = false;	//Certificate installation failed
                    }
                }
                else
                {
                    status = false;
#ifdef DBG_FILE_LOG_DAL_DBG_ENABLE
                    strDiagMsg = QString::asprintf("DAL-RestoreWSDCertificate() - GetProcAddress(ExtractAndInstallCertCab) failed at GTC:%u\r\n", GetTickCount());
                    m_debugFileLogger.WriteToDebugLogFile(strDiagMsg);
#endif
                }
                // Free the CertInstall.DLL

                //Remove the Certificate from SDMemory
                for(int index = 0; index < WSDFILECOUNT; index++)
                {
                    BuildPath(IDS_INTERNAL_SD, IDS_CERTIFICATES, &WSDCERTFILES[index], &fileName, MAX_PATH);
                    QFile::remove(fileName);
                }
                BuildPath(IDS_INTERNAL_SD, IDS_CERTIFICATES, NULL, &fileName, MAX_PATH);
                QDir rmdir(fileName);
	rmdir.removeRecursively();
            }
            else
            {
#ifdef DBG_FILE_LOG_DAL_DBG_ENABLE
                strDiagMsg = QString::asprintf("DAL-RestoreWSDCertificate() - Falied to Load the CertInstall library at GTC:%u\r\n", GetTickCount());
                m_debugFileLogger.WriteToDebugLogFile(strDiagMsg);
#endif
                status = false; // Falied to Load the library
            }
        }
    }
    if(status == false)
    {
        LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_ERROR, "Secure Self Certificate Installation Failed."));
#ifdef DBG_FILE_LOG_DAL_DBG_ENABLE
        strDiagMsg = QString::asprintf("DAL-RestoreWSDCertificate() - Secure WSD Certificate Installation Failed at GTC:%u\r\n", GetTickCount());
        m_debugFileLogger.WriteToDebugLogFile(strDiagMsg);
#endif
    }
#ifdef DBG_FILE_LOG_DAL_DBG_ENABLE
    strDiagMsg = QString::asprintf("DAL-RestoreWSDCertificate() - end Status(%d) at GTC:%u\r\n", status, GetTickCount());
    m_debugFileLogger.WriteToDebugLogFile(strDiagMsg);
#endif
}
/*
Method  : CheckForServerCertificate
Description : Check For Server Certificate
Parameter : void
Return  : void
*/
int CDeviceAbstraction::CheckForServerCertificate(TCHAR* certSubjectName)
{
    HMODULE hCertInstall = LoadLibrary(CERTCA_IMPORT_DLL);
    int ret = 0;
    if(hCertInstall)
    {
#ifdef UNDER_CE
        CHECKSERVERCACERTIFICATE CheckServerCACertificate = (CHECKSERVERCACERTIFICATE)GetProcAddress(hCertInstall, "CheckServerCACertificate"));
#else
        CHECKSERVERCACERTIFICATE CheckServerCACertificate = (CHECKSERVERCACERTIFICATE)GetProcAddress(hCertInstall, "CheckServerCACertificate");
#endif
        if (CheckServerCACertificate)
        {
            OutputDebugString("CheckServerCACertificate..."));
            if(!(lstrcmpi(certSubjectName, "")==0))
            {
                ret = CheckServerCACertificate(certSubjectName);
            }
        }

    }
    return ret;
}
/*
Method  : GetCertificateIssuerName
Description : Check For Server Certificate
Parameter : TCHAR*
Return  : QString
*/
QString CDeviceAbstraction::GetCertificateIssuerName(BOOL isSelfSigned)
{
    QString deviceSubjectName="";
    if(isSelfSigned)
    {
        QString strCertSub="";
        strCertSub = QString::asprintf("XS-%lu"), pGlbSysInfo->GetSerialNumber());
        deviceSubjectName =strCertSub;
#ifdef DBG_FILE_LOG_DAL_DBG_ENABLE
        QString strDiagMsg;
        strDiagMsg = QString::asprintf("CheckCertificateValidity - isselfsigned %s \n", strCertSub);
        m_debugFileLogger.WriteToDebugLogFile(strDiagMsg);
#endif
    }
    else
    {
        CCertSubjectsStore cCertSubjStore;
        //deviceSubjectName=cCertSubjStore.GetServerSubjectKey();
        deviceSubjectName =cCertSubjStore.GetServerSubjectKey();
    }

    WCHAR certIssuerName[MAX_PATH];
    QString strCertIssuerName="";
    if (GetCertificateIssuerName)
    {
        OutputDebugString("GetCertificateIssuerName...");
        if(!(lstrcmpi(deviceSubjectName, "")==0))
        {
            GetCertificateIssuerName(deviceSubjectName,certIssuerName);
            strCertIssuerName = QString(certIssuerName);
        }
    }


    return strCertIssuerName;
}

/*
Method  : CheckCertificateValidity
Description : Check For Certificate Validity
Parameter : void
Return  : void
*/
int CDeviceAbstraction::CheckCertificateValidity(BOOL isSelfSigned)
{
    QString deviceSubjectName;
    if(isSelfSigned)
    {
        QString strCertSub;
        strCertSub = QString::asprintf("XS-%lu", pGlbSysInfo->GetSerialNumber());
        deviceSubjectName = strCertSub;
#ifdef DBG_FILE_LOG_DAL_DBG_ENABLE
        QString strDiagMsg;
        strDiagMsg = QString::asprintf("CheckCertificateValidity - isselfsigned %s \n", strCertSub);
        m_debugFileLogger.WriteToDebugLogFile(strDiagMsg);
#endif
    }
    else
    {
        CCertSubjectsStore cCertSubjStore;
        //deviceSubjectName=cCertSubjStore.GetServerSubjectKey();
        deviceSubjectName = cCertSubjStore.GetServerSubjectKey();
    }
    int ret = -1;

#ifdef DBG_FILE_LOG_DAL_DBG_ENABLE
        QString strDiagMsg;
        strDiagMsg = QString::asprintf("CheckCertificateValidity - entered %s \n", deviceSubjectName);
        m_debugFileLogger.WriteToDebugLogFile(strDiagMsg);
#endif
#ifdef UNDER_CE
        CHECKCERTIFICATEVALIDITY CheckCertificateValidity = (CHECKCERTIFICATEVALIDITY)GetProcAddress(hCertCAInstall, "CheckCertificateValidity");
#else
        CHECKCERTIFICATEVALIDITY CheckCertificateValidity = (CHECKCERTIFICATEVALIDITY)GetProcAddress(hCertCAInstall, "CheckCertificateValidity");
#endif
        if (CheckCertificateValidity)
        {
            OutputDebugString("CheckCertificateValidity..."));
            if(!(lstrcmpi(deviceSubjectName, "")==0))
            {
#ifdef DBG_FILE_LOG_DAL_DBG_ENABLE
                strDiagMsg = QString::asprintf("CheckCertificateValidity - entered second check\n");
                m_debugFileLogger.WriteToDebugLogFile(strDiagMsg);
#endif
                ret = CheckCertificateValidity(deviceSubjectName);
            }


    }
#ifdef DBG_FILE_LOG_DAL_DBG_ENABLE
    QString strDiagMsg;
    strDiagMsg = QString::asprintf("CheckCertificateValidity - entered second check %d\n",ret);
    m_debugFileLogger.WriteToDebugLogFile(strDiagMsg);
#endif
    return ret;
}

/*
Method  : CleanSelfSignedFromFlash
Description : Clean cert from Flash storage
Parameter : void
Return  : void
*/
void CDeviceAbstraction::CleanSelfSignedFromFlash()
{
    BOOL bfilesize=FALSE;
    CFlashManager* pFlashMngr = CFlashManager::GetHandle();
    ULONG fileSize = pFlashMngr->GetDataBlockSize((T_FLASH_BLOCK)FLASH_BLK_WSDCERTIFICATE_1);
    if(fileSize>0)
    {
        bfilesize=TRUE;
    }
    if(bfilesize)
    {
        pFlashMngr->ClearFlashBlock(FLASH_BLK_WSDCERTIFICATE_1);
    }
}
/*
Method  : CleanWSDCACertFromFlash
Description : Clean cert from Flash storage
Parameter : void
Return  : void
*/
void CDeviceAbstraction::CleanWSDCACertFromFlash()
{
    BOOL bfilesize=FALSE;
    CFlashManager* pFlashMngr = CFlashManager::GetHandle();
    ULONG filesize1 = pFlashMngr->GetDataBlockSize((T_FLASH_BLOCK)FLASH_BLK_ROOTCACERTIFICATE_2);
    ULONG filesize2 = pFlashMngr->GetDataBlockSize((T_FLASH_BLOCK)FLASH_BLK_DEVICECACERTIFICATE_3);
    if(filesize1>0)
    {
        pFlashMngr->ClearFlashBlock(FLASH_BLK_ROOTCACERTIFICATE_2);
    }
    if(filesize2>0)
    {
        pFlashMngr->ClearFlashBlock(FLASH_BLK_DEVICECACERTIFICATE_3);
    }
}
/*
Method  : Restore WSD CACertificate
Description : Restore WSD CA Certificate.During firmware upgrade WSD certificate is getting deleted.This will be restored from flash again.
Parameter : void
Return  : void
*/
void CDeviceAbstraction::RestoreWSDCACertificates(LPWSTR wPassword)
{
    CStorage devicefile;
    CStorage rootfile;
    QString  devicePfxName;
    QString rootCerName;
    QString fileName = "";
    QString rootSubjectName="";
    QString deviceSubjectName="";
    QString checkMsg;
    bool status = true;
#ifdef DBG_FILE_LOG_DAL_DBG_ENABLE
    QString strDiagMsg;
    strDiagMsg = QString::asprintf("DAL-RestoreWSDCACertificate() - Begin at GTC:%u\r\n", GetTickCount());
    m_debugFileLogger.WriteToDebugLogFile(strDiagMsg);
#endif
    //Create Certificate directory in SDMemory, If not exist
    BuildPath(IDS_INTERNAL_SD, IDS_CERTIFICATESCA, NULL, &fileName, MAX_PATH);
    //checkMsg = QString::asprintf("CerificateCA filePath %s"),fileName);
    //LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_ERROR, checkMsg);
    if(!CStorage::CreateDirectory(fileName, NULL))
    {
        DWORD dwError = GetLastError();
        if(ERROR_ALREADY_EXISTS != dwError && ERROR_FILE_EXISTS != dwError)
        {
            QString strError;
            strError = QString::asprintf( "Failed to create the folder,%d", dwError);
            //checkMsg = QString::asprintf("CerificateCA filePath %s",fileName));
            //LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_ERROR, strError);
            status = false;
#ifdef DBG_FILE_LOG_DAL_DBG_ENABLE
            strDiagMsg = QString::asprintf("DAL-RestoreWSDCertificate() - Folder %s : %s at GTC:%u\r\n", fileName, strError, GetTickCount());
            m_debugFileLogger.WriteToDebugLogFile(strDiagMsg);
#endif
        }
    }
    if(status == true)
    {
        QFileDevice::FileError ex;
        BuildPath(IDS_INTERNAL_SD, IDS_CERTIFICATESCA,&WSDCACERTFILES[0], &devicePfxName, MAX_PATH);
        if(devicefile.Open(devicePfxName, QFile::WriteOnly  | QFile::Append,&ex))
        {
            /*checkMsg = QString::asprintf("CerificateCA devicePfxName %s"),devicePfxName);
  LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_ERROR, checkMsg);*/
            CFlashManager* pFlashMngr = CFlashManager::GetHandle();
            ULONG fileSize = pFlashMngr->GetDataBlockSize((T_FLASH_BLOCK)FLASH_BLK_DEVICECACERTIFICATE_3);
            byte* pData = new byte[fileSize];
            //Call Flash method to read
            T_FLASH_STATUS status = pFlashMngr->ReadBlock((T_FLASH_BLOCK)FLASH_BLK_DEVICECACERTIFICATE_3, pData, fileSize);
#ifdef DBG_FILE_LOG_DAL_DBG_ENABLE
            strDiagMsg = QString::asprintf("RestoreWSDCACertificates() - Read from flash %u bytes flash status %d at GTC:%u\r\n", fileSize, status, GetTickCount());
            m_debugFileLogger.WriteToDebugLogFile(strDiagMsg);
#endif
            devicefile.Write(pData, fileSize);
            devicefile.close();
            delete[] pData;
            pData = NULL;
        }
        else
        {
            status = false;
#ifdef DBG_FILE_LOG_DAL_DBG_ENABLE
            strDiagMsg = QString::asprintf("RestoreWSDCACertificates() - Failed to open the file %s at GTC:%u\r\n", fileName, GetTickCount());
            m_debugFileLogger.WriteToDebugLogFile(strDiagMsg);
#endif
        }
    }
    if(status==true)
    {
        BuildPath(IDS_INTERNAL_SD, IDS_CERTIFICATESCA,WSDCACERTFILES[1], rootCerName, MAX_PATH);
        if(rootfile.Open(rootCerName, QFile::WriteOnly  | QFile::Append))
        {
            CFlashManager* pFlashMngr = CFlashManager::GetHandle();
            ULONG fileSize = pFlashMngr->GetDataBlockSize((T_FLASH_BLOCK)FLASH_BLK_ROOTCACERTIFICATE_2);
            byte* pData = new byte[fileSize];
            //Call Flash method to read
            T_FLASH_STATUS status = pFlashMngr->ReadBlock((T_FLASH_BLOCK)FLASH_BLK_ROOTCACERTIFICATE_2, pData, fileSize);
#ifdef DBG_FILE_LOG_DAL_DBG_ENABLE
            strDiagMsg = QString::asprintf("RestoreWSDCACertificates() - Read from flash %u bytes flash status %d at GTC:%u\r\n", fileSize, status, GetTickCount());
            m_debugFileLogger.WriteToDebugLogFile(strDiagMsg);
#endif

            rootfile.write((char*)pData, fileSize);
            rootfile.close();
            delete[] pData;
            pData = NULL;
        }
        else
        {
            status = false;
#ifdef DBG_FILE_LOG_DAL_DBG_ENABLE
            strDiagMsg = QString::asprintf("RestoreWSDCACertificates() - Failed to open the file %s at GTC:%u\r\n", fileName, GetTickCount());
            m_debugFileLogger.WriteToDebugLogFile(strDiagMsg);
#endif
        }
    }

    if(status == true)
    {
        //Install WSD Certificate
        int ret = E_FAIL;

#ifdef UNDER_CE
            INSTALLCACERTFILES InstallCaCertFiles=(INSTALLCACERTFILES)GetProcAddress(hCertCAInstall,"InstallCaCertFiles");
#else
            INSTALLCACERTFILES InstallCaCertFiles=(INSTALLCACERTFILES)GetProcAddress(hCertCAInstall,"InstallCaCertFiles");
#endif
            if(InstallCaCertFiles)
            {
                //Pass empty string as already certificates are extracted in \SDMemory\CertificatesCA
                CCrypto kCrypto;
                QString strDecryptedPwd( kCrypto.Decrypt(wPassword, SECURITYOPTIONS_CERTPFXPASSWORD_LEN ) );
                ret = InstallCaCertFiles(devicePfxName,rootCerName,deviceSubjectName,rootSubjectName,T2W(strDecryptedPwd.toLocal8Bit().data()));
                strDecryptedPwd="";
                CCertSubjectsStore cCertSubjStore;
                cCertSubjStore.CreateandUpdateRootSubjectKey(rootSubjectName.toLocal8Bit().data());
                cCertSubjStore.CreateandUpdateServerSubjectKey(deviceSubjectName.toLocal8Bit().data());
                if(ret == ERROR_SUCCESS)
                {
                    // Certificate installed successfully.
                    LOG_SYSTEM_MESSAGE( MSGLISTSER_SYSTEM_INFORMATION, "Restore Secure Custom Certificate Installed Successfully.") );
                    status = true;
#ifdef DBG_FILE_LOG_DAL_DBG_ENABLE
                    strDiagMsg = QString::asprintf("DAL-RestoreWSDCACertificate() - Secure WSD CA Certificate Installed Successfully at GTC:%u\r\n", ret, GetTickCount());
                    m_debugFileLogger.WriteToDebugLogFile(strDiagMsg);
#endif
                }
                else
                {
#ifdef DBG_FILE_LOG_DAL_DBG_ENABLE
                    strDiagMsg = QString::asprintf("DAL-RestoreWSDCertificate() - InstallCab failed return code %d at GTC:%u\r\n", ret, GetTickCount());
                    m_debugFileLogger.WriteToDebugLogFile(strDiagMsg);
#endif
                    status = false;	//Certificate installation failed
                }


            /*for(int index = 0; index < WSDCAFILECOUT; index++)
    {
      BuildPath(IDS_INTERNAL_SD, IDS_CERTIFICATESCA, WSDCERTFILES[index], fileName, MAX_PATH);
      QFile::remove(fileName);
    }
    BuildPath(IDS_INTERNAL_SD, IDS_CERTIFICATESCA, NULL, fileName, MAX_PATH);
    QDir rmdir(fileName);
	rmdir.removeRecursively();*/
        }
        else
        {
#ifdef DBG_FILE_LOG_DAL_DBG_ENABLE
            strDiagMsg = QString::asprintf("DAL-RestoreWSDCertificate() - Falied to Load the CertInstall library at GTC:%u\r\n", GetTickCount());
            m_debugFileLogger.WriteToDebugLogFile(strDiagMsg);
#endif
            status = false; // Falied to Load the library
        }
    }
    if(status == false)
    {
        LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_ERROR, "Secure Custom Certificates Installation Failed."));
#ifdef DBG_FILE_LOG_DAL_DBG_ENABLE
        strDiagMsg = QString::asprintf("DAL-RestoreWSDCACertificate() - Secure WSD CA Certificate Installation Failed at GTC:%u\r\n", GetTickCount());
        m_debugFileLogger.WriteToDebugLogFile(strDiagMsg);
#endif
    }
#ifdef DBG_FILE_LOG_DAL_DBG_ENABLE
    strDiagMsg = QString::asprintf("DAL-RestoreWSDCACertificate() - end Status(%d) at GTC:%u\r\n", status, GetTickCount());
    m_debugFileLogger.WriteToDebugLogFile(strDiagMsg);
#endif
}

//********************************************************************************
//Method  : CleanSecureEmailCertFromFlash
//Description : Clear secure Email certificate which is stored in flash(Block :FLASH_BLK_EMAILROOTCERTIFICATE).
//Parameter : void
//Return  : void
///*******************************************************************************
void CDeviceAbstraction::CleanSecureEmailCertFromFlash()
{
    BOOL bfilesize=FALSE;
    CFlashManager* pFlashMngr = CFlashManager::GetHandle();
    ULONG filesize1 = pFlashMngr->GetDataBlockSize((T_FLASH_BLOCK)FLASH_BLK_EMAILROOTCERTIFICATE);
    if(filesize1>0)
    {
        pFlashMngr->ClearFlashBlock(FLASH_BLK_EMAILROOTCERTIFICATE);
    }
}
//********************************************************************************
//Method  : BackupEmailCertificateToFlash
//Description : Take a backup of Email certificate to FLASH .During firmware upgrade Email certificate is getting deleted.This will be restored from flash again.
//Parameter : void
//Return  : void
///*******************************************************************************
void CDeviceAbstraction::BackupEmailCertificateToFlash()
{
    CStorage file;
    QString  fileName = QString::fromWCharArray(pSYSTEM_INFO->SoftwareUpdater()->GetCertEmailRootFileName());
    QFileDevice::FileError ex;
    //BuildPath(IDS_INTERNAL_SD, IDS_CERTIFICATES, WSDCERTFILES[WSDFILECOUNT-1], fileName, MAX_PATH);
    if(file.Open(fileName, QFile::ReadOnly,&ex))
    {
        int fileSize = static_cast<int>(file.size());
        byte* pData = new byte[fileSize+4];
        file.seek(0);
        file.Read(pData, fileSize);
        file.close();
        //Call Flash method to write
        CFlashManager* pFlashMngr = CFlashManager::GetHandle();
        T_FLASH_STATUS status = pFlashMngr->WriteBlock((T_FLASH_BLOCK)FLASH_BLK_EMAILROOTCERTIFICATE, pData, fileSize);
        delete[] pData;
        pData = NULL;
    }
    QFile::remove(fileName);
    //Remove the Certificate files from SDMemory
    BuildPath(IDS_EXTERNAL_SD, IDS_EMAILCERTIFICATES, NULL, fileName, MAX_PATH);
    QDir rmdir(fileName);
	rmdir.removeRecursively();
}
/*
Method  : RestoreEmailCertificate
Description : Restore email Certificate.During firmware upgrade email certificate is getting deleted.This will be restored from flash again.
Parameter : void
Return  : void
*/
void CDeviceAbstraction::RestoreEmailCertificate()
{
    CStorage file;
    CStorage rootfile;
    QString fileName = "";
    QString rootCerName;
    WCHAR rootSubjectName[MAX_PATH];
    bool status = true;
    //CCertSubjectsStore cCertSubjStore;
    //wcscpy_s(rootSubjectName, sizeof(rootSubjectName)/sizeof(WCHAR),cCertSubjStore.GetRootSubjectKey());
    //Create Certificate directory in SDMemory, If not exist
    BuildPath(IDS_INTERNAL_SD, IDS_EMAILCERTIFICATES, NULL, &fileName, MAX_PATH);
    if(!CStorage::CreateDirectory(fileName, NULL))
    {
        DWORD dwError = GetLastError();
        if(ERROR_ALREADY_EXISTS != dwError && ERROR_FILE_EXISTS != dwError)
        {
            QString strError;
            strError = QString::asprintf( "Failed to create the folder,%d", dwError);
            status = false;
        }
    }
    if(status == true)
    {
        QFileDevice::FileError ex;
        //Copy the Certificates.cer from flash to SDMemory
        BuildPath(IDS_INTERNAL_SD, IDS_EMAILCERTIFICATES, &EMAILCERTFILES, &rootCerName, MAX_PATH);
        if(file.Open(rootCerName, QFile::WriteOnly  | QFile::Append, &ex))
        {
            CFlashManager* pFlashMngr = CFlashManager::GetHandle();
            ULONG fileSize = pFlashMngr->GetDataBlockSize((T_FLASH_BLOCK)FLASH_BLK_EMAILROOTCERTIFICATE);
            byte* pData = new byte[fileSize];
            //Call Flash method to read
            T_FLASH_STATUS status = pFlashMngr->ReadBlock((T_FLASH_BLOCK)FLASH_BLK_EMAILROOTCERTIFICATE, pData, fileSize);
            file.Write(pData, fileSize);
            file.close();
            delete[] pData;
            pData = NULL;
        }
        else
        {
            status = false;
        }
        if(status == true)
        {
            //Install Email Certificate
            int ret = E_FAIL;

#ifdef UNDER_CE
                INSTALLEMAILCERTFILES InstallEmailCertFiles = (INSTALLEMAILCERTFILES)GetProcAddress(hCertInstall, "InstallEmailCertFiles");
#else
                INSTALLEMAILCERTFILES InstallEmailCertFiles = (INSTALLEMAILCERTFILES)GetProcAddress(hCertInstall, "InstallEmailCertFiles");
#endif
                if(InstallEmailCertFiles)
                {
                    //wcscpy_s(rootSubjectName, sizeof(rootSubjectName)/sizeof(WCHAR),""));
                    //Pass empty string as already certificates are extracted in \SDMemory\EmailCertificates
                    WCHAR *pwStr;
                    rootCerName.toWCharArray(pwStr)
                    ret = InstallEmailCertFiles(pwStr,rootSubjectName);
                    CCertSubjectsStore cCertSubjStore;
                    cCertSubjStore.CreateandUpdateEmailRootSubjectKey(rootSubjectName);
                    if(ret == ERROR_SUCCESS)
                    {
                        // Certificate installed successfully.
                        LOG_SYSTEM_MESSAGE( MSGLISTSER_SYSTEM_INFORMATION, "Restore Secure Email Certificate Installed Successfully.") );
                    }
                    else
                    {
                        status = false;	//Certificate installation failed
                    }

                // Free the CertInstall.DLL

                //Remove the Certificate from SDMemory
                BuildPath(IDS_INTERNAL_SD, IDS_EMAILCERTIFICATES, &EMAILCERTFILES, &rootCerName, MAX_PATH);
                QFile::remove(rootCerName);
                BuildPath(IDS_INTERNAL_SD, IDS_EMAILCERTIFICATES, NULL, &fileName, MAX_PATH);
                QDir rmdir(fileName);
	rmdir.removeRecursively();
            }
            else
            {
                status = false; // Falied to Load the library
            }
        }
    }
    if(status == false)
    {
        LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_ERROR, "Restore Secure Email Certificate Installation Failed.");
    }
}
//PSR Fix for PAR# 1-3M9770D - Bootlace changes for barcodeScan and SPI test end
#endif //IS_BOOTLACE_APP

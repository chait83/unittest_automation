/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 System Absraction layer
/// @n Filename: DevCaps.cpp
/// @n Desc:	 Device capabilities information handler
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  54  Stability Project 1.49.1.3 7/2/2011 4:56:44 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  53  Stability Project 1.49.1.2 7/1/2011 4:38:14 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  52  Stability Project 1.49.1.1 3/17/2011 3:20:21 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  51  Stability Project 1.49.1.0 2/15/2011 3:02:55 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// ****************************************************************
#include "SlotMap.h"
#include "BaseProtocol.h"
#include "ATECal.h"
#include "PPL.h"
#include "DevCaps.h"
#include "V6Versions.h"
#include "MediaUtils.h"
//**********************************************************************
/// CDeviceCaps constructor
///
//**********************************************************************
CDeviceCaps::CDeviceCaps() : m_StageTimer(TIMER_NORMAL_RES) {
	m_Initialised = FALSE;
	SetPtrToDeviceCaps(&m_dc);				// By default assign pointer to internal space
	memset(&m_dc, 0, sizeof(T_DEVICECAPS));	// Clear internal device capabilites
	for (USHORT slotIndex = 0; slotIndex < DEVICECAPS_SLOT_SIZE; slotIndex++) {
		// Default each slot
		SetSlotInfo(slotIndex, BOARD_IMPOSSIBLE, 0);
	}
	m_pDal = NULL;
	m_pSlotMap = NULL;
	// Set the length for MEMORYSTATUS structure, only required for the CE build,
	// desktop build sets this automatically(but doesn't hurt).
	m_memStat.dwLength = sizeof(&m_memStat);
}
//**********************************************************************
///
/// Initialise Device Caps
///
/// @return		Nothing
/// 
//**********************************************************************
void CDeviceCaps::Initialise() {
	// Safeguard multiple initialisations
	if (m_Initialised == TRUE) {
		return;
	}
	// determine if this is a new registry
	m_bNewRegistry = GetNewRegistryStatus();
	m_pDal = CDeviceAbstraction::GetHandle();
	m_pSlotMap = CSlotMap::GetHandle();
	// Setup AppVersion
	m_pdc->AppRelease = static_cast<BYTE>(V6_RELEASE);
	m_pdc->AppVersion = V6_VERSION;
	// Get information about recorder build (except IO Cards)
	GenerateProcBoardCaps();
	// Set default IO capability for type of device
	SetPhysicalBoardPopulationCapability();
	m_lastMemoryLevel = GetMemoryAvailableVirtualK();
	m_StageTimer.StartTimer();
	m_Initialised = TRUE;		// Devcaps has been initialised
}
//******************************************************
// AIAcqRatePrimaryChannel()
///
/// Queries what type of board is in a current slot.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] usBoardChanNo - Card slot number channel number identification.
/// @param[out] pPrimaryChanNo - The primary channel channel number.
/// @param[out] pBankNo - The bank that the channel channel number is part of
///							or BANK_NA if bank is not part of setup.
///
/// @return TRUE if channel acqusition rate can be set up;
///			FALSE if channel acqusistion rate is obtained from another channel
/// 
//******************************************************
BOOL CDeviceCaps::AIAcqRatePrimaryChannel(const USHORT cardNo, const USHORT usBoardChanNo, USHORT *pPrimaryChanNo,
USHORT *pBankNo) const {
	BOOL retValue = TRUE;
	*pPrimaryChanNo = usBoardChanNo;
	*pBankNo = BANK_NA;				///< Bank is not applicable
	if (cardNo < DEVICECAPS_SLOT_SIZE) {
		if ( BOARD_EZ_AI == GetSlotType(cardNo)) {
			// Which bank are we operating on
			if (usBoardChanNo < BANK_2_START_CHANNEL) {
				*pBankNo = static_cast<USHORT>(BANK_1_ID);
				*pPrimaryChanNo = IO_CARD_CHANNEL_1;
				if (IO_CARD_CHANNEL_1 != usBoardChanNo) {
					retValue = FALSE;
				}
			} else {
				*pBankNo = static_cast<USHORT>(BANK_2_ID);
				*pPrimaryChanNo = IO_CARD_CHANNEL_4;
				if (IO_CARD_CHANNEL_4 != usBoardChanNo) {
					retValue = FALSE;
				}
			}
		}
	}
	return retValue;
}
//**********************************************************************
/// Get max extra pens for thei device, hard limit is 48 but soft limit
/// willde pend on device
///
/// @return		Number of extra pens supported for this device
//**********************************************************************
int CDeviceCaps::GetMaxExtrasPensForDevice() {
	int extraPensAllowed = EXTRA_PENS;
	// Set minitrend and Eztrend to reduced number of extra pens
	switch (GetDeviceType()) {
	case DEV_PC_MINI:
	case DEV_ARISTOS_MINITREND: {
		extraPensAllowed = EXTRA_PENS_MINI;
		break;
	}
	case DEV_PC_EZTREND:
	case DEV_ARISTOS_EZTREND:	//ARISTOS QXe Device Type updates
	{
		extraPensAllowed = EXTRA_PENS_EZTREND;
		break;
	}
	default: {
		//PSR -fix for the Extra Pens for SCR_MINITREND to be 48 (or equalent to GR Multi)
		extraPensAllowed = EXTRA_PENS;
		break;
	}
	}
	return extraPensAllowed;
}
//**********************************************************************
///
/// Get the mac address by octet, 00-D0-6E-XX-XX-XX where XX will be set in the factory
///
/// @param[in]	index - index of Mac address octet from 0 to 5
/// @return		Relevent mac address octet, or 0 if out of range
/// 
//**********************************************************************
const UCHAR CDeviceCaps::GetMACAddressOct(UCHAR octet) {
	if (octet >= BOARDDETAILS_MACADDRESS_SIZE)
		return 0;
	else
		return m_pdc->Board.MacAddress[octet];
}
//**********************************************************************
///
/// Set pointer to DEVICECAPS capabilities structure, used to access DEVICECAPS
///					held in CMM
///
/// @param[in]	pDevCaps - pointer to new DEVICECAPS structure
/// @return		nothing
/// 
//**********************************************************************
void CDeviceCaps::SetPtrToDeviceCaps(T_PDEVICECAPS pDevCaps) {
	m_pdc = pDevCaps;
}
//**********************************************************************
///
/// Set details of IO Board fitted in the specified slot
///
/// @param[in]	slotNumber - Zero based index of slot to set
/// @param[in]	type - board type see BOARD_XXX in V6IOBoardTypes.h
/// @param[in]	numChannels - Number of channels available on board
/// @return		TRUE if board set okay, FALSE if out of range
/// 
//**********************************************************************
BOOL CDeviceCaps::SetSlotInfo(USHORT slotNumber, USHORT type, USHORT numChannels) {
	if (slotNumber >= DEVICECAPS_SLOT_SIZE)
		return FALSE;
	m_pdc->Slot[slotNumber].Type = type;
	m_pdc->Slot[slotNumber].Channels = static_cast<UCHAR>(numChannels);
	return TRUE;
}
//**********************************************************************
///
/// Get the type of board fitted in the specified slot (including Demo board)
///
/// @param[in]	slotNumber - Zero based index of slot to set
/// @return		Board type in slot see BOARD_XXX in V6IOBoardTypes.h 
///					if slotNumber out of range BOARD_INVALID returned
/// 
//**********************************************************************
const USHORT CDeviceCaps::GetSlotType(USHORT slotNumber) const {
	if (slotNumber >= DEVICECAPS_SLOT_SIZE)
		return BOARD_INVALID;
	return m_pdc->Slot[slotNumber].Type;
}
//**********************************************************************
///
/// Get the general position of the slot passed
///
/// @param[in]	slotNumber - Zero based index of slot to set
/// @return		T_SLOT_POSITION of slot SLOT_TOP, SLOT_BOTTOM or SLOT_UNKNOWN
/// 
//**********************************************************************
const T_SLOT_POSITION CDeviceCaps::GetSlotPosition(USHORT slotNumber) const {
	T_SLOT_POSITION positionRet = SLOT_UNKNOWN;
	// determine which position the slot is related to.
	if (slotNumber >= RECORDER_SLOT_A && slotNumber <= RECORDER_SLOT_F) {
		positionRet = SLOT_TOP;		// These slots are in the top position
	} else if (slotNumber >= RECORDER_SLOT_G && slotNumber <= RECORDER_SLOT_I) {
		positionRet = SLOT_BOTTOM;	// These slots are in the bottom position
	} else {
		positionRet = SLOT_UNKNOWN;	// Unknown slot, so position unknown
	}
	return positionRet;
}
//**********************************************************************
///
/// Get the physical type of board fitted in the specified slot
///
/// @param[in]	slotNumber - Zero based index of slot to set
/// @return		Board type in slot see BOARD_XXX in V6IOBoardTypes.h 
///					if slotNumber out of range BOARD_INVALID returned
/// 
//**********************************************************************
const USHORT CDeviceCaps::GetPhysicalSlotType(USHORT slotNumber) const {
	// Get the slot type set in the device capabilities
	USHORT type = GetSlotType(slotNumber);
	// If this is a demo baord, then report the physical slot as not fitted
	if (IsDemoBoard(slotNumber) == TRUE) {
		type = BOARD_INVALID;
	}
	return type;
}
//**********************************************************************
///
/// Set channel capability of specified channel on the specified slot
///
/// @param[in]	slotNumber - Zero based index of slot to set
/// @param[in]	chanNumber - channel Number from 0-15
/// @param[in]	chanCaps - Channel capabilities, or together CHANNEL_CAP_XXX to
///								build up capability
/// @return		TRUE if board set okay, FALSE if out of range
/// 
//**********************************************************************
BOOL CDeviceCaps::SetChannelCaps(USHORT slotNumber, USHORT chanNumber, UCHAR chanCaps) {
	if (slotNumber >= DEVICECAPS_SLOT_SIZE || chanNumber >= SLOTINFO_CHANNELCAP_SIZE)
		return FALSE;
	m_pdc->Slot[slotNumber].ChannelCap[chanNumber] = chanCaps;
	return TRUE;
}
//**********************************************************************
///
/// Set maximum number of I/O cards available
///
/// @param[in]	maxIOSlots - Number of I/O slots to check
/// @return		Nothing
/// 
//**********************************************************************
void CDeviceCaps::SetIOCardInfo(UCHAR maxIOSlots) {
	m_pdc->IOBoardCount = maxIOSlots;
}
//**********************************************************************
///
/// Get channel capability of specified channel on the specified slot
///
/// @param[in]	slotNumber - Zero based index of slot to set
/// @param[in]	chanNumber - channel Number from 0-15
/// @return		Channel Capability combination of CHANNEL_CAP_XXX, or 0 if slot and channel number invalid
/// 
//**********************************************************************
UCHAR CDeviceCaps::GetChannelCaps(USHORT slotNumber, USHORT chanNumber) const {
	if (slotNumber >= DEVICECAPS_SLOT_SIZE || chanNumber >= SLOTINFO_CHANNELCAP_SIZE)
		return 0;
	return m_pdc->Slot[slotNumber].ChannelCap[chanNumber];
}
//**********************************************************************
///
/// Get maximum number of I/O cards available
///
/// @return		Number of I/O slots to check
/// 
//**********************************************************************
const UCHAR CDeviceCaps::GetIOCardInfo(void) const {
	return m_pdc->IOBoardCount;
}
//**********************************************************************
///
/// Test the channel capability of specified channel on the specified slot
///
/// @param[in]	slotNumber - Zero based index of slot to set
/// @param[in]	chanNumber - channel Number from 0-15
/// @param[in]	chanCaps - Channel capability to test use one CHANNEL_CAP_XXX 
///
/// @return		TRUE if channel capability available, otherwise FALSE
/// 
//**********************************************************************
BOOL CDeviceCaps::TestChannelCapability(USHORT slotNumber, USHORT chanNumber, UCHAR chanCap) const {
	if (slotNumber >= DEVICECAPS_SLOT_SIZE || chanNumber >= SLOTINFO_CHANNELCAP_SIZE)
		return FALSE;
	if (chanCap == (m_pdc->Slot[slotNumber].ChannelCap[chanNumber] & chanCap))
		return TRUE;
	else
		return FALSE;
}
//**********************************************************************
///
/// Test the channel capability of specified channel on the top slots
///
/// @param[in]	slotNumber - Zero based index of slot to set
/// @param[in]	sysChanNumber - System channel Number from 1-48
/// @param[in]	chanCaps - Channel capability to test use one CHANNEL_CAP_XXX 
/// @param[in]	base - The pen base
///
/// @return		TRUE if channel capability available, otherwise FALSE
/// 
//**********************************************************************
BOOL CDeviceCaps::TestTopSlotChannelCapability(const USHORT sysChanNumber, UCHAR chanCap, const T_PENBASE base) const {
	class CSlotMap *pSlotMap = NULL;
	USHORT slotNo;
	USHORT slotChanNo;
	BOOL retValue = FALSE;
	pSlotMap = CSlotMap::GetHandle();
	if (pSlotMap != NULL) {
		pSlotMap->GetSlotAndChannelFromAnalSysChan(sysChanNumber, &slotNo, &slotChanNo, base);/// Relies on all top slor channel numbers being the same
		retValue = TestChannelCapability(slotNo, slotChanNo, chanCap);
	}
	return retValue;
}
//**********************************************************************
///
/// Get the number of channels of board fitted in the specified slot
///
/// @param[in]	slotNumber - Zero based index of slot to query
/// @return		number of channels on board 
///					if slotNumber out of range 0 channels returned
/// 
//**********************************************************************
const USHORT CDeviceCaps::GetSlotNumChannels(USHORT slotNumber) const {
	if (slotNumber >= DEVICECAPS_SLOT_SIZE)
		return 0;
	return m_pdc->Slot[slotNumber].Channels;
}
//**********************************************************************
///
/// Get the number of channels of board fitted in the specified slot
///
/// @param[in]	slotNumber - Zero based index of slot to query
/// @return		number of channel on board 
///					if slotNumber out of range 0 channels returned
/// 
//**********************************************************************
const USHORT CDeviceCaps::GetSlotMaxChannels(USHORT slotNumber) const {
	if (slotNumber >= DEVICECAPS_SLOT_SIZE)
		return 0;
	return m_pSlotMap->GetIOSlotMaxChannels(slotNumber);
}
//**********************************************************************
///
/// Set possible board population for a device
/// 
/// @return		nothing
/// 
//**********************************************************************
void CDeviceCaps::SetPhysicalBoardPopulationCapability() {
	// Set all slots in Dewvice capabilities to impossible i.e cannot possibly be fitted.
	for (int slotIndex = 0; slotIndex < DEVICECAPS_SLOT_SIZE; slotIndex++) {
		SetSlotInfo(slotIndex, BOARD_IMPOSSIBLE, 0);
	}
	// Populate the basic slot map indicating if a card can be fitted by setting to
	// BOARD_NOT_FITTED, if slot is set to BOARD_IMPOSSIBLE then there is no physical way the slot can be used
	switch (GetDeviceType()) {
	case DEV_TEST:
	case DEV_PC_MINI:
	case DEV_ARISTOS_MINITREND:
	case DEV_PC_EZTREND:
	case DEV_ARISTOS_EZTREND:	//ARISTOS QXe Device Type updates
	case DEV_PC_TTR6SETUP: {
		// Only 3 slots available on Minitrend
		SetSlotInfo(RECORDER_SLOT_A, BOARD_NOT_FITTED, 0);
		SetSlotInfo(RECORDER_SLOT_B, BOARD_NOT_FITTED, 0);
		SetSlotInfo(RECORDER_SLOT_G, BOARD_NOT_FITTED, 0);
		break;
	}
	case DEV_PC_MULTI:
	case DEV_ARISTOS_MULTIPLUS:
	case DEV_PC_SCREEN_DESIGNER: {
		// All slots available on MultiPlus
		SetSlotInfo(RECORDER_SLOT_A, BOARD_NOT_FITTED, 0);
		SetSlotInfo(RECORDER_SLOT_B, BOARD_NOT_FITTED, 0);
		SetSlotInfo(RECORDER_SLOT_C, BOARD_NOT_FITTED, 0);
		SetSlotInfo(RECORDER_SLOT_D, BOARD_NOT_FITTED, 0);
		SetSlotInfo(RECORDER_SLOT_E, BOARD_NOT_FITTED, 0);
		SetSlotInfo(RECORDER_SLOT_F, BOARD_NOT_FITTED, 0);
		SetSlotInfo(RECORDER_SLOT_G, BOARD_NOT_FITTED, 0);
		SetSlotInfo(RECORDER_SLOT_H, BOARD_NOT_FITTED, 0);
		SetSlotInfo(RECORDER_SLOT_I, BOARD_NOT_FITTED, 0);
		break;
	}
	case DEV_SCR_MINITREND: {
		SetSlotInfo(RECORDER_SLOT_A, BOARD_NOT_FITTED, 0);
		SetSlotInfo(RECORDER_SLOT_B, BOARD_NOT_FITTED, 0);
		SetSlotInfo(RECORDER_SLOT_G, BOARD_NOT_FITTED, 0);
		SetSlotInfo(RECORDER_SLOT_H, BOARD_NOT_FITTED, 0);
		break;
	}
	}
}
/**
 * @brief GetSystemInfo
 * @param pInfo
 */
void CDeviceCaps::GetSystemInfo(LPSYSTEM_INFO pInfo) {
	/// TODO: Implement this
}
void CDeviceCaps::GlobalMemoryStatus(LPMEMORYSTATUS pMemStatus) {
	/// TODO: Implement this
}
//**********************************************************************
///
/// Populate Processor Board information
/// 
/// @return		nothing
/// 
//**********************************************************************
void CDeviceCaps::GenerateProcBoardCaps() {
	// Setup the device type
	SetDeviceType(m_pDal->GetDeviceType());
	/// TODO : Implementation of GetSystem Info and GlobalMemoryStatus
	// Get system information
	GetSystemInfo(&m_sysInf);
	// Get memory Status
	GlobalMemoryStatus(&m_memStat);
	// Set the RamSize to Total Physical memory available, this
	m_pdc->Board.RamSize = (ULONG) m_memStat.dwTotalPhys;
	// Set the size of the internal static RAM for Non volatile data
	m_pdc->Board.SRAMSize = m_pDal->GetSRAMSize();
	// Set the boot flash size, currently fixed at 2MB
	m_pdc->Board.FlashSize = MB_TO_BYTE(2);						/// Currently 2MB Boot flash
	// Get the Bootloader and BSP versions, BSP also indicates the NK.BIN features
	m_pDal->GetVersionInformation(VER_BOOTLOADER, &m_pdc->Board.BootVer.MajorRev, &m_pdc->Board.BootVer.MinorRev);
	m_pDal->GetVersionInformation(VER_BSP, &m_pdc->Board.BSPVer.MajorRev, &m_pdc->Board.BSPVer.MinorRev);
	// Get Processor board revision, build number and CPLD firmware version, processor speed and J5 jumper status(unused)
	m_pdc->Board.BoardRev = m_pDal->GetBoardRevision();
	//m_pdc->Board.BoardBuildNo = m_pDal->GetBoardBuild();
	m_pdc->Board.CPLDFWVer = m_pDal->GetCPLDVersion();
	m_pdc->Board.Megahertz = m_pDal->GetProcSpeed();
	m_pdc->Board.JumperJ5 = m_pDal->GetJ5Status();
	// Get FW version of AP8 SPI IO comms controller, if exisit (Board Rev 3 onwards)
	m_pdc->Board.SPIProcFW = m_pDal->GetSPIProcFW();
	// Get MAC address
	memcpy(&m_pdc->Board.MacAddress[0], m_pDal->GetMACPtr(), BOARDDETAILS_MACADDRESS_SIZE);
	// Get screen type, 5.5 or 12.1
	m_pdc->Board.ScreenType = m_pDal->GetScreenType();
	// Currently indicate speak always fitted, microphone not support yet
	m_pdc->Board.Speaker = TRUE;
	m_pdc->Board.Microphone = FALSE;
	// Front USB can be configured to HOST or DEVICE
	m_pdc->Board.FrontUSBSet = m_pDal->GetFrontUSBStatus();
	// At boot time the system can optionally check for a platform builder download, development only
	m_pdc->Board.EthernetBoot = m_pDal->GetEthernetBoot();
	// Single relay on power baord fitted
	m_pdc->Board.PowerRelay = m_pDal->IsPowerRelayFitted();
	// RS485 communication fitted
	m_pdc->Board.RS485fitted = m_pDal->GetRS485fitted();
	/// get the internal SD size
	quint64 uliTotalBytes;
	QString wcaInternalCFName = "";
	int iPathLen = MAX_PATH;
	/// TODO : implementation for MediaUtils::GetDiskFreeSpaceEx
	m_pDal->GetPath(static_cast<T_STORAGE_PATH>(IDS_INTERNAL_SD), &wcaInternalCFName, MAX_PATH, &iPathLen);
	if (MediaUtils::GetDiskFreeSpaceEx(wcaInternalCFName, NULL, &uliTotalBytes, NULL)) {
		// the internal SD card should never be greater than 2GB - restrict ot 2GB if it is
		m_pdc->Board.InternalCFSize = uliTotalBytes;
		// round the meory size up so we end up with values that reflect the card type e.g 128MB, 256MB etc
		if (uliTotalBytes > TWO_GB_SIZE)				// If there is greater than 2GB available
			m_pdc->Board.InternalCFSize = MB_TO_BYTE(128);			// must be a PC/emulator build, so treat as 128meg
		else if (m_pdc->Board.InternalCFSize >= FOUR_GB_SIZE) {
			// set to 4GB
			m_pdc->Board.InternalCFSize = ULONG_MAX;
			++m_pdc->Board.InternalCFSize;
		} else if ((m_pdc->Board.InternalCFSize >= MB_TO_BYTE(3500))
				&& (m_pdc->Board.InternalCFSize <= MB_TO_BYTE(4000)))				//4GB card
				{
			m_pdc->Board.InternalCFSize = MB_TO_BYTE(4096);
		} else if ((m_pdc->Board.InternalCFSize >= MB_TO_BYTE(1500))
				&& (m_pdc->Board.InternalCFSize <= MB_TO_BYTE(2000)))				//2GB card
				{
			m_pdc->Board.InternalCFSize = MB_TO_BYTE(2048);
		} else if ((m_pdc->Board.InternalCFSize >= MB_TO_BYTE(600))
				&& (m_pdc->Board.InternalCFSize <= MB_TO_BYTE(1000)))				//1GB card
				{
			m_pdc->Board.InternalCFSize = MB_TO_BYTE(1024);
		} else if (m_pdc->Board.InternalCFSize >= MB_TO_BYTE(480)) {
			m_pdc->Board.InternalCFSize = MB_TO_BYTE(512);
		} else if (m_pdc->Board.InternalCFSize >= MB_TO_BYTE(240)) {
			m_pdc->Board.InternalCFSize = MB_TO_BYTE(256);
		} else if (m_pdc->Board.InternalCFSize >= MB_TO_BYTE(120)) {
			m_pdc->Board.InternalCFSize = MB_TO_BYTE(128);
		} else {
			// must be a 64MB card as this is the minimum we are capable of running
			m_pdc->Board.InternalCFSize = MB_TO_BYTE(64);
		}
	} else {
		// this would imply somekind of fatal error in determining the disk size - this problem will no
		// doubt be caught by the UI so do nothing else here
		m_pdc->Board.InternalCFSize = 0;
	}
}
//**********************************************************************
///
/// Gets the current memory status and returns the approximate 
///  percentage of total physical memory that is in use
///
/// @return		percentage of memory in use
/// 
//**********************************************************************
const ULONG CDeviceCaps::GetMemoryStatus() {
	GlobalMemoryStatus(&m_memStat);
	return m_memStat.dwMemoryLoad;
}
//**********************************************************************
/// Trace the current memory statistics
/// 
/// @param[in]	stageText - Text of current stage
///
/// @return		nothing
//**********************************************************************
void CDeviceCaps::DisplayTraceMemoryStatus(QString stageText) {
	GetMemoryStatus();
	float currmem = GetMemoryAvailableVirtualK();
	m_StageTimer.StopTimer();
	qDebug("MEM: %s = %0.0fK diff(%0.0fK) (%d ms)\n ", stageText.toLocal8Bit().data(), currmem,
			currmem - m_lastMemoryLevel, m_StageTimer.GetTimeInMilliSec(TIMER_SINGLE));
	m_StageTimer.StartTimer();
	m_lastMemoryLevel = currmem;
}
//**********************************************************************
//	bool IsValidAIChannel(	const USHORT usSLOT_NO,
//							const USHORT usCHANNEL_NO ) const
//
/// Method that returns true if the slot contains an analogue input card 
///	and the channel exists on that card
///
/// @param[in]			const USHORT usSLOT_NO - The slot number of the card
/// @param[in]			const USHORT usCHANNEL_NO - The board channel number
///
/// @return		true if the slot contains an analogue input card and the channel
///				exists on that card
/// 
//**********************************************************************
bool CDeviceCaps::IsValidAIChannel(const USHORT usSLOT_NO, const USHORT usCHANNEL_NO) const {
	bool bValid = false;
	// now confirm if this analogue input exists
	UCHAR ucCHAN_CAPS = GetChannelCaps(usSLOT_NO, usCHANNEL_NO);
	// check if this is valid
	if ((ucCHAN_CAPS & CHANNEL_CAP_AI) == CHANNEL_CAP_AI) {
		bValid = true;
	}
	return bValid;
}
//**********************************************************************
//	bool IsValidPulseInputChannel(	const USHORT usSLOT_NO,
//									const USHORT usCHANNEL_NO ) const
//
/// Method that returns true if the slot contains an pulse card and the channel 
/// exists on that card
///
/// @param[in]			const USHORT usSLOT_NO - The slot number of the card
/// @param[in]			const USHORT usCHANNEL_NO - The board channel number
///
/// @return		true if the slot contains an pulse input card and the channel
///				exists on that card
/// 
//**********************************************************************
bool CDeviceCaps::IsValidPulseInputChannel(const USHORT usSLOT_NO, const USHORT usCHANNEL_NO) const {
	bool bValid = false;
	// now confirm if this pulse input exists
	UCHAR ucCHAN_CAPS = GetChannelCaps(usSLOT_NO, usCHANNEL_NO);
	// check if this is valid and not a digital IO card
	if (((ucCHAN_CAPS & CHANNEL_CAP_PULSE) == CHANNEL_CAP_PULSE)
			&& ((ucCHAN_CAPS & CHANNEL_CAP_PULSE) != CHANNEL_CAP_DI)) {
		bValid = true;
	}
	return bValid;
}
//**********************************************************************
//	bool IsValidAOChannel(	const USHORT usSLOT_NO,
//							const USHORT usCHANNEL_NO ) const
//
/// Method that returns true if the slot contains an analogue ouptut and the 
/// channel exists on that card
///
/// @param[in]			const USHORT usSLOT_NO - The slot number of the card
/// @param[in]			const USHORT usCHANNEL_NO - The board channel number
///
/// @return		true if the slot contains an analogue output card and the channel
///				exists on that card
/// 
//**********************************************************************
bool CDeviceCaps::IsValidAOChannel(const USHORT usSLOT_NO, const USHORT usCHANNEL_NO) const {
	bool bValid = false;
	// now confirm if this analogue output exists
	UCHAR ucCHAN_CAPS = GetChannelCaps(usSLOT_NO, usCHANNEL_NO);
	// check if this is valid
	if ((ucCHAN_CAPS & CHANNEL_CAP_AO) == CHANNEL_CAP_AO) {
		bValid = true;
	}
	return bValid;
}
//**********************************************************************
//	bool IsValidDigIOChannel(	const USHORT usSLOT_NO,
//								const USHORT usCHANNEL_NO ) const
//
/// Method that returns true if the slot contains a digital IO card and the channel 
/// exists on that card
///
/// @param[in]			const USHORT usSLOT_NO - The slot number of the card
/// @param[in]			const USHORT usCHANNEL_NO - The board channel number
///
/// @return		true if the slot contains an analogue output card and the channel
///				exists on that card
/// 
//**********************************************************************
bool CDeviceCaps::IsValidDigIOChannel(const USHORT usSLOT_NO, const USHORT usCHANNEL_NO) const {
	bool bValid = false;
	// now confirm if this digital IO exists
	UCHAR ucCHAN_CAPS = GetChannelCaps(usSLOT_NO, usCHANNEL_NO);
	// check if this is valid and not as relay card
	if (((ucCHAN_CAPS & CHANNEL_CAP_DI) == CHANNEL_CAP_DI) && ((ucCHAN_CAPS & CHANNEL_CAP_DO) == CHANNEL_CAP_DO)) {
		bValid = true;
	}
	return bValid;
}
//**********************************************************************
//	bool IsValidRelayOutputChannel(	const USHORT usSLOT_NO,
//									const USHORT usCHANNEL_NO ) const
//
/// Method that returns true if the slot contains a relay output card and the channel
/// exists on that card
///
/// @param[in]			const USHORT usSLOT_NO - The slot number of the card
/// @param[in]			const USHORT usCHANNEL_NO - The board channel number
///
/// @return		true if the slot contains an relay output card and the channel
///				exists on that card
/// 
//**********************************************************************
bool CDeviceCaps::IsValidRelayOutputChannel(const USHORT usSLOT_NO, const USHORT usCHANNEL_NO) const {
	bool bValid = false;
	// now confirm if this relay output exists
	UCHAR ucCHAN_CAPS = GetChannelCaps(usSLOT_NO, usCHANNEL_NO);
	// check if this is valid
	if ((ucCHAN_CAPS & CHANNEL_CAP_DO) == CHANNEL_CAP_DO) {
		bValid = true;
	}
	return bValid;
}
//**********************************************************************
/// Is this a eZ recorder build only(V6App)
///
/// @return		TRUE if a recorder firmware mini/multi only build otherwise FALSE
//**********************************************************************
BOOL CDeviceCaps::IsRecorderEzTrend() {
	//ARISTOS QXe Device Type updates
	if ((GetDeviceType() == DEV_ARISTOS_EZTREND) || (GetDeviceType() == DEV_PC_EZTREND)
			|| (GetDeviceType() == DEV_XS_EZTREND)) {
		return TRUE;
	} else {
		return FALSE;
	}
}
//**********************************************************************
/// Is this a multi recorder build only(V6App)
///
/// @return		TRUE if a recorder firmware multi only build otherwise FALSE
//**********************************************************************
BOOL CDeviceCaps::IsRecorderMulti(T_DEV_TYPE *device) {
	T_DEV_TYPE devType = GetDeviceType();
	if (devType == DEV_ARISTOS_MULTIPLUS || devType == DEV_PC_MULTI || devType == DEV_XS_MULTIPLUS
			|| devType == DEV_SCR_MINITREND) {
		if (device)
			*device = devType;
		return TRUE;
	} else {
		if (device)
			*device = DEV_UNKNOWN;
		return FALSE;
	}
}
//**********************************************************************
/// Is this a multi recorder build only(V6App)
///
/// @return		TRUE if a recorder firmware multi only build otherwise FALSE
//**********************************************************************
BOOL CDeviceCaps::IsRecorderMini() {
	T_DEV_TYPE devType = GetDeviceType();
	if (devType == DEV_ARISTOS_MINITREND || devType == DEV_PC_MINI) {
		return TRUE;
	} else {
		return FALSE;
	}
}
//**********************************************************************
///
/// Query the status whether the power relay is fitted or not
///
/// @return		TRUE if the power relay is fitted; otherwise FALSE
/// 
//**********************************************************************
BOOL CDeviceCaps::IsPowerRelayFitted() {
	BOOL retValue = TRUE;		// Power relay always fitted, in mini/multi
	if (IsRecorderEzTrend() == TRUE)
		retValue = FALSE;		// Power relay not present in eZtrend
	return retValue;
}
//**********************************************************************
///
/// Returns the maximum number of supported pens on the device
///
/// @return		The maximum number of pens supported
/// 
//**********************************************************************
const int CDeviceCaps::GetMaxSupportedPens() {
	if (IsRecorderEzTrend()) {
		return 14 + GetMaxExtrasPensForDevice();
	} else if (IsRecorderMini()) {
		return 16 + GetMaxExtrasPensForDevice();
	} else {
		// must be a multi
		return 48 + GetMaxExtrasPensForDevice();
	}
}
//**********************************************************************
///
/// Indicates if circular mode is available - should be updated to check credits, device type etc.
/// in the event the circular chart mode is to be restricted
///
/// @return		True if circular chart mode is available, false if not
/// 
//**********************************************************************
const BOOL CDeviceCaps::IsCircularChartModeAvailable() const {
	//PSR Fix for PAR # 1-3JLZOK8 - Remove Circular chart from Multi and Mini Recorder begin
	BOOL bIsCirciChartavailable = FALSE;
	//This is the place to enable the circular chart for any recorder varaint
	//For now, as dicussed it is enabled for Multi and SCR mini
	T_DEV_TYPE devType = GetDeviceType();
	if (devType == DEV_ARISTOS_MULTIPLUS || devType == DEV_PC_MULTI || devType == DEV_XS_MULTIPLUS
			|| (TRUE == IsRecorderDRG2()))
			//if ( (TRUE == IsRecorderMulti()) || (TRUE == IsRecorderDRG2()) )
			{
		bIsCirciChartavailable = TRUE;
	}
	//PSR Fix for PAR # 1-3JLZOK8 - Remove Circular chart from Multi and Mini Recorder end
	return bIsCirciChartavailable;
}
//PSR Fix for PAR # 1-3JLZOK8 - Remove Circular chart from Multi and Mini Recorder begin
BOOL CDeviceCaps::IsRecorderDRG2() const {
	T_DEV_TYPE devType = GetDeviceType();
	//DEV_PC_SCR_MINITREND
	if (devType == DEV_SCR_MINITREND /*|| devType == DEV_PC_SCR_MINITREND*/) {
		return TRUE;
	} else {
		return FALSE;
	}
}
//PSR Fix for PAR # 1-3JLZOK8 - Remove Circular chart from Multi and Mini Recorder end

/// @file
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Battery
/// @n Filename: BatteryManager.cpp
/// @n Desc:	 Main Battery management
///
///
//  ****************************************************************
//  Revision History
//
//	Sowmya Pothuri 12/Feb/2020 Battery Management
//  ****************************************************************
#include "BatteryManager.h"
#include "V6globals.h"
#include "StringUtils.h"
#include "DAL.h"
#include "ThreadInfo.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
CBatteryManager *CBatteryManager::m_pBatManInstance = NULL;
QMutex CBatteryManager::m_CreationMutex;
//CBatteryManager *pGlbBatteryManager = NULL;			///< Pointer to the Battery manager
//**********************************************************************
/// CBatteryManager constructor
///
//**********************************************************************
CBatteryManager::CBatteryManager() : m_BLTimer(TIMER_NORMAL_RES), m_pNVTotalOnTime(NULL), m_pNVTotalOnTimeLithium(NULL), m_bBatteryResetPerformed(
		false) {
	m_Initialised = FALSE;
	m_bBootUpLog = true;
}
//**********************************************************************
///
/// Instance creation of CBatteryManager singleton
///
/// @return		pointer to single instance of CBatteryManager
///
//**********************************************************************
CBatteryManager* CBatteryManager::GetHandle() {
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;
	if (NULL == m_pBatManInstance) {
		// An instance has yet to be completed
		waitSingleObjectResult = m_CreationMutex.tryLock(5000);
		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:
			// Object was signaled
			if (NULL == m_pBatManInstance) {
				m_pBatManInstance = new CBatteryManager;
				//pGlbBatteryManager = m_pBatManInstance;		// Assign global
			}
			m_CreationMutex.unlock();
			break;
		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
			V6WarningMessageBox(NULL, L"BATTERYMANAGER WaitForSingleObject Error", L"Battery Manager Error", MB_OK);
			break;
		}
		// Close the Mutex as no longer required
		//No need to close the mutex in Qt;
	}
	return (m_pBatManInstance);
}
//**********************************************************************
///
/// Deletes the instance of the singleton from memory
///
/// @return		Nothing
///
//**********************************************************************
void CBatteryManager::CleanUp() {
	delete m_pBatManInstance;
	m_pBatManInstance = NULL;
}
//**********************************************************************
///
/// Initialise the Battery Manager
///
/// @return		TRUE, if successful, FALSE if failed, Do not continue if failed
///
//**********************************************************************
T_BATTERY_MANAGER_RETURN CBatteryManager::Initialise() {
	if (m_Initialised == TRUE) {
		return BATTERY_MANAGER_OK;
	}
	m_pNVTotalOnTime = pNV_VARS->GetBasicVarNVObject(static_cast<NVVAR_IDENT>(NVV_TOTAL_TIME_ON));
	m_TotalOnTimeSeconds = m_pNVTotalOnTime->GetFromNV()->value;
	m_pNVTotalOnTimeLithium = pNV_VARS->GetBasicVarNVObject(static_cast<NVVAR_IDENT>(NVV_TOTAL_TIME_OFF_LITHIUM));
	m_TotalOnTimeSecondsLithium = m_pNVTotalOnTimeLithium->GetFromNV()->value;
	// Do we need to reset the lithium life counter?
	if ( pSYSTEM_INFO->IsFunctionAvailable(FUNC_RESET_LITHLIFE, TRUE) == TRUE) {
		// Encoded lithium reset file is on front CF, reset the lithium counters
		ResetBatteryLife();
	}
	m_BLTimer.StartTimer();
	m_Initialised = TRUE;	// Battery Manager has been initialised
	return BATTERY_MANAGER_OK;
}
#ifndef TTR6SETUP
//**********************************************************************
/// Process screen saver
///
/// @return		nothing
//**********************************************************************
T_BATTERY_MANAGER_RETURN CBatteryManager::Process() {
	// Update and store total time on
	m_TotalOnTimeSeconds.ul++;
	m_pNVTotalOnTime->SetToNV(m_TotalOnTimeSeconds);
	// Update and store total time on, resettable for use in litium battery calculation
	m_TotalOnTimeSecondsLithium.ul++;
	m_pNVTotalOnTimeLithium->SetToNV(m_TotalOnTimeSecondsLithium);
	return BATTERY_MANAGER_OK;
}
#endif
void CBatteryManager::ResetBatteryLife() {
	m_TotalOnTimeSecondsLithium.ul = 0;
	m_pNVTotalOnTimeLithium->SetToNV(m_TotalOnTimeSecondsLithium);
	pSYSTIMER->ResetLithiumLife();	// Reset the ongoing lithium counter.
	LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_INFORMATION, ("Battery reset is performed "));
}
//**********************************************************************
///
/// Method that resets the battery days left to default in recorder
///
//**********************************************************************
BOOL CBatteryManager::TriggerBatteryReset() {
	//Trigger Reset battery life parameters
	LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_INFORMATION, ("Battery reset is Triggered"));
	return PrepareToReset();
}
QString CBatteryManager::GetBatteryResetFileName() {
	//Create BatteryReset.Key
	QString pRootVol;
	QString fileName;
	pRootVol = pDALGLB->GetVolumeName(SD_INTERNAL_SD, NULL, 0);
	// Build filename and path for flash blocks, the size of the NV is built into
	// the filename, this will allow testing with different sizes without conflict.
	fileName = QString::asprintf((("%sBatteryReset_%04d.key")), pRootVol, BF_BLK_SRAM_BKP_ON_BAT_RESET);
	return fileName;
}
//**********************************************************************
///
/// Prepares the recorder to reset the battery
///
//**********************************************************************
BOOL CBatteryManager::PrepareToReset() {
	//Set Wait Cursor
	SetCursor (AfxGetApp() -> LoadStandardCursor(IDC_WAIT));
	//Trigger application shutdown...
TriggerAppShutdown	;
	//Create BatteryReset.Key
	QFile file;
	QFileDevice::FileError ex;
	//Get File Name
	QString strFileName(GetBatteryResetFileName());
	// File failed to so may not exist, try to create
	if( !file.open( strFileName, QFile::ReadWrite , &ex ) )
	{
		return FALSE;
	}
	//Write the system time that reset has triggered
	CTVtime tvTime;
	tvTime.TimeNow();
	__int64 timeInMicroSeconds = tvTime.GetMicroSecs();
	file.write(&timeInMicroSeconds, sizeof(__int64));
	//close the file
	file.close();
	//Popup.. Ready to shutdwon message
	return TRUE;
}
BOOL CBatteryManager::TriggerAppShutdown() {
	pGlbDal->SetShutDownMode(SHUTDOWN_MODE_SAFE_TO_POWER_OFF);
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	//Ignore the Main thread for watchdog as we have to wait infinitely
	if (pThreadInfo != NULL) {
		pThreadInfo->UpdateThreadInfo(AM_OPPANEL, false);
	}
	::SendMessage(AfxGetApp()->m_pMainWnd->m_hWnd, WM_CLOSE, 0, 0);
	//Consider the Main thread as the wait is over
	if (pThreadInfo != NULL) {
		pThreadInfo->UpdateThreadInfo(AM_OPPANEL, true);
	}
	return TRUE;
}
BOOL CBatteryManager::IsBatteryResetTriggered(QDateTime &stResetTriggerTime) {
	BOOL bRet = FALSE;
	//Get File Name
	QString strFileName(GetBatteryResetFileName());
	QFile file;
	QFileDevice::FileError ex;
	LPSYSTEMTIME lpSysTime = &stResetTriggerTime;
	// Try to open the file for read/write access
	if (file.Open(strFileName.toLocal8Bit().data(), QFile::ReadWrite, &ex)) {
		bRet = TRUE;
		__int64 tvTimeInMicroSeconds = 0;
		// Read from NV block
		file.Read(&tvTimeInMicroSeconds, sizeof(__int64) );
		const __int64 twoMinutesInMircoSec = (2 * 60 * 1000000);
		//Consider two minutes bump due to power off
		tvTimeInMicroSeconds += twoMinutesInMircoSec;
		CTVtime tvTime(tvTimeInMicroSeconds);
		tvTime.GetSYSTEMTIME(lpSysTime);
		file.close();
	}
	/*CStorage kBatteryResetFile;
	 if( kBatteryResetFile.exists( strFileName.toLocal8Bit().data() ) )
	 {
	 bRet = TRUE;
	 }*/
	return bRet;
}
BOOL CBatteryManager::ClearBatteryResetTrigger() {
	BOOL bRet = FALSE;
	//Get File Name
	QString strFileName(GetBatteryResetFileName());
	bRet = CStorage::DeleteFileW(strFileName.toLocal8Bit().data());
	strFileName.ReleaseBuffer();
	return bRet;
}
//**********************************************************************
///
/// Checks the battery reset trigger on reboot
/// And perform SRAM restore
///
/// @return		days left of lithium cell life
///
//**********************************************************************
void CBatteryManager::CheckAndPerformBatteryReset() {
	QDateTime stResetTriggerTime;
	if (IsBatteryResetTriggered(stResetTriggerTime)) {
		//Set the time from the reset key file
		SetV6LocalTime(&stResetTriggerTime);
		//Restore the SRAM
		pDALGLB->RestoreSRAMFromDiskCopy();
		//Clear the Trigger
		ClearBatteryResetTrigger();
		//Update Reset Status
		m_bBatteryResetPerformed = true;
	}
}
//**********************************************************************
///
/// Method that gives the lithum cell life in recorder
///
/// @return		days left of lithium cell life
///
//**********************************************************************
long CBatteryManager::GetLithiumCellLife(bool &bIsLithiumShelfExpired) {
	long lithiumLife = 0;
	lithiumLife = LITHIUM_LIFE_WHEN_POWER_OFF_HOURS - SEC_TO_HOUR(pSYSTIMER->GetLithiumLifeInSeconds());
	if (lithiumLife < 0) {
		lithiumLife = 0;	// lithium out, set to 0
	}
	// Check if lithium is nearing shelf life of 5 years
	long lithiumRunTimeSoFarInHours = SEC_TO_HOUR(GetTotalLithiumOnTimeInSeconds());
	bIsLithiumShelfExpired = false;
	// If the time left on the lithium is greater the shelf life, use shelf life as countdown
	if ((LITHIUM_LIFE_WHEN_POWER_ON_HOURS - lithiumRunTimeSoFarInHours) < lithiumLife) {
		//bIsLithiumShelfExpired = true;
		// Shelf life is 5 years minus the runtime so far of the lithium cell
		lithiumLife = (LITHIUM_LIFE_WHEN_POWER_ON_HOURS - lithiumRunTimeSoFarInHours);
		if (lithiumLife < 24 * 100)		//shelf life less than 100 days
				{
			bIsLithiumShelfExpired = true;
		}
		if (lithiumLife < 0) {
			lithiumLife = 0;	// Make sure no -ve if it has exceeded 5 years
		}
	} else {
		bIsLithiumShelfExpired = false;
	}
	if (lithiumLife) {
		lithiumLife = lithiumLife / 24;
	}
	return lithiumLife;
}
//**********************************************************************
///
/// Method that checks the Lithium cell life and generates a system message
///
/// @return - true if days left is < 100 and year lessthan to 2006
//***********************************************************************
bool CBatteryManager::CheckLithiumCellLife() {
	bool retVal = false;
	QDateTime systime;
	GetLocalTime(&systime);
	bool bIsShelfLifeExpired = false;
	if (IsBatteryResetPerformed()) {
		ResetBatteryLife();
		m_bBatteryResetPerformed = false;
	}
	long lnLithiumLife = GetLithiumCellLife(bIsShelfLifeExpired);
	if (lnLithiumLife < 100 || systime.wYear <= 2006 || (true == bIsShelfLifeExpired)) {
		retVal = true;
	}
	return retVal;
}
//*******************************************************************************
///
/// Method that reflash the system message for every 24hrs if battery is low
///
///*******************************************************************************
bool CBatteryManager::ReflashBatteryMessage() {
	bool bRetVal = false;
	if (m_BLTimer.RecordedTimeInMilliSeconds() >= MESSAGE_REFLASH_TIME_IN_MILLI_SEC || (m_bBootUpLog == true)) {
		if (true == CheckLithiumCellLife()) {
			LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, ("Detected Low Battery !!! "));
			m_bBootUpLog = false;
			bRetVal = true;
		}
		m_BLTimer.ResetAllTimers();
	}
	return bRetVal;
}
//*******************************************************************************
///
/// Method that returns run time days left of battery in recorder
///
///*******************************************************************************
long CBatteryManager::GetTotalLithiumOnTimeDaysleft() {
	long lithiumRunTimeDaysleft = 0;
	long lithiumRunTimeSoFarInHours = SEC_TO_HOUR(GetTotalLithiumOnTimeInSeconds());
	lithiumRunTimeDaysleft = LITHIUM_LIFE_WHEN_POWER_ON_HOURS - lithiumRunTimeSoFarInHours;
	lithiumRunTimeDaysleft = lithiumRunTimeDaysleft / 24;
	if (lithiumRunTimeDaysleft < 0) {
		lithiumRunTimeDaysleft = 0;
	}
	return lithiumRunTimeDaysleft;
}

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	Digital PPQ services
/// @n Filename:	DigitalPPQServices.cpp
/// @n Description: Implementation of the CDigitalPPQServices class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 26	Stability Project 1.21.1.3	7/2/2011 4:56:47 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 25	Stability Project 1.21.1.2	7/1/2011 4:38:15 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 24	Stability Project 1.21.1.1	3/17/2011 3:20:22 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 23	Stability Project 1.21.1.0	2/15/2011 3:02:58 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
// **************************************************************************
#include "DigitalPPQServices.h"
#include "V6globals.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//****************************************************************************
// CDigitalPPQServices(void)
///
/// Constructor of the Class, initialises all member variables to default
/// values.
///
//****************************************************************************
CDigitalPPQServices::CDigitalPPQServices(void) {
	m_NextAvailablePPQ = DPPQSER_DEFAULT_ZERO;
	m_MaxPPQsAvailable = DPPQSER_DEFAULT_ZERO;
	m_MaxAcqusitionRate = PPQC_1HZ;
	m_NumOfEnabledPPQs = DPPQSER_DEFAULT_ZERO;
} // End of Constructor
//****************************************************************************
// ~CDigitalPPQServices(void)
///
/// Destructor of the Class, cleans up the memory used for the class operation 
///
//****************************************************************************
CDigitalPPQServices::~CDigitalPPQServices(void) {
	for (USHORT PPQIndex = DPPQSER_DEFAULT_ZERO; PPQIndex < m_MaxPPQsAvailable; ++PPQIndex) {
		if (NULL != m_pDigitalPPQ.at(PPQIndex)) {
			delete (m_pDigitalPPQ.at(PPQIndex));
		} // End of IF
	} // End of FOR
	m_pDigitalPPQ.clear();
} // End of Destructor
//****************************************************************************
// GetLastResyncSystemTick( void )
///
/// Get the system tick that the Pre Process Queue was last resynced at
/// @param[in] hPPQ - PPQ handle
///
/// @return The system tick
/// 
//**************************************************************************** 
LONGLONG CDigitalPPQServices::GetLastResyncSystemTick(USHORT hPPQ) {
	return m_pDigitalPPQ.at(hPPQ)->GetLastResyncSystemTick();
}
//****************************************************************************
// GetLastResyncDITick( void )
///
/// Get the I/O card tick that the Pre Process Queue was last synced at
/// @param[in] hPPQ - PPQ handle
///
/// @return The I/O card tick
/// 
//**************************************************************************** 
USHORT CDigitalPPQServices::GetLastResyncDITick(USHORT hPPQ) {
	return m_pDigitalPPQ.at(hPPQ)->GetLastResyncDITick();
}
//****************************************************************************
// GetUnprocessedCoverage( void )
///
/// Get the amount of unprocessed coverage from the queue
/// @param[in] hPPQ - PPQ handle
///
/// @return The unprocessed coverage in the queue
/// 
//**************************************************************************** 
ULONG CDigitalPPQServices::GetUnprocessedCoverage(USHORT hPPQ) {
	return m_pDigitalPPQ.at(hPPQ)->GetUnprocessedCoverage();
}
//****************************************************************************
// USHORT GetNumOfEnabledPPQs( void )
///
/// ---Detailed Description of Member Function---
///
/// @return ---Brief Desciption of Return Value---
/// 
//****************************************************************************
USHORT CDigitalPPQServices::GetNumOfEnabledPPQs(void) {
	return (m_NumOfEnabledPPQs);
} // End of Member Function 
//****************************************************************************
// T_PPQSER_RETURN_VALUE RequestPPQ( USHORT &hPPQ )
///
/// ---Detailed Description of Member Function---
///
/// @param[in,out] hPPQ - Brief Desciption in param
///
/// @return ---Brief Desciption of Return Value---
/// 
//****************************************************************************
T_PPQSER_RETURN_VALUE CDigitalPPQServices::RequestPPQ(USHORT &hPPQ) {
	T_PPQSER_RETURN_VALUE retValue = PPQSER_NO_PPQ_AVAILABLE;
	hPPQ = 0xFFFF;
	if (m_MaxPPQsAvailable != m_NextAvailablePPQ) {
		hPPQ = m_NextAvailablePPQ;
		++m_NextAvailablePPQ;
		retValue = PPQSER_OK;
	}
	return (retValue);
} // End of Member Function 
//****************************************************************************
// T_PPQSER_RETURN_VALUE EnablePPQ
///
/// ---Detailed Description of Member Function---
///
/// @param[in] hPPQ			- Brief Desciption in param
/// @param[in] reference		- Brief Desciption in param
/// @param[in] acqusitionRate - Brief Desciption in param
/// @param[in] chartReportMask	- Bit set if channel is logged to the chart and message list
/// @param[in] msgReportMask	- Bit set if channel is logged to message list only
/// @param[in] IPMask			- Mask of all enabled inputs on board
/// @param[in] numOfActiveChannels - Highest IP channel set on board
///
/// @return PPQSER_OK if PPQ sucessfully initailised ortherwise error code
/// 
//****************************************************************************
T_PPQSER_RETURN_VALUE CDigitalPPQServices::EnablePPQ(USHORT hPPQ, T_PPQC_DIGITAL_PPQ_TYPE type,
		T_PPQC_ACQUSITION_RATE acqusitionRate, const USHORT chartReportMask, const USHORT msgReportMask,
		const USHORT IPMask, const USHORT numOfActiveChannels) {
	T_PPQSER_RETURN_VALUE retValue = ValidPPQHandler(hPPQ);
	if (PPQSER_OK == retValue) {
		if (m_MaxAcqusitionRate < acqusitionRate) {
			m_MaxAcqusitionRate = acqusitionRate;
		} // End of IF
		m_pDigitalPPQ.at(hPPQ)->EnablePPQ(type, acqusitionRate);
		m_IPMask[type] = IPMask;
		m_chartReportMask[type] = chartReportMask;
		m_msgReportMask[type] = msgReportMask;
		m_NumOfActiveChannelsOnDICard[type] = numOfActiveChannels + 1; //MarkD: m_NumOfActiveChannelsOnDICard not zero based
		++m_NumOfEnabledPPQs;
	} // End of IF
	return (retValue);
} // End of Member Function 
//****************************************************************************
// T_PPQSER_RETURN_VALUE DisablePPQ( USHORT hPPQ )
///
/// ---Detailed Description of Member Function---
///
/// @param[in] hPPQ		- Brief Desciption in param
///
/// @return ---Brief Desciption of Return Value---
/// 
//****************************************************************************
T_PPQSER_RETURN_VALUE CDigitalPPQServices::DisablePPQ(USHORT hPPQ) {
	T_PPQSER_RETURN_VALUE retValue = ValidPPQHandler(hPPQ);
	if (PPQSER_OK == retValue) {
		m_pDigitalPPQ.at(hPPQ)->DisablePPQ();
		--m_NumOfEnabledPPQs;
	} // End of IF
	return (retValue);
} // End of Member Function 
//****************************************************************************
// T_PPQSER_RETURN_VALUE SyncPPQ( USHORT hPPQ,
//								USHORT inputCardTick, 
//								LONGLONG systemTick )
///
/// ---Detailed Description of Member Function---
///
/// @param[in] hPPQ		- Brief Desciption in param
/// @param[in] inputCardTick - Brief Desciption in param
/// @param[in] systemTick	- Brief Desciption in param
///
/// @return ---Brief Desciption of Return Value---
/// 
//****************************************************************************
T_PPQSER_RETURN_VALUE CDigitalPPQServices::SyncPPQ(USHORT hPPQ, USHORT inputCardTick, LONGLONG systemTick) {
	T_PPQSER_RETURN_VALUE retValue = ValidPPQHandler(hPPQ);
	if (PPQSER_OK == retValue) {
		m_pDigitalPPQ.at(hPPQ)->SyncPPQ(inputCardTick, systemTick);
	} // End of IF
	return (retValue);
} // End of Member Function 
//****************************************************************************
// T_PPQSER_RETURN_VALUE ResetPPQ( USHORT hPPQ )
///
/// ---Detailed Description of Member Function---
///
/// @param[in] hPPQ			- Brief Desciption in param
///
/// @return ---Brief Desciption of Return Value---
/// 
//****************************************************************************										
T_PPQSER_RETURN_VALUE CDigitalPPQServices::ResetPPQ(USHORT hPPQ) {
	T_PPQSER_RETURN_VALUE retValue = ValidPPQHandler(hPPQ);
	if (PPQSER_OK == retValue) {
		m_pDigitalPPQ.at(hPPQ)->ResetPPQ();
	} // End of IF
	return (retValue);
} // End of Member Function 
T_PPQSER_RETURN_VALUE CDigitalPPQServices::ReSyncPPQ(USHORT hPPQ, USHORT inputCardTick, LONGLONG systemTick) {
	T_PPQSER_RETURN_VALUE retValue = ValidPPQHandler(hPPQ);
	if (PPQSER_OK == retValue) {
		m_pDigitalPPQ.at(hPPQ)->ReSyncPPQ(inputCardTick, systemTick);
	} // End of IF
	return (retValue);
} // End of Member Function									
T_PPQSER_RETURN_VALUE CDigitalPPQServices::AddReading(USHORT hPPQ, USHORT reading, USHORT digitalInputTick) {
	T_PPQSER_RETURN_VALUE retValue = ValidPPQHandler(hPPQ);
	if (PPQSER_OK == retValue) {
		m_pDigitalPPQ.at(hPPQ)->AddReading(reading, digitalInputTick);
	} // End of IF
	return (retValue);
} // End of Member Function 
T_PPQSER_RETURN_VALUE CDigitalPPQServices::ValidPPQHandler(USHORT hPPQ) {
	T_PPQSER_RETURN_VALUE retValue = PPQSER_INVALID_PPQ_HANDLE;
	if (hPPQ < m_NextAvailablePPQ) {
		retValue = PPQSER_OK;
	} // End of IF
	return (retValue);
} // End of Member Function 
T_PPQC_ACQUSITION_RATE CDigitalPPQServices::GetMaxAcqusitionRate(void) {
	return (m_MaxAcqusitionRate);
} // End of Member Function 
T_PPQSER_RETURN_VALUE CDigitalPPQServices::Initialise(USHORT maxPPQsAvailable) {
	T_PPQSER_RETURN_VALUE retValue = PPQSER_OK;
	m_MaxPPQsAvailable = maxPPQsAvailable;
	m_pDigitalPPQ.SetSize(m_MaxPPQsAvailable);
	for (USHORT PPQIndex = DPPQSER_DEFAULT_ZERO; PPQIndex < m_MaxPPQsAvailable; ++PPQIndex) {
		m_pDigitalPPQ.SetAt(PPQIndex, new CDigitalPPQ());
		if (NULL == m_pDigitalPPQ.at(PPQIndex)) {
			retValue = PPQSER_CREATION_FAILED;
		} // End of IF
	} // End of FOR
	return (retValue);
} // End of Member Function
T_PPQSER_RETURN_VALUE CDigitalPPQServices::SetTickToBeginProcessing(LONGLONG initialSystemTick) {
	for (USHORT PPQIndex = DPPQSER_DEFAULT_ZERO; PPQIndex < m_NextAvailablePPQ; ++PPQIndex) {
		// Set start position only if queue has been properly synchronised
		if (PPQC_STATUS_OPERATIONAL == m_pDigitalPPQ.at(PPQIndex)->GetStatus()) {
			m_pDigitalPPQ.at(PPQIndex)->SetPosToBeginProcessing(initialSystemTick);
		} // End of IF 
	} // End of FOR
	return (PPQSER_OK);
} // End of Member Function 
LONGLONG CDigitalPPQServices::GetMinSysTickCoverage(void) {
	LONGLONG minCoverage = DPPQSER_NO_ENABLED_PPQS;
	if (DPPQSER_DEFAULT_ZERO != m_NumOfEnabledPPQs) {
		LONGLONG tempMinCoverage = DPPQSER_DEFAULT_ZERO;
		USHORT numOfPPQsWithCoverage = DPPQSER_DEFAULT_ZERO;
		for (USHORT PPQIndex = DPPQSER_DEFAULT_ZERO; PPQIndex < m_NextAvailablePPQ; ++PPQIndex) {
			if (PPQC_STATUS_OPERATIONAL == m_pDigitalPPQ.at(PPQIndex)->GetStatus()) {
				m_pDigitalPPQ.at(PPQIndex)->GetMinSystemTickCoverage(tempMinCoverage);
				if (tempMinCoverage > minCoverage) {
					minCoverage = tempMinCoverage;
				} // End of IF
				++numOfPPQsWithCoverage;
			} // End of IF 
		} // End of FOR 
		if (numOfPPQsWithCoverage != m_NumOfEnabledPPQs) {
			minCoverage = DPPQSER_DEFAULT_ZERO;
		} // End of IF
	} // End of IF 
	return (minCoverage);
} // End of Member Function 
LONGLONG CDigitalPPQServices::GetMaxSysTickCoverage(void) {
	LONGLONG maxCoverage = DPPQSER_NO_ENABLED_PPQS;
	if (DPPQSER_DEFAULT_ZERO != m_NumOfEnabledPPQs) {
		maxCoverage = _I64_MAX;
		LONGLONG tempMaxCoverage = DPPQSER_DEFAULT_ZERO;
		USHORT numOfPPQsWithCoverage = DPPQSER_DEFAULT_ZERO;
		for (USHORT PPQIndex = DPPQSER_DEFAULT_ZERO; PPQIndex < m_NextAvailablePPQ; ++PPQIndex) {
			if (PPQC_STATUS_OPERATIONAL == m_pDigitalPPQ.at(PPQIndex)->GetStatus()) {
				m_pDigitalPPQ.at(PPQIndex)->GetMaxSystemTickCoverage(tempMaxCoverage);
				if (tempMaxCoverage < maxCoverage) {
					maxCoverage = tempMaxCoverage;
				}
				++numOfPPQsWithCoverage;
			}
		}
		if (numOfPPQsWithCoverage != m_NumOfEnabledPPQs) {
			maxCoverage = DPPQSER_DEFAULT_ZERO;
		}
	}
	return (maxCoverage);
}
T_PPQSER_RETURN_VALUE CDigitalPPQServices::PopulateDataItemTable(USHORT tickIncrement) {
	class CIOSetupConfig *pIOSetupConfig = NULL;
	T_MSGLISTSER_USER_MSG_TYPE msgType;			///< Type of user message 
	WCHAR messageText[MSGLISTSER_NUM_OF_CHARACTERS_PER_MESSAGE];
	CDigitalPPQ *pDPPQ = NULL;
	class CDataItem *pDataItem = NULL;
	USHORT firstChannelNumberOnSlot = DPPQSER_DEFAULT_ZERO;
	USHORT reading = DPPQSER_DEFAULT_ZERO;
	USHORT numOfActiveChannels = DPPQSER_DEFAULT_ZERO;
	for (USHORT PPQIndex = DPPQSER_DEFAULT_ZERO; PPQIndex < m_NextAvailablePPQ; ++PPQIndex) {
		pDPPQ = m_pDigitalPPQ.at(PPQIndex);
		if (PPQC_STATUS_OPERATIONAL == pDPPQ->GetStatus()) {
			pDPPQ->GetReading(reading, tickIncrement);
			switch (pDPPQ->GetType()) {
			case PPQC_DIGITAL_SLOT_1:
				firstChannelNumberOnSlot = PPQC_DI_SLOT_1_START_CHANNEL;
				if (pDPPQ->m_pCardDataItem == NULL) {
					pDPPQ->m_pCardDataItem = pGlbDIT->GetDataItemPtr(DI_IO, DI_IO_MISC, DI_IO_DIG_BITS_SLOT1);
				}
				break;
			case PPQC_DIGITAL_SLOT_2:
				firstChannelNumberOnSlot = PPQC_DI_SLOT_2_START_CHANNEL;
				if (pDPPQ->m_pCardDataItem == NULL) {
					pDPPQ->m_pCardDataItem = pGlbDIT->GetDataItemPtr(DI_IO, DI_IO_MISC, DI_IO_DIG_BITS_SLOT2);
				}
				break;
			case PPQC_DIGITAL_SLOT_3:
				firstChannelNumberOnSlot = PPQC_DI_SLOT_3_START_CHANNEL;
				if (pDPPQ->m_pCardDataItem == NULL) {
					pDPPQ->m_pCardDataItem = pGlbDIT->GetDataItemPtr(DI_IO, DI_IO_MISC, DI_IO_DIG_BITS_SLOT3);
				}
				break;
			default: /* Error */
				break;
			}
			if (NULL != pDPPQ->m_pCardDataItem) {
				pDPPQ->m_pCardDataItem->SetValue(static_cast<FLOAT>(reading));
			}
			pIOSetupConfig = pSETUP->GetIOSetupConfig();
			USHORT maxChan = m_NumOfActiveChannelsOnDICard[pDPPQ->GetType()];
			for (USHORT channelIndex = DPPQSER_DEFAULT_ZERO; channelIndex < maxChan; ++channelIndex) {
				// Only process channel if it is enabled
				if (GetBits(m_IPMask[pDPPQ->GetType()], channelIndex, 1) > 0) {
					if (NULL == pDPPQ->m_pChannelDataItem[channelIndex]) {
						// Channel is configured as an input
						pDPPQ->m_pChannelDataItem[channelIndex] = pGlbDIT->GetDataItemPtr(DI_IO, DI_IO_DIGITAL,
								firstChannelNumberOnSlot + channelIndex);
					}
					if (static_cast<BOOL>(pDPPQ->m_pChannelDataItem[channelIndex]->GetFPValue())
							!= static_cast<BOOL>(reading & DPPQSER_CHANNEL_SET_COMPARE_VALUE)) {
						if (pDPPQ->m_pDigCMMConfig[channelIndex] == NULL) {
							pDPPQ->m_pDigCMMConfig[channelIndex] = pIOSetupConfig->GetDigital(
									static_cast<UCHAR>(pDPPQ->GetType() + RECORDER_SLOT_G), channelIndex,
									CONFIG_COMMITTED);
						}
						// Log the input state change to the approriate message queues
						if ((reading & DPPQSER_CHANNEL_SET_COMPARE_VALUE) > 0) {
							swprintf(messageText, MSGLISTSER_NUM_OF_CHARACTERS_PER_MESSAGE, L"%s %s",
									pDPPQ->m_pDigCMMConfig[channelIndex]->Label,
									pDPPQ->m_pDigCMMConfig[channelIndex]->Active);
							msgType = MSGLISTSER_DIGITAL_ACTIVATE;
							// Update the digital I/O counter DIT
							pDataItem = pDIT->GetDataItemPtr(DI_COUNTER, DI_COUNTTYPE_IO,
									firstChannelNumberOnSlot + channelIndex);
							if (pDataItem != NULL) {
								pDataItem->SetValue(pDataItem->GetFPValue() + 1.0F);
								pDataItem->SetStatus(DISTAT_NORMAL);
							}
						} else {
							swprintf(messageText, MSGLISTSER_NUM_OF_CHARACTERS_PER_MESSAGE, L"%s %s",
									pDPPQ->m_pDigCMMConfig[channelIndex]->Label,
									pDPPQ->m_pDigCMMConfig[channelIndex]->InActive);
							msgType = MSGLISTSER_DIGITAL_DEACTIVATE;
						}
						if (GetBits(m_chartReportMask[pDPPQ->GetType()], channelIndex, 1) > 0) {
							LOG_DIGITAL_CHART_MESSAGE(msgType, QString::fromWCharArray(messageText));
						} else if (GetBits(m_msgReportMask[pDPPQ->GetType()], channelIndex, 1) > 0) {
							LOG_DIGITAL_MESSAGE(msgType, QString::fromWCharArray(messageText));
						}
					}
					if (NULL != pDPPQ->m_pChannelDataItem[channelIndex]) {
						pDPPQ->m_pChannelDataItem[channelIndex]->SetValue(
								static_cast<FLOAT>(reading & DPPQSER_CHANNEL_SET_COMPARE_VALUE));
					}
				}
				reading >>= DPPQSER_ONE_BIT;
			}
		}
	}
	return (PPQSER_OK);
} // End of Member Function 
T_PPQSER_RETURN_VALUE CDigitalPPQServices::ResetAllPPQs(void) {
	for (USHORT PPQIndex = DPPQSER_DEFAULT_ZERO; PPQIndex < m_MaxPPQsAvailable; ++PPQIndex) {
		if (NULL != m_pDigitalPPQ.at(PPQIndex)) {
			m_pDigitalPPQ.at(PPQIndex)->ResetPPQ();
			if (m_NextAvailablePPQ > 0)
				--m_NextAvailablePPQ;
			if (m_NumOfEnabledPPQs > 0)
				--m_NumOfEnabledPPQs;
		} // End of IF
	} // End of FOR
	return (PPQSER_OK);
} // End of Member Function
T_PPQSER_RETURN_VALUE CDigitalPPQServices::SetLastReadingCoverage(USHORT hPPQ, LONGLONG systemTick) {
	T_PPQSER_RETURN_VALUE retValue = ValidPPQHandler(hPPQ);
	if (PPQSER_OK == retValue) {
		m_pDigitalPPQ.at(hPPQ)->SetLastReadingCoverage(systemTick);
	} // End of IF
	return (retValue);
} // End of Member Function
/// Reset the Pre Process Queues to Default State
T_PPQSER_RETURN_VALUE CDigitalPPQServices::ResetToDefault(void) {
	T_PPQSER_RETURN_VALUE retValue = PPQSER_OK;
	return (retValue);
}
void CDigitalPPQServices::SaveToFileAllPPQInfo(CStorage &PPQInfoFile) {
	// Write the Column Headers
	QString columnHeader = "";
	columnHeader = "PPQ Type,";
	PPQInfoFile.Write(columnHeader.toLocal8Bit().data(), columnHeader.length() * sizeof(TCHAR));
	columnHeader = "PPQ Acq Rate,";
	PPQInfoFile.Write(columnHeader.toLocal8Bit().data(), columnHeader.length() * sizeof(TCHAR));
	columnHeader = "InitialSysCov,";
	PPQInfoFile.Write(columnHeader.toLocal8Bit().data(), columnHeader.length() * sizeof(TCHAR));
	columnHeader = "InitialAITick,";
	PPQInfoFile.Write(columnHeader.toLocal8Bit().data(), columnHeader.length() * sizeof(TCHAR));
	columnHeader = "FirstReadingDITick,";
	PPQInfoFile.Write(columnHeader.toLocal8Bit().data(), columnHeader.length() * sizeof(TCHAR));
	columnHeader = "FirstReadingTickDifference,";
	PPQInfoFile.Write(columnHeader.toLocal8Bit().data(), columnHeader.length() * sizeof(TCHAR));
	columnHeader = QString::asprintf("%c%c", 0x0D, 0x0A);
	PPQInfoFile.Write(columnHeader.toLocal8Bit().data(), columnHeader.length() * sizeof(TCHAR));
	for (USHORT PPQIndex = DPPQSER_DEFAULT_ZERO; PPQIndex < m_NextAvailablePPQ; ++PPQIndex) {
		if (NULL != m_pDigitalPPQ.at(PPQIndex)) {
			m_pDigitalPPQ.at(PPQIndex)->SavePPQInfoToFile(PPQInfoFile);
		} // End of IF
	} // End of FOR
} // End of Member Function

#ifndef _PPQMANAGER_H
#define _PPQMANAGER_H
#include <QMutex>
#include "Defines.h"
#include "PPQCommon.h"
#include "DigitalPPQServices.h"
#include "AnaloguePulsePPQServices.h"
#include "PassiveModule.h"
const USHORT PPQM_DEFAULT_ZERO = 0;
const SHORT PPQM_NO_ENABLED_PPQS = -1;
const SHORT PPQM_NO_COVERAGE = 0;
typedef enum {
	PPQM_SER_ANALOGUE_PULSE, PPQM_SER_DIGITAL,
	PPQM_SER_NUM_OF_SERVICES
} T_PPQM_SERVICES;
typedef enum {
	PPQM_OK, PPQM_NO_COVERAGE_AVAILABLE
} T_PPQM_RETURN_VALUE;
typedef enum {
	PPQM_ALIGNED, PPQM_NOT_ALIGNED
} T_PPQM_ALIGNMENT_STATUS;
//**Class*********************************************************************
///
/// @brief ---Single line description---.
/// 
/// --- Detailed Description ---
///
//****************************************************************************
class CPPQManager: public CPassiveModule {
public:
	/// Obtain Handler to the Pre Process Queue Manager
	static CPPQManager* GetHandle(void);
	/// Cleanup the Pre Process Queue Manager 
	T_PPQM_RETURN_VALUE CleanUp(void);
	/// Initialise the Pre Process Manager
	T_PPQM_RETURN_VALUE Initialise(USHORT numOfAnalogusPulsePPQs, USHORT numOfDigitalPPQs);
	/// Obtain the Min System Tick that can be processed from all Pre Process Queues
	T_PPQM_RETURN_VALUE GetMinSystemTickCoverage(LONGLONG &minCoverage);
	/// MarkD:obtain the Min System Tick that can be processed from only digital Pre Process Queues
	T_PPQM_RETURN_VALUE GetMinDigitalTickCoverage(LONGLONG &minCoverage);
	/// Obtain the Max System Tick that can be processed from all Pre Process Queues
	T_PPQM_RETURN_VALUE GetMaxSystemTickCoverage(LONGLONG &maxCoverage);
	/// Obtain the Max System Tick that can be processed from APPQs (MarkD)
	T_PPQM_RETURN_VALUE GetMaxSystemAPPQTickCoverage(LONGLONG &maxCoverage);
	/// Get the Max Acqusition Rate in use from all Pre Process Queues
	T_PPQC_ACQUSITION_RATE GetMaxAcquisitionRate(void);
	/// Reset all Pre Process Queues to default
	T_PPQM_RETURN_VALUE ResetAllPPQsToDefault(void);
	/// Reset the Pre Process Manager to Default
	T_PPQM_RETURN_VALUE ResetToDefault(void);
	/// Populate the Data Item Table for an associated tick
	T_PPQM_RETURN_VALUE PopulateDataItemTable(USHORT tickIncrement);
	/// Digital Pre Process Services 
	CDigitalPPQServices m_DPPQServices;
	/// Analogue Pre Process Services
	CAnaloguePulsePPQServices m_APPPQServices;
private:
	// --- Restrict the following four methods from being called, as this is a singleton --- //
	/// Constructor
	CPPQManager();
	/// Copy Constructor
	CPPQManager(const CPPQManager&);
	/// Equals Operator
	CPPQManager& operator=(const CPPQManager&) {
		return *this;
	}
	;
	/// Destructor
	~CPPQManager();
	// --- Private Member Variables --- //
	static CPPQManager *m_pInstance; ///< Single Instance of the Pre Process Queue Manager
	static QMutex m_CreationMutex;	///< Mutex for instance creation
	T_PPQM_ALIGNMENT_STATUS m_PPQsAlignmentStatus; ///< Status of initial Pre Process Queue Alignment
};
// End of Class Declaration
#endif // _PPQMANAGER_H

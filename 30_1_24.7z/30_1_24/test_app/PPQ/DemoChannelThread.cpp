// InputCardDemoThread.cpp : implementation file
//
#include "DemoChannelThread.h"
#include "AnaloguePulseDemoChannel.h"
#include "DigitalDemoChannel.h"
#include "PPQManager.h"
#include "V6globals.h"
CDemoChannelThread::CDemoChannelThread() {
}
CDemoChannelThread::~CDemoChannelThread() {
}
BOOL CDemoChannelThread::InitInstance() {
	// TODO: perform and per-thread initialization here
	return TRUE;
}
int CDemoChannelThread::ExitInstance() {
	// TODO: perform any per-thread cleanup here
	QThread::exit();
	return 0;
}
// CDemoChannelThread message handlers
UINT CDemoChannelThread::ThreadFunc(LPVOID lpParam) {
	const USHORT ICDT_THREAD_EXIT_CODE = 0x00;
	const USHORT ICDT_FOREVER = 1;
	const USHORT ICDT_TIME_INTERVAL_IN_MS = 250;
	LONGLONG currentTick = 0;
	LONGLONG previousTick = 0;
	USHORT tickCoverage = 0;
	//CInputCardDemoManager *pICDManager = new CInputCardDemoManager;
	/// @todo: Need to only create a demo queue when the CMM states that there is a demo queue required
	/// fo the time being test if slot 1 has a card fitted
	if (GlbDevCaps.GetSlotType(0) == BOARD_NOT_FITTED) {
		CPPQManager *pPPQManager = CPPQManager::GetHandle();
		// @todo: Only required if there are no cards in the system to use
		pPPQManager->Initialise(1, 0);
		CAnaloguePulseDemoChannel APDemo1;
		// Enable Demo Channels
		APDemo1.EnableAPDemoChannel(APDC_ANALOGUE, 0, APDC_SINE_WAVE, APDC_10HZ, 0, 0);
		currentTick = pGlbSysTimer->GetCurrentSystemTimeTick100();
		previousTick = currentTick;
		// Sync Pre Process Queues
		APDemo1.SynchAPDemoChannel(currentTick);
		LONGLONG minCoverage = 0;
		pPPQManager->GetMinSystemTickCoverage(minCoverage);
		while (ICDT_FOREVER) {
			currentTick = pGlbSysTimer->GetCurrentSystemTimeTick100();
			tickCoverage = static_cast<USHORT>(currentTick - previousTick);
			if (0 != tickCoverage) {
				APDemo1.PopulatePPQ(tickCoverage);
			}
			previousTick = currentTick;
			// currentTick += ICDT_SYSTEM_TICK_INTERVAL;
			sleep(ICDT_TIME_INTERVAL_IN_MS);
		} // End of WHILE
	}	// End of IF
	//delete( pICDManager );
	return (ICDT_THREAD_EXIT_CODE);
} // End of Member Function

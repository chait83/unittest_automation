﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "brightness_slider.h"
#include "confirmation_dialog.h"
#include "touch_dialog.h"
#include "sensor_comp_dialog.h"
#include "global.h"
#include "sample_rate_dialog.h"
#include "bypen_warning_dialog.h"
#include "output_popup.h"
#include "reset_all_dialog.h"
#include "digitalio_dialog.h"
#include "screen_template_type_selection.h"
#include "mv_dialog.h"
#include<qdebug.h>
//#include "mV_Conv.h"
#include "PenManager.h"
#include "maxmin_info_dialog.h"
#include <QProcess>
#include <QStringList>
#include "type.h"
#include <QBrush>
#include <QList>
#include "export_dialog.h"
#include "update_dialog.h"
#include "voltage_units.h"
#include "amps_dialog.h"
#include "voltsvalueselection.h"
#include "AIRanges.h"
#include "qwerty_keyboard.h"
#include "qwerty_keyboard_caps.h"
#include "alarm_status.h"
#include "alarm_type.h"
#include "dim_saver.h"
#include "saver_level.h"
#include "strip_fast.h"
#include "strip_med.h"
#include "strip_slow.h"
#include "circ_fast.h"
#include "circ_med.h"
#include "circ_slow.h"
#include "day_align.h"
#include "update_method.h"
#include "language.h"
#include "temp_unit.h"
#include "time_zone.h"
#include "hertz.h"
#include "user_level.h"
#include "no_pens.h"
#include "battery_reset.h"
#include "set_volume.h"
#include "update_sounds.h"
#include "cjc_calibration.h"
#include "resets.h"
#include "resets_layout.h"
#include "resets_data.h"
#include "reset_all.h"
#include "peers_setnumber.h"
#include "demo_traces.h"
#include "port.h"
#include "modbusprotocol.h"
#include "baudrate.h"
#include "byte_options.h"


extern T_LOGGINGINFO loaddata;
//extern T_LOGGING Pretrigger_status[V6_MAX_PENS];
extern void saveStructureToFile(const QString& filename, const T_LOGGINGINFO& data);
extern QString LOG_CONFIG_FILE;
extern QString LOG_INFO_FILE;

extern QString samp_rate;
//extern void saveStructureToFile_1(const QString& filename, QString data);
extern QString FILE_1;
extern ANALOG_IN save_data;
void saveStructureToFile_1(const QString& filename, ANALOG_IN& data);

extern "C"{
   // #include "mV_Conv.h"
    #include "v3_qt_spi.h"
    #include "AI_Queue.h"
    #include "qt_manager.h"
    #include "PPAIChannel.h"
    #include "sram.h"


}
extern void loadInfoStructureFromFile(const QString& filename, t_PEN *data[]);
extern void saveInfoStructureToFile(const QString& filename, t_PEN *data[]);
extern AIOCHINFO *AIOchinfo[49];
extern DIO_AR_CHINFO *DIOARchinfo[49];

extern sensor_type senType[8];



CPenManager *m_Instance = NULL;
CPenControl *m_pen = NULL;
extern long long AI_data_ch0;
extern long long AI_data_ch1;
extern long long AI_data_ch2;
extern long long AI_data_ch3;
extern long long AI_data_ch4;
extern long long AI_data_ch5;
extern long long AI_data_ch6;
extern long long AI_data_ch7;
extern uint8_t channel_executed;
extern uint8_t rx_pData[512];

/*extern long AI_ch0_TS;
extern long AI_ch1_TS;
extern long AI_ch2_TS;
extern long AI_ch3_TS;
extern long AI_ch4_TS;
extern long AI_ch5_TS;
extern long AI_ch6_TS;
extern long AI_ch7_TS;*/

/* AI channel block data newest reading */

int ai_channel_list[8];
//uint8_t range = 0x00;

extern int fd;
extern int sig_fd;
extern int LOG_LEVEL_1;
extern int LOG_LEVEL_2;
extern int verbose;
extern CARD_SLOT *slot_info[9];
extern Slot_Name *slot_name;
extern int counter[8];

extern int new_AI_data[8];

unsigned short vl_range[48]={0,};







int count = 0;
int ch_frq_count = 0;
int chart_speed = 10;
int gflag = 0;
int chan_config[8] = {20};
int Sample_rate = 20;
float time_rate_s = 0.02;

/*********************************/
//int GFLAG_CH[8] = {0,};
int GFLAG_CH[8]={0,0,0,0,0,0,0,0};
int s_rate[8]= {0,0,0,0,0,0,0,0};
int ch_freq_count = 0;

uint8_t ch_num = 0x00, num_of_ch = 0x00;
uint64_t n_time;
uint8_t gain_info;
uint8_t pair_info;


int AI_slot, slot_num;

uint8_t *data_ptr, error_code;
uint8_t ix = 0x00, temp = 0x00, ch_mask = 0x00;

int max_frq = 0, min_frq = 0;
int temp_s_rate[8] = {0,};
int channels = 0, c_num = 0;
long delay = 0;
int chavail_num = 0;
extern int d_acq_value;
int i=0;
int samplerate = 100;
int result=0;

static unsigned char cellText4 =0;
QBrush grayBrush(Qt::gray); // Create a gray brush
QString frequency_val[48];
QString range_val[48];
QString damp_val[4];
QString volt_val[49];
unsigned int frequency[48];
uint8_t range[48];
unsigned int damp[4];


/* milestone_4 */

static int AI_card=0;
static int AO_card=0;
static int DIO_card=0;
static int PI_card=0;
static int AR_card=0;
static int numDIOch=0;
unsigned int model6_ch;
unsigned int Pen_Selected;
unsigned int model9_ch;
unsigned int model11_ch;
unsigned int pen_num=100;
uint8_t p_status[8]={0};
//QString sensorcomp_type[8];
int ai_ch_no=100;
float single_point_values[8];
float Dual_point_values[8][4];


/*milestone 5*/
float pen_reading_value[97]={0,};
bool clickable = false;
bool reset_bypen =false;


int initial = 0;
int numAIChannel=0;
extern int resetCounter[9];
extern t_PEN *mt_PEN[MAX_PEN+1];
extern int flagPenEnabled[96];
int TotalPenCount=0;
int PenConfigFlag[97];
extern float prev_time[MAX_AI_CHANNEL+1];
extern float curr_time[MAX_AI_CHANNEL+1];
extern AI_Card_Info *AICardinfo[6];
extern AI_Channel_info *AIChannelinfo[MAX_AI_CHANNEL+1];
extern int *Q_ptr[MAX_CHANNEL+1];
extern int Front[MAX_CHANNEL+1];
extern int Rear[MAX_CHANNEL+1];
extern int channel_delay[MAX_AI_CHANNEL+1];
unsigned short chanType[49] = {0};
float milli_v_A[49] = {0};
/* Time for file */
time_t t = time(NULL);
struct tm tm;
/*   file logging    */
extern FILE *fptr_log[MAX_PEN+1];
extern long int count_ch0;
extern long int count_ch1;
int PenLogTimer=0;
int PenLogCounter =0;
int EnAcqFlag=0;
QStringList vrangtype = { "±1000mV","±500mV","±250mV","±100mV","±50mV","±25mV","±10mV","±5mV","±50V","±25V","±12V","±6V","±3V","±1.5V","±0.6V","±0.3V"};

QStringList sen_type = {"Volts","Amps","RT","TC"};
QStringList Sample_Rate = {"2Hz","5Hz","10Hz","50Hz"};
QStringList Sample_Rate_list = {"2Hz(500ms)","5Hz(200ms)","10Hz(100ms)","50Hz(20ms)"};

QStringList sensorcomp_type = {"None","Single Point","Dual Point","Multi Point"};
QStringList mVA = {" "," ","V","mV","mA"};
///////////

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);



    for(unsigned char j=0;j<48;j++)
    {
    frequency_val[j] = "2Hz(500ms)";
    //frequency[j] = 500;
    }
    for(unsigned char j=0;j<48;j++)
    {

    //range[j] = 0x54;
    range_val[j]=  "±100mV";
    }

    for(unsigned char j=0;j<4;j++)
    {
    damp[j] = 0;
    damp_val[j]=  "0.0";
    }
    for(unsigned char j=0;j<8;j++)
    {

    volt_val[j]= "Volts";
    }
    m_Instance = CPenManager::GetHandle();//$Amiya
    m_Instance->Initialise();

        ui->SELECT_PENS_DLG_BOTTOM_BAR_Add->setIcon(style()->standardIcon(QStyle::SP_DialogApplyButton));
        ui->SELECT_PENS_DLG_BOTTOM_BAR_Delete->setIcon(style()->standardIcon(QStyle::SP_DialogCloseButton));

        ui->SELECT_PENS_TABLE_BOTTOM_BAR_Add->setIcon(style()->standardIcon(QStyle::SP_DialogApplyButton));
        ui->SELECT_PENS_TABLE_BOTTOM_BAR_Finish->setIcon(style()->standardIcon(QStyle::SP_DialogCloseButton));
	
	
        /////////////////////////////////////////////////////min/max plot
        maxminwindow2 =new QWidget();
        maxminwindow2->setStyleSheet("background-color: rgb(255, 255, 255);"
                              );
        maxminwindow1 = new QWidget(maxminwindow2);
        maxminwindow1->setStyleSheet("background-color: rgb(255, 255, 255);"
                              );
        maxmingridLayout = new QGridLayout(maxminwindow1);
        maxmingridLayout->setSizeConstraint(QLayout::SetFixedSize);

        maxmingridLayout->setContentsMargins(1,1,1,1);
        maxmingridLayout->setMargin(0);

        maxmingridLayout->setSpacing(0);
        maxmingridLayout->setVerticalSpacing(0);
        maxmingridLayout->setHorizontalSpacing(0);
        ui->SELECT_PENS_TABLE_VERTICAL_LAYOUT->addWidget(maxminwindow2);


        //verticalLayout_75
        //





        //charts dpm
        plotwindow2 =new QWidget();
        plotwindow2->setStyleSheet("background-color: rgb(255, 255, 255);"
                             );
        plotwindow1 = new QWidget(plotwindow2);
        plotwindow1->setStyleSheet("background-color: rgb(255, 255, 255);"
                             );
        plotgridLayout = new QGridLayout(plotwindow1);
        plotgridLayout->setSizeConstraint(QLayout::SetFixedSize);

        plotgridLayout->setContentsMargins(1,1,1,1);
        plotgridLayout->setMargin(0);

        plotgridLayout->setSpacing(0);
        plotgridLayout->setVerticalSpacing(0);
        plotgridLayout->setHorizontalSpacing(0);
        ui->SELECT_PENS_DLG_VERTICAL_LAYOUT->addWidget(plotwindow2);


        ///////////////////////////////////////////////
        window2 = new QWidget();
        window2->setStyleSheet("background-color: rgb(255, 255, 255);"
                           );
        window1 = new QWidget(window2);
        window1->setStyleSheet("background-color: rgb(255, 255, 255);"
                           );
        gridLayout = new QGridLayout(window1);
        gridLayout->setSizeConstraint(QLayout::SetFixedSize);

        gridLayout->setContentsMargins(1,1,1,1);
        gridLayout->setMargin(0);

        gridLayout->setSpacing(0);
        gridLayout->setVerticalSpacing(0);
        gridLayout->setHorizontalSpacing(0);
        ui->verticalLayout_68->addWidget(window2);
        QDateTime currentdatetime = QDateTime::currentDateTime();
        QString dateTimeString = currentdatetime.toString("yyyy-MM-dd  hh:mm:ss");
        ui->label->setText("0001:Multitrend\n" + dateTimeString);
        ///////////////////////////////////////////////plot

        mPlot = new QCustomPlot;
        ui->verticalLayout_66->addWidget(mPlot);
        ui->stackedWidget_2->setCurrentIndex(1);
        if(screen_type == 1)
        {

        ui->stackedWidget_3->setCurrentIndex(0);
        }
        if(screen_type == 2)
        {

        ui->stackedWidget_3->setCurrentIndex(1);
        }

        if(screen_type == 3)
        {
        ui->stackedWidget_3->setCurrentIndex(2);
        }



        // ui->verticalLayout_29->addWidget(ui->horizontalWidget_11);

        //mPlot->xAxis->setPadding(500);
        //mPlot->xAxis->setVisible(true);
         mPlot->yAxis->setVisible(false);
         mPlot->yAxis->setTickLabels(false);
        connect(mPlot->yAxis2, SIGNAL(rangeChanged(QCPRange)), mPlot->yAxis, SLOT(setRange(QCPRange)));
        mPlot->yAxis2->setVisible(true);
        mPlot->yAxis2->setRange(0, 100);

        mPlot->yAxis2->setPadding(40);//added for chart for single axis

        //////////////////////////////////////////////

        QSize chartSize = mPlot->viewport().size();


                int width = chartSize.width();
                int height = chartSize.height();

                qDebug()<<"Widgth == "<<width<<"Height =="<<height;





        // create graphs:
        mGraph1 = mPlot->addGraph(mPlot->xAxis2, mPlot->yAxis2);
        mGraph2 = mPlot->addGraph(mPlot->xAxis2, mPlot->yAxis2);
        mGraph3 = mPlot->addGraph(mPlot->xAxis2, mPlot->yAxis2);
        mGraph4 = mPlot->addGraph(mPlot->xAxis2, mPlot->yAxis2);
        mGraph5 = mPlot->addGraph(mPlot->xAxis2, mPlot->yAxis2);
        mGraph6 = mPlot->addGraph(mPlot->xAxis2, mPlot->yAxis2);
        mGraph7 = mPlot->addGraph(mPlot->xAxis2, mPlot->yAxis2);
        mGraph8 = mPlot->addGraph(mPlot->xAxis2, mPlot->yAxis2);


        mTag1 = new AxisTag(mGraph1->valueAxis());
        //mTag1->setPen(mGraph1->pen());
        mTag2 = new AxisTag(mGraph2->valueAxis());
//        mTag2->setPen(mGraph2->pen());
        mTag3 = new AxisTag(mGraph3->valueAxis());
//        mTag3->setPen(mGraph3->pen());
        mTag4 = new AxisTag(mGraph4->valueAxis());
//        mTag4->setPen(mGraph4->pen());
        mTag5 = new AxisTag(mGraph5->valueAxis());
//        mTag5->setPen(mGraph5->pen());
        mTag6 = new AxisTag(mGraph6->valueAxis());
//        mTag6->setPen(mGraph6->pen());
        mTag7 = new AxisTag(mGraph7->valueAxis());
//        mTag7->setPen(mGraph7->pen());
        mTag8 = new AxisTag(mGraph8->valueAxis());
//        mTag8->setPen(mGraph8->pen());

        /////////////////////////////////////////dpms with selected pens
        //add frame
        Frame = new QFrame;
        Frame->setFrameShape(QFrame::Box);
        //Horizontal layout
        HLayout = new QHBoxLayout(Frame);
        for (int p = 0; p < 50; ++p)
        {
           pen_names.append("Pen "+QString :: number(p)) ;
        }

        HLayout->setContentsMargins(0,0,0,0);
        HLayout->setSpacing(0);
        Frame->setLayout(HLayout);
        Frame->setStyleSheet("border : 1px solid black;background-color:white");
        Frame->setMaximumSize(QSize(16777215, 40));

        ui->verticalLayout_66->addWidget(Frame);

        ///////////////////////////////////////////////////
//        //QBrush b =mTag1->brush();
//        QColor c = b.color();

//        qDebug()<<"color="<<c;
//        QVariant variant= c;
//        QString colcode = variant.toString();
//        qDebug()<<"colorcolcode="<<colcode;
///////////////////////////////////////////pen table




        model = new QStandardItemModel(8,2,this);
        ui->tableView->setModel(model);

        ui->tableView->setColumnWidth(0,250);
        ui->tableView->setColumnWidth(1,400);
        ui->tableView->horizontalHeader()->hide();
        ui->tableView->verticalHeader()->hide();
        ui->tableView->setStyleSheet(
                                         "QTableView::item{"
                                         "border: 1px solid black;"
                                         "border-radius: 5px;"
                                         "background-color: rgb(255, 255, 127);"
                                         "color: black;"
                                         "}"
                                         );


         for(int row = 0; row < 8; row++)
         {
             ui->tableView->setRowHeight(row,40);
             {
                 QModelIndex index = model->index(row,0,QModelIndex());
                 QString text= QString("Pen ");
                 text.append(QString("%1 ").arg(row));
                 model->setData(index,text);


                 QModelIndex index1 = model->index(row,1,QModelIndex());
                 // 0 for all data
                 //QString text1= QString("Pen , 0.00 to 100.00 %");
                 QString text1= QString("Pen ");
                 text1.append(QString("%1 ").arg(row));
                 QString text2= QString(", 0.00 to 100.00 %");
                 text1.append(QString("%1 ").arg(text2));
                 model->setData(index1,text1);

             }
         }

         model1 = new QStandardItemModel(13,2,this);
         ui->tableView_2->setModel(model1);
         ui->tableView_2->setColumnWidth(0,250);
         ui->tableView_2->setColumnWidth(1,400);
         ui->tableView_2->setStyleSheet(
                                          "QTableView::item{"
                                          "border: 1px solid black;"
                                          "border-radius: 5px;"
                                          "background-color: rgb(255, 255, 127);"
                                          "color: black;"
                                          "}"
                                          );
             // Generate data
             for(int row = 0; row < 13; row++)
             {

                 ui->tableView_2->setRowHeight(row,40);

                 {
                     QModelIndex index = model1->index(row,0,QModelIndex());
                     QStandardItem *my_item = model1->itemFromIndex(index);
                     my_item->setBackground(Qt::yellow);
                     // 0 for all data
                     if(row == 0)
                     {
                     QString text= QString("Enabled");
                     model1->setData(index,text);
                     }
                     else if(row == 1)
                     {
                     QString text= QString("Tag");
                     //text.append(QString("%1 ").arg(row));
                     model1->setData(index,text);
                     }
                     else if(row == 2)
                     {
                     QString text= QString("Description");
                     //text.append(QString("%1 ").arg(row));
                     model1->setData(index,text);
                     }
                     else if(row == 3)
                     {
                     QString text= QString("Maths Type ");
                     //text.append(QString("%1 ").arg(row));
                     model1->setData(index,text);
                     }
                     else if(row == 4)
                     {
                     QString text= QString("Edit Math ");
                     //text.append(QString("%1 ").arg(row));
                     model1->setData(index,text);
                     }
                     else if(row == 5)
                     {
                     QString text= QString("Scale ");
                     //text.append(QString("%1 ").arg(row));
                     model1->setData(index,text);
                     }
                     else if(row == 6)
                     {
                     QString text= QString("Logging ");
                     //text.append(QString("%1 ").arg(row));
                     model1->setData(index,text);
                     }
                     else if(row == 7)
                     {
                     QString text= QString("Alarms ");
                     //text.append(QString("%1 ").arg(row));
                     model1->setData(index,text);
                     }
                     else if(row == 8)
                     {
                     QString text= QString("Totaliser ");
                     //text.append(QString("%1 ").arg(row));
                     model1->setData(index,text);
                     }
                     else if(row == 9)
                     {
                     QString text= QString("Rav ");
                     //text.append(QString("%1 ").arg(index));
                     model1->setData(index,text);
                     }
                     else if(row == 10)
                     {
                     QString text= QString("Group ");
                     //text.append(QString("%1 ").arg(row));
                     model1->setData(index,text);
                     }
                     else if(row == 11)
                     {
                     QString text= QString("Colour ");
                     //text.append(QString("%1 ").arg(row));
                     model1->setData(index,text);
                     }
                     else if(row == 12)
                     {
                     QString text= QString("Trace Width ");
                     //text.append(QString("%1 ").arg(row));
                     model1->setData(index,text);
                     }

                 }

                 {
                     QModelIndex index = model1->index(row,1,QModelIndex());
                     QStandardItem *my_item = model1->itemFromIndex(index);
                     my_item->setBackground(Qt::yellow);
                     // 0 for all data
                     if(row == 0)
                     {
                     QString text= QString(" Enabled ");
                     //text.append(QString("%1 ").arg(row));
                     model1->setData(index,text);
                     }
                     else if(row == 1)
                     {

                     QString text= QString("Pen");
                     //text.append(QString("%1 ").arg(row));
                     model1->setData(index,text);
                     }
                     else if(row == 2)
                     {
                     QString text= QString("Description ");
                     //text.append(QString("%1 ").arg(row));
                     model1->setData(index,text);
                     }
                     else if(row == 3)
                     {
                     QString text= QString("Basic Math ");
                     //text.append(QString("%1 ").arg(row));
                     model1->setData(index,text);
                     }
                     else if(row == 4)
                     {

                         QString text= QString("A ");
                         //text.append(QString("%1 ").arg(row));
                         model1->setData(index,text);
//                         QStandardItem *my_item21 = model1->itemFromIndex(index);
//                         my_item21->setFlags(Qt::ItemIsEditable);
//                         my_item21->setEditable(true);

                     }
                     else if(row == 5)
                     {
                     QString text= QString("0.0 to 100.0 % ");
                     //text.append(QString("%1 ").arg(row));
                     model1->setData(index,text);
                     }
                     else if(row == 6)
                     {
                     QString text= QString("ENABLED");
                     //text.append(QString("%1 ").arg(row));
                     model1->setData(index,text);
                     }
                     else if(row == 7)
                     {
                     QString text= QString("None ");
                     //text.append(QString("%1 ").arg(row));
                     model1->setData(index,text);
                     }
                     else if(row == 8)
                     {
                     QString text= QString(" . ");
                     //text.append(QString("%1 ").arg(row));
                     model1->setData(index,text);
                     }
                     else if(row == 9)
                     {
                     QString text= QString(" . ");
                     //text.append(QString("%1 ").arg(index));
                     model1->setData(index,text);
                     }
                     else if(row == 10)
                     {
                     QString text= QString("No Group ");
                     //text.append(QString("%1 ").arg(row));
                     model1->setData(index,text);
                     }
                     else if(row == 11)
                     {
                     QString text= QString(" . ");
                     //text.append(QString("%1 ").arg(row));
                     model1->setData(index,text);
                     }
                     else if(row == 12)
                     {
                     QString text= QString("1 ");
                     //text.append(QString("%1 ").arg(row));
                     model1->setData(index,text);
                     }

                 }




                 model2 = new QStandardItemModel(2,2,this);
                 ui->tableView_3->setModel(model2);

                 ui->tableView_3->setColumnWidth(0,250);
                 ui->tableView_3->setColumnWidth(1,400);
                 ui->tableView_3->horizontalHeader()->hide();
                 ui->tableView_3->verticalHeader()->hide();
                 ui->tableView_3->setStyleSheet(
                                                  "QTableView::item{"
                                                  "border: 1px solid black;"
                                                  "border-radius: 5px;"
                                                  "background-color: rgb(255, 255, 127);"
                                                  "color: black;"
                                                  "}"
                                                  );


                  for(int row = 0; row < 2; row++)
                  {
                      ui->tableView_3->setRowHeight(row,40);
                      //for(int col = 0; col < 2; col++)
                      {
                          QModelIndex index = model2->index(row,0,QModelIndex());
                          QStandardItem *my_item1 = model2->itemFromIndex(index);
                          my_item1->setBackground(Qt::yellow);
                          // 0 for all data
                          if(row == 0)
                          {
                          QString text1= QString("Pre-Trigger Time ");
                          //text.append(QString("%1 ").arg(row));
                          model2->setData(index,text1);
                          }
                          if(row == 1)
                          {
                          QString text1= QString("Post-Trigger Time ");
                          //text.append(QString("%1 ").arg(row));
                          model2->setData(index,text1);
                          }


                      }
                      {
                          QModelIndex index = model2->index(row,1,QModelIndex());
                          QStandardItem *my_item1 = model2->itemFromIndex(index);
                          my_item1->setBackground(Qt::yellow);
                          // 0 for all data
                          if(row == 0)
                          {
                          QString PretriggerTime = QString::number(loaddata.PretriggerTime);
                          QString text1= QString("%1 mins").arg(PretriggerTime);
                          //text.append(QString("%1 ").arg(row));
                          model2->setData(index,text1);
                          }
                          else if(row == 1)
                          {
                          QString PostTriggerTime = QString::number(loaddata.PostTriggerTime);
                          QString text1= QString("%1 Secs").arg(PostTriggerTime);
                          //text.append(QString("%1 ").arg(row));model1
                          model2->setData(index,text1);
                          }
                  }
                  }




                  model3 = new QStandardItemModel(8,2,this);
                  ui->tableView_4->setModel(model3);

                  ui->tableView_4->setColumnWidth(0,250);
                  ui->tableView_4->setColumnWidth(1,400);
                  ui->tableView_4->horizontalHeader()->hide();
                  ui->tableView_4->verticalHeader()->hide();
                  ui->tableView_4->setStyleSheet(
                                                   "QTableView::item{"
                                                   "border: 1px solid black;"
                                                   "border-radius: 5px;"
                                                   "background-color: rgb(255, 255, 127);"
                                                   "color: black;"
                                                   "}"
                                                   );


                  for(int row = 0; row <8; row++)
                  {
                      ui->tableView_4->setRowHeight(row,40);

                      //for(int col = 0; col < 2; col++)
                      {
                          QModelIndex index = model3->index(row,0,QModelIndex());
                          QStandardItem *my_item3 = model3->itemFromIndex(index);
                          my_item3->setBackground(Qt::yellow);
                          // 0 for all data
                          if(row == 0)
                          {
                          QString text= QString("Enabled ");
                          //text.append(QString("%1 ").arg(row));
                          model3->setData(index,text);
                          }
                          else if(row == 1)
                          {
                          QString text= QString("Type ");
                          //text.append(QString("%1 ").arg(row));
                          model3->setData(index,text);
                          }
                          else if(row == 2)
                          {
                          QString text= QString("Rate Units ");
                          //text.append(QString("%1 ").arg(row));
                          model3->setData(index,text);
                          }
                          else if(row == 3)
                          {
                          QString text= QString("Rate ");
                          //text.append(QString("%1 ").arg(row));
                          model3->setData(index,text);
                          }
                          else if(row == 4)
                          {
                          QString text= QString("Auto Fit ");
                          //text.append(QString("%1 ").arg(row));
                          model3->setData(index,text);
                          }
                          else if(row == 5)
                          {
                          QString text= QString("Band 1% ");
                          //text.append(QString("%1 ").arg(row));
                          model3->setData(index,text);
                          }
                          else if(row == 6)
                          {
                          QString text= QString("Fuzzy Band 2 ");
                          //text.append(QString("%1 ").arg(row));
                          model3->setData(index,text);
                          }
                          else if(row == 7)
                          {
                          QString text= QString("Band 2% ");
                          //text.append(QString("%1 ").arg(row));
                          model3->setData(index,text);
                          }

                      }

                      {
                          QModelIndex index = model3->index(row,1,QModelIndex());
                          QStandardItem *my_item3 = model3->itemFromIndex(index);
                          my_item3->setBackground(Qt::yellow);
                          // 0 for all data
                          if(row == 0)
                          {
                          QString text= QString("DISABLED");
                          //text.append(QString("%1 ").arg(row));
                          model3->setData(index,text);
                          }
                          else if(row == 1)
                          {

                          QString text= QString("Fuzzy");
                          //text.append(QString("%1 ").arg(row));
                          model3->setData(index,text);
                          }
                          else if(row == 2)
                          {
                          QString text= QString("Seconds ");
                          //text.append(QString("%1 ").arg(row));
                          model3->setData(index,text);
                          }
                          else if(row == 3)
                          {
                          QString text= QString("10 Sec ");
                          //text.append(QString("%1 ").arg(row));
                          model3->setData(index,text);
                          }
                          else if(row == 4)
                          {
                          QString text= QString(" . ");
                          //text.append(QString("%1 ").arg(row));
                          model3->setData(index,text);
                          }
                          else if(row == 5)
                          {
                          QString text= QString("0.5");
                          //text.append(QString("%1 ").arg(row));
                          model3->setData(index,text);
                          }
                          else if(row == 6)
                          {
                          QString text= QString(" . ");
                          //text.append(QString("%1 ").arg(row));
                          model3->setData(index,text);
                          }
                          else if(row == 7)
                          {
                          QString text= QString("0.1");
                          //text.append(QString("%1 ").arg(row));
                          model3->setData(index,text);
                          }

                      }
                  }



                  model4 = new QStandardItemModel(9,2,this);
                  ui->tableView_5->setModel(model4);

                  ui->tableView_5->setColumnWidth(0,250);
                  ui->tableView_5->setColumnWidth(1,400);
                  ui->tableView_5->horizontalHeader()->hide();
                  ui->tableView_5->verticalHeader()->hide();
                  ui->tableView_5->setStyleSheet(
                                                   "QTableView::item{"
                                                   "border: 1px solid black;"
                                                   "border-radius: 5px;"
                                                   "background-color: rgb(255, 255, 127);"
                                                   "color: black;"
                                                   "}"
                                                   );


                  for(int row = 0; row <9; row++)
                  {
                      ui->tableView_5->setRowHeight(row,40);
                      //for(int col = 0; col < 2; col++)
                      {
                          QModelIndex index = model4->index(row,0,QModelIndex());
                          QStandardItem *my_item4 = model4->itemFromIndex(index);
                          my_item4->setBackground(Qt::yellow);
                          // 0 for all data
                          if(row == 0)
                          {
                          QString text= QString("Enabled ");
                          //text.append(QString("%1 ").arg(row));
                          model4->setData(index,text);
                          }
                          else if(row == 1)
                          {
                          QString text= QString("Type ");
                          //text.append(QString("%1 ").arg(row));
                          model4->setData(index,text);
                          }
                          else if(row == 2)
                          {
                          QString text= QString("Rate Units ");
                          //text.append(QString("%1 ").arg(row));
                          model4->setData(index,text);
                          }
                          else if(row == 3)
                          {
                          QString text= QString("Rate ");
                          //text.append(QString("%1 ").arg(row));
                          model4->setData(index,text);
                          }
                          else if(row == 4)
                          {
                          QString text= QString("Alarm Rate Units ");
                          //text.append(QString("%1 ").arg(row));
                          model4->setData(index,text);
                          }
                          else if(row == 5)
                          {
                          QString text= QString("Alarm Rate");
                          //text.append(QString("%1 ").arg(row));
                          model4->setData(index,text);
                          }
                          else if(row == 6)
                          {
                          QString text= QString("Pre-Trigger ");
                          //text.append(QString("%1 ").arg(row));
                          model4->setData(index,text);
                          }
                          else if(row == 7)
                          {
                          QString text= QString("Method ");
                          //text.append(QString("%1 ").arg(row));
                          model4->setData(index,text);
                          }
                          else if(row == 8)
                          {
                          QString text= QString("Align ");
                          //text.append(QString("%1 ").arg(row));
                          model4->setData(index,text);
                          }

                      }

                      {
                          QModelIndex index = model4->index(row,1,QModelIndex());
                          QStandardItem *my_item4 = model4->itemFromIndex(index);
                          my_item4->setBackground(Qt::yellow);
                          // 0 for all data
                          if(row == 0)
                          {
                          QString text= QString("DISABLED");
                          //text.append(QString("%1 ").arg(row));
                          model4->setData(index,text);
                          }
                          else if(row == 1)
                          {

                          QString text= QString("Continuous");
                          //text.append(QString("%1 ").arg(row));
                          model4->setData(index,text);
                          }
                          else if(row == 2)
                          {
                          QString text= QString("Seconds ");
                          //text.append(QString("%1 ").arg(row));
                          model4->setData(index,text);
                          }
                          else if(row == 3)
                          {
                          QString text= QString("10 Sec ");
                          //text.append(QString("%1 ").arg(row));
                          model4->setData(index,text);
                          }
                          else if(row == 4)
                          {
                          QString text= QString("Milliseconds ");
                          //text.append(QString("%1 ").arg(row));
                          model4->setData(index,text);
                          }
                          else if(row == 5)
                          {
                          QString text= QString("500ms(2Hz)");
                          //text.append(QString("%1 ").arg(row));
                          model4->setData(index,text);
                          }
                          else if(row == 6)
                          {
                          QString text= QString("DISABLED");
                          //text.append(QString("%1 ").arg(row));
                          model4->setData(index,text);
                          }
                          else if(row == 7)
                          {
                          QString text= QString("Sample");
                          //text.append(QString("%1 ").arg(row));
                          model4->setData(index,text);
                          }
                          else if(row == 8)
                          {
                          QString text= QString("None");
                          //text.append(QString("%1 ").arg(row));
                          model4->setData(index,text);
                          }

                      }
                  }

               //////////////////////////////////////////analog in
                  model5= new QStandardItemModel(8,2,this);
                   ui->tableView_6->setModel(model5);
                   ui->tableView_6->setColumnWidth(0,250);
                   ui->tableView_6->setColumnWidth(1,400);
                   ui->tableView_6->setStyleSheet(
                                                    "QTableView::item{"
                                                    "border: 1px solid black;"
                                                    "border-radius: 5px;"
                                                    "background-color: rgb(255, 255, 127);"
                                                    "color: black;"
                                                    "}"
                                                    );
                   //ui->tableView_6->setStyleSheet("QTableView{image: url(/home/pi/Desktop/Paperless_Recorder_gui/table_colour.jpg);background-color: rgb(251, 255, 207);}");
                       // Generate data
                       for(int row = 0; row < 9; row++)
                       {
                           ui->tableView_6->setRowHeight(row,40);
                           //for(int col = 0; col < 2; col++)
                           {
                               QModelIndex index = model5->index(row,0,QModelIndex());
                               // 0 for all data
                               QString text= QString("Analog In ");
                               text.append(QString("%1 ").arg(row));
                               model5->setData(index,text);

                               QModelIndex index1 = model5->index(row,1,QModelIndex());
                               // 0 for all data
                               //QString text1= QString("A, Volts(+-12V)");
                               QString text1= QString("A");
                               text1.append(QString("%1 ").arg(row));
                               QString text2= QString(", Volts(+-12V)");
                               text1.append(QString("%1 ").arg(text2));
                               model5->setData(index1,text1);

                           }
                       }



                       model6 = new QStandardItemModel(13,2,this);
                       ui->tableView_7->setModel(model6);
                       ui->tableView_7->setColumnWidth(0,250);
                       ui->tableView_7->setColumnWidth(1,400);
                       ui->tableView_7->setStyleSheet(
                                                        "QTableView::item{"
                                                        "border: 1px solid black;"
                                                        "border-radius: 5px;"
                                                        "background-color: rgb(255, 255, 127);"
                                                        "color: black;"
                                                        "}"
                                                        );
                       //ui->tableView_7->setStyleSheet("QTableView{image: url(/home/pi/Desktop/Paperless_Recorder_gui/table_colour.jpg);background-color: rgb(251, 255, 207);}");
                           // Generate data
                           for(int row = 0; row < 17; row++)
                           {
                               ui->tableView_7->setRowHeight(row,40);
                               //for(int col = 0; col < 2; col++)
                               {
                                   QModelIndex index = model6->index(row,0,QModelIndex());
                                   // 0 for all data
                                   if(row == 0)
                                   {
                                   QString text= QString("Enabel");
                                   //text.append(QString("%1 ").arg(row));
                                   model6->setData(index,text);
                                   }
                                   else if(row == 1)
                                   {
                                   QString text= QString("Type");
                                   //text.append(QString("%1 ").arg(row));
                                   model6->setData(index,text);
                                   }
                                   else if(row == 2)
                                   {
                                   QString text= QString("Sample Rate");
                                   //text.append(QString("%1 ").arg(row));
                                   model6->setData(index,text);
                                   }
                                   else if(row == 3)
                                   {
                                   QString text= QString("Range");
                                   //text.append(QString("%1 ").arg(row));
                                   model6->setData(index,text);
                                   }
                                   else if(row == 4)
                                   {
                                   QString text= QString("Range Type");
                                   //text.append(QString("%1 ").arg(row));
                                   model6->setData(index,text);
                                   }
                                   else if(row == 5)
                                   {
                                   QString text= QString("Damp Level");
                                   //text.append(QString("%1 ").arg(row));
                                   model6->setData(index,text);
                                   }
                                   else if(row == 6)
                                   {
                                   QString text= QString("Linearisation Table");
                                   //text.append(QString("%1 ").arg(row));
                                   model6->setData(index,text);
                                   }
                                   else if(row == 7)
                                   {
                                   QString text= QString("Use pen scale");
                                   //text.append(QString("%1 ").arg(row));
                                   model6->setData(index,text);
                                   }
                                   else if(row == 8)
                                   {
                                   QString text= QString("Units");
                                   //text.append(QString("%1 ").arg(row));
                                   model6->setData(index,text);
                                   }
                                   else if(row == 9)
                                   {
                                   QString text= QString("Label");
                                   //text.append(QString("%1 ").arg(index));
                                   model6->setData(index,text);
                                   }
                                   else if(row == 10)
                                   {
                                   QString text= QString("SQRT Extract");
                                   //text.append(QString("%1 ").arg(row));
                                   model6->setData(index,text);
                                   }
                                   else if(row == 11)
                                   {
                                   QString text= QString("Sensor Comp.");
                                   //text.append(QString("%1 ").arg(row));
                                   model6->setData(index,text);
                                   }
                                   else if(row == 12)
                                   {
                                   QString text= QString("Demo Setup");
                                   //text.append(QString("%1 ").arg(row));
                                   model6->setData(index,text);
                                   }

                               }

                               {
                                   QModelIndex index = model6->index(row,1,QModelIndex());
                                   // 0 for all data
                                   if(row == 0)
                                   {
                                   QString text= QString(" . ");
                                   //text.append(QString("%1 ").arg(row));
                                   model6->setData(index,text);
                                   }
                                   else if(row == 1)
                                   {
                                   QString text= QString("Volts");
                                   //text.append(QString("%1 ").arg(row));
                                   model6->setData(index,text);
                                   }
                                   else if(row == 2)
                                   {
                                   QString text= QString("2Hz(500ms) ");
                                   //text.append(QString("%1 ").arg(row));
                                   model6->setData(index,text);
                                   }
                                   else if(row == 3)
                                   {
                                   QString text= QString("Preset");
                                   //text.append(QString("%1 ").arg(row));
                                   model6->setData(index,text);
                                   }
                                   else if(row == 4)
                                   {
                                   QString text= QString("(+/-)12V ");
                                   //text.append(QString("%1 ").arg(row));
                                   model6->setData(index,text);
                                   }
                                   else if(row == 5)
                                   {
                                   QString text= QString("0.0 ");
                                   //text.append(QString("%1 ").arg(row));
                                   model6->setData(index,text);
                                   }
                                   else if(row == 6)
                                   {
                                   QString text= QString("No Tables ");
                                   //text.append(QString("%1 ").arg(row));
                                   model6->setData(index,text);
                                   }
                                   else if(row == 7)
                                   {
                                   QString text= QString("3");
                                   //text.append(QString("%1 ").arg(row));
                                   model6->setData(index,text);
                                   }
                                   else if(row == 8)
                                   {
                                   QString text= QString("%");
                                   //text.append(QString("%1 ").arg(row));
                                   model6->setData(index,text);
                                   }
                                   else if(row == 9)
                                   {
                                   QString text= QString("A1");
                                   //text.append(QString("%1 ").arg(index));
                                   model6->setData(index,text);
                                   }
                                   else if(row == 10)
                                   {
                                   QString text= QString(" Off ");
                                   //text.append(QString("%1 ").arg(row));
                                   model6->setData(index,text);
                                   }
                                   else if(row == 11)
                                   {
                                   QString text= QString("None");
                                   //text.append(QString("%1 ").arg(row));
                                   model6->setData(index,text);
                                   }
                                   else if(row == 12)
                                   {
                                   QString text= QString("200Secs. Drift ");
                                   //text.append(QString("%1 ").arg(row));
                                   model6->setData(index,text);
                                   }

                               }
                           }





                           model7 = new QStandardItemModel(2,2,this);
                           ui->tableView_15->setModel(model7);

                           ui->tableView_15->setColumnWidth(0,250);
                           ui->tableView_15->setColumnWidth(1,400);
                           ui->tableView_15->horizontalHeader()->hide();
                           ui->tableView_15->verticalHeader()->hide();
                           ui->tableView_15->setStyleSheet(
                                                            "QTableView::item{"
                                                            "border: 1px solid black;"
                                                            "border-radius: 5px;"
                                                            "background-color: rgb(255, 255, 127);"
                                                            //"color: black;"
                                                            "}"
                                                            );

                            for(int row = 0; row < 2; row++)
                            {
                                ui->tableView_15->setRowHeight(row,40);
                                //for(int col = 0; col < 2; col++)
                                {
                                    QModelIndex index = model7->index(row,0,QModelIndex());
                                    // 0 for all data
                                    if(row == 0)
                                    {
                                    QString text1= QString("Comp Type ");
                                    //text.append(QString("%1 ").arg(row));
                                    model7->setData(index,text1);
                                    }
                                    else if(row == 1)
                                    {

                                    QString text1= QString("Eng Offset ");
                                    //text.append(QString("%1 ").arg(row));
                                    model7->setData(index,text1);
                                    QStandardItem *my_item = model7->itemFromIndex(index);
                                    my_item->setFlags(0);
                                    }

                                }
                                {
                                    QModelIndex index = model7->index(row,1,QModelIndex());
                                    // 0 for all data
                                    if(row == 0)
                                    {
                                    QString text1= QString("None");
                                    //text.append(QString("%1 ").arg(row));
                                    model7->setData(index,text1);
                                    }
                                    else if(row == 1)
                                    {

                                    QString text1= QString("10.0 ");
                                    //text.append(QString("%1 ").arg(row));
                                    model7->setData(index,text1);
                                    QStandardItem *my_item = model7->itemFromIndex(index);
                                    my_item->setBackground(Qt::blue);
                                    my_item->setFlags(0);
                                    }
                            }
                            }


                            model20 = new QStandardItemModel(15,2,this);
                            ui->EDIT_SETUP_FIELDIO_ANALOGIN_INDEX_1_Tableview->setModel(model20);
                            ui->EDIT_SETUP_FIELDIO_ANALOGIN_INDEX_1_Tableview->setColumnWidth(0,250);
                            ui->EDIT_SETUP_FIELDIO_ANALOGIN_INDEX_1_Tableview->setColumnWidth(1,400);
                            ui->EDIT_SETUP_FIELDIO_ANALOGIN_INDEX_1_Tableview->setStyleSheet(
                                                             "QTableView::item{"
                                                            "border-radius: 5px;"
                                                             "border: 1px solid black;"
                                                             "background-color: rgb(255, 255, 127);"
                                                             "color: black;"
                                                             "}"
                                                             );
                            //ui->EDIT_SETUP_FIELDIO_ANALOGIN_INDEX_1_Tableview->setStyleSheet("QTableView{image: url(/home/pi/Desktop/Paperless_Recorder_gui/table_colour.jpg);background-color: rgb(251, 255, 207);}");
                                // Generate data
                                for(int row = 0; row < 15; row++)
                                {
                                    ui->EDIT_SETUP_FIELDIO_ANALOGIN_INDEX_1_Tableview->setRowHeight(row,40);
                                    //for(int col = 0; col < 2; col++)
                                    {
                                        QModelIndex index = model20->index(row,0,QModelIndex());
                                        // 0 for all data
                                        if(row == 0)
                                        {
                                        QString text= QString("Enabel");
                                        //text.append(QString("%1 ").arg(row));
                                        model20->setData(index,text);
                                        }
                                        else if(row == 1)
                                        {
                                        QString text= QString("Type");
                                        //text.append(QString("%1 ").arg(row));
                                        model20->setData(index,text);
                                        }
                                        else if(row == 2)
                                        {
                                        QString text= QString("Sample Rate");
                                        //text.append(QString("%1 ").arg(row));
                                        model20->setData(index,text);
                                        }
                                        else if(row == 3)
                                        {
                                        QString text= QString("Range");
                                        //text.append(QString("%1 ").arg(row));
                                        model20->setData(index,text);
                                        }
                                        else if(row == 4)
                                        {
                                        QString text= QString("Voltage Units");
                                        //text.append(QString("%1 ").arg(row));
                                        model20->setData(index,text);
                                        }
                                        else if(row == 5)
                                        {
                                        QString text= QString("High Limit");
                                        //text.append(QString("%1 ").arg(row));
                                        model20->setData(index,text);
                                        }
                                        else if(row == 6)
                                        {
                                        QString text= QString("Lower Limit");
                                        //text.append(QString("%1 ").arg(row));
                                        model20->setData(index,text);
                                        }
                                        else if(row == 7)
                                        {
                                        QString text= QString("Damp Level");
                                        //text.append(QString("%1 ").arg(row));
                                        model20->setData(index,text);
                                        }
                                        else if(row == 8)
                                        {
                                        QString text= QString("Linearisation Table");
                                        //text.append(QString("%1 ").arg(row));
                                        model20->setData(index,text);
                                        }
                                        else if(row == 9)
                                        {
                                        QString text= QString("Use pen scale");
                                        //text.append(QString("%1 ").arg(row));
                                        model20->setData(index,text);
                                        }
                                        else if(row == 10)
                                        {
                                        QString text= QString("Units");
                                        //text.append(QString("%1 ").arg(row));
                                        model20->setData(index,text);
                                        }
                                        else if(row ==11)
                                        {
                                        QString text= QString("Label");
                                        //text.append(QString("%1 ").arg(index));
                                        model20->setData(index,text);
                                        }
                                        else if(row == 12)
                                        {
                                        QString text= QString("SQRT Extract");
                                        //text.append(QString("%1 ").arg(row));
                                        model20->setData(index,text);
                                        }
                                        else if(row == 13)
                                        {
                                        QString text= QString("Sensor Comp.");
                                        //text.append(QString("%1 ").arg(row));
                                        model20->setData(index,text);
                                        }
                                        else if(row == 14)
                                        {
                                        QString text= QString("Demo Setup");
                                        //text.append(QString("%1 ").arg(row));
                                        model20->setData(index,text);
                                        }

                                    }

                                    {
                                        QModelIndex index = model20->index(row,1,QModelIndex());
                                        // 0 for all data
                                        if(row == 0)
                                        {
                                        QString text= QString(" . ");
                                        //text.append(QString("%1 ").arg(row));
                                        model20->setData(index,text);
                                        }
                                        else if(row == 1)
                                        {
                                        QString text= QString("Volts");
                                        //text.append(QString("%1 ").arg(row));
                                        model20->setData(index,text);
                                        }
                                        else if(row == 2)
                                        {
                                        QString text= QString("2Hz(500ms) ");
                                        //text.append(QString("%1 ").arg(row));
                                        model20->setData(index,text);
                                        }
                                        else if(row == 3)
                                        {
                                        QString text= QString("User Defined");
                                        //text.append(QString("%1 ").arg(row));
                                        model20->setData(index,text);
                                        }
                                        else if(row == 4)
                                        {
                                        QString text= QString("V");
                                        //text.append(QString("%1 ").arg(row));
                                        model20->setData(index,text);
                                        }
                                        else if(row == 5)
                                        {
                                        QString text= QString("1.0 ");
                                        //text.append(QString("%1 ").arg(row));
                                        model20->setData(index,text);
                                        }
                                        else if(row == 6)
                                        {
                                        QString text= QString("0.0");
                                        //text.append(QString("%1 ").arg(row));
                                        model20->setData(index,text);
                                        }
                                        else if(row == 7)
                                        {
                                        QString text= QString("0.0");
                                        //text.append(QString("%1 ").arg(row));
                                        model20->setData(index,text);
                                        }
                                        else if(row == 8)
                                        {
                                        QString text= QString("No Tables");
                                        //text.append(QString("%1 ").arg(row));
                                        model20->setData(index,text);
                                        }
                                        else if(row == 9)
                                        {
                                        QString text= QString("1");
                                        //text.append(QString("%1 ").arg(index));
                                        model20->setData(index,text);
                                        }
                                        else if(row == 10)
                                        {
                                        QString text= QString("% ");
                                        //text.append(QString("%1 ").arg(row));
                                        model20->setData(index,text);
                                        }
                                        else if(row == 11)
                                        {
                                        QString text= QString("A1");
                                        //text.append(QString("%1 ").arg(row));
                                        model20->setData(index,text);
                                        }
                                        else if(row == 12)
                                        {
                                        QString text= QString("Off ");
                                        //text.append(QString("%1 ").arg(row));
                                        model20->setData(index,text);
                                        }
                                        else if(row == 13)
                                        {
                                        QString text= QString("None ");
                                        //text.append(QString("%1 ").arg(row));
                                        model20->setData(index,text);
                                        }
                                        else if(row == 14)
                                        {
                                        QString text= QString("200 Secs. Drift ");
                                        //text.append(QString("%1 ").arg(row));
                                        model20->setData(index,text);
                                        }

                                    }
                                }



                            /************************************************/
                            model10 = new QStandardItemModel(5,2,this);
                            ui->tableView_20->setModel(model10);
                            ui->tableView_20->setColumnWidth(0,250);
                            ui->tableView_20->setColumnWidth(1,400);
                            ui->tableView_20->setStyleSheet(
                                                             "QTableView::item{"
                                                             "border: 1px solid black;"
                                                             "border-radius: 5px;"
                                                             "background-color: rgb(255, 255, 127);"
                                                             "color: black;"
                                                             "}"
                                                             );
                            /**************************************************/

























                                     model12 = new QStandardItemModel(9,2,this);
                                     ui->EDIT_SETUP_FIELDIO_ALARM_DIGITALIO_INDEX_Tableview->setModel(model12);
                                     ui->EDIT_SETUP_FIELDIO_ALARM_DIGITALIO_INDEX_Tableview->setColumnWidth(0,250);
                                     ui->EDIT_SETUP_FIELDIO_ALARM_DIGITALIO_INDEX_Tableview->setColumnWidth(1,400);
                                     ui->EDIT_SETUP_FIELDIO_ALARM_DIGITALIO_INDEX_Tableview->setStyleSheet(
                                                                      "QTableView::item{"
                                                                      "border: 1px solid black;"
                                                                      "border-radius: 5px;"
                                                                      "background-color: rgb(255, 255, 127);"
                                                                      "color: black;"
                                                                      "}"
                                                                       );


                                     model13 = new QStandardItemModel(2, 2, this);
                                     ui->EDIT_SETUP_EDIT_RECORDING_EXPORT_Tableview->setModel(model13);
                                     ui->EDIT_SETUP_EDIT_RECORDING_EXPORT_Tableview->setColumnWidth(0, 250);
                                     ui->EDIT_SETUP_EDIT_RECORDING_EXPORT_Tableview->setColumnWidth(1, 400);
                                     ui->EDIT_SETUP_EDIT_RECORDING_EXPORT_Tableview->horizontalHeader()->hide();
                                     ui->EDIT_SETUP_EDIT_RECORDING_EXPORT_Tableview->verticalHeader()->hide();


                                     ui->EDIT_SETUP_EDIT_RECORDING_EXPORT_Tableview->setStyleSheet(
                                                                     "QTableView::item{"
                                                                     "border: 1px solid black;"
                                                                       "border-radius: 5px;"
                                                                     "background-color: rgb(255, 255, 127);"
                                                                     "color: black;"
                                                                     "}"
                                                                 );

                                     // Set the data for each item in the model
                                     for (int row = 0; row < 2; ++row)
                                     {
                                         for (int col = 0; col < 2; ++col)
                                         {
                                             QModelIndex index = model13->index(row, col, QModelIndex());
                                             QStandardItem *my_item = model13->itemFromIndex(index);

                                             if (col == 0) {                                    
                                                 if (row == 0)
                                                          model13->setData(index, "TV Encrypt");                                                 
                                                 else if (row == 1)                                            
                                                     model13->setData(index, "CSV");

                                             }
                                             else if (col == 1) {
                                                 if(row == 0)
                                                 {
                                                     if(loaddata.Encrypt == 1)
                                                         model13->setData(index, "Enabled");
                                                     else if (loaddata.Encrypt == 0)
                                                          model13->setData(index, "Disabled");

                                                 }
                                                 if(row == 1)
                                                 {
                                                     if(loaddata.CSV == 1)
                                                            model13->setData(index, "Enabled");
                                                     else if (loaddata.CSV == 0)
                                                        model13->setData(index, "Disabled");
                                                 }

                                             }

                                             // Set the background color for all cells
                                             my_item->setBackground(Qt::yellow);
                                         }
                                     }

                                     // Set row heights
                                     ui->EDIT_SETUP_EDIT_RECORDING_EXPORT_Tableview->setRowHeight(0, 40);
                                     ui->EDIT_SETUP_EDIT_RECORDING_EXPORT_Tableview->setRowHeight(1, 40);

                                     engineer_model = new QStandardItemModel(15,2,this);
                                     ui->EDIT_SETUP_FIELDIO_ANALOGIN_INDEX_1_Tableview->setModel(engineer_model);
                                     ui->EDIT_SETUP_FIELDIO_ANALOGIN_INDEX_1_Tableview->setColumnWidth(0,250);
                                     ui->EDIT_SETUP_FIELDIO_ANALOGIN_INDEX_1_Tableview->setColumnWidth(1,400);
                                     ui->EDIT_SETUP_FIELDIO_ANALOGIN_INDEX_1_Tableview->setStyleSheet(
                                                                      "QTableView::item{"
                                                                     "border-radius: 5px;"
                                                                      "border: 1px solid black;"
                                                                      "background-color: rgb(255, 255, 127);"
                                                                      "color: black;"
                                                                      "}"
                                                                      );
                                     //ui->EDIT_SETUP_FIELDIO_ANALOGIN_INDEX_1_Tableview->setStyleSheet("QTableView{image: url(/home/pi/Desktop/Paperless_Recorder_gui/table_colour.jpg);background-color: rgb(251, 255, 207);}");
                                         // Generate data
                                         for(int row = 0; row < 15; row++)
                                         {
                                             ui->EDIT_SETUP_FIELDIO_ANALOGIN_INDEX_1_Tableview->setRowHeight(row,40);
                                             //for(int col = 0; col < 2; col++)
                                             {
                                                 QModelIndex index = engineer_model->index(row,0,QModelIndex());
                                                 // 0 for all data
                                                 if(row == 0)
                                                 {
                                                 QString text= QString("Enable");
                                                 //text.append(QString("%1 ").arg(row));
                                                 engineer_model->setData(index,text);
                                                 }
                                                 else if(row == 1)
                                                 {
                                                 QString text= QString("Type");
                                                 //text.append(QString("%1 ").arg(row));
                                                 engineer_model->setData(index,text);
                                                 }
                                                 else if(row == 2)
                                                 {
                                                 QString text= QString("Sample Rate");
                                                 //text.append(QString("%1 ").arg(row));
                                                 engineer_model->setData(index,text);
                                                 }
                                                 else if(row == 3)
                                                 {
                                                 QString text= QString("Range");
                                                 //text.append(QString("%1 ").arg(row));
                                                 engineer_model->setData(index,text);
                                                 }
                                                 else if(row == 4)
                                                 {
                                                 QString text= QString("Voltage Units");
                                                 //text.append(QString("%1 ").arg(row));
                                                 engineer_model->setData(index,text);
                                                 }
                                                 else if(row == 5)
                                                 {
                                                 QString text= QString("High Limit");
                                                 //text.append(QString("%1 ").arg(row));
                                                 engineer_model->setData(index,text);
                                                 }
                                                 else if(row == 6)
                                                 {
                                                 QString text= QString("Lower Limit");
                                                 //text.append(QString("%1 ").arg(row));
                                                 engineer_model->setData(index,text);
                                                 }
                                                 else if(row == 7)
                                                 {
                                                 QString text= QString("Damp Level");
                                                 //text.append(QString("%1 ").arg(row));
                                                 engineer_model->setData(index,text);
                                                 }
                                                 else if(row == 8)
                                                 {
                                                 QString text= QString("Linearisation Table");
                                                 //text.append(QString("%1 ").arg(row));
                                                 engineer_model->setData(index,text);
                                                 }
                                                 else if(row == 9)
                                                 {
                                                 QString text= QString("Use pen scale");
                                                 //text.append(QString("%1 ").arg(row));
                                                 engineer_model->setData(index,text);
                                                 }
                                                 else if(row == 10)
                                                 {
                                                 QString text= QString("Units");
                                                 //text.append(QString("%1 ").arg(row));
                                                 engineer_model->setData(index,text);
                                                 }
                                                 else if(row ==11)
                                                 {
                                                 QString text= QString("Label");
                                                 //text.append(QString("%1 ").arg(index));
                                                 engineer_model->setData(index,text);
                                                 }
                                                 else if(row == 12)
                                                 {
                                                 QString text= QString("SQRT Extract");
                                                 //text.append(QString("%1 ").arg(row));
                                                 engineer_model->setData(index,text);
                                                 }
                                                 else if(row == 13)
                                                 {
                                                 QString text= QString("Sensor Comp.");
                                                 //text.append(QString("%1 ").arg(row));
                                                 engineer_model->setData(index,text);
                                                 }
                                                 else if(row == 14)
                                                 {
                                                 QString text= QString("Demo Setup");
                                                 //text.append(QString("%1 ").arg(row));
                                                 engineer_model->setData(index,text);
                                                 }

                                             }

                                             {
                                                 QModelIndex index = engineer_model->index(row,1,QModelIndex());
                                                 // 0 for all data
                                                 if(row == 0)
                                                 {
                                                 QString text= QString("ENABLED");
                                                 //text.append(QString("%1 ").arg(row));
                                                 engineer_model->setData(index,text);
                                                 }
                                                 else if(row == 1)
                                                 {
                                                 QString text= QString("Volts");
                                                 //text.append(QString("%1 ").arg(row));
                                                 engineer_model->setData(index,text);
                                                 }
                                                 else if(row == 2)
                                                 {
                                                 QString text= QString("2Hz(500ms)");
                                                 //text.append(QString("%1 ").arg(row));
                                                 engineer_model->setData(index,text);
                                                 }
                                                 else if(row == 3)
                                                 {
                                                 QString text= QString("User Defined");
                                                 //text.append(QString("%1 ").arg(row));
                                                 engineer_model->setData(index,text);
                                                 }
                                                 else if(row == 4)
                                                 {
                                                 QString text= QString("V");
                                                 //text.append(QString("%1 ").arg(row));
                                                 engineer_model->setData(index,text);
                                                 }
                                                 else if(row == 5)
                                                 {
                                                 QString text= QString("1.0 ");
                                                 //text.append(QString("%1 ").arg(row));
                                                 engineer_model->setData(index,text);
                                                 }
                                                 else if(row == 6)
                                                 {
                                                 QString text= QString("0.0");
                                                 //text.append(QString("%1 ").arg(row));
                                                 engineer_model->setData(index,text);
                                                 }
                                                 else if(row == 7)
                                                 {
                                                 QString text= QString("0.0");
                                                 //text.append(QString("%1 ").arg(row));
                                                 engineer_model->setData(index,text);
                                                 }
                                                 else if(row == 8)
                                                 {
                                                 QString text= QString("No Tables");
                                                 //text.append(QString("%1 ").arg(row));
                                                 engineer_model->setData(index,text);
                                                 }
                                                 else if(row == 9)
                                                 {
                                                 QString text= QString("1");
                                                 //text.append(QString("%1 ").arg(index));
                                                 engineer_model->setData(index,text);
                                                 }
                                                 else if(row == 10)
                                                 {
                                                 QString text= QString("% ");
                                                 //text.append(QString("%1 ").arg(row));
                                                 engineer_model->setData(index,text);
                                                 }
                                                 else if(row == 11)
                                                 {
                                                 QString text= QString("A1");
                                                 //text.append(QString("%1 ").arg(row));
                                                 engineer_model->setData(index,text);
                                                 }
                                                 else if(row == 12)
                                                 {
                                                 QString text= QString("Off ");
                                                 //text.append(QString("%1 ").arg(row));
                                                 engineer_model->setData(index,text);
                                                 }
                                                 else if(row == 13)
                                                 {
                                                 QString text= QString("None ");
                                                 //text.append(QString("%1 ").arg(row));
                                                 engineer_model->setData(index,text);
                                                 }
                                                 else if(row == 14)
                                                 {
                                                 QString text= QString("200 Secs. Drift ");
                                                 //text.append(QString("%1 ").arg(row));
                                                 engineer_model->setData(index,text);
                                                 }

                                             }
                                         }

                                         model21 = new QStandardItemModel(14,2,this);
                                         ui->EDIT_SETUP_FIELDIO_ANALOGIN_INDEX_2_Tableview->setModel(model21);
                                         ui->EDIT_SETUP_FIELDIO_ANALOGIN_INDEX_2_Tableview->setColumnWidth(0,250);
                                         ui->EDIT_SETUP_FIELDIO_ANALOGIN_INDEX_2_Tableview->setColumnWidth(1,400);
                                         ui->EDIT_SETUP_FIELDIO_ANALOGIN_INDEX_2_Tableview->setStyleSheet(
                                                                          "QTableView::item{"
                                                                         "border-radius: 5px;"
                                                                          "border: 1px solid black;"
                                                                          "background-color: rgb(255, 255, 127);"
                                                                          "color: black;"
                                                                          "}"
                                                                          );
                                         //ui->EDIT_SETUP_FIELDIO_ANALOGIN_INDEX_2_Tableview->setStyleSheet("QTableView{image: url(/home/pi/Desktop/Paperless_Recorder_gui/table_colour.jpg);background-color: rgb(251, 255, 207);}");
                                             // Generate data
                                             for(int row = 0; row < 15; row++)
                                             {
                                                 ui->EDIT_SETUP_FIELDIO_ANALOGIN_INDEX_2_Tableview->setRowHeight(row,40);
                                                 //for(int col = 0; col < 2; col++)
                                                 {
                                                     QModelIndex index = model21->index(row,0,QModelIndex());
                                                     // 0 for all data
                                                     if(row == 0)
                                                     {
                                                     QString text= QString("Enabel");
                                                     //text.append(QString("%1 ").arg(row));
                                                     model21->setData(index,text);
                                                     }
                                                     else if(row == 1)
                                                     {
                                                     QString text= QString("Type");
                                                     //text.append(QString("%1 ").arg(row));
                                                     model21->setData(index,text);
                                                     }
                                                     else if(row == 2)
                                                     {
                                                     QString text= QString("Sample Rate");
                                                     //text.append(QString("%1 ").arg(row));
                                                     model21->setData(index,text);
                                                     }
                                                     else if(row == 3)
                                                     {
                                                     QString text= QString("Range");
                                                     //text.append(QString("%1 ").arg(row));
                                                     model21->setData(index,text);
                                                     }

                                                     else if(row == 4)
                                                     {
                                                     QString text= QString("High Limit");
                                                     //text.append(QString("%1 ").arg(row));
                                                     model21->setData(index,text);
                                                     }
                                                     else if(row == 5)
                                                     {
                                                     QString text= QString("Lower Limit");
                                                     //text.append(QString("%1 ").arg(row));
                                                     model21->setData(index,text);
                                                     }
                                                     else if(row == 6)
                                                     {
                                                     QString text= QString("Damp Level");
                                                     //text.append(QString("%1 ").arg(row));
                                                     model21->setData(index,text);
                                                     }
                                                     else if(row == 7)
                                                     {
                                                     QString text= QString("Linearisation Table");
                                                     //text.append(QString("%1 ").arg(row));
                                                     model21->setData(index,text);
                                                     }
                                                     else if(row == 8)
                                                     {
                                                     QString text= QString("Use pen scale");
                                                     //text.append(QString("%1 ").arg(row));
                                                     model21->setData(index,text);
                                                     }
                                                     else if(row == 9)
                                                     {
                                                     QString text= QString("Units");
                                                     //text.append(QString("%1 ").arg(row));
                                                     model21->setData(index,text);
                                                     }
                                                     else if(row ==10)
                                                     {
                                                     QString text= QString("Label");
                                                     //text.append(QString("%1 ").arg(index));
                                                     model21->setData(index,text);
                                                     }
                                                     else if(row == 11)
                                                     {
                                                     QString text= QString("SQRT Extract");
                                                     //text.append(QString("%1 ").arg(row));
                                                     model21->setData(index,text);
                                                     }
                                                     else if(row == 12)
                                                     {
                                                     QString text= QString("Sensor Comp.");
                                                     //text.append(QString("%1 ").arg(row));
                                                     model21->setData(index,text);
                                                     }
                                                     else if(row == 13)
                                                     {
                                                     QString text= QString("Demo Setup");
                                                     //text.append(QString("%1 ").arg(row));
                                                     model21->setData(index,text);
                                                     }

                                                 }

                                                 {
                                                     QModelIndex index = model21->index(row,1,QModelIndex());
                                                     // 0 for all data
                                                     if(row == 0)
                                                     {
                                                     QString text= QString(" . ");
                                                     //text.append(QString("%1 ").arg(row));
                                                     model21->setData(index,text);
                                                     }
                                                     else if(row == 1)
                                                     {
                                                     QString text= QString("Amps");
                                                     //text.append(QString("%1 ").arg(row));
                                                     model21->setData(index,text);
                                                     }
                                                     else if(row == 2)
                                                     {
                                                     QString text= QString("2Hz(500ms)");
                                                     //text.append(QString("%1 ").arg(row));
                                                     model21->setData(index,text);
                                                     }
                                                     else if(row == 3)
                                                     {
                                                     QString text= QString("User Defined");
                                                     //text.append(QString("%1 ").arg(row));
                                                     model21->setData(index,text);
                                                     }

                                                     else if(row == 4)
                                                     {
                                                     QString text= QString("1.0 ");
                                                     //text.append(QString("%1 ").arg(row));
                                                     model21->setData(index,text);
                                                     }
                                                     else if(row == 5)
                                                     {
                                                     QString text= QString("0.0");
                                                     //text.append(QString("%1 ").arg(row));
                                                     model21->setData(index,text);
                                                     }
                                                     else if(row == 6)
                                                     {
                                                     QString text= QString("0.0");
                                                     //text.append(QString("%1 ").arg(row));
                                                     model21->setData(index,text);
                                                     }
                                                     else if(row == 7)
                                                     {
                                                     QString text= QString("No Tables");
                                                     //text.append(QString("%1 ").arg(row));
                                                     model21->setData(index,text);
                                                     }
                                                     else if(row == 8)
                                                     {
                                                     QString text= QString("1");
                                                     //text.append(QString("%1 ").arg(index));
                                                     model21->setData(index,text);
                                                     }
                                                     else if(row == 9)
                                                     {
                                                     QString text= QString("% ");
                                                     //text.append(QString("%1 ").arg(row));
                                                     model21->setData(index,text);
                                                     }
                                                     else if(row == 10)
                                                     {
                                                     QString text= QString("A1");
                                                     //text.append(QString("%1 ").arg(row));
                                                     model21->setData(index,text);
                                                     }
                                                     else if(row == 11)
                                                     {
                                                     QString text= QString("Off ");
                                                     //text.append(QString("%1 ").arg(row));
                                                     model21->setData(index,text);
                                                     }
                                                     else if(row == 12)
                                                     {
                                                     QString text= QString("None ");
                                                     //text.append(QString("%1 ").arg(row));
                                                     model21->setData(index,text);
                                                     }
                                                     else if(row == 13)
                                                     {
                                                     QString text= QString("200 Secs. Drift ");
                                                     //text.append(QString("%1 ").arg(row));
                                                     model21->setData(index,text);
                                                     }

                                                 }
                                             }

                                             model22 = new QStandardItemModel(14,2,this);
                                             ui->EDIT_SETUP_FIELD_IO_ANALOG_IN_INDEX_Tableview->setModel(model22);
                                             ui->EDIT_SETUP_FIELD_IO_ANALOG_IN_INDEX_Tableview->setColumnWidth(0,250);
                                             ui->EDIT_SETUP_FIELD_IO_ANALOG_IN_INDEX_Tableview->setColumnWidth(1,400);
                                             ui->EDIT_SETUP_FIELD_IO_ANALOG_IN_INDEX_Tableview->setStyleSheet(
                                                                              "QTableView::item{"
                                                                              "border: 1px solid black;"
                                                                              "border-radius: 5px;"
                                                                              "background-color: rgb(255, 255, 127);"
                                                                              "color: black;"
                                                                              "}"
                                                                              );
                                             //ui->EDIT_SETUP_FIELD_IO_ANALOG_IN_INDEX_Tableview->setStyleSheet("QTableView{image: url(/home/pi/Desktop/Paperless_Recorder_gui/table_colour.jpg);background-color: rgb(251, 255, 207);}");
                                                 // Generate data
                                                 for(int row = 0; row < 17; row++)
                                                 {
                                                     ui->EDIT_SETUP_FIELD_IO_ANALOG_IN_INDEX_Tableview->setRowHeight(row,40);
                                                     //for(int col = 0; col < 2; col++)
                                                     {
                                                         QModelIndex index = model22->index(row,0,QModelIndex());
                                                         // 0 for all data
                                                         if(row == 0)
                                                         {
                                                         QString text= QString("Enabel");
                                                         //text.append(QString("%1 ").arg(row));
                                                         model22->setData(index,text);
                                                         }
                                                         else if(row == 1)
                                                         {
                                                         QString text= QString("Type");
                                                         //text.append(QString("%1 ").arg(row));
                                                         model22->setData(index,text);
                                                         }
                                                         else if(row == 2)
                                                         {
                                                         QString text= QString("Sample Rate");
                                                         //text.append(QString("%1 ").arg(row));
                                                         model22->setData(index,text);
                                                         }
                                                         else if(row == 3)
                                                         {
                                                         QString text= QString("Range");
                                                         //text.append(QString("%1 ").arg(row));
                                                         model22->setData(index,text);
                                                         }
                                                         else if(row == 4)
                                                         {
                                                         QString text= QString("High Limit");
                                                         //text.append(QString("%1 ").arg(row));
                                                         model22->setData(index,text);
                                                         }
                                                         else if(row == 5)
                                                         {
                                                         QString text= QString("Lower Limit");
                                                         //text.append(QString("%1 ").arg(row));
                                                         model22->setData(index,text);
                                                         }
                                                         else if(row == 6)
                                                         {
                                                         QString text= QString("Damp Level");
                                                         //text.append(QString("%1 ").arg(row));
                                                         model22->setData(index,text);
                                                         }
                                                         else if(row == 7)
                                                         {
                                                         QString text= QString("Linearisation Table");
                                                         //text.append(QString("%1 ").arg(row));
                                                         model22->setData(index,text);
                                                         }
                                                         else if(row == 8)
                                                         {
                                                         QString text= QString("Use pen scale");
                                                         //text.append(QString("%1 ").arg(row));
                                                         model22->setData(index,text);
                                                         }
                                                         else if(row == 9)
                                                         {
                                                         QString text= QString("Units");
                                                         //text.append(QString("%1 ").arg(row));
                                                         model22->setData(index,text);
                                                         }
                                                         else if(row == 10)
                                                         {
                                                         QString text= QString("Label");
                                                         //text.append(QString("%1 ").arg(index));
                                                         model22->setData(index,text);
                                                         }
                                                         else if(row == 11)
                                                         {
                                                         QString text= QString("SQRT Extract");
                                                         //text.append(QString("%1 ").arg(row));
                                                         model22->setData(index,text);
                                                         }
                                                         else if(row == 12)
                                                         {
                                                         QString text= QString("Sensor Comp.");
                                                         //text.append(QString("%1 ").arg(row));
                                                         model22->setData(index,text);
                                                         }
                                                         else if(row == 13)
                                                         {
                                                         QString text= QString("Demo Setup");
                                                         //text.append(QString("%1 ").arg(row));
                                                         model22->setData(index,text);
                                                         }

                                                     }

                                                     {
                                                         QModelIndex index = model22->index(row,1,QModelIndex());
                                                         // 0 for all data
                                                         if(row == 0)
                                                         {
                                                         QString text= QString(" . ");
                                                         //text.append(QString("%1 ").arg(row));
                                                         model22->setData(index,text);
                                                         }
                                                         else if(row == 1)
                                                         {
                                                         QString text= QString("Amps");
                                                         //text.append(QString("%1 ").arg(row));
                                                         model22->setData(index,text);
                                                         }
                                                         else if(row == 2)
                                                         {
                                                         QString text= QString("2Hz(500ms)");
                                                         //text.append(QString("%1 ").arg(row));
                                                         model22->setData(index,text);
                                                         }
                                                         else if(row == 3)
                                                         {
                                                         QString text= QString("User Defined");
                                                         //text.append(QString("%1 ").arg(row));
                                                         model22->setData(index,text);
                                                         }
                                                         else if(row == 4)
                                                         {
                                                         QString text= QString("1.0");
                                                         //text.append(QString("%1 ").arg(row));
                                                         model22->setData(index,text);
                                                         }
                                                         else if(row == 5)
                                                         {
                                                         QString text= QString("1.0 ");
                                                         //text.append(QString("%1 ").arg(row));
                                                         model22->setData(index,text);
                                                         }
                                                         else if(row == 6)
                                                         {
                                                         QString text= QString("0.0 ");
                                                         //text.append(QString("%1 ").arg(row));
                                                         model22->setData(index,text);
                                                         }
                                                         else if(row == 7)
                                                         {
                                                         QString text= QString("No Tables ");
                                                         //text.append(QString("%1 ").arg(row));
                                                         model22->setData(index,text);
                                                         }
                                                         else if(row == 8)
                                                         {
                                                         QString text= QString("3");
                                                         //text.append(QString("%1 ").arg(row));
                                                         model22->setData(index,text);
                                                         }
                                                         else if(row == 9)
                                                         {
                                                         QString text= QString("%");
                                                         //text.append(QString("%1 ").arg(row));
                                                         model22->setData(index,text);
                                                         }
                                                         else if(row == 10)
                                                         {
                                                         QString text= QString("A1");
                                                         //text.append(QString("%1 ").arg(index));
                                                         model22->setData(index,text);
                                                         }
                                                         else if(row == 11)
                                                         {
                                                         QString text= QString(" Off ");
                                                         //text.append(QString("%1 ").arg(row));
                                                         model22->setData(index,text);
                                                         }
                                                         else if(row == 12)
                                                         {
                                                         QString text= QString("None");
                                                         //text.append(QString("%1 ").arg(row));
                                                         model22->setData(index,text);
                                                         }
                                                         else if(row == 13)
                                                         {
                                                         QString text= QString("200Secs. Drift ");
                                                         //text.append(QString("%1 ").arg(row));
                                                         model22->setData(index,text);
                                                         }

                                                     }
                                                 }





                                                 scale_model = new QStandardItemModel(8, 2, this);
                                                 ui->tableView_64->setModel(scale_model);
                                                 ui->tableView_64->setColumnWidth(0, 250);
                                                 ui->tableView_64->setColumnWidth(1, 400);
                                                 ui->tableView_64->horizontalHeader()->hide();
                                                 ui->tableView_64->verticalHeader()->hide();
                                                 ui->tableView_64->setStyleSheet(
                                                     "QTableView::item {"
                                                     "border: 1px solid black;"
                                                     "border-radius: 5px;"
                                                     "background-color: rgb(255, 255, 127);"
                                                     "color: black;"
                                                     "}"
                                                 );

                                                 // Populate the data for each item in the model
                                                 for (int row = 0; row < 8; ++row) {
                                                     for (int col = 0; col < 2; ++col) {
                                                         QStandardItem* item = new QStandardItem();

                                                         if (row == 0) {
                                                             if (col == 0) {
                                                                 item->setText("Units");
                                                             } else if (col == 1) {
                                                                 item->setText("%");
                                                             }
                                                         } else if (row == 1) {
                                                             if (col == 0) {
                                                                 item->setText("Span");
                                                             } else if (col == 1) {
                                                                 item->setText("100.0");
                                                             }
                                                         } else if (row == 2) {
                                                             if (col == 0) {
                                                                 item->setText("Zero");
                                                             } else if (col == 1) {
                                                                 item->setText("0.0");
                                                             }
                                                         } else if (row == 3) {
                                                             if (col == 0) {
                                                                 item->setText("Scale Type");
                                                             } else if (col == 1) {
                                                                 item->setText("Linear");
                                                             }
                                                         } else if (row == 4) {
                                                             if (col == 0) {
                                                                 item->setText("Divs Select");
                                                             } else if (col == 1) {
                                                                 item->setText("User Defined");
                                                             }
                                                         } else if (row == 5) {
                                                             if (col == 0) {
                                                                 item->setText("Major Divs");
                                                             } else if (col == 1) {
                                                                 item->setText("20.0");
                                                             }
                                                         } else if (row == 6) {
                                                             if (col == 0) {
                                                                 item->setText("Minor Divs");
                                                             } else if (col == 1) {
                                                                 item->setText("5.0");
                                                             }
                                                         } else if (row == 7) {
                                                             if (col == 0) {
                                                                 item->setText("Numb Format");
                                                             } else if (col == 1) {
                                                                 item->setText("Normal");
                                                             }
                                                         }

                                                         scale_model->setItem(row, col, item);
                                                     }
                                                 }
                                                 for (int i = 0; i < 8; ++i) {
                                                     ui->tableView_64->setRowHeight(i, 40);
                                                 }

                                                 log_model = new QStandardItemModel(7, 2, this);
                                                 ui->EDIT_LAYOUT_SCREENS_SCREEN_Config_Table_3->setModel(log_model);
                                                 ui->EDIT_LAYOUT_SCREENS_SCREEN_Config_Table_3->setColumnWidth(0, 250);
                                                 ui->EDIT_LAYOUT_SCREENS_SCREEN_Config_Table_3->setColumnWidth(1, 400);
                                                 ui->EDIT_LAYOUT_SCREENS_SCREEN_Config_Table_3->horizontalHeader()->hide();
                                                 ui->EDIT_LAYOUT_SCREENS_SCREEN_Config_Table_3->verticalHeader()->hide();
                                                 ui->EDIT_LAYOUT_SCREENS_SCREEN_Config_Table_3->setStyleSheet(
                                                     "QTableView::item {"
                                                     "border: 1px solid black;"
                                                     "border-radius: 5px;"
                                                     "background-color: rgb(255, 255, 127);"
                                                     "color: black;"
                                                     "}"
                                                 );

                                                 // Populate the data for each item in the model
                                                 for (int row = 0; row < 7; ++row) {
                                                     for (int col = 0; col < 2; ++col) {
                                                         QStandardItem* item = new QStandardItem();

                                                         if (row == 0) {
                                                             if (col == 0) {
                                                                 item->setText("Units");
                                                             } else if (col == 1) {
                                                                 item->setText("%");
                                                             }
                                                         } else if (row == 1) {
                                                             if (col == 0) {
                                                                 item->setText("Span");
                                                             } else if (col == 1) {
                                                                 item->setText("E1");
                                                             }
                                                         } else if (row == 2) {
                                                             if (col == 0) {
                                                                 item->setText("Zero");
                                                             } else if (col == 1) {
                                                                 item->setText("E0");
                                                             }
                                                         } else if (row == 3) {
                                                             if (col == 0) {
                                                                 item->setText("Scale Type");
                                                             } else if (col == 1) {
                                                                 item->setText("Log");
                                                             }
                                                         } else if (row == 4) {
                                                             if (col == 0) {
                                                                 item->setText("Start Decade");
                                                             } else if (col == 1) {
                                                                 item->setText("0");
                                                             }
                                                         } else if (row == 5) {
                                                             if (col == 0) {
                                                                 item->setText("No.Decades");
                                                             } else if (col == 1) {
                                                                 item->setText("1");
                                                             }
                                                         } else if (row == 6) {
                                                             if (col == 0) {
                                                                 item->setText("Numb Format");
                                                             } else if (col == 1) {
                                                                 item->setText("Normal");
                                                             }
                                                         }

                                                         log_model->setItem(row, col, item);
                                                     }
                                                 }

                                                 // Set row heights for the 7 rows
                                                 for (int i = 0; i < 7; ++i) {
                                                     ui->EDIT_LAYOUT_SCREENS_SCREEN_Config_Table_3->setRowHeight(i, 40);
                                                 }



                                                 numb_model = new QStandardItemModel(3, 2, this);
                                                 ui->tableView_65->setModel(numb_model);
                                                 ui->tableView_65->setColumnWidth(0, 250);
                                                 ui->tableView_65->setColumnWidth(1, 400);
                                                 ui->tableView_65->horizontalHeader()->hide();
                                                 ui->tableView_65->verticalHeader()->hide();
                                                 ui->tableView_65->setStyleSheet(
                                                     "QTableView::item {"
                                                     "border: 1px solid black;"
                                                     "border-radius: 5px;"
                                                     "background-color: rgb(255, 255, 127);"
                                                     "color: black;"
                                                     "}"
                                                 );

                                                 // Populate the data for each item in the model
                                                 for (int row = 0; row < 3; ++row) {
                                                     for (int col = 0; col < 2; ++col) {
                                                         QStandardItem* item = new QStandardItem();

                                                         if (row == 0) {
                                                             if (col == 0) {
                                                                 item->setText("Notation");
                                                             } else if (col == 1) {
                                                                 item->setText("Normal");
                                                             }
                                                         } else if (row == 1) {
                                                             if (col == 0) {
                                                                 item->setText("Auto");
                                                             } else if (col == 1) {
                                                                 item->setText("Auto");
                                                             }
                                                         } else if (row == 2) {
                                                             if (col == 0) {
                                                                 item->setText("After Decimal");
                                                             } else if (col == 1) {
                                                                 item->setText("0");
                                                             }
                                                         }

                                                         // Add the item to the model
                                                         numb_model->setItem(row, col, item);
                                                     }
                                                 }

                                                 // Set row heights for all 3 rows
                                                 for (int row = 0; row < 3; ++row) {
                                                     ui->tableView_65->setRowHeight(row, 40);
                                                 }

                                                 rav_model = new QStandardItemModel(4, 2, this);
                                                 ui->tableView_66->setModel(rav_model);
                                                 ui->tableView_66->setColumnWidth(0, 250);
                                                 ui->tableView_66->setColumnWidth(1, 400);
                                                 ui->tableView_66->horizontalHeader()->hide();
                                                 ui->tableView_66->verticalHeader()->hide();
                                                 ui->tableView_66->setStyleSheet(
                                                     "QTableView::item {"
                                                     "border: 1px solid black;"
                                                     "border-radius: 5px;"
                                                     "background-color: rgb(255, 255, 127);"
                                                     "color: black;"
                                                     "}"
                                                 );

                                                 // Populate the data for each item in the model
                                                 for (int row = 0; row < 4; ++row) {
                                                     for (int col = 0; col < 2; ++col) {
                                                         QStandardItem* item = new QStandardItem();
                                                         if (row == 0) {
                                                             if (col == 0 || col == 1) {  // Corrected "col == 1"
                                                                 item->setText("Enabled");
                                                             }
                                                         } else if (row == 1) {
                                                             if (col == 0) {
                                                                 item->setText("No. of Samples");
                                                             } else if (col == 1) {
                                                                 item->setText("1");
                                                             }
                                                         } else if (row == 2) {
                                                             if (col == 0) {
                                                                 item->setText("Sample Interval");
                                                             } else if (col == 1) {
                                                                 item->setText("21 Secs");
                                                             }
                                                         } else if (row == 3) {
                                                             if (col == 0) {
                                                                 item->setText("Prefill");
                                                             } else if (col == 1) {
                                                                 item->setText("Enabled");
                                                             }
                                                         }

                                                         // Add the item to the model
                                                         rav_model->setItem(row, col, item);
                                                     }
                                                 }

                                                 // Set row heights for all 4 rows
                                                 for (int row = 0; row < 4; ++row) {
                                                     ui->tableView_66->setRowHeight(row, 40);
                                                 }



                                                 alarm_model = new QStandardItemModel(7, 2, this);

                                                 ui->tableView_67->setModel(alarm_model);
                                                 ui->tableView_67->setColumnWidth(0, 250);
                                                 ui->tableView_67->setColumnWidth(1, 400);
                                                 ui->tableView_67->horizontalHeader()->hide();
                                                 ui->tableView_67->verticalHeader()->hide();

                                                 ui->tableView_67->setStyleSheet(
                                                     "QTableView::item {"
                                                     "border: 1px solid black;"
                                                     "border-radius: 5px;"
                                                     "background-color: rgb(255, 255, 127);"
                                                     "color: black;"
                                                     "}"
                                                 );
                                                 for (int row = 0; row < 7; ++row) {
                                                     for (int col = 0; col < 2; ++col) {
                                                         QStandardItem* item = new QStandardItem();
                                                         if (col == 0) {
                                                             item->setText("Alarm " + QString::number(row + 1));
                                                         } else if (col == 1) {
                                                             item->setText("None");
                                                         }

                                                         // Add the item to the model
                                                         alarm_model->setItem(row, col, item);
                                                     }
                                                 }

                                                 // Set row heights for all 7 rows
                                                 for (int row = 0; row < 7; ++row) {
                                                     ui->tableView_67->setRowHeight(row, 40);
                                                 }


                                                 alarm_model1 = new QStandardItemModel(13, 2, this);

                                                  ui->tableView_69->setModel(alarm_model1);

                                                  ui->tableView_69->setColumnWidth(0, 250);
                                                  ui->tableView_69->setColumnWidth(1, 400);

                                                  ui->tableView_69->horizontalHeader()->hide();
                                                  ui->tableView_69->verticalHeader()->hide();

                                                  ui->tableView_69->setStyleSheet(
                                                      "QTableView::item {"
                                                      "border: 1px solid black;"
                                                      "border-radius: 5px;"
                                                      "background-color: rgb(255, 255, 127);"
                                                      "color: black;"
                                                      "}"
                                                  );

                                                  // Populate the data for each item in the model
                                                  for (int row = 0; row < 13; ++row) {
                                                      for (int col = 0; col < 2; ++col) {
                                                          QStandardItem* item = new QStandardItem();

                                                          // Set the text for each cell based on your logic
                                                          if (row == 0) {
                                                              if (col == 0) {
                                                                  item->setText("Enabled");
                                                              } else if (col == 1) {
                                                                  item->setText("Disabled");
                                                              }
                                                          } else if (row == 1) {
                                                              if (col == 0) {
                                                                  item->setText("Type");
                                                              } else if (col == 1) {
                                                                  item->setText("High");
                                                              }
                                                          } else if (row == 2) {
                                                              if (col == 0) {
                                                                  item->setText("Level");
                                                              } else if (col == 1) {
                                                                  item->setText("0.0%");
                                                              }
                                                          } else if (row == 3) {
                                                              if (col == 0) {
                                                                  item->setText("Tag");
                                                              } else if (col == 1) {
                                                                  item->setText("P6 Alm 1");
                                                              }
                                                          } else if (row == 4) {
                                                              if (col == 0) {
                                                                  item->setText("Allow Change");
                                                              } else if (col == 1) {
                                                                  item->setText("Enabled");
                                                              }
                                                          } else if (row == 5) {
                                                              if (col == 0) {
                                                                  item->setText("Relays out");
                                                              } else if (col == 1) {
                                                                  item->setText("None");
                                                              }
                                                          } else if (row == 6) {
                                                              if (col == 0) {
                                                                  item->setText("Latched");
                                                              } else if (col == 1) {
                                                                  item->setText("Disabled");
                                                              }
                                                          } else if (row == 7) {
                                                              if (col == 0) {
                                                                  item->setText("Change Log");
                                                              } else if (col == 1) {
                                                                  item->setText("Disabled");
                                                              }
                                                          } else if (row == 8) {
                                                              if (col == 0) {
                                                                  item->setText("Mark Chart");
                                                              } else if (col == 1) {
                                                                  item->setText("Disabled");
                                                              }
                                                          } else if (row == 9) {
                                                              if (col == 0) {
                                                                  item->setText("Email Alarm");
                                                              } else if (col == 1) {
                                                                  item->setText("Disabled");
                                                              }
                                                          } else if (row == 10) {
                                                              if (col == 0) {
                                                                  item->setText("Hysteresis");
                                                              } else if (col == 1) {
                                                                  item->setText("Disabled");
                                                              }
                                                          } else if (row == 11) {
                                                              if (col == 0) {
                                                                  item->setText("Damping");
                                                              } else if (col == 1) {
                                                                  item->setText("Disabled");
                                                              }
                                                          } else if (row == 12) {
                                                              if (col == 0) {
                                                                  item->setText("Reflash");
                                                              } else if (col == 1) {
                                                                  item->setText("Disabled");
                                                              }                     }

                                                          // Add the item to the model
                                                          alarm_model1->setItem(row, col, item);
                                                      }
                                                  }

                                                  // Set the row heights for all 13 rows
                                                  for (int row = 0; row < 13; ++row) {
                                                      ui->tableView_69->setRowHeight(row, 40);
                                                  }



                                                  alarm_model2 = new QStandardItemModel(14, 2, this);

                                                  ui->tableView_70->setModel(alarm_model2);

                                                  ui->tableView_70->setColumnWidth(0, 250);
                                                  ui->tableView_70->setColumnWidth(1, 400);

                                                  ui->tableView_70->horizontalHeader()->hide();
                                                  ui->tableView_70->verticalHeader()->hide();

                                                  ui->tableView_70->setStyleSheet(
                                                      "QTableView::item {"
                                                      "border: 1px solid black;"
                                                      "border-radius: 5px;"
                                                      "background-color: rgb(255, 255, 127);"
                                                      "color: black;"
                                                      "}"
                                                  );

                                                  // Populate the data for each item in the model
                                                  for (int row = 0; row < 14; ++row) {
                                                      for (int col = 0; col < 2; ++col) {
                                                          QStandardItem* item = new QStandardItem();

                                                          // Set the text for each cell based on your logic
                                                          if (row == 0) {
                                                              if (col == 0) {
                                                                  item->setText("Enabled");
                                                              } else if (col == 1) {
                                                                  item->setText("Disabled");
                                                              }
                                                          } else if (row == 1) {
                                                              if (col == 0) {
                                                                  item->setText("Type");
                                                              } else if (col == 1) {
                                                                  item->setText("Deviation");
                                                              }
                                                          } else if (row == 2) {
                                                              if (col == 0) {
                                                                  item->setText("Dev Level");
                                                              } else if (col == 1) {
                                                                  item->setText("1.0%");
                                                              }
                                                          } else if (row == 3) {
                                                              if (col == 0) {
                                                                  item->setText("Ref Pen");
                                                              } else if (col == 1) {
                                                                  item->setText("5");
                                                              }
                                                          } else if (row == 4) {
                                                              if (col == 0) {
                                                                  item->setText("Tag");
                                                              } else if (col == 1) {
                                                                  item->setText("P6 Alm 1");
                                                              }
                                                          } else if (row == 5) {
                                                              if (col == 0) {
                                                                  item->setText("Allow Change");
                                                              } else if (col == 1) {
                                                                  item->setText("Enabled");
                                                              }
                                                          } else if (row == 6) {
                                                              if (col == 0) {
                                                                  item->setText("Relays out");
                                                              } else if (col == 1) {
                                                                  item->setText("None");
                                                              }
                                                          } else if (row == 7) {
                                                              if (col == 0) {
                                                                  item->setText("Latched");
                                                              } else if (col == 1) {
                                                                  item->setText("Disabled");
                                                              }
                                                          } else if (row == 8) {
                                                              if (col == 0) {
                                                                  item->setText("Change Log");
                                                              } else if (col == 1) {
                                                                  item->setText("Disabled");
                                                              }
                                                          } else if (row == 9) {
                                                              if (col == 0) {
                                                                  item->setText("Mark Chart");
                                                              } else if (col == 1) {
                                                                  item->setText("Disabled");
                                                              }
                                                          } else if (row == 10) {
                                                              if (col == 0) {
                                                                  item->setText("Email Alarm");
                                                              } else if (col == 1) {
                                                                  item->setText("Disabled");
                                                              }
                                                          } else if (row == 11) {
                                                              if (col == 0) {
                                                                  item->setText("Damping");
                                                              } else if (col == 1) {
                                                                  item->setText("Disabled");
                                                              }
                                                          } else if (row == 12) {
                                                              if (col == 0) {
                                                                  item->setText("Damping Time");
                                                              } else if (col == 1) {
                                                                  item->setText("5 Secs");
                                                              }
                                                          } else if (row == 13) {
                                                              if (col == 0) {
                                                                  item->setText("Reflash");
                                                              } else if (col == 1) {
                                                                  item->setText("Enabled");
                                                              }
                                                          }

                                                          // Add the item to the model
                                                          alarm_model2->setItem(row, col, item);
                                                      }
                                                  }

                                                  // Set the row heights for all 14 rows
                                                  for (int row = 0; row < 14; ++row) {
                                                      ui->tableView_70->setRowHeight(row, 40);
                                                  }


                                                  alarm_model3 = new QStandardItemModel(14, 2, this);

                                                   ui->tableView_71->setModel(alarm_model3);

                                                   ui->tableView_71->setColumnWidth(0, 250);
                                                   ui->tableView_71->setColumnWidth(1, 400);

                                                   ui->tableView_71->horizontalHeader()->hide();
                                                   ui->tableView_71->verticalHeader()->hide();

                                                   ui->tableView_71->setStyleSheet(
                                                       "QTableView::item {"
                                                       "border: 1px solid black;"
                                                       "border-radius: 5px;"
                                                       "background-color: rgb(255, 255, 127);"
                                                       "color: black;"
                                                       "}"
                                                   );

                                                   // Populate the data for each item in the model
                                                   for (int row = 0; row < 14; ++row) {
                                                       for (int col = 0; col < 2; ++col) {
                                                           QStandardItem* item = new QStandardItem();

                                                           // Set the text for each cell based on your logic
                                                           if (row == 0) {
                                                               if (col == 0) {
                                                                   item->setText("Enabled");
                                                               } else if (col == 1) {
                                                                   item->setText("Disabled");
                                                               }
                                                           } else if (row == 1) {
                                                               if (col == 0) {
                                                                   item->setText("Type");
                                                               } else if (col == 1) {
                                                                   item->setText("Rate Up");
                                                               }
                                                           } else if (row == 2) {
                                                               if (col == 0) {
                                                                   item->setText("Dev Level");
                                                               } else if (col == 1) {
                                                                   item->setText("1.0%");
                                                               }
                                                           } else if (row == 3) {
                                                               if (col == 0) {
                                                                   item->setText("Time Period");
                                                               } else if (col == 1) {
                                                                   item->setText("5");
                                                               }
                                                           } else if (row == 4) {
                                                               if (col == 0) {
                                                                   item->setText("Tag");
                                                               } else if (col == 1) {
                                                                   item->setText("P6 Alm 1");
                                                               }
                                                           } else if (row == 5) {
                                                               if (col == 0) {
                                                                   item->setText("Allow Change");
                                                               } else if (col == 1) {
                                                                   item->setText("Enabled");
                                                               }
                                                           } else if (row == 6) {
                                                               if (col == 0) {
                                                                   item->setText("Relays out");
                                                               } else if (col == 1) {
                                                                   item->setText("None");
                                                               }
                                                           } else if (row == 7) {
                                                               if (col == 0) {
                                                                   item->setText("Latched");
                                                               } else if (col == 1) {
                                                                   item->setText("Disabled");
                                                               }
                                                           } else if (row == 8) {
                                                               if (col == 0) {
                                                                   item->setText("Change Log");
                                                               } else if (col == 1) {
                                                                   item->setText("Disabled");
                                                               }
                                                           } else if (row == 9) {
                                                               if (col == 0) {
                                                                   item->setText("Mark Chart");
                                                               } else if (col == 1) {
                                                                   item->setText("Disabled");
                                                               }
                                                           } else if (row == 10) {
                                                               if (col == 0) {
                                                                   item->setText("Email Alarm");
                                                               } else if (col == 1) {
                                                                   item->setText("Disabled");
                                                               }
                                                           } else if (row == 11) {
                                                               if (col == 0) {
                                                                   item->setText("Damping");
                                                               } else if (col == 1) {
                                                                   item->setText("Disabled");
                                                               }
                                                           } else if (row == 12) {
                                                               if (col == 0) {
                                                                   item->setText("Damping Time");
                                                               } else if (col == 1) {
                                                                   item->setText("5 Secs");
                                                               }
                                                           } else if (row == 13) {
                                                               if (col == 0) {
                                                                   item->setText("Reflash");
                                                               } else if (col == 1) {
                                                                   item->setText("Enabled");
                                                               }
                                                           }

                                                           // Add the item to the model
                                                           alarm_model3->setItem(row, col, item);
                                                       }
                                                   }

                                                   // Set the row heights for all 14 rows
                                                   for (int row = 0; row < 14; ++row) {
                                                       ui->tableView_71->setRowHeight(row, 40);
                                                   }


                                                   alarm_model4 = new QStandardItemModel(15, 2, this);

                                                   ui->tableView_72->setModel(alarm_model4);

                                                   ui->tableView_72->setColumnWidth(0, 250);
                                                   ui->tableView_72->setColumnWidth(1, 400);

                                                   ui->tableView_72->horizontalHeader()->hide();
                                                   ui->tableView_72->verticalHeader()->hide();

                                                   ui->tableView_72->setStyleSheet(
                                                       "QTableView::item {"
                                                       "border: 1px solid black;"
                                                       "border-radius: 5px;"
                                                       "background-color: rgb(255, 255, 127);"
                                                       "color: black;"
                                                       "}"
                                                   );

                                                   // Populate the data for each item in the model
                                                   for (int row = 0; row < 15; ++row) {
                                                       for (int col = 0; col < 2; ++col) {
                                                           QStandardItem* item = new QStandardItem();

                                                           // Set the text for each cell based on your logic
                                                           if (row == 0) {
                                                               if (col == 0) {
                                                                   item->setText("Enabled");
                                                               } else if (col == 1) {
                                                                   item->setText("Disabled");
                                                               }
                                                           } else if (row == 1) {
                                                               if (col == 0) {
                                                                   item->setText("Type");
                                                               } else if (col == 1) {
                                                                   item->setText("high");
                                                               }
                                                           } else if (row == 2) {
                                                               if (col == 0) {
                                                                   item->setText("Level");
                                                               } else if (col == 1) {
                                                                   item->setText("0.0%");
                                                               }
                                                           } else if (row == 3) {
                                                               if (col == 0) {
                                                                   item->setText("Tag");
                                                               } else if (col == 1) {
                                                                   item->setText("P6 Alm 1");
                                                               }
                                                           } else if (row == 4) {
                                                               if (col == 0) {
                                                                   item->setText("Allow Change");
                                                               } else if (col == 1) {
                                                                   item->setText("Enabled");
                                                               }
                                                           } else if (row == 5) {
                                                               if (col == 0) {
                                                                   item->setText("Relays out");
                                                               } else if (col == 1) {
                                                                   item->setText("None");
                                                               }
                                                           } else if (row == 6) {
                                                               if (col == 0) {
                                                                   item->setText("Latched");
                                                               } else if (col == 1) {
                                                                   item->setText("Disabled");
                                                               }
                                                           } else if (row == 7) {
                                                               if (col == 0) {
                                                                   item->setText("Change Log");
                                                               } else if (col == 1) {
                                                                   item->setText("Disabled");
                                                               }
                                                           } else if (row == 8) {
                                                               if (col == 0) {
                                                                   item->setText("Mark Chart");
                                                               } else if (col == 1) {
                                                                   item->setText("Disabled");
                                                               }
                                                           } else if (row == 9) {
                                                               if (col == 0) {
                                                                   item->setText("Email Alarm");
                                                               } else if (col == 1) {
                                                                   item->setText("Disabled");
                                                               }
                                                           } else if (row == 10) {
                                                               if (col == 0) {
                                                                   item->setText("Hysteresis");
                                                               } else if (col == 1) {
                                                                   item->setText("Disabled");
                                                               }
                                                           } else if (row == 11) {
                                                               if (col == 0) {
                                                                   item->setText("Hyst Level");
                                                               } else if (col == 1) {
                                                                   item->setText("2.0%");
                                                               }
                                                           } else if (row == 12) {
                                                               if (col == 0) {
                                                                   item->setText("Damping");
                                                               } else if (col == 1) {
                                                                   item->setText("Disabled");
                                                               }
                                                           } else if (row == 13) {
                                                               if (col == 0) {
                                                                   item->setText("Damping Time");
                                                               } else if (col == 1) {
                                                                   item->setText("5 Secs");
                                                               }
                                                           } else if (row == 14) {
                                                               if (col == 0) {
                                                                   item->setText("Reflash");
                                                               } else if (col == 1) {
                                                                   item->setText("Disabled");
                                                               }
                                                           }

                                                           // Add the item to the model
                                                           alarm_model4->setItem(row, col, item);
                                                       }
                                                   }

                                                   // Set the row heights for all 15 rows
                                                   for (int row = 0; row < 15; ++row) {
                                                       ui->tableView_72->setRowHeight(row, 40);
                                                   }





                                                   alarm_model5 = new QStandardItemModel(14, 2, this);

                                                      ui->tableView_73->setModel(alarm_model5);

                                                      ui->tableView_73->setColumnWidth(0, 250);
                                                      ui->tableView_73->setColumnWidth(1, 400);

                                                      ui->tableView_73->horizontalHeader()->hide();
                                                      ui->tableView_73->verticalHeader()->hide();

                                                      ui->tableView_73->setStyleSheet(
                                                          "QTableView::item {"
                                                          "border: 1px solid black;"
                                                          "border-radius: 5px;"
                                                          "background-color: rgb(255, 255, 127);"
                                                          "color: black;"
                                                          "}"
                                                      );

                                                      // Populate the data for each item in the model
                                                      for (int row = 0; row < 14; ++row) {
                                                          for (int col = 0; col < 2; ++col) {
                                                              QStandardItem* item = new QStandardItem();

                                                              // Set the text for each cell based on your logic
                                                              if (row == 0) {
                                                                  if (col == 0) {
                                                                      item->setText("Enabled");
                                                                  } else if (col == 1) {
                                                                      item->setText("Disabled");
                                                                  }
                                                              } else if (row == 1) {
                                                                  if (col == 0) {
                                                                      item->setText("Type");
                                                                  } else if (col == 1) {
                                                                      item->setText("Rate Up");
                                                                  }
                                                              } else if (row == 2) {
                                                                  if (col == 0) {
                                                                      item->setText("Dev Level");
                                                                  } else if (col == 1) {
                                                                      item->setText("1.0%");
                                                                  }
                                                              } else if (row == 3) {
                                                                  if (col == 0) {
                                                                      item->setText("Time Period");
                                                                  } else if (col == 1) {
                                                                      item->setText("5");
                                                                  }
                                                              } else if (row == 4) {
                                                                  if (col == 0) {
                                                                      item->setText("Tag");
                                                                  } else if (col == 1) {
                                                                      item->setText("P6 Alm 1");
                                                                  }
                                                              } else if (row == 5) {
                                                                  if (col == 0) {
                                                                      item->setText("Allow Change");
                                                                  } else if (col == 1) {
                                                                      item->setText("Enabled");
                                                                  }
                                                              } else if (row == 6) {
                                                                  if (col == 0) {
                                                                      item->setText("Relays out");
                                                                  } else if (col == 1) {
                                                                      item->setText("None");
                                                                  }
                                                              } else if (row == 7) {
                                                                  if (col == 0) {
                                                                      item->setText("Latched");
                                                                  } else if (col == 1) {
                                                                      item->setText("Disabled");
                                                                  }
                                                              } else if (row == 8) {
                                                                  if (col == 0) {
                                                                      item->setText("Change Log");
                                                                  } else if (col == 1) {
                                                                      item->setText("Disabled");
                                                                  }
                                                              } else if (row == 9) {
                                                                  if (col == 0) {
                                                                      item->setText("Mark Chart");
                                                                  } else if (col == 1) {
                                                                      item->setText("Disabled");
                                                                  }
                                                              } else if (row == 10) {
                                                                  if (col == 0) {
                                                                      item->setText("Email Alarm");
                                                                  } else if (col == 1) {
                                                                      item->setText("Disabled");
                                                                  }
                                                              } else if (row == 11) {
                                                                  if (col == 0) {
                                                                      item->setText("Damping");
                                                                  } else if (col == 1) {
                                                                      item->setText("Disabled");
                                                                  }
                                                              } else if (row == 12) {
                                                                  if (col == 0) {
                                                                      item->setText("Damping Time");
                                                                  } else if (col == 1) {
                                                                      item->setText("5 Secs");
                                                                  }
                                                              } else if (row == 13) {
                                                                  if (col == 0) {
                                                                      item->setText("Reflash");
                                                                  } else if (col == 1) {
                                                                      item->setText("Enabled");
                                                                  }
                                                              }

                                                              // Add the item to the model
                                                              alarm_model5->setItem(row, col, item);
                                                          }
                                                      }

                                                      // Set the row heights for all 14 rows
                                                      for (int row = 0; row < 14; ++row) {
                                                          ui->tableView_73->setRowHeight(row, 40);
                                                      }

                                                      alarm_model6 = new QStandardItemModel(15, 2, this);

                                                                 ui->tableView_74->setModel(alarm_model6);

                                                                 ui->tableView_74->setColumnWidth(0, 250);
                                                                 ui->tableView_74->setColumnWidth(1, 400);

                                                                 ui->tableView_74->horizontalHeader()->hide();
                                                                 ui->tableView_74->verticalHeader()->hide();

                                                                 ui->tableView_74->setStyleSheet(
                                                                     "QTableView::item {"
                                                                     "border: 1px solid black;"
                                                                     "border-radius: 5px;"
                                                                     "background-color: rgb(255, 255, 127);"
                                                                     "color: black;"
                                                                     "}"
                                                                 );

                                                                 // Populate the data for each item in the model
                                                                 for (int row = 0; row < 15; ++row) {
                                                                     for (int col = 0; col < 2; ++col) {
                                                                         QStandardItem* item = new QStandardItem();

                                                                         // Set the text for each cell based on your logic
                                                                         if (row == 0) {
                                                                             if (col == 0) {
                                                                                 item->setText("Enabled");
                                                                             } else if (col == 1) {
                                                                                 item->setText("Disabled");
                                                                             }
                                                                         } else if (row == 1) {
                                                                             if (col == 0) {
                                                                                 item->setText("Type");
                                                                             } else if (col == 1) {
                                                                                 item->setText("Low");
                                                                             }
                                                                         } else if (row == 2) {
                                                                             if (col == 0) {
                                                                                 item->setText("Level");
                                                                             } else if (col == 1) {
                                                                                 item->setText("0.0%");
                                                                             }
                                                                         } else if (row == 3) {
                                                                             if (col == 0) {
                                                                                 item->setText("Tag");
                                                                             } else if (col == 1) {
                                                                                 item->setText("P6 Alm 1");
                                                                             }
                                                                         } else if (row == 4) {
                                                                             if (col == 0) {
                                                                                 item->setText("Allow Change");
                                                                             } else if (col == 1) {
                                                                                 item->setText("Enabled");
                                                                             }
                                                                         } else if (row == 5) {
                                                                             if (col == 0) {
                                                                                 item->setText("Relays out");
                                                                             } else if (col == 1) {
                                                                                 item->setText("None");
                                                                             }
                                                                         } else if (row == 6) {
                                                                             if (col == 0) {
                                                                                 item->setText("Latched");
                                                                             } else if (col == 1) {
                                                                                 item->setText("Disabled");
                                                                             }
                                                                         } else if (row == 7) {
                                                                             if (col == 0) {
                                                                                 item->setText("Change Log");
                                                                             } else if (col == 1) {
                                                                                 item->setText("Disabled");
                                                                             }
                                                                         } else if (row == 8) {
                                                                             if (col == 0) {
                                                                                 item->setText("Mark Chart");
                                                                             } else if (col == 1) {
                                                                                 item->setText("Disabled");
                                                                             }
                                                                         } else if (row == 9) {
                                                                             if (col == 0) {
                                                                                 item->setText("Email Alarm");
                                                                             } else if (col == 1) {
                                                                                 item->setText("Disabled");
                                                                             }
                                                                         } else if (row == 10) {
                                                                             if (col == 0) {
                                                                                 item->setText("Hysteresis");
                                                                             } else if (col == 1) {
                                                                                 item->setText("Disabled");
                                                                             }
                                                                         } else if (row == 11) {
                                                                             if (col == 0) {
                                                                                 item->setText("Hyst Level");
                                                                             } else if (col == 1) {
                                                                                 item->setText("2.0%");
                                                                             }
                                                                         } else if (row == 12) {
                                                                             if (col == 0) {
                                                                                 item->setText("Damping");
                                                                             } else if (col == 1) {
                                                                                 item->setText("Disabled");
                                                                             }
                                                                         } else if (row == 13) {
                                                                             if (col == 0) {
                                                                                 item->setText("Damping Time");
                                                                             } else if (col == 1) {
                                                                                 item->setText("5 Secs");
                                                                             }
                                                                         } else if (row == 14) {
                                                                             if (col == 0) {
                                                                                 item->setText("Reflash");
                                                                             } else if (col == 1) {
                                                                                 item->setText("Disabled");
                                                                             }
                                                                         }

                                                                         // Add the item to the model
                                                                         alarm_model6->setItem(row, col, item);
                                                                     }
                                                                 }

                                                                 // Set the row heights for all 15 rows
                                                                 for (int row = 0; row < 15; ++row) {
                                                                     ui->tableView_74->setRowHeight(row, 40);
                                                                 }



                                                                 alarm_model7 = new QStandardItemModel(16, 2, this);

                                                                         ui->tableView_75->setModel(alarm_model7);

                                                                         ui->tableView_75->setColumnWidth(0, 250);
                                                                         ui->tableView_75->setColumnWidth(1, 400);

                                                                         ui->tableView_75->horizontalHeader()->hide();
                                                                         ui->tableView_75->verticalHeader()->hide();

                                                                         ui->tableView_75->setStyleSheet(
                                                                             "QTableView::item {"
                                                                             "border: 1px solid black;"
                                                                             "border-radius: 5px;"
                                                                             "background-color: rgb(255, 255, 127);"
                                                                             "color: black;"
                                                                             "}"
                                                                         );

                                                                         // Populate the data for each item in the model
                                                                         for (int row = 0; row < 16; ++row) {
                                                                             for (int col = 0; col < 2; ++col) {
                                                                                 QStandardItem* item = new QStandardItem();

                                                                                 // Set the text for each cell based on your logic
                                                                                 if (row == 0) {
                                                                                     if (col == 0) {
                                                                                         item->setText("Enabled");
                                                                                     } else if (col == 1) {
                                                                                         item->setText("Disabled");
                                                                                     }
                                                                                 }else if (row == 1) {
                                                                                     if (col == 0) {
                                                                                         item->setText("Enabled by dig");
                                                                                     } else if (col == 1) {
                                                                                         item->setText("None");
                                                                                     }
                                                                                }else if (row == 2) {
                                                                                     if (col == 0) {
                                                                                         item->setText("Type");
                                                                                     } else if (col == 1) {
                                                                                         item->setText("high");
                                                                                     }
                                                                                 } else if (row == 3) {
                                                                                     if (col == 0) {
                                                                                         item->setText("Level");
                                                                                     } else if (col == 1) {
                                                                                         item->setText("0.0%");
                                                                                     }
                                                                                 } else if (row == 4) {
                                                                                     if (col == 0) {
                                                                                         item->setText("Tag");
                                                                                     } else if (col == 1) {
                                                                                         item->setText("P6 Alm 1");
                                                                                     }
                                                                                 } else if (row == 5) {
                                                                                     if (col == 0) {
                                                                                         item->setText("Allow Change");
                                                                                     } else if (col == 1) {
                                                                                         item->setText("Enabled");
                                                                                     }
                                                                                 } else if (row == 6) {
                                                                                     if (col == 0) {
                                                                                         item->setText("Relays out");
                                                                                     } else if (col == 1) {
                                                                                         item->setText("None");
                                                                                     }
                                                                                 } else if (row == 7) {
                                                                                     if (col == 0) {
                                                                                         item->setText("Latched");
                                                                                     } else if (col == 1) {
                                                                                         item->setText("Disabled");
                                                                                     }
                                                                                 } else if (row == 8) {
                                                                                     if (col == 0) {
                                                                                         item->setText("Change Log");
                                                                                     } else if (col == 1) {
                                                                                         item->setText("Disabled");
                                                                                     }
                                                                                 } else if (row == 9) {
                                                                                     if (col == 0) {
                                                                                         item->setText("Mark Chart");
                                                                                     } else if (col == 1) {
                                                                                         item->setText("Disabled");
                                                                                     }
                                                                                 } else if (row == 10){
                                                                                     if (col == 0) {
                                                                                         item->setText("Email Alarm");
                                                                                     } else if (col == 1) {
                                                                                         item->setText("Disabled");
                                                                                     }
                                                                                 } else if (row == 11) {
                                                                                     if (col == 0) {
                                                                                         item->setText("Hysteresis");
                                                                                     } else if (col == 1) {
                                                                                         item->setText("Disabled");
                                                                                     }
                                                                                 } else if (row == 12) {
                                                                                     if (col == 0) {
                                                                                         item->setText("Hyst Level");
                                                                                     } else if (col == 1) {
                                                                                         item->setText("2.0%");
                                                                                     }
                                                                                 } else if (row == 13) {
                                                                                     if (col == 0) {
                                                                                         item->setText("Damping");
                                                                                     } else if (col == 1) {
                                                                                         item->setText("Disabled");
                                                                                     }
                                                                                 } else if (row == 14) {
                                                                                     if (col == 0) {
                                                                                         item->setText("Damping Time");
                                                                                     } else if (col == 1) {
                                                                                         item->setText("5 Secs");
                                                                                     }
                                                                                 } else if (row == 15) {
                                                                                     if (col == 0) {
                                                                                         item->setText("Reflash");
                                                                                     } else if (col == 1) {
                                                                                         item->setText("Disabled");
                                                                                     }
                                                                                 }

                                                                                 // Add the item to the model
                                                                                 alarm_model7->setItem(row, col, item);
                                                                             }
                                                                         }

                                                                         // Set the row heights for all 15 rows
                                                                         for (int row = 0; row < 16; ++row) {
                                                                             ui->tableView_75->setRowHeight(row, 40);
                                                                         }



                                                             screen_model = new QStandardItemModel(6, 2, this);

                                                                 ui->tableView_61->setModel(screen_model);

                                                                 ui->tableView_61->setColumnWidth(0, 250);
                                                                 ui->tableView_61->setColumnWidth(1, 400);

                                                                 ui->tableView_61->horizontalHeader()->hide();
                                                                 ui->tableView_61->verticalHeader()->hide();

                                                                 ui->tableView_61->setStyleSheet(
                                                                     "QTableView::item {"
                                                                     "border: 1px solid black;"
                                                                     "border-radius: 5px;"
                                                                     "background-color: rgb(255, 255, 127);"
                                                                     "color: black;"
                                                                     "}"
                                                                 );

                                                                 // Populate the data for each item in the model
                                                                 for (int row = 0; row < 6; ++row) {
                                                                     for (int col = 0; col < 2; ++col) {
                                                                         QStandardItem *item = new QStandardItem();

                                                                         // Set the text for each cell based on your logic
                                                                         if (row == 0) {
                                                                             if (col == 0) {
                                                                                 item->setText("Enabled");
                                                                             } else if (col == 1) {
                                                                                 item->setText("Disabled");
                                                                             }
                                                                         } else if (row == 1) {
                                                                             if (col == 0) {
                                                                                 item->setText("Timeout");
                                                                             } else if (col == 1) {
                                                                                 item->setText("21 Mins");
                                                                             }
                                                                         } else if (row == 2) {
                                                                             if (col == 0) {
                                                                                 item->setText("Saver Type");
                                                                             } else if (col == 1) {
                                                                                 item->setText("Normal");
                                                                             }
                                                                         } else if (row == 3) {
                                                                             if (col == 0) {
                                                                                 item->setText("Shift Mode");
                                                                             } else if (col == 1) {
                                                                                 item->setText("Between Hours on days");
                                                                             }
                                                                         } else if (row == 4) {
                                                                             if (col == 0) {
                                                                                 item->setText("Dim Saver");
                                                                             } else if (col == 1) {
                                                                                 item->setText("Use Saver Brightness");
                                                                             }
                                                                         } else if (row == 5) {
                                                                             if (col == 0) {
                                                                                 item->setText("Saver Level");
                                                                             } else if (col == 1) {
                                                                                 item->setText("80%");
                                                                             }
                                                                         }

                                                                         // Add the item to the model
                                                                         screen_model->setItem(row, col, item);
                                                                     }
                                                                 }

                                                                 // Set the row heights for all 6 rows
                                                                 for (int row = 0; row < 6; ++row) {
                                                                     ui->tableView_61->setRowHeight(row, 40);
                                                                 }

                                                                 chart_model = new QStandardItemModel(8, 2, this);

                                                                  ui->tableView_62->setModel(chart_model);

                                                                  ui->tableView_62->setColumnWidth(0, 250);
                                                                  ui->tableView_62->setColumnWidth(1, 400);

                                                                  ui->tableView_62->horizontalHeader()->hide();
                                                                  ui->tableView_62->verticalHeader()->hide();

                                                                  ui->tableView_62->setStyleSheet(
                                                                      "QTableView::item {"
                                                                      "border: 1px solid black;"
                                                                      "border-radius: 5px;"
                                                                      "background-color: rgb(255, 255, 127);"
                                                                      "color: black;"
                                                                      "}"
                                                                  );

                                                                  // Populate the data for each item in the model
                                                                  for (int row = 0; row < 8; ++row) {
                                                                      for (int col = 0; col < 2; ++col) {
                                                                          QStandardItem *item = new QStandardItem();

                                                                          // Set the text for each cell based on your logic
                                                                          if (row == 0) {
                                                                              if (col == 0) {
                                                                                  item->setText("Strip Fast Speed");
                                                                              } else if (col == 1) {
                                                                                  item->setText("600mm/h");
                                                                              }
                                                                          } else if (row == 1) {
                                                                              if (col == 0) {
                                                                                  item->setText("Strip Med Speed");
                                                                              } else if (col == 1) {
                                                                                  item->setText("20 mm/h");
                                                                              }
                                                                          } else if (row == 2) {
                                                                              if (col == 0) {
                                                                                  item->setText("Strip slow speed");
                                                                              } else if (col == 1) {
                                                                                  item->setText("5 mm/h");
                                                                              }
                                                                          } else if (row == 3) {
                                                                              if (col == 0) {
                                                                                  item->setText("Circ Fast Speed");
                                                                              } else if (col == 1) {
                                                                                  item->setText("1 hour");
                                                                              }
                                                                          } else if (row == 4) {
                                                                              if (col == 0) {
                                                                                  item->setText("Circ Med Speed");
                                                                              } else if (col == 1) {
                                                                                  item->setText("1 day");
                                                                              }
                                                                          } else if (row == 5) {
                                                                              if (col == 0) {
                                                                                  item->setText("Circ Slow Speed");
                                                                              } else if (col == 1) {
                                                                                  item->setText("5 days");
                                                                              }
                                                                          } else if (row == 6) {
                                                                              if (col == 0) {
                                                                                  item->setText("Hour Alignment");
                                                                              } else if (col == 1) {
                                                                                  item->setText("0");
                                                                              }
                                                                          } else if (row == 7) {
                                                                              if (col == 0) {
                                                                                  item->setText("Day Alignment");
                                                                              } else if (col == 1) {
                                                                                  item->setText("Sun");
                                                                              }
                                                                          }

                                                                          // Add the item to the model
                                                                          chart_model->setItem(row, col, item);
                                                                      }
                                                                  }

                                                                  // Set the row heights for all 8 rows
                                                                  for (int row = 0; row < 8; ++row) {
                                                                      ui->tableView_62->setRowHeight(row, 40);
                                                                  }
                                                                  tabdisplay_model= new QStandardItemModel(3, 2, this);
                                                                  ui->EDIT_SETUP_SCREEN_SETUP_TABULAR_DISPLAY_TableView->setModel(tabdisplay_model);
                                                                  ui->EDIT_SETUP_SCREEN_SETUP_TABULAR_DISPLAY_TableView->setColumnWidth(0, 250);
                                                                  ui->EDIT_SETUP_SCREEN_SETUP_TABULAR_DISPLAY_TableView->setColumnWidth(1, 400);
                                                                  ui->EDIT_SETUP_SCREEN_SETUP_TABULAR_DISPLAY_TableView->horizontalHeader()->hide();
                                                                  ui->EDIT_SETUP_SCREEN_SETUP_TABULAR_DISPLAY_TableView->verticalHeader()->hide();

                                                                  // Set up the stylesheet for tableView_25
                                                                  ui->EDIT_SETUP_SCREEN_SETUP_TABULAR_DISPLAY_TableView->setStyleSheet(
                                                                      "QTableView::item {"
                                                                      "border: 1px solid black;"
                                                                      "border-radius: 5px;"
                                                                      "background-color: rgb(255, 255, 127);"
                                                                      "color: black;"
                                                                      "}"
                                                                      "QTableView::item[selected='true'] {"
                                                                      "background-color: gray;"
                                                                      "color: black;"
                                                                      "}"
                                                                  );

                                                                  QStringList updateMethodData = {"Update Method", "Periodic"};
                                                                  QStringList periodicData = {"Update Period", "10 Secs"}; // Leave the second column empty for the second row
                                                                  QStringList alignmentEnabledData = {"Alignment ", "Enabled"}; // Leave the second column empty for the third row

                                                                  QList<QStringList> Tabular_Data = {updateMethodData, periodicData, alignmentEnabledData};

                                                                  for (int row = 0; row < 3; ++row) {
                                                                      for (int col = 0; col < 2; ++col) {
                                                                          QModelIndex index = tabdisplay_model->index(row, col, QModelIndex());
                                                                          tabdisplay_model->setData(index, Tabular_Data[row][col]);
                                                                      }
                                                                  }

                                                                  for (int i = 0; i < 3; ++i) {
                                                                      ui->EDIT_SETUP_SCREEN_SETUP_TABULAR_DISPLAY_TableView->setRowHeight(i, 40);
                                                                  }







                                                                  localization_model = new QStandardItemModel(7, 2, this);
                                                                  ui->tableView_60->setModel(localization_model);

                                                                  // Set column widths if needed
                                                                  ui->tableView_60->setColumnWidth(0, 250);
                                                                  ui->tableView_60->setColumnWidth(1, 400);

                                                                  // Optionally hide horizontal and vertical headers
                                                                  ui->tableView_60->horizontalHeader()->hide();
                                                                  ui->tableView_60->verticalHeader()->hide();

                                                                  // Set up the stylesheet for tableView_25
                                                                  ui->tableView_60->setStyleSheet(
                                                                      "QTableView::item {"
                                                                      "border: 1px solid black;"
                                                                      "border-radius: 5px;"
                                                                      "background-color: rgb(255, 255, 127);"
                                                                      "color: black;"
                                                                      "}"
                                                                      "QTableView::item[selected='true'] {"
                                                                      "background-color: gray;"
                                                                      "color: black;"
                                                                      "}"
                                                                  );

                                                                  // Define your data for the new table (7 rows and 2 columns)
                                                                  QList<QStringList> Tabular_Data25 = {
                                                                      {"Language", "English(US)"},
                                                                      {"Help Language", "English"},
                                                                      {"Time Zone", "(GMT-5:00) Eastern Time(US&Canada)"},
                                                                      {"Daylight saving", "Enabled"},
                                                                      {"Temp.Units", "Deg C"},
                                                                      {"Line Hz", "50Hz"},
                                                                      {"Paper Size", "A4"}
                                                                  };

                                                                  // Populate the new model with data
                                                                  for (int row = 0; row < 7; ++row) {
                                                                      for (int col = 0; col < 2; ++col) {
                                                                          QModelIndex index = localization_model->index(row, col, QModelIndex());
                                                                          localization_model->setData(index, Tabular_Data25[row][col]);
                                                                      }
                                                                  }

                                                                  // Set row heights if needed
                                                                  for (int i = 0; i < 7; ++i) {
                                                                      ui->tableView_60->setRowHeight(i, 40);
                                                                  }


                                                                  credit_model = new QStandardItemModel(4, 2, this);
                                                                  ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_3->setModel(credit_model);
                                                                  ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_3->setColumnWidth(0, 250);
                                                                  ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_3->setColumnWidth(1, 400);
                                                                  ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_3->horizontalHeader()->hide();
                                                                  ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_3->verticalHeader()->hide();

                                                                  // Set up the stylesheet for tableView_23
                                                                  ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_3->setStyleSheet(
                                                                      "QTableView::item {"
                                                                      "border: 1px solid black;"
                                                                      "border-radius: 5px;"
                                                                      "background-color: rgb(255, 255, 127);"
                                                                      "color: black;"
                                                                      "}"
                                                                      "QTableView::item[selected='true'] {"
                                                                      "background-color: gray;"
                                                                      "color: black;"
                                                                      "}"
                                                                  );

                                                                  // Set the data for each item in the model
                                                                  QStringList row1Data_23 = {"Serial No", "999999"};
                                                                  QStringList row2Data_23 = {"Credits", "0"};
                                                                  QStringList row3Data_23 = {"Options Code", "999999000088848"};
                                                                  QStringList row4Data_23 = {"Options", "0 Credits in use"};

                                                                  QList<QStringList> rowData_23 = {row1Data_23, row2Data_23, row3Data_23, row4Data_23};

                                                                  for (int row = 0; row < 4; ++row) {
                                                                      for (int col = 0; col < 2; ++col) {
                                                                          QModelIndex index = credit_model->index(row, col, QModelIndex());
                                                                          QStandardItem *my_item = credit_model->itemFromIndex(index);

                                                                          // Set the values for each column
                                                                          credit_model->setData(index, rowData_23[row][col]);


                                                                      }
                                                                  }
                                                                  for (int i = 0; i < 4; ++i) {
                                                                      ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_3->setRowHeight(i, 40);
                                                                     }

                                                                  // Create a new model (model16) for tableView_25
                                                                  sntp_model = new QStandardItemModel(5, 2, this);
                                                                  ui->tableView_41->setModel(sntp_model);
                                                                  ui->tableView_41->setColumnWidth(0, 250);
                                                                  ui->tableView_41->setColumnWidth(1, 400);
                                                                  ui->tableView_41->horizontalHeader()->hide();
                                                                  ui->tableView_41->verticalHeader()->hide();

                                                                  // Set up the stylesheet for tableView_25
                                                                  ui->tableView_41->setStyleSheet(
                                                                      "QTableView::item {"
                                                                      "border: 1px solid black;"
                                                                      "border-radius: 5px;"
                                                                      "background-color: rgb(255, 255, 127);"
                                                                      "color: black;"
                                                                      "}"
                                                                      "QTableView::item[selected='true'] {"
                                                                      "background-color: gray;"
                                                                      "color: black;"
                                                                      "}"
                                                                  );

                                                                  // Set the data for each item in the model
                                                                  QStringList serverEnableData = {"Server Enable", "Disabled"};
                                                                  QStringList ClientEnable= {"Client Enable","Disabled"};
                                                                  QStringList serverNameData = {"Server Name","Time Server"};
                                                                  QStringList PeriodData = {"Period","3600 Secs"};
                                                                  QStringList ThresholdData = {"Threshold","3600 Secs"};

                                                                  QList<QStringList> ServerData = {serverEnableData, ClientEnable, serverNameData, PeriodData, ThresholdData};

                                                                  for (int row = 0; row < 5; ++row) {
                                                                      for (int col = 0; col < 2; ++col) {
                                                                          QModelIndex index = sntp_model->index(row, col, QModelIndex());
                                                                          sntp_model->setData(index, ServerData[row][col]);
                                                                      }
                                                                  }
                                                                  for (int i = 0; i < 5; ++i) {
                                                                      ui->tableView_41->setRowHeight(i, 40);
                                                                     }





                                                                  // Create a new model (policy_model) for EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_4
                                                                  policy_model = new QStandardItemModel(22, 2, this);
                                                                  ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_4->setModel(policy_model);

                                                                  // Set the column widths (adjust these as needed)
                                                                  ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_4->setColumnWidth(0, 250);
                                                                  ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_4->setColumnWidth(1, 400);

                                                                  // Hide horizontal and vertical headers
                                                                  ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_4->horizontalHeader()->hide();
                                                                  ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_4->verticalHeader()->hide();

                                                                  // Set up the stylesheet for EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_4 (adjust as needed)
                                                                  ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_4->setStyleSheet(
                                                                      "QTableView::item {"
                                                                      "border: 1px solid black;"
                                                                      "border-radius: 5px;"
                                                                      "background-color: rgb(255, 255, 127);"
                                                                      "color: black;"
                                                                      "}"
                                                                      "QTableView::item[selected='true'] {"
                                                                      "background-color: gray;"
                                                                      "color: black;"
                                                                      "}"
                                                                  );

                                                                  // Populate the data for each item in the model
                                                                  for (int row = 0; row < 22; ++row) {
                                                                      for (int col = 0; col < 2; ++col) {
                                                                          QStandardItem* item = new QStandardItem();

                                                                          if (row == 0) {
                                                                              if (col == 0) {
                                                                                  item->setText("Pwds Enable");
                                                                              } else if (col == 1) {
                                                                                  item->setText("Disabled");
                                                                              }
                                                                          } else if (row == 1) {
                                                                              if (col == 0) {
                                                                                  item->setText("Level 0 Name");
                                                                              } else if (col == 1) {
                                                                                  item->setText("Administrator");
                                                                              }
                                                                          } else if (row == 2) {
                                                                              if (col == 0) {
                                                                                  item->setText("Level 01 Name");
                                                                              } else if (col == 1) {
                                                                                  item->setText("Engineer");
                                                                              }
                                                                          } else if (row == 3) {
                                                                              if (col == 0) {
                                                                                  item->setText("Level 2 Name");
                                                                              } else if (col == 1) {
                                                                                  item->setText("Supervisor");
                                                                              }
                                                                          } else if (row == 4) {
                                                                              if (col == 0) {
                                                                                  item->setText("Level 3 Name");
                                                                              } else if (col == 1) {
                                                                                  item->setText("Technician");
                                                                              }
                                                                          } else if (row == 5) {
                                                                              if (col == 0) {
                                                                                  item->setText("Level 4 Name");
                                                                              } else if (col == 1) {
                                                                                  item->setText("Operator");
                                                                              }
                                                                          } else if (row == 6) {
                                                                              if (col == 0) {
                                                                                  item->setText("Unrestrict");
                                                                              } else if (col == 1) {
                                                                                  item->setText("Override Restricted Access");
                                                                              }
                                                                          } else if (row == 7) {
                                                                              if (col == 0) {
                                                                                  item->setText("Menutimeout");
                                                                              } else if (col == 1) {
                                                                                  item->setText("Enabled");
                                                                              }
                                                                          } else if (row == 8) {
                                                                              if (col == 0) {
                                                                                  item->setText("Menu Timeout");
                                                                              } else if (col == 1) {
                                                                                  item->setText("1000 seconds");
                                                                              }
                                                                          } else if (row == 9) {
                                                                              if (col == 0) {
                                                                                  item->setText("Web Timeout");
                                                                              } else if (col == 1) {
                                                                                  item->setText("Enabled");
                                                                              }
                                                                          } else {
                                                                              item->setText("Row " + QString::number(row) + " Column " + QString::number(col + 1));
                                                                          }

                                                                          policy_model->setItem(row, col, item);
                                                                      }
                                                                  }

                                                                  // Set row heights (adjust as needed)
                                                                  for (int i = 0; i < 22; ++i) {
                                                                      ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_4->setRowHeight(i, 40);
                                                                  }




                                                                  // Create a QStandardItemModel with 1 row and 2 columns
                                                                  user_model= new QStandardItemModel(1, 2, this);

                                                                  // Set the model for the EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_5
                                                                  ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_5->setModel(user_model);

                                                                  // Set the column widths (adjust these as needed)
                                                                  ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_5->setColumnWidth(0, 250);
                                                                  ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_5->setColumnWidth(1, 400);

                                                                  // Hide horizontal and vertical headers
                                                                  ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_5->horizontalHeader()->hide();
                                                                  ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_5->verticalHeader()->hide();

                                                                  // Set up the stylesheet for EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_5 (adjust as needed)
                                                                  ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_5->setStyleSheet(
                                                                      "QTableView::item {"
                                                                      "border: 1px solid black;"
                                                                      "border-radius: 5px;"
                                                                      "background-color: rgb(255, 255, 127);"
                                                                      "color: black;"
                                                                      "}"
                                                                      "QTableView::item[selected='true'] {"
                                                                      "background-color: gray;"
                                                                      "color: black;"
                                                                      "}"
                                                                  );

                                                                  // Create data for the single row
                                                                  QStringList rowData_1 = {"Add New User", "<Your Data Here>"};

                                                                  // Populate the single row with data
                                                                  for (int col = 0; col < 2; ++col) {
                                                                      QModelIndex index = user_model->index(0, col, QModelIndex());
                                                                      user_model->setData(index, rowData_1[col]);
                                                                  }

                                                                  // Set row height for the single row (adjust as needed)
                                                                  ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_5->setRowHeight(0, 40);

                                                                  //QString user_name = userEnteredValue; // Replace with the actual user name

                                                                  // Create data for the two rows
                                                                  QStringList rowData_n = {"User Name", ""};
                                                                  QStringList rowData_2 = {"User Level", "Engineer"};



                                                                  // Create a new QStandardItemModel for  EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_6
                                                                 newuser_model = new QStandardItemModel(2, 2, this);

                                                                  // Set the model for  EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_6
                                                                  ui-> EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_6->setModel(newuser_model);

                                                                  // Set the column widths (adjust these as needed)
                                                                  ui-> EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_6->setColumnWidth(0, 250);
                                                                  ui-> EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_6->setColumnWidth(1, 400);

                                                                  // Hide horizontal and vertical headers
                                                                  ui-> EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_6->horizontalHeader()->hide();
                                                                  ui-> EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_6->verticalHeader()->hide();

                                                                  // Set up the stylesheet for  EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_6 (adjust as needed)
                                                                  ui-> EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_6->setStyleSheet(
                                                                      "QTableView::item {"
                                                                      "border: 1px solid black;"
                                                                      "border-radius: 5px;"
                                                                      "background-color: rgb(255, 255, 127);"
                                                                      "color: black;"
                                                                      "}"
                                                                      "QTableView::item[selected='true'] {"
                                                                      "background-color: gray;"
                                                                      "color: black;"
                                                                      "}"
                                                                  );

                                                                  // Populate the first row with data
                                                                  for (int col = 0; col < 2; ++col) {
                                                                      QModelIndex index =newuser_model->index(0, col, QModelIndex());
                                                                     newuser_model->setData(index, rowData_1[col]);
                                                                  }

                                                                  // Populate the second row with data
                                                                  for (int col = 0; col < 2; ++col) {
                                                                      QModelIndex index =newuser_model->index(1, col, QModelIndex());
                                                                     newuser_model->setData(index, rowData_2[col]);
                                                                  }

                                                                  // Set row heights for both rows (adjust as needed)
                                                                  ui-> EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_6->setRowHeight(0, 40);
                                                                  ui-> EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_6->setRowHeight(1, 40);


                                                                  engineer_model = new QStandardItemModel(49, 2, this);

                                                                  // Set the model for tableView_28
                                                                  ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_7->setModel(engineer_model);

                                                                  // Set the column widths (adjust these as needed)
                                                                  ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_7->setColumnWidth(0, 250);
                                                                  ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_7->setColumnWidth(1, 400);

                                                                  // Hide horizontal and vertical headers
                                                                  ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_7->horizontalHeader()->hide();
                                                                  ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_7->verticalHeader()->hide();

                                                                  // Set up the stylesheet for tableView_28 (adjust as needed)
                                                                  ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_7->setStyleSheet(
                                                                      "QTableView::item {"
                                                                      "border: 1px solid black;"
                                                                      "border-radius: 5px;"
                                                                      "background-color: rgb(255, 255, 127);"
                                                                      "color: black;"
                                                                      "}"
                                                                      "QTableView::item[selected='true'] {"
                                                                      "background-color: gray;"
                                                                      "color: black;"
                                                                      "}"
                                                                  );

                                                                  // Populate the engineer_model with data
                                                                  for (int row = 0; row < 49; ++row) {
                                                                      for (int col = 0; col < 2; ++col) {
                                                                          QModelIndex index = engineer_model->index(row, col, QModelIndex());

                                                                          QString defaultData = "Default Data";
                                                                          engineer_model->setData(index, defaultData);
                                                                      }
                                                                  }








                                                                  supervisor_model = new QStandardItemModel(49, 2, this);

                                                                  // Set the model for tableView_28
                                                                  ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_8->setModel(supervisor_model);

                                                                  // Set the column widths (adjust these as needed)
                                                                  ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_8->setColumnWidth(0, 250);
                                                                  ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_8->setColumnWidth(1, 400);

                                                                  // Hide horizontal and vertical headers
                                                                  ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_8->horizontalHeader()->hide();
                                                                  ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_8->verticalHeader()->hide();
                                                                  // Set up the stylesheet for tableView_28 (adjust as needed)
                                                                  ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_8->setStyleSheet(
                                                                      "QTableView::item {"
                                                                      "border: 1px solid black;"
                                                                      "border-radius: 5px;"
                                                                      "background-color: rgb(255, 255, 127);"
                                                                      "color: black;"
                                                                      "}"
                                                                      "QTableView::item[selected='true'] {"
                                                                      "background-color: gray;"
                                                                      "color: black;"
                                                                      "}"
                                                                  );

                                                                  // Populate the engineer_model with data
                                                                  for (int row = 0; row < 49; ++row) {
                                                                      for (int col = 0; col < 2; ++col) {
                                                                          QModelIndex index = supervisor_model->index(row, col, QModelIndex());

                                                                          QString defaultData = "Default Data";
                                                                         supervisor_model->setData(index, defaultData);
                                                                      }
                                                                  }





                                                                   technician_model = new QStandardItemModel(49, 2, this);

                                                                    // Set the model for tableView_28
                                                                    ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_9->setModel(supervisor_model);

                                                                    // Set the column widths (adjust these as needed)
                                                                    ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_9->setColumnWidth(0, 250);
                                                                    ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_9->setColumnWidth(1, 400);

                                                                    // Hide horizontal and vertical headers
                                                                    ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_9->horizontalHeader()->hide();
                                                                    ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_9->verticalHeader()->hide();
                                                                    // Set up the stylesheet for tableView_28 (adjust as needed)
                                                                    ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_9->setStyleSheet(
                                                                        "QTableView::item {"
                                                                        "border: 1px solid black;"
                                                                        "border-radius: 5px;"
                                                                        "background-color: rgb(255, 255, 127);"
                                                                        "color: black;"
                                                                        "}"
                                                                        "QTableView::item[selected='true'] {"
                                                                        "background-color: gray;"
                                                                        "color: black;"
                                                                        "}"
                                                                    );

                                                                    // Populate the engineer_model with data
                                                                    for (int row = 0; row < 49; ++row) {
                                                                        for (int col = 0; col < 2; ++col) {
                                                                            QModelIndex index =technician_model->index(row, col, QModelIndex());

                                                                            QString defaultData = "Default Data";
                                                                          technician_model->setData(index, defaultData);
                                                                        }
                                                                    }




                                                                    operator_model = new QStandardItemModel(49, 2, this);

                                                                     // Set the model for tableView_28
                                                                     ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_10->setModel( operator_model);

                                                                     // Set the column widths (adjust these as needed)
                                                                     ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_10->setColumnWidth(0, 250);
                                                                     ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_10->setColumnWidth(1, 400);

                                                                     // Hide horizontal and vertical headers
                                                                     ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_10->horizontalHeader()->hide();
                                                                     ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_10->verticalHeader()->hide();
                                                                     // Set up the stylesheet for tableView_28 (adjust as needed)
                                                                     ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_10->setStyleSheet(
                                                                         "QTableView::item {"
                                                                         "border: 1px solid black;"
                                                                         "border-radius: 5px;"
                                                                         "background-color: rgb(255, 255, 127);"
                                                                         "color: black;"
                                                                         "}"
                                                                         "QTableView::item[selected='true'] {"
                                                                         "background-color: gray;"
                                                                         "color: black;"
                                                                         "}"
                                                                     );

                                                                     // Populate the engineer_model with data
                                                                     for (int row = 0; row < 49; ++row) {
                                                                         for (int col = 0; col < 2; ++col) {
                                                                             QModelIndex index = operator_model->index(row, col, QModelIndex());

                                                                             QString defaultData = "Default Data";
                                                                            operator_model->setData(index, defaultData);
                                                                         }
                                                                     }






                                                                     marker_model = new QStandardItemModel(20, 2, this);

                                                                     ui->tableView_25->setModel(marker_model);

                                                                     ui->tableView_25->setColumnWidth(0, 250);
                                                                     ui->tableView_25->setColumnWidth(1, 400);

                                                                     ui->tableView_25->horizontalHeader()->hide();
                                                                     ui->tableView_25->verticalHeader()->hide();

                                                                     ui->tableView_25->setStyleSheet(
                                                                         "QTableView::item {"
                                                                         "border: 1px solid black;"
                                                                         "border-radius: 5px;"
                                                                         "background-color: rgb(255, 255, 127);"
                                                                         "color: black;"
                                                                         "}"
                                                                     );

                                                                     // Populate the data for each item in the model
                                                                     for (int row = 0; row < 20; ++row) {
                                                                         QStandardItem *item = new QStandardItem();

                                                                         // Set the text for column 0
                                                                         item->setText(QString("Marker %1").arg(row + 1));
                                                                         marker_model->setItem(row, 0, item);

                                                                         // Leave column 1 empty
                                                                         marker_model->setItem(row, 1, new QStandardItem());
                                                                     }

                                                                     // Set the row heights for all 20 rows
                                                                     for (int row = 0; row < 20; ++row) {
                                                                         ui->tableView_25->setRowHeight(row, 40);
                                                                     }





                                                                     timesync_model = new QStandardItemModel(3, 2, this);

                                                                     ui->tableView_76->setModel(timesync_model);

                                                                     ui->tableView_76->setColumnWidth(0, 250);
                                                                     ui->tableView_76->setColumnWidth(1, 400);

                                                                     ui->tableView_76->horizontalHeader()->hide();
                                                                     ui->tableView_76->verticalHeader()->hide();

                                                                     ui->tableView_76->setStyleSheet(
                                                                         "QTableView::item {"
                                                                         "border: 1px solid black;"
                                                                         "border-radius: 5px;"
                                                                         "background-color: rgb(255, 255, 127);"
                                                                         "color: black;"
                                                                         "}"
                                                                     );

                                                                     for (int row = 0; row < 3; ++row) {
                                                                         for (int col = 0; col < 2; ++col) {
                                                                             QStandardItem *item = new QStandardItem();


                                                                             if (row == 0) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Enabled");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Enabled");
                                                                                 }
                                                                             } else if (row == 1) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Trigger");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("ON");
                                                                                 }
                                                                             } else if (row == 2) {

                                                                                 if (col == 0) {
                                                                                     item->setText("Digital Input");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("1");
                                                                                 }
                                                                             }

                                                                             // Add the item to the timesync_model
                                                                             timesync_model->setItem(row, col, item);
                                                                         }
                                                                     }

                                                                     // Set the row heights for all 3 rows
                                                                     for (int row = 0; row < 3; ++row) {
                                                                         ui->tableView_76->setRowHeight(row, 40);
                                                                     }








                                                                     event_model = new QStandardItemModel(20, 2, this);

                                                                     ui->tableView_77->setModel(event_model);

                                                                     ui->tableView_77->setColumnWidth(0, 250);
                                                                     ui->tableView_77->setColumnWidth(1, 400);

                                                                     ui->tableView_77->horizontalHeader()->hide();
                                                                     ui->tableView_77->verticalHeader()->hide();

                                                                     ui->tableView_77->setStyleSheet(
                                                                         "QTableView::item {"
                                                                         "border: 1px solid black;"
                                                                         "border-radius: 5px;"
                                                                         "background-color: rgb(255, 255, 127);"
                                                                         "color: black;"
                                                                         "}"
                                                                     );

                                                                     for (int row = 0; row < 20; ++row) {
                                                                         QStandardItem *eventItem = new QStandardItem();

                                                                         eventItem->setText(QString("Event %1").arg(row + 1));
                                                                         event_model->setItem(row, 0, eventItem);

                                                                         QStandardItem *incrementItem = new QStandardItem();
                                                                         incrementItem->setText(QString("Event %1").arg(row + 1));
                                                                         event_model->setItem(row, 1, incrementItem);
                                                                     }

                                                                     for (int row = 0; row < 20; ++row) {
                                                                         ui->tableView_77->setRowHeight(row, 40);
                                                                     }






                                                                     counter_model = new QStandardItemModel(16, 2, this);

                                                                     ui->tableView_79->setModel(counter_model);

                                                                     ui->tableView_79->setColumnWidth(0, 250);
                                                                     ui->tableView_79->setColumnWidth(1, 400);

                                                                     ui->tableView_79->horizontalHeader()->hide();
                                                                     ui->tableView_79->verticalHeader()->hide();

                                                                     ui->tableView_79->setStyleSheet(
                                                                         "QTableView::item {"
                                                                         "border: 1px solid black;"
                                                                         "border-radius: 5px;"
                                                                         "background-color: rgb(255, 255, 127);"
                                                                         "color: black;"
                                                                         "}"
                                                                     );

                                                                     for (int row = 0; row < 16; ++row) {
                                                                         QStandardItem *eventItem = new QStandardItem();

                                                                         eventItem->setText(QString("Counter %1").arg(row + 1));
                                                                         counter_model->setItem(row, 0, eventItem);

                                                                         QStandardItem *incrementItem = new QStandardItem();
                                                                         incrementItem->setText(QString("Counter %1").arg(row + 1));
                                                                         counter_model->setItem(row, 1, incrementItem);
                                                                     }

                                                                     for (int row = 0; row < 16; ++row) {
                                                                         ui->tableView_79->setRowHeight(row, 40);
                                                                     }



                                                                     // Create a new model (policy_model) for EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_4
                                                                     peers_model = new QStandardItemModel(4, 2, this);
                                                                     ui->tableView_43->setModel(peers_model);

                                                                     // Set the column widths (adjust these as needed)
                                                                     ui->tableView_43->setColumnWidth(0, 250);
                                                                     ui->tableView_43->setColumnWidth(1, 400);

                                                                     // Hide horizontal and vertical headers
                                                                     ui->tableView_43->horizontalHeader()->hide();
                                                                     ui->tableView_43->verticalHeader()->hide();

                                                                     // Set up the stylesheet for EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_4 (adjust as needed)
                                                                     ui->tableView_43->setStyleSheet(
                                                                         "QTableView::item {"
                                                                         "border: 1px solid black;"
                                                                         "border-radius: 5px;"
                                                                         "background-color: rgb(255, 255, 127);"
                                                                         "color: black;"
                                                                         "}"
                                                                         "QTableView::item[selected='true'] {"
                                                                         "background-color: gray;"
                                                                         "color: black;"
                                                                         "}"
                                                                     );

                                                                     // Populate the data for each item in the model
                                                                     for (int row = 0; row < 4; ++row) {
                                                                         for (int col = 0; col < 2; ++col) {
                                                                             QStandardItem* item = new QStandardItem();

                                                                             if (row == 0) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Enabled");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Disabled");
                                                                                 }
                                                                             } else if (row == 1) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Set Number");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("3");
                                                                                 }
                                                                             } else if (row == 2) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Start Port");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("8955");
                                                                                 }
                                                                             } else if (row == 3) {
                                                                                 if (col == 0) {
                                                                                     item->setText("End Port");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("8970");
                                                                                 }
                                                                             }
                                                                             // Add the item to the timesync_model
                                                                             peers_model->setItem(row, col, item);
                                                                         }
                                                                     }

                                                                     // Set the row heights for all 3 rows
                                                                     for (int row = 0; row < 4; ++row) {
                                                                         ui->tableView_43->setRowHeight(row, 40);
                                                                     }


                                                                     web_model = new QStandardItemModel(1, 2, this);
                                                                     ui->tableView_web->setModel(web_model);

                                                                     // Set the column widths (adjust these as needed)
                                                                     ui->tableView_web->setColumnWidth(0, 250);
                                                                     ui->tableView_web->setColumnWidth(1, 400);

                                                                     // Hide horizontal and vertical headers
                                                                     ui->tableView_web->horizontalHeader()->hide();
                                                                     ui->tableView_web->verticalHeader()->hide();

                                                                     // Set up the stylesheet for tableView_web (adjust as needed)
                                                                     ui->tableView_web->setStyleSheet(
                                                                         "QTableView::item {"
                                                                         "border: 1px solid black;"
                                                                         "border-radius: 5px;"
                                                                         "background-color: rgb(255, 255, 127);"
                                                                         "color: black;"
                                                                         "}"
                                                                         "QTableView::item[selected='true'] {"
                                                                         "background-color: gray;"
                                                                         "color: black;"
                                                                         "}"
                                                                     );

                                                                     // Populate the data for each item in the model
                                                                     for (int col = 0; col < 2; ++col) {
                                                                         QStandardItem* item = new QStandardItem();

                                                                         if (col == 0) {
                                                                             item->setText("Enabled");
                                                                         } else if (col == 1) {
                                                                             item->setText("Disabled");
                                                                         }

                                                                         // Add the item to the web_model
                                                                         web_model->setItem(0, col, item);
                                                                     }

                                                                     // Set the row height for the single row
                                                                     ui->tableView_web->setRowHeight(0, 40);




                                                                     network_model = new QStandardItemModel(5, 2, this);
                                                                     ui->EDIT_SETUP_COMMS_NETWORK_ADMIN_Config_Table->setModel(network_model);

                                                                     // Set the column widths (adjust these as needed)
                                                                     ui->EDIT_SETUP_COMMS_NETWORK_ADMIN_Config_Table->setColumnWidth(0, 250);
                                                                     ui->EDIT_SETUP_COMMS_NETWORK_ADMIN_Config_Table->setColumnWidth(1, 400);

                                                                     // Hide horizontal and vertical headers
                                                                     ui->EDIT_SETUP_COMMS_NETWORK_ADMIN_Config_Table->horizontalHeader()->hide();
                                                                     ui->EDIT_SETUP_COMMS_NETWORK_ADMIN_Config_Table->verticalHeader()->hide();

                                                                     // Set up the stylesheet for EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_4 (adjust as needed)
                                                                     ui->EDIT_SETUP_COMMS_NETWORK_ADMIN_Config_Table->setStyleSheet(
                                                                         "QTableView::item {"
                                                                         "border: 1px solid black;"
                                                                         "border-radius: 5px;"
                                                                         "background-color: rgb(255, 255, 127);"
                                                                         "color: black;"
                                                                         "}"
                                                                         "QTableView::item[selected='true'] {"
                                                                         "background-color: gray;"
                                                                         "color: black;"
                                                                         "}"
                                                                     );

                                                                     // Populate the data for each item in the model
                                                                     for (int row = 0; row < 5; ++row) {
                                                                         for (int col = 0; col < 2; ++col) {
                                                                             QStandardItem* item = new QStandardItem();

                                                                             if (row == 0) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Username");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Not set");
                                                                                 }
                                                                             } else if (row == 1) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Password");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("********");
                                                                                 }
                                                                             } else if (row == 2) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Domain");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Not set");
                                                                                 }
                                                                             } else if (row == 3) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Use share path");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Enabled");
                                                                                 }
                                                                             }else if (row == 4) {
                                                                                 if (col == 0) {
                                                                                     item->setText("share path");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Not set");
                                                                                 }
                                                                             }
                                                                             // Add the item to the timesync_model
                                                                             network_model->setItem(row, col, item);
                                                                         }
                                                                     }

                                                                     // Set the row heights for all 3 rows
                                                                     for (int row = 0; row < 5; ++row) {
                                                                         ui->EDIT_SETUP_COMMS_NETWORK_ADMIN_Config_Table->setRowHeight(row, 40);
                                                                     }




                                                                     // Create a new model (policy_model) for EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_4
                                                                     security_model = new QStandardItemModel(4, 2, this);
                                                                     ui->EDIT_SETUP_COMMS_SECURITY_OPTIONS_Config_Table->setModel(security_model);

                                                                     // Set the column widths (adjust these as needed)
                                                                     ui->EDIT_SETUP_COMMS_SECURITY_OPTIONS_Config_Table->setColumnWidth(0, 250);
                                                                     ui->EDIT_SETUP_COMMS_SECURITY_OPTIONS_Config_Table->setColumnWidth(1, 400);

                                                                     // Hide horizontal and vertical headers
                                                                     ui->EDIT_SETUP_COMMS_SECURITY_OPTIONS_Config_Table->horizontalHeader()->hide();
                                                                     ui->EDIT_SETUP_COMMS_SECURITY_OPTIONS_Config_Table->verticalHeader()->hide();

                                                                     // Set up the stylesheet for EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_4 (adjust as needed)
                                                                     ui->EDIT_SETUP_COMMS_SECURITY_OPTIONS_Config_Table->setStyleSheet(
                                                                         "QTableView::item {"
                                                                         "border: 1px solid black;"
                                                                         "border-radius: 5px;"
                                                                         "background-color: rgb(255, 255, 127);"
                                                                         "color: black;"
                                                                         "}"
                                                                         "QTableView::item[selected='true'] {"
                                                                         "background-color: gray;"
                                                                         "color: black;"
                                                                         "}"
                                                                     );

                                                                     // Populate the data for each item in the model
                                                                     for (int row = 0; row < 4; ++row) {
                                                                         for (int col = 0; col < 2; ++col) {
                                                                             QStandardItem* item = new QStandardItem();

                                                                             if (row == 0) {
                                                                                 if (col == 0) {
                                                                                     item->setText("TLS Version");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("TLS 1.2");
                                                                                 }
                                                                             } else if (row == 1) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Custom Certificate");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Enabled");
                                                                                 }
                                                                             } else if (row == 2) {
                                                                                 if (col == 0) {
                                                                                     item->setText("CERT Password");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("********");
                                                                                 }
                                                                             } else if (row == 3) {
                                                                                 if (col == 0) {
                                                                                     item->setText("RDT");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Enabled");
                                                                                 }
                                                                             }
                                                                             // Add the item to the timesync_model
                                                                             security_model->setItem(row, col, item);
                                                                         }
                                                                     }

                                                                     // Set the row heights for all 3 rows
                                                                     for (int row = 0; row < 4; ++row) {
                                                                         ui->EDIT_SETUP_COMMS_SECURITY_OPTIONS_Config_Table->setRowHeight(row, 40);
                                                                     }




                                                                     identity_model = new QStandardItemModel(3, 2, this);

                                                                     ui->EDIT_LAYOUT_SCREENS_SCREEN_Config_Table_2->setModel(identity_model);

                                                                     ui->EDIT_LAYOUT_SCREENS_SCREEN_Config_Table_2->setColumnWidth(0, 250);
                                                                     ui->EDIT_LAYOUT_SCREENS_SCREEN_Config_Table_2->setColumnWidth(1, 400);

                                                                     ui->EDIT_LAYOUT_SCREENS_SCREEN_Config_Table_2->horizontalHeader()->hide();
                                                                     ui->EDIT_LAYOUT_SCREENS_SCREEN_Config_Table_2->verticalHeader()->hide();

                                                                     ui->EDIT_LAYOUT_SCREENS_SCREEN_Config_Table_2->setStyleSheet(
                                                                         "QTableView::item {"
                                                                         "border: 1px solid black;"
                                                                         "border-radius: 5px;"
                                                                         "background-color: rgb(255, 255, 127);"
                                                                         "color: black;"
                                                                         "}"
                                                                     );

                                                                     for (int row = 0; row < 3; ++row) {
                                                                         for (int col = 0; col < 2; ++col) {
                                                                             QStandardItem *item = new QStandardItem();


                                                                             if (row == 0) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Name");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Multitrend GR");
                                                                                 }
                                                                             } else if (row == 1) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Description");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Honeywell GR-Series Recorder");
                                                                                 }
                                                                             } else if (row == 2) {

                                                                                 if (col == 0) {
                                                                                     item->setText("ID");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("1");
                                                                                 }
                                                                             }

                                                                             // Add the item to the timesync_model
                                                                             identity_model->setItem(row, col, item);
                                                                         }
                                                                     }

                                                                     // Set the row heights for all 3 rows
                                                                     for (int row = 0; row < 3; ++row) {
                                                                         ui->EDIT_LAYOUT_SCREENS_SCREEN_Config_Table_2->setRowHeight(row, 40);
                                                                     }



                                                                     erroralert_model = new QStandardItemModel(6, 2, this);
                                                                     ui->EDIT_SETUP_GENERAL_ERROR_ALERT_Config_Table->setModel(erroralert_model);

                                                                     // Set the column widths (adjust these as needed)
                                                                     ui->EDIT_SETUP_GENERAL_ERROR_ALERT_Config_Table->setColumnWidth(0, 250);
                                                                     ui->EDIT_SETUP_GENERAL_ERROR_ALERT_Config_Table->setColumnWidth(1, 400);

                                                                     // Hide horizontal and vertical headers
                                                                     ui->EDIT_SETUP_GENERAL_ERROR_ALERT_Config_Table->horizontalHeader()->hide();
                                                                     ui->EDIT_SETUP_GENERAL_ERROR_ALERT_Config_Table->verticalHeader()->hide();

                                                                     // Set up the stylesheet for EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_4 (adjust as needed)
                                                                     ui->EDIT_SETUP_GENERAL_ERROR_ALERT_Config_Table->setStyleSheet(
                                                                         "QTableView::item {"
                                                                         "border: 1px solid black;"
                                                                         "border-radius: 5px;"
                                                                         "background-color: rgb(255, 255, 127);"
                                                                         "color: black;"
                                                                         "}"
                                                                         "QTableView::item[selected='true'] {"
                                                                         "background-color: gray;"
                                                                         "color: black;"
                                                                         "}"
                                                                     );

                                                                     // Populate the data for each item in the model
                                                                     for (int row = 0; row < 6; ++row) {
                                                                         for (int col = 0; col < 2; ++col) {
                                                                             QStandardItem* item = new QStandardItem();

                                                                             if (row == 0) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Error Types");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("1 Error(s)");
                                                                                 }
                                                                             } else if (row == 1) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Border Color");
                                                                                 } else if (col == 1) {
                                                                                     item->setText(".");
                                                                                 }
                                                                             } else if (row == 2) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Bkg color");
                                                                                 } else if (col == 1) {
                                                                                     item->setText(".");
                                                                                 }
                                                                             } else if (row == 3) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Auto clear");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Enabled");
                                                                                 }
                                                                             }else if (row == 4) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Enable Reflash");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Enabled");
                                                                                 }
                                                                             }else if (row == 5) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Reflash time");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("60 Mins");
                                                                                 }
                                                                             }
                                                                             // Add the item to the timesync_model
                                                                             erroralert_model->setItem(row, col, item);
                                                                         }
                                                                     }

                                                                     // Set the row heights for all 3 rows
                                                                     for (int row = 0; row < 6; ++row) {
                                                                         ui->EDIT_SETUP_GENERAL_ERROR_ALERT_Config_Table->setRowHeight(row, 40);
                                                                     }




                                                                     errortype_model = new QStandardItemModel(7, 2, this);
                                                                     ui->EDIT_SETUP_GENERAL_ERROR_ALERT_ERROR_TYPES_Config_Table->setModel(errortype_model);

                                                                     // Set the column widths (adjust these as needed)
                                                                     ui->EDIT_SETUP_GENERAL_ERROR_ALERT_ERROR_TYPES_Config_Table->setColumnWidth(0, 250);
                                                                     ui->EDIT_SETUP_GENERAL_ERROR_ALERT_ERROR_TYPES_Config_Table->setColumnWidth(1, 400);

                                                                     // Hide horizontal and vertical headers
                                                                     ui->EDIT_SETUP_GENERAL_ERROR_ALERT_ERROR_TYPES_Config_Table->horizontalHeader()->hide();
                                                                     ui->EDIT_SETUP_GENERAL_ERROR_ALERT_ERROR_TYPES_Config_Table->verticalHeader()->hide();

                                                                     // Set up the stylesheet for EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_4 (adjust as needed)
                                                                     ui->EDIT_SETUP_GENERAL_ERROR_ALERT_ERROR_TYPES_Config_Table->setStyleSheet(
                                                                         "QTableView::item {"
                                                                         "border: 1px solid black;"
                                                                         "border-radius: 5px;"
                                                                         "background-color: rgb(255, 255, 127);"
                                                                         "color: black;"
                                                                         "}"
                                                                         "QTableView::item[selected='true'] {"
                                                                         "background-color: gray;"
                                                                         "color: black;"
                                                                         "}"
                                                                     );

                                                                     // Populate the data for each item in the model
                                                                     for (int row = 0; row < 7; ++row) {
                                                                         for (int col = 0; col < 2; ++col) {
                                                                             QStandardItem* item = new QStandardItem();

                                                                             if (row == 0) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Network Unplugged");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Enabled");
                                                                                 }
                                                                             } else if (row == 1) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Int.Mem.Alarm");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Enabled");
                                                                                 }
                                                                             } else if (row == 2) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Export alarm");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Enabled");
                                                                                 }
                                                                             } else if (row == 3) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Media Missing");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Enabled");
                                                                                 }
                                                                             }else if (row == 4) {
                                                                                 if (col == 0) {
                                                                                     item->setText("FTP Mem. Lo");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Enabled");
                                                                                 }
                                                                             }else if (row == 5) {
                                                                                 if (col == 0) {
                                                                                     item->setText("CJC Missing");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Enabled");
                                                                                 }
                                                                             }else if (row == 6) {
                                                                                 if (col == 0) {
                                                                                     item->setText("TC Burnout");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Enabled");
                                                                                 }
                                                                             }
                                                                             // Add the item to the timesync_model
                                                                             errortype_model->setItem(row, col, item);
                                                                         }
                                                                     }

                                                                     // Set the row heights for all 3 rows
                                                                     for (int row = 0; row < 7; ++row) {
                                                                         ui->EDIT_SETUP_GENERAL_ERROR_ALERT_ERROR_TYPES_Config_Table->setRowHeight(row, 40);
                                                                     }


                                                                     demotraces_model = new QStandardItemModel(6, 2, this);
                                                                     ui->tableView_24->setModel(demotraces_model);

                                                                     // Set the column widths (adjust these as needed)
                                                                     ui->tableView_24->setColumnWidth(0, 250);
                                                                     ui->tableView_24->setColumnWidth(1, 400);

                                                                     // Hide horizontal and vertical headers
                                                                     ui->tableView_24->horizontalHeader()->hide();
                                                                     ui->tableView_24->verticalHeader()->hide();

                                                                     ui->tableView_24->setStyleSheet(
                                                                         "QTableView::item {"
                                                                         "border: 1px solid black;"
                                                                         "border-radius: 5px;"
                                                                         "background-color: rgb(255, 255, 127);"
                                                                         "color: black;"
                                                                         "}"
                                                                         "QTableView::item[selected='true'] {"
                                                                         "background-color: gray;"
                                                                         "color: black;"
                                                                         "}"
                                                                     );

                                                                     // Populate the data for each item in the model
                                                                     for (int row = 0; row < 6; ++row) {
                                                                         for (int col = 0; col < 2; ++col) {
                                                                             QStandardItem* item = new QStandardItem();

                                                                             if (row == 0) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Demo Board A");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("No Simulation");
                                                                                 }
                                                                             } else if (row == 1) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Demo Board B");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("No Simulation");
                                                                                 }
                                                                             } else if (row == 2) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Demo Board C");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("No Simulation");
                                                                                 }
                                                                             } else if (row == 3) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Demo Board D");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("No Simulation");
                                                                                 }
                                                                             }else if (row == 4) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Demo Board E");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("No Simulation");
                                                                                 }
                                                                             }else if (row == 5) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Demo Board F");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("No Simulation");
                                                                                 }
                                                                             }
                                                                             // Add the item to the timesync_model
                                                                             demotraces_model->setItem(row, col, item);
                                                                         }
                                                                     }

                                                                     // Set the row heights for all 3 rows
                                                                     for (int row = 0; row < 6; ++row) {
                                                                         ui->tableView_24->setRowHeight(row, 40);
                                                                     }




                                                                     mediaconf_model = new QStandardItemModel(8, 2, this);
                                                                     ui->tableView_media->setModel(mediaconf_model);

                                                                     // Set the column widths (adjust these as needed)
                                                                     ui->tableView_media->setColumnWidth(0, 250);
                                                                     ui->tableView_media->setColumnWidth(1, 400);

                                                                     // Hide horizontal and vertical headers
                                                                     ui->tableView_media->horizontalHeader()->hide();
                                                                     ui->tableView_media->verticalHeader()->hide();

                                                                     // Set up the stylesheet for EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_4 (adjust as needed)
                                                                     ui->tableView_media->setStyleSheet(
                                                                         "QTableView::item {"
                                                                         "border: 1px solid black;"
                                                                         "border-radius: 5px;"
                                                                         "background-color: rgb(255, 255, 127);"
                                                                         "color: black;"
                                                                         "}"
                                                                         "QTableView::item[selected='true'] {"
                                                                         "background-color: gray;"
                                                                         "color: black;"
                                                                         "}"
                                                                     );

                                                                     // Populate the data for each item in the model
                                                                     for (int row = 0; row < 8; ++row) {
                                                                         for (int col = 0; col < 2; ++col) {
                                                                             QStandardItem* item = new QStandardItem();

                                                                             if (row == 0) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Network Unplugged");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Enabled");
                                                                                 }
                                                                             } else if (row == 1) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Int.Mem.Alarm");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Enabled");
                                                                                 }
                                                                             } else if (row == 2) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Export alarm");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Enabled");
                                                                                 }
                                                                             } else if (row == 3) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Media Missing");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Enabled");
                                                                                 }
                                                                             }else if (row == 4) {
                                                                                 if (col == 0) {
                                                                                     item->setText("FTP Mem. Lo");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Enabled");
                                                                                 }
                                                                             }else if (row == 5) {
                                                                                 if (col == 0) {
                                                                                     item->setText("CJC Missing");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Enabled");
                                                                                 }
                                                                             }else if (row == 6) {
                                                                                 if (col == 0) {
                                                                                     item->setText("TC Burnout");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Enabled");
                                                                                 }
                                                                             }else if (row == 7) {
                                                                                 if (col == 0) {
                                                                                     item->setText("TC Burnout");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Enabled");
                                                                                 }
                                                                             }

                                                                             // Add the item to the timesync_model
                                                                             mediaconf_model->setItem(row, col, item);
                                                                         }
                                                                     }

                                                                     // Set the row heights for all 3 rows
                                                                     for (int row = 0; row < 8; ++row) {
                                                                         ui->tableView_media->setRowHeight(row, 40);
                                                                     }



                                                                     email_model = new QStandardItemModel(10, 2, this);
                                                                     ui->tableView_49->setModel(email_model);

                                                                     // Set the column widths (adjust these as needed)
                                                                     ui->tableView_49->setColumnWidth(0, 250);
                                                                     ui->tableView_49->setColumnWidth(1, 400);

                                                                     // Hide horizontal and vertical headers
                                                                     ui->tableView_49->horizontalHeader()->hide();
                                                                     ui->tableView_49->verticalHeader()->hide();

                                                                     // Set up the stylesheet for EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_4 (adjust as needed)
                                                                     ui->tableView_49->setStyleSheet(
                                                                         "QTableView::item {"
                                                                         "border: 1px solid black;"
                                                                         "border-radius: 5px;"
                                                                         "background-color: rgb(255, 255, 127);"
                                                                         "color: black;"
                                                                         "}"
                                                                         "QTableView::item[selected='true'] {"
                                                                         "background-color: gray;"
                                                                         "color: black;"
                                                                         "}"
                                                                     );

                                                                     // Populate the data for each item in the model
                                                                     for (int row = 0; row < 10; ++row) {
                                                                         for (int col = 0; col < 2; ++col) {
                                                                             QStandardItem* item = new QStandardItem();

                                                                             if (row == 0) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Server Name");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("192.168.1.209");
                                                                                 }
                                                                             } else if (row == 1) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Port");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("465");
                                                                                 }
                                                                             } else if (row == 2) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Secure Communication");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Disabled");
                                                                                 }
                                                                             } else if (row == 3) {
                                                                                 if (col == 0) {
                                                                                     item->setText("STARTTLS Support");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Disabled");
                                                                                 }
                                                                             }else if (row == 4) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Authentication");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Enabled");
                                                                                 }
                                                                             }else if (row == 5) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Username");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Not set");
                                                                                 }
                                                                             }else if (row == 6) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Password");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("*********");
                                                                                 }
                                                                             }else if (row == 7) {
                                                                                 if (col == 0) {
                                                                                     item->setText("User Address");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Not set");
                                                                                 }
                                                                             }else if (row == 8) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Reciepient's Email");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Reciepient's Email");
                                                                                 }
                                                                             }else if (row == 9) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Templates");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Templates");
                                                                                 }
                                                                             }

                                                                             // Add the item to the timesync_model
                                                                             email_model->setItem(row, col, item);
                                                                         }
                                                                     }

                                                                     // Set the row heights for all 3 rows
                                                                     for (int row = 0; row < 10; ++row) {
                                                                         ui->tableView_49->setRowHeight(row, 40);
                                                                     }

                                                                     emailtemplate_model = new QStandardItemModel(50, 2, this);
                                                                     ui->tableView_50->setModel(emailtemplate_model);

                                                                     // Set the column widths (adjust as needed)
                                                                     ui->tableView_50->setColumnWidth(0, 250);
                                                                     ui->tableView_50->setColumnWidth(1, 400);

                                                                     // Hide horizontal and vertical headers
                                                                     ui->tableView_50->horizontalHeader()->hide();
                                                                     ui->tableView_50->verticalHeader()->hide();

                                                                     // Set up the stylesheet for tableView_50 (adjust as needed)
                                                                     ui->tableView_50->setStyleSheet(

                                                                         "QTableView::item {"
                                                                         "border: 1px solid black;"
                                                                         "border-radius: 5px;"
                                                                         "background-color: rgb(255, 255, 127);"
                                                                         "color: black;"
                                                                         "}"
                                                                         "QTableView::item[selected='true'] {"
                                                                         "background-color: gray;"
                                                                         "color: black;"
                                                                         "}"
                                                                     );

                                                                     for (int row = 0; row < 50; ++row) {
                                                                         for (int col = 0; col < 2; ++col) {
                                                                             QStandardItem* item = new QStandardItem();

                                                                             if (col == 0) {
                                                                                 item->setText(QString("Address %1").arg(row + 1));
                                                                             }

                                                                             emailtemplate_model->setItem(row, col, item);
                                                                         }
                                                                     }

                                                                     // Set the row heights for all 50 rows
                                                                     for (int row = 0; row < 50; ++row) {
                                                                         ui->tableView_50->setRowHeight(row, 40);
                                                                     }


                                                                     // Create emailtemplate_model for tableView_51
                                                                    emailtemplate_model_51 = new QStandardItemModel(6, 2, this);
                                                                     ui->tableView_51->setModel(emailtemplate_model_51);

                                                                     // Set the column widths (adjust as needed)
                                                                     ui->tableView_51->setColumnWidth(0, 250);
                                                                     ui->tableView_51->setColumnWidth(1, 400);

                                                                     // Hide horizontal and vertical headers
                                                                     ui->tableView_51->horizontalHeader()->hide();
                                                                     ui->tableView_51->verticalHeader()->hide();

                                                                     // Set up the stylesheet for tableView_51 (adjust as needed)
                                                                     ui->tableView_51->setStyleSheet(
                                                                         "QTableView::item {"
                                                                         "border: 1px solid black;"
                                                                         "border-radius: 5px;"
                                                                         "background-color: rgb(255, 255, 127);"
                                                                         "color: black;"
                                                                         "}"
                                                                         "QTableView::item[selected='true'] {"
                                                                         "background-color: gray;"
                                                                         "color: black;"
                                                                         "}"
                                                                     );

                                                                     // Populate data for tableView_51
                                                                     QStringList templateNames = {"Template 1", "Template 2", "Template 3", "Template 4", "Template 5", "Template 6"};
                                                                     QStringList subjectNames = {"Subject 1", "Subject 2", "Subject 3", "Subject 4", "Subject 5", "Subject 6"};

                                                                     for (int row = 0; row < 6; ++row) {
                                                                         for (int col = 0; col < 2; ++col) {
                                                                             QStandardItem* item = new QStandardItem();

                                                                             if (col == 0) {
                                                                                 item->setText(templateNames[row]);
                                                                             } else if (col == 1) {
                                                                                 item->setText(subjectNames[row]);
                                                                             }

                                                                             emailtemplate_model_51->setItem(row, col, item);
                                                                         }
                                                                     }

                                                                     // Set the row heights for all 6 rows
                                                                     for (int row = 0; row < 6; ++row) {
                                                                         ui->tableView_51->setRowHeight(row, 40);
                                                                     }


                                                                    emailtemp_model = new QStandardItemModel(2, 2, this);
                                                                     ui->tableView_52->setModel(emailtemp_model);

                                                                     // Set the column widths (adjust these as needed)
                                                                     ui->tableView_52->setColumnWidth(0, 250);
                                                                     ui->tableView_52->setColumnWidth(1, 400);

                                                                     // Hide horizontal and vertical headers
                                                                     ui->tableView_52->horizontalHeader()->hide();
                                                                     ui->tableView_52->verticalHeader()->hide();

                                                                     // Set up the stylesheet for tableView_web (adjust as needed)
                                                                     ui->tableView_52->setStyleSheet(
                                                                         "QTableView::item {"
                                                                         "border: 1px solid black;"
                                                                         "border-radius: 5px;"
                                                                         "background-color: rgb(255, 255, 127);"
                                                                         "color: black;"
                                                                         "}"
                                                                         "QTableView::item[selected='true'] {"
                                                                         "background-color: gray;"
                                                                         "color: black;"
                                                                         "}"
                                                                     );

                                                                     for (int row = 0; row < 2; ++row) {
                                                                         for (int col = 0; col < 2; ++col) {
                                                                             QStandardItem* item = new QStandardItem();

                                                                             if (row == 0) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Subject");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("subject1");
                                                                                 }
                                                                             } else if (row == 1) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Message Body");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Empty e-mail 1");
                                                                                 }
                                                                             }

                                                                             // Add the item to the opc_model
                                                                             emailtemp_model->setItem(row, col, item);
                                                                         }
                                                                     }

                                                                     for (int row = 0; row < 2; ++row) {
                                                                         ui->tableView_52->setRowHeight(row, 40);
                                                                     }





                                                                     opc_model = new QStandardItemModel(2, 2, this);
                                                                     ui->tableView_26->setModel(opc_model);

                                                                     // Set the column widths (adjust these as needed)
                                                                     ui->tableView_26->setColumnWidth(0, 250);
                                                                     ui->tableView_26->setColumnWidth(1, 400);

                                                                     // Hide horizontal and vertical headers
                                                                     ui->tableView_26->horizontalHeader()->hide();
                                                                     ui->tableView_26->verticalHeader()->hide();

                                                                     // Set up the stylesheet for tableView_web (adjust as needed)
                                                                     ui->tableView_26->setStyleSheet(
                                                                         "QTableView::item {"
                                                                         "border: 1px solid black;"
                                                                         "border-radius: 5px;"
                                                                         "background-color: rgb(255, 255, 127);"
                                                                         "color: black;"
                                                                         "}"
                                                                         "QTableView::item[selected='true'] {"
                                                                         "background-color: gray;"
                                                                         "color: black;"
                                                                         "}"
                                                                     );

                                                                     for (int row = 0; row < 2; ++row) {
                                                                         for (int col = 0; col < 2; ++col) {
                                                                             QStandardItem* item = new QStandardItem();

                                                                             if (row == 0) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Enabled");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Enabled");
                                                                                 }
                                                                             } else if (row == 1) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Port");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("4850");
                                                                                 }
                                                                             }

                                                                             // Add the item to the opc_model
                                                                             opc_model->setItem(row, col, item);
                                                                         }
                                                                     }

                                                                     for (int row = 0; row < 2; ++row) {
                                                                         ui->tableView_26->setRowHeight(row, 40);
                                                                     }




                                                                     ftp_model = new QStandardItemModel(6, 2, this);
                                                                     ui->tableView_42->setModel(ftp_model);

                                                                     // Set the column widths (adjust these as needed)
                                                                     ui->tableView_42->setColumnWidth(0, 250);
                                                                     ui->tableView_42->setColumnWidth(1, 400);

                                                                     // Hide horizontal and vertical headers
                                                                     ui->tableView_42->horizontalHeader()->hide();
                                                                     ui->tableView_42->verticalHeader()->hide();

                                                                     ui->tableView_42->setStyleSheet(
                                                                         "QTableView::item {"
                                                                         "border: 1px solid black;"
                                                                         "border-radius: 5px;"
                                                                         "background-color: rgb(255, 255, 127);"
                                                                         "color: black;"
                                                                         "}"
                                                                         "QTableView::item[selected='true'] {"
                                                                         "background-color: gray;"
                                                                         "color: black;"
                                                                         "}"
                                                                     );

                                                                     // Populate the data for each item in the model
                                                                     for (int row = 0; row < 6; ++row) {
                                                                         for (int col = 0; col < 2; ++col) {
                                                                             QStandardItem* item = new QStandardItem();

                                                                             if (row == 0) {
                                                                                 if (col == 0) {
                                                                                     item->setText("FTP");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Enabled");
                                                                                 }
                                                                             } else if (row == 1) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Secure FT");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Enabled");
                                                                                 }
                                                                             } else if (row == 2) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Allow Upload");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Enabled");
                                                                                 }
                                                                             } else if (row == 3) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Allow Download");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Enabled");
                                                                                 }
                                                                             }else if (row == 4) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Log Messages");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Enabled");
                                                                                 }
                                                                             }else if (row == 5) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Mark Chart");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Enabled");
                                                                                 }
                                                                             }
                                                                             // Add the item to the timesync_model
                                                                             ftp_model->setItem(row, col, item);
                                                                         }
                                                                     }

                                                                     // Set the row heights for all 3 rows
                                                                     for (int row = 0; row < 6; ++row) {
                                                                         ui->tableView_42->setRowHeight(row, 40);
                                                                     }



                                                                    tcp_model = new QStandardItemModel(6, 2, this);
                                                                     ui->EDIT_SETUP_COMMS_TCPIP_Config_Table->setModel(tcp_model);

                                                                     // Set the column widths (adjust these as needed)
                                                                     ui->EDIT_SETUP_COMMS_TCPIP_Config_Table->setColumnWidth(0, 250);
                                                                     ui->EDIT_SETUP_COMMS_TCPIP_Config_Table->setColumnWidth(1, 400);

                                                                     // Hide horizontal and vertical headers
                                                                     ui->EDIT_SETUP_COMMS_TCPIP_Config_Table->horizontalHeader()->hide();
                                                                     ui->EDIT_SETUP_COMMS_TCPIP_Config_Table->verticalHeader()->hide();

                                                                     ui->EDIT_SETUP_COMMS_TCPIP_Config_Table->setStyleSheet(
                                                                         "QTableView::item {"
                                                                         "border: 1px solid black;"
                                                                         "border-radius: 5px;"
                                                                         "background-color: rgb(255, 255, 127);"
                                                                         "color: black;"
                                                                         "}"
                                                                         "QTableView::item[selected='true'] {"
                                                                         "background-color: gray;"
                                                                         "color: black;"
                                                                         "}"
                                                                     );

                                                                     // Populate the data for each item in the model
                                                                     for (int row = 0; row < 6; ++row) {
                                                                         for (int col = 0; col < 2; ++col) {
                                                                             QStandardItem* item = new QStandardItem();

                                                                             if (row == 0) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Static IP");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Enabled");
                                                                                 }
                                                                             } else if (row == 1) {
                                                                                 if (col == 0) {
                                                                                     item->setText("IP Address");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("127.0.0.1");
                                                                                 }
                                                                             } else if (row == 2) {
                                                                                 if (col == 0) {
                                                                                     item->setText("sub Net Mask");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("255.255.255.0");
                                                                                 }
                                                                             } else if (row == 3) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Gateway");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("0.0.0.0");
                                                                                 }
                                                                             }else if (row == 4) {
                                                                                 if (col == 0) {
                                                                                     item->setText("DNS/WINS/MDNS");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("DNS/WINS");
                                                                                 }
                                                                             }else if (row == 5) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Ports");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("80,502");
                                                                                 }
                                                                             }
                                                                             // Add the item to the timesync_model
                                                                             tcp_model->setItem(row, col, item);
                                                                         }
                                                                     }

                                                                     // Set the row heights for all 3 rows
                                                                     for (int row = 0; row < 6; ++row) {
                                                                         ui->EDIT_SETUP_COMMS_TCPIP_Config_Table->setRowHeight(row, 40);
                                                                     }



                                                                     tcpwin_model = new QStandardItemModel(7, 2, this);
                                                                     ui->EDIT_SETUP_COMMS_TCPIP_DNS_MDNS_WINE_Config_Table->setModel(tcpwin_model);

                                                                     // Set the column widths (adjust these as needed)
                                                                     ui->EDIT_SETUP_COMMS_TCPIP_DNS_MDNS_WINE_Config_Table->setColumnWidth(0, 250);
                                                                     ui->EDIT_SETUP_COMMS_TCPIP_DNS_MDNS_WINE_Config_Table->setColumnWidth(1, 400);

                                                                     // Hide horizontal and vertical headers
                                                                     ui->EDIT_SETUP_COMMS_TCPIP_DNS_MDNS_WINE_Config_Table->horizontalHeader()->hide();
                                                                     ui->EDIT_SETUP_COMMS_TCPIP_DNS_MDNS_WINE_Config_Table->verticalHeader()->hide();

                                                                     // Set up the stylesheet for EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_4 (adjust as needed)
                                                                     ui->EDIT_SETUP_COMMS_TCPIP_DNS_MDNS_WINE_Config_Table->setStyleSheet(
                                                                         "QTableView::item {"
                                                                         "border: 1px solid black;"
                                                                         "border-radius: 5px;"
                                                                         "background-color: rgb(255, 255, 127);"
                                                                         "color: black;"
                                                                         "}"
                                                                         "QTableView::item[selected='true'] {"
                                                                         "background-color: gray;"
                                                                         "color: black;"
                                                                         "}"
                                                                     );

                                                                     // Populate the data for each item in the model
                                                                     for (int row = 0; row < 7; ++row) {
                                                                         for (int col = 0; col < 2; ++col) {
                                                                             QStandardItem* item = new QStandardItem();

                                                                             if (row == 0) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Auto DNS");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Enabled");
                                                                                 }
                                                                             } else if (row == 1) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Pri.DNS Addr");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("0.0.0.0");
                                                                                 }
                                                                             } else if (row == 2) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Sec.DNS Addr");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("0.0.0.0");
                                                                                 }
                                                                             } else if (row == 3) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Auto WINS");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Enabled");
                                                                                 }
                                                                             }else if (row == 4) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Pri.WINS.Addr");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("0.0.0.0");
                                                                                 }
                                                                             }else if (row == 5) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Sec.WINS.Addr");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("0.0.0.0");
                                                                                 }
                                                                             }else if (row == 6) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Auto MDNS");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Enabled");
                                                                                 }
                                                                             }
                                                                             // Add the item to the timesync_model
                                                                             tcpwin_model->setItem(row, col, item);
                                                                         }
                                                                     }

                                                                     // Set the row heights for all 3 rows
                                                                     for (int row = 0; row < 7; ++row) {
                                                                         ui->EDIT_SETUP_COMMS_TCPIP_DNS_MDNS_WINE_Config_Table->setRowHeight(row, 40);
                                                                     }


                                                                     tcpport_model = new QStandardItemModel(2, 2, this);
                                                                     ui->EDIT_SETUP_COMMS_TCPIP_PORT_Config_Table->setModel(tcpport_model);

                                                                     ui->EDIT_SETUP_COMMS_TCPIP_PORT_Config_Table->setColumnWidth(0, 250);
                                                                     ui->EDIT_SETUP_COMMS_TCPIP_PORT_Config_Table->setColumnWidth(1, 400);

                                                                     // Hide horizontal and vertical headers
                                                                     ui->EDIT_SETUP_COMMS_TCPIP_PORT_Config_Table->horizontalHeader()->hide();
                                                                     ui->EDIT_SETUP_COMMS_TCPIP_PORT_Config_Table->verticalHeader()->hide();

                                                                     // Set up the stylesheet for tableView_web (adjust as needed)
                                                                     ui->EDIT_SETUP_COMMS_TCPIP_PORT_Config_Table->setStyleSheet(
                                                                         "QTableView::item {"
                                                                         "border: 1px solid black;"
                                                                         "border-radius: 5px;"
                                                                         "background-color: rgb(255, 255, 127);"
                                                                         "color: black;"
                                                                         "}"
                                                                         "QTableView::item[selected='true'] {"
                                                                         "background-color: gray;"
                                                                         "color: black;"
                                                                         "}"
                                                                     );

                                                                     for (int row = 0; row < 2; ++row) {
                                                                         for (int col = 0; col < 2; ++col) {
                                                                             QStandardItem* item = new QStandardItem();

                                                                             if (row == 0) {
                                                                                 if (col == 0) {
                                                                                     item->setText("HTTP");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("80");
                                                                                 }
                                                                             } else if (row == 1) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Modbus");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("502");
                                                                                 }
                                                                             }

                                                                             // Add the item to the opc_model
                                                                             tcpport_model->setItem(row, col, item);
                                                                         }
                                                                     }

                                                                     for (int row = 0; row < 2; ++row) {
                                                                         ui->EDIT_SETUP_COMMS_TCPIP_PORT_Config_Table->setRowHeight(row, 40);
                                                                     }



                                                                     storagealarm_model = new QStandardItemModel(3, 2, this);
                                                                     ui->tableView_27->setModel(storagealarm_model);

                                                                     ui->tableView_27->setColumnWidth(0, 250);
                                                                     ui->tableView_27->setColumnWidth(1, 400);

                                                                     // Hide horizontal and vertical headers
                                                                     ui->tableView_27->horizontalHeader()->hide();
                                                                     ui->tableView_27->verticalHeader()->hide();

                                                                     // Set up the stylesheet for tableView_web (adjust as needed)
                                                                     ui->tableView_27->setStyleSheet(
                                                                         "QTableView::item {"
                                                                         "border: 1px solid black;"
                                                                         "border-radius: 5px;"
                                                                         "background-color: rgb(255, 255, 127);"
                                                                         "color: black;"
                                                                         "}"
                                                                         "QTableView::item[selected='true'] {"
                                                                         "background-color: gray;"
                                                                         "color: black;"
                                                                         "}"
                                                                     );

                                                                     for (int row = 0; row < 3; ++row) {
                                                                         for (int col = 0; col < 2; ++col) {
                                                                             QStandardItem* item = new QStandardItem();

                                                                             if (row == 0) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Int.Memory");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("1.0 Hrs.");
                                                                                 }
                                                                             } else if (row == 1) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Export Media");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("1.0 Hrs.");
                                                                                 }
                                                                             }else if (row == 2) {
                                                                                 if (col == 0) {
                                                                                     item->setText("FTP Memory");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("1.0 Hrs.");
                                                                                 }
                                                                             }

                                                                             // Add the item to the opc_model
                                                                             storagealarm_model->setItem(row, col, item);
                                                                         }
                                                                     }

                                                                     for (int row = 0; row < 3; ++row) {
                                                                         ui->tableView_27->setRowHeight(row, 40);
                                                                     }



                                                                     // Create emailtemplate_model for tableView_51
                                                                     linearization_model = new QStandardItemModel(6, 2, this);
                                                                     ui->EDIT_SETUP_FIELDIO_LINEARISATION_Tableview->setModel(linearization_model);

                                                                     // Set the column widths (adjust as needed)
                                                                     ui->EDIT_SETUP_FIELDIO_LINEARISATION_Tableview->setColumnWidth(0, 250);
                                                                     ui->EDIT_SETUP_FIELDIO_LINEARISATION_Tableview->setColumnWidth(1, 400);

                                                                     // Hide horizontal and vertical headers
                                                                     ui->EDIT_SETUP_FIELDIO_LINEARISATION_Tableview->horizontalHeader()->hide();
                                                                     ui->EDIT_SETUP_FIELDIO_LINEARISATION_Tableview->verticalHeader()->hide();

                                                                     // Set up the stylesheet for tableView_51 (adjust as needed)
                                                                     ui->EDIT_SETUP_FIELDIO_LINEARISATION_Tableview->setStyleSheet(
                                                                         "QTableView::item {"
                                                                         "border: 1px solid black;"
                                                                         "border-radius: 5px;"
                                                                         "background-color: rgb(255, 255, 127);"
                                                                         "color: black;"
                                                                         "}"
                                                                         "QTableView::item[selected='true'] {"
                                                                         "background-color: gray;"
                                                                         "color: black;"
                                                                         "}"
                                                                     );

                                                                     // Populate data for tableView_51
                                                                     QStringList templateNames1 = {"Table 1", "Table 2", "Table 3", "Table 4", "Table 5", "Table 6"};
                                                                     QStringList subjectNames1 = {"Linear Table 1", "Linear Table 2", "Linear Table 3", "Linear Table 4", "Linear Table 5", "Linear Table 6"};

                                                                     for (int row = 0; row < 6; ++row) {
                                                                         for (int col = 0; col < 2; ++col) {
                                                                             QStandardItem* item = new QStandardItem();

                                                                             if (col == 0) {
                                                                                 item->setText(templateNames1[row]);
                                                                             } else if (col == 1) {
                                                                                 item->setText(subjectNames1[row]);
                                                                             }

                                                                             linearization_model->setItem(row, col, item);
                                                                         }
                                                                     }

                                                                     // Set the row heights for all 6 rows
                                                                     for (int row = 0; row < 6; ++row) {
                                                                         ui->EDIT_SETUP_FIELDIO_LINEARISATION_Tableview->setRowHeight(row, 40);
                                                                     }


                                                                    linearizationtable_model  = new QStandardItemModel(2, 2, this);
                                                                     ui->EDIT_SETUP_FIELDIO_LINEARISATION_TABLE_Tableview->setModel(linearizationtable_model);

                                                                     ui->EDIT_SETUP_FIELDIO_LINEARISATION_TABLE_Tableview->setColumnWidth(0, 250);
                                                                     ui->EDIT_SETUP_FIELDIO_LINEARISATION_TABLE_Tableview->setColumnWidth(1, 400);

                                                                     // Hide horizontal and vertical headers
                                                                     ui->EDIT_SETUP_FIELDIO_LINEARISATION_TABLE_Tableview->horizontalHeader()->hide();
                                                                     ui->EDIT_SETUP_FIELDIO_LINEARISATION_TABLE_Tableview->verticalHeader()->hide();

                                                                     // Set up the stylesheet for tableView_web (adjust as needed)
                                                                     ui->EDIT_SETUP_FIELDIO_LINEARISATION_TABLE_Tableview->setStyleSheet(
                                                                         "QTableView::item {"
                                                                         "border: 1px solid black;"
                                                                         "border-radius: 5px;"
                                                                         "background-color: rgb(255, 255, 127);"
                                                                         "color: black;"
                                                                         "}"
                                                                         "QTableView::item[selected='true'] {"
                                                                         "background-color: gray;"
                                                                         "color: black;"
                                                                         "}"
                                                                     );

                                                                     for (int row = 0; row < 2; ++row) {
                                                                         for (int col = 0; col < 2; ++col) {
                                                                             QStandardItem* item = new QStandardItem();

                                                                             if (row == 0) {
                                                                                 if (col == 0) {
                                                                                     item->setText("HTTP");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("80");
                                                                                 }
                                                                             } else if (row == 1) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Modbus");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("502");
                                                                                 }
                                                                             }

                                                                             // Add the item to the opc_model
                                                                             linearizationtable_model->setItem(row, col, item);
                                                                         }
                                                                     }

                                                                     for (int row = 0; row < 2; ++row) {
                                                                         ui->EDIT_SETUP_FIELDIO_LINEARISATION_TABLE_Tableview->setRowHeight(row, 40);
                                                                     }


                                                                     slave_model = new QStandardItemModel(4, 2, this);
                                                                     ui->tableView_28->setModel(slave_model);

                                                                     ui->tableView_28->setColumnWidth(0, 250);
                                                                     ui->tableView_28->setColumnWidth(1, 400);

                                                                     // Hide horizontal and vertical headers
                                                                     ui->tableView_28->horizontalHeader()->hide();
                                                                     ui->tableView_28->verticalHeader()->hide();

                                                                     // Set up the stylesheet for tableView_web (adjust as needed)
                                                                     ui->tableView_28->setStyleSheet(
                                                                         "QTableView::item {"
                                                                         "border: 1px solid black;"
                                                                         "border-radius: 5px;"
                                                                         "background-color: rgb(255, 255, 127);"
                                                                         "color: black;"
                                                                         "}"
                                                                         "QTableView::item[selected='true'] {"
                                                                         "background-color: gray;"
                                                                         "color: black;"
                                                                         "}"
                                                                     );

                                                                     for (int row = 0; row < 4; ++row) {
                                                                         for (int col = 0; col < 2; ++col) {
                                                                             QStandardItem* item = new QStandardItem();

                                                                             if (row == 0) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Enabled");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Enabled");
                                                                                 }
                                                                             } else if (row == 1) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Port ");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("RS-485");
                                                                                 }
                                                                             }else if (row == 2) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Protocol");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Modbus(FPLB)");
                                                                                 }
                                                                             }else if (row == 3) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Slave");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("1");
                                                                                 }
                                                                             }

                                                                             // Add the item to the opc_model
                                                                             slave_model->setItem(row, col, item);
                                                                         }
                                                                     }
                                                                     for (int row = 0; row < 4; ++row) {
                                                                         ui->tableView_28->setRowHeight(row, 40);
                                                                     }




                                                                     rs485_model = new QStandardItemModel(4, 2, this);
                                                                     ui->tableView_29->setModel(rs485_model);

                                                                     ui->tableView_29->setColumnWidth(0, 250);
                                                                     ui->tableView_29->setColumnWidth(1, 400);

                                                                     // Hide horizontal and vertical headers
                                                                     ui->tableView_29->horizontalHeader()->hide();
                                                                     ui->tableView_29->verticalHeader()->hide();

                                                                     // Set up the stylesheet for tableView_web (adjust as needed)
                                                                     ui->tableView_29->setStyleSheet(
                                                                         "QTableView::item {"
                                                                         "border: 1px solid black;"
                                                                         "border-radius: 5px;"
                                                                         "background-color: rgb(255, 255, 127);"
                                                                         "color: black;"
                                                                         "}"
                                                                         "QTableView::item[selected='true'] {"
                                                                         "background-color: gray;"
                                                                         "color: black;"
                                                                         "}"
                                                                     );

                                                                     for (int row = 0; row < 4; ++row) {
                                                                         for (int col = 0; col < 2; ++col) {
                                                                             QStandardItem* item = new QStandardItem();

                                                                             if (row == 0) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Baud Rate");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("38400");
                                                                                 }
                                                                             } else if (row == 1) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Byte Options");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("N-8-1");
                                                                                 }
                                                                             }else if (row == 2) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Line Turn Around");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("3 ms");
                                                                                 }
                                                                             }else if (row == 3) {
                                                                                 if (col == 0) {
                                                                                     item->setText("0 ms");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("1");
                                                                                 }
                                                                             }

                                                                             // Add the item to the opc_model
                                                                             rs485_model->setItem(row, col, item);
                                                                         }
                                                                     }
                                                                     for (int row = 0; row < 4; ++row) {
                                                                         ui->tableView_29->setRowHeight(row, 40);
                                                                     }





                                                                     appearance_model = new QStandardItemModel(7, 2, this);
                                                                     ui->EDIT_LAYOUT_APPEARANCE_Config_Table->setModel(appearance_model);

                                                                     // Set the column widths (adjust these as needed)
                                                                     ui->EDIT_LAYOUT_APPEARANCE_Config_Table->setColumnWidth(0, 250);
                                                                     ui->EDIT_LAYOUT_APPEARANCE_Config_Table->setColumnWidth(1, 400);

                                                                     // Hide horizontal and vertical headers
                                                                     ui->EDIT_LAYOUT_APPEARANCE_Config_Table->horizontalHeader()->hide();
                                                                     ui->EDIT_LAYOUT_APPEARANCE_Config_Table->verticalHeader()->hide();

                                                                     // Set up the stylesheet for EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_4 (adjust as needed)
                                                                     ui->EDIT_LAYOUT_APPEARANCE_Config_Table->setStyleSheet(
                                                                         "QTableView::item {"
                                                                         "border: 1px solid black;"
                                                                         "border-radius: 5px;"
                                                                         "background-color: rgb(255, 255, 127);"
                                                                         "color: black;"
                                                                         "}"
                                                                         "QTableView::item[selected='true'] {"
                                                                         "background-color: gray;"
                                                                         "color: black;"
                                                                         "}"
                                                                     );

                                                                     // Populate the data for each item in the model
                                                                     for (int row = 0; row < 7; ++row) {
                                                                         for (int col = 0; col < 2; ++col) {
                                                                             QStandardItem* item = new QStandardItem();

                                                                             if (row == 0) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Chart");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Graduations");
                                                                                 }
                                                                             } else if (row == 1) {
                                                                                 if (col == 0) {
                                                                                     item->setText("chart");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Colour");
                                                                                 }
                                                                             } else if (row == 2) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Chart");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Alarm");
                                                                                 }
                                                                             } else if (row == 3) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Replay");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Graduations");
                                                                                 }
                                                                             }else if (row == 4) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Replay");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("colour");
                                                                                 }
                                                                             }else if (row == 5) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Replay");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Alarm");
                                                                                 }
                                                                             }else if (row == 6) {
                                                                                 if (col == 0) {
                                                                                     item->setText("TimeStamp");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Enabled");
                                                                                 }
                                                                             }else if (row == 7) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Marker colour");
                                                                                   } else if (col == 1) {
                                                                                     item->setText("Enabled");
                                                                                 }
                                                                             }
                                                                             // Add the item to the timesync_model
                                                                             appearance_model->setItem(row, col, item);
                                                                         }
                                                                     }

                                                                     // Set the row heights for all 3 rows
                                                                     for (int row = 0; row < 7; ++row) {
                                                                         ui->EDIT_LAYOUT_APPEARANCE_Config_Table->setRowHeight(row, 40);
                                                                     }




                                                                     layoutsetting_model = new QStandardItemModel(15, 2, this);
                                                                     ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table->setModel(layoutsetting_model);

                                                                     // Set the column widths (adjust these as needed)
                                                                     ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table->setColumnWidth(0, 250);
                                                                     ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table->setColumnWidth(1, 400);

                                                                     // Hide horizontal and vertical headers
                                                                     ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table->horizontalHeader()->hide();
                                                                     ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table->verticalHeader()->hide();

                                                                     // Set up the stylesheet for EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_4 (adjust as needed)
                                                                     ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table->setStyleSheet(
                                                                         "QTableView::item {"
                                                                         "border: 1px solid black;"
                                                                         "border-radius: 5px;"
                                                                         "background-color: rgb(255, 255, 127);"
                                                                         "color: black;"
                                                                         "}"
                                                                         "QTableView::item[selected='true'] {"
                                                                         "background-color: gray;"
                                                                         "color: black;"
                                                                         "}"
                                                                     );

                                                                     // Populate the data for each item in the model
                                                                     for (int row = 0; row < 15; ++row) {
                                                                         for (int col = 0; col < 2; ++col) {
                                                                             QStandardItem* item = new QStandardItem();

                                                                             if (row == 0) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Cycle Screens");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Enabled");
                                                                                 }
                                                                             } else if (row == 1) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Cycle List");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("None");
                                                                                 }
                                                                             } else if (row == 2) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Cycle Interval");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("10 Secs");
                                                                                 }
                                                                             } else if (row == 3) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Screen Hold");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("20 Secs");
                                                                                 }
                                                                             }else if (row == 4) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Alarm Screen");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Enabled");
                                                                                 }
                                                                             }else if (row == 5) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Alarm Screen Name");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("NA");
                                                                                 }
                                                                             }else if (row == 6) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Replay Scrn TO");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Enabled");
                                                                                 }
                                                                             }else if (row == 7) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Replay Timeout");
                                                                                   } else if (col == 1) {
                                                                                     item->setText("10 Mins");
                                                                                 }
                                                                             }else if (row == 8) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Menu Bar TO");
                                                                                   } else if (col == 1) {
                                                                                     item->setText("10 Secs");
                                                                                 }
                                                                             }else if (row == 9) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Hourly stamps");
                                                                                   } else if (col == 1) {
                                                                                     item->setText("Enabled");
                                                                                 }
                                                                             }else if (row == 10) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Show Chart Start/stop");
                                                                                   } else if (col == 1) {
                                                                                     item->setText("Enabled");
                                                                                 }
                                                                             }else if (row == 11) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Hot Btn1");
                                                                                   } else if (col == 1) {
                                                                                     item->setText("HB1");
                                                                                 }
                                                                             }else if (row == 12) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Hot Btn2");
                                                                                   } else if (col == 1) {
                                                                                     item->setText("HB2");
                                                                                 }
                                                                             }else if (row == 13) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Hot Btn3");
                                                                                   } else if (col == 1) {
                                                                                     item->setText("HB3");
                                                                                 }
                                                                             }else if (row == 14) {
                                                                                 if (col == 0) {
                                                                                     item->setText("Hot Btn3");
                                                                                   } else if (col == 1) {
                                                                                     item->setText("HB4");
                                                                                 }
                                                                             }

                                                                             // Add the item to the timesync_model
                                                                             layoutsetting_model->setItem(row, col, item);
                                                                         }
                                                                     }

                                                                     // Set the row heights for all 3 rows
                                                                     for (int row = 0; row < 15; ++row) {
                                                                         ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table->setRowHeight(row, 40);
                                                                     }



                                                                     standardscreen_model = new QStandardItemModel(5, 2, this);
                                                                     ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_2->setModel(standardscreen_model);

                                                                     // Set the column widths (adjust these as needed)
                                                                     ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_2->setColumnWidth(0, 250);
                                                                     ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_2->setColumnWidth(1, 400);

                                                                     // Hide horizontal and vertical headers
                                                                     ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_2->horizontalHeader()->hide();
                                                                     ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_2->verticalHeader()->hide();

                                                                     ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_2->setStyleSheet(
                                                                         "QTableView::item {"
                                                                         "border: 1px solid black;"
                                                                         "border-radius: 5px;"
                                                                         "background-color: rgb(255, 255, 127);"
                                                                         "color: black;"
                                                                         "}"
                                                                         "QTableView::item[selected='true'] {"
                                                                         "background-color: gray;"
                                                                         "color: black;"
                                                                         "}"
                                                                     );

                                                                     // Populate the data for each item in the model
                                                                     for (int row = 0; row < 5; ++row) {
                                                                         for (int col = 0; col < 2; ++col) {
                                                                             QStandardItem* item = new QStandardItem();

                                                                             if (row == 0) {
                                                                                 if (col == 0) {
                                                                                     item->setText("screen1");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Standard Screen1");
                                                                                 }
                                                                             } else if (row == 1) {
                                                                                 if (col == 0) {
                                                                                     item->setText("screen2");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Standard Screen2");
                                                                                 }
                                                                             } else if (row == 2) {
                                                                                 if (col == 0) {
                                                                                     item->setText("screen3");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Standard Screen3");
                                                                                 }
                                                                             } else if (row == 3) {
                                                                                 if (col == 0) {
                                                                                     item->setText(" ");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Add Screen");
                                                                                 }
                                                                             } else if (row == 4) {
                                                                                 if (col == 0) {
                                                                                     item->setText(" ");
                                                                                 } else if (col == 1) {
                                                                                     item->setText("Delete screen");
                                                                                 }
                                                                             }

                                                                             // Add the item to the standardscreen_model
                                                                             standardscreen_model->setItem(row, col, item);
                                                                         }
                                                                     }

                                                                     // Set the row heights for all 5 rows (not 3 as mentioned in the comment)
                                                                     for (int row = 0; row < 5; ++row) {
                                                                         ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_2->setRowHeight(row, 40);
                                                                     }

    ///////////////////////////////////////////////ms5
                                     model81 = new QStandardItemModel(3,2,this);
                                     ui->EDIT_LAYOUT_TOP_BAR_Tableview->setModel(model81);
                                     ui->EDIT_LAYOUT_TOP_BAR_Tableview->setColumnWidth(0,250);
                                     ui->EDIT_LAYOUT_TOP_BAR_Tableview->setColumnWidth(1,400);
                                     ui->EDIT_LAYOUT_TOP_BAR_Tableview->setStyleSheet(
                                                                      "QTableView::item{"
                                                                      "border: 1px solid black;"
                                                                      "border-radius: 5px;"
                                                                      "background-color: rgb(255, 255, 127);"
                                                                      "color: black;"
                                                                      "}"
                                                                      );
                                     for(int row = 0; row < 3; row++)
                                     {
                                         ui->EDIT_LAYOUT_TOP_BAR_Tableview->setRowHeight(row,40);
                                         //for(int col = 0; col < 2; col++)
                                         {
                                             QModelIndex index = model81->index(row,0,QModelIndex());
                                             // 0 for all data
                                             if(row == 0)
                                             {
                                             QString text1= QString("Screen 1");
                                             //text.append(QString("%1 ").arg(row));
                                             model81->setData(index,text1);
                                             }

                                         }
                                         {
                                             QModelIndex index = model81->index(row,1,QModelIndex());
                                             // 0 for all data
                                             if(row == 0)
                                             {
                                             QString text1= QString("Standard Screen 1");
                                             //text.append(QString("%1 ").arg(row));
                                             model81->setData(index,text1);
                                             }
                                             else if(row == 1)
                                             {

                                             QString text1= QString("Add Screen");
                                             //text.append(QString("%1 ").arg(row));
                                             model81->setData(index,text1);
                                             }
                                             else if(row == 2)
                                             {

                                             QString text1= QString("Delete Screen");
                                             //text.append(QString("%1 ").arg(row));
                                             model81->setData(index,text1);
                                             }
                                     }
                                     }





             model82 = new QStandardItemModel(6,2,this);
             ui->EDIT_LAYOUT_SCREENS_INDEX_Tableview->setModel(model82);
             ui->EDIT_LAYOUT_SCREENS_INDEX_Tableview->setColumnWidth(0,250);
             ui->EDIT_LAYOUT_SCREENS_INDEX_Tableview->setColumnWidth(1,400);
             ui->EDIT_LAYOUT_SCREENS_INDEX_Tableview->setStyleSheet(
                                              "QTableView::item{"
                                              "border: 1px solid black;"
                                              "border-radius: 5px;"
                                              "background-color: rgb(255, 255, 127);"
                                              "color: black;"
                                              "}"
                                              );


             for(int row = 0; row < 6; row++)
             {
                 ui->EDIT_LAYOUT_SCREENS_INDEX_Tableview->setRowHeight(row,40);
                 //for(int col = 0; col < 2; col++)
                 {
                     QModelIndex index = model82->index(row,0,QModelIndex());
                     // 0 for all data
                     if(row == 0)
                     {
                     QString text1= QString("Name");
                     //text.append(QString("%1 ").arg(row));
                     model82->setData(index,text1);
                     }
                     if(row == 1)
                     {
                     QString text1= QString("Enabled");
                     //text.append(QString("%1 ").arg(row));
                     model82->setData(index,text1);
                     }
                     if(row == 2)
                     {
                     QString text1= QString("Template Type");
                     //text.append(QString("%1 ").arg(row));
                     model82->setData(index,text1);
                     }
                     if(row == 3)
                     {
                     QString text1= QString("Select By");
                     //text.append(QString("%1 ").arg(row));
                     model82->setData(index,text1);
                     }
                     if(row == 4)
                     {
                     QString text1= QString("Showing (Pens)");
                     //text.append(QString("%1 ").arg(row));
                     model82->setData(index,text1);
                     }
                     if(row == 5)
                     {
                     QString text1= QString("Orientation");
                     //text.append(QString("%1 ").arg(row));
                     model82->setData(index,text1);
                     }

                 }
                 {
                     QModelIndex index = model82->index(row,1,QModelIndex());
                     // 0 for all data
                     if(row == 0)
                     {
                     QString text1= QString("Standard Screen 1");
                     //text.append(QString("%1 ").arg(row));
                     model82->setData(index,text1);
                     }
                     else if(row == 1)
                     {

                     QString text1= QString(".");
                     //text.append(QString("%1 ").arg(row));
                     model82->setData(index,text1);
                     }
                     else if(row == 2)
                     {

                     QString text1= QString("Chart and DPMs");
                     //text.append(QString("%1 ").arg(row));
                     model82->setData(index,text1);
                     }
                     else if(row == 3)
                     {

                     QString text1= QString("Pen");
                     //text.append(QString("%1 ").arg(row));
                     model82->setData(index,text1);
                     }
                     else if(row == 4)
                     {

                     QString text1= QString("1,2");
                     //text.append(QString("%1 ").arg(row));
                     model82->setData(index,text1);
                     }
                     else if(row == 5)
                     {

                     QString text1= QString("Horizontal");
                     //text.append(QString("%1 ").arg(row));
                     model82->setData(index,text1);
                     }
             }
             }





             model83 = new QStandardItemModel(5,2,this);
             ui->EDIT_LAYOUT_SCREENS_INDEX_2_Tableview->setModel(model83);
             ui->EDIT_LAYOUT_SCREENS_INDEX_2_Tableview->setColumnWidth(0,250);
             ui->EDIT_LAYOUT_SCREENS_INDEX_2_Tableview->setColumnWidth(1,400);
             ui->EDIT_LAYOUT_SCREENS_INDEX_2_Tableview->setStyleSheet(
                                              "QTableView::item{"
                                              "border: 1px solid black;"
                                              "border-radius: 5px;"
                                              "background-color: rgb(255, 255, 127);"
                                              "color: black;"
                                              "}"
                                              );


             for(int row = 0; row < 5; row++)
             {
                 ui->EDIT_LAYOUT_SCREENS_INDEX_2_Tableview->setRowHeight(row,40);
                 //for(int col = 0; col < 2; col++)
                 {
                     QModelIndex index = model83->index(row,0,QModelIndex());
                     // 0 for all data
                     if(row == 0)
                     {
                     QString text1= QString("Name");
                     //text.append(QString("%1 ").arg(row));
                     model83->setData(index,text1);
                     }
                     if(row == 1)
                     {
                     QString text1= QString("Enabled");
                     //text.append(QString("%1 ").arg(row));
                     model83->setData(index,text1);
                     }
                     if(row == 2)
                     {
                     QString text1= QString("Template Type");
                     //text.append(QString("%1 ").arg(row));
                     model83->setData(index,text1);
                     }
                     if(row == 3)
                     {
                     QString text1= QString("Select By");
                     //text.append(QString("%1 ").arg(row));
                     model83->setData(index,text1);
                     }
                     if(row == 4)
                     {
                     QString text1= QString("Showing (Pens)");
                     //text.append(QString("%1 ").arg(row));
                     model83->setData(index,text1);
                     }

                 }
                 {
                     QModelIndex index = model83->index(row,1,QModelIndex());
                     // 0 for all data
                     if(row == 0)
                     {
                     QString text1= QString("Standard Screen 1");
                     //text.append(QString("%1 ").arg(row));
                     model83->setData(index,text1);
                     }
                     else if(row == 1)
                     {

                     QString text1= QString(".");
                     //text.append(QString("%1 ").arg(row));
                     model83->setData(index,text1);
                     }
                     else if(row == 2)
                     {

                     QString text1= QString("MaxMin");
                     //text.append(QString("%1 ").arg(row));
                     model83->setData(index,text1);
                     }
                     else if(row == 3)
                     {

                     QString text1= QString("Pen");
                     //text.append(QString("%1 ").arg(row));
                     model83->setData(index,text1);
                     }
                     else if(row == 4)
                     {

                     QString text1= QString("1,2");
                     //text.append(QString("%1 ").arg(row));
                     model83->setData(index,text1);
                     }
             }
             }

//             model84 = new QStandardItemModel(8,8,this);
//             ui->tableView_17->setModel(model84);
//             ui->tableView_17->setColumnWidth(0,250);
//             ui->tableView_17->setColumnWidth(1,400);
//             ui->EDIT_LAYOUT_SCREENS_INDEX_2_Tableview->setStyleSheet(
//                                              "QTableView::item{"
//                                              "border: 1px solid black;"
//                                              "border-radius: 5px;"
//                                              "background-color: rgb(255, 255, 255);"
//                                              "color: black;"
//                                              "}"
//                                              );
//             for(int row = 0; row < 5; row++)
//             {
//                 ui->tableView_17->setRowHeight(row,40);
//                 //for(int col = 0; col < 2; col++)
//                 {
//                     QModelIndex index = model84->index(row,0,QModelIndex());
//                     // 0 for all data
//                     if(row == 0)
//                     {
//                     QString text1= QString("Name");
//                     //text.append(QString("%1 ").arg(row));
//                     model84->setData(index,text1);
//                     }
//                 }
//                 {
//                     QModelIndex index = model84->index(row,1,QModelIndex());
//                     // 0 for all data
//                     if(row == 0)
//                     {
//                     QString text1= QString("Standard Screen 1");
//                     //text.append(QString("%1 ").arg(row));
//                     model84->setData(index,text1);
//             }
//                 }
//             }
}













    ///////////////////////////////////////////////



             connect(ui->tableView, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked(const QModelIndex &)));
             connect(ui->tableView_2, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_23(const QModelIndex &)));

             connect(ui->tableView_4, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_2(const QModelIndex &)));
             connect(ui->tableView_5, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_16(const QModelIndex &)));
             connect(ui->tableView_6, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_3(const QModelIndex &)));
             connect(ui->tableView_7, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_4(const QModelIndex &)));
             connect(ui->tableView_15, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_5(const QModelIndex &)));
             connect(ui->tableView_19, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_6(const QModelIndex &)));
             connect(ui->tableView_21, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_7(const QModelIndex &)));
             connect(ui->tableView_20, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_8(const QModelIndex &)));
             connect(ui->EDIT_SETUP_FIELDIO_ALARM_DIGITALIO_INDEX_Tableview, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_9(const QModelIndex &)));
             connect(ui->EDIT_SETUP_EDIT_RECORDING_EXPORT_Tableview, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_10(const QModelIndex &)));
             connect(ui->EDIT_SETUP_EDIT_RECORDING_SCHEDULED_Tableview, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_11(const QModelIndex &)));
             connect(ui->EDIT_LAYOUT_TOP_BAR_Tableview, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_12(const QModelIndex &)));
             connect(ui->tableView_64, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_13(const QModelIndex &)));
             connect(ui->EDIT_LAYOUT_SCREENS_SCREEN_Config_Table_3, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_14(const QModelIndex &)));
             connect(ui->tableView_65, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_15(const QModelIndex &)));
             connect(ui->tableView_66, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_17(const QModelIndex &)));
             connect(ui->tableView_67, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_18(const QModelIndex &)));
             connect(ui->tableView_69, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_19(const QModelIndex &)));
             connect(ui->tableView_70, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_20(const QModelIndex &)));
             connect(ui->tableView_71, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_21(const QModelIndex &)));
             connect(ui->tableView_72, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_22(const QModelIndex &)));
             connect(ui->tableView_73, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_24(const QModelIndex &)));
             connect(ui->tableView_74, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_25(const QModelIndex &)));
             connect(ui->tableView_75, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_26(const QModelIndex &)));
             connect(ui->tableView_61, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_27(const QModelIndex &)));
             connect(ui->tableView_62, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_28(const QModelIndex &)));
             connect(ui->EDIT_SETUP_SCREEN_SETUP_TABULAR_DISPLAY_TableView, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_29(const QModelIndex &)));
             connect(ui->tableView_60, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_30(const QModelIndex &)));
             connect(ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_3, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_31(const QModelIndex &)));
             connect(ui->tableView_41, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_32(const QModelIndex &)));
             connect(ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_4, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_33(const QModelIndex &)));
             connect(ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_5, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_34(const QModelIndex &)));
              connect(ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_6, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_35(const QModelIndex &)));
              connect(ui->tableView_25, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_36(const QModelIndex &)));
              connect(ui->tableView_76, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_37(const QModelIndex &)));
              connect(ui->tableView_77, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_38(const QModelIndex &)));
              connect(ui->tableView_79, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_39(const QModelIndex &)));
              connect(ui->tableView_43, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_40(const QModelIndex &)));
              connect(ui->tableView_web, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_41(const QModelIndex &)));
              connect(ui->EDIT_SETUP_COMMS_NETWORK_ADMIN_Config_Table, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_42(const QModelIndex &)));
              connect(ui->EDIT_SETUP_COMMS_SECURITY_OPTIONS_Config_Table, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_43(const QModelIndex &)));
              connect(ui->EDIT_LAYOUT_SCREENS_SCREEN_Config_Table_2, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_44(const QModelIndex &)));
              connect(ui->EDIT_SETUP_GENERAL_ERROR_ALERT_Config_Table, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_45(const QModelIndex &)));
              connect(ui->EDIT_SETUP_GENERAL_ERROR_ALERT_ERROR_TYPES_Config_Table, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_46(const QModelIndex &)));
              connect(ui->tableView_24, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_47(const QModelIndex &)));
              connect(ui->tableView_media, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_48(const QModelIndex &)));
              connect(ui->tableView_49, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_49(const QModelIndex &)));
              connect(ui->tableView_50, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_50(const QModelIndex &)));
              connect(ui->tableView_26, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_51(const QModelIndex &)));
              connect(ui->tableView_42, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_52(const QModelIndex &)));
              connect(ui->EDIT_SETUP_COMMS_TCPIP_Config_Table, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_53(const QModelIndex &)));
              connect(ui->EDIT_SETUP_COMMS_TCPIP_DNS_MDNS_WINE_Config_Table, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_54(const QModelIndex &)));
              connect(ui->EDIT_SETUP_COMMS_TCPIP_PORT_Config_Table, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_55(const QModelIndex &)));
              connect(ui->tableView_27, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_56(const QModelIndex &)));
              connect(ui->tableView_51, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_57(const QModelIndex &)));
              connect(ui->tableView_52, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_58(const QModelIndex &)));
              connect(ui->EDIT_SETUP_FIELDIO_LINEARISATION_Tableview, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_59(const QModelIndex &)));
              connect(ui->EDIT_SETUP_FIELDIO_LINEARISATION_TABLE_Tableview, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_60(const QModelIndex &)));
              connect(ui->tableView_28, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_61(const QModelIndex &)));
              connect(ui->tableView_29, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_62(const QModelIndex &)));
              connect(ui->EDIT_LAYOUT_LAYOUT_SETTINGS_Config_Table_2, SIGNAL(clicked(const QModelIndex &)), this, SLOT(onTableClicked_63(const QModelIndex &)));


             connect(&mDataTimer, SIGNAL(timeout()), this, SLOT(timerSlot()));
             mDataTimer.start(samplerate);


}

MainWindow::~MainWindow()
{
    delete ui;
}


unsigned int MainWindow::get_pre_trigger_time()
{

    //default pre-trigger values

    QModelIndex index = model2->index(0, 1, QModelIndex());
 //qDebug()<<".....................................1000";
    QString cellText = index.data().toString();
    QStringList list = cellText.split(QRegExp(" "), QString::SkipEmptyParts);

    unsigned int val = list[0].toUInt();

    cellText4 = index.row();
    //qDebug()<<"power_arr[power_value]"<<cellText4;
    //qDebug()<<"power_arr[power_value]"<<cellText;


//    QModelIndex index2 = model2->index(1, 1, QModelIndex());

//    QString cellText2 = index2.data().toString();
//    //cellText42 = index2.row();
//    //qDebug()<<"power_arr[power_value]"<<cellText42;
//    qDebug()<<"power_arr[power_value]"<<cellText2;

    return val;
}
unsigned int MainWindow:: get_post_trigger_time()
{

    //default post-trigger values



    QModelIndex index2= model2->index(1, 1, QModelIndex());

    QString cellText2= index2.data().toString();
    QStringList list = cellText2.split(QRegExp(" "), QString::SkipEmptyParts);
 //qDebug()<<".....................................198";
    unsigned int val = list[0].toUInt();
    //cellText42 = index2.row();
    //qDebug()<<"power_arr[power_value]"<<cellText42;
    //qDebug()<<"power_arr[power_value]"<<cellText2;

    return val;
}

void MainWindow::timerSlot()
{
   #if 0
    int i=0;
    int n=0;
    int q_data=0;
    int j=0;
    float milli_v=0;
    float milli_A=0;
    unsigned short range = 0;


    uint8_t error_code=0x00;
    //Abhisek need to change

    mDataTimer.setInterval(samplerate);
   // mDataTimer.setInterval(100);


    double key = QDateTime::currentDateTime().toMSecsSinceEpoch()/1000.0; // time elapsed since start of demo, in seconds

    static double lastPointKey = QDateTime::currentDateTime().toMSecsSinceEpoch()/1000.0;;

//maxmin showing(pens)
    QModelIndex index88 = model83->index(4,1,QModelIndex());
    QString liststring = QString("");
    for (int l = 0; l < selected_MaxMin_pens.size(); ++l)
    {
      liststring.append((QString("%1,").arg(selected_MaxMin_pens[l])));
    }
    if(selected_MaxMin_pens.size() >0)
    {
        model83->setData(index88,liststring);
    }
    else
    {
        model83->setData(index88,"None");
    }

//chat showing(pens)
    QModelIndex index89 = model82->index(4,1,QModelIndex());
    QString liststring1 = QString("");
    for (int r = 0; r < selected_pens.size(); ++r)
    {
      liststring1.append((QString("%1,").arg(selected_pens[r])));
    }
    if(selected_pens.size() >0)
    {
        model82->setData(index89,liststring1);
    }
    else
    {
        model82->setData(index89,"None");
    }



    /*  Need tp set the key-lastPpintkey as perr the user input
 Note : with current implementation it is not possiible to scan the channel
        with different ttime  rate*/

time_rate_s = 0.1;//0.1

//        if(sram_initial_plot > 0)
//        {
//            for (int sram_ch=0;sram_ch<=7;sram_ch++)
//            {
//                Read_NV(sram_ch);
//            }
//            sram_initial_plot=0;
//        }
LOG_LEVEL_1 = 0;
LOG_LEVEL_2 = 0;
verbose = 0;
    if (key-lastPointKey > time_rate_s) // at most add point every 3 sec
    {






        for (i = 0; i <= MAX_AI_SLOT; i++)
        {
//            if ((slot_info[i]->board_type == BOARD_AI) && (EnAcqFlag == 1) )
             if ((slot_info[i]->board_type == BOARD_AI))

            {
//                if(resetCounter[i] == 1)
//                {
//                    resetCounter[i] = 0;

//                  for (j = 1; j<=48; j++)
//                   {
//                       curr_time[j] = 0;
//                       prev_time[j] = 0;
//                       new_AI_data[j]=0;
//                   }
//                }


                if (resetCounter[i] > 25)
                {
                    result = reset_CircularBuff(fd, i, 1);
                    resetCounter[i] = 0;
                    if (result == 1)
                    {
                        resetCounter[i] = 0;
                        for (j = 1; j<=48; j++)
                        {
                            curr_time[j] = 0;
                            prev_time[j] = 0;

                        }

                    }
                    else
                        result = reset_CircularBuff(fd, i, 1);
                    if (result != 1)
                        printf("failed second time also\n");
                }
                if(resetCounter[i] == 0)
                {

                }
                else
                {
                     result = scanAICardChannel(fd, i);
                }


                resetCounter[i] = resetCounter[i]+1;



            }
        }


//CHART PLOTTING maxmin


        if(screen_type == 2)
        {
           // EnAcqFlag =1;
            if(initial < 1)
            {
                for (int v = 0; v < 6; ++v)
                {
                    result = reset_CircularBuff(fd, v, 1);
                    resetCounter[v] = 2;
                    for (int z = 1; z<=48; z++)
                    {
                        curr_time[z] = 0;
                        prev_time[z] = 0;

                    }
                }

            }
            initial++;

            int pen_num;
          for (int var = 0; var < selected_MaxMin_pens.size(); ++var)
          {
               //qDebug()<<"selected pens="<<selected_MaxMin_pens[var];

                QString selectedpenobject1 = "Pen";//change the values of the pen object name "pen5"
                selectedpenobject1.append((QString("%1").arg(selected_MaxMin_pens[var])));
                pen_num = selected_MaxMin_pens[var];

                QPushButton * targetlabel1 = window1->findChild<QPushButton*>(selectedpenobject1);
               // qDebug()<<"value1="<<targetlabel1;



                if(targetlabel1)
                {


                    if(mt_PEN[pen_num] != NULL )
                       {
                        if((mt_PEN[pen_num]->Enabled > 0) && (mt_PEN[pen_num]->Board_type == BOARD_AI) && (mt_PEN[pen_num]->ChNum > 0))
                        {
                            if (new_AI_data[mt_PEN[pen_num]->ChNum] > 0)
                            {
//                                printf("\nCh_Num %d Data_pts %d:\n", mt_PEN[pen_num]->ChNum, new_AI_data[mt_PEN[pen_num]->ChNum]);

                                for (j = 1; j <= new_AI_data[mt_PEN[pen_num]->ChNum] ; j++)
                                {
                                    q_data = deQueue((mt_PEN[pen_num]->ChNum), Q_ptr[mt_PEN[pen_num]->ChNum]);
                                    //printf("%d   ",q_data);

                                    /*********************sriram milliv************************/
//                                    qDebug()<<"AIOchinfo[mt_PEN[pen_num]->ChNum]->AIchinfo->SensorRange = " << AIOchinfo[mt_PEN[pen_num]->ChNum]->AIchinfo->SensorRange;
                                    if (AIOchinfo[mt_PEN[pen_num]->ChNum]->AIchinfo->SensorRange == Preset)
                                    {
                                        qDebug()<< " AIOchinfo[mt_PEN[pen_num]->ChNum]->AIchinfo->VRangetype = "<< AIOchinfo[mt_PEN[pen_num]->ChNum]->AIchinfo->VRangetype;
                                        milli_v = AIProcessChannelReading(q_data,AIOchinfo[mt_PEN[pen_num]->ChNum]->AIchinfo->VRangetype,(mt_PEN[pen_num]->ChNum));

//                                       // qDebug()<<"we have selected --> Preset";

                                    }
                                    else if(AIOchinfo[mt_PEN[pen_num]->ChNum]->AIchinfo->SensorRange == User_defined)
                                    {
//                                        qDebug()<<"we have selected --> User_Defined";

                                        range = GetRangeClosestMatch (0,
                                                                      AIOchinfo[mt_PEN[pen_num]->ChNum]->AIchinfo->SensorType,
                                                AIOchinfo[mt_PEN[pen_num]->ChNum]->AIchinfo->userVal.UserHighLim, AIOchinfo[mt_PEN[pen_num]->ChNum]->AIchinfo->userVal.UserLowLim, AIOchinfo[mt_PEN[pen_num]->ChNum]->AIchinfo->userVal.UserVoltUnits);


                                        milli_v = AIProcessChannelReading(q_data,range,(mt_PEN[pen_num]->ChNum));

                                    }

                                    if (AIOchinfo[mt_PEN[pen_num]->ChNum]->AIchinfo->SensorType == Volts)
                                    {
//                                        qDebug()<<"Channel is of type --> Volts";
                                        milli_v_A[mt_PEN[pen_num]->ChNum] = milli_v;
//                                        printf("%d %f  ",q_data, milli_v);

                                    }
                                    else if(AIOchinfo[mt_PEN[pen_num]->ChNum]->AIchinfo->SensorType == Amps)
                                    {
//                                        qDebug()<<"Channel is of type --> Amps";
                                        milli_A = get_measuredmA(mt_PEN[pen_num]->ChNum);
                                        milli_v_A[mt_PEN[pen_num]->ChNum] = milli_A;
//                                        printf("%d %f  ",q_data, milli_A);
                                    }

                                    //printf("======================= chaType[%d] : %d \n",i, chanType[pen_num]);
                                    /*********************************************/





                                    //milli_v_A[mt_PEN[pen_num]->ChNum]=q_data;
                                    pen_reading_value[pen_num]=milli_v_A[mt_PEN[pen_num]->ChNum];
                                    if((mt_PEN[pen_num]->PenLog.Enabled == 1 && mt_PEN[pen_num]->ChNum > 0) )
                                    {

                                        if(PenLogCounter == PenLogTimer)
                                        {

                                        /***  printing in file  *****/
                                        t = time(NULL);
                                        tm = *localtime(&t);
                                        fprintf(fptr_log[pen_num], "\"%d/%02d/%02d  %02d:%02d:%02d\",%f,\n",
                                                tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900, tm.tm_hour, tm.tm_min, tm.tm_sec, milli_v_A[mt_PEN[pen_num]->ChNum]);

                                        }

                                    }
                                    //maxmin object
                                    maxmin.IntialiseMaxMin(pen_num);
                                    maxmin.DoMaxMin();
                                    targetlabel1->setText(selectedpenobject1+"\n"+"PV: "+QString(QString::number(milli_v_A[mt_PEN[pen_num]->ChNum],'f',6))+"\n"+"Max:"+QString(QString::number(maxmin.GetMax(pen_num),'f',6))+"\n"+"Min:"+QString(QString::number(maxmin.GetMin(pen_num),'f',6)));
                                   targetlabel1->show();
                                }
                                new_AI_data[mt_PEN[pen_num]->ChNum] = 0;

//                                printf("\n");

                            }


                        }
                    }
                    else
                    {
                         milli_v_A[mt_PEN[pen_num]->ChNum]=0;
                        targetlabel1->setText(selectedpenobject1+"\n"+"PV: "+QString(QString::number(milli_v_A[mt_PEN[pen_num]->ChNum],'f',3))+"\n"+"Max:"+QString(QString::number(maxmin.GetMax(pen_num),'f',3))+"\n"+"Min:"+QString(QString::number(maxmin.GetMin(pen_num),'f',3)));

                    }



                }


          }

        }




//chart plot

        if(screen_type == 1)
        {
            //EnAcqFlag =1;
            if(initial < 1)
            {
                for (int v = 0; v < 6; ++v)
                {
                    result = reset_CircularBuff(fd, v, 1);
                    resetCounter[v] = 2;
                    for (int z = 1; z<=48; z++)
                    {
                        curr_time[z] = 0;
                        prev_time[z] = 0;

                    }
                }

            }
            initial++;


            int pen_num;
          for (int var = 0; var < selected_pens.size(); ++var)
          {

                QString selectedpenobject1 = "Pen";//change the values of the pen object name "pen5"
                selectedpenobject1.append((QString("%1").arg(selected_pens[var])));
                pen_num = selected_pens[var];

                QLabel * targetlabel1 = Frame->findChild<QLabel*>(selectedpenobject1);
               // qDebug()<<"value1="<<targetlabel1;



                if(targetlabel1)
                {

                    if(mt_PEN[pen_num] != NULL )
                       {
                        if((mt_PEN[pen_num]->Enabled > 0) && (mt_PEN[pen_num]->Board_type == BOARD_AI) && (mt_PEN[pen_num]->ChNum > 0))
                        {
                            if (new_AI_data[mt_PEN[pen_num]->ChNum] > 0)
                            {
//                                printf("\nCh_Num %d Data_pts %d:\n", mt_PEN[pen_num]->ChNum, new_AI_data[mt_PEN[pen_num]->ChNum]);

                                for (j = 1; j <= new_AI_data[mt_PEN[pen_num]->ChNum] ; j++)
                                {
                                    q_data = deQueue((mt_PEN[pen_num]->ChNum), Q_ptr[mt_PEN[pen_num]->ChNum]);

                                    //printf("%d   ",q_data);

                                    /*********************sriram milliv************************/

                                    if (AIOchinfo[mt_PEN[pen_num]->ChNum]->AIchinfo->SensorRange == Preset)
                                    {

                                        milli_v = AIProcessChannelReading(q_data,AIOchinfo[mt_PEN[pen_num]->ChNum]->AIchinfo->VRangetype,(mt_PEN[pen_num]->ChNum));
                                        //qDebug()<<"we have selected --> Preset";

                                    }
                                    else if(AIOchinfo[mt_PEN[pen_num]->ChNum]->AIchinfo->SensorRange == User_defined)
                                    {
//                                        qDebug()<<"we have selected --> User_Defined";

                                        range = GetRangeClosestMatch (0,
                                                                      AIOchinfo[mt_PEN[pen_num]->ChNum]->AIchinfo->SensorType,
                                                AIOchinfo[mt_PEN[pen_num]->ChNum]->AIchinfo->userVal.UserHighLim, AIOchinfo[mt_PEN[pen_num]->ChNum]->AIchinfo->userVal.UserLowLim, AIOchinfo[mt_PEN[pen_num]->ChNum]->AIchinfo->userVal.UserVoltUnits);


                                        milli_v = AIProcessChannelReading(q_data,range,(mt_PEN[pen_num]->ChNum));

                                    }

                                    if (AIOchinfo[mt_PEN[pen_num]->ChNum]->AIchinfo->SensorType == Volts)
                                    {
//                                        qDebug()<<"Channel is of type --> Volts";
                                        milli_v_A[mt_PEN[pen_num]->ChNum] = milli_v;
                                        //milli_v_A[mt_PEN[pen_num]->ChNum]=

                                        //printf("%d %f  ",q_data, milli_v);

                                    }
                                    else if(AIOchinfo[mt_PEN[pen_num]->ChNum]->AIchinfo->SensorType == Amps)
                                    {
//                                        qDebug()<<"Channel is of type --> Amps";
                                        milli_A = get_measuredmA(mt_PEN[pen_num]->ChNum);
                                        milli_v_A[mt_PEN[pen_num]->ChNum] = milli_A;
                                        //printf("%d %f  ",q_data, milli_A);
                                    }

                                    //printf("======================= chaType[%d] : %d \n",i, chanType[pen_num]);
                                    /*********************************************/





                                    //milli_v_A[mt_PEN[pen_num]->ChNum]=q_data;
                                    pen_reading_value[pen_num]=milli_v_A[mt_PEN[pen_num]->ChNum];
                                    if((mt_PEN[pen_num]->PenLog.Enabled == 1 && mt_PEN[pen_num]->ChNum > 0) )
                                    {
                                        if(PenLogCounter == PenLogTimer)
                                        {

                                        /***  printing in file  *****/
                                        t = time(NULL);
                                        tm = *localtime(&t);
                                        fprintf(fptr_log[pen_num], "\"%d/%02d/%02d  %02d:%02d:%02d\",%f,\n",
                                                tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900, tm.tm_hour, tm.tm_min, tm.tm_sec, milli_v_A[mt_PEN[pen_num]->ChNum]);

                                        }
                                    }

//                                     targetlabel1->setText(selectedpenobject1+"\t%\n"+QString("%1 ").arg(milli_v_A[mt_PEN[pen_num]->ChNum]));
//                                   targetlabel1->show();
                                   //mgraph_ptr[0]->addData(key,milli_v_A[mt_PEN[pen_num]->ChNum]);

                                 switch(var)
                                  {
                                      case 0:
                                                         mGraph1->setPen(QPen(QColor(255,0,0)));
                                       mTag1->setText(QString::number(pen_num));

                                       targetlabel1->setText(selectedpenobject1+"\t%\n"+QString("%1 ").arg(milli_v_A[mt_PEN[pen_num]->ChNum]));
                                                         targetlabel1->setStyleSheet("color: rgb(255,0,0);border-top:none;border-bottom:none;border-left:none;");
                                     targetlabel1->show();
                                      mGraph1->addData(key, milli_v_A[mt_PEN[pen_num]->ChNum]);


                                       break;
                                      case 1:
                                                             mGraph2->setPen(QPen(QColor(255,105,180)));
                                           mTag2->setText(QString::number(pen_num));
                                           targetlabel1->setText(selectedpenobject1+"\t%\n"+QString("%1 ").arg(milli_v_A[mt_PEN[pen_num]->ChNum]));
                                                             targetlabel1->setStyleSheet("color: rgb(255,105,180);border-top:none;border-bottom:none;border-left:none;");
                                         targetlabel1->show();
                                           mGraph2->addData(key, milli_v_A[mt_PEN[pen_num]->ChNum]);

                                           break;
                                      case 2:
                                                             mGraph3->setPen(QPen(QColor(0,128,0)));
                                           mTag3->setText(QString::number(pen_num));
                                           targetlabel1->setText(selectedpenobject1+"\t%\n"+QString("%1 ").arg(milli_v_A[mt_PEN[pen_num]->ChNum]));
                                                             targetlabel1->setStyleSheet("color: rgb(0,128,0);border-top:none;border-bottom:none;border-left:none;");
                                         targetlabel1->show();
                                           mGraph3->addData(key, milli_v_A[mt_PEN[pen_num]->ChNum]);
                                           break;
                                      case 3:
                                                             mGraph4->setPen(QPen(QColor(0,0,255)));
                                           mTag4->setText(QString::number(pen_num));
                                           targetlabel1->setText(selectedpenobject1+"\t%\n"+QString("%1 ").arg(milli_v_A[mt_PEN[pen_num]->ChNum]));
                                                             targetlabel1->setStyleSheet("color: rgb(0,0,255);border-top:none;border-bottom:none;border-left:none;");
                                         targetlabel1->show();
                                           mGraph4->addData(key, milli_v_A[mt_PEN[pen_num]->ChNum]);
                                           break;
                                      case 4:
                                                             mGraph5->setPen(QPen(QColor(165,42,42)));
                                           mTag5->setText(QString::number(pen_num));
                                           targetlabel1->setText(selectedpenobject1+"\t%\n"+QString("%1 ").arg(milli_v_A[mt_PEN[pen_num]->ChNum]));
                                                             targetlabel1->setStyleSheet("color: rgb(165,42,42);border-top:none;border-bottom:none;border-left:none;");
                                         targetlabel1->show();
                                           mGraph5->addData(key, milli_v_A[mt_PEN[pen_num]->ChNum]);
                                           break;
                                      case 5:
                                                             mGraph6->setPen(QPen(QColor(255,99,71)));
                                           mTag6->setText(QString::number(pen_num));
                                           targetlabel1->setText(selectedpenobject1+"\t%\n"+QString("%1 ").arg(milli_v_A[mt_PEN[pen_num]->ChNum]));
                                                             targetlabel1->setStyleSheet("color: rgb(255,99,71);border-top:none;border-bottom:none;border-left:none;");
                                         targetlabel1->show();
                                           mGraph6->addData(key, milli_v_A[mt_PEN[pen_num]->ChNum]);
                                           break;
                                      case 6:
                                                             mGraph7->setPen(QPen(QColor(30,144,255)));
                                           mTag7->setText(QString::number(pen_num));
                                           targetlabel1->setText(selectedpenobject1+"\t%\n"+QString("%1 ").arg(milli_v_A[mt_PEN[pen_num]->ChNum]));
                                                             targetlabel1->setStyleSheet("color: rgb(30,144,255);border-top:none;border-bottom:none;border-left:none;");
                                         targetlabel1->show();
                                           mGraph7->addData(key, milli_v_A[mt_PEN[pen_num]->ChNum]);
                                           break;
                                      case 7:
                                                             mGraph8->setPen(QPen(QColor(128,0,0)));
                                           mTag8->setText(QString::number(pen_num));
                                           targetlabel1->setText(selectedpenobject1+"\t%\n"+QString("%1 ").arg(milli_v_A[mt_PEN[pen_num]->ChNum]));
                                                             targetlabel1->setStyleSheet("color: rgb(128,0,0);border-top:none;border-bottom:none;border-left:none;");
                                         targetlabel1->show();
                                           mGraph8->addData(key, milli_v_A[mt_PEN[pen_num]->ChNum]);
                                           break;
                                      default:
                                          break;
                                  }
                                }
                                new_AI_data[mt_PEN[pen_num]->ChNum] = 0;

                               // printf("\n");

                            }


                        }
                    }
                    else
                    {
                         milli_v_A[mt_PEN[pen_num]->ChNum]=0;
                        targetlabel1->setText(selectedpenobject1+"\t%\n"+QString("%1 ").arg(milli_v_A[mt_PEN[pen_num]->ChNum]));

                    }



                }


          }

        }




        // qDebug()<<"timerslot";




        lastPointKey = key;


        if(PenLogCounter == PenLogTimer)
        {
            PenLogCounter=0;
        }
         PenLogCounter++;


    }
    QSharedPointer<QCPAxisTickerDateTime> dateTicker(new QCPAxisTickerDateTime);
    //dateTicker->setDateTimeFormat("HH:mm:ss \n d MMM yyyy");
    dateTicker->setDateTimeFormat(" hh:mm:ss \n yyyy-MM-dd ");
    mPlot->xAxis2->setTicker(dateTicker);

    QDateTime currentdatetime = QDateTime::currentDateTime();
     QString dateTimeString = currentdatetime.toString("yyyy-MM-dd  hh:mm:ss");
     ui->label->setText("0001:Multitrend\n" + dateTimeString);

    mPlot->xAxis2->setVisible(true);
    mPlot->xAxis->setVisible(false);
    mPlot->xAxis2->rescale();
    mPlot->xAxis2->grid()->setVisible(true);
    mPlot->yAxis2->grid()->setVisible(true);
    mPlot->yAxis2->grid()->setSubGridVisible(true);
    mPlot->xAxis2->grid()->setSubGridVisible(true);
    mGraph1->rescaleValueAxis(false, true);
    mGraph2->rescaleValueAxis(false, true);
    mGraph3->rescaleValueAxis(false, true);
    mGraph4->rescaleValueAxis(false, true);
    mGraph5->rescaleValueAxis(false, true);
    mGraph6->rescaleValueAxis(false, true);
    mGraph7->rescaleValueAxis(false, true);
    mGraph8->rescaleValueAxis(false, true);
    //mPlot->xAxis2->setRange(mPlot->xAxis2->range().upper, 500, Qt::AlignRight);
    mPlot->xAxis2->setRange(key, 1000, Qt::AlignRight);//second arg 64,128,256........250
    mPlot->replot();
    // update the vertical axis tag positions and texts to match the rightmost data point of the graphs:
    int graph1Value = 0;
    int graph2Value = 0;
    int graph3Value = 0;
    int graph4Value = 0;
    int graph5Value = 0;
    int graph6Value = 0;
    int graph7Value = 0;
    int graph8Value = 0;
    if (mGraph1->dataCount() >0)
        graph1Value = mGraph1->dataMainValue(mGraph1->dataCount()-1);
    if (mGraph2->dataCount() >0)
        graph2Value = mGraph2->dataMainValue(mGraph2->dataCount()-1);
    if (mGraph3->dataCount() >0)
        graph3Value = mGraph3->dataMainValue(mGraph3->dataCount()-1);
    if (mGraph4->dataCount() >0)
        graph4Value = mGraph4->dataMainValue(mGraph4->dataCount()-1);
    if (mGraph5->dataCount() >0)
        graph5Value = mGraph5->dataMainValue(mGraph5->dataCount()-1);
    if (mGraph6->dataCount() >0)
        graph6Value = mGraph6->dataMainValue(mGraph6->dataCount()-1);
    if (mGraph7->dataCount() >0)
        graph7Value = mGraph7->dataMainValue(mGraph7->dataCount()-1);
    if (mGraph8->dataCount() >0)
        graph8Value = mGraph8->dataMainValue(mGraph8->dataCount()-1);
   // m_Instance->GetPenControl(pen_num,ZERO_BASED);


    int graph_value[]={graph1Value,graph2Value,graph3Value,graph4Value,graph5Value,graph6Value,graph7Value,graph8Value};
    for(int i=0;i<8;i++)
    {
         m_pen =  m_Instance->GetPenControl(i,ZERO_BASED);
//        qDebug()<<"status=" <<m_pen->m_preTrigger.m_Enabled;
        if(m_pen != NULL)
             {
               if(m_pen->m_preTrigger.m_Enabled == TRUE)
               {
                    m_pen->m_preTrigger.AddReading(i,graph_value[i],1878);
                    // qDebug()<<graph1Value;
               }
             }
    }

    mTag1->setPen(mGraph1->pen());
    mTag2->setPen(mGraph2->pen());
    mTag3->setPen(mGraph3->pen());
    mTag4->setPen(mGraph4->pen());
    mTag5->setPen(mGraph5->pen());
    mTag6->setPen(mGraph6->pen());
    mTag7->setPen(mGraph7->pen());
    mTag8->setPen(mGraph8->pen());

    mTag1->updatePosition(graph1Value);
    mTag2->updatePosition(graph2Value);
    mTag3->updatePosition(graph3Value);
    mTag4->updatePosition(graph4Value);
    mTag5->updatePosition(graph5Value);
    mTag6->updatePosition(graph6Value);
    mTag7->updatePosition(graph7Value);
    mTag8->updatePosition(graph8Value);

//    mTag1->setText(QString::number(1));
//    mTag2->setText(QString::number(2));
//    mTag3->setText(QString::number(3));
//    mTag4->setText(QString::number(4));
//    mTag5->setText(QString::number(5));
//    mTag6->setText(QString::number(6));
//    mTag7->setText(QString::number(7));
//    mTag8->setText(QString::number(8));



   //QColor c = mGraph1->pen().(QColor color());

//    QColorDialog *dialog = new QColorDialog(this);
//    QColor color=  dialog->getColor();
//    QVariant variant= color;
//    QString colcode = variant.toString();
//    ui->label->setStyleSheet("QLabel { background-color :"+colcode+" ; color : blue; }");



//    ui->label_2->setText("Pen 1\n");
//    ui->label_2->setText(ui->label_2->text()+QString::number(graph1Value, 'f', 2));
//    ui->label_2->setStyleSheet("color : blue;padding: 0px 5px 0px 0px;");

//        QBrush b =mTag1->brush();
//        QColor c = b.color();
////        qDebug()<<"color="<<c;
//        QVariant variant= c;
//        QString colcode = variant.toString();
////        qDebug()<<"colorcolcode="<<colcode;

    ////////////////////////////////////////////
    //updating the DPMs with respect to channels


//    for (int var = 0; var < selected_pens.size(); ++var)
//    {
//         //qDebug()<<"selected pens="<<selected_pens[var];


//    QString selectedpenobject = "Pen";//change the values of the pen object name "pen5"
//    selectedpenobject.append((QString("%1").arg(selected_pens[var])));
//    QLabel * targetlabel = Frame->findChild<QLabel*>(selectedpenobject);
//    //qDebug()<<"value="<<targetlabel;
//    if(targetlabel)
//    {
//        targetlabel->setText(selectedpenobject+"\t\n"+QString("%1 ").arg(graph_value[selected_pens[var]-1]));
//        targetlabel->setWordWrap(true);
////        mTag1->setText(QString::number(selected_pens[var]-1));
////        mTag1->updatePosition(graph_value[selected_pens[var]-1]);

//        //targetlabel->setStyleSheet("color:"+colcode+"");
//    }
//    }



    /////////////////////////////////////
    /////////////////////////////////////
//        maxmin.DoMaxMin();
//      pen_reading_value=QVariant(graph1Value).toFloat();
//      //pen_reading_value=100;
//      for (int var = 0; var < selected_MaxMin_pens.size(); ++var)
//      {
//           //qDebug()<<"selected pens="<<selected_MaxMin_pens[var];

//            QString selectedpenobject1 = "Pen";//change the values of the pen object name "pen5"
//            selectedpenobject1.append((QString("%1").arg(selected_MaxMin_pens[var])));
//            QPushButton * targetlabel1 = window1->findChild<QPushButton*>(selectedpenobject1);
//           // qDebug()<<"value1="<<targetlabel1;



//            if(targetlabel1)
//            {
//                 //qDebug()<<"arrow1="<<selectedpenobject1;
//              //  targetlabel1->setText(selectedpenobject1+"\n"+"PV: "+QString(QVariant(graph1Value).toString()).insert(0,downarrow.repeated(4)));
//                 targetlabel1->setText(selectedpenobject1+"\n"+"PV: "+QString(QVariant(graph_value[selected_MaxMin_pens[var]-1]).toString())+"\n"+"Max:"+QString(QVariant(maxmin.GetMax()).toString())+"\n"+"Min:"+QString(QVariant(maxmin.GetMin()).toString()));
//                targetlabel1->show();
//            }


//      }
#endif

}

void MainWindow::Gui_card_detection()
{
    int i=0;
    for (i = 0; i<=5; i++)
    {
        if (slot_info[i]->board_type == BOARD_AI)
        {
            AI_card = AI_card+1;
            numAIChannel = numAIChannel + slot_info[i]->phy_num_channel;
        }
        else if (slot_info[i]->board_type == BOARD_AO)
        {
            AO_card = AO_card+1;

        }
        else if (slot_info[i]->board_type == BOARD_PI)
        {
            PI_card = PI_card+1;
        }

    }

    for (i=6; i <=8;i++)
    {
        if (slot_info[i]->board_type == BOARD_DIO || slot_info[i]->board_type == BOARD_AR)
        {
            DIO_card = DIO_card+1;
            numDIOch = numDIOch+slot_info[i]->phy_num_channel;
        }
    }
}
void MainWindow::Gui_pen_detection()
{
    int i;
    for (int i = 1; i <= 96; ++i)
    {

        if(mt_PEN[i] != NULL && mt_PEN[i]->Enabled > 0 )
         {
           TotalPenCount++;
          // qDebug()<<"i value ="<<i;
         }

    }

}

void MainWindow::boot_startup()
{
    /*****************************************************************/
#if 0

            int j=0;
        int result;

        //Sram initialization
        result = sram_initialise();
        result = Read_NV(1);

        m_Instance = CPenManager::GetHandle();//$Amiya
        m_Instance->Initialise();
           //initializing spi
           result = spi_gpio_init();
           result = irq_init();
           result = SPI_init(fd);

           /* Detecting slot */
            //LOG_LEVEL_1 = 3;
           // LOG_LEVEL_2 = 0;
            //verbose = 0;
            result = DetectSlot(fd);


            this->Gui_card_detection();



            int i = 0, n = 0;
            float milli_v;
            int q_data;

            for (i = 0; i<=MAX_AI_SLOT; i++)
            {
                result = fillAICARD_ChannelData(fd, i);
            }

            for (i = 1; i<=MAX_AI_CHANNEL; i++)
            {
                if (AIChannelinfo[i] != NULL)
                {
                    result = AIQueueInitilisation(i, &Front[i], &Rear[i], Q_ptr[i]);
                }

            }

            printf("channel_delay\n");
            for (i = 1; i <=48; i++)
            {
                if (AIChannelinfo[i] != NULL)
                    printf("i.%d %d %d %d %d\n", i, AIChannelinfo[i]->ChannelNumber, channel_delay[i], Front[i], Rear[i]);
            }
            printf("\n");



            result = AOCardChannelInfo();
            result = fillAOCardChannelInfo();
            qDebug()<<"..";
            result = DIO_Card_ChannelInfo();
            qDebug()<<"...";
            result = fillDIOCardChannelInfo();
            qDebug()<<"....";
            result = AICardChannelInfo();
            qDebug()<<"....";
            result = fillAICardChannelInfo();
qDebug()<<"....";
            result = penIntiallization();
            qDebug()<<".........";
            this->Gui_pen_detection();

            for (i = 1; i <=48; i++)
            {
                if (AIChannelinfo[i] != NULL && AIOchinfo[i]->AIchinfo  != NULL)
                {
                   AIOchinfo[i]->AIchinfo->range =  AIChannelinfo[i]->ack_range;

                   switch(AIOchinfo[i]->AIchinfo->range)
                   {
                    case 0x50:
                       AIOchinfo[i]->AIchinfo->VRangetype = mv_5;
                       break;
                   case 0x51:
                      AIOchinfo[i]->AIchinfo->VRangetype = mv_10;
                      break;
                   case 0x52:
                      AIOchinfo[i]->AIchinfo->VRangetype = mv_25;
                      break;
                   case 0x53:
                      AIOchinfo[i]->AIchinfo->VRangetype = mv_50;
                      break;
                   case 0x54:
                      AIOchinfo[i]->AIchinfo->VRangetype = mv_100;
                      break;
                   case 0x55:
                      AIOchinfo[i]->AIchinfo->VRangetype = mv_250;
                      break;
                   case 0x56:
                      AIOchinfo[i]->AIchinfo->VRangetype = mv_500;
                      break;
                   case 0x57:
                      AIOchinfo[i]->AIchinfo->VRangetype = mv_1000;
                      break;
                   case 0x20:
                      AIOchinfo[i]->AIchinfo->VRangetype = v_0_3;
                      break;
                   case 0x21:
                      AIOchinfo[i]->AIchinfo->VRangetype = v_0_6;
                      break;
                   case 0x22:
                      AIOchinfo[i]->AIchinfo->VRangetype = v_1_5;
                      break;
                   case 0x23:
                      AIOchinfo[i]->AIchinfo->VRangetype = v_3;
                      break;
                   case 0x24:
                      AIOchinfo[i]->AIchinfo->VRangetype = v_6;
                      break;
                   case 0x25:
                      AIOchinfo[i]->AIchinfo->VRangetype = v_12;
                      break;
                   case 0x26:
                      AIOchinfo[i]->AIchinfo->VRangetype = v_25;
                      break;
                   case 0x27:
                      AIOchinfo[i]->AIchinfo->VRangetype = v_50;
                      break;

                   default:
                      break;
                   }

                   AIOchinfo[i]->AIchinfo->frequency =  AIChannelinfo[i]->ack_frq;
                   AIOchinfo[i]->AIchinfo->SensorType = Volts;
                   AIOchinfo[i]->AIchinfo->Sen_Type = 0;
//                   AIOchinfo[i]->AIchinfo->SRate = ;
                   AIOchinfo[i]->AIchinfo->SensorRange = Preset;
//                   AIOchinfo[i]->AIchinfo->Sen_Range = ?;
                   AIOchinfo[i]->AIchinfo->sensorComp.type = 0;
                   AIOchinfo[i]->AIchinfo->sensorComp.singlepoint_val = 10;
                   AIOchinfo[i]->AIchinfo->sensorComp.dualPtEngLow = 20;
                   AIOchinfo[i]->AIchinfo->sensorComp.dualPtEngHigh = 80;
                   AIOchinfo[i]->AIchinfo->sensorComp.dualPtOffsetLow = 10;
                   AIOchinfo[i]->AIchinfo->sensorComp.dualPtOffsetHigh = 10;
                   AIOchinfo[i]->AIchinfo->userVal.UserVoltUnits = V;
                   AIOchinfo[i]->AIchinfo->userVal.UserLowLim = -12;
                   AIOchinfo[i]->AIchinfo->userVal.UserHighLim = 12;

                }

            }

//            for(i=1;i<=8;i++)
//            {
//                QString edit_math = QString("A");
//                edit_math.append(QString("%1").arg(i));
//                strncpy(mt_PEN[Pen_Selected]->MathsBlock, edit_math.toLocal8Bit().constData(), edit_math.size());
//            }






            //qDebug()<<"end 0f milestone 3........................";
/*
 * MS-4 imlementation
 *
*/
        if(AI_card > 0)
        {
            ui->toolButton_30->setEnabled(true);
        }

        if(AO_card > 0)
        {
            ui->toolButton_27->setEnabled(true);
        }

        if(PI_card > 0)
        {
            ui->toolButton_24->setEnabled(true);
        }
        if((DIO_card > 0) || (AR_card > 0))
        {
            ui->toolButton_23->setEnabled(true);
        }



/* AI */

        model5= new QStandardItemModel(numAIChannel,2,this);
         ui->tableView_6->setModel(model5);
         ui->tableView_6->setColumnWidth(0,250);
         ui->tableView_6->setColumnWidth(1,400);
         ui->tableView_6->setStyleSheet(
                                          "QTableView::item{"
                                          "border: 1px solid black;"
                                          "border-radius: 5px;"
                                          "background-color: rgb(255, 255, 127);"
                                          "color: black;"
                                          "}"
                                          );
         //ui->tableView_6->setStyleSheet("QTableView{image: url(/home/pi/Desktop/Paperless_Recorder_gui/table_colour.jpg);background-color: rgb(251, 255, 207);}");
             // Generate data numAIChannel+1
         int AIc_row = 0;
         int n_chavail =0;


//qDebug()<<"////////////////////////////////////////"<<vrangtype[0];
         for (int var = 0; var < 6; ++var)
         {
         if (slot_info[var]->board_type == BOARD_AI)
          {
             n_chavail = slot_info[var]->board_data->bd_capability->ch_available;

             for(int row = 0; row < n_chavail; row++)
             {

                     ui->tableView_6->setRowHeight(AIc_row,40);

                     {
                         QModelIndex index = model5->index(AIc_row,0,QModelIndex());

                         QString text= QString("Analog In ");
                         text.append(QString("%1,").arg((var*8)+row+1));
                         model5->setData(index,text);
                         QModelIndex index1 = model5->index(AIc_row,1,QModelIndex());
                         QString text1= QString("A");
                         text1.append(QString("%1").arg((var*8)+row+1));
                         if(AIOchinfo[(var*8)+row+1]->AIchinfo != NULL)
                         {
                           // qDebug()<<"..............................1999 "<<row<<var;
//                            qDebug()<<"..............................A1"<<AIOchinfo[(var*8)+row+1]->AIchinfo->SensorType;
                            //qDebug()<<"..............................A2"<<AIOchinfo[(var*8)+row+1]->AIchinfo->VRangetype;
                            //qDebug()<<"..............................A3"<<AIOchinfo[(var*8)+row+1]->AIchinfo->SRate;
                         QString text2 = QString(sen_type[AIOchinfo[(var*8)+row+1]->AIchinfo->SensorType]);
                         QString text3= QString(vrangtype[AIOchinfo[(var*8)+row+1]->AIchinfo->VRangetype]);
                         QString text4= QString(Sample_Rate[AIOchinfo[(var*8)+row+1]->AIchinfo->SRate]);
                         //qDebug()<<"..............................18888";
                         text1.append(QString(",%1 ").arg(text2));
                         text1.append(QString("%1,").arg(text3));
                         text1.append(QString("%1 ").arg(text4));
                         }
                         model5->setData(index1,text1);


                     }
                AIc_row++;
             }
         }
         }

//qDebug()<<"end 0f milestone 4........................";


/*pen listing */

model = new QStandardItemModel(TotalPenCount,2,this);
ui->tableView->setModel(model);

ui->tableView->setColumnWidth(0,250);
ui->tableView->setColumnWidth(1,400);
ui->tableView->horizontalHeader()->hide();
ui->tableView->verticalHeader()->hide();
ui->tableView->setStyleSheet(
                                 "QTableView::item{"
                                 "border: 1px solid black;"
                                 "border-radius: 5px;"
                                 "background-color: rgb(255, 255, 127);"
                                 "color: black;"
                                 "}"
                                 );

//qDebug()<<"TotalPenCount==============="<<TotalPenCount;
int pen_row_index = 0;
for (int i = 1; i <=96; ++i)
{
if(mt_PEN[i] !=NULL && mt_PEN[i]->Enabled > 0)
{

     ui->tableView->setRowHeight(pen_row_index,40);
     {
         QModelIndex index = model->index(pen_row_index,0,QModelIndex());
         QString text= QString("Pen ");
         text.append(QString("%1 ").arg(i));
         model->setData(index,text);


         QModelIndex index1 = model->index(pen_row_index,1,QModelIndex());
         // 0 for all data
         //QString text1= QString("Pen , 0.00 to 100.00 %");
         QString text1= QString("Pen ");
         text1.append(QString("%1 ").arg(i));
         QString text2= QString(", 0.00 to 100.00 %");
         text1.append(QString("%1 ").arg(text2));
         model->setData(index1,text1);

        pen_row_index++;

     }
 }
}








/*  AO Making number of table */


        model9 = new QStandardItemModel((AO_card*4),2,this);
        ui->tableView_19->setModel(model9);

        ui->tableView_19->setColumnWidth(0,250);
        ui->tableView_19->setColumnWidth(1,400);
        ui->tableView_19->horizontalHeader()->hide();
        ui->tableView_19->verticalHeader()->hide();
        ui->tableView_19->setStyleSheet(
                                         "QTableView::item{"
                                         "border: 1px solid black;"
                                         "border-radius: 5px;"
                                         "background-color: rgb(255, 255, 127);"
                                         //"color: black;"
                                         "}"
                                         );



/*******************************/
        int c_row = 0;

        if (slot_info[1]->board_type == BOARD_AO)
         {

             for(int row = 0; row < 4; row++)
             {
                 ui->tableView_19->setRowHeight(c_row,40);
                 //for(int col = 0; col < 2; col++)
                 {
                     QModelIndex index = model9->index(c_row,0,QModelIndex());
                     // 0 for all data
                     QString text= QString("Ana. Out ");
                     //text.append(QString("%1 ").arg(row+1));
                     text.append(QString("%1 ").arg(row+9));
                     model9->setData(index,text);

                     QModelIndex index1 = model9->index(c_row,1,QModelIndex());
                     // 0 for all data
                     //QString text1= QString("AO 41, Pen No. 1 4-20mA");
                     QString text1= QString("AO ");
                     text1.append(QString("%1 ").arg(row+9));
                     QString text2= QString(",Pen No. ");
                     text2.append(QString("%1 ").arg(row+9));

                     if(AIOchinfo[row+9]->AOchinfo->df_out_range == 1)
                     {

                         text2.append(QString("0-20mA"));
                         text1.append(QString("%1 ").arg(text2));
                         model9->setData(index1,text1);
                     }
                     if(AIOchinfo[row+9]->AOchinfo->df_out_range == 2)
                     {
                         text2.append(QString("4-20mA"));
                         text1.append(QString("%1 ").arg(text2));
                         model9->setData(index1,text1);
                     }

                 }
                 c_row++;
             }


        }







        if (slot_info[4]->board_type == BOARD_AO)
         {

             for(int row = 0; row < 4; row++)
             {
                 ui->tableView_19->setRowHeight(c_row,40);
                 //for(int col = 0; col < 2; col++)
                 {
                     QModelIndex index = model9->index(c_row,0,QModelIndex());
                     // 0 for all data
                     QString text= QString("Ana. Out ");
                     //text.append(QString("%1 ").arg(row+1));
                     text.append(QString("%1 ").arg(row+33));
                     model9->setData(index,text);

                     QModelIndex index1 = model9->index(c_row,1,QModelIndex());
                     // 0 for all data
                     //QString text1= QString("AO 41, Pen No. 1 4-20mA");
                     QString text1= QString("AO ");
                     text1.append(QString("%1 ").arg(row+33));
                     QString text2= QString(",Pen No. ");
                     text2.append(QString("%1 ").arg(row+33));

                     if(AIOchinfo[row+33]->AOchinfo->df_out_range == 1)
                     {

                         text2.append(QString("0-20mA"));
                         text1.append(QString("%1 ").arg(text2));
                         model9->setData(index1,text1);
                     }
                     if(AIOchinfo[row+33]->AOchinfo->df_out_range == 2)
                     {
                         text2.append(QString("4-20mA"));
                         text1.append(QString("%1 ").arg(text2));
                         model9->setData(index1,text1);
                     }
                 }
                 c_row++;
             }
          }



        if (slot_info[5]->board_type == BOARD_AO)
         {

             for(int row = 0; row < 4; row++)
             {
                 ui->tableView_19->setRowHeight(c_row,40);
                 //for(int col = 0; col < 2; col++)
                 {
                     QModelIndex index = model9->index(c_row,0,QModelIndex());
                     // 0 for all data
                     QString text= QString("Ana. Out ");
                     //text.append(QString("%1 ").arg(row+1));
                     text.append(QString("%1 ").arg(row+41));
                     model9->setData(index,text);

                     QModelIndex index1 = model9->index(c_row,1,QModelIndex());
                     // 0 for all data
                     //QString text1= QString("AO 41, Pen No. 1 4-20mA");
                     QString text1= QString("AO ");
                     text1.append(QString("%1 ").arg(row+41));
                     QString text2= QString(",Pen No. ");
                     text2.append(QString("%1 ").arg(row+41));

                     if(AIOchinfo[row+41]->AOchinfo->df_out_range == 1)
                     {

                         text2.append(QString("0-20mA"));
                         text1.append(QString("%1 ").arg(text2));
                         model9->setData(index1,text1);
                     }
                     if(AIOchinfo[row+41]->AOchinfo->df_out_range == 2)
                     {
                         text2.append(QString("4-20mA"));
                         text1.append(QString("%1 ").arg(text2));
                         model9->setData(index1,text1);
                     }
                 }
                 c_row++;
             }
        }







        usleep(20000);
    /*******************************************************************/

/* making table for digital*/
        c_row = 0;

        model11= new QStandardItemModel(numDIOch,2,this);
         ui->tableView_21->setModel(model11);
         ui->tableView_21->setColumnWidth(0,250);
         ui->tableView_21->setColumnWidth(1,400);
         ui->tableView_21->setStyleSheet(
                                          "QTableView::item{"
                                          "border: 1px solid black;"
                                          "border-radius: 5px;"
                                          "background-color: rgb(255, 255, 127);"
                                          "color: black;"
                                          "}"
                                          );





         /***************************************************/

         /* filling table */

int s_chnum = 0;
         if (slot_info[6]->board_type == BOARD_DIO || slot_info[6]->board_type == BOARD_AR)
          {
             s_chnum = slot_info[6]->phy_num_channel;
              for(int row=0;row < s_chnum; row++)
              {
                  ui->tableView_21->setRowHeight(c_row,40);

                  {
                      QModelIndex index = model11->index(c_row,0,QModelIndex());
                      QString text= QString("Digital I/O ");
                      text.append(QString("%1 ").arg(row+1));
                      model11->setData(index,text);

                      QModelIndex index1 = model11->index(c_row,1,QModelIndex());
                      // 0 for all data
                      //QString text1= QString("D1,Output Relay (24V)");
                       QString text1= QString("D");
                       text1.append(QString("%1 ").arg(row+1));


                      if(DIOARchinfo[row+1]->DIOchinfo->digitalType == 1)
                      {
                           QString text2= QString("Input");
                           text1.append(text2);
                           model11->setData(index1,text1);
                      }
                      else if(DIOARchinfo[row+1]->DIOchinfo->digitalType == 2)
                      {
                           QString text2= QString("Pulse Input (Hz)");
                           text1.append(text2);
                           model11->setData(index1,text1);
                      }
                      else if(DIOARchinfo[row+1]->DIOchinfo->digitalType == 3)
                      {
                           QString text2= QString("Output Relay (24V)");
                           text1.append(text2);
                           model11->setData(index1,text1);
                      }

                  }
                  c_row++;
              }


         }

         if (slot_info[7]->board_type == BOARD_DIO || slot_info[7]->board_type == BOARD_AR)
          {
             s_chnum = slot_info[7]->phy_num_channel;
              for(int row=17;row < (s_chnum+17); row++)
              {
                  ui->tableView_21->setRowHeight(c_row,40);

                  {
                      QModelIndex index = model11->index(c_row,0,QModelIndex());
                      QString text= QString("Digital I/O ");
                      text.append(QString("%1 ").arg(row));
                      model11->setData(index,text);

                      QModelIndex index1 = model11->index(c_row,1,QModelIndex());
                      // 0 for all data
                      //QString text1= QString("D1,Output Relay (24V)");
                       QString text1= QString("D");
                       text1.append(QString("%1 ").arg(row));



                      if(DIOARchinfo[row]->DIOchinfo->digitalType == 1)
                      {
                           QString text2= QString("Input");
                           text1.append(text2);
                           model11->setData(index1,text1);
                      }
                      else if(DIOARchinfo[row]->DIOchinfo->digitalType == 2)
                      {
                           QString text2= QString("Pulse Input (Hz)");
                           text1.append(text2);
                           model11->setData(index1,text1);
                      }
                      else if(DIOARchinfo[row]->DIOchinfo->digitalType == 3)
                      {
                           QString text2= QString("Output Relay (24V)");
                           text1.append(text2);
                           model11->setData(index1,text1);
                      }

                  }
                  c_row++;
              }


         }


         if (slot_info[8]->board_type == BOARD_DIO || slot_info[8]->board_type == BOARD_AR)
          {
             s_chnum = slot_info[8]->phy_num_channel;
              for(int row=33;row < (s_chnum+33); row++)
              {
                  ui->tableView_21->setRowHeight(c_row,40);

                  {
                      QModelIndex index = model11->index(c_row,0,QModelIndex());
                      QString text= QString("Digital I/O ");
                      text.append(QString("%1 ").arg(row));
                      model11->setData(index,text);

                      QModelIndex index1 = model11->index(c_row,1,QModelIndex());
                      // 0 for all data
                      //QString text1= QString("D1,Output Relay (24V)");
                       QString text1= QString("D ");
                       text1.append(QString("%1 ").arg(row));



                      if(DIOARchinfo[row]->DIOchinfo->digitalType == 1)
                      {
                           QString text2= QString("Input");
                           text1.append(text2);
                           model11->setData(index1,text1);
                      }
                      else if(DIOARchinfo[row]->DIOchinfo->digitalType == 2)
                      {
                           QString text2= QString("Pulse Input (Hz)");
                           text1.append(text2);
                           model11->setData(index1,text1);
                      }
                      else if(DIOARchinfo[row]->DIOchinfo->digitalType == 3)
                      {
                           QString text2= QString("Output Relay (24V)");
                           text1.append(text2);
                           model11->setData(index1,text1);
                      }

                  }
                  c_row++;
              }


         }

        PenLogTimer = 1000/samplerate;
#endif
}
//connect(ui->m_kConfigBtn,&QPushButton::released, [pMainMenu](){pMainMenu->OnMainMenuDlgConfigureBtn();});

void MainWindow::/*on_toolButton_12_clicked*/OnMainMenuDlgConfigureBtn()
{
    ui->stackedWidget->setCurrentIndex(1);

}
//connect(ui->m_kSetupBtn,&QPushButton::released, [pConfigMenu](){pConfigMenu->OnConfigMenuDlgSetupBtn();});
void MainWindow::/*on_toolButton_42_clicked*/OnConfigMenuDlgSetupBtn()
{
    ui->stackedWidget->setCurrentIndex(2);
}
//connect(ui->m_kEditBtn,&QPushButton::released, [pLoadSave](){pLoadSave->OnLoadSaveDlgEditBtn();});
void MainWindow::/*on_toolButton_59_clicked*/OnLoadSaveDlgEditBtn()
{
    ui->stackedWidget->setCurrentIndex(3);
}
//connect(ui->SETUP_MENU_m_kFinishBtn,&QPushButton::released, [pCfgSetupMenu](){pCfgSetupMenu->OnCfgSetupMenuDlgFinishBtn();});
void MainWindow::/*on_toolButton_74_clicked*/OnCfgSetupMenuDlgFinishBtn()
{
    ui->stackedWidget_2->setCurrentIndex(1);
}
//connect(ui->EDIT_SETUP_m_kFinishBtn,&QPushButton::released, [pLoadSave](){pLoadSave->OnLoadSaveDlgFinishBtn();});
void MainWindow::/*on_toolButton_64_clicked*/OnLoadSaveDlgFinishBtn()
{
    ui->stackedWidget_2->setCurrentIndex(1);
}
//connect(ui->CONFIGURE_m_kFinishBtn,&QPushButton::released, [pConfigMenu](){pConfigMenu->OnConfigMenuDlgFinishBtn();});
void MainWindow::/*on_toolButton_50_clicked*/OnConfigMenuDlgFinishBtn()
{
   ui->stackedWidget_2->setCurrentIndex(1);
}
//connect(ui->CONFIGURE_m_kBackBtn,&QPushButton::released, [pConfigMenu](){pConfigMenu->OnConfigMenuDlgExitBtn();});
void MainWindow::/*on_toolButton_48_clicked*/OnConfigMenuDlgExitBtn()
{
   ui->stackedWidget->setCurrentIndex(0);
}
//connect(ui->EDIT_SETUP_m_kBackBtn,&QPushButton::released, [pLoadSave](){pLoadSave->OnLoadSaveDlgExitBtn();});
void MainWindow::/*on_toolButton_63_clicked*/OnLoadSaveDlgExitBtn()
{
   ui->stackedWidget->setCurrentIndex(1);
}
//connect(ui->m_kFieldIOBtn,&QPushButton::released, [pCfgSetupMenu](){pCfgSetupMenu->OnCfgSetupMenuDlgFieldIoBtn();});
void MainWindow::/*on_toolButton_66_clicked*/OnCfgSetupMenuDlgFieldIoBtn()
{
    ui->stackedWidget->setCurrentIndex(4);
}

void MainWindow::on_toolButton_25_clicked()
{
    ui->stackedWidget->setCurrentIndex(3);
}

void MainWindow::on_toolButton_29_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(1);
}

void MainWindow::on_toolButton_30_clicked()
{
    ui->stackedWidget->setCurrentIndex(15);
}
//connect(ui->SETUP_MENU_m_kScreenBtn,&QPushButton::released, [pCfgSetupMenu](){pCfgSetupMenu->OnCfgSetupMenuDlgScreenBtn();});
void MainWindow::/*on_toolButton_71_clicked*/OnCfgSetupMenuDlgScreenBtn()
{
    ui->stackedWidget->setCurrentIndex(7);
}

void MainWindow::on_toolButton_53_clicked()
{
     ui->stackedWidget->setCurrentIndex(3);
}

void MainWindow::on_toolButton_54_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(1);
}

void MainWindow::on_toolButton_51_clicked()
{
    brightness_slider brightness_slider;
    brightness_slider.setModal(true);
    brightness_slider.exec();

//    double xvalue=brightness_slider.Slider->value();
//    qinfo<<"xvalue "<<xvalue;

}
//	connect(ui->m_kScreenBtn,&QPushButton::released, [pMainMenu](){pMainMenu->OnMainMenuDlgScreenBtn();});
void MainWindow::/*toolButton_14*/OnMainMenuDlgScreenBtn()
{
     ui->stackedWidget->setCurrentIndex(8);
}

void MainWindow::on_toolButton_33_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_toolButton_37_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(1);
}

void MainWindow::on_toolButton_34_clicked()
{
    confirmation_Dialog confirmation_Dialog;
    confirmation_Dialog.setModal(true);
    confirmation_Dialog.exec();
}

void MainWindow::on_toolButton_36_clicked()
{
    touch_dialog touch_dialog;
    touch_dialog.setModal(true);
    touch_dialog.exec();

//      QProcess process ;
//      process.startDetached("/bin/bash", QStringList()  << "/home/root/touch.sh");
//      process.waitForStarted();


}
//connect(ui->m_kPenBtn,&QPushButton::released, [pCfgSetupMenu](){pCfgSetupMenu->OnCfgSetupMenuDlgPensBtn();});
void MainWindow::/*on_toolButton_67_clicked*/OnCfgSetupMenuDlgPensBtn()
{
     ui->stackedWidget->setCurrentIndex(9);
}

void MainWindow::on_pushButton_72_clicked()
{
    ui->stackedWidget->setCurrentIndex(3);
}

void MainWindow::on_pushButton_74_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(1);

}
////////////////////////////////////////pen table
void MainWindow::onTableClicked(const QModelIndex &index)
{
       QString cellText = index.data().toString();
       cellText4 = index.row();

        ui->stackedWidget->setCurrentIndex(10);


                QModelIndex index27 = model->index(cellText4,1,QModelIndex());
                 QString cellText12 = index27.data().toString();
                 //qDebug()<<"cellText="<<cellText12.split(",")[0];




                 cellText=cellText12.split(",")[0];
                 cellText=cellText12.split(" ")[1];
                 Pen_Selected=QString(cellText).toUInt();
                 // qDebug()<<"......................................//Pen_Selected="<<Pen_Selected;


                  QString text121= QString(" Pen ");
                  text121.append(QString("%1").arg(Pen_Selected));
                  ui->pushButton_26->setText(text121);
                  ui->pushButton_32->setText(text121);
                  ui->pushButton_36->setText(text121);



                      // Generate data
                      for(int row = 0; row < 13; row++)
                      {

                          ui->tableView_2->setRowHeight(row,40);

                          {
                              QModelIndex index = model1->index(row,0,QModelIndex());
                              QStandardItem *my_item = model1->itemFromIndex(index);
                              my_item->setBackground(Qt::yellow);
                              // 0 for all data
                              if(row == 0)
                              {
                              QString text= QString("Enabled");
                              model1->setData(index,text);
                              }
                              else if(row == 1)
                              {
                              QString text= QString("Tag");
                              //text.append(QString("%1 ").arg(row));
                              model1->setData(index,text);
                              }
                              else if(row == 2)
                              {
                              QString text= QString("Description");
                              //text.append(QString("%1 ").arg(row));
                              model1->setData(index,text);
                              }
                              else if(row == 3)
                              {
                              QString text= QString("Maths Type ");
                              //text.append(QString("%1 ").arg(row));
                              model1->setData(index,text);
                              }
                              else if(row == 4)
                              {
                              QString text= QString("Edit Math ");
                              //text.append(QString("%1 ").arg(row));
                              model1->setData(index,text);
                              }
                              else if(row == 5)
                              {
                              QString text= QString("Scale ");
                              //text.append(QString("%1 ").arg(row));
                              model1->setData(index,text);
                              }
                              else if(row == 6)
                              {
                              QString text= QString("Logging ");
                              //text.append(QString("%1 ").arg(row));
                              model1->setData(index,text);
                              }
                              else if(row == 7)
                              {
                              QString text= QString("Alarms ");
                              //text.append(QString("%1 ").arg(row));
                              model1->setData(index,text);
                              }
                              else if(row == 8)
                              {
                              QString text= QString("Totaliser ");
                              //text.append(QString("%1 ").arg(row));
                              model1->setData(index,text);
                              }
                              else if(row == 9)
                              {
                              QString text= QString("Rav ");
                              //text.append(QString("%1 ").arg(index));
                              model1->setData(index,text);
                              }
                              else if(row == 10)
                              {
                              QString text= QString("Group ");
                              //text.append(QString("%1 ").arg(row));
                              model1->setData(index,text);
                              }
                              else if(row == 11)
                              {
                              QString text= QString("Colour ");
                              //text.append(QString("%1 ").arg(row));
                              model1->setData(index,text);
                              }
                              else if(row == 12)
                              {
                              QString text= QString("Trace Width ");
                              //text.append(QString("%1 ").arg(row));
                              model1->setData(index,text);
                              }

                          }

                          {
                              QModelIndex index = model1->index(row,1,QModelIndex());
                              QStandardItem *my_item = model1->itemFromIndex(index);
                              my_item->setBackground(Qt::yellow);
                              // 0 for all data
                              if(row == 0)
                              {
                              QString text= QString(" . ");
                              //text.append(QString("%1 ").arg(row));
                              model1->setData(index,text);
                              }
                              else if(row == 1)
                              {

                              QString text= QString("Pen");
                              //text.append(QString("%1 ").arg(row));
                              model1->setData(index,text);
                              }
                              else if(row == 2)
                              {
                              QString text= QString("Description ");
                              //text.append(QString("%1 ").arg(row));
                              model1->setData(index,text);
                              }
                              else if(row == 3)
                              {
                              QString text= QString("Basic Math ");
                              //text.append(QString("%1 ").arg(row));
                              model1->setData(index,text);
                              }
                              else if(row == 4)
                              {
                              //QString text= QString("A");
                                 QString text= QString(mt_PEN[Pen_Selected]->MathsBlock);
                                 qDebug()<<"mt_PEN[Pen_Selected]->MathsBlock"<< Pen_Selected << mt_PEN[Pen_Selected]->MathsBlock;
                              //text.append(QString("%1").arg(mt_PEN[Pen_Selected]->MathsBlock));
                              //strncpy(mt_PEN[Pen_Selected]->MathsBlock, edit_math.toLocal8Bit().constData(), edit_math.size());

                              model1->setData(index,text);
                              }
                              else if(row == 5)
                              {
                              QString text= QString("0.0 to 100.0 % ");
                              //text.append(QString("%1 ").arg(row));
                              model1->setData(index,text);
                              }
                              else if(row == 6)
                              {
                              QString text= QString(" . ");
                              //text.append(QString("%1 ").arg(row));
                              model1->setData(index,text);
                              }
                              else if(row == 7)
                              {
                              QString text= QString("None ");
                              //text.append(QString("%1 ").arg(row));
                              model1->setData(index,text);
                              }
                              else if(row == 8)
                              {
                              QString text= QString(" . ");
                              //text.append(QString("%1 ").arg(row));
                              model1->setData(index,text);
                              }
                              else if(row == 9)
                              {
                              QString text= QString(" . ");
                              //text.append(QString("%1 ").arg(index));
                              model1->setData(index,text);
                              }
                              else if(row == 10)
                              {
                              QString text= QString("No Group ");
                              //text.append(QString("%1 ").arg(row));
                              model1->setData(index,text);
                              }
                              else if(row == 11)
                              {
                              QString text= QString(" . ");
                              //text.append(QString("%1 ").arg(row));
                              model1->setData(index,text);
                              }
                              else if(row == 12)
                              {
                              QString text= QString("1 ");
                              //text.append(QString("%1 ").arg(row));
                              model1->setData(index,text);
                              }

                          }


                          QModelIndex index1 = model1->index(1,1,QModelIndex());
                          model1->setData(index1,text121);
}
}

void MainWindow::onTableClicked_23(const QModelIndex &index){




    int row = index.row();
    int col = index.column();
    QString cellText = index.data().toString();
    cellText4=index.row();
    //qDebug()<<"testttttttttt"<<cellText;

        if (row ==0 && col ==1 ){
            QModelIndex index667 = model1->index(0, 1, QModelIndex());
            QString currentText = model1->data(index667).toString();

            if (currentText == "Enabled") {
                model1->setData(index667, "Disabled");
            } else if (currentText == "Disabled") {
                model1->setData(index667, "Enabled");
            }
    }
      if (row == 1 & col ==1){
          qwerty_keyboard keyboard;
          keyboard.setModal(true);
          keyboard.exec();

          QModelIndex dataIndex = model1->index(1, 1, QModelIndex());

          if (qwert_flag == 0) {
              model1->setData(dataIndex, qwerty_keyboard_text);
          } else if (qwert_flag == 1) {
              model1->setData(dataIndex, qwerty_keyboard_CAPS_text);
          }
      }
      if (row == 2 & col ==1){
          qwerty_keyboard keyboard;
          keyboard.setModal(true);
          keyboard.exec();

          QModelIndex dataIndex = model1->index(2, 1, QModelIndex());

          if (qwert_flag == 0) {
              model1->setData(dataIndex, qwerty_keyboard_text);
          } else if (qwert_flag == 1) {
              model1->setData(dataIndex, qwerty_keyboard_CAPS_text);
          }
      }
      if (row == 4 & col ==1){
          qwerty_keyboard keyboard;
          keyboard.setModal(true);
          keyboard.exec();

          QModelIndex dataIndex = model1->index(4, 1, QModelIndex());

          if (qwert_flag == 0) {
              model1->setData(dataIndex, qwerty_keyboard_text);
          } else if (qwert_flag == 1) {
              model1->setData(dataIndex, qwerty_keyboard_CAPS_text);
          }
      }


   if (row == 6 && col==1)
    {
      ui->stackedWidget->setCurrentIndex(14);
    }
    if (row == 5 && col == 1) {
        ui->stackedWidget->setCurrentIndex(77);

    }
    if (row == 7 && col == 1) {
        ui->stackedWidget->setCurrentIndex(80);

    }
    if (row == 9 && col == 1) {
        ui->stackedWidget->setCurrentIndex(79);

    }

}

void MainWindow::onTableClicked_2(const QModelIndex &index)
{
    QString cellText = index.data().toString();
    cellText4=index.row();

 if (cellText == "."){
     ui->stackedWidget->setCurrentIndex(14);
 }
}

void MainWindow::onTableClicked_16(const QModelIndex &index)
{


       QString cellText = index.data().toString();
       cellText4=index.row();
       int row = index.row();
      // qDebug()<<"testttttttttt"<<cellText;
       //qDebug()<<"test_row="<<cellText4;


//       QModelIndex index343 = model1->index(4,1,QModelIndex());
//       QStandardItem *my_item121 = model1->itemFromIndex(index343);
//       my_item121->setFlags(Qt::ItemIsEditable);
//       my_item121->setEditable(true);


//       if((cellText == " (+/-)12V ") || (cellText == " (+/-)100mV ")|| (cellText == " (+/-)250mV ")|| (cellText == " (+/-)500mV ")|| (cellText == " (+/-)1000mV "))
//       {
//         ui->sample_rate_group_box_2->show();
//         //ui->sample_rate_group_box->setStyleSheet("QGroupBox::indicator:unchecked {image: url(/home/pi/Desktop/Paperless_Recorder_gui/lab_hz.PNG);background-color: rgb(17, 100, 255)}");
//       }

        //qDebug()<<"testttttttttt"<<cellText;
        //ui->stackedWidget_2->setCurrentIndex(1);
        //ui->stackedWidget->setStyleSheet("QStackedWidget{image: url(/home/pi/Desktop/Paperless_Recorder_gui/analog_in_1.jpg);background-color: rgb(17, 100, 255)}");

       if((cellText =="Fuzzy"))
       {
         ui->stackedWidget->setCurrentIndex(14);
         //ui->sample_rate_group_box->setStyleSheet("QGroupBox::indicator:unchecked {image: url(/home/pi/Desktop/Paperless_Recorder_gui/lab_hz.PNG);background-color: rgb(17, 100, 255)}");
       }
//       if((cellText =="Continuous"))
//       {
//         ui->stackedWidget->setCurrentIndex(13);
//         //ui->sample_rate_group_box->setStyleSheet("QGroupBox::indicator:unchecked {image: url(/home/pi/Desktop/Paperless_Recorder_gui/lab_hz.PNG);background-color: rgb(17, 100, 255)}");
//       }



       if(mt_PEN[Pen_Selected]->PenLog.PretriggerEn  == 0)
       {

           QModelIndex index5 = model4->index(6,1,QModelIndex());
           QString text= QString("DISABLED");
           model4->setData(index5,text);
       }
       if(mt_PEN[Pen_Selected]->PenLog.PretriggerEn  == 1)
       {

           QModelIndex index6 = model4->index(6,1,QModelIndex());
           QString text= QString("ENABLED");
           model4->setData(index6,text);
       }

       if((cellText4 == 6))
       {
          // qDebug()<<"2";
           if(cellText == "DISABLED")
           {
               m_pen = m_Instance->GetPenControl(Pen_Selected,ZERO_BASED);

               m_pen->m_preTrigger.m_Enabled = TRUE;
               if(mt_PEN[Pen_Selected] != NULL)
               {
                   mt_PEN[Pen_Selected]->PenLog.PretriggerEn  = 1;
                   saveInfoStructureToFile(LOG_INFO_FILE,mt_PEN);
               }
               m_pen->m_preTrigger.AllocateBuffer(1,this->get_pre_trigger_time());
               QString text= QString("ENABLED");
               //text.append(QString("%1 ").arg(row));
               model4->setData(index,text);
           }


           if(cellText == "ENABLED")
          {
               m_pen = m_Instance->GetPenControl(Pen_Selected,ZERO_BASED);
               //qDebug()<<"/////////////////////////////////pen_number="<<pen_num<<"Now Disabled";
               m_pen->m_preTrigger.m_Enabled = FALSE;
               if(mt_PEN[Pen_Selected] != NULL)
               {
                   mt_PEN[Pen_Selected]->PenLog.PretriggerEn  = 0;
                 saveInfoStructureToFile(LOG_INFO_FILE,mt_PEN);
               }
               m_pen->m_preTrigger.CleanUp();
              QString text= QString("DISABLED");
              model4->setData(index,text);
          }
    }



       if(mt_PEN[Pen_Selected]->PenLog.Enabled == 0)
       {

           QModelIndex index54 = model4->index(0,1,QModelIndex());
           QString text= QString("DISABLED");
           model4->setData(index54,text);
       }
       if(mt_PEN[Pen_Selected]->PenLog.Enabled  == 1)
       {

           QModelIndex index54 = model4->index(0,1,QModelIndex());
           QString text= QString("ENABLED");
           model4->setData(index54,text);
       }


       if((row == 0))
       {
           // qDebug()<<"1";
           if(cellText == "ENABLED")
           //if(mt_PEN[Pen_Selected]->PenLog.Enabled = 1)
           {
               mt_PEN[Pen_Selected]->PenLog.Enabled = 0;
//               QModelIndex index58 = model4->index(0,1,QModelIndex());
//               QStandardItem *my_item121 = model4->itemFromIndex(index58);
//                my_item121->setIcon(style()->standardIcon(QStyle::SP_DialogApplyButton));
               //       my_item121->setEditable(true);
               QString text= QString("DISABLED");
               model4->setData(index,text);
           }
          if (cellText == "DISABLED")
           {
              mt_PEN[Pen_Selected]->PenLog.Enabled = 1;
              QString text= QString("ENABLED");
              model4->setData(index,text);
           }
       }

}
//////////////////////////////////////////////////////////////////////////////////////

void MainWindow::onTableClicked_3(const QModelIndex &index)
{
    if (index.isValid()) {

           ui->stackedWidget->setCurrentIndex(16);

}
}

    //    QString cellText = index.data().toString();
//    cellText4 = index.row();
//    ai_ch_no=cellText4;

//     qDebug()<<"power_arr[power_value]"<<cellText4;
//     //frequency[cellText4]=sample_rate_value;
//     qDebug()<<"freq_val_text[power_value]"<<frequency_val[ai_ch_no];

//     range[cellText4]=milli_volt_value;
//     volt_val[cellText4]= Type_value;
//     ui->stackedWidget->setCurrentIndex(16);

//    // ui->stackedWidget->setStyleSheet("QStackedWidget{image: url(/home/pi/Desktop/Paperless_Recorder_gui/analog_in_1.jpg);background-color: rgb(17, 100, 255)}");
//     //index = model1->index(2,1,QModelIndex());
//     // 0 for all data
//      QModelIndex index3 = model6->index(2,1,QModelIndex());
//     //QString text = QVariant(frequency_val[cellText4]).toString();
//     //QString text= frequency_val[cellText4].toString();
//     //text.append(QString("%1 ").arg(row));
//    model6->setData(index3,frequency_val[ai_ch_no]);
//     QModelIndex index4 = model6->index(9,1,QModelIndex());

//     QModelIndex index5 = model6->index(4,1,QModelIndex());
//     model6->setData(index5,range_val[ai_ch_no]);

//     QModelIndex index555 = model6->index(1,1,QModelIndex());
//     if(index555.data().toString()=="Amps")
//     {
//     QModelIndex index51 = model6->index(4,1,QModelIndex());
//     model6->setData(index51, "0-20mA");
//     }

//     QString text= QString("A");
//     text.append(QString("%1 ").arg(cellText4));
//     model6->setData(index4,text);

//     QString text22= QString("Analog In ");
//     text22.append(QString("%1 ").arg(cellText4));
//     ui->pushButton_47->setText(text22);
//     ui->pushButton_51->setText(text22);


//     QModelIndex index6 = model6->index(11,1,QModelIndex());
//     model6->setData(index6,sensorcomp_type[ai_ch_no]);

//     QModelIndex index0 = model6->index(0,1,QModelIndex());
//     model7->setData(index0,sensorcomp_type[ai_ch_no]);






bool isPreset = true;
void MainWindow::onTableClicked_4(const QModelIndex &index)
{
       QString cellText = index.data().toString();
       if((cellText == "2Hz(500ms) ") || (cellText == "5Hz(200ms) ") || (cellText == "10Hz(100ms) ") || (cellText == "50Hz(20ms) "))
       {
           sample_rate sample_rate;
           sample_rate.setModal(true);
           sample_rate.exec();
           qDebug("sample rate value change: %d", sample_rate_value);
           QModelIndex index3 = model6->index(2,1,QModelIndex());
           //model6->setData(index3,Sample_Rate_list[AIOchinfo[model6_ch]->AIchinfo->SRate]);
          model6->setData(index3,frequency_val[ai_ch_no]);

         //ui->sample_rate_group_box->show();
         //ui->sample_rate_group_box->setStyleSheet("QGroupBox::indicator:unchecked {image: url(/home/pi/Desktop/Paperless_Recorder_gui/lab_hz.PNG);background-color: rgb(17, 100, 255)}");
       }
       if((cellText == "(+/-)12V ") || (cellText == "(+/-)100mV ")|| (cellText == "(+/-)250mV ")|| (cellText == "(+/-)500mV ")|| (cellText == "(+/-)1000mV ")|| (cellText == "(+/-)50V ")
              || (cellText == "(+/-)25V ")|| (cellText == "(+/-)6V ")|| (cellText == "(+/-)3V ")|| (cellText == "(+/-)1.5V ")|| (cellText == "(+/-)0.6V ")|| (cellText == "(+/-)0.3V ")|| (cellText == "(+/-)50mV ")
              || (cellText == "(+/-)25mV ")|| (cellText == "(+/-)10mV ")|| (cellText == "(+/-)5mV "))
       {
           mv_dialog mv_dialog;
           mv_dialog.setModal(true);
           mv_dialog.exec();
           qDebug("milli_volt_value change: %d", milli_volt_value);
           QModelIndex index4 = model6->index(4,1,QModelIndex());
           model6->setData(index4,range_val[ai_ch_no]);
       }
       if((cellText == "Volts") || (cellText == "Amps")|| (cellText == "Ohms")|| (cellText == "RT")|| (cellText == "TC"))
       {
           Type type;
           type.setModal(true);
           type.exec();
           qDebug("Type_value change: %d", Type_value);
           QModelIndex index1 = model6->index(1,1,QModelIndex());
       model6->setData(index1,volt_val[ai_ch_no]);
        }
       QString t=index.data().toString();
       QModelIndex index23 = model6->index(1,1,QModelIndex());
       if(index23.data().toString()=="Volts")
       {
           if(t=="Preset")
           {
           ui->stackedWidget->setCurrentIndex(28);
           }
       }

       if(t=="Amps")
       {
           QModelIndex index5 = model6->index(4,1,QModelIndex());
           model6->setData(index5, "0-20mA");
       }
       if(t=="Volts")
       {
           QModelIndex index5 = model6->index(4,1,QModelIndex());
           model6->setData(index5, "(+/-)100mV ");
       }
       if(t=="0-20mA" || t== "4-20mA")
       {
           Amps_dialog Amps_dialog;
           Amps_dialog.setModal(true);
           Amps_dialog.exec();
           QModelIndex index5 = model6->index(4,1,QModelIndex());
           model6->setData(index5, Amp_text[ai_ch_no]);
       }

       QModelIndex index22 = model6->index(1,1,QModelIndex());
       if(index22.data().toString()=="Amps")
       {
           if(t=="Preset")
           {
           ui->stackedWidget->setCurrentIndex(29);
           QModelIndex index5 = model21->index(1,1,QModelIndex());
           model21->setData(index5, "Amps");
           }
       }

       QString x=index.data().toString();
       if(x=="Damp Level")
       {
       VoltsValueSelection VoltsValueSelection;
       VoltsValueSelection.setModal(true);
       VoltsValueSelection.exec();
       QModelIndex index666 = model6->index(5,1,QModelIndex());
       model6->setData(index666,keyboard_text);
       }

       int row=index.row();
       int col=index.column();
       if(row==5 && col== 1)
       {
           VoltsValueSelection VoltsValueSelection;
           VoltsValueSelection.setModal(true);
           VoltsValueSelection.exec();
           QModelIndex index666 = model6->index(5,1,QModelIndex());
           model6->setData(index666,keyboard_text);

       }
         //ui->sample_rate_group_box->show();
         //ui->sample_rate_group_box->setStyleSheet("QGroupBox::indicator:unchecked {image: url(/home/pi/Desktop/Paperless_Recorder_gui/lab_hz.PNG);background-color: rgb(17, 100, 255)}");

       if((cellText == "None") || (cellText == "Single Point") || (cellText == "Dual Point") || (cellText == "Multi Point"))
       {

           if (cellText == "Single Point")
           {
               comp_type_val[ai_ch_no]=1;
               model7 = new QStandardItemModel(2,2,this);
               ui->tableView_15->setModel(model7);

               ui->tableView_15->setColumnWidth(0,250);
               ui->tableView_15->setColumnWidth(1,400);
               ui->tableView_15->horizontalHeader()->hide();
               ui->tableView_15->verticalHeader()->hide();


                for(int row = 0; row < 2; row++)
                {
                    ui->tableView_15->setRowHeight(row,40);
                    //for(int col = 0; col < 2; col++)
                    {
                        QModelIndex index = model7->index(row,0,QModelIndex());
                        // 0 for all data
                        if(row == 0)
                        {
                        QString text1= QString("Comp Type ");
                        //text.append(QString("%1 ").arg(row));
                        model7->setData(index,text1);
                        }
                        else if(row == 1)
                        {

                        QString text1= QString("Eng Offset ");
                        //text.append(QString("%1 ").arg(row));
                        model7->setData(index,text1);
                        }

                    }
                    {
                        QModelIndex index = model7->index(row,1,QModelIndex());
                        // 0 for all data
                        if(row == 0)
                        {
                        QString text1= QString("Single Point");
                        //text.append(QString("%1 ").arg(row));
                        model7->setData(index,text1);
                        }
                        else if(row == 1)
                        {
                            //update1
                        QString text1= QString(QVariant(singlepoint_val[ai_ch_no]).toString());
                        //text.append(QString("%1 ").arg(row));
                        model7->setData(index,text1);
                        }
                }

                }

           }
           else if (cellText == "None")
           {
               comp_type_val[ai_ch_no]=0;
               model7 = new QStandardItemModel(2,2,this);
               ui->tableView_15->setModel(model7);

               ui->tableView_15->setColumnWidth(0,250);
               ui->tableView_15->setColumnWidth(1,400);
               ui->tableView_15->horizontalHeader()->hide();
               ui->tableView_15->verticalHeader()->hide();


                for(int row = 0; row < 2; row++)
                {
                    ui->tableView_15->setRowHeight(row,40);
                    //for(int col = 0; col < 2; col++)
                    {
                        QModelIndex index = model7->index(row,0,QModelIndex());
                        // 0 for all data
                        if(row == 0)
                        {
                        QString text1= QString("Comp Type ");
                        //text.append(QString("%1 ").arg(row));
                        model7->setData(index,text1);
                        }
                        else if(row == 1)
                        {

                        QString text1= QString("Eng Offset ");
                        //text.append(QString("%1 ").arg(row));
                        model7->setData(index,text1);
                        QStandardItem *my_item = model7->itemFromIndex(index);
                        my_item->setFlags(0);
                        }

                    }
                    {
                        QModelIndex index = model7->index(row,1,QModelIndex());
                        // 0 for all data
                        if(row == 0)
                        {
                        QString text1= QString("None");
                        //text.append(QString("%1 ").arg(row));
                        model7->setData(index,text1);
                        }
                        else if(row == 1)
                        {

                        QString text1= QString("10.0 ");
                        //text.append(QString("%1 ").arg(row));
                        model7->setData(index,text1);
                        QStandardItem *my_item = model7->itemFromIndex(index);
                        my_item->setBackground(Qt::blue);
                        my_item->setFlags(0);
                        }
                   }
                }

           }
           else if (cellText == "Dual Point")
           {
               comp_type_val[ai_ch_no]=2;
               model7 = new QStandardItemModel(5,2,this);
               ui->tableView_15->setModel(model7);

               ui->tableView_15->setColumnWidth(0,250);
               ui->tableView_15->setColumnWidth(1,400);
               ui->tableView_15->horizontalHeader()->hide();
               ui->tableView_15->verticalHeader()->hide();
                    //update2

                for(int row = 0; row < 6; row++)
                {
                    ui->tableView_15->setRowHeight(row,40);
                    //for(int col = 0; col < 2; col++)
                    {
                        QModelIndex index = model7->index(row,0,QModelIndex());
                        // 0 for all data
                        if(row == 0)
                        {
                        QString text1= QString("Comp Type ");
                        //text.append(QString("%1 ").arg(row));
                        model7->setData(index,text1);
                        }
                        else if(row == 1)
                        {

                        QString text1= QString("Low Eng ");
                        //text.append(QString("%1 ").arg(row));
                        model7->setData(index,text1);
                        }
                        else if(row == 2)
                        {

                        QString text1= QString("Low offset ");
                        //text.append(QString("%1 ").arg(row));
                        model7->setData(index,text1);
                        }
                        else if(row == 3)
                        {

                        QString text1= QString("High Eng ");
                        //text.append(QString("%1 ").arg(row));
                        model7->setData(index,text1);
                        }
                        else if(row == 4)
                        {

                        QString text1= QString("High offset ");
                        //text.append(QString("%1 ").arg(row));
                        model7->setData(index,text1);
                        }

                    }
                    {
                        QModelIndex index = model7->index(row,1,QModelIndex());
                        // 0 for all data
                        if(row == 0)
                        {
                        QString text1= QString("Dual Point");
                        //text.append(QString("%1 ").arg(row));
                        model7->setData(index,text1);
                        }
                        else if(row == 1)
                        {

                        QString text1= QString(QVariant(Dualpoint_val1[ai_ch_no]).toString());
                        //text.append(QString("%1 ").arg(row));
                        model7->setData(index,text1);
                        }
                        else if(row == 2)
                        {

                        QString text1= QString(QVariant(Dualpoint_val2[ai_ch_no]).toString());
                        //text.append(QString("%1 ").arg(row));
                        model7->setData(index,text1);
                        }
                        else if(row == 3)
                        {

                        QString text1= QString(QVariant(Dualpoint_val1[ai_ch_no]).toString());
                        //text.append(QString("%1 ").arg(row));
                        model7->setData(index,text1);
                        }
                        else if(row == 4)
                        {

                        QString text1= QString(QVariant(Dualpoint_val1[ai_ch_no]).toString());
                        //text.append(QString("%1 ").arg(row));
                        model7->setData(index,text1);
                        }
                   }

                }

           }
           else if (cellText == "Multi Point")
           {
               model7 = new QStandardItemModel(2,2,this);
               ui->tableView_15->setModel(model7);

               ui->tableView_15->setColumnWidth(0,250);
               ui->tableView_15->setColumnWidth(1,400);
               ui->tableView_15->horizontalHeader()->hide();
               ui->tableView_15->verticalHeader()->hide();


                for(int row = 0; row < 2; row++)
                {
                    ui->tableView_15->setRowHeight(row,40);
                    //for(int col = 0; col < 2; col++)
                    {
                        QModelIndex index = model7->index(row,0,QModelIndex());
                        // 0 for all data
                        if(row == 0)
                        {
                        QString text1= QString("Comp Type ");
                        //text.append(QString("%1 ").arg(row));
                        model7->setData(index,text1);
                        }
                        else if(row == 1)
                        {

                        QString text1= QString("Values");
                        //text.append(QString("%1 ").arg(row));
                        model7->setData(index,text1);
                        }

                    }
                    {
                        QModelIndex index = model7->index(row,1,QModelIndex());
                        // 0 for all data
                        if(row == 0)
                        {
                        QString text1= QString("Multi Point");
                        //text.append(QString("%1 ").arg(row));
                        model7->setData(index,text1);
                        }
                        else if(row == 1)
                        {

                        QString text1= QString("2 Points");
                        //text.append(QString("%1 ").arg(row));
                        model7->setData(index,text1);
                        }
                }
                }

           }
           ui->stackedWidget->setCurrentIndex(17);

       }
//           ui->stackedWidget->setCurrentIndex(17);
         //ui->sample_rate_group_box->show();
         //ui->sample_rate_group_box->setStyleSheet("QGroupBox::indicator:unchecked {image: url(/home/pi/Desktop/Paperless_Recorder_gui/lab_hz.PNG);background-color: rgb(17, 100, 255)}");
       }
       //QString cellText = index.data().toString();


         //ui->sample_rate_group_box->show();
         //ui->sample_rate_group_box->setStyleSheet("QGroupBox::indicator:unchecked {image: url(/home/pi/Desktop/Paperless_Recorder_gui/lab_hz.PNG);background-color: rgb(17, 100, 255)}");

        //qDebug()<<"testttttttttt"<<cellText;
        //ui->stackedWidget_2->setCurrentIndex(1);
        //ui->stackedWidget->setStyleSheet("QStackedWidget{image: url(/home/pi/Desktop/Paperless_Recorder_gui/analog_in_1.jpg);background-color: rgb(17, 100, 255)}");


void MainWindow::onTableClicked_5(const QModelIndex &index)
{
    QString cellText = index.data().toString();
    cellText4=index.row();
    if((cellText == "None") || (cellText == "Single Point") || (cellText == "Dual Point") || (cellText == "Multi Point"))
    {
        sensor_comp_dialog sensor_comp_dialog;
        sensor_comp_dialog.setModal(true);
        sensor_comp_dialog.exec();
        qDebug()<<"cmp="<<comp_type;
        sensorcomp_type[ai_ch_no]=comp_type;
        //comp_type_val[ai_ch_no]=comp_type;
        qDebug()<<"ai_ch_no="<<ai_ch_no;
        model7->setData(index,sensorcomp_type[ai_ch_no]);

        QModelIndex index6 = model6->index(11,1,QModelIndex());

        model6->setData(index6,sensorcomp_type[ai_ch_no]);

        if (comp_type == "Single Point")
        {
            comp_type_val[ai_ch_no]=1;
            model7 = new QStandardItemModel(2,2,this);
            ui->tableView_15->setModel(model7);

            ui->tableView_15->setColumnWidth(0,250);
            ui->tableView_15->setColumnWidth(1,400);
            ui->tableView_15->horizontalHeader()->hide();
            ui->tableView_15->verticalHeader()->hide();


             for(int row = 0; row < 2; row++)
             {
                 ui->tableView_15->setRowHeight(row,40);
                 //for(int col = 0; col < 2; col++)
                 {
                     QModelIndex index = model7->index(row,0,QModelIndex());
                     // 0 for all data
                     if(row == 0)
                     {
                     QString text1= QString("Comp Type ");
                     //text.append(QString("%1 ").arg(row));
                     model7->setData(index,text1);
                     }
                     else if(row == 1)
                     {

                     QString text1= QString("Eng Offset ");
                     //text.append(QString("%1 ").arg(row));
                     model7->setData(index,text1);
                     }

                 }
                 {
                     QModelIndex index = model7->index(row,1,QModelIndex());
                     // 0 for all data
                     if(row == 0)
                     {
                     QString text1= QString("Single Point");
                     //text.append(QString("%1 ").arg(row));
                     model7->setData(index,text1);
                     }
                     else if(row == 1)
                     {

                     QString text1= QString("10.0");
                     //text.append(QString("%1 ").arg(row));
                     model7->setData(index,text1);
                     }
             }

             }

        }
        else if (comp_type == "None")
        {
            comp_type_val[ai_ch_no]=0;
            model7 = new QStandardItemModel(2,2,this);
            ui->tableView_15->setModel(model7);

            ui->tableView_15->setColumnWidth(0,250);
            ui->tableView_15->setColumnWidth(1,400);
            ui->tableView_15->horizontalHeader()->hide();
            ui->tableView_15->verticalHeader()->hide();


             for(int row = 0; row < 2; row++)
             {
                 ui->tableView_15->setRowHeight(row,40);
                 //for(int col = 0; col < 2; col++)
                 {
                     QModelIndex index = model7->index(row,0,QModelIndex());
                     // 0 for all data
                     if(row == 0)
                     {
                     QString text1= QString("Comp Type ");
                     //text.append(QString("%1 ").arg(row));
                     model7->setData(index,text1);
                     }
                     else if(row == 1)
                     {

                     QString text1= QString("Eng Offset ");
                     //text.append(QString("%1 ").arg(row));
                     model7->setData(index,text1);
                     QStandardItem *my_item = model7->itemFromIndex(index);
                     my_item->setFlags(0);
                     }

                 }
                 {
                     QModelIndex index = model7->index(row,1,QModelIndex());
                     // 0 for all data
                     if(row == 0)
                     {
                     QString text1= QString("None");
                     //text.append(QString("%1 ").arg(row));
                     model7->setData(index,text1);
                     }
                     else if(row == 1)
                     {

                     QString text1= QString("10.0 ");
                     //text.append(QString("%1 ").arg(row));
                     model7->setData(index,text1);
                     QStandardItem *my_item = model7->itemFromIndex(index);
                     my_item->setBackground(Qt::blue);
                     my_item->setFlags(0);
                     }
                }
             }

        }
        else if (comp_type == "Dual Point")
        {
            comp_type_val[ai_ch_no]=2;
            model7 = new QStandardItemModel(5,2,this);
            ui->tableView_15->setModel(model7);

            ui->tableView_15->setColumnWidth(0,250);
            ui->tableView_15->setColumnWidth(1,400);
            ui->tableView_15->horizontalHeader()->hide();
            ui->tableView_15->verticalHeader()->hide();


             for(int row = 0; row < 6; row++)
             {
                 ui->tableView_15->setRowHeight(row,40);
                 //for(int col = 0; col < 2; col++)
                 {
                     QModelIndex index = model7->index(row,0,QModelIndex());
                     // 0 for all data
                     if(row == 0)
                     {
                     QString text1= QString("Comp Type ");
                     //text.append(QString("%1 ").arg(row));
                     model7->setData(index,text1);
                     }
                     else if(row == 1)
                     {

                     QString text1= QString("Low Eng ");
                     //text.append(QString("%1 ").arg(row));
                     model7->setData(index,text1);
                     }
                     else if(row == 2)
                     {

                     QString text1= QString("Low offset ");
                     //text.append(QString("%1 ").arg(row));
                     model7->setData(index,text1);
                     }
                     else if(row == 3)
                     {

                     QString text1= QString("High Eng ");
                     //text.append(QString("%1 ").arg(row));
                     model7->setData(index,text1);
                     }
                     else if(row == 4)
                     {

                     QString text1= QString("High offset ");
                     //text.append(QString("%1 ").arg(row));
                     model7->setData(index,text1);
                     }

                 }
                 {
                     QModelIndex index = model7->index(row,1,QModelIndex());
                     // 0 for all data
                     if(row == 0)
                     {
                     QString text1= QString("Dual Point");
                     //text.append(QString("%1 ").arg(row));
                     model7->setData(index,text1);
                     }
                     else if(row == 1)
                     {

                     QString text1= QString("1.23");
                     //text.append(QString("%1 ").arg(row));
                     model7->setData(index,text1);
                     }
                     else if(row == 2)
                     {

                     QString text1= QString("0.0");
                     //text.append(QString("%1 ").arg(row));
                     model7->setData(index,text1);
                     }
                     else if(row == 3)
                     {

                     QString text1= QString("0.0");
                     //text.append(QString("%1 ").arg(row));
                     model7->setData(index,text1);
                     }
                     else if(row == 4)
                     {

                     QString text1= QString("0.0");
                     //text.append(QString("%1 ").arg(row));
                     model7->setData(index,text1);
                     }
                }

             }

        }
        else if (comp_type == "Multi Point")
        {
            model7 = new QStandardItemModel(2,2,this);
            ui->tableView_15->setModel(model7);

            ui->tableView_15->setColumnWidth(0,250);
            ui->tableView_15->setColumnWidth(1,400);
            ui->tableView_15->horizontalHeader()->hide();
            ui->tableView_15->verticalHeader()->hide();


             for(int row = 0; row < 2; row++)
             {
                 ui->tableView_15->setRowHeight(row,40);
                 //for(int col = 0; col < 2; col++)
                 {
                     QModelIndex index = model7->index(row,0,QModelIndex());
                     // 0 for all data
                     if(row == 0)
                     {
                     QString text1= QString("Comp Type ");
                     //text.append(QString("%1 ").arg(row));
                     model7->setData(index,text1);
                     }
                     else if(row == 1)
                     {

                     QString text1= QString("Values");
                     //text.append(QString("%1 ").arg(row));
                     model7->setData(index,text1);
                     }

                 }
                 {
                     QModelIndex index = model7->index(row,1,QModelIndex());
                     // 0 for all data
                     if(row == 0)
                     {
                     QString text1= QString("Multi Point");
                     //text.append(QString("%1 ").arg(row));
                     model7->setData(index,text1);
                     }
                     else if(row == 1)
                     {

                     QString text1= QString("2 Points");
                     //text.append(QString("%1 ").arg(row));
                     model7->setData(index,text1);
                     }
             }
             }

        }


    }
   if((cellText == "2 Points"))
   {
     qDebug()<<cellText;
     model8 = new QStandardItemModel(2,3,this);


     model8->setHeaderData(0, Qt::Horizontal, "Ins/Del", Qt::DisplayRole);
     model8->setHeaderData(1, Qt::Horizontal, "X (Signal Input)", Qt::DisplayRole);
     model8->setHeaderData(2, Qt::Horizontal, "Y (Eng.Units)", Qt::DisplayRole);

     ui->tableView_16->setModel(model8);

     ui->tableView_16->setColumnWidth(0,250);
     ui->tableView_16->setColumnWidth(1,400);



     ui->tableView_16->verticalHeader()->hide();


      for(int row = 0; row < 2; row++)
      {
          ui->tableView_15->setRowHeight(row,40);
          //for(int col = 0; col < 2; col++)
          {
              QModelIndex index = model8->index(row,0,QModelIndex());
              // 0 for all data
              if(row == 0)
              {
              QString text1= QString("1");
              //text.append(QString("%1 ").arg(row));
              model8->setData(index,text1);
              }
              else if(row == 1)
              {

              QString text1= QString("2");
              //text.append(QString("%1 ").arg(row));
              model8->setData(index,text1);
              }

          }
          {
              QModelIndex index = model8->index(row,1,QModelIndex());
              // 0 for all data
              if(row == 0)
              {
              QString text1= QString("0.0");
              //text.append(QString("%1 ").arg(row));
              model8->setData(index,text1);
              }
              else if(row == 1)
              {

              QString text1= QString("0.0");
              //text.append(QString("%1 ").arg(row));
              model8->setData(index,text1);
              }
      }
          {
              QModelIndex index = model8->index(row,2,QModelIndex());
              // 0 for all data
              if(row == 0)
              {
              QString text1= QString("0.0");
              //text.append(QString("%1 ").arg(row));
              model8->setData(index,text1);
              }
              else if(row == 1)
              {

              QString text1= QString("0.0");
              //text.append(QString("%1 ").arg(row));
              model8->setData(index,text1);
              }
      }
      }

      ui->stackedWidget->setCurrentIndex(18);
   }




}





void MainWindow::onTableClicked_6(const QModelIndex &index)
{

    //QString cellText = index.data().toString();
    cellText4 = index.row();
    //qDebug()<<"cellText4="<<cellText4;
    ui->stackedWidget->setCurrentIndex(6);



    QModelIndex index5 = model9->index(cellText4,1,QModelIndex());
    QString cellText = index5.data().toString();
    //qDebug()<<"cellText="<<cellText.split(",")[0];

    cellText=cellText.split(",")[0];
    model9_ch=cellText.split(" ")[1].toUInt();
     //qDebug()<<"model9_ch="<<model9_ch;

     //task bar Ana. Out (num)
    QString task_bar_ao = QString("Ana. Out ");
    task_bar_ao.append(cellText.split(" ")[1]);
    ui->pushButton_21->setText(task_bar_ao);





    /* filling data into respective AO cards channel */



               for(int row = 0; row < 5; row++)
               {
                   ui->tableView_20->setRowHeight(row,40);
                   //for(int col = 0; col < 2; col++)
                   {
                       QModelIndex index = model10->index(row,0,QModelIndex());
                       // 0 for all data
                       if(row == 0)
                       {
                       QString text= QString("Enabled");
                       //text.append(QString("%1 ").arg(row));
                       model10->setData(index,text);
                       }
                       else if(row == 1)
                       {
                       QString text= QString("Allow Overrge");
                       //text.append(QString("%1 ").arg(row));
                       model10->setData(index,text);
                       }
                       else if(row == 2)
                       {
                       QString text= QString("Transmit Pen");
                       //text.append(QString("%1 ").arg(row));
                       model10->setData(index,text);
                       }
                       else if(row == 3)
                       {
                       QString text= QString("Output");
                       //text.append(QString("%1 ").arg(row));
                       model10->setData(index,text);
                       }
                       else if(row == 4)
                       {
                       QString text= QString("Label");
                       //text.append(QString("%1 ").arg(row));
                       model10->setData(index,text);
                       }


                   }

                   {
                       QModelIndex index = model10->index(row,1,QModelIndex());
                       // 0 for all data
                       if(row == 0)
                       {
                          if(AIOchinfo[model9_ch]->AOchinfo->ch_enable == 1)
                          {
                               QString text= QString("ENABLED");
                               model10->setData(index,text);
                          }
                          else
                          {
                              QString text= QString("DISABLED");
                              model10->setData(index,text);
                          }
                       }
                       else if(row == 1)
                       {
                       QString text= QString("disabled");
                       //text.append(QString("%1 ").arg(row));
                       model10->setData(index,text);
                       }
                       else if(row == 2)
                       {

                         int tr_pen = AIOchinfo[model9_ch]->AOchinfo->transmit_pen_num;

                       QString text=QString(QVariant(tr_pen).toString());
                       //text.append(QString("%1 ").arg(row));
                       model10->setData(index,text);
                       }
                       else if(row == 3)
                       {
                           if(AIOchinfo[model9_ch]->AOchinfo->df_out_range == 1)
                           {
                                QString text= QString("0-20mA");
                                model10->setData(index,text);
                           }
                           else if(AIOchinfo[model9_ch]->AOchinfo->df_out_range == 2)
                           {

                               QString text= QString("4-20mA");
                               model10->setData(index,text);
                           }
                       }
                       else if(row == 4)
                       {
                       QString text= QString(" ");
                       model10->setData(index,text);
                       }


                   }
               }
    //**************************************************************


               QModelIndex index4 = model10->index(4,1,QModelIndex());
               model10->setData(index4,cellText.split(",")[0]);


}
void MainWindow::onTableClicked_7(const QModelIndex &index)
{
    //QString cellText = index.data().toString();
    cellText4 = index.row();
     //qDebug()<<"power_arr[power_value]"<<cellText4;
     ui->stackedWidget->setCurrentIndex(20);


     QModelIndex index5 = model11->index(cellText4,1,QModelIndex());
     QString cellText = index5.data().toString();
     //qDebug()<<"cellText="<<cellText.split(",")[0];


     cellText=cellText.split(" ")[0];
     // qDebug()<<"model11_ch_test="<<cellText;
     model11_ch=QString(cellText[1]).toUInt();
      //qDebug()<<"model11_ch="<< model11_ch;




      //task bar Digital I/O (num)
     QString task_bar_dio = QString("Digital I/O ");
     task_bar_dio.append(cellText[1]);
     ui->EDIT_SETUP_FIELDIO_ALARM_DIGITALIO_INDEX_TOP_BAR_Alarm_DigitalIo_Index->setText(task_bar_dio);





      for(int row = 0; row < 9; row++)
          {
              ui->EDIT_SETUP_FIELDIO_ALARM_DIGITALIO_INDEX_Tableview->setRowHeight(row,40);
              //for(int col = 0; col < 2; col++)
              {
                  QModelIndex index = model12->index(row,0,QModelIndex());
                  // 0 for all data
                  if(row == 0)
                  {
                  QString text= QString("Enabled");
                  //text.append(QString("%1 ").arg(row));
                  model12->setData(index,text);
                  }
                  else if(row == 1)
                  {
                  QString text= QString("Digital Type");
                  //text.append(QString("%1 ").arg(row));
                  model12->setData(index,text);
                  }
                  else if(row == 2)
                  {
                  QString text= QString("Output");
                  //text.append(QString("%1 ").arg(row));
                  model12->setData(index,text);
                  }
                  else if(row == 3)
                  {
                  QString text= QString("Pulse Duration");
                  //text.append(QString("%1 ").arg(row));
                  model12->setData(index,text);
                  }
                  else if(row == 4)
                  {
                  QString text= QString("Failsafe");
                  //text.append(QString("%1 ").arg(row));
                  model12->setData(index,text);
                  }
                  else if(row == 5)
                  {
                  QString text= QString("Label");
                  //text.append(QString("%1 ").arg(row));
                  model12->setData(index,text);
                  }
                  else if(row == 6)
                  {
                  QString text= QString("Active Label");
                  //text.append(QString("%1 ").arg(row));
                  model12->setData(index,text);
                  }
                  else if(row == 7)
                  {
                  QString text= QString("Inactive Label");
                  //text.append(QString("%1 ").arg(row));
                  model12->setData(index,text);
                  }
                  else if(row == 8)
                  {
                  QString text= QString("Reports To");
                  //text.append(QString("%1 ").arg(row));
                  model12->setData(index,text);
                  }


              }

              {
                  QModelIndex index = model12->index(row,1,QModelIndex());
                  // 0 for all data
                  if(row == 0)
                  {
                      if(DIOARchinfo[model11_ch]->DIOchinfo->ch_enable == 1)
                      {
                          QString text= QString("ENABLED");
                          //text.append(QString("%1 ").arg(row));
                          model12->setData(index,text);
                      }
                      else if (DIOARchinfo[model11_ch]->DIOchinfo->ch_enable == 0)
                      {
                          QString text= QString("DISABLED");
                          //text.append(QString("%1 ").arg(row));
                          model12->setData(index,text);
                      }
                  }
                  else if(row == 1)
                  {
                      if(DIOARchinfo[model11_ch]->DIOchinfo->digitalType == 1)
                      {
                          //qDebug()<<"////////////////////digital type="<<DIOARchinfo[model11_ch]->DIOchinfo->digitalType;
                          QString text= QString("Input");
                          model12->setData(index,text);
                      }
                      else if(DIOARchinfo[model11_ch]->DIOchinfo->digitalType == 2)
                      {
                         // qDebug()<<"/////////////////////digital type="<<DIOARchinfo[model11_ch]->DIOchinfo->digitalType;
                          QString text= QString("Pulse Input (Hz)");
                          model12->setData(index,text);
                      }
                      else if(DIOARchinfo[model11_ch]->DIOchinfo->digitalType == 3)
                      {
                         // qDebug()<<"/////////////////////digital type="<<DIOARchinfo[model11_ch]->DIOchinfo->digitalType;
                          QString text= QString("Output Relay contact (24V)");
                          model12->setData(index,text);
                      }

                  }
                  else if(row == 2)
                  {
                      if(DIOARchinfo[model11_ch]->DIOchinfo->outputType == 1)
                      {
                          QString text= QString("Latched");
                          model12->setData(index,text);
                      }
                      if(DIOARchinfo[model11_ch]->DIOchinfo->outputType == 2)
                      {
                          QString text= QString("Single Pulse");
                          model12->setData(index,text);
                      }
                  }
                  else if(row == 3)
                  {
                      if(DIOARchinfo[model11_ch]->DIOchinfo->outputType == 2)
                      {
                          int t_sec = 0;
                          t_sec = DIOARchinfo[model11_ch]->DIOchinfo->pulseDuration;

                          QString text= QString(QVariant(t_sec).toString());
                          model12->setData(index,text);
                      }

                  }
                  else if(row == 4)
                  {
                      if(DIOARchinfo[model11_ch]->DIOchinfo->failSafe == 2 )
                      {
                          QString text= QString("Off");
                          model12->setData(index,text);
                      }
                      else if (DIOARchinfo[model11_ch]->DIOchinfo->failSafe == 1)
                      {
                          QString text= QString("On");
                          model12->setData(index,text);

                      }
                  }
                  else if(row == 5)
                  {
                          QString text= QString(DIOARchinfo[model11_ch]->DIOchinfo->label);
                          model12->setData(index,text);
                  }
                  else if(row == 6)
                  {
                      QString text= QString("ON");
                      model12->setData(index,text);
                  }
                  else if(row == 7)
                  {
                      QString text= QString("OFF");
                      model12->setData(index,text);
                  }
                  else if(row == 8)
                  {
                      QString text= QString("User Messages and Chart");
                      model12->setData(index,text);
                  }


          }
      }





















      /***********************************************/





}
void MainWindow::onTableClicked_8(const QModelIndex &index)
{

 QString celltext = index.data().toString();

    if (celltext == "ENABLED")
    {
        AIOchinfo[model9_ch]->AOchinfo->ch_enable = 0;
        AIOchinfo[model9_ch]->AOchinfo->changeFlag = 1;
        QString text= QString("DISABLED");
        model10->setData(index,text);

    }
    if (celltext == "DISABLED" )
    {
        AIOchinfo[model9_ch]->AOchinfo->ch_enable = 1;
        AIOchinfo[model9_ch]->AOchinfo->changeFlag = 1;
        QString text= QString("ENABLED");
        model10->setData(index,text);

    }

    if (celltext == "0-20mA" || celltext == "4-20mA" )
    {
        output_popup output_popup;
        output_popup.setModal(true);
        output_popup.exec();
        AIOchinfo[model9_ch]->AOchinfo->df_out_range = AO_mode;
        //qDebug()<<"AO_MODE="<<AIOchinfo[model9_ch]->AOchinfo->df_out_range;
        AIOchinfo[model9_ch]->AOchinfo->changeFlag = 1;

        QModelIndex index2 = model10->index(3,1,QModelIndex());

        if(AIOchinfo[model9_ch]->AOchinfo->df_out_range == 1)
        {
             QString text= QString("0-20mA");
             model10->setData(index2,text);
        }
        else if(AIOchinfo[model9_ch]->AOchinfo->df_out_range == 2)
        {

            QString text= QString("4-20mA");
            model10->setData(index2,text);
        }





    }


}




//dio

void MainWindow::onTableClicked_9(const QModelIndex &index)
{
//DIOARchinfo[row+1]->DIOchinfo->digitalType == 3
 QString celltext = index.data().toString();

    if (celltext == "ENABLED")
    {
        DIOARchinfo[model11_ch]->DIOchinfo->ch_enable = 0;

        QString text= QString("DISABLED");
        model12->setData(index,text);

    }
    if (celltext == "DISABLED" )
    {
        DIOARchinfo[model11_ch]->DIOchinfo->ch_enable = 1;

        QString text= QString("ENABLED");
        model12->setData(index,text);

    }

    if (celltext == "Output Relay contact (24V)" || celltext == "Pulse Input (Hz)" || celltext == "Input" )
    {
        digitalio_dialog digitalio_dialog;
        digitalio_dialog.setModal(true);
        digitalio_dialog.exec();
        DIOARchinfo[model11_ch]->DIOchinfo->digitalType = DIO_mode;
       // qDebug()<<"DIO_MODE="<<DIOARchinfo[model11_ch]->DIOchinfo->digitalType;


        //QModelIndex index2 = model10->index(3,1,QModelIndex());

        if(DIOARchinfo[model11_ch]->DIOchinfo->digitalType == 1)
        {
            model12 = new QStandardItemModel(5,2,this);
            ui->EDIT_SETUP_FIELDIO_ALARM_DIGITALIO_INDEX_Tableview->setModel(model12);
            ui->EDIT_SETUP_FIELDIO_ALARM_DIGITALIO_INDEX_Tableview->setColumnWidth(0,250);
            ui->EDIT_SETUP_FIELDIO_ALARM_DIGITALIO_INDEX_Tableview->setColumnWidth(1,400);
            ui->EDIT_SETUP_FIELDIO_ALARM_DIGITALIO_INDEX_Tableview->setStyleSheet(
                                             "QTableView::item{"
                                             "border: 1px solid black;"
                                             "border-radius: 5px;"
                                             "background-color: rgb(255, 255, 127);"
                                             "color: black;"
                                             "}"
                                             );
            for(int row = 0; row < 6; row++)
                {
                    ui->EDIT_SETUP_FIELDIO_ALARM_DIGITALIO_INDEX_Tableview->setRowHeight(row,40);
                    //for(int col = 0; col < 2; col++)
                    {
                        QModelIndex index = model12->index(row,0,QModelIndex());
                        // 0 for all data
                        if(row == 0)
                        {
                        QString text= QString("Enabled");
                        //text.append(QString("%1 ").arg(row));
                        model12->setData(index,text);
                        }
                        else if(row == 1)
                        {
                        QString text= QString("Digital Type");
                        //text.append(QString("%1 ").arg(row));
                        model12->setData(index,text);
                        }

                        else if(row == 2)
                        {
                        QString text= QString("Label");
                        //text.append(QString("%1 ").arg(row));
                        model12->setData(index,text);
                        }
                        else if(row == 3)
                        {
                        QString text= QString("Active Label");
                        //text.append(QString("%1 ").arg(row));
                        model12->setData(index,text);
                        }
                        else if(row == 4)
                        {
                        QString text= QString("Inactive Label");
                        //text.append(QString("%1 ").arg(row));
                        model12->setData(index,text);
                        }
                        else if(row == 5)
                        {
                        QString text= QString("Reports To");
                        //text.append(QString("%1 ").arg(row));
                        model12->setData(index,text);
                        }


                    }

                    {
                        QModelIndex index = model12->index(row,1,QModelIndex());
                        // 0 for all data
                        if(row == 0)
                        {
                            if(DIOARchinfo[model11_ch]->DIOchinfo->ch_enable == 1)
                            {
                                QString text= QString("ENABLED");
                                //text.append(QString("%1 ").arg(row));
                                model12->setData(index,text);
                            }
                            else if (DIOARchinfo[model11_ch]->DIOchinfo->ch_enable == 0)
                            {
                                QString text= QString("DISABLED");
                                //text.append(QString("%1 ").arg(row));
                                model12->setData(index,text);
                            }
                        }
                        else if(row == 1)
                        {
                            if(DIOARchinfo[model11_ch]->DIOchinfo->digitalType == 1)
                            {
                                QString text= QString("Input");
                                model12->setData(index,text);
                            }
                            else if(DIOARchinfo[model11_ch]->DIOchinfo->digitalType == 2)
                            {
                                QString text= QString("Pulse Input (Hz)");
                                model12->setData(index,text);
                            }
                            else if(DIOARchinfo[model11_ch]->DIOchinfo->digitalType == 3)
                            {
                                QString text= QString("Output Relay contact (24V)");
                                model12->setData(index,text);
                            }

                        }

                        else if(row == 2)
                        {
                                QString text= QString(DIOARchinfo[model11_ch]->DIOchinfo->label);
                                model12->setData(index,text);
                        }
                        else if(row == 3)
                        {
                            QString text= QString("ON");
                            model12->setData(index,text);
                        }
                        else if(row == 4)
                        {
                            QString text= QString("OFF");
                            model12->setData(index,text);
                        }
                        else if(row == 5)
                        {
                            QString text= QString("User Messages and Chart");
                            model12->setData(index,text);
                        }


                }
            }

        }
        if(DIOARchinfo[model11_ch]->DIOchinfo->digitalType == 2)
        {
            //pulse input
            model12 = new QStandardItemModel(3,2,this);
            ui->EDIT_SETUP_FIELDIO_ALARM_DIGITALIO_INDEX_Tableview->setModel(model12);
            ui->EDIT_SETUP_FIELDIO_ALARM_DIGITALIO_INDEX_Tableview->setColumnWidth(0,250);
            ui->EDIT_SETUP_FIELDIO_ALARM_DIGITALIO_INDEX_Tableview->setColumnWidth(1,400);
            ui->EDIT_SETUP_FIELDIO_ALARM_DIGITALIO_INDEX_Tableview->setStyleSheet(
                                             "QTableView::item{"
                                             "border: 1px solid black;"
                                             "border-radius: 5px;"
                                             "background-color: rgb(255, 255, 127);"
                                             "color: black;"
                                             "}"
                                             );
            for(int row = 0; row < 3; row++)
                {
                    ui->EDIT_SETUP_FIELDIO_ALARM_DIGITALIO_INDEX_Tableview->setRowHeight(row,40);
                    //for(int col = 0; col < 2; col++)
                    {
                        QModelIndex index = model12->index(row,0,QModelIndex());
                        // 0 for all data
                        if(row == 0)
                        {
                        QString text= QString("ENABLED");
                        //text.append(QString("%1 ").arg(row));
                        model12->setData(index,text);
                        }
                        else if(row == 1)
                        {
                        QString text= QString("Digital Type");
                        //text.append(QString("%1 ").arg(row));
                        model12->setData(index,text);
                        }
                        else if(row == 2)
                        {
                        QString text= QString("Label");
                        //text.append(QString("%1 ").arg(row));
                        model12->setData(index,text);
                        }

                    }

                    {
                        QModelIndex index = model12->index(row,1,QModelIndex());
                        // 0 for all data
                        if(row == 0)
                        {
                            if(DIOARchinfo[model11_ch]->DIOchinfo->ch_enable == 1)
                            {
                                QString text= QString("ENABLED");
                                //text.append(QString("%1 ").arg(row));
                                model12->setData(index,text);
                            }
                            else if (DIOARchinfo[model11_ch]->DIOchinfo->ch_enable == 0)
                            {
                                QString text= QString("DISABLED");
                                //text.append(QString("%1 ").arg(row));
                                model12->setData(index,text);
                            }
                        }
                        else if(row == 1)
                        {
                            if(DIOARchinfo[model11_ch]->DIOchinfo->digitalType == 1)
                            {
                                QString text= QString("Input");
                                model12->setData(index,text);
                            }
                            else if(DIOARchinfo[model11_ch]->DIOchinfo->digitalType == 2)
                            {
                                QString text= QString("Pulse Input (Hz)");
                                model12->setData(index,text);
                            }
                            else if(DIOARchinfo[model11_ch]->DIOchinfo->digitalType == 3)
                            {
                                QString text= QString("Output Relay contact (24V)");
                                model12->setData(index,text);
                            }

                        }
                        else if(row == 2)
                        {
                                QString text= QString(DIOARchinfo[model11_ch]->DIOchinfo->label);
                                model12->setData(index,text);
                        }

                }
            }


           /////////////////////////
        }
        if(DIOARchinfo[model11_ch]->DIOchinfo->digitalType == 3)
        {
            //output
            model12 = new QStandardItemModel(9,2,this);
            ui->EDIT_SETUP_FIELDIO_ALARM_DIGITALIO_INDEX_Tableview->setModel(model12);
            ui->EDIT_SETUP_FIELDIO_ALARM_DIGITALIO_INDEX_Tableview->setColumnWidth(0,250);
            ui->EDIT_SETUP_FIELDIO_ALARM_DIGITALIO_INDEX_Tableview->setColumnWidth(1,400);
            ui->EDIT_SETUP_FIELDIO_ALARM_DIGITALIO_INDEX_Tableview->setStyleSheet(
                                             "QTableView::item{"
                                             "border: 1px solid black;"
                                             "border-radius: 5px;"
                                             "background-color: rgb(255, 255, 127);"
                                             "color: black;"
                                             "}"
                                             );

            for(int row = 0; row < 9; row++)
                {
                    ui->EDIT_SETUP_FIELDIO_ALARM_DIGITALIO_INDEX_Tableview->setRowHeight(row,40);
                    //for(int col = 0; col < 2; col++)
                    {
                        QModelIndex index = model12->index(row,0,QModelIndex());
                        // 0 for all data
                        if(row == 0)
                        {
                        QString text= QString("Enabled");
                        //text.append(QString("%1 ").arg(row));
                        model12->setData(index,text);
                        }
                        else if(row == 1)
                        {
                        QString text= QString("Digital Type");
                        //text.append(QString("%1 ").arg(row));
                        model12->setData(index,text);
                        }
                        else if(row == 2)
                        {
                        QString text= QString("Output");
                        //text.append(QString("%1 ").arg(row));
                        model12->setData(index,text);
                        }
                        else if(row == 3)
                        {
                        QString text= QString("Pulse Duration");
                        //text.append(QString("%1 ").arg(row));
                        model12->setData(index,text);
                        }
                        else if(row == 4)
                        {
                        QString text= QString("Failsafe");
                        //text.append(QString("%1 ").arg(row));
                        model12->setData(index,text);
                        }
                        else if(row == 5)
                        {
                        QString text= QString("Label");
                        //text.append(QString("%1 ").arg(row));
                        model12->setData(index,text);
                        }
                        else if(row == 6)
                        {
                        QString text= QString("Active Label");
                        //text.append(QString("%1 ").arg(row));
                        model12->setData(index,text);
                        }
                        else if(row == 7)
                        {
                        QString text= QString("Inactive Label");
                        //text.append(QString("%1 ").arg(row));
                        model12->setData(index,text);
                        }
                        else if(row == 8)
                        {
                        QString text= QString("Reports To");
                        //text.append(QString("%1 ").arg(row));
                        model12->setData(index,text);
                        }


                    }

                    {
                        QModelIndex index = model12->index(row,1,QModelIndex());
                        // 0 for all data
                        if(row == 0)
                        {
                            if(DIOARchinfo[model11_ch]->DIOchinfo->ch_enable == 1)
                            {
                                QString text= QString("ENABLED");
                                //text.append(QString("%1 ").arg(row));
                                model12->setData(index,text);
                            }
                            else if (DIOARchinfo[model11_ch]->DIOchinfo->ch_enable == 0)
                            {
                                QString text= QString("DISABLED");
                                //text.append(QString("%1 ").arg(row));
                                model12->setData(index,text);
                            }
                        }
                        else if(row == 1)
                        {
                            if(DIOARchinfo[model11_ch]->DIOchinfo->digitalType == 1)
                            {
                                QString text= QString("Input");
                                model12->setData(index,text);
                            }
                            else if(DIOARchinfo[model11_ch]->DIOchinfo->digitalType == 2)
                            {
                                QString text= QString("Pulse Input (Hz)");
                                model12->setData(index,text);
                            }
                            else if(DIOARchinfo[model11_ch]->DIOchinfo->digitalType == 3)
                            {
                                QString text= QString("Output Relay contact (24V)");
                                model12->setData(index,text);
                            }

                        }
                        else if(row == 2)
                        {
                            if(DIOARchinfo[model11_ch]->DIOchinfo->outputType == 1)
                            {
                                QString text= QString("Latched");
                                model12->setData(index,text);
                            }
                            if(DIOARchinfo[model11_ch]->DIOchinfo->outputType == 2)
                            {
                                QString text= QString("Single Pulse");
                                model12->setData(index,text);
                            }
                        }
                        else if(row == 3)
                        {
                            if(DIOARchinfo[model11_ch]->DIOchinfo->outputType == 2)
                            {
                                int t_sec = 0;
                                t_sec = DIOARchinfo[model11_ch]->DIOchinfo->pulseDuration;

                                QString text= QString(QVariant(t_sec).toString());
                                model12->setData(index,text);
                            }

                        }
                        else if(row == 4)
                        {
                            if(DIOARchinfo[model11_ch]->DIOchinfo->failSafe == 0 )
                            {
                                QString text= QString("Off");
                                model12->setData(index,text);
                            }
                            else if (DIOARchinfo[model11_ch]->DIOchinfo->failSafe == 1)
                            {
                                QString text= QString("On");
                                model12->setData(index,text);

                            }
                        }
                        else if(row == 5)
                        {
                                QString text= QString(DIOARchinfo[model11_ch]->DIOchinfo->label);
                                model12->setData(index,text);
                        }
                        else if(row == 6)
                        {
                            QString text= QString("ON");
                            model12->setData(index,text);
                        }
                        else if(row == 7)
                        {
                            QString text= QString("OFF");
                            model12->setData(index,text);
                        }
                        else if(row == 8)
                        {
                            QString text= QString("User Messages and Chart");
                            model12->setData(index,text);
                        }


                }
            }

        }





    }

    if(DIOARchinfo[model11_ch]->DIOchinfo->digitalType == 3)
    {
    //duration
    QModelIndex index6 = model12->index(3,0,QModelIndex());
    QString cell = index6.data().toString();
   // qDebug()<<"pre...........data=\n";
    if (cell ==  "Pulse Duration")
    {

        QModelIndex index7 = model12->index(3,1,QModelIndex());
        int data= index7.data().toInt();
       // qDebug()<<"...................data=\n"<<data;
        DIOARchinfo[model11_ch]->DIOchinfo->pulseDuration=data;

    }
    }


}

void MainWindow::onTableClicked_10(const QModelIndex &index) {
    int row = index.row();


    QModelIndex tvEncryptIndex = model13->index(0, 1, QModelIndex());
    QModelIndex csvIndex = model13->index(1, 1, QModelIndex());
      if (row == 0)
         {
           // If row 1 (TV Encrypt) is clicked and TV Encrypt is not disabled, disable TV Encrypt and enable CSV
           model13->setData(tvEncryptIndex, "Disabled");
           model13->setData(csvIndex, "Enabled");
           //ui->tableView->model()->setData(tvEncryptIndex, QColor(Qt::red), Qt::TextColorRole);

           ui->toolButton_40->setEnabled(false);
       } else if (row == 1) {
           // If row 2 (CSV) is clicked and CSV is not disabled, disable CSV and enable TV Encrypt
          model13->setData(csvIndex, "Disabled");
          model13->setData(tvEncryptIndex, "Enabled");
          ui->toolButton_40->setEnabled(true);
       }
   }






//       if (row == 0) {
//               // If row 1 (TV Encrypt) is clicked
//               if (tvEncryptText == "DISABLED") {
//                   model13->setData(tvEncryptIndex, "TV Encrypt");
//                   model13->setData(csvIndex, "DISABLED");
//                   ui->toolButton_40->setEnabled(true);
//               } else {
//                   model13->setData(tvEncryptIndex, "DISABLED");
//                   model13->setData(csvIndex, "CSV");
//                   ui->toolButton_40->setEnabled(true);
//               }
//           } else if (row == 1) {
//               // If row 2 (CSV) is clicked
//               if (csvText == "DISABLED") {
//                   model13->setData(csvIndex, "CSV");
//                   model13->setData(tvEncryptIndex, "DISABLED");
//                   ui->toolButton_40->setEnabled(true);
//               } else {
//                   model13->setData(csvIndex, "DISABLED");
//                   model13->setData(tvEncryptIndex, "TV Encrypt");
//                   ui->toolButton_40->setEnabled(true);
//               }
//           }
//       }


bool isRow0Clicked = false;
bool isRow3Clicked = false;

void MainWindow::onTableClicked_11(const QModelIndex &index) {

    int clickedRow = index.row();

    QModelIndex indexRow0Col1 = model14->index(0, 1, QModelIndex());
    QModelIndex indexRow1Col1 = model14->index(1, 1, QModelIndex());
    QModelIndex indexRow2Col1 = model14->index(2, 1, QModelIndex());
    QModelIndex indexRow3Col1 = model14->index(3, 1, QModelIndex());
    QModelIndex indexRow4Col1 = model14->index(4, 1, QModelIndex());
    QStandardItem *itemRow0Col1 = model14->itemFromIndex(indexRow0Col1);
    QStandardItem *itemRow3Col1 = model14->itemFromIndex(indexRow3Col1);
    QStandardItem *itemRow4Col1 = model14->itemFromIndex(indexRow4Col1);
    QString cellText1 = indexRow0Col1.data().toString();
    QString cellText2 = indexRow1Col1.data().toString();
    QString cellText3 = indexRow2Col1.data().toString();
    QString cellText4 = indexRow3Col1.data().toString();
    QString cellText5 = indexRow4Col1.data().toString();
    if (cellText1 == "Disabled" && clickedRow != 0)
        return;
     if(cellText4 == "Disabled" && clickedRow == 4)
         return;
    if (clickedRow == 0)
    {
        if (cellText1 == "Enabled")
            itemRow0Col1->setText("Disabled");
        if (cellText1 == "Disabled")        
            itemRow0Col1->setText("Enabled");
    }
    else if (clickedRow == 1 || clickedRow == 2)
    {
        if (clickedRow == 1) {
            Export_dialog exportDialog;
            exportDialog.exec();
        } else if (clickedRow == 2) {
            Update_dialog updateDialog;
            updateDialog.exec();
        }
    }
    else if (clickedRow == 3)
    {
        if (cellText4 == "Enabled") {
            itemRow4Col1->setText("Disabled");
            itemRow3Col1->setText("Disabled");
        }
        if (cellText4 == "Disabled")
        {
            itemRow4Col1->setText("Enabled");
            itemRow3Col1->setText("Enabled");
        }

    }

    if (usb ==1){
    QModelIndex Index = model14->index(1, 1, QModelIndex());
    model14->setData(Index,"Front SD");
    }
    if (usb ==2){
    QModelIndex Index = model14->index(1, 1, QModelIndex());
    model14->setData(Index,"USB1");
    }
    if (usb ==3){
    QModelIndex Index = model14->index(1, 1, QModelIndex());
    model14->setData(Index,"USB2");
    }
    if (minute_value ==1){
    QModelIndex Index = model14->index(2, 1, QModelIndex());
    model14->setData(Index,"10 Minutes");
    }
    if (minute_value ==2){
    QModelIndex Index = model14->index(2, 1, QModelIndex());
    model14->setData(Index,"30 Minutes");
    }
    if (minute_value ==3){
    QModelIndex Index = model14->index(2, 1, QModelIndex());
    model14->setData(Index,"1 Hour");
    }
    if (minute_value ==4){
    QModelIndex Index = model14->index(2, 1, QModelIndex());
    model14->setData(Index,"2 Hours");
    }
    if (minute_value ==5){
    QModelIndex Index = model14->index(2, 1, QModelIndex());
    model14->setData(Index,"12 Hours");
    }
    if (minute_value ==6){
    QModelIndex Index = model14->index(2, 1, QModelIndex());
    model14->setData(Index,"24 Hours");
    }
}

void MainWindow::onTableClicked_12(const QModelIndex &index)
{
    EnAcqFlag =0;
 QString celltext = index.data().toString();
 if(celltext == "Standard Screen 1")
 {

     if(screen_type == 1)
     {
        ui->stackedWidget->setCurrentIndex(34);
     }
     else if (screen_type == 2)
     {
        ui->stackedWidget->setCurrentIndex(41);
     }
 }


}


void MainWindow::onTableClicked_13(const QModelIndex &index) {
    int row = index.row();
    int col = index.column();
    QStandardItem *item = scale_model->item(row, col);

    if (index.row() == 0 && index.column() == 1) {
        qwerty_keyboard keyboard;
        keyboard.setModal(true);
        keyboard.exec();
        QModelIndex index667 = scale_model->index(0, 1, QModelIndex());
        if (qwert_flag == 0) {
            scale_model->setData(index667, qwerty_keyboard_text);
        } else if (qwert_flag == 1) {
            scale_model->setData(index667, qwerty_keyboard_CAPS_text);
        }
    } else if (index.row() == 1 && index.column() == 1) {
        VoltsValueSelection voltvalue;
        voltvalue.setModal(true);
        voltvalue.exec();
        QModelIndex index668 = scale_model->index(1, 1, QModelIndex());
        scale_model->setData(index668, keyboard_text);
    } else if (index.row() == 2 && index.column() == 1) {
        VoltsValueSelection voltvalue;
        voltvalue.setModal(true);
        voltvalue.exec();
        QModelIndex index669 = scale_model->index(2, 1, QModelIndex());
        scale_model->setData(index669, keyboard_text);
    }else if (row == 3 && col == 1) {
        QModelIndex index670 = scale_model->index(3, 1, QModelIndex());
        QString currentText = scale_model->data(index670).toString();

        if (currentText == "Linear") {
            ui->stackedWidget->setCurrentIndex(108); // Set index to 77 for "Log"
        }
    }else if (index.row() == 4 && index.column() == 1) {
        QModelIndex index669 = scale_model->index(4, 1, QModelIndex());
        QString currentText = scale_model->data(index669).toString();

        if (currentText == "User Defined") {
            scale_model->setData(index669, "Auto");
        } else if (currentText == "Auto") {
            scale_model->setData(index669, "User Defined");
        }
    }else if (index.row() == 5 && index.column() == 1) {
        QModelIndex index669 = scale_model->index(4, 1, QModelIndex()); // Check text in row 4
        QString currentText = scale_model->data(index669).toString();

        if (currentText == "User Defined") {
            VoltsValueSelection voltvalue;
            voltvalue.setModal(true);
            voltvalue.exec();
            QModelIndex index670 = scale_model->index(5, 1, QModelIndex());
            scale_model->setData(index670, keyboard_text);
        }
    }else if (index.row() == 6 && index.column() == 1) {
        QModelIndex index669 = scale_model->index(4, 1, QModelIndex()); // Check text in row 4
        QString currentText = scale_model->data(index669).toString();

        if (currentText == "User Defined") {
            VoltsValueSelection voltvalue;
            voltvalue.setModal(true);
            voltvalue.exec();
            QModelIndex index670 = scale_model->index(6, 1, QModelIndex());
            scale_model->setData(index670, keyboard_text);
        }
    }else if (index.row() == 7 && index.column() == 1) {

        ui->stackedWidget->setCurrentIndex(78);


        }
}

void MainWindow::onTableClicked_14(const QModelIndex &index) {
    int row = index.row();
    int col = index.column();
    QStandardItem *item = log_model->item(row, col);
    if (index.row() == 0 && index.column() == 1) {
        qwerty_keyboard keyboard;
        keyboard.setModal(true);
        keyboard.exec();
        QModelIndex index667 = log_model->index(0, 1, QModelIndex());
        if (qwert_flag == 0) {
            log_model->setData(index667, qwerty_keyboard_text);
        } else if (qwert_flag == 1) {
            log_model->setData(index667, qwerty_keyboard_CAPS_text);
        }
        }else if (row == 3 && col == 1) {
        QModelIndex index670 = log_model->index(3, 1, QModelIndex());
        QString currentText = log_model->data(index670).toString();

        if (currentText == "Log") {
            ui->stackedWidget->setCurrentIndex(77); // Set index to 77 for "Log"
            }
        } else if (index.row() == 4 && index.column() == 1) {
        VoltsValueSelection volt;
        volt.setModal(true);
        volt.exec();
        QModelIndex index668 = log_model->index(4, 1, QModelIndex());
        log_model->setData(index668, keyboard_text);
    } else if (index.row() == 5 && index.column() == 1) {
        VoltsValueSelection volt;
        volt.setModal(true);
        volt.exec();
        QModelIndex index669 = log_model->index(5, 1, QModelIndex());
        log_model->setData(index669, keyboard_text);

} else if (index.row() == 6 && index.column() == 1) {
        ui->stackedWidget->setCurrentIndex(78);
    }
}

void MainWindow::onTableClicked_15(const QModelIndex &index) {
    int row = index.row();
    int col = index.column();
    QStandardItem *item =numb_model->item(row, col);
    if (index.row() == 0 && index.column() == 1) {
        QModelIndex index667 = numb_model->index(0, 1, QModelIndex());
        QString currentText = numb_model->data(index667).toString();

        if (currentText == "Normal") {
            numb_model->setData(index667, "Scientific");
        } else if (currentText == "Scientific") {
            numb_model->setData(index667, "Normal");
        }
        // Display the chosen text in log_model at index.row() == 6 && index.column() == 1
        QModelIndex logIndex = log_model->index(6, 1, QModelIndex());
        log_model->setData(logIndex, currentText);

        // Display the chosen text in scale_model at index.row() == 7 && index.column() == 1
            QModelIndex scaleIndex = scale_model->index(7, 1, QModelIndex());
            scale_model->setData(scaleIndex, currentText);
    }

    if (index.row() == 1 && index.column() == 1) {
        QModelIndex index668 = numb_model->index(1, 1, QModelIndex());
        QString currentText = numb_model->data(index668).toString();

        if (currentText == "User Defined") {
            numb_model->setData(index668, "Auto");
        } else if (currentText == "Auto") {
            numb_model->setData(index668, "User Defined");
        }
    }
    if (index.row() == 2 && index.column() == 1) {
            QModelIndex index669 = numb_model->index(1, 1, QModelIndex()); // Check text in row 1
            QString currentText = numb_model->data(index669).toString();

            if (currentText == "User Defined") {
                VoltsValueSelection selectedvalue;
                selectedvalue.setModal(true);
                selectedvalue.exec();
                QModelIndex index669 = numb_model->index(2, 1, QModelIndex());
                numb_model->setData(index669, keyboard_text);
            }
        }
}

QString variable1;
QString variable2;

void MainWindow::onTableClicked_17(const QModelIndex &index) {
    int row = index.row();
    int col = index.column();
    QStandardItem *item =rav_model->item(row, col);
    if (index.row() == 0 && index.column() == 1) {
        QModelIndex index667 = rav_model->index(0, 1, QModelIndex());
        QString currentText = rav_model->data(index667).toString();

        if (currentText == "Enabled") {
            rav_model->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            rav_model->setData(index667, "Enabled");
        }
    }
    if (index.row() == 1 && index.column() == 1) {
        QModelIndex index669 = rav_model->index(0, 1, QModelIndex()); // Check text in row 1
        QString currentText = rav_model->data(index669).toString();
        if(currentText == "Enabled"){
        VoltsValueSelection selected;
        selected.setModal(true);
        selected.exec();
        QModelIndex index669 = rav_model->index(1, 1, QModelIndex());
        rav_model->setData(index669, keyboard_text);

         variable1 = keyboard_text;
         variable1 += " Samples";

        }
    }
    if (index.row() == 2 && index.column() == 1) {
        QModelIndex index669 = rav_model->index(0, 1, QModelIndex()); // Check text in row 1
        QString currentText = rav_model->data(index669).toString();
        if(currentText == "Enabled"){
        VoltsValueSelection selected;
        selected.setModal(true);
        selected.exec();
        QModelIndex index669 = rav_model->index(2, 1, QModelIndex());
        rav_model->setData(index669, keyboard_text+" "+"Secs");
       variable2 = keyboard_text;
        variable2 += " Secs";

        }
    }
    if (index.row() == 3 && index.column() == 1) {
        QModelIndex index669 = rav_model->index(0, 1, QModelIndex()); // Check text in row 1
        QString currentText = rav_model->data(index669).toString();
        if(currentText == "Enabled"){
        QModelIndex index667 = rav_model->index(3, 1, QModelIndex());
        QString currentText = rav_model->data(index667).toString();

        if (currentText == "Enabled") {
            rav_model->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            rav_model->setData(index667, "Enabled");
        }
    }
}
    QString concatenatedValue =  variable1 + " " +variable2;
    QModelIndex index91 = model1->index(9, 1, QModelIndex());
    model1->setData(index91, concatenatedValue);
}



int storedClickedRow ;
int storedClickedColumn ;
void MainWindow::onTableClicked_18(const QModelIndex &index) {
    int clickedRow = index.row();
    int clickedColumn = index.column();

    if (clickedRow >= 0 && clickedRow <= 7) {
        ui->stackedWidget->setCurrentIndex(82);


        storedClickedRow = clickedRow;
        storedClickedColumn = clickedColumn;

    }
}

void MainWindow::onTableClicked_19(const QModelIndex &index) {
    int row = index.row();
    int col = index.column();
    QStandardItem *item = alarm_model1->item(row, col);

    if (index.row() == 0 && index.column() == 1) {
        alarm_status status;
        status.setModal(true);
        status.exec();
        QModelIndex index669 = alarm_model1->index(0, 1, QModelIndex());
        alarm_model1->setData(index669, alaram_variable);
        if(alaram_variable =="Enabled Always"){
            ui->stackedWidget->setCurrentIndex(82);

        }
        if(alaram_variable =="Disabled"){
            ui->stackedWidget->setCurrentIndex(82);

        }
        if(alaram_variable =="Dig Enabled"){
            ui->stackedWidget->setCurrentIndex(132);

        }
    }

    if (row == 1 && col == 1) {
        QModelIndex index0 = alarm_model1->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model1->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            alarm_type alarmtype;
            alarmtype.setModal(true);
            alarmtype.exec();
            QModelIndex index669 = alarm_model1->index(1, 1, QModelIndex());
            alarm_model1->setData(index669, alarmtype_variable);
            if(alarmtype_variable=="Deviation"){
                ui->stackedWidget->setCurrentIndex(82);

            }
            if(alarmtype_variable=="Rate Up"){
                ui->stackedWidget->setCurrentIndex(83);

            }
            if(alarmtype_variable=="Rate Down"){
                ui->stackedWidget->setCurrentIndex(85);

            }
            if(alarmtype_variable=="High"){
                ui->stackedWidget->setCurrentIndex(84);

            }
            if(alarmtype_variable=="Low"){
                ui->stackedWidget->setCurrentIndex(86);

            }
        }
    }

    if (row == 2 && col == 1) {
        QModelIndex index0 = alarm_model1->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model1->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
        VoltsValueSelection volt_value;
        volt_value.setModal(true);
        volt_value.exec();
        QModelIndex index669 = alarm_model1->index(2, 1, QModelIndex());
        alarm_model1->setData(index669, keyboard_text);
        }
    }

    if (row == 3 && col == 1) {
        QModelIndex index0 = alarm_model1->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model1->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
        qwerty_keyboard qwerty;
        qwerty.setModal(true);
        qwerty.exec();
        QModelIndex index667 = alarm_model1->index(3, 1, QModelIndex());
        if (qwert_flag == 0) {
            alarm_model1->setData(index667, qwerty_keyboard_text);
        } else if (qwert_flag == 1) {
            alarm_model1->setData(index667, qwerty_keyboard_CAPS_text);
        }
        }
    }
    if (index.row() == 4 && index.column() == 1) {
        QModelIndex index0 = alarm_model1->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model1->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {

        QModelIndex index667 = alarm_model1->index(4, 1, QModelIndex());
        QString currentText = alarm_model1->data(index667).toString();

        if (currentText == "Enabled") {
            alarm_model1->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            alarm_model1->setData(index667, "Enabled");
        }
        }
    }
    if (index.row() == 6 && index.column() == 1) {
        QModelIndex index0 = alarm_model1->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model1->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {

        QModelIndex index667 = alarm_model1->index(6, 1, QModelIndex());
        QString currentText = alarm_model1->data(index667).toString();

        if (currentText == "Enabled") {
            alarm_model1->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            alarm_model1->setData(index667, "Enabled");
        }
        }
    }
    if (index.row() == 7 && index.column() == 1) {
        QModelIndex index0 = alarm_model1->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model1->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {

        QModelIndex index667 = alarm_model1->index(7, 1, QModelIndex());
        QString currentText = alarm_model1->data(index667).toString();

        if (currentText == "Enabled") {
            alarm_model1->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            alarm_model1->setData(index667, "Enabled");
        }
        }
    }
    if (index.row() == 8 && index.column() == 1) {
        QModelIndex index0 = alarm_model1->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model1->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {

        QModelIndex index667 = alarm_model1->index(8, 1, QModelIndex());
        QString currentText = alarm_model1->data(index667).toString();

        if (currentText == "Enabled") {
            alarm_model1->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            alarm_model1->setData(index667, "Enabled");
        }
        }
    }
    if (index.row() == 9 && index.column() == 1) {
        QModelIndex index0 = alarm_model1->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model1->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {

        QModelIndex index667 = alarm_model1->index(9, 1, QModelIndex());
        QString currentText = alarm_model1->data(index667).toString();

        if (currentText == "Enabled") {
            alarm_model1->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            alarm_model1->setData(index667, "Enabled");
        }
        }
    }
    if (index.row() == 10 && index.column() == 1) {
        QModelIndex index0 = alarm_model1->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model1->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {

        QModelIndex index667 = alarm_model1->index(10, 1, QModelIndex());
        QString currentText = alarm_model1->data(index667).toString();

        if (currentText == "Enabled") {
            alarm_model1->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            alarm_model1->setData(index667, "Enabled");
        }
        }
    }
    if (index.row() == 11 && index.column() == 1) {
        QModelIndex index0 = alarm_model1->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model1->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {

        QModelIndex index667 = alarm_model1->index(11, 1, QModelIndex());
        QString currentText = alarm_model1->data(index667).toString();

        if (currentText == "Enabled") {
            alarm_model1->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            alarm_model1->setData(index667, "Enabled");
        }
        }
    }
    if (index.row() == 12 && index.column() == 1) {
        QModelIndex index0 = alarm_model1->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model1->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {

        QModelIndex index667 = alarm_model1->index(4, 1, QModelIndex());
        QString currentText = alarm_model1->data(index667).toString();

        if (currentText == "Enabled") {
            alarm_model1->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            alarm_model1->setData(index667, "Enabled");
        }
        }
    }
}




void MainWindow::onTableClicked_20(const QModelIndex &index) {
    int row = index.row();
    int col = index.column();
  QStandardItem *item = alarm_model2->item(row, col);

    if (row == 0 && col == 1) {
        qDebug("Clicked sussceffull");
        alarm_status alarmstatus;


        alarmstatus.setModal(true);
        alarmstatus.exec();
         qDebug("Clicked sussceffull1");
        QModelIndex index3 = alarm_model2->index(0, 1, QModelIndex());

        alarm_model2->setData(index3, alaram_variable);
    }
    if (row == 1 && col == 1) {
        QModelIndex index0 = alarm_model2->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model2->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            alarm_type type;
            type.setModal(true);
            type.exec();
            QModelIndex index669 = alarm_model2->index(1, 1, QModelIndex());
            alarm_model2->setData(index669, alarmtype_variable);

            if (alarmtype_variable == "Deviation") {
                ui->stackedWidget->setCurrentIndex(83);
            } else if (alarmtype_variable == "Rate Up") {
                ui->stackedWidget->setCurrentIndex(84);
            } else if (alarmtype_variable == "Rate Down") {
                ui->stackedWidget->setCurrentIndex(86);
            } else if (alarmtype_variable == "High") {
                ui->stackedWidget->setCurrentIndex(85);
            } else if (alarmtype_variable == "Low") {
                ui->stackedWidget->setCurrentIndex(87);
            }
        }
    }
    if (row == 2 && col == 1) {
        QModelIndex index0 = alarm_model2->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model2->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            VoltsValueSelection voltvalue;
            voltvalue.setModal(true);
            voltvalue.exec();
            QModelIndex index669 = alarm_model2->index(2, 1, QModelIndex());
            alarm_model2->setData(index669, keyboard_text);
        }
    }
    if (row == 4 && col == 1) {
        QModelIndex index0 = alarm_model2->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model2->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            qwerty_keyboard qwerty;
            qwerty.setModal(true);
            qwerty.exec();
            QModelIndex index667 = alarm_model1->index(4, 1, QModelIndex());

            if (qwert_flag == 0) {
                alarm_model1->setData(index667, qwerty_keyboard_text);
            } else if (qwert_flag == 1) {
                alarm_model1->setData(index667, qwerty_keyboard_CAPS_text);
            }
        }
    }

    if (row == 5 && col == 1) {
        QModelIndex index0 = alarm_model2->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model2->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            QModelIndex index667 = alarm_model2->index(5, 1, QModelIndex());
            QString currentText = alarm_model2->data(index667).toString();

            if (currentText == "Enabled") {
                alarm_model2->setData(index667, "Disabled");
            } else if (currentText == "Disabled") {
                alarm_model2->setData(index667, "Enabled");
            }
        }
    }
    if (row == 6 && col == 1) {
        QModelIndex index0 = alarm_model2->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model2->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            QModelIndex index667 = alarm_model2->index(6, 1, QModelIndex());
            QString currentText = alarm_model2->data(index667).toString();

            if (currentText == "Enabled") {
                alarm_model2->setData(index667, "Disabled");
            } else if (currentText == "Disabled") {
                alarm_model2->setData(index667, "Enabled");
            }
        }
    }
    if (row == 7 && col == 1) {
        QModelIndex index0 = alarm_model2->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model2->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            QModelIndex index667 = alarm_model2->index(7, 1, QModelIndex());
            QString currentText = alarm_model2->data(index667).toString();

            if (currentText == "Enabled") {
                alarm_model2->setData(index667, "Disabled");
            } else if (currentText == "Disabled") {
                alarm_model2->setData(index667, "Enabled");
            }
        }
    }
    if (row == 8 && col == 1) {
        QModelIndex index0 = alarm_model2->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model2->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            QModelIndex index667 = alarm_model2->index(8, 1, QModelIndex());
            QString currentText = alarm_model2->data(index667).toString();

            if (currentText == "Enabled") {
                alarm_model2->setData(index667, "Disabled");
            } else if (currentText == "Disabled") {
                alarm_model2->setData(index667, "Enabled");
            }
        }
    }
    if (row == 9 && col == 1) {
        QModelIndex index0 = alarm_model2->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model2->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            QModelIndex index667 = alarm_model2->index(9, 1, QModelIndex());
            QString currentText = alarm_model2->data(index667).toString();

            if (currentText == "Enabled") {
                alarm_model2->setData(index667, "Disabled");
            } else if (currentText == "Disabled") {
                alarm_model2->setData(index667, "Enabled");
            }
        }
    }
    if (row == 10 && col == 1) {
        QModelIndex index0 = alarm_model2->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model2->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            QModelIndex index667 = alarm_model2->index(10, 1, QModelIndex());
            QString currentText = alarm_model2->data(index667).toString();

            if (currentText == "Enabled") {
                alarm_model2->setData(index667, "Disabled");
            } else if (currentText == "Disabled") {
                alarm_model2->setData(index667, "Enabled");
            }
        }
    }
    if (row == 11&& col == 1) {
        QModelIndex index0 = alarm_model2->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model2->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            QModelIndex index667 = alarm_model2->index(11, 1, QModelIndex());
            QString currentText = alarm_model2->data(index667).toString();

            if (currentText == "Enabled") {
                alarm_model2->setData(index667, "Disabled");
            } else if (currentText == "Disabled") {
                alarm_model2->setData(index667, "Enabled");
            }
        }
    }
    if (row == 12 && col == 1) {
        QModelIndex index0 = alarm_model2->index(11, col, QModelIndex());
        QStandardItem *item0 = alarm_model2->item(11, col);

        if (item0 && (item0->text() == "Enabled")) {
            VoltsValueSelection voltvalue;
            voltvalue.setModal(true);
            voltvalue.exec();
            QModelIndex index669 = alarm_model2->index(12, 1, QModelIndex());
            alarm_model2->setData(index669, keyboard_text);
        }
    }
    if (row == 13 && col == 1) {
        QModelIndex index0 = alarm_model2->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model2->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            QModelIndex index667 = alarm_model2->index(13, 1, QModelIndex());
            QString currentText = alarm_model2->data(index667).toString();

            if (currentText == "Enabled") {
                alarm_model1->setData(index667, "Disabled");
            } else if (currentText == "Disabled") {
                alarm_model1->setData(index667, "Enabled");
            }
        }
    }
}




void MainWindow::onTableClicked_21(const QModelIndex &index) {
    int row = index.row();
    int col = index.column();
  QStandardItem *item = alarm_model3->item(row, col);

    if (row == 0 && col == 1) {
        qDebug("Clicked sussceffull");
        alarm_status alarmstatus;
        alarmstatus.setModal(true);
        alarmstatus.exec();
         qDebug("Clicked sussceffull1");
        QModelIndex index3 = alarm_model3->index(0, 1, QModelIndex());

        alarm_model3->setData(index3, alaram_variable);
    }
    if (row == 1 && col == 1) {
        QModelIndex index0 = alarm_model3->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model3->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            alarm_type atype;
            atype.setModal(true);
            atype.exec();
            QModelIndex index669 = alarm_model3->index(1, 1, QModelIndex());
            alarm_model3->setData(index669, alarmtype_variable);

            if (alarmtype_variable == "Deviation") {
                ui->stackedWidget->setCurrentIndex(83);
            } else if (alarmtype_variable == "Rate Up") {
                ui->stackedWidget->setCurrentIndex(84);
            } else if (alarmtype_variable == "Rate Down") {
                ui->stackedWidget->setCurrentIndex(86);
            } else if (alarmtype_variable == "High") {
                ui->stackedWidget->setCurrentIndex(85);
            } else if (alarmtype_variable == "Low") {
                ui->stackedWidget->setCurrentIndex(87);
            }
        }
    }
    if (row == 2 && col == 1) {
        QModelIndex index0 = alarm_model3->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model3->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            VoltsValueSelection avoltvalue;
            avoltvalue.setModal(true);
            avoltvalue.exec();
            QModelIndex index669 = alarm_model3->index(2, 1, QModelIndex());
            alarm_model3->setData(index669, keyboard_text);
        }
    }
    if (row == 3 && col == 1) {
        QModelIndex index0 = alarm_model3->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model3->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            VoltsValueSelection avoltvalue;
            avoltvalue.setModal(true);
            avoltvalue.exec();
            QModelIndex index669 = alarm_model3->index(3, 1, QModelIndex());
            alarm_model3->setData(index669, keyboard_text);
        }
    }
    if (row == 4 && col == 1) {
        QModelIndex index0 = alarm_model3->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model3->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            qwerty_keyboard aqwerty;
            aqwerty.setModal(true);
            aqwerty.exec();
            QModelIndex index667 = alarm_model3->index(4, 1, QModelIndex());

            if (qwert_flag == 0) {
                alarm_model3->setData(index667, qwerty_keyboard_text);
            } else if (qwert_flag == 1) {
                alarm_model3->setData(index667, qwerty_keyboard_CAPS_text);
            }
        }
    }

    if (row == 5 && col == 1) {
        QModelIndex index0 = alarm_model3->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model3->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            QModelIndex index667 = alarm_model3->index(5, 1, QModelIndex());
            QString currentText = alarm_model3->data(index667).toString();

            if (currentText == "Enabled") {
                alarm_model3->setData(index667, "Disabled");
            } else if (currentText == "Disabled") {
                alarm_model3->setData(index667, "Enabled");
            }
        }
    }
    if (row == 6 && col == 1) {
        QModelIndex index0 = alarm_model3->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model3->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            QModelIndex index667 = alarm_model3->index(6, 1, QModelIndex());
            QString currentText = alarm_model3->data(index667).toString();

            if (currentText == "Enabled") {
                alarm_model3->setData(index667, "Disabled");
            } else if (currentText == "Disabled") {
                alarm_model3->setData(index667, "Enabled");
            }
        }
    }
    if (row == 7 && col == 1) {
        QModelIndex index0 = alarm_model3->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model3->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            QModelIndex index667 = alarm_model3->index(7, 1, QModelIndex());
            QString currentText = alarm_model3->data(index667).toString();

            if (currentText == "Enabled") {
                alarm_model3->setData(index667, "Disabled");
            } else if (currentText == "Disabled") {
                alarm_model3->setData(index667, "Enabled");
            }
        }
    }
    if (row == 8 && col == 1) {
        QModelIndex index0 = alarm_model3->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model3->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            QModelIndex index667 = alarm_model3->index(8, 1, QModelIndex());
            QString currentText = alarm_model3->data(index667).toString();

            if (currentText == "Enabled") {
                alarm_model3->setData(index667, "Disabled");
            } else if (currentText == "Disabled") {
                alarm_model3->setData(index667, "Enabled");
            }
        }
    }
    if (row == 9 && col == 1) {
        QModelIndex index0 = alarm_model3->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model3->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            QModelIndex index667 = alarm_model3->index(9, 1, QModelIndex());
            QString currentText = alarm_model3->data(index667).toString();

            if (currentText == "Enabled") {
                alarm_model3->setData(index667, "Disabled");
            } else if (currentText == "Disabled") {
                alarm_model3->setData(index667, "Enabled");
            }
        }
    }
    if (row == 10 && col == 1) {
        QModelIndex index0 = alarm_model3->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model3->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            QModelIndex index667 = alarm_model3->index(10, 1, QModelIndex());
            QString currentText = alarm_model3->data(index667).toString();

            if (currentText == "Enabled") {
                alarm_model3->setData(index667, "Disabled");
            } else if (currentText == "Disabled") {
                alarm_model3->setData(index667, "Enabled");
            }
        }
    }
    if (row == 11&& col == 1) {
        QModelIndex index0 = alarm_model3->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model3->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            QModelIndex index667 = alarm_model3->index(11, 1, QModelIndex());
            QString currentText = alarm_model3->data(index667).toString();

            if (currentText == "Enabled") {
                alarm_model3->setData(index667, "Disabled");
            } else if (currentText == "Disabled") {
                alarm_model3->setData(index667, "Enabled");
            }
        }
    }
    if (row == 12 && col == 1) {
        QModelIndex index0 = alarm_model3->index(11, col, QModelIndex());
        QStandardItem *item0 = alarm_model3->item(11, col);

        if (item0 && (item0->text() == "Enabled")) {
            VoltsValueSelection avoltvalue;
            avoltvalue.setModal(true);
            avoltvalue.exec();
            QModelIndex index669 = alarm_model3->index(12, 1, QModelIndex());
            alarm_model3->setData(index669, keyboard_text);
        }
    }
    if (row == 13 && col == 1) {
        QModelIndex index0 = alarm_model3->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model3->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            QModelIndex index667 = alarm_model3->index(13, 1, QModelIndex());
            QString currentText = alarm_model3->data(index667).toString();

            if (currentText == "Enabled") {
                alarm_model3->setData(index667, "Disabled");
            } else if (currentText == "Disabled") {
                alarm_model3->setData(index667, "Enabled");
            }
        }
    }
}


void MainWindow::onTableClicked_22(const QModelIndex &index) {
    int row = index.row();
    int col = index.column();
    QStandardItem *item = alarm_model4->item(row, col);

    if (index.row() == 0 && index.column() == 1) {
        alarm_status status;
        status.setModal(true);
        status.exec();
        QModelIndex index669 = alarm_model4->index(0, 1, QModelIndex());
        alarm_model4->setData(index669, alaram_variable);
    }

    if (row == 1 && col == 1) {
        QModelIndex index0 = alarm_model4->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model4->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            alarm_type alarmtype;
            alarmtype.setModal(true);
            alarmtype.exec();
            QModelIndex index669 = alarm_model4->index(1, 1, QModelIndex());
            alarm_model4->setData(index669, alarmtype_variable);
            if(alarmtype_variable=="Deviation"){
                ui->stackedWidget->setCurrentIndex(83);

            }
            if(alarmtype_variable=="Rate Up"){
                ui->stackedWidget->setCurrentIndex(84);

            }
            if(alarmtype_variable=="Rate Down"){
                ui->stackedWidget->setCurrentIndex(86);

            }
            if(alarmtype_variable=="High"){
                ui->stackedWidget->setCurrentIndex(85);

            }
            if(alarmtype_variable=="Low"){
                ui->stackedWidget->setCurrentIndex(87);

            }
        }
    }

    if (row == 2 && col == 1) {
        QModelIndex index0 = alarm_model4->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model4->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
        VoltsValueSelection volt_value;
        volt_value.setModal(true);
        volt_value.exec();
        QModelIndex index669 = alarm_model4->index(2, 1, QModelIndex());
        alarm_model4->setData(index669, keyboard_text);
        }
    }

    if (row == 3 && col == 1) {
        QModelIndex index0 = alarm_model4->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model4->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
        qwerty_keyboard qwerty;
        qwerty.setModal(true);
        qwerty.exec();
        QModelIndex index667 = alarm_model4->index(3, 1, QModelIndex());
        if (qwert_flag == 0) {
            alarm_model4->setData(index667, qwerty_keyboard_text);
        } else if (qwert_flag == 1) {
            alarm_model4->setData(index667, qwerty_keyboard_CAPS_text);
        }
        }
    }
    if (index.row() == 4 && index.column() == 1) {
        QModelIndex index0 = alarm_model4->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model4->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {

        QModelIndex index667 = alarm_model4->index(4, 1, QModelIndex());
        QString currentText = alarm_model4->data(index667).toString();

        if (currentText == "Enabled") {
            alarm_model4->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            alarm_model4->setData(index667, "Enabled");
        }
        }
    }
    if (index.row() == 6 && index.column() == 1) {
        QModelIndex index0 = alarm_model4->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model4->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {

        QModelIndex index667 = alarm_model4->index(6, 1, QModelIndex());
        QString currentText = alarm_model4->data(index667).toString();

        if (currentText == "Enabled") {
            alarm_model4->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            alarm_model4->setData(index667, "Enabled");
        }
        }
    }
    if (index.row() == 7 && index.column() == 1) {
        QModelIndex index0 = alarm_model4->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model4->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {

        QModelIndex index667 = alarm_model4->index(7, 1, QModelIndex());
        QString currentText = alarm_model4->data(index667).toString();

        if (currentText == "Enabled") {
            alarm_model4->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            alarm_model4->setData(index667, "Enabled");
        }
        }
    }
    if (index.row() == 8 && index.column() == 1) {
        QModelIndex index0 = alarm_model4->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model4->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {

        QModelIndex index667 = alarm_model4->index(8, 1, QModelIndex());
        QString currentText = alarm_model4->data(index667).toString();

        if (currentText == "Enabled") {
            alarm_model4->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            alarm_model4->setData(index667, "Enabled");
        }
        }
    }
    if (index.row() == 9 && index.column() == 1) {
        QModelIndex index0 = alarm_model4->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model4->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {

        QModelIndex index667 = alarm_model4->index(9, 1, QModelIndex());
        QString currentText = alarm_model4->data(index667).toString();

        if (currentText == "Enabled") {
            alarm_model4->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            alarm_model4->setData(index667, "Enabled");
        }
        }
    }
    if (index.row() == 10 && index.column() == 1) {
        QModelIndex index0 = alarm_model4->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model4->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {

        QModelIndex index667 = alarm_model4->index(10, 1, QModelIndex());
        QString currentText = alarm_model4->data(index667).toString();

        if (currentText == "Enabled") {
            alarm_model4->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            alarm_model4->setData(index667, "Enabled");
        }
        }
    }
    if (index.row() == 11 && index.column() == 1) {
        QModelIndex index0 = alarm_model4->index(10, col, QModelIndex());
        QStandardItem *item0 = alarm_model4->item(10,col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            VoltsValueSelection volt_value;
            volt_value.setModal(true);
            volt_value.exec();
            QModelIndex index669 = alarm_model4->index(11,1,QModelIndex());
            alarm_model4->setData(index669, keyboard_text);

        }
    }
    if (index.row() == 12 && index.column() == 1) {
        QModelIndex index0 = alarm_model4->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model4->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {

        QModelIndex index667 = alarm_model4->index(12,1, QModelIndex());
        QString currentText = alarm_model4->data(index667).toString();

        if (currentText == "Enabled") {
            alarm_model4->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            alarm_model4->setData(index667, "Enabled");
        }
        }
    }
    if (index.row() == 13 && index.column() == 1) {
        QModelIndex index0 = alarm_model4->index(12, col, QModelIndex());
        QStandardItem *item0 = alarm_model4->item(12,col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            VoltsValueSelection volt_value;
            volt_value.setModal(true);
            volt_value.exec();
            QModelIndex index669 = alarm_model4->index(13,1,QModelIndex());
            alarm_model4->setData(index669, keyboard_text);

        }
    }
    if (index.row() == 14 && index.column() == 1) {
        QModelIndex index0 = alarm_model4->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model4->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {

        QModelIndex index667 = alarm_model4->index(14,1, QModelIndex());
        QString currentText = alarm_model4->data(index667).toString();

        if (currentText == "Enabled") {
            alarm_model4->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            alarm_model4->setData(index667, "Enabled");
        }
        }
    }
}





void MainWindow::onTableClicked_24(const QModelIndex &index) {
    int row = index.row();
    int col = index.column();
  QStandardItem *item = alarm_model5->item(row, col);

    if (row == 0 && col == 1) {
        qDebug("Clicked sussceffull");
        alarm_status alarmstatus;
        alarmstatus.setModal(true);
        alarmstatus.exec();
         qDebug("Clicked sussceffull1");
        QModelIndex index3 = alarm_model5->index(0, 1, QModelIndex());

        alarm_model5->setData(index3, alaram_variable);
    }
    if (row == 1 && col == 1) {
        QModelIndex index0 = alarm_model5->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model5->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            alarm_type atype;
            atype.setModal(true);
            atype.exec();
            QModelIndex index669 = alarm_model5->index(1, 1, QModelIndex());
            alarm_model5->setData(index669, alarmtype_variable);

            if (alarmtype_variable == "Deviation") {
                ui->stackedWidget->setCurrentIndex(83);
            } else if (alarmtype_variable == "Rate Up") {
                ui->stackedWidget->setCurrentIndex(84);
            } else if (alarmtype_variable == "Rate Down") {
                ui->stackedWidget->setCurrentIndex(86);
            } else if (alarmtype_variable == "High") {
                ui->stackedWidget->setCurrentIndex(85);
            } else if (alarmtype_variable == "Low") {
                ui->stackedWidget->setCurrentIndex(87);
            }
        }
    }
    if (row == 2 && col == 1) {
        QModelIndex index0 = alarm_model5->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model5->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            VoltsValueSelection avoltvalue;
            avoltvalue.setModal(true);
            avoltvalue.exec();
            QModelIndex index669 = alarm_model5->index(2, 1, QModelIndex());
            alarm_model5->setData(index669, keyboard_text);
        }
    }
    if (row == 3 && col == 1) {
        QModelIndex index0 = alarm_model5->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model5->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            VoltsValueSelection avoltvalue;
            avoltvalue.setModal(true);
            avoltvalue.exec();
            QModelIndex index669 = alarm_model5->index(3, 1, QModelIndex());
            alarm_model5->setData(index669, keyboard_text);
        }
    }
    if (row == 4 && col == 1) {
        QModelIndex index0 = alarm_model5->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model5->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            qwerty_keyboard aqwerty;
            aqwerty.setModal(true);
            aqwerty.exec();
            QModelIndex index667 = alarm_model5->index(4, 1, QModelIndex());

            if (qwert_flag == 0) {
                alarm_model5->setData(index667, qwerty_keyboard_text);
            } else if (qwert_flag == 1) {
                alarm_model5->setData(index667, qwerty_keyboard_CAPS_text);
            }
        }
    }

    if (row == 5 && col == 1) {
        QModelIndex index0 = alarm_model5->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model5->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            QModelIndex index667 = alarm_model5->index(5, 1, QModelIndex());
            QString currentText = alarm_model5->data(index667).toString();

            if (currentText == "Enabled") {
                alarm_model5->setData(index667, "Disabled");
            } else if (currentText == "Disabled") {
                alarm_model5->setData(index667, "Enabled");
            }
        }
    }
    if (row == 6 && col == 1) {
        QModelIndex index0 = alarm_model5->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model5->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            QModelIndex index667 = alarm_model5->index(6, 1, QModelIndex());
            QString currentText = alarm_model5->data(index667).toString();

            if (currentText == "Enabled") {
                alarm_model5->setData(index667, "Disabled");
            } else if (currentText == "Disabled") {
                alarm_model5->setData(index667, "Enabled");
            }
        }
    }
    if (row == 7 && col == 1) {
        QModelIndex index0 = alarm_model5->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model5->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            QModelIndex index667 = alarm_model5->index(7, 1, QModelIndex());
            QString currentText = alarm_model5->data(index667).toString();

            if (currentText == "Enabled") {
                alarm_model5->setData(index667, "Disabled");
            } else if (currentText == "Disabled") {
                alarm_model5->setData(index667, "Enabled");
            }
        }
    }
    if (row == 8 && col == 1) {
        QModelIndex index0 = alarm_model5->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model5->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            QModelIndex index667 = alarm_model5->index(8, 1, QModelIndex());
            QString currentText = alarm_model5->data(index667).toString();

            if (currentText == "Enabled") {
                alarm_model5->setData(index667, "Disabled");
            } else if (currentText == "Disabled") {
                alarm_model5->setData(index667, "Enabled");
            }
        }
    }
    if (row == 9 && col == 1) {
        QModelIndex index0 = alarm_model5->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model5->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            QModelIndex index667 = alarm_model5->index(9, 1, QModelIndex());
            QString currentText = alarm_model5->data(index667).toString();

            if (currentText == "Enabled") {
                alarm_model5->setData(index667, "Disabled");
            } else if (currentText == "Disabled") {
                alarm_model5->setData(index667, "Enabled");
            }
        }
    }
    if (row == 10 && col == 1) {
        QModelIndex index0 = alarm_model5->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model5->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            QModelIndex index667 = alarm_model5->index(10, 1, QModelIndex());
            QString currentText = alarm_model5->data(index667).toString();

            if (currentText == "Enabled") {
                alarm_model5->setData(index667, "Disabled");
            } else if (currentText == "Disabled") {
                alarm_model5->setData(index667, "Enabled");
            }
        }
    }
    if (row == 11&& col == 1) {
        QModelIndex index0 = alarm_model5->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model5->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            QModelIndex index667 = alarm_model5->index(11, 1, QModelIndex());
            QString currentText = alarm_model5->data(index667).toString();

            if (currentText == "Enabled") {
                alarm_model5->setData(index667, "Disabled");
            } else if (currentText == "Disabled") {
                alarm_model5->setData(index667, "Enabled");
            }
        }
    }
    if (row == 12 && col == 1) {
        QModelIndex index0 = alarm_model5->index(11, col, QModelIndex());
        QStandardItem *item0 = alarm_model5->item(11, col);

        if (item0 && (item0->text() == "Enabled")) {
            VoltsValueSelection avoltvalue;
            avoltvalue.setModal(true);
            avoltvalue.exec();
            QModelIndex index669 = alarm_model5->index(12, 1, QModelIndex());
            alarm_model5->setData(index669, keyboard_text);
        }
    }
    if (row == 13 && col == 1) {
        QModelIndex index0 = alarm_model5->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model5->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            QModelIndex index667 = alarm_model5->index(13, 1, QModelIndex());
            QString currentText = alarm_model5->data(index667).toString();

            if (currentText == "Enabled") {
                alarm_model5->setData(index667, "Disabled");
            } else if (currentText == "Disabled") {
                alarm_model5->setData(index667, "Enabled");
            }
        }
    }
}




void MainWindow::onTableClicked_25(const QModelIndex &index) {
    int row = index.row();
    int col = index.column();
    QStandardItem *item = alarm_model6->item(row, col);

    if (index.row() == 0 && index.column() == 1) {
        alarm_status status;
        status.setModal(true);
        status.exec();
        QModelIndex index669 = alarm_model6->index(0, 1, QModelIndex());
        alarm_model6->setData(index669, alaram_variable);
    }

    if (row == 1 && col == 1) {
        QModelIndex index0 = alarm_model6->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model6->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            alarm_type alarmtype;
            alarmtype.setModal(true);
            alarmtype.exec();
            QModelIndex index669 = alarm_model6->index(1, 1, QModelIndex());
            alarm_model6->setData(index669, alarmtype_variable);
            if(alarmtype_variable=="Deviation"){
                ui->stackedWidget->setCurrentIndex(83);

            }
            if(alarmtype_variable=="Rate Up"){
                ui->stackedWidget->setCurrentIndex(84);

            }
            if(alarmtype_variable=="Rate Down"){
                ui->stackedWidget->setCurrentIndex(86);

            }
            if(alarmtype_variable=="High"){
                ui->stackedWidget->setCurrentIndex(85);

            }
            if(alarmtype_variable=="Low"){
                ui->stackedWidget->setCurrentIndex(87);

            }
        }
    }

    if (row == 2 && col == 1) {
        QModelIndex index0 = alarm_model6->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model6->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
        VoltsValueSelection volt_value;
        volt_value.setModal(true);
        volt_value.exec();
        QModelIndex index669 = alarm_model6->index(2, 1, QModelIndex());
        alarm_model6->setData(index669, keyboard_text);
        }
    }

    if (row == 3 && col == 1) {
        QModelIndex index0 = alarm_model6->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model6->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
        qwerty_keyboard qwerty;
        qwerty.setModal(true);
        qwerty.exec();
        QModelIndex index667 = alarm_model6->index(3, 1, QModelIndex());
        if (qwert_flag == 0) {
            alarm_model6->setData(index667, qwerty_keyboard_text);
        } else if (qwert_flag == 1) {
            alarm_model6->setData(index667, qwerty_keyboard_CAPS_text);
        }
        }
    }
    if (index.row() == 4 && index.column() == 1) {
        QModelIndex index0 = alarm_model6->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model6->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {

        QModelIndex index667 = alarm_model6->index(4, 1, QModelIndex());
        QString currentText = alarm_model6->data(index667).toString();

        if (currentText == "Enabled") {
            alarm_model6->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            alarm_model6->setData(index667, "Enabled");
        }
        }
    }
    if (index.row() == 6 && index.column() == 1) {
        QModelIndex index0 = alarm_model6->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model6->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {

        QModelIndex index667 = alarm_model6->index(6, 1, QModelIndex());
        QString currentText = alarm_model6->data(index667).toString();

        if (currentText == "Enabled") {
            alarm_model6->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            alarm_model6->setData(index667, "Enabled");
        }
        }
    }
    if (index.row() == 7 && index.column() == 1) {
        QModelIndex index0 = alarm_model6->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model6->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {

        QModelIndex index667 = alarm_model6->index(7, 1, QModelIndex());
        QString currentText = alarm_model6->data(index667).toString();

        if (currentText == "Enabled") {
            alarm_model6->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            alarm_model6->setData(index667, "Enabled");
        }
        }
    }
    if (index.row() == 8 && index.column() == 1) {
        QModelIndex index0 = alarm_model6->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model6->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {

        QModelIndex index667 = alarm_model6->index(8, 1, QModelIndex());
        QString currentText = alarm_model6->data(index667).toString();

        if (currentText == "Enabled") {
            alarm_model6->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            alarm_model6->setData(index667, "Enabled");
        }
        }
    }
    if (index.row() == 9 && index.column() == 1) {
        QModelIndex index0 = alarm_model6->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model6->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {

        QModelIndex index667 = alarm_model6->index(9, 1, QModelIndex());
        QString currentText = alarm_model6->data(index667).toString();

        if (currentText == "Enabled") {
            alarm_model6->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            alarm_model6->setData(index667, "Enabled");
        }
        }
    }
    if (index.row() == 10 && index.column() == 1) {
        QModelIndex index0 = alarm_model6->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model6->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {

        QModelIndex index667 = alarm_model6->index(10, 1, QModelIndex());
        QString currentText = alarm_model6->data(index667).toString();

        if (currentText == "Enabled") {
            alarm_model6->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            alarm_model6->setData(index667, "Enabled");
        }
        }
    }
    if (index.row() == 11 && index.column() == 1) {
        QModelIndex index0 = alarm_model6->index(10, col, QModelIndex());
        QStandardItem *item0 = alarm_model6->item(10,col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            VoltsValueSelection volt_value;
            volt_value.setModal(true);
            volt_value.exec();
            QModelIndex index669 = alarm_model6->index(11,1,QModelIndex());
            alarm_model6->setData(index669, keyboard_text);

        }
    }
    if (index.row() == 12 && index.column() == 1) {
        QModelIndex index0 = alarm_model6->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model6->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {

        QModelIndex index667 = alarm_model6->index(12,1, QModelIndex());
        QString currentText = alarm_model6->data(index667).toString();

        if (currentText == "Enabled") {
            alarm_model6->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            alarm_model6->setData(index667, "Enabled");
        }
        }
    }
    if (index.row() == 13 && index.column() == 1) {
        QModelIndex index0 = alarm_model6->index(12, col, QModelIndex());
        QStandardItem *item0 = alarm_model6->item(12,col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            VoltsValueSelection volt_value;
            volt_value.setModal(true);
            volt_value.exec();
            QModelIndex index669 = alarm_model6->index(13,1,QModelIndex());
            alarm_model6->setData(index669, keyboard_text);

        }
    }
    if (index.row() == 14 && index.column() == 1) {
        QModelIndex index0 = alarm_model6->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model6->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {

        QModelIndex index667 = alarm_model6->index(14,1, QModelIndex());
        QString currentText = alarm_model6->data(index667).toString();

        if (currentText == "Enabled") {
            alarm_model6->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            alarm_model6->setData(index667, "Enabled");
        }
        }
    }
}




void MainWindow::onTableClicked_26(const QModelIndex &index) {
    int row = index.row();
    int col = index.column();
    QStandardItem *item = alarm_model7->item(row, col);

    if (index.row() == 0 && index.column() == 1) {
        alarm_status status;
        status.setModal(true);
        status.exec();
        QModelIndex index669 =alarm_model7->index(0, 1, QModelIndex());
        alarm_model7->setData(index669, alaram_variable);
    }

    if (row == 2 && col == 1) {
        QModelIndex index0 = alarm_model7->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model7->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            alarm_type alarmtype;
            alarmtype.setModal(true);
            alarmtype.exec();
            QModelIndex index669 = alarm_model7->index(2, 1, QModelIndex());
            alarm_model7->setData(index669, alarmtype_variable);
            if(alarmtype_variable=="Deviation"){
                ui->stackedWidget->setCurrentIndex(83);

            }
            if(alarmtype_variable=="Rate Up"){
                ui->stackedWidget->setCurrentIndex(84);

            }
            if(alarmtype_variable=="Rate Down"){
                ui->stackedWidget->setCurrentIndex(86);

            }
            if(alarmtype_variable=="High"){
                ui->stackedWidget->setCurrentIndex(84);

            }
            if(alarmtype_variable=="Low"){
                ui->stackedWidget->setCurrentIndex(87);

            }
        }
    }

    if (row == 3 && col == 1) {
        QModelIndex index0 = alarm_model7->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model7->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
        VoltsValueSelection volt_value;
        volt_value.setModal(true);
        volt_value.exec();
        QModelIndex index669 = alarm_model7->index(3, 1, QModelIndex());
        alarm_model7->setData(index669, keyboard_text);
        }
    }

    if (row == 4 && col == 1) {
        QModelIndex index0 = alarm_model7->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model7->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
        qwerty_keyboard qwerty;
        qwerty.setModal(true);
        qwerty.exec();
        QModelIndex index667 = alarm_model7->index(4, 1, QModelIndex());
        if (qwert_flag == 0) {
            alarm_model7->setData(index667, qwerty_keyboard_text);
        } else if (qwert_flag == 1) {
            alarm_model7->setData(index667, qwerty_keyboard_CAPS_text);
        }
        }
    }
    if (index.row() == 5 && index.column() == 1) {
        QModelIndex index0 = alarm_model7->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model7->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {

        QModelIndex index667 = alarm_model7->index(5, 1, QModelIndex());
        QString currentText = alarm_model7->data(index667).toString();

        if (currentText == "Enabled") {
            alarm_model7->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            alarm_model7->setData(index667, "Enabled");
        }
        }
    }
    if (index.row() == 7 && index.column() == 1) {
        QModelIndex index0 = alarm_model7->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model7->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {

        QModelIndex index667 = alarm_model7->index(7, 1, QModelIndex());
        QString currentText = alarm_model7->data(index667).toString();

        if (currentText == "Enabled") {
            alarm_model7->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            alarm_model7->setData(index667, "Enabled");
        }
        }
    }
    if (index.row() == 8 && index.column() == 1) {
        QModelIndex index0 = alarm_model7->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model7->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {

        QModelIndex index667 = alarm_model7->index(8, 1, QModelIndex());
        QString currentText = alarm_model7->data(index667).toString();

        if (currentText == "Enabled") {
            alarm_model7->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            alarm_model7->setData(index667, "Enabled");
        }
        }
    }
    if (index.row() == 9 && index.column() == 1) {
        QModelIndex index0 = alarm_model7->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model7->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {

        QModelIndex index667 = alarm_model7->index(9, 1, QModelIndex());
        QString currentText = alarm_model7->data(index667).toString();

        if (currentText == "Enabled") {
            alarm_model7->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            alarm_model7->setData(index667, "Enabled");
        }
        }
    }
    if (index.row() == 10&& index.column() == 1) {
        QModelIndex index0 = alarm_model7->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model7->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {

        QModelIndex index667 = alarm_model7->index(10, 1, QModelIndex());
        QString currentText = alarm_model7->data(index667).toString();

        if (currentText == "Enabled") {
            alarm_model7->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            alarm_model7->setData(index667, "Enabled");
        }
        }
    }
    if (index.row() == 11 && index.column() == 1) {
        QModelIndex index0 = alarm_model7->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model7->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {

        QModelIndex index667 = alarm_model7->index(11, 1, QModelIndex());
        QString currentText = alarm_model7->data(index667).toString();

        if (currentText == "Enabled") {
            alarm_model7->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            alarm_model7->setData(index667, "Enabled");
        }
        }
    }
    if (index.row() == 12 && index.column() == 1) {
        QModelIndex index0 = alarm_model7->index(10, col, QModelIndex());
        QStandardItem *item0 = alarm_model7->item(10,col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            VoltsValueSelection volt_value;
            volt_value.setModal(true);
            volt_value.exec();
            QModelIndex index669 = alarm_model7->index(12,1,QModelIndex());
            alarm_model7->setData(index669, keyboard_text);

        }
    }
    if (index.row() == 13 && index.column() == 1) {
        QModelIndex index0 = alarm_model7->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model7->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {

        QModelIndex index667 = alarm_model7->index(13,1, QModelIndex());
        QString currentText = alarm_model7->data(index667).toString();

        if (currentText == "Enabled") {
            alarm_model7->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            alarm_model7->setData(index667, "Enabled");
        }
        }
    }
    if (index.row() == 14 && index.column() == 1) {
        QModelIndex index0 = alarm_model7->index(12, col, QModelIndex());
        QStandardItem *item0 = alarm_model7->item(12,col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {
            VoltsValueSelection volt_value;
            volt_value.setModal(true);
            volt_value.exec();
            QModelIndex index669 = alarm_model7->index(14,1,QModelIndex());
            alarm_model7->setData(index669, keyboard_text);

        }
    }
    if (index.row() == 15 && index.column() == 1) {
        QModelIndex index0 = alarm_model7->index(0, col, QModelIndex());
        QStandardItem *item0 = alarm_model7->item(0, col);

        if (item0 && (item0->text() == "Enabled Always" || item0->text() == "Dig Enabled")) {

        QModelIndex index667 = alarm_model7->index(15,1, QModelIndex());
        QString currentText = alarm_model7->data(index667).toString();

        if (currentText == "Enabled") {
            alarm_model7->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            alarm_model7->setData(index667, "Enabled");
        }
        }
    }
}





void MainWindow::onTableClicked_27(const QModelIndex &index) {
    int row = index.row();
    int col = index.column();
    QStandardItem *item = screen_model->item(row, col);
    if (index.row() == 0 && index.column() == 1) {
            QModelIndex index667 = screen_model->index(0,1, QModelIndex());
            QString currentText = screen_model->data(index667).toString();

            if (currentText == "Enabled") {
                screen_model->setData(index667, "Disabled");
            } else if (currentText == "Disabled") {
                screen_model->setData(index667, "Enabled");
            }
            }

    if (index.row() == 1 && index.column() == 1) {
        QModelIndex index0 = screen_model->index(0, col, QModelIndex());
        QStandardItem *item0 = screen_model->item(0, col);

        if (item0 && (item0->text() == "Enabled")) {
       VoltsValueSelection valselect;
       valselect.setModal(true);
       valselect.exec();
       QModelIndex index669 = screen_model->index(1, 1, QModelIndex());
       screen_model->setData(index669, keyboard_text+" "+"Mins");
        }
    }

    if (index.row() == 4 && index.column() == 1) {
        QModelIndex index0 = screen_model->index(0, col, QModelIndex());
        QStandardItem *item0 = screen_model->item(0, col);

        if (item0 && (item0->text() == "Enabled")) {
            Dim_saver saver;
            saver.setModal(true);
            saver.exec();
            QModelIndex index669 = screen_model->index(4, 1, QModelIndex());
            screen_model->setData(index669, saver_dim);

        }
    }
    if (index.row() == 5 && index.column() == 1) {
        QModelIndex index0 = screen_model->index(4, col, QModelIndex());
        QStandardItem *item0 = screen_model->item(4, col);

        if (item0 && (item0->text() == "Use Saver Brightness")) {
            saver_level saverlevel;
            saverlevel.setModal(true);
            saverlevel.exec();
//            QModelIndex index669 = screen_model->index(4, 1, QModelIndex());
//            screen_model->setData(index669, saver_dim);

        }
    }
 }





void MainWindow::onTableClicked_28(const QModelIndex &index) {
    int row = index.row();
    int col = index.column();
    QStandardItem *item = chart_model->item(row, col);
    if (index.row() == 0 && index.column() == 1) {
        strip_fast fast;
        fast.setModal(true);
        fast.exec();
        QModelIndex index669 = chart_model->index(0, 1, QModelIndex());
        chart_model->setData(index669, stripfastvariable);
    }
    if (index.row() == 1 && index.column() == 1) {
        strip_med med;
        med.setModal(true);
        med.exec();
        QModelIndex index669 = chart_model->index(1, 1, QModelIndex());
        chart_model->setData(index669, stripmedvariable);
    }
    if (index.row() == 2 && index.column() == 1) {
        strip_slow slow;
        slow.setModal(true);
        slow.exec();
        QModelIndex index669 = chart_model->index(2, 1, QModelIndex());
        chart_model->setData(index669, stripslowvariable);
    }
    if (index.row() == 3 && index.column() == 1) {
        circ_fast circf;
        circf.setModal(true);
        circf.exec();
        QModelIndex index669 = chart_model->index(3, 1, QModelIndex());
        chart_model->setData(index669, circfastvariable);
    }
    if (index.row() == 4 && index.column() == 1) {
        circ_med circm;
        circm.setModal(true);
        circm.exec();
        QModelIndex index669 = chart_model->index(4, 1, QModelIndex());
        chart_model->setData(index669, circmedvariable);
    }
    if (index.row() == 5 && index.column() == 1) {
        circ_slow circs;
        circs.setModal(true);
        circs.exec();
        QModelIndex index669 = chart_model->index(5, 1, QModelIndex());
        chart_model->setData(index669, circslowvariable);
    }
    if (index.row() == 6 && index.column() == 1) {
        VoltsValueSelection voltval;
        voltval.setModal(true);
        voltval.exec();
        QModelIndex index666 = chart_model->index(6,1,QModelIndex());
        chart_model->setData(index666,keyboard_text);
    }
    if (index.row() == 7 && index.column() == 1) {
        day_align align;
        align.setModal(true);
        align.exec();
        QModelIndex index666 = chart_model->index(7,1,QModelIndex());
        chart_model->setData(index666,dayalignvariable);
    }

}





void MainWindow::onTableClicked_29(const QModelIndex &index) {
    int row = index.row();
    int col = index.column();
    QStandardItem *item = tabdisplay_model->item(row, col);

    if (row == 0 && col == 1) {
        update_method update;
        update.setModal(true);
        update.exec();
        QModelIndex index = tabdisplay_model->index(0, 1, QModelIndex());
        tabdisplay_model->setData(index, update_value);
    }
    // Check if update_value is "Periodic" before allowing row 1 and row 2 to be clickable
    else if (update_value == "Periodic") {
        if (row == 1 && col == 1) {
            VoltsValueSelection ValueSelection;
            ValueSelection.setModal(true);
            ValueSelection.exec();
            QModelIndex index666 = tabdisplay_model->index(1, 1, QModelIndex());
            tabdisplay_model->setData(index666, keyboard_text+" "+"Secs");
        }

        if (row == 2 && col == 1) {
            QModelIndex cellIndex = tabdisplay_model->index(2, 1, QModelIndex());
            QString currentText = tabdisplay_model->data(cellIndex, Qt::DisplayRole).toString();

            // Toggle the text from "Enabled" to "Disabled" and vice versa
            if (currentText == "Enabled") {
                tabdisplay_model->setData(cellIndex, "Disabled", Qt::DisplayRole);
            } else if (currentText == "Disabled") {
                tabdisplay_model->setData(cellIndex, "Enabled", Qt::DisplayRole);
            }
        }
    }
}


void MainWindow::onTableClicked_30(const QModelIndex &index) {
    int row = index.row();
    int col = index.column();
    QStandardItem *item = localization_model->item(row, col);

    if (row == 0 && col == 1) {
        Language lang;
        lang.setModal(true);
        lang.exec();
        QModelIndex index134 = localization_model->index(0, 1, QModelIndex());
        localization_model->setData(index134, default_language);
    }
    if (row == 2 && col == 1) {
        Time_zone zone;
        zone.setModal(true);
        zone.exec();
        QModelIndex index154 = localization_model->index(2, 1, QModelIndex());
        localization_model->setData(index154, zonal_time);
    }
    if (row == 3 && col == 1) {
            QModelIndex indexToToggle = localization_model->index(3, 1, QModelIndex());
            QString currentText = indexToToggle.data(Qt::DisplayRole).toString();

            if (currentText == "Enabled") {
                localization_model->setData(indexToToggle, "Disabled");
            } else if (currentText == "Disabled") {
                localization_model->setData(indexToToggle, "Enabled");
            }
        }
    if (row == 4 && col == 1) {
        temp_unit unit_temp;
        unit_temp.setModal(true);
        unit_temp.exec();
        QModelIndex index154 = localization_model->index(4, 1, QModelIndex());
        localization_model->setData(index154, temperature_unit);
    }
    if (row == 5 && col == 1) {
        Hertz hertz;
        hertz.setModal(true);
        hertz.exec();
        QModelIndex index154 = localization_model->index(5, 1, QModelIndex());
        localization_model->setData(index154, hertz_value);
    }
    if (row == 6 && col == 1) {
            QModelIndex indexToToggle = localization_model->index(6, 1, QModelIndex());
            QString currentText = indexToToggle.data(Qt::DisplayRole).toString();

            if (currentText == "Letter") {
                localization_model->setData(indexToToggle, "A4");
            } else if (currentText == "A4") {
                localization_model->setData(indexToToggle, "Letter");
            }
        }
}





void MainWindow::onTableClicked_31(const QModelIndex &index) {
    if (index.isValid()) {
           int row = index.row();
           int col = index.column();

           // Assuming the data in column 0 is the item name
           QString itemName =credit_model->data(credit_model->index(row, 0)).toString();

           // Check if the clicked row is row 2 (row8Data)
           if (row == 2 && col ==1) {
               // Open a new table or perform actions specific to "New Data 3"
               // Here, we'll simply print a message
               qDebug() << "Opening a new table for: " << itemName;

               // Create a new table and show it
               VoltsValueSelection  voltsTable;
               voltsTable.exec();
               QModelIndex index666 = credit_model->index(2, 1, QModelIndex());
               credit_model->setData(index666, keyboard_text+" "+"Secs");
           }
       }
}



void MainWindow::onTableClicked_32(const QModelIndex &index) {
    int row = index.row();
    int col = index.column();
    QStandardItem *item = sntp_model->item(row, col);

    // Toggle "Disabled" and "Enabled" for row 1 (Server Enable)
    if (row == 0 && col == 1) {
        QString currentValue = item->text();
        if (currentValue == "Disabled")
            sntp_model->setData(index, "Enabled");
        else
            sntp_model->setData(index, "Disabled");
    }

    // Toggle "Disabled" and "Enabled" for row 2 (Client Enable)
    if (row == 1 && col == 1) {
        QString currentValue = item->text();
        if (currentValue == "Disabled") {
            sntp_model->setData(index, "Enabled");
            // Disable rows 3, 4, and 5
            sntp_model->item(2, 1)->setFlags(Qt::ItemIsEnabled);
            sntp_model->item(3, 1)->setFlags(Qt::ItemIsEnabled);
            sntp_model->item(4, 1)->setFlags(Qt::ItemIsEnabled);
        } else {
            sntp_model->setData(index, "Disabled");
            // Enable rows 3, 4, and 5
            sntp_model->item(2, 1)->setFlags(Qt::NoItemFlags);
            sntp_model->item(3, 1)->setFlags(Qt::NoItemFlags);
            sntp_model->item(4, 1)->setFlags(Qt::NoItemFlags);
        }
    }

    if(row==2 && col == 1)
    {
        if (sntp_model->item(1, 1)->text() == "Enabled") {
            qwerty_keyboard qwerty_keyboard;
            qwerty_keyboard.setModal(true);
            qwerty_keyboard.exec();
            QModelIndex index667 = sntp_model->index(2,1,QModelIndex());
            if(qwert_flag==0)
            {
                sntp_model->setData(index667,qwerty_keyboard_text);
            }
            else if(qwert_flag==1)
            {
                sntp_model->setData(index667,qwerty_keyboard_CAPS_text);
            }
        }
    }

    if(row==3 && col == 1)
    {
        if (sntp_model->item(1, 1)->text() == "Enabled") {
            VoltsValueSelection VoltsValueSelection;
            VoltsValueSelection.setModal(true);
            VoltsValueSelection.exec();
            QModelIndex index666 = sntp_model->index(3,1,QModelIndex());
            sntp_model->setData(index666,keyboard_text);
        }
    }

    if(row==4 && col == 1)
    {
            VoltsValueSelection VoltsValueSelection;
            VoltsValueSelection.setModal(true);
            VoltsValueSelection.exec();
            QModelIndex index666 = sntp_model->index(4,1,QModelIndex());
            sntp_model->setData(index666,keyboard_text);
        }
    }





void MainWindow::onTableClicked_33(const QModelIndex &index) {
    QStandardItem *firstRowItem = policy_model->item(0, 1);  // Get the item in the first row, second column
    bool isFirstRowEnabled = firstRowItem->data(Qt::UserRole).toBool();

    if (index.row() == 0 && index.column() == 1) {
        // Toggle the state of the first row
        isFirstRowEnabled = !isFirstRowEnabled;
        firstRowItem->setData(isFirstRowEnabled, Qt::UserRole);
        firstRowItem->setText(isFirstRowEnabled ? "Enabled" : "Disabled");

        // Update the rest of the rows based on the state of row 0
        for (int i = 1; i < policy_model->rowCount(); i++) {
            QModelIndex rowItem = policy_model->index(i, 1, QModelIndex());
            policy_model->setData(rowItem, isFirstRowEnabled, Qt::UserRole);
        }
    } else if (isFirstRowEnabled) {
        // Check if row 1 is clicked, and open the qwerty_keyboard dialog
        if (index.row() == 1) {
            qwerty_keyboard keyboard;
            keyboard.setModal(true);
            keyboard.exec();
            QModelIndex index667 = policy_model->index(1, 1, QModelIndex());
            if (qwert_flag == 0) {
                policy_model->setData(index667, qwerty_keyboard_text);
            } else if (qwert_flag == 1) {
                policy_model->setData(index667, qwerty_keyboard_CAPS_text);
            }
        }
    }
}




static int clickCount = 0; // Counter to keep track of clicks
QString userEnteredValue; // Variable to store user input
void MainWindow::onTableClicked_34(const QModelIndex &index) {
    int row = index.row();
    int col = index.column();
    qDebug() << "Clicked item: Row " << row << ", Column " << col;

    // Check if the first row in model17 is enabled
    QModelIndex index17 = policy_model->index(0, 1, QModelIndex());
    bool isFirstRowEnabled = policy_model->data(index17, Qt::UserRole).toBool();
    int rowIndex = user_model->rowCount(); // Get the current number of rows

    if (isFirstRowEnabled) {
        // Check the click count
        if (clickCount % 2 == 0) {
            // Perform the existing mechanism for even click counts
            if ((row == (rowIndex - 1) && col == 1) || (row == 0 && col == 1)) {
                // If the cell is enabled, open the qwerty_keyboard dialog
                qwerty_keyboard qwerty;
                qwerty.setModal(true);
                qwerty.exec();

                QModelIndex index668 = user_model->index((rowIndex - 1), 1, QModelIndex());
                if (qwert_flag == 0) {
                    userEnteredValue = qwerty_keyboard_text + user_designation;
                    user_model->setData(index668, userEnteredValue);

                    // Assign userEnteredValue to user_name innewuser_model
                    QModelIndex index19 =newuser_model->index(0, 1, QModelIndex());
                   newuser_model->setData(index19, userEnteredValue);
                } else if (qwert_flag == 1) {
                    userEnteredValue = qwerty_keyboard_CAPS_text + user_designation;
                    user_model->setData(index668, userEnteredValue);

                    // Assign userEnteredValue to user_name innewuser_model
                    QModelIndex index19 =newuser_model->index(0, 1, QModelIndex());
                   newuser_model->setData(index19, userEnteredValue);

                    if (user_designation =="Administrator"){
                    QModelIndex Index = model14->index(2, 1, QModelIndex());
                    model14->setData(Index,"10 Minutes");


                    }
                }
            }

            // Add a new row to user_model
            user_model->insertRow(rowIndex);

            // Set default data for the newly added row
            QStringList rowData_1 = {"Add New User", "<Your Data Here>"};
            for (int col = 0; col < 2; ++col) {
                QModelIndex targetIndex = user_model->index(rowIndex, col, QModelIndex());
                user_model->setData(targetIndex, rowData_1[col]);
            }
        } else {
            // For odd click counts, set the current index to 39
            ui->stackedWidget->setCurrentIndex(185);
        }

        // Increment the click count for the next click
        clickCount++;
    } else {
        qDebug() << "First row in model17 is not enabled, user_model is not clickable.";
    }
}



void MainWindow::onTableClicked_35(const QModelIndex &index) {
    int row = index.row();
    int col = index.column();
    QStandardItem *item = newuser_model->item(row, col);

    if (row == 1 && col == 1) {
        user_level userlevel;
        userlevel.setModal(true);
        userlevel.exec();
        QModelIndex index666 = newuser_model->index(1, 1, QModelIndex());

        // Store the original value of user_designation
        QString originalUserDesignation = user_designation;

        // Update the model
        newuser_model->setData(index666, user_designation);

        // Log and compare the original and updated values
        qDebug() << "Original user_designation = " << originalUserDesignation;
        qDebug() << "Updated user_designation = " << user_designation;


        user_designation = originalUserDesignation;


    }
}




void MainWindow::onTableClicked_36(const QModelIndex &index) {
    qwerty_keyboard qwerty;
    qwerty.setModal(true);
    qwerty.exec();

    if (qwerty.result() == QDialog::Accepted) {
        int row = index.row();
        int col = 1;

        qDebug() << "Table clicked! Row:" << row << "Column:" << col;

        QString newText = (qwert_flag == 0) ? qwerty_keyboard_text : qwerty_keyboard_CAPS_text;

        QModelIndex updatedIndex = marker_model->index(row, col, QModelIndex());
        marker_model->setData(updatedIndex, newText);

        ui->tableView_25->viewport()->update();
    }
}




void MainWindow::onTableClicked_37(const QModelIndex &index) {
    int row = index.row();
    int col = index.column();
    QStandardItem *item = timesync_model->item(row, col);

    if (row == 0 && col == 1) {
        QModelIndex index667 = timesync_model->index(0, 1, QModelIndex());
        QString currentText = timesync_model->data(index667).toString();

        if (currentText == "Enabled") {
            timesync_model->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            timesync_model->setData(index667, "Enabled");
        }
    } else if (row == 1 && col == 1) {
        QModelIndex index01 = timesync_model->index(0, 1, QModelIndex());
        QString status01 = timesync_model->data(index01).toString();

        if (status01 == "Enabled") {
            // Toggle the text between "ON" and "OFF"
            QModelIndex index11 = timesync_model->index(1, 1, QModelIndex());
            QString currentText11 = timesync_model->data(index11).toString();

            if (currentText11 == "ON") {
                timesync_model->setData(index11, "OFF");
            } else if (currentText11 == "OFF") {
                timesync_model->setData(index11, "ON");
            }
        }
    }
}


void MainWindow::onTableClicked_38(const QModelIndex &index) {
    if (index.isValid()) {
        ui->stackedWidget->setCurrentIndex(203);
        }
}

void MainWindow::onTableClicked_39(const QModelIndex &index) {
    if (index.isValid()) {
        ui->stackedWidget->setCurrentIndex(206);
        }
}



void MainWindow::onTableClicked_40(const QModelIndex &index) {
    int row = index.row();
    int col = index.column();
    //QStandardItem *item = peers_model->item(row, col);

    if (row == 0 && col == 1) {
        QModelIndex index667 = peers_model->index(0, 1, QModelIndex());
        QString currentText = peers_model->data(index667).toString();

        if (currentText == "Enabled") {
            peers_model->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            peers_model->setData(index667, "Enabled");
        }
    } else if (row == 1 && col == 1) {
        Peers_setnumber peer;
        peer.setModal(true);
        peer.exec();
        QModelIndex index666 = peers_model->index(1, 1, QModelIndex());
        peers_model->setData(index666, peer_value);
    } else if (row == 2 && col == 1) {
        QModelIndex index001 = peers_model->index(0, 1, QModelIndex());
        QString textEnabled = peers_model->data(index001).toString();

        if (textEnabled == "Enabled") {
            VoltsValueSelection voltvalue;
            voltvalue.setModal(true);
            voltvalue.exec();
            QModelIndex index668 = peers_model->index(2, 1, QModelIndex());
            peers_model->setData(index668, keyboard_text);
        }

    }
}


void MainWindow::onTableClicked_41(const QModelIndex &index) {
    int row = index.row();
    int col = index.column();

    if (row == 0 && col == 1) {
        QModelIndex index667 = web_model->index(0, 1, QModelIndex());
        QString currentText = web_model->data(index667).toString();

        if (currentText == "Enabled") {
            web_model->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            web_model->setData(index667, "Enabled");
        }
    }
}



void MainWindow::onTableClicked_42(const QModelIndex &index) {
    int row = index.row();
    int col = index.column();

    if (index.row() == 0 && index.column() == 1) {
        qwerty_keyboard keyboard;
        keyboard.setModal(true);
        keyboard.exec();
        QModelIndex index667 = network_model->index(0, 1, QModelIndex());
        if (qwert_flag == 0) {
            network_model->setData(index667, qwerty_keyboard_text);
        } else if (qwert_flag == 1) {
            network_model->setData(index667, qwerty_keyboard_CAPS_text);
        }
    }else if (row ==1 && col ==1){
        qwerty_keyboard keyboard;
        keyboard.setModal(true);
        keyboard.exec();
        QModelIndex index667 = network_model->index(1, 1, QModelIndex());
        if (qwert_flag == 0) {
            network_model->setData(index667, qwerty_keyboard_text);
        } else if (qwert_flag == 1) {
            network_model->setData(index667, qwerty_keyboard_CAPS_text);
        }
    }else if (row ==2 && col ==1){
        qwerty_keyboard keyboard;
        keyboard.setModal(true);
        keyboard.exec();
        QModelIndex index667 = network_model->index(2, 1, QModelIndex());
        if (qwert_flag == 0) {
            network_model->setData(index667, qwerty_keyboard_text);
        } else if (qwert_flag == 1) {
            network_model->setData(index667, qwerty_keyboard_CAPS_text);
        }
    }else if (row == 3 && col == 1) {
        QModelIndex index667 = network_model->index(3, 1, QModelIndex());
        QString currentText = network_model->data(index667).toString();

        if (currentText == "Enabled") {
            network_model->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            network_model->setData(index667, "Enabled");
        }
    }else if (row == 4 && col == 1) {
        QModelIndex index001 = network_model->index(3, 1, QModelIndex());
        QString textEnabled = network_model->data(index001).toString();

        if (textEnabled == "Enabled") {
            qwerty_keyboard keyboard;
            keyboard.setModal(true);
            keyboard.exec();
            QModelIndex index667 = network_model->index(4, 1, QModelIndex());
            if (qwert_flag == 0) {
                network_model->setData(index667, qwerty_keyboard_text);
            } else if (qwert_flag == 1) {
                network_model->setData(index667, qwerty_keyboard_CAPS_text);
            }
        }

    }
}



void MainWindow::onTableClicked_43(const QModelIndex &index) {
    int row = index.row();
    int col = index.column();
    if (row ==1 && col ==1){
        QModelIndex index667 = security_model->index(1, 1, QModelIndex());
        QString currentText = security_model->data(index667).toString();

        if (currentText == "Enabled") {
            security_model->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            security_model->setData(index667, "Enabled");
        }
    }else if (row == 2 && col == 1) {
        QModelIndex index001 = security_model->index(1, 1, QModelIndex());
        QString textEnabled = security_model->data(index001).toString();

        if (textEnabled == "Enabled") {
            qwerty_keyboard keyboard;
            keyboard.setModal(true);
            keyboard.exec();
            QModelIndex index667 = security_model->index(2, 1, QModelIndex());
            if (qwert_flag == 0) {
                security_model->setData(index667, qwerty_keyboard_text);
            } else if (qwert_flag == 1) {
                security_model->setData(index667, qwerty_keyboard_CAPS_text);
            }
        }

    } else if (row ==3 && col ==1 ){
        QModelIndex index667 = security_model->index(3, 1, QModelIndex());
        QString currentText = security_model->data(index667).toString();

        if (currentText == "Enabled") {
            security_model->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            security_model->setData(index667, "Enabled");
        }
    }
}


void MainWindow::onTableClicked_44(const QModelIndex &index) {
    int row = index.row();
    int col = index.column();
    if (index.row() == 0 && index.column() == 1) {
        qwerty_keyboard keyboard;
        keyboard.setModal(true);
        keyboard.exec();
        QModelIndex index667 = identity_model->index(0, 1, QModelIndex());
        if (qwert_flag == 0) {
            identity_model->setData(index667, qwerty_keyboard_text);
        } else if (qwert_flag == 1) {
            identity_model->setData(index667, qwerty_keyboard_CAPS_text);
        }
    }else if (row ==1 && col ==1){
        qwerty_keyboard keyboard;
        keyboard.setModal(true);
        keyboard.exec();
        QModelIndex index667 = identity_model->index(1, 1, QModelIndex());
        if (qwert_flag == 0) {
            identity_model->setData(index667, qwerty_keyboard_text);
        } else if (qwert_flag == 1) {
            identity_model->setData(index667, qwerty_keyboard_CAPS_text);
        }
    }else if (row == 2 && col ==1){
        VoltsValueSelection voltvalue;
        voltvalue.setModal(true);
        voltvalue.exec();
        QModelIndex index668 = identity_model->index(2, 1, QModelIndex());
        identity_model->setData(index668, keyboard_text);
    }
}



void MainWindow::onTableClicked_45(const QModelIndex &index) {
    int row = index.row();
    int col = index.column();

    if (row ==0 && col ==1){

        ui->stackedWidget->setCurrentIndex(102);

    }

    if (row ==3 && col ==1 ){
            QModelIndex index667 = erroralert_model->index(3, 1, QModelIndex());
            QString currentText = erroralert_model->data(index667).toString();

            if (currentText == "Enabled") {
                erroralert_model->setData(index667, "Disabled");
            } else if (currentText == "Disabled") {
                erroralert_model->setData(index667, "Enabled");
            }
        }
    if (row ==4 && col ==1 ){
            QModelIndex index667 = erroralert_model->index(4, 1, QModelIndex());
            QString currentText = erroralert_model->data(index667).toString();

            if (currentText == "Enabled") {
                erroralert_model->setData(index667, "Disabled");
            } else if (currentText == "Disabled") {
                erroralert_model->setData(index667, "Enabled");
            }
        }
    if (row == 5 && col == 1) {
            QModelIndex index001 = erroralert_model->index(4, 1, QModelIndex());
            QString textEnabled = erroralert_model->data(index001).toString();

            if (textEnabled == "Enabled") {
                VoltsValueSelection voltvalue;
                voltvalue.setModal(true);
                voltvalue.exec();
                QModelIndex index668 = erroralert_model->index(5, 1, QModelIndex());
                erroralert_model->setData(index668, keyboard_text + " "+ "Mins");
            }

        }
}



void MainWindow::onTableClicked_46(const QModelIndex &index) {
    int row = index.row();
    int col = index.column();
    if (row ==0 && col ==1 ){
            QModelIndex index667 = errortype_model->index(0, 1, QModelIndex());
            QString currentText = errortype_model->data(index667).toString();

            if (currentText == "Enabled") {
                errortype_model->setData(index667, "Disabled");
            } else if (currentText == "Disabled") {
                errortype_model->setData(index667, "Enabled");
            }
        } else if (row ==1 && col ==1 ){
        QModelIndex index667 = errortype_model->index(1, 1, QModelIndex());
        QString currentText = errortype_model->data(index667).toString();

        if (currentText == "Enabled") {
            errortype_model->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            errortype_model->setData(index667, "Enabled");
        }
    }else if (row ==2 && col ==1 ){
        QModelIndex index667 = errortype_model->index(2, 1, QModelIndex());
        QString currentText = errortype_model->data(index667).toString();

        if (currentText == "Enabled") {
            errortype_model->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            errortype_model->setData(index667, "Enabled");
        }
    }else if (row ==3 && col ==1 ){
        QModelIndex index667 = errortype_model->index(3, 1, QModelIndex());
        QString currentText = errortype_model->data(index667).toString();

        if (currentText == "Enabled") {
            errortype_model->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            errortype_model->setData(index667, "Enabled");
        }
    }else if (row ==4 && col ==1 ){
        QModelIndex index667 = errortype_model->index(4, 1, QModelIndex());
        QString currentText = errortype_model->data(index667).toString();

        if (currentText == "Enabled") {
            errortype_model->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            errortype_model->setData(index667, "Enabled");
        }
    }else if (row ==5 && col ==1 ){
        QModelIndex index667 = errortype_model->index(5, 1, QModelIndex());
        QString currentText = errortype_model->data(index667).toString();

        if (currentText == "Enabled") {
            errortype_model->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            errortype_model->setData(index667, "Enabled");
        }
    }else if (row ==6 && col ==1 ){
        QModelIndex index667 = errortype_model->index(6, 1, QModelIndex());
        QString currentText = errortype_model->data(index667).toString();

        if (currentText == "Enabled") {
            errortype_model->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            errortype_model->setData(index667, "Enabled");
        }
    }
}



void MainWindow::onTableClicked_47(const QModelIndex &index) {
    int row = index.row();
    int col = index.column();

    if (row == 0 && col ==1){
        demo_traces traces;
        traces.setModal(true);
        traces.exec();
        QModelIndex index668 = demotraces_model->index(0, 1, QModelIndex());
        demotraces_model->setData(index668, trace_value);
    }else if (row == 1 && col ==1){
        demo_traces traces;
        traces.setModal(true);
        traces.exec();
        QModelIndex index668 = demotraces_model->index(1, 1, QModelIndex());
        demotraces_model->setData(index668, trace_value);
    }else if (row == 2 && col ==1){
        demo_traces traces;
        traces.setModal(true);
        traces.exec();
        QModelIndex index668 = demotraces_model->index(2, 1, QModelIndex());
        demotraces_model->setData(index668, trace_value);
    }else if (row == 3 && col ==1){
        demo_traces traces;
        traces.setModal(true);
        traces.exec();
        QModelIndex index668 = demotraces_model->index(3, 1, QModelIndex());
        demotraces_model->setData(index668, trace_value);
    }else if (row == 4 && col ==1){
        demo_traces traces;
        traces.setModal(true);
        traces.exec();
        QModelIndex index668 = demotraces_model->index(4, 1, QModelIndex());
        demotraces_model->setData(index668, trace_value);
    }else if (row == 5 && col ==1){
        demo_traces traces;
        traces.setModal(true);
        traces.exec();
        QModelIndex index668 = demotraces_model->index(5, 1, QModelIndex());
        demotraces_model->setData(index668, trace_value);
    }


}



void MainWindow::onTableClicked_48(const QModelIndex &index) {
    int row = index.row();
    int col = index.column();
    if (row ==0 && col ==1 ){
            QModelIndex index667 = mediaconf_model->index(0, 1, QModelIndex());
            QString currentText = mediaconf_model->data(index667).toString();

            if (currentText == "Enabled") {
                mediaconf_model->setData(index667, "Disabled");
            } else if (currentText == "Disabled") {
                mediaconf_model->setData(index667, "Enabled");
            }
        } else if (row ==1 && col ==1 ){
        QModelIndex index667 = mediaconf_model->index(1, 1, QModelIndex());
        QString currentText = mediaconf_model->data(index667).toString();

        if (currentText == "Enabled") {
            mediaconf_model->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            mediaconf_model->setData(index667, "Enabled");
        }
    }else if (row ==2 && col ==1 ){
        QModelIndex index667 = mediaconf_model->index(2, 1, QModelIndex());
        QString currentText = mediaconf_model->data(index667).toString();

        if (currentText == "Enabled") {
            mediaconf_model->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            mediaconf_model->setData(index667, "Enabled");
        }
    }else if (row ==3 && col ==1 ){
        QModelIndex index667 = mediaconf_model->index(3, 1, QModelIndex());
        QString currentText = mediaconf_model->data(index667).toString();

        if (currentText == "Enabled") {
            mediaconf_model->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            mediaconf_model->setData(index667, "Enabled");
        }
    }else if (row ==4 && col ==1 ){
        QModelIndex index667 = mediaconf_model->index(4, 1, QModelIndex());
        QString currentText = mediaconf_model->data(index667).toString();

        if (currentText == "Enabled") {
            mediaconf_model->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            mediaconf_model->setData(index667, "Enabled");
        }
    }else if (row ==5 && col ==1 ){
        QModelIndex index667 = mediaconf_model->index(5, 1, QModelIndex());
        QString currentText = mediaconf_model->data(index667).toString();

        if (currentText == "Enabled") {
            mediaconf_model->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            mediaconf_model->setData(index667, "Enabled");
        }
    }

    }



void MainWindow::onTableClicked_49(const QModelIndex &index) {
    int row = index.row();
    int col = index.column();
    if (index.row() == 0 && index.column() == 1) {
        qwerty_keyboard keyboard;
        keyboard.setModal(true);
        keyboard.exec();
        QModelIndex index667 = email_model->index(0, 1, QModelIndex());
        if (qwert_flag == 0) {
            email_model->setData(index667, qwerty_keyboard_text);
        } else if (qwert_flag == 1) {
            email_model->setData(index667, qwerty_keyboard_CAPS_text);
        }
    }else if (row == 1 && col ==1){
        VoltsValueSelection voltvalue;
        voltvalue.setModal(true);
        voltvalue.exec();
        QModelIndex index668 = email_model->index(1, 1, QModelIndex());
        email_model->setData(index668, keyboard_text);
    }else if (row ==2 && col ==1 ){
        QModelIndex index667 = email_model->index(2, 1, QModelIndex());
        QString currentText = email_model->data(index667).toString();

        if (currentText == "Enabled") {
            email_model->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            email_model->setData(index667, "Enabled");
        }
    }else if (row ==3 && col ==1 ){
        QModelIndex index667 = email_model->index(3, 1, QModelIndex());
        QString currentText = email_model->data(index667).toString();

        if (currentText == "Enabled") {
            email_model->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            email_model->setData(index667, "Enabled");
        }
    }else if (row ==4 && col ==1 ){
        QModelIndex index667 = email_model->index(4, 1, QModelIndex());
        QString currentText = email_model->data(index667).toString();

        if (currentText == "Enabled") {
            email_model->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            email_model->setData(index667, "Enabled");
        }
    }else if (row == 5 && col == 1) {
        qwerty_keyboard keyboard;
        keyboard.setModal(true);
        keyboard.exec();
        QModelIndex index667 = email_model->index(5, 1, QModelIndex());
        if (qwert_flag == 0) {
            email_model->setData(index667, qwerty_keyboard_text);
        } else if (qwert_flag == 1) {
            email_model->setData(index667, qwerty_keyboard_CAPS_text);
        }
    }else if (row == 6 && col == 1) {
        qwerty_keyboard keyboard;
        keyboard.setModal(true);
        keyboard.exec();
        QModelIndex index667 = email_model->index(6, 1, QModelIndex());
        if (qwert_flag == 0) {
            email_model->setData(index667, qwerty_keyboard_text);
        } else if (qwert_flag == 1) {
            email_model->setData(index667, qwerty_keyboard_CAPS_text);
        }
    }else if (row == 7 && col == 1) {
        qwerty_keyboard keyboard;
        keyboard.setModal(true);
        keyboard.exec();
        QModelIndex index667 = email_model->index(7, 1, QModelIndex());
        if (qwert_flag == 0) {
            email_model->setData(index667, qwerty_keyboard_text);
        } else if (qwert_flag == 1) {
            email_model->setData(index667, qwerty_keyboard_CAPS_text);
        }
    }else if (row == 8 && col == 1) {
        ui->stackedWidget->setCurrentIndex(166);
    }else if (row == 9 && col == 1) {
        ui->stackedWidget->setCurrentIndex(150);
    }
}


void MainWindow::onTableClicked_50(const QModelIndex &index) {
    int clickedRow = index.row();
    int clickedCol = index.column();

    if (clickedRow >= 0 && clickedRow < 50 && (clickedCol == 0 || clickedCol == 1)) {
            qwerty_keyboard keyboard;
            keyboard.setModal(true);
            keyboard.exec();

            QModelIndex dataIndex = emailtemplate_model->index(clickedRow, 1, QModelIndex());

            if (qwert_flag == 0) {
                emailtemplate_model->setData(dataIndex, qwerty_keyboard_text);
            } else if (qwert_flag == 1) {
                emailtemplate_model->setData(dataIndex, qwerty_keyboard_CAPS_text);
            }
        }
}


void MainWindow::onTableClicked_51(const QModelIndex &index) {
    int row = index.row();
    int col = index.column();
    if (row ==0 && col ==1 ){
            QModelIndex index667 = opc_model->index(0, 1, QModelIndex());
            QString currentText = opc_model->data(index667).toString();

            if (currentText == "Enabled") {
                opc_model->setData(index667, "Disabled");
            } else if (currentText == "Disabled") {
                opc_model->setData(index667, "Enabled");
            }
        } else if (row ==1 && col ==1 ){
        VoltsValueSelection voltvalue;
        voltvalue.setModal(true);
        voltvalue.exec();
        QModelIndex index668 = opc_model->index(1, 1, QModelIndex());
        opc_model->setData(index668, keyboard_text);
       }
}


void MainWindow::onTableClicked_52(const QModelIndex &index) {
    int row = index.row();
    int col = index.column();
    if (row ==0 && col ==1 ){
            QModelIndex index667 = ftp_model->index(0, 1, QModelIndex());
            QString currentText = ftp_model->data(index667).toString();

            if (currentText == "Enabled") {
                ftp_model->setData(index667, "Disabled");
            } else if (currentText == "Disabled") {
                ftp_model->setData(index667, "Enabled");
            }
        } else if (row ==1 && col ==1 ){
        QModelIndex index667 = ftp_model->index(1, 1, QModelIndex());
        QString currentText = ftp_model->data(index667).toString();

        if (currentText == "Enabled") {
            ftp_model->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            ftp_model->setData(index667, "Enabled");
        }
    }else if (row ==2 && col ==1 ){
        QModelIndex index667 = ftp_model->index(2, 1, QModelIndex());
        QString currentText = ftp_model->data(index667).toString();

        if (currentText == "Enabled") {
            ftp_model->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            ftp_model->setData(index667, "Enabled");
        }
    }else if (row ==3 && col ==1 ){
        QModelIndex index667 = ftp_model->index(3, 1, QModelIndex());
        QString currentText = ftp_model->data(index667).toString();

        if (currentText == "Enabled") {
            ftp_model->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            ftp_model->setData(index667, "Enabled");
        }
    }else if (row ==4 && col ==1 ){
        QModelIndex index667 = ftp_model->index(4, 1, QModelIndex());
        QString currentText = ftp_model->data(index667).toString();

        if (currentText == "Enabled") {
            ftp_model->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            ftp_model->setData(index667, "Enabled");
        }
    }if (row == 5 && col == 1) {
        QModelIndex index001 = ftp_model->index(4, 1, QModelIndex());
        QString textEnabled = ftp_model->data(index001).toString();

        if (textEnabled == "Enabled") {
            QModelIndex index667 = ftp_model->index(5, 1, QModelIndex());
            QString currentText = ftp_model->data(index667).toString();

            if (currentText == "Enabled") {
                ftp_model->setData(index667, "Disabled");
            } else if (currentText == "Disabled") {
                ftp_model->setData(index667, "Enabled");
            }
        }

    }

    }





void MainWindow::onTableClicked_53(const QModelIndex &index) {
    int row = index.row();
    int col = index.column();
    if (row ==0 && col ==1 ){
            QModelIndex index667 = tcp_model->index(0, 1, QModelIndex());
            QString currentText = tcp_model->data(index667).toString();

            if (currentText == "Enabled") {
                tcp_model->setData(index667, "Disabled");
            } else if (currentText == "Disabled") {
                tcp_model->setData(index667, "Enabled");
            }
        }else if (row == 1 && col == 1) {
        QModelIndex index001 = tcp_model->index(0, 1, QModelIndex());
        QString textEnabled = tcp_model->data(index001).toString();

        if (textEnabled == "Enabled") {
            VoltsValueSelection voltvalue;
            voltvalue.setModal(true);
            voltvalue.exec();
            QModelIndex index668 = tcp_model->index(1, 1, QModelIndex());
            tcp_model->setData(index668, keyboard_text);
        }
    }else if (row == 2 && col == 1) {
        QModelIndex index001 = tcp_model->index(0, 1, QModelIndex());
        QString textEnabled = tcp_model->data(index001).toString();

        if (textEnabled == "Enabled") {
            VoltsValueSelection voltvalue;
            voltvalue.setModal(true);
            voltvalue.exec();
            QModelIndex index668 = tcp_model->index(2, 1, QModelIndex());
            tcp_model->setData(index668, keyboard_text);
        }
    }else if (row == 3 && col == 1) {
        QModelIndex index001 = tcp_model->index(0, 1, QModelIndex());
        QString textEnabled = tcp_model->data(index001).toString();

        if (textEnabled == "Enabled") {
            VoltsValueSelection voltvalue;
            voltvalue.setModal(true);
            voltvalue.exec();
            QModelIndex index668 = tcp_model->index(3, 1, QModelIndex());
            tcp_model->setData(index668, keyboard_text);
        }
    }else if (row ==4 && col ==1){
        ui->stackedWidget->setCurrentIndex(93);

    }else if (row ==5 && col ==1){
        ui->stackedWidget->setCurrentIndex(94);

    }
}


void MainWindow::onTableClicked_54(const QModelIndex &index) {
    int row = index.row();
    int col = index.column();
    if (row ==0 && col ==1 ){
            QModelIndex index667 = tcpwin_model->index(0, 1, QModelIndex());
            QString currentText = tcpwin_model->data(index667).toString();

            if (currentText == "Enabled") {
                tcpwin_model->setData(index667, "Disabled");
            } else if (currentText == "Disabled") {
                tcpwin_model->setData(index667, "Enabled");
            }
        }else if (row == 1 && col == 1) {
        QModelIndex index001 = tcpwin_model->index(0, 1, QModelIndex());
        QString textEnabled = tcpwin_model->data(index001).toString();

        if (textEnabled == "Enabled") {
            VoltsValueSelection voltvalue;
            voltvalue.setModal(true);
            voltvalue.exec();
            QModelIndex index668 = tcpwin_model->index(1, 1, QModelIndex());
            tcpwin_model->setData(index668, keyboard_text);
        }
    }else if (row == 2 && col == 1) {
        QModelIndex index001 = tcpwin_model->index(0, 1, QModelIndex());
        QString textEnabled = tcpwin_model->data(index001).toString();

        if (textEnabled == "Enabled") {
            VoltsValueSelection voltvalue;
            voltvalue.setModal(true);
            voltvalue.exec();
            QModelIndex index668 = tcpwin_model->index(2, 1, QModelIndex());
            tcpwin_model->setData(index668, keyboard_text);
        }
    } else if (row ==3 && col ==1 ){
        QModelIndex index667 = tcpwin_model->index(3, 1, QModelIndex());
        QString currentText = tcpwin_model->data(index667).toString();

        if (currentText == "Enabled") {
            tcpwin_model->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            tcpwin_model->setData(index667, "Enabled");
        }
    }else if (row == 4 && col == 1) {
        QModelIndex index001 = tcpwin_model->index(3, 1, QModelIndex());
        QString textEnabled = tcpwin_model->data(index001).toString();

        if (textEnabled == "Enabled") {
            VoltsValueSelection voltvalue;
            voltvalue.setModal(true);
            voltvalue.exec();
            QModelIndex index668 = tcpwin_model->index(4, 1, QModelIndex());
            tcpwin_model->setData(index668, keyboard_text);
        }
    }else if (row == 5 && col == 1) {
        QModelIndex index001 = tcpwin_model->index(3, 1, QModelIndex());
        QString textEnabled = tcpwin_model->data(index001).toString();

        if (textEnabled == "Enabled") {
            VoltsValueSelection voltvalue;
            voltvalue.setModal(true);
            voltvalue.exec();
            QModelIndex index668 = tcpwin_model->index(5, 1, QModelIndex());
            tcpwin_model->setData(index668, keyboard_text);
        }
    }else if (row ==6 && col ==1 ){
        QModelIndex index667 = tcpwin_model->index(6, 1, QModelIndex());
        QString currentText = tcpwin_model->data(index667).toString();

        if (currentText == "Enabled") {
            tcpwin_model->setData(index667, "Disabled");
        } else if (currentText == "Disabled") {
            tcpwin_model->setData(index667, "Enabled");
        }
    }

    }


void MainWindow::onTableClicked_55(const QModelIndex &index) {
    int row = index.row();
    int col = index.column();
    if (row ==0 && col ==1 ){
        VoltsValueSelection voltvalue;
        voltvalue.setModal(true);
        voltvalue.exec();
        QModelIndex index668 = tcpport_model->index(0, 1, QModelIndex());
        tcpport_model->setData(index668, keyboard_text);
    }else if (row ==1 && col ==1){
        VoltsValueSelection voltvalue;
        voltvalue.setModal(true);
        voltvalue.exec();
        QModelIndex index668 = tcpport_model->index(1, 1, QModelIndex());
        tcpport_model->setData(index668, keyboard_text);
    }
}

void MainWindow::onTableClicked_56(const QModelIndex &index) {
    int row = index.row();
    int col = index.column();
    if (row ==0 && col ==1 ){
        VoltsValueSelection voltvalue;
        voltvalue.setModal(true);
        voltvalue.exec();
        QModelIndex index668 = storagealarm_model->index(0, 1, QModelIndex());
        storagealarm_model->setData(index668, keyboard_text + " " +"Hrs.");
    }else if (row ==1 && col ==1){
        VoltsValueSelection voltvalue;
        voltvalue.setModal(true);
        voltvalue.exec();
        QModelIndex index668 = storagealarm_model->index(1, 1, QModelIndex());
        storagealarm_model->setData(index668, keyboard_text+ " " +"Hrs.");
    }else if (row ==2 && col ==1){
        VoltsValueSelection voltvalue;
        voltvalue.setModal(true);
        voltvalue.exec();
        QModelIndex index668 = storagealarm_model->index(2, 1, QModelIndex());
        storagealarm_model->setData(index668, keyboard_text+ " " +"Hrs.");
    }
}


void MainWindow::onTableClicked_57(const QModelIndex &index) {
    if (index.isValid()) {

           ui->stackedWidget->setCurrentIndex(151);

}
}


void MainWindow::onTableClicked_58(const QModelIndex &index) {
        int row = index.row();
        int col = index.column();
    if (row == 0 && col == 1) {
            qwerty_keyboard keyboard;
            keyboard.setModal(true);
            keyboard.exec();
            QModelIndex index667 = emailtemp_model->index(0, 1, QModelIndex());
            if (qwert_flag == 0) {
                emailtemp_model->setData(index667, qwerty_keyboard_text);
            } else if (qwert_flag == 1) {
                emailtemp_model->setData(index667, qwerty_keyboard_CAPS_text);
            }
    }
}

void MainWindow::onTableClicked_59(const QModelIndex &index) {
    if (index.isValid()) {

           ui->stackedWidget->setCurrentIndex(61);

}
}


void MainWindow::onTableClicked_60(const QModelIndex &index) {
        int row = index.row();
        int col = index.column();
    if (row == 0 && col == 1) {
            qwerty_keyboard keyboard;
            keyboard.setModal(true);
            keyboard.exec();
            QModelIndex index667 = linearizationtable_model->index(0, 1, QModelIndex());
            if (qwert_flag == 0) {
                linearizationtable_model->setData(index667, qwerty_keyboard_text);
            } else if (qwert_flag == 1) {
                linearizationtable_model->setData(index667, qwerty_keyboard_CAPS_text);
            }
    }
}



void MainWindow::onTableClicked_61(const QModelIndex &index) {
    int row = index.row();
    int col = index.column();
    if (row ==0 && col ==1 ){
            QModelIndex index667 = slave_model->index(0, 1, QModelIndex());
            QString currentText = slave_model->data(index667).toString();

            if (currentText == "Enabled") {
                slave_model->setData(index667, "Disabled");
            } else if (currentText == "Disabled") {
                slave_model->setData(index667, "Enabled");
            }
        } else if (row == 1 && col == 1) {
        QModelIndex index001 = slave_model->index(0, 1, QModelIndex());
        QString textEnabled = slave_model->data(index001).toString();
        if (textEnabled == "Enabled") {
            port port;
            port.setModal(true);
            port.exec();
            QModelIndex index668 = slave_model->index(1, 1, QModelIndex());
            slave_model->setData(index668, port_value);
        }

    }else if (row == 2 && col == 1) {
        QModelIndex index001 = slave_model->index(0, 1, QModelIndex());
        QString textEnabled = slave_model->data(index001).toString();
        if (textEnabled == "Enabled") {
            ModbusProtocol protocol;
            protocol.setModal(true);
            protocol.exec();
            QModelIndex index668 = slave_model->index(2, 1, QModelIndex());
            slave_model->setData(index668, protocol_value);
        }

    }else if (row == 3 && col == 1) {
        QModelIndex index001 = slave_model->index(0, 1, QModelIndex());
        QString textEnabled = slave_model->data(index001).toString();
        if (textEnabled == "Enabled") {
            VoltsValueSelection voltvalue;
            voltvalue.setModal(true);
            voltvalue.exec();
            QModelIndex index668 = slave_model->index(3, 1, QModelIndex());
            slave_model->setData(index668, keyboard_text);
        }

    }
}


void MainWindow::onTableClicked_62(const QModelIndex &index) {
    int row = index.row();
    int col = index.column();
    if (row ==0 && col ==1 ){
        baudrate baud;
        baud.setModal(true);
        baud.exec();
        QModelIndex index668 = rs485_model->index(0, 1, QModelIndex());
        rs485_model->setData(index668, baudrate_vaue);
    }else if (row ==1 && col ==1){
        byte_options byteop;
        byteop.setModal(true);
        byteop.exec();
        QModelIndex index668 = rs485_model->index(1, 1, QModelIndex());
        rs485_model->setData(index668, byteoption_value);
    }else if (row == 2 & col ==1){
            VoltsValueSelection voltvalue;
            voltvalue.setModal(true);
            voltvalue.exec();
            QModelIndex index668 = rs485_model->index(2, 1, QModelIndex());
            rs485_model->setData(index668, keyboard_text);
        }else if (row == 3 & col==1){
        VoltsValueSelection voltvalue;
        voltvalue.setModal(true);
        voltvalue.exec();
        QModelIndex index668 = rs485_model->index(3, 1, QModelIndex());
        rs485_model->setData(index668, keyboard_text);
    }


}

////////////////////////////////////////////////////
//connect(ui->m_kRecordingBtn,&QPushButton::released, [pCfgSetupMenu](){pCfgSetupMenu->OnCfgSetupMenuDlgRecordingBtn();});
void MainWindow::/*on_toolButton_72_clicked*/OnCfgSetupMenuDlgRecordingBtn()
{
     ui->stackedWidget->setCurrentIndex(11);
}

void MainWindow::on_toolButton_40_clicked()
{
   ui->stackedWidget->setCurrentIndex(12);
}

void MainWindow::on_toolButton_75_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(1);
}

void MainWindow::on_toolButton_55_clicked()
{
   ui->stackedWidget->setCurrentIndex(3);
}

void MainWindow::on_pushButton_76_clicked()
{
    ui->stackedWidget->setCurrentIndex(11);
}

void MainWindow::on_pushButton_78_clicked()
{
    QModelIndex index = model2->index(0, 1, QModelIndex());

    QString cellText = index.data().toString();
    QStringList list = cellText.split(QRegExp(" "), QString::SkipEmptyParts);
    loaddata.PretriggerTime = list[0].toUInt();
    index= model2->index(1, 1, QModelIndex());
    cellText= index.data().toString();
    list = cellText.split(QRegExp(" "), QString::SkipEmptyParts);
    loaddata.PostTriggerTime = list[0].toUInt();
    saveStructureToFile(LOG_CONFIG_FILE,loaddata);
    ui->stackedWidget->setCurrentIndex(11);
}

void MainWindow::on_pushButton_73_clicked()
{
    ui->stackedWidget->setCurrentIndex(9);
}

void MainWindow::on_pushButton_75_clicked()
{
    long ret;
    char *ptr;
    int result,s_num,ch_num;
    int f, p;
//  char str[10];
    uint32_t b_type;
    char fname[30];
    char *file_path = NULL;




    ui->stackedWidget_2->setCurrentIndex(1);

        QModelIndex index61 = model1->index(4,1,QModelIndex());
        QString edit_math = index61.data().toString();

        strncpy(mt_PEN[Pen_Selected]->MathsBlock, edit_math.toLocal8Bit().constData(), edit_math.size());
            char w=mt_PEN[Pen_Selected]->MathsBlock[0];
            QString str = edit_math;
            str=str.remove(QChar('a'), Qt::CaseInsensitive);
            ch_num = str.toInt();
            if (w =='A')
            {
                mt_PEN[Pen_Selected]->Board_type = BOARD_AI;
                b_type = BOARD_AI;
                mt_PEN[Pen_Selected]->ChNum = ch_num ;

                if (ch_num >= 1 && ch_num <= 8)
                    s_num = SLOT_A;
                else if (ch_num >= 9 && ch_num <= 16)
                    s_num = SLOT_B;
                else if (ch_num >= 17 && ch_num <= 24)
                    s_num = SLOT_C;
                else if (ch_num >= 25 && ch_num <= 32)
                    s_num = SLOT_D;
                else if (ch_num >= 33 && ch_num <= 40)
                    s_num = SLOT_E;
                else if (ch_num >= 41 && ch_num <= 48)
                    s_num = SLOT_F;


            }
            mt_PEN[Pen_Selected]->Slot = s_num;

        result = setPenChannelMapping(mt_PEN[Pen_Selected], s_num, ch_num, b_type);



        //qDebug()<<"...................................enabled="<<mt_PEN[Pen_Selected]->PenLog.Enabled;

       if(mt_PEN[Pen_Selected]->PenLog.Enabled == 1 && mt_PEN[Pen_Selected]->ChNum > 0);
        {
           tm = *localtime(&t);
           memset(fname, 0, sizeof(char));

               result = asprintf(&file_path, "/home/root/PenDatalog%d.csv",Pen_Selected);


               // QString name = QString("/home/root/PenDatalog")+QString(QVariant(Pen_Selected).toString())+QString(".csv\0");
               // strncpy(fname, name.toLocal8Bit().constData(), name.size());
                  // fname = name;
                   fptr_log[Pen_Selected] = fopen(file_path,"w+");
                   if(fptr_log[Pen_Selected] == NULL)
                   {
                       printf("file can't be opened\n");
                       exit(1);
                   }

                   fprintf(fptr_log[Pen_Selected], "%s, \"%d/%02d/%02d  %02d:%02d:%02d\",\n", "Start (MM/DD/YYYY HH:MM:SS:sss)",
                           tm.tm_mday, tm.tm_mon + 1,tm.tm_year + 1900, tm.tm_hour, tm.tm_min, tm.tm_sec);
                   fprintf(fptr_log[Pen_Selected], "%s, %dDay(s)%dHour(s)%dMin(s)%dSec(s),\n", "Span", 0,1, 52, 50);
                   fprintf(fptr_log[Pen_Selected], "%s,%s,\n", "Recorder Name(s)", "Multitrend GR");
                   fprintf(fptr_log[Pen_Selected], "%s,%d,\n", "ID", 0001);
                   fprintf(fptr_log[Pen_Selected], "%s,%d,\n", "Serial No.", 999999);
                   fprintf(fptr_log[Pen_Selected], "%s, %f - %f ,%%\n", "Scale and Units", 0.0, 100.0);
                   fprintf(fptr_log[Pen_Selected], "%s,%d,\n,\n,\n,\n,\n", "Pen No", Pen_Selected);

                   fprintf(fptr_log[Pen_Selected], "%s,%s,\"%d/%02d/%02d  %02d:%02d:%02d\", %f,\n",
                           "Date and Time (MM/DD/YYYY HH:MM:SS:sss)", "Sample",
                           tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900, tm.tm_hour, tm.tm_min, tm.tm_sec, 50.515427);

                   //fprintf(fptr_log[i], "%d/%02d/%02d  %02d:%02d:%02d",tm.tm_mday, tm.tm_mon + 1,tm.tm_year + 1900, tm.tm_hour, tm.tm_min, tm.tm_sec);
           signal(SIGINT, signal_callback_handler);
           signal(SIGSEGV, signal_callback_handler);

        }

       saveInfoStructureToFile(LOG_INFO_FILE,mt_PEN);


      // fclose(fptr_log[Pen_Selected]);
}

void MainWindow::on_pushButton_80_clicked()
{
    ui->stackedWidget->setCurrentIndex(10);
}

void MainWindow::on_pushButton_82_clicked()
{
   ui->stackedWidget->setCurrentIndex(13);
}

void MainWindow::on_pushButton_79_clicked()
{
  ui->stackedWidget->setCurrentIndex(10);
}

void MainWindow::on_pushButton_81_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(1);
}

void MainWindow::on_pushButton_119_clicked()
{
    ui->stackedWidget->setCurrentIndex(16);
}

void MainWindow::on_pushButton_120_clicked()
{
    if (comp_type == "Single Point")
    {
    QModelIndex index2 = model7->index(1,1,QModelIndex());
    QString cellText2= index2.data().toString();
   // qDebug()<<"singlepoint_val="<<cellText2;

    float s =cellText2.toFloat();
    //qDebug()<<"singlepoint_val_float="<<s;
//    singlepoint_val[ai_ch_no]=s;
    AIOchinfo[model6_ch]->AIchinfo->sensorComp.singlepoint_val = s;
    }
    ////////////////////////////////////////////////////////////////////dual point valus
    if (comp_type == "Dual Point"){

                     QModelIndex index2 = model7->index(1,1,QModelIndex());
                     QString cellText2= index2.data().toString();
                     qDebug()<<"dualpoint_val1="<<cellText2;
//                     Dualpoint_val1[ai_ch_no] =cellText2.toFloat();
//                     Dual_point_values[ai_ch_no][0]=Dualpoint_val1;
//                     qDebug()<<"dualpoint_val1_float="<<Dualpoint_val1;
                     AIOchinfo[model6_ch]->AIchinfo->sensorComp.dualPtEngLow = cellText2.toFloat();

                     QModelIndex index3 = model7->index(2,1,QModelIndex());
                     QString cellText3= index3.data().toString();
                     qDebug()<<"dualpoint_val2="<<cellText3;
//                     Dualpoint_val2[ai_ch_no] =cellText3.toFloat();
//                     Dual_point_values[ai_ch_no][1]=Dualpoint_val2;
//                     qDebug()<<"dualpoint_val1_float="<<Dualpoint_val2;
                     AIOchinfo[model6_ch]->AIchinfo->sensorComp.dualPtOffsetLow = cellText3.toFloat();

                     QModelIndex index4 = model7->index(3,1,QModelIndex());
                     QString cellText4= index4.data().toString();
                     qDebug()<<"dualpoint_val3="<<cellText4;
//                     Dualpoint_val3[ai_ch_no] =cellText4.toFloat();
//                     Dual_point_values[ai_ch_no][2]=Dualpoint_val3;
//                     qDebug()<<"dualpoint_val1_float="<<Dualpoint_val3;
                     AIOchinfo[model6_ch]->AIchinfo->sensorComp.dualPtEngHigh = cellText4.toFloat();

                     QModelIndex index5 = model7->index(4,1,QModelIndex());
                     QString cellText5= index5.data().toString();
                     qDebug()<<"dualpoint_val4="<<cellText5;
//                     Dualpoint_val4[ai_ch_no] =cellText5.toFloat();
//                     Dual_point_values[ai_ch_no][3]=Dualpoint_val4;
//                     qDebug()<<"dualpoint_val1_float="<<Dualpoint_val4;
                     AIOchinfo[model6_ch]->AIchinfo->sensorComp.dualPtOffsetHigh = cellText5.toFloat();
                     qDebug()<< "channel num : " << model6_ch ;
                    qDebug()<< "Dua Point dualPtEngLow : " << AIOchinfo[model6_ch]->AIchinfo->sensorComp.dualPtEngLow;
                     qDebug()<< "Dua Point dualPtOffsetLow : " << AIOchinfo[model6_ch]->AIchinfo->sensorComp.dualPtOffsetLow;
                     qDebug()<< "Dua Point dualPtEngHigh : " << AIOchinfo[model6_ch]->AIchinfo->sensorComp.dualPtEngHigh;

                      qDebug()<< "Dua Point dualPtOffsetHigh : " << AIOchinfo[model6_ch]->AIchinfo->sensorComp.dualPtOffsetHigh;
    }
    /////////////////////////////////////////////////////////////////////////
    ui->stackedWidget_2->setCurrentIndex(1);




}

void MainWindow::on_pushButton_85_clicked()
{
    ui->stackedWidget->setCurrentIndex(15);
}

void MainWindow::on_pushButton_86_clicked()
{

    ui->stackedWidget_2->setCurrentIndex(1);//num
}

void MainWindow::on_pushButton_83_clicked()
{
    ui->stackedWidget->setCurrentIndex(4);
}

void MainWindow::on_pushButton_87_clicked()
{
//#if 0
    int result;
    uint8_t range_info,setup_info;
    int n_chavail = 0;

    // get the AI cards present in slot..
    // traverse through the SRate and VRangetype which have been changed..
    // accordingly set setup_info and range_info values

    for (int var = 0; var < 6; ++var)
    {
        AI_slot = var;

        if (slot_info[var]->board_type == BOARD_AI)
        {
            n_chavail = slot_info[var]->board_data->bd_capability->ch_available;

            for(int row = 0; row < n_chavail; row++)
            {
                //frequency[(var*8)+row+1] = AIOchinfo[(var*8)+row+1]->AIchinfo->SRate;
                //range[(var*8)+row+1] = AIOchinfo[(var*8)+row+1]->AIchinfo->VRangetype;
//                if(AIOchinfo[(var*8)+row+1]->AIchinfo->SRate != NULL)
                //AIOchinfo[(var*8)+row+1]->AIchinfo->SRate
                {
                    //qDebug()<<"if check="<<frequency[(var*8)+row+1];

//                    if( frequency[(var*8)+row+1] > 0 )      // try to avoid this [(var*8)+row+1]
//                    {
//                       // qDebug()<<"entering if condition";
//                        switch (frequency[(var*8)+row+1])
//                        {
//                            case s_50Hz:
//                                setup_info=0x11;

//                                break;
//                            case s_10Hz:
//                                    setup_info=0x0D;
//                                break;
//                            case s_5Hz:
//                                    setup_info=0x09;

//                                break;
//                            case s_2Hz:
//                                    setup_info=0x05;

//                                break;
//                            default:
//                                break;

//                        }

//                    }

//                    if( frequency[(var*8)+row+1] > 0 )      // try to avoid this [(var*8)+row+1]
//                    {
//                       // qDebug()<<"entering if condition";
//                        switch (AIOchinfo[(var*8)+row+1]->AIchinfo->frequency)
//                        {
//                            case 20:
//                                setup_info=0x11;

//                                break;
//                            case 100:
//                                    setup_info=0x0D;
//                                break;
//                            case 200:
//                                    setup_info=0x09;

//                                break;
//                            case 500:
//                                    setup_info=0x05;

//                                break;
//                            default:
//                                break;

//                        }

//                    }

//                    qDebug()<<"AIOchinfo[(var*8)+row+1]->AIchinfo->frequency = "<< AIOchinfo[(var*8)+row+1]->AIchinfo->frequency;
//                    qDebug()<<"AIOchinfo[(var*8)+row+1]->AIchinfo->range = " << AIOchinfo[(var*8)+row+1]->AIchinfo->range;

//                    qDebug() << "frequency = " << frequency[(var*8)+row+1];
//                    qDebug() << "range = " << range[(var*8)+row+1];

//                    printf("AIOchinfo[(var*8)+row+1]->AIchinfo->frequency = %x \n", AIOchinfo[(var*8)+row+1]->AIchinfo->frequency);
//                    printf("AIOchinfo[(var*8)+row+1]->AIchinfo->range = %x \n", AIOchinfo[(var*8)+row+1]->AIchinfo->range);
//                    printf("frequency = %x \n", frequency[(var*8)+row+1]);
//                    printf("range = %x \n", range[(var*8)+row+1]);

//                    qDebug()<<"setup-info : " << setup_info;

//                    switch (AIOchinfo[(var*8)+row+1]->AIchinfo->frequency)
//                    {
//                        case 4:
//                            setup_info=0x11;
//                            break;
//                        case 3:
//                                setup_info=0x0D;
//                            break;
//                        case 2:
//                                setup_info=0x09;

//                            break;
//                        case 1:
//                                setup_info=0x05;

//                            break;
//                        default:
//                            break;
//                    }
//                    qDebug()<<"setup-info : " << setup_info;


                    if( (frequency[(var*8)+row+1] > 0) || (range[(var*8)+row+1] > 0) )
                    {

//                        if( frequency[(var*8)+row+1] > 0 )      // try to avoid this [(var*8)+row+1]
                        {
//                           qDebug()<<"entering if condition";

//                            frequency[(var*8)+row+1] = AIOchinfo[(var*8)+row+1]->AIchinfo->frequency;
//                            setup_info = AIOchinfo[(var*8)+row+1]->AIchinfo->frequency;
                            qDebug()<<"AIOchinfo[(var*8)+row+1]->AIchinfo->frequency = "<<AIOchinfo[(var*8)+row+1]->AIchinfo->frequency;

                            switch (AIOchinfo[(var*8)+row+1]->AIchinfo->frequency)
                            {
                                case 4:
                                    setup_info=0x11;
                                    break;
                                case 3:
                                        setup_info=0x0D;
                                    break;
                                case 2:
                                        setup_info=0x09;

                                    break;
                                case 1:
                                        setup_info=0x05;

                                    break;
                                default:
                                    break;
                            }
                       }
                        qDebug()<<"setup_info = "<<setup_info;

                        if (AIOchinfo[(var*8)+row+1]->AIchinfo->SensorType == Volts)
                        {
//                            if (range[(var*8)+row+1] > 0 )
                            {
//                                range_info=range[(var*8)+row+1];
//                                vl_range[(var*8)+row+1]=range[(var*8)+row+1];
                            }

                            if(AIOchinfo[(var*8)+row+1]->AIchinfo->SensorRange == User_defined){
                                unsigned int r = GetRangeClosestMatch (0,
                                                              AIOchinfo[(var*8)+row+1]->AIchinfo->SensorType,
                                        AIOchinfo[(var*8)+row+1]->AIchinfo->userVal.UserHighLim, AIOchinfo[(var*8)+row+1]->AIchinfo->userVal.UserLowLim, AIOchinfo[(var*8)+row+1]->AIchinfo->userVal.UserVoltUnits);

                                qDebug() << "  r : _________________ " << r;
                                qDebug() << "  SensorType : _________________ " << AIOchinfo[(var*8)+row+1]->AIchinfo->SensorType;
                                qDebug() << "  UserHighLim : _________________ " << AIOchinfo[(var*8)+row+1]->AIchinfo->userVal.UserHighLim;
                                qDebug() << "  UserLowLim : _________________ " << AIOchinfo[(var*8)+row+1]->AIchinfo->userVal.UserLowLim;
                                qDebug() << "  UserVoltUnits : _________________ " << AIOchinfo[(var*8)+row+1]->AIchinfo->userVal.UserVoltUnits;
                                qDebug() << "  (var*8)+row+1 : _________________ " << (var*8)+row+1;

                                switch(r)
                                {
                                 case mv_5:
                                     range_info = 0x50;
                                    break;
                                case mv_10:
                                   range_info = 0x51;
                                   break;
                                case mv_25:
                                   range_info = 0x52;
                                   break;
                                case mv_50:
                                   range_info = 0x53;
                                   break;
                                case mv_100:
                                   range_info = 0x54;
                                   break;
                                case mv_250:
                                   range_info = 0x55;
                                   break;
                                case mv_500:
                                   range_info = 0x56;
                                   break;
                                case mv_1000:
                                   range_info = 0x57;
                                   break;
                                case v_0_3:
                                   range_info = 0x20;
                                   break;
                                case v_0_6:
                                   range_info = 0x21;
                                   break;
                                case v_1_5:
                                   range_info = 0x22;
                                   break;
                                case v_3:
                                   range_info = 0x23;
                                   break;
                                case v_6:
                                   range_info = 0x24;
                                   break;
                                case v_12:
                                   range_info = 0x25;
                                   break;
                                case v_25:
                                   range_info = 0x26;
                                   break;
                                case v_50:
                                   range_info = 0x27;
                                   break;

                                default:
                                   break;
                                }
                                qDebug() << "  range_info : _________________ " << range_info;

                            }
                            else if(AIOchinfo[(var*8)+row+1]->AIchinfo->SensorRange == Preset)
                            {
                                range_info = AIOchinfo[(var*8)+row+1]->AIchinfo->range;
                                vl_range[(var*8)+row+1] = AIOchinfo[(var*8)+row+1]->AIchinfo->range;
                            }
                        }
                        else if (AIOchinfo[(var*8)+row+1]->AIchinfo->SensorType == Amps)
                        {
                            /********************************************************************
                            *	Current input ranges
                            ********************************************************************/
    //                        #define	INPUT_4_20MA	(CtrlP1 | PairA3A4 | Gain4)
    //                        #define	INPUT_0_20MA	(CtrlP1 | PairA3A4 | Gain4)
                              if( AIOchinfo[model6_ch]->AIchinfo->ARangetype == amp_0_20mA ||
                                      AIOchinfo[model6_ch]->AIchinfo->ARangetype == amp_4_20mA)
                              {
                                  range_info = INPUT_0_20MA;    // or INPUT_4_20MA --> is also OK
    //                              range_info = INPUT_4_20MA;
                                  vl_range[(var*8)+row+1]=INPUT_0_20MA;
                              }
    //                        range_info=range[(var*8)+row+1];
    //                        vl_range[(var*8)+row+1]=range[(var*8)+row+1];
                        }

                        result = IO_CardTest_CTAB(fd, AI_slot, GET_ERR_CODE);
                       printf("setup_info1=%x \n",setup_info);
                        printf("range_info1=%x \n",range_info);

//                        printf("row = %d ",row);

                        result = write_AI_Channel_Config(fd, AI_slot, row, setup_info, range_info); // confirm whether it is row or row+1
                        result = IO_CardTest_CTAB(fd, AI_slot, 0x0a);
                        result = IO_CardTest_CTAB(fd, AI_slot, GET_ERR_CODE);
                    }
                }
            }
        }
    }

       // LOG_LEVEL_1=1;
        for (int i=0 ;i < 48; i++)
        {
            frequency[i]=0;
            range[i]=0;
        }
#if 0
        result = GetAICardData(fd, AI_slot, AICardinfo);
        for (int i = 0; i < chavail_num ; i++)
        {

            result = GetAIChannelData(fd, AI_slot, i, AICardinfo, AIChannelinfo[i]);
        }
        for (int i = 0; i < chavail_num; i++)
        {
            if (s_rate[i] != AIChannelinfo[i]->ack_frq)
            {
                printf("Configuration Failed for Channel %d\n",i);
                printf("Default Sampling Rate is %d\n", AIChannelinfo[i]->ack_frq);
            }
        }


    result = reset_CircularBuff(fd, slot_num, 1);
    if (result == 1){
        for (i = 0; i<8; i++)
        {
            curr_time[i] = 0;
            prev_time[i] = 0;
        }
    }
    else
        result = reset_CircularBuff(fd, slot_num, 1);
    if (result != 1)
        printf("failed second time also\n");
    usleep(10000);

#endif

//    ui->Main_pushbutton->show();
//    ui->stackedWidget->setGeometry(0,55,1024,713);/////
//    ui->stackedWidget->setCurrentIndex(8);
//    ui->stackedWidget->setStyleSheet("QStackedWidget{image: url(/home/pi/Desktop/Paperless_Recorder_gui/front_screen_re.png);background-color: rgb(17, 100, 255)}");
     ui->stackedWidget_2->setCurrentIndex(1);
//#endif


    LOG_LEVEL_1=1;
  AI_Card_Info a;
     result=read_AI_Board_Config(fd,0, &a);

}

void MainWindow::on_pushButton_46_clicked()
{
    ui->stackedWidget->setCurrentIndex(17);
}

void MainWindow::on_toolButton_27_clicked()
{
    ui->stackedWidget->setCurrentIndex(5);
}

void MainWindow::on_pushButton_104_clicked()
{
   ui->stackedWidget->setCurrentIndex(4);
}

void MainWindow::on_pushButton_106_clicked()
{
   ui->stackedWidget_2->setCurrentIndex(1);
   //ANALOG OUT FINISH
    //verbose=1;
   int result = 0 ;
   result = updateAOCardInfo();

}



void MainWindow::on_pushButton_108_clicked()
{
   ui->stackedWidget->setCurrentIndex(5);
}

void MainWindow::on_pushButton_107_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(1);
}

void MainWindow::on_toolButton_23_clicked()
{
    ui->stackedWidget->setCurrentIndex(19);
}

void MainWindow::on_EDIT_SETUP_FIELDIO_ALARM_DIGITALIO_INDEX_BOTTOM_BAR_Back_clicked()
{
   ui->stackedWidget->setCurrentIndex(19);
}

void MainWindow::on_EDIT_SETUP_FIELDIO_ALARM_DIGITALIO_INDEX_BOTTOM_BAR_Finish_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(1);
}

void MainWindow::on_pushButton_110_clicked()
{
    ui->stackedWidget->setCurrentIndex(4);
}

void MainWindow::on_pushButton_109_clicked()
{
    //dio finish button
    int result_DIO;
    //verbose=1;
    result_DIO= updateDIOCardInfo();
    ui->stackedWidget_2->setCurrentIndex(1);
}




void MainWindow::on_toolButton_7_clicked()
{
    EnAcqFlag =0;
   ui->stackedWidget_2->setCurrentIndex(0);
   ui->stackedWidget->setCurrentIndex(0);
}
//connect(ui->MAIN_MENU_m_kFinishBtn,&QPushButton::released, [pMainMenu](){pMainMenu->OnMainMenuDlgExitBtn();});
void MainWindow::/*on_toolButton_20_clicked*/OnMainMenuDlgExitBtn()
{
    //EnAcqFlag =1;
   ui->stackedWidget_2->setCurrentIndex(1);
}

void MainWindow::on_pushButton_15_clicked()
{
    ui->stackedWidget->setCurrentIndex(3);
}

void MainWindow::on_pushButton_16_clicked()
{
    ui->stackedWidget->setCurrentIndex(4);
}

void MainWindow::on_pushButton_18_clicked()
{
    ui->stackedWidget->setCurrentIndex(3);
}

void MainWindow::on_pushButton_19_clicked()
{
    ui->stackedWidget->setCurrentIndex(4);
}

void MainWindow::on_pushButton_22_clicked()
{
    ui->stackedWidget->setCurrentIndex(3);
}

void MainWindow::on_pushButton_24_clicked()
{
    ui->stackedWidget->setCurrentIndex(3);
}

void MainWindow::on_pushButton_27_clicked()
{
    ui->stackedWidget->setCurrentIndex(3);
}

void MainWindow::on_pushButton_30_clicked()
{
    ui->stackedWidget->setCurrentIndex(3);
}

void MainWindow::on_pushButton_34_clicked()
{
    ui->stackedWidget->setCurrentIndex(3);
}

void MainWindow::on_pushButton_38_clicked()
{
    ui->stackedWidget->setCurrentIndex(3);
}

void MainWindow::on_pushButton_41_clicked()
{
    ui->stackedWidget->setCurrentIndex(3);
}

void MainWindow::on_pushButton_39_clicked()
{
    ui->stackedWidget->setCurrentIndex(4);
}

void MainWindow::on_pushButton_42_clicked()
{
    ui->stackedWidget->setCurrentIndex(4);
}




void MainWindow::on_pushButton_5_clicked()
{
    ui->stackedWidget->setCurrentIndex(3);
}

void MainWindow::on_pushButton_6_clicked()
{
    ui->stackedWidget->setCurrentIndex(4);
}

void MainWindow::on_EDIT_SETUP_FIELDIO_ALARM_DIGITALIO_INDEX_TOP_BAR_Edit_Setup_clicked()
{
    ui->stackedWidget->setCurrentIndex(3);
}

void MainWindow::on_EDIT_SETUP_FIELDIO_ALARM_DIGITALIO_INDEX_TOP_BAR_FieldIo_clicked()
{
    ui->stackedWidget->setCurrentIndex(4);
}

void MainWindow::on_EDIT_SETUP_FIELDIO_ALARM_DIGITALIO_INDEX_TOP_BAR_Alarm_DigitalIo_clicked()
{
    ui->stackedWidget->setCurrentIndex(19);
}

void MainWindow::on_pushButton_20_clicked()
{
    ui->stackedWidget->setCurrentIndex(5);
}

void MainWindow::on_pushButton_25_clicked()
{
    ui->stackedWidget->setCurrentIndex(9);
}

void MainWindow::on_pushButton_28_clicked()
{

    QModelIndex index = model2->index(0, 1, QModelIndex());
// qDebug()<<".....................................111";
    QString cellText = index.data().toString();
    QStringList list = cellText.split(QRegExp(" "), QString::SkipEmptyParts);
    loaddata.PretriggerTime = list[0].toUInt();
    index= model2->index(1, 1, QModelIndex());
    cellText= index.data().toString();
    list = cellText.split(QRegExp(" "), QString::SkipEmptyParts);
    loaddata.PostTriggerTime = list[0].toUInt();
    saveStructureToFile(LOG_CONFIG_FILE,loaddata);
    ui->stackedWidget->setCurrentIndex(11);
}

void MainWindow::on_pushButton_31_clicked()
{
    ui->stackedWidget->setCurrentIndex(9);
}

void MainWindow::on_pushButton_32_clicked()
{
    ui->stackedWidget->setCurrentIndex(10);
}

void MainWindow::on_pushButton_43_clicked()
{
    ui->stackedWidget->setCurrentIndex(15);
}

void MainWindow::on_pushButton_50_clicked()
{
    ui->stackedWidget->setCurrentIndex(15);
}

void MainWindow::on_pushButton_51_clicked()
{
    ui->stackedWidget->setCurrentIndex(16);
}

void MainWindow::on_pushButton_36_clicked()
{
     ui->stackedWidget->setCurrentIndex(10);
}

void MainWindow::on_pushButton_35_clicked()
{
   ui->stackedWidget->setCurrentIndex(9);
}
//connect(ui->m_kRecordBtn,&QPushButton::released, [pMainMenu](){pMainMenu->OnMainMenuDlgRecordBtn();});
void MainWindow::/*toolBotton_16*/OnMainMenuDlgRecordBtn()
{
   QString noOfPensInLogging = QString::number(3);
   QString Recording = "Recording:		%1 pens recording\n";
   QString Export = "Export Required In:	>1 year\n";
   QString Schedule_info = "Schedule:		%1\n";
   QString originalString2;
   if(loaddata.DoSchedExport)
   {
       QString Schedule_data;
       Schedule_data = "Schedule:		";
       if(loaddata.SchedExportTime == 0)
           Schedule_data =+ "10 Minutes";
       else if(loaddata.SchedExportTime == 1)
           Schedule_data =+ "30 Minutes";
       else if(loaddata.SchedExportTime == 2)
           Schedule_data =+ "1 Hour";
       else if(loaddata.SchedExportTime == 3)
           Schedule_data =+ "2 Hours";
       else if(loaddata.SchedExportTime == 4)
           Schedule_data =+ "12 Hours";
       else if(loaddata.SchedExportTime == 5)
           Schedule_data =+ "24 Hours";
       if(loaddata.SchedExportDev == 0 )
           Schedule_data.append(" to Front SD");
       else if(loaddata.SchedExportDev == 1)
            Schedule_data.append(" to USB1");
       else if(loaddata.SchedExportDev == 2)
            Schedule_data.append(" to USB2");
       originalString2 = Schedule_info.arg(Schedule_data);
   }
   else
       originalString2 = Schedule_info.arg("Inactive");

   QString Media_data = "Media full in:	NA\n";
   QString FTP_Data = "FTP Export Req in:	>1 year\n";
   QString pritriggerIsEnable = "Not Active";
   loadInfoStructureFromFile(LOG_INFO_FILE,mt_PEN);
   for(int i = 0;i< V6_MAX_PENS ;i++)
        {
       if(mt_PEN[i] != NULL){
          if( mt_PEN[i]->PenLog.PretriggerEn  == 1)
            {
             pritriggerIsEnable = "Acquiring";
             break;
            }
       }
        }

   QString Pre_Trigger_status = "Pre-Trigger status:	%1";
   QString Pre_Trigger_status1 = Pre_Trigger_status.arg(pritriggerIsEnable);
   QString originalString1 = Recording.arg(noOfPensInLogging);
   ui->textEdit_4->setText(originalString1+Export+originalString2+Media_data+FTP_Data+Pre_Trigger_status1);
   ui->textEdit_4->setReadOnly(true);
   ui->stackedWidget->setCurrentIndex(25);
}

void MainWindow::on_toolButton_672_clicked()
{
    ui->stackedWidget->setCurrentIndex(22);
}

void MainWindow::on_toolButton_127_clicked()
{
   ui->stackedWidget->setCurrentIndex(23);
}

void MainWindow::on_toolButton_128_clicked()
{
   ui->stackedWidget->setCurrentIndex(24);
}

void MainWindow::on_toolButton_129_clicked()
{
   ui->stackedWidget->setCurrentIndex(21);
}

void MainWindow::on_toolButton_131_clicked()
{
 ui->stackedWidget->setCurrentIndex(25);
}

void MainWindow::on_toolButton_215_clicked()
{
   ui->stackedWidget->setCurrentIndex(22);
}

void MainWindow::on_toolButton_216_clicked()
{
 ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_toolButton_366_clicked()
{
    ui->stackedWidget->setCurrentIndex(22);
}

void MainWindow::on_toolButton_364_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_toolButton_674_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_toolButton_675_clicked()
{
     ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_toolButton_519_clicked()
{
    ui->stackedWidget->setCurrentIndex(22);
}

void MainWindow::on_toolButton_517_clicked()
{
     ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_toolButton_56_clicked()
{
    ui->stackedWidget->setCurrentIndex(26);
}


void MainWindow::on_EDIT_SETUP_EDIT_RECORDING_EXPORT_BOTTON_BAR_Back_clicked()
{
    QModelIndex index0 = model13->index(0, 1, QModelIndex());
    QModelIndex index1 = model13->index(1, 1, QModelIndex());
    QString cellText0 = index0.data().toString();
    QString cellText1 = index1.data().toString();
    if(cellText0 == "Enabled")
        loaddata.Encrypt = 1;
    else
        loaddata.Encrypt = 0;
    if(cellText1 == "Enabled")
        loaddata.CSV = 1;
    else
         loaddata.CSV = 0;
    saveStructureToFile(LOG_CONFIG_FILE,loaddata);

    ui->stackedWidget->setCurrentIndex(11);
}

void MainWindow::on_EDIT_SETUP_EDIT_RECORDING_EXPORT_BOTTON_BAR_Finish_clicked()
{
    QModelIndex index0 = model13->index(0, 1, QModelIndex());
    QModelIndex index1 = model13->index(1, 1, QModelIndex());
    QString cellText0 = index0.data().toString();
    QString cellText1 = index1.data().toString();
    if(cellText0 == "Enabled")
        loaddata.Encrypt = 1;
    else
        loaddata.Encrypt = 0;
    if(cellText1 == "Enabled")
        loaddata.CSV = 1;
    else
        loaddata.CSV = 0;
    saveStructureToFile(LOG_CONFIG_FILE,loaddata);
      ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_toolButton_76_clicked()
{
  model14 = new QStandardItemModel(5, 2, this);
  ui->EDIT_SETUP_EDIT_RECORDING_SCHEDULED_Tableview->setModel(model14);
  ui->EDIT_SETUP_EDIT_RECORDING_SCHEDULED_Tableview->setColumnWidth(0, 250);
  ui->EDIT_SETUP_EDIT_RECORDING_SCHEDULED_Tableview->setColumnWidth(1, 400);
  ui->EDIT_SETUP_EDIT_RECORDING_SCHEDULED_Tableview->horizontalHeader()->hide();
  ui->EDIT_SETUP_EDIT_RECORDING_SCHEDULED_Tableview->verticalHeader()->hide();

  // Set up the stylesheet for EDIT_SETUP_EDIT_RECORDING_SCHEDULED_Tableview
  ui->EDIT_SETUP_EDIT_RECORDING_SCHEDULED_Tableview->setStyleSheet(
                                  "QTableView::item {"
                                  "border: 1px solid black;"
                                  "border-radius: 5px;"
                                  "background-color: rgb(255, 255, 127);"
                                  "color: black;"
                                  "}"
                                 "QTableView::item[selected='true'] {"
                                     "background-color: gray;"
                                     "color: black;"
                                     "}"


                              );
  // Set the data for each item in the model


  QString SE,ED,UP,LM,MCH;
  if(loaddata.DoSchedExport == 0)
  {
      SE = "Disabled";
      ED = "NA";
      UP = "30 Minutes";
      LM = "Disabled";
      MCH = "Disabled";
  }
  if(loaddata.DoSchedExport == 1)
  {
      SE = "Enabled";
      if(loaddata.LogMessage == 1)
      {
          LM = "Enabled";
          MCH = "Enabled";
      }
      else
      {
          LM = "Disabled";
          MCH = "Disabled";
      }
      switch(loaddata.SchedExportDev)
      {
      case 0:
      {
            ED = "Front SD";
            break;
      }
      case 1:
      {
          ED = "USB1";
          break;
      }
      case 2:
      {
          ED = "USB2";
          break;
      }
      default:
           break;
      }
      switch(loaddata.SchedExportTime)
      {
      case 0:
      {
            UP = "10 Minutes";
            break;
      }
      case 1:
      {
          UP = "30 Minutes";
          break;
      }
      case 2:
      {
          UP = "1 Hour";
          break;
      }
      case 3:
      {
          UP = "2 Hours";
          break;
      }
      case 4:
      {
          UP = "12 Hours";
          break;
      }
      case 5:
      {
          UP = "24 Hours";
          break;
      }
      default:
           break;
      }
  }
  QStringList row1Data = {"Schedule Export", SE};
  QStringList row2Data = {"Export Device", ED};
  QStringList row3Data = {"Update Period", UP};
  QStringList row4Data = {"Log Messages", LM};
  QStringList row5Data = {"Mark Chart", MCH};



  QList<QStringList> rowData = {row1Data, row2Data, row3Data, row4Data, row5Data};

  for (int row = 0; row < 5; ++row) {
      for (int col = 0; col < 2; ++col) {
          QModelIndex index = model14->index(row, col, QModelIndex());
          QStandardItem *my_item = model14->itemFromIndex(index);

          // Set the values for each column
          model14->setData(index, rowData[row][col]);

          if(row != 0)
          {
              // qDebug()<<row<<"  "<<col;
               QStandardItem *item = model14->itemFromIndex(index);
               item->setEnabled(false);
               item->setEditable(false);


          }
          // Set the background color for all cells except the first row
          if (row != 0) {
              my_item->setBackground(Qt::gray);

          }
      }
  }

  // Set row heights
  for (int i = 0; i < 5; ++i) {
      ui->EDIT_SETUP_EDIT_RECORDING_SCHEDULED_Tableview->setRowHeight(i, 40);
  }
      ui->stackedWidget->setCurrentIndex(27);


}

void MainWindow::on_EDIT_SETUP_EDIT_RECORDING_SCHEDULED_BOTTOM_BAR_Back_clicked()
{
    QModelIndex index = model14->index(0, 1, QModelIndex());
    QModelIndex index1 = model14->index(1, 1, QModelIndex());
    QModelIndex index2 = model14->index(2, 1, QModelIndex());
    QModelIndex index3 = model14->index(3, 1, QModelIndex());

    QString cellText = index.data().toString();
    QString cellText1 = index1.data().toString();
    QString cellText2 = index2.data().toString();
    QString cellText3 = index3.data().toString();
    if(cellText == "Disabled")
    {
        loaddata.DoSchedExport = 0;
        loaddata.SchedExportDev = 0;
        loaddata.SchedExportTime = 1;
        loaddata.LogMessage = 0;
        loaddata.MarkChart = 0;
    }
    if(cellText == "Enabled")
    {
        loaddata.DoSchedExport = 1;
        if(cellText3 == "Enabled")
        {
            loaddata.LogMessage = 1;
            loaddata.MarkChart = 1;
        }
        else
        {
            loaddata.LogMessage = 0;
            loaddata.MarkChart = 0;
        }
        if(cellText1 == "Front SD")
            loaddata.SchedExportDev = 0;
        else if(cellText1 == "USB1")
            loaddata.SchedExportDev = 1;
        else if(cellText1 == "USB2")
            loaddata.SchedExportDev = 2;
        if(cellText2 == "10 Minutes")
            loaddata.SchedExportTime = 0;
        else if(cellText2 == "30 Minutes")
            loaddata.SchedExportTime = 1;
        else if(cellText2 == "1 Hour")
            loaddata.SchedExportTime = 2;
        else if(cellText2 == "2 Hours")
            loaddata.SchedExportTime = 3;
        else if(cellText2 == "12 Hours")
            loaddata.SchedExportTime = 4;
        else if(cellText2 == "24 Hours")
            loaddata.SchedExportTime = 5;
     }
    saveStructureToFile(LOG_CONFIG_FILE,loaddata);
     ui->stackedWidget->setCurrentIndex(11);
}

void MainWindow::on_EDIT_SETUP_EDIT_RECORDING_SCHEDULED_BOTTOM_BAR_Finish_clicked()
{
    QModelIndex index = model14->index(0, 1, QModelIndex());
    QModelIndex index1 = model14->index(1, 1, QModelIndex());
    QModelIndex index2 = model14->index(2, 1, QModelIndex());
    QModelIndex index3 = model14->index(3, 1, QModelIndex());

    QString cellText = index.data().toString();
    QString cellText1 = index1.data().toString();
    QString cellText2 = index2.data().toString();
    QString cellText3 = index3.data().toString();
    if(cellText == "Disabled")
    {
        loaddata.DoSchedExport = 0;
        loaddata.SchedExportDev = 0;
        loaddata.SchedExportTime = 1;
        loaddata.LogMessage = 0;
        loaddata.MarkChart = 0;
    }
    if(cellText == "Enabled")
    {
        loaddata.DoSchedExport = 1;
        if(cellText3 == "Enabled")
        {
            loaddata.LogMessage = 1;
            loaddata.MarkChart = 1;
        }
        else
        {
            loaddata.LogMessage = 0;
            loaddata.MarkChart = 0;
        }
        if(cellText1 == "Front SD")
            loaddata.SchedExportDev = 0;
        else if(cellText1 == "USB1")
            loaddata.SchedExportDev = 1;
        else if(cellText1 == "USB2")
            loaddata.SchedExportDev = 2;
        if(cellText2 == "10 Minutes")
            loaddata.SchedExportTime = 0;
        else if(cellText2 == "30 Minutes")
            loaddata.SchedExportTime = 1;
        else if(cellText2 == "1 Hour")
            loaddata.SchedExportTime = 2;
        else if(cellText2 == "2 Hours")
            loaddata.SchedExportTime = 3;
        else if(cellText2 == "12 Hours")
            loaddata.SchedExportTime = 4;
        else if(cellText2 == "24 Hours")
            loaddata.SchedExportTime = 5;
     }
    saveStructureToFile(LOG_CONFIG_FILE,loaddata);
     ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_EDIT_SETUP_EDIT_RECORDING_EXPORT_TOP_BAR_Edit_Setup_clicked()
{
    QModelIndex index0 = model13->index(0, 1, QModelIndex());
    QModelIndex index1 = model13->index(1, 1, QModelIndex());
    QString cellText0 = index0.data().toString();
    QString cellText1 = index1.data().toString();
    if(cellText0 == "Enabled")
        loaddata.Encrypt = 1;
    else
        loaddata.Encrypt = 0;
    if(cellText1 == "Enabled")
        loaddata.CSV = 1;
    else
         loaddata.CSV = 0;
    saveStructureToFile(LOG_CONFIG_FILE,loaddata);
    ui->stackedWidget->setCurrentIndex(3);
}

void MainWindow::on_EDIT_SETUP_EDIT_RECORDING_EXPORT_TOP_BAR_Edit_Recordings_clicked()
{
    QModelIndex index0 = model13->index(0, 1, QModelIndex());
    QModelIndex index1 = model13->index(1, 1, QModelIndex());
    QString cellText0 = index0.data().toString();
    QString cellText1 = index1.data().toString();
    if(cellText0 == "Enabled")
        loaddata.Encrypt = 1;
    else
        loaddata.Encrypt = 0;
    if(cellText1 == "Enabled")
        loaddata.CSV = 1;
    else
         loaddata.CSV = 0;
    saveStructureToFile(LOG_CONFIG_FILE,loaddata);
    ui->stackedWidget->setCurrentIndex(11);
}

void MainWindow::on_EDIT_SETUP_EDIT_RECORDING_SCHEDULED_TOP_BAR_Edit_Setup_clicked()
{
    QModelIndex index = model14->index(0, 1, QModelIndex());
    QModelIndex index1 = model14->index(1, 1, QModelIndex());
    QModelIndex index2 = model14->index(2, 1, QModelIndex());
    QModelIndex index3 = model14->index(3, 1, QModelIndex());

    QString cellText = index.data().toString();
    QString cellText1 = index1.data().toString();
    QString cellText2 = index2.data().toString();
    QString cellText3 = index3.data().toString();
    if(cellText == "Disabled")
    {
        loaddata.DoSchedExport = 0;
        loaddata.SchedExportDev = 0;
        loaddata.SchedExportTime = 1;
        loaddata.LogMessage = 0;
        loaddata.MarkChart = 0;
    }
    if(cellText == "Enabled")
    {
        loaddata.DoSchedExport = 1;
        if(cellText3 == "Enabled")
        {
            loaddata.LogMessage = 1;
            loaddata.MarkChart = 1;
        }
        else
        {
            loaddata.LogMessage = 0;
            loaddata.MarkChart = 0;
        }
        if(cellText1 == "Front SD")
            loaddata.SchedExportDev = 0;
        else if(cellText1 == "USB1")
            loaddata.SchedExportDev = 1;
        else if(cellText1 == "USB2")
            loaddata.SchedExportDev = 2;
        if(cellText2 == "10 Minutes")
            loaddata.SchedExportTime = 0;
        else if(cellText2 == "30 Minutes")
            loaddata.SchedExportTime = 1;
        else if(cellText2 == "1 Hour")
            loaddata.SchedExportTime = 2;
        else if(cellText2 == "2 Hours")
            loaddata.SchedExportTime = 3;
        else if(cellText2 == "12 Hours")
            loaddata.SchedExportTime = 4;
        else if(cellText2 == "24 Hours")
            loaddata.SchedExportTime = 5;
     }
    saveStructureToFile(LOG_CONFIG_FILE,loaddata);
    ui->stackedWidget->setCurrentIndex(3);

}

void MainWindow::on_EDIT_SETUP_EDIT_RECORDING_SCHEDULED_TOP_BAR_Edit_Recording_clicked()
{
    QModelIndex index = model14->index(0, 1, QModelIndex());
    QModelIndex index1 = model14->index(1, 1, QModelIndex());
    QModelIndex index2 = model14->index(2, 1, QModelIndex());
    QModelIndex index3 = model14->index(3, 1, QModelIndex());

    QString cellText = index.data().toString();
    QString cellText1 = index1.data().toString();
    QString cellText2 = index2.data().toString();
    QString cellText3 = index3.data().toString();
    if(cellText == "Disabled")
    {
        loaddata.DoSchedExport = 0;
        loaddata.SchedExportDev = 0;
        loaddata.SchedExportTime = 1;
        loaddata.LogMessage = 0;
        loaddata.MarkChart = 0;
    }
    if(cellText == "Enabled")
    {
        loaddata.DoSchedExport = 1;
        if(cellText3 == "Enabled")
        {
            loaddata.LogMessage = 1;
            loaddata.MarkChart = 1;
        }
        else
        {
            loaddata.LogMessage = 0;
            loaddata.MarkChart = 0;
        }
        if(cellText1 == "Front SD")
            loaddata.SchedExportDev = 0;
        else if(cellText1 == "USB1")
            loaddata.SchedExportDev = 1;
        else if(cellText1 == "USB2")
            loaddata.SchedExportDev = 2;
        if(cellText2 == "10 Minutes")
            loaddata.SchedExportTime = 0;
        else if(cellText2 == "30 Minutes")
            loaddata.SchedExportTime = 1;
        else if(cellText2 == "1 Hour")
            loaddata.SchedExportTime = 2;
        else if(cellText2 == "2 Hours")
            loaddata.SchedExportTime = 3;
        else if(cellText2 == "12 Hours")
            loaddata.SchedExportTime = 4;
        else if(cellText2 == "24 Hours")
            loaddata.SchedExportTime = 5;
     }
    saveStructureToFile(LOG_CONFIG_FILE,loaddata);
    ui->stackedWidget->setCurrentIndex(11);
}

void MainWindow::on_EDIT_SETUP_FIELDIO_ANALOGIN_INDEX_1_Tableview_clicked(const QModelIndex &index)
{
    QString t =index.data().toString();
    QModelIndex index5 = model20->index(1,1,QModelIndex());
    if(index5.data().toString()=="Volts")
    {
    if(t== "User Defined")
    {
        ui->stackedWidget->setCurrentIndex(16);
        QModelIndex index999 = model6->index(1,1,QModelIndex());
        model6->setData(index999,"Volts");
        QModelIndex index5 = model6->index(4,1,QModelIndex());
        model6->setData(index5, "(+/-)100mV ");

    }
    }
    if(t=="V" || t== "mV")
    {
        Voltage_units Voltage_units;
        Voltage_units.setModal(true);
        Voltage_units.exec();
        QModelIndex index5 = model20->index(4,1,QModelIndex());
        model20->setData(index5, volt1_text[ai_ch_no]);
    }

    if((t== "Volts") || (t== "Amps")|| (t== "Ohms")|| (t== "RT")|| (t== "TC"))
    {
        Type type;
        type.setModal(true);
        type.exec();
        QModelIndex index1 = model20->index(1,1,QModelIndex());
        model20->setData(index1,volt_val[ai_ch_no]);
    }

    QModelIndex index66 = model20->index(1,1,QModelIndex());

    if(index66.data().toString()=="Amps")
    {
        ui->stackedWidget->setCurrentIndex(30);
        QModelIndex index666 = model22->index(1,1,QModelIndex());
        model22->setData(index666,"Amps");
    }

    QString  x=index.data().toString();
    int row=index.row();
    int col=index.column();
    if(
            (x=="High Limit")
            || (row==5 && col ==1)
            )
    {
    VoltsValueSelection VoltsValueSelection;
    VoltsValueSelection.setModal(true);
    VoltsValueSelection.exec();
    QModelIndex index666 = model20->index(5,1,QModelIndex());
    model20->setData(index666,keyboard_text);
    }
    if(
            (x=="Lower Limit")
            || (row==6 && col ==1)
            )
    {
    VoltsValueSelection VoltsValueSelection;
    VoltsValueSelection.setModal(true);
    VoltsValueSelection.exec();
    QModelIndex index666 = model20->index(6,1,QModelIndex());
    model20->setData(index666,keyboard_text);
    }
    if(
            (x=="Damp Level")
            || (row==7 && col ==1)
            )
    {
    VoltsValueSelection VoltsValueSelection;
    VoltsValueSelection.setModal(true);
    VoltsValueSelection.exec();
    QModelIndex index666 = model20->index(7,1,QModelIndex());
    model20->setData(index666,keyboard_text);
    }
}
void MainWindow::on_EDIT_SETUP_FIELDIO_ANALOGIN_INDEX_1_BOTTOM_BAR_Back_clicked()
{
   ui->stackedWidget->setCurrentIndex(15);
}

void MainWindow::on_EDIT_SETUP_FIELDIO_ANALOGIN_INDEX_2_BOTTOM_BAR_CopyTo_clicked()
{


}

void MainWindow::on_EDIT_SETUP_FIELDIO_ANALOGIN_INDEX_2_Tableview_clicked(const QModelIndex &index)
{
    QString t =index.data().toString();
    if((t== "Volts") || (t== "Amps")|| (t== "Ohms")|| (t== "RT")|| (t== "TC"))
    {
        Type type;
        type.setModal(true);
        type.exec();
        QModelIndex index1 = model21->index(1,1,QModelIndex());
        model21->setData(index1,volt_val[ai_ch_no]);
    }

    QModelIndex index44 = model21->index(1,1,QModelIndex());
    if(index44.data().toString() == "Volts")
    {
        ui->stackedWidget->setCurrentIndex(28);
    }

    int row=index.row();
    int col=index.column();
    QString x= index.data().toString();
    if(
            (x=="High Limit")
            || (row==4 && col ==1)
            )
    {
    VoltsValueSelection VoltsValueSelection;
    VoltsValueSelection.setModal(true);
    VoltsValueSelection.exec();
    QModelIndex index666 = model21->index(4,1,QModelIndex());
    model21->setData(index666,keyboard_text);
    }
    if(
            (x=="Lower Limit")
            || (row==5 && col ==1)
            )
    {
    VoltsValueSelection VoltsValueSelection;
    VoltsValueSelection.setModal(true);
    VoltsValueSelection.exec();
    QModelIndex index666 = model21->index(5,1,QModelIndex());
    model21->setData(index666,keyboard_text);
    }
    if(
            (x=="Damp Level")
            || (row==6 && col ==1)
            )
    {
    VoltsValueSelection VoltsValueSelection;
    VoltsValueSelection.setModal(true);
    VoltsValueSelection.exec();
    QModelIndex index666 = model21->index(6,1,QModelIndex());
    model21->setData(index666,keyboard_text);
    }
    QModelIndex index23=model21->index(1,1,QModelIndex());
    if(index23.data().toString()=="Amps")
    {
        if(t=="User Defined")
        {
            ui->stackedWidget->setCurrentIndex(16);
        }
    }
}

void MainWindow::on_EDIT_SETUP_FIELD_IO_ANALOG_IN_INDEX_Tableview_clicked(const QModelIndex &index)
{
    QString t = index.data().toString();

    if((t== "Volts") || (t== "Amps")|| (t== "Ohms")|| (t== "RT")|| (t== "TC"))
    {
        Type type;
        type.setModal(true);
        type.exec();
        QModelIndex index1 = model22->index(1,1,QModelIndex());
        model22->setData(index1,volt_val[ai_ch_no]);
    }

    int row=index.row();
    int col=index.column();
    QString x= index.data().toString();
    if(
            (x=="High Limit")
            || (row==4 && col ==1)
            )
    {
    VoltsValueSelection VoltsValueSelection;
    VoltsValueSelection.setModal(true);
    VoltsValueSelection.exec();
    QModelIndex index666 = model22->index(4,1,QModelIndex());
    model22->setData(index666,keyboard_text);
    }
    if(
            (x=="Lower Limit")
            || (row==5 && col ==1)
            )
    {
    VoltsValueSelection VoltsValueSelection;
    VoltsValueSelection.setModal(true);
    VoltsValueSelection.exec();
    QModelIndex index666 = model22->index(5,1,QModelIndex());
    model22->setData(index666,keyboard_text);
    }
    if(
            (x=="Damp Level")
            || (row==6 && col ==1)
            )
    {
    VoltsValueSelection VoltsValueSelection;
    VoltsValueSelection.setModal(true);
    VoltsValueSelection.exec();
    QModelIndex index666 = model22->index(6,1,QModelIndex());
    model22->setData(index666,keyboard_text);
    }
    QModelIndex index23 = model22->index(1,1,QModelIndex());
    if(index23.data().toString()=="Volts")
    {
        ui->stackedWidget->setCurrentIndex(28);
        QModelIndex index666 = model20->index(1,1,QModelIndex());
        model20->setData(index666,"Volts");
    }
    QModelIndex index234=model22->index(1,1,QModelIndex());
    if(index234.data().toString()=="Amps")
    {
        if(t=="User Defined")
        {
            ui->stackedWidget->setCurrentIndex(16);
            QModelIndex index5 = model6->index(1,1,QModelIndex());
            model6->setData(index5, "Amps");
            QModelIndex index51 = model6->index(4,1,QModelIndex());
            model6->setData(index51, "0-20mA");

        }
    }

}


void MainWindow::on_EDIT_SETUP_FIELD_IO_ANALOG_IN_INDEX_BOTTOM_BAR_Back_clicked()
{
    ui->stackedWidget->setCurrentIndex(15);
}

void MainWindow::on_EDIT_SETUP_FIELDIO_ANALOGIN_INDEX_2_BOTTOM_BAR_Back_clicked()
{
    ui->stackedWidget->setCurrentIndex(15);
}

void MainWindow::on_EDIT_SETUP_FIELDIO_ANALOGIN_INDEX_2_BOTTOM_BAR_Finish_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(1);
}

void MainWindow::on_EDIT_SETUP_FIELD_IO_ANALOG_IN_INDEX_BOTTOM_BAR_Finish_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(1);
}

void MainWindow::on_EDIT_SETUP_FIELDIO_ANALOGIN_INDEX_1_BOTTOM_BAR_Finish_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(1);
}
//connect(ui->m_kProcessBtn,&QPushButton::released, [pMainMenu](){pMainMenu->OnMainMenuDlgProcessBtn();});
void MainWindow::/*toolButton_18*/OnMainMenuDlgProcessBtn()
{
   ui->stackedWidget->setCurrentIndex(35);
}

void MainWindow::on_toolButton_91_clicked()
{
    ui->stackedWidget->setCurrentIndex(36);
}

void MainWindow::on_toolButton_93_clicked()
{
   ui->stackedWidget->setCurrentIndex(37);
}

void MainWindow::on_toolButton_94_clicked()
{
    ui->stackedWidget->setCurrentIndex(38);
}

void MainWindow::on_toolButton_95_clicked()
{
    ui->stackedWidget->setCurrentIndex(39);
}

void MainWindow::on_toolButton_38_clicked()
{
    ui->stackedWidget->setCurrentIndex(172);
}

void MainWindow::on_EDIT_LAYOUT_SCREENS_INDEX_Tableview_clicked(const QModelIndex &index)
{
    QString celltext = index.data().toString();
     cellText4 = index.row();
     if(celltext == "Chart and DPMs")
     {
         screen_template_type_selection screen_template_type_selection;
         screen_template_type_selection.setModal(true);
         screen_template_type_selection.exec();
     }
    // if(screen_type == 1)
    // {
    //    ui->stackedWidget->setCurrentIndex(24);
    //    ui->verticalLayout_29->addWidget(mPlot);
    //    ui->verticalLayout_29->addWidget(Frame);
    //    ui->verticalLayout_29->removeWidget(window1);

    // }
     if(screen_type == 2)
     {
         ui->stackedWidget->setCurrentIndex(41);
         ui->stackedWidget_3->setCurrentIndex(1);
     }
     if(screen_type == 3)
     {
         QModelIndex index662 = model83->index(2,1,QModelIndex());
         model83->setData(index662,"Tabular");
         ui->stackedWidget_3->setCurrentIndex(2);
         ui->stackedWidget->setCurrentIndex(34);
     }
     if(celltext == "Tabular")
     {
         screen_template_type_selection screen_template_type_selection;
         screen_template_type_selection.setModal(true);
         screen_template_type_selection.exec();
     }
     if(cellText4 == 4)
     {
//         plotwindow1;
//         plotwindow2;
//         plotgridLayout;
 //        ui->SELECT_PENS_DLG_VERTICAL_LAYOUT->addWidget(maxminwindow2);


         int maxpens =96;
         int i=0;

                     for (int index = 1;index <= maxpens;index++)
                     {
                         if(mt_PEN[index] != NULL)
                         {
                         if(index >= 0 && index < maxpens)
                         {
                             QString search_pen1 = "Pen";
                             search_pen1.append(QVariant(index).toString());
                             QPushButton * search_pen_btn = plotwindow1->findChild<QPushButton*>(search_pen1);

                             if(search_pen_btn == 0x0)
                             {
                                // for (int i = 0; i < totalButtons; ++i)

     //                                        QPushButton *button = new QPushButton("Button " + QString::number(index));
                                 QPushButton *buttonmaxmin = new QPushButton(QString::number(index));

                                     buttonmaxmin->setObjectName("Pen" + QString :: number(index));

                                     buttonmaxmin->setStyleSheet("color:black;text-align:center;border-style: solid;border-color: black;font-size: 22px;border-width: 1px;border-radius: 3px;border-style: outset;");
                                     buttonmaxmin->setCheckable(true);
     //                                        button->setMinimumSize(QSize(256, 118));
     //                                        button->setMaximumSize(QSize(256, 118));
                                     buttonmaxmin->setMinimumSize(QSize(80, 50));
                                     buttonmaxmin->setMaximumSize(QSize(80, 50));
                                     //button->hide();



                                     int row = i / 10;  // Calculate the row based on button count



                                     int col = i % 10;  // Calculate the column based on button count



                                     plotgridLayout->addWidget(buttonmaxmin, row, col,{Qt::AlignTop, Qt::AlignLeft});

                                     i++;


                                     //when buttons are clicked
                                     QObject::connect(buttonmaxmin,&QPushButton::clicked,[=]()
                                     {

                                        // qDebug()<<buttonmaxmin->text();
                                         //qDebug()<<buttonmaxmin->objectName();
                                         if(buttonmaxmin->isChecked()==true)
                                         {
                                             buttonmaxmin->setStyleSheet(":checked {color:black;text-align:center;border-style: solid;border-color: blue;font-size: 22px;border-width: 5px;border-radius: 3px;}");
                                           selected_pens << QString(buttonmaxmin->text()).toInt();
                                           //qDebug()<<selected_pens;
                                         }
                                         else if (buttonmaxmin->isChecked()==false)
                                         {
                                             buttonmaxmin->setStyleSheet("color:black;text-align:center;border-style: solid;border-color: black;font-size: 22px;border-width: 1px;border-radius: 3px;border-style: outset;");
                                             selected_pens.removeAll(QString(buttonmaxmin->text()).toInt());
                                             QString selectedpenobject = "Pen";
                                             selectedpenobject.append(buttonmaxmin->text());
                                            // qDebug()<<"remove"<<selectedpenobject;
                                             QLabel * targetlabel = Frame->findChild<QLabel*>(selectedpenobject);
                                             HLayout->removeWidget(targetlabel);
                                             delete targetlabel;
                                           //qDebug()<<selected_pens;

                                         }
                                     });



                                }
                         }
                     }
                     }


        ui->stackedWidget->setCurrentIndex(40);
     }





}

void MainWindow::on_EDIT_LAYOUT_SCREENS_INDEX_2_Tableview_clicked(const QModelIndex &index)
{
    QString celltext = index.data().toString();
     cellText4 = index.row();
     if(celltext == "MaxMin")
     {
         screen_template_type_selection screen_template_type_selection;
         screen_template_type_selection.setModal(true);
         screen_template_type_selection.exec();
     }
     if(screen_type == 1)
     {

        ui->stackedWidget_3->setCurrentIndex(0);
        ui->stackedWidget->setCurrentIndex(34);
     }
     if(screen_type == 3)
     {
         QModelIndex index662 = model83->index(2,1,QModelIndex());
         model83->setData(index662,"Tabular");
         ui->stackedWidget_3->setCurrentIndex(2);
//         ui->stackedWidget->setCurrentIndex(34);
     }
//     if(celltext == "Tabular")
//     {
//         screen_template_type_selection screen_template_type_selection;
//         screen_template_type_selection.setModal(true);
//         screen_template_type_selection.exec();
//     }
    // else if(screen_type == 2)
    // {
    //     ui->stackedWidget->setCurrentIndex(31);
    //     ui->verticalLayout_29->removeWidget(mPlot);
    //     ui->verticalLayout_29->removeWidget(Frame);
    //    ui->verticalLayout_29->addWidget(window1);
    // }
     if(cellText4 == 4)
     {
    //           ui->SELECT_PENS_TABLE_VERTICAL_LAYOUT->addWidget(maxminwindow2);
        int maxpens =96;
        int i=0;

                    for (int index = 1;index <= maxpens;index++)
                    {
                        if(mt_PEN[index] != NULL)
                        {
                        if(index >= 0 && index < maxpens)
                        {
                            QString search_pen1 = "Pen";
                            search_pen1.append(QVariant(index).toString());
                            QPushButton * search_pen_btn = maxminwindow1->findChild<QPushButton*>(search_pen1);

                            if(search_pen_btn == 0x0)
                            {
                               // for (int i = 0; i < totalButtons; ++i)

    //                                        QPushButton *button = new QPushButton("Button " + QString::number(index));
                                QPushButton *buttonmaxmin = new QPushButton(QString::number(index));

                                    buttonmaxmin->setObjectName("Pen" + QString :: number(index));

                                    buttonmaxmin->setStyleSheet("color:black;text-align:center;border-style: solid;border-color: black;font-size: 22px;border-width: 1px;border-radius: 3px;border-style: outset;");
                                    buttonmaxmin->setCheckable(true);
    //                                        button->setMinimumSize(QSize(256, 118));
    //                                        button->setMaximumSize(QSize(256, 118));
                                    buttonmaxmin->setMinimumSize(QSize(80, 50));
                                    buttonmaxmin->setMaximumSize(QSize(80, 50));
                                    //button->hide();



                                    int row = i / 10;  // Calculate the row based on button count



                                    int col = i % 10;  // Calculate the column based on button count



                                    maxmingridLayout->addWidget(buttonmaxmin, row, col,{Qt::AlignTop, Qt::AlignLeft});

                                    i++;


                                    //when buttons are clicked
                                    QObject::connect(buttonmaxmin,&QPushButton::clicked,[=]()
                                    {

                                       // qDebug()<<buttonmaxmin->text();
                                        //qDebug()<<buttonmaxmin->objectName();
                                        if(buttonmaxmin->isChecked()==true)
                                        {
                                            //buttonmaxmin->setStyleSheet(":checked {border: blue;}");
                                            buttonmaxmin->setStyleSheet(":checked {color:black;text-align:center;border-style: solid;border-color: blue;font-size: 22px;border-width: 5px;border-radius: 3px;}");
                                          selected_MaxMin_pens << QString(buttonmaxmin->text()).toInt();
                                          //qDebug()<<selected_MaxMin_pens;
                                        }
                                        else if (buttonmaxmin->isChecked()==false)
                                        {
                                           buttonmaxmin->setStyleSheet("color:black;text-align:center;border-style: solid;border-color: black;font-size: 22px;border-width: 1px;border-radius: 3px;border-style: outset;");

                                            selected_MaxMin_pens.removeAll(QString(buttonmaxmin->text()).toInt());

                                         // qDebug()<<selected_MaxMin_pens;

                                        }
                                    });



                               }
                        }
                    }
                    }

        ui->stackedWidget->setCurrentIndex(42);
     }

}

void MainWindow::on_toolButton_78_clicked()
{
    ui->stackedWidget->setCurrentIndex(33);
}

void MainWindow::on_toolButton_79_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(1);
}

void MainWindow::on_EDIT_LAYOUT_BOTTOM_BAR_Back_clicked()
{
    ui->stackedWidget->setCurrentIndex(32);
}

void MainWindow::on_EDIT_LAYOUT_TOP_BAR_Edit_Layout_clicked()
{
   ui->stackedWidget->setCurrentIndex(32);
}

void MainWindow::on_EDIT_LAYOUT_SCREENS_INDEX_TOP_BAR_Edit_Layout_clicked()
{
    ui->stackedWidget->setCurrentIndex(32);
}

void MainWindow::on_EDIT_LAYOUT_SCREENS_INDEX_2_TOP_BAR_Edit_Layout_clicked()
{
    ui->stackedWidget->setCurrentIndex(32);
}

void MainWindow::on_EDIT_LAYOUT_BOTTOM_BAR_Finish_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(1);
}

void MainWindow::on_EDIT_LAYOUT_SCREENS_INDEX_BOTTOM_BAR_Finish_clicked()
{
    initial=0;
    ui->stackedWidget_2->setCurrentIndex(1);
}

void MainWindow::on_toolButton_90_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(1);
}

void MainWindow::on_EDIT_LAYOUT_SCREENS_INDEX_2_BOTTOM_BAR_Finish_clicked()
{
    initial=0;
    ui->stackedWidget_2->setCurrentIndex(1);
}

void MainWindow::on_SELECT_PENS_DLG_BOTTOM_BAR_Clear_clicked()
{
    for (int var = 0; var <selected_pens.size(); ++var)
    {
        //selected_pens.removeAll(selected_pens[var]);
        QString selectedpenobject = "Pen";
        selectedpenobject.append(QVariant(selected_pens[var]).toString());
       // qDebug()<<"remove"<<selectedpenobject;
        QLabel * targetlabel2 = Frame->findChild<QLabel*>(selectedpenobject);
        QPushButton * uncheckbutton = plotwindow1->findChild<QPushButton*>(selectedpenobject);
        uncheckbutton->setStyleSheet("color:black;text-align:center;border-style: solid;border-color: black;font-size: 22px;border-width: 1px;border-radius: 3px;border-style: outset;");
        uncheckbutton->setChecked(false);
        HLayout->removeWidget(targetlabel2);
        delete targetlabel2;
    }

//    ui->pushButton_116->setChecked(false);
//    ui->pushButton_117->setChecked(false);
//    ui->pushButton_118->setChecked(false);
//    ui->pushButton_121->setChecked(false);

    selected_pens.clear();
   // qDebug()<<"cleared size,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,"<<selected_pens.size();



}

void MainWindow::on_SELECT_PENS_DLG_BOTTOM_BAR_Add_clicked()
{
    //EnAcqFlag =1;
    if(selected_pens.size() == 0)
    {
        ui->stackedWidget->setCurrentIndex(34);
    }
    if(selected_pens.size() > 0 && selected_pens.size()<=8 )
        {
                for (int index : selected_pens)
                {

                    if(index >= 0 && index < pen_names.size())
                    {
                        QString search_pen = "Pen";
                        search_pen.append(QVariant(index).toString());
                        QLabel * search_penlabel = Frame->findChild<QLabel*>(search_pen);

                        if(search_penlabel == 0x0)
                        {
                            QLabel *pen_data = new QLabel(pen_names.at(index));
                            //pen_data->setText(pen_data->text()+"\npenvalue\t %");
                           pen_data->setStyleSheet("border : 1px solid black;");
                                                    pen_data->setAlignment(Qt::AlignCenter);
                            pen_data->setObjectName("Pen"+QString::number(index));

                            HLayout->addWidget(pen_data);
                        }
                    }

                }

        ui->stackedWidget->setCurrentIndex(34);
        }
}

void MainWindow::on_SELECT_PENS_DLG_BOTTOM_BAR_Delete_clicked()
{
    ui->stackedWidget->setCurrentIndex(34);
}

void MainWindow::on_pushButton_116_clicked()
{
//    //here eg: selected 12,23,5 pens for dpm
//  if(ui->pushButton_116->isChecked()==true)
//  {
//    selected_pens << 1;
//  }
//  else if (ui->pushButton_116->isChecked()==false){
//      selected_pens.removeAll(1);
//      QString selectedpenobject = "Pen";
//      selectedpenobject.append(QVariant(1).toString());
//      qDebug()<<"remove"<<selectedpenobject;
//      QLabel * targetlabel = Frame->findChild<QLabel*>(selectedpenobject);
//      HLayout->removeWidget(targetlabel);
//      delete targetlabel;
//  }
}

void MainWindow::on_pushButton_117_clicked()
{
//    //here eg: selected 12,23,5 pens
//  if(ui->pushButton_117->isChecked()==true)
//  {
//    selected_pens << 2;
//  }
//  else if (ui->pushButton_117->isChecked()==false){
//      selected_pens.removeAll(2);
//      QString selectedpenobject = "Pen";
//      selectedpenobject.append(QVariant(2).toString());
//      qDebug()<<"remove"<<selectedpenobject;
//      QLabel * targetlabel2 = Frame->findChild<QLabel*>(selectedpenobject);
//      HLayout->removeWidget(targetlabel2);
//      delete targetlabel2;
//  }
}

void MainWindow::on_pushButton_118_clicked()
{
//    //here eg: selected 12,23,5 pens
//  if(ui->pushButton_118->isChecked()==true)
//  {
//    selected_pens << 3;
//  }
//  else if (ui->pushButton_118->isChecked()==false){
//      selected_pens.removeAll(3);
//      QString selectedpenobject = "Pen";
//      selectedpenobject.append(QVariant(3).toString());
//      qDebug()<<"remove"<<selectedpenobject;
//      QLabel * targetlabel2 = Frame->findChild<QLabel*>(selectedpenobject);
//      HLayout->removeWidget(targetlabel2);
//      delete targetlabel2;
//  }
}

void MainWindow::on_pushButton_121_clicked()
{
//    //here eg: selected 12,23,5 pens
//  if(ui->pushButton_121->isChecked()==true)
//  {
//    selected_pens << 4;
//  }
//  else if (ui->pushButton_121->isChecked()==false){
//      selected_pens.removeAll(4);
//      QString selectedpenobject = "Pen";
//      selectedpenobject.append(QVariant(4).toString());
//      qDebug()<<"remove"<<selectedpenobject;
//      QLabel * targetlabel2 = Frame->findChild<QLabel*>(selectedpenobject);
//      HLayout->removeWidget(targetlabel2);
//      delete targetlabel2;
//  }
}

void MainWindow::on_SELECT_PENS_TABLE_BOTTOM_BAR_Clear_clicked()
{
    for (int var = 0; var <selected_MaxMin_pens.size(); ++var)
    {
        //selected_pens.removeAll(selected_pens[var]);
        QString selectedpenobject1 = "Pen";
        selectedpenobject1.append(QVariant(selected_MaxMin_pens[var]).toString());
       // qDebug()<<"remove"<<selectedpenobject1;
        QPushButton * targetlabel21 = window1->findChild<QPushButton*>(selectedpenobject1);
        QPushButton * uncheckbutton = maxminwindow1->findChild<QPushButton*>(selectedpenobject1);
        uncheckbutton->setStyleSheet("color:black;text-align:center;border-style: solid;border-color: black;font-size: 22px;border-width: 1px;border-radius: 3px;border-style: outset;");
        uncheckbutton->setChecked(false);
        gridLayout->removeWidget(targetlabel21);
        delete targetlabel21;
    }

//    ui->pushButton_131->setChecked(false);
//    ui->pushButton_132->setChecked(false);
//    ui->pushButton_133->setChecked(false);
//    ui->pushButton_134->setChecked(false);

    selected_MaxMin_pens.clear();
   // qDebug()<<"cleared size,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,"<<selected_MaxMin_pens.size();


}

void MainWindow::on_SELECT_PENS_TABLE_BOTTOM_BAR_Add_clicked()
{
    for (int m = 1;m <=96;m++)
    {
//                        if(mt_PEN[index] != NULL)
//                        {
            QString search_pen2 = "Pen";
            search_pen2.append(QVariant(m).toString());
            QPushButton * search_pen_btn1 = window1->findChild<QPushButton*>(search_pen2);
//            if(search_pen_btn == 0x0)
//          {
            gridLayout->removeWidget(search_pen_btn1);

            delete search_pen_btn1;
//          }

//    }
    }



    int i = 0;
   // qDebug()<<"list="<<selected_MaxMin_pens;

            if(selected_MaxMin_pens.size() == 0)
            {
                ui->stackedWidget->setCurrentIndex(41);
            }
            if(selected_MaxMin_pens.size() > 0 && selected_MaxMin_pens.size()<=24 )
                {
                for (int var = 0; var < selected_MaxMin_pens.size(); ++var)
                {

                                QString search_pen1 = "Pen";
                                search_pen1.append((QString("%1").arg(selected_MaxMin_pens[var])));
                                QPushButton * search_pen_btn = window1->findChild<QPushButton*>(search_pen1);

//                                if(search_pen_btn == 0x0)
//                                {
                                   // for (int i = 0; i < totalButtons; ++i)
                              // qDebug()<<selected_MaxMin_pens[var];

                                        QPushButton *button = new QPushButton("Pen" + QString::number(selected_MaxMin_pens[var]));

                                        button->setObjectName("Pen" + QString :: number(selected_MaxMin_pens[var]));

                                        button->setStyleSheet("color:black;text-align:left;border-style: solid;border-color: black;font-size: 22px;border-width: 1px;border-radius: 3px;border-style: outset;background-color:#E7EFF7;");

                                        button->setMinimumSize(QSize(256, 118));
                                        button->setMaximumSize(QSize(256, 118));

                                        //button->hide();



                                        int row = i / 4;  // Calculate the row based on button count



                                        int col = i % 4;  // Calculate the column based on button count



                                        gridLayout->addWidget(button, row, col,{Qt::AlignTop, Qt::AlignLeft});

                                        i++;




//                                        QString selectedpenobject = "Pen";
//                                        selectedpenobject.append(buttonmaxmin->text());
//                                        qDebug()<<"remove"<<selectedpenobject;
//                                        QPushButton * targetlabel1 = window1->findChild<QPushButton*>(selectedpenobject);
//                                        gridLayout->removeWidget(targetlabel1);
//                                        delete targetlabel1;


                                        //when buttons are clicked
                                        QObject::connect(button,&QPushButton::clicked,[=]()
                                        {
                                            //qDebug()<<clickable;
                                            if(clickable==true)
                                            {
                                               // qDebug()<<button->objectName();
                                                   pt=button->objectName();
                                                   int n=(pt.split("n")[1].toInt());
//                                                    qDebug()<<n;

                                                   peninfo=(QString("Max: ")+QString(QVariant(maxmin.GetMax(n)).toString())+"%\n@ "+QString(maxmin.GetMaxtime(n))+QString("\nMin: ")+QString(QVariant(maxmin.GetMin(n)).toString())+"%\n@ "+QString(maxmin.GetMintime(n)));

                                              maxmin_info_Dialog maxmin_info_Dialog;
                                              maxmin_info_Dialog.setModal(true);
                                              maxmin_info_Dialog.exec();



                                            }
                                            if(reset_bypen==true)
                                            {
                                               // qDebug()<<button->objectName();
                                                   QString obj=button->objectName();
                                                   int p=(obj.split("n")[1].toInt());

                                                bypen_warning_Dialog  bypen_warning_Dialog;
                                                bypen_warning_Dialog.setModal(true);
                                                bypen_warning_Dialog.exec();

                                                if(ok == 1)
                                                {
                                                    maxmin.RequestAction(resetmode_bypen,p);
                                                     maxmin.DoMaxMin();
                                                }

                                            }

                                        });


//                                    }


                                }
                            }



                ui->stackedWidget->setCurrentIndex(41);
                }

void MainWindow::on_SELECT_PENS_TABLE_BOTTOM_BAR_Finish_clicked()
{
    ui->stackedWidget->setCurrentIndex(41);
}

void MainWindow::on_pushButton_131_clicked()
{
//    if(ui->pushButton_131->isChecked()==true)
//    {
//      selected_MaxMin_pens << 1;
//    }
//    else if (ui->pushButton_131->isChecked()==false){
//        selected_MaxMin_pens.removeAll(1);
//        QString selectedpenobject = "Pen";
//        selectedpenobject.append(QVariant(1).toString());
//        qDebug()<<"remove"<<selectedpenobject;
//        QPushButton * targetlabel1 = window1->findChild<QPushButton*>(selectedpenobject);
//        gridLayout->removeWidget(targetlabel1);
//        delete targetlabel1;
//    }
   ui->stackedWidget_2->setCurrentIndex(0);
     ui->stackedWidget->setCurrentIndex(36);
     clickable=false;
     if(screen_type == 1)
     {
        ui->verticalLayout_66->addWidget(mPlot);
        ui->stackedWidget_3->setCurrentIndex(0);
     }
     if(screen_type == 2)
     {
        ui->verticalLayout_68->addWidget(window2);
        ui->stackedWidget_3->setCurrentIndex(1);
     }
}

void MainWindow::on_pushButton_132_clicked()
{
//    if(ui->pushButton_132->isChecked()==true)
//    {
//      selected_MaxMin_pens << 2;
//    }
//    else if (ui->pushButton_132->isChecked()==false){
//        selected_MaxMin_pens.removeAll(2);
//        QString selectedpenobject = "Pen";
//        selectedpenobject.append(QVariant(2).toString());
//        qDebug()<<"remove"<<selectedpenobject;
//        QPushButton * targetlabel1 = window1->findChild<QPushButton*>(selectedpenobject);
//        gridLayout->removeWidget(targetlabel1);
//        delete targetlabel1;
//    }
}

void MainWindow::on_pushButton_133_clicked()
{
//    if(ui->pushButton_133->isChecked()==true)
//    {
//      selected_MaxMin_pens << 3;
//    }
//    else if (ui->pushButton_133->isChecked()==false){
//        selected_MaxMin_pens.removeAll(3);
//        QString selectedpenobject = "Pen";
//        selectedpenobject.append(QVariant(3).toString());
//        qDebug()<<"remove"<<selectedpenobject;
//        QPushButton * targetlabel1 = window1->findChild<QPushButton*>(selectedpenobject);
//        gridLayout->removeWidget(targetlabel1);
//        delete targetlabel1;
//    }
}

void MainWindow::on_pushButton_134_clicked()
{
//    if(ui->pushButton_134->isChecked()==true)
//    {
//      selected_MaxMin_pens << 4;
//    }
//    else if (ui->pushButton_134->isChecked()==false){
//        selected_MaxMin_pens.removeAll(4);
//        QString selectedpenobject = "Pen";
//        selectedpenobject.append(QVariant(4).toString());
//        qDebug()<<"remove"<<selectedpenobject;
//        QPushButton * targetlabel1 = window1->findChild<QPushButton*>(selectedpenobject);
//        gridLayout->removeWidget(targetlabel1);
//        delete targetlabel1;
//    }

    ui->stackedWidget_2->setCurrentIndex(0);
     ui->stackedWidget->setCurrentIndex(38);
	 reset_bypen=false;
     if(screen_type == 1)
     {

        ui->stackedWidget_3->setCurrentIndex(0);
     }
     if(screen_type == 2)
     {
        ui->verticalLayout_68->addWidget(window2);
        ui->stackedWidget_3->setCurrentIndex(1);
     }

}

void MainWindow::on_toolButton_96_clicked()
{
    clickable=true;
    //ui->verticalLayout_62->addWidget(window2);
    ui->verticalLayout_70->addWidget(window2);
    ui->stackedWidget_2->setCurrentIndex(2);
}

void MainWindow::on_toolButton_113_clicked()
{
    reset_all_Dialog reset_all_Dialog;
    reset_all_Dialog.setModal(true);
    reset_all_Dialog.exec();
    if(reset_all_ok == 1)
    {
        for (int var = 0; var < selected_MaxMin_pens.size(); ++var)
        {
          maxmin.RequestAction(MM_MODE_RESET_BOTH,selected_MaxMin_pens[var]);
           maxmin.DoMaxMin();
        }
    }
    ui->stackedWidget->setCurrentIndex(36);
}

void MainWindow::on_toolButton_120_clicked()
{
    reset_all_Dialog reset_all_Dialog;
    reset_all_Dialog.setModal(true);
    reset_all_Dialog.exec();
    if(reset_all_ok == 1)
    {
        for (int var = 0; var < selected_MaxMin_pens.size(); ++var)
        {
            maxmin.RequestAction(MM_MODE_RESET_MAX,selected_MaxMin_pens[var]);
            maxmin.DoMaxMin();
        }
    }
    ui->stackedWidget->setCurrentIndex(36);
}

void MainWindow::on_toolButton_133_clicked()
{
    reset_all_Dialog reset_all_Dialog;
    reset_all_Dialog.setModal(true);
    reset_all_Dialog.exec();
    if(reset_all_ok == 1)
    {
        for (int var = 0; var < selected_MaxMin_pens.size(); ++var)
        {
            maxmin.RequestAction(MM_MODE_RESET_MIN,selected_MaxMin_pens[var]);
            maxmin.DoMaxMin();
        }
     }

    ui->stackedWidget->setCurrentIndex(36);
}

void MainWindow::on_toolButton_123_clicked()
{
    reset_bypen=true;
    message = QString("Are You Sure You Wish to Reset this max ?");
    resetmode_bypen = MM_MODE_RESET_MAX;

    ui->verticalLayout_72->addWidget(window2);
    ui->stackedWidget_2->setCurrentIndex(3);
}

void MainWindow::on_toolButton_98_clicked()
{
   ui->stackedWidget_2->setCurrentIndex(1);
}

void MainWindow::on_toolButton_211_clicked()
{
    //sdcard = mmcblk, usb = sdX
    // Replace '/dev/sdX' with the actual device path you want to mount
    QString devicePath = "/dev/sdX";
    QString mountPoint = "/mnt/mounted_device";  // Choose a suitable mount point

    // Check if the device is already mounted
    QProcess checkMountProcess;
    checkMountProcess.start("mount | grep " + devicePath);
    checkMountProcess.waitForFinished();
    QByteArray checkMountResult = checkMountProcess.readAllStandardOutput();

    if (checkMountResult.isEmpty())
    {
        // If the device is not mounted, mount it
        QProcess mountProcess;
        mountProcess.start("mount " + devicePath + " " + mountPoint);
        mountProcess.waitForFinished();

        // Check if the mount was successful
        if (mountProcess.exitCode() == 0)
        {
            qDebug() << "Device mounted successfully.";
        }
        else
        {
            qDebug() << "Failed to mount device.";
            //return 1;
        }
    }
    else
    {
        qDebug() << "Device is already mounted.";
    }

    // Now that the device is mounted, you can use QStorageInfo to get information
    QStorageInfo storageInfo(mountPoint);
    //qDebug() << "Device:" << storageInfo.device();
    //qDebug() << "Description:";
    //qDebug() << "File System Type:" << storageInfo.fileSystemType();
    //qDebug() << "Total Size:" << storageInfo.bytesTotal() << "bytes";
    //qDebug() << "Free Space:" << storageInfo.bytesFree() << "bytes";
    //qDebug() << "Free Space:" << storageInfo.bytesFree() / (1024 * 1024) << "MB";
    //qDebug() << "Free Space:" << storageInfo.bytesFree() / (1024 * 1024 * 1024) << "GB";

}

void MainWindow::on_toolButton_97_clicked()
{
    ui->stackedWidget->setCurrentIndex(35);
}

void MainWindow::on_toolButton_115_clicked()
{
  ui->stackedWidget->setCurrentIndex(36);
}

void MainWindow::on_toolButton_122_clicked()
{
    ui->stackedWidget->setCurrentIndex(36);
}

void MainWindow::on_toolButton_135_clicked()
{
    ui->stackedWidget->setCurrentIndex(36);
}

void MainWindow::on_toolButton_134_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(1);
}

void MainWindow::on_toolButton_121_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(1);
}

void MainWindow::on_toolButton_114_clicked()
{
     ui->stackedWidget_2->setCurrentIndex(1);
}

void MainWindow::on_EDIT_LAYOUT_SCREENS_INDEX_BOTTOM_BAR_Back_clicked()
{
     ui->stackedWidget->setCurrentIndex(33);
}

void MainWindow::on_EDIT_LAYOUT_SCREENS_INDEX_2_BOTTOM_BAR_Back_clicked()
{
    ui->stackedWidget->setCurrentIndex(33);
}

void MainWindow::on_toolButton_116_clicked()
{
    reset_bypen=true;
    message = QString("Are You Sure You Wish to Reset this max/min ?");
    resetmode_bypen = MM_MODE_RESET_BOTH;

    ui->verticalLayout_72->addWidget(window2);
    ui->stackedWidget_2->setCurrentIndex(3);
}

void MainWindow::on_toolButton_136_clicked()
{
    reset_bypen=true;
    message = QString("Are You Sure You Wish to Reset this min ?");//copy only this line
    resetmode_bypen = MM_MODE_RESET_MIN;
    ui->verticalLayout_72->addWidget(window2);
    ui->stackedWidget_2->setCurrentIndex(3);
}

void MainWindow::on_toolButton_86_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}
//connect(ui->m_kCommsBtn,&QPushButton::released, [pCfgSetupMenu](){pCfgSetupMenu->OnCfgSetupMenuDlgCommsBtn();});
void MainWindow::/*on_toolButton_68_clicked*/OnCfgSetupMenuDlgCommsBtn()
{
    ui->stackedWidget->setCurrentIndex(63);

}

void MainWindow::on_toolButton_222_clicked()
{
    ui->stackedWidget->setCurrentIndex(64);

}

void MainWindow::on_toolButton_143_clicked()
{
    ui->stackedWidget->setCurrentIndex(65);

}

void MainWindow::on_toolButton_298_clicked()
{
    ui->stackedWidget->setCurrentIndex(66);

}

void MainWindow::on_toolButton_300_clicked()
{
    ui->stackedWidget->setCurrentIndex(67);

}

void MainWindow::on_toolButton_302_clicked()
{
    ui->stackedWidget->setCurrentIndex(68);

}

void MainWindow::on_toolButton_218_clicked()
{
    ui->stackedWidget->setCurrentIndex(3);

}

void MainWindow::on_toolButton_221_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_toolButton_303_clicked()
{
    ui->stackedWidget->setCurrentIndex(63);

}

void MainWindow::on_toolButton_313_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_toolButton_308_clicked()
{
    ui->stackedWidget->setCurrentIndex(64);

}

void MainWindow::on_toolButton_307_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_pushButton_159_clicked()
{
    ui->stackedWidget->setCurrentIndex(63);

}

void MainWindow::on_pushButton_314_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_pushButton_319_clicked()
{
    ui->stackedWidget->setCurrentIndex(64);

}

void MainWindow::on_pushButton_321_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_pushButton_326_clicked()
{
    ui->stackedWidget->setCurrentIndex(64);

}

void MainWindow::on_pushButton_328_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_toolButton_304_clicked()
{
    ui->stackedWidget->setCurrentIndex(69);

}

void MainWindow::on_pushButton_345_clicked()
{
    ui->stackedWidget->setCurrentIndex(64);

}

void MainWindow::on_pushButton_347_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}
//connect(ui->m_kMessagesBtn,&QPushButton::released, [pMainMenu](){pMainMenu->OnMainMenuDlgMessagesBtn();});
void MainWindow::/*toolButton_17*/OnMainMenuDlgMessagesBtn()
{
    ui->stackedWidget->setCurrentIndex(70);

}

void MainWindow::on_toolButton_324_clicked()
{
    ui->stackedWidget->setCurrentIndex(71);

}

void MainWindow::on_toolButton_321_clicked()
{
    ui->stackedWidget->setCurrentIndex(72);

}

void MainWindow::on_toolButton_317_clicked()
{
    ui->stackedWidget->setCurrentIndex(73);

}

void MainWindow::on_toolButton_318_clicked()
{
    ui->stackedWidget->setCurrentIndex(74);

}

void MainWindow::on_toolButton_320_clicked()
{
    ui->stackedWidget->setCurrentIndex(75);

}

void MainWindow::on_toolButton_322_clicked()
{
    ui->stackedWidget->setCurrentIndex(76);

}

void MainWindow::on_toolButton_319_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_toolButton_323_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_pushButton_351_clicked()
{
    ui->stackedWidget->setCurrentIndex(70);

}

void MainWindow::on_pushButton_353_clicked()
{
    ui->stackedWidget->setCurrentIndex(70);

}

void MainWindow::on_pushButton_358_clicked()
{
    ui->stackedWidget->setCurrentIndex(70);

}

void MainWindow::on_pushButton_363_clicked()
{
    ui->stackedWidget->setCurrentIndex(70);

}

void MainWindow::on_pushButton_368_clicked()
{
    ui->stackedWidget->setCurrentIndex(70);

}

void MainWindow::on_pushButton_373_clicked()
{
    ui->stackedWidget->setCurrentIndex(70);

}

void MainWindow::on_toolButton_220_clicked()
{
    ui->stackedWidget->setCurrentIndex(92);

}
//connect(ui->m_kStatusBtn,&QPushButton::released, [pMainMenu](){pMainMenu->OnMainMenuDlgStatusBtn();});
void MainWindow::/*toolButton_19*/OnMainMenuDlgStatusBtn()
{
    ui->stackedWidget->setCurrentIndex(121);

}

void MainWindow::on_toolButton_351_clicked()
{
    ui->stackedWidget->setCurrentIndex(123);

}

void MainWindow::on_toolButton_376_clicked()
{
    ui->stackedWidget->setCurrentIndex(125);

}

void MainWindow::on_toolButton_380_clicked()
{
    ui->stackedWidget->setCurrentIndex(126);

}

void MainWindow::on_toolButton_379_clicked()
{
    ui->stackedWidget->setCurrentIndex(127);

}

void MainWindow::on_toolButton_352_clicked()
{
    ui->stackedWidget->setCurrentIndex(128);

}

void MainWindow::on_toolButton_26_clicked()
{
    ui->stackedWidget->setCurrentIndex(60);

}
//connect(ui->m_kGeneralBtn,&QPushButton::released, [pCfgSetupMenu](){pCfgSetupMenu->OnCfgSetupMenuDlgGeneralBtn();});
void MainWindow::/*on_toolButton_70_clicked*/OnCfgSetupMenuDlgGeneralBtn()
{
    ui->stackedWidget->setCurrentIndex(130);

}

void MainWindow::on_toolButton_422_clicked()
{
    ui->stackedWidget->setCurrentIndex(131);

}

void MainWindow::on_toolButton_223_clicked()
{
    ui->stackedWidget->setCurrentIndex(95);

}

void MainWindow::on_toolButton_217_clicked()
{
    ui->stackedWidget->setCurrentIndex(96);

}

void MainWindow::on_toolButton_219_clicked()
{
    ui->stackedWidget->setCurrentIndex(97);

}

void MainWindow::on_toolButton_429_clicked()
{
    ui->stackedWidget->setCurrentIndex(107);

}

void MainWindow::on_toolButton_426_clicked()
{
    ui->stackedWidget->setCurrentIndex(101);

}



void MainWindow::on_toolButton_140_clicked()
{
    ui->stackedWidget->setCurrentIndex(115);

}

void MainWindow::on_toolButton_402_clicked()
{
    ui->stackedWidget->setCurrentIndex(116);

}

void MainWindow::on_toolButton_399_clicked()
{
    ui->stackedWidget->setCurrentIndex(117);

}

void MainWindow::on_toolButton_430_clicked()
{
    ui->stackedWidget->setCurrentIndex(88);

}

void MainWindow::on_toolButton_432_clicked()
{
ui->stackedWidget->setCurrentIndex(174);
}

void MainWindow::on_toolButton_416_clicked()
{
ui->stackedWidget->setCurrentIndex(114);

}

void MainWindow::on_toolButton_417_clicked()
{
    ui->stackedWidget->setCurrentIndex(50);

}

void MainWindow::on_toolButton_419_clicked()
{
    ui->stackedWidget->setCurrentIndex(120);

}

void MainWindow::on_toolButton_415_clicked()
{
    ui->stackedWidget->setCurrentIndex(122);

}

void MainWindow::on_toolButton_47_clicked()
{
    ui->stackedWidget->setCurrentIndex(89);

}

void MainWindow::on_toolButton_49_clicked()
{
    ui->stackedWidget->setCurrentIndex(91);

}

void MainWindow::on_toolButton_52_clicked()
{
    ui->stackedWidget->setCurrentIndex(46);

}

void MainWindow::on_pushButton_147_clicked()
{
    ui->stackedWidget->setCurrentIndex(10);

}

void MainWindow::on_pushButton_154_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_pushButton_151_clicked()
{
    ui->stackedWidget->setCurrentIndex(77);

}

void MainWindow::on_pushButton_155_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_pushButton_160_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_pushButton_165_clicked()
{
    ui->stackedWidget->setCurrentIndex(10);

}

void MainWindow::on_pushButton_166_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_pushButton_172_clicked()
{
    ui->stackedWidget->setCurrentIndex(80);

}

void MainWindow::on_pushButton_173_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_EDIT_SETUP_GENERAL_FACTORY_DEMO_TRACES_BOTTOM_BAR_Finish_clicked()
{
    ui->stackedWidget->setCurrentIndex(131);

}

void MainWindow::on_EDIT_SETUP_GENERAL_FACTORY_DEMO_TRACES_BOTTOM_BAR_CopyTo_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_pushButton_186_clicked()
{
    ui->stackedWidget->setCurrentIndex(115);

}

void MainWindow::on_pushButton_187_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_pushButton_195_clicked()
{
    ui->stackedWidget->setCurrentIndex(80);

}

void MainWindow::on_pushButton_196_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_pushButton_200_clicked()
{
    ui->stackedWidget->setCurrentIndex(80);

}

void MainWindow::on_pushButton_201_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_pushButton_207_clicked()
{
    ui->stackedWidget->setCurrentIndex(80);

}

void MainWindow::on_pushButton_208_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_pushButton_214_clicked()
{
    ui->stackedWidget->setCurrentIndex(80);

}

void MainWindow::on_pushButton_215_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_pushButton_563_clicked()
{
    ui->stackedWidget->setCurrentIndex(80);

}

void MainWindow::on_pushButton_564_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_pushButton_539_clicked()
{
    ui->stackedWidget->setCurrentIndex(7);

}

void MainWindow::on_pushButton_540_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_pushButton_545_clicked()
{
    ui->stackedWidget->setCurrentIndex(7);

}

void MainWindow::on_pushButton_546_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_EDIT_SETUP_SCREEN_SETUP_TABULAR_DISPLAY_BOTTOM_BAR_Back_clicked()
{
    ui->stackedWidget->setCurrentIndex(7);

}

void MainWindow::on_EDIT_SETUP_SCREEN_SETUP_TABULAR_DISPLAY_BOTTOM_BAR_Finish_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_EDIT_SETUP_FIELDIO_LINEARISATION_Bottom_Bar_Back_clicked()
{
    ui->stackedWidget->setCurrentIndex(4);

}

void MainWindow::on_EDIT_SETUP_FIELDIO_LINEARISATION_Bottom_Bar_Finish_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_EDIT_SETUP_FIELDIO_LINEARISATION_TABLE_Bottom_Bar_Back_clicked()
{
    ui->stackedWidget->setCurrentIndex(60);

}

void MainWindow::on_EDIT_SETUP_FIELDIO_LINEARISATION_TABLE_Bottom_Bar_Finish_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_LOAD_CERTIFICATE_Back_Button_clicked()
{
    ui->stackedWidget->setCurrentIndex(63);

}

void MainWindow::on_LOAD_CERTIFICATE_Finish_Button_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_EDIT_SETUP_COMMS_SECURITY_OPTIONS_Bottom_Bar_Back_clicked()
{
    ui->stackedWidget->setCurrentIndex(63);

}

void MainWindow::on_EDIT_SETUP_COMMS_SECURITY_OPTIONS_Bottom_Bar_Finish_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_toolButton_388_clicked()
{
    ui->stackedWidget->setCurrentIndex(131);

}

void MainWindow::on_toolButton_383_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_toolButton_355_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_toolButton_356_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_pushButton_403_clicked()
{
    ui->stackedWidget->setCurrentIndex(131);

}

void MainWindow::on_pushButton_402_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_toolButton_378_clicked()
{
    ui->stackedWidget->setCurrentIndex(121);

}

void MainWindow::on_toolButton_377_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_toolButton_396_clicked()
{
    ui->stackedWidget->setCurrentIndex(114);

}

void MainWindow::on_toolButton_389_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_EDIT_SETUP_COMMS_COMMS_SERVICES_MODBUS_RS485_TOP_BAR_Edit_Setup_clicked()
{
    ui->stackedWidget->setCurrentIndex(123);

}

void MainWindow::on_EDIT_SETUP_COMMS_COMMS_SERVICES_MODBUS_RS485_TOP_BAR_Comms_clicked()
{
    ui->stackedWidget->setCurrentIndex(123);

}

void MainWindow::on_EDIT_SETUP_COMMS_COMMS_SERVICES_MODBUS_RS485_TOP_BAR_Rs485_clicked()
{
    ui->stackedWidget->setCurrentIndex(123);

}

void MainWindow::on_EDIT_SETUP_COMMS_COMMS_SERVICES_MODBUS_RS485_BOTTOM_BAR_CopyTo_clicked()
{
    ui->stackedWidget->setCurrentIndex(121);

}

void MainWindow::on_pushButton_396_clicked()
{
    ui->stackedWidget->setCurrentIndex(121);

}

void MainWindow::on_toolButton_354_clicked()
{
    ui->stackedWidget->setCurrentIndex(129);

}

void MainWindow::on_EDIT_LAYOUT_SCREENS_SCREEN_Bottom_Bar_Back_2_clicked()
{
    ui->stackedWidget->setCurrentIndex(130);

}

void MainWindow::on_EDIT_LAYOUT_SCREENS_SCREEN_Bottom_Bar_Finish_2_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(1);

}

void MainWindow::on_EDIT_LAYOUT_SCREENS_SCREEN_Bottom_Bar_Back_3_clicked()
{

}

void MainWindow::on_pushButton_533_clicked()
{
    ui->stackedWidget->setCurrentIndex(131);

}

void MainWindow::on_pushButton_534_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(1);

}

void MainWindow::on_EDIT_SETUP_GENERAL_ERROR_ALERT_Bottom_Bar_Back_clicked()
{
    ui->stackedWidget->setCurrentIndex(131);;
}

void MainWindow::on_EDIT_SETUP_GENERAL_ERROR_ALERT_Bottom_Bar_Finish_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(1);
}
//	connect(ui->m_kLytBtn,&QPushButton::released, [pConfigMenu](){pConfigMenu->OnConfigMenuDlgLytBtn();});
void MainWindow::/*on_toolButton_43_clicked*/OnConfigMenuDlgLytBtn()
{
     ui->stackedWidget->setCurrentIndex(171);
}

void MainWindow::on_toolButton_153_clicked()
{
    ui->stackedWidget->setCurrentIndex(172);

}

void MainWindow::on_toolButton_155_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);

}

void MainWindow::on_toolButton_154_clicked()
{
     ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_toolButton_440_clicked()
{
     ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_toolButton_443_clicked()
{
     ui->stackedWidget->setCurrentIndex(98);
}

void MainWindow::on_toolButton_442_clicked()
{
     ui->stackedWidget->setCurrentIndex(99);
}

void MainWindow::on_toolButton_439_clicked()
{

    ui->stackedWidget->setCurrentIndex(173);
}

void MainWindow::on_EDIT_LAYOUT_LAYOUT_SETTINGS_Bottom_Bar_Back_2_clicked()
{
    ui->stackedWidget->setCurrentIndex(172);
}

void MainWindow::on_EDIT_LAYOUT_LAYOUT_SETTINGS_Bottom_Bar_FInish_2_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(1);

}

void MainWindow::on_EDIT_LAYOUT_LAYOUT_SETTINGS_Bottom_Bar_Back_clicked()
{
    ui->stackedWidget->setCurrentIndex(172);

}

void MainWindow::on_EDIT_LAYOUT_LAYOUT_SETTINGS_Bottom_Bar_FInish_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_EDIT_LAYOUT_APPEARANCE_Bottom_Bar_Back_clicked()
{
    ui->stackedWidget->setCurrentIndex(172);

}

void MainWindow::on_EDIT_LAYOUT_APPEARANCE_Bottom_Bar_Finish_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_toolButton_418_clicked()
{
    ui->stackedWidget->setCurrentIndex(130);
}

void MainWindow::on_toolButton_431_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_toolButton_424_clicked()
{
    ui->stackedWidget->setCurrentIndex(3);
}

void MainWindow::on_toolButton_428_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_toolButton_5_clicked()
{
    ui->stackedWidget->setCurrentIndex(131);
}

void MainWindow::on_toolButton_141_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_EDIT_LAYOUT_LAYOUT_SETTINGS_Bottom_Bar_Back_3_clicked()
{
    ui->stackedWidget->setCurrentIndex(131);
}

void MainWindow::on_EDIT_LAYOUT_LAYOUT_SETTINGS_Bottom_Bar_FInish_3_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_EDIT_LAYOUT_LAYOUT_SETTINGS_Bottom_Bar_Back_4_clicked()
{
     ui->stackedWidget->setCurrentIndex(176);
}
//connect(ui->m_kPwdBtn,&QPushButton::released, [pConfigMenu](){pConfigMenu->OnConfigMenuDlgPwdBtn();});
void MainWindow::/*on_toolButton_44_clicked*/OnConfigMenuDlgPwdBtn()
{
    ui->stackedWidget->setCurrentIndex(175);
}


void MainWindow::on_toolButton_450_clicked()
{
     ui->stackedWidget->setCurrentIndex(1);
}

void MainWindow::on_toolButton_451_clicked()
{
     ui->stackedWidget->setCurrentIndex(00);
}

void MainWindow::on_toolButton_445_clicked()
{
     ui->stackedWidget->setCurrentIndex(176);
}

void MainWindow::on_toolButton_453_clicked()
{
     ui->stackedWidget->setCurrentIndex(177);
}

void MainWindow::on_toolButton_460_clicked()
{
     ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_EDIT_LAYOUT_LAYOUT_SETTINGS_Bottom_Bar_FInish_4_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_toolButton_455_clicked()
{
    ui->stackedWidget->setCurrentIndex(178);
}

void MainWindow::on_EDIT_LAYOUT_LAYOUT_SETTINGS_Bottom_Bar_Back_6_clicked()
{
    ui->stackedWidget->setCurrentIndex(178);
}


void MainWindow::on_EDIT_LAYOUT_LAYOUT_SETTINGS_Bottom_Bar_FInish_6_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}


void MainWindow::on_EDIT_LAYOUT_LAYOUT_SETTINGS_Bottom_Bar_Back_5_clicked()
{
 ui->stackedWidget->setCurrentIndex(177);
}

void MainWindow::on_EDIT_LAYOUT_LAYOUT_SETTINGS_Bottom_Bar_FInish_5_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_toolButton_454_clicked()
{
    ui->stackedWidget->setCurrentIndex(179);
}

void MainWindow::on_toolButton_466_clicked()
{
    ui->stackedWidget->setCurrentIndex(177);
}

void MainWindow::on_toolButton_467_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_toolButton_462_clicked()
{
    ui->stackedWidget->setCurrentIndex(180);
}

void MainWindow::on_toolButton_463_clicked()
{
   ui->stackedWidget->setCurrentIndex(181);
}

void MainWindow::on_toolButton_464_clicked()
{
    ui->stackedWidget->setCurrentIndex(182);
}

void MainWindow::on_toolButton_465_clicked()
{
    ui->stackedWidget->setCurrentIndex(183);
}

void MainWindow::on_EDIT_LAYOUT_LAYOUT_SETTINGS_Bottom_Bar_Back_7_clicked()
{
     ui->stackedWidget->setCurrentIndex(179);
}

void MainWindow::on_EDIT_LAYOUT_LAYOUT_SETTINGS_Bottom_Bar_FInish_7_clicked()
{
      ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_EDIT_LAYOUT_LAYOUT_SETTINGS_Bottom_Bar_Back_8_clicked()
{
   ui->stackedWidget->setCurrentIndex(179);
}

void MainWindow::on_EDIT_LAYOUT_LAYOUT_SETTINGS_Bottom_Bar_FInish_8_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_EDIT_LAYOUT_LAYOUT_SETTINGS_Bottom_Bar_Back_9_clicked()
{
    ui->stackedWidget->setCurrentIndex(179);
}

void MainWindow::on_EDIT_LAYOUT_LAYOUT_SETTINGS_Bottom_Bar_FInish_9_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_EDIT_LAYOUT_LAYOUT_SETTINGS_Bottom_Bar_Back_10_clicked()
{
    ui->stackedWidget->setCurrentIndex(179);
}

void MainWindow::on_EDIT_LAYOUT_LAYOUT_SETTINGS_Bottom_Bar_FInish_10_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_toolButton_353_clicked()
{
 ui->stackedWidget->setCurrentIndex(187);
}

void MainWindow::on_pushButton_588_clicked()
{
     ui->stackedWidget->setCurrentIndex(121);
}

void MainWindow::on_toolButton_6_clicked()
{
     ui->stackedWidget->setCurrentIndex(188);
}

void MainWindow::on_toolButton_477_clicked()
{
     ui->stackedWidget->setCurrentIndex(121);
}

void MainWindow::on_toolButton_482_clicked()
{
     ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_toolButton_480_clicked()
{
    ui->stackedWidget->setCurrentIndex(189);
}

void MainWindow::on_toolButton_487_clicked()
{
    ui->stackedWidget->setCurrentIndex(188);
}

void MainWindow::on_toolButton_488_clicked()
{
     ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_toolButton_484_clicked()
{
    ui->stackedWidget->setCurrentIndex(190);
}

void MainWindow::on_toolButton_479_clicked()
{
ui->stackedWidget->setCurrentIndex(191);
}

void MainWindow::on_pushButton_600_clicked()
{
ui->stackedWidget->setCurrentIndex(188);
}

void MainWindow::on_toolButton_481_clicked()
{
    ui->stackedWidget->setCurrentIndex(192);

}

void MainWindow::on_toolButton_494_clicked()
{
    ui->stackedWidget->setCurrentIndex(188);

}

void MainWindow::on_toolButton_499_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_toolButton_497_clicked()
{
    ui->stackedWidget->setCurrentIndex(193);
}

void MainWindow::on_pushButton_591_clicked()
{
    ui->stackedWidget->setCurrentIndex(192);
}

void MainWindow::on_toolButton_496_clicked()
{
    ui->stackedWidget->setCurrentIndex(194);
}

void MainWindow::on_pushButton_597_clicked()
{
    ui->stackedWidget->setCurrentIndex(192);
}

void MainWindow::on_pushButton_603_clicked()
{
    ui->stackedWidget->setCurrentIndex(192);
}

void MainWindow::on_toolButton_498_clicked()
{
    ui->stackedWidget->setCurrentIndex(195);
}

void MainWindow::on_pushButton_608_clicked()
{
    ui->stackedWidget->setCurrentIndex(192);
}

void MainWindow::on_toolButton_495_clicked()
{
    ui->stackedWidget->setCurrentIndex(196);
}

void MainWindow::on_toolButton_509_clicked()
{
    ui->stackedWidget->setCurrentIndex(192);
}

void MainWindow::on_toolButton_506_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_toolButton_492_clicked()
{
    ui->stackedWidget->setCurrentIndex(197);
}

void MainWindow::on_toolButton_505_clicked()
{
    ui->stackedWidget->setCurrentIndex(198);
}

void MainWindow::on_pushButton_613_clicked()
{
    ui->stackedWidget->setCurrentIndex(197);
}

void MainWindow::on_pushButton_616_clicked()
{
     ui->stackedWidget->setCurrentIndex(197);
}

void MainWindow::on_toolButton_507_clicked()
{
     ui->stackedWidget->setCurrentIndex(199);
}

void MainWindow::on_pushButton_621_clicked()
{
    ui->stackedWidget->setCurrentIndex(188);
}

void MainWindow::on_toolButton_478_clicked()
{
   ui->stackedWidget->setCurrentIndex(200);
}

void MainWindow::on_toolButton_476_clicked()
{
     ui->stackedWidget->setCurrentIndex(56);
}

void MainWindow::on_toolButton_515_clicked()
{
    ui->stackedWidget->setCurrentIndex(188);
}

void MainWindow::on_pushButton_594_clicked()
{
     ui->stackedWidget->setCurrentIndex(189);
}

void MainWindow::on_toolButton_169_clicked()
{
    ui->stackedWidget->setCurrentIndex(201);
}
//connect(ui->m_kEventsCountersBtn,&QPushButton::released, [pCfgSetupMenu](){pCfgSetupMenu->OnCfgSetupMenuDlgEventsCountersBtn();});
void MainWindow::/*on_toolButton_69_clicked*/OnCfgSetupMenuDlgEventsCountersBtn()
{
    ui->stackedWidget->setCurrentIndex(157);
}
//	connect(ui->m_kBatchBtn,&QPushButton::released, [pMainMenu](){pMainMenu->OnMainMenuDlgBatchBtn();});
void MainWindow::/*toolButton_15*/OnMainMenuDlgBatchBtn()
{
    ui->stackedWidget->setCurrentIndex(132);
}

void MainWindow::on_toolButton_337_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_toolButton_342_clicked()
{
    ui->stackedWidget->setCurrentIndex(142);
}

void MainWindow::on_pushButton_400_clicked()
{
    ui->stackedWidget->setCurrentIndex(3);
}

void MainWindow::on_pushButton_399_clicked()
{
    ui->stackedWidget->setCurrentIndex(138);
}

void MainWindow::on_pushButton_401_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_pushButton_409_clicked()
{
    ui->stackedWidget->setCurrentIndex(142);
}

void MainWindow::on_pushButton_410_clicked()
{
    ui->stackedWidget->setCurrentIndex(144);
}

void MainWindow::on_pushButton_411_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_toolButton_423_clicked()
{
   ui->stackedWidget->setCurrentIndex(147);
}

void MainWindow::on_pushButton_442_clicked()
{
ui->stackedWidget->setCurrentIndex(130);
}

void MainWindow::on_pushButton_412_clicked()
{
    ui->stackedWidget->setCurrentIndex(142);
}

void MainWindow::on_pushButton_413_clicked()
{
    ui->stackedWidget->setCurrentIndex(144);
}

void MainWindow::on_pushButton_414_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_pushButton_422_clicked()
{
    ui->stackedWidget->setCurrentIndex(144);
}

void MainWindow::on_pushButton_423_clicked()
{
    ui->stackedWidget->setCurrentIndex(146);
}

void MainWindow::on_pushButton_424_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_pushButton_436_clicked()
{
    ui->stackedWidget->setCurrentIndex(145);
}

void MainWindow::on_pushButton_438_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_toolButton_533_clicked()
{
     ui->stackedWidget->setCurrentIndex(138);
}

void MainWindow::on_toolButton_536_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_pushButton_631_clicked()
{
    ui->stackedWidget->setCurrentIndex(142);
}

void MainWindow::on_pushButton_630_clicked()
{
    ui->stackedWidget->setCurrentIndex(139);
}

void MainWindow::on_pushButton_641_clicked()
{
    ui->stackedWidget->setCurrentIndex(143);
}

void MainWindow::on_pushButton_639_clicked()
{
    ui->stackedWidget->setCurrentIndex(138);
}

void MainWindow::on_pushButton_653_clicked()
{
    ui->stackedWidget->setCurrentIndex(143);
}

void MainWindow::on_pushButton_654_clicked()
{
    ui->stackedWidget->setCurrentIndex(145);
}

void MainWindow::on_pushButton_662_clicked()
{

}

void MainWindow::on_pushButton_640_clicked()
{
   ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_pushButton_655_clicked()
{
   ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_pushButton_663_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_pushButton_632_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_pushButton_229_clicked()
{
    ui->stackedWidget->setCurrentIndex(157);
}

void MainWindow::on_pushButton_275_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_toolButton_170_clicked()
{
    ui->stackedWidget->setCurrentIndex(204);

}

void MainWindow::on_pushButton_234_clicked()
{
    ui->stackedWidget->setCurrentIndex(157);

}

void MainWindow::on_pushButton_276_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_toolButton_171_clicked()
{
    ui->stackedWidget->setCurrentIndex(3);

}

void MainWindow::on_toolButton_172_clicked()
{
     ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_pushButton_665_clicked()
{
     ui->stackedWidget->setCurrentIndex(157);
}

void MainWindow::on_pushButton_667_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_pushButton_677_clicked()
{
    ui->stackedWidget->setCurrentIndex(157);

}

void MainWindow::on_pushButton_679_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_toolButton_167_clicked()
{
    ui->stackedWidget->setCurrentIndex(202);

}

void MainWindow::on_pushButton_683_clicked()
{
    ui->stackedWidget->setCurrentIndex(157);

}

void MainWindow::on_pushButton_685_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_pushButton_690_clicked()
{
    ui->stackedWidget->setCurrentIndex(202);

}

void MainWindow::on_pushButton_692_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_toolButton_168_clicked()
{
    ui->stackedWidget->setCurrentIndex(205);

}

void MainWindow::on_pushButton_703_clicked()
{
    ui->stackedWidget->setCurrentIndex(205);

}

void MainWindow::on_pushButton_705_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_pushButton_696_clicked()
{
    ui->stackedWidget->setCurrentIndex(157);

}

void MainWindow::on_pushButton_698_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_toolButton_82_clicked()
{
    ui->stackedWidget->setCurrentIndex(98);

}

void MainWindow::on_toolButton_85_clicked()
{
    ui->stackedWidget->setCurrentIndex(186);

}

void MainWindow::on_toolButton_473_clicked()
{
    ui->stackedWidget->setCurrentIndex(35);

}

void MainWindow::on_toolButton_470_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_toolButton_403_clicked()
{
    ui->stackedWidget->setCurrentIndex(114);

}

void MainWindow::on_toolButton_398_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_toolButton_670_clicked()
{
    No_Pens pens;
    pens.setModal(true);
    pens.exec();
}

void MainWindow::on_toolButton_671_clicked()
{
    No_Pens pens;
    pens.setModal(true);
    pens.exec();
}

void MainWindow::on_toolButton_543_clicked()
{
    No_Pens pens;
    pens.setModal(true);
    pens.exec();
}

void MainWindow::on_toolButton_547_clicked()
{

    No_Pens pens;
    pens.setModal(true);
    pens.exec();
}

void MainWindow::on_toolButton_546_clicked()
{

    No_Pens pens;
    pens.setModal(true);
    pens.exec();
}
//connect(ui->m_kAlarmsBtn,&QPushButton::released, [pMainMenu](){pMainMenu->OnCountersDlgAlarmsBtn();});
void MainWindow::/*toolBotton_13*/OnCountersDlgAlarmsBtn()
{
    ui->stackedWidget->setCurrentIndex(207);

}

void MainWindow::on_toolButton_545_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_toolButton_544_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_EDIT_LAYOUT_APPEARANCE_Top_Bar_Edit_Layout_2_clicked()
{
    ui->stackedWidget->setCurrentIndex(172);

}
//connect(ui->m_kSettingsBtn,&QPushButton::released, [pConfigMenu](){pConfigMenu->connect(ui->m_kSettingsBtn,&QPushButton::released, [pConfigMenu](){pConfigMenu->OnConfigMenuDlgSettingsBtn();});();});
void MainWindow::/*on_toolButton_45_clicked*/OnConfigMenuDlgSettingsBtn()
{
    ui->stackedWidget->setCurrentIndex(208);

}

void MainWindow::on_toolButton_552_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);

}

void MainWindow::on_toolButton_554_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_toolButton_555_clicked()
{
    set_volume volume;
    volume.setModal(true);
    volume.exec();
}

void MainWindow::on_toolButton_551_clicked()
{
    update_sounds sounds;
    sounds.setModal(true);
    sounds.exec();
}

void MainWindow::on_toolButton_553_clicked()
{
    battery_reset breset;
    breset.setModal(true);
    breset.exec();
}
//connect(ui->m_kSaveBtn,&QPushButton::released, [pLoadSave](){pLoadSave->OnLoadSaveDlgSaveBtn();});
void MainWindow::/*on_toolButton_60_clicked*/OnLoadSaveDlgSaveBtn()
{
    ui->stackedWidget->setCurrentIndex(22);

}
//connect(ui->m_kLoadBtn,&QPushButton::released, [pLoadSave](){pLoadSave->OnLoadSaveDlgLoadBtn();});
void MainWindow::/*on_toolButton_61_clicked*/OnLoadSaveDlgLoadBtn()
{
    ui->stackedWidget->setCurrentIndex(22);

}

void MainWindow::on_toolButton_306_clicked()
{
    ui->stackedWidget->setCurrentIndex(135);

}
//connect(ui->m_kReportsBtn,&QPushButton::released, [pCfgSetupMenu](){pCfgSetupMenu->OnCfgSetupMenuDlgReportsBtn();});
void MainWindow::/*on_toolButton_73_clicked*/OnCfgSetupMenuDlgReportsBtn()
{
    ui->stackedWidget->setCurrentIndex(133);

}

void MainWindow::on_pushButton_426_clicked()
{
    ui->stackedWidget->setCurrentIndex(65);

}

void MainWindow::on_toolButton_299_clicked()
{
    ui->stackedWidget->setCurrentIndex(165);

}

void MainWindow::on_toolButton_301_clicked()
{
    ui->stackedWidget->setCurrentIndex(51);

}

void MainWindow::on_pushButton_465_clicked()
{
    ui->stackedWidget->setCurrentIndex(165);

}

void MainWindow::on_EDIT_SETUP_COMMS_COMMS_SERVICES_OPCUA_BOTTOM_BAR_Back_clicked()
{
    ui->stackedWidget->setCurrentIndex(64);

}

void MainWindow::on_toolButton_309_clicked()
{
    ui->stackedWidget->setCurrentIndex(54);

}

void MainWindow::on_EDIT_SETUP_COMMS_COMMS_SERVICES_MODBUS_RS485_BOTTOM_BAR_Back_clicked()
{
    ui->stackedWidget->setCurrentIndex(65);

}

void MainWindow::on_pushButton_188_clicked()
{
    ui->stackedWidget->setCurrentIndex(115);

}



void MainWindow::on_toolButton_395_clicked()
{
    CJC_Calibration CJC_calib;
    CJC_calib.setModal(true);
    CJC_calib.exec();
}

void MainWindow::on_toolButton_390_clicked()
{
    CJC_Calibration CJC_calib;
    CJC_calib.setModal(true);
    CJC_calib.exec();
}

void MainWindow::on_EDIT_SETUP_GENERAL_FACTORY_DEMO_TRACES_BOTTOM_BAR_Back_clicked()
{
    ui->stackedWidget->setCurrentIndex(131);

}

void MainWindow::on_toolButton_384_clicked()
{
    resets_layout reset_layout;
    reset_layout.setModal(true);
    reset_layout.exec();
}

void MainWindow::on_toolButton_385_clicked()
{
    resets_data reset_data;
    reset_data.setModal(true);
    reset_data.exec();
}

void MainWindow::on_toolButton_386_clicked()
{
    Reset_all reset_all;
    reset_all.setModal(true);
    reset_all.exec();
}

void MainWindow::on_toolButton_387_clicked()
{
    Resets reset_setup;
    reset_setup.setModal(true);
    reset_setup.exec();
}

void MainWindow::on_toolButton_523_clicked()
{
    ui->stackedWidget->setCurrentIndex(188);

}

void MainWindow::on_EDIT_SETUP_COMMS_NETWORK_ADMIN_Botton_Bar_Back_clicked()
{
    ui->stackedWidget->setCurrentIndex(63);

}

void MainWindow::on_EDIT_SETUP_COMMS_NETWORK_ADMIN_Botton_Bar_Finish_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);

}

void MainWindow::on_EDIT_SETUP_GENERAL_ERROR_ALERT_ERROR_TYPES_Bottom_Bar_Finish_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(1);

}

void MainWindow::on_EDIT_SETUP_GENERAL_ERROR_ALERT_ERROR_TYPES_Bottom_Bar_Back_clicked()
{
    ui->stackedWidget->setCurrentIndex(101);

}

void MainWindow::on_pushButton_288_clicked()
{
    ui->stackedWidget->setCurrentIndex(131);

}

void MainWindow::on_pushButton_287_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(1);

}

void MainWindow::on_pushButton_285_clicked()
{
    ui->stackedWidget->setCurrentIndex(131);

}

void MainWindow::on_pushButton_284_clicked()
{
    ui->stackedWidget->setCurrentIndex(130);

}

void MainWindow::on_pushButton_283_clicked()
{
    ui->stackedWidget->setCurrentIndex(3);

}

void MainWindow::on_pushButton_407_clicked()
{
    ui->stackedWidget->setCurrentIndex(131);

}

void MainWindow::on_pushButton_406_clicked()
{
    ui->stackedWidget->setCurrentIndex(130);

}

void MainWindow::on_pushButton_405_clicked()
{
    ui->stackedWidget->setCurrentIndex(3);

}

void MainWindow::on_pushButton_529_clicked()
{
    ui->stackedWidget->setCurrentIndex(3);

}

void MainWindow::on_pushButton_530_clicked()
{
    ui->stackedWidget->setCurrentIndex(130);

}

void MainWindow::on_pushButton_531_clicked()
{
    ui->stackedWidget->setCurrentIndex(131);

}

void MainWindow::on_pushButton_494_clicked()
{
    ui->stackedWidget->setCurrentIndex(64);

}

void MainWindow::on_pushButton_495_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(1);

}

void MainWindow::on_pushButton_497_clicked()
{
    ui->stackedWidget->setCurrentIndex(165);

}

void MainWindow::on_pushButton_295_clicked()
{
    ui->stackedWidget->setCurrentIndex(64);

}

void MainWindow::on_pushButton_294_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(1);

}

void MainWindow::on_EDIT_SETUP_COMMS_TCPIP_DNS_MDNS_WINE_Botton_Bar_Back_clicked()
{
    ui->stackedWidget->setCurrentIndex(92);

}

void MainWindow::on_EDIT_SETUP_COMMS_TCPIP_DNS_MDNS_WINE_Botton_Bar_Finish_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(1);

}

void MainWindow::on_EDIT_SETUP_COMMS_TCPIP_PORT_Bottom_Bar_Back_clicked()
{
    ui->stackedWidget->setCurrentIndex(92);

}

void MainWindow::on_EDIT_SETUP_COMMS_TCPIP_PORT_Bottom_Bar_Finish_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(1);

}

void MainWindow::on_toolButton_39_clicked()
{
    ui->stackedWidget->setCurrentIndex(53);

}

void MainWindow::on_pushButton_301_clicked()
{
    ui->stackedWidget->setCurrentIndex(11);

}

void MainWindow::on_pushButton_300_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(1);

}

void MainWindow::on_EDIT_SETUP_COMMS_TCPIP_Bottom_Bar_Back_clicked()
{
    ui->stackedWidget->setCurrentIndex(63);

}

void MainWindow::on_EDIT_SETUP_COMMS_TCPIP_Bottom_Bar_Finish_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(1);

}

void MainWindow::on_EDIT_SETUP_COMMS_TCPIP_Top_Bar_Comms_clicked()
{
    ui->stackedWidget->setCurrentIndex(63);

}

void MainWindow::on_EDIT_SETUP_COMMS_TCPIP_Top_Bar_Edit_Setup_clicked()
{
    ui->stackedWidget->setCurrentIndex(3);

}

void MainWindow::on_pushButton_492_clicked()
{
    ui->stackedWidget->setCurrentIndex(64);

}

void MainWindow::on_pushButton_491_clicked()
{
    ui->stackedWidget->setCurrentIndex(63);

}

void MainWindow::on_pushButton_490_clicked()
{
    ui->stackedWidget->setCurrentIndex(3);

}

void MainWindow::on_pushButton_503_clicked()
{
    ui->stackedWidget->setCurrentIndex(165);

}

void MainWindow::on_pushButton_502_clicked()
{
    ui->stackedWidget->setCurrentIndex(64);

}

void MainWindow::on_pushButton_501_clicked()
{
    ui->stackedWidget->setCurrentIndex(63);

}

void MainWindow::on_pushButton_500_clicked()
{
    ui->stackedWidget->setCurrentIndex(3);

}

void MainWindow::on_EDIT_SETUP_COMMS_COMMS_SERVICES_OPCUA_TOP_BAR_Comms_Services_clicked()
{
    ui->stackedWidget->setCurrentIndex(64);

}

void MainWindow::on_EDIT_SETUP_COMMS_COMMS_SERVICES_OPCUA_TOP_BAR_Comms_clicked()
{
    ui->stackedWidget->setCurrentIndex(63);

}

void MainWindow::on_EDIT_SETUP_COMMS_COMMS_SERVICES_OPCUA_TOP_BAR_Edit_Setup_clicked()
{
    ui->stackedWidget->setCurrentIndex(3);

}

void MainWindow::on_pushButton_467_clicked()
{
    ui->stackedWidget->setCurrentIndex(63);

}

void MainWindow::on_pushButton_470_clicked()
{
    ui->stackedWidget->setCurrentIndex(64);

}

void MainWindow::on_pushButton_468_clicked()
{
    ui->stackedWidget->setCurrentIndex(165);

}

void MainWindow::on_pushButton_469_clicked()
{
    ui->stackedWidget->setCurrentIndex(150);

}

void MainWindow::on_pushButton_461_clicked()
{
    ui->stackedWidget->setCurrentIndex(165);

}

void MainWindow::on_pushButton_460_clicked()
{
    ui->stackedWidget->setCurrentIndex(64);

}

void MainWindow::on_pushButton_462_clicked()
{
    ui->stackedWidget->setCurrentIndex(63);

}

void MainWindow::on_pushButton_459_clicked()
{
    ui->stackedWidget->setCurrentIndex(3);

}

void MainWindow::on_pushButton_464_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(1);

}

void MainWindow::on_pushButton_473_clicked()
{
    ui->stackedWidget->setCurrentIndex(150);

}

void MainWindow::on_pushButton_472_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(1);

}

void MainWindow::on_pushButton_297_clicked()
{
    ui->stackedWidget->setCurrentIndex(3);

}

void MainWindow::on_pushButton_298_clicked()
{
    ui->stackedWidget->setCurrentIndex(11);

}

void MainWindow::on_pushButton_324_clicked()
{
    ui->stackedWidget->setCurrentIndex(64);

}

void MainWindow::on_pushButton_323_clicked()
{
    ui->stackedWidget->setCurrentIndex(63);

}

void MainWindow::on_pushButton_322_clicked()
{
    ui->stackedWidget->setCurrentIndex(3);

}

void MainWindow::on_pushButton_307_clicked()
{
    ui->stackedWidget->setCurrentIndex(65);

}

void MainWindow::on_pushButton_306_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(1);

}

void MainWindow::on_toolButton_310_clicked()
{
    ui->stackedWidget->setCurrentIndex(52);

}

void MainWindow::on_pushButton_304_clicked()
{
    ui->stackedWidget->setCurrentIndex(65);

}

void MainWindow::on_pushButton_303_clicked()
{
    ui->stackedWidget_2->setCurrentIndex(1);

}

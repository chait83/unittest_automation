/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Events
/// @n Filename: EventControl.cpp
/// @n Desc:	 Processing specifics for individual events
///				 
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  55  Stability Project 1.49.1.4 8/19/2011 6:46:29 PM  Hemant(HAIL) 
// Fix for 32 Pen in a Group in case of Batch
//  54  Stability Project 1.49.1.3 7/2/2011 4:57:07 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  53  Stability Project 1.49.1.2 7/1/2011 4:38:16 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  52  Stability Project 1.49.1.1 3/17/2011 3:20:23 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
// $
//
// ****************************************************************
#include "EventControl.h"
#include "V6globals.h"
#include "EventManager.h"
#include "PenManager.h"
#include "EmailData.h"
#include "SMTPThread.h"
#include "StringUtils.h"
#include "StringDefinitions.h"
#include "RecSetupCfgMgr.h"
#include "FunctionPack.h"
#include "ErrorControl.h"
#include "BatchManager.h"
#include "reportManager.h"
#include "reportgenthread.h"
#include "Crypto.h"
#include "InputConditioning.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
//**********************************************************************
/// CEventControl constructor
///
//**********************************************************************
CEventControl::CEventControl() {
	m_Enabled = FALSE;
}
//**********************************************************************
/// Initialise the CEventControl Instance
///
//**********************************************************************
void CEventControl::Initialise(int instance) {
	m_Instance = instance;			// Assign Instance
	// Setup access to the non-volatile data
	m_pNVData = pNV_VARS->GetBasic8TimeNVObject(static_cast<NVVAR_IDENT>(NVV_EVENTS_FIRST + instance));
	T_BASIC8_WITH_TIME *pNVDataStruct = m_pNVData->GetFromNV();
	m_NVvalue = pNVDataStruct->value;
	m_NVtime = pNVDataStruct->time;
	// Set the schedule with the initial countdown value
	for (int causeIndex = 0; causeIndex < EVENT_CAUSE_SIZE; causeIndex++) {
		m_schedule[causeIndex].SetCountDown(GetSchedCount(causeIndex));
		UserCounterTriggered[causeIndex] = FALSE;
	}
}
//**********************************************************************
/// Setup an individual event from configuration
///
/// @param[in]	pEventCause - ptr to event cause element to be added
/// @param[in]	instance - zero based Instance of Control
///
/// @return		TRUE, if successful, FALSE if failed, Do not continue if failed
//**********************************************************************
T_EVENT_CONTROL_RETURN CEventControl::SetupEventFromConfig(T_PEVENT pConfig, T_PEVENT pOldConfig) {
	T_EVENT_CONTROL_RETURN retVal = EVENTCONTROL_OK;
	m_pEventConfig = pConfig;		// Assign corrisponding event configuration 
	// Get poinetr to data Item
	m_pECDataItem = reinterpret_cast<CDataItemCounter*>(pGlbDIT->GetDataItemPtr(DI_COUNTER, DI_COUNTTYPE_EVENTS,
			m_Instance));
	m_pECDataItem->setTag(QString::fromWCharArray(m_pEventConfig->Name));
	// Only enable event control if event is enabled and the options has been selected
	if (pConfig->Enabled == TRUE && pSYSTEM_INFO->FWOptionEventsAvailable()) {
		m_Enabled = TRUE;
	} else {
		m_Enabled = FALSE;
		ResetEventCount();
		ResetNVTime();
	}
	// Check if the event configuration has changed
	BOOL eventConfigHasChnaged = FALSE;
	if ((pSETUP->GetEventSetupConfig()->HasEventSystemBeenModified()) == TRUE
			&& (memcmp(pConfig, pOldConfig, sizeof(T_EVENT)) != 0)) {
		eventConfigHasChnaged = TRUE;
	}
	// Setup any schedules that might exist
	for (int causeIndex = 0; causeIndex < EVENT_CAUSE_SIZE; causeIndex++) {
		if (m_Enabled == TRUE && pConfig->Cause[causeIndex].Enabled == TRUE) {
			// if the event configuration has changed, notify.
			BOOL configChanged = FALSE;
			if (eventConfigHasChnaged) {
				// Event block has been changed and more importantly, this specific event has changed
				configChanged = TRUE;
				UserCounterTriggered[causeIndex] = FALSE;
			}
			if (pConfig->Cause[causeIndex].Type == ectScheduledEvent) {
				m_schedule[causeIndex].SetupScheduleFromConfig(
						static_cast<T_SCHED_EVENT_SUBTYPE>(pConfig->Cause[causeIndex].SubType),
						&pConfig->Cause[causeIndex].SchedEvent, m_Instance, causeIndex, configChanged);
			} else {
				// The cause is not a scheduled event, disable it.
				m_schedule[causeIndex].DisableSchedule();
			}
		} else {
			// Event itself is not enabled, disable the schedule
			m_schedule[causeIndex].DisableSchedule();
			UserCounterTriggered[causeIndex] = FALSE;
		}
		// Set any modified countdown into the NV
		SetSchedCount(causeIndex, m_schedule[causeIndex].GetCountDown());
	}
	// Setup the effects
	for (int effectIndex = 0; effectIndex < EVENT_EFFECT_SIZE; effectIndex++) {
		if (eventConfigHasChnaged) {
			m_effect[effectIndex].ResetDelayedEvent();
		}
		m_effect[effectIndex].Setup(effectIndex, &pConfig->Effect[effectIndex]);
	}
	// Update and changes to the NV data
	UpdateNVData();
	return retVal;
}
//**********************************************************************
/// Setup an individual event from configuration
///
/// @param[in]	pEventCause - ptr to event cause element to be added
///
/// @return		TRUE, if successful, FALSE if failed, Do not continue if failed
//**********************************************************************
BOOL CEventControl::HasActiveType(T_EVENT_CAUSE_TYPE targetType) {
	BOOL hasActiveType = FALSE;
	int causeIndex = 0;
	// Run though all available causes 
	for (causeIndex = 0; causeIndex < EVENT_CAUSE_SIZE; causeIndex++) {
		// Only check enabled causes
		if (m_pEventConfig->Cause[causeIndex].Enabled == TRUE) {
			// Check f target type matchs the configured type
			if (m_pEventConfig->Cause[causeIndex].Type == targetType) {
				hasActiveType = TRUE;	// Match, target type found
			}
		}
	}
	return hasActiveType;
}
//**********************************************************************
/// Check if the counter based causes have hit thier trigger point
/// if so then trigger the cause immed
///
/// @return nothing
//**********************************************************************
void CEventControl::TriggerFromCounterCheck() {
	int causeIndex = 0;
	for (causeIndex = 0; causeIndex < EVENT_CAUSE_SIZE; causeIndex++) {
		// Check if Cause is enabled
		if (m_pEventConfig->Cause[causeIndex].Enabled == TRUE) {
			// Check if this is a counters based cause
			if (m_pEventConfig->Cause[causeIndex].Type == ectUserCounters) {
				if (m_pEventConfig->Cause[causeIndex].Data.S[USER_COUNTER_NO] < COUNTERS_COUNTER_SIZE) {
					// Check the trigger level has not been reached 
					float currLevel =
							pEVENTS->GetUserCounter(m_pEventConfig->Cause[causeIndex].Data.S[USER_COUNTER_NO])->GetCounterValue();
					if (currLevel >= m_pEventConfig->Cause[causeIndex].TriggerAt) {
						// Counter limit reached, trigger the effects directly.
						if (UserCounterTriggered[causeIndex] == FALSE) {
							pEVENTS->DirectEventTrigger(m_Instance);
							UserCounterTriggered[causeIndex] = TRUE;		// triggered once, don't retrigger
						}
					} else {
						// Counter below trigger point, allow trigger
						UserCounterTriggered[causeIndex] = FALSE;
					}
				}
			}
		}
	}
}
//**********************************************************************
/// Event being triggered by cause, filter on subtype and related data fields
/// and if successful will trigger event
///
/// @param[in]		pEventCause - ptr to event cause element to be added
///
/// @return T_EVENT_CONTROL_RETURN as result of function
//**********************************************************************
T_EVENT_CONTROL_RETURN CEventControl::TriggerFromCause(T_EVENTQUEUE_ELEMENT *pEventCause) {
	int causeIndex = 0;
	BOOL triggerTheEvent = FALSE;
	ULONG ulTriggerInstance = 0;
	// If the cause type is a direct trigger, then trigger otherwise check the causes.
	if (pEventCause->causeType == ectInstantCause) {
		triggerTheEvent = TRUE;
	} else {
		// Make sure the cause subtypes and data match before triggereing
		// Run through all cause configurations and check for an exact match on cause type,subtype and data
		for (causeIndex = 0; causeIndex < EVENT_CAUSE_SIZE; causeIndex++) {
			// Check if Cause is enabled
			if (m_pEventConfig->Cause[causeIndex].Enabled == TRUE) {
				// Make sure it is the correct cause, we already know it must exist in the event
				if (m_pEventConfig->Cause[causeIndex].Type == pEventCause->causeType) {
					// See if enabled cause matches event cause from queue
					if (MatchEventCause(causeIndex, pEventCause, ulTriggerInstance) == TRUE) {
						triggerTheEvent = TRUE;		// Match found, event will be triggered
						break;						// As causes are based on "or" logic we don't need to test any more
					}
				}
			}
		}
	}
	// Has a match been found, if so trigger the effects
	if (triggerTheEvent == TRUE) {
		int effectIndex = 0;
		// Run through and trigger all enabled effects
		for (effectIndex = 0; effectIndex < EVENT_EFFECT_SIZE; effectIndex++) {
			if (m_effect[effectIndex].IsEnabled()) {
				m_effect[effectIndex].Trigger(m_pEventConfig, static_cast<USHORT>(causeIndex),
						static_cast<USHORT>(ulTriggerInstance));		// Trigger the enabled effect
			}
		}
		TouchNVTime();				// Set the event rigger time to current process time
		IncrementEventCount();		// Increment the event counter
		UpdateNVData();				// Update the information
	}
	return EVENTCONTROL_OK;
}
//**********************************************************************
/// Check if cause from system matches the event cause
///
/// @param[in]		CauseInstance - Instance of cause in setup to test
/// @param[in]		pEventCause - ptr to event cause element to be added
/// @param[out]		ULONG &rulTriggerInstance - The zero based instance number that 
///					caused the event e.g. pen 1 or a 1
///
/// @return TRUE if cause matches and event to trigger, otherwise false
//**********************************************************************
BOOL CEventControl::MatchEventCause(int CauseInstance, T_EVENTQUEUE_ELEMENT *pEventCause, ULONG &rulTriggerInstance) {
	BOOL causeMatched = FALSE;
	T_PEVENTCAUSE pCauseConfig = &m_pEventConfig->Cause[CauseInstance];
	// At this point the cause generated by the system matches and enabled cause typoe within an enabled event
	// the next step is to match the Subtype and specific data for each type.
	switch (pEventCause->causeType) {
	case ectAlarm:				// Alarm action cause
	{
		// Alarm has a subtype so check it here
		if (pEventCause->subType == pCauseConfig->SubType) {
			// Check if the Pen number of config and trigger match
			if (pCauseConfig->AlarmData.PenNo == pEventCause->data.S[ALARM_EVENT_CAUSE_PENNUMBER_INDEX]) {
				// Yes, does the alarm mask match the alarm that transitioned
				if ((pCauseConfig->AlarmData.AlarmMask & (1 << pEventCause->data.S[ALARM_EVENT_CAUSE_ALARMNUMBER_INDEX]))
						!= 0) {
					// Alarm number that fired was contained in the mask, it's a full match. Trigger the event
					causeMatched = TRUE;
					rulTriggerInstance = static_cast<ULONG>(pEventCause->data.S[ALARM_EVENT_CAUSE_ALARMNUMBER_INDEX]);
				}
			}
		}
		break;
	}
	case ectTotaliser:			// Totaliser action cause
	{
		// Totaliser has a subtype so check it here
		if (pEventCause->subType == pCauseConfig->SubType) {
			// Perform a logical AND of cause with config, a non-zero in any of the data ULONGS means
			// a match has been found, use the if statement with || as a drop out will occur on match
			// and most likely will occur in 1 - 32.
			if ((pCauseConfig->Data.L[TOTALS_1_32] & pEventCause->data.L[TOTALS_1_32]) != 0) {
				causeMatched = TRUE;
				rulTriggerInstance = pEventCause->data.L[TOTALS_1_32];
				// convert the bitset into an actual instance number
				USHORT usInstance = 0;
				while (rulTriggerInstance > 1) {
					rulTriggerInstance >>= 1;
					++usInstance;
				}
				rulTriggerInstance = static_cast<ULONG>(usInstance);
			} else if ((pCauseConfig->Data.L[TOTALS_33_64] & pEventCause->data.L[TOTALS_33_64]) != 0) {
				causeMatched = TRUE;
				rulTriggerInstance = pEventCause->data.L[TOTALS_33_64];
				// convert the bitset into an actual instance number
				USHORT usInstance = 0;
				while (rulTriggerInstance > 1) {
					rulTriggerInstance >>= 1;
					++usInstance;
				}
				rulTriggerInstance = static_cast<ULONG>(usInstance + 32);
			} else if ((pCauseConfig->Data.L[TOTALS_65_96] & pEventCause->data.L[TOTALS_65_96]) != 0) {
				causeMatched = TRUE;
				rulTriggerInstance = pEventCause->data.L[TOTALS_65_96];
				// convert the bitset into an actual instance number
				USHORT usInstance = 0;
				while (rulTriggerInstance > 1) {
					rulTriggerInstance >>= 1;
					++usInstance;
				}
				rulTriggerInstance = usInstance + 64;
			}
		}
		break;
	}
	case ectDigitalInput:		// Digital Input change cause
	{
		int digMaskIndex = 0;
		USHORT workingMask = 0;
		USHORT invertedMask = 0;
		for (digMaskIndex = 0; digMaskIndex < MAX_DIGITAL_IO_MASKS && causeMatched == FALSE; digMaskIndex++) {
			switch (pCauseConfig->SubType) {
			case EVT_CAUSE_DIG_ON: {
				// Logical AND the bits that have changed by their actual state, this will leave any digital still on as 1
				workingMask = pEventCause->data.S[digMaskIndex]
						& pEventCause->data.S[DIO_CAUSE_CHANGE_MASK_BASE + digMaskIndex];
				// Logical and the reminder (digital that are on) by the ones we are interested in, a on-zero indicates a match
				if ((workingMask & pCauseConfig->Data.S[digMaskIndex]) != 0) {
					causeMatched = TRUE;	// Match, a digital has turned on
					rulTriggerInstance = static_cast<ULONG>(workingMask);
				}
				break;
			}
			case EVT_CAUSE_DIG_OFF: {
				invertedMask = ~pEventCause->data.S[digMaskIndex];
				// Logical AND the bits that have changed by their actual state, this will leave any digital still on as 1
				workingMask = invertedMask & pEventCause->data.S[DIO_CAUSE_CHANGE_MASK_BASE + digMaskIndex];
				// Logical and the reminder (digital that are on) by the ones we are interested in, a on-zero indicates a match
				if ((workingMask & pCauseConfig->Data.S[digMaskIndex]) != 0) {
					causeMatched = TRUE;	// Match, a digital has turned on
					rulTriggerInstance = static_cast<ULONG>(workingMask);
				}
				break;
			}
			case EVT_CAUSE_DIG_CHANGE: {
				// Mask the digital bits we are interested in with what has changed, a non zero indicates a match
				if ((pCauseConfig->Data.S[digMaskIndex] & pEventCause->data.S[DIO_CAUSE_CHANGE_MASK_BASE + digMaskIndex])
						!= 0) {
					causeMatched = TRUE;	// Match, a digital has changed state
					rulTriggerInstance = static_cast<ULONG>(pCauseConfig->Data.S[digMaskIndex]
							& pEventCause->data.S[DIO_CAUSE_CHANGE_MASK_BASE + digMaskIndex]);
				}
				break;
			}
			}
		}
		// convert the bitset into an actual instance number
		USHORT usInstance = 0;
		while (rulTriggerInstance > 1) {
			rulTriggerInstance >>= 1;
			++usInstance;
		}
		rulTriggerInstance = static_cast<ULONG>(usInstance + ((digMaskIndex - 1) * 16));
		break;
	}
	case ectTCBurnOut:			// Thermocouple burnout cause
	{
		// no subtype on burnout, check the TC that burned out is not in the mask
		if (CEventManager::GetBitInMask(pEventCause->data.S[TCBURNOUT_EVENT_CAUSE_ANANUMBER_INDEX],
				&pCauseConfig->Data) == TRUE) {
			// Mask contains analogue value that matches the TC that cause burnout event
			causeMatched = TRUE;
			rulTriggerInstance = static_cast<ULONG>(pEventCause->data.S[TCBURNOUT_EVENT_CAUSE_ANANUMBER_INDEX]);
		}
		break;
	}
	case ectMaxMins: {
		// Match the pen number with the bitmask of pens to trigger on
		if (CEventManager::GetBitInMask(pEventCause->data.S[0], &pCauseConfig->Data) == TRUE) {
			// Pen max min reset was in configured mask, trigger the cause
			causeMatched = TRUE;
			rulTriggerInstance = static_cast<ULONG>(pEventCause->data.S[0]);
		}
		break;
	}
	case ectSystem: {
		// If the subtypes match, it a valid cause
		if (pEventCause->subType == pCauseConfig->SubType) {
			causeMatched = TRUE;
		}
		break;
	}
	case ectUserAction: {
		// If the subtypes match, it a valid cause
		if (pEventCause->subType == pCauseConfig->SubType) {
			causeMatched = TRUE;
		}
		break;
	}
	case ectBatch:		/// Batch start stop or pause
	{
		// If the subtypes match, it a valid cause
		if (pEventCause->subType == pCauseConfig->SubType) {
			// It's the right type of batch action, is it fopr the right group
			if (pEventCause->data.S[0] == pCauseConfig->Data.S[MARKER_EVENT_CAUSE_GROUP_SEL_USHORT_INDEX]) {
				// Yes, batch type and group match. trigger effects
				causeMatched = TRUE;
			}
		}
		break;
	}
	case ectTUS:		/// TUS start or stop
	{
		// If the subtypes match, it a valid cause
		if (pEventCause->subType == pCauseConfig->SubType) {
			// It's the right type of TUS action
			causeMatched = TRUE;
		}
		break;
	}
	case ectAMS2750Timers:		/// AMS2750 Timer (TC or Process)
	{
		// If the subtypes match, it a valid cause
		if (pEventCause->subType == pCauseConfig->SubType) {
			// It's the right type of timer, is it the correct alert (warning or expiry)
			if (pEventCause->data.S[AMS2750_TIMER_CAUSE_ALERT_TYPE_USHORT_INDEX]
					== pCauseConfig->Data.S[AMS2750_TIMER_CAUSE_ALERT_TYPE_USHORT_INDEX]) {
				// Yes, timer type and alert type match. trigger effects
				causeMatched = TRUE;
			}
		}
		break;
	}
	case ectTCHealthMonitor:
		causeMatched = TRUE;
		break;
	default: {
		qDebug(" Unknown Cause %d found in event system \n", pCauseConfig->Type);
		break;
	}
	}
	return causeMatched;
}
//================================================================================================
// CEventEffect Class
//================================================================================================
//**********************************************************************
/// CEventEffect 
///
/// @return nothing
//**********************************************************************
CEventEffect::CEventEffect() {
	m_Enabled = FALSE;
}
//**********************************************************************
/// Configure the effect instance
///
/// @param[in]	Instance - Instance number of the effect within the event
/// @param[in]	pConfig - Configuration for this effect
///
/// @return nothing
//**********************************************************************
void CEventEffect::Setup(int Instance, T_PEVENTEFFECT pConfig) {
	m_pEffectConfig = pConfig;
	m_Instance = Instance;
	ResetList();
	m_Enabled = pConfig->Enabled;
	m_pUserCounter = NULL;
	digIO.Initialise();
	if (m_Enabled) {
		switch (m_pEffectConfig->Type) {
		case eetLogging:
		case eetTotaliser:
		case eetMaxMins: {
			// Produce a list of the Pens required for the following effects
			BuildList(EVENTEFFECT_BYTES_FOR_PENS);
			break;
		}
		case eetDelayedEvent: {
			// Build list of Events for time delay triggering (1-20)
			BuildList(EVENTEFFECT_BYTES_FOR_EVENT_COUNT);
			break;
		}
		case eetTimers: {
			// Build list of script timers for action 
			BuildList(EVENTEFFECT_BYTES_FOR_SCRIPT_TIMERS);
			break;
		}
		case eetDigitalOutput: {
			// Assign digital mask from event data union to digital mask union
			T_DIGITALMASK digMask;
			digMask.L[0] = pConfig->Data.L[0];
			digMask.L[1] = pConfig->Data.L[1];
			// Build digital IO access cache
			digIO.BuildCacheFromMask(&digMask);
			break;
		}
		case eetCounters: {
			switch (m_pEffectConfig->SubType) {
			case ceeEVENTS: {
				// Build list of Events for reset (1-20)
				BuildList(EVENTEFFECT_BYTES_FOR_EVENT_COUNT);
				break;
			}
			case ceeUSER: {
				// This is a user counter type, so get a handle on the counter
				if (pConfig->Data.S[USER_COUNTER_NO] < COUNTERS_COUNTER_SIZE) {
					m_pUserCounter = pEVENTS->GetUserCounter(pConfig->Data.S[USER_COUNTER_NO]);
				} else {
					// User has managed to configure a counter without specifiying the counter number
					m_Enabled = FALSE;
				}
				break;
			}
			case ceeDIGITAL_INPUTS:
			case ceeRELAY_OUTPUTS: {
				// Build a list of dig IO for reset (1-48)
				BuildList(EVENTEFFECT_BYTES_FOR_DIGIO_COUNT);
				break;
			}
			case ceeHARDWARE: {
				// Build a list of Pulse counters for reset (1-48 low and 49-96 high)
				BuildList(EVENTEFFECT_BYTES_FOR_PULSE_COUNT);
				break;
			}
			}
			break;
		}
		}
	} else {
		// Effect not enabled, clear any old link events
		m_LinkEvent.ResetLinkEvent();
	}
}
//**********************************************************************
/// Test if this is an event link effect
///
/// @return TRUE if it is, FALSE if not
//**********************************************************************
BOOL CEventEffect::IsLinkEffect() {
	BOOL retVal = FALSE;
	if (m_Enabled && m_pEffectConfig->Type == eetDelayedEvent) {
		retVal = TRUE;
	}
	return retVal;
}
//**********************************************************************
/// Reset the item list
///
/// @return nothing
//**********************************************************************
void CEventEffect::ResetList() {
	for (int itemIndex = 0; itemIndex < EVENTEFFECT_ITEMLIST_SIZE; itemIndex++) {
		m_ItemList[itemIndex] = 0;
	}
	m_ItemListLength = 0;
}
//**********************************************************************
/// Generate a list of bit set which would corrispond to a list of
/// Pens or Analogues to avoid repetative bit checking
///
/// @param[in]	bytesToConvert - number of bytes to build list for up to EVENTDATA_B_SIZE
///
/// @return nothing
//**********************************************************************
void CEventEffect::BuildList(int bytesToConvert) {
	m_ItemListLength = 0;
	int processByte = 0;
	int bitIndex = 1;
	int currentIndex = 0;
	int currentListIndex = 0;
	BYTE bitMask = 0;
	// Run through required number of bytes adding an entry to the list for every corrisponding bit set
	for (int bytesToProcess = 0; bytesToProcess < bytesToConvert && bytesToProcess < EVENTDATA_B_SIZE;
			bytesToProcess++) {
		bitMask = m_pEffectConfig->Data.B[bytesToProcess];
		for (bitIndex = 0; bitIndex < 8; bitIndex++) {
			if ((bitMask & 0x01) == 1) {
				m_ItemList[currentListIndex++] = currentIndex; // Bit set so record
			}
			currentIndex++;				// Next index
			bitMask = bitMask >> 1;		// Move to next bit for testing
		}
	}
	m_ItemListLength = currentListIndex;	// Total number of items in list
}
//**********************************************************************
/// Trigger the effects
///
/// @param[in]		const T_PEVENT pEVENT - The parent event
/// @param[in]		const USHORT usCAUSE_INDEX - The cause of the event
/// @param[in]		const USHORT usTRIGGER_INSTANCE - The zero based instance number 
///					that trigger the alarm e.g. pen 1, a 1 
///
/// @return nothing
//**********************************************************************
void CEventEffect::Trigger(const T_PEVENT pEVENT, const USHORT usCAUSE_INDEX, const USHORT usTRIGGER_INSTANCE) {
	switch (m_pEffectConfig->Type) {
	case eetMarkChart:			// Mark the Chart
	{
		QString strConvertedString("");
		QString strErrorString("");
		QString strOriginalMark("");
		// check if using preset's or not
		if (m_pEffectConfig->SubType == mcmUSER_DEFINED) {
			// use the marker text
			strOriginalMark = QString::fromWCharArray(m_pEffectConfig->Mark);
		} else {
			// use one of the preset strings
			CGeneralSetupConfig *pkGenCfg = pSETUP->GetGeneralSetupConfig();
			T_PGENERALCONFIG ptGenCfg = pkGenCfg->GetSystemGeneralBlock(CONFIG_COMMITTED);
			strOriginalMark = QString::fromWCharArray(
					ptGenCfg->PresetMarkers[m_pEffectConfig->Data.S[MARKER_EVENT_CAUSE_PRESET_SEL_INDEX]]);
		}
		// now expand the text we have
		if ( pDIT->ExpandEmbeddedValues(strOriginalMark, strConvertedString, MSGLISTSER_NUM_OF_CHARACTERS_PER_MESSAGE,
				strErrorString)) {
			LOG_USER_MESSAGE(MSGLISTSER_USER_GROUP_MARK_ON_CHART, strConvertedString);
		} else {
			LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "MARK CHART EVENT - " + strErrorString);
		}
		break;
	}
	case eetLogging:			// Control logging
	{
		TriggerLoggingAction();
		break;
	}
	case eetTotaliser:			// perform Action on totaliser
	{
		TriggerTotaliserAction();
		break;
	}
	case eetDigitalOutput:		// Set digital output
	{
		if (m_pEffectConfig->SubType == EVT_EFFECT_DIG_assert) {
			digIO.SetDigitalOutputs(CDataItemDigitalIOUser::digassert, NULL);
		} else {
			digIO.SetDigitalOutputs(CDataItemDigitalIOUser::digCLEAR, NULL);
		}
		break;
	}
	case eetAlarmAck:			// Acknowledge Alarm
	{
		TriggerAlarmAcknowledgeOrReset(REQ_ALARM_ACKNOWLEDGE);
		break;
	}
	case eetEmailEvent: {
		TriggerEmail(pEVENT, usCAUSE_INDEX, usTRIGGER_INSTANCE);
		break;
	}
	case eetScreenChange: {
		if (m_pEffectConfig->SubType == seeCHANGE_SCREEN) {
			// post a screen change message to op panel
			::PostMessage(AfxGetApp()->m_pMainWnd->m_hWnd, WM_OPPANEL_SET_TO_SCREEN_NO,
					static_cast<WPARAM>(m_pEffectConfig->Data.S[SCREEN_EFFECT_CHANGE_SCREEN_INDEX_NO]), 0);
		} else {
			// must be backlight on/off
			// the value below indicates the on/off state whereby 0/FALSE = OFF and 1/TRUE = ON
			if (m_pEffectConfig->Data.S[SCREEN_EFFECT_BACKLIGHT_ON_OFF_STATE] == FALSE) {
				pEVENTS->EventTriggerBackLightOff();
			} else {
				pEVENTS->EventTriggerBackLightOn();
			}
		}
		break;
	}
	case eetPrintScreen: {
		::PostMessage(AfxGetApp()->m_pMainWnd->m_hWnd, WM_OPPANEL_PRINT_SCREEN, m_pEffectConfig->SubType,
				m_pEffectConfig->Data.S[PRINT_SCREENSHOT_EFFECT_EXT_MEDIA_USHORT_INDEX]);
		break;
	}
	case eetCounters:				// Trigger counters
	{
		TriggerCounter();
		break;
	}
	case eetMaxMins:				// Reset Max Mins
	{
		TriggerMaxMinReset();
		break;
	}
	case eetChartControl:			// Pause, Stop , Resume, Clean and Prefil charts
	{
		TriggerChartControl();
		break;
	}
	case eetClearMessages:			// Clear message lists
	{
		// E529380 Get msg types to clear
		USHORT msgType = m_pEffectConfig->Data.S[SCREEN_EFFECT_CHART_SPEED];
		COpPanel *pOpPanel = reinterpret_cast<COpPanel*>(AfxGetApp()->GetMainWnd());
		pOpPanel->PostMessage(WM_OPPANEL_CLEARMESSAGELIST, (WPARAM) msgType, 0);
		break;
	}
	case eetDelayedEvent:			// Trigger delayed event
	{
		m_LinkEvent.TriggerEvent(m_pEffectConfig->Data.S[EVENT_EFFECT_DELAYED_EVENT_DELAY_TIME_USHORT_INDEX]);
		break;
	}
	case eetTimers:					// Trigger script timer control
	{
		TriggerTimerControl();
		break;
	}
	case eetSound:
#ifndef V6IOTEST
		// check if start or stop
		if (m_pEffectConfig->SubType == sndSTART_SOUND) {
			// start - get the file name - force the filename list to be updated
			CRecSetupCfgMgr::Instance();
			QString wcaPathName;
			CRecSetupCfgMgr *pkInstance = CRecSetupCfgMgr::Instance();
			QString strFileName(
					CStringUtils::GetItemAtPos(pkInstance->GetSoundFileNamesList(),
							m_pEffectConfig->Data.S[EVENT_EFFECT_SOUND_USHORT_INDEX]));
			// search the custom wavsd directory first
			pDALGLB->BuildPath(IDS_INTERNAL_SD, IDS_CUSTOM_WAVS, &strFileName, &wcaPathName, MAX_PATH);
			CStorage kSoundFile;
			// check the wav file exists before attempting to play it
			if (kSoundFile.exists(wcaPathName)) {
				// stop any sounds already playing
				sndPlaySound(NULL, SND_FILENAME | SND_SYNC);
				// now start our new sound
				if (m_pEffectConfig->Data.S[EVENT_EFFECT_SOUND_PLAY_ONCE_INDEX] == spmSINGLE_SHOT) {
					// play continuously
					sndPlaySound(wcaPathName, SND_FILENAME | SND_ASYNC);
				} else {
					// play once
					sndPlaySound(wcaPathName, SND_FILENAME | SND_ASYNC | SND_LOOP);
				}
			} else {
				// does not exist - try the default wavs directory instead
				pDALGLB->BuildPath(IDS_INTERNAL_SD, IDS_WAVS, strFileName, wcaPathName, MAX_PATH);
				CStorage kSoundFile;
				// check the wav file exists before attempting to play it
				if (kSoundFile.exists(wcaPathName)) {
					// stop any sounds already playing
					sndPlaySound(NULL, SND_FILENAME | SND_SYNC);
					// now start our new sound
					if (m_pEffectConfig->Data.S[EVENT_EFFECT_SOUND_PLAY_ONCE_INDEX] == spmSINGLE_SHOT) {
						// play continuously
						sndPlaySound(wcaPathName, SND_FILENAME | SND_ASYNC);
					} else {
						// play once
						sndPlaySound(wcaPathName, SND_FILENAME | SND_ASYNC | SND_LOOP);
					}
				} else {
					LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "Event Effect Error - Sound file missing!!!");
				}
			}
		} else {
			// stop the sound
			sndPlaySound(NULL, SND_FILENAME | SND_SYNC);
		}
#endif
		break;
	case eetDisplayDialog: {
#ifndef V6IOTEST
		// display the error dialog - events are quite low in the priority order so other events will need
		// to be acknowleged before event messages
		QString strConvertedString("");
		QString strErrorString("");
		QString strOriginalMark("");
		// check if using preset's or not
		if (m_pEffectConfig->SubType == mcmUSER_DEFINED) {
			// use the marker text
			strOriginalMark = m_pEffectConfig->Mark;
		} else {
			// use one of the preset strings
			CGeneralSetupConfig *pkGenCfg = pSETUP->GetGeneralSetupConfig();
			T_PGENERALCONFIG ptGenCfg = pkGenCfg->GetSystemGeneralBlock(CONFIG_COMMITTED);
			strOriginalMark = ptGenCfg->PresetMarkers[m_pEffectConfig->Data.S[MARKER_EVENT_CAUSE_PRESET_SEL_INDEX]];
		}
		// now expand the text we have
		if ( pDIT->ExpandEmbeddedValues(strOriginalMark, strConvertedString, MSGLISTSER_NUM_OF_CHARACTERS_PER_MESSAGE,
				strErrorString)) {
			CErrorControl *pkErrorCtrl = CErrorControl::Instance();
			QString strInfo("");
			strInfo = QString::asprintf("%s\n%s\n%s", pEVENT->Name, L"%s", strConvertedString.toLocal8Bit().data());
			pkErrorCtrl->UpdateErrorCondition(static_cast<T_RECORDER_ERROR_TYPES>(retFIRST_EVENT + m_Instance), true,
					strInfo);
		} else {
			LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "DISPLAY EVENT - " + strErrorString);
		}
#endif
	}
		break;
	case eetBatch:
		if ( pSYSTEM_INFO->FWOptionBatchAvailable()) {
			const USHORT usGROUP_NO = m_pEffectConfig->Data.S[MARKER_EVENT_EFFECT_GROUP_SEL_USHORT_INDEX];
			// perform the selected operation on the selected item
#ifndef V6IOTEST
			CBatchManager *pkBatchMgr = CBatchManager::Instance();
#endif
			QString strMessage("");
			//
			//
			// Stability Project Fix:
			//
			CPenManager *pPenManager = CPenManager::GetHandle();
			bool bBatchStatus = true;
			QString strErrorMsg(L" ");
			QString strSystemMsg("");
			switch (m_pEffectConfig->SubType) {
			case besSTART:
#ifndef V6IOTEST
				pkBatchMgr->StartAutoBatch(usGROUP_NO, pkBatchMgr->GetNextBatchName(usGROUP_NO));
#endif
				//
				//
				// Stability Project Fix:
				//
				//Check the no of pens in a group,If user Loads a Set files having more than 32 pens a group and events are configured for batch (create using TMS 6.1.36 or previous version)
				if (pPenManager->GetNoOfPensInGroup(usGROUP_NO + 1) > pPenManager->GetMaxPensInGroup()) {
					bBatchStatus = false;
				}
				if (bBatchStatus == false) {
					strErrorMsg = QString::asprintf(IDS_DIAGN_BATCH_MSG, usGROUP_NO + 1);
					strSystemMsg = QString::asprintf(IDS_MRKCHRT_MSG, usGROUP_NO + 1);
					LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strErrorMsg);
					LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_INFORMATION, strSystemMsg);
				}
				break;
			case besSTOP:
#ifndef V6IOTEST
				pkBatchMgr->SetBatchStopped(usGROUP_NO);
#endif
				break;
			case besPAUSE:
#ifndef V6IOTEST
				pkBatchMgr->SetBatchPaused(usGROUP_NO);
#endif
				break;
			default:
#ifdef _DEBUG
							DebugBreak();
#endif
				break;
			}
		} else {
			// batch firmware credit not enabled - log an error
			LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR,
					"Could not trigger the batch event as the credit option is disabled");
		}
		break;
	case eetReports: {
		QString strReportName("");
		QString strErrorMsg("");
		T_PREPORTS ptReports = pSETUP->GetEventSetupConfig()->GetReportsBlock(CONFIG_COMMITTED);
		const USHORT usREPORT_INDEX = m_pEffectConfig->Data.S[REPORT_NO_EVENT_EFFECT_USHORT_INDEX];
		// check the report number is okay and the report is still a valid event report and it is enabled
		if ((usREPORT_INDEX < REPORTS_REPORT_SIZE) && (ptReports->Report[usREPORT_INDEX].Enabled == TRUE)
				&& (ptReports->Report[usREPORT_INDEX].Trigger == rstEVENT)) {
#ifndef V6IOTEST
			//PSR - Fix for 1-30DY01Q begin
			//Instead of creating new thread for every effect(triggered from cause) of an event, we are having one
			//Thread all the time ahich queues up the requests and generate reports FIFO
			CReportManager *pReportManager = CReportManager::GetHandle();
			if (NULL != pReportManager) {
				pReportManager->PostReportGenRequest(usREPORT_INDEX);
			}
			//PSR - Fix for 1-30DY01Q end
#endif
		} else if (m_pEffectConfig->Data.S[REPORT_NO_EVENT_EFFECT_USHORT_INDEX] >= REPORTS_REPORT_SIZE) {
			// out of range
			LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR,
					"EVENT ERROR - The report number specfied is not valid");
		} else if ((usREPORT_INDEX < REPORTS_REPORT_SIZE) && (ptReports->Report[usREPORT_INDEX].Enabled != TRUE))//PSR - Coverity issue fix --Out-of-Bounds #770706
				{
			// not enabled
			LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "EVENT ERROR - The report is not enabled");
		} else {
			// must be not an event report
			LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR,
					"EVENT ERROR - The report trigger is not set to 'Event'");
		}
	}
		break;
	case eetUpdateTabDisp:
#ifndef V6IOTEST
		pTABULAR->SetNewDataFromEventTrigger();		// Set flag to add a tabular line at next execution cycle
#endif
		break;
		//E519766
	case eetEnterReplayScreen: {
		// 1-1NARXE1 : Recorder jump to replay mode for non-process screen
		COpPanel *pOpPanel = pEVENTS->GetOpPanel();
		if (pOpPanel) {
			if (!pOpPanel->m_pActiveScreen->IsNonProcessScreen()) {
				::PostMessage(AfxGetApp()->m_pMainWnd->m_hWnd, WM_SHOW_REPLAY_SCREEN, 0, 0);
			}
		}
		break;
	}
	case eetExitReplayScreen:
		::PostMessage(AfxGetApp()->m_pMainWnd->m_hWnd, WM_EXIT_REPLAY_SCREEN, 0, 0);
		break;
		//[ E528446
		// Set the chart speed
	case eetChartSpeed: {
		COpPanel *pOpPanel = NULL;
		USHORT usSCREEN_NO = 0;
		CWidget *pkWidget = NULL;
		USHORT usChartIndex = 0;
		pOpPanel = pEVENTS->GetOpPanel();
		if (pOpPanel) {
			usSCREEN_NO = pOpPanel->m_pActiveScreen->m_pCMMscreen->Number - 1;
			pSYSTEM_INFO->SetChartSpeed(usChartIndex, usSCREEN_NO, m_pEffectConfig->Data.S[SCREEN_EFFECT_CHART_SPEED]);
			pOpPanel->ConfigChange();
			::PostMessage(AfxGetApp()->m_pMainWnd->m_hWnd, WM_OPPANEL_REPAINT, 0, 0);
		}
	}
		break;
		//]
	default: {
		qDebug(" Unknown Event %d found in event system \n", m_pEffectConfig->Type);
		break;
	}
	}
}
//**********************************************************************
/// Trigger a totaliser action
///
/// @return nothing
//**********************************************************************
void CEventEffect::TriggerTotaliserAction() {
	CPenManager *pPenManager = CPenManager::GetHandle();
	// Run though all totalisers to be actioned
	// Set totaliser action mode add 1 for conversion back to T_TOTAL_MODE
	T_TOTAL_MODE eMode = static_cast<T_TOTAL_MODE>(m_pEffectConfig->SubType + 1);
	// check how we are supposed to perform the action - e.g. all pens, a group or a selection of pens
	if (m_pEffectConfig->Data.S[MARKER_EVENT_EFFECT_PEN_SEL_TYPE_USHORT_INDEX] == epsINDIVIDUAL_SELS) {
		// do action for each Pen in the List
		for (int listIndex = 0; listIndex < m_ItemListLength; listIndex++) {
			pPenManager->PerformTotaliserAction(NO_GROUP_SINGLE_PEN, m_ItemList[listIndex], eMode);
		}
	} else if (m_pEffectConfig->Data.S[MARKER_EVENT_EFFECT_PEN_SEL_TYPE_USHORT_INDEX] == epsPEN_GROUP) {
		// required to update a specific group
		pPenManager->PerformTotaliserAction(
				static_cast<T_PEN_GROUPS>(m_pEffectConfig->Data.S[MARKER_EVENT_EFFECT_GROUP_SEL_USHORT_INDEX]
						+ PEN_GROUP_1), 0, eMode);
	} else {
		// required to update all pens
		pPenManager->PerformTotaliserAction(PEN_GROUP_ALL, 0, eMode);
	}
}
//**********************************************************************
/// Trigger a logging Action
///
/// @return nothing
//**********************************************************************
void CEventEffect::TriggerLoggingAction() {
	CPenManager *pPenManager = CPenManager::GetHandle();
	// check how we are supposed to perform the action - e.g. all pens, a group or a selection of pens
	if (m_pEffectConfig->Data.S[MARKER_EVENT_EFFECT_PEN_SEL_TYPE_USHORT_INDEX] == epsINDIVIDUAL_SELS) {
		if (m_pEffectConfig->SubType == EVT_EFFECT_LOG_START) {
			// Start logging on all required pens
			for (int listIndex = 0; listIndex < m_ItemListLength; listIndex++) {
				pPenManager->StartPenLogging(m_ItemList[listIndex]);
			}
		} else {
			// Stop logging on all required pens
			for (int listIndex = 0; listIndex < m_ItemListLength; listIndex++) {
				pPenManager->StopPenLogging(m_ItemList[listIndex]);
			}
		}
	} else if (m_pEffectConfig->Data.S[MARKER_EVENT_EFFECT_PEN_SEL_TYPE_USHORT_INDEX] == epsPEN_GROUP) {
		// required to update a specific group
		if (m_pEffectConfig->SubType == EVT_EFFECT_LOG_START) {
			pPenManager->StartLogging(
					static_cast<T_PEN_GROUPS>(m_pEffectConfig->Data.S[MARKER_EVENT_EFFECT_GROUP_SEL_USHORT_INDEX]
							+ PEN_GROUP_1));
		} else {
			pPenManager->StopLogging(
					static_cast<T_PEN_GROUPS>(m_pEffectConfig->Data.S[MARKER_EVENT_EFFECT_GROUP_SEL_USHORT_INDEX]
							+ PEN_GROUP_1));
		}
	} else {
		// required to update all pens
		if (m_pEffectConfig->SubType == EVT_EFFECT_LOG_START) {
			pPenManager->StartLogging(PEN_GROUP_ALL);
		} else {
			pPenManager->StopLogging(PEN_GROUP_ALL);
		}
	}
}
//**********************************************************************
/// Trigger an alarm acknowledgement
///
/// @param[in] - reqType,	REQ_ALARM_ACKNOWLEDGE to acknowledge these alarm or 
///							REQ_ALARM_RESET to reset these alarms	
/// @return nothing
//**********************************************************************
void CEventEffect::TriggerAlarmAcknowledgeOrReset(T_ALARM_REQUEST reqType) {
	CPenManager *pPenManager = CPenManager::GetHandle();
	// check how we are supposed to perform the action - e.g. all pens, a group or a selection of pens
	if (m_pEffectConfig->Data.S[MARKER_EVENT_EFFECT_PEN_SEL_TYPE_USHORT_INDEX] == epsINDIVIDUAL_SELS) {
		USHORT alarmMask = m_pEffectConfig->AlarmData.AlarmMask;
		// Run though alarm mask chyecking for alarms set to be acknowledged
		for (int alarmIndex = 0; alarmIndex < V6_MAX_ALARMS; alarmIndex++) {
			if ((alarmMask & 0x01) == 1) {
				// Alarm to be acknowledged or reset
				pPenManager->AcknowledgeOrResetAlarm(reqType, NO_GROUP_SINGLE_PEN, m_pEffectConfig->AlarmData.PenNo,
						alarmIndex);
			}
			alarmMask >>= 1;
		}
	} else if (m_pEffectConfig->Data.S[MARKER_EVENT_EFFECT_PEN_SEL_TYPE_USHORT_INDEX] == epsPEN_GROUP) {
		// required to update a specific group
		pPenManager->AcknowledgeAlarm(
				static_cast<T_PEN_GROUPS>(PEN_GROUP_1
						+ m_pEffectConfig->Data.S[MARKER_EVENT_EFFECT_GROUP_SEL_USHORT_INDEX]), 0, ACK_ALL_ALARMS);
	} else {
		// required to update all pens
		pPenManager->AcknowledgeAlarm(PEN_GROUP_ALL, 0, ACK_ALL_ALARMS);
	}
}
//**********************************************************************
/// Trigger a MaxMin Reset
///
/// @return nothing
//**********************************************************************
void CEventEffect::TriggerMaxMinReset() {
	CPenManager *pPenManager = CPenManager::GetHandle();
	// check how we are supposed to perform the action - e.g. all pens, a group or a selection of pens
	if (m_pEffectConfig->Data.S[MARKER_EVENT_EFFECT_PEN_SEL_TYPE_USHORT_INDEX] == epsINDIVIDUAL_SELS) {
		// Reset Max Mins for each Pen in the List
		for (int listIndex = 0; listIndex < m_ItemListLength; listIndex++) {
			pPenManager->PerformMaxMinResetAction(NO_GROUP_SINGLE_PEN, m_ItemList[listIndex], MM_MODE_RESET_BOTH,
			FALSE);
		}
	} else if (m_pEffectConfig->Data.S[MARKER_EVENT_EFFECT_PEN_SEL_TYPE_USHORT_INDEX] == epsPEN_GROUP) {
		// required to update a specific group
		pPenManager->PerformMaxMinResetAction(
				static_cast<T_PEN_GROUPS>(m_pEffectConfig->Data.S[MARKER_EVENT_EFFECT_GROUP_SEL_USHORT_INDEX]
						+ PEN_GROUP_1), 0, MM_MODE_RESET_BOTH,
				FALSE);
	} else {
		// required to update all pens
		pPenManager->PerformMaxMinResetAction(PEN_GROUP_ALL, 0, MM_MODE_RESET_BOTH, FALSE);
	}
}
//**********************************************************************
/// Test and possibly a delayed event effect
///
/// @return nothing
//**********************************************************************
BOOL CEventEffect::TestAndTriggerDelayedEvent() {
	BOOL isTriggered = FALSE;
	// Check if the delayed event time has elapsed
	if (m_LinkEvent.IsScheduleComplete() == TRUE) {
		// Yes , so Trigger every Event in the list
		for (int listIndex = 0; listIndex < m_ItemListLength; listIndex++) {
			if ( pEVENTS->GetEventControl(m_ItemList[listIndex])->IsEnabled()) {
				pEVENTS->DirectEventTrigger(m_ItemList[listIndex]);
			}
		}
		isTriggered = TRUE;
	}
	return isTriggered;
}
//**********************************************************************
/// Trigger a Timer control
///
/// @return nothing
//**********************************************************************
void CEventEffect::TriggerTimerControl() {
	// Reset Max Mins for each Pen in the List
	for (int listIndex = 0; listIndex < m_ItemListLength; listIndex++) {
		switch (m_pEffectConfig->SubType) {
		case EVT_EFFECT_COUNT_START: {
			// Start the script timer, do not reset
			FP_runScriptTimer(m_ItemList[listIndex], FALSE);
			break;
		}
		case EVT_EFFECT_COUNT_STOP: {
			// Stop the script timer
			FP_pauseScriptTimer(m_ItemList[listIndex]);
			break;
		}
		case EVT_EFFECT_COUNT_RESET: {
			// Reset the script timer
			FP_resetScriptTimer(m_ItemList[listIndex]);
			break;
		}
		case EVT_EFFECT_COUNT_RESETSTART: {
			// Reset and Start the script timer 
			FP_runScriptTimer(m_ItemList[listIndex], TRUE);
			break;
		}
		}
	}
}
//**********************************************************************
/// Trigger a chart control action
///
/// @return nothing
//**********************************************************************
void CEventEffect::TriggerChartControl() {
	// Trigger the required chart control function in Op Panel
	COpPanel *pOpPanel = reinterpret_cast<COpPanel*>(AfxGetApp()->GetMainWnd());
	// the one based group number
	USHORT usOneBasedGroupNo = 0;
	// check if group or all - this onyl really applies to pause and resume
	if (m_pEffectConfig->Data.S[MARKER_EVENT_EFFECT_CHART_CONTROL_GROUP_SEL_USHORT_INDEX] == ecgALL_GROUPS) {
		// all groups
		usOneBasedGroupNo = 0;
	} else {
		// specific group
		usOneBasedGroupNo = m_pEffectConfig->Data.S[MARKER_EVENT_CAUSE_GROUP_SEL_USHORT_INDEX] + PEN_GROUP_1;
	}
	switch (m_pEffectConfig->SubType) {
	case ccePAUSE:
		pOpPanel->PostMessage(WM_OPPANEL_PAUSE_CHARTS, static_cast<WPARAM>(usOneBasedGroupNo), 0);
		break;
	case cceSTOP:
		pOpPanel->PostMessage(WM_OPPANEL_STOP_CHARTS, 0, 0);
		break;
	case cceRESUME:
		pOpPanel->PostMessage(WM_OPPANEL_RESUME_CHARTS, static_cast<WPARAM>(usOneBasedGroupNo), 0);
		break;
	case cceCLEAR:
		pOpPanel->PostMessage(WM_OPPANEL_CLEAR_CHARTS, 0, 0);
		break;
	case ccePREFILL:
		pOpPanel->PostMessage(WM_OPPANEL_PREFILL_CHARTS, 0, 0);
		break;
	}
}
//**********************************************************************
/// Trigger a counter action
///
/// @return nothing
//**********************************************************************
void CEventEffect::TriggerCounter() {
	// Perform effect dependent on counter subtype	
	switch (m_pEffectConfig->SubType) {
	case ceeUSER: {
		if (m_pUserCounter->IsEnabled()) {
			// Reset or Increment a user counter
			if (m_pEffectConfig->Data.S[RESET_OR_INC_COUNTER] == FALSE) {
				// It's a reset, Reset the counter to the value defined in the effect
				m_pUserCounter->ResetCounter(m_pEffectConfig->ResetTo);
			} else {
				// It's an increment, increment the counter by the value defines in the event effect
				m_pUserCounter->IncrementCounter(m_pEffectConfig->IncrementBy);
				// If the counter exceeds the limit, reset it to the events reset value
				if (m_pUserCounter->GetCounterValue() > m_pUserCounter->GetCounterLimit()) {
					// Reset the counter to the start value plus and remainder.
					m_pUserCounter->ResetCounter(
							m_pUserCounter->GetCounterStartValue()
									+ (m_pUserCounter->GetCounterValue() - m_pUserCounter->GetCounterLimit()));
				}
			}
		}
		break;
	}
	case ceeALARMS: {
		TriggerAlarmAcknowledgeOrReset(REQ_ALARM_RESET);	// Reset Alarm counters
		break;
	}
	case ceeEVENTS: {
		// Run though all selected event counters, reseting each one.
		int controlIndex = 0;
		for (int listIndex = 0; listIndex < m_ItemListLength; listIndex++) {
			controlIndex = m_ItemList[listIndex];
			if (controlIndex < EVENTSYSTEM_EVENT_SIZE) {
				pEVENTS->GetEventControl(controlIndex)->ResetEventCount();
			}
		}
		break;
	}
	case ceeDIGITAL_INPUTS:
	case ceeRELAY_OUTPUTS: {
		// Run though all Digital IO resetting ones selected for configuration
		CDataItemCounter *m_pCountDataItem = NULL;
		for (int listIndex = 0; listIndex < m_ItemListLength; listIndex++) {
			m_pCountDataItem = reinterpret_cast<CDataItemCounter*>(pGlbDIT->GetDataItemPtr(DI_COUNTER, DI_COUNTTYPE_IO,
					m_ItemList[listIndex]));
			if (m_pCountDataItem != NULL) {
				m_pCountDataItem->ResetCounter(0);
			}
		}
		break;
	}
	case ceeHARDWARE: {
		// Run though all High and Lo pulse counters
		int controlIndex = 0;
		CDataItemCounter *m_pCountDataItem = NULL;
		for (int listIndex = 0; listIndex < m_ItemListLength; listIndex++) {
			controlIndex = m_ItemList[listIndex];
			// Check if the counter is high pulse or low pulse
			if (controlIndex < MAX_LORES_PULSE) {
				// Low pulse, use 0-47 index straight
				m_pCountDataItem = reinterpret_cast<CDataItemCounter*>(pGlbDIT->GetDataItemPtr(DI_COUNTER,
						DI_COUNTTYPE_LCOUNT, controlIndex));
			} else {
				// High pulse, stored as 48-95, so realign to 0-47
				m_pCountDataItem = reinterpret_cast<CDataItemCounter*>(pGlbDIT->GetDataItemPtr(DI_COUNTER,
						DI_COUNTTYPE_HCOUNT, controlIndex - MAX_LORES_PULSE));
			}
			if (m_pCountDataItem != NULL) {
				m_pCountDataItem->ResetCounter(0);
			}
		}
		break;
	}
	}
}
//**********************************************************************
//	void TriggerEmail( const T_PEVENT pEVENT, const USHORT usCAUSE_INDEX ) const
///
///	Method that triggers the sending of an email
///
/// @param[in]		const T_PEVENT pEVENT - The parent event
/// @param[in]		const USHORT usCAUSE_INDEX - The cause of the event
/// @param[in]		const USHORT usTRIGGER_INSTANCE - The zero based instance number 
///					that trigger the alarm e.g. pen 1, a 1 
///
//**********************************************************************
void CEventEffect::TriggerEmail(const T_PEVENT pEVENT, const USHORT usCAUSE_INDEX,
		const USHORT usTRIGGER_INSTANCE) const {
	// now send the email necessary
	CCommsSetupConfig *pkCommsConfig = pGlbSetup->GetCommsSetupConfig();
	CGeneralSetupConfig *pkGenConfig = pGlbSetup->GetGeneralSetupConfig();
	T_PCOMMUNICATIONS ptCommsData = NULL;
	QString strRecipients("");
	// check the FW options allow emails
	if ( pSYSTEM_INFO->FWOptionEmailAvailable() && (pkCommsConfig != NULL) && (pkGenConfig != NULL)) {
		quint64 emailRecipients = 0;
		memcpy(&emailRecipients, &m_pEffectConfig->Data.L[EMAIL_EFFECT_RECIPIENTS_INDEX_NUMBER], sizeof(quint64));
		strRecipients = pkCommsConfig->GetEmailAddresses(emailRecipients);
		ptCommsData = pkCommsConfig->GetCommsBlock(CONFIG_COMMITTED);
		if ((ptCommsData != NULL) && (strRecipients != "")) {
			T_EMAIL *ptEmail = &ptCommsData->Email;
			QString strUsername("");
			QString strPassword("");
			if (ptEmail->ServerReqAuth != FALSE) {
				strUsername = QString::asprintf("%s", ptEmail->Username);
				CCrypto kCrypto;
				strPassword = kCrypto.Decrypt(QString::fromWCharArray(ptEmail->Password), EMAIL_PASSWORD_LEN);
			}
			// create the subject
			QString strSubject("");
			T_PGENERALCONFIG ptGeneral = pkGenConfig->GetSystemGeneralBlock(CONFIG_COMMITTED);
			if (ptGeneral != NULL) {
				strSubject = QString::asprintf(IDS_EVENTS_EMAIL_SUBJECT_TITLE, ptGeneral->Name, pEVENT->Name);
			}
			// now create the message body
			QString strMessage("");
			// always create the email header
			strMessage = CreateEmailHeader(pEVENT, usCAUSE_INDEX, usTRIGGER_INSTANCE);
			switch (m_pEffectConfig->SubType) {
			case eeeAUTO:
				// don't need to add any more information
				break;
			case eeeSINGLE_LINE_USER: {
				QString strConvertedText("");
				QString strErrorString("");
				QString strOriginalText = QString::fromWCharArray(m_pEffectConfig->Mark);
				if ( pDIT->ExpandEmbeddedValues(strOriginalText, strConvertedText, -1, strErrorString)) {
					strMessage += strConvertedText;
				} else {
					// replace the email text with the error message instead
					strMessage += strErrorString + "\n";
					LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "EMAIL EVENT - " + strErrorString);
				}
				break;
			}
			case eeeMULTI_LINE_USER: {
				QString strConvertedText("");
				QString strErrorString("");
				USHORT usEmailIndexNo = m_pEffectConfig->Data.S[EMAIL_EFFECT_TEMPLATES_INDEX_NUMBER];
				// check it is not exceeding our array
				if (usEmailIndexNo >= EMAIL_TEMPLATES_SIZE) {
					// too big - default to 0
					DebugBreak();
					usEmailIndexNo = 0;
				}
				QString strOriginalText = QString::fromWCharArray(
						pkCommsConfig->GetEmailBlock(usEmailIndexNo, CONFIG_COMMITTED));
				if ( pDIT->ExpandEmbeddedValues(strOriginalText, strConvertedText, -1, strErrorString)) {
					strMessage += strConvertedText;
				} else {
					// replace the email text with the error message instead
					strMessage += strErrorString + "\n";
					LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "EMAIL EVENT - " + strErrorString);
				}
				// now replace the automated subject line with this template subject line
				strOriginalText = QString::fromWCharArray(ptCommsData->Email.Templates[usEmailIndexNo]);
				if ( pDIT->ExpandEmbeddedValues(strOriginalText, strConvertedText, -1, strErrorString)) {
					strSubject = strConvertedText;
				} else {
					// replace the email text with the error message instead
					strSubject += strErrorString + "\n";
					LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "EMAIL EVENT - " + strErrorString);
				}
				break;
			}
			default:
				break;
			}
#ifndef V6IOTEST
			const CEmailData kMAIL_DATA(strRecipients, ptEmail->UserAddress, ptEmail->UserAddress, strSubject,
					strMessage, ptEmail->ServerName, ptEmail->SecurityMode, ptEmail->STARTTLSSupport, ptEmail->Port,
					strUsername, strPassword, (m_pEffectConfig->Data.S[EMAIL_EFFECT_ATTACH_SCREENSHOT] != FALSE));
			CSMTPThread::AddEmailToPending(kMAIL_DATA);
#endif
		}
	}
}
//**********************************************************************
//	const QString CreateEmailHeader( const T_PEVENT pEVENT, const USHORT usCAUSE_INDEX ) const
///
///	Method that creates the email header string
///
/// @param[in]		const T_PEVENT pEVENT - The parent event
/// @param[in]		const USHORT usCAUSE_INDEX - The cause of the event
/// @param[in]		const USHORT usTRIGGER_INSTANCE - The zero based instance number 
///					that trigger the alarm e.g. pen 1, a 1 
///
//**********************************************************************
const QString CEventEffect::CreateEmailHeader(const T_PEVENT pEVENT, const USHORT usCAUSE_INDEX,
		const USHORT usTRIGGER_INSTANCE) const {
	// create the email header which is basically the event cause information
	QString strEmailHeader("");
	QString strHyperLink("");
	// add a hyperlink to the recorder
	// use the IP address if the web server is enabled
	CCommsSetupConfig *pkCommsCfg = pSETUP->GetCommsSetupConfig();
	T_PCOMMUNICATIONS ptCOMMS = pkCommsCfg->GetCommsBlock(CONFIG_COMMITTED);
	if (ptCOMMS->Ethernet.EnableWeb == TRUE) {
		// check for non-standard port numbers
		if (ptCOMMS->Ethernet.HTTPSocket != 80) {
			strHyperLink = QString::asprintf("http://%s:%u/", pkCommsCfg->GetIPAddress().toLocal8Bit().data(),
					ptCOMMS->Ethernet.HTTPSocket);
		} else {
			strHyperLink = QString::asprintf("http://%s", pkCommsCfg->GetIPAddress().toLocal8Bit().data());
		}
		// add some blank lines
		strHyperLink += "\n\n";
	} else {
		// no web server therefore do not embed the hyperlink
		strHyperLink = "";
	}
	// add the cause information to the header
	QString strCauseList("");
	strCauseList =
			QWidget::tr(
					"Alarms|Totalizers|Digital Inputs|TC Burn Out|Scheduled|User Counters|Max Mins (Reset)|System|User Action|Batch|TUS|AMS2750 Timer|TC Health Monitor|");
	strEmailHeader = QString::asprintf(IDS_EVENTS_EMAIL_MESSAGE_HEADER_TITLE, strHyperLink.toLocal8Bit().data(),
			CStringUtils::GetItemAtPos(strCauseList.toLocal8Bit().data(), pEVENT->Cause[usCAUSE_INDEX].Type));
	// get the subtype information, if any
	QString strSubTypeList("");
	switch (pEVENT->Cause[usCAUSE_INDEX].Type) {
	case ectAlarm:
		strSubTypeList = QWidget::tr("Into Alarm|Out of Alarm|Ack. Alarm|");
		break;
	case ectTotaliser:
		strSubTypeList = QWidget::tr("Start|Stop|Reset|Rollover|");
		break;
	case ectDigitalInput:
		strSubTypeList = QWidget::tr("On|Off|State Change|");
		break;
	case ectScheduledEvent:
		strSubTypeList = QWidget::tr("Once|Interval|Specific Days|Month End|");
		break;
	case ectSystem:
		strSubTypeList = QWidget::tr("Power On|Setup Change|Int. Mem. Low|Exp. Mem. Lo|FTP Mem. Lo|");
		break;
	case ectUserAction:
		if ( pDALGLB->IsRecorderMulti()) {
			strSubTypeList = QWidget::tr("Mark Chart|Hot Button 1|Hot Button 2|Hot Button 3|Hot Button 4|");
		} else {
			strSubTypeList = QWidget::tr("Mark Chart|Hot Button 1|Hot Button 2|");
		}
		break;
	case ectBatch:
		strSubTypeList = QWidget::tr("Start|Stop|Pause|");
		break;
	case ectTUS:
		strSubTypeList = QWidget::tr("Start|Stop|Soak Started|Stability Achieved|Soak Complete|");
		break;
	case ectAMS2750Timers:
		strSubTypeList = QWidget::tr("TC/RT Timers|Process Timers|");
		break;
	case ectUserCounters:
	case ectTCBurnOut:
	case ectMaxMins:
	case ectTCHealthMonitor:
	default:
		break;
	}
	// check there is some subtype information
	if (strSubTypeList != "") {
		QString strSubType("");
		strSubType = QString::asprintf(IDS_EVENTS_EMAIL_MESSAGE_SUBTYPE_INFO,
				CStringUtils::GetItemAtPos(strSubTypeList, pEVENT->Cause[usCAUSE_INDEX].SubType));
		strEmailHeader += strSubType;
	}
	QString strAdditionalInfo("");
	// now create the relevant additional information
	switch (pEVENT->Cause[usCAUSE_INDEX].Type) {
	case ectAlarm: {
		// add the pen number
		QString strAlarms("");
		strAlarms = QString::asprintf("%u", usTRIGGER_INSTANCE + 1);
		strAdditionalInfo = QString::asprintf(IDS_EVENTS_EMAIL_MESSAGE_ALARM_ADDITIONAL_INFO,
				pEVENT->Cause[usCAUSE_INDEX].AlarmData.PenNo + 1, strAlarms.toLocal8Bit().data());
	}
		break;
	case ectTotaliser: {
		// add the pen number
		QString strPens("");
		strPens = QString::asprintf("%u", usTRIGGER_INSTANCE + 1);
		strAdditionalInfo = QString::asprintf(IDS_EVENTS_EMAIL_MESSAGE_TOTALISER_ADDITIONAL_INFO,
				strPens.toLocal8Bit().data());
	}
		break;
	case ectDigitalInput: {
		// add the digital number
		QString strDigitals("");
		strDigitals = QString::asprintf("%u", usTRIGGER_INSTANCE + 1);
		strAdditionalInfo = QString::asprintf(IDS_EVENTS_EMAIL_MESSAGE_DIGITALS_ADDITIONAL_INFO,
				strDigitals.toLocal8Bit().data());
	}
		break;
	case ectTCBurnOut: {
		// add the analogue input number
		QString strAnalogues("");
		strAnalogues = QString::asprintf("%u", usTRIGGER_INSTANCE + 1);
		strAdditionalInfo = QString::asprintf(IDS_EVENTS_EMAIL_MESSAGE_AI_ADDITIONAL_INFO,
				strAnalogues.toLocal8Bit().data());
	}
		break;
	case ectScheduledEvent: {
		// setup the scheduled event details
		switch (pEVENT->Cause[usCAUSE_INDEX].SubType) {
		case sesOnce: {
			// show the date/time field
			QString strDateTime("");
			quint64 ullDateTime = pEVENT->Cause[usCAUSE_INDEX].SchedEvent.DateTime;
			ullDateTime *= 1000000;
			CTVtime kTime(ullDateTime);
			kTime.ShortTimeAsString(strDateTime);
			// now add the date
			QString strDate("");
			kTime.DateAsString(strDate);
			strDateTime += " " + strDate;
			strAdditionalInfo = QString::asprintf(IDS_EVENTS_EMAIL_MESSAGE_SCHED_ADDITIONAL_INFO,
					strDateTime.toLocal8Bit().data());
		}
			break;
		case sesInterval: {
			// show the period and convert the value into hour mins seconds etc
			strAdditionalInfo = QString::asprintf(IDS_EVENTS_EMAIL_MESSAGE_SCHED_ADDITIONAL_INFO,
					CStringUtils::GetAutoDDHHMMSSspanFromSeconds(
							static_cast<__int64 >(pEVENT->Cause[usCAUSE_INDEX].SchedEvent.IntervalPeriod)));
		}
			break;
		case sesSpecDays: {
			// Show the days
			QString strDOWList("");
			QString strDOW("");
			QString strTime("");
			strDOWList = QWidget::tr("Sun|Mon|Tues|Weds|Thurs|Fri|Sat|");
			USHORT usBitmask = 0x0001;
			for (USHORT usCount = 0; usCount < 7; usCount++) {
				// check if the current alarm is set
				if ((usBitmask & pEVENT->Cause[usCAUSE_INDEX].SchedEvent.WeekDay) == usBitmask) {
					// It is set so add it
					strDOW += CStringUtils::GetItemAtPos(strDOWList, usCount) + ", ";
				}
				// shift onto the next bit
				usBitmask <<= 1;
			}
			// remove the trailing ', '
			if (strDOW != "") {
				strDOW.remove(strDOW.size() - 2, 2);
			}
			// add the time data field
			CTVtime kTime(static_cast<__int64 >(pEVENT->Cause[usCAUSE_INDEX].SchedEvent.DateTime) * 1000000);
			kTime.ShortTimeAsString(strTime);
			strTime += " " + strDOW;
			strAdditionalInfo = QString::asprintf(IDS_EVENTS_EMAIL_MESSAGE_SCHED_ADDITIONAL_INFO,
					strTime.toLocal8Bit().data());
		}
			break;
		case sesMonthEnd:
			// do nothing for this one
			break;
		default:
			break;
		}
	}
		break;
	case ectUserCounters: {
		// add the analogue input number
		QString strCounters("");
		QString strTriggerAt("");
		T_NUMFORMAT tNumasprintf;
		tNumasprintf.Auto = TRUE;
		tNumasprintf.Scientific = FALSE;
		strTriggerAt = CStringUtils::asprintfFloat(tNumasprintf, pEVENT->Cause[usCAUSE_INDEX].TriggerAt);
		strCounters = QString::asprintf("%u", usTRIGGER_INSTANCE + 1);
		strAdditionalInfo = QString::asprintf(IDS_EVENTS_EMAIL_MESSAGE_USER_COUNTER_ADDITIONAL_INFO,
				strCounters.toLocal8Bit().data(), strTriggerAt.toLocal8Bit().data());
	}
		break;
	case ectMaxMins: {
		// add the mam min pen number
		QString strMaxMins("");
		strMaxMins = QString::asprintf("%u", usTRIGGER_INSTANCE + 1);
		strAdditionalInfo = QString::asprintf(IDS_EVENTS_EMAIL_MESSAGE_MAX_MINS_ADDITIONAL_INFO,
				strMaxMins.toLocal8Bit().data());
	}
		break;
	case ectAMS2750Timers: {
		// add the alert type
		QString strAlertTitle("");
		QString strAlertTypeList("");
		strAlertTitle = QWidget::tr("Alert Type");
		strAlertTypeList = QWidget::tr("Warning|Expired|");
		strAdditionalInfo = QString::asprintf("%s: %s", strAlertTitle.toLocal8Bit().data(),
				CStringUtils::GetItemAtPos(strAlertTypeList,
						pEVENT->Cause[usCAUSE_INDEX].Data.S[AMS2750_TIMER_CAUSE_ALERT_TYPE_USHORT_INDEX]));
	}
		break;
	case ectTCHealthMonitor: {
		//add the status of TC
		if (pEVENT->Cause[usCAUSE_INDEX].Data.S[0] == CInputConditioning::BURNOUT_OK) {
			strAdditionalInfo = QString::asprintf(IDS_ACTIVE_BURNOUT_OK_LOG, usTRIGGER_INSTANCE + 1);
		} else if (pEVENT->Cause[usCAUSE_INDEX].Data.S[0] == CInputConditioning::BURNOUT_TC_FAILING) {
			strAdditionalInfo = QString::asprintf(IDS_ACTIVE_BURNOUT_FAILING_LOG, usTRIGGER_INSTANCE + 1);
		} else if (pEVENT->Cause[usCAUSE_INDEX].Data.S[0] == CInputConditioning::BURNOUT_TC_ALMOST_FAILED) {
			strAdditionalInfo = QString::asprintf(IDS_ACTIVE_BURNOUT_ALMOST_FAILED_LOG, usTRIGGER_INSTANCE + 1);
		} else if (pEVENT->Cause[usCAUSE_INDEX].Data.S[0] == CInputConditioning::BURNOUT_TC_OC_DETECTED
				&& pEVENT->Cause[usCAUSE_INDEX].Data.S[1] == DISTAT_INPUT_UPSCALE_BURNOUT) {
			strAdditionalInfo = QString::asprintf(IDS_UPSCALE_BURNOUT_LOG, usTRIGGER_INSTANCE + 1);
		} else if (pEVENT->Cause[usCAUSE_INDEX].Data.S[0] == CInputConditioning::BURNOUT_TC_OC_DETECTED
				&& pEVENT->Cause[usCAUSE_INDEX].Data.S[1] == DISTAT_INPUT_DOWNSCALE_BURNOUT) {
			strAdditionalInfo = QString::asprintf(IDS_DOWNSCALE_BURNOUT_LOG, usTRIGGER_INSTANCE + 1);
		}
	}
		break;
	default:
		break;
	}
	strEmailHeader += strAdditionalInfo;
	return strEmailHeader;
}

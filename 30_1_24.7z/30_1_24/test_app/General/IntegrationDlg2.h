#if !defined(AFX_INTEGRATIONDLG2_H__EA47FAC9_F0B6_43EC_BD95_E44E2A691507__INCLUDED_)
#define AFX_INTEGRATIONDLG2_H__EA47FAC9_F0B6_43EC_BD95_E44E2A691507__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// IntegrationDlg2.h : header file
//
/////////////////////////////////////////////////////////////////////////////
// CIntegrationDlg2 dialog
class CIntegrationDlg2: public QDialog {
// Construction
public:
	CIntegrationDlg2(CWidget *pParent = NULL);  // standard constructor
// Dialog Data
	//{{AFX_DATA(CIntegrationDlg2)
	enum {
		IDD = IDD_ANALOGS2
	};
	// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA
	COpPanel *pOpPanel;
	void InitInputType(int controlID);
	void InitVoltRanges(int controlID);
	void InitCurrentRanges(int controlID);
	void InitAcqRates(int controlID);
	void ConfigChange();
	void SetCurSel(int controlID, int selection);
	void TypeChange(int controlID);
	void RangeChange(int controlID);
	void RateChange(int controlID);
	void RefreshAnalogs();
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIntegrationDlg2)
	//}}AFX_VIRTUAL
// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CIntegrationDlg2)
	void OnPage1();
	void OnPage3();
	void OnQuit();
	virtual BOOL OnInitDialog();
	void OnSelchangeType9();
	void OnSelchangeType10();
	void OnSelchangeType11();
	void OnSelchangeType12();
	void OnSelchangeType13();
	void OnSelchangeType14();
	void OnSelchangeType15();
	void OnSelchangeType16();
	void OnSelchangeRange9();
	void OnSelchangeRange10();
	void OnSelchangeRange11();
	void OnSelchangeRange12();
	void OnSelchangeRange13();
	void OnSelchangeRange14();
	void OnSelchangeRange15();
	void OnSelchangeRange16();
	void OnSelchangeRate9();
	void OnSelchangeRate10();
	void OnSelchangeRate11();
	void OnSelchangeRate12();
	void OnSelchangeRate13();
	void OnSelchangeRate14();
	void OnSelchangeRate15();
	void OnSelchangeRate16();
	void OnApply();
	//}}AFX_MSG
};
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.
#endif // !defined(AFX_INTEGRATIONDLG2_H__EA47FAC9_F0B6_43EC_BD95_E44E2A691507__INCLUDED_)

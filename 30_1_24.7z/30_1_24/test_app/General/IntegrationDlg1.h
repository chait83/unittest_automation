#if !defined(AFX_INTEGRATIONDLG1_H__D66360B9_347C_4B27_B256_82CA43D9BE4C__INCLUDED_)
#define AFX_INTEGRATIONDLG1_H__D66360B9_347C_4B27_B256_82CA43D9BE4C__INCLUDED_
#include <QDialog>
#include "Defines.h"
#include "Widget.h"
/////////////////////////////////////////////////////////////////////////////
// CIntegrationDlg1 dialog
class CIntegrationDlg1: public QDialog {
// Construction
public:
	CIntegrationDlg1(CWidget *pParent = NULL);  // standard constructor
// Dialog Data
	//{{AFX_DATA(CIntegrationDlg1)
	// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA
	COpPanel *pOpPanel;
	void InitInputType(int controlID);
	void InitVoltRanges(int controlID);
	void InitCurrentRanges(int controlID);
	void InitAcqRates(int controlID);
	void ConfigChange();
	void SetCurSel(int controlID, int selection);
	void TypeChange(int controlID);
	void RangeChange(int controlID);
	void RateChange(int controlID);
	void RefreshAnalogs();
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIntegrationDlg1)
	//}}AFX_VIRTUAL
// Implementation
protected:
	void OnPage2();
	void OnPage3();
	void OnQuit();
	virtual BOOL OnInitDialog();
	void OnSelchangeType1();
	void OnSelchangeType2();
	void OnSelchangeType3();
	void OnSelchangeType4();
	void OnSelchangeType5();
	void OnSelchangeType6();
	void OnSelchangeType7();
	void OnSelchangeType8();
	void OnSelchangeRange1();
	void OnSelchangeRange2();
	void OnSelchangeRange3();
	void OnSelchangeRange4();
	void OnSelchangeRange5();
	void OnSelchangeRange6();
	void OnSelchangeRange7();
	void OnSelchangeRange8();
	void OnSelchangeRate1();
	void OnSelchangeRate2();
	void OnSelchangeRate3();
	void OnSelchangeRate4();
	void OnSelchangeRate5();
	void OnSelchangeRate6();
	void OnSelchangeRate7();
	void OnSelchangeRate8();
	void OnApply();
};
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.
#endif // !defined(AFX_INTEGRATIONDLG1_H__D66360B9_347C_4B27_B256_82CA43D9BE4C__INCLUDED_)

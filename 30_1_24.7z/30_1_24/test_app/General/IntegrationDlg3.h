#if !defined(AFX_INTEGRATIONDLG3_H__16DFA072_885F_4C54_BDB7_1A36FBA322C2__INCLUDED_)
#define AFX_INTEGRATIONDLG3_H__16DFA072_885F_4C54_BDB7_1A36FBA322C2__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// IntegrationDlg3.h : header file
//
/////////////////////////////////////////////////////////////////////////////
// CIntegrationDlg3 dialog
class CIntegrationDlg3: public QDialog {
// Construction
public:
	CIntegrationDlg3(CWidget *pParent = NULL);  // standard constructor
// Dialog Data
	//{{AFX_DATA(CIntegrationDlg3)
	enum {
		IDD = IDD_DIGITALS
	};
	//}}AFX_DATA
	COpPanel *pOpPanel;
	void ConfigChange();
	void SetCurSel(int controlID, int selection);
	void InitDigitalType(int controlID);
	void RefreshStats();
	void RefreshDigitals();
	void ButtonClicked(int controlID);
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIntegrationDlg3)
	//}}AFX_VIRTUAL
// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CIntegrationDlg3)
	void OnSelchangeDigtype1_8();
	void OnSelchangeDigtype9_16();
	void OnRadio1();
	void OnRadio10();
	void OnRadio11();
	void OnRadio12();
	void OnRadio13();
	void OnRadio14();
	void OnRadio15();
	void OnRadio16();
	void OnRadio2();
	void OnRadio3();
	void OnRadio4();
	void OnRadio5();
	void OnRadio6();
	void OnRadio7();
	void OnRadio8();
	void OnRadio9();
	void OnQuit();
	void OnApply();
	void OnPage1();
	void OnPage2();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
};
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.
#endif // !defined(AFX_INTEGRATIONDLG3_H__16DFA072_885F_4C54_BDB7_1A36FBA322C2__INCLUDED_)

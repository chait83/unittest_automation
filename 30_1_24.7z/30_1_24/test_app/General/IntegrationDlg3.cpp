/// @n Module: 	 Integration
/// @n Filename: IntegrationDlg3.cpp 
/// @n Description: Dialog to show digital IO
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  11  Stability Project 1.8.1.1 7/2/2011 4:57:59 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  10  Stability Project 1.8.1.0 7/1/2011 4:26:47 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  9 V6 Firmware 1.8 3/30/2005 2:39:58 PM  Alistair Brugsch
//  Changed constants starting with CONFIGCHANGE to MOD_CFG_CHG and added
//  extra message parameter
//  8 V6 Firmware 1.7 3/14/2005 10:08:44 PM  Jason Parker  
//  Updated to use V6ActiveModule 
// $
//
// **************************************************************************
#include "oppanelincludes.h"
#include "IntegrationDlg3.h"
#include "setupconfiguration.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
//extern CDataItemTable Glb_datatable; // Global datatable (for now)
extern CIntegrationDlg1 *Glb_pDialog1;
extern CIntegrationDlg2 *Glb_pDialog2;
extern CIntegrationDlg3 *Glb_pDialog3;
/////////////////////////////////////////////////////////////////////////////
// CIntegrationDlg3 dialog
CIntegrationDlg3::CIntegrationDlg3(CWidget *pParent /*=NULL*/) : QDialog(CIntegrationDlg3::IDD, pParent) {
	//{{AFX_DATA_INIT(CIntegrationDlg3)
	// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	pOpPanel = (COpPanel*) pParent; // keep pointer to OpPanel
}
BEGIN_MESSAGE_MAP(CIntegrationDlg3, QDialog)
//{{AFX_MSG_MAP(CIntegrationDlg3)
ON_CBN_SELCHANGE(IDC_DIGTYPE1, OnSelchangeDigtype1_8)
ON_CBN_SELCHANGE(IDC_DIGTYPE2, OnSelchangeDigtype9_16)
ON_BN_CLICKED(IDC_RADIO1, OnRadio1)
ON_BN_CLICKED(IDC_RADIO10, OnRadio10)
ON_BN_CLICKED(IDC_RADIO11, OnRadio11)
ON_BN_CLICKED(IDC_RADIO12, OnRadio12)
ON_BN_CLICKED(IDC_RADIO13, OnRadio13)
ON_BN_CLICKED(IDC_RADIO14, OnRadio14)
ON_BN_CLICKED(IDC_RADIO15, OnRadio15)
ON_BN_CLICKED(IDC_RADIO16, OnRadio16)
ON_BN_CLICKED(IDC_RADIO2, OnRadio2)
ON_BN_CLICKED(IDC_RADIO3, OnRadio3)
ON_BN_CLICKED(IDC_RADIO4, OnRadio4)
ON_BN_CLICKED(IDC_RADIO5, OnRadio5)
ON_BN_CLICKED(IDC_RADIO6, OnRadio6)
ON_BN_CLICKED(IDC_RADIO7, OnRadio7)
ON_BN_CLICKED(IDC_RADIO8, OnRadio8)
ON_BN_CLICKED(IDC_RADIO9, OnRadio9)
ON_BN_CLICKED(IDOK, OnQuit)
ON_BN_CLICKED(IDC_APPLY, OnApply)
ON_BN_CLICKED(IDC_PAGE1, OnPage1)
ON_BN_CLICKED(IDC_PAGE2, OnPage2)
//}}AFX_MSG_MAP
END_MESSAGE_MAP()
/////////////////////////////////////////////////////////////////////////////
// CIntegrationDlg3 message handlers
void CIntegrationDlg3::OnQuit()
{
	DestroyWindow();
	delete this;
	Glb_pDialog3=NULL;
}
BOOL CIntegrationDlg3::OnInitDialog() {
	QDialog::OnInitDialog();
	if (pOpPanel->m_ScreenWidth > 320) {
		// multiplus... position dialog across.
		QRect rect;
		GetWindowRect(&rect);
		OffsetRect(&rect, 20, 20);
		OffsetRect(&rect, 0, _Height(rect) + 20);
		move(rect.left, rect.top, _Width(rect), _Height(rect), TRUE);
	}
	// now set up the initial state for the radio buttons. (get state from DataITemTable)
	RefreshDigitals();
	// now look in the setup configuration and set them as they are.
	/*
	 USHORT Selection;
	 if(pOpPanel->m_pSetupConfig->QueryAIChannelSelection( i+1, &Selection )==CONFIG_OK)
	 {
	 // select the input type (volts/amps)
	 SetCurSel((IDC_TYPE1)+i,Selection);
	 }
	 */
	return TRUE; // return TRUE unless you set the focus to a control
				 // EXCEPTION: OCX Property Pages should return FALSE
}
void CIntegrationDlg3::SetCurSel(int controlID, int selection) {
	CComboBox *pbox = (CComboBox*) GetDlgItem(controlID);
	pbox->SetCurSel(selection); // select the top item.
}
void CIntegrationDlg3::OnApply() {
	ConfigChange(); // apply changes
}
void CIntegrationDlg3::ConfigChange() {
	T_MOD_CFG_CHG_MSGDATA msg;
	msg.TypeOfConfigChange = MOD_CFG_CHG_SETUP;
	msg.configChangeSystemAction = MOD_SYS_CFG_CHG_NORMAL_OPERATION;
	msg.ConfigChangeAction = MOD_CFG_CHG_ACTION_UPDATE;
	memset(msg.fileNameAndPath, 0, sizeof(msg.fileNameAndPath));
	// tell control sequencer about the update
	pOpPanel->m_pV6Module->SignalConfigChange(sizeof(T_MOD_CFG_CHG_MSGDATA), (UCHAR*) &msg);
}
void CIntegrationDlg3::InitDigitalType(int controlID) {
	CComboBox *pbox = (CComboBox*) GetDlgItem(controlID);
	pbox->ResetContent(); // empty it
	pbox->AddString(L"Input");
	pbox->AddString(L"Output");
}
void CIntegrationDlg3::OnPage1() {
	if (Glb_pDialog1 == NULL) {
		Glb_pDialog1 = new CIntegrationDlg1(pOpPanel);
		if (Glb_pDialog1 != NULL) {
			BOOL ret = Glb_pDialog1->Create(L"ANALOGS1", NULL);
			Glb_pDialog1->ShowWindow(SW_SHOW);
		}
	} else
		Glb_pDialog1->SetForegroundWindow();
}
void CIntegrationDlg3::OnPage2() {
	if (Glb_pDialog2 == NULL) {
		Glb_pDialog2 = new CIntegrationDlg2(pOpPanel);
		if (Glb_pDialog2 != NULL) {
			BOOL ret = Glb_pDialog2->Create(L"ANALOGS2", NULL);
			Glb_pDialog2->ShowWindow(SW_SHOW);
		}
	} else
		Glb_pDialog2->SetForegroundWindow();
}
void CIntegrationDlg3::RefreshStats() {
	wchar_t buff[20];
	for (int i = 0; i < 13; i++) {
		CWidget *pValue = GetDlgItem((IDC_VAR1) + i);
//		int val=Glb_datatable.Pens[100+i].Value.vint;
		int val = 1;
		swprintf(buff, L"%d", val);
		pValue->setWindowTitle(buff);
	}
	// do digitals too
//	RefreshDigitals();
	sleep(50);
}
void CIntegrationDlg3::RefreshDigitals() {
	for (int i = 0; i < 16; i++) {
		QPushButton *pRadio = (QPushButton*) GetDlgItem(IDC_RADIO1 + i);
//		int digitalNumber=i+1;
//		int numupdates;
		//	if(Glb_datatable.GetDigital(digitalNumber, numupdates))		
		//		pRadio->SetCheck(BST_CHECKED);			
		//	else		
		//		pRadio->SetCheck(BST_UNCHECKED);
		//	pRadio->setEnabled(Glb_datatable.GetDigitalType(digitalNumber));
	}
}
void CIntegrationDlg3::ButtonClicked(int controlID) {
	QPushButton *pRadio = (QPushButton*) GetDlgItem(controlID);
	int digitalNumber = (controlID - (IDC_RADIO1)) + 1;
	int numupdates = 0;
//	if(Glb_datatable.GetDigital(digitalNumber, numupdates))
//	{
//		pRadio->SetCheck(BST_UNCHECKED);
//		Glb_datatable.SetDigital(digitalNumber,FALSE);
//	}
//	else
//	{
//		pRadio->SetCheck(BST_CHECKED);
//		Glb_datatable.SetDigital(digitalNumber,TRUE);
//	}
}
void CIntegrationDlg3::OnSelchangeDigtype1_8() {
	// TODO: Add your control notification handler code here
}
void CIntegrationDlg3::OnSelchangeDigtype9_16() {
	// TODO: Add your control notification handler code here
}
void CIntegrationDlg3::OnRadio1() {
	ButtonClicked (IDC_RADIO1);
}
void CIntegrationDlg3::OnRadio10() {
	ButtonClicked (IDC_RADIO10);
}
void CIntegrationDlg3::OnRadio11() {
	ButtonClicked (IDC_RADIO11);
}
void CIntegrationDlg3::OnRadio12() {
	ButtonClicked (IDC_RADIO12);
}
void CIntegrationDlg3::OnRadio13() {
	ButtonClicked (IDC_RADIO13);
}
void CIntegrationDlg3::OnRadio14() {
	ButtonClicked (IDC_RADIO14);
}
void CIntegrationDlg3::OnRadio15() {
	ButtonClicked (IDC_RADIO15);
}
void CIntegrationDlg3::OnRadio16() {
	ButtonClicked (IDC_RADIO16);
}
void CIntegrationDlg3::OnRadio2() {
	ButtonClicked (IDC_RADIO2);
}
void CIntegrationDlg3::OnRadio3() {
	ButtonClicked (IDC_RADIO3);
}
void CIntegrationDlg3::OnRadio4() {
	ButtonClicked (IDC_RADIO4);
}
void CIntegrationDlg3::OnRadio5() {
	ButtonClicked (IDC_RADIO5);
}
void CIntegrationDlg3::OnRadio6() {
	ButtonClicked (IDC_RADIO6);
}
void CIntegrationDlg3::OnRadio7() {
	ButtonClicked (IDC_RADIO7);
}
void CIntegrationDlg3::OnRadio8() {
	ButtonClicked (IDC_RADIO8);
}
void CIntegrationDlg3::OnRadio9() {
	ButtonClicked (IDC_RADIO9);
}

// HelpViewerControl.cpp : Defines the class behaviors for the application.
//
#include "HelpViewerControl.h"
#include "HelpViewerControlDlg.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
/////////////////////////////////////////////////////////////////////////////
// CHelpViewerControlApp
BEGIN_MESSAGE_MAP(CHelpViewerControlApp, CWinApp)
//{{AFX_MSG_MAP(CHelpViewerControlApp)
// NOTE - the ClassWizard will add and remove mapping macros here.
//    DO NOT EDIT what you see in these blocks of generated code!
//}}AFX_MSG
END_MESSAGE_MAP()
/////////////////////////////////////////////////////////////////////////////
// CHelpViewerControlApp construction
CHelpViewerControlApp::CHelpViewerControlApp()
: CWinApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}
/////////////////////////////////////////////////////////////////////////////
// The one and only CHelpViewerControlApp object
CHelpViewerControlApp theApp;
/////////////////////////////////////////////////////////////////////////////
// CHelpViewerControlApp initialization
BOOL CHelpViewerControlApp::InitInstance() {
	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.
	CHelpViewerControlDlg dlg;
	m_pMainWnd = &dlg;
	SIZEINFO p_sizeInfo;
	p_sizeInfo.winWidth = 640;		// window width
	p_sizeInfo.winHeight = 480;		// window Height
	p_sizeInfo.btnWidth = 105;		// Button width must be 3 times less than window width
	p_sizeInfo.btnHeight = 25;		// Button Height
	QString dirPath;
	dirPath += PATH;				// get the default directory path
	dlg.InitializeHelp(&p_sizeInfo, dirPath);	// invoke the InitializeHelp method
	BOOL b = dlg.InvokeHelp("index");				// invoke the InvokeHelp method	
	/*int nResponse = dlg.DoModal();
	 if (nResponse == IDOK)
	 {
	 // TODO: Place code here to handle when the dialog is
	 //  dismissed with OK
	 }
	 else if (nResponse == IDCANCEL)
	 {
	 // TODO: Place code here to handle when the dialog is
	 //  dismissed with Cancel
	 }*/
	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Integration
/// @n Filename: IntegrationDlg2.cpp 
/// @n Description: Dialog to show analogs 9-16
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  21  Stability Project 1.18.1.1 7/2/2011 4:57:59 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  20  Stability Project 1.18.1.0 7/1/2011 4:26:47 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  19  V6 Firmware 1.18 7/29/2005 2:32:39 PM  Graham Waterfield
//  Removed topslot channel map - needed to remove validate and adjust
//  board setup temporaraly due to channel map not fulfilling original
//  design.
//  Validate & adjust still requires implementation
//  18  V6 Firmware 1.17 6/29/2005 8:01:33 PM  Roger Dawson  
//  Modified to use the global recorder setup pointer rather than the op
//  panel recorder setup pointer
// $
//
// **************************************************************************
#include "oppanelincludes.h"
#include "IntegrationDlg2.h"
#include "SetupConfiguration.h"
#include "IOSetupConfig.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
//extern CDataItemTable Glb_datatable; // Global datatable (for now)
extern CIntegrationDlg1 *Glb_pDialog1;
extern CIntegrationDlg2 *Glb_pDialog2;
extern CIntegrationDlg3 *Glb_pDialog3;
/////////////////////////////////////////////////////////////////////////////
// CIntegrationDlg2 dialog
CIntegrationDlg2::CIntegrationDlg2(CWidget *pParent /*=NULL*/) : QDialog(CIntegrationDlg2::IDD, pParent) {
	//{{AFX_DATA_INIT(CIntegrationDlg2)
	// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	pOpPanel = (COpPanel*) pParent; // keep pointer to OpPanel
}
BEGIN_MESSAGE_MAP(CIntegrationDlg2, QDialog)
//{{AFX_MSG_MAP(CIntegrationDlg2)
ON_BN_CLICKED(IDC_PAGE1, OnPage1)
ON_BN_CLICKED(IDC_PAGE3, OnPage3)
ON_BN_CLICKED(IDOK, OnQuit)
ON_CBN_SELCHANGE(IDC_TYPE9, OnSelchangeType9)
ON_CBN_SELCHANGE(IDC_TYPE10, OnSelchangeType10)
ON_CBN_SELCHANGE(IDC_TYPE11, OnSelchangeType11)
ON_CBN_SELCHANGE(IDC_TYPE12, OnSelchangeType12)
ON_CBN_SELCHANGE(IDC_TYPE13, OnSelchangeType13)
ON_CBN_SELCHANGE(IDC_TYPE14, OnSelchangeType14)
ON_CBN_SELCHANGE(IDC_TYPE15, OnSelchangeType15)
ON_CBN_SELCHANGE(IDC_TYPE16, OnSelchangeType16)
ON_CBN_SELCHANGE(IDC_RANGE9, OnSelchangeRange9)
ON_CBN_SELCHANGE(IDC_RANGE10, OnSelchangeRange10)
ON_CBN_SELCHANGE(IDC_RANGE11, OnSelchangeRange11)
ON_CBN_SELCHANGE(IDC_RANGE12, OnSelchangeRange12)
ON_CBN_SELCHANGE(IDC_RANGE13, OnSelchangeRange13)
ON_CBN_SELCHANGE(IDC_RANGE14, OnSelchangeRange14)
ON_CBN_SELCHANGE(IDC_RANGE15, OnSelchangeRange15)
ON_CBN_SELCHANGE(IDC_RANGE16, OnSelchangeRange16)
ON_CBN_SELCHANGE(IDC_RATE9, OnSelchangeRate9)
ON_CBN_SELCHANGE(IDC_RATE10, OnSelchangeRate10)
ON_CBN_SELCHANGE(IDC_RATE11, OnSelchangeRate11)
ON_CBN_SELCHANGE(IDC_RATE12, OnSelchangeRate12)
ON_CBN_SELCHANGE(IDC_RATE13, OnSelchangeRate13)
ON_CBN_SELCHANGE(IDC_RATE14, OnSelchangeRate14)
ON_CBN_SELCHANGE(IDC_RATE15, OnSelchangeRate15)
ON_CBN_SELCHANGE(IDC_RATE16, OnSelchangeRate16)
ON_BN_CLICKED(IDC_APPLY, OnApply)
//}}AFX_MSG_MAP
END_MESSAGE_MAP()
/////////////////////////////////////////////////////////////////////////////
// CIntegrationDlg2 message handlers
void CIntegrationDlg2::OnQuit()
{
	// TODO: Add your control notification handler code here
	DestroyWindow();
	delete this;
	Glb_pDialog2=NULL;
}
BOOL CIntegrationDlg2::OnInitDialog() {
	class CIOSetupConfig *pIOSetupConfig = pGlbSetup->GetIOSetupConfig();
	QDialog::OnInitDialog();
	if (pOpPanel->m_ScreenWidth > 320) {
		// multiplus... position dialog across.
		QRect rect;
		GetWindowRect(&rect);
		OffsetRect(&rect, 20, 20);
		OffsetRect(&rect, _Width(rect) + 20, 0);
		move(rect.left, rect.top, _Width(rect), _Height(rect), TRUE);
	}
	// set up the settings in the dialog from the current setup in use
	for (int i = 8; i < 16; i++) {
		// first set up the defaults for the input.
		// set up input type (volts/amps)
		InitInputType((IDC_TYPE1) + i);
		// then select top entry (volts)
		SetCurSel((IDC_TYPE1) + i, 0);
		// set up the ranges for volts
		InitVoltRanges((IDC_RANGE1) + i);
		// and then select the top one.
		SetCurSel((IDC_RANGE1) + i, 0);
		// set the rates
		InitAcqRates((IDC_RATE1) + i);
		// then select the top one
		SetCurSel((IDC_RATE1) + i, 0);
		// now look in the setup configuration and set them as they are.
		USHORT Selection;
		if (pIOSetupConfig->QueryAIChannelSelection(CONFIG_MODIFIABLE, i + 1, &Selection) == CONFIG_OK) {
			// select the input type (volts/amps)
			SetCurSel((IDC_TYPE1) + i, Selection);
			if (Selection == AI_CHANNEL_TYPE_LINEAR_VOLTS) {
				// set up the ranges for volts
				InitVoltRanges((IDC_RANGE1) + i);
				USHORT Range;
				if (pIOSetupConfig->QueryVoltageRange(CONFIG_MODIFIABLE, i + 1, &Range) == CONFIG_OK) {
					// use it
					SetCurSel((IDC_RANGE1) + i, Range);
				}
			} else if (Selection == AI_CHANNEL_TYPE_LINEAR_AMPS) {
				// set up the ranges for current
				InitCurrentRanges((IDC_RANGE1) + i);
				USHORT Range;
				if (pIOSetupConfig->QueryCurrentRange(CONFIG_MODIFIABLE, i + 1, &Range) == CONFIG_OK) {
					// use it
					SetCurSel((IDC_RANGE1) + i, Range);
				}
			}
			USHORT Rate;
			if (pIOSetupConfig->QueryAIAcqRate(CONFIG_MODIFIABLE, i + 1, &Rate) == CONFIG_OK) {
				// use it
				SetCurSel((IDC_RATE1) + i, Rate);
			}
		}
	}
	return TRUE; // return TRUE unless you set the focus to a control
				 // EXCEPTION: OCX Property Pages should return FALSE
}
void CIntegrationDlg2::SetCurSel(int controlID, int selection) {
	CComboBox *pbox = (CComboBox*) GetDlgItem(controlID);
	pbox->SetCurSel(selection); // select the top item.
}
void CIntegrationDlg2::OnApply() {
	ConfigChange(); // apply changes 
}
void CIntegrationDlg2::ConfigChange() {
	T_MOD_CFG_CHG_MSGDATA msg;
	msg.TypeOfConfigChange = MOD_CFG_CHG_SETUP;
	msg.configChangeSystemAction = MOD_SYS_CFG_CHG_NORMAL_OPERATION;
	msg.ConfigChangeAction = MOD_CFG_CHG_ACTION_UPDATE;
	memset(msg.fileNameAndPath, 0, sizeof(msg.fileNameAndPath));
	// tell control sequencer about the update
	pOpPanel->m_pV6Module->SignalConfigChange(sizeof(T_MOD_CFG_CHG_MSGDATA), (UCHAR*) &msg);
}
void CIntegrationDlg2::InitInputType(int controlID) {
	CComboBox *pbox = (CComboBox*) GetDlgItem(controlID);
	pbox->ResetContent(); // empty it
	// Channel input specifiers
	//#define AI_CHANNEL_TYPE_LINEAR_VOLTS		0		// Input type of voltage
	pbox->AddString(L"V");
	//#define AI_CHANNEL_TYPE_LINEAR_AMPS		1		// Current
	pbox->AddString(L"A");
}
void CIntegrationDlg2::InitVoltRanges(int controlID) {
	CComboBox *pbox = (CComboBox*) GetDlgItem(controlID);
	pbox->ResetContent(); // empty it
	// Channel voltage ranges
	//#define LINEAR_VOLTS_50V				0
	pbox->AddString(L"50V");
	//#define LINEAR_VOLTS_25V				1
	pbox->AddString(L"25V");
	//#define LINEAR_VOLTS_12V				2
	pbox->AddString(L"12V");
	//#define LINEAR_VOLTS_6V				3
	pbox->AddString(L"6V");
	//#define LINEAR_VOLTS_3V				4
	pbox->AddString(L"3V");
	//#define LINEAR_VOLTS_1_5V				5
	pbox->AddString(L"1.5V");
	//#define LINEAR_VOLTS_0_6V				6
	pbox->AddString(L"0.6V");
	//#define LINEAR_VOLTS_0_3V				7
	pbox->AddString(L"0.3V");
	//#define LINEAR_VOLTS_1000mV			8
	pbox->AddString(L"1000mV");
	//#define LINEAR_VOLTS_500mV			9
	pbox->AddString(L"500mV");
	//#define LINEAR_VOLTS_250mV			10
	pbox->AddString(L"250mV");
	//#define LINEAR_VOLTS_100mV			11
	pbox->AddString(L"100mV");
	//#define LINEAR_VOLTS_50mV				12
	pbox->AddString(L"50mV");
	//#define LINEAR_VOLTS_25mV				13
	pbox->AddString(L"25mV");
	//#define LINEAR_VOLTS_10mV				14
	pbox->AddString(L"10mV");
	//#define LINEAR_VOLTS_5mV				15
	pbox->AddString(L"5mV");
}
void CIntegrationDlg2::InitCurrentRanges(int controlID) {
	CComboBox *pbox = (CComboBox*) GetDlgItem(controlID);
	pbox->ResetContent(); // empty it
	// Channel current ranges
	//#define		LINEAR_AMPS_20mA			0
	pbox->AddString(L"20mA");
}
void CIntegrationDlg2::InitAcqRates(int controlID) {
	CComboBox *pbox = (CComboBox*) GetDlgItem(controlID);
	pbox->ResetContent(); // empty it
	//#define AI_ACQ_RATE_2HZ				0		// 2Hz acqusition rate
	pbox->AddString(L"2Hz");
	//#define AI_ACQ_RATE_5HZ				1		// 5Hz acqusition rate
	pbox->AddString(L"5Hz");
	//#define AI_ACQ_RATE_10HZ				2		// 10Hz acqusition rate
	pbox->AddString(L"10Hz");
	//#define AI_ACQ_RATE_50HZ				3		// 50Hz acqusition rate
	pbox->AddString(L"50Hz");
}
void CIntegrationDlg2::TypeChange(int controlID) {
	CComboBox *pbox = (CComboBox*) GetDlgItem(controlID);
	int selected = pbox->GetCurSel();
	qDebug("Type selected %d\n", selected);
	class CIOSetupConfig *pIOSetupConfig = pGlbSetup->GetIOSetupConfig();
	int analogNumber = (controlID - (IDC_TYPE1)) + 1;
	if (selected == AI_CHANNEL_TYPE_LINEAR_VOLTS) // Volts = 0 
			{
		InitVoltRanges((IDC_RANGE1) + analogNumber - 1);
		SetCurSel((IDC_RANGE1) + analogNumber - 1, 0); // select top one
		pIOSetupConfig->SelectVoltageRange(analogNumber, 0);
	}
	if (selected == AI_CHANNEL_TYPE_LINEAR_AMPS) // current = 1
			{
		InitCurrentRanges((IDC_RANGE1) + analogNumber - 1);
		SetCurSel((IDC_RANGE1) + analogNumber - 1, 0); // select top one
		pIOSetupConfig->SelectCurrentRange(analogNumber, 0);
	}
}
void CIntegrationDlg2::RangeChange(int controlID) {
	CComboBox *pbox = (CComboBox*) GetDlgItem(controlID);
	int rangeSelected = pbox->GetCurSel();
	qDebug("Range selected %d\n", rangeSelected);
	class CIOSetupConfig *pIOSetupConfig = pGlbSetup->GetIOSetupConfig();
	int analogNumber = (controlID - (IDC_RANGE1)) + 1;
	// see what type we have selected to know which function to call in config
	pbox = (CComboBox*) GetDlgItem((IDC_TYPE1) + analogNumber - 1); // get type control for this analog
	int typeSelected = pbox->GetCurSel();
	if (typeSelected == AI_CHANNEL_TYPE_LINEAR_VOLTS) // Volts 0
			{
		pIOSetupConfig->SelectVoltageRange(analogNumber, rangeSelected);
	}
	if (typeSelected == AI_CHANNEL_TYPE_LINEAR_AMPS) // current 1
			{
		pIOSetupConfig->SelectCurrentRange(analogNumber, rangeSelected);
	}
}
void CIntegrationDlg2::RateChange(int controlID) {
	CComboBox *pbox = (CComboBox*) GetDlgItem(controlID);
	int selected = pbox->GetCurSel();
	class CIOSetupConfig *pIOSetupConfig = pGlbSetup->GetIOSetupConfig();
	qDebug("Rate selected %d\n", selected);
	int analogNumber = (controlID - (IDC_RATE1)) + 1;
	pIOSetupConfig->SelectAcqRate(analogNumber, selected);
}
void CIntegrationDlg2::RefreshAnalogs() {
	wchar_t buff[100];
	for (int i = 8; i < 16; i++) {
		CWidget *pValue = GetDlgItem((IDC_VALUE1) + i);
		int numUpdates = 0;
		//	USHORT val=Glb_datatable.GetAnalog(i+1,numUpdates);
		CDataItem *pDataItem = pOpPanel->m_pDIT->GetDataItemPtr(DI_IO, DI_IO_ANALOGUE, i);
		float val = pDataItem->GetFPValue();
		swprintf(buff, L"%f", val);
		pValue->setWindowTitle(buff);
	}
	sleep(50);
}
void CIntegrationDlg2::OnPage1() {
	if (Glb_pDialog1 == NULL) {
		Glb_pDialog1 = new CIntegrationDlg1(pOpPanel);
		if (Glb_pDialog1 != NULL) {
			BOOL ret = Glb_pDialog1->Create(L"ANALOGS1", NULL);
			Glb_pDialog1->ShowWindow(SW_SHOW);
		}
	} else
		Glb_pDialog1->SetForegroundWindow();
}
void CIntegrationDlg2::OnPage3() {
	if (Glb_pDialog3 == NULL) {
		Glb_pDialog3 = new CIntegrationDlg3(pOpPanel);
		if (Glb_pDialog3 != NULL) {
			BOOL ret = Glb_pDialog3->Create(L"DIGITALS", NULL);
			Glb_pDialog3->ShowWindow(SW_SHOW);
		}
	} else
		Glb_pDialog3->SetForegroundWindow();
}
void CIntegrationDlg2::OnSelchangeType9() {
	TypeChange (IDC_TYPE9);
}
void CIntegrationDlg2::OnSelchangeType10() {
	TypeChange (IDC_TYPE10);
}
void CIntegrationDlg2::OnSelchangeType11() {
	TypeChange (IDC_TYPE11);
}
void CIntegrationDlg2::OnSelchangeType12() {
	TypeChange (IDC_TYPE12);
}
void CIntegrationDlg2::OnSelchangeType13() {
	TypeChange (IDC_TYPE13);
}
void CIntegrationDlg2::OnSelchangeType14() {
	TypeChange (IDC_TYPE14);
}
void CIntegrationDlg2::OnSelchangeType15() {
	TypeChange (IDC_TYPE15);
}
void CIntegrationDlg2::OnSelchangeType16() {
	TypeChange (IDC_TYPE16);
}
void CIntegrationDlg2::OnSelchangeRange9() {
	RangeChange (IDC_RANGE9);
}
void CIntegrationDlg2::OnSelchangeRange10() {
	RangeChange (IDC_RANGE10);
}
void CIntegrationDlg2::OnSelchangeRange11() {
	RangeChange (IDC_RANGE11);
}
void CIntegrationDlg2::OnSelchangeRange12() {
	RangeChange (IDC_RANGE12);
}
void CIntegrationDlg2::OnSelchangeRange13() {
	RangeChange (IDC_RANGE13);
}
void CIntegrationDlg2::OnSelchangeRange14() {
	RangeChange (IDC_RANGE14);
}
void CIntegrationDlg2::OnSelchangeRange15() {
	RangeChange (IDC_RANGE15);
}
void CIntegrationDlg2::OnSelchangeRange16() {
	RangeChange (IDC_RANGE16);
}
void CIntegrationDlg2::OnSelchangeRate9() {
	RateChange (IDC_RATE9);
}
void CIntegrationDlg2::OnSelchangeRate10() {
	RateChange (IDC_RATE10);
}
void CIntegrationDlg2::OnSelchangeRate11() {
	RateChange (IDC_RATE11);
}
void CIntegrationDlg2::OnSelchangeRate12() {
	RateChange (IDC_RATE12);
}
void CIntegrationDlg2::OnSelchangeRate13() {
	RateChange (IDC_RATE13);
}
void CIntegrationDlg2::OnSelchangeRate14() {
	RateChange (IDC_RATE14);
}
void CIntegrationDlg2::OnSelchangeRate15() {
	RateChange (IDC_RATE15);
}
void CIntegrationDlg2::OnSelchangeRate16() {
	RateChange (IDC_RATE16);
}

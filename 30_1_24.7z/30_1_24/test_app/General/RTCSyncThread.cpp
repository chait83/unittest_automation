/// @file
/// ****************************************************************
/// Honeywell Trendview
/// ****************************************************************
/// @n Module:	 External RTC Time
/// @n Filename: RTCSyncThread.cpp
/// @n Desc:	 Read External RTC Time
///
///
//  ****************************************************************
//  Revision History
//
//	Sowmya Pothuri 12/Feb/2020 RTC time Management
//  ****************************************************************
#include "RTCSyncThread.h"
#include "V6globals.h"

CRTCSyncThread *CRTCSyncThread::m_pRTCManInstance = NULL;
QMutex CRTCSyncThread::m_CreationMutex;
#define ONE_HOUR_SLEEP				  3600000
#define FIFTEEN_SECS_SYNC_TIME		  15
#define THIRTY_SECS_SYNC_TIME		  30
#define FOURTY_FIVE_SECS_SYNC_TIME  45
HANDLE glbhSyncThread = INVALID_HANDLE_VALUE;
uint glbCorrectionTime = 30000; //By default correction time is 30 secs.
#ifdef DBG_FILE_LOG_RTCSYNC_THREAD_ENABLE
CDebugFileLogger CRTCSyncThread::m_debugFileLogger(L"\\SDMemory\\RTCSyncThread.txt", FALSE, (10 * 1024 * 1024));
QString strNotifyLog;
#endif
//**********************************************************************
/// CRTCSyncThread constructor
///
//**********************************************************************
CRTCSyncThread::CRTCSyncThread() : m_RCTimer(TIMER_NORMAL_RES)
//#ifdef DBG_FILE_LOG_RTCSYNC_THREAD_ENABLE
//, m_pDebugFileLogger(&m_debugFileLogger)
//#endif
{
}
CRTCSyncThread::~CRTCSyncThread() {
	CleanUp();
}
//**********************************************************************
///
/// Instance creation of CRTCSyncThread singleton
///
/// @return		pointer to single instance of CRTCSyncThread
///
//**********************************************************************
CRTCSyncThread* CRTCSyncThread::GetHandle() {
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;
	if ( NULL == m_pRTCManInstance) {
		// An instance has yet to be completed
		m_CreationMutex = CreateMutex( NULL,			// No security descriptor
				FALSE,			// Mutex object not owned
				TEXT("RTCSyncThread"));	// Object name
		waitSingleObjectResult = WaitForSingleObject(m_CreationMutex, 5000);
		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:
			// Object was signaled
			if ( NULL == m_pRTCManInstance) {
				m_pRTCManInstance = new CRTCSyncThread;
				//pGlbRTCManager = m_pRTCManInstance;		// Assign global
			}
			if ( FALSE == m_CreationMutex.unlock()) {
				V6WarningMessageBox( NULL, L"Failed to release RTCSyncThread mutex", L"RTC Sync Thread Error", MB_OK);
			}
			break;
		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
			V6WarningMessageBox( NULL, L"RTCSyncThread WaitForSingleObject Error", L"RTC Sync Thread Error", MB_OK);
			break;
		}
		// Close the Mutex as no longer required
		//No need to close the mutex in Qt;
	}
	return (m_pRTCManInstance);
}
//**********************************************************************
///
/// Deletes the instance of the singleton from memory
///
/// @return		Nothing
///
//**********************************************************************
void CRTCSyncThread::CleanUp() {
	delete m_pRTCManInstance;
	m_pRTCManInstance = NULL;
	if (INVALID_HANDLE_VALUE != glbhSyncThread) {
		DWORD dwExitCode;
		GetExitCodeThread(glbhSyncThread, &dwExitCode);
		TerminateThread(glbhSyncThread, dwExitCode);
		CloseHandle(glbhSyncThread);
		glbhSyncThread = INVALID_HANDLE_VALUE;
	}
}
int CRTCSyncThread::ReadRTCAndSyncTime() {
	int timeDiffVal = 0;
	//Add critical section for  bUserTriggeredTimeChange
	pGlbSysTimer->m_SyncRTCCS.lock();
	if (false == pGlbSysTimer->bUserTriggeredTimeChange) {
		pGlbSysTimer->m_SyncRTCCS.lock();
		timeDiffVal = pGlbSysTimer->RegisterATimeChange(true);
	} else {
		pGlbSysTimer->m_SyncRTCCS.lock();
	}
	return timeDiffVal;
}
DWORD SyncThread(LPVOID lpArg) {
	CRTCSyncThread *pRTCManager = CRTCSyncThread::GetHandle();
	while (1) {
		if (pRTCManager->ReadRTCAndSyncTime() != 0) {
			sleep(glbCorrectionTime);			//sleep for correctionTime secs before correcting time again.
		} else {
			sleep(ONE_HOUR_SLEEP);				//Check diff of int and ext RTC every hour.
		}
	}
}
void RTCSyncThreadBegin() {
	DWORD dwThreadID;
	if ((pGlbSysInfo->IsFunctionAvailable(FUNC_15SECS_CORRECTIONTIME, FALSE) == TRUE)) // if 15 secs selected.
	{
		glbCorrectionTime = ( FIFTEEN_SECS_SYNC_TIME * 1000);
	} else if ((pGlbSysInfo->IsFunctionAvailable(FUNC_45SECS_CORRECTIONTIME, FALSE) == TRUE)) // if 45 secs selected.
	{
		glbCorrectionTime = ( FOURTY_FIVE_SECS_SYNC_TIME * 1000);
	} else //30 secs default
	{
		glbCorrectionTime = (THIRTY_SECS_SYNC_TIME * 1000);
	}
	glbhSyncThread = CreateThread(NULL, 0, SyncThread, 0, 0, &dwThreadID);
	SetThreadPriority(glbhSyncThread, THREAD_PRIORITY_HIGHEST);
}
//**********************************************************************
///
///
/// @return		TRUE, if successful, FALSE if failed, Do not continue if failed
///
//**********************************************************************
void CRTCSyncThread::Initialise() {
	LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_INFORMATION, _T("RTCSyncThread Begin!!"));
	RTCSyncThreadBegin();
}
#ifdef DBG_FILE_LOG_RTCSYNC_THREAD_ENABLE
void CRTCSyncThread::SetDebugLogger(CDebugFileLogger *pDbgFileLogger) {
	m_pDebugFileLogger = pDbgFileLogger;
}
void CRTCSyncThread::LogDebugMessage(QString strDebugMsg) {
	if ( NULL != m_pDebugFileLogger) {
		m_pDebugFileLogger->WriteToDebugLogFile(strDebugMsg);
		//m_debugFileLogger.Flush();
	}
}
#endif

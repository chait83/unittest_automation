/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Integration
/// @n Filename: IntegrationDlg1.cpp 
/// @n Description: Dialog to show analogs 1-8
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  23  Stability Project 1.20.1.1 7/2/2011 4:57:59 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  22  Stability Project 1.20.1.0 7/1/2011 4:26:47 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  21  V6 Firmware 1.20 7/29/2005 2:32:38 PM  Graham Waterfield
//  Removed topslot channel map - needed to remove validate and adjust
//  board setup temporaraly due to channel map not fulfilling original
//  design.
//  Validate & adjust still requires implementation
//  20  V6 Firmware 1.19 6/29/2005 8:01:33 PM  Roger Dawson  
//  Modified to use the global recorder setup pointer rather than the op
//  panel recorder setup pointer
// $
//
// **************************************************************************
#include "oppanelincludes.h"
#include "IntegrationDlg1.h"
#include "SetupConfiguration.h"
#include "IOSetupConfig.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
//extern CDataItemTable Glb_datatable; // Global datatable (for now)
extern CIntegrationDlg1 *Glb_pDialog1;
extern CIntegrationDlg2 *Glb_pDialog2;
extern CIntegrationDlg3 *Glb_pDialog3;
/////////////////////////////////////////////////////////////////////////////
// CIntegrationDlg1 dialog
CIntegrationDlg1::CIntegrationDlg1(CWidget *pParent /*=NULL*/) : QDialog(CIntegrationDlg1::IDD, pParent) {
	//{{AFX_DATA_INIT(CIntegrationDlg1)
	// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	pOpPanel = (COpPanel*) pParent; // keep pointer to OpPanel
}
BEGIN_MESSAGE_MAP(CIntegrationDlg1, QDialog)
//{{AFX_MSG_MAP(CIntegrationDlg1)
ON_BN_CLICKED(IDC_PAGE2, OnPage2)
ON_BN_CLICKED(IDC_PAGE3, OnPage3)
ON_BN_CLICKED(IDOK, OnQuit)
ON_CBN_SELCHANGE(IDC_TYPE1, OnSelchangeType1)
ON_CBN_SELCHANGE(IDC_TYPE2, OnSelchangeType2)
ON_CBN_SELCHANGE(IDC_TYPE3, OnSelchangeType3)
ON_CBN_SELCHANGE(IDC_TYPE4, OnSelchangeType4)
ON_CBN_SELCHANGE(IDC_TYPE5, OnSelchangeType5)
ON_CBN_SELCHANGE(IDC_TYPE6, OnSelchangeType6)
ON_CBN_SELCHANGE(IDC_TYPE7, OnSelchangeType7)
ON_CBN_SELCHANGE(IDC_TYPE8, OnSelchangeType8)
ON_CBN_SELCHANGE(IDC_RANGE1, OnSelchangeRange1)
ON_CBN_SELCHANGE(IDC_RANGE2, OnSelchangeRange2)
ON_CBN_SELCHANGE(IDC_RANGE3, OnSelchangeRange3)
ON_CBN_SELCHANGE(IDC_RANGE4, OnSelchangeRange4)
ON_CBN_SELCHANGE(IDC_RANGE5, OnSelchangeRange5)
ON_CBN_SELCHANGE(IDC_RANGE6, OnSelchangeRange6)
ON_CBN_SELCHANGE(IDC_RANGE7, OnSelchangeRange7)
ON_CBN_SELCHANGE(IDC_RANGE8, OnSelchangeRange8)
ON_CBN_SELCHANGE(IDC_RATE1, OnSelchangeRate1)
ON_CBN_SELCHANGE(IDC_RATE2, OnSelchangeRate2)
ON_CBN_SELCHANGE(IDC_RATE3, OnSelchangeRate3)
ON_CBN_SELCHANGE(IDC_RATE4, OnSelchangeRate4)
ON_CBN_SELCHANGE(IDC_RATE5, OnSelchangeRate5)
ON_CBN_SELCHANGE(IDC_RATE6, OnSelchangeRate6)
ON_CBN_SELCHANGE(IDC_RATE7, OnSelchangeRate7)
ON_CBN_SELCHANGE(IDC_RATE8, OnSelchangeRate8)
ON_BN_CLICKED(IDC_APPLY, OnApply)
//}}AFX_MSG_MAP
END_MESSAGE_MAP()
/////////////////////////////////////////////////////////////////////////////
// CIntegrationDlg1 message handlers
void CIntegrationDlg1::OnQuit()
{
	DestroyWindow();
	delete this;
	Glb_pDialog1=NULL;
}
BOOL CIntegrationDlg1::OnInitDialog() {
	QDialog::OnInitDialog();
	CIOSetupConfig *pIOSetupConfig = pGlbSetup->GetIOSetupConfig();
	if (pOpPanel->m_ScreenWidth > 320) {
		// multiplus... position dialog across.
		QRect rect;
		GetWindowRect(&rect);
		OffsetRect(&rect, 20, 20);
		move(rect.left, rect.top, _Width(rect), _Height(rect), TRUE);
	}
	// set up the settings in the dialog from the current setup in use
	for (int i = 0; i < 8; i++) {
		// first set up the defaults for the input.
		// set up input type (volts/amps)
		InitInputType((IDC_TYPE1) + i);
		// then select top entry (volts)
		SetCurSel((IDC_TYPE1) + i, 0);
		// set up the ranges for volts
		InitVoltRanges((IDC_RANGE1) + i);
		// and then select the top one.
		SetCurSel((IDC_RANGE1) + i, 0);
		// set the rates
		InitAcqRates((IDC_RATE1) + i);
		// then select the top one
		SetCurSel((IDC_RATE1) + i, 0);
		// now look in the setup configuration and set them as they are.
		USHORT Selection;
		if (pIOSetupConfig->QueryAIChannelSelection(CONFIG_MODIFIABLE, i + 1, &Selection) == CONFIG_OK) {
			// select the input type (volts/amps)
			SetCurSel((IDC_TYPE1) + i, Selection);
			if (Selection == AI_CHANNEL_TYPE_LINEAR_VOLTS) {
				// set up the ranges for volts
				InitVoltRanges((IDC_RANGE1) + i);
				USHORT Range;
				if (pIOSetupConfig->QueryVoltageRange(CONFIG_MODIFIABLE, i + 1, &Range) == CONFIG_OK) {
					// use it
					SetCurSel((IDC_RANGE1) + i, Range);
				}
			} else if (Selection == AI_CHANNEL_TYPE_LINEAR_AMPS) {
				// set up the ranges for current
				InitCurrentRanges((IDC_RANGE1) + i);
				USHORT Range;
				if (pIOSetupConfig->QueryCurrentRange(CONFIG_MODIFIABLE, i + 1, &Range) == CONFIG_OK) {
					// use it
					SetCurSel((IDC_RANGE1) + i, Range);
				}
			}
			USHORT Rate;
			if (pIOSetupConfig->QueryAIAcqRate(CONFIG_MODIFIABLE, i + 1, &Rate) == CONFIG_OK) {
				// use it
				SetCurSel((IDC_RATE1) + i, Rate);
			}
		}
	}
	return TRUE; // return TRUE unless you set the focus to a control
				 // EXCEPTION: OCX Property Pages should return FALSE
}
void CIntegrationDlg1::SetCurSel(int controlID, int selection) {
	CComboBox *pbox = (CComboBox*) GetDlgItem(controlID);
	pbox->SetCurSel(selection); // select the top item.
}
void CIntegrationDlg1::OnApply() {
	ConfigChange(); // apply changes 
}
void CIntegrationDlg1::ConfigChange() {
	T_MOD_CFG_CHG_MSGDATA msg;
	msg.TypeOfConfigChange = MOD_CFG_CHG_SETUP;
	msg.configChangeSystemAction = MOD_SYS_CFG_CHG_NORMAL_OPERATION;
	msg.ConfigChangeAction = MOD_CFG_CHG_ACTION_UPDATE;
	memset(msg.fileNameAndPath, 0, sizeof(msg.fileNameAndPath));
	// tell control sequencer about the update
	pOpPanel->m_pV6Module->SignalConfigChange(sizeof(T_MOD_CFG_CHG_MSGDATA), (UCHAR*) &msg);
}
void CIntegrationDlg1::InitInputType(int controlID) {
	CComboBox *pbox = (CComboBox*) GetDlgItem(controlID);
	pbox->ResetContent(); // empty it
	// Channel input specifiers
	//#define AI_CHANNEL_TYPE_LINEAR_VOLTS		0		// Input type of voltage
	pbox->AddString(L"V");
	//#define AI_CHANNEL_TYPE_LINEAR_AMPS		1		// Current
	pbox->AddString(L"A");
}
void CIntegrationDlg1::InitVoltRanges(int controlID) {
	CComboBox *pbox = (CComboBox*) GetDlgItem(controlID);
	pbox->ResetContent(); // empty it
	// Channel voltage ranges
	//#define LINEAR_VOLTS_50V				0
	pbox->AddString(L"50V");
	//#define LINEAR_VOLTS_25V				1
	pbox->AddString(L"25V");
	//#define LINEAR_VOLTS_12V				2
	pbox->AddString(L"12V");
	//#define LINEAR_VOLTS_6V				3
	pbox->AddString(L"6V");
	//#define LINEAR_VOLTS_3V				4
	pbox->AddString(L"3V");
	//#define LINEAR_VOLTS_1_5V				5
	pbox->AddString(L"1.5V");
	//#define LINEAR_VOLTS_0_6V				6
	pbox->AddString(L"0.6V");
	//#define LINEAR_VOLTS_0_3V				7
	pbox->AddString(L"0.3V");
	//#define LINEAR_VOLTS_1000mV			8
	pbox->AddString(L"1000mV");
	//#define LINEAR_VOLTS_500mV			9
	pbox->AddString(L"500mV");
	//#define LINEAR_VOLTS_250mV			10
	pbox->AddString(L"250mV");
	//#define LINEAR_VOLTS_100mV			11
	pbox->AddString(L"100mV");
	//#define LINEAR_VOLTS_50mV				12
	pbox->AddString(L"50mV");
	//#define LINEAR_VOLTS_25mV				13
	pbox->AddString(L"25mV");
	//#define LINEAR_VOLTS_10mV				14
	pbox->AddString(L"10mV");
	//#define LINEAR_VOLTS_5mV				15
	pbox->AddString(L"5mV");
}
void CIntegrationDlg1::InitCurrentRanges(int controlID) {
	CComboBox *pbox = (CComboBox*) GetDlgItem(controlID);
	pbox->ResetContent(); // empty it
	// Channel current ranges
	//#define		LINEAR_AMPS_20mA			0
	pbox->AddString(L"20mA");
}
void CIntegrationDlg1::InitAcqRates(int controlID) {
	CComboBox *pbox = (CComboBox*) GetDlgItem(controlID);
	pbox->ResetContent(); // empty it
	//#define AI_ACQ_RATE_2HZ				0		// 2Hz acqusition rate
	pbox->AddString(L"2Hz");
	//#define AI_ACQ_RATE_5HZ				1		// 5Hz acqusition rate
	pbox->AddString(L"5Hz");
	//#define AI_ACQ_RATE_10HZ				2		// 10Hz acqusition rate
	pbox->AddString(L"10Hz");
	//#define AI_ACQ_RATE_50HZ				3		// 50Hz acqusition rate
	pbox->AddString(L"50Hz");
}
void CIntegrationDlg1::TypeChange(int controlID) {
	CComboBox *pbox = (CComboBox*) GetDlgItem(controlID);
	class CIOSetupConfig *pIOSetupConfig = pGlbSetup->GetIOSetupConfig();
	int selected = pbox->GetCurSel();
	qDebug("Type selected %d\n", selected);
	int analogNumber = (controlID - (IDC_TYPE1)) + 1;
	if (selected == AI_CHANNEL_TYPE_LINEAR_VOLTS) // Volts = 0 
			{
		InitVoltRanges((IDC_RANGE1) + analogNumber - 1);
		SetCurSel((IDC_RANGE1) + analogNumber - 1, 0); // select top one
		pIOSetupConfig->SelectVoltageRange(analogNumber, 0);
	}
	if (selected == AI_CHANNEL_TYPE_LINEAR_AMPS) // current = 1
			{
		InitCurrentRanges((IDC_RANGE1) + analogNumber - 1);
		SetCurSel((IDC_RANGE1) + analogNumber - 1, 0); // select top one
		pIOSetupConfig->SelectCurrentRange(analogNumber, 0);
	}
}
void CIntegrationDlg1::RangeChange(int controlID) {
	CComboBox *pbox = (CComboBox*) GetDlgItem(controlID);
	int rangeSelected = pbox->GetCurSel();
	class CIOSetupConfig *pIOSetupConfig = pGlbSetup->GetIOSetupConfig();
	qDebug("Range selected %d\n", rangeSelected);
	int analogNumber = (controlID - (IDC_RANGE1)) + 1;
	// see what type we have selected to know which function to call in config
	pbox = (CComboBox*) GetDlgItem((IDC_TYPE1) + analogNumber - 1); // get type control for this analog
	int typeSelected = pbox->GetCurSel();
	if (typeSelected == AI_CHANNEL_TYPE_LINEAR_VOLTS) // Volts 0
			{
		pIOSetupConfig->SelectVoltageRange(analogNumber, rangeSelected);
	}
	if (typeSelected == AI_CHANNEL_TYPE_LINEAR_AMPS) // current 1
			{
		pIOSetupConfig->SelectCurrentRange(analogNumber, rangeSelected);
	}
}
void CIntegrationDlg1::RateChange(int controlID) {
	CComboBox *pbox = (CComboBox*) GetDlgItem(controlID);
	int selected = pbox->GetCurSel();
	qDebug("Rate selected %d\n", selected);
	class CIOSetupConfig *pIOSetupConfig = pGlbSetup->GetIOSetupConfig();
	int analogNumber = (controlID - (IDC_RATE1)) + 1;
	pIOSetupConfig->SelectAcqRate(analogNumber, selected);
}
void CIntegrationDlg1::RefreshAnalogs() {
	wchar_t buff[100];
	for (int i = 0; i < 8; i++) {
		CWidget *pValue = GetDlgItem((IDC_VALUE1) + i);
		//	USHORT val=Glb_datatable.GetAnalog(i+1,numUpdates);
		CDataItem *pDataItem = pOpPanel->m_pDIT->GetDataItemPtr(DI_IO, DI_IO_ANALOGUE, i);
//		CDataItem *pDataItem = pOpPanel->m_pDIT->GetDataItemPtr(DI_PEN,i+1,1);
		float val = pDataItem->GetFPValue();
		swprintf(buff, L"%f", val);
		pValue->setWindowTitle(buff);
	}
	sleep(50);
}
void CIntegrationDlg1::OnPage2() {
	if (Glb_pDialog2 == NULL) {
		Glb_pDialog2 = new CIntegrationDlg2(pOpPanel);
		if (Glb_pDialog2 != NULL) {
			BOOL ret = Glb_pDialog2->Create(L"ANALOGS2", NULL);
			Glb_pDialog2->ShowWindow(SW_SHOW);
		}
	} else
		Glb_pDialog2->SetForegroundWindow();
}
void CIntegrationDlg1::OnPage3() {
	if (Glb_pDialog3 == NULL) {
		Glb_pDialog3 = new CIntegrationDlg3(pOpPanel);
		if (Glb_pDialog3 != NULL) {
			BOOL ret = Glb_pDialog3->Create(L"DIGITALS", NULL);
			Glb_pDialog3->ShowWindow(SW_SHOW);
		}
	} else
		Glb_pDialog3->SetForegroundWindow();
}
void CIntegrationDlg1::OnSelchangeType1() {
	TypeChange (IDC_TYPE1);
}
void CIntegrationDlg1::OnSelchangeType2() {
	TypeChange (IDC_TYPE2);
}
void CIntegrationDlg1::OnSelchangeType3() {
	TypeChange (IDC_TYPE3);
}
void CIntegrationDlg1::OnSelchangeType4() {
	TypeChange (IDC_TYPE4);
}
void CIntegrationDlg1::OnSelchangeType5() {
	TypeChange (IDC_TYPE5);
}
void CIntegrationDlg1::OnSelchangeType6() {
	TypeChange (IDC_TYPE6);
}
void CIntegrationDlg1::OnSelchangeType7() {
	TypeChange (IDC_TYPE7);
}
void CIntegrationDlg1::OnSelchangeType8() {
	TypeChange (IDC_TYPE8);
}
void CIntegrationDlg1::OnSelchangeRange1() {
	RangeChange (IDC_RANGE1);
}
void CIntegrationDlg1::OnSelchangeRange2() {
	RangeChange (IDC_RANGE2);
}
void CIntegrationDlg1::OnSelchangeRange3() {
	RangeChange (IDC_RANGE3);
}
void CIntegrationDlg1::OnSelchangeRange4() {
	RangeChange (IDC_RANGE4);
}
void CIntegrationDlg1::OnSelchangeRange5() {
	RangeChange (IDC_RANGE5);
}
void CIntegrationDlg1::OnSelchangeRange6() {
	RangeChange (IDC_RANGE6);
}
void CIntegrationDlg1::OnSelchangeRange7() {
	RangeChange (IDC_RANGE7);
}
void CIntegrationDlg1::OnSelchangeRange8() {
	RangeChange (IDC_RANGE8);
}
void CIntegrationDlg1::OnSelchangeRate1() {
	RateChange (IDC_RATE1);
}
void CIntegrationDlg1::OnSelchangeRate2() {
	RateChange (IDC_RATE2);
}
void CIntegrationDlg1::OnSelchangeRate3() {
	RateChange (IDC_RATE3);
}
void CIntegrationDlg1::OnSelchangeRate4() {
	RateChange (IDC_RATE4);
}
void CIntegrationDlg1::OnSelchangeRate5() {
	RateChange (IDC_RATE5);
}
void CIntegrationDlg1::OnSelchangeRate6() {
	RateChange (IDC_RATE6);
}
void CIntegrationDlg1::OnSelchangeRate7() {
	RateChange (IDC_RATE7);
}
void CIntegrationDlg1::OnSelchangeRate8() {
	RateChange (IDC_RATE8);
}

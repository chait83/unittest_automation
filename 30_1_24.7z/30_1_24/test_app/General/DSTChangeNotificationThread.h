/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Time Tasks
/// @n Filename:  DSTChangeNotificationThread.h
/// @n Description: Definition of the CDSTChangeNotificationThread class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  3 Stability Project 1.0.1.1 7/2/2011 4:56:58 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  2 Stability Project 1.0.1.0 7/1/2011 4:27:44 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  1 V6 Firmware 1.0 4/7/2006 3:51:04 PM Roger Dawson  
// $
//
// **************************************************************************
#if !defined(AFX_DSTCHANGENOTIFICATIONTHREAD_H__C9AEF5DE_F28C_43F8_80B9_B20F1CEFFEA7__INCLUDED_)
#define AFX_DSTCHANGENOTIFICATIONTHREAD_H__C9AEF5DE_F28C_43F8_80B9_B20F1CEFFEA7__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include <QMutex>
#include <QThread>
#include "Defines.h"
#define DSTEVENT QString ("ShellDSTEvent")
#define DSTNOTIFICATION  QString ("\\\\.\\Notifications\\NamedEvents\\ShellDSTEvent")
//**CDSTChangeNotificationThread***********************************************************
///
/// @brief	Thread class used to synchronise the current local time with the
///			time history file and synchronise the RTC following DST changes
/// 
/// Thread class used to synchronise the current local time with the
///	time history file and synchronise the RTC following DST changes
///
//****************************************************************************
typedef enum {
	TIME_ZONE_ID_UNKNOWN = 0, TIME_ZONE_ID_STANDARD, TIME_ZONE_ID_DAYLIGHT
} DST_TYPES;
class CDSTChangeNotificationThread: public QThread {
public:
        /// Enum indicating the various thread states
        enum T_DST_THREAD_STATE {
                dstINIT, dstRUNNING, dstSHUTDOWN,
        };

public:
	/// @author : Chaitannya Mahatme: Changed the constructor from protected to public.
	/// TODO Check the impact of change
	CDSTChangeNotificationThread();
	virtual ~CDSTChangeNotificationThread();
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL
	static UINT DSTChangeNotificationFunc(LPVOID lpParam);
	// Method that signals to the thread a change of state is required
	static void ReInitialiseEvent();
	// Method that signals to the thread we are shutting down
	static void ShutdownThread();
private:
	DWORD GetTimeZoneInformation(TIME_ZONE_INFORMATION *tTZInfo);
	/// Variable used to indicate the required operational state of the daylight saving thread
	static T_DST_THREAD_STATE ms_eState;
	/// The handle to the DST trigger event
    static QMutex ms_hEvent;
	// Determines the day of week based on information in a QDateTime struct
	static int DowFromDate(SYSTEMTIME *pst);
	// indexOf the day of the week the indicated month begins on
	static int GetStartDowForMonth(int yr, int mo);
	// Method that determines the data at which the next daylight saving change is to occur - this 
	// may be going into or coming out of daylight saving
	static const bool DST_DetermineChangeDate(LPSYSTEMTIME pChangeOverTime, const bool bThisYear = false);
	// Method that determines if the current configuration and locale supports DST
	static const bool DaylightSavingRequired(const TIME_ZONE_INFORMATION &rtTZ_INFO);
public:
	// Method that setups the next daylight saving event
	static const bool SetupNextDSTEvent(const bool bFIRST_TIME = false);
};
/////////////////////////////////////////////////////////////////////////////
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.
#endif // !defined(AFX_DSTCHANGENOTIFICATIONTHREAD_H__C9AEF5DE_F28C_43F8_80B9_B20F1CEFFEA7__INCLUDED_)

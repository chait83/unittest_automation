/// @file
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 General
/// @n Filename: SysInfo.h
/// @n Desc:	 Consilidate all system information for V6 device
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  122  Stability Project 1.117.1.3  7/2/2011 5:01:58 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  121  Stability Project 1.117.1.2  7/1/2011 4:39:00 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  120  Stability Project 1.117.1.1  3/17/2011 3:20:49 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  119  Stability Project 1.117.1.0  2/15/2011 3:04:00 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// ****************************************************************
#include "SysInfo.h"
#include "V6globals.h"
#include "BoardManager.h"
#include <math.h>
#include "V6UIResource.h"
#include "V6ResourceBase.h"
#include "StringUtils.h"
#include "PWBackCoder.h"
#include "MediaUtils.h"
#include "BootData.h"
#include "BrdInfo.h"
#include <QFileInfo>
#include "EUDCDefs.h"
#include "V6MessageBoxDlg.h"
#include <wchar.h>
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
CSysInfo *CSysInfo::m_pV6SystemInfoInstance = NULL;
QMutex CSysInfo::m_CreationMutex;
QMutex CSysInfo::m_SysInfoCS;
#define OUTPUT_FILE ("/SDMemory/IOCardUpgrade.txt")
const USHORT CSysInfo::ms_usNO_PENS_PER_CREDIT = 2;
//**********************************************************************
/// CSysInfo constructor
///
//**********************************************************************
CSysInfo::CSysInfo() : m_PasswordsEnabled( FALSE), m_strErrList(""), m_eRecSecZone(REC_SEC_ZONE_SAFE), m_IsUserRemoteControl(
		FALSE), m_PreviouslyRemoteUserInCntrl(FALSE) {
    m_Initialised = FALSE;
	pOemInfo = NULL;
	// Reset Pen available details
	for (int penCount = 0; penCount < V6_MAX_PENS; penCount++)
		m_penAvailable[penCount] = FALSE;
	m_numAvailablePens = 0;
	//initialise Startup screen vars
	m_CurrStartupSection = SS_INITIAL_BOOT;
#if _MSC_VER < 1400 
    wcscpy(m_wcsAction, L"Initialising Hardware");
    wcscpy(m_wcsSubAction, L"");
#else
    wcscpy_s(m_wcsAction, sizeof(m_wcsAction)/sizeof(WCHAR), L"Initialising Hardware");
    wcscpy_s (m_wcsSubAction, sizeof(m_wcsSubAction)/sizeof(WCHAR), L"");
#endif
	// initialise the weightings of the firmware options
	InitFWOptWeights();
	m_pProfileCfg = NULL;
	m_pGeneralCfg = NULL;
	m_bLangValid = FALSE;
	m_FactoryReset = FALSE;
	m_eDataReset = DATA_RESET_NOT_SET;
	m_eAMS2750Mode = AMS2750_NONE;
}
//**********************************************************************
///
/// Instance creation of CSysInfo singleton
///
/// @return		pointer to single instance of CSysInfo
/// 
//**********************************************************************
CSysInfo* CSysInfo::GetHandle() {
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;
	if (NULL == m_pV6SystemInfoInstance) {
		// An instance has yet to be completed
		waitSingleObjectResult = m_CreationMutex.tryLock(g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);
		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:
			// Object was signaled
			if (NULL == m_pV6SystemInfoInstance) {
				m_pV6SystemInfoInstance = new CSysInfo;
			}
			m_CreationMutex.unlock();
			break;
		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
            CV6MessageBoxDlg("SYSINFO WaitForSingleObject Error", "Error");
			break;
		}
		// Close the Mutex as no longer required
		//No need to close the mutex in Qt
	}
	return (m_pV6SystemInfoInstance);
}
//**********************************************************************
///
/// Deletes the instance of the singleton from memory
///
/// @return		Nothing
/// 
//**********************************************************************
void CSysInfo::CleanUp() {
	if (m_pV6SystemInfoInstance != NULL) {
		if (m_Initialised == TRUE)
			//deletion of mutex not required
			delete m_pV6SystemInfoInstance;
		m_pV6SystemInfoInstance = NULL;
	}
}
//**********************************************************************
///
/// Initialise System info
///
/// @return		TRUE if successful otherwise FALSE
/// 
//**********************************************************************
BOOL CSysInfo::Initialise() {
	BOOL retVal = TRUE;
	if (m_Initialised == TRUE)
		return TRUE;
	m_FirmwareUpgraded = FALSE;
	QMutex * m_SysInfoCS;
	m_pFlash = CFlashManager::GetHandle();	// Get handle on flash
	m_GenNonVolChanged = FALSE;		// Non volatile has not changed, don't save
	if (NVLoadfromFlash() != FLASH_STATUS_OKAY) {
		memset(&m_GeneralNVCfg, 0, sizeof(T_GENNONVOL));
		SetSerialNumber(DEFAULT_SERIAL_NUMBER);
		// If it is a device then default first slot to demo boards allowed
		//This will help if the customer ordered recorder with no IO cards and
		//using it for Modbus communication. The demo traces will enable pens 
		//which in turn help for Modbus communication. Enable for only first slot
		//as it is for Analog card
		m_GeneralNVCfg.IsDemoBoard[0] = dboSIMULATE_IF_NO_BOARD_FITTED;
#ifndef UNDER_CE
		// setup a couple of demo channels on PC builds only
		m_GeneralNVCfg.IsDemoBoard[0] = dboSIMULATE_IF_NO_BOARD_FITTED;
		m_GeneralNVCfg.IsDemoBoard[1] = dboSIMULATE_IF_NO_BOARD_FITTED;
#endif
		// set the time zone to EST and daylight saving localisation if both these fields are zero which would 
		// imply this is a brand new recorder
		if (!m_GeneralNVCfg.Localisation.DayLightSaving && (m_GeneralNVCfg.Localisation.TimeZone == 0)) {
			m_GeneralNVCfg.Localisation.DayLightSaving = TRUE;
			m_GeneralNVCfg.Localisation.TimeZone = 14;
			// defualt the language too is this is not a debug build
#ifndef _DEBUG
			m_GeneralNVCfg.Language = lngEngUS;
#endif
		}
	} else {
		// If it is a device then default first slot to demo boards allowed
		//This will help if the customer ordered recorder with no IO cards and
		//using it for Modbus communication. The demo traces will enable pens 
		//which in turn help for Modbus communication. Enable for only first slot
		//as it is for Analog card
		m_GeneralNVCfg.IsDemoBoard[0] = dboSIMULATE_IF_NO_BOARD_FITTED;
	}
	m_GeneralNVCfg.FWOptions.SecureWSD = TRUE; ////R200 - WSD True by default e836320_tvgr200_spr_1_wsd - Make the WSD enable by default
#ifdef XSERIESSETUP	
	SetSerialNumber(DEFAULT_SERIAL_NUMBER);
#endif
	ReGenerateOptionsCode();			// Always regenerate optioins code, even though stored in flash
										// this will essentially be read only
#ifdef DOCVIEW
	// we don't allow the AMS2750 TUS screen in screen deisgner as it is fixed and recorder specific
	m_GeneralNVCfg.FWOptions.AMS2750TUS = FALSE;
#endif
	// set the AMS2750 mode based on the firmware options
	if (FWOptionAMS2750ProcessAvailable()) {
		m_eAMS2750Mode = AMS2750_PROCESS;
	} else if (FWOptionTUSModeAvailable()) {
		m_eAMS2750Mode = AMS2750_TUS;
	} else {
		m_eAMS2750Mode = AMS2750_NONE;
	}
	// initialise the OEM pack - always do this after the NV has been loaded as this class requires the 
	// current language from the NV
	pOemInfo = COEMInfo::Instance();
	USHORT theSession = 0;
	// Load NV Session Number
	m_pNVSessionNumber = pNV_VARS->GetBasicVarNVObject(NVV_SESSION);
	theSession = m_pNVSessionNumber->GetFromNV()->value.us[SESSION_ELEMENT];	// Get the USHORT session number from NV
	if (theSession == 0) {
		if ( TRUE == GetIdentity()) {
			theSession = m_IndentityInfo.usSessionNumber;
            LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_WARNING, "Session Number read from ID File");
		} else {
			// Session number has been reset, we need to set it to 1 and issue system warning that the session number was reset
			theSession = SESSION_RESET_NUMBER;
            LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_WARNING, "Session Number Reset");
		}
	}
	// Get a handle to on the T_GENERAL_STATIC sram area
	// this will be used to store state over power cycles for non essentials
	// essentials need to use update safe NVVariables.
	CSRAMManager *pSRAM = CSRAMManager::GetHandle();
	CSRAMRegion *pRegion = NULL;
	// Request a ptr to the CSRAMRegion instance for the corrisponding regionIdent
	CSRAMManager::regionError requestReturn = pSRAM->RequestRegion(REGION_GENERAL, &pRegion);
	m_staticInfo = static_cast<T_GENERAL_STATIC*>(pRegion->GetAddress());
	// Check if this is the first time the region has been used after power on
	if (pRegion->GetAutoState() == SRAM_STATE_FIRSTUSE) {
		pRegion->SetAutoStateToNormal();
	}
	BOOL performDataResetOnUpgrade = FALSE;
	//***************************************************************************
	//check for IOFirmware upgrade
	CStorage kFile;
	QFileDevice::FileError kEx;
	TCHAR m_Buffer[100];
	USHORT strLen = 0;
	memset(m_Buffer, NULL, sizeof(m_Buffer));
	if (kFile.Open(OUTPUT_FILE, CStorage::ReadOnly, &kEx)) {
		kFile.seek(0);
		strLen = kFile.size();
		kFile.Read(m_Buffer, strLen);
		kFile.Close();
		bool bFileDeleted = kFile.QFile::remove(OUTPUT_FILE);
		LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_INFORMATION, m_Buffer);
	}
	//***************************************************************************
	WCHAR wstr[100];
	memset(wstr, NULL, sizeof(wstr));
	// Check for firmware update
    if (GetCurrentFWVersion() == GetPreviousFWVersion()) {
		// Firmware has changed, post message to screen
		// Perform a data reset for TUS release, if upgrading from anything earlier then "GC"
        //if( wcscmp( GetPreviousFWVersion(), L"GC" ) < 0 )
		QString strPrevFirmware("");
        QString tempPrevFirmware;
        tempPrevFirmware = GetPreviousFWVersion();
		if (tempPrevFirmware[0] >= L'1' && tempPrevFirmware[0] <= L'9') {
            strPrevFirmware = tempPrevFirmware;
			int tempPos = strPrevFirmware.ReverseindexOf('.');
			strPrevFirmware = strPrevFirmware.mid(0, tempPos);
		} else {
            strPrevFirmware = GetPreviousFWVersion();
		}
		strPrevFirmware.toWCharArray(wstr);
//        int i = wcscmp(wstr,"");
		//PSR fix for PAR #1-3JLZOKS - Firmware Upgrade from 101.1.8.R to 991.1.11.Beta , crashes the begin
		//Current FW version needs data reset .. so Do automatic datareset if the previous version is already released to customer
		//SCR does not require any data reset as it would be a fresh installation
		//ToDo: Have version comparator so that all GR maintenance FWs with lesser than the SCR (Circular chart) will be
		//supported for FW U which needs automatic data reset due to changes in file and block allocation algorithm
        if ((wcscmp(wstr, L"100.1.41") == 0) || (wcscmp(wstr, L"100.2.10") == 0) || (wcscmp(wstr, L"101.1.08") == 0)
                || (wcscmp(wstr, L"101.2.03") == 0)) //FW U support for 3R maintenance release
				{
			performDataResetOnUpgrade = TRUE;
		}
		//PSR fix for PAR #1-3JLZOKS - Firmware Upgrade from 101.1.8.R to 991.1.11.Beta , crashes the end
		QString upgradeTextasprintf;
		upgradeTextasprintf = QWidget::tr("Firmware upgrade to %s");
		QString upgradeText;
        upgradeText = upgradeTextasprintf + " "+ GetCurrentFWVersion();
		LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_INFORMATION, upgradeText);
        AddStartupErr(upgradeText.toLocal8Bit().data());
		SetPreviousFWVersion(GetCurrentFWVersion());
		m_FirmwareUpgraded = TRUE;
	}
	// update the volume using the value in NV as long as it is not 0 which would
	// imply it is uninitialised
	CNVBasicVar *pNVparam = pNV_VARS->GetBasicVarNVObject(static_cast<NVVAR_IDENT>(NVV_VOLUME_LEVEL));
	if (pNVparam->GetFromNV()->value.ul > 0) {
		// must be a valid volume therefore update it - only do it to CE builds though
#ifdef UNDER_CE
		waveOutSetVolume( 0, pNVparam->GetFromNV()->value.ul );
#endif
	} else {
		// not a valid volume so set the NV value to the current volume level
		COMBO_VAR4 tNewValue;
		waveOutGetVolume(0, reinterpret_cast<DWORD*>(&tNewValue.ul));
		// mask out the top 2 bytes which can be set sometimes
		tNewValue.ul &= 0xFFFF;
		pNVparam->SetToNV(tNewValue);
	}
	m_staticInfo->ConfigVersion = CF_VERSION;
	// Setup the session number
	SetSessionNumber(theSession);
	// Setup the identity 
	m_IndentityInfo.ulSerialNumber = m_GeneralNVCfg.SerialNumber;
	m_IndentityInfo.usSessionNumber = theSession;
	SetIdentity();
	// Increment power cycles
	m_pNVPowerCycles = pNV_VARS->GetBasicVarNVObject(NVV_TOTAL_POWER_CYCLES);
	m_PowerCycles = m_pNVPowerCycles->GetFromNV()->value;
	m_PowerCycles.ul++;
	m_pNVPowerCycles->SetToNV(m_PowerCycles);
	// Setup the recorder max an Min temp every recorded
	m_pNVCJCMin = pNV_VARS->GetBasicVarNVObject(NVV_CJC_TEMP_MIN);
	m_CJCMin = m_pNVCJCMin->GetFromNV()->value;
	m_pNVCJCMax = pNV_VARS->GetBasicVarNVObject(NVV_CJC_TEMP_MAX);
	m_CJCMax = m_pNVCJCMax->GetFromNV()->value;
	// Setup the TC Cal adjust Exclusion flag
	m_pNVTCCalAdjustExclude = pNV_VARS->GetBasicVarNVObject(NVV_TCCALEXCLUDE);
	m_TCCalAdjustExclude = m_pNVTCCalAdjustExclude->GetFromNV()->value;
	// Test if manufacturing mode key is found
	if (IsFunctionAvailable(FUNC_ENTER_MFR_MODE, FALSE) == TRUE) {
		// Set product into manufacturing mode
		SetManufacturingMode();
        LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_WARNING, "Manufacturing mode ON");
	}
	// check for a customer mode key
	if (pSYSTEM_INFO->IsInHotSoakTestMode() == FALSE) // but only if not in Hot Soak Test mode
	{
		if (IsFunctionAvailable(FUNC_EXIT_MFR_MODE, FALSE) == TRUE) {
			// remove product from manufacturing mode 
			ClearManufacturingMode();
            LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_WARNING, "Manufacturing mode Off");
			// Here used to do a full reset (including data) - BUT if a customer's unit is
			// being repaired, and manufacturing mode is entered (to bypass passwords etc)
			// when it is to be returned to the customer, we don't want to wipe all his data and setup!
			//SetFactoryResetRequired();  // do full reset after manufacturing mode ?
			//SetDataResetRequired();
		}
	}
	// check for HotSoakTest key - an addition to manufacturing mode
	if (IsFunctionAvailable(FUNC_ENTER_HOTSOAKTEST_MODE, FALSE) == TRUE) {
		// Set product into Hot soak test mode with manufacturing mode
		SetManufacturingMode();
		SetHotSoakTestMode();
        LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_WARNING, "Hot Soak Test mode ON");
	}
	// Exit Hot Soak Test mode
	if (IsFunctionAvailable(FUNC_EXIT_HOTSOAKTEST_MODE, TRUE) == TRUE) // remove the key 
	{
		// remove product from manufacturing mode and Hot soak test mode
		ClearManufacturingMode();
		ClearHotSoakTestMode();
        LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_WARNING, "Hot Soak Test mode Off");
		SetFactoryResetRequired();  // do full reset this after hot soak test mode
		SetDataResetRequired(DATA_RESET_USER_SET);
		// format front SD if fitted
		pDALGLB->QuickasprintfFrontSD();
	}
	// if we are in Hot Soak Test mode, delete the configs
	if (pSYSTEM_INFO->IsInHotSoakTestMode()) {
		SetFactoryResetRequired();
		// delete LCF files for internal SD - 
		// with many config changes during manufacturing mode, the LCF files can become large
        MediaUtils::DeleteFile(IDS_INTERNAL_SD, IDS_CONFIG_DATA, "LCF.Conf");
        MediaUtils::DeleteFile(IDS_INTERNAL_SD, IDS_CONFIG_DATA, "LCF.Conf.index");
	}
	// If a factory reset key is on the front SD, set into factory reset mode, includes a data reset
	if ((IsFunctionAvailable(FUNC_FACTORY_RESET, TRUE) == TRUE)
			|| (IsFunctionAvailable(FUNC_PRODUCTION_RESET, FALSE) == TRUE)) {
		SetFactoryResetRequired();
		SetDataResetRequired(DATA_RESET_USER_SET);
		// Add reset notification to Start-up box and system messages
		QString strFactoryReset;
		strFactoryReset = QWidget::tr("Factory reset has been performed.");
        AddStartupErr(strFactoryReset.toLocal8Bit().data());
		LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, strFactoryReset);
	}
	// If a data reset key is on the front SD, or an upgrade has been performed, or start mode required reset, set into data reset mode
	if ((IsFunctionAvailable(FUNC_DATA_RESET, TRUE) == TRUE) || (performDataResetOnUpgrade == TRUE) || /*//PSR fix for PAR #1-3JLZOKS - Firmware Upgrade from 101.1.8.R to 991.1.11.Beta , crashes the app*/
	(GetStartMode() == START_MODE_DATA_RESET)) {
		SetDataResetRequired(DATA_RESET_USER_SET);
		// Add reset notification to Start-up box and system messages
		QString strDataReset;
		strDataReset = QWidget::tr("Data reset has been performed.");
		AddStartupErr(strDataReset.toLocal8Bit().data());
		LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, strDataReset);
	}
	// If a data reset is required then reset the time history file
	if (IsDataResetRequested() == TRUE) {
		// reset the time history file
		CTimeHistory *pTh = CTimeHistory::GetHandle();
		pTh->ResetHistory();
		pSYSTIMER->AddTimeHistoryStartEntry(pTh);
	}
	// Has the NV been reset or never used?
	if ((m_CJCMin.flt == 0 && m_CJCMax.flt == 0) || IsFactoryResetRequested() == TRUE) {
		// Yes set them to rogue values
		m_CJCMin.flt = RECORDER_TEMP_MIN_INVALID;
		m_CJCMax.flt = RECORDER_TEMP_MAX_INVALID;
		m_pNVCJCMin->SetToNV(m_CJCMin);
		m_pNVCJCMax->SetToNV(m_CJCMax);
	}
	// Reset startup mode to normal
	SetStartMode(START_MODE_NORMAL);
	m_Initialised = TRUE;
	return retVal;
}
//**********************************************************************
/// Include TC Cal in the input conditioning
///
/// @return		nothing
//**********************************************************************
void CSysInfo::IncludeAMS2750SensorCal() {
	SetTCCalExclude(FALSE);
	QString strTcCalIncluded;
	strTcCalIncluded = QWidget::tr("AMS2750 Sensor Cal adjust included");
	LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, strTcCalIncluded);
}
//**********************************************************************
/// Exclude TC Cal in the input conditioning
///
/// @return		nothing
//**********************************************************************
void CSysInfo::ExcludeAMS2750SensorCal() {
	SetTCCalExclude(TRUE);
	QString strTcCalExcluded;
	strTcCalExcluded = QWidget::tr("AMS2750 Sensor Cal adjust excluded");
	LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, strTcCalExcluded);
}
//**********************************************************************
/// Set or Clear the TC Cal Exclude NV Flag
/// 
/// @param[in]	exclude - TRUE to exclude the TC Cal, FALSE to include
///
/// @return		nothing
//**********************************************************************
void CSysInfo::SetTCCalExclude(BOOL exclude) {
	// Assign state to TC Cal exclude
	m_TCCalAdjustExclude.ul = (ULONG) exclude;
	// Save state to NV
	m_pNVTCCalAdjustExclude->SetToNV(m_TCCalAdjustExclude);
}
//**********************************************************************
/// Maintain the max/min of the temperature of the recorder by using valid
/// reading from any of the CJC's
/// 
/// @param[in]	cjcjInDegC - CJC value in degrees C
///
/// @return		nothing
//**********************************************************************
void CSysInfo::RegisterNewCJCValue(float cjcjInDegC) {
	// Is the new CJC reading lower then previously recorded
	if (cjcjInDegC < m_CJCMin.flt) {
		// Yes, it's a new low so reset
		m_CJCMin.flt = cjcjInDegC;
		m_pNVCJCMin->SetToNV(m_CJCMin);
	}
	// Is the new CJC reading higher then previously recorded
	if (cjcjInDegC > m_CJCMax.flt) {
		// Yes it's a new High so reset
		m_CJCMax.flt = cjcjInDegC;
		m_pNVCJCMax->SetToNV(m_CJCMax);
	}
}
//**********************************************************************
/// Set the serial number
/// 
/// @param[in]	newSerial - new serial number
///
/// @return		nothing
//**********************************************************************
void CSysInfo::SetSerialNumber(ULONG newSerial) {
	// Set serial number
	m_GeneralNVCfg.SerialNumber = newSerial;
	ReGenerateOptionsCode();
}
//**********************************************************************
/// Regenerate Options code
/// 
/// @return		nothing
//**********************************************************************
void CSysInfo::ReGenerateOptionsCode() {
	// create the options code for a serial number
	QString strOptionsCode("");
	m_OptionCode.CreateOptionsCode(strOptionsCode, m_GeneralNVCfg.SerialNumber, m_GeneralNVCfg.Credits,
			m_GeneralNVCfg.FWOptions.PasswordCFR,
			m_GeneralNVCfg.FWOptions.Pasturisation/*, m_GeneralNVCfg.FWOptions.SecureComm*/); // Build the default options code
	m_OptionCode.EncodeOptionsCode(strOptionsCode);		// encode the default options code
    WCHAR *pStr;
    strOptionsCode.toWCharArray(pStr);
    CStringUtils::SafeWcsCpy(m_GeneralNVCfg.OptionsCode, pStr, GENNONVOL_OPTIONSCODE_LEN);
}
//******************************************************
// ConfigurePens()
///
/// Configures pens
///
/// @return		TRUE if the pens are configured successful; otherwise FALSE
//******************************************************
BOOL CSysInfo::ConfigurePens(void) {
	USHORT slotNo;
	USHORT boardType;
	USHORT chanNo;
	USHORT channelCount = 0;
	UCHAR chanCap = 0;
	USHORT sysChanNo = 0;
	USHORT totalPens = 0;
	class CSlotMap *pSlotMap = NULL;
	BOOL createPen = FALSE;
	BOOL retValue = TRUE;
	pSlotMap = CSlotMap::GetHandle();
	// For each board fitted to a system, copy over to global board capabilities from the local stats
	for (slotNo = 0; slotNo < MAXIOCARDS; slotNo++) {
#ifndef DOCVIEW
		channelCount = DEVICE_INFO.GetSlotNumChannels(slotNo);
#else
		channelCount = MAX_AI_PER_CARD;
#endif
		boardType = DEVICE_INFO.GetSlotType(slotNo);
		for (chanNo = 0; chanNo < channelCount; chanNo++) {
			createPen = FALSE;
			// Now find out what demo channels have been selected too, so that they can be given pens.
			chanCap = GlbDevCaps.GetChannelCaps(slotNo, chanNo);
			if ((chanCap & CHANNEL_CAP_AI) != 0) {
				// Create pens for all analogue input channels
				createPen = TRUE;
				sysChanNo = pSlotMap->GetSysChannelFromAnaInChannel(slotNo, chanNo, ONE_BASED);
			} else if (((chanCap & CHANNEL_CAP_PULSE) != 0) && (boardType == BOARD_PI)) {
				// Only create pens for dedicated pulse channels
				createPen = TRUE;
				sysChanNo = pSlotMap->GetSysChannelFromDedicatedPulseChannel(slotNo, chanNo, ONE_BASED);
			}
			// Create the pens based on the hardware actually found
			if (createPen == TRUE) {
				SetPenAvailable(sysChanNo, ONE_BASED, TRUE);
				totalPens++;
			}
#ifdef DOCVIEW
			else
			{
				// get the channel number
				sysChanNo = pSlotMap->GetSysChannelFromAnaInChannel( slotNo, chanNo, ONE_BASED );
				SetPenAvailable( sysChanNo, ONE_BASED, FALSE );
			}
#endif
		}
	}
	// Setup extra pens depending on the firmware options
	USHORT extraPens = NORMAL_PENS;
	for (extraPens = NORMAL_PENS; extraPens < NORMAL_PENS + FWOptionExtraPensAvailable(); extraPens++) {
		SetPenAvailable(extraPens, ZERO_BASED, TRUE);
	}
	//set all remaining extra pens disabled - 
	//mainly of use to TTR6SETUP as pens get left enabled when adding a new device
	for (extraPens = (USHORT) (NORMAL_PENS + FWOptionExtraPensAvailable()); extraPens < V6_MAX_PENS; extraPens++) {
		SetPenAvailable(extraPens, ZERO_BASED, FALSE);
	}
#ifdef V6IOTEST
	for( int iCount = 0; iCount < V6_MAX_PENS; iCount++ )
	{
		SetPenAvailable( iCount, ZERO_BASED, TRUE );
		totalPens++;
	}
#endif
	// Now make available any TUS pens
	//if( GetAMS2750Mode() == AMS2750_TUS )
	if ( pSYSTEM_INFO->FWOptionTUSModeAvailable()) {
		// make the required TUS pens available - increment the number of available pens if necessary first
		if (m_penAvailable[gs_usSPECIAL_TUS_PEN_START_INST] == FALSE) {
			++totalPens;
		}
		if (m_penAvailable[gs_usSPECIAL_TUS_PEN_START_INST + 1] == FALSE) {
			++totalPens;
		}
		SetPenAvailable(gs_usSPECIAL_TUS_PEN_START_INST, ZERO_BASED, TRUE);
		SetPenAvailable(gs_usSPECIAL_TUS_PEN_START_INST + 1, ZERO_BASED, TRUE);
	}
	// Setup the available Pens
	SetTotalPens(totalPens + static_cast<USHORT>(pSYSTEM_INFO->FWOptionExtraPensAvailable()));
	return retValue;
}
//**********************************************************************
/// Build production info structure
///
/// @return		TRUE if the structure was populated OK, else FALSE 
/// 
/// Note no parameter method, updated the general NV copy of the production info structure
///
//**********************************************************************
BOOL CSysInfo::BuildProductionInfo() {
	return BuildProductionInfo(&m_GeneralNVCfg.ProductionInfo);
}
//**********************************************************************
/// Build production info structure
///
/// @param[in/out]	pProductionInfo - T_PRECPROD structure pointer
///
/// @return		TRUE if the structure was populated OK, else FALSE 
/// 
//**********************************************************************
BOOL CSysInfo::BuildProductionInfo(T_PRECPROD pProductionInfo) {
	BOOL bResult = TRUE;
	USHORT boardType = 0U;
	USHORT channelCount = 0U;
	USHORT slotNo = 0U;
	class CBrdInfo *pBrdInfoObj = NULL;
	pBrdInfoObj = CBrdInfo::GetHandle();
	// pProductionInfo->Table1_IOTop[slot]	(Slots A..F)
	for (slotNo = RECORDER_SLOT_A; slotNo <= RECORDER_SLOT_F; slotNo++) {
		channelCount = pBrdInfoObj->GetNoOfChannels(slotNo);	// DEVICE_INFO.GetSlotNumChannels( slotNo );
		boardType = pBrdInfoObj->WhatBoardType(slotNo);		//DEVICE_INFO.GetSlotType( slotNo );
		if ( BOARD_AI == boardType) {
			// Analogue input card
			if (channelCount == 4)
				pProductionInfo->Table1_IOTop[slotNo] = AI_4;
			else if (channelCount == 6)
				pProductionInfo->Table1_IOTop[slotNo] = AI_6;
			else if (channelCount == 8)
				pProductionInfo->Table1_IOTop[slotNo] = AI_8;
			else
				pProductionInfo->Table1_IOTop[slotNo] = NO_CARD;
		} else if ( BOARD_EZ_AI == boardType) {
			if (channelCount == 3)
				pProductionInfo->Table1_IOTop[slotNo] = AI_3;
			else if (channelCount == 6)
				pProductionInfo->Table1_IOTop[slotNo] = AI_6;
			else
				pProductionInfo->Table1_IOTop[slotNo] = NO_CARD;
		} else if ( BOARD_PI == boardType) {
			// Pulse input card
			pProductionInfo->Table1_IOTop[slotNo] = PI_4;
		} else if ( BOARD_AO == boardType) {
			// Analogue output card
			if (channelCount == 2)
				pProductionInfo->Table1_IOTop[slotNo] = AO_2;
			else if (channelCount == 4)
				pProductionInfo->Table1_IOTop[slotNo] = AO_4;
			else
				pProductionInfo->Table1_IOTop[slotNo] = NO_CARD;
		} else {
			// Other/no card
			pProductionInfo->Table1_IOTop[slotNo] = NO_CARD;
		}
	}
	// pProductionInfo->Table2_IOBot[slot]	(Slots G..I)
	for (slotNo = 0; slotNo <= 3; slotNo++) {
		channelCount = pBrdInfoObj->GetNoOfChannels(slotNo + RECORDER_SLOT_G);// DEVICE_INFO.GetSlotNumChannels( slotNo+6 );
		boardType = pBrdInfoObj->WhatBoardType(slotNo + RECORDER_SLOT_G);		//DEVICE_INFO.GetSlotType( slotNo+6 );
		if ( BOARD_AR == boardType) {
			// Alarm relay card
			if (channelCount == 4)
				pProductionInfo->Table2_IOBot[slotNo] = AR_4;
			else if (channelCount == 8)
				pProductionInfo->Table2_IOBot[slotNo] = AR_8;
			else
				pProductionInfo->Table2_IOBot[slotNo] = NO_CARD;
		} else if ( BOARD_DIO == boardType) {
			// Digital I/O card
			if (channelCount == 8)
				pProductionInfo->Table2_IOBot[slotNo] = DIO_8;
			else if (channelCount == 16)
				pProductionInfo->Table2_IOBot[slotNo] = DIO_16;
			else
				pProductionInfo->Table2_IOBot[slotNo] = NO_CARD;
		} else {
			// Other/no card
			pProductionInfo->Table2_IOBot[slotNo] = NO_CARD;
		}
	}
	// Build product model string
	WCHAR buffer[10];
	memset(buffer, 0, 10);
	// Build device specific stuff
	// pProductionInfo->ModelNoDisplay
	T_DEV_TYPE deviceType = DEV_UNKNOWN;
	deviceType = GlbDevCaps.GetDeviceType();
	switch (deviceType) {
	case DEV_ARISTOS_MINITREND:
	case DEV_PC_MINI:
	case DEV_TEST:
		// Key 
#if _MSC_VER < 1400 
		wcscpy(pProductionInfo->ModelNoDisplay, QX_KEY);
		wcscat(pProductionInfo->ModelNoDisplay, SEPERATOR);
#else
		if ( deviceType == DEV_ARISTOS_MINITREND )
		{
			wcscpy_s( pProductionInfo->ModelNoDisplay, sizeof(pProductionInfo->ModelNoDisplay)/sizeof(WCHAR), NEW_QX_KEY );
			wcscat( pProductionInfo->ModelNoDisplay, sizeof(pProductionInfo->ModelNoDisplay)/sizeof(WCHAR), SEPERATOR );
		}
		else
		{
			wcscpy_s( pProductionInfo->ModelNoDisplay, sizeof(pProductionInfo->ModelNoDisplay)/sizeof(WCHAR), QX_KEY );
			wcscat( pProductionInfo->ModelNoDisplay, sizeof(pProductionInfo->ModelNoDisplay)/sizeof(WCHAR), SEPERATOR );
		}
#endif
		// Slots A, B
		for (slotNo = 0; slotNo < 2; slotNo++) {
			buffer[0] = pProductionInfo->Table1_IOTop[slotNo];
			buffer[1] = (WCHAR) '\0';
#if _MSC_VER < 1400 
			wcscat(pProductionInfo->ModelNoDisplay, buffer);
#else
			wcscat( pProductionInfo->ModelNoDisplay, sizeof(pProductionInfo->ModelNoDisplay)/sizeof(WCHAR), buffer );
#endif
		}
#if _MSC_VER < 1400 
		wcscat(pProductionInfo->ModelNoDisplay, SEPERATOR);
		// Discrete Inputs
		buffer[0] = pProductionInfo->Table2_IOBot[0];
		buffer[1] = (WCHAR) '\0';
		wcscat(pProductionInfo->ModelNoDisplay, buffer);
		wcscat(pProductionInfo->ModelNoDisplay, SEPERATOR);
#else
		wcscat( pProductionInfo->ModelNoDisplay, sizeof(pProductionInfo->ModelNoDisplay)/sizeof(WCHAR), SEPERATOR );
		// Discrete Inputs
		buffer[0] = pProductionInfo->Table2_IOBot[0];
		buffer[1] = (WCHAR)'\0';
		wcscat( pProductionInfo->ModelNoDisplay, sizeof(pProductionInfo->ModelNoDisplay)/sizeof(WCHAR), buffer );
		wcscat( pProductionInfo->ModelNoDisplay, sizeof(pProductionInfo->ModelNoDisplay)/sizeof(WCHAR), SEPERATOR );
#endif
		break;
	case DEV_ARISTOS_MULTIPLUS:
	case DEV_PC_MULTI:
		// Key
#if _MSC_VER < 1400 
		wcscpy(pProductionInfo->ModelNoDisplay, SX_KEY);
		wcscat(pProductionInfo->ModelNoDisplay, SEPERATOR);
#else
	if ( deviceType == DEV_ARISTOS_MULTIPLUS )
	{
		wcscpy_s( pProductionInfo->ModelNoDisplay, sizeof(pProductionInfo->ModelNoDisplay)/sizeof(WCHAR), NEW_SX_KEY );
		wcscat( pProductionInfo->ModelNoDisplay, sizeof(pProductionInfo->ModelNoDisplay)/sizeof(WCHAR), SEPERATOR );
	}
	else
	{
		wcscpy_s( pProductionInfo->ModelNoDisplay, sizeof(pProductionInfo->ModelNoDisplay)/sizeof(WCHAR), SX_KEY );
		wcscat( pProductionInfo->ModelNoDisplay, sizeof(pProductionInfo->ModelNoDisplay)/sizeof(WCHAR), SEPERATOR );
	}
#endif
		// Slots A..F
		for (slotNo = 0; slotNo < 6; slotNo++) {
			buffer[0] = pProductionInfo->Table1_IOTop[slotNo];
			buffer[1] = (WCHAR) '\0';
#if _MSC_VER < 1400 
			wcscat(pProductionInfo->ModelNoDisplay, buffer);
#else
			wcscat( pProductionInfo->ModelNoDisplay, sizeof(pProductionInfo->ModelNoDisplay)/sizeof(WCHAR), buffer );
#endif
		}
#if _MSC_VER < 1400 
		wcscat(pProductionInfo->ModelNoDisplay, SEPERATOR);
#else
		wcscat( pProductionInfo->ModelNoDisplay, sizeof(pProductionInfo->ModelNoDisplay)/sizeof(WCHAR), SEPERATOR );
#endif
		// Discrete slots G..I
		for (slotNo = 0; slotNo < 3; slotNo++) {
			buffer[0] = pProductionInfo->Table2_IOBot[slotNo];
			buffer[1] = (WCHAR) '\0';
#if _MSC_VER < 1400 
			wcscat(pProductionInfo->ModelNoDisplay, buffer);
#else
			wcscat( pProductionInfo->ModelNoDisplay, sizeof(pProductionInfo->ModelNoDisplay)/sizeof(WCHAR), buffer );
#endif
		}
#if _MSC_VER < 1400 
		wcscat(pProductionInfo->ModelNoDisplay, SEPERATOR);
#else
		wcscat( pProductionInfo->ModelNoDisplay, sizeof(pProductionInfo->ModelNoDisplay)/sizeof(WCHAR), SEPERATOR );
#endif
		break;
	case DEV_ARISTOS_EZTREND: ////ARISTOS QXe Device Type updates
	case DEV_PC_EZTREND:
#if _MSC_VER < 1400 
		wcscpy(pProductionInfo->ModelNoDisplay, EX_KEY);
		wcscat(pProductionInfo->ModelNoDisplay, SEPERATOR);
#else
	if ( deviceType == DEV_ARISTOS_EZTREND ) //ARISTOS QXe Device Type updates
	{
		//Fix for the par 1-3AUG16Z
		wcscpy_s( pProductionInfo->ModelNoDisplay, sizeof(pProductionInfo->ModelNoDisplay)/sizeof(WCHAR), NEW_EX_KEY );
		wcscat( pProductionInfo->ModelNoDisplay, sizeof(pProductionInfo->ModelNoDisplay)/sizeof(WCHAR), SEPERATOR );
	}
	else
	{
		//Fix for the par 1-3AUG16Z
		wcscpy_s( pProductionInfo->ModelNoDisplay, sizeof(pProductionInfo->ModelNoDisplay)/sizeof(WCHAR), EX_KEY);
		wcscat( pProductionInfo->ModelNoDisplay, sizeof(pProductionInfo->ModelNoDisplay)/sizeof(WCHAR), SEPERATOR );
	}
#endif
		buffer[0] = pProductionInfo->Table1_IOTop[0];
		if ( pDALGLB->IsMotherBoardFitted())
			buffer[1] = EZ_EXPANSION_CARD;
		else
			buffer[1] = NO_CARD;
		buffer[3] = (WCHAR) '\0';
#if _MSC_VER < 1400 
		wcscat(pProductionInfo->ModelNoDisplay, buffer);
		wcscat(pProductionInfo->ModelNoDisplay, SEPERATOR);
#else
		wcscat( pProductionInfo->ModelNoDisplay, sizeof(pProductionInfo->ModelNoDisplay)/sizeof(WCHAR), buffer );
		wcscat( pProductionInfo->ModelNoDisplay, sizeof(pProductionInfo->ModelNoDisplay)/sizeof(WCHAR), SEPERATOR );
#endif
		buffer[0] = pProductionInfo->Table1_IOTop[1];
		buffer[1] = pProductionInfo->Table2_IOBot[0];
		if ( pDALGLB->IsCommsBoardFitted())
			buffer[2] = EZ_COMMS;
		else
			buffer[2] = NO_CARD;
		buffer[3] = (WCHAR) '\0';
#if _MSC_VER < 1400 
		wcscat(pProductionInfo->ModelNoDisplay, buffer);
		wcscat(pProductionInfo->ModelNoDisplay, SEPERATOR);
#else
		wcscat( pProductionInfo->ModelNoDisplay, sizeof(pProductionInfo->ModelNoDisplay)/sizeof(WCHAR), buffer );
		wcscat( pProductionInfo->ModelNoDisplay, sizeof(pProductionInfo->ModelNoDisplay)/sizeof(WCHAR), SEPERATOR );
#endif
		break;
	case DEV_SCR_MINITREND:
		//PSR Fix for PAR# 1-3IRVD6A - With changed jumper settings, we are not able to configure the recorders with digital I/O or Alarm cards. begin
		//As per SCR DRG2 MSG(Model Selection Guide the tables are as follows
		//	Key Number				I(AI/DI)		II(Power)		III	(Memory)		IV(Credtis)		V(Options)				VI(Factory Use)
		//	_ _ _ _ _ _		-		_ _ 		-	_ _			- 	_				-	_ _ _		-	 _ _ _ _ _ _		-	_ _ _	
		//PSR Fix for PAR# 1-3IRVD6A - With changed jumper settings, we are not able to configure the recorders with digital I/O or Alarm cards. end
		//PSR for PAR #1-3O00AC7 - Update SCR FW and PU tool with latest MSG with 3 characters for IO Slots begin
		//The table I for IO slots has changed to 3 characters instead of two characters like above
		//	I(AI/DI)		to I(AI/DI)
		//	_ _ 			to	_ _ _
		//PSR for PAR #1-3O00AC7 - Update SCR FW and PU tool with latest MSG with 3 characters for IO Slots end
		//
		// Key 
#if _MSC_VER < 1400 
		wcscpy(pProductionInfo->ModelNoDisplay, SCR_DRG2_KEY);
		wcscat(pProductionInfo->ModelNoDisplay, SEPERATOR);
#else
		if ( deviceType == DEV_SCR_MINITREND )
		{
			wcscpy_s( pProductionInfo->ModelNoDisplay, sizeof(pProductionInfo->ModelNoDisplay)/sizeof(WCHAR), SCR_DRG2_KEY );
			wcscat( pProductionInfo->ModelNoDisplay, sizeof(pProductionInfo->ModelNoDisplay)/sizeof(WCHAR), SEPERATOR );
		}
		else
		{
			wcscpy_s( pProductionInfo->ModelNoDisplay, sizeof(pProductionInfo->ModelNoDisplay)/sizeof(WCHAR), SCR_DRG2_KEY );
			wcscat( pProductionInfo->ModelNoDisplay, sizeof(pProductionInfo->ModelNoDisplay)/sizeof(WCHAR), SEPERATOR );
		}
#endif
		//PSR Fix for PAR# 1-3IRVD6A - With changed jumper settings, we are not able to configure the recorders with digital I/O or Alarm cards. begin
		//The Latest MSG Says Slot A0 is always zero(i.e. No onBoard) and Slot 1(Top) should be only Analog Io (so Slot A) 
		//and Slot 2(bottom) could be either Analog or Discret Io so (Slot B or Slot H) 
		/*
		 Slot 1 (A0)				No Analog Inputs							(Note 1)		0 _ _	
		 Slot A				None														_ 0 _		
		 Four Analog Inputs								(Note 1)		_ 4 _		
		 Six Analog Inputs								(Note 1)		_ 6 _		
		 Eight Analog Inputs								(Note 1)		_ 8 _		
		 Four Pulse Inputs												_ P _		
		 Slot B				None														_ _ 0		
		 Six Additional Analog Inputs								(Note 1)		_ _ 6		
		 Eight Additional Analog Inputs								(Note 1)		_ _ 8		
		 Four Pulse Inputs															_ _ P		
		 8 Relay/2 Digital Inputs-6 Fixed Outputs/2 Configurable DI or Relay			_ _ 2		
		 8 Configurable Digital Inputs/Discrete 24V Relay Outputs					_ _ 3		
		 16 Configurable Digital Inputs/Discrete 24V Relay Outputs					_ _ 4		
		 Two Analog Outputs 															_ _ A		
		 Four Analog Outputs															_ _ B*/
		// Slots A, B and Discrete slots G and H...as per above Slot G also not supported
		//PSR for PAR #1-3O00AC7 - Update SCR FW and PU tool with latest MSG with 3 characters for IO Slots begin
		buffer[0] = NO_CARD; ///As Per latest MSG the Slot A0 is not for TV DRG2 and only NO_CARD is allowed value
		buffer[1] = (WCHAR) '\0';
#if _MSC_VER < 1400 
		wcscat(pProductionInfo->ModelNoDisplay, buffer);
#else
					wcscat( pProductionInfo->ModelNoDisplay, sizeof(pProductionInfo->ModelNoDisplay)/sizeof(WCHAR), buffer );
		#endif
		//PSR for PAR #1-3O00AC7 - Update SCR FW and PU tool with latest MSG with 3 characters for IO Slots end
		//Read the data from Hardware Configuration on IO slots and update modelnumber string as per msg
		for (slotNo = 0; slotNo < 2; slotNo++) {
			buffer[0] = pProductionInfo->Table1_IOTop[slotNo];
			buffer[1] = (WCHAR) '\0';
			switch (slotNo) {
			case 0: //The solt 1 does not support AO and Discrete inputs check above comments
			{
				if ( NO_CARD != buffer[0]) {
					//Make it 0 other than below four supported IOs in Top Slot
					if ((AI_4 == buffer[0]) || (AI_6 == buffer[0]) || (AI_8 == buffer[0]) || (PI_4 == buffer[0])) {
						///no thing wrong here so break
						break;
					} else {
						//Wrong board fitted in this slot so make it NO_BOARD
						buffer[0] = NO_CARD;
					}
				}
				break;
			}
			case 1: //If no Analog Card in Slot 2 then check for Discrete IO Card
			{
				if ((AI_6 == buffer[0]) || (AI_8 == buffer[0]) || (PI_4 == buffer[0]) || (AO_2 == buffer[0])
						|| (AO_4 == buffer[0])) {
					///no thing wrong here..correct board fitted.. so break
					break;
				} else if ( NO_CARD == buffer[0]) //If NO_CARD(AI/AO/PI) in slot 2 then check the Dicrete category (DI, AR)
						{
					//NO_CARD so check if this solt is behaving as Slot H (Jumper settings) then get the buffer from Table2_IOBot
					buffer[0] = pProductionInfo->Table2_IOBot[slotNo];
				} else {
					//If this slot 2 behaves as Slot B (jumper settings) then only 6,8,P,A,B are supported..other than that means 
					//wrong board connected in this slot so make it NO_BOARD
					buffer[0] = NO_CARD;
				}
				break;
			}
			default: //this Never executes unless for loop is modified 
			{
				buffer[0] = NO_CARD;
				break;
			}
			}
#if _MSC_VER < 1400 
			wcscat(pProductionInfo->ModelNoDisplay, buffer);
#else
			wcscat( pProductionInfo->ModelNoDisplay, sizeof(pProductionInfo->ModelNoDisplay)/sizeof(WCHAR), buffer );
#endif
		}
		//PSR Fix for PAR# 1-3IRVD6A - With changed jumper settings, we are not able to configure the recorders with digital I/O or Alarm cards. end
#if _MSC_VER < 1400 
		wcscat(pProductionInfo->ModelNoDisplay, SEPERATOR);
#else
		wcscat( pProductionInfo->ModelNoDisplay, sizeof(pProductionInfo->ModelNoDisplay)/sizeof(WCHAR), SEPERATOR );
#endif
		break;
	default:
		break;
	}
	// Power
	// pProductionInfo->Table3_Power
#if _MSC_VER < 1400 
	if (iswprint(pProductionInfo->Table3_Power[0]))
		wcsncpy(buffer, pProductionInfo->Table3_Power, 2);
	else
        wcscpy(buffer,L"**");
#else
	if ( iswprint( pProductionInfo->Table3_Power[0] ) )
		wcsncpy_s( buffer, sizeof(buffer)/sizeof(WCHAR), pProductionInfo->Table3_Power, 2 );
	else
        wcscpy_s( buffer,sizeof(buffer)/sizeof(WCHAR), L"**" );
#endif
	buffer[2] = (WCHAR) '\0';
#if _MSC_VER < 1400 
	wcscat(pProductionInfo->ModelNoDisplay, buffer);
	wcscat(pProductionInfo->ModelNoDisplay, SEPERATOR);
#else
	wcscat( pProductionInfo->ModelNoDisplay, sizeof(pProductionInfo->ModelNoDisplay)/sizeof(WCHAR), buffer );
	wcscat( pProductionInfo->ModelNoDisplay, sizeof(pProductionInfo->ModelNoDisplay)/sizeof(WCHAR), SEPERATOR );
#endif
	MediaUtils MediaAPI;
    QString DeviceName;
	int Length = MAX_PATH;
	T_MEDIA_SIZE InternalCFSize = MediaAPI.MediaSize(
    pDALGLB->GetPath((T_STORAGE_PATH) IDS_INTERNAL_SD, &DeviceName, MAX_PATH, &Length));
	// Internal memory
	// pProductionInfo->Table4_memory
#if _MSC_VER < 1400 
	if (iswprint(pProductionInfo->Table4_memory[0]))
		wcsncpy(buffer, pProductionInfo->Table4_memory, 1);
	else
        wcscpy(buffer, L"*");
#else
	if ( iswprint( pProductionInfo->Table4_memory[0] ) )
		wcsncpy_s( buffer, sizeof(buffer)/sizeof(WCHAR), pProductionInfo->Table4_memory, 1 );
	else
        wcscpy_s( buffer, sizeof(buffer)/sizeof(WCHAR), L"*" );
#endif
	//PSR fix for - 1-3I2G538 PU_Front SD and Internal SD combinations in MSG are not handled in Production Tool begin
	//Get the External Memory (SD) card size as we have MSG options for 8GB External(Front) SD
	//For EzTrend only back SD with 1 & 2 GB are available
	//ToDo: Better read this configuration from ini or xml and make it configurable
	int nFrontSDLength = MAX_PATH;
	T_MEDIA_SIZE ExternalSDSize = MediaAPI.MediaSize(
    pDALGLB->GetPath((T_STORAGE_PATH) IDS_EXTERNAL_SD, &DeviceName, MAX_PATH, &nFrontSDLength));
	// override the set SD size with the actual
	switch (InternalCFSize) {
	case MS_8G:
		buffer[0] = INT_SD_8GIG;
		break;
	case MS_4G: {
		if ( FALSE == pGlbDal->IsRecorderEzTrend()) {
			if (MS_8G == ExternalSDSize) //Not supported for Ez
					{
				buffer[0] = INT_SD_4GB_EXT_SD_8GB;
			} else {
				buffer[0] = INT_SD_4GIG;
			}
		} else {
			buffer[0] = INT_SD_NOT_SUPPORTED; //4GB not supported for Ez
		};
	}
		break;
	case MS_2G: {
		if ((FALSE == pGlbDal->IsRecorderEzTrend()) && (MS_8G == ExternalSDSize)) //Not supported for Ez
				{
			buffer[0] = INT_SD_2GB_EXT_SD_8GB;
		} else {
			buffer[0] = INT_SD_2GIG;
		}
	}
		break;
	case MS_1G: {
		if ((FALSE == pGlbDal->IsRecorderEzTrend()) && (MS_8G == ExternalSDSize)) //Not supported for Ez ..
				{
			buffer[0] = INT_SD_1GB_EXT_SD_8GB;
		} else {
			buffer[0] = INT_SD_1GIG;
		}
	}
		break;
	case MS_128M: //GR does not support 128MB back SD card (as per ModelSelectionGuide)
		buffer[0] = INT_SD_128;
		break;
		/*case MS_512M:
		 buffer[0] = INT_CF_512;
		 break;
		 case MS_256M:
		 buffer[0] = INT_CF_256;
		 break;
		 case MS_128M:
		 buffer[0] = INT_CF_128;
		 break;*/
	}
	buffer[1] = (WCHAR) '\0';
	//PSR fix for - 1-3I2G538 PU_Front SD and Internal SD combinations in MSG are not handled in Production Tool end
#if _MSC_VER < 1400 
	wcscat(pProductionInfo->ModelNoDisplay, buffer);
	wcscat(pProductionInfo->ModelNoDisplay, SEPERATOR);
#else
	wcscat( pProductionInfo->ModelNoDisplay, sizeof( pProductionInfo->ModelNoDisplay)/sizeof(WCHAR), buffer );
	wcscat( pProductionInfo->ModelNoDisplay, sizeof( pProductionInfo->ModelNoDisplay)/sizeof(WCHAR), SEPERATOR );
#endif
	// Credits
	// pProductionInfo->Table5_Credits
#if _MSC_VER < 1400 
	if (iswprint(pProductionInfo->Table5_Credits[0]))
		wcsncpy(buffer, pProductionInfo->Table5_Credits, 3);
	else
        wcscpy(buffer, L"***");
#else
	if ( iswprint( pProductionInfo->Table5_Credits[0] ) )
		wcsncpy_s( buffer, sizeof(buffer)/sizeof(WCHAR), pProductionInfo->Table5_Credits, 3 );
	else
        wcscpy_s( buffer, sizeof(buffer)/sizeof(WCHAR), L"***" );
#endif
	buffer[3] = (WCHAR) '\0';
#if _MSC_VER < 1400 
	wcscat(pProductionInfo->ModelNoDisplay, buffer);
	wcscat(pProductionInfo->ModelNoDisplay, SEPERATOR);
#else
	wcscat( pProductionInfo->ModelNoDisplay, sizeof( pProductionInfo->ModelNoDisplay)/sizeof(WCHAR), buffer );
	wcscat( pProductionInfo->ModelNoDisplay, sizeof( pProductionInfo->ModelNoDisplay)/sizeof(WCHAR), SEPERATOR );
#endif
	// Options
	// pProductionInfo->Table6_Options
#if _MSC_VER < 1400 
	if (iswprint(pProductionInfo->Table6_Options[0]))
		wcsncpy(buffer, pProductionInfo->Table6_Options, 6);
	else
        wcscpy(buffer, L"******");
	buffer[6] = (WCHAR) '\0';
	wcscat(pProductionInfo->ModelNoDisplay, buffer);
	wcscat(pProductionInfo->ModelNoDisplay, SEPERATOR);
	// OEM labeling
	// pProductionInfo->Table7_OEM
	if (iswprint(pProductionInfo->Table7_OEM[0]))
		wcsncpy(buffer, pProductionInfo->Table7_OEM, 3);
	else
        wcscpy(buffer, L"***");
	buffer[3] = (WCHAR) '\0';
	wcscat(pProductionInfo->ModelNoDisplay, buffer);
#else
	if ( iswprint( pProductionInfo->Table6_Options[0] ) )
		wcsncpy_s( buffer, sizeof(buffer)/sizeof(WCHAR), pProductionInfo->Table6_Options, 6 );
	else
        wcscpy_s( buffer, sizeof( buffer)/sizeof(WCHAR), L"******" );
	buffer[6] = (WCHAR)'\0';
	wcscat( pProductionInfo->ModelNoDisplay, sizeof( pProductionInfo->ModelNoDisplay)/sizeof(WCHAR), buffer );
	wcscat( pProductionInfo->ModelNoDisplay, sizeof( pProductionInfo->ModelNoDisplay)/sizeof(WCHAR), SEPERATOR );
	// OEM labeling
	// pProductionInfo->Table7_OEM
	if ( iswprint( pProductionInfo->Table7_OEM[0] ) )
		wcsncpy_s( buffer, sizeof( buffer)/sizeof(WCHAR), pProductionInfo->Table7_OEM, 3 );
	else
        wcscpy_s( buffer, sizeof( buffer)/sizeof(WCHAR), L"***" );
	buffer[3] = (WCHAR)'\0';
	wcscat( pProductionInfo->ModelNoDisplay, sizeof( pProductionInfo->ModelNoDisplay)/sizeof(WCHAR), buffer );
#endif
	// Done...
	return bResult;
}
//**********************************************************************
/// Roll session number, take latest session number and increment
///
/// @return		new session number 
/// 
//**********************************************************************
const USHORT CSysInfo::RollSessionNumber() {
	// Get the current session number, add 1 then save session number back to SRAM.
	USHORT session = GetSessionNumber();
	session += SESSION_INCREMENT;
	SetSessionNumber(session);
	pDALGLB->UpdateSRAM();
	m_IndentityInfo.usSessionNumber = session;
	SetIdentity();
	// Reset log block sequence numbers
	ResetSequenceNumbers();
	return session;
}
//**********************************************************************
/// Resets log block sequence numbers back to default after a session roll.
///
/// @return		None
/// 
//**********************************************************************
void CSysInfo::ResetSequenceNumbers() {
	CNVBasicVar *pNVSequenceNumber;
	for (int instance = 0; instance < V6_MAX_PENS; instance++) {
		pNVSequenceNumber = pNV_VARS->GetBasicVarNVObject(static_cast<NVVAR_IDENT>(NVV_PEN_SEQ_FIRST + instance));
		if (NULL != pNVSequenceNumber) {
			pNVSequenceNumber->GetFromNV()->value.ul = 1L;
		}
	}
}
//**********************************************************************
/// Set a new session number, will be stored in SRAM.
///
/// @param[in] - newSessionNumber, the new session number in the sequence
///
/// @return		TRUE if successful otherwise FALSE
/// 
//**********************************************************************
void CSysInfo::SetSessionNumber( USHORT newSessionNumber) {
	m_SysInfoCS.lock();
	m_sessionNumber.us[SESSION_ELEMENT] = newSessionNumber;
	m_nextSessionNumber = m_sessionNumber.us[SESSION_ELEMENT] + 1;// Always set m_nextSessionNumber to be 1 more the m_sessionNumber
	m_pNVSessionNumber->SetToNV(m_sessionNumber);
	m_SysInfoCS.lock();
}
//**********************************************************************
/// Get Device name from OEM Info 
///
/// @return		WCHAR pointer to device Name
/// 
//**********************************************************************
const WCHAR* const CSysInfo::GetOEMDeviceName() {
	//TM - change V6 in strings to XSeries, add DEV_PC_TTR6SETUP to switch statment
	// Create some defaults for unknwon and desktop devices
    static WCHAR unknownDeviceName[] = L"TrendView Device";
    //static WCHAR desktopDeviceName[] = "X Series Desktop"; // string too long on mini/Ez
	WCHAR *pDeviceName = unknownDeviceName;
	// Based on the determined device type extract the relevant product name from the OEM information
	switch ( DEVICE_INFO.GetDeviceType()) {
	case DEV_TEST:
	case DEV_ARISTOS_MINITREND:
	case DEV_PC_MINI:
	case DEV_SCR_MINITREND:
		pDeviceName = pOemInfo->GetText( V6RES_TEXT_MINIPRODNAME)->szTextValue;
		break;
	case DEV_XS_MINITREND:
		pDeviceName = pOemInfo->GetText( V6RES_TEXT_MINIPRODNAME)->szTextValue;
		break;
	case DEV_ARISTOS_MULTIPLUS:
	case DEV_PC_MULTI:
		pDeviceName = pOemInfo->GetText( V6RES_TEXT_MULTIPRODNAME)->szTextValue;
		break;
	case DEV_XS_MULTIPLUS:
		pDeviceName = pOemInfo->GetText( V6RES_TEXT_MULTIPRODNAME)->szTextValue;
		break;
	case DEV_ARISTOS_EZTREND: //ARISTOS QXe Device Type updates
	case DEV_PC_EZTREND:
		pDeviceName = pOemInfo->GetText( V6RES_TEXT_EZPRODNAME)->szTextValue;
		break;
	case DEV_XS_EZTREND:
        pDeviceName = pOemInfo->GetText(V6RES_TEXT_EZPRODNAME)->szTextValue; //"eZtrend QXe";
		break;
	case DEV_PC_TTR6SETUP:
	default:
		pDeviceName = unknownDeviceName;
		break;
	}
	return pDeviceName;
}
//**********************************************************************
///
/// See if Pen is available, base indicated by 'base' to make intent readable
/// and avoid mixed base issues which is unavoidable in this system
///
/// @param[in]	PenNumber - Pen Number
/// @param[in]	base - Base assumption T_PENBASE, ZERO_BASED = Pen1=0 Pen96=95
///												 ONE_BASED = Pen1=1 Pen96=96
/// @return		TRUE if Pen available, FALSE if pen not available
/// 
//**********************************************************************
const BOOL CSysInfo::IsPenAvailable( USHORT penNumber, T_PENBASE base) {
	BOOL retVal = FALSE;
	// Pen references are always zero based internally
	penNumber = PEN_TO_ZERO_BASED(penNumber, base);
	if (penNumber < V6_MAX_PENS) {
		retVal = m_penAvailable[penNumber];
	}
	return retVal;
}
//**********************************************************************
///
/// Set Pen availability
/// 
/// @param[in]	PenNumber - Pen Number
/// @param[in]	base - Base assumption T_PENBASE, ZERO_BASED = Pen1=0 Pen96=95
///												 ONE_BASED = Pen1=1 Pen96=96
/// @param[in]	available - TRUE if pen available, otherwise FALSE
/// @return		nothing
/// 
//**********************************************************************
void CSysInfo::SetPenAvailable( USHORT penNumber, T_PENBASE base, BOOL available) {
	penNumber = PEN_TO_ZERO_BASED(penNumber, base);
	m_numAvailablePens = 0;		// Reset total available pen count
	if (penNumber < V6_MAX_PENS) {
		m_penAvailable[penNumber] = available;
	}
	// Run through all pen entries and build total available
	for (int penCount = 0; penCount < V6_MAX_PENS; penCount++) {
		if (m_penAvailable[penCount] == TRUE)
			m_numAvailablePens++;
	}
}
//**********************************************************************
/// void InitFWOptWeights( )
/// 
/// Method that intialises the map containing the firmware option weightings
///
//**********************************************************************
void CSysInfo::InitFWOptWeights() {
	m_kFWOptWeightMap[fwoMathsFullBlock] = 4;
	m_kFWOptWeightMap[fwoMathsFullScript] = 6;
	m_kFWOptWeightMap[fwoEvents] = 6;
	m_kFWOptWeightMap[fwoFastScan] = 5;
	m_kFWOptWeightMap[fwoTotals] = 4;
	m_kFWOptWeightMap[fwoCustomScrn] = 4;
	m_kFWOptWeightMap[fwoReports] = 3;
	m_kFWOptWeightMap[fwoNADCAPRecorder] = 5;
	m_kFWOptWeightMap[fwoMaintenance] = 2;
	m_kFWOptWeightMap[fwoPrintSupport] = 2;
	m_kFWOptWeightMap[fwoTUSMode] = 10;
	//m_kFWOptWeightMap[ fwoControlLoops ] = 0;
	m_kFWOptWeightMap[fwoBatch] = 5;
	m_kFWOptWeightMap[fwoCounters] = 3;
	m_kFWOptWeightMap[fwoModbusMaster] = 10;
	m_kFWOptWeightMap[fwoRemoteViewer] = 3;
	//m_kFWOptWeightMap[ fwoTrendBus ] = 3;
	m_kFWOptWeightMap[fwoEmail] = 3;
	//m_kFWOptWeightMap[ fwoOPC ] = 8;
	m_kFWOptWeightMap[fwoOpcUaServer] = 8;
#ifndef XSERIESSETUP
	m_kFWOptWeightMap[fwoExtSD] = 5;
#ifndef TTR6SETUP
	m_kFWOptWeightMap[fwoSecureWSD] = 0; //3; ////R200 - WSD True by default e836320_tvgr200_spr_1_wsd - Make the WSD enable by default
#else 
	m_kFWOptWeightMap[ fwoSecureWSD ] = 3;
#endif
	m_kFWOptWeightMap[fwoHWLock] = 2;
	m_kFWOptWeightMap[fwoRTDataBus] = 3;
#endif 
	m_kFWOptWeightMap[fwoPwdNetSync] = 5;
}
//**********************************************************************
// bool ValidateFWOptions(	const T_FIRMWARE_OPT eREQ_CREDIT_TYPE,
//							USHORT &rusCreditsInUse,
//							const ULONG ulNO_OF_PENS /* = 0 */ ) const
/// 
/// @param[in]	const CSysInfo::T_FIRMWARE_OPT eREQ_CREDIT_TYPE - The type of additional credits required
///	@param[out]	USHORT &rusCreditsInUse - The total number of credits being used
/// @param[in]	const ULONG ulNO_OF_PENS - The numer of pens required should the user have modified the pens FW option
///
/// @return		True if the credits could be allocated okay
/// 
/// @todo		Add code that gets the current firmware options so we can see if the user is reducing it
///				Only required if something has gone wrong and we have too many options before adding the
///				additional required credits. Also add credits for new items here.
//**********************************************************************
bool CSysInfo::ValidateFWOptions(const CSysInfo::T_FIRMWARE_OPT eREQ_CREDIT_TYPE,
USHORT &rusCreditsInUse, const ULONG ulNO_OF_PENS /* = 0 */) const {
	bool bAllocatedCredits = false;
	USHORT usOptionWeight = NULL;
	// reset the credits in use before calculating it
	rusCreditsInUse = 0;
	// check if the sum of all the credits and the further required credits exceed our number of credits
	const T_FIRMOPTIONS tFIRM_OPT = m_GeneralNVCfg.FWOptions;
	// check if each item is selected - if yes then add its weighting to the list
	if (((tFIRM_OPT.MathsType == MATH_OPTION_FULL_BLOCK) && (eREQ_CREDIT_TYPE != fwoMathsFullScript))
			|| (eREQ_CREDIT_TYPE == fwoMathsFullBlock)) {
		usOptionWeight = m_kFWOptWeightMap.value(fwoMathsFullBlock);
		rusCreditsInUse += usOptionWeight;
	}
	if (((tFIRM_OPT.MathsType == MATH_OPTION_FULL_SCRIPT) && (eREQ_CREDIT_TYPE != fwoMathsFullBlock))
			|| (eREQ_CREDIT_TYPE == fwoMathsFullScript)) {
		usOptionWeight = m_kFWOptWeightMap.value(fwoMathsFullScript);
		rusCreditsInUse += usOptionWeight;
	}
	if ((tFIRM_OPT.Events == TRUE) || (eREQ_CREDIT_TYPE == fwoEvents)) {
		usOptionWeight = m_kFWOptWeightMap.value(fwoEvents);
		rusCreditsInUse += usOptionWeight;
	}
	if ((tFIRM_OPT.FastScan == TRUE) || (eREQ_CREDIT_TYPE == fwoFastScan)) {
		usOptionWeight = m_kFWOptWeightMap.value(fwoFastScan);
		rusCreditsInUse += usOptionWeight;
	}
	if ((tFIRM_OPT.Totals == TRUE) || (eREQ_CREDIT_TYPE == fwoTotals)) {
		usOptionWeight = m_kFWOptWeightMap.value(fwoTotals);
		rusCreditsInUse += usOptionWeight;
	}
	if ((tFIRM_OPT.CustomScreens == TRUE) || (eREQ_CREDIT_TYPE == fwoCustomScrn)) {
		usOptionWeight = m_kFWOptWeightMap.value(fwoCustomScrn);
		rusCreditsInUse += usOptionWeight;
	}
	if ((tFIRM_OPT.Reports == TRUE) || (eREQ_CREDIT_TYPE == fwoReports)) {
		usOptionWeight = m_kFWOptWeightMap.value(fwoReports);
		rusCreditsInUse += usOptionWeight;
	}
	if ((tFIRM_OPT.AMS2750Process == TRUE) || (eREQ_CREDIT_TYPE == fwoNADCAPRecorder)) {
		usOptionWeight = m_kFWOptWeightMap.value(fwoNADCAPRecorder);
		rusCreditsInUse += usOptionWeight;
	}
	if ((tFIRM_OPT.AMS2750TUS == TRUE) || (eREQ_CREDIT_TYPE == fwoTUSMode)) {
		usOptionWeight = m_kFWOptWeightMap.value(fwoTUSMode);
		rusCreditsInUse += usOptionWeight;
	}
	if ((tFIRM_OPT.Maintenance == TRUE) || (eREQ_CREDIT_TYPE == fwoMaintenance)) {
		usOptionWeight = m_kFWOptWeightMap.value(fwoMaintenance);
		rusCreditsInUse += usOptionWeight;
	}
	if ((tFIRM_OPT.PrintSupport == TRUE) || (eREQ_CREDIT_TYPE == fwoPrintSupport)) {
		usOptionWeight = m_kFWOptWeightMap.value(fwoPrintSupport);
		rusCreditsInUse += usOptionWeight;
	}
	if ((tFIRM_OPT.Batch == TRUE) || (eREQ_CREDIT_TYPE == fwoBatch)) {
		usOptionWeight = m_kFWOptWeightMap.value(fwoBatch);
		rusCreditsInUse += usOptionWeight;
	}
	if ((tFIRM_OPT.Counters == TRUE) || (eREQ_CREDIT_TYPE == fwoCounters)) {
		usOptionWeight = m_kFWOptWeightMap.value(fwoCounters);
		rusCreditsInUse += usOptionWeight;
	}
	if ((tFIRM_OPT.RemoteView == TRUE) || (eREQ_CREDIT_TYPE == fwoRemoteViewer)) {
		usOptionWeight = m_kFWOptWeightMap.value(fwoRemoteViewer);
		rusCreditsInUse += usOptionWeight;
	}
	if ((tFIRM_OPT.Email == TRUE) || (eREQ_CREDIT_TYPE == fwoEmail)) {
		usOptionWeight = m_kFWOptWeightMap.value(fwoEmail);
		rusCreditsInUse += usOptionWeight;
	}
	/*if( ( tFIRM_OPT.OPC == TRUE ) || ( eREQ_CREDIT_TYPE == fwoOPC ) )
	 {
	 m_kFWOptWeightMap.Lookup( fwoOPC, usOptionWeight );
	 rusCreditsInUse += usOptionWeight;
	 }*/
#ifndef XSERIESSETUP
	if ((tFIRM_OPT.ExtSD == TRUE) || (eREQ_CREDIT_TYPE == fwoExtSD)) {
		usOptionWeight = m_kFWOptWeightMap.value(fwoExtSD);
		rusCreditsInUse += usOptionWeight;
	}
	if ((tFIRM_OPT.SecureWSD == TRUE) || (eREQ_CREDIT_TYPE == fwoSecureWSD)) {
		usOptionWeight = m_kFWOptWeightMap.value(fwoSecureWSD);
		rusCreditsInUse += usOptionWeight;
	}
	if ((tFIRM_OPT.RTDataBus == TRUE) || (eREQ_CREDIT_TYPE == fwoRTDataBus)) {
		usOptionWeight = m_kFWOptWeightMap.value(fwoRTDataBus);
		rusCreditsInUse += usOptionWeight;
	}
	if ((tFIRM_OPT.HWLock == TRUE) || (eREQ_CREDIT_TYPE == fwoHWLock)) {
		usOptionWeight = m_kFWOptWeightMap.value(fwoHWLock);
		rusCreditsInUse += usOptionWeight;
	}
	if ((tFIRM_OPT.OPCUA == TRUE) || (eREQ_CREDIT_TYPE == fwoOpcUaServer)) {
		usOptionWeight = m_kFWOptWeightMap.value(fwoOpcUaServer);
		rusCreditsInUse += usOptionWeight;
	}
#endif 
	if ((tFIRM_OPT.PasswordsSync == TRUE) || (eREQ_CREDIT_TYPE == fwoPwdNetSync)) {
		usOptionWeight = m_kFWOptWeightMap.value(fwoPwdNetSync);
		rusCreditsInUse += usOptionWeight;
	}
	if ((tFIRM_OPT.ModbusMaster == TRUE) || (eREQ_CREDIT_TYPE == fwoModbusMaster)) {
		usOptionWeight = m_kFWOptWeightMap.value(fwoModbusMaster);
		rusCreditsInUse += usOptionWeight;
	}
	// now add the extra pens credits
	float tCreditsForExtraPens = 0;
	// check if the pens are being modified
	if (eREQ_CREDIT_TYPE == fwoExtraPens) {
		// pens are being modified therefore add these
		tCreditsForExtraPens = static_cast<float>(ulNO_OF_PENS) / ms_usNO_PENS_PER_CREDIT;
		rusCreditsInUse += static_cast< USHORT >(ceil(tCreditsForExtraPens));
	} else {
		// pen not being modifed therefore use the existing
		tCreditsForExtraPens = static_cast<float>(tFIRM_OPT.ExtraPens) / ms_usNO_PENS_PER_CREDIT;
		rusCreditsInUse += static_cast< USHORT >(ceil(tCreditsForExtraPens));
	}
	if ((rusCreditsInUse > m_GeneralNVCfg.Credits) && (eREQ_CREDIT_TYPE != fwoNoneRequired)) {
		// we will have exceeded our quota therefore return false unless this is less than what we have
		// already in which case we must allwo the user t reduce their quota
		bAllocatedCredits = false;
	} else {
		// we can allocate these credits therefore return true
		bAllocatedCredits = true;
	}
	return bAllocatedCredits;
}
//**********************************************************************
//	const USHORT GetOptionInfo(	const T_FIRMWARE_OPT eOPTION_TYPE,
//								QString  &rstrOptionTitle,
//								USHORT &rusNoOfCredits ) const
/// 
/// Method that obtains information about a particular firmware option
///
/// @param[in]			const CSysInfo::T_FIRMWARE_OPT eOPTION_TYPE - The firware option being requested
/// @param[out]			QString  &rstrOptionTitle - The title of this firmware option ("" is not a valid option)
///	@param[out]			USHORT &rusNoOfCredits - The number of credits being used by this option
///
/// @return		True/False if the firmware option is enabled/disabled or the number of extra pens available
/// 
//**********************************************************************
const USHORT CSysInfo::GetOptionInfo(const T_FIRMWARE_OPT eOPTION_TYPE, QString &rstrOptionTitle,
USHORT &rusNoOfCredits) const {
	USHORT usEnabled = 0;
	const T_FIRMOPTIONS tFIRM_OPT = m_GeneralNVCfg.FWOptions;
	// get the number of options first
	rusNoOfCredits = m_kFWOptWeightMap.value(eOPTION_TYPE);
	switch (eOPTION_TYPE) {
	case fwoMathsFullBlock:
		rstrOptionTitle = QWidget::tr("Basic Maths|Full Maths|Scripting|");
		rstrOptionTitle = CStringUtils::GetItemAtPos(rstrOptionTitle, MATH_OPTION_FULL_BLOCK);
		usEnabled = (tFIRM_OPT.MathsType >= MATH_OPTION_FULL_BLOCK) ? TRUE : FALSE;
		break;
	case fwoMathsFullScript:
		if (!GlbDevCaps.IsRecorderEzTrend()) {
			rstrOptionTitle = QWidget::tr("Basic Maths|Full Maths|Scripting|");
			rstrOptionTitle = CStringUtils::GetItemAtPos(rstrOptionTitle, MATH_OPTION_FULL_SCRIPT);
			usEnabled = (tFIRM_OPT.MathsType == MATH_OPTION_FULL_SCRIPT) ? TRUE : FALSE;
		} else {
			rstrOptionTitle = "";
			usEnabled = FALSE;
		}
		break;
	case fwoEvents:
		rstrOptionTitle = QWidget::tr("Events");
		usEnabled = (tFIRM_OPT.Events == TRUE) ? TRUE : FALSE;
		break;
	case fwoFastScan:
		if (!GlbDevCaps.IsRecorderEzTrend()) {
			rstrOptionTitle = QWidget::tr("Fast Scan");
			usEnabled = (tFIRM_OPT.FastScan == TRUE) ? TRUE : FALSE;
		} else {
			rstrOptionTitle = "";
			usEnabled = FALSE;
		}
		break;
	case fwoTotals:
		rstrOptionTitle = QWidget::tr("Totals");
		usEnabled = (tFIRM_OPT.Totals == TRUE) ? TRUE : FALSE;
		break;
	case fwoCustomScrn: {
		T_DEV_TYPE devType = GlbDevCaps.GetDeviceType();
		if (!GlbDevCaps.IsRecorderEzTrend()) {
			rstrOptionTitle = QWidget::tr("Custom Scrn");
			usEnabled = (tFIRM_OPT.CustomScreens == TRUE) ? TRUE : FALSE;
		} else {
			rstrOptionTitle = "";
			usEnabled = FALSE;
		}
	}
		break;
	case fwoReports:
		rstrOptionTitle = QWidget::tr("Reports");
		usEnabled = (tFIRM_OPT.Reports == TRUE) ? TRUE : FALSE;
		break;
	case fwoNADCAPRecorder:
		rstrOptionTitle = QWidget::tr("AMS2750 Process");
		usEnabled = (tFIRM_OPT.AMS2750Process == TRUE) ? TRUE : FALSE;
		break;
	case fwoMaintenance:
		rstrOptionTitle = QWidget::tr("Maintenance");
		usEnabled = (tFIRM_OPT.Maintenance == TRUE) ? TRUE : FALSE;
		break;
	case fwoPrintSupport:
		rstrOptionTitle = QWidget::tr("Printing");
		usEnabled = (tFIRM_OPT.PrintSupport == TRUE) ? TRUE : FALSE;
		break;
	case fwoTUSMode:
		rstrOptionTitle = QWidget::tr("AMS2750 TUS");
		usEnabled = (tFIRM_OPT.AMS2750TUS == TRUE) ? TRUE : FALSE;
		break;
		/* REMOVED UNTIL THE CODE IS IMPLEMENTED
		 case fwoControlLoops:
		 rstrOptionTitle = QWidget::tr("Control Loops");
		 usEnabled = ( tFIRM_OPT.ControlLoops == TRUE )?TRUE:FALSE;
		 break;
		 */
	case fwoBatch:
		rstrOptionTitle = QWidget::tr("Batch");
		usEnabled = (tFIRM_OPT.Batch == TRUE) ? TRUE : FALSE;
		break;
	case fwoCounters:
		rstrOptionTitle = QWidget::tr("Counters");
		usEnabled = (tFIRM_OPT.Counters == TRUE) ? TRUE : FALSE;
		break;
	case fwoModbusMaster:
		rstrOptionTitle = QWidget::tr("Modbus Master");
		usEnabled = (tFIRM_OPT.ModbusMaster == TRUE) ? TRUE : FALSE;
		break;
	case fwoRemoteViewer:
		rstrOptionTitle = QWidget::tr("Remote View");
		usEnabled = (tFIRM_OPT.RemoteView == TRUE) ? TRUE : FALSE;
		break;
		/* REMOVED UNTIL THE CODE IS IMPLEMENTED
		 case fwoTrendBus:
		 rstrOptionTitle = QWidget::tr("TrendBus");
		 usEnabled = ( tFIRM_OPT.TrendBus == TRUE )?TRUE:FALSE;
		 break;*/
	case fwoEmail:
        rstrOptionTitle = QWidget::tr("Emai");
		usEnabled = (tFIRM_OPT.Email == TRUE) ? TRUE : FALSE;
		break;
		/*case fwoOPC:
		 rstrOptionTitle = QWidget::tr("OPC");
		 usEnabled = ( tFIRM_OPT.OPC == TRUE )?TRUE:FALSE;
		 break;*/
#ifndef XSERIESSETUP
	case fwoExtSD:
		if (GlbDevCaps.IsRecorderEzTrend()) {
			rstrOptionTitle = QWidget::tr("External SD");
			usEnabled = (tFIRM_OPT.ExtSD == TRUE) ? TRUE : FALSE;
		} else {
			rstrOptionTitle = "";
			usEnabled = FALSE;
		}
		break;
	case fwoHWLock:
		rstrOptionTitle = QWidget::tr("Hardware Lock");
		usEnabled = (tFIRM_OPT.HWLock == TRUE) ? TRUE : FALSE;
		break;
	case fwoOpcUaServer: {
		rstrOptionTitle = QWidget::tr("OPC UA");
		usEnabled = (tFIRM_OPT.OPCUA == TRUE) ? TRUE : FALSE;
	}
		break;
	case fwoSecureWSD: {
		rstrOptionTitle = QWidget::tr("Secure WSD");
		usEnabled = (tFIRM_OPT.SecureWSD == TRUE) ? TRUE : FALSE;
	}
		break;
	case fwoRTDataBus: {
		rstrOptionTitle = QWidget::tr("RTData Bus");
		usEnabled = (tFIRM_OPT.RTDataBus == TRUE) ? TRUE : FALSE;
		break;
	}
#endif
	case fwoPwdNetSync:
		rstrOptionTitle = QWidget::tr("Pwd Net Sync");
		usEnabled = (tFIRM_OPT.PasswordsSync == TRUE) ? TRUE : FALSE;
		break;
	case fwoExtraPens: {
		rstrOptionTitle = QWidget::tr("Extra Pens");
		float fCreditsForExtraPens = 0;
		fCreditsForExtraPens = static_cast<float>(tFIRM_OPT.ExtraPens) / ms_usNO_PENS_PER_CREDIT;
		rusNoOfCredits = static_cast< USHORT >(ceil(fCreditsForExtraPens));
		usEnabled = static_cast< USHORT >(tFIRM_OPT.ExtraPens);
	}
		break;
	default:
		usEnabled = FALSE;
		// set this field title to "" so the calling method knows this is not a valid option yet
		rstrOptionTitle = "";
		break;
	}
	return usEnabled;
}
//**********************************************************************
/// bool ValidateOptionsCode()
/// 
/// Method that validates an encoded options code
///
/// @param[in]		const WCHAR* const pwcOptionsCode - Pointer to the options code to validate
///
/// @return		True if the options code was valid
///
//**********************************************************************
bool CSysInfo::ValidateOptionsCode(const QString pwcOptionsCode) {
	bool bValid = FALSE;
	BOOL PasswordCFR = FALSE;
	BOOL Pasturisation = FALSE;
	//BOOL SecureComm		= FALSE;
	ULONG Credits = 0;
	// Call decipher which will return options if decpher successful
	if (m_OptionCode.DecipherOptionsCode(pwcOptionsCode, m_GeneralNVCfg.SerialNumber, Credits, PasswordCFR,
			Pasturisation/*, SecureComm */) == TRUE) {
		m_GeneralNVCfg.FWOptions.PasswordCFR = PasswordCFR;
		m_GeneralNVCfg.FWOptions.Pasturisation = Pasturisation;
		m_GeneralNVCfg.Credits = Credits;
        WCHAR *pStr;
        pwcOptionsCode.toWCharArray(pStr);
        CStringUtils::SafeWcsCpy(m_GeneralNVCfg.OptionsCode, pStr, GENNONVOL_OPTIONSCODE_LEN);
		//m_GeneralNVCfg.FWOptions.SecureComm = SecureComm;
		bValid = true;
	}
	return bValid;
}
///============================================================================================
// Device identity file, stored on internal SD and provide a validation file of recorder
// Used as an emergency copy of important device data, 
// can also be used to detect media swap.
const QString IdentityFile = "Indentity.TV6";
//****************************************************************************
/// Check and read device identity file
///
// return TRUE if the file exists and can be read, else FALSE
//****************************************************************************
BOOL CSysInfo::GetIdentity() {
	BOOL bResult = FALSE;
	CStorage idFile;
    QString wcFileName;
	T_IDENTITY localIdentity;
    pDALGLB->BuildPath((T_STORAGE_DEVICE) IDS_ANY_DEVICE, (T_STORAGE_PATH) IDS_INTERNAL_SD, &IdentityFile, &wcFileName, MAX_PATH);
	QFileDevice::FileError kEx;
	if ( TRUE == idFile.Open(wcFileName, QFile::ReadOnly, &kEx)) {
		idFile.seek(0);
		if (idFile.size() != sizeof(T_IDENTITY))
			bResult = FALSE;
		//idFile.Read( &m_IndentityInfo, sizeof( T_IDENTITY ));
		idFile.Read(&localIdentity, sizeof(T_IDENTITY));
		idFile.Close();
		// Check the file CRC
		if (localIdentity.crc != CrcCalc((unsigned char*) &localIdentity, sizeof(T_IDENTITY) - sizeof(USHORT)))
			bResult = FALSE;
		else {
			// CRC is OK, check the serial number
			if (localIdentity.ulSerialNumber == m_GeneralNVCfg.SerialNumber) {
				// Serial number is OK, use the data
				m_IndentityInfo = localIdentity;
				bResult = TRUE;
			} else
				bResult = FALSE;
		}
	} else {
		// Raised an exception so report the cause if it is not of type file does not exist
        /*
		if (kEx.m_cause != QFileDevice::FileError::fileNotFound) {
            idFile.ShowError("CSysInfo::GetIdentity( )", wcFileName, kEx);
        }*/
	}
	return bResult;
}
//****************************************************************************
/// Create/update the identity file
///
// return TRUE if OK, else FALSE
//****************************************************************************
BOOL CSysInfo::SetIdentity() {
	BOOL bResult = FALSE;
	CStorage idFile;
    QString wcFileName;
    pDALGLB->BuildPath((T_STORAGE_DEVICE) IDS_ANY_DEVICE, (T_STORAGE_PATH) IDS_INTERNAL_SD, &IdentityFile, &wcFileName,
	MAX_PATH);
    if ( TRUE == idFile.Open(wcFileName,  QFile::WriteOnly, NULL)) {
		m_IndentityInfo.crc = CrcCalc((unsigned char*) &m_IndentityInfo, sizeof(T_IDENTITY) - sizeof(USHORT));
		idFile.Write(&m_IndentityInfo, sizeof(T_IDENTITY));
		idFile.Close();
		bResult = TRUE;
	}
	return bResult;
}
//****************************************************************************
/// Set the production information
///
/// @param[in] pProdInfo - pointer to T_RECPROD structure to set information
//
// return nothing
//****************************************************************************
void CSysInfo::SetProductionInfo(T_PRECPROD pProdInfo) {
	T_PGENNONVOL ptGenNonVol = pSYSTEM_INFO->GetFactoryConfig();
	// Copy new production infomation
	memcpy(&m_GeneralNVCfg.ProductionInfo, pProdInfo, sizeof(T_RECPROD));
	// Set current mains frequency and language from the productioninfo
	USHORT usPos = (USHORT) wcslen(pProdInfo->ModelNoDisplay);
	if (usPos > 18) {
		usPos -= 18;
		if ( MAINS_60HZ == pProdInfo->ModelNoDisplay[usPos]) {
			// Set mains frequency to 60Hz
			ptGenNonVol->Localisation.MainFreq = 1;
		} else {
			// Set mains frequency to 50Hz
			ptGenNonVol->Localisation.MainFreq = 0;
		}
	}
	usPos = (USHORT) wcslen(pProdInfo->ModelNoDisplay);
	if (usPos > 10) {
		usPos -= 9;
		if ( LANGUAGE_ENGLISH == pProdInfo->ModelNoDisplay[usPos]) {
			// Set language to English
			ptGenNonVol->Language = lngEnglish;
		} else if ( LANGUAGE_FRENCH == pProdInfo->ModelNoDisplay[usPos]) {
			// Set language to French
			ptGenNonVol->Language = lngFra;
		} else if ( LANGUAGE_GERMAN == pProdInfo->ModelNoDisplay[usPos]) {
			// Set language to German
			ptGenNonVol->Language = lngGer;
		}
	}
}
//****************************************************************************
/// Set the unit into post configuration mode
///
/// return TRUE if OK, else FALSE
//****************************************************************************
void CSysInfo::PostUnitConfigurationMode() {
	SetHotSoakTestMode();
	WCHAR wcOEM = (WCHAR) '?';
	T_PGENNONVOL ptGenNonVol = pSYSTEM_INFO->GetFactoryConfig();
	WCHAR *wcProdOEM = ptGenNonVol->ProductionInfo.Table7_OEM;
	if (wcslen(wcProdOEM) > 0) {
		wcOEM = *wcProdOEM;
	}
	if (pSYSTEM_INFO->SoftwareUpdater()->indexOfUpdatePackage(wcOEM) == TRUE) {
		pDALGLB->SetShutDownMode(SHUTDOWN_MODE_FW_UPDATE);
		WCHAR szcommandline[MAX_PATH], szInstallerPath[MAX_PATH];
		//Our Installer app is always present inthe intCF, 
#if _MSC_VER < 1400 
        wcscpy(szInstallerPath, L"FirmwareUpgrade.exe");
#else
        wcscpy_s(szInstallerPath, MAX_PATH, L"FirmwareUpgrade.exe");
#endif
        QString mediaFullPath;
		int length = MAX_PATH;
		T_STORAGE_DEVICE m_InstallDrive;
		WCHAR xsuFile[MAX_PATH];
//		PROCESS_INFORMATION process;
		BOOL bResult = FALSE;
		swprintf(xsuFile, MAX_PATH, pSYSTEM_INFO->SoftwareUpdater()->GetFileName());
		m_InstallDrive = pSYSTEM_INFO->SoftwareUpdater()->GetInstallDriveName();
        pDALGLB->GetPath((T_STORAGE_PATH) m_InstallDrive, &mediaFullPath, MAX_PATH, &length);
        WCHAR *pStr;
        mediaFullPath.toWCharArray(pStr);
		//Build the complete path of the XSU installer cab file
        wcscpy(szcommandline, L"\"");
        wcscat(szcommandline, pStr);
		wcscat(szcommandline, xsuFile);
        wcscat(szcommandline, L"\"");
		//Set the XSU file path into the NV Region , SRAM, Also note that
		//Firmware upgrade is requested.
		pDALGLB->SetFirmwareUpdateDetails(FW_UPDATE_WCELOAD, QString::fromWCharArray(szcommandline));
		// reset the modified flag is we do not want the commit dialog to show - the user will lose
		// any changes here but AK says this is okay
//		CRecSetupCfgMgr *pkInstance = CRecSetupCfgMgr::Instance();
//		pkInstance->SetModified( false );
		//Launch the FirmwareUpgrade App.
		/// TODO : Firmware update through Yocto
		bResult = CreateProcess(szInstallerPath, szcommandline, NULL, NULL, FALSE, 0, NULL, NULL, NULL, &process);
	} else {
		pSYSTEM_INFO->SoftwareUpdater()->CancelUpdate();
	}
}
//****************************************************************************
/// Save the Gen non vol structure into flash
///
/// return TRUE if OK, else FALSE
//****************************************************************************
BOOL CSysInfo::NVSaveToFlash() {
	BOOL retVal = TRUE;
	T_FLASH_STATUS flashStatus = m_pFlash->WriteBlock(FLASH_BLK_SYSTEM, &m_GeneralNVCfg, sizeof(T_GENNONVOL));
	if (flashStatus != FLASH_STATUS_OKAY) {
		retVal = FALSE;
	}
	m_GenNonVolChanged = FALSE;		// No need to write NV block
	//Fix for PAR #1-3ENG3D7 - Code refactoring for Hardware lock fix RecSetupCfgMgr.cpp
	m_uiHWLockCommited = FWOptionHWLockAvailable();
	return retVal;
}
//****************************************************************************
/// Load the Gen non vol structure from flash into memory
///
/// return T_FLASH_STATUS of transaction status
//****************************************************************************
T_FLASH_STATUS CSysInfo::NVLoadfromFlash() {
	//Fix for PAR #1-3ENG3D7 - Code refactoring for Hardware lock fix RecSetupCfgMgr.cpp
	T_FLASH_STATUS tFlashSatus = m_pFlash->ReadBlock(FLASH_BLK_SYSTEM, &m_GeneralNVCfg, sizeof(T_GENNONVOL));
	m_uiHWLockCommited = FWOptionHWLockAvailable();
	return tFlashSatus;
}
//****************************************************************************
//	const ULONG GetReplayChartSpeed( const USHORT usSCREEN_NO) const
///
/// Method used to get a particular replay charts speed
///
/// @param[in]			const USHORT usSCREEN_NO - Screen no. for which chart gets displayed
///
/// @return			The reply chart speed as an enum, 0 - FAST, 1 - MED, 2 - SLOW
///
//****************************************************************************
// CR: 3151 Replay at Faster speed
const ULONG CSysInfo::GetReplayChartSpeed(const USHORT usSCREEN_NO) const {
	ULONG ulBitFieldAsULong = m_staticInfo->ReplayChartSpeed;
	// we now need to extra the correct two bits based on the chart number
	// shift the ULONG right until the first bit is the start of our bitfield
	ulBitFieldAsULong >>= (2 * usSCREEN_NO);
	// now mask all the higher bits
	ulBitFieldAsULong &= 0x00000003;
	return ulBitFieldAsULong;
}
//****************************************************************************
//	const ULONG GetChartSpeed( const USHORT usCHART_NO, const USHORT usSCREEN_NO ) const
///
/// Method used to get a particular charts speed
///
/// @param[in]			const USHORT usCHART_NO - The chart no on the current screen
/// @param[in]			const USHORT usSCREEN_NO
///
/// @return			The chart speed as an enum, 0 - FAST, 1 - MED, 2 - SLOW
///
//****************************************************************************
const ULONG CSysInfo::GetChartSpeed(const USHORT usCHART_NO, const USHORT usSCREEN_NO) const {
	// get the ULONG containing all the chart speeds for this particular screen
	ULONG ulBitFieldAsULong = m_staticInfo->ChartSpeed[usSCREEN_NO];
	// we now need to extra the correct two bits based on the chart number
	// shift the ULONG right until the first bit is the start of our bitfield
	ulBitFieldAsULong >>= (2 * usCHART_NO);
	// now mask all the higher bits
	ulBitFieldAsULong &= 0x00000003;
	return ulBitFieldAsULong;
}
//****************************************************************************
//	void SetReplayChartSpeed(const USHORT usSCREEN_NO, const USHORT usSPEED )
///
/// Method used to set replay chart speed for a perticular screen
///
/// @param[in]			const USHORT usSCREEN_NO - The screen no of reply chart
/// @param[in]			const USHORT usSPEED	-	The chart speed as an enum, 0 - FAST, 1 - MED, 2 - SLOW
///
/// @return		
///
//****************************************************************************
// CR: 3151 Replay at Faster speed
void CSysInfo::SetReplayChartSpeed(const USHORT usSCREEN_NO, const USHORT usSPEED) {
	// firstly we need to get set the two bits in the correct position within the ULONG
	ULONG ulThisChartSpeedBits = static_cast<ULONG>(usSPEED);
	ulThisChartSpeedBits <<= (2 * usSCREEN_NO);
	// now create a bitmask so we can reset the existing value without affecting an of the other chart
	// speeds
	ULONG ulResetBits = 0x00000003;
	ulResetBits <<= (2 * usSCREEN_NO);
	ulResetBits = ~ulResetBits;
	// we now need to mask the existing location of these two bits (e.g. set them to zero)
	m_staticInfo->ReplayChartSpeed &= ulResetBits;
	// finally set the new value for the two bits
	m_staticInfo->ReplayChartSpeed |= ulThisChartSpeedBits;
}
//****************************************************************************
//	void SetChartSpeed( const USHORT usCHART_NO, const USHORT usSCREEN_NO, const USHORT usSPEED )
///
/// Method used to set a particular chart speed
///
/// @param[in]			const USHORT usCHART_NO - The chart no on the current screen
/// @param[in]			const USHORT usSCREEN_NO
///
/// @return			The chart speed as an enum, 0 - FAST, 1 - MED, 2 - SLOW
///
//****************************************************************************
void CSysInfo::SetChartSpeed(const USHORT usCHART_NO, const USHORT usSCREEN_NO, const USHORT usSPEED) {
	// firstly we need to get set the two bits in the correct position within the ULONG
	ULONG ulThisChartSpeedBits = static_cast<ULONG>(usSPEED);
	ulThisChartSpeedBits <<= (2 * usCHART_NO);
	// now create a bitmask so we can reset the existing value without affecting an of the other chart
	// speeds
	ULONG ulResetBits = 0x00000003;
	ulResetBits <<= (2 * usCHART_NO);
	ulResetBits = ~ulResetBits;
	// we now need to mask the existing location of these two bits (e.g. set them to zero)
	m_staticInfo->ChartSpeed[usSCREEN_NO] &= ulResetBits;
	// finally set the new value for the two bits
	m_staticInfo->ChartSpeed[usSCREEN_NO] |= ulThisChartSpeedBits;
}
//****************************************************************************
//	SetSlotCardSerialNo
///
/// Method used to set a particular board serial number in a recorder slot
///
/// @param[in]			usSlotNo - The chart no on the current screen
/// @param[in]			usFirstTest - Date and time of first test
/// @param[in]			ucRigNo - Rig number that first test occurred on
///
//****************************************************************************
void CSysInfo::SetSlotCardSerialNo(const USHORT usSlotNo, const ULONG usFirstTest, const UCHAR ucRigNo) {
	m_staticInfo->SlotCardSerialNos[usSlotNo].RigNoOfFirstTest = ucRigNo;
	m_staticInfo->SlotCardSerialNos[usSlotNo].TimeDateOfFirstTest = usFirstTest;
}
//****************************************************************************
//	SetSlotCardSerialNo
///
/// Method used to set a particular board serial number in a recorder slot
///
/// @param[in]			usSlotNo - The chart no on the current screen
/// @param[out]			usFirstTest - Date and time of first test
/// @param[out]			ucRigNo - Rig number that first test occurred on
///
//****************************************************************************
void CSysInfo::GetSlotCardSerialNo(const USHORT usSlotNo, ULONG &usFirstTest, UCHAR &ucRigNo) {
	ucRigNo = m_staticInfo->SlotCardSerialNos[usSlotNo].RigNoOfFirstTest;
	usFirstTest = m_staticInfo->SlotCardSerialNos[usSlotNo].TimeDateOfFirstTest;
}
//**********************************************************************
/// Check if a functional area is available, by testing a keyfile on devices available
/// contained within a "keys" directory
///
/// @param[in]  functionalArea - T_FUNCTION_PROTECTION of area to check for
/// @param[in]  removeFileAfterCheck - will remove the keyfile if set to TRUE, if FALSE will leave.
///
/// @return TRUE if key found, otherwise false
//**********************************************************************
BOOL CSysInfo::IsFunctionAvailable(T_FUNCTION_PROTECTION functionalArea, BOOL removeFileAfterCheck) {
	BOOL functionAvailable = FALSE;
	// Test front SD first, if this does not contain a key then test the first USB device
	functionAvailable = TestFunctionAvailableFromDevice(functionalArea, removeFileAfterCheck, SD_EXTERNAL_SD);
	if (functionAvailable == FALSE) {
		functionAvailable = TestFunctionAvailableFromDevice(functionalArea, removeFileAfterCheck, SD_USB1);
	}
	return functionAvailable;
}
//**********************************************************************
/// Test if a function exists on a specific device
///
/// @param[in]  functionalArea - T_FUNCTION_PROTECTION of area to check for
/// @param[in]  removeFileAfterCheck - will remove the keyfile if set to TRUE, if FALSE will leave.
/// @param[in]  testDevice - the device to test the key on
///
/// @return TRUE if key found, otherwise false
//**********************************************************************
BOOL CSysInfo::TestFunctionAvailableFromDevice(T_FUNCTION_PROTECTION functionalArea, BOOL removeFileAfterCheck,
		storageDeviceIdent testDevice) {
	BOOL functionAvailable = FALSE;
	BOOL bRemoveKeysDir = FALSE;
	// Build standard path for keyfile
	QString strFunctionKey;
    strFunctionKey = QString::asprintf("%skeys/", pDALGLB->GetVolumeName(testDevice, NULL, 0).toLocal8Bit().data());
	// Add specific filename for each keyfile type
	switch (functionalArea) {
	case FUNC_PROTECT_PRODUCTION:			// Production menu in factory setup
	{
		strFunctionKey += "prodfact.key";
		break;
	}
	case FUNC_PROTECT_DIAGNOSTICS:			// System diagnostics 
	{
		strFunctionKey += "sysdiag.key";
		break;
	}
	case FUNC_PROTECT_CAL_TOUCH_SCREEN:		// Calibrate touch screen
	{
		strFunctionKey += "caltouch.key";
		break;
	}
	case FUNC_FACTORY_RESET:				// Factor reset, clears all layouts, passwords, configs.
	{
		if (V6_RELEASE != RELEASE_PRODUCTION) {
			strFunctionKey += "factreset.key";						// Alpha or Beta build key is not encoded
		} else {
            strFunctionKey += GeneratePWEncodedFilename("FR");	// Production release encoded key
		}
		break;
	}
	case FUNC_PRODUCTION_RESET:	// production reset, clears all layouts, passwords, configs, ready for customer shipments
	{
		strFunctionKey += "mfrreset.key";
		break;
	}
	case FUNC_ENTER_MFR_MODE:				// Key to enter manufacturing mode
	{
		strFunctionKey += "mfrmode.key";
		break;
	}
	case FUNC_EXIT_MFR_MODE:			// Key to exit manufacturing mode (and/or Hot Soak mode) and enter customer mode
	{
		strFunctionKey += "custmode.key";
		break;
	}
	case FUNC_ENTER_HOTSOAKTEST_MODE:		// Key to enter Hot Soak Test mode (+manufacturing mode)
	{
		strFunctionKey += "hotsoak.key";
		break;
	}
	case FUNC_EXIT_HOTSOAKTEST_MODE:		// Key to exit Hot Soak Test mode (+manufacturing mode)
	{
		strFunctionKey += "exithotsoak.key";
		//PSR Fix for PAR# 1-3N6VKTT - With an USB pen drive in recorder, when we click on [Prepare to Ship], then recorder is showing boot. begin
		bRemoveKeysDir = removeFileAfterCheck;		///remove keys direcotry when exiting			
		//PSR Fix for PAR# 1-3N6VKTT - With an USB pen drive in recorder, when we click on [Prepare to Ship], then recorder is showing boot. begin
		break;
	}
	case FUNC_TUS_TEST_MODE:				// TUS test miode for demo's and tests
	{
		strFunctionKey += "tusdemo.key";
		break;
	}
	case FUNC_DATA_RESET:					// Data Reset, clears only chart and log data from SRAM and removes LCF
	{
		if (V6_RELEASE != RELEASE_PRODUCTION) {
			strFunctionKey += "datareset.key";						// Alpha or Beta build key is not encoded
		} else {
            strFunctionKey += GeneratePWEncodedFilename("DR");	// Production release encoded key
		}
		break;
	}
	case FUNC_RESET_LITHLIFE:				// Reset the lithium life on a battery change
	{
        strFunctionKey += GeneratePWEncodedFilename("LITHR");
		break;
	}
	case FUNC_RESET_BACKLIGHTLIFE:			// Reset the backlight life on a backlight replacement
	{
        strFunctionKey += GeneratePWEncodedFilename("BACKR");
		break;
	}
	case FUNC_15SECS_CORRECTIONTIME: {
		strFunctionKey += "15SECONDS";
		break;
	}
	case FUNC_30SECS_CORRECTIONTIME: {
		strFunctionKey += "30SECONDS";
		break;
	}
	case FUNC_45SECS_CORRECTIONTIME: {
		strFunctionKey += "45SECONDS";
		break;
	}
	default: {
        MessageBox(NULL, L"Function area not \n implemented in \n IsFunctionAvailable", L"Error SysInfo",
		MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST);
		strFunctionKey += "nothing.key";
	}
	}
	// Set file attributes before trying to remove
    CFileStatus status;
    if (CStorage::GetStatus(strFunctionKey, &status) == TRUE) {
        // File exists
		functionAvailable = TRUE;
		//PSR Fix for PAR# 1-3N6VKTT - With an USB pen drive in recorder, when we click on [Prepare to Ship], then recorder is showing boot. begin
		if ( TRUE == bRemoveKeysDir) // Check if we need to remove the key folder itself along with all key files
				{
			QString strKeysPath;
            strKeysPath = QString::asprintf("%skeys", pDALGLB->GetVolumeName(testDevice, NULL, 0).toLocal8Bit().data());
			RemoveKeysDirectory(strKeysPath);
		} else if (removeFileAfterCheck) // Check if we need to remove the keyfile alone after use for one shot functions
		{
			status.m_attribute = 0x00;
            CStorage::SetStatus(strFunctionKey, &status);
			// Remove the file
            CStorage::remove(strFunctionKey);
		}
		//PSR Fix for PAR# 1-3N6VKTT - With an USB pen drive in recorder, when we click on [Prepare to Ship], then recorder is showing boot. end
	}
	return functionAvailable;
}
//PSR Fix for PAR# 1-3N6VKTT - With an USB pen drive in recorder, when we click on [Prepare to Ship], then recorder is showing boot. begin
BOOL CSysInfo::RemoveKeysDirectory(QString strPath) {
	BOOL retValue = FALSE;
	QString strKeyFiles(strPath);
    strKeyFiles += "/*"; //Search all files (. / .. and all fiels and subdirs
	WIN32_FIND_DATA sindexOfData;
	HANDLE hindexOf = NULL;
	hindexOf = CStorage::FindFirstFile(strKeyFiles, &sindexOfData);
	QString strFileName("");
	bool bContinueSearch = false;
	int nDirStatus = 0;
	if ( INVALID_HANDLE_VALUE == hindexOf) //No directory exist
			{
		return TRUE;
	} else {
		bContinueSearch = true;
		strFileName = QString::fromWCharArray(sindexOfData.cFileName);
	}
	//TDirectory found so we need to clean all the fiels and subfilders befire delete the directory
    foreach() {
        if (false == bContinueSearch)
            break;
		//Check the current file is not pointing to current Dir and parent dir files
        if ((0 != strFileName.CompareNoCase(".")) && (0 != strFileName.CompareNoCase(".."))) {
			if (sindexOfData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
				//Keys directory has one more sub directory 
				//Do not delete now.
				nDirStatus = 3; //Some error occured
			} else {
				QString strFilePath(strPath);
                strFilePath += "/";
				strFilePath += strFileName;
				// Set file attributes before trying to remove
				CFileStatus status;
				if (CStorage::GetStatus(strFilePath, status) == TRUE) {
					// Check if we need to remove the keyfile after use for one shot functions						
					status.m_attribute = 0x00;
					CStorage::SetStatus(strFilePath, status);
					// Remove the file
                    CStorage::remove(strFilePath);
					if (0 == nDirStatus)
						nDirStatus = 1;
					//else error occured for some other file or directory				
				} else {
					//Not able to get sttaus and delete the file ..may be no permisssions
					nDirStatus = 2; //Some error occured
				}
			}
		}
		//Move to next file
		if ( TRUE == CStorage::FindNextFile(hindexOf, &sindexOfData)) {
			strFileName = QString::fromWCharArray(sindexOfData.cFileName);
		} else //end of all files
		{
			//No more files in directory no more to search furhter
			bContinueSearch = false;
			DWORD dwErr = 0;
			dwErr = GetLastError();
			if (ERROR_NO_MORE_FILES != dwErr) {
				nDirStatus = 2; //Some error occured
			} else {
				if (0 == nDirStatus)
					nDirStatus = 1; //safe to remove directory
				//else error occured for some other file or directory
			}
			//close file handle
			
		}
	}
	if (1 == nDirStatus) {
		retValue = QDir rmdir(strPath);
	rmdir.removeRecursively();
		DWORD dwErr = 0;
		dwErr = GetLastError();
        OutputDebugString(("PSR: CSysInfo::RemoveKeysDirectory - removed successfully\n"));
	}
	return retValue;
}
//PSR Fix for PAR# 1-3N6VKTT - With an USB pen drive in recorder, when we click on [Prepare to Ship], then recorder is showing boot. end
//**********************************************************************
/// Generate a keyfile for IsFunctionAvailable that is encoded with
/// the password of the day to perform special functions such as factory resets etc..
///
/// @param[in]  pFileNamePrefix - prefix to identify encoded file
///
/// @return const QString  of encoded filename with relevant prefix
//**********************************************************************
const QString CSysInfo::GeneratePWEncodedFilename(QString pFileNamePrefix) {
	QString encodedFName = "";					///< Combined username and password
#ifndef TTR6SETUP
	WCHAR username[PWBD_USER_LEN + 1];	///< Holder for username
	WCHAR password[PWBD_PASS_LEN + 1];	///< Holder for password
	CPWBackCoder coder;					///< coder instance to generate code
	QDateTime st;						///< Time structure
	// Generate the encoded key name in format 
	// xxnnnnn.key where xx is the prefix and nnnnn is the password of the day
	GetV6LocalTime(&st);
	coder.Generate(GetSerialNumber(), st.wDay, st.wMonth, st.wYear % 1000, username, password);
	encodedFName = QString::asprintf("%s%s.key", pFileNamePrefix, password);
#endif
	return encodedFName;
}
//****************************************************************************
// const QString  GetStartupErrList( )
///
/// Methods that gets a copy of the startup error list
///
/// @return		A copy of the sdtartup error list
///
//**************************************************************************** 
const QString CSysInfo::GetStartupErrList() {
	m_SysInfoCS.lock();
	QString strTempCpy(m_strErrList);
	m_SysInfoCS.lock();
	return strTempCpy;
}
//****************************************************************************
// AddStartupErr( )
///
/// Methods that adds a startup error to the error list
/// @param[in]  str - startup error text
///
///
//**************************************************************************** 
void CSysInfo::AddStartupErr(LPCTSTR str) {
	m_SysInfoCS.lock();
	m_strErrList += str;
	m_strErrList += "|";
	m_SysInfoCS.lock();
}
//TM - Specifically added here so that unnecessary dialogs are not 
//included in the XSeries DLL Code
//****************************************************************************
// void WINAPI OptionsInitFunc (	QListView &rkStatusList,
//									QString  &rstrUserDefBtn1Title,
//									QString  &rstrUserDefBtn2Title )
///
/// Callback used to initialise the status list with the options code information
///
/// @param[out]			QListView &rkStatusList - The list control passed by reference
///	@param[out]			QString  &rstrUserDefBtn1Title - The title of the first user defined button
///	@param[out]			QString  &rstrUserDefBtn2Title - The title of the second user defined button
///
//****************************************************************************
void WINAPI OptionsInitFunc(QListView &rkStatusList, QString &rstrUserDefBtn1Title, QString &rstrUserDefBtn2Title) {
// enter critical section as necessary
	// resize the list control based on the new width
	QRect tWndRect;
	rkStatusList.tWndRect = rect();
	// subtract the horizontal scrollbar width
	USHORT usSBWidth = 0;
	USHORT usSBHeight = 0;
	pSYSTEM_INFO->pOemInfo->GetHorizSBDimensions(usSBHeight, usSBWidth);
	tWndRect.right -= usSBWidth;
	// Setup the generic titles
	QString strTitle("");
	strTitle = QWidget::tr("Options");
	rkStatusList.InsertColumn(0, strTitle, LVCFMT_LEFT, tWndRect.right / 2);
	strTitle = QWidget::tr("Credits");
	rkStatusList.InsertColumn(1, strTitle, LVCFMT_LEFT, tWndRect.right / 4);
	strTitle = QWidget::tr("Enabled");
	rkStatusList.InsertColumn(2, strTitle, LVCFMT_LEFT, tWndRect.right / 4);
	// now setup the insert the correct number of rows
	QString strCredits("");
	USHORT usNoOfCredits = 0;
	USHORT usEnabled = FALSE;
	QString strEnabled("");
	USHORT usRowCount = 0;
	for (USHORT usOptionsCount = 0; usOptionsCount < CSysInfo::fwoTotalCredits; usOptionsCount++) {
		usEnabled = pSYSTEM_INFO->GetOptionInfo(static_cast<CSysInfo::T_FIRMWARE_OPT>(usOptionsCount), strTitle,
				usNoOfCredits);
		// only add if a valid item
		if (strTitle != "") {
            rkStatusList.InsertItem(usRowCount, L"");
			rkStatusList.SetItemText(usRowCount, 0, strTitle);
			strCredits = QString::asprintf("%u", usNoOfCredits);
			//
			rkStatusList.SetItemText(usRowCount, 1, strCredits);
			// check if this is the extra pens option in which case we show a number
			if (static_cast<CSysInfo::T_FIRMWARE_OPT>(usOptionsCount) != CSysInfo::fwoExtraPens) {
				// check if this is the maths full block option which requires further checking
				if (static_cast<CSysInfo::T_FIRMWARE_OPT>(usOptionsCount) == CSysInfo::fwoMathsFullBlock) {
					// check if we have full script enabled in which case the credit option is not really relevant
					if ( pSYSTEM_INFO->FWOptionMathsType() == MATH_OPTION_FULL_SCRIPT) {
						// Set to NA and overwrite the number of credits cell
						strCredits = QWidget::tr("NA");
						rkStatusList.SetItemText(usRowCount, 1, strCredits);
					}
				}
				// not extra pens so just show the tick or cross
				strEnabled = QString::asprintf("%c", usEnabled ? g_wcTICK : g_wcCROSS);
			} else {
				// extra pens so show the number
				strEnabled = QString::asprintf("%u", usEnabled);
			}
			rkStatusList.SetItemText(usRowCount, 2, strEnabled);
			// increment the row count
			++usRowCount;
		}
	}
	// add password CFR
    rkStatusList.InsertItem(usRowCount, L"");
	strTitle = QWidget::tr("Password CFR");
	rkStatusList.SetItemText(usRowCount, 0, strTitle);
	strCredits = QWidget::tr("NA");
	rkStatusList.SetItemText(usRowCount, 1, strCredits);
	strEnabled = QString::asprintf("%c",
			( pSYSTEM_INFO->FWOptionPasswordCFRAvailable() == TRUE) ? g_wcTICK : g_wcCROSS);
	rkStatusList.SetItemText(usRowCount, 2, strEnabled);
	++usRowCount;
	// add SecureCommunication
    //rkStatusList.InsertItem( usRowCount, L"" );
	//strTitle = QWidget::tr("Secure Communication");
	//rkStatusList.SetItemText( usRowCount, 0, strTitle );
	//strCredits = QWidget::tr("NA");
	//rkStatusList.SetItemText( usRowCount, 1, strCredits );
    //strEnabled = QString::asprintf( "%c", ( pSYSTEM_INFO->FWOptionSecureCommAvailable() == TRUE )?g_wcTICK:g_wcCROSS );
	//rkStatusList.SetItemText( usRowCount, 2, strEnabled );
	//++usRowCount;
	/* TO BE ADDED ONCE THE CODE IS IMPLEMENTED
	 // add pasteurisation
     rkStatusList.InsertItem( usRowCount, L"" );
	 strTitle = QWidget::tr("Pasteurization");
	 rkStatusList.SetItemText( usRowCount, 0, strTitle );
	 rkStatusList.SetItemText( usRowCount, 1, strCredits );
     strEnabled = QString::asprintf( "%c", ( pSYSTEM_INFO->FWOptionPasteurisationAvailable() == TRUE )?g_wcTICK:g_wcCROSS );
	 rkStatusList.SetItemText( usRowCount, 2, strEnabled );
	 ++usRowCount;
	 */
	// finally add the total option
    rkStatusList.InsertItem(usRowCount, L"");
	strTitle = QWidget::tr("Total Credits");
	rkStatusList.SetItemText(usRowCount, 0, strTitle);
	pSYSTEM_INFO->ValidateFWOptions(CSysInfo::fwoNoneRequired, usNoOfCredits);
	T_PGENNONVOL ptFactory = pSYSTEM_INFO->GetFactoryConfig();
	strCredits = QString::asprintf("%u/%u", usNoOfCredits, ptFactory->Credits);
	rkStatusList.SetItemText(usRowCount, 1, strCredits);
	strEnabled = QWidget::tr("NA");
	rkStatusList.SetItemText(usRowCount, 2, strEnabled);
	rstrUserDefBtn1Title = "";
	rstrUserDefBtn2Title = "";
// leave critical section as necessary
}
//****************************************************************************
// Method	  : IsSecureWSDEnabled( )
// Description : Methods that return TRUE if WSD is enabled.
// Return	  : BOOL : TRUE/FALSE
//
//**************************************************************************** 
BOOL CSysInfo::IsSecureWSDEnabled() {
	BOOL bEnabled = FALSE;
	if (m_GeneralNVCfg.FWOptions.SecureWSD == 1) {
		bEnabled = TRUE;
	}
	return bEnabled;
}
//****************************************************************************
// Method	  : IsRecorderInSafeZone( )
// Description : Methods that return TRUE if Recorder in Safe Zone.
// Return	  : BOOL : TRUE/FALSE
//
//**************************************************************************** 
BOOL CSysInfo::IsRecorderInSafeZone() {
	BOOL bRet = TRUE;
	if (m_eRecSecZone != REC_SEC_ZONE_SAFE) {
		bRet = FALSE;
	}
	return bRet;
}
//****************************************************************************
// Method	  : SetRecSecurityZone( )
// Description : Methods that return TRUE if Recorder in Safe Zone.
// Return	  : BOOL : TRUE/FALSE
//
//**************************************************************************** 
void CSysInfo::SetRecSecurityZone(T_REC_SEC_ZONE eRecSecZone) {
	if (m_eRecSecZone != eRecSecZone) {
		m_eRecSecZone = eRecSecZone;
	}
}
//****************************************************************************
// Method	  : GetRecSecurityZone( )
// Description : Methods that return TRUE if Recorder in Safe Zone.
// Return	  : BOOL : TRUE/FALSE
//
//**************************************************************************** 
T_REC_SEC_ZONE CSysInfo::GetRecSecurityZone() {
	return m_eRecSecZone;
}
//****************************************************************************
// Method	  : GetUserInControl( )
// Description : Methods that return TRUE if Recorder in Safe Zone.
// Return	  : BOOL : TRUE/FALSE
//
//**************************************************************************** 
//BOOL CSysInfo::UserInFullMode()
//{
//			return UserIsInControl;
//}
//****************************************************************************
// Method	  : SetRemoteUserGotControl( )
// Description : 
// Return	  : BOOL : TRUE/FALSE
//
//**************************************************************************** 
void CSysInfo::SetRemoteUserGotControl(SHORT eRemoteUsrCntrl) {
	if (m_IsUserRemoteControl != eRemoteUsrCntrl) {
		m_PreviouslyRemoteUserInCntrl = m_IsUserRemoteControl;
		m_IsUserRemoteControl = eRemoteUsrCntrl;
	}
}
//****************************************************************************
// Method	  : GetRemoteUserControl( )
// Description : 
// Return	  : BOOL : TRUE/FALSE
//
//**************************************************************************** 
SHORT CSysInfo::GetRemoteUserControl() {
	return m_IsUserRemoteControl;
}
//****************************************************************************
// Method	  : PreviouslyRemoteUserInCntrl( )
// Description : 
// Return	  : BOOL : TRUE/FALSE
//
//**************************************************************************** 
SHORT CSysInfo::PreviouslyRemoteUserInCntrl() {
	return m_PreviouslyRemoteUserInCntrl;
}
BOOL CSysInfo::IsDataResetRequested() {
	T_DATA_RESET_TYPE eResetType = GetDataResetType();
	BOOL bDataReset;
	if (eResetType >= DATA_RESET_AUTO_SET) {
		bDataReset = TRUE;
	} else {
		bDataReset = FALSE;
	}
	return bDataReset;
}

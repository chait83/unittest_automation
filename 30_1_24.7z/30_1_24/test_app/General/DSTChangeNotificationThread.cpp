/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Time Tasks
/// @n Filename:  DSTChangeNotificationThread.cpp
/// @n Description: Implementation of the CDSTChangeNotificationThread class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  5 Stability Project 1.0.1.3 7/2/2011 4:56:58 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  4 Stability Project 1.0.1.2 7/1/2011 4:38:15 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  3 Stability Project 1.0.1.1 3/17/2011 3:20:22 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  2 Stability Project 1.0.1.0 2/22/2011 11:38:43 AM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented. (this is only for debug mode)
// $
//
// **************************************************************************
#include "DSTChangeNotificationThread.h"
#include "V6globals.h"
#include "TVtime.h"
#define FIRST_OF_MONTH 1
#define SECOND_OF_MONTH 2
#define THIRD_OF_MONTH 3
#define FOURTH_OF_MONTH 4
#define LAST_OF_MONTH  5
const int AccumDaysByMonth[13] = { 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365 };
/// Static Initialisation
CDSTChangeNotificationThread::T_DST_THREAD_STATE CDSTChangeNotificationThread::ms_eState =
        CDSTChangeNotificationThread::dstINIT;
/// The handle to the DST trigger event
QMutex CDSTChangeNotificationThread::ms_hEvent;
/////////////////////////////////////////////////////////////////////////////
// CDSTChangeNotificationThread
//****************************************************************************
// CDSTChangeNotificationThread()
///
/// Constructor
///
//****************************************************************************
CDSTChangeNotificationThread::CDSTChangeNotificationThread() {
}
//****************************************************************************
// ~CDSTChangeNotificationThread()
///
/// Destructor
///
//****************************************************************************
CDSTChangeNotificationThread::~CDSTChangeNotificationThread() {

}
//****************************************************************************
// BOOL InitInstance() 
///
/// Init Instance method
///
//****************************************************************************
BOOL CDSTChangeNotificationThread::InitInstance() {
	// TODO: perform and per-thread initialization here
	return TRUE;
}
//****************************************************************************
// int ExitInstance() 
///
/// Exit Instance method
///
//****************************************************************************
int CDSTChangeNotificationThread::ExitInstance() {
	// TODO: perform any per-thread cleanup here
	QThread::exit();
	return 0;
}
//****************************************************************************
// int GetStartDowForMonth(int yr, int mo)
///
/// indexOf the day of the week the indicated month begins on
///
//****************************************************************************
int CDSTChangeNotificationThread::GetStartDowForMonth(int yr, int mo) {
	int dow;
	// we want monday = 0, sunday = 6
	// dow = 6 + (yr - 1) + ((yr - 1) >> 2);
	dow = 5 + (yr - 1) + ((yr - 1) >> 2);
	if (yr > 1752)
		dow += ((yr - 1) - 1600) / 400 - ((yr - 1) - 1700) / 100 - 11;
	else if (yr == 1752 && mo > 9)
		dow -= 11;
	dow += AccumDaysByMonth[mo - 1];
	if (mo > 2 && (yr & 03) == 0 && (yr <= 1750 || yr % 100 != 0 || yr % 400 == 0))
		dow++;
	dow %= 7;
	return dow;
}
//****************************************************************************
// int DowFromDate(SYSTEMTIME *pst)
///
/// Determines the day of week based on information in a SYSTEMTIME struct
///
//****************************************************************************
int CDSTChangeNotificationThread::DowFromDate(SYSTEMTIME *pst) {
	int dow;
	assert(pst);
	dow = GetStartDowForMonth(pst->wYear, pst->wMonth);
	dow = (dow + pst->wDay) % 7;
	return dow;
}
//****************************************************************************
// const bool DST_DetermineChangeDate(	LPSYSTEMTIME pst, 
//										bool bTHIS_YEAR /* = false */ )
///
/// Method that determines the data at which the next daylight saving change is to occur - this 
/// may be going into or coming out of daylight saving
///
/// @param[in]			const TIME_ZONE_INFORMATION &rtTZ_INFO - The timezone information we need to inspect
///
///	@return		True if the configuration and local supports daylight saving
///
//****************************************************************************
const bool CDSTChangeNotificationThread::DST_DetermineChangeDate(LPSYSTEMTIME pst, bool bTHIS_YEAR /* = false */) {
	static BOOL bReEntered = FALSE;
	bool bRetval = false;
	const WORD wDAY = pst->wDay;
	assert(pst);
	if (NULL == pst)
		return bRetval;
	LONGLONG llChangeDate = 0, llNow = 0;
	// yes - February can have 29 days, but as of 6/01, no country changes dst in Feb, 
	// and certainly no one would change on the last day of February
	static const int lastDayOfMonth[12] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
	SYSTEMTIME st;
	GetLocalTime(&st);
	// build up the new structure
	if (pst->wYear == 0)
		pst->wYear = st.wYear;
	int tempExpectedWeek = pst->wDay;
	//look for daylight date
	switch (pst->wDay) {
	bRetval = true;
case FIRST_OF_MONTH:
case SECOND_OF_MONTH:
case THIRD_OF_MONTH:
case FOURTH_OF_MONTH: {
	//Day
	pst->wDay = 1; //
	int day = DowFromDate(pst);
	if (pst->wDayOfWeek >= day) { //If expected day is greater than returned day of week
		pst->wDay += pst->wDayOfWeek - day;
	} else {
		pst->wDay = (8 - day) + pst->wDayOfWeek;
	}
	pst->wDay += (tempExpectedWeek - 1) * 7; //This will take to second or 3rd or 4th Sunday/Monday/etc
	break;
}
case LAST_OF_MONTH: {
	//Day
	pst->wDay = lastDayOfMonth[pst->wMonth + 1];
	int day = DowFromDate(pst);
	if (pst->wDayOfWeek <= day) {
		pst->wDay = (pst->wDay - day) + pst->wDayOfWeek;
	} else {
		pst->wDay = (pst->wDay - day) - (7 - pst->wDayOfWeek);
	}
	break;
}
default:
	bRetval = FALSE;
	}
	// Need to determine if the next occurrance of this date is THIS year or NEXT year
	VERIFY(SystemTimeToFileTime(pst, (FILETIME*) &llChangeDate));
	VERIFY(SystemTimeToFileTime(&st, (FILETIME*) &llNow));
	//do we switch after Jan 1?
	if (!bTHIS_YEAR && !bReEntered && (llChangeDate < llNow)) {
		bReEntered = TRUE;
		//need to redetermine the date for next year
		pst->wYear++;
		// restore the day setting which may have been changed
		pst->wDay = wDAY;
		DST_DetermineChangeDate(pst);
	}
	bReEntered = FALSE;
	return bRetval;
}
//****************************************************************************
// const bool DaylightSavingRequired( const TIME_ZONE_INFORMATION &rtTZ_INFO )
///
/// Method that determines if the current configuration and locale supports DST
///
/// @param[in]			const TIME_ZONE_INFORMATION &rtTZ_INFO - The timezone information we need to inspect
///
///	@return		True if the configuration and local supports daylight saving
///
//****************************************************************************
const bool CDSTChangeNotificationThread::DaylightSavingRequired(const TIME_ZONE_INFORMATION &rtTZ_INFO) {
	bool bLocaleSupportsDST = false;
	// check the config is setup for DST too
	T_PGENNONVOL ptFactory = pSYSTEM_INFO->GetFactoryConfig();
	if (ptFactory->Localisation.DayLightSaving) {
		// If the month value is zero then this locale does not change for DST
		// it should never be the case that we have a DST date but not a SDT date
		assert(
				((0 != rtTZ_INFO.StandardDate.wMonth) && (0 != rtTZ_INFO.DaylightDate.wMonth))
						|| ((0 == rtTZ_INFO.StandardDate.wMonth) && (0 == rtTZ_INFO.DaylightDate.wMonth)));
		if ((0 != rtTZ_INFO.StandardDate.wMonth) && (0 != rtTZ_INFO.DaylightDate.wMonth)) {
			bLocaleSupportsDST = true;
		} else {
			bLocaleSupportsDST = false;
		}
	} else {
		// the configuration is not setup to support daylight saving
		bLocaleSupportsDST = false;
	}
	return bLocaleSupportsDST;
}
//****************************************************************************
// void ReInitialiseEvent( )
///
/// Method that signals to the thread a change of state is required
///
//****************************************************************************
void CDSTChangeNotificationThread::ReInitialiseEvent() {
	TIME_ZONE_INFORMATION tTZInfo;
	DWORD dwTime = GetTimeZoneInformation(&tTZInfo);
	ms_eState = dstINIT;
	if (ms_hEvent != NULL) {
		SetEvent(ms_hEvent);
	}
}
//****************************************************************************
// void ShutdownThread( )
///
/// Method that signals to the thread we are shutting down
///
//****************************************************************************
void CDSTChangeNotificationThread::ShutdownThread() {
	TIME_ZONE_INFORMATION tTZInfo;
//	DWORD dwTime = GetTimeZoneInformation(&tTZInfo);
	ms_eState = dstSHUTDOWN;
        /// TODO : indexOf alternative for SetEvent
    SetEvent(ms_hEvent);

}
//****************************************************************************
// const bool SetupNextDSTEvent( const bool bFIRST_TIME /* = false */ )
///
/// Method that setups the next daylight saving event
///
/// @param[in]			const bool bFIRST_TIME - Flag indicating this if the first time we have called 
///						this method
///
///	@return		True if the event was setup correctly
///
//****************************************************************************
const bool CDSTChangeNotificationThread::SetupNextDSTEvent(const bool bFIRST_TIME /* = false */) {
	bool bSetupEvent = false;
	HANDLE hEvent = NULL;
	bool bEvent = false;
	SYSTEMTIME tCurTime;
	SYSTEMTIME tNotificationTime;
	LONGLONG llNow = 0;
	LONGLONG llNotification = 0;
	TIME_ZONE_INFORMATION tTZInfo;
	DWORD dwTime = GetTimeZoneInformation(&tTZInfo);
	// check we are required to implement daylight saving
	if (DaylightSavingRequired(tTZInfo)) {
		// daylight saving is required, now determine if we are in standard or daylight saving time	
		switch (dwTime) {
		case TIME_ZONE_ID_DAYLIGHT:
			qDebug("DST - Currently in Daylight Time\r\n");
			tNotificationTime = tTZInfo.StandardDate;
			break;
		case TIME_ZONE_ID_STANDARD:
			qDebug("DST - Currently in Standard Time\r\n");
			tNotificationTime = tTZInfo.DaylightDate;
			break;
		default:
			qDebug("DST - Unknown TimeZone\r\n");
			assert(TIME_ZONE_ID_UNKNOWN == dwTime);  //otherwise GetTZInfo is busted
			return NULL;
		}
		if (0 == tNotificationTime.wYear) //no specific date set - do the math
				{
			DST_DetermineChangeDate(&tNotificationTime);
		}
		//only set events that are in the future
		VERIFY(SystemTimeToFileTime(&tNotificationTime, (FILETIME*) &llNotification));
		GetLocalTime(&tCurTime);
		VERIFY(SystemTimeToFileTime(&tCurTime, (FILETIME*) &llNow));
		if (llNotification > llNow) {
			//if( hEvent != INVALID_HANDLE_VALUE )
			{
				if (!CeRunAppAtTime(DSTNOTIFICATION, &tNotificationTime)) {
					/*
					 //No need to close the mutex in Qt
					 hEvent = NULL;
					 qDebug("DST - error setting up the event trigger time\r\n" );
					 */
				} else {
					bSetupEvent = true;
					// Yuvi - Added for testing
					/*QString  nextEventTime( "" );
					 nextEventTime = QString::asprintf("DST - Set TimeChange Event for %d/%d/%02d at %d:%02d\r\n", 
					 tNotificationTime.wDay, 
					 tNotificationTime.wMonth, 
					 tNotificationTime.wYear,
					 tNotificationTime.wHour, 
					 tNotificationTime.wMinute);
					 LOG_SYSTEM_MESSAGE( MSGLISTSER_SYSTEM_INFORMATION, nextEventTime );
					 */
					qDebug(L"DST - Set TimeChange Event for %d/%d/%02d at %d:%02d\r\n", tNotificationTime.wDay,
							tNotificationTime.wMonth, tNotificationTime.wYear, tNotificationTime.wHour,
							tNotificationTime.wMinute);
				}
			}
			/*
			 else
			 {
			 qDebug("DST - could not create event handle\r\n" );
			 }*/
		}
	}
	return bSetupEvent;
}
/**
 * @brief CDSTChangeNotificationThread::GetTimeZoneInformation
 * @param tTZInfo
 * @return
 */
DWORD CDSTChangeNotificationThread::GetTimeZoneInformation(TIME_ZONE_INFORMATION *tTZInfo) {
	/// TODO: Implement this function
}
/////////////////////////////////////////////////////////////////////////////
// CDSTChangeNotificationThread message handlers
//****************************************************************************
// UINT DSTChangeNotificationFunc(LPVOID lpParam)
///
/// Main thread function
///
//****************************************************************************
UINT CDSTChangeNotificationThread::DSTChangeNotificationFunc(LPVOID lpParam) {
	bool bFirstTime = true;
	ms_hEvent = NULL;
	DWORD dwWaitResult = 0;
	ms_eState = dstINIT;
#ifdef THREAD_ID_SERIAL_LOG
	  WCHAR szDbgMsg[512];
		swprintf( szDbgMsg, L"CDSTChangeNotificationThread::DSTChangeNotificationFunc-Thread id 0x%x, %lu ", GetThreadId(GetCurrentThread()), GetThreadId(GetCurrentThread()));
		OutputDebugString(szDbgMsg);
#endif
	// continue in this thread until the system is ordered to shutdown
	while (ms_eState != dstSHUTDOWN) {
		switch (ms_eState) {
		case dstRUNNING: {
			// check for the event occuring
			if (ms_hEvent != NULL) {
				dwWaitResult = ms_hEvent.tryLock(INFINITE);
				switch (dwWaitResult) {
				case WAIT_OBJECT_0:
					// check this has not been triggered because the time has just been changed
					// reset the event
					ResetEvent(ms_hEvent);
					if (ms_eState == dstRUNNING) {
						// need to call this method to update the RTC on the embedded platform
						CDeviceAbstraction *pkDal = pDEVICE_INFO->GetDalPtr();
						pkDal->SyncTime();
						pSYSTIMER->RegisterATimeChange();
						// set to reinitialise
						ms_eState = dstINIT;
						CeRunAppAtTime( DSTNOTIFICATION, NULL);
						// insert a sleep here so things settle down and the timezone function
						// reports the daylight saving mode correctly
						sleep(1000);
						QString strDSTChange("");
						TIME_ZONE_INFORMATION tTZInfo;
						DWORD dwTime = GetTimeZoneInformation(&tTZInfo);
						if (dwTime == TIME_ZONE_ID_DAYLIGHT) {
							strDSTChange = QString::asprintf("Recorder now operating in daylight saving time.");
						} else {
							strDSTChange = QString::asprintf("Recorder now operating in standard time");
						}
						LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_INFORMATION, strDSTChange);
					} else {
						// we have just triggered the DST event manually as
						// we want to change the state of this thread
						CeRunAppAtTime( DSTNOTIFICATION, NULL);
					}
					break;
				case WAIT_TIMEOUT:
					qDebug("DSTTimeChange timeout");
					break;
				case WAIT_ABANDONED:
					qDebug("DSTTimeChange abandoned");
					break;
				case WAIT_FAILED:
					qDebug("DSTTimeChange failed");
					break;
				default:
					qDebug("DSTTimeChange default");
					break;
				} // End of SWITCH 
			} else {
				// event is NULL therefore just sleep
				sleep(1000);
			}
		}
			break;
		case dstINIT: {
			if (SetupNextDSTEvent(bFirstTime)) {
				bFirstTime = false;
				ms_hEvent = OpenEvent(EVENT_ALL_ACCESS, FALSE, DSTEVENT);
			} else {
				// either there was a problem creating the event or no DST is required
				if (ms_hEvent != NULL) {
					//No need to close the mutex in Qt
					ms_hEvent = NULL;
					bFirstTime = true;
				}
			}
			ms_eState = dstRUNNING;
		}
			break;
		case dstSHUTDOWN:
		default:
			// set to shutdown if not already so
			ms_eState = dstSHUTDOWN;
			break;
		}
	}
    CeRunAppAtTime( DSTNOTIFICATION, NULL);
	return 0;
}

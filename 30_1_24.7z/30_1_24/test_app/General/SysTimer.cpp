/// @file
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	General
/// @n Filename: SysTimer.cpp
/// @n Desc:	Routines to V6 specific system timing
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 50	Stability Project 1.45.1.3	7/2/2011 5:01:58 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 49	Stability Project 1.45.1.2	7/1/2011 4:39:00 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 48	Stability Project 1.45.1.1	3/17/2011 3:20:49 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 47	Stability Project 1.45.1.0	2/15/2011 3:04:01 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
// ****************************************************************
#include "V6globals.h"
#include "V6ResourceBase.h"
#include "V6UIResource.h"
////PSR - SNTP fix begin
#ifdef UNDER_CE
#include "Service.h"
#include "Devload.h" 
#endif
#include "Registry.h"
//PSR - SNTP fix end
/// @note processing time slices are calculated in 1/100ths of a seconds but all internals
///	in this module are calculated in Microseconds 1/1,000,000ths of a second
#define CONVERT_100_TO_SEC(a)		( a / 100 )		///< convert processing ticks speed 1/100ths to Seconds
#define CONVERT_100_TO_MICROS(a)	( a * 10000 )	///< convert processing ticks speed 1/100ths to MicroSeconds 1/1,000,000
#define CONVERT_MICROS_TO_100(a)	( a / 10000 )	///< convert MicroSends into processing ticks
#define RTC_CLOCK_RATE		100000
#define RTC_ADDRESS					0x6F
#define RTC_RD_MSG_LENGTH			7		//7 bytes from RTC Chip
#define RTC_WR_MSG_LENGTH			8		//9 bytes to RTC Chip
#define CENTURY_IN_USE			2000		
#define SECOND_INDEX	0
#define MINUTE_INDEX	1
#define HOUR_INDEX		2
#define DAY_INDEX		3
#define DATE_INDEX		4
#define MONTH_INDEX		5
#define YEAR_INDEX		6
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
CV6SystemTimer *CV6SystemTimer::m_pV6SystemTimerInstance = NULL;
QMutex m_CreationMutex;
const ULONG MILLISECONDS_PER_TICK = 1000 / PROCESS_TICKS_PER_SECOND; // Milliseconds per Tick (10)
const ULONG FASTEST_DATA_PROCESSING_MSEC = 100;	// delay in Msec for the max data processing rate (10 times a sec)
#ifdef DBG_FILE_LOG_SYSTIMER_ENABLE
CDebugFileLogger CV6SystemTimer::m_debugFileLogger(L"\\SDMemory\\SYSTimer.txt",
FALSE, (10 * 1024 * 1024));
QString strLog;
QString strTime;
#endif
//**********************************************************************
/// CV6SystemTimer constructor
///
//**********************************************************************
CV6SystemTimer::CV6SystemTimer() : m_baseSysTimerMicroS(TIMER_NORMAL_RES) //(MarkD)
		//CV6SystemTimer::CV6SystemTimer( ) : m_baseSysTimerMicroS(TIMER_HIGH_RES)
#ifdef DBG_FILE_LOG_SYSTIMER_ENABLE
		, m_pDebugFileLogger(&m_debugFileLogger)
#endif
{
	SetProcessInterval(10);		// Set process interval to 10Hz
	QMutex * m_SysTimerCS;
	QMutex * m_SyncRTCCS;
	m_processTimeInSeconds = 0;
	ClearTimeHasChanged();
	m_UncoordinatedTimeChange = FALSE;
	//m_allowTimeAdjustment = FALSE;	//MarkD
	m_LastTimeOffInSeconds = 0;
	m_DataProcessingIntervalsleep = FASTEST_DATA_PROCESSING_MSEC;		// Defualt data processing sleep
	CTVtime::ms_pkCurrProcessTimeRef = &GetCurrentProcessTimeRef();
	bForceRTCSync = false;
	bUserTriggeredTimeChange = false;
	m_syncNextTime = false;
}
//**********************************************************************
///
/// Instance creation of CV6SystemTimer singleton
///
/// @return		pointer to single instance of CV6SystemTimer
///
//**********************************************************************
CV6SystemTimer* CV6SystemTimer::GetHandle() {
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;
	if (NULL == m_pV6SystemTimerInstance) {
		// An instance has yet to be completed
		waitSingleObjectResult = m_CreationMutex.tryLock(g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);
		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:
			// Object was signaled
			if (NULL == m_pV6SystemTimerInstance) {
				m_pV6SystemTimerInstance = new CV6SystemTimer;
			}
			if ( FALSE == m_CreationMutex.unlock())
				V6WarningMessageBox(NULL, L"Failed to release SYSTIMER mutex", L"Error", MB_OK);
			break;
		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
			V6WarningMessageBox(NULL, L"SYSTIMER WaitForSingleObject Error", L"Error", MB_OK);
			break;
		}
		// Close the Mutex as no longer required
		//No need to close the mutex in Qt
	}
	return (m_pV6SystemTimerInstance);
}
//**********************************************************************
///
/// Deletes the instance of the singleton from memory
///
/// @return		Nothing
///
//**********************************************************************
void CV6SystemTimer::CleanUp() {
	//deletion of mutex not required
	delete m_pV6SystemTimerInstance;
	m_pV6SystemTimerInstance = NULL;
	// clean up time history singleton
	CTimeHistory *pTh = CTimeHistory::GetHandle();
	pTh->CleanUp();
}
//**********************************************************************
///
/// Initialise the System timers, create initial baseline
///
/// @return		Nothing
///
//**********************************************************************
void CV6SystemTimer::Initialise() {
	// Baseline the current system tick and the current time
	m_baseSysTimerMicroS.StartTimer();
	m_baseRealTime.TimeNow();
	m_powerOnTime = m_baseRealTime;
	// Current processing tick starts at 0, and will follow the elapsed time of
	// the m_baseSysTimerMicroS timer, in steps of m_processInterval100
	// m_currProcessTime will be also be incremented using same process
	// to derive an accurate real world time for the m_currProcessTick100
	m_currProcessTick100 = 0;
	m_currProcessTime = m_baseRealTime;
	m_OnGoingProcessTick100.ll = 0;	// OnGoing timer default, this will be loaded from SRAM.
	m_baseOngoingTick = 0;
	// Get handle on NV varaible in SRAM and load up last good readings
	m_pOnGoingTimerNV = pNV_VARS->GetBasic8TimeNVObject(NVV_OGREALTIME);
	LONGLONG oldTime = m_pOnGoingTimerNV->GetFromNV()->time;
	LONGLONG oldTick = m_pOnGoingTimerNV->GetFromNV()->value.ll;
	//MarkD: always update m_OnGoingProcessTick100
	m_OnGoingProcessTick100.ll = oldTick;	// continue where it stopped
	m_baseOngoingTick = m_OnGoingProcessTick100.ll;
	CTimeHistory *pTh = CTimeHistory::GetHandle();
	// Is the m_OnGoingProcessTick100 zero? (first time run or after NV reset)
	if (m_OnGoingProcessTick100.ll == 0) {
		pTh->ResetHistory();	// wipe the history file and table (if they exist) and start again.
		oldTime = m_baseRealTime.GetMicroSecs();	// Set oldtime to first use on power on.
	} else {
		// Obtain the latest entry from the table
		TableEntry *pLatest = pTh->GetEntry(LATEST_ENTRY);
		if (!pLatest || (pLatest->Tick100 > m_OnGoingProcessTick100.ll)) {
			// this should never happen. Table is out of sync with m_OnGoingProcessTick100
			pTh->ResetHistory(); // wipe the history file and table (if they exist) and start again.
		}
	}
	AddTimeHistoryStartEntry(pTh);		// Add time history startup entry
	m_currProcessTime.GetTV5Time(&m_currProcessTimeTV5);	// Convert a TV5Time
	LONGLONG timeDiff = m_baseRealTime.GetMicroSecs() - oldTime;
	///PSR - SNTP begin
	if (timeDiff != 0) {
		m_LastTimeOffInSeconds = (int) USEC_TO_SEC(timeDiff);
		if (m_LastTimeOffInSeconds < 0) {
			m_LastTimeOffInSeconds *= -1;	///Make it positive value insted of zero
		}
	}
	///PSR - SNTP end
	// Update the Life history status
	m_pNVLithiumLifeInSeconds = pNV_VARS->GetBasicVarNVObject(NVV_LITHIUM_LIFE);
	m_pNVOffTimeInSeconds = pNV_VARS->GetBasicVarNVObject(NVV_TOTAL_TIME_OFF);
	m_pNVLongestTimeOffInSeconds = pNV_VARS->GetBasicVarNVObject(NVV_MAX_TIME_OFF);
	// Set the longest time off in seconds
	m_LongestTimeOffInSeconds = m_pNVLongestTimeOffInSeconds->GetFromNV()->value;
	if (m_LongestTimeOffInSeconds.ul < m_LastTimeOffInSeconds) {
		m_LongestTimeOffInSeconds.ul = m_LastTimeOffInSeconds;
	}
	m_pNVLongestTimeOffInSeconds->SetToNV(m_LongestTimeOffInSeconds);
	// Add the off time to the lithium cell calc (can be reset)
	m_LithiumLifeInSeconds = m_pNVLithiumLifeInSeconds->GetFromNV()->value;
	m_LithiumLifeInSeconds.ul += m_LastTimeOffInSeconds;
	m_pNVLithiumLifeInSeconds->SetToNV(m_LithiumLifeInSeconds);
	// Add the off to to the running off time
	m_OffTimeInSeconds = m_pNVOffTimeInSeconds->GetFromNV()->value;
	m_OffTimeInSeconds.ul += m_LastTimeOffInSeconds;
	m_pNVOffTimeInSeconds->SetToNV(m_OffTimeInSeconds);
	SetDataItemTimeCount();
	//PSR -SNTP fix begin
#ifdef UNDER_CE
  LoadSNTP();
#endif
	//PSR -SNTP fix end
}
//**********************************************************************
/// Update the processing time slice and all associated times and ticks
///
/// @param[in]	timeIn100 - tick time to be added
///
/// @return		Nothing
///
//**********************************************************************
void CV6SystemTimer::UpdateProcessTimeSlice(LONGLONG timeIn100) {
	m_SysTimerCS.lock();
	m_OnGoingProcessTick100.ll += timeIn100;	// Adjust ongoing process tick
	// Update current process ticks
	m_currProcessTick100 += timeIn100;					// Adjust process Tick
	m_currProcessTime += CONVERT_100_TO_MICROS(timeIn100);					// Adjust process Time
	m_currProcessTime.GetTV5Time(&m_currProcessTimeTV5);	// Convert a TV5Time
	// Get new elapsed process time in seconds
	m_processTimeInSeconds = (float) CONVERT_100_TO_SEC((float )m_currProcessTick100);// Pre-calc elapsed process time in seconds
	// Update on going process time for Data Item table access
	SetDataItemTimeCount();
	// Store current OnGoing process and real-time into NV
	m_pOnGoingTimerNV->SetToNV(m_OnGoingProcessTick100, m_currProcessTime.GetMicroSecs());
	m_SysTimerCS.lock();
}
//**********************************************************************
/// Set processing tick and time to an absolute time slice
///
/// @param[in]	absoluteTimeIn100 - absolute timeslice required in 100 of a second
///
/// @return		Nothing
///
//**********************************************************************
void CV6SystemTimer::SetAbsoluteProcessTimeSlice(LONGLONG absoluteTimeIn100) {
	// Calculate required adjustment from absolute time
	LONGLONG timeDiff = absoluteTimeIn100 - m_currProcessTick100;
	// only handles positive increments
	if (timeDiff > 0) {
		UpdateProcessTimeSlice(timeDiff);
	}
}
//**********************************************************************
///
/// Update the current processing time slice to next driven by the current
/// update interval
///
/// @return		Nothing
///
//**********************************************************************
void CV6SystemTimer::UpdateToNextProcessingTimeSlice() {
	UpdateProcessTimeSlice(m_processInterval100);
	CoordinateTimeChangeIfRequired();
}
#define	WINDOWS_TIMER_RES	1	// was 100 for 1 second increments, but performance of correction
// is believed to be better set to 1
//**********************************************************************
/// Get the current system time tick in 1/100ths of a second
/// This is elapsed time since start-up
///
/// @return	time tick in 1/100ths
///
//**********************************************************************
const LONGLONG CV6SystemTimer::GetCurrentSystemTimeTick100() {
	m_SysTimerCS.lock();
	LONGLONG currTick;
	currTick = CONVERT_MICROS_TO_100(m_baseSysTimerMicroS.ElapsedTimeInMicroSeconds());
	m_SysTimerCS.lock();
	return (currTick);	// up to date adjusted tick
}
//**********************************************************************
/// Gets the High resolution version of the Ongoing Tick (increments smoothly by small amounts)
/// This is also not real time, it's just total processed time
///
/// @return	time tick in 1/100ths
///
//**********************************************************************
const LONGLONG CV6SystemTimer::GetHighResOnGoingTick100() {
	LONGLONG currTick;
	currTick = GetCurrentSystemTimeTick100();	// get time since power-on, synced to windows time
	return (currTick + m_baseOngoingTick);	// add base time
}
//**********************************************************************
/// Set the process interval in 1/100ths os a second, this is the granularity
/// of each processing pass.
///
/// @param[in]	timeIn100 - new processing interval in 1/100ths of a sec
///
/// @return	nothing
///
//**********************************************************************
void CV6SystemTimer::SetProcessInterval(ULONG timeIn100) {
	m_processInterval100 = timeIn100;
	m_processSlicesSec = PROCESS_TICKS_PER_SECOND / m_processInterval100;
	// Calculate the sleep interval, for dataprocessing, restrict it to 10 times a second
	// as even with 50 Hz data the AI won't feed quickly enough
	m_DataProcessingIntervalsleep = m_processInterval100 * MILLISECONDS_PER_TICK;
	if (m_DataProcessingIntervalsleep < FASTEST_DATA_PROCESSING_MSEC) {
		m_DataProcessingIntervalsleep = FASTEST_DATA_PROCESSING_MSEC;
	}
}
//**********************************************************************
/// Provides the time in 1/100ths of the current processing time
/// and the actual system time
///
/// @return	Number of timeslice between process time and system
///
//**********************************************************************
const long CV6SystemTimer::TimeSlicesBetweenProcAndRealtime100() {
	long sliceDiff;
	m_SysTimerCS.lock();
	sliceDiff = (long) ( CONVERT_MICROS_TO_100(
			m_baseSysTimerMicroS.ElapsedTimeInMicroSeconds()) - m_currProcessTick100);
	m_SysTimerCS.lock();
	return sliceDiff;
}
//**********************************************************************
/// Number of Seconds since Power on in real time returned as a floating point value
/// for use within Maths block if required.
///
/// @return	Time since startup in seconds as a float value
///
//**********************************************************************
const float CV6SystemTimer::GetElapsedRealTimeInSeconds() {
	m_SysTimerCS.lock();
	float secSincePowerOn = (float) USEC_TO_SEC((double )m_baseSysTimerMicroS.ElapsedTimeInMicroSeconds());
	m_SysTimerCS.lock();
	return secSincePowerOn;
}
//**********************************************************************
/// Get the current Process time as a LONGLONG in uSec
///
/// @return	Process time in uSec
///
//**********************************************************************
const LONGLONG CV6SystemTimer::GetCurrentProcessTimeInMicroSec() {
	LONGLONG timeInMicroSeconds;
	m_SysTimerCS.lock();
	timeInMicroSeconds = m_currProcessTime.GetMicroSecs();
	m_SysTimerCS.lock();
	return timeInMicroSeconds;
}
//**********************************************************************
/// Register a time change, the current time is the new time(TimeNow), so
/// we need to adjust the process realtime and
///
/// @return		True if the time was modified
///
//**********************************************************************
const int CV6SystemTimer::RegisterATimeChange(bool bSyncTime) {
	bool bTimeModified = false;
	static __int64 timediff = 0;
	QDateTime tCurrTime;
	m_SysTimerCS.lock();
	if (true == bSyncTime) {
		if (false == bUserTriggeredTimeChange) {
			if (timediff != 0) {
				QDateTime tModifyTime;
				int Correction = 0;
				if (timediff > 0) {
					Correction = 2; //ext is ahead
				} else {
					Correction = -2;
				}
				// Adjust the process time and base realtime
				m_currProcessTime.GetSYSTEMTIME(&tModifyTime);
				if (tModifyTime.wMilliseconds < 20 || tModifyTime.wMilliseconds > 980) //To skip boundary condition
						{
					sleep(100);
					m_currProcessTime.GetSYSTEMTIME(&tModifyTime);
					if (tModifyTime.wMilliseconds < 20 || tModifyTime.wMilliseconds > 980) //To skip boundary condition
							{
						strTime = QString::asprintf("B: Day %d Mon %d %d:%d:%d:%d"), tModifyTime.wDay, tModifyTime.wMonth, tModifyTime.wHour, tModifyTime.wMinute, tModifyTime.wSecond, tModifyTime.wMilliseconds
						);
						LogDebugMessage(strTime);
						m_SysTimerCS.lock();
						return timediff;
					}
				}
				tModifyTime.wMilliseconds += Correction;
				m_currProcessTime.SYSTEMTIMEtoInternal(tModifyTime);
				//m_baseRealTime= m_currProcessTime;
				// Update the TV5Time used in logging to the latest time
				m_currProcessTime.GetTV5Time(&m_currProcessTimeTV5); // Convert a TV5Time
				// add an entry to the Time History Table/file
				CTimeHistory *pTh = CTimeHistory::GetHandle();
				pTh->AddEntry(m_OnGoingProcessTick100.ll, m_currProcessTime);
				// Preserve the last process time
				m_PreTimeChangeProcessTime = m_currProcessTime;
				if (timediff > 0) {
					timediff = timediff - 2;
				} else {
					timediff = timediff + 2;
				}
				if (0 == timediff) {
					strTime = QString::asprintf("Correc Day %d Mon %d %d:%d:%d:%d"), tModifyTime.wDay, tModifyTime.wMonth, tModifyTime.wHour, tModifyTime.wMinute, tModifyTime.wSecond, tModifyTime.wMilliseconds
					);
					LogDebugMessage(strTime);
				}
			} else {
				// Get the new time in a CTVtime format so we can perform some calculations
				CTVtime currTime;
				SYSTEMTIME tCurrentTime, tExternalTime, tGetLocalTime;
				int timeDifference = 0, timeTest = 0, currSecs = 0, extSecs = 0;
				GetV6LocalTime(&tCurrentTime);
				if (!ReadExternalRtcTime(&tExternalTime)) {
					strTime = QString::asprintf("i2c Comm Failed!")
					);
					LogDebugMessage(strTime);
					m_SysTimerCS.lock();
					return timediff;
				}
				//// Get the time adjustment required to the realtime
				if (tCurrentTime.wDay == tExternalTime.wDay) {
					if (tCurrentTime.wHour != tExternalTime.wHour) {
						currSecs = (tCurrentTime.wHour * 60 * 60);
						extSecs = (tExternalTime.wHour * 60 * 60);
					}
					if (tCurrentTime.wMinute != tExternalTime.wMinute) {
						currSecs += (tCurrentTime.wMinute * 60);
						extSecs += (tExternalTime.wMinute * 60);
					}
					timeDifference = (extSecs + tExternalTime.wSecond) - (currSecs + tCurrentTime.wSecond);
					if ((timeDifference > TIMESYNC_THRESHOLD_SEC) || (timeDifference < -TIMESYNC_THRESHOLD_SEC)) {
						if (timeDifference > 0) {
							timeDifference = timeDifference - 1;
						} else {
							timeDifference = timeDifference + 1;
						}
						timediff = timeDifference * 1000; //Convert to milliseconds
						strTime = QString::asprintf("timediff %d", timediff);
						LogDebugMessage(strTime);
						strTime =
								QString::asprintf(
										"diff %d Curr H: %d M: %d S: %d ms: %d Day %d Mon %d | Ext H: %d M: %d S: %d Day %d Mon %d",
										tCurrentTime.wHour, tCurrentTime.wMinute, tCurrentTime.wSecond,
										tCurrentTime.wMilliseconds, tCurrentTime.wDay, tCurrentTime.wMonth,
										tExternalTime.wHour, tExternalTime.wMinute, tExternalTime.wSecond,
										tExternalTime.wDay, tExternalTime.wMonth);
						LogDebugMessage(strTime);
					} else {
						strTime =
								QString::asprintf(
										"Nodiff Curr H: %d M: %d S: %d ms: %d Day %d Mon %d | Ext H: %d M: %d S: %d Day %d Mon %d",
										tCurrentTime.wHour, tCurrentTime.wMinute, tCurrentTime.wSecond,
										tCurrentTime.wMilliseconds, tCurrentTime.wDay, tCurrentTime.wMonth,
										tExternalTime.wHour, tExternalTime.wMinute, tExternalTime.wSecond,
										tExternalTime.wDay, tExternalTime.wMonth);
						LogDebugMessage(strTime);
					}
				} else {
					strTime = QString::asprintf(
					"Day not match! Curr H: %d M: %d S: %d ms: %d Day %d Mon %d | Ext H: %d M: %d S: %d Day %d Mon %d"), tCurrentTime.wHour, tCurrentTime.wMinute, tCurrentTime.wSecond, tCurrentTime.wMilliseconds, tCurrentTime.wDay, tCurrentTime.wMonth, tExternalTime.wHour, tExternalTime.wMinute, tExternalTime.wSecond, tExternalTime.wDay, tExternalTime.wMonth
					);
					LogDebugMessage(strTime);
				}
			}
		}
		m_SysTimerCS.lock();
		return timediff;
	}
	timediff = 0;	//New time set by user, setting time diff zero
	// Get the new time in a CTVtime format so we can perform some calculations
	CTVtime currTime;
	currTime = m_baseRealTime;
	currTime += m_baseSysTimerMicroS.ElapsedTimeInMicroSeconds();	// Add microseconds
	// Get the current time now in CTVtime format
	CTVtime newTime;
	newTime.TimeNow(false);
	// Get the time adjustment required to the realtime
	m_timeAdjustment = newTime - currTime;
	// only do a time change if greater than the time threshold, avoids lots of small changes on SNTP
	if ((m_timeAdjustment.GetMicroSecs() > TIMECHANGE_THRESHOLD_USEC)
			|| (m_timeAdjustment.GetMicroSecs() < -TIMECHANGE_THRESHOLD_USEC)) {
		// Register that a time change has been performed, next step is to coordinate it
		m_UncoordinatedTimeChange = TRUE;
		// Build up a string of old and new times and dates, store to be output as a system message
		QString strNewTime, strNewDate, strOldTime, strOldDate;
		newTime.ShortTimeAsString(strNewTime);
		newTime.DateAsString(strNewDate);
		currTime.ShortTimeAsString(strOldTime);
		currTime.DateAsString(strOldDate);
		// Build Up date change
		QString strTimeChangeasprintf;
		strTimeChangeasprintf = tr("Time Changed from %s %s to %s %s");
		m_strTimeChange = QString::asprintf(strTimeChangeasprintf, strOldTime, strOldDate, strNewTime, strNewDate);
		qDebug("%s\n ", m_strTimeChange);
		bTimeModified = true;
	} else {
		pGlbSysTimer->bUserTriggeredTimeChange = false;
		qDebug(" Time change ignored as only %d seconds out\n", (int) USEC_TO_SEC(m_timeAdjustment.GetMicroSecs()));
	}
	bForceRTCSync = false;
	m_SysTimerCS.lock();
	return bTimeModified;
}
//**********************************************************************
/// Coordinate a time change if one has been set
///
//**********************************************************************
void CV6SystemTimer::CoordinateTimeChangeIfRequired() {
	// if a uncoordinated time change is pending, then change the process times
	// and flags that the next process slice will change time
	if (m_UncoordinatedTimeChange == TRUE) {
		m_SysTimerCS.lock();	//**** Enter critical section
		// Set flag to indicate to process thread that a time change has occured
		StartTimeHasChanged();
		// Adjust the process time and base realtime
		m_currProcessTime += m_timeAdjustment;
		m_baseRealTime += m_timeAdjustment;
		m_SysTimerCS.lock();	//**** Leave critical section
		// Update the TV5Time used in logging to the latest time
		m_currProcessTime.GetTV5Time(&m_currProcessTimeTV5);	// Convert a TV5Time
		// add an entry to the Time History Table/file
		CTimeHistory *pTh = CTimeHistory::GetHandle();
		pTh->AddEntry(m_OnGoingProcessTick100.ll, m_currProcessTime);
		// Preserve the last process time
		m_PreTimeChangeProcessTime = m_currProcessTime;
		pGlbSysTimer->m_SyncRTCCS.lock();
		pGlbSysTimer->bUserTriggeredTimeChange = false;
		pGlbSysTimer->m_SyncRTCCS.lock();
		LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_INFORMATION, m_strTimeChange);	// Log time changed message
	} else {
		ClearTimeHasChanged();
	}
}
//**********************************************************************
/// CheckTime() will return whether the recorder is operating in DST/SDT 
/// with the passed in QDateTime and TIMEZONE information
/// 
///
/// @return		DWORD with value equals DST/SDT
///
//**********************************************************************
DWORD CV6SystemTimer::CheckTime(QDateTime sysTime, TIME_ZONE_INFORMATION tzi) {
	LONGLONG llStandard = 0, llDaylight = 0, llNow = 0;
	DWORD dwResult = TIME_ZONE_ID_UNKNOWN;
	//fix up the date structs if necessary
	if (0 == tzi.StandardDate.wYear)
		DST_DetermineChangeDate(&tzi.StandardDate, TRUE);
	if (0 == tzi.DaylightDate.wYear)
		DST_DetermineChangeDate(&tzi.DaylightDate, TRUE);
	//convert so we can do the math
	VERIFY(SystemTimeToFileTime(&tzi.StandardDate, (FILETIME*) &llStandard));
	VERIFY(SystemTimeToFileTime(&tzi.DaylightDate, (FILETIME*) &llDaylight));
	VERIFY(SystemTimeToFileTime(&sysTime, (FILETIME*) &llNow));
	/*if( &sysTime )
	 {
	 LONGLONG llNowLocal;
	 FileTimeToLocalFileTime((FILETIME *)&llNow, (FILETIME *)&llNowLocal);
	 llNow = llNowLocal;
	 }*/
	//the greater difference determines which zone we are in
	if (DST_Auto()
			&& ((llDaylight <= llStandard && llDaylight <= llNow && llNow <= llStandard)
					|| (llDaylight > llStandard && (llDaylight <= llNow || llNow <= llStandard)))) {
		dwResult = TIME_ZONE_ID_DAYLIGHT;
	} else {
		dwResult = TIME_ZONE_ID_STANDARD;
	}
	return dwResult;
}
//**********************************************************************
/// LocaleSupportsDST() will return whether the recorder's locale supports 
/// DST by passing in TIMEZONE information
/// 
/// See Also: CheckTime()
///
/// @return		true or false
///
//**********************************************************************
BOOL CV6SystemTimer::LocaleSupportsDST(TIME_ZONE_INFORMATION *ptzi) {
	assert(ptzi);
	// If the month value is zero then this locale does not change for DST
	// it should never be the case that we have a DST date but not a SDT date
	assert(
			((0 != ptzi->StandardDate.wMonth) && (0 != ptzi->DaylightDate.wMonth))
					|| ((0 == ptzi->StandardDate.wMonth) && (0 == ptzi->DaylightDate.wMonth)));
	if ((0 != ptzi->StandardDate.wMonth) && (0 != ptzi->DaylightDate.wMonth))
		return TRUE;
	else
		return FALSE;
}
//**********************************************************************
/// DST_DetermineChangeDate() will calculate the next chnage over date 
/// either from DST to SDT or vice-a-versa
/// 
/// See Also: CheckTime()
///
/// @return		true or false
///
//**********************************************************************
BOOL CV6SystemTimer::DST_DetermineChangeDate(LPSYSTEMTIME pStTzChange, BOOL fThisYear) {
	LONGLONG llChangeDate = 0, llNow = 0;
	SYSTEMTIME stAbsolute; // Conversion from pStTzChange
	QDateTime stNow; // Current time
	assert((pStTzChange->wDay >= 1) && (pStTzChange->wDay <= 5));
	memcpy(&stAbsolute, pStTzChange, sizeof(stAbsolute));
	GetLocalTime(&stNow);
	// build up the new structure
	if (stAbsolute.wYear == 0) {
		pStTzChange->wYear = stAbsolute.wYear = stNow.wYear;
	}
	// Day of week [Sun-Sat] the first day of week falls on
	WORD wFirstDayInMonth = GetFirstWeekDayOfMonth(&stAbsolute);
	// First day in month [1-7] that is on same day of week as timezone change
	WORD wFirstDayTZChange;
	// Determine the first date in this month that falls on the day of
	// the week that the time zone change will happen on, eg
	// first Monday in June 2006 would get wFirstDayTZChange=5.
	if (wFirstDayInMonth > pStTzChange->wDayOfWeek)
		wFirstDayTZChange = (1 + 7 - (wFirstDayInMonth - pStTzChange->wDayOfWeek));
	else
		wFirstDayTZChange = 1 + pStTzChange->wDayOfWeek - wFirstDayInMonth;
	assert((wFirstDayTZChange >= 1) && (wFirstDayTZChange <= 7));
	stAbsolute.wDay = wFirstDayTZChange;
	for (DWORD i = 1; i < pStTzChange->wDay; i++) {
		FILETIME ftTemp;
		// Increment the current week by one, and see if it's a legit date.
		// SystemTimeToFileTime has all the logic to determine if the SystemTime
		// is correct - if it's not in means we've "overshot" the intended date
		// and need to pull back on. Consider for instance if the TZ Cutover
		// was set to be 5th Thursday in July 2006. Eventually in this loop
		// we would get to July 34th, which is bogus, so we'd need to pull
		// back to July 27th.
		stAbsolute.wDay += 7;
		if (!SystemTimeToFileTime(&stAbsolute, &ftTemp)) {
			// We overshot, pull back a week
			stAbsolute.wDay -= 7;
			break;
		}
	}
	// Need to determine if the next occurrance of this date is THIS year or NEXT year
	VERIFY(SystemTimeToFileTime(&stAbsolute, (FILETIME*) &llChangeDate));
	VERIFY(SystemTimeToFileTime(&stNow, (FILETIME*) &llNow));
	// In this case, the change-over date was calculated to be in the past.
	// Sometimes this is what we want, othertimes (like when setting up an event
	// to be fired in future) we need to re-perform this calculation so that we
	// get a date in the future.
	if (!fThisYear && (llChangeDate < llNow)) {
		//need to redetermine the date for next year
		pStTzChange->wYear++;
		return DST_DetermineChangeDate(pStTzChange, TRUE);
	}
	memcpy(pStTzChange, &stAbsolute, sizeof(stAbsolute));
	return TRUE;
}
//**********************************************************************
/// GetFirstWeekDayOfMonth() used in calculating the next change over date 
/// either from DST to SDT or vice-a-versa
/// 
/// See Also: CheckTime(), DST_DetermineChangeDate()
///
/// @return		WORD, first day of the week
///
//**********************************************************************
WORD CV6SystemTimer::GetFirstWeekDayOfMonth(LPSYSTEMTIME pst) {
	SYSTEMTIME st;
	FILETIME ft;
	memcpy(&st, pst, sizeof(st));
	st.wDayOfWeek = 0;
	st.wDay = 1;
	// Convert to FILETIME and then back to QDateTime to get this information.
	SystemTimeToFileTime(&st, &ft);
	FileTimeToSystemTime(&ft, &st);
	assert((st.wDayOfWeek >= 0) && (st.wDayOfWeek <= 6));
	return st.wDayOfWeek;
}
//**********************************************************************
/// DST_Auto() checks the registry entry for the DST Auto flag
/// The valus of the Auto flag should be set to 1
/// 
/// See Also: CheckTime()
///
/// @return		true or false.
///
//**********************************************************************
BOOL CV6SystemTimer::DST_Auto(void) {
	DWORD ret = 0;
	HKEY hKey = NULL;
	if (ERROR_SUCCESS == RegOpenKeyEx(HKEY_LOCAL_MACHINE, RK_CLOCK, 0, 0, &hKey)) {
		DWORD dwSize = sizeof(DWORD);
		RegQueryValueEx(hKey, RV_AUTODST, 0, NULL, (LPBYTE) &ret, &dwSize);
		RegCloseKey(hKey);
	}
	return (BOOL) ret;
}
///PSR - SNTP begin
//**********************************************************************
///
/// Loads the SNTP server
///
/// @return error code if any
///
//**********************************************************************
int CV6SystemTimer::LoadSNTP(void) {
	BOOL bRet = FALSE;
#ifdef UNDER_CE
  HANDLE hFile = CreateFile(L"NTP0:",GENERIC_READ|GENERIC_WRITE,0,NULL,OPEN_EXISTING,0,NULL);
  if(INVALID_HANDLE_VALUE == hFile)
  {
  //SNTP Server is not running so try to bring this server up
  WCHAR szKey[]=L"Services\	IMESVC";
  CRegistryKey regKey;
  bRet = regKey.OpenKey(szKey);
  if ( TRUE == bRet )
  {
  DWORD dwType = 0;
  DWORD dwData = 0;
  DWORD dwSize = sizeof(dwData);
  bool bRegEdited = false;
  bRet = regKey.ReadValue(L"Flags", NULL, (BYTE *) (&dwData), &dwSize);
  if ( TRUE == bRet )
  {
  BOOL bIsSet = (dwData & DEVFLAGS_NOLOAD );
  if ( 0 != bIsSet)	//Value read from the Remote Registry for previous configuration
  {
  DWORD dwUnset = dwData;
  dwUnset ^= DEVFLAGS_NOLOAD;
  bRet = regKey.WriteValue(L"Flags", dwUnset ); //Remove the unload option
  if ( TRUE == bRet )
  {
  bRegEdited = true;
  }
  }
  else
  {
  bRet = TRUE;
  }
  }
  if ( TRUE == bRet ) //After registry changes
  {
  bRet = FALSE;
  WCHAR szControlString[]=L"TIMESVC";
  DWORD dwClientInfo = 0;
  HANDLE hSNTP = ActivateService(szControlString, dwClientInfo);
  if(NULL != hSNTP && INVALID_HANDLE_VALUE != hSNTP)
  {
  bRet = TRUE;
  //No need to close the mutex in Qt
  }
  }
  if ( bRegEdited )
  {
  regKey.WriteValue(L"Flags", dwData);//Write the previous data for no impact on Other functionalities
  //Do not flush the registry changes since we do not need them persistently
  }
  regKey.Close();
  }
  }
  else
  {
  //No need to close the mutex in Qt//SNTP already running and nothing ot do here, so close the hanlde
  }
#endif
	return bRet;
}
//---------------------------------------------------------------------------------------
//
// Function : bcd2bin
//
// Convert BCD (Binary Coded Decimal) Values to Binary formt.
//
//---------------------------------------------------------------------------------------
unsigned char CV6SystemTimer::bcd2bin(unsigned char val) {
	return (val & 0x0f) + (val >> 4) * 10;
}
BOOL CV6SystemTimer::ReadExternalRtcTime(SYSTEMTIME *lpst) {
	static HANDLE hI2C = NULL;
	LPINT lpiResult = 0;
	BYTE rtcReadBuffer[9];
	int i = 0;
	BOOL rc = FALSE;
	memset(rtcReadBuffer, 0, 9);
	if (NULL == hI2C) {
		hI2C = I2COpenHandle("I2C3:");
		rc = initRTC(hI2C);
		strTime.sprintf("I2COpenHandle called!");
		LogDebugMessage(strTime);
		if (FALSE == rc) {
			strTime.sprintf("initRTC failed!");
			LogDebugMessage(strTime);
			return rc;
		}
	}
	if (NULL != hI2C) {
		rc = I2CRead(hI2C, RTC_ADDRESS, rtcReadBuffer, RTC_RD_MSG_LENGTH);
		lpst->wYear = CENTURY_IN_USE + bcd2bin(rtcReadBuffer[YEAR_INDEX]);
		lpst->wMonth = bcd2bin(rtcReadBuffer[MONTH_INDEX] & 0x01F);
		lpst->wDayOfWeek = bcd2bin(rtcReadBuffer[DAY_INDEX] & 0x7) - 1; //1 to 7 in RTC while 0 to 6 in SYSTEMTIME
		lpst->wDay = bcd2bin(rtcReadBuffer[DATE_INDEX]);
		lpst->wHour = bcd2bin(rtcReadBuffer[HOUR_INDEX]);
		lpst->wMinute = bcd2bin(rtcReadBuffer[MINUTE_INDEX]);
		lpst->wSecond = bcd2bin(rtcReadBuffer[SECOND_INDEX] & 0x7F);
	}
	return rc;
}
HANDLE CV6SystemTimer::I2COpenHandle(LPCWSTR lpDevName) {
	HANDLE hI2C;
	hI2C = CreateFile(lpDevName,  // name of device
			GENERIC_READ | GENERIC_WRITE, // desired access
			FILE_SHARE_READ | FILE_SHARE_WRITE,  // sharing mode
			NULL,  // security attributes (ignored)
			OPEN_EXISTING, // creation disposition
			FILE_FLAG_RANDOM_ACCESS,  // flags/attributes
			NULL); // template file (ignored)
	if (hI2C == INVALID_HANDLE_VALUE) {
		//RETAILMSG(DEBUG_CONFIG_FLAG,(L"CreateFile I2C failed!%d\r\n", GetLastError()));
		return hI2C;
	}
	return hI2C;
}
BOOL CV6SystemTimer::I2CSetMasterMode(HANDLE hI2C) {
	if (!DeviceIoControl(hI2C, // file handle to the driver
			I2C_IOCTL_SET_MASTER_MODE, // I/O control code
			NULL,  // in buffer
			0, // in buffer size
			NULL,  // out buffer
			0, // out buffer size
			NULL,  // pointer to number of bytes returned
			NULL)) // ignored (=NULL)
			{
		//RETAILMSG(DEBUG_CONFIG_FLAG,(L"I2C_IOCTL_SET_MASTER_MODE failed!\r\n"));
		//DEBUGMSG(ZONE_ERROR,(TEXT("I2C_IOCTL_SET_MASTER_MODE failed!\r\n")));
		return FALSE;
	}
	return TRUE;
}
BOOL CV6SystemTimer::I2CSetFrequency(HANDLE hI2C, DWORD dwFreq) {
	if (!DeviceIoControl(hI2C, // file handle to the driver
			I2C_IOCTL_SET_FREQUENCY,  // I/O control code
			&dwFreq,  // in buffer
			sizeof(DWORD), // in buffer size
			NULL,  // out buffer
			0, // out buffer size
			NULL,  // pointer to number of bytes returned
			NULL)) // ignored (=NULL)
			{
		//DEBUGMSG(ZONE_ERROR,(TEXT("I2C_IOCTL_SET_FREQUENCY failed!\r\n")));
		return FALSE;
	}
	return TRUE;
}
BOOL CV6SystemTimer::initRTC(HANDLE hI2C) {
	BOOL bIsMaster = FALSE;
	if (NULL != hI2C) {
		bIsMaster = I2CSetMasterMode(hI2C);
		if (TRUE == bIsMaster) {
			if (!I2CSetFrequency(hI2C, 100000)) {
				//RETAILMSG(1, (L"SetI 2CSetFrequency Failed!\r\n", GetLastError()));
				return FALSE;
			}
		} else {
			return FALSE;
			//RETAILMSG(1, (L"SetI I2CSetMasterMode Failed!\r\n", GetLastError()));
		}
	} else {
		return FALSE;
	}
	return TRUE;
}
BOOL CV6SystemTimer::I2CTransfer(HANDLE hI2C, PI2C_TRANSFER_BLOCK pI2CTransferBlock) {
	//I2C_FUNCTION_ENTRY();
	if (!DeviceIoControl(hI2C, // file handle to the driver
			I2C_IOCTL_TRANSFER, // I/O control code
			pI2CTransferBlock, // in buffer
			sizeof(I2C_TRANSFER_BLOCK), // in buffer size
			NULL,  // out buffer
			0, // out buffer size
			NULL,  // pointer to number of bytes returned
			NULL)) // ignored (=NULL)
			{
		/*DEBUGMSG(ZONE_ERROR,
		 (TEXT("%s: I2C_IOCTL_TRANSFER failed!\r\n"), __WFUNCTION__));*/
		return FALSE;
	}
	//I2C_FUNCTION_EXIT();
	return TRUE;
}
BOOL CV6SystemTimer::I2CRead(HANDLE hContext, BYTE nRegAddr, VOID *pBuffer, UINT32 size) {
	BOOL bReturn = FALSE;
	I2C_TRANSFER_BLOCK I2CXferBlock;
	I2C_PACKET I2CPacket[2];
	int iResult;
	BYTE byOutData[1];
	byOutData[0] = (BYTE) 0;
	I2CPacket[0].byAddr = (BYTE) nRegAddr;
	I2CPacket[0].byRW = I2C_RW_WRITE;
	I2CPacket[0].pbyBuf = (PBYTE) byOutData;
	;
	I2CPacket[0].wLen = sizeof(byOutData);
	I2CPacket[0].lpiResult = &iResult;
	I2CPacket[1].byAddr = (BYTE) nRegAddr; //i2c_restart
	I2CPacket[1].byRW = I2C_RW_READ;
	I2CPacket[1].pbyBuf = (PBYTE) pBuffer;
	I2CPacket[1].wLen = size;
	I2CPacket[1].lpiResult = &iResult;
	I2CXferBlock.pI2CPackets = I2CPacket;
	I2CXferBlock.iNumPackets = 2;
	bReturn = I2CTransfer(hContext, &I2CXferBlock);
	if (!bReturn) {
		qDebug("I2CTransfer Failed! \n");
	}
	return bReturn;
}
///PSR - SNTP end
#ifdef DBG_FILE_LOG_SYSTIMER_ENABLE
void CV6SystemTimer::SetDebugLogger(CDebugFileLogger *pDbgFileLogger) {
	m_pDebugFileLogger = pDbgFileLogger;
}
void CV6SystemTimer::LogDebugMessage(QString strDebugMsg) {
	if (NULL != m_pDebugFileLogger) {
		QString strMsg;
		CTVtime currTime;
		strMsg.sprintf("%s - %d:%d:%d\r\n", currTime.hour(), currTime.minute(), currTime.second());
		m_pDebugFileLogger->WriteToDebugLogFile(strMsg);
	}
}
#endif

/// @file
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Generic
/// @n Filename: V6globals.cpp
/// @n Desc:	 All globals for V6 platform, only use for V6 specific modules
///				 
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  71  Stability Project 1.65.1.4 7/2/2011 5:02:42 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  70  Stability Project 1.65.1.3 7/1/2011 4:39:17 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  69  Stability Project 1.65.1.2 3/28/2011 3:06:59 PM  Hemant(HAIL) 
// Updated: Thread Synchronization included in operator overloads.
//  68  Stability Project 1.65.1.1 3/17/2011 3:20:54 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
// $
//
// ****************************************************************
#include "V6ResourceBase.h"
#include "V6UIResource.h"
#include "V6globals.h"
#include "NVVariables.h"
#include "StringUtils.h"
#include "V6defines.h"
#include "BasicMaxMinAve.h"
#include "QMDataBlock.h"
#include "QueueManager.h"
#include "ChartQueues.h"
#include <QString>
#include <QMutex>
#include "PPL.h"
#include <QMessageBox>
#include "RTCSyncThread.h"
#include "StringUtils.h"

CDeviceAbstraction *pGlbDal = NULL;					///< Gloabl Ddevice abstraction layer
CDeviceCaps GlbDevCaps;								///< Device Capabilities instance for recorder
CDataItemManager *pGlbDIT = NULL;						///< Handle on Data Item Table
CSetupConfiguration *pGlbSetup = NULL;				///< Pointer to Current Setup configuration
QMutex m_GlbSetupMutex;
CV6SystemTimer *pGlbSysTimer = NULL;				///< Instance of System timer singleton
CSysInfo *pGlbSysInfo = NULL;						///< Pointer to System Info singleton
CNVVariableBlockManager *pGlbNVVars = NULL;			///< Pointer to NV Variables
HKL gKeyBLayout = NULL;								///< Handle to Global KeyboardLayout
BSP_VERSION g_BSPVersion; //Added by dharma kiran
QString g_FormatType = ""; //Added by Prasad. Fix for 1-1713TYI GR_General Status shows "Internal Mem ID as 512(null)
#ifndef TTR6SETUP
#ifndef DOCVIEW
#ifndef V6IOTEST
CAMS2750TUSMgr *pGlbTUSMgr = NULL;					///< Pointer to TUS Manager
#endif
#endif
#ifndef V6IOTEST
CTabularReadings *pGlbTabReadings = NULL;			///< Pointer to the tabular readings
#endif
CLayoutConfiguration *pGlbLayout = NULL;			///< Pointer to the current layout configuration
CPasswordConfiguration *pPwdSetup = NULL;				///< Pointer to Current Password configuration
CMessageListServices *pGlbMsgListSer = NULL;		///< Pointer to Message List Service Singleton
#endif
T_APPINTERFACE_SEMAPHORE volatile GlbAppStateSema = APPACCESS_LOCKED;///< Semaphore for AppInterface if it is safe to access system
#ifdef __IMPLMT_HEAP__
// ----------------------------------------------------------------------------------------------------------
// Globals for Heap Memory Management.
// ----------------------------------------------------------------------------------------------------------
// defines of global members....
// Handles for Heaps
HANDLE m_hHeap_1;
HANDLE m_hHeap_2;
HANDLE m_hHeap_3;
HANDLE m_hHeap_4;
QMutex csPrivateHeap;
#endif	// __IMPLMT_HEAP__
//****************************************************************************
/// Initialise Globals for V6 recorder system
///
/// @return - TRUE if successful, FALSE if failed - fatal. 
///
//****************************************************************************
BOOL InitGlobals() {
#ifdef STARTUP_LOGGING
	WCHAR InitLogFileName[ 256 ];
	WCHAR InitLogString[512];
	int iPathLen = 256;
	BOOLEAN isFileCreated = FALSE;
	//m_pMutex = CreateMutex(NULL,false,_T("GlobalMutext"));
	CStorage kLogFile;
	QFileDevice::FileError kFileEx;
	pDALGLB->GetPath(	static_cast< T_STORAGE_PATH >( IDS_INTERNAL_SD ), 
						InitLogFileName,
						256,
						&iPathLen );
	wcsncat( InitLogFileName, 256, L"InitGlobals.txt", (256 - wcslen( InitLogFileName )) );
	if( kLogFile.Open(	InitLogFileName, 
						CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
						&kFileEx ) )
	{
		kLogFile.SeekToEnd();
		wcscpy(InitLogString,L"--------Initialisation started-------\n");
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
#ifndef TTR6SETUP
	// ----------------------------------------------------------------------------------------------------------
	// Get a handle on the message lists singleton and setup pMSG_SERVICES
	// -----------------------------------------------------------------------------------------------------------
	pGlbMsgListSer = CMessageListServices::GetHandle();
	if (NULL == pGlbMsgListSer) {
		return FALSE;
	}
#endif
	// ----------------------------------------------------------------------------------------------------------
	// Initialise NV Variables and setup pNV_VARS
	// -----------------------------------------------------------------------------------------------------------
#ifdef STARTUP_LOGGING
	wcscpy(InitLogString,L"Initialise NV Variables\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();	
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	pGlbNVVars = CNVVariableBlockManager::GetHandle();
	if (NULL == pGlbNVVars) {
		return FALSE;
	}
	pGlbNVVars->Initialise();
	GlbDevCaps.DisplayTraceMemoryStatus("Glb: NV Vars intialised");
	// ----------------------------------------------------------------------------------------------------------
	// Initialise System Timer, baseline start up time pSYSTIMER
	// -----------------------------------------------------------------------------------------------------------
#ifdef STARTUP_LOGGING
	wcscpy(InitLogString,L"Initialise System Timer\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();	
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	pGlbSysTimer = CV6SystemTimer::GetHandle();
	if (NULL == pGlbSysTimer) {
		return FALSE;
	}
	pGlbSysTimer->Initialise();
	GlbDevCaps.DisplayTraceMemoryStatus("Glb: systimer intialised");
#ifdef STARTUP_LOGGING
	wcscpy(InitLogString,L"time change notification\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();	
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	// ----------------------------------------------------------------------------------------------------------
	// Initialise system information instance and setup pSYSTEM_INFO
	// -----------------------------------------------------------------------------------------------------------
	pGlbSysInfo = CSysInfo::GetHandle();				///< Pointer to System Info singleton
	if (NULL == pGlbSysInfo) {
		return FALSE;
	}
#ifdef DOCVIEW
	MediaUtils kMedia;
	// on screen designer we need to check the internal media has been created
	if( !kMedia.CheckInternalMedia( IDS_INTERNAL_SD ) )
  {
  if( !kMedia.PrepareInternal( IDS_INTERNAL_SD ) )
  {
  return FALSE;
  } // End of IF
	}
#endif
#ifdef STARTUP_LOGGING
	wcscpy(InitLogString,L"Initialise system information\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();	
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	pGlbSysInfo->Initialise();
	GlbDevCaps.DisplayTraceMemoryStatus("Glb: Sys Info intialised");
	// Inititalize timer events handling thread
	// Moving this below sysInfo Init as Daylight saving required or not configuration 
	// is updated only in pGlbSysInfo->Initialise();
	// Startup the thread responsible for time change notification now the system timer has started
	StartTimeChangeThread();
	// ----------------------------------------------------------------------------------------------------------
	// Initialise language DLL's, load the correct resource DLL as we have the required language
	// -----------------------------------------------------------------------------------------------------------
#ifdef STARTUP_LOGGING
	wcscpy(InitLogString,L"pGlbSysInfo->GetFactoryConfig\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();	
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	QString strErrorMsg("");
	const T_PGENNONVOL ptGEN_NON_VOL = pGlbSysInfo->GetFactoryConfig();
	// check this value has not become corrupted
	QString strLanguages("");
	//#if LangAll == 1 kiran
	strLanguages =
			QWidget::tr(
					"English (UK)|English (US)|French|German|Italian|Spanish|Brazilian|Polish|Hungarian|Slovakian|Czech|Turkish|Romanian|Russian|Portuguese|Greek|Bulgarian|Korean|Chinese|Japanese|");
	//#endif
	//#if LangChinese == 1
	/*strLanguages = tr("English (UK)|English (US)|French|German|Italian|Spanish|Brazilian|Polish|Hungarian|Slovakian|Czech|Turkish|Romanian|Russian|Portuguese|Greek|Bulgarian|Chinese|");
	 #endif
	 #if LangJapanese == 1
	 strLanguages = tr("English (UK)|English (US)|French|German|Italian|Spanish|Brazilian|Polish|Hungarian|Slovakian|Czech|Turkish|Romanian|Russian|Portuguese|Greek|Bulgarian|Japanese|");
	 #endif
	 #if LangKorean == 1
	 strLanguages = tr("English (UK)|English (US)|French|German|Italian|Spanish|Brazilian|Polish|Hungarian|Slovakian|Czech|Turkish|Romanian|Russian|Portuguese|Greek|Bulgarian|Korean|");
	 #endif*/
	if (ptGEN_NON_VOL->Language >= CStringUtils::InstanceOfStr(strLanguages, "|")) {
		// default back to English for now
		ptGEN_NON_VOL->Language = 0;
	}
	T_LANGUAGES eLang = static_cast<T_LANGUAGES>(ptGEN_NON_VOL->Language);
	// only load the US language DLL if this is in manufacturing mode and not UK
	if ((eLang != lngEnglish) && pSYSTEM_INFO->IsInManufacturingMode()) {
		eLang = lngEngUS;
	}
// TAC ISSUE -: Language ChangeOver Issue for TMS (# define UNDER_CE to change keybaord layout function for Recorder only) 
#ifdef UNDER_CE	
	QString  strLocale("");
	// Check if the language is non-US and set the Keyboard layout if it is one of the keyboards we support
	if( eLang == lngFra) // French
	{
        strLocale = "0000040C";
	}
	else if (eLang == lngGer) // German
	{
        strLocale = "00000407";
	}
	else if (eLang == lngEnglish) // English UK
	{
        strLocale = "00000809";
	}
#ifdef STARTUP_LOGGING
	wcscpy(InitLogString,L"KeyBoard Layout\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();	
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	// If we have a non-US keyboard
	if( strLocale != "" )
	{		
		gKeyBLayout = LoadKeyboardLayout(strLocale, 1);
		if( gKeyBLayout != 0 )
		{
			// Now that we have the layout apply it, we can ignore the existing layout as the App restarts after lang change
			HKL oldLayout = ActivateKeyboardLayout( gKeyBLayout, 1);
		}
		else
		{
			LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_ERROR,"V6 APP ERROR - Unable to load Keyboard Layout for Locale : " + strLocale );
		}
		
	}
#endif
#ifdef STARTUP_LOGGING
	wcscpy(InitLogString,L"Load language Dll\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();	
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	if (!CStringUtils::LoadLangDLL(eLang, strErrorMsg)) {
		LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, "V6 APP ERROR - " + strErrorMsg);
	} else {
		//set the language loaded flag for the op panel
		pGlbSysInfo->SetStartupLanguageValid();
	}
	GlbDevCaps.DisplayTraceMemoryStatus("Glb: language DLL loaded");
	// ----------------------------------------------------------------------------------------------------------
	// Get a handle on the DIT (Data Item Table) singleton and configure pDIT (not initialised till later)
	// -----------------------------------------------------------------------------------------------------------
#ifdef STARTUP_LOGGING 
	wcscpy(InitLogString,L"Get a handle on the DIT\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();	
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	pGlbDIT = CDataItemManager::GetHandle();
	if (NULL == pGlbDIT) {
		return FALSE;
	}
	srand( pSYSTEM_INFO->GetSerialNumber());
#ifndef TTR6SETUP
	// ----------------------------------------------------------------------------------------------------------
	// Get a handle on the TUS manager singleton
	// -----------------------------------------------------------------------------------------------------------
#ifdef STARTUP_LOGGING
	wcscpy(InitLogString,L"CAMS2750TUSMgr::Instance()\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();	
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
#ifndef DOCVIEW
#ifndef V6IOTEST
	pGlbTUSMgr = CAMS2750TUSMgr::Instance();
#endif
#endif
	// ----------------------------------------------------------------------------------------------------------
	// Get a handle on the tabular data singleton
	// -----------------------------------------------------------------------------------------------------------
#ifdef STARTUP_LOGGING
	wcscpy(InitLogString,L"Get a handle on the tabular data\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();	
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
#ifndef V6IOTEST
	pGlbTabReadings = CTabularReadings::Instance();
#endif
#ifdef DOCVIEW
	// Initialise tabular readings for screen designer
	pTABULAR->Initialise();
#endif
#endif
#ifdef STARTUP_LOGGING
	wcscpy(InitLogString,L"--------END of Initialisation-------\n");
	if( kLogFile.Open(	InitLogFileName, 
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();	
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	return TRUE;
}
//****************************************************************************
/// Look up a reference for a variable name from script services, not a unicode
/// variable name
///
/// @param[in] - pvarName, Variable name to get reference for
///
/// @return - reference to a DataItem, use only if not a REF_ERROR 
///
//****************************************************************************	
int LookUpRefForDITByVarname(char *pvarName) {
	// Define a wide character strict for conversion
    QString UnicodeVarName= "";

	// If the variable name for conversion is valid, length, convert
	if (strlen(pvarName) < MAX_VARNAME_LEN) {
        UnicodeVarName = QString::fromLatin1( pvarName).toUpper();	// Convert from char to wchar string
	}
    return pGlbDIT->LookUp(UnicodeVarName);
}
//****************************************************************************
/// Get a data Item value form the reference passed
/// @note This MUST be a valiudated reference from LookUpRefForDITByVarname, if a
/// REF_ERROR id returned by LookUpRefForDITByVarname then this function should not be used
/// performance is key for this function hence no checks.
///
/// @param[in] - ref, Validated reference from LookUpRefForDITByVarname or pGlbDIT->LookUp
///
/// @return - current value of the data item required
///
//****************************************************************************	
float GetDITValueByRef(int ref) {
	float retValue = 0.0;
	// If the reference is valid lookup the value
	retValue = pGlbDIT->GetValueFromLookup(ref);
	return retValue;
}
//****************************************************************************
/// Log System Message to the Message List for Processing
///
/// @param[in] 	  msgType - Message Type
/// @param[in] const QString  &rstrMESSAGE - The Message Text( UNICODE )
/// @param[in]		const BYTE byMESSAGE_FLAGS - Flag indicating the actions to be taken with 
///					this message, e.g. don't mark on chart
///
/// @return MSGLISTSER_MESSAGE_LIST_FULL - Message List Full could not add Message to List
/// @n MSGLISTSER_OK  - Message Added Successfully
///
//****************************************************************************
const T_MSGLISTSER_RETURN_VALUE LogSystemMessage(const T_MSGLISTSER_SYSTEM_MSG_TYPE msgType, const QString &rstrMESSAGE,
		const BYTE byMESSAGE_FLAGS /* = 0 */) {
//TM - by removing this call from the XSeries DLL build a whole load of unused functionality 
//can also be removed fro the XSeries project - it makes sense to do this here
#ifndef TTR6SETUP
	// this has been removed following other changes allowing messages to still be logged
//	CChartQManager* CM=CChartQManager::GetHandle();
//	if(CM->IsChartsStopped()) // don't add messages if charts are stopped
//		return MSGLISTSER_OK; 
	assert(pGlbMsgListSer);
	return pGlbMsgListSer->LogSystemMessage(msgType, rstrMESSAGE, byMESSAGE_FLAGS);
#else
	return MSGLISTSER_OK;
#endif
}
//****************************************************************************
/// Log Diagnostic Message to the Message List for Processing
///
/// @param[in] 	  msgType - Message Type
/// @param[in] const QString  &rstrMESSAGE - The Message Text( UNICODE )
///
/// @return MSGLISTSER_MESSAGE_LIST_FULL - Message List Full could not add Message to List
/// @n MSGLISTSER_OK  - Message Added Successfully
///
//****************************************************************************
const T_MSGLISTSER_RETURN_VALUE LogDiagnosticMessage(const T_MSGLISTSER_DIAGNOSTIC_MSG_TYPE msgType,
		const QString rstrMESSAGE) {
//TM - by removing this call from the XSeries DLL build a whole load of unused functionality 
//can also be removed fro the XSeries project - it makes sense to do this here
#ifndef TTR6SETUP
	assert(pGlbMsgListSer);
	return pGlbMsgListSer->LogDiagnosticMessage(msgType, rstrMESSAGE);
#else
	return MSGLISTSER_OK;
#endif
}
void BlockServicesError(const QString strERROR) {
    char msg[] = "Block Services Error";
    V6CriticalMessageBox(NULL, strERROR.toLocal8Bit().data(), msg, MB_OK );
}
void FreeBlockQueueError(const QString strERROR) {
    char msg[] = "Free Block Queue Error";
    V6CriticalMessageBox(NULL, strERROR.toLocal8Bit().data(), msg, MB_OK );
}
//****************************************************************************
/// V6 Critical Message box - used when it's all gone bad and a reboot is the 
/// only answer. (Go ahead punk, make my day....)
///
/// @param[in] 	  hWnd			same params as for ::MessageBox
/// @param[in] lpText 
/// @param[in] lpCaption 
/// @param[in] uType 
///
//****************************************************************************
int V6CriticalMessageBox(HWND hWnd, LPCTSTR lpText, LPCTSTR lpCaption, UINT uType) {
	// ensure the messagebox is topmost
	QMessageBox msg_box;
	msg_box.setIcon(QMessageBox::Critical);
	msg_box.setWindowTitle(lpCaption);
	msg_box.setText(lpText);
	msg_box.setStandardButtons(QMessageBox::Ok);
	msg_box.exec();
	// do reboot here.
	pDALGLB->PerformReboot();
	// ensure we do not proceeed any further
	bool bTrue = true;
	while (bTrue) {
		sleep(1000);
	}
	return 0;
}
DWORD QString(UINT8 r, UINT8 g, UINT8 b) {
	DWORD op = 0;
	op = r | ((g << 8) & 0xFF00) | ((b << 16) & 0xFF0000);
	return op;
}
//****************************************************************************
/// V6 Warning Message box - Does nothing in a production build. 
/// if pre-production, displays a message box.
///
/// @param[in] 	  hWnd			same params as for ::MessageBox
/// @param[in] lpText 
/// @param[in] lpCaption 
/// @param[in] uType 
///
//****************************************************************************
int V6WarningMessageBox(HWND hWnd, LPCTSTR lpText, LPCTSTR lpCaption, UINT uType) {
	int iRetVal = 0;
	if (V6_RELEASE != RELEASE_PRODUCTION) {
		QMessageBox msg_box;
		msg_box.setIcon(QMessageBox::Warning);
		msg_box.setWindowTitle(lpCaption);
		msg_box.setText(lpText);
		msg_box.setStandardButtons(QMessageBox::Ok);
		iRetVal = msg_box.exec();
	} else {
		iRetVal = 1;
	}
    QString strError;
	// log a diagnostic error message too
    strError = QString::asprintf("%s, - %s", lpCaption, lpText);
	LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
	return iRetVal;
}
#ifdef __IMPLMT_HEAP__
// ----------------------------------------------------------------------------------------------------------
// Globals for Heap Memory Management.
// -----------------------------------------------------------------------------------------------------------
//////////////////////////////////////////////////////////////////////////////
//
//	Global Functions.
//
//////////////////////////////////////////////////////////////////////////////
void GlobalHeapCreate()
{
	// HeapCreate API
	m_hHeap_1 = ::HeapCreate(0, INITIAL_HEAP_SIZE, MAX_HEAP_SIZE);
	m_hHeap_2 = ::HeapCreate(0, INITIAL_HEAP_SIZE, MAX_HEAP_SIZE);
	m_hHeap_3 = ::HeapCreate(0, INITIAL_HEAP_SIZE, MAX_HEAP_SIZE);
	m_hHeap_4 = ::HeapCreate(0, INITIAL_HEAP_SIZE, MAX_HEAP_SIZE);
}
//////////////////////////////////////////////////////////////////////////////
//
//	Operator new, delete, new [], delete [] Overloaded functions.
//
//////////////////////////////////////////////////////////////////////////////
void* operator new(size_t nSize)
{
	csPrivateHeap.lock();
	void *ptr = NULL;
	DWORD dwCurrThreadID = 0;
	
	if (nSize != NULL)
	{
		// get the thread id which has called this implementation..
		//
		dwCurrThreadID = ::QThread::currentThreadId();
		
		// allocate 8 bytes extra to the actual "nSize"
		// this shall help to store the Heap Handle and ThreadId in the added extra bytes
		// do not return the ptr as is, move the ptr ahead again by 8 bytes and then return the ptr.
		//
		if (nSize <= HEAP_ALLOC_THRESHOLD_1)													// HEAP 1
		{		
			nSize = nSize + EXTRA_BYTES_FOR_HEAP_HANDLE + EXTRA_BYTES_FOR_THREAD_HANDLE;
			ptr = ::HeapAlloc(m_hHeap_1, HEAP_ZERO_MEMORY, nSize);
			
			if (ptr != NULL)
			{
				::memcpy(ptr, &(HANDLE)m_hHeap_1, sizeof(HANDLE));
				(void *)ptr = (char *)ptr + EXTRA_BYTES_FOR_HEAP_HANDLE;
				::memcpy(ptr, &(DWORD)dwCurrThreadID, sizeof(DWORD));
				(void *)ptr = (char *)ptr + EXTRA_BYTES_FOR_THREAD_HANDLE;
			}
		}
		else if ( (nSize > HEAP_ALLOC_THRESHOLD_1) && (nSize <= HEAP_ALLOC_THRESHOLD_2) )		// HEAP 2
		{
			nSize = nSize + EXTRA_BYTES_FOR_HEAP_HANDLE + EXTRA_BYTES_FOR_THREAD_HANDLE;
			ptr = ::HeapAlloc(m_hHeap_2, HEAP_ZERO_MEMORY, nSize);
			
			if (ptr != NULL)
			{
				::memcpy(ptr, &(HANDLE)m_hHeap_2, sizeof(HANDLE));
				(void *)ptr = (char *)ptr + EXTRA_BYTES_FOR_HEAP_HANDLE;
				::memcpy(ptr, &(DWORD)dwCurrThreadID, sizeof(DWORD));
				(void *)ptr = (char *)ptr + EXTRA_BYTES_FOR_THREAD_HANDLE;
			}
		}
		else if ( (nSize > HEAP_ALLOC_THRESHOLD_2) && (nSize <= HEAP_ALLOC_THRESHOLD_3) )		// HEAP 3
		{
			nSize = nSize + EXTRA_BYTES_FOR_HEAP_HANDLE + EXTRA_BYTES_FOR_THREAD_HANDLE;
			ptr = ::HeapAlloc(m_hHeap_3, HEAP_ZERO_MEMORY, nSize);
			
			if (ptr != NULL)
			{
				::memcpy(ptr, &(HANDLE)m_hHeap_3, sizeof(HANDLE));
				(void *)ptr = (char *)ptr + EXTRA_BYTES_FOR_HEAP_HANDLE;
				::memcpy(ptr, &(DWORD)dwCurrThreadID, sizeof(DWORD));
				(void *)ptr = (char *)ptr + EXTRA_BYTES_FOR_THREAD_HANDLE;
			}
		}
		else if (nSize > HEAP_ALLOC_THRESHOLD_3)												// HEAP 4
		{
			nSize = nSize + EXTRA_BYTES_FOR_HEAP_HANDLE + EXTRA_BYTES_FOR_THREAD_HANDLE;
			ptr = ::HeapAlloc(m_hHeap_4, HEAP_ZERO_MEMORY, nSize);
			
			if (ptr != NULL)
			{
				::memcpy(ptr, &(HANDLE)m_hHeap_4, sizeof(HANDLE));
				(void *)ptr = (char *)ptr + EXTRA_BYTES_FOR_HEAP_HANDLE;
				::memcpy(ptr, &(DWORD)dwCurrThreadID, sizeof(DWORD));
				(void *)ptr = (char *)ptr + EXTRA_BYTES_FOR_THREAD_HANDLE;
			}
		}
	}
	csPrivateHeap.unlock();
	return(ptr);
}

void operator delete(void *ptr)
{
	csPrivateHeap.lock();
	HANDLE l_hHeap = 0;
	DWORD l_dwThreadID;
	void *getPtr = NULL;
	void *releasePtr = NULL;
	BOOL bReturnStatus = FALSE;
	if (ptr != NULL)
	{
		//
		// get the handle of heap and thread id
		//
		getPtr = (char *)ptr - EXTRA_BYTES_FOR_HEAP_HANDLE - EXTRA_BYTES_FOR_THREAD_HANDLE;
		releasePtr = (char *)ptr - EXTRA_BYTES_FOR_HEAP_HANDLE - EXTRA_BYTES_FOR_THREAD_HANDLE;
		::memcpy(&l_hHeap, getPtr, sizeof(HANDLE));
		(void *)getPtr = (char *)getPtr + EXTRA_BYTES_FOR_THREAD_HANDLE;
		::memcpy(&l_dwThreadID, getPtr, sizeof(DWORD));
		// check if the local heap handle equals any of the global heap handles created
		// this is only for check...
		if ( (l_hHeap == m_hHeap_1) || (l_hHeap == m_hHeap_2) || (l_hHeap == m_hHeap_3) || (l_hHeap == m_hHeap_4) )
		{
			bReturnStatus = ::HeapFree(l_hHeap, 0, releasePtr);
			if (bReturnStatus != 0)
			{
				ptr = NULL;
				getPtr = NULL;
				releasePtr = NULL;
			}		
		}
	}
	
	csPrivateHeap.unlock();
}

void* operator new[] (size_t nSize)
{
	csPrivateHeap.lock();
	void *ptr = NULL;
	DWORD dwCurrThreadID = 0;
	
	if (nSize != NULL)
	{
		// get the thread id which has called this implementation..
		//
		dwCurrThreadID = ::QThread::currentThreadId();
		
		// allocate 8 bytes extra to the actual "nSize"
		// this shall help to store the Heap Handle and ThreadId in the added extra bytes
		// do not return the ptr as is, move the ptr ahead again by 8 bytes and then return the ptr.
		//
		if (nSize <= HEAP_ALLOC_THRESHOLD_1)													// HEAP 1
		{		
			nSize = nSize + EXTRA_BYTES_FOR_HEAP_HANDLE + EXTRA_BYTES_FOR_THREAD_HANDLE;
			ptr = ::HeapAlloc(m_hHeap_1, HEAP_ZERO_MEMORY, nSize);
			
			if (ptr != NULL)
			{
				::memcpy(ptr, &(HANDLE)m_hHeap_1, sizeof(HANDLE));
				(void *)ptr = (char *)ptr + EXTRA_BYTES_FOR_HEAP_HANDLE;
				::memcpy(ptr, &(DWORD)dwCurrThreadID, sizeof(DWORD));
				(void *)ptr = (char *)ptr + EXTRA_BYTES_FOR_THREAD_HANDLE;
			}
		}
		else if ( (nSize > HEAP_ALLOC_THRESHOLD_1) && (nSize <= HEAP_ALLOC_THRESHOLD_2) )		// HEAP 2
		{
			nSize = nSize + EXTRA_BYTES_FOR_HEAP_HANDLE + EXTRA_BYTES_FOR_THREAD_HANDLE;
			ptr = ::HeapAlloc(m_hHeap_2, HEAP_ZERO_MEMORY, nSize);
			
			if (ptr != NULL)
			{
				::memcpy(ptr, &(HANDLE)m_hHeap_2, sizeof(HANDLE));
				(void *)ptr = (char *)ptr + EXTRA_BYTES_FOR_HEAP_HANDLE;
				::memcpy(ptr, &(DWORD)dwCurrThreadID, sizeof(DWORD));
				(void *)ptr = (char *)ptr + EXTRA_BYTES_FOR_THREAD_HANDLE;
			}
		}
		else if ( (nSize > HEAP_ALLOC_THRESHOLD_2) && (nSize <= HEAP_ALLOC_THRESHOLD_3) )		// HEAP 3
		{
			nSize = nSize + EXTRA_BYTES_FOR_HEAP_HANDLE + EXTRA_BYTES_FOR_THREAD_HANDLE;
			ptr = ::HeapAlloc(m_hHeap_3, HEAP_ZERO_MEMORY, nSize);
			
			if (ptr != NULL)
			{
				::memcpy(ptr, &(HANDLE)m_hHeap_3, sizeof(HANDLE));
				(void *)ptr = (char *)ptr + EXTRA_BYTES_FOR_HEAP_HANDLE;
				::memcpy(ptr, &(DWORD)dwCurrThreadID, sizeof(DWORD));
				(void *)ptr = (char *)ptr + EXTRA_BYTES_FOR_THREAD_HANDLE;
			}
		}
		else if (nSize > HEAP_ALLOC_THRESHOLD_3)												// HEAP 4
		{
			nSize = nSize + EXTRA_BYTES_FOR_HEAP_HANDLE + EXTRA_BYTES_FOR_THREAD_HANDLE;
			ptr = ::HeapAlloc(m_hHeap_4, HEAP_ZERO_MEMORY, nSize);
			
			if (ptr != NULL)
			{
				::memcpy(ptr, &(HANDLE)m_hHeap_4, sizeof(HANDLE));
				(void *)ptr = (char *)ptr + EXTRA_BYTES_FOR_HEAP_HANDLE;
				::memcpy(ptr, &(DWORD)dwCurrThreadID, sizeof(DWORD));
				(void *)ptr = (char *)ptr + EXTRA_BYTES_FOR_THREAD_HANDLE;
			}
		}
	}
	csPrivateHeap.unlock();
	return(ptr);
}
void operator delete [](void *ptr)
{
	csPrivateHeap.lock();
	HANDLE l_hHeap = 0;
	DWORD l_dwThreadID;
	void *getPtr = NULL;
	void *releasePtr = NULL;
	BOOL bReturnStatus = FALSE;
	if (ptr != NULL)
	{
		//
		// get the handle of heap and thread id
		//
		getPtr = (char *)ptr - EXTRA_BYTES_FOR_HEAP_HANDLE - EXTRA_BYTES_FOR_THREAD_HANDLE;
		releasePtr = (char *)ptr - EXTRA_BYTES_FOR_HEAP_HANDLE - EXTRA_BYTES_FOR_THREAD_HANDLE;
		::memcpy(&l_hHeap, getPtr, sizeof(HANDLE));
		(void *)getPtr = (char *)getPtr + EXTRA_BYTES_FOR_THREAD_HANDLE;
		::memcpy(&l_dwThreadID, getPtr, sizeof(DWORD));
		// check if the local heap handle equals any of the global heap handles created
		// this is only for check...
		if ( (l_hHeap == m_hHeap_1) || (l_hHeap == m_hHeap_2) || (l_hHeap == m_hHeap_3) || (l_hHeap == m_hHeap_4) )
		{
			bReturnStatus = ::HeapFree(l_hHeap, 0, releasePtr);
			if (bReturnStatus != 0)
			{
				ptr = NULL;
				getPtr = NULL;
				releasePtr = NULL;
			}		
		}
	}
	
	csPrivateHeap.unlock();
}
#endif	// __IMPLMT_HEAP__

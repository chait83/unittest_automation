/// @file
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Time Tasks
/// @n Filename:  TimeChangeNotifyThread.cpp
/// @n Description: Implementation of the CTimeChangeNotifyThread class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  10  Aristos  1.4.1.3.1.0 9/19/2011 4:51:07 PM  Hemant(HAIL)  
//  Stability recorder source code (JI Release) updated for WatchDog
//  Timer functionality.
//  9 Stability Project 1.4.1.3 7/2/2011 5:02:06 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  8 Stability Project 1.4.1.2 7/1/2011 4:39:01 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  7 Stability Project 1.4.1.1 3/17/2011 3:20:50 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
// $
//
// **************************************************************************
#include "TimeChangeNotifyThread.h"
#include "TVtime.h"
#include "ThreadInfo.h"
#include "V6globals.h"
#include "StringDefinitions.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
#define TIME_CHANGE_NOTIFICATION _T("\\\\.\\Notifications\\NamedEvents\\TimeChangeEvent")
#define TIME_CHANGE_EVENT _T("TimeChangeEvent")
#define LOGON_EVENT _T("LogonEvent")
/// Static Initialisation
CTimeChangeNotifyThread::T_TCN_THREAD_STATE CTimeChangeNotifyThread::ms_eState = CTimeChangeNotifyThread::tcnINIT;
/// The handle to the time change trigger event
QMutex ms_hEvent;
/////////////////////////////////////////////////////////////////////////////
// CTimeChangeNotifyThread
// IMPLEMENT_DYNCREATE(CTimeChangeNotifyThread, QThread)
//****************************************************************************
// CTimeChangeNotifyThread()
///
/// Constructor
///
//****************************************************************************
CTimeChangeNotifyThread::CTimeChangeNotifyThread() {
}
//****************************************************************************
// ~CTimeChangeNotifyThread()
///
/// Destructor
///
//****************************************************************************
CTimeChangeNotifyThread::~CTimeChangeNotifyThread() {
}
//****************************************************************************
// BOOL InitInstance()
///
/// Init Instance method
///
//****************************************************************************
BOOL CTimeChangeNotifyThread::InitInstance() {
	// TODO: perform and per-thread initialization here
	return TRUE;
}
//****************************************************************************
// int ExitInstance()
///
/// Exit Instance method
///
//****************************************************************************
int CTimeChangeNotifyThread::ExitInstance() {
	// TODO: perform any per-thread cleanup here
    QThread::exit();
    return 0;
}

DWORD GetTimeZoneInformation(TIME_ZONE_INFORMATION *tzi){

    return 0;
}

//****************************************************************************
// void ShutdownThread( )
///
/// Method that signals to the thread we are shutting down
///
//****************************************************************************
void CTimeChangeNotifyThread::ShutdownThread()
{
	ms_eState = tcnSHUTDOWN;
	if( ms_hEvent != NULL )
	{
		SetEvent( ms_hEvent );
	}
}
//****************************************************************************
// UINT TimeChangeNotifyFunc(LPVOID lpParam)
///
/// Main thread function
///
//****************************************************************************
UINT CTimeChangeNotifyThread::TimeChangeNotifyFunc(LPVOID lpParam) {
	HANDLE hLogonEvent = NULL;
	HANDLE hDSTEvent = NULL;
	ms_hEvent = NULL;
	bool bFirstTime = true;
	DWORD dwWaitResult = 0;
	// Flag which maintains the state of DST /SDT message log 
	DWORD dwSysTimeDSTFlagStatus = 0;
	ms_eState = tcnINIT;
	const DWORD timeout = 1000;
	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//of the TimeChangeNotify thread
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
#ifdef THREAD_ID_SERIAL_LOG
	  WCHAR szDbgMsg[512];
		swprintf( szDbgMsg, L"CTimeChangeNotifyThread::TimeChangeNotifyFunc-Thread id 0x%x, %lu ", GetThreadId(GetCurrentThread()), GetThreadId(GetCurrentThread()));
		OutputDebugString(szDbgMsg);
#endif
	//Notify the WatchdogTimer that the TimeChangeNotify thread has 
	//started
	if (pThreadInfo != NULL) {
		pThreadInfo->UpdateThreadInfo(AM_TIME_CHANGE_NOTIFY, true);
	}
	// continue in this thread until the system is ordered to shutdown
	while (ms_eState != tcnSHUTDOWN) {
		switch (ms_eState) {
		case tcnRUNNING: {
			// check for the event occuring
			if ((ms_hEvent != NULL) && (hLogonEvent != NULL) && (hLogonEvent != NULL)) {
				if (pThreadInfo != NULL) {
					//Ignore the TimeChangeNotifyThread for WatchDog
					//thread until it waits infinitely
					pThreadInfo->UpdateThreadInfo(AM_TIME_CHANGE_NOTIFY, false);
				}
				HANDLE hEvents[3] = { ms_hEvent, hLogonEvent, hDSTEvent };
				//dwWaitResult = WaitForMultipleObjects( 2, hEvents, FALSE, INFINITE ); E529380 replaced infinite timeout
				dwWaitResult = WaitForMultipleObjects(3, hEvents, FALSE, INFINITE);
				if (pThreadInfo != NULL) {
					//Start considering the TimeChangeNotifyThread for WatchDog
					//thread after the wait is complete
					pThreadInfo->UpdateThreadInfo(AM_TIME_CHANGE_NOTIFY, true);
				}
				switch (dwWaitResult) {
				case WAIT_OBJECT_0:
				case WAIT_OBJECT_0 + 2: {
					if (WAIT_OBJECT_0 == dwWaitResult) {
						// reset the event
						ResetEvent(ms_hEvent);
					} else {
						// reset the event
						ResetEvent(hDSTEvent);
					}
					// only do things if the time change was not because we are shutting down
					if (ms_eState != tcnSHUTDOWN) {
						qDebug("Time change received - SNTP or UI Update\n");
						OutputDebugString(_T("Time change received - SNTP or UI Update\n"));
						if (pThreadInfo != NULL) {
							//Update the Thread Counter for the TimeChangeNotifyThread
							pThreadInfo->UpdateThreadCounter(AM_TIME_CHANGE_NOTIFY);
						}
						sleep(1000);
						pDALGLB->SyncTime();
						pSYSTIMER->RegisterATimeChange();
						//---------------------------------------------------------------
						// Added to log the DST/SDT message in the recorder
						//---------------------------------------------------------------
						CTVtime currTime;
						QDateTime pSysCurrTime;
						currTime.TimeNow();
						currTime.GetSYSTEMTIME(&pSysCurrTime);
						TIME_ZONE_INFORMATION tzi;
						DWORD dwTime = GetTimeZoneInformation(&tzi);
						// If the system supports DST verify that the kernel returned the correct
						// value, otherwise make sure the kerel is in SDT
						if (pSYSTIMER->LocaleSupportsDST(&tzi)) {
							if (dwTime != dwSysTimeDSTFlagStatus) {
								// update the flag status...
								dwSysTimeDSTFlagStatus = dwTime;
								//Log appropriate Message here..
								QString strDSTChange("");
								if (dwSysTimeDSTFlagStatus == TIME_ZONE_ID_DAYLIGHT) {
									strDSTChange = QString::asprintf(IDS_ENTERING_DAYLIGHT_SAVING);
									qDebug("Recorder now operating in daylight saving time \n");
								} else {
									strDSTChange = QString::asprintf(IDS_ENTERING_STANDARD_TIME);
									qDebug("Recorder now operating in standard time \n");
								}
								LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_INFORMATION, strDSTChange);
							}
						}									// End to log the DST/SDT message in the recorder
						CeRunAppAtTime( DSTNOTIFICATION, NULL);
						// Recalibrate the DST event
						CDSTChangeNotificationThread::SetupNextDSTEvent(bFirstTime);
					}
				}
					break;
				case WAIT_OBJECT_0 + 1:
					// reset the event
					ResetEvent(hLogonEvent);
					LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR,
							"Network Logon failure - please check Network Admin account details");
					break;
				case WAIT_TIMEOUT:
					//qDebug("TimeChangeNotify timeout" );
					break;
				case WAIT_ABANDONED:
					//qDebug("TimeChangeNotify abandoned" );
					break;
				case WAIT_FAILED:
					//qDebug("TimeChangeNotify failed" );
					break;
				default:
					//qDebug("TimeChangeNotify default" );
					break;
				} // End of SWITCH
			} else {
				if (pThreadInfo != NULL) {
					//Update the Thread Counter for the TimeChangeNotifyThread
					pThreadInfo->UpdateThreadCounter(AM_TIME_CHANGE_NOTIFY);
				}
				// event is NULL therefore just sleep
				sleep(1000);
			}
		}
			break;
		case tcnINIT: {
			if (pThreadInfo != NULL) {
				//Update the Thread Counter for the TimeChangeNotifyThread
				pThreadInfo->UpdateThreadCounter(AM_TIME_CHANGE_NOTIFY);
			}
			// make sure the time is synchronised before we kick this thread off in case
			// we have missed a time change event at startup (via SNTP)
			pDALGLB->SyncTime();
			pSYSTIMER->RegisterATimeChange();
			ms_hEvent = CreateEvent(NULL, FALSE, FALSE, TIME_CHANGE_EVENT);
			CeRunAppAtEvent( TIME_CHANGE_NOTIFICATION, NOTIFICATION_EVENT_TIME_CHANGE);
			ms_hEvent = OpenEvent(EVENT_ALL_ACCESS, FALSE, TIME_CHANGE_EVENT);
			hLogonEvent = CreateEvent(NULL, FALSE, FALSE, LOGON_EVENT);
			hLogonEvent = OpenEvent(EVENT_ALL_ACCESS, FALSE, LOGON_EVENT);
			ms_eState = tcnRUNNING;
			//---------------------------------------------------------------
			// Flag to maintains the state of DST /SDT 
			//---------------------------------------------------------------
			CTVtime currTime;
			QDateTime pSysCurrTime;
			currTime.TimeNow();
			currTime.GetSYSTEMTIME(&pSysCurrTime);
			TIME_ZONE_INFORMATION tzi;
			GetTimeZoneInformation(&tzi);
			// If the system supports DST verify that the kernel returned the correct
			// value, otherwise make sure the kerel is in SDT
			if (pSYSTIMER->LocaleSupportsDST(&tzi)) {
				// Check with the curr time to set the dwSysTimeDSTFlagStatus...
				dwSysTimeDSTFlagStatus = pSYSTIMER->CheckTime(pSysCurrTime, tzi);
			}					// End to log the DST/SDT message in the recorder
			// DST event triggerring Initialization
			// This fix is added as Win CE 7 OS is not sending NOTIFICATION_EVENT_TIME_CHANGE
			// which was sent properly in Win CE 5
			hDSTEvent = CreateEvent(NULL, FALSE, FALSE, DSTEVENT);
			if (CDSTChangeNotificationThread::SetupNextDSTEvent(bFirstTime)) {
				bFirstTime = false;
				hDSTEvent = OpenEvent(EVENT_ALL_ACCESS, FALSE, DSTEVENT);
			}
		}
			break;
		case tcnSHUTDOWN:
		default:
			// set to shutdown if not already so
			ms_eState = tcnSHUTDOWN;
			break;
		}
		if (pThreadInfo != NULL) {
			//Update the Thread Counter for the TimeChangeNotifyThread
			//thread after each iteration
			pThreadInfo->UpdateThreadCounter(AM_TIME_CHANGE_NOTIFY);
		}
	}
	//No need to close the mutex in Qt
	//No need to close the mutex in Qt
	//No need to close the mutex in Qt
	ms_hEvent = NULL;
	hDSTEvent = NULL;
	hLogonEvent = NULL;
	if (pThreadInfo != NULL) {
		//Update the info that the TimeChangeNotify thread is exiting
		//Hence this thread need not be considered to kick the 
		//watchdog
		pThreadInfo->UpdateThreadInfo(AM_TIME_CHANGE_NOTIFY, false);
	}
	return 0;
}

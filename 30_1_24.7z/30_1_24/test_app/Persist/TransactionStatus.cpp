/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	Persist Manager
/// @n Filename: TransactionStatus.cpp
/// @n Desc:	Keep track of transactions using NV 
///				
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 6	Stability Project 1.1.1.3	7/2/2011 5:02:10 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 5	Stability Project 1.1.1.2	7/1/2011 4:39:02 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 4	Stability Project 1.1.1.1	3/17/2011 3:20:51 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 3	Stability Project 1.1.1.0	2/15/2011 3:04:05 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
// ****************************************************************
#include "SRAM.h"
#include "TransactionStatus.h"
T_TRANSACTION_HOLDER *CTransactionStatus::pTransactionBase;
//****************************************************************************
/// Initialise the 
///
//****************************************************************************
BOOL CTransactionStatus::Initialise() {
	CSRAMManager *pSRAM;						///< SRAM manager
	CSRAMRegion *pTstore = NULL;
	// Create NV data block pointer
	pSRAM = CSRAMManager::GetHandle();
	// Request a ptr to the CSRAMRegion instance for the corrisponding regionIdent
	CSRAMManager::regionError requestReturn = pSRAM->RequestRegion(REGION_TRANSACTION, &pTstore);
	if (requestReturn != CSRAMManager::REGION_OKAY) {
		qDebug((" CRITICAL error\n"));
		return FALSE;
	}
	// Get the RAM region address
	pTransactionBase = reinterpret_cast<T_TRANSACTION_HOLDER*>(pTstore->GetAddress());
	// If the SRAM has not been used yet, clewar it down.
	if (pTstore->GetAutoState() == SRAM_STATE_FIRSTUSE) {
		memset(pTransactionBase, 0, pTstore->GetAvailableBytes());
	}
	// Run through and make sure any new transactions are initialised correctly.
	for (int transactionIdent = 0; transactionIdent < TRANS_IDENT_MAX; transactionIdent++) {
		// If the identifier in SRAM is not the same as the identifier it expects, assume this was added and
		// initialise the Transaction holder.
		if (pTransactionBase[transactionIdent].ident != transactionIdent) {
			pTransactionBase[transactionIdent].ident = static_cast<T_TRANSACTION_IDENT>(transactionIdent);
			pTransactionBase[transactionIdent].Status = TRANSACTION_STATUS_NORMAL;
		}
	}
	pTstore->SetAutoStateToNormal();
	return TRUE;
}
//****************************************************************************
/// Get the current status of the transaction 
///
/// @param[in] 	ident, T_TRANSACTION_IDENT as transaction identifier
/// @param[out] pData, pointer to holder for user defined data, or NULL if not required
///
/// @return T_TRANSACTION_STATUS of the idetifier
/// 
//****************************************************************************
T_TRANSACTION_STATUS CTransactionStatus::GetStatus(T_TRANSACTION_IDENT ident, DWORD *pData) {
	T_TRANSACTION_STATUS retStatus;
	retStatus = pTransactionBase[ident].Status;
	if (pData != NULL) {
		*pData = pTransactionBase[ident].userData;
	}
	return retStatus;
}
//****************************************************************************
/// Set a status of a transaction
///
/// @param[in] 	ident, T_TRANSACTION_IDENT as transaction identifier
/// @param[in] 	status, T_TRANSACTION_STATUS of status to set
/// @param[in] 	data, DWORD of user defined data to store
///
/// @return Status instance or STATUS_INVALID if Instance is invalid
/// 
//****************************************************************************
void CTransactionStatus::SetStatus(T_TRANSACTION_IDENT ident, T_TRANSACTION_STATUS status, DWORD data) {
	pTransactionBase[ident].Status = status;
	pTransactionBase[ident].userData = data;
}

#include "PWInteractionEvent.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
#ifdef DBG_FILE_LOG_NETSYNC_MACRO
	QString  strLog;
	CDebugFileLogger CPWInteractionEvent::m_debugFileLogger(L"\\SDMemory\\PwdNetSync_STATES.txt", FALSE, (10*1024*1024));
#endif
CPWInteractionEvent::CPWInteractionEvent() {
	pHandler = NULL;
	QMutex * m_csProtect;
}
CPWInteractionEvent::~CPWInteractionEvent() {
	if (m_pMonItem) {
		m_pMonItem->bCompleted = TRUE;
		/*#ifdef DBG_FILE_LOG_NETSYNC_MACRO	
		 strLog = QString::asprintf("CPWInteractionEvent::DTOR...Setting m_pMonItem->bCompleted = TRUE .. GTC - %d\r\n",GetTickCount());
		 CPWInteractionEvent::m_debugFileLogger.WriteToDebugLogFile(strLog);
		 #endif*/
	}
	//No need to close the mutex in Qt
}
CPWInteractionEvent::CPWInteractionEvent(T_SCENARIO_TYPE type, T_INTERACTION_ID *pID, T_INT_MON_ITEM *pNewMonItem) {
	/*#ifdef DBG_FILE_LOG_NETSYNC_MACRO	
	 strLog = QString::asprintf("CPWInteractionEvent::CTOR...<ENTRY>... GTC - %d\r\n",GetTickCount());
	 CPWInteractionEvent::m_debugFileLogger.WriteToDebugLogFile(strLog);
	 #endif*/
	m_pMonItem = pNewMonItem;
	if (m_pMonItem) {
		memcpy(&m_pMonItem->ID, pID, sizeof(T_INTERACTION_ID));
		m_pMonItem->LastAction = EV_ACT_NO_ACTION;
		m_pMonItem->LastState = SCN_ST_UNINITIALISED;
		m_pMonItem->bCompleted = FALSE;
	}
	//populate the handler function pointer with the required function
	switch (type) {
	case INT_EV_HEALTH_CHECK:
		pHandler = &CPWInteractionEvent::HealthCheckHandler;
		break;
	case INT_EV_SLAVE_JOIN_MASTER:
		pHandler = &CPWInteractionEvent::SlaveJoinMasterHandler;
		break;
//	case INT_EV_MASTER_KICK_SLAVE:
//		pHandler = &CPWInteractionEvent::MasterKickSlaveHandler;
//		break;
	case INT_EV_SLAVE_LEAVE_GROUP:
		pHandler = &CPWInteractionEvent::SlaveLeaveGroupHandler;
		break;
	case INT_EV_TOKEN_EXCHANGE:
		pHandler = &CPWInteractionEvent::TokenExchangeHandler;
		break;
	case INT_EV_FULL_DATA_UPDATE:
		pHandler = &CPWInteractionEvent::FullDataUpdateHandler;
		break;
	case INT_EV_FULL_USER_UPDATE:
		pHandler = &CPWInteractionEvent::FullUserUpdateHandler;
		break;
	case INT_EV_USER_UPDATE:
		pHandler = &CPWInteractionEvent::UserUpdateHandler;
		break;
	case INT_EV_POLICY_UPDATE:
		pHandler = &CPWInteractionEvent::PolicyUpdateHandler;
		break;
	case INT_EV_GROUPLIST_UPDATE:
		pHandler = &CPWInteractionEvent::GroupListUpdateHandler;
		break;
	case INT_EV_MEMBERSHIP_CONFIRM:
		pHandler = &CPWInteractionEvent::MembershipConfirmHandler;
		break;
	case INT_EV_SLAVE_PROMOTED:
		pHandler = &CPWInteractionEvent::SlavePromotedHandler;
		break;
	default:
		pHandler = &CPWInteractionEvent::DefaultHandler;
		break;
	}
	m_ScenarioType = type;
	m_ScenarioState = SCN_ST_UNINITIALISED;
	QMutex * m_csProtect;
	m_dwInitTime = ::GetTickCount();
	memcpy(&m_InteractionId, pID, sizeof(m_InteractionId));
	QString csTmp;
	csTmp = QString::asprintf("IntEv%d-%d-%d", pID->ulOriginator, pID->ulRecipient, pID->usMajSeq);
	m_Event = CreateEvent(NULL, TRUE, FALSE, csTmp);
	/*#ifdef DBG_FILE_LOG_NETSYNC_MACRO	
	 strLog = QString::asprintf("CPWInteractionEvent::CTOR...<EXIT>... GTC - %d\r\n",GetTickCount());
	 CPWInteractionEvent::m_debugFileLogger.WriteToDebugLogFile(strLog);
	 #endif*/
}
T_EVENT_ACTION CPWInteractionEvent::SubmitEvent(T_EVENT_ACTION Action) {
#ifdef DBG_FILE_LOG_NETSYNC_MACRO	
		QString  szEvent = ConvertTransEnumToString(Action);
		QString  szScenario = ConvertScenarioTypeEnumToString(m_ScenarioState);	
		strLog = QString::asprintf("CPWInteractionEvent::SubmitEvent..<ENTRY>.. Event:%s...Last State: %s .. GTC - %d\r\n",szEvent,szScenario,GetTickCount());
		CPWInteractionEvent::m_debugFileLogger.WriteToDebugLogFile(strLog);
	#endif
	T_EVENT_ACTION actRet;
	if (pHandler) {
		m_csProtect.lock();
		actRet = (this->*pHandler)(Action);
		m_csProtect.lock();
		/*	#ifdef DBG_FILE_LOG_NETSYNC_MACRO	
		 QString  szEvent = ConvertTransEnumToString(actRet);
		 strLog = QString::asprintf("CPWInteractionEvent::SubmitEvent...pHandler IS NOT NULL..Scenario NEXT ACTION: %s..szEvent GTC - %d\r\n",szEvent,GetTickCount());
		 CPWInteractionEvent::m_debugFileLogger.WriteToDebugLogFile(strLog);
		 #endif*/
	} else {
#ifdef DBG_FILE_LOG_NETSYNC_MACRO	
			strLog = QString::asprintf("CPWInteractionEvent::SubmitEvent...Event: %s..pHandler NULL..EV_ACT_INVALID.. GTC - %d\r\n",szEvent,GetTickCount());
			CPWInteractionEvent::m_debugFileLogger.WriteToDebugLogFile(strLog);
		#endif
		actRet = EV_ACT_INVALID;
	}
#ifdef TRACE_ALLOW
	qDebug("Interaction ID: %d-%d-%d: Type: %d: Action: %d: Result: %d\n", m_InteractionId.ulOriginator, m_InteractionId.ulRecipient,m_InteractionId.usMajSeq,m_ScenarioType,Action,actRet);
#endif
	if (m_pMonItem) {
		/*#ifdef DBG_FILE_LOG_NETSYNC_MACRO	
		 QString  szEvent = ConvertTransEnumToString(actRet);	
		 QString  szScenario = ConvertScenarioTypeEnumToString(m_ScenarioState);	
		 strLog = QString::asprintf("CPWInteractionEvent::SubmitEvent...Last Action: %s Last State: %s .. GTC - %d\r\n",actRet,szScenario,GetTickCount());
		 CPWInteractionEvent::m_debugFileLogger.WriteToDebugLogFile(strLog);
		 #endif*/
		m_pMonItem->LastAction = actRet;
		m_pMonItem->LastState = m_ScenarioState;
		if (actRet == EV_ACT_END_TRANS) {
			m_pMonItem->bCompleted = TRUE;
#ifdef DBG_FILE_LOG_NETSYNC_MACRO	
				strLog = QString::asprintf("CPWInteractionEvent::SubmitEvent: %s Setting m_pMonItem->bCompleted = TRUE .. GTC - %d\r\n",szEvent,GetTickCount());
				CPWInteractionEvent::m_debugFileLogger.WriteToDebugLogFile(strLog);
			#endif
		}
	}
#ifdef DBG_FILE_LOG_NETSYNC_MACRO	
		QString  sActRetEvent = ConvertTransEnumToString(actRet);	
		szScenario = ConvertScenarioTypeEnumToString(m_ScenarioState);	
		strLog = QString::asprintf("CPWInteractionEvent::SubmitEvent: %s...Last State: %s Last Action: %s .. GTC - %d\r\n",szEvent,szScenario,sActRetEvent,GetTickCount());
		CPWInteractionEvent::m_debugFileLogger.WriteToDebugLogFile(strLog);
	#endif
	return actRet;
}
//Handlers for scenario States
T_EVENT_ACTION CPWInteractionEvent::HealthCheckHandler(T_EVENT_ACTION Action) {
	T_EVENT_ACTION actRet = EV_ACT_NO_ACTION;
	switch (m_ScenarioState) {
	case SCN_ST_UNINITIALISED:
		switch (Action) {
		case EV_ACT_PING:
			//sent or recieved a ping - go to ping state respond with a response
			m_ScenarioState = SCN_ST_PING;
			actRet = EV_ACT_PING_RESP;
			break;
		case EV_ACT_PING_RESP:
			//sent or recieved a ping response - end the transaction
			m_ScenarioState = SCN_ST_PING_RESP;
			actRet = EV_ACT_END_TRANS;
			break;
		default:
			break;
		}
		break;
	case SCN_ST_PING:
		switch (Action) {
		case EV_ACT_PING:
			//do nothing as a ping state has already been set
			actRet = EV_ACT_NO_ACTION;
			break;
		case EV_ACT_PING_RESP:
			//an expected response to a ping has been sent. end the transaction
			m_ScenarioState = SCN_ST_PING_RESP;
			actRet = EV_ACT_END_TRANS;
			break;
		default:
			break;
		}
		break;
	case SCN_ST_PING_RESP:
		switch (Action) {
		case EV_ACT_PING:
			actRet = EV_ACT_NO_ACTION;
			break;
		case EV_ACT_PING_RESP:
			actRet = EV_ACT_END_TRANS;
			break;
		default:
			break;
		}
		break;
	default:
		break;
	}
	return actRet;
}
T_EVENT_ACTION CPWInteractionEvent::SlaveJoinMasterHandler(T_EVENT_ACTION Action) {
	T_EVENT_ACTION actRet = EV_ACT_NO_ACTION;
	switch (m_ScenarioState) {
	case SCN_ST_UNINITIALISED:
		//first actions set the main state
		switch (Action) {
		case EV_ACT_JOIN_GRP_INV:
			//join invite sent. set return action to accept
			m_ScenarioState = SCN_ST_JOIN_GRP_INV;
			actRet = EV_ACT_JOIN_GRP_ACC;
			break;
		case EV_ACT_JOIN_GRP_REQ:
			//request sent. set return to accept
			m_ScenarioState = SCN_ST_JOIN_GRP_REQ;
			actRet = EV_ACT_JOIN_GRP_ACC;
			break;
		case EV_ACT_JOIN_GRP_DENY:
			actRet = EV_ACT_END_TRANS;
			break;
		default:
			break;
		}
		break;
	case SCN_ST_JOIN_GRP_REQ:
	case SCN_ST_JOIN_GRP_INV:
		switch (Action) {
		case EV_ACT_JOIN_GRP_DENY:
		case EV_ACT_JOIN_GRP_ACC:
			//end the transaction since a new transaction will be created for the next step
			//m_ScenarioState = SCN_ST_JOIN_GRP_ACC;
			actRet = EV_ACT_END_TRANS;
			break;
		default:
			break;
		}
		break;
	default:
		break;
	}
	return actRet;
}
//T_EVENT_ACTION CPWInteractionEvent::MasterKickSlaveHandler(T_EVENT_ACTION Action)
//{
//	T_EVENT_ACTION actRet = EV_ACT_NO_ACTION;
//	switch (m_ScenarioState)
//	{
//	case SCN_ST_UNINITIALISED:
//		switch(Action)
//		{
//
//		}
//		break;
//	default:
//		break;
//	}
//	return actRet;
//}
T_EVENT_ACTION CPWInteractionEvent::SlaveLeaveGroupHandler(T_EVENT_ACTION Action) {
	T_EVENT_ACTION actRet = EV_ACT_NO_ACTION;
	switch (m_ScenarioState) {
	case SCN_ST_UNINITIALISED:
		switch (Action) {
		case EV_ACT_LEAV_GRP_REQ:
			m_ScenarioState = SCN_ST_LEAVE_GRP_REQ;
			actRet = EV_ACT_LEAV_GRP_ACC;
			break;
		case EV_ACT_LEAV_GRP_PUSH:
			m_ScenarioState = SCN_ST_LEAVE_GRP_PUSH;
			actRet = EV_ACT_LEAV_GRP_ACC;
			break;
		default:
			break;
		}
		break;
	case SCN_ST_LEAVE_GRP_PUSH:
	case SCN_ST_LEAVE_GRP_REQ:
		if (EV_ACT_LEAV_GRP_ACC == Action)
			actRet = EV_ACT_END_TRANS;
		break;
	default:
		break;
	}
	return actRet;
}
T_EVENT_ACTION CPWInteractionEvent::SlavePromotedHandler(T_EVENT_ACTION Action) {
	T_EVENT_ACTION actRet = EV_ACT_NO_ACTION;
	switch (m_ScenarioState) {
	case SCN_ST_UNINITIALISED:
		switch (Action) {
		case EV_ACT_MAST_CHG_OVTH:
			m_ScenarioState = SCN_ST_MAST_CHG_OVTH;
			actRet = EV_ACT_MAST_CHG_PROM;
			break;
		case EV_ACT_MAST_CHG_PROM:
			m_ScenarioState = SCN_ST_MAST_CHG_PROM;
			actRet = EV_ACT_MAST_CHG_ACC;
			break;
		case EV_ACT_MAST_CHG_INF:
			m_ScenarioState = SCN_ST_MAST_CHG_INF;
			actRet = EV_ACT_MAST_CHG_ACC;
			break;
		case EV_ACT_MAST_CHG_DENY:
			actRet = EV_ACT_END_TRANS;
			break;
		case EV_ACT_MAST_CHG_ACC:
			m_ScenarioState = SCN_ST_MAST_CHG_ACC;
			actRet = EV_ACT_END_TRANS;
			break;
		default:
			break;
		}
		break;
	case SCN_ST_MAST_CHG_OVTH:
		if (EV_ACT_MAST_CHG_PROM == Action) {
			m_ScenarioState = SCN_ST_MAST_CHG_PROM;
			actRet = EV_ACT_MAST_CHG_ACC;
		} else if (EV_ACT_MAST_CHG_DENY == Action)
			actRet = EV_ACT_END_TRANS;
		break;
	case SCN_ST_MAST_CHG_PROM:
		if (EV_ACT_MAST_CHG_ACC == Action) {
			m_ScenarioState = SCN_ST_MAST_CHG_ACC;
			actRet = EV_ACT_END_TRANS;
		} else if (EV_ACT_MAST_CHG_DENY == Action)
			actRet = EV_ACT_END_TRANS;
		break;
	case SCN_ST_MAST_CHG_ACC:
		if (EV_ACT_MAST_CHG_DENY == Action)
			actRet = EV_ACT_END_TRANS;
		break;
	case SCN_ST_MAST_CHG_INF:
		if (EV_ACT_MAST_CHG_ACC == Action || EV_ACT_MAST_CHG_DENY == Action)
			actRet = EV_ACT_END_TRANS;
		break;
	default:
		break;
	}
	return actRet;
}
T_EVENT_ACTION CPWInteractionEvent::FullDataUpdateHandler(T_EVENT_ACTION Action) {
	/*#ifdef DBG_FILE_LOG_NETSYNC_MACRO	
	 strLog = QString::asprintf("CPWInteractionEvent::FullDataUpdateHandler...<ENTRY>... GTC - %d\r\n",GetTickCount());
	 CPWInteractionEvent::m_debugFileLogger.WriteToDebugLogFile(strLog);
	 #endif*/
	T_EVENT_ACTION actRet = EV_ACT_NO_ACTION;
	switch (m_ScenarioState) {
	case SCN_ST_UNINITIALISED:
#ifdef DBG_FILE_LOG_NETSYNC_MACRO	
			strLog = QString::asprintf("CPWInteractionEvent::FullDataUpdateHandler...SCN_ST_UNINITIALISED... GTC - %d\r\n",GetTickCount());
			CPWInteractionEvent::m_debugFileLogger.WriteToDebugLogFile(strLog);
		#endif
		switch (Action) {
		case EV_ACT_FULL_PMM_REQ:
#ifdef DBG_FILE_LOG_NETSYNC_MACRO	
				strLog = QString::asprintf("CPWInteractionEvent::FullDataUpdateHandler...ACT: EV_ACT_FULL_PMM_REQ SCN:SCN_ST_FULL_PMM_REQ...ACTRET: EV_ACT_FULL_PMM_SEND.. GTC - %d\r\n",GetTickCount());
				CPWInteractionEvent::m_debugFileLogger.WriteToDebugLogFile(strLog);
			#endif
			m_ScenarioState = SCN_ST_FULL_PMM_REQ;
			actRet = EV_ACT_FULL_PMM_SEND;
			break;
		case EV_ACT_FULL_PMM_SEND:
#ifdef DBG_FILE_LOG_NETSYNC_MACRO	
				strLog = QString::asprintf("CPWInteractionEvent::FullDataUpdateHandler...ACT: EV_ACT_FULL_PMM_SEND SCN:SCN_ST_FULL_PMM_SEND...ACTRET: EV_ACT_FULL_PMM_ACC.. GTC - %d\r\n",GetTickCount());
				CPWInteractionEvent::m_debugFileLogger.WriteToDebugLogFile(strLog);
			#endif
			m_ScenarioState = SCN_ST_FULL_PMM_SEND;
			actRet = EV_ACT_FULL_PMM_ACC;
			break;
		case EV_ACT_FULL_PMM_ACC:
		case EV_ACT_FULL_PMM_DENY:
#ifdef DBG_FILE_LOG_NETSYNC_MACRO	
				strLog = QString::asprintf("CPWInteractionEvent::FullDataUpdateHandler...ACT: EV_ACT_FULL_PMM_ACC/DEMY SCN:NA...ACTRET: NA.. GTC - %d\r\n",GetTickCount());
				CPWInteractionEvent::m_debugFileLogger.WriteToDebugLogFile(strLog);
			#endif
			//unexpected
		default:
			break;
		}
		break;
	case SCN_ST_FULL_PMM_REQ:
#ifdef DBG_FILE_LOG_NETSYNC_MACRO	
			strLog = QString::asprintf("CPWInteractionEvent::FullDataUpdateHandler...SCN_ST_FULL_PMM_REQ... GTC - %d\r\n",GetTickCount());
			CPWInteractionEvent::m_debugFileLogger.WriteToDebugLogFile(strLog);
		#endif
		switch (Action) {
		case EV_ACT_FULL_PMM_SEND:
#ifdef DBG_FILE_LOG_NETSYNC_MACRO	
				strLog = QString::asprintf("CPWInteractionEvent::FullDataUpdateHandler...ACT: EV_ACT_FULL_PMM_SEND SCN:SCN_ST_FULL_PMM_SEND...ACTRET: EV_ACT_FULL_PMM_ACC.. GTC - %d\r\n",GetTickCount());
				CPWInteractionEvent::m_debugFileLogger.WriteToDebugLogFile(strLog);
			#endif
			m_ScenarioState = SCN_ST_FULL_PMM_SEND;
			actRet = EV_ACT_FULL_PMM_ACC;
			break;
		case EV_ACT_FULL_PMM_DENY:
#ifdef DBG_FILE_LOG_NETSYNC_MACRO	
				strLog = QString::asprintf("CPWInteractionEvent::FullDataUpdateHandler...ACT: EV_ACT_FULL_PMM_DENY SCN:SCN_ST_FULL_PMM_DENY...ACTRET: EV_ACT_END_TRANS.. GTC - %d\r\n",GetTickCount());
				CPWInteractionEvent::m_debugFileLogger.WriteToDebugLogFile(strLog);
			#endif
			m_ScenarioState = SCN_ST_FULL_PMM_DENY;
			actRet = EV_ACT_END_TRANS;
			break;
		}
		break;
	case SCN_ST_FULL_PMM_SEND:
#ifdef DBG_FILE_LOG_NETSYNC_MACRO	
			strLog = QString::asprintf("CPWInteractionEvent::FullDataUpdateHandler...SCN_ST_FULL_PMM_SEND..GTC - %d\r\n",GetTickCount());
			CPWInteractionEvent::m_debugFileLogger.WriteToDebugLogFile(strLog);
		#endif
		if (EV_ACT_FULL_PMM_ACC == Action || EV_ACT_FULL_PMM_DENY == Action) {
#ifdef DBG_FILE_LOG_NETSYNC_MACRO	
				strLog = QString::asprintf("CPWInteractionEvent::FullDataUpdateHandler...ACT: EV_ACT_FULL_PMM_ACC/DENY SCN:SCN_ST_FULL_PMM_SEND...ACTRET: EV_ACT_END_TRANS.. GTC - %d\r\n",GetTickCount());
				CPWInteractionEvent::m_debugFileLogger.WriteToDebugLogFile(strLog);
			#endif
			actRet = EV_ACT_END_TRANS;
		}
		break;
	default:
		break;
	}
	/*#ifdef DBG_FILE_LOG_NETSYNC_MACRO	
	 strLog = QString::asprintf("CPWInteractionEvent::FullDataUpdateHandler...<EXIT>... GTC - %d\r\n",GetTickCount());
	 CPWInteractionEvent::m_debugFileLogger.WriteToDebugLogFile(strLog);
	 #endif*/
	return actRet;
}
T_EVENT_ACTION CPWInteractionEvent::FullUserUpdateHandler(T_EVENT_ACTION Action) {
	T_EVENT_ACTION actRet = EV_ACT_NO_ACTION;
	switch (m_ScenarioState) {
	case SCN_ST_UNINITIALISED:
		switch (Action) {
		case EV_ACT_ALL_USER_REQ:
			m_ScenarioState = SCN_ST_ALL_USER_REQ;
			actRet = EV_ACT_ALL_USER_SEND;
			break;
		case EV_ACT_ALL_USER_SEND:
			m_ScenarioState = SCN_ST_ALL_USER_SEND;
			actRet = EV_ACT_ALL_USER_ACC;
			break;
		case EV_ACT_ALL_USER_ACC:
		case EV_ACT_ALL_USER_DENY:
		default:
			break;
		}
		break;
	case SCN_ST_ALL_USER_REQ:
		switch (Action) {
		case EV_ACT_ALL_USER_SEND:
			m_ScenarioState = SCN_ST_ALL_USER_SEND;
			actRet = EV_ACT_ALL_USER_ACC;
			break;
		case EV_ACT_ALL_USER_DENY:
			m_ScenarioState = SCN_ST_ALL_USER_DENY;
			actRet = EV_ACT_END_TRANS;
			break;
		default:
			break;
		}
		break;
	case SCN_ST_ALL_USER_SEND:
		if (EV_ACT_ALL_USER_ACC == Action || EV_ACT_ALL_USER_DENY == Action)
			actRet = EV_ACT_END_TRANS;
		break;
	case SCN_ST_ALL_USER_ACC:
	case SCN_ST_ALL_USER_DENY:
	default:
		break;
	}
	return actRet;
}
T_EVENT_ACTION CPWInteractionEvent::UserUpdateHandler(T_EVENT_ACTION Action) {
	T_EVENT_ACTION actRet = EV_ACT_NO_ACTION;
	switch (m_ScenarioState) {
	case SCN_ST_UNINITIALISED:
		switch (Action) {
		case EV_ACT_SIN_USER_REQ:
			m_ScenarioState = SCN_ST_SIN_USER_REQ;
			actRet = EV_ACT_SIN_USER_SEND;
			break;
		case EV_ACT_SIN_USER_SEND:
			m_ScenarioState = SCN_ST_SIN_USER_SEND;
			actRet = EV_ACT_SIN_USER_ACC;
			break;
		case EV_ACT_SIN_USER_ACC:
		case EV_ACT_SIN_USER_DENY:
		default:
			break;
		}
		break;
	case SCN_ST_SIN_USER_REQ:
		switch (Action) {
		case EV_ACT_SIN_USER_SEND:
			m_ScenarioState = SCN_ST_SIN_USER_SEND;
			actRet = EV_ACT_SIN_USER_ACC;
			break;
		case EV_ACT_SIN_USER_DENY:
			m_ScenarioState = SCN_ST_SIN_USER_DENY;
			actRet = EV_ACT_END_TRANS;
			break;
		default:
			break;
		}
		break;
	case SCN_ST_SIN_USER_SEND:
		if (EV_ACT_SIN_USER_ACC == Action || EV_ACT_SIN_USER_DENY == Action)
			actRet = EV_ACT_END_TRANS;
		break;
	case SCN_ST_SIN_USER_ACC:
	case SCN_ST_SIN_USER_DENY:
	default:
		break;
	}
	return actRet;
}
T_EVENT_ACTION CPWInteractionEvent::PolicyUpdateHandler(T_EVENT_ACTION Action) {
	T_EVENT_ACTION actRet = EV_ACT_NO_ACTION;
	switch (m_ScenarioState) {
	case SCN_ST_UNINITIALISED:
		switch (Action) {
		case EV_ACT_POLICY_REQ:
			m_ScenarioState = SCN_ST_POLICY_REQ;
			actRet = EV_ACT_POLICY_SEND;
			break;
		case EV_ACT_POLICY_SEND:
			m_ScenarioState = SCN_ST_POLICY_SEND;
			actRet = EV_ACT_POLICY_ACC;
			break;
		case EV_ACT_POLICY_ACC:
		case EV_ACT_POLICY_DENY:
		default:
			break;
		}
		break;
	case SCN_ST_POLICY_REQ:
		switch (Action) {
		case EV_ACT_POLICY_SEND:
			m_ScenarioState = SCN_ST_POLICY_SEND;
			actRet = EV_ACT_POLICY_ACC;
			break;
		case EV_ACT_POLICY_DENY:
			m_ScenarioState = SCN_ST_POLICY_DENY;
			actRet = EV_ACT_END_TRANS;
			break;
		default:
			break;
		}
		break;
	case SCN_ST_POLICY_SEND:
		if (EV_ACT_POLICY_ACC == Action || EV_ACT_POLICY_DENY == Action)
			actRet = EV_ACT_END_TRANS;
		break;
	case SCN_ST_POLICY_ACC:
	case SCN_ST_POLICY_DENY:
	default:
		break;
	}
	return actRet;
}
T_EVENT_ACTION CPWInteractionEvent::GroupListUpdateHandler(T_EVENT_ACTION Action) {
	T_EVENT_ACTION actRet = EV_ACT_NO_ACTION;
	switch (m_ScenarioState) {
	case SCN_ST_UNINITIALISED:
		switch (Action) {
		case EV_ACT_GROUPLIST_REQ:
			m_ScenarioState = SCN_ST_GROUPLIST_REQ;
			actRet = EV_ACT_GROUPLIST_UPDATE;
			break;
		case EV_ACT_GROUPLIST_UPDATE:
			m_ScenarioState = SCN_ST_GROUPLIST_UPDATE;
			actRet = EV_ACT_GROUPLIST_ACC;
			break;
		case EV_ACT_GROUPLIST_ACC:
		case EV_ACT_GROUPLIST_DENY:
			break;
		default:
			break;
		}
		break;
	case SCN_ST_GROUPLIST_REQ:
		switch (Action) {
		case EV_ACT_GROUPLIST_UPDATE:
			m_ScenarioState = SCN_ST_GROUPLIST_ACC;
			actRet = EV_ACT_GROUPLIST_ACC;
			break;
		case EV_ACT_GROUPLIST_DENY:
			m_ScenarioState = SCN_ST_GROUPLIST_DENY;
			actRet = EV_ACT_END_TRANS;
			break;
		case EV_ACT_GROUPLIST_ACC:
		default:
			break;
		}
		break;
	case SCN_ST_GROUPLIST_UPDATE:
		switch (Action) {
		case EV_ACT_GROUPLIST_DENY:
		case EV_ACT_GROUPLIST_ACC:
			actRet = EV_ACT_END_TRANS;
			break;
		case EV_ACT_GROUPLIST_UPDATE:
		case EV_ACT_GROUPLIST_REQ:
		default:
			break;
		}
		break;
	default:
		break;
	}
	return actRet;
}
T_EVENT_ACTION CPWInteractionEvent::TokenExchangeHandler(T_EVENT_ACTION Action) {
	T_EVENT_ACTION actRet = EV_ACT_NO_ACTION;
	switch (m_ScenarioState) {
	case SCN_ST_UNINITIALISED:
		switch (Action) {
		case EV_ACT_TOKEN_REQ:
			m_ScenarioState = SCN_ST_TOKEN_REQ;
			actRet = EV_ACT_TOKEN_GRANT;
			break;
		case EV_ACT_TOKEN_STEAL:
			m_ScenarioState = SCN_ST_TOKEN_STEAL;
			actRet = EV_ACT_TOKEN_RELEASE;
			break;
		case EV_ACT_TOKEN_INFORM:
		case EV_ACT_TOKEN_RELEASE: //done with token
			//single shot msg
			actRet = EV_ACT_END_TRANS;
			break;
		case EV_ACT_TOKEN_GRANT: //should only follow a request
		default:
			break;
		}
		break;
	case SCN_ST_TOKEN_REQ:
		if (EV_ACT_TOKEN_GRANT == Action) {
			m_ScenarioState = SCN_ST_TOKEN_GRANT;
			actRet = EV_ACT_END_TRANS;
		}
		break;
	case SCN_ST_TOKEN_STEAL:
		if (EV_ACT_TOKEN_RELEASE == Action) {
			actRet = EV_ACT_END_TRANS;
		}
		break;
	case SCN_ST_TOKEN_GRANT:
	default:
		break;
	}
	return actRet;
}
T_EVENT_ACTION CPWInteractionEvent::DefaultHandler(T_EVENT_ACTION Action) {
	return Action;
}
T_EVENT_ACTION CPWInteractionEvent::MembershipConfirmHandler(T_EVENT_ACTION Action) {
	//base result
	//Logic table - just change the values in here to modify the outcome
	const T_EVENT_ACTION results[4][3] = { { EV_ACT_MEMB_CONFIRMED, EV_ACT_END_TRANS, EV_ACT_END_TRANS }, {
			EV_ACT_NO_ACTION, EV_ACT_END_TRANS, EV_ACT_END_TRANS }, { EV_ACT_END_TRANS, EV_ACT_END_TRANS,
			EV_ACT_END_TRANS }, { EV_ACT_END_TRANS, EV_ACT_END_TRANS, EV_ACT_END_TRANS } };
	const T_SCENARIO_STATES resState[4][3] = { { SCN_ST_MEMB_CONF_REQ, SCN_ST_MEMB_CONFIRMED, SCN_ST_MEMB_DENIED }, {
			m_ScenarioState, SCN_ST_MEMB_CONFIRMED, SCN_ST_MEMB_DENIED }, { m_ScenarioState, m_ScenarioState,
			m_ScenarioState }, { m_ScenarioState, m_ScenarioState, m_ScenarioState } };
	//check the ranges of the indexers
	if ((SCN_ST_UNINITIALISED == m_ScenarioState || SCN_ST_MEMB_CONF_REQ == m_ScenarioState
			|| SCN_ST_MEMB_CONFIRMED == m_ScenarioState || SCN_ST_MEMB_DENIED == m_ScenarioState)
			&& (EV_ACT_MEMB_CONF_REQ == Action || EV_ACT_MEMB_CONFIRMED == Action || EV_ACT_MEMB_DENIED == Action)) {
		//create the indexers
		int currInd = 0;
		int ActionInd = 0;
		switch (m_ScenarioState) {
		case SCN_ST_MEMB_CONF_REQ:
			currInd = 1;
			break;
		case SCN_ST_MEMB_CONFIRMED:
			currInd = 2;
			break;
		case SCN_ST_MEMB_DENIED:
			currInd = 3;
			break;
		default:
			break;
		}
		switch (Action) {
		case EV_ACT_MEMB_CONFIRMED:
			ActionInd = 1;
			break;
		case EV_ACT_MEMB_DENIED:
			ActionInd = 2;
			break;
		default:
			break;
		}
		m_ScenarioState = resState[currInd][ActionInd];
		return results[currInd][ActionInd];
	} else
		return EV_ACT_NO_ACTION;
}
/* <START> ANOOP 
 QString  CPWInteractionEvent::ConvertTransEnumToString(T_EVENT_ACTION teAct)
 {
 QString  szAction;
 switch(teAct)
 {
 case EV_ACT_NO_ACTION:
 szAction = "EV_ACT_NO_ACTION";
 break;
 case EV_ACT_JOIN_GRP_REQ:
 szAction = "EV_ACT_JOIN_GRP_REQ";
 break;
 case EV_ACT_JOIN_GRP_ACC:
 szAction = "EV_ACT_JOIN_GRP_ACC";
 break;
 case EV_ACT_JOIN_GRP_DENY:
 szAction = "EV_ACT_JOIN_GRP_DENY";
 break;
 case EV_ACT_JOIN_GRP_INV:
 szAction = "EV_ACT_JOIN_GRP_INV";
 break;
 case EV_ACT_LEAV_GRP_REQ:
 szAction = "EV_ACT_LEAV_GRP_REQ";
 break;
 case EV_ACT_LEAV_GRP_ACC:
 szAction = "EV_ACT_LEAV_GRP_ACC";
 break;
 case EV_ACT_LEAV_GRP_PUSH:
 szAction = "EV_ACT_LEAV_GRP_PUSH";
 break;
 case EV_ACT_PING:
 szAction = "EV_ACT_PING";
 break;
 case EV_ACT_PING_RESP:
 szAction = "EV_ACT_PING_RESP";
 break;
 case EV_ACT_MAST_CHG_PROM:
 szAction = "EV_ACT_MAST_CHG_PROM";
 break;
 case EV_ACT_MAST_CHG_INF:
 szAction = "EV_ACT_MAST_CHG_INF";
 break;
 case EV_ACT_MAST_CHG_OVTH:
 szAction = "EV_ACT_MAST_CHG_OVTH";
 break;
 case EV_ACT_MAST_CHG_ACC:
 szAction = "EV_ACT_MAST_CHG_ACC";
 break;
 case EV_ACT_MAST_CHG_DENY:
 szAction = "EV_ACT_MAST_CHG_DENY";
 break;
 case EV_ACT_TOKEN_REQ:
 szAction = "EV_ACT_TOKEN_REQ";
 break;
 case EV_ACT_TOKEN_GRANT:
 szAction = "EV_ACT_TOKEN_GRANT";
 break;
 case EV_ACT_TOKEN_STEAL:
 szAction = "EV_ACT_TOKEN_STEAL";
 break;
 case EV_ACT_TOKEN_INFORM:
 szAction = "EV_ACT_TOKEN_INFORM";
 break;
 case EV_ACT_TOKEN_RELEASE:
 szAction = "EV_ACT_TOKEN_RELEASE";
 break;
 case EV_ACT_FULL_PMM_REQ:
 szAction = "EV_ACT_FULL_PMM_REQ";
 break;
 case EV_ACT_FULL_PMM_SEND:
 szAction = "EV_ACT_FULL_PMM_SEND";
 break;
 case EV_ACT_FULL_PMM_ACC:
 szAction = "EV_ACT_FULL_PMM_ACC";
 break;
 case EV_ACT_FULL_PMM_DENY:
 szAction = "EV_ACT_FULL_PMM_DENY";
 break;
 case EV_ACT_POLICY_REQ:
 szAction = "EV_ACT_POLICY_REQ";
 break;
 case EV_ACT_POLICY_SEND:
 szAction = "EV_ACT_POLICY_SEND";
 break;
 case EV_ACT_POLICY_ACC:
 szAction = "EV_ACT_POLICY_ACC";
 break;
 case EV_ACT_POLICY_DENY:
 szAction = "EV_ACT_POLICY_DENY";
 break;
 case EV_ACT_ALL_USER_REQ:
 szAction = "EV_ACT_ALL_USER_REQ";
 break;
 case EV_ACT_ALL_USER_SEND:
 szAction = "EV_ACT_ALL_USER_SEND";
 break;
 case EV_ACT_ALL_USER_ACC:
 szAction = "EV_ACT_ALL_USER_ACC";
 break;
 case EV_ACT_ALL_USER_DENY:
 szAction = "EV_ACT_ALL_USER_DENY";
 break;
 case EV_ACT_SIN_USER_REQ:
 szAction = "EV_ACT_SIN_USER_REQ";
 break;
 case EV_ACT_SIN_USER_SEND:
 szAction = "EV_ACT_SIN_USER_SEND";
 break;
 case EV_ACT_SIN_USER_ACC:
 szAction = "EV_ACT_SIN_USER_ACC";
 break;
 case EV_ACT_SIN_USER_DENY:
 szAction = "EV_ACT_SIN_USER_DENY";
 break;
 case EV_ACT_PW_ATTEMPT_FAIL:
 szAction = "EV_ACT_PW_ATTEMPT_FAIL";
 break;
 case EV_ACT_GROUPLIST_REQ:
 szAction = "EV_ACT_GROUPLIST_REQ";
 break;
 case EV_ACT_GROUPLIST_UPDATE:
 szAction = "EV_ACT_GROUPLIST_UPDATE";
 break;
 case EV_ACT_GROUPLIST_ACC:
 szAction = "EV_ACT_GROUPLIST_ACC";
 break;
 case EV_ACT_GROUPLIST_DENY:
 szAction = "EV_ACT_GROUPLIST_DENY";
 break;
 case EV_ACT_MEMB_CONF_REQ:
 szAction = "EV_ACT_MEMB_CONF_REQ";
 break;
 case EV_ACT_MEMB_CONFIRMED:
 szAction = "EV_ACT_MEMB_CONFIRMED";
 break;
 case EV_ACT_MEMB_DENIED:
 szAction = "EV_ACT_MEMB_DENIED";
 break;
 case EV_ACT_END_TRANS:
 szAction = "EV_ACT_END_TRANS";
 break;
 case EV_ACT_PW_ATTEMPT_SUCCESS:
 szAction = "EV_ACT_PW_ATTEMPT_SUCCESS";
 break;
 case EV_ACT_INVALID:
 szAction = "EV_ACT_INVALID";
 break;
 
 }
 return szAction;
 }
 QString  CPWInteractionEvent::ConvertScenarioTypeEnumToString(T_SCENARIO_TYPE te)
 {
 QString  szType;
 switch(te)
 {
 
 case	INT_EV_NO_SCENARIO:
 szType = "INT_EV_NO_SCENARIO";
 break;
 case	INT_EV_HEALTH_CHECK:
 szType = "INT_EV_HEALTH_CHECK";
 break;
 case	INT_EV_SLAVE_JOIN_MASTER:	
 szType = "INT_EV_SLAVE_JOIN_MASTER";
 break;
 case	INT_EV_SLAVE_LEAVE_GROUP:
 szType = "INT_EV_SLAVE_LEAVE_GROUP";
 break;
 case	INT_EV_TOKEN_EXCHANGE:
 szType = "INT_EV_TOKEN_EXCHANGE";
 break;
 case	INT_EV_SLAVE_PROMOTED:
 szType = "INT_EV_SLAVE_PROMOTED";
 break;
 case	INT_EV_FULL_DATA_UPDATE:
 szType = "INT_EV_FULL_DATA_UPDATE";
 break;
 case	INT_EV_FULL_USER_UPDATE:
 szType = "INT_EV_FULL_USER_UPDATE";
 break;
 case	INT_EV_USER_UPDATE:
 szType = "INT_EV_USER_UPDATE";
 break;
 case	INT_EV_POLICY_UPDATE:
 szType = "INT_EV_NO_SCENARIO";
 break;
 case	INT_EV_GROUPLIST_UPDATE:
 szType = "INT_EV_GROUPLIST_UPDATE";
 break;
 case	INT_EV_MEMBERSHIP_CONFIRM:
 szType = "INT_EV_MEMBERSHIP_CONFIRM";
 break;
 }
 
 return szType;
 } */
QString CPWInteractionEvent::ConvertTransEnumToString(T_EVENT_ACTION teAct) {
	QString szAction;
	switch (teAct) {
	case EV_ACT_NO_ACTION:
		szAction = "EV_ACT_NO_ACTION";
		break;
	case EV_ACT_JOIN_GRP_REQ:
		szAction = "EV_ACT_JOIN_GRP_REQ";
		break;
	case EV_ACT_JOIN_GRP_ACC:
		szAction = "EV_ACT_JOIN_GRP_ACC";
		break;
	case EV_ACT_JOIN_GRP_DENY:
		szAction = "EV_ACT_JOIN_GRP_DENY";
		break;
	case EV_ACT_JOIN_GRP_INV:
		szAction = "EV_ACT_JOIN_GRP_INV";
		break;
	case EV_ACT_LEAV_GRP_REQ:
		szAction = "EV_ACT_LEAV_GRP_REQ";
		break;
	case EV_ACT_LEAV_GRP_ACC:
		szAction = "EV_ACT_LEAV_GRP_ACC";
		break;
	case EV_ACT_LEAV_GRP_PUSH:
		szAction = "EV_ACT_LEAV_GRP_PUSH";
		break;
	case EV_ACT_PING:
		szAction = "EV_ACT_PING";
		break;
	case EV_ACT_PING_RESP:
		szAction = "EV_ACT_PING_RESP";
		break;
	case EV_ACT_MAST_CHG_PROM:
		szAction = "EV_ACT_MAST_CHG_PROM";
		break;
	case EV_ACT_MAST_CHG_INF:
		szAction = "EV_ACT_MAST_CHG_INF";
		break;
	case EV_ACT_MAST_CHG_OVTH:
		szAction = "EV_ACT_MAST_CHG_OVTH";
		break;
	case EV_ACT_MAST_CHG_ACC:
		szAction = "EV_ACT_MAST_CHG_ACC";
		break;
	case EV_ACT_MAST_CHG_DENY:
		szAction = "EV_ACT_MAST_CHG_DENY";
		break;
	case EV_ACT_TOKEN_REQ:
		szAction = "EV_ACT_TOKEN_REQ";
		break;
	case EV_ACT_TOKEN_GRANT:
		szAction = "EV_ACT_TOKEN_GRANT";
		break;
	case EV_ACT_TOKEN_STEAL:
		szAction = "EV_ACT_TOKEN_STEAL";
		break;
	case EV_ACT_TOKEN_INFORM:
		szAction = "EV_ACT_TOKEN_INFORM";
		break;
	case EV_ACT_TOKEN_RELEASE:
		szAction = "EV_ACT_TOKEN_RELEASE";
		break;
	case EV_ACT_FULL_PMM_REQ:
		szAction = "EV_ACT_FULL_PMM_REQ";
		break;
	case EV_ACT_FULL_PMM_SEND:
		szAction = "EV_ACT_FULL_PMM_SEND";
		break;
	case EV_ACT_FULL_PMM_ACC:
		szAction = "EV_ACT_FULL_PMM_ACC";
		break;
	case EV_ACT_FULL_PMM_DENY:
		szAction = "EV_ACT_FULL_PMM_DENY";
		break;
	case EV_ACT_POLICY_REQ:
		szAction = "EV_ACT_POLICY_REQ";
		break;
	case EV_ACT_POLICY_SEND:
		szAction = "EV_ACT_POLICY_SEND";
		break;
	case EV_ACT_POLICY_ACC:
		szAction = "EV_ACT_POLICY_ACC";
		break;
	case EV_ACT_POLICY_DENY:
		szAction = "EV_ACT_POLICY_DENY";
		break;
	case EV_ACT_ALL_USER_REQ:
		szAction = "EV_ACT_ALL_USER_REQ";
		break;
	case EV_ACT_ALL_USER_SEND:
		szAction = "EV_ACT_ALL_USER_SEND";
		break;
	case EV_ACT_ALL_USER_ACC:
		szAction = "EV_ACT_ALL_USER_ACC";
		break;
	case EV_ACT_ALL_USER_DENY:
		szAction = "EV_ACT_ALL_USER_DENY";
		break;
	case EV_ACT_SIN_USER_REQ:
		szAction = "EV_ACT_SIN_USER_REQ";
		break;
	case EV_ACT_SIN_USER_SEND:
		szAction = "EV_ACT_SIN_USER_SEND";
		break;
	case EV_ACT_SIN_USER_ACC:
		szAction = "EV_ACT_SIN_USER_ACC";
		break;
	case EV_ACT_SIN_USER_DENY:
		szAction = "EV_ACT_SIN_USER_DENY";
		break;
	case EV_ACT_PW_ATTEMPT_FAIL:
		szAction = "EV_ACT_PW_ATTEMPT_FAIL";
		break;
	case EV_ACT_GROUPLIST_REQ:
		szAction = "EV_ACT_GROUPLIST_REQ";
		break;
	case EV_ACT_GROUPLIST_UPDATE:
		szAction = "EV_ACT_GROUPLIST_UPDATE";
		break;
	case EV_ACT_GROUPLIST_ACC:
		szAction = "EV_ACT_GROUPLIST_ACC";
		break;
	case EV_ACT_GROUPLIST_DENY:
		szAction = "EV_ACT_GROUPLIST_DENY";
		break;
	case EV_ACT_MEMB_CONF_REQ:
		szAction = "EV_ACT_MEMB_CONF_REQ";
		break;
	case EV_ACT_MEMB_CONFIRMED:
		szAction = "EV_ACT_MEMB_CONFIRMED";
		break;
	case EV_ACT_MEMB_DENIED:
		szAction = "EV_ACT_MEMB_DENIED";
		break;
	case EV_ACT_END_TRANS:
		szAction = "EV_ACT_END_TRANS";
		break;
	case EV_ACT_PW_ATTEMPT_SUCCESS:
		szAction = "EV_ACT_PW_ATTEMPT_SUCCESS";
		break;
	case EV_ACT_INVALID:
		szAction = "EV_ACT_INVALID";
		break;
	}
	return szAction;
}
QString CPWInteractionEvent::ConvertScenarioTypeEnumToString(T_SCENARIO_STATES te) {
	QString szType;
	switch (te) {
	case SCN_ST_UNINITIALISED:
		szType = "SCN_ST_UNINITIALISED";
		break;
	case SCN_ST_PING:
		szType = "SCN_ST_PING";
		break;
	case SCN_ST_PING_RESP:
		szType = "SCN_ST_PING_RESP";
		break;
	case SCN_ST_JOIN_GRP_INV:
		szType = "SCN_ST_JOIN_GRP_INV";
		break;
	case SCN_ST_JOIN_GRP_REQ:
		szType = "SCN_ST_JOIN_GRP_REQ";
		break;
	case SCN_ST_LEAVE_GRP_PUSH:
		szType = "SCN_ST_LEAVE_GRP_PUSH";
		break;
	case SCN_ST_LEAVE_GRP_REQ:
		szType = "SCN_ST_LEAVE_GRP_REQ";
		break;
	case SCN_ST_MAST_CHG_OVTH:
		szType = "SCN_ST_MAST_CHG_OVTH";
		break;
	case SCN_ST_MAST_CHG_PROM:
		szType = "SCN_ST_MAST_CHG_PROM";
		break;
	case SCN_ST_MAST_CHG_ACC:
		szType = "SCN_ST_MAST_CHG_ACC";
		break;
	case SCN_ST_MAST_CHG_INF:
		szType = "SCN_ST_MAST_CHG_INF";
		break;
	case SCN_ST_FULL_PMM_REQ:
		szType = "INT_EV_GROUPLIST_UPDATE";
		break;
	case SCN_ST_FULL_PMM_SEND:
		szType = "SCN_ST_FULL_PMM_SEND";
		break;
	case SCN_ST_FULL_PMM_ACC:
		szType = "SCN_ST_FULL_PMM_ACC";
		break;
	case SCN_ST_FULL_PMM_DENY:
		szType = "SCN_ST_FULL_PMM_DENY";
		break;
	case SCN_ST_ALL_USER_REQ:
		szType = "SCN_ST_ALL_USER_REQ";
		break;
	case SCN_ST_ALL_USER_SEND:
		szType = "SCN_ST_ALL_USER_SEND";
		break;
	case SCN_ST_ALL_USER_ACC:
		szType = "SCN_ST_ALL_USER_ACC";
		break;
	case SCN_ST_ALL_USER_DENY:
		szType = "SCN_ST_ALL_USER_DENY";
		break;
	case SCN_ST_SIN_USER_REQ:
		szType = "SCN_ST_SIN_USER_REQ";
		break;
	case SCN_ST_SIN_USER_SEND:
		szType = "SCN_ST_SIN_USER_SEND";
		break;
	case SCN_ST_SIN_USER_ACC:
		szType = "SCN_ST_SIN_USER_ACC";
		break;
	case SCN_ST_SIN_USER_DENY:
		szType = "SCN_ST_SIN_USER_DENY";
		break;
	case SCN_ST_POLICY_REQ:
		szType = "SCN_ST_POLICY_REQ";
		break;
	case SCN_ST_POLICY_SEND:
		szType = "SCN_ST_POLICY_SEND";
		break;
	case SCN_ST_POLICY_ACC:
		szType = "SCN_ST_POLICY_ACC";
		break;
	case SCN_ST_POLICY_DENY:
		szType = "SCN_ST_POLICY_DENY";
		break;
	case SCN_ST_GROUPLIST_REQ:
		szType = "SCN_ST_GROUPLIST_REQ";
		break;
	case SCN_ST_GROUPLIST_UPDATE:
		szType = "SCN_ST_GROUPLIST_UPDATE";
		break;
	case SCN_ST_GROUPLIST_ACC:
		szType = "SCN_ST_GROUPLIST_ACC";
		break;
	case SCN_ST_GROUPLIST_DENY:
		szType = "SCN_ST_GROUPLIST_DENY";
		break;
	case SCN_ST_TOKEN_REQ:
		szType = "SCN_ST_TOKEN_REQ";
		break;
	case SCN_ST_TOKEN_GRANT:
	szType = "SCN_ST_TOKEN_GRAN

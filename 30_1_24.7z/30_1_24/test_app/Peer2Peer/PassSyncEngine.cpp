// PassSyncEngine.cpp: implementation of the PassSyncEngine class.
//
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Peer2Peer
/// @n Filename:  PassSyncEngine.cpp
/// @n Description: implementation of the PassSyncEngine class.
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  85  Aristos  1.79.1.3.1.0 9/19/2011 4:51:16 PM  Hemant(HAIL)  
//  Stability recorder source code (JI Release) updated for WatchDog
//  Timer functionality.
//  84  Stability Project 1.79.1.3 7/2/2011 4:59:37 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  83  Stability Project 1.79.1.2 7/1/2011 4:38:35 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  82  Stability Project 1.79.1.1 3/17/2011 3:20:33 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
// $
//
// **************************************************************************
#include "PassSyncEngine.h"
#include <list>
#include "StringUtils.h"
#include "PwdsCfgMgr.h"
#include "PassAuthMgr.h"
#include "configdata.h"
#include "CfgBitFieldEditDlg.h"
#include "errorControl.h"
#include "V7TLSUtilities.h"
//#include "TraceDefines.h"
#if ( !defined(P2P_XSERIES) )
#include "ThreadInfo.h"
#endif
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
	#include "CStorage.h"
#endif
#include "PNSCommsEngine.h"
// Some includes not needed in Comms Server because we do not need the firmware
// functionality.
#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TRENDSERVERPRO ) )
//#include "modbuswrapper.h"
#include "V6MessageBoxDlg.h"
#include "CPasswordModule.h"
#endif
//#define TRACE_ALLOW
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
static QString strLog;
const DWORD ESS_BIT = 1 << P2P_EXT_MODULE_ESS;
const DWORD PASS_BIT = 1 << P2P_EXT_MODULE_PASSWORDS;
const int THRESHOLD_AGE = 10000; //10 seconds
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CPassSyncEngine *CPassSyncEngine::m_pInstance = NULL;
QMutex m_CreationMutex;
//this needs to be a singleton
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
	CDebugFileLogger CPassSyncEngine::m_debugFileLogger(L"\\SDMemory\\PwdNetSync.txt", FALSE, (10*1024*1024));
#endif
//****************************************************************************
/// The first time this function is called it will create the single instance
/// of PassSyncEngine, Subsequent calls will return the Pointer to the instance
/// which has already been created.  
///
/// @param[in] 	  - None
///
/// @return Pointer to the PassSyncEngine instance 
/// 
//****************************************************************************
CPassSyncEngine* CPassSyncEngine::GetHandle() {
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;
	QString strFailure("");
	//LOG_INFO( TRACE_LOGGING , "CPassSyncEngine Constructor" );
	if (NULL == m_pInstance) {
		// An instance has yet to be completed
		m_CreationMutex = CreateMutex(NULL,					  // No security descriptor
				FALSE,					  // Mutex object not owned
				TEXT("PassSyncEngine"));	  // Object name
		waitSingleObjectResult = m_CreationMutex.tryLock(2000);
		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:
			// Object was signaled
			if (NULL == m_pInstance) {
				m_pInstance = new CPassSyncEngine;
			} // End of IF
			if ( FALSE == m_CreationMutex.unlock()) {
#ifdef _UNICODE
	strFailure = tr("PassSyncEngine not started Error - Mutex exists!");
					CV6MessageBoxDlg Dlg(_T("Error"),_T("PassSyncEngine not started Error - Mutex exists!"));
					Dlg.exec();
#else
				QMessageBox(_T("PassSyncEngine not started Error"), MB_OK);
#endif
				//V6WarningMessageBox( NULL, L"Failed to release PassAuthMgr mutex", L"CPassAuthUI Error", MB_OK );  
			} // End of IF
			break;
		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
			strFailure = tr("PassSyncEngine WaitForSingleObject Error");
#ifdef _UNICODE
				CV6MessageBoxDlg Dlg(_T("Error"),_T("PassSyncEngine WaitForSingleObject Error"));
				Dlg.exec();
#else
			QMessageBox(_T("PassSyncEngine WaitForSingleObject Error"), MB_OK);
#endif
			//V6WarningMessageBox( NULL, L"PassAuthMgr WaitForSingleObject Error", L"CPassAuthUI Error", MB_OK ); 
			break;
		} // End of SWITCH 
		// Close the Mutex as no longer required
		//No need to close the mutex in Qt
	} // End of IF 
	return (m_pInstance);
}
//********************************************************************
//
// Default constructor
//
// Initialise Member variables here
//
//********************************************************************
CPassSyncEngine::CPassSyncEngine() : m_pkNetSyncInfoDlg(NULL)
#ifdef SPNS_ENABLE
	, m_pPnsCommsEngine(NULL)
#endif
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
, m_pDebugFileLogger(&m_debugFileLogger) //Sett he available static member by default
#endif
{
	//init vars
	m_hStartupThread = NULL;
	m_hListenThread = NULL;
	m_hRegHandle = NULL;
	m_hShutdown = NULL;
	m_bInitialised = FALSE;
//	m_MasterState = PASS_STATE_INDETERMINATE;
	QMutex * m_csInteractionList;
	//QMutex* m_csGroupList;
	QMutex * m_csPeerList;
	QMutex * m_csMasterIdList;
	QMutex * m_csOrphanList;
	QMutex * m_csCommit;
	memset(&m_SyncInfo, NULL, sizeof(m_SyncInfo));
	memset(&m_OurPeerDetails, NULL, sizeof(m_OurPeerDetails));
	memset(&m_OurMaster, NULL, sizeof(m_OurMaster));
	m_Token.SetOurSerialID(pSYSTEM_INFO->GetSerialNumber());
	m_bTokenInUseByMaster = FALSE;
	m_usMasterSeqNum = NULL;
	m_hPromoteEvent = NULL;
	m_bConnectionToMaster = false;
	m_bInError = false;
	m_bCommitInProg = false;
	m_pNvConfig = NULL;
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE					
		strLog = QString::asprintf("::CTOR <ENTRY>");
		LogDebugMessage(strLog);
		//Set debug logging to token if required
		m_Token.SetDebugLogger(m_pDebugFileLogger);
#endif
	CSRAMManager *pRAM = NULL;
	CSRAMRegion *pPasswordRam = NULL;
	pRAM = CSRAMManager::GetHandle();
	pRAM->Initialise();
	CSRAMManager::regionError requestReturn = pRAM->RequestRegion(REGION_PASSWORD, &pPasswordRam);
	if (requestReturn == CSRAMManager::REGION_OKAY || requestReturn == CSRAMManager::REGION_IN_USE) {
		BYTE *pNvData = (BYTE*) pPasswordRam->GetAddress();
		m_pNvConfig = reinterpret_cast<T_NV_CONFIG*>(pNvData + sizeof(T_PMMNVDATA));
		if (CSRAMManager::REGION_OKAY == requestReturn) {
			//close the request
		}
	}
	//PSR - Coverity issue fix --#774138
	if (NULL != m_pNvConfig) {
		//set main state accordingly
		if (m_pNvConfig->State == PASS_STATE_MASTER_STATE) {
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE					
			strLog = QString::asprintf("::CTOR..Setting to PASS_STATE_MASTER_STARTUP..");
			LogDebugMessage(strLog);
			#endif	
			SetPeerType(PASS_STATE_MASTER_STARTUP);
		} else {
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE					
			QString  szState;			
			szState = ConvertStateEnumToString(m_pNvConfig->State);
			strLog = QString::asprintf("::CTOR..Setting to PASS_STATE_MASTER_STARTUP..Current State: %s", szState);
			LogDebugMessage(strLog);
			#endif	
			SetPeerType(m_pNvConfig->State);
		}
		if (m_pNvConfig->State != PASS_STATE_INDIVIDUAL) {
			SetGroup(m_pNvConfig->wcGroupName);
		}
	}
#ifdef SPNS_ENABLE
	//This is requied for Secure PNS COMMS
	m_pPnsCommsEngine = new CPNSCommsEngine(); //Consytruct the PNS Comms Engine
#endif
}
//****************************************************************************
/// Default Destructor  
///
/// final cleanup
/// 
//****************************************************************************
CPassSyncEngine::~CPassSyncEngine() {
	if (m_hPromoteEvent != NULL) {
		//No need to close the mutex in Qt
		m_hPromoteEvent = NULL;
	}
#ifdef SPNS_ENABLE
	if( m_pPnsCommsEngine != NULL )
	{
		delete m_pPnsCommsEngine;
		m_pPnsCommsEngine = NULL;
	}
#endif
}
//****************************************************************************
/// InitPassSyncEngine - sets the parent handle so messages can pe posted up
///
/// @param		n/a
///
/// @return		n/a
///
//****************************************************************************
void CPassSyncEngine::InitPassSyncEngine() {
	//register with P2P engine
	CP2PEngine *pP2P = CP2PEngine::GetHandle();
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE					
		strLog = QString::asprintf("::InitPassSyncEngine triggered");
		LogDebugMessage(strLog);
	#endif
	m_usMasterSeqNum = m_pNvConfig->usMasterSeqNum;
	pP2P->RebuildLocalDetails();
	//initilize events
	m_hShutdown = CreateEvent(NULL, TRUE, FALSE, _T("PassEngShutdown"));
	m_hPromoteEvent = CreateEvent(NULL, FALSE, FALSE, L"PassEngPromoteWait");
	//SPNS - PSR Backward compatibility with P2PEngine(non-secure) is not required here	
	//PNS Engine now depends on the PNSComms for Module Data for SPNS
#ifndef SPNS_ENABLE
	m_hRegHandle = pP2P->GetExtModuleNotificationHandle(P2P_EXT_MODULE_PASSWORDS);
#else
	//Initialize the Secure PNS comms engine
#ifdef DBG_FILE_LOG_SPNS_ENABLE
	//Set the debug logger
	m_pPnsCommsEngine->SetDebugLogger(m_pDebugFileLogger);
#endif
	m_pPnsCommsEngine->InitPnSComms();
	m_hRegHandle = m_pPnsCommsEngine->GetExtModuleNotificationHandle(P2P_EXT_MODULE_PASSWORDS);
	#endif
	// kick off threads
	m_hListenThread = CreateThread(NULL, 0, CPassSyncEngine::ListenThread, this, 0, NULL);
	m_bInitialised = TRUE;
	LOG_P2P_MESSAGE(MSGLISTSER_P2P_PWD_INFO, L"Pwd NetSync: Initialised");
}
void CPassSyncEngine::ShutDownEngine() {
	if (m_bInitialised) {
		SetEvent(m_hShutdown);
		//PAVAN&PSR -Fix for PAR#1-3SKV3GO - Lock up issue observed at the time of recorder auto reboot
		//Wait time is not sufficient for the Thread to do clean up operation
		//and resulting in app crash. So incresing the wait time to 1 minute
		WaitForSingleObject(m_hListenThread, 150000);
		if (m_hShutdown) {
			//No need to close the mutex in Qt
			m_hShutdown = NULL;
		}
		if (m_hListenThread) {
			//No need to close the mutex in Qt
			m_hListenThread = NULL;
		}
		//PAVAN&PSR -Fix for PAR#1-3SKV3GO - Lock up issue observed at the time of recorder auto reboot
		//Wait time is not sufficient for the Thread to do clean up operation
		//and resulting in app crash. So incresing the wait time to 1 minute
		WaitForSingleObject(m_hStartupThread, 120000);
		if (m_hStartupThread) {
			//No need to close the mutex in Qt
			m_hStartupThread = NULL;
		}
		m_bInitialised = FALSE;
#ifdef SPNS_ENABLE
		//Secure PNS Trigger shutdown on PNS Comms
		m_pPnsCommsEngine->ShutDownEngine();
		#endif
		//empty any lists
		if (!m_InteractionList.isEmpty())
			m_InteractionList.ClearData();
		m_csPeerList.lock();
		if (!m_PwdPeerList.isEmpty())
			m_PwdPeerList.ClearData();
		if (!m_GroupList.isEmpty())
			m_GroupList.ClearData();
		m_csPeerList.lock();
		//deletion of mutex not required
		if (!m_OrphanList.isEmpty())
			m_OrphanList.ClearData();
		while (m_MasterIDpList.size()) {
			interaction_index *pItem = m_MasterIDpList.front();
			m_MasterIDpList.pop_front();
			delete pItem;
		}
	}
	delete m_pInstance;
	m_pInstance = NULL;
}
DWORD WINAPI CPassSyncEngine::ListenThread(LPVOID pParam) {
	CPassSyncEngine *pParent = (CPassSyncEngine*) pParam;
#if ( !defined(P2P_XSERIES) )
	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//for PassSyncEngine thread
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	if (pThreadInfo != NULL) {
		//Notify the WatchdogTimer that the PassSyncEngine Listen thread has 
		//started
		pThreadInfo->UpdateThreadInfo(AM_PASS_SYNC_ENGINE_LISTEN_THREAD, true);
	}
#endif
	pParent->UpdatePeersList(FALSE, TRUE);
	//do startup stuff
#ifdef TRACE_ALLOW
	qDebug(".oO0Oo..oO0Oo..oO0Oo..oO0Oo..oO0Oo..oO0Oo..oO0Oo..oO0Oo..oO0Oo..oO0Oo.Starting PassSyncStartupThread.oO0Oo..oO0Oo..oO0Oo.\n");
#endif
	pParent->m_hStartupThread = CreateThread(NULL, 0, CPassSyncEngine::StartupThread, pParent, 0, NULL);
	//PAVAN&PSR -Fix for PAR#1-3SKV3GO - Lock up issue observed at the time of recorder auto reboot
	//This was added newly after X Series code. This releases the handle, but there is no way we can know later that 
	// Startup thread is gracefully shutdown.
	//Commenting the code and waiting for the thread to shutdown gracefully in ShutDownEngine()
	/*if(pParent->m_hStartupThread != NULL)
	 {
	 CloseHandle(pParent->m_hStartupThread);
	 pParent->m_hStartupThread = NULL;
	 }*/
	HANDLE pHandles[2] = { pParent->m_hShutdown, pParent->m_hRegHandle };
	DWORD num = 2;
	DWORD dwRet = NULL;
	BOOL bRun = TRUE;
	if (!pHandles[1]) {
		bRun = FALSE;
		LOG_P2P_MESSAGE(MSGLISTSER_P2P_PWD_ERROR, L"Pwd NetSync: Listen Thread will not run");
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE					
		strLog = QString::asprintf("::ListenThread..Listen Thread will not run..");
		pParent->LogDebugMessage(strLog);
		#endif
	}
	while (bRun) {
		dwRet = WaitForMultipleObjects(num, pHandles, FALSE, 3000);
		switch (dwRet) {
		case WAIT_OBJECT_0:
			bRun = FALSE;
			break;
		case WAIT_OBJECT_0 + 1:
			//data has arrived
#ifdef TRACE_ALLOW
			qDebug("External module event handled\n");
#endif
			/*
			 #ifdef DBG_FILE_LOG_NETSYNC_ENABLE					
			 strLog = QString::asprintf("ListenThread::Data arrived ...FetchAndProcessNewData <ENTRY>");
			 LogDebugMessage(strLog);
			 #endif
			 */
			pParent->FetchAndProcessNewData();
			/*
			 #ifdef DBG_FILE_LOG_NETSYNC_ENABLE					
			 strLog = QString::asprintf("ListenThread::FetchAndProcessNewData <EXIT>");
			 LogDebugMessage(strLog);
			 #endif
			 */
			break;
		case WAIT_TIMEOUT:
			//Clean out any stalled transactions
			pParent->CleanTransactions();
		default:
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE					
			//strLog = QString::asprintf("ListenThread::WaitForMultipleObjects dwRet %lu", dwRet);
			//LogDebugMessage(strLog);
#endif
			break;
		}
#if ( !defined(P2P_XSERIES) )
		if (pThreadInfo != NULL) {
			//Update the Thread Counter for the PassSyncEngine
			//thread after each iteration
			pThreadInfo->UpdateThreadCounter(AM_PASS_SYNC_ENGINE_LISTEN_THREAD);
		}
#endif
	}
#if ( !defined(P2P_XSERIES) )
	if (pThreadInfo != NULL) {
		//Update the info that the PassSyncEngine listen thread is exiting
		//Hence this thread need not be considered to kick the 
		//watchdog
		pThreadInfo->UpdateThreadInfo(AM_PASS_SYNC_ENGINE_LISTEN_THREAD, false);
	}
#endif
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
	QString  strLogMsg;
	strLogMsg = QString::asprintf("CPassSyncEngine::ListenThread..Exited..");
	pParent->LogDebugMessage(strLogMsg);
#endif
	return 0;
}
QString CPassSyncEngine::ConvertPwdPMMTypeToString(T_PW_PMM_TYPES te) {
	QString szPwdPMMType;
	switch (te) {
	case PW_PMM_REQ:
		szPwdPMMType = "PW_PMM_REQ";
		break;
	case PW_PMM_SEND:
		szPwdPMMType = "PW_PMM_SEND";
		break;
	case PW_PMM_ACC:
		szPwdPMMType = "PW_PMM_ACC";
		break;
	case PW_PMM_DENY:
		szPwdPMMType = "PW_PMM_DENY";
		break;
	}
	return szPwdPMMType;
}
QString CPassSyncEngine::ConvertPwdSyncMsgToString(BYTE byPwdSync) {
	QString szPwdSyncMsgType;
	switch (byPwdSync) {
	case PW_PING:
		szPwdSyncMsgType = "PW_PING";
		break;
	case PW_TOKEN:
		szPwdSyncMsgType = "PW_TOKEN";
		break;
	case PW_JOIN_GROUP:
		szPwdSyncMsgType = "PW_JOIN_GROUP";
		break;
	case PW_LEAVE_GROUP:
		szPwdSyncMsgType = "PW_LEAVE_GROUP";
		break;
	case PW_MASTER_CHANGE:
		szPwdSyncMsgType = "PW_MASTER_CHANGE";
		break;
	case PW_PMM_DATA:
		szPwdSyncMsgType = "PW_PMM_DATA";
		break;
	case PW_POLICY_DATA:
		szPwdSyncMsgType = "PW_POLICY_DATA";
		break;
	case PW_USER_DATA:
		szPwdSyncMsgType = "PW_USER_DATA";
		break;
	case PW_FULL_USER_DATA:
		szPwdSyncMsgType = "PW_FULL_USER_DATA";
		break;
	case PW_ATTEMPT_FAIL:
		szPwdSyncMsgType = "PW_ATTEMPT_FAIL";
		break;
	case PW_GROUP_LIST:
		szPwdSyncMsgType = "PW_GROUP_LIST";
		break;
	case PW_ATTEMPT_SUCCESS:
		szPwdSyncMsgType = "PW_ATTEMPT_SUCCESS";
		break;
	case PW_MEMBERSHIP_CONFIRM:
		szPwdSyncMsgType = "PW_MEMBERSHIP_CONFIRM";
		break;
	}
	return szPwdSyncMsgType;
}
QString CPassSyncEngine::ConvertScenarioTypeEnumToString(T_SCENARIO_TYPE te) {
	QString szType;
	switch (te) {
	case INT_EV_NO_SCENARIO:
		szType = "INT_EV_NO_SCENARIO";
		break;
	case INT_EV_HEALTH_CHECK:
		szType = "INT_EV_HEALTH_CHECK";
		break;
	case INT_EV_SLAVE_JOIN_MASTER:
		szType = "INT_EV_SLAVE_JOIN_MASTER";
		break;
	case INT_EV_SLAVE_LEAVE_GROUP:
		szType = "INT_EV_SLAVE_LEAVE_GROUP";
		break;
	case INT_EV_TOKEN_EXCHANGE:
		szType = "INT_EV_TOKEN_EXCHANGE";
		break;
	case INT_EV_SLAVE_PROMOTED:
		szType = "INT_EV_SLAVE_PROMOTED";
		break;
	case INT_EV_FULL_DATA_UPDATE:
		szType = "INT_EV_FULL_DATA_UPDATE";
		break;
	case INT_EV_FULL_USER_UPDATE:
		szType = "INT_EV_FULL_USER_UPDATE";
		break;
	case INT_EV_USER_UPDATE:
		szType = "INT_EV_USER_UPDATE";
		break;
	case INT_EV_POLICY_UPDATE:
		szType = "INT_EV_NO_SCENARIO";
		break;
	case INT_EV_GROUPLIST_UPDATE:
		szType = "INT_EV_GROUPLIST_UPDATE";
		break;
	case INT_EV_MEMBERSHIP_CONFIRM:
		szType = "INT_EV_MEMBERSHIP_CONFIRM";
		break;
	}
	return szType;
}
QString CPassSyncEngine::ConvertTransEnumToString(T_EVENT_ACTION teAct) {
	QString szAction;
	switch (teAct) {
	case EV_ACT_NO_ACTION:
		szAction = "EV_ACT_NO_ACTION";
		break;
	case EV_ACT_JOIN_GRP_REQ:
		szAction = "EV_ACT_JOIN_GRP_REQ";
		break;
	case EV_ACT_JOIN_GRP_ACC:
		szAction = "EV_ACT_JOIN_GRP_ACC";
		break;
	case EV_ACT_JOIN_GRP_DENY:
		szAction = "EV_ACT_JOIN_GRP_DENY";
		break;
	case EV_ACT_JOIN_GRP_INV:
		szAction = "EV_ACT_JOIN_GRP_INV";
		break;
	case EV_ACT_LEAV_GRP_REQ:
		szAction = "EV_ACT_LEAV_GRP_REQ";
		break;
	case EV_ACT_LEAV_GRP_ACC:
		szAction = "EV_ACT_LEAV_GRP_ACC";
		break;
	case EV_ACT_LEAV_GRP_PUSH:
		szAction = "EV_ACT_LEAV_GRP_PUSH";
		break;
	case EV_ACT_PING:
		szAction = "EV_ACT_PING";
		break;
	case EV_ACT_PING_RESP:
		szAction = "EV_ACT_PING_RESP";
		break;
	case EV_ACT_MAST_CHG_PROM:
		szAction = "EV_ACT_MAST_CHG_PROM";
		break;
	case EV_ACT_MAST_CHG_INF:
		szAction = "EV_ACT_MAST_CHG_INF";
		break;
	case EV_ACT_MAST_CHG_OVTH:
		szAction = "EV_ACT_MAST_CHG_OVTH";
		break;
	case EV_ACT_MAST_CHG_ACC:
		szAction = "EV_ACT_MAST_CHG_ACC";
		break;
	case EV_ACT_MAST_CHG_DENY:
		szAction = "EV_ACT_MAST_CHG_DENY";
		break;
	case EV_ACT_TOKEN_REQ:
		szAction = "EV_ACT_TOKEN_REQ";
		break;
	case EV_ACT_TOKEN_GRANT:
		szAction = "EV_ACT_TOKEN_GRANT";
		break;
	case EV_ACT_TOKEN_STEAL:
		szAction = "EV_ACT_TOKEN_STEAL";
		break;
	case EV_ACT_TOKEN_INFORM:
		szAction = "EV_ACT_TOKEN_INFORM";
		break;
	case EV_ACT_TOKEN_RELEASE:
		szAction = "EV_ACT_TOKEN_RELEASE";
		break;
	case EV_ACT_FULL_PMM_REQ:
		szAction = "EV_ACT_FULL_PMM_REQ";
		break;
	case EV_ACT_FULL_PMM_SEND:
		szAction = "EV_ACT_FULL_PMM_SEND";
		break;
	case EV_ACT_FULL_PMM_ACC:
		szAction = "EV_ACT_FULL_PMM_ACC";
		break;
	case EV_ACT_FULL_PMM_DENY:
		szAction = "EV_ACT_FULL_PMM_DENY";
		break;
	case EV_ACT_POLICY_REQ:
		szAction = "EV_ACT_POLICY_REQ";
		break;
	case EV_ACT_POLICY_SEND:
		szAction = "EV_ACT_POLICY_SEND";
		break;
	case EV_ACT_POLICY_ACC:
		szAction = "EV_ACT_POLICY_ACC";
		break;
	case EV_ACT_POLICY_DENY:
		szAction = "EV_ACT_POLICY_DENY";
		break;
	case EV_ACT_ALL_USER_REQ:
		szAction = "EV_ACT_ALL_USER_REQ";
		break;
	case EV_ACT_ALL_USER_SEND:
		szAction = "EV_ACT_ALL_USER_SEND";
		break;
	case EV_ACT_ALL_USER_ACC:
		szAction = "EV_ACT_ALL_USER_ACC";
		break;
	case EV_ACT_ALL_USER_DENY:
		szAction = "EV_ACT_ALL_USER_DENY";
		break;
	case EV_ACT_SIN_USER_REQ:
		szAction = "EV_ACT_SIN_USER_REQ";
		break;
	case EV_ACT_SIN_USER_SEND:
		szAction = "EV_ACT_SIN_USER_SEND";
		break;
	case EV_ACT_SIN_USER_ACC:
		szAction = "EV_ACT_SIN_USER_ACC";
		break;
	case EV_ACT_SIN_USER_DENY:
		szAction = "EV_ACT_SIN_USER_DENY";
		break;
	case EV_ACT_PW_ATTEMPT_FAIL:
		szAction = "EV_ACT_PW_ATTEMPT_FAIL";
		break;
	case EV_ACT_GROUPLIST_REQ:
		szAction = "EV_ACT_GROUPLIST_REQ";
		break;
	case EV_ACT_GROUPLIST_UPDATE:
		szAction = "EV_ACT_GROUPLIST_UPDATE";
		break;
	case EV_ACT_GROUPLIST_ACC:
		szAction = "EV_ACT_GROUPLIST_ACC";
		break;
	case EV_ACT_GROUPLIST_DENY:
		szAction = "EV_ACT_GROUPLIST_DENY";
		break;
	case EV_ACT_MEMB_CONF_REQ:
		szAction = "EV_ACT_MEMB_CONF_REQ";
		break;
	case EV_ACT_MEMB_CONFIRMED:
		szAction = "EV_ACT_MEMB_CONFIRMED";
		break;
	case EV_ACT_MEMB_DENIED:
		szAction = "EV_ACT_MEMB_DENIED";
		break;
	case EV_ACT_END_TRANS:
		szAction = "EV_ACT_END_TRANS";
		break;
	case EV_ACT_PW_ATTEMPT_SUCCESS:
		szAction = "EV_ACT_PW_ATTEMPT_SUCCESS";
		break;
	case EV_ACT_INVALID:
		szAction = "EV_ACT_INVALID";
		break;
	}
	return szAction;
}
QString CPassSyncEngine::ConvertStateEnumToString(T_PASS_SYNC_STATES eState) {
	QString szSate;
	switch (eState) {
	case PASS_STATE_INDIVIDUAL:
		szSate = "PASS_STATE_INDIVIDUAL";
		break;
	case PASS_STATE_SLAVE_STATE:
		szSate = "PASS_STATE_SLAVE_STATE";
		break;
	case PASS_STATE_MASTER_STATE:
		szSate = "PASS_STATE_MASTER_STATE";
		break;
	case PASS_STATE_INDETERMINATE:
		szSate = "PASS_STATE_INDETERMINATE";
		break;
	case PASS_STATE_MASTER_STARTUP:
		szSate = "PASS_STATE_MASTER_STARTUP";
		break;
	}
	return szSate;
}
DWORD WINAPI CPassSyncEngine::StartupThread(LPVOID pParam) {
	CPassSyncEngine *pParent = (CPassSyncEngine*) pParam;
#if ( !defined(P2P_XSERIES) )
	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//for PassSyncEngine Startup thread
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	if (pThreadInfo != NULL) {
		//Notify the WatchdogTimer that the PassSyncEngine thread has 
		//started
		pThreadInfo->UpdateThreadInfo(AM_PASS_SYNCENG_STARTUP_THREAD, true);
	}
#endif
	switch (pParent->m_OurPeerDetails.eState) {
	case PASS_STATE_SLAVE_STATE:
		//check for group name in peers
	{
		pParent->m_csPeerList.lock();
		bool bFound = false;
		T_PEER_ITEM *pItem = NULL;
		if (!pParent->m_PwdPeerList.isEmpty()) {
			pItem = pParent->m_PwdPeerList.GetHead();
			bool bLast = false;
			while (!bLast && !bFound) {
				if (pItem->eState == PASS_STATE_MASTER_STATE) {
					if (wcsncmp(pItem->wcGroupName, pParent->m_OurPeerDetails.wcGroupName, GENERALCONFIG_NAME_LEN)
							== 0) {
						memcpy(&(pParent->m_OurMaster), pItem, sizeof(pParent->m_OurMaster));
						bFound = true;
					}
				}
				bLast = pParent->m_PwdPeerList.IsLast();
				if (!bLast && !bFound)
					pItem = pParent->m_PwdPeerList.GetNext();
			}
		}
		pParent->m_csPeerList.lock();
		if (!bFound) {
			//contingency plan.....
			//set error state to promote or go standalone
			//popup alert
			QString strErrorMsg("");
			strErrorMsg =
					tr(
							"Password Net Sync Error!\r\nFailed to communicate with the master. Check Pwd NetSync setup to resolve this issue.");
			CErrorControl::Instance()->UpdateErrorCondition(retPWD_NET_SYNC_FAILURE, true, strErrorMsg);
			pParent->m_bConnectionToMaster = false;
			pParent->m_bInError = true;
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE					
				strLog = QString::asprintf("::StartupThread No master found..");
				pParent->LogDebugMessage(strLog);
				#endif
			LOG_P2P_MESSAGE(MSGLISTSER_P2P_PWD_WARNING, L"Pwd NetSync: No master found");
		} else {
			T_INTERACTION_ID NewId;
			NewId.ulOriginator = pParent->m_OurPeerDetails.ulSerial;
			NewId.ulRecipient = pItem->ulSerial;
			pParent->NewInteractID(NewId);
			LOG_P2P_MESSAGE(MSGLISTSER_P2P_PWD_INFO, L"Pwd NetSync: Master found, connecting.....");
			if (pParent->SendGroupConfirmMsg(PW_MEMBERSHIP_CONF_REQ, &NewId)) {
				CPWInteractionEvent *pEvent = new CPWInteractionEvent(INT_EV_MEMBERSHIP_CONFIRM, &NewId);
				if (pEvent->SubmitEvent(EV_ACT_MEMB_CONF_REQ) != EV_ACT_END_TRANS) {
					pParent->m_csInteractionList.lock();
					pParent->m_InteractionList.append(pEvent);
					pParent->m_csInteractionList.lock();
				} else {
					delete pEvent;
					//ULONG ulDest;
					//
					//ulDest = pParent->GetIPFromSerial(NewId.ulRecipient);
					//if(ulDest)
					//	CP2PEngine::GetHandle()->EndConnection(ulDest);
				}
				LOG_P2P_MESSAGE(MSGLISTSER_P2P_PWD_INFO, L"Pwd NetSync: Master contacted okay");
				pParent->m_bConnectionToMaster = true;
				QString strErrorMsg("");
				CErrorControl::Instance()->UpdateErrorCondition(retPWD_NET_SYNC_FAILURE, false, strErrorMsg);
				pParent->m_bInError = false;
			} else {
				LOG_P2P_MESSAGE(MSGLISTSER_P2P_PWD_ERROR, L"Pwd NetSync: Failed to contact master");
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE					
					strLog = QString::asprintf("::StartupThread Failed to contact master..");
					pParent->LogDebugMessage(strLog);
					#endif
				pParent->m_bConnectionToMaster = false;
				QString strErrorMsg("");
				strErrorMsg =
						tr(
								"Password Net Sync Error!\r\nFailed to communicate with the master. Check Pwd NetSync setup to resolve this issue.");
				CErrorControl::Instance()->UpdateErrorCondition(retPWD_NET_SYNC_FAILURE, true, strErrorMsg);
				pParent->m_bInError = true;
			}
		}
	}
		break;
	case PASS_STATE_MASTER_STARTUP:
		//check for group slaves and another master
	{
		//TODO: a interaction for query master
		pParent->m_csPeerList.lock();
		if (!pParent->m_PwdPeerList.isEmpty()) {
			T_PEER_ITEM *pItem = pParent->m_PwdPeerList.GetHead();
			bool bLast = false;
			while (!bLast) {
				if (wcsncmp(pItem->wcGroupName, pParent->m_OurPeerDetails.wcGroupName, GENERALCONFIG_NAME_LEN) == 0) {
					if (pItem->eState == PASS_STATE_SLAVE_STATE) {
						T_PEER_ITEM *pNewItem = new T_PEER_ITEM;
						memcpy(pNewItem, pItem, sizeof(T_PEER_ITEM));
						//pParent->m_csGroupList.lock();
						pParent->AddUniqueGroupTail(pNewItem);
						//pParent->m_csGroupList.lock();
					} else if (pItem->eState == PASS_STATE_MASTER_STATE) {
						//another master detected... assume it is the real one and drop from the group
						pParent->SetGroup(NULL);
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE					
							strLog = QString::asprintf("::StartupThread ..Setting to PASS_STATE_INDIVIDUAL since another master detected.");
							pParent->LogDebugMessage(strLog);
							#endif	
						pParent->SetPeerType(PASS_STATE_INDIVIDUAL);
						CP2PEngine::GetHandle()->RebuildLocalDetails();
						LOG_P2P_MESSAGE(MSGLISTSER_P2P_PWD_INFO,
								L"Pwd NetSync: Another master found. Dropping to standalone and rejoining.....");
						//request a join
						T_INTERACTION_ID NewId;
						NewId.ulRecipient = pItem->ulSerial;
						if (NULL != NewId.ulRecipient) {
							NewId.ulOriginator = pParent->m_OurPeerDetails.ulSerial;
							pParent->NewInteractID(NewId);
							CPWInteractionEvent *pEvent = new CPWInteractionEvent(INT_EV_SLAVE_JOIN_MASTER, &NewId);
							if (pParent->SendJoinGroupMsg(PW_JOIN_GRP_REQ, &NewId, QString(pItem->wcGroupName))) {
								pEvent->SubmitEvent(EV_ACT_JOIN_GRP_REQ);
								//add the event to the interaction list
								pParent->m_csInteractionList.lock();
								pParent->m_InteractionList.append(pEvent);
								pParent->m_csInteractionList.lock();
								LOG_P2P_MESSAGE(MSGLISTSER_P2P_PWD_INFO,
										L"Pwd NetSync: Rejoined group as slave successfully");
							} else {
								LOG_P2P_MESSAGE(MSGLISTSER_P2P_PWD_ERROR,
										L"Pwd NetSync: Failed to contact other master");
								delete pEvent;
							}
						}
						break;
					}
				}
				bLast = pParent->m_PwdPeerList.IsLast();
				if (bLast)
					pItem = NULL;
				else
					pItem = pParent->m_PwdPeerList.GetNext();
#if ( !defined(P2P_XSERIES) )
				if (pThreadInfo != NULL) {
					//Update the Thread Counter for the PassSyncEngine Startup
					//thread after each iteration
					pThreadInfo->UpdateThreadCounter(AM_PASS_SYNCENG_STARTUP_THREAD);
				}
#endif
			}
			//see if we are still master...
			if (pParent->m_OurPeerDetails.eState == PASS_STATE_MASTER_STARTUP) {
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE					
					strLog = QString::asprintf("::StartupThread...Setting Peer type to PASS_STATE_MASTER_STATE..");
					pParent->LogDebugMessage(strLog);
					#endif
				pParent->SetPeerType(PASS_STATE_MASTER_STATE);
				//confirm all the group members
				//pParent->m_csGroupList.lock();
				if (!pParent->m_GroupList.isEmpty()) {
					T_PEER_ITEM *pDest = pParent->m_GroupList.GetHead();
					bool bLast = false;
					while (!bLast) {
						T_INTERACTION_ID NewId;
						NewId.ulOriginator = pParent->m_OurPeerDetails.ulSerial;
						NewId.ulRecipient = pDest->ulSerial;
						pParent->NewInteractID(NewId);
						CPWInteractionEvent *pEvent = new CPWInteractionEvent(INT_EV_SLAVE_JOIN_MASTER, &NewId);
						if (!pParent->SendJoinGroupMsg(PW_JOIN_GRP_INV, &NewId,
								QString(pParent->m_OurPeerDetails.wcGroupName))) {
							QString strError("");
							strError = QString::asprintf("Pwd NetSync: Failed to contact slave %s", pDest->wcNetName);
							LOG_P2P_MESSAGE(MSGLISTSER_P2P_PWD_ERROR, strError);
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE					
								strLog = QString::asprintf("::StartupThread Failed to contact slave %s ..",pDest->wcNetName);
								pParent->LogDebugMessage(strLog);
								#endif
							delete pEvent;
							//remove from the group list
							pParent->m_GroupList.removeData(pDest);
							if (!pParent->m_GroupList.isEmpty())
								pDest = pParent->m_GroupList.GetHead();
							else
								bLast = true;
						} else {
							pEvent->SubmitEvent(EV_ACT_JOIN_GRP_INV);
							//add the event to the interaction list
							pParent->m_csInteractionList.lock();
							pParent->m_InteractionList.append(pEvent);
							pParent->m_csInteractionList.lock();
							QString strInfo("");
							strInfo = QString::asprintf("Pwd NetSync: Confirmed slave %s", pDest->wcNetName);
							LOG_P2P_MESSAGE(MSGLISTSER_P2P_PWD_INFO, strInfo);
							bLast = pParent->m_GroupList.IsLast();
							if (!bLast)
								pDest = pParent->m_GroupList.GetNext();
						}
#if ( !defined(P2P_XSERIES) )
						if (pThreadInfo != NULL) {
							//Update the Thread Counter for the PassSyncEngine Startup
							//thread 
							pThreadInfo->UpdateThreadCounter(AM_PASS_SYNCENG_STARTUP_THREAD);
						}
#endif
					}
					LOG_P2P_MESSAGE(MSGLISTSER_P2P_PWD_INFO, L"Pwd NetSync: Finished confirming slaves");
				}
				//pParent->m_csGroupList.lock();
			} else
				pParent->m_GroupList.ClearData();
		} else {
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE					
				strLog = QString::asprintf("::StartupThread.. Setting Peer Type to PASS_STATE_MASTER_STATE.. Action: PASS_STATE_MASTER_STARTUP ..");
				pParent->LogDebugMessage(strLog);
				#endif			
			pParent->SetPeerType(PASS_STATE_MASTER_STATE);
		}
		pParent->m_csPeerList.lock();
	}
		break;
	case PASS_STATE_INDIVIDUAL:
	case PASS_STATE_INDETERMINATE: //fallthrough
	default:
		break;
	}
pParent->m_Token.ForceTokenReset();
#if ( !defined(P2P_XSERIES)S)

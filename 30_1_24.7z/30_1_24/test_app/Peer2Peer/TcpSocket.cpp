//////////////////////////////////////////////////////////////////////
/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Peer2Peer
/// @n Filename:  TcpSocket.cpp
/// @n Description: Implementation of the CTcpSocket class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log:
//  13  Aristos  1.7.1.3.1.0 9/19/2011 4:51:17 PM  Hemant(HAIL)  
//  Stability recorder source code (JI Release) updated for WatchDog
//  Timer functionality.
//  12  Stability Project 1.7.1.3 7/2/2011 5:02:00 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  11  Stability Project 1.7.1.2 7/1/2011 4:39:00 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  10  Stability Project 1.7.1.1 3/17/2011 3:20:49 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  9 Stability Project 1.7.1.0 2/15/2011 3:04:02 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
//  8 V6 Firmware 1.7 7/4/2007 5:12:06 PM Charles Boardman
//  Adding more detailed qDebug information when a connection is accepted.
//  Can be turned on using TRACE_ALLOW.
//  7 V6 Firmware 1.6 6/20/2007 2:52:51 PM  Alistair Brugsch
//  added trace_allow defines around tracing
//  6 V6 Firmware 1.5 4/4/2007 5:41:13 PM Alistair Brugsch
//  conditionally removed tracing
//  5 V6 Firmware 1.4 11/21/2006 8:29:41 PM  Alistair Brugsch
//  removed un-necessary tracing.
//  Tightened the backoff timeout
//  4 V6 Firmware 1.3 11/21/2006 5:18:34 PM  Alistair Brugsch
//  changed the getsockname cll to get peername in order to display the
//  IP address of the connected peer, not the local host
//  3 V6 Firmware 1.2 11/20/2006 6:08:27 PM  Alistair Brugsch
//  reference check in to enable concurrent connection limiting
//  2 V6 Firmware 1.1 11/6/2006 9:40:18 PM  Charles Boardman
//  Replacing use of QString   ::fromWCharArray("") with _T("") to enable compilation in MBCS
//  projects in Visual Studio 2003, for benefit of Comms Server and TSP.
//  1 V6 Firmware 1.0 10/31/2006 10:18:24 PM Alistair Brugsch 
// $
//
// **************************************************************************
#include "TcpSocket.h"
#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TRENDSERVERPRO ) && ! defined ( TTR6SETUP ) ) && ( !defined(P2P_XSERIES) ) && (! defined (P2P_WRAPPER))
#include "ThreadInfo.h"
#endif
#define WM_TCP_ACCEPT WM_USER+2 // temporary work around... TODO: remove these references
//#define WM_TCP_ACCEPT WM_USER+3
#define WM_RECV_TCP_DATA WM_USER+4
//#define TRACE_ALLOW
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CTcpSocket::CTcpSocket(ESocketTransMode eSTMode) : CV7SecureSocket(eSTMode) {
	m_hParent = NULL;
	m_hAcceptedEv = NULL;
	m_hServFailed = NULL;
	m_hBackoffEv = NULL;
	m_hAcceptEv = NULL;
	m_hRecvEv = NULL;
	m_hCloseEv = NULL;
	m_hConnEv = NULL;
}
CTcpSocket::CTcpSocket(HWND hParent, ESocketTransMode eSTMode) : CV7SecureSocket(eSTMode) {
	m_hParent = hParent;
	m_hAcceptedEv = NULL;
	m_hServFailed = NULL;
	m_hBackoffEv = NULL;
	m_hAcceptEv = NULL;
	m_hRecvEv = NULL;
	m_hCloseEv = NULL;
	m_hConnEv = NULL;
}
CTcpSocket::CTcpSocket(QAbstractSocket skt, ESocketRoleType role, CredHandle *hServerCreds, CtxtHandle *hContext) : CV7SecureSocket(
		skt, role, hServerCreds, hContext) {
	m_hParent = NULL;
	m_hAcceptedEv = NULL;
	m_hServFailed = NULL;
	m_hBackoffEv = NULL;
	m_hAcceptEv = NULL;
	m_hRecvEv = NULL;
	m_hCloseEv = NULL;
	m_hConnEv = NULL;
}
CTcpSocket::~CTcpSocket() {
}
//****************************************************************************
/// SetParent - sets the parent handle so messages can pe posted up
///
/// @param[in]	hParent - Window handle to recieve notification
///
/// @return			n/a
///
//****************************************************************************
void CTcpSocket::SetParent(HWND hParent) {
	m_hParent = hParent;
}
//****************************************************************************
/// Create - creates a new TCP socket
///
/// @param n/a
///
/// @return		true if successful
///
//****************************************************************************
bool CTcpSocket::Create() {
	return CV7SecureSocket::Create(SOCK_STREAM, SECURE_TCP_BUFFERSIZE);
}
//****************************************************************************
/// OnAccept - Override to handle accept notifications
///
/// @param[in]	serviceSocket - QAbstractSocket to attach to new class instance
///
/// @return		false if new socket not handled by handler thread
///
//****************************************************************************
bool CTcpSocket::OnAccept(QAbstractSocket serviceSocket) {
	bool ret = false;
	if (m_eSocketTransMode == CCESecureSocket::ST_MODE_SECURE) {
		//Perform Secure handshake
		ret = CV7SecureSocket::OnAccept(serviceSocket);
		if (false == ret) {
			return ret;
		}
	}
	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//for the Accept thread
#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TRENDSERVERPRO ) )&& ( ! defined ( TRENDMANAGERPRO ) ) && ( ! defined ( P2P_WRAPPER ))
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
#endif
	if (m_hParent)
		PostMessage(m_hParent, WM_TCP_ACCEPT, (WPARAM) serviceSocket, NULL);
	else {
#ifdef TRACE_ALLOW
		qDebug("Accepting a socket\n");
#endif
		m_sServSock = serviceSocket;
		SetEvent(m_hAcceptEv);
		//qDebug("Waiting for accepted event\n");
		HANDLE hArr[2] = { m_hBackoffEv, m_hAcceptedEv };
		BOOL retry = 10;
		DWORD dwRet;
#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TRENDSERVERPRO ) )&& ( ! defined ( TRENDMANAGERPRO ) ) && ( ! defined ( P2P_WRAPPER ))
		if (pThreadInfo != NULL) {
			//Update the thread counter for the Socket Accept thread
			pThreadInfo->UpdateThreadCounter(AM_ACCEPT_THREAD);
		}
#endif
		while (retry) {
#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TRENDSERVERPRO ) )&& ( ! defined ( TRENDMANAGERPRO ) ) && ( ! defined ( P2P_WRAPPER ))
			if (pThreadInfo != NULL) {
				//Update the Thread Counter for the Socket Accept
				//thread for each iteration
				pThreadInfo->UpdateThreadCounter(AM_ACCEPT_THREAD);
			}
#endif
			dwRet = WaitForMultipleObjects(2, hArr, FALSE, 3000);
#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TRENDSERVERPRO ) )&& ( ! defined ( TRENDMANAGERPRO ) ) && ( ! defined ( P2P_WRAPPER ))
			if (pThreadInfo != NULL) {
				//Update the Thread Counter for the Socket Accept
				//thread afor each iteration
				pThreadInfo->UpdateThreadCounter(AM_ACCEPT_THREAD);
			}
#endif
			switch (dwRet)			 //test amount of timeout
			{
			case WAIT_TIMEOUT: {
				//no one's listening
				ResetEvent(m_hAcceptEv);
				//I need to know that the timeout may be too short
				SOCKADDR_IN sName;
				sName.sin_family = AF_INET;
				sName.sin_port = 0;
				sName.sin_addr.S_un.S_addr = ADDR_ANY;
				int siz = sizeof(sockaddr);
				getpeername(serviceSocket, (sockaddr*) &sName, &siz);
#ifdef TRACE_ALLOW
					qDebug(_T("###################################Timeout expired on new socket IP %X\n"),sName.sin_addr.S_un.S_addr);//,MB_ICONEXCLAMATION|MB_OK);
#endif
				//DebugBreak();
				retry = 0;
			}
				break;
			case WAIT_OBJECT_0: {
				//backoff
				SOCKADDR_IN sName;
				sName.sin_family = AF_INET;
				sName.sin_port = 0;
				sName.sin_addr.S_un.S_addr = ADDR_ANY;
				int siz = sizeof(sockaddr);
				getpeername(serviceSocket, (sockaddr*) &sName, &siz);
#ifdef TRACE_ALLOW
					qDebug("[][][][][][][][][][][][][][][]Backoff Invoked IP %X\n",sName.sin_addr.S_un.S_addr);
#endif
				sleep(100);
				SetEvent(m_hAcceptEv);
				--retry;
				//go back around
			}
				break;
			case WAIT_OBJECT_0 + 1:			 //all done we can carry on
			{
				retry = 0;
				ret = true;
#ifdef TRACE_ALLOW
					//I need to know that the timeout may be too short
					SOCKADDR_IN sName;
					sName.sin_family = AF_INET;
					sName.sin_port  = 0;
					sName.sin_addr.S_un.S_addr = ADDR_ANY; 
					int siz = sizeof(sockaddr);
					getpeername(serviceSocket,(sockaddr*)&sName,&siz);
					qDebug("[][][][][][][][][][][][][][][]All done we can carry on for IP %X.\n", sName.sin_addr.S_un.S_addr );
#endif
			}
				break;
			default:			 //something unexpected so we should get out while we can
			{
				retry = 0;
#ifdef TRACE_ALLOW
					SOCKADDR_IN sName;
					sName.sin_family = AF_INET;
					sName.sin_port  = 0;
					sName.sin_addr.S_un.S_addr = ADDR_ANY; 
					int siz = sizeof(sockaddr);
					getpeername(serviceSocket,(sockaddr*)&sName,&siz);
					qDebug("[][][][][][][][][][][][][][][]Unhandled response for wait for multiple objects for IP X.\n", sName.sin_addr.S_un.S_addr );
#endif
			}
				break;
			}
		}
		//qDebug("Accepted event triggered\n");
	}
	return ret;
}
//****************************************************************************
/// Accept - Override to start socket listening routine
///
/// @param[in]	LocalPort - port to listen on
/// @param[in] maxConn - max pending incoming connections to hold before 
///  connections are refused
///
/// @return		true - accept successful
///
//****************************************************************************
bool CTcpSocket::Accept(UINT LocalPort, int maxConn) {
	bool bRet = CV7SecureSocket::Accept(LocalPort, maxConn, TRUE);
	if (bRet) {
		QString csTmp;
		csTmp = QString::asprintf(_T("Socket_Accept%d"), LocalPort);
		m_hAcceptEv = CreateEvent(NULL, FALSE, FALSE, csTmp);
#ifdef DBG_FILE_LOG_STCPS_ENABLE
		QString  tcpLog;
		tcpLog = QString::asprintf(_T("::Accept--Socket_Accept %s ") ,csTmp);
		LogDebugMessage(tcpLog);
	#endif
		csTmp = QString::asprintf(_T("Socket_Accepted%d"), LocalPort);
		m_hAcceptedEv = CreateEvent(NULL, FALSE, FALSE, csTmp);
#ifdef DBG_FILE_LOG_STCPS_ENABLE					
		tcpLog = QString::asprintf(_T("::Accept--Socket_Accepted %s "),csTmp);
		LogDebugMessage(tcpLog);
	#endif
		csTmp = QString::asprintf(_T("ListenSocketClose%d"), LocalPort);
		m_hCloseEv = CreateEvent(NULL, FALSE, FALSE, csTmp);
#ifdef DBG_FILE_LOG_STCPS_ENABLE					
		tcpLog = QString::asprintf(_T("::Accept--ListenSocketClose %s "),csTmp);
		LogDebugMessage(tcpLog);
	#endif
		csTmp = QString::asprintf(_T("ListenSocketBackoff%d"), LocalPort);
		m_hBackoffEv = CreateEvent(NULL, FALSE, FALSE, csTmp);
#ifdef DBG_FILE_LOG_STCPS_ENABLE					
		tcpLog = QString::asprintf(_T("::Accept--ListenSocketBackoff %s "),csTmp);
		LogDebugMessage(tcpLog);
	#endif
	}
	return bRet;
}
//****************************************************************************
/// OnReceive - Override to handle Receive notifications
///
/// @param[in]	n/a
///
/// @return		n/a
///
//****************************************************************************
void CTcpSocket::OnReceive() {
	//qDebug("Setting Recieve event:%d\n",m_hRecvEv);
	if (!SetEvent(m_hRecvEv)) {
		qDebug("Recieve event %d not set\n", m_hRecvEv);
	}
#ifdef TRACE_ALLOW
	else
	{
		qDebug("Recieve event %X set\n",m_hRecvEv);
	}
#endif
	//if window notifications are to be used, post messages here
	if (m_hParent) {
		PostMessage(m_hParent, WM_RECV_TCP_DATA, NULL, NULL);
	}
}
//****************************************************************************
/// AcceptServiceSocket - Override to notify about accepting new incoming sockets
///
/// @param[in]	serviceSock - QAbstractSocket to attach to this instance
/// @param[in] hCloseEv - Event handle to set if socket closes
///
/// @return		n/a
///
//****************************************************************************
void CTcpSocket::AcceptServiceSocket(QAbstractSocket serviceSock, HANDLE hCloseEv) {
#ifdef DBG_FILE_LOG_STCPS_ENABLE	
	QString  tcpLog;
	tcpLog = QString::asprintf(_T("::AcceptServiceSocket %d "), serviceSock);
	LogDebugMessage(tcpLog);
	#endif
	m_hCloseEv = hCloseEv;
	CV7SecureSocket::AcceptServiceSocket(serviceSock, TRUE);
	//qDebug("Socket accepted\n");
	QString csTmp;
	csTmp = QString::asprintf(_T("TCP-Recv-%lu-%u"), m_ulPeer, serviceSock);
	m_hRecvEv = CreateEvent(NULL, FALSE, FALSE, csTmp);
#ifdef DBG_FILE_LOG_STCPS_ENABLE	
	tcpLog = QString::asprintf(_T("::AcceptServiceSocket:m_hRecvEv %s serviceSock - %u"),csTmp,serviceSock);
	LogDebugMessage(tcpLog);
	#endif
//	start(m_readThread);
}
//****************************************************************************
/// ResumeReadThread - resumes the read thread once the parent is ready
///
/// @param n/a
///
/// @return		true if resumed sucessfully
///
//****************************************************************************
bool CTcpSocket::ResumeReadThread() {
	//once events set up, start thread
	if (-1 != start(m_readThread))
		return true;
	else
		return false;
}
//****************************************************************************
/// ResumeAcceptThread - resumes the accept thread once the parent is ready
///
/// @param n/a
///
/// @return		true if resumed sucessfully
///
//****************************************************************************
bool CTcpSocket::ResumeAcceptThread() {
	//once events set up, start thread
	if (-1 != start(m_acceptThread))
		return true;
	else
		return false;
}
//****************************************************************************
/// OnClose - handler override for socket close
///
/// @param[in] closeEvent - reason close has been called
///
/// @return		n/a
///
//****************************************************************************
void CTcpSocket::OnClose(int closeEvent) {
	if (WSAECONNRESET == CV7SecureSocket::GetLastError()) {
		//notify the system that this particular unit has connection issues
		qDebug("PEER %X is having connection trouble - conn reset", this->m_ulPeer);
	}
	if (EVN_CONNCLOSED == closeEvent) {
#ifdef DBG_FILE_LOG_STCPS_ENABLE	
		QString  tcpLog;
		tcpLog = QString::asprintf(_T("::OnClose socket %d"), s);
		LogDebugMessage(tcpLog);
		#endif
		SetEvent(m_hCloseEv);
	}
	if (EVN_SERVERDOWN == closeEvent) {
		//if(m_hServFailed)
		//{
		//	SetEvent(m_hServFailed);
		//}
		if (m_hAcceptEv) {
			//No need to close the mutex in Qt
			m_hAcceptEv = NULL;
		}
		if (m_hAcceptedEv) {
			//No need to close the mutex in Qt
			m_hAcceptedEv = NULL;
		}
		if (m_hCloseEv) {
			//No need to close the mutex in Qt
			m_hCloseEv = NULL;
		}
		if (m_hBackoffEv) {
			//No need to close the mutex in Qt
			m_hBackoffEv = NULL;
		}
	}
}
//****************************************************************************
/// Connect - connect to a remote host
///
/// @param[in] addr - QString  containing IP address nnn.nnn.nnn.nnn
/// @param[in] remotePort - Port on the remote host to connect on
/// @param[in] hCloseEv - Close event to set when conn closes
///
/// @return		true if connect successful
///
//****************************************************************************
bool CTcpSocket::Connect(QString &addr, UINT remotePort, HANDLE hCloseEv) {
#ifdef DBG_FILE_LOG_STCPS_ENABLE	
	QString  tcpLog;
	tcpLog = QString::asprintf(_T("::Connect addr %s"), addr);
	LogDebugMessage(tcpLog);
	#endif
	if (CV7SecureSocket::Connect(addr, remotePort)) {
		QString csTmp;
		csTmp = QString::asprintf(_T("TCP-Recv-%lu-%u"), m_ulPeer, remotePort);
		m_hRecvEv = CreateEvent(NULL, FALSE, FALSE, csTmp);
#ifdef DBG_FILE_LOG_STCPS_ENABLE	
		tcpLog = QString::asprintf(_T("::Connect:m_hRecvEv %s remotePort %u"),csTmp,remotePort);
		LogDebugMessage(tcpLog);
	#endif
		m_hCloseEv = hCloseEv;
		return true;
	} else
		return false;
}
//****************************************************************************
/// Disconnect - disconnect from remote host
///
/// @param n/a
///
/// @return		n/a
///
//****************************************************************************
HRESULT CTcpSocket::Disconnect() {
	//qDebug("Disconnect called\n");
	HRESULT hr = CV7SecureSocket::Disconnect();
	SetEvent(m_hCloseEv);
	return hr;
}
//****************************************************************************
/// Connect - connect to a remote host
///
/// @param[in] addr - QString  containing IP address nnn.nnn.nnn.nnn
/// @param[in] remotePort - Port on the remote host to connect on
/// @param[in] hCloseEv - Close event to set when conn closes
///
/// @return		true if connect successful
///
//****************************************************************************
bool CTcpSocket::OnConnect(QString &addr) {
	bool ret = false;
	if (m_eSocketTransMode == CCESecureSocket::ST_MODE_SECURE) {
		ret = CV7SecureSocket::OnConnect(addr);
	} else {
		ret = true; //True always in non-secure mode
	}
	return ret;
}
#ifdef DBG_FILE_LOG_STCPS_ENABLE
void CTcpSocket::LogDebugMessage(QString  strDebugMsg)
{
	if( NULL != m_pDebugFileLogger )
	{
		QString  strDiagMsg;
		strDiagMsg = QString::asprintf(_T("TcpSock- %s"), strDebugMsg);
		CV7SecureSocket::LogDebugMessage(strDiagMsg);
	}
}
#endif

///////////////////////////CToken Funcs//////////////////////////
#include "token.h"
#include "passsyncengine.h"
//#define TRACE_ALLOW
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
	#include "CStorage.h"
#endif
static QString strLog;
CToken::CToken() : m_tokenTimer(TIMER_NORMAL_RES)
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
, m_pDebugFileLogger(NULL)
#endif
{
	m_bHaveToken = FALSE;
	QMutex * m_cs;
	m_bMaster = FALSE;
	m_usNextID = 0;
	m_usTokenReqCount = 0;
	m_ulTokenHolder = NULL;
	m_TokenReqAddrList.clear();
	m_TokenReqPidList.clear();
	m_ulOurID = 0;
	m_tokenTimer.StopTimer();
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
	strLog = QString::asprintf("CToken.. CTOR.");
	LogDebugMessage(strLog);
	#endif
}
//CToken::CToken(BOOL bMaster)
//{
//	m_bHaveToken = FALSE;
//	InitialiseCriticalSection(&m_cs);
//	m_bMaster = bMaster;
//	m_usNextID = 0;
//	m_sTokenReqCount = 0;
//	m_ulTokenHolder = 0;
//}
CToken::~CToken() {
}
ULONG CToken::TransRequestToken(ULONG ID) {
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
	strLog = QString::asprintf("TransRequestToken.. <ENTRY>.. for ID : %lu",ID);
	LogDebugMessage(strLog);
	strLog = QString::asprintf("TransRequestToken.. m_bMaster: %d m_bHaveToken: %d m_ulTokenHolder: %lu",m_bMaster, m_bHaveToken,m_ulTokenHolder);
	LogDebugMessage(strLog);
#endif
	//check we are master and this is being called appropriately
#ifdef TRACE_ALLOW
	qDebug("Token requested by %X\n",ID);
#endif TRACE_ALLOW
	ULONG ulRetId = 0;
	if (m_bMaster) {
		m_cs.lock();
		bool bTokenElpased = false;
		bool bGotToken = false;
		const ULONG TOKEN_EXPIRY_TIME = 60000; //In milli Seconds
		if ((ID != m_ulTokenHolder) && (m_tokenTimer.ElapsedTimeInMilliSeconds() > TOKEN_EXPIRY_TIME)) {
			bTokenElpased = true;
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE				
			strLog = QString::asprintf("TransRequestToken..TokenExpired with holder %lu.. ID : %lu", m_ulTokenHolder, ID);
			LogDebugMessage(strLog);
			#endif
			ulRetId = TransFinishedWithToken(m_ulTokenHolder);
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE				
			strLog = QString::asprintf("TransRequestToken..TokenReallocated - the new holder %lu.. ID : %lu", m_ulTokenHolder, ID);
			LogDebugMessage(strLog);
			#endif
		}
		if (m_bHaveToken) //Token Available for granting
		{
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE				
			strLog = QString::asprintf("TransRequestToken..Token Available TokenReqAddrList(%d).. ID : %lu", m_TokenReqAddrList.size(), ID);
			LogDebugMessage(strLog);
			#endif
			//pass it on to the the requester
			m_TokenReqAddrList.clear();
			m_ulTokenHolder = ID;
			m_bHaveToken = FALSE;
			ulRetId = ID; // caller knows to send the token
			m_tokenTimer.StartTimer();
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE				
			strLog = QString::asprintf("TransRequestToken..Token approved. for ID : %lu",ID);
			LogDebugMessage(strLog);
			#endif
#ifdef TRACE_ALLOW
			qDebug("Token Approved\n");
#endif TRACE_ALLOW
		} else if (m_ulTokenHolder == ID) //Requester already holding the token..
				{
			ulRetId = ID; // caller knows to send the token
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
			strLog = QString::asprintf("TransRequestToken..Token re-sent. for ID : %lu",ID);
			LogDebugMessage(strLog);
			#endif
			m_tokenTimer.ResetAllTimers();
#ifdef TRACE_ALLOW
			qDebug("Token Re-Sent\n");
#endif TRACE_ALLOW
		} else //if( ulRetId != ID ) //Do not make RetId zero
		{
			//add requester to the list
			m_TokenReqAddrList.push_back(ID);
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
			strLog = QString::asprintf("TransRequestToken..Token Requestor Added to Queue. for ID : %lu",ID);
			LogDebugMessage(strLog);
			#endif
#ifdef TRACE_ALLOW
			qDebug("Token Requestor Added to Queue\n");
#endif TRACE_ALLOW
		}
		m_cs.lock();
	}
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
strLog = QString::asprintf("TransRequestToken.. <EXIT>.. for ID : %lu",ID);
LogDebugMessage(strLog);
#endif
	return ulRetId;
}
ULONG CToken::TransFinishedWithToken(ULONG ID) {
	/*TCHAR tempStr[512];
	 QString  strDbgMsg;
	 strDbgMsg = QString::asprintf("\r\nCToken::TransFinishedWithToken() begin ID %lu at GTC:%u\r\n", ID, GetTickCount());	
	 swprintf(tempStr,_T("PNS: %s"), strDbgMsg);
	 OutputDebugString(tempStr);*/
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
strLog = QString::asprintf("TransFinishedWithToken.. <ENTRY>.. for ID : %lu",ID);
LogDebugMessage(strLog);
strLog = QString::asprintf("TransFinishedWithToken.. m_bMaster : %d m_bHaveToken: %d m_ulTokenHolder: %lu",m_bMaster, m_bHaveToken,m_ulTokenHolder);
LogDebugMessage(strLog);
#endif
	ULONG ulRet = 0;
#ifdef TRACE_ALLOW
	qDebug("Token Released by %X\n",ID);
#endif TRACE_ALLOW
	if (m_bMaster && !m_bHaveToken) {
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
		strLog = QString::asprintf("TransFinishedWithToken..ID :%lu Check releaser is correct peer..",ID);
		LogDebugMessage(strLog);
		#endif
		/*strDbgMsg = QString::asprintf("\r\nCToken::TransFinishedWithToken() CS-m_cs ID %lu at GTC:%u\r\n", ID, GetTickCount());	
		 swprintf(tempStr,_T("PNS: %s"), strDbgMsg);
		 OutputDebugString(tempStr);*/
		m_cs.lock();	//ANOOP 24/APR Added the CRITICAL SECTION 
		//check releaser is correct peer
		if (ID == m_ulTokenHolder) {
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
			strLog = QString::asprintf("TransFinishedWithToken..ID :%lu .",ID);
			LogDebugMessage(strLog);
			#endif
			m_tokenTimer.StopTimer();
			//find next requestor and change current token holder
			if (m_TokenReqAddrList.size()) {
				m_ulTokenHolder = m_TokenReqAddrList.front();
				m_TokenReqAddrList.pop_front();
				ulRet = m_ulTokenHolder;
				if (NULL != ulRet) {
					m_tokenTimer.StartTimer();
				}
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
		strLog = QString::asprintf("TransFinishedWithToken.. Token Re-Issued for ID : %lu",m_ulTokenHolder);
		LogDebugMessage(strLog);
		#endif
#ifdef TRACE_ALLOW
				qDebug("Token Re-Issued to %X\n",ulRet);
#endif TRACE_ALLOW
			}
			//or mark token as not is use
			else {
#ifdef TRACE_ALLOW
				qDebug("Token Now Available\n");
#endif TRACE_ALLOW
				m_ulTokenHolder = NULL;
				m_bHaveToken = TRUE;
				ulRet = 0xFFFFFFFF;
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
				strLog = QString::asprintf("TransFinishedWithToken..Token Now Available(m_bHaveToken %d).m_ulTokenHolder :%lu ulRet %lu", m_bHaveToken, m_ulTokenHolder, ulRet);
				LogDebugMessage(strLog);
				#endif
			}
		} else {
			//TransFinished request came when the tokenholder is busy with
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
			strLog = QString::asprintf("TransFinishedWithToken..No Action due to Token Hodler %lu is still busy and this requestor ID :%lu is not the holder", m_ulTokenHolder, ID);
			LogDebugMessage(strLog);
			#endif			
		}
		m_cs.lock();	//ANOOP 24/APR Added the CRITICAL SECTION
		/*strDbgMsg = QString::asprintf("\r\nCToken::TransFinishedWithToken() CS-m_cs leave ID %lu at GTC:%u\r\n", ID, GetTickCount());	
		 swprintf(tempStr,_T("PNS: %s"), strDbgMsg);
		 OutputDebugString(tempStr)*/;
	}
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
	strLog = QString::asprintf("TransFinishedWithToken.. <EXIT>.. for ID %lu with RetID : %lu m_ulTokenHolder: %lu m_bHaveToken : %d",ID, ulRet,m_ulTokenHolder, m_bHaveToken);
	LogDebugMessage(strLog);
	#endif
	/*strDbgMsg = QString::asprintf("\r\nCToken::TransFinishedWithToken() end ID %lu at GTC:%u\r\n", ID, GetTickCount());	
	 swprintf(tempStr,_T("PNS: %s"), strDbgMsg);
	 OutputDebugString(tempStr);*/
	return ulRet;
}
TOKEN_STATE CToken::PeerRequestToken(USHORT *pID, DWORD dwWait)	//wait in ms
		{
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
	strLog = QString::asprintf("PeerRequestToken.. <ENTRY>..");
	LogDebugMessage(strLog);
	strLog = QString::asprintf("PeerRequestToken.. m_bMaster : %d m_bHaveToken: %d",m_bMaster, m_bHaveToken);
	LogDebugMessage(strLog);
	#endif
	TOKEN_STATE tsRet = TOK_ERR;
	if (!m_bMaster) {
		//add the requester ID to the list and request the token if necessary
		m_cs.lock();
		*pID = ++m_usNextID;
#ifdef TRACE_ALLOW
		qDebug("Token Req ID %X\n",*pID);
#endif TRACE_ALLOW
		m_TokenReqPidList.push_back(m_usNextID);
		if (!m_bHaveToken && (m_TokenReqPidList.size() <= 1))	//no need to request more than once
				{
			if (CPassSyncEngine::GetHandle()->RequestToken()) {
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
				strLog = QString::asprintf("PeerRequestToken.. Token Requested.");
				LogDebugMessage(strLog);
				#endif
#ifdef TRACE_ALLOW
				qDebug("Token Requested\n");
#endif TRACE_ALLOW
			} else {
				//connection to master not available
				tsRet = TOKEN_CONN_UNAVAIL;
				// CR2992: The connection is unavailable. It makes no sense to 
				// retain a new entry in the token request list.
				m_TokenReqPidList.remove(m_usNextID);
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
				strLog = QString::asprintf("PeerRequestToken.. Token request failed: ID %d Removed from list due to failed master connection.",m_usNextID);
				LogDebugMessage(strLog);
				#endif
#ifdef TRACE_ALLOW
				qDebug("Token request failed: ID %X removed from list due to failed master connection\n", m_usNextID);
#endif TRACE_ALLOW
			}
		}
		m_cs.lock();
		if (tsRet == TOK_ERR) {
			tsRet = TOKEN_REQD;
			//wait for the token if the requester wants to 
			if (dwWait) {
				DWORD interval = 200;
				DWORD LoopCnt = dwWait / interval;
				//catch to force at least one iteration
				if (LoopCnt < 1)
					LoopCnt = 1;
				while (!m_bHaveToken && m_TokenReqPidList.size()) //m_bHaveToken declared volatile. size check in case we have been reset
				{
					if (0 == LoopCnt) {
						tsRet = TOKEN_REQ_TIMEOUT;
						break;
					}
					LoopCnt--;
					sleep(interval);
				}
				if (!m_TokenReqPidList.size())
					tsRet = TOKEN_RESET;
			}
			if (m_bHaveToken) {
				tsRet = TOKEN_OWNED;
#ifdef TRACE_ALLOW
				qDebug("Token Recieved\n");
	#endif TRACE_ALLOW
			}
		}
	}
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
	strLog = QString::asprintf("PeerRequestToken.. <EXIT>..");
	LogDebugMessage(strLog);
	#endif
	return tsRet;
}
TOKEN_STATE CToken::PeerFinishedWithToken(USHORT ID) {
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
strLog = QString::asprintf("PeerFinishedWithToken.. <ENTRY>..for Token Req ID %d",ID);
LogDebugMessage(strLog);
#endif
#ifdef TRACE_ALLOW
	qDebug("Token Req ID %X Finished\n",ID);
#endif TRACE_ALLOW
	TOKEN_STATE tsRet = TOK_ERR;
	if (!m_bMaster) {
		m_cs.lock();
		//find in list
		if (0 != m_TokenReqPidList.size()) {
			m_TokenReqPidList.remove(ID);
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
			strLog = QString::asprintf("PeerFinishedWithToken.. Removed Token Req ID %d",ID);
			LogDebugMessage(strLog);
#endif
#ifdef TRACE_ALLOW
			qDebug("ID removed\n");
#endif TRACE_ALLOW
			if (0 == m_TokenReqPidList.size()) {
				//time to give the token back
				if (m_bHaveToken && CPassSyncEngine::GetHandle()->ReleaseToken()) {
#ifdef TRACE_ALLOW
					qDebug("Token Released\n");
#endif TRACE_ALLOW
					m_bHaveToken = FALSE;
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
					strLog = QString::asprintf("PeerFinishedWithToken..Token Released..Token available..HaveToken :%d",m_bHaveToken);
					LogDebugMessage(strLog);
#endif
				}
				tsRet = TOKEN_RETD;
			} else {
				tsRet = TOKEN_OWNED;
			}
		}
		m_cs.lock();
	}
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
	strLog = QString::asprintf("PeerFinishedWithToken..<EXIT>.");
	LogDebugMessage(strLog);
#endif
	return tsRet;
}
void CToken::TokenArrived() {
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
	strLog = QString::asprintf("TokenArrived..<ENTRY>.");
	LogDebugMessage(strLog);
#endif
	m_cs.lock();		//ANOOP 24/APR code uncommented. Need the CRITICAL SECTION
#ifdef TRACE_ALLOW
	qDebug("Token Arrived\n");
#endif TRACE_ALLOW
	if (m_TokenReqPidList.size()) {
		m_bHaveToken = TRUE;
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
		strLog = QString::asprintf("TokenArrived..HaveToken :%d .",m_bHaveToken);
		LogDebugMessage(strLog);
		#endif
	} else {
		if (CPassSyncEngine::GetHandle()->ReleaseToken()) {
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
			strLog = QString::asprintf("TokenArrived..Token Returned..");
			LogDebugMessage(strLog);
			#endif
#ifdef TRACE_ALLOW
						qDebug("Token Returned\n");
			#endif TRACE_ALLOW
		}
	}
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
	strLog = QString::asprintf("TokenArrived..<EXIT>.");
	LogDebugMessage(strLog);
#endif
	m_cs.lock();	//ANOOP 24/APR code uncommented. Need the CRITICAL SECTION
}
void CToken::ForceTokenReset() {
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE		
	strLog = QString::asprintf("ForceTokenReset..<ENTRY>.");
	LogDebugMessage(strLog);
	#endif
	m_cs.lock();
	m_bHaveToken = m_bMaster;
	m_ulTokenHolder = NULL;
	m_TokenReqAddrList.clear();
	m_TokenReqPidList.clear();
	m_cs.lock();
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
	QString  strLog;
	strLog = QString::asprintf("ForceTokenReset..<EXIT>..");
	LogDebugMessage(strLog);
	#endif
#ifdef TRACE_ALLOW
	qDebug("Token Reset\n");
#endif TRACE_ALLOW
}
void CToken::RefreshTimer(ULONG ulRequestor) {
	if (m_bMaster) {
		if (m_ulTokenHolder == ulRequestor) {
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
			QString  strLogMsg;
			strLogMsg = QString::asprintf("RefreshTimer..ElapsedSofar %lld m_ulTokenHolder: %lu and m_bHaveToken: %d.", m_tokenTimer.ElapsedTimeInMilliSeconds(), m_ulTokenHolder,m_bHaveToken);
			LogDebugMessage(strLogMsg);
			#endif
			m_tokenTimer.ResetAllTimers();
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
			strLogMsg = QString::asprintf("RefreshTimer Reset..ElapsedSofar %lld m_ulTokenHolder: %lu and m_bHaveToken: %d.", m_tokenTimer.ElapsedTimeInMilliSeconds(), m_ulTokenHolder,m_bHaveToken);
			LogDebugMessage(strLogMsg);
			#endif
		}
	}
}
#ifdef DBG_FILE_LOG_NETSYNC_ENABLE
void CToken::SetDebugLogger(CDebugFileLogger* pDbgFileLogger)
{
	m_pDebugFileLogger = pDbgFileLogger;
}
void CToken::LogDebugMessage(QString  strDebugMsg)
{
	if( NULL != m_pDebugFileLogger )
	{
		QString  strDiagMsg;
		strDiagMsg = QString::asprintf(_T("PNS-CToken::%s at GTC:%u\r\n"), strDebugMsg, GetTickCount());
		m_pDebugFileLogger->WriteToDebugLogFile(strDiagMsg);
	}
}
#endif

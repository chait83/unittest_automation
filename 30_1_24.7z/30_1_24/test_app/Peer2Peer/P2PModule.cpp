/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Processing
/// @n Filename: DataProcessing.cpp
/// @n Desc:	 Perform all major operation for data processing
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  12  Stability Project 1.7.1.3 7/2/2011 4:59:36 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  11  Stability Project 1.7.1.2 7/1/2011 4:38:34 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  10  Stability Project 1.7.1.1 3/17/2011 3:20:32 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  9 Stability Project 1.7.1.0 2/15/2011 3:03:36 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// ****************************************************************
//#include "math.h"
#include "P2PModule.h"
//#include "FunctionPack.h"
#include "V6Config.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//******************************************************
/// CP2PModule Constructor
///
//******************************************************
CP2PModule::CP2PModule(T_MODULE_ID moduleId) : CV6ActiveModule(moduleId) {
	//m_NoCoverageFoundCounter = 0;
	m_bFirstRun = TRUE;
}
//******************************************************
/// Destructor
///
//******************************************************
CP2PModule::~CP2PModule() {
}
//******************************************************
/// CP2PModule CleanUp
///
//******************************************************
BOOL CP2PModule::CleanUp(void) {
	//use this to shut down the singleton
	m_pP2PEngine->CleanUp();
	m_pP2PEngine = NULL;
	return TRUE;
}
//******************************************************
/// Primary initialisation for Module, before tread is started
///
/// @return - T_V6ACTMOD_RETURN_VALUE
//******************************************************
T_V6ACTMOD_RETURN_VALUE CP2PModule::PerformPrimaryInitialisation(void) {
	T_V6ACTMOD_RETURN_VALUE retVal = V6ACTMOD_OK;
	m_DPMode = PM_MODE_IDLE;		// Set data processing mode into startup
	// Get a handle on the Pre Process Queues singleton object
	m_pP2PEngine = CP2PEngine::GetHandle();
	if (m_pP2PEngine == NULL) {
		retVal = V6ACTMOD_INITIALISATION_FAILED;
	} else
		m_pP2PEngine->AllowRebuild();
	return retVal;
}
//******************************************************
/// Secondary Initialisation, start thread
///
/// @return - T_V6ACTMOD_RETURN_VALUE 
//******************************************************
T_V6ACTMOD_RETURN_VALUE CP2PModule::PerformSecondaryInitialisation(void) {
	T_V6ACTMOD_RETURN_VALUE retVal = V6ACTMOD_OK;
	//do nothing here for now....
	//// Get handle on Script Manager, this is a Global to the Processing system, defined in Scripts.cpp and .h
	//pGlbScriptManager = CScriptManager::GetHandle();
	//if( NULL == pGlbScriptManager )
	//{
	//	return V6ACTMOD_INITIALISATION_FAILED;
	//  }
	//pGlbScriptManager->Initialise();	// Initialise the script manager
	//// Initialise Pen and Event manager
	//m_pPenManager->Initialise();
	//m_pEventManager->Initialise();
	//m_pP2PEngine->InitP2P();
	//// Get handle on general data items update in processing
	//m_pIdleTimer = reinterpret_cast<CDataItemGeneral *>(pDIT->GetDataItemPtr( DI_GENERAL, DI_GENTYPE_GENERAL, DI_GEN_IDLE ));
	//m_pMemLoad = reinterpret_cast<CDataItemGeneral *>(pDIT->GetDataItemPtr( DI_GENERAL, DI_GENTYPE_GENERAL, DI_GEN_MEM_LOAD ));
	//m_pMemTotal = reinterpret_cast<CDataItemGeneral *>(pDIT->GetDataItemPtr( DI_GENERAL, DI_GENTYPE_GENERAL, DI_GEN_MEM_PHYS_TOTAL ));
	//m_pMemAvail = reinterpret_cast<CDataItemGeneral *>(pDIT->GetDataItemPtr( DI_GENERAL, DI_GENTYPE_GENERAL, DI_GEN_MEM_PHYS_AVAIL ));
	//m_pVMemTotal = reinterpret_cast<CDataItemGeneral *>(pDIT->GetDataItemPtr( DI_GENERAL, DI_GENTYPE_GENERAL, DI_GEN_MEM_VIRT_TOTAL ));
	//m_pVMemAvail = reinterpret_cast<CDataItemGeneral *>(pDIT->GetDataItemPtr( DI_GENERAL, DI_GENTYPE_GENERAL, DI_GEN_MEM_VIRT_AVAIL ));
	//m_pVMemLowest = reinterpret_cast<CDataItemGeneral *>(pDIT->GetDataItemPtr( DI_GENERAL, DI_GENTYPE_GENERAL, DI_GEN_MEM_VIRT_LOWTIDE ));
	//m_pQMCPanel = reinterpret_cast<CDataItemGeneral *>(pDIT->GetDataItemPtr( DI_GENERAL, DI_GENTYPE_GENERAL, DI_GEN_Q_MCPAN ));
	//m_pQMCMess = reinterpret_cast<CDataItemGeneral *>(pDIT->GetDataItemPtr( DI_GENERAL, DI_GENTYPE_GENERAL, DI_GEN_Q_MCMES ));
	//m_pQMCChart = reinterpret_cast<CDataItemGeneral *>(pDIT->GetDataItemPtr( DI_GENERAL, DI_GENTYPE_GENERAL, DI_GEN_Q_MCCHA ));
	//m_pQMCLog = reinterpret_cast<CDataItemGeneral *>(pDIT->GetDataItemPtr( DI_GENERAL, DI_GENTYPE_GENERAL, DI_GEN_Q_MCLOG ));
	//m_pQMCOther = reinterpret_cast<CDataItemGeneral *>(pDIT->GetDataItemPtr( DI_GENERAL, DI_GENTYPE_GENERAL, DI_GEN_Q_MCOTH ));
	//m_pQMCBlkRel = reinterpret_cast<CDataItemGeneral *>(pDIT->GetDataItemPtr( DI_GENERAL, DI_GENTYPE_GENERAL, DI_GEN_Q_BLK_REL ));
	//m_pQMCHeart = reinterpret_cast<CDataItemGeneral *>(pDIT->GetDataItemPtr( DI_GENERAL, DI_GENTYPE_GENERAL, DI_GEN_Q_HB ));
	//pDEVICE_INFO->GetMemoryStatus();
	//m_pMemTotal->SetValue( pDEVICE_INFO->GetMemoryTotalPhysicalK() );
	//m_pMemAvail->SetValue( pDEVICE_INFO->GetMemoryAvailablePhysicalK() );
	//m_pMemLoad->SetValue( pDEVICE_INFO->GetMemoryLoadPercentage() );
	//m_pVMemTotal->SetValue( pDEVICE_INFO->GetMemoryTotalVirtualK() );
	//m_pVMemAvail->SetValue( pDEVICE_INFO->GetMemoryAvailableVirtualK() );
	//m_pVMemLowest->SetValue( pDEVICE_INFO->GetMemoryAvailableVirtualK() );
	return retVal;
}
//******************************************************
/// MESSAGE HANDLER CALLBACK 
/// Start normal operation after a config change or startup
///
/// @return - T_V6ACTMOD_RETURN_VALUE 
//******************************************************
T_V6ACTMOD_RETURN_VALUE CP2PModule::NormalOperation() {
	T_V6ACTMOD_RETURN_VALUE Ret = V6ACTMOD_OK;
	if (m_bFirstRun) {
		m_bFirstRun = FALSE;
		T_PCOMMUNICATIONS ptCommsData = pGlbSetup->GetCommsSetupConfig()->GetCommsBlock(CONFIG_COMMITTED);
		if (ptCommsData->P2P.Enabled) {
#ifdef PC_USE			
			if (!CEmulator::m_SimulatorVol[0]) // no P2P if running as simulator
#endif		
			{
				const USHORT usOFFSET = ptCommsData->P2P.SetNumber * 2;
				const USHORT usTCP_PORT = ptCommsData->P2P.TCPPort + usOFFSET;
				const USHORT usUDP_PORT = usTCP_PORT + 1;
				if (InitP2P(usTCP_PORT, usUDP_PORT) != P2P_INIT_OK) {
					Ret = V6ACTMOD_ACTION_NOT_PERFORMED;
				}
			}
		}
	}
	m_DPMode = PM_MODE_RUN;
	return Ret;
}
//******************************************************
/// MESSAGE HANDLER CALLBACK 
/// Prepare for a configuration change
///
/// @return - T_V6ACTMOD_RETURN_VALUE 
//******************************************************
T_V6ACTMOD_RETURN_VALUE CP2PModule::SetupConfigChangePreparation() {
	// At this stage the Input Scheduler would have gathered data from all cards and 
	// placed in pre process queues. The Data Processing thread must now process the 
	// remaining data in the pre-process queues and idle until a setup change complete is issued
//	ProcessData(TRUE);		// Process all remaining Data
	//no rebuild local details
	m_pP2PEngine->PreventRebuild();
	m_DPMode = PM_MODE_IDLE;
	return V6ACTMOD_OK;
}
//******************************************************
/// MESSAGE HANDLER CALLBACK 
/// Configuration change completed, use new config
///
/// @return - T_V6ACTMOD_RETURN_VALUE 
//******************************************************
T_V6ACTMOD_RETURN_VALUE CP2PModule::SetupConfigChangeComplete() {
	//update the local details
	m_pP2PEngine->AllowRebuild();
	m_pP2PEngine->RebuildLocalDetails();
	m_DPMode = PM_MODE_IDLE;
	return V6ACTMOD_OK;
}
//******************************************************
/// Shutdown has been requested close down all processes
/// MESSAGE HANDLER CALLBACK 
/// ready for final shutdown
///
/// @return - T_V6ACTMOD_RETURN_VALUE 
//******************************************************
T_V6ACTMOD_RETURN_VALUE CP2PModule::ShutdownPreparation() {
//	ProcessData(TRUE);		// Process all remaining Data
//	m_pEventManager->PrepareForConfigChange();	
	if (m_pP2PEngine->IsInitialised())
		CleanUp();
	m_DPMode = PM_MODE_IDLE;
	return V6ACTMOD_OK;
}
//******************************************************
/// Final shutdown, release all resources allocated in module
/// MESSAGE HANDLER CALLBACK 
///
/// @return - T_V6ACTMOD_RETURN_VALUE 
//******************************************************
T_V6ACTMOD_RETURN_VALUE CP2PModule::Shutdown(void) {
	m_DPMode = PM_MODE_EXIT;
	return V6ACTMOD_OK;
}
//******************************************************
/// Get the current execution mode of the data proicessing 
/// module. This will call ManualMessageHandler() which will receive messages from 
/// the control sequencer and call one of the message handlers above. Each message
/// handler will set the m_DPMode.
///
/// @return - T_DATAPROCESS_MODE current execution mode 
//******************************************************
T_P2PMOD_MODE CP2PModule::GetMode() {
	ManualMessageHandler();
	return m_DPMode;
}

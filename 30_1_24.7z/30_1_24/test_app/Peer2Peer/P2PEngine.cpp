//////////////////////////////////////////////////////////////////////
/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Peer2Peer
/// @n Filename:  P2PEngine.cpp
/// @n Description: implementation of the CP2PEngine class.
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  84  Aristos  1.78.1.3.1.0 9/19/2011 4:51:17 PM  Hemant(HAIL)  
//  Stability recorder source code (JI Release) updated for WatchDog
//  Timer functionality.
//  83  Stability Project 1.78.1.3 7/2/2011 4:59:36 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  82  Stability Project 1.78.1.2 7/1/2011 4:38:34 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  81  Stability Project 1.78.1.1 3/17/2011 3:20:32 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
// $
//
// **************************************************************************
#include "P2PEngine.h"
#include "V7TLSUtilities.h"
#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TMPV5 ) ) && ( ! defined ( TRENDMANAGERPRO ) ) && ( !defined(P2P_XSERIES) ) && (! defined (P2P_WRAPPER))
#include "ThreadInfo.h"
#endif
// Some includes not needed in Comms Server because we do not need the firmware
// functionality.
#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TMPV5 ) ) && ( ! defined ( TRENDMANAGERPRO ) ) && (! defined (P2P_WRAPPER))
#include "modbuswrapper.h"
#include "V6MessageBoxDlg.h"
#endif
#define WM_MULTICAST_DATA WM_USER+1
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//#define TRACE_ALLOW
const char CP2PEngine::EOT = 0x13;
const USHORT CP2PEngine::APP_ID = 0x1329;
const USHORT CP2PEngine::MSG_OVHD = sizeof(CP2PEngine::T_DataHdr) + 1; //+1 for EOT
const UCHAR MAX_PEERS = 200;
// Initial implementation had this at 15. This number is plenty big enough for
// PC, but for CE the real limit seems to be much lower i.e. 5.
const int CP2PEngine::m_iMAX_CONNECTION_BACKLOG = 15;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CP2PEngine *CP2PEngine::m_pInstance = NULL;
QMutex m_CreationMutex;
const USHORT CP2PEngine::m_usMAX_SETS = 8;
//this needs to be a singleton
#ifdef P2P_WRAPPER
T_MSGLISTSER_RETURN_VALUE LogDummyMessage( const T_MSGLISTSER_P2P_MSG_TYPE msgType, 
   const QString  &rstrMESSAGE )
{
	
	return MSGLISTSER_OK;
}
T_MSGLISTSER_RETURN_VALUE LogDummyMessage( const T_MSGLISTSER_DIAGNOSTIC_MSG_TYPE msgType, 
   const QString  &rstrMESSAGE )
{
	
	return MSGLISTSER_OK;
}
#endif
//****************************************************************************
/// The first time this function is called it will create the single instance
/// of CP2PEngine, Subsequent calls will return the Pointer to the instance
/// which has already been created.  
///
/// @param[in] 	  - None
///
/// @return Pointer to the Password Authentication UI 
/// 
//****************************************************************************
CP2PEngine* CP2PEngine::GetHandle() {
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;
	if (NULL == m_pInstance) {
		// An instance has yet to be completed
		m_CreationMutex = CreateMutex(NULL,					  // No security descriptor
				FALSE,					  // Mutex object not owned
				TEXT("P2PEngine"));	  // Object name
		waitSingleObjectResult = m_CreationMutex.tryLock(2000);
		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:
			// Object was signaled
			if (NULL == m_pInstance) {
				m_pInstance = new CP2PEngine;
			} // End of IF
			if ( FALSE == m_CreationMutex.unlock()) {
#if (defined( _UNICODE) ) && (! defined (P2P_WRAPPER))
					CV6MessageBoxDlg Dlg(_T("Error"),_T("P2PEngine not started Error - Mutex exists!"));
					Dlg.exec();
#else
				QMessageBox(_T("P2PEngine not started Error"), MB_OK);
#endif
				//V6WarningMessageBox( NULL, L"Failed to release PassAuthMgr mutex", L"CPassAuthUI Error", MB_OK );  
			} // End of IF
			break;
		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
#if (defined( _UNICODE)) && (! defined (P2P_WRAPPER))
				CV6MessageBoxDlg Dlg(_T("Error"),_T("P2PEngine WaitForSingleObject Error"));
				Dlg.exec();
#else
			QMessageBox(_T("P2PEngine WaitForSingleObject Error"), MB_OK);
#endif
			//V6WarningMessageBox( NULL, L"P2PEngine WaitForSingleObject Error", L"CPassAuthUI Error", MB_OK ); 
			break;
		} // End of SWITCH 
		// Close the Mutex as no longer required
		//No need to close the mutex in Qt
	} // End of IF 
	return (m_pInstance);
}
//****************************************************************************
/// Default Constructor  
///
/// Initialise variables here
/// 
//****************************************************************************
CP2PEngine::CP2PEngine()
#ifndef SP2P_ENABLE
: m_ListenSock(CCESecureSocket::ST_MODE_NON_SECURE) //Ensure Non Secure Mode
#else
: m_ListenSock(CCESecureSocket::ST_MODE_SECURE) //Ensure Secure Mode
#endif
{
	m_pEvents = &m_Events[0];
	m_iEventCount = NUM_EVENTS;
	m_hP2PInit = NULL;
	m_discoveryState = STATE_START;
	memset(m_discoveryEvent, NULL, sizeof(BOOL) * MAX_STATE_EVENTS);
	m_EventProcessed = TRUE;
	QMutex * m_csMsgList;
	QMutex * m_csPeerList;
	QMutex * m_csConnList;
	QMutex * m_csArbList;
	QMutex * m_csMasterArbList;
	QMutex * m_csEvents;
	QMutex * m_csLocalName;
	QMutex * m_csBackupPeerList;
	QMutex * m_csLocalDetails;
	for (int count = 0; count < NUM_EXT_MODULES; ++count)
		InitializeCriticalSection(&m_csExtModDataList[count]);
	m_ulArbitrator = NULL;
	m_bAllPeersCollected = FALSE;
	m_bArbConferConfirmed = FALSE;
	m_hArbThread = NULL;
	memset(&m_pMasterArbitrator, NULL, sizeof(m_pMasterArbitrator));
	//PSR Fix for PAR #1-1VKZOAA - GR recorder password does not synchronise with X-series
	m_pLocalDetails = NULL;
	// Default IP address, serial number and modbus slave id
	T_PEER_ID tPeerId;
	//This is a SV5 supported recorder
	//This decides what is the Stream Version and PeerVariant the recorder is running in
	tPeerId.ulStrucVersion = Glb_STREAM_VERSION_5;
	m_pLocalDetails = new CSV5Peer(tPeerId); //This is of SV5 new genration peer type	
	m_pLocalDetails->Initialize();
	m_bInitialised = FALSE;
	m_usTcpPort = NULL;
	m_usUdpPort = NULL;
	bRescanProg = FALSE;
	m_bRebuildAllow = TRUE;
	m_bEssEnabled = FALSE;
	// Add the local details always as first in list for both main peer list
	// and the backup peer list. The routines for clearing lists never delete
	// the contents of the first entry because it is address of stack memory.
	m_PeerList.prepend(m_pLocalDetails);
	m_BackupPeerList.prepend(m_pLocalDetails);
	memset(m_haExtModules, 0, sizeof(HANDLE) * NUM_EXT_MODULES);
	m_hStateThread = NULL;
	m_hDispThread = NULL;
	memset(m_Events, NULL, NUM_EVENTS * sizeof(HANDLE));
	m_hStateChangeEvent = NULL;
	m_hArbitratorEvent = NULL;
	m_ulLocalIPOverride = 0;
}
//****************************************************************************
/// Default Destructor  
///
/// final cleanup
/// 
//****************************************************************************
CP2PEngine::~CP2PEngine() {
	//deletion of mutex not required
	//deletion of mutex not required
	//deletion of mutex not required
	//deletion of mutex not required
	//deletion of mutex not required
	//deletion of mutex not required
	//deletion of mutex not required
	//deletion of mutex not required
	for (int count = 0; count < NUM_EXT_MODULES; ++count)
		DeleteCriticalSection(&m_csExtModDataList[count]);
	if (m_pEvents != &m_Events[0])
		delete[] m_pEvents;
	if (m_Events[P2P_SHUTDOWN]) {
		CloseHandle(m_Events[P2P_SHUTDOWN]);
		m_Events[P2P_SHUTDOWN] = NULL;
	}
	if (m_Events[TCP_CONN_CLOSE]) {
		CloseHandle(m_Events[TCP_CONN_CLOSE]);
		m_Events[TCP_CONN_CLOSE] = NULL;
	}
	if (m_Events[TCP_SERV_FAIL]) {
		CloseHandle(m_Events[TCP_SERV_FAIL]);
		m_Events[TCP_SERV_FAIL] = NULL;
	}
	if (m_Events[ADD_OUT_CONN]) {
		CloseHandle(m_Events[ADD_OUT_CONN]);
		m_Events[ADD_OUT_CONN] = NULL;
	}
}
//****************************************************************************
/// InitP2P - starts the P2P system, inits winsock to 2.2, gets the local address 
/// Starts the multicast socket and the listening socket, and starts the event 
/// handling thread
///
/// @param[in]	usTcpPort is the TCP port for connections. 
/// @param[in]	usUdpPort is the UDP port for connections.
/// @param[in]	ulLocalIPOverride defaults to 0 if not given and can be used
///				to indicate a preferred connection when a device that is 
///				running Peer Services is using more than one network adapter.
///
/// @return - T_P2P_INIT_RETURN 
///  P2P_INIT_OK if OK 
/// 
//****************************************************************************
T_P2P_INIT_RETURN CP2PEngine::InitP2P(USHORT usTcpPort, USHORT usUdpPort, ULONG ulLocalIPOverride) {
	m_usTcpPort = usTcpPort;
	m_usUdpPort = usUdpPort;
	// Initialise the random number generator based on the serial number which should always be unique -
	// this is required for the P2P engine when responding to broadcast messages so as to reduce the liklihood
	// of a collision
#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TMPV5 ) && ! defined ( TTR6SETUP ) ) && ( ! defined ( TRENDMANAGERPRO ) ) && (! defined (P2P_WRAPPER))
	srand( pSYSTEM_INFO->GetSerialNumber());
#endif
	// Local override defaults to 0 to mean there is no override.
	m_ulLocalIPOverride = ulLocalIPOverride;
	QString strInfo("");
	strInfo = QString::asprintf(_T("Peer Services: Initialising using port numbers %u and %u"), usTcpPort, usUdpPort);
	LOG_P2P_MESSAGE(MSGLISTSER_P2P_INFO, strInfo);
	//startup the multicast and TCP servers
	WSADATA wsaData;
	int retVal;
	T_P2P_INIT_RETURN Ret = P2P_INIT_OK;
	//make sure this isn't running elsewhere in the system
	m_hP2PInit = CreateMutex(NULL, FALSE, _T("P2P-192DA8A2-0729-429b-8119-8BFD2CE94EDC"));
	DWORD err = GetLastError();
	if (ERROR_ALREADY_EXISTS != err && ERROR_ACCESS_DENIED != err) {
		retVal = WSAStartup(0x0202, &wsaData);
		if (retVal) {
			//failure
			Ret = P2P_INIT_WINSOCK_ERR;
		} else {
			char buf[GENERALCONFIG_NAME_LEN];
			DWORD bufLen = GENERALCONFIG_NAME_LEN;
			// find the modbus slave ID (default it to 0 ).
			m_pLocalDetails->setModbusSlaveID(0);
#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TMPV5 ) && ! defined ( TTR6SETUP ) ) && ( ! defined ( TRENDMANAGERPRO ) ) && (! defined (P2P_WRAPPER))
			CModBusStats *pMbusStats = CModBusStats::GetHandle();
			T_PCOMMUNICATIONS pCom = pMbusStats->CurrentConfiguration();
			if (pCom) {
				//PSR Fix for PAR #1-1VKZOAA - GR recorder password does not synchronise with X-series
				m_pLocalDetails->setModbusSlaveID(pCom->ModbusSlave.Address);
			}
#endif
			//Lets get the local IP address for creation of Peer ID's
			//--------------------------------
			// Setup the hints address info structure
			// which is passed to the getaddrinfo() function
			addrinfo aiHints, *aiList, *aiFirst = NULL;
			memset(&aiHints, 0, sizeof(addrinfo));
			aiHints.ai_family = PF_INET;
			aiHints.ai_flags = AI_PASSIVE;
			gethostname(buf, bufLen);
			//PSR Fix for PAR #1-1VKZOAA - GR recorder password does not synchronise with X-series
			m_pLocalDetails->setNetName(buf);
			//getaddrinfo will return a linked list which needs to be traversed
			// return value of 0 indicates success.
			retVal = getaddrinfo(buf, NULL, &aiHints, &aiList);
			if (0 == retVal) {
				aiFirst = aiList;
				BOOL bFound = FALSE;
				while (aiList != NULL && !bFound) {
					bufLen = 50;
					if (PF_INET == aiList->ai_family) {
						// Currently no check is made to avoid loopback. Such a
						// check may not be applicable but if problems are 
						// experienced in the future then it should be a 
						// consideration. See MulticastSocket.cpp.
						// Has a preferred connection been specified?
						if ((0 != m_ulLocalIPOverride)) {
#if defined ( TRACE_ALLOW )
							qDebug(	_T("Comparing %#x with %#x in CP2PEngine::InitP2P().\n"),
									m_ulLocalIPOverride,
									((SOCKADDR_IN*)aiList->ai_addr)->sin_addr.S_un.S_addr
									);
#endif
							// Is this the preferred connection?
							if (((SOCKADDR_IN*) aiList->ai_addr)->sin_addr.S_un.S_addr == m_ulLocalIPOverride) {
#if defined ( TRACE_ALLOW )
								qDebug(	_T("Matched the address %#x with %#x.\n"),
										((SOCKADDR_IN*)aiList->ai_addr)->sin_addr.S_un.S_addr,
										m_ulLocalIPOverride
										);
#endif			
								// Found the preferred connection.
								bFound = TRUE;
								memcpy(&m_LocAddrV4, aiList->ai_addr, sizeof(SOCKADDR_IN));
							}
#if defined ( TRACE_ALLOW )
							else
							{
								qDebug(	_T("Ignored the address %#x as it did not match with %#x.\n"),
										((SOCKADDR_IN*)aiList->ai_addr)->sin_addr.S_un.S_addr,
										m_ulLocalIPOverride
										);
							}
#endif
						} else {
							// No local IP override provided so first found is
							// used as it is expected to be the only one found.
							bFound = TRUE;
							memcpy(&m_LocAddrV4, aiList->ai_addr, sizeof(SOCKADDR_IN));
#if defined ( TRACE_ALLOW )
							qDebug(	_T("Using local address of %#x as no local override was specified.\n"),
									((SOCKADDR_IN*)aiList->ai_addr)->sin_addr.S_un.S_addr
									);
#endif
						}
					}
					// Move on to next.
					aiList = aiList->ai_next;
					// If there are no more entries in the list and we have not
					// found what we are looking for then try again.
					if (aiList == NULL && !bFound) {
						// Free up entire list returned by getaddrinfo().
						freeaddrinfo(aiFirst);
						// We failed to get the connection, which might be
						// because preferred connection is not there, in which
						// case forget about it.
						m_ulLocalIPOverride = 0;
						// Try to get info again.
						retVal = getaddrinfo(buf, NULL, &aiHints, &aiList);
						if (0 == retVal) {
							// Successful call, lets go round the loop again.
							aiFirst = aiList;
						}
					}
				} // end while loop - aiList is valid and not bFound yet
				// Free up entire list that was returned by getaddrinfo().
				freeaddrinfo(aiFirst);
				//PSR Fix for PAR #1-1VKZOAA - GR recorder password does not synchronise with X-series
				m_pLocalDetails->setAddress(m_LocAddrV4.sin_addr.S_un.S_addr);
				//start the multicast socket
				if (bFound) {
					bool bRet = m_MultiSock.Create();
					if (bRet) {
						m_pMultiDataBuf = NULL;
						m_ulMultiBufLen = 0;
						//start listening on the multicast address (and it's read thread)
						bRet = m_MultiSock.Accept(m_usUdpPort, m_LocAddrV4.sin_addr.S_un.S_addr);
						if (bRet) {
							//put all the multicast events in place
							m_Events[MULTICAST_RECV_DATA] = m_MultiSock.GetEventHandle();
							m_Events[MULTICAST_CLOSE] = m_MultiSock.GetCloseEventHandle();
							//create the server listening socket
							bRet = m_ListenSock.Create();
							if (bRet) {
								//start the listening thread
								bRet = m_ListenSock.Accept(m_usTcpPort, m_iMAX_CONNECTION_BACKLOG);
								if (bRet) {
									//setup all the RCP events
									m_hListenBackOffEv = m_ListenSock.GetBackoffEvHandle();
									m_Events[TCP_ACCEPT_CONN] = m_ListenSock.GetAcceptEvHandle();
									//m_Events[TCP_ACCEPT_CONN] = CreateEvent(NULL,FALSE,FALSE,L"P2PTCPAddConn");
									m_Events[TCP_ACCEPT_CLOSE] = m_ListenSock.GetCloseEvHandle();
									m_hAcceptedEv = m_ListenSock.GetAcceptedEvHandle();
									m_Events[P2P_SHUTDOWN] = CreateEvent(NULL, TRUE, FALSE, _T("P2PShutdown"));
									m_Events[TCP_CONN_CLOSE] = CreateEvent(NULL, FALSE, FALSE, _T("TCPConnClose"));
									m_Events[TCP_SERV_FAIL] = CreateEvent(NULL, FALSE, FALSE, _T("TCPServFail"));
									m_Events[ADD_OUT_CONN] = CreateEvent(NULL, FALSE, FALSE, _T("NewTcpConn"));
									m_hStateChangeEvent = CreateEvent(NULL, FALSE, FALSE, _T("P2PStateChangeEvent"));
									m_hArbitratorEvent = CreateEvent(NULL, FALSE, FALSE, _T("P2PArbitratorEvent"));
									m_ListenSock.SetFailedServEvent(m_Events[TCP_SERV_FAIL]);
									//start the wait thread
									m_hDispThread = CreateThread(NULL, 0, CP2PEngine::ListenThread, this, 0, NULL);
									//start the state machine thread
									m_hStateThread = CreateThread(NULL, 0, CP2PEngine::StateThread, this, 0, NULL);
									m_ListenSock.ResumeAcceptThread();
									m_MultiSock.StartAcceptThr();
									QString csTmp;
									for (int count = 0; count < NUM_EXT_MODULES; ++count) {
										csTmp = QString::asprintf(_T("P2PExtModule%d-notification"), count);
										m_haExtModules[count] = CreateEvent(NULL, FALSE, FALSE, csTmp);
#if defined ( TRACE_ALLOW )
										qDebug("Created event (%X) for external module (%d) called (%s).\n", m_haExtModules[count], count, csTmp );
#endif
									}
									char namBuf[50];
									int hostRet = gethostname(namBuf, 50);
									if (QAbstractSocket_ERROR == hostRet) {
										hostRet = WSAGetLastError();
										switch (hostRet) {
										case WSAEFAULT:
										case WSANOTINITIALISED:
										case WSAENETDOWN:
										case WSAEINPROGRESS:
										default:
											break;
										}
										namBuf[0] = NULL;
									} else {
										//TODO: copy buffer to localdetails (note to Al: what does this comment mean?)
									}
									m_bInitialised = TRUE;
#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TMPV5 ) ) && ( ! defined ( TRENDMANAGERPRO ) ) && (! defined (P2P_WRAPPER))
									//start off the Pass sync engine
									//check the password firmware option
									m_bEssEnabled = pSYSTEM_INFO->FWOptionPasswordCFRAvailable();
									if (pSYSTEM_INFO->FWOptionPasswordsSyncAvailable()) {
										CPassSyncEngine::GetHandle()->InitPassSyncEngine();
									}
#endif
								} else {
									Ret = P2P_INIT_TCP_LISTEN_FAILED;
									m_ListenSock.Disconnect();
									//close the multisock
									m_MultiSock.Shutdown();
								}
							} else {
								Ret = P2P_INIT_TCP_LISTEN_FAILED;
								//close the multisock
								int tmp = m_ListenSock.GetLastError();
								m_MultiSock.Shutdown();
							}
						} else {
							Ret = P2P_INIT_UDP_LISTEN_FAILED;
							//close the multisock
							m_MultiSock.Shutdown();
						}
					} else {
						Ret = P2P_INIT_UDP_LISTEN_FAILED;
					}
				} else {
					Ret = P2P_NETWORK_UNAVAILABLE;
				}
			} else {
				Ret = P2P_INIT_GET_ADDRINFO_FAILED;
			}
		}
	} else {
		Ret = P2P_INIT_INSTANCE_EXISTS;
	}
	if (P2P_INIT_OK != Ret && Ret != P2P_INIT_INSTANCE_EXISTS && m_hP2PInit != NULL) {
		//No need to close the mutex in Qt
		m_hP2PInit = NULL;
	}
	return Ret;
}
//****************************************************************************
/// Cleanup - frees any allocated memory and resources  
///
/// @param[in] 	  - None
///
/// @return only TRUE ATM
/// @TODO - return something useful
/// 
//****************************************************************************
BOOL CP2PEngine::CleanUp(void) {
#ifdef TRACE_ALLOW
qDebug("========================================Cleanup called\n");
#endif
	//stop the data processing thread
	SetEvent(m_Events[P2P_SHUTDOWN]);
	//test for the thread's exit code
	WaitForSingleObject(m_hDispThread, INFINITE);
	//DWORD dwExitCode = STILL_ACTIVE;
	//while(STILL_ACTIVE == dwExitCode)
	//{
	//	sleep(50);
	//	if(GetExitCodeThread(m_hDispThread,&dwExitCode))
	//	{
	//		DWORD dwErr;
	//		dwErr = GetLastError();
	//	}
	//}
	if (m_hDispThread) {
		//No need to close the mutex in Qt
		m_hDispThread = NULL;
	}
	SetStateEvent(SHUTTING_DOWN);
	WaitForSingleObject(m_hStateThread, 20000);
	//dwExitCode = STILL_ACTIVE;
	//while(STILL_ACTIVE == dwExitCode)
	//{
	//	sleep(50);
	//	if(GetExitCodeThread(m_hStateThread,&dwExitCode))
	//	{
	//		DWORD dwErr;
	//		dwErr = GetLastError();
	//	}
	//}
	if (m_hStateThread) {
		//No need to close the mutex in Qt
		m_hStateThread = NULL;
	}
	if (m_hArbThread) {
		WaitForSingleObject(m_hArbThread, INFINITE);
		//No need to close the mutex in Qt
		m_hArbThread = NULL;
	}
	//stop the accepting sockets
	m_ListenSock.Disconnect();
	m_MultiSock.Shutdown();
	//close any accepted conns
	T_ConnData *pconn;
	m_csConnList.lock();
	while (m_connList.GetNumEntries()) {
		pconn = m_connList.removeFirst();
		pconn->pCSock->Disconnect();
		delete pconn->pCSock;
		delete pconn;
	}
	m_csConnList.lock();
	T_MsgInfo *pInfo;
	m_csMsgList.lock();
	while (m_msgList.GetNumEntries()) {
		pInfo = m_msgList.removeFirst();
		delete[] pInfo->pData;
		delete pInfo;
	}
	m_csMsgList.lock();
	//pConn's should have all been deleted by above
	m_csMasterArbList.lock();
	if (!m_MasterArbList.isEmpty())
		m_MasterArbList.ClearData();
	m_csMasterArbList.lock();
#ifdef TRACE_ALLOW
	qDebug("================================================Peer Lists being cleared\n");
#endif
	ClearPeerList();
	ClearBackupPeerList();
	m_csArbList.lock();
	if (m_ArbitratedList.GetNumEntries())
		m_ArbitratedList.ClearData();
	m_csArbList.lock();
#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TMPV5 ) ) && ( ! defined ( TRENDMANAGERPRO ) ) && (! defined (P2P_WRAPPER))
	CPassSyncEngine::GetHandle()->ShutDownEngine();
#endif
	for (int numMod = 0; numMod < NUM_EXT_MODULES; ++numMod) {
		EnterCriticalSection(&m_csExtModDataList[numMod]);
		while (!m_ExtModuleDataList[numMod].isEmpty()) {
			delete[] m_ExtModuleDataList[numMod].removeFirst()->pMsg;
		}
		//PSR - Coverity issue fix --Program Hangs
		LeaveCriticalSection(&m_csExtModDataList[numMod]);
	}
	WSACleanup();
	if (m_hP2PInit != NULL) {
		//No need to close the mutex in Qt
		m_hP2PInit = NULL;
	}
	int count;
	for (count = 0; count < NUM_EXT_MODULES; ++count) {
		if (m_haExtModules[count]) {
			CloseHandle(m_haExtModules[count]);
			m_haExtModules[count] = NULL;
		}
	}
	for (count = P2P_SHUTDOWN; count < NUM_EVENTS; ++count) {
		if (m_Events[count]) {
			CloseHandle(m_Events[count]);
			m_Events[count] = NULL;
		}
	}
	if (m_hStateChangeEvent) {
		//No need to close the mutex in Qt
		m_hStateChangeEvent = NULL;
	}
	if (m_hArbitratorEvent) {
		//No need to close the mutex in Qt
		m_hArbitratorEvent = NULL;
	}
	delete m_pInstance;
	m_pInstance = NULL;
	return ( TRUE);
}
//****************************************************************************
/// ListenThread - handles events generated by the sockets  
///
/// @param[in] 	LPVOID pParam - pointer to calling CP2PEngine Instance
///
/// @return - 0
///
/// @TODO handle error conditions in V6 friendly manner
/// 
//****************************************************************************
DWORD WINAPI CP2PEngine::ListenThread(LPVOID pParam) {
	qDebug(_T("ListenThread:Start"));
	CP2PEngine *parent = (CP2PEngine*) pParam;
	BOOL run = TRUE;
	DWORD dwRet;
#ifdef TRACE_ALLOW
	qDebug("+++++Started listening thread\n");
#endif
	//DebugMsg(_T("P2P:ListenThread(): 1\n"));
#ifdef DBG_FILE_LOG_P2P_X_ENABLE
	QString  strLog;
	strLog = QString::asprintf(_T("CP2PEngine::ListenThread(): 1 GTC - %d\r\n"),GetTickCount());
	CPassSyncEngine::m_debugFileLogger.WriteToDebugLogFile(strLog);
#endif	
	// Initialise the random number generator based on the serial number which should always be unique -
	// this is required for the P2P engine when responding to broadcast messages so as to reduce the liklihood
	// of a collision
#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TMPV5 ) && ! defined ( TTR6SETUP ) ) && ( ! defined ( TRENDMANAGERPRO ) ) && (! defined (P2P_WRAPPER))
	srand( pSYSTEM_INFO->GetSerialNumber());
#endif
#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TMPV5 ) && ! defined ( TTR6SETUP ) ) &&( !defined(P2P_XSERIES) ) && (! defined (P2P_WRAPPER))
	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//for P2PEngine listen thread
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	if (pThreadInfo != NULL) {
		//Notify the WatchdogTimer that the P2PEngine thread has 
		//started
		//DebugMsg(_T("P2P:ListenThread(): 2\n"));
		pThreadInfo->UpdateThreadInfo(AM_P2PENGINE_LISTEN_THREAD, true);
		pThreadInfo->UpdateThreadCounter(AM_P2PENGINE_LISTEN_THREAD);
	}
#endif
	while (run) {
		//wait for the list of events generated by the sockets
		static const DWORD dwTIMEOUT_FOR_WFMO = 30000;
#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TMPV5 ) && ! defined ( TTR6SETUP ) ) && ( !defined(P2P_XSERIES) ) && (! defined (P2P_WRAPPER))
		if (pThreadInfo != NULL) {
			//Notify the WatchdogTimer that the thread should be ignored
			//until it waits for multiple objects
			pThreadInfo->UpdateThreadInfo(AM_P2PENGINE_LISTEN_THREAD, false);
		}
#endif
		//DebugMsg(_T("ListenThread(): before WaitForMultipleObjects()\n"));
		dwRet = WaitForMultipleObjects(parent->m_iEventCount, parent->m_pEvents, FALSE, dwTIMEOUT_FOR_WFMO);
#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TMPV5 ) && ! defined ( TTR6SETUP ) ) && ( !defined(P2P_XSERIES) ) && (! defined (P2P_WRAPPER))
		if (pThreadInfo != NULL) {
			//Notify the WatchdogTimer that the thread should be considered
			//as the waits for multiple objects is over
			//DebugMsg(_T("ListenThread(): before UpdateThreadInfo()\n"));
			pThreadInfo->UpdateThreadInfo(AM_P2PENGINE_LISTEN_THREAD, true);
		}
#endif
		if ( WAIT_TIMEOUT == dwRet) {
			// CR2988. When this is the only device around, there will never 
			// be a reply to its own discover peer broadcast. In such a case we
			// need to be sure that we don't get stuck in the initial discovery
			// state, and so we have a timeout and indicate end of arbitration 
			// if there has been no event signalled before the timeout expired
			// and we have not yet come to a satisfactory resolution. Our 
			// state machine will drop into STATE_MAIN_PEER as a consequence 
			// and any query of P2P status will indicate RESOLVE_COMPLETE.
			T_RESOLVE_STATES resState = parent->GetListStatus();
			if ((RESOLVE_COMPLETE != resState) && (RESOLVE_RESCAN != resState)) {
				QString cstrMsg;
				cstrMsg = QString::asprintf(_T("P2P:No activity for %d seconds, assuming this device is an orphan"),
						dwTIMEOUT_FOR_WFMO / 1000);
				LOG_P2P_MESSAGE(MSGLISTSER_P2P_INFO, cstrMsg);
				parent->SetStateEvent(END_OF_ARBITRATION);
			}
		} else if (WAIT_FAILED == dwRet) {
			//arse! 
			//TODO handle this outcome properly
			//handle may have been closed while waiting on it
			DWORD dwErr = GetLastError();
			QString csErr;
			csErr = QString::asprintf(_T("P2P:Wait for multiple objects failed - err: %d"), dwErr);
			QMessageBox(csErr, MB_ICONEXCLAMATION | MB_OK);
			run = FALSE;
		} else if (dwRet < WAIT_OBJECT_0 + NUM_EVENTS) {
			switch (dwRet - WAIT_OBJECT_0) {
			case P2P_SHUTDOWN:
				run = FALSE;
				break;
			case MULTICAST_RECV_DATA:
				//process inbound multicast data
				LOG_P2P_MESSAGE(MSGLISTSER_P2P_INFO, _T("Received Broadcast Packet"));
				parent->ProcessMulticastData();
				break;
			case MULTICAST_CLOSE:
				//close handles and re-start server
				if (parent->m_pEvents[MULTICAST_CLOSE]) {
					CloseHandle(parent->m_pEvents[MULTICAST_CLOSE]);
					parent->m_pEvents[MULTICAST_CLOSE] = NULL;
				}
				if (parent->m_pEvents[MULTICAST_RECV_DATA]) {
					CloseHandle(parent->m_pEvents[MULTICAST_RECV_DATA]);
					parent->m_pEvents[MULTICAST_RECV_DATA] = NULL;
				}
				if (parent->m_MultiSock.Accept(parent->m_usUdpPort, parent->m_LocAddrV4.sin_addr.S_un.S_addr)) {
					parent->m_Events[MULTICAST_RECV_DATA] = parent->m_MultiSock.GetEventHandle();
					parent->m_Events[MULTICAST_CLOSE] = parent->m_MultiSock.GetCloseEventHandle();
				}
				break;
			case TCP_ACCEPT_CONN:
#ifdef DBG_FILE_LOG_P2P_X_ENABLE
	strLog = QString::asprintf(_T("CP2PEngine::ListenThread(): handle new inbound TCP connections GTC - %d\r\n"),GetTickCount());
	CPassSyncEngine::m_debugFileLogger.WriteToDebugLogFile(strLog);
#endif	
				//handle new inbound TCP connections
				parent->ProcessNewConn();
#ifdef TRACE_ALLOW
				qDebug("New Conn added : count %d\n",parent->m_iEventCount);
#endif
				break;
			case TCP_ACCEPT_CLOSE:
				break;
			case TCP_CONN_CLOSE:
#ifdef DBG_FILE_LOG_P2P_X_ENABLE
	strLog = QString::asprintf(_T("CP2PEngine::ListenThread(): find any disconnected sockets and remove from list GTC - %d\r\n"),GetTickCount());
	CPassSyncEngine::m_debugFileLogger.WriteToDebugLogFile(strLog);
#endif
				//find any disconnected sockets and remove from list
				parent->PurgeConnList();
				break;
			case ADD_OUT_CONN:
#ifdef DBG_FILE_LOG_P2P_X_ENABLE
	strLog = QString::asprintf(_T("CP2PEngine::ListenThread(): find new conns and add to the list GTC - %d\r\n"),GetTickCount());
	CPassSyncEngine::m_debugFileLogger.WriteToDebugLogFile(strLog);
#endif
				//find new conns and add to the list
				parent->AddNewConnEvents();
				break;
			case TCP_SERV_FAIL: {
#ifdef DBG_FILE_LOG_P2P_X_ENABLE
	strLog = QString::asprintf(_T("CP2PEngine::ListenThread():if TCP server fail have to re-start the server GTC - %d\r\n"),GetTickCount());
	CPassSyncEngine::m_debugFileLogger.WriteToDebugLogFile(strLog);
#endif
				//have to re-start the server
				bool bRet = parent->m_ListenSock.Create();
				if (bRet) {
					bRet = parent->m_ListenSock.Accept(parent->m_usTcpPort, 15);
					if (bRet) {
						//old handle will be closed so need a new one
						parent->m_hAcceptedEv = parent->m_ListenSock.GetAcceptedEvHandle();
						//start the accept thread
						parent->m_ListenSock.ResumeAcceptThread();
					}
				}
				break;
			}
			default:
				break;
			}
		} else //no timeout to catch
		{
#ifdef TRACE_ALLOW
			qDebug("Handle Recieved data event:%d handle: %X\n",dwRet, parent->m_pEvents[dwRet]);
#endif
			DebugMsg(_T("P2P:ListenThread(): before ProcessIncomingData\n"));
			T_PROC_DATA_RET Res = parent->ProcessIncomingData(dwRet - WAIT_OBJECT_0);
			switch (Res) {
			DebugMsg(_T("P2P:ListenThread(): PROC_RET_OK\n"));
		case PROC_RET_OK:
			break;
			//TODO: need to handle error conditions - but how?
		case PROC_RET_NO_RECV_HANDLE:
		case PROC_RET_NO_MEMORY:
		case PROC_RET_READ_FAILED:
		default:
			DebugMsg(_T("p2P:ListenThread(): default\n"));
#ifdef TRACE_ALLOW
				qDebug("Handle Recieved data event %d, handle: %X failed\n",dwRet,parent->m_pEvents[dwRet]);
#endif
			break;
			}
		}
#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TMPV5 ) && ! defined ( TTR6SETUP ) ) && ( !defined(P2P_XSERIES) ) && (! defined (P2P_WRAPPER))
		if (pThreadInfo != NULL) {
			//Update the Thread Counter for the P2PEngine
			//thread after each iteration
			pThreadInfo->UpdateThreadCounter(AM_P2PENGINE_LISTEN_THREAD);
		}
#endif
	}
#if ( ! defined ( COMMS_SERVER ) ) && ( ! defined ( TMPV5 ) && ! defined ( TTR6SETUP ) ) && ( !defined(P2P_XSERIES) )	&& (! defined (P2P_WRAPPER))
	if (pThreadInfo != NULL) {
		//Update the info that the P2PEngine listen thread is exiting
		//Hence this thread need not be considered to kick the 
		//watchdog
		pThreadInfo->UpdateThreadInfo(AM_P2PENGINE_LISTEN_THREAD, false);
	}
#endif
	//QMessageBox(_T("Thread Finished"),MB_OK);
	return 0;
}
//******
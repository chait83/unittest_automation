/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module:		Peer2Peer
/// @n Filename:	MulticastSocket.h
/// @n Description: Class declaration for CMulticastSocket.
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  6 Stability Project 1.3.1.1 7/2/2011 4:58:57 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  5 Stability Project 1.3.1.0 7/1/2011 4:27:48 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  4 V6 Firmware 1.3 7/13/2007 1:59:32 PM  Charles Boardman
//  CR2979: Adding ability of Peer Services to work with a preferred
//  network adapter connection, so that when it can be properly used by
//  the Locate X Series Device dialog.
//  3 V6 Firmware 1.2 6/19/2007 6:10:21 PM  Charles Boardman
//  Adding file header.
// $
//
// **************************************************************************
#if !defined(AFX_MULTICASTQAbstractSocket_H__00B43DE3_00FF_4B76_A724_E8C269769FB9__INCLUDED_)
#define AFX_MULTICASTQAbstractSocket_H__00B43DE3_00FF_4B76_A724_E8C269769FB9__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "CESocket.h"
#include "Defines.h"
class CMulticastSocket: public CCESocket {
public:
	bool Accept(USHORT localport, unsigned long addr);
	void SetWSAInit(bool set);
	HANDLE GetEventHandle();
	HANDLE GetCloseEventHandle() {
		return m_hCloseEvent;
	}
	;
	virtual bool OnReceive(char *buf, int len);
	virtual void OnReceive();
	virtual void OnClose(int closeEvent);
	bool Shutdown();
	bool Create();
	CMulticastSocket();
	CMulticastSocket(HWND parent);
	void SetParent(HWND parent);
	virtual ~CMulticastSocket();
	bool StartAcceptThr();
	// Allow broadcasts to be made from a preferred network adapter.
	bool UpdateBroadcastAddr(ULONG ulPreferredAddr = 0);
#ifdef TMS_DYNAMICLOADING
	///HTS - PCT fix begin
	QLibrary getIcmpLibray();
	///HTS - PCT fix end
#endif	
private:
	ip_mreq m_mReq;
	HWND m_hParent;
	HANDLE m_hEvent;
	HANDLE m_hCloseEvent;
#ifdef TMS_DYNAMICLOADING
	///HTS - PCT fix begin
	QLibrary m_hmICmp;
	///HTS - PCT fix end
#endif	
};
#endif // !defined(AFX_MULTICASTQAbstractSocket_H__00B43DE3_00FF_4B76_A724_E8C269769FB9__INCLUDED_)

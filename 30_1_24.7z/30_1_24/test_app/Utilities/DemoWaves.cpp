/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Utilities
/// @n Filename: Demo waves.h
/// @n Desc:	 Provide demonstration waves for simulating input
///					used in demo channels and in Maths block
///				 
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  12  Stability Project 1.7.1.3 7/2/2011 4:56:43 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  11  Stability Project 1.7.1.2 7/1/2011 4:38:14 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  10  Stability Project 1.7.1.1 3/17/2011 3:20:21 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  9 Stability Project 1.7.1.0 2/15/2011 3:02:55 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// ****************************************************************
#include "DemoWaves.h"
#include "SysTimer.h"
#include "math.h"
#include "V6globals.h"
#include "PPIOServiceManager.h"
#include "InputConditioning.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
float CDemoWave::m_preCalcSineTable[PRE_CALC_SINE_STEPS];
float CDemoWave::m_UIAnalogues[MAX_ANALOGUE_IN];
USHORT CDemoWave::m_UIDigitals[MAX_DIGITAL_CARDS];
BOOL CDemoWave::IsSharedDemoDataInitialised = FALSE;
const float WAVE_INPUT_ZERO = -1;
const float WAVE_INPUT_SPAN = +1;
const float DRIFT_AMOUNT_PERCENT = 2;			// Number of % to drift the value
#ifdef DEBUG
#define TEST_DEMO_WAVE	0
void TestDemoWave();
#endif
//=============================================================================
// CDemoWave Class
//=============================================================================
//****************************************************************************
/// CDemoWave Constructor
//****************************************************************************
CDemoWave::CDemoWave() :
#ifdef CAL_MODE
	m_NO_OF_SET_POINTS(6),
	m_SOAK_PERIOD_IN_SECONDS(25),
#else
		m_NO_OF_SET_POINTS(3), m_SOAK_PERIOD_IN_SECONDS(195),
#endif
		m_nextSetPoint(0), m_slotNo(0), m_boardChanNo(0) {
#ifdef CAL_MODE
	m_setPointsAsPercent[0] = 000.0f;
	m_setPointsAsPercent[1] = 100.0f;
	m_setPointsAsPercent[2] = 200.0f;
	m_setPointsAsPercent[3] = 300.0f;
	m_setPointsAsPercent[4] = 400.0f;
	m_setPointsAsPercent[5] = 500.0f;
#else
	m_setPointsAsPercent[0] = 100.0f;
	m_setPointsAsPercent[1] = 200.0f;
	m_setPointsAsPercent[2] = 300.0f;
#endif
	// Initialise the shared demo data for the demo waves (will only be done when very first object is constructed
	if (IsSharedDemoDataInitialised == FALSE) {
		CDemoWave::InitialiseSharedDemoWave();
	}
	ConfigureDemoWave(0, 0, 0, 0, 100, 0, DEMO_WAVE_SIN, 5, 10);
}
//****************************************************************************
/// Configure the demo wave
///
/// @param[in] - chanNumber, Zero based channel Number
/// @param[in] - slotNo, zero based slot Number
/// @param[in] - boardChanNo, zero based boarch channel Number
/// @param[in] - zero, Zero engineering value of the demo input.
/// @param[in] - span, Span engineering value of the demo input.
/// @param[in] - noise, %age of span to generate noise.
/// @param[in] - waveType, T_DEMOWAVE_TYPES of demo wave required
/// @param[in] - waveDuration, duration in seconds of one complete wave (Ignored for UI types)
/// @param[in] - sourceTickRate, source rate in ticks(1/100) per second that data will be requested (Ignored for UI types)
///
/// @return - nothing
///
//****************************************************************************
void CDemoWave::ConfigureDemoWave(int chanNumber, USHORT slotNo, USHORT boardChanNo, float zero, float span,
		float noise, T_DEMOWAVE_TYPES waveType, int waveDuration, int sourceTickRate) {
	// Setup conversion info to get the absolute span of the drift or noise required as a percentage
	m_conv.CalcFConvInfo(PERCENT_0, PERCENT_100, zero, span);
	// ALways convert drift factor
	m_driftLevel = static_cast<float>(fabs(m_conv.CalcSourceToDest(DRIFT_AMOUNT_PERCENT) - zero));
	m_driftFactor = m_driftLevel / RAND_MAX;
	// If noise is required find noise factor
	if (noise >= PERCENT_0 && noise < PERCENT_100) {
		m_noiseLevel = static_cast<float>(fabs(m_conv.CalcSourceToDest(noise) - zero));	// noiselevel is absolute span
		m_noiseFactor = m_noiseLevel / RAND_MAX;
	} else {
		m_noiseLevel = 0;	// Do not add any noise
		m_noiseFactor = 0;
	}
	m_isTUSMode = (pSYSTEM_INFO->FWOptionTUSModeAvailable() == TRUE) && CAMS2750TUSMgr::Instance()->IsInDemoMode();
	// Setup conversion info structure to work on wave range and convert to engineering span
	m_conv.CalcFConvInfo(WAVE_INPUT_ZERO, WAVE_INPUT_SPAN, zero, span);
	m_waveType = waveType;															// record wave type
	m_zero = zero;																	// Record the engineering Zero
	m_span = span;																	// Record the engineering span
	m_ticksPerCycle = waveDuration * (PROCESS_TICKS_PER_SECOND / sourceTickRate);// Calculate the number of tivck for the duration of the wave
	m_directChange = m_ticksPerCycle;										// Number of ticks before a direction change
	m_currentVal = 0;																// Reset the current value
	m_chanNumber = chanNumber;														// Record the channel number
	m_currentTickCount = 0;															// Reset the current tick count
	CSlotMap *pkSlotMap = CSlotMap::GetHandle();
	m_slotNo = slotNo;
	m_boardChanNo = boardChanNo;
	// Perform any wave type specific configuration here.
	switch (waveType) {
	case DEMO_WAVE_SIN:						// Sine wave	
	{
		m_increment = static_cast<float>(PRE_CALC_SINE_STEPS) / m_ticksPerCycle;// proportion of indexes to move through
		m_currentVal = 0;				// currentVal used as index into sine table
		break;
	}
	case DEMO_WAVE_SQUARE:					// Square wave
	{
		m_currentVal = 0;				// CurrentVal used as timer for changing wave
		m_directChange = m_ticksPerCycle / 2;				// Change direction halfway through cycle
		break;
	}
	case DEMO_WAVE_RAMP_UP:					// Ramp up sawtooth
	case DEMO_WAVE_RAMP_DOWN:				// Ramp Down sawtooth
	{
		m_increment = m_conv.GetDestSpan() / m_ticksPerCycle;	// Cover span in one complete cycle
		if (m_isTUSMode) {
			// check the weave duration is greater than required for the TUS (assumes 60 seconds soak plus 10 seconds
			// ramping between each)
			/*int minTusDurationInSeconds = (66 * m_NO_OF_SET_POINTS);
			 bool meetsMinWaveDurationForTus = waveDuration > minTusDurationInSeconds;
			 
			 if (!meetsMinWaveDurationForTus)
			 {
			 Trace("ERROR - Minimum TUS duration not met for the TUS for channel no. %d, needs to be %d", chanNumber, minTusDurationInSeconds);
			 }*/
			// we want to wait for 70 seconds, as the soak is 60 seconds in demo mode and we might need a few seconds for it
			// to stabilise
			m_soakWaitPeriodCountInTicks = m_SOAK_PERIOD_IN_SECONDS * (PROCESS_TICKS_PER_SECOND / sourceTickRate);
			m_currentSoakEndWaitCountInTick = -1;
			m_nextSetPoint = 0;
			//m_NO_OF_SET_POINTS
			// extend the duration of the wave by the number of setpoints and soak period
			int oldTicksPerCycle = m_ticksPerCycle;
			m_ticksPerCycle += m_NO_OF_SET_POINTS * m_soakWaitPeriodCountInTicks;
			m_directChange = m_ticksPerCycle;
			Trace("Chan %u inc: %f, z: %f, s: %f, old tick: %d, new tick: %d", m_chanNumber, m_increment, m_zero,
					m_span, oldTicksPerCycle, m_ticksPerCycle);
		}
		break;
	}
	case DEMO_WAVE_RAMP_UP_DOWN:			// Ramp up and down (triangle)
	{
		m_increment = m_conv.GetDestSpan() / (m_ticksPerCycle / 2);	// Cover two spans in one complete cycle
		m_directChange = m_ticksPerCycle / 2;	// Change direction halfway through cycle
		break;
	}
	case DEMO_WAVE_UI_AI:					// Take from user input selection for analogues
	{
		if (m_chanNumber >= MAX_ANALOGUE_IN) {
			m_chanNumber = 0;
		}
		break;
	}
	case DEMO_WAVE_UI_DI:					// Take from user input selection for digitals
	{
		if (m_chanNumber >= MAX_DIGITAL_CARDS) {
			m_chanNumber = 0;
		}
		break;
	}
	case DEMO_WAVE_DRIFT:					// Randon drift
	{
		m_currentVal = zero + (m_conv.GetDestSpan() / 2);	// Set level to start mid range
		break;
	}
	case DEMO_WAVE_DIGITAL:					// Digital Input simulation (randon)
	{
		m_increment = static_cast<float>(m_ticksPerCycle + 1);// Only change digital values every cycle, force an initial value
		m_noiseLevel = 0;					// Don't want noise on digital
		break;
	}
	case DEMO_WAVE_PULSE:					// Pulse input simulation (randon)				
	case DEMO_WAVE_NONE:					// No wave type
		break;
	default:
		qDebug("Unknown Demo wave Type");
		break;
	}
}
//****************************************************************************
/// Configure the demo wave
///
///
/// @return - engineering value in 
///
//****************************************************************************
float CDemoWave::GetDemoValue() {
	float retVal = 0;
	// Perform any wave type specific configuration here.
	switch (m_waveType) {
	case DEMO_WAVE_SIN:						// Sine wave	
	{
		retVal = CalcSineWave();
		break;
	}
	case DEMO_WAVE_RAMP_UP_DOWN:			// Ramp up and down (triangle)
	case DEMO_WAVE_RAMP_UP:					// Ramp up sawtooth
	{
		retVal = m_zero + CalcRamp();
		break;
	}
	case DEMO_WAVE_RAMP_DOWN:				// Ramp Down sawtooth
	{
		retVal = m_span - CalcRamp();
		break;
	}
	case DEMO_WAVE_SQUARE:					// Square wave
	{
		retVal = CalcSquare();
		break;
	}
	case DEMO_WAVE_UI_AI:					// Take from user input selection for analogues
	{
		retVal = m_UIAnalogues[m_chanNumber];
		break;
	}
	case DEMO_WAVE_UI_DI:					// Take from user input selection for digitals
	{
		retVal = 0;
		break;
	}
	case DEMO_WAVE_DRIFT:					// Randon drift
	{
		retVal = CalcDrift();
		break;
	}
	case DEMO_WAVE_PULSE:					// Pulse input simulation (randon)	
	{
		retVal = static_cast<float>(rand());
		break;
	}
	case DEMO_WAVE_DIGITAL:					// Digital Input simulation (randon)	
	{
		if (m_increment++ > m_ticksPerCycle) {
			m_currentVal = static_cast<float>(rand());
			m_increment = 0;
		}
		break;
	}
	case DEMO_WAVE_NONE:					// No demo wave
		break;
	default:
		qDebug("Unknown Demo wave Type");
		break;
	}
	// Add the noise level to any waves if set.
	if (m_noiseLevel > 0) {
		retVal += CalcNoiseLevel();
	}
	return retVal;
}
//****************************************************************************
/// Calculate Sine wave
///
/// @return - level in engineering units
//****************************************************************************
float CDemoWave::CalcSineWave() {
	float sineVal;
	// Get value from lookup table
	sineVal = m_preCalcSineTable[static_cast<ULONG>(floor(m_currentVal))];
	// Convert to engineering units
	sineVal = m_conv.CalcSourceToDest(sineVal);
	// Increments to move to next position in table
	m_currentVal += m_increment;
	if (m_currentVal >= PRE_CALC_SINE_STEPS) {
		m_currentVal -= PRE_CALC_SINE_STEPS;
	}
	return sineVal;
}
//****************************************************************************
/// Calculate Ramp
///
/// @return - level in engineering units
//****************************************************************************
float CDemoWave::CalcRamp() {
	m_currentTickCount++;
	if (m_currentTickCount > m_directChange) {
		// Are we in second phase or at end of cycle?
		if (m_currentTickCount < m_ticksPerCycle) {
			// In second phase so must be and up/down so ramp down
			m_currentVal -= m_increment;
		} else {
			// We have reached then end of the wave, reset the values
			m_currentTickCount = 0;
			m_currentVal = 0;
			if (m_isTUSMode && (m_waveType == DEMO_WAVE_RAMP_UP)) {
				m_currentSoakEndWaitCountInTick = -1;
				m_nextSetPoint = 0;
			}
		}
	} else {
		// check if TUS mode and a ramp
		if (m_isTUSMode && (m_waveType == DEMO_WAVE_RAMP_UP)) {
			if (m_currentSoakEndWaitCountInTick != -1) {
				// check if the current soak period has ended
				if (m_currentSoakEndWaitCountInTick < m_currentTickCount) {
#ifdef CAL_MODE
					Trace("Chan %u ended soak for set point %d", m_chanNumber, m_nextSetPoint);
#endif
					// reset the m_currentSoakEndWaitCountInTick so we end the soak period
					// and start ramping again
					m_currentSoakEndWaitCountInTick = -1;
					m_nextSetPoint++;
				} else {
					// the current soak period has not ended so do nothing (i.e. the current value remains the same)
				}
			} else {
				// check if reached another setpoint
				if (m_nextSetPoint < m_NO_OF_SET_POINTS) {
					// test using the adjusted value but don't store it
					float inputAdjustedReading;
					// apply the input adjustment compensation
					CPPIOServiceManager *pServiceManagerObj = CPPIOServiceManager::GetHandle();
					CInputConditioning *pICService = pServiceManagerObj->GetICService();
					pICService->PerformOutputAdjust(m_currentVal, m_slotNo, m_boardChanNo, &inputAdjustedReading);
					//if (inputAdjustedReading >= m_setPointsAsPercent[m_nextSetPoint] + ((m_chanNumber % 2) * 0.1))#
					if (m_currentVal >= m_setPointsAsPercent[m_nextSetPoint]) {
						// roger look at the increment value as it's always 1.5 which is a bit big
						// we've just reached another set point - set the tick count at which we will leave this soak
						m_currentSoakEndWaitCountInTick = (int) (m_currentTickCount + m_soakWaitPeriodCountInTicks);
#ifdef CAL_MODE
						Trace("Chan %u reached set point %d (cv: %.02f, civ: %.02f), current tick %f, waiting until %d", m_chanNumber, m_nextSetPoint, m_currentVal, inputAdjustedReading, m_currentTickCount, m_currentSoakEndWaitCountInTick);
#endif
						//return inputAdjustedReading;
					}
				}
				// we're not current in a wait period so increment the ramp up normally
				m_currentVal += m_increment;
			}
			float inputAdjustedReading;
			// apply the input adjustment compensation
			CPPIOServiceManager *pServiceManagerObj = CPPIOServiceManager::GetHandle();
			CInputConditioning *pICService = pServiceManagerObj->GetICService();
			pICService->PerformOutputAdjust(m_currentVal, m_slotNo, m_boardChanNo, &inputAdjustedReading);
			return inputAdjustedReading;
		} else {
			// Not TUS related
			// We are still in first phase, ramp up
			m_currentVal += m_increment;
		}
	}
	return m_currentVal;
}
//****************************************************************************
/// Calculate Square wave
///
/// @return - level in engineering units
//****************************************************************************
float CDemoWave::CalcSquare() {
	float retVal = m_zero;
	m_currentTickCount++;
	if (m_currentTickCount > m_directChange) {
		// Are we in second phase or at end of cycle?
		if (m_currentTickCount < m_ticksPerCycle) {
			// In second phase so must return the span instaed of the zero
			retVal = m_span;
		} else {
			// We have reached then end of the wave, reset the values
			m_currentTickCount = 0;
		}
	}
	return retVal;
}
//****************************************************************************
/// Calculate drift on a signal
///
/// @return - noise level in engineering units + or - to be added to current level
//****************************************************************************
float CDemoWave::CalcDrift() {
	float driftVal;
	// Calculate the drift value and centre it for a + or - value
	driftVal = (m_driftFactor * rand()) - (m_driftLevel / 2);
	// Add drift onto current value
	m_currentVal += driftVal;
	// Has current value has exceeded zero or span considering scale direction?
	if ((m_conv.DestScaleReversed() == TRUE && (m_currentVal > m_zero || m_currentVal < m_span))
			|| (m_conv.DestScaleReversed() == FALSE && (m_currentVal < m_zero || m_currentVal > m_span))) {
		// Yes, remove double the drift.
		m_currentVal -= (driftVal * 2);
	}
	return m_currentVal;
}
//****************************************************************************
/// Calculate additional noise level
///
/// @return - noise level in engineering units + or - to be added to current level
//****************************************************************************
float CDemoWave::CalcNoiseLevel() {
	float noiseVal;
	noiseVal = m_noiseFactor * rand();	// Calculate a random noise level
	noiseVal -= (m_noiseLevel / 2);		// Adjust the noise levelto a + and - value
	return noiseVal;
}
//****************************************************************************
/// Initialise a prebuilt sine wave shared over all object instances
/// also pre set the analogue inputs
///
/// @return - nothing
//****************************************************************************
void CDemoWave::InitialiseSharedDemoWave() {
	// Generate the pre-calculated sine wave
	float sineWaveSteps = (DEMO_PI * 2) / PRE_CALC_SINE_STEPS;
	float sineWave = 0;
	for (int sineIndex = 0; sineIndex < PRE_CALC_SINE_STEPS; sineIndex++) {
		m_preCalcSineTable[sineIndex] = static_cast<float>(sin(sineWave));
		sineWave += sineWaveSteps;
		//qDebug("Sine %f \n", (m_preCalcSineTable[sineIndex]*50)+50 );
	}
	int UIdemoCount;
	// Initialise all the demo analogue inputs that can be set via user interface
	for (UIdemoCount = 0; UIdemoCount < MAX_ANALOGUE_IN; UIdemoCount++) {
		m_UIAnalogues[UIdemoCount] = static_cast<float>(UIdemoCount + 1);// Set the default AI values to the Ai channel
	}
	// Initialise all the demo digital input that can be set via user interface
	for (UIdemoCount = 0; UIdemoCount < MAX_DIGITAL_CARDS; UIdemoCount++) {
		m_UIDigitals[UIdemoCount] = 0;
	}
	// One time initialisation completed.
	IsSharedDemoDataInitialised = TRUE;
}
//****************************************************************************
/// Set the demo analogue input from a user level
///
/// @param[in] - analogueNumber, Zero based analogue Input number 0 to MAX_ANALOGUE_IN
/// @param[in] - analogueValue, engineering value to set analogue value with
///
/// @return - nothing
//****************************************************************************
void CDemoWave::SetDemoAnalogue(int analogueNumber, float analogueValue) {
	if (analogueNumber < MAX_ANALOGUE_IN) {
		m_UIAnalogues[analogueNumber] = analogueValue;
	}
}
//****************************************************************************
/// Set the demo digital input card from a user level
///
/// @param[in] - digitalCardNumber, Zero based DIO card number 0 to MAX_DIGITAL_CARDS
/// @param[in] - digitalBitMask, 16 channel bitmask to set digital status
///
/// @return - nothing
//****************************************************************************
void CDemoWave::SetDemoDigitalCard(int digitalCardNumber, USHORT digitalBitMask) {
	if (digitalCardNumber < MAX_DIGITAL_CARDS) {
		m_UIDigitals[digitalCardNumber] = digitalBitMask;
	}
}
/// Test caddy for waves @todo AK remove once tests complete
#if TEST_DEMO_WAVE
void TestDemoWave()
{
	CDemoWave dem;
//	dem.ConfigureDemoWave( 1, 10, 40, 0, DEMO_WAVE_NONE, 10, 10 );						// tested ok
//	dem.ConfigureDemoWave( 1, 10, 40, 0, DEMO_WAVE_SIN, 10, 10 );						// tested ok
//	dem.ConfigureDemoWave( 1, 10, 40, 0, DEMO_WAVE_RAMP_UP, 10, 10 );					// tested ok
//	dem.ConfigureDemoWave( 1, 10, 40, 0, DEMO_WAVE_RAMP_DOWN, 10, 10 );					// tested ok
//	dem.ConfigureDemoWave( 1, 10, 40, 0, DEMO_WAVE_RAMP_UP_DOWN, 10, 10 );				// tested ok
//	dem.ConfigureDemoWave( 1, 10, 40, 0, DEMO_WAVE_SQUARE, 10, 10 );					// tested ok
	dem.ConfigureDemoWave( 1, 10, 40, 10, DEMO_WAVE_SQUARE, 10, 10 );	// With noise	// tested ok
//	dem.ConfigureDemoWave( 1, 10, 40, 0, DEMO_WAVE_UI_AI, 10, 10 );
//	dem.ConfigureDemoWave( 1, 10, 40, 0, DEMO_WAVE_UI_DI, 10, 10 );
	float val;
	for( int i=0; i < 200; i++ )
	{
		val = dem.GetDemoValue();
		qDebug("Demo Val(%d) = %f \n", i, val );
	}
	// Nasty stop
//	for(;;)
//	{
//		sleep(5);
//	}
}
#endif // #ifdef TEST_DEMO_WAVE

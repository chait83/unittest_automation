/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  CERemoteDispToolSocket 
/// @n Filename:  CERemoteDispToolSocket.cpp
/// @n Description: This class is responsible for communication of recorder and
/// RDT
///
// **************************************************************************
// Revision History
//	#Nilesh: 1-Feb-2021 Created separate thread for RDT and Recorder communication.
// **************************************************************************
#include "CERemoteDispToolSocket.h"
#include "V6AppInterface.h"
#include "TopStatusBar.h"
#include "ThreadInfo.h"
#define MODEL_NO 01
#define SET_INFO 02
#define MODEL_TYPE 03
#define TRACE_ALLOW
IV6AppInterface *g_V6AppInterface = NULL;							 // V6AppInterface Pointer.
IV6TimeInterface *g_V6TimeInterface = NULL;
QString StrInvalid = _T("invalid");
//****************************************************************************
/// CERemoteDispToolSocket - Constructor
///
/// @param n/a
///
/// @return		n/a
///
//****************************************************************************
CERemoteDispToolSocket::CERemoteDispToolSocket() {
	m_rdtSocket = INVALID_SOCKET;
	m_rdtThread = NULL;
	m_rdtsocketState = NONE;
}							 //end CERemoteDispToolSocket()
//****************************************************************************
/// ~CERemoteDispToolSocket - Destructor
///
/// @param n/a
///
/// @return		n/a
///
//****************************************************************************
CERemoteDispToolSocket::~CERemoteDispToolSocket() {
}							 //end ~CERemoteDispToolSocket()
//****************************************************************************
/// OnAccept - Override to handle accept notifications
///
/// @param[in]	serviceSocket - QAbstractSocket to attach to new class instance
///
/// @return		false if new socket not handled by handler thread
///
//****************************************************************************
bool CERemoteDispToolSocket::OnAccept(QAbstractSocket serviceSocket) {
	bool ret = true;
	AcceptRdtSocket(serviceSocket);
	return ret;
}							 //end OnAccept()
//****************************************************************************
/// OnClose - handler override for socket close
///
/// @param[in] closeEvent - reason close has been called
///
/// @return		n/a
///
//****************************************************************************
void CERemoteDispToolSocket::OnClose(int closeEvent) {
	if (NULL != m_rdtThread) {
		//No need to close the mutex in Qt
		m_rdtThread = NULL;
	}
	m_rdtThreadState = CLOSED;
	if (m_rdtSocket != INVALID_SOCKET) {
		shutdown(m_rdtSocket, SD_BOTH);
		closesocket(m_rdtSocket);
		m_rdtSocket = INVALID_SOCKET;
	}
	m_rdtsocketState = NONE;
}							 //end OnClose()
//****************************************************************************
/// Disconnect - disconnect from remote host
///
/// @param n/a
///
/// @return		n/a
///
//****************************************************************************
void CERemoteDispToolSocket::Disconnect() {
	if (NULL != m_rdtThread) {
		//No need to close the mutex in Qt
		m_rdtThread = NULL;
	}
	m_rdtThreadState = CLOSED;
	if (m_rdtSocket != INVALID_SOCKET) {
		shutdown(m_rdtSocket, SD_BOTH);
		closesocket(m_rdtSocket);
		m_rdtSocket = INVALID_SOCKET;
	}
	m_rdtsocketState = NONE;
}							 //end Disconnect()
//****************************************************************************
/// OnReceive - Receives data from client
///
/// @param [in] buf  Data buffer read over the socket connection
/// @param [in] bytesRead Number of bytes read  
///
/// @return		bool - Returns true as this method is used
///
//****************************************************************************
bool CERemoteDispToolSocket::SendRDT() {
	bool retVal = false;
	int size = 0;
	char DataBuffer[512];
	try {
		//Get model Number of the Recorder
		QString Modelno("");
		Modelno = GetModelNumber();
		wcstombs(DataBuffer, Modelno.GetBuffer(Modelno.size()), Modelno.size() + 1);
		Send(DataBuffer, strlen(DataBuffer));
		sleep(10);
	} catch (...) {
		LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, _T("Exception: Could not send model number to RDT!"));
	}
	return retVal;
}							 //end OnReceive()
//****************************************************************************
/// GetModelNumber - Returns the Model Number
///
/// @return		QString  - Returns the model number of the recorder
///
//****************************************************************************
QString CERemoteDispToolSocket::GetModelNumber() {
	HRESULT hResult = S_OK;
	hResult = CoCreateInstance(CLSID_V6AppInterface, NULL, CLSCTX_INPROC_SERVER, IID_IV6AppInterface,
			(void**) &g_V6AppInterface);
	// Fails to Create the Instance.
	if (FAILED(hResult)) {
		QString szErr;
		if (CO_E_SERVER_EXEC_FAILURE == hResult) {
			szErr = "Failed to Connect with Recorder.- Firmware not running!";
		} else {
			szErr = "Failed to Connect with Recorder.";
		}
		MessageBox(NULL, szErr, L"Production Interface - Error", MB_OK | MB_TOPMOST);
		CoUninitialize();
		return StrInvalid;
	} else {
		if (g_V6AppInterface == NULL) {
			MessageBox(NULL, _T("Failed to Connect with Recorder."), L"Production Interface - Error",
			MB_OK | MB_TOPMOST);
			CoUninitialize();
			return StrInvalid;
		}
	}
	hResult = g_V6AppInterface->QueryInterface(IID_IV6TimeInterface, (void**) &g_V6TimeInterface);
	VARIANT vBstrModelNumber;
	VariantInit(&vBstrModelNumber);
	// Get the Model Number from the Recorder.
	hResult = g_V6AppInterface->GetModelNumber(&vBstrModelNumber);
	QString Modelno = vBstrModelNumber.bstrVal;
	return Modelno;
}							 //end GetModelNumber()
//****************************************************************************
/// Send - Sends the Model Number to the Production Interface tool
///
/// @param [in] buf - Holds the model number of the recorder
/// @return		 int - Returns number of bytes of data sent successfully
///
//****************************************************************************
int CERemoteDispToolSocket::Send(const char *buf, int len) {
	int dataPtr = 0;
	int sentBytes = 0;
	if (!m_bWSAStarted)
		return QAbstractSocket_ERROR;
	//Do we have a valid buffer?
	if (!buf || len <= 0) {
		m_errorCode = WSAEFAULT;
		return QAbstractSocket_ERROR;
	}
	sentBytes = send(m_rdtSocket, &buf[dataPtr], len, 0);
	if (sentBytes <= 0) {
		m_errorCode = WSAGetLastError();
		return QAbstractSocket_ERROR;
	}
	dataPtr += sentBytes;
	len -= sentBytes;
	return dataPtr;
}							 //end Send()
void CERemoteDispToolSocket::AcceptRdtSocket(QAbstractSocket serviceSocket) {
	if (NULL == m_rdtThread) {
		m_rdtSocket = serviceSocket;
		m_rdtsocketState = CONNECTED;
		m_rdtThread = CreateThread(NULL, 0, StartRdtThread, this, 0, NULL);
	} else {
		Disconnect();
	}
}
DWORD WINAPI CERemoteDispToolSocket::StartRdtThread(LPVOID pParam) {
	CERemoteDispToolSocket *parent = (CERemoteDispToolSocket*) pParam;
	parent->RdtThread();
	return 0;
}
void CERemoteDispToolSocket::RdtThread() {
	SendRDT();	//Sending model number to RDT
	if (NULL != m_rdtThread) {
		//No need to close the mutex in Qt
		m_rdtThread = NULL;
	}
	m_rdtThreadState = CLOSED;
	if (m_rdtSocket != INVALID_SOCKET) {
		shutdown(m_rdtSocket, SD_BOTH);
		closesocket(m_rdtSocket);
		m_rdtSocket = INVALID_SOCKET;
	}
	m_rdtsocketState = NONE;
}

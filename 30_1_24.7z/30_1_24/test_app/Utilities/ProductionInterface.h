/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  CProductionInterface 
/// @n Filename:  CProductionInterface.h
/// @n Description: Sets the of Production Information
///
// **************************************************************************
// Revision History
// **************************************************************************
#include "CEProductionSocket.h"
class CProductionInterface {
public:
	CProductionInterface();
	~CProductionInterface();
	bool ProductionInterfaceFunc();
};

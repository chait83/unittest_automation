#ifndef __ACTIVITYLOG_H_INCLUDED__
#define __ACTIVITYLOG_H_INCLUDED__
#include "CStorage.h"
#include <QMutex>
#define ACTIVITY_LOG
//**Class*********************************************************************
///
/// @brief 
/// 
///
//****************************************************************************
class CActivityLog {
public: // methods
	static CActivityLog* GetHandle();
	BOOL CleanUp();
	void Initialise();
	void OpenInternalLog(QString Name);
	void OpenExternalLog(QString Name);
	void CloseInternalLog();
	void CloseExternalLog();
	void LogInternalMessage(char *Message);
	void LogExternalMessage(char *Message);
	void CopyInternalLog(QString Source, QString Target);
	void DeleteInternalLog(QString Name);
public: // data
private: // methods
	CActivityLog();
	~CActivityLog();
private: // data
	static CActivityLog *pInstance;				///< Single instance object pointer
	static QMutex hCreationMutex;				///< Object creation mutex
protected: // data
	BOOL m_Initialised;
	static QMutex m_hCritical;
	CStorage m_InternalLog;
	BOOL m_InternalLogIsOpen;
	CStorage m_ExternalLog;
	BOOL m_ExternalLogIsOpen;
};
#endif // __ACTIVITYLOG_H_INCLUDED__

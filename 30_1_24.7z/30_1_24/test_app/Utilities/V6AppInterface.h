/// @file 
/// **************************************************************************
///  Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  V6AppInterface 
/// @n Filename:  V6AppInterface.h
/// @n Description: Declaration of the CV6AppInterface
///
//  **************************************************************************
//  Revision History
//  **************************************************************************
//  $Log[4]:
// 28  Stability Project 1.25.1.1   7/2/2011 5:02:37 PM   Hemant(HAIL) 
//    Stability Project: Recorder source has been upgraded from IL
//    version of firmware to JF version of firmware.
// 27  Stability Project 1.25.1.0   7/1/2011 4:28:17 PM   Hemant(HAIL) 
//    Stability Project: Files has been checked in before the merging
//    task. The merging will be done between IL version of firmware and JF
//    version of firmware. 
// 26  V6 Firmware 1.25   7/21/2010 4:56:24 PM  Karnav(HAIL) 
//    Modificaitons for 3137
// 25  V6 Firmware 1.24   6/10/2010 12:12:30 PM Binsy Pillai 
//    added comment
//  $
//
///***************************************************************************
#ifndef __V6APPINTERFACE_H_
#define __V6APPINTERFACE_H_
#include "PMMglobal.h"
#include "CMMDefines.h"
#include "V6globals.h"
#include "MessageListServicesItem.h"
#include "ConfigurationManager.h"
#include "PasswordInterfaceManager.h"
#include "CPasswordModule.h"
//#include "V6DesktopCP.h"
//****************************************************************************
/// Defines the Minimum Update Rate in Milliseconds as 100.
#define MIN_DI_UPDATE_RATE	100	  
#define MIN_MSG_SUB_RATE	500  /// Message Subscription Rate 
#define MIN_MSG_LIM			300  /// Message Limitations for Deque
//****************************************************************************
//****************************************************************************
/// enum DI_VALUES
/// 
/// Defines the index values for the Data Item Attributes.
///
//****************************************************************************
typedef enum {
	DI_FLOAT_VALUE = 0,					///< Data Item Float Value.
	DI_ENABLE,							///< Data Item Enable Property.
	DI_DATA_TYPE,         ///< Data Item Data Type.
	DI_RATE,							///< Data Item Rate.
	DI_SPAN,							///< Data Item Span value.
	DI_TIME,							///< Data Item Time Stamp.
	DI_STATUS,							///< Data Item Status.
	DI_ZERO,							///< Data Item Zero Value.
	DI_VAR_NAME,						///< Data Item Variable Name.
	DI_UNITS,         ///< Data Item Units
	DI_TAG,           ///< Data Item Tag Name
	DI_COLOR,         ///< Data Item Color
	DI_ALARM_STATUS,					///< Data Item Alarm Status
	DI_ALARM_TYPE,						///< Data Item Alarm Type		
	DI_REFERENCE,						///< Data Item Refernce
	DI_INSTANCE,						///< Data Item Instance
	DI_TYPE,          ///< Data Item Type
	DI_RECORDING_STATUS,				///< Data Item Recording Status
	DI_DESC,							///< Data Item Description
	DI_LOG_UNITS,						///< Log Unit only for of Type Pen
	DI_VAL_MAX,							///< Max Value
	DI_LOG_RATE,						///< Log Rate
	DI_LOG_TYPE							///< Log Type
} DI_VALUES;
//****************************************************************************
/// T_OPC_DETAILS 
/// 
/// Structure to fill the general information for the OPCServer.
///
//****************************************************************************
typedef struct _stOPCDetailsTemplate {
	BOOL bServerStatus;				///< Server Status Running or Not.
	USHORT usOPCDARecomConnections;	///< Recommended connections for OPCDAServer.
	USHORT usOPCAERecomConnections;	///< Recommended connections for OPCDAServer.
	USHORT usOPCDAClients;				///< Number of OPCDAClients Connected.
	USHORT usOPCAEClients;				///< Number of OPCAEClients Connected.
	USHORT usMinUpdateRateSupported;	///< Minimum Update Rate Supported for the OPCDAServer.
	USHORT usMaxGroupSupported;		///< Maximum Number of Groups Supported for the OPCDAServer.
	USHORT usMaxUniqueItemsSupported;	///< Maximum Number of Unique Items Supported for the OPCDAServer.
	USHORT usGroupsRequested;			///< Number of Groups Requested to OPCDAServer.
	USHORT usItemsRequested;			///< Number of Items Requested to OPCDAServer.
	USHORT usMaxActiveAlarmsSupported;	///< Number of Acive Alarms Supported in OPCA&EServer.
	USHORT usActiveAlarmsAvailable;	///< Number of Acive Alarms Available in OPCA&EServer.  
} T_OPC_DETAILS;
//****************************************************************************
/// @brief CRequestObject class
/// 
/// This class provides metods to stores the information for an Update Request.
///
//****************************************************************************
class CRequestObject {
public:
	// Class Constructor
	CRequestObject() {
		// OPCDAServer.
		m_hlThreadHdl = INVALID_HANDLE_VALUE;
		m_dwUpdateRate = MIN_DI_UPDATE_RATE;
		// OPCA&EServer
		QMutex * ms_csCriticalSection;
		QMutex * ms_csOPCGroupConfigStatus;
		ms_bInitialised = true;
		// OPC Server Info
		m_hOPCInfo = CreateEvent(NULL, FALSE, FALSE, NULL);
		m_hOPCInfoReqComplete = CreateEvent(NULL, FALSE, FALSE, NULL);
		QMutex * ms_csOPCServerInfo;
		QMutex * ms_csOPCServerADDREmoveInfo;
	}
	// Class Destructor
	~CRequestObject() {
		// OPCDAServer
		ms_csOPCServerADDREmoveInfo.lock();
		m_DIUpdateMap.clear();
		ms_csOPCServerADDREmoveInfo.lock();
		// OPCA&EServer
		ms_bInitialised = false;
		ms_csCriticalSection.lock();
		ms_dqMessageList.clear();
		ms_csCriticalSection.lock();
		//deletion of mutex not required;
		//deletion of mutex not required;
		// OPC Server Info
		m_bStopOPCInfoThread = false;
		SetEvent(m_hOPCInfo);
		if (m_hOPCInfo != INVALID_HANDLE_VALUE) {
			//No need to close the mutex in Qt;
			//No need to close the mutex in Qt;
			m_hOPCInfo = NULL;
			m_hOPCInfoReqComplete = NULL;
		}
		//deletion of mutex not required;
		//deletion of mutex not required;
	}
	// Member Variables - OPCDAServer
	DWORD m_dwUpdateRate;		/// Update Rate for the Call Back.
	HANDLE m_hlThreadHdl;		/// Thread Handle for Call Back.
	CTypedPtrMap<QMap, QString, CDataItem*> m_DIUpdateMap;	// Map from Data Item name to DataItem Pointer.	
	// Member Variables - OPCA&EServer
	static std::deque<T_MSGLISTSER_MESSAGE> ms_dqMessageList; /// The queue for the message
	static QMutex ms_csCriticalSection; 	/// System Timer Critical section
	static QMutex ms_csOPCGroupConfigStatus; 	/// Critical section for Group configuration Status.
	static bool ms_bInitialised; 	/// Flag used to identify if the critical section has been intialised
	static bool ms_bOPCGroupConfigStatus; /// Group configuration Status.
	// Member Functions -  OPCDAServer
	void AddRemoveDataItem(unsigned short nType, unsigned short nRef, unsigned short nInst, BOOL bAddData);
	BOOL IsDataItemAvailable(unsigned short nType, unsigned short nRef, unsigned short nInst);
	// Member Functions -  OPCA&EServer
	static void UpdateOPCPenConfig(USHORT usPenNumber);
	static void UpdateOPCGroupConfig();  // Called whenever there is any change in the Pen's Group Configuration.
	static void PushMsg(const T_MSGLISTSER_MESSAGE &rtMSG); // Push a message onto the queue
	const bool PopMsg(T_MSGLISTSER_MESSAGE &rtMsg); // Pop a message from the front of the queue		
	// OPC Server Info - Member Variables.
	static HANDLE m_hOPCInfo; // Event to notify to get the OPCInformation.
	static HANDLE m_hOPCInfoReqComplete; // Event to notify to get the OPCInformation.
	static bool m_bStopOPCInfoThread; // Variable to notify the Stop of Thread.	
	static T_OPC_DETAILS m_sOPCDetails; //Structure to fill the OPCServer Details.
	static QMutex ms_csOPCServerInfo; //Critical Section for the OPCServer Info.
	QMutex ms_csOPCServerADDREmoveInfo; //it must only be used inside object methods
	// OPC Server Info - Member functions.
	static void CallOPCServerForInfo();
	static T_OPC_DETAILS& GetOPCDetails();
};
//****************************************************************************
/// @brief CV6AppInterface class
/// 
/// This class provides implementation for IV6AppInterface, IV6DITInterface and
/// IV6App Interfaces
///
//****************************************************************************
class CV6AppInterface {
public:
	CV6AppInterface() {
		m_ReqObj = new CRequestObject;  // Create the CRequest Object.   
		m_hlMsgSubHdl = NULL; // Thread Handle for Message Callback.
		m_dwMessSubsRate = MIN_MSG_SUB_RATE; // Call Back rate for Message Call Back.				
		UpdateMsgs(); // Call to get the Messages and return to OPCA&E Server.
		// OPC Server Info Inialization.
		m_hlOPCServerInfo = INVALID_HANDLE_VALUE; // Thread Handle for the OPCServerInfo thread.
		StartOPCServerInfoThread(); // Create the Thread to get the OPCServer Info. 
	}
	~CV6AppInterface() {
		if (m_ReqObj != NULL) {
			delete (m_ReqObj);
		}
		if (m_hlOPCServerInfo != INVALID_HANDLE_VALUE) {
			//No need to close the mutex in Qt;
			m_hlOPCServerInfo = NULL;
		}
		if (m_hlMsgSubHdl != NULL) {
			//No need to close the mutex in Qt;
			m_hlMsgSubHdl = NULL;
		}
	}
private:
// IV6AppInterface
	HRESULT SetData(CDataItem *pDataItem, DWORD dwIndex, VARIANT vDataItemValues);
	HRESULT GetData(CDataItem *pDataItem, DWORD dwCount, VARIANT vIndexValues, VARIANT *pDataItemvalues);static UINT __cdecl UpdateThread(void *pThreadArg);
	UINT UpdateThreadFunc();
// IV6MessageListInterface
	HRESULT UpdateMsgs();
	void SendMessage(T_MSGLISTSER_MESSAGE rtMsg);static UINT __cdecl SendMsgs(void *pThreadArg);
	UINT SendMsgsFunc();
	HANDLE m_hlMsgSubHdl;		/// Thread Handle for Call Back.
	DWORD m_dwMessSubsRate;	/// Message Subscription Rate.
// IV6PMMInterface
	PasswordInterfaceManager CPasswordInterface;	// PMM CPWI wrapper class instanciated.
// OPCServerInfo
	HRESULT StartOPCServerInfoThread();static UINT __cdecl OPCInfoThread(void *pThreadArg);
	UINT OPCInfoThreadFunc();
	HANDLE m_hlOPCServerInfo;
// CV6AppInterface Data Members
public:
	CRequestObject *m_ReqObj;
};
#endif //__V6APPINTERFACE_H_

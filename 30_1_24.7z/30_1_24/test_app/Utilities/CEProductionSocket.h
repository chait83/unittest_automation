/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  CEProductionSocket 
/// @n Filename:  CEProductionSocket.h
/// @n Description: This class is responsible for communication of recorder and
/// Production Interface tool
///
// **************************************************************************
// Revision History
//	Swathi 07/23/2014 Fix for the par 1-3GM1NP1: Do not set the date when 
//					 requested for Recorder Model Number alone. This can
//				 be possible for Remote Display Tool
// Swathi 07/30/2014 Install Device Certificate when requested via Production Tool
// **************************************************************************
#include "CESocket.h"
#include "Defines.h"
#include <QString>
#include <QAbstractSocket>
class CEProductionSocket: public CCESocket {
public:
	CEProductionSocket();
	virtual ~CEProductionSocket();
	bool OnReceive(char *buf, int bytesRead);
	bool Accept(UINT localPort, int maxConn = SOMAXCONN);
	virtual bool OnAccept(QAbstractSocket serviceSocket);
	virtual void OnClose(int closeEvent);
	bool Create();
	void Disconnect();
	QString GetModelNumber(char *buf);
	bool SetDate(char *buf);
	bool SetProductionInfo(char *buf);
	int Send(const char *buf, int len);
	void InstallDeviceCertificate();
	int SendProductionInfo(const char *buf, int len);
	//!Starts the read thread for Production Interface Socket
	void AcceptProductionSocket(QAbstractSocket serviceSocket);
private:
	QAbstractSocket serviceSocket;
	socketState m_productionSocketState;
	char m_recvBuf[1024];
	QString GetModelNumber();
protected:
	threadState m_productionReadThreadState;
	HANDLE m_productionReadThread;
	QAbstractSocket m_productionSocket;
	void ReadProdInfoThread();
	static DWORD WINAPI StartProdInfoReadThread(LPVOID pParam);
};

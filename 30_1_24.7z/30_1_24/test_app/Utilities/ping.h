/**********************************************************************************
 
 COPYRIGHT (c) 2001
 HONEYWELL LTD.
 ALL RIGHTS RESERVED
 
 This software is a copyrighted work and/or information protected as a
 trade secret. Legal rights of Honeywell Ltd. in this software is distinct
 from ownership of any medium in which the software is embodied. Copyright
 or trade secret notices included must be reproduced in any copies
 authorised by Honeywell Ltd.
 
 /////////////////////////////////////////////////////////////////////////////
 /////////////////////////////////////////////////////////////////////////////
 
 Ping.h : Implementation of class CPing (Using WINSOCK2).
 
 Revision History:
 
 Date Author			  Comments
 ---------	-------		  -----------------------------------------
 26/07/2006	Amey				Initial Version 
 *********************************************************************************/
#ifndef __CTS_PING_H__
#define __CTS_PING_H__
//#include <iostream.h>
#include "Defines.h"
/// TODO , implement using shell script
typedef struct tagIP_HEADER {
	unsigned int h_len :4; // length of the header
	unsigned int version :4;  // Version of IP
	unsigned char tos; // Type of service
	unsigned short total_len; // total length of the packet
	unsigned short ident; // unique identifier
	unsigned short frag_and_flags; // flags
	unsigned char ttl;
	unsigned char proto;  // protocol (TCP, UDP etc)
	unsigned short checksum;  // IP checksum
	unsigned int sourceIP;
	unsigned int destIP;
} IP_HEADER;
typedef IP_HEADER FAR* LPIP_HEADER;
typedef struct tagICMP_HEADER {
	BYTE i_type;
	BYTE i_code; /* type sub code */
	USHORT i_cksum;
	USHORT i_id;
	USHORT i_seq;
	/* This is not the std header, but we reserve space for time */
	ULONG timestamp;
} ICMP_HEADER;
typedef ICMP_HEADER FAR* LPICMP_HEADER;
#pragma pack(pop)
struct CPingReply {
	in_addr Address;  //IP Address of the Replier
	unsigned long RTT; //Round Trip Time in ms	
};
class CPing {
protected:
	static BOOL sm_bAttemptedWinsock2Initialise;
public:
	BOOL Initialise();
	//BOOL Ping(LPCTSTR pszHostName,CPingReply &pr,UCHAR nTTL = 10, DWORD dwTimeout = 5000, UCHAR nPacketSize = 32);
	BOOL Ping(LPCTSTR pszHostName, CPingReply &pr, UCHAR nTTL = 10, DWORD dwTimeout = 2000, UCHAR nPacketSize = 32);
	int Ping1(LPCTSTR Address, int &nErrCode, int iTtl = 10, int iWaitTime = 2000);
	static BOOL IsSocketReadible(QAbstractSocket socket, DWORD dwTimeout, BOOL &bReadible);
	static __int64 sm_TimerFrequency;
};
#endif //__CTS_PING_H__

/// @file
// **************************************************************************
/// © Honeywell Trendview
// **************************************************************************
/// @n Module:		I/O conditioning
/// @n Filename:	FFConversionInfo.h
/// @n Description: Interface to convert floating point values to and from Engineering 
///	and internal representations
// 
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 6	Stability Project 1.3.1.1	7/2/2011 4:57:12 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 5	Stability Project 1.3.1.0	7/1/2011 4:27:21 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 4	V6 Firmware 1.3		2/2/2006 8:35:42 PM	Andy Kassell	Add
//		function to conver a magntude not an absolute value
// 3	V6 Firmware 1.2		5/18/2005 3:14:55 PM	Andy Kassell	Add
//		absolute span and reverse scale check accessors
// $
//
// **************************************************************************
#ifndef _FFCONVERSIONINFO_H
#define _FFCONVERSIONINFO_H
#include "Defines.h"
struct FConvPoint {
	float Source;			// Source value
	float Dest;				// Dest value
};
class CFFConversionInfo {
public:
	void CalcFConvInfo(float ZeroSource, float SpanSource, float ZeroDest, float SpanDest);
	float CalcSourceToDest(float sourceValue) const;
	float CalcDestToSource(float destValue) const;
	float CalcSourceToDestCapped(float Sourcepoint);
	float CalcDestMagnitude(float SourceMagnitude);
	// Get the absolute span of the scale (not the top limit) i.e. Zero = 20, Span =50 then result = 30
	float GetDestSpan() {
		return (m_Span.Dest - m_Zero.Dest);
	}
	;			///< Get the span of the destination 
	float GetSourceSpan() {
		return (m_Span.Source - m_Zero.Source);
	}
	;		///< Get the span of the source
	// Check if scale is reversed, TRUE = reversed scale, FALSE if normal
	BOOL DestScaleReversed() {
		return (m_Zero.Dest > m_Span.Dest);
	}
	;		///< Dest scale Boolean result on zero being greater then span
	BOOL SourceScaleReversed() {
		return (m_Zero.Source > m_Span.Source);
	}
	;	///< Source scale Boolean result on zero being greater then span
	QString GetConversionString();
private:
	struct FConvPoint m_Zero;		// Zero point	
	struct FConvPoint m_Span;		// Span point
	// Eng and Pixel
	float m_SourcePerDest;			// Source Units per dest
	float m_DestPerSource;			// Dest units per source
	BOOL m_SourceReverse;			// Zero and span reveresed for Source?
	BOOL m_DestReverse;				// Zero and span reveresed for Dest?
};
// End of Class Declaration
#endif // _FFCONVERSIONINFO_H

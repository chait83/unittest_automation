/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Utilties
/// @n Filename: OptionsCode.h
/// @n Desc:	 Build/decipher options code
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  4 Stability Project 1.1.1.1 7/2/2011 4:59:21 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  3 Stability Project 1.1.1.0 7/1/2011 4:27:40 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  2 V6 Firmware 1.1 2/9/2006 5:57:16 PM Andy Kassell  
//  Change encoding to reverse CCITT CRC-16 from arbitary BCC
//  1 V6 Firmware 1.0 9/7/2005 10:15:48 PM  Andy Kassell  
// $
//
// ****************************************************************
#ifndef __OPTIONCODE_H__
#define __OPTIONCODE_H__
#define DEV_ARISTOS	1
#define DEV_XSERIES	0
#include <QString>
#include "Defines.h"
//**Class*********************************************************************
///
/// @brief V6 Options code class
/// 
/// Cipher / Decihper options code for V6 recorder
///
//****************************************************************************
class COptionCode {
public:
	void CreateOptionsCode(QString &rstrOptionsCode, ULONG Serial, ULONG Credits, BOOL PasswordCFR, BOOL Pasturisation, /*BOOL SecureComm,*/
	int devType = DEV_ARISTOS);
	void EncodeOptionsCode(QString &rstrOptionsCode, int devType = DEV_ARISTOS);
    bool DecipherOptionsCode(const QString pwcOptionsCode, ULONG Serial, ULONG &Credits, BOOL &PasswordCFR,
			BOOL &Pasturisation,/* BOOL &SecureComm,*/int devType = DEV_ARISTOS);
	void UniqueCodeChecker();
};
#endif // __OPTIONCODE_H__

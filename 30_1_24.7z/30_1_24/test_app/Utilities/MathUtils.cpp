/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	Utilities
/// @n Filename:	MathUtils.cpp
/// @n Description: Implementation of general utility class providing math functions
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 7	Stability Project 1.2.1.3	7/2/2011 4:58:34 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 6	Stability Project 1.2.1.2	7/1/2011 4:38:28 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 5	Stability Project 1.2.1.1	3/17/2011 3:20:28 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 4	Stability Project 1.2.1.0	2/15/2011 3:03:16 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
// **************************************************************************
#include "MathUtils.h"
#include <math.h>
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
//****************************************************************************
// CMathUtils( )
///
/// Constructor
///
//****************************************************************************
CMathUtils::CMathUtils(void) {
}
//****************************************************************************
// ~CMathUtils()
///
/// Destructor
///
//****************************************************************************
CMathUtils::~CMathUtils(void) {
}
//****************************************************************************
//	void InitNumberasprintf(	T_NUMFORMAT &Numberasprintf, 
//							QString  pasprintfStr,
//							const T_SCALEINFO* const ScaleDetails ) const
///
/// Method that creates an appropriately formatted scale string
///
/// @param[in/out] 			T_NUMFORMAT &Numberasprintf - The number format structure
/// @param[out]				QString  pasprintfStr - The string we are to populate
/// @param[in]				const T_SCALEINFO* const ScaleDetails - The scale details
/// 
//****************************************************************************
void CMathUtils::InitNumberasprintf(T_NUMFORMAT &Numberasprintf, QString pasprintfStr, INT pasprintfStrBuffSize,
		const T_SCALEINFO *const ScaleDetails) {
	if (Numberasprintf.Auto) {
		//MarkD: if in scientific notation, Auto to 1 decimal place so the number can be read in DPMs
		if (Numberasprintf.Scientific) {
			Numberasprintf.Bd = 1;
			Numberasprintf.Ad = 1;
		} else {
			// base it on the scale details
			double range = fabs(ScaleDetails->Span - ScaleDetails->Zero);
			if (range < 10.0) {
				Numberasprintf.Bd = 1;
				Numberasprintf.Ad = 4;
			} else if (range < 100.0) {
				Numberasprintf.Bd = 2;
				Numberasprintf.Ad = 3;
			} else if (range < 1000.0) {
				Numberasprintf.Bd = 3;
				Numberasprintf.Ad = 2;
			} else if (range < 10000.0) {
				Numberasprintf.Bd = 4;
				Numberasprintf.Ad = 2;
			} else if (range < 100000.0) {
				Numberasprintf.Bd = 5;
				Numberasprintf.Ad = 0;
			}
		}
	}
	WCHAR temp[20];
	memset(temp, 0, 20);
	pasprintfStr.toWCharArray(temp);
	if (Numberasprintf.Base) // Hex?
	{
#if _MSC_VER < 1400 
		wcscpy(temp, L"%%0x%X"); // treat the value as hex rather than float.
#else
		wcscpy_s(pasprintfStr, pasprintfStrBuffSize, L"%%0x%X"); // treat the value as hex rather than float.
#endif
	} else {
		// only makes sense to set .Bd if you have .Zpad set to 1 since you will always get the
		// value displayed before the decimal point anyway (never truncated)
		if (Numberasprintf.Zpad)
			// for zero padding, we want to have at least Numberasprintf.Bd before the Decimal point
			// since the '.' counts as 1 char we need to add 1 to the minimum width specifier here.
			swprintf(temp, 20, L"%%0%d.%df", 1 + Numberasprintf.Bd + Numberasprintf.Ad, Numberasprintf.Ad);
		else {
			if (Numberasprintf.Scientific)
				swprintf(temp, 20, L"%%.%de", Numberasprintf.Ad); // scientific notation here	(.bd always 1 anyway and no zpad)
			else
				swprintf(temp, 20, L"%%.%df", Numberasprintf.Ad); // normal floating point
		}
	}
}
//****************************************************************************
// const USHORT Get16BitMask( const USHORT usINSTANCE_NO, USHORT &rusUShortArrayPos )
///
/// Helper method that returns a bit mask for a USHORT given the passed in instance number
///
/// @param[in]		const USHORT usINSTANCE_NO - The number to obtain a bitmask for
/// @param[out]		USHORT &rusUShortArrayPos - The position within a USHORT array that the passed in
///					instance number would lie within once converted to a bitmask
///
/// @return			The USHORT mask
///
//****************************************************************************
const USHORT CMathUtils::Get16BitMask(const USHORT usINSTANCE_NO, USHORT &rusUShortArrayPos) {
	USHORT usBitMask = 0x0001;
	rusUShortArrayPos = 0;
	USHORT usInstanceNo = usINSTANCE_NO;
	// check this is a valid instance for a picker (128 will be the max number of anything)
	if (usInstanceNo < 128) {
		while (usInstanceNo >= 16) {
			++rusUShortArrayPos;
			usInstanceNo -= 16;
		}
		// should have the correct USHORT, now set the correct bit
		while (usInstanceNo > 0) {
			// shift the mask to the next bit
			usBitMask <<= 1;
			--usInstanceNo;
		}
	} else {
		// do nothing
	}
	return usBitMask;
}
//****************************************************************************
// const ULONG Get32BitMask( const USHORT usINSTANCE_NO, USHORT &rusULongArrayPos )
///
/// Static helper method that returns a bit mask for a ULONG given the passed in instance number
///
/// @param[in]		const USHORT usINSTANCE_NO - The number to obtain a bitmask for
/// @param[out]		USHORT &rusULongArrayPos - The position within a ULONG array that the passed in
///					instance number would lie within once converted to a bitmask
///
/// @return			The ULONG mask
///
//****************************************************************************
const ULONG CMathUtils::Get32BitMask(const USHORT usINSTANCE_NO, USHORT &rusULongArrayPos) {
	ULONG ulBitMask = 0x0001;
	rusULongArrayPos = 0;
	USHORT usInstanceNo = usINSTANCE_NO;
	// check this is a valid instance for a picker (128 will be the max number of counters)
	if (usInstanceNo < 128) {
		while (usInstanceNo >= 32) {
			++rusULongArrayPos;
			usInstanceNo -= 32;
		}
		// should have the correct ULONG, now set the correct bit
		while (usInstanceNo > 0) {
			// shift the mask to the next bit
			ulBitMask <<= 1;
			--usInstanceNo;
		}
	} else {
		// do nothing
	}
	return ulBitMask;
}

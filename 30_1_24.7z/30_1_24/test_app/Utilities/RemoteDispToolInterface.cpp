/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Utilties
/// @n Filename: CRemoteDispToolInterface.cpp
/// @n Desc:	Implementation of CRemoteDispToolInterface
///
// ****************************************************************
// Revision History
//	1-Feb-2021 Created separate thread for RDT and Recorder communication.
// ****************************************************************
#include "RemoteDispToolInterface.h"
//****************************************************************************
/// CRemoteDispToolInterface - Constructor
///
/// @param n/a
///
/// @return		n/a
///
//****************************************************************************
CRemoteDispToolInterface::CRemoteDispToolInterface() {
} //end CRemoteDispToolInterface()
//****************************************************************************
/// ~CRemoteDispToolInterface - Destructor
///
/// @param n/a
///
/// @return		n/a
///
//****************************************************************************
CRemoteDispToolInterface::~CRemoteDispToolInterface() {
} //end ~CRemoteDispToolInterface() 
//****************************************************************************
/// RemoteDispToolInterfaceFunc - Starts the thread for accepting connections
///
/// @param n/a
///
/// @return		true if successful
///
//****************************************************************************
bool CRemoteDispToolInterface::RemoteDispToolInterfaceFunc() {
	CERemoteDispToolSocket *socket;
	socket = new CERemoteDispToolSocket();
	if (socket->Create(SOCK_STREAM, 512) == false) // Buffer size- 512
			{
		printf("Error");
		return false;
	}
	if (socket->Accept(2150, 5) == false) //BackLog - 5
			{
		return false;
	}
	return true;
} //end RemoteDispToolInterfaceFunc()

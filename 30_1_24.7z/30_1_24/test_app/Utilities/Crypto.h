/// @file 
/// **************************************************************************
/// © Honeywell Trendview - Inspired by codeproject.com article written by Shrishail Rana
/// **************************************************************************
/// @n Module: 		Utilities
/// @n Filename:  Crypto.h
/// @n Description: Definition of the Crypto class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  4 Stability Project 1.1.1.1 7/2/2011 4:56:25 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  3 Stability Project 1.1.1.0 7/1/2011 4:26:48 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  2 V6 Firmware 1.1 5/1/2007 3:42:26 PM Roger Dawson  
//  Fixed a problem with the password encryption code corrupting network
//  admin and email passwords.
//  1 V6 Firmware 1.0 6/1/2006 2:02:07 PM Roger Dawson  
// $
//
// **************************************************************************
#if !defined(AFX_CRYPTO_H__5ACD60F7_1E73_4060_8204_509C11422864__INCLUDED_)
#define AFX_CRYPTO_H__5ACD60F7_1E73_4060_8204_509C11422864__INCLUDED_
#include <QString>
#include "Defines.h"
//**CCrypto***********************************************************
///
/// @brief Encryption class
/// 
/// Encryption class
///
//****************************************************************************
class CCrypto {
public:
	// Constructor
	CCrypto();
	// Constructor
	CCrypto(const QString &rstrKEY);
	// Destructor
	virtual ~CCrypto();
	// Method that decrypts the passed in string
	const QString Decrypt(const QString pwcENCRYPTED_DATA, const USHORT usDATA_LEN);
	// Method that encrypts the passed in string
	void Encrypt(WCHAR *pwcDataToEncrypt, const USHORT usDATA_LEN, const USHORT usBUFF_LEN);
private:
	/// Variable used to store the KEY
	const QString m_strKEY;
	/// Variable used to store the global key (when one is not defined)
	static const QString ms_strDEFAULT_KEY;
	// Method that actually performs the encrypting/decrypting
	void Crypt(WCHAR *pwcData, const USHORT usDATA_LEN);
};
#endif // !defined(AFX_CRYPTO_H__5ACD60F7_1E73_4060_8204_509C11422864__INCLUDED_)

// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Utility
/// @n Filename: sercomm.cpp
/// @n Desc:	 Simple Serial communications class for Windows
///						
// 
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  19  Stability Project 1.14.1.3 7/2/2011 5:01:15 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  18  Stability Project 1.14.1.2 7/1/2011 4:38:55 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  17  Stability Project 1.14.1.1 3/17/2011 3:20:46 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  16  Stability Project 1.14.1.0 2/15/2011 3:03:55 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// ****************************************************************
#include <QtWidgets/qwidget.h>
#include <QSerialPort>
#include "sercomm.h"
#include "TVtime.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
//**********************************************************************
///
/// CSerialComms constructor
/// 
//**********************************************************************
CSerialComms::CSerialComms() {
//	qDebug("Creating new CSerialComms instance\n");
	m_hPort = NULL;
}
//**********************************************************************
///
/// CSerialComms destructor
/// 
//**********************************************************************
CSerialComms::~CSerialComms() {
//	qDebug("Deleting new CSerialComms instance\n");
	Close();
}
#define COMM_PORT_NAME_LEN		10
#define COMM_STATE_FAILURE		0
//**********************************************************************
///
/// Open a serial communication port
///
/// @param[in]	commPort - Comms port to open, see T_COMMPORT enum in sercomm.h
/// @param[int]	baudRate - Baud rate to set port to, see T_BAUDRATE enum in sercomm.h
/// @return		T_SERCOM_RESULT return result, see T_SERCOM_RESULT enum in sercomm.h
/// 
//**********************************************************************
T_SERCOM_RESULT CSerialComms::Open(T_COMMPORT commPort, T_BAUDRATE baudRate) {
	T_SERCOM_RESULT retVal = SC_OKAY;
	QString devName = "";
	devName = QString::asprintf("/dev/ttyS%d", commPort);
	m_DCB.setPortName(devName);
	if (!m_DCB.open(QIODevice::ReadWrite))
		retVal = SC_FAILED;
	qDebug("Serial port Opened on /dev/ttyS:%d \n ", commPort);
	// Change the QIODevice structure settings.
	m_DCB.setBaudRate(baudRate);					// Set to specified baud rate
	m_DCB.setParity(QSerialPort::NoParity);						// Enable parity checking
	m_DCB.setFlowControl(QSerialPort::NoFlowControl);					// No CTS output flow control
	m_DCB.setRequestToSend(FALSE);					// No CTS output flow control
	m_DCB.setDataBits(QSerialPort::Data8);							// Number of bits/byte, 4-8
	m_DCB.setParity(QSerialPort::NoParity);					// 0-4=no,odd,even,mark,space
	m_DCB.setStopBits(QSerialPort::OneStop);				// 0,1,2 = 1, 1.5, 2
	return SC_OKAY;
}
//**********************************************************************
///
/// Read data from serail communication port
///
/// @param[out]	pBuffer - Pointer to buffer to read data into
/// @param[int,out]	pSize - ptr to Max size data to read, will be set to number of bytes read.
/// @return		T_SERCOM_RESULT return result, see T_SERCOM_RESULT enum in sercomm.h
/// 
//**********************************************************************
T_SERCOM_RESULT CSerialComms::Read(void *pBuffer, ULONG *pSize) {
	DWORD errors = 0;
	/// TODO Complete this code
}
//**********************************************************************
///
/// Write data to serial communication port
///
/// @param[in]	pBuffer - Pointer to buffer of data to write
/// @param[int,out]	pSize - ptr to Max size data to written, will be set to number of bytes written.
/// @return		T_SERCOM_RESULT return result, see T_SERCOM_RESULT enum in sercomm.h
/// 
//**********************************************************************
T_SERCOM_RESULT CSerialComms::Write(void *pBuffer, ULONG *pSize) {
	DWORD errors = 0;
	T_SERCOM_RESULT retVal = SC_OKAY;
	QByteArray data;
	m_DCB.write(data);
	if (m_DCB.waitForBytesWritten()) {
		return SC_OKAY;
	} else {
		/// TODO : Resolve this
        emit timeout(QWidget::tr("Wait write request timeout %1").arg(QTime::currentTime().toString("hh:mm:ss")));
	}
	return SC_FAILED;
}
//**********************************************************************
///
/// Clears all internal comms buffers and and pending operations
///
/// @return		T_SERCOM_RESULT return result, see T_SERCOM_RESULT enum in sercomm.h
/// 
//**********************************************************************
T_SERCOM_RESULT CSerialComms::ClearAllBuffers() {
	T_SERCOM_RESULT retVal = SC_OKAY;
	m_DCB.flush();
	m_DCB.close();
	return retVal;
}
//**********************************************************************
///
/// General error handler to tarce out comms errors and reset appropriate 
///
/// @return		nothing
/// 
//**********************************************************************
void CSerialComms::HandleError(QString pRoutine) {
	m_DCB.clearError();
    qDebug("S COMMS: %s failed with error %d CCE(%x) InQueue(%d)\n", pRoutine.toLocal8Bit().data(), "", m_cstat.cbInQue);
}
//**********************************************************************
///
/// Close the port if open
///
/// @return		T_SERCOM_RESULT return result, see T_SERCOM_RESULT enum in sercomm.h
/// 
//**********************************************************************
T_SERCOM_RESULT CSerialComms::Close() {
	m_DCB.close();
	return SC_OKAY;
}
//**********************************************************************
///
/// Sends a test string of hello to specified com port at 9600 for
/// specified number of times at 1 second intervals
///
/// @return		T_SERCOM_RESULT return result, see T_SERCOM_RESULT enum in sercomm.h
/// 
//**********************************************************************
void CSerialComms::TestHelloToPortAt9600(T_COMMPORT commPort, int times) {
	ULONG size;
	CHAR buffer[100];
	sprintf(buffer, "Hello\n\r");
	if (Open(commPort, BR_9600) == SC_FAILED) {
		qDebug(("S COMMS: Open Failed on COM%d: \n"), commPort);
		return;
	}
	for (int i = 0; i < times; i++) {
		size = 7;
		if (Write(buffer, &size) == SC_FAILED) {
			qDebug(("S COMMS: Write %d failed on COM%d: \n"), i, commPort);
			Close();
			return;
		}
		qDebug(("S COMMS: Write HELLO(%d) on COM%d: \n"), i, commPort);
		sleep(1000);
	}
	Close();
}

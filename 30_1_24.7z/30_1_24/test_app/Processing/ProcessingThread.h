/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Processing
/// @n Filename: ProcessingThread.h
/// @n Desc:	 Main Data processing thread 
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  3 Stability Project 1.0.1.1 7/2/2011 4:59:54 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  2 Stability Project 1.0.1.0 7/1/2011 4:27:12 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  1 V6 Firmware 1.0 12/17/2004 4:27:32 PM  Andy Kassell  
// $
//
// ****************************************************************
#ifndef __PROCESSING_THREAD__
#define __PROCESSING_THREAD__
//**Class*********************************************************************
///
/// @brief Main Data processing thread 
/// 
//****************************************************************************
// CProcessingThread
#include <QThread>
#include "Defines.h"

class CProcessingThread: public QThread {
	// DECLARE_DYNCREATE (CProcessingThread)
protected:
	CProcessingThread();  // protected constructor used by dynamic creation
	virtual ~CProcessingThread();
public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	static UINT ThreadFunc(LPVOID lpParam);
protected:
};
#endif //__PROCESSING_THREAD__

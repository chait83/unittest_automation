/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Processing
/// @n Filename: Alarms.h
/// @n Desc:	 Manage all aspects of Alarms within the system
///				 
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  36  Stability Project 1.33.1.1 7/2/2011 4:55:19 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  35  Stability Project 1.33.1.0 7/1/2011 4:27:27 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  34  V6 Firmware 1.33 9/25/2009 3:19:26 PM  Binsy Pillai  
//  event cursor merging of code
//  33  V6 Firmware 1.32 2/12/2007 9:23:25 PM  Jason Parker  
//  Additions to make alarms work ok for charts when in alarm and the pen
//  changes group
// $
//
// ****************************************************************
#ifndef __ALARMS_H__
#define __ALARMS_H__
#include "V6defines.h"
#include "V6globals.h"
#include "V6Config.h"
#include "BasicMaxMinAve.h"
#include "PipeProcess.h"
class CPenControl;
const USHORT ASTAT_OUT_ALARM = 0;
const USHORT ASTAT_IN_ALARM = 1;
/// Return types for PenControl access
typedef enum {
	REQ_ALARM_RESET = 0,							///< Request a Reset
	REQ_ALARM_ACKNOWLEDGE						///< Request and Acknoledge
} T_ALARM_REQUEST;
/// Return types for PenControl access
typedef enum {
	RET_ALARM_OKAY = 0,							///< Function completed okay
	RET_ALARM_INIT_FAILED,						///< Alarm initialisation failed
	RET_ALARM_CFG_FAILED						///< Alarm configuration failed
} T_ALARM_CONTROL_RETURN;
// NV data to store for each alarm
typedef struct {
	USHORT State;			///< Alarm State to persist.
	USHORT Type;			///< Type of alarm when persist was set.
	float OriginalLevel;	///< Original alarm level wehn persist was set.
	float UserLevel;		///< New user level.
	ULONG Counter;			///< Number of time alarm has been triggered.
	USHORT Enabled;			///< Enabled Flag.
	USHORT Spare;			///< Spare data.
} T_NV_ALARM_DATA;
const int MAX_ALARMS_IN_LIST = V6_MAX_PENS * V6_MAX_ALARMS;
//**Class*********************************************************************
///
/// @brief Alarm processor
/// 
/// Process and individual alarm for a Pen, maintiain DIT
///
//****************************************************************************
class CAlarm {
public:
	CAlarm();
	~CAlarm();
public:		// API methods
	static void InitialiseAlarmNonVolatile();
	T_ALARM_CONTROL_RETURN IntialiseAlarm(USHORT penNumber, USHORT alarmNumber, CPenControl *pLogChannel);
	T_ALARM_CONTROL_RETURN SetAlarmFromConfig(T_PPEN pPenCfg);
	BOOL IsEnabled() {
		return m_Enabled;
	}
	;		///< Is the Alarm enabled
	BOOL IsActive() {
		return m_Active;
	}
	;		///< Is the Alarm Active
	T_ALARM_CONTROL_RETURN ProcessAlarm();
	void UpdateCommonPenAlarm();				///< Update Pen alarm summary with individual alarm
	void RequestAcknowledge();					///< Request the alarm is acknowledged
	void RequestCounterReset() {
		m_requestResetCounter = TRUE;
	}
	;
	BOOL ChangeLogSpeedOnAlarm() {
		return m_pAlarmCfg->ChangeLog;
	}
	;	///< Determine if change logging speed enabled
	void UpdateUserLevel(float userLevel);
	float GetUserLevel() const {
		return m_pAlarmDataItem->GetFPValue();
	}
	;
	ULONG GetAlarmCounter() const {
		return m_pNVData->Counter;
	}
	BOOL InAlarm() const {
		return m_InAlarmNow;
	}
private:	// Methods
	// Alarm processing function, used as ptrs so all must be same prototype
	T_ALARM_CONTROL_RETURN ProcessDummy();					///< Dummy for unused alarms
	T_ALARM_CONTROL_RETURN ProcessHighAlarm();				///< Processing for High alarm
	T_ALARM_CONTROL_RETURN ProcessLowAlarm();				///< Processing for Low alarm
	T_ALARM_CONTROL_RETURN ProcessRateAlarm();				///< Processing for Rate Up/Down alarm
	T_ALARM_CONTROL_RETURN ProcessDeviationAlarm();			///< Processing for Deviation alarm
	T_ALARM_CONTROL_RETURN CommonProcessing();				///< Common processing for all alarms
	void ProcessDamping();									///< Process damping on an alarm
	void ProcessReflash();									///< Process the reflash
	T_ALARM_CONTROL_RETURN ConfigureRateAlarm();			///< Configuration for Rate up and Rate down alarms
	T_ALARM_CONTROL_RETURN ConfigureDeviationAlarm();		///< Configuration for Deviation alarm
	T_ALARM_CONTROL_RETURN ConfigureHysteresis();			///< Configure Hysteresis
	T_ALARM_CONTROL_RETURN ConfigureDamping();				///< Configure Damping
	T_ALARM_CONTROL_RETURN AlarmStateMachine();				///< Alarm status state machine
	T_ALARM_CONTROL_RETURN ResetAlarmToNonActive(BOOL startup); ///< Reset alarm to inactive state (with flag for start-up call)
	T_ALARM_CONTROL_RETURN SetAlarmToActive(BOOL startup); ///< Set alarm to an active state (with flag for start-up call)
	void AssertClearRelays(CDataItemDigitalIOUser::T_DIG_STATE state);
	void ClearRelays(void);
	void AssertRelays(void);
	void ClearOldRelays(void);
	void UpdateStatusAndLevel(T_DATAITEM_STATUS status, float userLevel);	///< Set the alarm status and persist
	void UpdateStatus(T_DATAITEM_STATUS status);
	void LogMessage(T_MSGLISTSER_ALARM_MSG_TYPE type, UINT messNumber); ///< Log the alarm message
	float CalcEngRangeFromPercentageRange(float percentValue);
	void ResetAlarmCounter() {
		m_pNVData->Counter = 0;
		m_pAlarmDataItem->SetCounter(m_pNVData->Counter);
	}
	;
	void IncrementAlarmCounter() {
		m_pNVData->Counter++;
		m_pAlarmDataItem->SetCounter(m_pNVData->Counter);
	}
	;
	// Method that sends an alarm as an email, if necessary
    void SendEmail(const char* MESSAGE) const;
private:	// Member variables
	int m_penNumber;						///< Number of pen that alarm belongs to 0-95
	int m_alarmNumber;						///< Number of alarm within pen 0-5
	T_ALARM_CONTROL_RETURN (CAlarm::*m_pFuncProcess)();	///< Pointer to relevant processing function
	BOOL m_Enabled;				///< Is alarm currently enabled? if so should be processed depending on m_Active member
	BOOL m_Active;				///< Is alarm processing active? if so include in processing, can be controlled by DI
	BOOL m_requestAcknowledge;				///< An Acknowledge has been requested
	BOOL m_requestResetCounter;				///< An Reset Counter has been requested
	CPenControl *m_pPenCtrl;				///< Pointer to controlling Pen
	T_PALARM m_pAlarmCfg;					///< Pointer to Alarm configuration in CMM
	T_PPEN m_pPenCfg;						///< Pointer to the Pen config for the Alarm
	CDataItemPen *m_pPenDataItem;			///< Pointer to Pen Data Item
	CDataItemAlarm *m_pAlarmDataItem;		///< Pointer to Alarm Data Item
	CDataItemPen *m_pDevPenDataItem;		///< Pointer to Pen Data Item for deviation alarm
	BOOL m_InAlarmNow;						///< Status of Alarm TRUE in alarm state , FALSE not in alarm state
	USHORT m_AlarmStatusLastTime;///< State of m_InAlarmNow in previous evaluation @note but needs to be set rogue on startup hence not BOOL
	float m_hystLevelInEngValue;			///< Hysteresis band in engineering units
	BOOL m_CurrentDeviationAbove;			///< Keep track if current deviation is above or below band 
	float m_dampingStartTime;				///< Time that damping was started
	BOOL m_StartDamping;					///< If TRUE start damping on next "in alarm", FALSE indicates in damping
	CDataItemDigitalIOUser *m_pDigUserEnableBy;		///< Interface to data item table if alarm enabled by digital inputs
	CDataItemDigitalIOUser *m_pDigUserSetOuptuts;///< Interface to data item table if alarm asserts/clears digital on actuation
	BOOL m_ActivateRelays;							///< Indicates if relays need to be activated on alarm
	T_NV_ALARM_DATA *m_pNVData;				///< Non volatile alarm data
	static BYTE *pAlarmNVBaseAddress;		///< Static base address for alarm NV (for all alarms)
	float m_reflashStartTime;					///< Start time of reflash
	BOOL m_StartReflash;					///< TRUE to start reflash on next alarm, otherwise false
	BOOL m_relaysAsserted;	///< Flasg to indicate if relays have already been asserted or cleared (avoids duplication)
	BOOL m_FirstDIRun;						///< Control processing of alarm enabled by DI on power-up
	BOOL m_OldMarkChart;					///< Remember mark chart status before last change
	T_PEN_GROUPS m_OldGroupNumber;
	CPipeProcess m_ratePipe;				///< Reading pipe for Rate of change alarm
	int m_rateCountDown;					///< Countdown time for rate
	int m_secsPerReading;					///< seconds per reading for reload for Rate
	CBasicAverage m_rateAve;				///< Average of all reading for rate processing
};
//**Class*********************************************************************
///
/// @brief Alarm processor overview
/// 
/// Provide information and stats on alarm activity
///
//****************************************************************************
class CAlarmOverview {
public:
	CAlarmOverview();
public:		// API methods
	void AddActiveAlarm() {
		m_ActiveAlarms++;
	}
	;
	void RemoveActiveAlarm() {
		m_ActiveAlarms--;
	}
	;
	void AddInAlarm() {
		m_AlarmInAlarm++;
	}
	;
	void RemoveInAlarm() {
		m_AlarmInAlarm--;
	}
	;
	void AddChartInAlarm(UCHAR GroupNumber) {
		m_ChartAlarmInAlarm[GroupNumber]++;
		m_ChartAlarmInAlarm[PEN_GROUP_NONE]++;
	}
	;
	void RemoveChartInAlarm(UCHAR GroupNumber) {
		m_ChartAlarmInAlarm[GroupNumber]--;
		m_ChartAlarmInAlarm[PEN_GROUP_NONE]--;
	}
	;
	void ResetAlarmOverview() {
		m_AlarmInAlarm = 0;
		m_ActiveAlarms = 0;
		for (int i = 0; i < PEN_GROUP_MAX; i++)
			m_ChartAlarmInAlarm[i] = 0;
	}
	;
	ULONG GetNumberOfActiveAlarms() {
		return m_ActiveAlarms;
	}
	;		///< Get Active alarms, i.e. alarms enabled and active
	ULONG GetNumberOfAlarmsInAlarm() {
		return m_AlarmInAlarm;
	}
	;		///< Get Number of alarms in alarm condition
	ULONG GetNumberOfChartAlarmsInAlarm(UCHAR GroupNumber) {
		return m_ChartAlarmInAlarm[GroupNumber];
	}
	;	///< Get Number of alarms in alarm condition
private:	// Methods
private:	// Member variables
	ULONG m_ActiveAlarms;
	ULONG m_AlarmInAlarm;
	ULONG m_ChartAlarmInAlarm[PEN_GROUP_MAX];
};
/// @todo change this to a singleton
extern CAlarmOverview GlbAlarmOverview;		///< Global alarm overview
#define pALARM_OVERVIEW (&GlbAlarmOverview)	///< Use to access global alarm overview, for furture abstraction	
//**Class*********************************************************************
///
/// @brief Cross reference Alarm List
/// 
/// Provide a simple class to provide a list of alarms for speed of processing
///
//****************************************************************************
class CAlarmList {
public:
	CAlarmList() {
		ResetList();
	}
	;
public:		// API methods
	CAlarm* GetEntry(USHORT Index) {
		return m_listRef[Index];
	}
	;
	void ResetList();
	short AddAlarmToList(CAlarm *alarm);
	const USHORT GetNumberOfAlarms() {
		return m_NumEntries;
	}
	;
	void SetNumberOfAlarm(const USHORT num) {
		m_NumEntries = num;
	}
	;
private:	// Member variables
	CAlarm *m_listRef[MAX_ALARMS_IN_LIST];
	USHORT m_NumEntries;
};
#endif //__ALARMS_H__

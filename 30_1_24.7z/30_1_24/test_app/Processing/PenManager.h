/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Processing
/// @n Filename: PenManager.h
/// @n Desc:	 Manage Pens within the recorder system
///				 
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  60  Stability Project 1.56.1.2 8/19/2011 6:46:29 PM  Hemant(HAIL) 
// Fix for 32 Pen in a Group in case of Batch
//  59  Stability Project 1.56.1.1 7/2/2011 4:59:40 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  58  Stability Project 1.56.1.0 7/1/2011 4:27:10 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  57  V6 Firmware 1.56 11/20/2009 4:57:31 PM  Binsy Pillai  
//  precursur code
// $
//
// ****************************************************************
#ifndef __PENMANAGER_H__
#define __PENMANAGER_H__
#include <QMutex>
#include "PenControl.h"
#include "QueueManager.h"
#include "reportData.h"
#include "LogRateControl.h"
#include "DataItemBase.h"
const short NO_PEN = -1;		// Indicate no pen is available within list
typedef enum {
	BIAS_LOG, BIAS_CHART,
} T_BIAS_TOWARDS;
typedef enum {
	MAX_VALS_OK, INVALID_BIAS_AMOUNT
} T_CALC_MAX_RET;
typedef enum {
	PRE_TRIGGER_NOT_ACTIVE = 0,			///< Pre trigger is not active, there are no pre-trigger pens configured
	PRE_TRIGGER_RUNNING,				///< Pre trigger is running and storeing information
	PRE_TRIGGER_READY_FOR_PROCESSING,	///< Pre trigger event has fired and pre trigger info needs to be processed
	PRE_TRIGGER_READY_FOR_EXPORT,		///< Pre trigger buffer have been saved to interval CF ready for export
	PRE_TRIGGER_READY_FOR_RESTART,///< Pre trigger buffers have been put to disk and exported so a restart can be performed when alarms are inactive
	PRE_TRIGGER_RESTART,				///< Pre buffers saved and alarms inactive, restart the pre trigger buffer
} T_PRETRIGGER_STAT;
//structure for recieving info relating to the Max value calculation
typedef struct {
	ULONG ulChartFastTime;
	ULONG ulChartMedTime;
	ULONG ulChartSlowTime;
	ULONG ulLongestLog;
	ULONG ulShortestLog;
	USHORT usLongestID;
	USHORT usShortestID;
	USHORT usNumPens;
	USHORT usNumLogs;
	USHORT usNumLogFiles;
	USHORT usNumChartFiles;
	USHORT usNumMsgFiles;
	USHORT usShortestFiles;
	USHORT usLongestFiles;
} T_CALC_MAX_INFO;
const USHORT MAX_BIAS = 100;
const USHORT MIN_Q_LEN = 1;
const USHORT PERCENTAGE = 100;
const USHORT ALARM_WEIGHT = 25;
const int CHART_RATE_FACTOR = 1000000;
const int LOG_RATE_FACTOR = 1000000;
const USHORT CHART_READS_PER_BLOCK = 63;
const USHORT LOG_READS_PER_BLOCK = 120;
const float QFUZZY = 2;
const float QCONTINUOUS = 1;
const float QMAXMIN = 0.5;
//PSR fix for 1-37ZF83M - QXe_Not able to add more than 16 Pens in a group begin 
//This should be derived from V6Config.h #define SCREEN_CANNEDPENS_SIZE  32 ///< Length of CannedPens - Pen config for canned screens
#define MAX_PENS_IN_GROUP_MULTI 32 
//This should be derived from V6Config.h #define SCREEN_CANNEDPENS_SIZE  32 ///< Length of CannedPens - Pen config for canned screens
//So changing from 16 to 32. Also 16 is not proper restriction since V6(XSeries) supports 32
#define MAX_PENS_IN_GROUP_MINI 32
//PSR fix for 1-37ZF83M - QXe_Not able to add more than 16 Pens in a group end 
//**Class*********************************************************************
///
/// @brief Cross reference Pen List
/// 
/// Provide a simple class to provide a list of pens that match user criteria
///
//****************************************************************************
class CPenList {
public:
	CPenList() {
		ResetList();
	}
	;
public:		// API methods
	CPenControl* GetFirst(USHORT *pIndex);
	CPenControl* GetNext(USHORT *pIndex);
	CPenControl* GetEntry(USHORT Index) {
		return m_listRef[Index];
	}
	;
	void ResetList();
	short AddPenToList(CPenControl *pen);
	const USHORT GetNumberOfPens() {
		return m_NumEntries;
	}
	;
	void SetNumberOfPens(const USHORT num) {
		m_NumEntries = num;
	}
	;
private:	// Member variables
	CPenControl *m_listRef[V6_MAX_PENS];
	USHORT m_NumEntries;
};
// Pen Manager class memebr return values
typedef enum {
	PENMANAGER_OK, PENMANAGER_CONFIG_FAILURE,
} T_PENMANAGER_RETURN;
typedef enum {
	STRIP_PENQ_SLOW,
	STRIP_PENQ_MED,
	STRIP_PENQ_FAST,
	CIRC_PENQ_SLOW,
	CIRC_PENQ_MED,
	CIRC_PENQ_FAST,
	NO_OF_PENQS = QMC_TOTAL_NO_OF_CHART_QUEUES_PER_PEN
} T_PENQ_INFO_INDEXES;
typedef struct {
	float fChartQDataRate[V6_MAX_PENS * (NO_OF_PENQS)];
	float fLogQDataRate[V6_MAX_PENS];
	USHORT MaxFilesPerChartQ[V6_MAX_PENS * (NO_OF_PENQS)];
	USHORT MaxFilesPerLogQ[V6_MAX_PENS];
	BOOL aPenActive[V6_MAX_PENS];
	BOOL aLogActive[V6_MAX_PENS];
	BOOL aLogFast[V6_MAX_PENS];
} T_QRATE_MAX_INFO, *T_PQRATE_MAX_INFO;
//**Class*********************************************************************
///
/// @brief Manage pens running within the recorder
/// 
/// The Pen manager will manage all pens within the system
/// this will tie pen configuration with working information
/// to provide a complete view of the pen for all processing
///
/// This class is a singleton.
///
//****************************************************************************
typedef std::vector<RTDATASTRUCT> RTDATASTRUCTLIST;
typedef std::map<int, CLogRateControl*> LOGRATEMAP;
typedef std::map<int, RTDATASTRUCTLIST> RTDATASTRUCTMAP;
typedef std::map<int, RLOGCONFIGSTRUCT*> LOGCONFIGMAP;
typedef std::vector<int> QAbstractSocket_CONN_VEC;
class CPenManager: public CPassiveModule {
public:		//Singleton 
	static CPenManager* GetHandle();
	void CleanUp();
private:	// Singleton
	CPenManager();
	~CPenManager() {
	}
	;	// Will never be called
	CPenManager(const CPenManager&);
	CPenManager& operator=(const CPenManager&) {
		return *this;
	}
	;
	static CPenManager *m_pPenManInstance;
    static QMutex m_CreationMutex;
public:	// API methods
	// Initialise and shutdown of device abstraction
	T_PENMANAGER_RETURN Initialise();
	CPenControl* GetPenControl(USHORT penNumber, T_PENBASE base);
	T_PENMANAGER_RETURN ImplementConfiguration();
	T_PENMANAGER_RETURN ProcessPens();
	T_PENMANAGER_RETURN ProcessTotals();
	T_PENMANAGER_RETURN ProcessLogging();
	T_PENMANAGER_RETURN ProcessAlarms();
	T_PENMANAGER_RETURN ProcessPenChartQueues();
	T_PENMANAGER_RETURN AcknowledgeAlarm(T_PEN_GROUPS Group, USHORT penNumber, USHORT alarmNumber);
	T_PENMANAGER_RETURN ResetAlarm(T_PEN_GROUPS Group, USHORT penNumber, USHORT alarmNumber);
	T_PENMANAGER_RETURN AcknowledgeOrResetAlarm(T_ALARM_REQUEST reqType, T_PEN_GROUPS Group, USHORT penNumber,
			USHORT alarmNumber);
	T_PENMANAGER_RETURN PerformTotaliserAction(T_PEN_GROUPS Group, USHORT penNumber, T_TOTAL_MODE totalAction);
	T_PENMANAGER_RETURN PerformMaxMinResetAction(T_PEN_GROUPS Group, USHORT penNumber, T_MAXMIN_MODE maxminAction,
			BOOL IsManual = TRUE);
	T_PENMANAGER_RETURN PerformAlarmLevelUpdate(USHORT penNumber, USHORT alarmNumber, float newLevel);
	T_PENMANAGER_RETURN PerformAlarmLevelUpdateSilent(USHORT penNumber, USHORT alarmNumber, float newLevel);
	BOOL IsGroupUsed(T_PEN_GROUPS group);
	BOOL IsPenInGroup(const T_PEN_GROUPS group, const USHORT penNo);
	WCHAR* GetGroupName(T_PEN_GROUPS group);
	CPenList* GetGroupList(T_PEN_GROUPS group);
	CPenList* GetAvailableList() {
		return &m_AvailablePens;
	}
	;
	T_PENMANAGER_RETURN StartLogging(T_PEN_GROUPS group);
	T_PENMANAGER_RETURN StopLogging(T_PEN_GROUPS group);
	T_PENMANAGER_RETURN FlushAllLogChannels();
	USHORT NumberOfPensLogging();
	ULONG PenLogRate(USHORT penInstance);
	ULONG PenEffectiveLogRate(USHORT penInstance);
	// Method that determines if a particular pen is logging
	const bool IsPenLogging(const USHORT usPEN_INSTANCE);
	// Start and stop logging an individual pen
	T_PENMANAGER_RETURN StopPenLogging(const USHORT usPEN_INSTANCE);
	T_PENMANAGER_RETURN StartPenLogging(const USHORT usPEN_INSTANCE);
	T_PENMANAGER_RETURN StopAllLoggingDirect();
	T_PENMANAGER_RETURN RestoreLogging(T_PEN_GROUPS group);
	const bool IsPenWaitingForAlignment(const USHORT usPEN_INSTANCE);
	const USHORT NoOfPensWaitingForAlignment(T_PEN_GROUPS group = PEN_GROUP_ALL);
	T_CALC_MAX_RET CalculateQueueMaxVals(BYTE BiasAmount, T_BIAS_TOWARDS BiasTowards, T_CALC_MAX_INFO *pCalcInfo = NULL,
			BOOL bQuery = FALSE);
	BOOL IsActionStillPending() {
		return m_LogChannelActionPending;
	}
	;
	// Reports
	void ResetAllReportData();
	void CheckReportTimers();
	BOOL IsNewHour() {
		return m_IsNewHour;
	}
	;
	BOOL IsNewDay() {
		return m_IsNewDay;
	}
	;
	BOOL IsNewWeek() {
		return m_IsNewWeekDay;
	}
	;
	BOOL IsNewMonth() {
		return m_IsNewMonth;
	}
	;
	void SetWeekChangeOverDay(int ChangeOverDay) {
		m_pNVReportData->startWeekDay = ChangeOverDay;
	}
	;		///< Start Weekday - 0 to 6
	BOOL IsReportResetRequested() {
		return m_ReportResetRequest;
	}
	;
	void RequestFullReportReset();
	T_PEN_REPORT* GetPenReport(USHORT penNumber, T_PENBASE base);
	float GetReportMax(USHORT penNumber, T_PENBASE base, T_REPORT_HISTORY history, T_REPORT_PERIOD period,
			LONGLONG &maxTime);
	float GetReportMin(USHORT penNumber, T_PENBASE base, T_REPORT_HISTORY history, T_REPORT_PERIOD period,
			LONGLONG &minTime);
	float GetReportTot(USHORT penNumber, T_PENBASE base, T_REPORT_HISTORY history, T_REPORT_PERIOD period);
	float GetReportAve(USHORT penNumber, T_PENBASE base, T_REPORT_HISTORY history, T_REPORT_PERIOD period);
	LONGLONG GetReportStartTime(USHORT penNumber, T_PENBASE base, T_REPORT_HISTORY history, T_REPORT_PERIOD period);
	// Pre Trigger API
	BOOL ProcessPreTriggerFilesForExport();											///< Process the pre trigger data
	T_PRETRIGGER_STAT GetPreTriggerStatus() {
		return (T_PRETRIGGER_STAT) m_preTriggerStatus.ul;
	}
	;	///< Get the pre trigger status
	BOOL DoesPenHavePreTrigger(int penNo) {
		return m_Pen[penNo].m_preTrigger.m_Enabled;
	}
	;		///< Return if pen is enabled for pre-triggering - zero based	
	void SetPreTriggerStatus(T_PRETRIGGER_STAT status);							///< Set the status of the pre trigger
	const QString GetPreTriggerTextStatus() {
		return m_preTriggerTextStatus;
	}
	;					///< return the text status for the pre trigger
	// Stability Project Fix:
	// Fix for 32 Pen in a Group in case of Batch
	USHORT GetNoOfPensInGroup(USHORT GroupNO) {
		return m_GroupPens[GroupNO].GetNumberOfPens();
	}
	;
	USHORT GetMaxPensInGroup() {
		//PSR fix for 1-37ZF83M - QXe_Not able to add more than 16 Pens in a group begin 
		//This should be derived from V6Config.h #define SCREEN_CANNEDPENS_SIZE  32 ///< Length of CannedPens - Pen config for canned screens
		//right now not changing here much since modified the const definition according to V6Config.h SCREEN_CANNEDPENS_SIZE
		//No more conditional checks so return directly
		/*if ( pDALGLB->IsRecorderMulti())
		 return MAX_PENS_IN_GROUP_MULTI;
		 else if( pDALGLB->IsRecorderMini() || pDALGLB->IsRecorderEzTrend() )
		 return MAX_PENS_IN_GROUP_MINI;
		 */
		//PSR fix for 1-37ZF83M - QXe_Not able to add more than 16 Pens in a group end 
		return MAX_PENS_IN_GROUP_MULTI;
	}
	T_PENMANAGER_RETURN ProcessRealTimeData();
	void SetRealTimeData(BOOL bIsRealTimeData, int clientId, RLOGCONFIGSTRUCT *rLogConfigStruct);
	BOOL IsRealTimeData();
	RTDATASTRUCTMAP GetRealTimeData();
	T_PENMANAGER_RETURN AddRealTimeData(int penCount, int subscribe, int clientId);
	void SetSocketConnected(int clientId, BOOL bIsSocketConnected);
	BOOL IsRTConfigExist();
	void SetFreeRTDataStruct(int clientId);
	HANDLE GetRTDataEventHandle(int clientId) {
		return m_hRealTimeDataEvent[clientId];
	}
	void ClearRateConfigList(int clientId);
	BOOL IsConnectionAlive(int clientId);
	int GetNoEnabledPens() {
		return m_EnabledPens.GetNumberOfPens();
	}
	int GetNoAvailablePens() {
		return m_AvailablePens.GetNumberOfPens();
	}
	int GetNoLoggingPens() {
		return m_LoggingPens.GetNumberOfPens();
	}
	BOOL IsSocketConnectionExist();
	//**********************************************************************
	/// Function to calculate the queue index for the specified pen instance, speed and chart type
	/// 
	/// @param[in] penInstanceNo - The pen instance number
	/// @param[in] chartSpeed - indicates the chart speed
	///
	/// @return		The queue index 
	/// 
	//**********************************************************************
	const int GetChartQueueIndex(int penInstanceNo, T_PENQ_INFO_INDEXES chartSpeedIndex) {
		return (penInstanceNo * NO_OF_PENQS) + chartSpeedIndex;
	}
	//**********************************************************************
	/// Function to calculate the queue index for the fast strip chart pen instance
	/// 
	/// @param[in] penInstanceNo - The pen instance number
	///
	/// @return		The queue index 
	/// 
	//**********************************************************************
	const int GetFastStripQueueIndex(int penInstanceNo) {
		return GetChartQueueIndex(penInstanceNo, STRIP_PENQ_FAST);
	}
	//**********************************************************************
	/// Function to calculate the queue index for the medium strip chart pen instance
	/// 
	/// @param[in] penInstanceNo - The pen instance number
	///
	/// @return		The queue index 
	/// 
	//**********************************************************************
	const int GetMedStripQueueIndex(int penInstanceNo) {
		return GetChartQueueIndex(penInstanceNo, STRIP_PENQ_MED);
	}
	//**********************************************************************
	/// Function to calculate the queue index for the slow strip chart pen instance
	/// 
	/// @param[in] penInstanceNo - The pen instance number
	///
	/// @return		The queue index 
	/// 
	//**********************************************************************
	const int GetSlowStripQueueIndex(int penInstanceNo) {
		return GetChartQueueIndex(penInstanceNo, STRIP_PENQ_SLOW);
	}
	//**********************************************************************
	/// Function to calculate the queue index for the fast circular chart pen instance
	/// 
	/// @param[in] penInstanceNo - The pen instance number
	///
	/// @return		The queue index 
	/// 
	//**********************************************************************
	const int GetFastCircularQueueIndex(int penInstanceNo) {
		return GetChartQueueIndex(penInstanceNo, CIRC_PENQ_FAST);
	}
	//**********************************************************************
	/// Function to calculate the queue index for the medium circular chart pen instance
	/// 
	/// @param[in] penInstanceNo - The pen instance number
	///
	/// @return		The queue index 
	/// 
	//**********************************************************************
	const int GetMedCircularQueueIndex(int penInstanceNo) {
		return GetChartQueueIndex(penInstanceNo, CIRC_PENQ_MED);
	}
	//**********************************************************************
	/// Function to calculate the queue index for the slow circular chart pen instance
	/// 
	/// @param[in] penInstanceNo - The pen instance number
	///
	/// @return		The queue index 
	/// 
	//**********************************************************************
	const int GetSlowCircularQueueIndex(int penInstanceNo) {
		return GetChartQueueIndex(penInstanceNo, CIRC_PENQ_SLOW);
	}
private:	// Methods
	void GenerateAvailablePenList();
	void GenerateWorkingLists();
	void ResetWorkingLists();
private:	// Member variables
	CPenControl m_Pen[V6_MAX_PENS];		///< Pen control, one per pen.
	CPenList m_AvailablePens;			///< List of all pens that are available enabled or disabled, index into m_pen
	CPenList m_EnabledPens;				///< List of all pens that are enabled, index into m_pen
	CPenList m_LoggingPens;				///< List of all pens that are enabled for logging
	CPenList m_TotalisingPens;			///< List of all pens that are enabled for totalising
	CPenList m_AlarmPens;				///< List of all pens that have at least 1 enabled alarm
	CPenList m_PreTriggerPens;			///< List of all pens that are configured for Pre trigger
	CPenList m_GroupPens[PEN_GROUP_MAX];			///< List of pens contained within each group, 0 = all pens
	CAlarmList m_EnabledAlarms;			///< List of Alarms that are enabled
	CAlarmList m_DIEnabledAlarms;		///< List of Alarms that are enabled by DI
	CAlarmList m_PreTriggerAlarms;		///< List of Alarms that will caused a pre trigger event
	BOOL m_Initialised;					///< Indicates if the PenManager has been initialised
	USHORT m_fastestPenRate;			///< rate of fastest pen
	BOOL m_LogChannelActionPending;	///< Indication when a log channel action has been completed
	QMutex m_UIActionsCS;	///< UI Action Critical section, protect when resetting MaxMins, Totals and Alarms Acks
	QMutex m_LoggingCS;		///< UI Action Critical section, protect when starting and stopping logging
	QMutex m_RTDataCS;  ///< Real Time Data Critical Section
	// Report information
	T_REPORT_DATA *m_pNVReportData;		///< Pointer to report structure in NV
	BOOL m_IsNewHour;				///< is this start of new hour
	BOOL m_IsNewDay;					///< is this a start of new day?
	BOOL m_IsNewWeekDay;				///< is this start of new week
	BOOL m_IsNewMonth;				///< is this start of new month
	BOOL m_ReportResetRequest;		///< Report reset has been requested - reset all report Tots, ave max and mins
	// Pre-trigger Information
	int m_totalPreTriggerAlarmsActive;		///< Total number of pre-trigger alarms that are currently active
	BOOL m_preTriggerFirstIn;				///< Pre trigger first in check flag
	CNVBasicVar *m_pNVStatus;				///< Pre trigger status held in NV
	COMBO_VAR4 m_preTriggerStatus;			///< Pre trigger status
	QString m_preTriggerTextStatus;			///< Text status of pre-trigger
	// Post Trigger Information
	int m_postTriggerTime;					///< Time in seconds for post trigger to run, 0 = disabled
	BOOL m_postTriggerTimerActive;			///< Post trigger timer active
	LONGLONG m_postTriggerEndTime;			///< End time of calculated post trigger
	BOOL m_bRealTimeData;  ///< Flag to indicate if realtime data is to be processed
	RTDATASTRUCT m_rtDataStruct[5];
	int m_clientId;
	//List containing information for pens
	RTDATASTRUCTLIST m_rtDataStructList[5];
	CLogRateControl *m_LogRateControl;
	MAP_RLOGCONFIG mapRlogConfig;
	RLOGCONFIGSTRUCT *m_pLogConfigStruct;
	BOOL m_bIsFree;
	LOGRATEMAP m_logRateMap;
	LOGCONFIGMAP m_logConfigMap;
	RTDATASTRUCTMAP m_rtDataStructMap;
	HANDLE m_hRealTimeDataEvent[5];
	BOOL m_bIsUpdate[5];
	QAbstractSocket_CONN_VEC m_socketConnVec;
};
#endif //__PENMANAGER_H__

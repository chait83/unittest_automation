/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Processing
/// @n Filename: MaxMins.h
/// @n Desc:	 Manage Max and Min for a data reading
///				 
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  5 Stability Project 1.2.1.1 7/2/2011 4:58:36 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  4 Stability Project 1.2.1.0 7/1/2011 4:27:40 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  3 V6 Firmware 1.2 3/17/2006 4:50:06 PM  Andy Kassell  Set
//  max min to normal status
//  2 V6 Firmware 1.1 11/9/2005 9:38:59 PM  Andy Kassell  Add
//  accessor for pending mode request
// $
//
// ****************************************************************
#ifndef __MAXMINS_H__
#define __MAXMINS_H__
#include "V6defines.h"
#include "V6globals.h"
#include "V6Config.h"
#include "float.h"
/// Max min types
typedef enum {
	MM_TYPE_SIMPLE = 0,					///< Simple Max Min, no time storage or NV
	MM_TYPE_WITH_TIME,					///< Max min keeps track of time of Max & Min
	MM_TYPE_WITH_TIME_AND_NV			///< Man min keeps track of time and is non-volatile					
} T_MAXMIN_TYPES;
// Max min mode requests
typedef enum {
	MM_MODE_NORMAL = 0,						///< Mode unchanged from last itteration (when being used as action)
	MM_MODE_RESET_MAX,						///< Request to reset the Max value
	MM_MODE_RESET_MIN,						///< Request To Rest the Min Value
	MM_MODE_RESET_BOTH,						///< Request to Rest both
} T_MAXMIN_MODE;
///MaxMin routine return types
typedef enum {
	MM_OKAY = 0,							///< MaxMin method performed ok
	MM_INIT_FAILED,						///< Max Min initialisation failed						
} T_MAXMIN_RETURN;
//**Class*********************************************************************
///
/// @brief Max Min processor
/// 
/// Process a max min value 
///
//****************************************************************************
class CMaxMin {
public:
	CMaxMin();
public:		// API methods
	T_MAXMIN_RETURN IntialiseMaxMin(USHORT penNumber);	// Initialise Max and Mon for a Pen
	T_MAXMIN_RETURN SetMaxMinFromConfig(T_PPEN pPenCfg);	// Process configuration changes for a max min
	void DoMaxMin();										// Perform Max & Min processing
	void RequestAction(T_MAXMIN_MODE mode) {
		m_requestMode = mode;
	}
	; // Reset resets of max/min or both
	T_MAXMIN_MODE GetPendingRequest() {
		return m_requestMode;
	}
	;
	void DoAverage(float value);
private:	// Methods
	void ResetMax();										// Reset the max value and time
	void ResetMin();										// Reset the min value and time
	void ResetBoth() {
		ResetMax();
		ResetMin();
	}
	void ProcessRequestAction();
private:	// Member variables
	USHORT m_penNumber;						// Pen related to this max & min
	CDataItemPen *m_pPenDataItem;	// Pointer to Pen Data Item
	CDataItemMaxMinAve *m_pMaxDataItem;	// Pointer to Data item for Max
	CDataItemMaxMinAve *m_pMinDataItem;	// Pointer to Data item for Min
	CNVBasicTimeVar *m_pMaxNV;				// Pointer to NV for Max
	CNVBasicTimeVar *m_pMinNV;				// Pointer to NV for Min
	T_BASIC_WITH_TIME m_Max;				// RunTime Max 
	T_BASIC_WITH_TIME m_Min;				// RunTime Min
	T_MAXMIN_MODE m_requestMode;			// Requested Mode
	T_PPEN m_pPenCfg;						// Ponter to Pen configuration in CMM
	CDataItemMaxMinAve *m_pAvgDataItem;  // Pointer to Data item for Average 
};
#endif //__MAXMINS_H__

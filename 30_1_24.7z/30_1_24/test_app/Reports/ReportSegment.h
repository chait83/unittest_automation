/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Reports System UI
/// @n Filename: ReportSegment.h
/// @n Desc:	 Definition of the CReportSegment class
///				 
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  4 Stability Project 1.1.1.1 7/2/2011 5:00:25 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  3 Stability Project 1.1.1.0 7/1/2011 4:25:21 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  2 V6 Firmware 1.1 4/10/2007 5:33:30 PM  Roger Dawson  
//  changes to allow the printing of reports from the recorder.
//  1 V6 Firmware 1.0 4/4/2007 5:29:13 PM Roger Dawson  
// $
//
// ****************************************************************
#if !defined(AFX_REPORTSEGMENT_H__142C94C5_BD6D_4792_AFC2_D6D86DE85E81__INCLUDED_)
#define AFX_REPORTSEGMENT_H__142C94C5_BD6D_4792_AFC2_D6D86DE85E81__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "Print.h"
//**CReportDoc***********************************************************
///
/// @brief Class used to store the report data in easy to handle segments
/// 
/// Class used to store the report data in easy to handle segments
///
//**********************************************************************
class CReportSegment {
public:
	// Constructor
	CReportSegment();
	// Copy Constructor
	CReportSegment(const CReportSegment &rkREPORT_SEGMENT);
	// Destructor
	virtual ~CReportSegment();
	// Equals operator
	void operator=(const CReportSegment &rkREPORT_SEGMENT);
	/// Enum used to indicate if the segment is a table row or a paragraph
	enum T_REPORT_SEGMENT_TYPE {
		rstPARAGRAPH, rstTABLE
	};
	// Method that sets up the segment information and strips the data out of the passed in string
	void InitSegment(QString &rstrReportData);
	// Method that sets the number of lines the segment data will occupy based
	// on the passed in page/character parameters
	void SetNoOfLines(CDC *pDC, const int iPAGE_WIDTH, const int iCHAR_HEIGHT, const ULONG ulSTART_LINE_NO);
	// Accessor for the number of line variable
	const ULONG GetNoOfLines() const {
		return m_ulNoOfLines;
	}
	// Accessor for the start line number
	const ULONG GetStartLineNo() const {
		return m_ulStartLineNo;
	}
	// Accessor for the segment type
	const bool IsParagraph() const {
		return (m_eSegmentType == rstPARAGRAPH);
	}
	// Method that draws the segment information on the screen
	const ULONG DrawSegment(CDC *pDC, QRect &tClipRect, const int iCHAR_HEIGHT, const ULONG ulFIRST_VIEWABLE_LINE,
			const ULONG ulCURR_LINE, const ULONG ulLAST_VIEWABLE_LINE);
#ifdef PRINT_CE
	void SetNoOfLines(	CPrintCEWrapper* pCEWrapper, 
						const int iPAGE_WIDTH, 
						const int iCHAR_HEIGHT,
						const ULONG ulSTART_LINE_NO );
	const ULONG DrawSegment(	CPrintCEWrapper* pCEWrapper, 
								QRect &tClipRect, 
								const int iCHAR_HEIGHT,
								const ULONG ulFIRST_VIEWABLE_LINE,
								const ULONG ulCURR_LINE,
								const ULONG ulLAST_VIEWABLE_LINE );
#endif
private:
	/// The block of data - this could either be a paragraph of normal
	/// test or a delimitted list of table data
	QString m_strReportBlock;
	/// Variable representing the number of lines that this block of data will require
	ULONG m_ulNoOfLines;
	/// Variable indicating the report segment type
	T_REPORT_SEGMENT_TYPE m_eSegmentType;
	// The number of rows the table has
	int m_iNoOfRows;
	// The number of cells per line
	int m_iNoOfCellsPerLine;
	// the start line number for this segment
	ULONG m_ulStartLineNo;
	// Method used to extract the row text
	const bool GetRowText(int &riStartOfRowPos, int &riEndOfRowPos, QString &rstrCurrRow);
	// Method that draws the paragraph information on the screen
	const ULONG DrawParagraph(CDC *pDC, QRect &rtClipRect, const int iCHAR_HEIGHT, const ULONG ulFIRST_VIEWABLE_LINE,
			const ULONG ulCURR_LINE, const ULONG ulLAST_VIEWABLE_LINE);
	// Method that draws the table information on the screen
	const ULONG DrawTable(CDC *pDC, QRect &rtClipRect, const int iCHAR_HEIGHT, const ULONG ulFIRST_VIEWABLE_LINE,
			const ULONG ulCURR_LINE, const ULONG ulLAST_VIEWABLE_LINE);
	// Method that draws the row information on the screen
	const ULONG DrawRow(CDC *pDC, QRect &rtClipRect, const int iCHAR_HEIGHT, const ULONG ulFIRST_VIEWABLE_LINE,
			const ULONG ulCURR_LINE, const ULONG ulLAST_VIEWABLE_LINE, const QString &rstrCURR_ROW);
#ifdef PRINT_CE
	const ULONG DrawParagraph(	CPrintCEWrapper* pCEWrapper, 
								QRect &rtClipRect,
								const int iCHAR_HEIGHT,
								const ULONG ulFIRST_VIEWABLE_LINE,
								const ULONG ulCURR_LINE,
								const ULONG ulLAST_VIEWABLE_LINE );
	const ULONG DrawTable(	CPrintCEWrapper* pCEWrapper, 
							QRect &rtClipRect,
							const int iCHAR_HEIGHT,
							const ULONG ulFIRST_VIEWABLE_LINE,
							const ULONG ulCURR_LINE,
							const ULONG ulLAST_VIEWABLE_LINE );
	const ULONG DrawRow(	CPrintCEWrapper* pCEWrapper, 
							QRect &rtClipRect,
							const int iCHAR_HEIGHT,
							const ULONG ulFIRST_VIEWABLE_LINE,
							const ULONG ulCURR_LINE,
							const ULONG ulLAST_VIEWABLE_LINE,
							const QString &rstrCURR_ROW );
#endif
};
#endif // !defined(AFX_REPORTSEGMENT_H__142C94C5_BD6D_4792_AFC2_D6D86DE85E81__INCLUDED_)

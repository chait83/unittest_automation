#include "RTFErrors.h"
#include "RTFGlobals.h"
#include "rtflib.h"
#include "StringUtils.h"
RTF_DOCUMENT_FORMAT rtfDocasprintf;					// RTF document formatting params
RTF_SECTION_FORMAT rtfSecasprintf;					// RTF section formatting params
RTF_PARAGRAPH_FORMAT rtfParasprintf;					// RTF paragraph formatting params
RTF_TABLEROW_FORMAT rtfRowasprintf;					// RTF table row formatting params
RTF_TABLECELL_FORMAT rtfCellasprintf;					// RTF table cell formatting params
// RTF library global params
QString rtfFontTable = "";
QString rtfColorTable = "";
IPicture *rtfPicture = NULL;
const int CRTFLib::ms_iMAX_CELL_WIDTH = 9000;
//****************************************************************************
// CRTFLib( const bool bLETTER_PAGE_SIZE )
///
/// Constructor - Use me when writing RTF files as I set the correct paper size
///
/// @param[in]		const bool bLETTER_PAGE_SIZE - Flag indicating the page is is letter (true)
///					or A4 (false)
///
//****************************************************************************
CRTFLib::CRTFLib(const bool bLETTER_PAGE_SIZE) : CRecorderStorage(), m_ulMAX_READ_BUFF_LEN(0xFFFF), m_bLetterPageSize(
		bLETTER_PAGE_SIZE), m_iA4_WIDTH_IN_TWIPS(11907), m_iA4_HEIGHT_IN_TWIPS(16840), m_iLETTER_WIDTH_IN_TWIPS(12240), m_iLETTER_HEIGHT_IN_TWIPS(
		15840) {
	rtfColorTable = "";
	rtfFontTable = "";
}
//****************************************************************************
// CRTFLib( )
///
/// Default Constructor
///
//****************************************************************************
CRTFLib::CRTFLib() : CRecorderStorage(), m_ulMAX_READ_BUFF_LEN(0xFFFF), m_bLetterPageSize(false), m_iA4_WIDTH_IN_TWIPS(
		11907), m_iA4_HEIGHT_IN_TWIPS(16840), m_iLETTER_WIDTH_IN_TWIPS(12240), m_iLETTER_HEIGHT_IN_TWIPS(15840) {
}
// Creates new RTF document
int CRTFLib::rtf_open(const QString &rstrFILENAME, const QString &rstrFONTS, const QString &rstrCOLOURS) {
	// Set error flag
	int error = RTF_SUCCESS;
	// Initialize global params
	rtf_init();
	// Set RTF document font table
	if (rstrFONTS != (""))
		rtf_set_fonttable(rstrFONTS);
	// Set RTF document color table
	if (rstrCOLOURS != "")
		rtf_set_colortable(rstrCOLOURS);
	// Create RTF document
	;
	if (Open(rstrFILENAME, QFile::WriteOnly)) {
		// Write RTF document header
		if (!rtf_write_header())
			error = RTF_HEADER_ERROR;
		// Write RTF document formatting properties
		if (!rtf_write_documentformat())
			error = RTF_DOCUMENTFORMAT_ERROR;
		// Create first RTF document section with default formatting
		rtf_write_sectionformat();
	} else
		error = RTF_OPEN_ERROR;
	// Return error flag
	return error;
}
// Closes created RTF document
int CRTFLib::rtf_close() {
	// Set error flag
	int error = RTF_SUCCESS;
	// Write RTF document end part
	WCHAR rtfText[1024];
    wcscpy(rtfText, L"\n/par}");
	tempwrite(QString::fromWCharArray(rtfText));
	WriteBuffer();
	// Free IPicture object
	if (rtfPicture != NULL) {
		rtfPicture->Release();
		rtfPicture = NULL;
	}
	// Close RTF document
	Close();
	//	error = RTF_CLOSE_ERROR;
	// Return error flag
	return error;
}
BOOL CRTFLib::WriteBuffer() {
	size_t pNoOfChars;
	QString strConvertedData = ConvertUnicode(m_strBUFFER);
	char *ptNewBuff = new char[strConvertedData.size() + 50];
	wcstombs_s(&pNoOfChars, ptNewBuff, strConvertedData.size() + 50, strConvertedData.toLocal8Bit().data(),
			strConvertedData.size() + 50);
	Write(ptNewBuff, static_cast<UINT>(strlen(ptNewBuff)));
	delete[] ptNewBuff;
	return TRUE;
}
// Writes RTF document header
bool CRTFLib::rtf_write_header() {
	// Set error flag
	bool result = true;
	// Standard RTF document header
	QString rtfText;
	rtfText = "{/rtf1/ansi/ansicpg1252/deff0{/fonttb";
	rtfText += rtfFontTable;
	rtfText += "}{/colortb";
	rtfText += rtfColorTable;
	rtfText += "}{/*/generator HonRTF ver. 1.0;}";
	rtfText += "\n{/info{/author HonRTF ver. 1.0}{/company Honeywell.}}";
	// Writes standard RTF document header part
	//if ( fwrite( rtfText, 1, strlen(rtfText), rtfFile ) < strlen(rtfText) )
	tempwrite(rtfText);
	//result = false;
	// Return error flag
	return result;
}
// Sets global RTF library params
void CRTFLib::rtf_init() {
	// Set RTF document default font table
	rtfFontTable = "";
	rtfFontTable += "{/f0/froman/fcharset0/cpg1252 Times New Roman}";
	rtfFontTable += "{/f1/fswiss/fcharset0/cpg1252 Arial}";
	rtfFontTable += "{/f2/fmodern/fcharset0/cpg1252 Courier New}";
	rtfFontTable += "{/f3/fscript/fcharset0/cpg1252 Cursive}";
	rtfFontTable += "{/f4/fdecor/fcharset0/cpg1252 Old English}";
	rtfFontTable += "{/f5/ftech/fcharset0/cpg1252 Symbol}";
	rtfFontTable += "{/f6/fbidi/fcharset0/cpg1252 Miriam}";
	// Set RTF document default color table
	rtfColorTable = "";
	rtfColorTable += "/red0/green0/blue0;";
	rtfColorTable += "/red255/green0/blue0;";
	rtfColorTable += "/red0/green255/blue0;";
	rtfColorTable += "/red0/green0/blue255;";
	rtfColorTable += "/red255/green255/blue0;";
	rtfColorTable += "/red255/green0/blue255;";
	rtfColorTable += "/red0/green255/blue255;";
	rtfColorTable += "/red255/green255/blue255;";
	rtfColorTable += "/red128/green0/blue0;";
	rtfColorTable += "/red0/green128/blue0;";
	rtfColorTable += "/red0/green0/blue128;";
	rtfColorTable += "/red128/green128/blue0;";
	rtfColorTable += "/red128/green0/blue128;";
	rtfColorTable += "/red0/green128/blue128;";
	rtfColorTable += "/red128/green128/blue128;";
	// Set default formatting
	rtf_set_defaultformat();
}
// Sets default RTF document formatting
void CRTFLib::rtf_set_defaultformat() {
	// Set default RTF document formatting properties
	RTF_DOCUMENT_FORMAT df = { RTF_DOCUMENTVIEWKIND_PAGE, 100, 12240, 15840, 1800, 1800, 1440, 1440, false, 0, false };
	// Set default RTF section formatting properties
	RTF_SECTION_FORMAT sf = { RTF_SECTIONBREAK_CONTINUOUS, false, true, 12240, 15840, 1800, 1800, 1440, 1440, 0, 720,
			720, false, 720, 720, false, 1, 720, false };
	// check if letter or A4
	if (m_bLetterPageSize) {
		df.paperWidth = 12240;
		df.paperHeight = 15840;
		sf.pageWidth = 12240;
		sf.pageHeight = 15840;
	} else {
		df.paperWidth = 11907;
		df.paperHeight = 16840;
		sf.pageWidth = 11907;
		sf.pageHeight = 16840;
	}
	rtf_set_documentformat(&df);
	rtf_set_sectionformat(&sf);
	// Set default RTF paragraph formatting properties
	//RTF_PARAGRAPH_FORMAT pf = {RTF_PARAGRAPHBREAK_NONE, false, true, RTF_PARAGRAPHALIGN_LEFT, 0, 0, 0, 0, 0, 0, QString ::fromWCharArray(""), false, false, false, false, false, false};
	RTF_PARAGRAPH_FORMAT pf;
	pf.paragraphBreak = RTF_PARAGRAPHBREAK_NONE;
	pf.newParagraph = false;
	pf.newHeader = false;
	pf.newFooter = false;
	pf.defaultParagraph = true;
	pf.paragraphAligment = RTF_PARAGRAPHALIGN_LEFT;
	pf.firstLineIndent = 0;
	pf.leftIndent = 0;
	pf.rightIndent = 0;
	pf.spaceBefore = 0;
	pf.spaceAfter = 0;
	pf.lineSpacing = 0;
	pf.paragraphText = "";
	pf.tabbedText = false;
	pf.tableText = false;
	pf.bInsertPageNo = false;
	pf.paragraphTabs = false;
	pf.paragraphNums = false;
	pf.paragraphBorders = false;
	pf.paragraphShading = false;
	pf.BORDERS.borderColor = 0;
	pf.BORDERS.borderKind = RTF_PARAGRAPHBORDERKIND_NONE;
	pf.BORDERS.borderSpace = 0;
	pf.BORDERS.borderType = RTF_PARAGRAPHBORDERTYPE_STHICK;
	pf.BORDERS.borderWidth = 0;
	pf.CHARACTER.animatedCharacter = false;
	pf.CHARACTER.backgroundColor = 0;
	pf.CHARACTER.boldCharacter = false;
	pf.CHARACTER.capitalCharacter = false;
	pf.CHARACTER.doublestrikeCharacter = false;
	pf.CHARACTER.embossCharacter = false;
	pf.CHARACTER.engraveCharacter = false;
	pf.CHARACTER.expandCharacter = 0;
	pf.CHARACTER.fontNumber = 0;
	pf.CHARACTER.fontSize = 20;
	pf.CHARACTER.foregroundColor = 0;
	pf.CHARACTER.italicCharacter = false;
	pf.CHARACTER.kerningCharacter = 0;
	pf.CHARACTER.outlineCharacter = false;
	pf.CHARACTER.scaleCharacter = 100;
	pf.CHARACTER.shadowCharacter = false;
	pf.CHARACTER.smallcapitalCharacter = false;
	pf.CHARACTER.strikeCharacter = false;
	pf.CHARACTER.subscriptCharacter = false;
	pf.CHARACTER.superscriptCharacter = false;
	pf.CHARACTER.underlineCharacter = 0;
	pf.NUMS.numsChar = WCHAR(0x95);
	pf.NUMS.numsLevel = 11;
	pf.NUMS.numsSpace = 360;
	pf.SHADING.shadingBkColor = 0;
	pf.SHADING.shadingFillColor = 0;
	pf.SHADING.shadingIntensity = 0;
	pf.SHADING.shadingType = RTF_PARAGRAPHSHADINGTYPE_FILL;
	pf.TABS.tabKind = RTF_PARAGRAPHTABKIND_NONE;
	pf.TABS.tabLead = RTF_PARAGRAPHTABLEAD_NONE;
	pf.TABS.tabPosition = 0;
	rtf_set_paragraphformat(&pf);
	// Set default RTF table row formatting properties
	RTF_TABLEROW_FORMAT rf = { RTF_ROWTEXTALIGN_LEFT, 0, 0, 0, 0, 0, 0 };
	rtf_set_tablerowformat(&rf);
	// Set default RTF table cell formatting properties
	RTF_TABLECELL_FORMAT cf = { RTF_CELLTEXTALIGN_CENTER, 0, 0, 0, 0, RTF_CELLTEXTDIRECTION_LRTB, false };
	cf.SHADING.shadingBkColor = 0;
	cf.SHADING.shadingFillColor = 0;
	cf.SHADING.shadingIntensity = 0;
	cf.SHADING.shadingType = RTF_PARAGRAPHSHADINGTYPE_FILL;
	cf.borderBottom.border = false;
	cf.borderBottom.BORDERS.borderColor = 0;
	cf.borderBottom.BORDERS.borderKind = RTF_PARAGRAPHBORDERKIND_NONE;
	cf.borderBottom.BORDERS.borderSpace = 0;
	cf.borderBottom.BORDERS.borderType = RTF_PARAGRAPHBORDERTYPE_STHICK;
	cf.borderBottom.BORDERS.borderWidth = 5;
	cf.borderleft.border = false;
	cf.borderleft.BORDERS.borderColor = 0;
	cf.borderleft.BORDERS.borderKind = RTF_PARAGRAPHBORDERKIND_NONE;
	cf.borderleft.BORDERS.borderSpace = 0;
	cf.borderleft.BORDERS.borderType = RTF_PARAGRAPHBORDERTYPE_STHICK;
	cf.borderleft.BORDERS.borderWidth = 5;
	cf.borderright.border = false;
	cf.borderright.BORDERS.borderColor = 0;
	cf.borderright.BORDERS.borderKind = RTF_PARAGRAPHBORDERKIND_NONE;
	cf.borderright.BORDERS.borderSpace = 0;
	cf.borderright.BORDERS.borderType = RTF_PARAGRAPHBORDERTYPE_STHICK;
	cf.borderright.BORDERS.borderWidth = 5;
	cf.borderTop.border = false;
	cf.borderTop.BORDERS.borderColor = 0;
	cf.borderTop.BORDERS.borderKind = RTF_PARAGRAPHBORDERKIND_NONE;
	cf.borderTop.BORDERS.borderSpace = 0;
	cf.borderTop.BORDERS.borderType = RTF_PARAGRAPHBORDERTYPE_STHICK;
	cf.borderTop.BORDERS.borderWidth = 5;
	rtf_set_tablecellformat(&cf);
}
// Sets new RTF document font table
void CRTFLib::rtf_set_fonttable(const QString &rstrFONTS) {
	// Clear old font table
	rtfFontTable = "";
	// Set separator list
	//WCHAR separator[] = ";";
	// Create new RTF document font table
	int font_number = 0;
	/*QString  token = strtok( rstrFONTS.GetBuffer( ), separator );
	 while ( token != NULL )
	 {
	 // asprintf font table entry
	 swprintf( font_table_entry, "{/f%d/fnil/fWCHARset0/cpg1252 %s}", font_number, token );
	 wcscat( rtfFontTable, font_table_entry );
	 // Get next font
	 token = strtok( NULL, separator );
	 font_number++;
	 }*/
	int iDelimPos = 0;
	QString strFonts(rstrFONTS);
	QString strFontTables = "";
	QString strFontTable = "";
	while ((iDelimPos = strFonts.indexOf(L';')) != -1) {
		strFontTable = QString::asprintf("{/f%d/fnil/fcharset0/cpg1252 %s}", font_number, strFonts.left(iDelimPos));
		strFontTables += strFontTable;
		strFonts.remove(0, iDelimPos + 1);
		font_number++;
	}
	rtfFontTable = strFontTables;
}
// Sets new RTF document color table
void CRTFLib::rtf_set_colortable(const QString &rstrCOLOURS) {
	// Clear old color table
	rtfColorTable = "";
	// Set separator list
	WCHAR separator[] = L";";
	// Create new RTF document color table
	int color_number = 0;
	int iDelimPos = 0;
	QString strColours(rstrCOLOURS);
	QString strColourTables = "";
	QString strColourTable = "";
	while ((iDelimPos = strColours.indexOf(L';')) != -1) {
		// Red
        strColourTable = "/red%s"+ strColours.left(iDelimPos);
		strColourTables += strColourTable;
		strColours.remove(0, iDelimPos + 1);
		// Green
		iDelimPos = strColours.indexOf(L';');
		if (iDelimPos != -1) {
            strColourTable = "/green%s" + strColours.left(iDelimPos);
			strColourTables += strColourTable;
			strColours.remove(0, iDelimPos + 1);
		}
		// Blue
		iDelimPos = strColours.indexOf(L';');
		if (iDelimPos != -1) {
            strColourTable = "/blue%s;"+ strColours.left(iDelimPos);
			strColourTables += strColourTable;
			strColours.remove(0, iDelimPos + 1);
		}
		color_number++;
	}
	rtfColorTable = strColourTables;
	//wcscolor_table_entry, strColourTables.toLocal8Bit().data() );
	//wcstombs( color_table_entry, wcscolor_table_entry, 1024 );
	/*
	 QString  token = strtok( rstrCOLOURS.toLocal8Bit().data(), separator );
	 while ( token != NULL )
	 {
	 // Red
	 sprintf( color_table_entry, "/red%s", token );
	 wcscat( rtfColorTable, color_table_entry );
	 // Green
	 token = strtok( NULL, separator );
	 if ( token != NULL )
	 {
	 sprintf( color_table_entry, "/green%s", token );
	 wcscat( rtfColorTable, color_table_entry );
	 }
	 // Blue
	 token = strtok( NULL, separator );
	 if ( token != NULL )
	 {
	 sprintf( color_table_entry, "/blue%s;", token );
	 wcscat( rtfColorTable, color_table_entry );
	 }
	 // Get next color
	 token = strtok( NULL, separator );
	 color_number++;
	 }*/
}
// Sets RTF document formatting properties
void CRTFLib::rtf_set_documentformat(RTF_DOCUMENT_FORMAT *df) {
	// Set new RTF document formatting properties
	memcpy(&rtfDocasprintf, df, sizeof(RTF_DOCUMENT_FORMAT));
}
// Writes RTF document formatting properties
bool CRTFLib::rtf_write_documentformat() {
	// Set error flag
	bool result = true;
	// RTF document text
	WCHAR rtfText[1024];
	wcscpy(rtfText, L"");
	swprintf(rtfText, 1024, L"/viewkind%d/viewscale%d/paperw%d/paperh%d/margl%d/margr%d/margt%d/margb%d/gutter%d",
			rtfDocasprintf.viewKind, rtfDocasprintf.viewScale, rtfDocasprintf.paperWidth, rtfDocasprintf.paperHeight,
			rtfDocasprintf.marginleft, rtfDocasprintf.marginright, rtfDocasprintf.marginTop,
			rtfDocasprintf.marginBottom, rtfDocasprintf.gutterWidth);
	if (rtfDocasprintf.facingPages)
		wcscat(rtfText, L"/facingp");
	if (rtfDocasprintf.readOnly)
		wcscat(rtfText, L"/annotprot");
	// Writes RTF document formatting properties
	tempwrite(QString::fromWCharArray(rtfText));
	//result = false;
	// Return error flag
	return result;
}
// Sets RTF section formatting properties
void CRTFLib::rtf_set_sectionformat(RTF_SECTION_FORMAT *sf) {
	// Set new RTF section formatting properties
	memcpy(&rtfSecasprintf, sf, sizeof(RTF_SECTION_FORMAT));
}
// Writes RTF section formatting properties
bool CRTFLib::rtf_write_sectionformat() {
	// Set error flag
	bool result = true;
	// RTF document text
	WCHAR rtfText[1024];
	wcscpy(rtfText, L"");
	// asprintf new section
	WCHAR text[1024] = L"", pgn[100] = L"";
	if (rtfSecasprintf.newSection)
		wcscat(text, L"/sect");
	if (rtfSecasprintf.defaultSection)
		wcscat(text, L"/sectd");
	if (rtfSecasprintf.showPageNumber) {
		swprintf(pgn, 100, L"/pgnx%d/pgny%d", rtfSecasprintf.pageNumberOffsetX, rtfSecasprintf.pageNumberOffsetY);
		wcscat(text, pgn);
	}
	// asprintf section break
	WCHAR sbr[100] = L"";
	switch (rtfSecasprintf.sectionBreak) {
	// Continuous break
	case RTF_SECTIONBREAK_CONTINUOUS:
		wcscat(sbr, L"/sbknone");
		break;
		// Column break
	case RTF_SECTIONBREAK_COLUMN:
		wcscat(sbr, L"/sbkco");
		break;
		// Page break
	case RTF_SECTIONBREAK_PAGE:
		wcscat(sbr, L"/sbkpage");
		break;
		// Even-page break
	case RTF_SECTIONBREAK_EVENPAGE:
		wcscat(sbr, L"/sbkeven");
		break;
		// Odd-page break
	case RTF_SECTIONBREAK_ODDPAGE:
		wcscat(sbr, L"/sbkodd");
		break;
	}
	// asprintf section columns
	WCHAR cols[100] = L"";
	if (rtfSecasprintf.cols == true) {
		// asprintf columns
		swprintf(cols, 100, L"/cols%d/colsx%d", rtfSecasprintf.colsNumber, rtfSecasprintf.colsDistance);
		if (rtfSecasprintf.colsLineBetween)
			wcscat(cols, L"/linebetco");
	}
	swprintf(rtfText, 1024,
			L"\n%s%s%s/pgwsxn%d/pghsxn%d/marglsxn%d/margrsxn%d/margtsxn%d/margbsxn%d/guttersxn%d/headery%d/footery%d",
			text, sbr, cols, rtfSecasprintf.pageWidth, rtfSecasprintf.pageHeight, rtfSecasprintf.pageMarginleft,
			rtfSecasprintf.pageMarginright, rtfSecasprintf.pageMarginTop, rtfSecasprintf.pageMarginBottom,
			rtfSecasprintf.pageGutterWidth, rtfSecasprintf.pageHeaderOffset, rtfSecasprintf.pageFooterOffset);
	// Writes RTF section formatting properties
	tempwrite(QString::fromWCharArray(rtfText));
	//		result = false;
	// Return error flag
	return result;
}
// Starts new RTF section
int CRTFLib::rtf_start_section() {
	// Set error flag
	int error = RTF_SUCCESS;
	// Set new section flag
	rtfSecasprintf.newSection = true;
	// Starts new RTF section
	if (!rtf_write_sectionformat())
		error = RTF_SECTIONFORMAT_ERROR;
	// Return error flag
	return error;
}
// Sets RTF paragraph formatting properties
void CRTFLib::rtf_set_paragraphformat(RTF_PARAGRAPH_FORMAT *pf) {
	// Set new RTF paragraph formatting properties
	memcpy(&rtfParasprintf, pf, sizeof(RTF_PARAGRAPH_FORMAT));
}
// Writes RTF paragraph formatting properties
bool CRTFLib::rtf_write_paragraphformat() {
	// Set error flag
	bool result = true;
	WCHAR temp[100];
	// RTF document text
	WCHAR rtfText[4096];
	wcscpy(rtfText, L"");
	// asprintf new paragraph
	WCHAR text[1024] = L"";
	if (rtfParasprintf.newHeader) {
		wcscat(text, L"{ /header");
	}
	if (rtfParasprintf.newFooter) {
		wcscat(text, L"{ /footer");
	}
	if (rtfParasprintf.newParagraph)
		wcscat(text, L"/par");
	if (rtfParasprintf.defaultParagraph)
		wcscat(text, L"/pard");
	if (rtfParasprintf.tableText == false)
		wcscat(text, L"/plain");
	else
		wcscat(text, L"/intb");
	switch (rtfParasprintf.paragraphBreak) {
	// No break
	case RTF_PARAGRAPHBREAK_NONE:
		break;
		// Page break;
	case RTF_PARAGRAPHBREAK_PAGE:
		wcscat(text, L"/page");
		break;
		// Column break;
	case RTF_PARAGRAPHBREAK_COLUMN:
		wcscat(text, L"/column");
		break;
		// Line break;
	case RTF_PARAGRAPHBREAK_LINE:
		wcscat(text, L"/line");
		break;
	}
	// asprintf aligment
	switch (rtfParasprintf.paragraphAligment) {
	// left aligned paragraph
	case RTF_PARAGRAPHALIGN_LEFT:
		wcscat(text, L"/q");
		break;
		// Center aligned paragraph
	case RTF_PARAGRAPHALIGN_CENTER:
		wcscat(text, L"/qc");
		break;
		// right aligned paragraph
	case RTF_PARAGRAPHALIGN_RIGHT:
		wcscat(text, L"/qr");
		break;
		// Justified aligned paragraph
	case RTF_PARAGRAPHALIGN_JUSTIFY:
		wcscat(text, L"/qj");
		break;
	}
	// asprintf tabs
	if (rtfParasprintf.paragraphTabs == true) {
		// Set tab kind
		switch (rtfParasprintf.TABS.tabKind) {
		// No tab
		case RTF_PARAGRAPHTABKIND_NONE:
			break;
			// Centered tab
		case RTF_PARAGRAPHTABKIND_CENTER:
			wcscat(text, L"/tqc");
			break;
			// Flush-right tab
		case RTF_PARAGRAPHTABKIND_RIGHT:
			wcscat(text, L"/tqr");
			break;
			// Decimal tab
		case RTF_PARAGRAPHTABKIND_DECIMAL:
			wcscat(text, L"/tqdec");
			break;
		}
		// Set tab leader
		switch (rtfParasprintf.TABS.tabLead) {
		// No lead
		case RTF_PARAGRAPHTABLEAD_NONE:
			break;
			// Leader dots
		case RTF_PARAGRAPHTABLEAD_DOT:
			wcscat(text, L"/tldot");
			break;
			// Leader middle dots
		case RTF_PARAGRAPHTABLEAD_MDOT:
			wcscat(text, L"/tlmdot");
			break;
			// Leader hyphens
		case RTF_PARAGRAPHTABLEAD_HYPH:
			wcscat(text, L"/tlhyph");
			break;
			// Leader underline
		case RTF_PARAGRAPHTABLEAD_UNDERLINE:
			wcscat(text, L"/tlu");
			break;
			// Leader thick line
		case RTF_PARAGRAPHTABLEAD_THICKLINE:
			wcscat(text, L"/tlth");
			break;
			// Leader equal sign
		case RTF_PARAGRAPHTABLEAD_EQUAL:
			wcscat(text, L"/tleq");
			break;
		}
		// Set tab position
		WCHAR tb[10];
		swprintf(tb, 10, L"/tx%d", rtfParasprintf.TABS.tabPosition);
		wcscat(text, tb);
	}
	// asprintf bullets and numbering
	if (rtfParasprintf.paragraphNums == true) {
		WCHAR nums[1024];
		swprintf(nums, "{/*/pn/pnlvl%d/pnsp%d/pntxtb %c}", rtfParasprintf.NUMS.numsLevel, rtfParasprintf.NUMS.numsSpace,
				rtfParasprintf.NUMS.numsChar);
		wcscat(text, nums);
	}
	// asprintf paragraph borders
	if (rtfParasprintf.paragraphBorders == true) {
		WCHAR border[1024] = L"";
		// asprintf paragraph border kind
		switch (rtfParasprintf.BORDERS.borderKind) {
		// No border
		case RTF_PARAGRAPHBORDERKIND_NONE:
			break;
			// Border top
		case RTF_PARAGRAPHBORDERKIND_TOP:
			wcscat(border, L"/brdrt");
			break;
			// Border bottom
		case RTF_PARAGRAPHBORDERKIND_BOTTOM:
			wcscat(border, L"/brdrb");
			break;
			// Border left
		case RTF_PARAGRAPHBORDERKIND_LEFT:
			wcscat(border, L"/brdr");
			break;
			// Border right
		case RTF_PARAGRAPHBORDERKIND_RIGHT:
			wcscat(border, L"/brdrr");
			break;
			// Border box
		case RTF_PARAGRAPHBORDERKIND_BOX:
			wcscat(border, L"/box");
			break;
		}
		// asprintf paragraph border type
		QString strBorder(rtf_get_bordername(rtfParasprintf.BORDERS.borderType));
		strBorder.toWCharArray(temp);
		wcscat(border, temp);
		// Set paragraph border width
		WCHAR brd[100];
		swprintf(brd, 100, L"/brdrw%d/brsp%d", rtfParasprintf.BORDERS.borderWidth, rtfParasprintf.BORDERS.borderSpace);
		wcscat(border, brd);
		wcscat(text, border);
		// Set paragraph border color
		WCHAR brdcol[100];
		swprintf(brdcol, 100, L"/brdrcf%d", rtfParasprintf.BORDERS.borderColor);
		wcscat(text, brdcol);
	}
	// asprintf paragraph shading
	if (rtfParasprintf.paragraphShading == true) {
		WCHAR shading[100];
		swprintf(shading, 100, L"/shading%d", rtfParasprintf.SHADING.shadingIntensity);
		// asprintf paragraph shading
		QString strShading = rtf_get_shadingname(rtfParasprintf.SHADING.shadingType, false);
		strShading.toWCharArray(temp);
		wcscat(text, temp);
		// Set paragraph shading color
		WCHAR shcol[100];
		swprintf(shcol, 100, L"/cfpat%d/cbpat%d", rtfParasprintf.SHADING.shadingFillColor,
				rtfParasprintf.SHADING.shadingBkColor);
		wcscat(text, shcol);
	}
	// asprintf paragraph font
	QString font = "";
	font = QString::asprintf("/animtext%d/expndtw%d/kerning%d/charscalex%d/f%d/fs%d/cf%d",
			rtfParasprintf.CHARACTER.animatedCharacter, rtfParasprintf.CHARACTER.expandCharacter,
			rtfParasprintf.CHARACTER.kerningCharacter, rtfParasprintf.CHARACTER.scaleCharacter,
			rtfParasprintf.CHARACTER.fontNumber, rtfParasprintf.CHARACTER.fontSize,
			rtfParasprintf.CHARACTER.foregroundColor);
	if (rtfParasprintf.CHARACTER.boldCharacter)
		font += "/b";
	else
		font += "/b0";
	if (rtfParasprintf.CHARACTER.capitalCharacter)
		font += "/caps";
	else
		font += "/caps0";
	if (rtfParasprintf.CHARACTER.doublestrikeCharacter)
		font += "/striked1";
	else
		font += "/striked0";
	if (rtfParasprintf.CHARACTER.embossCharacter)
		font += "/embo";
	if (rtfParasprintf.CHARACTER.engraveCharacter)
		font += "/impr";
	if (rtfParasprintf.CHARACTER.italicCharacter)
		font += "/i";
	else
		font += "/i0";
	if (rtfParasprintf.CHARACTER.outlineCharacter)
		font += "/out";
	else
		font += "/outl0";
	if (rtfParasprintf.CHARACTER.shadowCharacter)
		font += "/shad";
	else
		font += "/shad0";
	if (rtfParasprintf.CHARACTER.smallcapitalCharacter)
		font += "/scaps";
	else
		font += "/scaps0";
	if (rtfParasprintf.CHARACTER.strikeCharacter)
		font += "/strike";
	else
		font += "/strike0";
	if (rtfParasprintf.CHARACTER.subscriptCharacter)
		font += "/sub";
	if (rtfParasprintf.CHARACTER.superscriptCharacter)
		font += "/super";
	// check if we must insert the page number
	if (rtfParasprintf.bInsertPageNo == true) {
		font += "/chpgn";
	}
	switch (rtfParasprintf.CHARACTER.underlineCharacter) {
	// None underline
	case 0:
		font += "/ulnone";
		break;
		// Continuous underline
	case 1:
		font += "/u";
		break;
		// Dotted underline
	case 2:
		font += "/uld";
		break;
		// Dashed underline
	case 3:
		font += "/uldash";
		break;
		// Dash-dotted underline
	case 4:
		font += "/uldashd";
		break;
		// Dash-dot-dotted underline
	case 5:
		font += "/uldashdd";
		break;
		// Double underline
	case 6:
		font += "/uldb";
		break;
		// Heavy wave underline
	case 7:
		font += "/ulhwave";
		break;
		// Long dashed underline
	case 8:
		font += "/ulldash";
		break;
		// Thick underline
	case 9:
		font += "/ulth";
		break;
		// Thick dotted underline
	case 10:
		font += "/ulthd";
		break;
		// Thick dashed underline
	case 11:
		font += "/ulthdash";
		break;
		// Thick dash-dotted underline
	case 12:
		font += "/ulthdashd";
		break;
		// Thick dash-dot-dotted underline
	case 13:
		font += "/ulthdashdd";
		break;
		// Thick long dashed underline
	case 14:
		font += "/ulthldash";
		break;
		// Double wave underline
	case 15:
		font += "/ululdbwave";
		break;
		// Word underline
	case 16:
		font += "/ulw";
		break;
		// Wave underline
	case 17:
		font += "/ulwave";
		break;
	}
	WCHAR txt[20] = L"";
	// Set paragraph tabbed text
	if (rtfParasprintf.tabbedText == false) {
		swprintf(rtfText, "\n%s/fi%d/li%d/ri%d/sb%d/sa%d/sl%d%s %s", text, rtfParasprintf.firstLineIndent,
				rtfParasprintf.leftIndent, rtfParasprintf.rightIndent, rtfParasprintf.spaceBefore,
				rtfParasprintf.spaceAfter, rtfParasprintf.lineSpacing, font, rtfParasprintf.paragraphText);
	} else
		swprintf(rtfText, "/tab %s", rtfParasprintf.paragraphText);
	// Writes RTF paragraph formatting properties
	tempwrite(QString::fromWCharArray(rtfText));
	//		result = false;
	// Return error flag
	return result;
}
// Starts new RTF paragraph
int CRTFLib::rtf_start_paragraph(const QString &rstrTEXT, bool newPar) {
	// Set error flag
	int error = RTF_SUCCESS;
	// Copy paragraph text
	rtfParasprintf.paragraphText = rstrTEXT;	//new WCHAR[strlen(text)];
	//	wcscpy( rtfParasprintf.paragraphText, text );
	// Set new paragraph
	rtfParasprintf.newParagraph = newPar;
	// Starts new RTF paragraph
	if (!rtf_write_paragraphformat())
		error = RTF_PARAGRAPHFORMAT_ERROR;
	// Return error flag
	return error;
}
// Gets RTF document formatting properties
RTF_DOCUMENT_FORMAT* CRTFLib::rtf_get_documentformat() {
	// Get current RTF document formatting properties
	return &rtfDocasprintf;
}
// Gets RTF section formatting properties
RTF_SECTION_FORMAT* CRTFLib::rtf_get_sectionformat() {
	// Get current RTF section formatting properties
	return &rtfSecasprintf;
}
// Gets RTF paragraph formatting properties
RTF_PARAGRAPH_FORMAT* CRTFLib::rtf_get_paragraphformat() {
	// Get current RTF paragraph formatting properties
	return &rtfParasprintf;
}
// Loads image from file
int CRTFLib::rtf_load_image(QString image, int width, int height) {
	// Set error flag
	int error = RTF_SUCCESS;
	/*
	 // Free IPicture object
	 if ( rtfPicture != NULL )
	 {
	 rtfPicture->Release();
	 rtfPicture = NULL;
	 }
	 // Read image file
	 int imageFile = _open( image, _O_RDONLY | _O_BINARY );
	 struct _stat st;
	 _fstat( imageFile, &st );
	 DWORD nSize = st.st_size;
	 BYTE* pBuff = new BYTE[nSize];
	 _read( imageFile, pBuff, nSize );
	 // Alocate memory for image data
	 HGLOBAL hGlobal = GlobalAlloc(GMEM_MOVEABLE, nSize);
	 void* pData = GlobalLock(hGlobal);
	 memcpy(pData, pBuff, nSize);
	 GlobalUnlock(hGlobal);
	 // Load image using OLE
	 IStream* pStream = NULL;
	 if ( CreateStreamOnHGlobal(hGlobal, TRUE, &pStream) == S_OK )
	 {
	 HRESULT hr;
	 if ((hr = OleLoadPicture( pStream, nSize, FALSE, IID_IPicture, (LPVOID *)&rtfPicture)) != S_OK)
	 error = RTF_IMAGE_ERROR;
	 pStream->Release();
	 }
	 delete []pBuff;
	 _close(imageFile);
	 // If image is loaded
	 if ( rtfPicture != NULL )
	 {
	 // Calculate image size
	 long hmWidth;
	 long hmHeight;
	 rtfPicture->get_Width(&hmWidth);
	 rtfPicture->get_Height(&hmHeight);
	 int nWidth	= MulDiv( hmWidth, GetDeviceCaps(GetDC(NULL),LOGPIXELSX), 2540 );
	 int nHeight	= MulDiv( hmHeight, GetDeviceCaps(GetDC(NULL),LOGPIXELSY), 2540 );
	 // Create metafile;
	 HDC hdcMeta = CreateMetaFile(NULL);
	 // Render picture to metafile
	 rtfPicture->Render( hdcMeta, 0, 0, nWidth, nHeight, 0, hmHeight, hmWidth, -hmHeight, NULL );
	 // Close metafile
	 HMETAFILE hmf = CloseMetaFile(hdcMeta);
	 // Get metafile data
	 UINT size = GetMetaFileBitsEx( hmf, 0, NULL );
	 BYTE* buffer = new BYTE[size];
	 GetMetaFileBitsEx( hmf, size, buffer );
	 DeleteMetaFile(hmf);
	 // Convert metafile binary data to hexadecimal
	 QString  str = rtf_bin_hex_convert( buffer, size );
	 delete []buffer;
	 // asprintf picture paragraph
	 RTF_PARAGRAPH_FORMAT* pf = rtf_get_paragraphformat();
	 pf->paragraphText = "";
	 rtf_write_paragraphformat();
	 // Writes RTF picture data
	 WCHAR rtfText[1024];
	 wsprint( rtfText, L"\n{/pict/wmetafile8/picwgoal%d/pichgoal%d/picscalex%d/picscaley%d\n", hmWidth, hmHeight, width, height );
	 //if ( fwrite( rtfText, 1, strlen(rtfText), rtfFile ) < strlen(rtfText) )
	 tempwrite( QString::fromWCharArray(rtfText));
	 //	error = RTF_IMAGE_ERROR;
	 tempwrite( str );
	 wcscpy( rtfText, L"}" );
	 tempwrite( rtfText  );
	 }
	 */
	// Return error flag
	return error;
}
// Converts binary data to hex
QString CRTFLib::rtf_bin_hex_convert(WCHAR* binary, int size) {
    QString result = "";
    WCHAR part1, part2;

    for (int i = 0; i < size; i++) {

		part1 = binary[i] / 16;
		if (part1 < 10)
			part1 += 48;
		else {
			if (part1 == 10)
				part1 = 'a';
			if (part1 == 11)
				part1 = 'b';
			if (part1 == 12)
				part1 = 'c';
			if (part1 == 13)
				part1 = 'd';
			if (part1 == 14)
				part1 = 'e';
			if (part1 == 15)
				part1 = 'f';
		}
		part2 = binary[i] % 16;
		if (part2 < 10)
			part2 += 48;
		else {
			if (part2 == 10)
				part2 = 'a';
			if (part2 == 11)
				part2 = 'b';
			if (part2 == 12)
				part2 = 'c';
			if (part2 == 13)
				part2 = 'd';
			if (part2 == 14)
				part2 = 'e';
			if (part2 == 15)
				part2 = 'f';
		}
		result[2 * i] = part1;
		result[2 * i + 1] = part2;
	}
    return result;
}
// Starts new RTF table row
int CRTFLib::rtf_start_tablerow() {
	// Set error flag
	int error = RTF_SUCCESS;
	WCHAR tblrw[12] = L"";
	// asprintf table row aligment
	switch (rtfRowasprintf.rowAligment) {
	// left align
	case RTF_ROWTEXTALIGN_LEFT:
		wcscat(tblrw, L"/trql");
		break;
		// Center align
	case RTF_ROWTEXTALIGN_CENTER:
		wcscat(tblrw, L"/trqc");
		break;
		// right align
	case RTF_ROWTEXTALIGN_RIGHT:
		wcscat(tblrw, L"/trqr");
		break;
	}
	// Writes RTF table data
	WCHAR rtfText[1024];
	swprintf(rtfText, 1024,
			L"\n/trowd/trgaph115%s/trleft%d/trrh%d/trpaddb%d/trpaddfb3/trpaddl%d/trpaddfl3/trpaddr%d/trpaddfr3/trpaddt%d/trpaddft3",
			tblrw, rtfRowasprintf.rowleftMargin, rtfRowasprintf.rowHeight, rtfRowasprintf.marginTop,
			rtfRowasprintf.marginBottom, rtfRowasprintf.marginleft, rtfRowasprintf.marginright);
	tempwrite(QString::fromWCharArray(rtfText));
	//\error = RTF_TABLE_ERROR;
	// Return error flag
	return error;
}
// Ends RTF table row
int CRTFLib::rtf_end_tablerow() {
	// Set error flag
	int error = RTF_SUCCESS;
	// Writes RTF table data
	WCHAR rtfText[1024];
	swprintf(rtfText, 1024, L"\n/trgaph115/row/pard");
	tempwrite(QString::fromWCharArray(rtfText));
	//error = RTF_TABLE_ERROR;
	// Return error flag
	return error;
}
// Starts new RTF table cell
int CRTFLib::rtf_start_tablecell(int rightMargin) {
	// Set error flag
	int error = RTF_SUCCESS;
	WCHAR tblcla[20];
	// asprintf table cell text aligment
	switch (rtfCellasprintf.textVerticalAligment) {
	// Top align
	case RTF_CELLTEXTALIGN_TOP:
		wcscpy(tblcla, L"/clvertalt");
		break;
		// Center align
	case RTF_CELLTEXTALIGN_CENTER:
		wcscpy(tblcla, L"/clvertalc");
		break;
		// Bottom align
	case RTF_CELLTEXTALIGN_BOTTOM:
		wcscpy(tblcla, L"/clvertalb");
		break;
	default:
		wcscpy(tblcla, L"");
	}
	WCHAR tblcld[20];
	// asprintf table cell text direction
	switch (rtfCellasprintf.textDirection) {
	// left to right, top to bottom
	case RTF_CELLTEXTDIRECTION_LRTB:
		wcscpy(tblcld, L"/cltxlrtb");
		break;
		// right to left, top to bottom
	case RTF_CELLTEXTDIRECTION_RLTB:
		wcscpy(tblcld, L"/cltxtbrl");
		break;
		// left to right, bottom to top
	case RTF_CELLTEXTDIRECTION_LRBT:
		wcscpy(tblcld, L"/cltxbtlr");
		break;
		// left to right, top to bottom, vertical
	case RTF_CELLTEXTDIRECTION_LRTBV:
		wcscpy(tblcld, L"/cltxlrtbv");
		break;
		// right to left, top to bottom, vertical
	case RTF_CELLTEXTDIRECTION_RLTBV:
		wcscpy(tblcld, L"/cltxtbrlv");
		break;
	default:
		wcscpy(tblcld, L"");				//Coverity CID: 1992645
	}
	WCHAR tbclbrb[1024] = L"", tbclbrl[1024] = L"", tbclbrr[1024] = L"", tbclbrt[1024] = L"";
	// asprintf table cell border
	if (rtfCellasprintf.borderBottom.border == true) {
		// Bottom cell border
		WCHAR tbclbt[20];
		wcscpy(tbclbt, L"/clbrdrb");
		QString strBorder(rtf_get_bordername(rtfCellasprintf.borderBottom.BORDERS.borderType));
		swprintf(tbclbrb, 20, L"%s%s/brdrw%d/brsp%d/brdrcf%d", tbclbt, strBorder.toLocal8Bit().data(),
				rtfCellasprintf.borderBottom.BORDERS.borderWidth, rtfCellasprintf.borderBottom.BORDERS.borderSpace,
				rtfCellasprintf.borderBottom.BORDERS.borderColor);
	}
	if (rtfCellasprintf.borderleft.border == true) {
		// left cell border
		WCHAR tbclbt[20];
		wcscpy(tbclbt, L"/clbrdrl");
		QString strBorder(rtf_get_bordername(rtfCellasprintf.borderleft.BORDERS.borderType));
		swprintf(tbclbrl, 20, L"%s%s/brdrw%d/brsp%d/brdrcf%d", tbclbt, strBorder.toLocal8Bit().data(),
				rtfCellasprintf.borderleft.BORDERS.borderWidth, rtfCellasprintf.borderleft.BORDERS.borderSpace,
				rtfCellasprintf.borderleft.BORDERS.borderColor);
	}
	if (rtfCellasprintf.borderright.border == true) {
		// right cell border
		WCHAR tbclbt[20];
		wcscpy(tbclbt, L"/clbrdrr");
		QString strBorder(rtf_get_bordername(rtfCellasprintf.borderright.BORDERS.borderType));
		swprintf(tbclbrr, 20, L"%s%s/brdrw%d/brsp%d/brdrcf%d", tbclbt, strBorder.toLocal8Bit().data(),
				rtfCellasprintf.borderright.BORDERS.borderWidth, rtfCellasprintf.borderright.BORDERS.borderSpace,
				rtfCellasprintf.borderright.BORDERS.borderColor);
	}
	if (rtfCellasprintf.borderTop.border == true) {
		// Top cell border
		WCHAR tbclbt[20];
		wcscpy(tbclbt, L"/clbrdrt");
		QString strBorder(rtf_get_bordername(rtfCellasprintf.borderTop.BORDERS.borderType));
		swprintf(tbclbrt, 20, L"%s%s/brdrw%d/brsp%d/brdrcf%d", tbclbt, strBorder.toLocal8Bit().data(),
				rtfCellasprintf.borderTop.BORDERS.borderWidth, rtfCellasprintf.borderTop.BORDERS.borderSpace,
				rtfCellasprintf.borderTop.BORDERS.borderColor);
	}
	// asprintf table cell shading
	WCHAR shading[100];
	memset(shading, 0, 100);
	if (rtfCellasprintf.cellShading == true) {
		QString strShading(rtf_get_shadingname(rtfCellasprintf.SHADING.shadingType, true));
		// Set paragraph shading color
		swprintf(shading, 100, L"%s/clshdgn%d/clcfpat%d/clcbpat%d", strShading.toLocal8Bit().data(),
				rtfCellasprintf.SHADING.shadingIntensity, rtfCellasprintf.SHADING.shadingFillColor,
				rtfCellasprintf.SHADING.shadingBkColor);
	}
	// Writes RTF table data
	WCHAR rtfText[1024];
	swprintf(rtfText, 1024, L"\n/tcelld%s%s%s%s%s%s%s/cellx%d", tblcla, tblcld, tbclbrb, tbclbrl, tbclbrr, tbclbrt,
			shading, rightMargin);
	tempwrite(QString::fromWCharArray(rtfText));
	//error = RTF_TABLE_ERROR;		//Coverity CID: 1992630
	// Return error flag
	return error;
}
// Ends RTF table cell
int CRTFLib::rtf_end_tablecell() {
	// Set error flag
	int error = RTF_SUCCESS;
	// Writes RTF table data
	WCHAR rtfText[1024];
	wcscpy(rtfText, L"\n/cell ");
	tempwrite(QString::fromWCharArray(rtfText));
	//error = RTF_TABLE_ERROR;
	// Return error flag
	return error;
}
// Gets RTF table row formatting properties
RTF_TABLEROW_FORMAT* CRTFLib::rtf_get_tablerowformat() {
	// Get current RTF table row formatting properties
	return &rtfRowasprintf;
}
// Sets RTF table row formatting properties
void CRTFLib::rtf_set_tablerowformat(RTF_TABLEROW_FORMAT *rf) {
	// Set new RTF table row formatting properties
	memcpy(&rtfRowasprintf, rf, sizeof(RTF_TABLEROW_FORMAT));
}
// Gets RTF table cell formatting properties
RTF_TABLECELL_FORMAT* CRTFLib::rtf_get_tablecellformat() {
	// Get current RTF table cell formatting properties
	return &rtfCellasprintf;
}
// Sets RTF table cell formatting properties
void CRTFLib::rtf_set_tablecellformat(RTF_TABLECELL_FORMAT *cf) {
	// Set new RTF table cell formatting properties
	memcpy(&rtfCellasprintf, cf, sizeof(RTF_TABLECELL_FORMAT));
}
// Gets border name
const QString CRTFLib::rtf_get_bordername(int border_type) {
	QString strBorder("");
	switch (border_type) {
	// Single-thickness border
	case RTF_PARAGRAPHBORDERTYPE_STHICK:
		strBorder = "/brdrs";
		break;
		// Double-thickness border
	case RTF_PARAGRAPHBORDERTYPE_DTHICK:
		strBorder = "/brdrth";
		break;
		// Shadowed border
	case RTF_PARAGRAPHBORDERTYPE_SHADOW:
		strBorder = "/brdrsh";
		break;
		// Double border
	case RTF_PARAGRAPHBORDERTYPE_DOUBLE:
		strBorder = "/brdrdb";
		break;
		// Dotted border
	case RTF_PARAGRAPHBORDERTYPE_DOT:
		strBorder = "/brdrdot";
		break;
		// Dashed border
	case RTF_PARAGRAPHBORDERTYPE_DASH:
		strBorder = "/brdrdash";
		break;
		// Hairline border
	case RTF_PARAGRAPHBORDERTYPE_HAIRLINE:
		strBorder = "/brdrhair";
		break;
		// Inset border
	case RTF_PARAGRAPHBORDERTYPE_INSET:
		strBorder = "/brdrinset";
		break;
		// Dashed border (small)
	case RTF_PARAGRAPHBORDERTYPE_SDASH:
		strBorder = "/brdrdashsm";
		break;
		// Dot-dashed border
	case RTF_PARAGRAPHBORDERTYPE_DOTDASH:
		strBorder = "/brdrdashd";
		break;
		// Dot-dot-dashed border
	case RTF_PARAGRAPHBORDERTYPE_DOTDOTDASH:
		strBorder = "/brdrdashdd";
		break;
		// Outset border
	case RTF_PARAGRAPHBORDERTYPE_OUTSET:
		strBorder = "/brdroutset";
		break;
		// Triple border
	case RTF_PARAGRAPHBORDERTYPE_TRIPLE:
		strBorder = "/brdrtriple";
		break;
		// Wavy border
	case RTF_PARAGRAPHBORDERTYPE_WAVY:
		strBorder = "/brdrwavy";
		break;
		// Double wavy border
	case RTF_PARAGRAPHBORDERTYPE_DWAVY:
		strBorder = "/brdrwavydb";
		break;
		// Striped border
	case RTF_PARAGRAPHBORDERTYPE_STRIPED:
		strBorder = "/brdrdashdotstr";
		break;
		// Embossed border
	case RTF_PARAGRAPHBORDERTYPE_EMBOSS:
		strBorder = "/brdremboss";
		break;
		// Engraved border
	case RTF_PARAGRAPHBORDERTYPE_ENGRAVE:
		strBorder = "/brdrengrave";
		break;
	}
	return strBorder;
}
// Gets shading name
const QString CRTFLib::rtf_get_shadingname(int shading_type, bool cell) {
	QString strShading("");
	if (cell == false) {
		switch (shading_type) {
		// Fill shading
		case RTF_PARAGRAPHSHADINGTYPE_FILL:
			strShading = "";
			break;
			// Horizontal background pattern
		case RTF_PARAGRAPHSHADINGTYPE_HORIZ:
			strShading = "/bghoriz";
			break;
			// Vertical background pattern
		case RTF_PARAGRAPHSHADINGTYPE_VERT:
			strShading = "/bgvert";
			break;
			// Forward diagonal background pattern
		case RTF_PARAGRAPHSHADINGTYPE_FDIAG:
			strShading = "/bgfdiag";
			break;
			// Backward diagonal background pattern
		case RTF_PARAGRAPHSHADINGTYPE_BDIAG:
			strShading = "/bgbdiag";
			break;
			// Cross background pattern
		case RTF_PARAGRAPHSHADINGTYPE_CROSS:
			strShading = "/bgcross";
			break;
			// Diagonal cross background pattern
		case RTF_PARAGRAPHSHADINGTYPE_CROSSD:
			strShading = "/bgdcross";
			break;
			// Dark horizontal background pattern
		case RTF_PARAGRAPHSHADINGTYPE_DHORIZ:
			strShading = "/bgdkhoriz";
			break;
			// Dark vertical background pattern
		case RTF_PARAGRAPHSHADINGTYPE_DVERT:
			strShading = "/bgdkvert";
			break;
			// Dark forward diagonal background pattern
		case RTF_PARAGRAPHSHADINGTYPE_DFDIAG:
			strShading = "/bgdkfdiag";
			break;
			// Dark backward diagonal background pattern
		case RTF_PARAGRAPHSHADINGTYPE_DBDIAG:
			strShading = "/bgdkbdiag";
			break;
			// Dark cross background pattern
		case RTF_PARAGRAPHSHADINGTYPE_DCROSS:
			strShading = "/bgdkcross";
			break;
			// Dark diagonal cross background pattern
		case RTF_PARAGRAPHSHADINGTYPE_DCROSSD:
			strShading = "/bgdkdcross";
			break;
		}
	} else {
		switch (shading_type) {
		// Fill shading
		case RTF_CELLSHADINGTYPE_FILL:
			strShading = "";
			break;
			// Horizontal background pattern
		case RTF_CELLSHADINGTYPE_HORIZ:
			strShading = "/clbghoriz";
			break;
			// Vertical background pattern
		case RTF_CELLSHADINGTYPE_VERT:
			strShading = "/clbgvert";
			break;
			// Forward diagonal background pattern
		case RTF_CELLSHADINGTYPE_FDIAG:
			strShading = "/clbgfdiag";
			break;
			// Backward diagonal background pattern
		case RTF_CELLSHADINGTYPE_BDIAG:
			strShading = "/clbgbdiag";
			break;
			// Cross background pattern
		case RTF_CELLSHADINGTYPE_CROSS:
			strShading = "/clbgcross";
			break;
			// Diagonal cross background pattern
		case RTF_CELLSHADINGTYPE_CROSSD:
			strShading = "/clbgdcross";
			break;
			// Dark horizontal background pattern
		case RTF_CELLSHADINGTYPE_DHORIZ:
			strShading = "/clbgdkhoriz";
			break;
			// Dark vertical background pattern
		case RTF_CELLSHADINGTYPE_DVERT:
			strShading = "/clbgdkvert";
			break;
			// Dark forward diagonal background pattern
		case RTF_CELLSHADINGTYPE_DFDIAG:
			strShading = "/clbgdkfdiag";
			break;
			// Dark backward diagonal background pattern
		case RTF_CELLSHADINGTYPE_DBDIAG:
			strShading = "/clbgdkbdiag";
			break;
			// Dark cross background pattern
		case RTF_CELLSHADINGTYPE_DCROSS:
			strShading = "/clbgdkcross";
			break;
			// Dark diagonal cross background pattern
		case RTF_CELLSHADINGTYPE_DCROSSD:
			strShading = "/clbgdkdcross";
			break;
		}
	}
	return strShading;
}
void CRTFLib::tempwrite(const QString &rstrADD_DATA) {
	m_strBUFFER += rstrADD_DATA;
	if (m_strBUFFER.size() > 32000) {
		// flush the contents of the buffer
		WriteBuffer();
		// clear the buffer
		m_strBUFFER = "";
	}
}
//****************************************************************************
//	const QString ConvertUnicode( const QString pwcBUFFER )
///
/// Method that converts any unicode characters into RTF compatible strings
///
/// @param[in]		const QString pwcBUFFER - The text buffer that might contain unicode data
///
/// @return		The converted RTF compatible string
///
//****************************************************************************
const QString CRTFLib::ConvertUnicode(const QString pwcBUFFER) {
	QString strConverted("");
	strConverted = pwcBUFFER;
	const TCHAR *strFORMAT = "/u%u ?";
	QString strDecimalEquiv("");
	// loop through the text looking for charaters outside of the usual ASCII boundaries
	for (int iCount = 0; iCount < strConverted.size(); iCount++) {
		if (static_cast<ULONG>(strConverted[iCount]) > 127) {
			// convert to a ACSII decimal equivalent preceded by a \u which implieies it is unicode
			const ULONG ulUNICODE_CHAR = strConverted[iCount];
			strDecimalEquiv = QString::asprintf(strFORMAT, ulUNICODE_CHAR);
			// remove the old unicode character and
			strConverted.Delete(iCount, 1);
			strConverted.insert(iCount, strDecimalEquiv);
		}
	}
	return strConverted;
}
void CRTFLib::EndHeader() {
	m_strBUFFER += "}";
}
void CRTFLib::EndFooter() {
	m_strBUFFER += "}";
}
void CRTFLib::StartTable() {
	rtf_start_section();
	// asprintf paragraph
	rtfParasprintf.spaceBefore = 0;
	rtfParasprintf.spaceAfter = 0;
	// asprintf table row
	rtfRowasprintf.rowAligment = RTF_ROWTEXTALIGN_LEFT;
	rtfRowasprintf.marginTop = 120;
	rtfRowasprintf.marginBottom = 120;
	rtfRowasprintf.marginleft = 120;
	rtfRowasprintf.marginright = 120;
	// Start table row
	//kNewRTFFile.rtf_start_tablerow();
	// asprintf table cell
	rtfCellasprintf.textVerticalAligment = RTF_CELLTEXTALIGN_CENTER;
	rtfCellasprintf.textDirection = RTF_CELLTEXTDIRECTION_LRTB;
	rtfCellasprintf.borderBottom.border = true;
	rtfCellasprintf.borderBottom.BORDERS.borderType = RTF_PARAGRAPHBORDERTYPE_STHICK;
	rtfCellasprintf.borderBottom.BORDERS.borderWidth = 5;
	rtfCellasprintf.borderleft.border = true;
	rtfCellasprintf.borderleft.BORDERS.borderType = RTF_PARAGRAPHBORDERTYPE_STHICK;
	rtfCellasprintf.borderleft.BORDERS.borderWidth = 5;
	rtfCellasprintf.borderright.border = true;
	rtfCellasprintf.borderright.BORDERS.borderType = RTF_PARAGRAPHBORDERTYPE_STHICK;
	rtfCellasprintf.borderright.BORDERS.borderWidth = 5;
	rtfCellasprintf.borderTop.border = true;
	rtfCellasprintf.borderTop.BORDERS.borderType = RTF_PARAGRAPHBORDERTYPE_STHICK;
	rtfCellasprintf.borderTop.BORDERS.borderWidth = 5;
	rtfCellasprintf.cellShading = true;
	rtfCellasprintf.SHADING.shadingType = RTF_CELLSHADINGTYPE_FILL;
	rtfCellasprintf.SHADING.shadingBkColor = 3;
	rtfParasprintf.tableText = true;
}
//******************************************************
//
/// Method that adds the table header cells
///
/// @param[in]		const QString &rstrHEADERS - The header cell text delimitted with pipes
///
//******************************************************
void CRTFLib::AddTableHeader(const QString &rstrHEADERS) {
	int iNoOfCols = CStringUtils::InstanceOfStr(rstrHEADERS, CStringUtils::ms_strDELIMITTER);
	// add a second title row
	rtf_start_tablerow();
	// asprintf table cell
	rtfCellasprintf.borderleft.BORDERS.borderWidth = 5;
	rtfCellasprintf.SHADING.shadingBkColor = 2;
	rtfParasprintf.CHARACTER.boldCharacter = true;
	rtfCellasprintf.borderleft.BORDERS.borderWidth = 30;
	rtfCellasprintf.borderright.BORDERS.borderWidth = 5;
	const int iCOL_WIDTH = ms_iMAX_CELL_WIDTH / iNoOfCols;
	int iColCount = 0;
	for (iColCount = 0; iColCount < iNoOfCols; iColCount++) {
		rtf_start_tablecell((iColCount + 1) * iCOL_WIDTH);
	}
	for (iColCount = 0; iColCount < iNoOfCols; iColCount++) {
		rtf_start_paragraph(CStringUtils::GetItemAtPos(rstrHEADERS, iColCount), false);
		rtf_end_tablecell();
	}
	// End table row
	rtf_end_tablerow();
}
//******************************************************
//
/// Method that adds the table header cells - also supports variable row/cell widths
///
/// @param[in]		const QString &rstrHEADERS - The header cell text delimitted with pipes
/// @param[in]		const int* CELL_WIDTHS - Array containing the cell widths as a percentage
///
//******************************************************
void CRTFLib::AddTableHeader(const QString &rstrHEADERS, const int iaCELL_WIDTHS[]) {
	int iNoOfCols = CStringUtils::InstanceOfStr(rstrHEADERS, CStringUtils::ms_strDELIMITTER);
	// add a second title row
	rtf_start_tablerow();
	// asprintf table cell
	rtfCellasprintf.borderleft.BORDERS.borderWidth = 5;
	rtfCellasprintf.SHADING.shadingBkColor = 2;
	rtfParasprintf.CHARACTER.boldCharacter = true;
	rtfCellasprintf.borderleft.BORDERS.borderWidth = 30;
	rtfCellasprintf.borderright.BORDERS.borderWidth = 5;
	const int iCOL_WIDTH = ms_iMAX_CELL_WIDTH / iNoOfCols;
	int iColCount = 0;
	int iColEnd = 0;
	for (iColCount = 0; iColCount < iNoOfCols; iColCount++) {
		const int iCOL_WIDTH = (ms_iMAX_CELL_WIDTH * iaCELL_WIDTHS[iColCount]) / 100;
		iColEnd += iCOL_WIDTH;
		rtf_start_tablecell(iColEnd);
	}
	for (iColCount = 0; iColCount < iNoOfCols; iColCount++) {
		rtf_start_paragraph(CStringUtils::GetItemAtPos(rstrHEADERS, iColCount), false);
		rtf_end_tablecell();
	}
	// End table row
	rtf_end_tablerow();
}
//******************************************************
//
/// Method used to create equal width rows
///
/// @param[in]		const int iNO_OF_COLS - The numnber of columns
///
//******************************************************
void CRTFLib::StartRow(const int iNO_OF_COLS) {
	rtf_start_tablerow();
	const int iCOL_WIDTH = ms_iMAX_CELL_WIDTH / iNO_OF_COLS;
	for (int iColCount = 0; iColCount < iNO_OF_COLS; iColCount++) {
		rtf_start_tablecell((iColCount + 1) * iCOL_WIDTH);
	}
}
//******************************************************
//
/// Method used to create variable width rows/cells
///
/// @param[in]		const int iNO_OF_COLS - The numnber of columns
/// @param[in]		const int* CELL_WIDTHS - Array containing the cell widths as a percentage
///
//******************************************************
void CRTFLib::StartVarWidthRow(const int iNO_OF_COLS, const int iaCELL_WIDTHS[]) {
	rtf_start_tablerow();
	int iColEnd = 0;
	for (int iColCount = 0; iColCount < iNO_OF_COLS; iColCount++) {
		const int iCOL_WIDTH = (ms_iMAX_CELL_WIDTH * iaCELL_WIDTHS[iColCount]) / 100;
		iColEnd += iCOL_WIDTH;
		rtf_start_tablecell(iColEnd);
	}
}
void CRTFLib::EndTable() {
	rtfParasprintf.tableText = false;
}
void CRTFLib::AddTitle(const QString &rstrTITLE) {
	rtfParasprintf.CHARACTER.boldCharacter = true;
	rtfParasprintf.CHARACTER.underlineCharacter = true;
	const int iOLD_FONT_SIZE = rtfParasprintf.CHARACTER.fontSize;
	rtfParasprintf.CHARACTER.fontSize = 24;
	rtf_start_paragraph(rstrTITLE, true);
	rtfParasprintf.CHARACTER.boldCharacter = false;
	rtfParasprintf.CHARACTER.underlineCharacter = false;
	rtfParasprintf.CHARACTER.fontSize = iOLD_FONT_SIZE;
	rtf_start_paragraph("", true);
	rtf_start_paragraph("", true);
}
//****************************************************************************
//  const QString ReadBuffer( QString &rstrFULL_PATH_NAME )
///
//// Method used to read RTF files
///
/// @param[in]		QString &rstrFULL_PATH_NAME - The full path name of the file
///					we wish to read in
///
///	@return			A string containing the read in RTF file
///
///	@TODO - Modify this method so it returns 32K segments of the data which can be
///			process (stripped of RTF information) after which another segment can be
///			grabbed
///
//****************************************************************************
const QString CRTFLib::ReadBuffer(QString &rstrFULL_PATH_NAME) {
	QString strInputBuffer("");
	char *ptNewBuff = new char[m_ulMAX_READ_BUFF_LEN];
	QString pwcNewBuff = "";
	ULONG ulCount = m_ulMAX_READ_BUFF_LEN;
	bool bContinue = true;
	ULONG ulFilePos = 0;
	const ULONG ulFILE_LENGTH = GetFileSize(rstrFULL_PATH_NAME.toLocal8Bit().data());
	QString strTempBuffer;
	Open(rstrFULL_PATH_NAME.toLocal8Bit().data(), CStorage::ReadOnly);
	while ((ulFILE_LENGTH - 1) > ulFilePos) {
		Seek(ulFilePos, 0);
		const ULONG ulBYTES_READ = Read(ptNewBuff, m_ulMAX_READ_BUFF_LEN);
		ulFilePos += ulBYTES_READ;
		size_t pNoOfChars;
		/// TODO: CHeck this functionality
//        mbstowcs_s(&pNoOfChars, pwcNewBuff,  m_ulMAX_READ_BUFF_LEN, ptNewBuff, ulBYTES_READ );
		strTempBuffer = pwcNewBuff;
		strInputBuffer += strTempBuffer;
	}
	delete[] ptNewBuff;
	return strInputBuffer;
}

/// @file SipEdit.h
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		EditPanel
/// @n Filename:  SipEdit.h
/// @n Description: Definition of the CSipEdit class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  3 Stability Project 1.0.1.1 7/2/2011 5:01:24 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  2 Stability Project 1.0.1.0 7/1/2011 4:26:32 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  1 V6 Firmware 1.0 3/2/2006 2:42:25 PM Sanjeev (HTSL) 
// $
//
// **************************************************************************
#if !defined(AFX_SIPEDIT_H__AF415ABE_01E1_40DB_B8CC_A38D6F7D5A4D__INCLUDED_)
#define AFX_SIPEDIT_H__AF415ABE_01E1_40DB_B8CC_A38D6F7D5A4D__INCLUDED_
#include "Defines.h"
#include <QTextEdit>
// SipEdit.h : header file
//
/////////////////////////////////////////////////////////////////////////////
// CSipEdit window
class CSipEdit: public QTextEdit {
// Construction
public:
	CSipEdit();
// Attributes
public:
// Operations
public:
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSipEdit)
	//}}AFX_VIRTUAL
// Implementation
public:
	virtual ~CSipEdit();
	// Generated message map functions
protected:
	//{{AFX_MSG(CSipEdit)
	// NOTE - the ClassWizard will add and remove member functions here.
	BOOL OnEraseBkgnd(CDC *pDC);
	UINT OnGetDlgCode();
	//}}AFX_MSG
};
/////////////////////////////////////////////////////////////////////////////
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.
#endif // !defined(AFX_SIPEDIT_H__AF415ABE_01E1_40DB_B8CC_A38D6F7D5A4D__INCLUDED_)

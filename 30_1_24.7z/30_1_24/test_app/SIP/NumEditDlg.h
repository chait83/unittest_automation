/// @file
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Configuration System
/// @n Filename:  NumEditDlg.cpp
/// @n Description: Implementation for the CNumEditDlg class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  5 Stability Project 1.2.1.1 7/2/2011 4:59:07 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  4 Stability Project 1.2.1.0 7/1/2011 4:26:33 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  3 V6 Firmware 1.2 3/14/2006 10:02:43 PM  Roger Dawson  
//  Fixed excessive memory usage by SIPs.
//  2 V6 Firmware 1.1 3/1/2006 6:26:41 PM Roger Dawson  
//  Modified the various edit panels so they are no longer singletons in
//  order to save memory.
// $
//
// **************************************************************************
#if !defined(AFX_NUMEDITDLG_H__2261A66B_49ED_4713_A713_2C0AED2C9841__INCLUDED_)
#define AFX_NUMEDITDLG_H__2261A66B_49ED_4713_A713_2C0AED2C9841__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "EditPanelDlg.h"
//**CNumEditDlg**********************************************************
///
/// @brief Dialog that displays the Numeric SIP
/// 
/// Dialog class that displays the Numeric SIP. 
///
//****************************************************************************
class CNumEditDlg: public CEditPanelDlg {
// Construction
public:
	CNumEditDlg(CWidget *pParent = NULL);  // standard constructor
	// Destructor
	virtual ~CNumEditDlg();
// Dialog Data
	//{{AFX_DATA(CNumEditDlg)
	enum {
		IDD = IDD_NUM_EDIT_DLG
	};
	// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNumEditDlg)
protected:
	virtual void DoDataExchange(CDataItem *pDX);  // DDX/DDV support
	//}}AFX_VIRTUAL
// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CNumEditDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
private:
	// Method that initialises the edit panel member variables such as the bitmap and keymap
	void InitializeIP();
};
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.
#endif // !defined(AFX_NUMEDITDLG_H__2261A66B_49ED_4713_A713_2C0AED2C9841__INCLUDED_)

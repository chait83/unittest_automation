/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  CEFileTransferSocket 
/// @n Filename:  CEFileTransferSocket.cpp
/// @n Description: This class is responsible for communication of recorder and
/// Production Interface tool
///
// **************************************************************************
// Revision History
// 20-10-14 Rajanbabu M Fixed PAR:1-3I2GTSM - WSD communication is not working on upgrading the firmware
//	Swathi 07/23/2014 Fix for the par 1-3GM1NP1: Do not set the date when 
//					 requested for Recorder Model Number alone. This can
//				 be possible for Remote Display Tool
// Swathi 07/30/2014 Install Device Certificate when requested via Production Tool
// **************************************************************************
#include "CEFileTransferSocket.h"
#include "HtDataCommand.h"
#define MODEL_NO 01
#define SET_INFO 02
#define MODEL_TYPE 03
#define TRACE_ALLOW
//****************************************************************************
/// CEFileTransferSocket - Constructor
///
/// @param n/a
///
/// @return		n/a
///
//****************************************************************************
CEFileTransferSocket::CEFileTransferSocket(ESocketTransMode eSTMode) : CV7SecureSocket(eSTMode) {
	m_hRecvEv = NULL;
	m_hAcceptedEv = NULL;
	m_hCloseEv = NULL;
	m_hConnEv = NULL;
	m_hServFailed = NULL;
	m_hAcceptEv = NULL;
	m_hCmdRespEv = NULL;
	QMutex * m_csHtdCmdList;
} //end CEFileTransferSocket()
CEFileTransferSocket::CEFileTransferSocket(QAbstractSocket skt, ESocketRoleType role, CredHandle *hServerCreds,
		CtxtHandle *hContext) : CV7SecureSocket(skt, role, hServerCreds, hContext) {
	m_hRecvEv = NULL;
	m_hAcceptedEv = NULL;
	m_hCloseEv = NULL;
	m_hConnEv = NULL;
	m_hServFailed = NULL;
	m_hAcceptEv = NULL;
	m_hCmdRespEv = NULL;
	QMutex * m_csHtdCmdList;
}
//****************************************************************************
/// ~CEFileTransferSocket - Destructor
///
/// @param n/a
///
/// @return		n/a
///
//****************************************************************************
CEFileTransferSocket::~CEFileTransferSocket() {
	CleanHtdCmds();
	//deletion of mutex not required
} //end ~CEFileTransferSocket()
//****************************************************************************
/// Create - creates a new socket
///
/// @param n/a
///
/// @return		true if successful
///
//****************************************************************************
bool CEFileTransferSocket::Create() {
	return CV7SecureSocket::Create(SOCK_STREAM, SECURE_TCP_BUFFERSIZE);
} //end Create()
//****************************************************************************
/// OnAccept - Override to handle accept notifications
///
/// @param[in]	serviceSocket - QAbstractSocket to attach to new class instance
///
/// @return		false if new socket not handled by handler thread
///
//****************************************************************************
bool CEFileTransferSocket::OnAccept(QAbstractSocket serviceSocket) {
	bool ret = false;
#ifdef DBG_FILE_LOG_FTS_DBG_ENABLE
	QString   strDbgMsg;
	strDbgMsg = QString::asprintf(_T("::OnAccept BEGIN s = %lu serviceSocket %lu"), s, serviceSocket);
	LogDebugMessage(strDbgMsg);
	#endif
	if (ST_MODE_SECURE == m_eSocketTransMode) {
		//Perform Secure handshake
		ret = CV7SecureSocket::OnAccept(serviceSocket);
		if (false == ret) {
#ifdef DBG_FILE_LOG_FTS_DBG_ENABLE
			strDbgMsg = QString::asprintf(_T("::OnAccept END CV7SecureSocket::OnAccept FAILED s = %lu serviceSocket %lu"), s, serviceSocket);
			LogDebugMessage(strDbgMsg);
			#endif
			return ret;
		}
	}
	//Store momentarily 
	m_sServSock = serviceSocket;
	//and inform the App layer
	SetEvent(m_hAcceptEv);
	//Wait for Applayer to accept the connection
	BOOL retry = 3;
	while (retry) {
		DWORD dwRet = m_hAcceptedEv.tryLock(5000);
		switch (dwRet) //test amount of timeout
		{
		case WAIT_TIMEOUT: {
			//no one's listening
			ResetEvent(m_hAcceptEv);
			retry = 0;
#ifdef DBG_FILE_LOG_FTS_DBG_ENABLE
				strDbgMsg = QString::asprintf(_T("::OnAccept s = %lu serviceSocket %lu TIMED OUT"), s, serviceSocket);
				LogDebugMessage(strDbgMsg);
				#endif
		}
			break;
		case WAIT_OBJECT_0: {
			//Got it - listening
			ret = true;
			retry = 0;
		}
			break;
		default: {
#ifdef DBG_FILE_LOG_FTS_DBG_ENABLE
				strDbgMsg = QString::asprintf(_T("::OnAccept s = %lu serviceSocket %lu defaulted"), s, serviceSocket);
				LogDebugMessage(strDbgMsg);
				#endif
			retry = 0;
		}
			break;
		}
	}
#ifdef DBG_FILE_LOG_FTS_DBG_ENABLE
	strDbgMsg = QString::asprintf(_T("::OnAccept END s = %lu serviceSocket %lu"), s, serviceSocket);
	LogDebugMessage(strDbgMsg);
	#endif
	return ret;
} //end OnAccept()
//****************************************************************************
/// Accept - Override to start socket listening routine
///
/// @param[in]	LocalPort - port to listen on
/// @param[in] maxConn - max pending incoming connections to hold before 
///  connections are refused
///
/// @return		true - accept successful
///
//****************************************************************************
bool CEFileTransferSocket::Accept(UINT LocalPort, int maxConn) {
#ifdef DBG_FILE_LOG_FTS_DBG_ENABLE
	QString   strDbgMsg;
	strDbgMsg = QString::asprintf(_T("::Accept LocalPort = %lu maxConn %lu BEGIN"), LocalPort, maxConn);
	LogDebugMessage(strDbgMsg);
	#endif
	bool bRet = CV7SecureSocket::Accept(LocalPort, maxConn);
	if (bRet) {
		QString csTmp;
		csTmp = QString::asprintf(_T("FTSocket_Accept%d"), LocalPort);
		m_hAcceptEv = CreateEvent(NULL, FALSE, FALSE, csTmp);
		csTmp = QString::asprintf(_T("FTSocket_Accepted%d"), LocalPort);
		m_hAcceptedEv = CreateEvent(NULL, FALSE, FALSE, csTmp);
		csTmp = QString::asprintf(_T("FTListenSocketClose%d"), LocalPort);
		m_hCloseEv = CreateEvent(NULL, FALSE, FALSE, csTmp);
	}
#ifdef DBG_FILE_LOG_FTS_DBG_ENABLE
	strDbgMsg = QString::asprintf(_T("::Accept LocalPort = %lu maxConn %lu bRet %d END"), LocalPort, maxConn, bRet);
	LogDebugMessage(strDbgMsg);
	#endif
	return bRet;
} //end Accept()
//****************************************************************************
/// OnClose - handler override for socket close
///
/// @param[in] closeEvent - reason close has been called
///
/// @return		n/a
///
//****************************************************************************
void CEFileTransferSocket::OnClose(int closeEvent) {
	//Clean up the base class portion
	CV7SecureSocket::OnClose(closeEvent);
	if (EVN_CONNCLOSED == closeEvent) {
		SetEvent(m_hCloseEv);
	} else if (EVN_SERVERDOWN == closeEvent) {
		if (m_hAcceptEv) {
			//No need to close the mutex in Qt
			m_hAcceptEv = NULL;
		}
		if (m_hAcceptedEv) {
			//No need to close the mutex in Qt
			m_hAcceptedEv = NULL;
		}
		if (m_hCloseEv) {
			//No need to close the mutex in Qt
			m_hCloseEv = NULL;
		}
	}
#ifdef DBG_FILE_LOG_FTS_DBG_ENABLE
	QString   strDbgMsg;
	strDbgMsg = QString::asprintf(_T("::OnClose s = %lu closeEvent %d"), s, closeEvent);
	LogDebugMessage(strDbgMsg);	
	#endif
} //end OnClose()
//****************************************************************************
/// Disconnect - disconnect from remote host
///
/// @param n/a
///
/// @return		n/a
///
//****************************************************************************
HRESULT CEFileTransferSocket::Disconnect() {
#ifdef DBG_FILE_LOG_FTS_DBG_ENABLE
	QString   strDbgMsg;
	strDbgMsg = QString::asprintf(_T("::Disconnect s = %lu"), s);
	LogDebugMessage(strDbgMsg);
	#endif
	HRESULT hr = CV7SecureSocket::Disconnect();
	SetEvent(m_hCloseEv);
	qDebug(_T("Disconnect called\n"));
	return hr;
} //end Disconnect()
//****************************************************************************
/// OnReceive - Receives data from client
///
/// @param [in] buf  Data buffer read over the socket connection
/// @param [in] bytesRead Number of bytes read  
///
/// @return		bool - Returns true as this method is used
///
//****************************************************************************
bool CEFileTransferSocket::OnReceive(char *buf, int bytesRead, E_ON_RECV_BUF_ACTION &eOrbAction) {
	bool retVal = true;
#ifdef DBG_FILE_LOG_FTS_DBG_ENABLE
	QString   strDbgMsg;
	strDbgMsg = QString::asprintf(_T("::OnReceive BEGIN bytesRead %d "), bytesRead);
	LogDebugMessage(strDbgMsg);
	#endif
	//Ensure have buffers
	BOOL bCmdAdded = AddHtdCmdToQueue(buf, bytesRead);
	SetEvent(m_hRecvEv);
#ifdef DBG_FILE_LOG_FTS_DBG_ENABLE
	strDbgMsg = QString::asprintf(_T("::OnReceive END retVal %d bCmdAdded %d"), retVal, bCmdAdded);
	LogDebugMessage(strDbgMsg);
	#endif
	eOrbAction = CCESecureSocket::eOrb_Memset;
	return retVal;
} //end OnReceive()
//****************************************************************************
/// OnConnect - OnConnect from a remote host
///
/// @param[in] addr - QString   containing IP address nnn.nnn.nnn.nnn
///
/// @return		true if connect successful
///
//****************************************************************************
bool CEFileTransferSocket::OnConnect(QString &addr) {
	bool ret = false;
	if (CCESecureSocket::ST_MODE_SECURE == m_eSocketTransMode) {
		ret = CV7SecureSocket::OnConnect(addr);
	} else {
		ret = true; //True always in non-secure mode
	}
	return ret;
}
//****************************************************************************
/// Connect - connect to a remote host
///
/// @param[in] addr - QString   containing IP address nnn.nnn.nnn.nnn
/// @param[in] remotePort - Port on the remote host to connect on
/// @param[in] hCloseEv - Close event to set when conn closes
///
/// @return		true if connect successful
///
//****************************************************************************
bool CEFileTransferSocket::Connect(QString &addr, UINT remotePort, HANDLE hCloseEv) {
	bool bRet = false;
#ifdef DBG_FILE_LOG_FTS_DBG_ENABLE	
	QString   strDbgMsg;
	strDbgMsg = QString::asprintf(_T("FTS::Connect addr %s"), addr);
	LogDebugMessage(strDbgMsg);
#endif
	if (CV7SecureSocket::Connect(addr, remotePort)) {
		QString csTmp;
		csTmp = QString::asprintf(_T("FTS-TRANSCEIVE-%lu-%lu"), m_ulPeer, remotePort);
		m_hRecvEv = CreateEvent(NULL, FALSE, FALSE, csTmp);
#ifdef DBG_FILE_LOG_FTS_DBG_ENABLE	
		strDbgMsg = QString::asprintf(_T("FTS::Connect:m_hTransceiveEv %s serviceSock %u"), csTmp, remotePort);
		LogDebugMessage(strDbgMsg);
		#endif
		csTmp = QString::asprintf(_T("FTS-CMD_RESP-%lu-%lu"), m_ulPeer, remotePort);
		m_hCmdRespEv = CreateEvent(NULL, FALSE, FALSE, csTmp);
#ifdef DBG_FILE_LOG_FTS_DBG_ENABLE	
		strDbgMsg = QString::asprintf(_T("::Connect:m_hCmdRespEv %s remotePort %u"), csTmp, remotePort);
		LogDebugMessage(strDbgMsg);
		#endif
		m_hCloseEv = hCloseEv;
		bRet = true;
	}
#ifdef DBG_FILE_LOG_FTS_DBG_ENABLE	
	strDbgMsg = QString::asprintf(_T("::Connect END addr %s - bRet %d"), addr,bRet);
	LogDebugMessage(strDbgMsg);
	#endif
	return bRet;
}
void CEFileTransferSocket::AcceptServiceSocket(QAbstractSocket serviceSock, HANDLE hCloseEv) {
#ifdef DBG_FILE_LOG_FTS_DBG_ENABLE
	QString   strDbgMsg;
	strDbgMsg = QString::asprintf(_T("::AcceptServiceSocket BEGIN ServiceSock %u"), serviceSock);
	LogDebugMessage(strDbgMsg);
#endif
	m_hCloseEv = hCloseEv;
	CV7SecureSocket::AcceptServiceSocket(serviceSock);
	if (CONNECTED == GetSocketState()) {
		QString csTmp;
		csTmp = QString::asprintf(_T("FTS-TRANSCEIVE-%lu-%lu"), m_ulPeer, serviceSock);
		m_hRecvEv = CreateEvent(NULL, FALSE, FALSE, csTmp);
#ifdef DBG_FILE_LOG_FTS_DBG_ENABLE	
		strDbgMsg = QString::asprintf(_T("::AcceptServiceSocket:m_hRecvEv %s serviceSock %u"), csTmp, serviceSock);
		LogDebugMessage(strDbgMsg);
		#endif
		csTmp = QString::asprintf(_T("FTS-CMD_RESP-%lu-%lu"), m_ulPeer, serviceSock);
		m_hCmdRespEv = CreateEvent(NULL, FALSE, FALSE, csTmp);
#ifdef DBG_FILE_LOG_FTS_DBG_ENABLE	
		strDbgMsg = QString::asprintf(_T("::AcceptServiceSocket:m_hCmdRespEv %s serviceSock %u"), csTmp, serviceSock);
		LogDebugMessage(strDbgMsg);
		#endif
	}
#ifdef DBG_FILE_LOG_FTS_DBG_ENABLE
	strDbgMsg = QString::asprintf(_T("::AcceptServiceSocket END ServiceSock %u"), serviceSock);
	LogDebugMessage(strDbgMsg);
	#endif
}
//****************************************************************************
/// ResumeReadThread - resumes the read thread once the parent is ready
///
/// @param n/a
///
/// @return		true if resumed sucessfully
///
//****************************************************************************
bool CEFileTransferSocket::ResumeReadThread() {
#ifdef DBG_FILE_LOG_FTS_DBG_ENABLE
	QString   strDbgMsg;
	strDbgMsg = QString::asprintf(_T("::ResumeReadThread BEGIN"));
	LogDebugMessage(strDbgMsg);
#endif
	bool bRet = false;
	//once events set up, start thread
	if (-1 != start(m_readThread)) {
		bRet = true;
	} else {
		bRet = false;
	}
#ifdef DBG_FILE_LOG_FTS_DBG_ENABLE
	strDbgMsg = QString::asprintf(_T("::ResumeReadThread END bRet %d"), bRet);
	LogDebugMessage(strDbgMsg);
#endif
	return bRet;
}
//****************************************************************************
/// ResumeAcceptThread - resumes the accept thread once the parent is ready
///
/// @param n/a
///
/// @return		true if resumed sucessfully
///
//****************************************************************************
bool CEFileTransferSocket::ResumeAcceptThread() {
#ifdef DBG_FILE_LOG_FTS_DBG_ENABLE
	QString   strDbgMsg;
	strDbgMsg = QString::asprintf(_T("::ResumeAcceptThread BEGIN"));
	LogDebugMessage(strDbgMsg);
#endif
	bool bRet = false;
	//once events set up, start thread
	if (-1 != start(m_acceptThread)) {
		bRet = true;
	} else {
		bRet = false;
	}
#ifdef DBG_FILE_LOG_FTS_DBG_ENABLE
	strDbgMsg = QString::asprintf(_T("::ResumeAcceptThread END bRet %d"), bRet);
	LogDebugMessage(strDbgMsg);
#endif
	return bRet;
}
//****************************************************************************
/// ConvertUnicodeStrToMBCSStr - ConvertUnicodeStrToMBCSStr from a remote host
///
/// @param[in] strUnicode - String in unicode format
///
/// @return		MBCS string 
///
//****************************************************************************
QString A CEFileTransferSocket::ConvertUnicodeStrToMBCSStr(const QString W &strUnicode, int nFieldLength) {
	if (strUnicode.isEmpty())
	return ""; // nothing to do
	QString A strMBCS;
	int cc = 0;
	// get length (cc) of the new multibyte string excluding the \0 terminator first
	if ((cc = WideCharToMultiByte(CP_ACP, 0, strUnicode, -1, NULL, 0, 0, 0) - 1) > 0) {
		if (cc >= nFieldLength)
		cc = nFieldLength;
		char *buf = strMBCS.GetBuffer(cc);
		if (buf)
		WideCharToMultiByte(CP_ACP, 0, strUnicode, -1, buf, cc, 0, 0);
		strMBCS.ReleaseBuffer();
	}
	return strMBCS;
}
BOOL CEFileTransferSocket::AddHtdCmdToQueue(char *buf, int bytesRead) {
	BOOL bRet = FALSE;
#ifdef DBG_FILE_LOG_FTS_DBG_ENABLE
	CHtDtCmdHelper htdCmdHelper(m_pDebugFileLogger);//Pass on the logger
	#else
	CHtDtCmdHelper htdCmdHelper;
#endif
	CHtDataCmd *pInCmd = NULL;
	bRet = htdCmdHelper.ParseCmdPkt(buf, bytesRead, &pInCmd);
#ifdef DBG_FILE_LOG_FTS_DBG_ENABLE
	QString   strDbgMsg;
	strDbgMsg = QString::asprintf(_T("::AddHtdCmdToQueue BEGIN htdCmdHelper.ParseCmdPkt ret %d"), bRet);
	LogDebugMessage(strDbgMsg);
	#endif
	if (bRet) {
		//Correct Pkt Received
		if (pInCmd != NULL) {
			m_csHtdCmdList.lock();
			m_listHtdCmd.append(pInCmd);
			m_csHtdCmdList.lock();
		}
	}
#ifdef DBG_FILE_LOG_FTS_DBG_ENABLE
	strDbgMsg = QString::asprintf(_T("::AddHtdCmdToQueue END bRet %d"), bRet);
	LogDebugMessage(strDbgMsg);
	#endif
	return bRet;
}
CHtDataCmd* CEFileTransferSocket::GetHtdCmdFromQueue() {
	CHtDataCmd *pCmd = NULL;
	m_csHtdCmdList.lock();
	if (!m_listHtdCmd.isEmpty()) {
		pCmd = m_listHtdCmd.removeFirst(); //Remove from queue and pass ont the next layer
	}
	m_csHtdCmdList.lock();
	return pCmd;
}
void CEFileTransferSocket::CleanHtdCmds() {
	m_csHtdCmdList.lock();
	while (!m_listHtdCmd.isEmpty()) {
		CHtDataCmd *pCmd = m_listHtdCmd.removeFirst();
		if ( FALSE == pCmd->IsCompleted()) {
			pCmd->Abort();
		}
		delete pCmd;
	}
	m_csHtdCmdList.lock();
}
#ifdef DBG_FILE_LOG_FTS_DBG_ENABLE
void CEFileTransferSocket::LogDebugMessage(QString   strDebugMsg)
{
	if( NULL != m_pDebugFileLogger )
	{
		QString   strDiagMsg;
		strDiagMsg = QString::asprintf(_T("FTSock- %s"), strDebugMsg);
		CV7SecureSocket::LogDebugMessage(strDiagMsg);
	}
}
#endif

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  FileTransfer 
/// @n Filename:  HtDataCommand.h
/// @n Description: This file has the HtData commands hierarchy
///
// **************************************************************************
// Revision History
//	Shankar Rao P 16/Sep/2019 HtData Command Definition
// **************************************************************************
#if !defined(AFX_HT_DATA_COMMAND_H__)
#define AFX_HT_DATA_COMMAND_H__
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "V7DbgLogDefines.h"
#include "CStorage.h"
#include "CESecureSocket.h"
#include "V7TLSServCleComm.h"
#include "TV6Timer.h"
typedef union U_HTD_DATA_LEN {
	ULONG ulLen;
	USHORT usLen[2];
	BYTE byLen[4];
	CHAR chLen[4];
} UCmdPcktLen;
typedef UCmdPcktLen UHtdFileLen;
typedef UCmdPcktLen UHtdFileListLen;
typedef UCmdPcktLen UHtdRespDataLen;
#define MAX_HTD_FILE_PATH_LEN 256
#define HTD_UFR_CHUNK_SIZE 800 // for smaller file req-send part of cmd only
#define HTD_GFR_CHUNK_SIZE 1100 // for smaller data chunks
#define HTD_RESP_CHUNK_SIZE 1260 // for smaller data chunks
#define HTD_DATA_CHUNK_SIZE V7_TLS_MAX_MSG_SIZE ///16000 Excluding the TLS headers in TLS record of 16384
class CHtDataCmd {
public:
	enum EHtdCmdType {
		HTD_CMD_UPLOAD_FILE_REQUEST = 1, //UploadFile File Request
		HTD_CMD_GET_FILE_REQUEST, // GetFile Request
		HTD_CMD_GET_FILE_LIST_REQUEST, //GetFileList Request
		HTD_CMD_RESP_ACK_DETAILS,	//Send Ack/Nack/RespLen details
		HTD_CMD_RESP_DATA,	//The Response Data Packet 
		HTD_CMD_RESP_DATA_EX,	//The Response Data Packet extended
		HTD_CMD_LAST,
	}; //These are the commands but Client Requests these and Server Responds to these
	//! Possible socket command states
	enum ECmdState {
		CMD_ST_IDLE = 0, CMD_ST_WAIT_ACK, CMD_ST_ACCEPTED, CMD_ST_BEGIN, CMD_ST_END, CMD_ST_REJECTED, CMD_ST_EXPIRED
	};
	enum ECmdRespStatus {
		CMD_RESP_ST_WAIT = 0, CMD_RESP_ST_ACK, CMD_RESP_ST_NACK, CMD_RESP_ST_TIMEOUT, CMD_RESP_ST_ABORTED
	};
	enum ECmdDisha {
		CMD_DISHA_NONE = 0, CMD_DISHA_INCOMING, CMD_DISHA_OUTGOING
	};
	typedef enum E_HTD_CMD_RESP_CODE {
		HTD_CMD_RESP_CODE_NONE = 0,
		HTD_CMD_RESP_CODE_ACK = 1,
		HTD_CMD_RESP_CODE_NACK = 2,
		HTD_CMD_RESP_CODE_INITIAL_PKT = 3,
	} EHtdCmdRespCode;
	typedef union U_HTD_CMD_HEADER {
		typedef struct S_HTD_CMD_HEADER {
			BYTE byAppId;
			BYTE byHtdCmdType;
			BYTE byExpectedRespType;
			BYTE byEOT;
			UCmdPcktLen uCmdPcktLen;
		} SHtdCmdHeader;
		SHtdCmdHeader sCmdHeader;
		BYTE byByes[sizeof(SHtdCmdHeader)];
	} UHtdCmdHeader;
	union UHtdCmdRespAck {
		typedef struct S_HTD_CMD_RESP_ACK {
			CHtDataCmd::UHtdCmdHeader uCmdHeader;
			EHtdCmdRespCode eCmdRespCode;
			UHtdRespDataLen uTotalDataLen; //This is total Len
			UHtdRespDataLen uCurChunkLen;	//
			char chDataBuf[HTD_RESP_CHUNK_SIZE];
		} SHtdCmdRAck;
		SHtdCmdRAck sCmdRAck;
		BYTE byBytes[sizeof(SHtdCmdRAck)];
	};
public:
	CHtDataCmd(EHtdCmdType eCmdType, ECmdDisha eCmdDisha);
	virtual ~CHtDataCmd();
public:
	EHtdCmdType GetCmdType() const {
		return m_eCmdType;
	}
	ECmdDisha GetCmdDisha() const {
		return m_eCmdDisha;
	}
	ECmdState getCmdState() const {
		return m_eCmdState;
	}
	ECmdRespStatus getCmdRespStatus() const {
		return m_eCmdRespStatus;
	}
	ULONG getCmdHeaderLen() const {
		return sizeof(UHtdCmdHeader);
	}
	BOOL IsCompleted();
	BOOL IsExpired();
	BOOL Begin();
	void Abort();
	void End();
	virtual ULONG GetCmdPktLen() = 0;
	virtual const BYTE* GetCmdPktBytes() = 0;
	virtual UHtdCmdHeader* GetCmdHeader() {
		return NULL;
	}
	virtual BOOL ProcessRespCmd(CHtDataCmd *pRespCmd);
	int Send(CCESecureSocket *pSock);
	void EndAndNotify(bool bFileIsOpen, bool bNotify = false);
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	void SetDebugLogger(CDebugFileLogger* pDbgFileLogger);
#endif
protected:
	virtual BOOL Execute() = 0;
	virtual void ResetPkt() = 0;
	BOOL PrepareHdr(UHtdCmdHeader *pCmdHeader);
	virtual bool Validate();
	virtual BOOL End(ECmdState eCmdState);
	BOOL WaitForCmdResp(const DWORD dwTIMEOUT_FOR_WFMO);
	BOOL WaitAndGetAck();
	int SendRAck(const UHtdCmdRespAck *puCmdRAck);
	int SendRAck(EHtdCmdRespCode, ULONG ulRepLen = 0L);
	int SendRData(char *pDataBuf, ULONG ulRepLen);
	void RefreshTimer();
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	void LogDebugMessage(QString   strDebugMessage);
#endif
protected:
	EHtdCmdType m_eCmdType;
	ECmdDisha m_eCmdDisha;
	ECmdState m_eCmdState;
	ECmdRespStatus m_eCmdRespStatus;
	CStorage *m_pFile;
	//Timer for the command
	CTV6Timer m_cmdTimer;	//Timer to maintain the lifetime of the cmd
public:
	static const USHORT m_usCmdPckSize;
protected:
	static const ULONG m_ulCmdExpiryInMilliSeconds;
protected:
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	CDebugFileLogger* m_pDebugFileLogger;
#endif
};
class CCmdRespAck: public CHtDataCmd {
public:
	//Align 4 bytes
	CCmdRespAck(ECmdDisha eCmdDisha);
	CCmdRespAck(ECmdDisha eCmdDisha, const UHtdCmdRespAck::SHtdCmdRAck &sCmdRAck);
	~CCmdRespAck();
public:
	virtual ULONG GetCmdPktLen();
	virtual const BYTE* GetCmdPktBytes();
	EHtdCmdRespCode GetCmdRespCode() const {
		return m_uCmdRAck.sCmdRAck.eCmdRespCode;
	}
	ULONG GetRespDataLen() const {
		return m_uCmdRAck.sCmdRAck.uTotalDataLen.ulLen;
	}
	const UHtdCmdRespAck& GetURAck() const {
		return m_uCmdRAck;
	}
protected:
	virtual BOOL Execute();
	virtual void ResetPkt();
	virtual bool Validate();
	virtual UHtdCmdHeader* GetCmdHeader();
private:
	UHtdCmdRespAck m_uCmdRAck;
};
class CCmdRespData: public CHtDataCmd {
public:
	//Align 4 bytes
	union UHtdCmdRespData {
		typedef struct S_HTD_CMD_RESP_DATA {
			CHtDataCmd::UHtdCmdHeader uCmdHeader;
			UHtdRespDataLen uRDataLen;
			char chDataBuf[HTD_RESP_CHUNK_SIZE];
		} SHtdCmdRData;
		SHtdCmdRData sCmdRData;
		BYTE byBytes[sizeof(SHtdCmdRData)];
	};
public:
	CCmdRespData(ECmdDisha eCmdDisha, EHtdCmdType eCmdType = HTD_CMD_RESP_DATA);
	CCmdRespData(ECmdDisha eCmdDisha, const UHtdCmdRespData::SHtdCmdRData &sCmdRData);
	~CCmdRespData();
public:
	virtual ULONG GetCmdPktLen();
	virtual const BYTE* GetCmdPktBytes();
	virtual const char* GetRespDataBuf() const {
		return m_uCmdRData.sCmdRData.chDataBuf;
	}
	virtual ULONG GetRespDataLen() const {
		return m_uCmdRData.sCmdRData.uRDataLen.ulLen;
	}
protected:
	virtual BOOL Execute();
	virtual bool Validate();
	virtual void ResetPkt();
	virtual UHtdCmdHeader* GetCmdHeader();
private:
	UHtdCmdRespData m_uCmdRData;
};
class CCmdRespDataEx: public CHtDataCmd {
public:
	//Align 4 bytes
	union UHtdCmdRespDataEx {
		typedef struct S_HTD_CMD_RESP_DATA_EX {
			CHtDataCmd::UHtdCmdHeader uCmdHeader;
			UHtdRespDataLen uRDataLen;
			char chDataBuf[HTD_DATA_CHUNK_SIZE];
		} SHtdCmdRData;
		SHtdCmdRData sCmdRData;
		BYTE byBytes[sizeof(SHtdCmdRData)];
	};
public:
	CCmdRespDataEx(ECmdDisha eCmdDisha);
	CCmdRespDataEx(ECmdDisha eCmdDisha, const char *pDataBuf, int nLen);
	CCmdRespDataEx(ECmdDisha eCmdDisha, UHtdCmdRespDataEx *puHtdCmdRDataEx);
	~CCmdRespDataEx();
public:
	virtual ULONG GetCmdPktLen();
	virtual const BYTE* GetCmdPktBytes();
	const char* GetRespDataBuf() const;
	ULONG GetRespDataLen() const;
protected:
	virtual BOOL Execute();
	virtual bool Validate();
	virtual void ResetPkt();
	virtual UHtdCmdHeader* GetCmdHeader();
private:
	UHtdCmdRespDataEx *m_puCmdRDataEx;
};
//Get File List Request Command
class CGetFileListRequestCmd: public CHtDataCmd {
public:
	//Align 4 bytes
	typedef union UGetFileListRequestCmd {
		typedef struct S_HTD_GFL_CMD_REQ {
			CHtDataCmd::UHtdCmdHeader uCmdHeader;
			CHAR chFolderPath[MAX_HTD_FILE_PATH_LEN];
			UHtdFileLen uChunkLen;
			char chFileBuf[HTD_GFR_CHUNK_SIZE];
		} SHtdCmdGFLRequest;
		SHtdCmdGFLRequest sCmdGFLReq;
		BYTE byBytes[sizeof(SHtdCmdGFLRequest)];
	} UHtdGFLReqCmd;
public:
	CGetFileListRequestCmd(ECmdDisha eCmdDisha, const UHtdGFLReqCmd::SHtdCmdGFLRequest &sCmdGFLRequest);
	CGetFileListRequestCmd(ECmdDisha eCmdDisha, QString strFolderPath);
	~CGetFileListRequestCmd();
public:
	virtual ULONG GetCmdPktLen();
	virtual const BYTE* GetCmdPktBytes();
	virtual BOOL ProcessRespCmd(CHtDataCmd *pRespCmd);
	const QString GetFileListReceived() const {
		return m_strFileList;
	}
protected:
	virtual BOOL Execute();
	virtual void ResetPkt();
	virtual bool Validate();
	virtual UHtdCmdHeader* GetCmdHeader();
	BOOL PrepareToSend();	//CMD_DISHA_INCOMING (ACK/Len outgoes)
	BOOL SendInitialPkt();
	BOOL SendDataChunk(); //CMD_DISHA_INCOMING (data outgoes)
	BOOL GetFileList(QString strFolderPath, QString &strFileList, QString strDelim);
	BOOL PrepareToReceive(); //CMD_DISHA_OUTGOING
	BOOL RecvStateMachine(const CHtDataCmd *pRespCmd); //CMD_DISHA_OUTGOING
	BOOL ProcessCmdRAck(const CHtDataCmd *pRespCmd); //CMD_DISHA_OUTGOING
	BOOL RecvInitialPkt(const CCmdRespAck *pRespInitPkt);
	BOOL RecvDataChunk(const char *pDataBuf, ULONG ulLen);
private:
	UHtdGFLReqCmd m_uCmdGFLReq;
	QString m_strFolderPath; //CMD_DISHA_INCOMING
	QString m_strFileList; //CMD_DISHA_OUTGOING
	UHtdFileListLen m_uFileListBytesTransceived; //CMD_DISHA_OUTGOING
	UHtdFileListLen m_uFileListBytesExpected; //CMD_DISHA_OUTGOING
	char m_chDataChunk[HTD_DATA_CHUNK_SIZE];
};
//GetFile Request Cmd
class CGetFileRequestCmd: public CHtDataCmd {
public:
	//Align 4 bytes
	typedef union UGetFileRequestCmd {
		typedef struct S_HTD_GFL_CMD_REQ {
			CHtDataCmd::UHtdCmdHeader uCmdHeader;
			CHAR chFilePath[MAX_HTD_FILE_PATH_LEN];
			UHtdFileLen uChunkLen;
			char chFileBuf[HTD_GFR_CHUNK_SIZE];
		} SHtdCmdGFRequest;
		SHtdCmdGFRequest sCmdGFReq;
		BYTE byBytes[sizeof(SHtdCmdGFRequest)];
	} UHtdGFReqCmd;
public:
	CGetFileRequestCmd(ECmdDisha eCmdDisha, const UHtdGFReqCmd::SHtdCmdGFRequest &sCmdGFRequest);
	CGetFileRequestCmd(ECmdDisha eCmdDisha, QString remotefName, QString localfName, bool bOverWrite);
	~CGetFileRequestCmd();
public:
	virtual ULONG GetCmdPktLen();
	virtual const BYTE* GetCmdPktBytes();
	virtual BOOL ProcessRespCmd(CHtDataCmd *pRespCmd);
protected:
	virtual BOOL Execute();
	virtual void ResetPkt();
	virtual bool Validate();
	virtual UHtdCmdHeader* GetCmdHeader();
	BOOL PrepareToSend(); //CMD_DISHA_INCOMING (ACK/Len outgoes)
	BOOL SendInitialPkt();
	BOOL SendDataChunk(); //CMD_DISHA_INCOMING (data outgoes)
	BOOL PrepareToReceive(); //CMD_DISHA_OUTGOING
	BOOL RecvStateMachine(const CHtDataCmd *pRespCmd); //CMD_DISHA_OUTGOING
	BOOL ProcessCmdRAck(const CHtDataCmd *pRespCmd);
	BOOL RecvInitialPkt(const CCmdRespAck *pRespInitPkt);
	BOOL CreateRecvFile(QString strFileName, bool bOverWrite, QFile *destFile); //CMD_DISHA_OUTGOING
private:
	UHtdGFReqCmd m_uCmdGFReq;
	QString m_strRemoteFileName; //CMD_DISHA_INCOMING/OUTGOING
	QString m_strLocalFileName; //CMD_DISHA_OUTGOING
	bool m_bOverWrite; //CMD_DISHA_OUTGOING
	UHtdFileLen m_uFileBytesTransceived; //CMD_DISHA_OUTGOING
	UHtdFileLen m_uFileBytesExpected; //CMD_DISHA_OUTGOING
	char m_chDataChunk[HTD_DATA_CHUNK_SIZE];
};
class CUploadFileRequestCmd: public CHtDataCmd {
public:
	//Align 4 bytes
	typedef union UHtdUploadFileRequestCmd {
		typedef struct S_HTD_UF_CMD_REQ {
			CHtDataCmd::UHtdCmdHeader uCmdHeader;
			CHAR chInterimFileName[MAX_HTD_FILE_PATH_LEN];
			CHAR chFinalFileName[MAX_HTD_FILE_PATH_LEN];
			UHtdFileLen uFileLen;
			UHtdFileLen uChunkLen;
			char chFileBuf[HTD_UFR_CHUNK_SIZE];
		} SHtdCmdUFRequest;
		SHtdCmdUFRequest sCmdUFReq;
		BYTE byBytes[sizeof(SHtdCmdUFRequest)];
	} UHtdUFRequestCmd;
public:
	CUploadFileRequestCmd(ECmdDisha eCmdDisha, const UHtdUFRequestCmd::SHtdCmdUFRequest &sCmdUFRequest,
			QString strLocalFileName = QString(""));
	CUploadFileRequestCmd(ECmdDisha eCmdDisha, QString strLocalFileName, QString strRemoteInterimFName,
			QString strRemoteActualFName);
	~CUploadFileRequestCmd();
public:
	virtual ULONG GetCmdPktLen();
	virtual const BYTE* GetCmdPktBytes();
	BOOL ProcessRespCmd(CHtDataCmd *pRespCmd);
protected:
	virtual BOOL Execute();
	virtual void ResetPkt();
	virtual bool Validate();
	virtual UHtdCmdHeader* GetCmdHeader();
	BOOL PrepareToSend(); //SEND Data
	BOOL SendInitialPkt(); //CMD_DISHA_INCOMING (data outgoes)
	BOOL SendDataChunk(); //CMD_DISHA_INCOMING (data outgoes)
	BOOL PrepareToReceive(); //
	BOOL RecvStateMachine(const CHtDataCmd *pRespCmd);
	BOOL Finish();
private:
	UHtdUFRequestCmd m_uCmdUFReq;
	QString m_strLocalFileName; //CMD_DISHA_INCOMING/OUTGOING
	QString m_strRemoteActualFPath; //CMD_DISHA_INCOMING/OUTGOING
	QString m_strRemoteInterimFPath; //CMD_DISHA_INCOMING/OUTGOING
	UHtdFileLen m_uFileBytesTransceived; //CMD_DISHA_OUTGOING
	UHtdFileLen m_uFileBytesExpected; //CMD_DISHA_OUTGOING
	char m_chDataChunk[HTD_DATA_CHUNK_SIZE];
};
//A light weight wrapper to parse and create cmd objs from incoming data
class CHtDtCmdHelper {
public:
	CHtDtCmdHelper(CDebugFileLogger *m_pDebugFileLogger = NULL);
	~CHtDtCmdHelper();
	BOOL ParseCmdPkt(const char *buf, UINT unLen, CHtDataCmd **ppHtdCmd);
private:
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	void LogDebugMessage(QString   strDebugMessage);
#endif
private:
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	CDebugFileLogger* m_pDebugFileLogger;
#endif
};
typedef union U_HTD_CMD_GEN_PKT {
	CHtDataCmd::UHtdCmdHeader uCmdHeader;
	CGetFileRequestCmd::UHtdGFReqCmd uCmdGFR;
	CGetFileListRequestCmd::UHtdGFLReqCmd uCmdGFLR;
	CUploadFileRequestCmd::UHtdUFRequestCmd uCmdUFR;
	CCmdRespAck::UHtdCmdRespAck uCmdRAck;
} UHtdCmdGenericPkt;
#endif //AFX_HT_DATA_COMMAND_H__

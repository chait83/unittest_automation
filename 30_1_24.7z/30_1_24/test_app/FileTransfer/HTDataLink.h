//////////////////////////////////////////////////////////////////////
/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		HTDataServer
/// @n Filename:  HTDataLink.h
/// @n Description: Declaration of the CHTDataLink class
///
// **************************************************************************
// Revision History
// **************************************************************************
#ifndef __HTDATALINK_H_
#define __HTDATALINK_H_
#pragma comment(lib, "comsuppw.lib")
//#include "SecureSocket.h"
#include <string.h>
#include "CStorage.h"
using namespace std;
const int RESPONSE_DATA_TYPE_REALTIME = 0x0A;
const int RESPONSE_DATA_TYPE_ALARMS = 0x0B;
const int RESPONSE_DATA_TYPE_EVENTS = 0x0C;
const int RESPONSE_SET_CONFIGURATION_ACK = 0x0D;
const int RESPONSE_WRITE_DATA_ACK = 0x0E;
class CSecureSocket;
class CHTDataLink /*: public CComObjectRootEx<CComSingleThreadModel>*/
{
	enum EFileTransferCommand {
		CMD_NONE = 0, CMD_UPLOAD_FILE, CMD_GET_FILE, CMD_GET_FILE_LIST
	};
	//! Possible socket command states
	enum ECmdState {
		CMD_ST_IDLE = 0, CMD_ST_ACCEPTED, CMD_ST_BEGIN, CMD_ST_END, CMD_ST_REJECTED
	};
public:
	// Constructor
	CHTDataLink();
	//Destructor
	~CHTDataLink();
	//Starts the Data Link
	void Start();
	bool OnReceive(int clientId, BYTE *buf, int bytesRead);
	bool ProcessGetFileRequest(const QString Array &saCmdArgs);bool ProcessGetFileListRequest(const QString Array &saCmdArgs);bool ProcessUploadFileRequest(const QString Array &saCmdArgs);
	BOOL SendFile(QString fName);
	BOOL SendFileList(QString strFolderPath);
	BOOL GetFileList(QString strFolderPath, QString &strFileList, QString strDelim = QString(" "));
	BOOL ExecuteCmd(char *buf, int bytesRead);
	BOOL UploadStateMachine(char *buf, int bytesRead);
	void ResetCmd();
	BOOL ParseCommandPacket(char *buf, int nBufLen, QString Array &saCommandParams);
#ifdef DFL_HTD_LINK_DBG_ENABLE
	static void LogDebugMessage(QString   strDebugMessage);
#endif
private:
	int m_ClientId; /// Client Id
	CSecureSocket *m_pHTDataSocket; /// Pointer to data socket
	EFileTransferCommand m_ePrevFTCmd;
	EFileTransferCommand m_eCurFTCmd;
	ECmdState m_eCmdState;
	QString m_strUploadFilePathInterim;
	QString m_strUploadFilePathFinal;
	ULONG m_ulFileLen;
	ULONG m_ulFileBytesRcvd;
	CStorage *m_pUploadFile;
#ifdef DFL_HTD_LINK_DBG_ENABLE
	static CDebugFileLogger m_debugFileLogger;
#endif
};
#endif

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  FileTransfer 
/// @n Filename:  HtDataTransferEngine.cpp
/// @n Description: This class is responsible for Historical Data Transfer thru TCP sockets
///
// **************************************************************************
// Revision History
// Shankar Rao P 17/Sep/2019 Initial Draft
// **************************************************************************
#include "HtDataTransferEngine.h"
#include "HtDataCommand.h"
#define MODEL_NO 01
#define SET_INFO 02
#define MODEL_TYPE 03
#define TRACE_ALLOW
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
#ifdef UNDER_CE
CDebugFileLogger CHtDataTransferEngine::m_debugFileLogger(_T("\\SDMemory\\HtDtEngineDbgLogFile.txt"), FALSE, (10*1024*1024));
#else
CDebugFileLogger CHtDataTransferEngine::m_debugFileLogger(_T("C:\\ProgramData\\TMS\\HtDtEngineDbgLogFile.txt"), FALSE, (15*1024*1024));
#endif
#endif
//Initialize the static Objects
CHtDataTransferEngine *CHtDataTransferEngine::m_pInstance = NULL;
QMutex m_CreationMutex;
//****************************************************************************
/// CHtDataTransferEngine - Constructor
///
/// @param n/a
///
/// @return		n/a
///
//****************************************************************************
CHtDataTransferEngine::CHtDataTransferEngine() : m_eHtdMode(HTD_MODE_NOT_SET), m_eHtdSTMode(
		CCESecureSocket::ST_MODE_NOT_SET), m_hHtDTEInit(NULL), m_bInitialised(FALSE), m_usTcpPort(5359), m_hHtDtListenerThread(
NULL), m_pHtDtThread(NULL), m_pCurHtdCmd(NULL), m_pHtdListenSock(NULL), m_pHtDataSocket(NULL), m_nContinuousTimeOutCnt(
		0), m_pEvents(NULL), m_hCmdProcEvent(NULL), m_hHtCmdProcessThread(NULL)
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
, m_pDebugFileLogger(NULL)
#endif
{
	for (int nCnt = HTD_SHUTDOWN; nCnt < HTD_NUM_EVENTS; nCnt++) {
		m_hEvents[nCnt] = NULL;
	}
	m_pEvents = &m_hEvents[0]; //Init to the standard event set
	m_iEventCount = HTD_NUM_EVENTS;
	QMutex * m_csConnList; //right now only one connection at a time
	QMutex * m_csEvents;
	QMutex * m_csRespDataEx;
	m_hCmdRespEv = NULL;
	//Initialize
	memset(m_uHtdCmdRespDataEx.byBytes, 0, sizeof(m_uHtdCmdRespDataEx));
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	SetDebugLogger(&m_debugFileLogger);
	#endif
} //end CEFileTransferSocket()
//****************************************************************************
/// ~CHtDataTransferEngine - Destructor
///
/// @param n/a
///
/// @return		n/a
///
//****************************************************************************
CHtDataTransferEngine::~CHtDataTransferEngine() {
	//deletion of mutex not required
	//deletion of mutex not required
	if (m_pEvents != &m_hEvents[0]) {
		delete[] m_pEvents;
		m_pEvents = NULL;
	}
	if (m_hCmdRespEv) {
		//No need to close the mutex in Qt
		m_hCmdRespEv = NULL;
	}
} //end ~CHtDataTransferEngine()
//****************************************************************************
/// The first time this function is called it will create the single instance
/// of CHtDTEngine, Subsequent calls will return the Pointer to the instance
/// which has already been created.  
///
/// @param[in] 	  - None
///
/// @return Pointer to the HtDTEngine
/// 
//****************************************************************************
CHtDataTransferEngine* CHtDataTransferEngine::GetHandle() {
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;
	if (NULL == m_pInstance) {
		// An instance has yet to be completed
		m_CreationMutex = CreateMutex(NULL,					  // No security descriptor
				FALSE,					  // Mutex object not owned
				TEXT("HtDTEngine"));	  // Object name
		waitSingleObjectResult = m_CreationMutex.tryLock(2000);
		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:
			// Object was signaled
			if (NULL == m_pInstance) {
				m_pInstance = new CHtDataTransferEngine();
			} // End of IF
			if ( FALSE == m_CreationMutex.unlock()) {
#if (defined( _UNICODE) ) && (! defined (UNDER_CE))
					//CV6MessageBoxDlg Dlg(_T("Error"),_T("P2PEngine not started Error - Mutex exists!"));
					//Dlg.exec();
#else
				QMessageBox(_T("HtDTEngine not started Error"), MB_OK);
#endif
			} // End of IF
			break;
		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
#if (defined( _UNICODE)) && (defined (UNDER_CE))
				//CV6MessageBoxDlg Dlg(_T("Error"),_T("HtDTEngine WaitForSingleObject Error"));
				//Dlg.exec();
#else
			QMessageBox(_T("HtDTEngine WaitForSingleObject Error"), MB_OK);
#endif
			break;
		} // End of SWITCH 
		// Close the Mutex as no longer required
		//No need to close the mutex in Qt
	} // End of IF 
	return (m_pInstance);
}
//****************************************************************************
/// InitHTDTEngine - Initialize 
///
/// @param n/a
///
/// @return		true if successful
///
//****************************************************************************
T_HTDTE_INIT_RETURN CHtDataTransferEngine::InitHTDTEngine(EHtdMode eHtdMode,
		CCESecureSocket::ESocketTransMode eSTMode) {
	T_HTDTE_INIT_RETURN eRet = HTDTE_INIT_OK;
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	QString   strDbgMsg;
	strDbgMsg = QString::asprintf(_T("InitHTDTEngine BEGIN"));
	LogDebugMessage(strDbgMsg);
	#endif
	if ( FALSE == m_bInitialised) {
		m_eHtdMode = eHtdMode;
		m_eHtdSTMode = eSTMode;
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
		strDbgMsg = QString::asprintf(_T("InitHTDTEngine Mode %d STMode %d"), eHtdMode, eSTMode);
		LogDebugMessage(strDbgMsg);
		#endif
	} else {
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
		strDbgMsg = QString::asprintf(_T("InitHTDTEngine Already Initialized"));
		LogDebugMessage(strDbgMsg);
		#endif
		eRet = HTDTE_ALREADY_INITED;
		return eRet;
	}
	//make sure this isn't running elsewhere in the system
	//GUID Created for uniqueness{198FE2A0-41AD-4d9a-A32E-F69D4B3C31C5}
	m_hHtDTEInit = CreateMutex(NULL, FALSE, _T("HTDTE-198FE2A0-41AD-4d9a-A32E-F69D4B3C31C5"));
	DWORD err = GetLastError();
	if (ERROR_ALREADY_EXISTS != err && ERROR_ACCESS_DENIED != err) {
		int retVal = 0;
		WSADATA wsaData;
		retVal = WSAStartup(0x0202, &wsaData);
		if (retVal) {
			//failure
			eRet = HTDTE_INIT_WINSOCK_ERR;
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
			strDbgMsg = QString::asprintf(_T("InitHTDTEngine Winsok init failed"));
			LogDebugMessage(strDbgMsg);
			#endif
		} else {
			//Common Events between Client Mode/ Server Mode
			m_hEvents[HTD_SHUTDOWN] = CreateEvent(NULL, TRUE, FALSE, _T("HtdShutdown"));
			m_hEvents[HTD_TCP_CONN_CLOSE] = CreateEvent(NULL, FALSE, FALSE, _T("HtdTCPConnClose"));
			if (HTD_MODE_SERVER == m_eHtdMode) {
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
				strDbgMsg = QString::asprintf(_T("InitHTDTEngine Server Mode Init begin"));
				LogDebugMessage(strDbgMsg);
				#endif
				m_pHtdListenSock = new CEFileTransferSocket(m_eHtdSTMode);
#if (defined DBG_FILE_LOG_HTD_DBG_ENABLE) && (defined DBG_FILE_LOG_FTS_DBG_ENABLE)
				m_pHtdListenSock->SetDebugLogger(m_pDebugFileLogger);
				#endif
				//Create Listen Socket
				if (true == m_pHtdListenSock->Create()) {
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
					strDbgMsg = QString::asprintf(_T("InitHTDTEngine Creates Listen Sock"));
					LogDebugMessage(strDbgMsg);
					#endif
					//Set Socket ready for connections
					if (true == m_pHtdListenSock->Accept(m_usTcpPort, 2)) // total number change from 4 to 2
							{
						//Create the Cmd/Data Listening thread
						AddEvent(m_pHtdListenSock->GetAcceptEvHandle());
						//m_hEvents[HTD_TCP_ACCEPT_CONN] = m_pHtdListenSock->GetAcceptEvHandle();
						AddEvent(m_pHtdListenSock->GetCloseEvHandle());
						//m_hEvents[HTD_TCP_ACCEPT_CLOSE] = m_pHtdListenSock->GetCloseEvHandle();
						m_hAcceptedEv = m_pHtdListenSock->GetAcceptedEvHandle();
						//m_hEvents[HTD_TCP_SERV_FAIL] = CreateEvent(NULL,FALSE,FALSE,_T("HtdTCPServFail"));
						HANDLE hServFail = CreateEvent(NULL, FALSE, FALSE, _T("HtdTCPServFail"));
						AddEvent(hServFail);
						m_pHtdListenSock->SetFailedServEvent(hServFail);
						//Set The init flag
						m_bInitialised = TRUE;
					} else {
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
						strDbgMsg = QString::asprintf(_T("InitHTDTEngine Failed to set listen Sock in accept state so disconnect"));
						LogDebugMessage(strDbgMsg);
						#endif
						eRet = HTDTE_INIT_TCP_LISTEN_FAILED;
						m_pHtdListenSock->Disconnect();
					}
				} else {
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
					strDbgMsg = QString::asprintf(_T("InitHTDTEngine Failed to create listen Sock"));
					LogDebugMessage(strDbgMsg);
					#endif
					eRet = HTDTE_INIT_TCP_LISTEN_FAILED;
				}
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
				strDbgMsg = QString::asprintf(_T("InitHTDTEngine Server Mode Init End"));
				LogDebugMessage(strDbgMsg);
				#endif
			} else if (HTD_MODE_CLIENT == m_eHtdMode) {
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
				strDbgMsg = QString::asprintf(_T("InitHTDTEngine Client Mode Init begin"));
				LogDebugMessage(strDbgMsg);
				#endif
				m_bInitialised = TRUE;
				m_pHtDataSocket = new CEFileTransferSocket(m_eHtdSTMode);
#if (defined DBG_FILE_LOG_HTD_DBG_ENABLE) && (defined DBG_FILE_LOG_FTS_DBG_ENABLE)
				m_pHtDataSocket->SetDebugLogger(m_pDebugFileLogger);
				#endif 
				if (m_pHtDataSocket->Create()) {
					//Set The init flag
					m_bInitialised = TRUE;
				} else {
					eRet = HTDTE_INIT_TCP_CONN_FAILED;
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
					strDbgMsg = QString::asprintf(_T("InitHTDTEngine Failed to create Client Sock"));
					LogDebugMessage(strDbgMsg);
					#endif
				}
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
				strDbgMsg = QString::asprintf(_T("InitHTDTEngine Client mode init end"));
				LogDebugMessage(strDbgMsg);
				#endif
			}
			if ( TRUE == m_bInitialised) {
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
				strDbgMsg = QString::asprintf(_T("InitHTDTEngine Creating the HtDt Listener thread"));
				LogDebugMessage(strDbgMsg);
				#endif
				//start the CmdListener/DataTransfer thread
				m_hHtDtListenerThread = CreateThread(NULL, 0, CHtDataTransferEngine::HtDtListenThread, this, 0, NULL);
			}
		} //WinSOCK Level
	} else {
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
		strDbgMsg = QString::asprintf(_T("InitHTDTEngine Instance already exists"));
		LogDebugMessage(strDbgMsg);
		#endif
		eRet = HTDTE_INIT_INSTANCE_EXISTS;
	}
	if ((HTDTE_INIT_OK != eRet) && (eRet != HTDTE_INIT_INSTANCE_EXISTS) && (m_hHtDTEInit != NULL)) {
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
		strDbgMsg = QString::asprintf(_T("InitHTDTEngine Close Handle.. failed to init"));
		LogDebugMessage(strDbgMsg);
		#endif
		//No need to close the mutex in Qt
		m_hHtDTEInit = NULL;
	}
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	strDbgMsg = QString::asprintf(_T("InitHTDTEngine END eRet %d"), eRet);
	LogDebugMessage(strDbgMsg);
	#endif
	return eRet;
} //end Create()
BOOL CHtDataTransferEngine::Start(QString strIpAddr) {
	BOOL bRet = FALSE;
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	QString   strDbgMsg;
	strDbgMsg = QString::asprintf(_T("Start Begin Mode %d strIpAddr %s"), m_eHtdMode, strIpAddr);
	LogDebugMessage(strDbgMsg);
	#endif
	if (m_bInitialised) {
		if (HTD_MODE_SERVER == m_eHtdMode) {
			if (true == m_pHtdListenSock->ResumeAcceptThread()) {
				bRet = TRUE;
			}
		} else if (HTD_MODE_CLIENT == m_eHtdMode) {
			//Connect to the socket
			if (NULL != m_pHtDataSocket) {
				//Create an EVENt for Close and pass the event
				if (true == m_pHtDataSocket->Connect(strIpAddr, m_usTcpPort, m_hEvents[HTD_TCP_CONN_CLOSE])) {
					m_hCmdRespEv = m_pHtDataSocket->GetCmdRespEvHandle();
					AddEvent(m_pHtDataSocket->GetRecvEvHandle());
					bRet = TRUE;
					//Reset Timeout Count
					m_nContinuousTimeOutCnt = 0;
				}
			}
		};
	}
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	strDbgMsg = QString::asprintf(_T("Start END Mode %d bRet %d"), m_eHtdMode, bRet);
	LogDebugMessage(strDbgMsg);
	#endif
	return bRet;
}
BOOL CHtDataTransferEngine::Stop() {
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	QString   strDbgMsg;
	strDbgMsg = QString::asprintf(_T("Stop triggered Mode %d"), m_eHtdMode);
	LogDebugMessage(strDbgMsg);
	#endif
	return CleanUp();
}
//****************************************************************************
/// Cleanup - frees any allocated memory and resources  
///
/// @param[in] 	  - None
///
/// @return only TRUE ATM
/// @TODO - return something useful
/// 
//****************************************************************************
BOOL CHtDataTransferEngine::CleanUp(void) {
#ifdef TRACE_ALLOW
	qDebug("========================================Cleanup called\n");
#endif
	//stop the data processing thread
	SetEvent(m_hEvents[HTD_SHUTDOWN]);
	//test for the thread's exit code
	WaitForSingleObject(m_hHtDtListenerThread, INFINITE);
	if (m_hHtDtListenerThread) {
		//No need to close the mutex in Qt
		m_hHtDtListenerThread = NULL;
	}
	if (NULL != m_pHtDtThread) {
		m_pHtDtThread->PostThreadMessage(WM_QUIT, NULL, NULL);
		WaitForSingleObject(m_pHtDtThread->m_hThread, INFINITE);
		delete m_pHtDtThread;
		m_pHtDtThread = NULL;
	}
	if (HTD_MODE_SERVER == m_eHtdMode) {
		if (NULL != m_pHtdListenSock) {
			//stop the accepting sockets
			m_pHtdListenSock->Disconnect();
			m_pHtdListenSock->EraseTLSSerOnceAccept();
			delete m_pHtdListenSock;
			m_pHtdListenSock = NULL;
		}
	}
	//Clean the Cmd under execution if any
	ResetCmd();
	if (m_pHtDataSocket != NULL) {
		m_pHtDataSocket->Disconnect();
		delete m_pHtDataSocket;
		m_pHtDataSocket = NULL;
	}
	//close any accepted conns
	//T_ConnData* pconn;
	//m_csConnList.lock();
	/*while(m_connList.GetNumEntries())
	 {
	 pconn = m_connList.removeFirst();
	 pconn->pCSock->Disconnect();
	 delete pconn->pCSock;
	 delete pconn;
	 }*/
	//m_csConnList.lock();	
	WSACleanup();
	for (int count = HTD_SHUTDOWN; count < HTD_NUM_EVENTS; ++count) {
		if (m_hEvents[count]) {
			CloseHandle(m_hEvents[count]);
			m_hEvents[count] = NULL;
		}
	}
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	QString   strDbgMsg;
	strDbgMsg = QString::asprintf(_T("Cleanup END Mode %d"), m_eHtdMode);
	LogDebugMessage(strDbgMsg);
	#endif
	//No need to close the mutex in Qt
	m_hHtDTEInit = NULL;
	delete m_pInstance;
	m_pInstance = NULL;
	return ( TRUE);
}
//****************************************************************************
/// HtDtListenThread - HtDtListenThread
///
/// @param[in]	LPVOID - CHtDataTransferEngine pointer reference
/// @return		Thread Exit Code
///
//****************************************************************************
DWORD WINAPI CHtDataTransferEngine::HtDtListenThread(LPVOID pParam) {
	CHtDataTransferEngine *pParent = (CHtDataTransferEngine*) pParam;
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	QString   strDbgMsg;
	strDbgMsg = QString::asprintf(_T("HtDtListenThread BEGIN"));
	pParent->LogDebugMessage(strDbgMsg);
	#endif
	BOOL bRun = TRUE;
	DWORD dwRet = 0;
	const DWORD dwTIMEOUT_FOR_WFMO = 10000;
	const int nSocketTimeOutExpiry = 34; //One minute -->(nSocketTimeOutExpiry * dwTIMEOUT_FOR_WFMO)
	while (bRun) {
		//wait for the list of events generated by the FT Sockets
		dwRet = WaitForMultipleObjects(pParent->m_iEventCount, pParent->m_pEvents, FALSE, dwTIMEOUT_FOR_WFMO);
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	strDbgMsg = QString::asprintf(_T("WaitForMultipleObjects dwRet- 0x%lx"),dwRet);
	pParent->LogDebugMessage(strDbgMsg);
#endif
		if ((WAIT_TIMEOUT == dwRet) || (0x00000102L == dwRet)) {
			pParent->m_nContinuousTimeOutCnt++;
			//Do we need to close the socket? but when? what basis?
			if (pParent->m_nContinuousTimeOutCnt > nSocketTimeOutExpiry) {
				pParent->m_csConnList.lock();
				if (NULL != pParent->m_pHtDataSocket) {
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
					strDbgMsg = QString::asprintf(_T("HtDtLt WAIT_TIMEOUT m_nContinuousTimeOutCnt %d"), pParent->m_nContinuousTimeOutCnt);
					pParent->LogDebugMessage(strDbgMsg);
					#endif 
					//Doscinnect the connection if not already
					pParent->m_pHtDataSocket->Disconnect();
					pParent->m_nContinuousTimeOutCnt = 0;
				}
				pParent->m_csConnList.lock();
			}
		} else if (WAIT_FAILED == dwRet) {
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
			strDbgMsg = QString::asprintf(_T("HtDtLt WAIT_FAILED pParent->m_iEventCount %d err %lu"), pParent->m_iEventCount, GetLastError());
			pParent->LogDebugMessage(strDbgMsg);
			#endif 
			//Something went wrong with events .. 
			//lets clean the excess events in wait list
			pParent->CleanExcessEvents();
		} else if (dwRet < WAIT_OBJECT_0 + HTD_NUM_EVENTS) {
			switch (dwRet - WAIT_OBJECT_0) {
			case HTD_SHUTDOWN:
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
				strDbgMsg = QString::asprintf(_T("HtDtLt HTD_SHUTDOWN received "));
				pParent->LogDebugMessage(strDbgMsg);
				#endif 
				bRun = FALSE;
				break;
			case HTD_TCP_CONN_CLOSE:
				//find any disconnected sockets and remove from list
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
				strDbgMsg = QString::asprintf(_T("HtDtLt HTD_TCP_CONN_CLOSE received "));
				pParent->LogDebugMessage(strDbgMsg);
				#endif 
				pParent->PurgeConnList();
				break;
			default:
				break;
			}
		} else if ((dwRet < WAIT_OBJECT_0 + HTD_NUM_EX_EVENTS) && (HTD_MODE_SERVER == pParent->m_eHtdMode)) {
			switch (dwRet - WAIT_OBJECT_0) {
			case HTD_TCP_ACCEPT_CONN:
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
				strDbgMsg = QString::asprintf(_T("HtDtLt HTD_TCP_ACCEPT_CONN received m_nContinuousTimeOutCnt %d"), pParent->m_nContinuousTimeOutCnt);
				pParent->LogDebugMessage(strDbgMsg);
				#endif 
				//handle new inbound TCP connections
				if (HTD_MODE_SERVER == pParent->m_eHtdMode) {
					pParent->ProcessNewConn();
				}
				break;
			case HTD_TCP_ACCEPT_CLOSE:
				break;
			case HTD_TCP_SERV_FAIL: {
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
					strDbgMsg = QString::asprintf(_T("HtDtLt HTD_TCP_SERV_FAIL received "));
					pParent->LogDebugMessage(strDbgMsg);
					#endif
				if (HTD_MODE_SERVER == pParent->m_eHtdMode) {
					//have to re-start the server
					bool bRet = pParent->m_pHtdListenSock->Create();
					if (bRet) {
						bRet = pParent->m_pHtdListenSock->Accept(pParent->m_usTcpPort, 2);
						if (bRet) {
							//old handle will be closed so need a new one
							pParent->m_hAcceptedEv = pParent->m_pHtdListenSock->GetAcceptedEvHandle();
							//start the accept thread
							pParent->m_pHtdListenSock->ResumeAcceptThread();
						}
					}
				}
				break;
			}
			default:
				break;
			}
		} else {
			//Reset Timeout Count
			pParent->m_nContinuousTimeOutCnt = 0;
			if (dwRet < pParent->m_iEventCount) {
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
				strDbgMsg = QString::asprintf(_T("HtDtLt ReSet the event id %d"), dwRet);
				pParent->LogDebugMessage(strDbgMsg);
				#endif 
				ResetEvent(pParent->m_pEvents[dwRet]);
			}
			//Run StateMachines
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
			strDbgMsg = QString::asprintf(_T("HTDTLT WAIT_OBJECT_0 EventId %d "), dwRet);
			pParent->LogDebugMessage(strDbgMsg);
			#endif
			pParent->m_csRespDataEx.lock();
			pParent->ProcessIncomingData();
			pParent->m_csRespDataEx.lock();
		}
		//Check the cmd expiry and take approriate actions if expired
		if (NULL != pParent->m_pCurHtdCmd) {
			if (!pParent->m_pCurHtdCmd->IsCompleted()) {
				if ( TRUE == pParent->m_pCurHtdCmd->IsExpired()) {
					//End and Notify
					pParent->m_pCurHtdCmd->EndAndNotify(true, true);
					//Give time to Cmd to shutdown
					sleep(1000);
					//Do the clean up in server mode, for the clent mode EndAndNotify will trigger the 
					//Cmd exit and caller thread does ResetCmd
					if (HTD_MODE_SERVER == pParent->m_eHtdMode) {
						//Do the cleanup
						pParent->ResetCmd();
					}
				}
			}
		}
		sleep(1000);
	}
	//Do some cleanup
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	strDbgMsg = QString::asprintf(_T("HtDtListenThread END "));
	if( NULL != pParent )
	{
		pParent->LogDebugMessage(strDbgMsg);
	}
	#endif
	return 0;
}
void CHtDataTransferEngine::ProcessNewConn() {
	QAbstractSocket sockLastServiceSocket = m_pHtdListenSock->GetServiceSocket();
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	QString   strDbgMsg;
	strDbgMsg = QString::asprintf(_T("ProcessNewConn Begin sock %d"), sockLastServiceSocket);
	LogDebugMessage(strDbgMsg);
	#endif 
	if (m_pHtDataSocket != NULL) {
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
		strDbgMsg = QString::asprintf(_T("ProcessNewConn Already a client connection exist Reject the sock %d"), sockLastServiceSocket);
		LogDebugMessage(strDbgMsg);
		#endif
		//Already a client connection exist	 --Reject the existing
		shutdown(sockLastServiceSocket, SD_BOTH);
		closesocket(sockLastServiceSocket);
		SetEvent(m_hAcceptedEv);
	} else {
		//Reset Timeout Count
		m_nContinuousTimeOutCnt = 0;
		if (CCESecureSocket::ST_MODE_SECURE == m_eHtdSTMode) {
			m_pHtDataSocket = new CEFileTransferSocket(sockLastServiceSocket, CV7SecureSocket::SocketServer,
					m_pHtdListenSock->getCredHanle(), m_pHtdListenSock->getContextHandle());
			m_pHtDataSocket->SetBufferSize(SECURE_TCP_BUFFERSIZE);
			m_pHtdListenSock->EraseTLSSerOnceAccept();
		} else {
			m_pHtDataSocket = new CEFileTransferSocket(m_eHtdSTMode);
			m_pHtDataSocket->SetBufferSize(SECURE_TCP_BUFFERSIZE);
		}
#if (defined DBG_FILE_LOG_HTD_DBG_ENABLE) && (defined DBG_FILE_LOG_FTS_DBG_ENABLE)
		m_pHtDataSocket->SetDebugLogger(m_pDebugFileLogger);
		#endif 
		m_pHtDataSocket->AcceptServiceSocket(sockLastServiceSocket, m_hEvents[HTD_TCP_CONN_CLOSE]);
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
		strDbgMsg = QString::asprintf(_T("ProcessNewConn Accepted the sock %d"), sockLastServiceSocket);
		LogDebugMessage(strDbgMsg);
		#endif
		//Reset Timeout Count
		m_nContinuousTimeOutCnt = 0;
		m_hCmdRespEv = m_pHtDataSocket->GetCmdRespEvHandle();
		;
		AddEvent(m_pHtDataSocket->GetRecvEvHandle());
		SetEvent(m_hAcceptedEv);
		sleep(10);
		m_pHtDataSocket->ResumeReadThread();
	}
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	strDbgMsg = QString::asprintf(_T("ProcessNewConn End sock %d"), sockLastServiceSocket);
	LogDebugMessage(strDbgMsg);
	#endif
}
//****************************************************************************
/// PurgeConnList - tidy up the connection list of any connections that have closed
///
/// @param[in] 	none
///
/// @return void
/// @TODO return something useful
/// 
//****************************************************************************
void CHtDataTransferEngine::PurgeConnList() {
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	QString   strDbgMsg;
	strDbgMsg = QString::asprintf(_T("PurgeConnList Begin "));
	LogDebugMessage(strDbgMsg);
	#endif 
	//check the num of conns match the number of notification handles
	if (NULL != m_pHtDataSocket) {
		if (NULL != m_pHtDataSocket/*(m_iEventCount - HTD_NUM_EVENTS) > 0 */) {
			//Better Protect this
			if (m_pCurHtdCmd != NULL) {
				if (FALSE == m_pCurHtdCmd->IsCompleted()) {
					m_pCurHtdCmd->Abort();
					//Do we need to notify here?
					m_pCurHtdCmd->EndAndNotify(true, true);
				}
				sleep(1000);
				//Do the clean up in server mode, for the clent mode EndAndNotify will trigger the 
				//Cmd exit and caller thread does ResetCmd
				if (HTD_MODE_SERVER == m_eHtdMode) {
					delete m_pCurHtdCmd;
					m_pCurHtdCmd = NULL;
				}
			}
			if (m_pHtDataSocket->GetSocketState() <= CCESecureSocket::DISCONNECTING) {
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
				strDbgMsg = QString::asprintf(_T("PurgeConnList Delete event and then socket "));
				LogDebugMessage(strDbgMsg);
				#endif 
				//Delete the recv handle
				DeleteEvent(m_pHtDataSocket->GetRecvEvHandle());
				//Delete the cmd resp handle
				HANDLE hCmdResp = m_pHtDataSocket->GetCmdRespEvHandle();
				if (hCmdResp) {
					//No need to close the mutex in Qt
					if (m_hCmdRespEv == hCmdResp) {
						m_hCmdRespEv = NULL;
					} else {
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
						strDbgMsg = QString::asprintf(_T("PurgeConnList m_hCmdRespEv is different from the socket resp handle"));
						LogDebugMessage(strDbgMsg);
						#endif 
					}
				}
				delete m_pHtDataSocket;
				m_pHtDataSocket = NULL;
			} else {
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
				strDbgMsg = QString::asprintf(_T("PurgeConnList HtDatasocket no int DISCONNECTING state %d"), m_pHtDataSocket->GetSocketState());
				LogDebugMessage(strDbgMsg);
				#endif 
			}
		} else {
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
			strDbgMsg = QString::asprintf(_T("PurgeConnList Event count doesnot match "));
			LogDebugMessage(strDbgMsg);
			#endif 
		}
	} else {
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
		strDbgMsg = QString::asprintf(_T("PurgeConnListNo HtDataSocket to close"));
		LogDebugMessage(strDbgMsg);
		#endif 
	}
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	strDbgMsg = QString::asprintf(_T("PurgeConnList END "));
	LogDebugMessage(strDbgMsg);
	#endif 
}
//****************************************************************************
/// AddEvent - Add a connection read event to the event list that the thread waits on  
/// and resets the pointer to new data
///
/// @param[in] 	 HANDLE hEv - handle to be added
///
/// @return bool - false if new space cannot be allocated
/// 
//****************************************************************************
bool CHtDataTransferEngine::AddEvent(HANDLE hEv) {
	bool bRet = false;
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	QString   strDbgMsg;
	strDbgMsg = QString::asprintf(_T("AddEvent Begin hEv %X"), hEv);
	LogDebugMessage(strDbgMsg);
	#endif
	//allocate space for the now larger event list
	HANDLE *hTmp = new HANDLE[++m_iEventCount];
	if (hTmp) {
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
		strDbgMsg = QString::asprintf(_T("AddEvent hEv %X m_iEventCount %d"), hEv, m_iEventCount);
		LogDebugMessage(strDbgMsg);
		#endif
		m_csEvents.lock();
		//copy old list to new list
		//Fixed the access violation issue in the memcpy.
		memcpy(hTmp, m_pEvents, (m_iEventCount - 1) * sizeof(HANDLE));
		//free old memory if it's not the original static list
		if (m_pEvents != &m_hEvents[0]) {
			delete[] m_pEvents;
		}
		//set the pointer for WaitForMultipleObjects
		m_pEvents = hTmp;
		//add new handle to end of list
		m_pEvents[m_iEventCount - 1] = hEv;
		m_csEvents.lock();
		bRet = true;
	} else {
		bRet = false;
	}
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	strDbgMsg = QString::asprintf(_T("AddEvent End hEv %X"), hEv);
	LogDebugMessage(strDbgMsg);
	#endif
	return bRet;
}
//****************************************************************************
/// DeleteEvent - remove an event from the event list  
///
/// @param[in] 	 HANDLE hEv - handle to be deleted
///
/// @return bool - false if new space cannot be allocated, or handle not in list
/// 
//****************************************************************************
bool CHtDataTransferEngine::DeleteEvent(HANDLE hEv) {
	bool ret = true;
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	QString   strDbgMsg;
	strDbgMsg = QString::asprintf(_T("DeleteEvent Begin m_iEventCount %d hEv %X"), m_iEventCount, hEv);
	LogDebugMessage(strDbgMsg);
	#endif
	//find event in list
	int index = 0;
	while (index < m_iEventCount) {
		if (hEv == m_pEvents[index]) {
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
			strDbgMsg = QString::asprintf(_T("DeleteEvent Event found at index %d"), index);
			LogDebugMessage(strDbgMsg);
			#endif
			break;
		}
		++index;
	}
	//Get the number of events (default) for client/server mode
	int nDefEventCount = HTD_NUM_EVENTS;
	if (HTD_MODE_SERVER == m_eHtdMode) {
		nDefEventCount = HTD_NUM_EX_EVENTS;
	}
	if (index < m_iEventCount && index >= nDefEventCount) {
		//we've got it
		m_csEvents.lock();
		////Static Default are always HTD_NUM_EVENTS
		////HTD_NUM_EX_EVENTS are added as AddEvent but not to be removed
		if (--m_iEventCount == HTD_NUM_EVENTS) //i.e. this only occurs in client mode
				{
			//switch back to original data (default events)
			HANDLE *pTmp = m_pEvents;
			m_pEvents = &m_hEvents[0];
			delete[] pTmp;
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
			strDbgMsg = QString::asprintf(_T("DeleteEvent switch back to original data m_iEventCount %d"), m_iEventCount);
			LogDebugMessage(strDbgMsg);
			#endif
		} else {
			//need to re-allocate memory to avoid leaks
			HANDLE *phTmp = new HANDLE[m_iEventCount];
			if (phTmp) {
				//copy items below deleted item
				memcpy(phTmp, m_pEvents, index * sizeof(HANDLE));
				////EventCount is decremented in above condition so this evealuates to index+1 < m_iEventCount
				if (index < m_iEventCount) {
					//copy items above deleted item
					memcpy(&phTmp[index], &m_pEvents[index + 1], (m_iEventCount - index) * sizeof(HANDLE));
				}
				//delete old data
				delete[] m_pEvents;
				m_pEvents = phTmp;
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
				strDbgMsg = QString::asprintf(_T("DeleteEvent re-allocate events mem m_iEventCount %d"), m_iEventCount);
				LogDebugMessage(strDbgMsg);
				#endif
			} else //memory not available
			{
				ret = false;
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
				strDbgMsg = QString::asprintf(_T("DeleteEvent re-allocate failed m_iEventCount %d"), m_iEventCount);
				LogDebugMessage(strDbgMsg);
				#endif
			}
		}
		if (hEv) {
			//No need to close the mutex in Qt
		}
		m_csEvents.lock();
	} else //handle not in variable list
	{
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
		strDbgMsg = QString::asprintf(_T("DeleteEvent handle not in event list m_iEventCount %d"), m_iEventCount);
		LogDebugMessage(strDbgMsg);
		#endif
		ret = false;
	}
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
	strDbgMsg = QString::asprintf(_T("DeleteEvent End m_iEventCount %d ret %d"), m_iEventCount, ret);
	LogDebugMessage(strDbgMsg);
	#endif
	return ret;
}
//****************************************************************************
/// CleanExcessEvents - remove excess event from the event list if present any  
///
/// @param[in] 	 HANDLE hEv - handle to be deleted
///
/// @return bool - false if new space cannot be allocated, or handle not in list
/// 
//****************************************************************************
bool CHtDataTransferEngine::CleanExcessEvents() {
	bool bRet = true;
	//Get the number of events (default) for client/server mode
	int nDefEventCount = HTD_NUM_EVENTS;
	if (HTD_MODE_SERVER == m_eHtdMode) {
		nDefEventCount = HTD_NUM_EX_EVENTS;
	}
	//Clean if only excess events are present
	if (m_iEventCount > nDefEventCount) {
		m_csEvents.lock();
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
		QString   strDbgMsg;
		strDbgMsg = QString::asprintf(_T("CleanExcessEvents m_iEventCount %d begin"), m_iEventCount);
		LogDebugMessage(strDbgMsg);
		#endif
		while (m_iEventCount > nDefEventCount) {
			--m_iEventCount;
			int nIndex = m_iEventCount;
			if (m_pEvents[nIndex]) {
				CloseHandle(m_pEvents[nIndex]);
				m_pEvents[nIndex] = NULL;
			}
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
			strDbgMsg = QString::asprintf(_T("CleanExcessEvents cleaning m_iEventCount %d"), m_iEventCount);
			LogDebugMessage(strDbgMsg);
			#endif
		}
		////Static Default are always HTD_NUM_EVENTS
		////HTD_NUM_EX_EVENTS are added as AddEvent but not to be removed
		if (m_iEventCount == HTD_NUM_EVENTS) //i.e. this only occurs in client mode
				{
			//switch back to original data (default events)
			HANDLE *pTmp = m_pEvents;
			m_pEvents = &m_hEvents[0];
			delete[] pTmp;
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
			strDbgMsg = QString::asprintf(_T("CleanExcessEvents switch back to original data m_iEventCount %d"), m_iEventCount);
			LogDebugMessage(strDbgMsg);
			#endif
		} else {
			//need to re-allocate memory to avoid leaks
			HANDLE *phTmp = new HANDLE[m_iEventCount];
			if (phTmp) {
				//copy items below deleted item
				memcpy(phTmp, m_pEvents, m_iEventCount * sizeof(HANDLE));
				//delete old data
				delete[] m_pEvents;
				m_pEvents = phTmp;
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
				strDbgMsg = QString::asprintf(_T("CleanExcessEvents re-allocate events mem m_iEventCount %d"), m_iEventCount);
				LogDebugMessage(strDbgMsg);
				#endif
			} else //memory not available
			{
				bRet = false;
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
				strDbgMsg = QString::asprintf(_T("CleanExcessEvents re-allocate failed m_iEventCount %d"), m_iEventCount);
				LogDebugMessage(strDbgMsg);
				#endif
			}
		}
		m_csEvents.lock();
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
		strDbgMsg = QString::asprintf(_T("CleanExcessEvents m_iEventCount %d end"), m_iEventCount);
		LogDebugMessage(strDbgMsg);
		#endif
	}
	return bRet;
}
BOOL CHtDataTransferEngine::ProcessIncomingData() {
	BOOL bRet = FALSE;
#ifdef DBG_FILE_LOG_HTD_DBG_ENABLE
QString strDbgMsg;
strDbgMsg = QString::asprintf(_T("ProcessIncomingData BEGIN "));
LogDebugMessage(e(
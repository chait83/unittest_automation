/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 File Transfer
/// @n Filename: CHtFileTransferClient.cpp
/// @n Desc:	Implementation of CHtFileTransferClient
///
// ****************************************************************
// Revision History
// ****************************************************************
#include "HtFileTransferClient.h"
#include "HtDataTransferEngine.h"
//****************************************************************************
/// CHtFileTransferClient - Constructor
///
/// @param n/a
///
/// @return		n/a
///
//****************************************************************************
CHtFileTransferClient::CHtFileTransferClient() : m_unFileTransferPort(5359) {
} //end CHtFileTransferClient()
//****************************************************************************
/// ~CHtFileTransferClient - Destructor
///
/// @param n/a
///
/// @return		n/a
///
//****************************************************************************
CHtFileTransferClient::~CHtFileTransferClient() {
	//Shutdown(); //Lets clients handle the cleanup by calling shutdown
} //end ~CHtFileTransferClient() 
//****************************************************************************
/// Start - Starts the HtDTE Engine with connection to HtDataServer
///
/// @param n/a
///
/// @return		true if successful
///
//****************************************************************************
BOOL CHtFileTransferClient::Start(QString &strServerIpAddr) {
	BOOL bRet = FALSE;
	CHtDataTransferEngine *pHtDTE = CHtDataTransferEngine::GetHandle();
	if (pHtDTE != NULL) {
		if (FALSE == pHtDTE->IsInitialized()) {
			if (HTDTE_INIT_OK
					== pHtDTE->InitHTDTEngine(CHtDataTransferEngine::HTD_MODE_CLIENT,
							CCESecureSocket::ST_MODE_SECURE)) {
				bRet = pHtDTE->Start(strServerIpAddr);
				if (FALSE == bRet) {
					pHtDTE->Stop();
				}
			}
		}
	}
	return bRet;
} //end Start()
//****************************************************************************
/// GetHtDataConnection - Starts the thread for accepting connections
///
/// @param n/a
///
/// @return		return FileTrabsfer Socket ptr
///
//****************************************************************************
CHtFileTransferInterface* CHtFileTransferClient::GetHtDataConnection() {
	return this;
}
BOOL CHtFileTransferClient::Shutdown() {
	CHtDataTransferEngine *pHtDTE = CHtDataTransferEngine::GetHandle();
	pHtDTE->Stop();
	return TRUE;
}
BOOL CHtFileTransferClient::GetFileListFromRemoteSender(QString remotefName, QString &fileList) {
	BOOL bRet = FALSE;
	CHtDataTransferEngine *pHtDTE = CHtDataTransferEngine::GetHandle();
	if ( TRUE == pHtDTE->IsInitialized()) {
		bRet = pHtDTE->GetFileListFromRemoteSender(remotefName, fileList);
	}
	return bRet;
}
BOOL CHtFileTransferClient::GetFileFromRemoteSender(QString remotefName, QString localfName, bool bOverWrite) {
	BOOL bRet = FALSE;
	CHtDataTransferEngine *pHtDTE = CHtDataTransferEngine::GetHandle();
	if (TRUE == pHtDTE->IsInitialized()) {
		bRet = pHtDTE->GetFileFromRemoteSender(remotefName, localfName, bOverWrite);
	}
	return bRet;
}
BOOL CHtFileTransferClient::SendFileToRemoteRecipient(QString localfName, QString remoteinterfName,
		QString remoteactualfName) {
	BOOL bRet = FALSE;
	CHtDataTransferEngine *pHtDTE = CHtDataTransferEngine::GetHandle();
	if (TRUE == pHtDTE->IsInitialized()) {
		bRet = pHtDTE->SendFileToRemoteRecipient(localfName, remoteinterfName, remoteactualfName);
	}
	return bRet;
}

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  Secure Comm
/// @n Filename:  V7TlsClient.h
/// @n Description: TLS Client
///
// **************************************************************************
// Revision History
// **************************************************************************
// Project		Date			Team/Person			Comments
//	TVR211		08-Aug-2019		TechM				Initial Draft
//
// **************************************************************************
#ifndef _V7_TLS_CLIENT_H
#define _V7_TLS_CLIENT_H
#pragma once
#define SECURITY_WIN32
#define DLL_NAME "Secur32.dll"
#define NT4_DLL_NAME "Security.dll"
//
#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <Winsock2.h>
#include <wintrust.h>
#include <schannel.h>
//#include <security.h>
#include <sspi.h>
#include <Ws2tcpip.h>
#include "V7tstring.h"
#include "V7DbgLogDefines.h"
#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
#include "CStorage.h"
#endif
using namespace std;
#pragma comment(lib, "Crypt32.Lib")
//#pragma comment(lib, "MSVCRTD.lib")
#ifdef _WIN32_WCE
	#define _WCE_SECTION
#endif
#ifdef _WCE_SECTION
	#pragma comment(lib,"ws2.lib")
#else
//#pragma comment(lib, "WSock32.Lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "Secur32.lib")
#pragma comment (lib, "ws2_32.lib")
#endif
#define V7_TLS_MAX_RECORD_SIZE		16000//16384
#define V7_TLS_MAX_MSG_SIZE			15360//16000
#define V7_TLS_MAX_MSG_HDR_SIZE		200 //(still 284 spare buffer for future header sizes)
#define IO_BUFFER_SIZE 0x10000
#define ERROR_FAILURE -1
class CV7TLSClient {
public:
	HINSTANCE m_hSecurity;
	bool m_fUseProxy;
	bool m_fVerbose;
	HCERTSTORE m_hMyCertStore;
	//QAbstractSocket m_Socket;
	CredHandle m_hClientCreds;
	CV7TLSClient(void);
	CV7TLSClient(QAbstractSocket skt);
	~CV7TLSClient(void);
	static PSecurityFunctionTable SSPI(void);
	SECURITY_STATUS PerformClientHandshake(QAbstractSocket Socket, std::tstring wstrServerName);
	SECURITY_STATUS Receive(QAbstractSocket Socket);
	int Receive(QAbstractSocket s, void *lpBuf, int nBufLen, int nFlags); //Usha
	int decryptReceivedClientData(void *lpBuf, int Len);
	DWORD Send(QAbstractSocket Socket, char *sBuff);
	int Send(QAbstractSocket s, const void *lpBuf, int nBufLen, int nFlags); //Usha
	LONG DisconnectFromServer(QAbstractSocket Socket);
	void PrintText(DWORD length, PBYTE buffer);
	CtxtHandle& getContextHandle() {
		return (m_hContext);
	}
	int ReceiveChunk(QAbstractSocket s, void *lpBuf, int nBufLen, int nFlags); //Usha
	int SendChunk(QAbstractSocket s, const void *lpBuf, int nBufLen, int nFlags); //Usha
	DWORD ClientSecureSend(QAbstractSocket Socket, char *sBuff, int iLen);
	int RecvPartial(LPVOID lpBuf, const ULONG Len);
	int decryptReceivedData(void *lpBuf, int Len, bool bInExMode, char **ppExtraBuf, int *nExtraLen);
private:
	static PSecurityFunctionTable m_pSSPI;
	static HRESULT InitializeSSPI(void);
	BYTE *m_pbIoBuffer; //Usha
	DWORD m_cbIoBuffer; //Usha
	BYTE *m_pbReceiveBuf; //Usha
	DWORD m_dwReceiveBuf; //Usha
	DWORD LoadSecurityLibrary(void);
	SECURITY_STATUS CreateCredentials();
	bool ServerCredAut(CtxtHandle *phContext, std::tstring wstrServerName);
	SECURITY_STATUS ClientHandshakeLoop(QAbstractSocket Socket, BOOL fDoInitialRead, SecBuffer *pExtraData);
	void DisplayConnectionInfo(CtxtHandle *phContext);
	void DisplayCertChain(PCCERT_CONTEXT pServerCert, BOOL fLocal);
	void GetNewClientCredentials(CredHandle *phCreds, CtxtHandle *phContext);
	DWORD VerifyServerCertificate(PCCERT_CONTEXT pServerCert, std::tstring wstrServerName, DWORD dwCertFlags);
	SECURITY_STATUS ReadDecrypt(QAbstractSocket Socket, PCredHandle phCreds, CtxtHandle *phContext, PBYTE pbIoBuffer,
			DWORD cbIoBufferLength);
	DWORD EncryptSend(QAbstractSocket Socket, CtxtHandle *phContext, PBYTE pbIoBuffer, SecPkgContext_StreamSizes Sizes);
	DWORD ClientEncryptSend(QAbstractSocket Socket, CtxtHandle *phContext, PBYTE pbIoBuffer,
			SecPkgContext_StreamSizes Sizes, int iLen);
	void DisplaySECError(DWORD ErrCode);
	int RecvPartialEncrypted(LPVOID lpBuf, const ULONG Len);
	int RecvRawDataBytes(char *pData, int nLen);
protected:
#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
	void LogDebugMessage(QString   strDebugMessage);
#endif
public:
#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
	void SetDebugLogger(CDebugFileLogger* pDbgFileLogger);
#endif
private:
	CtxtHandle m_hContext;
	bool m_encrypting;
	DWORD readBufferBytes;
	CHAR *plainTextPtr;
	DWORD plainTextBytes;
	void *readPtr;
	int m_LastError;
	QAbstractSocket m_ActualSocket;
	static CHAR readBuffer[(V7_TLS_MAX_RECORD_SIZE + V7_TLS_MAX_MSG_HDR_SIZE) * 2]; // Enough for two whole messages so we don't need to move data around in buffers
	static CHAR plainText[V7_TLS_MAX_RECORD_SIZE * 2];
#ifdef DBG_FILE_LOG_TLS_CLNT_ENABLE
CDebugFileLogger* m_pDebugFileLogger;
#endif
};
#endif // _V7_TLS_CLIENT_H

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  Secure Comm
/// @n Filename:  V7TlsServCleComm.h
/// @n Description: Common Communication function for Server and Client
///
// **************************************************************************
// Revision History
// **************************************************************************
// Project		Date			Team/Person			Comments
//	TVR211		08-Aug-2019		TechM				Initial Draft
//
// **************************************************************************
#ifndef _V7_TLS_SERVER_CLE_COMM_H
#define _V7_TLS_SERVER_CLE_COMM_H
#pragma once
#include <memory>
#include "V7TLSCertificate.h"
#include "V7DbgLogDefines.h"
#ifdef DBG_FILE_LOG_TLS_SERV_ENABLE
#include "CStorage.h"
#endif
#include "Defines.h"
#define E_NOT_VALID_STATE  HRESULT_FROM_WIN32(ERROR_INVALID_STATE)
#define READ_WRITE_TIMEOUT  60
#define V7_TLS_MAX_RECORD_SIZE		16000//16384
#define V7_TLS_MAX_MSG_SIZE			15360//16000
#define V7_TLS_MAX_MSG_HDR_SIZE		200 //(still 284 spare buffer for future header sizes)
//class RecrTLSServerProcess;
class CV7TLSServCleComm {
public:
	//CV7TLSServCleComm(QAbstractSocket skt, RecrTLSServerProcess * serverProc);
	CV7TLSServCleComm(QAbstractSocket skt);
	CV7TLSServCleComm(QAbstractSocket skt, CredHandle *hServerCreds, CtxtHandle *hContext);
	virtual ~CV7TLSServCleComm();
	static PSecurityFunctionTable SSPI(void);
	// accessor
//	RecrTLSServerProcess* getServerProcInstance(){ return(m_ServerProc);}
	CV7TLSServCleComm* getSocketSteram() {
		return (m_SocketStream);
	}
	bool getConnectStatus() {
		return (m_IsConnected);
	}
	bool getEncryptStatus() {
		return (m_encrypting);
	}
	HRESULT Disconnect(void);
	bool StartHandShake(void);
	int Recv(void *const lpBuf, const int Len);
	int RecvRDT(void *const lpBuf, const int Len);
	int Send(const void *const lpBuf, const int Len);
	int SendRDT(const void *const lpBuf, const int Len);
	int GetLastError();
	void SetTimeoutSeconds(int NewTimeoutSeconds);
	HRESULT DisconnectSocket(void);
	BOOL ShutDown(int nHow = SD_SEND);
	int ReceiveBytes(void *const lpBuf, const int nBufLen);
	int SendBytes(const void *const lpBuf, const int Len);
	SelectServerCertFPTR SelectServerCert;
	ClientCertAcceptableFPTR ClientCertAcceptable;
	SecPkgContext_StreamSizes& GetSizes() {
		return (Sizes);
	}
	CtxtHandle* getContextHandle() {
		return (&m_hContext);
	}
	CredHandle* getCredHanle() {
		return (&m_hServerCreds);
	}
	int decryptReceivedData(void *lpBuf, const int Len, bool bInExMode, char **ppExtraBuf, int *nExtraLen);
	int RecvEncrypted(void *const lpBuf, const int Len);
	int RecvEncryptedRDT(void *const lpBuf, const int Len);
protected:
#ifdef DBG_FILE_LOG_TLS_SERV_ENABLE
	void LogDebugMessage(QString   strDebugMessage);
	#endif
public:
#ifdef DBG_FILE_LOG_TLS_SERV_ENABLE
	void SetDebugLogger(CDebugFileLogger* pDbgFileLogger);
	#endif
private:
	static PSecurityFunctionTable g_pSSPI;
	CV7TLSServCleComm *m_SocketStream; // Same Class also work as Socket Handler for Calling application 
	bool m_IsConnected;
	//RecrTLSServerProcess* m_ServerProc; 
	int m_LastError;
	CredHandle m_hServerCreds;
	CtxtHandle m_hContext;
	SecPkgContext_StreamSizes Sizes;
	bool m_encrypting; // Is channel currently encypting
	// Read Write Parameter , 
	CTime m_recvEndTime;
	CTime m_sendEndTime;
	WSAEVENT m_write_event;
	WSAEVENT m_read_event;
	WSAOVERLAPPED m_os;
	bool m_recvInitiated;
	QAbstractSocket m_actualSocket;
	int m_lastSocketError;
	int m_timeoutSeconds;
	HANDLE m_hStopEvent;
	// Data Buffer Parameter
	static const int MaxMsgSize = V7_TLS_MAX_RECORD_SIZE; // Arbitrary but less than 16384 limit, including MaxExtraSize
	static const int MaxExtraSize = V7_TLS_MAX_MSG_HDR_SIZE; // Also arbitrary, current header is 5 bytes, trailer 36
	CHAR writeBuffer[MaxMsgSize + MaxExtraSize]; // Enough for a whole encrypted message
	CHAR readBuffer[(MaxMsgSize + MaxExtraSize) * 2]; // Enough for two whole messages so we don't need to move data around in buffers
	DWORD readBufferBytes;
	void *readPtr;
	CHAR decReadBuffer[(MaxMsgSize + MaxExtraSize) * 2]; // Enough for two whole messages so we don't need to move data around in buffers
	DWORD decReadBufferBytes;
	void *decReadPtr;
	// Method
	//void initReadWriteParameter(QAbstractSocket skt, RecrTLSServerProcess * serverProc);
	void initReadWriteParameter(QAbstractSocket skt);
	//int RecvEncrypted(void* const lpBuf, const int Len);
	int SendEncrypted(const void *const lpBuf, const int Len);
	int SendEncryptedRDT(const void *const lpBuf, const int Len);
	void InitializeReadBuffer(const void *const lpBuf = NULL, const int Len = 0);
	static HRESULT InitializeSSPI(void);
	// Set up state for this connection
	HRESULT InitializeConnection(const void *const lpBuf = NULL, const int Len = 0);
	bool SSPINegotiateLoop(void);
	int RecvDataBuffer(void *const lpBuf, const int Len);
	int SendDataBuffer(const void *const lpBuf, const int Len);
	int checkIsDecryptDataAvail(void *const lpBuf, const int Len);
protected:
#ifdef DBG_FILE_LOG_TLS_SERV_ENABLE
	CDebugFileLogger* m_pDebugFileLogger;
#endif
};
#endif // _V7_TLS_SERVER_CLE_COMM_H

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	Module Message Manager
/// @n Filename: ModuleMsgManagerClient.h
/// @n Desc:	Class Declaration for Module Message Manager Client. 
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 6	Stability Project 1.3.1.1	7/2/2011 4:58:53 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 5	Stability Project 1.3.1.0	7/1/2011 4:26:59 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 4	V6 Firmware 1.3		10/4/2004 8:37:50 PM	Alistair Brugsch
//		Changed Constructor to contain no paramters, and changed
//		MMMClientRegister parameter list to include Module ID. 
// 3	V6 Firmware 1.2		9/8/2004 5:28:52 PM	Alistair Brugsch
//		Changed T_MODULE_MESSAGE_ID to USHORT, as the messages to be used
//		have been taken out of an enum and declared as constants for
//		clarification and usability.
// $
//
// 
#ifndef _MODULEMSGMANAGERCLIENT_H 
#define _MODULEMSGMANAGERCLIENT_H
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include <QMutex>
#include "Defines.h"
#include "ModuleMsgManager.h"
#include "ModuleConstants.h"
#include "MsgQueueMessage.h"
const ULONG MMMCLIENT_INTERNAL_MESSAGE = 127; ///< IP Address value for INTERNAL Message
const DWORD MMMCLIENT_MESSAGEQUEUE_MUTEX_WAIT = 10;	///< Time in Ms to wait for ownership of Mutex 
const USHORT MMMCLIENT_MESSAGE_QUEUE_RETRY_VALUE = 10;	///< Time in Ms retry to post messages
const USHORT MMMCLIENT_MESSAGE_QUEUE_MAX_WAIT = 1000; ///< Maximun time of one second for message to be posted
/// Status of Message being Read and Released
///
typedef enum {
	MMMCLIENT_MSG_READ_NOT_RELEASED, MMMCLIENT_MSG_READ_AND_RELEASED,
} T_MMMCLIENT_MESSAGE_READ;
/// Return Values for Class Member Functions, indicates success or failures that have occurred for
/// operation that have been undertaken
//
typedef enum {
	MMMCLIENT_REGISTRATION_SUCCESSFUL,
	MMMCLIENT_MODULE_ALREADY_REGISTERED,
	MMMCLIENT_REGISTRATION_FAILED,
	MMMCLIENT_MESSAGE_POSTED,
	MMMCLIENT_MESSAGE_NOT_POSTED,
	MMMCLIENT_MESSAGE_ALLOCATED,
	MMMCLIENT_DESTINATION_MODULE_DOES_NOT_EXIST,
	MMMCLIENT_MESSAGE_NOT_READ,
	MMMCLIENT_MESSAGE_RELEASED,
	MMMCLIENT_ALLOCATED_DATA_LENGTH_EXCEEDED,
	MMMCLIENT_DATA_WRITTEN_SUCESSFULLY,
	MMMCLIENT_NO_MESSAGE_ALLOCATED,
	MMMCLIENT_MESSAGE_ALLOCATED_BUT_NOT_POSTED,
	MMMCLIENT_MESSAGE_COMPLETED_TIMEOUT,
	MMMCLIENT_MESSAGE_COMPLETED,
	MMMCLIENT_ERROR,
	MMMCLIENT_NO_MESSAGE_AVAILABLE,
	MMMCLIENT_MESSAGE_AVAILABLE
} T_MMMCLIENT_RETURN_VALUE;
//**Class*********************************************************************
///
/// @brief Client Interface(API) to the Module Message Manager
/// 
/// This class provides modules within the system to communicate with each
/// other via Message Queues, provided by the Module Message Manager.
/// This class interacts directly with the Module Message Manager, who is 
/// responsible for each Message Queue available in the system. The Class 
/// provides functionality to send and receive messages between internal and
/// external modules on a different device.	
///
/// @note This class is declared as a friend to Module Message Manager, for
///	speed and efficiency in accessing the message queues. 
//****************************************************************************
class CModuleMsgManagerClient {
public:
	/// Constructor
	CModuleMsgManagerClient();
	/// Destructor
	virtual ~CModuleMsgManagerClient();
	/// Register Client with the Module Message Manager
	T_MMMCLIENT_RETURN_VALUE MMMClientRegister(T_MODULE_ID moduleId, T_MODULE_MSG_NOTIFICATION moduleNotification,
			T_MODULE_QUEUE_WRAP_STATUS queueWrap);
	/// Read the first item in the queue
	const CMsgQueueMessage* MMMClientReadMsg();
	/// Release the read message from the queue
	T_MMMCLIENT_RETURN_VALUE MMMClientRemoveMsg(void);
	/// Obtain the Event Handler to determine if a message has been written to the queue
	HANDLE GetMessageQueueEventHandler(void);
	/// Post a message to a internal module within the system
	T_MMMCLIENT_RETURN_VALUE MMMClientPostIntMsg(DWORD waitForSpaceInQueueInMs, T_MODULE_ID destinationModule,
			T_MODULE_ID sendingModule, USHORT messageType, USHORT datalength, BYTE *pData);
	/// Post a message to an internal module within the system, and wait for the message to be completed
	/// by the destination module
	T_MMMCLIENT_RETURN_VALUE MMMClientPostIntMsgAndWait(DWORD waitForSpaceInQueueInMs, DWORD waitTimeOutInMs,
			T_MODULE_ID destinationModule, T_MODULE_ID sendingModule, USHORT messageType, USHORT datalength,
			BYTE *pData);
	/// Post a message to a particular module on a external device
	T_MMMCLIENT_RETURN_VALUE MMMClientPostExtMsg(DWORD waitForSpaceInQueueInMs, ULONG ipAddress,
			T_MODULE_ID destinationModule, T_MODULE_ID sendingModule, USHORT messageType, USHORT datalength,
			BYTE *pData);
private:
	// Private Member Functions
	//
	/// Wait for a message to be completed by receiving module
	T_MMMCLIENT_RETURN_VALUE WaitForMessageCompletion(DWORD timeOutInMs);
	// Private Member Variables
	//
	CModuleMsgManager *m_pModuleMsgManager; ///< Module Message Manager Singleton
	HANDLE m_hMessageQueueEventHandler; ///< Event Handler to determine new messages to read
	static QMutex m_hMsgCompleted;	///< Event Handler to determine when destination module has copmleted message
	BOOL m_ModuleRegistered;	///< Indication to whether the module has registered with the Module Message Manager
	T_MODULE_ID m_ModuleId; ///< Module Identification Number		
	T_MMMCLIENT_MESSAGE_READ m_MsgReadStatus; ///< Used to store when a message has been read
};
// End of CModuleMsgManagerClient Class Declaration
#endif // _MODULEMSGMANAGERCLIENT_H

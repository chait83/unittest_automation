#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
///////////////////////////////////////////table
#include <QTableView>
#include <QItemDelegate>
#include <QStandardItemModel>
#include "qcustomplot.h"
#include "axistag.h"
#include "Pen/hdr/Misc.h"
#include "MaxMins.h"
#include <QRandomGenerator>
///////////////////////////////////////////////
QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    unsigned int get_pre_trigger_time();
    unsigned int get_post_trigger_time();
    void boot_startup();
    void Gui_card_detection();
    void Gui_pen_detection();

    ~MainWindow();

private slots:
    void on_toolButton_12_clicked();

    void on_toolButton_42_clicked();

    void on_toolButton_59_clicked();

    void on_toolButton_74_clicked();

    void on_toolButton_64_clicked();

    void on_toolButton_50_clicked();

    void on_toolButton_48_clicked();

    void on_toolButton_63_clicked();

    void on_toolButton_66_clicked();

    void on_toolButton_25_clicked();

    void on_toolButton_29_clicked();

    void on_toolButton_30_clicked();

    void on_toolButton_71_clicked();

    void on_toolButton_53_clicked();

    void on_toolButton_54_clicked();

    void on_toolButton_51_clicked();

    void on_toolButton_14_clicked();

    void on_toolButton_33_clicked();

    void on_toolButton_37_clicked();

    void on_toolButton_34_clicked();

    void on_toolButton_36_clicked();

    void on_toolButton_67_clicked();

    void on_pushButton_72_clicked();

    void on_pushButton_74_clicked();

    void onTableClicked(const QModelIndex &index);
    void onTableClicked_2(const QModelIndex &index);
    void onTableClicked_3(const QModelIndex &index);
    void onTableClicked_4(const QModelIndex &index);
    void onTableClicked_5(const QModelIndex &index);
    void onTableClicked_6(const QModelIndex &index);
    void onTableClicked_7(const QModelIndex &index);
    void onTableClicked_8(const QModelIndex &index);
    void onTableClicked_9(const QModelIndex &index);
    void onTableClicked_10(const QModelIndex &index);
    void onTableClicked_11(const QModelIndex &index);
    void onTableClicked_12(const QModelIndex &index);
    void onTableClicked_16(const QModelIndex &index);
    void onTableClicked_23(const QModelIndex &index);
    void onTableClicked_13(const QModelIndex &index);
    void onTableClicked_14(const QModelIndex &index);
    void onTableClicked_15(const QModelIndex &index);
    void onTableClicked_17(const QModelIndex &index);
    void onTableClicked_18(const QModelIndex &index);
    void onTableClicked_19(const QModelIndex &index);
    void onTableClicked_20(const QModelIndex &index);
    void onTableClicked_21(const QModelIndex &index);
    void onTableClicked_22(const QModelIndex &index);
    void onTableClicked_24(const QModelIndex &index);
    void onTableClicked_25(const QModelIndex &index);
    void onTableClicked_26(const QModelIndex &index);
    void onTableClicked_27(const QModelIndex &index);
    void onTableClicked_28(const QModelIndex &index);
    void onTableClicked_29(const QModelIndex &index);
    void onTableClicked_30(const QModelIndex &index);
    void onTableClicked_31(const QModelIndex &index);
    void onTableClicked_32(const QModelIndex &index);
    void onTableClicked_33(const QModelIndex &index);
    void onTableClicked_34(const QModelIndex &index);
    void onTableClicked_35(const QModelIndex &index);
    void onTableClicked_36(const QModelIndex &index);
    void onTableClicked_37(const QModelIndex &index);
    void onTableClicked_38(const QModelIndex &index);
    void onTableClicked_39(const QModelIndex &index);
    void onTableClicked_40(const QModelIndex &index);
    void onTableClicked_41(const QModelIndex &index);
    void onTableClicked_42(const QModelIndex &index);
    void onTableClicked_43(const QModelIndex &index);
    void onTableClicked_44(const QModelIndex &index);
    void onTableClicked_45(const QModelIndex &index);
    void onTableClicked_46(const QModelIndex &index);
    void onTableClicked_47(const QModelIndex &index);
    void onTableClicked_48(const QModelIndex &index);
    void onTableClicked_49(const QModelIndex &index);
    void onTableClicked_50(const QModelIndex &index);
    void onTableClicked_51(const QModelIndex &index);
    void onTableClicked_52(const QModelIndex &index);
    void onTableClicked_53(const QModelIndex &index);
    void onTableClicked_54(const QModelIndex &index);
    void onTableClicked_55(const QModelIndex &index);
    void onTableClicked_56(const QModelIndex &index);
    void onTableClicked_57(const QModelIndex &index);
    void onTableClicked_58(const QModelIndex &index);
    void onTableClicked_59(const QModelIndex &index);
    void onTableClicked_60(const QModelIndex &index);
    void onTableClicked_61(const QModelIndex &index);
    void onTableClicked_62(const QModelIndex &index);
    void onTableClicked_63(const QModelIndex &index);

    void on_toolButton_72_clicked();

    void on_toolButton_40_clicked();

    void on_toolButton_75_clicked();

    void on_toolButton_55_clicked();

    void on_pushButton_76_clicked();

    void on_pushButton_78_clicked();

    void on_pushButton_73_clicked();

    void on_pushButton_75_clicked();

    void on_pushButton_80_clicked();

    void on_pushButton_82_clicked();

    void on_pushButton_79_clicked();

    void on_pushButton_81_clicked();

    void on_pushButton_119_clicked();

    void on_pushButton_120_clicked();

    void on_pushButton_85_clicked();

    void on_pushButton_86_clicked();

    void on_pushButton_83_clicked();

    void on_pushButton_87_clicked();

    void on_pushButton_46_clicked();

    void on_toolButton_27_clicked();

    void on_pushButton_104_clicked();

    void on_pushButton_106_clicked();


    void on_pushButton_108_clicked();

    void on_pushButton_107_clicked();

    void on_toolButton_23_clicked();

    void on_EDIT_SETUP_FIELDIO_ALARM_DIGITALIO_INDEX_BOTTOM_BAR_Back_clicked();

    void on_EDIT_SETUP_FIELDIO_ALARM_DIGITALIO_INDEX_BOTTOM_BAR_Finish_clicked();

    void on_pushButton_110_clicked();

    void on_pushButton_109_clicked();
    void timerSlot();
    void on_toolButton_7_clicked();

    void on_toolButton_20_clicked();

    void on_pushButton_15_clicked();

    void on_pushButton_16_clicked();

    void on_pushButton_18_clicked();

    void on_pushButton_19_clicked();

    void on_pushButton_22_clicked();

    void on_pushButton_24_clicked();

    void on_pushButton_27_clicked();

    void on_pushButton_30_clicked();

    void on_pushButton_34_clicked();

    void on_pushButton_38_clicked();

    void on_pushButton_41_clicked();

    void on_pushButton_39_clicked();

    void on_pushButton_42_clicked();






    void on_pushButton_5_clicked();

    void on_pushButton_6_clicked();

    void on_EDIT_SETUP_FIELDIO_ALARM_DIGITALIO_INDEX_TOP_BAR_Edit_Setup_clicked();

    void on_EDIT_SETUP_FIELDIO_ALARM_DIGITALIO_INDEX_TOP_BAR_FieldIo_clicked();

    void on_EDIT_SETUP_FIELDIO_ALARM_DIGITALIO_INDEX_TOP_BAR_Alarm_DigitalIo_clicked();

    void on_pushButton_20_clicked();

    void on_pushButton_25_clicked();

    void on_pushButton_28_clicked();

    void on_pushButton_31_clicked();

    void on_pushButton_32_clicked();

    void on_pushButton_43_clicked();

    void on_pushButton_50_clicked();

    void on_pushButton_51_clicked();

    void on_pushButton_36_clicked();

    void on_pushButton_35_clicked();

    void on_toolButton_56_clicked();

    void on_toolButton_16_clicked();

    void on_toolButton_672_clicked();

    void on_toolButton_127_clicked();

    void on_toolButton_128_clicked();

    void on_toolButton_129_clicked();

    void on_toolButton_131_clicked();

    void on_toolButton_215_clicked();

    void on_toolButton_216_clicked();

    void on_toolButton_366_clicked();

    void on_toolButton_364_clicked();

    void on_toolButton_674_clicked();

    void on_toolButton_675_clicked();

    void on_toolButton_519_clicked();

    void on_toolButton_517_clicked();


    void on_EDIT_SETUP_EDIT_RECORDING_EXPORT_BOTTON_BAR_Back_clicked();

    void on_EDIT_SETUP_EDIT_RECORDING_EXPORT_BOTTON_BAR_Finish_clicked();

    void on_toolButton_76_clicked();

    void on_EDIT_SETUP_EDIT_RECORDING_SCHEDULED_BOTTOM_BAR_Back_clicked();

    void on_EDIT_SETUP_EDIT_RECORDING_SCHEDULED_BOTTOM_BAR_Finish_clicked();

    void on_EDIT_SETUP_FIELDIO_ANALOGIN_INDEX_1_Tableview_clicked(const QModelIndex &index);

    void on_EDIT_SETUP_FIELDIO_ANALOGIN_INDEX_1_BOTTOM_BAR_Back_clicked();

    void on_EDIT_SETUP_FIELDIO_ANALOGIN_INDEX_2_BOTTOM_BAR_CopyTo_clicked();

    void on_EDIT_SETUP_FIELDIO_ANALOGIN_INDEX_2_Tableview_clicked(const QModelIndex &index);

    void on_EDIT_SETUP_FIELD_IO_ANALOG_IN_INDEX_Tableview_clicked(const QModelIndex &index);

    void on_EDIT_SETUP_FIELD_IO_ANALOG_IN_INDEX_BOTTOM_BAR_Back_clicked();

    void on_EDIT_SETUP_FIELDIO_ANALOGIN_INDEX_2_BOTTOM_BAR_Back_clicked();

    void on_EDIT_SETUP_FIELDIO_ANALOGIN_INDEX_2_BOTTOM_BAR_Finish_clicked();

    void on_EDIT_SETUP_FIELD_IO_ANALOG_IN_INDEX_BOTTOM_BAR_Finish_clicked();

    void on_EDIT_SETUP_FIELDIO_ANALOGIN_INDEX_1_BOTTOM_BAR_Finish_clicked();
	
    void on_EDIT_SETUP_EDIT_RECORDING_EXPORT_TOP_BAR_Edit_Setup_clicked();

    void on_EDIT_SETUP_EDIT_RECORDING_EXPORT_TOP_BAR_Edit_Recordings_clicked();

    void on_EDIT_SETUP_EDIT_RECORDING_SCHEDULED_TOP_BAR_Edit_Setup_clicked();

    void on_EDIT_SETUP_EDIT_RECORDING_SCHEDULED_TOP_BAR_Edit_Recording_clicked();

    void on_toolButton_18_clicked();

    void on_toolButton_91_clicked();

    void on_toolButton_93_clicked();

    void on_toolButton_94_clicked();

    void on_toolButton_95_clicked();

    void on_toolButton_38_clicked();

    void on_EDIT_LAYOUT_SCREENS_INDEX_Tableview_clicked(const QModelIndex &index);

    void on_EDIT_LAYOUT_SCREENS_INDEX_2_Tableview_clicked(const QModelIndex &index);

    void on_toolButton_78_clicked();

    void on_toolButton_79_clicked();

    void on_EDIT_LAYOUT_BOTTOM_BAR_Back_clicked();

    void on_EDIT_LAYOUT_TOP_BAR_Edit_Layout_clicked();

    void on_EDIT_LAYOUT_SCREENS_INDEX_TOP_BAR_Edit_Layout_clicked();

    void on_EDIT_LAYOUT_SCREENS_INDEX_2_TOP_BAR_Edit_Layout_clicked();

    void on_EDIT_LAYOUT_BOTTOM_BAR_Finish_clicked();

    void on_EDIT_LAYOUT_SCREENS_INDEX_BOTTOM_BAR_Finish_clicked();

    void on_toolButton_90_clicked();

    void on_EDIT_LAYOUT_SCREENS_INDEX_2_BOTTOM_BAR_Finish_clicked();

    void on_SELECT_PENS_DLG_BOTTOM_BAR_Clear_clicked();

    void on_SELECT_PENS_DLG_BOTTOM_BAR_Add_clicked();

    void on_SELECT_PENS_DLG_BOTTOM_BAR_Delete_clicked();

    void on_pushButton_116_clicked();

    void on_pushButton_117_clicked();

    void on_pushButton_118_clicked();

    void on_pushButton_121_clicked();

    void on_SELECT_PENS_TABLE_BOTTOM_BAR_Clear_clicked();

    void on_SELECT_PENS_TABLE_BOTTOM_BAR_Add_clicked();

    void on_SELECT_PENS_TABLE_BOTTOM_BAR_Finish_clicked();

    void on_pushButton_131_clicked();

    void on_pushButton_132_clicked();

    void on_pushButton_133_clicked();

    void on_pushButton_134_clicked();

    void on_toolButton_96_clicked();

    void on_toolButton_113_clicked();

    void on_toolButton_120_clicked();

    void on_toolButton_133_clicked();

    void on_toolButton_123_clicked();

    void on_toolButton_98_clicked();

    void on_toolButton_211_clicked();

    void on_toolButton_97_clicked();

    void on_toolButton_115_clicked();

    void on_toolButton_122_clicked();

    void on_toolButton_135_clicked();

    void on_toolButton_134_clicked();

    void on_toolButton_121_clicked();

    void on_toolButton_114_clicked();

    void on_EDIT_LAYOUT_SCREENS_INDEX_BOTTOM_BAR_Back_clicked();

    void on_EDIT_LAYOUT_SCREENS_INDEX_2_BOTTOM_BAR_Back_clicked();

    void on_toolButton_116_clicked();

    void on_toolButton_136_clicked();

    void on_toolButton_86_clicked();

    void on_toolButton_68_clicked();

    void on_toolButton_222_clicked();

    void on_toolButton_143_clicked();

    void on_toolButton_298_clicked();

    void on_toolButton_300_clicked();

    void on_toolButton_302_clicked();

    void on_toolButton_218_clicked();

    void on_toolButton_221_clicked();

    void on_toolButton_303_clicked();

    void on_toolButton_313_clicked();

    void on_toolButton_308_clicked();

    void on_toolButton_307_clicked();

    void on_pushButton_159_clicked();

    void on_pushButton_314_clicked();

    void on_pushButton_319_clicked();

    void on_pushButton_321_clicked();

    void on_pushButton_326_clicked();

    void on_pushButton_328_clicked();

    void on_toolButton_304_clicked();

    void on_pushButton_345_clicked();

    void on_pushButton_347_clicked();

    void on_toolButton_17_clicked();

    void on_toolButton_324_clicked();

    void on_toolButton_321_clicked();

    void on_toolButton_317_clicked();

    void on_toolButton_318_clicked();

    void on_toolButton_320_clicked();

    void on_toolButton_322_clicked();

    void on_toolButton_319_clicked();

    void on_toolButton_323_clicked();

    void on_pushButton_351_clicked();

    void on_pushButton_353_clicked();

    void on_pushButton_358_clicked();

    void on_pushButton_363_clicked();

    void on_pushButton_368_clicked();

    void on_pushButton_373_clicked();

    void on_toolButton_220_clicked();

    void on_toolButton_19_clicked();

    void on_toolButton_351_clicked();

    void on_toolButton_376_clicked();

    void on_toolButton_380_clicked();

    void on_toolButton_379_clicked();

    void on_toolButton_352_clicked();

    void on_toolButton_26_clicked();

    void on_toolButton_70_clicked();

    void on_toolButton_422_clicked();

    void on_toolButton_223_clicked();

    void on_toolButton_217_clicked();

    void on_toolButton_219_clicked();

    void on_toolButton_429_clicked();

    void on_toolButton_426_clicked();


    void on_toolButton_140_clicked();

    void on_toolButton_402_clicked();

    void on_toolButton_399_clicked();




    void on_toolButton_430_clicked();

    void on_toolButton_432_clicked();

    void on_toolButton_416_clicked();

    void on_toolButton_417_clicked();

    void on_toolButton_419_clicked();

    void on_toolButton_415_clicked();

    void on_toolButton_47_clicked();

    void on_toolButton_49_clicked();

    void on_toolButton_52_clicked();

    void on_pushButton_147_clicked();

    void on_pushButton_154_clicked();

    void on_pushButton_151_clicked();

    void on_pushButton_155_clicked();

    void on_pushButton_160_clicked();

    void on_pushButton_165_clicked();

    void on_pushButton_166_clicked();

    void on_pushButton_172_clicked();

    void on_pushButton_173_clicked();

    void on_EDIT_SETUP_GENERAL_FACTORY_DEMO_TRACES_BOTTOM_BAR_Finish_clicked();

    void on_EDIT_SETUP_GENERAL_FACTORY_DEMO_TRACES_BOTTOM_BAR_CopyTo_clicked();

    void on_pushButton_186_clicked();

    void on_pushButton_187_clicked();

    void on_pushButton_195_clicked();

    void on_pushButton_196_clicked();

    void on_pushButton_200_clicked();

    void on_pushButton_201_clicked();

    void on_pushButton_207_clicked();

    void on_pushButton_208_clicked();

    void on_pushButton_214_clicked();

    void on_pushButton_215_clicked();

    void on_pushButton_563_clicked();

    void on_pushButton_564_clicked();

    void on_pushButton_539_clicked();

    void on_pushButton_540_clicked();

    void on_pushButton_545_clicked();

    void on_pushButton_546_clicked();

    void on_EDIT_SETUP_SCREEN_SETUP_TABULAR_DISPLAY_BOTTOM_BAR_Back_clicked();

    void on_EDIT_SETUP_SCREEN_SETUP_TABULAR_DISPLAY_BOTTOM_BAR_Finish_clicked();

    void on_EDIT_SETUP_FIELDIO_LINEARISATION_Bottom_Bar_Back_clicked();

    void on_EDIT_SETUP_FIELDIO_LINEARISATION_Bottom_Bar_Finish_clicked();

    void on_EDIT_SETUP_FIELDIO_LINEARISATION_TABLE_Bottom_Bar_Back_clicked();

    void on_EDIT_SETUP_FIELDIO_LINEARISATION_TABLE_Bottom_Bar_Finish_clicked();

    void on_LOAD_CERTIFICATE_Back_Button_clicked();

    void on_LOAD_CERTIFICATE_Finish_Button_clicked();

    void on_EDIT_SETUP_COMMS_SECURITY_OPTIONS_Bottom_Bar_Back_clicked();

    void on_EDIT_SETUP_COMMS_SECURITY_OPTIONS_Bottom_Bar_Finish_clicked();

    void on_toolButton_388_clicked();

    void on_toolButton_383_clicked();

    void on_toolButton_355_clicked();

    void on_toolButton_356_clicked();

    void on_pushButton_403_clicked();

    void on_pushButton_402_clicked();

    void on_toolButton_378_clicked();

    void on_toolButton_377_clicked();

    void on_toolButton_396_clicked();

    void on_toolButton_389_clicked();

    void on_EDIT_SETUP_COMMS_COMMS_SERVICES_MODBUS_RS485_TOP_BAR_Edit_Setup_clicked();

    void on_EDIT_SETUP_COMMS_COMMS_SERVICES_MODBUS_RS485_TOP_BAR_Comms_clicked();

    void on_EDIT_SETUP_COMMS_COMMS_SERVICES_MODBUS_RS485_TOP_BAR_Rs485_clicked();

    void on_EDIT_SETUP_COMMS_COMMS_SERVICES_MODBUS_RS485_BOTTOM_BAR_CopyTo_clicked();

    void on_pushButton_396_clicked();

    void on_toolButton_354_clicked();

    void on_EDIT_LAYOUT_SCREENS_SCREEN_Bottom_Bar_Back_2_clicked();

    void on_EDIT_LAYOUT_SCREENS_SCREEN_Bottom_Bar_Finish_2_clicked();

    void on_EDIT_LAYOUT_SCREENS_SCREEN_Bottom_Bar_Back_3_clicked();

    void on_pushButton_533_clicked();

    void on_pushButton_534_clicked();

    void on_EDIT_SETUP_GENERAL_ERROR_ALERT_Bottom_Bar_Back_clicked();

    void on_EDIT_SETUP_GENERAL_ERROR_ALERT_Bottom_Bar_Finish_clicked();

    void on_toolButton_43_clicked();

    void on_toolButton_153_clicked();

    void on_toolButton_155_clicked();

    void on_toolButton_154_clicked();

    void on_toolButton_440_clicked();

    void on_toolButton_443_clicked();

    void on_toolButton_442_clicked();

    void on_toolButton_439_clicked();

    void on_EDIT_LAYOUT_LAYOUT_SETTINGS_Bottom_Bar_Back_2_clicked();

    void on_EDIT_LAYOUT_LAYOUT_SETTINGS_Bottom_Bar_FInish_2_clicked();

    void on_EDIT_LAYOUT_LAYOUT_SETTINGS_Bottom_Bar_Back_clicked();

    void on_EDIT_LAYOUT_LAYOUT_SETTINGS_Bottom_Bar_FInish_clicked();

    void on_EDIT_LAYOUT_APPEARANCE_Bottom_Bar_Back_clicked();

    void on_EDIT_LAYOUT_APPEARANCE_Bottom_Bar_Finish_clicked();

    void on_toolButton_418_clicked();

    void on_toolButton_431_clicked();

    void on_toolButton_424_clicked();

    void on_toolButton_428_clicked();

    void on_toolButton_5_clicked();

    void on_toolButton_141_clicked();

    void on_EDIT_LAYOUT_LAYOUT_SETTINGS_Bottom_Bar_Back_3_clicked();

    void on_EDIT_LAYOUT_LAYOUT_SETTINGS_Bottom_Bar_FInish_3_clicked();

    void on_EDIT_LAYOUT_LAYOUT_SETTINGS_Bottom_Bar_Back_4_clicked();

    void on_toolButton_44_clicked();

    void on_toolButton_450_clicked();

    void on_toolButton_451_clicked();

    void on_toolButton_445_clicked();

    void on_toolButton_453_clicked();

    void on_toolButton_460_clicked();

    void on_EDIT_LAYOUT_LAYOUT_SETTINGS_Bottom_Bar_FInish_4_clicked();

    void on_toolButton_455_clicked();

    void on_EDIT_LAYOUT_LAYOUT_SETTINGS_Bottom_Bar_Back_6_clicked();

    void on_EDIT_LAYOUT_LAYOUT_SETTINGS_Bottom_Bar_FInish_6_clicked();

    void on_EDIT_LAYOUT_LAYOUT_SETTINGS_Bottom_Bar_Back_5_clicked();

    void on_EDIT_LAYOUT_LAYOUT_SETTINGS_Bottom_Bar_FInish_5_clicked();

    void on_toolButton_454_clicked();

    void on_toolButton_466_clicked();

    void on_toolButton_467_clicked();

    void on_toolButton_462_clicked();

    void on_toolButton_463_clicked();

    void on_toolButton_464_clicked();

    void on_toolButton_465_clicked();

    void on_EDIT_LAYOUT_LAYOUT_SETTINGS_Bottom_Bar_Back_7_clicked();

    void on_EDIT_LAYOUT_LAYOUT_SETTINGS_Bottom_Bar_FInish_7_clicked();

    void on_EDIT_LAYOUT_LAYOUT_SETTINGS_Bottom_Bar_Back_8_clicked();

    void on_EDIT_LAYOUT_LAYOUT_SETTINGS_Bottom_Bar_FInish_8_clicked();

    void on_EDIT_LAYOUT_LAYOUT_SETTINGS_Bottom_Bar_Back_9_clicked();

    void on_EDIT_LAYOUT_LAYOUT_SETTINGS_Bottom_Bar_FInish_9_clicked();

    void on_EDIT_LAYOUT_LAYOUT_SETTINGS_Bottom_Bar_Back_10_clicked();

    void on_EDIT_LAYOUT_LAYOUT_SETTINGS_Bottom_Bar_FInish_10_clicked();

    void on_toolButton_353_clicked();

    void on_pushButton_588_clicked();

    void on_toolButton_6_clicked();

    void on_toolButton_477_clicked();

    void on_toolButton_482_clicked();

    void on_toolButton_480_clicked();

    void on_toolButton_487_clicked();

    void on_toolButton_488_clicked();

    void on_toolButton_484_clicked();

    void on_toolButton_479_clicked();

    void on_pushButton_600_clicked();

    void on_toolButton_481_clicked();

    void on_toolButton_494_clicked();

    void on_toolButton_499_clicked();

    void on_toolButton_497_clicked();

    void on_pushButton_591_clicked();

    void on_toolButton_496_clicked();

    void on_pushButton_597_clicked();

    void on_pushButton_603_clicked();

    void on_toolButton_498_clicked();

    void on_pushButton_608_clicked();

    void on_toolButton_495_clicked();

    void on_toolButton_509_clicked();

    void on_toolButton_506_clicked();

    void on_toolButton_492_clicked();

    void on_toolButton_505_clicked();

    void on_pushButton_613_clicked();

    void on_pushButton_616_clicked();

    void on_toolButton_507_clicked();

    void on_pushButton_621_clicked();

    void on_toolButton_478_clicked();

    void on_toolButton_476_clicked();

    void on_toolButton_515_clicked();

    void on_pushButton_594_clicked();

    void on_toolButton_169_clicked();

    void on_toolButton_69_clicked();

    void on_toolButton_15_clicked();

    void on_toolButton_337_clicked();

    void on_toolButton_342_clicked();

    void on_pushButton_400_clicked();

    void on_pushButton_399_clicked();

    void on_pushButton_401_clicked();

    void on_pushButton_409_clicked();

    void on_pushButton_410_clicked();

    void on_pushButton_411_clicked();

    void on_toolButton_423_clicked();

    void on_pushButton_442_clicked();

    void on_pushButton_412_clicked();

    void on_pushButton_413_clicked();

    void on_pushButton_414_clicked();

    void on_pushButton_422_clicked();

    void on_pushButton_423_clicked();

    void on_pushButton_424_clicked();

    void on_pushButton_436_clicked();

    void on_pushButton_438_clicked();

    void on_toolButton_533_clicked();

    void on_toolButton_536_clicked();

    void on_pushButton_631_clicked();

    void on_pushButton_630_clicked();

    void on_pushButton_641_clicked();

    void on_pushButton_639_clicked();

    void on_pushButton_653_clicked();

    void on_pushButton_654_clicked();

    void on_pushButton_662_clicked();

    void on_pushButton_640_clicked();

    void on_pushButton_655_clicked();

    void on_pushButton_663_clicked();

    void on_pushButton_632_clicked();

    void on_pushButton_229_clicked();

    void on_pushButton_275_clicked();

    void on_toolButton_170_clicked();

    void on_pushButton_234_clicked();

    void on_pushButton_276_clicked();

    void on_toolButton_171_clicked();

    void on_toolButton_172_clicked();

    void on_pushButton_665_clicked();

    void on_pushButton_667_clicked();

    void on_pushButton_677_clicked();

    void on_pushButton_679_clicked();

    void on_toolButton_167_clicked();

    void on_pushButton_683_clicked();

    void on_pushButton_685_clicked();

    void on_pushButton_690_clicked();

    void on_pushButton_692_clicked();

    void on_toolButton_168_clicked();

    void on_pushButton_703_clicked();

    void on_pushButton_705_clicked();

    void on_pushButton_696_clicked();

    void on_pushButton_698_clicked();

    void on_toolButton_82_clicked();

    void on_toolButton_85_clicked();

    void on_toolButton_473_clicked();

    void on_toolButton_470_clicked();

    void on_toolButton_403_clicked();

    void on_toolButton_398_clicked();

    void on_toolButton_670_clicked();

    void on_toolButton_671_clicked();

    void on_toolButton_543_clicked();

    void on_toolButton_547_clicked();

    void on_toolButton_546_clicked();

    void on_toolButton_13_clicked();

    void on_toolButton_545_clicked();

    void on_toolButton_544_clicked();

    void on_EDIT_LAYOUT_APPEARANCE_Top_Bar_Edit_Layout_2_clicked();

    void on_toolButton_45_clicked();

    void on_toolButton_552_clicked();

    void on_toolButton_554_clicked();

    void on_toolButton_555_clicked();

    void on_toolButton_551_clicked();

    void on_toolButton_553_clicked();

    void on_toolButton_60_clicked();

    void on_toolButton_61_clicked();

    void on_toolButton_306_clicked();

    void on_toolButton_73_clicked();

    void on_pushButton_426_clicked();

    void on_toolButton_299_clicked();

    void on_toolButton_301_clicked();

    void on_pushButton_465_clicked();

    void on_EDIT_SETUP_COMMS_COMMS_SERVICES_OPCUA_BOTTOM_BAR_Back_clicked();

    void on_toolButton_309_clicked();

    void on_EDIT_SETUP_COMMS_COMMS_SERVICES_MODBUS_RS485_BOTTOM_BAR_Back_clicked();

    void on_pushButton_188_clicked();

    void on_toolButton_395_clicked();

    void on_toolButton_390_clicked();

    void on_EDIT_SETUP_GENERAL_FACTORY_DEMO_TRACES_BOTTOM_BAR_Back_clicked();

    void on_toolButton_384_clicked();

    void on_toolButton_385_clicked();

    void on_toolButton_386_clicked();

    void on_toolButton_387_clicked();

    void on_toolButton_523_clicked();

    void on_EDIT_SETUP_COMMS_NETWORK_ADMIN_Botton_Bar_Back_clicked();

    void on_EDIT_SETUP_COMMS_NETWORK_ADMIN_Botton_Bar_Finish_clicked();

    void on_EDIT_SETUP_GENERAL_ERROR_ALERT_ERROR_TYPES_Bottom_Bar_Finish_clicked();

    void on_EDIT_SETUP_GENERAL_ERROR_ALERT_ERROR_TYPES_Bottom_Bar_Back_clicked();

    void on_pushButton_288_clicked();

    void on_pushButton_287_clicked();

    void on_pushButton_285_clicked();

    void on_pushButton_284_clicked();

    void on_pushButton_283_clicked();

    void on_pushButton_407_clicked();

    void on_pushButton_406_clicked();

    void on_pushButton_405_clicked();

    void on_pushButton_529_clicked();

    void on_pushButton_530_clicked();

    void on_pushButton_531_clicked();

    void on_pushButton_494_clicked();

    void on_pushButton_495_clicked();

    void on_pushButton_497_clicked();

    void on_pushButton_295_clicked();

    void on_pushButton_294_clicked();

    void on_EDIT_SETUP_COMMS_TCPIP_DNS_MDNS_WINE_Botton_Bar_Back_clicked();

    void on_EDIT_SETUP_COMMS_TCPIP_DNS_MDNS_WINE_Botton_Bar_Finish_clicked();

    void on_EDIT_SETUP_COMMS_TCPIP_PORT_Bottom_Bar_Back_clicked();

    void on_EDIT_SETUP_COMMS_TCPIP_PORT_Bottom_Bar_Finish_clicked();

    void on_toolButton_39_clicked();

    void on_pushButton_301_clicked();

    void on_pushButton_300_clicked();

    void on_EDIT_SETUP_COMMS_TCPIP_Bottom_Bar_Back_clicked();

    void on_EDIT_SETUP_COMMS_TCPIP_Bottom_Bar_Finish_clicked();

    void on_EDIT_SETUP_COMMS_TCPIP_Top_Bar_Comms_clicked();

    void on_EDIT_SETUP_COMMS_TCPIP_Top_Bar_Edit_Setup_clicked();

    void on_pushButton_492_clicked();

    void on_pushButton_491_clicked();

    void on_pushButton_490_clicked();

    void on_pushButton_503_clicked();

    void on_pushButton_502_clicked();

    void on_pushButton_501_clicked();

    void on_pushButton_500_clicked();

    void on_EDIT_SETUP_COMMS_COMMS_SERVICES_OPCUA_TOP_BAR_Comms_Services_clicked();

    void on_EDIT_SETUP_COMMS_COMMS_SERVICES_OPCUA_TOP_BAR_Comms_clicked();

    void on_EDIT_SETUP_COMMS_COMMS_SERVICES_OPCUA_TOP_BAR_Edit_Setup_clicked();

    void on_pushButton_467_clicked();

    void on_pushButton_470_clicked();

    void on_pushButton_468_clicked();

    void on_pushButton_469_clicked();

    void on_pushButton_461_clicked();

    void on_pushButton_460_clicked();

    void on_pushButton_462_clicked();

    void on_pushButton_459_clicked();

    void on_pushButton_464_clicked();

    void on_pushButton_473_clicked();

    void on_pushButton_472_clicked();

    void on_pushButton_297_clicked();

    void on_pushButton_298_clicked();

    void on_pushButton_324_clicked();

    void on_pushButton_323_clicked();

    void on_pushButton_322_clicked();

    void on_pushButton_307_clicked();

    void on_pushButton_306_clicked();

    void on_toolButton_310_clicked();

    void on_pushButton_304_clicked();

    void on_pushButton_303_clicked();

private:
    Ui::MainWindow *ui;
    QStandardItemModel *model;
    QStandardItemModel *model1;
    QStandardItemModel *model2;
    QStandardItemModel *model3;
    QStandardItemModel *model4;
    QStandardItemModel *model5;
    QStandardItemModel *model6;
    QStandardItemModel *model7;
    QStandardItemModel *model8;
    QStandardItemModel *model9;
    QStandardItemModel *model10;
    QStandardItemModel *model11;
    QStandardItemModel *model12;
    QStandardItemModel *model13;
    QStandardItemModel *model14;
    QStandardItemModel *model20;
    QStandardItemModel *model21;
    QStandardItemModel *model22;
    QStandardItemModel *model25;
	QStandardItemModel *model81;
    QStandardItemModel *model82;
    QStandardItemModel *model83;
    QStandardItemModel *model84;
    QStandardItemModel *scale_model;
    QStandardItemModel *log_model;
    QStandardItemModel *numb_model;
    QStandardItemModel *rav_model;
    QStandardItemModel *alarm_model;
    QStandardItemModel *alarm_model1;
    QStandardItemModel *alarm_model2;
    QStandardItemModel *alarm_model3;
    QStandardItemModel *alarm_model4;
    QStandardItemModel *alarm_model5;
    QStandardItemModel *alarm_model6;
    QStandardItemModel *alarm_model7;
    QStandardItemModel *screen_model;
    QStandardItemModel *chart_model;
    QStandardItemModel *tabdisplay_model;
    QStandardItemModel *localization_model;
    QStandardItemModel *credit_model;
    QStandardItemModel *sntp_model;
    QStandardItemModel *policy_model;
    QStandardItemModel *user_model;
    QStandardItemModel *newuser_model;
    QStandardItemModel *engineer_model;
    QStandardItemModel *supervisor_model;
    QStandardItemModel *technician_model;
    QStandardItemModel *operator_model;
    QStandardItemModel *marker_model;
    QStandardItemModel *timesync_model;
    QStandardItemModel *event_model;
    QStandardItemModel *counter_model;
    QStandardItemModel *peers_model;
    QStandardItemModel *web_model;
    QStandardItemModel *network_model;
    QStandardItemModel *security_model;
    QStandardItemModel *identity_model;
    QStandardItemModel *erroralert_model;
    QStandardItemModel *errortype_model;
    QStandardItemModel *demotraces_model;
    QStandardItemModel *mediaconf_model;
    QStandardItemModel *email_model;
    QStandardItemModel *emailtemplate_model;
    QStandardItemModel *opc_model;
    QStandardItemModel *ftp_model;
    QStandardItemModel *tcp_model;
    QStandardItemModel *tcpwin_model;
    QStandardItemModel *tcpport_model;
    QStandardItemModel *storagealarm_model;
    QStandardItemModel *emailtemplate_model_51;
    QStandardItemModel *emailtemp_model;
    QStandardItemModel *linearization_model;
    QStandardItemModel *linearizationtable_model;
    QStandardItemModel *slave_model;
    QStandardItemModel *rs485_model;
    QStandardItemModel *appearance_model;
    QStandardItemModel *layoutsetting_model;
    QStandardItemModel *standardscreen_model;


    QCustomPlot *mPlot;
    QPointer<QCPGraph> mGraph1;
    QPointer<QCPGraph> mGraph2;
    QPointer<QCPGraph> mGraph3;
    QPointer<QCPGraph> mGraph4;
    QPointer<QCPGraph> mGraph5;
    QPointer<QCPGraph> mGraph6;
    QPointer<QCPGraph> mGraph7;
    QPointer<QCPGraph> mGraph8;

    QWidget *window1;
    QWidget *window2;
    QWidget *maxminwindow1;
     QWidget *maxminwindow2;
     QGridLayout *maxmingridLayout;




     QWidget *plotwindow1;
     QWidget *plotwindow2;
      QGridLayout *plotgridLayout;



    QFrame *Frame;
    CMaxMin maxmin;
    //create labels based on selection of pens
    QList<int> selected_pens;
    QList<int> selected_MaxMin_pens;
    QStringList pen_names;
    QHBoxLayout* HLayout;
    QGridLayout *gridLayout;

    QHBoxLayout* firstRowLayout;

        QCPAxis *sec;
        AxisTag *mTag1;
        AxisTag *mTag2;
        AxisTag *mTag3;
        AxisTag *mTag4;
        AxisTag *mTag5;
        AxisTag *mTag6;
        AxisTag *mTag7;
        AxisTag *mTag8;
        QTimer mDataTimer;
        T_MAXMIN_MODE resetmode_bypen;
};
#endif // MAINWINDOW_H

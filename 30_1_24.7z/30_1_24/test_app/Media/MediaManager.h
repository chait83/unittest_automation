/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  Media Manager
/// @n Filename:  MediaManager.cpp
/// @n Description: Provides the access point for the media manager
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log:
//  17  Stability Project 1.14.1.1 7/2/2011 4:58:43 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  16  Stability Project 1.14.1.0 7/1/2011 4:27:44 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  15  V6 Firmware 1.14 8/19/2008 5:32:23 PM  Binsy Pillai  
//  added usb change --- refer CR 3039
//  14  V6 Firmware 1.13 8/18/2008 12:32:15 PM  Binsy Pillai  to
//  revert back usb changes .... need to test the decrease time during
//  upgrade ...and revert back the latest file later
//  13  V6 Firmware 1.12 8/12/2008 4:59:40 PM  Binsy Pillai  
//  fixed CR 3039 : On upgrading of firmware the message in message
//  options shows
//  "unknown external device attached " even if no device is attached'
//  12  V6 Firmware 1.11 12/20/2006 3:36:52 PM  Roger Dawson  
//  Phase 3b merges into the main build. Added return varaible to the
//  CheckDeviceChanges method in order to improved the robustness of the
//  thread.
//  11  V6 Firmware 1.10 6/19/2006 9:16:05 PM  Roger Dawson  
//  Modifications to allow the status list on the logging dialog to show
//  the amount of time until the scheduled export media is full.
//  10  V6 Firmware 1.9 5/4/2006 8:47:38 PM Andy Kassell  Add
//  percentage free data items for Front CF USB1 and USB2 drives
//  9 V6 Firmware 1.8 5/3/2006 8:55:44 PM Graham Waterfield
//  Added extra state to indicate that the thread is not currently
//  initialised
//  8 V6 Firmware 1.7 5/2/2006 8:49:47 PM Roger Dawson  
//  Modified the media notifcation thread to be message based rather than
//  periodically checking the device state. Also modified logging code in
//  order to reduce the number of times the current logging device state
//  is updated.
//  7 V6 Firmware 1.6 4/5/2006 5:11:34 PM Martin Miller 
//  Clear schedule space low warning state on media removal.
//  6 V6 Firmware 1.5 2/24/2006 8:14:56 PM  Andy Kassell  
//  Refactor MediaManager and thread
//  5 V6 Firmware 1.4 2/10/2006 7:21:53 PM  Andy Kassell  Add
//  Front CF insert count for life history
//  Fix bug that prevents front CF from being checked
//  ** Needs a restructure **
//  4 V6 Firmware 1.3 1/30/2006 9:49:38 PM  Martin Miller 
//  Critical section singleton initialisation.
//  3 V6 Firmware 1.2 1/25/2006 3:31:20 PM  Martin Miller 
//  Moved media detection to it's own module from the DAL.
//  2 V6 Firmware 1.1 1/24/2006 9:54:48 PM  Martin Miller 
//  Corrected base class inheritance
//  1 V6 Firmware 1.0 1/24/2006 9:14:57 PM  Martin Miller  
// $
//
//
//		  Shankar Rao P		24/11/2014		Fix for PAR# 1-3KM3QDH - Minitrend & Multitrend 
//												gets Lock up when configured for NAS
// **************************************************************************
#ifndef __MEDIAMANAGER_H_INCLUDED__
#define __MEDIAMANAGER_H_INCLUDED__
#include "PassiveModule.h" 
#include "DAL.h"
#include "NVVariables.h"
#include "QueueMonitor.h"
#include <QMutex>
#define MAX_DEVCLASS_NAMELEN 100
const int DEVICE_CHECK_PATH_LENGTH = 128;		///< Max Path length for device checks
const int DEVICE_LENGTH = 50;
typedef struct {
	GUID guidDevClass;
	DWORD dwReserved;
	BOOL fAttached;
	int cbName;
	TCHAR szName[1];
} DEVDETAIL, *PDEVDETAIL;
// Thread state
typedef enum {
	NT_RUNNING, NT_SHUTDOWN, NT_NOT_STARTED
} NOTIFICATION_STATE;
// Device monitoring information
typedef struct {
	ULONG freeSpace;										///< Free space on dive in KB
	ULONG totalSize;										///< Total size of device in KB
	CDataItemGeneral *pDIPCFree;							///< pointer to Data item for %age free of device
	BOOL IsInserted;										///< TRUE if device inserted - otherwise FALSE
	WCHAR nameForAvailable[DEVICE_CHECK_PATH_LENGTH + 1];		///< Cached name of device
	WCHAR nameForSize[DEVICE_CHECK_PATH_LENGTH + 1];			///< Cached name of device
	int reloadCountDown;									///< reload timer for Countdown till device checked
	int countDown;											///< Countdown till device checked
} NOTIFICATION_DATA;
/// Track the state of the front compact flash card to monitor the number of insertions
typedef enum {
	EXT_CF_STATE_UNINITIALISED,		///< CF card state not yet determined
	EXT_CF_STATE_INSERTED,			///< Card is inserted
	EXT_CF_STATE_OUT				///< Card is out, NOT inserted
} T_EXT_CF_STATES;
//**Class*********************************************************************
///
/// @brief Media manager, detacts and identifies storage media
/// 
///
//****************************************************************************
class CMediaManager: public CPassiveModule {
public: // methods
	static CMediaManager* GetHandle();
	BOOL CleanUp();
	void Initialise();
	void InitialiseDeviceInfo(T_STORAGE_DEVICE device, int tenthsOfASecondToCheck);
	void CheckDevice(T_STORAGE_DEVICE device, const bool bDEVICE_REMOVED);
	void ClearAsDeviceNotInserted(T_STORAGE_DEVICE device);
	bool CheckExternalDeviceNotification(WCHAR wcaDevName[DEVICE_LENGTH]); //CR3039
	// Device notification stuff
	void StartMediaIdentification(BOOL state);
	NOTIFICATION_STATE GetRunState() {
		return m_ThreadState;
	}
	;	///< Get status of thread		
	// OS Device status
	BOOL GetKeyboardState() {
		return m_Keyboard;
	}
	;
	BOOL IsDeviceInserted(T_STORAGE_DEVICE device) { /*if( device == IDS_SHARE)
	 m_DeviceInfo[device].IsInserted = (CheckSharedFolder() == 0);*/
		return m_DeviceInfo[device].IsInserted;
	}
	;
	ULONG GetFreeSpaceK(T_STORAGE_DEVICE device) {
		return m_DeviceInfo[device].freeSpace;
	}
	;
	ULONG GetTotalSizeK(T_STORAGE_DEVICE device) {
		return m_DeviceInfo[device].totalSize;
	}
	;
	/*	BOOL GetCompactFlashState( T_ENUMERATED_DEVICE device )	const	{ return m_DeviceThreadState.m_CompactFlash[device]; };
	 BOOL GetHardDiskState( T_ENUMERATED_DEVICE device ) const		{ return m_DeviceThreadState.m_HardDisk[device]; };
	 ULONG GetUSBSize( T_ENUMERATED_DEVICE device ) const			{ return m_DeviceThreadState.m_USB_Size[device]; };
	 ULONG GetUSBFree( T_ENUMERATED_DEVICE device ) const			{ return m_DeviceThreadState.m_USB_FreeSpace[device]; };
	 ULONG GetCFSize( T_ENUMERATED_DEVICE device ) const				{ return m_DeviceThreadState.m_CF_Size[device]; };
	 ULONG GetCFFree( T_ENUMERATED_DEVICE device ) const				{ return m_DeviceThreadState.m_CF_FreeSpace[device]; };
	 */
	/// Front CF insertions
	ULONG GetNumberOfCFInsertions() {
		return m_ExtCFInsertions.ul;
	}
	;
	void SetFrontCompactFlashState(T_EXT_CF_STATES state) {
		m_ExtCFState = state;
	}
	;
	T_EXT_CF_STATES GetFrontCompactFlashState() {
		return m_ExtCFState;
	}
	;
	void RegisterFrontCompactFlashInsertion();
	LONG CheckSharedFolder();
	BOOL IsServerRunning(LPCTSTR pszHostName);
	//PSR Fix for PAR# 1-3KM3QDH - Minitrend & Multitrend gets Lock up when configured for NAS begin
	bool RunLogOnFailureChecker();
	bool CloseLogOnFailureChecker();
	bool IsLogOnFailureCheckerRunning();
	//PSR Fix for PAR# 1-3KM3QDH - Minitrend & Multitrend gets Lock up when configured for NAS end
private: // methods
	CMediaManager();
	~CMediaManager();
//PSR Fix for PAR# 1-3KM3QDH - Minitrend & Multitrend gets Lock up when configured for NAS begin
	static UINT LogOnFailureCheckerThread(LPVOID pParam); // Thread for the authentication Ln window dialog
	void WaitForThread(HANDLE &handle);
//PSR Fix for PAR# 1-3KM3QDH - Minitrend & Multitrend gets Lock up when configured for NAS end
private: // data
	BOOL bInitialised;
	static CMediaManager *pInstance;					///< Single instance object pointer
	static QMutex hCreationMutex;						///< Object creation mutex
	NOTIFICATION_DATA m_DeviceInfo[IDS_MAX_DEVICES];	///< Device change notification thread state
	NOTIFICATION_STATE m_ThreadState;					///< Status of notification thread			
	QThread *m_hDeviceThread;						///< Device notification thread
	BOOL m_Keyboard;									///< USB keyboard in/out
	T_EXT_CF_STATES m_ExtCFState;						///< External compact flash state
	CNVBasicVar *m_pNVExtCFInsertions;					///< ptr to NV variable to track number of flash card insertions
	COMBO_VAR4 m_ExtCFInsertions;						///< Number of external CF insertions
	CQMonitor *m_pQueueMonitor;							///< Queue monitor handle
	static QMutex m_hCritical;
//PSR Fix for PAR# 1-3KM3QDH - Minitrend & Multitrend gets Lock up when configured for NAS begin
	QThread *m_hLogOnFailureCheckerThread;							//Logon failed dialog box checker
	bool m_bLogOnFailureCheckerRunnig; ///Increment the count on every Run request log on checker and decrement on every Close call
	static QMutex m_hCSLogOnFailureChecker;
//PSR Fix for PAR# 1-3KM3QDH - Minitrend & Multitrend gets Lock up when configured for NAS end
};
// Device change notification thread 
class CNotificationThread: public QThread {
	friend class CMediaManager;
public:
	/// Enum indicating the various thread states
	typedef enum {
		dtsINIT, dtsRUNNING, dtsSHUTDOWN,
	} T_DEVICE_THREAD_STATE;
	static T_DEVICE_THREAD_STATE ms_eState;
	// Method that signals to the thread we are shutting down
	static void ShutdownThread();
	// Method that determines of the thread is up and running and it's respective values are
	// valid
	static const bool IsInitialised() {
		return (ms_eState != dtsINIT);
	}
private:
	// Thread function for message processing
	static UINT ThreadFunc(LPVOID lpParam);
	// Constructor
	CNotificationThread();
	// Destructor
	virtual ~CNotificationThread();
	// Method that checks the device change messages
	static const bool CheckDeviceChanges(HANDLE hQueue);
	/// The current thread state
};
#endif // __MEDIAMANAGER_H_INCLUDED__

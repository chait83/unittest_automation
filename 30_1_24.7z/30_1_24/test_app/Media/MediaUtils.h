// MediaUtils.h: Storage utilities.
//
//////////////////////////////////////////////////////////////////////
#if !defined(__MEDIA_U_H__)
#define __MEDIA_U_H__
#include "StoragePaths.h"
#include "DAL.h"
#include "V6Versions.h"
#include <vector>
#include <string>
#include <algorithm>
using namespace std;
#define TWO_GB_SIZE 2147483648
#define FOUR_GB_SIZE 4294967295
//
// Byte offsets
// This is a quick and dirty format check.
//
#define FAT_16_FORMAT	54
#define FAT_32_FORMAT	82
#define VOLUME_SIZE		11
#define FAT_16_VOLUME	43
#define FAT_32_VOLUME	71
// Media format
typedef enum {
	FORMAT_UNKNOWN = 0, FORMAT_FAT_16, FORMAT_TFAT_16, FORMAT_FAT_32, FORMAT_TFAT_32
} T_MEDIA_FORMAT;
typedef enum {
	MS_UNKNOWN = 0,
	/*MS_8M,
	 MS_16M,
	 MS_32M,
	 MS_64M,
	 MS_128M,
	 MS_256M,
	 MS_512M,*/
	MS_128M, MS_1G, MS_2G, MS_4G, MS_8G, MS_OTHER
} T_MEDIA_SIZE;
typedef enum {
	SELF_CERT = 0, CA_CERT, EMAIL_CERT
} T_MEDIA_CERT_TYPE;
//**Class*********************************************************************
///
/// @brief 
/// 
//****************************************************************************
class MediaUtils {
public:
	ULONG Meg;
	MediaUtils();
	~MediaUtils();
	static bool GetDiskFreeSpaceEx(QString device, quint64 *userFreeSpace, quint64 *totalSpace,
			quint64 *totalFreeSpace = NULL);
	static const T_MEDIA_FORMAT Mediaasprintf(QString wszVolume);
	T_MEDIA_SIZE MediaSize(QString device);
	BOOL PrepareInternal(T_STORAGE_DEVICE drive);
	BOOL CheckInternalMedia(T_STORAGE_DEVICE drive);
	BOOL PrepareExternal(T_STORAGE_DEVICE drive);
	BOOL CheckExternalMedia(T_STORAGE_DEVICE drive);
	ULONG GetFreeDiskSpace() {
		return Meg;
	}
	static void DeleteFile(T_STORAGE_DEVICE device, T_STORAGE_PATH path, const QString fileName);
};
//**Class*********************************************************************
///
/// @brief 
/// 
//****************************************************************************
class CSoftwareUpdate {
public:
	CSoftwareUpdate();
	~CSoftwareUpdate();
	BOOL indexOfUpdatePackage(WCHAR wcOEM = (WCHAR) '?');
	BOOL indexOfIOUpdatePackage(WCHAR wcOEM = (WCHAR) '?');
	BOOL indexOfCertPackage(T_MEDIA_CERT_TYPE certTypeUsed = SELF_CERT);
	void CancelUpdate() {
		m_UpgradeFound = FALSE;
	}
	;	// Cancel the software update
	const WCHAR* GetFileName() {
		return m_PackageFile;
	}
	;		// Get the firmware update file
	const WCHAR* GetCertFileName() {
		return m_CertPackageFile;
	}
	;	// Get the certificate pckg file name
	const WCHAR* GetCertEmailRootFileName() {
		return m_CertEmailRootFile;
	}
	; //Get the Root CA certificate path and file name
	const WCHAR* GetCertCARootFileName() {
		return m_CertCARootFile;
	}
	; //Get the Root CA certificate path and file name
	const WCHAR* GetCertCAServerFileName() {
		return m_CertCAServerFile;
	}
	; //Get the Server CA pfx Certificate path and file name	
	QString GetUpgradeVersion() {
		return m_UpgradeVersion;
	}
	;	// Get version number of upgrade
	T_RELEASE_TYPE GetUpgradeType() {
		return m_UpgradeType;
	}
	;		// Get release type of upgrade
	T_STORAGE_DEVICE GetInstallDriveName() {
		return m_InstallDrive;
	}
	;		// Get the firmware upgrade file drive name
	BOOL IsCertPackageAvailable(T_STORAGE_DEVICE DriveToTry);
	BOOL IsCertCAFolderPathAvailable(T_STORAGE_DEVICE DriveToTry);
	BOOL IsEmailCertPackageAvailable(T_STORAGE_DEVICE DriveToTry);
private:	// Methods
	BOOL IsPackageAvailable(T_STORAGE_DEVICE DriveToTry, WCHAR wcOEM = (WCHAR) '?');
	BOOL IsIOPackageAvailable(T_STORAGE_DEVICE DriveToTry, WCHAR wcOEM = (WCHAR) '?');
	std::vector<std::wstring> GetAllCACertsName(QString folder);
private:	// Members
	BOOL m_UpgradeFound;				///< An upgrade has been found
	BOOL m_CertpackageFound;				///< An upgrade has been found
	QString m_UpgradeVersion;			///< Version of Upgrade found
	T_RELEASE_TYPE m_UpgradeType;		///< Release type of Upgrade found
	T_STORAGE_DEVICE m_InstallDrive;		///< Installation drive of firmware update
	WCHAR m_PackageFile[MAX_PATH];		///< Package filename
	WCHAR m_CertPackageFile[MAX_PATH];	///< Certificate Package filename
	WCHAR m_CertCARootFile[MAX_PATH]; ///CA Root FilePath
	WCHAR m_CertCAServerFile[MAX_PATH]; ///CA Server FilePath	
	WCHAR m_CertEmailRootFile[MAX_PATH]; ///CA Root FilePath
};
#endif // !defined(__MEDIA_U_H__)

/// @file
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Media Manager
/// @n Filename:	Storage.cpp
/// @n Description: Provides the access point for the media manager
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 38	Stability Project 1.33.1.3	7/2/2011 4:56:25 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 37	Stability Project 1.33.1.2	7/1/2011 4:38:11 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 36	Stability Project 1.33.1.1	3/17/2011 3:20:19 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 35	Stability Project 1.33.1.0	2/15/2011 3:02:47 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
// **************************************************************************
// Storage.cpp: implementation of the CStorage class.
//
//////////////////////////////////////////////////////////////////////
#include <QMutex>
#include <QDir>
#include <QFileInfo>
#include <QDebug>
#include "CStorage.h"
#include "TVtime.h"
#include "MediaUtils.h"
#include<QDataStream>
#ifndef V6_VER_qDebug_DISABLE
#ifndef V6_CRC_DISABLE
#include "V6crc.h"
#endif
#include "V6Versions.h"
#include "Defines.h"
#endif
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
static QMutex csFiles;
static BOOL csFilesInit = FALSE;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
#ifdef DBL_STORAGE_CS_THREAD
extern ULONG glb_MsgCntMsg;
extern ULONG glb_MsgCntPan;
#endif
//****************************************************************************
/// Storage object constructor
///
/// @return No return value from the object constructor
///
/// @note No initialisation is performed, owner must use Open() before use
//****************************************************************************
CStorage::CStorage() : QFile() {
	if (!csFilesInit)
		csFilesInit = TRUE;
}
//****************************************************************************
/// Storage object constructor
///
/// @return No return value from the object constructor
///
/// @note No initialisation is performed, owner must use Open() before use
//****************************************************************************
CStorage::CStorage(LPCTSTR lpszFileName, QFileDevice::OpenMode nOpenFlags) : QFile() {
	// do not call the constructor that allows the filename and flags to be passed in as
	// we have now way of trapping exceptions (except from the calling function). Instead,
	// lets explicitly call the open method as this has exception handling inside
	if (!csFilesInit)
		csFilesInit = TRUE;
	Open(lpszFileName, nOpenFlags);
}
//****************************************************************************
/// Storage object destructor
///
/// @return No return value from the object destructor
///
//****************************************************************************
CStorage::~CStorage() {
}
BOOL CStorage::Open(QString Name, UINT Flags, QFileDevice::FileError *Error) {
    Open(Name.toLocal8Bit().data(),Flags,Error);
}
//**************************************************************************
/// QFile wrapper methods
//**************************************************************************
//****************************************************************************
/// Open a file
///
/// @note See QFile::Open for parameters and return value
///
//****************************************************************************
BOOL CStorage::Open(LPCTSTR Name, UINT Flags, QFileDevice::FileError *Error) {
	BOOL bSuccess = FALSE;
	Lock();
	/// TODO copy Name to m_strFileName
	try {
		m_hFile = new QFile(Name);

        /// TODO: Open the file w.r.t to the flags
		if (m_hFile->open(QIODevice::ReadOnly)) {
			bSuccess = true;
		} else {
		}
		throw QString("Failed to open file");
	} catch (const std::exception &e) {
		// unhandled exception
		QString errormessage = QString::fromStdString(e.what());
		ShowError("Open", Name, errormessage);
		bSuccess = FALSE;
	}
	Unlock();
	return bSuccess;
}
//****************************************************************************
/// Close a file
///
/// @note See QFile::Close for parameters and return value
///
//****************************************************************************
void CStorage::Close(void) {
	Lock();
	try {
		m_hFile->close();
	} catch (const std::exception &e) {
		// unhandled exception
		QString errormessage = QString::fromStdString(e.what());
		ShowError("Close", m_strFileName, errormessage);
	}
	Unlock();
	return;
}
//****************************************************************************
/// Read a file
///
/// @note See QFile::Read for parameters and return value
///
//****************************************************************************
UINT CStorage::Read(void *Buffer, UINT Size) {
	Lock();
	UINT uiBYTES_READ = 0;
	try {
		if (m_hFile->open(QIODevice::ReadOnly)) {
			uiBYTES_READ = m_hFile->read(reinterpret_cast<char*>(Buffer), Size);
			m_hFile->close();
		}
	} catch (const std::exception &e) {
		// unhandled exception
		QString errormessage = QString::fromStdString(e.what());
		ShowError("Read", m_strFileName, errormessage);
	}
	Unlock();
	return uiBYTES_READ;
}
//****************************************************************************
//	const bool CStorage::Write( const void *pvBUFFER, UINT Size, bool bNotUsed /* = false */ )
///
/// Write a file
///
/// @return		ERROR_SUCCESS if the data was written successfully
///
//****************************************************************************
const DWORD CStorage::Write(const void *pvBUFFER, UINT Size, bool bNotUsed /* = false */) {
	Lock();
	DWORD dwRetVal = ERROR_SUCCESS;
	try {
		/// TODO Fid alternative to assert_VALID
		assert(m_hFile);
//        assert_VALID(this);
//        assert(m_hFile != hFileNull);
		if (Size != 0) {
			assert(pvBUFFER != NULL);
			QDataStream out(m_hFile);
			m_hFile->open(WriteOnly);
			DWORD nWritten = out.writeRawData(static_cast<const char*>(pvBUFFER), Size);
			if (nWritten != Size) {
				//dwRetVal = GetLastError();
				dwRetVal = ERROR_DISK_FULL;
				throw std::runtime_error("Error:Partial writing of data");
			} else if (nWritten == (DWORD) -1) {
				dwRetVal = ERROR_DISK_FULL;
				throw std::runtime_error("Failed to write any data");
			} else {
				// avoid Win32 "null-write" option - don't bother throwing an error though as it
				// shouldn't have done any harm
				dwRetVal = ERROR_SUCCESS;
			}
		}
	} catch (const std::exception &e) {
		// Raised an exception so report the cause
		QString errorstring = QString::fromStdString(e.what());
		ShowError("Write", m_strFileName, errorstring);
		//dwRetVal = GetLastError();
		//pkEx->Delete();
	} catch (...) {
		// unhandled exception
		ShowError("Write", m_strFileName);
		//dwRetVal = GetLastError();
	}
	Unlock();
	return dwRetVal;
}
//****************************************************************************
/// Seek a file
///
/// @note See QFile::Seek for parameters and return value
///
//****************************************************************************
LONG CStorage::Seek(LONG Offset, UINT from) {
	Lock();
	LONG lBytesOffset = 0;
	try {
		if (m_hFile->open(QIODevice::ReadWrite)) {
			if (m_hFile->seek(Offset + from)) {
				lBytesOffset = m_hFile->pos();
				if (lBytesOffset > LONG_MAX) {
#ifndef V6_VER_qDebug_DISABLE
					if (V6_RELEASE != RELEASE_PRODUCTION) {
						QString strError = QString("%1, Seek method - Offset greater than a LONG").arg(fileName());
#ifdef _NOPROMPTMESSAGE
                        MessageBox( NULL, strError, L"CStorage Error", MB_OK | MB_TOPMOST);
#endif
					}
#endif
				}
			}
		}
	} catch (std::exception &e) {
		// Raised an exception so report the cause
		QString errorstring = QString::fromStdString(e.what());
		ShowError("Seek", m_strFileName, errorstring);
		//pkEx->Delete();
	} catch (...) {
		// unhandled exception
		ShowError("Seek", m_strFileName);
	}
	Unlock();
	return lBytesOffset;
	// make sure the returned value is not greater than a LONG
}
//****************************************************************************
/// Get File Position
///
/// @note See QFile::GetPosition for parameters and return value
///
//****************************************************************************
unsigned long CStorage::GetPosition(void) {
	Lock();
	quint64 ullFILE_POSITION = 0;
	try {
		ullFILE_POSITION = m_hFile->pos();
		// make sure the returned value is not greater than a LONG
		if (ullFILE_POSITION > LONG_MAX) {
#ifndef V6_VER_qDebug_DISABLE
			if (V6_RELEASE != RELEASE_PRODUCTION) {
				QString strError = QString("%1, GetPosition method - Position greater than a LONG").arg(fileName());
#ifdef _NOPROMPTMESSAGE
                MessageBox( NULL, strError, L"CStorage Error", MB_OK | MB_TOPMOST);
#endif
			}
#endif
		}
	} catch (...) {
		// unhandled exception
		ShowError("GetPosition", m_strFileName);
	}
	Unlock();
	return static_cast<LONG>(ullFILE_POSITION);
}
//****************************************************************************
/// QFile Extension methods
//****************************************************************************
//****************************************************************************
/// GetFileSize returns the size for the named file
///
/// @param[in] 	Name, file path and name
///
/// return ULONG file size or 0 if the file wasn't found
///
//****************************************************************************
ULONG CStorage::GetFileSize(TCHAR *Filename) {
	ULONG ulResult = 0;
	//HANDLE hFile = NULL;
	Lock();
	QFile *m_file_local;
	m_file_local = new QFile(Filename);
	try {
		if (m_file_local->exists()) {
			ulResult = m_file_local->size();
		}
	} catch (...) {
		// unhandled exception
		ShowError("GetFileSize", m_strFileName);
	}
	Unlock();
	delete m_file_local;
	return ulResult;
}
//****************************************************************************
/// Deletes the specified file
///
/// @param[in] 	QString &rstrFilename - the required filename
///
/// return TRUE if the operation successeded, false if not
///
//****************************************************************************
BOOL CStorage::DeleteFile(QString fileName) {
	QFile *m_local_file;
	m_local_file = new QFile(fileName);
	BOOL succeeded = m_local_file->remove(fileName);
	delete m_local_file;
	return succeeded;
}
//****************************************************************************
/// exists check if a file exists
///
/// @param[in] 	QString &rstrFilename - the required filename
///
/// return TRUE if the file exists, else FALSE
///
//****************************************************************************
BOOL CStorage::FileExists(QString &filename) {
	Lock();
	BOOL exists = QFile::exists(filename);
	Unlock();
	return exists;
}
bool CStorage::SetStatus(QString file_name, CFileStatus *status) {
}
bool CStorage::GetStatus(QString file_name, CFileStatus *status) {
	status->m_szFullName = file_name;
	status->setFile(file_name);
	status->m_attribute = (status->isDir() << 4) | (status->isHidden() << 1) | (1 & ~status->isWritable());
	status->m_size = status->size();
	status->m_ctime = status->created();
	status->m_mtime = status->lastModified();
	status->m_atime = status->lastRead();
}
//****************************************************************************
/// FileRead read a file into a memory buffer
///
/// @param[in] 	Name, file path and name
/// @param[in]	Buffer to store the data
/// @param[in]	Size of data to read
///
/// return TRUE if all is OK, else FALSE
///
//****************************************************************************
BOOL CStorage::FileRead(TCHAR *FileName, void *Buffer, DWORD Size) {
	Lock();
	BOOL bResult = FALSE;
	//HANDLE hFile = NULL;
	DWORD dwBytesRead = 0;
	QFile *m_local_file = new QFile(FileName);
	try {
		if (m_local_file->open(ReadOnly)) {
			dwBytesRead = m_local_file->read(static_cast<char*>(Buffer), Size);
			if (dwBytesRead == Size) {
				bResult = TRUE;
			}
			m_local_file->close();
		}
	} catch (...) {
		// unhandled exception
		ShowError("FileRead", m_strFileName);
	}
	Unlock();
	return bResult;
}
//****************************************************************************
/// FileWrite Store a memory buffer in a file
///
/// @param[in] 	Name, file path and name
/// @param[in]	Buffer to store the data
/// @param[in]	Size of data to write
///
/// return TRUE if all is OK, else FALSE
///
//****************************************************************************
BOOL CStorage::FileWrite(TCHAR *FileName, void *Buffer, DWORD Size) {
	Lock();
	BOOL bResult = FALSE;
	QFile hFile(FileName);
	DWORD dwBytesRead = 0;
	if (hFile.open(WriteOnly)) {
		QDataStream out(&hFile);
		dwBytesRead = out.writeRawData(static_cast<const char*>(Buffer), Size);
		if (dwBytesRead == Size) {
			bResult = TRUE;
		} else {
			bResult = FALSE;
		}
	}
	Unlock();
	return bResult;
}
#ifndef V6_CRC_DISABLE
//****************************************************************************
/// Storage object add CRC
///
/// @return TRUE if the CRC was added OK, else FALSE
///
/// @note 
//****************************************************************************
BOOL CStorage::AddCRC() {
	Lock();
	WORD wNewCRC = 0;
	wNewCRC = GetCRC( FALSE);
	Seek(0L, QFile::atEnd());
	Write(&wNewCRC, sizeof(WORD));
	Unlock();
	return TRUE;
}
//****************************************************************************
/// Storage object validate CRC
///
/// @return TRUE if the CRC is OK, else FALSE
///
/// @note 
//****************************************************************************
BOOL CStorage::ValidateCRC() {
	WORD wNewCRC = 0;
	WORD dwReadCRC = 0;
	wNewCRC = GetCRC( TRUE);
	const LONG lOFFSET = sizeof(WORD);
	Seek(-(lOFFSET), QFile::atEnd());
	Read(&dwReadCRC, sizeof(WORD));
	if (wNewCRC != dwReadCRC)
		return FALSE;
	else
		return TRUE;
}
#endif
//****************************************************************************
/// Check to see if a file is set to read only
///
/// @param[in] pPathAndFileName, path and filename of the file to check
///
/// @return TRUE if file is read only Otherwise FALSE
//****************************************************************************
BOOL CStorage::IsReadOnly(TCHAR *pPathAndFileName) {
#ifndef DBL_STORAGE_NO_CS_LOCK
#ifdef DBL_STORAGE_CS_THREAD
    csFiles.lock();
    glb_MsgCntMsg = GetThreadId(GetCurrentThread()); //MFree - ThId to qDebug the csFiles holder
#else
	csFiles.lock();
#endif
#endif
	BOOL IsThisReadOnly = FALSE;
	QFileInfo fileinfo(pPathAndFileName);
	// Get current status
	if (fileinfo.exists()) {
		// Successful attribute get so check if read only bit is set
		if (!fileinfo.isWritable()) {
			IsThisReadOnly = TRUE;		// It's read only
		}
	}
#ifndef DBL_STORAGE_NO_CS_LOCK
	csFiles.lock();
#ifdef DBL_STORAGE_CS_THREAD
    glb_MsgCntMsg = 0; //MFree - ThId to qDebug the csFiles Free
    glb_MsgCntPan = GetThreadId(GetCurrentThread());//MFree - ThId to qDebug the csFiles requestor(latest)
#endif
#endif
	return IsThisReadOnly;
}
//****************************************************************************
/// Set a file attribute so that it is writable
///
/// @param[in] pPathAndFileName, path and filename of the file to make writable
///
/// @return TRUE if file made writable, otherwise FALSE
//****************************************************************************
BOOL CStorage::MakeFileWritable(TCHAR *pPathAndFileName) {
#ifndef DBL_STORAGE_NO_CS_LOCK
#ifdef DBL_STORAGE_CS_THREAD	
    csFiles.lock();
    glb_MsgCntMsg = GetThreadId(GetCurrentThread()); //MFree - ThId to qDebug the csFiles holder
#else
	csFiles.lock();
#endif
#endif
	BOOL writeableSuccess = FALSE;
	QFile file(pPathAndFileName);
	QFileInfo fileinfo(pPathAndFileName);
	QFileDevice::Permissions permissions = fileinfo.permissions();
	try {
		// Get current status
		if (!file.open(WriteOnly)) {
			// Clear read only status
			permissions |= QFileDevice::WriteUser;
			file.setPermissions(permissions);
			writeableSuccess = TRUE;
		}
	} catch (...) {
#ifndef V6_VER_qDebug_DISABLE
		// unhandled exception
		if (V6_RELEASE != RELEASE_PRODUCTION) {
			CStorage kFile;
			kFile.ShowError("MakeFileWriteable", pPathAndFileName);
		}
#endif
	}
#ifndef DBL_STORAGE_NO_CS_LOCK
	csFiles.lock();
#ifdef DBL_STORAGE_CS_THREAD
    glb_MsgCntMsg = 0; //MFree - ThId to qDebug the csFiles Free
    glb_MsgCntPan = GetThreadId(GetCurrentThread());//MFree - ThId to qDebug the csFiles requestor(latest)
#endif
#endif
	return writeableSuccess;
}
//****************************************************************************
/// Delete the specified file, will make sure it is writable first
///
/// @param[in] pPathAndFileName, path and filename of the file to delete
///
/// @return TRUE if delete successful, otherwise FALSE
//****************************************************************************
BOOL CStorage::DeleteFile(TCHAR *pPathAndFileName) {
#ifndef DBL_STORAGE_NO_CS_LOCK
#ifdef DBL_STORAGE_CS_THREAD	
    csFiles.lock();
    glb_MsgCntMsg = GetThreadId(GetCurrentThread()); //MFree - ThId to qDebug the csFiles holder
#else
	csFiles.lock();
#endif
#endif
	BOOL deleteSuccess = FALSE;
	// Make file writable before trying to delete
	if (CStorage::MakeFileWritable(pPathAndFileName) == TRUE) {
		try {
			// Attempt to delete the file
			/*QString strErrMsg;
			 strErrMsg.sprintf(L"\r\nAttempt to delete the file at GTC:%u\r\n", GetTickCount());
			 TCHAR tempStr[512];
			 sprintf(tempStr,"\r\nPSR: CS::DeleteFile %s\r\n"), strErrMsg);
			 qDebug(tempStr);*/
			deleteSuccess = TRUE;
			QFile::remove(pPathAndFileName);
			/*sprintf(tempStr,"\r\nPSR: CS::DeleteFile deleted at GTC:%u\r\n"), GetTickCount());
			 qDebug(tempStr);*/
		} catch (std::exception &pEx) {
			// File could not be deleted, probably open as we have already set as writable
			CStorage kFile;
			kFile.ShowError("DeleteFile", pPathAndFileName, pEx);
			//delete pEx;
			//deleteSuccess = FALSE;
		} catch (...) {
#ifndef V6_VER_qDebug_DISABLE
			if (V6_RELEASE != RELEASE_PRODUCTION) {
				CStorage kFile;
				kFile.ShowError("DeleteFile", pPathAndFileName);
			}
#endif
		}
	}
#ifndef DBL_STORAGE_NO_CS_LOCK
	csFiles.lock();
#ifdef DBL_STORAGE_CS_THREAD
    glb_MsgCntMsg = 0; //MFree - ThId to qDebug the csFiles Free
    glb_MsgCntPan = GetThreadId(GetCurrentThread());//MFree - ThId to qDebug the csFiles requestor(latest)
#endif
#endif
	return deleteSuccess;
}
#ifndef V6_CRC_DISABLE
//****************************************************************************
/// Storage object calculate CRC
///
/// @param[in] hasCRC TRUE if the file already contains a CRC, else FALSE
///
/// @return DWORD file CRC
///
/// @note 
//****************************************************************************
WORD CStorage::GetCRC(BOOL hasCRC) {
#ifndef V6_VER_qDebug_DISABLE
	WORD dwWorkingCRC = CRC_CCITT_INITIAL_VALUE;
	void *buffer = malloc( CRC_BUFFER);						///< Working buffer
	try {
		seek(0);
		// check if the file size is valid
		DWORD dwFileSize = (DWORD) m_hFile->size();
		if (dwFileSize > 0 || (hasCRC && (dwFileSize > 2))) {
			// if the size includes a CRC, don't include it
			if (hasCRC) {
				dwFileSize -= sizeof(WORD);
			}
			// calculate the number of file pages and the remainder size
			DWORD dwPages = dwFileSize / CRC_BUFFER;
			DWORD dwRemainder = dwFileSize % CRC_BUFFER;
			while (dwPages > 0) {
				UINT bytesRead = 0;
				// calculate page CRC
				bytesRead = Read(buffer, CRC_BUFFER);
				dwWorkingCRC = CrcRecalc((unsigned char*) buffer, bytesRead, dwWorkingCRC);
				dwPages--;
			}
			// calculate remainder CRC
			if (dwRemainder > 0) {
				UINT bytesRead = 0;
				bytesRead = Read(buffer, dwRemainder);
				dwWorkingCRC = CrcRecalc((unsigned char*) buffer, bytesRead, dwWorkingCRC);
			}
		}
	} catch (...) {
		// unhandled exception
		ShowError("GetCRC", m_strFileName);
	}
	free(buffer);
	return dwWorkingCRC;
#else
    return 0;
#endif
}
#endif
//****************************************************************************
//	void ShowError( const TCHAR* rstrFUNC_NAME,
//					const QString &rstrFILENAME, 
//					std::exception &kEx )
///
/// Method that shows file exception errors
///
/// @param[in]		const TCHAR* rstrFUNC_NAME - The function name that generated the exception
/// @param[in]		const QString &rstrFILENAME - The filename the error weas generated within
/// @param[in]		std::exception &kEx - The file exception generated
///
//****************************************************************************
void CStorage::ShowError(const TCHAR *rstrFUNC_NAME, const QString &rstrFILENAME, const QString &errormessage) {
#ifndef V6_VER_qDebug_DISABLE
	if (V6_RELEASE != RELEASE_PRODUCTION) {
		QString strError = QString("%1, %2 - %3").arg(rstrFILENAME, rstrFUNC_NAME, errormessage);
		QString strErrMsg = QString("\nError at GTC: %1\n").arg(QTime::currentTime().toString());
		QString tempStr = QString("\nPSR: CS::SE %1\n").arg(strErrMsg);
		qDebug() << tempStr;
#ifdef _NOPROMPTMESSAGE
        MessageBox( NULL, strError, L"CStorage Error", MB_OK | MB_TOPMOST);
#endif
	}
#endif
}
void CStorage::ShowError(const TCHAR *rstrFUNC_NAME, const QString &rstrFILENAME, const std::exception &errormessage) {
#ifndef V6_VER_qDebug_DISABLE
	if (V6_RELEASE != RELEASE_PRODUCTION) {
		QString strError = QString("%1, %2 - %3").arg(rstrFILENAME, rstrFUNC_NAME, errormessage.what());
		QString strErrMsg = QString("\nError at GTC: %1\n").arg(QTime::currentTime().toString());
		QString tempStr = QString("\nPSR: CS::SE %1\n").arg(strErrMsg);
		qDebug() << tempStr;
#ifdef _NOPROMPTMESSAGE
        MessageBox( NULL, strError, L"CStorage Error", MB_OK | MB_TOPMOST);
#endif
	}
#endif
}
//****************************************************************************
//	void ShowError( const TCHAR* rstrFUNC_NAME, const QString &rstrFILENAME )
///
/// Method that shows non-file exception errors
///
/// @param[in]		const TCHAR* rstrFUNC_NAME - The function name that generated the exception
/// @param[in]		const QString &rstrFILENAME - The filename the error weas generated within
///
//****************************************************************************
void CStorage::ShowError(const QString &rstrFUNC_NAME, const QString &rstrFILENAME) {
#ifndef V6_VER_qDebug_DISABLE
	if (V6_RELEASE != RELEASE_PRODUCTION) {
		QString strError = QString("%1, %2 - %3").arg(rstrFILENAME, rstrFUNC_NAME);
		QString strErrMsg = QString("\nError at GTC: %1\n").arg(QTime::currentTime().toString());
		QString tempStr = QString("\nPSR: CS::SE %1\n").arg(strErrMsg);
		qDebug() << tempStr;
#ifdef _NOPROMPTMESSAGE
        MessageBox( NULL, strError, L"CStorage Error", MB_OK | MB_TOPMOST);
#endif
	}
#endif
}
void CStorage::EnterStorageCS() {
#ifndef DBL_STORAGE_NO_CS_LOCK
#ifdef DBL_STORAGE_CS_THREAD	
    csFiles.lock();
    glb_MsgCntMsg = GetThreadId(GetCurrentThread()); //MFree - ThId to qDebug the csFiles holder
#else
	csFiles.lock();
#endif
#else
    return;
#endif
}
void CStorage::LeaveStorageCS() {
#ifndef DBL_STORAGE_NO_CS_LOCK
	csFiles.lock();
#ifdef DBL_STORAGE_CS_THREAD
    glb_MsgCntMsg = 0; //MFree - ThId to qDebug the csFiles Free
    glb_MsgCntPan = GetThreadId(GetCurrentThread());//MFree - ThId to qDebug the csFiles requestor(latest)
#endif
#else
    return;
#endif
}
//****************************************************************************
//	const BOOL CopyFiles(	const QString &strORIGINAL_FILE_PATH, 
//							const QString &rstrNEW_FILE_PATH,
//							const BOOL bFAIL_IF_EXISTS,
//							const BOOL bPROMPT_OVERWRITE_IF_EXISTS )
///
/// Method that shows non-file exception errors
///
/// @param[in]		const TCHAR* rstrFUNC_NAME - The function name that generated the exception
/// @param[in]		const QString &rstrFILENAME - The filename the error weas generated within
/// @param[in]		const BOOL bFAIL_IF_EXISTS - Flag indicating if the copy should fail if the file
///					already exists
/// @param[in]		const BOOL bPROMPT_OVERWRITE_IF_EXISTS - Flag indicating if the user should be prompted
///					before overwriting any already existing file - flag above must be false for correct behaviour
///
/// @return			Flag set to TRUE if the file was successfully copied	
///
//****************************************************************************
const BOOL CStorage::CopyFiles(const QString &strORIGINAL_FILE_PATH, const QString &rstrNEW_FILE_PATH,
		const BOOL bFAIL_IF_EXISTS, const BOOL bPROMPT_OVERWRITE_IF_EXISTS) {
	BOOL bSuccess = FALSE;
	BOOL bContinue = FALSE;
	// if a prompt is required then check if the file exists and prompt as necessary
	if (bPROMPT_OVERWRITE_IF_EXISTS) {
		QFileInfo kFileStatus(rstrNEW_FILE_PATH);
		QFile file(rstrNEW_FILE_PATH);
		QFileDevice::Permissions permissions = kFileStatus.permissions();
		if (kFileStatus.exists()) {
			if (PromptOverwrite()) {
				// the user has confirmed it is okay to overwrite the file
				bContinue = TRUE;
				// make the file writeable
				if (!file.open(WriteOnly)) {
					// Clear read only status
					permissions |= QFileDevice::WriteUser;
					file.setPermissions(permissions);
				}
			}
		} else {
			// the file doesn't exist
			bContinue = TRUE;
		}
	} else if (!bPROMPT_OVERWRITE_IF_EXISTS) {
		bContinue = TRUE;
	}
	// check if it is okay to proceed
	if (bContinue) {
		// attempt to copy the file
		bSuccess = copy(strORIGINAL_FILE_PATH, rstrNEW_FILE_PATH);
	}
	return bSuccess;
}
//****************************************************************************
//	const bool PromptUser( )
///
/// Method that prompts the user with an OK to overwrite existing message
///
/// @return			True if the user selected the OK button
///
//****************************************************************************
const bool CStorage::PromptOverwrite() {
	QString strTitle("File Already Exists!!!");
	QString strMessage("The file already exists. Do you wish to overwrite it?");
	bool bOK = false;
	// prompt the user with a windows message box
#ifdef _NOPROMPTMESSAGE
    if( MessageBox( NULL, strMessage, strTitle, MB_OKCANCEL | MB_TOPMOST ) == IDOK )
    {
        bOK = true;
    }
#endif
	return bOK;
}
void CStorage::Lock() //Locking mechanism for the file operation
{
#ifndef DBL_STORAGE_NO_CS_LOCK
#ifdef DBL_STORAGE_CS_THREAD	
    csFiles.lock();
    glb_MsgCntMsg = GetThreadId(GetCurrentThread()); //MFree - ThId to qDebug the csFiles holder
#else
	csFiles.lock();
#endif
#else
    return;
#endif
}
void CStorage::Unlock() //Locking mechanism for the file operartion
{
#ifndef DBL_STORAGE_NO_CS_LOCK
	csFiles.lock();
#ifdef DBL_STORAGE_CS_THREAD
    glb_MsgCntMsg = 0; //MFree - ThId to qDebug the csFiles Free
    glb_MsgCntPan = GetThreadId(GetCurrentThread());//MFree - ThId to qDebug the csFiles requestor(latest)
#endif
#else
    return;
#endif
}
DWORD GetTickCount() {
};

CDiskStorage::CDiskStorage(QMutex pCS) {
//	m_pCS = pCS;
}
CDiskStorage::CDiskStorage(LPCTSTR lpszFileName, QIODevice::OpenMode nOpenFlags, QMutex pCS)  {
//    m_pCS = pCS;
}
void CDiskStorage::Lock() //Locking mechanism for the file operation
{
#ifndef DBL_STORAGE_NO_CS_LOCK
#ifdef DBL_STORAGE_CS_THREAD		
        m_pCS.lock();
        glb_MsgCntMsg = GetThreadId(GetCurrentThread()); //MFree - ThId to qDebug the csFiles holder
#else
		m_pCS.lock();
#endif
#else
    return;
#endif
}
void CDiskStorage::Unlock() //Locking mechanism for the file operartion
{
	//return;
#ifndef DBL_STORAGE_NO_CS_LOCK
		m_pCS.unlock();
#ifdef DBL_STORAGE_CS_THREAD
        glb_MsgCntMsg = 0; //MFree - ThId to qDebug the csFiles Free
        glb_MsgCntPan = GetThreadId(GetCurrentThread());//MFree - ThId to qDebug the csFiles requestor(latest)
#endif
#endif
}
bool CDebugFileLogger::m_bExcpetionLogEnable = true; //Make it disable by default
CDebugFileLogger::CDebugFileLogger(QString strFilePath, BOOL bNoRecycle) : m_strFilePath(strFilePath), m_bLogDbgMessage(
		FALSE), m_bLogFileExists(FALSE), m_ulnMaxFileSize(5 * 1024 * 1024), m_ulnFileSize(0), m_strFileCreattionTime(
		"NOT CREATED"), m_dwGTCAtFileCreation(0), m_bFirstMsgForThisInstance(TRUE), m_nFlushThreshold(0), m_bNoRecycle(
		bNoRecycle), m_bReachedRecycleState(FALSE)
{
}
CDebugFileLogger::CDebugFileLogger(QString strFilePath, BOOL bNoRecycle, ULONG ulnFileSize) : m_strFilePath(
		strFilePath), m_bLogDbgMessage(FALSE), m_bLogFileExists(FALSE), m_ulnMaxFileSize(ulnFileSize) //Max file size is decided by client
		, m_ulnFileSize(0), m_strFileCreattionTime("NOT CREATED"), m_dwGTCAtFileCreation(0), m_bFirstMsgForThisInstance(
		TRUE), m_nFlushThreshold(0), m_bNoRecycle(bNoRecycle) //Want to recycle the file or not on completing the size
		, m_bReachedRecycleState(FALSE) {
}
CDebugFileLogger::~CDebugFileLogger() {
	if (m_bLogFileExists && m_bLogDbgMessage) {
		m_fileDebugLog.flush();
		m_fileDebugLog.Close();
	}
}
#define LOCALE_USER_DEFAULT 0x000004
BOOL CDebugFileLogger::OpenDebugLogFile() {
	QString strLogFilename = m_strFilePath;
	std::exception kEx;
	QString strLogMessage;
	BOOL bLogMessage = m_bLogDbgMessage;
	try {
		if ( FALSE == m_bLogFileExists) {
			if (!m_fileDebugLog.Open(strLogFilename.toLocal8Bit().data(), QIODevice::Append | QIODevice::WriteOnly)) {
//                QString strError( "" );
//                TCHAR wcaError[ 50 ];
				QString strError = QString("Failed to Create LogFile:%1 - Error(%2), E(%3)").arg(strLogFilename).arg(
						kEx.what()).arg(GetLastError());
				m_bLogFileExists = FALSE;
				bLogMessage = FALSE;
			} else {
				m_bLogFileExists = TRUE;
				bLogMessage = TRUE;
				m_ulnFileSize = m_fileDebugLog.GetFileSize(strLogFilename.toLocal8Bit().data());
				m_fileDebugLog.seek(m_fileDebugLog.size());
				QString strLocalTime;
				SYSTEMTIME st;
				GetLocalTime(&st);
				const int DT_BUFF_LEN = 22;
				TCHAR timeBuff[DT_BUFF_LEN];
				memset(timeBuff, 0, sizeof(TCHAR) * DT_BUFF_LEN);
				GetTimeFormat(LOCALE_USER_DEFAULT, 0, &st, "HH':'mm':'ss", timeBuff, DT_BUFF_LEN);
				strLocalTime = timeBuff;
				strLocalTime += " - ";
				GetTimeFormat(LOCALE_USER_DEFAULT, 0, &st, "dd MMM yy", timeBuff, DT_BUFF_LEN);
				strLocalTime += timeBuff;
				//Maintain File Creation time and its coressponding tick
				m_strFileCreattionTime = strLocalTime;
				m_dwGTCAtFileCreation = GetTickCount();
				m_bFirstMsgForThisInstance = FALSE;
				strLogMessage.sprintf("\r\n\r\nLogFile:%s FSize(%u) - Created/Opened at(%s) - GTC:%u\r\n\r\n",
						strLogFilename.toLocal8Bit().data(), m_ulnFileSize, m_strFileCreattionTime.toLocal8Bit().data(),
						m_dwGTCAtFileCreation);
				CyclicWrite(strLogMessage.toLocal8Bit().data());
			}
		} else {
			if ( FALSE == m_bLogDbgMessage) {
				if (!m_fileDebugLog.Open(strLogFilename.toLocal8Bit().data(), CStorage::WriteOnly)) {
					QString strError("");
					TCHAR wcaError[50];
					//kEx.GetErrorMessage(wcaError, 50);
					strError.sprintf("Failed to Open LogFile:%s - %s Error:(%ld)", strLogFilename.toLocal8Bit().data(),
							kEx.what(), GetLastError());
					bLogMessage = FALSE;
				} else {
					bLogMessage = TRUE;
					QString strLocalTime;
					SYSTEMTIME st;
					GetLocalTime(&st);
					const int DT_BUFF_LEN = 22;
					TCHAR timeBuff[DT_BUFF_LEN];
					memset(timeBuff, 0, sizeof(TCHAR) * DT_BUFF_LEN);
					///TODO  Get date and time format from the system.
					GetTimeFormat(LOCALE_USER_DEFAULT, 0, &st, "HH':'mm':'ss", timeBuff, DT_BUFF_LEN);
					strLocalTime = timeBuff;
					strLocalTime += " - ";
					GetDateFormat(LOCALE_USER_DEFAULT, 0, &st, "dd MMM yy", timeBuff, DT_BUFF_LEN);
					strLocalTime += timeBuff;
                    strLogMessage.sprintf("\r\n\r\nLogFile:%s Opened at(%s) - GTC:%u\r\n\r\n",
                                          strLogFilename.toLocal8Bit().data(), strLocalTime.toLocal8Bit().data(), GetTickCount());
					CyclicWrite(strLogMessage.toLocal8Bit().data());
				}
			} else {
				bLogMessage = m_bLogDbgMessage; ///If its already opened successfully
			}
		}
	} catch (std::exception pEx) {
        LogException("OPDLF", pEx);
		//delete pEx;
	} catch (...) {
		LogException("OPDLF");
	}
	m_bLogDbgMessage = bLogMessage; //Set the state //If member is available
	return bLogMessage;
}
///TODO Implement these functions
void CDebugFileLogger::GetDateFormat(WORD type, int size, SYSTEMTIME *st, TCHAR *format, TCHAR *buf, int bufLen) {
}
void CDebugFileLogger::GetTimeFormat(WORD type, int size, SYSTEMTIME *st, TCHAR *format, TCHAR *buf, int bufLen) {
}
void CDebugFileLogger::GetLocalTime(SYSTEMTIME *st) {
}
BOOL CStorage::CreateDirectory(QString pathName, LPSECURITY_ATTRIBUTES lpSecurityAttributes) {
	QDir().mkdir(pathName);
}
BOOL CDebugFileLogger::CyclicWrite(QString strLogMessage) {
	BOOL bRet = TRUE;
	try {
		ULONG ulnMessageSize = strLogMessage.length() * sizeof(TCHAR);
		//Check if it needs recycle
		if (((m_ulnFileSize + ulnMessageSize) >= m_ulnMaxFileSize) && ( FALSE == m_bReachedRecycleState)) {
			QString strLocalTime;
			SYSTEMTIME st;
			GetLocalTime(&st);
			const int DT_BUFF_LEN = 22;
			TCHAR timeBuff[DT_BUFF_LEN];
			memset(timeBuff, 0, sizeof(TCHAR) * DT_BUFF_LEN);
			/// locale -k LC_TIME | grep -w ^t_fmt | cut -d= -f2
			TCHAR time_format[] = "HH':'mm':'ss";
			/// locale -k LC_TIME | grep ^d_fmt | cut -d= -f2 -> Local date format
			TCHAR date_format[] = "dd MMM yy";
			GetTimeFormat(LOCALE_USER_DEFAULT, 0, &st, time_format, timeBuff, DT_BUFF_LEN);
			strLocalTime = timeBuff;
			strLocalTime += " - ";
			GetDateFormat(LOCALE_USER_DEFAULT, 0, &st, date_format, timeBuff, DT_BUFF_LEN);
			strLocalTime += timeBuff;
			QString strRecreateMsg;
			if (m_bNoRecycle == FALSE) {
				strRecreateMsg.sprintf(
						"\r\n\r\nLogFile:%s Recycled at(%s, GTC:%u) - Was created at (%s, GTC:%u) \r\n\r\n",
						m_strFilePath.toLocal8Bit().data(), strLocalTime.toLocal8Bit().data(), GetTickCount(),
						m_strFileCreattionTime.toLocal8Bit().data(), m_dwGTCAtFileCreation);
				m_ulnFileSize = strRecreateMsg.length() * sizeof(TCHAR);
				m_fileDebugLog.seek(0);
				m_fileDebugLog.Write(strRecreateMsg.toLocal8Bit().data(), m_ulnFileSize);
				m_bReachedRecycleState = FALSE; //Recyle the state aswell
				m_nFlushThreshold++;
			} else {
				m_bReachedRecycleState = TRUE; //This indicates no further logging on this file
				strRecreateMsg.sprintf(
						"\r\n\r\nLogFile:%s StoppedRecycle at(%s, GTC:%u) - Was created at (%s, GTC:%u) \r\n\r\n",
						m_strFilePath.toLocal8Bit().data(), strLocalTime.toLocal8Bit().data(), GetTickCount(),
						m_strFileCreattionTime.toLocal8Bit().data(), m_dwGTCAtFileCreation);
				m_ulnFileSize = strRecreateMsg.length() * sizeof(TCHAR);
				m_fileDebugLog.Write(strRecreateMsg.toLocal8Bit().data(), m_ulnFileSize);
				m_fileDebugLog.flush();
			}
			qDebug() << strRecreateMsg;
		}
		if ( TRUE == m_bFirstMsgForThisInstance) {
			QString strLocalTime;
			SYSTEMTIME st;
			GetLocalTime(&st);
			const int DT_BUFF_LEN = 22;
			TCHAR timeBuff[DT_BUFF_LEN];
			memset(timeBuff, 0, sizeof(TCHAR) * DT_BUFF_LEN);
			GetTimeFormat(LOCALE_USER_DEFAULT, 0, &st, "HH':'mm':'ss", timeBuff, DT_BUFF_LEN);
			strLocalTime = timeBuff;
			strLocalTime += " - ";
			GetDateFormat(LOCALE_USER_DEFAULT, 0, &st, "dd MMM yy", timeBuff, DT_BUFF_LEN);
			strLocalTime += timeBuff;
			//Maintain File Creation time and its coressponding tick
			m_strFileCreattionTime = strLocalTime;
			m_dwGTCAtFileCreation = GetTickCount();
			m_bFirstMsgForThisInstance = FALSE;
			QString strFirstMsg = "";
			strFirstMsg.sprintf("\r\n\r\nLogFile:%s FirstMessage For this instance at(%s, GTC:%u) \r\n\r\n",
					m_strFilePath.toLocal8Bit().data(), m_strFileCreattionTime.toLocal8Bit().data(),
					m_dwGTCAtFileCreation);
			qDebug() << strFirstMsg;
			ULONG ulnFirstMessageSize = strFirstMsg.length() * sizeof(TCHAR);
			m_fileDebugLog.Write(strFirstMsg.toLocal8Bit().data(), ulnFirstMessageSize);
			m_ulnFileSize += ulnFirstMessageSize;
			m_nFlushThreshold++;
		}
		if ( FALSE == m_bReachedRecycleState) {
			//Write the original Message
			m_fileDebugLog.Write(strLogMessage.toLocal8Bit().data(), ulnMessageSize);
			m_ulnFileSize += ulnMessageSize;
			m_nFlushThreshold++;
			qDebug() << strLogMessage;
			//Forcefully flush the file IO periodically
			if (m_nFlushThreshold >= 30) {
				m_nFlushThreshold = 0;
				m_fileDebugLog.flush();
			}
		}
	} catch (std::exception *pEx) {
		LogException("CYWR", *pEx);
		delete pEx;
	} catch (...) {
		LogException("CYWR");
	}
	return bRet;
}
BOOL CDebugFileLogger::WriteToDebugLogFile(QString strLogMessage) {
	BOOL bRet = TRUE;
	try {
		if (OpenDebugLogFile()) {
			CyclicWrite(strLogMessage.toLocal8Bit().data());
		}
	} catch (std::exception &pEx) {
		LogException("WTDLF", pEx);
	} catch (...) {
		LogException("WTDLF");
	}
	return bRet;
}
void CDebugFileLogger::flush(bool bClose) {
	try {
		if (m_bLogFileExists && m_bLogDbgMessage) {
			m_fileDebugLog.flush();
			if (bClose)
				m_fileDebugLog.Close();
		}
	} catch (std::exception *pEx) {
		LogException("FLSH", *pEx);
		delete pEx;
	} catch (...) {
		LogException("FLSH");
	}
}
void CDebugFileLogger::LogException(const TCHAR *rstrFUNC_NAME, std::exception &kEx) {
	if (true == m_bExcpetionLogEnable) {
		const char *wcaError;
		wcaError = kEx.what();
		QString strError("");
		strError.sprintf("DblExc , %s - %s", rstrFUNC_NAME, wcaError);
	}
}
void CDebugFileLogger::LogException(const TCHAR *rstrFUNC_NAME) {
	if (true == m_bExcpetionLogEnable) {
		QString strError = "";
		strError.sprintf("DblExc unkn - %s", rstrFUNC_NAME);
	}
}
CStorageNC::CStorageNC() {
}
//****************************************************************************
/// Storage object constructor
///
/// @return No return value from the object constructor
///
//****************************************************************************
CStorageNC::CStorageNC(LPCTSTR lpszFileName, UINT nOpenFlags) {
}
//****************************************************************************
/// Storage object destructor
///
/// @return No return value from the object destructor
///
//****************************************************************************
CStorageNC::~CStorageNC() {
}
//****************************************************************************
/// Lock()
///
//****************************************************************************
void CStorageNC::Lock() //Locking mechanism for the file operation
{
	//Nothing to lock ...that's the override here
	return;
}
//****************************************************************************
/// Unlock()
///
//****************************************************************************
void CStorageNC::Unlock() //Locking mechanism for the file operartion
{
	//Nothing to Unlock as well ...that's the override here
	return;
}

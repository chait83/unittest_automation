/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  Media Manager
/// @n Filename:  Media.h
/// @n Description: Provides an abstraction layer for storage media devices
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  4 Stability Project 1.1.1.1 7/2/2011 4:58:42 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  3 Stability Project 1.1.1.0 7/1/2011 4:27:02 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  2 V6 Firmware 1.1 4/25/2005 2:50:49 PM  Martin Miller 
//  Moved StoragePaths to the DAL ands added accessor methods.
//  StoragePaths is no longer directly accessable.
//  1 V6 Firmware 1.0 9/17/2004 12:53:06 PM  Martin Miller  
// $
//
// **************************************************************************
// Media.h: interface for the CMedia class.
//
//////////////////////////////////////////////////////////////////////
#if !defined(__MEDIA_H__)
#define __MEDIA_H__
#include "StoragePaths.h"
//**Class*********************************************************************
///
/// @brief Provides the access point for the media manager
/// 
/// Encapsulates and provides access to a storage device
///
//****************************************************************************
class CMedia {
public:
//	class CStoragePaths *pPath;
	CMedia(T_STORAGE_DEVICE volumeID);
	virtual ~CMedia();
	BOOL GetMediaFreeSpace();
	BOOL CheckMedia();
	BOOL m_Available;							///< TRUE when media is inserted, else FALSE
	DWORD m_LastError;							///< Last error while accessing media
	WCHAR m_VolumeName[MAX_PATH];				///< Storage media root volume name
private:
	CDeviceAbstraction *m_pDAL;
	T_STORAGE_DEVICE m_VolumeID;				///< Storage media device volume ID (0 based)
	ULARGE_INTEGER m_BytesAvailable;			///< Total bytes available for use
	ULARGE_INTEGER m_TotalBytes;				///< Total media storage 
	ULARGE_INTEGER m_TotalFreeBytes;			///< Total of free storage
	HANDLE m_Handle;							///< Root volume handle
};
#endif // !defined(__MEDIA_H__)

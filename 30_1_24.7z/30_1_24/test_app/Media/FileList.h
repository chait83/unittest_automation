/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Media Manager
/// @n Filename:	FileList.h
/// @n Description: Wrapper class for file searching API calls CStorage::FindFirstFile/CStorage::FindNextFile/indexOfClose
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log:
// 3	Stability Project 1.0.1.1	7/2/2011 4:57:16 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 2	Stability Project 1.0.1.0	7/1/2011 4:27:02 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 1	V6 Firmware 1.0		9/17/2004 12:53:06 PM Martin Miller 
// $
//
// **************************************************************************
// FileList.h: interface for the CFileList class.
//
//////////////////////////////////////////////////////////////////////
#if !defined(__FILELIST_H__)
#define __FILELIST_H__
#include "StoragePaths.h"
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
//*******************************************
// Storage file identity structure
///
/// @brief Contains the identity and storage location of a file
//*******************************************
typedef struct T_STORAGE_FILE {
	T_STORAGE_DEVICE DeviceID;				///< Storage device ID (0 based)
	T_STORAGE_PATH Location;				///< Storage location (see paths.h)
	QString FileName;
	///< File name
} STORAGE_FILE;
//**Class*********************************************************************
///
/// @brief File List class
/// 
/// Provides a wrapper for the file search (indexOfFirst/indexOfNext) API calls
///
//****************************************************************************
class CFileList {
public:
	WIN32_FIND_DATA* Next();
	CFileList(T_STORAGE_FILE *pfileMask);
	virtual ~CFileList();
private:
	BOOL m_First;								///< Fist time use flag
	HANDLE m_indexOfHandle;						///< Search handle
	WCHAR m_FileName[MAX_PATH];					///< File mask and path
	WIN32_FIND_DATA m_indexOfData;					///< indexOf data
};
#endif // !defined(__FILELIST_H__)

/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n AIConfig.h
/// @n interface for the CAIConfig class.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 40	Stability Project 1.37.1.1	7/2/2011 4:56:46 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 39	Stability Project 1.37.1.0	7/1/2011 4:27:11 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 38	V6 Firmware 1.37		11/24/2006 3:08:42 PM Graham Waterfield
//		Reset the digital value in the DIT when an input is deselceted
// 37	V6 Firmware 1.36		10/25/2006 3:03:20 PM Graham Waterfield
//		Prevented initial forced read of digital I/O card (digital inputs)
//		and initial check-in for pulse measurements
// $
//
//////////////////////////////////////////////////////////////////////
#if !defined(AFX_DIGCONFIG_H__7183B928_7F0B_4A3E_B59F_D66BE1885837__INCLUDED_)
#define AFX_DIGCONFIG_H__7183B928_7F0B_4A3E_B59F_D66BE1885837__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "IOCardStats.h"
#include "BrdStats.h"
#include "IOCardInfo.h"
#include "BrdInfo.h"
#include "V6defines.h"
#include "CMMDefines.h"
#include "V6Config.h"
#include "IOSetupConfig.h"
#include "PenSetupConfig.h"
#include "Config.h"
#include "V6Config.h"
#include "MessageListServicesItem.h"
typedef struct _digcfgchannelconfig {
	T_COMMONCFGCHANNEL ChanCfgInfo;		///< Universal channel configuration
	USHORT PulseDuration;		///< Channel pulse duration for pulsed output
	BOOL DigIn;				///< Channel is configured as a digital input
	BOOL DigOut;				///< Channel is configured as a digital output
	BOOL PulseIn;			///< Channel is configured as a pulse input
	WCHAR Label[DIGCHANNEL_LABEL_LEN];			///< Digital channel name label
	WCHAR Active[DIGCHANNEL_ACTIVE_LEN];	///< Digital channel active label
	WCHAR InActive[DIGCHANNEL_INACTIVE_LEN];	///< Digital channel inactive label
	// Digital output options
	BOOL FailSafe;			///< Channel output is in failsafe mode
	BOOL OutputLatched;		///< Digital stays latched until acknowledged
	UCHAR PulseDirection;		///< Digital pulse direction
	UCHAR PersistEvent;		///< How to log the digital activation state
} T_DIGCFGCHANNEL, *T_PDIGCFGCHANNEL;
typedef struct _digwrkconfig {
	USHORT IODigitalEnabledMask;		///< Which channels are enabled, as either a pulse, digital in or digital out
	USHORT OutputPulseMask;	///< Which channels are selected for pulse output
	USHORT InputSelectionMask;	///< Selects which channels are selected as an input
	USHORT DigInputSelectionMask;	///< Selects which digital inputs are an input
	USHORT OutputFailSafe;		///< Selects output as a fail safe output type
	USHORT PulseSelectionMask;		///< Selects which pulse inputs are selected
	USHORT chartReportMask;	///< Selects which inputs will be reported to the chart and 'digital' message list
	USHORT msgReportMask;	///< Selects which inputs will only be reported to the 'digital' message list
} T_DIGWRKCFG, *T_PDIGWRKCFG;
// Overall board configuration holder
typedef struct _digcfgboardconfig {
	T_DIGCFGCHANNEL CfgChan[BOTTOMSLOT_DIGCHAN_SIZE];	///< Downloadable setup for all board channels
	USHORT ConfigCRC;		/// Board configuration CRC
} T_DIGCFGBOARDCONFIG, *T_PDIGCFGBOARDCONFIG;
typedef struct _digchancfgupload {
	USHORT PulseDuration;		///< Digital channel output pulse duration time in 10ths of a second
} T_DIGCHANCFGUPLOAD, *T_PDIGCHANCFGUPLOAD;
typedef struct _pulsechancfgupload {
	USHORT PulseAcqFreq;		///< Pulse channel acqusition frequency
} T_PULSECHANCFGUPLOAD, *T_PPULSECHANCFGUPLOAD;
// Overall board configuration holder
typedef struct _digboardconfig {
	T_DIGWRKCFG CfgBoard;		///< Working downloadable board configuration
	T_DIGCFGBOARDCONFIG Cfg;	///< Downloadable setup for all board channels
} T_DIGBOARDCONFIG, *T_PDIGBOARDCONFIG;
class CDigConfig: public CConfig {
	// Allow the Card manager class only to create new instances of the AI configuration
	friend class CIOConfigManager;
public:		//Singleton 
	virtual BOOL CMMCreateLocalConfig(void);
	BOOL UploadConfig(void);
//	BOOL ConvertLocalConfig( void );
	void ClearLocalConfig(void);
	BOOL PulseSlotLoad(const UCHAR chanNo, T_PPULSECHANNEL pPulseCMMConfig);
	USHORT IOEnumConvert(const USHORT acqRate) const;
	BOOL GetChannelConfigRef(const UCHAR ChanNo, T_DIGCFGCHANNEL **pChanCfgInfo);
	BOOL SetupConfigChangePreparation(void);
	BOOL QueryChannelEnabled(const UCHAR chanNo) const;
	BOOL IsChanEnabledDigIn(const UCHAR chanNo) const;
	BOOL IsChanEnabledDigOut(const UCHAR chanNo) const;
	BOOL IsChanEnabledPulseIn(const UCHAR chanNo) const;
	void QueryReportSelectionMask( USHORT &chartReportMask,
	USHORT &msgReportMask) const;
	USHORT GetBoardCfgDigitalInputSelectionMask(void) const;
	USHORT GetBoardCfgInputSelectionMask(void) const;
	USHORT GetBoardCfgIODigitalEnabledMask(void) const;
	USHORT GetBoardCfgOutputFailSafe(void) const;
	UCHAR GetBoardCfgPulseInSelectionMask(void) const;
	USHORT GetBoardCfgOutputPulseMask(void) const;
	USHORT GetBoardCfgOutputPulseDuration( USHORT chanNo) const;
	USHORT GetChannelAcqRate(const UCHAR chanNo) const;
	UCHAR GetBoardCfgPulseAcqRate(const USHORT chanNo) const;
	USHORT CalculateCMMChannelReadRate(const UCHAR CMMSetting) const;
	BOOL QueryIsChanOPFailSafe(const UCHAR chanNo) const;
	BOOL CMMSlotLoad(void);
	BOOL CMMTopSlotPulseLoad(const UCHAR chanNo);
	BOOL CMMBottomSlotPulseLoad(const UCHAR chanNo);
	BOOL IOCardLocalConfigCommit(void);
	BOOL DigCalStructTransfer(class CATECal *const pCalStruct);
	BOOL PulseCalStructTransfer(class CATECal *const pCalStruct);
	void LogDigitalState( USHORT sysDigitalNo, BOOL Activate);
	BOOL InitialiseCardConfigHolder(class CIOCard *const pIOCard);
	void CleanUp();
private:
	CDigConfig();
	CDigConfig(const CDigConfig&);
	CDigConfig& operator=(const CDigConfig&) {
		return *this;
	}
	;
	~CDigConfig();
	T_DIGBOARDCONFIG m_Config;			///< Digital/Pulse board configuration
	// Singleton handlers
	static CDigConfig *m_pInstance;
	static HANDLE m_CreationMutex;
};
#endif // !defined(AFX_DIGCONFIG_H__7183B928_7F0B_4A3E_B59F_D66BE1885837__INCLUDED_)

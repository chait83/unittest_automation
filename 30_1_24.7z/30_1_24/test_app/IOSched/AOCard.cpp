/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n AOCard.cpp
/// @n implement the AO Card state machine.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 59 Stability Project 1.54.1.3	7/2/2011 4:55:26 PM	Hemant(HAIL) 
//				Stability Project: Recorder source has been upgraded from IL
//			version of firmware to JF version of firmware.
// 58 Stability Project 1.54.1.2	7/1/2011 4:37:57 PM	Hemant(HAIL) 
//				Stability Project: Files has been checked in before the merging
//			task. The merging will be done between IL version of firmware and JF
//			version of firmware. 
// 57 Stability Project 1.54.1.1	3/17/2011 3:20:09 PM Hemant(HAIL) 
//				Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//			new operator in DEBUG mode only. To detect memory leaks in files, use
//			it in preprocessor definition when in debug mode.
// 56 Stability Project 1.54.1.0	2/15/2011 3:02:11 PM Hemant(HAIL) 
//				File updated during Heap Management. Call to the default behaviour
//			of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////
#include "CMMDefines.h"
#include "V6Config.h"
#include "Timer.h"
#include "ConfigManager.h"
#include "AOConfig.h"
#include "TransMngr.h"
#include "BaseProtocol.h"
#include "Protocol.h"
#include "CardSlot.h"
#include "IOCard.h"
#include "AOCard.h"
#include "ATECal.h"
#include "V6IOProtocol.h"
#include "PPL.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#define new DEBUG_NEW
#endif
#endif
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CAOCard::CAOCard(USHORT CardSlotID) : CIOCard(CardSlotID) {
//	qDebug("Create new CAOCard\n");
	m_pConfigMngrObj = CIOConfigManager::GetHandle(); // Get reference to configuration manager
	m_OutputUpdateRqd = TRUE;
	m_StatusCheckRqd = FALSE;
//	ResetStateMachine();											// Reset state machine
//	m_pProtocol = NULL;											// No allocated protocol
}
CAOCard::~CAOCard() {
//	qDebug("Deleting CAOCard\n");
}
//******************************************************
///
/// Schedule a upload of factory Cal points for selected channels.
///
/// @return TRUE if successfully scheduled; otherwise FALSE
/// 
//******************************************************
BOOL CAOCard::ScheduleFactoryCalUpload(void) {
	m_BoardCmd.FactoryCalibration = TRUE;
	return m_BoardCmd.FactoryCalibration;
}
//**********************************************************************
/// CalculateChannelReadRate()
///
/// Calculates the channel read rate.
///
/// @param[in] ChanNo - Card slot channel number.
///
/// @return			The number of mS between reads on this channel
//**********************************************************************
USHORT CAOCard::CalculateChannelReadRate(UCHAR chanNo) {
	return 0;
}
//**********************************************************************
/// GetChannelAcqRate()
///
/// Gets the channel acqusition rate.
///
/// @param[in] ChanNo - Card slot channel number.
///
/// @return			The number of mS between acqusitions on this channel
//**********************************************************************
USHORT CAOCard::GetChannelAcqRate(const UCHAR chanNo) const {
	return 0;
}
//******************************************************
// ChannelsToService()
///
/// Query which channels to service.
///
/// @return The current channel(s) to service
/// 
//******************************************************
USHORT CAOCard::ChannelsToService(void) {
	return 0x0f;
}
//******************************************************
// DoesBoardRqSched()
///
/// Queries whether the I/O board requires periodic scheduling.
///
/// @return TRUE if the I/O card requires periodic scheduling 
/// 
//******************************************************
BOOL CAOCard::DoesBoardRqSched(void) {
	return TRUE;
}
//**********************************************************************
///
/// Get reference to channel local configuration as channel service data
///
/// @param[in] ChanNo - Card slot channel number.
/// @param[out] pChanCfgInfo - Channel configuration info
/// @param[out] pChanWrkInfo - Channel working info
///
/// @return			TRUE if the cahannel has configuration data available; otherwise FALSE
//**********************************************************************
BOOL CAOCard::GetChannelConfigRef(const UCHAR ChanNo, T_AOCFGCHANNEL **ppChanCfgInfo,
		T_AOWRKCHANNELCFG **ppChanWrkInfo) {
	return m_pAOConfigObj->GetChannelConfigRef(ChanNo, ppChanCfgInfo, ppChanWrkInfo);
}
//******************************************************
// IOCardCommand()
///
/// Sends a user command to the I/O boards.
/// @param[in] newCmd - I/O board command.
///
/// @return IOCARDSTAT (IOSTAT_CMDOK) if successful otherwise IOCARDSTAT fail code 
/// 
//******************************************************
IOCARDSTAT CAOCard::IOCardCommand(const USHORT newCmd) {
	class CProtocol *pProtocolHnd = NULL;
	IOCARDSTAT retValue = IOSTAT_CMDOK;
	// Remove unprocessed commands from queue
//	if( newCmd != IO_HISTORYUPLOAD )
//			ResetStateMachine();
// Load new command into the state machine sequencer
	switch (newCmd) {
	case IO_RESET:
		// Reset instructed
		break;
	case IO_CONFIGCHECK:
		// Configuration check instructed
		break;
	case IO_CONFIGDOWNLOAD:
		// Configuration download to board instructed
		break;
	case IO_CALIBRATION:
		// Unit calibration mode instructed
		break;
	case IO_CONFIGUPLOAD:
		// configuration upload to recorder instructed
		break;
	case IO_HISTORYUPLOAD:
		// History upload to recorder instructed
		break;
	case IO_ACQUIRE:
		// Normal acquisition mode commanded
		break;
	case IO_IDLE:
		// Module commanded to enter IDLE mode
		break;
	};
	// Execute new command; and update state machine
//	pProtocolHnd = m_pTransMngr->RequestTransToken( this );
//	if( pProtocolHnd != NULL )
//			OperateTransactionSM( pProtocolHnd );
	return retValue;
}
//******************************************************
// InitialiseCard()
///
/// Schedule correct desired update rate for card & channel	based on configuration.
/// @param[in] cardNo - Card slot number identification.
///
/// @return TRUE
/// 
//******************************************************
BOOL CAOCard::InitialiseCard(const USHORT cardNo) {
//	QString   IOCardDescription;
//	GetIOCardStrDescription( &IOCardDescription );
//	LogInternalError(IOCardDescription.toLocal8Bit().data());
	return TRUE;
}
//******************************************************
// InitialiseCardConfig()
///
/// Create the local configuration for the I/O card from the CMM.
///
/// @return TRUE if local configuration could be created, otherwise FALSE 
/// 
//******************************************************
BOOL CAOCard::InitialiseCardConfig(void) {
	BOOL retValue = FALSE;
	if ((m_pTransMngr != NULL) && (m_pConfigMngrObj != NULL)) {
		// Initialise local configuration
		m_pAOConfigObj = m_pConfigMngrObj->CreateAOLocalConfig(m_Instance);
		retValue = m_pAOConfigObj->InitialiseCardConfigHolder(this);
		m_NormOpPending.CommandModeToProc = IO_CONFIGCHECK;
		RunProcess();
		// Create instances of the channel holders
		if (retValue != FALSE) {
			retValue = InitialiseChannels();
		}
	}
	return retValue;
}
//**********************************************************************
/// Obtains the I/O board designator
///
/// @param[out] IDText - Slot designator ID text.
///
//**********************************************************************
void CAOCard::GetIOCardStrID(QString *pIDText) const {
#ifndef V6IOTEST
pIDText-> = tr("AO");
#endif
}
//**********************************************************************
/// Obtains the I/O board designator
///
/// @param[out] pIDText - Card description.
///
//**********************************************************************
void CAOCard::GetIOCardStrDescription(QString *pIDText) {
QString cardText;
class CSlotMap *pSlotMap = NULL;
class CBrdInfo *pBrdInfo = NULL;
WCHAR boardSlotStr[4];
pSlotMap = CSlotMap::GetHandle();
pBrdInfo = CBrdInfo::GetHandle();
if (pSlotMap != NULL)
	pSlotMap->GetSlotStrID(BoardSlotInstance(), boardSlotStr);
GetIOCardStrID(&cardText);
pIDText->asprintf(IDS_BOARD_IN_SLOT, cardText, pBrdInfo->GetNoOfChannels(BoardSlotInstance()), boardSlotStr);
}
//******************************************************
// CMMCreateLocalConfig()
///
/// Load the global configuration from the CMM and create the locally held one.
///
/// @return TRUE if successful created local configuration; otherwise FALSE
/// 
//******************************************************
BOOL CAOCard::CMMCreateLocalConfig(void) {
return m_pAOConfigObj->CMMCreateLocalConfig();
}
//******************************************************
// ScheduleBoardProcess()
///
/// Allow write output from state machine.
///
/// @return TRUE if successful scheduled; otherwise FALSE
/// 
//******************************************************
BOOL CAOCard::ScheduleBoardProcess(void) {
m_NormOpPending.Board.WriteAllow = TRUE;
return TRUE;
}
//******************************************************
// ScheduleNextChannelProcess()
///
/// Schedules the next ideal channel read times for channels just processed.
///
/// @return TRUE
/// 
//******************************************************
BOOL CAOCard::ScheduleNextChannelProcess(void) {
return TRUE;
}
//******************************************************
// ScheduleChannelStatusCheck()
///
/// Schedules channel status download.
///
/// @return TRUE if successfully scheduled
/// 
//******************************************************
BOOL CAOCard::ScheduleChannelStatusCheck(void) {
m_StatusCheckRqd = TRUE;
return m_StatusCheckRqd;
}
//******************************************************
///
/// Services the output channels on the recorder.
///
/// Note: Process is different for test equipment
/// @param[out] pCardData - System channel analogue word data.
/// @param[out] nextToService - Card channel number that is next to check.
/// @param[out] pChanNo - Card channel number.
///
/// @return TRUE on a O/P change being detected; otherwise FALSE
/// 
//******************************************************
BOOL CAOCard::ProcessOutputChannel(USHORT *pCardData, const UCHAR nextToService, UCHAR *pChanNo) {
return m_ChanList.ProcessOutputChannel(pCardData, nextToService, pChanNo);
}
//******************************************************
// RunProcess()
///
/// Virtual function implementation
/// Performs a time slice action for an instance of a card slot 
/// The CardSlot class must decide what action is required based
/// on the current action and action state.
///
/// @return TRUE on sucess; otherwise FALSE
/// 
//******************************************************
BOOL CAOCard::RunProcess(void) {
class CProtocol *pProtocolHnd = NULL;
BOOL retValue = FALSE;
//	if( m_ChanList.ProcessOutputChannels() == TRUE )
//	{
// Output has changed state/value therefore schedule board output
//	}
pProtocolHnd = m_pTransMngr->RequestTransToken(this);
if (pProtocolHnd != NULL) {
	// Perform mode change first
	retValue = PerformSMModeChange(pProtocolHnd);
	if ((retValue == TRUE) && (m_pBrdStatsObj->HasIdleModeBeenOrdered() == FALSE)) {
		// Perform operations within mode, only if mode change was valid
		retValue = OperateTransactionSM(pProtocolHnd);
	}
}
m_pTransMngr->TransactionTerminated();
// Schedule the next acquire
//	retValue = SetNextRunTime();
return retValue;
}
//******************************************************
// OperateTransactionSM()
///
/// Main digital/pulse transaction state machine.
/// @param[in] pProtocol - Pointer to the I/O board protocol handle.
///
/// @return TRUE if successful; otherwise FALSE
/// 
//******************************************************
BOOL CAOCard::OperateTransactionSM(class CProtocol *pProtocol) {
class CATECal *pCalStruct = NULL;
BOOL opState = TRUE;
BOOL nextOpTest = TRUE;
BOOL exitStateMachine = FALSE;
m_pProtocol = pProtocol;
pCalStruct = CATECal::GetHandle();
// If entered with an invalid protocol token then fail
if ((m_pProtocol == NULL) || (pCalStruct == NULL)) {
	return FALSE;
}
do {
	// If a command failed exit state machine after any errors have been downloaded (if possible)
	// to allow fault evaluation
	CIOCard::OperateTransactionSM();
	nextOpTest = m_NormOpPending.Board.ChanRead;
//			m_NormOpPending.Board.ChanRead = FALSE;
	if (nextOpTest == TRUE) {
		// If reading is enabled, also allow writing to output ports
		m_NormOpPending.Board.WriteAllow = TRUE;
	}
//			if( (m_NormOpPending.Board.WriteAllow == TRUE) && (IsRunningAsATEEquipment() == TRUE) &&
//					(pCalStruct->IsOutputUpdated() == TRUE) )
	if (IsRunningAsATEEquipment() == FALSE) {
		if (m_NormOpPending.Board.WriteAllow == TRUE) {
			sleep(INTER_COMMAND_DELAY);
			if (m_pProtocol->WriteAnalOut() == TRUE)
				m_CmdProcessed++;
		}
	} else {
		if ((m_NormOpPending.Board.WriteAllow == TRUE) && (pCalStruct->IsOutputUpdated() == TRUE)) {
			sleep(INTER_COMMAND_DELAY);
			if (m_pProtocol->WriteATEAnalOut() == TRUE)
				m_CmdProcessed++;
			pCalStruct->SetOutputUpdated(FALSE);
		}
	}
//			if( (m_NormOpPending.Board.WriteAllow == TRUE) && (IsRunningAsATEEquipment() == TRUE) &&
//					(pCalStruct->IsOutputUpdated() == TRUE) )
//			{
//					sleep(INTER_COMMAND_DELAY);
//					if( m_pProtocol->WriteATEAnalOut() == TRUE )
//							m_CmdProcessed++;
//
//					pCalStruct->SetOutputUpdated( FALSE );
//			}
	// Use standard exit method - no readings to acknowledge
	if (m_NormOpPending.Board.AckReadings != TRUE) {
		exitStateMachine = TRUE;
	}
	nextOpTest = FALSE;
} while (exitStateMachine == FALSE);	// Check timeslice exit strategy
return TRUE;
}
//**********************************************************************
/// Obtains the I/O board life history
///
/// @return - TRUE if the upload of I/O life history was succesful; otherwise FALSE.
///
//**********************************************************************
BOOL CAOCard::GetIOLifeHistory(class CProtocol *const pProtocol) {
BOOL retValue = FALSE;
retValue = pProtocol->GetAOLifeHistory();
return retValue;
}
//**********************************************************************
/// Saves the I/O board life history
///
/// @return - TRUE if the upload of I/O life history was succesful; otherwise FALSE.
///
//**********************************************************************
BOOL CAOCard::SaveIOLifeHistory(class CProtocol *const pProtocol) {
BOOL retValue = FALSE;
retValue = pProtocol->SaveAOLifeHistory();
return retValue;
}
//******************************************************
//
/// Change the current operating mode of the AI transaction state machine.
/// @param[in] pProtocol - Pointer to the I/O board protocol handle.
///
/// @return TRUE if successful; otherwise FALSE
/// 
//******************************************************
BOOL CAOCard::PerformSMModeChange(class CProtocol *const pProtocol) {
class CATECal *pATECal = CATECal::GetHandle();
BOOL opState = TRUE;
BOOL nextOpTest = FALSE;
m_pProtocol = pProtocol;
CIOCard::PerformSMModeChange();
// Schedule a channel status read
nextOpTest = m_StatusCheckRqd;	// Always check AO card schedule
#ifdef V6IOTEST
 // Check and reschedule if either the AO card schedule or ATE is schedule
 // requires for the ATE build only
 nextOpTest |= pATECal->IsChannelStatusCheckScheduled ();
#endif
if (nextOpTest == TRUE) {
	opState = m_pProtocol->QueryAOStatus();	///< Query the AO channel status
	if (TRUE == opState)
		m_StatusCheckRqd = FALSE;
}
// Schedule history upload if required
nextOpTest = m_BoardCmd.HistoryUpload;
m_BoardCmd.HistoryUpload = FALSE;
if (nextOpTest == TRUE) {
	SaveIOLifeHistory(m_pProtocol);
}
// Schedule Configuration upload if required
nextOpTest = m_BoardCmd.FactoryCalibration;
m_BoardCmd.FactoryCalibration = FALSE;
if (nextOpTest == TRUE) {
	sleep(INTER_COMMAND_DELAY);
	opState = m_pProtocol->SetAOFactoryCalPoints();	///< Download AI factory calibration points
	m_CmdProcessed++;
}
nextOpTest = m_BoardCmd.ConfigDownload;
m_BoardCmd.ConfigDownload = FALSE;
if (nextOpTest == TRUE) {
	sleep(INTER_COMMAND_DELAY);
	opState = m_pProtocol->DownloadAOConfig();	///< Download AI config to I/O board
	if ((opState == TRUE) && (IsRunningAsATEEquipment() == TRUE)) {
		sleep(INTER_COMMAND_DELAY);
		opState = m_pProtocol->SetAORawMode();	///< Update raw mode status
	}
	// Board has been reset so enable reading and later writing to board
	if (IsRunningAsATEEquipment() == TRUE) {
		// When running as test equipment we can start get readings as soon as we can
		m_CardQueryEnabled = TRUE;
		m_NormOpPending.Board.ChanRead = TRUE;
		m_NormOpPending.Board.ChanRead2 = TRUE;
	}
	m_NormOpPending.Board.WriteAllow = TRUE;
//			if( opState == TRUE )
//			{
	// Resync the queues
//					m_SyncOpPending = TRUE;
	// and the board data needs resetting
//					m_NormOpPending.Board.DataReset = TRUE;
//					opState = CIOCard::OperateTransactionSM();
//			}
	m_CmdProcessed++;
}
nextOpTest = m_BoardCmd.ConfigUpload;
m_BoardCmd.ConfigUpload = FALSE;
if (nextOpTest == TRUE) {
	sleep(INTER_COMMAND_DELAY);
	opState = m_pProtocol->UploadAOConfig();		// Upload AI config from I/O board
	m_CmdProcessed++;
}
return TRUE;
}
//******************************************************
// SetSpecialTestMode()
///
/// Sets the special test mode were boards hidden functionality are made visible.
/// @param[in] state - Whether special test mode is enabled or disabled.
///
/// @return TRUE if the I/O board has a special test mode; otherwise FALSE.
/// 
//******************************************************
BOOL CAOCard::SetSpecialTestMode(const BOOL state) {
return FALSE;
}
//******************************************************
// Initialise()
///
/// Implementation of the virtual function.
/// Initialise and create the relationship between the Protocol and Transaction objects.
///
/// @return TRUE
/// 
//******************************************************
BOOL CAOCard::Initialise(void) {
return TRUE;
}

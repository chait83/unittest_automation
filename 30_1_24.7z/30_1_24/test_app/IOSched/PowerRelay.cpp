/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n PowerRelay.cpp
/// @n implement the Power Relay state machine.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
//
#include "DAL.h"
#include "V6globals.h"
#include "Timer.h"
#include "CardSlot.h"
#include "PowerRelay.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CPowerRelay::CPowerRelay(USHORT CardSlotID) : CCardSlot(CardSlotID) {
//	qDebug("Create new CPowerRelay\n");
	m_OPUpdateRequired = TRUE;
}
CPowerRelay::~CPowerRelay() {
//	qDebug("Deleting CPowerRelay\n");
}
//**********************************************************************
/// CalculateChannelReadRate()
///
/// Calculates the channel read rate.
///
/// @param[in] ChanNo - Card slot channel number.
///
/// @return		The number of mS between reads on this channel
//**********************************************************************
USHORT CPowerRelay::CalculateChannelReadRate(UCHAR chanNo) {
	return 0;
}
//**********************************************************************
/// GetChannelAcqRate()
///
/// Gets the channel acqusition rate.
///
/// @param[in] ChanNo - Card slot channel number.
///
/// @return		The number of mS between acqusitions on this channel
//**********************************************************************
USHORT CPowerRelay::GetChannelAcqRate(const UCHAR chanNo) const {
	return 0;
}
//******************************************************
// DoesBoardRqSched()
///
/// Queries whether the I/O board requires periodic scheduling.
///
/// @return TRUE if the I/O card requires periodic scheduling 
/// 
//******************************************************
BOOL CPowerRelay::DoesBoardRqSched(void) {
	return FALSE;
}
//******************************************************
// SetupConfigChangePreparation()
///
/// Sets all power relay services on a setup commit change preperation
///
/// @return Card process handler
/// 
//******************************************************
BOOL CPowerRelay::SetupConfigChangePreparation(void) {
	m_OPUpdateRequired = TRUE;
	return TRUE;		// No handler to remove
}
//******************************************************
// InitialiseCardConfig()
///
/// Create the local configuration for the I/O card.
///
/// @return TRUE if local configuration could be created	otherwise FALSE 
/// 
//******************************************************
BOOL CPowerRelay::InitialiseCardConfig(void) {
	m_OPUpdateRequired = TRUE;
	return TRUE;
}
//******************************************************
// CMMCreateLocalConfig()
///
/// Load the global configuration from the CMM and create the locally held one.
///
/// @return TRUE if successful created local configuration; otherwise FALSE
/// 
//******************************************************
BOOL CPowerRelay::CMMCreateLocalConfig(void) {
	m_OPUpdateRequired = TRUE;
	return TRUE;
}
BOOL CPowerRelay::ScheduleBoardProcess(void) {
	return TRUE;
}
//******************************************************
// IsCMMConfigValid()
///
/// Check the CMM configuartion to a single I/O board.
///
/// @return TRUE if the I/O board CMM configuration uploaded is the same as the local config; otherwise FALSE.
/// 
//******************************************************
BOOL CPowerRelay::IsCMMConfigValid(void) {
	return TRUE;
}
#define POWER_RELAY_CHANNEL_MASK	0x1
//******************************************************
// ChannelsToService()
///
/// Query which channels to service.
///
/// @return The current channel(s) to service
/// 
//******************************************************
USHORT CPowerRelay::ChannelsToService(void) {
	return POWER_RELAY_CHANNEL_MASK;
}
//******************************************************
// IOCardCommand()
///
/// Sends a user command to the I/O boards.
/// @param[in] newCmd - I/O board command.
///
/// @return IOCARDSTAT (IOSTAT_CMDOK) if successful otherwise IOCARDSTAT fail code 
/// 
//******************************************************
IOCARDSTAT CPowerRelay::IOCardCommand(const USHORT newCmd) {
	IOCARDSTAT retValue = IOSTAT_CMDOK;
	// Any mode change will be internal in this class
	return retValue;
}
//******************************************************
// RunProcess()
///
/// Virtual function implementation
/// Performs a time slice action for an instance of a card slot	
/// The CardSlot class must decide what action is required based
/// on the current action and action state.
///
/// @return TRUE
/// 
//******************************************************
BOOL CPowerRelay::RunProcess(void) {
	class CDataItem *pDataItem = NULL;
	CNVBasicVar *pOPStateVar = NULL;
	COMBO_VAR4 OPStateVar;
	USHORT relayInverseState = 0;
	BOOL newState = FALSE;
	BOOL retValue = TRUE;
	pDataItem = pDIT->GetDataItemPtr(DI_IO, DI_IO_MISC, DI_IO_DIG_POWERRELAY);
	pOPStateVar = pNV_VARS->GetBasicVarNVObject(static_cast<NVVAR_IDENT>(NVV_RELAY_STATE_POWER));
	if (m_OPUpdateRequired == TRUE) {
		// If just powered up get the last state to Non volatile state saved
		OPStateVar = pOPStateVar->GetFromNV()->value;
		relayInverseState = ~OPStateVar.us[0];
		if (OPStateVar.us[1] == relayInverseState) {
			m_RTState = static_cast<BOOL>(OPStateVar.us[0]);
		} else {
			m_RTState = FALSE;
		}
		if (pDataItem != NULL) {
			pDataItem->SetValue(static_cast<float>(m_RTState));
		}
	} else {
		if (pDataItem != NULL) {
			newState = static_cast<BOOL>(pDataItem->GetFPValue());
		} else {
			retValue = FALSE;
		}
	}
	if ((m_OPUpdateRequired == TRUE) || (newState != m_RTState)) {
		// Update the power relay state
		if (m_OPUpdateRequired == FALSE)
			m_RTState = newState;
		pDALGLB->IOSetPowerRelay(m_RTState);
		// Update the last state to Non volatile
		OPStateVar.us[0] = static_cast<USHORT>(m_RTState);
		OPStateVar.us[1] = ~OPStateVar.us[0];
		pOPStateVar->SetToNV(OPStateVar);				// Store to NV
		// Increment the number of digital activations in Non volatile life stats for the power relay
		if (newState == TRUE) {
			pOPStateVar = pNV_VARS->GetBasicVarNVObject(static_cast<NVVAR_IDENT>(NVV_RELAY_OPS_POWER));
			OPStateVar = pOPStateVar->GetFromNV()->value;
			OPStateVar.ul++;
			pOPStateVar->SetToNV(OPStateVar);				// Store incremented count back to NV
		}
		// Increment the digital I/O counter for power relay
		if (newState == TRUE) {
			// Increment the accumulated counter value
			pDataItem = pDIT->GetDataItemPtr(DI_COUNTER, DI_COUNTTYPE_IO, DIGITAL_IO_INC_POWER_RELAY - 1);
			if (NULL != pDataItem) {
				pDataItem->SetValue(pDataItem->GetFPValue() + 1.0F);
				pDataItem->SetStatus(DISTAT_NORMAL);
			}
		}
	}
	m_OPUpdateRequired = FALSE;
	return retValue;
}
//******************************************************
// SetSpecialTestMode()
///
/// Sets the special test mode were boards hidden functionality are made visible.
/// @param[in] state - Whether special test mode is enabled or disabled.
///
/// @return TRUE if the I/O board has a special test mode; otherwise FALSE.
/// 
//******************************************************
BOOL CPowerRelay::SetSpecialTestMode(const BOOL state) {
	return FALSE;
}
//******************************************************
// InitialiseCard()
///
/// Schedule correct desired update rate for card & channel	based on configuration.
/// @param[in] cardNo - Card slot number identification.
///
/// @return TRUE
///
/// Note: assumes that data item table is set correctly later 
//******************************************************
BOOL CPowerRelay::InitialiseCard(const USHORT cardNo) {
	BOOL retValue = TRUE;
	// Set power relay output to default state (assumes that data item table is set correctly later)
	m_RTState = FALSE;
	pDALGLB->IOSetPowerRelay(m_RTState);
	return retValue;
}
//******************************************************
// ScheduleErrorDownload()
///
/// Schedule a block data download of all I/O card erros.
///
/// @return TRUE if successfully scheduled; otherwise FALSE
/// 
//******************************************************
BOOL CPowerRelay::ScheduleErrorDownload(void) {
	// No errors to download
	return FALSE;
}

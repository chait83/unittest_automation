/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 I/O Scheduler
/// @n Filename: IOMemManager.cpp
/// @n Desc:	implementation of the CIOMemManager class 
///
// 
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  13  Stability Project 1.8.1.3 7/2/2011 4:58:02 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  12  Stability Project 1.8.1.2 7/1/2011 4:38:22 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  11  Stability Project 1.8.1.1 3/17/2011 3:20:26 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  10  Stability Project 1.8.1.0 2/15/2011 3:03:11 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////
#include "IOMemManager.h"
#include "V6defines.h"
#include "V6globals.h"
QMutex CIOMemManager::m_CreationMutex;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CIOMemManager::CIOMemManager() {
//	qDebug("Create new CIOMemManager\n");
}
CIOMemManager::~CIOMemManager() {
//	qDebug("Deleting CIOMemManager class\n");
// Destroy the Allocated buffer
	if (m_pHeapIOBuffer) {
		delete[] m_pHeapIOBuffer;
		m_pHeapIOBuffer = NULL;
	}
}
CIOMemManager *CIOMemManager::m_pInstance = NULL;
QMutex m_CreationMutex;
//**********************************************************************
///
/// Instance creation of CIOMemManager singleton
///
/// @return		pointer to single instance of CIOMemManager
/// 
//**********************************************************************
CIOMemManager* CIOMemManager::GetHandle() {
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;
	if (NULL == m_pInstance) {
		// An instance has yet to be completed
		waitSingleObjectResult = m_CreationMutex.tryLock(g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);
		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:
			// Object was signaled
			if (NULL == m_pInstance)
				m_pInstance = new CIOMemManager;
			if ( FALSE == m_CreationMutex.unlock()) {
				V6WarningMessageBox(NULL, L"Failed to release IOMemManager mutex", L"CIOMemManager Error", MB_OK);
			}
			break;
		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
			V6WarningMessageBox(NULL, L"IOMemManager WaitForSingleObject Error", L"CIOMemManager Error", MB_OK);
			break;
		}
		// Close the Mutex as no longer required
		//No need to close the mutex in Qt
	}
	return (m_pInstance);
}
//**********************************************************************
/// Deletes the instance of the singleton from memory
///
/// @return		pointer to single instance of CIOMemManager
//**********************************************************************
void CIOMemManager::CleanUp() {
	if (NULL != m_pInstance) {
		delete m_pInstance;
		m_pInstance = NULL;
	}
}
//****************************************************************************
/// Creates and Allocates a Heap Buffer of a specified size
/// for IO scheduler object creation
///
/// @param[in] heapSize - Size of the heap to allocated
///
/// @return whether the heap memory was allocated or an error has occurred.
///
//****************************************************************************
T_HEAPIOBUFFER_RETURN_VALUE CIOMemManager::AllocateIOMemManager(USHORT heapSize) {
	T_HEAPIOBUFFER_RETURN_VALUE retValue = HEAPIOBUFFER_HEAP_ALLOCATED;
//  GlbDevCaps.DisplayTraceMemoryStatus( L"before alloc IO Mem" );
	m_pHeapIOBuffer = (BYTE*) new int[heapSize / 4]; // allocate as ints to get on 4 byte boundary
//	WCHAR buffy[200];
//	swprintf(buffy,L"after alloc IO Mem of size %d",heapSize);
//	GlbDevCaps.DisplayTraceMemoryStatus(buffy);
	m_pNextFreeAddress = m_pHeapIOBuffer;
	m_IOBufferSize = heapSize;
	m_FreeSpace = heapSize;
	// Ensure we have a valid pointer to the Heap Memory Allocated
	if (NULL == m_pHeapIOBuffer) {
		retValue = HEAPIOBUFFER_HEAP_ERROR;
	} else {
		// Initialise the Block of allocated Memory to known values
		memset(m_pHeapIOBuffer, (BYTE) 0xBD, m_IOBufferSize);
	}
	return (retValue);
}
//****************************************************************************
/// Allocates an IO object of a specified size to the IO Heap Buffer
///
/// @param[in] objectSize - Size of the object to allocated to heap
///
/// @return Object start address on success; NULL on failure.
///
//****************************************************************************
BYTE* CIOMemManager::AllocateIOObject(USHORT objectSize) {
	long spaceCheck;
	BYTE *pObject = m_pNextFreeAddress;
	spaceCheck = m_FreeSpace - objectSize;
	if (spaceCheck < 0)
		return NULL;			// No room left for object
	// Room exists for object; so allocate to storage
	m_pNextFreeAddress += objectSize;
	m_FreeSpace -= objectSize;
	return pObject;
}
//****************************************************************************
/// Releases an IO object of a specified size from the IO Heap Buffer
///
/// @param[in] pBuffer - Pointer to object
/// @param[in] objectSize - Size of the object to allocated to heap
///
//****************************************************************************
void CIOMemManager::ReleaseIOObjects(BYTE *pBuffer, USHORT objectSize) {
	// @todo: Need to release individual objects and compact otherwise fagmentation will occur
	// Workaround is to use ReleaseAllIOObjects
}
//****************************************************************************
/// Empties all IO objects from the IO Heap Buffer
///
//****************************************************************************
void CIOMemManager::ReleaseAllIOObjects(void) {
	// Allow space to be reallocated
	m_FreeSpace = m_IOBufferSize;
	m_pNextFreeAddress = m_pHeapIOBuffer;
}

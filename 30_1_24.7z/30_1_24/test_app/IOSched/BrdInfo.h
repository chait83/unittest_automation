/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n BrdInfo.h
/// @n interface for the CBrdInfo class.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 42	Stability Project 1.39.1.1	7/2/2011 4:55:44 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 41	Stability Project 1.39.1.0	7/1/2011 4:27:03 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 40	V6 Firmware 1.39		1/19/2007 4:58:33 PM	Graham Waterfield
//		Allow for the maximum AO output current to be based on board revision
//		number
// 39	V6 Firmware 1.38		7/31/2006 1:42:29 PM	Graham Waterfield
//		Added ezTrend mods and input GCA damping. Some work done on
//		linearisation tables (but parked until setup UI done)
// $
//
//////////////////////////////////////////////////////////////////////
#if !defined(AFX_BRDINFO_H__7183B928_7F0B_4A3E_B59F_D66BE1885837__INCLUDED_)
#define AFX_BRDINFO_H__7183B928_7F0B_4A3E_B59F_D66BE1885837__INCLUDED_
#include <QMutex>
#include "IOCardInfo.h"
#include "CardSlot.h"
#include "CardList.h"
#include "PassiveModule.h"
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
/// Being a singleton the single instance of the board information class can be read by all
/// other I/O scheduler classes by using GetHandle().
/// The Board information will be directly updated by the the BaseProtocol class.
/// To allow limited update of the board information the data is declared
/// private and BaseProtocol made a friend of this module. This effectively splits the
/// module implementation into the two distinct components	and only
/// allows the BaseProtocol class to update the board configuration via I/O board messages
class CBrdInfo: public CPassiveModule {
	// Allow the base protocol, board configurations and card factory to update protected board configuration
	friend class CAIConfig;
	friend class CAOConfig;
	friend class CDigConfig;
	friend class CBaseProtocol;
	friend class CCardList;
	friend class CATECal;
	friend class CIOScheduler;
public:		//Singleton 
	static CBrdInfo* GetHandle();
	void CleanUp();
	BOOL ConfigCRCCheck(const USHORT cardNo) const;
	void SetCalcConfigCRC(USHORT cardNo, USHORT configCRC);
	USHORT GetCalcConfigCRC(USHORT cardNo);
	void SetFirstRigID(USHORT cardNo, UCHAR rigID);
	// Test result storage accessors
	void SetCurrentRigID(const USHORT cardNo, const UCHAR rigID);
	void SetLastTestStatus(const USHORT cardNo, const UCHAR LastTestStatus);
	void SetDateLastTested(const USHORT cardNo, const ULONG date);
	ULONG GetDateLastTested(const USHORT cardNo) const;
	UCHAR GetBoardLastTestRig(const USHORT cardNo) const;
	UCHAR GetLastTestStatus(const USHORT cardNo) const;
	void SetLastRigID(USHORT cardNo, UCHAR rigID);
	UCHAR WhatBoardType(const USHORT cardNo) const;
	UCHAR WhatSelectedChannelType(const USHORT cardNo, const USHORT channelNo) const;
	UCHAR WhatAvailableChannelType(const USHORT cardNo, const USHORT channelNo) const;
	UCHAR GetNoOfChannels(const USHORT cardNo) const;
	ULONG GetFirmwareBuildNo(const USHORT cardNo) const;
	ULONG GetRootFirmwareBuildNo(const USHORT cardNo) const;
	USHORT HighestAllowedmAOutput(const USHORT slotNo, const BOOL overRangeAllowed) const;
	UCHAR WhatModbusSelectedDigChannelType(const USHORT sysChannelNo, const T_PENBASE base) const;
	UCHAR WhatModbusSelectedAnalChannelType(const USHORT sysChannelNo, const T_PENBASE base) const;
	const bool IsAIChannelLinear(const USHORT chanType) const;
	USHORT GetQueueGearing(USHORT cardNo) const;
	ULONG GetQueueRollover(USHORT cardNo) const;
	USHORT GetBoardTimebase(const USHORT cardNo) const;
	USHORT GetBoardTicks(const USHORT cardNo) const;
	USHORT GetBoardConfigCRC(const USHORT cardNo) const;
//	UCHAR GetBoardCurrentTestRig( const USHORT cardNo ) const;
	UCHAR GetCurrentTestRigID(const USHORT cardNo) const;
	ULONG GetDateFirstTested(const USHORT cardNo) const;
	UCHAR GetBoardFirstTestRig(const USHORT cardNo) const;
	BOOL GetBoardRangeRevision(const USHORT cardNo, UCHAR *const pRangeRevision) const;
	BOOL GetBoardFirmwareRevision(const USHORT cardNo, UCHAR *const pBoardRevision, int pBuffSize);
	BOOL GetBoardHardwareRevision(const USHORT cardNo, UCHAR *const pHWRevision) const;
	BOOL IsFirmwareAtLeastRevision(const USHORT cardNo, const UCHAR *pRefBoardRevision,
			const ULONG refBoardBuildNo) const;
	T_AIRANGE GetIOCardChannelRangeSelection(const USHORT cardNo, const USHORT channelNo) const;
	void MoveCardCapabilitiesToNewSlot(const USHORT OrigCardSlot, const USHORT newCardSlot);
	BOOL AIAcqRatePrimaryChannel(const USHORT cardNo, const USHORT usBoardChanNo, USHORT *pPrimaryChanNo,
	USHORT *pBankNo) const;
	float GetDegCCJCReading(const USHORT cardNo) const;
	float GetDegCCJCReading(const USHORT cardNo, const USHORT usBoardChanNo) const;
	void SetDegCCJCReading(const USHORT cardNo, const float value);
	void SetDegCCJCReading(const USHORT cardNo, const USHORT usCJCNo, const float value);
	//PSR - fix for IO compatibility for star star star fix
	//This function verifies the AI card FW version/Build number
	//that supports ADC reset thru perform RESET function code
	BOOL IsCardResetSupported(const USHORT cardNo);
	void SetBoardFirmwareRevision(const USHORT cardNo, UCHAR *const pFirmwareRevision);
private:	// Singleton
	CBrdInfo();
	CBrdInfo(const CBrdInfo&);
	CBrdInfo& operator=(const CBrdInfo&) {
		return *this;
	}
	;
	~CBrdInfo();
	void SetQueueGearing(const USHORT cardNo, const USHORT queueGearing);
	void SetQueueRollover(const USHORT cardNo, const ULONG queueRollover);
	void SetAvailableChannelType(const USHORT cardNo, const USHORT channelNo, const UCHAR channelCap);
	void SetIOCardChannelSelection(const USHORT cardNo, const USHORT channelNo, const T_AIRANGE BaseRangeInfo);
	static bool ms_bUseAverageCJC;
public:
	void SetBoardHardwareRevision(const USHORT cardNo, const UCHAR HWRevision);
	void SetBoardRangeRevision(const USHORT cardNo, const UCHAR RangeRevision);
	void SetBoardType(const USHORT cardNo, const UCHAR boardType);
	void SetDateFirstTested(const USHORT cardNo, const ULONG date);
	void SetBoardTimebase(const USHORT cardNo, const USHORT timebase);
	void SetSelectedChannelType(const USHORT cardNo, const USHORT channelNo, const UCHAR channelType);
	void SetBoardTicks(const USHORT cardNo, const USHORT IOCardTicks);
	// Toggles the use average CJC flag and returns the current state of this flag
	static const bool ToggleUseAverageCJC() {
		ms_bUseAverageCJC = !ms_bUseAverageCJC;
		return ms_bUseAverageCJC;
	}
	// Returns the current state of this flag
	static const bool GetUseAverageCJC() {
		return ms_bUseAverageCJC;
	}
	void BoardInfoBeenUploaded(const USHORT cardNo, const BOOL InfoUploaded);
	void SetBoardConfigCRC(const USHORT cardNo, const USHORT configCRC);
	BOOL TestNoOfChannels(const USHORT cardNo, const UCHAR boardType, const UCHAR noOfChans);
	BOOL SetNoOfChannels(const USHORT cardNo, const UCHAR noOfChans);
private:
	BOOL HasBoardInfoBeenUploaded(const USHORT cardNo) const;
	static CBrdInfo *m_pInstance;
	static QMutex m_CreationMutex;
	T_OVERALLBOARDINFO m_BrdInfo[MAX_SCHED_SERVICES];	///< Board info
};
#endif // !defined(AFX_BRDINFO_H__7183B928_7F0B_4A3E_B59F_D66BE1885837__INCLUDED_)

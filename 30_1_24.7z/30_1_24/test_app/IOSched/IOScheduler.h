//////////////////////////////////////////////////////////////////////
/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	I/O Scheduler
/// @n Filename: IOScheduler.h
/// @n Desc:	interface for the IOScheduler class.
///
// 
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 36	Stability Project 1.33.1.1	7/2/2011 4:58:02 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 35	Stability Project 1.33.1.0	7/1/2011 4:27:05 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 34	V6 Firmware 1.33		11/16/2006 4:44:39 PM Graham Waterfield
//		Added more event diagnostic information and got AI calibration
//		rescheduling
// 33	V6 Firmware 1.32		11/22/2005 2:01:33 PM Roger Dawson 
//		User calibration changes. Made message handler virtual in the base
//		class and added method to the IOScheduler child class so module
//		specific methods can be handled within the specific module rather
//		than writing code within the active module base class.
// $
//
//////////////////////////////////////////////////////////////////////
#if !defined(AFX_CIOSCHEDULER_H__2C2CE960_FCA1_42E1_93AE_BFA48A04B4E4__INCLUDED_)
#define AFX_CIOSCHEDULER_H__2C2CE960_FCA1_42E1_93AE_BFA48A04B4E4__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "V6ActiveModule.h"
#include "ModuleMsgManagerClient.h"
#include "ConfigManager.h"
#include "CardList.h"
#ifdef DBG_FILE_LOG_IO_SCHED_ENABLE
	#include "CStorage.h"
#endif
class CIOScheduler: public CV6ActiveModule {
public:
	CIOScheduler(T_MODULE_ID moduleId);
	BOOL InitialiseScheduler(void);
	BOOL HasShutdownBeenOrdered(void);
	BOOL HasIdleModeBeenOrdered(void) const;
	BOOL ScheduleService(void);
	void Wait(void);
	BOOL UpdateBoardCapabilities(void);
	BOOL IOCommitCMM(void);
	BOOL LoadRunTimeRanges(void);
	DWORD GetScheduleTime(void);
	BOOL ActivatePriorityService(void);
	BOOL CheckATECardReadingsAvailable(void);
	BOOL RegisterForModeSelect(void);
	BOOL CommitLocalDeviceCapabilities(void);
	BOOL QueryIOHardware(void);
	virtual ~CIOScheduler();
	/// Carries out the desired functional when a message is received
	T_V6ACTMOD_RETURN_VALUE ModuleMessageHandler(const CMsgQueueMessage *pMsg);
	/// Primary Initialisation of the Module
	virtual T_V6ACTMOD_RETURN_VALUE PerformPrimaryInitialisation(void);
	/// Secondary Initialisation of the Module
	virtual T_V6ACTMOD_RETURN_VALUE PerformSecondaryInitialisation(void);
	/// Method called when Module goes into Normal Operation
	virtual T_V6ACTMOD_RETURN_VALUE NormalOperation(void);
	/// Method called when Module is to prepare for Setup Config Change 
	virtual T_V6ACTMOD_RETURN_VALUE SetupConfigChangePreparation(void);
	/// Method called when a Module is to prepare for Shutdown
	virtual T_V6ACTMOD_RETURN_VALUE ShutdownPreparation(void);
	/// Method called when a Module is to Shutdown
	virtual T_V6ACTMOD_RETURN_VALUE Shutdown(void);
	/// Method called when Module is to carry out Setup Change Completion
	virtual T_V6ACTMOD_RETURN_VALUE SetupConfigChangeComplete(void);
	/// Method called when Module is informed to Carry out Query Hardware
	virtual T_V6ACTMOD_RETURN_VALUE ATEQueryHardware(void);
	/// Method called when Module is informed to perform ATE Calibration
	virtual T_V6ACTMOD_RETURN_VALUE ATECalibration(void);
	/// Method called when Module is informed to perform ATE Test
	virtual T_V6ACTMOD_RETURN_VALUE ATETest(void);
	/// Method called when the Calibration Info has been updated, and can be processed
	virtual T_V6ACTMOD_RETURN_VALUE ProcessCalibrationInfo(void);
	/// Method called when the IO Scheduler is told to Process Card Readings
	virtual T_V6ACTMOD_RETURN_VALUE ProcessATECardChannels(void);
	//static USHORT m_usForceIOResetSlot;
private:
	BOOL UploadCMMConfiguration(void);
	// Method called when the user has finished calibrating AI cards (this will be immediately
	// prior to a reboot). The calibration NVRAM needs to be updated at this point
	void CalibrationFinished();
//	class CDeviceAbstraction *m_pDevAbst;			///< Device abstraction layer holder
	class CBrdInfo *m_pBrdInfoObj;					///< Board info holder
	class CBrdStats *m_pBrdStatsObj;				///< Board stats holder
	// I/O scheduler messages
	class CModuleMsgManagerClient m_mmClient;		///< Message Manager Client
	const CMsgQueueMessage *m_pMsg;					///< Received Message
	class CIOConfigManager *m_pCIOConfigManagerObj;	///< I/O card CMM manager
	class CCardList *m_pCardHldr;				///< Card list holder creation
	USHORT m_IOS_command;					///< Mode change/progression command
public:
#ifdef DBG_FILE_LOG_IO_SCHED_ENABLE
	CDebugFileLogger m_debugFileLogger;
#endif
};
#endif // !defined(AFX_CIOSCHEDULER_H__2C2CE960_FCA1_42E1_93AE_BFA48A04B4E4__INCLUDED_)

/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	I/O Scheduler
/// @n Filename: PPIOService.h
/// @n Desc:	interface for the abstract pre-process I/O service handler
///
// 
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 16	Stability Project 1.13.1.1	7/2/2011 4:59:45 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 15	Stability Project 1.13.1.0	7/1/2011 4:27:14 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 14	V6 Firmware 1.13		6/9/2006 1:12:02 PM	Graham Waterfield
//		Merged phase 2 development
// 13	V6 Firmware 1.12		11/18/2005 3:22:18 PM Graham Waterfield
//		Staged check-in of manual calibration changes
// $
//
//////////////////////////////////////////////////////////////////////
#ifndef _PPIOSERVICE_H
#define _PPIOSERVICE_H
#if !defined(AFX_PPIOSERVICE_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_)
#define AFX_PPIOSERVICE_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_
#include "Defines.h"
#include "IOHandler.h"
#include "PPQCommon.h"
#define ROUND_READING_TIME_UP		1500		///< Round up by a 1.5 seconds
class CPPIOService {
public:
	CPPIOService(const BOOL isChanInput);
	virtual ~CPPIOService();
	BOOL InitialiseChanService(void);
	BOOL DisableService(T_CHANPROCESSINFO *const pChanInfo);
	BOOL DisableService(T_COMMONPROCESSINFO *const pBoardInfo);
	T_PPQC_ACQUSITION_RATE ConvertToPPQ(const UCHAR PPService, const USHORT ConfigAcqRate) const;
	BOOL CreateDefaultChannelServiceData(T_COMMONPROCESSINFO *pboardInfo, T_CHANPROCESSINFO *pchanInfo,
			class CCardSlot *const pCard, const USHORT chanNo);
protected:
};
#endif // !defined(AFX_PPIOSERVICE_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_)
#endif		// _PPIOSERVICE_H

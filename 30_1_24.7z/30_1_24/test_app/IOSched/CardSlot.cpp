//////////////////////////////////////////////////////////////////////
/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n CardSlot.cpp
/// @n implementation of the CCardSlot class.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 67	Stability Project 1.62.1.3	7/2/2011 4:55:54 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 66	Stability Project 1.62.1.2	7/1/2011 4:38:01 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 65	Stability Project 1.62.1.1	3/17/2011 3:20:13 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 64	Stability Project 1.62.1.0	2/15/2011 3:02:22 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////
#include "Conversion.h"
#include "IOCardInfo.h"
#include "IOCardStats.h"
#include "BrdStats.h"
#include "BrdInfo.h"
#include "Timer.h"
#include "CardSlot.h"
#include "PPL.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CCardSlot::CCardSlot(const USHORT cardNo) : m_ChanList(static_cast<UCHAR>(cardNo)) {
//	qDebug("Create new CCardSlot\n");
	//Reset for IO card to recovery ADC timeout and Wrong Speed mode errors(**** issues) begin
	m_bIsResetNeeded = false;
	//Reset for IO card to recovery ADC timeout and Wrong Speed mode errors(**** issues) end
	// Get a handle on board info, stats and abstraction layer
	m_pBrdInfoObj = CBrdInfo::GetHandle();
	m_pBrdStatsObj = CBrdStats::GetHandle();
	m_Instance = cardNo;
	m_ChannelsCreated = FALSE;
	// Default condition is that startup data needs to be collected
	m_FirstReadRqd = TRUE;
	m_DataFromCard = FALSE;
	m_chanReadMask = 0;
	m_chanAckMask = 0;
	m_thisStateMCCycles = 0;
	m_nextRunTime = 0L;
	m_timeToRead = 0L;			///< Time to read next block data
	m_BoardCmd.Reset = FALSE;
	m_BoardCmd.ConfigCheck = FALSE;
	m_BoardCmd.ConfigDownload = FALSE;
	m_BoardCmd.UserCalibration = FALSE;
	m_BoardCmd.FactoryCalibration = FALSE;
	m_BoardCmd.ConfigUpload = FALSE;
	m_BoardCmd.HistoryUpload = FALSE;
	m_BoardCmd.Acquire = FALSE;
	m_BoardCmd.CardIDUpload = FALSE;
	m_BoardCmd.CardTestStatUpload = FALSE;
	m_BoardCmd.AIRTChanCal = FALSE;
	m_BoardCmd.AICalQuery = FALSE;
}
CCardSlot::~CCardSlot() {
//	qDebug("Destroy CCardSlot class\n");
	// Destroy all created channels
}
//Reset for IO card to recovery ADC timeout and Wrong Speed mode errors(**** issues) begin
void CCardSlot::UpdateCardReset(bool isResetNeeded) {
	m_bIsResetNeeded = isResetNeeded;
}
bool CCardSlot::IsResetRequired() {
	return m_bIsResetNeeded;
}
void CCardSlot::PerformReset() {
	//Do nothing here and let the Specific Slot/Card handle its own way
}
//Reset for IO card to recovery ADC timeout and Wrong Speed mode errors(**** issues) end
//******************************************************
// InitialiseCard()
///
/// Runs the factory to create concrete board type.
/// @param[in] cardNo - Card number identification.
///
/// @return TRUE if card have been succesfully identified; otherwise FALSE
/// 
//******************************************************
BOOL CCardSlot::RegisterCard( USHORT cardNo) {
	BOOL retValue = TRUE;
	if (m_pBrdStatsObj == NULL) {
		// @todo: Unable to get handle/create board stats
		retValue = FALSE;
	}
	if (m_pBrdInfoObj == NULL) {
		// @todo: Unable to get handle/create board info
		retValue = FALSE;
	}
	m_Instance = cardNo;
	return retValue;
}
//******************************************************
///
/// Schedule a history status upload from a single I/O cards.
///
/// @return TRUE if successfully scheduled; otherwise FALSE
/// 
//******************************************************
BOOL CCardSlot::ScheduleHistoryUpload(void) {
	m_BoardCmd.HistoryUpload = TRUE;
	return m_BoardCmd.HistoryUpload;
}
//******************************************************
///
/// Schedule a board info status upload from a single I/O cards.
///
/// @return TRUE if successfully scheduled; otherwise FALSE
/// 
//******************************************************
BOOL CCardSlot::ScheduleBoardInfoUpload(void) {
	m_BoardCmd.BoardInfoUpload = TRUE;
	return m_BoardCmd.BoardInfoUpload;
}
//******************************************************
///
/// Quey whether the I/O card has returned signal process data.
///
/// @return TRUE if process data has been obtained; otherwise FALSE
/// 
//******************************************************
BOOL CCardSlot::HasProcessDataBeenReturned() {
	return m_DataFromCard;
}
//******************************************************
///
/// Log that the I/O card has returned signal process data.
/// @param[in] dataObtained - TRUE if data has been obtained.
///
/// @return TRUE if data obtained; otherwise FALSE
/// 
//******************************************************
BOOL CCardSlot::ProcessDataReturned(const BOOL dataObtained) {
	m_DataFromCard = dataObtained;
	return m_DataFromCard;
}
//******************************************************
// AckChannelRecieved()
///
/// Acknowledge that channel data has been successfully received.
/// @param[in] chanNo - The channel number.
///
/// @return The bit mask of channels successfully received
/// 
//******************************************************
USHORT CCardSlot::AckChannelRecieved(const USHORT chanNo) {
	SetBits(static_cast<USHORT*>(&m_chanAckMask), 1, chanNo, 1);
	return static_cast<USHORT>(m_chanAckMask);
}
//******************************************************
// GetBlockTransChansToAck()
///
/// Query to find the channel data successfully received.
///
/// @return The bit mask of channels successfully received
/// 
//******************************************************
USHORT CCardSlot::GetBlockTransChansToAck(void) {
	return static_cast<USHORT>(m_chanAckMask);
}
//******************************************************
///
/// Clear the channel log of successfully received channels.
///
//******************************************************
void CCardSlot::ClearAckChannelRecieved(void) {
	m_chanAckMask = 0;
}
//******************************************************
///
/// Schedule a configuration upload from a single I/O cards.
///
/// @return TRUE if successfully scheduled; otherwise FALSE
/// 
//******************************************************
BOOL CCardSlot::ScheduleConfigUpload(void) {
	m_BoardCmd.ConfigUpload = TRUE;
	return m_BoardCmd.ConfigUpload;
}
//******************************************************
///
/// Schedule a configuration download to a single I/O cards.
///
/// @return TRUE if successfully scheduled; otherwise FALSE
/// 
//******************************************************
BOOL CCardSlot::ScheduleConfigDownload(void) {
	m_BoardCmd.ConfigDownload = TRUE;
	return m_BoardCmd.ConfigDownload;
}
//******************************************************
///
/// Queries what type of board is in a current slot.
///
/// @return Card slot board type
/// 
//******************************************************
UCHAR CCardSlot::WhatBoardType(void) {
	class CBrdInfo *pBrdInfoObj = NULL;					///< Board info holder
	pBrdInfoObj = CBrdInfo::GetHandle();
	return pBrdInfoObj->WhatBoardType(m_Instance);
}
//******************************************************
///
/// Sets what type of board is in a current slot.
///
/// @return Card slot board current timebase frequency
///
//******************************************************
USHORT CCardSlot::GetBoardTimebase(void) {
	class CBrdInfo *pBrdInfoObj = NULL;					///< Board info holder
	pBrdInfoObj = CBrdInfo::GetHandle();
	return pBrdInfoObj->GetBoardTimebase(m_Instance);
}
//******************************************************
///
/// Checks the board configuration downloaded to a current slot.
///
/// @return TRUE if the calculated CRC and actual CRC match; otherwise FALSE
//******************************************************
BOOL CCardSlot::ConfigCRCCheck(void) {
	class CBrdInfo *pBrdInfoObj = NULL;					///< Board info holder
	pBrdInfoObj = CBrdInfo::GetHandle();
	return pBrdInfoObj->ConfigCRCCheck(m_Instance);
}
//******************************************************
// GetProcessHandle()
///
/// Get the default card handler so that card specific information can
/// be handled in a generic manner.
///
/// @return Card process handler
/// 
//******************************************************
class CIOCardHandler* CCardSlot::GetProcessHandle(void) {
	return static_cast<class CIOCardHandler*>(NULL);
}
//******************************************************
///
/// Gets the board configuration CRC that has been calculated for a current slot.
///
/// @return The calculated CRC of the local configuration
/// 
//******************************************************
USHORT CCardSlot::GetCalcConfigCRC(void) {
	class CBrdInfo *pBrdInfoObj = NULL;					///< Board info holder
	pBrdInfoObj = CBrdInfo::GetHandle();
	return pBrdInfoObj->GetCalcConfigCRC(m_Instance);
}
//******************************************************
///
/// Gets the board configuration downloaded to a current slot.
///
/// @return The CRC of the configuration stored on the board
/// 
//******************************************************
USHORT CCardSlot::GetBoardConfigCRC(void) {
	class CBrdInfo *pBrdInfoObj = NULL;					///< Board info holder
	pBrdInfoObj = CBrdInfo::GetHandle();
	return pBrdInfoObj->GetBoardConfigCRC(m_Instance);
}
//******************************************************
///
/// Queries what the date first tested of the chosen card is.
///
/// @return The I/O boards ID
/// 
//******************************************************
ULONG CCardSlot::GetDateFirstTested(void) {
	class CBrdInfo *pBrdInfoObj = NULL;					///< Board info holder
	pBrdInfoObj = CBrdInfo::GetHandle();
	return pBrdInfoObj->GetDateFirstTested(m_Instance);
}
//******************************************************
///
/// Queries what the date last tested of the chosen card is.
///
/// @return The I/O boards ID
/// 
//******************************************************
ULONG CCardSlot::GetDateLastTested(void) {
	class CBrdInfo *pBrdInfoObj = NULL;					///< Board info holder
	pBrdInfoObj = CBrdInfo::GetHandle();
	return pBrdInfoObj->GetDateLastTested(m_Instance);
}
//******************************************************
// GetLastTestStatus()
///
/// Gets whether the card passed the last test performed.
///
/// @return last test status
///
//******************************************************
UCHAR CCardSlot::GetLastTestStatus(void) {
	class CBrdInfo *pBrdInfoObj = NULL;					///< Board info holder
	pBrdInfoObj = CBrdInfo::GetHandle();
	return pBrdInfoObj->GetLastTestStatus(m_Instance);
}
//******************************************************
///
/// Queries what the I/O board revision is.
/// @param[out] pBoardRevision - Board revision letters.
///
/// @return TRUE if the boards revision is available; otherwise FALSE
/// 
//******************************************************
BOOL CCardSlot::GetBoardFirmwareRevision(UCHAR *const pBoardRevision, int pBuffSize) const {
	class CBrdInfo *pBrdInfoObj = NULL;					///< Board info holder
	pBrdInfoObj = CBrdInfo::GetHandle();
	return pBrdInfoObj->GetBoardFirmwareRevision(m_Instance, pBoardRevision, pBuffSize);
}
//******************************************************
///
/// Queries what type of channel is currently selected.
/// @param[in] channelNo - Card slot channel number.
///
/// @return The channel type currently selected
/// 
//******************************************************
UCHAR CCardSlot::WhatSelectedChannelType(const USHORT channelNo) const {
	class CBrdInfo *pBrdInfoObj = NULL;					///< Board info holder
	pBrdInfoObj = CBrdInfo::GetHandle();
	if (pBrdInfoObj != NULL)
		return pBrdInfoObj->WhatSelectedChannelType(m_Instance, channelNo);
	return CHANNEL_UNKNOWN;
}
//******************************************************
///
/// Queries what type of channel types are available from a given board channel.
/// @param[in] channelNo - Card slot channel number.
///
/// @return The channel capabilities - i.e. types currently available for selection
/// 
//******************************************************
UCHAR CCardSlot::WhatAvailableChannelType(const USHORT channelNo) const {
	class CBrdInfo *pBrdInfoObj;					///< Board info holder
	pBrdInfoObj = CBrdInfo::GetHandle();
	if (pBrdInfoObj != NULL)
		return pBrdInfoObj->WhatAvailableChannelType(m_Instance, channelNo);
	return CHANNEL_CAP_UNKNOWN;
}
//******************************************************
///
/// Gets the pre-process queue gearing for the I/O card.
///
/// @return The main queue gearing ratio
//******************************************************
USHORT CCardSlot::GetQueueGearing(void) {
	class CBrdInfo *pBrdInfoObj;					///< Board info holder
	pBrdInfoObj = CBrdInfo::GetHandle();
	return pBrdInfoObj->GetQueueGearing(m_Instance);
}
//******************************************************
///
/// Gets the queue rollover value for the I/O card.
///
/// @return The value at which the main queue will rollover
//******************************************************
ULONG CCardSlot::GetQueueRollover(void) {
	class CBrdInfo *pBrdInfoObj;					///< Board info holder
	pBrdInfoObj = CBrdInfo::GetHandle();
	return pBrdInfoObj->GetQueueRollover(m_Instance);
}
//******************************************************
// BoardSlotInstance()
///
/// Queriries the board slot ID.
///
/// @return Card slot ID
/// 
//******************************************************
USHORT CCardSlot::BoardSlotInstance(void) {
	return m_Instance;
}
//******************************************************
// GetBoardType()
///
/// Get I/O board type RTTI.
///
/// @return Board type information
//******************************************************
UCHAR CCardSlot::GetBoardType(void) const {
	UCHAR boardType = BOARD_IMPOSSIBLE;
	if (m_Instance < MAXIOCARDS) {
		boardType = m_pBrdInfoObj->WhatBoardType(m_Instance);
	} else if (MAX_SCHED_SERVICES - 1 == m_Instance) {
		boardType = BOARD_POWER_RELAY;
	}
	return boardType;
}
//******************************************************
// IsCMMConfigValid()
///
/// Check the CMM configuartion to a single I/O board.
///
/// @return TRUE if the I/O board CMM configuration uploaded is the same as the local config; otherwise FALSE.
/// 
//******************************************************
BOOL CCardSlot::IsCMMConfigValid(void) {
	if ((m_pBrdInfoObj->GetBoardConfigCRC(m_Instance) != 0)
			&& (m_pBrdInfoObj->GetBoardConfigCRC(m_Instance) == m_pBrdInfoObj->GetCalcConfigCRC(m_Instance)))
		return TRUE;
	return FALSE;
}
//******************************************************
// InitialiseChannels()
///
/// Create or refurbish the I/O card channels.
///
/// @return TRUE if local configuration could be created, otherwise FALSE 
/// 
//******************************************************
BOOL CCardSlot::InitialiseChannels(void) {
	BOOL retValue = FALSE;
	BOOL chansAlreadyCreated = FALSE;
	QString errLog;
	chansAlreadyCreated = m_ChannelsCreated;
	if (m_ChannelsCreated == TRUE) {
		// Only creates the channels once
		retValue = m_ChanList.ChannelFactory(this, TRUE);
	} else {
		// Refurbish the original channels
		retValue = m_ChanList.ChannelFactory(this, FALSE);
		m_ChannelsCreated = retValue;
	}
	// If the channels are not created correctly the invalidate board, to prevent further processing
	if (retValue == FALSE) {
		// @todo: Set the local board capabilities to board unservicable
		// Log failure
		errLog = QString::asprintf("I/O board %d: Could not create channel handler", m_Instance);
		LogInternalError(errLog.toLocal8Bit().data());
	}
	// If channel creation/refurbish successful and board handler not previously created; then create
	retValue = CardBoardHandlerFactory();
	// If the board handler are not created correctly the invalidate board, to prevent further processing
	if (retValue == FALSE) {
		// @todo: Set the local board capabilities to board unservicable
		// Log failure
		errLog = QString::asprintf("I/O board %d: Could not create board handler", m_Instance);
		LogInternalError(errLog.toLocal8Bit().data());
	}
	return retValue;
}
//******************************************************
// CardBoardHandlerFactory()
///
/// Queries each board type to check whether a board handler is required.
/// @note: Used so that single digital card can be overloaded
///
/// @return TRUE if no errors are encountered during any board creation and initialisation;
///		otherwise FALSE.
/// 
//******************************************************
BOOL CCardSlot::CardBoardHandlerFactory(void) {
	BOOL retValue = TRUE;
	return retValue;
}
//******************************************************
// GetChanSchedule()
///
/// Gets an IO card channel schedule list.
///
/// @return Channel schedule list.
/// 
//******************************************************
class CChanList* CCardSlot::GetChanSchedule(void) {
	return &m_ChanList;
}
//******************************************************
// SetGlobalChannelID()
///
/// Sets the global system system known channel number.
/// @param[in] channelNo - Card slot channel number.
/// @param[in] glbChannelNo - Card slot channel number, globally known to system.
///
/// @return TRUE if the global channel number is succesfully set; otherwise FALSE
/// 
//******************************************************
BOOL CCardSlot::SetGlobalChannelID(const USHORT channelNo, const USHORT glbChannelNo) {
	return m_ChanList.SetGlobalChannelID(channelNo, glbChannelNo);
}
//******************************************************
// AddChanToSchedule()
///
/// Adds an IO channel to an IO card to allow returned channel data to be processed.
/// @param[in] cardNo - Channel number identification.
/// @param[in] pCard - The concrete channel type to add.
///
/// @return TRUE is channel is added; otherwise FALSE.
/// 
//******************************************************
BOOL CCardSlot::AddChanToSchedule(const USHORT chanNo, class CIOHandler *const pChan) {
	return m_ChanList.AddChanToSchedule(chanNo, pChan);
}
//******************************************************
///
/// Schedule the IO board to enter run mode.
///
/// @param[in] runMode - TRUE if the IO board is to enter run mode; otherwise FALSE.
///
/// @return TRUE if successfully scheduled; otherwise FALSE
/// 
//******************************************************
BOOL CCardSlot::ScheduleIOBoardRunMode(BOOL runMode) {
	m_CardOperational = runMode;
	return runMode;
}
//******************************************************
///
/// Queries whether the IO board is in run mode.
///
/// @return TRUE if the IO board hase successfully entered run mode; otherwise FALSE
/// 
//******************************************************
BOOL CCardSlot::IsIOBoardInRunMode() const {
	CBrdStats *pBrdStatsObj = NULL;
	pBrdStatsObj = CBrdStats::GetHandle();
	return (m_CardOperational && (pBrdStatsObj->HasIdleModeBeenOrdered() == FALSE));
}
//******************************************************
///
/// Queries whether the IO board has entered idle mode.
///
/// @return TRUE if the IO board hase successfully entered run mode; otherwise FALSE
/// 
//******************************************************
BOOL CCardSlot::HasIdleModeBeenOrdered() const {
	CBrdStats *pBrdStatsObj = NULL;
	pBrdStatsObj = CBrdStats::GetHandle();
	return (m_CardOperational && (pBrdStatsObj->HasIdleModeBeenOrdered() == TRUE));
}
//******************************************************
// ScheduleProcess()
///
/// Reschedule the no later than time, based on the last time.
///
/// @return TRUE
/// 
//******************************************************
BOOL CCardSlot::ScheduleProcess(void) {
//	for( chanNo = 0; chanNo < m_ChanList.GetListCount(); chanNo++ )
	m_nextRunTime = (m_nextRunTime);
	// Has time already passed
	// If time has already passed then log schedule failure and reschedule for minimum reschedule time
	return TRUE;
}
//******************************************************
// GetTimeServiceRqd()
///
/// Gets the time the board next needs servicing for a main channel reading.
///
/// @return the time that board next requires servicing
/// 
//******************************************************
LONGLONG CCardSlot::GetTimeServiceRqd(void) {
//	USHORT chanNo;
	// Check all channels for the first channel that requires servicing
//	m_ChanList.GetEarliestServiceRqd( &chanNo, &m_nextRunTime );
	return m_nextRunTime;
}
//******************************************************
// SetNextRunTime()
///
/// Set the next time to run again for all channels requiring reschedule.
/// @todo: limit to only the channels that require rescheduling
///
/// @return TRUE if no errors (even if no channels to schedule) otherwise FALSE if any channel failed to schedule
/// 
//******************************************************
BOOL CCardSlot::SetNextRunTime(void) {
	USHORT chanNo;
	BOOL retValue = TRUE;
//	m_nextRunTime = nextScheduled;
	// @todo: For all channels processed this time; reschedule their next read time
	for (chanNo = 0; chanNo < m_ChanList.GetChannelCount(); chanNo++) {
		if (m_ChanList.ScheduleChannelRead(chanNo) == FALSE)
			retValue = FALSE;
	}
	// Check all channels for the first channel that requires servicing
	// and use that as the new board time
	m_ChanList.GetEarliestServiceRqd(&chanNo, &m_nextRunTime);
	return retValue;
}
//******************************************************
// InitialiseBoardCapabilities()
///
/// Intialise the board capabilites holder with all General I/O system boards.
///
/// @return TRUE if successful initialised; otherwise FALSE
/// 
//******************************************************
BOOL InitialiseBoardCapabilities(void) {
	// Get device capabilities for Power relay
	// Get device capabilities for each optional I/O board
	return TRUE;
}
//******************************************************
// WhatBoardSubType()
///
/// There can be subtypes for few boards for example AI card(V6AI & V7AI)
/// This function returns the AICard type i.e. T_AI_CARD_TYPE -- V6AI(old) or V7AI(new)
/// @param[in] cardNo - Card slot number identification.
///
/// @return value - V6AI if the card is of old type otherwise V7AI
/// Rev History
/// @Version	@Date			@Author					@Remarks
/// 1.0			28/Mar/2019		Shankar Rao	Pendyala	IO compatibility with New AI card and Old AI Card
//******************************************************
UCHAR CCardSlot::WhatBoardSubType(void) {
	return AI_CARD_TYPE_INVALID;
}

/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	I/O Scheduler
/// @n Filename: IOCardHandler.h
/// @n Desc:	interface for the I/O channel
///
// 
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 33	Stability Project 1.30.1.1	7/2/2011 4:58:01 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 32	Stability Project 1.30.1.0	7/1/2011 4:27:15 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 31	V6 Firmware 1.30		1/5/2007 3:32:04 PM	Graham Waterfield
//		Changed to allow process time for each channel to be calculated for
//		missing readings
// 30	V6 Firmware 1.29		11/8/2006 3:01:24 PM	Graham Waterfield
//		Digital I/O setup commit improvements, first stage of hardware
//		counters and fix to milli-amp user defined range.
// $
//
//////////////////////////////////////////////////////////////////////
#ifndef _IOCHANHANDLER_H
#define _IOCHANHANDLER_H
#if !defined(AFX_IOCHANHANDLER_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_)
#define AFX_IOCHANHANDLER_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_
#include "IOHandler.h"
#include "PPQCommon.h"
class CIOChanHandler: public CIOHandler {
public:
	CIOChanHandler();
	virtual ~CIOChanHandler();
	BOOL InitialiseChanService(T_COMMONPROCESSINFO *const pBoardInfo, T_CHANPROCESSINFO *const pChanInfo,
			const UCHAR acqRate);
	BOOL SetGlobalChannelID(const USHORT glbChannelNo);
	BOOL SetupConfigChangePreparation(void);
	USHORT GetGlobalChannelID(void) const;
	BOOL UpdateOutputDigital(const BOOL NewOPState);
	BOOL OutputDigital(BOOL *pNewState);
	BOOL OutputAnalogue(USHORT *pOutputVal, UCHAR *pChanNo);
	void ResetDigPulseDITValues(void);
	void ResetDigitalDITValues(void);
	void ResetPulseDITValues(void);
	LONGLONG PulseProcessMissingChannelReadings(const LONGLONG lastProcTime, const LONGLONG procTime);
	void ResetRawVoltageReadings(void);
	LONGLONG AIProcessMissingChannelReadings(const LONGLONG lastProcTime, const LONGLONG procTime);
	BOOL ProcessAIChannelReadings(const UCHAR *pServiceData, const USHORT timestamp, const USHORT noOfReadings);
	BOOL ProcessPulseChannelReadings(const UCHAR *pServiceData, const USHORT timestamp, const USHORT noOfReadings);
	UCHAR GetChannelServiceRequired(void);
	BOOL SyncService(const USHORT IOCardTick, const LONGLONG systemTick);
	BOOL StartChanService(T_COMMONPROCESSINFO *const pBoardInfo, T_CHANPROCESSINFO *const pChanInfo,
			const UCHAR acqRate);
	BOOL StoreDefaultRTCal(const BOOL highCurrentSet);
	BOOL StoreRawRTCal(const T_RANGE_COUNTS RTCal, const BOOL highCurrent);
	BOOL StoreRawRTComp(const T_RANGE_COUNTS RTComp, const BOOL highCurrent, const USHORT cardSubType,
			const USHORT chanType);
	BOOL GetLatestRTComp(float *const pRTComp) const;
	BOOL GetLatestRTCal(float *const pRTCal) const;
protected:
	T_CHANPROCESSINFO m_ChanInfo;	///< Channel specific process information
private:
};
#endif // !defined(AFX_IOCHANHANDLER_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_)
#endif		// _IOCHANHANDLER_H

/// @file 
/// *****************************************************************
/// © Honeywell Trendview
/// *****************************************************************
/// @n Module : IOScheduler
/// @n FileName: IOMemManager.h
/// @n Desc  : Class Declaration for the CIOMemManager
///  
/// *****************************************************************
/// @b Revision @b History
/// *****************************************************************
/// $Log[4]:
/// 7 Stability Project 1.4.1.1 7/2/2011 4:58:02 PM Hemant(HAIL) 
/// Stability Project: Recorder source has been upgraded from IL
///  version of firmware to JF version of firmware.
/// 6 Stability Project 1.4.1.0 7/1/2011 4:27:12 PM Hemant(HAIL) 
/// Stability Project: Files has been checked in before the merging
///  task. The merging will be done between IL version of firmware and JF
///  version of firmware. 
/// 5 V6 Firmware 1.4 12/20/2006 3:14:49 PM  Jason Parker  
///  removed heap - THIS FILE CAN BE REMOVED FROM THE PROJECT
/// 4 V6 Firmware 1.3 1/20/2005 7:04:40 PM  Graham Waterfield
///  Move dedicated channels to the IO condition and replace with generic
///  board and channel handlers in the IO scheduler
/// $
///
/////////////////////////////////////////////////////////////////////
#ifndef _HEAPIOBUFFER_H
#define _HEAPIOBUFFER_H
#include "Defines.h"
#include <QMutex>
const DWORD HEAPIOBUFFER_HEAP_ABLE_TO_GROW = 0;
const USHORT HEAPIOBUFFER_FOUR_BYTES = 4;
const USHORT HEAPIOBUFFER_ZERO_VALUE = 0;
/// Return Values for CIOMemManager Member Functions, used to describe the type of 
/// success or failure.
///  
typedef enum {
	HEAPIOBUFFER_COMMITTED_MEMORY_RELEASED, HEAPIOBUFFER_HEAP_ALLOCATED, HEAPIOBUFFER_HEAP_ERROR
} T_HEAPIOBUFFER_RETURN_VALUE;
class CIOMemManager {
public:
	static CIOMemManager* GetHandle();
	void CleanUp();
	T_HEAPIOBUFFER_RETURN_VALUE AllocateIOMemManager(USHORT heapSize);
	BYTE* AllocateIOObject(USHORT objectSize);
	void ReleaseIOObjects(BYTE *pBuffer, USHORT objectSize);
	void ReleaseAllIOObjects(void);
private:	// Singleton
	CIOMemManager();
	CIOMemManager(const CIOMemManager&);
	CIOMemManager& operator=(const CIOMemManager&) {
		return *this;
	}
	;
	~CIOMemManager();
	static CIOMemManager *m_pInstance;
	static QMutex m_CreationMutex;
	BYTE *m_pHeapIOBuffer; ///< Pointer to the start of the Heap Buffer.
	BYTE *m_pCurrentData;  ///< Pointer to the start of the available buffer. 
	BYTE *m_pNextFreeAddress; ///< Pointer to the start of the buffer where data can be inserted.
	USHORT m_FreeSpace;			///< Amount of free space available in the buffer.
	USHORT m_IOBufferSize; ///< The total size of the BIP Buffer, allocated.
	USHORT m_CommittedMemSize; ///< Amount of used memory
};
#endif // _HEAPIOBUFFER_H

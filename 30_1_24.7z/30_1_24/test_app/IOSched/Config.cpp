//////////////////////////////////////////////////////////////////////
/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n CConfig.cpp
/// @n implementation of the abstract CConfig class.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 24	Stability Project 1.19.1.3	7/2/2011 4:56:13 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 23	Stability Project 1.19.1.2	7/1/2011 4:38:06 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 22	Stability Project 1.19.1.1	3/17/2011 3:20:16 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 21	Stability Project 1.19.1.0	2/15/2011 3:02:38 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////
#include "SetupConfiguration.h"
#include "V6defines.h"
#include "CMMDefines.h"
#include "V6Config.h"
#include "IOSetupConfig.h"
#include "PenSetupConfig.h"
#include "CardSlot.h"
#include "IOCard.h"
#include "Config.h"
#include "ConfigManager.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CConfig::CConfig() {
//	qDebug("Create new CConfig\n");
	m_pBrdInfoObj = NULL;
	m_pBrdStatsObj = NULL;
	m_pSlotMapObj = NULL;
	m_pCIOConfigManagerObj = NULL;
	m_pIOCard = NULL;
}
CConfig::~CConfig() {
//	qDebug("Deleting CConfig class\n");
}
//******************************************************
///
/// Schedule an upload of the I/O card serial number.
///
/// @return TRUE if successfully scheduled; otherwise FALSE
/// 
//******************************************************
BOOL CConfig::ScheduleSerialNoUpdate(void) {
	return (static_cast<class CIOCard*>(m_pIOCard))->ScheduleSerialNoUpdate();
}
//******************************************************
///
/// Schedule an upload of card info.
///
/// @return TRUE if successfully scheduled; otherwise FALSE
/// 
//******************************************************
BOOL CConfig::ScheduleUpdateCardInfo(void) {
	return (static_cast<class CIOCard*>(m_pIOCard))->ScheduleUpdateCardInfo();
}
//******************************************************
///
/// Schedule the IO board to enter run mode.
///
/// @param[in] runMode - TRUE if the IO board is to enter run mode; otherwise FALSE.
///
/// @return TRUE if successfully scheduled; otherwise FALSE
/// 
//******************************************************
BOOL CConfig::ScheduleIOBoardRunMode(BOOL runMode) {
	return (static_cast<class CIOCard*>(m_pIOCard))->ScheduleIOBoardRunMode(runMode);
}
//******************************************************
///
/// Schedule a download of special AI RT channel calibration info.
///
/// @return TRUE if successfully scheduled; otherwise FALSE
/// 
//******************************************************
BOOL CConfig::ScheduleRTChanCal(void) {
	return (static_cast<class CIOCard*>(m_pIOCard))->ScheduleRTChanCal();
}
//******************************************************
///
/// Schedule a upload of factory Cal points for selected channels.
///
/// @return TRUE if successfully scheduled; otherwise FALSE
/// 
//******************************************************
BOOL CConfig::ScheduleTestStatusUpdate(void) {
	return (static_cast<class CIOCard*>(m_pIOCard))->ScheduleTestStatusUpdate();
}
//******************************************************
///
/// Schedule a .
///
/// @return TRUE if successfully scheduled; otherwise FALSE
/// 
//******************************************************
BOOL CConfig::SetAcquireModeActiveState(const BOOL activeState) {
	BOOL retValue = FALSE;
	if (m_pIOCard != NULL) {
		(static_cast<class CIOCard*>(m_pIOCard))->SetAcquireModeActiveState(activeState);
		retValue = TRUE;
	}
	return retValue;
}
//**********************************************************************
///
/// Initialises the I/O board configuration.
///
/// @return		TRUE if the load is successful; otherwise FALSE
//**********************************************************************
BOOL CConfig::InitialiseConfig(void) {
	// Get a handle on board info and stats
	m_pBrdInfoObj = CBrdInfo::GetHandle();
	m_pBrdStatsObj = CBrdStats::GetHandle();
	m_pSlotMapObj = CSlotMap::GetHandle();
	m_pCIOConfigManagerObj = CIOConfigManager::GetHandle();
	if ((m_pBrdInfoObj == NULL) || (m_pBrdStatsObj == NULL) || (m_pSlotMapObj == NULL)
			|| (m_pCIOConfigManagerObj == NULL))
		return FALSE;
	return TRUE;
}

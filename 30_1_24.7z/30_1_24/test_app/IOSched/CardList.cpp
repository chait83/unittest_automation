/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n CardList.cpp
/// @n implementation for the CCardList class.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 18-09-15	Rajanbabu M			Called SetSecondaryProcFWVersion() method to update secondary firmware version dynamically
// 149 Stability Project 1.144.1.3	7/2/2011 4:55:53 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 148 Stability Project 1.144.1.2	7/1/2011 4:38:01 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 147 Stability Project 1.144.1.1	3/17/2011 3:20:12 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 146 Stability Project 1.144.1.0	2/15/2011 3:02:21 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////
#include "ATECal.h"
#include "BoardManager.h"
#include "IOCardInfo.h"
#include "IOCardStats.h"
#include "BrdStats.h"
#include "BrdInfo.h"
#include "V6IOBoardTypes.H"
#include "IOHandler.h"
#include "IOCardHandler.h"
#include "CardList.h"
#include "LinearTable.h"
#include "Device.h"
#include "DeviceManager.h"
#include "FFConversionInfo.h"
#include "InputConditioning.h"
#include "CardSlot.h"
#include "IOCard.h"
#include "AICard.h"
#include "AO_Card.h"
#include "DigPulseCard.h"
#include "PowerRelay.h"
#include "BaseProtocol.h"
#include "DevCaps.h"
#include "V6globals.h"
#include "Conversion.h"
#include "PPL.h"
#include "Timer.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
/// Digital bit status
#define DATA_READY_SLOT_G	4
#define DATA_READY_SLOT_H	2
#define DATA_READY_SLOT_I	1
#define DIG_DATA_READY (DATA_READY_SLOT_G | DATA_READY_SLOT_H | DATA_READY_SLOT_I)
#define MIN_WAIT_TIME 8			// 8mS delay only - works with 3 cards @ 50Hz (once)
#define MAX_WAIT_TIME 500 		// 500mS maximum delay
#define POWER_BOARD_VIRTUAL_SLOT	9		///< Virtual slot for the power board
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CCardList::CCardList() {
	UCHAR serviceNo = 0;
//	qDebug("Create new CCardList\n");
	m_pInterrogateBoard = NULL;
	// Get a handle on board info and stats
	m_pBrdInfoObj = CBrdInfo::GetHandle();
	m_pBrdStatsObj = CBrdStats::GetHandle();
//	m_pDevAbs = CDeviceAbstraction::GetHandle();
	m_pAPreProcQ = CPPQManager::GetHandle();	//MarkD
	m_DigitalLastSyncedSystemTick = 0L;
	m_LastSystemTick = 0L;
	// No boards identified yet
	m_NoOfAICards = 0;
	m_NoOfDigPulseCards = 0;
	m_NoOfAOCards = 0;
	// Only the bottom slots have data ready lines
	m_DataReadyIOCard[RECORDER_SLOT_G] = DATA_READY_SLOT_G;
	m_DataReadyIOCard[RECORDER_SLOT_H] = DATA_READY_SLOT_H;
	m_DataReadyIOCard[RECORDER_SLOT_I] = DATA_READY_SLOT_I;
	// Default all card slots to empty
	for (serviceNo = 0; serviceNo < MAX_SCHED_SERVICES; serviceNo++) {
		m_pIOCard[serviceNo] = NULL;
		m_scheduledAcqRqd[serviceNo] = FALSE;	// Default to no scheduled acqusition
	}
	// No board to service yet found
	m_PriorityService.BoardID = BOARD_INVALID;
	m_PriorityService.Found = FALSE;
}
CCardList::~CCardList() {
	USHORT slotNo;
//	qDebug("Delete CCardList class\n");
	// Remove the transaction manager
	if (m_pTransMngr != NULL) {
		delete m_pTransMngr;
		m_pTransMngr = NULL;
	}
	// Remove each I/O card
	for (slotNo = 0; slotNo < MAX_SCHED_SERVICES; slotNo++) {
		if (m_pIOCard[slotNo] != NULL) {
			delete m_pIOCard[slotNo];
			m_pIOCard[slotNo] = NULL;
		}
	}
}
//******************************************************
// Initialise()
///
/// Runs the factory to create concrete board type.
///
/// @return TRUE if card have been succesfully identified; otherwise FALSE
/// 
//******************************************************
BOOL CCardList::InitialiseCardList(void) {
	USHORT slotNo;
	BOOL retValue = TRUE;
	if (m_pBrdStatsObj == NULL) {
		// Unable to get handle/create board stats
		retValue = FALSE;
	}
	if (m_pBrdInfoObj == NULL) {
		// Unable to get handle/create board info
		retValue = FALSE;
	}
	// Create BaseProtocol for card factory
	m_pInterrogateBoard = new class CBaseProtocol;
	if (m_pInterrogateBoard == NULL) {
		// Unable to create card factory
		LogInternalError("Unable to create card factory");
		retValue = FALSE;
	} else if (retValue == TRUE) {
		// Note: if running on a PC in test equipment mode, then the UUT must be previously initialsed in command mode
		retValue = m_pInterrogateBoard->InitialiseProtocol();
		//Get the Secondary Version here. If the version not returned properly. Possible Secondary Firmware Corruption.
		if (!pDALGLB->IsRecorderEzTrend()) {
			int secFWVer = m_pInterrogateBoard->GetSecondaryFwVersion();
			pDALGLB->SetSecondaryProcFWVersion(secFWVer);
		}
		// Use factory to create concrete board types, if on recorder or auxilarily command mode entered.
		if (retValue == TRUE) {
			retValue = CardFactory();
			// Initialiase each board after creation
			for (slotNo = 0; slotNo < MAXIOCARDS; slotNo++) {
				if (m_pIOCard[slotNo] != NULL) {
					m_pIOCard[slotNo]->RegisterCard(slotNo);
				}
			}
			CleanUpFactory();
		}
	}
	return retValue;
}
//******************************************************
// IOCardCommand()
///
/// Sends a user command to the I/O boards.
/// @param[in] cardNo - Card number identification.
/// @param[in] newCmd - I/O board command.
///
/// @return IOCARDSTAT (IOSTAT_CMDOK) if successful otherwise IOCARDSTAT fail code 
/// 
//******************************************************
IOCARDSTAT CCardList::IOCardCommand(const USHORT cardNo, const USHORT newCmd) {
	IOCARDSTAT retValue = IOSTAT_CMDOK;
//	if( m_pIOCard[cardNo] != NULL )
//		retValue = m_pIOCard[cardNo]->IOCardCommand( newCmd );
	return retValue;
}
//******************************************************
///
/// Removes I/O card from card list (Test equipment use only).
/// @param[in] cardNo - Card number identification.
///
//******************************************************
void CCardList::CleanUpIOCard(const USHORT cardNo) {
	if (m_pIOCard[cardNo] != NULL) {
		// Remove all the channels associated with card
		m_pIOCard[cardNo]->m_ChanList.DestroyChannels();
		// Now remove any I/O board handler
		if ((m_pIOCard[cardNo]->GetBoardType() == BOARD_DIO) || (m_pIOCard[cardNo]->GetBoardType() == BOARD_AR)) {
			static_cast<CDigPulseCard*>(m_pIOCard[cardNo])->SetupConfigChangePreparation();
		}
		DefaultIOCardHolders(cardNo);
		// Remove the I/O card
		delete m_pIOCard[cardNo];
		m_pIOCard[cardNo] = NULL;
	}
}
//******************************************************
///
/// Removes I/O card from card list (Test equipment use only).
/// @param[in] cardNo - Card number identification.
///
//******************************************************
BOOL CCardList::DefaultIOCardHolders(const USHORT cardNo) {
	BOOL retValue = TRUE;
	if (m_pIOCard[cardNo] != NULL) {
		if ((m_pIOCard[cardNo]->GetBoardType() == BOARD_AI) || (m_pIOCard[cardNo]->GetBoardType() == BOARD_EZ_AI)) {
			// Reset the AI I/O card specific holders (as required)
			retValue = static_cast<CAICard*>(m_pIOCard[cardNo])->ResetAICardDataItems();
		} else if (m_pIOCard[cardNo]->GetBoardType() == BOARD_PI) {
			// Reset the pulse I/O card specific holders (as required)
			static_cast<CDigPulseCard*>(m_pIOCard[cardNo])->ResetPulseDITValues();
		} else if ((m_pIOCard[cardNo]->GetBoardType() == BOARD_DIO)
				|| (m_pIOCard[cardNo]->GetBoardType() == BOARD_AR)) {
			// Reset the digital I/O card specific holders (as required)
			static_cast<CDigPulseCard*>(m_pIOCard[cardNo])->ResetDigPulseCardDataItems();
		}
	}
	return retValue;
}
//**********************************************************************
/// Sets all services on a setup commit change preperation
///
/// @return TRUE on successful commit; otherwise FALSE
/// 
//**********************************************************************
BOOL CCardList::SetupConfigChangePreparation(void) {
	class CChanList *pChanList = NULL;
	BOOL retValue = TRUE;
	UCHAR cardNo;
	for (cardNo = 0; cardNo < MAX_SCHED_SERVICES; cardNo++) {
		// Prepare each channel on an I/O board for setup change
		if (m_pIOCard[cardNo] != NULL) {
			pChanList = m_pIOCard[cardNo]->GetChanSchedule();
			pChanList->SetupConfigChangePreparation();
			if ((m_pIOCard[cardNo]->GetBoardType() == BOARD_DIO) || (m_pIOCard[cardNo]->GetBoardType() == BOARD_AR)) {
				// Prepare the digital/AR board for setup change
				retValue = static_cast<CDigPulseCard*>(m_pIOCard[cardNo])->SetupConfigChangePreparation();
			} else if (m_pIOCard[cardNo]->GetBoardType() == BOARD_POWER_RELAY) {
				// Prepare the power relay for setup change
				retValue = static_cast<CPowerRelay*>(m_pIOCard[cardNo])->SetupConfigChangePreparation();
			} else if ((m_pIOCard[cardNo]->GetBoardType() == BOARD_AI)
					|| (m_pIOCard[cardNo]->GetBoardType() == BOARD_EZ_AI)) {
				// Prepare the AI card for setup change
				retValue = static_cast<CAICard*>(m_pIOCard[cardNo])->SetupConfigChangePreparation();
			}
		}
	}
	return retValue;
}
//******************************************************
///
/// Removes all values I/O cards from card list
///
//******************************************************
BOOL CCardList::DefaultAllIOCardHolders(void) {
	BOOL retValue = FALSE;
	USHORT cardNo;
	for (cardNo = 0; cardNo < MAX_SCHED_SERVICES; cardNo++) {
		retValue |= DefaultIOCardHolders(cardNo);
	}
	return retValue;
}
//******************************************************
///
/// Removes all I/O cards from card list (Test equipment use only).
///
//******************************************************
void CCardList::CleanUpAllIOCards(void) {
	USHORT cardNo;
	for (cardNo = 0; cardNo < MAX_SCHED_SERVICES; cardNo++) {
		CleanUpIOCard(cardNo);
	}
}
//******************************************************
// AnyDigitalsRqrService()
///
/// Test whether any digital boards require service.
///
/// @return TRUE if one or more cards require processing;
///			otherwise FALSE
/// 
//******************************************************
BOOL CCardList::AnyDigitalsRqrService(void) {
	m_DigCrdProcState = pDALGLB->SPIGetDigitalCardStatus();
	if ( pDALGLB->IsRecorderEzTrend()) {
		m_DigCrdProcState ^= (DATA_READY_SLOT_G);	///< Active low, so invert
	} else {
		m_DigCrdProcState ^= (DIG_DATA_READY);	///< Active low, so invert
	}
	if (m_DigCrdProcState != 0)
		return TRUE;
	return FALSE;
}
//******************************************************
// AllCardSchedule()
///
/// Checks for the card that is most in need of servicing.
///
/// @return TRUE if card has been scheduled; otherwise FALSE
/// 
//******************************************************
BOOL CCardList::AllCardSchedule(void) {
	USHORT slotNo;
	USHORT highestNoActiveChannel = 0;
	UCHAR boardType;
	// No board to service yet found
	m_PriorityService.Found = FALSE;
	// Check all boards for service required; updates 
	for (slotNo = 0; slotNo < MAXIOCARDS; slotNo++) {
		if (m_pIOCard[slotNo] != NULL) {
//			m_PriorityService.Found = TRUE;
			boardType = m_pIOCard[slotNo]->WhatBoardType();
			if ((boardType == BOARD_DIO) || (boardType == BOARD_AR)) {
				m_scheduledAcqRqd[slotNo] =
						((static_cast<class CDigPulseCard*>(m_pIOCard[slotNo]))->HighestPIChannelEnabled(
								highestNoActiveChannel));
			}
		}
		CheckCardSchedule(slotNo);
	}
	// If no board to schedule then use minimum wait time
	if ((m_PriorityService.Found == FALSE) || (m_PriorityService.TimeCount < MIN_WAIT_TIME))
		m_PriorityService.TimeCount = MIN_WAIT_TIME;
	// Make sure I/O boards with really slow updates don't slow the system down
	if (m_PriorityService.TimeCount > MAX_WAIT_TIME)
		m_PriorityService.TimeCount = MIN_WAIT_TIME;
	// Make sure that calibration mode has plenty of time to update screen
	if (m_pBrdStatsObj->HasLimitedRunModeBeenOrdered() == TRUE)
		m_PriorityService.TimeCount = MAX_WAIT_TIME;
	return m_PriorityService.Found;
}
//******************************************************
// CardSchedule()
///
/// Schedules whether a timed poll is required.
/// @param[in] slotNo - Card slot number identification.
///
/// @return TRUE if card has been scheduled; otherwise FALSE
/// 
//******************************************************
BOOL CCardList::CardSchedule(const USHORT slotNo) {
	BOOL retValue = TRUE;
	USHORT highestNoActiveChannel = 0;
	UCHAR boardType;
	if (m_pIOCard[slotNo] != NULL) {
		boardType = m_pIOCard[slotNo]->WhatBoardType();
		if ((boardType == BOARD_DIO) || (boardType == BOARD_AR)) {
			m_scheduledAcqRqd[slotNo] =
					((static_cast<class CDigPulseCard*>(m_pIOCard[slotNo]))->HighestPIChannelEnabled(
							highestNoActiveChannel));
		}
	}
	return retValue;
}
//******************************************************
// GetCardScheduleTime()
///
/// Checks for the card that is most in need of servicing.
/// @param[out] pTimeCount - The time that the scheduler can wait for.
/// @param[out] pBoardID - Card slot number identification	if scheduled card found.
///
/// @return TRUE if card has been scheduled; otherwise FALSE
/// 
//******************************************************
BOOL CCardList::GetCardScheduleTime(LONGLONG *pTimeCount, USHORT *pBoardID) {
	BOOL retValue = FALSE;
	retValue = AllCardSchedule();
	*pTimeCount = m_PriorityService.TimeCount;
	if (retValue == TRUE)
		*pBoardID = m_PriorityService.BoardID;
	return retValue;
}
//******************************************************
// GetChanSchedule()
///
/// Gets an IO card channel schedule list.
/// @param[in] cardNo - Card slot number identification.
///
/// @return Channel list.
/// 
//******************************************************
class CChanList* CCardList::GetChanSchedule(const USHORT cardNo) {
	if (m_pIOCard[cardNo] != NULL)
		return m_pIOCard[cardNo]->GetChanSchedule();
	return NULL;
}
//******************************************************
///
/// Schedule the I/O Card batch information to be reset.
/// @param[in] cardNo - Card slot number identification.
///
/// @return TRUE if successfully scheduled; otherwise FALSE
///
/// @Note: This method can only be used when not in continuous run mode, otherwise data queues
///		will be misalligned due to the PPQ implementation.
//******************************************************
BOOL CCardList::ScheduleClearBatchedData(const USHORT cardNo) {
	if (m_pIOCard[cardNo] != NULL)
		return static_cast<class CIOCard*>(m_pIOCard[cardNo])->ScheduleClearBatchedData();
	return FALSE;
}
//******************************************************
// CheckCardSchedule()
///
/// Checks whether the card is the one most in need of servicing.
/// @param[in] cardNo - Card slot number identification.
///
/// @return TRUE if card has been found; otherwise FALSE
/// 
//******************************************************
BOOL CCardList::CheckCardSchedule(const USHORT cardNo) {
	// No board to service yet found
	m_PriorityService.Found = FALSE;
	// If it is the first populated card slot
	if ((m_PriorityService.Found == FALSE) && (m_pIOCard[cardNo] != NULL)
			&& (m_pIOCard[cardNo]->DoesBoardRqSched() == TRUE)) {
		// Then this must be currently the first requiring service
		m_PriorityService.Found = TRUE;
		m_PriorityService.TimeCount = m_pIOCard[cardNo]->GetTimeServiceRqd();
		m_PriorityService.BoardID = cardNo;
	} else if ((m_pIOCard[cardNo] != NULL) && (m_pIOCard[cardNo]->DoesBoardRqSched() == TRUE)) {
		// Check whether the current card is more needy
		if (m_pIOCard[cardNo]->GetTimeServiceRqd() < m_PriorityService.TimeCount) {
			// Current card is more needy
			m_PriorityService.TimeCount = m_pIOCard[cardNo]->GetTimeServiceRqd();
			m_PriorityService.BoardID = cardNo;
		}
	}
	return m_PriorityService.Found;
}
//******************************************************
// CheckScheduledService()
///
/// Checkes whether a scheduled service is changing state.
/// @param[in] cardNo - Card slot number identification.
///
/// @return TRUE if all OK; otherwise FALSE
/// 
//******************************************************
BOOL CCardList::CheckScheduledService(LONGLONG thisSystemTick) {
	BOOL retValue = TRUE;
	USHORT slotNo;
	class CBrdInfo *pBrdInfoObj = NULL;
	class CAICard *pAICard = NULL;
	WCHAR boardSlotStr[4];
	class CSlotMap *pSlotMap = NULL;
	char errStr[100];
	memset(errStr, 0, 100);
	// Give the RT input 3 seconds from startup before raising an error for a specific channel
	// if there has been no RT cal or RT comp change flag raised and either a resistance channel or RT is is being measured
	pSlotMap = CSlotMap::GetHandle();
	pBrdInfoObj = CBrdInfo::GetHandle();
	for (slotNo = 0; slotNo < MAXIOCARDS; slotNo++) {
		if (pSlotMap != NULL)
			pSlotMap->GetSlotStrID(slotNo, boardSlotStr);
		if ((pBrdInfoObj->WhatBoardType(slotNo) == BOARD_AI) || (pBrdInfoObj->WhatBoardType(slotNo) == BOARD_EZ_AI)) {
			if (m_DigitalLastSyncedSystemTick == 0) {
				// First time run; so set start time
				m_DigitalLastSyncedSystemTick = thisSystemTick;
			}
			// Check for time expired
			pAICard = static_cast<class CAICard*>(m_pIOCard[slotNo]);
			if (pAICard->CheckLastRTCompReadTime(thisSystemTick) == TRUE) {
				// Problem with no RT comp available
				sprintf(errStr, "I/O board %w : Startup RT comp failure", boardSlotStr);
				LogInternalError(errStr.toLocal8Bit().data());
			}
			if (pAICard->CheckLastRTCalReadTime(thisSystemTick) == TRUE) {
				// Problem with no RT cal available
				sprintf(errStr, "I/O board %w : Startup RT cal failure", boardSlotStr);
				LogInternalError(errStr.toLocal8Bit().data());
			}
		}
	}
	return retValue;
}
//******************************************************
// IsDigitalInStatusUpdateRqd()
///
/// Checkes whether a digital input update status update is required.
/// @param[in] boardSlotID - Card slot number identification.
///
/// @return TRUE if all OK; otherwise FALSE
/// 
//******************************************************
BOOL CCardList::IsDigitalInStatusUpdateRqd( USHORT boardSlotID) {
	BOOL atLeastOneInputChannelEnabled = FALSE;
	USHORT highestNoActiveChannel = 0;
	UCHAR boardType;
	if ((IsRunningAsATEEquipment() == FALSE) && (m_pIOCard[boardSlotID] != NULL)) {
		boardType = m_pIOCard[boardSlotID]->WhatBoardType();
		if ((boardType == BOARD_DIO) || (boardType == BOARD_AR)) {
			atLeastOneInputChannelEnabled =
					(static_cast<class CDigPulseCard*>(m_pIOCard[boardSlotID])->HighestDIChannelEnabled(
							highestNoActiveChannel));
		}
	}
	return atLeastOneInputChannelEnabled;
}
// #define DIGITAL_RESYNC_TIME 60000		///< 10 minutes @ 100Hz tick rate
//const ULONG DIGITAL_RESYNC_TIME = 42000;			///< 7 minutes @ 100Hz tick rate
const ULONG DIGITAL_RESYNC_TIME = 6000;	///< 1 minute @ 100Hz tick rate (MarkD)
//******************************************************
// ActivatePriorityService()
///
/// Schedules the card most in need of servicing.
///
/// @return TRUE if card has been found; otherwise FALSE
/// 
//******************************************************
BOOL CCardList::ActivatePriorityService(void) {
	LONGLONG thisSystemTick = 0L;
	BOOL retValue = FALSE;
	BOOL resyncOK = FALSE;
	USHORT SlotNo;
	USHORT chanNo;
//	CTV6Timer ProcATimer(TIMER_HIGH_RES);		// Total time of Proc A run time slice
//	LONG ProcAtimetaken = 0;
//	LONG sleeptimetaken = 0;
//	HANDLE hMsgCompleted;			///< Event Handler to determine when destination module has copmleted message
//	DWORD waitSingleObjectResult = WAIT_OBJECT_0; ///< Result of the WaitForSingleObject function call
	thisSystemTick = pGlbSysTimer->GetCurrentSystemTimeTick100();
	if (m_LastSystemTick == 0) {
		// First time run
		m_LastSystemTick = thisSystemTick;
		//m_DigitalLastSyncedSystemTick = thisSystemTick;
		m_DigitalLastSyncedSystemTick = thisSystemTick - DIGITAL_RESYNC_TIME + 1000; // for early resync
	}
	// Check whether it is time for digital queue resync required
	if (thisSystemTick > m_DigitalLastSyncedSystemTick + DIGITAL_RESYNC_TIME) {
		SlotNo = RECORDER_SLOT_G;
		resyncOK = TRUE;	// Assume all is well until a failure is found
		do {
			if ((m_pIOCard[SlotNo] != NULL) && (m_pIOCard[SlotNo]->IsIOBoardInRunMode() == TRUE)) {
				// Only resync the slots that have an operational board
//				resyncOK = static_cast<class CIOCard *> (m_pIOCard[SlotNo])->ResyncService();
				resyncOK = static_cast<class CIOCard*>(m_pIOCard[SlotNo])->ScheduleCardQueueSyncOperation();
				if (resyncOK == TRUE)
					resyncOK = static_cast<class CIOCard*>(m_pIOCard[SlotNo])->RunProcess();
			}
			SlotNo++;
		} while ((resyncOK == TRUE) && (SlotNo <= RECORDER_SLOT_I));	// Try all slots unless 
		// there is a failure on one, in which case none will be resynced till next time
		retValue = resyncOK;
		// Register that all digital I/O cards have been been succesfully resynced
		if (retValue == TRUE)
			m_DigitalLastSyncedSystemTick = thisSystemTick;
	}
	AnyDigitalsRqrService();
	// Which lower card slot(s) have notified that they have data to return
	for (SlotNo = RECORDER_SLOT_G; SlotNo <= RECORDER_SLOT_I; SlotNo++) {
		if ((m_pIOCard[SlotNo] != NULL) && (m_pIOCard[SlotNo]->IsIOBoardInRunMode() == TRUE)) {
			if (((IsRunningAsATEEquipment() == TRUE) && (RECORDER_SLOT_G == SlotNo))
					|| ((m_DigCrdProcState & m_DataReadyIOCard[SlotNo]) > 0)) {
				if (static_cast<class CDigPulseCard*>(m_pIOCard[SlotNo])->HighestDIChannelEnabled(chanNo) == FALSE) {
					// If there are no inputs currently selected then the data ready line will indicate an error
					m_pIOCard[SlotNo]->ScheduleErrorDownload();
					static_cast<class CIOCard*>(m_pIOCard[SlotNo])->RunProcess();
				}
				// Data ready line can indicate either an error or data ready;
				// however a read input block will statisfy both.
				(static_cast<class CDigPulseCard*>(m_pIOCard[SlotNo])->UpdateLastDIReadService(thisSystemTick));
			} else if ((IsDigitalInStatusUpdateRqd(SlotNo) == TRUE)) {
				// After a while then update digital input coverage to confirm no new data.
				(static_cast<class CDigPulseCard*>(m_pIOCard[SlotNo])->UpdateLastDICoverageService(thisSystemTick,
						m_LastSystemTick, m_DigitalLastSyncedSystemTick));
			}
		}
	}
	// Check all top slots for scheduled cards
	for (SlotNo = RECORDER_SLOT_A; SlotNo < RECORDER_SLOT_G; SlotNo++) {
		if ((m_pIOCard[SlotNo] != NULL)) {
			if ((m_pIOCard[SlotNo]->HasIdleModeBeenOrdered() == FALSE)) {
				m_pIOCard[SlotNo]->RunProcess();
			}
		}
	}
	// Now check all bottom slots for digital cards that require scheduled acqusition (pulse in channels enabled)
	for (SlotNo = RECORDER_SLOT_G; SlotNo <= RECORDER_SLOT_I; SlotNo++) {
		if ((m_pIOCard[SlotNo] != NULL) && (m_pIOCard[SlotNo]->IsIOBoardInRunMode() == TRUE)) {
			if (IsRunningAsATEEquipment() == TRUE) {
				if (m_scheduledAcqRqd[SlotNo] == TRUE) {
					m_pIOCard[SlotNo]->RunProcess();
				}
			} else {
				m_pIOCard[SlotNo]->RunProcess();
			}
		}
	}
	if (m_pBrdStatsObj->HasIdleModeBeenOrdered() == FALSE) {
		// Update the power relay board if fitted
		if (m_pIOCard[POWER_BOARD_VIRTUAL_SLOT] != NULL) {
			m_pIOCard[POWER_BOARD_VIRTUAL_SLOT]->RunProcess();
		}
	}
	// Use time at the start of this routine, as the last certain time readings were valid for
	m_LastSystemTick = thisSystemTick;
	if (m_pBrdStatsObj->HasIdleModeBeenOrdered() == FALSE) {
		// Check for any I/O card timeouts
		CheckScheduledService(thisSystemTick);
	}
	return retValue;
}
//******************************************************
// SetGlobalChannelID()
///
/// Sets the global system system known channel number.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] channelNo - Card slot channel number.
///
/// @return TRUE if the global channel number is succesfully set; otherwise FALSE
/// 
//******************************************************
BOOL CCardList::SetGlobalChannelID(const USHORT cardNo, const USHORT channelNo, const USHORT glbChannelNo) {
	if (m_pIOCard[cardNo] != NULL)
		return m_pIOCard[cardNo]->SetGlobalChannelID(channelNo, glbChannelNo);
	return FALSE;
}
//******************************************************
// AddCardToSchedule()
///
/// Adds an IO card to the processing list.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] pCard - The concrete board type to add.
///
/// @return TRUE is card is added; otherwise FALSE.
/// 
//******************************************************
BOOL CCardList::AddCardToSchedule(const USHORT cardNo, class CCardSlot *const pCard) {
	m_pIOCard[cardNo] = pCard;
	return pCard->RegisterCard(cardNo);
}
//******************************************************
// AddAICardToSchedule()
///
/// Adds an IO card to the processing list.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] pCard - The concrete board type to add.
///
/// @return TRUE is card is added; otherwise FALSE.
/// 
//******************************************************
BOOL CCardList::AddAICardToSchedule(const USHORT cardNo, class CAICard *const pCard) {
	m_pIOCard[cardNo] = static_cast<class CCardSlot*>(pCard);
	return pCard->RegisterCard(cardNo);
}
//******************************************************
// AddAOCardToSchedule()
///
/// Adds an IO card to the processing list.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] pCard - The concrete board type to add.
///
/// @return TRUE is card is added; otherwise FALSE.
/// 
//******************************************************
BOOL CCardList::AddAOCardToSchedule(const USHORT cardNo, CAOCard *const pCard) {
	m_pIOCard[cardNo] = static_cast<CCardSlot*>(pCard);
	return pCard->RegisterCard(cardNo);
}
//******************************************************
// AddDigPulseCardToSchedule()
///
/// Adds an IO card to the processing list.
/// @param[in] cardNo - Card slot number identification.
/// @param[in] pCard - The concrete board type to add.
///
/// @return TRUE is card is added; otherwise FALSE.
/// 
//******************************************************
BOOL CCardList::AddDigPulseCardToSchedule(const USHORT cardNo, class CDigPulseCard *const pCard) {
//	m_pDigPulseCard[m_NoOfDigPulseCards] = pCard;
	m_SlotPosition[cardNo] = m_NoOfDigPulseCards;
	m_NoOfDigPulseCards++;
	m_pIOCard[cardNo] = static_cast<class CCardSlot*>(pCard);
	return pCard->RegisterCard(cardNo);
}
//******************************************************
// GetCardReference()
///
/// Gets an IO card reference from the processing list.
/// @param[in] cardNo - Card slot number identification.
///
/// @return he concrete board reference.
/// 
//******************************************************
class CCardSlot* CCardList::GetCardReference(const USHORT cardNo) {
	return m_pIOCard[cardNo];
}
//******************************************************
// AnyCardBeingProcessed()
///
/// Retrieves the current processing state of all IO cards.
///
/// @return TRUE if any card is currently being processed;
/// otherwise FALSE if no card currently being processed.
/// 
//******************************************************
BOOL CCardList::AnyCardBeingProcessed(void) {
	// Check all boards in list, for any that are being processed, or have requested service
	return m_pTransMngr->IsTransMangBusy();
}
//******************************************************
// QueryBoardConfig()
///
/// Queries the configuration on a board and populates board information object.
/// @param[in] cardNo - Card instance number.
///
/// @return TRUE if board config is identified and matches local config; otherwise FALSE.
/// 
//******************************************************
BOOL CCardList::QueryBoardConfig(const USHORT cardNo) {
	BOOL retValue = FALSE;
	UCHAR boardType;
	class CIOCard *pIOCard = NULL;
	class CSlotMap *pSlotMap = NULL;
	pSlotMap = CSlotMap::GetHandle();
	pIOCard = static_cast<class CIOCard*>(m_pIOCard[cardNo]);
	boardType = pIOCard->GetBoardType();
	if (pSlotMap->IsBoardIOTypeLegal(boardType) == TRUE) {
		// Dowload the local configuration from the I/O board
		// Create the local configuration
//		retValue = pIOCard->CMMCreateLocalConfig();
		// The local configuration and that stored on the I/O boards should match
		if (retValue == TRUE)
			retValue = IsCMMConfigValid(cardNo);
	} else if (boardType == BOARD_POWER_RELAY) {
		// @todo: Test CRC held in memory only
		retValue = TRUE;
	}
	return retValue;
}
//******************************************************
// QueryBoardType()
///
/// Queries a board and populates board information object.
/// @param[in] cardNo - Card instance number.
///
/// @return TRUE if board is identified; otherwise FALSE.
/// 
//******************************************************
BOOL CCardList::QueryBoardType(const USHORT cardNo) {
	BOOL retValue = FALSE;
	if (m_pInterrogateBoard->SelectSlot(static_cast<UCHAR>(cardNo)) == FALSE)
		retValue = FALSE;
	if (retValue == TRUE)
		retValue = m_pInterrogateBoard->GetBoardType( TRUE);
	m_pInterrogateBoard->DeselectAllBoards();
	// Check that the board found is a valid and supported type
	if ((m_pBrdInfoObj->WhatBoardType(cardNo) > BOARD_NOT_YET15))
		retValue = FALSE;
	return retValue;
}
//******************************************************
// SetSpecialTestMode()
///
/// Sets the special test mode were boards hidden functionality are made visible.
/// @param[in] cardNo - Card instance number.
/// @param[in] state - Whether special test mode is enabled or disabled.
///
/// @return TRUE if the I/O board has a special test mode; otherwise FALSE.
/// 
//******************************************************
BOOL CCardList::SetSpecialTestMode(const USHORT cardNo, const BOOL state) {
	if (m_pIOCard[cardNo] != NULL)
		return m_pIOCard[cardNo]->SetSpecialTestMode(state);
	return FALSE;
}
//******************************************************
// ATECalUpdateConfig()
///
/// Upload the CMM configuartion to a single I/O board.
/// This method should be used after a board calibration; were it is not needed to test all boards
///
/// @return TRUE if the I/O board CMM configuration is uploaded; otherwise FALSE.
/// 
/// @note: Should only be used in calibration mode
//******************************************************
BOOL CCardList::ATECalUpdateConfig(void) {
	class CATECal *pATECalStruct = NULL;
	BOOL retValue = TRUE;
	pATECalStruct = CATECal::GetHandle();
	if (pATECalStruct != NULL) {
		retValue = pATECalStruct->CommitIOATECalStruct();
	}
	return retValue;
}
//******************************************************
// ATECalDownloadConfig()
///
/// Upload the CMM configuartion to a single I/O board.
/// This method should be used after a board calibration; were it is not needed to test all boards
///
/// @return TRUE if the I/O board CMM configuration is uploaded; otherwise FALSE.
/// 
/// @note: Should only be used in calibration mode
//******************************************************
BOOL CCardList::ATECalDownloadConfig(void) {
	UCHAR cardNo;
	class CATECal *pATECalStruct = NULL;
	BOOL retValue = TRUE;
	pATECalStruct = CATECal::GetHandle();
if( pATECalStruct != NULL )
{
	cardNo = pATECalStruct->QueryATECardNo();
	if( (cardNo != ILLEGAL_CARD_SELECTED) && (pATECalStruct->IsSetupDownloadable() == TRURU

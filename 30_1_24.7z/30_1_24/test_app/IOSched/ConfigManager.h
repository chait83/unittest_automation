/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n ConfigManager.h
/// @n interface for the CConfigManager class.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 18	Stability Project 1.15.1.1	7/2/2011 4:56:16 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 17	Stability Project 1.15.1.0	7/1/2011 4:27:09 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 16	V6 Firmware 1.15		7/20/2005 7:45:52 PM	Graham Waterfield
//		Debugging of CMM issues for digitals/pulse
//		(Still not fully resolved)
// 15	V6 Firmware 1.14		7/15/2005 6:16:47 PM	Graham Waterfield
//		Recorder optimisation
// $
//
//////////////////////////////////////////////////////////////////////
#if !defined(AFX_CONFIGMANAGER_H__7183B928_7F0B_4A3E_B59F_D66BE1885837__INCLUDED_)
#define AFX_CONFIGMANAGER_H__7183B928_7F0B_4A3E_B59F_D66BE1885837__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "CardList.h"
#include "PassiveModule.h" 
#include "Defines.h"
typedef struct _configmanager {
	UCHAR ConfigType;		///< Derived class position of each slot position
	UCHAR SlotPosition;		///< Derived class position of each slot position
} T_CONFIGMANAGER, *T_PCONFIGMANAGER;
class CIOConfigManager: public CPassiveModule {
public:		//Singleton 
	static CIOConfigManager* GetHandle();
	void CleanUp();
	class CAIConfig* CreateAILocalConfigHolder(const USHORT slotNo);
	class CDigConfig* CreateDigLocalConfig(const USHORT slotNo);
	class CAOConfig* CreateAOLocalConfig(const USHORT slotNo);
	class CAIConfig* GetAILocalConfig(const USHORT slotNo) const;
	class CAOConfig* GetAOLocalConfig(const USHORT slotNo) const;
	class CDigConfig* GetDigLocalConfig(const USHORT slotNo) const;
	class CConfig* GetCommonLocalConfig(const USHORT slotNo) const;
	// Configure local setup
	BOOL SelectAIChanAcqRate(const USHORT sysChannelNo, const USHORT Rate);
	BOOL SelectAIChanVoltageRange(const USHORT sysChannelNo, const USHORT Range);
	BOOL SelectAIChanCurrentRange(const USHORT sysChannelNo, const USHORT Range);
	BOOL SelectAIChanResistanceRange(const USHORT sysChannelNo, const USHORT Range);
	BOOL SelectAIChanTCRange(const USHORT sysChannelNo, const USHORT Range);
	BOOL SelectAIChanRTRange(const USHORT sysChannelNo, const USHORT Range);
	BOOL CMMCreateLocalConfig(const USHORT slotNo);
	BOOL InitialiseConfigManager(void);
	BOOL InitialiseCardConfig(class CCardSlot *const pCard);
private:	// Singleton
	CIOConfigManager();
	CIOConfigManager(const CIOConfigManager&);
	CIOConfigManager& operator=(const CIOConfigManager&) {
		return *this;
	}
	;
	~CIOConfigManager();
	/// Data for card stats and info
	class CBrdInfo *m_pBrdInfoObj;			///< Board info holder
	class CBrdStats *m_pBrdStatsObj;		///< Board stats holder
	class CSlotMap *m_pSlotMapObj;			///< Slot map holder
	// Singleton handlers
	static CIOConfigManager *m_pInstance;
	static QMutex m_CreationMutex;
	// Derived class to accomodate fundamental differences in channel operation and card type count
	class CAIConfig *m_pAIConfig[MAX_SCHED_SERVICES];			///< Holder for AI board config
	class CAOConfig *m_pAOConfig[MAX_SCHED_SERVICES];			///< Holder for AO board config
	class CDigConfig *m_pDigConfig[MAX_SCHED_SERVICES];	///< Holder for Digital/Pulse board config
	UCHAR m_NoOfAICards;								///< AI board count
	UCHAR m_NoOfDigPulseCards;					///< Digital & pulse board count
	UCHAR m_NoOfAOCards;								///< AO board count
	// Base class I/O board config holder for rapid common schedule query
	class CConfig *m_pCardConfig[MAX_SCHED_SERVICES];
	T_CONFIGMANAGER m_Config[MAX_SCHED_SERVICES];						///< Derived class manager of each slot position
};
#endif // !defined(AFX_CONFIGMANAGER_H__7183B928_7F0B_4A3E_B59F_D66BE1885837__INCLUDED_)

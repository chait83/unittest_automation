/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	I/O Scheduler
/// @n Filename: Protocol.h
/// @n Desc:	interface of the CProtocol class 
///
// 
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//	28-07-17	Shankar Rao		Added Sub Error Code detection to process error data patterns and identify detailed errors in IO
// 39	Stability Project 1.36.1.1	7/2/2011 4:59:58 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 38	Stability Project 1.36.1.0	7/1/2011 4:27:05 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 37	V6 Firmware 1.36		10/20/2006 7:47:42 PM Graham Waterfield
//		Improve error reports, test CRC befor function ID# failure and ensure
//		that 6 byte error messages are always processed as such and not valid
//		data returns
// 36	V6 Firmware 1.35		10/10/2006 3:32:50 PM Graham Waterfield
//		Allow eZtrend to user calibrate channels and prevent startup RT &
//		ohms spikes using the third major method tried.
// $
//
//////////////////////////////////////////////////////////////////////
#ifndef _PROTOCOL_H
#define _PROTOCOL_H
#if !defined(AFX_PROTOCOL_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_)
#define AFX_PROTOCOL_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_
#include "Defines.h"
#include "BaseProtocol.h"
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#define ALL_EIGHT_CHANNELS					0xff		///< All eight channels selected
// Active burnout status (status code)
#define ABS_DISABLED						0x0			///< Active burnout disabled
#define ABS_TC_OK							0x1			///< Active burnout enabled, input OK
#define ABS_TC_DEGRADED						0x2			///< Thermocouple Degraded (difference measurement: about 10 ohms to 99 ohms increase)
#define ABS_TC_FAILING_DIFF					0x3			///< Thermocouple Failing (difference measurement: about 100 ohms to 200 ohms increase)
#define ABS_TC_ALMOST_FAILED_DIFF			0x4			///< Thermocouple Almost Failed (difference measurement: over 200 ohms, not failed)
#define ABS_TC_FAILING						0x5			///< Thermocouple Failing (absolute measurement: over about 230 ohms)
#define ABS_TC_ALMOST_FAILED				0x6			///< Thermocouple Almost Failed (absolute measurement: about 330 ohms to 2k ohms)
#define ABS_TC_FAILED_NO_DATA				0x7			///< Thermocouple Failed (ADC input 0xffff) (no data on passive channel)
#define ABS_TC_FAILED_ACTIVE_ONLY			0x8			///< Thermocouple Failed, but no error on passive thermocouple channel
#define ABS_TC_FAILED_PASSIVE_AND_ACTIVE	0x9			///< Thermocouple Failed, also failed status on passive channel
#define ABS_TC_SC_DETECTED					0x0a		///< Possible thermocouple wiring short circuit detected (significant reduction in ohms)
//**Class*********************************************************************
///
/// @brief Manage communications protocol to and from I/O boards
/// 
/// This class handles the board specific commands to and from I/O boards
///
/// This class inherits from the core protocol message class
///
//****************************************************************************
class CProtocol: public CBaseProtocol {
public:
	// Process returns from board commands
	BOOL ProcessAIReadingsReturn(UCHAR *pData, const USHORT timestampInterval,
	USHORT msgLength);
	BOOL ProcessAnalBlockTransfer(UCHAR *pData, const UCHAR startByte,
	USHORT count);
	BOOL ProcessPulseBlockTransfer(UCHAR *pData, USHORT count);
	BOOL ProcessDigitalBlockTransfer(UCHAR *const pData, const USHORT count);
	BOOL DecodeAOChannelStatus(const UCHAR status, const USHORT chanNo);
	// Perform AI board commands
	BOOL GetRTComp(void);
	BOOL GetRTCal(void);
	BOOL GetCJC(void);
	BOOL ConfigureCJCActiveBurnoutState(void);
	BOOL GetCJCActiveBurnoutState(void);
	BOOL GetAICalibrationHistory(void);
	BOOL CheckCJCBurnoutWiring(void);
	BOOL ACKGoodAIBlock(void);
	BOOL GetAIDataBlock(E_IO_MOD_SUB_ERROR_CODE&);
	BOOL DownloadAIConfig(void);
	BOOL UploadAIConfig(void);
	BOOL SetAICalPoints(const UCHAR calMethod);
	BOOL SetAIRawMode(void);
	BOOL SetUseCalValues(void);
	BOOL SetMainsFrequency(void);
	BOOL GetAICalPoints(const UCHAR calMethod);
	BOOL AIRTCurrentDeselect(void);
	BOOL GetAILifeHistory(void);
	// Perform AO board commands
	BOOL UploadAOConfig(void);
	BOOL DownloadAOConfig(void);
	BOOL WriteAnalOut(void);
	BOOL WriteATEAnalOut(void);
	BOOL SetAORawMode(void);
	BOOL GetAOCalData(void);
	BOOL QueryAOStatus(void);
	BOOL SetAOFactoryCalPoints(void);
	BOOL GetAOLifeHistory(void);
	// Perform digital & pulse board commands
	BOOL DownloadDigitalPulseConfig(void);
	BOOL UploadDigitalPulseConfig(void);
	BOOL GetDigDataBlock(void);
	BOOL ACKGoodDigBlock(void);
	BOOL ReadDigInputState(void);
	BOOL GetPulseDataBlock(void);
	BOOL ACKGoodPulseBlock(void);
	BOOL WriteDigData(void);
	BOOL GetARLifeHistory(void);
	BOOL GetDIOLifeHistory(void);
	BOOL GetPILifeHistory(void);
	BOOL SaveAILifeHistory(void);
	BOOL SaveAOLifeHistory(void);
	BOOL SaveARLifeHistory(void);
	BOOL SaveDIOLifeHistory(void);
	BOOL SavePILifeHistory(void);
	CProtocol();
	virtual ~CProtocol();
private:
	void DecodeHistoryFaultRecord(const UCHAR *pMsgStart, const USHORT faultNo);
};
#endif // !defined(AFX_PROTOCOL_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_)
#endif // _PROTOCOL_H

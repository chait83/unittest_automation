//////////////////////////////////////////////////////////////////////
/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n IOCard.cpp
/// @n implementation of the CIOSlot class (SPI card).
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 71	Stability Project 1.66.1.3	7/2/2011 4:58:00 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 70	Stability Project 1.66.1.2	7/1/2011 4:38:21 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 69	Stability Project 1.66.1.1	3/17/2011 3:20:25 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 68	Stability Project 1.66.1.0	2/15/2011 3:03:10 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////
#include "Timer.h"
#include "V6globals.h"
#include "IOCardInfo.h"
#include "BrdInfo.h"
#include "BaseProtocol.h"
#include "Protocol.h"
#include "AIConfig.h"
#include "IOHandler.h"
#include "IOChanHandler.h"
#include "IOCardHandler.h"
#include "ConfigManager.h"
#include "BoardManager.h"
#include "TransMngr.h"
#include "CardSlot.h"
#include "IOCard.h"
#include "PPL.h"
#include "V6IOErrorCodes.H"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
// Earliest revsion/build combination that saves I/O card life stats
// Note - Removed in AK.005 and subsequent releases due to performance issues with eZTrend & Rev B processor boards
const UCHAR EarliestLifeStatsSavedRevision[3] = "AK";
const UCHAR EarliestLifeStatsSavedBuild = 4;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CIOCard::CIOCard(const USHORT cardNo) : CCardSlot(static_cast<UCHAR>(cardNo)) {
//	qDebug("Create new CIOCard\n");
	m_DigitalLastCovSystemTick = 0L;
	m_DigitalLastReadSystemTick = 0L;
	m_LastSuccesfulReadSystemTick = 0;
	m_SyncOpPending = FALSE;
	m_ReSyncOpPending = FALSE;
	m_pTransMngr = NULL;
	m_CmdProcessed = 0;
	m_CardOperational = FALSE;
	m_DeviceFailed = FALSE;
	m_failureReportAdded = FALSE;
	m_pProtocol = NULL;
	INTER_COMMAND_DELAY = 0;
//	if( IsRunningAsATEEquipment() == TRUE )
//		INTER_COMMAND_DELAY = 50;
// Get reference to I/O card configuration handler
	m_pConfigMngrObj = CIOConfigManager::GetHandle();
	ResetStateMachine();
}
CIOCard::~CIOCard() {
//	qDebug("Deleting CIOCard class\n");
}
void CIOCard::PerformReset() {
	if (true == IsResetRequired()) {
		UpdateCardReset(false);
		QString strError("");
		strError = QString::asprintf("Schedule Reset on Slot - %d", m_Instance);
		LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_INFORMATION, strError);
		m_NormOpPending.CommandModeToProc = IO_RESET;
	}
}
/////////////////////////////////////////////////////
/// Register a single instance of the transaction manager
///
/// @param[in] pTransMangr - Pointer to the transaction manager class to register.
///
/// @return TRUE if the passed in transaction manager is successfully registered,
/// or the same manager has been previously registered; otherwise FALSE
/////////////////////////////////////////////////////
BOOL CIOCard::RegisterTransManager(class CTransMangr *const pTransMangr) {
	// If one is not already registered, then register
	if (m_pTransMngr == NULL)
		m_pTransMngr = pTransMangr;
	// Success if actual registered transaction manager is the same as register request
	if (m_pTransMngr == pTransMangr)
		return TRUE;
	return FALSE;
}
//******************************************************
// ResetStateMachine()
///
/// Reset the acqusition state machine.
///
/// @return Nothing
/// 
//******************************************************
void CIOCard::ResetStateMachine(void) {
	m_bIsResetNeeded = false;
	// Default the state machine
	m_NormOpPending.CommandModeToProc = IO_IDLE;	// Module is IDLE
	m_BoardCmd.Acquire = FALSE;
	m_BoardCmd.Reset = FALSE;
	m_BoardCmd.CardIDUpload = FALSE;
	m_BoardCmd.CardTestStatUpload = FALSE;
	m_BoardCmd.ConfigCheck = FALSE;
	m_BoardCmd.ConfigDownload = FALSE;
	m_BoardCmd.ConfigUpload = FALSE;
	m_BoardCmd.UserCalibration = FALSE;
	m_BoardCmd.FactoryCalibration = FALSE;
	m_BoardCmd.HistoryUpload = FALSE;
	m_BoardCmd.BoardInfoUpload = FALSE;
	m_NormOpPending.Board.AckReadings = FALSE;
	m_NormOpPending.Board.WriteAllow = FALSE;
	m_NormOpPending.Board.ChanRead = FALSE;
	m_NormOpPending.Board.ChanRead2 = FALSE;
	m_NormOpPending.Board.CJC = FALSE;
	m_NormOpPending.Board.DataReset = TRUE;
	m_NormOpPending.Board.RTCal = FALSE;
	m_NormOpPending.Board.RTComp = FALSE;
	m_NormOpPending.Board.Sync = FALSE;
	m_NormOpPending.Board.TimeBase = FALSE;
	m_NormOpPending.Board.Timestamp = FALSE;
	m_NormOpPending.Board.RxError = FALSE;
	m_DeviceFailed = FALSE;
	m_failureReportAdded = FALSE;
	m_DataFromCard = FALSE;
	m_CardQueryEnabled = FALSE;
	m_initialDataReadForce = FALSE;
	m_NormOpPending.CommandModeToProc = 0;
}
//******************************************************
///
/// Schedule the I/O Card batch information to be reset.
///
/// @return TRUE if successfully scheduled; otherwise FALSE
///
/// @Note: This method can only be used when not in continuous run mode, otherwise data queues
///		will be misalligned due to the PPQ implementation.
//******************************************************
BOOL CIOCard::ScheduleClearBatchedData(void) {
	m_NormOpPending.Board.DataReset = TRUE;
	return m_NormOpPending.Board.DataReset;
}
//******************************************************
///
/// Schedule a upload of Card information.
///
/// @return TRUE if successfully scheduled; otherwise FALSE
/// 
//******************************************************
BOOL CIOCard::ScheduleCardQueueSyncOperation(void) {
	m_NormOpPending.Board.Sync = TRUE;
	return m_NormOpPending.Board.Sync;
}
//******************************************************
///
/// Schedule a card & queue sync.
///
/// @return TRUE if successfully scheduled; otherwise FALSE
/// 
//******************************************************
BOOL CIOCard::ScheduleUpdateCardInfo(void) {
	m_NormOpPending.Board.Sync = TRUE;
	return m_NormOpPending.Board.Sync;
}
//******************************************************
///
/// Schedule a download of special AI RT channel calibration info.
///
/// @return TRUE if successfully scheduled; otherwise FALSE
/// 
//******************************************************
BOOL CIOCard::ScheduleRTChanCal(void) {
	m_BoardCmd.AIRTChanCal = TRUE;
	return m_BoardCmd.AIRTChanCal;
}
//******************************************************
///
/// Schedule a upload of of the I/O card serial number.
///
/// @return TRUE if successfully scheduled; otherwise FALSE
/// 
//******************************************************
BOOL CIOCard::ScheduleSerialNoUpdate(void) {
	m_BoardCmd.CardIDUpload = TRUE;
	return m_BoardCmd.CardIDUpload;
}
//******************************************************
///
/// Schedule a upload of Test status.
///
/// @return TRUE if successfully scheduled; otherwise FALSE
/// 
//******************************************************
BOOL CIOCard::ScheduleTestStatusUpdate(void) {
	m_BoardCmd.CardTestStatUpload = TRUE;
	return m_BoardCmd.CardTestStatUpload;
}
//******************************************************
///
/// The time that the system coverage was last updated.
///
/// @return The last coverage system tick
/// 
//******************************************************
LONGLONG CIOCard::GetLastPPQSystemCoverage(void) const {
	return m_DigitalLastCovSystemTick;
}
//******************************************************
///
/// The next time that the system coverage is to be updated.
///
/// @return The system tick which coverage is next required on
/// 
//******************************************************
LONGLONG CIOCard::GetNextPPQSystemCoverageRqd(const ULONG difference) const {
	return m_DigitalLastCovSystemTick + difference;
}
//******************************************************
///
/// The time that the system coverage was last updated.
/// @param[in] digitalLastCovSystemTick - The last system tick that PPQ coverage was set to.
///
/// @return The last coverage system tick
/// 
//******************************************************
LONGLONG CIOCard::SetLastPPQSystemCoverage(const LONGLONG digitalLastCovSystemTick) {
	m_DigitalLastCovSystemTick = digitalLastCovSystemTick;
	return m_DigitalLastCovSystemTick;
}
//******************************************************
///
/// The time that the digital board was last read.
///
/// @return The last coverage system tick
/// 
//******************************************************
LONGLONG CIOCard::GetLastDISystemCoverage(void) const {
	return m_DigitalLastReadSystemTick;
}
//******************************************************
///
/// The next time that the system coverage is to be updated.
///
/// @return The system tick which coverage is next required on
/// 
//******************************************************
LONGLONG CIOCard::GetNextDISystemCoverageRqd(const ULONG difference) const {
	return m_DigitalLastReadSystemTick + difference;
}
//******************************************************
///
/// The time that the system coverage was last updated.
/// @param[in] digitalLastCovSystemTick - The last system tick that PPQ coverage was set to.
///
/// @return The last coverage system tick
/// 
//******************************************************
LONGLONG CIOCard::SetLastDISystemCoverage(const LONGLONG digitalLastCovSystemTick) {
	m_DigitalLastReadSystemTick = digitalLastCovSystemTick;
	return m_DigitalLastReadSystemTick;
}
//******************************************************
// SyncService()
///
/// Synchronises all card and card channel's pre-process queue(s)
///
/// @return TRUE on successful sychronisation; otherwise FALSE
/// 
//******************************************************
BOOL CIOCard::SyncService(void) {
	LONGLONG systemTick;
	USHORT chanNo;
	USHORT cardTick;
	BOOL retValue = FALSE;
//	class CProtocol *pProtocolHnd = NULL;
	class CIOCardHandler *pService = NULL;		// General Board reference
	class CIOChanHandler *pChan = NULL;		// General Channel reference
	// Get I/O card local time
	if (m_pProtocol != NULL) {
		// Get system time
		//systemTick = pGlbSysTimer->GetCurrentSystemTimeTick100();
		m_pProtocol->GetTimestamp();
		cardTick = m_pBrdInfoObj->GetBoardTicks(m_Instance);
		systemTick = pGlbSysTimer->GetCurrentSystemTimeTick100(); //MarkD: better late than early
		// Synchonise all board service queues, digital in channels are already synced at board level.
		pService = GetProcessHandle();
		if (pService != NULL)
			retValue = pService->SyncService(cardTick, systemTick);
		// Synchonise all channel service queues
		for (chanNo = 0; chanNo < m_ChanList.GetListCount(); chanNo++) {
			pChan = m_ChanList.GetChannelRef(chanNo);
			if (pChan != NULL) {
				switch (pChan->GetChannelServiceRequired()) {
				case PP_SERVICE_AI_CHAN:
				case PP_SERVICE_PULSE_CHAN:
					// Ensure that only valid channel types are ever resynced
					retValue = pChan->SyncService(cardTick, systemTick);
					break;
				case PP_SERVICE_DO_CHAN:
				case PP_SERVICE_AO_CHAN:
					// Real Time output, so no queues to sync
					break;
				}
			}
		}
//		if( retValue = TRUE )
//			qDebug("One or more queues synced\n");
	}
	return retValue;
}
//******************************************************
// ResyncService()
///
/// Synchronises all card and card channel's pre-process queue(s)
///
/// @return TRUE on successful re-sychronisation; otherwise FALSE
/// 
//******************************************************
BOOL CIOCard::ResyncService(void) {
	LONGLONG systemTick;
	USHORT cardTick;
	BOOL retValue = FALSE;
//	class CProtocol *pProtocolHnd = NULL;
	class CIOCardHandler *pService = NULL;		// General Board reference
//	m_pProtocol = m_pTransMngr->RequestTransToken( this );
	// Get I/O card local time
	if (m_pProtocol != NULL) {
		// Get system time
		//systemTick = pGlbSysTimer->GetCurrentSystemTimeTick100();
		if (m_pProtocol->GetTimestamp() == TRUE) {
			// Timestamp has succesfully been received by the card
			cardTick = m_pBrdInfoObj->GetBoardTicks(m_Instance);
			systemTick = pGlbSysTimer->GetCurrentSystemTimeTick100(); //MarkD: better late than early
			// Synchonise all board service queues
			pService = GetProcessHandle();
			if (pService != NULL)
				retValue = pService->ResyncService(cardTick, systemTick);
			// If ever required continue to resynchonise all channel service queues
//			if( retValue = TRUE )
//				qDebug("One or more queues re-synced\n");
		}
	}
//	m_pTransMngr->TransactionTerminated();
	return retValue;
}
//******************************************************
// UpdateRecorderCardSerialNo()
///
/// Updates the serial number of a recorders slot.
/// @param[in] slotNo - Card instance number.
///
//******************************************************
void CIOCard::UpdateRecorderCardSerialNo( USHORT slotNo) {
	class CBrdInfo *pBrdInfoObj = NULL;
	ULONG dateFirstTested;
	UCHAR rigNo;
	pBrdInfoObj = CBrdInfo::GetHandle();
	dateFirstTested = pBrdInfoObj->GetDateFirstTested(slotNo);
	rigNo = pBrdInfoObj->GetBoardFirstTestRig(slotNo);
	pSYSTEM_INFO->SetSlotCardSerialNo(slotNo, dateFirstTested, rigNo);
}
//******************************************************
// CheckRecorderCardSerialNoChanged()
///
/// Checks whether the board ID serial number is the same as that as saved.
/// @param[in] slotNo - Card instance number.
///
/// @return TRUE if update has been performed (i.e. board has changed); otherwise FALSE
/// 
//******************************************************
BOOL CIOCard::CheckRecorderCardSerialNoChanged( USHORT slotNo) {
	class CBrdInfo *pBrdInfoObj = NULL;
	BOOL boardChanged = FALSE;
	ULONG fittedDateFirstTested;
	UCHAR fittedRigNo;
	ULONG refDateFirstTested;
	UCHAR refRigNo;
	pBrdInfoObj = CBrdInfo::GetHandle();
	fittedDateFirstTested = pBrdInfoObj->GetDateFirstTested(slotNo);
	fittedRigNo = pBrdInfoObj->GetBoardFirstTestRig(slotNo);
	pSYSTEM_INFO->GetSlotCardSerialNo(slotNo, refDateFirstTested, refRigNo);
	if ((refDateFirstTested != fittedDateFirstTested) || (fittedRigNo != refRigNo)) {
		boardChanged = TRUE;
		UpdateRecorderCardSerialNo(slotNo);
	}
	return boardChanged;
}
//******************************************************
// IOCardIPQueryAllowed()
///
/// Query whether a read from the I/O card is allowed yet.
///
/// @return TRUE if I/P read is allowed; otherwise FALSE
/// 
//******************************************************
BOOL CIOCard::IOCardIPQueryAllowed(void) {
	return m_CardQueryEnabled;
}
//******************************************************
// ScheduleDataBlockAck()
///
/// Schedule a block data acknowledge of the block read.
///
/// @return TRUE if successfully scheduled; otherwise FALSE
/// 
//******************************************************
BOOL CIOCard::ScheduleDataBlockAck(void) {
	m_NormOpPending.Board.AckReadings = TRUE;
	return m_NormOpPending.Board.AckReadings;
}
//******************************************************
// ScheduleDataWriteAllowed()
///
/// Schedule a constant update of I/O card output.
///
/// @return TRUE if successfully scheduled; otherwise FALSE
/// 
//******************************************************
BOOL CIOCard::ScheduleDataWriteAllowed(void) {
	m_NormOpPending.Board.WriteAllow = TRUE;
	return m_NormOpPending.Board.WriteAllow;
}
//******************************************************
// ScheduleStatusCheck()
///
/// Schedule a status check.
///
/// @return TRUE if successfully scheduled; otherwise FALSE
/// 
//******************************************************
BOOL CIOCard::ScheduleStatusCheck(void) {
	m_NormOpPending.Board.StatCheck = TRUE;
	return m_NormOpPending.Board.StatCheck;
}
//******************************************************
// SetAcquireModeActiveState()
///
/// Schedule an acquire mode active state.
/// @param[in] activeState - The current active state for channel read.
///
/// @return TRUE if channel read active; otherwise FALSE
/// 
//******************************************************
BOOL CIOCard::SetAcquireModeActiveState(const BOOL activeState) {
	m_NormOpPending.Board.ChanRead = activeState;
	return m_NormOpPending.Board.ChanRead;
}
//******************************************************
///
/// Schedule a queue synchronisation.
///
/// @return TRUE if successfully scheduled; otherwise FALSE
/// 
//******************************************************
BOOL CIOCard::ScheduleQueueSync(void) {
	m_SyncOpPending = TRUE;
	return m_SyncOpPending;
}
//******************************************************
///
/// Schedule a queue re-synchronisation.
///
/// @return TRUE if successfully re-scheduled; otherwise FALSE
/// 
//******************************************************
BOOL CIOCard::ScheduleQueueReSync(void) {
	m_ReSyncOpPending = TRUE;
	return m_ReSyncOpPending;
}
//******************************************************
// ScheduleErrorDownload()
///
/// Schedule a block data download of all I/O card errors.
///
/// @return TRUE if successfully scheduled; otherwise FALSE
/// 
//******************************************************
BOOL CIOCard::ScheduleErrorDownload(void) {
	m_NormOpPending.Board.RxError = TRUE;
	return m_NormOpPending.Board.RxError;
}
//******************************************************
// OperateTransactionSM()
///
/// Main generic transaction state machine.
///
/// @return TRUE if successful; otherwise FALSE
/// @pre - Pointer to the I/O board protocol handle.
/// 
//******************************************************
BOOL CIOCard::OperateTransactionSM(void) {
//	QDateTime sysTime;
//	WCHAR wcSystemTime[100];
//	static USHORT StateMCCycles = 0;
	BOOL opState = TRUE;
	BOOL nextOpTest = TRUE;
	BOOL readingSync = FALSE;
	UCHAR boardType;
	USHORT BoardNo;
	// If entered with an invalid protocol token then fail
	if (m_pProtocol == NULL) {
		return FALSE;
	}
	boardType = WhatBoardType();
	// Work on highest priority actions first
	// A little delay before each command prevents the driver from responding with an error
	if (m_NormOpPending.CommandModeToProc & IO_RESET) {
		sleep(INTER_COMMAND_DELAY);
		opState = m_pProtocol->ResetCard();
		if (opState == TRUE) {
			m_thisStateMCCycles++;
			m_NormOpPending.CommandModeToProc ^= IO_RESET;
			//opState = ScheduleBoardInfoUpload();				// Upload info to the I/O card
			// Reset all board status variables to their default condition
			for (BoardNo = 0; BoardNo < MAX_SCHED_SERVICES; BoardNo++) {
				// Reset the status of each board in turn
				m_pBrdStatsObj->ResetCardStats(BoardNo);
			}
			ScheduleConfigDownload();
		}
	}
	// Need to check errors yet?
	nextOpTest = m_NormOpPending.Board.RxError;
	m_NormOpPending.Board.RxError = FALSE;
	if (nextOpTest == TRUE) {
		sleep(INTER_COMMAND_DELAY);
		// Get the errors on the board
		opState = m_pProtocol->GetErrors();
		if (opState == TRUE) {
			m_NormOpPending.Board.RxError = FALSE;
		}
	}
	if (m_NormOpPending.CommandModeToProc & IO_CONFIGCHECK) {
		opState = ScheduleBoardInfoUpload();	// Upload info to the I/O card
		sleep(INTER_COMMAND_DELAY);
		opState = m_pProtocol->GetCardTimeBase();
		if (opState == TRUE) {
			sleep(INTER_COMMAND_DELAY);
			opState = m_pProtocol->GetConfigCRC();
			m_thisStateMCCycles++;
			m_NormOpPending.CommandModeToProc ^= IO_CONFIGCHECK;
		}
	}
	// Schedule time stamp synchronising if required before data block read (If not ATE build)ee
	readingSync = m_NormOpPending.Board.Sync;
	if ((readingSync == TRUE) && (IsRunningAsATEEquipment() == FALSE)) {
		sleep(INTER_COMMAND_DELAY);
		opState = ResyncService();
		if (opState == TRUE) {
			// Automatically reschedule board sync, unless the last resync of board was succesful
			m_NormOpPending.Board.Sync = FALSE;
		}
	}
	// Need to get the cards timebase reference yet?
	nextOpTest = m_ReSyncOpPending;
	m_ReSyncOpPending = FALSE;
	if (nextOpTest == TRUE) {
//		if( opState == TRUE )
		{
			sleep(INTER_COMMAND_DELAY);
			opState = SyncService();
		}
	}
	// Need to get the cards timebase reference yet?
	nextOpTest = m_SyncOpPending;
	m_SyncOpPending = FALSE;
	if (nextOpTest == TRUE) {
//		if( opState == TRUE )
		{
			// All 50Hz channels need to be reset at this point; otherwise the system becomes overloaded
//			if( opState == TRUE )
			{
				sleep(INTER_COMMAND_DELAY);
				opState = SyncService();
				m_NormOpPending.Board.DataReset = TRUE;
			}
			nextOpTest = m_NormOpPending.Board.DataReset;
			m_NormOpPending.Board.DataReset = FALSE;
			if (nextOpTest == TRUE) {
				opState = m_pProtocol->ResetBoardData();
//				opState = m_pProtocol->ResetBoardDataAndTimeStamp();
				if (opState == TRUE) {
					m_thisStateMCCycles++;
					m_NormOpPending.Board.DataReset = FALSE;
				}
			}
//			if( opState == TRUE )
//			{
//				sleep(INTER_COMMAND_DELAY);
//				opState = SyncService();
//			}
			// Board has been reset and queues synced so enable reading and later writing to board
			if (opState == TRUE)
				m_CardQueryEnabled = TRUE;
			// If we can determine at this stage that a scheduled operation is going to be required then we can set
			// This state can be modified on a board by board basis
			if ((opState == TRUE) && (boardType != BOARD_DIO) && (boardType != BOARD_AR)) {
				// Board has been reset and queues synced so enable reading and later writing to board
				m_NormOpPending.Board.ChanRead = TRUE;
				m_NormOpPending.Board.ChanRead2 = TRUE;
			}
		}
//		m_NormOpPending.Board.DataReset = TRUE;
//		if( opState == TRUE )
//		{
//			m_thisStateMCCycles++;
//			opState = m_pProtocol->ResetBoardData();
//			m_NormOpPending.Board.DataReset = TRUE;
//		}
	}
	// Schedule time stamp synchronising if required before data block read
	nextOpTest = m_NormOpPending.Board.Timestamp;
	m_NormOpPending.Board.Timestamp = FALSE;
	if (nextOpTest == TRUE) {
		sleep(INTER_COMMAND_DELAY);
		// Timestamp this is not a new command but an extenstion to an existing command
		opState = m_pProtocol->GetTimestamp();
		if (opState == TRUE) {
			m_thisStateMCCycles++;
			m_NormOpPending.Board.Timestamp = FALSE;
		}
	}
	return TRUE;
}
//******************************************************
//
/// Change the current operating mode of the generic transaction state machine.
///
/// @return TRUE if successful; otherwise FALSE
/// @pre - Pointer to the I/O board protocol handle.
/// 
//******************************************************
BOOL CIOCard::PerformSMModeChange(void) {
	class CBrdStats *pBrdStat = NULL;
	class CBrdInfo *pBrdInfo = NULL;
	class CSlotMap *pSlotMap = NULL;
	CNVBasicVar *pOPStateVar = NULL;
	COMBO_VAR4 OPStateVar;					// Union cannot initialise
	USHORT sysChanNo = 0;
	USHORT chanNo = 0;
	UCHAR failCount = ERROR_REPORT_NONE;
	BOOL opState = TRUE;
	BOOL nextOpTest = FALSE;
	nextOpTest = m_BoardCmd.BoardInfoUpload;
	m_BoardCmd.BoardInfoUpload = FALSE;
	if (nextOpTest == TRUE) {
		sleep(INTER_COMMAND_DELAY);
		opState = m_pProtocol->GetCardCalStatus();					// Get current firmware revision and cal history
		if (opState == TRUE) {
			m_thisStateMCCycles++;
			m_CmdProcessed++;
			m_BoardCmd.BoardInfoUpload = FALSE;
			if (CheckRecorderCardSerialNoChanged(BoardSlotInstance()) == TRUE) {
				// Note: Before firmware release AK.004 there is no point using the relay operations
				//	downloaded from the I/O board have never been persisted.
				// AK.005 saw the removal of this feature due to operational board issues so default all to 0
				// ------------------------------------------------------------------------------------------
				pSlotMap = CSlotMap::GetHandle();
				pBrdStat = CBrdStats::GetHandle();
				pBrdInfo = CBrdInfo::GetHandle();
				if (WhatBoardType() == BOARD_DIO) {
					// The I/O board has been changed so we need to use the boards history, rather than stored recorders.
					opState = m_pProtocol->GetDIOLifeHistory();	// Get board history
					pBrdStat->CheckFailCount(BoardSlotInstance(), EERT_NON_PARAMETERISED, ERR_READING_STATS,
							&failCount);
#if 0
					if( (failCount == ERROR_REPORT_NONE) && (opState == TRUE) &&
						(pBrdInfo->IsFirmwareAtLeastRevision(BoardSlotInstance(), EarliestLifeStatsSavedRevision, EarliestLifeStatsSavedBuild) == TRUE ))
					{
						// Update recorder digital relay cycle count, only if there are no life history stat CRC errors
						// and the firmware revision supports saved life stats.
						for( chanNo = 0; chanNo < MAX_DIG_CHANNELS; chanNo++ )
						{
							sysChanNo = pSlotMap->GetSysChannelFromDigIOChannel( BoardSlotInstance(), chanNo, ZERO_BASED );
							pOPStateVar = pNV_VARS->GetBasicVarNVObject( static_cast<NVVAR_IDENT>(NVV_RELAY_OPS_FIRST + sysChanNo) );
							OPStateVar = pOPStateVar->GetFromNV()->value;
							OPStateVar.ul = pBrdStat->GetSavedDIORelayOpsRecord( BoardSlotInstance(), chanNo );
							pOPStateVar->SetToNV( OPStateVar );				// Store back to NV
						}
					}
					else
#endif
					{
						// Reset the operations count
						for (chanNo = 0; chanNo < MAX_DIG_CHANNELS; chanNo++) {
							sysChanNo = pSlotMap->GetSysChannelFromDigIOChannel(BoardSlotInstance(), chanNo,
									ZERO_BASED);
							pOPStateVar = pNV_VARS->GetBasicVarNVObject(
									static_cast<NVVAR_IDENT>(NVV_RELAY_OPS_FIRST + sysChanNo));
							OPStateVar = pOPStateVar->GetFromNV()->value;
							OPStateVar.ul = 0L;
							pOPStateVar->SetToNV(OPStateVar);		// Clear NV
						}
					}
				} else if (WhatBoardType() == BOARD_AR) {
					// The I/O board has been changed so we need to use the boards history, rather than stored recorders.
					opState = m_pProtocol->GetARLifeHistory();		// Get board history
					pBrdStat->CheckFailCount(BoardSlotInstance(), EERT_NON_PARAMETERISED, ERR_READING_STATS,
							&failCount);
#if 0
					if( (failCount == ERROR_REPORT_NONE) && (opState == TRUE) &&
						(pBrdInfo->IsFirmwareAtLeastRevision(BoardSlotInstance(), EarliestLifeStatsSavedRevision, EarliestLifeStatsSavedBuild) == TRUE ))
					{
						// Update recorder digital relay cycle count, only if there is are life history stat CRC errors
						// and the firmware revision supports saved life stats.
						for( chanNo = 0; chanNo < MAX_AR_CHANNELS; chanNo++ )
						{
							sysChanNo = pSlotMap->GetSysChannelFromDigIOChannel( BoardSlotInstance(), chanNo, ZERO_BASED );
							pOPStateVar = pNV_VARS->GetBasicVarNVObject( static_cast<NVVAR_IDENT>(NVV_RELAY_OPS_FIRST + sysChanNo) );
							OPStateVar = pOPStateVar->GetFromNV()->value;
							OPStateVar.ul = pBrdStat->GetSavedARRelayOpsRecord( BoardSlotInstance(), chanNo );
							pOPStateVar->SetToNV( OPStateVar );				// Store back to NV
						}
					}
					else
#endif
					{
						// Reset the operations count
						for (chanNo = 0; chanNo < MAX_DIG_CHANNELS; chanNo++) {
							sysChanNo = pSlotMap->GetSysChannelFromDigIOChannel(BoardSlotInstance(), chanNo,
									ZERO_BASED);
							pOPStateVar = pNV_VARS->GetBasicVarNVObject(
									static_cast<NVVAR_IDENT>(NVV_RELAY_OPS_FIRST + sysChanNo));
							OPStateVar = pOPStateVar->GetFromNV()->value;
							OPStateVar.ul = 0L;
							pOPStateVar->SetToNV(OPStateVar);		// Clear NV
						}
					}
				}
			}
		}
	}
	nextOpTest = m_BoardCmd.CardIDUpload;
	m_BoardCmd.CardIDUpload = FALSE;
	if (nextOpTest == TRUE) {
		sleep(INTER_COMMAND_DELAY);
		opState = m_pProtocol->SetCardSerialNo();	// Send the card serial no.
		if (opState == TRUE) {
			m_thisStateMCCycles++;
			m_CmdProcessed++;
			m_BoardCmd.CardIDUpload = FALSE;
		}
	}
	nextOpTest = m_BoardCmd.CardTestStatUpload;
	m_BoardCmd.CardTestStatUpload = FALSE;
	if (nextOpTest == TRUE) {
		sleep(INTER_COMMAND_DELAY);
		opState = m_pProtocol->SetCardTestData();	// Send I/O card test status
		if (opState == TRUE) {
			m_thisStateMCCycles++;
			m_CmdProcessed++;
			m_BoardCmd.CardTestStatUpload = FALSE;
		}
	}
	return TRUE;
}

/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n PPDICard.cpp
/// @n implementation for the DI board (16 channels) handler.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 41	Stability Project 1.36.1.3	7/2/2011 4:59:44 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 40	Stability Project 1.36.1.2	7/1/2011 4:38:38 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 39	Stability Project 1.36.1.1	3/17/2011 3:20:34 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 38	Stability Project 1.36.1.0	2/15/2011 3:03:41 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////
#include "PPQManager.h"
#include "PPL.h"
#include "ATECal.h"
#include "V6IOErrorCodes.H"
#include "BaseProtocol.h"
#include "Config.h"
#include "DigConfig.h"
#include "CardSlot.h"
#include "IOCard.h"
#include "DigPulseCard.h"
#include "PPQService.h"
#include "AIConfig.h"
#include "IOHandler.h"
#include "PPIOService.h"
#include "PPDICard.h"
#include "TraceDefines.h"
#include <math.h>
#include "AnaloguePulsePPQ.h"
#ifndef __cplusplus
#define __cplusplus
#endif
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
#define MAX_DI_RETURN_BYTES 256
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CPPDICard::CPPDICard(BOOL chanInput) : CPPIOService(chanInput) {
//	qDebug("Create new CPPDICard\n");
	m_firstReadingAdded = FALSE;
}
CPPDICard::~CPPDICard() {
//	qDebug("Delete CPPDICard class\n");
}
/////////////////////////////////////////////////////
/// Process a state change or read for a digital in channel
/// @param[in] state - Channel state (On/Off).
/// @param[in] timeStamp - Timestamp of state change/measurement.
///
/// @return TRUE if reading processed; otherwise FALSE.
/////////////////////////////////////////////////////
BOOL CPPDICard::ProcessCardReadings(const USHORT state, const USHORT timeStamp) {
	return FALSE;
}
#define SIZEOF_DIG_READING	4
//******************************************************
// InitialiseChanService()
///
/// Request and enable the relevant digital board pre-process queue,
/// only if there is at least one digital input enabled
/// and if we have a handle on the Pre-process queue manager
/// @param[in] pBoardInfo - I/O board process information.
///
/// @return TRUE on successful initialisation; otherwise FALSE
/// 
//******************************************************
BOOL CPPDICard::InitialiseChanService(T_COMMONPROCESSINFO *const pBoardInfo) {
	T_PPQSER_RETURN_VALUE PPQState = PPQSER_INVALID_PPQ_HANDLE;
	BOOL atLeastOneInputChannelEnabled;
#ifndef V6IOTEST
	T_PPQC_DIGITAL_PPQ_TYPE digitalQueueType;
#endif
	USHORT highestNoActiveChannel;
	BOOL retValue = FALSE;
	class CPPQManager *pPPQManager = NULL;		///< Pre-process queue manager
	USHORT chartReportMask = 0;
	USHORT msgReportMask = 0;
	// Get the highest channel number that is an active digital input on the card
	pPPQManager = CPPQManager::GetHandle();
	atLeastOneInputChannelEnabled = (static_cast<class CDigPulseCard*>(pBoardInfo->pCard))->HighestDIChannelEnabled(
			highestNoActiveChannel);
	if (atLeastOneInputChannelEnabled == TRUE) {
		pBoardInfo->PPService = PP_SERVICE_DI_CARD;
#ifndef V6IOTEST
		if (IsRunningAsATEEquipment() == FALSE) {
			if (pPPQManager != NULL) {
				digitalQueueType = GetDigitalPPQReference(pBoardInfo);
				PPQState = pPPQManager->m_DPPQServices.RequestPPQ(pBoardInfo->hPPQ);
				(static_cast<class CDigPulseCard*>(pBoardInfo->pCard))->QueryReportSelectionMask(chartReportMask,
						msgReportMask);
				if (PPQState == PPQSER_OK) {
					PPQState =
							pPPQManager->m_DPPQServices.EnablePPQ(pBoardInfo->hPPQ, digitalQueueType, PPQC_10HZ,
									chartReportMask, msgReportMask,
									(static_cast<class CDigPulseCard*>(pBoardInfo->pCard))->GetBoardCfgDigitalInputSelectionMask(),
									highestNoActiveChannel);
					if (PPQState == PPQSER_OK) {
						(static_cast<class CIOCard*>(pBoardInfo->pCard))->ScheduleQueueSync();
					}
				}
			}
		}
#endif
	}
	// Success is successful input queue creation or non-required (no inputs enabled)
	if ((PPQState == PPQSER_OK) || (IsRunningAsATEEquipment() == TRUE) || (atLeastOneInputChannelEnabled == FALSE)) {
		retValue = TRUE;
	}
	return retValue;
}
/////////////////////////////////////////////////////
/// Create the default definition of an DI channel
/// @param[in] pboardInfo - The board process info.
/// @param[in] pchanInfo - The channel process info.
/// @param[in] pCard - The I/O board class.
/// @param[in] chanNo - The board channel number.
///
/// @return TRUE if channel configured; otherwise FALSE
/////////////////////////////////////////////////////
BOOL CPPDICard::CreateChannelServiceData(T_COMMONPROCESSINFO *const pboardInfo, T_CHANPROCESSINFO *const pchanInfo,
		class CCardSlot *pCard,
		USHORT chanNo) {
	static BOOL powerUp = TRUE;	//MarkD
	BOOL retValue = FALSE;
	class CSlotMap *pSlotMapObj = NULL;			///< Slot map holder
	pSlotMapObj = CSlotMap::GetHandle();
	if (pSlotMapObj != NULL) {
		pboardInfo->input = TRUE;
		pboardInfo->pCard = pCard;
		pboardInfo->CardSlotNo = static_cast<UCHAR>(pCard->BoardSlotInstance());
		pchanInfo->PPService = PP_SERVICE_DI_CHAN;
		pchanInfo->channelNo = static_cast<UCHAR>(chanNo);
		pchanInfo->glbchannelNo = pSlotMapObj->GetSysChannelFromDigIOChannel(pboardInfo->CardSlotNo, chanNo, ONE_BASED);
		if (powerUp == TRUE) {
			pchanInfo->LastOPState = DEFAULT_DIGITAL_IO_STATE;	//MarkD: do this first time only, ie on power-up		
			powerUp = FALSE;
		}
		retValue = TRUE;
	}
	return retValue;
}
/////////////////////////////////////////////////////
/// Create the default definition of an AO channel
/// @param[in] pboardInfo - The board process info.
/// @param[in] pCard - The I/O board class.
///
/// @return TRUE if channel configured; otherwise FALSE
/////////////////////////////////////////////////////
BOOL CPPDICard::InitialiseBoardService(T_COMMONPROCESSINFO *pboardInfo, class CCardSlot *const pCard) {
	pboardInfo->input = FALSE;
	pboardInfo->pCard = pCard;
	pboardInfo->CardSlotNo = static_cast<UCHAR>(pCard->BoardSlotInstance());
	pboardInfo->PPService = PP_SERVICE_UNKNOWN;
	return TRUE;
}
//******************************************************
// ResyncPPQueue()
///
/// Resync a digital pre-process input queue.
/// @param[in] pBoardInfo - Board specific data processing parameters.
/// @param[in] IOCardTick - I/O card tick to sync to.
/// @param[in] systemTick - The global system time to sync to.
///
/// @return TRUE if resync succedded; otherwise FALSE.
//******************************************************
BOOL CPPDICard::ResyncPPQueue(T_PCOMMONPROCESSINFO pBoardInfo, const USHORT IOCardTick, const LONGLONG systemTick) {
	BOOL retValue = FALSE;
#ifndef V6IOTEST
	class CPPQManager *pPPQManager = NULL;		///< Pre-process queue manager
	pPPQManager = CPPQManager::GetHandle();
	// Resync the Pre-process queues
	if (pPPQManager->m_DPPQServices.ReSyncPPQ(pBoardInfo->hPPQ, IOCardTick, systemTick) == APPPQ_OK)
		retValue = TRUE;
#endif
	return retValue;
}
//******************************************************
// ResyncPPQueue()
///
/// Resync a digital pre-process input queue.
/// @param[in] pBoardInfo - Board specific data processing parameters.
/// @param[in] IOCardTick - I/O card tick to sync to.
/// @param[in] systemTick - The global system time to sync to.
///
/// @return TRUE if resync succedded; otherwise FALSE.
//******************************************************
BOOL CPPDICard::SyncPPQueue(T_PCOMMONPROCESSINFO pBoardInfo, const USHORT IOCardTick, const LONGLONG systemTick) {
	BOOL retValue = FALSE;
#ifndef V6IOTEST
	class CPPQManager *pPPQManager = NULL;		///< Pre-process queue manager
	pPPQManager = CPPQManager::GetHandle();
	// Resync the Pre-process queues
	if (pPPQManager->m_DPPQServices.SyncPPQ(pBoardInfo->hPPQ, IOCardTick, systemTick) == APPPQ_OK)
		retValue = TRUE;
#else
	retValue = TRUE;
#endif
	return retValue;
}
//******************************************************
///
/// Get the card PQQ reference
///
/// @return The PPQ reference number
/// 
//******************************************************
T_PPQC_DIGITAL_PPQ_TYPE CPPDICard::GetDigitalPPQReference(T_PCOMMONPROCESSINFO pBoardInfo) {
	switch (pBoardInfo->pCard->BoardSlotInstance()) {
	case RECORDER_SLOT_G:
		return PPQC_DIGITAL_SLOT_1;
	case RECORDER_SLOT_H:
		return PPQC_DIGITAL_SLOT_2;
	case RECORDER_SLOT_I:
		return PPQC_DIGITAL_SLOT_3;
	default:
		// assert an error
		LogInternalError("ILLEGAL DIGITAL PPQ REQUESTED");
	};
	return PPQC_DIGITAL_SLOT_1;
}
//******************************************************
// ProcessDigitalInReadings()
///
/// Performs a channel service to enable message decode and storage/collection
/// to the approriate Data Item table or data queue for data extraction/processing.
/// @param[in] pCardInfo - System card data.
/// @param[in] pCardData - Card message data.
/// @param[in] noOfBytesToProcess - Number of digatl data bytes to process.
///
/// @return TRUE on successful service execution; otherwise FALSE
/// 
//******************************************************
BOOL CPPDICard::ProcessDigitalInReadings(T_PCOMMONPROCESSINFO pCardInfo, const UCHAR *pCardData,
		const USHORT noOfBytesToProcess) {
	class CATECal *pATECalStruct = NULL;
	class CBrdStats *pBrdStatsObj = NULL;				///< Board stats holder
	class CPPQManager *pPPQManager = NULL;		///< Pre-process queue manager
	BOOL retValue = TRUE;
	UCHAR BytesProcessed = 0;
	DataItem2bytes timestamp;
	DataItem2bytes newvalue;
	pPPQManager = CPPQManager::GetHandle();
	pATECalStruct = CATECal::GetHandle();
	pBrdStatsObj = CBrdStats::GetHandle();
	if (noOfBytesToProcess > 0) {
		// Number of data bytes should be multiples of sizeof(timestamp + readings) and not overflow
		if (noOfBytesToProcess > MAX_DI_RETURN_BYTES) {
			LOG_ERR(TRACE_IO_SCHED, "TOO MANY READINGS FROM BOARD");
			retValue = FALSE;
		} else if ((noOfBytesToProcess % SIZEOF_DIG_READING) != 0) {
			LOG_ERR(TRACE_IO_SCHED, "BOARD DATA RETURN SIZE MISMATCH");
			retValue = FALSE;
		} else {
			while ((retValue == TRUE) && (BytesProcessed < noOfBytesToProcess)) {
				// Get time stamp
				timestamp.UCData[SWAP_BYTE_1] = pCardData[BytesProcessed + SWAP_BYTE_0];
				timestamp.UCData[SWAP_BYTE_0] = pCardData[BytesProcessed + SWAP_BYTE_1];
				// Get value
				newvalue.UCData[SWAP_BYTE_0] = pCardData[BytesProcessed + SWAP_BYTE_3];
				newvalue.UCData[SWAP_BYTE_1] = pCardData[BytesProcessed + SWAP_BYTE_2];
				if (IsRunningAsATEEquipment() == FALSE) {
					// Send each reading to the relevant pre-process queue
					if (pPPQManager != NULL) {
//						qDebug("Adding %d @ %d to %d\n", newvalue.USData, timestamp.USData, pCardInfo->hPPQ);
						pPPQManager->m_DPPQServices.AddReading(pCardInfo->hPPQ, newvalue.USData, timestamp.USData);
						m_firstReadingAdded = TRUE;
					}
				}
				// If in ATE test mode then send readings to ATE Cal structure
				if ((IsRunningAsATEEquipment() == TRUE) && (pATECalStruct != NULL)
						&& (pATECalStruct->QueryATECardNo() == pCardInfo->CardSlotNo)) {
					pATECalStruct->DigitalInChanState = newvalue.USData;
				}
				BytesProcessed += 4;
			}
		}
#ifndef V6IOTEST
		LONGLONG SysTicks;
		USHORT IOTicks;
		if (IsRunningAsATEEquipment() == FALSE) {
			SysTicks = pPPQManager->m_DPPQServices.GetLastResyncSystemTick(pCardInfo->hPPQ);
			IOTicks = pPPQManager->m_DPPQServices.GetLastResyncDITick(pCardInfo->hPPQ);
			pBrdStatsObj->SetIOTimesync(pCardInfo->CardSlotNo, 0, IOTicks, SysTicks);
		}
#endif
	}
	return retValue;
}
//******************************************************
// SetLastReadingCoverage()
///
/// Set the continued coverage of the digital last reading.
/// @param[in] pCardInfo - System card data.
/// @param[in] systemTick - The system tick time.
///
/// @return TRUE
/// 
//******************************************************
BOOL CPPDICard::SetLastReadingCoverage(T_PCOMMONPROCESSINFO pCardInfo, const LONGLONG systemTick) {
#ifndef V6IOTEST
	class CPPQManager *pPPQManager = NULL;		///< Pre-process queue manager
	class CBrdStats *pBrdStatsObj = NULL;				///< Board stats holder
	LONGLONG SysTicks;
	USHORT IOTicks;
	pBrdStatsObj = CBrdStats::GetHandle();
	pPPQManager = CPPQManager::GetHandle();
	if ((pPPQManager != NULL) && (m_firstReadingAdded == TRUE)) {
//		qDebug("SetLastReadingCoverage queue %d to %ld", pCardInfo->hPPQ, systemTick);
		pPPQManager->m_DPPQServices.SetLastReadingCoverage(pCardInfo->hPPQ, systemTick);
		SysTicks = pPPQManager->m_DPPQServices.GetLastResyncSystemTick(pCardInfo->hPPQ);
		IOTicks = pPPQManager->m_DPPQServices.GetLastResyncDITick(pCardInfo->hPPQ);
		pBrdStatsObj->SetIOTimesync(pCardInfo->CardSlotNo, 0, IOTicks, SysTicks);
	}
#endif
	return TRUE;
}

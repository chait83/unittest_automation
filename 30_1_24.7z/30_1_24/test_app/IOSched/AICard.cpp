/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n AICard.cpp
/// @n implement the AI Card state machine.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
//	28-07-17	Shankar Rao		Added Sub Error Code detection to process error data patterns and identify detailed errors in IO
// 152 Stability Project 1.147.1.3	2/2011 4:55:15 PM		ant(HAIL) 
//				ity Project: Recorder source has been upgraded from IL
//		vers		irmware to JF version of firmware.
// 151 Stability Project 1.147.1.2	7/1/2011 4	54 PM	Hemant(HAIL	/		Stability		Files has been checked in before the merging
//		task. The mergin		e done between IL version of firmware and JF
//		version of firmware.		50 Stability Project 1.147.1.1	3/17/2011 3:20:07 PM	Hema	AIL) 
//		Implem	d "#ifdef _STD_H		MT_" for default functioning of
//		new operator in DEBUG mode only.		ct memory leaks in files, use
//		it in preprocessor definition when i		mode.
// 149 Stability Project 1.147.1.0	2/15/2011 3:02:02 PM	Hemant(HAIL) 
//			le updated during He	anagement. Call		efault behaviour
//		of new operator has been commented.
// $
//
///		///////////////////////////////////////////////////////////
#include <math.h>
#include <QtWidgets/qwidget.h>
#include "Conversion.h"
#include "BrdInfo.h"
#include "Timer.h"
#include "TV6Timer.h"
#include "V6IO_AI_InputRanges.H"
#include "AIConfig.h"
#include "BoardManager.h"
#include "BaseProtocol.h"
#include "V6globals.h"
#include "IOHandler.h"
#include "IOChanHandler.h"
#include "LinearTable.h"
#include "Device.h"
#include "DeviceManager.h"
#include "FFConversionInfo.h"
#include "InputConditioning.h"
#include "CardSlot.h"
#include "IOCard.h"
#include "AICard.h"
#include "V6defines.h"
#include "ATECal.h"
#include "TV6Timer.h"
#include "StringDefinitions.h"
#include "BoardChannelCommonDefines.h"
#include "ErrorControl.h"
#define MAX_PRIORITY_CHANNELS_SIM_DWNLD	2
#define MAX_CHANNELS_SIM_DWNLD	8
#define PRIORITY_1		1
#define PRIORITY_2		2
#define PRIORITY_3		3
#define PRIORITY_4		4
#define MAX_PARTIAL_ERRORS_ALLOWED	30
// #define OVERALL_TIMMINGS_RQD 1
#include <QThread>
#define sleep(a) QThread::msleep(a)
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CAICard::CAICard(USHORT CardSlotID) : CIOCard(CardSlotID) {
	USHORT chanNo;
	USHORT priorityNo;
	ULONG currentTime;
	CTVtime time;		// Time routines instance (structure - cannot initialise).
//	qDebug("Create new CAICard\n");
	time.TimeNow();
	currentTime = static_cast<ULONG>(USEC_TO_SEC(time.GetMicroSecs()));
	m_PriorityScheduleRqd = PRIORITY_1;
	m_totalChanMask = 0;
	m_CJCFailed = FALSE;
	m_numPartialErrors = 0;
	for (chanNo = 0; chanNo < MAX_AI_BOARD_CHANNELS; chanNo++) {
//		m_chanInitPriority[chanNo] = 0;		/// No priority for channel
//		m_chanRunPriority[chanNo] = 0;			/// No priority for channel
		m_AILastRTCalSystemTick[chanNo] = currentTime;		///< No RT cal saved
		m_AILastRTCompSystemTick[chanNo] = currentTime;	///< No RT comp saved
		m_startRTCalCheckRqd[chanNo] = TRUE;	///< Initial RT cal check required
		m_startRTCompCheckRqd[chanNo] = TRUE;	///< Initial RT comp check required
	}
	for (priorityNo = 0; priorityNo < TOTAL_AI_BOARD_PRIORITIES; priorityNo++) {
		m_PriorityChanMask[priorityNo] = 0;
	}
	// Get reference to I/O card ranges
	m_pAIRanges = CAIRanges::GetHandle();
	m_pServiceManagerObj = CPPIOServiceManager::GetHandle();
	m_pICService = m_pServiceManagerObj->GetICService();
	m_pAIConfigObj = NULL;
	ResetStateMachine();						// Reset state machine
	EmptyStartupList();					// Reset startup sequence state machine
}
CAICard::~CAICard() {
//	qDebug("Deleting CAICard\n");
}
//******************************************************
// InitialiseCard()
///
/// Schedule correct desired update rate for card & channel	based on configuration.
/// @param[in] cardNo - Card slot number identification.
///
/// @return TRUE
/// 
//******************************************************
BOOL CAICard::InitialiseCard(const USHORT cardNo) {
//	QString   IOCardDescription;
	class CSlotMap *pSlotMap = NULL;
	CDataItem *pDataItem = NULL;
	BOOL retValue = FALSE;
//	GetIOCardStrDescription( &IOCardDescription );
//	LogInternalError(IOCardDescription.toLocal8Bit().data());
	if ((m_pAIRanges != NULL) && (m_pTransMngr != NULL) && (m_pConfigMngrObj != NULL)) {
		// Initialise the card's transaction management
		retValue = m_pTransMngr->InitialiseTransProcess(cardNo);
	}
	return retValue;
}
//******************************************************
// ResetCardChanDataItems()
///
/// Reset channel readings.
///
/// 
//******************************************************
void CAICard::ResetCardChanDataItems(void) {
	// Initialise the reading data items for card
	ResetRawVoltageReadings();
}
//******************************************************
// ResetAICardDataItems()
///
/// Reset all the AI card specific DIT values.
///
/// @return TRUE
/// 
//******************************************************
BOOL CAICard::ResetAICardDataItems() {
	BOOL retValue = TRUE;
	// Reset the card specific items
	if (ResetCardDataItems() == FALSE)
		retValue = FALSE;
	// Reset the channel specific items
	ResetCardChanDataItems();
	return retValue;
}
//******************************************************
// ResetCardDataItems()
///
/// Reset the AI card DIT values.
///
/// @return TRUE if the data items can be failed; otherwise FALSE
/// 
//******************************************************
BOOL CAICard::ResetCardDataItems(void) {
	BOOL retValue = TRUE;
	// Initialise the RT readings
	ResetRTReadingState();
	// Initialise the CJC readings
	retValue = FailBoardCJC();
	return retValue;
}
//******************************************************
// FailBoardCJC()
///
/// Fail the AI Card CJC DIT values.
///
/// @return TRUE if the data items can be failed; otherwise FALSE
/// 
//******************************************************
BOOL CAICard::FailBoardCJC(void) {
	class CSlotMap *pSlotMap = NULL;
	CDataItem *pCJCDataItem = NULL;
	CDataItem *pCJC_C_DataItem = NULL;
	BOOL retValue = TRUE;
	USHORT CJCNo;
	USHORT CJCDegCNo;
	pSlotMap = CSlotMap::GetHandle();
	if (pSlotMap != NULL) {
		// Initiliase the CJC data items for card
		int slotInstanceNo = BoardSlotInstance();
		if (pSlotMap->ObtainBoardsDICJCRef(slotInstanceNo, &CJCNo, &CJCDegCNo) == TRUE) {
			// Set the localised CJC reading to unknown
			pCJCDataItem = pDIT->GetDataItemPtr(DI_IO, DI_IO_MISC, CJCNo);
			pCJC_C_DataItem = pDIT->GetDataItemPtr(DI_IO, DI_IO_MISC, CJCDegCNo);
			retValue = UpdateCJCDataItemInvalidStatus(pCJCDataItem, pCJC_C_DataItem);
			// invalidate all other CJC slots
			for (int cjcCount = 0; cjcCount < CAIRanges::MAX_CJCS; cjcCount++) {
				CJCDegCNo = CDataItemTypeIO::GetCJCDIRef(slotInstanceNo, cjcCount * 2, true);
				CJCNo = CDataItemTypeIO::GetCJCDIRef(slotInstanceNo, cjcCount * 2, false);
				pCJC_C_DataItem = pDIT->GetDataItemPtr(DI_IO, DI_IO_CJC_MULTI_CHAN, CJCDegCNo);
				pCJCDataItem = pDIT->GetDataItemPtr(DI_IO, DI_IO_CJC_MULTI_CHAN, CJCNo);
				retValue = UpdateCJCDataItemInvalidStatus(pCJCDataItem, pCJC_C_DataItem);
			}
		} else {
			retValue = FALSE;
		}
	} else {
		retValue = FALSE;
	}
	return retValue;
}
//******************************************************
// UpdateCJCDataItemInvalidStatus()
///
/// Updates the specified CJC items with the invalid status
/// 
//******************************************************
BOOL CAICard::UpdateCJCDataItemInvalidStatus(CDataItem *pCJCDataItem, CDataItem *pCJC_C_DataItem) {
	BOOL retValue = TRUE;
	if (pCJC_C_DataItem != NULL) {
		pCJC_C_DataItem->SetStatus(DISTAT_INVALID);
	} else {
		retValue = FALSE;
	}
	if (pCJCDataItem != NULL) {
		pCJCDataItem->SetStatus(DISTAT_INVALID);
	} else {
		retValue = FALSE;
	}
	return retValue;
}
//******************************************************
// UpdateCJCDataItems()
///
/// Updates the specified CJC items with the passed in values
/// 
//******************************************************
void CAICard::UpdateCJCDataItems(CDataItem *pCJCDataItem, CDataItem *pCJC_C_DataItem, float cjcVal) {
	if (pCJC_C_DataItem != NULL) {
		// Register the CJC value with the system info, this will generate a recorder wide max an min CJC temp seen
		pSYSTEM_INFO->RegisterNewCJCValue(cjcVal);
		// Save the Deg C internal use value
		pCJC_C_DataItem->SetValue(cjcVal);
		pCJC_C_DataItem->SetStatus(DISTAT_NORMAL);
	}
	// Convert the temperature (if needed) to the localised units and store in the display data item table
	if (pCJCDataItem != NULL) {
		///< If the temperature output is not Deg C, then convert
		cjcVal = pSYSTEM_INFO->GetLocalTempFromDegC(cjcVal);
		// Store the converted temperature in the data item table
		pCJCDataItem->SetValue(cjcVal);
		pCJCDataItem->SetStatus(DISTAT_NORMAL);
	}
}
//**********************************************************************
/// Obtains the I/O board designator
///
/// @param[out] IDText - Card designator ID text.
///
//**********************************************************************
void CAICard::GetIOCardStrID(QString *pIDText) const {
#ifndef V6IOTEST
	*pIDText = QWidget::tr("AI");
#endif
}
//**********************************************************************
/// Obtains the I/O board designator
///
/// @param[out] pIDText - Card description.
///
//**********************************************************************
void CAICard::GetIOCardStrDescription(QString *pIDText) {
	QString cardText;
	class CSlotMap *pSlotMap = NULL;
	class CBrdInfo *pBrdInfo = NULL;
	WCHAR boardSlotStr[4];
	pSlotMap = CSlotMap::GetHandle();
	pBrdInfo = CBrdInfo::GetHandle();
	if (pSlotMap != NULL)
		pSlotMap->GetSlotStrID(BoardSlotInstance(), boardSlotStr);
	GetIOCardStrID(&cardText);
    *pIDText = QString::asprintf(IDS_BOARD_IN_SLOT, cardText.toLocal8Bit().data(), pBrdInfo->GetNoOfChannels(BoardSlotInstance()), boardSlotStr);
}
//**********************************************************************
/// Gets the local configuration handle.
///
/// @return	The local configuration handle, if one exist otherwise NULL
//**********************************************************************
class CAIConfig* CAICard::GetLocalConfigHandle(void) {
	return m_pAIConfigObj;
}
//**********************************************************************
/// CalculateChannelReadRate()
///
/// Calculates the channel read rate.
///
/// @param[in] ChanNo - Card slot channel number.
///
/// @return		The number of mS between reads on this channel
//**********************************************************************
USHORT CAICard::CalculateChannelReadRate(UCHAR chanNo) {
	return m_pAIConfigObj->CalculateChannelReadRate(chanNo);
}
//**********************************************************************
/// GetChannelAcqRate()
///
/// Gets the channel acqusition rate.
///
/// @param[in] ChanNo - Card slot channel number.
///
/// @return		The number of mS between acqusitions on this channel
//**********************************************************************
USHORT CAICard::GetChannelAcqRate(const UCHAR chanNo) const {
	return m_pAIConfigObj->GetChannelAcqRate(chanNo);
}
//******************************************************
///
/// Queries whether a channel is currently configured as a TC
/// @param[in] chanNo - The card channel number.
///
/// @return TRUE if the channel is currently set as a TC; otherwise FALSE
/// 
//******************************************************
BOOL CAICard::QueryIsChanATC(const USHORT chanNo) const {
	return m_pAIConfigObj->QueryIsChanATC(chanNo);
}
//******************************************************
///
/// Queries whether any channel is enabled
///
/// @return The bit mask of the enabled channels
/// 
//******************************************************
USHORT CAICard::QueryAnySlotChannelEnabled(void) const {
	return m_pAIConfigObj->QueryAnySlotChannelEnabled();
}
//**********************************************************************
/// GetAnalRTCalChan()
///
/// Gets the first channel that requires an RT cal obtained.
///
/// @param[in] cardNo - Card slot number identification.
/// @param[Out] pChanNo - The first slot channel number of an RT cal requiring service
///
/// @return	TRUE - if there is a channel to service
//**********************************************************************
BOOL CAICard::GetAnalRTCalChan(const USHORT cardNo, UCHAR *pChanNo) const {
	class CBrdStats *pStatsInfoObj = NULL;
	BOOL retValue = FALSE;
	UCHAR chanNo;
	pStatsInfoObj = CBrdStats::GetHandle();
	if (pStatsInfoObj != NULL) {
		for (chanNo = 0; chanNo < TOPSLOT_AICHAN_SIZE; chanNo++) {
			if (pStatsInfoObj->IsChannelRTCalRqd(cardNo, chanNo) == TRUE) {
				*pChanNo = chanNo;
				retValue = TRUE;
				break;
			}
		}
	}
	return retValue;
}
//**********************************************************************
/// GetAnalRTCompChan()
///
/// Gets the first channel that requires an RT comp obtained.
///
/// @param[in] cardNo - Card slot number identification.
/// @param[Out] pChanNo - The first slot channel number of an RT comp requiring service
///
/// @return	TRUE - if there is a channel to service
//**********************************************************************
BOOL CAICard::GetAnalRTCompChan(const USHORT cardNo, UCHAR *pChanNo) const {
	class CBrdStats *pStatsInfoObj = NULL;
	BOOL retValue = FALSE;
	UCHAR chanNo;
	pStatsInfoObj = CBrdStats::GetHandle();
	if (pStatsInfoObj != NULL) {
		for (chanNo = 0; chanNo < TOPSLOT_AICHAN_SIZE; chanNo++) {
			if (pStatsInfoObj->IsChannelRTCompRqd(cardNo, chanNo) == TRUE) {
				*pChanNo = chanNo;
				retValue = TRUE;
				break;
			}
		}
	}
	return retValue;
}
//******************************************************
// SetLastRTCalReadTime()
///
/// Sets the system tick that RT cal was last saved.
///
/// @param[in] chanNo - I/O board channel number.
/// @param[in] timeRead - The time value was last valid.
///
//******************************************************
void CAICard::SetLastRTCalReadTime(UCHAR chanNo, LONGLONG timeRead) {
	m_AILastRTCalSystemTick[chanNo] = timeRead;	///< System tick that RT cal was last saved
	m_startRTCalCheckRqd[chanNo] = FALSE;
}
//******************************************************
// SetLastRTCompReadTime()
///
/// Sets the system tick that RT comp was last saved.
///
/// @param[in] chanNo - I/O board channel number.
/// @param[in] timeRead - The time value was last valid.
///
//******************************************************
void CAICard::SetLastRTCompReadTime(UCHAR chanNo, LONGLONG timeRead) {
	m_AILastRTCompSystemTick[chanNo] = timeRead;	///< System tick that RT comp was last saved
	m_startRTCompCheckRqd[chanNo] = FALSE;
}
#define RT_COMP_CAL_STARTUP_TIMEOUT 3000
//******************************************************
// CheckLastRTCalReadTime()
///
/// Checks whether the system tick whether RT cal update has timed out
///
/// @param[in] timeRead - The time now.
///
/// @return TRUE if timeout has been reached, otherwise FALSE 
/// 
//******************************************************
BOOL CAICard::CheckLastRTCalReadTime(LONGLONG timeNow) {
	UCHAR chanNo;
	USHORT chanType;
	BOOL retValue = FALSE;
	// Do not check until card is allowed to receive data
	if (m_NormOpPending.Board.ChanRead == TRUE) {
		for (chanNo = 0; chanNo < m_ChanList.GetListCount(); chanNo++) {
			if (m_startRTCalCheckRqd[chanNo] == TRUE) {
				// Time has been set, so test
				m_pAIConfigObj->QueryAISlotChannelSelection(chanNo, &chanType);
				if ((chanType == AI_CHANNEL_TYPE_RT) || (chanType == AI_CHANNEL_TYPE_LINEAR_OHMS)) {
					// Check each channel that is an RT or resistance measurement
					if (timeNow > (m_AILastRTCalSystemTick[chanNo] + RT_COMP_CAL_STARTUP_TIMEOUT)) {
						retValue = TRUE;
						m_startRTCalCheckRqd[chanNo] = FALSE;
					}
				}
			}
		}
	}
	return retValue;
}
//******************************************************
// CheckLastRTCompReadTime()
///
/// Checks whether the system tick whether RT comp update has timed out
///
/// @param[in] timeRead - The time now.
///
/// @return TRUE if timeout has been reached, otherwise FALSE 
/// 
//******************************************************
BOOL CAICard::CheckLastRTCompReadTime(LONGLONG timeNow) {
	UCHAR chanNo;
	USHORT chanType;
	BOOL retValue = FALSE;
	// Do not check until card is allowed to receive data
	if (m_NormOpPending.Board.ChanRead == TRUE) {
		for (chanNo = 0; chanNo < m_ChanList.GetListCount(); chanNo++) {
			if (m_AILastRTCompSystemTick[chanNo] > 0) {
				// Time has been set, so test
				m_pAIConfigObj->QueryAISlotChannelSelection(chanNo, &chanType);
				if ((chanType == AI_CHANNEL_TYPE_RT) || (chanType == AI_CHANNEL_TYPE_LINEAR_OHMS)) {
					// Check each channel that is an RT or resistance measurement
					if (timeNow > (m_AILastRTCompSystemTick[chanNo] + RT_COMP_CAL_STARTUP_TIMEOUT)) {
						retValue = TRUE;
						m_startRTCompCheckRqd[chanNo] = FALSE;
					}
				}
			}
		}
	}
	return retValue;
}
//******************************************************
// InitialiseCardConfig()
///
/// Create the local configuration for the I/O card from the CMM.
///
/// @return TRUE if local configuration could be created, otherwise FALSE 
/// 
//******************************************************
BOOL CAICard::InitialiseCardConfig(void) {
	BOOL retValue = FALSE;
	m_NormOpPending.CommandModeToProc = IO_CONFIGCHECK;
	RunProcess();
	if ((m_pAIRanges != NULL) && (m_pTransMngr != NULL) && (m_pConfigMngrObj != NULL)) {
		// Initialise local configuration
		m_pAIConfigObj = m_pConfigMngrObj->CreateAILocalConfigHolder(m_Instance);
		if (m_pAIConfigObj != NULL)
			retValue = m_pAIConfigObj->InitialiseCardConfigHolder(this);
		if (retValue != FALSE) {
//			m_NormOpPending.CommandModeToProc = IO_CONFIGCHECK;
//			RunProcess();
			// Create instances of the channel holders
			retValue = InitialiseChannels();
		}
	} else {
		qDebug("Error - CAICard support services unavailable");
	}
	// If not test equipment we need to obtain readings and allow for startup error
	if (IsRunningAsATEEquipment() == FALSE)
		m_FirstReadRqd = TRUE;
	// No devices on board have failed yet; with this configuration
	m_DeviceFailed = FALSE;
	m_DataFromCard = FALSE;
	m_CJCFailed = FALSE;
	// Reschedule highest priority channels first
	m_PriorityScheduleRqd = PRIORITY_1;
	return retValue;
}
//******************************************************
// SetupConfigChangePreparation()
///
/// Sets all AI services on a setup commit change preperation
///
/// @return TRUE on success; otherwise FALSE
/// 
//******************************************************
BOOL CAICard::SetupConfigChangePreparation(void) {
	BOOL retValue = TRUE;
	EmptyStartupList();
	return retValue;
}
//******************************************************
// DoesBoardRqSched()
///
/// Queries whether the I/O board requires periodic scheduling.
///
/// @return TRUE if the I/O card requires periodic scheduling 
/// 
//******************************************************
BOOL CAICard::DoesBoardRqSched(void) {
	return TRUE;
}
//******************************************************
// IOCardCommand()
///
/// Sends a user command to the I/O boards.
/// @param[in] newCmd - I/O board command.
///
/// @return IOCARDSTAT (IOSTAT_CMDOK) if successful otherwise IOCARDSTAT fail code 
/// 
//******************************************************
IOCARDSTAT CAICard::IOCardCommand( USHORT newCmd) {
	class CProtocol *pProtocolHnd = NULL;
	IOCARDSTAT retValue = IOSTAT_CMDOK;
	// Remove unprocessed commands from queue
//	if( newCmd != IO_HISTORYUPLOAD )
//	{
//		ResetStateMachine();
//	}
	// Load new command into the state machine sequencer
	m_NormOpPending.CommandModeToProc = newCmd;
	switch (newCmd) {
	case IO_RESET:
		// I/O H/W reset instructed
		// Data reset instructed
		break;
	case IO_CONFIGCHECK:
		// Configuration check instructed
		break;
	case IO_CONFIGDOWNLOAD:
		// Configuration download to board instructed
		break;
	case IO_CALIBRATION:
		// Unit calibration mode instructed
		break;
	case IO_CONFIGUPLOAD:
		// configuration upload to recorder instructed
		break;
	case IO_HISTORYUPLOAD:
		// History upload to recorder instructed
		break;
	case IO_ACQUIRE:
		// Normal acquisition mode commanded	so reschedule all I/O cards
		break;
	case IO_IDLE:
		// Module commanded to enter IDLE mode
		break;
	};
	// Execute new command; and update state machine
	pProtocolHnd = m_pTransMngr->RequestTransToken(this);
	if (pProtocolHnd != NULL) {
		if (OperateTransactionSM(pProtocolHnd) == FALSE) {
			retValue = IOSTAT_CMDFAILED;
		}
	}
//	if( SetNextRunTime() == TRUE )
	SetNextRunTime();
// retValue =
	return retValue;
}
//******************************************************
// SetSpecialTestMode()
///
/// Sets the special test mode were boards hidden functionality are made visible.
/// @param[in] state - Whether special test mode is enabled or disabled.
///
/// @return TRUE if the I/O board has a special test mode; otherwise FALSE.
/// 
//******************************************************
BOOL CAICard::SetSpecialTestMode(const BOOL state) {
	return FALSE;
}
//******************************************************
// ResetStateMachine()
///
/// Reset the AI acqusition state machine.
///
/// @return Nothing
/// 
//******************************************************
void CAICard::ResetStateMachine(void) {
	UCHAR channel = 0;
	// Reset state machine
	for (channel = 0; channel < m_pBrdInfoObj->GetNoOfChannels(m_Instance); channel++) {
		m_AINormOpPending.Channel[channel].ChannelPending.RTCal = FALSE;		// No RTCal read pending
		m_AINormOpPending.Channel[channel].ChannelPending.RTComp = FALSE;		// No RTComp read pending
		m_AINormOpPending.Channel[channel].ChannelPending.RdPending = FALSE;		// No channel reading pending
		m_AINormOpPending.Channel[channel].ChannelPending.RdTaken = FALSE;		// No channel reading taken
	}
	CIOCard::ResetStateMachine();
}
//******************************************************
// ResetRTReadingState()
///
/// Reset the AI RT comp & cal acqusition state machine.
///
/// @return Nothing
/// 
//******************************************************
void CAICard::ResetRTReadingState(void) {
	UCHAR channel = 0;
	float noCJCReadingYet = 0.0F;
	float noRTCalReadingYet = 0.0F;
	float noRTCompReadingYet = 0.0F;
	USHORT sysAIChan = 0;
	class CSlotMap *pSlotMap = NULL;				///< System slot map
	class CDataItem *pDataItem = NULL;
	class CInputConditioning *pICService = NULL;				///< Input conditioning service
	class CPPIOServiceManager *pServiceManagerObj = NULL;	///< Service manager
	class CBrdInfo *pBrdInfoObj = NULL;					///< Board info holder
	class CBrdStats *pBrdStatsObj = NULL;				///< Board stats holder
	pSlotMap = CSlotMap::GetHandle();
	pBrdInfoObj = CBrdInfo::GetHandle();
	pBrdStatsObj = CBrdStats::GetHandle();
	pServiceManagerObj = CPPIOServiceManager::GetHandle();
	if (pServiceManagerObj != NULL)
		pICService = pServiceManagerObj->GetICService();
	if (pICService != NULL) {
		pICService->CreateFloatingPointRepresentation( IO_SCHED_MISSING_CJC, &noCJCReadingYet);
		pICService->CreateFloatingPointRepresentation( IO_SCHED_MISSING_RT_COMP, &noRTCompReadingYet);
		pICService->CreateFloatingPointRepresentation( IO_SCHED_MISSING_RT_CAL, &noRTCalReadingYet);
	}
	pBrdInfoObj->SetDegCCJCReading(m_Instance, noCJCReadingYet);
	for (int cjcCount = 0; cjcCount < CAIRanges::MAX_CJCS; cjcCount++) {
		pBrdInfoObj->SetDegCCJCReading(m_Instance, cjcCount, noCJCReadingYet);
	}
	for (channel = 0; channel < m_pBrdInfoObj->GetNoOfChannels(m_Instance); channel++) {
		// Invalidate the current RT comp channel reading
		if (pSlotMap != NULL) {
			sysAIChan = pSlotMap->GetSysChannelFromAnaInChannel(m_Instance, channel, ONE_BASED);
		}
		if (pDIT != NULL) {
			// Initialise the RT comp data items for card
			pDataItem = pDIT->GetDataItemPtr(DI_IO, DI_IO_RT_COMP, sysAIChan);
			if (pDataItem != NULL) {
				pDataItem->SetValue(noRTCompReadingYet);
				pDataItem->SetStatus(DISTAT_INVALID);
			}
		}
		// Invalidate the current RT comp channel reading
		if (pDIT != NULL) {
			// Initialise the RT cal data items for card
			pDataItem = pDIT->GetDataItemPtr(DI_IO, DI_IO_RT_CAL, sysAIChan);
			if (pDataItem != NULL) {
				pDataItem->SetValue(noRTCalReadingYet);
				pDataItem->SetStatus(DISTAT_INVALID);
			}
		}
		// Reset state machine
		pBrdStatsObj->SetChannelRTCalRqdState(m_Instance, channel, FALSE);
		pBrdStatsObj->SetChannelRTCompRqdState(m_Instance, channel, FALSE);
//		m_AINormOpPending.Channel[channel].ChannelPending.RTCal = FALSE;			// No RTCal read pending 
//		m_AINormOpPending.Channel[channel].ChannelPending.RTComp = FALSE;			// No RTComp read pending
//		m_AINormOpPending.Channel[channel].ChannelPending.RdPending = FALSE;		// No channel reading pending
//		m_AINormOpPending.Channel[channel].ChannelPending.RdTaken = FALSE;			// No channel reading taken
	}
}
//******************************************************
// CMMCreateLocalConfig()
///
/// Load the global configuration from the CMM and create the locally held one.
///
/// @return TRUE if successful created local configuration; otherwise FALSE
/// 
//******************************************************
BOOL CAICard::CMMCreateLocalConfig(void) {
	class CBrdInfo *pBrdInfoObj = NULL;
	class CBrdStats *pBrdStatsObj = NULL;
	BOOL chanEnabled = FALSE;
	USHORT chanToRead = 0;
	USHORT AIAcqRate = 0;
	BOOL retValue = FALSE;
	retValue = m_pAIConfigObj->CMMSlotLoad();
	pBrdInfoObj = CBrdInfo::GetHandle();
	pBrdStatsObj = CBrdStats::GetHandle();
	if ((QueryAnySlotChannelEnabled() != 0) || (IsRunningAsATEEquipment() == TRUE)) {
		if (m_FirstReadRqd == TRUE) {
			// Ensure that priority is given to 10Hz on startup (50Hz has already lost data)
			// and that during normal operation 50Hz operation becomes the most needy
			for (chanToRead = 0; chanToRead < MAX_AI_BOARD_CHANNELS; chanToRead++) {
				if (chanToRead < pBrdInfoObj->GetNoOfChannels(m_Instance)) {
					AIAcqRate = m_pAIConfigObj->GetChannelAcqRate(static_cast<UCHAR>(chanToRead));
					m_pAIConfigObj->QuerySlotChannelEnabled(chanToRead, &chanEnabled);
					switch (AIAcqRate) {
					case AI_ACQ_RATE_2HZ:
						m_chanInitPriority[chanToRead] = PRIORITY_3;
						m_chanRunPriority[chanToRead] = PRIORITY_2;
						break;
					case AI_ACQ_RATE_5HZ:
						m_chanInitPriority[chanToRead] = PRIORITY_2;
						m_chanRunPriority[chanToRead] = PRIORITY_2;
						break;
					case AI_ACQ_RATE_10HZ:
						m_chanInitPriority[chanToRead] = PRIORITY_1;
						m_chanRunPriority[chanToRead] = PRIORITY_2;
						break;
					case AI_ACQ_RATE_50HZ:
						m_chanInitPriority[chanToRead] = PRIORITY_4;
						m_chanRunPriority[chanToRead] = PRIORITY_1;
						break;
					default:
						m_chanInitPriority[chanToRead] = PRIORITY_2;
						m_chanRunPriority[chanToRead] = PRIORITY_2;
						break;
					}
					if (chanEnabled == TRUE) {
						SetBits(&m_totalChanMask, 1, chanToRead, 1);
						SetBits(&m_PriorityChanMask[m_chanRunPriority[chanToRead] - 1], 1, chanToRead, 1);
					}
				}
			}
			// Ensure that the highest priority with channels available is used
			if (m_totalChanMask != 0) {
				while (m_PriorityChanMask[m_PriorityScheduleRqd - 1] == 0) {
					// If this priority schedule has no channels, then do not waste time on it
					m_PriorityScheduleRqd++;
					if (m_PriorityScheduleRqd > TOTAL_AI_BOARD_PRIORITIES) {
						break;			// Tried all and nothing to schedule - Problem should never occur
					}
				}
			}
			m_chanReadMask = 0;
			m_FirstReadRqd = FALSE;
		}
	}
//	if(retValue != FALSE)
//	{
//		retValue = m_pAIConfigObj->ConvertLocalConfig( );
//	}
//	return m_pAIConfigObj->CMMCreateLocalConfig( );
	return retValue;
}
//******************************************************
// ScheduleBoardProcess()
///
/// Schedule each of the channels read times.
///
/// @return TRUE if successful scheduled; otherwise FALSE
/// 
//******************************************************
BOOL CAICard::ScheduleBoardProcess(void) {
	UCHAR channel;
	LONGLONG RdNextScheduledTime;
	// Next time to schedule error message download
//	if( m_NormOpPending.Board )
	// Are there are any urgent data compensations to be scheduled	if so these must take priority
	for (channel = 0; channel < MAX_AI_BOARD_CHANNELS; channel++) {
		// Schedule first RTCal channel in need of servicing
		if (m_AINormOpPending.Channel[channel].ChannelPending.RTCal == TRUE) {
			// Start immediate request for RTCal read
			m_NormOpPending.Board.RTCal = TRUE;	// Request RTCal reading on channel
		}
		// Schedule first RTComp channel in need of servicing
		if (m_AINormOpPending.Channel[channel].ChannelPending.RTComp == TRUE) {
			// Start immediate request for RTComp read
			m_NormOpPending.Board.RTComp = TRUE;	// Request RTCal reading on channel
		}
		// Make schedule time
		RdNextScheduledTime = m_pBrdStatsObj->m_schedTimer.timeCheck(
				m_AINormOpPending.Channel[channel].RdNextScheduledTime);
		// Check for channels for which reading is due/overdue
		if (RdNextScheduledTime < m_nextRunTime) {
			m_nextRunTime = RdNextScheduledTime;
//			m_NormOpPending.Board.ChanRead = TRUE;
		}
	}
	return TRUE;
}
//******************************************************
// ScheduleNextChannelProcess()
///
/// Schedules the next ideal channel read times for channels just processed.
///
/// @return TRUE
/// 
//******************************************************
BOOL CAICard::ScheduleNextChannelProcess(void) {
	UCHAR channel;
	if (m_FirstReadRqd == TRUE) {
		// For first release discard all board data on startup
		m_NormOpPending.Board.DataReset = TRUE;
//		m_NormOpPending.Board.ChanRead = FALSE;
	} else {
		// Once the initial readings have been downloaded/discarded then return to normal mode
//		m_FirstReadRqd = FALSE;
//		m_NormOpPending.Board.ChanRead = TRUE;
	}
	// @todo: Only schedule next channel reading if there are no higher priority tasks required
	if (0) {
		return FALSE;	// Cannot yet schedule
	}
	for (channel = 0; channel < MAX_AI_BOARD_CHANNELS; channel++) {
		// Run through and schedule all channels just processed that need servicing
		if (m_AINormOpPending.Channel[channel].ChannelPending.RdTaken == TRUE) {
			m_AINormOpPending.Channel[channel].RdNextScheduledTime = CTimer::scheduleReferencedRuntime(
					m_AINormOpPending.Channel[channel].RdLastScheduledTime,
					m_AINormOpPending.Channel[channel].RdInterval);
			INormOpPending.Channel[channel].ChannelPending.RdTaken = FALSE;
		}
	}
	return TRUE;
}
//******************************************************
//  RunProcess()
///
/// Virtual function implementation
/// Performs a time slice action for an instance of a card slot
/// The CardSlot class must decide what action is required based
/// on the current action and action state.
///
/// @return TRUE
///
//******************************************************
BOOL CAICard::RunProcess(void) {
#ifdef OVERALL_TIMMINGS_RQD
 static  CTV6Timer scheduleTimer(TIMER_HIGH_RES);	 	 // Total time in this 'timeslice'
 CTV6Timer transTimer(TIMER_HIGH_RES);	 	 // Total time in this 'timeslice'
 LONGLONG timetaken = (LONGLONG) 0L;
 static BOOL scheduleTimed = FALSE;
#endif
	class CProtocol *pProtocolHnd = NULL;
	BOOL retValue = FALSE;
#ifdef OVERALL_TIMMINGS_RQD
 if( scheduleTimed == TRUE )
 {
 // Calculate the time that the state machine was active
 scheduleTimer.StopTimer();
 timetaken = scheduleTimer.GetTimeInMicroSec(TIMER_SINGLE);
 qDebug(L"Wait took %dmS\n", static_cast<int> (timetaken / 1000));
 }
 // Tranaction timer reset
 transTimer.ResetAllTimers();
 transTimer.StartTimer();
#endif
	pProtocolHnd = m_pTransMngr->RequestTransToken(this);
	if (pProtocolHnd != NULL) {
		// Perform mode change first
		retValue = PerformSMModeChange(pProtocolHnd);
		if ((retValue == TRUE) && (m_pBrdStatsObj->HasIdleModeBeenOrdered() == FALSE)) {
			// Perform operations within mode, only if mode change was valid
			OperateTransactionSM(pProtocolHnd);
		}
	}
	m_pTransMngr->TransactionTerminated();
	// Schedule the next acquire
	retValue = SetNextRunTime();
#ifdef OVERALL_TIMMINGS_RQD
 // Calculate the time that the state machine was active
 transTimer.StopTimer();
 timetaken = transTimer.GetTimeInMicroSec(TIMER_SINGLE);
 qDebug(L"Timeslice took %dmS\n", static_cast<int> (timetaken / 1000));
 scheduleTimer.ResetAllTimers();
 scheduleTimer.StartTimer();
 scheduleTimed = TRUE;
#endif
	return retValue;
}
//**********************************************************************
/// GetRangeRevision
///
/// Obtain the range capabilities revision from the board revision
///
/// @param[in] boardType - The I/O board type.
/// @param[in] BoardRev - The AI board revision identified.
///
/// @return	 	 The AI range revision ID
//**********************************************************************
UCHAR CAICard::GetRangeRevision(const UCHAR boardType, const UCHAR BoardRev) const {
	return m_pAIRanges->GetRangeRevision(boardType, BoardRev);
}
//**********************************************************************
/// GetRangeClosestMatch
///
/// indexOfs the voltage range that supports the whole of the requested range, for a given board revision
///
/// @param[in] RangeRev - The AI range revision to be found.
/// @param[in] RangeType - The AI boards Range type desired.
/// @param[in] UpperRange - The AI boards upper range limit desired.
/// @param[in] LowerRange - The AI boards lower range limit desired.
/// @param[in] engUnits - The AI boards range limit desired - units.
///
/// @return	 	 The range ID code if a suitable one is found; otherwise INVALID_RANGE
//**********************************************************************
UCHAR CAICard::GetRangeClosestMatch(const UCHAR RangeRev, const UCHAR RangeType, const T_RANGE UpperRange,
		const T_RANGE LowerRange, const USHORT engUnits) const {
	return m_pAIRanges->GetRangeClosestMatch(RangeRev, RangeType, UpperRange, LowerRange, engUnits);
}
//**********************************************************************
/// GetChannelRange
///
/// Obtains the channel range of a given range ID
///
/// @param[in] RangeCode - The AI range ID.
/// @param[in] RangeRev - The AI range revision to be found.
/// @param[out] pUpperRange - The AI boards upper range limit.
/// @param[out] pLowerRange - The AI boards lower range limit.
///
/// @return	 	 The same range ID code if confirmed; otherwise INVALID_RANGE
//**********************************************************************
T_PAIRANGEDEF CAICard::GetChannelRange(const T_AIRANGE *pRangeCode, const UCHAR RangeRev,
T_RANGE *pUpperRange, T_RANGE *pLowerRange) const {
	return m_pAIRanges->GetChannelRange(pRangeCode, RangeRev, pUpperRange, pLowerRange);
}
//**********************************************************************
/// GetChannelCalPoints
///
/// Obtains the channel range cal points of a given range ID
///
/// @param[in] RangeCode - The AI range ID.
/// @param[in] RangeRev - The AI range revision to be found.
/// @param[out] pUpperRange - The AI boards upper range limit.
/// @param[out] pLowerRange - The AI boards lower range limit.
///
/// @return	 	 The same range ID code if confirmed; otherwise INVALID_RANGE
//**********************************************************************
T_PAIRANGEDEF CAICard::GetChannelCalPoints(T_PAIRANGE pRangeCode, const UCHAR RangeRev,
T_RANGE *pUpperRange, T_RANGE *pLowerRange, IO_MEASURE_UNITS *pUnits) const {
	return m_pAIRanges->GetChannelCalPoints(pRangeCode, RangeRev, pUpperRange, pLowerRange, pUnits);
}
//**********************************************************************
///GetRangeConfig
///
/// Obtains the channel range configuration and units types
///
/// @param[in] RangeCode - The AI range ID.
/// @param[in] RangeRev - The AI range revision to be found.
/// @param[out] pRange - The AI boards range setup.
/// @param[out] pRangeUnits - The AI boards range units.
///
/// @return	 	 The same range ID code if confirmed; otherwise INVALID_RANGE
//**********************************************************************
BOOL CAICard::GetRangeConfig(T_PAIRANGE pRangeCode, const UCHAR RangeRev, UCHAR *pRangeGain, UCHAR *pRangeUnits) const {
	return m_pAIRanges->GetRangeConfig(pRangeCode, RangeRev, pRangeGain, pRangeUnits);
}
//**********************************************************************
///
/// Get reference to channel local configuration as channel service data
///
/// @param[in] ChanNo - Card slot channel number.
/// @param[out] pChanCfgInfo - Channel configuration info
/// @param[out] pChanWrkInfo - Channel working info
///
/// @return	 	 TRUE if the channel has configuration data available; otherwise FALSE
//**********************************************************************
BOOL CAICard::GetChannelConfigRef(const UCHAR ChanNo, T_AICFGCHANNEL **ppChanCfgInfo,
		T_AIWRKCHANNELCFG **ppChanWrkInfo) const {
	return m_pAIConfigObj->GetChannelConfigRef(ChanNo, ppChanCfgInfo, ppChanWrkInfo);
}
//******************************************************
///
/// Get the next n channel(s) to process from a bit mask
/// Shift along a selection bit pattern to obtain the next n bits and return in lastProcessedMask.
/// @param[in] noOfBitsRqd - The number of bits (max) of the output.
/// @param[in] allBitMask - The bit mask of all possible selections.
/// @param[in/out] lastProcessedMask - The last processed mask passed in and the next one to process out.
///
/// @return TRUE on success; otherwise FALSE.
///
//******************************************************
#define NO_PROCESSED_BITS -1
BOOL PatternBitShift(const USHORT noOfBitsRqd, const USHORT allBitMask, USHORT &processedMask) {
	USHORT testMask = allBitMask;
	BOOL selectBitSet[16];
	UCHAR count = 0;
	UCHAR selectHighBitNo = 0;
	UCHAR selectBitsSet = 0;
	BOOL inhibit = FALSE;
	UCHAR processedHighBitNo = 0;
	UCHAR processedCount = 0;
	char lastProcessedBit = NO_PROCESSED_BITS;
	UCHAR nextProcessBit = 0;
	// indexOf the bits set in the selection mask
	for (count = 0; testMask != 0; testMask >>= 1) {
		if (testMask & 01) {
			selectBitSet[selectHighBitNo] = TRUE;
			selectBitsSet++;
		} else {
			selectBitSet[selectHighBitNo] = FALSE;
		}
		selectHighBitNo++;
	}
	testMask = processedMask;
	// indexOf the bits set in the processed mask
	for (processedCount = 0; testMask != 0; testMask >>= 1) {
		if (testMask & 01) {
			// Track the last channel that has been processed
			processedCount++;
			if (inhibit == FALSE) {
				lastProcessedBit = processedHighBitNo;
			}
		} else if (selectBitSet[processedHighBitNo] == TRUE) {
			// If we have a low bit number processed and then a gap of available selection bits before a
			// high one then the channel selection has wrapped and we do not want the higher bit in this case
			if (lastProcessedBit != NO_PROCESSED_BITS)
				inhibit = TRUE;
		}
		processedHighBitNo++;
	}
	// Set the next channels to process from the last processed channel until the required amount have been set
	// or there are no further channels available to process
	if ((noOfBitsRqd != processedCount) || (processedCount < selectBitsSet)) {
		// There are currently channels available that are not selected, so shift along bit pattern
		count = 0;
		processedMask = 0;		// Reset the process selection
		// Start creating the new process mask from the first selection bit if non previously processed
		// otherwise start from the next unprocessed selection bit
		nextProcessBit = lastProcessedBit + 1;
		do {
			if (nextProcessBit > selectHighBitNo)
				nextProcessBit = 0;								///< Wrap back to the start of selection mask
			if (selectBitSet[nextProcessBit] == TRUE) {
				processedMask |= (1 << nextProcessBit);			///< Set new process selection
				count++;
			}
			nextProcessBit++;
		} while ((count < noOfBitsRqd) || (lastProcessedBit == nextProcessBit));
	}
	return TRUE;
}
//******************************************************
///
/// Get the next high prirority channel(s) to process from a bit mask
/// Shift along a selection bit pattern to obtain the next x-THROUGH_AWAY_BITS bits, and include the recycled bits
///  returned in lastProcessedMask.
/// @param[in] noOfBitsRqd - The maximum number of bits to be serviced.
/// @param[in] allBitMask - The bit mask of all possible selections.
/// @param[in/out] lastProcessedMask - The last processed mask passed in and the next one to process out.
///
/// @return TRUE when all channels in priority schedule have been completed; otherwise FALSE.
///
//******************************************************
#define NO_PROCESSED_BITS		-1
#define THROUGH_AWAY_BITS		 1			///< Only the first channel requested is guaranteed sucessful
BOOL HighPrioritySchedule(const USHORT noOfBitsRqd, const USHORT allBitMask, USHORT &processedMask) {
	USHORT testMask = allBitMask;
	BOOL selectBitSet[16];
	UCHAR count = 0;
	UCHAR selectHighBitNo = 0;
	UCHAR selectBitsSet = 0;
	BOOL inhibit = FALSE;
	UCHAR processedHighBitNo = 0;
	UCHAR processedCount = 0;
	char lastProcessedBit = NO_PROCESSED_BITS;
	UCHAR nextProcessBit = 0;
	BOOL retValue = FALSE;
	// indexOf the bits set in the selection mask
	for (count = 0; testMask != 0; testMask >>= 1) {
		if (testMask & 01) {
			selectBitSet[selectHighBitNo] = TRUE;
			selectBitsSet++;
		} else {
			selectBitSet[selectHighBitNo] = FALSE;
		}
		selectHighBitNo++;
	}
	testMask = processedMask;
	// indexOf the bits set in the processed mask
	for (processedCount = 0; testMask != 0; testMask >>= 1) {
		if (testMask & 01) {
			// Track the last channel that has been processed
			processedCount++;
			if (inhibit == FALSE) {
				lastProcessedBit = processedHighBitNo;
			}
			// Only discard the correct amount of previously processed bits
			if (processedCount == THROUGH_AWAY_BITS) {
				inhibit = TRUE;
			}
		} else if (selectBitSet[processedHighBitNo] == TRUE) {
			// If we have a low bit number processed and then a gap of available selection bits before a
			// high one then the channel selection has wrapped and we do not want the higher bit in this case
			if (lastProcessedBit != NO_PROCESSED_BITS)
				inhibit = TRUE;
		}
		processedHighBitNo++;
	}
	// Set the next channels to process from the last processed channel until the required amount have been set
	// or there are no further channels available to process
	if ((noOfBitsRqd != processedCount) || (processedCount < selectBitsSet)) {
		// There are currently channels available that are not selected, so shift along bit pattern
		count = 0;
		processedMask = 0;		// Reset the process selection
		// Start creating the new process mask from the first selection bit if non previously processed
		// otherwise start from the next unprocessed selection bit
		nextProcessBit = lastProcessedBit + 1;
		do {
			if (nextProcessBit > selectHighBitNo)
				nextProcessBit = 0;								///< Wrap back to the start of selection mask
			if (selectBitSet[nextProcessBit] == TRUE) {
				processedMask |= (1 << nextProcessBit);			///< Set new process selection
				count++;
			}
			nextProcessBit++;
		} while ((count < noOfBitsRqd) || (lastProcessedBit == nextProcessBit));
	}
	return retValue;
}
//******************************************************
//  ChannelsToService()
///
/// Query which channels to service.
///
/// @return The current channel(s) to service
///
//******************************************************
USHORT CAICard::ChannelsToService(void) {
	class CBrdInfo *pBrdInfoObj = NULL;
	class CBrdStats *pBrdStatsObj = NULL;
	BOOL chanEnabled = FALSE;
	USHORT chanToRead = 0;
	USHORT AIAcqRate = 0;
	pBrdInfoObj = CBrdInfo::GetHandle();
	pBrdStatsObj = CBrdStats::GetHandle();
	if ((QueryAnySlotChannelEnabled() != 0) || (IsRunningAsATEEquipment() == TRUE)) {
		if (m_FirstReadRqd == TRUE) {
			// Ensure that priority is given to 10Hz on startup (50Hz has already lost data)
			// and that during normal operation 50Hz operation becomes the most needy
			for (chanToRead = 0; chanToRead < MAX_AI_BOARD_CHANNELS; chanToRead++) {
				if (chanToRead < pBrdInfoObj->GetNoOfChannels(m_Instance)) {
					AIAcqRate = m_pAIConfigObj->GetChannelAcqRate(static_cast<UCHAR>(chanToRead));
					m_pAIConfigObj->QuerySlotChannelEnabled(chanToRead, &chanEnabled);
					switch (AIAcqRate) {
					case AI_ACQ_RATE_2HZ:
						m_chanInitPriority[chanToRead] = PRIORITY_3;
						m_chanRunPriority[chanToRead] = PRIORITY_2;
						break;
					case AI_ACQ_RATE_5HZ:
						m_chanInitPriority[chanToRead] = PRIORITY_2;
						m_chanRunPriority[chanToRead] = PRIORITY_2;
						break;
					case AI_ACQ_RATE_10HZ:
						m_chanInitPriority[chanToRead] = PRIORITY_1;
						m_chanRunPriority[chanToRead] = PRIORITY_2;
						break;
					case AI_ACQ_RATE_50HZ:
						m_chanInitPriority[chanToRead] = PRIORITY_4;
						m_chanRunPriority[chanToRead] = PRIORITY_1;
						break;
					default:
						m_chanInitPriority[chanToRead] = PRIORITY_2;
						m_chanRunPriority[chanToRead] = PRIORITY_2;
						break;
					}
					if (chanEnabled == TRUE) {
						SetBits(&m_totalChanMask, 1, chanToRead, 1);
						SetBits(&m_PriorityChanMask[m_chanRunPriority[chanToRead] - 1], 1, chanToRead, 1);
					}
				}
			}
			// Ensure that the highest priority with channels available is used
			if (m_totalChanMask != 0) {
				while (m_PriorityChanMask[m_PriorityScheduleRqd - 1] == 0) {
					// If this priority schedule has no channels, then do not waste time on it
					m_PriorityScheduleRqd++;
					if (m_PriorityScheduleRqd > TOTAL_AI_BOARD_PRIORITIES) {
						break;			// Tried all and nothing to schedule - Problem should never occur
					}
				}
			}
			m_chanReadMask = 0;
			m_FirstReadRqd = FALSE;
		}
		if ((IsRunningAsATEEquipment() == TRUE) || (pBrdStatsObj->HasLimitedRunModeBeenOrdered() == TRUE)) {
			// The acqusition rate is so slow on the test equipment that we can request all channels continually
			if (pBrdInfoObj != NULL) {
				SetBits(&m_chanReadMask, MAX_OF_ALL_16_CHANNELS, 0, pBrdInfoObj->GetNoOfChannels(m_Instance));
			}
		} else {
			// We need to work out which channels to download
//			if( m_PriorityScheduleRqd == PRIORITY_1 )
//			{
			// Continually request different channels to process, ensuring that all 50Hz channels are obtained singually to ensure
			// that data is not continually returned from the same channel staving the other channels from giving data
//				::PatternBitShift( MAX_PRIORITY_CHANNELS_SIM_DWNLD, m_totalChanMask, m_chanReadMask );
			// When all priority channels have been done then start on the remainder of the channels that can be batched together
//				m_PriorityScheduleRqd++;
//			}
			if (m_totalChanMask > 0) {
				// Continually request batches of channels to process, as long as there are some to process on this card
				if ((PRIORITY_1 == m_PriorityScheduleRqd) && (m_PriorityChanMask[m_PriorityScheduleRqd - 1] > 0)) {
					::HighPrioritySchedule( MAX_PRIORITY_CHANNELS_SIM_DWNLD,
							m_PriorityChanMask[m_PriorityScheduleRqd - 1], m_chanReadMask);
				} else {
					//PSR - Coverity issue fix --Uninitialized pointer read #773596
					if ((m_PriorityScheduleRqd - 1) < TOTAL_AI_BOARD_PRIORITIES) {
						// All slow channels can be obtained together, remembering that 1Hz pulse channels hold back data processing anyway
						::HighPrioritySchedule( MAX_CHANNELS_SIM_DWNLD, m_PriorityChanMask[m_PriorityScheduleRqd - 1],
								m_chanReadMask);
					}
				}
				// Move on to the next priority channels again, when all high priority channels have been completed
				m_PriorityScheduleRqd++;
				// Restart with the priority channels again, when all channels have been completed
				if (m_PriorityScheduleRqd > TOTAL_AI_BOARD_PRIORITIES)
					m_PriorityScheduleRqd = PRIORITY_1;
				while (m_PriorityChanMask[m_PriorityScheduleRqd - 1] == 0) {
					// If this priority schedule has no channels, then do not waste time on it
					m_PriorityScheduleRqd++;
					// Restart with the priority channels again, when all channels have been completed
					if (m_PriorityScheduleRqd > TOTAL_AI_BOARD_PRIORITIES)
						m_PriorityScheduleRqd = PRIORITY_1;
				}
			}
		}
	}
	return static_cast<USHORT>(m_chanReadMask);
}
//******************************************************
//  ScheduleCJCDownload()
///
/// Schedule a download of the current CJC value.
///
/// @return TRUE if successfully scheduled; otherwise FALSE
///
//******************************************************
BOOL CAICard::ScheduleCJCDownload(void) {
	m_NormOpPending.Board.CJC = TRUE;
	return m_NormOpPending.Board.CJC;
}
//******************************************************
///
/// Schedule a download of selected RT Cal channels.
///
/// @return TRUE if successfully scheduled; otherwise FALSE
///
//******************************************************
BOOL CAICard::ScheduleRTCalDownload(void) {
	m_NormOpPending.Board.RTCal = TRUE;
	return m_NormOpPending.Board.RTCal;
}
//******************************************************
///
/// Schedule a download of selected RT Comp channels.
///
/// @return TRUE if successfully scheduled; otherwise FALSE
///
//******************************************************
BOOL CAICard::ScheduleRTCompDownload(void) {
	m_NormOpPending.Board.RTComp = TRUE;
	return m_NormOpPending.Board.RTComp;
}
//******************************************************
//  ScheduleActBrnStatusDownload()
///
/// Schedule a block data download of all AI card active burnout states.
///
/// @return TRUE if successfully scheduled; otherwise FALSE
///
//******************************************************
BOOL CAICard::ScheduleActBrnStatusDownload(void) {
	m_NormOpPending.Board.ActBrnStatusRqd = TRUE;
	return m_NormOpPending.Board.ActBrnStatusRqd;
}
//******************************************************
///
/// Schedule a upload of user Cal points for selected channels.
///
/// @return TRUE if successfully scheduled; otherwise FALSE
///
//******************************************************
BOOL CAICard::ScheduleUserCalUpload(void) {
	m_BoardCmd.UserCalibration = TRUE;
	return m_BoardCmd.UserCalibration;
}
//******************************************************
///
/// Schedule a upload of factory Cal points for selected channels.
///
/// @return TRUE if successfully scheduled; otherwise FALSE
///
//******************************************************
BOOL CAICard::ScheduleFactoryCalUpload(void) {
	m_BoardCmd.FactoryCalibration = TRUE;
	return m_BoardCmd.FactoryCalibration;
}
/////////////////////////////////////////////////////
/// Process all readings and status for one or more channels returned
/// from the block read command
///
/// @param[in] time - Length of time needed to be processed.
///
/// @return TRUE on success; else FALSE.
/////////////////////////////////////////////////////
BOOL CAICard::ProcessMissingAnalBlockTransfer(LONGLONG procTime) {
	USHORT BoardNo = BoardSlotInstance();
	class CBrdStats *pBrdStatsObj = NULL;		///< Board stats holder
	class CBrdInfo *pBrdInfoObj = NULL;		///< Board info holder
	UCHAR chanCount = 0;
	CChanList *pBoardChanLst = NULL;	 // Board channels for processing
	class CIOChanHandler *pChan = NULL;	 	 // General Channel reference
	BOOL illegalChannelUsed = FALSE;	 // Has illegal channel been identified in message
	USHORT chanNo = 0;	 	 	 	 	 // Channel number being processed
	BOOL readingsProcessed = FALSE;	 // Missing readings actually added
	QString errStr;
	pBrdStatsObj = CBrdStats::GetHandle();
	pBrdInfoObj = CBrdInfo::GetHandle();
	if (pBrdInfoObj != NULL)
		chanCount = pBrdInfoObj->GetNoOfChannels(BoardNo);
	ClearAckChannelRecieved();	 	 	 	 	 // No channels to acknowledge yet
	// Update queues from last updated system tick
	for (chanNo = 0; chanNo < chanCount; chanNo++) {
		pBoardChanLst = GetChanSchedule();
		if (pBoardChanLst != NULL)
			pChan = pBoardChanLst->GetChannelRef(chanNo);
		if (pChan != NULL) {
			//	QString   strErr = L"ProcessMissingAnalBlockTransfer";
			////	strErr = QString::asprintf(strErr, (int)numOfBlocksToWriteToPhysicalDisk);
			//	LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_INFO, strErr);
			pChan->AIProcessMissingChannelReadings(m_LastPPQSystemUpdateTick, procTime);
			readingsProcessed = TRUE;
		} else {
			illegalChannelUsed = TRUE;
		}
	}
	return readingsProcessed;
}
//******************************************************
//  ResetRawVoltageReadings()
///
/// Reset raw reading holders to show no valid data
///
//******************************************************
void CAICard::ResetRawVoltageReadings(void) {
	USHORT BoardNo = BoardSlotInstance();
	class CBrdStats *pBrdStatsObj = NULL;		///< Board stats holder
	class CBrdInfo *pBrdInfoObj = NULL;		///< Board info holder
	UCHAR chanCount = 0;
	CChanList *pBoardChanLst = NULL;	 // Board channels for processing
	class CIOChanHandler *pChan = NULL;	 	 // General Channel reference
	USHORT chanNo = 0;	 	 	 	 	 // Channel number being processed
	QString errStr;
	pBrdStatsObj = CBrdStats::GetHandle();
	pBrdInfoObj = CBrdInfo::GetHandle();
	if (pBrdInfoObj != NULL)
		chanCount = pBrdInfoObj->GetNoOfChannels(BoardNo);
	// Update queues from last updated system tick
	for (chanNo = 0; chanNo < chanCount; chanNo++) {
		pBoardChanLst = GetChanSchedule();
		if (pBoardChanLst != NULL)
			pChan = pBoardChanLst->GetChannelRef(chanNo);
		if (pChan != NULL) {
			pChan->ResetRawVoltageReadings();
		}
	}
}
//******************************************************
//  GenerateChannelStartupList()
///
/// Generates the list of RT & ohms channels that will need a startup sequence.
///
/// @return TRUE if successful; otherwise FALSE
///
//******************************************************
BOOL CAICard::GenerateChannelStartupList() {
	UCHAR typeNo = 0;
	CARDLIST *pCardStartupList = NULL;
#ifndef V6IOTEST
	T_AICFGCHANNEL *pChanCfgInfo = NULL;
	T_AIWRKCHANNELCFG *pChanWrkInfo = NULL;
#endif
	BOOL retValue = TRUE;
	UCHAR boardChanNo = 0;
	// Initialise each list entry to empty
	m_startupList.startUpNeeded = FALSE;
	m_startupList.startupCompleted = FALSE;
#if 1
	for (typeNo = 0; typeNo < NO_MONITOR_BANKS_ON_STARTUP; typeNo++) {
		pCardStartupList = &m_startupList.ChanList[typeNo];
		pCardStartupList->Count = 0;
		for (boardChanNo = 0; boardChanNo < MAX_AI_BOARD_CHANNELS; boardChanNo++) {
			pCardStartupList->ChanList[boardChanNo] = INVALID_CHANNEL;
		}
	}
#else
  EmptyStartupList();
#endif
#ifndef V6IOTEST
	// Note: ATE build must startup as quickly as possible
	// Run through config logging all ohms and RT channels
	for (boardChanNo = 0; boardChanNo < MAX_AI_BOARD_CHANNELS; boardChanNo++) {
		m_pAIConfigObj->GetChannelConfigRef(boardChanNo, &pChanCfgInfo, &pChanWrkInfo);
		if ((TRUE == pChanCfgInfo->ChanCfgInfo.Enabled)
				&& ((AI_CHANNEL_TYPE_RT == pChanCfgInfo->UserRange.RangeInfo.ChanType)
						|| (AI_CHANNEL_TYPE_LINEAR_OHMS == pChanCfgInfo->UserRange.RangeInfo.ChanType))) {
			m_startupList.startUpNeeded = TRUE;
			// Add RT & ohms channels to startup sequence list
			for (typeNo = 0; typeNo < NO_MONITOR_BANKS_ON_STARTUP; typeNo++) {
				pCardStartupList = &m_startupList.ChanList[typeNo];
				pCardStartupList->ChanList[pCardStartupList->Count] = boardChanNo;
				(pCardStartupList->Count)++;
			}
		}
	}
#endif
	return retValue;
}
//******************************************************
//  RemoveChannelFromStartupList()
///
/// Removes a single channel from the startup sequence list.
/// @param[in] listTypeNo - The type number of the list being updated.
/// @param[in] boardChanNo - The board channel number to remove from list.
///
/// @return TRUE if channel is successfully removed; otherwise FALSE
///
//******************************************************
BOOL CAICard::RemoveChannelFromStartupList(const UCHAR listTypeNo, const UCHAR boardChanNo) {
	BOOL retValue = FALSE;
	CARDLIST *pCardStartupList = NULL;
	UCHAR chanNo = 0;
	pCardStartupList = &m_startupList.ChanList[listTypeNo];
	if (pCardStartupList->Count > 0) {
		for (chanNo = 0; chanNo < MAX_AI_BOARD_CHANNELS; chanNo++) {
			if (pCardStartupList->ChanList[chanNo] == boardChanNo) {
				// Remove channel from list
				pCardStartupList->ChanList[chanNo] = INVALID_CHANNEL;
				--(pCardStartupList->Count);
				retValue = TRUE;
				break;
			}
		}
	}
	return retValue;
}
//******************************************************
//  EmptyStartupList()
///
/// Initialise the startup sequence to an empty startup list.
///
/// @return TRUE if empty; otherwise FALSE
///
//******************************************************
BOOL CAICard::EmptyStartupList() {
	CARDLIST *pCardStartupList = NULL;
	BOOL retValue = TRUE;
	UCHAR typeNo = 0;
	UCHAR chanNo = 0;
	for (typeNo = 0; typeNo < NO_MONITOR_BANKS_ON_STARTUP; typeNo++) {
		pCardStartupList = &m_startupList.ChanList[typeNo];
		pCardStartupList->Count = 0;
		for (chanNo = 0; chanNo < MAX_AI_BOARD_CHANNELS; chanNo++) {
			pCardStartupList->ChanList[chanNo] = INVALID_CHANNEL;
			m_pBrdStatsObj->ResetChanStatMonitor(m_Instance, chanNo);
		}
	}
	return retValue;
}
//******************************************************
//  IsStartupListEmpty()
///
/// Checks whether there are any channels left that have not been removed from startup sequence.
///
/// @return TRUE if empty; otherwise FALSE
///
//******************************************************
BOOL CAICard::IsStartupListEmpty() {
	BOOL retValue = TRUE;
	UCHAR typeNo = 0;
	for (typeNo = 0; typeNo < NO_MONITOR_BANKS_ON_STARTUP; typeNo++) {
		if (m_startupList.ChanList[typeNo].Count != 0) {
			retValue = FALSE;
		}
	}
	return retValue;
}
//******************************************************
//  IsStartupSeqRqd()
///
/// Checks whether the startup sequence is required.
///
/// @return TRUE if startup sequence is still required to be completed; otherwise FALSE
///
//******************************************************
BOOL CAICard::IsStartupSeqRqd() {
	return m_startupList.startUpNeeded;
}
//******************************************************
//  StartupSeqCompleted()
///
/// Logs the startup sequence as completed.
///
//******************************************************
void CAICard::StartupSeqCompleted() {
	m_startupList.startupCompleted = TRUE;
	m_startupList.startUpNeeded = FALSE;
}
//******************************************************
//  ReportCJCFailureDiagnostics()
///
/// Reports that the CJC has failed
///
/// @return TRUE on Msg Tx & Rx success (i.e. data to process), else FALSE.
///
//******************************************************
BOOL CAICard::ReportCJCFailureDiagnostics( USHORT usBoardNo) {
	BOOL retValue = TRUE;
	// determine the board sub-type
	int boardSubType = WhatBoardSubType();
#ifndef V6IOTEST
	if (boardSubType != AI_CARD_TYPE_V7AI) {
		CErrorControl *pkErrorCtrl = NULL;
		pkErrorCtrl = CErrorControl::Instance();
		// Report burnout recovery to the error control module
		pkErrorCtrl->CJCMissingError(true, usBoardNo);
	} else {
		if (!m_CJCFailed) {
			// this is a new board type so the board is failed rather than missing a CJC
			// so log an error
			WCHAR boardSlotStr[4];
			CSlotMap *pSlotMap = CSlotMap::GetHandle();
			QString errStr = "";
			if (pSlotMap != NULL) {
				pSlotMap->GetSlotStrID(usBoardNo, boardSlotStr);
			}
			errStr = QString::asprintf("CJC error reported by V7 AI card: %s", boardSlotStr);
			AddErrorToReportAsError(errStr.toLocal8Bit().data());
		}
	}
#endif
	m_CJCFailed = TRUE;
	// Fail the stored CJC readings
	retValue = FailBoardCJC();
	return retValue;
}
//******************************************************
//  ReportCJCFailureRecovery()
///
/// Reports that the CJC has recovered
///
/// @return TRUE on Msg Tx & Rx success (i.e. data to process), else FALSE.
///
//******************************************************
BOOL CAICard::ReportCJCFailureRecovery( USHORT usBoardNo) {
#ifndef V6IOTEST
	CErrorControl *pkErrorCtrl = NULL;
	pkErrorCtrl = CErrorControl::Instance();
#endif
	// Report burnout recovery to the error control module
	if ( TRUE == m_CJCFailed) {
		// Only report recovery if failure has already occurred
#ifndef V6IOTEST
		pkErrorCtrl->CJCMissingError(false, usBoardNo);
#endif
		m_CJCFailed = FALSE;
	}
	return TRUE;
}
//******************************************************
//  OperateTransactionSM()
///
/// Main AI transaction state machine.
/// @param[in] pProtocol - Pointer to the I/O board protocol handle.
///
/// @return TRUE if successful; otherwise FALSE
///
//******************************************************
BOOL CAICard::OperateTransactionSM(class CProtocol *pProtocol) {
//	 SYSTEMTIME sysTime;
//	 WCHAR wcSystemTime[100];
	CTV6Timer transTimer(TIMER_HIGH_RES);	 	 // Total time in this 'timeslice'
	CTV6Timer readTimer(TIMER_HIGH_RES);	 	 // Total time of block read
	CTV6Timer ackTimer(TIMER_HIGH_RES);	 	 // Total time of acknowledge
	LONGLONG timetaken = (LONGLONG) 0L;
	LONGLONG readtimetaken = (LONGLONG) 0L;
	LONGLONG acktimetaken = (LONGLONG) 0L;
	BOOL opState = TRUE;
	BOOL nextOpTest = TRUE;
	BOOL exitStateMachine = FALSE;
	BOOL readingSync = FALSE;
	UCHAR CmdProcessed = 0;					// Number of commands processed in this timeslice
	UCHAR dummyChanNo;
//	 USHORT BoardNo;
	m_pProtocol = pProtocol;
	// If entered with an invalid protocol token then fail
	if (m_pProtocol == NULL) {
		return FALSE;
	}
	m_thisStateMCCycles = 0;
	// Tranaction timer reset
	transTimer.ResetAllTimers();
	transTimer.StartTimer();
	// Set the next channel read as pending (if previously enabled)
	m_NormOpPending.Board.ChanRead = m_CardQueryEnabled;
	do {
		if ((IsStartupSeqRqd() == TRUE) && (IsStartupListEmpty() == TRUE)) {
			ScheduleQueueReSync();
			StartupSeqCompleted();
		}
		// Work on highest priority actions first
		// A little delay before each command prevents the driver from responding with an error
		CIOCard::OperateTransactionSM();
		// Need to acknowledge readings yet?
		nextOpTest = m_NormOpPending.Board.AckReadings;
		m_NormOpPending.Board.AckReadings = FALSE;
		if (nextOpTest == TRUE) {
			sleep(INTER_COMMAND_DELAY);
			// If data block was received OK, then acknowledge (this is not a new command but an extension)
			opState = m_pProtocol->ACKGoodAIBlock();
		}
		// Schedule active burnout status download
		nextOpTest = m_NormOpPending.Board.ActBrnStatusRqd;
		m_NormOpPending.Board.ActBrnStatusRqd = FALSE;
		if (nextOpTest == TRUE) {
			sleep(INTER_COMMAND_DELAY);
			opState = m_pProtocol->GetCJCActiveBurnoutState();	 	 // Request burnout status
			m_CmdProcessed++;
		}
		// Schedule CJC if in need of servicing
		nextOpTest = m_NormOpPending.Board.CJC;
		m_NormOpPending.Board.CJC = FALSE;
		if (nextOpTest == TRUE) {
			sleep(INTER_COMMAND_DELAY);
			opState = m_pProtocol->GetCJC();	 	 // Request CJC reading
			if ( FALSE == opState) {
				// Get CJC failed
				ReportCJCFailureDiagnostics(BoardSlotInstance());		// Total failure of CJC
			}
			m_CmdProcessed++;
		}
		// Schedule RT cal read if required
		nextOpTest = m_NormOpPending.Board.RTCal;
		if (nextOpTest == TRUE) {
			sleep(INTER_COMMAND_DELAY);
			opState = m_pProtocol->GetRTCal();	 	 // Request RT cal reading
			m_CmdProcessed++;
			// If no further channels are yet ready then confirm no further RT cal reads required
			if (GetAnalRTCalChan(BoardSlotInstance(), &dummyChanNo) == FALSE)
				m_NormOpPending.Board.RTCal = FALSE;
		}
		// Schedule RT comp read if required; but must come after and RT Cal request
		nextOpTest = m_NormOpPending.Board.RTComp;
		if (nextOpTest == TRUE) {
			sleep(INTER_COMMAND_DELAY);
			opState = m_pProtocol->GetRTComp();	 	 // Request RT comp reading
			m_CmdProcessed++;
			// If no further channels are yet ready then confirm no further RT comp reads required
			if (GetAnalRTCompChan(BoardSlotInstance(), &dummyChanNo) == FALSE)
				m_NormOpPending.Board.RTComp = FALSE;
		}
//	 	 m_NormOpPending.Board.ChanRead = TRUE;
		// Get AI data block; with or without timestamp synchorisation
		nextOpTest = m_NormOpPending.Board.ChanRead;
//	 	 m_NormOpPending.Board.ChanRead = FALSE;
		if (nextOpTest == TRUE) {
			// Schedule time stamp synchronising if required before data block read
			readingSync = m_NormOpPending.Board.Sync;
			m_NormOpPending.Board.Sync = FALSE;
			if ((readingSync == TRUE) && (FALSE == m_DeviceFailed)) {
				sleep(INTER_COMMAND_DELAY);
				// Timestamp this is not a new command but an extenstion to an existing command
				opState = m_pProtocol->GetTimestamp();
				// If timesync was not successful, but was required; then reschedule timesync
				if ((readingSync == TRUE) && (opState == FALSE)) {
					m_NormOpPending.Board.Sync = TRUE;
				}
			}
			// If timesync was required and failed then there is no point getting data that we have no time reference for
			// also if there are no channels to service then do not make any request
			if ((QueryAnySlotChannelEnabled() != 0) || (IsRunningAsATEEquipment() == TRUE)) {
				if (((FALSE == readingSync) || (TRUE == opState)) && (m_DeviceFailed == FALSE)) {
					sleep(INTER_COMMAND_DELAY);
					//Reset for IO card buffer to recover over flow situation(**** issues or PV Freeze) begin
					E_IO_MOD_SUB_ERROR_CODE eSubErrCode = SUB_ERR_NOTHING;
					opState = m_pProtocol->GetAIDataBlock(eSubErrCode);
					if (SUB_ERR_NOTHING != eSubErrCode) {
						if (SUB_ERR_PARTIAL_DATA == eSubErrCode) {
							m_numPartialErrors++;
						} else if (SUB_ERR_AI_BUFFER_OVER_FLOW == eSubErrCode) {
							QString strSlotEr = "";
							strSlotEr = QString::asprintf("AI:OTSM-Slot%d Partial Data but No channel data",
									m_Instance);
							LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, strSlotEr);
							//Reset IO buffer since buffer overflow occured in IO FW and no data has been sent in the packet but Partial error reported in error code.
							//This will have data loss due to reset of existing buf(192 samples) but retrieves the communication
							opState = m_pProtocol->ResetBoardData();
						} else {
							m_numPartialErrors = 0;
						}
					} else {
						//The partial data error should not repeat itself. We reset the number of errors to 0 if there is no error returned from AI card.
						m_numPartialErrors = 0;
					}
					//Reset for IO card buffer to recover over flow situation(**** issues or PV Freeze) end
				}
				if ((FALSE == opState) || (TRUE == m_DeviceFailed)) {
					// Data block failed this time; need to check for a timeout
					LONGLONG thisSystemTick = pGlbSysTimer->GetCurrentSystemTimeTick100();
					LONGLONG TimeDiff = thisSystemTick - m_LastSuccesfulReadSystemTick;
					//USHORT usRetryTime = MAX_STARTUP_RETRY_TIME;
					USHORT usRetryTime = MAX_IO_STARTUP_RETRY_TIME;
					//MAX_IO_STARTUP_RETRY_TIME
					// On start-up the time to wait needs to be much longer; as we are currently
					// seeing timouts of around 13 seconds before missed reading replacement activated.
					TimeDiff = thisSystemTick - m_LastSuccesfulReadSystemTick;
					if ( TRUE == m_DataFromCard) {
						//usRetryTime = MAX_DATA_RETRY_TIME;
						usRetryTime = WAIT_2500ms;
						//usRetryTime = 180000;//3 minutes give breaktime for secondary debugging
					} else if ( TRUE == m_DeviceFailed) {
						// After failure we only need to wait for one reading period before updating PPQ
						//usRetryTime = WAIT_750ms / 10;
						usRetryTime = WAIT_2500ms;
						//usRetryTime = 180000;//3 minutes give breaktime for secondary debugging
						TimeDiff = thisSystemTick - m_LastPPQSystemUpdateTick;
					}
					if (TimeDiff >= usRetryTime) {
						// Data block was not obtained for timeout period; so data must be declared invalid
						// for card so that pre-process queues are not held.
						if ( FALSE == m_failureReportAdded) {
							WCHAR boardSlotStr[4];
							QString errStr = "";
							class CSlotMap *pSlotMap = NULL;
							pSlotMap = CSlotMap::GetHandle();
							pSlotMap->GetSlotStrID(m_Instance, boardSlotStr);
							errStr = QString::asprintf(L"%s %s %s", L"I/O Card", boardSlotStr, L"has failed");
							AddErrorToReport(errStr.toLocal8Bit().data());
							m_failureReportAdded = TRUE;
						}
						// Calculate the number of time frames missed and insert the correct number of readings
//						overrun = ProcessMissingAnalBlockTransfer(thisSystemTick);
						ProcessMissingAnalBlockTransfer(thisSystemTick);
						// And store the update tick to continue from next time
						m_LastPPQSystemUpdateTick = thisSystemTick;
						// Note: If communication recovery is possible then readings could be returned from card for times already
						// specified as invalid.
						m_NormOpPending.Board.ChanRead = TRUE;
						m_DeviceFailed = TRUE;
					}
				} else {
					// Reset timeout, if started if good response obtained
					m_LastSuccesfulReadSystemTick = pGlbSysTimer->GetCurrentSystemTimeTick100();
					CmdProcessed++;
				}
			}
			// If block sucessfully transferred then data needs acknowledging
			if ((TRUE == opState) && (FALSE == m_DeviceFailed)) {
				m_NormOpPending.Board.ChanRead = FALSE;
				m_NormOpPending.Board.AckReadings = TRUE;
			}
		}
		// Summarise timeslice exit strategy
		// If a command failed exit state machine after any errors have been downloaded (if possible)
		// to allow fault evaluation
		// Exit after readings have been acknowledged; or not required
		if (m_NormOpPending.Board.AckReadings != TRUE) {
			exitStateMachine = TRUE;
		}
		nextOpTest = FALSE;
	} while (exitStateMachine == FALSE);	 	 	 // Check timeslice exit strategy
	// Calculate the time that the state machine was active
	transTimer.StopTimer();
	timetaken = transTimer.GetTimeInMicroSec(TIMER_SINGLE);
	// If the transaction has failed, then register failure
//	 if( opState == FALSE )
//	 	 TransactionFailed();
	return TRUE;
}
//**********************************************************************
/// Obtains the I/O board life history
///
/// @return - TRUE if the upload of I/O life history was succesful; otherwise FALSE.
///
//**********************************************************************
BOOL CAICard::GetIOLifeHistory(class CProtocol *const pProtocol) {
	BOOL retValue = FALSE;
	retValue = pProtocol->GetAILifeHistory();
	return retValue;
}
//**********************************************************************
/// Saves the I/O board life history
///
/// @return - TRUE if the upload of I/O life history was succesful; otherwise FALSE.
///
//**********************************************************************
BOOL CAICard::SaveIOLifeHistory(class CProtocol *const pProtocol) {
	BOOL retValue = FALSE;
	retValue = pProtocol->SaveAILifeHistory();
	return retValue;
}
//**********************************************************************
/// Checks user calibration points
///
/// @return - TRUE if the user calibration points are within limits; otherwise FALSE.
///
//**********************************************************************
/*
 BOOL CAICard::CheckUserCalibration( )
 {
 BOOL retValue = TRUE;
 UCHAR chanNo;
 UCHAR chanCount;
 UCHAR RangeRev;
 USHORT ChanType;
 USHORT RangeEnum;
 USHORT Intern0;
 USHORT Intern0V;
 USHORT Intern100;
 class CATECal *pATECal = NULL;
 class CBrdInfo *pBrdInfoObj = NULL;		///< Board info holder
 const T_AICHANNELCAL *pAIChanCal = NULL;
 class CAIRanges *pAIRange = NULL;
 pAIRange = CAIRanges::GetHandle();
 pATECal = CATECal::GetHandle();
 pBrdInfoObj = CBrdInfo::GetHandle();
 if( pBrdInfoObj != NULL )
 chanCount = pBrdInfoObj->GetNoOfChannels(BoardSlotInstance());
 for( chanNo = 0; chanNo < chanCount; chanNo++ )
 {
 if( pATECal->GetAIChannelRange( chanNo, &ChanType, &RangeEnum) == TRUE )
 {
 pBrdInfoObj->GetBoardRangeRevision( BoardSlotInstance(), &RangeRev );
 pAIRange->GetBaseInternValues( RangeEnum, RangeRev, &Intern0, &Intern0V, &Intern100);
 }
 // Check each channels cal data in turn
 pAIChanCal = pATECal->GetAIChanDownloadCal( chanNo );
 if( pAIChanCal != NULL )
 {
 pAIChanCal->zeroCount;
 pAIChanCal->spanCount;
 if( pAIChanCal->zeroCount >= pAIChanCal->spanCount )
 {
 // Reject this channel if reverse voltages (or no change) detected for input calibration voltages
 retValue = FALSE;
 }
 }
 }
 return retValue;
 }
 */
//******************************************************
//
/// Change the current operating mode of the AI transaction state machine.
/// @param[in] pProtocol - Pointer to the I/O board protocol handle.
///
/// @return TRUE if successful; otherwise FALSE
///
//******************************************************
BOOL CAICard::PerformSMModeChange(class CProtocol *const pProtocol) {
	class CATECal *pATECal = NULL;
	BOOL opState = TRUE;
	BOOL nextOpTest = FALSE;
	pATECal = CATECal::GetHandle();
	m_pProtocol = pProtocol;
	CIOCard::PerformSMModeChange();
	// Schedule history upload if required
	nextOpTest = m_BoardCmd.HistoryUpload;
	m_BoardCmd.HistoryUpload = FALSE;
	if (nextOpTest == TRUE) {
		SaveIOLifeHistory(m_pProtocol);
	}
	// If the calibration data is required then download
	nextOpTest = m_BoardCmd.AICalQuery;
	m_BoardCmd.AICalQuery = FALSE;
	if (nextOpTest == TRUE) {
		opState = m_pProtocol->GetAICalibrationHistory();	 	// Download AI calibration dates
	}
	nextOpTest = m_BoardCmd.FactoryCalibration;
	m_BoardCmd.FactoryCalibration = FALSE;
	if (nextOpTest == TRUE) {
		// In factory mode set both the factory calibration and user calibration
		sleep(INTER_COMMAND_DELAY);
		opState = m_pProtocol->SetAICalPoints(V6_AI_FACTORY_CAL);	 	// Download AI factory calibration points
//		if( opState == TRUE )
//		{
//			sleep(INTER_COMMAND_DELAY);
//			opState = m_pProtocol->SetAICalPoints( AI_USER_CAL );	 	// Download AI user calibration points
//		}
//		m_pProtocol->UploadAIConfig();
		m_CmdProcessed++;
//		m_pProtocol->GetAICalPoints( AI_FACTORY_CAL );
	}
	nextOpTest = m_BoardCmd.UserCalibration;
	m_BoardCmd.UserCalibration = FALSE;
	if (nextOpTest == TRUE) {
		if (pATECal->CheckUserCalibration() == true) {
			sleep(INTER_COMMAND_DELAY);
			opState = m_pProtocol->SetAICalPoints(V6_AI_USER_CAL);	 		// Download AI user calibration points
			m_CmdProcessed++;
		}
	}
	nextOpTest = m_BoardCmd.ConfigDownload;
	m_BoardCmd.ConfigDownload = FALSE;
	if (nextOpTest == TRUE) {
		m_BoardCmd.AICalQuery = TRUE;
		//		sleep(INTER_COMMAND_DELAY);
		//		opState = m_pProtocol->GetConfigCRC();
//		if( opState == TRUE )
//		{
		sleep(INTER_COMMAND_DELAY);
		opState = m_pProtocol->SetMainsFrequency();	// Select correct mains frequency operation
//		}
		if (opState == TRUE) {
			sleep(INTER_COMMAND_DELAY);
			opState = m_pProtocol->DownloadAIConfig();	 	 // Download AI config to I/O board
			m_CmdProcessed++;
			// Update the time the system was reset
			m_LastPPQSystemUpdateTick = pGlbSysTimer->GetCurrentSystemTimeTick100();
			m_LastSuccesfulReadSystemTick = m_LastPPQSystemUpdateTick;
			if (opState == TRUE) {
				sleep(INTER_COMMAND_DELAY);
				opState = m_pProtocol->ResetBoardData();	 	 // Ensure we get the CJC reading again
			}
//			ResetCardDataItems();
		}
		// Board has been reset so enable reading and later writing to board
		if (IsRunningAsATEEquipment() == TRUE) {
			// When running as test equipment we may need to download direct RT current control
			if (m_BoardCmd.AIRTChanCal == TRUE) {
				opState = m_pProtocol->AIRTCurrentDeselect();
			}
			// When running as test equipment we can start get readings as soon as we can
			m_CardQueryEnabled = TRUE;
			m_NormOpPending.Board.ChanRead = TRUE;
			m_NormOpPending.Board.ChanRead2 = TRUE;
		}
//		if( opState == TRUE )
//		{
		// Resync the queues
//			m_SyncOpPending = TRUE;
		//  and the board data needs resetting
//			m_NormOpPending.Board.DataReset = TRUE;
//			opState = CIOCard::OperateTransactionSM();
//		}
//		// Now reset the data on the board - all previous data is invalid
//		m_pProtocol->ResetBoardData();
	}
	nextOpTest = m_BoardCmd.ConfigUpload;
	m_BoardCmd.ConfigUpload = FALSE;
	if (nextOpTest == TRUE) {
		sleep(INTER_COMMAND_DELAY);
		opState = m_pProtocol->UploadAIConfig();	 	 // Upload AI config from I/O board
		m_CmdProcessed++;
	}
	return TRUE;
}
/////////////////////////////////////////////////////
/// Automatically calibrate each card channel offset to the CJC sensor
///
/// Note: System must already be notified that CJC channel calibration is occurring
///
/// @return The current status of CJC auto calibrate
/////////////////////////////////////////////////////
BOOL CAICard::AIAutoCalibrateCJC(void) {
	class CBrdInfo *pBrdInfo = NULL;			///< Board info holder
	class CATECal *pATECal = NULL;
	UCHAR chanCount = 0;
	BOOL retValue = FALSE;
	pATECal = CATECal::GetHandle();
	if (pATECal != NULL) {
		pATECal->SelectATECardNo(static_cast<UCHAR>(BoardSlotInstance()));
		chanCount = pATECal->QueryATECardNoOfChannel();
		pATECal->ResetRTChanOffsetStatus();
		pATECal->SetCalModeState(CTOM_ATE_CJC_READ);
	}
	if (chanCount > BRDCHANDEF_CHANNEL_0) {
		// Setup I/O H/W channels 2, 3, 6 & 7 as PT100 inputs @ 2Hz
		m_pAIConfigObj->SelectAIChanRTRange(1, AI_RT_RANGE_PT100);
		m_pAIConfigObj->SelectAIChanAcqRate(1, AI_ACQ_RATE_2HZ);
		m_pAIConfigObj->SelectAIChanRTRange(2, AI_RT_RANGE_PT100);
		m_pAIConfigObj->SelectAIChanAcqRate(2, AI_ACQ_RATE_2HZ);
		if (chanCount > BRDCHANDEF_CHANNEL_5) {
			m_pAIConfigObj->SelectAIChanRTRange(5, AI_RT_RANGE_PT100);
			m_pAIConfigObj->SelectAIChanAcqRate(5, AI_ACQ_RATE_2HZ);
		}
		if (chanCount > BRDCHANDEF_CHANNEL_7) {
			m_pAIConfigObj->SelectAIChanRTRange(6, AI_RT_RANGE_PT100);
			m_pAIConfigObj->SelectAIChanAcqRate(6, AI_ACQ_RATE_2HZ);
		}
		if (m_pAIConfigObj->IOCardLocalConfigCommit() == TRUE) {
			if (pATECal != NULL)
				retValue = pATECal->AIAutoCalibrateCJC(20.0);
		} else {
			// Could not select required RT channels
		}
	}
	if (retValue == TRUE) {
		// @todo: Notify status that all CJC channel on card have been calibrated successfully
	} else {
		// @todo: Notify status that one or more CJC channel(s) on card have failed calibration
	}
	// No need to reset board to previous setup - power cycle will reload CMM copy
	return retValue;
}
//******************************************************
//  WhatBoardSubType()
///
/// There can be subtypes for few boards for example AI card(V6AI & V7AI)
/// This function returns the AICard type i.e. T_AI_CARD_TYPE -- V6AI(old) or V7AI(new)
/// @param[in] void.
///
/// @return value - V6AI if the card is of old type otherwise V7AI
/// Rev History
/// @Version	@Date			@Author					@Remarks
/// 1.0			28/Mar/2019		Shankar Rao	Pendyala	IO compatibility with New AI card and Old AI Card
//******************************************************
UCHAR CAICard::WhatBoardSubType(void) {
	UCHAR ucAICardType = AI_CARD_TYPE_INVALID;
	class CBrdInfo *pBrdInfoObj = NULL;					///< Board info holder
	pBrdInfoObj = CBrdInfo::GetHandle();
	UCHAR ucBoardRev;
	if ( TRUE == pBrdInfoObj->GetBoardHardwareRevision(m_Instance, &ucBoardRev)) {
		ucAICardType = CAICard::WhatBoardSubType(ucBoardRev);
	}
	return ucAICardType;
}
//******************************************************
//  WhatBoardSubType()
///
/// There can be subtypes for few boards for example AI card(V6AI & V7AI)
/// This function returns the AICard type i.e. T_AI_CARD_TYPE -- V6AI(old) or V7AI(new)
/// @param[in] usBoardRev - Board Revision number identification.
///
/// @return value - V6AI if the card is of old type otherwise V7AI
/// Rev History
/// @Version	@Date			@Author					@Remarks
/// 1.0			28/Mar/2019		Shankar Rao	Pendyala	IO compatibility with New AI card and Old AI Card
//******************************************************
UCHAR CAICard::WhatBoardSubType(const UCHAR ucBoardRev) {
	T_AI_CARD_TYPE eAICardType = AI_CARD_TYPE_INVALID;
	if (ucBoardRev < V7AI_ISSUE_0) {
		eAICardType = AI_CARD_TYPE_V6AI;
	} else {
		eAICardType = AI_CARD_TYPE_V7AI;
	}
	return eAICardType;
}
//******************************************************
//  WhatIsRawReadingLength()
///
/// There can be subtypes for few boards for example AI card(V6AI & V7AI)
/// This function returns the length of the Channel Reading in bytes based on Board Sub Type
/// @param[in] ucBoardSubType - Board SubType number .
///
/// @return value - Length of the Channel Readings length in bytes
/// Rev History
/// @Version	@Date			@Author					@Remarks
/// 1.0			28/Mar/2019		Shankar Rao	Pendyala	IO compatibility with New AI card and Old AI Card
//******************************************************
UCHAR CAICard::WhatIsRawReadingLength(const UCHAR ucBoardSubType) {
	UCHAR ucReadingLength = sizeof(USHORT);
	if (AI_CARD_TYPE_V7AI == ucBoardSubType) {
		ucReadingLength = sizeof(T_RANGE_COUNTS);
	}
	return ucReadingLength;
}

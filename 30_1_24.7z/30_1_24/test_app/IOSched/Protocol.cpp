/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n Protocol.cpp
/// @n implementation for the board dependant CProtocol class.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
//	28-07-17	Shankar Rao		Added Sub Error Code detection to process error data patterns and identify detailed errors in IO
// 162 Stability Project 1.157.1.3	7/2/2011 4:59:58 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 161 Stability Project 1.157.1.2	7/1/2011 4:38:41 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 160 Stability Project 1.157.1.1	3/17/2011 3:20:36 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 159 Stability Project 1.157.1.0	2/15/2011 3:03:43 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////
#include "Timer.h"
#include "TV6Timer.h"
#include "Conversion.h"
#include "ATECal.h"
#include "AOCard.h"
#include "V6IOErrorCodes.H"
#include "V6globals.h"
#include <stdlib.h>
#include <stdio.h>
#include "InputConditioning.h"
#include "DataItemManager.h"
#include "DataItemIO.h"
#include "CardSlot.h"
#include "IOCard.h"
#include "AICard.h"
#include "DigPulseCard.h"
#include "IOCardStats.h"
#include "IOCardInfo.h"
#include "BrdInfo.h"
#include "BrdStats.h"
#include "DAL.h"
#include "ConfigManager.h"
#include "BoardManager.h"
#include "BaseProtocol.h"
#include "Protocol.h"
#include "SysInfo.h"
#include "Conversion.h"
#include "AOConfig.h"
#include "AIConfig.h"
#include "DigConfig.h"
#include "IOHandler.h"
#include "IOChanHandler.h"
#include "IOCardHandler.h"
#include "V6IO_AI_InputRanges.H"
#include "PPL.h"
#ifndef CPLUSPLUS
#define CPLUSPLUS
#endif
#include "V6crc.h"
#include "V6IOCommandCodes.H"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CProtocol::CProtocol() {
	//	qDebug("Create new CProtocol\n");
}
CProtocol::~CProtocol() {
	//	qDebug("Delete CProtocol class\n");
}
#define MSG_CJC_CHANGED						0
#define MSG_FAULT_LIST_NOT_EMPTY			1
#define MSG_ACTIVE_BURNOUT_STATE_CHANGE		2
/////////////////////////////////////////////////////
/// Process all channel readings from returned protocol message
///
/// @param[in] pData - Pointer to a data buffer holding the AI board data.
/// @param[in] msgLength - Length of data message	in bytes.
///
/// @return TRUE on success, else FALSE.
/// Rev History
/// @Version	@Date			@Author					@Remarks
/// 2.0			29/Mar/2019		Shankar Rao	Pendyala	Protocol compatibility with New AI card and Old AI Card
/////////////////////////////////////////////////////
BOOL CProtocol::ProcessAIReadingsReturn(UCHAR *pData, const USHORT timestampInterval, USHORT msgLength) {
	CChanList *pBoardChanLst = NULL;	// Board channels for processing
	class CIOChanHandler *pChan = NULL;		// General Channel reference
	class CAICard *pAIBoard = NULL;		// AI board reference
	class CSlotMap *pSlotMap = NULL;
	BOOL illegalChannelUsed = FALSE;		// Has illegal channel been identified in message
	USHORT slotNo = 0;					// Slot number being processed
	UCHAR chanNo = 0;					// Channel number being processed
	UCHAR offset = 0;					// Message byte position offset
	DataItem2bytes timestamp;					// Newest reading timestamp (Union; cannot initialise)
	USHORT readingsProcessed = 0;		// Number of readings actually processed
	USHORT bytesProcessed = 0;	// Number of bytes processed for this channel
	USHORT noOfReadings = 0;			// Number of readings to process
	WCHAR slotNoStr[4];
	QString errStr;
	pSlotMap = CSlotMap::GetHandle();
	pAIBoard = static_cast<class CAICard*>(m_pBoard);	// AI board reference
	slotNo = m_pBoard->BoardSlotInstance();
	pSlotMap->GetSlotStrID(slotNo, slotNoStr);
	pAIBoard->ClearAckChannelRecieved();	// No channels to acknowledge yet
	//Get the AI Card subtype to differenticate the RawCount length
	UCHAR ucReadingLength = CAICard::WhatIsRawReadingLength(pAIBoard->WhatBoardSubType());
	// Process each channel in turn	untill all completed or illegal channel specified
	while ((msgLength > 0) && (illegalChannelUsed == FALSE)) {
		pChan = NULL;				// Channel not yet identified
		chanNo = 0;					// Channel number being processed
		offset = 0;					// Message byte position offset
		timestamp.USData = 0;		// Newest reading timestamp
		readingsProcessed = 0;		// Number of readings actually processed
		bytesProcessed = 0;		// Number of bytes processed for this channel
		noOfReadings = 0;			// Number of readings to process
		chanNo = pData[offset];
		offset += sizeof(BYTE);
		// Check channel is within range
		if (chanNo > MAX_AI_BOARD_CHANNELS - 1) {
			errStr = QString::asprintf("Illegal channel %d found in AI readings return card %s", chanNo, slotNoStr);
			LogInternalError(errStr.toLocal8Bit().data());
			return FALSE;		// Illegal message generated from the I/O card
		}
		// Timestamp of latest reading sent by card
		timestamp.UCData[SWAP_BYTE_0] = pData[offset + SWAP_BYTE_1];
		timestamp.UCData[SWAP_BYTE_1] = pData[offset];
		offset += sizeof(USHORT);
		noOfReadings = pData[offset];		// Get number of readings to process
		offset += sizeof(BYTE);
		pBoardChanLst = m_pBoard->GetChanSchedule();
		if (pBoardChanLst != NULL)
			pChan = pBoardChanLst->GetChannelRef(chanNo);
		if (pChan != NULL) {
			timestampInterval;
			readingsProcessed = pChan->ProcessAIChannelReadings(&pData[offset], timestamp.USData, noOfReadings);
			/// Note in the event of failure pre-process queues donot provide undo of any previously loaded buffers
			// Schedule an acknowledgment for the channel if all readings successfully processed
			if (readingsProcessed == noOfReadings)
				pAIBoard->AckChannelRecieved(chanNo);
			bytesProcessed = (readingsProcessed * ucReadingLength) + offset;
		} else {
			illegalChannelUsed = TRUE;
		}
		msgLength -= bytesProcessed;		// Remove channel readings from length remaining to process
		pData += bytesProcessed;		// Move on to the next channel readings
		/// @todo: Need to undo any previously unpacked buffers upon failure
	}
	return TRUE;
}
enum IO_BURNOUT_STATUS {
	ANAL_READINGS_PROCESSED_OK = 0x0,	///< One or more readings processed OK
	ANAL_NO_READINGS,						///< No readings found
	ANAL_MESSAGE_FAILURE,					///< Message block has failed
};
/////////////////////////////////////////////////////
/// Process all readings and status for one or more channels returned
/// from the block read command
/// Schedules the need for CJC	RTCal & RTComp readings
///
/// @param[in] pData - Pointer to a data buffer holding the channel data.
/// @param[in] startByte - Number of bytes already processed.
/// @param[in] count - Number of bytes to process.
///
/// @return TRUE on success	else FALSE.
/////////////////////////////////////////////////////
BOOL CProtocol::ProcessAnalBlockTransfer(UCHAR *pData, const UCHAR startByte,
USHORT count) {
	BOOL retValue = FALSE;		// Ensure that no data is logged as a failure
	WORD newState;
	UCHAR BytesProcessed = 0;
	USHORT BoardNo = m_pBoard->BoardSlotInstance();
	class CAICard *pAICard = static_cast<class CAICard*>(m_pBoard);
	USHORT chanNo;
	class CBrdStats *pBrdStatsObj = NULL;		///< Board stats holder
	class CBrdInfo *pBrdInfoObj = NULL;		///< Board info holder
	UCHAR chanCount = 0;
	if (count > 0) {
		// If messages have errored then no board data can be returned
		pBrdInfoObj = CBrdInfo::GetHandle();
		if (pBrdInfoObj != NULL)
			chanCount = pBrdInfoObj->GetNoOfChannels(BoardNo);
		pBrdStatsObj = CBrdStats::GetHandle();
		if (pBrdStatsObj != NULL) {
			// Check whether the CJC reading or active burnout status has been updated
			if (*pData != 0) {
				newState = static_cast<WORD>(*pData);
				// CJC reading has been updated, so schedule download via state machine
				if (GetBits((USHORT) newState, MSG_CJC_CHANGED, 1) != 0u)
					pAICard->ScheduleCJCDownload();
				// Error (fault) list not empty flag is no longer used as it is not reset correctly on AI board (although it is still in documentation)
				//				if( GetBits( newState, MSG_FAULT_LIST_NOT_EMPTY, 1 ) != 0 )
				//					m_pBoard->ScheduleErrorDownload();
				// Has active burnout status changed on any thermocouples?
				if (GetBits((USHORT) newState, MSG_ACTIVE_BURNOUT_STATE_CHANGE, 1) != 0)
					pAICard->ScheduleActBrnStatusDownload();
			}
			BytesProcessed++;
			if (CheckReplyByte(startByte + BytesProcessed) == TRUE) {
				pData++;
				// Check whether any RT cal readings have been updated
				if (*pData != 0) {
					newState = static_cast<WORD>(*pData);
					// RT cal readings on one or more channels have been updated, so schedule via state machine
					for (chanNo = 0; chanNo < chanCount; chanNo++) {
						if (GetBits((USHORT) newState, chanNo, 1) != 0)
							pBrdStatsObj->SetChannelRTCalRqdState(m_pBoard->BoardSlotInstance(), chanNo,
							TRUE);
					}
					pAICard->ScheduleRTCalDownload();
				}
				BytesProcessed++;
			}
			if (CheckReplyByte(startByte + BytesProcessed) == TRUE) {
				pData++;
				// Check whether any RT comp readings on one or more channels have been updated
				if (*pData != 0) {
					newState = static_cast<WORD>(*pData);
					// RT comp readings has been updated, so schedule via state machine
					for (chanNo = 0; chanNo < chanCount; chanNo++) {
						if (GetBits((USHORT) newState, chanNo, 1) != 0)
							pBrdStatsObj->SetChannelRTCompRqdState(m_pBoard->BoardSlotInstance(), chanNo,
							TRUE);
					}
					pAICard->ScheduleRTCompDownload();
				}
				BytesProcessed++;
			}
			if (CheckReplyByte(startByte + BytesProcessed) == TRUE) {
				pData++;
				// Only process all channel readings if readings exist for one or more channels
				if (m_RxMessage[1] != ERR_NO_DATA) {
					pData++;		// Move to start of data
					BytesProcessed++;
					retValue = ProcessAIReadingsReturn(pData, pBrdInfoObj->GetBoardTimebase(BoardNo),
							count - BytesProcessed);
				}
			}
		}
	}
	return retValue;
}
#define NO_OF_PULSE_READINGS_BYTE			4
#define START_OF_PULSE_READINGS_BYTE		5
/////////////////////////////////////////////////////
/// Process all readings and status for one or more channels returned
/// from the block read command
///
/// @param[in] pData - Pointer to a data buffer holding the channel data.
/// @param[in] count - Number of bytes to process.
///
/// @return TRUE on success, else FALSE.
/////////////////////////////////////////////////////
BOOL CProtocol::ProcessPulseBlockTransfer(UCHAR *pData, USHORT count) {
	BOOL retValue = TRUE;
	class CChanList *pBoardChanLst = NULL;	// Board channels for processing
	class CIOChanHandler *pChan = NULL;	// General Channel reference
	class CDigPulseCard *pDigCard = static_cast<class CDigPulseCard*>(m_pBoard);
	UCHAR noOfReadings = 0;					// Number of readings to process
	DataItem2bytes timestamp;			// Newest reading timestamp
	USHORT BoardNo = m_pBoard->BoardSlotInstance();
	USHORT channelsToProcess = 0;
	USHORT chanNo;
	USHORT bytesProcessed = 0;
	UCHAR chanCount = 0;
	class CBrdInfo *pBrdInfoObj = NULL;		///< Board info holder
	WCHAR boardSlotStr[4];
	class CSlotMap *pSlotMap = NULL;
	QString errStr;
	if (count > 0) {
		pSlotMap = CSlotMap::GetHandle();
		if (pSlotMap != NULL)
			pSlotMap->GetSlotStrID(m_pBoard->BoardSlotInstance(), boardSlotStr);
		pBrdInfoObj = CBrdInfo::GetHandle();
		if (pBrdInfoObj != NULL)
			chanCount = pBrdInfoObj->GetNoOfChannels(BoardNo);
		pDigCard->ClearAckChannelRecieved();		// No channels to acknowledge yet
		// Only process all channel readings if readings exist for one or more channels
		channelsToProcess = pData[0];		// Get number of channels returned
		if (count != 0) {
			pData++;		// Move to start of data
			while ((channelsToProcess > 0) && (retValue == TRUE)) {
				// Keep processing whilst there is valid data
				bytesProcessed = 0;
				chanNo = pData[0];	// Get the channel number
				pData[1];	// Ignore pulse acqusition frequency (if we are not right by now then no hope)
				// Get time stamp
				timestamp.UCData[SWAP_BYTE_1] = pData[2];
				timestamp.UCData[SWAP_BYTE_0] = pData[3];
				noOfReadings = pData[NO_OF_PULSE_READINGS_BYTE];	///< Get number of readings to process
				pBoardChanLst = m_pBoard->GetChanSchedule();
				if (pBoardChanLst != NULL) {
					if (chanNo < chanCount) {
						pChan = pBoardChanLst->GetChannelRef(chanNo);
						if ((pChan != NULL) && (CheckReplyByte(START_OF_PULSE_READINGS_BYTE) == TRUE)) {
							retValue = pChan->ProcessPulseChannelReadings(&pData[START_OF_PULSE_READINGS_BYTE],
									timestamp.USData, noOfReadings);
						}
					} else {
						errStr = QString::asprintf("Pulse slot %s - Illegal channel %d referenced", boardSlotStr,
								chanNo);
						LogInternalError(errStr.toLocal8Bit().data());
						retValue = FALSE;
					}
				}
				--channelsToProcess;
				bytesProcessed = (5 + (noOfReadings * sizeof(USHORT)));
				if (bytesProcessed <= count) {
					count = count - bytesProcessed;
				} else {
					retValue = FALSE;
				}
				if (retValue == TRUE) {
					pDigCard->AckChannelRecieved(chanNo);
				}
				pData += bytesProcessed;
			}
		}
	}
	return retValue;
}
/////////////////////////////////////////////////////
/// Decode AO channel status
///
/// @param[in] status - Channel status byte.
/// @param[in] chanNo - Channel number being processed.
///
/// @return TRUE on success	else FALSE.
/////////////////////////////////////////////////////
BOOL CProtocol::DecodeAOChannelStatus(const UCHAR status, const USHORT chanNo) {
	class CATECal *pATECal = NULL;
	class CBrdStats *pBrdStats = NULL;		///< Board stats holder
	BOOL retValue = FALSE;
	pATECal = CATECal::GetHandle();
	pBrdStats = CBrdStats::GetHandle();
	if (pATECal != NULL) {
		switch (status) {
		case AO_CHAN_NOT_ENABLED:
		case AO_CHAN_CURRENT_LOOP_OK:
		case AO_CHAN_RAW_MODE_CURRENT_LOOP_OK:
			// Log the OP status as OK
			pBrdStats->SetAOChanOPState(m_pBoard->BoardSlotInstance(), chanNo,
			FALSE);
			retValue = TRUE;
			break;
		case AO_CHAN_CURRENT_LOOP_OC:
			// Log the O/C status as O/C
			pBrdStats->SetAOChanOPState(m_pBoard->BoardSlotInstance(), chanNo,
			TRUE);
			// This is the only status that interests us
			if (IsRunningAsATEEquipment() == TRUE) {
				/// Set the status for the test equipment
				pATECal->SetAOChanState(chanNo, TRUE);
			} else {
				/// @todo: Send the O/C status to the event manager
			}
			retValue = TRUE;
			break;
		}
	}
	return retValue;
}
#define SIZEOF_DIG_READING	4
/////////////////////////////////////////////////////
/// Process all readings and status for one or more channels returned
/// from the block read command
///
/// @param[in] pData - Pointer to a data buffer holding the channel data.
/// @param[in] count - Number of bytes to process.
///
/// @return TRUE on success, else FALSE.
/////////////////////////////////////////////////////
BOOL CProtocol::ProcessDigitalBlockTransfer(UCHAR *const pData, const USHORT count) {
	BOOL retValue = FALSE;		// We have been told there are readings (from interrupt); so where are they?
	UCHAR boardType;
	class CIOCardHandler *pService = NULL;
	class CDigPulseCard *pDigCard = static_cast<class CDigPulseCard*>(m_pBoard);
	USHORT BoardNo = m_pBoard->BoardSlotInstance();
	class CBrdInfo *pBrdInfoObj = NULL;					///< Board info holder
	UCHAR chanCount = 0;
	pBrdInfoObj = CBrdInfo::GetHandle();
	chanCount = pBrdInfoObj->GetNoOfChannels(BoardNo);
	// Can only process if there are readings to process
	if (count > 0) {
		boardType = m_pBoard->GetBoardType();
		/// Only process boards of correct type, if we have got here then there is a channel enabled
		if ((boardType == BOARD_AR) || (boardType == BOARD_DIO)) {
			pService = pDigCard->GetProcessHandle();
			if (pService != NULL)
				retValue = pService->ProcessDigitalInReadings(pData, count);
		}
	}
	return retValue;
}
#define GRC_SIZE_OF_VALID_MSG_DATA_TO_PROCESS		8
#define GRC_SIZE_OF_VALID_DATA_TO_PROCESS_V6AI		3
#define GRC_SIZE_OF_VALID_DATA_TO_PROCESS_V7AI		5
#define GRC_DATA_CHANNEL_NO							4
#define GRC_RT_COMP_DATA_START_BYTE					5
//******************************************************
// GetRTComp()
///
/// Retrieves the current channel RT comp value
///
/// @return TRUE on Msg Tx & Rx success (i.e. data to process), else FALSE.
/// 
/// 
/// Rev History
/// @Version	@Date			@Author					@Remarks
/// 2.0			05/Apr/2019		Shankar Rao	Pendyala	Protocol compatibility with New AI card and Old AI Card
//******************************************************
BOOL CProtocol::GetRTComp(void) {
	DataItem4bytes RTComp;				///< Union; cannot initialise
	class CBrdStats *pBrdStatsObj = NULL;		///< Board stats holder
	class CAICard *pAIBoard = NULL;		// AI board reference
	class CChanList *pBoardChanLst = NULL;	// Board channels for processing
	class CIOChanHandler *pChan = NULL;	// General Channel reference
	class CSlotMap *pSlotMap = NULL;		// System slot map
	class CDataItem *pDataItem = NULL;
	USHORT sysAIChan = 0;
	BOOL MsgSuccess = FALSE;
	class CAIConfig *pAIConfig = NULL;
	CTVtime time;		// Time routines instance (structure - cannot initialise).
	LONGLONG currSecs;
	pAIConfig = m_pConfigManager->GetAILocalConfig(static_cast<UCHAR>(m_pBoard->BoardSlotInstance()));
	pAIBoard = reinterpret_cast<class CAICard*>(m_pBoard);		// AI board reference
	pBrdStatsObj = CBrdStats::GetHandle();
	pSlotMap = CSlotMap::GetHandle();
	if ((pAIBoard != NULL) && (pBrdStatsObj != NULL)) {
		UCHAR ucAICardSubType = m_pBoard->WhatBoardSubType();
		/// TODO
		CreateTXHeader( GET_RT_COMP, MESSAGE_DATA_1_BYTE);
		// Get first channel that needs RTComp obtained
		if (pAIBoard->GetAnalRTCompChan(m_pBoard->BoardSlotInstance(), &m_TxMessage[GRC_DATA_CHANNEL_NO]) == TRUE) {
			MsgSuccess = WaitSendMessage(WAIT_30ms);
			// Ensure there is valid data to process
			if (m_RxSize >= GRC_SIZE_OF_VALID_MSG_DATA_TO_PROCESS) {
				if (MsgSuccess == TRUE) {
					// Remove channel from list to do
					pBrdStatsObj->SetChannelRTCompRqdState(m_pBoard->BoardSlotInstance(),
							m_RxMessage[GRC_DATA_CHANNEL_NO], FALSE);
					BOOL bProceed = FALSE;
					// Process returned data
					if (m_RxMessage[RX_MESS_LO_BYTE_COUNT] == GRC_SIZE_OF_VALID_DATA_TO_PROCESS_V6AI) {
						RTComp.UCData[SWAP_BYTE_3] = 0x00;
						RTComp.UCData[SWAP_BYTE_2] = 0x00;
						RTComp.UCData[SWAP_BYTE_1] = m_RxMessage[GRC_RT_COMP_DATA_START_BYTE + SWAP_BYTE_0];
						RTComp.UCData[SWAP_BYTE_0] = m_RxMessage[GRC_RT_COMP_DATA_START_BYTE + SWAP_BYTE_1];
						bProceed = TRUE;
					} else if (m_RxMessage[RX_MESS_LO_BYTE_COUNT] == GRC_SIZE_OF_VALID_DATA_TO_PROCESS_V7AI) {
						RTComp.UCData[SWAP_BYTE_3] = m_RxMessage[GRC_RT_COMP_DATA_START_BYTE + SWAP_BYTE_0];
						RTComp.UCData[SWAP_BYTE_2] = m_RxMessage[GRC_RT_COMP_DATA_START_BYTE + SWAP_BYTE_1];
						RTComp.UCData[SWAP_BYTE_1] = m_RxMessage[GRC_RT_COMP_DATA_START_BYTE + SWAP_BYTE_2];
						RTComp.UCData[SWAP_BYTE_0] = m_RxMessage[GRC_RT_COMP_DATA_START_BYTE + SWAP_BYTE_3];
						bProceed = TRUE;
					} else {
						bProceed = FALSE;
					}
					//Proceed only if the Data is received
					if ( TRUE == bProceed) {
						// Get the present day time in seconds.
						time.TimeNow();
						currSecs = static_cast<LONGLONG>(time.GetMicroSecs());
						// Register that we have had an RT cal reading
						pAIBoard->SetLastRTCompReadTime(m_RxMessage[GRC_DATA_CHANNEL_NO], currSecs);
						if (IsRunningAsATEEquipment() == FALSE) {
							// Store local copy and update status; if not test equipment build
							pBoardChanLst = m_pBoard->GetChanSchedule();
							if (pBoardChanLst != NULL) {
								pChan = pBoardChanLst->GetChannelRef(m_RxMessage[GRC_DATA_CHANNEL_NO]);
								// Store the current RT compensation value
								if (pChan != NULL) {
									// Valid message returned; so do not fail if error code returned
									if (pChan->StoreRawRTComp(RTComp.ULData,
											pAIConfig->QueryHighConstantCurrent(m_RxMessage[GRC_DATA_CHANNEL_NO]),
											ucAICardSubType, AI_CHANNEL_TYPE_LINEAR_OHMS) == TRUE) {
										if (pDataItem != NULL)
											pDataItem->SetStatus(DISTAT_NORMAL);///< Set the raw status according to test results
									} else {
										if (pDataItem != NULL)
											pDataItem->SetStatus(DISTAT_INVALID);///< Set the raw status accordng to test results
									}
									// Automatically rescheduled if there are more channels to process
								}
							}
						}
					} else {
						MsgSuccess = FALSE;
					}
				}
			}
		} else {
			// There is no command to fail
			MsgSuccess = TRUE;
		}
	}
	return MsgSuccess;
}
#define GRTC_VALID_DATA_LENGTH_V6AI		3
#define GRTC_VALID_DATA_LENGTH_V7AI		5
#define GRTC_DATA_CHANNEL_NO			4
#define GRC_RT_CAL_DATA_START_BYTE		5
//******************************************************
// GetRTCal()
///
/// Retrieves the current channel RT cal value
///
/// @return TRUE on Msg Tx & Rx success (i.e. data to process), else FALSE.
/// 
/// Rev History
/// @Version	@Date			@Author					@Remarks
/// 2.0			05/Apr/2019		Shankar Rao	Pendyala	Compatibility with New AI card (24Bit ADC/Channel Readings) and Old AI Card (16Bit)
/////////////////////////////////////////////////////
//******************************************************
BOOL CProtocol::GetRTCal(void) {
	DataItem4bytes RTCal;				///< Union; cannot initialise
	class CBrdStats *pBrdStatsObj = NULL;		///< Board stats holder
	class CAICard *pAIBoard = NULL;		// AI board reference
	class CChanList *pBoardChanLst = NULL;	// Board channels for processing
	class CIOChanHandler *pChan = NULL;	// General Channel reference
	class CSlotMap *pSlotMap = NULL;		// System slot map
	class CDataItem *pDataItem = NULL;
	USHORT sysAIChan = 0;
	BOOL MsgSuccess = FALSE;
	CTVtime time;		// Time routines instance (structure - cannot initialise).
	LONGLONG currSecs;
	class CAIConfig *pAIConfig = NULL;
	pAIConfig = m_pConfigManager->GetAILocalConfig(static_cast<UCHAR>(m_pBoard->BoardSlotInstance()));
	// Ensure there is valid data to process
	pAIBoard = reinterpret_cast<class CAICard*>(m_pBoard);		// AI board reference
	pBrdStatsObj = CBrdStats::GetHandle();
	pSlotMap = CSlotMap::GetHandle();
	if ((pAIBoard != NULL) && (pBrdStatsObj != NULL)) {
		CreateTXHeader( GET_RT_CAL, MESSAGE_DATA_1_BYTE);
		// Get first channel that needs RTCal obtained
		if (pAIBoard->GetAnalRTCalChan(m_pBoard->BoardSlotInstance(), &m_TxMessage[GRTC_DATA_CHANNEL_NO]) == TRUE) {
			MsgSuccess = WaitSendMessage(WAIT_30ms);
			// Process returned data
			if (MsgSuccess == TRUE) {
				if (m_RxSize >= GRC_SIZE_OF_VALID_MSG_DATA_TO_PROCESS) {
					// Remove channel from list to do
					pBrdStatsObj->SetChannelRTCalRqdState(m_pBoard->BoardSlotInstance(),
							m_RxMessage[GRTC_DATA_CHANNEL_NO], FALSE);
					BOOL bProceed = FALSE;
					// Process returned data
					if (m_RxMessage[RX_MESS_LO_BYTE_COUNT] == GRTC_VALID_DATA_LENGTH_V6AI) {
						RTCal.UCData[SWAP_BYTE_3] = 0x00;
						RTCal.UCData[SWAP_BYTE_2] = 0x00;
						RTCal.UCData[SWAP_BYTE_0] = m_RxMessage[GRC_RT_CAL_DATA_START_BYTE + SWAP_BYTE_1];
						RTCal.UCData[SWAP_BYTE_1] = m_RxMessage[GRC_RT_CAL_DATA_START_BYTE + SWAP_BYTE_0];
						bProceed = TRUE;
					} else if (m_RxMessage[RX_MESS_LO_BYTE_COUNT] == GRTC_VALID_DATA_LENGTH_V7AI) {
						RTCal.UCData[SWAP_BYTE_3] = m_RxMessage[GRC_RT_CAL_DATA_START_BYTE + SWAP_BYTE_0];
						RTCal.UCData[SWAP_BYTE_2] = m_RxMessage[GRC_RT_CAL_DATA_START_BYTE + SWAP_BYTE_1];
						RTCal.UCData[SWAP_BYTE_1] = m_RxMessage[GRC_RT_CAL_DATA_START_BYTE + SWAP_BYTE_2];
						RTCal.UCData[SWAP_BYTE_0] = m_RxMessage[GRC_RT_CAL_DATA_START_BYTE + SWAP_BYTE_3];
						bProceed = TRUE;
					} else {
						bProceed = FALSE;
					}
					//Proceed only if the Data is received
					if ( TRUE == bProceed) {
						// Get the present day time in seconds.
						time.TimeNow();
						currSecs = static_cast<LONGLONG>(time.GetMicroSecs());
						// Register that we have had an RT cal reading
						pAIBoard->SetLastRTCalReadTime(m_RxMessage[GRC_DATA_CHANNEL_NO], currSecs);
						if (IsRunningAsATEEquipment() == FALSE) {
							// Store local copy and update status; if not test equipment build
							pBoardChanLst = m_pBoard->GetChanSchedule();
							if (pBoardChanLst != NULL) {
								pChan = pBoardChanLst->GetChannelRef(m_RxMessage[GRC_DATA_CHANNEL_NO]);
								if (pChan != NULL) {
									// Convert & store the local copy of the current RT calibration value
									if (pChan->StoreRawRTCal(RTCal.ULData,
											pAIConfig->QueryHighConstantCurrent(
													m_RxMessage[GRC_DATA_CHANNEL_NO])) == TRUE) {
										if (pDataItem != NULL)
											pDataItem->SetStatus(DISTAT_NORMAL);///< Set the raw status according to test results
									} else {
										if (pDataItem != NULL)
											pDataItem->SetStatus(DISTAT_INVALID);///< Set the raw status accordng to test results
									}
									// Automatically rescheduled if there are more channels to process
								}
							}
						}
					} else
						MsgSuccess = FALSE;
				}
			}
		} else {
			// There is no command to fail
			MsgSuccess = TRUE;
		}
	}
	return MsgSuccess;
}
#define GCJC_VALID_DATA_LENGTH			4
#define GCJC_V7AI_VALID_DATA_LENGTH		16
#define GCJC_TEMP_RETURN_START_BYTE		4
//******************************************************
// GetCJC()
///
/// Retrieves the current CJC value
///
/// @return TRUE on Msg Tx & Rx success (i.e. data to process), else FALSE.
/// 
//******************************************************
BOOL CProtocol::GetCJC(void) {
	DataItem4bytes CJCTemp;		///< Union; cannot initialise
	BOOL MsgSuccess = FALSE;
	T_PRECPROFILE ptProfile = pSYSTEM_INFO->GetProfileConfig();
	CBrdInfo *pBrdInfoObj = CBrdInfo::GetHandle();
	class CSlotMap *pSlotMap = NULL;
	UCHAR ucAICardSubType = m_pBoard->WhatBoardSubType();
	UCHAR ucFunctionCode;
	int noOfCJCs;
	int lastBytePosInMessage;
	int expectedDataLen;
	float cjcVals[CAIRanges::MAX_CJCS];
	// Now update the individual CJC's, get how many channels this card has
	CAICard *pAIBoard = (CAICard*) m_pBoard;			// AI board reference
	int slotInstanceNo = pAIBoard->BoardSlotInstance();
	int noOfChans = pBrdInfoObj->GetNoOfChannels(slotInstanceNo);
	float cjcMissingReading;
	//Switch Command code according to AI Card Sub Type
	if (AI_CARD_TYPE_V7AI == ucAICardSubType) {
		//The new function code to V7AI datablock with 32 bits for each data sample to support 24 ADC counts
		ucFunctionCode = GET_CJC_V7AI;
		noOfCJCs = CAIRanges::MAX_V7AI_CJCS;
		// limit the number of CJCs for 4 and 6 input cards
		if (noOfChans < noOfCJCs) {
			noOfCJCs = noOfChans;
			CInputConditioning::CreateFloatingPointRepresentation(
			IO_SCHED_MISSING_CJC, &cjcMissingReading);
		}
		lastBytePosInMessage = GCJC_TEMP_RETURN_START_BYTE + ((sizeof(float) * 4) - 1);
		expectedDataLen = GCJC_V7AI_VALID_DATA_LENGTH;
	} else {
		ucFunctionCode = GET_CJC;
		noOfCJCs = 1;
		lastBytePosInMessage = GCJC_TEMP_RETURN_START_BYTE + SWAP_BYTE_3;
		expectedDataLen = GCJC_VALID_DATA_LENGTH;
	}
	pSlotMap = CSlotMap::GetHandle();
	CreateTXHeader(ucFunctionCode, NO_MESSAGE_DATA_BYTES);
	MsgSuccess = WaitSendMessage(WAIT_30ms);
	if (MsgSuccess == TRUE) {
		// Process returned data
		if (m_RxMessage[RX_MESS_LO_BYTE_COUNT] == expectedDataLen) {
			// bit overboard but duplicating existing functionality, by checking the number of bytes
			// returned is actually the same as the length we've verified above
			if (CheckReplyByte(lastBytePosInMessage) == TRUE) {
				float averageCJCTemp = 0;
				// read the CJC value(s)
				for (int cjcCount = 0; cjcCount < CAIRanges::MAX_CJCS; cjcCount++) {
					// check we haven't exceeded the CJC count for this card type
					if (cjcCount < noOfCJCs) {
						// valid so use the actual value
						int currCJCBytePos = GCJC_TEMP_RETURN_START_BYTE + (cjcCount * sizeof(float));
						CJCTemp.UCData[SWAP_BYTE_0] = m_RxMessage[currCJCBytePos + SWAP_BYTE_3];
						CJCTemp.UCData[SWAP_BYTE_1] = m_RxMessage[currCJCBytePos + SWAP_BYTE_2];
						CJCTemp.UCData[SWAP_BYTE_2] = m_RxMessage[currCJCBytePos + SWAP_BYTE_1];
						CJCTemp.UCData[SWAP_BYTE_3] = m_RxMessage[currCJCBytePos + SWAP_BYTE_0];
						cjcVals[cjcCount] = CJCTemp.FData;
						// add to the average temperature (which is actually a sum to begin with)
						averageCJCTemp += cjcVals[cjcCount];
					} else {
						// not valid so use the first CJC value
						cjcVals[cjcCount] = cjcVals[0];	//Coverity CID: 1992622 // it is not an issue as 0th element will be filled always. (No change)
					}
				}
				// update the average (which is a total up until now)
				averageCJCTemp /= noOfCJCs;
				// at this point we will have 1-4 CJC values (some might be duplicates if an old card)
				// and we have an overall average. We now need to update the relevant board information
				// and data items
				/// Store the original deg C reading for use in all TC measurement calculations
				pBrdInfoObj->SetDegCCJCReading(slotInstanceNo, averageCJCTemp);
				pAIBoard->ReportCJCFailureRecovery(slotInstanceNo);
				if (pSlotMap != NULL) {
					CDataItem *pCJCDataItem = NULL;
					CDataItem *pCJC_C_DataItem = NULL;
					USHORT CJCNo;
					USHORT CJCDegCNo;
					if (pSlotMap->ObtainBoardsDICJCRef(slotInstanceNo, &CJCNo, &CJCDegCNo) == TRUE) {
						pCJC_C_DataItem = pDIT->GetDataItemPtr(DI_IO, DI_IO_MISC, CJCDegCNo);
						pCJCDataItem = pDIT->GetDataItemPtr(DI_IO, DI_IO_MISC, CJCNo);
						pAIBoard->UpdateCJCDataItems(pCJCDataItem, pCJC_C_DataItem, averageCJCTemp);
						// loop through the additional per channel pair CJCs - don't worry if not present,
						// because an old AI card or 4/6 input card, we will simply set them to the first
						// channel's value (set earlier)
						for (int cjcCount = 0; cjcCount < CAIRanges::MAX_CJCS; cjcCount++) {
							CJCDegCNo = CDataItemTypeIO::GetCJCDIRef(slotInstanceNo, cjcCount * 2, true);
							CJCNo = CDataItemTypeIO::GetCJCDIRef(slotInstanceNo, cjcCount * 2, false);
							pCJC_C_DataItem = pDIT->GetDataItemPtr(DI_IO, DI_IO_CJC_MULTI_CHAN, CJCDegCNo);
							pCJCDataItem = pDIT->GetDataItemPtr(DI_IO, DI_IO_CJC_MULTI_CHAN, CJCNo);
							// check the CJC exists or a single AI card only
							if ((noOfCJCs == 1) || (cjcCount < noOfCJCs)) {
								pAIBoard->UpdateCJCDataItems(pCJCDataItem, pCJC_C_DataItem, cjcVals[cjcCount]);
								pBrdInfoObj->SetDegCCJCReading(slotInstanceNo, cjcCount, cjcVals[cjcCount]);
							} else {
								// multiple CJC card fitted but with channels missing therefore set as invalud
								pAIBoard->UpdateCJCDataItemInvalidStatus(pCJCDataItem, pCJC_C_DataItem);
								pBrdInfoObj->SetDegCCJCReading(slotInstanceNo, cjcCount, cjcMissingReading);
							}
						}
					}
				}
			} else {
				// CJ Data item is invalid
				//				pAIBoard->ResetCardDataItems();
				pAIBoard->ReportCJCFailureDiagnostics(slotInstanceNo);
			}
		} else {
			// CJ Data item is invalid
			//			pAIBoard->ResetCardDataItems();
			pAIBoard->ReportCJCFailureDiagnostics(slotInstanceNo);
		}
	} else {
		// CJ Data item is invalid
		//		pAIBoard->ResetCardDataItems();
		pAIBoard->ReportCJCFailureDiagnostics(slotInstanceNo);
	}
	return MsgSuccess;
}
#define SACTBRNOUT_CHAN_NO_BYTE				4
#define SACTBRNOUT_BURNOUT_SETTING_BYTE		5
//******************************************************
// ConfigureCJCActiveBurnoutState()
///
/// Configures a CJC active burnout measurement
/// This command effectively resets the burnout state of the TC if the lead's are long (high resistance)
///
/// @return TRUE on Msg Tx & Rx success (i.e. data to process), else FALSE.
///
//******************************************************
BOOL CProtocol::ConfigureCJCActiveBurnoutState(void) {
	UCHAR chanNo;
	USHORT chanType;
	BOOL FuncSuccess = TRUE;
	BOOL MsgSuccess = TRUE;
	BOOL activeBurnOutSelected = FALSE;
	class CAIConfig *pAIConfig = NULL;
	pAIConfig = m_pConfigManager->GetAILocalConfig(static_cast<UCHAR>(m_pBoard->BoardSlotInstance()));
	if (pAIConfig != NULL) {
		// Repeat for all channels configured with active burnout
		for (chanNo = 0; chanNo < MAX_AI_BOARD_CHANNELS; chanNo++) {
			pAIConfig->QueryAISlotChannelSelection(chanNo, &chanType);
			if ((chanType == AI_CHANNEL_TYPE_TC)
					&& (pAIConfig->QueryChanActiveBurnout(chanNo, &activeBurnOutSelected) == TRUE)) {
				if (activeBurnOutSelected == TRUE) {
					m_TxMessage[SACTBRNOUT_CHAN_NO_BYTE] = chanNo;
					m_TxMessage[SACTBRNOUT_BURNOUT_SETTING_BYTE] =
					DEFAULT_ACTIVE_BURNOUT_TYPE;
					CreateTXHeader( SET_ACTIVE_BNOUT, MESSAGE_DATA_2_BYTES);
					MsgSuccess = WaitSendMessage(WAIT_30ms);
					// No returned data to process
					if (MsgSuccess == FALSE)
						FuncSuccess = FALSE;
				}
			}
		}
	} else {
		// Cannot get a handle on the AI card configuration
		FuncSuccess = FALSE;
	}
	return FuncSuccess;
}
#define GBS_ACTIVE_BURNOUT_STATUS_START_BYTE		13
//******************************************************
// GetCJCActiveBurnoutState()
///
/// Retrieves the current CJC active burnout status
///
/// @return TRUE on Msg Tx & Rx success (i.e. data to process), else FALSE.
///
//******************************************************
BOOL CProtocol::GetCJCActiveBurnoutState(void) {
	BOOL MsgSuccess = FALSE;
	class CPPIOServiceManager *pServiceManagerObj = NULL;	///< Service manager
	class CInputConditioning *pICService = NULL;
	class CBrdInfo *pBrdInfoObj = NULL;		///< Board stats holder
	USHORT chanNo = 0;
	pBrdInfoObj = CBrdInfo::GetHandle();
	pServiceManagerObj = CPPIOServiceManager::GetHandle();
	if (pServiceManagerObj != NULL)
		pICService = pServiceManagerObj->GetICService();
	CreateTXHeader( GET_BNOUT_STATUS, NO_MESSAGE_DATA_BYTES);
	MsgSuccess = WaitSendMessage(WAIT_30ms);
	if (MsgSuccess == TRUE) {
		// Process returned data, for all valid channels on board
		//		pBrdStatsObj->SetActiveBurnoutStatus( m_RxMessage[GBS_ACTIVE_BURNOUT_STATUS_START_BYTE] );
		for (chanNo = 0; chanNo < pBrdInfoObj->GetNoOfChannels(m_pBoard->BoardSlotInstance()); chanNo++) {
			if (CheckReplyByte(
			GBS_ACTIVE_BURNOUT_STATUS_START_BYTE + chanNo) == TRUE) {
				pICService->ConvertStoreBurnoutResponse(m_pBoard->BoardSlotInstance(), chanNo,
						m_RxMessage[GBS_ACTIVE_BURNOUT_STATUS_START_BYTE + chanNo]);
			}
		}
	}
	return MsgSuccess;
}
#define RAR_FACT_CAL_RECORD_START_BYTE	4
#define RAR_FACT_CAL_RIG_ID_BYTE		8
#define RAR_USER_CAL_RECORD_START_BYTE	17
//******************************************************
// GetAICalibrationHistory()
///
/// Retrieves the AI calibration history for the AI board currently selected
///
/// @return TRUE on Msg Tx & Rx success (i.e. data to process), else FALSE.
///
//******************************************************
BOOL CProtocol::GetAICalibrationHistory(void) {
	class CBrdInfo *pBrdInfoObj = NULL;		///< Board stats holder
	class CBrdStats *pBrdStatsObj = NULL;		///< Board stats holder
	DataItem4bytes RetDate;		///< Union; cannot initialise
	USHORT chanNo = 0;
	UCHAR chanStartOffset = 0;
	BOOL MsgSuccess = FALSE;
	pBrdInfoObj = CBrdInfo::GetHandle();
	pBrdStatsObj = CBrdStats::GetHandle();
	CreateTXHeader( RD_AICAL_REC, NO_MESSAGE_DATA_BYTES);
	MsgSuccess = WaitSendMessage(WAIT_80ms);
	if (MsgSuccess == TRUE) {
		if (CheckReplyByte(
		RAR_FACT_CAL_RECORD_START_BYTE + SWAP_BYTE_3) == TRUE) {
			// Process returned factory calibration data, for all valid channels on board
			RetDate.UCData[SWAP_BYTE_0] = m_RxMessage[RAR_FACT_CAL_RECORD_START_BYTE + SWAP_BYTE_3];
			RetDate.UCData[SWAP_BYTE_1] = m_RxMessage[RAR_FACT_CAL_RECORD_START_BYTE + SWAP_BYTE_2];
			RetDate.UCData[SWAP_BYTE_2] = m_RxMessage[RAR_FACT_CAL_RECORD_START_BYTE + SWAP_BYTE_1];
			RetDate.UCData[SWAP_BYTE_3] = m_RxMessage[RAR_FACT_CAL_RECORD_START_BYTE + SWAP_BYTE_0];
			pBrdStatsObj->SetFactoryCalDate(m_pBoard->BoardSlotInstance(), RetDate.ULData,
					m_RxMessage[RAR_FACT_CAL_RIG_ID_BYTE]);
		}
		chanStartOffset = RAR_USER_CAL_RECORD_START_BYTE;
		// Process returned user calibration data, for all valid channels on board
		for (chanNo = 0; chanNo < pBrdInfoObj->GetNoOfChannels(m_pBoard->BoardSlotInstance()); chanNo++) {
			if (CheckReplyByte(chanStartOffset + SWAP_BYTE_3) == TRUE) {
				RetDate.UCData[SWAP_BYTE_0] = m_RxMessage[chanStartOffset + SWAP_BYTE_3];
				RetDate.UCData[SWAP_BYTE_1] = m_RxMessage[chanStartOffset + SWAP_BYTE_2];
				RetDate.UCData[SWAP_BYTE_2] = m_RxMessage[chanStartOffset + SWAP_BYTE_1];
				RetDate.UCData[SWAP_BYTE_3] = m_RxMessage[chanStartOffset + SWAP_BYTE_0];
				pBrdStatsObj->SetUserCalDate(m_pBoard->BoardSlotInstance(), chanNo, RetDate.ULData);
				chanStartOffset += sizeof(ULONG) + sizeof(USHORT);
			}
		}
	}
	return MsgSuccess;
}
//******************************************************
// GetCJCBurnoutWiring()
///
/// Retrieves the current CJC active burnout status
///
/// @return TRUE on Msg Tx & Rx success (i.e. data to process), else FALSE.
///
//******************************************************
BOOL CProtocol::CheckCJCBurnoutWiring(void) {
	BOOL MsgSuccess = FALSE;
	CreateTXHeader( CHK_BNOUT_WIRING, MESSAGE_DATA_2_BYTES);
	MsgSuccess = WaitSendMessage(WAIT_30ms);
	if (MsgSuccess == TRUE) {
		// Process returned data
	}
	return MsgSuccess;
}
//******************************************************
// ACKGoodAIBlock()
///
/// Sends an ACK to a previously supplied data block.
///
/// @return TRUE on Msg Tx & Rx success (i.e. data to process), else FALSE.
///
//******************************************************
BOOL CProtocol::ACKGoodAIBlock(void) {
	BOOL MsgSuccess = FALSE;
	CTV6Timer ackTimer(TIMER_HIGH_RES);		// Total time of acknowledge
	LONGLONG acktimetaken = static_cast<LONGLONG>(0L);
	class CAICard *pAIBoard = static_cast<class CAICard*>(m_pBoard);
	// ackTimer timer reset
	ackTimer.ResetAllTimers();
	ackTimer.StartTimer();
	CreateTXHeader( ACK_GOOD_AIBLOCK, MESSAGE_DATA_1_BYTE);
	m_TxMessage[4] = static_cast<UCHAR>(pAIBoard->GetBlockTransChansToAck());
	MsgSuccess = WaitSendMessage(WAIT_20ms);
	if (MsgSuccess == FALSE) {
		pAIBoard->ScheduleDataBlockAck();
	}
	ackTimer.StopTimer();
	acktimetaken = ackTimer.GetTimeInMicroSec(TIMER_SINGLE);
	return MsgSuccess;
}
#define GET_AI_DATABLOCK_CH_SELECT		4
#define RDAIDB_BOARD_DATA_START_BYTE	4
#define NO_CHANNELS_SELECTED			0
//******************************************************
// GetAIDataBlock()
///
/// Retrieves a block of data from the AI card.
///
/// @return TRUE on Msg Tx & Rx success (i.e. data to process), else FALSE.
///
/// Rev History
/// @Version	@Date			@Author					@Remarks
/// 1.0			29/Mar/2019		Shankar Rao	Pendyala	Protocol compatibility with New AI card and Old AI Card
//******************************************************
BOOL CProtocol::GetAIDataBlock(E_IO_MOD_SUB_ERROR_CODE &eIoModSubErrCode) {
	DataItem2bytes DataCnt;		// (union cannot initialise)
	BOOL MsgSuccess = FALSE;
	UCHAR ucAICardSubType = m_pBoard->WhatBoardSubType();
	UCHAR ucFunctionCode = RD_ANAL_BLOCK;
	//Switch Command code according to AI Card Sub Type
	if (AI_CARD_TYPE_V7AI == ucAICardSubType) {
		//The new function code to V7AI datablock with 32 bits for each data sample to support 24 ADC counts
		ucFunctionCode = RD_ANAL_BLOCK_V7AI;
	}
	CreateTXHeader(ucFunctionCode, MESSAGE_DATA_1_BYTE);
	m_TxMessage[GET_AI_DATABLOCK_CH_SELECT] = static_cast<UCHAR>(m_pBoard->ChannelsToService());
	if (m_TxMessage[GET_AI_DATABLOCK_CH_SELECT] != NO_CHANNELS_SELECTED) {
		// There are some channels to be requested
		MsgSuccess = WaitSendMessage(WAIT_30ms);
		if ((MsgSuccess == TRUE) && (CheckReplyByte(RDAIDB_BOARD_DATA_START_BYTE) == TRUE)) {
			//			DisplayCommandReturn();
			// Process each returned channel data & status
			DataCnt.UCData[SWAP_BYTE_1] = m_RxMessage[RX_MESS_HI_BYTE_COUNT];
			DataCnt.UCData[SWAP_BYTE_0] = m_RxMessage[RX_MESS_LO_BYTE_COUNT];
			MsgSuccess = ProcessAnalBlockTransfer(&m_RxMessage[RDAIDB_BOARD_DATA_START_BYTE],
			RDAIDB_BOARD_DATA_START_BYTE, DataCnt.USData);
			//			if ( MsgSuccess == TRUE )
			//			{
			//				pAIBoard->ScheduleAIDataAck();
			//			}
			GetSubErrorCode(eIoModSubErrCode);
		}
	} else {
		MsgSuccess = TRUE;
	}
	return MsgSuccess;
}
#define RDIB_BOARD_DATA_START_BYTE	4
//******************************************************
// GetDigDataBlock()
///
/// Retrieves a block of data from the Digital I/O or alarm card.
///
/// @return TRUE on Msg Tx & Rx success (i.e. data to process), else FALSE.
///
//******************************************************
BOOL CProtocol::GetDigDataBlock(void)
{
	DataItem2bytes DataCnt;		// (union cannot initialise)
	BOOL MsgSuccess = FALSE;
	CreateTXHeader( RD_DIG_IN_BLK, NO_MESSAGE_DATA_BYTES);
	MsgSuccess = WaitSendMessage(WAIT_30ms);
	if ((MsgSuccess == TRUE) && (CheckReplyByte(RDIB_BOARD_DATA_START_BYTE) == TRUE)) {
		// Process returned digital data
		DataCnt.UCData[SWAP_BYTE_1] = m_RxMessage[RX_MESS_HI_BYTE_COUNT];
		DataCnt.UCData[SWAP_BYTE_0] = m_RxMessage[RX_MESS_LO_BYTE_COUNT];
		MsgSuccess = ProcessDigitalBlockTransfer(&m_RxMessage[RDIB_BOARD_DATA_START_BYTE], DataCnt.USData);
	}
	return MsgSuccess;
}
#define WDO_BOARD_OP_DATA_START_BYTE	4
#define WDO_BOARDSTOP_PULSE_SELECT_BYTE	6
//******************************************************
// WriteDigData()
///
/// Writes digital data to the Digital I/O or alarm card.
///
/// @return TRUE on Msg Tx & Rx success, otherwise FALSE.
///
//******************************************************
BOOL CProtocol::WriteDigData(void) {
	DataItem2bytes DataCnt;		// (union cannot initialise)
	UCHAR chanNo;
	BOOL MsgSendRqd = TRUE;
	BOOL MsgSuccess = FALSE;
	USHORT outputState = 0;
	class CATECal *pCal = NULL;
	class CDigConfig *pDigConfig = NULL;
	class CDigPulseCard *pDigBoard = static_cast<class CDigPulseCard*>(m_pBoard);
	DataCnt.USData = 0;
	if (IsRunningAsATEEquipment() == TRUE) {
		// Operating within test equipment
		pCal = CATECal::GetHandle();
		if (pCal != NULL) {
			for (chanNo = 0; chanNo < BOTTOMSLOT_DIGCHAN_SIZE; chanNo++) {
				SetBits(&DataCnt.USData, pCal->GetDigBoardActiveState(chanNo), chanNo, 1);
			}
		}
	} else {
		// Operating in recorder
		MsgSendRqd = pDigBoard->ProcessOutputChannels(&DataCnt.USData);
	}
	if (MsgSendRqd == TRUE) {
		pDigConfig = m_pConfigManager->GetDigLocalConfig(static_cast<UCHAR>(m_pBoard->BoardSlotInstance()));
		CreateTXHeader( WR_DIG_OUTPUT, MESSAGE_DATA_3_BYTES);
		m_TxMessage[WDO_BOARD_OP_DATA_START_BYTE + SWAP_BYTE_0] = DataCnt.UCData[SWAP_BYTE_1];
		m_TxMessage[WDO_BOARD_OP_DATA_START_BYTE + SWAP_BYTE_1] = DataCnt.UCData[SWAP_BYTE_0];
		m_TxMessage[WDO_BOARDSTOP_PULSE_SELECT_BYTE] = 0;
		//		qDebug(L"Dig out = %d\n", DataCnt.USData);
		MsgSuccess = WaitSendMessage(WAIT_30ms);
		// No returned data to process
	}
	return MsgSuccess;
}
#define HISTORY_INVALID_CHANNEL		0xff		///< Note only available after AK 003
#define ILLEGAL_TIME				0
//******************************************************
// DecodeHistoryFaultRecord()
///
/// Decodes a history fault IO card life history data.
///
/// @param[in] pMsgStart - Start of message block to decode.
/// @param[in] faultNo - The fault number being decoded.
///
//******************************************************
void CProtocol::DecodeHistoryFaultRecord(const UCHAR *pMsgStart, const USHORT faultNo) {
	class CBrdStats *pBrdStats = NULL;
	UCHAR FaultOnChannel;			// (union cannot initialise)
	DataItem4bytes FaultTimeStamp;			// (union cannot initialise)
	DataItem4bytes FaultOperatingTime;		// (union cannot initialise)
	pMsgStart += (sizeof(struct FaultRecord) * faultNo);
	pBrdStats = CBrdStats::GetHandle();
	///< Get channel number for this fault
	FaultOnChannel = *pMsgStart;
	///< Get global timestamp at time of fault
	FaultTimeStamp.UCData[SWAP_BYTE_1] = *(++pMsgStart);
	FaultTimeStamp.UCData[SWAP_BYTE_0] = *(++pMsgStart);
	///< Get life Stats operating time at time of fault
	FaultOperatingTime.UCData[SWAP_BYTE_3] = *(++pMsgStart);
	FaultOperatingTime.UCData[SWAP_BYTE_2] = *(++pMsgStart);
	FaultOperatingTime.UCData[SWAP_BYTE_1] = *(++pMsgStart);
	FaultOperatingTime.UCData[SWAP_BYTE_0] = *(++pMsgStart);
	// It is likely that pre-AK003 can be checked that an error is only valid for the sum of channel failurs if less than 8;
	// otherwise all errors will be valid
	if ((FaultOnChannel != HISTORY_INVALID_CHANNEL) && (FaultTimeStamp.USData[0] != ILLEGAL_TIME)) {
		pBrdStats->SaveHistoryFaultRecord(m_pBoard->BoardSlotInstance(), faultNo, FaultOnChannel,
				FaultTimeStamp.USData[0], FaultOperatingTime.ULData);
	}
}
#define SIZEOF_RETURNED_GEN_IO_STATUS					26
#define LIFE_HISTORY_DATA_START_BYTE					4
#define LIFE_HISTORY_GENERIC_DATA_START_BYTE			8
#define LIFE_HISTORY_SPECIFIC_DATA_START_BYTE			(LIFE_HISTORY_GENERIC_DATA_START_BYTE + SIZEOF_RETURNED_GEN_IO_STATUS)
//******************************************************
// GetAILifeHistory()
///
/// Retrieves the AI IO card life history data.
///
/// @return TRUE on Msg decode success (not if error msg returned), else FALSE.
///
//******************************************************
BOOL CProtocol::GetAILifeHistory(void) {
	DataItem4bytes MinCjTemp;			// (union cannot initialise)
	DataItem4bytes MaxCjTemp;			// (union cannot initialise)
	DataItem4bytes QueueOverRuns[MAX_ADC_CHANNELS];	// (union cannot initialise)
	class CBrdStats *pBrdStats = NULL;
	UCHAR *pMsgStart = NULL;
	UCHAR bytePos = 0;
	USHORT chanNo = 0;
	BOOL retValue = FALSE;
	pBrdStats = CBrdStats::GetHandle();
	retValue = GetLifeHistory();		// Decode generic life history
	if (retValue == TRUE) {
		// Decode the AI specific part of the message
		bytePos = LIFE_HISTORY_SPECIFIC_DATA_START_BYTE;
		pMsgStart = &m_RxMessage[LIFE_HISTORY_SPECIFIC_DATA_START_BYTE];
		if (CheckReplyByte(bytePos + SWAP_BYTE_3) == TRUE) {
			///< Get CJC minimum temperature
			MinCjTemp.UCData[SWAP_BYTE_3] = *(++pMsgStart);
			MinCjTemp.UCData[SWAP_BYTE_2] = *(++pMsgStart);
			MinCjTemp.UCData[SWAP_BYTE_1] = *(++pMsgStart);
			MinCjTemp.UCData[SWAP_BYTE_0] = *(++pMsgStart);
			bytePos += sizeof(ULONG);
		}
		if (CheckReplyByte(bytePos + SWAP_BYTE_3) == TRUE) {
			///< Get CJC maximum temperature
			MaxCjTemp.UCData[SWAP_BYTE_3] = *(++pMsgStart);
			MaxCjTemp.UCData[SWAP_BYTE_2] = *(++pMsgStart);
			MaxCjTemp.UCData[SWAP_BYTE_1] = *(++pMsgStart);
			MaxCjTemp.UCData[SWAP_BYTE_0] = *(++pMsgStart);
			pBrdStats->SaveAISpecificHistory(m_pBoard->BoardSlotInstance(), MinCjTemp.FData, MaxCjTemp.FData);
			bytePos += sizeof(ULONG);
		}
		for (chanNo = 0; chanNo < MAX_ADC_CHANNELS; chanNo++) {
			if (CheckReplyByte(bytePos + SWAP_BYTE_3) == TRUE) {
				///< Get number of times data queue lost data
				QueueOverRuns[chanNo].UCData[SWAP_BYTE_3] = *(++pMsgStart);
				QueueOverRuns[chanNo].UCData[SWAP_BYTE_2] = *(++pMsgStart);
				QueueOverRuns[chanNo].UCData[SWAP_BYTE_1] = *(++pMsgStart);
				QueueOverRuns[chanNo].UCData[SWAP_BYTE_0] = *(++pMsgStart);
				pBrdStats->SaveAIQueueOverrunHistory(m_pBoard->BoardSlotInstance(), chanNo,
						QueueOverRuns[chanNo].ULData);
				bytePos += sizeof(ULONG);
			}
		}
	}
	return retValue;
}
#define GAOLH_CH1_OUTPUT_FAULT_COUNT_START_BYTE			LIFE_HISTORY_SPECIFIC_DATA_START_BYTE
//******************************************************
// GetAOLifeHistory()
///
/// Retrieves the AO IO card life history data.
///
/// @return TRUE on Msg decode success (not if error msg returned), else FALSE.
///
//******************************************************
BOOL CProtocol::GetAOLifeHistory(void) {
	DataItem4bytes FailureCount;		// (union cannot initialise)
	class CBrdStats *pBrdStats = NULL;
	BOOL retValue = FALSE;
	UCHAR *pDecodePtr = NULL;
	UCHAR bytePos = 0;
	USHORT chanNo = 0;
	USHORT faultNo = 0;
	pBrdStats = CBrdStats::GetHandle();
	retValue = GetLifeHistory();		// Decode generic life history
	if (retValue == TRUE) {
		// Decode the AO specific part of the message
		bytePos = GAOLH_CH1_OUTPUT_FAULT_COUNT_START_BYTE;
		pDecodePtr = &(m_RxMessage[GAOLH_CH1_OUTPUT_FAULT_COUNT_START_BYTE]);
		for (chanNo = 0; chanNo < HW_ANA_OUT_CHAN_PER_BOARD; chanNo++) {
			if (CheckReplyByte(bytePos + SWAP_BYTE_3) == TRUE) {
				// Set the failure count for each channel
				FailureCount.UCData[SWAP_BYTE_3] = *(++pDecodePtr);
				FailureCount.UCData[SWAP_BYTE_2] = *(++pDecodePtr);
				FailureCount.UCData[SWAP_BYTE_1] = *(++pDecodePtr);
				FailureCount.UCData[SWAP_BYTE_0] = *(++pDecodePtr);
				pBrdStats->SaveChanHistoryFaultRecord(m_pBoard->BoardSlotInstance(), chanNo, FailureCount.ULData);
				bytePos += sizeof(ULONG);
			}
		}
		// Examine the history fault records
		DecodeHistoryFaultRecord(pDecodePtr, faultNo);
	}
	return retValue;
}
//******************************************************
// GetARLifeHistory()
///
/// Retrieves the AR IO card life history data.
///
/// @return TRUE on Msg decode success (not if error msg returned), else FALSE.
///
//******************************************************
BOOL CProtocol::GetARLifeHistory(void) {
	class CBrdStats *pBrdStats = NULL;
	BOOL retValue = FALSE;
	UCHAR chanNo = 0;
	UCHAR bytePos = 0;
	UCHAR *pDecodePtr = NULL;
	DataItem4bytes NumARRelayOps[MAX_AR_CHANNELS];
	DataItem4bytes InputQueueOverRuns;
	DataItem4bytes PulseOutInterrupts[MAX_AR_CHANNELS];
	pBrdStats = CBrdStats::GetHandle();
	retValue = GetLifeHistory();		// Decode generic life history
	if (retValue == TRUE) {
		// Decode the AR specific part of the message
		bytePos = LIFE_HISTORY_SPECIFIC_DATA_START_BYTE;
		pDecodePtr = &(m_RxMessage[LIFE_HISTORY_SPECIFIC_DATA_START_BYTE]);
		for (chanNo = 0; chanNo < MAX_AR_CHANNELS; chanNo++) {
			if (CheckReplyByte(bytePos + SWAP_BYTE_3) == TRUE) {
				///< Get number of relay ops for each relay
				NumARRelayOps[chanNo].UCData[SWAP_BYTE_3] = *(++pDecodePtr);
				NumARRelayOps[chanNo].UCData[SWAP_BYTE_2] = *(++pDecodePtr);
				NumARRelayOps[chanNo].UCData[SWAP_BYTE_1] = *(++pDecodePtr);
				NumARRelayOps[chanNo].UCData[SWAP_BYTE_0] = *(++pDecodePtr);
				pBrdStats->SaveARRelayOpsRecord(m_pBoard->BoardSlotInstance(), chanNo, NumARRelayOps[chanNo].ULData);
				bytePos += sizeof(ULONG);
			}
		}
		if (CheckReplyByte(bytePos + SWAP_BYTE_3) == TRUE) {
			// Get number of times inputs data queue lost data
			InputQueueOverRuns.UCData[SWAP_BYTE_3] = *(++pDecodePtr);
			InputQueueOverRuns.UCData[SWAP_BYTE_2] = *(++pDecodePtr);
			InputQueueOverRuns.UCData[SWAP_BYTE_1] = *(++pDecodePtr);
			InputQueueOverRuns.UCData[SWAP_BYTE_0] = *(++pDecodePtr);
			pBrdStats->SaveARQueueOverRuns(m_pBoard->BoardSlotInstance(), InputQueueOverRuns.ULData);
			bytePos += sizeof(ULONG);
		}
		for (chanNo = 0; chanNo < MAX_AR_CHANNELS; chanNo++) {
			if (CheckReplyByte(bytePos + SWAP_BYTE_3) == TRUE) {
				///< Get number of times an output pulse was re-written before finishing
				PulseOutInterrupts[chanNo].UCData[SWAP_BYTE_3] = *(++pDecodePtr);
				PulseOutInterrupts[chanNo].UCData[SWAP_BYTE_2] = *(++pDecodePtr);
				PulseOutInterrupts[chanNo].UCData[SWAP_BYTE_1] = *(++pDecodePtr);
				PulseOutInterrupts[chanNo].UCData[SWAP_BYTE_0] = *(++pDecodePtr);
				pBrdStats->SaveARPulseOutInterrupts(m_pBoard->BoardSlotInstance(), chanNo,
						PulseOutInterrupts[chanNo].ULData);
				bytePos += sizeof(ULONG);
			}
		}
	}
	return retValue;
}
//******************************************************
// GetDIOLifeHistory()
///
/// Retrieves the DIO IO card life history data.
///
/// @return TRUE on Msg decode success (not if error msg returned), else FALSE.
///
//******************************************************
BOOL CProtocol::GetDIOLifeHistory(void) {
	class CBrdStats *pBrdStats = NULL;
	BOOL retValue = FALSE;
	UCHAR chanNo = 0;
	UCHAR bytePos = 0;
	UCHAR *pDecodePtr = NULL;
	DataItem4bytes NumDIORelayOps[MAX_DIG_CHANNELS];
	DataItem4bytes InputQueueOverRuns;
	DataItem4bytes PulseOutInterrupts;
	DataItem4bytes PulseQueueOverRuns;
	BYTE PulseOverRunChans;
	DataItem2bytes PulseOutIntChans;
	pBrdStats = CBrdStats::GetHandle();
	retValue = GetLifeHistory();		// Decode generic life history
	if (retValue == TRUE) {
		// Decode the DIO specific part of the message
		bytePos = LIFE_HISTORY_SPECIFIC_DATA_START_BYTE;
		pDecodePtr = &(m_RxMessage[LIFE_HISTORY_SPECIFIC_DATA_START_BYTE]);
		for (chanNo = 0; chanNo < MAX_DIG_CHANNELS; chanNo++) {
			if (CheckReplyByte(bytePos + SWAP_BYTE_3) == TRUE) {
				///< Get number of relay ops for each relay
				NumDIORelayOps[chanNo].UCData[SWAP_BYTE_3] = *(++pDecodePtr);
				NumDIORelayOps[chanNo].UCData[SWAP_BYTE_2] = *(++pDecodePtr);
				NumDIORelayOps[chanNo].UCData[SWAP_BYTE_1] = *(++pDecodePtr);
				NumDIORelayOps[chanNo].UCData[SWAP_BYTE_0] = *(++pDecodePtr);
				pBrdStats->SaveDIORelayOpsRecord(m_pBoard->BoardSlotInstance(), chanNo, NumDIORelayOps[chanNo].ULData);
				bytePos += sizeof(ULONG);
			}
		}
		if (CheckReplyByte(bytePos + SWAP_BYTE_3) == TRUE) {
			// Get number of times inputs data queue lost data
			InputQueueOverRuns.UCData[SWAP_BYTE_3] = *(++pDecodePtr);
			InputQueueOverRuns.UCData[SWAP_BYTE_2] = *(++pDecodePtr);
			InputQueueOverRuns.UCData[SWAP_BYTE_1] = *(++pDecodePtr);
			InputQueueOverRuns.UCData[SWAP_BYTE_0] = *(++pDecodePtr);
			bytePos += sizeof(ULONG);
		}
		if (CheckReplyByte(bytePos + SWAP_BYTE_3) == TRUE) {
			// Get the number of times an output pulse was re-written before finishing
			PulseOutInterrupts.UCData[SWAP_BYTE_3] = *(++pDecodePtr);
			PulseOutInterrupts.UCData[SWAP_BYTE_2] = *(++pDecodePtr);
			PulseOutInterrupts.UCData[SWAP_BYTE_1] = *(++pDecodePtr);
			PulseOutInterrupts.UCData[SWAP_BYTE_0] = *(++pDecodePtr);
			bytePos += sizeof(ULONG);
		}
		if (CheckReplyByte(bytePos + SWAP_BYTE_3) == TRUE) {
			// Get number of times a pulse data queue lost data
			PulseQueueOverRuns.UCData[SWAP_BYTE_3] = *(++pDecodePtr);
			PulseQueueOverRuns.UCData[SWAP_BYTE_2] = *(++pDecodePtr);
			PulseQueueOverRuns.UCData[SWAP_BYTE_1] = *(++pDecodePtr);
			PulseQueueOverRuns.UCData[SWAP_BYTE_0] = *(++pDecodePtr);
			bytePos += sizeof(ULONG);
		}
		if (CheckReplyByte(bytePos) == TRUE) {
			// indexOf out which pulse in channels have had queue over-runs
			PulseOverRunChans = *(++pDecodePtr);
			bytePos++;
		}
		if (CheckReplyByte(bytePos + SWAP_BYTE_1) == TRUE) {
			// indexOf out which channels have had a pulse interrupted, LSB = channel 0
			PulseOutIntChans.UCData[SWAP_BYTE_1] = *(++pDecodePtr);
			PulseOutIntChans.UCData[SWAP_BYTE_0] = *(++pDecodePtr);
			pBrdStats->SaveDIOQueueHistoryRecord(m_pBoard->BoardSlotInstance(), InputQueueOverRuns.ULData,
					PulseOutInterrupts.ULData, PulseQueueOverRuns.ULData, PulseOverRunChans, PulseOutIntChans.USData);
		}
	}
	return retValue;
}
//******************************************************
// GetPILifeHistory()
///
/// Retrieves the PI IO card life history data.
///
/// @return TRUE on Msg decode success (not if error msg returned), else FALSE.
///
//******************************************************
BOOL CProtocol::GetPILifeHistory(void) {
	class CBrdStats *pBrdStats = NULL;
	BOOL retValue = FALSE;
	UCHAR chanNo = 0;
	UCHAR bytePos = 0;
	UCHAR *pDecodePtr = NULL;
	DataItem4bytes PulseQueueOverRuns[MAX_PULSE_COUNTERS];
	DataItem4bytes LastFaultTime[MAX_PULSE_COUNTERS];
	pBrdStats = CBrdStats::GetHandle();
	retValue = GetLifeHistory();		// Decode generic life history
	if (retValue == TRUE) {
		// Decode the PI specific part of the message
		bytePos = LIFE_HISTORY_SPECIFIC_DATA_START_BYTE;
		pDecodePtr = &(m_RxMessage[LIFE_HISTORY_SPECIFIC_DATA_START_BYTE]);
		for (chanNo = 0; chanNo < MAX_PULSE_COUNTERS; chanNo++) {
			if (CheckReplyByte(bytePos + SWAP_BYTE_3) == TRUE) {
				///< Get number of times data queue lost data
				PulseQueueOverRuns[chanNo].UCData[SWAP_BYTE_3] = *(++pDecodePtr);
				PulseQueueOverRuns[chanNo].UCData[SWAP_BYTE_2] = *(++pDecodePtr);
				PulseQueueOverRuns[chanNo].UCData[SWAP_BYTE_1] = *(++pDecodePtr);
				PulseQueueOverRuns[chanNo].UCData[SWAP_BYTE_0] = *(++pDecodePtr);
				pBrdStats->SavePulseQueueOverRuns(m_pBoard->BoardSlotInstance(), chanNo,
						PulseQueueOverRuns[chanNo].ULData);
				bytePos += sizeof(ULONG);
			}
		}
		for (chanNo = 0; chanNo < MAX_PULSE_COUNTERS; chanNo++) {
			if (CheckReplyByte(bytePos + SWAP_BYTE_3) == TRUE) {
				///< Get Life Stats operating time at time of last fault
				LastFaultTime[chanNo].UCData[SWAP_BYTE_3] = *(++pDecodePtr);
				LastFaultTime[chanNo].UCData[SWAP_BYTE_2] = *(++pDecodePtr);
				LastFaultTime[chanNo].UCData[SWAP_BYTE_1] = *(++pDecodePtr);
				LastFaultTime[chanNo].UCData[SWAP_BYTE_0] = *(++pDecodePtr);
				pBrdStats->SavePulseLastFaultTime(m_pBoard->BoardSlotInstance(), chanNo, LastFaultTime[chanNo].ULData);
				bytePos += sizeof(ULONG);
			}
		}
	}
	return retValue;
}
#define RDI_DATA_START_BYTE		4
#define RDI_DATA_BLOCK_LENGTH	4
//******************************************************
// ReadDigInputState()
///
/// Retrieves a block of data from the Digital I/O or alarm card.
///
/// @return TRUE on Msg Tx & Rx success (i.e. data to process), else FALSE.
///
//******************************************************
BOOL CProtocol::ReadDigInputState(void) {
	BOOL MsgSuccess = FALSE;
	CreateTXHeader( RD_DIG_INPUT, NO_MESSAGE_DATA_BYTES);
	MsgSuccess = WaitSendMessage(WAIT_30ms);
	if (MsgSuccess == TRUE) {
		// Process returned digital data
		MsgSuccess = ProcessDigitalBlockTransfer(&m_RxMessage[RDI_DATA_START_BYTE], RDI_DATA_BLOCK_LENGTH);
	}
	return MsgSuccess;
}
#define AGDB_ACK_CHAN_MASK_BYTE		4
//******************************************************
// ACKGoodDigBlock()
///
/// Sends an ACK to a previously supplied data block.
///
/// @return TRUE on Msg Tx & Rx success (i.e. data to process), else FALSE.
///
//******************************************************
BOOL CProtocol::ACKGoodDigBlock(void) {
	BOOL MsgSuccess = FALSE;
	UCHAR ackChannels = 0;
	class CDigConfig *pDigConfig = NULL;
	class CIOConfigManager *pConfigManager = NULL;
	class CDigPulseCard *pDigBoard = static_cast<class CDigPulseCard*>(m_pBoard);
	pConfigManager = CIOConfigManager::GetHandle();
	if (pConfigManager != NULL)
		pDigConfig = pConfigManager->GetDigLocalConfig(static_cast<UCHAR>(m_pBoard->BoardSlotInstance()));
	if (pDigConfig != NULL) {
		ackChannels = static_cast<UCHAR>(pDigBoard->GetBlockTransChansToAck());
		//< Any number equal to or greater than 1 suffices to acqnowledge digital data, so add if there are any inputs
		if (pDigConfig->GetBoardCfgInputSelectionMask() > 0) {
			if (ackChannels == 0)
				ackChannels = 1;
		}
		if (ackChannels > 0) {
			// If there is nothing to acknowledge then do not bother
			CreateTXHeader( ACK_GOOD_DIG_BLK, MESSAGE_DATA_1_BYTE);
			m_TxMessage[AGDB_ACK_CHAN_MASK_BYTE] = ackChannels;
			MsgSuccess = WaitSendMessage(WAIT_30ms);
			if (MsgSuccess == FALSE) {
				pDigBoard->ScheduleDataBlockAck();
			}
		}
	}
	return MsgSuccess;
}
#define RPIB_CHAN_SELECT_MASK_BYTE		4
//******************************************************
// GetPulseDataBlock()
///
/// Retrieves a block of data from the Pulse/Digital I/O card.
///
/// @return TRUE on Msg Tx & Rx success (i.e. data to process), else FALSE.
///
//******************************************************
BOOL CProtocol::GetPulseDataBlock(void) {
	DataItem2bytes DataCnt;		///< Union - cannot initialise
	BOOL MsgSuccess = FALSE;
	class CDigConfig *pDigConfig = NULL;
	pDigConfig = m_pConfigManager->GetDigLocalConfig(static_cast<UCHAR>(m_pBoard->BoardSlotInstance()));
	if (pDigConfig != NULL) {
		CreateTXHeader( RD_PULSE_IN_BLK, MESSAGE_DATA_1_BYTE);
		m_TxMessage[RPIB_CHAN_SELECT_MASK_BYTE] = pDigConfig->GetBoardCfgPulseInSelectionMask();
		MsgSuccess = WaitSendMessage(WAIT_30ms);
		if (MsgSuccess == TRUE) {
			// Process returned data
			DataCnt.UCData[SWAP_BYTE_1] = m_RxMessage[RX_MESS_HI_BYTE_COUNT];
			DataCnt.UCData[SWAP_BYTE_0] = m_RxMessage[RX_MESS_LO_BYTE_COUNT];
			if (DataCnt.USData > 0) {
				MsgSuccess = ProcessPulseBlockTransfer(&m_RxMessage[4], DataCnt.USData);
			}
		}
	}
	return MsgSuccess;
}
//******************************************************
// ACKGoodPulseBlock()
///
/// Sends an ACK to a previously supplied data block.
///
/// @return TRUE on Msg Tx & Rx success (i.e. data to process), else FALSE.
///
//******************************************************
BOOL CProtocol::ACKGoodPulseBlock(void) {
	BOOL MsgSuccess = FALSE;
	class CDigPulseCard *pDigBoard = static_cast<class CDigPulseCard*>(m_pBoard);
	// digital acknowledge message is also used for pulse acknowledge
	CreateTXHeader( ACK_GOOD_DIG_BLK, MESSAGE_DATA_1_BYTE);
	m_TxMessage[AGDB_ACK_CHAN_MASK_BYTE] = static_cast<UCHAR>(pDigBoard->GetBlockTransChansToAck());
	MsgSuccess = WaitSendMessage(WAIT_30ms);
	if (MsgSuccess == FALSE) {
		pDigBoard->ScheduleDataBlockAck();
	}
	return MsgSuccess;
}
#define WRAICONF_START_OF_SETUP_INFO			4
#define WRAICONF_START_OF_RANGE_INFO			12
//******************************************************
///
/// sends new configuration data to an AI IO card.
///
/// @return TRUE on Msg decode success (not if error msg returned), else FALSE.
///
//******************************************************
BOOL CProtocol::DownloadAIConfig(void) {
	BOOL MsgSuccess = FALSE;
	UCHAR chanNo = 0;
	class CAIConfig *pAIConfig = NULL;
	class CChanList *pBoardChanLst = NULL;	// Board channels for processing
	class CIOChanHandler *pChan = NULL;	// General Channel reference
	pAIConfig = m_pConfigManager->GetAILocalConfig(static_cast<UCHAR>(m_pBoard->BoardSlotInstance()));
	if (pAIConfig != NULL) {
		// Can only change config if valid configuration exists
		CreateTXHeader( WR_AI_CONFIG, MESSAGE_DATA_16_BYTES);
		for (chanNo = 0; chanNo < MAX_AI_BOARD_CHANNELS; chanNo++) {
			// Copy the working configuartion data
			m_TxMessage[WRAICONF_START_OF_SETUP_INFO + chanNo] = pAIConfig->GetWrkSetupInfo(chanNo);
		}
		for (chanNo = 0; chanNo < MAX_AI_BOARD_CHANNELS; chanNo++) {
			// Copy the ADC setings for the range set
			m_TxMessage[WRAICONF_START_OF_RANGE_INFO + chanNo] = pAIConfig->GetWrkRangeInfo(chanNo);
		}
		MsgSuccess = WaitSendMessage(WAIT_350ms);
		// No returned data to process
		if (MsgSuccess == TRUE)
			SetConfigCRC();
		// Store the associated default values
		pBoardChanLst = m_pBoard->GetChanSchedule();
		if (pBoardChanLst != NULL) {
			for (chanNo = 0; chanNo < MAX_AI_BOARD_CHANNELS; chanNo++) {
				pChan = pBoardChanLst->GetChannelRef(chanNo);
				if (pChan != NULL) {
					// Store the default RT calibration value (only if the range is set to millivolts)
					pChan->StoreDefaultRTCal(pAIConfig->QueryHighConstantCurrent(chanNo));
				}
			}
		}
	}
	return MsgSuccess;
}
//******************************************************
// UploadAIConfig()
///
/// Gets current configuration data from an AI IO card.
///
/// @return TRUE on Msg decode success (not if error msg returned), else FALSE.
///
//******************************************************
BOOL CProtocol::UploadAIConfig(void) {
	BOOL MsgSuccess = FALSE;
	UCHAR *pSetup = NULL;
	UCHAR chanNo = 0;
	class CIOConfigManager *pConfigManager = NULL; ///< Configuration manager holder
	class CAIConfig *pAIConfig = NULL;
	pConfigManager = CIOConfigManager::GetHandle();
	if (pConfigManager != NULL)
		pAIConfig = m_pConfigManager->GetAILocalConfig(static_cast<UCHAR>(m_pBoard->BoardSlotInstance()));
	if (pAIConfig != NULL) {
		CreateTXHeader( RD_AI_CONFIG, NO_MESSAGE_DATA_BYTES);
		MsgSuccess = WaitSendMessage(WAIT_100ms);
		if (MsgSuccess == TRUE) {
			// Process returned data
			pAIConfig->SetUploadedVersion(static_cast<USHORT>(m_RxMessage[4]));
			pSetup = &m_RxMessage[6];
			for (chanNo = 0; chanNo < TOPSLOT_AICHAN_SIZE; chanNo++) {
				pAIConfig->SetUploadedCfg(chanNo, *pSetup, *(pSetup + 1));
				pSetup += sizeof(USHORT);		// Skip to next channel range
			}
		}
	}
	return MsgSuccess;
}
//******************************************************
// GetAICalPoints()
///
/// Retrieves the available calibration data for a given channel on the AO board.
///
/// @return TRUE on Msg Tx & Rx success (i.e. data to process), else FALSE.
///
//******************************************************
BOOL CProtocol::GetAICalPoints(const UCHAR calMethod) {
	USHORT ChanType;
	USHORT RangeEnum;
	UCHAR RangeComp;
	UCHAR RangeGain;
	UCHAR chanNo;
	UCHAR RangePair;
	class CATECal *pATECal = NULL;
	class CAIRanges *pAIRange = NULL;
	BOOL MsgSuccess = FALSE;
	pAIRange = CAIRanges::GetHandle();
	pATECal = CATECal::GetHandle();
	UCHAR ucBoardType = m_pBoard->WhatBoardSubType();
	if ((pATECal != NULL) && (pAIRange != NULL)) {
		if (calMethod == V6_AI_FACTORY_CAL) {
			CreateTXHeader( RD_FACT_CAL, MESSAGE_DATA_2_BYTES);
		} else {
			if (AI_CARD_TYPE_V7AI == ucBoardType) {
				CreateTXHeader( RD_USER_CAL_24BIT, MESSAGE_DATA_2_BYTES);
			} else {
				CreateTXHeader( RD_USER_CAL, MESSAGE_DATA_2_BYTES);
			}
		}
		/// @todo: Need to choose channel number
		chanNo = 0;
		// Get input pair and gain from AI ranges for the current range
		pATECal->GetAIChannelRange(chanNo, &ChanType, &RangeEnum);
		pAIRange->GetBaseChannelConfig(RangeEnum, V6AI_ISSUE_1, &RangeComp, &RangeGain, &RangePair);
		m_TxMessage[4] = RangePair;		///< Input pair
		m_TxMessage[5] = RangeGain;		///< Gain
		MsgSuccess = WaitSendMessage(WAIT_50ms);
		if (MsgSuccess == TRUE) {
			// Process returned data
		}
	}
	return MsgSuccess;
}
//******************************************************
///
/// Sends AI factory or user calibration data to the IO card.
/// @param[in] calMethod - AI_FACTORY_CAL (factory calibration) or AI_USER_CAL (user calibration).
///
/// @return TRUE on Msg Tx & Rx success (i.e. data to process), else FALSE.
///
//******************************************************
BOOL CProtocol::SetAICalPoints(const UCHAR calMethod) {
	UCHAR chanNo;
	UCHAR msgOffset;
	UCHAR noOfChannels = 0;
	DataItem4bytes CrdTimeData;		// (union cannot initialise)
	DataItem2bytes calPoint;			// (union cannot initialise)
	DataItem4bytes calPointNewV7AI;
	//	USHORT ChanType;
	//	USHORT RangeEnum;
#ifdef RT_CHAN_CAL_USE_MV_CAL
	USHORT forBitManipulation;
#endif
	UCHAR RangeComp;
	UCHAR RangeGain;
	UCHAR RangePair;
	UCHAR firstChanNo = 0;
	class CAIConfig *pAIConfig = NULL;
	//	class CAIRanges *pAIRange = NULL;
	const T_AICHANNELCAL *pAIChanCal = NULL;
	class CIOConfigManager *pConfigManager = NULL; ///< Configuration manager holder
	class CATECal *pATECal = NULL;
	USHORT chanMask = 0;
	BOOL MsgSuccess = FALSE;
	BOOL UserRangeIdentified = FALSE;
	pATECal = CATECal::GetHandle();
	pConfigManager = CIOConfigManager::GetHandle();
	//	pAIRange = CAIRanges::GetHandle();
	//	if( (pConfigManager != NULL) && (pATECal != NULL) && (pAIRange != NULL) )
	if ((pConfigManager != NULL) && (pATECal != NULL)) {
		pAIConfig = pConfigManager->GetAILocalConfig(static_cast<UCHAR>(m_pBoard->BoardSlotInstance()));
		chanMask = pATECal->GetChannelSelectionMask();
		/*
		 if( 0 )
		 {
		 // Calculate the number of channels to calibrate
		 for( chanNo = 0; chanNo < TOPSLOT_AICHAN_SIZE; chanNo++ )
		 {
		 if( GetBits(chanMask, chanNo, 1) != 0 )
		 {
		 UserRangeIdentified = pATECal->GetAIChannelRange( chanNo, &ChanType, &RangeEnum);
		 noOfChannels++;
		 }
		 }
		 // If no channels then do not send, assume that all selected channels are being calibrated to the same range
		 if( UserRangeIdentified == TRUE )
		 {
		 if( (noOfChannels > 0) && (ChanType == AI_CHANNEL_TYPE_LINEAR_VOLTS) )
		 pAIRange->GetBaseChannelConfig( RangeEnum, ISSUE_1, &RangeComp, &RangeGain, &RangePair);
		 }
		 }
		 else
		 {
		 */
		for (chanNo = 0; chanNo < TOPSLOT_AICHAN_SIZE; chanNo++) {
			if (GetBits(chanMask, chanNo, 1) != 0) {
				if (firstChanNo == 0)
					firstChanNo = chanNo;
				noOfChannels++;
			}
		}
		// Working copy is the only reference to range being calibrated
		pAIConfig->GetWorkingChannelConfig(firstChanNo, &RangeComp, &RangeGain, &RangePair);
		//		}
		UCHAR ucBoardType = m_pBoard->WhatBoardSubType();
		if (pAIConfig != NULL) {
			if (calMethod == V6_AI_FACTORY_CAL) {
				CreateTXHeader( FACT_CALIB, (noOfChannels * 4) + 8);
			} else {
				if (AI_CARD_TYPE_V7AI == ucBoardType) {
					CreateTXHeader( USER_CALIB_24BIT, (noOfChannels * 8) + 7); // 4 Bytes of Span + 4 Bytes of Zeroes
				} else {
					CreateTXHeader( USER_CALIB, (noOfChannels * 4) + 7); // 2 Bytes of Span + 2 Bytes of Zeroes
				}
			}
			MsgSuccess = SetTimeNowSecs(&CrdTimeData.UCData[SWAP_BYTE_0]);
			m_TxMessage[7] = CrdTimeData.UCData[SWAP_BYTE_0];
			m_TxMessage[6] = CrdTimeData.UCData[SWAP_BYTE_1];
			m_TxMessage[5] = CrdTimeData.UCData[SWAP_BYTE_2];
			m_TxMessage[4] = CrdTimeData.UCData[SWAP_BYTE_3];
			msgOffset = 8;
			if (calMethod == V6_AI_FACTORY_CAL) {
				// Factory cal has an additional rig number byte
				m_TxMessage[msgOffset++] = pATECal->GetRigNo();
			}
			m_TxMessage[msgOffset++] = static_cast<UCHAR>(chanMask);
			m_TxMessage[msgOffset++] = RangePair;		///< Input pair
			m_TxMessage[msgOffset++] = RangeGain;		///< Gain
			for (chanNo = 0; chanNo < TOPSLOT_AICHAN_SIZE; chanNo++) {
				if (GetBits(chanMask, chanNo, 1) != 0) {
					// Copy each channels cal data over in turn
					pAIChanCal = pATECal->GetAIChanDownloadCal(chanNo);
					if (pAIChanCal != NULL) {
						if (AI_CARD_TYPE_V7AI == ucBoardType) {
							calPointNewV7AI.ULData = pAIChanCal->zeroCount;
							m_TxMessage[msgOffset++] = calPointNewV7AI.UCData[SWAP_BYTE_3];
							m_TxMessage[msgOffset++] = calPointNewV7AI.UCData[SWAP_BYTE_2];
							m_TxMessage[msgOffset++] = calPointNewV7AI.UCData[SWAP_BYTE_0];
							m_TxMessage[msgOffset++] = calPointNewV7AI.UCData[SWAP_BYTE_1];
							calPointNewV7AI.ULData = pAIChanCal->spanCount;
							m_TxMessage[msgOffset++] = calPointNewV7AI.UCData[SWAP_BYTE_3];
							m_TxMessage[msgOffset++] = calPointNewV7AI.UCData[SWAP_BYTE_2];
							m_TxMessage[msgOffset++] = calPointNewV7AI.UCData[SWAP_BYTE_0];
							m_TxMessage[msgOffset++] = calPointNewV7AI.UCData[SWAP_BYTE_1];
						} else {
							calPoint.USData = pAIChanCal->zeroCount;
							m_TxMessage[msgOffset++] = calPoint.UCData[SWAP_BYTE_0];
							m_TxMessage[msgOffset++] = calPoint.UCData[SWAP_BYTE_1];
							calPoint.USData = pAIChanCal->spanCount;
							m_TxMessage[msgOffset++] = calPoint.UCData[SWAP_BYTE_0];
							m_TxMessage[msgOffset++] = calPoint.UCData[SWAP_BYTE_1];
						}
					}
				}
			}
		}
		if (MsgSuccess == TRUE)
			MsgSuccess = WaitSendMessage(WAIT_750ms);
	}
#ifdef RT_CHAN_CAL_USE_MV_CAL
	// And now the really horrible bit, lets send the message again to the RT channels
	// if factory calibration of the mV input was being performed.
	// In an ideal world this would be a seperate calibration method; however we are just using the
	// same calibration values from the mV input pair for the RT input pair
	// But of course they were not good enough
	if( (MsgSuccess == TRUE) && (RangePair == PairA3A4) && (calMethod == AI_FACTORY_CAL) )
	{
		forBitManipulation = RangePair;		///< Input pair
		SetBits(&forBitManipulation, (PairA7A8 >> 4), 4, 2);
		m_TxMessage[10] = static_cast<UCHAR> (forBitManipulation);
		MsgSuccess = WaitSendMessage( WAIT_750ms );
	}
#endif
	return MsgSuccess;
}
//******************************************************
///
/// Sends AO factory calibration data to the IO card.
///
/// @return TRUE on Msg Tx & Rx success (i.e. data to process), else FALSE.
///
//******************************************************
BOOL CProtocol::SetAOFactoryCalPoints(void) {
	UCHAR chanNo;
	UCHAR msgOffset;
	DataItem4bytes CrdTimeData;		// (union cannot initialise)
	DataItem2bytes calPoint;			// (union cannot initialise)
	const T_AOCHANCAL *pAOChanCal = NULL;
	//	class CAOConfig *pAOConfig = NULL;
	BOOL MsgSuccess = FALSE;
	class CATECal *pATECal = NULL;
	pATECal = CATECal::GetHandle();
	//	pAOConfig = m_pConfigManager->GetAOLocalConfig( static_cast<UCHAR> (m_pBoard->BoardSlotInstance()) );
	if (pATECal != NULL) {
		CreateTXHeader( SET_AO_CALIB, MESSAGE_DATA_17_BYTES);
		MsgSuccess = SetTimeNowSecs(&CrdTimeData.UCData[0]);
		m_TxMessage[7] = CrdTimeData.UCData[SWAP_BYTE_0];
		m_TxMessage[6] = CrdTimeData.UCData[SWAP_BYTE_1];
		m_TxMessage[5] = CrdTimeData.UCData[SWAP_BYTE_2];
		m_TxMessage[4] = CrdTimeData.UCData[SWAP_BYTE_3];
		m_TxMessage[8] = pATECal->GetRigNo();
		msgOffset = 9;
		for (chanNo = 0; chanNo < TOPSLOT_AOCHAN_SIZE; chanNo++) {
			// Copy each channels cal data over in turn
			pAOChanCal = pATECal->GetAOChanCal(chanNo);
			m_TxMessage[msgOffset++] = pAOChanCal->Offset;
			calPoint.USData = pAOChanCal->RawCount20mA;
			m_TxMessage[msgOffset++] = calPoint.UCData[SWAP_BYTE_1];
			m_TxMessage[msgOffset++] = calPoint.UCData[SWAP_BYTE_0];
		}
		if (MsgSuccess == TRUE)
			MsgSuccess = WaitSendMessage(WAIT_150ms);
	}
	return MsgSuccess;
}
//******************************************************
///
/// Query the status of the AO card.
///
/// @return TRUE on Msg Tx & Rx success (i.e. data to process), else FALSE.
///
//******************************************************
BOOL CProtocol::QueryAOStatus(void) {
	BOOL MsgSuccess = FALSE;
	UCHAR chanNo = 0;
	CreateTXHeader( GET_AO_STATUS, NO_MESSAGE_DATA_BYTES);
	MsgSuccess = WaitSendMessage(WAIT_30ms);
	if (MsgSuccess == TRUE) {
		// Process returned data
		for (chanNo = 0; chanNo < TOPSLOT_AOCHAN_SIZE; chanNo++) {
			if (DecodeAOChannelStatus(m_RxMessage[4 + chanNo], chanNo) == FALSE)
				MsgSuccess = FALSE;
		}
	}
	return MsgSuccess;
}
//******************************************************
// SetAIRawMode()
///
/// Sets the AI card into raw acquisition mode.
///
/// @return TRUE on Msg Tx & Rx success (i.e. data to process); otherwise FALSE.
///
//******************************************************
BOOL CProtocol::SetAIRawMode(void) {
	BOOL MsgSuccess = FALSE;
	const T_AIBOARDCONFIG *pconfig = NULL;
	class CAIConfig *pAIConfig = NULL;
	class CAICard *pAICard = NULL;
	pAICard = static_cast<class CAICard*>(m_pBoard);
	pAIConfig = pAICard->m_pAIConfigObj;
	CreateTXHeader( SET_RAW_MODE, MESSAGE_DATA_2_BYTES);
	pconfig = pAIConfig->GetAIconfig();
	m_TxMessage[4] = ALL_EIGHT_CHANNELS;					// Set all channels
	m_TxMessage[5] = pconfig->RawMode;		// Set raw mode to overall state
	///@ todo: otherwise set individual channels
	MsgSuccess = WaitSendMessage(WAIT_30ms);
	if (MsgSuccess == TRUE) {
		// Process returned data
	}
	return MsgSuccess;
}
#define CHANNELS_TO_DESELECT			4
//******************************************************
// AIRTCurrentDeselect()
///
/// Turns the RT constant current off for select channels.
///
/// @return TRUE on Msg Tx & Rx success (i.e. data to process); otherwise FALSE.
///
//******************************************************
BOOL CProtocol::AIRTCurrentDeselect(void) {
	BOOL MsgSuccess = FALSE;
	class CATECal *pATECal = NULL;
	pATECal = CATECal::GetHandle();
	if (pATECal != NULL) {
		CreateTXHeader( TURN_RT_CURR_OFF, MESSAGE_DATA_1_BYTE);
		m_TxMessage[CHANNELS_TO_DESELECT] = static_cast<UCHAR>(pATECal->GetRTISrcChannelDisableMask());
		MsgSuccess = WaitSendMessage(WAIT_30ms);
		// No returned data to process
	}
	return MsgSuccess;
}
#define ALL_CHANNELS_SELECTED			1
#define NO_CHANNELS_SELECTED			0
//******************************************************
// SetAORawMode()
///
/// Sets the AO card into raw acquisition mode.
///
/// @return TRUE on Msg Tx & Rx success (i.e. data to process), else FALSE.
///
//******************************************************
BOOL CProtocol::SetAORawMode(void) {
	BOOL MsgSuccess = FALSE;
	UCHAR chanNo;
	USHORT chanMask = 0;			///< Default raw mode off
	class CBrdInfo *pBrdInfo = NULL;
	class CAOConfig *pAOConfig = NULL;
	class CAOCard *pAOCard = NULL;
	pBrdInfo = CBrdInfo::GetHandle();
	pAOCard = static_cast<class CAOCard*>(m_pBoard);
	if ((pAOCard != NULL) && (pBrdInfo != NULL))
		pAOConfig = pAOCard->m_pAOConfigObj;
	if (pAOConfig != NULL) {
		CreateTXHeader( SET_AO_RAWMODE, MESSAGE_DATA_1_BYTE);
		/// Set individual channels state
		for (chanNo = 0; chanNo < pBrdInfo->GetNoOfChannels(pAOCard->BoardSlotInstance()); chanNo++) {
			if (pAOConfig->QueryChannelRawSelected(chanNo) == TRUE) {
				SetBits(&chanMask, 1, chanNo, 1);
			}
		}
		// All channels must be selected on block
		if (chanMask > 0) {
			m_TxMessage[4] = ALL_CHANNELS_SELECTED;	///< All channels must be selected on block
		} else {
			m_TxMessage[4] = NO_CHANNELS_SELECTED;
		}
		MsgSuccess = WaitSendMessage(WAIT_30ms);
		// No returned data to process
	}
	return MsgSuccess;
}
#define WAO_ANAL_OUT_CHANNEL_BYTE			4
#define WAO_ANAL_OUT_VALUE_START_BYTE		5
#define WAO_ANAL_OUT_STATUS_RX_BYTE			5
//******************************************************
// WriteATEAnalOut()
///
/// Write analogue output to all enabled card channels requiring an update.
///
/// @return TRUE on Msg Tx & Rx success (i.e. data to process), else FALSE.
///
//******************************************************
BOOL CProtocol::WriteATEAnalOut(void) {
	BOOL MsgRqd = FALSE;
	BOOL MsgSuccess = FALSE;
	DataItem2bytes AOOutput;					///< Union; cannot initialise
	const T_AOBOARDCONFIG *pconfig = NULL;
	class CAOConfig *pAOConfig = NULL;
	class CAOCard *pAOCard = NULL;
	class CATECal *pATECal = NULL;
	BOOL firstChanFound = FALSE;
	UCHAR firstChan = 0;
	UCHAR chanNo = 0;
	pAOCard = static_cast<class CAOCard*>(m_pBoard);
	if (pAOCard != NULL)
		pAOConfig = pAOCard->m_pAOConfigObj;
	pATECal = CATECal::GetHandle();
	if ((pATECal != NULL) && (IsRunningAsATEEquipment() == TRUE)) {
		// indexOf the next channel to service; if any
		do {
			MsgRqd = pATECal->GetNextATEAnalOut(&chanNo, &AOOutput.USData);
			if ((MsgRqd == TRUE) && (firstChanFound == FALSE)) {
				// Make a record of the first channel to be updated
				firstChan = chanNo;
				firstChanFound = TRUE;
			} else if (MsgRqd == TRUE) {
				// Finished if this is the second time processing the first channel to be updated
				if (firstChan == chanNo)
					MsgRqd = FALSE;
			}
			if (MsgRqd == TRUE) {
				CreateTXHeader( WR_ANAL_OUTPUT, MESSAGE_DATA_3_BYTES);
				m_TxMessage[WAO_ANAL_OUT_CHANNEL_BYTE] = chanNo;					// Set a single channel
				if (IsRunningAsATEEquipment() == TRUE) {
					// Only use ATECal structure if ATE equipment
					m_TxMessage[WAO_ANAL_OUT_VALUE_START_BYTE] = AOOutput.UCData[SWAP_BYTE_1];
					m_TxMessage[WAO_ANAL_OUT_VALUE_START_BYTE + SWAP_BYTE_1] = AOOutput.UCData[SWAP_BYTE_0];
				}
				MsgSuccess = WaitSendMessage(WAIT_30ms);
				if (MsgSuccess == TRUE) {
					// Log the state of the channel load
					if (DecodeAOChannelStatus(m_RxMessage[WAO_ANAL_OUT_STATUS_RX_BYTE], chanNo) == FALSE)
						MsgSuccess = FALSE;
				}
			}
		} while (MsgRqd == TRUE);
	}
	return MsgSuccess;
}
//******************************************************
// WriteAnalOut()
///
/// Write the first analogue output channels that is enabled and requiring an update.
///
/// @return TRUE on Msg Tx & Rx success (i.e. data to process), else FALSE.
///
//******************************************************
BOOL CProtocol::WriteAnalOut(void) {
	BOOL MsgRqd = FALSE;
	BOOL MsgSuccess = FALSE;
	DataItem2bytes AOOutput;					///< Union; cannot initialise
	class CAOCard *pAOBoard = static_cast<class CAOCard*>(m_pBoard);
	class CAOConfig *pAOConfig = NULL;
	class CAOCard *pAOCard = NULL;
	UCHAR firstChan = 0;
	UCHAR nextChanNo = 0;
	UCHAR chanNo = 0;
	pAOCard = static_cast<class CAOCard*>(m_pBoard);
	if (pAOCard != NULL)
		pAOConfig = pAOCard->m_pAOConfigObj;
	if (IsRunningAsATEEquipment() == FALSE) {
		// Operating in recorder
		MsgRqd = pAOBoard->ProcessOutputChannel(&AOOutput.USData, nextChanNo, &chanNo);
		// Make a record of the first channel to be updated
		if (MsgRqd == TRUE)
			firstChan = chanNo;
		// indexOf the next channel to service; if any
		while (MsgRqd == TRUE) {
			if (MsgRqd == TRUE) {
				CreateTXHeader( WR_ANAL_OUTPUT, MESSAGE_DATA_3_BYTES);
				m_TxMessage[WAO_ANAL_OUT_VALUE_START_BYTE] = AOOutput.UCData[SWAP_BYTE_1];
				m_TxMessage[WAO_ANAL_OUT_VALUE_START_BYTE + SWAP_BYTE_1] = AOOutput.UCData[SWAP_BYTE_0];
				m_TxMessage[WAO_ANAL_OUT_CHANNEL_BYTE] = chanNo;					// Set a single channel
				//		qDebug(L"Anal out = %d\n", DataCnt.USData);
				MsgSuccess = WaitSendMessage(WAIT_30ms);
				if (MsgSuccess == TRUE) {
					// Process returned data
					// Log the state of the channel load
					if (DecodeAOChannelStatus(m_RxMessage[WAO_ANAL_OUT_STATUS_RX_BYTE], chanNo) == FALSE)
						MsgSuccess = FALSE;
					nextChanNo = chanNo + 1;
					// Is there another channel to update
					MsgRqd = pAOBoard->ProcessOutputChannel(&AOOutput.USData, nextChanNo, &chanNo);
					//					chanNo++;
					// Finished if this is the second time processing the first channel to be updated
					if (firstChan == chanNo)
						MsgRqd = FALSE;
					if (MsgRqd == FALSE)
						MsgSuccess = TRUE;
				}
			}
		}
	}
	return MsgSuccess;
}
//******************************************************
// SetUseCalValues()
///
/// Deselects raw mode channel readings.
///
/// @return TRUE on Msg Tx & Rx success (i.e. data to process), else FALSE.
///
//******************************************************
BOOL CProtocol::SetUseCalValues(void) {
	BOOL MsgSuccess = FALSE;
	CreateTXHeader( SET_RAW_MODE, MESSAGE_DATA_2_BYTES);
	m_TxMessage[4] = 0xf;			// Set all channels
	m_TxMessage[5] = 0;			// Set raw mode off
	/// @todo: Need to select the correct type of calibration to use?
	MsgSuccess = WaitSendMessage(WAIT_30ms);
	// No returned data to process
	return MsgSuccess;
}
#define MAINS_FREQ_MESS_POS		4
//******************************************************
// SetMainsFrequency()
///
/// Sets the mains frequency that the AI is running at.
///
/// @return TRUE on Msg Tx & Rx success (i.e. data to process), else FALSE.
///
//******************************************************
BOOL CProtocol::SetMainsFrequency(void) {
#ifndef V6IOTEST
	T_PGENNONVOL ptGenNonVol = pSYSTEM_INFO->GetFactoryConfig();
#endif
	QString err;
	BOOL MsgSuccess = FALSE;
#ifndef V6IOTEST
	if (ptGenNonVol != NULL)
#endif
	{
		CreateTXHeader( SET_MAINS_F, MESSAGE_DATA_1_BYTE);
#ifndef V6IOTEST
		m_TxMessage[MAINS_FREQ_MESS_POS] = static_cast<UCHAR>(ptGenNonVol->Localisation.MainFreq);
#else
		// Default to 50 Hz operation
		m_TxMessage[MAINS_FREQ_MESS_POS] = MAINS_FREQ_50HZ;
#endif
		MsgSuccess = WaitSendMessage(WAIT_750ms);
		// No returned data to process
	}
#ifndef V6IOTEST
	else {
		err = QString::asprintf("Could not set I/O card %d mains frequency; could not obtain recorder profile",
				m_pBoard->BoardSlotInstance());
		AddErrorToReport(err.toLocal8Bit().data());
	}
#endif
	return MsgSuccess;
}
//******************************************************
// GetAOCalData()
///
/// Retrieves the available calibration data for a given channel on the AO board.
///
/// @return TRUE on Msg Tx & Rx success (i.e. data to process), else FALSE.
///
//******************************************************
BOOL CProtocol::GetAOCalData(void) {
	BOOL MsgSuccess = FALSE;
	CreateTXHeader( RD_AO_CALIB, NO_MESSAGE_DATA_BYTES);
	MsgSuccess = WaitSendMessage(WAIT_150ms);
	if (MsgSuccess == TRUE) {
		// Process returned data
	}
	return MsgSuccess;
}
//******************************************************
// UploadAOConfig()
///
/// Obtains configuration data from an AO IO card.
///
/// @return TRUE on Msg decode success (not if error msg returned), else FALSE.
///
//******************************************************
BOOL CProtocol::UploadAOConfig(void) {
	BOOL MsgSuccess = FALSE;
	UCHAR chanNo = 0;
	class CAOConfig *pAOConfig = NULL;
	pAOConfig = m_pConfigManager->GetAOLocalConfig(static_cast<UCHAR>(m_pBoard->BoardSlotInstance()));
	if (pAOConfig != NULL) {
		// Can only change config if valid confuguration exists
		CreateTXHeader( RD_AO_CONFIG, NO_MESSAGE_DATA_BYTES);
		MsgSuccess = WaitSendMessage(WAIT_300ms);
		{
			// Process returned data
		}
	}
	return MsgSuccess;
}
#define WAC_DEFAULT_CHAN_OUT_START_BYTE		5
#define WAC_CHAN_MASK_BYTE					4
//******************************************************
// DownloadAOConfig()
///
/// sends new configuration data to an AO IO card.
///
/// @return TRUE on Msg decode success (not if error msg returned), else FALSE.
///
//******************************************************
BOOL CProtocol::DownloadAOConfig(void) {
	BOOL MsgSuccess = FALSE;
	UCHAR chanNo = 0;
	USHORT chanMask = 0;
	DataItem2bytes AOOutput;					///< Union; cannot initialise
	class CPPIOServiceManager *pServiceManagerObj = NULL;	///< Service manager
	class CInputConditioning *pICService = NULL;	///< Input conditioning service
	class CAOConfig *pAOConfig = NULL;
	pAOConfig = m_pConfigManager->GetAOLocalConfig(static_cast<UCHAR>(m_pBoard->BoardSlotInstance()));
	pServiceManagerObj = CPPIOServiceManager::GetHandle();
	if (pServiceManagerObj != NULL)
		pICService = pServiceManagerObj->GetICService();
	if ((pAOConfig != NULL) && (pICService != NULL)) {
		// Can only change config if valid confuguration exists
		CreateTXHeader( WR_AO_CONFIG, MESSAGE_DATA_9_BYTES);
		for (chanNo = 0; chanNo < TOPSLOT_AOCHAN_SIZE; chanNo++) {
			// If 4-20mA range then set to 4mA; otherwise set to 0mA
			AOOutput.USData = pICService->LimitCurrentLoopmAOutput(m_pBoard->BoardSlotInstance(),
					pAOConfig->QueryChannelLimitSelected(chanNo),
					FALSE, static_cast<USHORT>(0));
			m_TxMessage[WAC_DEFAULT_CHAN_OUT_START_BYTE + (chanNo * sizeof(USHORT))] = AOOutput.UCData[SWAP_BYTE_1];
			m_TxMessage[WAC_DEFAULT_CHAN_OUT_START_BYTE + SWAP_BYTE_1 + (chanNo * sizeof(USHORT))] =
					AOOutput.UCData[SWAP_BYTE_0];
			SetBits(&chanMask, pAOConfig->QueryChannelEnabled(chanNo), chanNo, 1);
		}
		m_TxMessage[WAC_CHAN_MASK_BYTE] = static_cast<UCHAR>(chanMask);	/// Enabled mask
		MsgSuccess = WaitSendMessage(WAIT_350ms);
		// No returned data to process
		if (MsgSuccess == TRUE)
			SetConfigCRC();
	}
	return MsgSuccess;
}
#define WDC_CHAN_ENABLED_MASK			4
#define WDC_CHAN_OUTPUT_PULSE_MASK		6
#define WDC_CHAN_INPUT_SELECT_MASK		8
#define WDC_CHAN_OUTPUT_FAILSAFE_MASK	10
#define WDC_PULSE_DURATION_CHAN_1		12
//******************************************************
// DownloadDigitalPulseConfig()
///
/// sends new configuration data to a Digital or Pulse IO card.
///
/// @return TRUE on Msg decode success (not if error msg returned), else FALSE.
///
//******************************************************
BOOL CProtocol::DownloadDigitalPulseConfig(void) {
	BOOL MsgSuccess = FALSE;
	UCHAR chanNo = 0;
	class CDigConfig *pDigConfig = NULL;
	class CIOConfigManager *pConfigManager = NULL;
	pConfigManager = CIOConfigManager::GetHandle();
	if (pConfigManager != NULL)
		pDigConfig = pConfigManager->GetDigLocalConfig(static_cast<UCHAR>(m_pBoard->BoardSlotInstance()));
	if (pDigConfig != NULL) {
		// Can only change config if valid configuration exists
		CreateTXHeader( WR_DIG_CONFIG, MESSAGE_DATA_45_BYTES);
		//all of the USHORT entries need to be byte swapped as they are being entered low byte / high byte,
		//and need to be high byte / low byte
		// Get digital I/O configuration
		*(reinterpret_cast<USHORT*>(&m_TxMessage[WDC_CHAN_ENABLED_MASK])) =
				pDigConfig->GetBoardCfgIODigitalEnabledMask();
		m_TxMessage[4] |= pDigConfig->GetBoardCfgPulseInSelectionMask();
		/// TODO CHeck the output at runtime
		swap(reinterpret_cast<char*>(&m_TxMessage[WDC_CHAN_ENABLED_MASK]),
				reinterpret_cast<char*>(&m_TxMessage[WDC_CHAN_ENABLED_MASK]));
		*(reinterpret_cast<USHORT*>(&m_TxMessage[WDC_CHAN_OUTPUT_PULSE_MASK])) =
				pDigConfig->GetBoardCfgOutputPulseMask();
		swab(reinterpret_cast<char*>(&m_TxMessage[WDC_CHAN_OUTPUT_PULSE_MASK]),
				reinterpret_cast<char*>(&m_TxMessage[WDC_CHAN_OUTPUT_PULSE_MASK]));
		*(reinterpret_cast<USHORT*>(&m_TxMessage[WDC_CHAN_INPUT_SELECT_MASK])) =
				pDigConfig->GetBoardCfgInputSelectionMask();
		m_TxMessage[8] |= pDigConfig->GetBoardCfgPulseInSelectionMask();
		swab(reinterpret_cast<char*>(&m_TxMessage[WDC_CHAN_INPUT_SELECT_MASK]),
				reinterpret_cast<char*>(&m_TxMessage[WDC_CHAN_INPUT_SELECT_MASK]));
		*(reinterpret_cast<USHORT*>(&m_TxMessage[WDC_CHAN_OUTPUT_FAILSAFE_MASK])) =
				pDigConfig->GetBoardCfgOutputFailSafe();
		swab(reinterpret_cast<char*>(&m_TxMessage[WDC_CHAN_OUTPUT_FAILSAFE_MASK]),
				reinterpret_cast<char*>(&m_TxMessage[WDC_CHAN_OUTPUT_FAILSAFE_MASK]));
		// Add the pulse duration settings
		for (chanNo = 0; chanNo < BOTTOMSLOT_DIGCHAN_SIZE; chanNo++) {
			*(reinterpret_cast<USHORT*>(&m_TxMessage[(WDC_PULSE_DURATION_CHAN_1 + (sizeof(USHORT) * chanNo))])) =
					pDigConfig->GetBoardCfgOutputPulseDuration(chanNo);
			swab(reinterpret_cast<char*>(&m_TxMessage[(WDC_PULSE_DURATION_CHAN_1 + (sizeof(USHORT) * chanNo))]),
					reinterpret_cast<char*>(&m_TxMessage[(WDC_PULSE_DURATION_CHAN_1 + (sizeof(USHORT) * chanNo))]),
					sizeof(USHORT));
		}
		// Add pulse input configuration
		m_TxMessage[44] = pDigConfig->GetBoardCfgPulseInSelectionMask();
		for (chanNo = 0; chanNo < HW_BOTTOMSLOT_PULSECHAN_SIZE; chanNo++)
			m_TxMessage[45 + chanNo] = pDigConfig->GetBoardCfgPulseAcqRate(chanNo);
		MsgSuccess = WaitSendMessage(WAIT_750ms);
		// No returned data to process
		if (MsgSuccess == TRUE)
			SetConfigCRC();
	}
	return MsgSuccess;
}
//******************************************************
// UploadDigitalPulseConfig()
///
/// retrives configuration data from a Digital or Pulse IO card.
///
/// @return TRUE on Msg decode success (not if error msg returned), else FALSE.
///
//******************************************************
BOOL CProtocol::UploadDigitalPulseConfig(void) {
	BOOL MsgSuccess = FALSE;
	CreateTXHeader( RD_DIG_CONFIG, NO_MESSAGE_DATA_BYTES);
	MsgSuccess = WaitSendMessage(WAIT_300ms);
	return MsgSuccess;
}
#define US_SPECIFIC_HISTORY_DATA_START_BYTE		32
//******************************************************
// SaveAILifeHistory()
///
/// Uploads the AI IO card life history data.
///
/// @return TRUE on Msg decode success (not if error msg returned), else FALSE.
///
//******************************************************
BOOL CProtocol::SaveAILifeHistory(void) {
	DataItem4bytes MinCjTemp;			// (union cannot initialise)
	DataItem4bytes MaxCjTemp;			// (union cannot initialise)
	DataItem4bytes QueueOverRuns[MAX_ADC_CHANNELS];	// (union cannot initialise)
	class CBrdStats *pBrdStats = NULL;
	UCHAR *pMsgStart = NULL;
	USHORT chanNo = 0;
	BOOL retValue = FALSE;
	pBrdStats = CBrdStats::GetHandle();
	// Encode the AI specific part of the message
	pMsgStart = &m_TxMessage[US_SPECIFIC_HISTORY_DATA_START_BYTE];
	///< Get CJC minimum temperature
	MinCjTemp.FData = pBrdStats->GetAIMinCJTempHistory(m_pBoard->BoardSlotInstance());
	*(++pMsgStart) = MinCjTemp.UCData[SWAP_BYTE_3];
	*(++pMsgStart) = MinCjTemp.UCData[SWAP_BYTE_2];
	*(++pMsgStart) = MinCjTemp.UCData[SWAP_BYTE_1];
	*(++pMsgStart) = MinCjTemp.UCData[SWAP_BYTE_0];
	///< Get CJC maximum temperature
	MaxCjTemp.FData = pBrdStats->GetAIMaxCJTempHistory(m_pBoard->BoardSlotInstance());
	*(++pMsgStart) = MaxCjTemp.UCData[SWAP_BYTE_3];
	*(++pMsgStart) = MaxCjTemp.UCData[SWAP_BYTE_2];
	*(++pMsgStart) = MaxCjTemp.UCData[SWAP_BYTE_1];
	*(++pMsgStart) = MaxCjTemp.UCData[SWAP_BYTE_0];
	for (chanNo = 0; chanNo < MAX_ADC_CHANNELS; chanNo++) {
		///< Get number of times data queue lost data
		QueueOverRuns[chanNo].ULData = pBrdStats->GetAIQueueOverrunHistory(m_pBoard->BoardSlotInstance(), chanNo);
		*(++pMsgStart) = QueueOverRuns[chanNo].UCData[SWAP_BYTE_3];
		*(++pMsgStart) = QueueOverRuns[chanNo].UCData[SWAP_BYTE_2];
		*(++pMsgStart) = QueueOverRuns[chanNo].UCData[SWAP_BYTE_1];
		*(++pMsgStart) = QueueOverRuns[chanNo].UCData[SWAP_BYTE_0];
	}
	retValue = SaveLifeHistory(sizeof(struct AIStats) - 2);	// Encode generic life history
	return retValue;
}
//******************************************************
// SaveAOLifeHistory()
///
/// Uploads the AO IO card life history data.
///
/// @return TRUE on Msg decode success (not if error msg returned), else FALSE.
///
//******************************************************
BOOL CProtocol::SaveAOLifeHistory(void) {
	DataItem4bytes FailureCount;		// (union cannot initialise)
	class CBrdStats *pBrdStats = NULL;
	BOOL retValue = FALSE;
	UCHAR *pEncodePtr = NULL;
	USHORT chanNo = 0;
	USHORT faultNo = 0;
	pBrdStats = CBrdStats::GetHandle();
	// Encode the AO specific part of the message
	pEncodePtr = &(m_TxMessage[US_SPECIFIC_HISTORY_DATA_START_BYTE]);
	for (chanNo = 0; chanNo < HW_ANA_OUT_CHAN_PER_BOARD; chanNo++) {
		// Set the failure count for each channel
		FailureCount.ULData = pBrdStats->GetChanHistoryFaultRecord(m_pBoard->BoardSlotInstance(), chanNo);
		*(++pEncodePtr) = FailureCount.UCData[SWAP_BYTE_3];
		*(++pEncodePtr) = FailureCount.UCData[SWAP_BYTE_2];
		*(++pEncodePtr) = FailureCount.UCData[SWAP_BYTE_1];
		*(++pEncodePtr) = FailureCount.UCData[SWAP_BYTE_0];
	}
	// Examine the history fault records
	DecodeHistoryFaultRecord(pEncodePtr, faultNo);
	retValue = SaveLifeHistory(sizeof(struct AOStats) - 2);	// Encode generic life history
	return retValue;
}
//******************************************************
// SaveARLifeHistory()
///
/// Uploads the AR IO card life history data.
///
/// @return TRUE on Msg decode success (not if error msg returned), else FALSE.
///
//******************************************************
BOOL CProtocol::SaveARLifeHistory(void) {
	class CBrdStats *pBrdStats = NULL;
	BOOL retValue = FALSE;
	UCHAR chanNo = 0;
	UCHAR *pEncodePtr = NULL;
	DataItem4bytes NumARRelayOps[MAX_AR_CHANNELS];
	DataItem4bytes InputQueueOverRuns;
	DataItem4bytes PulseOutInterrupts[MAX_AR_CHANNELS];
	pBrdStats = CBrdStats::GetHandle();
	// Encode the AR specific part of the message
	pEncodePtr = &(m_TxMessage[US_SPECIFIC_HISTORY_DATA_START_BYTE]);
	for (chanNo = 0; chanNo < MAX_AR_CHANNELS; chanNo++) {
		///< Get number of relay ops for each relay
		NumARRelayOps[chanNo].ULData = pBrdStats->GetARRelayOpsRecord(m_pBoard->BoardSlotInstance(), chanNo);
		*(++pEncodePtr) = NumARRelayOps[chanNo].UCData[SWAP_BYTE_3];
		*(++pEncodePtr) = NumARRelayOps[chanNo].UCData[SWAP_BYTE_2];
		*(++pEncodePtr) = NumARRelayOps[chanNo].UCData[SWAP_BYTE_1];
		*(++pEncodePtr) = NumARRelayOps[chanNo].UCData[SWAP_BYTE_0];
	}
	// Get number of times inputs data queue lost data
	InputQueueOverRuns.ULData = pBrdStats->GetARQueueOverRuns(m_pBoard->BoardSlotInstance());
	*(++pEncodePtr) = InputQueueOverRuns.UCData[SWAP_BYTE_3];
	*(++pEncodePtr) = InputQueueOverRuns.UCData[SWAP_BYTE_2];
	*(++pEncodePtr) = InputQueueOverRuns.UCData[SWAP_BYTE_1];
	*(++pEncodePtr) = InputQueueOverRuns.UCData[SWAP_BYTE_0];
	for (chanNo = 0; chanNo < MAX_AR_CHANNELS; chanNo++) {
		///< Get number of times an output pulse was re-written before finishing
		PulseOutInterrupts[chanNo].ULData = pBrdStats->GetARPulseOutInterrupts(m_pBoard->BoardSlotInstance(), chanNo);
		*(++pEncodePtr) = PulseOutInterrupts[chanNo].UCData[SWAP_BYTE_3];
		*(++pEncodePtr) = PulseOutInterrupts[chanNo].UCData[SWAP_BYTE_2];
		*(++pEncodePtr) = PulseOutInterrupts[chanNo].UCData[SWAP_BYTE_1];
		*(++pEncodePtr) = PulseOutInterrupts[chanNo].UCData[SWAP_BYTE_0];
	}
	retValue = SaveLifeHistory(sizeof(struct ARStats) - 2);	// Encode generic life history
	return retValue;
}
//******************************************************
// SaveDIOLifeHistory()
///
/// Uploads the DIO IO card life history data.
///
/// @return TRUE on Msg decode success (not if error msg returned), else FALSE.
///
//******************************************************
BOOL CProtocol::SaveDIOLifeHistory(void) {
	class CBrdStats *pBrdStats = NULL;
	BOOL retValue = FALSE;
	UCHAR chanNo = 0;
	UCHAR *pEncodePtr = NULL;
	DataItem4bytes NumDIORelayOps[MAX_DIG_CHANNELS];
	//	DataItem4bytes		InputQueueOverRuns;
	DataItem4bytes PulseOutInterrupts;
	DataItem4bytes PulseQueueOverRuns;
	BYTE PulseOverRunChans;
	DataItem2bytes PulseOutIntChans;
	pBrdStats = CBrdStats::GetHandle();
	// Encode the DIO specific part of the message
	pEncodePtr = &(m_TxMessage[US_SPECIFIC_HISTORY_DATA_START_BYTE]);
	for (chanNo = 0; chanNo < MAX_DIG_CHANNELS; chanNo++) {
		///< Get number of relay ops for each relay
		NumDIORelayOps[chanNo].ULData = pBrdStats->GetSavedDIORelayOpsRecord(m_pBoard->BoardSlotInstance(), chanNo);
		*(++pEncodePtr) = NumDIORelayOps[chanNo].UCData[SWAP_BYTE_3];
		*(++pEncodePtr) = NumDIORelayOps[chanNo].UCData[SWAP_BYTE_2];
		*(++pEncodePtr) = NumDIORelayOps[chanNo].UCData[SWAP_BYTE_1];
		*(++pEncodePtr) = NumDIORelayOps[chanNo].UCData[SWAP_BYTE_0];
	}
	// Get number of times inputs data queue lost data
	PulseQueueOverRuns.ULData = pBrdStats->GetDIOPulseQueueOverRuns(m_pBoard->BoardSlotInstance());
	*(++pEncodePtr) = PulseQueueOverRuns.UCData[SWAP_BYTE_3];
	*(++pEncodePtr) = PulseQueueOverRuns.UCData[SWAP_BYTE_2];
	*(++pEncodePtr) = PulseQueueOverRuns.UCData[SWAP_BYTE_1];
	*(++pEncodePtr) = PulseQueueOverRuns.UCData[SWAP_BYTE_0];
	// Get the number of times an output pulse was re-written before finishing
	PulseOutInterrupts.ULData = pBrdStats->GetDIOPulseOutInterrupts(m_pBoard->BoardSlotInstance());
	*(++pEncodePtr) = PulseOutInterrupts.UCData[SWAP_BYTE_3];
	*(++pEncodePtr) = PulseOutInterrupts.UCData[SWAP_BYTE_2];
	*(++pEncodePtr) = PulseOutInterrupts.UCData[SWAP_BYTE_1];
	*(++pEncodePtr) = PulseOutInterrupts.UCData[SWAP_BYTE_0];
	// Get number of times a pulse data queue lost data
	PulseQueueOverRuns.ULData = pBrdStats->GetDIOInputQueueOverRuns(m_pBoard->BoardSlotInstance());
	*(++pEncodePtr) = PulseQueueOverRuns.UCData[SWAP_BYTE_3];
	*(++pEncodePtr) = PulseQueueOverRuns.UCData[SWAP_BYTE_2];
	*(++pEncodePtr) = PulseQueueOverRuns.UCData[SWAP_BYTE_1];
	*(++pEncodePtr) = PulseQueueOverRuns.UCData[SWAP_BYTE_0];
	// indexOf out which pulse in channels have had queue over-runs
	PulseOverRunChans = pBrdStats->GetDIOPulseOverRunChans(m_pBoard->BoardSlotInstance());
	*(++pEncodePtr) = PulseOverRunChans;
	// indexOf out which channels have had a pulse interrupted, LSB = channel 0
	PulseOutIntChans.USData = pBrdStats->GetDIOPulseOutIntChans(m_pBoard->BoardSlotInstance());
	*(++pEncodePtr) = PulseOutIntChans.UCData[SWAP_BYTE_1];
	*(++pEncodePtr) = PulseOutIntChans.UCData[SWAP_BYTE_0];
	retValue = SaveLifeHistory(sizeof(struct DIOStats) - 3);	// Encode generic life history
	return retValue;
}
//******************************************************
// SavePILifeHistory()
///
/// Uploads the PI IO card life history data.
///
/// @return TRUE on Msg decode success (not if error msg returned), else FALSE.
///
//******************************************************
BOOL CProtocol::SavePILifeHistory(void) {
	class CBrdStats *pBrdStats = NULL;
	BOOL retValue = FALSE;
	UCHAR chanNo = 0;
	UCHAR *pDecodePtr = NULL;
	DataItem4bytes PulseQueueOverRuns[MAX_PULSE_COUNTERS];
	DataItem4bytes LastFaultTime[MAX_PULSE_COUNTERS];
	pBrdStats = CBrdStats::GetHandle();
	// Encode the PI specific part of the message
	pDecodePtr = &(m_TxMessage[US_SPECIFIC_HISTORY_DATA_START_BYTE]);
	for (chanNo = 0; chanNo < MAX_PULSE_COUNTERS; chanNo++) {
		///< Get number of times data queue lost data
		PulseQueueOverRuns[chanNo].ULData = pBrdStats->GetPulseQueueOverRuns(m_pBoard->BoardSlotInstance(), chanNo);
		*(++pDecodePtr) = PulseQueueOverRuns[chanNo].UCData[SWAP_BYTE_3];
		*(++pDecodePtr) = PulseQueueOverRuns[chanNo].UCData[SWAP_BYTE_2];
		*(++pDecodePtr) = PulseQueueOverRuns[chanNo].UCData[SWAP_BYTE_1];
		*(++pDecodePtr) = PulseQueueOverRuns[chanNo].UCData[SWAP_BYTE_0];
	}
	for (chanNo = 0; chanNo < MAX_PULSE_COUNTERS; chanNo++) {
		///< Get Life Stats operating time at time of last fault
		LastFaultTime[chanNo].ULData = pBrdStats->GetPulseLastFaultTime(m_pBoard->BoardSlotInstance(), chanNo);
		*(++pDecodePtr) = LastFaultTime[chanNo].UCData[SWAP_BYTE_3];
		*(++pDecodePtr) = LastFaultTime[chanNo].UCData[SWAP_BYTE_2];
		*(++pDecodePtr) = LastFaultTime[chanNo].UCData[SWAP_BYTE_1];
		*(++pDecodePtr) = LastFaultTime[chanNo].UCData[SWAP_BYTE_0];
	}
	retValue = SaveLifeHistory(sizeof(struct PIStats) - 2);	// Encode generic life history
	return retValue;
}

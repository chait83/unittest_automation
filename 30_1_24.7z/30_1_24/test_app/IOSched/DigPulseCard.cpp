/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n DigPulseCard.cpp
/// @n implement the Digital/Pulse Card state machine.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 106 Stability Project 1.101.1.3	7/2/2011 4:56:47 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 105 Stability Project 1.101.1.2	7/1/2011 4:38:15 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 104 Stability Project 1.101.1.1	3/17/2011 3:20:22 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 103 Stability Project 1.101.1.0	2/15/2011 3:02:59 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////
#include "Timer.h"
#include "TV6Timer.h"
#include "IOCardInfo.h"
#include "BrdInfo.h"
#include "BaseProtocol.h"
#include "Config.h"
#include "DigConfig.h"
#include "CardSlot.h"
#include "IOCard.h"
#include "DigPulseCard.h"
#include "ConfigManager.h"
#include "AIConfig.h"
#include "IOHandler.h"
#include "IOChanHandler.h"
#include "IOCardHandler.h"
#include "PPIOService.h"
#include "PPDICard.h"
#include "V6globals.h"
#include "ATECal.h"
#include "PPL.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CDigPulseCard::CDigPulseCard(USHORT CardSlotID) : CIOCard(CardSlotID) {
//	qDebug("Create new CDigPulseCard\n");
	m_pConfigMngrObj = CIOConfigManager::GetHandle(); // Get reference to configuration manager
	m_Instance = CardSlotID;
	m_ExtraInput = FALSE;
	m_lastValueWritten = 0;
	m_SetupHasBeenChanged = FALSE;
	m_OutputUpdateRqd = TRUE;
	m_timeToRead = 0L;						///< Time to read next block data
	m_pDIHandler = NULL;
	m_pProtocol = NULL;						// No allocated protocol
	m_pDigConfigObj = NULL;
//	ResetStateMachine();						// Reset state machine
}
CDigPulseCard::~CDigPulseCard() {
//	qDebug("Deleting CDigPulseCard\n");
	delete m_pDIHandler;
	m_pDIHandler = NULL;
}
//******************************************************
// InitialiseCard()
///
/// Schedule correct desired update rate for card & channel	based on configuration.
/// @param[in] cardNo - Card slot number identification.
///
/// @return TRUE
/// 
//******************************************************
BOOL CDigPulseCard::InitialiseCard(const USHORT cardNo) {
//	QString   IOCardDescription;
	m_pDIHandler = new class CIOCardHandler();
//	GetIOCardStrDescription( &IOCardDescription );
//	LogInternalError(IOCardDescription.toLocal8Bit().data());
	return TRUE;
}
//******************************************************
// GetProcessHandle()
///
/// Get the card handler so that card specific (DI channel) information can be processed.
///
/// @return Card process handler
/// 
//******************************************************
class CIOCardHandler* CDigPulseCard::GetProcessHandle(void) {
	return static_cast<class CIOCardHandler*>(m_pDIHandler);
}
//******************************************************
// SetupConfigChangePreparation()
///
/// Sets all digital/pulse services on a setup commit change preperation
///
/// @return TRUE on success; otherwise FALSE
/// 
//******************************************************
BOOL CDigPulseCard::SetupConfigChangePreparation(void) {
	BOOL retValue = TRUE;
	class CSlotMap *pSlotMapObj = NULL;			///< Slot map holder
	pSlotMapObj = CSlotMap::GetHandle();
	// Prepare the digital inputs for the configuration change
	if ((NULL != m_pDigConfigObj) && (pSlotMapObj->IsCardInTopSlot(BoardSlotInstance()) == FALSE))
		retValue = m_pDigConfigObj->SetupConfigChangePreparation();
	if (m_pDIHandler != NULL) {
		if (static_cast<class CIOCardHandler*>(m_pDIHandler)->SetupConfigChangePreparation() == FALSE)
			retValue = FALSE;
	}
	m_SetupHasBeenChanged = TRUE;
	return retValue;
}
//**********************************************************************
/// Obtains the I/O board designator
///
/// @param[out] IDText - Slot designator ID text.
///
//**********************************************************************
void CDigPulseCard::GetIOCardStrID(QString *pIDText) const {
#ifndef V6IOTEST
	if (GetBoardType() == BOARD_AR)
		*pIDText = QWidget::tr("Alarm");
	else if (GetBoardType() == BOARD_DIO)
		*pIDText = QWidget::tr("Digital I/O");
	else if (GetBoardType() == BOARD_PI)
		*pIDText = QWidget::tr("Pulse");
#endif
}
//**********************************************************************
/// Obtains the I/O board designator
///
/// @param[out] pIDText - Card description.
///
//**********************************************************************
void CDigPulseCard::GetIOCardStrDescription(QString *pIDText) {
#ifndef V6IOTEST
	QString cardText;
	class CSlotMap *pSlotMap = NULL;
	class CBrdInfo *pBrdInfo = NULL;
	WCHAR boardSlotStr[4];
	pSlotMap = CSlotMap::GetHandle();
	pBrdInfo = CBrdInfo::GetHandle();
	if (pSlotMap != NULL)
		pSlotMap->GetSlotStrID(BoardSlotInstance(), QString::fromWCharArray(boardSlotStr));
	GetIOCardStrID(&cardText);
	/// TODO: Resolve this
	pIDText->asprintf(IDS_BOARD_IN_SLOT, cardText.toWCharArray, pBrdInfo->GetNoOfChannels(BoardSlotInstance()),
			boardSlotStr);
#endif
}
//**********************************************************************
/// Post the digital activation notfication message, dependant upon CMM requirements
///
/// @param[in]	messNumber - message identifier in string table
/// @param[in]	Activate - TRUE if digital is activated; otherwise FALSE
///
/// @return		nothing
/// 
//**********************************************************************
void CDigPulseCard::LogDigitalState( USHORT sysDigitalNo, BOOL Activate) {
	m_pDigConfigObj->LogDigitalState(sysDigitalNo, Activate);
}
//******************************************************
// InitialiseCardConfig()
///
/// Create the local configuration for the I/O card from the CMM.
///
/// @return TRUE if local configuration could be created; otherwise FALSE 
/// 
//******************************************************
BOOL CDigPulseCard::InitialiseCardConfig(void) {
	BOOL retValue = FALSE;
	if ((m_pTransMngr != NULL) && (m_pConfigMngrObj != NULL)) {
		// Load the local configuration from the CMM
		m_pDigConfigObj = m_pConfigMngrObj->CreateDigLocalConfig(m_Instance);
		if (m_pDigConfigObj != NULL)
			retValue = m_pDigConfigObj->InitialiseCardConfigHolder(this);
		// Initialise local configuration
		if (retValue != FALSE) {
			m_NormOpPending.CommandModeToProc = IO_CONFIGCHECK;
			RunProcess();
			// Create instances of the channel holders
			retValue = InitialiseChannels();
		}
	}
	// No devices on board have failed yet; with this configuration
	m_DeviceFailed = FALSE;
	return retValue;
}
//******************************************************
///
/// Services the output channels on the recorder.
///
/// Note: Process is different for test equipment
/// @param[out] pCardData - System channel analogue word data.
///
/// @return TRUE on a O/P change being detected; otherwise FALSE
/// 
//******************************************************
BOOL CDigPulseCard::ProcessOutputChannels( USHORT *pCardData) {
	BOOL outputUpdated = FALSE;
	outputUpdated = m_ChanList.ProcessOutputChannels(pCardData);
	if (outputUpdated == TRUE) {
		m_lastValueWritten = *pCardData;
		m_OutputUpdateRqd = outputUpdated;
	}
	return outputUpdated;
}
//******************************************************
// ResetDigitalDITValues()
///
/// Reset digital reader holders to default state
/// @param[in] pChanInfo - The channel process info.
/// 
//******************************************************
void CDigPulseCard::ResetDigitalDITValues(void) {
	USHORT BoardNo = BoardSlotInstance();
	class CBrdStats *pBrdStatsObj = NULL;		///< Board stats holder
	class CBrdInfo *pBrdInfoObj = NULL;		///< Board info holder
	UCHAR chanCount = 0;
	USHORT inputSelect = 0;
	CChanList *pBoardChanLst = NULL;	// Board channels for processing
	class CIOChanHandler *pChan = NULL;		// General Channel reference
	USHORT chanNo = 0;					// Channel number being processed
	pBrdStatsObj = CBrdStats::GetHandle();
	pBrdInfoObj = CBrdInfo::GetHandle();
	if (pBrdInfoObj != NULL)
		chanCount = pBrdInfoObj->GetNoOfChannels(BoardNo);
	pBoardChanLst = GetChanSchedule();
	// Reset all persisted inputs
	if (NULL != m_pDigConfigObj) {
		inputSelect = (m_pDigConfigObj->GetBoardCfgInputSelectionMask()
				| m_pDigConfigObj->GetBoardCfgPulseInSelectionMask());
		pBoardChanLst->ResetPersistedDigitalPersistChannels(inputSelect);
		// Update DIT values based on the current configuration
		for (chanNo = 0; chanNo < chanCount; chanNo++) {
			if (pBoardChanLst != NULL)
				pChan = pBoardChanLst->GetChannelRef(chanNo);
			if (pChan != NULL) {
				if (m_pDigConfigObj->IsChanEnabledPulseIn(static_cast<UCHAR>(chanNo)) == FALSE) {
					// If a channel is disabled or is not currently configured as a pulse input,
					// but can be a pulse input then reset accumulated pulse count
					pChan->ResetPulseDITValues();
				}
				/*
				 else
				 {
				 // If channel is a pulse then the digital I/O count needs to be reset
				 pChan->ResetDigitalDITValues();
				 }
				 */
				/*
				 if( m_pDigConfigObj->IsChanEnabledDigOut(static_cast<UCHAR> (chanNo)) == TRUE )
				 {
				 // If a channel is disabled or is not currently configured as a digital input,
				 // but can be a digital input then reset DIT value
				 pChan->ResetDigitalDITValues();
				 }
				 */
			}
		}
	}
}
//******************************************************
// ResetPulseDITValues()
///
/// Reset accumulated pulse reading holders to default state (pulse board)
///
/// @param[in] pChanInfo - The channel process info.
/// 
//******************************************************
void CDigPulseCard::ResetPulseDITValues(void) {
	USHORT BoardNo = BoardSlotInstance();
	class CBrdStats *pBrdStatsObj = NULL;		///< Board stats holder
	class CBrdInfo *pBrdInfoObj = NULL;		///< Board info holder
	UCHAR chanCount = 0;
	CChanList *pBoardChanLst = NULL;	// Board channels for processing
	class CIOChanHandler *pChan = NULL;		// General Channel reference
	USHORT chanNo = 0;					// Channel number being processed
	pBrdStatsObj = CBrdStats::GetHandle();
	pBrdInfoObj = CBrdInfo::GetHandle();
	if (pBrdInfoObj != NULL)
		chanCount = pBrdInfoObj->GetNoOfChannels(BoardNo);
	// Update queues from last updated system tick
	for (chanNo = 0; chanNo < chanCount; chanNo++) {
		pBoardChanLst = GetChanSchedule();
		if (pBoardChanLst != NULL)
			pChan = pBoardChanLst->GetChannelRef(chanNo);
		if (pChan != NULL) {
			if (m_pDigConfigObj->IsChanEnabledPulseIn(static_cast<UCHAR>(chanNo)) == FALSE) {
				// If a channel is disabled or is not currently configured as a pulse input,
				// but can be a pulse input then reset accumulated pulse count
				pChan->ResetPulseDITValues();
			}
		}
	}
}
//******************************************************
// ResetDigPulseCardDataItems()
///
/// Reset the digital I/O and Alarm card specific DT values
///
/// @param[in] pChanInfo - The channel process info.
/// 
//******************************************************
BOOL CDigPulseCard::ResetDigPulseCardDataItems() {
	CChanList *pBoardChanLst = NULL;	// Board channels for processing
	BOOL retValue = TRUE;
	// Reset the digital pulse channel DIT values
	ResetPulseDITValues();
	// Reset the setup input to output changed digital DIT values
	ResetDigitalDITValues();
	// Reset the output state persisted values when the setup has changed
	if ( TRUE == m_SetupHasBeenChanged) {
		pBoardChanLst = GetChanSchedule();
		pBoardChanLst->ResetPersistedDigitalDITValues();
	}
	return retValue;
}
//**********************************************************************
///
/// Get reference to channel local configuration as channel service data
///
/// @param[in] ChanNo - Card slot channel number.
/// @param[out] pChanCfgInfo - Channel configuration info
/// @param[out] pChanWrkInfo - Channel working info
///
/// @return		TRUE if the cahannel has configuration data available; otherwise FALSE
//**********************************************************************
BOOL CDigPulseCard::GetChannelConfigRef(const UCHAR ChanNo, T_DIGCFGCHANNEL **ppChanCfgInfo) {
	return m_pDigConfigObj->GetChannelConfigRef(ChanNo, ppChanCfgInfo);
}
//******************************************************
///
/// Query the board Report Selection Mask
/// @param[out] chartReportMask - TRUE if channel activation is to be reported to the chart & 'digital' message list.
/// @param[out] msgReportMask - TRUE if channel activation is only to be reported to the 'digital' message list.
///
/// 
//******************************************************
void CDigPulseCard::QueryReportSelectionMask( USHORT &chartReportMask,
USHORT &msgReportMask) const {
	m_pDigConfigObj->QueryReportSelectionMask(chartReportMask, msgReportMask);
}
//******************************************************
///
/// Query the board configuration Digital Input Selection Mask
///
/// @return The Digital Input Selection Mask
/// 
//******************************************************
USHORT CDigPulseCard::GetBoardCfgDigitalInputSelectionMask(void) const {
	return m_pDigConfigObj->GetBoardCfgDigitalInputSelectionMask();
}
//******************************************************
///
/// Queries the highest digital input channel that is enabled.
/// @param[out] ChanNo - The number of the highest digital input channel enabled
///
/// @return TRUE if at least 1 digital input channel is selected; otherwise FALSE
/// 
//******************************************************
BOOL CDigPulseCard::HighestDIChannelEnabled( USHORT &ChanNo) const {
	USHORT chanNo;
	BOOL DIFound = FALSE;
	if (m_pDigConfigObj != NULL) {
		// Search through all the channels looking for an enabled digital input
		for (chanNo = 0; chanNo < BOTTOMSLOT_DIGCHAN_SIZE; chanNo++) {
			if (m_pDigConfigObj->IsChanEnabledDigIn(static_cast<UCHAR>(chanNo)) == TRUE) {
				ChanNo = chanNo;
				DIFound = TRUE;
			}
		}
	}
	return DIFound;
}
//******************************************************
///
/// Queries the highest digital pulse input channel that is enabled.
/// @param[out] ChanNo - The number of the highest digital pulse input channel enabled
///
/// @return TRUE if at least 1 digital pulse input channel is selected; otherwise FALSE
/// 
//******************************************************
BOOL CDigPulseCard::HighestPIChannelEnabled( USHORT &ChanNo) const {
	USHORT chanNo;
	BOOL PIFound = FALSE;
	if (m_pDigConfigObj != NULL) {
		// Search through all the channels looking for an enabled digital input
		for (chanNo = 0; chanNo < BOTTOMSLOT_DIGCHAN_SIZE; chanNo++) {
			if (m_pDigConfigObj->IsChanEnabledPulseIn(static_cast<UCHAR>(chanNo)) == TRUE) {
				ChanNo = chanNo;
				PIFound = TRUE;
			}
		}
	}
	return PIFound;
}
//******************************************************
// IOCardCommand()
///
/// Sends a user command to the I/O boards.
/// @param[in] newCmd - I/O board command.
///
/// @return IOCARDSTAT (IOSTAT_CMDOK) if successful otherwise IOCARDSTAT fail code 
/// 
//******************************************************
IOCARDSTAT CDigPulseCard::IOCardCommand(const USHORT newCmd) {
//	class CProtocol *pProtocolHnd;
	IOCARDSTAT retValue = IOSTAT_CMDOK;
	// Remove unprocessed commands from queue
//	if( newCmd != IO_HISTORYUPLOAD )
//		ResetStateMachine();
	// Load new command into the state machine sequencer
	switch (newCmd) {
	case IO_RESET:
		// Reset instructed
		break;
	case IO_CONFIGCHECK:
		// Configuration check instructed
		break;
	case IO_CONFIGDOWNLOAD:
		// Configuration download to board instructed
		break;
	case IO_CALIBRATION:
		// Unit calibration mode instructed
		break;
	case IO_CONFIGUPLOAD:
		// configuration upload to recorder instructed
		break;
	case IO_HISTORYUPLOAD:
		// History upload to recorder instructed
		break;
	case IO_ACQUIRE:
		// Normal acquisition mode commanded
		break;
	case IO_IDLE:
		// Module commanded to enter IDLE mode
		break;
	};
	// Execute new command; and update state machine
//	pProtocolHnd = m_pTransMngr->RequestTransToken( this );
//	if( pProtocolHnd != NULL )
//		OperateTransactionSM( pProtocolHnd );
	return retValue;
}
//**********************************************************************
/// CalculateChannelReadRate()
///
/// Calculates the channel read rate.
///
/// @param[in] ChanNo - Card slot channel number.
///
/// @return		The number of mS between reads on this channel
//**********************************************************************
USHORT CDigPulseCard::CalculateChannelReadRate(UCHAR chanNo) {
	return 0;
}
//**********************************************************************
/// GetChannelAcqRate()
///
/// Gets the channel acqusition rate.
///
/// @param[in] ChanNo - Card slot channel number.
///
/// @return		The number of mS between acqusitions on this channel
//**********************************************************************
USHORT CDigPulseCard::GetChannelAcqRate(const UCHAR chanNo) const {
	return m_pDigConfigObj->GetChannelAcqRate(chanNo);
}
//******************************************************
// ChannelsToService()
///
/// Query which channels to service.
///
/// @return The current channel(s) to service
/// 
//******************************************************
USHORT CDigPulseCard::ChannelsToService(void) {
	USHORT chanMask = 0;
	class CBrdInfo *pBrdInfoObj = NULL;
	pBrdInfoObj = CBrdInfo::GetHandle();
	if (pBrdInfoObj != NULL)
		SetBits(&chanMask, MAX_OF_ALL_16_CHANNELS, 0, pBrdInfoObj->GetNoOfChannels(m_Instance));
	return chanMask;
}
//******************************************************
// SetSpecialTestMode()
///
/// Sets the special test mode were boards hidden functionality are made visible.
/// @param[in] state - Whether special test mode is enabled or disabled.
///
/// @return TRUE if the I/O board has a special test mode; otherwise FALSE.
/// 
//******************************************************
BOOL CDigPulseCard::SetSpecialTestMode(const BOOL state) {
	BOOL retValue = FALSE;
	// If the card is a four channel AR card, then special test mode is possible
	if ((m_pBrdInfoObj->WhatBoardType(m_Instance) == BOARD_AR)
			&& (m_pBrdInfoObj->GetNoOfChannels(m_Instance) == FOUR_IO_BOARD_CHANNELS)) {
		m_ExtraInput = state;
		retValue = TRUE;
	}
	return retValue;
}
//******************************************************
// CMMCreateLocalConfig()
///
/// Virtual function implementation
/// Load the global configuration from the CMM and create the locally held one.
///
/// @return TRUE if successfully created local configuration; otherwise FALSE
/// 
//******************************************************
BOOL CDigPulseCard::CMMCreateLocalConfig(void) {
	return m_pDigConfigObj->CMMCreateLocalConfig();
}
//******************************************************
// ScheduleBoardProcess()
///
/// Schedules whether the I/O board requires digital acqusition.
///
/// @return TRUE if successfully scheduled; otherwise FALSE
/// 
//******************************************************
BOOL CDigPulseCard::ScheduleBoardProcess(void) {
	return TRUE;
}
//******************************************************
// ScheduleBoardProcess()
///
/// Schedules whether the I/O board requires digital acqusition.
///
/// @return TRUE if successfully scheduled; otherwise FALSE
/// 
//******************************************************
BOOL CDigPulseCard::SchedulePulseDownload(void) {
	// Set the next channel read as pending
	m_NormOpPending.Board.ChanRead2 = TRUE;
	return TRUE;
}
//******************************************************
// ResyncService()
///
/// Synchronises a card's digital input pre-process queue
/// @param[in] IOCardTick - I/O card tick to sync to.
/// @param[in] systemTick - The global system time to sync to.
///
/// @return TRUE on successful resync; otherwise FALSE
/// 
//******************************************************
BOOL CDigPulseCard::ResyncService(const USHORT IOCardTick, const LONGLONG systemTick) {
	class CIOCardHandler *pService = NULL;
	BOOL retValue = FALSE;
	pService = GetProcessHandle();
	if (pService != NULL)
		retValue = pService->ResyncService(IOCardTick, systemTick);
	return retValue;
}
//******************************************************
// DoesBoardRqSched()
///
/// Queries whether the I/O board requires periodic scheduling.
///
/// @return TRUE if the I/O card requires periodic scheduling; otherwise FALSE 
/// 
//******************************************************
BOOL CDigPulseCard::DoesBoardRqSched(void) {
	return TRUE;
}
//******************************************************
// ScheduleNextChannelProcess()
///
/// Schedules the next ideal channel read times for channels just processed.
///
/// @return TRUE
/// 
//******************************************************
BOOL CDigPulseCard::ScheduleNextChannelProcess(void) {
	return TRUE;
}
//******************************************************
// CardBoardHandlerFactory()
///
/// Queries each board type to check whether a board handler is required.
///
/// @return TRUE if no errors are encountered during any board creation and initialisation;
///		otherwise FALSE.
/// 
//******************************************************
BOOL CDigPulseCard::CardBoardHandlerFactory(void) {
	UCHAR chanNo;
	BOOL boardHandlerRqd = FALSE;
	class CIOCardHandler *pCardService = NULL;
	class CPPIOServiceManager *pServMngr = NULL;
	class CPPDICard *pDIService = NULL;
	T_COMMONPROCESSINFO BoardInfo;
	BOOL retValue = TRUE;
	for (chanNo = 0; chanNo < m_pBrdInfoObj->GetNoOfChannels(BoardSlotInstance()); chanNo++) {
		// indexOf out normal card capabilities
		if ((m_pBrdInfoObj->WhatAvailableChannelType(BoardSlotInstance(), chanNo) & CHANNEL_CAP_DI) != 0)
			boardHandlerRqd = TRUE;
	}
	// indexOf out if there are extra capabilities because of operating mode
	if ((WhatBoardType() == BOARD_AR)
			&& ((IsRunningAsATEEquipment() == TRUE) || (pSYSTEM_INFO->IsInHotSoakTestMode() == TRUE))) {
		boardHandlerRqd = TRUE;
	}
	if (boardHandlerRqd == TRUE) {
		retValue = FALSE;
		pServMngr = CPPIOServiceManager::GetHandle();
		if (pServMngr != NULL) {
			pDIService = pServMngr->GetDIService();
			/// A board handler service is required
			if (pDIService != NULL) {
				retValue = pDIService->InitialiseBoardService(&BoardInfo, this);
				pCardService = GetProcessHandle();
			}
			if ((pDIService != NULL) && (pCardService != NULL)) {
				retValue = pCardService->InitialiseIOHandler();
//				pBoardInfo = pCardService->GetBoardProcessInfo();
				if (retValue == TRUE) {
					retValue = pCardService->InitialiseCardService(&BoardInfo);
				}
			}
		}
	}
	return retValue;
}
//******************************************************
// UpdateLastDIReadService()
///
/// Reads the I/O card digital input and updates the PPQ reading.
/// @param[in] thisSystemTick - System time of this operation.
///
/// @return TRUE if all OK; otherwise FALSE
/// 
//******************************************************
BOOL CDigPulseCard::UpdateLastDIReadService(LONGLONG thisSystemTick) {
	BOOL retValue = TRUE;
	if (IOCardIPQueryAllowed() == TRUE) {
		// Perform a digital block read & write, only if I/P query is allowed
		SetAcquireModeActiveState( TRUE);
		RunProcess();
		// Update when the reading was last taken from the DI input.
		SetLastPPQSystemCoverage(thisSystemTick);
		SetLastDISystemCoverage(thisSystemTick);
	}
	return retValue;
}
//******************************************************
// UpdateLastDICoverageService()
///
/// Checks whether a scheduled service is changing state, if not it updates
/// the coverage to reflect that the digital reading has remained unaltered.
/// @param[in] thisSystemTick - System time of this operation.
/// @param[in] lastSystemTick - Last system tick that cards were scheduled on
/// @param[in] digitalLastSyncedSystemTick - System tick that digital I/O cards were last synced at
///
/// @return TRUE if all OK; otherwise FALSE
/// 
//******************************************************
BOOL CDigPulseCard::UpdateLastDICoverageService(LONGLONG thisSystemTick, LONGLONG lastSystemTick,
		LONGLONG digitalLastSyncedSystemTick) {
	BOOL retValue = TRUE;
	if (IsRunningAsATEEquipment() == FALSE) {
		if ((thisSystemTick > GetNextPPQSystemCoverageRqd(NEXT_SYSTEM_COVERAGE_UPDATE))
				&& (thisSystemTick > GetNextDISystemCoverageRqd(
				NEXT_SYSTEM_COVERAGE_HOLDOFF))
				&& (thisSystemTick > (digitalLastSyncedSystemTick + NEXT_SYSTEM_COVERAGE_HOLDOFF))) {
			// Only update coverage if holdoff time has been exceeded
			if (IOCardIPQueryAllowed() == TRUE) {
				// Don't add coverage up to current time, as an input event may be in the past
				SetLastReadingCoverage(lastSystemTick - NEXT_SYSTEM_COVERAGE_HOLDOFF);
			}
			// Register with coverage update timer that coverage is current
			SetLastPPQSystemCoverage(thisSystemTick);
		}
	}
	return retValue;
}
/////////////////////////////////////////////////////
/// Process all readings and status for one or more channels returned
/// from the block read command
///
/// @param[in] time - Length of time needed to be processed.
///
/// @return TRUE on success	else FALSE.
/////////////////////////////////////////////////////
BOOL CDigPulseCard::ProcessMissingPulseBlockTransfer(LONGLONG procTime) {
	USHORT BoardNo = BoardSlotInstance();
	class CBrdStats *pBrdStatsObj = NULL;		///< Board stats holder
	class CBrdInfo *pBrdInfoObj = NULL;		///< Board info holder
	UCHAR chanCount = 0;
	CChanList *pBoardChanLst = NULL;	// Board channels for processing
	class CIOChanHandler *pChan = NULL;		// General Channel reference
	BOOL illegalChannelUsed = FALSE;		// Has illegal channel been identified in message
	USHORT chanNo = 0;					// Channel number being processed
	BOOL readingsProcessed = FALSE;	// missing readings actually added
	QString errStr;
	pBrdStatsObj = CBrdStats::GetHandle();
	pBrdInfoObj = CBrdInfo::GetHandle();
	if (pBrdInfoObj != NULL)
		chanCount = pBrdInfoObj->GetNoOfChannels(BoardNo);
	ClearAckChannelRecieved();				// No channels to acknowledge yet
	// Update queues from last updated system tick
	for (chanNo = 0; chanNo < chanCount; chanNo++) {
		pBoardChanLst = GetChanSchedule();
		if (pBoardChanLst != NULL)
			pChan = pBoardChanLst->GetChannelRef(chanNo);
		if (pChan != NULL) {
			pChan->PulseProcessMissingChannelReadings(m_LastPPQSystemUpdateTick, procTime);
			readingsProcessed = TRUE;
		} else {
			illegalChannelUsed = TRUE;
		}
	}
	return readingsProcessed;
}
//******************************************************
//
/// Change the current operating mode of the Digital/Pulse transaction state machine.
/// @param[in] pProtocol - Pointer to the I/O board protocol handle.
///
/// @return TRUE if successful; otherwise FALSE
/// 
//******************************************************
BOOL CDigPulseCard::PerformSMModeChange(class CProtocol *const pProtocol) {
	USHORT highestNoActiveChannel;
	BOOL opState = TRUE;
	BOOL nextOpTest = FALSE;
	m_pProtocol = pProtocol;
	CIOCard::PerformSMModeChange();
	// Schedule history upload if required
	nextOpTest = m_BoardCmd.HistoryUpload;
	m_BoardCmd.HistoryUpload = FALSE;
	if (nextOpTest == TRUE) {
		SaveIOLifeHistory(m_pProtocol);
	}
	// Schedule Configuration upload if required
	nextOpTest = m_BoardCmd.ConfigDownload;
	m_BoardCmd.ConfigDownload = FALSE;
	if (nextOpTest == TRUE) {
		m_OutputUpdateRqd = TRUE;
		sleep(INTER_COMMAND_DELAY);
		opState = m_pProtocol->DownloadDigitalPulseConfig();			// Download digital/pulse config to I/O board
		m_CmdProcessed++;
		// Update the time the system was reset
		m_LastPPQSystemUpdateTick = pGlbSysTimer->GetCurrentSystemTimeTick100();
		m_LastSuccesfulReadSystemTick = m_LastPPQSystemUpdateTick;
		if (opState == TRUE) {
			// Resync the queues
//			m_SyncOpPending = TRUE;
			CIOCard::ScheduleQueueSync();
			// Create instances of the channel holders
//			opState = InitialiseChannels();
			if (opState == TRUE) {
				// and the board data needs resetting
				m_NormOpPending.Board.DataReset = TRUE;
				opState = CIOCard::OperateTransactionSM();
			}
			if ((IsRunningAsATEEquipment() == TRUE)
					|| ((TRUE == m_CardQueryEnabled) && (TRUE == m_initialDataReadForce)
							&& (HighestDIChannelEnabled(highestNoActiveChannel) == TRUE))) {
				// Board has been reset and queues synced so enable reading of digital data from board
				m_NormOpPending.Board.ChanRead = TRUE;
			}
			if ((IsRunningAsATEEquipment() == TRUE)
					|| ((TRUE == m_CardQueryEnabled) && (HighestPIChannelEnabled(highestNoActiveChannel) == TRUE))) {
				// Board has been reset and queues synced so enable reading of pulse data from board
				m_NormOpPending.Board.ChanRead2 = TRUE;
			}
		}
//		// Now reset the data on the board - all previous data is invalid
//		m_pProtocol->ResetBoardData();
	}
	nextOpTest = m_BoardCmd.ConfigUpload;
	m_BoardCmd.ConfigUpload = FALSE;
	if (nextOpTest == TRUE) {
		sleep(INTER_COMMAND_DELAY);
		opState = m_pProtocol->UploadDigitalPulseConfig();				// Upload digital/pulse config from I/O board
		m_CmdProcessed++;
	}
	return TRUE;
}
//**********************************************************************
/// Gets the I/O board life history
///
/// @return - TRUE if the upload of I/O life history was succesful; otherwise FALSE.
///
//**********************************************************************
BOOL CDigPulseCard::GetIOLifeHistory(class CProtocol *const pProtocol) {
	BOOL retValue = FALSE;
	if (GetBoardType() == BOARD_AR)
		retValue = pProtocol->GetARLifeHistory();
	else if (GetBoardType() == BOARD_DIO)
		retValue = pProtocol->GetDIOLifeHistory();
	else if (GetBoardType() == BOARD_PI)
		retValue = pProtocol->GetPILifeHistory();
	return retValue;
}
//**********************************************************************
/// Saves the I/O board life history
///
/// @return - TRUE if the upload of I/O life history was succesful; otherwise FALSE.
///
//**********************************************************************
BOOL CDigPulseCard::SaveIOLifeHistory(class CProtocol *const pProtocol) {
	BOOL retValue = FALSE;
	if (GetBoardType() == BOARD_AR)
		retValue = pProtocol->SaveARLifeHistory();
	else if (GetBoardType() == BOARD_DIO)
		retValue = pProtocol->SaveDIOLifeHistory();
	else if (GetBoardType() == BOARD_PI)
		retValue = pProtocol->SavePILifeHistory();
	return retValue;
}
#define JUST_OVER_ONE_SECOND	101
#define DEBOUNCE_TIME			11
//******************************************************
// OperateTransactionSM()
///
/// Main digital/pulse transaction state machine.
/// @param[in] pProtocol - Pointer to the I/O board protocol handle.
///
/// @return TRUE if successful; otherwise FALSE
/// 
//******************************************************
BOOL CDigPulseCard::OperateTransactionSM(class CProtocol *pProtocol) {
//	QDateTime sysTime;
//	WCHAR wcSystemTime[100];
//	static USHORT StateMCCycles = 0;
	class CATECal *pCalStruct = NULL;
	class CDigConfig *pDigConfig = NULL;
	class CIOConfigManager *pConfigManager = NULL;
	CTV6Timer transTimer(TIMER_HIGH_RES);	// Total time in this 'timeslice'
	CTV6Timer readTimer(TIMER_HIGH_RES);		// Total time of block read
CTV6T6T

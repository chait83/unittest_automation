/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n ChanList.cpp
/// @n implementation for the abstract CChanList class.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 80	Stability Project 1.75.1.3	7/2/2011 4:56:03 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 79	Stability Project 1.75.1.2	7/1/2011 4:38:04 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 78	Stability Project 1.75.1.1	3/17/2011 3:20:15 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 77	Stability Project 1.75.1.0	2/15/2011 3:02:31 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////
#include "V6IOBoardTypes.H"
#include "BoardManager.h"
#include "IOCardInfo.h"
#include "IOCardStats.h"
#include "BrdStats.h"
#include "BrdInfo.h"
#include "Timer.h"
#include "SlotMap.h"
#include "PPIOServiceManager.h"
#include "ChanList.h"
#include "AIConfig.h"
#include "IOHandler.h"
#include "IOChanHandler.h"
#include "IOCardHandler.h"
#include "DevCaps.h"
#include "V6globals.h"
#include "LinearTable.h"
#include "Device.h"
#include "DeviceManager.h"
#include "FFConversionInfo.h"
#include "InputConditioning.h"
#include "CardSlot.h"
#include "IOCard.h"
#include "AICard.h"
#include "DigPulseCard.h"
#include "PPIOService.h"
#include "PPDICard.h"
#include "PPAIChannel.h"
#include "PPAOChannel.h"
#include "PPDOChannel.h"
#include "PPPulseChannel.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CChanList::CChanList(const UCHAR slotNo) {
	USHORT chanNo;
//	qDebug("Creating new CChanList class\n");
	m_ChannelCount = 0;
	m_ChannelListCount = 0;
	m_BoardInstance = slotNo;
	// Get a handle on board info and stats
	m_pBrdInfoObj = CBrdInfo::GetHandle();
	m_pBrdStatsObj = CBrdStats::GetHandle();
	m_pServiceManagerObj = CPPIOServiceManager::GetHandle();
	m_pSlotMapObj = CSlotMap::GetHandle();
	m_OPUpdateRequired = FALSE;
	m_ForceCardUpdate = TRUE;
	if (m_pServiceManagerObj == NULL) {
		// @todo: Unable to get handle/create the service manager
	}
	if (m_pSlotMapObj == NULL) {
		// @todo: Unable to get handle/create board stats
	}
	if (m_pBrdStatsObj == NULL) {
		// @todo: Unable to get handle/create board stats
	}
	if (m_pBrdInfoObj == NULL) {
		// @todo: Unable to get handle/create board info
	}
	// Initialise all channel holders with no channels
	for (chanNo = 0; chanNo < MAXIOCHANS; chanNo++)
		m_pIOHndlr[chanNo] = NULL;
}
CChanList::~CChanList() {
	USHORT chanNo;
//	qDebug("Deleting CChanList class\n");
// Remove all the channels for the card
	for (chanNo = 0; chanNo < MAXIOCHANS; chanNo++) {
		if (m_pIOHndlr[chanNo] != NULL) {
			delete m_pIOHndlr[chanNo];
			m_pIOHndlr[chanNo] = NULL;
		}
	}
	// Remove the service manager
	m_pServiceManagerObj->CleanUp();
}
//******************************************************
// Initialise()
///
/// Creates a list of channels for a CardSlot.
///
/// @return TRUE if channel list has been succesfully created; otherwise FALSE
/// 
//******************************************************
BOOL CChanList::Initialise(void) {
	return TRUE;
}
//******************************************************
// AddChanToSchedule()
///
/// Adds an IO channel to an IO card.
/// @param[in] chanNo - Channel number identification.
/// @param[in] pChan - The concrete channel type to add.
///
/// @return TRUE is channel is added; otherwise FALSE.
/// 
//******************************************************
BOOL CChanList::AddChanToSchedule(const USHORT chanNo, class CIOHandler *const pChan) {
	BOOL retValue = FALSE;
	if (m_pIOHndlr[chanNo] == NULL) {
		m_ChannelListCount++;
		m_pIOHndlr[chanNo] = pChan;
		retValue = TRUE;
	}
	return retValue;
}
//******************************************************
// GetChannelRef()
///
/// Recovers an IO channel reference.
/// @param[in] chanNo - Channel number identification.
///
/// @return The channel reference (if scheduled); otherwise NULL.
/// 
//******************************************************
class CIOChanHandler* CChanList::GetChannelRef(const USHORT chanNo) {
	return static_cast<class CIOChanHandler*>(m_pIOHndlr[chanNo]);
}
//******************************************************
// GetListCount()
///
/// Gets the number of channels scheduled in a channel list.
///
/// @return Channel count.
/// 
//******************************************************
UCHAR CChanList::GetListCount() {
	return m_ChannelListCount;
}
//******************************************************
// SetChannelCount()
///
/// Sets the number of channels on the I/O board.
///
//******************************************************
void CChanList::SetChannelCount(UCHAR noOfChannels) {
	m_ChannelCount = noOfChannels;
}
//******************************************************
// GetBoardID()
///
/// Gets the board ID that the channel schedule list is associated with.
///
/// @return The board instance.
/// 
//******************************************************
UCHAR CChanList::GetBoardID(void) {
	return m_BoardInstance;
}
//******************************************************
// DestroyChannels()
///
/// Destroys board channel class, for all card channels.
///
/// @pre Requires that concrete card classes are created and configuration loaded
///
/// @return TRUE if no errors when removing channels; otherwise FALSE.
/// 
//******************************************************
BOOL CChanList::DestroyChannels(void) {
	UCHAR chanNo;
	for (chanNo = 0; chanNo < MAX_IOBOARDCHANS; chanNo++) {
		if (m_pIOHndlr[chanNo] != NULL)
			static_cast<CIOChanHandler*>(m_pIOHndlr[chanNo])->SetupConfigChangePreparation();
		// Remove it to the process list
		RemoveChanFromSchedule(chanNo);
	}
	return TRUE;
}
//**********************************************************************
/// Sets all services on a setup commit change preperation
///
/// @return TRUE on successful commit; otherwise FALSE
/// 
//**********************************************************************
BOOL CChanList::SetupConfigChangePreparation(void) {
	UCHAR chanNo;
	BOOL retValue = TRUE;
	for (chanNo = 0; chanNo < MAX_IOBOARDCHANS; chanNo++) {
		if (m_pIOHndlr[chanNo] != NULL)
			static_cast<CIOChanHandler*>(m_pIOHndlr[chanNo])->SetupConfigChangePreparation();
	}
//	m_OPUpdateRequired = TRUE;		// Update DIT from NV
	m_ForceCardUpdate = TRUE;		// Make recorder update card from DIT
	return retValue;
}
//******************************************************
///
/// Resets the pesisted data output states.
/// @param[in] chanMask - Channel mask to reset.
///
/// @return TRUE on a O/P change being detected; otherwise FALSE
/// 
//******************************************************
BOOL CChanList::ResetPersistedDigitalPersistChannels(const USHORT chanMask) {
	class CNVBasicVar *pOPStateVar = NULL;
	COMBO_VAR4 OPStateVar;
	USHORT relayInverseState = 0;
	UCHAR CardSlotNo = 0;
	BOOL retValue = TRUE;
	CardSlotNo = GetBoardID();
	pOPStateVar = pNV_VARS->GetBasicVarNVObject(
			static_cast<NVVAR_IDENT>(NVV_RELAY_STATE_BOARD1 + CardSlotNo - RECORDER_SLOT_G));
	OPStateVar.us[0] &= chanMask;
	relayInverseState = ~OPStateVar.us[0];
	OPStateVar.us[1] = relayInverseState;
	pOPStateVar->SetToNV(OPStateVar);
	return retValue;
}
//******************************************************
///
/// Resets the pesisted data output states.
///
/// @return TRUE on a O/P change being detected; otherwise FALSE
/// 
//******************************************************
BOOL CChanList::ResetPersistedDigitalDITValues() {
	class CNVBasicVar *pOPStateVar = NULL;
	COMBO_VAR4 OPStateVar;
	USHORT relayInverseState = 0;
	UCHAR CardSlotNo = 0;
	BOOL retValue = TRUE;
	CardSlotNo = GetBoardID();
	pOPStateVar = pNV_VARS->GetBasicVarNVObject(
			static_cast<NVVAR_IDENT>(NVV_RELAY_STATE_BOARD1 + CardSlotNo - RECORDER_SLOT_G));
	OPStateVar.us[0] = 0;
	relayInverseState = ~OPStateVar.us[0];
	OPStateVar.us[1] = relayInverseState;
	pOPStateVar->SetToNV(OPStateVar);
	return retValue;
}
//******************************************************
///
/// Services the output channels on the recorder.
///
/// Note: Process is different for test equipment
/// @param[out] pCardData - System channel digital or analogue word data.
///
/// @return TRUE on a O/P change being detected; otherwise FALSE
/// 
//******************************************************
BOOL CChanList::ProcessOutputChannels( USHORT *pCardData) {
	class CNVBasicVar *pOPStateVar = NULL;
	COMBO_VAR4 OPStateVar;
	class CBrdInfo *pBrdInfoObj = NULL;					///< Board info holder
	UCHAR chanNo = 0;
	UCHAR cardChanType;
	UCHAR CardSlotNo = 0;
	BOOL digiState = FALSE;
	BOOL OPchangeDetected = FALSE;
	USHORT relayInverseState = 0;
	CardSlotNo = GetBoardID();
	pBrdInfoObj = CBrdInfo::GetHandle();
	if (IsRunningAsATEEquipment() == FALSE) {
		pOPStateVar = pNV_VARS->GetBasicVarNVObject(
				static_cast<NVVAR_IDENT>(NVV_RELAY_STATE_BOARD1 + CardSlotNo - RECORDER_SLOT_G));
		if (pBrdInfoObj != NULL) {
			*pCardData = 0;
			if (m_OPUpdateRequired == TRUE) {
#if 0
				// If just powered up get the last state to Non volatile state saved
				OPStateVar = pOPStateVar->GetFromNV()->value;
				relayInverseState = ~OPStateVar.us[0];
				if( OPStateVar.us[1] == relayInverseState )
				{
					// If vaild relay save found then set outputs to saved value
					*pCardData = OPStateVar.us[0];
				}
				else
				{
					// Valid relay save not found so set the outputs to the default condition
					*pCardData = 0;
				}
#endif
				OPchangeDetected = TRUE;
			}
			for (chanNo = 0; chanNo < GetListCount(); chanNo++) {
				if (m_pIOHndlr[chanNo] != NULL) {
					cardChanType = pBrdInfoObj->WhatSelectedChannelType(CardSlotNo, chanNo);
//					if( cardChanType == CHANNEL_DI )
//					{
					// Always save digital inputs as off, and then process the real inputs later
//						digiState = static_cast<BOOL> (GetBits(*pCardData, chanNo, 1));
//						if( digiState == TRUE )
//						{
//							digiState = FALSE;
//							static_cast<CIOChanHandler *> (m_pIOHndlr[chanNo])->UpdateOutputDigital(digiState);
//							OPchangeDetected = TRUE;
//						}
//					}
					if ( CHANNEL_DO == cardChanType) {
						/*
						 if( TRUE == m_OPUpdateRequired )
						 {
						 // If just powered up then we need to force an update
						 digiState = static_cast<BOOL> (GetBits(*pCardData, chanNo, 1));
						 OPchangeDetected |= static_cast<CIOChanHandler *> (m_pIOHndlr[chanNo])->UpdateOutputDigital(digiState);
						 
						 // Must complete initial recovery before outputing current values
						 }
						 */
						/*
						 if( TRUE == m_ForceCardUpdate )
						 {
						 digiState = FALSE;
						 OPchangeDetected |= static_cast<CIOChanHandler *> (m_pIOHndlr[chanNo])->UpdateOutputDigital(digiState);
						 }
						 else
						 */
						{
							// Ask the channel if there is an update in value
							OPchangeDetected |= static_cast<CIOChanHandler*>(m_pIOHndlr[chanNo])->OutputDigital(
									&digiState);
							SetBits(pCardData, digiState, chanNo, 1);
						}
					}
#if 0
					else if( m_OPUpdateRequired == TRUE )
					{
						// Any stored 'on' value needs to default to 'off' if just powered up,
						// if the channel is not a digital output
						digiState = FALSE;
						OPchangeDetected |= static_cast<CIOChanHandler *> (m_pIOHndlr[chanNo])->UpdateOutputDigital(digiState);
					}
#endif
					if ( TRUE == m_ForceCardUpdate) {
						// Force board update
						OPchangeDetected = TRUE;
						m_ForceCardUpdate = FALSE;
					}
				}
			}
			if (OPchangeDetected == TRUE) {
				// Update the last state to Non volatile
				OPStateVar.us[0] = *pCardData;
				OPStateVar.us[1] = ~OPStateVar.us[0];
				pOPStateVar->SetToNV(OPStateVar);				// Store to NV
			}
		}
	}
	m_OPUpdateRequired = FALSE;
	return OPchangeDetected;
}
//******************************************************
///
/// Services the output channels on the recorder.
///
/// Note: Process is different for test equipment
/// @param[out] pCardData - System channel analogue word data.
/// @param[out] nextToService - Card channel number that is next to check.
/// @param[out] pChanNo - Card channel number.
///
/// @return TRUE on a O/P change being detected; otherwise FALSE
/// 
//******************************************************
BOOL CChanList::ProcessOutputChannel( USHORT *pCardData, const UCHAR nextToService, UCHAR *pChanNo) {
	class CBrdInfo *pBrdInfoObj = NULL;					///< Board info holder
	UCHAR chanNo = 0;
	UCHAR cardChanType;
	UCHAR CardSlotNo = 0;
	BOOL digiState = FALSE;
	BOOL retValue = FALSE;
	pBrdInfoObj = CBrdInfo::GetHandle();
	if (pBrdInfoObj != NULL) {
		if (IsRunningAsATEEquipment() == FALSE) {
			*pCardData = 0;
			CardSlotNo = GetBoardID();
			for (chanNo = nextToService; chanNo < GetListCount(); chanNo++) {
				cardChanType = pBrdInfoObj->WhatSelectedChannelType(CardSlotNo, chanNo);
				if (m_pIOHndlr[chanNo] != NULL) {
					if (cardChanType == CHANNEL_AO) {
						if (m_pIOHndlr[chanNo] != NULL) {
							retValue = static_cast<CIOChanHandler*>(m_pIOHndlr[chanNo])->OutputAnalogue(pCardData,
									pChanNo);
							if (retValue == TRUE)
								break;
						}
					}
				}
			}
		}
	}
	return retValue;
}
//******************************************************
///
/// Creates or reconnects a concrete board channel type, for all card channels.
/// @param[in] pCard - Card to add channels to.
/// @param[in] refurbish - Card to add channels to.
///
/// @pre Requires that concrete card classes are created and configuration loaded
///
/// @return TRUE if no errors when creating channels; otherwise FALSE.
/// 
//******************************************************
BOOL CChanList::ChannelFactory(class CCardSlot *const pCard, const BOOL refurbish) {
	BOOL channelHandler = FALSE;
	BOOL boardHandlerRqd = FALSE;
	BOOL retValue = FALSE;
	UCHAR CardSlotNo;
	UCHAR cardChanType;
	UCHAR channelType;
	UCHAR chanNo;
	T_COMMONPROCESSINFO boardInfo;
	T_CHANPROCESSINFO chanInfo;
	class CBrdInfo *pBrdInfoObj = NULL;			///< Board info holder
	class CPPIOServiceManager *pServMngr = NULL;
	class CIOHandler *pService = NULL;
	class CIOChanHandler *pChanService = NULL;
	class CIOCardHandler *pCardService = NULL;
	class CChanList *pChanRef = NULL;
	class CDigPulseCard *pDigPulseCard = NULL;
	class CPPDICard *pDIService = NULL;
	class CPPPulseChannel *pPulseService = NULL;
	class CPPDOChannel *pDOService = NULL;
	class CPPAOChannel *pAOService = NULL;
	class CPPAIChannel *pAIService = NULL;
//	CTV6Timer factoryTimer(TIMER_HIGH_RES);		// Total time in factory
//	LONGLONG timetaken = (LONGLONG) 0L;
	// Transaction timer reset
//	qDebug("Starting Card Channel Factory timer\n");
//	factoryTimer.ResetAllTimers();
//	factoryTimer.StartTimer();
	pBrdInfoObj = CBrdInfo::GetHandle();
	pServMngr = CPPIOServiceManager::GetHandle();
	if ((pServMngr != NULL) && (pBrdInfoObj != NULL)) {
		pDIService = pServMngr->GetDIService();
		pPulseService = pServMngr->GetPulseService();
		pDOService = pServMngr->GetDOService();
		pAOService = pServMngr->GetAOService();
		pAIService = pServMngr->GetAIService();
	} else {
		QString errLog;
		// Log failure
		errLog = QString::asprintf("I/O board %d: Incorrect services CChanList::ChannelFactory",
				pCard->BoardSlotInstance());
		LogInternalError(errLog.toLocal8Bit().data());
	}
	pChanRef = pCard->GetChanSchedule();
	if (pChanRef != NULL) {
		CardSlotNo = pChanRef->GetBoardID();
		for (chanNo = 0; chanNo < MAX_IOBOARDCHANS; chanNo++) {
			boardHandlerRqd = FALSE;
			channelHandler = FALSE;
			pService = NULL;
			boardInfo.PPService = PP_SERVICE_UNKNOWN;
			chanInfo.PPService = PP_SERVICE_UNKNOWN;
			cardChanType = m_pBrdInfoObj->WhatSelectedChannelType(CardSlotNo, chanNo);
			switch (cardChanType) {
			case CHANNEL_AI:
			case CHANNEL_AO:
			case CHANNEL_DO:
			case CHANNEL_DI:
			case CHANNEL_PULSE:
			case CHANNEL_DIG_PULSE:
				SetChannelCount(chanNo);			///< If it is a valid channel then log as the largest to process
				// Do the same for all channel types
				if (refurbish == TRUE)
					pChanService = GetChannelRef(chanNo);
				else
					pChanService = new class CIOChanHandler();
				break;
			case CHANNEL_UNKNOWN:
				retValue = TRUE;		// No handler for an unknown channel
			default:
				break;
			}
			if (pChanService != NULL) {
				// Query each board slot, in turn (if in the recorder), creating the correct channel class
				switch (cardChanType) {
				case CHANNEL_AI:
					if (pAIService != NULL) {
						pAIService->CreateChannelServiceData(&boardInfo, &chanInfo, pCard, chanNo);
						channelHandler = TRUE;
					} else {
						// Could not create/obtain channel reference structure
						LogInternalError("Could not create/obtain channel reference structure");
					}
					break;
				case CHANNEL_AO:
					if (pAOService != NULL) {
						pAOService->CreateChannelServiceData(&boardInfo, &chanInfo, pCard, chanNo);
						channelHandler = TRUE;
					} else {
						// Could not create/obtain channel reference structure
						LogInternalError("Could not create/obtain channel reference structure");
					}
					break;
				case CHANNEL_DO:
					if (pDOService != NULL) {
						pDOService->CreateChannelServiceData(&boardInfo, &chanInfo, pCard, chanNo);
						channelHandler = TRUE;
					} else {
						// Could not create/obtain channel reference structure
						LogInternalError("Could not create/obtain channel reference structure");
					}
					break;
				case CHANNEL_DI:
//						// Install a channel for any channel that has a capability of being anything but a digital input
					// Install a channel stub for any channel that is a digital input
					channelType = pBrdInfoObj->WhatAvailableChannelType(CardSlotNo, chanNo);
//						if( ((channelType & CHANNEL_CAP_PULSE ) != 0) || ((channelType & CHANNEL_CAP_DO ) != 0) )
					{
						if (pDIService != NULL) {
							pDIService->CreateChannelServiceData(&boardInfo, &chanInfo, pCard, chanNo);
//								pDOService->CreateDefaultChannelServiceData( &boardInfo, &chanInfo, pCard, chanNo );
							channelHandler = TRUE;
						} else {
							// Could not create/obtain channel reference structure
							LogInternalError("Could not create/obtain channel reference structure");
						}
					}
					break;
				case CHANNEL_PULSE:
					if (pPulseService != NULL) {
						pPulseService->CreateChannelServiceData(&boardInfo, &chanInfo, pCard, chanNo);
						channelHandler = TRUE;
					} else {
						// Could not create/obtain channel reference structure
						LogInternalError("Could not create/obtain channel reference structure");
					}
					break;
				default:
					break;
				}
			} else if (retValue == FALSE) {
				QString errLog;
				// Log failure
				errLog = QString::asprintf("I/O board %d: Could not create/get channel %d service",
						pCard->BoardSlotInstance(), chanNo);
				LogInternalError(errLog.toLocal8Bit().data());
//				retValue = FALSE;
			}
			if (channelHandler == TRUE) {
				pChanService->InitialiseIOHandler();
				// It's a channel handler service required
				pCard->AddChanToSchedule(chanNo, pChanService);	// Add it to the process list
				// Schedule channel acqusition & read rates depending upon configuration
				// This includes "no schedule" for channels that are write not read
				pChanService->InitialiseChanService(&boardInfo, &chanInfo,
						static_cast<UCHAR>(pCard->GetChannelAcqRate(chanNo)));
			}
			retValue = TRUE;
		}
	} else if (retValue == TRUE) {
		QString errLog;
		// Log failure
		errLog = QString::asprintf("I/O board %d: Could not get channel reference", pCard->BoardSlotInstance());
		LogInternalError(errLog.toLocal8Bit().data());
	}
//	// Calculate the time that the factory took
//	factoryTimer.StopTimer();
//	timetaken = factoryTimer.GetTimeInMilliSec(TIMER_SINGLE);
//	qDebug("Card Channel Factory took %dmS\n", static_cast<int> (timetaken));
	return retValue;
}
//******************************************************
// SetGlobalChannelID()
///
/// Sets the global system system known channel number.
/// The action of setting the system kknown channel number also allows the
/// the channel to correctly initialised.
/// @param[in] channelNo - Card slot channel number.
/// @param[in] glbChannelNo - Card slot channel number, globally known to system.
///
/// @return TRUE if the global channel number is succesfully set; otherwise FALSE
/// 
//******************************************************
BOOL CChanList::SetGlobalChannelID(const USHORT channelNo, const USHORT glbChannelNo) {
	class CIOChanHandler *pIOChanHndlr;
	// Initialise the channel
	pIOChanHndlr = static_cast<class CIOChanHandler*>(m_pIOHndlr[channelNo]);
	return pIOChanHndlr->SetGlobalChannelID(glbChannelNo);
}
//******************************************************
// GetChannelCount()
///
/// Gets the number of channels that the I/O card to check.
///
/// @return Number of channels to scan
/// 
//******************************************************
USHORT CChanList::GetChannelCount(void) {
	return MAXIOCHANS;
}
//******************************************************
// ScheduleChannelRead()
///
/// Set the next time to run again.
/// @param[in] channelNo - Card slot channel number.
///
/// @return TRUE
/// 
//******************************************************
BOOL CChanList::ScheduleChannelRead(const USHORT channelNo) {
	if ((m_pIOHndlr[channelNo] != NULL) && (m_pIOHndlr[channelNo]->IsServiceAnInput() == TRUE))
		m_pIOHndlr[channelNo]->ScheduleNextServiceRead();
	return TRUE;
}
//******************************************************
// RemoveChanFromSchedule()
///
/// Removes an IO channel from an IO card.
/// @param[in] cardNo - Channel number identification.
///
/// @return TRUE is channel is deleted; otherwise FALSE.
/// 
//******************************************************
BOOL CChanList::RemoveChanFromSchedule(const USHORT chanNo) {
	BOOL removed = FALSE;
	// Delete channel from channel schedule
	if (m_pIOHndlr[chanNo] != NULL) {
		delete m_pIOHndlr[chanNo];
		m_pIOHndlr[chanNo] = NULL;
		removed = TRUE;
	}
	return removed;
}
//******************************************************
// GetChannelReadRate()
///
/// Sets the rate at which the readings are acquired from the card.
/// @param[in] channelNo - Card slot channel number.
///
/// @return The rate at which the readings are acquired from the card
/// 
//******************************************************
USHORT CChanList::GetChannelReadRate(const USHORT channelNo) const {
	return m_pIOHndlr[channelNo]->GetServiceReadRate();
}
//******************************************************
// GetChannelAcqRate()
///
/// Sets the actual acqusition rate of the channel (number of readings per second).
/// @param[in] channelNo - Card slot channel number.
///
/// @return The actual acqusition rate of the channel
/// 
//******************************************************
USHORT CChanList::GetChannelAcqRate(const USHORT channelNo) const {
	return m_pIOHndlr[channelNo]->GetServiceAcqRate();
}
//******************************************************
// GetTimeServiceRqd()
///
/// Gets the time the channel next needs servicing.
/// @param[in] channelNo - Card slot channel number.
///
/// @return the time that channel next requires servicing
/// 
//******************************************************
LONGLONG CChanList::GetTimeServiceRqd(const USHORT channelNo) {
	return m_pIOHndlr[channelNo]->GetTimeServiceRqd();
}
//******************************************************
// GetTimeServiceRqd()
///
/// Gets the time the earliest channel next needs servicing.
/// @param[out] pChannelNo - Card slot channel number.
/// @param[out] pEarliestTime - the time that channel next requires servicing.
///
/// @return TRUE if a channel is found to schedule; otherwise FALSE
/// 
//******************************************************
BOOL CChanList::GetEarliestServiceRqd( USHORT *const pChannelNo, LONGLONG *const pEarliestTime) {
	LONGLONG earliestTime = 0;
	USHORT chanNo = 0;
	BOOL retValue = FALSE;
	for (chanNo = 0; chanNo < MAX_IOBOARDCHANS; chanNo++) {
		// Only check valid channels
		if ((m_pBrdInfoObj->WhatSelectedChannelType(m_BoardInstance, chanNo) <= CHANNEL_DIG_PULSE)
				&& (m_pIOHndlr[chanNo] != NULL)) {
//			earliestTime = GetChannelReadRate( chanNo );
			earliestTime = m_pIOHndlr[chanNo]->GetTimeServiceRqd();
			if ((retValue == FALSE) || (earliestTime < *pEarliestTime)) {
				*pEarliestTime = earliestTime;
				*pChannelNo = chanNo;
				retValue = TRUE;
			}
		}
	}
	return retValue;
}

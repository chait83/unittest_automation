/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 I/O Scheduler
/// @n Filename: PPAIChannel.h
/// @n Desc:	Interface of the Pre-process AI channel class 
///
// 
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  30  Stability Project 1.27.1.1 7/2/2011 4:59:44 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  29  Stability Project 1.27.1.0 7/1/2011 4:27:15 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  28  V6 Firmware 1.27 3/14/2007 7:20:15 PM  Graham Waterfield
//  Added local declarations
//  27  V6 Firmware 1.26 1/5/2007 3:30:30 PM Graham Waterfield
//  Added error control TC burnout failure/recovery reporting
// $
//
//////////////////////////////////////////////////////////////////////
#ifndef _PPAICHANNEL_H
#define _PPAICHANNEL_H
#if !defined(AFX_PPAICHANNEL_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_)
#define AFX_PPAICHANNEL_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_
#include "Defines.h"
#include "PPIOService.h"
#if defined (DBG_FILE_LOG_PPAI_ERR_ENABLE) || defined (DBG_FILE_LOG_PPAI_DBG_ENABLE) || defined (DBG_FILE_LOG_PPAI_TC_DBG_ENABLE)
	#include "CStorage.h" //PSR - Debug File Logger integration
#endif
class CPPAIChannel: public CPPIOService {
public:
	CPPAIChannel(const BOOL chanInput);
	virtual ~CPPAIChannel();
	// Debug code
	void OpenChannelLog(void);
	void WriteChannelReading(const T_RANGE_COUNTS Reading);
	void WriteTimestamp(const USHORT TimeStamp);
	void NoOfReadings(const USHORT NoOfReadings);
	void CloseChannelLog(void);
	BOOL CreateChannelServiceData(T_COMMONPROCESSINFO *const pboardInfo, T_CHANPROCESSINFO *const pchanInfo,
			class CCardSlot *pCard, USHORT chanNo);
	float EngConvertAIChannelReading(const T_RANGE_COUNTS reading, class CFFConversionInfo *pEngScale);
	float mVConvertAIChannelReading(const T_RANGE_COUNTS reading);
	float uAConvertAIChannelReading(const T_RANGE_COUNTS reading);
	BOOL InitialiseChanService(T_CHANPROCESSINFO *const pChanInfo);
	BOOL SyncChannelQueue(T_CHANPROCESSINFO *const pChanInfo, const USHORT IOCardTick, const LONGLONG systemTick);
	void ResetRawVoltageReadings(T_PCHANPROCESSINFO pChanInfo);
	LONGLONG AIProcessMissingChannelReadings(T_COMMONPROCESSINFO *const pCommonInfo, T_CHANPROCESSINFO *const pChanInfo,
			const LONGLONG lastProcTime, const LONGLONG procTime);
	BOOL AIProcessChannelReading(const T_RANGE_COUNTS reading, const BOOL firstReading, const BOOL lastReading,
			T_CHANPROCESSINFO *const pChanInfo);
	BOOL ProcessAIChannelReadings(T_COMMONPROCESSINFO *const pCommonInfo, T_CHANPROCESSINFO *const pChanInfo,
			const UCHAR *pData, const USHORT timestamp, const USHORT noOfReadings);
	void ReportPPQDiagnostics(T_CHANPROCESSINFO *const pChanInfo);
private:
	BOOL CalculateOhmsReading(CAICard *const pAICard, CAIConfig *const pAIConfig, const CIOChanHandler *const pChan,
			T_PCHANPROCESSINFO pChanInfo, const float measuredV, float *const leadV, float *const ohmsMeasurement);
	void AddErrorReadingToQueue(T_PCHANPROCESSINFO pChanInfo, const float conditionedReading, const BOOL firstReading);
	void AddReadingToQueue(T_PCHANPROCESSINFO pChanInfo, const float conditionedReading, const BOOL firstReading);
	float AdjustEzResistanceReading(T_CHANPROCESSINFO *const pChanInfo, const float ResistorV, const float excitationA);
	void StoreEngineeringValue(T_PCHANPROCESSINFO pChanInfo, const float measuredV);
	BOOL ApplyActiveBurnoutStatus(T_PCHANPROCESSINFO pChanInfo, float *const conditionedReading,
			const BOOL upscaleBurnOutSelected);
	void ReportBurnOutDiagnostics(const T_DATAITEM_STATUS status, T_CHANPROCESSINFO *const pChanInfo);
	void ReportBurnOutRecovery(T_CHANPROCESSINFO *const pChanInfo);
	class CAIRanges *m_pAIRangeObj;							///< AI ranges
	class CPPIOServiceManager *m_pServiceManagerObj;		///< Service manager
	class CInputConditioning *m_pICService;					///< Input conditioning module
//		void *pChanConfig;			///< Channel configuaration
#if defined (DBG_FILE_LOG_PPAI_DBG_ENABLE) || defined (DBG_FILE_LOG_PPAI_TC_DBG_ENABLE)
		CDebugFileLogger m_debugFileLogger; //PSR - DebugFile Logger integration
#endif
};
#endif // !defined(AFX_PPAICHANNEL_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_)
#endif // _PPAICHANNEL_H

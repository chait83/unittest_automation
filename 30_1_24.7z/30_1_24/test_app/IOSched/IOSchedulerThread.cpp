/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n IOSchedulerThread.cpp
/// @n implementation of the IOSchedulerThread class.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
//
#include "V6ActiveModule.h"
#include "IOCardStats.h"
#include "BrdStats.h"
#include "IOScheduler.h"
#include "IOSchedulerThread.h"
#include "ThreadInfo.h"
#include "PPL.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
/////////////////////////////////////////////////////////////////////////////
// CIOSchedulerThread
// IMPLEMENT_DYNCREATE(CIOSchedulerThread, QThread)
CIOSchedulerThread::CIOSchedulerThread() {
//	qDebug("Create new CIOSchedulerThread class\n");
}
CIOSchedulerThread::~CIOSchedulerThread() {
//	qDebug("Delete CIOSchedulerThread class\n");
}
BOOL CIOSchedulerThread::InitInstance() {
	/// @todo: perform any per-thread initialization here
	return TRUE;
}
int CIOSchedulerThread::ExitInstance() {
	///@ todo: perform any per-thread cleanup here
     QThread::exit();
     return 0;
}
/////////////////////////////////////////////////////////////////////////////
// CIOSchedulerThread message handlers
UINT CIOSchedulerThread::ThreadFunc(LPVOID lpParam) {
	class CBrdStats *pBrdStatsObj = NULL;				///< Board stats holder
	CIOScheduler *pIOSchdlr = static_cast<CIOScheduler*>(lpParam);
	QString strLogMessage;
	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//after each iteration
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	//Notify that the WatchdogTimer that the IOScheduler thread has 
	//started
	if (pThreadInfo != NULL) {
		pThreadInfo->UpdateThreadInfo(AM_IO_SCHEDULER, true);
	}
	// Get handle to allow destruction of the last of the I/O scheduler utility singletons
	pBrdStatsObj = CBrdStats::GetHandle();
#ifdef THREAD_ID_SERIAL_LOG
		WCHAR szDbgMsg[512];
		swprintf( szDbgMsg, L"CIOSchedulerThread::ThreadFunc-Thread id 0x%x, %lu ", GetThreadId(GetCurrentThread()), GetThreadId(GetCurrentThread()));
		OutputDebugString(szDbgMsg);
		#endif
#ifdef DBG_FILE_LOG_IO_SCHED_ENABLE
	/*strLogMessage = QString::asprintf("CIOSchedulerThread::ThreadFunc ScheduleService begin GTC:%d\r\n", GetTickCount() );
	pIOSchdlr->m_debugFileLogger.WriteToDebugLogFile(strLogMessage);*/
#endif
	// Schedule any services that the thread can operate on
	pIOSchdlr->ScheduleService();
	// Wait for the shutdown, before terminating
	do {
		// Only schedule card operation if system not IDLE
		if (pIOSchdlr->HasIdleModeBeenOrdered() == FALSE) {
			pIOSchdlr->ActivatePriorityService();
			if (IsRunningAsATEEquipment() == TRUE)
				pIOSchdlr->CheckATECardReadingsAvailable();
		}
		// Check for a command, or wait for time to check cards again
		pIOSchdlr->Wait();
		if (pThreadInfo != NULL) {
			//Update the Thread Counter for the IOScheduler
			//after each iteration
			pThreadInfo->UpdateThreadCounter(AM_IO_SCHEDULER);
		}
	} while (!pBrdStatsObj->HasShutdownBeenOrdered());
	qDebug("CIOSchedulerThread class shutdown\n");
	// Destroy the last of the I/O scheduler utility singletons
	pBrdStatsObj->CleanUp();
	//Update the info that the IOScheduler thread is exiting
	//Hence this thread need not be considered to kick the 
	//watchdog
	if (pThreadInfo != NULL) {
		pThreadInfo->UpdateThreadInfo(AM_IO_SCHEDULER);
	}
	return 0x15;
}

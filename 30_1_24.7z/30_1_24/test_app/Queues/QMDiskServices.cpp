/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Queue Manager
/// @n Filename:	QMDiskServices.cpp
/// @n Description: Class Declaration File for the class CQMDiskServices
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 37	Stability Project 1.32.1.3	7/2/2011 5:00:03 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 36	Stability Project 1.32.1.2	7/1/2011 4:38:45 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 35	Stability Project 1.32.1.1	3/17/2011 3:20:38 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 34	Stability Project 1.32.1.0	2/15/2011 3:03:47 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
// **************************************************************************
#include "QMDiskServices.h"
#include "V6globals.h"

QMutex CQMDiskServices::m_csDiskServices;
ULONG glb_QMHeartBeat = NULL;
#ifdef SHOW_CPU
	#include "cpumon.h"
#endif
//****************************************************************************
/// Constructor
///
/// @param[in] 	&toDiskBlkQAccess - reference to the To DiskQueue class
/// @param[in] 	&memoryBlockAccess - reference to the SRAM data block class
/// @param[in] 	&memoryOpDataAccess - reference to Operational data SRAM area
/// @param[in] 	&persistedBlkQAccess - reference to the Free block queue class
/// @param[in] 	&persistedDataFileQAccess - reference to the file queue access class
/// @param[in] 	&DataFileAccess - reference to Free file access class
/// @param[in] 	&freeFileQAccess - reference to Free file Queue access class
///
/// @return No Return Value
/// 
//****************************************************************************
CQMDiskServices::CQMDiskServices(CQMBlkQAccess &toDiskBlkQAccess, CQMBlkQAccess &tempStorageBlkQAccess,
		CQMDataBlkAccess &memoryBlockAccess, const CQMMemoryOpDataAccess &memoryOpDataAccess,
		CQMPersistBlkQAccess &persistedBlkQAccess, CQMPersistDataFileQAccess &persistedDataFileQAccess,
		CQMDataFileAccess &dataFileAccess, CQMDataFileQAccess &freeFileQAccess)
: m_DiskHandler(toDiskBlkQAccess, tempStorageBlkQAccess, memoryBlockAccess, memoryOpDataAccess, persistedBlkQAccess,
		persistedDataFileQAccess, dataFileAccess, freeFileQAccess, m_asFiles),
m_UserRequestServices(memoryOpDataAccess, persistedBlkQAccess, persistedDataFileQAccess, dataFileAccess, m_asFiles,
		toDiskBlkQAccess, tempStorageBlkQAccess),
m_PersistBlkQAccess(persistedBlkQAccess),
m_LastFileBlockTransaction(memoryOpDataAccess.GetNumOfQueues()),
m_TempStorageBlkQAccess(tempStorageBlkQAccess),
m_ToDiskBlkQAccess(toDiskBlkQAccess) {
	// Initialise the Critical Section for Operation	

	m_OperationalMode = QMDSKSER_OPMODE_NORMAL_OPERATION;
	m_ActionToPerform = QMDSKSER_ACTION_WRITE_BLOCKS_TO_DISK;
	for (int i = 0; i < MAX_FILES; i++) {
		m_asFiles[i].bFileCreated = FALSE;
//		m_asFiles[i].hFile = NULL;
		m_asFiles[i].pFile = NULL;
		m_asFiles[i].bFileCurrOpen = FALSE;
	}
} // End of Constructor
//****************************************************************************
/// destructor
///
/// @return no return Value
///
///****************************************************************************
CQMDiskServices::~CQMDiskServices(void) {
	// Cleanup the Critical Section
	//deletion of mutex not required
	//cleanup created files
	for (int i = 0; i < MAX_FILES; i++)
		if (m_asFiles[i].bFileCurrOpen) {
			//if (m_asFiles[i].bFileCurrOpen)
//			CloseHandle(m_asFiles[i].hFile);
			m_asFiles[i].pFile->Close();
			delete m_asFiles[i].pFile;
		}
} // End of Destructor
///
//****************************************************************************
/// Initialise - start up the services related to the disk services
///
/// @param [in] pBlockServices - pointer to instance of block services
///
/// @return T_QMDSKSER_RETURN_VALUE - QMDSKSER_INITIALISATION_FAILED or QMDSKSER_OK
///
///****************************************************************************
T_QMDSKSER_RETURN_VALUE CQMDiskServices::Initialise(CQMBlockServices *pBlockServices) {
	T_QMDSKSER_RETURN_VALUE retValue = QMDSKSER_INITIALISATION_FAILED; // Member Function Return Value
	if (NULL != pBlockServices) {
		m_LastFileBlockTransaction.Initialise();
		m_DiskHandler.Initialise(pBlockServices, &m_LastFileBlockTransaction);
		m_UserRequestServices.Initialise(&m_LastFileBlockTransaction);
		retValue = QMDSKSER_OK;
	} // End of IF
	return (retValue);
} // End of Member Function
//****************************************************************************
/// RegisterWithQMDiskServices - Allow the User to Register with the Queue 
/// Manager Disk Services
///
/// @param [in] user - Op panel, logging, chart, message service
/// @param [in] pInternalMessageQueue - pointer to the message queue to send the message
///
/// @return T_QMDSKSER_RETURN_VALUE - QMDSKSER_OK
///
///****************************************************************************
T_QMDSKSER_RETURN_VALUE CQMDiskServices::RegisterWithQMDiskServices(const T_USRREQSER_USER user,
		CInternalMessageQueue *pInternalMessageQueue) {
	T_QMDSKSER_RETURN_VALUE retValue = QMDSKSER_OK; // Member Function Return Value
	m_UserRequestServices.RegisterUsingIntMsgQueue(user, pInternalMessageQueue);
	return (retValue);
} // End of Member Function												
//****************************************************************************
/// CompareAndFlushLostBlocks - This function is added recently to address 
/// data loss during abrupt power cycle scenario
/// If the blocks are deleted from SRAM (toDisk queue) and not completely written
/// into SD card due to power failures, the blocks are stored in temporary storage
/// queue will be used to fill the lost blocks
/// @param [in] n/a
///
/// @return USHORT
///
///****************************************************************************
USHORT CQMDiskServices::CompareAndFlushLostBlocks(void) {
	USHORT retValue = QMDSKSER_OK; // Member Function Return Value
	m_csDiskServices.lock();
	retValue = m_DiskHandler.CompareAndFlushLostBlocks();
	m_csDiskServices.lock();
	return (retValue);
} // End of Member Function 
//****************************************************************************
/// FlushDataBlocksToPhysicalDisk - Flush all the Data Blocks within the 
/// To Disk Queue to Physical Disk 
///
/// @param [in] n/a
///
/// @return T_QMDSKSER_RETURN_VALUE - QMDSKSER_OK
///
///****************************************************************************
T_QMDSKSER_RETURN_VALUE CQMDiskServices::FlushDataBlocksToPhysicalDisk(void) {
	T_QMDSKSER_RETURN_VALUE retValue = QMDSKSER_OK; // Member Function Return Value
	m_csDiskServices.lock();
	m_DiskHandler.WriteDataBlocksToPhysicalDisk(m_ToDiskBlkQAccess.GetNumOfBlocksInQueue());
	m_csDiskServices.lock();
	return (retValue);
} // End of Member Function 
//****************************************************************************
/// PerformNormalOperation - Perform Normal Operation ensuring both user 
/// requests are processed and block written to disk 
///
/// @param [in] n/a
///
/// @return T_QMDSKSER_RETURN_VALUE - QMDSKSER_OK
///
///****************************************************************************
T_QMDSKSER_RETURN_VALUE CQMDiskServices::PerformNormalOperation(void) {
	T_QMDSKSER_RETURN_VALUE retValue = QMDSKSER_OK; // Member Function Return Value
	m_csDiskServices.lock();
	// Determine the Action to Perform on this Disk Service Cycle
	switch (m_ActionToPerform) {
	case QMDSKSER_ACTION_WRITE_BLOCKS_TO_DISK: {
		glb_QMHeartBeat = 10;
		USHORT numOfBlockToWriteToPhysicalDisk = m_ToDiskBlkQAccess.GetNumOfBlocksInQueue();
		// check if the initial queue to disk limit has been met
		if (numOfBlockToWriteToPhysicalDisk >= QMDSKHAN_WRITE_TO_DISK_LIMIT) {
			// the initial limit has been met - check if any of the other limits have been met
			if (numOfBlockToWriteToPhysicalDisk <= QMDSKHAN_WRITE_TO_DISK_SECONDARY_LIMIT) {
				glb_QMHeartBeat = 11;
				// the secondary limit has not been met therefore flush all
				m_DiskHandler.WriteDataBlocksToPhysicalDisk(numOfBlockToWriteToPhysicalDisk);
			} else if (numOfBlockToWriteToPhysicalDisk < QMDSKHAN_WRITE_TO_DISK_FLUSH_ALL_LIMIT) {
				// we secondary limit has been exceended but the flush all limit has not so just
				// flush the default amount of blocks
				//int numBlocks = numOfBlockToWriteToPhysicalDisk < QMDSKHAN_DEFAULT_BLOCKS_TO_WRITE ? numOfBlockToWriteToPhysicalDisk:(numOfBlockToWriteToPhysicalDisk*2)/3;
				//m_DiskHandler.WriteDataBlocksToPhysicalDisk( numBlocks ); 
				if (numOfBlockToWriteToPhysicalDisk > QMDSKHAN_DEFAULT_BLOCKS_TO_WRITE) {
					glb_QMHeartBeat = 12;
					m_DiskHandler.WriteDataBlocksToPhysicalDisk(
					/*numOfBlockToWriteToPhysicalDisk*/QMDSKHAN_DEFAULT_BLOCKS_TO_WRITE);
				} else {
					glb_QMHeartBeat = 13;
					m_DiskHandler.WriteDataBlocksToPhysicalDisk(numOfBlockToWriteToPhysicalDisk);
				}
				//QString  strErr = L"Flush All limit not reached yet, pending blks = %d, Actual block to flush = %d ";
				/*QString  strErr = L"Flush All limit not reached yet, pending blks = %d";
				 strErr = QString::asprintf(strErr, (int)numOfBlockToWriteToPhysicalDisk);
				 LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_INFO, strErr);*/
			} else {
				glb_QMHeartBeat = 14;
				// the flush all limit must have been met therefore flush all
				m_DiskHandler.WriteDataBlocksToPhysicalDisk(numOfBlockToWriteToPhysicalDisk);
				//QString  strErr = L"FlushAll limit reached,pending blks = " ;
				//QString  strTemp;
				//strTemp = QString::asprintf("%d", (int)numOfBlockToWriteToPhysicalDisk);
				//strErr +=strTemp;
				//LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_INFO, strErr);
//#ifdef SHOW_CPU
//					float cpuUsage = GetCurrentCPUUtilization();
//					QString  csTxt2 ;
//					csTxt2 = QString::asprintf("CPU: %.02f%s", cpuUsage,L"%");
//					LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_WARNING, csTxt2);
//#endif
			}
			glb_QMHeartBeat = 15;
		} // End of IF
		else {
			glb_QMHeartBeat = 16;
		}
	}
		break;
	case QMDSKSER_ACTION_PROCESS_USER_REQUESTS: {
		glb_QMHeartBeat = 200;
		//qDebug("QM: PROCESS USER REQUESTS..................\n");
		// PerformUserRequest();
		m_UserRequestServices.ProcessUserRequest();
	}
		break;
	default: /* Error */
		break;
	} // End of SWITCH
	SetNextActionToPerform();
	m_csDiskServices.lock();
	return (retValue);
} // End of Member Function
//****************************************************************************
/// PerformShutdownSequence - Perform Shutdown Sequence ensuring all blocks 
/// are written to disk, and user requests processed 
///
/// @param [in] n/a
///
/// @return T_QMDSKSER_RETURN_VALUE - QMDSKSER_OK
///
///****************************************************************************
T_QMDSKSER_RETURN_VALUE CQMDiskServices::PerformShutdownSequence(void) {
	T_QMDSKSER_RETURN_VALUE retValue = QMDSKSER_OK; // Member Function Return Value
	// Flush the To Disk Queue to Physical Disk
	FlushDataBlocksToPhysicalDisk();
	// Perform All User Requests before closing. 
	while (USRREQSER_OK == m_UserRequestServices.ProcessUserRequest());
	m_DiskHandler.CloseAllActiveFile();
	return (retValue);
} // End of Member Function
////////////////////////////////////////////////////////////////////////////////////////////////
// Private Member Functions
////////////////////////////////////////////////////////////////////////////////////////////////
//****************************************************************************
/// WriteBlocksToDisk - Called by the Block Services to Write Block(s) to Disk 
///
/// @param [in] startBlockNumber - ID of first block in list to write
/// @param [in] endBlockNumber - ID of last block in list to write
/// @param [in] numOfBlocks - number of blocks to write
///
/// @return T_QMDSKSER_RETURN_VALUE - QMDSKSER_OK
///
///****************************************************************************
T_QMDSKSER_RETURN_VALUE CQMDiskServices::WriteBlocksToDisk(const USHORT startBlockNumber, const USHORT endBlockNumber,
		const USHORT numOfBlocks) {
	T_QMDSKSER_RETURN_VALUE retValue = QMDSKSER_OK; // Member Function Return Value
	if (QMDSKHAN_OK != m_DiskHandler.WriteBlocksToDisk(startBlockNumber, endBlockNumber, numOfBlocks)) {
		retValue = QMDSKSER_ERROR;
	}
	return (retValue);
} // End of Member Function 
//****************************************************************************
/// SetNextActionToPerform - called by DiskServicesThread to alternate every action
///
/// @param [in] void
///
/// @return void
///
///****************************************************************************
void CQMDiskServices::SetNextActionToPerform(void) {
	// Toogle the Action to perform
	if (QMDSKSER_ACTION_WRITE_BLOCKS_TO_DISK == m_ActionToPerform) {
		m_ActionToPerform = QMDSKSER_ACTION_PROCESS_USER_REQUESTS;
	} else {
		m_ActionToPerform = QMDSKSER_ACTION_WRITE_BLOCKS_TO_DISK;
	} // End of IF
} // End of Member Function 
/// Perform the Actions for writing blocks to Disk
//****************************************************************************
/// PerformWriteToDisk - empty function stub 
///
/// @param [in] void
///
/// @return T_QMDSKSER_RETURN_VALUE - QMDSKSER_OK
///
///****************************************************************************
T_QMDSKSER_RETURN_VALUE CQMDiskServices::PerformWriteToDisk(void) {
	T_QMDSKSER_RETURN_VALUE retValue = QMDSKSER_OK; // Member Function Return Value 
	return (retValue);
} // End of Member Function 
//****************************************************************************
/// PerformUserRequest - Perform the Actions assocatied with a User Request 
///
/// @param [in] void
///
/// @return T_QMDSKSER_RETURN_VALUE - QMDSKSER_OK
///
///****************************************************************************
T_QMDSKSER_RETURN_VALUE CQMDiskServices::PerformUserRequest(void) {
	T_QMDSKSER_RETURN_VALUE retValue = QMDSKSER_OK; // Member Function Return Value 
	// m_UserRequestServices.PostUserRequest( NULL, 0 );
	BYTE *pBuffer = new BYTE[10 * 512];
	//m_LastFileBlockTransaction.SetFileBlockTransaction( 393, 789, 1, 0 );
	m_LastFileBlockTransaction.SetFileBlockTransaction(QMC_LAST_QUEUE_ID, 0xFFFF, 0xFFFF, 0);
	/* GetPrevBlocksFromStartTime(USRREQSER_USER_OPPANEL,
	 393,
	 256,
	 10,
	 pBuffer,
	 USRREQSER_EXACT_NEAREST_OR_LAST_BLOCK );*/
	/* GetNextBlocksFromStartTime( USRREQSER_USER_OPPANEL,
	 393,
	 258,
	 10,
	 pBuffer );*/
	GetBlocksFromFirstAvailable(USRREQSER_USER_LOGGING, QMC_LAST_QUEUE_ID, 10, pBuffer);
	delete[] pBuffer;
	// ResetToOldestAvailable( USRREQSER_USER_LOGGING, 393, m_LastFileBlockTransaction.GetFileBlockTransaction( 393 ) ); 
	//GetPreviousBlocks( USRREQSER_USER_LOGGING, 393, 2, pBuffer );
	//GetNextBlocks( USRREQSER_USER_LOGGING, 393, 10, pBuffer );
	//GetNextBlocks( USRREQSER_USER_LOGGING, 393, 2, pBuffer );
	// m_UserRequestServices.ProcessUserRequest();
	return (retValue);
} // End of Member Function 
//****************************************************************************
/// GetPrevBlocksFromStartTime - Get the Specified Number of Blocks from a 
/// specified Start Time in a Backward Direction
///
/// @param [in] user - Op panel, logging, chart, message service
/// @param [in] hQueue - Queue handle to use
/// @param [in] startTime - Timepoint to search from
/// @param [in] numOfBlocks - number of blocks to fetch
/// @param [in] pDataBuffer - pointer of buffer to fill
///
/// @return T_QMDSKSER_RETURN_VALUE
///
///****************************************************************************
T_QMDSKSER_RETURN_VALUE CQMDiskServices::GetPrevBlocksFromStartTime(const T_USRREQSER_USER user, const USHORT hQueue,
		const LONGLONG startTime, const USHORT numOfBlocks, BYTE *const pDataBuffer) {
	/*
	 return( PostUserRequest( user, 
	 hQueue, 
	 USRREQSER_UA_GET_PREVIOUS_BLOCKS_FROM_START_TIME, 
	 startTime,
	 numOfBlocks, 
	 USRREQSER_NOT_REQUIRED, 
	 USRREQSER_MAINTAIN_FILE_TRANS_INT,
	 m_LastFileBlockTransaction.GetFileBlockTransaction( hQueue ),
	 NULL, 
	 pDataBuffer ) );
	 */
	T_QMDSKSER_RETURN_VALUE retValue = QMDSKSER_OK; // Member Function Return Value 
	T_USRREQSER_USER_MESSAGE_REQUEST userMessageRequest;
	userMessageRequest.user = user;
	userMessageRequest.hQueue = hQueue;
	userMessageRequest.userAction = USRREQSER_UA_GET_PREVIOUS_BLOCKS_FROM_START_TIME;
	userMessageRequest.startTime = startTime;
	userMessageRequest.numOfBlocks = numOfBlocks;
	userMessageRequest.mode = USRREQSER_NOT_REQUIRED;
	userMessageRequest.userFileTransactionType = USRREQSER_MAINTAIN_FILE_TRANS_INT;
	userMessageRequest.pFileBlockTransaction = m_LastFileBlockTransaction.GetFileBlockTransaction(hQueue);
	userMessageRequest.pConfirmFromFileBlockTransaction = NULL;
	userMessageRequest.pDataBuffer = pDataBuffer;
	T_IMQ_RETURN_VALUE ret = m_UserRequestServices.PostUserRequest(reinterpret_cast<BYTE*>(&userMessageRequest),
			sizeof(T_USRREQSER_USER_MESSAGE_REQUEST));
	if (ret >= IMQ_ERROR)
		retValue = QMDSKSER_ERROR;
	return (retValue);
} // End of Member Function														
//****************************************************************************
/// GetNextBlocksFromStartTime - Get the Specified Number of Blocks from a 
/// specified Start Time in a forward Direction
///
/// @param [in] user - Op panel, logging, chart, message service
/// @param [in] hQueue - Queue handle to use
/// @param [in] startTime - Timepoint to search from
/// @param [in] numOfBlocks - number of blocks to fetch
/// @param [in] pDataBuffer - pointer of buffer to fill
///
/// @return T_QMDSKSER_RETURN_VALUE
///
///****************************************************************************
T_QMDSKSER_RETURN_VALUE CQMDiskServices::GetNextBlocksFromStartTime(const T_USRREQSER_USER user, const USHORT hQueue,
		const LONGLONG startTime, const USHORT numOfBlocks, BYTE *const pDataBuffer)
		{
	/*
	 return( PostUserRequest( user, 
	 hQueue, 
	 USRREQSER_UA_GET_NEXT_BLOCKS_FROM_START_TIME, 
	 startTime,
	 numOfBlocks, 
	 USRREQSER_NOT_REQUIRED, 
	 USRREQSER_MAINTAIN_FILE_TRANS_INT,
	 m_LastFileBlockTransaction.GetFileBlockTransaction( hQueue ),
	 NULL, 
	 pDataBuffer ) );
	 */
	T_QMDSKSER_RETURN_VALUE retValue = QMDSKSER_OK; // Member Function Return Value 
	T_USRREQSER_USER_MESSAGE_REQUEST userMessageRequest;
	userMessageRequest.user = user;
	userMessageRequest.hQueue = hQueue;
	userMessageRequest.userAction = USRREQSER_UA_GET_NEXT_BLOCKS_FROM_START_TIME;
	userMessageRequest.startTime = startTime;
	userMessageRequest.numOfBlocks = numOfBlocks;
	userMessageRequest.mode = USRREQSER_NOT_REQUIRED;
	userMessageRequest.userFileTransactionType = USRREQSER_MAINTAIN_FILE_TRANS_INT;
	userMessageRequest.pFileBlockTransaction = m_LastFileBlockTransaction.GetFileBlockTransaction(hQueue);
	userMessageRequest.pConfirmFromFileBlockTransaction = NULL;
	userMessageRequest.pDataBuffer = pDataBuffer;
	T_IMQ_RETURN_VALUE ret = m_UserRequestServices.PostUserRequest(reinterpret_cast<BYTE*>(&userMessageRequest),
			sizeof(T_USRREQSER_USER_MESSAGE_REQUEST));
	if (ret >= IMQ_ERROR)
		retValue = QMDSKSER_ERROR;
	return (retValue);
} // End of Member Function														
//****************************************************************************
/// GetPrevBlocksFromNewest - Get the Specified Number of Blocks from the 
/// Newest Available in a Backward Direction
///
/// @param [in] user - Op panel, logging, chart, message service
/// @param [in] hQueue - Queue handle to use
/// @param [in] numOfBlocks - number of blocks to fetch
/// @param [in] pDataBuffer - pointer of buffer to fill
///
/// @return T_QMDSKSER_RETURN_VALUE
///
///****************************************************************************
T_QMDSKSER_RETURN_VALUE CQMDiskServices::GetPrevBlocksFromNewest(const T_USRREQSER_USER user, const USHORT hQueue,
		const USHORT numOfBlocks, BYTE *const pDataBuffer) {
	return (PostUserRequest(user, hQueue, USRREQSER_UA_GET_PREVIOUS_BLOCKS_FROM_NEWEST_AVAILABLE, QMC_ZERO, numOfBlocks,
			USRREQSER_NOT_REQUIRED, USRREQSER_MAINTAIN_FILE_TRANS_INT,
			m_LastFileBlockTransaction.GetFileBlockTransaction(hQueue), NULL, pDataBuffer));
} // End of Member Function													
//****************************************************************************
/// GetNextBlocks - Get the Specified Number of Blocks from the last point 
/// requested in a forward Direction
///
/// @param [in] user - Op panel, logging, chart, message service
/// @param [in] hQueue - Queue handle to use
/// @param [in] numOfBlocks - number of blocks to fetch
/// @param [in] pDataBuffer - pointer of buffer to fill
///
/// @return T_QMDSKSER_RETURN_VALUE
///
///****************************************************************************
T_QMDSKSER_RETURN_VALUE CQMDiskServices::GetNextBlocks(const T_USRREQSER_USER user, const USHORT hQueue,
		const USHORT numOfBlocks, BYTE *const pDataBuffer) {
	/*	
	 return( PostUserRequest( user,
	 hQueue, 
	 USRREQSER_UA_GET_NEXT_BLOCKS,
	 QMC_ZERO,
	 numOfBlocks,
	 USRREQSER_NOT_REQUIRED,
	 USRREQSER_MAINTAIN_FILE_TRANS_INT,
	 m_LastFileBlockTransaction.GetFileBlockTransaction( hQueue ),
	 NULL,
	 pDataBuffer ) );
	 */
	T_QMDSKSER_RETURN_VALUE retValue = QMDSKSER_OK; // Member Function Return Value 
	T_USRREQSER_USER_MESSAGE_REQUEST userMessageRequest;
	userMessageRequest.user = user;
	userMessageRequest.hQueue = hQueue;
	userMessageRequest.userAction = USRREQSER_UA_GET_NEXT_BLOCKS;
	userMessageRequest.startTime = QMC_ZERO;
	userMessageRequest.numOfBlocks = numOfBlocks;
	userMessageRequest.mode = USRREQSER_NOT_REQUIRED;
	userMessageRequest.userFileTransactionType = USRREQSER_MAINTAIN_FILE_TRANS_INT;
	userMessageRequest.pFileBlockTransaction = m_LastFileBlockTransaction.GetFileBlockTransaction(hQueue);
	userMessageRequest.pConfirmFromFileBlockTransaction = NULL;
	userMessageRequest.pDataBuffer = pDataBuffer;
	T_IMQ_RETURN_VALUE ret = m_UserRequestServices.PostUserRequest(reinterpret_cast<BYTE*>(&userMessageRequest),
			sizeof(T_USRREQSER_USER_MESSAGE_REQUEST));
	if (ret >= IMQ_ERROR)
		retValue = QMDSKSER_ERROR;
	return (retValue);
} //
/// Get the Specified Number of Block in a Backward Direction 
//****************************************************************************
/// GetPreviousBlocks - Get the Specified Number of Blocks from the last point 
/// requested in a backward Direction
///
/// @param [in] user - Op panel, logging, chart, message service
/// @param [in] hQueue - Queue handle to use
/// @param [in] numOfBlocks - number of blocks to fetch
/// @param [in] pDataBuffer - pointer of buffer to fill
///
/// @return T_QMDSKSER_RETURN_VALUE
///
///****************************************************************************
T_QMDSKSER_RETURN_VALUE CQMDiskServices::GetPreviousBlocks(const T_USRREQSER_USER user, const USHORT hQueue,
		const USHORT numOfBlocks, BYTE *const pDataBuffer) {
	/*
	 return( PostUserRequest( user,
	 hQueue, 
	 USRREQSER_UA_GET_PREVIOUS_BLOCKS,
	 QMC_ZERO,
	 numOfBlocks,
	 USRREQSER_NOT_REQUIRED,
	 USRREQSER_MAINTAIN_FILE_TRANS_INT,
	 m_LastFileBlockTransaction.GetFileBlockTransaction( hQueue ),
	 NULL,
	 pDataBuffer ) );
	 */
	T_QMDSKSER_RETURN_VALUE retValue = QMDSKSER_OK; // Member Function Return Value 
	T_USRREQSER_USER_MESSAGE_REQUEST userMessageRequest;
	userMessageRequest.user = user;
	userMessageRequest.hQueue = hQueue;
	userMessageRequest.userAction = USRREQSER_UA_GET_PREVIOUS_BLOCKS;
	userMessageRequest.startTime = QMC_ZERO;
	userMessageRequest.numOfBlocks = numOfBlocks;
	userMessageRequest.mode = USRREQSER_NOT_REQUIRED;
	userMessageRequest.userFileTransactionType = USRREQSER_MAINTAIN_FILE_TRANS_INT;
	userMessageRequest.pFileBlockTransaction = m_LastFileBlockTransaction.GetFileBlockTransaction(hQueue);
	userMessageRequest.pConfirmFromFileBlockTransaction = NULL;
	userMessageRequest.pDataBuffer = pDataBuffer;
	T_IMQ_RETURN_VALUE ret = m_UserRequestServices.PostUserRequest(reinterpret_cast<BYTE*>(&userMessageRequest),
			sizeof(T_USRREQSER_USER_MESSAGE_REQUEST));
	if (ret >= IMQ_ERROR)
		retValue = QMDSKSER_ERROR;
	return (retValue);
} // End of Member Function																									
//****************************************************************************
/// GetBlocksFromFirstAvailable - Get the Specified Number of Blocks from the 
/// earliest point in a backward Direction
///
/// @param [in] user - Op panel, logging, chart, message service
/// @param [in] hQueue - Queue handle to use
/// @param [in] numOfBlocks - number of blocks to fetch
/// @param [in] pDataBuffer - pointer of buffer to fill
///
/// @return T_QMDSKSER_RETURN_VALUE
///
///****************************************************************************
T_QMDSKSER_RETURN_VALUE CQMDiskServices::GetBlocksFromFirstAvailable(const T_USRREQSER_USER user, const USHORT hQueue,
		const USHORT numOfBlocks, BYTE *const pDataBuffer) {
	return (PostUserRequest(user, hQueue, USRREQSER_UA_GET_BLOCKS_FROM_FIRST_AVAILABLE, QMC_ZERO, numOfBlocks,
			USRREQSER_NOT_REQUIRED, USRREQSER_MAINTAIN_FILE_TRANS_INT,
			m_LastFileBlockTransaction.GetFileBlockTransaction(hQueue), NULL, pDataBuffer));
} // End of Member Function 
//resets the associated transaction point to the oldest block in the head file
//****************************************************************************
/// GetBlocksFromFirstAvailable - Get the Specified Number of Blocks from the 
/// earliest point in a backward Direction
///
/// @param [in] user - Op panene

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Queue Manager
/// @n Filename:	QMMemoryOpDataAccess.cpp
/// @n Description: Class Implementation File for CQMMemoryOpDataAccess
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 6	Stability Project 1.1.1.3	7/2/2011 5:00:04 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 5	Stability Project 1.1.1.2	7/1/2011 4:38:46 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 4	Stability Project 1.1.1.1	3/17/2011 3:20:39 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 3	Stability Project 1.1.1.0	2/15/2011 3:03:48 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
// **************************************************************************
#include "QMMemoryOpDataAccess.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//****************************************************************************
/// Constructor
///
/// @param[in] 	memoryOpData - Reference to the Memory Operation Data
///
/// @return No Return Value
/// 
//****************************************************************************
CQMMemoryOpDataAccess::CQMMemoryOpDataAccess(const T_QMC_DATA &memoryOpData) : m_MemoryOpData(memoryOpData) {
	// Do Nothing
} // End of Constructor
//****************************************************************************
/// Destructor
//****************************************************************************
CQMMemoryOpDataAccess::~CQMMemoryOpDataAccess(void) {
	// Do Nothing
} // End of Destructor

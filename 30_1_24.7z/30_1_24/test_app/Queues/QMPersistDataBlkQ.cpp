/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  Queue Manager
/// @n Filename:  QMPersistDataBlkQ.cpp
/// @n Description: Implementation File for the class CQMPersistDataBlkQ
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  14  Stability Project 1.9.1.3 7/2/2011 5:00:04 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  13  Stability Project 1.9.1.2 7/1/2011 4:38:46 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  12  Stability Project 1.9.1.1 3/17/2011 3:20:39 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  11  Stability Project 1.9.1.0 2/15/2011 3:03:48 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// **************************************************************************
#include "QMPersistDataBlkQ.h"
#include "QMMemoryBlkAccess.h"
#include "QMPersistBlkQAccess.h"
#include "V6globals.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
//****************************************************************************
/// Constructor
///
/// @param[in] 	persistDataBlkQ - Pointer to the Block Queue Access 
/// @param[in] memoryBlockAccess  - Pointer to data block access
///
/// @return No Return Value
/// 
//****************************************************************************
CQMPersistDataBlkQ::CQMPersistDataBlkQ(CQMPersistBlkQAccess &persistDataBlkQ, CQMDataBlkAccess &memoryBlockAccess) : m_PersistDataBlkQAccess(
		persistDataBlkQ), m_MemoryBlockAccess(memoryBlockAccess)
{
	// Do Nothing
} // End of Constructor
//****************************************************************************
/// Destructor
///
//****************************************************************************
CQMPersistDataBlkQ::~CQMPersistDataBlkQ(void) {
	// Do Nothing
} // End of Destructor
//****************************************************************************
/// SetupQueue - Initialises a queue for its first use
///
/// @param[in] 	hQueue - Queue Number to initialise
/// @param[in]  queueType - chart fast med slow,log,message
/// @param[in]  flushToDiskLimit - number of blocks to hold before a flush takes place
/// @param[in]  queueConfirmation - reserved
/// @param[in]  UserStatus - user definable flag
///
/// @return QMPDBQ_OK
/// 
//****************************************************************************
T_QMPDBQ_RETURN_VALUE CQMPersistDataBlkQ::SetupQueue(const USHORT hQueue, const T_QMC_QUEUE_TYPE queueType,
		const USHORT flushToDiskLimit, const T_QMC_QUEUE_CONFIRMATION queueConfirmation, const USHORT UserStatus) //=0xFFFF
		{
	if (QMPDBQ_OK != m_PersistDataBlkQAccess.ValidatePersistedQueueHandler(hQueue)) {
		QString strError("");
		strError = QString::asprintf("SetupQueue - Invalid queue handle (%u)", hQueue);
		V6CriticalMessageBox(NULL, strError.toLocal8Bit().data(), "CQMPersistDataBlkQ Error", MB_OK);
	}
	T_QMPDBQ_RETURN_VALUE retValue = QMPDBQ_OK; // Member Function Return Value 
	m_PersistDataBlkQAccess.SetStatus(hQueue, QMC_BLKQ_STATUS_QUEUE_SETUP);
	m_PersistDataBlkQAccess.SetQueueType(hQueue, queueType);
	m_PersistDataBlkQAccess.SetHead(hQueue, QMC_START_OF_QUEUE);
	m_PersistDataBlkQAccess.SetTail(hQueue, QMC_END_OF_QUEUE);
	m_PersistDataBlkQAccess.SetNumOfBlocks(hQueue, QMC_ZERO);
	m_PersistDataBlkQAccess.SetFlushToDiskLimit(hQueue, flushToDiskLimit);
	m_PersistDataBlkQAccess.SetUserStatus(hQueue, UserStatus);
	return (retValue);
} // End of Member Function  
//****************************************************************************
/// ResetQueue - Mark Queue as not in use
///
/// @param[in] 	hQueue - Queue Number to initialise
///
/// @return QMPDBQ_OK
/// 
//****************************************************************************  
T_QMPDBQ_RETURN_VALUE CQMPersistDataBlkQ::ResetQueue(const USHORT hQueue) {
	if (QMPDBQ_OK != m_PersistDataBlkQAccess.ValidatePersistedQueueHandler(hQueue)) {
		QString strError("");
		strError = QString::asprintf("ResetQueue - Invalid queue handle (%u)", hQueue);
		V6CriticalMessageBox(NULL, strError.toLocal8Bit().data(), "CQMPersistDataBlkQ Error", MB_OK);
	}
	T_QMPDBQ_RETURN_VALUE retValue = QMPDBQ_OK; // Member Function Return Value
	m_PersistDataBlkQAccess.SetStatus(hQueue, QMC_BLKQ_STATUS_QUEUE_NOT_SETUP);
	RemoveAllBlocks(hQueue, QMPDBQ_ALL);
	return (retValue);
} // End of Member Function  
//****************************************************************************
/// AddBlockToTail - Add a new block to the tail
///
/// @param[in] 	hQueue - Queue Number to add to
/// @param[in]  blockNumber - Block ID of empty block to add to tail
///
/// @return QMPDBQ_STATUS_EMPTY,
/// QMPDBQ_STATUS_SPACE_AVAILABLE,
/// QMPDBQ_STATUS_FLUSH_TO_DISK_REQUIRED
/// 
//**************************************************************************** 
T_QMPDBQ_QUEUE_STATUS CQMPersistDataBlkQ::AddBlockToTail(const USHORT hQueue, const USHORT blockNumber) {
	if (QMPDBQ_OK != m_PersistDataBlkQAccess.ValidatePersistedQueueHandler(hQueue)) {
		QString strError("");
		strError = QString::asprintf("AddBlockToTail - Invalid queue handle (%u)", hQueue);
		V6CriticalMessageBox(NULL, strError.toLocal8Bit().data(), "CQMPersistDataBlkQ Error", MB_OK);
	}
	if (QMPDBQ_OK != m_MemoryBlockAccess.ValidateBlockNumber(blockNumber)) {
		QString strError("");
		strError = QString::asprintf("AddBlockToTail - Invalid block number (%u)", blockNumber);
		V6CriticalMessageBox(NULL, strError.toLocal8Bit().data(), "CQMPersistDataBlkQ Error", MB_OK);
	}
	T_QMPDBQ_RETURN_VALUE retValue = QMPDBQ_OK;
	if (QMPDBQ_STATUS_EMPTY == GetQueueStatus(hQueue)) {
		// Set Head to the block being added
		m_PersistDataBlkQAccess.SetHead(hQueue, blockNumber);
		m_MemoryBlockAccess.SetNextBlock(blockNumber, QMC_END_OF_QUEUE);
	} else {
		m_MemoryBlockAccess.SetNextBlock(m_PersistDataBlkQAccess.GetTail(hQueue), blockNumber);
		m_MemoryBlockAccess.SetNextBlock(blockNumber, QMC_END_OF_QUEUE);
	} // End of IF
	m_PersistDataBlkQAccess.SetTail(hQueue, blockNumber);
	m_PersistDataBlkQAccess.IncrementNumOfBlocks(hQueue);
	// Set the Queue Id of the Block
	m_MemoryBlockAccess.SetQueueId(blockNumber, hQueue);
	return (GetQueueStatus(hQueue));
} // End of Member Function  
//****************************************************************************
/// GetHeadBlock - gets the Block pointer of the head of the queue
///
/// @param[in] 	hQueue - Queue Number to check
///
/// @return T_QMC_BLOCK pointer to head block
/// 
//****************************************************************************
T_QMC_BLOCK* const CQMPersistDataBlkQ::GetHeadBlock(const USHORT hQueue) const {
	if (QMPDBQ_OK != m_PersistDataBlkQAccess.ValidatePersistedQueueHandler(hQueue)) {
		QString strError("");
		strError = QString::asprintf("GetHeadBlock - Invalid queue handle (%u)", hQueue);
		V6CriticalMessageBox(NULL, strError.toLocal8Bit().data(), "CQMPersistDataBlkQ Error", MB_OK);
	}
	T_QMC_BLOCK *pBlock = NULL;
	if (QMPDBQ_STATUS_EMPTY != GetQueueStatus(hQueue)) {
		pBlock = m_MemoryBlockAccess.GetBlock(m_PersistDataBlkQAccess.GetHead(hQueue));
	} // End of IF
	return (pBlock);
} // End of Member Function
//****************************************************************************
/// GetQueueStatus - gets the current status of the queue
///
/// @param[in] 	hQueue - Queue Number to check
///
/// @return QMPDBQ_STATUS_EMPTY,
/// QMPDBQ_STATUS_SPACE_AVAILABLE,
/// QMPDBQ_STATUS_FLUSH_TO_DISK_REQUIRED
/// 
//**************************************************************************** 
T_QMPDBQ_QUEUE_STATUS CQMPersistDataBlkQ::GetQueueStatus(const USHORT hQueue) const {
	if (QMPDBQ_OK != m_PersistDataBlkQAccess.ValidatePersistedQueueHandler(hQueue)) {
		QString strError("");
		strError = QString::asprintf("GetQueueStatus - Invalid queue handle (%u)", hQueue);
		V6CriticalMessageBox(NULL, strError.toLocal8Bit().data(), "CQMPersistDataBlkQ Error", MB_OK);
	}
	T_QMPDBQ_QUEUE_STATUS retValue = QMPDBQ_STATUS_EMPTY;
	if ((QMC_START_OF_QUEUE != m_PersistDataBlkQAccess.GetHead(hQueue))
			&& (QMC_END_OF_QUEUE != m_PersistDataBlkQAccess.GetTail(hQueue))) {
		// Determine the status of the number of blocks within the queue
		if (m_PersistDataBlkQAccess.GetNumOfBlocksInQueue(hQueue)
				>= m_PersistDataBlkQAccess.GetFlushToDiskLimit(hQueue)) {
			retValue = QMPDBQ_STATUS_FLUSH_TO_DISK_REQUIRED;
		} else {
			retValue = QMPDBQ_STATUS_SPACE_AVAILABLE;
		} // End of IF 
	} // End of IF
	return (retValue);
} // End of Member Function  
//****************************************************************************
/// RemoveHeadBlock - Remove the head block and adjust the headers
///
/// @param[in] 	hQueue - Queue Number to remove
///
/// @return QMPDBQ_OK,
/// QMPDBQ_NO_BLOCK_TO_REMOVE
/// 
//****************************************************************************
T_QMPDBQ_RETURN_VALUE CQMPersistDataBlkQ::RemoveHeadBlock(const USHORT hQueue) {
	if (QMPDBQ_OK != m_PersistDataBlkQAccess.ValidatePersistedQueueHandler(hQueue)) {
		QString strError("");
		strError = QString::asprintf("RemoveHeadBlock - Invalid queue handle (%u)", hQueue);
		V6CriticalMessageBox(NULL, strError.toLocal8Bit().data(), "CQMPersistDataBlkQ Error", MB_OK);
	}
	T_QMPDBQ_RETURN_VALUE retValue = QMPDBQ_NO_BLOCK_TO_REMOVE;
	if (QMPDBQ_STATUS_EMPTY != GetQueueStatus(hQueue)) {
		USHORT nextBlock = m_MemoryBlockAccess.GetNextBlock(m_PersistDataBlkQAccess.GetHead(hQueue));
		if (QMC_END_OF_QUEUE == nextBlock) {
			m_PersistDataBlkQAccess.SetHead(hQueue, QMC_START_OF_QUEUE);
			m_PersistDataBlkQAccess.SetTail(hQueue, QMC_END_OF_QUEUE);
		} else {
			m_PersistDataBlkQAccess.SetHead(hQueue, nextBlock);
		} // End of IF
		m_PersistDataBlkQAccess.DecrementNumOfBlocks(hQueue);
		retValue = QMPDBQ_OK;
	} // End of IF
	return (retValue);
} // End of Member Function 
//****************************************************************************
/// RemoveHeadBlock - Remove the head block and adjust the headers
///
/// @param[in] 	hQueue - Queue Number to remove head from
///
/// @return QMPDBQ_OK,
/// QMPDBQ_NO_BLOCK_TO_REMOVE
/// 
//****************************************************************************
T_QMC_BLOCK* const CQMPersistDataBlkQ::GetTailBlock(const USHORT hQueue) const {
	if (QMPDBQ_OK != m_PersistDataBlkQAccess.ValidatePersistedQueueHandler(hQueue)) {
		QString strError("");
		strError = QString::asprintf("GetTailBlock - Invalid queue handle (%u)", hQueue);
		V6CriticalMessageBox(NULL, strError.toLocal8Bit().data(), "CQMPersistDataBlkQ Error", MB_OK);
	}
	T_QMC_BLOCK *pBlock = NULL;
	if (QMPDBQ_STATUS_EMPTY != GetQueueStatus(hQueue)) {
		pBlock = m_MemoryBlockAccess.GetBlock(m_PersistDataBlkQAccess.GetTail(hQueue));
	} // End of IF
	return (pBlock);
} // End of Member Function  
//****************************************************************************
/// GetNumOfBlocksInQueue - get the number of data blocks in a queue
///
/// @param[in] 	hQueue - Queue Number to check
///
/// @return count of blocks
/// 
//****************************************************************************  
USHORT CQMPersistDataBlkQ::GetNumOfBlocksInQueue(const USHORT hQueue) const {
	if (QMPDBQ_OK != m_PersistDataBlkQAccess.ValidatePersistedQueueHandler(hQueue)) {
		QString strError("");
		strError = QString::asprintf("GetNumOfBlocksInQueue - Invalid queue handle (%u)", hQueue);
		V6CriticalMessageBox(NULL, strError.toLocal8Bit().data(), "CQMPersistDataBlkQ Error", MB_OK);
	}
	return (m_PersistDataBlkQAccess.GetNumOfBlocksInQueue(hQueue));
} // End of Member Function
//****************************************************************************
/// RemoveAllBlocks - empty the queue
///
/// @param[in]  hQueue - Queue Number to empty
/// @param[in]  removeAllMode - QMPDBQ_ALL to remove all, QMPDBQ_EXCLUDING_TAIL all but last
///
/// @return QMPDBQ_OK
/// 
//****************************************************************************
/// Remove all Blocks from the Specified Queue
T_QMPDBQ_RETURN_VALUE CQMPersistDataBlkQ::RemoveAllBlocks(const USHORT hQueue,
		const T_QMPDBQ_REMOVE_BLOCK_MODE removeAllMode) {
	if (QMPDBQ_OK != m_PersistDataBlkQAccess.ValidatePersistedQueueHandler(hQueue)) {
		QString strError("");
		strError = QString::asprintf("RemoveAllBlocks - Invalid queue handle (%u)", hQueue);
		V6CriticalMessageBox(NULL, strError.toLocal8Bit().data(), "CQMPersistDataBlkQ Error", MB_OK);
	}
	if (QMPDBQ_ALL == removeAllMode) {
		m_PersistDataBlkQAccess.SetHead(hQueue, QMC_START_OF_QUEUE);
		m_PersistDataBlkQAccess.SetTail(hQueue, QMC_END_OF_QUEUE);
		m_PersistDataBlkQAccess.SetNumOfBlocks(hQueue, QMC_ZERO);
	} else {
		m_PersistDataBlkQAccess.SetHead(hQueue, m_PersistDataBlkQAccess.GetTail(hQueue));
		m_PersistDataBlkQAccess.SetNumOfBlocks(hQueue, QMC_ONE_BLOCK);
	} // End of IF
	return (QMPDBQ_OK);
} // End of Member Function
//****************************************************************************
/// GetBlockIdFromQueuePos - find the ID of a block in a particular place
///
/// @param[in]  hQueue - Queue Number to empty
/// @param[in]  queuePos - index into queue for block to check
///
/// @return Block ID
/// 
//****************************************************************************
USHORT CQMPersistDataBlkQ::GetBlockIdFromQueuePos(const USHORT hQueue, const USHORT queuePos) {
	if (QMPDBQ_OK != m_PersistDataBlkQAccess.ValidatePersistedQueueHandler(hQueue)) {
		QString strError("");
		strError = QString::asprintf("GetBlockIdFromQueuePos - Invalid queue handle (%u)", hQueue);
		V6CriticalMessageBox(NULL, strError.toLocal8Bit().data(), "CQMPersistDataBlkQ Error", MB_OK);
	}
	USHORT queuePosZeroBased = queuePos - QMC_ONE_BLOCK;
	USHORT blockId = m_PersistDataBlkQAccess.GetHead(hQueue);
	for (USHORT queuePosIndex = QMC_ZERO; queuePosIndex < queuePosZeroBased; queuePosIndex++) {
		blockId = m_MemoryBlockAccess.GetNextBlock(blockId);
	} // End of FOR
	return (blockId);
} // End of Member Function
//****************************************************************************
/// GetPersistDataBlkQ - wrapper
///
/// @param[in]  hQueue - Queue Number to empty
///
/// @return pointer to T_QMC_PERSIST_DATA_BLKQ header structure for hQueue
/// 
//****************************************************************************
const T_QMC_PERSIST_DATA_BLKQ& CQMPersistDataBlkQ::GetPersistDataBlkQ(const USHORT hQueue) const {
	return (m_PersistDataBlkQAccess.GetPersistDataBlkQ(hQueue));
} // End of Member Function
//****************************************************************************
/// TraceQueue - trace out the given queue in format 
/// Name: <Label>
/// Queue: HEAD = [<BlockID>][<BlockID>] = TAIL -> <BlockID>
///
/// @param[in] pName - label to append to trace
/// @param[in] hQueue - queue to trace
///
/// @return  void
/// 
//****************************************************************************
void CQMPersistDataBlkQ::TraceQueue(const QString pName, const USHORT hQueue) {
	if (QMPDBQ_OK != m_PersistDataBlkQAccess.ValidatePersistedQueueHandler(hQueue)) {
		QString strError("");
		strError = QString::asprintf("TraceQueue - Invalid queue handle (%u)", hQueue);
		V6CriticalMessageBox(NULL, strError.toLocal8Bit().data(), "CQMPersistDataBlkQ Error", MB_OK);
	}
	qDebug("\nName: %s Queue: %d\n", pName.toLocal8Bit().data(), hQueue);
	if (QMPDBQ_STATUS_EMPTY == GetQueueStatus(hQueue)) {
		qDebug("FILE QUEUE EMPTY\n");
	} else {
		USHORT item = m_PersistDataBlkQAccess.GetHead(hQueue);
		qDebug("HEAD =");
		for (USHORT pos = 0; pos < m_PersistDataBlkQAccess.GetNumOfBlocksInQueue(hQueue); pos++) {
			qDebug(" [%d] ", item);
			item = m_MemoryBlockAccess.GetNextBlock(item);
		} // End of FOR
		qDebug("= TAIL -> 0x%X (NoOfBlocks: %d)\n\n", item, m_PersistDataBlkQAccess.GetNumOfBlocksInQueue(hQueue));
	} // End of IF
} // End of Member Function 
//****************************************************************************
/// GetUserStatus - returns the user defined status field
///
/// @param[in]  hQueue - Queue Number to check
///
/// @return user defined value
/// 
//****************************************************************************  
USHORT CQMPersistDataBlkQ::GetUserStatus(const USHORT hQueue) const {
	if (QMPDBQ_OK != m_PersistDataBlkQAccess.ValidatePersistedQueueHandler(hQueue)) {
		QString strError("");
		strError = QString::asprintf("GetUserStatus - Invalid queue handle (%u)", hQueue);
		V6CriticalMessageBox(NULL, strError.toLocal8Bit().data(), "CQMPersistDataBlkQ Error", MB_OK);
	}
	return (m_PersistDataBlkQAccess.GetUserStatus(hQueue));
} // End of Member Function  
//****************************************************************************
/// SetUserStatus - sets the user defined status field
///
/// @param[in]  hQueue - Queue Number to set
///
/// @return  QMPBQA_OK,
///  QMPBQA_ERROR,
///  QMPBQA_QUEUE_NUMBER_INVALID
/// 
//****************************************************************************  
T_QMPBQA_RETURN_VALUE CQMPersistDataBlkQ::SetUserStatus(const USHORT hQueue, const USHORT UserStatus) {
	if (QMPDBQ_OK != m_PersistDataBlkQAccess.ValidatePersistedQueueHandler(hQueue)) {
		QString strError("");
		strError = QString::asprintf("SetUserStatus - Invalid queue handle (%u)", hQueue);
		V6CriticalMessageBox(NULL, strError.toLocal8Bit().data(), "CQMPersistDataBlkQ Error", MB_OK);
	}
	return (m_PersistDataBlkQAccess.SetUserStatus(hQueue, UserStatus));
} // End of Member Function  
//****************************************************************************
/// GetBlock - wrapper function to get a pointer to a specific block header
///
/// @param[in]  blockId - block ID to fetch header for
///
/// @return  T_QMC_BLOCK* - pointer to block header
/// 
//**************************************************************************** 
T_QMC_BLOCK* const CQMPersistDataBlkQ::GetBlock(const USHORT blockId) const {
	if (QMMBA_OK != m_MemoryBlockAccess.ValidateBlockNumber(blockId)) {
		QString strError("");
		strError = QString::asprintf("GetBlock - Invalid block ID (%u)", blockId);
		V6CriticalMessageBox(NULL, strError.toLocal8Bit().data(), "CQMPersistDataBlkQ Error", MB_OK);
	}
	T_QMC_BLOCK *pBlock = NULL;
	pBlock = m_MemoryBlockAccess.GetBlock(blockId);
	return (pBlock);
}

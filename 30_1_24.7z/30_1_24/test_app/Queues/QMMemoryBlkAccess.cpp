/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Queue Manager
/// @n Filename:	QMMemoryBlkAccess.cpp
/// @n Description: Implementation File for the class CQMDataBlkAccess
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 8	Stability Project 1.3.1.3	7/2/2011 5:00:03 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 7	Stability Project 1.3.1.2	7/1/2011 4:38:46 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 6	Stability Project 1.3.1.1	3/17/2011 3:20:39 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 5	Stability Project 1.3.1.0	2/15/2011 3:03:47 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
// **************************************************************************
#include "QMMemoryBlkAccess.h"
#include "V6globals.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//****************************************************************************
/// Constructor
///
/// @param[in] 	pFirstMemoryBlock - Pointer to the First Memory Block 
/// @param[in] maxNumOfBlocks	- Maximum Number of Blocks
///
/// @return No Return Value
/// 
//****************************************************************************
CQMDataBlkAccess::CQMDataBlkAccess(const T_PQMC_BLOCK pFirstMemoryBlock, const USHORT maxNumOfBlocks)
: m_Block(pFirstMemoryBlock), m_MaxNumOfBlocks(maxNumOfBlocks) {
} // End of Constructor
//****************************************************************************
/// Destructor
//****************************************************************************
CQMDataBlkAccess::~CQMDataBlkAccess(void) {
	// Do Nothing 
} // End of Destructor
//****************************************************************************
/// Validates the Block Number with the Maximum Number of Blocks Allowed
///
/// @param[in] 	blockNumber - Block Number to Validate
///
/// @return QMMBA_OK				- Block Number is VALID
///		QMMBA_BLOCK_NUMBER_INVALID - Block Number is INVALID			
/// 
//****************************************************************************
T_QMMBA_RETURN_VALUE CQMDataBlkAccess::ValidateBlockNumber(const USHORT blockNumber) {
	T_QMMBA_RETURN_VALUE retValue = QMMBA_OK;
	if (blockNumber >= m_MaxNumOfBlocks) {
		retValue = QMMBA_BLOCK_NUMBER_INVALID;
	} // End of IF
	return (retValue);
} // End of Member Function
//****************************************************************************
/// Obtains a Pointer the Specified Block, this member function is used internally
/// to the Queue Manager, and therefore an invalid block number should never occur.
/// In Debug mode an assertion will be thrown if an invalid block number is found. 
///
/// @param[in] 	blockNumber - Block Number Required
///
/// @return QMMBA_OK				- Block Number is VALID
///		QMMBA_BLOCK_NUMBER_INVALID - Block Number is INVALID			
/// 
//****************************************************************************
T_QMC_BLOCK* const CQMDataBlkAccess::GetBlock(const USHORT blockNumber) {
	// In Debug Mode check to ensure the Block Number provided is valid.
	if (QMMBA_OK != ValidateBlockNumber(blockNumber)) {
		QString strError("");
		strError = QString::asprintf("GetBlock - Invalid block number (%u)", blockNumber);
        V6CriticalMessageBox(NULL, strError, L"CQMDataBlkAccess Error", MB_OK );
	}
	return (&m_Block[blockNumber]);
} // End of Member Function

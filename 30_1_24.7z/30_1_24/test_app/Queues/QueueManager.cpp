/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Queue Manager
/// @n Filename:	Queue Manager.cpp
/// @n Description: Class Implementation for the CQueueManager Class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 21	Stability Project 1.16.1.3	7/2/2011 5:00:05 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 20	Stability Project 1.16.1.2	7/1/2011 4:38:47 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 19	Stability Project 1.16.1.1	3/17/2011 3:20:39 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 18	Stability Project 1.16.1.0	2/15/2011 3:03:49 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
// **************************************************************************
#include "QueueManager.h"
#include "TraceDefines.h"
#include "V6globals.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
/// Initialise the Class Instance to Default Value
CQueueManager *CQueueManager::m_pInstance = NULL;
/// Initialise the Class Mutex to Default Value
QMutex CQueueManager::m_CreationMutex;
//****************************************************************************
/// Constructor
//****************************************************************************
CQueueManager::CQueueManager(void) : m_bInitialised(false) {
	// Initialise Member Variables to Default Values	
	m_pBlockServices = NULL;
	m_pDiskServices = NULL;
} // End of Constructor
//****************************************************************************
/// Destructor
//****************************************************************************
CQueueManager::~CQueueManager(void) {
	// Delete the Services Classes Created
	delete (m_pBlockServices);
	m_pBlockServices = NULL;
	delete (m_pDiskServices);
	m_pDiskServices = NULL;
} // End of Destructor
//****************************************************************************
/// Deletes the instance of the singleton from memory
///
/// @param[in] 	- NONE
///
/// @return QUEMAN_OK - Cleanup was Successful
/// 
//****************************************************************************
T_QUEMAN_RETURN_VALUE CQueueManager::CleanUp(void) {
	delete m_pInstance;
	m_pInstance = NULL;
	return (QUEMAN_OK);
} // End of Member Function
//****************************************************************************
/// The first time this function is called it will created the single instance
/// of CQueueManager, Subsequent calls will return the Pointer to the instance
/// which has already been created.	
///
/// @param[in] 	- None
///
/// @return Pointer to the Queue Manager 
/// 
//****************************************************************************
CQueueManager* CQueueManager::GetHandle() {
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;
	if (NULL == m_pInstance) {
		// An instance has yet to be completed
		waitSingleObjectResult = m_CreationMutex.tryLock(g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);
		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:
			// Object was signaled
			if (NULL == m_pInstance) {
				m_pInstance = new CQueueManager;
			} // End of IF
			m_CreationMutex.unlock();
			break;
		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
			V6WarningMessageBox(NULL, "QueueManager WaitForSingleObject Error", "CQueueManager Error", MB_OK);
			break;
		} // End of SWITCH 
		// Close the Mutex as no longer required
		//No need to close the mutex in Qt
	} // End of IF 
	return (m_pInstance);
} // End of Member Function
//****************************************************************************
/// Initialises the Queue Manager for operation, constructing the Hardware,
/// and Services Layers used throughout the Queue Manager Module. The initialisation
/// performs data intergrity checks on the Memory Supplied to ensure that no data
/// corruption exists over power failure and startup/shutdown. Two types of Initialisation
/// exist, the first is the Default Initialisation in which all the supplied memory is
/// initialised to a default state, and the second is Normal Initialisation in which
/// the previous setup should be used, such as over a power failure or if the recorder is
/// shutdown and started up again.		
///
/// On successful initialisation all data blocks indentified as COMPLETED will be written
/// to Physical Disk. 
///
/// @param[in] initType	- The type of initialisation to be undertaken
/// @param[in] pBasePointer - Pointer to the memory to use for the Queue Manager
/// @param[in] systemInfo - Key data in order for the Queue Manager to be initialised correctly
///
/// @return QUEMAN_OK					- Queue Manager was successfully initialised
///		QUEMAN_INITIALISATION_FAILED - Queue Manager Initialisation Failed 
/// 
//****************************************************************************
T_QUEMAN_RETURN_VALUE CQueueManager::Initialise(T_QMC_INITIALISATION_TYPE initType, BYTE *const pBasePointer,
		const T_QMC_SYSTEM_INFO &systemInfo) {
	T_QUEMAN_RETURN_VALUE retValue = QUEMAN_INITIALISATION_FAILED;
	OutputDebugString(("CB: CQueueManager MemMgr initialisation\n"));
	if (QMMEMMAN_OK == m_QMHardwareLayer.Initialise(initType, pBasePointer, systemInfo)) {
		QString csTxt;
		csTxt = QWidget::tr("Performing Data Integrity Checks");
		pGlbSysInfo->SetStartupSubAction(csTxt);
		OutputDebugString(("CB: CQueueManager m_QMHardwareLayer.PerformDataIntegrityTests()\n"));
		if (QMMEMMAN_OK == m_QMHardwareLayer.PerformDataIntegrityTests(systemInfo)) {
			OutputDebugString(("CB: CQueueManager Create instances of Disk and Block Services\n"));
			//Integrity passed take a backup of FileQ
			BackupSRAMFileQueues();
			// Create the Block Services
			m_pBlockServices = new CQMBlockServices(m_QMHardwareLayer.GetFreeBlkQAccess(),
					m_QMHardwareLayer.GetPersistBlkQAccess(), m_QMHardwareLayer.GetDataBlkAccess(),
					m_QMHardwareLayer.GetMemoryOpDataAccess());
			// Create the Disk Services
			csTxt = QWidget::tr("Creating File Services");
			pGlbSysInfo->SetStartupSubAction(csTxt);
			m_pDiskServices = new CQMDiskServices(m_QMHardwareLayer.GetToDiskBlkQAccess(),
					m_QMHardwareLayer.GetTempStoredBlkQAccess(), m_QMHardwareLayer.GetDataBlkAccess(),
					m_QMHardwareLayer.GetMemoryOpDataAccess(), m_QMHardwareLayer.GetPersistBlkQAccess(),
					m_QMHardwareLayer.GetPersistDataFileQAccess(), m_QMHardwareLayer.GetDataFileAccess(),
					m_QMHardwareLayer.GetFreeFileAccess());
			// Check to ensure the Block Services and Disk Services have been created
			if (NULL != m_pBlockServices && NULL != m_pDiskServices) {
				// Initialise the Block Services
				csTxt = QWidget::tr("Initializing Block Services");
				pGlbSysInfo->SetStartupSubAction(csTxt);
				OutputDebugString(("CB: CQueueManager m_pBlockServices->Initialise()\n"));
				if (QMBLKSER_OK == m_pBlockServices->Initialise(m_pDiskServices)) {
					// Initialise the Disk Services
					csTxt = QWidget::tr("Initializing Disk Services");
					pGlbSysInfo->SetStartupSubAction(csTxt);
					OutputDebugString(("CB: CQueueManager m_pDiskServices->Initialise()\n"));
					if (QMBLKSER_OK == m_pDiskServices->Initialise(m_pBlockServices)) {
						// Flush Available Blocks Ready for Physical Disk		
						csTxt = QWidget::tr("Flushing Un-Persisted Blocks");
						pGlbSysInfo->SetStartupSubAction(csTxt);
						//This method added to make sure any blocks which are not completely written into 
						//SD card while abrupt power failure case and if those blocks are removed from ToDisk
						//Queue then it will be re-written again from temporary storage queue
						m_pDiskServices->CompareAndFlushLostBlocks();
						for (USHORT queueIndex = QMC_ZERO;
								queueIndex < m_QMHardwareLayer.GetMemoryOpDataAccess().GetNumOfQueues(); queueIndex++) {
							m_pBlockServices->FlushQDataBlocksReadyForDisk(queueIndex);
						} // End of FOR		
						// Flush Available Blocks to Physical Disk
						m_pDiskServices->FlushDataBlocksToPhysicalDisk();
						csTxt = QWidget::tr("Launching Disk Services Thread");
						pGlbSysInfo->SetStartupSubAction(csTxt);
						OutputDebugString(("CB: CQueueManager Create CQMDiskServicesThread\n"));
						// Initialisation Complete, start the Disk Service Thread Running
						m_pThread = AfxBeginThread(CQMDiskServicesThread::ThreadFunc, m_pDiskServices,
								THREAD_PRIORITY_NORMAL, QUEMAN_ZERO, CREATE_SUSPENDED, NULL);
						qDebug("CQueueManager Disk Service Thread ID: 0x%x, %lu\n", m_pThread->m_nThreadID,
								m_pThread->m_nThreadID);
						if (NULL != m_pThread) {
							// Allows a WaitForSingleObject to be used on the thread handle, for safe thread shutdown
							
							// Allow the Thread to Run
							m_pThread->start();
							retValue = QUEMAN_OK;
							// set the initialised flag
							m_bInitialised = true;
							// update the message queues
							OutputDebugString(("CB: CQueueManager pGlbMsgListSer->InitialiseQueues()\n"));
							pGlbMsgListSer->InitialiseQueues();
						} // End of IF
					} // End of IF
				} // End of IF
			} // End of IF
		} else {
			OutputDebugString(("CB: CQueueManager Initialisation Error..Stuck Here\n"));
			LOG_CRTL(TRACE_QUEUE_MANAGER, "Queue Manager Failed Data Intergrity Checks");
			csTxt = QWidget::tr("Data Integrity Tests Failed");
			pGlbSysInfo->SetStartupSubAction(csTxt);
            pGlbSysInfo->AddStartupErr("Fatal Error - System Cannot continue");
			while (TRUE);
		} // End of IF
	} // End of IF
	OutputDebugString(("CB: CQueueManager Initialisation End\n"));
	return (retValue);
} // End of Member Function
//****************************************************************************
/// Perform a Controlled Shutdown of the Queue Manager, informs the Queue Manager
/// thread to close, and waits until this thread has exited, providing a safe shutdown.
/// A timeout is implemented for closing the thread to ensure that the system does not
/// lock up if the thread shutdown fails. All Data Blocks that have been indentified as
/// COMPLETED will be written to Physical Disk.	
/// 
/// @param[in] 	- None 
///
/// @return QUEMAN_OK - Queue Manager has been Shutdown
/// 
/// @todo Replace qDebug with LOG_INFO / LOG_ERR
//****************************************************************************
T_QUEMAN_RETURN_VALUE CQueueManager::Shutdown(void) {
	///@todo Timeout increased to allow MultiPlus to shut-down
	const USHORT QUEMAN_SHUTDOWN_TIMEOUT_IN_MS = 30000; // Timeout of the Shutdown Process to avoid Deadlock ( 20 Seconds )
	// Shutdown the Block Services
	m_pBlockServices->Shutdown();
	// Prompt the Disk Service to Close Down
	m_pDiskServices->Shutdown();
	// Wait for the Disk Service Thread to Exit, to ensure all actions are performed before shutting down
	switch (WaitForSingleObject(m_pThread->m_hThread, QUEMAN_SHUTDOWN_TIMEOUT_IN_MS)) {
	case WAIT_OBJECT_0:
		delete (m_pThread);
		m_pThread = NULL;
		qDebug("QUEUE MANAGER SAFELY SHUTDOWN\n");
		break;
	case WAIT_TIMEOUT:
		qDebug("QM: SHUTDOWN HAS TAKEN TOO LONG\n");
		break;
	case WAIT_FAILED:
	case WAIT_ABANDONED:
		qDebug("QM: ERROR WITH WAIT\n");
		break;
	default:
		qDebug("QM: THREAD PROBLEM\n");
		break;
	} // End of SWITCH
	return (QUEMAN_OK);
} // End of Member Function 
//****************************************************************************
/// Perform a data integrity check on the block queues while the app is running
/// This will only work safely during a setup change as only the Free Q and TDQ are 
/// Critical Sectioned. otherwise the function may report a fail when it shouldn't
/// 
/// 
/// @param[in] 	- None 
///
/// @return QMMEMMAN_OK - check successful
///			QMMEMMAN_DATA_INTEGRITY_CHECKS_FAILED - check failed
/// 
//****************************************************************************
T_QMMEMMAN_RETURN_VALUE CQueueManager::BlockQueueIntegCheck(void) {
	T_QMMEMMAN_RETURN_VALUE retVal = QMMEMMAN_OK;
	//if this is only called when the data queues are inactive e.g. during a commit
	//then only using the freeblockQ and TDQ Critical sections should suffice.
	m_pDiskServices->EnterDSCritical();
	m_pBlockServices->EnterCS();
//	m_pDiskServices->EnterTDQCritical();
	retVal = m_QMHardwareLayer.PerformBlockIntegrityTests();
//	m_pDiskServices->LeaveTDQCritical();
	m_pBlockServices->LeaveCS();
	m_pDiskServices->LeaveDSCritical();
	return retVal;
}
//****************************************************************************
/// ClearChartBlocks - accessor to clear out all file and SRAM blocks related 
/// to charts
/// 
/// @param[in] 	- None 
///
/// @return QMMEMMAN_OK - all operations successful
///			QMMEMMAN_ERROR - one of files or blocks has failed
/// 
//****************************************************************************
T_QMMEMMAN_RETURN_VALUE CQueueManager::ClearChartBlocks() {
	if (QMBLKSER_OK == m_pBlockServices->ClearChartBlocks() && QMDSKSER_OK == m_pDiskServices->ClearChartFiles())
		return QMMEMMAN_OK;
	else
		return QMMEMMAN_ERROR;
}
//****************************************************************************
/// BackupSRAMFileQueues - Backup of SRAM file data to restore 
/// 
/// @param[in] 	- None 
///
/// @return			- None
/// 
//****************************************************************************
void CQueueManager::BackupSRAMFileQueues() {
	m_QMHardwareLayer.BackUpFileQueueHeaders();
}
//****************************************************************************
/// RestoreSRAMFileQueues - restore file data to SRAM when corrupted 
/// 
/// @param[in] 	- None 
///
/// @return			- None
/// 
//****************************************************************************
void CQueueManager::RestoreSRAMFileQueues() {
	m_QMHardwareLayer.RestoreFileQueueHeaders();
}
BOOL CQueueManager::ValidateBlockId(USHORT usBlockId) {
	BOOL bRet = FALSE;
	if (QMC_INVALID_BLOCK_NUMBER != usBlockId) {
		if (usBlockId >= QMC_ZERO && usBlockId < pGlbSysInfo->GetNumDataBlocks()) {
			bRet = TRUE;
		}
	}
	return bRet;
}
BOOL CQueueManager::ValidateFileId(USHORT usFileId) {
	BOOL bRet = FALSE;
	if (QMC_INVALID_FILE_NUMBER != usFileId) {
		if (usFileId >= QMC_ZERO && usFileId < pGlbSysInfo->GetNumCreatedFiles()) {
			bRet = TRUE;
		}
	}
	return bRet;
}

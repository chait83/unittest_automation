/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Queues
/// @n Filename:  QMDiskHandler.cpp
/// @n Description: Class Implementation File for the Disk Handler class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  69  Aristos  1.62.1.3.1.1 9/21/2011 3:15:56 PM  Hemant(HAIL)  
//  Updated watchdog threadinfo call check
//  68  Aristos  1.62.1.3.1.0 9/19/2011 4:51:12 PM  Hemant(HAIL)  
//  Stability recorder source code (JI Release) updated for WatchDog
//  Timer functionality.
//  67  Stability Project 1.62.1.3 7/2/2011 5:00:02 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  66  Stability Project 1.62.1.2 7/1/2011 4:38:45 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
// $
//
// **************************************************************************
//#include "CStorage.h"
#include "QMDiskHandler.h"
#include "V6crc.h"
#include "QMBlockServices.h"
#include "V6globals.h"
#include "QueueManager.h"
#include "MediaManager.h"
#include "ThreadInfo.h"
#include "ChartQueues.h"
//extern USHORT glb_usNUM_LAST_FILES_READ;
extern USHORT *glb_usaLastFilesRead;
extern USHORT glb_usLastFileArrayInd;
ULONG glb_QMBlockRel = NULL;
extern ULONG glb_QMHeartBeat;
#define FILE_BEGIN 0
CQMDiskHandler::CQMDiskHandler(CQMBlkQAccess &toDiskBlkQAccess, CQMBlkQAccess &tempStorageBlkQAccess,
		CQMDataBlkAccess &memoryBlockAccess, const CQMMemoryOpDataAccess &memoryOpDataAccess,
		CQMPersistBlkQAccess &persistedBlkQAccess, CQMPersistDataFileQAccess &persistedDataFileQAccess,
		CQMDataFileAccess &dataFileAccess, CQMDataFileQAccess &freeFileQAccess, T_PQMC_DBFILES pDBFiles)
: m_ToDiskBlockQueue(toDiskBlkQAccess, memoryBlockAccess), m_TempStorageBlockQueue(tempStorageBlkQAccess,
		memoryBlockAccess), m_MemoryOpData(memoryOpDataAccess), m_pBlockServices(NULL), m_PersistedBlkQAccess(
		persistedBlkQAccess), m_PersistedDataFileQ(persistedDataFileQAccess, dataFileAccess, pDBFiles), m_FreeFileQueue(
		freeFileQAccess, dataFileAccess), m_PersistedDataFileQAccess(persistedDataFileQAccess), m_DataFileAccess(
		dataFileAccess) {
	m_apFiles = pDBFiles;
	m_QueueIdToCheckForFile = QMDSKHAN_ZERO;
	m_OpenFileId = QMC_INVALID_FILE_NUMBER;
	m_OpenFileCount = 0;
} // End of Constructor
CQMDiskHandler::~CQMDiskHandler(void) {
} // End of Destructor
//****************************************************************************
// T_QMDSKHAN_RETURN_VALUE Initialise()
/// sets up a few variable after construction 
///
/// @param [in] - CQMBlockServices* - pointer of BlockServices instance
/// @param [in] - CQMFileBlockTransaction* - pointer of transaction point instance
///
/// @return QMDSKHAN_OK
/// 
//****************************************************************************
T_QMDSKHAN_RETURN_VALUE CQMDiskHandler::Initialise(CQMBlockServices *pBlockServices,
		CQMFileBlockTransaction *pFileTrans) {
	T_QMDSKHAN_RETURN_VALUE retValue = QMDSKHAN_OK;
	m_pBlockServices = pBlockServices;
	m_pLogDeviceStatus = CLogDeviceStatus::GetHandle();
	m_pFileTransaction = pFileTrans;
	return (retValue);
} // End of Member Function 
//****************************************************************************
// T_QMDSKHAN_RETURN_VALUE WriteBlocksToTempStorage()
/// add a chain of blocks from data queue to the to Temp Storage queue 
///
/// @return QMDSKHAN_ERROR if the add function fails
/// 
//****************************************************************************
T_QMDSKHAN_RETURN_VALUE CQMDiskHandler::WriteBlocksToTempStorage(USHORT blockIdx)
{
	T_QMDSKHAN_RETURN_VALUE retValue = QMDSKHAN_OK;
	T_QMC_BLOCK *pHeadBlock = NULL;
	//WCHAR printMsg[100];
	if (m_TempStorageBlockQueue.GetNumOfBlocksInQueue() >= QMC_MAX_TEMP_STORED_SIZE) {
		pHeadBlock = m_TempStorageBlockQueue.GetHeadBlock();
        m_TempStorageBlockQueue.RemoveHeadBlock();
		m_pBlockServices->FreeBlock(pHeadBlock->blockHeader.blockId);
		glb_QMBlockRel++;
        //qDebug("CB: Removed Block from TSQ\n"));
	}
    if (QMBQ_OK == m_ToDiskBlockQueue.RemoveHeadBlockNoModify()) //Remove block but do not modify the Block content
			{
		if (QMBQ_OK == m_TempStorageBlockQueue.AddLinkedBlocksToTail(blockIdx, blockIdx, 1)) {
            //swprintf( printMsg, 256, L"CB: Added Block to TSQ - %d\n",m_TempStorageBlockQueue.GetNumOfBlocksInQueue());
            //qDebug() << printMsg;;
		} else {
            //swprintf( printMsg, 256, L"---Error---WriteBlocksToTempStorage: Not Able to Add Block to TSQ - %d\n",blockIdx);
            //qDebug() << printMsg;;
			//Since add to TSQ gave error then free this block
			m_pBlockServices->FreeBlock(blockIdx);
			glb_QMBlockRel++;
			retValue = QMDSKHAN_ERROR;
		}
	} else {
        //swprintf( printMsg, 256, L"---Error---WriteBlocksToTempStorage: Not Able to Remove Block from TDQ - %d\n",blockIdx);
        //qDebug() << printMsg;;
	}
	return (retValue);
} // End of Member Function 
//****************************************************************************
// T_QMDSKHAN_RETURN_VALUE WriteBlocksToDisk()
/// add a chain of blocks from a data queue to the to disk queue 
///
/// @param [in] - startBlockNumber - ID of the block to start at
/// @param [in] - endBlockNumber - ID of Block to finish at
/// @param [in] - numOfBlocks - length of chain to add
///
/// @return QMDSKHAN_ERROR if the add function fails
/// 
//****************************************************************************
T_QMDSKHAN_RETURN_VALUE CQMDiskHandler::WriteBlocksToDisk(const USHORT startBlockNumber, const USHORT endBlockNumber,
		const USHORT numOfBlocks)
		{
	T_QMDSKHAN_RETURN_VALUE retValue = QMDSKHAN_OK;
	if (QMBQ_OK == m_ToDiskBlockQueue.AddLinkedBlocksToTail(startBlockNumber, endBlockNumber, numOfBlocks)) {
		CDataItem *pDI = pGlbDIT->GetDataItemPtr(DI_GENERAL, DI_GENTYPE_GENERAL, DI_GEN_QUEUE_TODISK);
		if (NULL != pDI) {
			pDI->SetValue(m_ToDiskBlockQueue.GetPercentageOfFreeBlocks()); //m_FreeBlockQueue.GetPercentageOfFreeBlocks()
		}
	} else {
		retValue = QMDSKHAN_ERROR;
	}
	return (retValue);
} // End of Member Function 
//****************************************************************************
// T_QMDSKHAN_RETURN_VALUE SetFileLimits()
/// obsolete stub function 
///
/// @param [in] - fileQueue - ID of the queue to set
/// @param [in] - minFiles - number of files to set as minimum
/// @param [in] - maxFiles - number of files to set as maximum
///
/// @return QMDSKHAN_OK
/// 
//****************************************************************************
T_QMDSKHAN_RETURN_VALUE CQMDiskHandler::SetFileLimits(const USHORT fileQueue, const USHORT minFiles,
		const USHORT maxFiles) {
	T_QMDSKHAN_RETURN_VALUE retValue = QMDSKHAN_OK;
	// m_
	return (retValue);
} // End of Member Function 
//****************************************************************************
/// CompareAndFlushLostBlocks - This function is added recently to address 
/// data loss during abrupt power cycle scenario
/// If the blocks are deleted from SRAM (toDisk queue) and not completely written
/// into SD card due to power failures, the blocks are stored in temporary storage
/// queue will be used to fill the lost blocks
/// @param [in] n/a
///
/// @return USHORT
///
///****************************************************************************
USHORT CQMDiskHandler::CompareAndFlushLostBlocks(void) {
	USHORT retValue = QMDSKHAN_OK, i = 0;
	USHORT NumOfBlocksToRead = 0;
	UINT8 ReadBuffer[QMC_BLOCK_SIZE];
	T_QMC_DATAFILE_HEADER *pFileHdr, *pFHdr;
	T_LOGRECORD *pBlockInSD, *pBlockInTemp;
	ChartRec *pChartRecSD, *pChartRecTemp;
	MessageRec *pMessageRecSD, *pMessageRecTemp;
	WCHAR printMsg[256];
	USHORT QType = 0, ReturnValue;
	USHORT NoOfRecoveredBlocks = 0;
	UINT8 IsBlockTobeWritten = FALSE;
	CFileStatus FSts;
	NumOfBlocksToRead = m_TempStorageBlockQueue.GetNumOfBlocksInQueue();
	for (i = 0; i < NumOfBlocksToRead; ++i) {
		//Get the Block from Temporary Block Queue
		m_pCurrBlKToProcess = m_TempStorageBlockQueue.GetHeadBlock();
		if (NULL != m_pCurrBlKToProcess) {
			IsBlockTobeWritten = FALSE;
			//Get FileID 
			pFileHdr = m_PersistedDataFileQ.GetTailFile(m_pCurrBlKToProcess->blockHeader.QueueId);
			QType = m_PersistedBlkQAccess.GetQueueType(m_pCurrBlKToProcess->blockHeader.QueueId);
			swprintf(printMsg, 256, L"Temp Storage: ID = %d, Blk Type = %d, QID = %d QType = %d FileID=%d\n",
					m_pCurrBlKToProcess->blockHeader.blockId, m_pCurrBlKToProcess->blockHeader.blockType,
					m_pCurrBlKToProcess->blockHeader.QueueId, QType,
					m_PersistedDataFileQAccess.GetTail(m_pCurrBlKToProcess->blockHeader.QueueId));
            qDebug() << printMsg;
			swprintf(printMsg, 256, L"SD card: File ID = %d, NumBlk = %d, Sts = %d Mode = %d QID = %d NewestNum = %d\n",
					pFileHdr->fileId, pFileHdr->numOfDataBlocks, pFileHdr->fileStatus, pFileHdr->fileMode,
					pFileHdr->queueId, pFileHdr->newestBlockNumber);
            qDebug() << printMsg;;
			//Open File for read or write
			if ( TRUE == OpenFileToWriteBlock(pFileHdr->fileId)) {
				//Modify below function to get correct position to read last block
				m_apFiles[m_OpenFileId].pFile->seek(0);
				m_apFiles[m_OpenFileId].pFile->Read(ReadBuffer, sizeof(T_QMC_DATAFILE_HEADER));
				pFHdr = (T_QMC_DATAFILE_HEADER*) ReadBuffer;
                //swprintf( printMsg, 256, L"SD card: File ID = %d, m_OpenFileId = %d, NumBlk = %d, Sts = %d Mode = %d QID = %d, NewestNum = %d, GetNewNum()=%d\n",pFHdr->fileId, m_OpenFileId,
				//	pFHdr->numOfDataBlocks, pFHdr->fileStatus, pFHdr->fileMode, pFHdr->queueId, pFHdr->newestBlockNumber,m_DataFileAccess.GetNewestBlockNumber(pFHdr->fileId));
                //qDebug() << printMsg;;
				ReturnValue = 0;
				if (m_apFiles[m_OpenFileId].pFile) {//Read the data from Disk for verification by going to proper location
					SeekToProperReadPosition(QType, ReturnValue, ReadBuffer);
                    m_apFiles[m_OpenFileId].pFile->GetStatus(FSts);
				}
				if (ReturnValue) {				//The read is successful
					if (QType == QMC_QUEUE_PEN_LOG) {//If block type is Pen then compare the sequence number to see whether any data_block lost
													 //OR not completely written into SD card
						pBlockInSD = (T_LOGRECORD*) ReadBuffer; //This points to Data read from SD card
						pBlockInTemp = (T_LOGRECORD*) m_pCurrBlKToProcess->blockData; //This points data which is there in temporary queue
						swprintf(printMsg, 256, L"Temp Storage: Pen Num = %d, Session = %d, SeqNo = %d\n",
								pBlockInTemp->Header.PenNumber, pBlockInTemp->Header.Session,
								pBlockInTemp->Header.SeqNo);
                        qDebug() << printMsg;;
						swprintf(printMsg, 256, L"SD card: Pen Num = %d, Session = %d, SeqNo = %d\n",
								pBlockInSD->Header.PenNumber, pBlockInSD->Header.Session, pBlockInSD->Header.SeqNo);
                        qDebug() << printMsg;;
						//Check if the data written in SD is latest or not
						if (((pBlockInTemp->Header.PenNumber == pBlockInSD->Header.PenNumber)
								&& (pBlockInTemp->Header.Session == pBlockInSD->Header.Session)
								&& (pBlockInTemp->Header.SeqNo > pBlockInSD->Header.SeqNo))
								|| ((pBlockInTemp->Header.Session > pBlockInSD->Header.Session)
										&& ((pBlockInTemp->Header.Session - pBlockInSD->Header.Session) < 5))
								|| (pBlockInTemp->Header.PenNumber != pBlockInSD->Header.PenNumber)) { //If the sequence number is higher OR if the Pen or session number does no tmatch then it is missing data block
																									 //There is a block which is not written into SD card on Abrupt power OFF
							IsBlockTobeWritten = TRUE;
							NoOfRecoveredBlocks++;
						}
					} else if (QType == QMC_QUEUE_MESSAGE) {//If block type is Message then compare the last message sequence and session number to see whether any data_block lost
						pMessageRecSD = (MessageRec*) ReadBuffer; //This points to Data read from SD card
						pMessageRecTemp = (MessageRec*) m_pCurrBlKToProcess->blockData; //This points data which is there in temporary queue
                        qDebug("CompareAndFlushLostBlocks(): =====Message Type======\n"));
						if (pMessageRecTemp->NumMessages > QMDSKHAN_ZERO
								&& pMessageRecTemp->NumMessages <= g_MAX_NO_OF_MESSAGES_PER_BLOCK) { //%I64u can be used to print long long integers
							swprintf(printMsg, 256,
									L"Temp Storage: NumOfMsg = %d, ID = %lld, Session = =%d logTime=%lld\n",
									pMessageRecTemp->NumMessages,
									pMessageRecTemp->message[pMessageRecTemp->NumMessages - 1].messageId,
									pMessageRecTemp->message[pMessageRecTemp->NumMessages - 1].usSessionNo,
									pMessageRecTemp->message[pMessageRecTemp->NumMessages - 1].logTime);
                            qDebug() << printMsg;;
							if (pMessageRecSD->NumMessages <= g_MAX_NO_OF_MESSAGES_PER_BLOCK
									&& pMessageRecSD->NumMessages > QMDSKHAN_ZERO) {
								swprintf(printMsg, 256,
										L"SD card: NumOfMsg = %d, ID = %lld, Session = =%d logTime=%lld\n",
										pMessageRecSD->NumMessages,
										pMessageRecSD->message[pMessageRecSD->NumMessages - 1].messageId,
										pMessageRecSD->message[pMessageRecSD->NumMessages - 1].usSessionNo,
										pMessageRecSD->message[pMessageRecSD->NumMessages - 1].logTime);
                                qDebug() << printMsg;;
								//Check if the data written in SD is latest or not
								if (((pMessageRecTemp->message[pMessageRecTemp->NumMessages - 1].usSessionNo
										== pMessageRecSD->message[pMessageRecSD->NumMessages - 1].usSessionNo)
										&& (pMessageRecTemp->message[pMessageRecTemp->NumMessages - 1].logTime
												> pMessageRecSD->message[pMessageRecSD->NumMessages - 1].logTime)) || //Is Msg timestamp written in SD is latest 
										((pMessageRecTemp->message[pMessageRecTemp->NumMessages - 1].usSessionNo
												> pMessageRecSD->message[pMessageRecSD->NumMessages - 1].usSessionNo)
												&& ((pMessageRecTemp->message[pMessageRecTemp->NumMessages - 1].usSessionNo
														- pMessageRecSD->message[pMessageRecSD->NumMessages - 1].usSessionNo)
														< 5)) //Is session written in SD is latest (consider that not more than 5 times configuration has changed and data available in Temp Storage
										) {
									//There is a block which is not written into SD card on Abrupt power OFF
									IsBlockTobeWritten = TRUE;
									NoOfRecoveredBlocks++;
								}
								//Else Drop the Temporary block
							} else { //The SD card does not have valid data, so write it again
                                qDebug("CompareAndFlushLostBlocks(): The SD block data is corrupted\n");
								IsBlockTobeWritten = TRUE;
								NoOfRecoveredBlocks++;
							}
						} else {
                            qDebug( "CompareAndFlushLostBlocks(): The Temporary block data is corrupted, drop it\n");
						}
					} else //Chart Type
					{ //TBD: Session, does not applicable to Chart.
						pChartRecSD = (ChartRec*) ReadBuffer; //This points to Data read from SD card
						pChartRecTemp = (ChartRec*) m_pCurrBlKToProcess->blockData; //This points data which is there in temporary queue
                        qDebug("CompareAndFlushLostBlocks(): =====Chart Type======\n");
						swprintf(printMsg, 256, L"SD card: PenNo = %d, RateIdx = %d, TimeH = %d, TimeL = %d\n",
								pChartRecSD->hdr.penNo, pChartRecSD->hdr.rateIndex, pChartRecSD->hdr.startTimeH,
								pChartRecSD->hdr.startTimeL);
                        qDebug() << printMsg;;
						swprintf(printMsg, 256, L"Temp Storage: PenNo = %d, RateIdx = %d, TimeH = %d, TimeL = %d\n",
								pChartRecTemp->hdr.penNo, pChartRecTemp->hdr.rateIndex, pChartRecTemp->hdr.startTimeH,
								pChartRecTemp->hdr.startTimeL);
                        qDebug() << printMsg;;
						//Check if the data written in SD is latest or not
						if ((pChartRecTemp->hdr.penNo == pChartRecSD->hdr.penNo)
								&& (pChartRecTemp->hdr.rateIndex == pChartRecSD->hdr.rateIndex)
								&& (((pChartRecTemp->hdr.startTimeH == pChartRecSD->hdr.startTimeH)
										&& (pChartRecTemp->hdr.startTimeL > pChartRecSD->hdr.startTimeL))
										|| (pChartRecTemp->hdr.startTimeH > pChartRecSD->hdr.startTimeH))) {
							//There is a block which is not written into SD card on Abrupt power OFF
							//if( )
							{							//To check if it is not genuine, skip if not genuine.
														//Do not see more than 100 blocks getting lost, it could be roll over. Not handled at this point???
								IsBlockTobeWritten = TRUE;
								NoOfRecoveredBlocks++;
							}
						}
					}
				} else {							//Error in reading SD card file
					swprintf(printMsg, 256, L"CompareAndFlushLostBlocks(): Reading File failed = %d Sts=%d\n",
							ReturnValue, FSts.m_attribute);
                    qDebug() << printMsg;;
				}
			} else {							//File is not correct or some problem in opening file
                qDebug("CompareAndFlushLostBlocks(): Could not Open file\n");
			}
			if (TRUE == IsBlockTobeWritten) {							//File is missing, write it back to SD card
																		//Write Block to File
				USHORT fileId = QMC_INVALID_FILE_NUMBER;
                qDebug("CompareAndFlushLostBlocks(): ****WRITE QUEUE TO FILE****\n");
				// Step 1: Obtain the File to Write Block
				fileId = ObtainFileToWriteBlock();
				// Step 2: Open the File 
				if ( TRUE == OpenFileToWriteBlock(fileId)) {
                    qDebug("CompareAndFlushLostBlocks(): WriteBlockToPhysicalDisk\n");
					// Step 3: Seek to the Correct Position in the File to Write Block
					SeekToWritePosition();
					// Step 4: Write Block to the File
					if (WriteBlockToPhysicalDisk()) {
						// Step 5: Update SRAM File Header  
                        qDebug("CompareAndFlushLostBlocks(): UpdateSRAMFileHeader\n");
						UpdateSRAMFileHeader();
						pFileHdr = m_DataFileAccess.GetFileHeader(fileId);
                        swprintf(printMsg,256,
								L"SD card: File ID = %d, NumBlk = %d, Sts = %d Mode = %d QID = %d NewestNum = %d\n",
								pFileHdr->fileId, pFileHdr->numOfDataBlocks, pFileHdr->fileStatus, pFileHdr->fileMode,
								pFileHdr->queueId, pFileHdr->newestBlockNumber);
                        qDebug() << printMsg;;
					} else {
                        qDebug("CompareAndFlushLostBlocks(): ****ERROR in WRITE****\n");
					}
				} else {
                    qDebug("CompareAndFlushLostBlocks(): ****ERROR in OPEN****\n");
				}
			}
			//Free the block
            qDebug("CompareAndFlushLostBlocks(): Free the Block\n");
            m_TempStorageBlockQueue.RemoveHeadBlock();
			m_pBlockServices->FreeBlock(m_pCurrBlKToProcess->blockHeader.blockId);
			glb_QMBlockRel++;
		} else {
            qDebug("CompareAndFlushLostBlocks(): Some Error, could not process Temp Storage blocks\n");
			retValue = 3; //Number other than zero indicating problem
			break;
		}
	}
	swprintf(printMsg, 256,
			L"-----------CompareAndFlushLostBlocks(): Number of Blocks recovered = %d\n------------------",
			NoOfRecoveredBlocks);
    qDebug() << printMsg;;
	m_pCurrBlKToProcess = NULL;
	return (retValue);
}
//****************************************************************************
// void WriteDataBlocksToPhysicalDisk()
/// write blocks from the to disk queue down to physical flash and release 
/// blocks to the free block queue
///
/// @param [in] - numOfBlocksToWriteToPhysicalDisk - count of blocks to write
///
/// @return n/a
/// 
//****************************************************************************
void CQMDiskHandler::WriteDataBlocksToPhysicalDisk(const USHORT numOfBlocksToWriteToPhysicalDisk) {
	USHORT usLastQID = QMC_INVALID_QUEUE;
#ifdef UNDER_CE
	CThreadInfo* pThreadInfo = CThreadInfo::GetHandle();
#endif
	for (USHORT blockIndex = QMDSKHAN_ZERO; blockIndex < numOfBlocksToWriteToPhysicalDisk; blockIndex++) {
		glb_QMHeartBeat = 20;
#ifdef UNDER_CE	
		if(pThreadInfo != NULL)
		{
			//Update the thread counter of diskservices thread 
			pThreadInfo->UpdateThreadCounter(AM_QMDISKSERVICES);
			pThreadInfo->UpdateThreadCounter(AM_TX_SCHEDULER_THREAD);
		}  
#endif
		m_pCurrBlKToProcess = m_ToDiskBlockQueue.GetHeadBlock();
		USHORT QId = m_pCurrBlKToProcess->blockHeader.QueueId;
		if (NULL != m_pCurrBlKToProcess) {
			USHORT fileId = QMC_INVALID_FILE_NUMBER;
			//glb_QMHeartBeat = 21;
			// Step 1: Obtain the File to Write Block
			fileId = ObtainFileToWriteBlock();
			//glb_QMHeartBeat = 22;
			// Step 2: Open the File 
			if ( TRUE == OpenFileToWriteBlock(fileId)) {
				//glb_QMHeartBeat = 23;
				// Step 3: Seek to the Correct Position in the File to Write Block
				SeekToWritePosition();
				//glb_QMHeartBeat = 24;
				// Step 4: Write Block to the File
				if (WriteBlockToPhysicalDisk()) {
					//glb_QMHeartBeat = 25;
					// Step 5: Update SRAM File Header  
					m_PersistedBlkQAccess.SetStatus(QId, QMC_BLKQ_STATUS_RELEASE_BLOCK);
					UpdateSRAMFileHeader();
					//glb_QMHeartBeat = 26;
					// Step 6: Release Block  
					ReleaseBlock();
					//glb_QMHeartBeat = 27;
					m_PersistedBlkQAccess.SetStatus(QId, QMC_BLKQ_STATUS_QUEUE_SETUP);
				}
				//glb_QMHeartBeat = 28;
				CDataItem *pDI = pGlbDIT->GetDataItemPtr(DI_GENERAL, DI_GENTYPE_GENERAL, DI_GEN_QUEUE_TODISK);
				if (NULL != pDI) {
					pDI->SetValue(m_ToDiskBlockQueue.GetPercentageOfFreeBlocks());//m_FreeBlockQueue.GetPercentageOfFreeBlocks()
				}
				//glb_QMHeartBeat = 29;
				pDI = pGlbDIT->GetDataItemPtr(DI_GENERAL, DI_GENTYPE_GENERAL, DI_GEN_QUEUE_FILESFREE);
				if (NULL != pDI) {
					pDI->SetValue(m_FreeFileQueue.GetPercentageOfFreeFiles());//m_FreeBlockQueue.GetPercentageOfFreeBlocks()
				}
				//glb_QMHeartBeat = 30;
			} // End of IF
			else {
				glb_QMHeartBeat = 31;
			}
		} else {
			qDebug("QM DSK HAN -------------FATAL ERROR-------------\n");
			glb_QMHeartBeat = 32;
		} // End of IF
	} // End of FOR 
	//glb_QMHeartBeat = 180;
	//disable active file
	CloseActiveFile(FALSE);	//_TEST TRUE here to always close, FALSE for never or when full
	glb_QMHeartBeat = 181;
	//QString  strErr = L"Blks written to file:%d";
	//strErr = QString::asprintf(strErr, (int)numOfBlocksToWriteToPhysicalDisk);
	//LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_INFO, strErr);
} // End of Member Function 
//****************************************************************************
// USHORT ObtainFileToWriteBlock()
/// determine where to aquire a new file from. from the free queue, another 
/// queue or recycle the current files
///
/// @param [n/a]
///
/// @return File ID of new tail file or QMC_INVALID_FILE_NUMBER
/// 
//**************************************************************************** 
USHORT CQMDiskHandler::ObtainFileToWriteBlock() {
#ifdef UNDER_CE	
	CThreadInfo* pThreadInfo = CThreadInfo::GetHandle();
	if(pThreadInfo != NULL)
	{
		//Update the thread counter of diskservices thread 
		pThreadInfo->UpdateThreadCounter(AM_QMDISKSERVICES);
	} 
#endif	
	USHORT fileId = QMC_INVALID_FILE_NUMBER;
	glb_QMHeartBeat = 35;
//  m_PersistedDataFileQ.TraceQueue(L"DATA FILE QUEUE B4", m_pCurrBlKToProcess->blockHeader.QueueId ); 
	// Check whether the File Queue is Empty
	if (QMPDFQ_STATUS_EMPTY == m_PersistedDataFileQ.GetQueueStatus(m_pCurrBlKToProcess->blockHeader.QueueId)) {
		//glb_QMHeartBeat = 36;
		fileId = ObtainFileFromFreeFileQueue();
		//glb_QMHeartBeat = 37;
		/// No files available within the Free File Queue
		if (QMC_INVALID_FILE_NUMBER == fileId) {
			//glb_QMHeartBeat = 38;
			fileId = ObtainFileFromAnotherQueue();
			//glb_QMHeartBeat = 39;
		} // End of IF 
		//Backup FileQueue info to alternate persistent Memory
		CQueueManager *pQMgr = CQueueManager::GetHandle();
		pQMgr->BackupSRAMFileQueues();
	} else {
		//glb_QMHeartBeat = 41;
		// Determine if the Current File is FULL
		T_QMC_DATAFILE_HEADER *m_pTailFile = m_PersistedDataFileQ.GetTailFile(m_pCurrBlKToProcess->blockHeader.QueueId);
		//glb_QMHeartBeat = 42;
		if (NULL != m_pTailFile) {
			//glb_QMHeartBeat = 43;
			// Step 1: Check whether the File is FULL
			if ( TRUE == IsCurrentFileFull(m_pTailFile)) {
				//glb_QMHeartBeat = 44;
				CloseActiveFile(TRUE); //TRUE here to close when full, false to never close
				//glb_QMHeartBeat = 45;
				// Step 2: Check whether the MAX Number of Files 
				// for Queue has been Reached to determine the next Action.
				if (m_PersistedDataFileQ.GetNumOfFilesInQueue(m_pCurrBlKToProcess->blockHeader.QueueId)
						>= m_PersistedDataFileQAccess.GetMaxFiles(m_pCurrBlKToProcess->blockHeader.QueueId))
						{
					//glb_QMHeartBeat = 46;
					fileId = RecycleFileQueue();
					//glb_QMHeartBeat = 47;
				} else {
					//glb_QMHeartBeat = 48;
					// Step 3: Try to obtain a file from the Free File Queue
					fileId = ObtainFileFromFreeFileQueue();
					//glb_QMHeartBeat = 49;
					if (QMC_INVALID_FILE_NUMBER == fileId) {
						//glb_QMHeartBeat = 50;
						//No free files, try and get one from another queue
						fileId = ObtainFileFromAnotherQueue();
						//glb_QMHeartBeat = 51;
						if (QMC_INVALID_FILE_NUMBER == fileId) {
							//glb_QMHeartBeat = 52;
							//no queues are above MAX so recycle
							fileId = RecycleFileQueue();
							//glb_QMHeartBeat = 53;
						}
						//glb_QMHeartBeat = 54;
					}
					//glb_QMHeartBeat = 55;
				} // End of IF
				//glb_QMHeartBeat = 56;
				//Backup FileQueue info to alternate persistent Memory
				CQueueManager *pQMgr = CQueueManager::GetHandle();
				pQMgr->BackupSRAMFileQueues();
			} else {
				fileId = m_pTailFile->fileId;
				//glb_QMHeartBeat = 57;
			} // End of IF
			  //glb_QMHeartBeat = 58;
		} // End of IF
		else {
			//Log Diagnostics message here
		}
		//glb_QMHeartBeat = 59;
	} // End of IF
	glb_QMHeartBeat = 60;
	return (fileId);
} // End of Member Function 
//****************************************************************************
// USHORT RecycleFileQueue()
/// move the oldest data file (head) to the tail to become the newest file
///
/// @param [n/a]
///
/// @return File ID of new tail file or QMC_INVALID_FILE_NUMBER
/// 
//**************************************************************************** 
USHORT CQMDiskHandler::RecycleFileQueue(void) {
	USHORT fileId = QMC_INVALID_FILE_NUMBER;
	const T_QMC_DATAFILE_HEADER *const m_pHeadFile = m_PersistedDataFileQ.GetHeadFile(
			m_pCurrBlKToProcess->blockHeader.QueueId);
	if (NULL != m_pHeadFile) {
		if (QMPDFQ_OK == m_PersistedDataFileQ.removeHeadFile(m_pCurrBlKToProcess->blockHeader.QueueId)) {
			if (QMPDFQ_OK
					== m_PersistedDataFileQ.AddFileToTail(m_pCurrBlKToProcess->blockHeader.QueueId, m_pHeadFile->fileId,
							QMPDFQ_FA_RECYCLED_FILE)) {
				fileId = m_pHeadFile->fileId;
			}
		}
	} // End of IF
	return (fileId);
} // End of Member Function 
//****************************************************************************
// USHORT ObtainFileFromAnotherQueue()
/// cycles through all data queues and gets a file from a queue which is 
/// above it's MAX length
///
/// @param [n/a]
///
/// @return File ID of obtained file or QMC_INVALID_FILE_NUMBER
/// 
//**************************************************************************** 
USHORT CQMDiskHandler::ObtainFileFromAnotherQueue()
{
  USHORT numOfQueuesChecked = QMDSKHAN_OK;
  USHORT fileId     = QMC_INVALID_FILE_NUMBER;
#ifdef UNDER_CE
  CThreadInfo* pThreadInfo = CThreadInfo::GetHandle();
#endif

  do
  {
#ifdef UNDER_CE
    if(pThreadInfo != NULL)
    {
    //Update the thread counter of diskservices thread

    pThreadInfo->UpdateThreadCounter(AM_QMDISKSERVICES);
    }
#endif

    if( QMPDFQ_STATUS_MAX_EXCEEDED == m_PersistedDataFileQ.GetQueueStatus( m_QueueIdToCheckForFile ) )
    {

    const T_QMC_DATAFILE_HEADER * const m_pTailFile =
          m_PersistedDataFileQ.GetTailFile( m_QueueIdToCheckForFile );

    // Check whether the Tail file is being recycled
    if( QMC_DATAFILE_MODE_RECYCLING == m_pTailFile->fileMode )
    {
      // In order to remove the head file from this queue we need to carry out the
      // following steps on the Queue and Tail File.

      // Step 1: Set the Tail File to NORMAL MODE
      m_DataFileAccess.SetFileMode( m_pTailFile->fileId, QMC_DATAFILE_MODE_NORMAL );

      // Step 2: Set the Oldest Block in the File to the First Data Block in the File
      m_DataFileAccess.SetOldestBlockNumber( m_pTailFile->fileId, QMC_FIRST_BLOCK_IN_FILE );

      // Step 3: Set the number of blocks in the file to the same as newest
      m_DataFileAccess.SetNumOfBlocks(m_pTailFile->fileId,m_pTailFile->newestBlockNumber);

      // Step 4: Set the Head of the Queue to pointer to the Tail Next File Id
      m_PersistedDataFileQAccess.SetHead( m_QueueIdToCheckForFile, m_pTailFile->nextFile );

      // Step 5: Set the Tail Next file to indicate End of Queue
      m_DataFileAccess.SetNextFile( m_pTailFile->fileId, QMC_END_OF_QUEUE );
//				qDebug(L"@@@@@@@@@@@@@@@@@@@@@@@@ File %d shoud never attempt to increment\n",m_pTailFile->fileId);

    } // End of IF

    // Remove the Head file from the identified queue that has exceeded its maximum,
    // and insert the removed file back into the Free File Queue for use.
    const T_QMC_DATAFILE_HEADER * const m_pHeadFile =
          m_PersistedDataFileQ.GetHeadFile( m_QueueIdToCheckForFile );

    //close the file if it's open
    if(m_apFiles[m_pHeadFile->fileId].bFileCurrOpen)
    {
      //CloseHandle(m_apFiles[m_pHeadFile->fileId].hFile);
      m_apFiles[m_pHeadFile->fileId].pFile->Close();
      delete m_apFiles[m_pHeadFile->fileId].pFile;
      m_apFiles[m_pHeadFile->fileId].pFile = NULL;
      m_apFiles[m_pHeadFile->fileId].bFileCurrOpen = FALSE;
      m_OpenFileCount--;
    }

    m_PersistedDataFileQ.RemoveHeadFile( m_QueueIdToCheckForFile );
    //reset any transaction pointers on logging queues that may point to this file
    //test for Log or message queue
    if (m_QueueIdToCheckForFile >= MESSAGE_LIST_QUEUE_START_ID)
    {
      // Queue is message queue - normalise the message list and then offset past the pens
      int channel = ( m_QueueIdToCheckForFile - MESSAGE_LIST_QUEUE_START_ID ) + V6_MAX_PENS;
      //m_pLogDeviceStatus->UpdateRecycled(m_QueueIdToCheckForFile - (V6_MAX_PENS * (QMC_PEN_NUM_OF_PEN_QUEUES-1)), m_pHeadFile->fileId, QMC_INVALID_BLOCK_NUMBER);
      m_pLogDeviceStatus->UpdateRecycled(channel, m_pHeadFile->fileId, QMC_INVALID_BLOCK_NUMBER);

    //update the internal trans points as well
    }
    else if (!((m_QueueIdToCheckForFile) % QMC_TOTAL_NO_OF_QUEUES_PER_PEN))
    {
      // this is log data (not chart)
      m_pLogDeviceStatus->UpdateRecycled(m_QueueIdToCheckForFile/QMC_TOTAL_NO_OF_QUEUES_PER_PEN, m_pHeadFile->fileId, QMC_INVALID_BLOCK_NUMBER);
    }
    m_FreeFileQueue.AddFileToTail( m_pHeadFile->fileId, TRUE );


    // Obtain the File from the Free File Queue
    fileId = ObtainFileFromFreeFileQueue();


    } // End of IF

    ++m_QueueIdToCheckForFile;
    ++numOfQueuesChecked;

    if( m_MemoryOpData.GetNumOfQueues() == m_QueueIdToCheckForFile )
    {
    m_QueueIdToCheckForFile = QMDSKHAN_ZERO;

    } // End of IF

  } while( fileId == QMC_INVALID_FILE_NUMBER && numOfQueuesChecked < m_MemoryOpData.GetNumOfQueues() );

  return( fileId );

} // End of Member Function

//****************************************************************************
// USHORT ObtainFileFromFreeFileQueue()
/// gets the head FileID of the free file queue
///
/// @param [n/a]
///
/// @return File ID of obtained file or QMC_INVALID_FILE_NUMBER
///
//****************************************************************************
USHORT CQMDiskHandler::ObtainFileFromFreeFileQueue( void )
{
  USHORT fileId = QMC_INVALID_FILE_NUMBER;

  const T_QMC_DATAFILE_HEADER * const m_pDataFile = m_FreeFileQueue.GetHeadFile();

  if( NULL != m_pDataFile )
  {
    BOOL FileOpened = FALSE;
    if (QMDFQ_OK == m_FreeFileQueue.RemoveHeadFile())
    {
    if(QMDFQ_OK == m_PersistedDataFileQ.AddFileToTail( m_pCurrBlKToProcess->blockHeader.QueueId,
                m_pDataFile->fileId,QMPDFQ_FA_NEW_FILE))
    {
      fileId = m_pDataFile->fileId;
    }
    }
  } // End of IF

  return( fileId );

} // End of Member Function

//****************************************************************************
// BOOL IsCurrentFileFull()
/// Tests if the the given file is full or not
///
/// @param [in] m_pFile - pointer to file header T_QMC_DATAFILE_HEADER
///
/// @return TRUE if full
///
//****************************************************************************
BOOL CQMDiskHandler::IsCurrentFileFull( const T_QMC_DATAFILE_HEADER * const m_pFile )
{
  BOOL fileFullResult = FALSE;  // Indicates whether the File is FULL or NOT

  if( m_pFile->newestBlockNumber >= m_MemoryOpData.GetNumOfDataBlocksPerFile() )
  {
    fileFullResult = TRUE;

  } // End of IF

  return( fileFullResult );

} // End of Member Function

//****************************************************************************
// void OpenFileToWriteBlock()
/// Opens the required file and mark it as active
///
/// @param [in] fileId - Index of the file to be opened
///
/// @return TRUE if Sucessful
///
//****************************************************************************
BOOL CQMDiskHandler::OpenFileToWriteBlock( USHORT fileId )
{
#ifdef UNDER_CE
  CThreadInfo* pThreadInfo = CThreadInfo::GetHandle();

  if(pThreadInfo != NULL)
  {
    //Update the thread counter of diskservices thread

    pThreadInfo->UpdateThreadCounter(AM_QMDISKSERVICES);

  }

#endif

  BOOL fileOpened = TRUE;

  QString filePathAndFileName = "";  // File and Path Name of the Data Block File

  glb_QMHeartBeat = 121;
  CQueueManager *pq_manager = CQueueManager::GetHandle();

  //test that the given file number is valid
  if (QMC_INVALID_FILE_NUMBER != fileId && (TRUE == pq_manager->ValidateFileId(fileId)))
  {
    //check if the file is already open
    if(FALSE == m_apFiles[fileId].bFileCurrOpen)
    {
    //glb_QMHeartBeat = 122;
    if( TRUE == pDALGLB->BuildPath( IDS_INTERNAL_SD, IDS_LOG_DATA, NULL, &filePathAndFileName, MAX_PATH ) )
    {
      //glb_QMHeartBeat = 123;
      //is the currently active file the same as the one that's been supplied
      if( m_OpenFileId != fileId )
      {
        //glb_QMHeartBeat = 124;
        //is there a currently active file
        if( QMC_INVALID_FILE_NUMBER != m_OpenFileId && (TRUE == pq_manager->ValidateFileId(fileId)))
        {
        //glb_QMHeartBeat = 125;
        //DisableActiveFile();
        CloseActiveFile(FALSE);//_TEST TRUE here to always close


        } // End of IF


        //glb_QMHeartBeat = 126;
        // Construct the File Name and Extension for the associated Data Block File
        CQMDataFileAccess::CompleteDataFilePath( filePathAndFileName, MAX_PATH, fileId );	// Complete Path
        CQMDataFileAccess::CompleteDataFileName( filePathAndFileName, MAX_PATH, fileId );	// Complete Name


        //glb_QMHeartBeat = 127;
        // Open the Active File
        if (!m_apFiles[fileId].bFileCurrOpen)
        {
        //glb_QMHeartBeat = 128;

        //added for CStorage
        m_apFiles[fileId].pFile = new CDiskStorage(); //new CStorage;
        //glb_QMHeartBeat = 129;
        fileOpened = m_apFiles[fileId].pFile->Open( filePathAndFileName, CStorage::ReadWrite);
        //temporarily removed for CStorage
//						m_apFiles[fileId].hFile = CreateFile(filePathAndFileName,GENERIC_READ|GENERIC_WRITE,
//							FILE_SHARE_READ,NULL,OPEN_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);//|FILE_FLAG_WRITE_THROUGH

//						if(INVALID_HANDLE_VALUE != m_apFiles[fileId].hFile)
//						{
        //glb_QMHeartBeat = 130;
        if (fileOpened)
        {
          glb_QMHeartBeat = 131;

          m_apFiles[fileId].bFileCreated = TRUE;
          m_apFiles[fileId].bFileCurrOpen = TRUE;

          fileOpened = TRUE;
          m_OpenFileId = fileId;
          m_OpenFileCount++;

          //write the header info and handle errors
          //temporarily removed for CStorage

          //SetFilePointer(m_apFiles[fileId].hFile,0,NULL,FILE_BEGIN);
          //DWORD numWritten = NULL;
          //if (!WriteFile(m_apFiles[fileId].hFile,m_DataFileAccess.GetFileHeader(fileId),sizeof(T_QMC_DATAFILE_HEADER),&numWritten,NULL))
          //{
          //	DWORD err;
          //	err = GetLastError();
          //	QString csErr;

          //	csErr = QString::asprintf("DATABASE FILE ERROR: Q-%d, F-%d, B-%d, Err - %d",
          //		m_pCurrBlKToProcess->blockHeader.QueueId,m_OpenFileId, numWritten, err);

          //	LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_ERROR, csErr );
          //	if (TestMedia())
          //	{
          //		csErr = "File Write Test successful";
          //	}
          //	else
          //	{
          //		csErr = "File Write Test Un-Successful";
          //	}
          //	LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_INFO, csErr );

          //}

          //Temporary CStorage code
          //glb_QMHeartBeat = 132;
          m_apFiles[fileId].pFile->seek(0);
          //glb_QMHeartBeat = 133;
          m_apFiles[fileId].pFile->Write(m_DataFileAccess.GetFileHeader(fileId),sizeof(T_QMC_DATAFILE_HEADER));
          glb_QMHeartBeat = 134;

        }
        else
        {
          glb_QMHeartBeat = 135;
          //log the error
          DWORD err;
          err = GetLastError();
          QString csErr;

          csErr = QString::asprintf("DATABASE FILE CREATE ERROR: Q-%d, F-%d, Err Unknown - %d",
            m_pCurrBlKToProcess->blockHeader.QueueId,fileId, err);

          LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_ERROR, csErr );
          fileOpened = FALSE;

          //glb_QMHeartBeat = 136;
          if (TestMedia())
          {
            glb_QMHeartBeat = 137;
            csErr = "File Write Test successful";
          }
          else
          {
            csErr = "File Write Test Un-Successful";
          }
          LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_INFO, csErr );
          glb_QMHeartBeat = 138;

        }
        }
      } // End of IF
    } // End of IF
    }
    else
    {
    m_OpenFileId = fileId;
    }
  }
  else
  {
    fileOpened = FALSE;
  }

  glb_QMHeartBeat = 140;
  return( fileOpened );

} // End of Member Function

//****************************************************************************
// void CloseActiveFile()
/// Mark the current file as inactive and if required, close it
///
/// @param [in] bClose - Set to TRUE if the current file is to be closed
///
/// @return N/A
///
//****************************************************************************
void CQMDiskHandler::CloseActiveFile(BOOL bClose)
{
  CQueueManager *pq_manager = CQueueManager::GetHandle();

  if( QMC_INVALID_FILE_NUMBER != m_OpenFileId && (TRUE == pq_manager->ValidateFileId(m_OpenFileId))  )
  {

    // Close the File if req'd otherwise just disable it
    if (bClose)
    {
    if ((m_apFiles[m_OpenFileId].bFileCurrOpen) && (m_apFiles[m_OpenFileId].pFile != NULL))
    {
      //CloseHandle(m_apFiles[m_OpenFileId].hFile);
      m_apFiles[m_OpenFileId].pFile->Close();
      delete m_apFiles[m_OpenFileId].pFile;
      m_apFiles[m_OpenFileId].pFile = NULL;
      m_apFiles[m_OpenFileId].bFileCurrOpen = FALSE;
      m_OpenFileCount--;
    }
    else
    {
      V6WarningMessageBox(	NULL, L"CloseActiveFile attempted to close an invalid file", L"CQMDiskHandler Error", MB_OK );

    }

    }
    m_OpenFileId=QMC_INVALID_FILE_NUMBER;

  } // End of IF

} // End of Member Function

//****************************************************************************
// void SeekToReadPosition()
/// Set the file pointer to the appropriate point in the file to perform a
/// last block Read
///
/// @param N/A
///
/// @return N/A
///
//****************************************************************************
void CQMDiskHandler::SeekToProperReadPosition(USHORT QType,USHORT &ReturnValue,UINT8 *ReadBuffer)
{
  WCHAR printMsg[256];
  USHORT i=0;
  const T_QMC_DATAFILE_HEADER * const m_pTailFileHeader =
      m_PersistedDataFileQ.GetTailFile( m_pCurrBlKToProcess->blockHeader.QueueId );
  ReturnValue = 0;
  if(QType ==QMC_QUEUE_PEN_LOG)
  {//If it is Pen data then find last written block
    T_LOGRECORD *pBlockInSD, *pBlockInTemp;
    pBlockInTemp = (T_LOGRECORD *)m_pCurrBlKToProcess->blockData;
    pBlockInSD = (T_LOGRECORD *)ReadBuffer;
    for(i=0;i<m_pTailFileHeader->newestBlockNumber;++i)
    {//Try to find proper position of file where the actual data is written
   //rest og data might not be written during abrupt power failure
    m_apFiles[m_OpenFileId].pFile->Seek((m_pTailFileHeader->newestBlockNumber-i) * QMC_BLOCK_SIZE,FILE_BEGIN);
    //Read the Blocks from SD card
    ReturnValue = m_apFiles[m_OpenFileId].pFile->Read(ReadBuffer,QMC_BLOCK_SIZE);
    if(pBlockInTemp->Header.PenNumber == pBlockInSD->Header.PenNumber)
    {//Found Last written block
      break;
    }
    //Continue to check previous block as the current pointing block is written
    //It could be because the SRAM pointers are moved properly but the actual
    //write to SD card was not complete on Abrupt power supply
    }
    if(i==0)
    {//Everything seems to be fine
    }
    else if(i<m_pTailFileHeader->newestBlockNumber)
    {//reset few blocks
    USHORT NewBlkNum = m_pTailFileHeader->newestBlockNumber - i;
    swprintf( printMsg, 256, L"---Number of Missing blocks = %d for Pen No= %d---\n",i,pBlockInTemp->Header.PenNumber);
    qDebug() << printMsg;;
    //Reset the SRAM counters as blocks were not written to SD card
    m_DataFileAccess.SetNewestBlockNumber(m_OpenFileId,NewBlkNum);
    if (m_MemoryOpData.GetNumOfDataBlocksPerFile() > m_pTailFileHeader->numOfDataBlocks)
    {
      m_DataFileAccess.SetNumOfBlocks(m_OpenFileId,NewBlkNum);
    }
    }
    else
    {//Soemthign wrong with file as Pen number didn't match
    USHORT NewBlkNum = m_pTailFileHeader->newestBlockNumber - i;
    swprintf( printMsg, 256, L"---Problem, could not find proper values in this file\n");
    qDebug() << printMsg;;
    //Reset the SRAM counters as blocks were not written to SD card
    m_DataFileAccess.SetNewestBlockNumber(m_OpenFileId,NewBlkNum);
    if (m_MemoryOpData.GetNumOfDataBlocksPerFile() > m_pTailFileHeader->numOfDataBlocks)
    {
      m_DataFileAccess.SetNumOfBlocks(m_OpenFileId,NewBlkNum);
    }
    }
  }
  else if(QType ==QMC_QUEUE_MESSAGE)
  {//It is message
    MessageRec *pMessageRecSD,*pMessageRecTemp;
    pMessageRecSD = (MessageRec *)ReadBuffer; //This points to Data read from SD card
    pMessageRecTemp = (MessageRec *)m_pCurrBlKToProcess->blockData; //This points data which is there in temporary queue

    for(i=0;i<m_pTailFileHeader->newestBlockNumber;++i)
    {//Try to find proper position of file where the actual data is written
   //rest og data might not be written during abrupt power failure
    m_apFiles[m_OpenFileId].pFile->Seek((m_pTailFileHeader->newestBlockNumber-i) * QMC_BLOCK_SIZE,FILE_BEGIN);
    //Read the Blocks from SD card
    ReturnValue = m_apFiles[m_OpenFileId].pFile->Read(ReadBuffer,QMC_BLOCK_SIZE);
    if(pMessageRecSD->NumMessages > QMDSKHAN_ZERO && pMessageRecSD->NumMessages <= g_MAX_NO_OF_MESSAGES_PER_BLOCK)
    {//Check if the header is proper, if it is proper then return
      break;
    }
    //Continue to check previous block as the current pointing block is written
    //It could be because the SRAM pointers are moved properly but the actual
    //write to SD card was not complete on Abrupt power supply
    }

    if(i==0)
    {//Everything seems to be fine
    }
    else if(i<m_pTailFileHeader->newestBlockNumber)
    {//reset few blocks
    USHORT NewBlkNum = m_pTailFileHeader->newestBlockNumber - i;
    swprintf( printMsg, 256, L"---Number of Missing Msg blocks = %d for Session No= %d ID = %I64u---\n",i,
      pMessageRecTemp->message[pMessageRecTemp->NumMessages-1].usSessionNo,pMessageRecTemp->message[pMessageRecTemp->NumMessages-1].messageId);
    qDebug() << printMsg;;
    //Reset the SRAM counters as blocks were not written to SD card
    m_DataFileAccess.SetNewestBlockNumber(m_OpenFileId,NewBlkNum);
    if (m_MemoryOpData.GetNumOfDataBlocksPerFile() > m_pTailFileHeader->numOfDataBlocks)
    {
      m_DataFileAccess.SetNumOfBlocks(m_OpenFileId,NewBlkNum);
    }
    }
    else
    {//Soemthign wrong with file as Pen number didn't match
    USHORT NewBlkNum = m_pTailFileHeader->newestBlockNumber - i;
    swprintf( printMsg, 256, L"---Problem, could not find proper values in this file\n");
    qDebug() << printMsg;;
    //Reset the SRAM counters as blocks were not written to SD card
    m_DataFileAccess.SetNewestBlockNumber(m_OpenFileId,NewBlkNum);
    if (m_MemoryOpData.GetNumOfDataBlocksPerFile() > m_pTailFileHeader->numOfDataBlocks)
    {
      m_DataFileAccess.SetNumOfBlocks(m_OpenFileId,NewBlkNum);
    }
    }
  }
  else
  {//It is Chart. TBD:: Here logic needs to be added for logic of validating SD card data, similar to Pend Data (in above if)
    m_apFiles[m_OpenFileId].pFile->Seek(m_pTailFileHeader->newestBlockNumber * QMC_BLOCK_SIZE,FILE_BEGIN);
    //Read the Blocks from SD card
    ReturnValue = m_apFiles[m_OpenFileId].pFile->Read(ReadBuffer,QMC_BLOCK_SIZE);
  }
} // End of Member Function

//****************************************************************************
// void SeekToWritePosition()
/// Set the file pointer to the appropriate point in the file to perform a block write
///
/// @param N/A
///
/// @return N/A
///
//****************************************************************************
void CQMDiskHandler::SeekToWritePosition()
{
  //glb_QMHeartBeat = 145;
  if(m_apFiles[m_OpenFileId].pFile != NULL)
  {
    const T_QMC_DATAFILE_HEADER * const m_pTailFileHeader =
        m_PersistedDataFileQ.GetTailFile( m_pCurrBlKToProcess->blockHeader.QueueId );
    //glb_QMHeartBeat = 146;
    // Newest block indicates the current file position, to write the next block the position
    // requires to be increment by one block.  If the block has been successful then the
    // SRAM Header will be updated accordingly.
    USHORT blockToWriteData = m_pTailFileHeader->newestBlockNumber + QMC_ONE_BLOCK;

//		SetFilePointer(m_apFiles[m_OpenFileId].hFile,blockToWriteData * QMC_BLOCK_SIZE,NULL,FILE_BEGIN);
    m_apFiles[m_OpenFileId].pFile->Seek(blockToWriteData * QMC_BLOCK_SIZE,FILE_BEGIN);
    m_NewFileOpened = FALSE;
  } // End of IF

   //glb_QMHeartBeat = 148;

} // End of Member Function

//****************************************************************************
// void WriteBlockToPhysicalDisk()
/// Perform a block write to CF, including a CRC calculate
///
/// @param N/A
///
/// @return BOOL - TRUE if Write Successful
///
//****************************************************************************
BOOL CQMDiskHandler::WriteBlockToPhysicalDisk()
{

  BOOL bSuccess = FALSE;
  // Write the Block to Disk

  DWORD ret = NULL;
  glb_QMHeartBeat = 80;
  if(m_apFiles[m_OpenFileId].pFile != NULL)
  {
    if (m_apFiles[m_OpenFileId].pFile->Write(m_pCurrBlKToProcess->blockData,QMC_BLOCK_SIZE) == ERROR_SUCCESS )
    //if(!WriteFile(m_apFiles[m_OpenFileId].hFile,m_pCurrBlKToProcess->blockData,QMC_BLOCK_SIZE,&ret,NULL))
    //{
    //	DWORD err;
    //	err = GetLastError();
    //	QString csErr;

    //	csErr = QString::asprintf("DATABASE FILE ERROR: Q-%d, F-%d, B-%d, Err Unknown - %d",m_pCurrBlKToProcess->blockHeader.QueueId,
    //		m_OpenFileId, ret, err);

    //	LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_ERROR, csErr );

    //	if (TestMedia())
    //	{
    //		csErr = "File Write Test successful";
    //	}
    //	else
    //	{
    //		csErr = "File Write Test Un-Successful";
    //	}
    //	LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_INFO, csErr );

    //	//try to clear the bug
    //	USHORT fileTmp = m_OpenFileId;
    //	CloseActiveFile(TRUE);
    //	if (OpenFileToWriteBlock(fileTmp))
    //	{
    //		ret = NULL;
    //		if(!WriteFile(m_apFiles[m_OpenFileId].hFile,m_pCurrBlKToProcess->blockData,QMC_BLOCK_SIZE,&ret,NULL))
    //		{
    //			m_pCurrBlKToProcess->blockHeader.blockstatus = QMC_BLKSTATUS_WRITTEN;
    //			bSuccess = TRUE;
    //		}
    //		else
    //		{
    //			csErr = QString::asprintf("DATABASE FILE ERROR: final write attempt failed - %d bytes",ret);
    //			LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_ERROR, csErr );
    //		}

    //	}
    //	else
    //	{
    //		csErr = QString::asprintf("DATABASE FILE ERROR: final write attempt open failed");
    //		LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_ERROR, csErr );
    //	}
    //}
    //else
    {
    m_pCurrBlKToProcess->blockHeader.blockstatus = QMC_BLKSTATUS_WRITTEN;
    bSuccess = TRUE;
    //glb_QMHeartBeat = 81;
    }
  }
  glb_QMHeartBeat = 90;
  return bSuccess;
} // End of Member Function

//****************************************************************************
// void UpdateSRAMFileHeader()
/// Updates the File header stored in SRAM to reflect changes after a physical
/// write to Compact Flash
///
/// @param N/A
///
/// @return N/A
///
//****************************************************************************
void CQMDiskHandler::UpdateSRAMFileHeader()
{
#ifdef UNDER_CE
  CThreadInfo* pThreadInfo = CThreadInfo::GetHandle();

  if(pThreadInfo != NULL)
  {
    //Update the thread counter of diskservices thread

    pThreadInfo->UpdateThreadCounter(AM_QMDISKSERVICES);
  }

#endif
  //
  const T_QMC_DATAFILE_HEADER * const m_pTailFileHeader =
        m_PersistedDataFileQ.GetTailFile( m_pCurrBlKToProcess->blockHeader.QueueId );

  // The associated update will depend on whether the file is recycling or not, determine
  // the file mode.
  if( QMC_DATAFILE_MODE_NORMAL == m_pTailFileHeader->fileMode )
  {
    // Check whether this is the first block written to disk, if so then the oldest block position
    // needs to be updated.
    if( QMDSKHAN_ZERO == m_pTailFileHeader->numOfDataBlocks )
    {
    m_DataFileAccess.SetOldestBlockNumber( m_pTailFileHeader->fileId, QMC_FIRST_BLOCK_IN_FILE );

    } // End of IF

    //if a file goes back to being normal(after a setup change), it would still get it's blocks incremented
    if (m_MemoryOpData.GetNumOfDataBlocksPerFile() > m_pTailFileHeader->numOfDataBlocks)
    m_DataFileAccess.IncNumOfDataBlocks( m_pTailFileHeader->fileId );
    else
    {
    qDebug(L"Attempted to Increment past num of blocks per file %d\n",m_pTailFileHeader->fileId);
    }
    m_DataFileAccess.IncLatestBlockNumber( m_pTailFileHeader->fileId );

  }
  else
  {
    // --- File is Recycling --- //

    //determine if the file being moved is in any of the LogDeviceStatus lists

    //first see if it's a logging queue or message queue
    /// @todo re-instate simpler test once Martin and Jase implement blockType
    //if (QMC_QUEUE_PEN_LOG == m_pCurrBlKToProcess->blockHeader.blockType)//this won't work properly until both charts and logs implement using the block type
    //meantime test the QueueID to be an exact multiple of 4 -1 OR more than number of MAX_PENS * NUM_PEN_QUEUES
    USHORT Chan = 0;
    //if (QMC_QUEUE_MESSAGE == m_pCurrBlKToProcess->blockHeader.blockType)
    if ((m_pCurrBlKToProcess->blockHeader.QueueId >= MESSAGE_LIST_QUEUE_START_ID) &&
    (m_pCurrBlKToProcess->blockHeader.QueueId < ( MESSAGE_LIST_QUEUE_START_ID + MAX_MESSAGE_LISTS )))
    {
    //it's a message queue, normalise the queue id to a channel id
    Chan = ( m_pCurrBlKToProcess->blockHeader.QueueId - MESSAGE_LIST_QUEUE_START_ID ) + V6_MAX_PENS;
    m_pLogDeviceStatus->UpdateRecycled(Chan,m_pTailFileHeader->fileId,m_pTailFileHeader->oldestBlockNumber);
    }
    //if (QMC_QUEUE_PEN_LOG == m_pCurrBlKToProcess->blockHeader.blockType)
    if (((m_pCurrBlKToProcess->blockHeader.QueueId) % QMC_TOTAL_NO_OF_QUEUES_PER_PEN == 0) &&
    (m_pCurrBlKToProcess->blockHeader.QueueId < QMC_TOTAL_NO_OF_PEN_QUEUES))
    {
    //it's a logging queue
    //Chan = (m_pCurrBlKToProcess->blockHeader.QueueId+1) / 4;
    Chan = (m_pCurrBlKToProcess->blockHeader.QueueId) / QMC_TOTAL_NO_OF_QUEUES_PER_PEN;
    //check that this file isn't in one of the device status fields
    m_pLogDeviceStatus->UpdateRecycled(Chan,m_pTailFileHeader->fileId,m_pTailFileHeader->oldestBlockNumber);
    }
    T_QMC_FILE_BLOCK_TRANSACTION * pTrans = NULL;
    BOOL Match = FALSE;
    if(((m_pCurrBlKToProcess->blockHeader.QueueId) % QMC_TOTAL_NO_OF_QUEUES_PER_PEN != 0) &&
    (m_pCurrBlKToProcess->blockHeader.QueueId < QMC_TOTAL_NO_OF_PEN_QUEUES))
    {
    //It's a Chart Queue
    ///@todo - reinstate this code once it can be tested reliably
    //pTrans = m_pFileTransaction->GetFileBlockTransaction(m_pCurrBlKToProcess->blockHeader.QueueId);
    //if((m_pTailFileHeader->fileId == pTrans->fileId) &&
    //	(m_pTailFileHeader->oldestBlockNumber == pTrans->blockId))
    //{
    //	if( m_MemoryOpData.GetNumOfDataBlocksPerFile() == m_pTailFileHeader->oldestBlockNumber )
    //	{
    //		m_pFileTransaction->SetFileBlockTransaction(m_pCurrBlKToProcess->blockHeader.QueueId,
    //			m_pTailFileHeader->nextFile,QMC_START_OF_QUEUE,pTrans->numOfBlocksLastRequested);
    //	}
    //	else
    //	{
    //		m_pFileTransaction->SetFileBlockTransaction(m_pCurrBlKToProcess->blockHeader.QueueId,
    //			pTrans->fileId,pTrans->blockId+1,pTrans->numOfBlocksLastRequested);
    //	}
    //}
    }
    // Increment the Newest Block Position
    m_DataFileAccess.IncLatestBlockNumber( m_pTailFileHeader->fileId );

    if( m_MemoryOpData.GetNumOfDataBlocksPerFile() == m_pTailFileHeader->newestBlockNumber )
    {
    // File is now FULL
    m_DataFileAccess.SetOldestBlockNumber( m_pTailFileHeader->fileId, QMC_FIRST_BLOCK_IN_FILE );
    m_DataFileAccess.SetFileMode( m_pTailFileHeader->fileId, QMC_DATAFILE_MODE_NORMAL );

    // Update the Persisted File Queue back to a normal queue
    m_PersistedDataFileQAccess.SetHead( m_pCurrBlKToProcess->blockHeader.QueueId, m_pTailFileHeader->nextFile );
    m_DataFileAccess.SetPreviousFile(m_pTailFileHeader->nextFile, QMC_START_OF_QUEUE);
    m_DataFileAccess.SetNextFile( m_pTailFileHeader->fileId, QMC_END_OF_QUEUE );

    }
    else
    {
    m_DataFileAccess.IncOldestBlockNumber( m_pTailFileHeader->fileId );

    } // End of IF

  } // End of IF
} // End of Member Function

//****************************************************************************
// void ReleaseBlock()
/// Releases the head block of the To disk Queue back to the Free Block Q
///
/// @param N/A
///
/// @return N/A
///
//****************************************************************************
void CQMDiskHandler::ReleaseBlock()
{
  //WCHAR printMsg[250];
  ///***************************** DEBUGGING CODE FOR Q integrity  only ever of an alpha build ******
#if (INCLUDE_Q_INTEGRITY_CHECK == 1)
  {
    CQueueManager * pQM = CQueueManager::GetHandle();
    if(QMMEMMAN_DATA_INTEGRITY_CHECKS_FAILED == pQM->BlockQueueIntegCheck())
    {
    pDALGLB->BackupSRAMToDiskCopy();
    DebugBreak();
    V6CriticalMessageBox(NULL, L"NV0066.BIN written recorder now stopped", L"Q Integrity failed", MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST );
    }
  }
#endif
  ///***************************** End DEBUGGING CODE FOR Q integrity  only ever of an alpha build ******

  const T_QMC_BLOCK * const pHeadBlock = m_ToDiskBlockQueue.GetHeadBlock();
  T_QMC_QUEUE_TYPE QType = m_PersistedBlkQAccess.GetQueueType(pHeadBlock->blockHeader.QueueId);

  if	(	(QMC_QUEUE_PEN_LOG == QType) ||
    (QMC_QUEUE_MESSAGE == QType) //||
    //(QType >= QMC_QUEUE_PEN_LOG) //For all types
    )
  {//This Logic can be used to control what to be stored in temporary block (which can be recovered later during power cycle, if any data loss)
    WriteBlocksToTempStorage(pHeadBlock->blockHeader.blockId); //Add to Temporary storage
  }
  else
  {
    m_ToDiskBlockQueue.RemoveHeadBlock();
    m_pBlockServices->FreeBlock( pHeadBlock->blockHeader.blockId );
    glb_QMBlockRel++;
  }

  //swprintf( printMsg, 256, L"ReleaseBlock(); BlkID = %d, QID = %d, QType = %d\n",pHeadBlock->blockHeader.blockId,pHeadBlock->blockHeader.QueueId,QType);
  //qDebug() << printMsg;;

} // End of Member Function

//****************************************************************************
// ULONG GetNumBlocksInFileQueue(const USHORT hQueue)
/// Counts the Total number of used blocks in a file queue
///
/// @param[in] hQueue - Queue handle to be checked
///
/// @return Number of blocks in the requested queue
///
//****************************************************************************
ULONG CQMDiskHandler::GetNumBlocksInFileQueue( const USHORT hQueue ) const
{
  return (m_PersistedDataFileQ.GetNumBlocksInFileQueue(hQueue, m_MemoryOpData.GetNumOfDataBlocksPerFile()));
}

//****************************************************************************
// ULONG GetNumBlocksInFileQueueFromPoint(USHORT hQueue, USHORT FileID, USHORT BlockID)
/// Returns the number of blocks in a queue between a given point and the
/// actual head
///
/// @param[in] hQueue - Queue handle to be checked
/// @param[in] FileID - Index of file to check from
/// @param[in] BlockID - Index of block to check from
///
/// @return Number of blocks in the requested queue
///
//****************************************************************************
ULONG CQMDiskHandler::GetNumBlocksInFileQueueFromPoint( const USHORT hQueue, const USHORT FileID, const USHORT BlockID ) const
{
  return (m_PersistedDataFileQ.GetNumBlocksInFileQueueFromPoint(hQueue, m_MemoryOpData.GetNumOfDataBlocksPerFile(),FileID,BlockID));
}

//****************************************************************************
// ULONG GetNumBlocksReservedInFileQueue(const USHORT hQueue)
/// Get the number of blocks in a queue based on the queue's actual number of
/// files and the total number of blocks in those files (including unused blocks)
///
/// @param[in] hQueue - Queue handle to be checked
///
/// @return Number of blocks in the requested queue
///
//****************************************************************************
ULONG CQMDiskHandler::GetNumBlocksReservedInFileQueue( const USHORT hQueue ) const
{
  return (m_PersistedDataFileQ.GetNumBlocksReservedInFileQueue(hQueue, m_MemoryOpData.GetNumOfDataBlocksPerFile()));
}
//****************************************************************************
// T_QMPDFQA_RETURN_VALUE SetMaxFiles(const USHORT hQueue,const USHORT NumFiles)
/// Set the Maximum files a queue is allowed to grow up to
///
/// @param[in] hQueue - Queue handle to be checked
/// @param[in] NumFiles - Maximum files
///
/// @return T_QMPDFQA_RETURN_VALUE
///
//****************************************************************************
T_QMPDFQA_RETURN_VALUE CQMDiskHandler::SetMaxFiles(const USHORT hQueue,const USHORT NumFiles)
{
  return (m_PersistedDataFileQ.SetMaxFiles(hQueue,NumFiles));
}
//****************************************************************************
// ULONG GetMaxNumBlocksInQueue(const USHORT hQueue)
/// Get the number of blocks in a queue based on the queue's Max files
///
/// @param[in] hQueue - Queue handle to be checked
///
/// @return Number of blocks in the requested queue
///
//****************************************************************************
ULONG CQMDiskHandler::GetMaxNumBlocksInQueue(const USHORT hQueue)
{
  return (m_PersistedDataFileQ.GetMaxNumBlocksInQueue(hQueue,m_MemoryOpData.GetNumOfDataBlocksPerFile()));
}
//****************************************************************************
//  BOOL GetNewestBlockAndFile(const USHORT hQueue, USHORT *pFile, USHORT *pBlock)
/// Get the current tail of a disk queue
///
/// @param[in] hQueue - Queue handle to be checked
/// @param[in/out] pFile - USHORT pointer to be filled with File ID
/// @param[in/out] pBlock - USHORT pointer to be filled with Block ID
///
/// @return TRUE if all validation successful
///
//****************************************************************************
BOOL CQMDiskHandler::GetNewestBlockAndFile(const USHORT hQueue, USHORT *pFile, USHORT *pBlock)
{
  if(QMPDFQA_OK == m_PersistedDataFileQAccess.ValidateQueueHandler( hQueue ))
  {
    //find the tail end of the queue
    T_QMC_DATAFILE_HEADER *pHdr;
    pHdr = m_PersistedDataFileQ.GetTailFile(hQueue);
    if (NULL != pHdr)
    {
    *pFile = pHdr->fileId;
    *pBlock = m_DataFileAccess.GetNewestBlockNumber(*pFile);
    return TRUE;
    }
  }

  return FALSE;
}
//****************************************************************************
//  T_QMPBQA_RETURN_VALUE SetFlushToDiskLimit(const USHORT hQueue, const USHORT flushToDiskLimit)
/// Sets the number of blocks for a queue before it will auto flush
///
/// @param[in] hQueue - Queue handle to be checked
/// @param[in] flushToDiskLimit - number of blocks to hold
///
/// @return QMPBQA_QUEUE_NUMBER_INVALID if queue invalid
///
//****************************************************************************
T_QMPBQA_RETURN_VALUE CQMDiskHandler::SetFlushToDiskLimit(const USHORT hQueue, const USHORT flushToDiskLimit)
{
  if(QMPDFQA_OK == m_PersistedDataFileQAccess.ValidateQueueHandler( hQueue ))
    return m_PersistedBlkQAccess.SetFlushToDiskLimit(hQueue,flushToDiskLimit);
  else
    return QMPBQA_QUEUE_NUMBER_INVALID;
}

//****************************************************************************
//  BOOL IsQObjectInToDiskQ(const USHORT hQueue, USHORT* pCount)
/// find if a block from a given queue is waiting in the TDQ
///
///
/// @param[in] hQueue - Queue handle to be checked
/// @param[in/out] pCount - pointer to a USHORT to be filled with a count if required
///
/// @return TRUE if a block of a given queue is in the to disk queue
///
//****************************************************************************
BOOL CQMDiskHandler::IsQObjectInToDiskQ(const USHORT hQueue, USHORT* pCount)
{
  EnterCriticalSection(&m_pBlockServices->m_csBlockServices);
  T_QMC_BLOCK * pBlk = m_ToDiskBlockQueue.GetHeadBlock();
  BOOL BlockFound = FALSE;


  if (NULL != pCount)
    *pCount = 0;
  USHORT nextBlock = 0;
  if(pBlk != NULL)
  {
    USHORT MaxCount = m_ToDiskBlockQueue.GetNumOfBlocksInQueue();
    USHORT Count = 0;
    nextBlock = pBlk->blockHeader.blockId;
    qDebug(L"----------------IsObjectInTDQ pointer 0x%X Max count %d-------------\n",pCount, MaxCount);
#ifdef UNDER_CE
    CThreadInfo* pThreadInfo = CThreadInfo::GetHandle();
#endif
    while((((NULL != pCount) && (nextBlock != QMC_INVALID_BLOCK_NUMBER)) ||
    ((!BlockFound) && (nextBlock != QMC_INVALID_BLOCK_NUMBER))) &&
    Count < MaxCount)
    {

#ifdef UNDER_CE
    if(pThreadInfo != NULL)
    {
      //Update the thread counter of diskservices thread

      pThreadInfo->UpdateThreadCounter(AM_QMDISKSERVICES);

    }
#endif
    qDebug(L"Block %d count %d Queue %d Req Queue %d\n",nextBlock,Count,m_ToDiskBlockQueue.GetBlockQueueID(nextBlock),hQueue);
    Count++;
    if (m_ToDiskBlockQueue.GetBlockQueueID(nextBlock) == hQueue)
    {
      BlockFound = TRUE;
      if (pCount)
        *pCount++;
    }


    nextBlock = m_ToDiskBlockQueue.GetNextBlock(nextBlock);

    }
  }
  LeaveCriticalSection(&m_pBlockServices->m_csBlockServices);
  return BlockFound;
}
//****************************************************************************
//  USHORT GetNumBlocksInToDiskQ(const USHORT hQueue)
/// Gets the number of blocks in the TDQ
///
///
/// @param[in] hQueue - Queue handle to be checked
///
/// @return USHORT - returns the number of blocks currently waiting in the TDQ
///
//****************************************************************************
USHORT CQMDiskHandler::GetNumBlocksInToDiskQ()
{
  return m_ToDiskBlockQueue.GetNumOfBlocksInQueue();
}
//****************************************************************************
//  USHORT GetNumFilesInQueue(const USHORT hQueue)
/// Get the value set MAX for a given Queue
///
///
/// @param[in] hQueue - Queue handle to be checked
///
/// @return USHORT - actual number of files in use by the queue
///
//****************************************************************************
USHORT CQMDiskHandler::GetNumFilesInQueue(const USHORT hQueue)
{
  return m_PersistedDataFileQ.GetNumOfFilesInQueue(hQueue);
}
//****************************************************************************
//  USHORT GetMaxFilesInQueue(const USHORT hQueue)
/// Get the value set MAX for a given Queue
///
///
/// @param[in] hQueue - Queue handle to be checked
///
/// @return USHORT - Maximum files allocated to the queue
///
//****************************************************************************
USHORT CQMDiskHandler::GetMaxFilesInQueue(const USHORT hQueue)
{
  return m_PersistedDataFileQ.GetMaxFiles(hQueue);
}
//****************************************************************************
//  USHORT IsQueueRecycling(const USHORT hQueue)
/// Test to see if a given queue is recycling
///
///
/// @param[in] hQueue - Queue handle to be checked
///
/// @return T_QMC_DATAFILE_MODE - QMC_DATAFILE_MODE_NORMAL or QMC_DATAFILE_MODE_RECYCLING
///
//****************************************************************************
T_QMC_DATAFILE_MODE CQMDiskHandler::IsQueueRecycling(const USHORT hQueue)
{
  const T_QMC_DATAFILE_HEADER * const m_pTailFileHeader =
        m_PersistedDataFileQ.GetTailFile( hQueue );


  return (T_QMC_DATAFILE_MODE)m_pTailFileHeader->fileMode;
}


//****************************************************************************
//  BOOL TestMedia()
/// do a test create and write to a variety of files in the event a file error happens
///
///
/// @param - n/a
///
/// @return BOOL false if any files fail to create
///
//****************************************************************************
BOOL CQMDiskHandler::TestMedia()
{
  BOOL retVal = TRUE;

#ifndef DOCVIEW
#ifndef TTR6SETUP
  QString fileName = "filetest.txt";
  QString filePath="";
  CStorage cFile;
  QString csFile;
  DWORD dwRet = NULL;
  //make a string with the time in it
  QString csTime;
  SYSTEMTIME time;
  GetV6LocalTime(&time);
  csTime = QString::asprintf("Time - %d/%02d/%d %02d:%02d:%02d",time.wDay,time.wMonth,time.wYear,time.wHour,time.wMinute,time.wSecond);
  //first test the internalCF
  HANDLE hFile;
  pDALGLB->BuildPath(IDS_INTERNAL_SD, IDS_ROOT, NULL, &filePath, MAX_PATH);
  //check the filename length
  if (filePath.length()+ fileName.length() < MAX_PATH)
  {
    csFile = filePath;
    csFile += fileName;
    //open the file, always creating a new one, overwriting if necessary
    hFile = CreateFile(csFile.toLocal8Bit().data(),GENERIC_READ|GENERIC_WRITE,
    FILE_SHARE_READ,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
    if (INVALID_HANDLE_VALUE == hFile)
    {
    retVal = FALSE;
    }
    else
    {
    //try to write
    if (!WriteFile(hFile,csTime.toLocal8Bit().data(),csTime.size()*sizeof(WCHAR),&dwRet,NULL))
    {
      retVal = FALSE;
    }
    //No need to close the mutex in Qt;
    }
  }
  //now repeat for external CF
  CMediaManager * pMMan = CMediaManager::GetHandle();
  filePath = "";
  if(pMMan->IsDeviceInserted(IDS_EXTERNAL_SD))
  {
    pDALGLB->BuildPath(IDS_EXTERNAL_SD, IDS_ROOT, NULL, &filePath, MAX_PATH);
    //check the filename length
    if (filePath.length()+fileName.length() < MAX_PATH)
    {
    csFile = filePath;
    csFile += fileName;
    //open the file, always creating a new one, overwriting if necessary
    hFile = CreateFile(csFile.toLocal8Bit().data(),GENERIC_READ|GENERIC_WRITE,
      FILE_SHARE_READ,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
    if (INVALID_HANDLE_VALUE == hFile)
    {
      retVal = FALSE;
    }
    else
    {
      //try to write
      if (!WriteFile(hFile,csTime.toLocal8Bit().data(),csTime.size()*sizeof(WCHAR),&dwRet,NULL))
      {
        retVal = FALSE;
      }
      //No need to close the mutex in Qt;
    }
    }
  }
  //now repeat for Front USB
  filePath = "";
  if(pMMan->IsDeviceInserted(IDS_FIRST_USB))
  {
    pDALGLB->BuildPath(IDS_FIRST_USB, IDS_ROOT, NULL, &filePath, MAX_PATH);
    //check the filename length
    if (filePath.length()+fileName.length() < MAX_PATH)
    {
    csFile = filePath;
    csFile += fileName;
    //open the file, always creating a new one, overwriting if necessary
    hFile = CreateFile(csFile.toLocal8Bit().data(),GENERIC_READ|GENERIC_WRITE,
      FILE_SHARE_READ,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
    if (INVALID_HANDLE_VALUE == hFile)
    {
      retVal = FALSE;
    }
    else
    {
      //try to write
      if (!WriteFile(hFile,csTime.toLocal8Bit().data(),csTime.size()*sizeof(WCHAR),&dwRet,NULL))
      {
        retVal = FALSE;
      }
      //No need to close the mutex in Qt;
    }
    }
  }
#endif
#endif

  return retVal;

}
//****************************************************************************
//  T_QMPDFQA_RETURN_VALUE ClearChartQueues()
/// clear out the files in the chart queues back to the free file queue
///
///
/// @param - n/a
///
/// @return QMPDFQA_ERROR if the blocks cannot be added back to the free file queue
///
//****************************************************************************
T_QMPDFQA_RETURN_VALUE CQMDiskHandler::ClearChartQueues(void)
{
  T_QMPDFQA_RETURN_VALUE ret = QMPDFQA_OK;
  USHORT count;
  USHORT TotPens = V6_MAX_PENS*QMC_TOTAL_NO_OF_QUEUES_PER_PEN;
#ifdef UNDER_CE
  CThreadInfo* pThreadInfo = CThreadInfo::GetHandle();
#endif
  for(int FQIndex=0;FQIndex<=TotPens+CMessageListServices::msqAlarms4Chart;++FQIndex)
  {
#ifdef UNDER_CE
    if(pThreadInfo != NULL)
    {
   //Update the thread counter of diskservices thread

    pThreadInfo->UpdateThreadCounter(AM_QMDISKSERVICES);

    }
#endif
    if ((FQIndex < TotPens && FQIndex%QMC_TOTAL_NO_OF_QUEUES_PER_PEN) || TotPens+CMessageListServices::msqAlarms4Chart == FQIndex )
    {
    T_QMC_DATAFILE_HEADER * pFile = m_PersistedDataFileQ.GetHeadFile(FQIndex);
    if (pFile)
    {
      count = m_PersistedDataFileQ.RemoveAllFiles(FQIndex);
      if(count)
      {
        if (QMDFQ_OK != m_FreeFileQueue.AddLinkedFilesToTail(pFile->fileId,count))
        {
        ret = QMPDFQA_ERROR;
        }
      }
    }
    }
  }
  return ret;
}


//****************************************************************************
// void CloseAllActiveFile()
/// Mark the current file as inactive and if required, close it
///
/// @param [in] bClose - Set to TRUE if the current file is to be closed
///
/// @return N/A
///
//****************************************************************************
void CQMDiskHandler::CloseAllActiveFile(void)
{
  for(int i=0;i<MAX_FILES;++i)
  {

    // Close the File if req'd otherwise just disable it
    if ((m_apFiles[i].bFileCurrOpen) && (m_apFiles[i].pFile != NULL))
    {
    //CloseHandle(m_apFiles[m_OpenFileId].hFile);
    m_apFiles[i].pFile->flush();
    m_apFiles[i].pFile->Close();
    delete m_apFiles[i].pFile;
    m_apFiles[i].pFile = NULL;
    m_apFiles[i].bFileCurrOpen = FALSE;
    m_OpenFileCount--;
    }
  } // End of IF

} // End of Member Function



/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  Queue Manager
/// @n Filename:  QMDiskHandler.h
/// @n Description: Class Declaration for CQMDiskHandler
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  28  Stability Project 1.25.1.1 7/2/2011 5:00:02 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  27  Stability Project 1.25.1.0 7/1/2011 4:27:35 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  26  V6 Firmware 1.25 5/14/2010 5:14:39 PM  Vivek (HAIL)  
//  Wyeth m_freeBlockQueue.GetHead() return a null empty blok error. 
//  Modified mechanism that flushes blocks to physical disk.
//  25  V6 Firmware 1.24 9/14/2006 3:55:34 PM  Alistair Brugsch
//  added in functionality to allow clearing of data from chart queues
// $
//
// **************************************************************************
#ifndef _QMDISKHANDLER_H
#define _QMDISKHANDLER_H
#include "QMBlkQHeaderAccess.h"
#include "QMMemoryBlkAccess.h"
#include "QMMemoryOpDataAccess.h"
#include "QMPersistBlkQAccess.h"
#include "QMBlockQueue.h"
#include "QMPersistDataFileQAccess.h"
#include "QMDataFileAccess.h"
#include "QMPersistDataFileQ.h"
#include "QMDataFileQueue.h"
#include "CStorage.h"
#include "LogDeviceStatus.h"
#include "QMFileBlockTransaction.h"
///< The threshold at which data blocks should be written to disk when periodically checking the to disk queue
const USHORT QMDSKHAN_WRITE_TO_DISK_LIMIT = 10;
///< A secondary threshold used when determining how many blocks should be written to disk when emptying blocks from the to disk queue
const USHORT QMDSKHAN_WRITE_TO_DISK_SECONDARY_LIMIT = 24;
///< A flush all blocks threshold used when determining how many blocks should be written to disk when emptying blocks from the to disk queue
const USHORT QMDSKHAN_WRITE_TO_DISK_FLUSH_ALL_LIMIT = V6_MAX_PENS * 2;
///< The default number of blocks to write to disk when other, flush all, type conditions have not been met
const USHORT QMDSKHAN_DEFAULT_BLOCKS_TO_WRITE = 32;
///< Represents the Value Zero for Defaulting Variables
const USHORT QMDSKHAN_ZERO = 0;
/// Enumeration to describe whether the operation of a Member Function has been
/// completed Successfully or a Failure has occurred. 
typedef enum {
	QMDSKHAN_OK, QMDSKHAN_INITIALISATION_FAILED, QMDSKHAN_ERROR
} T_QMDSKHAN_RETURN_VALUE;
//**Class*********************************************************************
///
/// @brief ---Single line description---.
/// 
/// --- Detailed Description ---
///
//****************************************************************************
class CQMDiskHandler {
public:
	/// Constructor
	CQMDiskHandler(CQMBlkQAccess &toDiskBlkQAccess, CQMBlkQAccess &tempStorageBlkQAccess,
			CQMDataBlkAccess &memoryBlockAccess, const CQMMemoryOpDataAccess &memoryOpDataAccess,
			CQMPersistBlkQAccess &persistedBlkQAccess, CQMPersistDataFileQAccess &persistedDataFileQAccess,
			CQMDataFileAccess &dataFileAccess, CQMDataFileQAccess &freeFileQAccess, T_PQMC_DBFILES pDBFiles);
	/// Destructor
	virtual ~CQMDiskHandler();
	/// Initialise
	T_QMDSKHAN_RETURN_VALUE Initialise(class CQMBlockServices *pBlockServices, CQMFileBlockTransaction *pFileTrans);
	//If there are any blocks which are not completely written into SD card during abrupt power
	//cycle then those blocks written from the temporary storage queue
	USHORT CompareAndFlushLostBlocks(void);
	/// Write the Data Blocks to Physical Disk
	void WriteDataBlocksToPhysicalDisk(const USHORT numOfBlocksToWriteToPhysicalDisk);
	/// Write the Data Blocks to the To Temp Storage Queue 
	T_QMDSKHAN_RETURN_VALUE WriteBlocksToTempStorage(USHORT blockIdx);
	/// Write the Data Blocks to the To Disk Queue 
	T_QMDSKHAN_RETURN_VALUE WriteBlocksToDisk(const USHORT startBlockNumber, const USHORT endBlockNumber,
			const USHORT numOfBlocks);
	/// Set the File Limits for a specified Queue
	T_QMDSKHAN_RETURN_VALUE SetFileLimits(const USHORT fileQueue, const USHORT minFiles, const USHORT maxFiles);
	///Returns the number of blocks used by a Queue
	ULONG GetNumBlocksInFileQueue(const USHORT hQueue) const;
	///Returns the number of blocks used by a Queue
	ULONG GetNumBlocksReservedInFileQueue(const USHORT hQueue) const;
	T_QMPDFQA_RETURN_VALUE SetMaxFiles(const USHORT hQueue, const USHORT NumFiles);
	///Returns the number of blocks used by a Queue from a given point
	ULONG GetNumBlocksInFileQueueFromPoint(const USHORT hQueue, const USHORT FileID, const USHORT BlockID) const;
	///Returns the number of blocks allocated to a queue through it's MAX value
	ULONG GetMaxNumBlocksInQueue(const USHORT hQueue);
	///fills the File and Block arguments with the head file and newest block
	///returns true if sucessful
	BOOL GetNewestBlockAndFile(const USHORT hQueue, USHORT *pFile, USHORT *pBlock);
	///Gets the actual number of files in use by the queue
	USHORT GetNumFilesInQueue(const USHORT hQueue);
	///gets the maximum set for the queue
	USHORT GetMaxFilesInQueue(const USHORT hQueue);
	///queries if the queue is currently recycling
	T_QMC_DATAFILE_MODE IsQueueRecycling(const USHORT hQueue);
	///set the limit of a block queue length before a flush is necessary
	T_QMPBQA_RETURN_VALUE SetFlushToDiskLimit(const USHORT hQueue, const USHORT flushToDiskLimit);
	///determine if a a particular queue has any blocks waiting in the TDQ
	BOOL IsQObjectInToDiskQ(const USHORT hQueue, USHORT *pCount);
	///Gets the count of blocks waiting in the TDQ
	USHORT GetNumBlocksInToDiskQ();
	///Clear the Chart queue data from the file queues and release back to the free queue
	T_QMPDFQA_RETURN_VALUE ClearChartQueues(void);
	//Get the Queue ID for a given Data File
	USHORT GetQueueIDFromFileID(USHORT ID) {
		return m_DataFileAccess.GetQueueId(ID);
	}
	;
	///Accessors to enter and leave the TDQ critical section from external
	void EnterTDQCS(void) {
		m_ToDiskBlockQueue.EnterCS();
	}
	void LeaveTDQCS(void) {
		m_ToDiskBlockQueue.LeaveCS();
	}
	void CloseAllActiveFile(void);
private: // Member Functions
	/// Obtain the File Number to Write the Data Block
	USHORT ObtainFileToWriteBlock();
	/// Open the Data File to Write the Data Block
	BOOL OpenFileToWriteBlock(USHORT fileId);
	/// Seek the Read Position within the File
	void SeekToProperReadPosition(USHORT QType, USHORT &ReturnValue, UINT8 *ReadBuffer);
	/// Seek the Write Position within the File
	void SeekToWritePosition();
	/// Write the Block to Physical Disk
	BOOL WriteBlockToPhysicalDisk();
	/// Update the SRAM File Header
	void UpdateSRAMFileHeader();
	/// Update the File Header
	void UpdateFileHeader();
	/// Release the Data Block to the Free Block Queue
	void ReleaseBlock();
	/// Close the Current File
	void CloseActiveFile(BOOL bClose);
	/// Recycle the File Queue
	USHORT RecycleFileQueue();
	/// Obtain a File from another Queue exceeding its maximum
	USHORT ObtainFileFromAnotherQueue();
	/// Obtain a File from the Free File Queue
	USHORT ObtainFileFromFreeFileQueue();
	/// Check whether the File is Full
	BOOL IsCurrentFileFull(const T_QMC_DATAFILE_HEADER *const m_pFile);
	//Get the next block ID from a given ID
	USHORT GetNextBlockinTDQ(USHORT ID) {
		return m_ToDiskBlockQueue.GetNextBlock(ID);
	}
	//Get the QueueID for a given block
	USHORT GetQueueIDfromTDQBlock(USHORT ID) {
		return m_ToDiskBlockQueue.GetBlockQueueID(ID);
	}
	//test the read/write of the disk system
	BOOL TestMedia();
private: // Member Variables
	CQMBlockQueue m_ToDiskBlockQueue;  ///< To Disk Queue
	CQMBlockQueue m_TempStorageBlockQueue; ///< Temporary Storage Queue
	const CQMMemoryOpDataAccess &m_MemoryOpData;  ///< Memory Operational Data Class 
	CQMPersistBlkQAccess &m_PersistedBlkQAccess;  ///< Allow access to the Persisted Block Queue Header
	class CQMBlockServices *m_pBlockServices;  ///< Pointer to the Block Services
	CQMPersistDataFileQ m_PersistedDataFileQ;  ///< Class to Access the Data File Persisted Queues
	CQMDataFileQueue m_FreeFileQueue;  ///< Free File Queue 
	CQMPersistDataFileQAccess &m_PersistedDataFileQAccess; ///< Access to the Persisted Data File Queues 
	CQMDataFileAccess &m_DataFileAccess;  ///< Access to the Data File Headers
	CStorage m_ActiveFile; ///< File Handler to the Active File 
	USHORT m_OpenFileId;  ///< File Id of the Opened File
	BOOL m_NewFileOpened;  ///< Used to indicate that a new file has been opened
	T_QMC_BLOCK *m_pCurrBlKToProcess;  ///< Pointer to a Data Block
	USHORT m_QueueIdToCheckForFile; ///< Queue Id to check to obtain a file 
	CLogDeviceStatus *m_pLogDeviceStatus; ///< Pointer to LogDeviceStatus class singleton
	T_PQMC_DBFILES m_apFiles;
	HANDLE m_hActiveFileHandle;
	USHORT m_OpenFileCount;
	CQMFileBlockTransaction *m_pFileTransaction;
};
// End of Class Declaration 
#endif //_QMDISKHANDLER_H

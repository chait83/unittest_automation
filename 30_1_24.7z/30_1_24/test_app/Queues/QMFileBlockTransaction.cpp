/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Queue Manager
/// @n Filename:	QMFileBlockTransaction.cpp
/// @n Description: Class Implementation File for CQMFileBlockTransaction
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 9	Stability Project 1.4.1.3	7/2/2011 5:00:03 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 8	Stability Project 1.4.1.2	7/1/2011 4:38:45 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 7	Stability Project 1.4.1.1	3/17/2011 3:20:39 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 6	Stability Project 1.4.1.0	2/15/2011 3:03:47 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
// **************************************************************************
#include "QMFileBlockTransaction.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
//****************************************************************************
/// Constructor
///
/// @param[in] 	numOfQueues	- Number of Persisted Queues Available 
///
/// @return No Return Value
/// 
//****************************************************************************
CQMFileBlockTransaction::CQMFileBlockTransaction(const USHORT numOfQueues) : m_QMFBTRANS_NUM_OF_QUEUES(numOfQueues)
{
	// Do Nothing 
} // End of Constructor
//****************************************************************************
/// Destructor
//****************************************************************************
CQMFileBlockTransaction::~CQMFileBlockTransaction(void) {
	// Clean up Dynamic Memory Allocated within the Class
	delete[] m_pFileBlockTransaction;
	m_pFileBlockTransaction = NULL;
} // End of Destructor
//****************************************************************************
/// Initialise the Class for Operation, creating an array of File / Block 
/// Transactions for the number of Persisted Queues available within the 
/// system. Each File / Block Transaction is then default to known values. 
///
/// @param[in] 	- None
///
/// @return QMFBTRANS_OK					- Initialisation Successful
///		QMFBTRANS_INITIALISATION_FAILED - Initialisation has Failed
/// 
//****************************************************************************
T_QMFBTRANS_RETURN_VALUE CQMFileBlockTransaction::Initialise(void) {
	T_QMFBTRANS_RETURN_VALUE retValue = QMFBTRANS_INITIALISATION_FAILED; // Member Function Return Value
	m_pFileBlockTransaction = new T_QMC_FILE_BLOCK_TRANSACTION[m_QMFBTRANS_NUM_OF_QUEUES];
	if (NULL != m_pFileBlockTransaction) {
		retValue = QMFBTRANS_OK;
	} // End of IF
	for (USHORT queueIndex = QMC_ZERO; queueIndex < m_QMFBTRANS_NUM_OF_QUEUES; queueIndex++) {
		m_pFileBlockTransaction[queueIndex].fileId = QMC_INVALID_FILE_NUMBER;
		m_pFileBlockTransaction[queueIndex].blockId = QMC_INVALID_BLOCK_NUMBER;
		m_pFileBlockTransaction[queueIndex].numOfBlocksLastRequested = QMC_ZERO;
		m_pFileBlockTransaction[queueIndex].recycleState = QMC_TRANS_INITIALISED;
	} // End of FOR
	return (retValue);
} // End of Member Function
//****************************************************************************
/// Obtains the File/Block Transaction for the Specified Queue, the Queue 
/// handle is validated to ensure memory access violations do not exist. 
///
/// @param[in] 	hQueue - Handle to the Queue
///
/// @return T_QMC_FILE_BLOCK_TRANSACTION - Pointer to the Specified Queue File/Block Transaction 
///		NULL						- File / Block Transaction does not exist for the Queue Requested
/// 
//****************************************************************************
T_QMC_FILE_BLOCK_TRANSACTION* const CQMFileBlockTransaction::GetFileBlockTransaction(const USHORT hQueue) {
	T_QMC_FILE_BLOCK_TRANSACTION *pFileBlockTransaction = NULL;
	/// Ensure we have a valid Queue Handler
	if (hQueue < m_QMFBTRANS_NUM_OF_QUEUES) {
		pFileBlockTransaction = &m_pFileBlockTransaction[hQueue];
	} // End of IF
	return (pFileBlockTransaction);
} // End of Member Function
//****************************************************************************
/// Set the File / Block Transaction for a Specified Queue
///
/// @param[in] 	hQueue	- Handle to the Queue
/// @param[in] 	fileId	- File Identification Number
/// @param[in] 	blockId	- Block Identification Number 
/// @param[in] 	numOfBlocks - Number of Blocks
///
/// @return No Return Value
/// 
//****************************************************************************
void CQMFileBlockTransaction::SetFileBlockTransaction(const USHORT hQueue, const USHORT fileId, const USHORT blockId,
		const USHORT numOfBlocks) {
	/// Ensure we have a valid Queue Handler
	if (hQueue < m_QMFBTRANS_NUM_OF_QUEUES) {
		m_pFileBlockTransaction[hQueue].fileId = fileId;
		m_pFileBlockTransaction[hQueue].blockId = blockId;
		m_pFileBlockTransaction[hQueue].numOfBlocksLastRequested = numOfBlocks;
	} // End of IF 
} // End of Member Function 
//****************************************************************************
/// Increment the Block Number by the number of blocks last requested, completing
/// the previous transaction made on the specified queue by the user. 
///
/// @param[in] 	hQueue	- Handle to the Queue
///
/// @return No Return Value
/// 
//****************************************************************************
void CQMFileBlockTransaction::CompleteLastTransaction(const USHORT hQueue) {
	/// Always ensure the Block Id represents the Last Block requested. 
	m_pFileBlockTransaction[hQueue].blockId += m_pFileBlockTransaction[hQueue].numOfBlocksLastRequested;
	m_pFileBlockTransaction[hQueue].numOfBlocksLastRequested = QMC_ZERO;
} // End of Member Function 

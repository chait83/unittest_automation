/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Queue Manager
/// @n Filename:	QMPersistDataFileQAccess.cpp
/// @n Description: Class Implementation File for CQMPersistDataFileQAccess
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 7	Stability Project 1.2.1.3	7/2/2011 5:00:04 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 6	Stability Project 1.2.1.2	7/1/2011 4:38:47 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 5	Stability Project 1.2.1.1	3/17/2011 3:20:39 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 4	Stability Project 1.2.1.0	2/15/2011 3:03:48 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
// **************************************************************************
#include "QMPersistDataFileQAccess.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
//****************************************************************************
/// Constructor
///
/// @param[in] 	pFirstPersistDataFileQ - Pointer to the First Data File Queue in Memory
/// @param[in] maxNumOfFileQueues	- Maximum Number of Data File Queues
///
/// @return No Return Value
/// 
//****************************************************************************
CQMPersistDataFileQAccess::CQMPersistDataFileQAccess(T_QMC_PERSIST_DATAFILE_QUEUE *const pFirstPersistDataFileQ,
		const USHORT maxNumOfFileQueues)
: m_pPersistDataFileQ(pFirstPersistDataFileQ), m_MaxNumOfFileQueues(maxNumOfFileQueues) {
	// Do Nothing 
} // End of Constructor
//****************************************************************************
/// Destructor
//****************************************************************************
CQMPersistDataFileQAccess::~CQMPersistDataFileQAccess(void) {
	// Do Nothing
} // End of Destructor
//****************************************************************************
/// Validate the Persisted Queue Number against the maximum Persisted Queues 
/// Avialable.
///
/// @param[in] 	hQueue - Queue Handler
///
/// @return QMPDFQA_OK						- Queue Handler VALID
///		QMPDFQA_FILE_QUEUE_NUMBER_INVALID - Queue Handler INVALID
/// 
//****************************************************************************
T_QMPDFQA_RETURN_VALUE CQMPersistDataFileQAccess::ValidateQueueHandler(const USHORT hQueue) {
	T_QMPDFQA_RETURN_VALUE retValue = QMPDFQA_OK;
	if (hQueue >= m_MaxNumOfFileQueues) {
		retValue = QMPDFQA_FILE_QUEUE_NUMBER_INVALID;
	} // End of IF
	return (retValue);
} // End of Member Function 

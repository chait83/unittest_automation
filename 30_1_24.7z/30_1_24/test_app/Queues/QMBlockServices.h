/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Queue Manager
/// @n Filename:	QMBlockServices.h
/// @n Description: Class Declaration for CQMBlockServices
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 12	Stability Project 1.9.1.1	7/2/2011 5:00:01 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 11	Stability Project 1.9.1.0	7/1/2011 4:27:34 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 10	V6 Firmware 1.9		5/14/2010 5:13:07 PM	Vivek (HAIL) 
//		Wyeth m_freeBlockQueue.GetHead() return a null empty blok error. 
//		GetFreeBlockQueue gurads m_free by polling free block queue before
//		requesting block from free block queue.
// 9	V6 Firmware 1.8		4/28/2010 1:19:20 PM	Vivek (HAIL)	CR
//		3131: Wyeth m_freeBlockQueue.GetHead() return a null empty blok
//		error.Recover block memory
// $
//
// **************************************************************************
#ifndef _QMBLOCKSERVICES_H
#define _QMBLOCKSERVICES_H
#include "QMCommon.h"
#include "QMPersistBlkQAccess.h"
#include "QMBlkQHeaderAccess.h"
#include "QMMemoryBlkAccess.h"
#include "QMMemoryOpDataAccess.h"
#include "QMBlockQueue.h"
#include "QMPersistDataBlkQ.h"
#include "QMDataBlock.h"
#include <QMutex>
/// Enumeration to describe whether the operation of a Member Function has been
/// completed Successfully or a Failure has occurred. 
typedef enum {
	QMBLKSER_OK,
	QMBLKSER_PERSISTED_QUEUE_NOT_SETUP,
	QMBLKSER_INITIALISATION_FAILED,
	QMBLKSER_NO_DATA_BLOCKS_AVAILABLE,
	QMBLKSER_NO_LAST_DATA_BLOCK,
	QMBLKSER_ERROR
} T_QMBLKSER_RETURN_VALUE;
//**Class*********************************************************************
///
/// @brief This is the Class for the Queue Manager Block Services
/// 
/// The Class provides users with a set of member functions for adding and removing
/// Data Blocks from their Queue. Perisisted Queues are allocated a unique number,
/// this number is the Queue Handle and is used whether users want to carry out an
/// operation on the Persisted Queue. 
///
//****************************************************************************
class CQMBlockServices {
	// Allow the Disk Services to access Private Members
	friend class CQMDiskHandler;
public:
	/// Constructor
	CQMBlockServices(CQMBlkQAccess &freeBlkQAccess, CQMPersistBlkQAccess &persistBlkQAccess,
			CQMDataBlkAccess &memoryBlockAccess, const CQMMemoryOpDataAccess &memoryOpDataAccess);
	/// Destructor
	virtual ~CQMBlockServices(void);
	/// Initialise the Block Services for Use
	T_QMBLKSER_RETURN_VALUE Initialise(class CQMDiskServices *const pDiskServices);
	/// Get a Handle to a specified Queue based on queue type and instance number
	T_QMBLKSER_RETURN_VALUE GetQueue(const T_QMC_QUEUE_TYPE QueueType, const USHORT QueueInstance, USHORT &hQueue);
	/// Setup the Queue for Specific Use
	T_QMBLKSER_RETURN_VALUE SetupQueue(const USHORT hQueue, const T_QMC_QUEUE_TYPE queueType,
			const USHORT flushToDiskLimit, const T_QMC_QUEUE_CONFIRMATION queueConfirmation =
					QMC_CONFIRMATION_NOT_REQUIRED, const USHORT UserStatus = 0xFFFF);
	/// Reset the Queue to Default State, forcing all blocks within the Queue to be written to disk
	T_QMBLKSER_RETURN_VALUE ResetQueue(const USHORT hQueue);
	/// Obtain a Free Data Block for the specified Queue
	T_QMBLKSER_RETURN_VALUE GetFreeDataBlock(const USHORT hQueue, CQMDataBlock &dataBlock);
	/// Obtain the Last Data Block within the specified Queue, if available
	T_QMBLKSER_RETURN_VALUE GetLastDataBlock(const USHORT hQueue, CQMDataBlock &dataBlock);
	/// Flush Available Data Blocks to the To Disk Queue Ready for Disk
	T_QMBLKSER_RETURN_VALUE FlushQDataBlocksReadyForDisk(const USHORT hQueue);
	///Set the User Definable Status for the Queue
	T_QMPBQA_RETURN_VALUE SetUserStatus(const USHORT hQueue, const USHORT UserStatus);
	USHORT GetNoOfBlockinFreeBlockQueue() {
		return m_FreeBlockQueue.GetNumOfBlocksInQueue();
	}
	///Get the User Definable Status for the Queue
	USHORT GetUserStatus(const USHORT hQueue);
	///Clear out chart blocks apart from current working block
	T_QMBLKSER_RETURN_VALUE ClearChartBlocks(void);
	static const int GetPenQueueHandle(int penInstanceNo, T_QMC_QUEUE_TYPE penQueueType);
	/// Shutdown the Queue Manager Block Services
	void Shutdown(void);
	///Accessors to the member critical section
	void EnterCS(void);
	void LeaveCS(void);
private: // --- Member Functions --- //
	/// Called by the Disk Services to Return a Block to the Free Block Queue
	T_QMBLKSER_RETURN_VALUE FreeBlock(const USHORT blockId);
	T_QMBLKSER_RETURN_VALUE ResetChartQueue(int queueHandle);
private: // --- Member Variables --- //
	static QMutex m_csBlockServices;	///< Critical Section for Thread Safe Operation
	CQMBlockQueue m_FreeBlockQueue;			///< Free Block Queue
	CQMPersistDataBlkQ m_PersistDataBlkQ;		///< Persist Data Block Queues
	const CQMMemoryOpDataAccess &m_MemoryOpData; ///< Memory Operational Data Class 
	class CQMDiskServices *m_pDiskServices;	///< Pointer to the Disk Services 
};
// End of Class Declaration
#endif // _QMBLOCKSERVICES_H

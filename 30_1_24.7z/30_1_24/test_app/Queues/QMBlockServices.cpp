/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Queue Manager
/// @n Filename:	QMBlockServices.cpp
/// @n Description: Class Implementation for CQMBlockServices
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 31	Stability Project 1.26.1.3	7/2/2011 5:00:01 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 30	Stability Project 1.26.1.2	7/1/2011 4:38:44 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 29	Stability Project 1.26.1.1	3/17/2011 3:20:37 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 28	Stability Project 1.26.1.0	2/15/2011 3:03:46 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
// **************************************************************************
#include "QMBlockServices.h"
#include "QMDiskServices.h"
#include "V6globals.h"
#include "QueueManager.h"
#include "V6ResourceBase.h"
#include "V6UIResource.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
#ifdef SHOW_CPU
	#include "cpumon.h"
#endif
//****************************************************************************
/// Constructor
///
/// @param[in,out] 	freeBlkQAccess	- Reference to the Free Block Queue Access Class 
/// @param[in,out] persistBlkQAccess - Reference to the Persisted Block Queue Access Class
/// @param[in,out] memoryBlockAccess - Reference to the Memory Block Access Class
/// @param[in]	memoryOpDataAccess - Reference to the Queue Manager Operational Data
///
/// @return No Return Value
/// 
//****************************************************************************
CQMBlockServices::CQMBlockServices(CQMBlkQAccess &freeBlkQAccess, CQMPersistBlkQAccess &persistBlkQAccess,
		CQMDataBlkAccess &memoryBlockAccess, const CQMMemoryOpDataAccess &memoryOpDataAccess) : m_FreeBlockQueue(
		freeBlkQAccess, memoryBlockAccess), m_PersistDataBlkQ(persistBlkQAccess, memoryBlockAccess), m_MemoryOpData(
		memoryOpDataAccess), m_pDiskServices(NULL) {
	// Initialise the Critical Section for Operation	
	QMutex * m_csBlockServices;
} // End of Constructor
//****************************************************************************
/// Destructor
//****************************************************************************
CQMBlockServices::~CQMBlockServices(void) {
	// Cleanup the Critical Section
	//deletion of mutex not required
} // End of Destructor
//****************************************************************************
/// Initialise the Block Services for Operation, the Block Services require
/// a pointer to the Disk Services in order for block to be passed to the 
/// To Disk Queue. Initialisation sets up the Disk Services Pointer. 
///
/// @param[in] pDiskServices - Pointer to the Disk Services 
///
/// @return QMBLKSER_OK					- Block Services Initialised Successfully
///		QMBLKSER_INITIALISATION_FAILED - Block Services Initialisation has FAILED
/// 
//****************************************************************************
T_QMBLKSER_RETURN_VALUE CQMBlockServices::Initialise(CQMDiskServices *const pDiskServices) {
	T_QMBLKSER_RETURN_VALUE retValue = QMBLKSER_INITIALISATION_FAILED; // Member Function Return Value
	if (NULL != pDiskServices) {
		// Initialise the Disk Service Pointer
		m_pDiskServices = pDiskServices;
		retValue = QMBLKSER_OK;
	} // End of IF
	return (retValue);
} // End of Member Function 
//****************************************************************************
/// Shutdown the Block Services, forcing all available Data Blocks ready for 
/// disk, across all Persisted Data Block Queue. 
///
/// @param[in] - None
///
/// @return No Return Value
/// 
//****************************************************************************
void CQMBlockServices::Shutdown(void) {
	for (USHORT queueIndex = QMC_ZERO; queueIndex < m_MemoryOpData.GetNumOfQueues(); queueIndex++) {
		FlushQDataBlocksReadyForDisk(queueIndex);
	} // End of FOR		
} // End of Member Function 
//****************************************************************************
/// Based on the Queue Type and Queue Instance a Queue Handle will be returned,
/// the handle will be required for Persisted Queue Operations.	
///
/// @param[in]	QueueType	- Type of Queue
/// @param[in]	QueueInstance - Instance Number of the Queue
/// @param[in,out] hQueue		- Queue Handle 
///
/// @return QMBLKSER_OK						- Queue Handle has been Obtained 
///		QMBLKSER_PERSISTED_QUEUE_NOT_SETUP - Queue Handle has been Obtained, Queue not Setup 
/// 
//****************************************************************************
T_QMBLKSER_RETURN_VALUE CQMBlockServices::GetQueue(const T_QMC_QUEUE_TYPE QueueType, const USHORT QueueInstance,
		USHORT &hQueue) {
	T_QMBLKSER_RETURN_VALUE retValue = QMBLKSER_OK; // Member Function Return Value
	// Determine the Type of Queue
	if (QMC_QUEUE_MESSAGE == QueueType) {
		// Message Queue Request - located after all the Pen Queues
		hQueue = (m_MemoryOpData.GetMaxNumOfPens() * QMC_TOTAL_NO_OF_QUEUES_PER_PEN);
		hQueue += QueueInstance;
	} else {
		// log, strip or circular chart pen Queue Request
		//hQueue = ( ( QueueInstance * QMC_TOTAL_NO_OF_QUEUES_PER_PEN ) + QueueType );
		hQueue = GetPenQueueHandle(QueueInstance, QueueType);
	} // End of IF
	// Determine whether the Queue has been initialised - this state is maintained over a 
	// power cycle
	if (QMC_BLKQ_STATUS_QUEUE_NOT_SETUP == m_PersistDataBlkQ.GetPersistDataBlkQ(hQueue).Status) {
		retValue = QMBLKSER_PERSISTED_QUEUE_NOT_SETUP;
	} // End of IF
	return (retValue);
} // End of Member Function									
//**********************************************************************
/// Function to calculate the queue handle/index for the specified pen instance and queue type
/// 
/// @param[in] penInstanceNo - The pen instance number
/// @param[in] penQueueType - indicates the queue type
///
/// @return		The queue handle/index 
/// 
//**********************************************************************
const int CQMBlockServices::GetPenQueueHandle(int penInstanceNo, T_QMC_QUEUE_TYPE penQueueType) {
	return (penInstanceNo * QMC_TOTAL_NO_OF_QUEUES_PER_PEN) + penQueueType;
}
//****************************************************************************
/// Based on the Queue Type and Queue Instance a Queue Handle will be returned,
/// the handle will be required for Persisted Queue Operations.	
///
/// @param[in] hQueue			- Handle to the Persisted Queue
/// @param[in] queueType		- Type of Queue required
/// @param[in] flushToDiskLimit - Number of Blocks before flushing to the To Disk Queue
/// @param[in] queueConfirmation - Data Confirmation Required or not
///
/// @return QMBLKSER_OK - Queue has been Setup
/// 
//****************************************************************************
T_QMBLKSER_RETURN_VALUE CQMBlockServices::SetupQueue(const USHORT hQueue, const T_QMC_QUEUE_TYPE queueType,
		const USHORT flushToDiskLimit, const T_QMC_QUEUE_CONFIRMATION queueConfirmation, /* = QMC_CONFIRMATION_NOT_REQUIRED */
		const USHORT UserStatus) {
	T_QMBLKSER_RETURN_VALUE retValue = QMBLKSER_OK;
	// Initialise the Persisted Queue ready for operation
	m_PersistDataBlkQ.SetupQueue(hQueue, queueType, flushToDiskLimit, queueConfirmation, UserStatus);
	return (retValue);
} // End of Member Function									
//****************************************************************************
/// Reset the Queue to Default State, this call will also flush Completed Blocks
/// to the To Disk Queue.	
///
/// @param[in] hQueue - Handle to the Persisted Queue
///
/// @return QMBLKSER_OK - Queue has been Reset
/// 
/// @note Please ensure the Last Block has been completed before calling reset. 
///
//****************************************************************************
T_QMBLKSER_RETURN_VALUE CQMBlockServices::ResetQueue(const USHORT hQueue) {
	T_QMBLKSER_RETURN_VALUE retValue = QMBLKSER_OK;
	// Flush the Blocks within the Queue to the To Disk Queue 
	FlushQDataBlocksReadyForDisk(hQueue);
	// Reset the Queue to Default State 
	m_PersistDataBlkQ.ResetQueue(hQueue);
	return (retValue);
} // End of Member Function									
//****************************************************************************
/// Obtains a Data Block from the Free Data Block Queue, and adds the Block to
/// the Persisted Data Block Queue. A Data Block Class passed in is populated 
/// to point to the Memory Block Obtained. Each Persisted Queue has a flush to disk
/// limit, once the Persisted Queue reaches this limit, the Data Blocks are transfered
/// to the To Disk Queue where they are written to Physical Disk. 
///
/// @param[in]	hQueue	- Handle to the Persisted Queue
/// @param[in,out] dataBlock - Data Block for the User to populate
///
/// @return QMBLKSER_OK - Queue has been Reset
/// 
/// @note Before obtaining a Data Block the previous data block( if any ) should be set
///	to COMPLETED. 
///
/// @todo JU: Determine whether the call should be blocked until a Data Block is
///		available if the Free Data Block Queue is empty. 
///
//****************************************************************************
T_QMBLKSER_RETURN_VALUE CQMBlockServices::GetFreeDataBlock(const USHORT hQueue, CQMDataBlock &dataBlock) {
	///***************************** DEBUGGING CODE FOR Q integrity only ever of an alpha build ******
#if (INCLUDE_Q_INTEGRITY_CHECK == 1)
	{	
		CQueueManager * pQM = CQueueManager::GetHandle();
		if(QMMEMMAN_DATA_INTEGRITY_CHECKS_FAILED == pQM->BlockQueueIntegCheck())
		{
			qDebug("Integ check failed - called by Queue Handle %d",hQueue);
			pDALGLB->BackupSRAMToDiskCopy();
			V6CriticalMessageBox(NULL, L"NV0066.BIN written recorder now stopped", L"Q Integrity failed", MB_OK | MB_ICONEXCLAMATION | MB_TOPMOST );
		}
	}
#endif
	///***************************** End DEBUGGING CODE FOR Q integrity only ever of an alpha build ******
	T_QMBLKSER_RETURN_VALUE retValue = QMBLKSER_NO_DATA_BLOCKS_AVAILABLE; // Member Function Return Value
	// Step 1: Determine whether the Queue needs to be Flushed to Disk
	if (QMPDBQ_STATUS_FLUSH_TO_DISK_REQUIRED == m_PersistDataBlkQ.GetQueueStatus(hQueue)) {
		retValue = FlushQDataBlocksReadyForDisk(hQueue);
	} // End of IF
	else {
		retValue = QMBLKSER_OK;
	}
	// if successful
	if (retValue == QMBLKSER_OK) {
		// Wait a total of 2 seconds
		const int QFREE_BLOCK_RETRY = 20;
		const int QFREE_BlOCK_RETRY_TIMEOUT = 100;
		unsigned short l_NoOfFreeBlocks = 0;
		//m_csBlockServices.lock();
		l_NoOfFreeBlocks = m_FreeBlockQueue.GetNumOfBlocksInQueue();
		//m_csBlockServices.unlock();
		// Check there are no blocks available before proceeding
		if (l_NoOfFreeBlocks <= 0) {
//#ifdef SHOW_CPU
//		float cpuUsage = GetCurrentCPUUtilization();
//					QString  csTxt2 ;
//					csTxt2 = QString::asprintf("CPU: %.02f%s", cpuUsage,L"%");
//					LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_INFO, csTxt2);
//#endif
			// There are no blocks available, we need to wait for the Data Writer to return blocks to the free queue.
			int iCount = 0;
			// Make sure there is at least 2 free blocks in the queue, enough to satisfy block 
			// request and possible block request by logging diagnostic message
			while (l_NoOfFreeBlocks <= 1 && iCount++ < QFREE_BLOCK_RETRY) {
				sleep(QFREE_BlOCK_RETRY_TIMEOUT);
				//m_csBlockServices.lock();
				l_NoOfFreeBlocks = m_FreeBlockQueue.GetNumOfBlocksInQueue();
				//m_csBlockServices.unlock();
			}
			// Check that we have enough blocks to safely log the diagnostic message, and log the message
			if (l_NoOfFreeBlocks > 1) {
//#ifdef SHOW_CPU
//		float cpuUsage = GetCurrentCPUUtilization();
//					QString  csTxt2 ;
//					csTxt2 = QString::asprintf("CPU: %.02f%s", cpuUsage,L"%");
//					LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_INFO, csTxt2);
//#endif
				QString strTempMsg("");
				strTempMsg = QWidget::tr("Recover low block memory");
				LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, strTempMsg);
			}
		}
		//moved as this is now called in Flush as well
		m_csBlockServices.lock();
		// Step 2: Obtain a Block from the Free Block Queue
		T_QMC_BLOCK *const pDataBlock = m_FreeBlockQueue.GetHeadBlock();
		if (NULL != pDataBlock) {
			// no need to check return as always set to okay
			m_PersistDataBlkQ.SetStatusNewBlk(hQueue);
			CDataItem *pDI = pGlbDIT->GetDataItemPtr(DI_GENERAL, DI_GENTYPE_GENERAL, DI_GEN_QUEUE_FREEBLOCK);
			if (NULL != pDI) {
				pDI->SetValue(m_FreeBlockQueue.GetPercentageOfFreeBlocks());
				//			if(m_FreeBlockQueue.GetPercentageOfFreeBlocks() < 5)
				//				DebugBreak();
			} else {
				// data item pointer is NULL
				QString strError("");
				strError = QString::asprintf("DI_GEN_QUEUE_FREEBLOCK data item is NULL");
				BlockServicesError(strError);
			}
			// Remove the Obtained Block from the Free Block Queue
    if (m_FreeBlockQueue.RemoveHeadBlock() == QMBQ_NO_BLOCKS_TO_REMOVE) {
//#ifdef SHOW_CPU
//				float cpuUsage = GetCurrentCPUUtilization();
//					QString  csTxt2 ;
//					csTxt2 = QString::asprintf("CPU: %.02f%s", cpuUsage,L"%");
//					LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_INFO, csTxt2);
//#endif
				QString strError("");
				strError = QString::asprintf(
						"m_FreeBlockQueue.removeHeadBlock() method failed as no more blocks to remove");
				BlockServicesError(strError);
			}
			// Add the Allocated Block to the Persisted Block Queue	
			const T_QMPDBQ_QUEUE_STATUS persistRetVal = m_PersistDataBlkQ.AddBlockToTail(hQueue,
					pDataBlock->blockHeader.blockId);
			if (QMPDBQ_STATUS_EMPTY == persistRetVal) {
				QString strError("");
				strError = QString::asprintf("m_PersistDataBlkQ.AddBlockToTail method failed, error code: %u",
						persistRetVal);
				BlockServicesError(strError);
				retValue = QMBLKSER_NO_DATA_BLOCKS_AVAILABLE;
			} else {
				m_PersistDataBlkQ.SetStatusClear(hQueue); //normal operation for queue
				retValue = QMBLKSER_OK;
			}
		} // End of IF
		else {
			QString strError("");
			strError = QString::asprintf("m_FreeBlockQueue.GetHeadBlock() returned a NULL empty block");
			//LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_ERROR, strError);
			BlockServicesError(strError);
		}
		//clear the data
		memset(pDataBlock->blockData, NULL, QMC_BLOCK_SIZE);
		// Set the Pointer for the Data Block Passed into the Member Function
		dataBlock.SetDataBlock(pDataBlock);
		dataBlock.SetBlockStatus(QMC_BLKSTATUS_IN_USE);
		m_csBlockServices.lock();
	} else {
		QString strError("");
		strError = QString::asprintf("FlushQDataBlocksReadyForDisk method failed, error code: %u", retValue);
		BlockServicesError(strError);
	}
	return (retValue);
} // End of Member Function									
//****************************************************************************
/// Obtain the Last Data Block within the Persisted Data Block Queue. This call
/// should always be made on Startup, as the Persisted Queues are maintained over 
/// a Power Cycle. The Last Block either needs to be Completed or continued to be 
/// used for adding data until the Block is Full. The Data Block Class will contain 
/// a NULL Pointer if the Last Block does not exist.	
///
/// @param[in]	hQueue	- Handle to the Persisted Queue
/// @param[in,out] dataBlock - Last Data Block
///
/// @return QMBLKSER_OK				- Last Data Block has been obtained
///		QMBLKSER_NO_LAST_DATA_BLOCK - No Last Data Block Available
/// 
//****************************************************************************
T_QMBLKSER_RETURN_VALUE CQMBlockServices::GetLastDataBlock(const USHORT hQueue, CQMDataBlock &dataBlock) {
	T_QMBLKSER_RETURN_VALUE retValue = QMBLKSER_OK; // Member Function Return Value
	// Set the Data Block Pointer of the class passed in, to pointer to either the Last Data Block, or 
	// NULL if no block is available.	
	dataBlock.SetDataBlock(m_PersistDataBlkQ.GetTailBlock(hQueue));
	if (NULL == m_PersistDataBlkQ.GetTailBlock(hQueue)) {
		retValue = QMBLKSER_NO_LAST_DATA_BLOCK;
	} // End of IF
	return (retValue);
} // End of Member Function									
//****************************************************************************
/// Flush the Persisted Block Queue to the To Disk Queue ready to be written 
/// to Physical Disk. The number of blocks to flush to the To Disk queue is 
/// determined by whether the Last Block in the Queue has been completed. If
/// the Last Block in the Queue is set to Completed, then the entire queue will
/// be flush to the To Disk Queue. Otherwise the Queue minus the Last Block will 
/// be flushed to the To Disk Queue. 
///
/// @param[in] hQueue - Handle to the Persisted Queue
///
/// @return QMBLKSER_OK - Flush to the To Disk Queue Successful
/// 
//****************************************************************************
T_QMBLKSER_RETURN_VALUE CQMBlockServices::FlushQDataBlocksReadyForDisk(const USHORT hQueue) {
	T_QMBLKSER_RETURN_VALUE retValue = QMBLKSER_OK;
	BOOL writeToDiskRequired = TRUE;
	m_csBlockServices.lock();
	if (QMPDBQ_STATUS_EMPTY != m_PersistDataBlkQ.GetQueueStatus(hQueue)) {
		// Pointer to the Head Block
		const T_QMC_BLOCK *const pHeadBlock = m_PersistDataBlkQ.GetHeadBlock(hQueue);
		// Pointer to the Tail Block
		const T_QMC_BLOCK *const pTailBlock = m_PersistDataBlkQ.GetTailBlock(hQueue);
		// NULL Pointer check for safety
		if (NULL != pHeadBlock && NULL != pTailBlock) {
			// Number of Blocks to Write
			USHORT numOfBlocksToWriteToQueue = m_PersistDataBlkQ.GetNumOfBlocksInQueue(hQueue);
			// Last Block Id to be written
			USHORT endBlockIdToWrite = pTailBlock->blockHeader.blockId;
			// Check if the last block within the Queue is Completed
			if (QMC_BLKSTATUS_COMPLETE != pTailBlock->blockHeader.blockstatus) {
				// Last Block in the Queue has not been completed, therefore the we can only flush
				// up to the Last Block. 
				--numOfBlocksToWriteToQueue;
				// Ensure that at least one block is available
				if (QMC_ZERO == numOfBlocksToWriteToQueue) {
					writeToDiskRequired = FALSE;
				} else {
					// Set the End Block Id to the last but one data block
					endBlockIdToWrite = m_PersistDataBlkQ.GetBlockIdFromQueuePos(hQueue, numOfBlocksToWriteToQueue);
				} // End of IF
			} // End of IF
			if ( TRUE == writeToDiskRequired) {
				T_QMDSKSER_RETURN_VALUE diskReturnValue = QMDSKSER_OK;
				m_PersistDataBlkQ.SetStatusLinkdTDQ(hQueue);
				diskReturnValue = m_pDiskServices->WriteBlocksToDisk(pHeadBlock->blockHeader.blockId, endBlockIdToWrite,
						numOfBlocksToWriteToQueue);
				if (QMDSKSER_OK == diskReturnValue) {
					m_PersistDataBlkQ.SetStatusRemBlks(hQueue);
					// Remove the Required Data Blocks from the Persisted Data Block Queue
					if (numOfBlocksToWriteToQueue == m_PersistDataBlkQ.GetNumOfBlocksInQueue(hQueue)) {
        m_PersistDataBlkQ.RemoveAllBlocks(hQueue, QMPDBQ_ALL);
					} else {
        m_PersistDataBlkQ.RemoveAllBlocks(hQueue, QMPDBQ_EXCLUDING_TAIL);
					} // End of IF
				} // End of IF
				else {
					retValue = QMBLKSER_ERROR;
				}
				m_PersistDataBlkQ.SetStatusClear(hQueue);
				// m_PersistDataBlkQ.TraceQueue( L"AFTER FLUSH", hQueue );				
			} // End of IF
		} // End of IF
	} // End of IF 
	m_csBlockServices.lock();
	return (retValue);
} // End of Member Function	
//****************************************************************************
/// This member function will be called by the Disk Services to add a block
/// written to disk back to the Free Block Queue. This call is thread safe,
/// to ensure that when we add a block, another thread is not obtianing a block. 
/// 
/// @param[in] blockId - Block Identification Number for the Block to Add
///
/// @return QMBLKSER_OK - Block Added to the Free Block Queue
/// 
/// @note Thread Safe by using Critical Section 
///
//****************************************************************************
T_QMBLKSER_RETURN_VALUE CQMBlockServices::FreeBlock(const USHORT blockId) {
	T_QMBLKSER_RETURN_VALUE retValue = QMBLKSER_OK; // Member Function Return Value
	m_csBlockServices.lock();
	// Add the Block to the Free Block Queue
	m_FreeBlockQueue.AddBlockToTail(blockId);
	CDataItem *pDI = pGlbDIT->GetDataItemPtr(DI_GENERAL, DI_GENTYPE_GENERAL, DI_GEN_QUEUE_FREEBLOCK);
	if (NULL != pDI) {
		pDI->SetValue(m_FreeBlockQueue.GetPercentageOfFreeBlocks());
	}
	m_csBlockServices.lock();
	return (retValue);
} // End of Member Function
//****************************************************************************
/// Set the value in the user definable block of the queue header.
/// Setup Queue will default the value to FFFF
///
/// @param[in]	hQueue	- Handle to the Persisted Queue
/// @param[in]	UserStatus - Value to be set
///
/// @return	QMPBQA_OK	- Value has been set
///			QMPBQA_QUEUE_NUMBER_INVALID - Invalid Queue number
/// 
//****************************************************************************
T_QMPBQA_RETURN_VALUE CQMBlockServices::SetUserStatus(const USHORT hQueue, const USHORT UserStatus) {
	return (m_PersistDataBlkQ.SetUserStatus(hQueue, UserStatus));
}
//****************************************************************************
/// Get the value in the user definable block of the queue header.
/// Setup Queue will default the value to FFFF
///
/// @param[in]	hQueue	- Handle to the Persisted Queue
///
/// @return				- Requested Value
/// 
//****************************************************************************
USHORT CQMBlockServices::GetUserStatus(const USHORT hQueue) {
	return (m_PersistDataBlkQ.GetUserStatus(hQueue));
}
//****************************************************************************
/// Accessor for an external class to use the critical section of the TDQ
///
/// @param	n/a
///
/// @return	n/a
/// 
//****************************************************************************
void CQMBlockServices::EnterCS(void) {
	m_csBlockServices.lock();
}
//****************************************************************************
/// Accessor for an external class to use the critical section of the TDQ
///
/// @param	n/a
///
/// @return	n/a
/// 
//****************************************************************************
void CQMBlockServices::LeaveCS(void) {
	m_csBlockServices.lock();
}
//****************************************************************************
/// ResetChartQueue - reset the chart queue blocks
///
/// @param	int queueHandle - the queue handle
///
/// @return	QMBLKSER_OK	- blocks have been cleared and released back to free queue
///			QMBLKSER_ERROR - failed
/// 
//****************************************************************************
T_QMBLKSER_RETURN_VALUE CQMBlockServices::ResetChartQueue(int queueHandle) {
	T_QMBLKSER_RETURN_VALUE ret = QMBLKSER_ERROR;
	USHORT first, second, num = 0;
	T_QMC_BLOCK *pBl;
	m_csBlockServices.lock();
	num = m_PersistDataBlkQ.GetNumOfBlocksInQueue(queueHandle);
	if (num > 1) {
		pBl = m_PersistDataBlkQ.GetHeadBlock(queueHandle);
		first = pBl->blockHeader.blockId;
		second = first;
		USHORT NumCpy = num;
		while (--NumCpy > 1) {
			second = pBl->blockHeader.nextBlock;
			pBl = m_PersistDataBlkQ.GetBlock(second);
		}
    if (QMPDBQ_OK == m_PersistDataBlkQ.RemoveAllBlocks(queueHandle, QMPDBQ_EXCLUDING_TAIL)
				&& QMBQ_OK == m_FreeBlockQueue.AddLinkedBlocksToTail(first, second, num - 1)) {
			ret = QMBLKSER_OK;
		}
	}
	m_csBlockServices.lock();
	return ret;
}
//****************************************************************************
/// ClearChartBlocks - clear the blocks in all the queues associated with charts
///
/// @param	n/a
///
/// @return	QMBLKSER_OK	- blocks have been cleared and released back to free queue
///			QMBLKSER_ERROR - failed
/// 
//****************************************************************************
T_QMBLKSER_RETURN_VALUE CQMBlockServices::ClearChartBlocks() {
	T_QMBLKSER_RETURN_VALUE ret = QMBLKSER_ERROR;
	const int ALARMS_4_CHART_QUEUE_HANDLE = QMC_TOTAL_NO_OF_PEN_QUEUES + CMessageListServices::msqAlarms4Chart;
	// reset all the pen chart queues and the alarms for chart message list - leave the pen log
	// queues and other message lists alone
	for (int queueHandle = 0; queueHandle <= QMC_TOTAL_NO_OF_PEN_QUEUES + CMessageListServices::msqAlarms4Chart;
			++queueHandle) {
		// reset the chart queues or alarm 4 chart message, but not the log queues and other message lists
		if (((queueHandle < QMC_TOTAL_NO_OF_PEN_QUEUES) && (queueHandle % QMC_TOTAL_NO_OF_QUEUES_PER_PEN))
				|| (ALARMS_4_CHART_QUEUE_HANDLE == queueHandle)) {
			// technically if the return value is not ok then this loop should stop - however,
			// outside the scope of this work so last working as it does now
			ret = ResetChartQueue(queueHandle);
		}
	}
	return ret;
}

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Queue Manager
/// @n Filename:	QMPersistBlkQAccess.cpp
/// @n Description: Implementation File for the class CQMPersistBlkQAccess
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 6	Stability Project 1.1.1.3	7/2/2011 5:00:04 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 5	Stability Project 1.1.1.2	7/1/2011 4:38:46 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 4	Stability Project 1.1.1.1	3/17/2011 3:20:39 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 3	Stability Project 1.1.1.0	2/15/2011 3:03:48 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
// **************************************************************************
#include "QMPersistBlkQAccess.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//****************************************************************************
/// Constructor
///
/// @param[in] 	pFirstPersistDataBlkQ - Pointer to the First data Block 
/// @param[in] maxNumOfQueues	- Maximum Number of queues
///
/// @return No Return Value
/// 
//****************************************************************************
CQMPersistBlkQAccess::CQMPersistBlkQAccess(T_QMC_PERSIST_DATA_BLKQ *const pFirstPersistDataBlkQ,
		const USHORT maxNumOfQueues)
: m_pPersistDataBlkQ(pFirstPersistDataBlkQ), m_MaxNumOfQueues(maxNumOfQueues) {
}
//****************************************************************************
/// Destructor
//****************************************************************************
CQMPersistBlkQAccess::~CQMPersistBlkQAccess(void) {
}
//****************************************************************************
/// ValidatePersistedQueueHandler - validates the queue ID is in the correct range
///
/// @param[in] 	persistedQueueHandler - Queue Number to Validate
///
/// @return QMPBQA_OK				- Queue Number is VALID
///		QMPBQA_QUEUE_NUMBER_INVALID - Queue Number is INVALID			
/// 
//****************************************************************************
T_QMPBQA_RETURN_VALUE CQMPersistBlkQAccess::ValidatePersistedQueueHandler(const USHORT persistedQueueHandler) {
	T_QMPBQA_RETURN_VALUE retValue = QMPBQA_OK;
	if (persistedQueueHandler >= m_MaxNumOfQueues) {
		retValue = QMPBQA_QUEUE_NUMBER_INVALID;
	} // End of IF
	return (retValue);
} // End of Member Function

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  Queue Manager
/// @n Filename:  QMBlockQueue.h
/// @n Description: Class Declaration File for the class CQMBlockQueue
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  7 Stability Project 1.4.1.1 7/2/2011 5:00:01 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  6 Stability Project 1.4.1.0 7/1/2011 4:27:34 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  5 V6 Firmware 1.4 3/15/2006 9:49:05 PM  Alistair Brugsch
//  Added accessors to use the Critical section for the To disk Queue
//  4 V6 Firmware 1.3 11/17/2005 4:24:50 PM  Alistair Brugsch
//  Added functionality to test if a block of a given Queue is waiting in
//  the To Disk Queue
// $
//
// **************************************************************************
#ifndef _QMBLOCKQUEUE_H
#define _QMBLOCKQUEUE_H
#include "QMCommon.h"
#include "QMBlkQHeaderAccess.h"
#include "QMMemoryBlkAccess.h"
/// Enumeration to describe whether the operation of a Member Function has been
/// completed Successfully or a Failure has occurred. 
typedef enum {
	QMBQ_OK, QMBQ_ERROR, QMBQ_NO_BLOCK_AVAILABLE, QMBQ_BLOCK_AVAILABLE, QMBQ_NO_BLOCKS_TO_REMOVE
} T_QMBQ_RETURN_VALUE;
/// Enumeration to indicate the Status of the Block Queue
typedef enum {
	QMBQ_STATUS_EMPTY, QMBQ_STATUS_SPACE_AVAILABLE, QMBQ_STATUS_FULL
} T_QMBQ_QUEUE_STATUS;
//**Class*********************************************************************
///
/// @brief Block Queue Linked List
/// 
/// This class provides the linked list operations for insert and removing 
/// data blocks into a Queue. This class is used for the Free Block Queue, and
/// To Disk Queue. 
///
/// @note This Class is Thread Safe using a Critical Section
///
//****************************************************************************
class CQMBlockQueue {
public:
	/// Constructor
	CQMBlockQueue(CQMBlkQAccess &blockQueue, CQMDataBlkAccess &memoryBlockAccess);
	/// Destructor  
	virtual ~CQMBlockQueue(void);
	/// Add a Memory Block to the End( Tail ) of the Queue
	T_QMBQ_RETURN_VALUE AddBlockToTail(const USHORT blockNumber);
	/// Obtain a Pointer to the Current( Head ) Available Block in the Queue
	T_QMC_BLOCK* const GetHeadBlock(void);
	/// Remove the Current( Head ) Available Block from the Queue
	T_QMBQ_RETURN_VALUE RemoveHeadBlock(void);
	/// Remove the Current( Head ) Available Block from the Queue, but do not modify the block
	T_QMBQ_RETURN_VALUE RemoveHeadBlockNoModify(void);
	/// Obtain the Status of the Block Queue
	T_QMBQ_QUEUE_STATUS GetQueueStatus(void);
	/// Get Percentage of Number of Blocks Available
	FLOAT GetPercentageOfFreeBlocks(void) const;
	/// Obtain the Number of Blocks currently within the Block Queue
	USHORT GetNumOfBlocksInQueue(void) const {
		return (m_BlockQueue.GetNumOfBlocksInQueue());
	}
	/// Add Linked Blocks to the Queue
	T_QMBQ_RETURN_VALUE AddLinkedBlocksToTail(const USHORT startBlockNumber, const USHORT endBlockNumber,
			const USHORT numOfBlocks);
	//get the ID of the next block from a given block
	USHORT GetNextBlock(USHORT BlockID) {
		return (m_MemoryBlockAccess.GetNextBlock(BlockID));
	}
	//Get the Queue ID for a given Block
	USHORT GetBlockQueueID(USHORT BlockID) {
		return (m_MemoryBlockAccess.GetQueueId(BlockID));
	}
	/// Obtain the Block Queue Header 
	// const T_QMC_BLOCK_QUEUE& GetBlockQueueHeader( void ); 
	/// Display the Queue using the Trace Window - for DEBUG PURPOSES ONLY
	void TraceQueue(const QString pName);
	//Accessors to enter and leave Crititcal sections externally
	void EnterCS(void) {
		m_csBlockQueue.lock();
	}
	void LeaveCS(void) {
		m_csBlockQueue.lock();
	}
private: // -- Member Variables -- //
	QMutex m_csBlockQueue; ///< Critical Section for Thread Safe Operation
	CQMBlkQAccess &m_BlockQueue; ///< Block Queue Interface Class
	CQMDataBlkAccess &m_MemoryBlockAccess;  ///< Member Variable to gain access to the Memory Blocks
};
// End of Class Declaration
/// Get Percentage of the Number of Free Block Available
inline FLOAT CQMBlockQueue::GetPercentageOfFreeBlocks(void) const {
	FLOAT freeBlocks = static_cast<FLOAT>(m_BlockQueue.GetNumOfBlocksInQueue())
			/ m_MemoryBlockAccess.GetMaxNumOfBlocks();
	return (freeBlocks * 100.0F);
} // End of Member Function
#endif // _QMBLOCKQUEUE_H

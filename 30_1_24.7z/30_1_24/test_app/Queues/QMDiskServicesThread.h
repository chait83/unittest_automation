/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	--- Add Module Name ---
/// @n Filename:	--- Add Filename ---
/// @n Description: --- Add File Description ---
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 3	Stability Project 1.0.1.1	7/2/2011 5:00:03 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 2	Stability Project 1.0.1.0	7/1/2011 4:27:35 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 1	V6 Firmware 1.0		6/21/2005 3:44:16 PM	Alistair Brugsch 
// $
//
// **************************************************************************
#ifndef _QMDISKSERVICESTHREAD_H
#define _QMDISKSERVICESTHREAD_H
#include <QThread>
#include "Defines.h"
//**Class*********************************************************************
///
/// @brief ---Single line description---.
/// 
/// --- Detailed Description ---
///
//****************************************************************************
class CQMDiskServicesThread: public QThread {
	// DECLARE_DYNCREATE (CQMDiskServicesThread)
protected:
	/// Constructor
	CQMDiskServicesThread(); // protected constructor used by dynamic creation
	/// Destructor
	virtual ~CQMDiskServicesThread();
public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	/// 
	static UINT ThreadFunc(LPVOID lpParam);
protected:
};
// End of Class Declaration
#endif // _QMDISKSERVICESTHREAD_H

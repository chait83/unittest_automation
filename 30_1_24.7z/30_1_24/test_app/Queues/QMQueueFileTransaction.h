/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Queue Manager
/// @n Filename:	QMQueueFileStatus.h
/// @n Description: Class Declaration File for the class CQMQueueFileTransaction
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 3	Stability Project 1.0.1.1	7/2/2011 5:00:05 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 2	Stability Project 1.0.1.0	7/1/2011 4:27:37 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 1	V6 Firmware 1.0		6/22/2005 8:43:35 PM	Alistair Brugsch 
// $
//
// **************************************************************************
#ifndef _QMQUEUEFILETRANSACTION_H
#define _QMQUEUEFILETRANSACTION_H
#include "Defines.h"
typedef enum _eQMFileTransactionAvailable {
	QUEFILETTR_TRANSACTION_AVAILABLE, QUEFILETTR_TRANSACTION_NOT_AVAILABLE
} T_QUEFILETTR_TRANSACTION_AVIALABLE;
//**Class*********************************************************************
///
/// @brief ---Single line description---.
/// 
/// --- Detailed Description ---
///
//****************************************************************************
class CQMQueueFileTransaction {
public:
	/// Constructor
	CQMQueueFileTransaction();
	/// Destructor
	virtual ~CQMQueueFileTransaction(void);
	/// Set File Transaction Information
	void SetFileTransactionInfo(const USHORT fileId, const USHORT blockId, const USHORT numOfBlocks);
	/// Set Complete Last Transaction
	void CompleteLastTransaction(void);
	/// Get File Identification Number
	USHORT GetFileId(void) const {
		return (m_FileId);
	}
	/// Get the Block Identification Number of the Block to Start From
	USHORT GetFromBlockId(void) const {
		return (m_BlockId);
	}
	/// Get the Number of Blocks obtained within the Last Transaction
	USHORT GetNumOfBlocksOfLastTransaction(void) const {
		return (m_NumOfBlocksOfLastTransaction);
	}
private:
	USHORT m_NumOfBlocksOfLastTransaction; ///< Number of Blocks Obtained from the Last Transaction
	USHORT m_FileId;						///< File Identification Number
	USHORT m_BlockId;					///< Block Identification Number 
	T_QUEFILETTR_TRANSACTION_AVIALABLE m_TransactionAvailable; ///< Indication to whether a transaction is available
};
// End of Class Declaration
#endif // _QMQUEUEFILESTATUS_H

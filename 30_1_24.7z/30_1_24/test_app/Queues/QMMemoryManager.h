/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Queue Manager 
/// @n Filename:	QMMemoryManager.h"
/// @n Description: Class Declaration for CQMHardwareManager
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 6	Stability Project 1.3.1.1	7/2/2011 5:00:03 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 5	Stability Project 1.3.1.0	7/1/2011 4:27:36 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 4	V6 Firmware 1.3		3/15/2006 5:32:28 PM	Alistair Brugsch
//		added wrapper to call Data Block Integrity check
// 3	V6 Firmware 1.2		11/8/2005 5:17:27 PM	Alistair Brugsch
//		Added DelTree method, use it to clear out the data directory if a
//		file size change is detected.
//		
//		added startup reporting information
// $
//
// **************************************************************************
#ifndef _QMHARDWAREMANAGER_H
#define _QMHARDWAREMANAGER_H
#include "QMCommon.h"
#include "QMPersistBlkQAccess.h"
#include "QMBlkQHeaderAccess.h"
#include "QMMemoryBlkAccess.h"
#include "QMMemoryOpDataAccess.h"
#include "QMDataFileAccess.h"
#include "QMDataFileQAccess.h"
#include "QMPersistDataFileQAccess.h"
#include "QMPersistDataFileQ.h"
#include "QMDataIntegrity.h"
#include "flash.h"
/// Enumeration to describe whether the operation of a Member Function has been
/// completed Successfully or a Failure has occurred. 
typedef enum {
	QMMEMMAN_OK,
	QMMEMMAN_ERROR,
	QMMEMMAN_NULL_POINTER,
	QMMEMMAN_INSUFFICENT_MEMORY,
	QMMEMMAN_UPDATE_MEMORY_SIZE,
	QMMEMMAN_SYSTEM_INFO_CHANGED_ERROR,
	QMMEMMAN_DATA_INTEGRITY_CHECKS_FAILED
} T_QMMEMMAN_RETURN_VALUE;
typedef enum {
	QMMEMMAN_DEF_RESET = 0, QMMEMMAN_BLK_RESET, QMMEMMAN_FULL_RESET
} T_QMMEMMAN_RESETVAL;
const USHORT MAX_FILE_BLOCK_SIZE = 40000;
//**Class*********************************************************************
///
/// @brief Initialises the Hardware Layer for the Queue Manager
/// 
/// --- Detailed Description ---
///
//****************************************************************************
class CQMHardwareManager {
public:
	/// Constructor
	CQMHardwareManager(void);
	/// Destructor
	virtual ~CQMHardwareManager(void);
	/// Initialise the Queue Manager Memory
	T_QMMEMMAN_RETURN_VALUE Initialise(const T_QMC_INITIALISATION_TYPE initialisationType, BYTE *const pBasePointer,
			const T_QMC_SYSTEM_INFO &systemInfo);
	/// Undertake Data Integrity Test on the Queue Manager Memory
	T_QMMEMMAN_RETURN_VALUE PerformDataIntegrityTests(const T_QMC_SYSTEM_INFO &systemInfo);
	/// Get the Free Block Queue Interface Class
	CQMBlkQAccess& GetFreeBlkQAccess(void) {
		return (*m_pFreeBlkQ);
	}
	/// Get the Temporary Stored Block Queue Interface Class
	CQMBlkQAccess& GetTempStoredBlkQAccess(void) {
		return (*m_pTempStoredBlkQ);
	}
	/// Get the To Disk Queue Interface Class
	CQMBlkQAccess& GetToDiskBlkQAccess(void) {
		return (*m_pToDiskQ);
	}
	/// Get the Memory Block Interface Class, for accessing specific memory blocks		
	CQMDataBlkAccess& GetDataBlkAccess(void) {
		return (*m_pMemoryBlkAccess);
	}
	/// Get the Persist Block Queue Interface Class for accessing a specific Persist Block Queue
	CQMPersistBlkQAccess& GetPersistBlkQAccess(void) {
		return (*m_pPersistBlkQAccess);
	}
	/// Get the Memory Operational Data Interface Class for accessing operational data within memory	
	CQMMemoryOpDataAccess& GetMemoryOpDataAccess(void) {
		return (*m_pMemoryOpDataAccess);
	}
	/// 
	CQMDataFileAccess& GetDataFileAccess(void) {
		return (*m_pDataFileAccess);
	}
	///
	CQMDataFileQAccess& GetFreeFileAccess(void) {
		return (*m_pFreeFileQ);
	}
	///
	CQMPersistDataFileQAccess& GetPersistDataFileQAccess(void) {
		return (*m_pPersistDataFileQAccess);
	}
	/// Undertake Data Integrity Test on the Block Queues
	T_QMMEMMAN_RETURN_VALUE PerformBlockIntegrityTests(void);
	///Write(backup)file data containing in SRAM to flash
	void BackUpFileQueueHeaders(void);
	///Read file data in flash to update SRAM
	BOOL RestoreFileQueueHeaders(void);
private:
	// --- Private Member Functions --- //
	/// Initialise the Queue Manager Memory to Default
	T_QMMEMMAN_RETURN_VALUE DefaultInitialisation(const T_QMC_SYSTEM_INFO &sysInfo);
	/// Initialise the Queue Manager Memory for Normal Operation
	T_QMMEMMAN_RETURN_VALUE NormalInitialisation(const T_QMC_SYSTEM_INFO &systemInfo);
	/// Initialise Free Block Queue Header to Default
	void InitialiseFreeBlockHeader(void);
	/// Initialise Temporary Stored Block Queue Header to Default
	void InitialiseTempStoredBlockHeader(void);
	/// Initialise To Disk Queue Header to Default
	void InitialiseToDiskQueueHeader(void);
	// Initialise File Available Queue to Default
	void InitialiseFileAvailableQueue(void);
	/// Initialise Persisted Block Queue Headers to Default
	void InitialisePersistedBlockQueueHeaders(void);
	/// Initialise Persisted File Queue Header to Default
	void InitialisePersistedFileQueueHeaders(void);
	/// Initialise Block Headers to Default - Set Block Id
	void InitialiseBlockHeaders(void);
	/// Initialise File Headers to Default - Set File Id
	void InitialiseFileHeaders(void);
	/// Create Default Files
	void CreateBlockFiles(void);
	/// Validate the System Information to ensure Queue Manager can operate correctly
	T_QMMEMMAN_RETURN_VALUE ValidateSystemInfo(const T_QMC_SYSTEM_INFO &sysInfo);
	/// Calculate the Minimum Memory Requirements for the Queue Manager to operate	
	ULONG CalculateMinMemoryRequirements(const T_QMC_SYSTEM_INFO &sysInfo);
	/// Initialise the Memory Operational Data
	T_QMMEMMAN_RETURN_VALUE InitialiseMemoryOpData(const T_QMC_SYSTEM_INFO &sysInfo);
	/// Calculate the Amount of Memory in Bytes available for Data Blocks
	ULONG CalculateMemoryForBlocks(void);
	/// Calculate and Initialise the Memory Pointers
	T_QMMEMMAN_RETURN_VALUE CalculateAndInitialisePointers(void);
	/// Initialise the interface classes to be used by the service layer of the Queue Manager
	T_QMMEMMAN_RETURN_VALUE CreateInterfaceClasses(void);
	///delete a directory and all sub items
	void DelTree(QString path);
	// --- Private Member Variables --- //	
	BYTE *m_pBasePointer;	///< Pointer to the start of the Memory to be used
	T_QMC_DATA *m_pMemoryOpData;		///< Memory Operational Data
	T_QMC_BLOCK_QUEUE *m_pFreeBlockQueue; ///< Pointer to the Free Block Queue Header
	T_QMC_BLOCK_QUEUE *m_pTempStoredBlockQueue; ///< Pointer to the Temporary Stored Block Queue Header
	T_QMC_BLOCK_QUEUE *m_pToDiskQueue;	///< Pointer to the To Disk Queue Header
	T_QMC_BLOCK *m_pBlock;		///< Pointer to the FIRST Data Block in Memory
	T_QMC_DATAFILE_QUEUE *m_pFileAvailableQueue;		///< Pointer to the File Available Queue Header
	T_QMC_PERSIST_DATA_BLKQ *m_pPersistDataBlockQueue; ///< Pointer to the FIRST Persisted Data Block Queue Header in Memory
	T_QMC_PERSIST_DATAFILE_QUEUE *m_pPersistDataFileQueue; ///< Pointer to the FIRST Persisted Data File Queue Header in Memory
	T_QMC_DATAFILE_HEADER *m_pFileHeader; ///< Pointer to the FIRST File Header in Memory
	CQMBlkQAccess *m_pFreeBlkQ;	///< Free Block Queue Hardware Interface Class
	CQMBlkQAccess *m_pTempStoredBlkQ;	///< Temporary Stored Block Queue Hardware Interface Class
	CQMBlkQAccess *m_pToDiskQ;		///< To Disk Queue Hardware Interface Class
	CQMDataBlkAccess *m_pMemoryBlkAccess;		///< Memory Block Hardware Interface Class
	CQMPersistBlkQAccess *m_pPersistBlkQAccess; ///< Persisted Block Queues Hardware Interface Class
	CQMMemoryOpDataAccess *m_pMemoryOpDataAccess; ///< Memory Operational Data Hardware Interface Class
	CQMDataFileAccess *m_pDataFileAccess; ///< Data File Hardware Interface Class
	CQMDataFileQAccess *m_pFreeFileQ;	///< Free File Hardware Interface Class 
	CQMPersistDataFileQAccess *m_pPersistDataFileQAccess;	///< Persisted File Queues Hardware Interface Class
	CQMDataIntegrity m_DataIntegrity;	/// Class which contains the Data Integrity Checks 
	T_QMMEMMAN_RESETVAL m_eSpReset;
	CFlashManager *pFlash;
#ifdef DBG_FILE_LOG_QUEUEMM_ENABLE
	static CDebugFileLogger m_debugFileLogger;
#endif
};
// End of Class Declaration 
#endif // _QMMEMORYMANAGER_H

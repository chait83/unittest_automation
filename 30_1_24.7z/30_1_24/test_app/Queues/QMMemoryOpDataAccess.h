/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Queue Manager
/// @n Filename:	QMMemoryOpDataAccess.h
/// @n Description: Class Declaration File for CQMMemoryOpDataAccess
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 4	Stability Project 1.1.1.1	7/2/2011 5:00:04 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 3	Stability Project 1.1.1.0	7/1/2011 4:27:36 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 2	V6 Firmware 1.1		7/22/2005 4:11:15 PM	Alistair Brugsch
//		Added Doxygen Comments
// 1	V6 Firmware 1.0		6/21/2005 3:44:16 PM	Alistair Brugsch 
// $
//
// **************************************************************************
#ifndef _QMMEMORYOPDATAACCESS_H
#define _QMMEMORYOPDATAACCESS_H
#include "QMCommon.h"
/// Enumeration to describe whether the operation of a Member Function has been
/// completed Successfully or a Failure has occurred. 
typedef enum {
	QMMOPDA_OK, QMMOPDA_ERROR
} T_QMMOPDA_RETURN_VALUE;
//**Class*********************************************************************
///
/// @brief Class for setting and getting the Queue Manager Operational Data
/// 
/// This Class provides Member Functions for Getting the Queue Manager 
/// Operational Data. The Operational Data is key data that is used
/// to create and allow the Queue Manager to Operate Correctly. The Class 
/// Member Functions have been made Inline for speed and efficiency.	
///
//****************************************************************************
class CQMMemoryOpDataAccess {
public:
	/// Constructor
	CQMMemoryOpDataAccess(const T_QMC_DATA &memoryOpData);
	/// Destructor
	virtual ~CQMMemoryOpDataAccess(void);
	/// Get the Max Number of Available Pens
	USHORT GetMaxNumOfPens(void) const;
	/// Get the Number of Queues Per Pen
	USHORT GetNumOfQueuesPerPen(void) const;
	/// Get the Number of Available Data Blocks
	USHORT GetNumOfDataBlocks(void) const;
	/// Get the Number of Available Queues
	USHORT GetNumOfQueues(void) const;
	/// Get the Number of Data Blocks Allocated to a File
	USHORT GetNumOfDataBlocksPerFile(void) const;
	/// Get the Number of Allocated Data Files
	USHORT GetNumOfDataFiles(void) const;
private:
	const T_QMC_DATA &m_MemoryOpData; ///< Reference to the Memory Operational Data
};
// End of Class Declaration
//****************************************************************************
/// Get the Max Number of Available Pens Available
///
/// @param[in] - None
///
/// @return Maximum Number of Pens Available
/// 
//****************************************************************************
inline USHORT CQMMemoryOpDataAccess::GetMaxNumOfPens(void) const {
	return (m_MemoryOpData.systemInfo.maxNumOfPens);
} // End of Member Function
//****************************************************************************
/// Get the Number of Data Blocks Available
///
/// @param[in] - None
///
/// @return Number of Data Blocks Available
/// 
//****************************************************************************
inline USHORT CQMMemoryOpDataAccess::GetNumOfDataBlocks(void) const {
	return (m_MemoryOpData.numOfBlocks);
} // End of Member Function
//****************************************************************************
/// Get the Number of Queues Available
///
/// @param[in] - None
///
/// @return Number of Queues Available
/// 
//**************************************************************************** 
inline USHORT CQMMemoryOpDataAccess::GetNumOfQueues(void) const {
	return (m_MemoryOpData.numOfQueues);
} // End of Member Function
//****************************************************************************
/// Get the Number of Data Blocks Per File
///
/// @param[in] - None
///
/// @return Number of Data Blocks Per File
/// 
//**************************************************************************** 
inline USHORT CQMMemoryOpDataAccess::GetNumOfDataBlocksPerFile(void) const {
	return (m_MemoryOpData.numOfDataBlocksPerFile);
} // End of Member Function
//****************************************************************************
/// Get the Number of Data Files Available
///
/// @param[in] - None
///
/// @return Number of Data Files
/// 
//**************************************************************************** 
inline USHORT CQMMemoryOpDataAccess::GetNumOfDataFiles(void) const {
	return (m_MemoryOpData.numOfFiles);
} // End of Member Function
#endif // _QMMEMORYOPDATAACCESS_H

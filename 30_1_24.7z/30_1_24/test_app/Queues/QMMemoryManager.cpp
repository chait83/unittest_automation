/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Queue Manager
/// @n Filename:	QMMemoryManager.h
/// @n Description: Memory management for NV queue system
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 39	Stability Project 1.34.1.3	7/2/2011 5:00:03 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 38	Stability Project 1.34.1.2	7/1/2011 4:38:46 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 37	Stability Project 1.34.1.1	3/17/2011 3:20:39 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 36	Stability Project 1.34.1.0	2/15/2011 3:03:47 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
// **************************************************************************
#include "QMMemoryManager.h"
#include "TraceDefines.h"
#include <wchar.h>
#include "V6globals.h"
#include "CStorage.h"
#include "TVtime.h"
#include <QDirIterator>
#ifdef DBG_FILE_LOG_QUEUEMM_ENABLE
	CDebugFileLogger CQMHardwareManager::m_debugFileLogger(L"\\SDMemory\\QMmemmgr.txt", FALSE, (10*1024*1024));
#endif
//*************************************************************************************************
/// CQMHardwareManager Constructor
/// 
//*************************************************************************************************
CQMHardwareManager::CQMHardwareManager(void) {
	// Initalise All Member Variables to Default State
	m_pBasePointer = NULL;
	m_pMemoryOpData = NULL;
	m_pFreeBlockQueue = NULL;
	m_pTempStoredBlockQueue = NULL;
	m_pToDiskQueue = NULL;
	m_pBlock = NULL;
	m_pFileAvailableQueue = NULL;
	m_pPersistDataBlockQueue = NULL;
	m_pPersistDataFileQueue = NULL;
	m_pFileHeader = NULL;
	m_pFreeBlkQ = NULL;
	m_pTempStoredBlkQ = NULL;
	m_pToDiskQ = NULL;
	m_pMemoryBlkAccess = NULL;
	m_pPersistBlkQAccess = NULL;
	m_pMemoryOpDataAccess = NULL;
	m_pDataFileAccess = NULL;
	m_pFreeFileQ = NULL;
	m_pPersistDataFileQAccess = NULL;
	m_eSpReset = QMMEMMAN_DEF_RESET;
}
//*************************************************************************************************
/// CQMHardwareManager destructor
/// 
//*************************************************************************************************
CQMHardwareManager::~CQMHardwareManager(void) {
	// Cleanup all dynamically Allocated Memory
	delete (m_pFreeBlkQ);
	m_pFreeBlkQ = NULL;
	delete (m_pTempStoredBlkQ);
	m_pTempStoredBlkQ = NULL;
	delete (m_pToDiskQ);
	m_pToDiskQ = NULL;
	delete (m_pMemoryBlkAccess);
	m_pMemoryBlkAccess = NULL;
	delete (m_pPersistBlkQAccess);
	m_pPersistBlkQAccess = NULL;
	delete (m_pMemoryOpDataAccess);
	m_pMemoryOpDataAccess = NULL;
	delete (m_pDataFileAccess);
	m_pDataFileAccess = NULL;
	delete (m_pFreeFileQ);
	m_pFreeFileQ = NULL;
	delete (m_pPersistDataFileQAccess);
	m_pPersistDataFileQAccess = NULL;
}
//*************************************************************************************************
/// Initialise the Queue Manager Memory
///
/// @param[in] 	initialisationType - type of initialisation QMC_DEFAULT_INIT or QMC_NORMAL_INIT
/// @param[in] pBasePointer - ptr to SRAM area to use
/// @param[in] systemInfo - system information to determine if changes have been made
///
/// @return T_QMMEMMAN_RETURN_VALUE as result
/// 
//*************************************************************************************************
T_QMMEMMAN_RETURN_VALUE CQMHardwareManager::Initialise(const T_QMC_INITIALISATION_TYPE initialisationType,
		BYTE *const pBasePointer, const T_QMC_SYSTEM_INFO &systemInfo) {
	T_QMMEMMAN_RETURN_VALUE retValue = QMMEMMAN_NULL_POINTER;
	WCHAR printMsg[512];
	pFlash = CFlashManager::GetHandle();
	// Ensure the Pointer to the memory to use is Valid 
	if (NULL != pBasePointer) {
		m_pBasePointer = pBasePointer;
		// Setup the Memory Data Pointer as this is critical to the operation of the Queue Manager
		m_pMemoryOpData = (T_QMC_DATA*) m_pBasePointer;
		QString csTxt;
		// Check to ensure the memory supplied is large enough to meet the minimum requirements
		if (systemInfo.lengthOfMemoryInBytes >= CalculateMinMemoryRequirements(systemInfo)) {
			//test the integrity of the data log file structure
            QString blockDataPathName="";		// Data File Path
            QString fileDataPathName="";
			WIN32_FIND_DATA indexOfData;
			WIN32_FIND_DATA FileindexOfData;
			HANDLE hindexOf;
			HANDLE hFileindexOf;
			int indexOfCount = 0;
			DWORD FileSize = 0;
			// Build the Persisted Setup Configuration Path and File Name
            pDALGLB->BuildPath(IDS_INTERNAL_SD, IDS_LOG_DATA, NULL, &blockDataPathName,
			MAX_PATH);
			//determine the Directory name of the first data dir
            fileDataPathName = blockDataPathName;
            blockDataPathName = QString::asprintf("%s%S%c", blockDataPathName.toLocal8Bit().data(),
					DATA_BLOCK_SUBDIR_PREFIX, '*');		// Complete Path
			//find the dirs
            QDirIterator it(blockDataPathName, QStringList() << "", QDir::NoFilter, QDirIterator::Subdirectories);
            QString file_name="";
            if (it.hasNext()) {
				BOOL Found = TRUE;
                file_name = it.next();
				//test file size is correct
				//find the first file to get its size
                fileDataPathName = QString::asprintf("%s%s%s", fileDataPathName.toLocal8Bit().data(),
                        file_name.toLocal8Bit().data(), "/data*.blk");
                QDirIterator it_n(blockDataPathName, QStringList() << "", QDir::NoFilter, QDirIterator::Subdirectories);
                if (it_n.hasNext()) {
                    file_name = it_n.next();
                    QFile  h_file(file_name);
                    FileSize = h_file.size();
				}
				if ((FileSize != 0) && (FileSize != systemInfo.fileSizeInBytes)) {
					csTxt = QWidget::tr("Re-Initializing Data Directory - Please Wait...");
					pGlbSysInfo->SetStartupSubAction(csTxt);
					//revert back to the original path
                    pDALGLB->BuildPath(IDS_INTERNAL_SD, IDS_LOG_DATA, NULL, &blockDataPathName,
					MAX_PATH);
					//delete the database
					DelTree(blockDataPathName);
				} else {
					while (Found) {
						indexOfCount++;
                        /// TODO:
						Found = CStorage::indexOfNextFile(hindexOf, &indexOfData);
					}
				}
				
			}
			//qDebug("Initialise :: initialisationType : %d ,indexOfCount :%d ,QMMEMMAN_OK :%d\n ",QMC_NORMAL_INIT ,indexOfCount , QMMEMMAN_OK );
			if (initialisationType == QMC_NORMAL_INIT && (NUMBER_OF_FOLDER_SPREAD_OVER == indexOfCount)
					&& ValidateSystemInfo(systemInfo) == QMMEMMAN_OK && FileSize == systemInfo.fileSizeInBytes) {
				//qDebug("QMMemoryManager Normal Initialisation Start\n");
				OutputDebugString("CB: QMMemoryManager Normal Initialisation Start\n");
				csTxt = QWidget::tr("Normal Initialization");
				pGlbSysInfo->SetStartupSubAction(csTxt);
				retValue = NormalInitialisation(systemInfo);
			} else {
				if ((NUMBER_OF_FOLDER_SPREAD_OVER != indexOfCount) || (FileSize != systemInfo.fileSizeInBytes))	//SD card is not prepared
						{
					pSYSTEM_INFO->SetDataResetRequired(DATA_RESET_USER_SET);
					m_eSpReset = QMMEMMAN_DEF_RESET;
					OutputDebugString("CB: QMMemoryManager Default Initialisation Fresh SD Start\n");
				} else {
					if (QMMEMMAN_BLK_RESET != m_eSpReset) {
						//qDebug("QMMemoryManager Default Initialisation Start\n");
						OutputDebugString("CB: QMMemoryManager Default Initialisation Start\n");
						if ( FALSE == pSYSTEM_INFO->IsDataResetRequested()) {
							pSYSTEM_INFO->SetDataResetRequired(DATA_RESET_USER_SET);
						}
						//pFlash->ClearFlashBlock(FLASH_BLK_ADDITIONAL_SPARE_2);
						//qDebug("CQMHardwareManager::Initialise:: data reset called -QMMemoryManager Default Initialisation Start");
					}
				}
				csTxt = QWidget::tr("Default Initialization");
				pGlbSysInfo->SetStartupSubAction(csTxt);
				retValue = DefaultInitialisation(systemInfo);
			} // End of IF
		} else {
			retValue = QMMEMMAN_INSUFFICENT_MEMORY;
		} // End of IF
		// If the Hardware has been initalised correctly, then create the
		// requried interface classes to be made available to the Queue Manager
		// Services. 
		if (QMMEMMAN_OK == retValue) {
			csTxt = QWidget::tr("Create Interface Classes");
			pGlbSysInfo->SetStartupSubAction(csTxt);
			retValue = CreateInterfaceClasses();
			pSYSTEM_INFO->SetNumBlocksPerFile(m_pMemoryOpData->numOfDataBlocksPerFile);
			pSYSTEM_INFO->SetNumCreatedFiles(m_pMemoryOpData->numOfFiles);
			pSYSTEM_INFO->SetNumDataBlocks(m_pMemoryOpData->numOfBlocks);
		} // End of IF
	} // End of IF
	swprintf(printMsg, 512,
			L"m_pMemoryOpData: numOfFiles = %d,numOfQueues = %d, numOfBlocks = %d numOfDataBlocksPerFile = %d\n",
			m_pMemoryOpData->numOfFiles, m_pMemoryOpData->numOfQueues, m_pMemoryOpData->numOfBlocks,
			m_pMemoryOpData->numOfDataBlocksPerFile);
	OutputDebugString()<<printMsg;
	return (retValue);
} // End of Member Function				
//*************************************************************************************************
/// Undertake Data Integrity Test on just the Block Queues
///
/// @return T_QMMEMMAN_RETURN_VALUE as result
//*************************************************************************************************
T_QMMEMMAN_RETURN_VALUE CQMHardwareManager::PerformBlockIntegrityTests(void) {
	T_QMMEMMAN_RETURN_VALUE retValue = QMMEMMAN_OK;
	if (QMDI_TEST_PASSED
			!= m_DataIntegrity.TestBlockCoverage(m_pFreeBlockQueue, m_pTempStoredBlockQueue, m_pToDiskQueue,
					m_pPersistDataBlockQueue, m_pBlock, m_pMemoryOpData->numOfBlocks, m_pMemoryOpData->numOfQueues)) {
		LOG_ERR(TRACE_QUEUE_MANAGER, "QM Data Integrity: Block Coverage Check Failed");
		retValue = QMMEMMAN_DATA_INTEGRITY_CHECKS_FAILED;
	}
	return retValue;
}
//*************************************************************************************************
/// Undertake Data Integrity Test on the Queue Manager Memory
///
/// @return T_QMMEMMAN_RETURN_VALUE as result
//*************************************************************************************************
T_QMMEMMAN_RETURN_VALUE CQMHardwareManager::PerformDataIntegrityTests(const T_QMC_SYSTEM_INFO &systemInfo) {
	T_QMMEMMAN_RETURN_VALUE retValue = QMMEMMAN_OK;
	T_QMDI_RETURN_VALUE retBlockCoverageTestVal = QMDI_TEST_PASSED;
	m_eSpReset = QMMEMMAN_DEF_RESET;
#ifdef DBG_FILE_LOG_QUEUEMM_ENABLE
	QString  strLog;
#endif
	QString csTxt;
	csTxt = QWidget::tr("Running Operation Data Check");
	pGlbSysInfo->SetStartupSubAction(csTxt);
	if (QMDI_TEST_FAILED == m_DataIntegrity.TestMemoryOperationalData(m_pMemoryOpData)) {
		retValue = QMMEMMAN_DATA_INTEGRITY_CHECKS_FAILED;
		LOG_ERR(TRACE_QUEUE_MANAGER, "QM Data Integrity: Operational Data Check Failed");
		csTxt = QWidget::tr("Operation Data Check Failed");
		pGlbSysInfo->SetStartupSubAction(csTxt);
	} // End of IF
	//CBatteryManager* pBatMan = CBatteryManager::GetHandle(); 
	//if ( (NULL != pBatMan ) && (FALSE == pBatMan->IsBatteryResetPerformed() ) )
	{
		SYSTEMTIME sysTime;
		GetLocalTime(&sysTime);
		//if date changed to 2006 (battery low identified) reset blockdata
		if ((sysTime.wYear <= 2006) && (DATA_RESET_USER_SET != pSYSTEM_INFO->GetDataResetType())) {
			RestoreFileQueueHeaders();
		}
	}
	csTxt = QWidget::tr("Starting Block Coverage Test");
	pGlbSysInfo->SetStartupSubAction(csTxt);
	retBlockCoverageTestVal = m_DataIntegrity.TestBlockCoverage(m_pFreeBlockQueue, m_pTempStoredBlockQueue,
			m_pToDiskQueue, m_pPersistDataBlockQueue, m_pBlock, m_pMemoryOpData->numOfBlocks,
			m_pMemoryOpData->numOfQueues);
	if (QMDI_TEST_PASSED != retBlockCoverageTestVal) {
		LOG_ERR(TRACE_QUEUE_MANAGER, "QM Data Integrity: Block Coverage Check Failed");
		csTxt = QWidget::tr("Block Coverage Test Failed");
		pGlbSysInfo->SetStartupSubAction(csTxt);
		if (QMDI_TEST_FAILED == retBlockCoverageTestVal) {
            pGlbSysInfo->SetStartupSubAction("Attempting Recovery");
			if (QMDI_TEST_PASSED
					!= m_DataIntegrity.RecoverBlockCoverage(m_pFreeBlockQueue, m_pTempStoredBlockQueue, m_pToDiskQueue,
							m_pPersistDataBlockQueue, m_pBlock, m_pMemoryOpData->numOfBlocks,
							m_pMemoryOpData->numOfQueues)) {
				m_eSpReset = QMMEMMAN_BLK_RESET;
				//retValue = QMMEMMAN_DATA_INTEGRITY_CHECKS_FAILED;
                pGlbSysInfo->AddStartupErr("Send recovery.log to the Software Team.");
                pGlbSysInfo->AddStartupErr("Data Block Integrity failed.");
			}
		} else {
			m_eSpReset = QMMEMMAN_BLK_RESET;
#ifdef DBG_FILE_LOG_QUEUEMM_ENABLE
			strLog = QString::asprintf("PerformDataIntegrityTests failed perform recovery \n");
			m_debugFileLogger.WriteToDebugLogFile(strLog);
#endif
		}
	} // End of IF
	if (QMMEMMAN_BLK_RESET == m_eSpReset) {
		DefaultInitialisation(systemInfo);
#ifdef DBG_FILE_LOG_QUEUEMM_ENABLE
			strLog = QString::asprintf("PerformDataIntegrityTests :: DefaultInitialisation done with spreset\n");
			m_debugFileLogger.WriteToDebugLogFile(strLog);
	#endif
		if (QMDI_TEST_PASSED
				!= m_DataIntegrity.TestBlockCoverage(m_pFreeBlockQueue, m_pTempStoredBlockQueue, m_pToDiskQueue,
						m_pPersistDataBlockQueue, m_pBlock, m_pMemoryOpData->numOfBlocks,
						m_pMemoryOpData->numOfQueues)) {
			retValue = QMMEMMAN_DATA_INTEGRITY_CHECKS_FAILED;
#ifdef DBG_FILE_LOG_QUEUEMM_ENABLE
				strLog = QString::asprintf("PerformDataIntegrityTests :: TBC recovery Failed \n");
				m_debugFileLogger.WriteToDebugLogFile(strLog);
	#endif
		}
		m_eSpReset = QMMEMMAN_DEF_RESET;
	}
	csTxt = QWidget::tr("Starting File Coverage Test");
	pGlbSysInfo->SetStartupSubAction(csTxt);
	if (QMDI_TEST_FAILED
			== m_DataIntegrity.TestFileCoverage(m_pFileAvailableQueue, m_pPersistDataFileQueue, m_pFileHeader,
					m_pMemoryOpData->numOfFiles, m_pMemoryOpData->numOfQueues))
					{
		retValue = QMMEMMAN_DATA_INTEGRITY_CHECKS_FAILED;
		m_eSpReset = QMMEMMAN_FULL_RESET;
		LOG_ERR(TRACE_QUEUE_MANAGER, "QM Data Integrity: File Coverage Check Failed");
		csTxt = QWidget::tr("File Coverage Test Failed");
		pGlbSysInfo->SetStartupSubAction(csTxt);
	} // End of IF
	if (m_eSpReset == QMMEMMAN_FULL_RESET) {
		//file coverage integrity failed,Update backup file data from flash to SRAM 
		BOOL bRet = RestoreFileQueueHeaders();
		if ( TRUE == bRet) {
			QString sysMessage;
			sysMessage = QString::asprintf("File data Restored from Backup Memory ");
			LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_INFORMATION, sysMessage);
			if (QMDI_TEST_FAILED
					== m_DataIntegrity.TestFileCoverage(m_pFileAvailableQueue, m_pPersistDataFileQueue, m_pFileHeader,
							m_pMemoryOpData->numOfFiles, m_pMemoryOpData->numOfQueues)) {
				retValue = QMMEMMAN_DATA_INTEGRITY_CHECKS_FAILED;
			} else {
				retValue = QMMEMMAN_OK;
			}
		}
		if ((FALSE == bRet) || (QMMEMMAN_DATA_INTEGRITY_CHECKS_FAILED == retValue)) {
			pSYSTEM_INFO->SetDataResetRequired(DATA_RESET_USER_SET);
			retValue = DefaultInitialisation(systemInfo);
		}
		m_eSpReset = QMMEMMAN_DEF_RESET;
	}
	return (retValue);
} // End of Member Function
////////////////////////////////////////////////////////////////////////////////////////////////
// Private Member Functions
////////////////////////////////////////////////////////////////////////////////////////////////
//*************************************************************************************************
/// InitialiseBlockHeaders( void ) Initialise Block Headers to Default - Set Block Id
///
/// @return n/a
//*************************************************************************************************
void CQMHardwareManager::InitialiseBlockHeaders(void) {
	// Initialise Each Block Header, linking each block to each other to form
	// a linked list. 
	for (USHORT blkIndex = QMC_ZERO; blkIndex < m_pMemoryOpData->numOfBlocks; ++blkIndex) {
		m_pBlock[blkIndex].blockHeader.blockId = blkIndex;
		m_pBlock[blkIndex].blockHeader.blockType = QMC_ZERO;
		m_pBlock[blkIndex].blockHeader.nextBlock = blkIndex + QMC_ONE_BLOCK;
		m_pBlock[blkIndex].blockHeader.QueueId = QMC_INVALID_Q_ID; //temporary magic number outside of queue range, but NOT 65535
		/// @todo REMOVE FOR FINAL RELEASE, FOR TEST PURPOSES ONLY due to speed issues
		// Initialise the data area of the block to Default Values;
		// memset( m_pBlock[blkIndex].blockData, 0xDD, QMC_BLOCK_SIZE );
	} // End of FOR
	// Set the last block to indicate End of Queue
	m_pBlock[m_pMemoryOpData->numOfBlocks - QMC_ONE_BLOCK].blockHeader.nextBlock = QMC_END_OF_QUEUE;
} // End of Member Function
//*************************************************************************************************
/// InitialiseFileHeaders( void ) Initialise File Headers to Default - Set File Id
///
/// @return n/a
//*************************************************************************************************
void CQMHardwareManager::InitialiseFileHeaders(void) {
	// Initialise Each File Header, linking each file to each other to form
	// a linked list. 
	for (USHORT fileIndex = QMC_ZERO; fileIndex < m_pMemoryOpData->numOfFiles; ++fileIndex) {
		m_pFileHeader[fileIndex].fileId = fileIndex;
		m_pFileHeader[fileIndex].fileMode = QMC_DATAFILE_MODE_NORMAL;
		m_pFileHeader[fileIndex].fileStatus = QMC_FILE_AVAILABLE_NOT_USED;
		m_pFileHeader[fileIndex].newestBlockNumber = QMC_ZERO;
		m_pFileHeader[fileIndex].previousFile = fileIndex - QMC_ONE_FILE;
		m_pFileHeader[fileIndex].nextFile = fileIndex + QMC_ONE_FILE;
		m_pFileHeader[fileIndex].numOfDataBlocks = QMC_ZERO;
		m_pFileHeader[fileIndex].oldestBlockNumber = QMC_ZERO;
		m_pFileHeader[fileIndex].oldestBlockNumber = QMC_ZERO;
		m_pFileHeader[fileIndex].queueId = QMC_INVALID_QUEUE;
	} // End of FOR
	// Set the last file to indicate End of Queue
	m_pFileHeader[m_pMemoryOpData->numOfFiles - QMC_ONE_FILE].nextFile = QMC_END_OF_QUEUE;
} // End of Member Function
//*************************************************************************************************
/// CreateBlockFiles( void ) Create Default Files split over directories
///
/// @return n/a
//*************************************************************************************************
void CQMHardwareManager::CreateBlockFiles(void) {
	// Persisted Path and File Name
	QString blockDataPathName;		// Data File Path
	QString blockDataFileAndPathName; // Data File Path and File Name
	CStorage blockFileToCreate;
	// Build the Persisted Setup Configuration Path and File Name
	pDALGLB->BuildPath(IDS_INTERNAL_SD, IDS_LOG_DATA, NULL, &blockDataPathName, MAX_PATH);
//	qDebug("CREATING FILES, file number.......\n");
	QString csTxt;
	csTxt = QWidget::tr("Initializing Header Buffer");
	pGlbSysInfo->SetStartupSubAction(csTxt);
	// Create a File Header Buffer and Initialise to all 0xEE for readability within the file
	BYTE *pFileHeaderBuffer = new BYTE[QMC_BLOCK_SIZE];
	memset(pFileHeaderBuffer, 0xEE, QMC_BLOCK_SIZE);
	T_QMC_DATAFILE_HEADER *pFileHeader = reinterpret_cast<T_QMC_DATAFILE_HEADER*>(pFileHeaderBuffer);
	// Set the File Header 
	pFileHeader->fileMode = QMC_DATAFILE_MODE_NORMAL;
	pFileHeader->fileStatus = QMC_ZERO;
	pFileHeader->newestBlockNumber = QMC_ZERO;
	pFileHeader->nextFile = QMC_END_OF_QUEUE;
	pFileHeader->numOfDataBlocks = QMC_ZERO;
	pFileHeader->oldestBlockNumber = QMC_ZERO;
	pFileHeader->previousFile = QMC_START_OF_QUEUE;
	pFileHeader->queueId = QMC_INVALID_QUEUE;
	const USHORT usTenPercent = m_pMemoryOpData->numOfFiles / 10;
	csTxt = QWidget::tr("Creating Sub-Directories");
	pGlbSysInfo->SetStartupSubAction(csTxt);
	// Create the split subdirectories for database
	for (USHORT subdirIndex = 0; subdirIndex < NUMBER_OF_FOLDER_SPREAD_OVER; subdirIndex++) {
		blockDataFileAndPathName = blockDataPathName;
		CQMDataFileAccess::CompleteDataFilePath(blockDataFileAndPathName,
				sizeof(blockDataFileAndPathName) / sizeof(WCHAR), subdirIndex);	// Complete Path
		//create path if does not exist	
		CStorage::CreateDirectory(blockDataFileAndPathName, NULL);
	}
	for (USHORT fileIndex = QMC_ZERO; fileIndex < m_pMemoryOpData->numOfFiles; fileIndex++) {
		// Construct the File Name and Extension for the associated Data Block File 
		blockDataFileAndPathName = blockDataPathName;
		CQMDataFileAccess::CompleteDataFilePath(blockDataFileAndPathName,
		MAX_PATH, fileIndex);	// Complete Path
		CQMDataFileAccess::CompleteDataFileName(blockDataFileAndPathName,
		MAX_PATH, fileIndex);	// Complete Name
		WCHAR mess[40];
		csTxt = QWidget::tr("Creating file %d of %d");
        csTxt = QString::asprintf(csTxt.toLocal8Bit().data(), fileIndex, m_pMemoryOpData->numOfFiles);
		pGlbSysInfo->SetStartupSubAction(mess);
		if ( TRUE
				== blockFileToCreate.Open(blockDataFileAndPathName.toLocal8Bit().data(),
						QFile::Append | QFile::WriteOnly)) {
			// Write Header to the File
			blockFileToCreate.Write(pFileHeaderBuffer, QMC_BLOCK_SIZE);
			// Set the File Length for access speed 
//			blockFileToCreate.SetLength(m_pMemoryOpData->systemInfo.fileSizeInBytes);
			blockFileToCreate.Close();
		}
	}
	delete[] pFileHeaderBuffer;
	pFileHeaderBuffer = NULL;
} // End of Member Function
/// Initialise the Queue Manager Memory to Default
//*************************************************************************************************
/// DefaultInitialisation - Initialise the Queue Manager Memory to Default
///
/// @param [in/out] - &sysInfo - reference to the T_QMC_SYSTEM_INFO structure
///
/// @return QMMEMAN_OK
//*************************************************************************************************
T_QMMEMMAN_RETURN_VALUE CQMHardwareManager::DefaultInitialisation(const T_QMC_SYSTEM_INFO &sysInfo) {
	T_QMMEMMAN_RETURN_VALUE retValue = QMMEMMAN_OK; // Member Function Return Value 
	QString csTxt;
#ifdef DBG_FILE_LOG_QUEUEMM_ENABLE
	QString  strLog;
	strLog = QString::asprintf("CQMHardwareManager::DefaultInitialisation \n");
	m_debugFileLogger.WriteToDebugLogFile(strLog);
#endif
	QString sysMessage;
    sysMessage = QString::asprintf("DefaultInitialisation SpReset %d ", m_eSpReset );
	LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_INFORMATION, sysMessage);
// SS:Restoring Email Root Certificate from Flash for fresh SDcard 
// we are handling here because defautInitialisation and m_eSpReset '0' represents fresh SDcard scenario
#ifdef UNDER_CE
	if(m_eSpReset == 0)
	{
		CFlashManager* pFlashMngr = CFlashManager::GetHandle();
		ULONG fileSize = pFlashMngr->GetDataBlockSize((T_FLASH_BLOCK)FLASH_BLK_EMAILROOTCERTIFICATE);
		if (fileSize > 0)
		{
			pDALGLB->RestoreEmailCertificate();
		}
	}
#endif
	if (QMMEMMAN_BLK_RESET != m_eSpReset) //This is Special RESET for SRAM Queue content but files remain as-is.
			{
		memset(m_pBasePointer, 0xDD, sysInfo.lengthOfMemoryInBytes);
		csTxt = QWidget::tr("Initializing Headers");
		pGlbSysInfo->SetStartupSubAction(csTxt);
		// Step 1: Initialise Operational Memory
		InitialiseMemoryOpData(sysInfo);
	} else {
		pGlbSysInfo->SetStartupSubAction("SP RESET is being performed");
	}
	// Step 2: Calculate And Initialise Operational Pointers
	CalculateAndInitialisePointers();
	// Step 3: Initialise Free Block Queue Header to Default
	InitialiseFreeBlockHeader();
	// Initialise Temporary Stored Block Queue Header to Default
	InitialiseTempStoredBlockHeader();
	// Step 4: Initialise To Disk Queue Header to Default
	InitialiseToDiskQueueHeader();
	if (QMMEMMAN_BLK_RESET != m_eSpReset) //This is Special RESET for SRAM Queue content but files remain as-is.
			{
		if (DATA_RESET_USER_SET == pSYSTEM_INFO->GetDataResetType()) {
			// Step 5: Initialise File Available Queue to Default
			InitialiseFileAvailableQueue();
		} else {
			//Incase of AutoReset and Default initialization is triggered.
			//Copy the FileQ content from Flash
			RestoreFileQueueHeaders();
			sysMessage = QString::asprintf("DefaultInit Restored SRAM fileQueues ");
			LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_INFORMATION, sysMessage);
		}
	}
	// Step 6: Initialise Persisted Block Queue Headers to Default
	InitialisePersistedBlockQueueHeaders();
	if (QMMEMMAN_BLK_RESET != m_eSpReset) //This is Special RESET for SRAM Queue content but files remain as-is.
			{
		if (DATA_RESET_USER_SET == pSYSTEM_INFO->GetDataResetType()) {
			// Step 7: Initialise Persisted File Queue Header to Default
			InitialisePersistedFileQueueHeaders();
			// Step 8: Initialise File Headers to Default - Set File Id
			InitialiseFileHeaders();
		}
	}
	// Step 9: Initialise Block Headers to Default - Set Block Id
	InitialiseBlockHeaders();
	if (QMMEMMAN_BLK_RESET != m_eSpReset) //This is Special RESET for SRAM Queue content but files remain as-is.
			{
		if (DATA_RESET_USER_SET == pSYSTEM_INFO->GetDataResetType()) {
			csTxt = QWidget::tr("Creating Block Files");
			pGlbSysInfo->SetStartupSubAction(csTxt);
			// Step 10: Create Default Files
			CreateBlockFiles();
		}
	}
	m_eSpReset = QMMEMMAN_DEF_RESET;
	return (retValue);
} // End of Member Function
//*************************************************************************************************
/// Initialise the Queue Manager Memory for Normal Operation
///
/// @param[in] systemInfo - system information to determine if changes have been made
///
/// @return T_QMMEMMAN_RETURN_VALUE as result QMMEMMAN_OK if successful
/// 
//*************************************************************************************************
T_QMMEMMAN_RETURN_VALUE CQMHardwareManager::NormalInitialisation(const T_QMC_SYSTEM_INFO &systemInfo) {
	T_QMMEMMAN_RETURN_VALUE retValue = QMMEMMAN_OK; // Member Function Return Value 
	if (QMMEMMAN_OK == retValue) {
		// Calculate And Initialise Operational Pointers
		QString csTxt;
		csTxt = QWidget::tr("Initializing Pointers");
		pGlbSysInfo->SetStartupSubAction(csTxt);
		retValue = CalculateAndInitialisePointers();
	} // End of IF
	return (retValue);
} // End of Member Function	
//*************************************************************************************************
/// ValidateSystemInfo - Ensure that nothing has changed since Last run (int CF size etc)
///
/// @param[in] systemInfo - system information to determine if changes have been made
///
/// @return T_QMMEMMAN_RETURN_VALUE as result QMMEMMAN_OK if successful
/// 
//*************************************************************************************************
T_QMMEMMAN_RETURN_VALUE CQMHardwareManager::ValidateSystemInfo(const T_QMC_SYSTEM_INFO &sysInfo) {
	T_QMMEMMAN_RETURN_VALUE retValue = QMMEMMAN_OK;
	const ULONG ulNvQDiffLenInBytes = 10240; //bytes
	ULONG ulDiffLen = m_pMemoryOpData->systemInfo.lengthOfMemoryInBytes - sysInfo.lengthOfMemoryInBytes;
	if (ulNvQDiffLenInBytes == ulDiffLen) {
		m_eSpReset = QMMEMMAN_BLK_RESET;
	}
	if ((sysInfo.lengthOfMemoryInBytes < m_pMemoryOpData->systemInfo.lengthOfMemoryInBytes)) {
		retValue = QMMEMMAN_SYSTEM_INFO_CHANGED_ERROR;
		if (QMMEMMAN_BLK_RESET == m_eSpReset) {
			//Reduced number of blocks with 10K new region is 19
			// 10240/524 = 19
			const USHORT usReducedNumBlks = 19;
			m_pMemoryOpData->numOfBlocks -= usReducedNumBlks;
		}
	} else {
		if ((sysInfo.diskSizeInBytes != m_pMemoryOpData->systemInfo.diskSizeInBytes)
				|| (sysInfo.fileSizeInBytes != m_pMemoryOpData->systemInfo.fileSizeInBytes)
				|| (sysInfo.maxNumOfPens != m_pMemoryOpData->systemInfo.maxNumOfPens)
				|| (sysInfo.numOfMessageQueues != m_pMemoryOpData->systemInfo.numOfMessageQueues)) {
			retValue = QMMEMMAN_SYSTEM_INFO_CHANGED_ERROR;
		} // End of IF
	} // End of IF
	return (retValue);
} // End of Member Function
//*************************************************************************************************
/// CalculateMinMemoryRequirements - calculate data space requirements for database system
///
/// @param[in] systemInfo - system information to determine if changes have been made
///
/// @return - size of required memory in bytes
/// 
//*************************************************************************************************	
ULONG CQMHardwareManager::CalculateMinMemoryRequirements(const T_QMC_SYSTEM_INFO &sysInfo) {
	ULONG minMemoryRequiredInBytes = QMC_ZERO;
	USHORT numOfFiles = static_cast<USHORT>(sysInfo.diskSizeInBytes / sysInfo.fileSizeInBytes);
	USHORT numOfQueues = ((sysInfo.maxNumOfPens * QMC_TOTAL_NO_OF_QUEUES_PER_PEN) + sysInfo.numOfMessageQueues);
	// NV SRAM Header
	minMemoryRequiredInBytes += sizeof(T_QMC_DATA);
	// Free Block Queue Header
	minMemoryRequiredInBytes += sizeof(T_QMC_BLOCK_QUEUE);
	// To Disk Queue Header
	minMemoryRequiredInBytes += sizeof(T_QMC_BLOCK_QUEUE);
	// File Available Queue Header
	minMemoryRequiredInBytes += sizeof(T_QMC_DATAFILE_QUEUE);
	// Persist Data Queue Headers
	minMemoryRequiredInBytes += (numOfQueues * sizeof(T_QMC_PERSIST_DATA_BLKQ));
	// Persist Data File Queue Headers
	minMemoryRequiredInBytes += (numOfQueues * sizeof(T_QMC_PERSIST_DATAFILE_QUEUE));
	// File Headers
	minMemoryRequiredInBytes += (numOfFiles * sizeof(T_QMC_DATAFILE_HEADER));
	// Calculate the memory required based on one block per queue
	minMemoryRequiredInBytes += (numOfQueues * sizeof(T_QMC_BLOCK));
	return (minMemoryRequiredInBytes);
} // End of Member Function
//*************************************************************************************************
/// InitialiseMemoryOpData - initialise the operational data for first use
///
/// @param[in]  systemInfo - system information to determine if changes have been made
///
/// @return - QMMEMMAN_OK
///
//*************************************************************************************************
T_QMMEMMAN_RETURN_VALUE CQMHardwareManager::InitialiseMemoryOpData(const T_QMC_SYSTEM_INFO &sysInfo) {
	T_QMMEMMAN_RETURN_VALUE retValue = QMMEMMAN_OK; // Member Function Return Value
	m_pMemoryOpData->systemInfo = sysInfo;
	m_pMemoryOpData->signature = QMC_SIGNATURE;
	m_pMemoryOpData->status = QMC_ZERO;
	m_pMemoryOpData->numOfFiles = static_cast<USHORT>(m_pMemoryOpData->systemInfo.diskSizeInBytes
			/ m_pMemoryOpData->systemInfo.fileSizeInBytes);
	m_pMemoryOpData->numOfQueues = ((m_pMemoryOpData->systemInfo.maxNumOfPens * QMC_TOTAL_NO_OF_QUEUES_PER_PEN)
			+ m_pMemoryOpData->systemInfo.numOfMessageQueues);
	m_pMemoryOpData->numOfBlocks = static_cast<USHORT>(CalculateMemoryForBlocks() / sizeof(T_QMC_BLOCK));
	qDebug("NUMBER OF BLOCKS: %d\n", m_pMemoryOpData->numOfBlocks);
	// One block is taken off this calulcation to allow for the file containing a header which
	// for efficiency is the size of one block.
	m_pMemoryOpData->numOfDataBlocksPerFile = static_cast<USHORT>((m_pMemoryOpData->systemInfo.fileSizeInBytes
			/ QMC_BLOCK_SIZE) - QMC_ONE_BLOCK);
	return (retValue);
} // End of Member Function
//*************************************************************************************************
/// CalculateAndInitialisePointers - calculate and set NVQueue system pointers
///
/// @param[in]  n/a
///
/// @return - QMMEMMAN_OK
///
//*************************************************************************************************
T_QMMEMMAN_RETURN_VALUE CQMHardwareManager::CalculateAndInitialisePointers(void) {
	T_QMMEMMAN_RETURN_VALUE retValue = QMMEMMAN_OK;  // Member Function Return Value
	ULONG MemoryUsedInBytes = QMC_ZERO;
	m_pMemoryOpData = (T_QMC_DATA*) m_pBasePointer;
	MemoryUsedInBytes += sizeof(T_QMC_DATA);
#ifdef DBG_FILE_LOG_QUEUEMM_ENABLE
  QString strLog;
  strLog = QString::asprintf(L"CalculateAndInitialisePointers ::size of T_QMC_DATA :: %lu MemoryUsedInBytes :%lu GTC - %d\r\n",sizeof( T_QMC_DATA ),MemoryUsedInBytes,GetTickCount());
  m_debugFileLogger.WriteToDebugLogFile(strLog);
  strLog = QString::asprintf(L"numOfFiles :: %d numOfBlocks:: %d numOfQueues :: %d GTC - %d\r\n", m_pMemoryOpData->numOfFiles,m_pMemoryOpData->numOfBlocks,m_pMemoryOpData->numOfQueues,GetTickCount());
  m_debugFileLogger.WriteToDebugLogFile(strLog);
  strLog = QString::asprintf(L"numOfDataBlocksPerFile :: %d GTC - %d\r\n",m_pMemoryOpData->numOfDataBlocksPerFile,GetTickCount());
  m_debugFileLogger.WriteToDebugLogFile(strLog);
#endif
	m_pFreeBlockQueue = (T_PQMC_BLOCK_QUEUE) (m_pBasePointer + MemoryUsedInBytes);
	MemoryUsedInBytes += sizeof(T_QMC_BLOCK_QUEUE);
#ifdef DBG_FILE_LOG_QUEUEMM_ENABLE
  strLog = QString::asprintf(L"m_pFreeBlockQueue :: head : %d tail : %d NumOfBlocksInQueue : %d GTC - %d\r\n",m_pFreeBlockQueue->Head,m_pFreeBlockQueue->Tail,m_pFreeBlockQueue->NumOfBlocksInQueue,GetTickCount());
  m_debugFileLogger.WriteToDebugLogFile(strLog);
#endif
	m_pToDiskQueue = (T_PQMC_BLOCK_QUEUE) (m_pBasePointer + MemoryUsedInBytes);
	MemoryUsedInBytes += sizeof(T_QMC_BLOCK_QUEUE);
#ifdef DBG_FILE_LOG_QUEUEMM_ENABLE
  strLog = QString::asprintf(L"m_pToDiskQueue :: head : %d tail : %d NumOfBlocksInQueue : %d GTC - %d\r\n",m_pToDiskQueue->Head,m_pToDiskQueue->Tail,m_pToDiskQueue->NumOfBlocksInQueue,GetTickCount());
  m_debugFileLogger.WriteToDebugLogFile(strLog);
#endif
	m_pTempStoredBlockQueue = (T_PQMC_BLOCK_QUEUE) (m_pBasePointer + MemoryUsedInBytes);
	MemoryUsedInBytes += sizeof(T_QMC_BLOCK_QUEUE);
#ifdef DBG_FILE_LOG_QUEUEMM_ENABLE
  strLog = QString::asprintf(L"m_pTempStoredBlockQueue :: head : %d tail : %d NumOfBlocksInQueue : %d GTC - %d\r\n",m_pTempStoredBlockQueue->Head,m_pTempStoredBlockQueue->Tail,m_pTempStoredBlockQueue->NumOfBlocksInQueue,GetTickCount());
  m_debugFileLogger.WriteToDebugLogFile(strLog);
#endif
	m_pFileAvailableQueue = (T_PQMC_DATAFILE_QUEUE) (m_pBasePointer + MemoryUsedInBytes);
	MemoryUsedInBytes += sizeof(T_QMC_DATAFILE_QUEUE);
	m_pPersistDataBlockQueue = (T_PQMC_PERSIST_DATA_BLKQ) (m_pBasePointer + MemoryUsedInBytes);
	MemoryUsedInBytes += (m_pMemoryOpData->numOfQueues * sizeof(T_QMC_PERSIST_DATA_BLKQ));
	m_pPersistDataFileQueue = (T_PQMC_PERSIST_DATAFILE_QUEUE) (m_pBasePointer + MemoryUsedInBytes);
	MemoryUsedInBytes += (m_pMemoryOpData->numOfQueues * sizeof(T_QMC_PERSIST_DATAFILE_QUEUE));
	m_pFileHeader = (T_PQMC_DATAFILE_HEADER) (m_pBasePointer + MemoryUsedInBytes);
	MemoryUsedInBytes += (m_pMemoryOpData->numOfFiles * sizeof(T_QMC_DATAFILE_HEADER));
	m_pBlock = (T_PQMC_BLOCK) (m_pBasePointer + MemoryUsedInBytes);
	return (retValue);
} // End of Member Function
//*************************************************************************************************
/// CalculateMemoryForBlocks - calculate remaining SRAM available for blocks
///
/// @param[in]  n/a
///
/// @return - available SRAM in bytes
///
//*************************************************************************************************
ULONG CQMHardwareManager::CalculateMemoryForBlocks(void) {
	ULONG memoryUsedInBytes = QMC_ZERO;
	// NV SRAM Header
	memoryUsedInBytes += sizeof(T_QMC_DATA);
	// Free Block Queue Header
	memoryUsedInBytes += sizeof(T_QMC_BLOCK_QUEUE);
	// To Disk Queue Header
	memoryUsedInBytes += sizeof(T_QMC_BLOCK_QUEUE);
	// File Available Queue Header
	memoryUsedInBytes += sizeof(T_QMC_DATAFILE_QUEUE);
	// File Unavialable Queue Header
	//memoryUsedInBytes += sizeof(  T_QMC_DATAFILE_QUEUE );
	// Persist Data Queue Headers
	memoryUsedInBytes += (m_pMemoryOpData->numOfQueues * sizeof(T_QMC_PERSIST_DATA_BLKQ));
	// Persist Data File Queue Headers
	memoryUsedInBytes += (m_pMemoryOpData->numOfQueues * sizeof(T_QMC_PERSIST_DATAFILE_QUEUE));
	// File Headers
	memoryUsedInBytes += (m_pMemoryOpData->numOfFiles * sizeof(T_QMC_DATAFILE_HEADER));
	qDebug("MEMORY USED( EXCLUDING BLOCKS ): %d\n", memoryUsedInBytes);
	qDebug("MEMORY AVAILABLE FOR BLOCKS: %d\n", m_pMemoryOpData->systemInfo.lengthOfMemoryInBytes - memoryUsedInBytes);
	return (m_pMemoryOpData->systemInfo.lengthOfMemoryInBytes - memoryUsedInBytes);
} // End of Member Function
//*************************************************************************************************
/// CreateInterfaceClasses - Initialise the interface classes to be used by the service layer of the Queue Manager
///
/// @param[in]  n/a
///
/// @return - QMMEMMAN_OK or QMMEMMAN_NULL_POINTER
///
//*************************************************************************************************
T_QMMEMMAN_RETURN_VALUE CQMHardwareManager::CreateInterfaceClasses(void) {
	T_QMMEMMAN_RETURN_VALUE retValue = QMMEMMAN_OK;
	m_pFreeBlkQ = new CQMBlkQAccess(*m_pFreeBlockQueue);
	if ( NULL == m_pFreeBlkQ) {
		retValue = QMMEMMAN_NULL_POINTER;
	} // End of IF
	m_pTempStoredBlkQ = new CQMBlkQAccess(*m_pTempStoredBlockQueue);
	if ( NULL == m_pTempStoredBlkQ) {
		retValue = QMMEMMAN_NULL_POINTER;
	} // End of IF
	m_pToDiskQ = new CQMBlkQAccess(*m_pToDiskQueue);
	if ( NULL == m_pToDiskQ) {
		retValue = QMMEMMAN_NULL_POINTER;
	} // End of IF
	m_pMemoryBlkAccess = new CQMDataBlkAccess(m_pBlock, m_pMemoryOpData->numOfBlocks);
	if ( NULL == m_pMemoryBlkAccess) {
		retValue = QMMEMMAN_NULL_POINTER;
	} // End of IF
	m_pPersistBlkQAccess = new CQMPersistBlkQAccess(m_pPersistDataBlockQueue, m_pMemoryOpData->numOfQueues);
	if ( NULL == m_pPersistBlkQAccess) {
		retValue = QMMEMMAN_NULL_POINTER;
	} // End of IF
	m_pMemoryOpDataAccess = new CQMMemoryOpDataAccess(*m_pMemoryOpData);
	if ( NULL == m_pMemoryOpDataAccess) {
		retValue = QMMEMMAN_NULL_POINTER;
	} // End of IF
	m_pDataFileAccess = new CQMDataFileAccess(m_pFileHeader, m_pMemoryOpData->numOfFiles);
	if ( NULL == m_pDataFileAccess) {
		retValue = QMMEMMAN_NULL_POINTER;
	} // End of IF
	m_pFreeFileQ = new CQMDataFileQAccess(*m_pFileAvailableQueue);
	if ( NULL == m_pFreeFileQ) {
		retValue = QMMEMMAN_NULL_POINTER;
	} // End of IF
	m_pPersistDataFileQAccess = new CQMPersistDataFileQAccess(m_pPersistDataFileQueue, m_pMemoryOpData->numOfQueues);
	return (retValue);
} // End of Member Function
//*************************************************************************************************
/// InitialiseFreeBlockHeader - Initialise Free Block Queue Header to Default
///
/// @param[in]  n/a
///
/// @return - n/a
///
//*************************************************************************************************
void CQMHardwareManager::InitialiseFreeBlockHeader(void) {
	// Initialise the Header to indicate all blocks are available.
	m_pFreeBlockQueue->Head = QMC_ZERO;
	// Blocks go from 0 to MAX Blocks - 1
	m_pFreeBlockQueue->Tail = m_pMemoryOpData->numOfBlocks - QMC_ONE_BLOCK;
	// Set Number of Blocks in Queue, to the Max Number of Blocks Available
	m_pFreeBlockQueue->NumOfBlocksInQueue = m_pMemoryOpData->numOfBlocks;
} // End of Member Function
//*************************************************************************************************
/// InitialiseTempStoredBlockHeader - Initialise Temporary Stored Block Queue Header to Default
///
/// @param[in]  n/a
///
/// @return - n/a
///
//*************************************************************************************************
void CQMHardwareManager::InitialiseTempStoredBlockHeader(void) {
	// Initialise the Header to indicate the Queue is Empty
	m_pTempStoredBlockQueue->Head = QMC_START_OF_QUEUE;
	m_pTempStoredBlockQueue->Tail = QMC_END_OF_QUEUE;
	m_pTempStoredBlockQueue->NumOfBlocksInQueue = QMC_ZERO;
} // End of Member Function
//*************************************************************************************************
/// InitialiseToDiskQueueHeader - Initialise To Disk Queue Header to Default
///
/// @param[in]  n/a
///
/// @return - n/a
///
//*************************************************************************************************
void CQMHardwareManager::InitialiseToDiskQueueHeader(void) {
	// Initialise the Header to indicate the Queue is Empty
	m_pToDiskQueue->Head = QMC_START_OF_QUEUE;
	m_pToDiskQueue->Tail = QMC_END_OF_QUEUE;
	m_pToDiskQueue->NumOfBlocksInQueue = QMC_ZERO;
} // End of Member Function
//*************************************************************************************************
/// InitialiseFileAvailableQueue - Initialise File Available Queue to Default
///
/// @param[in]  n/a
///
/// @return - n/a
///
//*************************************************************************************************
void CQMHardwareManager::InitialiseFileAvailableQueue(void) {
	// Initialise File Available Queue Header to indicate all files are available.
	m_pFileAvailableQueue->Head = QMC_ZERO;
	// Files go from 0 to MAX Files - 1
	m_pFileAvailableQueue->Tail = m_pMemoryOpData->numOfFiles - QMC_ONE_FILE;
	// Set Number of Files in Queue, to the Max Number of Files Available
	m_pFileAvailableQueue->NumOfFilesInQueue = m_pMemoryOpData->numOfFiles;
} // End of Member Function
//*************************************************************************************************
/// InitialisePersistedBlockQueueHeaders - Initialise Persisted Block Queue Headers to Default
///
/// @param[in]  n/a
///
/// @return - n/a
///
//*************************************************************************************************
void CQMHardwareManager::InitialisePersistedBlockQueueHeaders(void) {
	for (USHORT persistBlkHeaderIndex = QMC_ZERO; persistBlkHeaderIndex < m_pMemoryOpData->numOfQueues;
			++persistBlkHeaderIndex) {
		m_pPersistDataBlockQueue[persistBlkHeaderIndex].Status = QMC_BLKQ_STATUS_QUEUE_NOT_SETUP;
		m_pPersistDataBlockQueue[persistBlkHeaderIndex].Head = QMC_START_OF_QUEUE;
		m_pPersistDataBlockQueue[persistBlkHeaderIndex].Tail = QMC_END_OF_QUEUE;
		m_pPersistDataBlockQueue[persistBlkHeaderIndex].NumOfBlocksInQueue = QMC_ZERO;
		m_pPersistDataBlockQueue[persistBlkHeaderIndex].FlushToDiskLimit = QMC_ZERO;
		m_pPersistDataBlockQueue[persistBlkHeaderIndex].QueueConfirmation = QMC_CONFIRMATION_NOT_REQUIRED;
	} // End of FOR
} // End of Member Function
//*************************************************************************************************
/// InitialisePersistedFileQueueHeaders - Initialise Persisted File Queue Header to Default
///
/// @param[in]  n/a
///
/// @return - n/a
///
//*************************************************************************************************
void CQMHardwareManager::InitialisePersistedFileQueueHeaders(void) {
	for (USHORT persistFileHeaderIndex = QMC_ZERO; persistFileHeaderIndex < m_pMemoryOpData->numOfQueues;
			++persistFileHeaderIndex) {
		m_pPersistDataFileQueue[persistFileHeaderIndex].Head = QMC_START_OF_QUEUE;
		m_pPersistDataFileQueue[persistFileHeaderIndex].Tail = QMC_END_OF_QUEUE;
		m_pPersistDataFileQueue[persistFileHeaderIndex].MinFiles = QMC_ONE_FILE;
		m_pPersistDataFileQueue[persistFileHeaderIndex].MaxFiles = QMC_ONE_FILE;
		m_pPersistDataFileQueue[persistFileHeaderIndex].NumOfFilesInQueue = QMC_ZERO;
	} // End of FOR
} // End of Member Function
//*************************************************************************************************
/// DelTree - delete a folder and all sub folders
///
/// @param[in]  path - WHCAR string containing the path of the folder to delete
///
/// @return - n/a
///
//*************************************************************************************************
void CQMHardwareManager::DelTree(QString path)
{
    HANDLE hSearch;
    WIN32_FIND_DATA FindData;

    QString SearchName="";
    SearchName =path;
    if (SearchName[SearchName.length()-1] != '/')
        SearchName+="/*";
    else
        SearchName+="*";

    // Open file search
    QDirIterator it(SearchName, QStringList() << "", QDir::NoFilter, QDirIterator::Subdirectories);
    while(it.hasNext())
    {
            // Build a full file/folder path
            QString FullName="";
            QString FindData = "";

            FullName = path;
            if (FullName[FullName.length()-1] != '/')
                FullName += '/';
            if ( (FindData.compare(".") != NULL )&& (wcscmp (FindData.cFileName,L"..") ))
            {
                if ( ( FindData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY ) != 0)
                {
                    // File is a folder, delete the content
                    FullName+=FindData;
                    DelTree( FullName );

                    // restore the folder name so we can delete it


                    FullName = path;
                    wcsncat( FullName, MAX_PATH, '/', wcslen('/') );
                }

                // create the full path and file name for deletion
                FullName, MAX_PATH, FindData.cFileName, wcslen(FindData.cFileName) );
                CStorage::DeleteFile( FullName );

        }

        FindClose( hSearch );
    }
}
//****************************************************************************
/// BackUpFileQueueHeaders - Backup of SRAM fileQ data to SDCard
///
/// @param[in] 	 - None
///
/// @return			- None
///
//****************************************************************************
				void CQMHardwareManager::BackUpFileQueueHeaders() {
					BOOL bretVal = FALSE;
					bretVal = pDALGLB->ReadWriteNV( BF_WRITE, MAX_FILE_BLOCK_SIZE, (LPWORD) m_pFileAvailableQueue,
							BF_BLK_SRAM_FILE_Q_BACKUP, MAX_FILE_BLOCK_SIZE);
					//backUp SRAM in flash
					//pFlash = CFlashManager::GetHandle();
					//pFlash->CheckIntegrityAndRepair();
					//pFlash->WriteBlock( FLASH_BLK_SRAM_FILE_Q_BACKUP, m_pFileAvailableQueue , MAX_FILE_BLOCK_SIZE );
				}
//****************************************************************************************
/// RestoreFileQueueHeaders - Read file headers from disk and copy to SRAM fileQS location
///
/// @param[in] 	 - None
///
/// @return			- None
///
//*****************************************************************************************
				BOOL CQMHardwareManager::RestoreFileQueueHeaders() {
					BOOL bRetVal = FALSE;
					BYTE *pByReadBack = new BYTE[MAX_FILE_BLOCK_SIZE];
					if (pByReadBack != NULL) {
						//Restore from flash
						//T_FLASH_STATUS retVal;
						//pFlash = CFlashManager::GetHandle();
						//retVal = pFlash->ReadBlock( FLASH_BLK_SRAM_FILE_Q_BACKUP, pByReadBack,  MAX_FILE_BLOCK_SIZE );
						bRetVal = pDALGLB->ReadWriteNV( BF_READ, MAX_FILE_BLOCK_SIZE, (LPWORD) pByReadBack,
								BF_BLK_SRAM_FILE_Q_BACKUP, MAX_FILE_BLOCK_SIZE, TRUE);
						if ( TRUE == bRetVal) {
							//Check if this is empty file
							CHAR chEmptyNv[] = "Empty NV file"; //This text is dependent on ReadWriteNV function
							if (memcmp(pByReadBack, chEmptyNv, 13) == 0) {
								//Empty File Detected
								bRetVal = FALSE;
							}
						}
					}
					if (TRUE == bRetVal) {
						T_QMC_DATAFILE_QUEUE *pFileAvailableQueueRead;
						T_QMC_PERSIST_DATAFILE_QUEUE *pPersistDataFileQueueRead;
						T_QMC_DATAFILE_HEADER *pDataFileHeader;
						ULONG memoryPositionOfFileHeader = QMC_ZERO;
						//Copy free file available queue to SRAM
						pFileAvailableQueueRead = (T_QMC_DATAFILE_QUEUE*) (pByReadBack + memoryPositionOfFileHeader);
						memcpy(m_pFileAvailableQueue, pFileAvailableQueueRead, sizeof(T_QMC_DATAFILE_QUEUE));
						memoryPositionOfFileHeader += sizeof(T_QMC_DATAFILE_QUEUE);
						memoryPositionOfFileHeader += (m_pMemoryOpData->numOfQueues * sizeof(T_QMC_PERSIST_DATA_BLKQ));
						//copy persisted file available queue to SRAM
						pPersistDataFileQueueRead = (T_QMC_PERSIST_DATAFILE_QUEUE*) (pByReadBack
								+ memoryPositionOfFileHeader);
						memcpy(m_pPersistDataFileQueue, pPersistDataFileQueueRead,
								(m_pMemoryOpData->numOfQueues * sizeof(T_QMC_PERSIST_DATAFILE_QUEUE)));
						memoryPositionOfFileHeader += (m_pMemoryOpData->numOfQueues
								* sizeof(T_QMC_PERSIST_DATAFILE_QUEUE));
						//copy data file header to SRAM
						pDataFileHeader = (T_QMC_DATAFILE_HEADER*) (pByReadBack + memoryPositionOfFileHeader);
						memcpy(m_pFileHeader, pDataFileHeader,
								(m_pMemoryOpData->numOfFiles * sizeof(T_QMC_DATAFILE_HEADER)));
					}
					delete[] pByReadBack;
					return bRetVal;
				}

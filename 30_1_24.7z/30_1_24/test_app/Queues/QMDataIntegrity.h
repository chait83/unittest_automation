/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Queue Manager
/// @n Filename:	QMDataIntergrity.h
/// @n Description: Class Declaration File for the Queue Manager Data Intergrity
///				Tests to be undertaken. 
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 6	Stability Project 1.3.1.1	7/2/2011 5:00:02 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 5	Stability Project 1.3.1.0	7/1/2011 4:27:35 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 4	V6 Firmware 1.3		2/24/2006 8:58:21 PM	Alistair Brugsch
//		implemented data recovery attempts
// 3	V6 Firmware 1.2		2/13/2006 9:25:00 PM	Alistair Brugsch
//		added debug message boxes and Database boot recovery (WIP)
// $
//
// **************************************************************************
#ifndef _QMDATAINTEGRITY_H
#define _QMDATAINTEGRITY_H
#include "QMCommon.h"
/// Enumeration to describe whether the operation of a Member Function has been
/// completed Successfully or a Failure has occurred. 
typedef enum {
	QMDI_TEST_PASSED,
	QMDI_TEST_FAILED,
	QMDI_BLOCKID_TEST_FAILED,
	QMDI_FBQ_TEST_FAILED,
	QMDI_TSBQ_TEST_FAILED,
	QMDI_TDQ_TEST_FAILED,
	QMDI_PBQ_TEST_FAILED
} T_QMDI_RETURN_VALUE;
typedef enum {
	QMDI_FBQ = 0, QMDI_TSBQ, QMDI_TDQ, QMDI_PDBQ,
	QMDI_EOQ, //End of Q TYPEs
} T_QMDI_BLK_Q_TYPE;
typedef struct T_BLOCK_COVERAGE {
	USHORT usCoverage;
	BYTE byFBQ;
	BYTE byTSBQ;
	BYTE byTDQ;
	BYTE byPDBQ;
} SBlockCoverage;
typedef enum {
	QMDI_FAQ = 0, QMDI_PFAQ,
	QMDI_EOF, //End of File TYPEs
} T_QMDI_FILE_Q_TYPE;
typedef struct T_FILE_COVERAGE {
	USHORT usfileCoverage;
	BYTE byFAQ;
	BYTE byPFAQ;
} SFileCoverage;
//**Class*********************************************************************
///
/// @brief ---Single line description---.
/// 
/// --- Detailed Description ---
///
//****************************************************************************
class CQMDataIntegrity {
public:
	/// Constructor
	CQMDataIntegrity(void);
	/// Destructor
	virtual ~CQMDataIntegrity(void);
	/// Test whether the Memory Operational Data has become corrupt.
	T_QMDI_RETURN_VALUE TestMemoryOperationalData(const T_QMC_DATA *const pMemoryOpData);
	/// Test to determine whether all blocks are allocated across the Queues correctly
	T_QMDI_RETURN_VALUE TestBlockCoverage(const T_QMC_BLOCK_QUEUE *const pFreeBlockQueue,
			const T_QMC_BLOCK_QUEUE *const pTempStoredBlockQueue, const T_QMC_BLOCK_QUEUE *const pToDiskQueue,
			T_QMC_PERSIST_DATA_BLKQ *pPersistDataBlockQueue, const T_QMC_BLOCK *const pBlock, const USHORT numOfBlocks,
			const USHORT numOfQueues);
	/// Test to determine whether all files are allocated across the appropiate Queues Correctly
	T_QMDI_RETURN_VALUE TestFileCoverage(const T_QMC_DATAFILE_QUEUE *const pFileAvailableQueue,
			const T_QMC_PERSIST_DATAFILE_QUEUE *const pPersistDataFileQueue,
			const T_QMC_DATAFILE_HEADER *const pFileHeader, const USHORT numOfFiles, const USHORT numOfQueues);
	/// Test Free Block Queue for Completion and Missing / Broken Links
	T_QMDI_RETURN_VALUE TestFreeBlockQueue(const T_QMC_BLOCK_QUEUE *const pFreeBlockQueue,
			const T_QMC_BLOCK *const pBlock, USHORT numOfBlocks);
	/// Test Free Block Queue for Completion and Missing / Broken Links
	T_QMDI_RETURN_VALUE TestTempStoredBlockQueue(const T_QMC_BLOCK_QUEUE *const pTempStoredBlockQueue,
			const T_QMC_BLOCK *const pBlock, USHORT numOfBlocks);
	/// Test Free Block Queue for Completion and Missing / Broken Links
	T_QMDI_RETURN_VALUE TestToDiskQueue(const T_QMC_BLOCK_QUEUE *const pToDiskBlockQueue,
			const T_QMC_BLOCK *const pBlock, USHORT numOfBlocks);
	/// Test Free File Queue for Completion and Missing / Broken Links
	T_QMDI_RETURN_VALUE TestFreeFileQueue(const T_QMC_DATAFILE_QUEUE *const pFileAvailableQueue,
			const T_QMC_DATAFILE_HEADER *const pFileHeader, const USHORT numOfFiles);
	/// Test Each Persisted Block Queue for Completion and M issing / Broken Links
	T_QMDI_RETURN_VALUE TestPersistedBlockQueues(const T_QMC_PERSIST_DATA_BLKQ *const pPersistDataBlockQueue,
			const T_QMC_BLOCK *const pBlock, const USHORT numOfBlocks, const USHORT numOfQueues);
	/// Test Each Persisted File Queue for Completion and Missing / Broken Links
	T_QMDI_RETURN_VALUE TestPersistedFileQueues(const T_QMC_PERSIST_DATAFILE_QUEUE *const pPersistDataFileQueue,
			const T_QMC_DATAFILE_HEADER *const pFileHeader, const USHORT numOfFiles, const USHORT numOfQueues);
	/// Test to determine whether all blocks are allocated across the Queues correctly
	T_QMDI_RETURN_VALUE RecoverBlockCoverage(T_QMC_BLOCK_QUEUE *pFreeBlockQueue,
			T_QMC_BLOCK_QUEUE *pTempStoredBlockQueue, T_QMC_BLOCK_QUEUE *pToDiskQueue,
			T_QMC_PERSIST_DATA_BLKQ *pPersistDataBlockQueue, T_QMC_BLOCK *pBlock, const USHORT numOfBlocks,
			const USHORT numOfQueues);
private: // --- Member Variables --- //
	inline BOOL ValidateBlockId(USHORT usBlockId, const USHORT numOfBlocks);
	inline BOOL ValidateFileId(USHORT usFileId, const USHORT numOfFiles);
	BOOL ValidateBlkQLink(T_QMDI_BLK_Q_TYPE eBlkQType, USHORT usBlockId, const USHORT numOfBlocks,
			const T_QMC_BLOCK *const pBlock, SBlockCoverage *psBlockCoverage);
	inline void UpdateBlockCoverage(T_QMDI_BLK_Q_TYPE eBlkQType, USHORT usBlockId, const T_QMC_BLOCK *const pBlock,
			SBlockCoverage *psBlockCoverage, bool &bLoopDetected);
	inline void UpdateFileCoverage(T_QMDI_FILE_Q_TYPE eFileQType, USHORT usFileId,
			const T_QMC_DATAFILE_HEADER *const pFileHeader, SFileCoverage *psFileCoverage, bool &bLoopDetected);
};
// End of Class Declaration
#endif // _QMDATAINTEGRITY_H

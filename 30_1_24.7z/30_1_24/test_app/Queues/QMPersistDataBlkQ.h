/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  Queue Manager
/// @n Filename:  QMPersistDataBlkQ.h
/// @n Description: Class Declaration for CQMPersistDataBlkQ
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  10  Stability Project 1.7.1.1 7/2/2011 5:00:04 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  9 Stability Project 1.7.1.0 7/1/2011 4:27:36 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  8 V6 Firmware 1.7 9/14/2006 3:55:35 PM  Alistair Brugsch
//  added in functionality to allow clearing of data from chart queues
//  7 V6 Firmware 1.6 2/24/2006 8:57:51 PM  Alistair Brugsch
//  fixed a copy and paste error
// $
//
// **************************************************************************
#ifndef _QMPERSISTDATABLKQ_H
#define _QMPERSISTDATABLKQ_H
#include "QMCommon.h"
#include "QMPersistBlkQAccess.h"
#include "QMMemoryBlkAccess.h"
/// Enumeration to describe whether the operation of a Member Function has been
/// completed Successfully or a Failure has occurred. 
typedef enum {
	QMPDBQ_OK, QMPDBQ_NO_BLOCK_TO_REMOVE
} T_QMPDBQ_RETURN_VALUE;
/// Enumeration to indicate the Status of the Block Queue
typedef enum {
	QMPDBQ_STATUS_EMPTY, QMPDBQ_STATUS_SPACE_AVAILABLE, QMPDBQ_STATUS_FLUSH_TO_DISK_REQUIRED
} T_QMPDBQ_QUEUE_STATUS;
/// Enumeration to indicate the number of blocks to be removed from a queue.
typedef enum {
	QMPDBQ_ALL, QMPDBQ_EXCLUDING_TAIL
} T_QMPDBQ_REMOVE_BLOCK_MODE;
//**Class*********************************************************************
///
/// @brief Linked List Operations for a Persisted Data Block Queues
/// 
/// This class manages the linked list operations on a Specified Data Block Queue,
/// allowing Data Blocks to be Added, Removed and Obtained. Each Persisted Data Block
/// Queue has a Flush to Disk Limit once this limit is reached the Data Blocks within the
/// Queue are flushed to the To Disk Queue ready for Physical Disk.  
///
//****************************************************************************
class CQMPersistDataBlkQ {
public:
	/// Constructor
	CQMPersistDataBlkQ(class CQMPersistBlkQAccess &persistDataBlkQ, class CQMDataBlkAccess &memoryBlockAccess);
	/// Destructor 
	virtual ~CQMPersistDataBlkQ(void);
	/// Enable the Persisted Block Queue for Operation
	T_QMPDBQ_RETURN_VALUE SetupQueue(const USHORT hQueue, const T_QMC_QUEUE_TYPE queueType,
			const USHORT flushToDiskLimit, const T_QMC_QUEUE_CONFIRMATION queueConfirmation, const USHORT UserStatus =
					0xFFFF);
	/// Disable the Specified Presisted Block Queue  
	T_QMPDBQ_RETURN_VALUE ResetQueue(const USHORT hQueue);
	/// Add a Block to the End of the Specified Persisted Block Queue
	T_QMPDBQ_QUEUE_STATUS AddBlockToTail(const USHORT hQueue, const USHORT blockNumber);
	/// Get a pointer to a specified block
	T_QMC_BLOCK* const GetBlock(const USHORT blockId) const;
	/// Obtain a Pointer to the Head Block of the Specified Persisted Block Queue
	T_QMC_BLOCK* const GetHeadBlock(const USHORT hQueue) const;
	/// Remove the Head Block of the Specified Persisted Block Queue
	T_QMPDBQ_RETURN_VALUE RemoveHeadBlock(const USHORT hQueue);
	/// Obtain a Pointer to the Tail Block of the Specified Persisted Block Queue
	T_QMC_BLOCK* const GetTailBlock(const USHORT hQueue) const;
	/// Get the Status of the Specified Persisted Block Queue
	T_QMPDBQ_QUEUE_STATUS GetQueueStatus(const USHORT hQueue) const;
	/// Get the Number of Blocks within the Queue
	USHORT GetNumOfBlocksInQueue(const USHORT hQueue) const;
	/// Remove all Blocks from the Specified Queue
	T_QMPDBQ_RETURN_VALUE RemoveAllBlocks(const USHORT hQueue, const T_QMPDBQ_REMOVE_BLOCK_MODE removeAllMode);
	/// Get the Persisted Data Block Queue
	const T_QMC_PERSIST_DATA_BLKQ& GetPersistDataBlkQ(const USHORT hQueue) const;
	/// Obtain the Block Identification Number based on the Queue Position
	USHORT GetBlockIdFromQueuePos(const USHORT hQueue, const USHORT queuePos);
	/// Display the Queue using the Trace Window - for DEBUG PURPOSES ONLY
	void TraceQueue(const QString pName, const USHORT hQueue);
	///Get the User Defined Status for the queue
	USHORT GetUserStatus(const USHORT hQueue) const;
	///Set the User Defined Status for the queue
	T_QMPBQA_RETURN_VALUE SetUserStatus(const USHORT hQueue, const USHORT UserStatus);
	///Data integrity check support funcs
	T_QMPBQA_RETURN_VALUE SetStatusClear(const USHORT hQueue) {
		return m_PersistDataBlkQAccess.SetStatus(hQueue, QMC_BLKQ_STATUS_QUEUE_SETUP);
	}
	;
	T_QMPBQA_RETURN_VALUE SetStatusNewBlk(const USHORT hQueue) {
		return m_PersistDataBlkQAccess.SetStatus(hQueue, QMC_BLKQ_STATUS_ADD_NEW_BLOCK);
	}
	;
	T_QMPBQA_RETURN_VALUE SetStatusLinkdTDQ(const USHORT hQueue) {
		return m_PersistDataBlkQAccess.SetStatus(hQueue, QMC_BLKQ_STATUS_ADD_LINK_TO_TAIL);
	}
	;
	T_QMPBQA_RETURN_VALUE SetStatusRemBlks(const USHORT hQueue) {
		return m_PersistDataBlkQAccess.SetStatus(hQueue, QMC_BLKQ_STATUS_REMOVE_BLKS);
	}
	;
	T_QMPBQA_RETURN_VALUE SetStatusRelBlk(const USHORT hQueue) {
		return m_PersistDataBlkQAccess.SetStatus(hQueue, QMC_BLKQ_STATUS_RELEASE_BLOCK);
	}
	;
private:
	CQMPersistBlkQAccess &m_PersistDataBlkQAccess; ///< Persist Block Queue Interface Class
	CQMDataBlkAccess &m_MemoryBlockAccess; ///< Member Variable to gain access to the Memory Blocks
};
// End of Class Declaration
#endif // _QMPERSISTDATABLKQ_H

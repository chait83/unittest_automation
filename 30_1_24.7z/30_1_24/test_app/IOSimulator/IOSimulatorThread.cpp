// IOSimulatorThread.cpp : implementation file
//
#include "IOSimulatorThread.h"
#include "IOSimulator.h"
#include "ThreadInfo.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
// CIOSimulatorThread
// IMPLEMENT_DYNCREATE(CIOSimulatorThread, QThread)
CIOSimulatorThread::CIOSimulatorThread() {
}
CIOSimulatorThread::~CIOSimulatorThread() {
}
BOOL CIOSimulatorThread::InitInstance() {
	// TODO: perform and per-thread initialization here
	return TRUE;
}
int CIOSimulatorThread::ExitInstance() {
	// TODO: perform any per-thread cleanup here
	return QThread::ExitInstance();
}
BEGIN_MESSAGE_MAP(CIOSimulatorThread, QThread)
END_MESSAGE_MAP()
//****************************************************************************
/// Thread Function that will Periodically Simulate Channel Data, and prompt
/// the IO Simulator to Populate the Pre Process Queues with Readings upto until
/// the Current System Time. The Thread will also respond to Control Sequencer 
/// Messages to allow Setup Configuration Changes to be undertaken, and controlled
/// Shutdown.  
///
/// @param[in] 	  lpParam - Pointer to IO Simulator
///
/// @return 0x00 - Thread Exit Successful
/// @n 0xFF - Thread could not operate correctly and has terminated
///
//****************************************************************************
UINT CIOSimulatorThread::ThreadFunc(LPVOID lpParam)
{
	const UINT IOSIMTHRD_THREAD_EXIT_SUCCESSFUL = 0x00;  // Constant to represent Thread Exit Code Successful
	const UINT IOSIMTHRD_THREAD_OPERATIONAL_FAILURE = 0xFF;// Constant to represent Thread Exit Code Successful
	const USHORT IOSIMTHRD_THREAD_PERIODIC_UPDATE_TIMEOUT = 250;// Periodic IO Simulator Update Value
	UINT threadExitCode = IOSIMTHRD_THREAD_OPERATIONAL_FAILURE;// Thread Exit Code 
	// Pointer to the IO Simulator
	CIOSimulator *pIOSimulator = static_cast<CIOSimulator*>( lpParam );
	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//after each iteration
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	//Notify that the WatchdogTimer that the IOSimulator thread has 
	//started
	if(pThreadInfo != NULL)
	{
		pThreadInfo->UpdateThreadInfo(AM_IO_SIMULATOR,true);
	}
#ifdef THREAD_ID_SERIAL_LOG
	  WCHAR szDbgMsg[512];
		swprintf( szDbgMsg, L"CIOSimulatorThread::ThreadFunc-Thread id 0x%x, %lu ", GetThreadId(GetCurrentThread()), GetThreadId(GetCurrentThread()));
		OutputDebugString(szDbgMsg);
	#endif
	if( NULL != pIOSimulator )
	{
		// Loop shall remain active until the IO Simulator is required to Exit
		while( IOSIM_OPMODE_EXIT != pIOSimulator->GetOperationalState() )
		{
			// Wait for either a System Message, or a timeout to occur to update the IO Simulator. 
			switch( pIOSimulator->EventMessageHandler( IOSIMTHRD_THREAD_PERIODIC_UPDATE_TIMEOUT ) )
			{
				case V6ACTMOD_EVENT_TIMEOUT:
				if( IOSIM_OPMODE_NORMAL_OPERATION == pIOSimulator->GetOperationalState() )
				{
					// Simulate Channel Data
					pIOSimulator->UpdateIOSimulator();
				} // End of IF
				break;
				default: /* Do Nothing */break;
			} // End of SWITCH
			if(pThreadInfo != NULL)
			{
				//Update the Thread Counter for the IOSimulatorThread
				//after each iteration
				pThreadInfo->UpdateThreadCounter(AM_IO_SIMULATOR);
			}
		} // End of WHILE 
		threadExitCode = IOSIMTHRD_THREAD_EXIT_SUCCESSFUL;
	} // End of IF
	//Update the info that the IOSimulator thread is exiting
	//Hence this thread need not be considered to kick the 
	//watchdog
	if(pThreadInfo != NULL)
	{
		pThreadInfo->UpdateThreadInfo(AM_IO_SIMULATOR);
	}
	return( threadExitCode );
} // End of Member Function
/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	  IO Simulator
/// @n Filename:  AnaloguePulseDemoChannel.h
/// @n Description: Class Implementation for Analogue/Pulse Demo Channel
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  5 Stability Project 1.0.1.3 7/2/2011 4:55:24 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  4 Stability Project 1.0.1.2 7/1/2011 4:37:57 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  3 Stability Project 1.0.1.1 3/17/2011 3:20:09 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  2 Stability Project 1.0.1.0 2/15/2011 3:02:09 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// **************************************************************************
#include "AnaloguePulseDemoChannel.h"
#include "PPQManager.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//****************************************************************************
/// Constructor
///
//****************************************************************************
CAnaloguePulseDemoChannel::CAnaloguePulseDemoChannel(void) {
	m_ChannelNumber = APDEMOCHAN_INVALID_CHANNEL_NUMBER;
	m_slotNo = 0;
	ResetChannel();
} // End of Constructor
//****************************************************************************
/// Destructor
///
//****************************************************************************
CAnaloguePulseDemoChannel::~CAnaloguePulseDemoChannel(void) {
	// --- Do Nothing --- //
} // End of Destructor
//****************************************************************************
/// Initialise the Demo Channel for First Time Use
///
/// @param[in] 	  channelNumber - Number of the Channel
/// @param[in] 	  slotNo - the slot number
/// @param[in] 	  boardChanNo - the board channel number
///
/// @return APDEMOCHAN_OK - Analogue/Pulse Demo Channel Initialised Successfully
/// 
//****************************************************************************
T_APDEMOCHAN_RETURN_VALUE CAnaloguePulseDemoChannel::Initialise(const USHORT channelNumber, const USHORT slotNo,
		const USHORT boardChanNo) {
	T_APDEMOCHAN_RETURN_VALUE retValue = APDEMOCHAN_OK;
	m_ChannelNumber = channelNumber;
	m_slotNo = slotNo;
	m_boardChanNo = boardChanNo;
	return (retValue);
} // End of Member Function
//****************************************************************************
/// Setup the Channel according to the required parameters, and configure the
/// Input Wave for operation with the passed paramaters.
///
/// @param[in] 	acqRate - Acquiisiton Rate of the Channel
/// @param[in] zero  - Engineering Zero for the Channel
/// @param[in] span  - Engineering Span for the Channel
/// @param[in] noise  - %age of span to generate noise.
/// @param[in] waveType  - T_DEMOWAVE_TYPES of demo wave required
/// @param[in] waveDuration  - duration in seconds of one complete wave (Ignored for UI types)
/// @param[in] sourceTickRate - source rate in ticks(1/100) per second that data will be requested
///
/// @return APDEMOCHAN_OK - Channel Setup Successfully
///
//****************************************************************************
T_APDEMOCHAN_RETURN_VALUE CAnaloguePulseDemoChannel::SetupChannel(const T_BRDCHANDEF_ACQUSITION_RATE acqRate,
		const FLOAT zero, const FLOAT span, const FLOAT noise, const T_DEMOWAVE_TYPES waveType, const INT waveDuration,
		const INT sourceTickRate) {
	T_APDEMOCHAN_RETURN_VALUE retValue = APDEMOCHAN_OK;
	// Enable the Channel 
	m_ChannelStatus = APDEMOCHAN_CHANNEL_ENABLED;
	m_AcquisitionRate = acqRate;
	m_DemoWave.ConfigureDemoWave(m_ChannelNumber, m_slotNo, m_boardChanNo, zero, span, noise, waveType, waveDuration,
			sourceTickRate);
	return (retValue);
} // End of Member Function 
//****************************************************************************
/// Reset the Channel to a Default State, to allow the Channel to be Setup.
///
/// @param[in] 	- NONE
///
/// @return APDEMOCHAN_OK - Channel has been Reset Correctly
///
//****************************************************************************
T_APDEMOCHAN_RETURN_VALUE CAnaloguePulseDemoChannel::ResetChannel(void) {
	T_APDEMOCHAN_RETURN_VALUE retValue = APDEMOCHAN_OK;
	m_hPPQ = PPQC_INVALID_REFERENCE;
	m_ChannelStatus = APDEMOCHAN_CHANNEL_DISABLED;
	m_AcquisitionRate = BRDCHANDEF_1HZ;
	m_ChannelStatus = APDEMOCHAN_CHANNEL_DISABLED;
	return (retValue);
} // End of Member Function 
//****************************************************************************
/// Acquire a simulated reading that has an associated timestamp in Board Ticks
/// and Populate the Pre Process Queue for that Channel  
///
/// @param[in] 	readingTick - Timestamp in Board Tick of the Reading
///
/// @return No Return Value
///
//****************************************************************************
void CAnaloguePulseDemoChannel::ProcessFirstReading(const USHORT readingTick) {
	CPPQManager *pPPQManager = CPPQManager::GetHandle();
	if (NULL != pPPQManager) {
		// Add First Reading
		pPPQManager->m_APPPQServices.AddTimeStampedReading(m_hPPQ, m_DemoWave.GetDemoValue(), readingTick);
	} // End of IF
} // End of Member Function
//****************************************************************************
/// Acquire a simulated reading and Populate the Pre Process Queue for that Channel,
/// for the number of additional readings required. 
///
/// @param[in] 	numOfAdditionalReadings - Number of Additional Readings to Simulate
///
/// @return No Return Value
///
//**************************************************************************** 
void CAnaloguePulseDemoChannel::ProcessAdditionalReadings(const USHORT numOfAdditionalReadings) {
	CPPQManager *pPPQManager = CPPQManager::GetHandle();
	if (NULL != pPPQManager) {
		// Process Additional Readings
		for (USHORT readingIndex = 0; readingIndex < numOfAdditionalReadings; ++readingIndex) {
			pPPQManager->m_APPPQServices.AddReading(m_hPPQ, m_DemoWave.GetDemoValue());
		} // End of FOR
	} // End of IF
} // End of Member Function

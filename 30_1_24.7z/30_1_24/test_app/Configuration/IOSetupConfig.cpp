/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 Configuration
/// @n IOSetupConfig.cpp
/// @n implementation to handle creating default configurations
///  and getting CMM configuration for I/O boards.
/// @author GKW
/// @date 22/09/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
//  88  Stability Project 1.83.1.3 7/2/2011 4:58:02 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  87  Stability Project 1.83.1.2 7/1/2011 4:38:22 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  86  Stability Project 1.83.1.1 3/17/2011 3:20:26 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  85  Stability Project 1.83.1.0 2/15/2011 3:03:11 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////
#include "../inc/SlotMap.h"
#include "../inc/V6defines.h"
#include "../common/CMMDefines.h"
#include "../Configuration/V6Config.h"
#include "../Configuration/IOSetupConfig.h"
#include "../inc/SetupConfiguration.h"
#include "../inc/V6ResourceBase.h"
#include "../inc/V6UIResource.h"
#include "../inc/V6globals.h"
#include "../IOSched/ATECal.h"
#include "../AMS2750/AMS2750InputCalMgr.h"
#include "../AMS2750/AMS2750ProcessCalFile.h"
#include "../AMS2750/AMS2750TUSMgr.h"
#include "../IOSched/BrdInfo.h"
#include "../DAL_OP/DevCaps.h"
#include "../IOCond/InputConditioning.h"
#include "../inc/StringDefinitions.h"
#include "../Configuration/GeneralSetupConfig.h"
#include "../inc/hw_defs.h"
#include "../Persist/flash.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
extern QMutex m_GlbSetupMutex;
CIOSetupConfig::CIOSetupConfig(void) {
//	qDebug("Create new CIOSetupConfig\n");
	m_pSlotMapObj = CSlotMap::GetHandle();
	// update the AMS2750 sensor information
	LoadAMS2750SensorBlockFromNV();
}
CIOSetupConfig::~CIOSetupConfig(void) {
//	qDebug("Deleting CIOSetupConfig class\n");
}
//******************************************************
///
/// Creates this services default configuration.
///
/// @return CONFIG_OK if succesful creation; otherwise CONFIG_ERROR
/// 
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::CreateServiceDefaultConfig(void) {
	T_CONFIG_RETURN_VALUE retValue = CONFIG_OK;
	retValue = CreateRecorderSlots();		// Create the recorder slots
	if (retValue == CONFIG_OK)
		retValue = CreateTopSlotRecorderCalInfo();		// Create the recorder calibration data
	return (retValue);
} // End of Member Function
//**********************************************************************
///
/// Function that is called immediately before a setup config is commited
/// to the CMM.
///
/// @return		T_CONFIG_RETURN_VALUE return value
/// 
//**********************************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::PreCommitProcessing(void) {
	QString strRenewalDateChangedMsg("");
	QString strCalDateChangedMsg("");
	QString strPrevDate("");
	QString strNewDate("");
	CTVtime kTime;
	// check for any differences between the AMS2750 sensor renewal dates and calibration dates
	for (USHORT usSensorCount = 0; usSensorCount < AMS2750SENSORS_SENSORS_SIZE; usSensorCount++) {
		T_AMS2750SENSOR *committedSensor = &m_AMS2750SensorsCommitted.Sensors[usSensorCount];
		T_AMS2750SENSOR *workingSensor = &m_AMS2750SensorsWorking.Sensors[usSensorCount];
		// check the renewal dates first
		if (committedSensor->DateRenewed != workingSensor->DateRenewed) {
			bool isTC = IsAnalogueSetupAsTC(usSensorCount);
#if (!defined DOCVIEW) && (!defined TTR6SETUP)
			// log a system message
			/// TODO : Uncomment DateAsString API in ctvtime
			kTime = static_cast<LONGLONG>(committedSensor->DateRenewed) * USEC_IN_A_SEC;
            kTime.DateAsString(strPrevDate);
			kTime = static_cast<LONGLONG>(workingSensor->DateRenewed) * USEC_IN_A_SEC;
			kTime.DateAsString(strNewDate);
            strRenewalDateChangedMsg = QString::asprintf("%s renewal date changed from %s to %s",
                    CAMS2750TUSMgr::buildSensorName(usSensorCount + 1, isTC).toStdString().c_str(), strPrevDate.toStdString().c_str(), strNewDate.toStdString().c_str());
			LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_INFORMATION, strRenewalDateChangedMsg);
#endif
		}
		// now check the renewal dates first
		if (committedSensor->NextCalibDate != workingSensor->NextCalibDate) {
			bool isTC = IsAnalogueSetupAsTC(usSensorCount);
#if (!defined DOCVIEW) && (!defined TTR6SETUP)
			// log a system message
			kTime = static_cast<LONGLONG>(committedSensor->NextCalibDate) * USEC_IN_A_SEC;
			kTime.DateAsString(strPrevDate);
			kTime = static_cast<LONGLONG>(workingSensor->NextCalibDate) * USEC_IN_A_SEC;
			kTime.DateAsString(strNewDate);
            strCalDateChangedMsg = QString::asprintf("%s calibration date changed from %s to %s",
                    CAMS2750TUSMgr::buildSensorName(usSensorCount + 1, isTC).toStdString().c_str(), strPrevDate.toStdString().c_str(), strNewDate.toStdString().c_str());
			LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_INFORMATION, strCalDateChangedMsg);
#endif
		}
	}
	// update the committed AMS2750 sensor data
	UpdateAMS270SensorCommittedWithWorking();
	// update the NV Multi Point data
	T_PMPCALCHANNELS pWorkingMpChannelCal = GetMultiPointBlock(CONFIG_MODIFIABLE);
	T_PMPCALCHANNELS pCommittedMpChannelCal = GetMultiPointBlock(CONFIG_COMMITTED);
	CGeneralSetupConfig *pkGenCfg = pSETUP->GetGeneralSetupConfig();
	T_AMS2750CALCFG *ptCalConfig = pkGenCfg->GetAMS2750CalibrationBlock(CONFIG_MODIFIABLE);
	const ULONG lastInputCalTestDate = ptCalConfig->TestDate;
	// Check if block exists, if yes then update the NV copy
	if (pWorkingMpChannelCal != NULL) {
		// sanity check the multi-point cal elements as we've seen some invalid values
		for (USHORT usChanCount = 0; usChanCount < MPCALCHANNELS_CHANNEL_SIZE; usChanCount++) {
			T_MPCALCHANNEL *modifiableChannel = &pWorkingMpChannelCal->Channel[usChanCount];
			if (modifiableChannel->CalElements > MPCALCHANNEL_CALPOINTS_SIZE) {
				// this is an invalid value, report it and reset to 0
				QString errorMessage;
				errorMessage = QString::asprintf("Invalid multi-point cal. value for analogue input %d, defaulted",
						usChanCount + 1);
				LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, errorMessage);
				modifiableChannel->CalElements = 2;
				modifiableChannel->CalPoints[0].CalPoint = 0.0;
				modifiableChannel->CalPoints[0].Offset = 0.0;
				modifiableChannel->CalPoints[1].CalPoint = 1.0;
				modifiableChannel->CalPoints[1].Offset = 0.0;
			}
		}
		if (pCommittedMpChannelCal != NULL) {
			// check for any differences between the working and committed cals
			for (USHORT usChanCount = 0; usChanCount < MPCALCHANNELS_CHANNEL_SIZE; usChanCount++) {
				T_MPCALCHANNEL *committedChannel = &pCommittedMpChannelCal->Channel[usChanCount];
				T_MPCALCHANNEL *workingChannel = &pWorkingMpChannelCal->Channel[usChanCount];
				// check if any of the cal points have changed
				T_MPCALPOINT *committedCalPoints = committedChannel->CalPoints;
				float *committedPrevCalPoints = committedChannel->PrevCalPoints;
				T_MPCALPOINT *workingCalPoints = workingChannel->CalPoints;
				float *workingPrevCalPoints = workingChannel->PrevCalPoints;
				for (int calPointIndex = 0; calPointIndex < MPCALCHANNEL_CALPOINTS_SIZE; calPointIndex++) {
					// only perform this check if the input cal dates match which implies this is not following an
					// input calibration or the dates don't match but the new cal date is not the same as the last overall
					// input cal date which implies the user has manaully changed the cal date
					if ((pCommittedMpChannelCal->LastCalDate[usChanCount]
							== pWorkingMpChannelCal->LastCalDate[usChanCount])
							|| (pWorkingMpChannelCal->LastCalDate[usChanCount] != lastInputCalTestDate)) {
						// check this point is even valid
						if ((int) workingChannel->CalElements > calPointIndex) {
							// find the current cal point in the working, find a match in the committed, then check
							// to see if they've changed. If yes the copy the current committed cal point to the 
							// previous cal point in the working
							for (int commCalPointIndex = 0; commCalPointIndex < MPCALCHANNEL_CALPOINTS_SIZE;
									commCalPointIndex++) {
								if ((int) committedChannel->CalElements > commCalPointIndex) {
									if (committedCalPoints[commCalPointIndex].CalPoint
											== workingCalPoints[calPointIndex].CalPoint) {
										// this is a match, check if the offset has changed
										if (committedCalPoints[commCalPointIndex].Offset
												== workingCalPoints[calPointIndex].Offset) {
											// the offset's match so no change - replace previous with the existing previous which it
											// probably is anyway unless a load of inserts and removes of the same values took place
											workingPrevCalPoints[calPointIndex] =
													committedPrevCalPoints[commCalPointIndex];
										} else {
											// the offset's don't match so copy the previous offset to the working previous
											workingPrevCalPoints[calPointIndex] =
													committedCalPoints[commCalPointIndex].Offset;
										}
										// exit this inner loop as a match was found
										break;
									}
								} else {
									// we've exceeded the cal points and thus won't find a match - ensure the previous is 0.0
									workingPrevCalPoints[calPointIndex] = 0.0F;
									// break from this inner loop as no more readings to check
									break;
								}
							}
						} else {
							// we've exceeded the cal points so just ensure the previous cal point is zero in this case
							workingPrevCalPoints[calPointIndex] = 0.0F;
						}
					}
				}
			}
		}
		UpdateMultiPointNVFromCMM(pWorkingMpChannelCal);
	}
#if (!defined DOCVIEW) && (!defined TTR6SETUP)
	// check the in-memory/saved calibration matches the new config
	ValidateAMS2750Calibration();
#endif
	return CONFIG_OK;
}
#if (!defined DOCVIEW) && (!defined TTR6SETUP)
//*************************************************************************************
///
/// Validates the AMS2750 calibration against any newly modified changes to the cal
///
//*************************************************************************************
void CIOSetupConfig::ValidateAMS2750Calibration() {
	// check this recorder is configured for AMS2750
	if (pSYSTEM_INFO->GetAMS2750Mode() != AMS2750_NONE) {
		CAMS2750InputCalMgr *pkCalMgr = new CAMS2750InputCalMgr();
		pkCalMgr->PrecommitValidateCal();
		delete pkCalMgr;
	}
}
#endif
//*************************************************************************************
/// Determine if the analogue input is a TC
///
///
/// @return T_CONFIG_RETURN_VALUE indicating status of call
/// 
//*************************************************************************************
bool CIOSetupConfig::IsAnalogueSetupAsTC(const USHORT usSensorCount) {
	USHORT usSlotNo = 0;
	USHORT usBoardChanNum = 0;
	// check the slot number and board channel number are okay and that an analogue input card exists in this slot
	if (indexOfBoardSlotAndChannel(usSensorCount + 1, &usSlotNo, &usBoardChanNum)) {
		// Get the pen data structure
		T_PAICHANNEL ptAnalogueData = NULL;
		ptAnalogueData = GetAnalogueInput(usSlotNo, usBoardChanNum, CONFIG_MODIFIABLE);
		// Check we managed to obtain a pen
		if (ptAnalogueData != NULL) {
			if (ptAnalogueData->Type != AI_CHANNEL_TYPE_TC) {
				return false;
			}
		}
	}
	return true;
}
//*************************************************************************************
/// Validate the configuration items when a config has been loaded and is about to be commited
///
///
/// @return T_CONFIG_RETURN_VALUE indicating status of call
/// 
//*************************************************************************************
T_CONFIG_VALIDATE_RETURN CIOSetupConfig::ValidateServiceConfig(void) {
	T_CONFIG_VALIDATE_RETURN retValue = CONFIG_VALIDATE_NO_CHANGES;
	CDeviceCaps PrevDevCaps;
	T_DEVICECAPS PrevDevCapsData;
	// Get the previous recorder configuration
	GetPreviousRecorderConfig(&PrevDevCapsData);
	PrevDevCaps.SetPtrToDeviceCaps(&PrevDevCapsData);
	// Run through and align IO configurtion with actual IO hardware in system
#ifndef DOCVIEW
#ifndef TTR6SETUP
	// update the CMM with the NVRAM calibration data 
	CPPIOServiceManager *pkServiceManagerObj = NULL; ///< Service manager
	CInputConditioning *pkICService = NULL; ///< Input conditioning service
	pkServiceManagerObj = CPPIOServiceManager::GetHandle();
	if (pkServiceManagerObj != NULL) {
		pkICService = pkServiceManagerObj->GetICService();
		// make sure we have the NV data loaded and is valid (which it won't be on first time run)
		if (pkICService->IOCalLoad()) {
			// now update the CMM with the NVRAM data
			pkICService->RecorderCalCMMDump();
		}
	}
#endif
#endif
	for (USHORT slotNo = 0; slotNo < GlbDevCaps.GetIOCardInfo(); slotNo++) {
		// Run validate and modify routine, if any changes are made set the return value to indicate this
		// note: do not set return value directly as this would overwrite possible changes.
		if (ValidateAndAlignBoardCMM(slotNo, &PrevDevCaps) == CONFIG_VALIDATE_CHANGES_MADE) {
			retValue = CONFIG_VALIDATE_CHANGES_MADE;
		}
	}
#ifndef DOCVIEW
	// Check the CMM I/O calibration structures
	if (ResetProcessedCMMToUserCalSet() == CONFIG_VALIDATE_CHANGES_MADE) {
		retValue = CONFIG_VALIDATE_CHANGES_MADE;
	}
	// check if in AMS2750 TUS mode or process mode
	if ( pSYSTEM_INFO->FWOptionAMS2750ProcessAvailable()) {
		bool bSensorChanged = false;
		// we are in process mode therefore we need to reset the TUS flags in the AMS2750 sensor configurations
		// in order to simplify the TC AMS2750 status code
		for (USHORT usSensor = 0; usSensor < AMS2750SENSORS_SENSORS_SIZE; usSensor++) {
			// check if this TC is configured to be a TUS TC
			if (m_AMS2750SensorsWorking.Sensors[usSensor].TUSTC) {
				m_AMS2750SensorsWorking.Sensors[usSensor].TUSTC = FALSE;
				bSensorChanged = true;
			}
		}
		// check if we had to change any of the sensor information
		if (bSensorChanged) {
			// update the committed structure and the NV
			UpdateAMS270SensorCommittedWithWorking();
		}
	} else if ( pSYSTEM_INFO->FWOptionTUSModeAvailable()) {
		bool bSensorChanged = false;
		// we are in TUS mode therefore we need to reset the load flags in the AMS2750 sensor configurations
		// in order to simplify the TC AMS2750 status code
		for (USHORT usSensor = 0; usSensor < AMS2750SENSORS_SENSORS_SIZE; usSensor++) {
			// check if this TC is configured to be a load TC
			if (m_AMS2750SensorsWorking.Sensors[usSensor].LoadTC) {
				m_AMS2750SensorsWorking.Sensors[usSensor].LoadTC = FALSE;
				bSensorChanged = true;
			}
		}
		// check if we had to change any of the sensor information
		if (bSensorChanged) {
			// update the committed structure and the NV
			UpdateAMS270SensorCommittedWithWorking();
		}
	}
#endif
	// Validate the recorder calibration block block
	T_PRECORDERCAL pRecCal = GetTopSlotRecorderCalInfo(CONFIG_MODIFIABLE);
	// Check if block exists, if not create
	if (pRecCal == NULL) {
		// Block does not exist so create and update the structure
		CreateTopSlotRecorderCalInfo();
		retValue = CONFIG_VALIDATE_CHANGES_MADE;
	}
	// validate the multipoint cal block
	T_PMPCALCHANNELS pMPChannelCal = GetMultiPointBlock(CONFIG_MODIFIABLE);
	// Check if block exists, if not create, otherwise check for any compatablility issues	
	if (pMPChannelCal == NULL) {
		// Block does not exist so create
		pMPChannelCal = CreateTCMultipointCalBlock();
		if (pMPChannelCal == NULL) {
			// the config didn't get created properly
			retValue = CONFIG_VALIDATE_INVALID;
		} else {
#ifndef TTR6SETUP
			// ensure the cal reflects the cal in NV
			UpdateMultiPointCMMFromNV(pMPChannelCal);
#endif
		}
		retValue = CONFIG_VALIDATE_CHANGES_MADE;
	} else
#ifndef TTR6SETUP
		// ensure the cal reflects the cal in NV
		UpdateMultiPointCMMFromNV(pMPChannelCal);
#endif
	return (retValue);
}
//******************************************************
// GetPreviousRecorderConfig()
///
/// Obtain the saved Device Caps from the CMM.
///
/// @return creation sucess state
/// 
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::GetPreviousRecorderConfig(const T_DEVICECAPS *const pPrevDevCaps) {
	BLOCK_INFO blockInfo;
	T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;
	CMMERROR err = CMM_FAILED;
	// Update CMM default device capabilities
	blockInfo.wInstanceID = ONLY_ONE_INST;
	blockInfo.wBlockType = BLK_DEVICECAPS;
	/// TODO : Implementation of GetDataBlock
	err = GetDataBlock(m_ConfigurationId, &blockInfo, CONFIG_MODIFIABLE);
	if (err == CMM_SUCCESS) {
		// Copy over the previous I/O board device capabilities
		memcpy((void*) pPrevDevCaps, (void*) blockInfo.pByBlock, (size_t) blockInfo.dwBlockSize);
		retValue = CONFIG_OK;
	}
	return retValue;
}
//******************************************************
// AnyEnabledEvents()
///
/// Are there any enabled events configured in the CMM.
///
/// @return TRUE if there is at least a single event enabled; otherwise FALSE
/// 
//******************************************************
BOOL CIOSetupConfig::AnyEnabledEvents() {
	class CEventSetupConfig *pEventConfig = NULL;
	T_EVENTSYSTEM *pEventBlk = NULL;
	T_PEVENT pEvent = NULL;
	USHORT usEventNo = 0;
	BOOL retValue = FALSE;
	pEventConfig = pSETUP->GetEventSetupConfig();
	pEventBlk = pEventConfig->GetEventBlock(CONFIG_COMMITTED);
	for (usEventNo = 0; usEventNo < V6_MAX_EVENTS; usEventNo++) {
		pEvent = &pEventBlk->Event[usEventNo];
		if ((pEvent != NULL) && (TRUE == pEvent->Enabled)) {
			// Register and leave if any event is enabled
			retValue = TRUE;
			break;
		}
	}
	return retValue;
}
//******************************************************
// CreateRecorderSlots()
///
/// Create the default configuration for an Analogue Input channel in the CMM.
/// @todo: Update the board and channel labels from resource table
///
/// @return creation sucess state
/// 
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::CreateRecorderSlots(void) {
	T_CONFIG_RETURN_VALUE ret = CONFIG_ERROR;
	T_CONFIG_RETURN_VALUE retValue = CONFIG_OK;
	CMMERROR err = CMM_FAILED;
	BLOCK_INFO blockInfo;
	USHORT slotNo = RECORDER_SLOT_A;
	USHORT chanNumber = SLOT_CHANNEL_0;
	// Create a default recorder config for each slot
	do {
		ret = CreateDefaultBoard(slotNo);
		if (ret == CONFIG_OK) {
			if ( DEVICE_INFO.GetSlotPosition(slotNo) == SLOT_TOP) {
				// Top slot cards being created
				// Update the run-time parameters for the AI channel
				for (chanNumber = SLOT_CHANNEL_0; chanNumber < TOPSLOT_AICHAN_SIZE; chanNumber++) {
					ret = CreateDefAIChan(slotNo, chanNumber);
					if (ret != CONFIG_OK)
						retValue = ret;
				}
				// Update the run-time parameters for the AO channel
				for (chanNumber = SLOT_CHANNEL_0; chanNumber < TOPSLOT_AOCHAN_SIZE; chanNumber++) {
					ret = CreateDefAOChan(slotNo, chanNumber);
					if (ret != CONFIG_OK)
						retValue = ret;
				}
				// Update the run-time parameters for the pulse channel on top slot boards
				for (chanNumber = SLOT_CHANNEL_0; chanNumber < TOPSLOT_PULSECHAN_SIZE; chanNumber++) {
					ret = CreateDefTopPulseChan(slotNo, chanNumber);
					if (ret != CONFIG_OK)
						retValue = ret;
				}
			} else if ( DEVICE_INFO.GetSlotPosition(slotNo) == SLOT_BOTTOM) {
				// Bottom slot cards being created
				// Update the run-time parameters for the digital channel
				for (chanNumber = SLOT_CHANNEL_0; chanNumber < BOTTOMSLOT_DIGCHAN_SIZE; chanNumber++) {
					ret = CreateDefDigitalChan(slotNo, chanNumber);
					if (ret != CONFIG_OK)
						retValue = ret;
				}
			}
			slotNo++;
		}
	} while ((slotNo <= RECORDER_SLOT_I) && (ret == CONFIG_OK));
	if (ret == CONFIG_OK) {
		// Update CMM default device capabilities
		blockInfo.wInstanceID = ONLY_ONE_INST;
		blockInfo.wBlockType = BLK_DEVICECAPS;
		err = GetDataBlock(m_ConfigurationId, &blockInfo, CONFIG_MODIFIABLE);
		if (err == CMM_SUCCESS) {
			// Populate the CMM default device capabilities with real value from the global device capabilities
			memcpy((void*) blockInfo.pByBlock, (void*) DEVICE_INFO.GetPtrToDeviceCaps(),
					(size_t) blockInfo.dwBlockSize);
			err = ModifyDataBlock(m_ConfigurationId, &blockInfo);
		}
	}
	// Default config was not generated
	if ((err != CMM_SUCCESS) || (retValue != CONFIG_OK))
		return CONFIG_ERROR;
	return CONFIG_OK;
}
//******************************************************
// CreateDefAIChan()
///
/// Create the default configuration for an Analogue Input channel in the CMM.
/// @param[in] slotNumber - The recorder I/O board slot number.
/// @param[in] chanNumber - The recorder based channel number.
///
/// @return creation sucess state
/// 
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::CreateDefAIChan(const USHORT slotNumber, const USHORT chanNumber) {
	T_PTOPSLOT pTopSlot = NULL;
	T_PAICHANNEL pAIChan = NULL;
	T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;
	class CSlotMap *pSlotMap = NULL;
	pTopSlot = GetTopSlot(slotNumber, CONFIG_MODIFIABLE);
	if (pTopSlot != NULL) {
		pAIChan = static_cast<T_PAICHANNEL>(&pTopSlot->AIChan[chanNumber]);
		pSlotMap = CSlotMap::GetHandle();
		if (pSlotMap != NULL) {
			// Allocate the pen with the correct instance, default label and tie to relevant pen
			pAIChan->Instance = pSlotMap->GetSysChannelFromAnaInChannel(slotNumber, chanNumber, ONE_BASED) - 1;
			swprintf(pAIChan->Label, AOCHANNEL_LABEL_LEN, L"A%d", pAIChan->Instance + 1);
			pAIChan->TiedTo = pAIChan->Instance;
			retValue = CONFIG_OK;
		}
	}
	return retValue;
}
//******************************************************
// CreateDefAOChan()
///
/// Create the default configuration for an Analogue Input channel in the CMM.
/// @param[in] slotNumber - The recorder I/O board slot number.
/// @param[in] chanNumber - The recorder based channel number.
///
/// @return creation sucess state
/// 
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::CreateDefAOChan(const USHORT slotNumber, const USHORT chanNumber) {
	T_PTOPSLOT pTopSlot = NULL;
	T_PAOCHANNEL pAOChan = NULL;
	T_PPEN pPen = NULL;
	T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;
	class CSlotMap *pSlotMap = NULL;
	USHORT penNo = 0;
	pTopSlot = GetTopSlot(slotNumber, CONFIG_MODIFIABLE);
	if (pTopSlot != NULL) {
		pAOChan = static_cast<T_PAOCHANNEL>(&pTopSlot->AOChan[chanNumber]);
		pSlotMap = CSlotMap::GetHandle();
		if (pSlotMap != NULL) {
			for (penNo = 0; penNo < V6_MAX_PENS; penNo++) {
				pPen = NULL;
				if ( pSYSTEM_INFO->IsPenAvailable(penNo, ZERO_BASED) == TRUE) {
                //	CSingleLock lock(&m_GlbSetupMutex);
                    m_GlbSetupMutex.lock();
					pPen = pGlbSetup->GetPenSetupConfig()->GetPen(penNo, ZERO_BASED, CONFIG_MODIFIABLE);
                    m_GlbSetupMutex.lock();
				}
				if ((pPen != NULL) && (pPen->Enabled == TRUE)) {
					pAOChan->PenNo = penNo;								///< Retransmit the first available pen
					break;												///< Look no further
				}
			}
			pAOChan->Instance = pSlotMap->GetSysChannelFromAnaOutChannel(slotNumber, chanNumber, ONE_BASED) - 1;
			swprintf(pAOChan->Label, AOCHANNEL_LABEL_LEN, L"AO%d", pAOChan->Instance + 1);
			retValue = CONFIG_OK;
		}
	}
	return retValue;
}
//******************************************************
// CreateDefDigitalChan()
///
/// Create the default configuration for an Digital channel in the CMM.
/// @param[in] slotNumber - The recorder I/O board slot number.
/// @param[in] chanNumber - The recorder based channel number.
///
/// @return creation sucess state
/// 
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::CreateDefDigitalChan(const USHORT slotNumber, const USHORT chanNumber) {
	T_PBOTTOMSLOT pBottomSlot = NULL;
	T_PDIGCHANNEL pDigitalChan = NULL;
	T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;
	class CSlotMap *pSlotMap = NULL;
	pBottomSlot = GetBottomSlot(slotNumber, CONFIG_MODIFIABLE);
	if (pBottomSlot != NULL) {
		pDigitalChan = static_cast<T_PDIGCHANNEL>(&pBottomSlot->DigChan[chanNumber]);
		pSlotMap = CSlotMap::GetHandle();
		if (pSlotMap != NULL) {
			pDigitalChan->Instance = pSlotMap->GetSysChannelFromDigIOChannel(slotNumber, chanNumber, ONE_BASED) - 1;
			swprintf(pDigitalChan->Label, AOCHANNEL_LABEL_LEN, L"D%d", pDigitalChan->Instance + 1);
			retValue = CONFIG_OK;
		}
	}
	return retValue;
}
//******************************************************
// CreateDefTopPulseChan()
///
/// Create the default configuration for a Pulse Input channel in the CMM.
/// @param[in] slotNumber - The recorder I/O board slot number.
/// @param[in] chanNumber - The recorder based channel number.
///
/// @return creation sucess state
/// 
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::CreateDefTopPulseChan(const USHORT slotNumber, const USHORT chanNumber) {
	T_PTOPSLOT pTopSlot = NULL;
	T_PPULSECHANNEL pPulseChan = NULL;
	T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;
	class CSlotMap *pSlotMap = NULL;
	pTopSlot = GetTopSlot(slotNumber, CONFIG_MODIFIABLE);
	if (pTopSlot != NULL) {
		pPulseChan = static_cast<T_PPULSECHANNEL>(&pTopSlot->PulseChan[chanNumber]);
		pSlotMap = CSlotMap::GetHandle();
		if (pSlotMap != NULL) {
			pPulseChan->Instance = pSlotMap->GetSysChannelFromDedicatedPulseChannel(slotNumber, chanNumber, ONE_BASED)
					- 1;
			swprintf(pPulseChan->Label, AOCHANNEL_LABEL_LEN, L"PI%d", pPulseChan->Instance + 1);
			retValue = CONFIG_OK;
		}
	}
	return retValue;
}
//******************************************************
// CreateDefaultBoard()
///
/// Create a default CMM configuration in a specified recorder slot,
/// using the slot information from the device capabilities table.
/// @param[in] slotNumber - The recorder I/O board slot number.
///
/// @return channel type creation sucess state
/// 
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::CreateDefaultBoard(const USHORT slotNumber) {
	USHORT chanNo;
	T_PTOPSLOT pTopSlot = NULL;
	T_PBOTTOMSLOT pBottomSlot = NULL;
	T_CONFIG_RETURN_VALUE retValue = CONFIG_OK;
	if ( DEVICE_INFO.GetSlotPosition(slotNumber) == SLOT_TOP) {
		// Top slot cards being accessed
		pTopSlot = CreateTopSlot(slotNumber);
		if (pTopSlot == NULL) {
			retValue = CONFIG_ERROR;
		} else {
			pTopSlot->SlotNumber = slotNumber;
			// Use the device capabilities table to create the safest channel set
			// Nothing special is required for AO & Pulse cards
			for (chanNo = 0; chanNo < TOPSLOT_AICHAN_SIZE; chanNo++) {
				switch (DEVICE_INFO.GetSlotType(slotNumber)) {
				case BOARD_AI:
				case BOARD_EZ_AI:
					// Make all AI board channels for reading volts
					pTopSlot->AIChan[chanNo].Type = AI_CHANNEL_TYPE_LINEAR_VOLTS;
					break;
				}
			}
		}
	} else if ( DEVICE_INFO.GetSlotPosition(slotNumber) == SLOT_BOTTOM) {
		// Bottom slot cards being accessed
		pBottomSlot = CreateBottomSlot(slotNumber);
		if (pBottomSlot == NULL) {
			retValue = CONFIG_ERROR;
		} else {
			pBottomSlot->SlotNumber = slotNumber;
			// Use the device capabilities table to create the safest channel set
			for (chanNo = 0; chanNo < BOTTOMSLOT_DIGCHAN_SIZE; chanNo++) {
				switch (DEVICE_INFO.GetSlotType(slotNumber)) {
				case BOARD_AR:
				case BOARD_DIO:
					// Make all digital board channels latched outputs
					pBottomSlot->DigChan[chanNo].DigO.OPLatched = DO_CHANNEL_LATCHED;
					break;
				}
			}
		}
	}
	return retValue;
}
//******************************************************
///
/// Check the CMM I/O calibration structure for a calibration required.
///
/// @return CONFIG_VALIDATE_CHANGES_MADE if any calibration required otherwise CONFIG_VALIDATE_NO_CHANGES.
/// 
//******************************************************
T_CONFIG_VALIDATE_RETURN CIOSetupConfig::CheckCMMForUserCalSet(void) {
	USHORT slotNo = 0;
	USHORT rangeNo = 0;
	USHORT chanNo = 0;
	T_RECORDERCAL *pCMMRecorderCal = NULL;
	T_CONFIG_VALIDATE_RETURN retValue = CONFIG_VALIDATE_NO_CHANGES;
	pCMMRecorderCal = GetTopSlotRecorderCalInfo(CONFIG_MODIFIABLE);
	if (pCMMRecorderCal != NULL) {
		for (slotNo = 0; slotNo < RECORDERCAL_RECORDERCALS_SIZE; slotNo++) {
			if (retValue == CONFIG_VALIDATE_CHANGES_MADE)
				break;
			// @todo: Only check the number of avaialable channels on each board actually fitted
			for (chanNo = 0; chanNo < IORANGECAL_CHANNEL_SIZE; chanNo++) {
				if (retValue == CONFIG_VALIDATE_CHANGES_MADE)
					break;
				for (rangeNo = 0; rangeNo < BOARDCALS_RANGECALS_SIZE; rangeNo++) {
					if (retValue == CONFIG_VALIDATE_CHANGES_MADE)
						break;
					// Check the range calibration selection
					if (pCMMRecorderCal->RecorderCals[slotNo].RangeCals[rangeNo].Channel[chanNo]
							== CInputConditioning::V6_IO_USER_AND_RECALIBRATE) {
						retValue = CONFIG_VALIDATE_CHANGES_MADE;
					}
				}
				// Check the channel single/dual point cals
				if (pCMMRecorderCal->RecorderCals[slotNo].ChanCals[chanNo].PointCals.CalType
						== CInputConditioning::V6_IO_USER_AND_RECALIBRATE) {
					retValue = CONFIG_VALIDATE_CHANGES_MADE;
				}
			}
		}
	}
	return retValue;
}
//******************************************************
///
/// Limit the CMM I/O calibration structure for a calibration required.
/// Check and remove from CMM calibration structure any 'illegal' user & calibration selections
/// these should never be persisted, but is so we need to remove them before loading configuration to the I/O board(s)
///
/// @return CONFIG_VALIDATE_CHANGES_MADE if changes were made otherwise CONFIG_VALIDATE_NO_CHANGES.
/// 
//******************************************************
T_CONFIG_VALIDATE_RETURN CIOSetupConfig::ResetProcessedCMMToUserCalSet(void) {
	USHORT slotNo = 0;
	USHORT rangeNo = 0;
	USHORT chanNo = 0;
	T_RECORDERCAL *pCMMRecorderCal = NULL;
	T_CONFIG_VALIDATE_RETURN retValue = CONFIG_VALIDATE_NO_CHANGES;
	pCMMRecorderCal = GetTopSlotRecorderCalInfo(CONFIG_MODIFIABLE);
	if (pCMMRecorderCal != NULL) {
		for (slotNo = 0; slotNo < RECORDERCAL_RECORDERCALS_SIZE; slotNo++) {
			// @todo: Only check the number of avaialable channels on each board actually fitted
			for (chanNo = 0; chanNo < IORANGECAL_CHANNEL_SIZE; chanNo++) {
				for (rangeNo = 0; rangeNo < BOARDCALS_RANGECALS_SIZE; rangeNo++) {
					// Check the range calibration selection
					if (pCMMRecorderCal->RecorderCals[slotNo].RangeCals[rangeNo].Channel[chanNo]
							== CInputConditioning::V6_IO_USER_AND_RECALIBRATE) {
						// Uploaded user calibration data to AI board so start using
						pCMMRecorderCal->RecorderCals[slotNo].RangeCals[rangeNo].Channel[chanNo] =
								CInputConditioning::V6_IO_FACTORY_CALIBRATION;
						retValue = CONFIG_VALIDATE_CHANGES_MADE;
					}
				}
			}
		}
	}
	return retValue;
}
//***************************************************************************
///
/// Validate the CMM configuration in a specified recorder slot, with the
/// actual hardware using the slot information from the device capabilities table.
/// Make any adjustments necessary to the CMM to aligh its config with the device capabilities table
///
/// @param[in] slotNumber - The recorder I/O board slot number.
///
/// @return board & CMM validation sucess state
/// 
//***************************************************************************
T_CONFIG_VALIDATE_RETURN CIOSetupConfig::ValidateAndAlignBoardCMM( const USHORT slotNumber, const class CDeviceCaps * const pPrevDevCaps )
{
  T_CONFIG_VALIDATE_RETURN retValue = CONFIG_VALIDATE_NO_CHANGES;
#ifndef DOCVIEW
//TM removed	pAIRangeInfo = CAIRanges::GetHandle();
  class CBrdInfo *pBrdInfo = NULL;
  USHORT chanNo;
  USHORT penNo;
  BOOL boardChangeReported = FALSE;
  T_PTOPSLOT pTopSlot = NULL;
  T_PBOTTOMSLOT pBottomSlot = NULL;
  USHORT sysChanNo = 0;
  WCHAR slotNoStr[4];
  QString newSlotBrdStr("");
  QString oldSlotBrdStr("");
  QString strErrorMsg("");
  class CSlotMap *pSlotMap = NULL;

  pBrdInfo = CBrdInfo::GetHandle();

  pSlotMap = CSlotMap::GetHandle();
  pSlotMap->GetSlotStrID( slotNumber, slotNoStr );

  pSlotMap->GetIOCardStrID(static_cast<UCHAR> (DEVICE_INFO.GetSlotType( slotNumber )), &newSlotBrdStr);
  pSlotMap->GetIOCardStrID(static_cast<UCHAR> (pPrevDevCaps->GetSlotType( slotNumber )), &oldSlotBrdStr);

  // Is the slot to be checked a top slot on the recorder?
  if( DEVICE_INFO.GetSlotPosition( slotNumber ) == SLOT_TOP )
  {
    // Yes, get information from the CMM and check the validity and repair if necessary
    pTopSlot = GetTopSlot(slotNumber, CONFIG_MODIFIABLE);
    if( pTopSlot != NULL )
    {
    pTopSlot->SlotNumber = slotNumber;	// Make sure Slot number in CMM is correctly set after any defaulting

    // @todo: Only check the number of avaialable channels on each board actually fitted
    for(chanNo = 0; chanNo < SLOTINFO_CHANNELCAP_SIZE; chanNo++)
    {
      // If the device caps shows a channel is Unknown
      if( DEVICE_INFO.GetChannelCaps(slotNumber, chanNo) != CHANNEL_CAP_UNKNOWN )
      {
        switch(DEVICE_INFO.GetSlotType( slotNumber ))
        {
        case BOARD_AI:
        case BOARD_EZ_AI:
          {
            // It's an AI board this time so was it an AI board with the same or less channels when the devcaps was last saved
            if( ( pPrevDevCaps->GetSlotType( slotNumber ) == BOARD_AI ) ||
            ( pPrevDevCaps->GetSlotType( slotNumber ) == BOARD_EZ_AI ))
            {
            // Check for added/removed channels
            if( pPrevDevCaps->GetSlotNumChannels( slotNumber ) != DEVICE_INFO.GetSlotNumChannels( slotNumber ) )
            {
              // Report channel change
              if( boardChangeReported == FALSE )
              {
                strErrorMsg = QString::asprintf( "Slot %s: %d channels previously; currently %d channels", slotNoStr,
                      pPrevDevCaps->GetSlotNumChannels( slotNumber ),
                      DEVICE_INFO.GetSlotNumChannels( slotNumber ) );
                LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, strErrorMsg );
              }
              boardChangeReported = TRUE;
            }

            // Upgrades can be performed silently
            }
            else
            {
            // No it was not an AI last time
            if( pPrevDevCaps->GetSlotType( slotNumber ) == BOARD_NOT_FITTED )
            {
              if( boardChangeReported == FALSE )
              {
                strErrorMsg = QString::asprintf( "Slot %s: setup unspecified for %s card", slotNoStr, newSlotBrdStr.toStdWString().c_str() );
                LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, strErrorMsg );
              }
              boardChangeReported = TRUE;
            }
            else if( pPrevDevCaps->GetSlotType( slotNumber ) == BOARD_AO )
            {
              // Report different card
              if( boardChangeReported == FALSE )
              {
                strErrorMsg = QString::asprintf( IDS_STATUS_CARD_SWAP_NOTIFICATION, slotNoStr, oldSlotBrdStr.toStdWString().c_str(), newSlotBrdStr.toStdWString().c_str() );
                LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, strErrorMsg );
              }
              boardChangeReported = TRUE;
            }
            else if( pPrevDevCaps->GetSlotType( slotNumber ) == BOARD_PI )
            {
              // Report different card
              if( boardChangeReported == FALSE )
              {
                strErrorMsg = QString::asprintf( IDS_STATUS_CARD_SWAP_NOTIFICATION, slotNoStr, oldSlotBrdStr.toStdWString().c_str(), newSlotBrdStr.toStdWString().c_str() );
                LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, strErrorMsg );
              }
              boardChangeReported = TRUE;
            }
            }

            // Check if the device capability for this channel is an AI, if not leave alone
            if( DEVICE_INFO.TestChannelCapability(slotNumber, chanNo, CHANNEL_CAP_AI ) == TRUE )
            {
            // Check that amps sub-range is not out-of-range; can occur if CMM has been upgraded
            if( (pTopSlot->AIChan[chanNo].Type == AI_CHANNEL_TYPE_LINEAR_AMPS) &&
              (pTopSlot->AIChan[chanNo].Linear.RangePreset > LINEAR_AMPS_4mA_20mA) )
            {
              pTopSlot->AIChan[chanNo].Linear.RangePreset = LINEAR_AMPS_0mA_20mA;
            }

            // Check acqusition rate for problems and options code changes
            if( pSYSTEM_INFO->FWOptionFastScanAvailable() == TRUE )
            {
              // Next check if the acquisition rate is 50Hz, if so make sure it's only set on certain channel types
              if( pTopSlot->AIChan[chanNo].AcqRate == AI_ACQ_RATE_50HZ )
              {
                // Check if the channel type is illegal at this rate
                if(	(pTopSlot->AIChan[chanNo].Type == AI_CHANNEL_TYPE_RT) ||
                (pTopSlot->AIChan[chanNo].Type == AI_CHANNEL_TYPE_TC) )
                {
                // Channel operating at 50Hz but RT or TC is selected, so reset to fastest possible - 10Hz
                pTopSlot->AIChan[chanNo].AcqRate = AI_ACQ_RATE_10HZ;

                sysChanNo = pSlotMap->GetSysChannelFromAnaInChannel( slotNumber, chanNo, ONE_BASED);
                strErrorMsg = QString::asprintf( IDS_STATUS_TC_DOWNGRADE_50HZ_ACQ, sysChanNo );
                LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, strErrorMsg );
                }
              }
            }
            else if( pTopSlot->AIChan[chanNo].AcqRate == AI_ACQ_RATE_50HZ )
            {
              // Drop to 10Hz acqusition, if no fast scanning option in recorder
              pTopSlot->AIChan[chanNo].AcqRate = AI_ACQ_RATE_10HZ;

              sysChanNo = pSlotMap->GetSysChannelFromAnaInChannel( slotNumber, chanNo, ONE_BASED);
              strErrorMsg = QString::asprintf( IDS_STATUS_DOWNGRADE_50HZ_ACQ, sysChanNo );
              LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, strErrorMsg );
            }

            // here if in hot soak test mode modify it to be 200 Ohm range
            if(pSYSTEM_INFO->IsInHotSoakTestMode())
            {
              pTopSlot->AIChan[chanNo].Enabled=TRUE;
              pTopSlot->AIChan[chanNo].Type=AI_CHANNEL_TYPE_LINEAR_OHMS;
              pTopSlot->AIChan[chanNo].Linear.RangePreset=LINEAR_200_OHM;
              if(!pDALGLB->IsRecorderEzTrend())
                pTopSlot->AIChan[chanNo].AcqRate = AI_ACQ_RATE_10HZ; // not for Ez
              boardChangeReported = TRUE;
            }
            }

            if( DEVICE_INFO.GetSlotType( slotNumber ) == BOARD_EZ_AI )
            {
            // Eztrend board does not have TC active burnout mode
            if( (pTopSlot->AIChan[chanNo].TC.ActiveBurnout == TRUE) &&
              (pTopSlot->AIChan[chanNo].Type == AI_CHANNEL_TYPE_TC) )
            {
              pTopSlot->AIChan[chanNo].TC.ActiveBurnout = FALSE;
            }

            // Eztrend can only operate at maximum of 5Hz
            if( AI_ACQ_RATE_50HZ == pTopSlot->AIChan[chanNo].AcqRate )
            {
              // back it off to 5Hz
              pTopSlot->AIChan[chanNo].AcqRate -= 2;

              sysChanNo = pSlotMap->GetSysChannelFromAnaInChannel( slotNumber, chanNo, ONE_BASED);
              strErrorMsg = QString::asprintf( IDS_STATUS_TC_DOWNGRADE_50HZ_ACQ, sysChanNo );
              LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, strErrorMsg );
            }
            else if( AI_ACQ_RATE_10HZ == pTopSlot->AIChan[chanNo].AcqRate )
            {
              // back it off to 5Hz
              pTopSlot->AIChan[chanNo].AcqRate -= 1;

              // Notify user of change
              sysChanNo = pSlotMap->GetSysChannelFromAnaInChannel( slotNumber, chanNo, ONE_BASED);
              strErrorMsg = QString::asprintf( IDS_STATUS_TC_DOWNGRADE_50HZ_ACQ, sysChanNo );
              LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, strErrorMsg );
            }
            }
          }
          break;

        // Analogue output baord
        case BOARD_AO:
          {
            T_PPEN pPen = NULL;

            // Check that the re-tranmission pen is legal
            if( pSYSTEM_INFO->IsPenAvailable( pTopSlot->AOChan[chanNo].PenNo, ZERO_BASED ) != TRUE )
            {
            sysChanNo = pSlotMap->GetSysChannelFromAnaOutChannel( slotNumber, chanNo, ONE_BASED);
            strErrorMsg = QString::asprintf( IDS_STATUS_AO_INCORRECT_RETRANS_PEN, sysChanNo );
            LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, strErrorMsg );

            // No it isn't; so correct
            for( penNo = 0; penNo < V6_MAX_PENS; penNo++ )
            {
              pPen = NULL;
              if( pSYSTEM_INFO->IsPenAvailable( penNo, ZERO_BASED ) == TRUE)
              {

                m_GlbSetupMutex.lock();
                 pPen = pGlbSetup->GetPenSetupConfig()->GetPen(penNo, ZERO_BASED , CONFIG_MODIFIABLE);
                m_GlbSetupMutex.unlock();
              }
              if( (pPen != NULL) && (pPen->Enabled == TRUE) )
              {
                pTopSlot->AOChan[chanNo].PenNo = penNo;				///< Retransmit the first available pen
                break;												///< Look no further
              }
            }
            }

            // It's an AO board this time so was it an AO board with the same or less channels when the devcaps was last saved
            if( pPrevDevCaps->GetSlotType( slotNumber ) == BOARD_AO )
            {
            // Check for removed/added channels
            if( pPrevDevCaps->GetSlotNumChannels( slotNumber ) != DEVICE_INFO.GetSlotNumChannels( slotNumber ) )
            {
              // Report less channel change
              if( boardChangeReported == FALSE )
              {
                strErrorMsg = QString::asprintf( IDS_STATUS_CARD_CHANNEL_CHANGED, slotNoStr,
                      pPrevDevCaps->GetSlotNumChannels( slotNumber ),
                      DEVICE_INFO.GetSlotNumChannels( slotNumber ) );
                LOG_SYSTEM_MESSAGE( MSGLISTSER_SYSTEM_WARNING, strErrorMsg );
              }
              boardChangeReported = TRUE;
            }

            // Upgrades can be performed silently
            }
            else
            {
            // No it was not an AO last time
            if( pPrevDevCaps->GetSlotType( slotNumber ) == BOARD_NOT_FITTED )
            {
              if( boardChangeReported == FALSE )
              {
                strErrorMsg = QString::asprintf( IDS_STATUS_CARD_INSERTED_NOTIFICATION, slotNoStr, newSlotBrdStr.toStdWString().c_str() );
                LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, strErrorMsg );
              }
              boardChangeReported = TRUE;
            }
            else if(( pPrevDevCaps->GetSlotType( slotNumber ) == BOARD_AI ) ||
                ( pPrevDevCaps->GetSlotType( slotNumber ) == BOARD_EZ_AI ))
            {
              // Report different card
              if( boardChangeReported == FALSE )
              {
                strErrorMsg = QString::asprintf( IDS_STATUS_CARD_SWAP_NOTIFICATION, slotNoStr, oldSlotBrdStr.toStdWString().c_str(), newSlotBrdStr.toStdWString().c_str() );
                LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, strErrorMsg );
              }
              boardChangeReported = TRUE;
            }
            else if( pPrevDevCaps->GetSlotType( slotNumber ) == BOARD_PI )
            {
              // Report different card
              if( boardChangeReported == FALSE )
              {
                strErrorMsg = QString::asprintf( IDS_STATUS_CARD_SWAP_NOTIFICATION, slotNoStr, oldSlotBrdStr.toStdWString().c_str(), newSlotBrdStr.toStdWString().c_str() );
                LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, strErrorMsg );
              }
              boardChangeReported = TRUE;
            }
            }
          }
          break;

        // Pulse channel board
        case BOARD_PI:
          {
            // Only pulse channels are allowed
            if( DEVICE_INFO.TestChannelCapability(slotNumber, chanNo, CHANNEL_CAP_PULSE ) == TRUE )
            {
            // It's an PI board this time so was it an PI board with the same or less channels when the devcaps was last saved
            if( pPrevDevCaps->GetSlotType( slotNumber ) == BOARD_PI )
            {
              // Check for removed/added channels
              if( pPrevDevCaps->GetSlotNumChannels( slotNumber ) != DEVICE_INFO.GetSlotNumChannels( slotNumber ) )
              {
                // Report less channels
                if( boardChangeReported == FALSE )
                {
                strErrorMsg = QString::asprintf( IDS_STATUS_CARD_CHANNEL_CHANGED, slotNoStr,
                        pPrevDevCaps->GetSlotNumChannels( slotNumber ),
                        DEVICE_INFO.GetSlotNumChannels( slotNumber ) );
                LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, strErrorMsg );
                }
                boardChangeReported = TRUE;
              }

              // Upgrades can be performed silently
            }
            else
            {
              if( pPrevDevCaps->GetSlotType( slotNumber ) == BOARD_NOT_FITTED )
              {
                // New board first fit
                strErrorMsg = QString::asprintf( IDS_STATUS_CARD_INSERTED_NOTIFICATION, slotNoStr, newSlotBrdStr.toStdWString().c_str() );
                LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, strErrorMsg );
              }
              else if(( pPrevDevCaps->GetSlotType( slotNumber ) == BOARD_AI ) ||
                ( pPrevDevCaps->GetSlotType( slotNumber ) == BOARD_EZ_AI ))
              {
                // Report different card
                if( boardChangeReported == FALSE )
                {
                strErrorMsg = QString::asprintf( IDS_STATUS_CARD_SWAP_NOTIFICATION, slotNoStr, oldSlotBrdStr.toStdWString().c_str(), newSlotBrdStr.toStdWString().c_str() );
                LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, strErrorMsg );
                }
                boardChangeReported = TRUE;
              }
              else if( pPrevDevCaps->GetSlotType( slotNumber ) == BOARD_AO )
              {
                // Report different card
                if( boardChangeReported == FALSE )
                {
                strErrorMsg = QString::asprintf( IDS_STATUS_CARD_SWAP_NOTIFICATION, slotNoStr, oldSlotBrdStr.toStdWString().c_str(), newSlotBrdStr.toStdWString().c_str() );
                LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, strErrorMsg );
                }
                boardChangeReported = TRUE;
              }
            }

            // else Yes, it's a Pulse channel fitted so use CMM Pulse channel

            }
          }
          break;
        default:
        // Board is not fitted, or unknown type and any config is valid
        break;
        }
      }
      else
      {
        // Device caps is showing an unknown channel, anything is permissable in the CMM
      }
    }
    }
  }
  else if( DEVICE_INFO.GetSlotPosition( slotNumber ) == SLOT_BOTTOM )
  {
    // Bottom slot cards being accessed
    pBottomSlot = GetBottomSlot(slotNumber, CONFIG_MODIFIABLE);

    BOOL channelCombinationValid = FALSE;		// Accumulated check for slot validity against deviace capabilities
    if( pBottomSlot != NULL )
    {
    pBottomSlot->SlotNumber = slotNumber;	// Make sure Slot number in CMM is correctly set after any defaulting

    // @todo: Only check the number of avaialable channels on each board actually fitted
    for(chanNo = 0; chanNo < SLOTINFO_CHANNELCAP_SIZE; chanNo++)
    {
      channelCombinationValid = FALSE;		// Assume channel configuation combination invalid until tested otherwise

      switch(DEVICE_INFO.GetSlotType( slotNumber ))
      {
        case BOARD_AR:
        case BOARD_DIO:
        {
          if( pPrevDevCaps->GetSlotType( slotNumber ) == BOARD_NOT_FITTED )
          {
            if( boardChangeReported == FALSE )
            {
            strErrorMsg = QString::asprintf( IDS_STATUS_CARD_INSERTED_NOTIFICATION, slotNoStr, newSlotBrdStr.toStdWString().c_str() );
            LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, strErrorMsg );
            }
            boardChangeReported = TRUE;
          }
          else if( DEVICE_INFO.GetSlotType( slotNumber ) != pPrevDevCaps->GetSlotType( slotNumber ) )
          {
            // Report when one board has been swapped with another
            if( boardChangeReported == FALSE )
            {
            strErrorMsg = QString::asprintf( IDS_STATUS_CARD_SWAP_NOTIFICATION, slotNoStr, oldSlotBrdStr.toStdWString().c_str(), newSlotBrdStr.toStdWString().c_str() );
            LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, strErrorMsg );
            }
            boardChangeReported = TRUE;

          }
          else if( pPrevDevCaps->GetSlotNumChannels( slotNumber ) != DEVICE_INFO.GetSlotNumChannels( slotNumber ) )
          {
            // Report downgrade/upgrade in number of channels
            if( boardChangeReported == FALSE )
            {
            strErrorMsg = QString::asprintf( IDS_STATUS_CARD_CHANNEL_CHANGED, slotNoStr,
                    pPrevDevCaps->GetSlotNumChannels( slotNumber ),
                    DEVICE_INFO.GetSlotNumChannels( slotNumber ) );
            LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, strErrorMsg );
            }
            boardChangeReported = TRUE;
          }

          // Check DI channel capability between CMM configuration and physical capability of channel,
          // because some channel types are valid on more than one type of board
          if( GetBottomSlotChannelSelectedType( pBottomSlot, chanNo ) == CHANNEL_DI &&
            DEVICE_INFO.TestChannelCapability(slotNumber, chanNo, CHANNEL_CAP_DI ) == TRUE )
          {
            channelCombinationValid = TRUE;	// An DI channel is configured and is compatible with channel capabilities
          }
          // Check DO channel capability between CMM configuration and physical capability of channel
          if( GetBottomSlotChannelSelectedType( pBottomSlot, chanNo ) == CHANNEL_DO &&
            DEVICE_INFO.TestChannelCapability(slotNumber, chanNo, CHANNEL_CAP_DO ) == TRUE )
          {
            channelCombinationValid = TRUE;	// An DO channel is configured and is compatible with channel capabilities
          }
          // Check Pulse channel capability between CMM configuration and physical capability of channel
          if( GetBottomSlotChannelSelectedType( pBottomSlot, chanNo ) == CHANNEL_DIG_PULSE &&
            DEVICE_INFO.TestChannelCapability(slotNumber, chanNo, CHANNEL_CAP_PULSE ) == TRUE )
          {
            channelCombinationValid = TRUE;	// An Pulse channel is configured and is compatible with channel capabilities
          }

          // There is an incompatability with the capabilities of the channel in the CMM and that of
          // the physical hardware, so change channel to be a correct type
          if( channelCombinationValid == FALSE )
          {
            // Does the card have the capability to be a DO?
            if( DEVICE_INFO.TestChannelCapability(slotNumber, chanNo, CHANNEL_CAP_DO ) == TRUE )
            {
            // Yes, set CMM to channel to be a DO as the safest options
            pBottomSlot->DigChan[chanNo].DigO.FailSafe = FALSE;		// Make sure failsafe is configured
            pBottomSlot->DigChan[chanNo].Type = dtOutput;
            boardChangeReported = TRUE;
            }
            // No, so does it have capability to be a DI?
            else if( DEVICE_INFO.TestChannelCapability(slotNumber, chanNo, CHANNEL_CAP_DI ) == TRUE )
            {
            // Yes, set CMM to channel to be a DI
            pBottomSlot->DigChan[chanNo].Type = dtInput;
            boardChangeReported = TRUE;
            }
            // No, so does it have capability to be a Pulse?
            else if( DEVICE_INFO.TestChannelCapability(slotNumber, chanNo, CHANNEL_CAP_PULSE ) == TRUE )
            {
            // Yes, set CMM to channel to be a PULSE
            pBottomSlot->DigChan[chanNo].Type = dtPulseInput;
            boardChangeReported = TRUE;
            }
            else
            {
            // Does not have capability to be DI,DO or PULSE.
            // Assumes that channel is not present so anything is allowed.
            }
          }
        }
        break;
        default:
        // Unknown board type, so anything allowed
        break;
      }
    }
    }
  }

  // Report if changes have been made
  if( boardChangeReported == TRUE )
    retValue = CONFIG_VALIDATE_CHANGES_MADE;
#endif

  return retValue;
}



//******************************************************
//  SelectBoardType()
///
/// Select the current board type in any given recorder slot.
/// @param[in] slotNumber - The recorder I/O board slot number.
/// @param[in] boardType - The board type.
///
/// @return channel type creation sucess state
///
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::SelectBoardType(const USHORT slotNumber,  const USHORT boardType)
{
  T_PTOPSLOT pTopSlot = NULL;
  T_PBOTTOMSLOT pBottomSlot = NULL;
  T_CONFIG_RETURN_VALUE status = CONFIG_ERROR;

  if( DEVICE_INFO.GetSlotPosition( slotNumber ) == SLOT_TOP )
  {
    // Top slot cards being accessed
    pTopSlot = GetTopSlot(slotNumber, CONFIG_MODIFIABLE);
    if( pTopSlot != NULL )
    {
    pTopSlot->SlotNumber = slotNumber;
    pTopSlot->SlotType = boardType;
    status = CONFIG_OK;
    }
  }
  else if ( DEVICE_INFO.GetSlotPosition( slotNumber ) == SLOT_BOTTOM )
  {
    // Bottom slot cards being accessed
    pBottomSlot = GetBottomSlot(slotNumber, CONFIG_MODIFIABLE);
    if( pBottomSlot != NULL )
    {
    pBottomSlot->SlotNumber = slotNumber;
    pBottomSlot->SlotType = boardType;
    status = CONFIG_OK;
    }
  }

  return status;
}


//**********************************************************************
/// DecodeChannelAcqRate()
///
/// Decodes the channel acqusition rate for the local configuration.
///
/// @param[in] CMMSetting - CMM representation of the acqusition rates.
///
/// @return	 	 The acquisitions on this channel
//**********************************************************************
USHORT CIOSetupConfig::GetAIChannelRateFromConfiguration( const UCHAR CMMSetting )
{
   USHORT AIAcqRate = 2;	// Default to 2Hz if rate not found

   switch( CMMSetting )
   {
   case AI_ACQ_RATE_2HZ:
   AIAcqRate = 2;
   break;
   case AI_ACQ_RATE_5HZ:
   AIAcqRate = 5;
   break;
   case AI_ACQ_RATE_10HZ:
   AIAcqRate = 10;
   break;
   case AI_ACQ_RATE_50HZ:
   AIAcqRate = 50;
   break;
   };

   return AIAcqRate;
}

//******************************************************
//  GetAnalogueCJCal()
///
/// Get the current configuration for an analogue channel CJ cal from the CMM.
/// @param[in] slotNumber - The recorder I/O board slot number.
/// @param[in] analNumber - The recorder analogue channel number.
/// @param[in] cfgType - The type of configuration to access.
///
/// @return Pointer to the analogue channel CJ cal config structure, if valid; otherwise NULL
///
//******************************************************
T_PCHANCJCCAL CIOSetupConfig::GetAnalogueCJCal(const USHORT slotNumber, const USHORT analNumber, const REFERENCE cfgType)
{
  T_PCHANCJCCAL pCJCChanCal = NULL;
  T_PRECORDERCAL pTopSlotCalInfo = NULL;

  // Get the ptr to CMM data
  if( (slotNumber >= RECORDER_SLOT_A) && (slotNumber <= RECORDER_SLOT_F) )
  {
    // Only valid for topslots
    pTopSlotCalInfo = reinterpret_cast<T_PRECORDERCAL>(CConfiguration::GetBlock( BLK_RECORDERCAL, 0, m_ConfigurationId, cfgType ));
    //PSR - Coverity issue fix --#776292
    if( (pTopSlotCalInfo != NULL) && (analNumber < TOPSLOT_AICHAN_SIZE) )
    {
    pCJCChanCal = &(pTopSlotCalInfo->RecorderCals[slotNumber].ChanCals[analNumber].CJCCals);
    }
  }

  return pCJCChanCal;
}


//******************************************************
//  GetAnalogueOPCal()
///
/// Get the current configuration for an analogue channel dual and single point cal from the CMM.
/// @param[in] slotNumber - The recorder I/O board slot number.
/// @param[in] analNumber - The recorder analogue channel number.
/// @param[in] cfgType - The type of configuration to access.
///
/// @return Pointer to the analogue channel single/dual point cal config structure, if valid; otherwise NULL
///
//******************************************************
T_PCHANCALPOINT CIOSetupConfig::GetAnalogueOPCal(const USHORT slotNumber, const USHORT analNumber, const REFERENCE cfgType)
{
  T_PCHANCALPOINT pCJCChanCal = NULL;
  T_PRECORDERCAL pTopSlotCalInfo = NULL;

  // Get the ptr to CMM data
  if( (slotNumber >= RECORDER_SLOT_A) && (slotNumber <= RECORDER_SLOT_F) )
  {
    // Only valid for topslots
    pTopSlotCalInfo = reinterpret_cast<T_PRECORDERCAL>(CConfiguration::GetBlock( BLK_RECORDERCAL, 0, m_ConfigurationId, cfgType ));
    //PSR - Coverity issue fix --Out-ofBounds memory access #769456
    if( (pTopSlotCalInfo != NULL) && (analNumber < TOPSLOT_AICHAN_SIZE) )
    {
    pCJCChanCal = &(pTopSlotCalInfo->RecorderCals[slotNumber].ChanCals[analNumber].PointCals);
    }
  }

  return pCJCChanCal;
}

//******************************************************
//  GetAnalogueInput()
///
/// Get the current configuration for an analogue channel from the CMM.
/// @param[in] slotNumber - The recorder I/O board slot number.
/// @param[in] analNumber - The recorder analogue channel number.
/// @param[in] cfgType - The type of configuration to access.
///
/// @return Pointer to the analogue channel config structure, if valid; otherwise NULL
///
//******************************************************
T_PAICHANNEL CIOSetupConfig::GetAnalogueInput(const USHORT slotNumber, const USHORT analNumber, const REFERENCE cfgType)
{
  T_PTOPSLOT pTopSlot = NULL;
  T_PAICHANNEL pAnaInChan = NULL;

  if( (slotNumber >= RECORDER_SLOT_A) && (slotNumber <= RECORDER_SLOT_F) )
  {
    pTopSlot = GetTopSlot(slotNumber, cfgType);
    if( (pTopSlot != NULL) && (analNumber <= TOPSLOT_AICHAN_SIZE) )
    pAnaInChan = &pTopSlot->AIChan[analNumber];
  }

  return pAnaInChan;
}
//******************************************************
//  GetAnalogueInput()
///
/// Get the current configuration for an analogue channel from the CMM.
/// @param[in] slotNumber - The Analogue Input instance number
/// @param[in] cfgType - The type of configuration to access.
///
/// @return Pointer to the analogue channel config structure, if valid; otherwise NULL
///
//******************************************************
T_PAICHANNEL CIOSetupConfig::GetAnalogueInput(const USHORT usINSTANCE_NO, const REFERENCE cfgType)
{
  T_PAICHANNEL pAnaInChan = NULL;

  USHORT usSlotNo = 0;
  USHORT usChanNo = 0;
  CSlotMap *pkSlotMap = CSlotMap::GetHandle();

  if( pkSlotMap->GetSlotAndChannelFromAnalSysChan( usINSTANCE_NO, &usSlotNo, &usChanNo, ZERO_BASED ) )
  {
    T_PTOPSLOT pTopSlot = NULL;

    if( ( usSlotNo >= RECORDER_SLOT_A ) && ( usSlotNo <= RECORDER_SLOT_F ) )
    {
    pTopSlot = GetTopSlot( usSlotNo, cfgType);
    if( ( pTopSlot != NULL ) && ( usChanNo <= TOPSLOT_AICHAN_SIZE) )
    {
      pAnaInChan = &pTopSlot->AIChan[ usChanNo ];
    }
    }
  }

  return pAnaInChan;
}

//******************************************************
//  GetAnalogueOutput()
///
/// Get the current configuration for an analogue channel from the CMM.
/// @param[in] slotNumber - The recorder I/O board slot number.
/// @param[in] analNumber - The recorder analogue channel number.
/// @param[in] cfgType - The type of configuration to access.
///
/// @return Pointer to the analogue channel config structure, if valid; otherwise NULL
///
//******************************************************
T_PAOCHANNEL CIOSetupConfig::GetAnalogueOutput(const USHORT slotNumber, const USHORT analNumber, const REFERENCE cfgType)
{
  T_PTOPSLOT pTopSlot = NULL;
  T_PAOCHANNEL pAnaOutChan = NULL;

  if( (slotNumber >= RECORDER_SLOT_A) && (slotNumber <= RECORDER_SLOT_F) )
  {
    pTopSlot = GetTopSlot(slotNumber, cfgType);
    if( (pTopSlot != NULL) && (analNumber <= TOPSLOT_AOCHAN_SIZE) )
    pAnaOutChan = &pTopSlot->AOChan[analNumber];
  }

  return pAnaOutChan;
}

//******************************************************
//  GetDigital()
///
/// Get the current configuration for an digital channel from the CMM.
/// @param[in] slotNumber - The recorder I/O board slot number.
/// @param[in] digiNumber - The board slot digital channel number.
/// @param[in] cfgType - The type of configuration to access.
///
/// @return Pointer to the digital channel config structure, if valid; otherwise NULL
///
//******************************************************
T_PDIGCHANNEL CIOSetupConfig::GetDigital(const USHORT slotNumber, const USHORT digiNumber, const REFERENCE cfgType)
{
  T_PBOTTOMSLOT pBottomSlot = NULL;
  T_PDIGCHANNEL pDigChan = NULL;

  if( (slotNumber >= RECORDER_SLOT_G) && (slotNumber <= RECORDER_SLOT_I) )
  {
    pBottomSlot = GetBottomSlot(slotNumber, cfgType);
    if( pBottomSlot != NULL )
    pDigChan = &pBottomSlot->DigChan[digiNumber];
  }

  return pDigChan;
}


//******************************************************
//  GetPulseInput()
///
/// Get the current configuration for an  pulse input channel from the CMM.
/// @param[in] slotNumber - The recorder I/O board slot number.
/// @param[in] digiNumber - The board slot pulse channel number.
/// @param[in] cfgType - The type of configuration to access.
///
/// @return Pointer to the  pulse channel config structure, if valid; otherwise NULL
///
//******************************************************
T_PPULSECHANNEL CIOSetupConfig::GetPulseInput(const USHORT slotNumber, const USHORT digiNumber, const REFERENCE cfgType)
{
  T_PTOPSLOT pTopSlot = NULL;
  T_PBOTTOMSLOT pBottomSlot = NULL;
  T_PPULSECHANNEL pPulseChan = NULL;

  if( DEVICE_INFO.GetSlotPosition( slotNumber ) == SLOT_TOP )
  {
    pTopSlot = GetTopSlot(slotNumber, cfgType);
    if( (pTopSlot != NULL) && (digiNumber <= TOPSLOT_PULSECHAN_SIZE) )
    {
    pPulseChan = &pTopSlot->PulseChan[digiNumber];
    }
  }
  return pPulseChan;
}
//******************************************************
//  T_PDEMOCHANNEL GetDemoChannel()
///
/// Get the current configuration for a demo channel from the CMM.
///
/// @param[in]		const USHORT usSLOT_NO - The recorder I/O board slot number.
/// @param[in]		const USHORT usBOARD_CHAN_NO - The board channel number
/// @param[in]		const REFERENCE eCFG_TYPE - The type of configuration to access
///
/// @return Pointer to the  demo channel config structure, if valid; otherwise NULL
///
//******************************************************
T_PDEMOCHANNEL CIOSetupConfig::GetDemoChannel(	const USHORT usSLOT_NO,
                const USHORT usBOARD_CHAN_NO,
                const REFERENCE eCFG_TYPE )
{
  T_PTOPSLOT ptSlot = GetTopSlot( usSLOT_NO, eCFG_TYPE );
  T_PDEMOCHANNEL ptDemoChannel = NULL;

  // get the demo channel information if the slot data is valid and we are not looking at an invalid channel
  if( ( ptSlot != NULL ) && ( usBOARD_CHAN_NO < TOPSLOT_DEMOCHAN_SIZE ) ) // coverity fix 774612
  {
    ptDemoChannel = &ptSlot->DemoChan[ usBOARD_CHAN_NO ];
  }

  return ptDemoChannel;
}
//******************************************************
//  GetBoardType()
///
/// Get the current channel type for any channel on any card from the CMM.
/// @param[in] slotNumber - The recorder I/O board slot number.
/// @param[in] cfgType - The type of configuration to access.
///
/// @return Board type that Slot is populated with
///
//******************************************************
USHORT CIOSetupConfig::GetBoardType(const USHORT slotNumber, const REFERENCE cfgType) const
{
  const T_TOPSLOT *pTopSlot = NULL;
  const T_BOTTOMSLOT *pBottomSlot = NULL;
  USHORT boardType = BOARD_NOT_FITTED;
  if( DEVICE_INFO.GetSlotPosition( slotNumber ) == SLOT_TOP )
  {
    // Top slot cards being accessed
    pTopSlot = GetTopSlot(slotNumber, cfgType);
    if( pTopSlot != NULL )
    boardType = pTopSlot->SlotType;
  }
  else if( DEVICE_INFO.GetSlotPosition( slotNumber ) == SLOT_BOTTOM )
  {
    pBottomSlot = GetBottomSlot(slotNumber, cfgType);
    if( pBottomSlot != NULL )
    boardType = pBottomSlot->SlotType;
  }
  return boardType;
}


//******************************************************
//  GetChannelSelectedType()
///
/// Get the current channel type for any channel on any card from the CMM.
/// @param[in] slotNumber - The recorder I/O board slot number.
/// @param[in] chanNumber - The board channel number.
/// @param[in] cfgType - The type of configuration to access.
///
/// @return Slot selected channel type
///
//******************************************************
USHORT CIOSetupConfig::GetChannelSelectedType(const USHORT slotNumber, const USHORT chanNumber, const REFERENCE cfgType) const
{
  T_PTOPSLOT pTopSlot = NULL;
  T_PBOTTOMSLOT pBottomSlot = NULL;
  USHORT channelType = CHANNEL_UNKNOWN;

  if( DEVICE_INFO.GetSlotPosition( slotNumber ) == SLOT_TOP )
  {
    // Top slot being requested
    pTopSlot = GetTopSlot(slotNumber, cfgType);
    if( pTopSlot != NULL )
    {
    channelType = GetTopSlotChannelSelectedType(pTopSlot, chanNumber);
    }
  }
  else if( DEVICE_INFO.GetSlotPosition( slotNumber ) == SLOT_BOTTOM )
  {
    // Bottom slot being requested
    pBottomSlot = GetBottomSlot(slotNumber, cfgType);
    if( pBottomSlot != NULL )
    {
    channelType = GetBottomSlotChannelSelectedType(pBottomSlot, chanNumber);
    }
  }
  return channelType;
}


//******************************************************
//  GetTopSlotChannelSelectedType()
///
/// Get the current channel type for any top slot channel on any card from the CMM.
/// @param[in] pTopSlot - The recorder I/O board top slot CMM config.
/// @param[in] chanNumber - The board channel number.
///
/// @return Slot selected channel type
///
//******************************************************
USHORT CIOSetupConfig::GetTopSlotChannelSelectedType(const T_TOPSLOT *pTopSlot, const USHORT chanNumber) const
{
  USHORT channelType = CHANNEL_UNKNOWN;

  switch( pDEVICE_INFO->GetChannelCaps( pTopSlot->SlotNumber, chanNumber ) )
  {
    case CHANNEL_CAP_AO:
    channelType = CHANNEL_AO;
    break;
    case CHANNEL_CAP_AI:
    channelType = CHANNEL_AI;
    break;
    case CHANNEL_CAP_PULSE:
    channelType = CHANNEL_PULSE;
    break;
  }

  // Unable to determine the type of setup required just by inspecting the CMM
  return channelType;
}


//******************************************************
//  GetChannelSelectedType()
///
/// Get the current channel type for any bottom slot channel on any card from the CMM.
/// @param[in] pBottomSlot - The recorder I/O board slot bottom slot CMM config.
/// @param[in] chanNumber - The board channel number.
///
/// @return Slot selected channel type
///
//******************************************************
USHORT CIOSetupConfig::GetBottomSlotChannelSelectedType(const T_BOTTOMSLOT *pBottomSlot, const USHORT chanNumber) const
{
  USHORT channelType = CHANNEL_UNKNOWN;

  // Bottom slot being requested
  if( pBottomSlot != NULL )
  {
    if( pBottomSlot->DigChan[chanNumber].Type == dtInput )
    {
    channelType = CHANNEL_DI;
    }
    else if( pBottomSlot->DigChan[chanNumber].Type == dtOutput )
    {
    channelType = CHANNEL_DO;
    }
    else if( pBottomSlot->DigChan[chanNumber].Type == dtPulseInput )
    {
    channelType = CHANNEL_DIG_PULSE;
    }
    else
    {
    channelType = CHANNEL_UNKNOWN;
    }
  }

  return channelType;
}


//******************************************************
//  CreateTopSlotBoardCalInfo()
///
/// Create a top slot card in the CMM.
/// @param[in] slotNumber - The recorder I/O board slot number.
///
/// @return Pointer to a top slot board
///
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::CreateTopSlotRecorderCalInfo( void )
{
  T_PRECORDERCAL pTopSlotCalInfo = NULL;
  USHORT slotNo = 0;
  USHORT rangeNo = 0;
  CMMERROR err = CMM_FAILED;
  T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;

  // Block does not exist so create
  pTopSlotCalInfo = reinterpret_cast<T_PRECORDERCAL>(CConfiguration::CreateNewBlock( BLK_RECORDERCAL, 0, m_ConfigurationId ));

  if( pTopSlotCalInfo != NULL )
  {
    // Top slot cards being accessed
    for( slotNo = 0; slotNo < RECORDERCAL_RECORDERCALS_SIZE; slotNo++ )
    {
    for( rangeNo = 0; rangeNo < BOARDCALS_RANGECALS_SIZE; rangeNo++ )
    {
      // Update the range number
      pTopSlotCalInfo->RecorderCals[slotNo].RangeCals[rangeNo].RangeType = rangeNo;
    }
    }
    retValue = CONFIG_OK;
  }

  return retValue;
}


//******************************************************
//  GetTopSlotRecorderCalInfo()
///
/// Get the calibration information from a top slot card from the CMM.
/// @param[in] cfgType - The type of configuration to access.
///
/// @return Pointer to a top slot board I/O board structure
///
//******************************************************
T_PRECORDERCAL CIOSetupConfig::GetTopSlotRecorderCalInfo(const REFERENCE cfgType) const
{
  T_PRECORDERCAL pTopSlotCalInfo = NULL;

  // Get the ptr to CMM data
  pTopSlotCalInfo = reinterpret_cast<T_PRECORDERCAL>(CConfiguration::GetBlock( BLK_RECORDERCAL, 0, m_ConfigurationId, cfgType ));

  return pTopSlotCalInfo;
}


//******************************************************
//  GetTopSlotBoardCalInfo()
///
/// Get the calibration information from a top slot card from the CMM.
/// @param[in] slotNumber - The recorder I/O board slot number.
/// @param[in] cfgType - The type of configuration to access.
///
/// @return Pointer to a top slot board I/O board structure
///
//******************************************************
T_PBOARDCALS CIOSetupConfig::GetTopSlotBoardRangeCalInfo(const USHORT slotNumber, const REFERENCE cfgType) const
{
  T_PRECORDERCAL pTopSlotCalInfo = NULL;
  T_PBOARDCALS pIOBoardCalInfo = NULL;

  // If it's a valid top slot get the ptr to CMM data
  if( DEVICE_INFO.GetSlotPosition( slotNumber ) == SLOT_TOP )
  {
    pTopSlotCalInfo = GetTopSlotRecorderCalInfo( cfgType );
    if( pTopSlotCalInfo != NULL )
    {
    pIOBoardCalInfo = &(pTopSlotCalInfo->RecorderCals[slotNumber]);
    }
  }
  return pIOBoardCalInfo;
}


//******************************************************
//  GetTopSlot()
///
/// Get a top slot card from the CMM.
/// @param[in] slotNumber - The recorder I/O board slot number.
/// @param[in] cfgType - The type of configuration to access.
///
/// @return Pointer to a top slot board
///
//******************************************************
T_PTOPSLOT CIOSetupConfig::GetTopSlot(const USHORT slotNumber, const REFERENCE cfgType) const
{
  T_PTOPSLOT pTopSlot = NULL;

  // If it's a valid top slot get the ptr to CMM data
  if( DEVICE_INFO.GetSlotPosition( slotNumber ) == SLOT_TOP )
  {
    pTopSlot = reinterpret_cast<T_PTOPSLOT>(CConfiguration::GetBlock( BLK_TOPSLOT, slotNumber, m_ConfigurationId, cfgType ));
  }
  return pTopSlot;
}


//******************************************************
//  GetBottomSlot()
///
/// Get a bottom slot from the CMM.
/// @param[in] slotNumber - The recorder I/O board slot number.
/// @param[in] cfgType - The type of configuration to access.
///
/// @return Pointer to a bottom slot board
///
//******************************************************
T_PBOTTOMSLOT CIOSetupConfig::GetBottomSlot(const USHORT slotNumber, const REFERENCE cfgType) const
{
  T_PBOTTOMSLOT pBottomSlot = NULL;
  CMMERROR err = CMM_FAILED;
  // If it's a valid bottom slot get the ptr to CMM data
  if( DEVICE_INFO.GetSlotPosition( slotNumber ) == SLOT_BOTTOM )
  {
    // Bottom slot cards being accessed
    pBottomSlot = reinterpret_cast<T_PBOTTOMSLOT>(CConfiguration::GetBlock( BLK_BOTTOMSLOT, slotNumber, m_ConfigurationId, cfgType ));
  }
  return pBottomSlot;
}


//******************************************************
//  CreateTopSlot()
///
/// Create a top slot card in the CMM.
/// @param[in] slotNumber - The recorder I/O board slot number.
///
/// @return Pointer to a top slot board
///
//******************************************************
T_PTOPSLOT CIOSetupConfig::CreateTopSlot(USHORT slotNumber)
{
  T_PTOPSLOT pTopSlot = NULL;
  CMMERROR err = CMM_FAILED;

  if( DEVICE_INFO.GetSlotPosition( slotNumber ) == SLOT_TOP )
  {
    // Top slot cards being accessed
    pTopSlot = reinterpret_cast<T_PTOPSLOT>(CConfiguration::CreateNewBlock( BLK_TOPSLOT, slotNumber, m_ConfigurationId ));
  }
  return pTopSlot;
}


//******************************************************
//  CreateBottomSlot()
///
/// Create a bottom slot in the CMM.
/// @param[in] slotNumber - The recorder I/O board slot number.
///
/// @return Pointer to a bottom slot board
///
//******************************************************
T_PBOTTOMSLOT CIOSetupConfig::CreateBottomSlot(USHORT slotNumber)
{
  T_PBOTTOMSLOT pBottomSlot = NULL;

  if( DEVICE_INFO.GetSlotPosition( slotNumber ) == SLOT_BOTTOM )
  {
    // Bottom slot cards being accessed
    pBottomSlot = reinterpret_cast<T_PBOTTOMSLOT>(CConfiguration::CreateNewBlock( BLK_BOTTOMSLOT, slotNumber, m_ConfigurationId ));
  }
  return pBottomSlot;
}


//******************************************************
///
/// Sets the engineering values for any AI channel in the CMM.
/// @param[in] sysChannelNo - The system channel number.
/// @param[in] EngZero - The lower enginering value to set.
/// @param[in] EngSpan - The upper engineering value to set.
///
/// @return CONFIG_OK if valid return; otherwise CONFIG_ERROR
///
/// @note: on reverse scales the upper value will be lower than the lower
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::SelectSlotEngValues( USHORT sysChannelNo, float EngZero, float EngSpan )
{
  USHORT slotNo;
  USHORT chanNo;
  T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;

  if( indexOfBoardSlotAndChannel( sysChannelNo, &slotNo, &chanNo ) == TRUE )
  {
    retValue = SelectSlotEngValues( slotNo, chanNo, EngZero, EngSpan );
  }

  return retValue;
}


//******************************************************
//  SelectAcqRate()
///
/// Sets the current channel acqsistion rate for any input channel on any card in the CMM.
/// @param[in] sysChannelNo - The system channel number.
/// @param[in] Rate - The acquisition rate of the channel.
///
/// @return Whether the given rate could be selected
///
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::SelectAcqRate( USHORT sysChannelNo, USHORT Rate )
{
  USHORT slotNo;
  USHORT chanNo;
  T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;

  if( indexOfBoardSlotAndChannel( sysChannelNo, &slotNo, &chanNo ) == TRUE )
  {
    retValue = SelectSlotAcqRate(slotNo, chanNo, Rate);
  }

  return retValue;
}


//******************************************************
//  SelectVoltageRange()
///
/// Sets the current channel range for any voltage channel on any card in the CMM.
/// @param[in] sysChannelNo - The system channel number.
/// @param[in] Range - The voltage range of the channel.
///
/// @return Whether the given range could be selected
///
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::SelectVoltageRange( USHORT sysChannelNo, USHORT Range )
{
  USHORT slotNo;
  USHORT chanNo;
  T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;

  if( indexOfBoardSlotAndChannel( sysChannelNo, &slotNo, &chanNo ) == TRUE )
  {
    retValue = SelectSlotRange( slotNo, chanNo, AI_CHANNEL_TYPE_LINEAR_VOLTS, Range );
  }

  return retValue;
}


//******************************************************
//  SelectCurrentRange()
///
/// Sets the current channel range for any current channel on any card in the CMM.
/// @param[in] sysChannelNo - The system channel number.
/// @param[in] Range - The current range of the channel.
///
/// @return Whether the given range could be selected
///
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::SelectCurrentRange( USHORT sysChannelNo, USHORT Range )
{
  USHORT slotNo;
  USHORT chanNo;
  T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;

  if( indexOfBoardSlotAndChannel( sysChannelNo, &slotNo, &chanNo ) == TRUE )
  {
    retValue = SelectSlotRange( slotNo, chanNo, AI_CHANNEL_TYPE_LINEAR_AMPS, Range );
  }

  return retValue;
}


//******************************************************
//  SelectResistanceRange()
///
/// Sets the current channel range for any resistance channel on any card in the CMM.
/// @param[in] sysChannelNo - The system channel number.
/// @param[in] Range - The rsistance range of the channel.
///
/// @return Whether the given range could be selected
///
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::SelectResistanceRange( USHORT sysChannelNo, USHORT Range )
{
  USHORT slotNo;
  USHORT chanNo;
  T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;

  if( indexOfBoardSlotAndChannel( sysChannelNo, &slotNo, &chanNo ) == TRUE )
  {
    retValue = SelectSlotRange( slotNo, chanNo, AI_CHANNEL_TYPE_LINEAR_OHMS, Range );
  }

  return retValue;
}


//******************************************************
//  SelectTCRange()
///
/// Sets the current channel range for any voltage channel on any card in the CMM.
/// @param[in] sysChannelNo - The TC channel number.
/// @param[in] Range - The TC range of the channel.
///
/// @return Whether the given range could be selected
///
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::SelectTCRange( USHORT sysChannelNo, USHORT Range )
{
  USHORT slotNo;
  USHORT chanNo;
  T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;

  if( indexOfBoardSlotAndChannel( sysChannelNo, &slotNo, &chanNo ) == TRUE )
  {
    retValue = SelectSlotTCRange(slotNo, chanNo, Range);
  }

  return retValue;
}


//******************************************************
//  SelectRTRange()
///
/// Sets the current channel range for any RT channel on any card in the CMM.
/// @param[in] sysChannelNo - The system channel number.
/// @param[in] Range - The RT range of the channel.
///
/// @return Whether the given range could be selected
///
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::SelectRTRange( USHORT sysChannelNo, USHORT Range )
{
  USHORT slotNo;
  USHORT chanNo;
  T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;

  if( indexOfBoardSlotAndChannel( sysChannelNo, &slotNo, &chanNo ) == TRUE )
  {
    retValue = SelectSlotRTRange(slotNo, chanNo, Range);
  }

  return retValue;
}

//******************************************************
//  SelectSlotAcqRate()
///
/// Sets the current channel acqsistion rate for any input channel on any card in the CMM.
/// @param[in] SlotNo - The card slot number.
/// @param[in] ChanNo - The card channel number.
/// @param[in] Rate - The acquisition rate of the channel.
///
/// @return Whether the given rate could be selected
///
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::SelectSlotAcqRate( USHORT slotNo, USHORT chanNo, USHORT Rate )
{
  T_PTOPSLOT pTopSlot = NULL;
  T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;

  pTopSlot = GetTopSlot( slotNo, CONFIG_MODIFIABLE );
  if( pTopSlot != NULL )
  {
    // Make AI board channel configured for reading at correct rate
    pTopSlot->AIChan[chanNo].AcqRate = Rate;
    retValue = CONFIG_OK;
  }

  return retValue;
}


//******************************************************
//  SelectSlotRange()
///
/// Sets the current channel range for any voltage channel on any card in the CMM.
/// @param[in] SlotNo - The card slot number.
/// @param[in] ChanNo - The card channel number.
/// @param[in] chanSelect - The card channel selection.
/// @param[in] Range - The voltage range of the channel.
///
/// @return Whether the given range could be selected
///
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::SelectSlotRange( USHORT slotNo, USHORT chanNo, USHORT chanSelect, USHORT Range )
{
  T_PTOPSLOT pTopSlot = NULL;
  T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;

  pTopSlot = GetTopSlot( slotNo, CONFIG_MODIFIABLE );
  if( pTopSlot != NULL )
  {
    // Make AI board channel configured for reading volts
    pTopSlot->AIChan[chanNo].Type = chanSelect;

    pTopSlot->AIChan[chanNo].Linear.RangePreset = Range;
    retValue = CONFIG_OK;
  }

  return retValue;
}


//******************************************************
//  SelectSlotTCRange()
///
/// Sets the current channel range for any voltage channel on any card in the CMM.
/// @param[in] SlotNo - The card slot number.
/// @param[in] ChanNo - The card channel number.
/// @param[in] Range - The TC range of the channel.
///
/// @return Whether the given range could be selected
///
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::SelectSlotTCRange( USHORT slotNo, USHORT chanNo, USHORT Range )
{
  T_PTOPSLOT pTopSlot = NULL;
  T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;

  pTopSlot = GetTopSlot( slotNo, CONFIG_MODIFIABLE );
  if( pTopSlot != NULL )
  {
    // Make AI board channel configured for reading a TC
    pTopSlot->AIChan[chanNo].Type = AI_CHANNEL_TYPE_TC;
    pTopSlot->AIChan[chanNo].TC.SelectedTC = Range;
    retValue = CONFIG_OK;
  }

  return retValue;
}


//******************************************************
//  SelectSlotRTRange()
///
/// Sets the current channel range for any RT channel on any card in the CMM.
/// @param[in] SlotNo - The card slot number.
/// @param[in] ChanNo - The card channel number.
/// @param[in] Range - The RT range of the channel.
///
/// @return Whether the given range could be selected
///
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::SelectSlotRTRange( USHORT slotNo, USHORT chanNo, USHORT Range )
{
  T_PTOPSLOT pTopSlot = NULL;
  T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;

  pTopSlot = GetTopSlot( slotNo, CONFIG_MODIFIABLE );
  if( pTopSlot != NULL )
  {
    // Make AI board channel configured for reading a RT
    pTopSlot->AIChan[chanNo].Type = AI_CHANNEL_TYPE_RT;
    pTopSlot->AIChan[chanNo].RT.SelectedRT = Range;
    retValue = CONFIG_OK;
  }

  return retValue;
}

//******************************************************
///
/// Sets the engineering values for any AI channel in the CMM.
/// @param[in] SlotNo - The card slot number.
/// @param[in] ChanNo - The card channel number.
/// @param[in] pEngZero - The lower enginering value.
/// @param[in] pEngSpan - The upper engineering value.
///
/// @return CONFIG_OK if valid return; otherwise CONFIG_ERROR
///
/// @note: on reverse scales the upper value will be lower than the lower
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::SelectSlotEngValues( USHORT slotNo, USHORT chanNo, float EngZero, float EngSpan )
{
  T_PTOPSLOT pTopSlot = NULL;
  T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;

  pTopSlot = GetTopSlot( slotNo, CONFIG_MODIFIABLE );
  if( pTopSlot != NULL )
  {
    pTopSlot->AIChan[chanNo].EngZero = EngZero;
    pTopSlot->AIChan[chanNo].EngSpan = EngSpan;
    retValue = CONFIG_OK;
  }

  return retValue;
}


//******************************************************
//  QueryAIChannelSelection()
///
/// Queries the current channel range for any voltage channel on any card in the CMM.
/// @param[in] configType - Whether the current or pending configuration is being queried.
/// @param[in] sysChannelNo - The system channel number.
/// @param[out] pSelection - Channel selction.
///
/// @return CONFIG_OK if valid return; otherwise CONFIG_ERROR
///
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::QueryAIChannelSelection( REFERENCE configType, USHORT sysChannelNo, USHORT *pSelection )
{
  USHORT slotNo;
  USHORT chanNo;
  T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;

  if( m_pSlotMapObj != NULL )
  {
    slotNo = m_pSlotMapObj->GetAnaInChannelSlotNo( sysChannelNo, ONE_BASED );
    chanNo = m_pSlotMapObj->GetBoardChannelFromAnaInChannel( sysChannelNo, ONE_BASED );
    if( (SMAP_ILLEGAL_INDEX != slotNo) && (SMAP_ILLEGAL_INDEX != chanNo) )
    retValue = QueryAISlotChannelSelection( configType, slotNo, chanNo, pSelection );
  }

  return retValue;
}


//******************************************************
//  QueryAcqRate()
///
/// Queries the current AI channel acqusistion rate for any input channel on any card in the CMM.
/// @param[in] configType - Whether the current or pending configuration is being queried.
/// @param[in] slotNo - The slot number.
/// @param[in] cardChanNo - The card channel number.
/// @param[out] Rate - The acquisition rate of the channel.
///
/// @return CONFIG_OK if valid return; otherwise CONFIG_ERROR
///
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::QueryAIAcqRate( const REFERENCE configType, const USHORT slotNo, const USHORT cardChanNo, USHORT *pRate )
{
  T_PTOPSLOT pTopSlot = NULL;
  T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;
//	class CBrdInfo *pBrdInfo = NULL;
  class CSlotMap *pSlotMap = NULL;
  BOOL isPrimaryChannel = TRUE;
  USHORT PrimaryChanNo;
  USHORT BankNo;

  pSlotMap = CSlotMap::GetHandle();
//	pBrdInfo = CBrdInfo::GetHandle();
  if( pSlotMap != NULL )
  {
    if( (SMAP_ILLEGAL_INDEX != slotNo) && (SMAP_ILLEGAL_INDEX != cardChanNo) )
    {
    pTopSlot = GetTopSlot( slotNo, configType );
    if( pTopSlot != NULL )
    {
      if( GlbDevCaps.GetSlotType(slotNo) == BOARD_EZ_AI )
      {
        isPrimaryChannel = GlbDevCaps.AIAcqRatePrimaryChannel(slotNo, cardChanNo, &PrimaryChanNo, &BankNo);
        *pRate = pTopSlot->AIChan[PrimaryChanNo].AcqRate;
      }
      else
      {
        *pRate = pTopSlot->AIChan[cardChanNo].AcqRate;
      }
      retValue = CONFIG_OK;
    }
    }
  }

  return retValue;
}


//******************************************************
//  QueryAIAcqRateStatus()
///
/// Queries the current AI channel acqusistion rate status for any input channel on any card in the CMM.
/// @param[in] configType - Whether the current or pending configuration is being queried.
/// @param[in] slotNo - The slot number.
/// @param[in] cardChanNo - The card channel number.
/// @param[out] Rate - The acquisition rate of the channel.
///
/// @return TRUE on channel being a primary channel; otherwise FALSE
///
//******************************************************
BOOL CIOSetupConfig::QueryAIAcqRateStatus( const REFERENCE configType, const USHORT slotNo, const USHORT cardChanNo, USHORT *pRate )
{
  T_PTOPSLOT pTopSlot = NULL;
  class CBrdInfo *pBrdInfo = NULL;
  class CSlotMap *pSlotMap = NULL;
  BOOL isPrimaryChannel = TRUE;
  USHORT PrimaryChanNo;
  USHORT BankNo;

  pSlotMap = CSlotMap::GetHandle();
  pBrdInfo = CBrdInfo::GetHandle();
  if( pSlotMap != NULL )
  {
    if( (SMAP_ILLEGAL_INDEX != slotNo) && (SMAP_ILLEGAL_INDEX != cardChanNo) )
    {
    pTopSlot = GetTopSlot( slotNo, configType );
    if( pTopSlot != NULL )
    {
      if( GlbDevCaps.GetSlotType(slotNo) == BOARD_EZ_AI )
      {
        isPrimaryChannel = GlbDevCaps.AIAcqRatePrimaryChannel(slotNo, cardChanNo, &PrimaryChanNo, &BankNo);
        *pRate = pTopSlot->AIChan[PrimaryChanNo].AcqRate;
      }
      else
      {
        *pRate = pTopSlot->AIChan[cardChanNo].AcqRate;
      }
    }
    }
  }

  return isPrimaryChannel;
}


//******************************************************
//  QuerySysAIAcqRate()
///
/// Queries the current AI channel acqusistion rate for any input channel on any card in the CMM.
/// @param[in] configType - Whether the current or pending configuration is being queried.
/// @param[in] sysChannelNo - The system channel number.
/// @param[out] Rate - The acquisition rate of the channel.
///
/// @return CONFIG_OK if valid return; otherwise CONFIG_ERROR
///
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::QueryAISysChanAcqRate( const REFERENCE configType, const USHORT sysChannelNo, USHORT *pRate )
{
  USHORT slotNo;
  USHORT chanNo;
  T_PTOPSLOT pTopSlot = NULL;
  T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;
  class CSlotMap *pSlotMap = NULL;

  pSlotMap = CSlotMap::GetHandle();
  if( pSlotMap != NULL )
  {
    slotNo = pSlotMap->GetAnaInChannelSlotNo( sysChannelNo, ONE_BASED );
    chanNo = pSlotMap->GetBoardChannelFromAnaInChannel( sysChannelNo, ONE_BASED );
    if( (SMAP_ILLEGAL_INDEX != slotNo) && (SMAP_ILLEGAL_INDEX != chanNo) )
    {
    pTopSlot = GetTopSlot( slotNo, configType );
    if( pTopSlot != NULL )
    {
      retValue = QueryAIAcqRate(configType, slotNo, chanNo, pRate);
    }
    }
  }

  return retValue;
}


//******************************************************
///
/// Queries the engineering values for any AI channel in the CMM.
/// @param[in] sysChannelNo - The system channel number.
/// @param[out] pSlotNo - The board slot number.
/// @param[out] pChanNo - The board channel number.
///
/// @return TRUE if board and board channel successfully identified; otherwise FALSE
///
/// @note: on reverse scales the upper value will be lower than the lower
//******************************************************
BOOL CIOSetupConfig::indexOfBoardSlotAndChannel( const USHORT sysChannelNo, USHORT *pSlotNo, USHORT *pChanNo )
{
  BOOL retValue = FALSE;

  if( m_pSlotMapObj != NULL )
  {
    /// Otherwise cannot map config to recorder channels
    *pSlotNo = m_pSlotMapObj->GetAnaInChannelSlotNo( sysChannelNo, ONE_BASED );
    *pChanNo = m_pSlotMapObj->GetBoardChannelFromAnaInChannel ( sysChannelNo, ONE_BASED );
    if( (SMAP_ILLEGAL_INDEX != *pSlotNo) && (SMAP_ILLEGAL_INDEX != *pChanNo) )
    retValue = TRUE;
  }

  return retValue;
}

//******************************************************
///
/// Queries the engineering values for any AI channel in the CMM.
/// @param[in] configType - Whether the current or pending configuration is being queried.
/// @param[in] sysChannelNo - The system channel number.
/// @param[out] pEngZero - The lower enginering value to set.
/// @param[out] pEngSpan - The upper engineering value to set.
///
/// @return CONFIG_OK if valid return; otherwise CONFIG_ERROR
///
/// @note: on reverse scales the upper value will be lower than the lower
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::QuerySlotEngValues( REFERENCE configType, USHORT sysChannelNo, float *pEngZero, float *pEngSpan )
{
  USHORT slotNo;
  USHORT chanNo;
  T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;

  if( indexOfBoardSlotAndChannel( sysChannelNo, &slotNo, &chanNo ) == TRUE )
  {
    retValue = QuerySlotEngValues( configType, slotNo, chanNo, pEngZero, pEngSpan );
  }

  return retValue;
}


//******************************************************
//  QueryVoltageRange()
///
/// Queries the current channel range for any voltage channel on any card in the CMM.
/// @param[in] configType - Whether the current or pending configuration is being queried.
/// @param[in] sysChannelNo - The system channel number.
/// @param[out] Range - The voltage range of the channel.
///
/// @return CONFIG_OK if valid return; otherwise CONFIG_ERROR
///
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::QueryVoltageRange( REFERENCE configType, USHORT sysChannelNo, USHORT *pRange )
{
  USHORT slotNo;
  USHORT chanNo;
  T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;

  if( indexOfBoardSlotAndChannel( sysChannelNo, &slotNo, &chanNo ) == TRUE )
  {
    retValue = QuerySlotVoltageRange( configType, slotNo, chanNo, pRange );
  }

  return retValue;
}


//******************************************************
//  QueryCurrentRange()
///
/// Queries the current channel range for any current channel on any card in the CMM.
/// @param[in] configType - Whether the current or pending configuration is being queried.
/// @param[in] sysChannelNo - The system channel number.
/// @param[out] Range - The current range of the channel.
///
/// @return CONFIG_OK if valid return; otherwise CONFIG_ERROR
///
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::QueryCurrentRange( REFERENCE configType, USHORT sysChannelNo, USHORT *pRange )
{
  USHORT slotNo;
  USHORT chanNo;
  T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;

  if( indexOfBoardSlotAndChannel( sysChannelNo, &slotNo, &chanNo ) == TRUE )
  {
    retValue = QuerySlotCurrentRange( configType, slotNo, chanNo, pRange );
  }

  return retValue;
}


//******************************************************
//  QueryResistanceRange()
///
/// Queries the current channel range for any resistance channel on any card in the CMM.
/// @param[in] configType - Whether the current or pending configuration is being queried.
/// @param[in] sysChannelNo - The system channel number.
/// @param[out] Range - The rsistance range of the channel.
///
/// @return CONFIG_OK if valid return; otherwise CONFIG_ERROR
///
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::QueryResistanceRange( REFERENCE configType, USHORT sysChannelNo, USHORT *pRange )
{
  USHORT slotNo;
  USHORT chanNo;
  T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;

  if( indexOfBoardSlotAndChannel( sysChannelNo, &slotNo, &chanNo ) == TRUE )
  {
    retValue = QuerySlotResistanceRange( configType, slotNo, chanNo, pRange );
  }

  return retValue;
}


//******************************************************
//  QueryTCRange()
///
/// Queries the current channel range for any voltage channel on any card in the CMM.
/// @param[in] configType - Whether the current or pending configuration is being queried.
/// @param[in] sysChannelNo - The TC channel number.
/// @param[out] Range - The TC range of the channel.
///
/// @return CONFIG_OK if valid return; otherwise CONFIG_ERROR
///
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::QueryTCRange( REFERENCE configType, USHORT sysChannelNo, USHORT *pRange )
{
  USHORT slotNo;
  USHORT chanNo;
  T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;

  if( indexOfBoardSlotAndChannel( sysChannelNo, &slotNo, &chanNo ) == TRUE )
  {
    retValue = QuerySlotTCRange( configType, slotNo, chanNo, pRange );
  }

  return retValue;
}


//******************************************************
//  QueryRTRange()
///
/// Queries the current channel range for any RT channel on any card in the CMM.
/// @param[in] configType - Whether the current or pending configuration is being queried.
/// @param[in] sysChannelNo - The system channel number.
/// @param[out] Range - The RT range of the channel.
///
/// @return CONFIG_OK if valid return; otherwise CONFIG_ERROR
///
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::QueryRTRange( REFERENCE configType, USHORT sysChannelNo, USHORT *pRange )
{
  USHORT slotNo;
  USHORT chanNo;
  T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;

  if( indexOfBoardSlotAndChannel( sysChannelNo, &slotNo, &chanNo ) == TRUE )
  {
    retValue = QuerySlotRTRange( configType, slotNo, chanNo, pRange );
  }

  return retValue;
}


//******************************************************
///
/// Get the current channel type for any channel on any card from the CMM.
/// @param[in] configType - Whether the current or pending configuration is being queried.
/// @param[in] SlotNo - The card slot number.
/// @param[in] ChanNo - The card channel number.
/// @param[in] pchanType - The type channel selected.
///
/// @return CONFIG_OK if valid return; otherwise CONFIG_ERROR
///
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::QuerySlotChannelSelectedType( REFERENCE configType, USHORT slotNo,
                        USHORT chanNo, USHORT *pchanType)
{
  T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;

  *pchanType = GetChannelSelectedType( slotNo, chanNo, configType );

  if(*pchanType != CHANNEL_CAP_UNKNOWN)
    retValue = CONFIG_OK;

  return retValue;
}

//******************************************************
///
/// Queries the current channel range for any voltage channel on any card in the CMM.
/// @param[in] configType - Whether the current or pending configuration is being queried.
/// @param[in] SlotNo - The card slot number.
/// @param[in] ChanNo - The card channel number.
/// @param[out] pSelection - Channel selction.
///
/// @return CONFIG_OK if valid return; otherwise CONFIG_ERROR
///
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::QueryAISlotChannelSelection( REFERENCE configType, USHORT slotNo,
                      USHORT chanNo, USHORT *pSelection )
{
  T_PTOPSLOT pTopSlot = NULL;
  T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;

  pTopSlot = GetTopSlot( slotNo, configType );
  if( pTopSlot != NULL )
  {
    *pSelection = pTopSlot->AIChan[chanNo].Type;
    retValue = CONFIG_OK;
  }

  return retValue;
}


//******************************************************
///
/// Queries the current channel acqsistion rate for any input channel on any card in the comitted CMM.
/// @param[in] configType - Whether the current or pending configuration is being queried.
/// @param[in] SlotNo - The card slot number.
/// @param[in] ChanNo - The card channel number.
/// @param[out] Rate - The acquisition rate of the channel.
///
/// @return CONFIG_OK if valid return; otherwise CONFIG_ERROR
///
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::QuerySlotAcqRate( const REFERENCE configType, const USHORT slotNo, const USHORT chanNo, USHORT *pRate )
{
  T_PTOPSLOT pTopSlot = NULL;
  T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;
  class CSlotMap *pSlotMap = NULL;

  pSlotMap = CSlotMap::GetHandle();
  pTopSlot = GetTopSlot( slotNo, configType );
  if( pTopSlot != NULL )
  {
    if( pSlotMap->GetChannelSelectedType( slotNo, chanNo ) == CHANNEL_AI )
    {
    retValue = QueryAIAcqRate(configType, slotNo, chanNo, pRate);
    }
    if( pSlotMap->GetChannelSelectedType( slotNo, chanNo ) == CHANNEL_PULSE )
    {
    /// @todo Add correct rates for pulse card
    *pRate = 1;
    retValue = CONFIG_OK;
    }
  }

  return retValue;
}


//******************************************************
///
/// Queries the current channel range for any voltage channel on any card in the CMM.
/// @param[in] configType - Whether the current or pending configuration is being queried.
/// @param[in] SlotNo - The card slot number.
/// @param[in] ChanNo - The card channel number.
/// @param[out] Range - The voltage range of the channel.
///
/// @return CONFIG_OK if valid return; otherwise CONFIG_ERROR
///
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::QuerySlotVoltageRange( REFERENCE configType, USHORT slotNo, USHORT chanNo,
                     USHORT *pRange )
{
  T_PTOPSLOT pTopSlot = NULL;
  T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;

  pTopSlot = GetTopSlot( slotNo, configType );
  if( pTopSlot != NULL )
  {
    *pRange = pTopSlot->AIChan[chanNo].Linear.RangePreset;
    retValue = CONFIG_OK;
  }

  return retValue;
}


//******************************************************
///
/// Queries the current channel range for any current channel on any card in the CMM.
/// @param[in] configType - Whether the current or pending configuration is being queried.
/// @param[in] SlotNo - The card slot number.
/// @param[in] ChanNo - The card channel number.
/// @param[out] Range - The current range of the channel.
///
/// @return CONFIG_OK if valid return; otherwise CONFIG_ERROR
///
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::QuerySlotCurrentRange( REFERENCE configType, USHORT slotNo, USHORT chanNo,
                     USHORT *pRange )
{
  T_PTOPSLOT pTopSlot = NULL;
  T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;

  pTopSlot = GetTopSlot( slotNo, configType );
  if( pTopSlot != NULL )
  {
    *pRange = pTopSlot->AIChan[chanNo].Linear.RangePreset;
    retValue = CONFIG_OK;
  }

  return retValue;
}


//******************************************************
///
/// Queries the current channel range for any resistance channel on any card in the CMM.
/// @param[in] configType - Whether the current or pending configuration is being queried.
/// @param[in] SlotNo - The card slot number.
/// @param[in] ChanNo - The card channel number.
/// @param[out] Range - The rsistance range of the channel.
///
/// @return CONFIG_OK if valid return; otherwise CONFIG_ERROR
///
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::QuerySlotResistanceRange( REFERENCE configType, USHORT slotNo,
                     USHORT chanNo, USHORT *pRange )
{
  T_PTOPSLOT pTopSlot = NULL;
  T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;

  pTopSlot = GetTopSlot( slotNo, configType );
  if( pTopSlot != NULL )
  {
    *pRange = pTopSlot->AIChan[chanNo].Linear.RangePreset;
    retValue = CONFIG_OK;
  }

  return retValue;
}


//******************************************************
///
/// Queries the current channel range for any voltage channel on any card in the CMM.
/// @param[in] configType - Whether the current or pending configuration is being queried.
/// @param[in] SlotNo - The card slot number.
/// @param[in] ChanNo - The TC card channel number.
/// @param[out] Range - The TC range of the channel.
///
/// @return CONFIG_OK if valid return; otherwise CONFIG_ERROR
///
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::QuerySlotTCRange( REFERENCE configType, USHORT slotNo, USHORT chanNo,
                    USHORT *pRange )
{
  T_PTOPSLOT pTopSlot = NULL;
  T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;

  pTopSlot = GetTopSlot( slotNo, configType );
  if( pTopSlot != NULL )
  {
    *pRange = pTopSlot->AIChan[chanNo].TC.SelectedTC;
    retValue = CONFIG_OK;
  }

  return retValue;
}


//******************************************************
///
/// Queries the current channel range for any RT channel on any card in the CMM.
/// @param[in] configType - Whether the current or pending configuration is being queried.
/// @param[in] SlotNo - The card slot number.
/// @param[in] ChanNo - The card channel number.
/// @param[out] Range - The RT range of the channel.
///
/// @return CONFIG_OK if valid return; otherwise CONFIG_ERROR
///
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::QuerySlotRTRange( REFERENCE configType, USHORT slotNo, USHORT chanNo, USHORT *pRange )
{
  T_PTOPSLOT pTopSlot = NULL;
  T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;

  pTopSlot = GetTopSlot( slotNo, configType );
  if( pTopSlot != NULL )
  {
    *pRange = pTopSlot->AIChan[chanNo].RT.SelectedRT;
    retValue = CONFIG_OK;
  }

  return retValue;
}


//******************************************************
///
/// Queries the engineering values for any AI channel in the CMM.
/// @param[in] configType - Whether the current or pending configuration is being queried.
/// @param[in] SlotNo - The card slot number.
/// @param[in] ChanNo - The card channel number.
/// @param[out] pEngZero - The lower enginering value.
/// @param[out] pEngSpan - The upper engineering value.
///
/// @return CONFIG_OK if valid return; otherwise CONFIG_ERROR
///
/// @note: on reverse scales the upper value will be lower than the lower
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::QuerySlotEngValues( REFERENCE configType, USHORT slotNo, USHORT chanNo,
                    float *pEngZero, float *pEngSpan )
{
  T_PTOPSLOT pTopSlot = NULL;
  T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;

  pTopSlot = GetTopSlot( slotNo, configType );
  if( pTopSlot != NULL )
  {
    *pEngZero = pTopSlot->AIChan[chanNo].EngZero;
    *pEngSpan = pTopSlot->AIChan[chanNo].EngSpan;
    retValue = CONFIG_OK;
  }

  return retValue;
}


//******************************************************
///
/// Queries the state of SQRT extract in the CMM.
/// @param[in] configType - Whether the current or pending configuration is being queried.
/// @param[in] SlotNo - The card slot number.
/// @param[in] ChanNo - The card channel number.
/// @param[out] pState - Whether SQRT extract is selected.
///
/// @return CONFIG_OK if valid return; otherwise CONFIG_ERROR
///
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::GetSlotSQRTExtractState( REFERENCE configType, USHORT slotNo, USHORT chanNo, BOOL *pState )
{
  T_PTOPSLOT pTopSlot = NULL;
  T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;

  pTopSlot = GetTopSlot( slotNo, configType );
  if( pTopSlot != NULL )
  {
    *pState = pTopSlot->AIChan[chanNo].SqrtExtract;
    retValue = CONFIG_OK;
  }

  return retValue;
}


//******************************************************
///
/// Sets the state of SQRT extract in the CMM.
/// @param[in] SlotNo - The card slot number.
/// @param[in] ChanNo - The card channel number.
/// @param[out] pState - Whether SQRT extract is selected.
///
/// @return CONFIG_OK if valid return; otherwise CONFIG_ERROR
///
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::SetSlotSQRTExtractState( USHORT slotNo, USHORT chanNo, BOOL State )
{
  T_PTOPSLOT pTopSlot = NULL;
  T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;

  pTopSlot = GetTopSlot( slotNo, CONFIG_MODIFIABLE );
  if( pTopSlot != NULL )
  {
    pTopSlot->AIChan[chanNo].SqrtExtract = State;
    retValue = CONFIG_OK;
  }

  return retValue;
}


//******************************************************
///
/// Sets the state of SQRT extract in the CMM.
/// @param[in] sysChannelNo - The system channel number.
/// @param[out] pState - Whether SQRT extract is selected.
///
/// @return CONFIG_OK if valid return; otherwise CONFIG_ERROR
///
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::SetSQRTExtractState( USHORT sysChannelNo, BOOL State )
{
  USHORT slotNo;
  USHORT chanNo;
  T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;

  if( indexOfBoardSlotAndChannel( sysChannelNo, &slotNo, &chanNo ) == TRUE )
  {
    retValue = SetSlotSQRTExtractState( slotNo, chanNo, State );
  }

  return retValue;
}


//******************************************************
///
/// Gets the state of SQRT extract in the CMM.
/// @param[in] configType - Whether the current or pending configuration is being queried.
/// @param[in] sysChannelNo - The system channel number.
/// @param[out] pState - Whether SQRT extract is selected.
///
/// @return CONFIG_OK if valid return; otherwise CONFIG_ERROR
///
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::GetSQRTExtractState( REFERENCE configType, USHORT sysChannelNo, BOOL *pState )
{
  USHORT slotNo;
  USHORT chanNo;
  T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;

  if( indexOfBoardSlotAndChannel( sysChannelNo, &slotNo, &chanNo ) == TRUE )
  {
    retValue = GetSlotSQRTExtractState( configType, slotNo, chanNo, pState );
  }

  return retValue;
}


//******************************************************
///
/// Sets the pen that the analogue channel is tied to in the CMM.
/// @param[in] SlotNo - The card slot number.
/// @param[in] ChanNo - The card channel number.
/// @param[in] PenNo - The pen number (NO_TIED_TO_PEN if no pen selected).
///
/// @return CONFIG_OK if valid return; otherwise CONFIG_ERROR
///
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::SelectSlotTiedToPen( const USHORT slotNo, const USHORT chanNo, const USHORT PenNo )
{
  T_PTOPSLOT pTopSlot = NULL;
  T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;

  pTopSlot = GetTopSlot( slotNo, CONFIG_MODIFIABLE );
  if( pTopSlot != NULL )
  {
    pTopSlot->AIChan[chanNo].TiedTo = PenNo;
    retValue = CONFIG_OK;
  }

  return retValue;
}


//******************************************************
///
/// Gets the pen that the analogue channel is tied to from the CMM.
/// @param[in] configType - Whether the current or pending configuration is being queried.
/// @param[in] SlotNo - The card slot number.
/// @param[in] ChanNo - The card channel number.
/// @param[out] pPenNo - The pen number (NO_TIED_TO_PEN if no pen selected).
///
/// @return CONFIG_OK if valid return; otherwise CONFIG_ERROR
///
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::QuerySlotTiedToPen( const REFERENCE configType, const USHORT slotNo, const USHORT chanNo, USHORT *pPenNo )
{
  T_PTOPSLOT pTopSlot = NULL;
  T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;

  pTopSlot = GetTopSlot( slotNo, configType );
  if( pTopSlot != NULL )
  {
    *pPenNo = pTopSlot->AIChan[chanNo].TiedTo;
    retValue = CONFIG_OK;
  }

  return retValue;
}


//******************************************************
///
/// Sets the pen that the analogue channel is tied to in the CMM.
/// @param[in] sysChannelNo - The system channel number.
/// @param[in] PenNo - The pen number (NO_TIED_TO_PEN if no pen selected).
///
/// @return CONFIG_OK if valid return; otherwise CONFIG_ERROR
///
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::SelectTiedToPen( const USHORT sysChannelNo, const USHORT PenNo )
{
  USHORT slotNo;
  USHORT chanNo;
  T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;

  if( indexOfBoardSlotAndChannel( sysChannelNo, &slotNo, &chanNo ) == TRUE )
  {
    retValue = SelectSlotTiedToPen( slotNo, chanNo, PenNo );
  }

  return retValue;
}


//******************************************************
///
/// Gets the pen that the analogue channel is tied to from the CMM.
/// @param[in] configType - Whether the current or pending configuration is being queried.
/// @param[in] sysChannelNo - The system channel number.
/// @param[out] pPenNo - The pen number (NO_TIED_TO_PEN if no pen selected).
///
/// @return CONFIG_OK if valid return; otherwise CONFIG_ERROR
///
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::QueryTiedToPen( const REFERENCE configType, const USHORT sysChannelNo, USHORT *pPenNo )
{
  USHORT slotNo;
  USHORT chanNo;
  T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;

  if( indexOfBoardSlotAndChannel( sysChannelNo, &slotNo, &chanNo ) == TRUE )
  {
    retValue = QuerySlotTiedToPen( configType, slotNo, chanNo, pPenNo );
  }

  return retValue;
}

//******************************************************
///
/// Gets the pen that the analogue channel is tied to from the CMM.
/// @param[in] SlotNo - The card slot number.
/// @param[in] ChanNo - The card channel number.
/// @param[in] Units - The units (channel type) that the measurment is to be made in.
/// @param[in] RngZero - The lower range limit desired.
/// @param[in] RngSpan - The upper range limit desired.
///
/// @return CONFIG_OK if valid return; otherwise CONFIG_ERROR
///
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::SelectSlotUserDesiredRange( const USHORT slotNo, const USHORT chanNo, const UCHAR Units ,
                       const float RngZero, const float RngSpan )
{
  T_PTOPSLOT pTopSlot = NULL;
  T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;

  // Is the range within board capabilities?

  pTopSlot = GetTopSlot( slotNo, CONFIG_MODIFIABLE );
  if( pTopSlot != NULL )
  {
    // Select user selected range
    pTopSlot->AIChan[chanNo].Linear.Mode = USE_USER_LIMITS;
    //pTopSlot->AIChan[chanNo].Linear.Type = Units;
//		pTopSlot->AIChan[chanNo].Linear.Units =;		///< @todo: Set the textual representation of the channel units

    pTopSlot->AIChan[chanNo].Linear.UserLowLim = RngZero;
    pTopSlot->AIChan[chanNo].Linear.UserHighLim = RngSpan;
    retValue = CONFIG_OK;
  }

  return retValue;
}


//******************************************************
///
/// Gets the pen that the analogue channel is tied to from the CMM.
/// @param[in] sysChannelNo - The system channel number.
/// @param[out] Units - The desired channel type.
///
/// @return CONFIG_OK if valid return; otherwise CONFIG_ERROR
///
//******************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::SelectSlotUserDesiredRange( USHORT sysChannelNo, UCHAR Units ,
                       float RngZero, float RngSpan )
{
  USHORT slotNo;
  USHORT chanNo;
  T_CONFIG_RETURN_VALUE retValue = CONFIG_ERROR;

  if( indexOfBoardSlotAndChannel( sysChannelNo, &slotNo, &chanNo ) == TRUE )
  {
    retValue = SelectSlotUserDesiredRange( slotNo, chanNo, Units, RngZero, RngSpan );
  }

  return retValue;
}
//**********************************************************************
///
/// Function that is called immediately after a setup config is commited
/// to the CMM.
///
/// @return		T_CONFIG_RETURN_VALUE return value
///
//**********************************************************************
T_CONFIG_RETURN_VALUE CIOSetupConfig::PostCommitProcessing( void )
{
#ifdef STARTUP_LOGGING
  WCHAR InitLogFileName[ 256 ];
  WCHAR InitLogString[512];
  int iPathLen = 256;
  BOOLEAN isFileCreated = FALSE;
  CStorage kLogFile;
  CFileException kFileEx;

  pDALGLB->GetPath(	static_cast< T_STORAGE_PATH >( IDS_INTERNAL_SD ),
        InitLogFileName,
        256,
        &iPathLen );
  wcsncat_s( InitLogFileName, 256, L"PostCommit_IO.txt", (256 - wcslen( InitLogFileName )) );
  if( kLogFile.Open(	InitLogFileName,
        CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
        &kFileEx ) )
  {
    kLogFile.SeekToEnd();
    wcscpy(InitLogString,L"--------Initialisation started-------\n");
    kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
    wcscpy(InitLogString,L"WasBlockModified()\n");
    kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
    kLogFile.Close();
  }
#endif

  // Save recorder calibration non vol block into flash if anything has changed
  if( CConfiguration::WasBlockModified(BLK_RECORDERCAL, 0, m_ConfigurationId) == TRUE )
  {
#ifdef STARTUP_LOGGING
    if( kLogFile.Open(	InitLogFileName,
          CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
          &kFileEx ) )
    {
    kLogFile.SeekToEnd();
    wcscpy(InitLogString,L"NVCalibrationSaveToFlash()\n");
    kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
    kLogFile.Close();
    }
#endif
    NVCalibrationSaveToFlash();
  }
#ifdef STARTUP_LOGGING
  if( kLogFile.Open(	InitLogFileName,
        CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
        &kFileEx ) )
  {
    kLogFile.SeekToEnd();
    wcscpy(InitLogString,L"--------END-------\n");
    kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
    kLogFile.Close();
  }
#endif
  return CONFIG_OK;
}
//****************************************************************************
/// Save the calibration non vol structure into flash
///
/// return TRUE if OK, else FALSE
//****************************************************************************
BOOL CIOSetupConfig::NVCalibrationSaveToFlash()
{
  BOOL retVal = FALSE;

#ifndef DOCVIEW
#ifndef TTR6SETUP
  CATECal *pkATECal = CATECal::GetHandle();

  // update the NVRAM with the CMM calibration data
  CPPIOServiceManager *pkServiceManagerObj = NULL;       ///< Service manager
  CInputConditioning *pkICService = NULL;              ///< Input conditioning service

  pkServiceManagerObj = CPPIOServiceManager::GetHandle();

  if( pkServiceManagerObj != NULL )
  {
    pkICService = pkServiceManagerObj->GetICService();

    if( pkICService != NULL )
    {
    // now update the flash with the modifiable CMM data
    if( pkICService->RecorderCalCMMReload( ) )
    {
      // make sure we have the NV data saved
      retVal = pkICService->IOCalSave( );
    }
    }
  }
#endif
#endif

  return retVal;
}
//****************************************************************************
//
/// Method that loads the AMS2750 sensor configuration from NV
///
//****************************************************************************
void CIOSetupConfig::LoadAMS2750SensorBlockFromNV()
{
  CFlashManager *pkFlashMgr = CFlashManager::GetHandle();
  T_FLASH_STATUS eFlashStatus = pkFlashMgr->ReadBlock( FLASH_BLK_AMS2750_SENSORS, &m_AMS2750SensorsWorking, sizeof( T_AMS2750SENSORS ) );

  // check the block has not been initialised or the size has changed
  if( (  m_AMS2750SensorsWorking.Version == 0 ) || ( eFlashStatus != FLASH_STATUS_OKAY ) )
  {
    // the data has not been intialised therefore default the information
    DefaultAMS2750SensorInfo( &m_AMS2750SensorsWorking );

    // something has changed therefore write the defaulted information to flash as well
    // as updating the committed version
    UpdateAMS270SensorCommittedWithWorking();
  }
  else
  {
    // update the committed structure too
    memcpy( &m_AMS2750SensorsCommitted, &m_AMS2750SensorsWorking, sizeof( T_AMS2750SENSORS ) );
  }
}
//****************************************************************************
//
/// Method that gets the AMS2750 sensor block
///
/// @param[in]	REFERENCE cfgType - The desired sensor block type
///
/// @return A pointer to the relevant (committed/working) sensor block
///
//****************************************************************************
T_PAMS2750SENSORS CIOSetupConfig::GetAMS2750SensorBlock(REFERENCE cfgType)
{
  return ( cfgType == CONFIG_MODIFIABLE )?&m_AMS2750SensorsWorking:&m_AMS2750SensorsCommitted;
}
//****************************************************************************
//
/// Method that updates the working AMS2750 sensors with the committed copy - used when discarding
/// changes
///
//****************************************************************************
void CIOSetupConfig::UpdateAMS270SensorWorkingWithCommitted( )
{
  memcpy( &m_AMS2750SensorsWorking, &m_AMS2750SensorsCommitted, sizeof( T_AMS2750SENSORS ) );
}
//****************************************************************************
//
/// Method that updates the committed AMS2750 sensors with the working copy - used when committing
/// changes - also writes to flash
///
//****************************************************************************
void CIOSetupConfig::UpdateAMS270SensorCommittedWithWorking( )
{
  // check to see if there is a difference between the two arrays before committing
  // and writing to flash as this could be costly timewise
  if( memcmp( &m_AMS2750SensorsCommitted, &m_AMS2750SensorsWorking, sizeof( T_AMS2750SENSORS ) ) != 0 )
  {
    memcpy( &m_AMS2750SensorsCommitted, &m_AMS2750SensorsWorking, sizeof( T_AMS2750SENSORS ) );

    // now write it to flash
    CFlashManager *pkFlashMgr = CFlashManager::GetHandle();
    pkFlashMgr->WriteBlock( FLASH_BLK_AMS2750_SENSORS, &m_AMS2750SensorsWorking, sizeof( T_AMS2750SENSORS ) );
  }
}
//****************************************************************************
//
/// Method that defaults the AMS2750 sensors block
///
//****************************************************************************
void CIOSetupConfig::DefaultAMS2750SensorInfo( T_PAMS2750SENSORS pSensors )
{
  // ensure everything is set to zero
  memset( pSensors, 0, sizeof( T_AMS2750SENSORS ) );

  // set to version 1
  pSensors->Version = 1;

  for( int iCount = 0; iCount < AMS2750SENSORS_SENSORS_SIZE ; iCount++ )
  {
    // default the times to the date today and 6am in the morning
    CTVtime kTodaysDate;
    kTodaysDate.TimeNow();
    SYSTEMTIME tSysTimeNow;
    kTodaysDate.GetSYSTEMTIME( &tSysTimeNow );
    tSysTimeNow.wHour = 6;
    tSysTimeNow.wMinute = 0;
    tSysTimeNow.wSecond = 0;
    tSysTimeNow.wMilliseconds = 0;
    kTodaysDate.SYSTEMTIMEtoInternal( tSysTimeNow );

    pSensors->Sensors[ iCount ].NextCalibDate = static_cast< ULONG >( kTodaysDate.GetSeconds() );
    pSensors->Sensors[ iCount ].DateRenewed = static_cast< ULONG >( kTodaysDate.GetSeconds() );
  }
}
//****************************************************************************
//
/// Method that gets the Multi Point Calibration block
///
/// @param[in]	REFERENCE cfgType - The desired sensor block type
///
/// @return A pointer to the relevant (committed/working) sensor block
///
//****************************************************************************
T_PMPCALCHANNELS CIOSetupConfig::GetMultiPointBlock(REFERENCE cfgType)
{
  return reinterpret_cast<T_PMPCALCHANNELS>(CConfiguration::GetBlock( BLK_MPCALCHANNELS, 0, m_ConfigurationId, cfgType ));
}
//*************************************************************************************
/// Create a TC multipoint cal block
///
/// @return Pointer to the TC multipoint cal block; otherwise NULL
///
//*************************************************************************************
T_PMPCALCHANNELS CIOSetupConfig::CreateTCMultipointCalBlock()
{
  T_PMPCALCHANNELS pMPChannelCal = NULL;

  // create a TC multipoint cal Block
  pMPChannelCal = reinterpret_cast<T_PMPCALCHANNELS>(CConfiguration::CreateNewBlock( BLK_MPCALCHANNELS, 0, m_ConfigurationId ));

  // now default the block
  if( pMPChannelCal != NULL )
  {
    DefaultMultiPointInfo( pMPChannelCal );
  }

  return pMPChannelCal;
}
//****************************************************************************
//
/// Method that updates the Multi Point configuration from NV into the CMM block
///
//****************************************************************************
void CIOSetupConfig::UpdateMultiPointCMMFromNV( T_PMPCALCHANNELS pMPChannelCalCMM )
{
  CFlashManager *pkFlashMgr = CFlashManager::GetHandle();
  T_MPCALCHANNELS multiPointNV;
  T_FLASH_STATUS eFlashStatus = pkFlashMgr->ReadBlock( FLASH_BLK_MULTI_POINT_CAL, &multiPointNV, sizeof( T_MPCALCHANNELS ) );

  // check the block has not been initialised or the size has changed
  if( (  multiPointNV.Version == 0 ) || ( eFlashStatus != FLASH_STATUS_OKAY ) )
  {
    // the data has not been intialised therefore default the information
    DefaultMultiPointInfo( &multiPointNV );

    // now save it back to NV
    CFlashManager *pkFlashMgr = CFlashManager::GetHandle();
    pkFlashMgr->WriteBlock( FLASH_BLK_MULTI_POINT_CAL, &multiPointNV, sizeof( T_MPCALCHANNELS ) );
  }

  // now update the CMM data with the NV version
  memcpy( pMPChannelCalCMM, &multiPointNV, sizeof( T_MPCALCHANNELS ) );
}
//****************************************************************************
//
/// Method that updates the Multi Point configuration from the CMM into NV
///
//****************************************************************************
void CIOSetupConfig::UpdateMultiPointNVFromCMM( T_PMPCALCHANNELS pMPChannelCalCMM )
{
  CFlashManager *pkFlashMgr = CFlashManager::GetHandle();
  pkFlashMgr->WriteBlock( FLASH_BLK_MULTI_POINT_CAL, pMPChannelCalCMM, sizeof( T_MPCALCHANNELS ) );
}
//****************************************************************************
//
/// Method that defaults the Multi Point Calibration block
///
//****************************************************************************
void CIOSetupConfig::DefaultMultiPointInfo( T_PMPCALCHANNELS pMPChannelCal )
{
  // ensure everything is set to zero
  memset( pMPChannelCal, 0, sizeof( T_MPCALCHANNELS ) );

  // Default the multi point calibrations to at least 2 points.
  for( int index = 0; index < MPCALCHANNELS_CHANNEL_SIZE; index++ )
  {
    pMPChannelCal->Channel[index].CalElements = 2;
    pMPChannelCal->Channel[index].CalPoints[0].CalPoint = 0;
    pMPChannelCal->Channel[index].CalPoints[0].Offset = 0;
    pMPChannelCal->Channel[index].CalPoints[1].CalPoint = 1;
    pMPChannelCal->Channel[index].CalPoints[1].Offset = 0;
  }

  // set to version 1
  pMPChannelCal->Version = 1;

}
//****************************************************************************
//
/// Method that resets any IO setup information that may be held in NV or somewhere
/// other than the setup file
///
//****************************************************************************
void CIOSetupConfig::ResetSetup()
{
  // Deafult and update AMS2750 sensors
  DefaultAMS2750SensorInfo( &m_AMS2750SensorsWorking );
  UpdateAMS270SensorCommittedWithWorking();

  // Default and Update Multi Point Cal.
  T_MPCALCHANNELS tMultiPointCalChans;
  DefaultMultiPointInfo( &tMultiPointCalChans );
  // default the NV structure - on a reboot this will cause the CMM copies to be overwritten
  UpdateMultiPointNVFromCMM( &tMultiPointCalChans );

  // Remove any cal files
  CAMS2750ProcessCalFile processCalFile;
  CStorage calFile;
  QString internalFilename = processCalFile.GetInternalCalFilename();

  if (calFile.FileExists( internalFilename ) )
  {
    // the cal file exists, delete it
    calFile.QFile::remove(internalFilename);
  }
}

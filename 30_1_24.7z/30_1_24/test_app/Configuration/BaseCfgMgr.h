/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	Configuration System
/// @n Filename:	BaseCfgMgr.cpp
/// @n Description: Definition for the CBaseCfgMgr class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log:
// 22	Stability Project 1.19.1.1	7/2/2011 4:55:36 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 21	Stability Project 1.19.1.0	7/1/2011 4:27:31 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 20	V6 Firmware 1.19		9/23/2008 3:09:20 PM	Build Machine 
//		AMS2750 Merge
// 19	V6 Firmware 1.18		12/20/2006 2:52:31 PM Roger Dawson 
//		Phase 3b merges into the main build. Removed unnecessary function.
// 18	V6 Firmware 1.17		4/5/2006 5:21:04 PM	Alistair Brugsch
//		added verifyadminuser Virtual function to allow a check to make sure
//		at least one admin user is in the system when passwords are first
//		enabled
// 17	V6 Firmware 1.16		3/17/2006 4:32:52 PM	Tony Maycock 
//		Numb Format was incorrectly enabled on Totals, even if the Totals
//		were disabled.
//		SetupNumasprintf changed in BaseCfgMgr to include a bool in the
//		declaration - this is defaulted true.
//		
//		RecSetupCfgMgr modified so on Totals this parameter is passed
//		dependent on the totals enabled state
// 16	V6 Firmware 1.15		3/16/2006 5:55:41 PM	Roger Dawson 
//		Added timeout variable
// 15	V6 Firmware 1.14		3/9/2006 9:25:12 PM	Graham Waterfield
//		Fix compile problems with test equipment build
// 14	V6 Firmware 1.13		1/20/2006 9:14:30 PM	Roger Dawson 
//		Added code to do reboots casued by the configuration, properly.
// 13	V6 Firmware 1.12		12/14/2005 6:09:42 PM Roger Dawson 
//		Removed the load/save all option.
// 12	V6 Firmware 1.11		12/8/2005 7:17:46 PM	Roger Dawson 
//		Commit/Discard password configuration changes.
// 11	V6 Firmware 1.10		12/8/2005 5:37:12 PM	Roger Dawson 
//		Help System changes. 
// 10	V6 Firmware 1.9		12/6/2005 3:25:27 PM	Roger Dawson 
//		Changes required for showing the channel map properites editor
//		directly from the statusbar.
// 9	V6 Firmware 1.8		10/24/2005 4:15:46 PM Tony Maycock 
//		static consts made public
// 8	V6 Firmware 1.7		9/1/2005 9:21:51 PM	Roger Dawson 
//		Added code to prevent the commit dialog from appearing when using the
//		screen designer data driven dialog.
// 7	V6 Firmware 1.6		8/11/2005 7:10:54 PM	Roger Dawson 
//		Made destructor virtual.
// 6	V6 Firmware 1.5		7/14/2005 8:38:38 PM	Roger Dawson 
//		Moved GetItemAtPos method to the CStringUtils class.
// 5	V6 Firmware 1.4		6/30/2005 2:00:30 PM	Roger Dawson 
//		Made ms_strEnabledList varaible public as it is required by the
//		CBoolData class. This is acceptable as this variable is a static
//		const and thus cannot be changed even though it is public.
// 4	V6 Firmware 1.3		6/21/2005 9:04:17 PM	Roger Dawson 
//		Added modified flag to indicate if the data has been changed.
// 3	V6 Firmware 1.2		6/21/2005 1:19:59 PM	Roger Dawson 
//		Added virtual method to the class following changes to the data
//		driven dialogs that allow them to update a configuration tree without
//		requiring knowledge of the particular configuration manager they are
//		using.
// 2	V6 Firmware 1.1		6/6/2005 9:23:00 PM	Roger Dawson 
//		Added variable for the maximum size of a 32-bit colour
// 1	V6 Firmware 1.0		5/31/2005 3:04:47 PM	Roger Dawson	
// $
//
// **************************************************************************
#pragma once
//#include "V6globals.h"
#include "V6Config.h"
#include "ModuleMsgManagerClient.h"
#include <vector>
class CConfigInterface;
class CConfigBranch;
class CConfigItem;
class CLayoutItem;
//**CBaseCfgMgr*********************************************************************
///
/// @brief Singleton class responsible for processing calls for a particular setup item and subsequently
///	creating the required configuration heirarchy
/// 
/// Singleton class responsible for processing calls for a particular setup item and subsequently
///	creating the required configuration heirarchy. Currently this class wil handle the creation of
/// setup heirarchies for the recorder setup, passowrds and screen layout.
///
//****************************************************************************
class CBaseCfgMgr {
public:
	/// Enumerated variables indicating the configuration manager type
	enum T_CONFIG_TYPE {
		ctSetup, ctLayout, ctPasswords,
	};
	CBaseCfgMgr(const T_CONFIG_TYPE eCONFIG_TYPE);
	virtual ~CBaseCfgMgr(void);
	// Virtual method that refreshes a configuration tree after it has been modifed
	// the layout item variable is only required by screen layout config managers, hence why it is
	// defaulted to NULL
	virtual CConfigInterface* RefreshConfigTree(CConfigItem *pkModifiedItem, CLayoutItem *pkCurrLayoutItem = NULL) = 0;
	// Accessor method for the modified flag
	void SetModified(const bool bMODIFIED) {
		m_bModified = bMODIFIED;
	}
	const bool GetModified() const {
		return m_bModified;
	}
	const bool IsLayout() const {
		return (ctLayout == m_eCONFIG_TYPE);
	}
	const T_CONFIG_TYPE GetConfigType() {
		return m_eCONFIG_TYPE;
	}
	// Method that commits changes to the CMM
	virtual void CommitChanges() = 0;
	// Method that discards changes made to the CMM modifiable data
	virtual void DiscardChanges() = 0;
	// Public Generic List Names
	static QString ms_strEnabledList;
	// Generic Key Names
	// Number Format
	static const QString ms_strNUM_FORMAT_KEY;
	static const QString ms_strNUM_FORMAT_SCI_KEY;
	static const QString ms_strNUM_FORMAT_AUTO_KEY;
	static const QString ms_strNUM_FORMAT_AD_KEY;
	// Style key names
	static const QString ms_strSTYLE_COLOUR_KEY;
	static const QString ms_strSTYLE_THICKNESS_KEY;
	// Max 32-bit colour size
	static const ULONG ms_ulMaxColour;
	// Adds a new message to the reboot reasons list
	void AddRebootMessage(const QString &rstrREBOOT_REASON) {
		m_kReasonsForReboot.push_back(rstrREBOOT_REASON);
	}
	// Method that returns true if configuration changes have been made which require a reboot
	const bool RebootRequired() {
		return (m_kReasonsForReboot.size() > 0);
	}
	// virtual base function for the password derrived class. checks that a valid admin user exists
	virtual BOOL VerifyAdminUser(BOOL bPure = FALSE) {
		return bPure;
	}
protected:
#ifndef DOCVIEW
	// Instance of a message manager client - this is required for committing or discarding 
	// data from the CMM
	CModuleMsgManagerClient m_ModuleMessageManagerClient;
#endif
	// Flag indicating if the currnet configuration has been modified and not yet committed
	bool m_bModified;
	// Generic Key Names
	// Generic List Item Names
	static QString ms_strNumasprintfSciList;
	static QString ms_strNumasprintfAutoList;
	/// Variable indicating the config manager type
	const T_CONFIG_TYPE m_eCONFIG_TYPE;
	// Method that loads all the title strings and listbox items into some static string 
	// objects. This is to decrease memory usage
	void LoadStrings();
	// Method that sets up the style details for a particular pen
	void SetupStyleDetails(CConfigBranch *pkParent, T_PLINESTYLE ptLineStyleData);
	// Method that sets up the number format for a particular item
	void SetupNumasprintf(CConfigBranch *pkParent, T_PNUMFORMAT ptNumasprintf, const bool bEnabled = true);
	// Method that finds the child that has the passed in key
	CConfigInterface* indexOfChildByKey(const QString &rstrKEY, CConfigBranch *pkParent,
			const USHORT usSTART_KEY_POS) const;
	/// List containing reasons for rebooting
	std::vector<QString> m_kReasonsForReboot;
	/// Const defining the standard timeout for tasks that are carried out by the control sequencer
	/// like config changes, loading configs
	const DWORD m_dwPOST_MESSAGE_WAIT_TIMEOUT;
};

/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	Configuration System
/// @n Filename:	ConfigBranch.h
/// @n Description: Definition for the CConfigBranch class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
// 8	Stability Project 1.5.1.1	7/2/2011 4:56:15 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 7	Stability Project 1.5.1.0	7/1/2011 4:28:14 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 6	V6 Firmware 1.5		10/24/2005 4:15:21 PM Tony Maycock 
//		GetChildByKey( const QString   & csKey) added to be able to a child item
//		by passing the relevant key
// 5	V6 Firmware 1.4		9/27/2005 8:21:32 PM	Roger Dawson 
//		Added the ability to setup new screens and edit them.
// $
//
// **************************************************************************
#pragma once
#include "ConfigInterface.h"
#include <vector>
#include <QString>
#include "Defines.h"
//**CConfigBranch*********************************************************************
///
/// @brief This is an inherited class that forms a branch in a configuration hierarchy.
/// 
/// This is an inherited class that forms a branch in a configuration hierarchy. It will
/// have at least one child item stemming from it. These children may be more branches or
/// leaves ( see CConfigItem class ). This class will be used by GUI's to create a menu
/// interface rather than an actual editor (although editing may be possible based on the
/// GUI implementation). Also refer to the CConfigInterface and CConfigItem classes for a
/// broader view of how these classes are designed to operate.
///
//****************************************************************************
class CConfigBranch: public CConfigInterface {
public:
	// Constructor
	CConfigBranch(const QString &rstrKEY, const QString &rstrTITLE, const QString &rstrSUB_TITLE,
			const ControlType eCONTROL_TYPE, const bool bMODIFIED, const bool bENABLED, const long lHELP_ID,
			const bool bLOCKED, CConfigInterface *const pkPARENT);
	~CConfigBranch(void);
	// Method that gets the first child and sets the current child variable to one
	CConfigInterface* GetFirstChild();
	// Method that gets the current child and increments the current child variable by one
	CConfigInterface* GetNextChild();
	// Method that gets the requested child using the passed in number
	CConfigInterface* GetChild(const USHORT usCHILD_NUM);
	// Method that gets the requested child using the passed in key
	CConfigInterface* GetChildByKey(const QString &csKey);
	// Method that adds a child to the list of child items
	void AddChild(CConfigInterface *pkChild);
	// Method that adds replace a child in the list of child items
	void ReplaceChild(CConfigInterface *pkNewChild);
	// Method that returns the number of children associated with this branch
	const long GetNumberOfChildren() const {
		return static_cast<long>(m_kChildren.size());
	}
	// Method that returns the position of this item within the child list
	const USHORT indexOfChildPos(const CConfigInterface *const pkCHILD);
	// Method that inserts a new child into this parents child list
	void InsertChild(CConfigInterface *pkNewChild, CConfigInterface *pkChildToInsertBefore);
private:
	/// Variable indicating the current child item when the user is using the GetFirstChild
	/// and GetNextChild method calls
	USHORT m_usCurrentChild;
	// List containing the children stemming from this branch
	std::vector<CConfigInterface*> m_kChildren;
};

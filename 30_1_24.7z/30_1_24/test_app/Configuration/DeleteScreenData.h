/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Configuration System
/// @n Filename:  DeleteScreenData.h
/// @n Description: Definition for the CDeleteScreenData class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  3 Stability Project 1.0.1.1 7/2/2011 4:56:42 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  2 Stability Project 1.0.1.0 7/1/2011 4:28:10 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  1 V6 Firmware 1.0 1/27/2006 8:56:46 PM  Roger Dawson  
// $
//
// **************************************************************************
#if !defined(AFX_DELETESCREENDATA_H_INCLUDED_)
#define AFX_DELETESCREENDATA_H_INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "ConfigData.h"
//**CDeleteScreenData*********************************************************************
///
/// @brief Class that deletes a screen from the screen list when selected by the user
/// 
/// Class that deletes a screen from the screen list when selected by the user
///
//****************************************************************************
class CDeleteScreenData: public CConfigData {
public:
	// Constructor
    CDeleteScreenData(const int iHELP_ID, const char* iDESC_ID);
	// Destructor
	virtual ~CDeleteScreenData();
	// Method that returns a pointer to the data
	void* GetData() const {
		return NULL;
	}
	// Method that returns the data as a string
	const QString GetDataAsString(const bool bINCLUDE_UNITS = false);
	// Method that updates the data e.g. a new screen is added to the layout 
	const bool UpdateData();
private:
};
#endif // !defined(AFX_DELETESCREENDATA_H_INCLUDED_)

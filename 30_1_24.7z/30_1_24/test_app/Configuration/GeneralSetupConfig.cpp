/// @file
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Configuration
/// @n Filename: GeneralSetupConfig.cpp
/// @n Desc:	 Handles all general setup configuration services
///				 
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  78  Stability Project 1.73.1.3 7/2/2011 4:57:25 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  77  Stability Project 1.73.1.2 7/1/2011 4:38:18 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  76  Stability Project 1.73.1.1 3/17/2011 3:20:25 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  75  Stability Project 1.73.1.0 2/15/2011 3:03:06 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// ****************************************************************
#include "../inc/V6defines.h"
#include "../inc/V6globals.h"
#include "V6Config.h"
#include "../inc/Registry.h"
#include "GeneralSetupConfig.h"
#include "RecSetupCfgMgr.h"
#include "../DAL_OP/Opl.h"
#include "../DAL_OP/PPL.h"
#include "../inc/V6ResourceBase.h"
#include "../inc/V6UIResource.h"
#include "../Utilities/V6AppInterface.h"
#include "../inc/Registry.h"
#include "../inc/BoardChannelCommonDefines.h"
#include "../Logging/LogDeviceStatus.h"
#include "../Utilities/StringUtils.h"
#include "../UIControl/BatchManager.h"
#include "../inc/hw_defs.h"
#include "../MessageList/MessageListServicesItem.h"
#include "../inc/StringDefinitions.h"
#include "../Defines.h"
#include "../Persist/NVVariables.h"
#include "../Configuration/Configuration.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
#define REG_DWORD                   ( 4 )
T_REG_TABLE_ENTRY GeneralTable[] = { { "Ident", "Name", VALUE_STRING, ITEM_IDENT_NAME, FALSE }, { "Ident", "Desc",
		VALUE_STRING, ITEM_IDENT_DESC, FALSE },
{ NULL, NULL, VALUE_DWORD, NUM_REG_ITEMS, FALSE }	// End of table
};
CGeneralSetupConfig::CGeneralSetupConfig(void) {
	m_GeneralSetupModified = FALSE;
	for (int iCount = 0; iCount < FURNACESCONFIG_FURNACES_SIZE; iCount++) {
		m_baFurnaceChangeMade[iCount] = false;
	}
	m_bSetpointChanged = false;
}
CGeneralSetupConfig::~CGeneralSetupConfig(void) {
}
//*************************************************************************************
/// A default configuration is required for service, so create default blocks
/// and perform and specific defaulting required
///
/// @return T_CONFIG_RETURN_VALUE indicating status of call
/// 
//*************************************************************************************
T_CONFIG_RETURN_VALUE CGeneralSetupConfig::CreateServiceDefaultConfig(void) {
	T_CONFIG_RETURN_VALUE retValue = CONFIG_OK;
	CRegistryKey RegKey;
	// Create system general block
	if (CreateSystemGeneralBlock() == NULL) {
		retValue = CONFIG_ERROR;
	}
	// Create device capabilities block
	if (CreateDevCapsBlock() == NULL) {
		retValue = CONFIG_ERROR;
	}
	// Create General non volatile block
	if (CreateGenNonVolBlock() == NULL) {
		retValue = CONFIG_ERROR;
	}
	// Create profile block
	if (CreateProfileBlock() == NULL) {
		retValue = CONFIG_ERROR;
	}
	// Create change header
	if (CreateChangeHeaderBlock() == NULL) {
		retValue = CONFIG_ERROR;
	}
	// create the AMS2750 furnace information
	if (CreateAMS2750FurnaceInfoBlock() == NULL) {
		retValue = CONFIG_ERROR;
	}
	// create the AMS2750 calibration information
	if (CreateAMS2750CalibrationBlock() == NULL) {
		retValue = CONFIG_ERROR;
	}
	return (retValue);
}
//*************************************************************************************
/// Validate the configuration items when a config has been loaded and is about to be commited
///
///
/// @return T_CONFIG_RETURN_VALUE indicating status of call
/// 
//*************************************************************************************
T_CONFIG_VALIDATE_RETURN CGeneralSetupConfig::ValidateServiceConfig() {
	T_CONFIG_VALIDATE_RETURN retValue = CONFIG_VALIDATE_NO_CHANGES;
	T_PCHANGEHEADER pChangeHeader = GetChangeHeaderBlock(CONFIG_MODIFIABLE);
	if (pChangeHeader == NULL) {
		pChangeHeader = CreateChangeHeaderBlock();
		retValue = CONFIG_VALIDATE_CHANGES_MADE;
		// Create the change header, this will be completed by the pre-commit processing
	}
	// Validate the System general block
	T_PGENERALCONFIG pGeneral = GetSystemGeneralBlock(CONFIG_MODIFIABLE);
	// Check if block exists, if not create, otherwise check for any compatablility issues
	if (pGeneral == NULL) {
		// Block does not exist so create
		pGeneral = CreateSystemGeneralBlock();
		if (pGeneral == NULL) {
			///@todo create a system error
		}
		retValue = CONFIG_VALIDATE_CHANGES_MADE;
	}
	// Validate the profile block
	T_PRECPROFILE pProfile = GetProfileBlock(CONFIG_MODIFIABLE);
	// Check if block exists, if not create, otherwise check for any compatablility issues	
	if (pProfile == NULL) {
		// Block does not exist so create
		pProfile = CreateProfileBlock();
		if (pProfile == NULL) {
			///@todo create a system error
		}
		retValue = CONFIG_VALIDATE_CHANGES_MADE;
	}
	// Validate the Device capabilities block
	T_PDEVICECAPS pDevCaps = GetDeviceCapsBlock(CONFIG_MODIFIABLE);
	// Check if block exists, if not create, otherwise check for any compatablility issues	
	if (pDevCaps == NULL) {
		// Block does not exist so create
		pDevCaps = CreateDevCapsBlock();
		if (pDevCaps == NULL) {
			///@todo create a system error
		}
		retValue = CONFIG_VALIDATE_CHANGES_MADE;
	}
	// Validate the General Non Vol block
	T_PGENNONVOL pGenNV = GetGenNonVolBlock(CONFIG_MODIFIABLE);
	// Check if block exists, if not create, otherwise check for any compatablility issues	
	if (pGenNV == NULL) {
		// Block does not exist so create
		pGenNV = CreateGenNonVolBlock();
		if (pGenNV == NULL) {
			///@todo create a system error
		}
		retValue = CONFIG_VALIDATE_CHANGES_MADE;
	} else {
		// Check to make sure the serial number is not invalid, if it is then reset to default
		if (pGenNV->SerialNumber < 100000 || pGenNV->SerialNumber > 999999) {
			pGenNV->SerialNumber = DEFAULT_SERIAL_NUMBER;
			retValue = CONFIG_VALIDATE_CHANGES_MADE;
		}
	}
	// check the custom screens option is not selected already on an EZTrend
	T_PGENNONVOL ptGenNonVol = pSYSTEM_INFO->GetFactoryConfig();
	const T_DEV_TYPE eDEV_TYPE = pDALGLB->GetDeviceType();
	if (((ptGenNonVol->FWOptions.CustomScreens == TRUE) || (ptGenNonVol->FWOptions.FastScan == TRUE)
			|| (ptGenNonVol->FWOptions.MathsType == MATH_OPTION_FULL_SCRIPT)) &&
	pDALGLB->IsRecorderEzTrend()) {
		// set back to false
		ptGenNonVol->FWOptions.CustomScreens = FALSE;
		ptGenNonVol->FWOptions.FastScan = FALSE;
		if (ptGenNonVol->FWOptions.MathsType == MATH_OPTION_FULL_SCRIPT) {
			ptGenNonVol->FWOptions.MathsType = MATH_OPTION_FULL_BLOCK;
		}
        LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_WARNING, "Defaulted incorrectly set QXe firmware options");
		retValue = CONFIG_VALIDATE_CHANGES_MADE;
	}
	// For the V6 Setup DLL we need to copy the Gen NV block out of the setup loaded and into the memory based copy (from flash on recorder build)
	// also copy the DevCaps structure from thge CMM into the global memory version. 
	if (eDEV_TYPE == DEV_PC_TTR6SETUP || eDEV_TYPE == DEV_PC_SCREEN_DESIGNER) {
		// Update System GenNV and DevCaps for CMM
		if (eDEV_TYPE == DEV_PC_SCREEN_DESIGNER) {
			// if this is a manually loaded setup then we may need to turn on the demo channels in order
			// to emulate the boards being fitted - if the fitted board is actually an AO board then we
			// must disable the demo channel as this would not actaully provide us with any additional pens
			for (USHORT usCount = 0; usCount < BRDCHANDEF_MULTIPLUS_MAX_AI_CARDS; usCount++) {
				if ((pDevCaps->Slot[usCount].Type == BOARD_AI) || (pDevCaps->Slot[usCount].Type == BOARD_PI)) {
					// the inserted board would provide us with additional pens so setup a demo card
					pGenNV->IsDemoBoard[usCount] = 1;
				} else if (pDevCaps->Slot[usCount].Type == BOARD_AO) {
					// the inserted board would NOT provide us with additional pens so DON'T setup a demo card
					pGenNV->IsDemoBoard[usCount] = 0;
				}
			}
			// disable the TUS process screen option if enabled
			pGenNV->FWOptions.AMS2750TUS = FALSE;
			// set the AMS2750 mode based on the firmware options
			if (pGenNV->FWOptions.AMS2750Process == TRUE) {
				pSYSTEM_INFO->SetAMS2750Mode(AMS2750_PROCESS);
			} else {
				pSYSTEM_INFO->SetAMS2750Mode(AMS2750_NONE);
			}
		}
		UpdateGenNonVolSystemFromCMM(pGenNV);
		UpdateDevcapsSystemFromCMM(pDevCaps);
		if (eDEV_TYPE == DEV_PC_SCREEN_DESIGNER) {
			pDEVICE_INFO->m_pdc->DevType = DEV_PC_SCREEN_DESIGNER;
		}
		// Run Pen setup information again to size number of pens available correctly based on devcaps from CMM
		pSYSTEM_INFO->ConfigurePens();
	}
// Moved to V6AppInterface so the product info is only built when requested by the configuration tool.
//	else
//		pSYSTEM_INFO->BuildProductionInfo( );
	// make sure the batch names have been defaulted and are not simply set to NONE
	QString strFieldName("");
    strFieldName = QString::fromWCharArray(pGeneral->Batch.FieldNames[bflNAME]);
    if (strFieldName == "NONE") {
        strFieldName = QWidget::tr("Name");
#if _MSC_VER < 1400 
        wcsncpy(pGeneral->Batch.FieldNames[bflNAME], strFieldName.toStdWString().c_str(), BATCH_FIELDNAMES_LEN);
#else
		wcsncpy_s( pGeneral->Batch.FieldNames[ bflNAME ], sizeof(pGeneral->Batch.FieldNames[ bflNAME ])/sizeof(WCHAR), strFieldName.GetBuffer( 0 ), _TRUNCATE );
#endif
		retValue = CONFIG_VALIDATE_CHANGES_MADE;
	}
    strFieldName = QString::fromWCharArray(pGeneral->Batch.FieldNames[bflUSER_ID]);
    if (strFieldName == "NONE") {
        strFieldName = QWidget::tr("User ID");
#if _MSC_VER < 1400 
        wcsncpy(pGeneral->Batch.FieldNames[bflUSER_ID], strFieldName.toStdWString().c_str(), BATCH_FIELDNAMES_LEN);
#else
		wcsncpy_s( pGeneral->Batch.FieldNames[ bflUSER_ID ], sizeof(pGeneral->Batch.FieldNames[ bflUSER_ID ])/sizeof(WCHAR), strFieldName.GetBuffer( 0 ), _TRUNCATE );
#endif
		retValue = CONFIG_VALIDATE_CHANGES_MADE;
	}
    strFieldName = QString::fromWCharArray(pGeneral->Batch.FieldNames[bflDESCRIPTION]);
    if (strFieldName == "NONE") {
        strFieldName = QWidget::tr("Desc.");
#if _MSC_VER < 1400 
        wcsncpy(pGeneral->Batch.FieldNames[bflDESCRIPTION], strFieldName.toStdWString().c_str(), BATCH_FIELDNAMES_LEN);
#else
		wcsncpy_s( pGeneral->Batch.FieldNames[ bflDESCRIPTION ], sizeof(pGeneral->Batch.FieldNames[ bflDESCRIPTION ])/sizeof(WCHAR), strFieldName.GetBuffer( 0 ), _TRUNCATE );
#endif
		retValue = CONFIG_VALIDATE_CHANGES_MADE;
	}
    strFieldName = QString::fromWCharArray(pGeneral->Batch.FieldNames[bflLOT_NO]);
    if (strFieldName == "NONE") {
        strFieldName = QWidget::tr("Lot No.");
#if _MSC_VER < 1400 
        wcsncpy(pGeneral->Batch.FieldNames[bflLOT_NO], strFieldName.toStdWString().c_str(), BATCH_FIELDNAMES_LEN);
#else
		wcsncpy_s( pGeneral->Batch.FieldNames[ bflLOT_NO ], sizeof(pGeneral->Batch.FieldNames[ bflLOT_NO ])/sizeof(WCHAR), strFieldName.GetBuffer( 0 ), _TRUNCATE );
#endif
		retValue = CONFIG_VALIDATE_CHANGES_MADE;
	}
    strFieldName = QString::fromWCharArray(pGeneral->Batch.FieldNames[bflCOMMENT]);
    if (strFieldName == "NONE") {
        strFieldName = QWidget::tr("Comment");
#if _MSC_VER < 1400 
        wcsncpy(pGeneral->Batch.FieldNames[bflDESCRIPTION], strFieldName.toStdWString().c_str(), BATCH_FIELDNAMES_LEN);
#else
		wcsncpy_s( pGeneral->Batch.FieldNames[ bflCOMMENT ], sizeof(pGeneral->Batch.FieldNames[ bflCOMMENT ])/sizeof(WCHAR), strFieldName.GetBuffer( 0 ), _TRUNCATE );
#endif
		retValue = CONFIG_VALIDATE_CHANGES_MADE;
	}
	USHORT usListCount = 0;
	for (usListCount = 0; usListCount < BATCH_BATCHNAMES_SIZE; usListCount++) {
        strFieldName = QString::fromWCharArray(pGeneral->Batch.BatchNames[usListCount]);
        if (strFieldName == "NONE") {
			// set the first character to a NULL one thus making the string blank
			pGeneral->Batch.BatchNames[usListCount][0] = 0x0000;
		}
	}
	for (usListCount = 0; usListCount < BATCH_USERNAMES_SIZE; usListCount++) {
        strFieldName = QString::fromWCharArray(pGeneral->Batch.UserNames[usListCount]);
        if (strFieldName == "NONE") {
			// set the first character to a NULL one thus making the string blank
			pGeneral->Batch.UserNames[usListCount][0] = 0x0000;
		}
	}
	for (usListCount = 0; usListCount < BATCH_LOTNONAMES_SIZE; usListCount++) {
        strFieldName = QString::fromWCharArray(pGeneral->Batch.LotNoNames[usListCount]);
        if (strFieldName == "NONE") {
			// set the first character to a NULL one thus making the string blank
			pGeneral->Batch.LotNoNames[usListCount][0] = 0x0000;
		}
	}
	for (usListCount = 0; usListCount < BATCH_DESCNAMES_SIZE; usListCount++) {
        strFieldName = QString::fromWCharArray(pGeneral->Batch.DescNames[usListCount]);
        if (strFieldName == "NONE") {
			// set the first character to a NULL one thus making the string blank
			pGeneral->Batch.DescNames[usListCount][0] = 0x0000;
		}
	}
	for (usListCount = 0; usListCount < BATCH_COMMENTNAMES_SIZE; usListCount++) {
        strFieldName = QString::fromWCharArray(pGeneral->Batch.CommentNames[usListCount]);
        if (strFieldName == "NONE") {
			// set the first character to a NULL one thus making the string blank
			pGeneral->Batch.CommentNames[usListCount][0] = 0x0000;
		}
	}
	for (USHORT usGroupCount = 0; usGroupCount < BATCH_GROUPINFO_SIZE; usGroupCount++) {
        strFieldName = QString::fromWCharArray(pGeneral->Batch.GroupInfo[usGroupCount].AutoBatchName);
        if (strFieldName == "NONE") {
			// create a dummy batch name
            strFieldName = QString::asprintf("BATCH-%u-[[GC.v]]", usGroupCount + 1);
            CStringUtils::SafeWcsCpy(pGeneral->Batch.GroupInfo[usGroupCount].AutoBatchName, strFieldName.toStdWString().c_str(),
			GROUPINFO_AUTOBATCHNAME_LEN);
		}
	}
	// Validate the AMS2750 furnaces block
	T_PFURNACESCONFIG pAMS2750 = GetAMS2750FurnaceInfoBlock(CONFIG_MODIFIABLE);
	// Check if block exists, if not create it
	if (pAMS2750 == NULL) {
		// Block does not exist so create
		pAMS2750 = CreateAMS2750FurnaceInfoBlock();
		if (pAMS2750 == NULL) {
			retValue = CONFIG_VALIDATE_INVALID;
		} else {
			retValue = CONFIG_VALIDATE_CHANGES_MADE;
		}
	} else {
		// ensure no setpoints are enabled if this is not an SX recorder or TUS mode is not enabled
		if (!pDEVICE_INFO->IsRecorderMulti() || !pSYSTEM_INFO->FWOptionTUSModeAvailable()) {
			for (int iSetpointCount = 0; iSetpointCount < FURNACESCONFIG_SETPOINTS_SIZE; iSetpointCount++) {
				if (pAMS2750->Setpoints[iSetpointCount].Enabled == TRUE) {
					// the setpoint is incorreclty enabled - disable and flag the config
					// has changed
					pAMS2750->Setpoints[iSetpointCount].Enabled = FALSE;
					retValue = CONFIG_VALIDATE_CHANGES_MADE;
				}
			}
		}
	}
	// Validate the AMS2750 calibration block
	T_PAMS2750CALCFG pAMS2750Cal = GetAMS2750CalibrationBlock(CONFIG_MODIFIABLE);
	// Check if block exists, if not create it
	if (pAMS2750Cal == NULL) {
		// Block does not exist so create
		pAMS2750Cal = CreateAMS2750CalibrationBlock();
		if (pAMS2750Cal == NULL) {
			retValue = CONFIG_VALIDATE_INVALID;
		} else {
			retValue = CONFIG_VALIDATE_CHANGES_MADE;
		}
	}
	return (retValue);
}
//**********************************************************************
///
/// Function that is called immediately before a setup config is commited
/// to the CMM.
///
/// @return		T_CONFIG_RETURN_VALUE return value
/// 
//**********************************************************************
T_CONFIG_RETURN_VALUE CGeneralSetupConfig::PreCommitProcessing(void) {
	// Update the change header
	T_PCHANGEHEADER pChangeHeader = GetChangeHeaderBlock(CONFIG_MODIFIABLE);
	// Update the change header ONLY if not in depersist mode OR if in depersist mode something changes
	if (( pSETUP->InDepersistMode() == FALSE)
			|| (( pSETUP->InDepersistMode() == TRUE) && (pSETUP->DepersistChangesMadeInConfig() == TRUE))) {
		if (pChangeHeader != NULL) {
			pChangeHeader->SessionNumber = pSYSTEM_INFO->GetNextSessionNumber();
			pChangeHeader->ConfigVersion = CF_VERSION;
			// pChangeHeader->CommitedBy @todo AK, when passwords available add logged in user here
            CTVtime theTime;
			theTime.TimeNow();
			pChangeHeader->CommitDate = theTime.GetMicroSecs();
		}
	}
	// Update devcaps in Configuration
	T_PDEVICECAPS pDevCaps = GetDeviceCapsBlock(CONFIG_MODIFIABLE);
	if (pDevCaps != NULL) {
		// Dev Caps block exists in config, update it with latest in memory
		UpdateDevcapsCMMFromSystem(pDevCaps);
	}
	// Update General Non Volatile block in configuration
	T_PGENNONVOL pGenNV = GetGenNonVolBlock(CONFIG_MODIFIABLE);
	if (pGenNV != NULL) {
		DWORD dwRequiredLCID = 0;
		// get the required LCID
		dwRequiredLCID = GetLCID(static_cast<T_LANGUAGES>( pSYSTEM_INFO->GetFactoryConfig()->Language));
		CRegistryKey kRegKey;
        if (kRegKey.OpenKey("nls\\overrides")) {
			bool bLangUpdateRequired = false;
			// determine the current LCID
			DWORD dwCurrentLCID = 0;
			DWORD dwType = REG_DWORD;
			DWORD dwSize = sizeof(DWORD);
            //if (kRegKey.ReadValue(L"LCID", &dwType, reinterpret_cast<BYTE*>(&dwCurrentLCID), &dwSize)) {
				// compare to the existing
				if (dwCurrentLCID != dwRequiredLCID) {
					// different therefore an update is required
					bLangUpdateRequired = true;
				}
            //} else
                {
				bLangUpdateRequired = true;
			}
			// check if the language is about to change in which case we need to setup the correct localisation
			if (bLangUpdateRequired) {
                //kRegKey.WriteValue(L"LCID", dwRequiredLCID);
				// make sure the recorder is going to reset to force the changes
                //if (!pSETUP->IsResetRequired()) {
                    //pSETUP->RequestUnitResetAfterConfigChange(L"RESET REQUIRED: Language Registry Info Changed (LCID)");
                //}
			}
			kRegKey.Close();
		}
		// Gen NV block exists in config, update it with latest in memory
		UpdateGenNonVolCMMFromSystem(pGenNV);
	}
	// check if the logging info structure needs to be updated with the old logging information
	// stored in NV
	T_PRECPROFILE ptProfile = GetProfileBlock(CONFIG_MODIFIABLE);
#ifndef TTR6SETUP
	if (ptProfile->Logging.UpdatedFromNV == FALSE) {
		// firstly check if we are supposed to be logging - this used to be indicated by the logging interval
		// enum being set to 0
		CNVBasicVar *pNVvariable = pNV_VARS->GetBasicVarNVObject(static_cast<NVVAR_IDENT>(NVV_EXPORT_INTERVAL));
		if (pNVvariable->GetFromNV()->value.us[0] > 0) {
			ptProfile->Logging.DoSchedExport = TRUE;
			// setup the time interval here too - minus one from the actual value as we are no longer using
			// 0 as an indicator for 'not logging'. Instead we now have the flag above
			ptProfile->Logging.SchedExportTime = pNVvariable->GetFromNV()->value.us[0] - 1;
		} else {
			ptProfile->Logging.DoSchedExport = FALSE;
			// leave the time interval at its default value
		}
		// now setup the logging device
		pNVvariable = pNV_VARS->GetBasicVarNVObject(static_cast<NVVAR_IDENT>(NVV_EXPORT_DEVICE));
		// minus one because FTP used to be the first log device selection - now moved though
		ptProfile->Logging.SchedExportDev = pNVvariable->GetFromNV()->value.us[0] - 1;
		// set the unused flag so this action doesn't get carried out in the future
		ptProfile->Logging.UpdatedFromNV = TRUE;
	}
#endif
	// default to USB1 if this is an EZTrend and the front SD is selected
	if (GlbDevCaps.IsRecorderEzTrend() && !pGlbSysInfo->FWOptionExtSDAvailable()
			&& (static_cast<T_LOG_DEVICE>(ptProfile->Logging.SchedExportDev) == LOGDEV_EXT_SD)) {
		ptProfile->Logging.SchedExportDev = static_cast<T_LOG_DEVICE>(LOGDEV_USB1);
	}
	// default the preset marker text to blank if there 'NONE' is defined
	WCHAR wcaTest[5] = L"NONE";
	T_PGENERALCONFIG ptGenCfg = GetSystemGeneralBlock(CONFIG_MODIFIABLE);
	for (USHORT usCount = 0; usCount < GENERALCONFIG_PRESETMARKERS_SIZE; usCount++) {
		// marker 
		if (wcsncmp(ptGenCfg->PresetMarkers[usCount], wcaTest, wcslen(wcaTest)) == 0) {
			// set to blank
			ptGenCfg->PresetMarkers[usCount][0] = L'\0';
		}
	}
	// compare the furnace information to see if any of it has changed - this will require the canned screens
	// to be rebuilt as the AMS2750 process screen shows some furnace information
	T_PFURNACESCONFIG ptCommittedFurnaceCfg = GetAMS2750FurnaceInfoBlock(CONFIG_COMMITTED);
	T_PFURNACESCONFIG ptModifiableFurnaceCfg = GetAMS2750FurnaceInfoBlock(CONFIG_MODIFIABLE);
	if ((ptCommittedFurnaceCfg != NULL) && (ptModifiableFurnaceCfg != NULL)) {
		for (int iCount = 0; iCount < FURNACESCONFIG_FURNACES_SIZE; iCount++) {
			if (memcmp(&(ptCommittedFurnaceCfg->Furnaces[iCount]), &(ptModifiableFurnaceCfg->Furnaces[iCount]),
					sizeof(T_FURNACE)) != 0) {
				m_baFurnaceChangeMade[iCount] = true;
			} else {
				m_baFurnaceChangeMade[iCount] = false;
			}
		}
		// now check the setpoint information which is required for TUS's
		m_bSetpointChanged = false;
		for (int iSPCount = 0; iSPCount < FURNACESCONFIG_SETPOINTS_SIZE; iSPCount++) {
			if (memcmp(&(ptCommittedFurnaceCfg->Setpoints[iSPCount]), &(ptModifiableFurnaceCfg->Setpoints[iSPCount]),
					sizeof(T_SETPOINT)) != 0) {
				// the setpoint has changed - do not continue any further
				m_bSetpointChanged = true;
				break;
			}
		}
	}
	return CONFIG_OK;
}
//**********************************************************************
//	const DWORD GetLCID( const T_LANGUAGES eLANGUAGE ) const
///
/// Function that returns the LCID code for the specified language
///
/// @return		T_CONFIG_RETURN_VALUE return value
/// 
//**********************************************************************
const DWORD CGeneralSetupConfig::GetLCID(const T_LANGUAGES eLANGUAGE) const {
	// see c:\wince5\public\common\sdk\inc\lid.h on the platform builder machine to get hold of the relevant
	// codes for a particular language
	DWORD dwLCID = 0;
	switch (eLANGUAGE) {
	case lngEnglish:
		dwLCID = 0x0809;
		break;
	case lngFra:
		dwLCID = 0x040C;
		break;
	case lngGer:
		dwLCID = 0x0407;
		break;
	case lngIta:
		dwLCID = 0x0410;
		break;
	case lngSpa:
		dwLCID = 0x040A;
		break;
	case lngBraz:
		dwLCID = 0x0416;
		break;
	case lngPol:
		dwLCID = 0x0415;
		break;
	case lngHung:
		dwLCID = 0x040E;
		break;
	case lngSlo:
		dwLCID = 0x041B;
		break;
	case lngCze:
		dwLCID = 0x0405;
		break;
	case lngTurk:
		dwLCID = 0x041F;
		break;
	case lngRom:
		dwLCID = 0x0418;
		break;
	case lngRus:
		dwLCID = 0x0419;
		break;
	case lngPor:
		dwLCID = 0x0816;
		break;
	case lngGrk:
		dwLCID = 0x0408;
		break;
	case lngBulg:
		dwLCID = 0x0402;
		break;
		//#if LangChinese == 1
	case lngChin:
		dwLCID = 0x0C04;
		break;
		//#endif
		//#if LangJapanese == 1
	case lngJap:
		dwLCID = 0x0411;
		break;
		//#endif
		//#if LangKorean == 1
	case lngKor:
		dwLCID = 0x0412;
		break;
		//#endif
	case lngEngUS:
		dwLCID = 0x0409;
	default:
		// default to english us
		break;
	}
	return dwLCID;
}
//**********************************************************************
///
/// Function that is called immediately after a setup config is commited
/// to the CMM.
///
/// @return		T_CONFIG_RETURN_VALUE return value
/// 
//**********************************************************************
T_CONFIG_RETURN_VALUE CGeneralSetupConfig::PostCommitProcessing(void) {
	CRegistryKey RegKey;
#ifdef STARTUP_LOGGING
	WCHAR InitLogFileName[ 256 ];
	WCHAR InitLogString[512];
	int iPathLen = 256;
	BOOLEAN isFileCreated = FALSE;
	CStorage kLogFile;
	QFileDevice::FileError kFileEx;
	pDALGLB->GetPath(	static_cast< T_STORAGE_PATH >( IDS_INTERNAL_SD ), 
						InitLogFileName,
						256,
						&iPathLen );
	wcsncat( InitLogFileName, 256, L"PostCommit_General.txt", (256 - wcslen( InitLogFileName )) );
	if( kLogFile.Open(	InitLogFileName, 
						CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
						&kFileEx ) )
	{
		kLogFile.SeekToEnd();
		wcscpy(InitLogString,L"--------Initialisation started-------\n");
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		wcscpy(InitLogString,L"--------RegistryUpdate-------\n");
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	// Update registry with any changes made in an edit session, may require a reset
	if ( TRUE == RegKey.Update(GeneralTable)) {
		QString resetReason;
        resetReason = QWidget::tr("Restart required, General info updated");
		pSETUP->RequestUnitResetAfterConfigChange(resetReason);
	}
#ifdef STARTUP_LOGGING
	if( kLogFile.Open(	InitLogFileName, 
						CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
						&kFileEx ) )
	{
		kLogFile.SeekToEnd();
		wcscpy(InitLogString,L"GetProfileBlock()\n");
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	T_PRECPROFILE pProfile = GetProfileBlock(CONFIG_COMMITTED);
	pSYSTEM_INFO->SetProfileConfig(pProfile);		// Set the profile configuration to new current
#ifdef STARTUP_LOGGING
	if( kLogFile.Open(	InitLogFileName, 
						CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
						&kFileEx ) )
	{
		kLogFile.SeekToEnd();
		wcscpy(InitLogString,L"GetSystemGeneralBlock()\n");
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	T_PGENERALCONFIG pGeneral = GetSystemGeneralBlock(CONFIG_COMMITTED);
	pSYSTEM_INFO->SetGeneralConfig(pGeneral);
#ifdef STARTUP_LOGGING
	if( kLogFile.Open( InitLogFileName,
					CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
					&kFileEx ) )
	{
		kLogFile.SeekToEnd();
		wcscpy(InitLogString,L"SetScreenBrightness()\n");
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	// Set the screen brightness from the commited profile
	pDALGLB->SetScreenBrightness(pProfile->ScreenSaver.NormalBright);
#ifdef STARTUP_LOGGING
	if( kLogFile.Open(	InitLogFileName, 
						CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
						&kFileEx ) )
	{
		kLogFile.SeekToEnd();
		wcscpy(InitLogString,L"WasBlockModified()\n");
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	// Save general non vol block into flash if anything has changed OR always for Screen designer	
	if (( pDALGLB->GetDeviceType() == DEV_PC_SCREEN_DESIGNER)
			|| (CConfiguration::WasBlockModified(BLK_GENNONVOL, 0, m_ConfigurationId) == TRUE)) {
#ifdef STARTUP_LOGGING
		if( kLogFile.Open(	InitLogFileName, 
							CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
							&kFileEx ) )
		{
			kLogFile.SeekToEnd();
			wcscpy(InitLogString,L"NVSaveToFlash()\n");
			kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
			kLogFile.Close();
		}
#endif
		pSYSTEM_INFO->NVSaveToFlash();
	}
#ifdef STARTUP_LOGGING
	if( kLogFile.Open(	InitLogFileName, 
						CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
						&kFileEx ) )
	{
		kLogFile.SeekToEnd();
		wcscpy(InitLogString,L"WasBlockModified(BLK_GENERALCONFIG)\n");
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	m_GeneralSetupModified = CConfiguration::WasBlockModified(BLK_GENERALCONFIG, 0, m_ConfigurationId);
	// Check if general block was modified, if so we need to register this change with OPC A&E server 
	if (m_GeneralSetupModified == TRUE) {
#ifdef STARTUP_LOGGING	
		if( kLogFile.Open(	InitLogFileName, 
							CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
							&kFileEx ) )
		{
			kLogFile.SeekToEnd();
			wcscpy(InitLogString,L"UpdateOPCConfig()\n");
			kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
			kLogFile.Close();
		}
#endif
		UpdateOPCConfig();
	}
#ifdef STARTUP_LOGGING
	if( kLogFile.Open(	InitLogFileName, 
						CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
						&kFileEx ) )
	{
		kLogFile.SeekToEnd();
		wcscpy(InitLogString,L"UpdateTimeInformation()\n");
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	// apply any changes that may require external data to be updated e.g. time zones and daylight saving
	UpdateTimeInformation();
#ifdef STARTUP_LOGGING
	if( kLogFile.Open(	InitLogFileName, 
						CStorage::modeCreate | CStorage::ReadOnlyWrite | CStorage::Append,
						&kFileEx ) )
	{
		kLogFile.SeekToEnd();
		wcscpy(InitLogString,L"--------END-------\n");
		kLogFile.Write( InitLogString, (wcslen(InitLogString) * 2) );
		kLogFile.Close();
	}
#endif
	return CONFIG_OK;
}
//*************************************************************************************
/// Get the current system general configuration from the CMM.
///
/// @param[in] cfgType - The type of configuration to access.
///
/// @return Pointer to the system general block; otherwise NULL
/// 
//*************************************************************************************
T_PGENERALCONFIG CGeneralSetupConfig::GetSystemGeneralBlock(REFERENCE cfgType) {
	return reinterpret_cast<T_PGENERALCONFIG>(CConfiguration::GetBlock(BLK_GENERALCONFIG, 0, m_ConfigurationId, cfgType));
}
//*************************************************************************************
/// Create a default general block
///
/// @return Pointer to the system general block; otherwise NULL
/// 
//*************************************************************************************
T_PGENERALCONFIG CGeneralSetupConfig::CreateSystemGeneralBlock() {
	T_PGENERALCONFIG pGeneral = NULL;
	// get general Block
	pGeneral = reinterpret_cast<T_PGENERALCONFIG>(CConfiguration::CreateNewBlock(BLK_GENERALCONFIG, 0,
			m_ConfigurationId));
	DefaultSystemGeneralBlock(pGeneral);
	return pGeneral;
}
//*************************************************************************************
/// default a system general block
///
/// @return Pointer to the system general block; otherwise NULL
/// 
//*************************************************************************************
void CGeneralSetupConfig::DefaultSystemGeneralBlock(T_PGENERALCONFIG pGeneral) {
	// If General block created okay the perform specific initialisations
	if (pGeneral != NULL) {
#if _MSC_VER < 1400 
		wcsncpy(pGeneral->Name, pSYSTEM_INFO->GetOEMDeviceName(), GENERALCONFIG_NAME_LEN);
#else
		wcsncpy_s( pGeneral->Name, sizeof(pGeneral->Name)/sizeof(WCHAR),pSYSTEM_INFO->GetOEMDeviceName() , _TRUNCATE );
#endif
		QString strDescription("");
		strDescription = QString::asprintf("%s %s", pSYSTEM_INFO->GetOEMCompanyName(),
				pSYSTEM_INFO->GetOEMProductRangeName());
#if _MSC_VER < 1400 
        wcsncpy(pGeneral->Description, strDescription.toStdWString().c_str(), GENERALCONFIG_DESCRIPTION_LEN);
#else
		wcsncpy_s( pGeneral->Description, sizeof(pGeneral->Description)/sizeof(WCHAR),strDescription, _TRUNCATE );
#endif
		int groupIndex = 0;
		QString strGroupTitle("");
        strGroupTitle = QWidget::tr("Group %u");
		QString groupName;
		for (groupIndex = 0; groupIndex < GENERALCONFIG_GROUPNAME_SIZE; groupIndex++) {
            groupName = QString::asprintf(strGroupTitle.toStdString().c_str(), groupIndex + 1);
#if _MSC_VER < 1400 
            wcsncpy(pGeneral->GroupName[groupIndex], groupName.toStdWString().c_str(), GENERALCONFIG_GROUPNAME_LEN);
#else
			wcsncpy_s( pGeneral->GroupName[groupIndex], sizeof(pGeneral->GroupName[groupIndex])/sizeof(WCHAR), groupName, _TRUNCATE );
#endif
		}
		QString strTableTitle("");
        strTableTitle = QWidget::tr("Linear Table %u");
		for (groupIndex = 0; groupIndex < GENERALCONFIG_USERTABLE_SIZE; groupIndex++) {
			groupName = QString::asprintf(IDS_CFG_LINEARISATION_DEF_TABLE_TITLE, groupIndex + 1);
#if _MSC_VER < 1400 
            wcsncpy(pGeneral->UserTable[groupIndex].Name, groupName.toStdWString().c_str(), LOOKUPTABLE_NAME_LEN);
#else
			wcsncpy_s( pGeneral->UserTable[groupIndex].Name, sizeof(pGeneral->UserTable[groupIndex].Name)/sizeof(WCHAR),groupName, _TRUNCATE );
#endif
			// ensure the first 2 points are defaulted to something valid and that basically gives
			// a one to one mapping
			pGeneral->UserTable[groupIndex].LookupEntry[0].in = 0;
			pGeneral->UserTable[groupIndex].LookupEntry[0].out = 0;
			pGeneral->UserTable[groupIndex].LookupEntry[1].in = 1;
			pGeneral->UserTable[groupIndex].LookupEntry[1].out = 1;
			pGeneral->UserTable[groupIndex].ElementCount = 2;
		}
		// default the batch field names
#if _MSC_VER < 1400
		QString strFieldName("");
        strFieldName = QObject::tr("Name");
        wcsncpy(pGeneral->Batch.FieldNames[bflNAME], strFieldName.toStdWString().c_str(), BATCH_FIELDNAMES_LEN);
        strFieldName = QWidget::tr("User ID");
        wcsncpy(pGeneral->Batch.FieldNames[bflUSER_ID], strFieldName.toStdWString().c_str(), BATCH_FIELDNAMES_LEN);
        strFieldName = QWidget::tr("Desc.");
        wcsncpy(pGeneral->Batch.FieldNames[bflDESCRIPTION], strFieldName.toStdWString().c_str(), BATCH_FIELDNAMES_LEN);
        strFieldName = QWidget::tr("Lot No.");
        wcsncpy(pGeneral->Batch.FieldNames[bflLOT_NO], strFieldName.toStdWString().c_str(), BATCH_FIELDNAMES_LEN);
        strFieldName = QWidget::tr("Comment");
        wcsncpy(pGeneral->Batch.FieldNames[bflDESCRIPTION], strFieldName.toStdWString().c_str(), BATCH_FIELDNAMES_LEN);
#else
		QString   strFieldName( QString   ::fromWCharArray("") );
    strFieldName = QWidget::tr("Name");
		wcsncpy_s( pGeneral->Batch.FieldNames[ bflNAME ], sizeof(pGeneral->Batch.FieldNames[ bflNAME ])/sizeof(WCHAR), strFieldName.GetBuffer( 0 ), _TRUNCATE );
    strFieldName = QWidget::tr("User ID");
		wcsncpy_s( pGeneral->Batch.FieldNames[ bflUSER_ID ], sizeof(pGeneral->Batch.FieldNames[ bflUSER_ID ])/sizeof(WCHAR),strFieldName.GetBuffer( 0 ), _TRUNCATE );
    strFieldName = QWidget::tr("Desc.");
		wcsncpy_s( pGeneral->Batch.FieldNames[ bflDESCRIPTION ], sizeof(pGeneral->Batch.FieldNames[ bflDESCRIPTION ])/sizeof(WCHAR),strFieldName.GetBuffer( 0 ), _TRUNCATE );
    strFieldName = QWidget::tr("Lot No.");
		wcsncpy_s( pGeneral->Batch.FieldNames[ bflLOT_NO ], sizeof(pGeneral->Batch.FieldNames[ bflLOT_NO ])/sizeof(WCHAR),strFieldName.GetBuffer( 0 ), _TRUNCATE );
    strFieldName = QWidget::tr("Comment");
		wcsncpy_s( pGeneral->Batch.FieldNames[ bflCOMMENT ], sizeof(pGeneral->Batch.FieldNames[ bflCOMMENT ])/sizeof(WCHAR),strFieldName.GetBuffer( 0 ), _TRUNCATE );
#endif
		// default CJC missing to true as it is a common error/support call generator
		pGeneral->ErrorControl.CJCMissing = TRUE;
	}
}
//*************************************************************************************
/// Create a devcaps block and copy in the current device caps working sturcture
///
/// @return Pointer to the CMM based device caps block; otherwise NULL
/// 
//*************************************************************************************
T_PDEVICECAPS CGeneralSetupConfig::CreateDevCapsBlock() {
	T_PDEVICECAPS pDevCaps = NULL;
	pDevCaps = reinterpret_cast<T_PDEVICECAPS>(CConfiguration::CreateNewBlock(BLK_DEVICECAPS, 0, m_ConfigurationId));
	if (pDevCaps != NULL) {
		if (pDALGLB->GetDeviceType() == DEV_PC_SCREEN_DESIGNER) {
			// If not a device then default to demo boards allowed
			for (USHORT usCount = 0; usCount < BRDCHANDEF_MULTIPLUS_MAX_AI_CARDS; usCount++)
				pDevCaps->Slot[usCount].Type = BOARD_NOT_FITTED;
		} else {
			UpdateDevcapsCMMFromSystem(pDevCaps);
		}
	}
	return pDevCaps;
}
//*************************************************************************************
/// Get the devcaps configuration from the CMM.
///
/// @param[in] cfgType - The type of configuration to access.
///
/// @return Pointer to the device caps block; otherwise NULL
/// 
//*************************************************************************************
T_PDEVICECAPS CGeneralSetupConfig::GetDeviceCapsBlock(REFERENCE cfgType) {
	return reinterpret_cast<T_PDEVICECAPS>(CConfiguration::GetBlock(BLK_DEVICECAPS, 0, m_ConfigurationId, cfgType));
}
//*************************************************************************************
/// Updates the CMM based version of Devcaps with the system version
///
/// @param[in] pDevCaps - pointer to the CMM based devaps structure
/// @return nothing
/// 
//*************************************************************************************
void CGeneralSetupConfig::UpdateDevcapsCMMFromSystem(T_PDEVICECAPS pDevCaps) {
	// Copy in current global device caps into CMM based version
	memcpy(pDevCaps, pDEVICE_INFO->m_pdc, sizeof(T_DEVICECAPS));
}
//*************************************************************************************
/// Updates the system version of Devcaps with the CMM based version
///
/// @param[in] pDevCaps - pointer to the CMM based devaps structure
/// @return nothing
/// 
//*************************************************************************************
void CGeneralSetupConfig::UpdateDevcapsSystemFromCMM(T_PDEVICECAPS pDevCaps) {
	// Copy in current global device caps into CMM based version
	memcpy( pDEVICE_INFO->m_pdc, pDevCaps, sizeof(T_DEVICECAPS));
}
//*************************************************************************************
/// Create a General NV block and copy in the current General NV working sturcture
///
/// @return Pointer to the CMM based general non vol block; otherwise NULL
/// 
//*************************************************************************************
T_PGENNONVOL CGeneralSetupConfig::CreateGenNonVolBlock() {
	T_PGENNONVOL pGenNV;
	pGenNV = reinterpret_cast<T_PGENNONVOL>(CConfiguration::CreateNewBlock(BLK_GENNONVOL, 0, m_ConfigurationId));
	if (pGenNV != NULL) {
		T_DEV_TYPE devType = pDALGLB->GetDeviceType();
		// For TTR6 setup only we need to provide a fully loaded recorder
		if (devType == DEV_XS_MINITREND || devType == DEV_XS_MULTIPLUS || devType == DEV_XS_EZTREND
				|| DEV_ARISTOS_MINITREND || DEV_ARISTOS_MULTIPLUS || DEV_ARISTOS_EZTREND || DEV_SCR_MINITREND) {
#if defined ( TTR6SETUP )
				UpdateGenNonVolCMMFromSystem( pGenNV );
				InitialiseForTV6DLL( pGenNV );
				UpdateGenNonVolSystemFromCMM( pGenNV );
			#endif 
		}
		if (devType == DEV_PC_TTR6SETUP) {
			UpdateGenNonVolCMMFromSystem(pGenNV);
			InitialiseForTV6DLL(pGenNV);
			UpdateGenNonVolSystemFromCMM(pGenNV);
		} else if (devType == DEV_PC_SCREEN_DESIGNER) {
			// turn on all the extra pens
			pGenNV->FWOptions.ExtraPens = 48;
			pGenNV->FWOptions.Batch = TRUE;
			// If not a device then default to demo boards allowed
			pGenNV->IsDemoBoard[BRDCHANDEF_SLOT_A] = dboSIMULATE_IF_NO_BOARD_FITTED;
			pGenNV->IsDemoBoard[BRDCHANDEF_SLOT_B] = dboSIMULATE_IF_NO_BOARD_FITTED;
			pGenNV->IsDemoBoard[BRDCHANDEF_SLOT_C] = dboSIMULATE_IF_NO_BOARD_FITTED;
			pGenNV->IsDemoBoard[BRDCHANDEF_SLOT_D] = dboSIMULATE_IF_NO_BOARD_FITTED;
			pGenNV->IsDemoBoard[BRDCHANDEF_SLOT_E] = dboSIMULATE_IF_NO_BOARD_FITTED;
			pGenNV->IsDemoBoard[BRDCHANDEF_SLOT_F] = dboSIMULATE_IF_NO_BOARD_FITTED;
			// for screen designer, we want default CMM data to override NV data
			UpdateGenNonVolSystemFromCMM(pGenNV);
			for (USHORT usCount = 0; usCount < BRDCHANDEF_MULTIPLUS_MAX_AI_CARDS; usCount++) {
				// Mini/Multi can always have 8 channels.
				GlbDevCaps.SetSlotInfo(usCount, BOARD_AI, 8);
				// Set the Channel Capabilities for the Required Channels
				GlbDevCaps.SetChannelCaps(usCount, BRDCHANDEF_CHANNEL_0, CHANNEL_CAP_AI);
				GlbDevCaps.SetChannelCaps(usCount, BRDCHANDEF_CHANNEL_1, CHANNEL_CAP_AI);
				GlbDevCaps.SetChannelCaps(usCount, BRDCHANDEF_CHANNEL_2, CHANNEL_CAP_AI);
				GlbDevCaps.SetChannelCaps(usCount, BRDCHANDEF_CHANNEL_3, CHANNEL_CAP_AI);
				GlbDevCaps.SetChannelCaps(usCount, BRDCHANDEF_CHANNEL_4, CHANNEL_CAP_AI);
				GlbDevCaps.SetChannelCaps(usCount, BRDCHANDEF_CHANNEL_5, CHANNEL_CAP_AI);
				GlbDevCaps.SetChannelCaps(usCount, BRDCHANDEF_CHANNEL_6, CHANNEL_CAP_AI);
				GlbDevCaps.SetChannelCaps(usCount, BRDCHANDEF_CHANNEL_7, CHANNEL_CAP_AI);
				// Enable the Demo Board 
				GlbDevCaps.SetDemoBoard(usCount, TRUE);
			}
		} else {
			if ((devType != DEV_ARISTOS_MINITREND) && (devType != DEV_ARISTOS_MULTIPLUS)
					&& (devType != DEV_ARISTOS_EZTREND) && (devType != DEV_SCR_MINITREND)) //ARISTOS QXe Device Type updates
					{
				// If not a device then default to demo boards allowed
				pGenNV->IsDemoBoard[BRDCHANDEF_SLOT_A] = dboSIMULATE_IF_NO_BOARD_FITTED;
				pGenNV->IsDemoBoard[BRDCHANDEF_SLOT_B] = dboSIMULATE_IF_NO_BOARD_FITTED;
			} else {
				// If it is a device then default first slot to demo boards allowed
				//This will help if the customer ordered recorder with no IO cards and
				//using it for Modbus communication. The demo traces will enable pens 
				//which in turn help for Modbus communication. Enable for only first slot
				//as it is for Analog card
				pGenNV->IsDemoBoard[BRDCHANDEF_SLOT_A] = dboSIMULATE_IF_NO_BOARD_FITTED;
			}
			// Copy in current global NV block into CMM based version
			UpdateGenNonVolCMMFromSystem(pGenNV);
		}
	}
	return pGenNV;
}
//*************************************************************************************
/// Setup a fully loaded set of options for a new device created in TMP Setup
///
/// @param[in] pGenNV - pointer to CMM based Gen non Vol block to update
///
/// @return nothing
/// 
//*************************************************************************************
void CGeneralSetupConfig::InitialiseForTV6DLL(T_PGENNONVOL pGenNV) {
	pGenNV->FWOptions.ExtraPens = 48;
	pGenNV->Credits = 200; // Credits raised to 150 for Aristos
	pGenNV->FWOptions.Batch = TRUE;
	pGenNV->FWOptions.ControlLoops = FALSE;
	pGenNV->FWOptions.Counters = TRUE;
	pGenNV->FWOptions.CustomScreens = TRUE;
	pGenNV->FWOptions.AMS2750Process = FALSE;
	pGenNV->FWOptions.Email = TRUE;
	pGenNV->FWOptions.Events = TRUE;
	pGenNV->FWOptions.FastScan = TRUE;
	pGenNV->FWOptions.Groups = TRUE;
	pGenNV->FWOptions.Maintenance = TRUE;
	pGenNV->FWOptions.ModbusMaster = TRUE;
	/*pGenNV->FWOptions.OPC = TRUE;*/
	pGenNV->FWOptions.ExtSD = FALSE;
	pGenNV->FWOptions.Passwords = FALSE;
	pGenNV->FWOptions.PasswordCFR = TRUE; ///???????????????? OPTIONS CODE DEPENDANT
	pGenNV->FWOptions.PasswordsSync = TRUE;
	pGenNV->FWOptions.Pasturisation = TRUE; ///???????????????? OPTIONS CODE DEPENDANT
	pGenNV->FWOptions.PrintSupport = TRUE;
	pGenNV->FWOptions.RemoteView = TRUE;
	pGenNV->FWOptions.Reports = TRUE;
	pGenNV->FWOptions.AMS2750TUS = FALSE;
	pGenNV->FWOptions.Totals = TRUE;
	pGenNV->FWOptions.TrendBus = FALSE;
#ifndef TTR6SETUP
	pGenNV->FWOptions.SecureWSD = TRUE; //R200 - WSD True by default e836320_tvgr200_spr_1_wsd
#else
	pGenNV->FWOptions.SecureWSD = FALSE;
#endif
	pGenNV->FWOptions.RTDataBus = FALSE;
	pGenNV->FWOptions.OPCUA = FALSE;
//	pGenNV->FWOptions.SecureComm = FALSE;
	if (!pDEVICE_INFO->IsRecorderEzTrend()) {
		pGenNV->FWOptions.MathsType = MATH_OPTION_FULL_SCRIPT;
		if ( pDEVICE_INFO->IsRecorderMini()) {
			pGenNV->FWOptions.ExtraPens = 16;
		}
	} else {
		pGenNV->FWOptions.MathsType = MATH_OPTION_FULL_BLOCK;
		pGenNV->FWOptions.CustomScreens = FALSE;
		pGenNV->FWOptions.FastScan = FALSE;
		pGenNV->FWOptions.ExtraPens = 12;
		pGenNV->FWOptions.ExtSD = TRUE;
	}
}
//*************************************************************************************
/// Update the General NV block in CMM with the system based block
///
/// @param[in] pGenNV - pointer to CMM based Gen non Vol block to update
///
/// @return nothing
/// 
//*************************************************************************************
void CGeneralSetupConfig::UpdateGenNonVolCMMFromSystem(T_PGENNONVOL pGenNV) {
	// Copy in current global NV block into CMM based version
	memcpy(pGenNV, pSYSTEM_INFO->GetFactoryConfig(), sizeof(T_GENNONVOL));
}
//*************************************************************************************
/// Update the CMM with the system based block
///
/// @param[in] pGenNV - pointer to CMM based Gen non Vol block to update system from
///
/// @return nothing
/// 
//*************************************************************************************
void CGeneralSetupConfig::UpdateGenNonVolSystemFromCMM(T_PGENNONVOL pGenNV) {
	// Copy in current global NV block into CMM based version
	memcpy( pSYSTEM_INFO->GetFactoryConfig(), pGenNV, sizeof(T_GENNONVOL));
}
//*************************************************************************************
/// Get the general non volatile configuration from the CMM.
///
/// @param[in] cfgType - The type of configuration to access.
///
/// @return Pointer to the Gen non vol block; otherwise NULL
/// 
//*************************************************************************************
T_PGENNONVOL CGeneralSetupConfig::GetGenNonVolBlock(REFERENCE cfgType) {
	return reinterpret_cast<T_PGENNONVOL>(CConfiguration::GetBlock(BLK_GENNONVOL, 0, m_ConfigurationId, cfgType));
}
//*************************************************************************************
/// Create a Profile block
///
/// @return Pointer to the CMM based profile block; otherwise NULL
/// 
//*************************************************************************************
T_PRECPROFILE CGeneralSetupConfig::CreateProfileBlock() {
	T_PRECPROFILE pProfile;
	pProfile = reinterpret_cast<T_PRECPROFILE>(CConfiguration::CreateNewBlock(BLK_RECPROFILE, 0, m_ConfigurationId));
	if (pProfile != NULL) {
		// default the logging info unused flag which is used to indicate whether we should copy information from
		// the old logging NV block
		pProfile->Logging.unused = 1;
	}
	return pProfile;
}
//*************************************************************************************
/// Get the Profile configuration from the CMM.
///
/// @param[in] cfgType - The type of configuration to access.
///
/// @return Pointer to the profile block; otherwise NULL
/// 
//*************************************************************************************
T_PRECPROFILE CGeneralSetupConfig::GetProfileBlock(REFERENCE cfgType) {
	return reinterpret_cast<T_PRECPROFILE>(CConfiguration::GetBlock(BLK_RECPROFILE, 0, m_ConfigurationId, cfgType));
}
//*************************************************************************************
/// Get the change header block from the CMM.
///
/// @param[in] cfgType - The type of configuration to access.
///
/// @return Pointer to the change header block; otherwise NULL
/// 
//*************************************************************************************
T_PCHANGEHEADER CGeneralSetupConfig::GetChangeHeaderBlock(REFERENCE cfgType) {
	return reinterpret_cast<T_PCHANGEHEADER>(CConfiguration::GetBlock(BLK_CHANGEHEADER, 0, m_ConfigurationId, cfgType));
}
//*************************************************************************************
/// Create a change header
///
/// @return Pointer to the CMM based change header block; otherwise NULL
/// 
//*************************************************************************************
T_PCHANGEHEADER CGeneralSetupConfig::CreateChangeHeaderBlock() {
	T_PCHANGEHEADER pchangeHeader;
	pchangeHeader = reinterpret_cast<T_PCHANGEHEADER>(CConfiguration::CreateNewBlock(BLK_CHANGEHEADER, 0,
			m_ConfigurationId));
	return pchangeHeader;
}
//****************************************************************************
// CConfigBranch *CreateGeneralDeviceConfig( )
///
/// Method that determines if the printing function is allowed/enabled
///
/// @return True if the firmware credits and recorder setup allow printing
///
//****************************************************************************
const bool CGeneralSetupConfig::PrintingIsAllowed() {
	bool bPrintingAllowed = false;
	// check if the credits are enabled
	if ( pSYSTEM_INFO->FWOptionPrintSupportAvailable()) {
		// printing credits are enabled, now check if the config allows printing
		if (GetSystemGeneralBlock(CONFIG_COMMITTED)->Printer.AllowPrint == TRUE) {
			// printing is allowed
			bPrintingAllowed = true;
		} else {
			// printing is not allowed
			bPrintingAllowed = false;
		}
	} else {
		// credits not enabled
		bPrintingAllowed = false;
	}
	return bPrintingAllowed;
}
//*************************************************************************************
/// Get the current furnace information configuration from the CMM.
///
/// @param[in] cfgType - The type of configuration to access.
///
/// @return Pointer to the furnace information; otherwise NULL
/// 
//*************************************************************************************
T_PFURNACESCONFIG CGeneralSetupConfig::GetAMS2750FurnaceInfoBlock(REFERENCE cfgType) {
	return reinterpret_cast<T_PFURNACESCONFIG>(CConfiguration::GetBlock(BLK_FURNACESCONFIG, 0, m_ConfigurationId,
			cfgType));
}
//*************************************************************************************
/// Create a default furnace information block
///
/// @return Pointer to the furnace information block; otherwise NULL
/// 
//*************************************************************************************
T_PFURNACESCONFIG CGeneralSetupConfig::CreateAMS2750FurnaceInfoBlock() {
	T_PFURNACESCONFIG pFurnaces = NULL;
	// get furnace information Block
	pFurnaces = reinterpret_cast<T_PFURNACESCONFIG>(CConfiguration::CreateNewBlock(BLK_FURNACESCONFIG, 0,
			m_ConfigurationId));
	DefaultAMS2750FurnaceInfo(pFurnaces);
	return pFurnaces;
}
//*************************************************************************************
/// default a furnace information block
///
/// @return Pointer to the furnace information block; otherwise NULL
/// 
//*************************************************************************************
void CGeneralSetupConfig::DefaultAMS2750FurnaceInfo(T_PFURNACESCONFIG pFurnaces) {
	// If furnaces block created okay the perform specific initialisations
	if (pFurnaces != NULL) {
		QString strFurnaceName("");
		for (int iCount = 0; iCount < FURNACESCONFIG_FURNACES_SIZE; iCount++) {
			strFurnaceName = QString::asprintf(IDS_CFG_FURNACE_NAME_DEF_TITLE, iCount + 1);
            CStringUtils::SafeWcsCpy(pFurnaces->Furnaces[iCount].Name, strFurnaceName.toStdWString().c_str(), FURNACE_NAME_LEN);
			pFurnaces->Furnaces[iCount].Manufacturer[0] = 0;
			pFurnaces->Furnaces[iCount].ModelNo[0] = 0;
		}
	}
}
//*************************************************************************************
/// Get the current AMS2750 calibration configuration from the CMM.
///
/// @param[in] cfgType - The type of configuration to access.
///
/// @return Pointer to the calibration information; otherwise NULL
/// 
//*************************************************************************************
T_PAMS2750CALCFG CGeneralSetupConfig::GetAMS2750CalibrationBlock(REFERENCE cfgType) {
	return reinterpret_cast<T_PAMS2750CALCFG>(CConfiguration::GetBlock(BLK_AMS2750CALCFG, 0, m_ConfigurationId, cfgType));
}
//*************************************************************************************
/// Create a default AMS2750 calibration information block
///
/// @return Pointer to the AMS2750 calibration information block; otherwise NULL
/// 
//*************************************************************************************
T_PAMS2750CALCFG CGeneralSetupConfig::CreateAMS2750CalibrationBlock() {
	T_PAMS2750CALCFG pCalConfig = NULL;
	// get calibration config information Block
	pCalConfig = reinterpret_cast<T_PAMS2750CALCFG>(CConfiguration::CreateNewBlock(BLK_AMS2750CALCFG, 0,
			m_ConfigurationId));
	DefaultAMS2750CalibrationInfo(pCalConfig);
	return pCalConfig;
}
//*************************************************************************************
/// default a AMS2750 calibration information block
///
/// @return Pointer to the calibration information block; otherwise NULL
/// 
//*************************************************************************************
void CGeneralSetupConfig::DefaultAMS2750CalibrationInfo(T_PAMS2750CALCFG pCalibration) {
	// If calibration block created okay then perform specific initialisations
	if (pCalibration != NULL) {
		QString tempStr("");
		tempStr = QString::asprintf(IDS_NOT_AVAILABLE_TITLE);
        CStringUtils::SafeWcsCpy(pCalibration->CalibratorType, tempStr.toStdWString().c_str(), AMS2750CALCFG_CALIBRATORTYPE_LEN);
        CStringUtils::SafeWcsCpy(pCalibration->CalibratorSerNo, tempStr.toStdWString().c_str(), AMS2750CALCFG_CALIBRATORSERNO_LEN);
        CStringUtils::SafeWcsCpy(pCalibration->TraceableTo, tempStr.toStdWString().c_str(), AMS2750CALCFG_qDebugABLETO_LEN);
        CStringUtils::SafeWcsCpy(pCalibration->TechnicianId, tempStr.toStdWString().c_str(), AMS2750CALCFG_TECHNICIANID_LEN);
        CStringUtils::SafeWcsCpy(pCalibration->CalPerformedBy, tempStr.toStdWString().c_str(), AMS2750CALCFG_CALPERFORMEDBY_LEN);
        CStringUtils::SafeWcsCpy(pCalibration->CalPerformedFor, tempStr.toStdWString().c_str(), AMS2750CALCFG_CALPERFORMEDFOR_LEN);
        CStringUtils::SafeWcsCpy(pCalibration->QualityOrg, tempStr.toStdWString().c_str(), AMS2750CALCFG_QUALITYORG_LEN);
		for (int calPointNo = 0; calPointNo < AMS2750CALCFG_CALPOINTS_SIZE; calPointNo++) {
			pCalibration->CalPoints->CalPoint = 0.0f;
			pCalibration->CalPoints->Offset = 0.0f;
		}
	}
}

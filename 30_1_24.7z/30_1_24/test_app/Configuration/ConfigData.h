/// @file
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Configuration System
/// @n Filename:  ConfigData.h
/// @n Description: Definition for the CConfigData base class and its inherited classes
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  43  Stability Project 1.40.1.1 7/2/2011 4:56:16 PM Hemant(HAIL)
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  42  Stability Project 1.40.1.0 7/1/2011 4:28:14 PM Hemant(HAIL)
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware.
//  41  V6 Firmware 1.40 9/23/2008 3:09:23 PM  Build Machine
//  AMS2750 Merge
//  40  V6 Firmware 1.39 3/22/2007 4:22:47 PM  Roger Dawson
//  Modified the code that updates the data for the multiple pickers so
//  it uses USHORT's rather than ULONG's thus avoiding data misalignment
//  issues.
// $
//
// **************************************************************************
#if !defined( _CCONFIGDATA_H )
#define _CCONFIGDATA_H

#include "ConfigSystemData.h"
#include "CMMDefines.h"
#include "../inc/SIPGlobal.h"
#include "Conversion.h"
#include "../inc/SysInfo.h"
#include "../UIControl/PickerMgr.h"
#include "../inc/EUDCDefs.h"
#include "../OpPanel/Widget.h"
#include "V6Config.h"
/// Enum used to store the various types of bitfield
typedef enum {
    bfeBool, bfeNumerical, bfeSingleSelList
} BitFieldEditor;
//**CConfigData*********************************************************************
///
/// @brief Virtual base class for the config item data attributes
///
/// Virtual base class for the config item data attributes
///
//****************************************************************************
class CConfigData {
public:
    virtual ~CConfigData(void);
    // Accessor methods
    const T_CFG_DATA_TYPE GetDataType() const {
        return m_eDATA_TYPE;
    }
    // Pointer to the data currently being edited - required for validation purposes
    static CConfigData *ms_pkEditData;
    // Method called to validate data entered by a user
    virtual bool ValidateData(const QString pwcDATA) {
        return true;
    }
    virtual bool IsBoolean() const {
        return (m_eDATA_TYPE == dtBool);
    }
    const bool IsBitfield() const {
        return (m_eDATA_TYPE == dtShortBitField) || (m_eDATA_TYPE == dtLongBitField)
                || (m_eDATA_TYPE == dtFWOptBitField);
    }
    const bool IsPicker() const {
        return (m_eDATA_TYPE >= dtSinglePen) && (m_eDATA_TYPE <= dtMultiAlarm);
    }
    const bool UpdateTree() const {
        return m_bUPDATE_TREE_ON_CHANGE;
    }
    // Method that updates the data based on the passed in string
    virtual void UpdateData(const QString pwcDATA) {
        ;
    }
    // Method that returns a pointer to the data
    virtual void* GetData() const {
        return NULL;
    }
    // Method that returns the data as a string
    virtual const QString GetDataAsString(const bool bINCLUDE_UNITS = false) = 0;
    // The maximum allowable length of the string
    virtual const USHORT GetDataLength() const {
        return 0;
    }
    // Accessor for the requires restart flag
    const bool GetRequiresRestart() const {
        return m_bREQUIRES_RESTART;
    }
    // Method that returns the units associated with this item
    const QString GetUnits(void) const {
        return m_strUNITS;
    }
protected:
    // Constructor - not to be called directly, only via the inherited classes
    CConfigData(const T_CFG_DATA_TYPE eDATA_TYPE, const int iHELP_ID, const char* iDESC_ID,
            const bool bUPDATE_TREE_ON_CHANGE, const bool bREQUIRES_RESTART = false, const QString &rstrUNITS =
                    "");
            // The type of the data stored within this class
            const T_CFG_DATA_TYPE m_eDATA_TYPE;
    // Variable that indicates if this item requires the config tree to be rebuilt
    const bool m_bUPDATE_TREE_ON_CHANGE;
    /// Flag indicating if this item requires a system restart when it is modified
    const bool m_bREQUIRES_RESTART;
    /// String containing any required units that we must display at the end of the string
    QString m_strUNITS;
private:
};
//**CBoolData*********************************************************************
///
/// @brief Class containing information on bool config data items
///
/// Class containing information on bool config data items
///
//****************************************************************************
class CBoolData: public CConfigData {
public:
    CBoolData(TV_BOOL *pbDATA, const int iHELP_ID, const char* iDESC_ID, const bool bUPDATE_TREE_ON_CHANGE);
    ~CBoolData(void);
    void UpdateData(const QString pwcDATA);
    void UpdateData(TV_BOOL bTRUE);
    // Method that returns the data as a string
    const QString GetDataAsString(const bool bINCLUDE_UNITS = false);
    // Method that toggles the boolean flag as a quick method of editing the variable
    void ToggleData() {
        *m_pbData = !(*m_pbData);
    }
private:
    /// Pointer to the floating point data
    TV_BOOL *m_pbData;
};
//**CFloatData*********************************************************************
///
/// @brief Class containing information on floating point config data items
///
/// Class containing information on floating point config data items
///
//****************************************************************************
class CFloatData: public CConfigData {
public:
    CFloatData(float *pfDATA, const float fLOWER, const float fUPPER, const int iHELP_ID, const char* iDESC_ID,
            const bool bUPDATE_TREE_ON_CHANGE, const T_CFG_DATA_TYPE eDATA_TYPE = dtFloat,
            const T_TEMP_UNIT eTEMP_UNIT = TEMP_DEG_C, const QString strUNITS = "",
            const T_PNUMFORMAT ptNUM_FORMAT = NULL);
    ~CFloatData(void);
    // Method called to validate data entered by a user
    bool ValidateData(const QString pwcDATA);
    void UpdateData(const QString pwcDATA);
    // Method that returns a pointer to the data
    void* GetData() const {
        return m_pfData;
    }
    // Method that returns the data as a string
    const QString GetDataAsString(const bool bINCLUDE_UNITS = false);
    // The maximum allowable length of the data as a string
    const USHORT GetDataLength() const {
        return g_usMAX_FLOAT_STR_LEN;
    }
private:
    /// Pointer to the floating point data
    float *m_pfData;
    /// the upper and lower limits required to validate a floating point number
    float m_fLower;
    float m_fUpper;
    // Enum indicating what type of temperature units this item is to be displayed in (only applies
    // to temperature data types)
    T_TEMP_UNIT m_eDISP_TEMP_UNIT;
    /// Pointer to the associted num format structure - may be null
    const T_PNUMFORMAT m_ptNUM_FORMAT;
};
//**CLongData*********************************************************************
///
/// @brief Class containing information on long config data items
///
/// Class containing information on long config data items
///
//****************************************************************************
class CLongData: public CConfigData {
public:
    CLongData(long *plDATA, const long lLOWER, const long lUPPER, const int iHELP_ID, const char* iDESC_ID,
            const bool bUPDATE_TREE_ON_CHANGE);
    ~CLongData(void);
    // Method called to validate data entered by a user
    bool ValidateData(const QString pwcDATA);
    void UpdateData(const QString pwcDATA);
    // Method that returns a pointer to the data
    void* GetData() const {
        return m_plData;
    }
    // Method that returns the data as a string
    const QString GetDataAsString(const bool bINCLUDE_UNITS = false);
    // The maximum allowable length of the data as a string
    const USHORT GetDataLength() const {
        return g_usMAX_LONG_STR_LEN;
    }
private:
    /// Pointer to the long data
    long *m_plData;
    /// the upper and lower limits required to validate a LONG
    long m_lLower;
    long m_lUpper;
};
//**CULongData*********************************************************************
///
/// @brief Class containing information on ULong config data items
///
/// Class containing information on ULong config data items
///
//****************************************************************************
class CULongData: public CConfigData {
public:
    CULongData(ULONG *pulDATA, const ULONG ulLOWER, const ULONG ulUPPER, const int iHELP_ID, const char* iDESC_ID,
            const bool bUPDATE_TREE_ON_CHANGE, const T_CFG_DATA_TYPE eDATA_TYPE = dtUnsignedLong,
            const QString strUNITS = "", const bool bREQUIRES_RESTART = false);
    ~CULongData(void);
    // Method called to validate data entered by a user
    bool ValidateData(const QString pwcDATA);
    void UpdateData(const QString pwcDATA);
    // Method that returns a pointer to the data
    void* GetData() const {
        return m_pulData;
    }
    // Method that returns the data as a string
    const QString GetDataAsString(const bool bINCLUDE_UNITS = false);
    // The maximum allowable length of the data as a string
    const USHORT GetDataLength() const;
private:
    /// Pointer to the ULONG data
    ULONG *m_pulData;
    /// the upper and lower limits required to validate a ULONG
    ULONG m_ulLower;
    ULONG m_ulUpper;
};
//**CShortData*********************************************************************
///
/// @brief Class containing information on short config data items
///
/// Class containing information on short config data items
///
//****************************************************************************
class CShortData: public CConfigData {
public:
    CShortData(short *psDATA, const short sLOWER, const short sUPPER, const int iHELP_ID, const char* iDESC_ID,
            const bool bUPDATE_TREE_ON_CHANGE, const QString strUNITS = "");
    ~CShortData(void);
    // Method called to validate data entered by a user
    bool ValidateData(const QString pwcDATA);
    void UpdateData(const QString pwcDATA);
    // Method that returns a pointer to the data
    void* GetData() const {
        return m_psData;
    }
    // Method that returns the data as a string
    const QString GetDataAsString(const bool bINCLUDE_UNITS = false);
    // The maximum allowable length of the data as a string
    const USHORT GetDataLength() const {
        return g_usMAX_SHORT_STR_LEN;
    }
private:
    /// Pointer to the short data
    short *m_psData;
    /// the upper and lower limits required to validate a short
    short m_sLower;
    short m_sUpper;
};
//**CUShortData*********************************************************************
///
/// @brief Class containing information on USHORT config data items
///
/// Class containing information on USHORT config data items
///
//****************************************************************************
class CUShortData: public CConfigData {
public:
    CUShortData(USHORT *pusDATA, const USHORT usLOWER, const USHORT usUPPER, const int iHELP_ID, const char* iDESC_ID,
            const bool bUPDATE_TREE_ON_CHANGE, const T_CFG_DATA_TYPE eDATA_TYPE = dtUnsignedShort,
            const QString strUNITS = "", const bool bREQUIRES_RESTART = false);
    ~CUShortData(void);
    // Method called to validate data entered by a user
    bool ValidateData(const QString pwcDATA);
    void UpdateData(const QString pwcDATA);
    // Method that shows the brightness slider and allows the user to adjust it
    const bool ShowSlider(const QString &rstrTITLE, QWidget *pkWnd);
    // Method that returns a pointer to the data
    void* GetData() const {
        return m_pusData;
    }
    // Method that returns the data as a string
    const QString GetDataAsString(const bool bINCLUDE_UNITS = false);
    // The maximum allowable length of the data as a string
    const USHORT GetDataLength() const {
        return m_eDATA_TYPE == dt16Colour ? 6 : g_usMAX_USHORT_STR_LEN;
    }
private:
    /// Pointer to the USHORT data
    USHORT *m_pusData;
    /// the upper and lower limits required to validate a USHORT
    USHORT m_usLower;
    USHORT m_usUpper;
};
//added by nilesh for SNTP
//[
class CULongDataForSNTPThreshold: public CConfigData {
public:
    CULongDataForSNTPThreshold(ULONG *pulDATA, const ULONG ulLOWER, const ULONG ulUPPER, const int iHELP_ID,
            const char* iDESC_ID, const bool bUPDATE_TREE_ON_CHANGE, const T_CFG_DATA_TYPE eDATA_TYPE = dtUnsignedLong,
            const QString strUNITS = "", const bool bREQUIRES_RESTART = false);
    ~CULongDataForSNTPThreshold(void);
    // Method called to validate data entered by a user
    bool ValidateData(const QString pwcDATA);
    void UpdateData(const QString pwcDATA);
    // Method that returns a pointer to the data
    void* GetData() const {
        return m_pulData;
    }
    // Method that returns the data as a string
    const QString GetDataAsString(const bool bINCLUDE_UNITS = false);
    // The maximum allowable length of the data as a string
    const USHORT GetDataLength() const;
private:
    /// Pointer to the ULONG data
    ULONG *m_pulData;
    /// the upper and lower limits required to validate a ULONG
    ULONG m_ulLower;
    ULONG m_ulUpper;
};
//**CUShortData*********************************************************************
///
/// @brief Class containing information on USHORT config data items
///
/// Class containing information on USHORT config data items
///
//****************************************************************************
class CUShortDataForSNTPUpdatePeriod: public CConfigData {
public:
    CUShortDataForSNTPUpdatePeriod(USHORT *pusDATA, const USHORT usLOWER, const USHORT usUPPER, const int iHELP_ID,
            const char* iDESC_ID, const bool bUPDATE_TREE_ON_CHANGE, const T_CFG_DATA_TYPE eDATA_TYPE = dtUnsignedShort,
            const QString strUNITS = "", const bool bREQUIRES_RESTART = false);
    ~CUShortDataForSNTPUpdatePeriod(void);
    // Method called to validate data entered by a user
    bool ValidateData(const QString pwcDATA);
    void UpdateData(const QString pwcDATA);
    // Method that shows the brightness slider and allows the user to adjust it
    const bool ShowSlider(const QString &rstrTITLE, QWidget *pkWnd);
    // Method that returns a pointer to the data
    void* GetData() const {
        return m_pusData;
    }
    // Method that returns the data as a string
    const QString GetDataAsString(const bool bINCLUDE_UNITS = false);
    // The maximum allowable length of the data as a string
    const USHORT GetDataLength() const {
        return m_eDATA_TYPE == dt16Colour ? 6 : g_usMAX_USHORT_STR_LEN;
    }
private:
    /// Pointer to the USHORT data
    USHORT *m_pusData;
    /// the upper and lower limits required to validate a USHORT
    USHORT m_usLower;
    USHORT m_usUpper;
};
//]
//**CBitFieldData*********************************************************************
///
/// @brief Abstract Class containing information on bitfield config data items
///
/// Class containing information on bitfield config data items
///
//****************************************************************************
class CBitFieldData: public CConfigData {
public:
    CBitFieldData(const T_CFG_DATA_TYPE eDATA_TYPE, const USHORT usNUM_OF_BITS, const USHORT usSTART_BIT,
            const QString pwcLIST_BOX_ITEMS, const BitFieldEditor eEDITOR_TYPE, const int iHELP_ID,
            const char* iDESC_ID, const bool bUPDATE_TREE_ON_CHANGE, const bool bREQUIRES_RESTART = false,
            const QString &rstrUNITS = "");
    ~CBitFieldData(void);
    // Method that returns the items required for a list control
    const WCHAR* GetListBoxItems() const {
        return m_pwcLIST_BOX_ITEMS;
    }
    bool IsBoolean() const {
        return (m_eEDITOR_TYPE == bfeBool);
    }
    bool IsSingleSelList() const {
        return (m_eEDITOR_TYPE == bfeSingleSelList);
    }
    virtual void UpdateData(const USHORT usBIT_VALUE) = 0;
    // Method that cross-references the text with the drop down list text and gets the position number
    // accordingly
    USHORT GetPosOfItem(const QString pwcDATA) const;
    // Method that toggles boolean data as a quick method of editing
    virtual void ToggleData() = 0;
    // Method that returns the data as a string
    virtual const QString GetDataAsString(const bool bINCLUDE_UNITS = false) = 0;
    // The maximum allowable length of the data as a string
    const USHORT GetDataLength() const {
        return g_usMAX_SHORT_STR_LEN;
    }
    // Method that removes any embedded control characters from the passed in string
    void RemoveEmbeddedControlInfo(QString &rstrItem) const;
    // Method that converts the index of an item into it's actual associated value e.g. screens have
    // a number, and when setting things like the alarm screen you need to set this value, not the index
    const USHORT ConvertIndexToActualVal(const USHORT usINDEX);
protected:
    /// Pointer to the short bitfield data
    USHORT m_usNumOfBits; // 1 - 16
    USHORT m_usStartBit;	// 0 based index, 0 - 15
    const QString m_pwcLIST_BOX_ITEMS;
    const BitFieldEditor m_eEDITOR_TYPE;
};
//**CShortBitFieldData*********************************************************************
///
/// @brief Class containing information on short bitfield config data items
///
/// Class containing information on short bitfield config data items
///
//****************************************************************************
class CShortBitFieldData: public CBitFieldData {
public:
    CShortBitFieldData(USHORT *pusDATA,
                       const USHORT usNUM_OF_BITS,
                       const USHORT usSTART_BIT,
                       const QString pwcLIST_BOX_ITEMS,
                       const BitFieldEditor eEDITOR_TYPE,
                       const int iHELP_ID,
                       const char* iDESC_ID,
                       const bool bUPDATE_TREE_ON_CHANGE,
                       const USHORT usLOWER = 0,
                       const USHORT usUPPER = USHRT_MAX,
                       const bool bREQUIRES_RESTART = false,
                       const QString &rstrUNITS = "");
    ~CShortBitFieldData(void);
    // Method that converts a bitfield into an INT
    USHORT BitFieldToUShort() const;
    // Method called to validate data entered by a user
    bool ValidateData(const QString pwcDATA);
    void UpdateData(const QString pwcDATA);
    void UpdateData(const USHORT usBIT_VALUE);
    // Method that returns a pointer to the data
    void* GetData() const {
        return m_pusData;
    }
    // Method that toggles boolean data as a quick method of editing
    void ToggleData();
    // Method that returns the data as a string
    const QString GetDataAsString(const bool bINCLUDE_UNITS = false);
private:
    /// Pointer to the short bitfield data
    USHORT *m_pusData;
    // Max/min limits - only used for numerical type bitfields
    const USHORT m_usLOWER;
    const USHORT m_usUPPER;
};
//**CLongBitFieldData*********************************************************************
///
/// @brief Class containing information on long bitfield config data items
///
/// Class containing information on long bitfield config data items
///
//****************************************************************************
class CLongBitFieldData: public CBitFieldData {
public:
    CLongBitFieldData(ULONG *pulDATA, const USHORT usNUM_OF_BITS, const USHORT usSTART_BIT,
            const QString pwcLIST_BOX_ITEMS, const BitFieldEditor eEDITOR_TYPE, const int iHELP_ID,
            const char* iDESC_ID, const bool bUPDATE_TREE_ON_CHANGE, const T_CFG_DATA_TYPE eDATA_TYPE = dtLongBitField,
            const bool bREQUIRES_RESTART = false, const ULONG ulLOWER = 0, const ULONG ulUPPER = ULONG_MAX,
            const QString &rstrUNITS = "");
    ~CLongBitFieldData(void);
    // Method that converts a bitfield into an INT
    ULONG BitFieldToULong() const;
    // Method called to validate data entered by a user
    bool ValidateData(const QString pwcDATA);
    void UpdateData(const QString pwcDATA);
    void UpdateData(const USHORT usBIT_VALUE);
    // Method that returns a pointer to the data
    void* GetData() const {
        return m_pulData;
    }
    // Method that returns the current firmware option this bitfield relates to
    CSysInfo::T_FIRMWARE_OPT GetFirmwareOption(const USHORT usCURR_SEL) const;
    // Method that toggles boolean data as a quick method of editing
    void ToggleData();
    // Method that returns the data as a string
    const QString GetDataAsString(const bool bINCLUDE_UNITS = false);
private:
    /// Pointer to the long bitfield data
    ULONG *m_pulData;
    /// The upper limit of any numerical data
    const ULONG m_ulUPPER;
    /// The lower limit of any numerical data
    const ULONG m_ulLOWER;
    // Method used to identify if the variable is part of the firmware options which require different
    // validation
    const bool IsFwOptBitField() const {
        return (m_eDATA_TYPE == dtFWOptBitField);
    }
};
//**QString  CfgData*********************************************************************
///
/// @brief Class containing information on string config data items
///
/// Class containing information on string config data items
///
//****************************************************************************
class CStringCfgData: public CConfigData {
public:
    CStringCfgData(QString pwcDATA, const USHORT usSTRING_LENGTH, const T_CFG_DATA_TYPE eDATA_TYPE, const int iHELP_ID,
            const char* iDESC_ID, const bool bUPDATE_TREE_ON_CHANGE);
    ~CStringCfgData(void);
    // Method called to validate data entered by a user
    bool ValidateData(const QString pwcDATA);
    void UpdateData(const QString pwcDATA);
    //const USHORT GetStringLength( ) const { return m_usStringLength - 1; }
    // Method that returns a pointer to the data
    void* GetData() const {
        return m_pwcData;
    }
    // The maximum allowable length of the data as a string
    const USHORT GetDataLength() const {
        return m_usStringLength - 1;
    }
    // Method that returns the data as a string
    const QString GetDataAsString(const bool bINCLUDE_UNITS = false);
private:
    /// Pointer to the string data
    QString m_pwcData;
    USHORT m_usStringLength;
    /// Variable indicating the number of attempts a user has made at entering an options code
    USHORT m_usAttempts;
};
//**CScriptData*********************************************************************
///
/// @brief Class containing information on script config data items
///
/// Class containing information on script config data items
///
//****************************************************************************
class CScriptData: public CConfigData {
public:
    // SiLE Script Constructor
    CScriptData(char *pcDATA, const USHORT usSTRING_LENGTH, const int iHELP_ID, const char* iDESC_ID,
            const bool bUPDATE_TREE_ON_CHANGE);
    // MuLE Script Constructor
    CScriptData(char *pcDATA, const USHORT usSTRING_LENGTH, const USHORT usPEN_NUMBER, const int iHELP_ID,
            const char* iDESC_ID, const bool bUPDATE_TREE_ON_CHANGE);
    // MuLE Email Template Constructor
    CScriptData(QString pwcDATA, const USHORT usSTRING_LENGTH, const USHORT usEMAIL_INSTANCE, const int iHELP_ID,
            const char* iDESC_ID, const bool bUPDATE_TREE_ON_CHANGE);
    ~CScriptData(void);
    // Method called to validate data entered by a user
    bool ValidateData(const QString pwcDATA);
    void UpdateData(const QString pwcDATA);
    const USHORT GetDataLength() const {
        return m_usSTRING_LENGTH - 1;
    }
    // Method that returns a pointer to the data
    void* GetData() const {
        return m_pcData;
    }
    // Method that returns the data as a string
    const QString GetDataAsString(const bool bINCLUDE_UNITS = false);
private:
    /// Pointer to the script data
    char *m_pcData;
    const USHORT m_usSTRING_LENGTH;
    const USHORT m_usINSTANCE_NUMBER;
};
//**CPickerData*********************************************************************
///
/// @brief Class containing information on data items that are chosen using a pick list
///
/// Class containing information on data items that are chosen using a pick list
///
//****************************************************************************
class CPickerData: public CConfigData {
public:
    CPickerData(USHORT *pusData, const T_CFG_DATA_TYPE eDATA_TYPE, const int iHELP_ID, const char* iDESC_ID,
            const bool bUPDATE_TREE_ON_CHANGE, const USHORT usMIN_NO_OF_SELECTIONS, const USHORT usMAX_NO_OF_SELECTIONS,
            const USHORT usINSTANCE_NO = 255);
    ~CPickerData(void);
    // Method that returns a pointer to the data
    void* GetData() const {
        return m_pusData;
    }
    // Method that sets up the data within the picker manager class so it is ready
    // for display
    void SetupPickerMgr(CPickerMgr &rkPickerMgr) const;
    // Method that updates the data class using the picker manager class data
    const QString UpdateData(CPickerMgr &rkPickerMgr);
    // Method that returns the data as a string
    const QString GetDataAsString(const bool bINCLUDE_UNITS = false);
private:
    /// Pointer to the data - this could be USHORT, Bitfield or WCHAR type data
    USHORT *m_pusData;
    /// Variable indicating the minimum number of selections the user can make
    const USHORT m_usMIN_NO_OF_SELECTIONS;
    /// Variable indicating the maximum number of selections the user can make
    const USHORT m_usMAX_NO_OF_SELECTIONS;
    /// The one based instance number of this picker item e.g. a pen number or
    /// analogue number - 0 implies none
    const USHORT m_usINSTANCE_NO;
    // Method that sets up the data required for a single pen picker
    void SetupSinglePenData(CPickerMgr &rkPickerMgr, const bool bINCLUDE_NONE_SELECTION = false) const;
    // Method that sets up the data required for a single pen alarm picker
    void SetupSinglePenAlarmData(CPickerMgr &rkPickerMgr) const;
    // Method that sets up the data required for a single pen latched alarm picker
    void SetupSinglePenLatchedAlarmData(CPickerMgr &rkPickerMgr) const;
    // Method that sets up the data required for a multiple pen picker
    void SetupMultiPenData(CPickerMgr &rkPickerMgr, const T_PEN_PICKER_TYPES ePICKER_TYPES) const;
    // Method that sets up the data required for a single alarm picker
    void SetupSingleAlarmData(CPickerMgr &rkPickerMgr) const;
    // Method that sets up the data required for a multiple alarm picker
    void SetupMultiAlarmData(CPickerMgr &rkPickerMgr) const;
    // Method that sets up the data required for a multiple latched alarm picker
    void SetupMultiLatchedAlarmData(CPickerMgr &rkPickerMgr) const;
    // Method that sets up the data required for a single analogue input picker
    void SetupSingleAnalogueInData(CPickerMgr &rkPickerMgr, const T_AIN_PICKER_TYPES eAIN_PICKER_TYPE) const;
    // Method that sets up the data required for a multiple analogue input picker
    void SetupMultiAnalogueInData(CPickerMgr &rkPickerMgr, const T_AIN_PICKER_TYPES eAIN_PICKER_TYPE) const;
    // Method that sets up the data required for a single/multiple digital input/output/pulse input picker
    void SetupDigData(CPickerMgr &rkPickerMgr, const T_DIGIO_TYPES eDIG_IO_TYPE) const;
    // Method that updates the data using the picker manager class data
    const QString UpdateSingleInstanceData(CPickerMgr &rkPickerMgr);
    // Method that updates the data using the picker manager class data
    const QString UpdateMultiInstanceData(CPickerMgr &rkPickerMgr);
    // Method that returns the number of instances of the configured data type
    // for this class
    const USHORT GetNumberOfInstances() const;
};
//**CByteData*********************************************************************
///
/// @brief Class containing information on BYTE config data items
///
/// Class containing information on BYTE config data items
///
//****************************************************************************
class CByteData: public CConfigData {
public:
    CByteData(BYTE *pbyDATA, const BYTE byLOWER, const BYTE byUPPER, const int iHELP_ID, const char* iDESC_ID,
            const bool bUPDATE_TREE_ON_CHANGE, const QString strUNITS = "",
            const bool bREQUIRES_RESTART = false);
    ~CByteData(void);
    // Method called to validate data entered by a user
    bool ValidateData(const QString pwcDATA);
    void UpdateData(const QString pwcDATA);
    // Method that returns a pointer to the data
    void* GetData() const {
        return m_pbyData;
    }
    // Method that returns the data as a string
    const QString GetDataAsString(const bool bINCLUDE_UNITS = false);
    // The maximum allowable length of the data as a string
    const USHORT GetDataLength() const {
        return 3;
    }
private:
    /// Pointer to the USHORT data
    BYTE *m_pbyData;
    /// the upper and lower limits required to validate a BYTE
    const BYTE m_byLOWER;
    const BYTE m_byUPPER;
};
/////////////////////////////////////////////////////////////////////////////
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.
#endif

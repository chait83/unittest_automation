/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Configuration System
/// @n Filename:  MultiPointCalData.cpp
/// @n Description: Implementation for the CMultiPointCalData class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  2 Stability Project 1.1 7/2/2011 4:58:57 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  1 Stability Project 1.0 7/2/2011 3:46:06 PM Hemant(HAIL) 
// 
// $
//
// **************************************************************************
#include "MultiPointCalData.h"
#include <QString>
#include "../inc/StringDefinitions.h"
#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
//****************************************************************************
// CMultiPointCalData (	T_PMPCALCHANNEL *ptMpCalData,
//				const USHORT usMAX_NO_OF_ELEMENTS )
///
/// Constructor
///
/// @param[in/out] 		T_PMPCALCHANNEL ptMpCalData - Pointer to the sensor calibration data we 
///						want to modify/view	
///
//****************************************************************************
CMultiPointCalData::CMultiPointCalData(T_PMPCALCHANNEL ptMpCalData, bool isTemperature) : CConfigData(dtMultiPointCal,
		0, 0, false), m_ptMpCalData(ptMpCalData) {
	m_bIsTemperature = isTemperature;
}
//****************************************************************************
// ~CMultiPointCalData( )
///
/// Destructor
///
//****************************************************************************
CMultiPointCalData::~CMultiPointCalData() {
}
//****************************************************************************
// const QString   GetDataAsString( const bool bINCLUDE_UNITS )
///
/// Method that returns the data as a string
///
/// @return		A string containing the data
///
//****************************************************************************
const QString CMultiPointCalData::GetDataAsString(const bool bINCLUDE_UNITS) {
	QString strTitle("");
	strTitle = QString::asprintf(IDS_CFG_LINEARISATION_NO_OF_POINTS_SUBTITLE, m_ptMpCalData->CalElements);
	return strTitle;
}
//****************************************************************************
///
/// Method called to validate data entered by the user
///
/// @param[in]		const T_PMPCALCHANNEL ptNEW_CAL_DATA - The new multi point cal data that we need
///					to validate
/// @param[out]		USHORT &rusFailedValueZeroBased - The value that has failed, zero based
///
/// @return		True if the data validated okay
///
//****************************************************************************
const bool CMultiPointCalData::ValidateData(const T_PMPCALCHANNEL ptNEW_CAL_DATA, USHORT &rusFailedValueZeroBased) {
	bool bOK = true;
	// check there are a minimum of 2 elements defined
	if (ptNEW_CAL_DATA->CalElements >= 2) {
		// run through the table checking for dog legs - firstly check which way we are
		// going
		bool bAscending = false;
		if (ptNEW_CAL_DATA->CalPoints[0].CalPoint < ptNEW_CAL_DATA->CalPoints[1].CalPoint) {
			// the X values are in ascending order
			bAscending = true;
		} else {
			// the X values are in descending order
			bAscending = false;
		}
		// loop through all the values checking if they are valid - don't check the first value as it can
		// only be checked against the next reading
		for (USHORT usCount = 1; usCount < ptNEW_CAL_DATA->CalElements; usCount++) {
			// check based on the ascending flag
			if (bAscending) {
				// the current must be greater than the previous
				if (ptNEW_CAL_DATA->CalPoints[usCount].CalPoint <= ptNEW_CAL_DATA->CalPoints[usCount - 1].CalPoint) {
					// the value is the same or going back on the previous therefore this is an error - set the
					// value that is in error and drop out of the loop
					rusFailedValueZeroBased = usCount;
					bOK = false;
					break;
				}
			} else {
				// the current must be less than the previous
				if (ptNEW_CAL_DATA->CalPoints[usCount].CalPoint >= ptNEW_CAL_DATA->CalPoints[usCount - 1].CalPoint) {
					// the value is the same or going back on the previous therefore this is an error - set the
					// value that is in error and drop out of the loop
					rusFailedValueZeroBased = usCount;
					bOK = false;
					break;
				}
			}
		}
	} else {
		// there are less than two elements defined therefore this is a failure - set the return value
		// to zero which will imply there are not enough elements (as the other checks cannot set values
		// of less than 1)
		rusFailedValueZeroBased = 0;
		bOK = false;
	}
	return bOK;
}

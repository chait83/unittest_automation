/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	Configuration
/// @n Filename: CommsSetupConfig.h
/// @n Desc:	Class to manage the configuration of the communications
///				block
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 14	Stability Project 1.11.1.1	7/2/2011 4:56:13 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 13	Stability Project 1.11.1.0	7/1/2011 4:28:17 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 12	V6 Firmware 1.11		8/31/2006 2:39:14 PM	Roger Dawson 
//		Added new method for logging on to the domain.
// 11	V6 Firmware 1.10		8/16/2006 4:10:23 PM	Andy Kassell	Add
//		suuport for variable sized e-mail blocks
// $
//
// ****************************************************************
#ifndef _COMMSSETUPCONFIG_H
#define _COMMSSETUPCONFIG_H
#include "SetupConfigService.h"
#include "V6Config.h"
#include "../../MbusMaster/hmserio.hpp"
#define DEFAULT_TIME_SERVER L"TimeServer"

struct CRED{
    WCHAR *dwVersion;
    WCHAR *dwType;
    WCHAR *wszTarget;
    int dwTargetLen;
    WCHAR *dwFlags;
    WCHAR *wszUser;
    int dwUserLen;
    WCHAR *pBlob;
    int dwBlobSize;
};
class CCommsSetupConfig: public CSetupConfigService {
	enum E_TLS_PROTOCOL_CONFIG_ID {
		TLS_V_1_0 = 0, TLS_V_1_1, TLS_V_1_2
	};
public:
	CCommsSetupConfig(void);
	virtual ~CCommsSetupConfig(void);
	T_CONFIG_RETURN_VALUE EnableDCOM(BOOL Enable);
	T_CONFIG_RETURN_VALUE CreateServiceDefaultConfig(void);
	T_CONFIG_VALIDATE_RETURN ValidateServiceConfig(void);
	T_CONFIG_RETURN_VALUE PostCommitProcessing(void);
	T_PCOMMUNICATIONS GetCommsBlock(REFERENCE cfgType);
	// Variable sized e-mail blocks
	T_CONFIG_RETURN_VALUE CreateEmailIfNotAvailable(USHORT emailNumber);
	WCHAR* GetEmailBlock(USHORT emailNumber, REFERENCE cfgType);
	CMMERROR ModifyEmailBlock(USHORT emailNumber, QString pNewBlock);
	// Method that returns a string containing the email addresses that relate to the 
	// passed in bitfield
	const QString GetEmailAddresses(const quint64 ulEMAIL_ADDRS_BITFIELD);
	// Method that stores the login information in order to provide automatic connection
	// to network resources
	const bool SetupLoginInfo();
	// Method that returns a string containing the recorders current IP address
	const QString GetIPAddress() const;
	//Enabling Protocols
	void UpdateTLSProtocolSettings(E_TLS_PROTOCOL_CONFIG_ID eTlsV, bool bEnable);
	//void UpdateTLSCofiguration(E_TLS_PROTOCOL_CONFIG_ID eTlsV, bool bEnable);
private:
	T_PCOMMUNICATIONS CreateDefaultCommsBlock();
};
// End of Class Declaration
#endif // _COMMSSETUPCONFIG_H

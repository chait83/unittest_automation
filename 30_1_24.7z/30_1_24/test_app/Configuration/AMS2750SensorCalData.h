/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 	 Configuration System
/// @n Filename:  AMS2750SensorCalData.h
/// @n Description: Declaration for the CAMS2750SensorCalData class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  3 Stability Project 1.0.1.1 7/2/2011 4:55:22 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  2 Stability Project 1.0.1.0 7/1/2011 4:28:09 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  1 V6 Firmware 1.0 9/23/2008 12:14:17 PM  Build Machine  
// $
//
// **************************************************************************
#if !defined(AFX_AMS2750SENSORCALDATA_H__512E2766_3AE7_4FDA_942F_A2764228AD7D__INCLUDED_)
#define AFX_AMS2750SENSORCALDATA_H__512E2766_3AE7_4FDA_942F_A2764228AD7D__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "ConfigData.h"
#include "V6Config.h"
//**CAMS2750SensorCalData*****************************************************
///
/// @brief Provides an interface to T_AMS2750SENSOR information for the data-driven menu's
/// 
/// Provides an interface to T_AMS2750SENSOR information for the data-driven menu's
///
//****************************************************************************
class CAMS2750SensorCalData: public CConfigData {
public:
	// Constructor
	CAMS2750SensorCalData(T_PAMS2750SENSOR ptSensor);
	// Destructor
	virtual ~CAMS2750SensorCalData();
	// Method called to validate data entered by a user - not used
	virtual bool ValidateData(const QString pwcDATA) {
		return true;
	}
	// Method called to validate data entered by the user
	static const bool ValidateData(const T_PAMS2750SENSOR ptSENSOR_DATA, USHORT &rusFailedValue);
	// Method that updates the data based on the passed in string - not used
	virtual void UpdateData(const QString pwcDATA) {
		;
	}
	// Method that returns the data as a string
	virtual const QString GetDataAsString(const bool bINCLUDE_UNITS = false);
	// Method that returns a pointer to the data
	virtual void* GetData() const {
		return m_ptAMS2750Sensor;
	}
private:
	/// Variable used to store a pointer to the sensor and thus calibration information
	T_PAMS2750SENSOR m_ptAMS2750Sensor;
};
#endif // !defined(AFX_LINEARISATIONDATA_H__512E2755_3AE7_4FDA_942F_A2764228AD7D__INCLUDED_)

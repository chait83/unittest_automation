/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	Configuration
/// @n Filename: GeneralSetupConfig.h
/// @n Desc:	Handles all general setup configuration services
///				
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 22	Stability Project 1.19.1.1	7/2/2011 4:57:25 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 21	Stability Project 1.19.1.0	7/1/2011 4:28:16 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 20	V6 Firmware 1.19		9/23/2008 3:09:24 PM	Build Machine 
//		AMS2750 Merge
// 19	V6 Firmware 1.18		3/7/2007 6:35:27 PM	Andy Kassell 
//		reset batch counter is any of the batch counter configuration changes
// $
//
// ****************************************************************
#ifndef _GENERALSETUPCONFIG_H
#define _GENERALSETUPCONFIG_H
#include "SetupConfigService.h"
#include "ConfigurationCommon.h"
#include "../inc/V6types.h"
#include "V6Config.h"
class CGeneralSetupConfig: public CSetupConfigService {
public:
	CGeneralSetupConfig(void);
	virtual ~CGeneralSetupConfig(void);
	T_CONFIG_RETURN_VALUE CreateServiceDefaultConfig(void);
	T_CONFIG_VALIDATE_RETURN ValidateServiceConfig(void);
	T_CONFIG_RETURN_VALUE PostCommitProcessing(void);
	T_CONFIG_RETURN_VALUE PreCommitProcessing(void);
	T_PGENERALCONFIG GetSystemGeneralBlock(REFERENCE cfgType);
	T_PDEVICECAPS GetDeviceCapsBlock(REFERENCE cfgType);
	T_PGENNONVOL GetGenNonVolBlock(REFERENCE cfgType);
	T_PRECPROFILE GetProfileBlock(REFERENCE cfgType);
	T_PCHANGEHEADER GetChangeHeaderBlock(REFERENCE cfgType);
	// Get the current furnace information configuration from the CMM
	T_PFURNACESCONFIG GetAMS2750FurnaceInfoBlock(REFERENCE cfgType);
	// Get the current AMS2750 calibration information configuration from the CMM
	T_PAMS2750CALCFG GetAMS2750CalibrationBlock(REFERENCE cfgType);
	void UpdateGenNonVolSystemFromCMM(T_PGENNONVOL pGenNV);
	// Method that determines if the printing function is allowed/enabled
	const bool PrintingIsAllowed();
	const void CheckForNetworkPrint();
	BOOL WasGeneralSetupModified() {
		return m_GeneralSetupModified;
	}
	;
	// Accessor method that returns true if changes have been made to the furnace configuration on
	// the last commit
	const bool FurnacesChanged() const {
		return m_baFurnaceChangeMade[0] || m_baFurnaceChangeMade[1] || m_baFurnaceChangeMade[2]
				|| m_baFurnaceChangeMade[3] || m_baFurnaceChangeMade[4] || m_baFurnaceChangeMade[5];
	}
	// Accessor method that returns true if changes have been made to a particualr furnace configuration on
	// the last commit
	const bool FurnaceChanged(const USHORT usGROUP_NO) const {
		return m_baFurnaceChangeMade[usGROUP_NO];
	}
	// Accessor method that returns true if any TUS related information has changed - awlays return true as there are too
	// many things that could affect the TUS, i.e. the sensors changing, the setpoints, the frunace etc
	const bool TUSInfoChanged() const {
		return true;/*m_baFurnaceChangeMade[ 0 ] || m_bSetpointChanged;*/
	}
private:
	T_PGENERALCONFIG CreateSystemGeneralBlock();
	T_PDEVICECAPS CreateDevCapsBlock();
	T_PGENNONVOL CreateGenNonVolBlock();
	T_PRECPROFILE CreateProfileBlock();
	T_PCHANGEHEADER CreateChangeHeaderBlock();
	// Create a default furnace information block
	T_PFURNACESCONFIG CreateAMS2750FurnaceInfoBlock();
	// Create a default AMS2750 calibration block
	T_PAMS2750CALCFG CreateAMS2750CalibrationBlock();
	void DefaultSystemGeneralBlock(T_PGENERALCONFIG pGeneral);
	// default a furnace information block
	void DefaultAMS2750FurnaceInfo(T_PFURNACESCONFIG pFurnaces);
	// default an AMS2750 calibration block
	void DefaultAMS2750CalibrationInfo(T_PAMS2750CALCFG pCalibration);
	void UpdateDevcapsCMMFromSystem(T_PDEVICECAPS pDevCaps);
	void UpdateDevcapsSystemFromCMM(T_PDEVICECAPS pDevCaps);
	void UpdateGenNonVolCMMFromSystem(T_PGENNONVOL pGenNV);
	void InitialiseForTV6DLL(T_PGENNONVOL pGenNV);
	// Function that returns the LCID code for the specified language
	const DWORD GetLCID(const T_LANGUAGES eLANGUAGE) const;
	BOOL m_GeneralSetupModified;
	/// Variable indicating if changes have been made to the furnace information following a commit
	bool m_baFurnaceChangeMade[FURNACESCONFIG_FURNACES_SIZE];
	/// Variable indicating if changes have been made to the furnace information following a commit
	bool m_bSetpointChanged;
};
// End of Class Declaration
#endif // _GENERALSETUPCONFIG_H

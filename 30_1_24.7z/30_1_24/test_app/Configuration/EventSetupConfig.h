/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	Configuration
/// @n Filename: EventSetupConfig.h
/// @n Desc:	Handles all event setup configuration 
///				
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 10	Stability Project 1.7.1.1	7/2/2011 4:57:09 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 9	Stability Project 1.7.1.0	7/1/2011 4:28:16 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 8	V6 Firmware 1.7		3/14/2007 2:13:18 PM	Roger Dawson 
//		Added code for creating, defaulting and retrieving the new report
//		structures.
// 7	V6 Firmware 1.6		1/3/2007 4:51:13 PM	Roger Dawson 
//		Added code to stop event sounds from being stopped due to default
//		error or replay mode error sounds being played while the event sound
//		is played.
// $
//
// ****************************************************************
#ifndef _EVENTSETUPCONFIG_H
#define _EVENTSETUPCONFIG_H
#include "SetupConfigService.h"
#include "ConfigurationCommon.h"
#include "V6Config.h"
class CEventSetupConfig: public CSetupConfigService {
public:
	CEventSetupConfig(void);
	virtual ~CEventSetupConfig(void);
	T_CONFIG_RETURN_VALUE CreateServiceDefaultConfig();
	// Function that is called immediately before a setup config is commited to the CMM. 
	T_CONFIG_RETURN_VALUE PreCommitProcessing(void);
	T_CONFIG_VALIDATE_RETURN ValidateServiceConfig();
	T_CONFIG_RETURN_VALUE PostCommitProcessing();
	void DefaultEventBlock(T_PEVENTSYSTEM pEventBlk);
	T_PEVENTSYSTEM GetEventBlock(REFERENCE cfgType);
	T_PEVENTSYSTEM CreateEventBlock();
	BOOL HasEventSystemBeenModified() {
		return m_EventConfigChanged;
	}
	;
	void DefaultCountersBlock(T_PCOUNTERS pCountersBlk);
	T_PCOUNTERS GetCountersBlock(REFERENCE cfgType);
	T_PCOUNTERS CreateCountersBlock();
	void DefaultReportsBlock(T_PREPORTS ptReportsBlk);
	T_PREPORTS GetReportsBlock(REFERENCE cfgType);
	T_PREPORTS CreateReportsBlock();
private:
	BOOL m_EventConfigChanged;
};
#endif // _EVENTSETUPCONFIG_H

/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O conditioning
/// @n Device.cpp
/// @n implementation for the Input Conditioning class.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
// 35	Stability Project 1.30.1.3	7/2/2011 4:56:44 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 34	Stability Project 1.30.1.2	7/1/2011 4:38:14 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 33	Stability Project 1.30.1.1	3/17/2011 3:20:21 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 32	Stability Project 1.30.1.0	2/15/2011 3:02:55 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////
#include "CMMDefines.h"
#include "V6Config.h"
#include "V6IOErrorCodes.H"
#include "TraceDefines.h"
#include "V6defines.h"
#include <math.h>
#include "LinearTable.h"
#include "Device.h"
#include "DeviceManager.h"
#include "TypeB.h"
#include "TypeC.h"
#include "TypeD.h"
#include "TypeE.h"
#include "TypeJ.h"
#include "TypeK.h"
#include "TypeL.h"
#include "TypeM.h"
#include "TypeN.h"
#include "TypeR.h"
#include "TCTypeS.h"
#include "TypeT.h"
#include "WW26.h"
#include "Chromel-Copel.h"
#include "NNMHi.h"
#include "Patinel.h"
#include "PT100.h"
#include "PT200.h"
#include "PT400.h"
#include "PT500.h"
#include "PT1000.h"
#include "PT2000.h"
#include "Ni100.h"
#include "NK120.h"
#include "CU10.h"
#include "CU53.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CDevice::CDevice() {
//	qDebug("Create new CDevice\n");
// Devive data and headers are not currently valid
	m_pSensorHdr = NULL;
	m_pCJHdr = NULL;
	m_DeviceCreated = FALSE;
	m_SensorValid = FALSE;
	m_CJValid = FALSE;
}
CDevice::~CDevice() {
//	qDebug("Delete CDevice class\n");
	if (m_DeviceCreated == TRUE)
		delete m_pSensorHdr;
	m_DeviceCreated = FALSE;
}
//******************************************************
///
/// Queries the device header details.
///
/// @return Pointer to a sensor table header.
/// 
//******************************************************
const T_PDEVICETABLEHDR CDevice::GetSensorDeviceHdr(void) const {
	return m_pSensorHdr;
}
//******************************************************
///
/// Queries the CJ device header details.
///
/// @return Pointer to a CJ device table header.
/// 
//******************************************************
const T_PDEVICETABLEHDR CDevice::GetCJDeviceHdr(void) const {
	return m_pCJHdr;
}
//******************************************************
///
/// Looks up the Sensor linearisation table.
/// @param[in] SensorIn - The device table I/P value.
/// @param[out] pSensorOut - The corresponding device table O/P value.
///
/// @return TRUE if lookup OK otherwise FALSE.
/// 
//******************************************************
BOOL CDevice::LookupSensorLimitTable(const float SensorIn, float *const pSensorOut) const {
	BOOL retValue = FALSE;
	// Check that I/P table exists and is within I/P range of table
	if ((m_pSensorHdr != NULL) && (m_SensorValid == TRUE)
			&& ((SensorIn >= m_pSensorHdr->IPRangeLow) && (SensorIn <= m_pSensorHdr->IPRangeHigh))) {
		*pSensorOut = m_Sensor.LookUpValue(SensorIn);
		retValue = TRUE;
	}
	return retValue;
}
//******************************************************
///
/// Looks up the Sensor linearisation table.
/// @param[in] SensorIn - The device table I/P value.
/// @param[out] pSensorOut - The corresponding device table O/P value.
///
/// @return TRUE if lookup OK otherwise FALSE.
/// 
//******************************************************
BOOL CDevice::LookupSensorTable(const float SensorIn, float *const pSensorOut) const {
	BOOL retValue = TRUE;
	*pSensorOut = m_Sensor.LookUpValue(SensorIn);
	return retValue;
}
//******************************************************
///
/// Looks up the CJ linearisation table.
/// @param[in] CJIn - The device table I/P value.
/// @param[out] pCJOut - The corresponding device table O/P value.
///
/// @return TRUE if lookup OK otherwise FALSE.
/// 
//******************************************************
BOOL CDevice::LookupCJTable(const float CJIn, float *const pCJOut) const {
	BOOL retValue = FALSE;
	// Check that I/P table exists and is within I/P range of table
	if ((m_pSensorHdr != NULL) && (m_CJValid == TRUE)
			&& ((CJIn >= m_pCJHdr->IPRangeLow) && (CJIn <= m_pCJHdr->IPRangeHigh))) {
		*pCJOut = m_CJ.LookUpValue(CJIn);
		retValue = TRUE;
	}
	return retValue;
}
//******************************************************
///
/// Marks whether a CJ linearisation table is used or not.
/// @param[in] Used - TRUE if the the sensor table if currently used
///
/// @return TRUE if lookup OK otherwise FALSE.
/// 
//******************************************************
BOOL CDevice::MarkCJTableUsed(const BOOL Used) {
	BOOL retValue = FALSE;
	if (m_CJValid == TRUE) {
		m_pCJHdr->Referenced = Used;
		retValue = TRUE;
	}
	return retValue;
}
//******************************************************
///
/// Marks whether a sensor linearisation table is used or not.
/// @param[in] Used - TRUE if the the sensor table if currently used
///
/// @return TRUE if lookup OK otherwise FALSE.
/// 
//******************************************************
BOOL CDevice::MarkSensorTableUsed(const BOOL Used) {
	BOOL retValue = FALSE;
	if (m_SensorValid == TRUE) {
		m_pSensorHdr->Referenced = Used;
		retValue = TRUE;
	}
	return retValue;
}
//******************************************************
///
/// Initialises the TC type B linearisation tables.
/// Creates the device lookup tables
///
/// @return TRUE if initialised OK otherwise FALSE.
/// 
//******************************************************
BOOL CDevice::InitialiseTypeBTC(void) {
	BOOL retValue = TRUE;
	T_TABLE_RETURN TableGenRet;
	m_DeviceCreated = FALSE;
	m_pCJHdr = &TypeBTempHdr;
	TypeBTempHdr.TableReadings = static_cast<USHORT>(sizeof(TypeBTemp) / sizeof(T_IP_TABLE_ELEMENT));
	TableGenRet = m_CJ.GenerateTable((T_PIP_TABLE_ELEMENT) &TypeBTemp, TypeBTempHdr.TableReadings,
			TypeBTempHdr.TableReadings, NORMAL_TABLE, TRUE);
	if (TableGenRet != TABLE_OK)
		retValue = FALSE;
	else
		m_CJValid = TRUE;
	m_pSensorHdr = &TypeBVoltageHdr;
	TypeBVoltageHdr.TableReadings = static_cast<USHORT>(sizeof(TypeBVoltage) / sizeof(T_IP_TABLE_ELEMENT));
	TableGenRet = m_Sensor.GenerateTable((T_PIP_TABLE_ELEMENT) &TypeBVoltage, TypeBVoltageHdr.TableReadings,
			TypeBVoltageHdr.TableReadings, NORMAL_TABLE);
	if (TableGenRet != TABLE_OK)
		retValue = FALSE;
	else
		m_SensorValid = TRUE;
	return retValue;
}
//******************************************************
///
/// Initialises the TC type D linearisation tables.
/// Creates the device lookup tables
///
/// @return TRUE if initialised OK otherwise FALSE.
/// 
//******************************************************
BOOL CDevice::InitialiseTypeDTC(void) {
	BOOL retValue = TRUE;
	T_TABLE_RETURN TableGenRet;
	m_DeviceCreated = FALSE;
	m_pCJHdr = &TypeDTempHdr;
	TypeDTempHdr.TableReadings = static_cast<USHORT>(sizeof(TypeDTemp) / sizeof(T_IP_TABLE_ELEMENT));
	TableGenRet = m_CJ.GenerateTable((T_PIP_TABLE_ELEMENT) &TypeDTemp, TypeDTempHdr.TableReadings,
			TypeDTempHdr.TableReadings, NORMAL_TABLE);
	if (TableGenRet != TABLE_OK)
		retValue = FALSE;
	else
		m_CJValid = TRUE;
	m_pSensorHdr = &TypeDVoltageHdr;
	TypeDVoltageHdr.TableReadings = static_cast<USHORT>(sizeof(TypeDVoltage) / sizeof(T_IP_TABLE_ELEMENT));
	TableGenRet = m_Sensor.GenerateTable((T_PIP_TABLE_ELEMENT) &TypeDVoltage, TypeDVoltageHdr.TableReadings,
			TypeDVoltageHdr.TableReadings, NORMAL_TABLE);
	if (TableGenRet != TABLE_OK)
		retValue = FALSE;
	else
		m_SensorValid = TRUE;
	return retValue;
}
//******************************************************
///
/// Initialises the TC type C linearisation tables.
/// Creates the device lookup tables
///
/// @return TRUE if initialised OK otherwise FALSE.
/// 
//******************************************************
BOOL CDevice::InitialiseTypeCTC(void) {
	BOOL retValue = TRUE;
	T_TABLE_RETURN TableGenRet;
	m_DeviceCreated = FALSE;
	m_pCJHdr = &TypeCTempHdr;
	TypeCTempHdr.TableReadings = static_cast<USHORT>(sizeof(TypeCTemp) / sizeof(T_IP_TABLE_ELEMENT));
	TableGenRet = m_CJ.GenerateTable((T_PIP_TABLE_ELEMENT) &TypeCTemp, TypeCTempHdr.TableReadings,
			TypeCTempHdr.TableReadings, NORMAL_TABLE);
	if (TableGenRet != TABLE_OK)
		retValue = FALSE;
	else
		m_CJValid = TRUE;
	m_pSensorHdr = &TypeCVoltageHdr;
	TypeCVoltageHdr.TableReadings = static_cast<USHORT>(sizeof(TypeCVoltage) / sizeof(T_IP_TABLE_ELEMENT));
	TableGenRet = m_Sensor.GenerateTable((T_PIP_TABLE_ELEMENT) &TypeCVoltage, TypeCVoltageHdr.TableReadings,
			TypeCVoltageHdr.TableReadings, NORMAL_TABLE);
	if (TableGenRet != TABLE_OK)
		retValue = FALSE;
	else
		m_SensorValid = TRUE;
	return retValue;
}
//******************************************************
///
/// Initialises the TC type E linearisation tables.
/// Creates the device lookup tables
///
/// @return TRUE if initialised OK otherwise FALSE.
/// 
//******************************************************
BOOL CDevice::InitialiseTypeETC(void) {
	BOOL retValue = TRUE;
	T_TABLE_RETURN TableGenRet;
	m_DeviceCreated = FALSE;
	m_pCJHdr = &TypeETempHdr;
	TypeETempHdr.TableReadings = static_cast<USHORT>(sizeof(TypeETemp) / sizeof(T_IP_TABLE_ELEMENT));
	TableGenRet = m_CJ.GenerateTable((T_PIP_TABLE_ELEMENT) &TypeETemp, TypeETempHdr.TableReadings,
			TypeETempHdr.TableReadings, NORMAL_TABLE);
	if (TableGenRet != TABLE_OK)
		retValue = FALSE;
	else
		m_CJValid = TRUE;
	m_pSensorHdr = &TypeEVoltageHdr;
	TypeEVoltageHdr.TableReadings = static_cast<USHORT>(sizeof(TypeEVoltage) / sizeof(T_IP_TABLE_ELEMENT));
	TableGenRet = m_Sensor.GenerateTable((T_PIP_TABLE_ELEMENT) &TypeEVoltage, TypeEVoltageHdr.TableReadings,
			TypeEVoltageHdr.TableReadings, NORMAL_TABLE);
	if (TableGenRet != TABLE_OK)
		retValue = FALSE;
	else
		m_SensorValid = TRUE;
	return retValue;
}
//******************************************************
///
/// Initialises the TC type J linearisation tables.
/// Creates the device lookup tables
///
/// @return TRUE if initialised OK otherwise FALSE.
/// 
//******************************************************
BOOL CDevice::InitialiseTypeJTC(void) {
	BOOL retValue = TRUE;
	T_TABLE_RETURN TableGenRet;
	m_DeviceCreated = FALSE;
	m_pCJHdr = &TypeJTempHdr;
	TypeJTempHdr.TableReadings = static_cast<USHORT>(sizeof(TypeJTemp) / sizeof(T_IP_TABLE_ELEMENT));
	TableGenRet = m_CJ.GenerateTable((T_PIP_TABLE_ELEMENT) &TypeJTemp, TypeJTempHdr.TableReadings,
			TypeJTempHdr.TableReadings, NORMAL_TABLE);
	if (TableGenRet != TABLE_OK)
		retValue = FALSE;
	else
		m_CJValid = TRUE;
	m_pSensorHdr = &TypeJVoltageHdr;
	TypeJVoltageHdr.TableReadings = static_cast<USHORT>(sizeof(TypeJVoltage) / sizeof(T_IP_TABLE_ELEMENT));
	TableGenRet = m_Sensor.GenerateTable((T_PIP_TABLE_ELEMENT) &TypeJVoltage, TypeJVoltageHdr.TableReadings,
			TypeJVoltageHdr.TableReadings, NORMAL_TABLE);
	if (TableGenRet != TABLE_OK)
		retValue = FALSE;
	else
		m_SensorValid = TRUE;
	return retValue;
}
//******************************************************
///
/// Initialises the TC type K linearisation tables.
/// Creates the device lookup tables
///
/// @return TRUE if initialised OK otherwise FALSE.
/// 
//******************************************************
BOOL CDevice::InitialiseTypeKTC(void) {
	BOOL retValue = TRUE;
	T_TABLE_RETURN TableGenRet;
#ifdef DBG_FILE_LOG_DEV_MGR_DBG_ENABLE
	QString  strLogMessage;
	strLogMessage = QString::asprintf("CDevice::InitialiseTypeKTC begin");
	CDeviceManager::LogDbgMessageToFile(strLogMessage);
	#endif
	m_DeviceCreated = FALSE;
	m_pCJHdr = &TypeKTempHdr;
	TypeKTempHdr.TableReadings = static_cast<USHORT>(sizeof(TypeKTemp) / sizeof(T_IP_TABLE_ELEMENT));
#ifdef DBG_FILE_LOG_DEV_MGR_DBG_ENABLE
	strLogMessage = QString::asprintf("CDevice::InitialiseTypeKTC m_CJ.GenerateTable TableReadings %d", TypeKTempHdr.TableReadings);
	CDeviceManager::LogDbgMessageToFile(strLogMessage);
	#endif
	TableGenRet = m_CJ.GenerateTable((T_PIP_TABLE_ELEMENT) &TypeKTemp, TypeKTempHdr.TableReadings,
			TypeKTempHdr.TableReadings, NORMAL_TABLE);
	if (TableGenRet != TABLE_OK)
		retValue = FALSE;
	else
		m_CJValid = TRUE;
	m_pSensorHdr = &TypeKVoltageHdr;
	TypeKVoltageHdr.TableReadings = static_cast<USHORT>(sizeof(TypeKVoltage) / sizeof(T_IP_TABLE_ELEMENT));
#ifdef DBG_FILE_LOG_DEV_MGR_DBG_ENABLE
	strLogMessage = QString::asprintf("CDevice::InitialiseTypeKTC m_Sensor.GenerateTable TableReadings %d", TypeKVoltageHdr.TableReadings);
	CDeviceManager::LogDbgMessageToFile(strLogMessage);
	#endif
	TableGenRet = m_Sensor.GenerateTable((T_PIP_TABLE_ELEMENT) &TypeKVoltage, TypeKVoltageHdr.TableReadings,
			TypeKVoltageHdr.TableReadings, NORMAL_TABLE);
	if (TableGenRet != TABLE_OK)
		retValue = FALSE;
	else
		m_SensorValid = TRUE;
#ifdef DBG_FILE_LOG_DEV_MGR_DBG_ENABLE
	strLogMessage = QString::asprintf("CDevice::InitialiseTypeKTC End m_CJValid %d m_SensorValid %d", m_CJValid, m_SensorValid);
	CDeviceManager::LogDbgMessageToFile(strLogMessage);
	#endif
	return retValue;
}
//******************************************************
///
/// Initialises the TC type L linearisation tables.
/// Creates the device lookup tables
///
/// @return TRUE if initialised OK otherwise FALSE.
/// 
//******************************************************
BOOL CDevice::InitialiseTypeLTC(void) {
	BOOL retValue = TRUE;
	T_TABLE_RETURN TableGenRet;
	m_DeviceCreated = FALSE;
	m_pCJHdr = &TypeLTempHdr;
	TypeLTempHdr.TableReadings = static_cast<USHORT>(sizeof(TypeLTemp) / sizeof(T_IP_TABLE_ELEMENT));
	TableGenRet = m_CJ.GenerateTable((T_PIP_TABLE_ELEMENT) &TypeLTemp, TypeLTempHdr.TableReadings,
			TypeLTempHdr.TableReadings, NORMAL_TABLE);
	if (TableGenRet != TABLE_OK)
		retValue = FALSE;
	else
		m_CJValid = TRUE;
	m_pSensorHdr = &TypeLVoltageHdr;
	TypeLVoltageHdr.TableReadings = static_cast<USHORT>(sizeof(TypeLVoltage) / sizeof(T_IP_TABLE_ELEMENT));
	TableGenRet = m_Sensor.GenerateTable((T_PIP_TABLE_ELEMENT) &TypeLVoltage, TypeLVoltageHdr.TableReadings,
			TypeLVoltageHdr.TableReadings, NORMAL_TABLE);
	if (TableGenRet != TABLE_OK)
		retValue = FALSE;
	else
		m_SensorValid = TRUE;
	return retValue;
}
//******************************************************
///
/// Initialises the TC type N linearisation tables.
/// Creates the device lookup tables
///
/// @return TRUE if initialised OK otherwise FALSE.
/// 
//******************************************************
BOOL CDevice::InitialiseTypeMTC(void) {
	BOOL retValue = TRUE;
	T_TABLE_RETURN TableGenRet;
	m_DeviceCreated = FALSE;
	m_pCJHdr = &TypeMTempHdr;
	TypeMTempHdr.TableReadings = static_cast<USHORT>(sizeof(TypeMTemp) / sizeof(T_IP_TABLE_ELEMENT));
	TableGenRet = m_CJ.GenerateTable((T_PIP_TABLE_ELEMENT) &TypeMTemp, TypeMTempHdr.TableReadings,
			TypeMTempHdr.TableReadings, NORMAL_TABLE);
	if (TableGenRet != TABLE_OK)
		retValue = FALSE;
	else
		m_CJValid = TRUE;
	m_pSensorHdr = &TypeMVoltageHdr;
	TypeMVoltageHdr.TableReadings = static_cast<USHORT>(sizeof(TypeMVoltage) / sizeof(T_IP_TABLE_ELEMENT));
	TableGenRet = m_Sensor.GenerateTable((T_PIP_TABLE_ELEMENT) &TypeMVoltage, TypeMVoltageHdr.TableReadings,
			TypeMVoltageHdr.TableReadings, NORMAL_TABLE);
	if (TableGenRet != TABLE_OK)
		retValue = FALSE;
	else
		m_SensorValid = TRUE;
	return retValue;
}
//******************************************************
///
/// Initialises the TC type N linearisation tables.
/// Creates the device lookup tables
///
/// @return TRUE if initialised OK otherwise FALSE.
/// 
//******************************************************
BOOL CDevice::InitialiseTypeNTC(void) {
	BOOL retValue = TRUE;
	T_TABLE_RETURN TableGenRet;
	m_DeviceCreated = FALSE;
	m_pCJHdr = &TypeNTempHdr;
	TypeNTempHdr.TableReadings = static_cast<USHORT>(sizeof(TypeNTemp) / sizeof(T_IP_TABLE_ELEMENT));
	TableGenRet = m_CJ.GenerateTable((T_PIP_TABLE_ELEMENT) &TypeNTemp, TypeNTempHdr.TableReadings,
			TypeNTempHdr.TableReadings, NORMAL_TABLE);
	if (TableGenRet != TABLE_OK)
		retValue = FALSE;
	else
		m_CJValid = TRUE;
	m_pSensorHdr = &TypeNVoltageHdr;
	TypeNVoltageHdr.TableReadings = static_cast<USHORT>(sizeof(TypeNVoltage) / sizeof(T_IP_TABLE_ELEMENT));
	TableGenRet = m_Sensor.GenerateTable((T_PIP_TABLE_ELEMENT) &TypeNVoltage, TypeNVoltageHdr.TableReadings,
			TypeNVoltageHdr.TableReadings, NORMAL_TABLE);
	if (TableGenRet != TABLE_OK)
		retValue = FALSE;
	else
		m_SensorValid = TRUE;
	return retValue;
}
//******************************************************
///
/// Initialises the TC type R linearisation tables.
/// Creates the device lookup tables
///
/// @return TRUE if initialised OK otherwise FALSE.
/// 
//******************************************************
BOOL CDevice::InitialiseTypeRTC(void) {
	BOOL retValue = TRUE;
	T_TABLE_RETURN TableGenRet;
	m_DeviceCreated = FALSE;
	m_pCJHdr = &TypeRTempHdr;
	TypeRTempHdr.TableReadings = static_cast<USHORT>(sizeof(TypeRTemp) / sizeof(T_IP_TABLE_ELEMENT));
	TableGenRet = m_CJ.GenerateTable((T_PIP_TABLE_ELEMENT) &TypeRTemp, TypeRTempHdr.TableReadings,
			TypeRTempHdr.TableReadings, NORMAL_TABLE);
	if (TableGenRet != TABLE_OK)
		retValue = FALSE;
	else
		m_CJValid = TRUE;
	m_pSensorHdr = &TypeRVoltageHdr;
	TypeRVoltageHdr.TableReadings = static_cast<USHORT>(sizeof(TypeRVoltage) / sizeof(T_IP_TABLE_ELEMENT));
	TableGenRet = m_Sensor.GenerateTable((T_PIP_TABLE_ELEMENT) &TypeRVoltage, TypeRVoltageHdr.TableReadings,
			TypeRVoltageHdr.TableReadings, NORMAL_TABLE);
	if (TableGenRet != TABLE_OK)
		retValue = FALSE;
	else
		m_SensorValid = TRUE;
	return retValue;
}
//******************************************************
///
/// Initialises the TC type S linearisation tables.
/// Creates the device lookup tables
///
/// @return TRUE if initialised OK otherwise FALSE.
/// 
//******************************************************
BOOL CDevice::InitialiseTypeSTC(void) {
	BOOL retValue = TRUE;
	T_TABLE_RETURN TableGenRet;
	m_DeviceCreated = FALSE;
	m_pCJHdr = &TypeSTempHdr;
	TypeSTempHdr.TableReadings = static_cast<USHORT>(sizeof(TypeSTemp) / sizeof(T_IP_TABLE_ELEMENT));
	TableGenRet = m_CJ.GenerateTable((T_PIP_TABLE_ELEMENT) &TypeSTemp, TypeSTempHdr.TableReadings,
			TypeSTempHdr.TableReadings, NORMAL_TABLE);
	if (TableGenRet != TABLE_OK)
		retValue = FALSE;
	else
		m_CJValid = TRUE;
	m_pSensorHdr = &TypeSVoltageHdr;
	TypeSVoltageHdr.TableReadings = static_cast<USHORT>(sizeof(TypeSVoltage) / sizeof(T_IP_TABLE_ELEMENT));
	TableGenRet = m_Sensor.GenerateTable((T_PIP_TABLE_ELEMENT) &TypeSVoltage, TypeSVoltageHdr.TableReadings,
			TypeSVoltageHdr.TableReadings, NORMAL_TABLE);
	if (TableGenRet != TABLE_OK)
		retValue = FALSE;
	else
		m_SensorValid = TRUE;
	return retValue;
}
//******************************************************
///
/// Initialises the TC type T linearisation tables.
/// Creates the device lookup tables
///
/// @return TRUE if initialised OK otherwise FALSE.
/// 
//******************************************************
BOOL CDevice::InitialiseTypeTTC(void) {
	BOOL retValue = TRUE;
	T_TABLE_RETURN TableGenRet;
	m_DeviceCreated = FALSE;
	m_pCJHdr = &TypeTTempHdr;
	TypeTTempHdr.TableReadings = static_cast<USHORT>(sizeof(TypeTTemp) / sizeof(T_IP_TABLE_ELEMENT));
	TableGenRet = m_CJ.GenerateTable((T_PIP_TABLE_ELEMENT) &TypeTTemp, TypeTTempHdr.TableReadings,
			TypeTTempHdr.TableReadings, NORMAL_TABLE);
	if (TableGenRet != TABLE_OK)
		retValue = FALSE;
	else
		m_CJValid = TRUE;
	m_pSensorHdr = &TypeTVoltageHdr;
	TypeTVoltageHdr.TableReadings = static_cast<USHORT>(sizeof(TypeTVoltage) / sizeof(T_IP_TABLE_ELEMENT));
	TableGenRet = m_Sensor.GenerateTable((T_PIP_TABLE_ELEMENT) &TypeTVoltage, TypeTVoltageHdr.TableReadings,
			TypeTVoltageHdr.TableReadings, NORMAL_TABLE);
	if (TableGenRet != TABLE_OK)
		retValue = FALSE;
	else
		m_SensorValid = TRUE;
	return retValue;
}
//******************************************************
///
/// Initialises the Chromel-Copel TC type linearisation tables.
/// Creates the device lookup tables
///
/// @return TRUE if initialised OK otherwise FALSE.
/// 
//******************************************************
BOOL CDevice::InitialiseChromelCopel(void) {
	BOOL retValue = TRUE;
	T_TABLE_RETURN TableGenRet;
	m_DeviceCreated = FALSE;
	m_pCJHdr = &ChromelCopelTempHdr;
	ChromelCopelTempHdr.TableReadings = static_cast<USHORT>(sizeof(ChromelCopelTemp) / sizeof(T_IP_TABLE_ELEMENT));
	TableGenRet = m_CJ.GenerateTable((T_PIP_TABLE_ELEMENT) &ChromelCopelTemp, ChromelCopelTempHdr.TableReadings,
			ChromelCopelTempHdr.TableReadings, NORMAL_TABLE);
	if (TableGenRet != TABLE_OK)
		retValue = FALSE;
	else
		m_CJValid = TRUE;
	m_pSensorHdr = &ChromelCopelVoltageHdr;
	ChromelCopelVoltageHdr.TableReadings =
			static_cast<USHORT>(sizeof(ChromelCopelVoltage) / sizeof(T_IP_TABLE_ELEMENT));
	TableGenRet = m_Sensor.GenerateTable((T_PIP_TABLE_ELEMENT) &ChromelCopelVoltage,
			ChromelCopelVoltageHdr.TableReadings, ChromelCopelVoltageHdr.TableReadings, NORMAL_TABLE);
	if (TableGenRet != TABLE_OK)
		retValue = FALSE;
	else
		m_SensorValid = TRUE;
	return retValue;
}
//******************************************************
///
/// Initialises the Platinel TC type linearisation tables.
/// Creates the device lookup tables
///
/// @return TRUE if initialised OK otherwise FALSE.
/// 
//******************************************************
BOOL CDevice::InitialisePlatinel(void) {
	BOOL retValue = TRUE;
	T_TABLE_RETURN TableGenRet;
	m_DeviceCreated = FALSE;
	m_pCJHdr = &PlatinelTempHdr;
	PlatinelTempHdr.TableReadings = static_cast<USHORT>(sizeof(PlatinelTemp) / sizeof(T_IP_TABLE_ELEMENT));
	TableGenRet = m_CJ.GenerateTable((T_PIP_TABLE_ELEMENT) &PlatinelTemp, PlatinelTempHdr.TableReadings,
			PlatinelTempHdr.TableReadings, NORMAL_TABLE);
	if (TableGenRet != TABLE_OK)
		retValue = FALSE;
	else
		m_CJValid = TRUE;
	m_pSensorHdr = &PlatinelVoltageHdr;
	PlatinelVoltageHdr.TableReadings = static_cast<USHORT>(sizeof(PlatinelVoltage) / sizeof(T_IP_TABLE_ELEMENT));
	TableGenRet = m_Sensor.GenerateTable((T_PIP_TABLE_ELEMENT) &PlatinelVoltage, PlatinelVoltageHdr.TableReadings,
			PlatinelVoltageHdr.TableReadings, NORMAL_TABLE);
	if (TableGenRet != TABLE_OK)
		retValue = FALSE;
	else
		m_SensorValid = TRUE;
	return retValue;
}
//******************************************************
///
/// Initialises the TC type WW26 (G) linearisation tables.
/// Creates the device lookup tables
///
/// @return TRUE if initialised OK otherwise FALSE.
/// 
//******************************************************
BOOL CDevice::InitialiseTypeGTC(void) {
	BOOL retValue = TRUE;
	T_TABLE_RETURN TableGenRet;
	m_DeviceCreated = FALSE;
	m_pCJHdr = &WW26TempHdr;
	WW26TempHdr.TableReadings = static_cast<USHORT>(sizeof(WW26Temp) / sizeof(T_IP_TABLE_ELEMENT));
	TableGenRet = m_CJ.GenerateTable((T_PIP_TABLE_ELEMENT) &WW26Temp, WW26TempHdr.TableReadings,
			WW26TempHdr.TableReadings, NORMAL_TABLE);
	if (TableGenRet != TABLE_OK)
		retValue = FALSE;
	else
		m_CJValid = TRUE;
	m_pSensorHdr = &WW26VoltageHdr;
	WW26VoltageHdr.TableReadings = static_cast<USHORT>(sizeof(WW26Voltage) / sizeof(T_IP_TABLE_ELEMENT));
	TableGenRet = m_Sensor.GenerateTable((T_PIP_TABLE_ELEMENT) &WW26Voltage, WW26VoltageHdr.TableReadings,
			WW26VoltageHdr.TableReadings, NORMAL_TABLE);
	if (TableGenRet != TABLE_OK)
		retValue = FALSE;
	else
		m_SensorValid = TRUE;
	return retValue;
}
//******************************************************
///
/// Initialises a user defined linearisation table.
/// Creates a user defined device lookup tables
///
/// @param[in] tableNo - The number of the user table.
/// @param[in] pTableHdr - The header for the user table.
/// @param[in] pSensorData - The data elements for the user table.
/// @param[in] noOfElements - The number of elements in the user table.
///
/// @return TRUE if initialised OK otherwise FALSE.
/// 
//******************************************************
BOOL CDevice::InitialiseUserTable(const USHORT tableNo, T_PDEVICETABLEHDR pTableHdr, T_LTELEMENT *pSensorData,
		const USHORT noOfElements) {
	BOOL retValue = TRUE;
	T_TABLE_RETURN TableGenRet;
	// Create the linearisation table header
	m_pSensorHdr = pTableHdr;
	m_DeviceCreated = FALSE;
	TableGenRet = m_Sensor.GenerateUserTableHdr(m_pSensorHdr, (T_PIP_TABLE_ELEMENT) pSensorData, tableNo, noOfElements);
	// Create the linearisation table
	if (TableGenRet == TABLE_OK) {
		TableGenRet = m_Sensor.GenerateTable((T_PIP_TABLE_ELEMENT) pSensorData, m_pSensorHdr->TableReadings,
				m_pSensorHdr->TableReadings, NORMAL_TABLE);
	}
	if (TableGenRet != TABLE_OK) {
		/// Cleanup if table is invalid
		delete m_pSensorHdr;
		m_pSensorHdr = NULL;
		retValue = FALSE;
	} else
		m_SensorValid = TRUE;
	return retValue;
}
//******************************************************
///
/// Queries whether a user defined linearisation table is initialised.
///
/// @return TRUE if initialised OK otherwise FALSE.
/// 
//******************************************************
BOOL CDevice::QueryUserTableVaild() const {
	return m_SensorValid;
}
//******************************************************
///
/// Initialises the PT100 RT linearisation tables.
/// Creates the device lookup tables
///
/// @return TRUE if initialised OK otherwise FALSE.
/// 
//******************************************************
BOOL CDevice::InitialisePT100RT(void) {
	BOOL retValue = TRUE;
	T_TABLE_RETURN TableGenRet;
	m_DeviceCreated = FALSE;
	m_pSensorHdr = &PT100Hdr;
	PT100Hdr.TableReadings = static_cast<USHORT>(sizeof(PT100Measurement) / sizeof(T_IP_TABLE_ELEMENT));
	TableGenRet = m_Sensor.GenerateTable((T_PIP_TABLE_ELEMENT) &PT100Measurement, PT100Hdr.TableReadings,
			PT100Hdr.TableReadings, NORMAL_TABLE);
	if (TableGenRet != TABLE_OK)
		retValue = FALSE;
	else
		m_SensorValid = TRUE;
	return retValue;
}
//******************************************************
///
/// Initialises the PT200 RT linearisation tables.
/// Creates the device lookup tables
///
/// @return TRUE if initialised OK otherwise FALSE.
/// 
//******************************************************
BOOL CDevice::InitialisePT200RT(void) {
	BOOL retValue = TRUE;
	T_TABLE_RETURN TableGenRet;
	m_DeviceCreated = FALSE;
	m_pSensorHdr = &PT200Hdr;
	PT200Hdr.TableReadings = static_cast<USHORT>(sizeof(PT200Measurement) / sizeof(T_IP_TABLE_ELEMENT));
	TableGenRet = m_Sensor.GenerateTable((T_PIP_TABLE_ELEMENT) &PT200Measurement, PT200Hdr.TableReadings,
			PT200Hdr.TableReadings, NORMAL_TABLE);
	if (TableGenRet != TABLE_OK)
		retValue = FALSE;
	else
		m_SensorValid = TRUE;
	return retValue;
}
//******************************************************
///
/// Initialises the PT400 RT linearisation tables.
/// Creates the device lookup tables
///
/// @return TRUE if initialised OK otherwise FALSE.
/// 
//******************************************************
BOOL CDevice::InitialisePT400RT(void) {
	BOOL retValue = TRUE;
	T_TABLE_RETURN TableGenRet;
	m_DeviceCreated = FALSE;
	m_pSensorHdr = &PT400Hdr;
	PT400Hdr.TableReadings = static_cast<USHORT>(sizeof(PT400Measurement) / sizeof(T_IP_TABLE_ELEMENT));
	TableGenRet = m_Sensor.GenerateTable((T_PIP_TABLE_ELEMENT) &PT400Measurement, PT400Hdr.TableReadings,
			PT400Hdr.TableReadings, NORMAL_TABLE);
	if (TableGenRet != TABLE_OK)
		retValue = FALSE;
	else
		m_SensorValid = TRUE;
	return retValue;
}
//******************************************************
///
/// Initialises the PT500 RT linearisation tables.
/// Creates the device lookup tables
///
/// @return TRUE if initialised OK otherwise FALSE.
/// 
//******************************************************
BOOL CDevice::InitialisePT500RT(void) {
	BOOL retValue = TRUE;
	T_TABLE_RETURN TableGenRet;
	m_DeviceCreated = FALSE;
	m_pSensorHdr = &PT500Hdr;
	PT500Hdr.TableReadings = static_cast<USHORT>(sizeof(PT500Measurement) / sizeof(T_IP_TABLE_ELEMENT));
	TableGenRet = m_Sensor.GenerateTable((T_PIP_TABLE_ELEMENT) &PT500Measurement, PT500Hdr.TableReadings,
			PT500Hdr.TableReadings, NORMAL_TABLE);
	if (TableGenRet != TABLE_OK)
		retValue = FALSE;
	else
		m_SensorValid = TRUE;
	return retValue;
}
//******************************************************
///
/// Initialises the PT1000 RT linearisation tables.
/// Creates the device lookup tables
///
/// @return TRUE if initialised OK otherwise FALSE.
/// 
//******************************************************
BOOL CDevice::InitialisePT1000RT(void) {
	BOOL retValue = TRUE;
	T_TABLE_RETURN TableGenRet;
	m_DeviceCreated = FALSE;
	m_pSensorHdr = &PT1000Hdr;
	PT1000Hdr.TableReadings = static_cast<USHORT>(sizeof(PT1000Measurement) / sizeof(T_IP_TABLE_ELEMENT));
	TableGenRet = m_Sensor.GenerateTable((T_PIP_TABLE_ELEMENT) &PT1000Measurement, PT1000Hdr.TableReadings,
			PT1000Hdr.TableReadings, NORMAL_TABLE);
	if (TableGenRet != TABLE_OK)
		retValue = FALSE;
	else
		m_SensorValid = TRUE;
	return retValue;
}
//******************************************************
///
/// Initialises the PT2000 RT linearisation tables.
/// Creates the device lookup tables
///
/// @return TRUE if initialised OK otherwise FALSE.
/// 
//******************************************************
BOOL CDevice::InitialisePT2000RT(void) {
	BOOL retValue = TRUE;
	T_TABLE_RETURN TableGenRet;
	m_DeviceCreated = FALSE;
	m_pSensorHdr = &PT2000Hdr;
	PT2000Hdr.TableReadings = static_cast<USHORT>(sizeof(PT2000Measurement) / sizeof(T_IP_TABLE_ELEMENT));
	TableGenRet = m_Sensor.GenerateTable((T_PIP_TABLE_ELEMENT) &PT2000Measurement, PT2000Hdr.TableReadings,
			PT2000Hdr.TableReadings, NORMAL_TABLE);
	if (TableGenRet != TABLE_OK)
		retValue = FALSE;
	else
		m_SensorValid = TRUE;
	return retValue;
}
//******************************************************
///
/// Initialises the NK120 RT linearisation tables.
/// Creates the device lookup tables
///
/// @return TRUE if initialised OK otherwise FALSE.
/// 
//******************************************************
BOOL CDevice::InitialiseNK120RT(void) {
	BOOL retValue = TRUE;
	T_TABLE_RETURN TableGenRet;
	m_DeviceCreated = FALSE;
	m_pSensorHdr = &NK120Hdr;
	NK120Hdr.TableReadings = static_cast<USHORT>(sizeof(NK120Measurement) / sizeof(T_IP_TABLE_ELEMENT));
	TableGenRet = m_Sensor.GenerateTable((T_PIP_TABLE_ELEMENT) &NK120Measurement, NK120Hdr.TableReadings,
			NK120Hdr.TableReadings, NORMAL_TABLE);
	if (TableGenRet != TABLE_OK)
		retValue = FALSE;
	else
		m_SensorValid = TRUE;
	return retValue;
}
//******************************************************
///
/// Initialises the Ni100 RT linearisation tables.
/// Creates the device lookup tables
///
/// @return TRUE if initialised OK otherwise FALSE.
/// 
//******************************************************
BOOL CDevice::InitialiseNi100RT(void) {
	BOOL retValue = TRUE;
	T_TABLE_RETURN TableGenRet;
	m_DeviceCreated = FALSE;
	m_pSensorHdr = &Ni100Hdr;
	Ni100Hdr.TableReadings = static_cast<USHORT>(sizeof(Ni100Measurement) / sizeof(T_IP_TABLE_ELEMENT));
	TableGenRet = m_Sensor.GenerateTable((T_PIP_TABLE_ELEMENT) &Ni100Measurement, Ni100Hdr.TableReadings,
			Ni100Hdr.TableReadings, NORMAL_TABLE);
	if (TableGenRet != TABLE_OK)
		retValue = FALSE;
	else
		m_SensorValid = TRUE;
	return retValue;
}
//******************************************************
///
/// Initialises the e 

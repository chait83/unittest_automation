/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	I/O Scheduler
/// @n Filename: CU10.h
/// @n Desc:	Constant data for the CU10 RT
///
// 
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 3	Stability Project 1.0.1.1	7/2/2011 4:56:26 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 2	Stability Project 1.0.1.0	7/1/2011 4:27:21 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 1	V6 Firmware 1.0		3/1/2005 7:46:30 PM	Graham Waterfield 
// $
//
//////////////////////////////////////////////////////////////////////
#ifndef _CU10_H
#define _CU10_H
#if !defined(AFX_CU10_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_)
#define AFX_CU10_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "LinearTable.h"
const T_IP_TABLE_ELEMENT CU10Measurement[] = {
		// resistance,	TempC
		1.058F, -200, 1.472F, -190, 1.884F, -180, 2.295F, -170, 2.705F, -160, 3.113F, -150, 3.519F, -140, 3.923F, -130,
		4.327F, -120, 4.728F, -110, 5.128F, -100, 5.526F, -90, 5.923F, -80, 6.318F, -70, 6.712F, -60, 7.104F, -50,
		7.490F, -40, 7.876F, -30, 8.263F, -20, 8.649F, -10, 9.035F, 0, 9.421F, 10, 9.807F, 20, 10.194F, 30, 10.580F, 40,
		10.966F, 50, 11.352F, 60, 11.738F, 70, 12.124F, 80, 12.511F, 90, 12.897F, 100, 13.283F, 110, 13.669F, 120,
		14.055F, 130, 14.442F, 140, 14.828F, 150, 15.217F, 160, 15.607F, 170, 15.996F, 180, 16.386F, 190, 16.776F, 200,
		17.166F, 210, 17.555F, 220, 17.945F, 230, 18.335F, 240, 18.726F, 250, 19.116F, 260 };
#endif // !defined(AFX_CU10_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_)
#endif		// _CU10_H

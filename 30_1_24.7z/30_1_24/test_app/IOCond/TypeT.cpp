/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O conditioning
/// @n TypeJ.cpp
/// @n implementation for the Type J TC.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log:
// 13	Stability Project 1.8.1.3	7/2/2011 5:02:17 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 12	Stability Project 1.8.1.2	7/1/2011 4:39:05 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 11	Stability Project 1.8.1.1	3/17/2011 3:20:53 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 10	Stability Project 1.8.1.0	2/15/2011 3:04:08 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// 9	V6 Firmware 1.8		8/22/2006 3:19:05 PM	Graham Waterfield
//		Back out changes to hard code 0.01mV offset
// 8	V6 Firmware 1.7		7/31/2006 8:31:07 PM	Graham Waterfield
//		Allowed a 0.01mV over and under range to ensure T/C can acheive upper
//		limits with factory calibration
// 7	V6 Firmware 1.6		11/14/2005 7:36:26 PM Graham Waterfield
//		Correct comments
// 6	V6 Firmware 1.5		9/7/2005 1:10:13 PM	Graham Waterfield
//		Removed duplicate temperature conversion units
// 5	V6 Firmware 1.4		4/22/2005 2:13:15 PM	Graham Waterfield
//		Removed linear channel subtype
// 4	V6 Firmware 1.3		4/20/2005 3:46:58 PM	Graham Waterfield
//		Add AO calibration data
// 3	V6 Firmware 1.2		3/2/2005 4:18:56 PM	Graham Waterfield
//		Updated to include new linerisation table stuff
// 2	V6 Firmware 1.1		3/1/2005 3:31:25 PM	Graham Waterfield
//		Staged check-in to allow release of project file
// 1	V6 Firmware 1.0		2/25/2005 8:57:06 PM	Graham Waterfield 
// $
//
//////////////////////////////////////////////////////////////////////
#include "CMMDefines.h"
#include "V6Config.h"
#include "V6IOErrorCodes.H"
#include "TraceDefines.h"
#include "V6defines.h"
#include <math.h>
#include "LinearTable.h"
#include "Device.h"
#include "TypeT.h"
#ifndef __cplusplus
#define __cplusplus
#endif
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
T_DEVICETABLEHDR TypeTVoltageHdr = { -6.258F,	///< Minimum table I/P value mV
		20.872F,								///< Maximum table I/P value mV
		-270,							///< Minimum table O/P value degrees C
		400,							///< Maximum table O/P value degrees C
		12,									///< The unique device identity ID
		12,											///< The device name
		0,	///< Number of readings to follow, must be set during initialisation
		FALSE,				///< This device table cannot be used as a CJ lookup
		FALSE,							///< This device table is not referenced
		AI_THERMO_RANGE_T,							///< Type of device
		AI_CHANNEL_TYPE_LINEAR_VOLTS,	///< I/P channel type (ohms, volts etc.)
		MILLI,				///< What units the I/P table units in (m, u, n, p)
		0,											///< N/A
		LINEAR_CHANNEL_TYPE_TEMP,		///< O/P channel type (ohms, volts etc.)
		UNITS,				///< What units the O/P table units in (m, u, n, p)
		TEMP_DEG_C									///< Degrees C
		// Pointer to start of table
		};
T_DEVICETABLEHDR TypeTTempHdr = { -270,	///< Minimum table I/P value degrees C
		400,							///< Maximum table I/P value degrees C
		-6.258F,								///< Minimum table O/P value mV
		20.872F,								///< Maximum table O/P value mV
		12,									///< The unique device identity ID
		12,											///< The device name
		0,	///< Number of readings to follow, must be set during initialisation
		TRUE,				///< This device table can be used as a CJ lookup
		FALSE,							///< This device table is not referenced
		AI_THERMO_RANGE_T,							///< Type of device
		LINEAR_CHANNEL_TYPE_TEMP,		///< I/P channel type (ohms, volts etc.)
		UNITS,				///< What units the I/P table units in (m, u, n, p)
		TEMP_DEG_C,									///< Degrees C
		AI_CHANNEL_TYPE_LINEAR_VOLTS,	///< O/P channel type (ohms, volts etc.)
		MILLI,				///< What units the O/P table units in (m, u, n, p)
		0											///< N/A
		// Pointer to start of table
		};

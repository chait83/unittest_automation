/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	I/O Scheduler
/// @n Filename: PT2000.h
/// @n Desc:	Constant data for the PT2000 RT
///
// 
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 3	Stability Project 1.0.1.1	7/2/2011 4:59:59 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 2	Stability Project 1.0.1.0	7/1/2011 4:27:23 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 1	V6 Firmware 1.0		3/9/2005 8:15:28 PM	Graham Waterfield 
// $
//
//////////////////////////////////////////////////////////////////////
#ifndef _PT2000_H
#define _PT2000_H
#if !defined(AFX_PT2000_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_)
#define AFX_PT2000_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
const T_IP_TABLE_ELEMENT PT2000Measurement[] = {
		// resistance,	TempC
		369.796F, -200, 455.996F, -190, 541.496F, -180, 626.34F, -170, 710.57F, -160, 794.22F, -150, 877.332F, -140,
		959.94F, -130, 1042.074F, -120, 1123.768F, -110, 1205.048F, -100, 1285.942F, -90, 1366.476F, -80, 1446.67F, -70,
		1526.544F, -60, 1606.12F, -50, 1685.412F, -40, 1764.456F, -30, 1843.2F, -20, 1921.72F, -10, 2000, 0, 2078.048F,
		10, 2155.862F, 20, 2233.446F, 30, 2310.796F, 40, 2387.914F, 50, 2464.802F, 60, 2541.456F, 70, 2617.878F, 80,
		2694.068F, 90, 2770.026F, 100, 2845.75F, 110, 2921.244F, 120, 2996.504F, 130, 3071.534F, 140, 3146.33F, 150,
		3220.896F, 160, 3295.228F, 170, 3369.328F, 180, 3443.196F, 190, 3516.832F, 200, 3590.234F, 210, 3663.406F, 220,
		3736.346F, 230, 3809.052F, 240, 3881.528F, 250, 3953.77F, 260, 4025.78F, 270, 4097.558F, 280, 4169.104F, 290 };
#endif // !defined(AFX_PT2000_H__BD564303_86C1_4F44_93ED_08C15F4B2740__INCLUDED_)
#endif		// _PT2000_H

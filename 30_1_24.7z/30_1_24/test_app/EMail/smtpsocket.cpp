/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Email system
/// @n Filename:  SMTPSocket.cpp
/// @n Description: Implementation of the CSMTPSocket class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  30  Aristos  1.22.1.5.1.0 9/19/2011 4:51:17 PM  Hemant(HAIL)  
//  Stability recorder source code (JI Release) updated for WatchDog
//  Timer functionality.
//  29  Stability Project 1.22.1.5 7/11/2011 4:15:49 PM  Hemant(HAIL) 
// Files updated when fixing the Email Memory Leak Issue.
//  28  Stability Project 1.22.1.4 7/2/2011 5:01:28 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  27  Stability Project 1.22.1.3 7/1/2011 4:38:56 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
// $
//
// **************************************************************************
#include "smtpsocket.h"
#include <wchar.h>
#include "Base64.h"
#include "StringUtils.h"
#include "Crypto.h"
#include "V6globals.h"
#include "ThreadInfo.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
/// Static Initialisation
const DWORD CSMTPSocket::ms_dwGENERIC_SMTP_ERROR = 0xFFFF;
//****************************************************************************
// CSMTPSocket( )
///
/// Constructor
///
//****************************************************************************
CSMTPSocket::CSMTPSocket(ESocketTransMode eSTMode) : CV7SecureSocket(eSTMode), m_eCommsState(
		CSMTPSocket::cstNOT_CONNECTED), m_dwLastError(0), m_bFinishedSendingLastEmail(true), m_ulMAX_ATTEMPTS(1), m_ulCurrAttemptNo(
		0), m_bRequiresAuth(false), m_bstartTLSsupport(false), m_iCurrRecipientNo(0), m_bReconnectSocket(false), m_bSendReceiveOpInProgress(
		false), m_bAbortCurrOp(false), m_bWaitingForQuitReply(false), m_bSendData(false)	// Stability Project Fix
{
}
//****************************************************************************
// ~CSMTPSocket( )
///
/// Destructor
///
//****************************************************************************
CSMTPSocket::~CSMTPSocket() {
	// now ensure we are not in the middle of a send or receive operation
	const int ABORT_TIMEOUT_IN_SECS = 300;
	int currWaitDurationInSecs = 0;
	const int ONE_SEC_WAIT_PERIOD = 1000;
	// ensure any current operations in the OnRecieve method are aborted
	m_bAbortCurrOp = true;
	// wait until the operation completes or the timeout is reached
	while (SendReceiveOpInProgress()) {
		// check if our timeout has been exceeded
		if (currWaitDurationInSecs >= ABORT_TIMEOUT_IN_SECS) {
			// if this timeout has been reached then we are seemingly stuck in the send/receive
			// method - we have no choice but to try and delete the socket anyway or email
			// can never work again - log a diagnostic message to record the fact this has
			// happened
			QString strError("");
			strError = QString::asprintf("Email error - the receive event hasn't completed. Socket deleted.");
			LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
			LOG_SMTP_MESSAGE(MSGLISTSER_SMTP_CLIENT_ERROR, strError);
			//HAIL addition
			//[
			Disconnect();
			CloseConnection();
			//]
			break;
		} else {
			// the timout hasn't been reached yet so just increment the timer
			sleep(ONE_SEC_WAIT_PERIOD);
			currWaitDurationInSecs++;
		}
	}
}
// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CSMTPSocket, CAsyncSocket)
	//{{AFX_MSG_MAP(CSMTPSocket)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0
//****************************************************************************
// const bool ConnectToServer( const QString  &rstrSERVER_NAME, const UINT uiPORT_NO )
///
/// Method that initiates connection with an SMTP Server
///
/// @param[in]		const QString  &rstrSERVER_NAME - The name of the server we wish to connect to
/// @param[in]		const UINT uiPORT_NO - The port number we wish to connect to
///
/// @return			False if we have attempted to many failed connection attempts
///
//****************************************************************************
const bool CSMTPSocket::ConnectToServer(const QString &rstrSERVER_NAME, const UINT uiPORT_NO) {
	// reset the abort flag in the event it is set
	m_bAbortCurrOp = false;
	// attempt to retry connecting
	if (m_ulCurrAttemptNo < m_ulMAX_ATTEMPTS) {
		++m_ulCurrAttemptNo;
		// log an approriate message letting the user know we are trying to connect
		if (m_ulCurrAttemptNo <= 1) {
			QString strConnection(L"Attempting to connect....");
			LOG_SMTP_MESSAGE(MSGLISTSER_SMTP_CLIENT_INFO, strConnection);
		} else {
			QString strPrevError("");
			strPrevError = QString::asprintf("Connection Error %u - Attempting to reconnect....", m_errorCode);
			LOG_SMTP_MESSAGE(MSGLISTSER_SMTP_CLIENT_INFO, strPrevError);
		}
		const DWORD dwRET_VAL = CV7SecureSocket::Connect(rstrSERVER_NAME, uiPORT_NO);
		if (dwRET_VAL != 0) {
			PostConnectAction();
		} else {
			m_dwLastError = GetLastError();
			if ((m_dwLastError != 0) && (m_dwLastError != WSAEWOULDBLOCK)) {
				ConnectToServer(rstrSERVER_NAME, uiPORT_NO);
			}
		}
	} else {
		// too many failures do not attmempt to send this message again
		m_dwLastError = ms_dwGENERIC_SMTP_ERROR;
		QString strError(L"FAILED TO SEND EMAIL, ABORTED");
		LOG_SMTP_MESSAGE(MSGLISTSER_SMTP_CLIENT_ERROR, strError);
		m_bFinishedSendingLastEmail = true;
	}
	return !m_bFinishedSendingLastEmail;
}
//****************************************************************************
// void OnReceive(int nErrorCode) 
///
/// On receive event handler
///
//***************************************************************************
void CSMTPSocket::OnReceive() {
	m_bSendReceiveOpInProgress = true;
	//Stability Project Fix:
	m_bReconnectSocket = false;
	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//for the Socket Read thread
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	if (pThreadInfo != NULL) {
		pThreadInfo->UpdateThreadCounter(AM_QAbstractSocket_READ_THREAD);
	}
	CV7SecureSocket::OnReceive();
	bool bTXSuccess = true;
	T_SMTP_RX_MSG_STATES eReplyMsgAction = srmPROCEED;
	// check if successfull
	int nErrorCode = 0;
	if (nErrorCode == 0) {
		QString strReceiveData("");
		if (QAbstractSocket_ERROR == Receive(strReceiveData)) {
			m_dwLastError = GetLastError();
			QString strError("");
			strError = QString::asprintf("Receive Error (%u)", m_dwLastError);
			LOG_SMTP_MESSAGE(MSGLISTSER_SMTP_CLIENT_ERROR, strError);
			eReplyMsgAction = srmABORT;
		} else {
			eReplyMsgAction = ParseRXMessage(strReceiveData);
			// check if the reply was a bad one
			if (eReplyMsgAction == srmABORT) {
				// check we didn't just send the quit message in an 
				// attempt to reconnect or we didn't just send a quit message normally
				if ((m_eCommsState != cstRECONNECTING) && (m_eCommsState != cstSENT_QUIT)) {
					// not a good reply - send a quit and reattempt sending this message unless
					// we are actually are already aborting, presumably because of a timeout
					if (!m_bAbortCurrOp) {
						SendQuit();
					}
					// set the state to ignore so the code at the end of the method takes no action
					eReplyMsgAction = srmIGNORE;
					m_eCommsState = cstRECONNECTING;
					m_bReconnectSocket = true;
				} else if (m_eCommsState == cstSENT_QUIT) {
					// there was a problem with the reply to a QUIT command, but at least we got something
					// so just proceed as if we got a valid quit message
					eReplyMsgAction = srmPROCEED;
				} else {
					// we were trying to reconnect following a problem with a previous reply and
					// this one it would appear - game over really so set the error flag
					m_dwLastError = ms_dwGENERIC_SMTP_ERROR;
				}
			}
		}
		// check we can proceed
		if (eReplyMsgAction == srmPROCEED) {
			// check the state we are currently in
			switch (m_eCommsState) {
			case cstSENT_HELO:
				bTXSuccess = SendMailFrom();
				break;
			case cstSENT_EHLO:
				if (GetEmailSTARTTLSSupport() && (CCESecureSocket::ST_MODE_SECURE == m_eSocketTransMode)
						&& (!m_eSecureConnReadyToEstd)) {
					bTXSuccess = SendStartTls();
				} else if (GetEmailSTARTTLSSupport() && (CCESecureSocket::ST_MODE_SECURE != m_eSocketTransMode)) {
					bTXSuccess = SendStartTls();
				} else {
					bTXSuccess = SendInitAuth();
				}
				break;
			case cstSENT_STARTTLS:
				if (CCESecureSocket::ST_MODE_SECURE == m_eSocketTransMode) {
					m_eSecureConnReadyToEstd = TRUE;
					SetEvent(m_hReadThreadEvent);
					SuspendThread(m_readThread);
				} else {
					bTXSuccess = SendInitAuth();
				}
				break;
			case cstMUST_SEND_AUTH:
				bTXSuccess = SendInitAuth();
				break;
			case cstSEND_AUTH_USERNAME:
				// sent the AUTH message successfully so now send the encrypted username
				bTXSuccess = SendUsername();
				break;
			case cstSEND_AUTH_PASSWORD:
				bTXSuccess = SendPassword();
				break;
			case cstSENT_AUTH_PASSWORD:
				bTXSuccess = SendMailFrom();
				break;
			case cstSENT_FROM:
				bTXSuccess = SendRcptTo();
				break;
			case cstSENT_TO:
				// increment the recipient number so we move onto the next recipient, if any
				++m_iCurrRecipientNo;
				// check if there is another recipient
				if (CStringUtils::GetItemAtPos(m_kEmailData.GetToAddress(), m_iCurrRecipientNo) != "") {
					bTXSuccess = SendRcptTo();
				} else {
					// no more recipients therefore move onto the next stage which is preparing to send
					// the data part of the email
					bTXSuccess = SendReqSendData();
				}
				break;
			case cstSENT_REQ_SEND_DATA:
				// do nothing as we are waiting for a specific reply here - it will
				// be the code that processes the replies that sets the next state
				break;
			case cstOKAY_TO_SEND_DATA:
				// a reply saying it is okay to send the message data must have been
				// received
				bTXSuccess = SendMessageData();
				break;
			case cstSENT_DATA:
				m_bFinishedSendingLastEmail = true;
				m_eCommsState = cstCONNECTED;
				bTXSuccess = true;
				m_dwLastError = 0;
				// Stability Project Fix:
				//Set the flag to true so that we know that we have to
				// send a Quit Message
				m_bSendData = true;
				break;
			case cstSENT_QUIT:
				bTXSuccess = true;
				//m_eCommsState = cstCONNECTED;					
				m_dwLastError = 0;
				//ShutDown( 2 );
				Disconnect();
				// Stability Project Fix:
				//Set the commState to cstNOT_CONNECTED so that
				//we do not drop the SMTP connection.
				//Reset the flag m_bSendData to false after receiving
				//response for Quit message
				m_eCommsState = cstNOT_CONNECTED;
				m_bSendData = false;
				m_bFinishedSendingLastEmail = true;
				break;
			case cstRECONNECTING:
				// this would usually happen following us attempting to reconnect to the server
				// and resending the email because of some previous send/receive error - if we
				// set the abort flag to false which will achieve the same result
				bTXSuccess = true;
				eReplyMsgAction = srmABORT;
				break;
			default:
				// should never happen so ignore
				DebugBreak();
				break;
			}
			// check the transmit went okay
			if (!bTXSuccess) {
				m_dwLastError = GetLastError();
				QString strError("");
				strError = QString::asprintf("Send Error (%u)", m_dwLastError);
				LOG_SMTP_MESSAGE(MSGLISTSER_SMTP_CLIENT_ERROR, strError);
			}
		}
	}
	// check if there has been a receive error, or an error within the SMTP data or
	// a transmit error - all will require us to disconnect and then reconnect to the server
	// assuming there haven't been too many timeouts already
	if ((nErrorCode != 0) || !bTXSuccess || (eReplyMsgAction == srmABORT)) {
		//ShutDown( 2 );
		Disconnect();
		m_eCommsState = cstRECONNECTING;
		m_bReconnectSocket = true;
	}
	m_bSendReceiveOpInProgress = false;
}
//****************************************************************************
// void SendEmail( const CEmailData &rkEMAIL_DATA )
///
/// // Method that initiates the sending of the email data
///
/// @param[in]		const CEmailData &rkEMAIL_DATA - The current email we want to send
///	@param[in]		const ULONG ulATTEMPT_NO - The retry attempt number
///
//****************************************************************************
void CSMTPSocket::SendEmail(const CEmailData &rkEMAIL_DATA, const ULONG ulATTEMPT_NO /* = 0 */) {
	// reset the email sent flag
	m_bFinishedSendingLastEmail = false;
	m_ulCurrAttemptNo = ulATTEMPT_NO;
	m_iCurrRecipientNo = 0;
	// check if already connect and to the correct server
	const bool bIS_CONNECTED(IsConnected());
	if (bIS_CONNECTED && (m_kEmailData.GetSMTPServerName() == rkEMAIL_DATA.GetSMTPServerName())) {
		// already connect to the correct server therefore do nothing but copy the new email and begin sending
		// it
		m_kEmailData = rkEMAIL_DATA;
		// increment the current attempt numbre as this usally gets done in the connect to server call
		++m_ulCurrAttemptNo;
		// now begin the sending of the data
		SendMailFrom();
	} else {
		m_kEmailData = rkEMAIL_DATA;
		if (bIS_CONNECTED) {
			// connected but not to the right server - disconnect and re-establish connection
			SendQuit();
			m_eCommsState = cstRECONNECTING;
		} else {
			// not connected so initiate the connection
			m_eCommsState = cstCONNECTING;
			ConnectToServer(m_kEmailData.GetSMTPServerName(), m_kEmailData.GetSMTPPortNum());
		}
	}
}
//****************************************************************************
// const bool SendHelo( )
///
/// Method that sends the helo message
///
/// @returns	True if the send message completed okay even though it may not have actually
///				completed sending the message yet
///
//****************************************************************************
const bool CSMTPSocket::SendHelo() {
	bool bSuccess = true;
	const QString strHELO(L"HELO " + m_kEmailData.GetThisIPAddress() + L"\r\n");
	m_eCommsState = cstSENT_HELO;
	// send the message on
	if (QAbstractSocket_ERROR == Send(strHELO)) {
		if (GetLastError() != WSAEWOULDBLOCK) {
			bSuccess = false;
		}
	}
	return bSuccess;
}
//****************************************************************************
// const bool SendEhlo( )
///
/// Method that sends the ehlo message
///
/// @returns	True if the send message completed okay even though it may not have actually
///				completed sending the message yet
///
//****************************************************************************
const bool CSMTPSocket::SendEhlo() {
	bool bSuccess = true;
	const QString strEHLO(L"EHLO " + m_kEmailData.GetThisIPAddress() + L"\r\n");
	m_eCommsState = cstSENT_EHLO;
	// send the message on
	if (QAbstractSocket_ERROR == Send(strEHLO)) {
		if (GetLastError() != WSAEWOULDBLOCK) {
			bSuccess = false;
		}
	}
	return bSuccess;
}
//****************************************************************************
// const bool SendMailFrom( )
///
/// Method that sends the mail from message
///
/// @returns	True if the send message completed okay even though it may not have actually
///				completed sending the message yet
///
//****************************************************************************
const bool CSMTPSocket::SendMailFrom() {
	bool bSuccess = true;
	const QString strMAIL_FROM(L"MAIL FROM:<" + m_kEmailData.GetFromAddress() + L">\r\n");
	m_eCommsState = cstSENT_FROM;
	if (QAbstractSocket_ERROR == Send(strMAIL_FROM)) {
		if (GetLastError() != WSAEWOULDBLOCK) {
			bSuccess = false;
		}
	}
	return bSuccess;
}
const bool CSMTPSocket::SendStartTls() {
	bool bSuccess = true;
	const QString strSTART_TLS(L"STARTTLS\r\n");
	if (QAbstractSocket_ERROR == Send(strSTART_TLS)) {
		if (GetLastError() != WSAEWOULDBLOCK) {
			bSuccess = false;
		}
	}
	m_eCommsState = cstSENT_STARTTLS;
	return bSuccess;
}
//****************************************************************************
// const bool SendInitAuth( )
///
/// Method that sends the initial authetification message data
///
/// @returns	True if the send message completed okay even though it may not have actually
///				completed sending the message yet
///
//****************************************************************************
const bool CSMTPSocket::SendInitAuth() {
	bool bSuccess = true;
	const QString strINIT_AUTH(L"AUTH LOGIN\r\n");
	m_eCommsState = cstSENT_INIT_AUTH;
	if (QAbstractSocket_ERROR == Send(strINIT_AUTH)) {
		if (GetLastError() != WSAEWOULDBLOCK) {
			bSuccess = false;
		}
	}
	return bSuccess;
}
//****************************************************************************
// const bool SendUsername( )
///
/// Method that sends the username message data
///
/// @returns	True if the send message completed okay even though it may not have actually
///				completed sending the message yet
///
//****************************************************************************
const bool CSMTPSocket::SendUsername() {
	bool bSuccess = true;
	m_kCoder.Encode(m_kEmailData.GetAuthUsername());
	WCHAR wcEncodedMsg[64];
	memset(wcEncodedMsg, 0, 64);
	size_t mbSize;
	mbstowcs_s(&mbSize, wcEncodedMsg, 64, reinterpret_cast<char*>(m_kCoder.EncodedMessage()), 64);
	wcsncat(wcEncodedMsg, 63, L"\r\n", 2);
	m_eCommsState = cstSENT_AUTH_USERNAME;
	if (QAbstractSocket_ERROR == Send(wcEncodedMsg)) {
		if (GetLastError() != WSAEWOULDBLOCK) {
			bSuccess = false;
		}
	}
	return bSuccess;
}
//****************************************************************************
// const bool SendPassword( )
///
/// Method that sends the password message data
///
/// @returns	True if the send message completed okay even though it may not have actually
///				completed sending the message yet
///
//****************************************************************************
const bool CSMTPSocket::SendPassword() {
	bool bSuccess = true;
	QString strDecodedPwd(m_kEmailData.GetAuthPassword());
	m_kCoder.Encode(strDecodedPwd);
	WCHAR wcEncodedMsg[40];
	memset(wcEncodedMsg, 0, 80);
	size_t mbSize;
	mbstowcs_s(&mbSize, wcEncodedMsg, 40, reinterpret_cast<char*>(m_kCoder.EncodedMessage()), 38);
	wcsncat(wcEncodedMsg, 40, L"\r\n", 2);
	m_eCommsState = cstSENT_AUTH_PASSWORD;
	if (QAbstractSocket_ERROR == Send(wcEncodedMsg)) {
		if (GetLastError() != WSAEWOULDBLOCK) {
			bSuccess = false;
		}
	}
	return bSuccess;
}
//****************************************************************************
// const bool SendRcptTo( )
///
/// Method that sends the rcpt to message
///
/// @returns	True if the send message completed okay even though it may not have actually
///				completed sending the message yet
///
//****************************************************************************
const bool CSMTPSocket::SendRcptTo() {
	bool bSuccess = true;
	QString strToAddress(CStringUtils::GetItemAtPos(m_kEmailData.GetToAddress(), m_iCurrRecipientNo));
	if (strToAddress != "") {
		const QString strMAIL_TO(L"RCPT TO:<" + strToAddress + L">\r\n");
		m_eCommsState = cstSENT_TO;
		if (QAbstractSocket_ERROR == Send(strMAIL_TO)) {
			if (GetLastError() != WSAEWOULDBLOCK) {
				bSuccess = false;
			}
		}
	} else {
		// somehow we have an empty email address so return false - more of a sanity check
		bSuccess = false;
	}
	return bSuccess;
}
//****************************************************************************
// const bool SendReqSendData( )
///
/// Method that sends the request send data message
///
/// @returns	True if the send message completed okay even though it may not have actually
///				completed sending the message yet
///
//****************************************************************************
const bool CSMTPSocket::SendReqSendData() {
	bool bSuccess = true;
	const QString strDATA(L"DATA\r\n");
	m_eCommsState = cstSENT_REQ_SEND_DATA;
	// send the from field
	if (QAbstractSocket_ERROR == Send(strDATA)) {
		if (GetLastError() != WSAEWOULDBLOCK) {
			bSuccess = false;
		}
	}
	return bSuccess;
}
//****************************************************************************
// const bool SendMessageData( )
///
/// Method that sends the message data
///
/// @returns	True if the send message completed okay even though it may not have actually
///				completed sending the message yet
///
//****************************************************************************
const bool CSMTPSocket::SendMessageData() {
	bool bSuccess = true;
	const QString strEND_CHAR(L"\r\n.\r\n");
	m_eCommsState = cstSENT_DATA;
	// send a complex email using MIME
	bSuccess = SendMIMEEmail();
	// send the end field
	if (bSuccess && (QAbstractSocket_ERROR == Send(strEND_CHAR))) {
		if (GetLastError() != WSAEWOULDBLOCK) {
			bSuccess = false;
		}
	}
	return bSuccess;
}
//****************************************************************************
// const bool SendMessageData( )
///
/// Method that sends a simple email with no MIME
///
/// @return	True if the data was sent okay
///
/// @NOTE		THIS FUNCTION IS NOW OBSELETE AS IT CANNOT SEND UNICODE DATA, THUS WE MUST
///				ALWAYS SEND EMAILS USING MIME
///
//****************************************************************************
const bool CSMTPSocket::SendSimpleEmail() {
	bool bSuccess = true;
	const QString strFROM(L"From: " + m_kEmailData.GetFromName() + L"\r\n");
	const QString strSUBJECT(L"Subject: " + m_kEmailData.GetSubject() + L"\r\n");
	const QString strMESSAGE(m_kEmailData.GetMessageBody() + L"\r\n");
	// send the from field
	if (QAbstractSocket_ERROR == Send(strFROM)) {
		if (GetLastError() != WSAEWOULDBLOCK) {
			bSuccess = false;
		}
	}
	// send the subject field
	if (bSuccess && (QAbstractSocket_ERROR == Send(strSUBJECT))) {
		if (GetLastError() != WSAEWOULDBLOCK) {
			bSuccess = false;
		}
	}
	// send the message body field
	if (bSuccess && (QAbstractSocket_ERROR == Send(strMESSAGE))) {
		if (GetLastError() != WSAEWOULDBLOCK) {
			bSuccess = false;
		}
	}
	return bSuccess;
}
//****************************************************************************
// const bool SendMIMEEmail( SendMIMEEmail )
///
/// Method that sends a MIME email with a screenshot attached
///
/// @return	True if the data was sent okay
///
//****************************************************************************
const bool CSMTPSocket::SendMIMEEmail() {
	bool bSuccess = true;
	QString strTemp("");
	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//for the Socket Read thread
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	if (pThreadInfo != NULL) {
		//Update the Thread Counter for the Socket Read
		//thread after each iteration
		pThreadInfo->UpdateThreadCounter(AM_QAbstractSocket_READ_THREAD);
	}
	// setup the various headers
	const QString strMIME_VER(L"MIME-Version: 1.0\r\n");
	const QString strX_PRIORTY(L"X-Priority: 3 (Normal)\r\n");
	const QString strMS_MAIL_PRIORITY(L"X-MSMail-Priority: Normal\r\n");
	strTemp = QString::asprintf("%s", pSYSTEM_INFO->GetOEMCompanyName());
	const QString strMAILER(L"X-Mailer: " + strTemp + L" Recorder Mailer\r\n");
	const QString strIMPORTANCE(L"Importance: Normal\r\n");
	// get the time
	const int iTIME_LEN = 64;
	TCHAR szTime[iTIME_LEN];
	TCHAR szDate[iTIME_LEN];
	QDateTime tTimestamp;
	int iGMTOffset = 0;
	TIME_ZONE_INFORMATION tzi;
	DWORD dwRet = 0;
	GetV6LocalTime(&tTimestamp);
	dwRet = GetTimeZoneInformation(&tzi);
	if (dwRet == TIME_ZONE_ID_DAYLIGHT) //Adjusting DST offset when recorder is in Daylight saving mode.
			{
		iGMTOffset = -((((tzi.Bias + tzi.DaylightBias) / 60L) * 100L) + ((tzi.Bias + tzi.DaylightBias) % 60L));
	} else {
		iGMTOffset = -(((tzi.Bias / 60L) * 100L) + (tzi.Bias % 60L)); //when recorder is in Standard mode.
	}
	//iGMTOffset is a value of bias in HHMM format. 
	//The calculations below are extracting the HH part and multiplying by 100 to move it to left by two digits.
	//And the MM value extracted by % operator is added to the HH00 value. It gets placed at the right two digits position to form HHMM value.
	GetDateasprintf(OCALE_SYSTEM_DEFAULT, 0, &tTimestamp, _T("ddd, d MMM yyyy"), szDate, iTIME_LEN);
	GetTimeasprintf(OCALE_SYSTEM_DEFAULT, 0, &tTimestamp, _T("H:mm:ss"), szTime, iTIME_LEN);
	strTemp = QString::asprintf(_T("%s %s %4.4d\r\n"), szDate, szTime, iGMTOffset);
	const QString strDATE(L"Date: " + strTemp);
	const QString strFROM(L"From: " + m_kEmailData.GetFromName() + L"\r\n");
	QString strTO(L"To: ");
	int iCurrRecipientNo = 0;
	QString strRecip("");
	while ((strRecip = CStringUtils::GetItemAtPos(m_kEmailData.GetToAddress(), iCurrRecipientNo)) != "") {
		// add the recipient to the list and delimit
		strTO += L"<" + strRecip + L">,";
		// move onto the next recipient
		++iCurrRecipientNo;
		if (pThreadInfo != NULL) {
			//Update the Thread Counter for the Socket Read
			//thread after each iteration
			pThreadInfo->UpdateThreadCounter(AM_QAbstractSocket_READ_THREAD);
		}
	}
	// remove the last comma
	strTO.remove(strTO.size() - 1, 1);
	strTO += L"\r\n";
	QString strUTF8Subject(CStringUtils::EncodeToUTF8(m_kEmailData.GetSubject()));
	// replace all spaces with '=20'
	strUTF8Subject.Replace(L" ", L"=20");
	const QString strUTF8_QUOTED_PRINTABLE_SUBJECT(EncodeQuotedPrintable(strUTF8Subject));
	const QString strSUBJECT(L"Subject: =?utf-8?Q?" + strUTF8_QUOTED_PRINTABLE_SUBJECT + L"?=\r\n");
	const QString strMESSAGE_DATA(m_kEmailData.GetMessageBody() + L"\r\n");
	// Create the unique message ID
	strTemp = QString::asprintf("%u%4.4X%2.2X%2.2X%8.8X", m_kEmailData.GetSerialNo(), tTimestamp.wYear,
			tTimestamp.wMonth, tTimestamp.wDay, GetTickCount());
	// encode the ID
	m_kCoder.Encode(strTemp);
	strTemp = m_kCoder.EncodedMessage();
	QString strMESSAGE_ID(L"Message-ID: " + strTemp + L"\r\n");
	// always 2 parts to the email so setup as a multipart email
	strTemp = QString::asprintf(_T("CSmtpMsgPart123X456%8.8X"), GetTickCount());
	QString strBOUNDARY(L"\r\n--" + strTemp + L"\r\n");
	QString strEND_BOUNDARY(L"\r\n--" + strTemp + L"--\r\n");
	QString strCONTENT_TYPE(L"Content-Type: multipart/mixed;\r\n\tboundary=\"" + strTemp + L"\"\r\n" + strBOUNDARY);
	// container for the email information we are going to send
	QString strMessageToSend(
			strMIME_VER + strX_PRIORTY + strMS_MAIL_PRIORITY + strMAILER + strIMPORTANCE + strDATE + strFROM + strTO
					+ strSUBJECT + strMESSAGE_ID + strCONTENT_TYPE);
	// add the secondary content type/boundary information
	strTemp = QString::asprintf(_T("CSmtpMsgPart123X457%8.8X"), GetTickCount());
	QString strSECONDARY_BOUNDARY(L"\r\n--" + strTemp + L"\r\n");
	QString strSECONDARY_END_BOUNDARY(L"\r\n--" + strTemp + L"--\r\n");
	QString strSECONDARY_CONTENT_TYPE(
			L"Content-Type: multipart/alternative;\r\n\tboundary=\"" + strTemp + L"\"\r\n" + strSECONDARY_BOUNDARY);
	strMessageToSend += strSECONDARY_CONTENT_TYPE;
	// now add the message data
	strMessageToSend += L"Content-Type: text/plain;\r\n\tcharset=\"utf-8\"\r\n";
	// Encode the message using the desired encoding method - we use quoted-printable for this part
	strMessageToSend += _T("Content-Transfer-Encoding: quoted-printable\r\n\r\n");
	// send what we have done so far
	if (QAbstractSocket_ERROR == Send(strMessageToSend)) {
		if (GetLastError() != WSAEWOULDBLOCK) {
			bSuccess = false;
		}
	}
	// now send the encoded message information
	if (QAbstractSocket_ERROR == Send(EncodeQuotedPrintable(CStringUtils::EncodeToUTF8(strMESSAGE_DATA)))) {
		if (GetLastError() != WSAEWOULDBLOCK) {
			bSuccess = false;
		}
	}
	// finish this section off with the boundary marker
	strMessageToSend = L"\r\n" + strSECONDARY_BOUNDARY;
	// add an HTML section
	strMessageToSend += L"Content-Type: text/html;\r\n\tcharset=\"utf-8\"\r\n";
	// Encode the message using the desired encoding method - we use quoted-printable for this part
	strMessageToSend += _T("Content-Transfer-Encoding: quoted-printable\r\n\r\n");
	// send this data 
	if (QAbstractSocket_ERROR == Send(strMessageToSend)) {
		if (GetLastError() != WSAEWOULDBLOCK) {
			bSuccess = false;
		}
	}
	strMessageToSend = static_cast<WCHAR>(0xFEFF);
	strMessageToSend += L"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">\r\n<HTML><HEAD>\r\n";
	strMessageToSend +=
			L"<META http-equiv=Content-Type content=\"text/html; charset=utf-8\">\r\n<META content=\"MSHTML 6.00.2900.3059\" name=GENERATOR>\r\n";
	strMessageToSend += L"<STYLE></STYLE>\r\n</HEAD>\r\n<BODY bgColor=#ffffff>\r\n";
	QString strMessageBody(strMESSAGE_DATA);
	int iCrLfPos = 0;
	const QString strCRLF(L"\r\n");
	while (strMessageBody.size() > 0) {
		strMessageToSend += L"<DIV><FONT face=Arial size=2>";
		if ((iCrLfPos = strMessageBody.indexOf(strCRLF, 0)) != -1) {
			// check this is not a lone CRLF
			if (iCrLfPos == 0) {
				// add the HTML crlf and delete the crlf from the message body
				strMessageToSend += "&nbsp;";
				strMessageBody.remove(0, strCRLF.size());
			} else {
				strMessageToSend += strMessageBody.left(iCrLfPos);
				strMessageBody.remove(0, iCrLfPos + strCRLF.size());
			}
		} else {
			// no carriage return line feeds therefore just add this string in its entirety
			strMessageToSend += strMessageBody;
			strMessageBody = "";
		}
		strMessageToSend += L"</FONT></DIV>\r\n";
		if (pThreadInfo != NULL) {
			//Update the Thread Counter for the Socket Read
			//thread after each iteration
			pThreadInfo->UpdateThreadCounter(AM_QAbstractSocket_READ_THREAD);
		}
	}
	strMessageToSend += L"</BODY></HTML>\r\n";
	// send this data after converting into UTF-8
	if (QAbstractSocket_ERROR == Send(EncodeQuotedPrintable(CStringUtils::EncodeToUTF8(strMessageToSend))))
	//if( QAbstractSocket_ERROR == Send( CStringUtils::EncodeToUTF8( strMessageToSend ) ) )
			{
		if (GetLastError() != WSAEWOULDBLOCK) {
			bSuccess = false;
		}
	}
	// add the secondary end boundary
	if (bSuccess && (QAbstractSocket_ERROR == Send(strSECONDARY_END_BOUNDARY))) {
		if (GetLastError() != WSAEWOULDBLOCK) {
			bSuccess = false;
		}
	}
	// finish this section off with the boundary marker
	strMessageToSend = L"\r\n\r\n" + strBOUNDARY;
	const QString strFILE_ATTACHMENTS(m_kEmailData.GetFileAttachments());
	QString strCurrFile("");
	USHORT usFileCount = 0;
	// check if we need to attach a report
	while ((strCurrFile = CStringUtils::GetItemAtPos(strFILE_ATTACHMENTS, usFileCount)) != "") {
		// The file should have been created so open it and encode it
		HANDLE hFile = CreateFile(strCurrFile, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
	if (hFile != INVALID_HANDLE_VALUE)
	{
		LPBYTE pData;
		DWORD dwSize;
		DWORD dwBytes;
		// Get the size of the file, allocate the memory and read the contents.
		dwSize = GetFileSize( hFile, NULL );
		pData = (LPBYTE)malloc( dwSize );
		// check pData was allocated successfully
		if( pData != NULL )
		{
			bool dataEncodedOk = true;
			if( ReadFile( hFile, pData, dwSize, &dwBytes, NULL ) )
			{
				// BASE64 encode the message
				if( !m_kCoder.Encode( pData, dwBytes ) )
				{
					// the data was not encoded successfully - attempt to record a diagnostic error
					LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_ERROR,"Could not email the report, not enough memory for encoding!!!" );
					dataEncodedOk = false;
				}
			}
			// free the memory 
			//No need to close the mutex in Qt
			free(pData);
			// check the data was encoded ok before sending the extra email data
			if( dataEncodedOk )
			{
				QString strFileName( QString ::fromWCharArray("") );
				strFileName = strCurrFile;

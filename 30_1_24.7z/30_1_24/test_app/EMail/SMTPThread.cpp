/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Email system
/// @n Filename:  SMTPThread.cpp
/// @n Description: Implementation of the CSMTPThread class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log[4]:
//  14  Aristos  1.4.1.7.1.0 9/19/2011 4:51:17 PM  Hemant(HAIL)  
//  Stability recorder source code (JI Release) updated for WatchDog
//  Timer functionality.
//  13  Stability Project 1.4.1.7 8/10/2011 12:09:19 PM  Hemant(HAIL) 
// PAR # 1-L2UODL (Issue: Email Timeout)
//  12  Stability Project 1.4.1.6 7/11/2011 4:15:49 PM  Hemant(HAIL) 
// Files updated when fixing the Email Memory Leak Issue.
//  11  Stability Project 1.4.1.5 7/2/2011 5:01:28 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
// $
//
// **************************************************************************
#include "SMTPThread.h"
#include "ThreadInfo.h"
#include "V6globals.h"
/// Static Initialisation
std::deque<CEmailData> CSMTPThread::ms_kMessageList;
CSMTPSocket *CSMTPThread::m_pkSMTPSocket = NULL;
const ULONG CSMTPThread::m_ulTIMEOUT_PERIOD = 300;
const ULONG CSMTPThread::m_ulQUIT_TIMEOUT_PERIOD = 60;
ULONG CSMTPThread::m_ulTimeout = 0;
bool CSMTPThread::m_bWaitingForQuitReply = false;
CSMTPThread::T_SMTP_THREAD_STATE CSMTPThread::ms_eState = CSMTPThread::stsINIT;
QMutex CSMTPThread::m_kCriticalSection;
//****************************************************************************
// CSMTPThread(	)
///
/// Constructor
///
//****************************************************************************
CSMTPThread::CSMTPThread() {
}
//****************************************************************************
// ~CSMTPThread(	)
///
/// Destructor
///
//****************************************************************************
CSMTPThread::~CSMTPThread() {
}
//****************************************************************************
// BOOL InitInstance()
///
/// Init method
///
//****************************************************************************
BOOL CSMTPThread::InitInstance() {
	// TODO: perform and per-thread initialization here
	return TRUE;
}
//****************************************************************************
// int CSMTPThread::ExitInstance()
///
/// Init method
///
//****************************************************************************
int CSMTPThread::ExitInstance() {
	QThread::exit();
	return 0;
}
//****************************************************************************
// void ShutdownThread( )
///
/// Method that signals to the thread we are shutting down
///
//****************************************************************************
void CSMTPThread::ShutdownThread() {
	ms_eState = stsSHUTDOWN;
}
//****************************************************************************
// UINT EmailNotificationThreadFunc(LPVOID lpParam)
///
/// Main thread function
///
//****************************************************************************
UINT CSMTPThread::EmailNotificationThreadFunc(LPVOID lpParam) {
	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//for the Email thread
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
#ifdef THREAD_ID_SERIAL_LOG
	WCHAR szDbgMsg[512];
	swprintf( szDbgMsg, L"CSMTPThread::EmailNotificationThreadFunc-Thread id 0x%x, %lu ", GetThreadId(GetCurrentThread()), GetThreadId(GetCurrentThread()));
	OutputDebugString(szDbgMsg);
#endif
	if (pThreadInfo != NULL) {
		pThreadInfo->UpdateThreadInfo(AM_EMAIL_THREAD, true);
	}
	while (ms_eState != stsSHUTDOWN) {
		sleep(1000);
		// check if a socket connection exists
		if (m_pkSMTPSocket != NULL) {
			// get the current comms state
			CSMTPSocket::T_SMTP_COMMS_THREAD_STATE eCommsState = m_pkSMTPSocket->GetCommsState();
			// increment the timeout variable
			++m_ulTimeout;
			// the socket exists so check if there has been a timeout
			if ((!m_bWaitingForQuitReply && (m_ulTimeout >= m_ulTIMEOUT_PERIOD))
					|| (m_bWaitingForQuitReply && (m_ulTimeout >= m_ulQUIT_TIMEOUT_PERIOD))) {
				// there has been a timeout - abort the current operation
				// generate an error as long as we are not already attemtping to quit because 
				// of an error
				if (!m_bWaitingForQuitReply) {
					QString strError("");
					strError = QString::asprintf(
							"Timeout sending email, error(%u) - Subject: " + m_pkSMTPSocket->GetEmailSubject(),
							m_pkSMTPSocket->GetLastError());
					LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
					strError = QString::asprintf(
							"TIMEOUT SENDING EMAIL, error(%u) - Subject: " + m_pkSMTPSocket->GetEmailSubject(),
							m_pkSMTPSocket->GetLastError());
					LOG_SMTP_MESSAGE(MSGLISTSER_SMTP_CLIENT_ERROR, strError);
				}
				// now try and drop the connection in a suitable manner
				DropFaultySMTPConnection();
			} else {
				// there has not been a timeout
				// check if we are waiting for a quit reply
				if (m_bWaitingForQuitReply) {
					// we are waiting for a quit reply, see if we have received one
					if (eCommsState == CSMTPSocket::cstNOT_CONNECTED) {
						// we have received a reply therefore close and delete the socket
						//
						// Stability Project Fix:
						//
						// This fix was done to avoid memory leak. We do not close and delete the Socket
						// when we send the Quit Message.Hence just set the flag m_bWaitingForQuitReply to false
						//DropSMTPConnection();
						m_bWaitingForQuitReply = false;
						m_ulTimeout = 0;
					} else {
						// waiting for a quit message still so do nothing
					}
				} else if (m_pkSMTPSocket->SocketNeedsReconnecting()) {
					// the socket has had a problem and need reconnecting - store the retry attempts
					const ULONG ulRETRY_ATTEMPTS = m_pkSMTPSocket->GetCurrAttemptNo();
					const CEmailData kEMAIL_DATA = m_pkSMTPSocket->GetEmailData();
					// delete the current socket object - this will disconnect from the server
					delete m_pkSMTPSocket;
					if (kEMAIL_DATA.GetSMTPSecurityMode())
						m_pkSMTPSocket = new CSMTPSocket(CCESecureSocket::ST_MODE_SECURE);
					else
						m_pkSMTPSocket = new CSMTPSocket(CCESecureSocket::ST_MODE_NON_SECURE);
					if (m_pkSMTPSocket->Create(SOCK_STREAM) == FALSE) {
						DWORD dwError = GetLastError();
						// delete the socket and report the error
						delete m_pkSMTPSocket;
						m_pkSMTPSocket = NULL;
						QString strError("");
						strError = QString::asprintf("Failed to create the socket correctly (E%u)", dwError);
						LOG_SMTP_MESSAGE(MSGLISTSER_SMTP_CLIENT_ERROR, strError);
					} else {
						// the socket was created okay - now pass on the email
						m_pkSMTPSocket->SendEmail(kEMAIL_DATA, ulRETRY_ATTEMPTS);
					}
				} else {
					// not waiting for a quit reply
					// check if we have finished sending the last email
					if (FinishedSendingLastEmail()) {
						// shankar
						// FinishedSendingLastEmail checks for m_pkSMTPSocket "null"ness and if so, below m_pkSMTPSocket->GetLastError() will crash
						if (m_pkSMTPSocket != NULL) {
							// we have finished sending the last email but we need to check if there was a problem
							// sending it - if yes then we must generate an error message
							if (m_pkSMTPSocket->GetLastError() != 0) {
								DWORD dwError = m_pkSMTPSocket->GetLastError();
								// there was a problem sending the last email - generate a diagnostic error
								// message and then quit the connection
								QString strError("");
								strError = QString::asprintf(
										"Failed to send email (E%lu) - Subject: " + m_pkSMTPSocket->GetEmailSubject(),
										m_pkSMTPSocket->GetLastError());
								LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
								// drop the connection in a suitable manner
								DropFaultySMTPConnection();
							} else {
								// there was not a problem sending the last email therefore see if there are any new
								// emails and send them
								//					  				
								CEmailData kEmailData;
								//
								// Stability Project Fix:
								//
								// Set the attempt number to zero because we establish a new connection
								// for every email
								if (m_pkSMTPSocket->GetSocketState() == CCESecureSocket::NONE) {
									m_pkSMTPSocket->SetCurrAttemptNo(0);
									// always reset the timeout at this point as nothing will be pending
									m_ulTimeout = 0;
								}
								if ((m_pkSMTPSocket->IsSendData() == false) && (GetEmail(kEmailData))) {
									// there is an email pending therefore pass it on to the socket code
									SendEmail(kEmailData);
								} else if (m_pkSMTPSocket->IsSendData() == true) {
									// no more mail so send a quit message
									SendQuit();
									m_pkSMTPSocket->SetFinishedSendingLastEmail(false);
									//m_pkSMTPSocket->SetIsSendData(false);
								}
							}
						}// checking for NULL m_pkSMTPSocket - in next while loop, NULL m_pkSMTPSocket is handled in else case below
					} else {
						// we have not finished sending the last email so do nothing
					}
				}
			}
		} else {
			// always reset the timout at this point as nothing will be pending
			m_ulTimeout = 0;
			// reset the quit reply too
			m_bWaitingForQuitReply = false;
			// a socket connection does not exist therefore just check if there is new mail to
			// send	
			CEmailData kEmailData;
			if (GetEmail(kEmailData)) {
				// there is an email pending therefore pass it on to the socket code
				SendEmail(kEmailData);
			} else {
				// nothing pending so do nothing
			}
		}
		if (pThreadInfo != NULL) {
			//Update the Thread Counter for the Email
			//thread after each iteration
			pThreadInfo->UpdateThreadCounter(AM_EMAIL_THREAD);
		}
	}
	if (m_pkSMTPSocket != NULL) {
		//
		// Stability Project Fix:
		//
		// m_pkSMTPSocket was not deleted as a result there was a drop in memory issue
		//
		delete m_pkSMTPSocket;
		m_pkSMTPSocket = NULL;
	}
	DeleteCritSect();
	if (pThreadInfo != NULL) {
		//Update the info that the Email thread is exiting
		//Hence this thread need not be considered to kick the 
		//watchdog
		pThreadInfo->UpdateThreadInfo(AM_EMAIL_THREAD, false);
	}
	return 0;
}
//****************************************************************************
// void SendEmail( const CEmailData &rkEMAIL_DATA, HANDLE hEVENT )
///
/// Method that initiates the connection with the SMTP server (if necessary) and begins 
/// sending the email
///
/// @param[in]		const CEmailData &rkEMAIL_DATA - The current email we want to send
///
//****************************************************************************
void CSMTPThread::SendEmail(const CEmailData &rkEMAIL_DATA) {
	QString strInfo("");
	strInfo = QString::asprintf("SENDING NEW EMAIL");
	LOG_SMTP_MESSAGE(MSGLISTSER_SMTP_CLIENT_INFO, strInfo);
	// Stability Project Fix:
	//
	// This fix was done to avoid memory leak. We do not close and delete the instance
	// of class SMTP socket .We only create and destroy the raw socket.
	// We set the flag to continue the ReadThread in class CESocket. 
	if (m_pkSMTPSocket == NULL) {
		if (rkEMAIL_DATA.GetSMTPSecurityMode())
			m_pkSMTPSocket = new CSMTPSocket(CCESecureSocket::ST_MODE_SECURE);
		else
			m_pkSMTPSocket = new CSMTPSocket(CCESecureSocket::ST_MODE_NON_SECURE);
		//The ReadThread is set to true the first time socket is created.
		// It remains true throughout the lifetime of the application.
		m_pkSMTPSocket->SetContinueReadThread(true);
	}
	if (m_pkSMTPSocket->GetSocketState() < CSMTPSocket::CREATED) {
		if (m_pkSMTPSocket->Create(SOCK_STREAM) == FALSE) {
			DWORD dwError = GetLastError();
			// delete the socket and report the error
			delete m_pkSMTPSocket;
			m_pkSMTPSocket = NULL;
			QString strError("");
			strError = QString::asprintf("Failed to create the socket correctly (E%u)", dwError);
			LOG_SMTP_MESSAGE(MSGLISTSER_SMTP_CLIENT_ERROR, strError);
			// not waiting for a quit reply therefore reset
			//m_bWaitingForQuitReply = false;
			// reset the timeout variable
			//m_ulTimeout = 0;
			//return;
		} else {
			// the socket was created okay - now pass on the email
			m_pkSMTPSocket->SendEmail(rkEMAIL_DATA);
		}
	}
	// socket already exists so pass on the email
	//m_pkSMTPSocket->SendEmail( rkEMAIL_DATA );
	// not waiting for a quit reply therefore reset
	m_bWaitingForQuitReply = false;
	// reset the timeout variable
	m_ulTimeout = 0;
}
//****************************************************************************
// const bool FinishedSendingLastEmail() 
///
/// Method indicating if scoket has finished sending the last email (successful or not)
///
/// @returns	True if the socket has finished sending the last email
///
//****************************************************************************
const bool CSMTPThread::FinishedSendingLastEmail() {
	return ((m_pkSMTPSocket == NULL) || m_pkSMTPSocket->FinishedSendingLastEmail());
}
//****************************************************************************
// void DropSMTPConnection()
///
/// Method that closes the SMTP socket connection to the server, usually because there
/// are no more emails left to send or we are closing down
///
//****************************************************************************
void CSMTPThread::DropSMTPConnection() {
	if (m_pkSMTPSocket != NULL) {
		//m_pkSMTPSocket->Close();
		delete m_pkSMTPSocket;
		m_pkSMTPSocket = NULL;
	}
	// reset the waiting for quit flag
	m_bWaitingForQuitReply = false;
	// reset the timeout variable too
	m_ulTimeout = 0;
}
//****************************************************************************
// void AddEmailToPending( const CEmailData &rkEMAIL_DATA )
///
/// Method that adds an email to the send queue reading for processing and sending
///
//****************************************************************************
void CSMTPThread::AddEmailToPending(const CEmailData &rkEMAIL_DATA) {
	m_kCriticalSection.lock();
	if (ms_kMessageList.size() < 200) {
		ms_kMessageList.push_back(rkEMAIL_DATA);
	} else {
		// too many email messages in the buffer - do not add to the buffer and log a diagnostic message
		// instead
		LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR,
				"Cannot send email as buffer full - Subject: " + rkEMAIL_DATA.GetSubject());
	}
	m_kCriticalSection.lock();
}
//****************************************************************************
// void GetEmail( CEmailData &rkEmailData )
///
/// Method that gets an email in order to send it
///
//****************************************************************************
const bool CSMTPThread::GetEmail(CEmailData &rkEmailData) {
	bool bDataPresent = false;
	m_kCriticalSection.lock();
	if (ms_kMessageList.size() > 0) {
		// get the front data item
		rkEmailData = ms_kMessageList.front();
		// now remove from our queue
		ms_kMessageList.pop_front();
		// let the calling process know there is data
		bDataPresent = true;
	}
	m_kCriticalSection.lock();
	return bDataPresent;
}
//****************************************************************************
// void SendQuit( )
///
/// Method that sends the quit message
///
//****************************************************************************
void CSMTPThread::SendQuit() {
	m_pkSMTPSocket->SendQuit();
	// set the flag indicating we are waiting for a quit reply
	m_bWaitingForQuitReply = true;
	// reset the timeout variable too
	m_ulTimeout = 0;
}
//****************************************************************************
// void DropFaultySMTPConnection( )
///
/// Method that drops an SMTP connection in a suitable manner
///
//****************************************************************************
void CSMTPThread::DropFaultySMTPConnection() {
	//Get Handle of the class CThreadInfo.
	//The handle is used to update the thread counter
	//for the Email thread
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	CSMTPSocket::T_SMTP_COMMS_THREAD_STATE eCommsState = m_pkSMTPSocket->GetCommsState();
	// check if the socket is connected at all and that we are nto already waiting for
	// a quit reply
	if ((eCommsState > CSMTPSocket::cstCONNECTED) && !m_bWaitingForQuitReply) {
		QString strError("");
		strError = QString::asprintf("Timeout sending email, aborting and sending a quit message");
		LOG_SMTP_MESSAGE(MSGLISTSER_SMTP_CLIENT_ERROR, strError);
		// We are connected and have had some replies so send the quit message but only
		// after we are sure we are not stuck in any time consuming send or receive operations
		m_pkSMTPSocket->AbortCurrOperation();
		// wait for any current send/receive operations to complete/abort gracefully
		const int ABORT_TIMEOUT_IN_SECS = 60;
		int currWaitDurationInSecs = 0;
		const int ONE_SEC_WAIT_PERIOD = 1000;
		while (m_pkSMTPSocket->SendReceiveOpInProgress()) {
			if (pThreadInfo != NULL) {
				//Update the Thread Counter for the Email thread
				pThreadInfo->GetThreadCounter(AM_EMAIL_THREAD);
			}
			// check if our timeout has been exceeded
			if (currWaitDurationInSecs >= ABORT_TIMEOUT_IN_SECS) {
				// the timeout has occurred - this is pretty serious and the only thing we
				// can do is kill the socket object - record an error message first though
				QString strError("");
				strError = QString::asprintf("Current SMTP operation failed to abort - closing socket forcibly");
				LOG_DIAGNOSTIC_MESSAGE(MSGLISTSER_DIAGNOSTIC_ERROR, strError);
				// now delete the socket object
				delete m_pkSMTPSocket;
				m_pkSMTPSocket = NULL;
				// reset the timeout variable too
				m_ulTimeout = 0;
				// break from the loop				
				break;
			} else {
				// the timeout has not been reached so wait another second
				sleep(ONE_SEC_WAIT_PERIOD);
				currWaitDurationInSecs++;
				QString strWarning("");
				strWarning = QString::asprintf("Waiting for current operation to abort...");
				LOG_SMTP_MESSAGE(MSGLISTSER_SMTP_SERVER_WARNING, strWarning);
			}
		}
		// send the quit message if the socket is valid
		if (m_pkSMTPSocket != NULL) {
			SendQuit();
		}
	} else if (eCommsState == CSMTPSocket::cstCONNECTED) {
		QString strError("");
		strError = QString::asprintf("Timeout sending email, connected but no replies received");
		LOG_SMTP_MESSAGE(MSGLISTSER_SMTP_CLIENT_ERROR, strError);
		// we haven't managed to receive any replies from the server but we are
		// connected at a socket level so just drop the connection
		DropSMTPConnection();
	} else if (m_bWaitingForQuitReply) {
		QString strError("");
		strError = QString::asprintf("Timeout sending email, no reply to the quit message so dropping connection");
		LOG_SMTP_MESSAGE(MSGLISTSER_SMTP_CLIENT_ERROR, strError);
		// we haven't managed to receive any replies from the server but we 
		// have sent a quit message after a previous problem and still have not
		// had a reply
		DropSMTPConnection();
	} else {
		// we are not even connected so just delete the socket pointer - this error will have already been 
		// reported so no need to report anything
		delete m_pkSMTPSocket;
		m_pkSMTPSocket = NULL;
		// reset the waiting for quit flag
		m_bWaitingForQuitReply = false;
		// reset the timeout variable too
		m_ulTimeout = 0;
	}
}

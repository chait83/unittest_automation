/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Email system
/// @n Filename:  Base64.h
/// @n Description: Definition of the CBase64 class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log:
//  6 Stability Project 1.3.1.1 7/2/2011 4:55:36 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  5 Stability Project 1.3.1.0 7/1/2011 4:27:45 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  4 V6 Firmware 1.3 3/15/2010 11:07:50 AM  Vivek (HAIL)  CR
//  3133:Wyeth Lock Up issue (Emailing screenshots may cause the X-Series
//  recorder to crash unexpectedly)
//  3 V6 Firmware 1.2 3/2/2007 9:05:08 PM Roger Dawson  
//  Fixed problem with email attachments not appearing when using Lan
//  Suite email server.
//  2 V6 Firmware 1.1 12/20/2006 3:06:00 PM  Roger Dawson  
//  Phase 3b merges into the main build. Added the ability to embed
//  screenshots in emails.
//  1 V6 Firmware 1.0 5/25/2006 5:28:31 PM  Roger Dawson  
// $
//
// **************************************************************************
#if !defined(AFX_CBase64_H__B2E45717_0625_11D2_A80A_00C04FB6794C__INCLUDED_)
#define AFX_CBase64_H__B2E45717_0625_11D2_A80A_00C04FB6794C__INCLUDED_
#include "Defines.h"
//**CBase64***********************************************************
///
/// @brief Encryption class used by the SMTP classes
/// 
/// Encryption class used by the SMTP classes
///
//****************************************************************************
class CBase64 {
	// Internal bucket class.
	class TempBucket {
	public:
		BYTE nData[4];
		BYTE nSize;
		void Clear() {
			::ZeroMemory(nData, 4);
			nSize = 0;
		}
		;
	};
	PBYTE m_pDBuffer;
	PBYTE m_pEBuffer;
	DWORD m_nDBufLen;
	DWORD m_nEBufLen;
	DWORD m_nDDataLen;
	DWORD m_nEDataLen;
public:
	CBase64();
	virtual ~CBase64();
	const DWORD GetEncodeBufferLength() const {
		return m_nEBufLen;
	}
	const DWORD GetEncodeDataLength() const {
		return m_nEDataLen;
	}
public:
	// Method used to encode some data ready for sending to an email server
	virtual bool Encode(const PBYTE, DWORD);
	// Method used to encode some data ready for sending to an email server
	virtual bool Encode(QString strMessage);
	// Method used to decode some data received from an email server
	virtual bool Decode(const PBYTE, DWORD);
	// Method used to decode some data received from an email server
	virtual bool Decode(QString strMessage);
	// Accessor for the decoded message buffer
	virtual PBYTE DecodedMessage() const;
	// Accessor for the encoded message buffer
	virtual PBYTE EncodedMessage() const;
	// Method that allocates an appropriately sized buffer for encoding
	virtual bool AllocEncode(DWORD);
	// Method that allocates an appropriately sized buffer for decoding
	virtual bool AllocDecode(DWORD);
	// Method that copies data into the encoded buffer
	virtual bool SetEncodeBuffer(const PBYTE pBuffer, DWORD nBufLen);
	// Method that copies data into the decoded buffer
	virtual bool SetDecodeBuffer(const PBYTE pBuffer, DWORD nBufLen);
protected:
	// Encode to buffer method
	virtual void _EncodeToBuffer(const TempBucket &Decode, PBYTE pBuffer);
	// Decode to buffer method
	virtual ULONG _DecodeToBuffer(const TempBucket &Decode, PBYTE pBuffer);
	// Encode raw method 
	virtual void _EncodeRaw(TempBucket&, const TempBucket&);
	// Decode raw method
	virtual void _DecodeRaw(TempBucket&, const TempBucket&);
	// Checks for bad mime characters
	virtual BOOL _IsBadMimeChar(BYTE);
	static char m_DecodeTable[256];
	static BOOL m_Init;
	// Initialisation decoding table method
	void _Init();
};
#endif // !defined(AFX_CBase64_H__B2E45717_0625_11D2_A80A_00C04FB6794C__INCLUDED_)

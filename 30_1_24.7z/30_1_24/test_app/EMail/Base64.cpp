/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Email system
/// @n Filename:  Base64.cpp
/// @n Description: Implementation of the CBase64 class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log:
//  8 Stability Project 1.3.1.3 7/2/2011 4:55:36 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  7 Stability Project 1.3.1.2 7/1/2011 4:37:58 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  6 Stability Project 1.3.1.1 3/17/2011 3:20:10 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  5 Stability Project 1.3.1.0 2/15/2011 3:02:14 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
//  4 V6 Firmware 1.3 3/15/2010 11:07:49 AM  Vivek (HAIL)  CR
//  3133:Wyeth Lock Up issue (Emailing screenshots may cause the X-Series
//  recorder to crash unexpectedly)
//  3 V6 Firmware 1.2 7/11/2006 1:40:03 PM  Roger Dawson  
//  Added the code necessary for identifying memory leaks by filename.
//  2 V6 Firmware 1.1 5/31/2006 8:50:25 PM  Roger Dawson  
//  Fixed memory leak and updated the Decode method to accept QString   's.
//  1 V6 Firmware 1.0 5/25/2006 5:27:54 PM  Roger Dawson  
// $
//
// **************************************************************************
#include "Base64.h"
#include <stdlib.h>
// Digits...
static char Base64Digits[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
BOOL CBase64::m_Init = FALSE;
char CBase64::m_DecodeTable[256];
#ifndef PAGESIZE
#define PAGESIZE 4096
#endif
#ifndef ROUNDTOPAGE
#define ROUNDTOPAGE(a) (((a/4096)+1)*4096)
#endif
//****************************************************************************
// CBase64( )
///
/// Constructor
/// 
//****************************************************************************
CBase64::CBase64() : m_pDBuffer(NULL), m_pEBuffer(NULL), m_nDBufLen(0), m_nEBufLen(0) {
}
//****************************************************************************
// ~CBase64( )
///
/// Destructor
/// 
//****************************************************************************
CBase64::~CBase64() {
	if (m_pDBuffer != NULL) {
		free(m_pDBuffer);
		m_pDBuffer = NULL;
	}
	if (m_pEBuffer != NULL) {
		free(m_pEBuffer);
		m_pEBuffer = NULL;
	}
}
//****************************************************************************
// PBYTE DecodedMessage() const 
///
/// Accessor for the decoded message buffer
/// 
//****************************************************************************
PBYTE CBase64::DecodedMessage() const {
	return m_pDBuffer;
}
//****************************************************************************
// PBYTE EncodedMessage() const
///
/// Accessor for the encoded message buffer
/// 
//****************************************************************************
PBYTE CBase64::EncodedMessage() const {
	return m_pEBuffer;
}
//****************************************************************************
// bool AllocEncode(DWORD nSize)
///
/// Method that allocates an appropriately sized buffer for encoding
/// 
/// @returns - False if the memory failed to get allocated, otherwise true
///
//****************************************************************************
bool CBase64::AllocEncode(DWORD nSize) {
	bool allocatedMemOk = true;
	if (m_nEBufLen < nSize) {
		if (m_pEBuffer != NULL) {
			free(m_pEBuffer);
		}
		m_nEBufLen = ROUNDTOPAGE(nSize);
		m_pEBuffer = (BYTE*) malloc(m_nEBufLen);
	}
	// check the memory is allocated ok
	if (m_pEBuffer != NULL) {
		::ZeroMemory(m_pEBuffer, m_nEBufLen);
	} else {
		// the memory did not get allocated - zero the buffer length
		m_nEBufLen = 0;
		// check the passed in size wasn't zero
		if (nSize > 0) {
			allocatedMemOk = false;
		}
	}
	m_nEDataLen = 0;
	return allocatedMemOk;
}
//****************************************************************************
// bool AllocDecode(DWORD nSize)
///
/// Method that allocates an appropriately sized buffer for decoding
/// 
/// @returns - False if the memory failed to get allocated, otherwise true
///
//****************************************************************************
bool CBase64::AllocDecode(DWORD nSize) {
	bool allocatedMemOk = true;
	if (m_nDBufLen < nSize) {
		if (m_pDBuffer != NULL) {
			free(m_pDBuffer);
		}
		m_nDBufLen = ROUNDTOPAGE(nSize);
		m_pDBuffer = (BYTE*) malloc(m_nDBufLen);
	}
	// check the memory is allocated ok
	if (m_pDBuffer != NULL) {
		::ZeroMemory(m_pDBuffer, m_nDBufLen);
	} else {
		// the memory did not get allocated - zero the buffer length
		m_nDBufLen = 0;
		// check the passed in size wasn't zero
		if (nSize > 0) {
			allocatedMemOk = false;
		}
	}
	m_nDDataLen = 0;
	return allocatedMemOk;
}
//****************************************************************************
// bool SetEncodeBuffer(const PBYTE pBuffer, DWORD nBufLen)
///
/// Method that copies data into the encoded buffer
/// 
/// @returns - False if the memory failed to get allocated, otherwise true
///
//****************************************************************************
bool CBase64::SetEncodeBuffer(const PBYTE pBuffer, DWORD nBufLen) {
	DWORD i = 0;
	// attempt to allocate the encoder memory
	if (AllocEncode(nBufLen)) {
		while (i < nBufLen) {
			if (!_IsBadMimeChar(pBuffer[i])) {
				m_pEBuffer[m_nEDataLen] = pBuffer[i];
				m_nEDataLen++;
			}
			i++;
		}
		return true;
	} else {
		// failed to allocate the memory
		return false;
	}
}
//****************************************************************************
// bool SetDecodeBuffer(const PBYTE pBuffer, DWORD nBufLen)
///
/// Method that copies data into the decoded buffer
/// 
/// @returns - False if the memory failed to get allocated, otherwise true
///
//****************************************************************************
bool CBase64::SetDecodeBuffer(const PBYTE pBuffer, DWORD nBufLen) {
	// attempt to allocate the decoder memory
	if (AllocDecode(nBufLen)) {
		::CopyMemory(m_pDBuffer, pBuffer, nBufLen);
		m_nDDataLen = nBufLen;
		return true;
	} else {
		// failed to allocate the memory
		return false;
	}
}
//****************************************************************************
// bool CBase64::Encode(const PBYTE pBuffer, DWORD nBufLen)
///
/// Method used to encode some data ready for sending to an email server
/// 
/// @returns - true if the operation was successful, false if not
///
//****************************************************************************
bool CBase64::Encode(const PBYTE pBuffer, DWORD nBufLen) {
	bool encodeSuccessful = true;
	if (SetDecodeBuffer(pBuffer, nBufLen)) {
		if (AllocEncode(nBufLen * 2)) {
			TempBucket Raw;
			DWORD nIndex = 0;
			while ((nIndex + 3) <= nBufLen) {
				Raw.Clear();
				::CopyMemory(&Raw, m_pDBuffer + nIndex, 3);
				Raw.nSize = 3;
				_EncodeToBuffer(Raw, m_pEBuffer + m_nEDataLen);
				nIndex += 3;
				m_nEDataLen += 4;
			}
			if (nBufLen > nIndex) {
				Raw.Clear();
				Raw.nSize = (BYTE) (nBufLen - nIndex);
				::CopyMemory(&Raw, m_pDBuffer + nIndex, nBufLen - nIndex);
				_EncodeToBuffer(Raw, m_pEBuffer + m_nEDataLen);
				m_nEDataLen += 4;
			}
			encodeSuccessful = true;
		} else {
			// failed to allocate the encode buffer memory
			encodeSuccessful = false;
		}
	} else {
		// failed to allocate the decode buffer memory
		encodeSuccessful = false;
	}
	return encodeSuccessful;
}
//****************************************************************************
// bool CBase64::Encode( QString  strMessage )
///
/// Method used to encode some data ready for sending to an email server
/// 
/// @returns - true if the operation was successful, false if not
///
//****************************************************************************
bool CBase64::Encode(QString strMessage) {
	bool encodeSuccessful = true;
	if (strMessage != "") {
		// convert the string into a char equivalent
		char *pcMessageBuff = new char[strMessage.size() + 1];
		// check the memory was allocated
		if (pcMessageBuff != NULL) {
			size_t pNoOfChars;
			memset(pcMessageBuff, 0, strMessage.size() + 1);
			wcstombs_s(&pNoOfChars, pcMessageBuff, strMessage.size() + 1, strMessage, strMessage.size());
			if (CBase64::Encode(reinterpret_cast<BYTE*>(pcMessageBuff), strMessage.size())) {
				// the operation succeeded
				encodeSuccessful = true;
			} else {
				// the operation failed, presumably due to a lack of memory
				encodeSuccessful = false;
			}
			delete[] pcMessageBuff;
		} else {
			// failed to allocate the memory for the message buffer
			encodeSuccessful = false;
		}
	}
	return encodeSuccessful;
}
//****************************************************************************
// bool Decode(const PBYTE pBuffer, DWORD dwBufLen)
///
/// Method used to decode some data received from an email server
/// 
/// @returns - true if the operation was successful, false if not
///
//****************************************************************************
bool CBase64::Decode(const PBYTE pBuffer, DWORD dwBufLen) {
	bool decodeSuccessful = true;
	if (!CBase64::m_Init)
		_Init();
	if (SetEncodeBuffer(pBuffer, dwBufLen)) {
		// allocate the decode memory, checking it was successful
		if (AllocDecode(dwBufLen)) {
			TempBucket Raw;
			DWORD nIndex = 0;
			while ((nIndex + 4) <= m_nEDataLen) {
				Raw.Clear();
				Raw.nData[0] = CBase64::m_DecodeTable[m_pEBuffer[nIndex]];
				Raw.nData[1] = CBase64::m_DecodeTable[m_pEBuffer[nIndex + 1]];
				Raw.nData[2] = CBase64::m_DecodeTable[m_pEBuffer[nIndex + 2]];
				Raw.nData[3] = CBase64::m_DecodeTable[m_pEBuffer[nIndex + 3]];
				if (Raw.nData[2] == 255)
					Raw.nData[2] = 0;
				if (Raw.nData[3] == 255)
					Raw.nData[3] = 0;
				Raw.nSize = 4;
				_DecodeToBuffer(Raw, m_pDBuffer + m_nDDataLen);
				nIndex += 4;
				m_nDDataLen += 3;
			}
			// If nIndex < m_nEDataLen, then we got a decode message without padding.
			// We may want to throw some kind of warning here, but we are still required
			// to handle the decoding as if it was properly padded.
			if (nIndex < m_nEDataLen) {
				Raw.Clear();
				for (DWORD i = nIndex; i < m_nEDataLen; i++) {
					Raw.nData[i - nIndex] = CBase64::m_DecodeTable[m_pEBuffer[i]];
					Raw.nSize++;
					if (Raw.nData[i - nIndex] == 255)
						Raw.nData[i - nIndex] = 0;
				}
				_DecodeToBuffer(Raw, m_pDBuffer + m_nDDataLen);
				m_nDDataLen += (m_nEDataLen - nIndex);
			}
		} else {
			// the decode was a failure because the memory could not get allocated
			decodeSuccessful = false;
		}
	} else {
		// the decode was a failure because the memory could not get allocated
		decodeSuccessful = false;
	}
	return decodeSuccessful;
}
//****************************************************************************
// bool Decode( QString  strMessage )
///
/// Method used to decode some data received from an email server
/// 
/// @returns - true if the operation was successful, false if not
///
//****************************************************************************
bool CBase64::Decode(QString strMessage) {
	bool decodeSuccessful = true;
	if (strMessage != "") {
		// convert the string into a char equivalent
		char *pcMessageBuff = new char[strMessage.size() + 1];
		// check the memory was allocated
		if (pcMessageBuff != NULL) {
			size_t pNoOfChars;
			memset(pcMessageBuff, 0, strMessage.size() + 1);
			wcstombs_s(&pNoOfChars, pcMessageBuff, strMessage.size() + 1, strMessage, strMessage.size());
			if (CBase64::Decode(reinterpret_cast<BYTE*>(pcMessageBuff), strMessage.size())) {
				// the operation succeeded
				decodeSuccessful = true;
			} else {
				// the operation failed, presumably due to a lack of memory
				decodeSuccessful = false;
			}
			delete[] pcMessageBuff;
		} else {
			// failed to allocate the memory for the message buffer
			decodeSuccessful = false;
		}
	}
	return decodeSuccessful;
}
//****************************************************************************
// DWORD _DecodeToBuffer(const TempBucket &Decode, PBYTE pBuffer)
///
/// Decode to buffer method
/// 
//****************************************************************************
DWORD CBase64::_DecodeToBuffer(const TempBucket &Decode, PBYTE pBuffer) {
	TempBucket Data;
	DWORD nCount = 0;
	_DecodeRaw(Data, Decode);
	for (int i = 0; i < 3; i++) {
		pBuffer[i] = Data.nData[i];
		if (pBuffer[i] != 255)
			nCount++;
	}
	return nCount;
}
//****************************************************************************
// void _EncodeToBuffer(const TempBucket &Decode, PBYTE pBuffer)
///
/// _EncodeToBuffer method
/// 
//****************************************************************************
void CBase64::_EncodeToBuffer(const TempBucket &Decode, PBYTE pBuffer) {
	TempBucket Data;
	_EncodeRaw(Data, Decode);
	for (int i = 0; i < 4; i++)
		pBuffer[i] = Base64Digits[Data.nData[i]];
	switch (Decode.nSize) {
	case 1:
		pBuffer[2] = '=';
	case 2:
		pBuffer[3] = '=';
	}
}
//****************************************************************************
// void _DecodeRaw(TempBucket &Data, const TempBucket &Decode)
///
/// Decode raw method
/// 
//****************************************************************************
void CBase64::_DecodeRaw(TempBucket &Data, const TempBucket &Decode) {
	BYTE nTemp;
	Data.nData[0] = Decode.nData[0];
	Data.nData[0] <<= 2;
	nTemp = Decode.nData[1];
	nTemp >>= 4;
	nTemp &= 0x03;
	Data.nData[0] |= nTemp;
	Data.nData[1] = Decode.nData[1];
	Data.nData[1] <<= 4;
	nTemp = Decode.nData[2];
	nTemp >>= 2;
	nTemp &= 0x0F;
	Data.nData[1] |= nTemp;
	Data.nData[2] = Decode.nData[2];
	Data.nData[2] <<= 6;
	nTemp = Decode.nData[3];
	nTemp &= 0x3F;
	Data.nData[2] |= nTemp;
}
//****************************************************************************
// void _EncodeRaw(TempBucket &Data, const TempBucket &Decode)
///
/// Encode raw method
/// 
//****************************************************************************
void CBase64::_EncodeRaw(TempBucket &Data, const TempBucket &Decode) {
	BYTE nTemp;
	Data.nData[0] = Decode.nData[0];
	Data.nData[0] >>= 2;
	Data.nData[1] = Decode.nData[0];
	Data.nData[1] <<= 4;
	nTemp = Decode.nData[1];
	nTemp >>= 4;
	Data.nData[1] |= nTemp;
	Data.nData[1] &= 0x3F;
	Data.nData[2] = Decode.nData[1];
	Data.nData[2] <<= 2;
	nTemp = Decode.nData[2];
	nTemp >>= 6;
	Data.nData[2] |= nTemp;
	Data.nData[2] &= 0x3F;
	Data.nData[3] = Decode.nData[2];
	Data.nData[3] &= 0x3F;
}
//****************************************************************************
// BOOL _IsBadMimeChar(BYTE nData
///
/// Checks for bad mime characters
/// 
//****************************************************************************
BOOL CBase64::_IsBadMimeChar(BYTE nData) {
	switch (nData) {
	case '\r':
	case '\n':
	case '\t':
	case ' ':
	case '\b':
	case '\a':
	case '\f':
	case '\v':
		return TRUE;
	default:
		return FALSE;
	}
}
//****************************************************************************
// void _Init()
///
/// Initialisation decoding table method
/// 
//****************************************************************************
void CBase64::_Init() {
	int i;
	for (i = 0; i < 256; i++)
		CBase64::m_DecodeTable[i] = -2;
	for (i = 0; i < 64; i++) {
		CBase64::m_DecodeTable[Base64Digits[i]] = i;
		CBase64::m_DecodeTable[Base64Digits[i] | 0x80] = i;
	}
	CBase64::m_DecodeTable['='] = -1;
	CBase64::m_DecodeTable['=' | 0x80] = -1;
	CBase64::m_Init = TRUE;
}

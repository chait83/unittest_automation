/// @file
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Email system
/// @n Filename:  EmailData.cpp
/// @n Description: Implementation of the CEmailData class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log:
//  8 Stability Project 1.3.1.3 7/2/2011 4:57:02 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  7 Stability Project 1.3.1.2 7/1/2011 4:38:15 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  6 Stability Project 1.3.1.1 3/17/2011 3:20:23 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  5 Stability Project 1.3.1.0 2/15/2011 3:02:59 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
//  4 V6 Firmware 1.3 3/16/2007 9:04:06 PM  Roger Dawson  
//  Added code that allows us to add multiple file attachments to emails.
//  This has specifically been added for reports.
//  3 V6 Firmware 1.2 3/9/2007 8:24:09 PM Roger Dawson  
//  Addressed a potential problem where the confuration could be accessed
//  by the email system in the middle of a configuration change.
//  2 V6 Firmware 1.1 12/20/2006 3:05:59 PM  Roger Dawson  
//  Phase 3b merges into the main build. Added the ability to embed
//  screenshots in emails.
//  1 V6 Firmware 1.0 5/25/2006 5:27:17 PM  Roger Dawson  
// $
//
// **************************************************************************
#include "EmailData.h"
#include "V6globals.h"
#include "Registry.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//****************************************************************************
// CEmailData(	)
///
/// Default Constructor
///
//****************************************************************************
CEmailData::CEmailData() : m_strTO_ADDRESS(""), m_strFROM_ADDRESS(""), m_strFROM_NAME(""), m_strSUBJECT(""), m_strMESSAGE_BODY(
		""), m_strSMTP_SERVER_NAME(""), m_ulSMTP_SECURITY_MODE(0), m_ulSMTPPortNum(25), m_strAuthUsername(""), m_ulSTARTTLSSupport(
		false), m_strAuthPassword(""), m_bEmbedScreenshot(false), m_ulSerialNo(0), m_strIPAddress(""), m_strFileAttachments(
		"") {
}
//****************************************************************************
// CEmailData( const QString  &rstrTO_ADDRESS,
//				const QString  &rstrFROM_ADDRESS,
//				const QString  &rstrFROM_NAME,
//				const QString  &rstrSUBJECT,
//				const QString  &rstrMESSAGE_BODY,
//				const QString  &rstrSMTP_SERVER_NAME,
//				const ULONG ulSMTP_SECURITY_MODE,
//				const ULONG ulSMTP_PORT_NUM /* = 25 */,
//				const QString  &rstrAUTH_USERNAME /* = QString   ::fromWCharArray("") */,
//				const QString  &rstrAUTH_PASSWORD /* = QString   ::fromWCharArray("") */,
//				const bool bEMBED_SCREENSHOT /* = false */,
//				const QString  &rstrFILES_ATTACHMENTS /* = QString   ::fromWCharArray("") */
//				const ULONG ulbSTARTTLS_SUPPORT /* = false*/)
///
/// Constructor
///
/// @param[in]			const QString  &rstrTO_ADDRESS - The 'to' address
/// @param[in]			const QString  &rstrFROM_ADDRESS - The 'from' address
/// @param[in]			const QString  &rstrFROM_NAME - The 'from' name
/// @param[in]			const QString  &rstrSUBJECT - The subject title
/// @param[in]			const QString  &rstrMESSAGE_BODY - The body of the message
/// @param[in]			const QString  &rstrSMTP_SERVER_NAME - The server name or IP address
/// @param[in]			const ULONG ulSMTP_SECURITY_MODE - The SMTP Server Security mode
/// @param[in]			const ULONG ulSMTP_PORT_NUM - The SMTP port number
/// @param[in]			const QString  &rstrAUTH_USERNAME - The authenticate username
/// @param[in]			const QString  &rstrAUTH_PASSWORD - The authenticate password
/// @param[in]			const bool bEMBED_SCREENSHOT - Flag to indicate if a screenshot should
///						be embedded
/// @param[in]			const QString  &rstrFILES_ATTACHMENTS - The name of files that need to be 
///						attached to the email
/// @param[in]			const bool ulSTARTTLS_SUPPORT - Flag to indicate if STARTLTS command support 
///						for email server
///
//****************************************************************************
CEmailData::CEmailData(const QString &rstrTO_ADDRESS, const QString &rstrFROM_ADDRESS, const QString &rstrFROM_NAME,
		const QString &rstrSUBJECT, const QString &rstrMESSAGE_BODY, const QString &rstrSMTP_SERVER_NAME,
		const ULONG ulSMTP_SECURITY_MODE, const ULONG ulSTARTTLS_SUPPORT /* = false */,
		const ULONG ulSMTP_PORT_NUM /* = 25 */, const QString &rstrAUTH_USERNAME /* = QString   ::fromWCharArray("") */,
		const QString &rstrAUTH_PASSWORD /* = QString   ::fromWCharArray("") */,
		const bool bEMBED_SCREENSHOT /* = false */,
		const QString &rstrFILES_ATTACHMENTS /* = QString   ::fromWCharArray("") */) : m_strTO_ADDRESS(rstrTO_ADDRESS), m_strFROM_ADDRESS(
		rstrFROM_ADDRESS), m_strFROM_NAME(rstrFROM_NAME), m_strSUBJECT(rstrSUBJECT), m_strMESSAGE_BODY(
		rstrMESSAGE_BODY), m_strSMTP_SERVER_NAME(rstrSMTP_SERVER_NAME), m_ulSMTP_SECURITY_MODE(ulSMTP_SECURITY_MODE), m_ulSTARTTLSSupport(
		ulSTARTTLS_SUPPORT), m_ulSMTPPortNum(ulSMTP_PORT_NUM), m_strAuthUsername(rstrAUTH_USERNAME), m_strAuthPassword(
		rstrAUTH_PASSWORD), m_bEmbedScreenshot(bEMBED_SCREENSHOT), m_strFileAttachments(rstrFILES_ATTACHMENTS) {
	// get the serial number
	CGeneralSetupConfig *pkCfg = pSETUP->GetGeneralSetupConfig();
	m_ulSerialNo = pkCfg->GetGenNonVolBlock(CONFIG_COMMITTED)->SerialNumber;
	// get the IP address of this recorder
#ifdef UNDER_CE
	CCommsSetupConfig *pkCommsConfig = pGlbSetup->GetCommsSetupConfig();
	T_PCOMMUNICATIONS ptCommsData = NULL;
	if( pkCommsConfig != NULL )
	{
		ptCommsData = pkCommsConfig->GetCommsBlock( CONFIG_COMMITTED );
		if( ptCommsData->Ethernet.UseStaticIP )
		{
			m_strIPAddress = CStringUtils::PackedIPv4ULongToStr( ptCommsData->Ethernet.IPAddress.L );		// Get static IP address
		}
		else
		{
			m_strIPAddress = CRegistryKey::GetDHCPIPAddress( );
		}
	}
#else
	m_strIPAddress = "195.26.40.36";
#endif
}
//****************************************************************************
// CEmailData( const CEmailData &rkEMAIL_DATA )
///
/// Copy Constructor
///
/// @param[in]			const CEmailData &rkEMAIL_DATA - The email data structure to copy
///
//****************************************************************************
CEmailData::CEmailData(const CEmailData &rkEMAIL_DATA) : m_strTO_ADDRESS(rkEMAIL_DATA.GetToAddress()), m_strFROM_ADDRESS(
		rkEMAIL_DATA.GetFromAddress()), m_strFROM_NAME(rkEMAIL_DATA.GetFromName()), m_strSUBJECT(
		rkEMAIL_DATA.GetSubject()), m_strMESSAGE_BODY(rkEMAIL_DATA.GetMessageBody()), m_strSMTP_SERVER_NAME(
		rkEMAIL_DATA.GetSMTPServerName()), m_ulSMTP_SECURITY_MODE(rkEMAIL_DATA.GetSMTPSecurityMode()), m_ulSMTPPortNum(
		rkEMAIL_DATA.GetSMTPPortNum()), m_strAuthUsername(rkEMAIL_DATA.GetAuthUsername()), m_strAuthPassword(
		rkEMAIL_DATA.GetAuthPassword()), m_bEmbedScreenshot(rkEMAIL_DATA.GetEmbedScreenshot()), m_ulSerialNo(
		rkEMAIL_DATA.GetSerialNo()), m_strIPAddress(rkEMAIL_DATA.GetThisIPAddress()), m_strFileAttachments(
		rkEMAIL_DATA.GetFileAttachments()), m_ulSTARTTLSSupport(rkEMAIL_DATA.GetStartTLSSupport()) {
}
//****************************************************************************
// operator=( const CEmailData &rkEMAIL_DATA )
///
/// = method
///
/// @param[in]			const CEmailData &rkEMAIL_DATA - The email data structure to copy
///
//****************************************************************************
void CEmailData::operator=(const CEmailData &rkEMAIL_DATA) {
	m_strTO_ADDRESS = rkEMAIL_DATA.GetToAddress();
	m_strFROM_ADDRESS = rkEMAIL_DATA.GetFromAddress();
	m_strFROM_NAME = rkEMAIL_DATA.GetFromName();
	m_strSUBJECT = rkEMAIL_DATA.GetSubject();
	m_strMESSAGE_BODY = rkEMAIL_DATA.GetMessageBody();
	m_strSMTP_SERVER_NAME = rkEMAIL_DATA.GetSMTPServerName();
	m_ulSMTP_SECURITY_MODE = rkEMAIL_DATA.GetSMTPSecurityMode();
	m_ulSMTPPortNum = rkEMAIL_DATA.GetSMTPPortNum();
	m_strAuthUsername = rkEMAIL_DATA.GetAuthUsername();
	m_strAuthPassword = rkEMAIL_DATA.GetAuthPassword();
	m_bEmbedScreenshot = rkEMAIL_DATA.GetEmbedScreenshot();
	m_ulSerialNo = rkEMAIL_DATA.GetSerialNo();
	m_strIPAddress = rkEMAIL_DATA.GetThisIPAddress();
	m_strFileAttachments = rkEMAIL_DATA.GetFileAttachments();
	m_ulSTARTTLSSupport = rkEMAIL_DATA.GetStartTLSSupport();
}
//****************************************************************************
// ~CEmailData()
///
/// Destructor
///
//****************************************************************************
CEmailData::~CEmailData() {
}

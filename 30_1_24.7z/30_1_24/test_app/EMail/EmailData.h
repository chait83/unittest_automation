/// @file 
/// **************************************************************************
/// © Honeywell Trendview
/// **************************************************************************
/// @n Module: 		Email system
/// @n Filename:  EmailData.h
/// @n Description: Definition of the CEmailData class
///
// **************************************************************************
// Revision History
// **************************************************************************
// $Log:
//  6 Stability Project 1.3.1.1 7/2/2011 4:57:02 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  5 Stability Project 1.3.1.0 7/1/2011 4:27:45 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  4 V6 Firmware 1.3 3/16/2007 9:04:06 PM  Roger Dawson  
//  Added code that allows us to add multiple file attachments to emails.
//  This has specifically been added for reports.
//  3 V6 Firmware 1.2 3/9/2007 8:24:09 PM Roger Dawson  
//  Addressed a potential problem where the confuration could be accessed
//  by the email system in the middle of a configuration change.
//  2 V6 Firmware 1.1 12/20/2006 3:06:00 PM  Roger Dawson  
//  Phase 3b merges into the main build. Added the ability to embed
//  screenshots in emails.
//  1 V6 Firmware 1.0 5/25/2006 5:28:31 PM  Roger Dawson  
// $
//
// **************************************************************************
#if !defined(AFX_EMAILDATA_H__411F1D8D_3EA7_4ED4_AE80_3D18B15AD5DC__INCLUDED_)
#define AFX_EMAILDATA_H__411F1D8D_3EA7_4ED4_AE80_3D18B15AD5DC__INCLUDED_
#include "Defines.h"
//**CEmailData***********************************************************
///
/// @brief Class used to store email message information
/// 
/// Class used to store email message information
///
//****************************************************************************
class CEmailData {
public:
	// Default Constructor
	CEmailData();
	// Normal Constructor
	CEmailData(const QString &rstrTO_ADDRESS, const QString &rstrFROM_ADDRESS, const QString &rstrFROM_NAME,
			const QString &rstrSUBJECT, const QString &rstrMESSAGE_BODY, const QString &rstrSMTP_SERVER_NAME,
			const ULONG ulSMTP_SECURITY_MODE = 0, const ULONG ulSTARTTLS_SUPPORT = false,
			const ULONG m_ulSMTP_PORT_NUM = 25, const QString &rstrAUTH_USERNAME = "",
			const QString &rstrAUTH_PASSWORD = "", const bool bEMBED_SCREENSHOT = false,
			const QString &rstrFILES_ATTACHMENTS = "");
	// Copy Constructor
	CEmailData(const CEmailData &rkEMAIL_DATA);
	// Equals operator
	void operator=(const CEmailData &rkEMAIL_DATA);
	// Destructor
	virtual ~CEmailData();
	// Accessor Methods
	const QString GetToAddress() const {
		return m_strTO_ADDRESS;
	}
	const QString GetFromAddress() const {
		return m_strFROM_ADDRESS;
	}
	const QString GetFromName() const {
		return m_strFROM_NAME;
	}
	const QString GetSubject() const {
		return m_strSUBJECT;
	}
	const QString GetMessageBody() const {
		return m_strMESSAGE_BODY;
	}
	const QString GetSMTPServerName() const {
		return m_strSMTP_SERVER_NAME;
	}
	const ULONG GetSMTPSecurityMode() const {
		return m_ulSMTP_SECURITY_MODE;
	}
	const ULONG GetSMTPPortNum() const {
		return m_ulSMTPPortNum;
	}
	const QString GetAuthUsername() const {
		return m_strAuthUsername;
	}
	const ULONG GetStartTLSSupport() const {
		return m_ulSTARTTLSSupport;
	}
	const QString GetAuthPassword() const {
		return m_strAuthPassword;
	}
	const bool GetEmbedScreenshot() const {
		return m_bEmbedScreenshot;
	}
	const ULONG GetSerialNo() const {
		return m_ulSerialNo;
	}
	const QString GetThisIPAddress() const {
		return m_strIPAddress;
	}
	const QString GetFileAttachments() const {
		return m_strFileAttachments;
	}
private:
	/// The 'to' address e.g. Joe.Bloggs@Yokogowa.com
	QString m_strTO_ADDRESS;
	/// The 'from' address e.g. Roger.Dawson@Honeywell.com
	QString m_strFROM_ADDRESS;
	/// The 'from name' e.g. Roger Dawson
	QString m_strFROM_NAME;
	/// The subject
	QString m_strSUBJECT;
	/// The message body
	QString m_strMESSAGE_BODY;
	/// The server name or IP address
	QString m_strSMTP_SERVER_NAME;
	ULONG m_ulSMTP_SECURITY_MODE;
	/// The port number of the email server
	ULONG m_ulSMTPPortNum;
	/// The username if using a server that requires authentification
	QString m_strAuthUsername;
	/// The password if using a server that requires authentification
	QString m_strAuthPassword;
	/// Flag indicating if a screen shot should be embedded
	bool m_bEmbedScreenshot;
	/// The recorder serial number
	ULONG m_ulSerialNo;
	// The recorder IP Address
	QString m_strIPAddress;
	// The filenames to embed delimitted by CStringUtils::ms_strDELIMITTER 
	QString m_strFileAttachments;
	ULONG m_ulSTARTTLSSupport;
};
#endif // !defined(AFX_EMAILDATA_H__411F1D8D_3EA7_4ED4_AE80_3D18B15AD5DC__INCLUDED_)

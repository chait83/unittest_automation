/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	Logging
/// @n Filename: LogDeviceStatus.h
/// @n Desc:	Maintain status between logging device and internal log store
///				
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 25	Stability Project 1.22.1.1	7/2/2011 4:58:25 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 24	Stability Project 1.22.1.0	7/1/2011 4:27:24 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 23	V6 Firmware 1.22		8/30/2006 2:08:18 PM	Martin Miller 
//		Fixed problem with transaction points being reset on a data transfer
//		when the data queues were in recycle.
// 22	V6 Firmware 1.21		6/14/2006 3:32:59 PM	Roger Dawson 
//		Changes to scheduled logging. Now moved fron NV to the CMM setup
//		data. Corresponding setup menu's now also moved to the recorder
//		setup.
// $
//
// ****************************************************************
#ifndef __LOGDEVICESTATUS_H_INCLUDED__
#define __LOGDEVICESTATUS_H_INCLUDED__
#include "SRAM.h"
#include "QMCommon.h"
#include "MessageListServices.h"
#include "ActivityLog.h"
//#define LD_LOG
const USHORT LDS_INVALID_FILE = 0xFFFF;
const USHORT LDS_INVALID_BLOCK = 0xFFFF;
// Used to identify the physical data transfer device
typedef enum {
	LOGDEV_EXT_SD = 0, LOGDEV_USB1, LOGDEV_USB2, LOGDEV_SHARE, LOGDEV_FTP, LOGDEV_MAX_DEVICES // Do nt delete, always at end
} T_LOG_DEVICE;
// Used to identify the transfer confirmation type
typedef enum						// Status type
{
	TYPE_CONFIRMED = 0,				// transfer confirmed
	TYPE_TRANSFERED					// transfered (not confirmed)
} T_STATUS_TYPE;
// Used to identify the Data transfer format type
typedef enum						// Format type
{
	EXPORT_FORMAT_TVENCRYPT = 0,	// Regular Data export(TV Encrypt)
	EXPORT_FORMAT_CSV,				// CSV data export
} T_DATA_EXPORT_FORMAT_TYPE;
/// Status information for a storage device
typedef struct {
	USHORT Status;		/// Do not remove!
	T_QMC_FILE_BLOCK_TRANSACTION ConfirmedDataEndPoint;
	T_QMC_FILE_BLOCK_TRANSACTION TRansferredDataEndPoint;
} T_DEVICE_LOG_STATUS;
/// Status for all storage devices that can be used to retrive data from a queue
typedef struct {
	T_DEVICE_LOG_STATUS devStatus[LOGDEV_MAX_DEVICES];
} T_QDEVICE_STATUS;
/// Non-volatile transfer status structure, device status for each logging channel
typedef struct {
	T_QDEVICE_STATUS channel[V6_MAX_PENS + MAX_MESSAGE_LISTS];
} T_QCHANNEL_STATUS;
//**Class*********************************************************************
///
/// @brief Maintain the status of a logging queue within internal log store
///			with log information on a number of destination devices
/// 
/// This class provides the management of a logging queue instance between the internal
/// data store and a set of external devices, USB, Ext CF, Net Share,FTP etc...
/// it controls the status of the data sent to the devices and maintains the
/// protection of new and transferred but not confirmed data
///
//****************************************************************************
class CLogDeviceStatus {
public:
	static CLogDeviceStatus* CLogDeviceStatus::GetHandle();
	void Initialise();
	BOOL Cleanup();
	// Old API
	BOOL SetStatus(T_LOG_DEVICE device, USHORT instance, T_STATUS_TYPE type, T_QMC_FILE_BLOCK_TRANSACTION location,
			T_DATA_EXPORT_FORMAT_TYPE eExportasprintfType = EXPORT_FORMAT_TVENCRYPT);
	T_QMC_FILE_BLOCK_TRANSACTION* GetStatus(T_LOG_DEVICE device, USHORT instance, T_STATUS_TYPE type,
			T_DATA_EXPORT_FORMAT_TYPE eExportasprintfType = EXPORT_FORMAT_TVENCRYPT);
	BOOL UpdateRecycled(const USHORT Channel, const USHORT FileID, const USHORT BlockID);
	void UpdateTransactoionPoint(T_LOG_DEVICE device, USHORT instance, T_QMC_FILE_BLOCK_TRANSACTION *pTransactionPoint,
			T_DATA_EXPORT_FORMAT_TYPE eExportasprintfType = EXPORT_FORMAT_TVENCRYPT);
	void SaveAllFTPTransactionPoints();
	void ClearRollBack();
	void RollBackIfRequired();
	void RestoreAllFTPTransactionPoints();
	static T_STORAGE_DEVICE LogDeviceToStorageDevice(T_LOG_DEVICE logDevice);
private:					// methods
	CLogDeviceStatus();
	~CLogDeviceStatus();
	void InitStore();
private:					// date
	static CLogDeviceStatus *pInstance;		///< Single instance object pointer
	static HANDLE hCreationMutex;				///< Object creation mutex
	CSRAMManager *m_pSRAM;						///< SRAM manager
	CSRAMRegion *m_pTstore;						///< SRAM region
	CSRAMRegion *m_pTstore_csv;			///< SRAM region for csv transactions
	T_QCHANNEL_STATUS *m_pNV_status;			///< Pointer to the non-volatile RAM region	
	T_QCHANNEL_STATUS *m_pNV_CSVstatus;	///< Pointer to the non-volatile RAM region	for CSV transfer
protected:
	USHORT m_RegionSize;
	QMutex m_hCritical;
	QMutex m_hInitialise;
#ifdef LD_LOG
	CActivityLog *m_ActivityLog;
#endif
};
#endif // __LOGDEVICESTATUS_H_INCLUDED__

#ifndef __QUEUEMONITOR_H_INCLUDED__
#define __QUEUEMONITOR_H_INCLUDED__
#include "LogDeviceStatus.h"
#include "PenManager.h"
#include "LogRec.h"
#include "LogDeviceStatus.h"
#include "ActivityLog.h"
//#define QM_LOG
//**Class*********************************************************************
///
/// @brief Data transfer log queue monitor
///
///		Monitor the status of the logging queues.
///
//****************************************************************************
class CQMonitor {
	friend class CTScheduleThread;
	friend class CTxSchedule;
public: // Methods
	static CQMonitor* GetHandle();
	BOOL CleanUp();
	void Initialise();
	ULONG GetBlocksWaiting() {
		return m_BlocksWaiting;
	}
	;
	ULONG GetPenSeconds() {
		return m_PenSeconds;
	}
	;
	ULONG GetPenQueueSize(USHORT penInstance);
	void LogDeviceRemoved(T_LOG_DEVICE device);
	const BOOL DiskSpaceWarningInPlace(const T_LOG_DEVICE eDEVICE) const {
		return m_bScheduleWarning[eDEVICE];
	}
	void ResetDiskSpaceWarning(const T_LOG_DEVICE eDEVICE) {
		m_bScheduleWarning[eDEVICE] = FALSE;
	}
	void ClearAllNewFTPData();						///< Clear any waiting FTP data
	// Accessor for the blocks per hour variable
	const ULONG GetBlocksUsedPerHour();
private: // Data
	ULONG m_BlocksWaiting;							///< Number of new blocks in the queues
	ULONG m_PenSeconds;								///< Safe pen recording time
	ULONG m_TotalQueueBlocks;						///< Total number of blocks in the queues
	ULONG m_FTPPenSeconds;							///< safe FTP pen recording time
	CDataItemGeneral *m_pInternalHoursToRecycle;	///< Number of hours till a recycle
	CDataItemGeneral *m_pFTPHoursToRecycle;			///< Number of hours till FTP recycle
	ULONG m_PenQueueBlocks[V6_MAX_PENS];			///< number of data blocks in each pen queue
	static CQMonitor *pInstance;					///< Single instance object pointer
	static HANDLE hCreationMutex;					///< Object creation mutex
	BOOL m_Initialised;								///< Object initialisation flag	
	QMutex m_hCritical;
	BOOL m_bScheduleWarning[LOGDEV_MAX_DEVICES];		///< TRUE if a schedule space warning has been issued
	BOOL m_bMediaMissingWarning[LOGDEV_MAX_DEVICES];	///< TRUE if a media missing warning has been issued
	T_STORAGE_DEVICE m_storageDevice;				///< Current schedule warning storage device
#ifdef QM_LOG
	CActivityLog *m_ActivityLog;
#endif
	/// Variable used to store the approximate number of logging blocks being used per hour
	FLOAT m_fBlockPerHour;
private: // Methods
	CQMonitor();
	~CQMonitor();
	void ClearNumBlocksWaiting();
	void Update(T_LOG_DEVICE device, const bool bDISK_FULL);		///< Update ququq stats
	void ClearAllNewData();						///< Update the transaction pointes to the newest block
	void PrepareTransferAll();						///< Prepare to transfer all data (re-scale the progress bar)
	BOOL CheckNextScheduleSpace(const bool bDISK_FULL);	///< Check media space required for the NEXT scheduled transfer
	void ClearNewData(T_LOG_DEVICE device);
	ULONG GetNumNewBlocksWaiting(T_LOG_DEVICE device);
	ULONG indexOfShortestPenQueue(T_LOG_DEVICE device);
	LONG GetBlocksleftInQueue(T_LOG_DEVICE device, USHORT penInstance);
	ULONG GetQueueSpaceBlocks(T_LOG_DEVICE device);
	BOOL ValidateTransactionPoint(T_QMC_FILE_BLOCK_TRANSACTION *pTransactionPoint, USHORT QueueHandle);
};
#endif // __QUEUEMONITOR_H_INCLUDED__

#ifndef __LOG_CHANNEL_H_INCLUDED__
#define __LOG_CHANNEL_H_INCLUDED__
#include "TVtime.h"
#include "CMMDefines.h"
#include "V6Config.h"
#include "DataItemBase.h"
#include "DataItemPen.h"
#include "RateControl.h"
#include "BlockControl.h"
#include "LogControl.h"
#include "BasicMaxMinAve.h"
const short LOGGING_BYTE = 0;
const short FLUSH_THRESHOLD = 4;
typedef enum {
	DATATYPE_PEN, DATATYPE_TOTAL, DATATYPE_COUNTER, DATATYPE_MESSAGE
} T_LOG_DATATYPE;
typedef struct {
	T_LOGRECORDVARS LogRecVars[V6_MAX_PENS];
} T_LOGGING_NV;
//**Class*********************************************************************
///
/// @brief 
/// 
///
//****************************************************************************
class CLogChannel {
public:
	CLogChannel();
	~CLogChannel();
	BOOL SetConfig(T_LOG_DATATYPE Type, USHORT Instance);								/// Initialise log channel
	BOOL Reading();												/// Push reading
	BOOL StartLog(USHORT uReason, USHORT Session);				/// Start logging
	BOOL RestoreNVState(USHORT uReason, USHORT Session);			/// Restore previous logging state
	BOOL StopLog(BOOL bSaveState);								/// Stop logging
	BOOL FlushData();										/// Flush current data block (need to stop logging first)
	void SetSession(USHORT NewSession) {
		m_Session = NewSession;
	}
	;
	USHORT GetSession() {
		return m_Session;
	}
	;
	ULONG GetSequence() {
		return NV_Sequence.ul;
	}
	;
	void SetSequence(ULONG NewSequence) {
		NV_Sequence.ul = NewSequence;
	}
	;
	// Current log state
	BOOL IsLogging();
	USHORT GetQueueHandle() {
		return m_BlockControl.GetQueueHandle();
	}
	;
	void CheckAndChangeRateIfRequired();
	void RegisterAlarmLogRateRequired() {
		m_UseAlarmRate = TRUE;
	}
	;
	void ClearAlarmLogRateRequired() {
		m_UseAlarmRate = FALSE;
	}
	;
	ULONG CurrentRate();							/// Current log rate in ms-tenths
	BOOL IsContinuous();							/// TRUE if continuous logging, else FALSE
	BOOL IsFuzzy();								/// True if logging as Fuzzy
	BOOL IsMaxMin();								/// True if logging as Max-Min
	BOOL IsAverage();								/// True if logging as Average
	BOOL IsEnabled();								/// TRUE if the pen has been enabled (configured)
	BOOL IsWaitingForAlignment();					/// TRUE if channel is logging and waiting for alignment
	void SetReason(USHORT reason) {
		m_LogControl.SetReason(reason);
	}
	;
private:
	void InitNewBlock();							/// Initialise a new log block
	void ReCreateVars();							/// Re-Create the log record vars after a power loss (etc)
	BOOL m_UseAlarmRate;							/// Use alarm log rate flag
	BOOL m_UseAlarmRateCurrent;						/// Current setting of the use m_UseAlarmRate
	BOOL m_RateHasChanged;							/// True when a rate change is being done
	BOOL m_RequestNew;								/// New data block has been requested
	BOOL m_IsLogging;								/// Channel is logging
	T_LOG_DATATYPE m_DataType;						/// Data type being logged
	USHORT m_Instance;								/// instance (zero based)
	T_PLOGGING m_pLogging;							/// Logging configuration data 
	CDataItem *m_pDataItem;							/// Data Item table pointer
	USHORT m_LogType;								/// Data block type
protected:
	CBasicMaxMin m_MaxMin;							/// Basic Max-Min
	CBasicAverage m_Average;						/// Basic average 
	CLogControl m_LogControl;						/// Log data and style control
	CRateControl m_RateControl;						/// Log rate control
	CBlockControl m_BlockControl;					/// Data block control 
	USHORT m_Session;								/// Current session number
	COMBO_VAR4 NV_Sequence;
	CNVBasicVar *m_pNVSequenceNumber;
	T_LOGRECORD *m_pLogRecord;						/// Pointer to log record vars
	T_LOGRECORDVARS *mp_LogVars;					/// Current log record vars
	T_LOGGING_NV *mpNVData;							/// Non-volatile log status data
	CSRAMManager *mpSRAM;							/// SRAM manager pointer
	CSRAMRegion *mpRegion;							/// SRAM region pointer
	BOOL m_bConfigChanged;							/// Indicated the first process cycle after a configuration chqange
};
#endif // __LOG_CHANNEL_H_INCLUDED__

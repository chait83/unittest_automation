#ifndef __DATACHANNEL_H_INCLUDED__
#define __DATACHANNEL_H_INCLUDED__
#include "TVtime.h"
#include "logrec.h"
#include "LogDeviceStatus.h"
//**Class*********************************************************************
///
/// @brief 
/// 
///
//****************************************************************************
class CDataChannel {
public:
	CDataChannel();
	~CDataChannel();
	T_QMC_FILE_BLOCK_TRANSACTION LocateBlockByTime(struct TV5Time blocktime);
	void* LocateBlockByID(T_QMC_FILE_BLOCK_TRANSACTION location);
	void* GetNextBlock(T_QMC_FILE_BLOCK_TRANSACTION currentblock);
private:
};
#endif // __DATACHANNEL_H_INCLUDED__

/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 Log record utilities
/// @n Logrec.cpp
/// @n Utilities for maintaining log records.
/// @author MM
/// @date 27/01/2005
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
//  38  Stability Project 1.33.1.3 7/2/2011 4:58:26 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  37  Stability Project 1.33.1.2 7/1/2011 4:38:27 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  36  Stability Project 1.33.1.1 3/17/2011 3:20:28 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  35  Stability Project 1.33.1.0 2/15/2011 3:03:15 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////
#include "LogRec.h"
#include "V6globals.h"
#include "V6defines.h"
#include "ffconversionInfo.h"
#include <float.h>
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
// table of Control Type sizes, indexed using LogStyle (0 or 1) and ControlType
UCHAR Glb_ControlTypeSizes[2][8] = { { 0, sizeof(T_ABSOLUTECONTROL), sizeof(T_SHORTCONTROL), sizeof(T_LONGCONTROL), 0,
		0, sizeof(T_SHORTRATECONTROL), sizeof(T_LONGRATECONTROL) },
{ 0, sizeof(T_ABSOLUTECONTROL),  // ONLY in Header of record
		sizeof(T_ABSOLUTECONTROL),  // ONLY in Header of record
		sizeof(T_SHORTLOECONTROL), sizeof(T_LONGLOECONTROL), sizeof(T_ABSOLUTECONTROL),  // Fuzzy
		0, 0 } };
// table of DataType sizes, indexed using Device (0 or 1) and 
UCHAR Glb_DataTypeSizes[2][8] = { { 2, 2, 2, 2, 4, 8, 1, 16 }, { 0, 2, 4, 8, 4, 8, 16, 0 } };
//****************************************************************************
/// LogRecord utility: class constructor
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
CLogRec::CLogRec() {
	return;
}
//****************************************************************************
/// LogRecord utility: class destructor
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
CLogRec::~CLogRec() {
	return;
}
//****************************************************************************
/// LogRecord utility: class initialisation
///
/// @param[in] 		lq - pointer to the base log queue
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
void CLogRec::Initialise() {
	return;
}
//****************************************************************************
/// LogRecord utility: Insert a time into the record header (FOR CONTINUOUS READINGS)
///
/// @param[in]		pLogRecordVars - pointer to log record vars
/// @param[in]		pLogRecord - Pointer to current log record
/// @param[in] 		Time - pointer to time to insert
///
/// @return			None
///
/// @note Initialises the log record start and end time
//****************************************************************************
void CLogRec::SetStartTime(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, T_TV5TIME *Time) {
	pLogRecord->Header.StartTime = *Time;	// init log record start time
	pLogRecordVars->LastTime = *Time;		// init running lasttime variable.
	return;
}
//****************************************************************************
/// LogRecord utility: Adds a Continuous reading
///
/// @param[in]		pLogRecordVars - pointer to log record vars
/// @param[in]		pLogRecord - Pointer to current log record
/// @param[in] 		reading - reading to add
///
/// @return			TRUE if record is full, else FALSE
///
/// @note --- Delete if not requried ---
//****************************************************************************
BOOL CLogRec::AddContReading(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, float reading) {
	// no need to check if we can add the reading, since there will ALWAYS be room
	*((float*) &pLogRecord->Data[pLogRecordVars->FreeDataPos]) = reading;		// add the reading
	pLogRecordVars->FreeDataPos += pLogRecordVars->DataSize;
	if (pLogRecordVars->CurrentControl->ToControl)					// if this is not the first reading
		AddPosmstenths(&pLogRecordVars->LastTime, pLogRecordVars->Rate);		// increment the time of the reading
	pLogRecordVars->CurrentControl->ToControl++;					// inc number of readings in the current control
	// now see if there will be room for another reading
	if (V6_SIZE_OF_DATA_PART - pLogRecordVars->FreeDataPos - pLogRecordVars->DataSize < 2) {
		// will not be room, so record is full (or as good as).
		pLogRecord->Header.EndTime = pLogRecordVars->LastTime;	// copy the last time to the header.
		pLogRecord->Header.Incomplete = COMPLETE;					// mark record as complete
		return TRUE;
	} else
		return FALSE;
	return FALSE;
}
//****************************************************************************
/// LogRecord utility: Adds a Continuous Max Min reading
///
/// @param[in]		pLogRecordVars - pointer to log record vars
/// @param[in]		pLogRecord - Pointer to current log record
/// @param[in] 		max - max reading to add
/// @param[in] 		min - min reading to add
///
/// @return			TRUE if record is full, else FALSE
///
/// @note --- Delete if not requried ---
//****************************************************************************
BOOL CLogRec::AddContMaxMin(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, float max, float min) {
	// no need to check if we can add the reading, since there will ALWAYS be room
	*((float*) &pLogRecord->Data[pLogRecordVars->FreeDataPos]) = max; // add the max
	*(1 + (float*) &pLogRecord->Data[pLogRecordVars->FreeDataPos]) = min; // and the min
	pLogRecordVars->FreeDataPos += pLogRecordVars->DataSize;
	if (pLogRecordVars->CurrentControl->ToControl) // if this is not the first reading
		AddPosmstenths(&pLogRecordVars->LastTime, pLogRecordVars->Rate); // increment the time of the reading
	pLogRecordVars->CurrentControl->ToControl++; // inc number of readings in the current control
	// now see if there will be room for another reading
	if (V6_SIZE_OF_DATA_PART - pLogRecordVars->FreeDataPos - pLogRecordVars->DataSize < 4) {
		// will not be room, so record is full (or as good as).
		pLogRecord->Header.EndTime = pLogRecordVars->LastTime; // copy the last time to the header.
		AddPosmstenths(&pLogRecord->Header.EndTime, pLogRecordVars->Rate); // FOR MAXMIN the EndTime is the
		// time at the END of the reading.
		pLogRecord->Header.Incomplete = COMPLETE; // mark record as complete
		return TRUE;
	}
	return FALSE;
}
//****************************************************************************
/// LogRecord utility: Adds a Fuzzy Logging reading and multiplier
///
/// @param[in]		pLogRecordVars - pointer to log record vars
/// @param[in]		pLogRecord - Pointer to current log record
/// @param[in] 		multiplier - gap multiplier
/// @param[in] 		reading - reading to add
///
/// @return			TRUE if record is full, else FALSE
///
/// @note --- Delete if not requried ---
//****************************************************************************
BOOL CLogRec::AddFuzzyReadingByGap(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, UCHAR multiplier,
		float reading) {
	// insert the multiplier
	*((UCHAR*) &pLogRecord->Data[pLogRecordVars->FreeDataPos]) = multiplier;
	pLogRecordVars->FreeDataPos += pLogRecordVars->TimeSize;
	// and the reading
	//*((float*)&pLogRecord->Data[pLogRecordVars->FreeDataPos]) = reading; 
	memcpy(&pLogRecord->Data[pLogRecordVars->FreeDataPos], &reading, pLogRecordVars->DataSize);
	pLogRecordVars->FreeDataPos += pLogRecordVars->DataSize;
	AddPosmstenths(&pLogRecordVars->LastTime, pLogRecord->Header.Rate * multiplier);
	(UCHAR) pLogRecordVars->CurrentControl->ToControl++; // inc number of readings in the current control
	// now see if there will be room for another reading
	if (V6_SIZE_OF_DATA_PART - pLogRecordVars->FreeDataPos - pLogRecordVars->DataSize - pLogRecordVars->TimeSize < 0) {
		pLogRecord->Header.EndTime = pLogRecordVars->LastTime; // copy the last time to the header.
		// will not be room, so record is full (or as good as).
		pLogRecord->Header.Incomplete = COMPLETE; // mark record as complete
		return TRUE;
	}
	return FALSE;
}
//****************************************************************************
/// LogRecord utility: Adds a reading to a fuzzy log queue
///
/// @param[in]		pLogRecordVars - pointer to log record vars
/// @param[in]		pLogRecord - Pointer to current log record
/// @param[in]		timestamp - log point real-time
/// @param[in] 		Reading - reading to add
///
/// @return			always FALSE
///
/// @note --- Delete if not requried ---
//****************************************************************************
BOOL CLogRec::AddFuzzyReading(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, T_TV5TIME *timestamp,
		T_FUZZY_CONTROL *pFuzzyControl, float Reading) {
	BOOL ReturnCode = FALSE;
	// Indicate that this fuzzy pen is being updated
	pFuzzyControl->UpdateInProgress = TRUE;
	pFuzzyControl->CycleCount++;
	switch (pFuzzyControl->Status) {
	case LOG_STATE_RUNNING: {	// check if the value is within the pipe, or it's time for a break.
		if ((FLT_MAX == Reading || -FLT_MAX == Reading) && pLogRecordVars->ReadingCount < FUZZY_BREAK) {
			// In an error state, maintain the current pipe...
			if (Reading != pLogRecordVars->PipeEnd) {
				// If the pipe has just started, make sure it starts with a break
				pLogRecordVars->PipeEnd = Reading;
				ReturnCode = PipeBreak(pLogRecordVars, pLogRecord, pFuzzyControl, Reading);
			} else {
				ReturnCode = UpdatePipeInvalid(Reading, pFuzzyControl, pLogRecordVars);
			}
		} else if ((Reading > pFuzzyControl->PipeMax) || (Reading < pFuzzyControl->PipeMin)
				|| pLogRecordVars->ReadingCount == FUZZY_BREAK) {
			ReturnCode = PipeBreak(pLogRecordVars, pLogRecord, pFuzzyControl, Reading);
		} else {
			ReturnCode = UpdatePipe(Reading, pFuzzyControl, pLogRecordVars);
		}
		break;
	}
	case LOG_STATE_SECOND: {	// second value available, set the angle of dangle
		if ( FLT_MAX == Reading || -FLT_MAX == Reading) {
			// In an error state, maintain a flat line
			pLogRecordVars->PipeEnd = 0.0;
			pFuzzyControl->Direction = 0.0;
			pFuzzyControl->Status = LOG_STATE_RUNNING;
			pFuzzyControl->Prediction = Reading;
			ReturnCode = UpdatePipeInvalid(Reading, pFuzzyControl, pLogRecordVars);
		} else {
			pFuzzyControl->Direction = (Reading - pLogRecordVars->PipeEnd);
			pFuzzyControl->Status = LOG_STATE_RUNNING;
			(float) pFuzzyControl->Prediction = (float) (Reading + pFuzzyControl->Direction);
			ReturnCode = UpdatePipe(Reading, pFuzzyControl, pLogRecordVars);
		}
		break;
	}
	case LOG_STATE_INITIAL: {
		pFuzzyControl->Status = LOG_STATE_SECOND;
		pLogRecordVars->ReadingCount = 0;
		(UCHAR) pLogRecordVars->CurrentControl->ToControl = 1;
		pLogRecordVars->PipeEnd = Reading;
		// Initialise the midpiint stuff
		pFuzzyControl->LogPoint[0] = pFuzzyControl->LogPoint[1] = pFuzzyControl->LogPoint[2] = NULL;
		pLogRecordVars->MaxReading.TimeOffset = pLogRecordVars->MinReading.TimeOffset =
				pLogRecordVars->LastBandB.TimeOffset = 0;
		pLogRecordVars->MaxReading.Reading = pLogRecordVars->MinReading.Reading = pLogRecordVars->LastBandB.Reading =
				Reading;
		// set the base value
		*((FLOAT*) &pLogRecord->Data[pLogRecordVars->FreeDataPos]) = Reading;
		pLogRecordVars->FreeDataPos += pLogRecordVars->DataSize;
		break;
	}
	default:
		// Doh!
		break;
	}
	pFuzzyControl->UpdateInProgress = FALSE;
	return ReturnCode;
}
//****************************************************************************
/// Initialise a fuzzy control
///
/// @return			none
//****************************************************************************
void CLogRec::InitFuzzyControl(T_PLOGGING pLogging, T_FUZZY_CONTROL *pFuzzyControl) {
	if (NULL != pLogging) {
		if (LOGTYPE_FUZZY == pLogging->LogType) {
			pFuzzyControl->Status = LOG_STATE_INITIAL;
			// store fuzzy parameters for later use.
			pFuzzyControl->UseAutoFit = pLogging->UseFuzzyAutoFit;
			pFuzzyControl->UseSecondBand = pLogging->UseFuzzyBand2;
			pFuzzyControl->FirstBand = pLogging->FBand1;
			pFuzzyControl->SecondBand = pLogging->FBand2;
			pFuzzyControl->CycleCount = 1L;
			pFuzzyControl->PipeCount = 1L;
			// Setup a conversion structure to map a %age range to then engineering value range 
			class CFFConversionInfo conv;
			conv.CalcFConvInfo(PERCENT_0, PERCENT_100, m_penZero, m_penSpan);
			// Calc firstband from %age of total span to a magnitude in engineering values
			pFuzzyControl->FirstBand = conv.CalcDestMagnitude(pLogging->FBand1) / 2;
			// Calc Seconds, if used, from %age of total span to a magnitude in engineering values
			if (pFuzzyControl->UseSecondBand == TRUE)
				pFuzzyControl->SecondBand = conv.CalcDestMagnitude(pLogging->FBand2) / 2;
			else
				pFuzzyControl->SecondBand = 0;
		}
	}
	return;
}
//****************************************************************************
/// Reset a fuzzy control
///
/// @return			none
//****************************************************************************
void CLogRec::ResetFuzzyControl(T_PLOGGING pLogging, T_FUZZY_CONTROL *pFuzzyControl) {
	if (NULL != pLogging) {
		if (LOGTYPE_FUZZY == pLogging->LogType) {
			pFuzzyControl->Status = LOG_STATE_INITIAL;
			pFuzzyControl->CycleCount = 1L;
			pFuzzyControl->PipeCount = 1L;
		}
	}
	return;
}
//****************************************************************************
/// LogRecord utility: Calculate the packing efficiency of a fuzzy log
///
/// @return			packing efficiency 0-100% (ish)
///
/// @note --- Delete if not requried ---
//****************************************************************************
float CLogRec::FuzzyEfficiency(T_FUZZY_CONTROL *pFuzzyControl) {
	ULONG Index;
	Index = pFuzzyControl->PipeCount + (pFuzzyControl->PipeCount >> 1);
	return (float) (pFuzzyControl->CycleCount / Index);
}
//****************************************************************************
/// LogRecord utility: predicts where the next fuzzy point should be
///
/// @return			predicted fuzzy log point
///
/// @note --- Delete if not requried ---
//****************************************************************************
float CLogRec::FuzzyPrediction(T_FUZZY_CONTROL *pFuzzyControl) {
	return pFuzzyControl->Prediction;
}
//****************************************************************************
/// LogRecord utility: Fuzzy pipe has been broken, store it, and start a new one
///
/// @param[in]		pLogRecordVars - pointer to log record vars
/// @param[in]		pLogRecord - Pointer to current log record
/// @param[in] 		Reading - reading which broke the pipe
///
/// @return			TRUE if record is full, else FALSE
///
/// @note --- Delete if not requried ---
//****************************************************************************
BOOL CLogRec::PipeBreak(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, T_FUZZY_CONTROL *pFuzzyControl,
		float Reading) {
	BOOL ReturnCode = FALSE;
	UCHAR PointCount = 0;
	UCHAR ReadingCount = 0;
	UCHAR midPoints = 1;
	if (pFuzzyControl->UseAutoFit == 1)
		midPoints += 2;
	if (pFuzzyControl->UseSecondBand == 1)
		midPoints++;
	// Reading is outside the pipe, or a pipe break.
	pFuzzyControl->PipeCount++;
	// decide which reading to use first
	SortmidpointReading(pFuzzyControl, pLogRecordVars);
	while (PointCount < 3 && pFuzzyControl->LogPoint[PointCount] != NULL) {
		// ensure we don't put two reading down at the same time mark
		if (pFuzzyControl->LogPoint[PointCount]->TimeOffset > ReadingCount) {
			AddFuzzyReadingByGap(pLogRecordVars, pLogRecord,
					pFuzzyControl->LogPoint[PointCount]->TimeOffset - ReadingCount,
					pFuzzyControl->LogPoint[PointCount]->Reading);
			ReadingCount = pFuzzyControl->LogPoint[PointCount++]->TimeOffset;
		} else
			PointCount++;
	}
	pLogRecordVars->ReadingCount -= ReadingCount;
	if (pLogRecordVars->ReadingCount != (UCHAR) 0)
		AddFuzzyReadingByGap(pLogRecordVars, pLogRecord, pLogRecordVars->ReadingCount, pLogRecordVars->PipeEnd);
	// Make sure there is enough space for the next reading
	if ((UCHAR) pLogRecordVars->CurrentControl->ToControl + midPoints >= V6_FUZZY_LOG_POINTS) {
		pLogRecord->Header.EndTime = pLogRecordVars->LastTime; // copy the last time to the header.
		ReturnCode = TRUE;
	} else {
		if ( FLT_MAX == Reading || -FLT_MAX == Reading) {
			// Reading has hit float max or -float max
			pFuzzyControl->Direction = 0.0;
			pLogRecordVars->ReadingCount = 1;
			pLogRecordVars->PipeEnd = Reading;
			pFuzzyControl->PipeMax = Reading;
			pFuzzyControl->PipeMin = Reading;
		} else {
			// start of a new pipe.....
			pFuzzyControl->Direction = (Reading - pLogRecordVars->PipeEnd);
			pLogRecordVars->ReadingCount = 1;
			// calculate the next value
			pFuzzyControl->Prediction = Reading + pFuzzyControl->Direction;
			// calculate the next value limits
			pLogRecordVars->PipeEnd = Reading;
			pFuzzyControl->PipeMax = (pFuzzyControl->Prediction) + pFuzzyControl->FirstBand;
			pFuzzyControl->PipeMin = (pFuzzyControl->Prediction) - pFuzzyControl->FirstBand;
		}
	}
	pFuzzyControl->LogPoint[0] = pFuzzyControl->LogPoint[1] = pFuzzyControl->LogPoint[2] = NULL;
	pLogRecordVars->MaxReading.TimeOffset = pLogRecordVars->MinReading.TimeOffset =
			pLogRecordVars->LastBandB.TimeOffset = 0;
	pLogRecordVars->MaxReading.Reading = pLogRecordVars->MinReading.Reading = pLogRecordVars->LastBandB.Reading =
			Reading;
	return ReturnCode;
}
//****************************************************************************
/// LogRecord utility: Add a reading to an existing fuzzy pipe
///
/// @param[in] 		Reading - reading to add
///
/// @return			Always FALSE
///
/// @note --- Delete if not requried ---
//****************************************************************************
BOOL CLogRec::UpdatePipe(float Reading, T_FUZZY_CONTROL *pFuzzyControl, T_LOGRECORDVARS *pLogRecordVars) {
	BOOL ReturnCode = FALSE;
	pLogRecordVars->PipeEnd = Reading;
	pLogRecordVars->ReadingCount++;
	if (pFuzzyControl->UseAutoFit == 1) {
		if (Reading < pLogRecordVars->MinReading.Reading) {
			pLogRecordVars->MinReading.Reading = Reading;
			pLogRecordVars->MinReading.TimeOffset = pLogRecordVars->ReadingCount;
		} else if (Reading > pLogRecordVars->MaxReading.Reading) {
			pLogRecordVars->MaxReading.Reading = Reading;
			pLogRecordVars->MaxReading.TimeOffset = pLogRecordVars->ReadingCount;
		}
	}
	if (pFuzzyControl->UseSecondBand == 1) {
		// Update band B <<
		if (Reading < (pFuzzyControl->Prediction) + pFuzzyControl->SecondBand
				&& Reading > (pFuzzyControl->Prediction) - pFuzzyControl->SecondBand) {
			pLogRecordVars->LastBandB.Reading = Reading;
			pLogRecordVars->LastBandB.TimeOffset = pLogRecordVars->ReadingCount;
		}
	}
	pFuzzyControl->Prediction = pFuzzyControl->Prediction + pFuzzyControl->Direction;
	// calculate the next value limits
	pFuzzyControl->PipeMax = (pFuzzyControl->Prediction) + pFuzzyControl->FirstBand;
	pFuzzyControl->PipeMin = (pFuzzyControl->Prediction) - pFuzzyControl->FirstBand;
	return ReturnCode;
}
//****************************************************************************
/// LogRecord utility: Add a reading to an existing fuzzy pipe
///
/// @param[in] 		Reading - reading to add
///
/// @return			Always FALSE
//****************************************************************************
BOOL CLogRec::UpdatePipeInvalid(float Reading, T_FUZZY_CONTROL *pFuzzyControl, T_LOGRECORDVARS *pLogRecordVars) {
	BOOL ReturnCode = FALSE;
	pLogRecordVars->PipeEnd = Reading;
	pLogRecordVars->ReadingCount++;
	pFuzzyControl->LogPoint[0] = pFuzzyControl->LogPoint[1] = pFuzzyControl->LogPoint[2] = NULL;
	pLogRecordVars->MaxReading.TimeOffset = pLogRecordVars->MinReading.TimeOffset =
			pLogRecordVars->LastBandB.TimeOffset = 0;
	pLogRecordVars->MaxReading.Reading = pLogRecordVars->MinReading.Reading = pLogRecordVars->LastBandB.Reading =
			Reading;
	pFuzzyControl->Prediction = 0;
	pFuzzyControl->Direction = 0;
	// calculate the next value limits
	pFuzzyControl->PipeMax = +pFuzzyControl->FirstBand;
	pFuzzyControl->PipeMin = -pFuzzyControl->FirstBand;
	return ReturnCode;
}
//****************************************************************************
/// LogRecord utility: Flush a fuzzy log block
///
/// @return			Always FALSE
///
/// @note --- Delete if not requried ---
//****************************************************************************
BOOL CLogRec::FlushFuzzyLogBlock(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord,
		T_FUZZY_CONTROL *pFuzzyControl) {
	BOOL ReturnCode = FALSE;
	UCHAR PointCount = 0;
	UCHAR ReadingCount = 0;
	UCHAR midPoints = 1;
	if (pFuzzyControl->UseAutoFit == 1)
		midPoints += 2;
	if (pFuzzyControl->UseSecondBand == 1)
		midPoints++;
	// Reading is outside the pipe, or a pipe break.
	pFuzzyControl->PipeCount++;
	// decide which reading to use first
	if (SortmidpointReading(pFuzzyControl, pLogRecordVars)) {
		while (PointCount < 3 && pFuzzyControl->LogPoint[PointCount] != NULL) {
			// ensure we don't put two reading down at the same time mark
			if (pFuzzyControl->LogPoint[PointCount]->TimeOffset > ReadingCount) {
				AddFuzzyReadingByGap(pLogRecordVars, pLogRecord,
						pFuzzyControl->LogPoint[PointCount]->TimeOffset - ReadingCount,
						pFuzzyControl->LogPoint[PointCount]->Reading);
				ReadingCount = pFuzzyControl->LogPoint[PointCount++]->TimeOffset;
			} else
				PointCount++;
		}
		pLogRecordVars->ReadingCount -= ReadingCount;
	}
	if (pLogRecordVars->ReadingCount != (UCHAR) 0)
		AddFuzzyReadingByGap(pLogRecordVars, pLogRecord, pLogRecordVars->ReadingCount, pLogRecordVars->PipeEnd);
	pLogRecord->Header.EndTime = pLogRecordVars->LastTime;		// copy the last time to the header.
	pLogRecord->Header.Incomplete = COMPLETE;					// mark record as complete
	pFuzzyControl->Status = LOG_STATE_INITIAL;
	pFuzzyControl->LogPoint[0] = pFuzzyControl->LogPoint[1] = pFuzzyControl->LogPoint[2] = NULL;
	pLogRecordVars->MaxReading.TimeOffset = pLogRecordVars->MinReading.TimeOffset =
			pLogRecordVars->LastBandB.TimeOffset = 0;
	pLogRecordVars->MaxReading.Reading = pLogRecordVars->MinReading.Reading = pLogRecordVars->LastBandB.Reading = 0;
	return ReturnCode;
}
//****************************************************************************
/// LogRecord utility: Set Fuzzy midpoint reading pointers in the right order
///
/// @return			Always FALSE
///
/// @note --- Delete if not requried ---
//****************************************************************************
BOOL CLogRec::SortmidpointReading(T_FUZZY_CONTROL *pFuzzyControl, T_LOGRECORDVARS *pLogRecordVars) {
	UCHAR PointCount = 0;
	T_FUZZY_READING *midPoint = NULL;
	if (pLogRecordVars->MaxReading.TimeOffset > 0)
		pFuzzyControl->LogPoint[PointCount++] = &pLogRecordVars->MaxReading;
	if (pLogRecordVars->MinReading.TimeOffset > 0)
		pFuzzyControl->LogPoint[PointCount++] = &pLogRecordVars->MinReading;
	if (pLogRecordVars->LastBandB.TimeOffset > 0)
		pFuzzyControl->LogPoint[PointCount++] = &pLogRecordVars->LastBandB;
	// We now have the three values set to either a value, or NULL, so sort them
	// there is only one point, so no point in sorting it
	if (PointCount <= 1)
		return FALSE;
	if (pFuzzyControl->LogPoint[0]->TimeOffset > pFuzzyControl->LogPoint[1]->TimeOffset) {
		midPoint = pFuzzyControl->LogPoint[0];
		pFuzzyControl->LogPoint[0] = pFuzzyControl->LogPoint[1];
		pFuzzyControl->LogPoint[1] = midPoint;
	}
	// there are only two points, so sort is complete
	if (PointCount == 2)
		return TRUE;
	// first two are sorted, decide where to stick the third one (ooh, err!)
	if (pFuzzyControl->LogPoint[2]->TimeOffset < pFuzzyControl->LogPoint[0]->TimeOffset) {
		midPoint = pFuzzyControl->LogPoint[2];
		pFuzzyControl->LogPoint[2] = pFuzzyControl->LogPoint[1];
		pFuzzyControl->LogPoint[1] = pFuzzyControl->LogPoint[0];
		pFuzzyControl->LogPoint[0] = midPoint;
	} else if (pFuzzyControl->LogPoint[2]->TimeOffset < pFuzzyControl->LogPoint[1]->TimeOffset
			&& pFuzzyControl->LogPoint[2]->TimeOffset > pFuzzyControl->LogPoint[0]->TimeOffset) {
		midPoint = pFuzzyControl->LogPoint[1];
		pFuzzyControl->LogPoint[1] = pFuzzyControl->LogPoint[2];
		pFuzzyControl->LogPoint[2] = midPoint;
	}
	return TRUE;
}
//****************************************************************************
/// LogRecord utility: Finalises the totals in the record and does CRC
///
/// @param[in]		pLogRecordVars - pointer to log record vars
/// @param[in]		pLogRecord - Pointer to current log record
/// @param[in] 		timestamp - time stamp pointer
/// @param[in] 		finalcomplete - completion flag
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
void CLogRec::CompleteLogBlock(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, T_TV5TIME *timestamp,
		UCHAR finalcomplete) {
	if (pLogRecordVars->ExtraSize) {
		// should be a valid time passed in, to complete this LOE maX min record
		// put it into the record
		if (pLogRecordVars->CurrentControl->ControlType == TV5HEADER_LOE_LNG
				|| pLogRecordVars->CurrentControl->ControlType == TV5LOE_LNG)
			*((long*) &pLogRecord->Data[pLogRecordVars->FreeDataPos]) = Diffmstenths(timestamp,
					&pLogRecordVars->LastTime);
		else
			*((short*) &pLogRecord->Data[pLogRecordVars->FreeDataPos]) = (short) (Diffmstenths(timestamp,
					&pLogRecordVars->LastTime) / 100);
		// NB we have divided by 100 for short LOE since time stored is in 100ths sec
		// this gives a more useful range for short LOE, allbeit with a loss of accuracy.
		pLogRecord->Header.EndTime = *timestamp;
	} else if (((pLogRecord->Header.Device == TRENDVIEW_DEVICE) && (pLogRecordVars->CurrentControl->DataType == MAXMIN))
			|| ((pLogRecord->Header.Device == OTHER_DEVICE)
					&& ((pLogRecordVars->CurrentControl->DataType == EX_SHORT_MAXMIN)
							|| (pLogRecordVars->CurrentControl->DataType == EX_FLOAT_MAXMIN)
							|| (pLogRecordVars->CurrentControl->DataType == EX_DOUBLE_MAXMIN)))) {
		pLogRecord->Header.EndTime = pLogRecordVars->LastTime;
		// if we have continuous maxmin, increment the end time
//		AddPosmstenths(&pLogRecord->Header.EndTime, pLogRecordVars->Rate); // FOR MAXMIN the EndTime is the
		// time at the END of the reading.		
	} else
		pLogRecord->Header.EndTime = pLogRecordVars->LastTime; // copy the last (Sample) time to the header.
	if (finalcomplete)
		pLogRecord->Header.Incomplete = COMPLETE; // mark record as complete (only if it really is complete!!)
	return;
}
//****************************************************************************
/// LogRecord utility: Insert a control into the data part of the record
///
/// @param[in]		pLogRecordVars - pointer to log record vars
/// @param[in]		pLogRecord - Pointer to current log record
/// @param[in] 		control - pointer to control to add
///
/// @return			TRUE if record is full, else FALSE
///
/// @note --- Delete if not requried ---
//****************************************************************************
BOOL CLogRec::AddControl(T_LOGRECORDVARS *pLogRecordVars, T_LOGRECORD *pLogRecord, void *control) {
	// before calling, user must complete the control
	short controlsize;
	short mask = 0;
	short keepextrasize = pLogRecordVars->ExtraSize; // we need to save this from being changed if there
	// is no room for the control
	// make general a pointer to our control
	T_GENERALCONTROL *general = (T_GENERALCONTROL*) control;
	// use the tables to retrieve the size of the control to be inserted...
	controlsize = Glb_ControlTypeSizes[general->LogStyle][general->ControlType];
	// ..and the size of the new readings
	pLogRecordVars->DataSize = Glb_DataTypeSizes[pLogRecord->Header.Device][general->DataType];
	if (general->LogStyle == VARIABLE) {
		// for variable rate logging, each reading is accompanied by a time,whch can 
		// be either 2 or 4 bytes long. For fuzzy it is 1 byte long (base time multiplier)
		// general can point to the header control as well, so allow for this.
		if (general->ControlType == TV5FUZZY)
			pLogRecordVars->TimeSize = 1; // FUZZY LOGGING
		else if (general->ControlType == TV5LOE_SHT) // ****SHOULD NEVER BE***** TV5HEADER_LOE_SHT or TV5HEADER_LOE_LNG
			pLogRecordVars->TimeSize = 2;
		else
			// if(general->ControlType==TV5LOE_LNG)
			pLogRecordVars->TimeSize = 4;
		// For LOE MaxMin, there must ALWAYS be room for a time after the last reading
		// so we will allow for it
		// fuzzy is never MaxMin
		if (((pLogRecord->Header.Device == TRENDVIEW_DEVICE) && (general->DataType == MAXMIN))
				|| ((pLogRecord->Header.Device == OTHER_DEVICE)
						&& ((general->DataType == EX_SHORT_MAXMIN) || (general->DataType == EX_FLOAT_MAXMIN)
								|| (general->DataType == EX_DOUBLE_MAXMIN))))
			pLogRecordVars->ExtraSize = pLogRecordVars->TimeSize;
		else
			pLogRecordVars->ExtraSize = 0;
		// for digitals, we need to allow for the size of the mask overview
		if (general->DataType == DIGITALS)
			mask = Glb_DataTypeSizes[pLogRecord->Header.Device][DIGITALS_OVERVIEW]; // special case for the digitals mask
	} else //CONTINUOUS
	{
		// only do the next part if there will be room to insert the control
		if (V6_SIZE_OF_DATA_PART - pLogRecordVars->FreeDataPos - controlsize - pLogRecordVars->DataSize >= 0) {
			pLogRecordVars->TimeSize = 0; // not LOE 
			pLogRecordVars->ExtraSize = 0; // and not LOE MaxMin			
			if (general->ControlType == TV5RATE_SHORT) {
				pLogRecordVars->Rate = ((T_SHORTRATECONTROL*) general)->Rate;
				AddPosmstenths(&pLogRecordVars->LastTime, ((T_SHORTRATECONTROL*) general)->Adjust);
			} else if (general->ControlType == TV5RATE_LONG) {
				pLogRecordVars->Rate = ((T_LONGRATECONTROL*) general)->Rate;
				AddPosmstenths(&pLogRecordVars->LastTime, ((T_LONGRATECONTROL*) general)->Adjust);
			} else if (general->ControlType == TV5ADJUST_LONG)
				AddPosmstenths(&pLogRecordVars->LastTime, ((T_LONGCONTROL*) general)->Adjust);
			else if (general->ControlType == TV5ADJUST_SHORT)
				AddPosmstenths(&pLogRecordVars->LastTime, ((T_SHORTCONTROL*) general)->Adjust);
			else
			//(general->ControlType==TV5HEADER) == ABSOLUTE
			{
				pLogRecordVars->Rate = ((T_ABSOLUTECONTROL*) general)->Rate;
				pLogRecordVars->LastTime = ((T_ABSOLUTECONTROL*) general)->ABSTime; // assign the time here
			}
		}
	}
	// Only insert the control if there is room for it and at least 1 reading
	// NB for LOE the first time goes in the control, so do not include TimeSize in THIS calculation
if(V6_SIZE_OF_DATA_PART - pLogRecordVars->FreeDataPos - controlsize - pLogRecordVars->DataSize - mask - pLogRecordVars->ExtraSize <0)
{
	// will not be room, so record is full (or as good as).
	pLogRecordVars->ExtraSize = keepextrasize;// put this back.
	if(pLogRecordVars->ExtraSize)
	{
		// HOWEVER for MAx Min LOE we have a *special* consideration...
		// We need to finish off the readings with a time increment.
		// (the space reserved for this is ExtraSize.)
		// The following return informs the user that they must call the completion routine
		return TRUE;
	}
	pLogRecord->Header.EndTime = pLogRecordVars->LastTime; // copy the last time to t t

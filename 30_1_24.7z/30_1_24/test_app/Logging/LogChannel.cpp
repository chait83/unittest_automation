/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 Log record utilities
/// @n LogChannel.cpp
/// @n Utilities for maintaining log record format.
/// @author MM
/// @date 15/03/2005
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
//  95  Stability Project 1.90.1.3 7/2/2011 4:58:24 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  94  Stability Project 1.90.1.2 7/1/2011 4:38:26 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  93  Stability Project 1.90.1.1 3/17/2011 3:20:27 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  92  Stability Project 1.90.1.0 2/15/2011 3:03:14 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
//////////////////////////////////////////////////////////////////////
#include "TVTime.h"
#include "LogRec.h"
#include "V6globals.h"
#include "LogChannel.h"
#include "TraceDefines.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
//****************************************************************************
// Logging channel:
//
// Any data source which requires data to be logged will need to create an
// instance of this class.
//
// All pen/channel instances are expected to be 0 based
//
//****************************************************************************
//****************************************************************************
/// CLogChannel wrapper: class constructor
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
CLogChannel::CLogChannel() {
	m_IsLogging = FALSE;
	m_pLogRecord = NULL;
	m_pLogging = NULL;
	m_Session = 1;
	m_Instance = 0;
	m_UseAlarmRate = FALSE;
	m_UseAlarmRateCurrent = FALSE;
	m_RateHasChanged = FALSE;
	m_pNVSequenceNumber = NULL;
	mpSRAM = NULL;
	mpNVData = NULL;
	mpRegion = NULL;
	m_bConfigChanged = FALSE;
	return;
}
//****************************************************************************
/// CLogChannel wrapper: class destructor
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
CLogChannel::~CLogChannel() {
	return;
}
//****************************************************************************
/// CLogChannel wrapper: Get current log rate
///
/// @return			ULONG current log rate in ms-tenths or 0
///
/// @note Log channel MUST have been configured else returns 0L
//****************************************************************************
ULONG CLogChannel::CurrentRate() {
	if (NULL != m_pLogging)
		return m_RateControl.CurrentRate();
	else
		return 0L;
}
//****************************************************************************
/// CLogChannel wrapper: Get current log style
///
/// @return			TRUE if continuous logging, else FALSE
///
/// @note Log channel MUST have been configured else returns FALSE
//****************************************************************************
BOOL CLogChannel::IsContinuous() {
	BOOL bReturn = FALSE;
	if (NULL != m_pLogging)
		if (LOGTYPE_CONTINUOUS == m_pLogging->LogType)
			bReturn = TRUE;
	return bReturn;
}
//****************************************************************************
/// CLogChannel wrapper: Get current log style
///
/// @return			TRUE if fuzzy logging, else FALSE
///
/// @note Log channel MUST have been configured else returns FALSE
//****************************************************************************
BOOL CLogChannel::IsFuzzy() {
	BOOL bReturn = FALSE;
	if (NULL != m_pLogging)
		if (LOGTYPE_FUZZY == m_pLogging->LogType)
			bReturn = TRUE;
	return bReturn;
}
//****************************************************************************
/// CLogChannel wrapper: Get current log style
///
/// @return			TRUE if MaxMin logging, else FALSE
///
/// @note Log channel MUST have been configured else returns FALSE
//****************************************************************************
BOOL CLogChannel::IsMaxMin() {
	BOOL bReturn = FALSE;
	if (NULL != m_pLogging)
		if (LOGTYPE_CONTINUOUS == m_pLogging->LogType && LOGSTYLE_MAXMIN == m_pLogging->LogStyle)
			bReturn = TRUE;
	return bReturn;
}
//****************************************************************************
/// CLogChannel wrapper: Get current log style
///
/// @return			TRUE if Average logging, else FALSE
///
/// @note Log channel MUST have been configured else returns FALSE
//****************************************************************************
BOOL CLogChannel::IsAverage() {
	BOOL bReturn = FALSE;
	if (NULL != m_pLogging)
		if (LOGTYPE_CONTINUOUS == m_pLogging->LogType && LOGSTYLE_AVERAGE == m_pLogging->LogStyle)
			bReturn = TRUE;
	return bReturn;
}
//****************************************************************************
/// CLogChannel wrapper: Check if a pen has been configured (is enabled)
///
/// @return			TRUE if enabled, else FALSE
///
/// @note 
//****************************************************************************
BOOL CLogChannel::IsEnabled() {
	if (NULL != m_pLogging)
		return m_pLogging->Enabled;
	else
		return FALSE;
}
//****************************************************************************
/// CLogChannel wrapper: Check if a pen is logging
///
/// @return			TRUE if logging, else FALSE
///
/// @note 
//****************************************************************************
BOOL CLogChannel::IsLogging() {
	BOOL bResult = FALSE;
	if (NULL != m_pLogging)
		bResult = m_IsLogging;
	return bResult;
}
//****************************************************************************
/// CLogChannel wrapper: Check if a channel is waiting for alognment
///
/// @return			TRUE if waiting, else FALSE
///
/// @note 
//****************************************************************************
BOOL CLogChannel::IsWaitingForAlignment() {
	BOOL bResult = FALSE;
	if (IsLogging()) {
		bResult = m_RateControl.WaitingForAlignment();
	}
	return bResult;
}
//****************************************************************************
/// CLogChannel wrapper: class initialisation
///
/// @param[in]		Type data type being logged
/// @param[in]		Instance zero based data source instance
///	
/// @return			True if pen was set-up OK, else FALSE
///
/// @note This method gets passed all the configuration data required to log data
/// rather than getting the data from the CMM.
//****************************************************************************
BOOL CLogChannel::SetConfig(T_LOG_DATATYPE Type, USHORT Instance) {
	m_IsLogging = FALSE;					// Default log state to off
	m_RequestNew = TRUE;					// Need to initialise the new block
	m_DataType = Type;						// Save data type being logged
	m_Instance = Instance;					// Save pen instance
	T_PPEN pConfig;
	pConfig = pGlbSetup->GetPenSetupConfig()->GetPen(Instance, ZERO_BASED, CONFIG_COMMITTED);
	m_pLogging = &pConfig->PenLog;
	if (NULL != m_pLogging &&
	TRUE == m_pLogging->Enabled) {
		if (NULL == mpSRAM) {
			// Create NV data block pointer
			mpSRAM = CSRAMManager::GetHandle();
			mpSRAM->Initialise();
		}
		// Get SRAM Handle
		if (NULL == mpNVData) {
			CSRAMManager::regionError requestReturn = mpSRAM->RequestRegion(REGION_LOGGING, &mpRegion);
			if (requestReturn == CSRAMManager::REGION_OKAY) {
				mpNVData = (T_LOGGING_NV*) mpRegion->GetAddress();
			} else {
				LOG_CRTL( TRACE_LOGGING, " CRITICAL error\n Logging status RAM region not available.");
			}
			if (sizeof(T_LOGGING_NV) > mpRegion->GetAvailableBytes()) {
				LOG_CRTL( TRACE_LOGGING, " CRITICAL error\n Logging status RAM region too small.");
			}
			T_LOGGING_NV *NV_Vars = (T_LOGGING_NV*) mpNVData;
			// Check for region first use
			if (mpRegion->GetAutoState() == SRAM_STATE_FIRSTUSE) {
				mpRegion->SetAutoStateToUpdating();
				// Initialise log record vars to 'safe' values
				for (int index = 0; index < V6_MAX_PENS; index++) {
					T_LOGRECORDVARS *p_LogVars = &NV_Vars->LogRecVars[index];
					p_LogVars->CurrentControl = NULL;
					p_LogVars->FreeDataPos = 0;
				}
				mpRegion->SetAutoStateToNormal();
			}
			mpSRAM->ReleaseRegion(REGION_LOGGING);
			mp_LogVars = &NV_Vars->LogRecVars[Instance];
		}
		m_pNVSequenceNumber = pNV_VARS->GetBasicVarNVObject(static_cast<NVVAR_IDENT>(NVV_PEN_SEQ_FIRST + Instance));
		NV_Sequence = m_pNVSequenceNumber->GetFromNV()->value;
		m_pDataItem = (CDataItemPen*) pGlbDIT->GetDataItemPtr(DI_PEN, 0, Instance);
		m_RateControl.Initialise(m_pLogging);
		m_bConfigChanged = TRUE;
		T_BLOCK_INIT BlockState = m_BlockControl.Initialise(m_pLogging, Instance);
		if (BLOCK_INCOMPLETE == BlockState) {
			// Flush incomplete log record
			FlushData();
		} else if (BLOCK_ERROR == BlockState) {
			LOG_CRTL( TRACE_LOGGING, " Log Channel Initialisation Error.");
		}
		m_LogControl.SetReason(SETUP_CHANGED);
		m_pLogRecord = (T_LOGRECORD*) m_BlockControl.CurrentBlock();
		m_LogControl.SetZeroAndSpan(pConfig->Scale.Zero, pConfig->Scale.Span);	// Set zero and span for configuration
		return TRUE;
	}
	return FALSE;
}
//****************************************************************************
/// Decide if a change in log rate depending on alarm is required
///
/// @return		nothing
//****************************************************************************
void CLogChannel::CheckAndChangeRateIfRequired() {
	// If there has been a change in state, perform a rate change
	if (LOGTYPE_CONTINUOUS == m_pLogging->LogType && LOGSTYLE_SAMPLE == m_pLogging->LogStyle
			&& m_UseAlarmRate != m_UseAlarmRateCurrent) {
		// Register new rate required
		m_RateControl.ChangeRate(m_UseAlarmRate);
		// indicate that we need to add a control to the log block on the next log point
		m_RateHasChanged = TRUE;
		// Update new rate status
		m_UseAlarmRateCurrent = m_UseAlarmRate;
	}
}
//****************************************************************************
/// CLogChannel wrapper: log reading
///
/// @return			none
///
/// @note The required data will be read from the Data Item Table entry
/// using the member CDataItem *m_pDirectVar
//****************************************************************************
BOOL CLogChannel::Reading() {
	if (m_IsLogging) {
		//*******************************************
		// Actions/checks made on each process cycle.
		//*******************************************
		if ( FALSE == m_RateControl.WaitingForAlignment()) {
			// If max min or average build up logged reading from each process slice
			if (LOGSTYLE_MAXMIN == m_pLogging->LogStyle)
				m_MaxMin.DoMaxMinForReading(m_pDataItem->GetFPValue());
			else if (LOGSTYLE_AVERAGE == m_pLogging->LogStyle)
				m_Average.DoAverageForReading(m_pDataItem->GetFPValue());
		}
		// If no block currently available for logging, attempt to get a block
		if (NULL == m_BlockControl.CurrentBlock()) {
			m_pLogRecord = (T_LOGRECORD*) m_BlockControl.RequestNew();
			if (NULL != m_BlockControl.CurrentBlock())
				m_RequestNew = TRUE;
		}
		if (NULL == m_BlockControl.CurrentBlock()) {
			qDebug(" Log channel %d, No data block available?\n", m_Instance + 1);
		} else {
			if ( pSYSTIMER->HasTimeChangeOccured()) {
				if ( FALSE == m_RateControl.WaitingForAlignment())// If time changes while waiting for alignment, ignore it.
						{
					// CR2081 if a (natural) new block and a time change happen at the same time, the reason code
					// and sequence numbers were not being set.
					if ( FALSE == m_RequestNew) {
						T_TV5TIME LastReadingTime = mp_LogVars->LastTime;
						m_LogControl.Complete(mp_LogVars, (T_LOGRECORD*) m_BlockControl.CurrentBlock(),
								&LastReadingTime);
						m_RequestNew = TRUE;
						m_BlockControl.RequestNew();
						m_pLogRecord = (T_LOGRECORD*) m_BlockControl.CurrentBlock();
					}
					m_LogControl.SetReason(TIME_ADJUSTED);
					// Nudge the sequence number to ensure graph is not continuous over the time change
					NV_Sequence = m_pNVSequenceNumber->GetFromNV()->value;
					NV_Sequence.ul++;
					m_pNVSequenceNumber->SetToNV(NV_Sequence);
				}
			} else if ( TRUE == m_RateHasChanged &&				// else if avoids time and rate change at same time
					FALSE == m_RequestNew)							// Prevent double block request
							{
				if ( FALSE == m_RateControl.WaitingForAlignment())// If log rate changes while waiting for alignment, ignore it.
						{
					// Complete current block and start new, at new rate
					T_TV5TIME LastReadingTime = mp_LogVars->LastTime;
					m_LogControl.Complete(mp_LogVars, m_pLogRecord, &LastReadingTime);
					m_RequestNew = TRUE;
					m_BlockControl.RequestNew();
					m_pLogRecord = (T_LOGRECORD*) m_BlockControl.CurrentBlock();
				}
				m_RateHasChanged = FALSE;
			}
			// check if it's time to log this reading & we have somewhere to log & the log channel is enabled..
			if (NULL != m_BlockControl.CurrentBlock() && m_RateControl.LogReading()) {
				//*******************************************
				// Only performed when it's time to log data.
				//*******************************************
				if (m_bConfigChanged && IsAverage()) {
					// Initial Average value needs to be the pen value otherwise the average is wrong
					m_Average.ResetAverage(m_pDataItem->GetFPValue());
					m_bConfigChanged = FALSE;
				}
				if (m_bConfigChanged && IsMaxMin()) {
					m_MaxMin.ResetMaxMin();
					m_bConfigChanged = FALSE;
				} else {
					// Check if we need a new log block
					if (m_RequestNew) {
						InitNewBlock();										// Initialise the new log block
					}
					// Log the reading, if TRUE returned current block is full so close off blockand request a new one
					if (m_LogControl.Log(mp_LogVars, (T_LOGRECORD*) m_BlockControl.CurrentBlock(), m_pDataItem,
							&m_MaxMin, &m_Average)) {
						// Record if full create a new block
						T_TV5TIME ReadingTime = mp_LogVars->LastTime;
						m_RequestNew = TRUE;
						m_LogControl.Complete(mp_LogVars, (T_LOGRECORD*) m_BlockControl.CurrentBlock(), &ReadingTime);
						m_BlockControl.RequestNew();
						m_pLogRecord = (T_LOGRECORD*) m_BlockControl.CurrentBlock();
					}
					m_LogControl.SetReason(CONTINUATION);
				}
			}
		} // NULL block test
	}
	return TRUE;
}
//****************************************************************************
/// CLogChannel wrapper: Initialise a new log block
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
void CLogChannel::InitNewBlock() {
	T_TV5TIME ReadingTime = pSYSTIMER->GetCurrentProcessTimeTV5Ref();
	NV_Sequence = m_pNVSequenceNumber->GetFromNV()->value;
	NV_Sequence.ul++;
	m_pNVSequenceNumber->SetToNV(NV_Sequence);
	//initialise the new log record
	m_LogControl.Initialise(m_Session, NV_Sequence.ul, m_Instance, m_RateControl.CurrentRate(),
			(T_LOGRECORD*) m_BlockControl.CurrentBlock(), ReadingTime, m_pLogging);
	if (m_pLogRecord != m_BlockControl.CurrentBlock())
		V6WarningMessageBox(NULL, L"Log record/Current Block mismatch", L"Error", MB_OK | MB_TOPMOST);
	mp_LogVars->FreeDataPos = 0;
	if (m_pLogRecord->Header.DataType == EX_FLOAT_MAXMIN)
		mp_LogVars->DataSize = sizeof(float) * 2;
	else
		mp_LogVars->DataSize = sizeof(float);
	if (LOGTYPE_FUZZY == m_pLogging->LogType)
		mp_LogVars->TimeSize = sizeof(UCHAR);
	else
		mp_LogVars->TimeSize = sizeof(T_TV5TIME);
	mp_LogVars->ExtraSize = 0;
	mp_LogVars->LastTime = ReadingTime;
	mp_LogVars->Rate = m_pLogRecord->Header.Rate;
	mp_LogVars->CurrentControl = (T_GENERALCONTROL*) m_BlockControl.CurrentBlock();
	m_BlockControl.SetState(BLOCK_IN_USE);
	m_RequestNew = FALSE;
}
/* AK we don't seem to need this yet, maybe needed with phase 2 code refresh
 //****************************************************************************
 /// CLogChannel wrapper: Recreate log record vars after a power cycle
 ///
 /// @return			none
 ///
 /// @note --- Delete if not requried ---
 //****************************************************************************
 void CLogChannel::ReCreateVars( )
 {
 if ( NULL != m_pLogRecord &&
 0 != m_pLogRecord->Header.Session &&
 0 != m_pLogRecord->Header.SeqNo )
 {
 if ( m_pLogRecord->Header.DataType == EX_FLOAT_MAXMIN )
 mp_LogVars->DataSize = sizeof(float) * 2;
 else
 mp_LogVars->DataSize = sizeof(float);
 
 if ( LOGTYPE_FUZZY == m_pLogging->LogType )
 mp_LogVars->TimeSize = sizeof(UCHAR);
 else
 mp_LogVars->TimeSize = sizeof(T_TV5TIME);
 mp_LogVars->ExtraSize = 0;
 mp_LogVars->Rate = m_pLogRecord->Header.Rate;
 mp_LogVars->CurrentControl = (T_GENERALCONTROL*)m_BlockControl.CurrentBlock();
 }
 }
 */
//****************************************************************************
/// CLogChannel wrapper: start logging
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
BOOL CLogChannel::StartLog(USHORT uReason, USHORT Session) {
	CNVBasicVar *pNVvariable = pNV_VARS->GetBasicVarNVObject(
			static_cast<NVVAR_IDENT>(NVV_PEN_LOGGING_FIRST + m_Instance));
	if (!m_IsLogging) {
		if (m_Session != Session)
			NV_Sequence.ul = 1;
		m_RateControl.Initialise(m_pLogging);		// Ensure rate control is reset
		m_RateControl.Start();						// Also reset any alignment
		m_Session = Session;
		m_IsLogging = TRUE;
		pNVvariable->GetFromNV()->value.byte[LOGGING_BYTE] = TRUE;
		m_RequestNew = TRUE;
		m_BlockControl.Initialise(m_pLogging, m_Instance);
		m_LogControl.InitFuzzyControl(m_pLogging, &m_LogControl.FuzzyControl);
	}
	return TRUE;
}
//****************************************************************************
/// CLogChannel wrapper: restore previous logging state
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
BOOL CLogChannel::RestoreNVState(USHORT uReason, USHORT Session) {
	CNVBasicVar *pNVvariable = pNV_VARS->GetBasicVarNVObject(
			static_cast<NVVAR_IDENT>(NVV_PEN_LOGGING_FIRST + m_Instance));
	if ( TRUE == pNVvariable->GetFromNV()->value.byte[LOGGING_BYTE] &&
	FALSE == m_IsLogging) {
		if (m_Session != Session)
			NV_Sequence.ul = 1;
		m_RateControl.Initialise(m_pLogging);		// Ensure rate control is reset
		m_RateControl.Start();						// Also reset any alignment
		m_Session = Session;
		m_IsLogging = TRUE;
		pNVvariable->GetFromNV()->value.byte[LOGGING_BYTE] = TRUE;
		m_RequestNew = TRUE;
		m_BlockControl.Initialise(m_pLogging, m_Instance);
		m_LogControl.InitFuzzyControl(m_pLogging, &m_LogControl.FuzzyControl);
	}
	return TRUE;
}
//****************************************************************************
/// CLogChannel wrapper: stop logging
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
BOOL CLogChannel::StopLog(BOOL bSaveState) {
	if (m_IsLogging) {
		m_IsLogging = FALSE;
		CNVBasicVar *pNVvariable = pNV_VARS->GetBasicVarNVObject(
				static_cast<NVVAR_IDENT>(NVV_PEN_LOGGING_FIRST + m_Instance));
		T_SHUTDOWN_MODE sdMode = pDALGLB->GetShutDownMode();
		if (bSaveState) {
			pNVvariable->GetFromNV()->value.byte[LOGGING_BYTE] = FALSE;
		}
		// Flush incomplete log record
		FlushData();
		m_RateControl.Stop();
	}
	return TRUE;
}
//****************************************************************************
/// CLogChannel wrapper: flush incomplete data
///
/// @return			Alwaye TRUE
///
/// @note Called on power cycle and prior to a data transfer
//****************************************************************************
BOOL CLogChannel::FlushData() {
	BOOL bReturn = TRUE;
	if (NULL != mpNVData) {
		// Quick sanity test...
		BYTE *vpLogCtrl = (BYTE*) mp_LogVars->CurrentControl;
		BYTE *vpLogBlock = (BYTE*) m_BlockControl.CurrentBlock();
		if ((vpLogCtrl < vpLogBlock) || (vpLogCtrl > (vpLogBlock + 512))) {
			// Data is presumed damaged, certainly not useable.
			// Existing block will be re-initialised rather than flushed.
			// qDebug(" NV data damaged, block for pen %d discarded\n", m_Instance+1 );
		} else {
			// Must be at least one reading in the block
			if (mp_LogVars->FreeDataPos >= mp_LogVars->DataSize) {
				T_TV5TIME timestamp = mp_LogVars->LastTime;
				T_LOGRECORD *pLogRecord = (T_LOGRECORD*) m_BlockControl.CurrentBlock();
				// Incomplete block to flush...
				if (NULL != pLogRecord) {
					if (TV5FUZZY == pLogRecord->Header.ControlType)
						m_LogControl.FlushFuzzyLogBlock(mp_LogVars, (T_LOGRECORD*) m_BlockControl.CurrentBlock(),
								&m_LogControl.FuzzyControl);
					else
						m_LogControl.CompleteLogBlock(mp_LogVars, (T_LOGRECORD*) m_BlockControl.CurrentBlock(),
								&timestamp, TRUE);
				}
				m_pLogRecord = (T_LOGRECORD*) m_BlockControl.RequestNew();
			}
		}
		// Initialise/Reinitialise the block.
		m_RequestNew = TRUE;
		bReturn = TRUE;
	}
	return bReturn;
}

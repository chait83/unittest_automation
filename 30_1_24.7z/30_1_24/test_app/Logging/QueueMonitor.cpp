/// @file 
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 Log record utilities
/// @n QueueMonitor.cpp
/// @n Utilities for monitoring data log queues.
/// @author MM
/// @date 25/10/2005
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
//  70  Aristos  1.63.1.4.1.0 9/19/2011 4:51:16 PM  Hemant(HAIL)  
//  Stability recorder source code (JI Release) updated for WatchDog
//  Timer functionality.
//  69  Stability Project 1.63.1.4 7/2/2011 5:00:06 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  68  Stability Project 1.63.1.3 7/1/2011 4:38:47 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  67  Stability Project 1.63.1.2 3/17/2011 3:20:40 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
// $
//
//////////////////////////////////////////////////////////////////////
#include "QueueMonitor.h"
#include "DataTransfer.h"
#include "MediaManager.h"
#include "TraceDefines.h"
#include "V6defines.h"
#include "ThreadInfo.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
CQMonitor *CQMonitor::pInstance = NULL;
QMutex hCreationMutex;
/// Const used to indicate if a queue is in use or not (i.e. because a pen is disabled)
const long QUEUE_NOT_IN_USE = -1;
//****************************************************************************
/// DataTransfer queue monitor: singleton get/create instance
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
CQMonitor* CQMonitor::GetHandle() {
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;
	if (NULL == pInstance) {
		hCreationMutex = CreateMutex(NULL,					// No security descriptor
				TRUE,					// Mutex object owned
				L"QueueMoinitor");		// Object name
		waitSingleObjectResult = hCreationMutex.tryLock(g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);
		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:
			// Object was signaled
			if (NULL == pInstance) {
				pInstance = new CQMonitor;
				LOG_INFO( TRACE_TRANSFER, "CQMonitor new Instance created");
			}
			if ( FALSE == hCreationMutex.unlock())
				V6WarningMessageBox(NULL, L"Failed to release QueueMonitor mutex", L"Error", MB_OK);
			break;
		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
			V6WarningMessageBox(NULL, L"QueueMonitor WaitForSingleObject Error", L"Error", MB_OK);
			break;
		}
		// Close the Mutex as no longer required
		//No need to close the mutex in Qt
	}
	return pInstance;
}
//****************************************************************************
/// DataTransfer queue monitor singleton cleanup
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
BOOL CQMonitor::CleanUp() {
	//
	// Stability Project Fix:
	//
	// CleanUp function modified as it was not deleting the pInstance correctly.
	// Earlier the condition was wrongly handled.
	//
	if (m_Initialised) {
		//deletion of mutex not required
		m_Initialised = FALSE;
	}
	if (pInstance != NULL) {
		delete pInstance;
		pInstance = NULL;
	}
	qDebug(" DataTransfer module CleanUp() called.\n");
	return TRUE;
}
//****************************************************************************
/// Data transfer queue monitor initialisation
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
void CQMonitor::Initialise() {
	if (!m_Initialised) {
		m_Initialised = TRUE;
		CNVBasicVar *pNVparam = NULL;
		// Read non-volatile recording time available
		m_pInternalHoursToRecycle = reinterpret_cast<CDataItemGeneral*>(pDIT->GetDataItemPtr(DI_GENERAL,
				DI_GENTYPE_GENERAL, DI_GEN_INT_HOURS));
		pNVparam = pNV_VARS->GetBasicVarNVObject(static_cast<NVVAR_IDENT>(NVV_RECORDING_TIME));
		m_PenSeconds = pNVparam->GetFromNV()->value.ul;
		m_pInternalHoursToRecycle->SetValue(SEC_TO_HOUR((float )m_PenSeconds));
		// Read non-volatile FTP recording time available
		m_pFTPHoursToRecycle = reinterpret_cast<CDataItemGeneral*>(pDIT->GetDataItemPtr(DI_GENERAL, DI_GENTYPE_GENERAL,
				DI_GEN_FTP_HOURS));
		pNVparam = pNV_VARS->GetBasicVarNVObject(static_cast<NVVAR_IDENT>(NVV_FTP_RECORDING_TIME));
		m_PenSeconds = pNVparam->GetFromNV()->value.ul;
		m_pFTPHoursToRecycle->SetValue(SEC_TO_HOUR((float )m_PenSeconds));
		pNVparam = pNV_VARS->GetBasicVarNVObject(static_cast<NVVAR_IDENT>(NVV_BLOCKS_WAITING));
		m_BlocksWaiting = pNVparam->GetFromNV()->value.ul;
		pNVparam = pNV_VARS->GetBasicVarNVObject(static_cast<NVVAR_IDENT>(NVV_LOG_QUEUE_BLOCKS));
		m_TotalQueueBlocks = pNVparam->GetFromNV()->value.ul;
		LOG_INFO( TRACE_LOGGING, "CQMonitor Constructor :- PenSeconds %d, BlocksWaiting %d, AllBlocks %d", m_PenSeconds, m_BlocksWaiting, m_TotalQueueBlocks);
		for (int iPen = 0; iPen < V6_MAX_PENS; iPen++)
			m_PenQueueBlocks[iPen] = 0;
		QMutex * m_hCritical;
	}
	return;
}
//****************************************************************************
/// Data transfer queue monitor constructor
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
CQMonitor::CQMonitor() {
	m_Initialised = FALSE;
	for (int iCount = 0; iCount < LOGDEV_MAX_DEVICES; iCount++) {
		m_bScheduleWarning[iCount] = FALSE;				// Initialise the schedule space warning state
		m_bMediaMissingWarning[iCount] = FALSE;			// Initialise the media missing warning state
	}
	m_fBlockPerHour = 0;
	return;
}
//****************************************************************************
/// Data transfer queue monitor
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
CQMonitor::~CQMonitor() {
	return;
}
//****************************************************************************
/// Queue Monitor return the current number of blocks for a pen queue
///
/// @param[in] penInstance - pen instyance (zero based)
///
/// @return		Number of blocks in the pen queue, or 0
///
/// @note 
//****************************************************************************
ULONG CQMonitor::GetPenQueueSize(USHORT penInstance) {
	ULONG RetVal = 0L;
	if (penInstance < V6_MAX_PENS)
		RetVal = m_PenQueueBlocks[penInstance];
	return RetVal;
}
//****************************************************************************
/// Queue Monitor Update the monitor for the specified device
///
/// @param[in]		device - Device to update
/// @param[in]		const bool bDISK_FULL - Flag indicating in an export failed because
///					the disk was full
///
/// @return			None
///
/// @note Used to show the recording progress as a bar
//****************************************************************************
void CQMonitor::Update(T_LOG_DEVICE device, const bool bDISK_FULL) {
	COMBO_VAR4 value;
	CNVBasicVar *pNVparam = NULL;
	//Get the handle of ThreadInfo class to update 
	//the thread count for scheduler thread
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	m_BlocksWaiting = GetNumNewBlocksWaiting(device);
	// loop through getting the longest of the short pen queues on all the devices
	ULONG ulPenSeconds = 0;
	ULONG ulHighestPenSeconds = 0;
	for (USHORT usCurrDevice = LOGDEV_EXT_SD; usCurrDevice <= LOGDEV_SHARE; usCurrDevice++) {
		//Update the scheduler thread count for each iteration
		if (pThreadInfo != NULL) {
			pThreadInfo->UpdateThreadCounter(AM_TX_SCHEDULER_THREAD);
		}
		ulPenSeconds = indexOfShortestPenQueue(static_cast<T_LOG_DEVICE>(usCurrDevice));
		// see if this is higher than the current highest value
		if (ulPenSeconds > ulHighestPenSeconds) {
			ulHighestPenSeconds = ulPenSeconds;
		}
	}
	// set the pen seconds to the highest found for the log devices
	m_PenSeconds = ulHighestPenSeconds;
	m_FTPPenSeconds = indexOfShortestPenQueue(LOGDEV_FTP);
	m_TotalQueueBlocks = GetQueueSpaceBlocks(device);
//	qDebug(" Waiting = %ld, Seconds = %ld\n", m_BlocksWaiting, m_PenSeconds );
	// Apply the fudge factor as some data may be held in SRAM
	if (m_TotalQueueBlocks < m_BlocksWaiting) {
		m_TotalQueueBlocks = m_BlocksWaiting;
	}
	// Update NV copies of the data
	pNVparam = pNV_VARS->GetBasicVarNVObject(static_cast<NVVAR_IDENT>(NVV_RECORDING_TIME));
	value.ul = m_PenSeconds;
	pNVparam->SetToNV(value);
	m_pInternalHoursToRecycle->SetValue(SEC_TO_HOUR((float )m_PenSeconds));
	pNVparam = pNV_VARS->GetBasicVarNVObject(static_cast<NVVAR_IDENT>(NVV_FTP_RECORDING_TIME));
	value.ul = m_FTPPenSeconds;
	pNVparam->SetToNV(value);
	m_pFTPHoursToRecycle->SetValue(SEC_TO_HOUR((float )m_FTPPenSeconds));
//	qDebug("FTP Hours = %f.\n", m_pFTPHoursToRecycle->GetFPValue( ) );
	pNVparam = pNV_VARS->GetBasicVarNVObject(static_cast<NVVAR_IDENT>(NVV_BLOCKS_WAITING));
	value.ul = m_BlocksWaiting;
	pNVparam->SetToNV(value);
	pNVparam = pNV_VARS->GetBasicVarNVObject(static_cast<NVVAR_IDENT>(NVV_LOG_QUEUE_BLOCKS));
	value.ul = m_TotalQueueBlocks;
	pNVparam->SetToNV(value);
	if (!CheckNextScheduleSpace(bDISK_FULL)) {
		qDebug(" Media space too low for next scheduled data transfer.\n");
	}
}
//*********************************************************************************
/// Queue Monitor Check the required media space for the NEXT scheduled transfer
///
/// @param[in]		const bool bDISK_FULL - Flag indicating in an export failed because
///					the disk was full
///
/// @return			FALSE if there is insuficient space, TRUE for suficient space or no media
///
/// @note CR2064
//****************************************************************************
BOOL CQMonitor::CheckNextScheduleSpace(const bool bDISK_FULL) {
	BOOL bResult = TRUE;
	T_PRECPROFILE ptProfile = pSETUP->GetGeneralSetupConfig()->GetProfileBlock(CONFIG_COMMITTED);
	T_LOG_DEVICE log_device = static_cast<T_LOG_DEVICE>(ptProfile->Logging.SchedExportDev);
	CMediaManager *pMediaManager = CMediaManager::GetHandle();
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	if (pThreadInfo != NULL) {
		//Update the Thread Counter for the TxScheduler thread
		pThreadInfo->UpdateThreadCounter(AM_TX_SCHEDULER_THREAD);
	}
	// Check if a schedule is set and this is the required device...
	if (ptProfile->Logging.DoSchedExport == TRUE) {
		// Get required media space
		ULONG ulAvailableSpaceinK = 0;
		CLogDeviceStatus *pkDeviceStatus = CLogDeviceStatus::GetHandle();
		T_STORAGE_DEVICE localStorageDevice = pkDeviceStatus->LogDeviceToStorageDevice(log_device);
		// if the device contains media
		if (pMediaManager->IsDeviceInserted(localStorageDevice) && localStorageDevice != IDS_SHARE) {
			// a device is inserted therefore always reset the media missing warning
			m_bMediaMissingWarning[log_device] = FALSE;
			// get the available storage space (in KB)
			ulAvailableSpaceinK = pMediaManager->GetFreeSpaceK(localStorageDevice);
			// if an export failed due to disk full or we are less than the allowed free space
			if (bDISK_FULL || (ulAvailableSpaceinK <= CTransferDevice::ms_ulFREE_SPACE_MIN_KB)) {
				// If there is insuficient space
				if ( FALSE == m_bScheduleWarning[log_device]) {
					// and the warning hasn't been issued...
					m_bScheduleWarning[log_device] = TRUE;
					bResult = FALSE;
					qDebug(" Media space warning set.\n");
					QString MessageTxT = "";
					MessageTxT = tr("Media space too low for next scheduled data transfer");
					LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, MessageTxT);
				}
			}
		}
		/*else if(localStorageDevice == IDS_SHARE)
		 {
		 // E527303
		 // default it is assumed that network conenction exists, in case of NAS activated feature
		 // actual network connection is checked when data is ready for transfer when the time interval is reached...
		 //
		 LONG bError = 0;
		 //pMediaManager->CheckSharedFolder();
		 if( bError == 0)
		 {
		 m_bMediaMissingWarning[ log_device ] = FALSE;
		 }
		 else
		 {
		 if ( FALSE == m_bMediaMissingWarning[ log_device ] )
		 {
		 // and the warning hasn't been issued...
		 m_bMediaMissingWarning[ log_device ] = TRUE;
		 bResult = FALSE;
		 qDebug(" Media missing warning set.\n" );
		 QString  strError( QString   ::fromWCharArray("") );
		 strError = QString::asprintf( IDS_SCHEDULE_MEDIA_MISSING_ERROR );
		 LOG_SYSTEM_MESSAGE( MSGLISTSER_SYSTEM_WARNING, strError );
		 strError.Empty();	
		 strError = tr("Scheduled export failed - Network Error");
		 TCHAR szError[MAX_PATH] = {0};
		 _stprintf(szError, L"%s (%ld)",strError, bError);
		 
		 LOG_DIAGNOSTIC_MESSAGE( MSGLISTSER_DIAGNOSTIC_ERROR,szError );
		 }
		 }
		 }*/
		else {
			// If there is no media inserted
			if ( FALSE == m_bMediaMissingWarning[log_device]) {
				// and the warning hasn't been issued...
				m_bMediaMissingWarning[log_device] = TRUE;
				bResult = FALSE;
				qDebug(" Media missing warning set.\n");
				QString strError("");
				strError = QString::asprintf(IDS_SCHEDULE_MEDIA_MISSING_ERROR);
				LOG_SYSTEM_MESSAGE(MSGLISTSER_SYSTEM_WARNING, strError);
			}
		}
	}
	return bResult;
}
//*********************************************************************************
/// Queue Monitor Tell the schedule space warning that the media has been removed
///
///@param[in]	device - storage device identification 
///
/// @return		none	
///
/// @note 
//****************************************************************************
void CQMonitor::LogDeviceRemoved(T_LOG_DEVICE device) {
	if (m_bScheduleWarning[device]) {
		qDebug(" Media space warning cleared.\n");
		m_bScheduleWarning[device] = FALSE;
	}
}
//*********************************************************************************
/// Queue Monitor Clear the number of block waiting to be transferred
///
/// @return			
///
/// @note 
//****************************************************************************
void CQMonitor::ClearNumBlocksWaiting() {
	COMBO_VAR4 value;
	CNVBasicVar *pNVparam = NULL;
	m_BlocksWaiting = 0;
	pNVparam = pNV_VARS->GetBasicVarNVObject(static_cast<NVVAR_IDENT>(NVV_BLOCKS_WAITING));
	value.ul = m_BlocksWaiting;
	pNVparam->SetToNV(value);
}
//****************************************************************************
/// Queue Monitor prepare for a transfer all
///
/// @return			None
///
/// @note Used to show the recording progress as a bar
//****************************************************************************
void CQMonitor::PrepareTransferAll() {
	m_BlocksWaiting = m_TotalQueueBlocks;
}
//****************************************************************************
/// Queue Monitor Get total number of blocks used
///
/// @return			Number of blocks in ALL queues
///
/// @note Used to show the recording progress as a bar
//****************************************************************************
ULONG CQMonitor::GetNumNewBlocksWaiting(T_LOG_DEVICE device) {
	CQueueManager *pq_manager = CQueueManager::GetHandle();
	CLogDeviceStatus *pDeviceStatus = CLogDeviceStatus::GetHandle();
	CDataTransfer *pDataTransfer = CDataTransfer::GetHandle();
	pDataTransfer->Initialise();
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	ULONG ulTotalBlocks = 0L;
	USHORT QueueHandle;
	T_QMBLKSER_RETURN_VALUE q_error;
//////RTVIEW - 2060 fix - added type of export format in getstatus methods
	T_DATA_EXPORT_FORMAT_TYPE eExportasprintfType = EXPORT_FORMAT_TVENCRYPT;
	if (LOGDEV_FTP != device) {
		pDataTransfer->getDataExportasprintf(device, eExportasprintfType);
	}
//////RTVIEW - 2060 fix
	for (int Instance = 0; Instance < V6_MAX_PENS; Instance++) {
		//Update the scheduler thread count for each iteration
		if (pThreadInfo != NULL) {
			pThreadInfo->UpdateThreadCounter(AM_TX_SCHEDULER_THREAD);
		}
		q_error = pq_manager->GetBlockServices().GetQueue(QMC_QUEUE_PEN_LOG, Instance, QueueHandle);
		if (QMBLKSER_OK == q_error && QMC_QUEUE_EMPTY != pq_manager->GetDiskServices().GetQueueStatus(QueueHandle)) {
			T_QMC_FILE_BLOCK_TRANSACTION *pTransactionPoint = pDeviceStatus->GetStatus(device, Instance,
					TYPE_TRANSFERED, eExportasprintfType);
			ValidateTransactionPoint(pTransactionPoint, QueueHandle);
			if ((QMC_INVALID_FILE_NUMBER != pTransactionPoint->fileId
					&& QMC_INVALID_BLOCK_NUMBER != pTransactionPoint->blockId)
					&& ((TRUE == pq_manager->ValidateFileId(pTransactionPoint->fileId))
							|| (TRUE == pq_manager->ValidateBlockId(pTransactionPoint->blockId)))) {
				LONG Addition = pq_manager->GetDiskServices().GetNumBlocksInFileQueueFromPoint(QueueHandle,
						pTransactionPoint->fileId, pTransactionPoint->blockId);
				if (Addition > 0) {
					m_PenQueueBlocks[Instance] = Addition;
					ulTotalBlocks += Addition;
				}
			}
		}
	}
	for (int List = 0; List < CMessageListServices::msqMAX_QUEUES; List++) {
		//Update the scheduler thread count for each iteration
		if (pThreadInfo != NULL) {
			pThreadInfo->UpdateThreadCounter(AM_TX_SCHEDULER_THREAD);
		}
		q_error = pq_manager->GetBlockServices().GetQueue(QMC_QUEUE_MESSAGE, List, QueueHandle);
		if (QMBLKSER_OK == q_error && QMC_QUEUE_EMPTY != pq_manager->GetDiskServices().GetQueueStatus(QueueHandle)) {
			T_QMC_FILE_BLOCK_TRANSACTION *pTransactionPoint = pDeviceStatus->GetStatus(device, List + V6_MAX_PENS,
					TYPE_TRANSFERED, eExportasprintfType);
			ValidateTransactionPoint(pTransactionPoint, QueueHandle);
			if ((QMC_INVALID_FILE_NUMBER != pTransactionPoint->fileId
					&& QMC_INVALID_BLOCK_NUMBER != pTransactionPoint->blockId)
					&& ((TRUE == pq_manager->ValidateFileId(pTransactionPoint->fileId))
							|| (TRUE == pq_manager->ValidateBlockId(pTransactionPoint->blockId)))) {
				LONG Addition = pq_manager->GetDiskServices().GetNumBlocksInFileQueueFromPoint(QueueHandle,
						pTransactionPoint->fileId, pTransactionPoint->blockId);
				if (Addition > 0) {
					ulTotalBlocks += Addition;
				}
			}
		}
	}
	// tell the transfer class how many blocks are waiting, so it can scale transfer percentages
	pDataTransfer->SetBlocksWaiting(ulTotalBlocks);
	return ulTotalBlocks;
}
//****************************************************************************
/// Queue Monitor Scan all queues and report the space left
///
/// @param[in]	device		- storage device being used
///
/// @return		
///
/// @note 
//****************************************************************************
ULONG CQMonitor::indexOfShortestPenQueue(T_LOG_DEVICE device) {
	CPenManager *pPenManager = CPenManager::GetHandle();
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	LONG Timeleft = LONG_MAX;
	USHORT ShortestPen = 0;
	m_hCritical.lock();
	m_fBlockPerHour = 0;
	for (USHORT penInstance = 0; penInstance < V6_MAX_PENS; penInstance++) {
		//Update the scheduler thread count for each iteration
		if (pThreadInfo != NULL) {
			pThreadInfo->UpdateThreadCounter(AM_TX_SCHEDULER_THREAD);
		}
		float PenBlocksPerHour = 0;
		float BlockTime = (float) (pPenManager->PenEffectiveLogRate(penInstance) * V6_READINGS_PER_BLOCK) / 10000;
		LONG left = GetBlocksleftInQueue(device, penInstance);
		// calculate block useage in data blocks per hour (at the current log rate)
		if (pPenManager->IsPenLogging(penInstance)) {
			PenBlocksPerHour = (3600 / BlockTime);
			m_fBlockPerHour += PenBlocksPerHour;
		}
		if (QUEUE_NOT_IN_USE != left) {
			if (0L == left)
				Timeleft = 0L;
			else {
				if (BlockTime > 0 && left >= 0L) {
					if (Timeleft > (LONG) (BlockTime * left)) {
						Timeleft = (LONG) (BlockTime * left);
						ShortestPen = penInstance;
					}
				}
			}
		}
	}
	m_hCritical.lock();
	return Timeleft;
}
//****************************************************************************
/// Queue monitor Get the number of log blocks left in a pen queue
///
/// @param[in]	device		- storage device being used
/// @param[in]	penInstance	- zero based pen number
///
/// @return		ULONG number of blocks left before a re-cycle, QUEUE_NOT_IN_USE is returned if the queue is 
///				not in use i.e. perhaps it is a disabled pen
///
/// @note Used to calculate the "safe" recording time available
//****************************************************************************
LONG CQMonitor::GetBlocksleftInQueue(T_LOG_DEVICE device, USHORT penInstance) {
	LONG Blocksleft = QUEUE_NOT_IN_USE;
	CQueueManager *pq_manager = CQueueManager::GetHandle();
	CLogDeviceStatus *pDeviceStatus = CLogDeviceStatus::GetHandle();
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	CDataTransfer *pDataTransfer = CDataTransfer::GetHandle();
	//Update the scheduler thread count for escheduler thread
	if (pThreadInfo != NULL) {
		pThreadInfo->UpdateThreadCounter(AM_TX_SCHEDULER_THREAD);
	}
	USHORT QueueHandle;
//////RTVIEW - 2060 fix - added type of export format in getstatus method
	T_DATA_EXPORT_FORMAT_TYPE eExportasprintfType = EXPORT_FORMAT_TVENCRYPT;
	if (LOGDEV_FTP != device) {
		pDataTransfer->getDataExportasprintf(device, eExportasprintfType);
	}
//////RTVIEW - 2060 fix
	// Only check pen queues
	if (penInstance < V6_MAX_PENS) {
		if (QMBLKSER_OK == pq_manager->GetBlockServices().GetQueue(QMC_QUEUE_PEN_LOG, penInstance, QueueHandle)) {
			if (QMC_QUEUE_EMPTY == pq_manager->GetDiskServices().GetQueueStatus(QueueHandle)) {
				// if the queue is empty, use the full queue space
				ULONG ulQueuueMaxBlocks = pq_manager->GetDiskServices().GetMaxNumBlocksQueue(QueueHandle);
				if (0 != ulQueuueMaxBlocks)
					Blocksleft = pq_manager->GetDiskServices().GetMaxNumBlocksQueue(QueueHandle);
			} else {
				// queue exists and contains data
				// get the current transaction point and check that it's valid
				T_QMC_FILE_BLOCK_TRANSACTION *pTransactionPoint = pDeviceStatus->GetStatus(device, penInstance,
						TYPE_TRANSFERED, eExportasprintfType);
				ValidateTransactionPoint(pTransactionPoint, QueueHandle);
				if ((QMC_INVALID_FILE_NUMBER != pTransactionPoint->fileId
						&& QMC_INVALID_BLOCK_NUMBER != pTransactionPoint->blockId)
						&& ((TRUE == pq_manager->ValidateFileId(pTransactionPoint->fileId))
								|| (TRUE == pq_manager->ValidateBlockId(pTransactionPoint->blockId)))) {
					if (QMC_TRANS_RECYCLED == pTransactionPoint->recycleState) {
						// Queue is in re-cycle, no space available
						Blocksleft = 0L;
					} else {
						// calculate the (probable) queue free space
						ULONG TotalQueueBlocks = pq_manager->GetDiskServices().GetMaxNumBlocksQueue(QueueHandle);
						LONG BlocksUsed = pq_manager->GetDiskServices().GetNumBlocksInFileQueueFromPoint(QueueHandle,
								pTransactionPoint->fileId, pTransactionPoint->blockId);
						if (BlocksUsed > 0) {
							if (static_cast<ULONG>(BlocksUsed) < TotalQueueBlocks)
								Blocksleft = TotalQueueBlocks - BlocksUsed;
						} else if (TotalQueueBlocks > 0) {
							// no blocks have been used yet so simply set the blocks left to the
							// total number of blocks available to the queue
							Blocksleft = TotalQueueBlocks;
						} else {
							// the blocks left and total queue blocks are both zero which implies
							// the pen is disabled so leave the blocks left as QUEUE_NOT_IN_USE
							Blocksleft = QUEUE_NOT_IN_USE;
						}
					}
				} else {
					// transaction point is invalid (??) assume the full queue space is available
					ULONG ulQueuueMaxBlocks = pq_manager->GetDiskServices().GetMaxNumBlocksQueue(QueueHandle);
					if (0 != ulQueuueMaxBlocks)
						Blocksleft = pq_manager->GetDiskServices().GetMaxNumBlocksQueue(QueueHandle);
				}
			} // ! QMC_QUEUE_EMPTY
		} // QMBLKSER_OK
	} // V6_MAX_PENS
	return Blocksleft;
}
//****************************************************************************
/// Queue Monitor Calculate queue free space in blocks
///
/// @return			Queue free space in blocks
///
/// @note Used to calculate recording time left
//****************************************************************************
ULONG CQMonitor::GetQueueSpaceBlocks(T_LOG_DEVICE device) {
	CQueueManager *pq_manager = CQueueManager::GetHandle();
	CLogDeviceStatus *pDeviceStatus = CLogDeviceStatus::GetHandle();
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	USHORT QueueHandle;
	T_QMBLKSER_RETURN_VALUE q_error;
	ULONG TotalQueueBlocks = 0L;
	ULONG TotalUsedBlocks = 0L;
	for (int Queue = 0; Queue < V6_MAX_PENS; Queue++) {
		q_error = pq_manager->GetBlockServices().GetQueue(QMC_QUEUE_PEN_LOG, Queue, QueueHandle);
		if (QMBLKSER_OK == q_error && QMC_QUEUE_EMPTY != pq_manager->GetDiskServices().GetQueueStatus(QueueHandle)) {
			TotalQueueBlocks += pq_manager->GetDiskServices().GetNumBlocksInFileQueue(QueueHandle);
		}
		//Update the scheduler thread count for each iteration
		if (pThreadInfo != NULL) {
			pThreadInfo->UpdateThreadCounter(AM_TX_SCHEDULER_THREAD);
		}
	}
	for (int List = 0; List < CMessageListServices::msqMAX_QUEUES; List++) {
		q_error = pq_manager->GetBlockServices().GetQueue(QMC_QUEUE_MESSAGE, List, QueueHandle);
		if (QMBLKSER_OK == q_error && QMC_QUEUE_EMPTY != pq_manager->GetDiskServices().GetQueueStatus(QueueHandle)) {
			TotalQueueBlocks += pq_manager->GetDiskServices().GetNumBlocksInFileQueue(QueueHandle);
		}
		//Update the scheduler thread count for each iteration
		if (pThreadInfo != NULL) {
			pThreadInfo->UpdateThreadCounter(AM_TX_SCHEDULER_THREAD);
		}
	}
	return TotalQueueBlocks;
}
//****************************************************************************
/// Queue Monitor Validate and (if required) reset a transaction point
///
/// @param[in]		pTransactionPoint - 
/// @param[in]		QueueHandle
///
/// @return			TRUE if the point is OK, else false if is no longer valid
///
/// @note --- Delete if not requried ---
//****************************************************************************
BOOL CQMonitor::ValidateTransactionPoint(T_QMC_FILE_BLOCK_TRANSACTION *pTransactionPoint, USHORT QueueHandle) {
	BOOL bResult = TRUE;
	CQueueManager *pq_manager = CQueueManager::GetHandle();
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	// Check for a first time use on the transaction point; if so, use the oldest available
	if (QMC_INVALID_FILE_NUMBER == pTransactionPoint->fileId
			|| QMC_INVALID_BLOCK_NUMBER == pTransactionPoint->blockId) {
		if (QMC_QUEUE_EMPTY != pq_manager->GetDiskServices().GetQueueStatus(QueueHandle)) {
			pTransactionPoint->numOfBlocksLastRequested = 1;
			pq_manager->GetDiskServices().ResetToOldestAvailable(USRREQSER_USER_LOGGING, QueueHandle,
					pTransactionPoint);
			// message based not direct, also no reply!
			int iTryCount = 100;
			while (0 != pTransactionPoint->numOfBlocksLastRequested && iTryCount > 0) {
				//Update the scheduler thread count for each iteration
				if (pThreadInfo != NULL) {
					pThreadInfo->UpdateThreadCounter(AM_TX_SCHEDULER_THREAD);
				}
				//	OutputDebugString(L"**sleep 10ms");
				sleep(10);
				--iTryCount;
			}
			if (0 == iTryCount) {
				qDebug(" No reply from ResetToOldestAvailable(1) \n");
			}
			// check if the file ID is still invalid (e.g. for unused queues)
			if (QMC_INVALID_FILE_NUMBER == pTransactionPoint->fileId
					|| QMC_INVALID_BLOCK_NUMBER == pTransactionPoint->blockId) {
				bResult = FALSE;
			}
		} else
			bResult = FALSE;		// Can't reset, no longer valid
	}
	return bResult;
}
//****************************************************************************
/// Queue Monitor clear all new data
///
/// @return	
///
/// @note 
//****************************************************************************
void CQMonitor::ClearAllNewData() {
	CPenManager *pPenManager = CPenManager::GetHandle();
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
	// Flush all existing log blocks
	if (NULL != pPenManager)	// just in case...
			{
		pPenManager->FlushAllLogChannels();
	}
	// Allow time for the pen flush
	sleep(100);
	m_hCritical.lock();
	for (USHORT deviceInstance = 0; deviceInstance < LOGDEV_MAX_DEVICES; deviceInstance++) {
		ClearNewData((T_LOG_DEVICE) deviceInstance);
		//Update the scheduler thread count for escheduler thread
		if (pThreadInfo != NULL) {
			pThreadInfo->UpdateThreadCounter(AM_TX_SCHEDULER_THREAD);
		}
	}
	m_hCritical.lock();
	ClearNumBlocksWaiting();
}
//****************************************************************************
/// Queue Monitor clear all new FTP data
///
/// @return	
///
/// @note 
//****************************************************************************
void CQMonitor::ClearAllNewFTPData() {
	ClearNewData(LOGDEV_FTP);
}
//****************************************************************************
/// Queue Monitor clear new data for a specified device
///
/// @return	
///
/// @note 
//****************************************************************************
void CQMonitor::ClearNewData(T_LOG_DEVICE device) {
	CQueueManager *pq_manager = CQueueManager::GetHandle();
	CLogDeviceStatus *pDeviceStatus = CLogDeviceStatus::GetHandle();
	CDataTransfer *pDataTransfer = CDataTransfer::GetHandle();
	pDataTransfer->Initialise();
	USHORT QueueHandle;
	T_QMBLKSER_RETURN_VALUE q_error;
	CThreadInfo *pThreadInfo = CThreadInfo::GetHandle();
//////RTVIEW - 2060 fix - added type of export format in getstatus and setstatus methods
	T_DATA_EXPORT_FORMAT_TYPE eExportasprintfType = EXPORT_FORMAT_TVENCRYPT;
	if (LOGDEV_FTP != device) {
		pDataTransfer->getDataExportasprintf(device, eExportasprintfType);
	}
//////RTVIEW - 2060 fix CSV export 
	for (int Instance = 0; Instance < V6_MAX_PENS; Instance++) {
		//Update the scheduler thread count for escheduler thread
		if (pThreadInfo != NULL) {
			pThreadInfo->UpdateThreadCounter(AM_TX_SCHEDULER_THREAD);
		}
		q_error = pq_manager->GetBlockServices().GetQueue(QMC_QUEUE_PEN_LOG, Instance, QueueHandle);
		if (QMBLKSER_OK == q_error) {
			T_QMC_FILE_BLOCK_TRANSACTION tempTransactionPoint = *pDeviceStatus->GetStatus(device, Instance,
					TYPE_TRANSFERED, eExportasprintfType);
			pq_manager->GetDiskServices().GetNewestBlockAndFile(QueueHandle, &tempTransactionPoint.fileId,
					&tempTransactionPoint.blockId);
			tempTransactionPoint.numOfBlocksLastRequested = QMC_ZERO;
			pDeviceStatus->SetStatus(device, Instance, TYPE_TRANSFERED, tempTransactionPoint, eExportasprintfType);
		}
	}
	for (int List = 0; List < CMessageListServices::msqMAX_QUEUES; List++) {
		//Update the scheduler thread count for escheduler thread
		if (pThreadInfo != NULL) {
			pThreadInfo->UpdateThreadCounter(AM_TX_SCHEDULER_THREAD);
		}
		q_error = pq_manager->GetBlockServices().GetQueue(QMC_QUEUE_MESSAGE, List, QueueHandle);
		if (QMBLKSER_OK == q_error) {
			T_QMC_FILE_BLOCK_TRANSACTION tempTransactionPoint = *pDeviceStatus->GetStatus(device, List + V6_MAX_PENS,
					TYPE_TRANSFERED, eExportasprintfType);
			pq_manager->GetDiskServices().GetNewestBlockAndFile(QueueHandle, &tempTransactionPoint.fileId,
					&tempTransactionPoint.blockId);
			tempTransactionPoint.numOfBlocksLastRequested = QMC_ZERO;
			pDeviceStatus->SetStatus(device, List + V6_MAX_PENS, TYPE_TRANSFERED, tempTransactionPoint,
					eExportasprintfType);
		}
	}
}
/// Accessor for the blocks per hour variable
//****************************************************************************
///	const ULONG GetBlocksUsedPerHour()
///
/// Accessor for the blocks per hour variable
///
/// @note 
//****************************************************************************
const ULONG CQMonitor::GetBlocksUsedPerHour() {
	m_hCritical.lock();
	ULONG ulBlockPerHour = static_cast<ULONG>(m_fBlockPerHour);
	m_hCritical.lock();
	return ulBlockPerHour;
}

/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 Log record utilities
/// @n LogRateControl.cpp
/// @n Utilities for maintaining log rate.
/// @author MM
/// @date 13/02/2012
///
// 
// *******************************************
// Revision History
// *******************************************
//////////////////////////////////////////////////////////////////////
#include "TVTime.h"
#include "LogRateControl.h"
#include "V6globals.h"
const int START_LOG_IMMEDIATELY = 1;
const int START_LOG_NEXT_CYCLE = 2;
//****************************************************************************
/// LogRecord utility: class constructor
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
CLogRateControl::CLogRateControl() {
	m_Counter = START_LOG_IMMEDIATELY;
	m_Rate = 0;
	m_CurrentRate = 0;
	m_PenNumber = 0;
	m_bIsLogFirstTime = FALSE;
} //end CLogRateControl( )
//****************************************************************************
/// LogRecord utility: class destructor
///
/// @return			none
///
/// @note --- Delete if not requried ---
//****************************************************************************
CLogRateControl::~CLogRateControl() {
} //end ~CLogRateControl()
//****************************************************************************
/// LogRecord utility: change log rate
///
/// @param[in]	logRate - Indicates the log rate
/// @param[in]	rateUnits - Indicates the rate units
///
/// @return		none
///
//****************************************************************************
void CLogRateControl::ChangeRate(ULONG logRate, ULONG rateUnits) {
	int rateToUse = GetLogRate(rateUnits, logRate);		// Set to Standard Pen rate
	// Calculate the divide down value for logging at the current processing rate;
	m_Rate = MSEC_TENTHS_TO_TICKS(rateToUse) / pSYSTIMER->GetCurrentProcessInterval();
	// Calculate the *actual* log rate (may be faster then requested rate)
	m_CurrentRate = pSYSTIMER->GetCurrentProcessInterval() * m_Rate * 100;
	m_Counter = START_LOG_IMMEDIATELY;
} //end ChangeRate()
//****************************************************************************
/// LogRecord utility: Divide down logging rate to match process rates
///
/// @return		TRUE when reading needs to be logged, else FALSE
///
//****************************************************************************
BOOL CLogRateControl::LogReading() {
	BOOL bResult = FALSE;
	if (--m_Counter <= 0) {
		// Time to log reset the counter and return TRUE 
		m_Counter = m_Rate;
		bResult = TRUE;
	}
	return bResult;
} //end LogReading()
//****************************************************************************
/// SetPenConfigNumber: Set the pen number for which the log Rate is configured
///
/// @return		void
///
//****************************************************************************
void CLogRateControl::SetPenConfigNumber(int penNumber) {
	m_PenNumber = penNumber;
} //end SetPenCount()
//****************************************************************************
/// GetConfigPenNumber: Returns the pen number for which the log Rate is configured
///
///
//****************************************************************************
int CLogRateControl::GetConfigPenNumber() {
	return m_PenNumber;
} //end GetConfigPenNumber()
//****************************************************************************
//	const ULONG GetLogRate( ULONG RateUnits,ULONG logRate )
///
/// Method that determines the required log rate
///
/// @param[in]  rateUnits - Units of log rate
/// @param[in]  logRate  - Log rate
///
/// @return The log rate in millisecond tenths
///
//****************************************************************************
const ULONG CLogRateControl::GetLogRate(ULONG rateUnits, ULONG logRate) {
	ULONG ulMsTenthLogRate = 0;
	const int lruHours = 0xE4;
	const int lruMinutes = 0xE5;
	const int lruSeconds = 0xE6;
	const int lruMsec = 0xE7;
	// must be seconds, minutes or hours so calculate a multiplier
	ULONG ulMultiplier = 0;
	switch (rateUnits) {
	case lruSeconds:
		ulMultiplier = RATE_S_TO_MS_MULTIPLIER;
		break;
	case lruMinutes:
		ulMultiplier = RATE_M_TO_MS_MULTIPLIER;
		break;
	case lruHours:
		ulMultiplier = RATE_H_TO_MS_MULTIPLIER;
		break;
	case lruMsec:
		ulMultiplier = 1;
		break;
	default:
		// should never happen but set to 10000 just in case
		ulMultiplier = RATE_S_TO_MS_MULTIPLIER;
		break;
	}
	ULONG usLogRate = logRate;
	// check required due to the variable size changing within a V6 config upgrade thus enabling
	// an invalid value of zero to be created (or maybe above 60 )
	if ((usLogRate == 0) || (usLogRate > 60)) {
		// default to 1
		usLogRate = 1;
	}
	// now multiply the rate by the multiplier and we will have our value in millisecond tenths
	ulMsTenthLogRate = ulMultiplier * usLogRate;
	return ulMsTenthLogRate;
}	//end GetLogRate()
//****************************************************************************
/// SetLogFirstTime: Sets the flag to indicate if the logging is requested for
/// the first time
///
/// @return		void
///
//****************************************************************************
void CLogRateControl::SetLogFirstTime(BOOL bIsLogFirstTime) {
	m_bIsLogFirstTime = bIsLogFirstTime;
}	//end SetLogFirstTime()
//****************************************************************************
/// IsLogFirstTime: Gets the flag to indicate if the logging is requested for
/// the first time
///
/// @return		void
///
//****************************************************************************
BOOL CLogRateControl::IsLogFirstTime() {
	return m_bIsLogFirstTime;
}	//end IsLogFirstTime()

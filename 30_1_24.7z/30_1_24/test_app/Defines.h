#ifndef DEFINES_H
#define DEFINES_H
#include <string.h>
#include <iostream>
#include <QtGlobal>
#include <QString>
#include <QThread>
#include <stddef.h>
#include <QRect>
#include <inttypes.h>
#include <stdint.h>
#include <unistd.h> //LTTS added to solve _swab error
#define STATUS_WAIT_0 ((DWORD)0x00000000L)
#define STATUS_ABANDONED_WAIT_0 ((DWORD)0x00000080L)
#define WAIT_TIMEOUT 258L //LTTS Copied from winerror.h
#define WAIT_FAILED ((DWORD)0xFFFFFFFF)
#define WAIT_OBJECT_0 ((STATUS_WAIT_0)+0)
#define WAIT_ABANDONED ((STATUS_ABANDONED_WAIT_0)+0)
#define WAIT_ABANDONED_0 ((STATUS_ABANDONED_WAIT_0)+0)
#define WM_APP 0x8000
#define FLT_MAX 10
#define afx_msg
#define WINAPI
#define MAX_PATH 200
#define DECLARE_MESSAGE_MAP()
#define SIZE_OF_BYTE 1
#define INSTANCE_LENGTH 2
#define interface //! This is COM defined macro
#define INFINITE -1
#define IDOK 0
#define RtlEqualMemory(Destination,Source,Length) (!memcmp((Destination),(Source),(Length)))
#define RtlMoveMemory(Destination,Source,Length) memmove((Destination),(Source),(Length))
#define RtlCopyMemory(Destination,Source,Length) memcpy((Destination),(Source),(Length))
#define RtlFillMemory(Destination,Length,Fill) memset((Destination),(Fill),(Length))
#define RtlZeroMemory(Destination,Length) memset((Destination),0,(Length))
#define MoveMemory(Destination,Source,Length) memmove((Destination),(Source),(Length))
#define CopyMemory(Destination,Source,Length) memcpy((Destination),(Source),(Length))
#define FillMemory(Destination,Length,Fill) memset((Destination),(Fill),(Length))
#define ZeroMemory(Destination,Length) memset((Destination),0,(Length))
#define LMEM_FIXED          0x0000
#define LMEM_MOVEABLE       0x0002
#define LMEM_NOCOMPACT      0x0010
#define LMEM_NODISCARD      0x0020
#define LMEM_ZEROINIT       0x0040
#define LMEM_MODIFY         0x0080
#define LMEM_DISCARDABLE    0x0F00
#define LMEM_VALID_FLAGS    0x0F72
#define LMEM_INVALID_HANDLE 0x8000

#define REG_NONE                    ( 0 )   // No value type
#define REG_SZ                      ( 1 )   // Unicode nul terminated string
#define REG_EXPAND_SZ               ( 2 )   // Unicode nul terminated string
                                            // (with environment variable references)
#define REG_BINARY                  ( 3 )   // Free form binary
#define REG_DWORD                   ( 4 )   // 32-bit number
#define REG_DWORD_LITTLE_ENDIAN     ( 4 )   // 32-bit number (same as REG_DWORD)
#define REG_DWORD_BIG_ENDIAN        ( 5 )   // 32-bit number
#define REG_LINK                    ( 6 )   // Symbolic Link (unicode)
#define REG_MULTI_SZ                ( 7 )   // Multiple Unicode strings
#define REG_RESOURCE_LIST           ( 8 )   // Resource list in the resource map
#define REG_FULL_RESOURCE_DESCRIPTOR ( 9 )  // Resource list in the hardware description
#define REG_RESOURCE_REQUIREMENTS_LIST ( 10 )
#define REG_QWORD                   ( 11 )  // 64-bit number
#define REG_QWORD_LITTLE_ENDIAN     ( 11 )  // 64-bit number (same as REG_QWORD)
#define REG_MUI_SZ

#define OutputDebugString(x) qDebug() << x
#define _I64_MAX 0x7FFFFFFFFFFFFFFF

typedef char CHAR, *NPSTR, *LPSTR, *PSTR;
typedef unsigned char UINT8;
typedef wchar_t WCHAR;
typedef long __int64;
typedef bool BOOL, BOOLEAN;
typedef BOOL *PBOOL;
typedef char *_TCHAR;
typedef const char *PCSTR;
typedef int INT32, *LPINT, *INT_PTR;
typedef unsigned int UINT32;
typedef unsigned short USHORT;
typedef unsigned short UINT16;
typedef unsigned long ULONG, *PULONG;
typedef ulong ULONG, DWORD, *DWORD_PTR, *PDWORD, *LPDWORD;
typedef uchar UCHAR;
typedef qint64 LONGLONG, *LONG_PTR;
typedef unsigned int UINT, *UINT_PTR;
typedef quint64 ULONGLONG;
typedef wchar_t WCHAR;
typedef unsigned int WORD, *PWORD,*LPWORD;
typedef long LONG;
typedef unsigned char byte, BYTE, *PBYTE, *LPBYTE;
typedef char TCHAR; //LTTSR
typedef DWORD COLORREF; //LTTSR
typedef void VOID, *PVOID; //LTTSR
typedef PVOID HANDLE; //LTTSR
typedef PVOID HINSTANCE; //LTTSR
typedef HINSTANCE HMODULE;
typedef const char *LPCSTR;
typedef void *LPVOID;
typedef wchar_t *LPWSTR, *PWSTR;
typedef const wchar_t *LPCWSTR;
typedef const void *LPCVOID;
#define FALSE false
#define TRUE true
#define REG_SZ 1
typedef char CHAR;
typedef LONG HRESULT;
typedef const char *LPCTSTR;
typedef double DOUBLE;
typedef short SHORT;
typedef unsigned short ushort;
typedef int INT;
typedef float FLOAT;
typedef unsigned long int ULONG_PTR;
typedef ULONG_PTR SIZE_T;
typedef DWORD COLORREF, *LPCOLORREF;
typedef HANDLE HLOCAL;
typedef WORD CLIPFORMAT;
typedef HANDLE HRGN;
typedef UINT_PTR WPARAM;
typedef LONG_PTR LPARAM;
typedef void *HANDLE;
typedef void *HBRUSH;
#define DECLARE_HANDLE(name) struct name##__ { int unused; }; typedef struct name##__ *name
DECLARE_HANDLE            (HWND);
DECLARE_HANDLE            (HDC);
#define DebugBreak()
class CDC : public QObject
{
    Q_OBJECT
public:

    HDC m_hDC;          // The output DC (must be first data member)
    HDC m_hAttribDC;
};
typedef struct _LARGE_INTEGER {
	signed long int QuadPart;
	char HighPart;
	char LowPart;
} LARGE_INTEGER, *PLARGE_INTEGER;
#define INVALID_HANDLE_VALUE (HANDLE)(~0)
typedef struct _MEMORYSTATUS {
	DWORD dwLength;
	DWORD dwMemoryLoad;
	SIZE_T dwTotalPhys;
	SIZE_T dwAvailPhys;
	SIZE_T dwTotalPageFile;
	SIZE_T dwAvailPageFile;
	SIZE_T dwTotalVirtual;
	SIZE_T dwAvailVirtual;
} MEMORYSTATUS, *LPMEMORYSTATUS;
typedef struct tagRGBQUAD {
	BYTE rgbBlue;
	BYTE rgbGreen;
	BYTE rgbRed;
	BYTE rgbReserved;
} RGBQUAD;
typedef struct _GUID {
	DWORD Data1;
	WORD Data2;
	WORD Data3;
	BYTE Data4[8];
} GUID;
typedef GUID UUID;
typedef struct tagBITMAPINFOHEADER {
	DWORD biSize;
	LONG biWidth;
	LONG biHeight;
	WORD biPlanes;
	WORD biBitCount;
	DWORD biCompression;
	DWORD biSizeImage;
	LONG biXPelsPerMeter;
	LONG biYPelsPerMeter;
	DWORD biClrUsed;
	DWORD biClrImportant;
} BITMAPINFOHEADER, *LPBITMAPINFOHEADER, *PBITMAPINFOHEADER;
typedef struct tagBITMAPINFO {
	BITMAPINFOHEADER bmiHeader;
	RGBQUAD bmiColors[1];
} BITMAPINFO, *LPBITMAPINFO, *PBITMAPINFO;
typedef enum {
	Normal = 1
} FontWeight;
typedef struct _SYSTEM_INFO {
	union {
		DWORD dwOemId;
		struct {
			WORD wProcessorArchitecture;
			WORD wReserved;
		} DUMMYSTRUCTNAME;
	} DUMMYUNIONNAME;
	DWORD dwPageSize;
	LPVOID lpMinimumApplicationAddress;
	LPVOID lpMaximumApplicationAddress;
	DWORD_PTR dwActiveProcessorMask;
	DWORD dwNumberOfProcessors;
	DWORD dwProcessorType;
	DWORD dwAllocationGranularity;
	WORD wProcessorLevel;
	WORD wProcessorRevision;
} SYSTEM_INFO, *LPSYSTEM_INFO;
typedef struct tagCREATESTRUCTA {
	LPVOID lpCreateParams;
	HINSTANCE hInstance;
// HMENU	hMenu;
// HWND	hwndParent;
	int cy;
	int cx;
	int y;
	int x;
	LONG style;
	PCSTR lpszName;
	PCSTR lpszClass;
	DWORD dwExStyle;
} CREATESTRUCTA, *LPCREATESTRUCT;
typedef struct tagDRAWITEMSTRUCT {
	UINT CtlType;
	UINT CtlID;
	UINT itemID;
	UINT itemAction;
	UINT itemState;
// HWND	hwndItem;
// HDC	hDC;
	QRect rcItem;
	ULONG_PTR itemData;
} DRAWITEMSTRUCT, *PDRAWITEMSTRUCT, *LPDRAWITEMSTRUCT;
typedef struct _LIST_ENTRY {
	struct _LIST_ENTRY *Flink;
	struct _LIST_ENTRY *Blink;
} LIST_ENTRY, *PLIST_ENTRY, PRLIST_ENTRY;
typedef struct _RTL_QMutex_DEBUG {
	WORD Type;
	WORD CreatorBackIndex;
// RTL_QMutex *CriticalSection;
	LIST_ENTRY ProcessLocksList;
	DWORD EntryCount;
	DWORD ContentionCount;
	DWORD Spare[2];
} RTL_QMutex_DEBUG, *PRTL_QMutex_DEBUG;
typedef struct {
	PRTL_QMutex_DEBUG DebugInfo;
	LONG LockCount;
	LONG RecursionCount;
	HANDLE OwningThread;
	HANDLE LockSemaphore;
	ULONG_PTR SpinCount;
} RTL_QMutex, *LPQMutex;
typedef struct _SYSTEMTIME {
	WORD wYear;
	WORD wMonth;
	WORD wDayOfWeek;
	WORD wDay;
	WORD wHour;
	WORD wMinute;
	WORD wSecond;
	WORD wMilliseconds;
} SYSTEMTIME, *PSYSTEMTIME, *LPSYSTEMTIME;
typedef struct _ULARGE_INTEGER {
	DWORD LowPart;
	DWORD HighPart;
} ULARGE_INTEGER, *PULARGE_INTEGER;
typedef struct _TIME_ZONE_INFORMATION {
	LONG Bias;
	WCHAR StandardName[32];
	SYSTEMTIME StandardDate;
	LONG StandardBias;
	WCHAR DaylightName[32];
	SYSTEMTIME DaylightDate;
	LONG DaylightBias;
} TIME_ZONE_INFORMATION, *PTIME_ZONE_INFORMATION, *LPTIME_ZONE_INFORMATION;
typedef enum {
	S_OK,
	S_FALSE,
	E_ABORT,
	E_ACCESSDENIED,
	E_FAIL,
	E_HANDLE,
	E_INVALIDARG,
	E_NOINTERFACE,
	E_NOTIMPL,
	E_OUTOFMEMORY,
	E_POINTER,
	E_UNEXPECTED
} ERROR_DEF;
typedef enum _TCPSTATE {
	TCPSTATE_CLOSED,
	TCPSTATE_LISTEN,
	TCPSTATE_SYN_SENT,
	TCPSTATE_SYN_RCVD,
	TCPSTATE_ESTABLISHED,
	TCPSTATE_FIN_WAIT_1,
	TCPSTATE_FIN_WAIT_2,
	TCPSTATE_CLOSE_WAIT,
	TCPSTATE_CLOSING,
	TCPSTATE_LAST_ACK,
	TCPSTATE_TIME_WAIT,
	TCPSTATE_MAX
} TCPSTATE;
typedef struct _TCP_INFO_v1 {
	TCPSTATE State;
	ULONG Mss;
	LONGLONG ConnectionTimeMs;
	BOOLEAN TimestampsEnabled;
	ULONG RttUs;
	ULONG MinRttUs;
	ULONG BytesInFlight;
	ULONG Cwnd;
	ULONG SndWnd;
	ULONG RcvWnd;
	ULONG RcvBuf;
	LONGLONG BytesOut;
	LONGLONG BytesIn;
	ULONG BytesReordered;
	ULONG BytesRetrans;
	ULONG FastRetrans;
	ULONG DupAcksIn;
	ULONG TimeoutEpisodes;
	UCHAR SynRetrans;
	ULONG SndLimTransRwin;
	ULONG SndLimTimeRwin;
	LONGLONG SndLimBytesRwin;
	ULONG SndLimTransCwnd;
	ULONG SndLimTimeCwnd;
	LONGLONG SndLimBytesCwnd;
	ULONG SndLimTransSnd;
	ULONG SndLimTimeSnd;
	LONGLONG SndLimBytesSnd;
} TCP_INFO_v1, *PTCP_INFO_v1;
typedef enum {
	DEFAULT_QUALITY = 0x00,
	DRAFT_QUALITY = 0x01,
	PROOF_QUALITY = 0x02,
	NONANTIALIASED_QUALITY = 0x03,
	ANTIALIASED_QUALITY = 0x04,
	CLEARTYPE_QUALITY = 0x05
} FontQuality;
typedef struct tagDEC {
	WORD wReserved;
	BYTE scale;
	BYTE sign;
	ULONG Hi32;
	ULONGLONG Lo64;
} DECIMAL;
typedef enum {
	STRING
} VARTYPE;
typedef enum VARENUM {
	VT_EMPTY,
	VT_NULL,
	VT_I2,
	VT_I4,
	VT_R4,
	VT_R8,
	VT_CY,
	VT_DATE,
	VT_BSTR,
	VT_DISPATCH,
	VT_ERROR,
	VT_BOOL,
	VT_VARIANT,
	VT_UNKNOWN,
	VT_DECIMAL,
	VT_I1,
	VT_UI1,
	VT_UI2,
	VT_UI4,
	VT_I8,
	VT_UI8,
	VT_INT,
	VT_UINT,
	VT_VOID,
	VT_HRESULT,
	VT_PTR,
	VT_SAFEARRAY,
	VT_CARRAY,
	VT_USERDEFINED,
	VT_LPSTR,
	VT_LPWSTR,
	VT_FILETIME,
	VT_BLOB,
	VT_STREAM,
	VT_STORAGE,
	VT_STREAMED_OBJECT,
	VT_STORED_OBJECT,
	VT_BLOB_OBJECT,
	VT_CF,
	VT_CLSID,
	VT_VECTOR,
	VT_ARRAY,
	VT_BYREF,
	VT_RESERVED,
	VT_ILLEGAL,
	VT_ILLEGALMASKED,
	VT_TYPEMASK
};
enum {
	ERROR_SUCCESS = 0, ERROR_DISK_FULL
};
typedef LONG_PTR LRESULT;
typedef struct tagNMHDR {
	HANDLE hwndFrom;
	UINT idFrom;
	UINT code;         // NM_ code
} NMHDR;
typedef NMHDR *LPNMHDR;
/// TODO: implement this
#define SecureZeroMemory(x,y)
typedef struct _FILETIME {
	DWORD dwLowDateTime;
	DWORD dwHighDateTime;
} FILETIME, *PFILETIME, *LPFILETIME;
typedef struct _COMSTAT {
    DWORD fCtsHold : 1;
    DWORD fDsrHold : 1;
    DWORD fRlsdHold : 1;
    DWORD fXoffHold : 1;
    DWORD fXoffSent : 1;
    DWORD fEof : 1;
    DWORD fTxim : 1;
    DWORD fReserved : 25;
    DWORD cbInQue;
    DWORD cbOutQue;
} COMSTAT, *LPCOMSTAT;
typedef struct CRITICAL_SECTION {
    unsigned int LockCount;         /* Nesting count on critical section */
    HANDLE OwnerThread;             /* Handle of owner thread */
    HANDLE hCrit;                   /* Handle to this critical section */
    DWORD needtrap;                 /* Trap in when freeing critical section */
    DWORD dwContentions;            /* Count of contentions */
} CRITICAL_SECTION, *LPCRITICAL_SECTION;

typedef struct _PROCESS_INFORMATION {
    HANDLE hProcess;
    HANDLE hThread;
    DWORD dwProcessId;
    DWORD dwThreadId;
} PROCESS_INFORMATION, *PPROCESS_INFORMATION, *LPPROCESS_INFORMATION;
typedef struct tagVARIANT {
	VARTYPE vt;
	union {
		struct {
			WORD wReserved1;
			WORD wReserved2;
			WORD wReserved3;
			union {
				LONGLONG llVal;
				LONG lVal;
				BYTE bVal;
				SHORT iVal;
				FLOAT fltVal;
				DOUBLE dblVal;
				bool boolVal;
				bool __OBSOLETE__VARIANT_BOOL;
//		SCODE		scode;
//		CY		cyVal;
//		DATE		date;
//		BSTR		bstrVal;
//		IUnknown	*punkVal;
//		IDispatch	*pdispVal;
//				SAFEARRAY *parray;
				BYTE *pbVal;
				SHORT *piVal;
				LONG *plVal;
				LONGLONG *pllVal;
				FLOAT *pfltVal;
				DOUBLE *pdblVal;
				/*VARIANT_BOOL *pboolVal;
				 VARIANT_BOOL *__OBSOLETE__VARIANT_PBOOL;
				 SCODE		*pscode;
				 CY		*pcyVal;
				 DATE		*pdate;
				 BSTR		*pbstrVal;
				 IUnknown	**ppunkVal;
				 IDispatch	**ppdispVal;
				 SAFEARRAY	**pparray;
				 VARIANT	*pvarVal;*/
				PVOID byref;
				CHAR cVal;
				USHORT uiVal;
				ULONG ulVal;
				ULONGLONG ullVal;
				INT intVal;
				UINT uintVal;
				DECIMAL *pdecVal;
				CHAR *pcVal;
				USHORT *puiVal;
				ULONG *pulVal;
				ULONGLONG *pullVal;
				INT *pintVal;
				UINT *puintVal;
				struct {
					PVOID pvRecord;
//		IRecordInfo *pRecInfo;
				} __VARIANT_NAME_4;
			} __VARIANT_NAME_3;
		} __VARIANT_NAME_2;
		DECIMAL decVal;
	} __VARIANT_NAME_1;
} VARIANT;
#endif // DEFINES_H

/*
 * ---------------------------------------------------------------------------
 * Copyright (c) 2015 UTC - All rights reserved.
 *
 * Model Name:         PitHandlePesConfig
 * Code Generation:     -
 * Svn:
 * ---------------------------------------------------------------------------
 */

//! @details
//!   To prevent the usage of this header in the production binary code
//!   Only be used for the cmocka test.
//!   define CMOCKA to be externally provided, see MakefileCmocka.
#ifndef CMOCKA
#error "Only to be used with CMOCKA library"
#endif

#ifndef RTW_HEADER_CanMsgAlias_h_
#define RTW_HEADER_CanMsgAlias_h_
#include "rtwtypes.h"

typedef enum
{
    can_message_application_id_invalid = 0,/* Default value */
    CedesMsg11_msg_MSGID,
    CedesMsg12_msg_MSGID,
    CedesMsg21_msg_MSGID,
    CedesMsg22_msg_MSGID,
    PesCarPosition_msg_MSGID,
    PesFloorStatus_msg_MSGID,
    PesClipPosition_msg_MSGID,
    PesSafetyDetails1_msg_MSGID,
    PesSafetyDetails2_msg_MSGID,
    PesSafetyStatus_msg_MSGID,
    PesDbpStatus_msg_MSGID,
    PesFieldTestStatus_msg_MSGID,
    SafCarCommand_msg_MSGID,
    SafCarInputs_msg_MSGID,
    SafCarStatus_msg_MSGID,
    SafPitCommand_msg_MSGID,
    SafPitInputs_msg_MSGID,
    SafSabCommand_msg_MSGID,
    SafSabStatus_msg_MSGID,
    SystemFloorTable_ByScon_msg_MSGID,
    SystemFloorTable_ByDrive_msg_MSGID,
    SystemFloorTable_ByOcss_msg_MSGID,
    FloorTableRequest_ByScon_msg_MSGID,
    FloorTableRequest_ByDrive_msg_MSGID,
    FloorTableRequest_ByOcss_msg_MSGID,
    DriveRequest2_msg_MSGID,
    PesAvAlarm_msg_MSGID,
    DriveFeatureStatus_msg_MSGID,
    PesDbpRequest_msg_MSGID,
    PesFieldTestRequest_ByDrive_msg_MSGID,
    PesFieldTestRequest_msg_MSGID,
    CedesMsg1A_msg_MSGID,
    CedesMsg1B_msg_MSGID,
    CedesMsg2A_msg_MSGID,
    CedesMsg2B_msg_MSGID,
    PesCommand_msg_MSGID,
    PesTestRequest_msg_MSGID,
    SafCarEvent_msg_MSGID,
    SafPitEvent_msg_MSGID,
    SafSabEvent_msg_MSGID,
    PesRequestByOcss_msg_MSGID,
    PesFeatureStatus_ByScon_msg_MSGID,
    PesTimeLeftUntilTest_ByOcss_msg_MSGID,
    PesTestPermission_msg_MSGID,
    PesTimeLeftUntilTest_ByScon_msg_MSGID,
    PesConfigBySpit_msg_MSGID,
    PesConfigByScar_msg_MSGID,
    PesConfigBySab_msg_MSGID,
    PesConfigByOcss_msg_MSGID,
    PesRequestByScar_msg_MSGID,
    PesRequestBySconOnCarBus_msg_MSGID,
    PesRequestBySconOnPitBus_msg_MSGID,
    PesConfigBySconOnCarBus_msg_MSGID,
    PesConfigBySconOnPitBus_msg_MSGID,
    PesConfigByScon_msg_MSGID,
    PesRequestByDrive_msg_MSGID,
    PesConfigRequest_msg_MSGID,
    StartupByScon_msg_MSGID,
    StartupByScar_msg_MSGID,
    StartupBySpit_msg_MSGID,
    StartupBySab_msg_MSGID,
    SafPitSupervisionReport_msg_MSGID,
    PesFeatureStatus_BySab_msg_MSGID,
    PesNonSafetyRequestByScon_msg_MSGID,
    PesNonSafetyResponseByOcss_msg_MSGID
}

CanMsgAlias;

#endif                                 /* RTW_HEADER_CanMsgAlias_h_ */

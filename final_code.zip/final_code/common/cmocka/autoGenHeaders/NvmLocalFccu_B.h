/*
 * ---------------------------------------------------------------------------
 * Copyright (c) 2015 UTC - All rights reserved.
 *
 * Model Name:         ScomFunction
 * Code Generation:    knuth - Wed Apr 29 22:13:13 2020
 * Svn:
 * ---------------------------------------------------------------------------
 */

//! @details
//!   To prevent the usage of this header in the production binary code
//!   Only be used for the cmocka test.
//!   define CMOCKA to be externally provided, see MakefileCmocka.
#ifndef CMOCKA
#error "Only to be used with CMOCKA library"
#endif

#ifndef RTW_HEADER_NvmLocalFccu_B_h_
#define RTW_HEADER_NvmLocalFccu_B_h_
#include "rtwtypes.h"

/* Local stored FCCU faults. */
typedef struct
{
    /* FCCU fault 0. */
    uint32_T fault0;

    /* FCCU fault 1. */
    uint32_T fault1;

    /* FCCU fault 2. */
    uint32_T fault2;
}

NvmLocalFccu_B;

#endif                                 /* RTW_HEADER_NvmLocalFccu_B_h_ */

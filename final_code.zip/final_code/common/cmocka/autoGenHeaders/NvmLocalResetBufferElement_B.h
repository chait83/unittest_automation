/*
 * ---------------------------------------------------------------------------
 * Copyright (c) 2015 UTC - All rights reserved.
 *
 * Model Name:         ScomFunction
 * Code Generation:    knuth - Wed Apr 29 22:13:13 2020
 * Svn:
 * ---------------------------------------------------------------------------
 */

//! @details
//!   To prevent the usage of this header in the production binary code
//!   Only be used for the cmocka test.
//!   define CMOCKA to be externally provided, see MakefileCmocka.
#ifndef CMOCKA
#error "Only to be used with CMOCKA library"
#endif

#ifndef RTW_HEADER_NvmLocalResetBufferElement_B_h_
#define RTW_HEADER_NvmLocalResetBufferElement_B_h_
#include "rtwtypes.h"

/* Reset buffer element. */
typedef struct
{
    /* Destructive Reset: Voltage Out Of Range */
    bool_t destructiveResetVoltageOutOfRange;

    /* Destructive Reset: Temperature Sensor Failure */
    bool_t destructiveResetTempSensorFailure;

    /* Destructive Reset: Flash Initialization Failure */
    bool_t destructiveResetFlashInitFailure;

    /* Destructive Reset: Functional Reset Escalation */
    bool_t destructiveResetFunctionalResetEscalation;

    /* Destructive Reset: Stcu Unrecoverable Fault */
    bool_t destructiveResetStcuUnrecoverableFault;

    /* Destructive Reset: Fccu Failure To React */
    bool_t destructiveResetFccuFailureToReact;

    /* Destructive Reset: Software Destructive Reset */
    bool_t destructiveResetSoftwareDestructiveReset;

    /* Destructive Reset: Power On */
    bool_t destructiveResetPowerOn;

    /* Functional Reset: Voltage Out Of Range */
    bool_t functionalResetVoltageOutOfRange;

    /* Functional Reset: Temperature Sensor Failure */
    bool_t functionalResetTempSensorFailure;

    /* Functional Reset: Jtag */
    bool_t functionalResetJtag;

    /* Functional Reset: Fccu Software Reaction */
    bool_t functionalResetFccuSoftReaction;

    /* Functional Reset: Fccu Hardware Reaction */
    bool_t functionalResetFccuHardReaction;

    /* Functional Reset: Software Functional Reset */
    bool_t functionalResetSoftwareFunctionalReset;

    /* Functional Reset: Self Test Completed */
    bool_t functionalResetSelfTestCompleted;

    /* Functional Reset: External Reset */
    bool_t functionalResetExternalReset;

    /* Timestamp */
    uint16_T Timestamp_5p0s;

    /* Intented reset. */
    bool_t intended;
}

NvmLocalResetBufferElement_B;

#endif                          /* RTW_HEADER_NvmLocalResetBufferElement_B_h_ */

/*
 * ---------------------------------------------------------------------------
 * Copyright (c) 2015 UTC - All rights reserved.
 *
 * Model Name:         ScomFunction
 * Code Generation:    knuth - Wed Apr 29 22:13:13 2020
 * Svn:
 * ---------------------------------------------------------------------------
 */

//! @details
//!   To prevent the usage of this header in the production binary code
//!   Only be used for the cmocka test.
//!   define CMOCKA to be externally provided, see MakefileCmocka.
#ifndef CMOCKA
#error "Only to be used with CMOCKA library"
#endif

#ifndef RTW_HEADER_NvmGlobalFactoryCfgFactory_B_h_
#define RTW_HEADER_NvmGlobalFactoryCfgFactory_B_h_
#include "rtwtypes.h"

typedef struct
{
    /* Name of the manufacturer */
    uint8_T Name[8];

    /* Manufacturing date year */
    uint8_T DateYear[4];

    /* Manufacturing date week */
    uint8_T DateWeek[2];
}

NvmGlobalFactoryCfgFactory_B;

#endif                          /* RTW_HEADER_NvmGlobalFactoryCfgFactory_B_h_ */

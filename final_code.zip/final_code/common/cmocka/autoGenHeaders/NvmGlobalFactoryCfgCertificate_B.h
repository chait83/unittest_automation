/*
 * ---------------------------------------------------------------------------
 * Copyright (c) 2015 UTC - All rights reserved.
 *
 * Model Name:         ScomFunction
 * Code Generation:    knuth - Wed Apr 29 22:13:13 2020
 * Svn:
 * ---------------------------------------------------------------------------
 */

//! @details
//!   To prevent the usage of this header in the production binary code
//!   Only be used for the cmocka test.
//!   define CMOCKA to be externally provided, see MakefileCmocka.
#ifndef CMOCKA
#error "Only to be used with CMOCKA library"
#endif

#ifndef RTW_HEADER_NvmGlobalFactoryCfgCertificate_B_h_
#define RTW_HEADER_NvmGlobalFactoryCfgCertificate_B_h_
#include "rtwtypes.h"

typedef struct
{
    /* Prefix for manufacturing country */
    uint8_T Prefix;
    uint8_T Number[5];
}

NvmGlobalFactoryCfgCertificate_B;

#endif                      /* RTW_HEADER_NvmGlobalFactoryCfgCertificate_B_h_ */

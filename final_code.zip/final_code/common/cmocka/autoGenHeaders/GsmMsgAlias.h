/*
 * ---------------------------------------------------------------------------
 * Copyright (c) 2015 UTC - All rights reserved.
 *
 * Model Name:         PitSafetyFunction
 * Code Generation:    knuth - Tue Mar 10 17:35:36 2020
 * Svn:
 * ---------------------------------------------------------------------------
 */

//! @details
//!   To prevent the usage of this header in the production binary code
//!   Only be used for the cmocka test.
//!   define CMOCKA to be externally provided, see MakefileCmocka.
#ifndef CMOCKA
#error "Only to be used with CMOCKA library"
#endif

#ifndef RTW_HEADER_GsmMsgAlias_h_
#define RTW_HEADER_GsmMsgAlias_h_
#include "rtwtypes.h"

typedef enum
{
    GsmMsgAlias_IdInvalid = 0,         /* Default value */
    GsmMsgAlias_AdcReadTemp0Request_msg,
    GsmMsgAlias_AdcReadTemp0Reply_msg,
    GsmMsgAlias_CtrlShiftRegReadRequest_msg,
    GsmMsgAlias_CtrlShiftRegRead2Reply_msg,
    GsmMsgAlias_CarShiftRegRequest_msg,
    GsmMsgAlias_CarShiftRegRead2Reply_msg,
    GsmMsgAlias_PitShiftRegRequest_msg,
    GsmMsgAlias_PitShiftRegRead2Reply_msg,
    GsmMsgAlias_AdcReadTemp1Request_msg,
    GsmMsgAlias_AdcReadTemp1Reply_msg,
    GsmMsgAlias_UpdateEvent_msg,
    GsmMsgAlias_UpdateIntegrityErrorClass_msg,
    GsmMsgAlias_HsmVerifySignatureExternalReply_msg,
    GsmMsgAlias_HsmVerifySignatureExternalRequest_msg,
    GsmMsgAlias_HsmStatus_msg
}

GsmMsgAlias;

#endif                                 /* RTW_HEADER_GsmMsgAlias_h_ */

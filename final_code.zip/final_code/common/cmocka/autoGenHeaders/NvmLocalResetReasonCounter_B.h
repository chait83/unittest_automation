/*
 * ---------------------------------------------------------------------------
 * Copyright (c) 2015 UTC - All rights reserved.
 *
 * Model Name:         ScomFunction
 * Code Generation:    knuth - Wed Apr 29 22:13:13 2020
 * Svn:
 * ---------------------------------------------------------------------------
 */

//! @details
//!   To prevent the usage of this header in the production binary code
//!   Only be used for the cmocka test.
//!   define CMOCKA to be externally provided, see MakefileCmocka.
#ifndef CMOCKA
#error "Only to be used with CMOCKA library"
#endif

#ifndef RTW_HEADER_NvmLocalResetReasonCounter_B_h_
#define RTW_HEADER_NvmLocalResetReasonCounter_B_h_
#include "rtwtypes.h"

/* Count of reset reasons stored. */
typedef struct
{
    /* # Destructive Reset: Voltage Out Of Range */
    uint8_T destructiveResetVoltageOutOfRange;

    /* # Destructive Reset: Temperature Sensor Failure */
    uint8_T destructiveResetTempSensorFailure;

    /* # Destructive Reset: Flash Initialization Failure */
    uint8_T destructiveResetFlashInitFailure;

    /* # Destructive Reset: Functional Reset Escalation */
    uint8_T destructiveResetFunctionalResetEscalation;

    /* # Destructive Reset: Stcu Unrecoverable Fault */
    uint8_T destructiveResetStcuUnrecoverableFault;

    /* # Destructive Reset: Fccu Failure To React */
    uint8_T destructiveResetFccuFailureToReact;

    /* # Destructive Reset: Software Destructive Reset */
    uint8_T destructiveResetSoftwareDestructiveReset;

    /* # Destructive Reset: Power On */
    uint8_T destructiveResetPowerOn;

    /* # Functional Reset: Voltage Out Of Range */
    uint8_T functionalResetVoltageOutOfRange;

    /* # Functional Reset: Temperature Sensor Failure */
    uint8_T functionalResetTempSensorFailure;

    /* # Functional Reset: Jtag */
    uint8_T functionalResetJtag;

    /* # Functional Reset: Fccu Software Reaction */
    uint8_T functionalResetFccuSoftReaction;

    /* # Functional Reset: Fccu Hardware Reaction */
    uint8_T functionalResetFccuHardReaction;

    /* # Functional Reset: Software Functional Reset */
    uint8_T functionalResetSoftwareFunctionalReset;

    /* # Functional Reset: Self Test Completed */
    uint8_T functionalResetSelfTestCompleted;

    /* # Functional Reset: External Reset */
    uint8_T functionalResetExternalReset;
}

NvmLocalResetReasonCounter_B;

#endif                          /* RTW_HEADER_NvmLocalResetReasonCounter_B_h_ */

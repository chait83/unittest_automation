/*
 * ---------------------------------------------------------------------------
 * Copyright (c) 2015 UTC - All rights reserved.
 *
 * Model Name:         ScomFunction
 * Code Generation:    WELLSB - Mon Aug 23 10:54:16 2021
 * Svn:
 * ---------------------------------------------------------------------------
 */

#ifndef RTW_HEADER_NvmGlobalFactoryCfgParameter_B_h_
#define RTW_HEADER_NvmGlobalFactoryCfgParameter_B_h_
#include "rtwtypes.h"

typedef struct
{
    uint8_T UnitNr[8];
    uint16_T NomSpeed1p0mmps;
    uint8_T Rise1p0m;
    uint8_T LS8Position1p0mm;
    uint8_T LS7Position1p0mm;
    uint16_T LS6MICAO1p0mm;
    uint16_T LS6PINS1p0mm;
    uint16_T LS5PINS1p0mm;
    uint16_T LS5MICAO1p0mm;
    uint16_T PitProtection1p0mm;
    uint16_T PitDepth1p0mm;
    uint16_T OverheadProtection1p0mm;
    uint16_T Overhead1p0mm;
    uint8_T DzSiceUCM1p0mm;
    uint8_T NrOfDsSegments;
    uint16_T EIBoardVersion;
    uint16_T PitBoardVersion;
    uint16_T CarBoardVersion;
    uint16_T SabBoardVersion;
    uint16_T DriveBoardVersion;
    uint16_T CanProtocolVersion;
    uint16_T A11p0mmps2;
    uint16_T A21p0mmps2;
    uint16_T A2Down1p0mmps2;
    uint16_T A31p0mmps2;
    uint16_T A3Down1p0mmps2;
    uint16_T DtBrake1p0ms;
    uint16_T DtSFC1p0ms;
    uint16_T StrikeSpeed1p0mmps;
    uint16_T MinBuffer1p0mm;
    uint16_T MinEtsSpeed1p0mmps;
    uint16_T SpareWord[6];
    bool_t PICS;
    bool_t BFS;
    bool_t PLAD;
    bool_t CLAD;
    bool_t MAC;
    bool_t SCS;
    bool_t RearDoors;
    bool_t RearDoorsInPit;
    uint8_T SpareJumper1_8;
}

NvmGlobalFactoryCfgParameter_B;

#endif                        /* RTW_HEADER_NvmGlobalFactoryCfgParameter_B_h_ */

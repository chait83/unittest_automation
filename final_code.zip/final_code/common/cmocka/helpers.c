#include <stdio.h>
#include <ctype.h>

// strcasecmp() implementation (missing from Diab liraries)
int strcasecmp(const char *s1, const char *s2)
{
    int offset,ch;
    unsigned char a,b;

    offset = 0;
    ch = 0;
    while( *(s1+offset) != '\0' )
    {
        /* check for end of s2 */
        if( *(s2+offset)=='\0')
            return( *(s1+offset) );

        a = (unsigned)*(s1+offset);
        b = (unsigned)*(s2+offset);
        ch = toupper(a) - toupper(b);
        if( ch<0 || ch>0 )
            return(ch);
        offset++;
    }

    return(ch);
}

// read_xml_file() to extract the XML data from a file in RAM
extern void read_xml_file(char *fn)
{
    static FILE *fp;
    static int one_char;
    static char file_data[10000];
    static int bytes_read;
    static char file_name[100];
    static int name_length;
    	
    fp = fopen(fn, "r");
    
    for (bytes_read = 0; bytes_read < sizeof(file_data); bytes_read++) 
    { 
        one_char = getc(fp);
        if (one_char == EOF)
            break;
        else 
            file_data[bytes_read] = (char)one_char;
    }
    
    for (name_length = 0; name_length < sizeof(file_name); name_length++)
    {
        file_name[name_length] = fn[name_length];
        if (file_name[name_length] == '.')
        {
            file_name[++name_length] = fn[name_length];
            file_name[++name_length] = fn[name_length];
            file_name[++name_length] = fn[name_length];
            file_name[++name_length] = fn[name_length];
            break;
        }
    }
}

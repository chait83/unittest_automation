#!/bin/bash

# ==============================================================================
# usage: run.sh [ clean | c ]
# ==============================================================================
# This script assumes, that in the directory above (path '..') the
# MakefileCmocka can be found.


FOLDER=$(dirname ${0})/..

cmocka/tools/run_shared.sh "$FOLDER" $*

// =====================================================================================
// Copyright 2019 OTIS GmbH & Co OHG - OTIS Component Engineering Center Berlin
// =====================================================================================
//
//
//  File Name:
//!   @file     SwMon/Processes.h
//!   @brief    Interface description of SwMon/Processes module. Defines the
//!             process IDs and the corresponding timeouts. @n
//!             @attention This module shall only be included inside the component SwMon!
//!
//!             @see @ref Section_SwMonProcesses for descriptive informations
//!                       and the requirement traceability.
//!             @see @ref SwMon/Processes.c for implementation details.
//!
//!             @addtogroup  Group_SwMonProcesses    SwMon/Processes
//!             @section     Section_SwMonProcesses  Details
//!
//! Purpose:@n
//!    Type definitions for processes and flow point.
//!
//! Functionality:@n
//!    To define a Process the following steps have to be done:
//!    - Define a ID for the Process
//!    - Create a entry in the Process List
//!    - Create a flow point list for the Process with minimum one flow point
//!
//!    Notes:
//!    If there is only one flow point the minimum timeout have to be > 0
//!    If there are more than one flow point, flow points do not need to have a
//!    timeout.
//!
//! Realized Requirements:@n
//!    - R-007 List of Process items <ReqId 88192> <ReqId 284197> <ReqId 95837> <ReqId 284199>
//!    - R-040 List of Process IDs
//!    - R-041 List of Flowpoint timeout limitations
//!
//!    Requirements can be found in [1] SW-RD (@ref document_sec)
//!
//! Module information:@n
//!    @code
//!    $Revision: 950 $
//!    $Date: 2017-04-27 10:46:33 +0200 (Do, 27 Apr 2017) $
//!    $URL: https://svn/Otis/PESSRAL/tags/SWMon/V1.0/Coding/SwMon/Processes.h $
//!    $Author: hartm $
//!    @endcode
//!
//  Revision History
//
//  Date           Filename            Comment
//  --------------+-------------------+-----------------------------------------
//  2017-Mar-6 KH | SwMon/Processes.h | Initial SwMon/Processes.h file
//  2017-Apr-20 KH| SwMon/Processes.h | First tested version
//  ============================================================================

//! @details
//!   To prevent the usage of this header in the production binary code
//!   Only be used for the cmocka test.
//!   define CMOCKA to be externally provided, see MakefileCmocka.
#ifndef CMOCKA
#error "Only to be used with CMOCKA library"
#endif

#ifndef SWMONPROCESSES_H
#define SWMONPROCESSES_H

//! @reviewNoAction
//!  * 2019-06-06 -- PP, MHo
//!   * no Action required

// =============================================================================
// Includes

#include <stdint.h>
#include <stdbool.h>

#include "SwMon/SwMonTypes.h"

// =============================================================================
// Macros

// =============================================================================
// Type definitions

// =============================================================================
//! @brief Structure to define flow point list items
// =============================================================================
typedef struct  // R-041
{
  const SwMonTypes_Timestamp_T tOut; //!< Timeout of the flow point.
  SwMonTypes_Timestamp_T timestamp;  //!< Last time stamp of the flowpoint.
} SwMonProcesses_FlpListItem_S;

// =============================================================================
//! @brief List of Processes that must register to the Software Monitor.
//! Each entry has a unique process ID.
//! @n Assumptions:
//!   - Zero is a valid process ID and the first entry
//!   - The last entry of the list is not a valid process ID.
//!
//! @reviewMinor
//!  * 2019-06-06 -- PP, MHo
//!   * explain fix values for ProcessId
// =============================================================================
typedef enum // R-040
{
  SwMonProcesses_PROCESSID_SwMonSProc = 0x1001, //!< Software Monitor Process
  SwMonProcesses_PROCESSID_SafetyProc = 0x1002, //!< Safety Process
  SwMonProcesses_NUMBER_OF_PROCESSES = 2        //!< This must be the last value. It is the
                                                //!< amount of configured Processes.
} SwMonProcesses_ProcessId_E;

// =============================================================================
//! @brief Structure to define Process List items
// =============================================================================

typedef struct // R-007
{
  const SwMonProcesses_ProcessId_E  processID;  //!< Process ID
  const SwMonTypes_Timestamp_T init1stFpTout;   //!< Timeout until the occurrence of the first flow point of the process.
  SwMonProcesses_FlpListItem_S * const flpList; //!< List of flow point data
  const uint32_t noOfFlps;                      //!< Number flow points
  uint32_t idxOfLastUsedFlp;                    //!< Index of the last refreshed flow point
  bool firstRefreshDone;                        //!< True if the function refresh was called for this process for the first time
} SwMonProcesses_ProcListItem_S;

// =============================================================================
// Constants

// =============================================================================
//! @brief  List of all allowed processes
extern SwMonProcesses_ProcListItem_S processList[SwMonProcesses_NUMBER_OF_PROCESSES];

#endif // SWMONPROCESSES_H

// Documentation for doxygen
//
//! @mainpage Software Monitor - Detailed Design Specification
//!
//! @section general_sec General Information
//!
//! @subsection purpose_sec Purpose
//!
//! NewTec is developing a Software Monitor (SwMon) which includes a software watchdog,
//! a program flow monitor and an error logging for the company OTIS GmbH & Co. OHG.
//!
//! This Detailed Design Documentation describes all modules and interfaces in detail.
//! The implemented requirements can be found in [1] and the related architecture is described in [2].
//! Inside the Header-File of each module a reference to the software requirements [1] can be
//! found.
//!
//! The source code is implemented according to the valid coding standard from OTIS
//! (see [3] and [4]).
//!
//! @subsection HowTo_sec How to use
//!
//! To use the Software Monitor (SwMon) the following header files shall be included:
//! - SwMon/SwMonTypes.h
//! - SwMon/Callback.h
//! - SwMon/Monitor.h
//! - SwMon/HaltManager.h
//!
//! @subsection document_sec Related documents
//!
//!  Reference | Document name | Description
//!  --------- | ------------- | -----------
//! [1] SW-RD | 11513_0002_0004_RD-SwRD.doc | Software Requirements Document
//! [2] SW-DD | 11513_0002_0004_DD-SwDD.doc | Software Design Document
//! [3] OTIS-CSTD | 31660_CSTD.docx | OTIS PESSRAL Coding Standard
//! [4] OTIS-OECF | OSP00030_OecfCodingStandardGuideline.doc | OTIS Worldwide Standard for Software Coding
//!
//! @subsection diagram_sec Context diagram
//! @image html Context-Diagram.png "Context-Diagram"
//!
//!


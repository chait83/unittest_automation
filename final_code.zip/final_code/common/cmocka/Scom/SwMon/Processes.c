// =====================================================================================
// Copyright 2019 OTIS GmbH & Co OHG - OTIS Component Engineering Center Berlin
// =====================================================================================
//
//
//  File Name:
//!   @file     SwMon/Processes.c
//!   @brief    Implementation
//!
//! Purpose:@n
//!    Implementation of SwMon/Processes module
//!
//! Functionality:@n
//!    This file is used to define the white list for Processes that are
//!    observed by the Software Monitor.
//!
//!    Notes:
//!    If there is only one flow point the minimum timeout have to be > 0
//!    If there are more than one flow point, flow points do not need to have a
//!    timeout
//!
//! Module information:@n
//!     @code
//!     $Revision: 978 $
//!     $Date: 2017-04-27 15:51:33 +0200 (Do, 27 Apr 2017) $
//!     $URL: https://svn/Otis/PESSRAL/tags/SWMon/V1.0/Coding/SwMon/Processes.c $
//!     $Author: heser $
//!     @endcode
//!
//  Revision History
//
//  Date           Filename            Comment
//  --------------+-------------------+------------------------------------------
//  2017-Mar-6 KH | SwMon/Processes.c | Initial SwMon/Processes.c file
//  2017-Apr-20 KH| SwMon/Processes.c | First tested version
//  2017-Apr-27 KH| SwMon/Processes.c | Final implementation
//  ============================================================================

//! @details
//!   To prevent the usage of this header in the production binary code
//!   Only be used for the cmocka test.
//!   define CMOCKA to be externally provided, see MakefileCmocka.
#ifndef CMOCKA
#error "Only to be used with CMOCKA library"
#endif

// =============================================================================
// Includes
#include "SwMon/Processes.h"

// =============================================================================
//! @brief Macros definition to insert in a safe and comfortable way the
//! process ID and the according flow point list.
#define INIT_PROCESSLIST_ITEM(pID, FirstTimeout, TimeOutList)   \
  { \
    .processID = (pID), \
    .noOfFlps = sizeof(TimeOutList) / sizeof(SwMonProcesses_FlpListItem_S), \
    .flpList = (TimeOutList), \
    .init1stFpTout = (FirstTimeout) \
  }

// =============================================================================
// Constants

//! @brief Safety Monitor flow Point
static SwMonProcesses_FlpListItem_S flpList_SwMonSProc[] = {
      {.tOut = 12U }
};


//! @reviewMajor
//!  * 2019-06-06 -- PP, MHo
//!    * meaning of array-indices is unclear
//!    * possibly expect additional sampling at 15 ms?
//!  * 2019-06-07 - KNU
//!    * Has to be 10 Sciopta ticks
//!    * CECBSAFETY-2432
//!    * Already solved
//!
//! @brief Safety Process flow Points
static SwMonProcesses_FlpListItem_S flpList_SafetyProces_SCON[] = {
      {.tOut =  10U }, // Overall

      {.tOut =  5U },  // Sampling

      {.tOut =  10U }, // Sampling
      {.tOut =  10U }, // Debouncing
      {.tOut =  10U }, // Evaluation
};

//! @details Detailed description of the process list.
SwMonProcesses_ProcListItem_S processList[SwMonProcesses_NUMBER_OF_PROCESSES] =
{
  // <ReqId 87883> requires for every process a maximum of 1700 for
  //               init1stFpTout (which is the second parameter of
  //               INIT_PROCESSLIST_ITEM)
  INIT_PROCESSLIST_ITEM(SwMonProcesses_PROCESSID_SwMonSProc, 200, flpList_SwMonSProc),
  INIT_PROCESSLIST_ITEM(SwMonProcesses_PROCESSID_SafetyProc, 800, flpList_SafetyProces_SCON)
};


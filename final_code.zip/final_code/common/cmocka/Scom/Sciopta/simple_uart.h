/*
**********************************************************************
**  _______  _______ _________ _______  _______ _________ _______   **
** (  ____ \(  ____ \\__   __/(  ___  )(  ____ )\__   __/(  ___  )  **
** | (    \/| (    \/   ) (   | (   ) || (    )|   ) (   | (   ) |  **
** | (_____ | |         | |   | |   | || (____)|   | |   | (___) |  **
** (_____  )| |         | |   | |   | ||  _____)   | |   |  ___  |  **
**       ) || |         | |   | |   | || (         | |   | (   ) |  **
** /\____) || (____/\___) (___| (___) || )         | |   | )   ( |  **
** \_______)(_______/\_______/(_______)|/          )_(   |/     \|  **
**                                                                  **
**                   (c) 2002 SCIOPTA Systems GmbH                  **
**                                                                  **
**********************************************************************
** ID: S06258BS3                                                    **
** +Revision: 1.5 +                                                 **
** +Date: 2014/06/06 11:52:29 +                                     **
** Simple UART routines                                             **
**********************************************************************
*/

//! @details
//!   To prevent the usage of this header in the production binary code
//!   Only be used for the cmocka test.
//!   define CMOCKA to be externally provided, see MakefileCmocka.
#ifndef CMOCKA
#error "Only to be used with CMOCKA library"
#endif

#ifndef _SIMPLE_UART_H_
#define _SIMPLE_UART_H_

void uart_init(unsigned int uart, unsigned int baudrate);
void uart_putchar(unsigned int uart,int ch);
int uart_getchar(unsigned int uart);

#endif

/*SOC
**********************************************************************
**  _______  _______ _________ _______  _______ _________ _______   **
** (  ____ \(  ____ \\__   __/(  ___  )(  ____ )\__   __/(  ___  )  **
** | (    \/| (    \/   ) (   | (   ) || (    )|   ) (   | (   ) |  **
** | (_____ | |         | |   | |   | || (____)|   | |   | (___) |  **
** (_____  )| |         | |   | |   | ||  _____)   | |   |  ___  |  **
**       ) || |         | |   | |   | || (         | |   | (   ) |  **
** /\____) || (____/\___) (___| (___) || )         | |   | )   ( |  **
** \_______)(_______/\_______/(_______)|/          )_(   |/     \|  **
**                                                                  **
**                  (c) 2011 SCIOPTA Systems GmbH                   **
**                                                                  **
**********************************************************************
** ID: S16040FB02                                                   **
** +Revision: 1.3.2.4 +                                                 **
** +Date: 2017/10/20 06:40:35 +                                     **
** Function and message definitions for I/O process                 **
**********************************************************************
EOC*/

//! @details
//!   To prevent the usage of this header in the production binary code
//!   Only be used for the cmocka test.
//!   define CMOCKA to be externally provided, see MakefileCmocka.
#ifndef CMOCKA
#error "Only to be used with CMOCKA library"
#endif

#ifndef _IO_H_
#define _IO_H_

#ifndef CNF_BSP_IO_BASE
#define CNF_BSP_IO_BASE 0x10900000
#endif

#define IO_MAX_PAD (153U)
#define IO_MAX_PORT (IO_MAX_PAD / 16)

/*lint -e768 global struct member not referenced (e.g. id, dummy1 etc.)*/
/*lint -e756 global typedef 'io_digAllPortsInGet_t' not referenced ->
                            used by the user*/

/*
****************************************
** Get input state
**
** no - pad (0..107, some are not valid, check manual)
*/
#define IO_DIGPADINGET_MSG (CNF_BSP_IO_BASE + 1)
typedef struct io_digPadInGet_s {
  sc_msgid_t id;
  uint32_t no;
  uint32_t dummy1;
  int32_t dumm2;
} io_digPadInGet_t;

/*
****************************************
** Input state:
**
** no    - requested pad
** state - 0/1
** error - -EIO  - pin is no I/O
*/
#define IO_DIGPADINGET_REPLY_MSG (CNF_BSP_IO_BASE + 2)
typedef struct io_digpadInGetReply_s {
  sc_msgid_t id;
  uint32_t no;
  uint32_t state;
  int32_t error;
} io_digpadInGetReply_t;

/*
****************************************
** Set pad to a state
**
** no    - pad (0..153, some are not valid, check manual)
** state - 0 or != 0
**
*/
#define IO_DIGPADOUTSET_MSG (CNF_BSP_IO_BASE + 3)
typedef struct io_digPadOutSet_s {
  sc_msgid_t id;
  uint32_t no;
  uint32_t state;
  int32_t dumm2;
} io_digPadOutSet_t;

/*
****************************************
** Reply of set pad to a state
**
** no    - pad (0..107, some are not valid, check manual)
** state - actual state
** error - -EIO - pin is no I/O
*/

#define IO_DIGPADOUTSET_REPLY_MSG (CNF_BSP_IO_BASE + 4)
typedef io_digpadInGetReply_t io_digPadOutSetReply_t;

/*
****************************************
** Get state of a output pad
**
** no    - pad (0..153, some are not valid, check manual)
**
*/
#define IO_DIGPADOUTGET_MSG (CNF_BSP_IO_BASE + 5)
typedef io_digPadInGet_t io_digPadOutGet_t;

/*
****************************************
** Reply of a get state request
**
** no    - pad (0..153, some are not valid, check manual)
** state - state
** error - -EIO - pin is no I/O
**
*/
#define IO_DIGPADOUTGET_REPLY_MSG (CNF_BSP_IO_BASE + 6)
typedef io_digpadInGetReply_t io_digPadOutGetReply_t;

/*
****************************************
** Get state of a output-pad the specified port
**
** port_no    - port number (0..9)
** mask       - mask of the to read
*/
#define IO_DIGPORTOUTGET_MSG (CNF_BSP_IO_BASE + 7)
typedef struct io_digPortOutGet_s {
  sc_msgid_t id;
  uint32_t port_no;
  uint16_t mask;
  int32_t dummy;
} io_digPortOutGet_t;

/*
****************************************
** Reply of the Get state of a output-pad the specified port
**
** port_no    - port number (0..9)
** state      - states of the read pads
** error      - -EIO - pin is no I/O
*/
#define IO_DIGPORTOUTGET_REPLY_MSG (CNF_BSP_IO_BASE + 8)
typedef struct io_digPortOutGetReply_s {
  sc_msgid_t id;
  uint32_t port_no;
  uint16_t state;
  int32_t error;
} io_digPortOutGetReply_t;

/*
****************************************
** Set state of a output-pad the specified port
**
** port_no    - port number (0..9)
** mask       - mask of the pads to set
** state      - state to set
*/
#define IO_DIGPORTOUTSET_MSG (CNF_BSP_IO_BASE + 9)
typedef struct io_digPortOutSet_s {
  sc_msgid_t id;
  uint32_t port_no;
  uint16_t mask;
  uint16_t state;
  int32_t dummy;
} io_digPortOutSet_t;

/*
****************************************
** Reply of the set state of a output-pad the specified port
**
** port_no    - port number (0..9)
** mask       - mask of the pads to set
** state      - state to set
** error      - -EIO - pin is no I/O
*/
#define IO_DIGPORTOUTSET_REPLY_MSG (CNF_BSP_IO_BASE + 10)
typedef struct io_digPortOutSetReply_s {
  sc_msgid_t id;
  uint32_t port_no;
  uint16_t mask;
  uint16_t state;
  int32_t error;
} io_digPortOutSetReply_t;

/*
****************************************
** Get state of an input-pad the specified port
**
** port_no    - port number (0(A)..9(J))
** mask       - mask of the pads to read
*/
#define IO_DIGPORTINGET_MSG (CNF_BSP_IO_BASE + 11)
typedef io_digPortOutGet_t io_digPortInGet_t;

/*
****************************************
** reply of the get state of an input-pad the specified port
**
** port_no    - port number (0(A)..9(J))
** state      - state of the read pads
*/
#define IO_DIGPORTINGET_REPLY_MSG (CNF_BSP_IO_BASE + 12)
typedef io_digPortOutGetReply_t io_digPortInGetReply_t;

/*
****************************************
** Get state of all Output pads
**
*/
#define IO_DIGALLPORTSOUTGET_MSG (CNF_BSP_IO_BASE + 13)
typedef struct io_digAllPortsOutGet_s {
  sc_msgid_t id;
  uint16_t state[IO_MAX_PORT + 1];
} io_digAllPortsOutGet_t;

/*
****************************************
** Reply of the Get state of all Output pads
** state [0..IO_MAX_PORT] - states of the pads
**
*/
#define IO_DIGALLPORTSOUTGET_REPLY_MSG (CNF_BSP_IO_BASE + 14)
typedef io_digAllPortsOutGet_t io_digAllPortsOutGetReply_t;

/*
****************************************
** Get state of all Input pads
**
*/
#define IO_DIGALLPORTSINGET_MSG (CNF_BSP_IO_BASE + 15)
typedef io_digAllPortsOutGet_t io_digAllPortsInGet_t;

/*
****************************************
** Reply of the get state of all Input pads
**
*/
#define IO_DIGALLPORTSINGET_REPLY_MSG (CNF_BSP_IO_BASE + 16)
typedef io_digAllPortsOutGet_t io_digAllPortsInGetReply_t;

/*
****************************************
** Set state of all Output pads
** mask[0..IO_MAX_PORT]  - points to pads in port to set new state
** stet[0..IO_MAX_PORT]  - new states
*/
#define IO_DIGALLPORTSOUTSET_MSG (CNF_BSP_IO_BASE + 17)
typedef struct io_digAllPortsOutSet_s {
  sc_msgid_t id;
  uint16_t mask[IO_MAX_PORT + 1];
  uint16_t state[IO_MAX_PORT + 1];
  int32_t error;
} io_digAllPortsOutSet_t;

/*
****************************************
** Reply of the set state of all Output pads
** stat[0..IO_MAX_PORT]  - current states of the pads
** error                 - -EIO - pin is no I/O
*/
#define IO_DIGALLPORTSOUTSET_REPLY_MSG (CNF_BSP_IO_BASE + 18)
typedef io_digAllPortsOutSet_t io_digAllPortsOutSetReply_t;

/*
****************************************************************************
** Function interface
****************************************************************************
*/

/*
****************************************
** io_digPadOutSet
**
** IN:
** tmo   - time in ticks to wait for a reply.
** no    - Pad number to set
** state - new state of the pad (0 | 1)
**
** OUT:
** 0 / 1  - new state
** -EIO   - state could not be set
** -ETIME - timeout expired
*/
int io_digPadOutSet(sc_ticks_t tmo, int no, int state);

/*
****************************************
** io_digPadOutGet
**
** IN:
** tmo   - time in ticks to wait for a reply.
** no    - Pad number to get
**
** OUT:
** 0 / 1  - state
** -EIO   - state could not be read (not an /O pin)
** -ETIME - timeout expired
*/
int io_digPadOutGet(sc_ticks_t tmo, int no);

/*
****************************************
** io_digPadInGet
**
** IN:
** tmo   - time in ticks to wait for a reply.
** no    - Pad number to get
**
** OUT:
** 0 / 1  - state
** -EIO   - state could not be read (not an /I pin)
** -ETIME - timeout expired
*/
int io_digPadInGet(sc_ticks_t tmo, int no);

/*
****************************************
** io_digPortOutSet
**
** IN:
** tmo     - time in ticks to wait for a reply.
** port_no - Port number to set (0-9)
** state   - new state of the pads (0 - 0xffff)
** mask    - mask of the pads to set (0 - 0xffff)
**
** OUT:
** 0 .. 0xffff  - state
** -EIO   - state could not be read
** -ETIME - timeout expired
*/
int io_digPortOutSet(sc_ticks_t tmo, int port_no, int state, int mask);

/*
****************************************
** io_digPortOutGet
**
** IN:
** tmo     - time in ticks to wait for a reply.
** port_no - Port number to read (0-9)
** mask    - mask of the pads to read (0 - 0xffff)
**
** OUT:
** 0 .. 0xffff  - state
** -EIO   - state could not be read
** -ETIME - timeout expired
*/
int io_digPortOutGet(sc_ticks_t tmo, int port_no, int mask);

/*
****************************************
** io_digPortInGet
**
** IN:
** tmo     - time in ticks to wait for a reply.
** port_no - Port number to read (0-9)
** mask    - mask of the pads to read (0 - 0xffff)
**
** OUT:
** 0 .. 0xffff  - state
** -EIO   - state could not be read
** -ETIME - timeout expired
*/
int io_digPortInGet(sc_ticks_t tmo, int port_no, int mask);

/*
****************************************
** io_digPortInGet
**
** IN:
** tmo     - time in ticks to wait for a reply.
** state   - table of states for all ports
** mask    - mask of the pads to set for all ports
**
** OUT:
** 0  - No error
** -EIO   - state could not be read
** -ETIME - timeout expired
*/
int io_digAllPortsOutSet(sc_ticks_t tmo, uint16_t *state, uint16_t *mask);

/*
****************************************
** io_digAllPortsOutGet
**
** IN:
** tmo     - time in ticks to wait for a reply.
** state   - buffer to read all states of all ports
**
** OUT:
** 0  - No error
** -EIO   - state could not be read
** -ETIME - timeout expired
*/
int io_digAllPortsOutGet(sc_ticks_t tmo, uint16_t *state);

/*
****************************************
** io_digAllPortsInGet
**
** IN:
** tmo     - time in ticks to wait for a reply.
** state   - buffer to read all states of all ports
**
** OUT:
** 0  - No error
** -EIO   - state could not be read
** -ETIME - timeout expired
*/
int io_digAllPortsInGet(sc_ticks_t tmo, uint16_t *state);
#endif

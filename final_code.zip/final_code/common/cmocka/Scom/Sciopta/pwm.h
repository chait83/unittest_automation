/*
**********************************************************************
**  _______  _______ _________ _______  _______ _________ _______   **
** (  ____ \(  ____ \\__   __/(  ___  )(  ____ )\__   __/(  ___  )  **
** | (    \/| (    \/   ) (   | (   ) || (    )|   ) (   | (   ) |  **
** | (_____ | |         | |   | |   | || (____)|   | |   | (___) |  **
** (_____  )| |         | |   | |   | ||  _____)   | |   |  ___  |  **
**       ) || |         | |   | |   | || (         | |   | (   ) |  **
** /\____) || (____/\___) (___| (___) || )         | |   | )   ( |  **
** \_______)(_______/\_______/(_______)|/          )_(   |/     \|  **
**                                                                  **
**                 (c) 2014 Sciopta Systems  AG/ Schweiz            **
**                                                                  **
**********************************************************************
** ID: 14269FB2                                                     **
** +Revision: 1.1.2.1 +                                                 **
** +Date: 2016/10/11 09:30:06 +                                     **
** PWM driver                                                       **
**********************************************************************
*/
#ifndef CMOCKA
#error "Only to be used with CMOCKA library"
#endif

#ifndef _DRV_PWM_H_
#define _DRV_PWM_H_
#include <config.h>

#ifndef CNF_BSP_PWM_BASE
#define CNF_BSP_PWM_BASE (CNF_BSP_MSG_BASE + 0x10000)
#endif

/* PWM Driver Error Codes */
#define PWM_NO_ERROR     (0)
#define PWM_LDOK_HIGH    (CNF_BSP_PWM_BASE + 0x1000 + 1)
#define PWM_ILLEGAL_UNIT (CNF_BSP_PWM_BASE + 0x1000 + 2)
/**************************/

/*Submodule register read structure*/
typedef struct pwm_subm_reg_rd_s
{
    sc_msgid_t id;
    uint16_t regval; /*Content of register*/
    uint32_t subm;   /*0-submodule 0, 1-submodule1, .. 3-submodule3*/
    int error;       /*Error code*/
} pwm_subm_reg_rd_t;

/*Configuration register read structure*/
typedef struct pwm_config_reg_rd_s
{
    sc_msgid_t id;
    uint16_t regval; /*Content of register*/
} pwm_config_reg_rd_t;

/*CNT register read message id*/
#define MSG_PWM_CNT_REG_RD       (CNF_BSP_PWM_BASE + 2)
#define MSG_PWM_CNT_REG_RD_REPLY (MSG_PWM_CNT_REG_RD + 1)

/*Duty Cycle registers write message id*/
#define MSG_PWM_DC_REGS_WR (CNF_BSP_PWM_BASE + 4)
#define MSG_PWM_DC_REGS_WR_REPLY (MSG_PWM_DC_REGS_WR + 1)

/*Duty Cycle registers write structure*/
typedef struct pwm_dc_regs_wr_s
{
    sc_msgid_t id;
    uint32_t subm;       /*0-submodule 0, 1-submodule1, .. 3-submodule3*/
    int error;           /*Error code*/
    union {
        struct {
            int16_t init;
            int16_t prsc:3; /*CTRL1[prcs]*/
            int16_t val0;
            int16_t val1;
            int16_t val2;
            int16_t val3;
            int16_t val4;
            int16_t val5;
        };
        int16_t regs[8];
    };
} pwm_dc_regs_wr_t;

/*Duty Cycle registers read message id*/
#define MSG_PWM_DC_REGS_RD (CNF_BSP_PWM_BASE + 6)
#define MSG_PWM_DC_REGS_RD_REPLY (MSG_PWM_DC_REGS_RD + 1)

/*Duty Cycle registers read structure*/
typedef struct pwm_dc_regs_rd_s
{
    sc_msgid_t id;
    uint32_t subm; /*0-submodule 0, 1-submodule1, .. 3-submodule3*/
    int error;     /*Error code*/
    union {
        struct {
            int16_t init;
            int16_t prsc;
            int16_t val0;
            int16_t val1;
            int16_t val2;
            int16_t val3;
            int16_t val4;
            int16_t val5;
        };
        int16_t regs[8];
    };
} pwm_dc_regs_rd_t;


/*Duty Cycle register write message id*/
#define MSG_PWM_DC_REG_WR (CNF_BSP_PWM_BASE + 8)
#define MSG_PWM_DC_REG_WR_REPLY (MSG_PWM_DC_REG_WR + 1)

/*Duty Cycle register write structure*/
typedef struct pwm_dc_reg_wr_s
{
    sc_msgid_t id;
    uint32_t subm;       /*0-submodule 0, 1-submodule1, .. 3-submodule3*/
    int error;           /*Error code*/
    uint32_t regidx;     /*0-init, 1-ctr1[prsc], 2-val0, .. 7-val5 */
    int16_t regval;      /*Data to write*/
} pwm_dc_reg_wr_t;

/*Duty Cycle register read message id*/
#define MSG_PWM_DC_REG_RD (CNF_BSP_PWM_BASE + 10)
#define MSG_PWM_DC_REG_RD_REPLY (MSG_PWM_DC_REG_RD + 1)

/*Duty Cycle register read structure*/
typedef struct pwm_dc_reg_rd_s
{
    sc_msgid_t id;
    uint32_t subm;   /*0-submodule 0, 1-submodule1, .. 3-submodule3*/
    int error;       /*Error code*/
    uint32_t regidx; /*0-init, 1-ctr1[prsc], 2-val0, .. 7-val5 */
    int16_t regval;  /*Content of the register*/
} pwm_dc_reg_rd_t;

/*CTRL2 register write message id*/
#define MSG_PWM_CTRL2_REG_WR (CNF_BSP_PWM_BASE + 12)
#define MSG_PWM_CTRL2_REG_WR_REPLY (MSG_PWM_CTRL2_REG_WR + 1)

/*CTRL2 register write structure*/
typedef struct pwm_ctrl2_reg_wr_s
{
    sc_msgid_t id;
    uint32_t subm; /*0-submodule 0, 1-submodule1, .. 3-submodule3*/
    int error;     /*Error code*/
    union {
        struct {   /*Data to write: Bits version*/
            int:14;
            int clk_sel:2;
        };
        uint16_t regval; /*Data to write*/
    };
} pwm_ctrl2_reg_wr_t;

/*CTRL2 register read message id*/
#define MSG_PWM_CTRL2_REG_RD (CNF_BSP_PWM_BASE + 14)
#define MSG_PWM_CTRL2_REG_RD_REPLY (MSG_PWM_CTRL2_REG_RD + 1)

/*CTRL1 register write message id*/
#define MSG_PWM_CTRL1_REG_WR (CNF_BSP_PWM_BASE + 16)
#define MSG_PWM_CTRL1_REG_WR_REPLY (MSG_PWM_CTRL1_REG_WR + 1)

/*CTRL1 register write structure*/
typedef struct pwm_ctrl1_reg_wr_s
{
    sc_msgid_t id;
    uint32_t subm; /*0-submodule 0, 1-submodule1, .. 3-submodule3*/
    int error;     /*Error code*/
    union {
        struct { /*Data to write : Bits version*/
            int ldfq:4;
            int half:1;
            int full:1;
            int:7;
            int ldmod:1;
            int:2;
        };
        uint16_t regval; /*Data to write*/
    };
} pwm_ctrl1_reg_wr_t;

/*CTRL1 register read message id*/
#define MSG_PWM_CTRL1_REG_RD (CNF_BSP_PWM_BASE + 18)
#define MSG_PWM_CTRL1_REG_RD_REPLY (MSG_PWM_CTRL1_REG_RD + 1)

/*OCTRL register write message id*/
#define MSG_PWM_OCTRL_REG_WR (CNF_BSP_PWM_BASE + 20)
#define MSG_PWM_OCTRL_REG_WR_REPLY (MSG_PWM_OCTRL_REG_WR + 1)

/*OCTRL register write structure*/
typedef struct pwm_octrl_reg_wr_s
{
    sc_msgid_t id;
    uint32_t subm; /*0-submodule 0, 1-submodule1, .. 3-submodule3*/
    int error;     /*Error code*/
    union {
        struct {  /*Data to write : Bits version*/
            int:5;
            int pola:1;
            int polb:1;
            int polx:1;
            int:8;
        };
        uint16_t regval; /*Data to write*/
    };
} pwm_octrl_reg_wr_t;

/*OCTRL register read message id*/
#define MSG_PWM_OCTRL_REG_RD (CNF_BSP_PWM_BASE + 22)
#define MSG_PWM_OCTRL_REG_RD_REPLY (MSG_PWM_OCTRL_REG_RD + 1)

/*STS register read message id*/
#define MSG_PWM_STS_REG_RD (CNF_BSP_PWM_BASE + 24)
#define MSG_PWM_STS_REG_RD_REPLY (MSG_PWM_STS_REG_RD + 1)

/*STS register write message id*/
#define MSG_PWM_STS_REG_WR (CNF_BSP_PWM_BASE + 26)
#define MSG_PWM_STS_REG_WR_REPLY (MSG_PWM_STS_REG_WR + 1)

/*STS register write structure*/
typedef struct {
    sc_msgid_t id;
    uint32_t subm; /*0-submodule 0, 1-submodule1, .. 3-submodule3*/
    int error;     /*Error code*/
    union {
        struct {   /*Data to write: Bits version*/
            int:2;
            int ref:1;
            int rf:1;
            int:12;
        };
        uint16_t regval; /*Data to write*/
    };
} pwm_sts_reg_wr_t;

/*OUTEN register write message id*/
#define MSG_PWM_OUTEN_REG_WR (CNF_BSP_PWM_BASE + 28)
#define MSG_PWM_OUTEN_REG_WR_REPLY (MSG_PWM_OUTEN_REG_WR + 1)

/*OUTEN register write structure*/
typedef struct pwm_outen_reg_wr_s
{
    sc_msgid_t id;
    union {
        struct {         /*Data to write : Bits version*/
            int:4;
            int pwma_en:4;
            int pwmb_en:4;
            int pwmx_en:4;
        };
        uint16_t regval; /*Data to write*/
    };
} pwm_outen_reg_wr_t;

/*OUTEN register read message id*/
#define MSG_PWM_OUTEN_REG_RD (CNF_BSP_PWM_BASE + 30)
#define MSG_PWM_OUTEN_REG_RD_REPLY (MSG_PWM_OUTEN_REG_RD + 1)

/*MASK register write message id*/
#define MSG_PWM_MASK_REG_WR (CNF_BSP_PWM_BASE + 32)
#define MSG_PWM_MASK_REG_WR_REPLY (MSG_PWM_MASK_REG_WR + 1)

/*MASK register write structure*/
typedef struct pwm_mask_reg_wr_s
{
    sc_msgid_t id;
    union {
        struct {         /*Data to write: Bits version*/
            int:4;
            int maska:4;
            int maskb:4;
            int maskx:4;
        };
        uint16_t regval; /*Data to write*/
    };
} pwm_mask_reg_wr_t;

/*MASK register read message id*/
#define MSG_PWM_MASK_REG_RD (CNF_BSP_PWM_BASE + 34)
#define MSG_PWM_MASK_REG_RD_REPLY (MSG_PWM_MASK_REG_RD + 1)

/*MCTRL register write message id*/
#define MSG_PWM_MCTRL_REG_WR (CNF_BSP_PWM_BASE + 36)
#define MSG_PWM_MCTRL_REG_WR_REPLY (MSG_PWM_MCTRL_REG_WR + 1)

/*MCTRL register write structure*/
typedef struct pwm_mctrl_reg_wr_s
{
    sc_msgid_t id;
    union {
        struct {         /*Data to write: bits version*/
            uint16_t :4;
            uint16_t run  :4;
            uint16_t cldok:4;
            uint16_t :4;
        };
        uint16_t regval; /*Data to write*/
    };
} pwm_mctrl_reg_wr_t;

/*MCTRL register read message id*/
#define MSG_PWM_MCTRL_REG_RD (CNF_BSP_PWM_BASE + 38)
#define MSG_PWM_MCTRL_REG_RD_REPLY (MSG_PWM_MCTRL_REG_RD + 1)

/*Structure to pass the inti values to pwmInit() function*/
typedef struct{
    int clk_sel;         /*Clock Source Select*/
    int load_fq;         /*Load Frequency*/
    int cycle_reload;    /*Cycle Reload:
                         0 - HALF = 0 FULL = 0
                         1 - HALF = 0 FULL = 1
                         2 - HALF = 1 FULL = 0
                         3 - HALF = 1 FULL = 1
                         */
    int loadImmediately; /*Load Immediately flag*/
} pwm_init_t;

/*Structure to pass the Duty Cycle values to pwmSetDutyCycle() function*/
typedef struct{
    int16_t init; /*Data to write to the register INIT*/
    int16_t prsc; /*Data to write to the register CTRL1.PRSC*/
    int16_t val0; /*Data to write to the register VAL0*/
    int16_t val1; /*Data to write to the register VAL1*/
    int16_t val2; /*Data to write to the register VAL2*/
    int16_t val3; /*Data to write to the register VAL3*/
    int16_t val4; /*Data to write to the register VAL4*/
    int16_t val5; /*Data to write to the register VAL5*/
} dutyCycle_t;

int pwmInit(uint32_t unit, uint32_t subm, pwm_init_t *pwm_init);
int pwmEnableChannel(uint32_t unit, int ch_a, int ch_b, int ch_x);
int pwmDisableChannel(uint32_t unit, int ch_a, int ch_b, int ch_x);
int pwmSetDutyCycle(uint32_t unit, uint32_t subm, dutyCycle_t *dc);
int pwmStart(uint32_t unit, int subm_mask);
int pwmStop(uint32_t unit, int subm_mask);


#endif /*_DRV_PWM_H_*/

/*SOC
**********************************************************************
**  _______  _______ _________ _______  _______ _________ _______   **
** (  ____ \(  ____ \\__   __/(  ___  )(  ____ )\__   __/(  ___  )  **
** | (    \/| (    \/   ) (   | (   ) || (    )|   ) (   | (   ) |  **
** | (_____ | |         | |   | |   | || (____)|   | |   | (___) |  **
** (_____  )| |         | |   | |   | ||  _____)   | |   |  ___  |  **
**       ) || |         | |   | |   | || (         | |   | (   ) |  **
** /\____) || (____/\___) (___| (___) || )         | |   | )   ( |  **
** \_______)(_______/\_______/(_______)|/          )_(   |/     \|  **
**                                                                  **
**                     (c) 2015 SCIOPTA Systems GmbH                **
**                                                                  **
**********************************************************************
** ID: S15334BS1                                                    **
** +Revision: 1.2 +                                                 **
** +Date: 2015/11/30 12:19:10 +                                     **
** MPC5744P interrupt vectors                                       **
**********************************************************************
EOC*/

//! @details
//!   To prevent the usage of this header in the production binary code
//!   Only be used for the cmocka test.
//!   define CMOCKA to be externally provided, see MakefileCmocka.
#ifndef CMOCKA
#error "Only to be used with CMOCKA library"
#endif

#ifndef _MPC5744P_INTC_H_
#define _MPC5744P_INTC_H_

#define INTC_SSFn(n)	(0+(n))
#define INTC_PWTDG_TMO  (32)
#define INTC_STM0_0     (36)
#define INTC_STM0_1     (37)
#define INTC_STM0_2     (38)
#define INTC_STM0_3     (39)
#define INTC_STM0_n     (36+(n))
#define INTC_EDMA_ERR   (52)
#define INTC_EDMA_CHN(n) (53+(n))
#define INTC_FLASHC     (185)
#define INTC_ENET0_TMR  (216)
#define INTC_ENET0_TX   (217)
#define INTC_ENET0_RX   (218)
#define INTC_ENET0_ERR  (219)
#define INTC_PIT0_0     (226)
#define INTC_PIT0_1     (227)
#define INTC_PIT0_2     (228)
#define INTC_PIT0_3     (229)
#define INTC_PIT0(n)    (226+(n))
#define INTC_XOSC       (242)
#define INTC_EXT0       (243)
#define INTC_EXT1       (244)
#define INTC_EXT2       (245)
#define INTC_EXT3       (246)
#define INTC_EXTn(n)    (243+(n))

#define INTC_ME_SAFE    (251)
#define INTC_ME_TRANS   (252)
#define INTC_ME_INVMODE (253)
#define INTC_ME_INVCFG  (254)
#define INTC_ME_RESET   (255)

#define INTC_DSPI0_TFUF_RFOF (259)
#define INTC_DSPI0_EOQF (260)
#define INTC_DSPI0_TFFF (261)
#define INTC_DSPI0_TCF  (262)
#define INTC_DSPI0_RFDF (263)

#define INTC_DSPI1_TFUF_RFOF (268)
#define INTC_DSPI1_EOQF (269)
#define INTC_DSPI1_TFFF (270)
#define INTC_DSPI1_TCF  (271)
#define INTC_DSPI1_RFDF (272)

#define INTC_DSPI2_TFUF_RFOF (277)
#define INTC_DSPI2_EOQF (278)
#define INTC_DSPI2_TFFF (279)
#define INTC_DSPI2_TCF  (280)
#define INTC_DSPI2_RFDF (281)

#define INTC_DSPI3_TFUF_RFOF (286)
#define INTC_DSPI3_EOQF (287)
#define INTC_DSPI3_TFFF (288)
#define INTC_DSPI3_TCF  (289)
#define INTC_DSPI3_RFDF (290)

#define INTC_DSPIn_TFUF_RFOF(n) (268+(n)*9)
#define INTC_DSPIn_EOQF(n) (269+(n)*9)
#define INTC_DSPIn_TFFF(n) (270+(n)*9)
#define INTC_DSPIn_TCF(n)  (271+(n)*9)
#define INTC_DSPIn_RFDF(n) (272+(n)*9)

#define INTC_LINFLEX0_RX  (376)
#define INTC_LINFLEX0_TX  (377)
#define INTC_LINFLEX0_ERR (378)

#define INTC_LINFLEX1_RX  (380)
#define INTC_LINFLEX1_TX  (381)
#define INTC_LINFLEX1_ERR (382)

#define INTC_LINFLEXn_RX(n)  (376+(n)*4)
#define INTC_LINFLEXn_TX(n)  (377+(n)*4)
#define INTC_LINFLEXn_ERR(n) (378+(n)*4)

#define INTC_FR0_LRNEIF_DRNEIF (453)
#define INTC_FR0_LRCEIF_DRCEIF (454)
#define INTC_FR0_FNEAIF        (455)
#define INTC_FR0_FNEBIF        (456)
#define INTC_FR0_WUPIF         (457)
#define INTC_FR0_PRIF          (458)
#define INTC_FR0_CHIF          (459)
#define INTC_FR0_TBIF          (460)
#define INTC_FR0_RBIF          (461)
#define INTC_FR0_MIF           (462)

#define INTC_PMU               (477)
#define INTC_PMU_TEMP          (478)

#define INTC_FCCU_ALARM        (488)
#define INTC_CFG_TMO           (489)

#define INTC_ADC0_EOC          (496)
#define INTC_ADC0_ER           (497)
#define INTC_ADC0_WD           (498)
#define INTC_ADC1_EOC          (500)
#define INTC_ADC1_ER           (501)
#define INTC_ADC1_WD           (502)
#define INTC_ADC2_EOC          (504)
#define INTC_ADC2_ER           (505)
#define INTC_ADC2_WD           (506)
#define INTC_ADC3_EOC          (508)
#define INTC_ADC3_ER           (509)
#define INTC_ADC3_WD           (510)
#define INTC_ADCn_EOC(n)       (496+(n)*4)
#define INTC_ADCn_ER(n)        (497+(n)*4)
#define INTC_ADCn_WD(n)        (498+(n)*4)

#define INTC_CAN0_ERR          (520)
#define INTC_CAN0_BOFF         (521)
#define INTC_CAN0_BUF_00_03    (522)
#define INTC_CAN0_BUF_04_07    (523)
#define INTC_CAN0_BUF_08_11    (524)
#define INTC_CAN0_BUF_12_15    (525)
#define INTC_CAN0_BUF_16_31    (526)
#define INTC_CAN0_BUF_32_39    (527)
#define INTC_CAN0_BUF_40_47    (528)
#define INTC_CAN0_BUF_48_55    (529)
#define INTC_CAN0_BUF_56_63    (530)

#define INTC_CAN1_ERR          (533)
#define INTC_CAN1_BOFF         (534)
#define INTC_CAN1_BUF_00_03    (535)
#define INTC_CAN1_BUF_04_07    (536)
#define INTC_CAN1_BUF_08_11    (537)
#define INTC_CAN1_BUF_12_15    (538)
#define INTC_CAN1_BUF_16_31    (539)
#define INTC_CAN1_BUF_32_39    (540)
#define INTC_CAN1_BUF_40_47    (541)
#define INTC_CAN1_BUF_48_55    (542)
#define INTC_CAN1_BUF_56_63    (543)

#define INTC_CAN2_ERR          (546)
#define INTC_CAN2_BOFF         (547)
#define INTC_CAN2_BUF_00_03    (548)
#define INTC_CAN2_BUF_04_07    (549)
#define INTC_CAN2_BUF_08_11    (550)
#define INTC_CAN2_BUF_12_15    (551)
#define INTC_CAN2_BUF_16_31    (552)
#define INTC_CAN2_BUF_32_39    (553)
#define INTC_CAN2_BUF_40_47    (554)
#define INTC_CAN2_BUF_48_55    (555)
#define INTC_CAN2_BUF_56_63    (556)

#define INTC_CANn_ERR(n)       (520+(n)*13)
#define INTC_CANn_BOFF(n)      (521+(n)*13)
#define INTC_CANn_BUF_00_03(n) (522+(n)*13)
#define INTC_CANn_BUF_04_07(n) (523+(n)*13)
#define INTC_CANn_BUF_08_11(n) (524+(n)*13)
#define INTC_CANn_BUF_12_15(n) (525+(n)*13)
#define INTC_CANn_BUF_16_31(n) (526+(n)*13)
#define INTC_CANn_BUF_32_39(n) (527+(n)*13)
#define INTC_CANn_BUF_40_47(n) (528+(n)*13)
#define INTC_CANn_BUF_48_55(n) (529+(n)*13)
#define INTC_CANn_BUF_56_63(n) (530+(n)*13)

#define INTC_SENT0_FRX0        (570)
#define INTC_SENT0_SRX0        (571)
#define INTC_SENT0_RXERR0      (572)
#define INTC_SENT0_FRX1        (573)
#define INTC_SENT0_SRX1        (574)
#define INTC_SENT0_RXERR1      (575)

#define INTC_SENT1_FRX0        (582)
#define INTC_SENT1_SRX0        (583)
#define INTC_SENT1_RXERR0      (584)
#define INTC_SENT1_FRX1        (585)
#define INTC_SENT1_SRX1        (586)
#define INTC_SENT1_RXERR1      (587)

#define INTC_SENTn_FRX0(n)     (570(n)*12)
#define INTC_SENTn_SRX0(n)     (571(n)*12)
#define INTC_SENTn_RXERR0(n)   (572(n)*12)
#define INTC_SENTn_FRX1(n)     (573(n)*12)
#define INTC_SENTn_SRX1(n)     (574(n)*12)
#define INTC_SENTn_RXERR1(n)   (575(n)*12)

#define INTC_SIPI_RX1          (594)
#define INTC_SIPI_RX2          (595)
#define INTC_SIPI_RX3          (596)
#define INTC_SIPI_RX4          (597)
#define INTC_SIPI_ERROR1       (602)
#define INTC_SIPI_ERROR2       (603)
#define INTC_SIPI_TRIGGER      (604)

#define INTC_LFAST0_TX         (605)
#define INTC_LFAST0_TXEX       (606)
#define INTC_LFAST0_RX         (607)
#define INTC_LFAST0_RXEX       (608)
#define INTC_LFAST0_RXICLC     (609)

#define INTC_ETMR0_TC0IR       (611)
#define INTC_ETMR0_TC1IR       (612)
#define INTC_ETMR0_TC2IR       (613)
#define INTC_ETMR0_TC3IR       (614)
#define INTC_ETMR0_TC4IR       (615)
#define INTC_ETMR0_TC5IR       (616)
#define INTC_ETMR0_WT1F        (619)
#define INTC_ETMR0_RCF         (621)

#define INTC_ETMR1_TC0IR       (622)
#define INTC_ETMR1_TC1IR       (623)
#define INTC_ETMR1_TC2IR       (624)
#define INTC_ETMR1_TC3IR       (625)
#define INTC_ETMR1_TC4IR       (626)
#define INTC_ETMR1_TC5IR       (627)
#define INTC_ETMR1_RCF         (632)

#define INTC_ETMR2_TC0IR       (633)
#define INTC_ETMR2_TC1IR       (634)
#define INTC_ETMR2_TC2IR       (635)
#define INTC_ETMR2_TC3IR       (636)
#define INTC_ETMR2_TC4IR       (637)
#define INTC_ETMR2_TC5IR       (638)
#define INTC_ETMR2_RCF         (643)

#define INTC_PWM0_RF0          (655)
#define INTC_PWM0_COF0         (656)
#define INTC_PWM0_CAF0         (657)
#define INTC_PWM0_RF1          (658)
#define INTC_PWM0_COF1         (659)
#define INTC_PWM0_CAF1         (660)
#define INTC_PWM0_RF2          (661)
#define INTC_PWM0_COF2         (662)
#define INTC_PWM0_CAF2         (663)
#define INTC_PWM0_RF3          (664)
#define INTC_PWM0_COF3         (665)
#define INTC_PWM0_CAF3         (666)
#define INTC_PWM0_FFLAG        (667)
#define INTC_PWM0_REF          (668)

#define INTC_PWM1_RF0          (670)
#define INTC_PWM1_COF0         (671)
#define INTC_PWM1_CAF0         (672)
#define INTC_PWM1_RF1          (673)
#define INTC_PWM1_COF1         (674)
#define INTC_PWM1_CAF1         (675)
#define INTC_PWM1_RF2          (676)
#define INTC_PWM1_COF2         (677)
#define INTC_PWM1_CAF2         (678)
#define INTC_PWM1_RF3          (679)
#define INTC_PWM1_COF3         (680)
#define INTC_PWM1_CAF3         (681)
#define INTC_PWM1_FFLAG        (682)
#define INTC_PWM1_REF          (683)

#define INTC_CTU0_MRS          (700)
#define INTC_CTU0_Tn(n)        (701+(n))
#define INTC_CTU0_FIFO(n)      (709+(n))
#define INTC_CTU0_ADC          (713)
#define INTC_CTU0_ERR          (714)

#define INTC_CTU1_MRS          (716)
#define INTC_CTU1_Tn(n)        (717+(n))
#define INTC_CTU1_FIFO(n)      (725+(n))
#define INTC_CTU1_ADC          (729)
#define INTC_CTU1_ERR          (730)

#define INTC_SGEN              (732)

#endif /* _MPC5744P_INTC_H_ */

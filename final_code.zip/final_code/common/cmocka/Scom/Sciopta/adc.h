/*SOC
**********************************************************************
**  _______  _______ _________ _______  _______ _________ _______   **
** (  ____ \(  ____ \\__   __/(  ___  )(  ____ )\__   __/(  ___  )  **
** | (    \/| (    \/   ) (   | (   ) || (    )|   ) (   | (   ) |  **
** | (_____ | |         | |   | |   | || (____)|   | |   | (___) |  **
** (_____  )| |         | |   | |   | ||  _____)   | |   |  ___  |  **
**       ) || |         | |   | |   | || (         | |   | (   ) |  **
** /\____) || (____/\___) (___| (___) || )         | |   | )   ( |  **
** \_______)(_______/\_______/(_______)|/          )_(   |/     \|  **
**                                                                  **
**                   (c) 2011 SCIOPTA Systems GmbH                  **
**                                                                  **
**********************************************************************
** ID: S11039BS3                                                    **
** +Revision: 1.4.4.5 +                                                 **
** +Date: 2017/10/11 09:36:49 +                                     **
** ADC driver for MPC5643L/MPC5744P                                 **
**********************************************************************
EOC*/

//! @details
//!   To prevent the usage of this header in the production binary code
//!   Only be used for the cmocka test.
//!   define CMOCKA to be externally provided, see MakefileCmocka.
#ifndef CMOCKA
#error "Only to be used with CMOCKA library"
#endif

#ifndef _ADC_H_
#define _ADC_H_ "ADC"

#include <config.h>

#ifndef CNF_BSP_ADC_BASE
#define CNF_BSP_ADC_BASE 0x10800000
#endif

typedef union {
  uint32_t r;
  struct {
#ifdef MPC5744P
    uint16_t bg;
    uint16_t tsens;
#else
    uint16_t p;
    uint16_t c;
#endif
  };
} tsenspc_t;

typedef union {   /* CHANNEL DATA REGS */
  uint32_t R;
  struct {
  uint32_t:12;
    uint32_t  VALID:1;           /* validity of data */
    uint32_t  OVERW:1;           /* overwrite data */
    uint32_t  RESULT:2;          /* reflects mode conversion */
  uint32_t:4;
    uint32_t  CDATA:12;          /* Channel 0 converted data */
  } B;
} ADC_CDR_32B_t;


/*
** adc_enableChannel_t
**
** Enable channel(s) for scan.
*/
#define ADC_ENABLE_CHANNEL_MSG (CNF_BSP_ADC_BASE + 1)
typedef struct adc_enableChannel_s {
  sc_msgid_t id;
  uint32_t chanMask; /* mask, bit == 1 => enable channel, 0 => do not change */
} adc_enableChannel_t;


/*
** adc_enableChannel_t
**
** Enable channel(s) for scan.
*/
#define ADC_DISABLE_CHANNEL_MSG (CNF_BSP_ADC_BASE + 2)
typedef struct adc_disableChannel_s {
  sc_msgid_t id;
  uint32_t chanMask; /* mask, bit == 1 => disable channel, 0 => do not change */
} adc_disableChannel_t;

/*
** adc_readConversion_t
**
** Read all conversion results.
**
*/
#define ADC_READ_CONVERSION_MSG (CNF_BSP_ADC_BASE + 3)
typedef struct adc_readConversion_s {
  sc_msgid_t id;
} adc_readConversion_t;

/*
** adc_readConversionReply_t
**
** Read all conversion results.
**
*/
#define ADC_READ_CONVERSION_REPLY_MSG (CNF_BSP_ADC_BASE + 4)
typedef struct adc_readConversionReply_s {
  sc_msgid_t id;
  uint32_t chanMask; /* bitmask of valid entries */
  ADC_CDR_32B_t cdr[16];  /* see MPC5643L manual vor values in CDR */
} adc_readConversionReply_t;

/*
** adc_readTsensor_t
*/
#define ADC_READ_TSENSOR_MSG (CNF_BSP_ADC_BASE + 5)
#define ADC_READ_TSENSOR_REPLY_MSG (CNF_BSP_ADC_BASE + 6)

typedef struct adc_readTsensor_s {
  sc_msgid_t id;
#ifdef MPC5744P
  uint16_t bg;
  uint16_t tsens;
#else
  uint16_t p;
  uint16_t c;
#endif
} adc_readTsensor_t;

/*
** adc_startScan_t
**
** Start SCAN mode
*/
#define ADC_START_SCAN_MSG (CNF_BSP_ADC_BASE + 7)
typedef struct adc_startScan_s {
  sc_msgid_t id;
} adc_startScan_t;

/*
** adc_stopScan_t
**
** Stop SCAN mode
*/
#define ADC_STOP_SCAN_MSG (CNF_BSP_ADC_BASE + 8)
typedef struct adc_stopScan_s {
  sc_msgid_t id;
} adc_stopScan_t;


/*
** adc_readTemp
*/
#define ADC_READ_TEMP_MSG (CNF_BSP_ADC_BASE + 9)
#define ADC_READ_TEMP_REPLY_MSG (CNF_BSP_ADC_BASE + 10)
typedef struct adc_readTemp_s {
  sc_msgid_t id;
  int error;
  int temp;
} adc_readTemp_t;

/*
** Function interface
*/

/*
** adc_enableChannel
**
** Enable all channels in chanMask in ADC<unit> for scan.
*/
void adc_enableChannel(int unit, uint32_t chanMask);

/*
** adc_disableChannel
**
** Disable all channels in chanMask in ADC<unit>
*/
void adc_disableChannel(int unit, uint32_t chanMask);

/*
** adc_startScan
**
** Start continous scan in ADC<unit>
*/
void adc_startScan(int unit);

/*
** adc_stopScan
**
** Stop continous scan in ADC<unit>
*/
void adc_stopScan(int unit);

/*
** adc_readConversion
**
** Read conversion results for all active channels in <unit>
** Returns adc_readConversionReply_t message.
**
*/
sc_msg_t adc_readConversion(int unit);

/*
** adc_readTsensor
**
** Read the TSENS
*/
tsenspc_t adc_readTsensor(int unit);

/*
** adc_readTemp
**
** Return calculated temperature
*/
int adc_readTemp(int *temp, int unit);
#endif /* _ADC_H_ */

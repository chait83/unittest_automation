/*SOC
**********************************************************************
**  _______  _______ _________ _______  _______ _________ _______   **
** (  ____ \(  ____ \\__   __/(  ___  )(  ____ )\__   __/(  ___  )  **
** | (    \/| (    \/   ) (   | (   ) || (    )|   ) (   | (   ) |  **
** | (_____ | |         | |   | |   | || (____)|   | |   | (___) |  **
** (_____  )| |         | |   | |   | ||  _____)   | |   |  ___  |  **
**       ) || |         | |   | |   | || (         | |   | (   ) |  **
** /\____) || (____/\___) (___| (___) || )         | |   | )   ( |  **
** \_______)(_______/\_______/(_______)|/          )_(   |/     \|  **
**                                                                  **
**                  (c) 2011 SCIOPTA Systems GmbH                   **
**                                                                  **
**********************************************************************
** ID: S11039BS2                                                    **
** +Revision: 1.6.4.3 +                                                 **
** +Date: 2017/09/19 14:51:11 +                                     **
** DSPI driver for MPC5xxx (header)                                 **
**********************************************************************
EOC*/

//! @details
//!   To prevent the usage of this header in the production binary code
//!   Only be used for the cmocka test.
//!   define CMOCKA to be externally provided, see MakefileCmocka.
#ifndef CMOCKA
#error "Only to be used with CMOCKA library"
#endif

#ifndef _DSPI_H_
#define _DSPI_H_ "DSPI"

#ifndef CNF_BSP_SPI_BASE
#define CNF_BSP_SPI_BASE 0x10700000
#endif

/*lint -e657 Unusual (nonportable) anonymous struct or union*/

/*
** Some non-volatile versions of the HW registers
*/
typedef union {   /* CTAR0-7 - Clock and Transfer Attribute Registers */
  uint32_t r;
  struct {
    uint32_t  dbr:1;             /* Double Baud Rate */
    uint32_t  fmsz:4;            /* Frame Size */
    uint32_t  cpol:1;            /* Clock Polarity */
    uint32_t  cpha:1;            /* Clock Phase */
    uint32_t  lsbfe:1;           /* LSB First Enable */
    uint32_t  pcssck:2;          /* PCS to SCK Delay Prescaler */
    uint32_t  pasc:2;            /* After SCK Delay Prescaler */
    uint32_t  pdt:2;             /* Delay after Transfer Prescaler */
    uint32_t  pbr:2;             /* Baud Rate Prescaler */
    uint32_t  cssck:4;           /* PCS to SCK Delay Scaler */
    uint32_t  asc:4;             /* After SCK Delay Scaler */
    uint32_t  dt:4;              /* Delay after Transfer Scaler */
    uint32_t  br:4;              /* Baud Rate Scaler */
  };
} dspi_ctar_t;

/* mcr - module configuration register
** Some parts are removed, as they are not user settable
*/
typedef union {
  uint32_t r;
  struct {
    uint32_t  mstr:1;            /* master/slave mode select */
    uint32_t  cont_scke:1;       /* continuous sck enable */
    uint32_t  :2;                /* privat: dspi configuration */
    uint32_t  frz:1;                /* privat: freeze */
    uint32_t  mtfe:1;            /* modified timing format enable */
    uint32_t  pcsse:1;           /* peripheral chip select strobe enable */
    uint32_t  rooe:1;            /* receive fifo overflow overwrite enable */
    uint32_t  pcsis7:1;          /* peripheral chip select 7 inactive state */
    uint32_t  pcsis6:1;          /* peripheral chip select 6 inactive state */
    uint32_t  pcsis5:1;          /* peripheral chip select 5 inactive state */
    uint32_t  pcsis4:1;          /* peripheral chip select 4 inactive state */
    uint32_t  pcsis3:1;          /* peripheral chip select 3 inactive state */
    uint32_t  pcsis2:1;          /* peripheral chip select 2 inactive state */
    uint32_t  pcsis1:1;          /* peripheral chip select 1 inactive state */
    uint32_t  pcsis0:1;          /* peripheral chip select 0 inactive state */
    uint32_t  doze:1;            /* doze enable */
    uint32_t  :1;                /* privat: module disable */
    uint32_t  :1;                /* privat: disable transmit fifo */
    uint32_t  :1;                /* privat: disable receive fifo */
    uint32_t  clr_txf:1;         /* privat: clear tx fifo */
    uint32_t  clr_rxf:1;         /* privat: clear rx fifo */
    uint32_t  smpl_pt:2;         /* sample point */
    uint32_t  :7;
    uint32_t  halt:1;            /* privat: halt */
  };
} dspi_mcr_t;

#define DSPI_MCR_USER_VALID (0xc7ff8300UL)

/*
** spi_init_t
*/
#define SPI_INIT_MSG      (CNF_BSP_SPI_BASE+0x1)
typedef struct spi_init_s {
  sc_msgid_t id;
  dspi_mcr_t mcr;
} spi_init_t;

/*
** spi_xfer_t
**
** Writes/reads from SPI
*/
#define SPI_XFER_MSG       (CNF_BSP_SPI_BASE+0x3)
#define SPI_XFER_REPLY_MSG(unit) (CNF_BSP_SPI_BASE+0x4+0x10*((uint32_t)unit))

#define SPI_FLAG_CLEAR          (0x00000000)
#define SPI_FLAG_CONTINUED_CS   (0x00000001)    /* leave CS asserted low */

/*e658 Anonymous union assumed*/
typedef struct spi_xfer_s {
  sc_msgid_t id;
  sc_errcode_t error;       /* returned error code => errno.h */
  dspi_ctar_t ctar;         /* Basic CTAR: See HW manual      */
  uint32_t flags;           /* various flags                  */
  unsigned int cs;          /* chipselect                     */
  unsigned int size;        /* number of frames to transfer   */
  unsigned int inOffset;    /* where to store data            */
  unsigned int outOffset;   /* where to get data from         */
  union {
    uint8_t bdata[1];
    uint16_t sdata[1];
  }; /*lint !e658*/
} spi_xfer_t;

/*
** Function interface
*/

uint32_t dspi_calcCTAR(uint32_t baudrate,
                       uint32_t cssckDelay,
                       uint32_t ascDelay,
                       uint32_t dtDelay,
                       int cpol,
                       int cpha,
                       int fmsz);

#endif /* _DSPI_H_ */

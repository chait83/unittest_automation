// *****************************************************************************
// **                _______   _________  _________   _______                 **
// **               (  ___  )  \__   __/  \__   __/  (  ____ \                **
// **               | (   ) |     ) (        ) (     | (    \/                **
// **               | |   | |     | |        | |     | (_____                 **
// **               | |   | |     | |        | |     (_____  )                **
// **               | |   | |     | |        | |           ) |                **
// **               | (___) |     | |     ___) (___  /\____) |                **
// **               (_______)     )_(     \_______/  \_______)                **
// **                                                                         **
// **                   Component Engineering Center Berlin                   **
// **                                                                         **
// **   Copyright 2019 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **
// **                                                                         **
// *****************************************************************************
//!
//! @file
//!
//! @ingroup grp_CanSchedConfiguration
//!
//! @brief  Board specific Configuration of the CAN scheduler
//!
//! @sa CanSched/Cfg.h
//!
// *****************************************************************************


//! @details
//!   To prevent the usage of this header in the production binary code
//!   Only be used for the cmocka test.
//!   define CMOCKA to be externally provided, see MakefileCmocka.
#ifndef CMOCKA
#error "Only to be used with CMOCKA library"
#endif

#ifndef CFGCANSCHED_H
#define CFGCANSCHED_H


#include "CanSched/CfgDriver.h"
#include <sciopta_sc.h>
#include <sdd/sdd.h>
#include <sdd/sddcan.h>


// =============================================================================
//  CONFIGURATION
// =============================================================================

//! @brief  number of used channels (up to 3)
#define CFGCANSCHED_CHANNELS 3

//! @name Configuration settings of Channel 0
//! @{
#if CFGCANSCHED_CHANNELS >= 1

  //! @brief  HW unit of the channel
  #define CFGCANSCHED_CHANNEL_0_UNIT           0

  //! @brief  baud rate of the channel
  //! @sa sdd/sddcan.h `_CAN_100k_`, `_CAN_125k_`, ...
  #define CFGCANSCHED_CHANNEL_0_BAUD           (_CAN_125k_)

  //! @brief  number of receive filters reserved for safety related software
  #define CFGCANSCHED_CHANNEL_0_SRS_FILTERS    (15)

  //! @brief  number of receive filters reserved for safety and non-safety
  //!         related software together
  #define CFGCANSCHED_CHANNEL_0_USED_MAILBOXES (CANSCHEDCFGDRIVER_UNIT_0_MAX_FILTERS)

#endif
//! @}

//! @name Configuration settings of Channel 1
//! @{
#if CFGCANSCHED_CHANNELS >= 2

  //! @brief  HW unit of the channel
  #define CFGCANSCHED_CHANNEL_1_UNIT           1

  //! @brief  baud rate of the channel
  //! @sa sdd/sddcan.h `_CAN_100k_`, `_CAN_125k_`, ...
  #define CFGCANSCHED_CHANNEL_1_BAUD           (_CAN_125k_)

  //! @brief  number of receive filters reserved for safety related software
  #define CFGCANSCHED_CHANNEL_1_SRS_FILTERS    (15)

  //! @brief  number of receive filters reserved for safety and non-safety
  //!         related software together
  #define CFGCANSCHED_CHANNEL_1_USED_MAILBOXES (CANSCHEDCFGDRIVER_UNIT_1_MAX_FILTERS)

#endif
//! @}

//! @name Configuration settings of Channel 2
//! @{
#if CFGCANSCHED_CHANNELS >= 3

  //! @brief  HW unit of the channel
  #define CFGCANSCHED_CHANNEL_2_UNIT           2

  //! @brief  baud rate of the channel
  //! @sa sdd/sddcan.h `_CAN_100k_`, `_CAN_125k_`, ...
  #define CFGCANSCHED_CHANNEL_2_BAUD           (_CAN_125k_)

  //! @brief  number of receive filters reserved for safety related software
  #define CFGCANSCHED_CHANNEL_2_SRS_FILTERS    (15)

  //! @brief  number of receive filters reserved for safety and non-safety
  //!         related software together
  #define CFGCANSCHED_CHANNEL_2_USED_MAILBOXES (CANSCHEDCFGDRIVER_UNIT_2_MAX_FILTERS)

#endif
//! @}

//! @brief  number of CAN messages that might be concurrently in the send queue
//!         of each single channel
#define CFGCANSCHED_SEND_QUEUE_LENGTH 32


#endif // CFGCANSCHED_H

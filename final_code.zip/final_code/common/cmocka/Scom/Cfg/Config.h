// *****************************************************************************
// **                _______   _________  _________   _______                 **
// **               (  ___  )  \__   __/  \__   __/  (  ____ \                **
// **               | (   ) |     ) (        ) (     | (    \/                **
// **               | |   | |     | |        | |     | (_____                 **
// **               | |   | |     | |        | |     (_____  )                **
// **               | |   | |     | |        | |           ) |                **
// **               | (___) |     | |     ___) (___  /\____) |                **
// **               (_______)     )_(     \_______/  \_______)                **
// **                                                                         **
// **                   Component Engineering Center Berlin                   **
// **                                                                         **
// **   Copyright 2019 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **
// **                                                                         **
// *****************************************************************************
//!
//! @file
//!
//! @brief  board specific part of config.h
//!
// *****************************************************************************

//! @details
//!   To prevent the usage of this header in the production binary code
//!   Only be used for the cmocka test.
//!   define CMOCKA to be externally provided, see MakefileCmocka.
#ifndef CMOCKA
#error "Only to be used with CMOCKA library"
#endif

#ifndef CFG_CONFIG_H
#define CFG_CONFIG_H

//! @reviewNoAction
//! * GB, MW - 2019-06-06
//!   * no action required


//! @name Otis Debug Configuration
//! @{
//!
//! @details
//!
//! When CNF_PRODUCTION_CODE is set to 1, the build is meant as a production-build without any debugging-capabilities.
//!
//! When CNF_NEAR_PRODUCTION_CODE is set to 1, the build is also meant as a
//! production-build without any debugging-capabilities.  But with some
//! provisioning faults deactivated, so that less electronic waste is produces
//! in the laboratories.
//!
//! "Without any debugging-capabilities", means that none of the module-specific
//! debug-defines -- as well as the usage of the debug-jumper
//! using the CNF_DEBUG_PERMITTED-define -- can be set when the define CNF_NEAR_PRODUCTION_CODE is set to 1.
//! In case the build is not a production build, any combination of the module-specific debug-defines and the
//! debug-jumper can be set.
//! If an debug-define is enabled in the production-build, the code will not compile by intention.
//! The following table lists all possible settings and their result:
//!
//! CNF_NEAR_PRODUCTION_CODE | CNF_DEBUG_PERMITTED | module-specific define (like PROCTIMING_ENABLE) | result
//! :-----------------------:|:-------------------:|:-----------------------------------------------:|:--------------------------------------------------------------------
//!             0            |          0          |                        0                        | build without debug-jumper-support and without module-specific debug
//!             0            |          0          |                        1                        | build without debug-jumper-support and with    module-specific debug
//!             0            |          1          |                        0                        | build with    debug-jumper-support and without module-specific debug
//!             0            |          1          |                        1                        | build with    debug-jumper-support and with    module-specific debug
//!             1            |          0          |                        0                        | build without any debug-support
//!             1            |          0          |                        1                        | build-failure
//!             1            |          1          |                        0                        | build-failure
//!             1            |          1          |                        1                        | build-failure
//!
//! When introducing new module-specific debug-defines, it must be checked if the configuration is not
//! an production build. See an existing define (like PROCTIMING_ENABLE) for an example.
//!
//! @note Some debug-capabilities may be automatically enabled, if the build is a non-production build.
//!
//! @sa PROCTIMING_ENABLE
//! @sa PESDBGPROC_ACTIVE


// =============================================================================
//! @brief configure debug mode
//!
//! @details
//!
//!   This define should be either `1` or `0`.  Other values are not allowed.
//!
//!    Value | Description
//!   -------|-------------------------------------------------------------
//!        0 | "Safe" production version, debug mode not possible
//!        1 | allows both "safe" and debug mode depending on debug jumper
//!
//! @note Setting CNF_DEBUG_PERMITTED is only allowed if CNF_PRODUCTION_CODE is not set.
//! @note Setting CNF_DEBUG_PERMITTED is only allowed if CNF_NEAR_PRODUCTION_CODE is not set.
//!
//! @sa CNF_PRODUCTION_CODE
//! @sa CNF_NEAR_PRODUCTION_CODE
// =============================================================================
#define CNF_DEBUG_PERMITTED  (0)

// ensure the correct definition of CNF_DEBUG_PERMITTED
#ifndef CNF_DEBUG_PERMITTED
  #error CNF_DEBUG_PERMITTED not defined
#elif ((CNF_DEBUG_PERMITTED != 0) && (CNF_DEBUG_PERMITTED != 1))
  #error Wrong CNF_DEBUG_PERMITTED setting
#endif


// =============================================================================
//! @brief configure production mode
//!
//! @details
//!
//!   This define should be either `1` or `0`.  Other values are not allowed.
//!
//!    Value | Description
//!   -------|-------------------------------------------------------------
//!        0 | enable debugging (to execute detailed diagnostics for lab purposes or usage of the debug jumper)
//!        1 | production version without debug output (CFG_DEBUG_PERMITTED is also not accepted)
//!
//! @sa CNF_DEBUG_PERMITTED
//! @sa CNF_NEAR_PRODUCTION_CODE
// =============================================================================

#define CNF_PRODUCTION_CODE  (1)

// ensure the correct definition of CNF_PRODUCTION_CODE
#ifndef CNF_PRODUCTION_CODE
  #error CNF_PRODUCTION_CODE not defined
#elif ((CNF_PRODUCTION_CODE != 0) && (CNF_PRODUCTION_CODE != 1))
  #error Wrong CNF_PRODUCTION_CODE setting
#endif

// the setting of CNF_DEBUG_PERMITTED is only allowed when CNF_PRODUCTION_CODE is not set
#if ((CNF_PRODUCTION_CODE != 0) && (CNF_DEBUG_PERMITTED != 0))
  #error CNF_DEBUG_PERMITTED can only be used when CNF_PRODUCTION_CODE is not set
#endif


// =============================================================================
//! @brief configure near production mode
//!
//! @details
//!
//!   This define should be either `1` or `0`.  Other values are not allowed.
//!
//!   This is similar to #CNF_PRODUCTION_CODE, except that the provisioning
//!   faults
//!     * JTAG-Password-Not-Set-Fault
//!     * OTP-Not-Activated-Fault
//!     * PCB-Manufacturing-Date-Not-Set-Fault
//!   do not set the "critical function" error class.  This is necessary to
//!   decrease electronic waste in the laboratories.
//!
//!
//! @sa CNF_DEBUG_PERMITTED
//! @sa CNF_PRODUCTION_CODE
// =============================================================================

#define CNF_NEAR_PRODUCTION_CODE  (1)

// ensure the correct definition of CNF_NEAR_PRODUCTION_CODE
#ifndef CNF_NEAR_PRODUCTION_CODE
  #error CNF_NEAR_PRODUCTION_CODE not defined
#elif ((CNF_NEAR_PRODUCTION_CODE != 0) && (CNF_NEAR_PRODUCTION_CODE != 1))
  #error Wrong CNF_NEAR_PRODUCTION_CODE setting
#endif

// when CNF_NEAR_PRODUCTION_CODE is set, then also CNF_PRODUCTION_CODE must be set
#if ((CNF_PRODUCTION_CODE != 0) && (CNF_NEAR_PRODUCTION_CODE == 0))
  #error if CNF_PRODUCTION_CODE is set, CNF_NEAR_PRODUCTION_CODE must also be set
#endif

// the setting of CNF_DEBUG_PERMITTED is only allowed when CNF_NEAR_PRODUCTION_CODE is not set
#if ((CNF_NEAR_PRODUCTION_CODE != 0) && (CNF_DEBUG_PERMITTED != 0))
  #error CNF_DEBUG_PERMITTED can only be used when CNF_NEAR_PRODUCTION_CODE is not set
#endif

//! @}


// #############################################################################
//! @name Activated Sciopta Processes
//! @{
// #############################################################################

// ADC
#define CNF_ADC0           //!< ADC0 configured & used by Sciopta
#define CNF_ADC1           //!< ADC1 configured & used by Sciopta


// CAN (FlexCan)
#define CNF_CAN0           //!< CAN0 configured & used by Sciopta


// PWM
#define CNF_PWM0           //!< PWM0 configured & used by Sciopta


// SPI
#define CNF_DSPI0          //!< DSPI0 configured & used by Sciopta
#define CNF_DSPI1          //!< DSPI1 configured & used by Sciopta

//! @}



// #############################################################################
//! @name Activated Otis Processes
//! @{
// #############################################################################

// Shift Register
#define CNF_SHIFTREG      //!< shift register process is used

//! @}



// #############################################################################
//! @name Timings
//! @{
// #############################################################################

// SysTick
#define CNF_TICKLENGTH (1187)   //!<  Sciopta systick length in us (same as in SCON)


// SW and HW watchdog settings
#define CNF_SWT_WATCHDOG_TIMEOUT_MS     (12)   //!< (SWT) SW watchdog timeout value in [ms]
#define CNF_SBC_WATCHDOG_TIMEOUT_MS     (12)   //!< <ReqId 261640> (SBC) HW watchdog timeout value in [ms]

//! @}

#endif // CFG_CONFIG_H

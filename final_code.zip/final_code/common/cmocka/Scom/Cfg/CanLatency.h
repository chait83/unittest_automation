// =======================================================================================
// Copyright 2021 OTIS GmbH & Co. OHG - OTIS Lead Design Center Berlin
// =======================================================================================
//
//! @file
//!
//! @brief PCB specific configuration of CAN latency measurement
//
// =======================================================================================


#ifndef CFGCANLATENCY_H
#define CFGCANLATENCY_H


#include "config.h"


#if (CNF_NEAR_PRODUCTION_CODE == 0)

  // When defining CFGCANLATENCY_ENABLE, the following needs to be done:
  //
  //  - Temporarily do the following changes to common\src\sciopta\bsp\ppc\mpc5xxx\src\flexcan.c. This file may not be changed
  //    for production builds since it has been certified by Sciopta.
  //
  //      - Add #include "CanLatency.h"
  //
  //      - Call CANLATENCY_STOP_TX_LATENCY as last command in FCAN_Tx
  //
  //          static void FCAN_Tx ...
  //          {
  //            ...
  //            (void)CAN(unit).TIMER.R; /* unlock MBs */
  //            CANLATENCY_STOP_TX_LATENCY(id, extended, unit);
  //          }
  //
  //  - If sc_procCreate2 generates an "Out of Memory" error at startup, the system default pool size needs to be reduced
  //    accordingly.

  // #define CFGCANLATENCY_ENABLE

#endif


// =======================================================================================
// Defines
// =======================================================================================


//! Maximum number of CAN messages that are waiting to be put into the transmit mailbox of the CAN controller
#define CFGCANLATENCY_TXLIST_SIZE         10

//! Number of latencies in 100 us steps in the histogram, e.g. 101 -> 0.0 ms ... 10.0 ms
#define CFGCANLATENCY_TXLATENCYLIST_SIZE 101


#endif // #ifndef CFGCANLATENCY_H

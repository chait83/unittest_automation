//! @details
//!   To prevent the usage of this header in the production binary code
//!   Only be used for the cmocka test.
//!   define CMOCKA to be externally provided, see MakefileCmocka.
#ifndef CMOCKA
#error "Only to be used with CMOCKA library"
#endif

#ifndef CFGCAN_H
#define CFGCAN_H


enum CanBus
{
  Pit_bus   = 0,
  Opb_bus   = 1,
  Car_bus   = 2,
  Aprs1_bus   = 3,
  Aprs2_bus   = 4,
  __BUS_NOWRITE__ = 5
};

#endif // CFGCAN_H

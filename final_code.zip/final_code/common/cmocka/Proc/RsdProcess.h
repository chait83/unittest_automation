// =======================================================================================
// Copyright 2022 OTIS GmbH & Co. OHG - Lead Design Center Berlin
// =======================================================================================
//
//! @file
//!
//! @brief RSD process
//!
//! @details
//!   This module handles RSD message processing
// =======================================================================================

#ifndef PROC_RSDPROCESS_H
#define PROC_RSDPROCESS_H

#include <sciopta_sc.h>

// =============================================================================
// Function Prototypes
// =============================================================================


// ======================================================================================
//! @brief Remote Software Download process
//!
//! @details
//!   This process runs the remote software download.
// ======================================================================================
extern SC_PROCESS(ProcRsdProcess_Process);

#endif  // PROC_RSDPROCESS_H

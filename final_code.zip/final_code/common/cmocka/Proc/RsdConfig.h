// =======================================================================================
// Copyright 2022 OTIS GmbH & Co. OHG - Lead Design Center Berlin
// =======================================================================================
//
//! @file
//!
//! @brief RSD process
//!
//! @details
//!   This module handles RSD message processing
// =======================================================================================

#ifndef PROC_RSDCONFIG_H
#define PROC_RSDCONFIG_H


// =============================================================================
// Function Prototypes
// =============================================================================
#define PESS_SCON  //!< This configures the dbc library for the correct board configuration

#endif  // PROC_RSDCONFIG_H



/*
 * ATECC508.h
 *
 *  Created on: May 13, 2020
 *      Author: piecha
 */

#ifndef CMOCKA_WRAP_COMMON_CRYPTO_ATECC508_H_
#define CMOCKA_WRAP_COMMON_CRYPTO_ATECC508_H_

#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <stdint.h>
#include <stdbool.h>

#include "cmocka.h"

#include <sciopta_sc.h>
#include <logd/logd.h>


#define ATECC_PUB_KEY_SIZE            (64)       //!< size of a p256 public key


// =====================================================================================
//! @brief ATECC508 Status/Error codes read back from device or detected by functions below
// =====================================================================================
typedef enum
{
  ATECC508_ERROR_SUCCESS             = 0x000,  //!< returned from device
  ATECC508_ERROR_CHECKMAC_VERIFY_ERR = 0x001,  //!< returned from device
  ATECC508_ERROR_PARSE_ERR           = 0x003,  //!< returned from device
  ATECC508_ERROR_ECC_FAULT           = 0x005,  //!< returned from device
  ATECC508_ERROR_EXECUTION_FAULT     = 0x00F,  //!< returned from device
  ATECC508_ERROR_STATUS_AWAKED       = 0x011,  //!< returned from device
  ATECC508_ERROR_WATCHDOG_EXPIRING   = 0x0EE,  //!< returned from device
  ATECC508_ERROR_CRC_COMM_ERR        = 0x0FF,  //!< returned from device
  ATECC508_ERROR_CRC_MISMATCH        = 0x100,  //!< detected by functions below
  ATECC508_ERROR_UNEXP_PACKETSIZE    = 0x101,  //!< detected by functions below
  ATECC508_ERROR_BAD_DEVICE_STATUS   = 0x102,  //!< returned from device but unknown value
  ATECC508_ERROR_I2C_ERROR           = 0x103,  //!< i2c device reported an error
  ATECC508_ERROR_TIMEOUT             = 0x104,  //!< timeout during reception
  ATECC508_ERROR_BUF_TOO_SMALL       = 0x105,  //!< destination buffer too small
  ATECC508_ERROR_INVALID_PARAMS      = 0x106,  //!< invalid parameters given
  ATECC508_ERROR_INVALID_DATA        = 0x107,  //!< invalid data recieved
} ATECC508_Error_t;


extern ATECC508_Error_t __wrap_ATECC508_GoSleep(void);

extern ATECC508_Error_t __wrap_ATECC508_GoIdle(void);

extern ATECC508_Error_t __wrap_ATECC508_WakeUp(void);

extern ATECC508_Error_t __wrap_ATECC508_Cmd_Read(const uint8_t param1, const uint16_t param2, uint8_t responseSize, uint8_t *pResponse);

extern ATECC508_Error_t __wrap_ATECC508_genPubKey(uint8_t slotID, uint8_t pubKey[ATECC_PUB_KEY_SIZE]);

extern ATECC508_Error_t __wrap_ATECC508_lockCfg(void);

extern ATECC508_Error_t __wrap_ATECC508_lockDev(void);

extern ATECC508_Error_t __wrap_ATECC508_lockSlot(uint8_t slotID);

extern ATECC508_Error_t __wrap_ATECC508_readData ( const uint8_t chipZone, const uint16_t addr, uint8_t* const data, const uint16_t bytesToRead );

extern ATECC508_Error_t __wrap_ATECC508_readKeyCfg(const uint8_t slotID, uint8_t* const keyCfg);

extern ATECC508_Error_t __wrap_ATECC508_readSlotCfg(const uint8_t slotID, uint8_t* const slotCfg);

extern ATECC508_Error_t __wrap_ATECC508_readSlotLock(const uint8_t slotID, bool* const slotLock);

extern ATECC508_Error_t __wrap_ATECC508_readCfgLock ( bool* const cfgLock );

extern ATECC508_Error_t __wrap_ATECC508_readDevLock ( bool* const devLock );

extern int __wrap_ATECC508_powerCycle ( logd_t* const logd, const uint32_t durationMs );

extern ATECC508_Error_t __wrap_ATECC508_Cmd_Verify(const uint8_t mode, const uint16_t keyID, const uint8_t *signature, const uint8_t *oherData);

extern ATECC508_Error_t __wrap_ATECC508_Cmd_GenKey(const uint8_t param1, const uint16_t param2, const uint8_t *data, uint8_t responseSize, uint8_t *pResponse);

extern ATECC508_Error_t __wrap_ATECC508_writeData ( const uint8_t chipZone, const uint16_t addr, const uint8_t* const data, const uint16_t bytesToWrite );

extern ATECC508_Error_t __wrap_ATECC508_writeKeyCfg(const uint8_t slotID, const uint8_t* const keyCfg);

extern ATECC508_Error_t __wrap_ATECC508_writeSlotCfg(const uint8_t slotID, const uint8_t* const slotCfg);

extern ATECC508_Error_t __wrap_ATECC508_performCreateDataHash ( const uint8_t* const msg, const size_t msgLen, uint8_t* const digest, const size_t digestLen );

#endif /* CMOCKA_WRAP_COMMON_CRYPTO_ATECC508_H_ */


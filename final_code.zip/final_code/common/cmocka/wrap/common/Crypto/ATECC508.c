/*
 * ATECC508.c
 *
 *  Created on: 2020-11-23
 *      Author: piecha
 */

#include "wrap/common/Crypto/ATECC508.h"


extern ATECC508_Error_t __wrap_ATECC508_GoSleep(void)
{
  return (ATECC508_Error_t) mock();
}

extern ATECC508_Error_t __wrap_ATECC508_GoIdle(void)
{
  return (ATECC508_Error_t) mock();
}

extern ATECC508_Error_t __wrap_ATECC508_WakeUp(void)
{
  return (ATECC508_Error_t) mock();
}

extern ATECC508_Error_t __wrap_ATECC508_Cmd_Read(const uint8_t param1, const uint16_t param2, uint8_t responseSize, uint8_t *pResponse)
{
  return (ATECC508_Error_t) mock();
}

extern ATECC508_Error_t __wrap_ATECC508_genPubKey(uint8_t slotID, uint8_t pubKey[ATECC_PUB_KEY_SIZE])
{
  return (ATECC508_Error_t) mock();
}

extern ATECC508_Error_t __wrap_ATECC508_lockCfg(void)
{
  return (ATECC508_Error_t) mock();
}

extern ATECC508_Error_t __wrap_ATECC508_lockDev(void)
{
  return (ATECC508_Error_t) mock();
}

extern ATECC508_Error_t __wrap_ATECC508_lockSlot(uint8_t slotID)
{
  return (ATECC508_Error_t) mock();
}

extern ATECC508_Error_t __wrap_ATECC508_readData ( const uint8_t chipZone, const uint16_t addr, uint8_t* const data, const uint16_t bytesToRead )
{
  return (ATECC508_Error_t) mock();
}

extern ATECC508_Error_t __wrap_ATECC508_readKeyCfg(const uint8_t slotID, uint8_t* const keyCfg)
{
  return (ATECC508_Error_t) mock();
}

extern ATECC508_Error_t __wrap_ATECC508_readSlotCfg(const uint8_t slotID, uint8_t* const slotCfg)
{
  return (ATECC508_Error_t) mock();
}

extern ATECC508_Error_t __wrap_ATECC508_readSlotLock(const uint8_t slotID, bool* const slotLock)
{
  const ATECC508_Error_t  rc = (ATECC508_Error_t) mock();
  const bool  lockVal = (bool) mock();
  if (NULL != slotLock)
  {
    if (ATECC508_ERROR_SUCCESS == rc)
    {
      *slotLock = lockVal;
    }
    else
    {
      *slotLock = false;
    }
  }
  return rc;
}

extern ATECC508_Error_t __wrap_ATECC508_readCfgLock ( bool* const cfgLock )
{
  const ATECC508_Error_t  rc = (ATECC508_Error_t) mock();
  const bool  lockVal = (bool) mock();
  if (NULL != cfgLock)
  {
    if (ATECC508_ERROR_SUCCESS == rc)
    {
      *cfgLock = lockVal;
    }
    else
    {
      *cfgLock = false;
    }
  }
  return rc;
}

extern ATECC508_Error_t __wrap_ATECC508_readDevLock ( bool* const devLock )
{
  const ATECC508_Error_t  rc = (ATECC508_Error_t) mock();
  const bool  lockVal = (bool) mock();
  if (NULL != devLock)
  {
    if (ATECC508_ERROR_SUCCESS == rc)
    {
      *devLock = lockVal;
    }
    else
    {
      *devLock = false;
    }
  }
  return rc;
}

extern int __wrap_ATECC508_powerCycle(logd_t* const logd, const uint32_t durationMs)
{
  return (ATECC508_Error_t) mock();
}

extern ATECC508_Error_t __wrap_ATECC508_Cmd_Verify(const uint8_t mode, const uint16_t keyID, const uint8_t *signature, const uint8_t *oherData)
{
  return (ATECC508_Error_t) mock();
}

extern ATECC508_Error_t __wrap_ATECC508_Cmd_GenKey(const uint8_t param1, const uint16_t param2, const uint8_t *data, uint8_t responseSize, uint8_t *pResponse)
{
  return (ATECC508_Error_t) mock();
}

extern ATECC508_Error_t __wrap_ATECC508_writeData ( const uint8_t chipZone, const uint16_t addr, const uint8_t* const data, const uint16_t bytesToWrite )
{
  return (ATECC508_Error_t) mock();
}

extern ATECC508_Error_t __wrap_ATECC508_writeKeyCfg(const uint8_t slotID, const uint8_t* const keyCfg)
{
  return (ATECC508_Error_t) mock();
}

extern ATECC508_Error_t __wrap_ATECC508_writeSlotCfg(const uint8_t slotID, const uint8_t* const slotCfg)
{
  return (ATECC508_Error_t) mock();
}

extern ATECC508_Error_t __wrap_ATECC508_performCreateDataHash ( const uint8_t* const msg, const size_t msgLen, uint8_t* const digest, const size_t digestLen )
{
  return (ATECC508_Error_t) mock();
}


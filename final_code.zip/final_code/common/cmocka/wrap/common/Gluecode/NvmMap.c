#include "NvmMap.h"

extern void __wrap_GlueCodeNvm_HandleNvmItemsOfInterest(GlueCodeNvm_OfInterest_S * nvmOfInterests,
                                                       size_t size,
                                                       enum GlueCodeNvmAction action,
                                                       GlueCodeProcessNvm_Common_IO_S * nvmCommon)
{
  function_called();
}

extern void __wrap_GlueCodeNvmMap_Item0(
    enum nvm_message_id msgId,
    uint8_t * nvmBuffer,
    GlueCodeProcessNvm_Common_S * nvmCommon,
    bool toBuffer)
{

}

extern void __wrap_GlueCodeNvmMap_Item1(
    enum nvm_message_id msgId,
    uint8_t * nvmBuffer,
    GlueCodeProcessNvm_Common_S * nvmCommon,
    bool toBuffer)
{

}

extern void __wrap_GlueCodeNvmMap_Item2(
    enum nvm_message_id msgId,
    uint8_t * nvmBuffer,
    GlueCodeProcessNvm_Common_S * nvmCommon,
    bool toBuffer)
{

}

extern void __wrap_GlueCodeNvmMap_Item3(
    enum nvm_message_id msgId,
    uint8_t * nvmBuffer,
    GlueCodeProcessNvm_Common_S * nvmCommon,
    bool toBuffer)
{

}

extern void __wrap_GlueCodeNvmMap_Item4(
    enum nvm_message_id msgId,
    uint8_t * nvmBuffer,
    GlueCodeProcessNvm_Common_S * nvmCommon,
    bool toBuffer)
{

}

extern void __wrap_GlueCodeNvmMap_Item5(
    enum nvm_message_id msgId,
    uint8_t * nvmBuffer,
    GlueCodeProcessNvm_Common_S * nvmCommon,
    bool toBuffer)
{

}

extern void __wrap_GlueCodeNvmMap_Item6(
    enum nvm_message_id msgId,
    uint8_t * nvmBuffer,
    GlueCodeProcessNvm_Common_S * nvmCommon,
    bool toBuffer)
{

}

extern void __wrap_GlueCodeNvmMap_Item7(
    enum nvm_message_id msgId,
    uint8_t * nvmBuffer,
    GlueCodeProcessNvm_Common_S * nvmCommon,
    bool toBuffer)
{

}

extern void __wrap_GlueCodeNvmMap_Item8(
    enum nvm_message_id msgId,
    uint8_t * nvmBuffer,
    GlueCodeProcessNvm_Common_S * nvmCommon,
    bool toBuffer)
{

}

extern void __wrap_GlueCodeNvmMap_Item23(
    enum nvm_message_id msgId,
    uint8_t * nvmBuffer,
    GlueCodeProcessNvm_Common_S * nvmCommon,
    bool toBuffer)
{

}

extern void __wrap_GlueCodeNvmMap_Item25(
    enum nvm_message_id msgId,
    uint8_t * nvmBuffer,
    GlueCodeProcessNvm_Common_S * nvmCommon,
    bool toBuffer)
{

}

extern void __wrap_GlueCodeNvmMap_Item26(
    enum nvm_message_id msgId,
    uint8_t * nvmBuffer,
    GlueCodeProcessNvm_Common_S * nvmCommon,
    bool toBuffer)
{

}

extern void __wrap_GlueCodeNvmMap_Item27(
    enum nvm_message_id msgId,
    uint8_t * nvmBuffer,
    GlueCodeProcessNvm_Common_S * nvmCommon,
    bool toBuffer)
{

}

extern void __wrap_GlueCodeNvmMap_Item28_39(
    enum nvm_message_id msgId,
    uint8_t * nvmBuffer,
    GlueCodeProcessNvm_Common_S * nvmCommon,
    bool toBuffer)
{

}

extern void __wrap_GlueCodeNvmMap_Item100_105(
    enum nvm_message_id msgId,
    uint8_t * nvmBuffer,
    GlueCodeProcessNvm_Common_S * nvmCommon,
    bool toBuffer)
{

}

extern void __wrap_GlueCodeNvmMap_Item140(
    enum nvm_message_id msgId,
    uint8_t * nvmBuffer,
    GlueCodeProcessNvm_Common_S * nvmCommon,
    bool toBuffer)
{

}

extern void __wrap_GlueCodeNvmMap_Item141(
    enum nvm_message_id msgId,
    uint8_t * nvmBuffer,
    GlueCodeProcessNvm_Common_S * nvmCommon,
    bool toBuffer)
{

}

extern void __wrap_GlueCodeNvmMap_Item142(
    enum nvm_message_id msgId,
    uint8_t * nvmBuffer,
    GlueCodeProcessNvm_Common_S * nvmCommon,
    bool toBuffer)
{

}


extern void __wrap_GlueCodeNvmMap_Item143(
    enum nvm_message_id msgId,
    uint8_t * nvmBuffer,
    GlueCodeProcessNvm_Common_S * nvmCommon,
    bool toBuffer)
{

}

extern void __wrap_GlueCodeNvmMap_Item205(
    enum nvm_message_id msgId,
    uint8_t * nvmBuffer,
    GlueCodeProcessNvm_Common_S * nvmCommon,
    bool toBuffer)
{

}

extern void __wrap_GlueCodeNvmMap_Item206(
    enum nvm_message_id msgId,
    uint8_t * nvmBuffer,
    GlueCodeProcessNvm_Common_S * nvmCommon,
    bool toBuffer)
{

}

extern void __wrap_GlueCodeNvmMap_Item207(
    enum nvm_message_id msgId,
    uint8_t * nvmBuffer,
    GlueCodeProcessNvm_Common_S * nvmCommon,
    bool toBuffer)
{

}

extern void __wrap_GlueCodeNvmMap_Item208(
    enum nvm_message_id msgId,
    uint8_t * nvmBuffer,
    GlueCodeProcessNvm_Common_S * nvmCommon,
    bool toBuffer)
{

}

extern void __wrap_GlueCodeNvmMap_Item209_219(
    enum nvm_message_id msgId,
    uint8_t * nvmBuffer,
    GlueCodeProcessNvm_Common_S * nvmCommon,
    bool toBuffer)
{

}

extern void __wrap_GlueCodeNvmMap_Item220_224(
    enum nvm_message_id msgId,
    uint8_t * nvmBuffer,
    GlueCodeProcessNvm_Common_S * nvmCommon,
    bool toBuffer)
{

}

//!}

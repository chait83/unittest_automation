/*
 * Proc.h
 *
 *  Created on: Apr 16, 2020
 *      Author: knuth
 */

#ifndef CMOCKA_WRAP_COMMON_HLP_PROC_H_
#define CMOCKA_WRAP_COMMON_HLP_PROC_H_

#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <stdint.h>

#include "cmocka.h"

#include <sciopta_sc.h>
#include <stdbool.h>

#include <logd/logd.h>

extern bool __wrap_HlpProc_AlwaysTrue(void);

extern logd_t *  __wrap_HlpProcVar_GetLogd(void);

extern sc_pid_t __wrap_HlpProc_GetCurrentPid(void);

#endif /* CMOCKA_WRAP_COMMON_HLP_PROC_H_ */

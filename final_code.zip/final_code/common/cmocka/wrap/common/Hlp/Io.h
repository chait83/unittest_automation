/*
 * Io.h
 *
 *  Created on: Apr 16, 2020
 *      Author: knuth
 */

#ifndef CMOCKA_WRAP_COMMON_HLP_IO_H_
#define CMOCKA_WRAP_COMMON_HLP_IO_H_

#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <stdint.h>

#include "cmocka.h"

#include <sciopta_sc.h>
#include <logd/logd.h>

#include "Hlp/Io.h"

extern void __wrap_hlpio_readAllPortsIn(logd_t * logd, const sc_pid_t pid,
                                        hlpio_allPorts_t * data);

extern void __wrap_hlpio_setAllPorts(logd_t * logd, const sc_pid_t pid,
                                     const hlpio_allPorts_t * mask,
                                     const hlpio_allPorts_t * data);

#endif /* CMOCKA_WRAP_COMMON_HLP_IO_H_ */

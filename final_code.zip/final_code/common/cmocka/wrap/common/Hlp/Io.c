/*
 * Io.c
 *
 *  Created on: Apr 16, 2020
 *      Author: knuth
 */

#include "wrap/common/Hlp/Io.h"

extern void __wrap_hlpio_readAllPortsIn(logd_t * logd, const sc_pid_t pid,
                                        hlpio_allPorts_t * data)
{
  function_called();
}

extern void __wrap_hlpio_setAllPorts(logd_t * logd, const sc_pid_t pid,
                                     const hlpio_allPorts_t * mask,
                                     const hlpio_allPorts_t * data)
{
  function_called();
}

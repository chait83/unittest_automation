/*
 * hlp.h
 *
 *  Created on: Apr 16, 2020
 *      Author: knuth
 */

#ifndef CMOCKA_WRAP_COMMON_HLP_FAILURE_H_
#define CMOCKA_WRAP_COMMON_HLP_FAILURE_H_

#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <stdint.h>

#include "cmocka.h"

#include <sciopta_sc.h>
#include <logd/logd.h>

extern void __wrap_HlpFailure_EndlessLoopBusy(void);

extern void __wrap_HlpFailure_EndlessLoop(void);

extern void __wrap_HlpMsg_AssertSentFatal_f(logd_t * logd, sc_msg_t * pm,
                                            const char * file, int line,
                                            const char * func);

#endif /* CMOCKA_WRAP_COMMON_HLP_FAILURE_H_ */

/*
 * Proc.c
 *
 *  Created on: Apr 16, 2020
 *      Author: knuth
 */

#include "wrap/common/Hlp/Proc.h"

#include "cmocka.h"

extern bool __wrap_HlpProc_AlwaysTrue(void)
{
  return (bool) mock();         /* dequeue second value */
}

extern logd_t *  __wrap_HlpProcVar_GetLogd(void)
{
  function_called();
  return 0;
}

extern sc_pid_t __wrap_HlpProc_GetCurrentPid(void)
{
  return (sc_pid_t) mock();
}

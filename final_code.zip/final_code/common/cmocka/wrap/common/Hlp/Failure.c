/*
 * hlp.c
 *
 *  Created on: Apr 16, 2020
 *      Author: knuth
 */

#include "wrap/common/Hlp/Failure.h"

void __wrap_HlpFailure_EndlessLoopBusy(void)
{
  function_called();
}

extern void __wrap_HlpFailure_EndlessLoop(void)
{
  function_called();
}

extern void __wrap_HlpMsg_AssertSentFatal_f(logd_t * logd, sc_msg_t * pm,
                                            const char * file, int line,
                                            const char * func)
{
  function_called();
}

/*
 * Msg.h
 *
 *  Created on: Apr 16, 2020
 *      Author: knuth
 */

#ifndef CMOCKA_WRAP_COMMON_HLP_MSG_H_
#define CMOCKA_WRAP_COMMON_HLP_MSG_H_

#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <stdint.h>

#include "cmocka.h"

#include <sciopta_sc.h>
#include <logd/logd.h>

void  __wrap_HlpMsg_Unexpected(logd_t * logd, sc_msg_t * pm);

extern void __wrap_HlpMsg_AssertSent_f(logd_t * logd, sc_msg_t * pm,
                                       const char * file, int line,
                                       const char * func);
#endif /* CMOCKA_WRAP_COMMON_HLP_MSG_H_ */

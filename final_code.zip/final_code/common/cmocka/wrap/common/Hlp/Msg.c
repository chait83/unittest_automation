/*
 * Msg.c
 *
 *  Created on: Apr 16, 2020
 *      Author: knuth
 */

#include "wrap/common/Hlp/Msg.h"

#include "cmocka.h"

void  __wrap_HlpMsg_Unexpected(logd_t * logd, sc_msg_t * pm)
{
  function_called();
}

extern void __wrap_HlpMsg_AssertSent_f(logd_t * logd, sc_msg_t * pm,
                                       const char * file, int line,
                                       const char * func)
{

}

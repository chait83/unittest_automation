/*
 * Sciopta.h
 *
 *  Created on: Apr 16, 2020
 *      Author: knuth
 */

#ifndef CMOCKA_WRAP_SCIOPTA_H_
#define CMOCKA_WRAP_SCIOPTA_H_

#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <stdint.h>

#include "cmocka.h"

#include <Sciopta_sc.h>


//! @brief Possible Sciopta kernel errors based on Sciopta reference manual
//!
//! @details
//!   The prefix INJECT_ is used to prevent a confusion with the real Sciopta errors
enum InjectScioptaError
{
  INJECT_NO_ERROR,       //!< No fault shall be triggered
  // Real kernel errors
  INJECT_KERNEL_EOUT_OF_MEMORY, //!< Request for number of bytes could not be fulfilled.
  INJECT_KERNEL_EILL_PID,       //!< Addressee pid not valid
  // Other
  INJECT_TIMEOUT                //!< A timeout is injected
};
typedef enum InjectScioptaError InjectScioptaError_E;


//! @brief Free a Sciopta message
//!
//! @param[in] sc_msg_t Sciopta message pointer
//!
//! @details
//!   The c-library function #free is used here.
//!   An assert is triggered, when sc_msg_t is NULL.
extern void __wrap___sc_msgFree(sc_msg_t* pMsg);

//! @brief Helper for #__wrap___sc_msgAlloc
//!
//! @param[in] injectError   defines the injected failure
//!
//! If error #INJECT_KERNEL_EOUT_OF_MEMORY is used, NULL pointer will be provided by #__wrap___sc_msgRx.
extern void sc_msgAlloc_will_return(InjectScioptaError_E injectError);

//! @brief Wrapper for __sc_msgAlloc
//!
//! @param[in] size of the Sciopta message
//! @param[in] msgid of the Sciopta message
//! @param[in] poolid not used.
//! @param[in] ticks not used.
//!
//! @details
//!  For correct mocking, see sc_msgAlloc_will_return for details.
//!   The c-library function #calloc is used here.
//!   A Sciopta message is return with the #msgid already assigned.
extern sc_msg_t __wrap___sc_msgAlloc(size_t size, sc_msgid_t msgid, sc_poolid_t poolid, sc_ticks_t ticks);

//! @brief Helper for #__wrap___sc_msgRx
//!
//! @param[in] injectError defines the injected failure
//! @param[in] sc_msg_t Sciopta message to be provided
//!
//! If error #INJECT_TIMEOUT is used, NULL pointer will be provided by #__wrap___sc_msgRx.
extern void sc_msgRx_will_return(InjectScioptaError_E injectError, sc_msg_t sc_msg);

//! @brief Wrapper for __sc_msgRx
//!
//! @param[in] tmo Timeout, not used
//! @param[in] wanted messages, not used
//! @param[in] flags Sciopta flags, not used.
//!
//! @details
//!  For correct mocking, see sc_msgRx_will_return for details.
extern sc_msg_t __wrap___sc_msgRx(const sc_ticks_t tmo, void* wanted, int flags);

//! @brief Helper for #__wrap___sc_msgTx
//!
//! @param[in] injectError   defines the injected failure
//! @param[in] expectedScMsg expected message, that shall be send
//! @param[in] expectedScMsgSize  size of the expected message
//! @param[in] expectedPid     expected PID of the target process
//!
//! If error #INJECT_KERNEL_EILL_PID is used, the original message will be returned (i.e. *ptr is not freed) by #__wrap___sc_msgRx.
extern void sc_msgTx_will_return(InjectScioptaError_E injectError, sc_msg_t expectedScMsg, size_t expectedScMsgSize, sc_pid_t expectedPid);

//! @brief Wrapper for __sc_msgTx
//!
//! @param[in] ptr Sciopta message pointer
//! @param[in] pid PID of the target
//! @param[in] flags Sciopta flags.
//!
//! @details
//!  For correct mocking, see sc_msgRx_will_return for details.
//!  According to the #flags, the message will be returned (i.e. *pm is not freed) in case of failure.
//!  Assertion are triggered in case of
//!    * the #pid is not the expected #pid
//!    * #ptr is null
//!    * #flags contains invalid flags
//!    * the provided message via #ptr is not the expected messages
extern void __wrap___sc_msgTx(sc_msgptr_t ptr, sc_pid_t pid, sc_msgTxFlags_t flags);

extern void __wrap___sc_procYield(void);

extern sc_pid_t __wrap___sc_procIdGet();

extern sc_msg_t __wrap___sc_procNameGet(sc_pid_t pid);

extern sc_ticks_t __wrap___sc_sleep(sc_ticks_t interval);

#endif /* CMOCKA_WRAP_SCIOPTA_H_ */


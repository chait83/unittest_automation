#include "wrap/sciopta.h"
#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include <stdbool.h>
#include <stdarg.h>

static const bool doPrint = false;


union sc_msg
{
  sc_msgid_t  scMsgId;
};


static void print(const bool doPrint, const char *format, ...)
{
  if (doPrint)
  {
    va_list argptr;
    va_start(argptr, format);
    (void)vprintf_s(format, argptr);
    va_end(argptr);
  }
}


extern void __wrap___sc_msgFree(sc_msg_t* pMsg)
{
  if (*pMsg != NULL)
  {
    print(doPrint, "Freeing message with msgId = 0x%X at 0x%p\n", (*pMsg)->scMsgId, *pMsg);
  }
  else
  {
    print(doPrint, "Attempting to free message NULL pointer\n");
  }
  function_called();

  assert_non_null(pMsg);
  assert_non_null(*pMsg);

  free(*pMsg);
  *pMsg = NULL;
}

extern void sc_msgAlloc_will_return(InjectScioptaError_E injectError)
{
  will_return(__wrap___sc_msgAlloc, injectError);
}

extern sc_msg_t __wrap___sc_msgAlloc(size_t size, sc_msgid_t msgid, sc_poolid_t poolid, sc_ticks_t ticks)
{
  sc_msg_t scMsg = NULL;

  const InjectScioptaError_E  scioptaError = mock();

  switch (scioptaError)
  {
    case INJECT_KERNEL_EOUT_OF_MEMORY:
      scMsg = NULL;
      break;
    case INJECT_NO_ERROR:
      scMsg = (sc_msg_t) calloc(1, size);
      if (scMsg != NULL)
      {
        print(doPrint, "Allocating message with msgId = 0x%X at 0x%p\n", msgid, scMsg);
      }
      else
      {
        print(doPrint, "Failed to allocate message with msgId = 0x%X\n", msgid);
      }
      assert_non_null (scMsg);
      scMsg->scMsgId = msgid;
      break;
    default:
      fail_msg ("%s: unknown error-injection %d", __func__, (int) scioptaError);
      break;
  }

  return scMsg;
}

extern void sc_msgRx_will_return(InjectScioptaError_E injectError, sc_msg_t sc_msg)
{
  will_return(__wrap___sc_msgRx, injectError);
  will_return(__wrap___sc_msgRx, sc_msg);
}

extern sc_msg_t __wrap___sc_msgRx(const sc_ticks_t tmo, void* wanted, int flags)
{
  const InjectScioptaError_E  scioptaError = mock();

  sc_msg_t scMsg = NULL;

  switch (scioptaError)
  {
    case INJECT_TIMEOUT:
      (void) mock();
      break;
    case INJECT_NO_ERROR:
      scMsg = (sc_msg_t) mock();
      if (scMsg != NULL)
      {
        print(doPrint, "Received message with msgId = 0x%X at 0x%p\n", scMsg->scMsgId, scMsg);
      }
      else
      {
        print(doPrint, "Received message NULL pointer\n");
      }
      break;
    default:
      fail_msg ("%s: unknown error-injection %d", __func__, (int) scioptaError);
      break;
  }

  return scMsg;
}

extern void sc_msgTx_will_return(InjectScioptaError_E injectError, sc_msg_t expectedScMsg, size_t expectedScMsgSize, sc_pid_t expectedPid)
{
  will_return(__wrap___sc_msgTx, injectError);
  will_return(__wrap___sc_msgTx, expectedScMsg);
  will_return(__wrap___sc_msgTx, expectedScMsgSize);
  will_return(__wrap___sc_msgTx, expectedPid);
}

extern void __wrap___sc_msgTx(sc_msgptr_t ptr, sc_pid_t pid, sc_msgTxFlags_t flags)
{
  function_called();

  const InjectScioptaError_E  scioptaError = (InjectScioptaError_E) mock();
  const sc_msg_t  expectedScMsg = (sc_msg_t) mock();
  const size_t    expectedScMsgSize = (size_t) mock();
  const sc_pid_t  expectedPid = (sc_pid_t) mock();

  assert_non_null (ptr);

  assert_true( (flags == 0) || (flags == SC_MSGTX_RTN2SND));
  assert_true( pid == expectedPid);
  if (expectedScMsgSize > 0)
  {
    assert_non_null (expectedScMsg);
    assert_memory_equal(expectedScMsg, *ptr, expectedScMsgSize);
  }

  if (flags == SC_MSGTX_RTN2SND)
  {
    switch (scioptaError)
    {
      case INJECT_KERNEL_EILL_PID:
        // Message cannot be delivered to the destination process -> return the message to the sender by not freeing it
        if (*ptr != NULL)
        {
          print(doPrint, "Sending message with msgId = 0x%X at 0x%p failed because the destination process does not exist\n", (*ptr)->scMsgId, *ptr);
        }
        else
        {
          print(doPrint, "Attempting to send NULL pointer message supposed to fail because the destination process does not exist\n");
        }
        break;
      case INJECT_NO_ERROR:
        // Message will not be returned in case of failure
        if (*ptr != NULL)
        {
          print(doPrint, "Sending message with msgId = 0x%X at 0x%p\n", (*ptr)->scMsgId, *ptr);
        }
        else
        {
          print(doPrint, "Attempting to send NULL pointer message\n");
        }
        free(*ptr);
        *ptr = NULL;
        break;
      default:
        printf ("%s: unknown error-injection %d\n", __func__, (int) scioptaError);
        assert_true (false);
        break;
    }
  }
  else if (flags == 0)
  {
    // If flag is not SC_MSGTX_RTN2SND, message is never returned, also in case of failure
    free(*ptr);
    *ptr = NULL;
  }
}

extern void __wrap___sc_procYield(void)
{

}

sc_pid_t __wrap___sc_procIdGet()
{
  function_called();
  return (sc_pid_t) mock();
}

extern sc_msg_t __wrap___sc_procNameGet(sc_pid_t pid)
{
  return (sc_msg_t) mock();
}

extern sc_ticks_t __wrap___sc_sleep(sc_ticks_t interval)
{
  function_called();
  return (sc_ticks_t) 0;
}

extern sc_msg_t __wrap___sc_procPathGet(sc_pid_t pid, flags_t flags)
{
  return (sc_msg_t) mock();
}


#!/bin/bash

## get the absolute path ... in Windows-style (D:\...)
CURR_PATH=$(cygpath --windows "${PWD}")
## remove "\sub\common\cmocka\TRACE32" from absolute path to get to project path
PROJ_PATH=`echo $CURR_PATH | cut -d '\' -f -4`

## replace '\' with '\\' for passing as parameter into TRACE32 PPC simulator
PROJ_PATH=`echo "${PROJ_PATH//'\'/'\\'}"`
## setup the paths needed for later
TEST_COMMON_PATH=${PROJ_PATH}\\build\\tests_diab\\sub\\common\\cmocka\\src\\common\\
TEST_PCB_PATH=${PROJ_PATH}\\build\\tests_diab\\cmocka\\src\\pcb\\
RESULTS_PATH=${PROJ_PATH}\\build\\tests_diab\\testresults\\

## replace '\\' with '/' for executing commands in Git Bash
PROJ_PATH=`echo "${PROJ_PATH//'\\'/'/'}"`
## clean and build the production code for unit tests using Diab for PPC
cd ${PROJ_PATH}
make -f MakefileCmockaDiab --no-builtin-rules --no-builtin-variables clean
make -f MakefileCmockaDiab --no-builtin-rules --no-builtin-variables all
## switch back to location of TRACE32 PPC simulator
cd ${PROJ_PATH}"/sub/common/cmocka/TRACE32"

## make the "testresults" directory for storring XML results
mkdir -p ${PROJ_PATH}/build/tests_diab/testresults


echo ""
echo "*************************************************"
echo "* Run PCB unit tests - Cmocka using Diab on PPC *"
echo "*************************************************"
FILE=${PROJ_PATH}"/cmocka/tests_pcb.mk"
while IFS= read -r LINE
do
  TEST=`echo "${LINE//'TESTS_PCB_SRC  += src/pcb/'/''}"`
  TEST=`echo "${TEST//'/'/'\'}"`
  TEST=`echo "${TEST//'.c'/'_test.elf'}"`
  RESULTS=`echo "${LINE//'TESTS_PCB_SRC  += '/''}"`
  RESULTS=`echo "${RESULTS//'/'/'_'}"`
  RESULTS=`echo "${RESULTS//'.c'/'_test.xml'}"`
  echo ${TEST_PCB_PATH}${TEST} "-->" ${RESULTS_PATH}${RESULTS}
  ./t32mppc.exe -s gen360.cmm ${TEST_PCB_PATH}${TEST} ${RESULTS_PATH}${RESULTS}
done < "$FILE"


echo ""
echo "****************************************************"
echo "* Run Common unit tests - Cmocka using Diab on PPC *"
echo "****************************************************"
FILE=${PROJ_PATH}"/sub/common/cmocka/tests.mk"
while IFS= read -r LINE
do
  TEST=`echo "${LINE//'TESTS_SRC  += src/common/'/''}"`
  TEST=`echo "${TEST//'/'/'\'}"`
  TEST=`echo "${TEST//'.c'/'_test.elf'}"`
  RESULTS=`echo "${LINE//'TESTS_SRC  += '/''}"`
  RESULTS=`echo "${RESULTS//'/'/'_'}"`
  RESULTS=`echo "${RESULTS//'.c'/'_test.xml'}"`
  echo ${TEST_COMMON_PATH}${TEST} "-->" ${RESULTS_PATH}"build_tests_sub_common_cmocka_"${RESULTS}
  ./t32mppc.exe -s gen360.cmm ${TEST_COMMON_PATH}${TEST} ${RESULTS_PATH}"build_tests_sub_common_cmocka_"${RESULTS}
done < "$FILE"

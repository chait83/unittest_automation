// =======================================================================================
// Copyright 2021 OTIS GmbH & Co OHG - Lead Design Center Berlin
// =======================================================================================
//
//! @file
//!
//! @brief CMOCKA tests for SafetyCanProtocol.c
//
// =======================================================================================


#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include "cmocka.h"

#include "Crc.h"
#include "Cfg/Crc.h"
#include "CanSched/Types.h"
#include "Hlp/Types.h"
#include "SafetyCanProtocol/SafetyCanProtocol.h"
#include "ossys/types.h"


// =======================================================================================
//! @brief Constants defined in SafetyCanProtocol.c
// =======================================================================================


static const ssize_t  protocolLen                 = 8;            //!< The safety protocol has always a length of 8 bytes.
static const uint32_t safetyProtocol_CrcSeed      = 0xFFFFFFFFU;  //!< CRC32 seed for the safety protocol.


// =======================================================================================
//! @brief Constants
// =======================================================================================


const CanSchedTypes_CanMsg_S msgValid = {
                                          .protocol = CanSchedTypes_PROTOCOL_EXTENDED,
                                          .canId    = 0,
                                          .dataLen  = 8, // protocolLen would produce error: initializer element is not constant
                                          .data.u64 = {0ULL}
                                        };


// =======================================================================================
//! @brief Forward declarations
// =======================================================================================


static void Crc_Get_will_return(const uint32_t crc32Dummy);


// =======================================================================================
//! @brief Helper functions for setting components in the Safety CAN Protocol frame
//
//        0             1             2             3             4            5              6             7
// +-------------+-------------+-------------+-------------+-------------+-------------+-------------+-------------+
// | CRC0 (LSB)  |    Data2    |    CRC1     | Data0 (LSB) | Data3 (MSB) | CRC3 (MSB)  |    Data1    |    CRC2     |
// +-------------+-------------+-------------+-------------+-------------+-------------+-------------+-------------+
// =======================================================================================


// Set data in Safety CAN Protocol frame
static void setSafetyCanProtocolFrameData(CanSchedTypes_CanMsg_S* const pMsg, const uint32_t data)
{
  pMsg->data.u8[1] = HlpTypes_GetUint32Uint8Significance2(data);
  pMsg->data.u8[3] = HlpTypes_GetUint32Uint8Significance0(data);
  pMsg->data.u8[4] = HlpTypes_GetUint32Uint8Significance3(data);
  pMsg->data.u8[6] = HlpTypes_GetUint32Uint8Significance1(data);
}


// Set CRC in Safety CAN Protocol frame
static void setSafetyCanProtocolFrameCrc(CanSchedTypes_CanMsg_S* const pMsg, const uint32_t crc)
{
  pMsg->data.u8[0] = HlpTypes_GetUint32Uint8Significance0(crc);
  pMsg->data.u8[2] = HlpTypes_GetUint32Uint8Significance1(crc);
  pMsg->data.u8[5] = HlpTypes_GetUint32Uint8Significance3(crc);
  pMsg->data.u8[7] = HlpTypes_GetUint32Uint8Significance2(crc);
}


// Set sequenceCounter in Safety CAN Protocol frame
static void setSafetyCanProtocolFrameSequenceCounter(CanSchedTypes_CanMsg_S* const pMsg, const uint8_t sequenceCounter)
{
  pMsg->data.u8[4] &= 0x1F;                 // Enforce SequenceCounter is cleared before setting it
  pMsg->data.u8[4] |= sequenceCounter << 5; // Set sequenceCounter
}


// =======================================================================================
//! @brief Test functions for SafetyCanProtocol_WrapNodeOriented
// =======================================================================================


// CAN message pointer is NULL
static void test_SafetyCanProtocol_WrapNodeOriented_CanMsgPointerNull(void** state)
{
  uint8_t sequenceCounter = 0;

  assert_false(SafetyCanProtocol_WrapNodeOriented(NULL, &sequenceCounter));
}


// Sequence counter pointer is NULL
static void test_SafetyCanProtocol_WrapNodeOriented_SequenceCounterPointerNull(void** state)
{
  CanSchedTypes_CanMsg_S msg = msgValid;

  assert_false(SafetyCanProtocol_WrapNodeOriented(&msg, NULL));
}


// CAN identifier has only 11 bits
static void test_SafetyCanProtocol_WrapNodeOriented_InvalidCanIdentifierProtocol(void** state)
{
  CanSchedTypes_CanMsg_S msg = msgValid;
  uint8_t                sequenceCounter = 0;

  msg.protocol = CanSchedTypes_PROTOCOL_STANDARD; // Invalid CAN identifier format

  assert_false(SafetyCanProtocol_WrapNodeOriented(&msg, &sequenceCounter));
}


// CAN identifier is invalid
static void test_SafetyCanProtocol_WrapNodeOriented_InvalidCanIdentifierValue(void** state)
{
  CanSchedTypes_CanMsg_S msg = msgValid;
  uint8_t                sequenceCounter = 0;

  msg.canId = 1U << 29; // Invalid CAN identifier value (does not fit into 29 bits)

  assert_false(SafetyCanProtocol_WrapNodeOriented(&msg, &sequenceCounter));
}


// CAN data length is != 8
static void test_SafetyCanProtocol_WrapNodeOriented_InvalidCanDataLength(void** state)
{
  CanSchedTypes_CanMsg_S msg = msgValid;
  uint8_t                sequenceCounter = 0;

  msg.dataLen = protocolLen - 1U; // Invalid CAN data length

  assert_false(SafetyCanProtocol_WrapNodeOriented(&msg, &sequenceCounter));
}


// The CRC32 is not calculated. A dummy is used instead.
static void helperWrapNodeOriented(const uint32_t data, const uint32_t crc32Dummy, const uint8_t sequenceCounterInput)
{
  CanSchedTypes_CanMsg_S msg = msgValid;
  CanSchedTypes_CanMsg_S msgExpected;
  uint8_t                sequenceCounter = sequenceCounterInput;
  size_t                 i;

  // Message to be passed to SafetyCanProtocol_WrapNodeOriented (input)
  setSafetyCanProtocolFrameData(&msg, data);

  // Expected message after calling SafetyCanProtocol_WrapNodeOriented (output)
  msgExpected = msg;
  setSafetyCanProtocolFrameSequenceCounter(&msgExpected, (sequenceCounterInput + 1) % 8);
  setSafetyCanProtocolFrameCrc(&msgExpected, crc32Dummy);

  // Call SafetyCanProtocol_WrapNodeOriented and verify output
  expect_function_call(__wrap_Crc_Init);
  expect_function_calls(__wrap_Crc_AddUint32, 2);
  Crc_Get_will_return(crc32Dummy);

  assert_true(SafetyCanProtocol_WrapNodeOriented(&msg, &sequenceCounter));
  assert_true(sequenceCounter == ((sequenceCounterInput + 1) % 8));
  for (i = 0; i < protocolLen; i++)
  {
    assert_true(msg.data.u8[i] == msgExpected.data.u8[i]);
  }
}


// Normal
static void test_SafetyCanProtocol_WrapNodeOriented_Normal(void** state)
{
  struct
  {
    uint32_t data;
    uint32_t crc32Dummy;
  } list[] = {
               {.data = 0x01234567, .crc32Dummy = 0x89ABCDEF},
               {.data = 0x12345678, .crc32Dummy = 0x9ABCDEF0},
               {.data = 0x23456789, .crc32Dummy = 0xABCDEF01},
               {.data = 0x34567890, .crc32Dummy = 0xBCDEF012}
             };
  uint8_t sequenceCounter;
  size_t i;

  for (i = 0; i < sizeof(list)/sizeof(list[0]); i++)
  {
    for (sequenceCounter = 0; sequenceCounter < protocolLen; sequenceCounter++)
    {
      helperWrapNodeOriented(list[i].data, list[i].crc32Dummy, sequenceCounter);
    }
  }
}


// =======================================================================================
//! @brief Test functions for SafetyCanProtocol_Verify
// =======================================================================================


// CAN message pointer is NULL
static void test_SafetyCanProtocol_Verify_CanMsgPointerNull(void** state)
{
  uint8_t sequenceCounterOld = 0;

  assert_false(SafetyCanProtocol_Verify(NULL, &sequenceCounterOld));
}


// Previous sequence counter pointer is NULL
static void test_SafetyCanProtocol_Verify_SequenceCounterOldPointerNull(void** state)
{
  CanSchedTypes_CanMsg_S msg = msgValid;

  assert_false(SafetyCanProtocol_Verify(&msg, NULL));
}


// CAN identifier has only 11 bits
static void test_SafetyCanProtocol_Verify_InvalidCanIdentifierProtocol(void** state)
{
  CanSchedTypes_CanMsg_S msg = msgValid;
  uint8_t                sequenceCounterOld = 0;

  msg.protocol = CanSchedTypes_PROTOCOL_STANDARD; // Invalid CAN identifier format

  assert_false(SafetyCanProtocol_Verify(&msg, &sequenceCounterOld));
}


// CAN identifier is invalid
static void test_SafetyCanProtocol_Verify_InvalidCanIdentifierValue(void** state)
{
  CanSchedTypes_CanMsg_S msg = msgValid;
  uint8_t                sequenceCounterOld = 0;

  msg.canId = 1U << 29; // Invalid CAN identifier value (does not fit into 29 bits)

  assert_false(SafetyCanProtocol_Verify(&msg, &sequenceCounterOld));
}


// CAN data length is != 8
static void test_SafetyCanProtocol_Verify_InvalidCanDataLength(void** state)
{
  CanSchedTypes_CanMsg_S msg = msgValid;
  uint8_t                sequenceCounterOld = 0;

  msg.dataLen = protocolLen - 1U; // Invalid CAN data length

  assert_false(SafetyCanProtocol_Verify(&msg, &sequenceCounterOld));
}


// The CRC32 is not calculated. Two dummies are used instead:
//   - crc32DummyInMsg    - CRC embedded in message
//   - crc32DummyExpected - CRC that would be "calculated" from the message
static void helperVerify(const uint32_t data,
                         const uint32_t crc32DummyInMsg,
                         const uint32_t crc32DummyExpected,
                               uint8_t  sequenceCounterOld,
                         const uint8_t  sequenceCounter,
                         const bool     verifyIsExpectedToReturnTrue)
{
  CanSchedTypes_CanMsg_S msg = msgValid;

  // printf("\ncrc32DummyInMsg = 0x%08X, crc32DummyExpected = 0x%08X, sequenceCounterOld = %u, sequenceCounter = %u, verifyIsExpectedToReturnTrue = %u\n",
  //        crc32DummyInMsg,
  //        crc32DummyExpected,
  //        sequenceCounterOld,
  //        sequenceCounter,
  //        verifyIsExpectedToReturnTrue);

  setSafetyCanProtocolFrameData(&msg, data);
  setSafetyCanProtocolFrameCrc(&msg, crc32DummyInMsg);
  setSafetyCanProtocolFrameSequenceCounter(&msg, sequenceCounter);

  expect_function_call(__wrap_Crc_Init);
  expect_function_calls(__wrap_Crc_AddUint32, 2);
  Crc_Get_will_return(crc32DummyExpected);

  if (verifyIsExpectedToReturnTrue)
  {
    assert_true(SafetyCanProtocol_Verify(&msg, &sequenceCounterOld));
  }
  else
  {
    assert_false(SafetyCanProtocol_Verify(&msg, &sequenceCounterOld));
  }
}


// Normal
static void test_SafetyCanProtocol_Verify_Normal(void** state)
{
  struct
  {
    uint32_t data;
    uint32_t crc32Dummy;
  } list[] = {
               {.data = 0x01234567, .crc32Dummy = 0x89ABCDEF},
               {.data = 0x12345678, .crc32Dummy = 0x9ABCDEF0},
               {.data = 0x23456789, .crc32Dummy = 0xABCDEF01},
               {.data = 0x34567890, .crc32Dummy = 0xBCDEF012}
             };
  uint8_t sequenceCounterOld;
  size_t i;

  for (i = 0; i < sizeof(list)/sizeof(list[0]); i++)
  {
    for (sequenceCounterOld = 0; sequenceCounterOld < protocolLen; sequenceCounterOld++)
    {
      uint8_t sequenceCounter = (sequenceCounterOld + 1) % 8;

      // Matching CRC and sequence counter -> pass
      helperVerify(list[i].data, list[i].crc32Dummy, list[i].crc32Dummy,     sequenceCounterOld, sequenceCounter, true);

      // Mismatching CRC -> fail
      helperVerify(list[i].data, list[i].crc32Dummy, list[i].crc32Dummy + 1, sequenceCounterOld, sequenceCounter, false);

      // Mismatching sequenceCounter (repeating the previous one) -> fail
      helperVerify(list[i].data, list[i].crc32Dummy, list[i].crc32Dummy,     sequenceCounterOld, sequenceCounterOld, false);
    }
  }
}


int main(void)
{
  int retval = 0;
  
#ifdef CMOCKA_DIAB
  putenv("CMOCKA_XML_FILE=src_common_SafetyCanProtocol_SafetyCanProtocol.xml"); // environment variable for XML file when running on PPC
#endif

  const struct CMUnitTest tests[] =
  {
    cmocka_unit_test(test_SafetyCanProtocol_WrapNodeOriented_CanMsgPointerNull),
    cmocka_unit_test(test_SafetyCanProtocol_WrapNodeOriented_SequenceCounterPointerNull),
    cmocka_unit_test(test_SafetyCanProtocol_WrapNodeOriented_InvalidCanIdentifierProtocol),
    cmocka_unit_test(test_SafetyCanProtocol_WrapNodeOriented_InvalidCanIdentifierValue),
    cmocka_unit_test(test_SafetyCanProtocol_WrapNodeOriented_InvalidCanDataLength),
    cmocka_unit_test(test_SafetyCanProtocol_WrapNodeOriented_Normal),
    cmocka_unit_test(test_SafetyCanProtocol_Verify_CanMsgPointerNull),
    cmocka_unit_test(test_SafetyCanProtocol_Verify_SequenceCounterOldPointerNull),
    cmocka_unit_test(test_SafetyCanProtocol_Verify_InvalidCanIdentifierProtocol),
    cmocka_unit_test(test_SafetyCanProtocol_Verify_InvalidCanIdentifierValue),
    cmocka_unit_test(test_SafetyCanProtocol_Verify_InvalidCanDataLength),
    cmocka_unit_test(test_SafetyCanProtocol_Verify_Normal)
  };

  cmocka_set_message_output(CM_OUTPUT_XML);

  retval = cmocka_run_group_tests_name("src_common_SafetyCanProtocol_SafetyCanProtocol", tests, NULL, NULL);
  
#ifdef CMOCKA_DIAB
  read_xml_file("src_common_SafetyCanProtocol_SafetyCanProtocol.xml"); // extract XML test results from file in RAM when running on PPC
#endif

  return retval;
}


// =======================================================================================
//! @brief Stub functions
// =======================================================================================


extern void __wrap_Crc_Init(const Crc_Unit_E cu, const Crc_Type_E ct,
                            const uint8_t sw, const uint8_t swby, const uint8_t swbi, const uint8_t inv,
                            const uint32_t seed)
{
  // Check whether Crc_Init is called with the proper parameters for the Safety CAN Protocol
  assert_true(cu   == CFGCRC_UNIT_SAFETY_PROCESS);
  assert_true(ct   == Crc_TYPE_CRC32);
  assert_true(sw   == 1);
  assert_true(swby == 1);
  assert_true(swbi == 0);
  assert_true(inv  == 1);
  assert_true(seed == safetyProtocol_CrcSeed);

  function_called();
}


extern void __wrap_Crc_AddUint32(const Crc_Unit_E cu, const uint32_t byte4)
{
  // Check whether Crc_AddUint32 is called with the proper CRC unit for the Safety CAN Protocol
  assert_true(cu == CFGCRC_UNIT_SAFETY_PROCESS);

  function_called();
}


static void Crc_Get_will_return(const uint32_t crc32Dummy)
{
  will_return(__wrap_Crc_Get, crc32Dummy);
  expect_function_call(__wrap_Crc_Get);
}


extern uint32_t __wrap_Crc_Get(const Crc_Unit_E cu)
{
  // Check whether Crc_Get is called with the proper CRC unit for the Safety CAN Protocol
  assert_true(cu == CFGCRC_UNIT_SAFETY_PROCESS);

  function_called();

  return (uint32_t)mock();
}




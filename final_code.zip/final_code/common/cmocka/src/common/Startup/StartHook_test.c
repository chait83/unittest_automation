// *****************************************************************************
// **                _______   _________  _________   _______                 **
// **               (  ___  )  \__   __/  \__   __/  (  ____ \                **
// **               | (   ) |     ) (        ) (     | (    \/                **
// **               | |   | |     | |        | |     | (_____                 **
// **               | |   | |     | |        | |     (_____  )                **
// **               | |   | |     | |        | |           ) |                **
// **               | (___) |     | |     ___) (___  /\____) |                **
// **               (_______)     )_(     \_______/  \_______)                **
// **                                                                         **
// **                        Lead Design Center Berlin                        **
// **                                                                         **
// **   Copyright 2021 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **
// **                                                                         **
// *****************************************************************************
//!
//! @file
//!
//! @brief cmocka test file for src/common/Startup/StartHook.c
//!
// *****************************************************************************
#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <stdint.h>
#include <stdio.h>
#include <stdarg.h>

#include "cmocka.h"
#include "ScnType.h"
#include "LinkDateTime.h"
#include "Cfg/BuildType.h"
#include "mpc5744p.h"

#include "Safety/SafetyLib/inc/SafetyLibTestManager.h"
#include <stdbool.h>
#include "Startup/StartHook.h"

const char LinkInfo_User[64]     = "Developer";
const char LinkInfo_Computer[64] = "Computer";

const char* const  LinkDateTime_Date = __DATE__;
const char* const  LinkDateTime_Time = __TIME__;

const char CfgGit_Hash[64]   = "123456";
const bool CfgGit_HasChanged = false;
const char CfgGit_Head[256]  = "HEAD";

const char * CfgPcb_PcbDescription = "CMOCKA";

volatile struct INTC_tag INTC_register = {};

const union ScnType_Scn CfgScn_BoardScn =
{
  .part = { .country = "G", .releaseType = "00", .baseline = "00000", .releaseVersion = "123", .postfix = "     ", .terminator = "\0" }
  // required sizes:   "?"                 "??"              "?????"                    "???"             "?????"             DONT CHANGE
  //        example:   "G"                 "P1"              "12345"                    "AAA"             "+HL01"
};

const CfgBuildType_E CfgBuildType = CfgBuildType_AutomaticBuild;

static void test_start_hook_stack_safe(void** state)
{
  start_hook_stack_safe();
	(void) state;
}

int main(void)
{
    int retval = 0;
    
#ifdef CMOCKA_DIAB
    putenv("CMOCKA_XML_FILE=src_common_Startup_StartHook.xml"); // environment variable for XML file when running on PPC
#endif
    
    const struct CMUnitTest tests[] =
    {
        cmocka_unit_test(test_start_hook_stack_safe),
    };

    cmocka_set_message_output(CM_OUTPUT_XML);

    retval = cmocka_run_group_tests_name("src_common_Startup_StartHook", tests, NULL, NULL);
    
#ifdef CMOCKA_DIAB
    read_xml_file("src_common_Startup_StartHook.xml"); // extract XML test results from file in RAM when running on PPC
#endif
    
    return retval;
}

void __wrap___putchar(const char c)
{
  (void) printf("%c",c);
}

void __wrap_uart_init(void){};

void __wrap_ErrorHook_ErrorHook(void){};

void __wrap_xsc_miscErrorHookRegister(void){};
void __wrap_sTestManager_Config(TmState_E state){};
void __wrap_sTestHandler_Run(TmState_E state){};
void __wrap_Sciopta_SwapHook(void){};
void __wrap_xsc_procHookRegister(void){};
void __wrap_StartupRegProt_InitializeRegProt(void){};
void __wrap_sc_procAttrGet(void){};

#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <stdint.h>

#include "cmocka.h"

#include "Startup/BoardId.h"

#include "mpc5744p.h"

volatile struct SIUL2_tag SIUL2_register = {};

static void test_StartupBoardId_Read(void** state)
{
  size_t pad;


  for (pad = 0; pad < 154 ; pad ++)
  {
    SIUL2.GPDI[pad+0].B.PDI = 0;
    SIUL2.GPDI[pad+1].B.PDI = 1;
    SIUL2.GPDI[pad+2].B.PDI = 0;

    assert_int_equal(StartupBoardId_Read(pad+0,pad+1,pad+2), 2);
  }

  (void) state;

}

int main(void)
{
    int retval = 0;
	
#ifdef CMOCKA_DIAB
    putenv("CMOCKA_XML_FILE=src_common_startup_BoardId.xml"); // environment variable for XML file when running on PPC
#endif

    const struct CMUnitTest tests[] =
    {
        cmocka_unit_test(test_StartupBoardId_Read),
    };

	  cmocka_set_message_output(CM_OUTPUT_XML);

    retval =  cmocka_run_group_tests_name("src_common_startup_BoardId", tests, NULL, NULL);
	
#ifdef CMOCKA_DIAB
    read_xml_file("src_common_startup_BoardId.xml"); // extract XML test results from file in RAM when running on PPC
#endif

    return retval;
}

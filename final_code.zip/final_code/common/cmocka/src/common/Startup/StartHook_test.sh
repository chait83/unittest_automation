#!/bin/bash
STUBS+=("uart_init")
STUBS+=("ErrorHook_ErrorHook")
STUBS+=("__putchar")
STUBS+=("sTestManager_Config")
STUBS+=("xsc_miscErrorHookRegister")
STUBS+=("sTestHandler_Run")
STUBS+=("Sciopta_SwapHook")
STUBS+=("xsc_procHookRegister")
STUBS+=("StartupRegProt_InitializeRegProt")
STUBS+=("sc_procAttrGet")

STUB_WRAPS=${STUBS[@]/#/\-Wl,$2} # Diab wrap option syntax is different than GNU so pass in as parameter from make file

LINK+=("sub/subcommon/sub/sciopta/util/logd/kprintf.o")

LINK_OBJECT=${LINK[@]/#/$1}

shift 2

$* $LINK_OBJECT $STUB_WRAPS

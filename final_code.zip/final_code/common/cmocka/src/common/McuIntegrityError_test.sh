#!/bin/bash

STUBS+=("kprintf")
STUBS+=("logd_printf")
STUBS+=("__sc_msgTx")
STUBS+=("__sc_procNameGet")
STUBS+=("__sc_procIdGet")
STUBS+=("__sc_msgAlloc")
STUBS+=("__sc_msgFree")
STUBS+=("HlpFailure_EndlessLoopBusy")
STUBS+=("Fccu_ProcessFaults")
STUBS+=("EepromEProc_ProcessFaults")
STUBS+=("SafetyLibApi_ProcessFaults")
STUBS+=("ProcSafetyIntegrity_SbcReset")
#STUBS+=("")

STUB_WRAPS=${STUBS[@]/#/\-Wl,$2} # Diab wrap option syntax is different than GNU so pass in as parameter from make file

LINK+=("cmocka/wrap/sciopta.o")
LINK+=("cmocka/wrap/common/Hlp/Failure.o")
#LINK+=("")

LINK_OBJECT=${LINK[@]/#/$1}

shift 2

$* $LINK_OBJECT $STUB_WRAPS

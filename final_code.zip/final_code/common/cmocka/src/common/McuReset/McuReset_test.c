// =====================================================================================
// Copyright 2022 OTIS GmbH & Co OHG - OTIS Lead Design Center Berlin
// =====================================================================================
//
//! @file
//!
//! @brief MCU Reset API
//!
//!
//! @brief cmocka test file for src/common/McuReset/McuReset.c
//

#include <sciopta_sc.h>
#include <logd/logd.h>
#include "Cfg/ProcNames.h"
#include "Hlp/Msg.h"
#include "Cfg/MsgIds.h"
#include "wrap/sciopta.h"
#include "McuReset/McuReset.h"

union sc_msg {
  sc_msgid_t                        msgid;
  struct McuReset_ScMsgResetRequest resetRequest;
};


const char* const  CfgProcNames_safetyProcess = "/user/SafetyProcess";

#define PID_SAFETY_PROC  ((sc_pid_t) 40)

static logd_t  logd;


static void test_McuReset_SendRequest_01(void** state)
{
  sc_msg_t msg = NULL;
  
  expect_function_call(__wrap___sc_procIdGet);
  will_return(__wrap___sc_procIdGet, PID_SAFETY_PROC);

  sc_msgAlloc_will_return(INJECT_NO_ERROR);  // for the next call within this test case
  msg = __wrap___sc_msgAlloc(sizeof(struct McuReset_ScMsgResetRequest), SAFETYPROC_RESET_REQUEST_MSGID, SC_DEFAULT_POOL, SC_FATAL_IF_TMO);
  assert_true(msg != NULL);
  msg->resetRequest.resetReason = RESET_FOR_BOOTLOADER;
  sc_msgAlloc_will_return(INJECT_NO_ERROR);  // for the call within the test candidate

  expect_function_call(__wrap___sc_msgTx);  // is called by HlpMsg_TxFatal
  sc_msgTx_will_return(INJECT_NO_ERROR, msg, sizeof(struct McuReset_ScMsgResetRequest), PID_SAFETY_PROC); 
  expect_function_call(__wrap_HlpMsg_AssertSentFatal_f);  // is called instead of HlpMsg_TxFatal
  
  McuReset_SendRequest(&logd, RESET_FOR_BOOTLOADER);  // test candidate
  
  (void) state;
}

static void test_McuReset_SendRequest_02(void** state)
{
  expect_function_call(__wrap___sc_procIdGet);
  will_return(__wrap___sc_procIdGet, SC_ILLEGAL_PID);
  
  McuReset_SendRequest(&logd, RESET_FOR_BOOTLOADER);  // test candidate

  (void) state;
}


int main(void)
{
  int  retval = 0;
    
#ifdef CMOCKA_DIAB
  putenv("CMOCKA_XML_FILE=src_common_McuReset_McuReset.xml"); // environment variable for XML file when running on PPC
#endif
    
  const struct CMUnitTest  tests[] =
  {
    cmocka_unit_test(test_McuReset_SendRequest_01),  // good case
    cmocka_unit_test(test_McuReset_SendRequest_02),  // illegal PID
  };

  cmocka_set_message_output (CM_OUTPUT_XML);  // comment out for result output on console

  retval = cmocka_run_group_tests_name("src_common_McuReset_McuReset", tests, NULL, NULL);
  
#ifdef CMOCKA_DIAB
  read_xml_file("src_common_McuReset_McuReset.xml"); // extract XML test results from file in RAM when running on PPC
#endif
  
  return retval;
}

#!/bin/bash

STUBS+=("__sc_msgAlloc")   # from sciopta.o
STUBS+=("__sc_procIdGet")  # from sciopta.o
STUBS+=("__sc_msgTx")      # from sciopta.o
STUBS+=("HlpMsg_AssertSentFatal_f") # from Failure.o

STUB_WRAPS=${STUBS[@]/#/\-Wl,$2} # Diab wrap option syntax is different than GNU so pass in as parameter from make file

LINK+=("cmocka/wrap/sciopta.o")
LINK+=("cmocka/wrap/common/Hlp/Failure.o")

LINK_OBJECT=${LINK[@]/#/$1}

shift 2

$* $LINK_OBJECT $STUB_WRAPS

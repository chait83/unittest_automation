#!/bin/bash
STUBS+=("__sc_procIdGet")
STUBS+=("__sc_msgFree")
STUBS+=("__sc_msgRx")
STUBS+=("LifetimeCounter_Get")
STUBS+=("LifetimeCounter_ToMs32")
STUBS+=("__sc_tickMs2Tick")
STUBS+=("__sc_msgAlloc")

STUB_WRAPS=${STUBS[@]/#/\-Wl,$2} # Diab wrap option syntax is different than GNU so pass in as parameter from make file

LINK+=("cmocka/wrap/sciopta.o")

LINK_OBJECT=${LINK[@]/#/$1}

shift 2

$* $LINK_OBJECT $STUB_WRAPS

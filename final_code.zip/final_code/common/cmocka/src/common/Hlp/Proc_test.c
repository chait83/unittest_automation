// *****************************************************************************
// **                _______   _________  _________   _______                 **
// **               (  ___  )  \__   __/  \__   __/  (  ____ \                **
// **               | (   ) |     ) (        ) (     | (    \/                **
// **               | |   | |     | |        | |     | (_____                 **
// **               | |   | |     | |        | |     (_____  )                **
// **               | |   | |     | |        | |           ) |                **
// **               | (___) |     | |     ___) (___  /\____) |                **
// **               (_______)     )_(     \_______/  \_______)                **
// **                                                                         **
// **                        Lead Design Center Berlin                        **
// **                                                                         **
// **   Copyright 2021 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **
// **                                                                         **
// *****************************************************************************
//!
//! @file
//!
//! @brief cmocka test file for src/common/Hlp/Proc.c
//!
// *****************************************************************************
#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <stdbool.h>
#include <stdio.h>

#include "cmocka.h"

#include <sciopta_sc.h>
#include <sciopta.msg>
#include "Hlp/Proc.h"

#include "wrap/sciopta.h"

union sc_msg
{
  sc_procPathGetMsgReply_t procPath;
};

static void test_HlpProc_AlwaysTrue(void** state)
{
 	assert_true(HlpProc_AlwaysTrue());
  (void) state;
}

static void test_HlpProc_GetCurrentPid(void** state)
{
  expect_function_call(__wrap___sc_procIdGet);
  will_return(__wrap___sc_procIdGet, (sc_pid_t) 42);

  assert_true(HlpProc_GetCurrentPid() != 0);
  (void) state;

}

//! @details
//!   #HlpProc_ClearQueueTill contains an endless loop
//!   which is expected to be finished when #LifetimeCounter_Get provides a value
//!   which is greater than the provided delay
//!
//! @todo Add missing tests for the `ignoreList` parameter.
static void test_HlpProc_ClearQueueTill(void** state)
{
  size_t delay_ms;
  size_t cycleCount;

  // delays that are power of 2
  for (delay_ms = 1; delay_ms < 5; delay_ms = delay_ms * 2)
  {
    // Normal loops with reception of sciopta messages
    for (cycleCount = 0; cycleCount < delay_ms + 1; cycleCount++)
    {
      will_return(__wrap_LifetimeCounter_Get, (uint64_t) cycleCount);

      if (cycleCount % 2 == 0)
      {

        sc_msgAlloc_will_return(INJECT_NO_ERROR);
        sc_msg_t scMsg = sc_msgAlloc(sizeof(sc_procPathGetMsgReply_t), 0, (sc_poolid_t) 0 , (sc_ticks_t) 0);

        expect_function_call(__wrap___sc_msgFree);
        sc_msgRx_will_return(INJECT_NO_ERROR, scMsg );
      }
      else
      {
        sc_msgRx_will_return(INJECT_NO_ERROR, (sc_msg_t) NULL);
      }
    }

    // The last loop is terminated with the time measurement and does not need
    // any sciopta message reception.
    will_return(__wrap_LifetimeCounter_Get, (uint64_t) cycleCount);

    HlpProc_ClearQueueTill( (uint32_t) delay_ms, NULL);
  }

  (void) state;
}

int main(void)
{
    int retval = 0;
	
#ifdef CMOCKA_DIAB
    putenv("CMOCKA_XML_FILE=src_common_hlp_Proc.xml"); // environment variable for XML file when running on PPC
#endif

    const struct CMUnitTest tests[] =
    {
        cmocka_unit_test(test_HlpProc_AlwaysTrue),
        cmocka_unit_test(test_HlpProc_GetCurrentPid),
        cmocka_unit_test(test_HlpProc_ClearQueueTill)
    };


    cmocka_set_message_output(CM_OUTPUT_XML);

    retval = cmocka_run_group_tests_name("src_common_hlp_Proc", tests, NULL, NULL);
	
#ifdef CMOCKA_DIAB
    read_xml_file("src_common_hlp_Proc.xml"); // extract XML test results from file in RAM when running on PPC
#endif

    return retval;
}

extern uint32_t __wrap_LifetimeCounter_ToMs32(const uint64_t timeClk)
{
  return (uint32_t)(timeClk);
}

extern uint64_t __wrap_LifetimeCounter_Get(void)
{
  return (uint64_t) mock();
}

extern uint32_t __wrap___sc_tickMs2Tick(uint32_t ticks)
{
  return ticks;
}

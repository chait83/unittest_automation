// *****************************************************************************
// **                _______   _________  _________   _______                 **
// **               (  ___  )  \__   __/  \__   __/  (  ____ \                **
// **               | (   ) |     ) (        ) (     | (    \/                **
// **               | |   | |     | |        | |     | (_____                 **
// **               | |   | |     | |        | |     (_____  )                **
// **               | |   | |     | |        | |           ) |                **
// **               | (___) |     | |     ___) (___  /\____) |                **
// **               (_______)     )_(     \_______/  \_______)                **
// **                                                                         **
// **                        Lead Design Center Berlin                        **
// **                                                                         **
// **   Copyright 2021 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **
// **                                                                         **
// *****************************************************************************
//!
//! @file
//!
//! @brief cmocka test file for src/common/Hlp/Check.c
//!
// *****************************************************************************
#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <stdint.h>

#include "cmocka.h"

#include <sciopta.h>
#include "Hlp/Check.h"

uint64_t __wrap_LifetimeCounter_Get()
{
  return 0;
}

static void test_HlpCheck_IsValidScioptaPointer_false(void** state)
{
  assert_false(HlpCheck_IsValidScioptaPointer(NULL));
  assert_false(HlpCheck_IsValidScioptaPointer(SC_NIL));
  (void) state;
}

static void test_HlpCheck_IsValidScioptaPointer_true(void** state)
{
 	assert_true(HlpCheck_IsValidScioptaPointer(1));
  (void) state;
}

int main(void)
{
  int retval = 0;

#ifdef CMOCKA_DIAB
  putenv("CMOCKA_XML_FILE=src_common_hlp_Check.xml"); // environment variable for XML file when running on PPC
#endif

  const struct CMUnitTest tests[] =
  {
      cmocka_unit_test(test_HlpCheck_IsValidScioptaPointer_false),
      cmocka_unit_test(test_HlpCheck_IsValidScioptaPointer_true),
  };

  cmocka_set_message_output(CM_OUTPUT_XML);

  retval =  cmocka_run_group_tests_name("src_common_hlp_Check", tests, NULL, NULL);
  
#ifdef CMOCKA_DIAB
  read_xml_file("src_common_hlp_Check.xml"); // extract XML test results from file in RAM when running on PPC
#endif
			
  return retval;
}

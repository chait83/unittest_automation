#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>

#include "cmocka.h"
#include "Hlp\Crc32.h"


typedef struct
{
  const uint8_t *data;
  uint16_t length;
  uint32_t expectedCrc32;
} TestData_S;


// CRC32 of test data verified with http://www.sunshine2k.de/coding/javascript/crc/crc_js.html with the following settings:
//  - CRC width:                32
//  - CRC parameterization:     Predefined "CRC32"
//  - CRC detailed parameters:
//    - Input reflected:        yes
//    - result reflected:       yes
//    - Polynominal:            0x4c11DB7
//    - Initial value:          0xFFFFFFFF
//    - Final Xor Value:        0xFFFFFFFF


static const uint8_t data00[] = {0x00};
static const uint8_t data01[] = {0x00, 0x00};
static const uint8_t data02[] = {0x00, 0x00, 0x00};
static const uint8_t data03[] = {0x00, 0x00, 0x00, 0x00};
static const uint8_t data04[] = {0x00, 0x00, 0x00, 0x00, 0x00};
static const uint8_t data05[] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
static const uint8_t data06[] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
static const uint8_t data07[] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
static const uint8_t data08[] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
static const uint8_t data09[] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
static const uint8_t data10[] = {0x00, 0x01};
static const uint8_t data11[] = {0x00, 0x01, 0x02};
static const uint8_t data12[] = {0x00, 0x01, 0x02, 0x03};
static const uint8_t data13[] = {0x00, 0x01, 0x02, 0x03, 0x04};
static const uint8_t data14[] = {0x00, 0x01, 0x02, 0x03, 0x04, 0x05};
static const uint8_t data15[] = {0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39};
static const uint8_t data16[] = {0x1A, 0x3F, 0x7C, 0x84, 0xBC, 0x76, 0xFF, 0x27, 0x4F, 0x22, 0x3E, 0x65, 0xFC, 0xDE, 0xAD, 0xBE, 0xEF};


static const TestData_S testData[] =
{
  {.data = data00, .length = sizeof(data00), .expectedCrc32 = 0xD202EF8D},
  {.data = data01, .length = sizeof(data01), .expectedCrc32 = 0x41D912FF},
  {.data = data02, .length = sizeof(data02), .expectedCrc32 = 0xFF41D912},
  {.data = data03, .length = sizeof(data03), .expectedCrc32 = 0x2144DF1C},
  {.data = data04, .length = sizeof(data04), .expectedCrc32 = 0xC622F71D},
  {.data = data05, .length = sizeof(data05), .expectedCrc32 = 0xB1C2A1A3},
  {.data = data06, .length = sizeof(data06), .expectedCrc32 = 0x9D6CDF7E},
  {.data = data07, .length = sizeof(data07), .expectedCrc32 = 0x6522DF69},
  {.data = data08, .length = sizeof(data08), .expectedCrc32 = 0xE60914AE},
  {.data = data09, .length = sizeof(data09), .expectedCrc32 = 0xE38A6876},
  {.data = data10, .length = sizeof(data10), .expectedCrc32 = 0x36DE2269},
  {.data = data11, .length = sizeof(data11), .expectedCrc32 = 0x0854897F},
  {.data = data12, .length = sizeof(data12), .expectedCrc32 = 0x8BB98613},
  {.data = data13, .length = sizeof(data13), .expectedCrc32 = 0x515AD3CC},
  {.data = data14, .length = sizeof(data14), .expectedCrc32 = 0x30EBCF4A},
  {.data = data15, .length = sizeof(data15), .expectedCrc32 = 0xCBF43926},
  {.data = data16, .length = sizeof(data16), .expectedCrc32 = 0xC1737024}
};


// The caller must provide char s[dataLength * 3]
static char *Dbg_ByteStreamToHexStr(char* const str, const size_t strLength, const uint8_t* const data, const size_t dataLength)
{
  if ( (str != NULL)  &&  (data != NULL)  &&  ((3 * dataLength) <= strLength) )
  {
    str[0] = '\0';

    size_t  offset = 0;

    for ( size_t  i = 0; i < dataLength; i++ )
    {
      const int  rc = snprintf (&str[offset], strLength - offset, "%s%02X", (0 < i) ? " " : "", data[i]);
      if ( rc <= 0 )
      {
        str[0] = '\0';
        break;
      }
      offset += rc;
    }
  }

  return str;
}


static void test_HlpCrc32_Calculate16BitLength(void **state)
{
  char dataStr[100];

  printf("\nHlpCrc32_Calculate16BitLength\n");
  printf(" # | Expected | Calculated | Data\n");
  printf("---+----------+------------+-------------------------------------\n");

  for ( size_t  i = 0; i < sizeof(testData)/sizeof(testData[0]); i++)
  {
    const uint32_t  calculatedCrc32 = HlpCrc32_Calculate16BitLength(testData[i].data, testData[i].length);

    dataStr[0] = '\0';
    printf("%2u | %08X | %08X   | %s\n", (unsigned int) i, testData[i].expectedCrc32, calculatedCrc32, Dbg_ByteStreamToHexStr(dataStr, sizeof (dataStr), testData[i].data, testData[i].length));
    assert_int_equal(calculatedCrc32, testData[i].expectedCrc32);
  }
}


static void test_HlpCrc32_InitAddGet(void **state)
{
  char dataStr[100];

  printf("\nHlpCrc32_Init, HlpCrc32_Add, HlpCrc32_Get\n");
  printf(" # | Expected | Calculated | Data\n");
  printf("---+----------+------------+-------------------------------------\n");

  for ( size_t  i = 0; i < sizeof(testData)/sizeof(*testData); i++)
  {
    uint32_t  crcPrivate = 0;

    HlpCrc32_Init(&crcPrivate);
    HlpCrc32_Add(&crcPrivate, testData[i].data, testData[i].length);

    const uint32_t  calculatedCrc32 = HlpCrc32_Get(&crcPrivate);

    dataStr[0] = '\0';
    printf("%2u | %08X | %08X   | %s\n", (unsigned int) i, testData[i].expectedCrc32, calculatedCrc32, Dbg_ByteStreamToHexStr(dataStr, sizeof (dataStr), testData[i].data, testData[i].length));
    assert_int_equal(calculatedCrc32, testData[i].expectedCrc32);
  }
}


int main(void)
{
  int retval = 0;

#ifdef CMOCKA_DIAB
  putenv("CMOCKA_XML_FILE=src_common_Hlp_Crc32.xml"); // environment variable for XML file when running on PPC
#endif

  const struct CMUnitTest tests[] =
  {
    cmocka_unit_test(test_HlpCrc32_Calculate16BitLength),
    cmocka_unit_test(test_HlpCrc32_InitAddGet)
  };

  // Comment the following line out to get direct response regarding failed and succeeded test.
  // Otherwise, the testreport has to be created.
  cmocka_set_message_output(CM_OUTPUT_XML);

  retval = cmocka_run_group_tests_name("src_common_Hlp_Crc32", tests, NULL, NULL);
  
#ifdef CMOCKA_DIAB
  read_xml_file("src_common_Hlp_Crc32.xml"); // extract XML test results from file in RAM when running on PPC
#endif

  return retval;
}

#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include "ScnType.h"
#include "Cfg/Scn.h"
#include "Cfg/BuildType.h"
#include "Hlp/Scn.h"

#include "cmocka.h"

const char LinkInfo_User[64]     = "Developer";
const char LinkInfo_Computer[64] = "Computer";

const char CfgGit_Hash[64]   = "123456";
const bool CfgGit_HasChanged = false;
const char CfgGit_Head[256]  = "HEAD";

//! @brief is postfix correctly detected
static void test_HlpScn_hasPostfix(void** state)
{
  const union ScnType_Scn scnWithPostFix    = {.str = "GAA31660BAB+SK??"};

  const union ScnType_Scn scnWithoutPostFix = {.str = "GAA31660BAB     "};;

  assert_true (HlpScn_HasPostfix(&scnWithPostFix));
  assert_false(HlpScn_HasPostfix(&scnWithoutPostFix));
  (void) state;
}

//! @brief are SCNs with git changes correct adapted according to build type
static void test_HlpScn_toSendStrGitNoChanges(void** state)
{
  const union ScnType_Scn scn            = {.str = "G1231660BAB     "};
  const union ScnType_Scn scnWithPostFix = {.str = "G1231660BAB+SK01"};
  char  sendStr[sizeof(CfgScn_BoardScn)] = { '\0' };

  HlpScn_ToSendStr(&scn, sendStr, CfgBuildType_Beta, false);
  assert_string_equal(sendStr,"BAB12b 123456");

  HlpScn_ToSendStr(&scn, sendStr, CfgBuildType_Release, false);
  assert_string_equal(sendStr,"G1231660BAB     ");

  HlpScn_ToSendStr(&scnWithPostFix, sendStr, CfgBuildType_Release, false);
  assert_string_equal(sendStr,"G12BAB+SK01     ");

  HlpScn_ToSendStr(&scn, sendStr, CfgBuildType_ReleaseCandiate, false);
  assert_string_equal(sendStr,"BAB12rc123456");

  HlpScn_ToSendStr(&scn, sendStr, CfgBuildType_AutomaticBuild, false);
  assert_string_equal(sendStr,"BAB12ab123456");

  (void) state;
}

//! @brief are SCNs with git changes correct adapted according to build type
static void test_HlpScn_toSendStrGitWithChanges(void** state)
{
  const union ScnType_Scn scn    = {.str = "G1231660BAB     "};
  const union ScnType_Scn scnWithPostFix = {.str = "G1231660BAB+SK01"};
  char  sendStr[sizeof(CfgScn_BoardScn)] = { '\0' };

  HlpScn_ToSendStr(&scn, sendStr, CfgBuildType_Beta, true);
  assert_string_equal(sendStr,"BAB12b Devel*");

  HlpScn_ToSendStr(&scn, sendStr, CfgBuildType_Release, true);
  assert_string_equal(sendStr,"G1231660BAB*    ");

  HlpScn_ToSendStr(&scnWithPostFix, &sendStr[0], CfgBuildType_Release, true);
  assert_string_equal(sendStr,"G12BAB+SK01*    ");


  HlpScn_ToSendStr(&scn, sendStr, CfgBuildType_ReleaseCandiate, true);
  assert_string_equal(sendStr,"BAB12rcDevel*");

  // Should not happen in our environment but was added
  // because the contrary part with gitHasChanged=false was also tested.
  HlpScn_ToSendStr(&scn, sendStr, CfgBuildType_AutomaticBuild, true);
  assert_string_equal(sendStr,"BAB12abDevel*");

  (void) state;
}

//! @brief Unknown build type
static void test_HlpScn_wrongBuildType(void** state)
{
  const union ScnType_Scn scn    = {.str = "G1231660BAB     "};
  char  sendStr[sizeof(CfgScn_BoardScn)] = { '\0' };

  HlpScn_ToSendStr(&scn, &sendStr[0], (CfgBuildType_E) -1, false);
  assert_string_equal(sendStr,"BAB12??123456");

  HlpScn_ToSendStr(&scn, &sendStr[0], (CfgBuildType_E) -1, true);
  assert_string_equal(sendStr,"BAB12??Devel*");

  (void) state;
}

int main(void)
{
    int retval = 0;
	
#ifdef CMOCKA_DIAB
    putenv("CMOCKA_XML_FILE=src_common_Hlp_Scn.xml"); // environment variable for XML file when running on PPC
#endif

    const struct CMUnitTest tests[] =
    {
        cmocka_unit_test(test_HlpScn_hasPostfix),
        cmocka_unit_test(test_HlpScn_toSendStrGitNoChanges),
        cmocka_unit_test(test_HlpScn_toSendStrGitWithChanges),
        cmocka_unit_test(test_HlpScn_wrongBuildType)
    };

    cmocka_set_message_output(CM_OUTPUT_XML);

    retval =  cmocka_run_group_tests_name("src_common_Hlp_Scn", tests, NULL, NULL);
	
#ifdef CMOCKA_DIAB
    read_xml_file("src_common_Hlp_Scn.xml"); // extract XML test results from file in RAM when running on PPC
#endif

    return retval;
}

void __wrap_kprintf(const char* fmt)
{
  (void) printf(fmt);
}

#!/bin/bash
STUBS+=("CanSchedSrs_SendBlocking")

STUB_WRAPS=${STUBS[@]/#/\-Wl,$2} # Diab wrap option syntax is different than GNU so pass in as parameter from make file

shift 2

$* $STUB_WRAPS

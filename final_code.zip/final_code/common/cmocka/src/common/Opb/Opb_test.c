#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <stdint.h>
#include <string.h>

#include "cmocka.h"
#include "Opb/Opb.h"
#include <stdbool.h>
#include "Hlp/Types.h"
#include "Cfg/Self.h"

extern const CfgSelf_Self_S CfgSelf_self = {
                                      .safetyNode  = SafetyNode_SCON,
                                      .canNodeAddr = OpbNodeAddr_SCON
                                    };

//! @brief Tests the correctness of the Message Oriented CAN identifier
static void test_Opb_SetCanIdentifierMessageOriented(void** state)
{
  uint32_t expected_canIdentifier  =  ((((uint32_t)Opb_SERVICECODE_NODEORIENTED_PERFORMANCERELATED_NONFRAGMENTED) & 0x0FU)   << 25)
                                    | ((((uint32_t)true)                                                          & 0x01U)   << 24)
                                    | ((((uint32_t)Opb_MSGID_PESINFO)                                             & 0x0FFFU) << 12)
                                    | ((((uint32_t)OpbNodeAddr_SCON)                                             & 0x0FFFU) << 0);

  assert_int_equal(Opb_SetCanIdentifierMessageOriented(Opb_SERVICECODE_NODEORIENTED_PERFORMANCERELATED_NONFRAGMENTED,Opb_MSGID_PESINFO,OpbNodeAddr_SCON), expected_canIdentifier);

  (void) state;
}

//! @brief Tests the correctness of the Node Oriented CAN identifier
static void test_Opb_SetCanIdentifierNodeOriented(void** state)
{
  uint32_t expected_canIdentifier  =  ((((uint32_t)Opb_SERVICECODE_NODEORIENTED_PERFORMANCERELATED_NONFRAGMENTED) & 0x0FU)   << 25)
                                    | ((((uint32_t)false)                                                         & 0x01U)   << 24)
                                    | ((((uint32_t)OpbNodeAddr_SCAR)                                             & 0x0FFFU) << 12)
                                    | ((((uint32_t)OpbNodeAddr_SCON)                                             & 0x0FFFU) << 0);

  assert_int_equal(Opb_SetCanIdentifierNodeOriented(Opb_SERVICECODE_NODEORIENTED_PERFORMANCERELATED_NONFRAGMENTED,OpbNodeAddr_SCAR,OpbNodeAddr_SCON), expected_canIdentifier);

  (void) state;
}

//! @brief Tests the decision for Message Oriented communication
static void test_Opb_IsMessageOriented(void** state)
{
  uint32_t canIdentifier = 0x010ABC00;

  assert_true(Opb_IsMessageOriented(canIdentifier));

  (void) state;

}

//! @brief Tests decision for Node Oriented communication
static void test_Opb_IsNodeOriented(void** state)
{
  uint32_t canIdentifier = 0xF0000AEF;

  assert_false(Opb_IsMessageOriented(canIdentifier));

  (void) state;

}

//! @brief Tests the correctness of Destination Node address
static void test_Opb_GetMsgIdDestinationNodeAddress(void** state)
{
  uint32_t canIdentifier = 0xAE6E0AFF;

  assert_int_equal((Opb_GetMsgIdDestinationNodeAddress(canIdentifier)), (uint16_t)((canIdentifier & 0x00FFF000) >> 12));

  (void) state;

}

//! @brief Tests the correctness of Source Node address
static void test_Opb_GetSourceNodeAddr(void** state)
{
  uint32_t canIdentifier = 0xAE6E0AFF;

  assert_int_equal((Opb_GetSourceNodeAddr(canIdentifier)), (uint16_t)((canIdentifier & 0x00000FFF) >> 0));

  (void) state;

}

//! @brief Tests the sending of PesData
static void test_SendPesData(void** state)
{
  logd_t                     * logd                 = NULL;
  sc_pid_t                   canSchedulerPid        = 42;
  CanSchedTypes_CanChannel_T channel                = 10;
  uint8_t                    data[6]                = {1,2,3,4,5,6};
  uint32_t                   expected_canIdentifier =   ((((uint32_t)Opb_SERVICECODE_NODEORIENTED_NONCRITICAL_NONFRAGMENTED)        & 0x0FU)   << 25)
                                                      | ((((uint32_t)false)                                                         & 0x01U)   << 24)
                                                      | ((((uint32_t)OpbNodeAddr_SCAR)                                             & 0x0FFFU) << 12)
                                                      | ((((uint32_t)OpbNodeAddr_SCON)                                             & 0x0FFFU) << 0);
  uint8_t expected_data[8];
  expected_data[0]                                  = (uint8_t) ((Opb_MSGID_PESDATA >> 8) & 0xFF);
  expected_data[1]                                  = (uint8_t) (Opb_MSGID_PESDATA & 0xFF);
  memcpy(&expected_data[2], data, sizeof(data));
  uint8_t expected_dataLen                          = sizeof(expected_data);


  will_return(__wrap_CanSchedSrs_SendBlocking, expected_canIdentifier);
  will_return(__wrap_CanSchedSrs_SendBlocking, expected_dataLen);
  will_return(__wrap_CanSchedSrs_SendBlocking, expected_data);

  will_return(__wrap_CanSchedSrs_SendBlocking, canSchedulerPid);
  will_return(__wrap_CanSchedSrs_SendBlocking, channel);

  will_return(__wrap_CanSchedSrs_SendBlocking, CanSchedTypes_ERROR_SUCCESS);

  expect_function_call(__wrap_CanSchedSrs_SendBlocking);

  Opb_SendPesData(logd, canSchedulerPid, channel, OpbNodeAddr_SCAR, data);

  (void) state;

}

//! @brief Executed for getting coverage
static void test_Opb_SendCanMsgBlocking_If_DataLength_Greater_Than_OPB_CAN_MSG_MAX_SIZE(void** state)
{
  uint8_t                     buffer[9]     = {0};
  uint8_t                     pesDataSize   = 9;
  uint32_t                    canIdentifier = 45;
  CanSchedTypes_CanChannel_T  channel       = 10;
  sc_pid_t                    canSchedPid   = 42;

  assert_int_equal(Opb_SendCanMsgBlocking(canSchedPid, channel, canIdentifier, buffer, pesDataSize), CanSchedTypes_ERROR_CAN_DATA_LENGTH);

  (void) state;

}

int main(void)
{
    int retval = 0;
    
#ifdef CMOCKA_DIAB
    putenv("CMOCKA_XML_FILE=src_common_Opb_Opb.xml"); // environment variable for XML file when running on PPC
#endif

    const struct CMUnitTest tests[] =
    {
        cmocka_unit_test(test_Opb_SetCanIdentifierMessageOriented),
        cmocka_unit_test(test_Opb_SetCanIdentifierNodeOriented),
        cmocka_unit_test(test_Opb_IsMessageOriented),
        cmocka_unit_test(test_Opb_IsNodeOriented),
        cmocka_unit_test(test_Opb_GetMsgIdDestinationNodeAddress),
        cmocka_unit_test(test_Opb_GetSourceNodeAddr),
        cmocka_unit_test(test_SendPesData),
        cmocka_unit_test(test_Opb_SendCanMsgBlocking_If_DataLength_Greater_Than_OPB_CAN_MSG_MAX_SIZE),
    };

    cmocka_set_message_output(CM_OUTPUT_XML);

    retval =  cmocka_run_group_tests_name("src_common_Opb_Opb", tests, NULL, NULL);
    
#ifdef CMOCKA_DIAB
    read_xml_file("src_common_Opb_Opb.xml"); // extract XML test results from file in RAM when running on PPC
#endif

    return retval;
}

CanSchedTypes_Error_E __wrap_CanSchedSrs_SendBlocking(sc_pid_t                       canSchedPid,
                                                      CanSchedTypes_CanChannel_T     channel,
                                                      const CanSchedTypes_CanMsg_S * pCanMsg)
{
  uint32_t  expected_canIdentifier = (uint32_t) mock();
  uint8_t   expected_dataLen = (uint8_t) mock();
  uint8_t * expected_data = (uint8_t *) mock();
  sc_pid_t  expected_pid = (sc_pid_t) mock();
  CanSchedTypes_CanChannel_T  expected_channel = (CanSchedTypes_CanChannel_T) mock();


  assert_true(pCanMsg->protocol == CanSchedTypes_PROTOCOL_EXTENDED);
  assert_true(pCanMsg->canId == expected_canIdentifier);
  assert_true(pCanMsg->dataLen ==expected_dataLen);
  assert_memory_equal(expected_data, pCanMsg->data.u8, sizeof(pCanMsg->data.u8));

  assert_int_equal(canSchedPid, expected_pid);
  assert_int_equal(channel, expected_channel);

  function_called();

  return (CanSchedTypes_Error_E) mock();
}

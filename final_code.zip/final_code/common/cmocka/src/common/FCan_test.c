// *****************************************************************************
// **                _______   _________  _________   _______                 **
// **               (  ___  )  \__   __/  \__   __/  (  ____ \                **
// **               | (   ) |     ) (        ) (     | (    \/                **
// **               | |   | |     | |        | |     | (_____                 **
// **               | |   | |     | |        | |     (_____  )                **
// **               | |   | |     | |        | |           ) |                **
// **               | (___) |     | |     ___) (___  /\____) |                **
// **               (_______)     )_(     \_______/  \_______)                **
// **                                                                         **
// **                        Lead Design Center Berlin                        **
// **                                                                         **
// **   Copyright 2021 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **
// **                                                                         **
// *****************************************************************************
//!
//! @file
//!
//! @brief cmocka test file for src/common/FCan.c
//!
// *****************************************************************************
#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <stdint.h>

#include "cmocka.h"
#include "FCan.h"

uint64_t __wrap_LifetimeCounter_Get()
{
	return 0;
}

static void test_FCAN_getTimestamp(void** state)
{
	assert_int_equal(FCAN_getTimestamp(), 0);
    (void) state;

}

int main(void)
{
    int retval = 0;
	
#ifdef CMOCKA_DIAB
    putenv("CMOCKA_XML_FILE=src_common_FCan.xml"); // environment variable for XML file when running on PPC
#endif

    const struct CMUnitTest tests[] =
    {
        cmocka_unit_test(test_FCAN_getTimestamp),
    };

    cmocka_set_message_output(CM_OUTPUT_XML);

    retval =  cmocka_run_group_tests_name("src_common_FCan", tests, NULL, NULL);
	
#ifdef CMOCKA_DIAB
    read_xml_file("src_common_FCan.xml"); // extract XML test results from file in RAM when running on PPC
#endif

    return retval;
}

#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <stdint.h>
#include <string.h>

#include "cmocka.h"
#include "Scom/PcbInfo.h"
#include "Cfg/Self.h"

typedef struct packed
{
  uint16_t year;
  uint8_t  month;
  uint8_t  day;
  uint16_t padding;
} DeviceData_Date_S;


static const char* examinationCertificateSconScarSpit = "NL19-400-1002-    242-04 Rev8";  // <ReqId 383591>
static const char* examinationCertificateStab         = "NL19-400-1002-    242-06 Rev5";  // <ReqId 383591>
static const char* safetySystemTypeSconScarSpit       = "SIL rated System  GEA29502J1";   // <ReqId 383590>
static const char* safetySystemTypeStab               = "ESA, TBA20630A";                 // <ReqId 383590>


PcbInfo_B pcbInfo;

void __wrap_HlpFailure_EndlessLoopBusy(void)
{
  function_called();
}

static void test_check_HlpFailureEndlessLoopBusy_called(void** state)
{
  expect_function_calls(__wrap_HlpFailure_EndlessLoopBusy, 2);

  memset (&pcbInfo, 0, sizeof (pcbInfo));
  PcbInfo_SetOnce(&pcbInfo, 4);

  (void) state;
}

static void test_check_correct_handling_of_SCON(void** state)
{
  memset (&pcbInfo, 0, sizeof (pcbInfo));
  PcbInfo_SetOnce(&pcbInfo, SafetyNode_SCON);

  assert_string_equal(pcbInfo.PcbPartNumber, "GAA26800RR1-02");  // <ReqId 383586>
  assert_string_equal(pcbInfo.ExaminationCertificate, examinationCertificateSconScarSpit);
  assert_string_equal(pcbInfo.SafetySystemType, safetySystemTypeSconScarSpit);

  (void) state;
}

static void test_check_correct_handling_of_SCAR(void** state)
{
  memset (&pcbInfo, 0, sizeof (pcbInfo));
  PcbInfo_SetOnce(&pcbInfo, SafetyNode_SCAR);

  assert_string_equal(pcbInfo.PcbPartNumber, "GBA26800RZ1-02");  // <ReqId 383586>
  assert_string_equal(pcbInfo.ExaminationCertificate, examinationCertificateSconScarSpit);
  assert_string_equal(pcbInfo.SafetySystemType, safetySystemTypeSconScarSpit);

  (void) state;
}

static void test_check_correct_handling_of_SPIT(void** state)
{
  memset (&pcbInfo, 0, sizeof (pcbInfo));
  PcbInfo_SetOnce(&pcbInfo, SafetyNode_SPIT);

  assert_string_equal(pcbInfo.PcbPartNumber, "GBA26800SC1-02");  // <ReqId 383586>
  assert_string_equal(pcbInfo.ExaminationCertificate, examinationCertificateSconScarSpit);
  assert_string_equal(pcbInfo.SafetySystemType, safetySystemTypeSconScarSpit);

  (void) state;
}

static void test_check_correct_handling_of_STAB(void** state)
{
  memset (&pcbInfo, 0, sizeof (pcbInfo));
  PcbInfo_SetOnce(&pcbInfo, SafetyNode_SAB);

  assert_string_equal(pcbInfo.PcbPartNumber, "GAA20630D1-02");  // <ReqId 383586>
  assert_string_equal(pcbInfo.ExaminationCertificate, examinationCertificateStab);
  assert_string_equal(pcbInfo.SafetySystemType, safetySystemTypeStab);

  (void) state;
}

static void test_check_SamePcbInfoParameters(void** state)
{
  int i;

  for (i=SafetyNode_SCON;i<=SafetyNode_SAB;i++)
  {
    memset (&pcbInfo, 0, sizeof (pcbInfo));
    PcbInfo_SetOnce(&pcbInfo,i);

    assert_string_equal(pcbInfo.PcbManufacturer, "Otis Berlin");  // <ReqId 383592>
    assert_int_equal(pcbInfo.MissionTime[0],21);  // <ReqId 383593>

    // change pointer-type
    const void* const  ptrBuf = pcbInfo.PcbManufacturingDate.raw;
    const DeviceData_Date_S* const  ptrDate = ptrBuf;

    assert_int_equal (ptrDate->year,    0);
    assert_int_equal (ptrDate->month,   0);
    assert_int_equal (ptrDate->day,     0);
    assert_int_equal (ptrDate->padding, 0);
    assert_true(pcbInfo.PcbManufacturingDateIsValid == false);

    (void) state;
  }
}

//! @brief Check system manufacturer name according to prefix and node
static void test_check_CorrectSystemManufacturerProvided(void** state)
{
  size_t safetyNode;
  size_t prefix;

  for (safetyNode=0; safetyNode<=UINT8_MAX; safetyNode++)
  {
    for (prefix = 0; prefix < UINT8_MAX; prefix++)
    {
      memset(&pcbInfo, 0, sizeof(pcbInfo));

      if (
           (safetyNode != SafetyNode_SCON) && (safetyNode != SafetyNode_SCAR) &&
           (safetyNode != SafetyNode_SPIT) && (safetyNode != SafetyNode_SAB)
         )
      {
        expect_function_calls(__wrap_HlpFailure_EndlessLoopBusy, 1);
        PcbInfo_Set(&pcbInfo, safetyNode, prefix);
        assert_true(pcbInfo.SystemManufacturer[0] == 0);
      }
      else
      {
        PcbInfo_Set(&pcbInfo, safetyNode, prefix);
        if (safetyNode == SafetyNode_SAB)
        {
          switch ((char) prefix)
          {
            case 'F':
              assert_string_equal(pcbInfo.SystemManufacturer, "Otis SCS          F-45504 Gien");  // <ReqId 383589>

              break;
            case 'T':
              assert_string_equal(pcbInfo.SystemManufacturer, "Zardoya Otis      E-28919 Leganés");  // <ReqId 383589>

              break;
            default:
              assert_string_equal(pcbInfo.SystemManufacturer, "Unknown");  // <ReqId 383589>
              break;
          }
        }
        else if ( (safetyNode == SafetyNode_SCON) || (safetyNode == SafetyNode_SCAR) || (safetyNode == SafetyNode_SPIT) )
        {
          assert_string_equal(pcbInfo.SystemManufacturer, "Otis GmbH & Co.OHGD-13507 Berlin");  // <ReqId 383589>
        }

        assert_true(pcbInfo.SystemManufacturer[0] != 0);
      }
    }



  }
  (void) state;
}

int main(void)
{
  int retval = 0;
  
#ifdef CMOCKA_DIAB
  putenv("CMOCKA_XML_FILE=src_common_Scom_PcbInfo.xml"); // environment variable for XML file when running on PPC
#endif

  const struct CMUnitTest tests[] =
  {
      cmocka_unit_test(test_check_HlpFailureEndlessLoopBusy_called),
      cmocka_unit_test(test_check_correct_handling_of_SCON),
      cmocka_unit_test(test_check_correct_handling_of_SCAR),
      cmocka_unit_test(test_check_correct_handling_of_SPIT),
      cmocka_unit_test(test_check_correct_handling_of_STAB),
      cmocka_unit_test(test_check_SamePcbInfoParameters),
      cmocka_unit_test(test_check_CorrectSystemManufacturerProvided)
  };

  cmocka_set_message_output(CM_OUTPUT_XML);

  retval =  cmocka_run_group_tests_name("src_common_Scom_PcbInfo", tests, NULL, NULL);
  
#ifdef CMOCKA_DIAB
  read_xml_file("src_common_Scom_PcbInfo.xml"); // extract XML test results from file in RAM when running on PPC
#endif

  return retval;
}

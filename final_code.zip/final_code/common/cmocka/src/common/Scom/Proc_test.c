// *****************************************************************************
// **                _______   _________  _________   _______                 **
// **               (  ___  )  \__   __/  \__   __/  (  ____ \                **
// **               | (   ) |     ) (        ) (     | (    \/                **
// **               | |   | |     | |        | |     | (_____                 **
// **               | |   | |     | |        | |     (_____  )                **
// **               | |   | |     | |        | |           ) |                **
// **               | (___) |     | |     ___) (___  /\____) |                **
// **               (_______)     )_(     \_______/  \_______)                **
// **                                                                         **
// **                        Lead Design Center Berlin                        **
// **                                                                         **
// **   Copyright 2021 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **
// **                                                                         **
// *****************************************************************************
//!
//! @file
//!
//! @brief cmocka test file for src/common/Scom/Proc.c
//!
// *****************************************************************************
#include "Scom/Proc.h"
#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <sciopta_sc.h>

#include "cmocka.h"
#include "ScomFunction.h"
#include "Cfg/Self.h"
#include "CanSched/Msgs.h"
#include "Cfg/Can.h"
#include "Cfg/MsgIds.h"
#include <logd/logd.h>

ExtU_ScomFunction_T ScomFunction_U;
ExtY_ScomFunction_T ScomFunction_Y;

const char * const CfgProcNames_securityProcess = "/user/SecurityProcess";
static logd_t * _logd = NULL;
static bool _logdInitialized = false;


union sc_msg
{
  sc_msgid_t                    scMsgId;
  CanSchedMsgs_ScMsgRcvNotify_S canSchedRxMsg; //!< Message for receiving PesRequest CAN messages
};

const CfgSelf_Self_S CfgSelf_self = {
                                      .safetyNode  = SafetyNode_SPIT,
                                      .canNodeAddr = OpbNodeAddr_SPIT
                                    };

//!@name Module tests for ScomProc
//!{

//! @brief Check correct handling of unexpected sciopta messages
static void test_ScomProc_unexpected_ScMsg(void** state)
{
  union sc_msg sc_msg_unknown;
  sc_msg_unknown.scMsgId = 0;

  will_return(__wrap___sc_msgRx, &sc_msg_unknown);
  will_return(__wrap_HlpProc_AlwaysTrue, true);
  will_return(__wrap_HlpProc_AlwaysTrue, false);

  will_return(__wrap_CanSchedSrs_AllocFilter,       CanSchedTypes_ERROR_SUCCESS);
  will_return(__wrap_CanSchedSrs_SetFilterBlocking, CanSchedTypes_ERROR_SUCCESS);

  expect_function_calls(__wrap_Opb_SetCanIdentifierNodeOriented, 1);
  expect_function_calls(__wrap_HlpMsg_Unexpected, 1);

  _logdInitialized = false;
  (void) ScomProc_Proc();

  (void) state;
}

//! @brief Check if cyclic call yields call of model
static void test_ScomProc_Proc_Check_Cyclic_refresh_sc_msg(void** state)
{
  union sc_msg sc_msg_refresh;
  sc_msg_refresh.scMsgId = SCOMPROC_REFRESH_MSGID;

  will_return(__wrap_CanSchedSrs_AllocFilter,       CanSchedTypes_ERROR_SUCCESS);
  will_return(__wrap_CanSchedSrs_SetFilterBlocking, CanSchedTypes_ERROR_SUCCESS);

  will_return(__wrap___sc_msgRx, &sc_msg_refresh);

  will_return(__wrap_HlpProc_AlwaysTrue, true);
  will_return(__wrap_HlpProc_AlwaysTrue, false);

  expect_function_calls(__wrap_Opb_SetCanIdentifierNodeOriented, 1);
  expect_function_calls(__wrap_ScomFunction_output, 1);
  expect_function_calls(__wrap_ScomFunction_update, 1);

  _logdInitialized = false;
  (void) ScomProc_Proc();

  assert_true(ScomFunction_U.IsPeriodicCall);

  (void) state;
}

//! @brief Check if no cyclic call is communicated to the model
static void test_ScomProc_Proc_Check_Non_Cyclic_by_can_msg(void** state)
{
  union sc_msg sc_msg_can_message_PesRequest;
  sc_msg_can_message_PesRequest.scMsgId = CFGMSGIDS_CANSCHED_RCVNOTIFY_MSGID(Opb_bus);
  sc_msg_can_message_PesRequest.canSchedRxMsg.canMsg.canId = Opb_MSGID_PESREQUEST << 12;

  will_return(__wrap_CanSchedSrs_AllocFilter,       CanSchedTypes_ERROR_SUCCESS);
  will_return(__wrap_CanSchedSrs_SetFilterBlocking, CanSchedTypes_ERROR_SUCCESS);

  will_return(__wrap___sc_msgRx, &sc_msg_can_message_PesRequest);

  will_return(__wrap_Opb_IsMessageOriented,              true);
  will_return(__wrap_Opb_GetMsgIdDestinationNodeAddress, Opb_MSGID_PESREQUEST);

  will_return(__wrap_HlpProc_AlwaysTrue, true);
  will_return(__wrap_HlpProc_AlwaysTrue, false);

  expect_function_calls(__wrap_Opb_SetCanIdentifierNodeOriented, 1);
  expect_function_calls(__wrap_ScomFunction_output, 1);
  expect_function_calls(__wrap_ScomFunction_update, 1);

  _logdInitialized = false;
  (void) ScomProc_Proc();

  assert_false(ScomFunction_U.IsPeriodicCall);

  (void) state;
}

//! @brief Check if PesRequest Sciopta message is mapped to model input
static void test_ScomProc_Proc_Check_Mapping_PesRequest_sc_msg(void** state)
{
  union sc_msg sc_msg_can_message_PesRequest;
  union sc_msg sc_msg_can_message_NonPesRequest;

  sc_msg_can_message_NonPesRequest.scMsgId = CFGMSGIDS_CANSCHED_RCVNOTIFY_MSGID(Opb_bus);
  sc_msg_can_message_NonPesRequest.canSchedRxMsg.canMsg.canId = Opb_MSGID_PESINFO << 12;

  sc_msg_can_message_PesRequest.scMsgId = CFGMSGIDS_CANSCHED_RCVNOTIFY_MSGID(Opb_bus);
  sc_msg_can_message_PesRequest.canSchedRxMsg.canMsg.canId = Opb_MSGID_PESREQUEST << 12;
  sc_msg_can_message_PesRequest.canSchedRxMsg.canMsg.data.u8[0] = 1;
  sc_msg_can_message_PesRequest.canSchedRxMsg.canMsg.data.u8[1] = 2;
  sc_msg_can_message_PesRequest.canSchedRxMsg.canMsg.data.u8[2] = 3;
  sc_msg_can_message_PesRequest.canSchedRxMsg.canMsg.data.u8[3] = 4;
  sc_msg_can_message_PesRequest.canSchedRxMsg.canMsg.data.u8[4] = 5;
  sc_msg_can_message_PesRequest.canSchedRxMsg.ltcReceptionTime = 0xFF;

  will_return(__wrap_CanSchedSrs_AllocFilter,       CanSchedTypes_ERROR_SUCCESS);
  will_return(__wrap_CanSchedSrs_SetFilterBlocking, CanSchedTypes_ERROR_SUCCESS);

  will_return(__wrap___sc_msgRx, &sc_msg_can_message_PesRequest);
  will_return(__wrap___sc_msgRx, &sc_msg_can_message_NonPesRequest);

  will_return(__wrap_HlpProc_AlwaysTrue, true);
  will_return(__wrap_HlpProc_AlwaysTrue, true);
  will_return(__wrap_HlpProc_AlwaysTrue, false);

  will_return(__wrap_Opb_IsMessageOriented,              true);
  will_return(__wrap_Opb_GetMsgIdDestinationNodeAddress, Opb_MSGID_PESREQUEST);
  expect_function_calls(__wrap_Opb_SetCanIdentifierNodeOriented, 1);
  expect_function_calls(__wrap_ScomFunction_output, 1);
  expect_function_calls(__wrap_ScomFunction_update, 1);


  // CanScheduler is configured to only accept PesRequest messages
  will_return(__wrap_Opb_IsMessageOriented,              true);
  will_return(__wrap_Opb_GetMsgIdDestinationNodeAddress, Opb_MSGID_PESINFO);
  expect_function_calls(__wrap_ScomFunction_output, 1);
  expect_function_calls(__wrap_ScomFunction_update, 1);

  _logdInitialized = false;
  (void) ScomProc_Proc();

  assert_false(ScomFunction_U.IsPeriodicCall);

  assert_int_equal(sc_msg_can_message_PesRequest.canSchedRxMsg.canMsg.data.u8[0], (uint8_t) ScomFunction_U.ScomCanInputs.PesRequest.Requestee);
  assert_int_equal(sc_msg_can_message_PesRequest.canSchedRxMsg.canMsg.data.u8[1], (uint8_t) (ScomFunction_U.ScomCanInputs.PesRequest.Request >> 8));
  assert_int_equal(sc_msg_can_message_PesRequest.canSchedRxMsg.canMsg.data.u8[2], (uint8_t) ScomFunction_U.ScomCanInputs.PesRequest.Request );
  assert_int_equal(sc_msg_can_message_PesRequest.canSchedRxMsg.canMsg.data.u8[3], (uint8_t) (ScomFunction_U.ScomCanInputs.PesRequest.Parameter >> 8));
  assert_int_equal(sc_msg_can_message_PesRequest.canSchedRxMsg.canMsg.data.u8[4], (uint8_t) ScomFunction_U.ScomCanInputs.PesRequest.Parameter);
  assert_int_equal(sc_msg_can_message_PesRequest.canSchedRxMsg.ltcReceptionTime,  (uint8_t) ScomFunction_U.ScomCanInputs.PesRequest.ReceptionTimeStamp);

  (void) state;
}

//! @brief Check if correct PesRequest with system manufacturer
//!
//! @details
//!  * Check if NVM update is triggered before model is updated
//!  * Check if other requests doesn't trigger update of NVM
static void test_ScomProc_Proc_Check_Handling_PesRequest_SystemManufacturer(void** state)
{
  union sc_msg sc_msg_can_message_PesRequest_SystemManufacturer;
  union sc_msg sc_msg_can_message_PesRequest_NonSystemManufacturer;

  sc_msg_can_message_PesRequest_SystemManufacturer.scMsgId = CFGMSGIDS_CANSCHED_RCVNOTIFY_MSGID(Opb_bus);
  sc_msg_can_message_PesRequest_SystemManufacturer.canSchedRxMsg.canMsg.canId = Opb_MSGID_PESREQUEST << 12;
  sc_msg_can_message_PesRequest_SystemManufacturer.canSchedRxMsg.canMsg.data.u8[0] = 1;
  sc_msg_can_message_PesRequest_SystemManufacturer.canSchedRxMsg.canMsg.data.u8[1] = (PesRequest_Request_E_Data >> 8) & 0xFF;
  sc_msg_can_message_PesRequest_SystemManufacturer.canSchedRxMsg.canMsg.data.u8[2] = (PesRequest_Request_E_Data >> 0) & 0xFF;
  sc_msg_can_message_PesRequest_SystemManufacturer.canSchedRxMsg.canMsg.data.u8[3] = (PesDataId_SYSTEM_MANUFACTURER >> 8) & 0xFF;
  sc_msg_can_message_PesRequest_SystemManufacturer.canSchedRxMsg.canMsg.data.u8[4] = (PesDataId_SYSTEM_MANUFACTURER >> 0) & 0xFF;
  sc_msg_can_message_PesRequest_SystemManufacturer.canSchedRxMsg.ltcReceptionTime = 0xFF;

  memcpy(&sc_msg_can_message_PesRequest_NonSystemManufacturer,
         &sc_msg_can_message_PesRequest_SystemManufacturer,
         sizeof(sc_msg_can_message_PesRequest_SystemManufacturer));

  sc_msg_can_message_PesRequest_NonSystemManufacturer.canSchedRxMsg.canMsg.data.u8[3] = (PesDataId_None >> 8) & 0xFF;
  sc_msg_can_message_PesRequest_NonSystemManufacturer.canSchedRxMsg.canMsg.data.u8[4] = (PesDataId_None >> 0) & 0xFF;

  will_return(__wrap_CanSchedSrs_AllocFilter,       CanSchedTypes_ERROR_SUCCESS);
  will_return(__wrap_CanSchedSrs_SetFilterBlocking, CanSchedTypes_ERROR_SUCCESS);

  will_return(__wrap___sc_msgRx, &sc_msg_can_message_PesRequest_SystemManufacturer);
  will_return(__wrap___sc_msgRx, &sc_msg_can_message_PesRequest_NonSystemManufacturer);

  will_return(__wrap_HlpProc_AlwaysTrue, true);
  will_return(__wrap_HlpProc_AlwaysTrue, true);
  will_return(__wrap_HlpProc_AlwaysTrue, false);

  will_return(__wrap_Opb_IsMessageOriented,              true);
  will_return(__wrap_Opb_GetMsgIdDestinationNodeAddress, Opb_MSGID_PESREQUEST);

  will_return(__wrap_Opb_IsMessageOriented,              true);
  will_return(__wrap_Opb_GetMsgIdDestinationNodeAddress, Opb_MSGID_PESREQUEST);

  expect_function_calls(__wrap_Opb_SetCanIdentifierNodeOriented, 1);
  expect_function_calls(__wrap_GlueCodeNvm_HandleNvmItemsOfInterest, 1);
  expect_function_calls(__wrap_ScomFunction_output, 1);
  expect_function_calls(__wrap_ScomFunction_update, 1);

  expect_function_calls(__wrap_ScomFunction_output, 1);
  expect_function_calls(__wrap_ScomFunction_update, 1);

  _logdInitialized = false;
  (void) ScomProc_Proc();

  (void) state;
}

//! @brief Check if wrong PesRequest is not mapped to the model
//!
//! @details
//!  * Wrong due to being node oriented
static void test_ScomProc_Proc_Check_Handling_Wrong_PesRequest(void** state)
{
  union sc_msg sc_msg_can_message_PesRequest;

  sc_msg_can_message_PesRequest.scMsgId = CFGMSGIDS_CANSCHED_RCVNOTIFY_MSGID(Opb_bus);
  sc_msg_can_message_PesRequest.canSchedRxMsg.canMsg.canId = Opb_MSGID_PESREQUEST << 12;
  sc_msg_can_message_PesRequest.canSchedRxMsg.canMsg.data.u8[0] = 0x42;

  will_return(__wrap_CanSchedSrs_AllocFilter,       CanSchedTypes_ERROR_SUCCESS);
  will_return(__wrap_CanSchedSrs_SetFilterBlocking, CanSchedTypes_ERROR_SUCCESS);

  will_return(__wrap___sc_msgRx, &sc_msg_can_message_PesRequest);

  will_return(__wrap_HlpProc_AlwaysTrue, true);
  will_return(__wrap_HlpProc_AlwaysTrue, false);

  will_return(__wrap_Opb_IsMessageOriented,              false);

  expect_function_calls(__wrap_Opb_SetCanIdentifierNodeOriented, 1);
  expect_function_calls(__wrap_ScomFunction_output, 1);
  expect_function_calls(__wrap_ScomFunction_update, 1);

  _logdInitialized = false;
  (void) ScomProc_Proc();

  assert_true(ScomFunction_U.ScomCanInputs.PesRequest.Requestee != sc_msg_can_message_PesRequest.canSchedRxMsg.canMsg.data.u8[0]);

  (void) state;
}

//! @brief Test correct reaction in case of failures by CanSchedSrs
static void test_ScomProc_Proc_ErrorHandling_CanSchedSrs(void** state)
{
  will_return(__wrap_CanSchedSrs_AllocFilter,       CanSchedTypes_ERROR_CAN_BUS_OFF);
  will_return(__wrap_CanSchedSrs_SetFilterBlocking, CanSchedTypes_ERROR_CAN_BUS_OFF);

  will_return(__wrap_HlpProc_AlwaysTrue, false);

  expect_function_calls(__wrap_Opb_SetCanIdentifierNodeOriented, 1);
  expect_function_calls(__wrap_HlpFailure_EndlessLoopBusy, 2);

  _logdInitialized = false;
  (void) ScomProc_Proc();

  (void) state;
}

//! @brief Test mapping of model input for PcbInfo
static void test_ScomProc_Proc_Check_Mapping_PcbInfo(void** state)
{
  uint8_t i;

  will_return(__wrap_CanSchedSrs_AllocFilter,       CanSchedTypes_ERROR_SUCCESS);
  will_return(__wrap_CanSchedSrs_SetFilterBlocking, CanSchedTypes_ERROR_SUCCESS);
  will_return(__wrap_HlpProc_AlwaysTrue, false);
  expect_function_calls(__wrap_Opb_SetCanIdentifierNodeOriented, 1);

  _logdInitialized = false;
  (void) ScomProc_Proc();

  for (i=0; i < sizeof(ScomFunction_U.PcbInfo.MissionTime)/sizeof(ScomFunction_U.PcbInfo.MissionTime[0]);i++)
  {
    assert_true(ScomFunction_U.PcbInfo.MissionTime[i] == i);
  }

  for (i=0; i < sizeof(ScomFunction_U.PcbInfo.PcbManufacturer)/sizeof(ScomFunction_U.PcbInfo.PcbManufacturer[0]);i++)
  {
    assert_true(ScomFunction_U.PcbInfo.PcbManufacturer[i] == i);
  }

  for (i=0; i < sizeof(ScomFunction_U.PcbInfo.PcbManufacturingDate.raw)/sizeof(ScomFunction_U.PcbInfo.PcbManufacturingDate.raw[0]);i++)
  {
    assert_true(ScomFunction_U.PcbInfo.PcbManufacturingDate.raw[i] == i);
  }
  assert_true(ScomFunction_U.PcbInfo.PcbManufacturingDateIsValid == true);

  for (i=0; i < sizeof(ScomFunction_U.PcbInfo.ExaminationCertificate)/sizeof(ScomFunction_U.PcbInfo.ExaminationCertificate[0]);i++)
  {
    assert_true(ScomFunction_U.PcbInfo.ExaminationCertificate[i] == i);
  }

  for (i=0; i < sizeof(ScomFunction_U.PcbInfo.PcbPartNumber)/sizeof(ScomFunction_U.PcbInfo.PcbPartNumber[0]);i++)
  {
    assert_true(ScomFunction_U.PcbInfo.PcbPartNumber[i] == i);
  }

  for (i=0; i < sizeof(ScomFunction_U.PcbInfo.SafetySystemType)/sizeof(ScomFunction_U.PcbInfo.SafetySystemType[0]);i++)
  {
    assert_true(ScomFunction_U.PcbInfo.SafetySystemType[i] == i);
  }

  (void) state;
}

static void test_ScomProc_Proc_Check_Mapping_ScomHost(void** state)
{
  union sc_msg sc_msg_refresh;

  sc_msg_refresh.scMsgId = SCOMPROC_REFRESH_MSGID;

  will_return(__wrap_CanSchedSrs_AllocFilter,       CanSchedTypes_ERROR_SUCCESS);
  will_return(__wrap_CanSchedSrs_SetFilterBlocking, CanSchedTypes_ERROR_SUCCESS);

  will_return(__wrap___sc_msgRx, &sc_msg_refresh);

  will_return(__wrap_HlpProc_AlwaysTrue, true);
  will_return(__wrap_HlpProc_AlwaysTrue, false);

  expect_function_calls(__wrap_Opb_SetCanIdentifierNodeOriented, 1);
  expect_function_calls(__wrap_ScomFunction_output, 1);
  expect_function_calls(__wrap_ScomFunction_update, 1);

  _logdInitialized = false;
  (void) ScomProc_Proc();

  assert_true(ScomFunction_U.ScomHost == CfgSelf_self.safetyNode);

  (void) state;
}

//! @brief Test correct reaction in case PesData shall be send
static void test_ScomProc_Proc_Check_Sending_Pesdata(void** state)
{
  union sc_msg sc_msg_refresh;
  uint8_t i;

  sc_msg_refresh.scMsgId = SCOMPROC_REFRESH_MSGID;

  will_return(__wrap_CanSchedSrs_AllocFilter,       CanSchedTypes_ERROR_SUCCESS);
  will_return(__wrap_CanSchedSrs_SetFilterBlocking, CanSchedTypes_ERROR_SUCCESS);

  will_return(__wrap___sc_msgRx, &sc_msg_refresh);

  ScomFunction_Y.ScomCanOutputs.PesData.Send = true;

  for (i=0; i < sizeof(ScomFunction_Y.ScomCanOutputs.PesData.Data)/sizeof(ScomFunction_Y.ScomCanOutputs.PesData.Data[0]);i++)
  {
    ScomFunction_Y.ScomCanOutputs.PesData.Data[i] = i;
  }

  expect_function_calls(__wrap_Opb_SetCanIdentifierNodeOriented, 1);
  expect_function_calls(__wrap_ScomFunction_output, 1);
  expect_function_calls(__wrap_ScomFunction_update, 1);
  expect_function_calls(__wrap_Opb_SendPesData, 1);

  will_return(__wrap_HlpProc_AlwaysTrue, true);
  will_return(__wrap_HlpProc_AlwaysTrue, false);

  _logdInitialized = false;
  (void) ScomProc_Proc();

  ScomFunction_Y.ScomCanOutputs.PesData.Send = false;

  (void) state;
}



//! @brief Test correct reaction in case PesData according to crypto chip config response
static void test_ScomProc_Proc_Check_Handling_CryptoChipConfig_Response(void** state)
{
  union sc_msg sc_msg_crypto_reply;

  sc_msg_crypto_reply.scMsgId = SECURITY_CRYPTOCHIPCONFIGURE_REPLY_MSGID;

  will_return(__wrap_CanSchedSrs_AllocFilter,       CanSchedTypes_ERROR_SUCCESS);
  will_return(__wrap_CanSchedSrs_SetFilterBlocking, CanSchedTypes_ERROR_SUCCESS);

  will_return(__wrap___sc_msgRx, &sc_msg_crypto_reply);

  expect_function_calls(__wrap_Opb_SetCanIdentifierNodeOriented, 1);
  expect_function_calls(__wrap_HlpCrc32_Calculate16BitLength, 1);
  expect_function_calls(__wrap_Opb_SendPesData, 2);

  will_return(__wrap_HlpProc_AlwaysTrue, true);
  will_return(__wrap_HlpProc_AlwaysTrue, false);

  _logdInitialized = false;
  (void) ScomProc_Proc();

  (void) state;
}
//!}

//! @brief Test correct reaction in case PesData according to crypto chip GenKey response
static void test_ScomProc_Proc_Check_Handling_CryptoGenKey_Response(void** state)
{
  union sc_msg sc_msg_crypto_reply;

  sc_msg_crypto_reply.scMsgId = SECURITY_CRYPTOCHIPGENKEY_REPLY_MSGID;

  will_return(__wrap_CanSchedSrs_AllocFilter,       CanSchedTypes_ERROR_SUCCESS);
  will_return(__wrap_CanSchedSrs_SetFilterBlocking, CanSchedTypes_ERROR_SUCCESS);

  will_return(__wrap___sc_msgRx, &sc_msg_crypto_reply);

  expect_function_calls(__wrap_Opb_SetCanIdentifierNodeOriented, 1);
  expect_function_calls(__wrap_HlpCrc32_Calculate16BitLength, 1);
  expect_function_calls(__wrap_Opb_SendPesData, 2);

  will_return(__wrap_HlpProc_AlwaysTrue, true);
  will_return(__wrap_HlpProc_AlwaysTrue, false);

  _logdInitialized = false;
  (void) ScomProc_Proc();

  (void) state;
}
//!}

//! @brief Test correct reaction in case PesData according to crypto chip Lock response
static void test_ScomProc_Proc_Check_Handling_CryptoChipLockConfig_Response(void** state)
{
  union sc_msg sc_msg_crypto_reply;

  sc_msg_crypto_reply.scMsgId = SECURITY_CRYPTOCHIPLOCK_REPLY_MSGID;

  will_return(__wrap_CanSchedSrs_AllocFilter,       CanSchedTypes_ERROR_SUCCESS);
  will_return(__wrap_CanSchedSrs_SetFilterBlocking, CanSchedTypes_ERROR_SUCCESS);

  will_return(__wrap___sc_msgRx, &sc_msg_crypto_reply);

  expect_function_calls(__wrap_Opb_SetCanIdentifierNodeOriented, 1);
  expect_function_calls(__wrap_HlpCrc32_Calculate16BitLength, 1);
  expect_function_calls(__wrap_Opb_SendPesData, 2);

  will_return(__wrap_HlpProc_AlwaysTrue, true);
  will_return(__wrap_HlpProc_AlwaysTrue, false);

  _logdInitialized = false;
  (void) ScomProc_Proc();

  (void) state;
}
//!}


//! @brief Test correct reaction in case PesData according to OtpActivate response
static void test_ScomProc_Proc_Check_Handling_OtpActivate_Response(void** state)
{
  union sc_msg sc_msg_otp_reply;

  sc_msg_otp_reply.scMsgId = SECURITY_SECUREBOOT_REPLY_MSGID;

  will_return(__wrap_CanSchedSrs_AllocFilter,       CanSchedTypes_ERROR_SUCCESS);
  will_return(__wrap_CanSchedSrs_SetFilterBlocking, CanSchedTypes_ERROR_SUCCESS);

  will_return(__wrap___sc_msgRx, &sc_msg_otp_reply);

  expect_function_calls(__wrap_Opb_SetCanIdentifierNodeOriented, 1);
  expect_function_calls(__wrap_HlpCrc32_Calculate16BitLength, 1);
  expect_function_calls(__wrap_Opb_SendPesData, 2);

  will_return(__wrap_HlpProc_AlwaysTrue, true);
  will_return(__wrap_HlpProc_AlwaysTrue, false);

  _logdInitialized = false;
  (void) ScomProc_Proc();

  (void) state;
}
//!}


static void test_ScomProc_Proc_Check_Sending_CryptoChipConfigureRequest_helper(bool_t allocateFailure, bool_t txFailure)
{
  union sc_msg sc_msg_refresh;
  sc_msg_t msg_pointer_vaild = (sc_msg_t) 1;

  sc_msg_refresh.scMsgId = SCOMPROC_REFRESH_MSGID;

  will_return(__wrap_CanSchedSrs_AllocFilter,       CanSchedTypes_ERROR_SUCCESS);
  will_return(__wrap_CanSchedSrs_SetFilterBlocking, CanSchedTypes_ERROR_SUCCESS);

  will_return(__wrap___sc_msgRx, &sc_msg_refresh);

  ScomFunction_Y.ScomMsgOutputs.SecurityRequestCryptoChipConfigure.Send = true;

  expect_function_calls(__wrap_Opb_SetCanIdentifierNodeOriented, 1);
  expect_function_calls(__wrap_ScomFunction_output, 1);
  expect_function_calls(__wrap_ScomFunction_update, 1);

  expect_function_calls(__wrap_SecuritySProc_AllocCryptoChipConfigureRequest, 1);

  if (allocateFailure)
  {
    will_return(__wrap_SecuritySProc_AllocCryptoChipConfigureRequest, NULL);
  }
  else
  {
    will_return(__wrap_SecuritySProc_AllocCryptoChipConfigureRequest, msg_pointer_vaild);
    expect_function_calls(__wrap___sc_msgTx, 1);
    if (txFailure)
    {
      will_return(__wrap___sc_msgTx, txFailure);
      expect_function_call(__wrap_HlpFailure_EndlessLoop);
    }
    else
    {
      will_return(__wrap___sc_msgTx, txFailure);
    }
  }


  will_return(__wrap_HlpProc_AlwaysTrue, true);
  will_return(__wrap_HlpProc_AlwaysTrue, false);

  _logdInitialized = false;
  (void) ScomProc_Proc();

  ScomFunction_Y.ScomMsgOutputs.SecurityRequestCryptoChipConfigure.Send = false;
}

//! @brief Test correct reaction in case CryptoChipConfigureRequest shall be send
static void test_ScomProc_Proc_Check_Sending_CryptoChipConfigureRequest(void** state)
{
  test_ScomProc_Proc_Check_Sending_CryptoChipConfigureRequest_helper(false, false);
  test_ScomProc_Proc_Check_Sending_CryptoChipConfigureRequest_helper(true, false);
  test_ScomProc_Proc_Check_Sending_CryptoChipConfigureRequest_helper(false, true);

  (void) state;
}
//!}

static void test_ScomProc_Proc_Check_Sending_CryptoChipGenKeyRequest_helper(bool_t allocateFailure, bool_t txFailure)
{
  union sc_msg sc_msg_refresh;
  sc_msg_t msg_pointer_vaild = (sc_msg_t) 1;

  sc_msg_refresh.scMsgId = SCOMPROC_REFRESH_MSGID;

  will_return(__wrap_CanSchedSrs_AllocFilter,       CanSchedTypes_ERROR_SUCCESS);
  will_return(__wrap_CanSchedSrs_SetFilterBlocking, CanSchedTypes_ERROR_SUCCESS);

  will_return(__wrap___sc_msgRx, &sc_msg_refresh);

  ScomFunction_Y.ScomMsgOutputs.SecurityRequestCryptoChipCreateKey.Send = true;

  expect_function_calls(__wrap_Opb_SetCanIdentifierNodeOriented, 1);
  expect_function_calls(__wrap_ScomFunction_output, 1);
  expect_function_calls(__wrap_ScomFunction_update, 1);

  expect_function_calls(__wrap_SecuritySProc_AllocCryptoChipGenKeyRequest, 1);

  if (allocateFailure)
  {
    will_return(__wrap_SecuritySProc_AllocCryptoChipGenKeyRequest, NULL);
  }
  else
  {
    will_return(__wrap_SecuritySProc_AllocCryptoChipGenKeyRequest, msg_pointer_vaild);

    expect_function_calls(__wrap___sc_msgTx, 1);

    if (txFailure)
    {
      will_return(__wrap___sc_msgTx, txFailure);
      expect_function_call(__wrap_HlpFailure_EndlessLoop);
    }
    else
    {
      will_return(__wrap___sc_msgTx, txFailure);
    }
  }


  will_return(__wrap_HlpProc_AlwaysTrue, true);
  will_return(__wrap_HlpProc_AlwaysTrue, false);

  _logdInitialized = false;
  (void) ScomProc_Proc();

  ScomFunction_Y.ScomMsgOutputs.SecurityRequestCryptoChipCreateKey.Send = false;
}

//! @brief Test correct reaction in case CryptoChipGenKeyRequest shall be sent
static void test_ScomProc_Proc_Check_Sending_CryptoChipGenKeyRequest(void** state)
{
  test_ScomProc_Proc_Check_Sending_CryptoChipGenKeyRequest_helper(false, false);
  test_ScomProc_Proc_Check_Sending_CryptoChipGenKeyRequest_helper(true, false);
  test_ScomProc_Proc_Check_Sending_CryptoChipGenKeyRequest_helper(false, true);

  (void) state;
}
//!}

static void test_ScomProc_Proc_Check_Sending_CryptoChipLockConfigRequest_helper(bool_t allocateFailure, bool_t txFailure)
{
  union sc_msg sc_msg_refresh;
  sc_msg_t msg_pointer_vaild = (sc_msg_t) 1;

  sc_msg_refresh.scMsgId = SCOMPROC_REFRESH_MSGID;

  will_return(__wrap_CanSchedSrs_AllocFilter,       CanSchedTypes_ERROR_SUCCESS);
  will_return(__wrap_CanSchedSrs_SetFilterBlocking, CanSchedTypes_ERROR_SUCCESS);

  will_return(__wrap___sc_msgRx, &sc_msg_refresh);

  ScomFunction_Y.ScomMsgOutputs.SecurityRequestCryptoChipLockConfig.Send = true;

  expect_function_calls(__wrap_Opb_SetCanIdentifierNodeOriented, 1);
  expect_function_calls(__wrap_ScomFunction_output, 1);
  expect_function_calls(__wrap_ScomFunction_update, 1);

  expect_function_calls(__wrap_SecuritySProc_AllocCryptoChipLockRequest, 1);

  if (allocateFailure)
  {
    will_return(__wrap_SecuritySProc_AllocCryptoChipLockRequest, NULL);
  }
  else
  {
    will_return(__wrap_SecuritySProc_AllocCryptoChipLockRequest, msg_pointer_vaild);
    expect_function_calls(__wrap___sc_msgTx, 1);
    if (txFailure)
    {
      will_return(__wrap___sc_msgTx, txFailure);
      expect_function_call(__wrap_HlpFailure_EndlessLoop);
    }
    else
    {
      will_return(__wrap___sc_msgTx, txFailure);
    }
  }


  will_return(__wrap_HlpProc_AlwaysTrue, true);
  will_return(__wrap_HlpProc_AlwaysTrue, false);

  _logdInitialized = false;
  (void) ScomProc_Proc();

  ScomFunction_Y.ScomMsgOutputs.SecurityRequestCryptoChipLockConfig.Send = false;
}

//! @brief Test correct reaction in case CryptoChipLockRequest shall be sent
static void test_ScomProc_Proc_Check_Sending_CryptoChipLockConfigRequest(void** state)
{
  test_ScomProc_Proc_Check_Sending_CryptoChipLockConfigRequest_helper(false, false);
  test_ScomProc_Proc_Check_Sending_CryptoChipLockConfigRequest_helper(true, false);
  test_ScomProc_Proc_Check_Sending_CryptoChipLockConfigRequest_helper(false, true);

  (void) state;
}
//!}


static void test_ScomProc_Proc_Check_Sending_OtpActivateRequest_helper(bool_t allocateFailure, bool_t txFailure)
{
  union sc_msg sc_msg_refresh;
  sc_msg_t msg_pointer_vaild = (sc_msg_t) 1;

  sc_msg_refresh.scMsgId = SCOMPROC_REFRESH_MSGID;

  will_return(__wrap_CanSchedSrs_AllocFilter,       CanSchedTypes_ERROR_SUCCESS);
  will_return(__wrap_CanSchedSrs_SetFilterBlocking, CanSchedTypes_ERROR_SUCCESS);

  will_return(__wrap___sc_msgRx, &sc_msg_refresh);

  ScomFunction_Y.ScomMsgOutputs.SecurityRequestOtpActivate.Send = true;

  expect_function_calls(__wrap_Opb_SetCanIdentifierNodeOriented, 1);
  expect_function_calls(__wrap_ScomFunction_output, 1);
  expect_function_calls(__wrap_ScomFunction_update, 1);

  expect_function_calls(__wrap_SecuritySProc_AllocSecureBootRequest, 1);

  if (allocateFailure)
  {
    will_return(__wrap_SecuritySProc_AllocSecureBootRequest, NULL);
  }
  else
  {
    will_return(__wrap_SecuritySProc_AllocSecureBootRequest, msg_pointer_vaild);
    expect_function_calls(__wrap___sc_msgTx, 1);
    if (txFailure)
    {
      will_return(__wrap___sc_msgTx, txFailure);
      expect_function_call(__wrap_HlpFailure_EndlessLoop);
    }
    else
    {
      will_return(__wrap___sc_msgTx, txFailure);
    }
  }


  will_return(__wrap_HlpProc_AlwaysTrue, true);
  will_return(__wrap_HlpProc_AlwaysTrue, false);

  _logdInitialized = false;
  (void) ScomProc_Proc();

  ScomFunction_Y.ScomMsgOutputs.SecurityRequestOtpActivate.Send = false;
}


//! @brief Test correct reaction in case OtpActivateRequest shall be sent
static void test_ScomProc_Proc_Check_Sending_OtpActivateRequest(void** state)
{
  test_ScomProc_Proc_Check_Sending_OtpActivateRequest_helper(false, false);
  test_ScomProc_Proc_Check_Sending_OtpActivateRequest_helper(true, false);
  test_ScomProc_Proc_Check_Sending_OtpActivateRequest_helper(false, true);

  (void) state;
}
//!}


int main(void)
{
    int retval = 0;

#ifdef CMOCKA_DIAB
    putenv("CMOCKA_XML_FILE=src_common_proc_Scom.xml"); // environment variable for XML file when running on PPC
#endif

    const struct CMUnitTest tests[] =
    {
        cmocka_unit_test(test_ScomProc_unexpected_ScMsg),
        cmocka_unit_test(test_ScomProc_Proc_Check_Cyclic_refresh_sc_msg),
        cmocka_unit_test(test_ScomProc_Proc_Check_Non_Cyclic_by_can_msg),
        cmocka_unit_test(test_ScomProc_Proc_Check_Mapping_PesRequest_sc_msg),
        cmocka_unit_test(test_ScomProc_Proc_Check_Handling_PesRequest_SystemManufacturer),
        cmocka_unit_test(test_ScomProc_Proc_Check_Handling_Wrong_PesRequest),
        cmocka_unit_test(test_ScomProc_Proc_ErrorHandling_CanSchedSrs),
        cmocka_unit_test(test_ScomProc_Proc_Check_Mapping_PcbInfo),
        cmocka_unit_test(test_ScomProc_Proc_Check_Mapping_ScomHost),
        cmocka_unit_test(test_ScomProc_Proc_Check_Sending_Pesdata),

        // Handling responses
        cmocka_unit_test(test_ScomProc_Proc_Check_Handling_CryptoChipConfig_Response),
        cmocka_unit_test(test_ScomProc_Proc_Check_Handling_CryptoGenKey_Response),
        cmocka_unit_test(test_ScomProc_Proc_Check_Handling_CryptoChipLockConfig_Response),
        cmocka_unit_test(test_ScomProc_Proc_Check_Handling_OtpActivate_Response),

        // Sending requests
        cmocka_unit_test(test_ScomProc_Proc_Check_Sending_CryptoChipConfigureRequest),
        cmocka_unit_test(test_ScomProc_Proc_Check_Sending_CryptoChipGenKeyRequest),
        cmocka_unit_test(test_ScomProc_Proc_Check_Sending_CryptoChipLockConfigRequest),
        cmocka_unit_test(test_ScomProc_Proc_Check_Sending_OtpActivateRequest)
    };

    cmocka_set_message_output(CM_OUTPUT_XML);

    retval =  cmocka_run_group_tests_name("src_common_proc_Scom", tests, NULL, NULL);
	
#ifdef CMOCKA_DIAB
    read_xml_file("src_common_proc_Scom.xml"); // extract XML test results from file in RAM when running on PPC
#endif

    return retval;
}

//!@name Stubbed PcbInfo Functions
//!{
extern void __wrap_PcbInfo_Set(PcbInfo_B *pPcbInfo, const SafetyNode_E safetyNode)
{

}
extern void  __wrap_PcbInfo_SetOnce(PcbInfo_B *pPcbInfo)
{
  uint8_t i;
  for (i=0; i < sizeof(pPcbInfo->MissionTime)/sizeof(pPcbInfo->MissionTime[0]);i++)
  {
    pPcbInfo->MissionTime[i] = i;
  }

  for (i=0; i < sizeof(pPcbInfo->PcbManufacturer)/sizeof(pPcbInfo->PcbManufacturer[0]);i++)
  {
    pPcbInfo->PcbManufacturer[i] = i;
  }

  for (i=0; i < sizeof(pPcbInfo->PcbManufacturingDate.raw)/sizeof(pPcbInfo->PcbManufacturingDate.raw[0]);i++)
  {
    pPcbInfo->PcbManufacturingDate.raw[i] = i;
  }
  pPcbInfo->PcbManufacturingDateIsValid = true;

  for (i=0; i < sizeof(pPcbInfo->ExaminationCertificate)/sizeof(pPcbInfo->ExaminationCertificate[0]);i++)
  {
    pPcbInfo->ExaminationCertificate[i] = i;
  }

  for (i=0; i < sizeof(pPcbInfo->PcbPartNumber)/sizeof(pPcbInfo->PcbPartNumber[0]);i++)
  {
    pPcbInfo->PcbPartNumber[i] = i;
  }

  for (i=0; i < sizeof(pPcbInfo->SafetySystemType)/sizeof(pPcbInfo->SafetySystemType[0]);i++)
  {
    pPcbInfo->SafetySystemType[i] = i;
  }

}
//!}

//!@name Stubbed ModelSupport Functions
//!{
uint32_t __wrap_ModelSupport_LtcToModelTimebase(uint64_t ltc)
{
  return ltc;
}
//!}

//!@name Stubbed CanSched Functions
//!{
sc_pid_t __wrap_CanSchedCanSched_GetPid(void)
{
  return 0;
}

CanSchedTypes_Error_E __wrap_CanSchedSrs_AllocFilter(sc_pid_t                         canSchedPid,
                                                     CanSchedTypes_CanChannel_T       channel,
                                                     CanSchedTypes_CanFilterIndex_T * pFilterIndex)
{
  return (CanSchedTypes_Error_E) mock();
}

CanSchedTypes_Error_E __wrap_CanSchedSrs_SetFilterBlocking(sc_pid_t                          canSchedPid,
                                                           CanSchedTypes_CanChannel_T        channel,
                                                           CanSchedTypes_CanFilterIndex_T    filterIndex,
                                                           size_t                            filterListLength,
                                                           const CanSchedTypes_CanFilter_S * pFilterList)
{
  return (CanSchedTypes_Error_E) mock();
}

//!}

//!@name Stubbed OPB Functions
//!{

//!  @details
//!  Contains check if can message is correct, @sa test_ScomProc_Proc_sendPesdata.
extern CanSchedTypes_Error_E __wrap_Opb_SendCanMsgBlocking(const sc_pid_t                   canSchedPid,
                                                           const CanSchedTypes_CanChannel_T channel,
                                                           const uint32_t                   canIdentifier,
                                                           const uint8_t                    data[],
                                                           const uint8_t                    length)
{
  function_called();

  uint8_t i;

  assert_int_equal(data[0], (uint8_t) (Opb_MSGID_PESDATA >> 8) );
  assert_int_equal(data[1], (uint8_t) (Opb_MSGID_PESDATA >> 0) );

  for (i=0; i < 6; i++)
  {
    assert_int_equal(data[i+2], i);
  }

  return CanSchedTypes_ERROR_SUCCESS;
}

uint32_t __wrap_Opb_SetCanIdentifierMessageOriented(const Opb_ServiceCode_E serviceCode,
                                                    const Opb_MsgId_E       msgId,
                                                    const OpbNodeAddr_E     sourceNodeAddress)
{
  return 0;
}

uint32_t __wrap_Opb_SetCanIdentifierNodeOriented(const Opb_ServiceCode_E serviceCode,
                                                 const OpbNodeAddr_E     destinationNodeAddress,
                                                 const OpbNodeAddr_E     sourceNodeAddress)
{
  function_called();

  return 0xFF;
}

bool __wrap_Opb_IsMessageOriented(const uint32_t canIdentifier)
{
  return (bool)mock();
}

uint16_t __wrap_Opb_GetMsgIdDestinationNodeAddress(const uint32_t canIdentifier)
{
  return (uint16_t)mock();
}

extern uint16_t __wrap_Opb_GetSourceNodeAddr(const uint32_t canIdentifier)
{
  return 0;
}

extern void __wrap_Opb_SendPesData(logd_t                    *logd,
                            const sc_pid_t                   canSchedulerPid,
                            const CanSchedTypes_CanChannel_T channel,
                            const OpbNodeAddr_E              requesterNodeAddr,
                            const uint8_t                    *data)
{
  function_called();
}


//!}

//!@name Stubbed Sciopta Functions
//!{

static void * _msgAllocBuffers[10] = { 0 };

sc_msg_t __wrap___sc_msgAlloc(size_t size, sc_msgid_t msgid, sc_poolid_t poolid, sc_ticks_t ticks)
{
  size_t i;
  bool foundBuffer = false;

  for (i = 0; i < sizeof(_msgAllocBuffers) / sizeof(_msgAllocBuffers[0]); ++i)
  {
    if (_msgAllocBuffers[i] == NULL)
    {
      foundBuffer = true;
      break;
    }
  }

  assert_true(foundBuffer);
  assert_true(size >= sizeof(sc_msgid_t));

  _msgAllocBuffers[i] = malloc(size);
  assert_true(_msgAllocBuffers[i] != NULL);

  *((sc_msgid_t *) (_msgAllocBuffers[i])) = msgid;

  return _msgAllocBuffers[i];
}

uint64_t __wrap___sc_msgFree(sc_msg_t * msgPtr)
{
  size_t i;
  bool foundBuffer = false;

  assert_true(msgPtr != NULL);

  {
    // if message was really allocated, free the buffer
    for (i = 0; i < sizeof(_msgAllocBuffers) / sizeof(_msgAllocBuffers[0]); ++i)
    {
      if (_msgAllocBuffers[i] == *msgPtr)
      {
        foundBuffer = true;
        break;
      }
    }

    if (foundBuffer)
    {
      free(_msgAllocBuffers[i]);
      _msgAllocBuffers[i] = NULL;
    }
  }

  *msgPtr = NULL;
  return 0;
}

sc_msg_t __wrap___sc_msgRx()
{
  return (sc_msg_t) mock();
}

extern void __wrap___sc_msgTx(sc_msgptr_t ptr,sc_pid_t pid , sc_msgTxFlags_t flags)
{
  bool_t failure = (bool_t) mock();

  if (!failure)
  {
    *ptr = NULL;
  }

  function_called();
}

sc_pid_t __wrap___sc_procIdGet()
{
  return (sc_pid_t) 0;
}

//!}

//!@name Stubbed Model Functions
//!{
void __wrap_ScomFunction_output(void)
{
  function_called();
}

void __wrap_ScomFunction_update(void)
{
  function_called();
}

void __wrap_ScomFunction_initialize(void)
{

}
//!}

//!@name Stubbed Helper Functions
//!{

void __wrap_HlpFailure_EndlessLoopBusy(void)
{
  function_called();
}

bool __wrap_HlpProc_AlwaysTrue(void)
{
  return (bool) mock();
}

void  __wrap_HlpMsg_Unexpected(logd_t * logd, sc_msg_t * pm)
{
  function_called();
}

extern void __wrap_HlpFailure_EndlessLoop(void)
{
  function_called();
}

extern uint32_t __wrap_HlpCrc32_Calculate16BitLength(const uint8_t *data, const uint16_t length)
{
  function_called();
  return 0;
}

extern void __wrap_HlpMsg_AssertSentFatal_f(logd_t * logd, sc_msg_t * pm, const char * file, int lineno, const char * func)
{
  assert_true(logd != NULL);
  assert_true(pm != NULL);
  assert_true(file != NULL);
  assert_true(func != NULL);
}


extern void __wrap_HlpProcVar_Init(const char * procName, size_t additional)
{
  assert_true(_logdInitialized == false);
  _logd = logd_new("scpLogd", 0, procName, SC_DEFAULT_POOL, SC_NO_TMO);
  _logdInitialized = true;
}

extern logd_t * __wrap_HlpProcVar_GetLogd()
{
  assert_true(_logdInitialized == true);
  return _logd;
}

//!}

//!@name Stubbed Other Functions
//!{
void __wrap_logd_printf(const char *fmt)
{
  (void) printf(fmt);
}

logd_t * __wrap_logd_new(const char *logdProcessName,
                         int levelMax, /* obsolete ! */
                         const char *appl,
                         sc_poolid_t plid,
                         sc_ticks_t tmo)
{
  return NULL;
}

extern uint64_t __wrap_LifetimeCounter_Get(void)
{
   return 0xFF;
}

extern sc_pid_t __wrap_EepromEProc_GetPid(void)
{
  return 0;
}
//!}

extern sc_msg_t __wrap_SecuritySProc_AllocCryptoChipConfigureRequest(sc_poolid_t pool, sc_ticks_t tmo)
{
  function_called();
  return (sc_msg_t) mock();
}

extern sc_msg_t __wrap_SecuritySProc_AllocCryptoChipGenKeyRequest(sc_poolid_t pool, sc_ticks_t tmo)
{
  function_called();
  return (sc_msg_t) mock();
}

extern sc_msg_t __wrap_SecuritySProc_AllocCryptoChipLockRequest(sc_poolid_t pool, sc_ticks_t tmo)
{
  function_called();
  return (sc_msg_t) mock();
}

extern sc_msg_t __wrap_SecuritySProc_AllocSecureBootRequest(sc_poolid_t pool, sc_ticks_t tmo)
{
  function_called();
  return (sc_msg_t) mock();
}

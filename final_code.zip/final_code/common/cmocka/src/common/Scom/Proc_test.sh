#!/bin/bash
STUBS+=("ModelSupport_LtcToModelTimebase")
STUBS+=("CanSchedCanSched_GetPid")
STUBS+=("Opb_SetCanIdentifierMessageOriented")
STUBS+=("CanSchedSrs_AllocFilter")
STUBS+=("logd_printf")
STUBS+=("ModelSupport_LtcToModelTimebase")

STUBS+=("HlpFailure_EndlessLoopBusy")
STUBS+=("CanSchedSrs_SetFilterBlocking")
STUBS+=("Opb_SetCanIdentifierNodeOriented")
STUBS+=("Opb_IsMessageOriented")
STUBS+=("Opb_GetMsgIdDestinationNodeAddress")
STUBS+=("Opb_GetSourceNodeAddr")
STUBS+=("HlpFailure_EndlessLoop")
STUBS+=("HlpCrc32_Calculate16BitLength")
STUBS+=("Opb_SendPesData")
STUBS+=("SecuritySProc_AllocCryptoChipConfigureRequest")
STUBS+=("SecuritySProc_AllocCryptoChipGenKeyRequest")
STUBS+=("SecuritySProc_AllocCryptoChipLockRequest")
STUBS+=("SecuritySProc_AllocSecureBootRequest")


STUBS+=("__sc_msgRx")
STUBS+=("Dbg_ByteStreamToHexStr")

STUBS+=("Opb_SendCanMsgBlocking")
STUBS+=("logd_new")
STUBS+=("ScomFunction_initialize")
STUBS+=("PcbInfo_Set")
STUBS+=("PcbInfo_SetOnce")

STUBS+=("__sc_msgAlloc")
STUBS+=("__sc_msgFree")
STUBS+=("__sc_msgTx")
STUBS+=("__sc_procIdGet")

STUBS+=("ScomFunction_output")
STUBS+=("ScomFunction_update")
STUBS+=("HlpFailure_NullPointer")
STUBS+=("HlpMsg_Unexpected")
STUBS+=("HlpMsg_AssertSentFatal_f")
STUBS+=("HlpProc_AlwaysTrue")
STUBS+=("HlpProcVar_Init")
STUBS+=("HlpProcVar_GetLogd")

STUBS+=("GlueCodeNvmMap_Item0")
STUBS+=("GlueCodeNvmMap_Item1")
STUBS+=("GlueCodeNvmMap_Item2")
STUBS+=("GlueCodeNvmMap_Item3")
STUBS+=("GlueCodeNvmMap_Item4")
STUBS+=("GlueCodeNvmMap_Item5")
STUBS+=("GlueCodeNvmMap_Item6")
STUBS+=("GlueCodeNvmMap_Item7")
STUBS+=("GlueCodeNvmMap_Item8")
STUBS+=("GlueCodeNvmMap_Item23")
STUBS+=("GlueCodeNvmMap_Item140")
STUBS+=("GlueCodeNvmMap_Item141")
STUBS+=("GlueCodeNvmMap_Item142")
STUBS+=("GlueCodeNvmMap_Item143")
STUBS+=("GlueCodeNvmMap_Item25")
STUBS+=("GlueCodeNvmMap_Item26")
STUBS+=("GlueCodeNvmMap_Item27")
STUBS+=("GlueCodeNvmMap_Item28_39")
STUBS+=("GlueCodeNvmMap_Item100_105")
STUBS+=("GlueCodeNvmMap_Item205")
STUBS+=("GlueCodeNvmMap_Item206")
STUBS+=("GlueCodeNvmMap_Item207")
STUBS+=("GlueCodeNvmMap_Item208")
STUBS+=("GlueCodeNvm_HandleNvmItemsOfInterest")

STUBS+=("LifetimeCounter_Get")
STUBS+=("EepromEProc_GetPid")

#STUBS+=("CanSchedSrs_SendBlocking")


STUB_WRAPS=${STUBS[@]/#/\-Wl,$2} # Diab wrap option syntax is different than GNU so pass in as parameter from make file

LINK+=("cmocka/wrap/common/GlueCode/NvmMap.o")
#LINK+=("src/common/Opb/Opb.o")  ## use real module

LINK_OBJECT=${LINK[@]/#/$1}

shift 2

$* $LINK_OBJECT $STUB_WRAPS

#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>

#include <sciopta_sc.h>

#include "cmocka.h"

#include "Cfg/Self.h"
#include "CanSched/Msgs.h"
#include "Cfg/Can.h"
#include "Cfg/MsgIds.h"
#include <logd/logd.h>
#include "Cfg/ProcNames.h"
#include "McuIntegrityError.h"

#include "CanMsgAlias.h"
#include "Proc/RsdProcess.h"
#include "Cdrv.h"
#include "dbc.h"

#define SC_CURRENT_RSD ((sc_pid_t)43)

const char * const CfgProcNames_canSched        = "canSched";
const char * const CfgProcNames_RsdProc         = "rsdProc";
const char * const CfgProcNames_scpLogd         = "/SCP_logd";

static logd_t * _logd = NULL;
static bool _logdInitialized = false;

union sc_msg
{
  sc_msgid_t              scMsgId;   //!< Sciopta message ID
  union CanSchedMsgs_Msgs canSched;  //!< CAN Scheduler message interface
};

const CfgSelf_Self_S CfgSelf_self = {
                                      .safetyNode         = SafetyNode_SCON,
                                      .canNodeAddr        = OpbNodeAddr_SCON
                                    };

//!@name Module tests for Rsd process
//!{

//! @brief Check if can messages from the car bus are correctly handled
static void test_check_handling_can_messages_sc_msg(void** state)
{
  union sc_msg sc_can_msg;
  CanSchedTypes_CanChannel_T     channel       = 1;
  
  sc_can_msg.scMsgId = CFGMSGIDS_CANSCHED_RCVNOTIFY_MSGID(channel);

  will_return(__wrap_CanSchedSrs_AllocFilter, true);
  will_return(__wrap_CanSchedSrs_SetFilterBlocking, true);
  will_return(__wrap_CanSchedSrs_SendNonBlocking, 0);
  
  will_return(__wrap_RCL_Init, 0);

  will_return(__wrap___sc_msgRx, &sc_can_msg);
  will_return(__wrap_CopyMsgFromTxQueueToCAN, 0);
  will_return(__wrap___sc_tickGet, 1250);
  will_return(__wrap___sc_tickTick2Ms, 1);
  will_return(__wrap___sc_tickMs2Tick, 251);
  will_return(__wrap___sc_sleep, 0);
  
  will_return(__wrap_HlpProc_AlwaysTrue, true);
  will_return(__wrap_HlpProc_AlwaysTrue, false);

  _logdInitialized = false;
  ProcRsdProcess_Process();

  (void) state;
}

//! @brief Check if can messages from the car bus are correctly handled
static void test_check_handling_unknown_sciopta_messages_sc_msg(void** state)
{
  union sc_msg sc_can_msg;
  
  sc_can_msg.scMsgId = 0;

  will_return(__wrap_CanSchedSrs_AllocFilter, true);
  will_return(__wrap_CanSchedSrs_SetFilterBlocking, true);
  will_return(__wrap_CanSchedSrs_SendNonBlocking, 0);
  
  will_return(__wrap_RCL_Init, 0);

  will_return(__wrap___sc_msgRx, &sc_can_msg);
  expect_function_call(__wrap_HlpMsg_Unexpected);
  will_return(__wrap_CopyMsgFromTxQueueToCAN, 0);
  will_return(__wrap___sc_tickGet, 2500);
  will_return(__wrap___sc_tickTick2Ms, 1);
  will_return(__wrap___sc_tickMs2Tick, 501);
  will_return(__wrap___sc_sleep, 0);
  
  will_return(__wrap_HlpProc_AlwaysTrue, true);
  will_return(__wrap_HlpProc_AlwaysTrue, false);

  _logdInitialized = false;
  ProcRsdProcess_Process();
  
  (void) state;
}


int main(void)
{
    int retval = 0;

    printf("Starting main()\n");
    
#ifdef CMOCKA_DIAB
    putenv("CMOCKA_XML_FILE=src_pcb_proc_RsdProcess.xml"); // environment variable for XML file when running on PPC
#endif

    const struct CMUnitTest tests[] =
    {
      cmocka_unit_test(test_check_handling_can_messages_sc_msg),
      cmocka_unit_test(test_check_handling_unknown_sciopta_messages_sc_msg)
    };

    cmocka_set_message_output(CM_OUTPUT_XML);

    retval =  cmocka_run_group_tests_name("src_pcb_proc_RsdProcess", tests, NULL, NULL);
    
#ifdef CMOCKA_DIAB
    read_xml_file("src_pcb_proc_RsdProcess.xml"); // extract XML test results from file in RAM when running on PPC
#endif

    return retval;
}

//!@name Stubbed RSD Library Functions
//!{

void __wrap_LSMin_Initialize(uint16_t uiPcbType, uint16_t uiNodeAddr, uint16_t uiOtherAddr)
{

}

void __wrap_LS_AcknowledgeStartup(void)
{

}

void __wrap_LS_Receive(const uint8_t sourceid, const uint8_t port,const uint8_t *data, const uint16_t length)
{

}

uint8_t __wrap_LS_LoaderSlave(void)
{
  //return (uint8_t)mock();
  return 0;
}


//!}

//!@name Stubbed CanSched Functions
//!{
sc_pid_t __wrap_CanSchedCanSched_GetPid(void)
{
  return 0;
}

CanSchedTypes_Error_E __wrap_CanSchedSrs_AllocFilter(sc_pid_t                         canSchedPid,
                                                     CanSchedTypes_CanChannel_T       channel,
                                                     CanSchedTypes_CanFilterIndex_T * pFilterIndex)
{
  return (CanSchedTypes_Error_E) mock();
}

CanSchedTypes_Error_E __wrap_CanSchedSrs_SetFilterBlocking(sc_pid_t                          canSchedPid,
                                                           CanSchedTypes_CanChannel_T        channel,
                                                           CanSchedTypes_CanFilterIndex_T    filterIndex,
                                                           size_t                            filterListLength,
                                                           const CanSchedTypes_CanFilter_S * pFilterList)
{
  return (CanSchedTypes_Error_E) mock();
}

CanSchedTypes_Error_E __wrap_CanSchedSrs_SendNonBlocking(   sc_pid_t                       canSchedPid,
                                                            CanSchedTypes_CanChannel_T     channel,
                                                            const CanSchedTypes_CanMsg_S * pCanMsg)
{
  return (CanSchedTypes_Error_E) mock();
}

//!}


//!@name Stubbed Sciopta Functions
//!{

uint64_t __wrap___sc_msgFree(sc_msg_t * msgPtr)
{
  return 0;
}

sc_msg_t __wrap___sc_msgRx()
{
//  static CanSchedMsgs_ScMsgRcvNotify_S retVal;
//  return (sc_msg_t)&retVal;
  return (sc_msg_t) mock();         /* dequeue second value */
}

sc_time_t __wrap___sc_tickMs2Tick (uint32_t ms)
{
  return (sc_time_t) mock();
}
//!}


//!@name Stubbed Helper Functions
//!{

void __wrap_HlpFailure_EndlessLoopBusy(void)
{
  function_called();
}

bool __wrap_HlpProc_AlwaysTrue(void)
{
  return (bool) mock();
}

sc_msg_t __wrap_HlpMsg_RxAny(const sc_ticks_t tmo)
{
  return (sc_msg_t) mock();
}

extern void __wrap_HlpFailure_EndlessLoop(void)
{
  function_called();
}

extern void __wrap_HlpFailure_EndlessLoopSleepingMsg(sc_ticks_t interval, logd_t * logd, const char * msg)
{
  function_called();
}

extern void __wrap_HlpProcVar_Init(const char * procName, size_t additional)
{
  assert_true(_logdInitialized == false);
  _logd = logd_new("scpLogd", 0, procName, SC_DEFAULT_POOL, SC_NO_TMO);
  _logdInitialized = true;
}

extern logd_t * __wrap_HlpProcVar_GetLogd()
{
  assert_true(_logdInitialized == true);
  return _logd;
}



//!}

void __wrap_logd_printf(const char *fmt)
{
  if(fmt != NULL)
  {
    printf(fmt);
  }
}


logd_t * __wrap_logd_new(const char *logdProcessName,
                         int levelMax, 
                         const char *appl,
                         sc_poolid_t plid,
                         sc_ticks_t tmo)
{
  return 0;
}

sc_time_t __wrap___sc_tickGet(void)
{
  return (sc_time_t) mock();  
}

uint32_t __wrap___sc_tickTick2Ms(sc_ticks_t t)
{
  (void)t;
  return  (uint32_t) mock();
}

sc_time_t __wrap___sc_sleep(sc_ticks_t tmo)
{
  (void)tmo;
  return (sc_time_t) mock();
}

void __wrap_DriverInitRx(void)
{
}

void __wrap_DriverInitTx(void)
{
}

void __wrap_OPB_RxDbcMsg(unsigned char bBusNum, CDRV_RX_MSG *pstCanRxMsg)
{
  (void)bBusNum;
  (void)pstCanRxMsg;
}

CDRV_RX_MSG_INTERNAL* __wrap_CDRV_GetRxMsg(void)
{
  static CDRV_RX_MSG_INTERNAL s_internalMsg;
  return &s_internalMsg;
}

CdrvRtn __wrap_CDRV_Send(uint8_t uiBusIndex, PCDRV_MSG pstCanMsg)
{
  (void)uiBusIndex;
  (void)pstCanMsg;
  return (CdrvRtn) mock();
}

bool __wrap_CDRV_ReleaseRxMsg()
{
  return true;
}

unsigned int  __wrap_RCL_Init(unsigned int uiCarNumber,   unsigned int uiTransportType, unsigned int uiTransportMode,
                UINT_PFUNC_DBC_BUFFER pfTransportTx, UINT_PFUNC_DBC_BUFFER *pfTransportRx)
{
  (void)uiCarNumber;
  (void)uiTransportType;
  (void)uiTransportMode;
  (void)pfTransportTx;
  (void)pfTransportRx;
  return (unsigned int) mock();
}

void __wrap_RCL_RunThread(void)
{
}

void __wrap_DBC_RunThread(void)
{
}

CdrvRtn __wrap_CopyDataToRxQueue(CDRV_RX_MSG_INTERNAL *pstCanIntMessage)
{
  (void)pstCanIntMessage;
  return (CdrvRtn) mock();
}

CdrvRtn __wrap_CopyMsgFromTxQueueToCAN(uint8_t uiBusIndex, uint8_t bTxQueue, sc_pid_t canSchedPid)
{
  (void)uiBusIndex;
  (void)bTxQueue;
  (void)canSchedPid;
  return (CdrvRtn) mock();  
}


#!/bin/bash
STUBS+=("LSMin_Initialize")
STUBS+=("LS_LoaderSlave")

STUBS+=("CanSchedCanSched_GetPid")
STUBS+=("CanSchedSrs_AllocFilter")
STUBS+=("CanSchedSrs_SetFilterBlocking")
STUBS+=("CanSchedSrs_SendNonBlocking")

STUBS+=("logd_new")
STUBS+=("logd_printf")


STUBS+=("__sc_msgFree")
STUBS+=("__sc_msgRx")
STUBS+=("__sc_tickMs2Tick")

STUBS+=("HlpFailure_EndlessLoopSleepingMsg")
STUBS+=("HlpProc_AlwaysTrue")
STUBS+=("HlpMsg_Unexpected")

STUBS+=("HlpProcVar_Init")
STUBS+=("HlpProcVar_GetLogd")

STUBS+=("__sc_tickGet")
STUBS+=("__sc_tickTick2Ms")
STUBS+=("__sc_sleep")
STUBS+=("__sc_tickGet")

STUBS+=("DriverInitRx")
STUBS+=("DriverInitTx")
STUBS+=("OPB_RxDbcMsg")
STUBS+=("CDRV_GetRxMsg")
STUBS+=("CDRV_Send")
STUBS+=("CDRV_ReleaseRxMsg")
STUBS+=("RCL_Init")
STUBS+=("RCL_RunThread")
STUBS+=("DBC_RunThread")
STUBS+=("CopyDataToRxQueue")
STUBS+=("CopyMsgFromTxQueueToCAN")

STUB_WRAPS=${STUBS[@]/#/\-Wl,$2} # Diab wrap option syntax is different than GNU so pass in as parameter from make file

LINK+=("cmocka/wrap/common/Hlp/Msg.o")

LINK_OBJECT=${LINK[@]/#/$1}

shift 2

$* $LINK_OBJECT $STUB_WRAPS

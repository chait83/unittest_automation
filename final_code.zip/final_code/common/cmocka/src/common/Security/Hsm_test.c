// *****************************************************************************
// **                _______   _________  _________   _______                 **
// **               (  ___  )  \__   __/  \__   __/  (  ____ \                **
// **               | (   ) |     ) (        ) (     | (    \/                **
// **               | |   | |     | |        | |     | (_____                 **
// **               | |   | |     | |        | |     (_____  )                **
// **               | |   | |     | |        | |           ) |                **
// **               | (___) |     | |     ___) (___  /\____) |                **
// **               (_______)     )_(     \_______/  \_______)                **
// **                                                                         **
// **                        Lead Design Center Berlin                        **
// **                                                                         **
// **   Copyright 2021 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **
// **                                                                         **
// *****************************************************************************
//!
//! @file
//!
//! @brief cmocka test file for src/common/Security/Hsm.c
//!
// *****************************************************************************
#include <setjmp.h>
#include <stdio.h>
#include <inttypes.h>
#include <stdarg.h>
#include "cmocka.h"
#include "Crypto/ATECC508.h"
#include "Security/Hsm.h"
#include "Security/HsmHelper.h"



//! @brief wrapper function for hsmInternalCheckParams()
extern int8_t __wrap_hsmInternalCheckParams(const logd_t* const logd, const hsmParam_S *const pParam);
//! @brief callback for real function of hsmInternalCheckParams()
extern int8_t __real_hsmInternalCheckParams(const logd_t* const logd, const hsmParam_S *const pParam);

//! @brief wrapper function for SecurityHsm_CheckConfig()
extern int __wrap_SecurityHsm_CheckConfig(logd_t* const logd);
//! @brief callback for real function of SecurityHsm_CheckConfig()
extern int __real_SecurityHsm_CheckConfig(logd_t* const logd);

//! @brief wrapper function for SecurityHsm_GetConfig()
extern int __wrap_SecurityHsm_GetConfig(logd_t* const logd, hsmConfig_S* const hsmCfg);
//! @brief callback for real function of SecurityHsm_GetConfig()
extern int __real_SecurityHsm_GetConfig(logd_t* const logd, hsmConfig_S* const hsmCfg);

//! @brief wrapper function for hsmInternalCommSync()
extern int8_t __wrap_hsmInternalCommSync(void);
//! @brief callback for real function of hsmInternalCommSync()
extern int8_t __real_hsmInternalCommSync(void);

//! @brief wrapper function for hsmInternalCompareConfiguration()
extern bool __wrap_hsmInternalCompareConfiguration(const hsmConfig_S* const hsmCfgCurrent, const hsmConfig_S* const hsmCfgExpected);
//! @brief callback for real function of hsmInternalCompareConfiguration()
extern bool __real_hsmInternalCompareConfiguration(const hsmConfig_S* const hsmCfgCurrent, const hsmConfig_S* const hsmCfgExpected);



static logd_t  logd;


//! @note the contents here are just an example for testing the implementation, they not necessarily need to represent the real configuration
static const hsmConfig_S  hsmDefaultConfig =
{
  .hsmType = HSM_TYPE_eATECC508A,
  .cfg =
  {
    .atecc508Cfg =
    {
      .i2cAddr  = 0xC0,  // I2C address shifted 1 bit right (0x60)
      .otpMode  = 0xAA,  // read-only mode for OTP
      .chipMode = 0x01,  // WatchdogDuration=0 (1.3 sec), TTLenable=0 (uses fixed reference), SelectorMode=1 (can only be written if it is zero)
      .lastKeyUse =
      {
        0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,  // limited use control (128 times) for key-id 15
        0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
      },
      .x509Format =
      {
        0x00, 0x00, 0x00, 0x00,  // ignore formatting restrictions for X.509 certificates
      },
      .slotCfg[0] =  // polyspace MISRA-C3:9.3 [Not a defect:Low] "other entries are not used and set to zero"
      {
        0x81,  // LSB, IsSecret=1, EncryptRead=0, LimitedUse=0, NoMac=0, ReadKey=1 (External signatures of arbitrary messages enabled)
        0x20,  // MSB, WriteConfig=2 (use Encrypted mode for Write command), WriteKey=0
      },
      .keyCfg[0] =  // polyspace MISRA-C3:9.3 [Not a defect:Low] "other entries are not used and set to zero"
      {
        0x33,  // LSB, Private=1, PubInfo=1 (can generate pubkey), KeyType=P256 NIST ECC key, Lockable=1, ReqRandom=0, ReqAuth=0
        0x00,  // MSB, AuthKey=0, IntrusionDisable=0, X509id=0
      },
      .slotCfg[8] =  // polyspace MISRA-C3:9.3 [Not a defect:Low] "other entries are not used and set to zero"
      {
        0x00,  // LSB, IsSecret=0, EncryptRead=0, LimitedUse=0, NoMac=0, ReadKey=0
        0x00,  // MSB, WriteConfig=0, WriteKey=0
      },
      .keyCfg[8] =  // polyspace MISRA-C3:9.3 [Not a defect:Low] "other entries are not used and set to zero"
      {
        0x3C,  // LSB, Private=0, PubInfo=0, KeyType=not an ECC key, Lockable=1, ReqRandom=0, ReqAuth=0
        0x00,  // MSB, AuthKey=0, IntrusionDisable=0, X509id=0
      },
      .slotCfg[9] =  // polyspace MISRA-C3:9.3 [Not a defect:Low] "other entries are not used and set to zero"
      {
        0x80,  // LSB, IsSecret=1, EncryptRead=0, LimitedUse=0, NoMac=0, ReadKey=0
        0x20,  // MSB, WriteConfig=2 (use Encrypted mode for Write command), WriteKey=0
      },
      .keyCfg[9] =  // polyspace MISRA-C3:9.3 [Not a defect:Low] "other entries are not used and set to zero"
      {
        0x30,  // LSB, Private=0, PubInfo=0, KeyType=P256 NIST ECC key, Lockable=1, ReqRandom=0, ReqAuth=0
        0x00,  // MSB, AuthKey=0, IntrusionDisable=0, X509id=0
      },
    },
  },
};


//! @brief  SecurityHsm_SetConfig successful
static void test_SecurityHsm_SetConfig_01(void)
{
  size_t  i;

  will_return(__wrap_hsmInternalCommSync, true);  // mock
  will_return(__wrap_hsmInternalCommSync, 0);  // success
  expect_function_calls(__wrap_hsmInternalCommSync, 1);

  for ( i = 0; i < 16U; ++i )
  {
    will_return(__wrap_ATECC508_writeSlotCfg, ATECC508_ERROR_SUCCESS);  // success
    will_return(__wrap_ATECC508_writeKeyCfg, ATECC508_ERROR_SUCCESS);  // success
  }

  will_return(__wrap_ATECC508_GoIdle, ATECC508_ERROR_SUCCESS);  // success
  will_return(__wrap_ATECC508_WakeUp, ATECC508_ERROR_SUCCESS);  // success

  for ( i = 0; i < 7U; ++i )
  {
    will_return(__wrap_ATECC508_writeData, ATECC508_ERROR_SUCCESS);  // success
  }

  assert_int_equal(SecurityHsm_SetConfig(&logd), 0);  // success
}

//! @brief  hsmInternalCommSync fails
static void test_SecurityHsm_SetConfig_02(void)
{
  will_return(__wrap_hsmInternalCommSync, true);  // mock
  will_return(__wrap_hsmInternalCommSync, -1);  // fail
  expect_function_calls(__wrap_hsmInternalCommSync, 1);

  assert_int_equal(SecurityHsm_SetConfig(&logd), -1);  // fail
}

//! @brief  ATECC508_writeSlotCfg fails
static void test_SecurityHsm_SetConfig_03(void)
{
  will_return(__wrap_hsmInternalCommSync, true);  // mock
  will_return(__wrap_hsmInternalCommSync, 0);  // success
  expect_function_calls(__wrap_hsmInternalCommSync, 1);

  will_return(__wrap_ATECC508_writeSlotCfg, ATECC508_ERROR_TIMEOUT);  // fail

  assert_int_equal(SecurityHsm_SetConfig(&logd), -2);  // fail
}

//! @brief  ATECC508_writeKeyCfg fails
static void test_SecurityHsm_SetConfig_04(void)
{
  will_return(__wrap_hsmInternalCommSync, true);  // mock
  will_return(__wrap_hsmInternalCommSync, 0);  // success
  expect_function_calls(__wrap_hsmInternalCommSync, 1);

  will_return(__wrap_ATECC508_writeSlotCfg, ATECC508_ERROR_SUCCESS);  // success
  will_return(__wrap_ATECC508_writeKeyCfg, ATECC508_ERROR_TIMEOUT);  // fail

  assert_int_equal(SecurityHsm_SetConfig(&logd), -2);  // fail
}

//! @brief  ATECC508_GoIdle fails
static void test_SecurityHsm_SetConfig_05(void)
{
  size_t  i;

  will_return(__wrap_hsmInternalCommSync, true);  // mock
  will_return(__wrap_hsmInternalCommSync, 0);  // success
  expect_function_calls(__wrap_hsmInternalCommSync, 1);

  for ( i = 0; i < 16U; ++i )
  {
    will_return(__wrap_ATECC508_writeSlotCfg, ATECC508_ERROR_SUCCESS);  // success
    will_return(__wrap_ATECC508_writeKeyCfg, ATECC508_ERROR_SUCCESS);  // success
  }

  will_return(__wrap_ATECC508_GoIdle, ATECC508_ERROR_TIMEOUT);  // fail

  assert_int_equal(SecurityHsm_SetConfig(&logd), -1);  // fail
}

//! @brief  ATECC508_WakeUp fails
static void test_SecurityHsm_SetConfig_06(void)
{
  size_t  i;

  will_return(__wrap_hsmInternalCommSync, true);  // mock
  will_return(__wrap_hsmInternalCommSync, 0);  // success
  expect_function_calls(__wrap_hsmInternalCommSync, 1);

  for ( i = 0; i < 16U; ++i )
  {
    will_return(__wrap_ATECC508_writeSlotCfg, ATECC508_ERROR_SUCCESS);  // success
    will_return(__wrap_ATECC508_writeKeyCfg, ATECC508_ERROR_SUCCESS);  // success
  }

  will_return(__wrap_ATECC508_GoIdle, ATECC508_ERROR_SUCCESS);  // success
  will_return(__wrap_ATECC508_WakeUp, ATECC508_ERROR_TIMEOUT);  // fail

  assert_int_equal(SecurityHsm_SetConfig(&logd), -1);  // fail
}

//! @brief  ATECC508_writeData fails
//! @param[in]  n  specifies that the n'th call to ATECC508_writeData() should fail, allowed range: 0 <= n < 7
static void test_SecurityHsm_SetConfig_07(const size_t n)
{
  size_t  i;

  will_return(__wrap_hsmInternalCommSync, true);  // mock
  will_return(__wrap_hsmInternalCommSync, 0);  // success
  expect_function_calls(__wrap_hsmInternalCommSync, 1);

  for ( i = 0; i < 16U; ++i )
  {
    will_return(__wrap_ATECC508_writeSlotCfg, ATECC508_ERROR_SUCCESS);  // success
    will_return(__wrap_ATECC508_writeKeyCfg, ATECC508_ERROR_SUCCESS);  // success
  }

  will_return(__wrap_ATECC508_GoIdle, ATECC508_ERROR_SUCCESS);  // success
  will_return(__wrap_ATECC508_WakeUp, ATECC508_ERROR_SUCCESS);  // success

  for ( i = 0; i < 7U; ++i )
  {
    if ( n == i )
    {
      will_return(__wrap_ATECC508_writeData, ATECC508_ERROR_TIMEOUT);  // fail
      break;
    }
    will_return(__wrap_ATECC508_writeData, ATECC508_ERROR_SUCCESS);  // success
  }

  assert_int_equal(SecurityHsm_SetConfig(&logd), -2);  // fail
}

static void test_SecurityHsm_SetConfig(void** state)
{
  size_t  n;

  test_SecurityHsm_SetConfig_01();
  test_SecurityHsm_SetConfig_02();
  test_SecurityHsm_SetConfig_03();
  test_SecurityHsm_SetConfig_04();
  test_SecurityHsm_SetConfig_05();
  test_SecurityHsm_SetConfig_06();

  for ( n = 0; n < 7U; ++n )
  {
    test_SecurityHsm_SetConfig_07(n);
  }

  (void) state;
}


//! @brief  SecurityHsm_SetLock LOCK_ZONE_CONFIG successful
static void test_SecurityHsm_SetLock_01a(void)
{
  hsmParams_S  param = {.paramType = HSM_PARAM_TYPE_eLOCK, .param.hsmLock.zone = LOCK_ZONE_CONFIG};

  param.param.hsmLock.isLocked = false;  // should toggle

  will_return(__wrap_hsmInternalCommSync, true);  // mock
  will_return(__wrap_hsmInternalCommSync, 0);  // success
  expect_function_calls(__wrap_hsmInternalCommSync, 1);

  will_return(__wrap_ATECC508_lockCfg, ATECC508_ERROR_SUCCESS);  // success

  assert_int_equal(SecurityHsm_SetLock(&logd, &param), 0);  // success
  assert_true(param.param.hsmLock.isLocked);  // locked
}

//! @brief  SecurityHsm_SetLock LOCK_ZONE_DATA successful
static void test_SecurityHsm_SetLock_01b(void)
{
  hsmParams_S  param = {.paramType = HSM_PARAM_TYPE_eLOCK, .param.hsmLock.zone = LOCK_ZONE_DATA};

  param.param.hsmLock.isLocked = false;  // should toggle

  will_return(__wrap_hsmInternalCommSync, true);  // mock
  will_return(__wrap_hsmInternalCommSync, 0);  // success
  expect_function_calls(__wrap_hsmInternalCommSync, 1);

  will_return(__wrap_ATECC508_lockDev, ATECC508_ERROR_SUCCESS);  // success

  assert_int_equal(SecurityHsm_SetLock(&logd, &param), 0);  // success
  assert_true(param.param.hsmLock.isLocked);  // locked
}

//! @brief  SecurityHsm_SetLock LOCK_ZONE_DATA_SLOT successful
static void test_SecurityHsm_SetLock_01c(void)
{
  hsmParams_S  param = {.paramType = HSM_PARAM_TYPE_eLOCK, .param.hsmLock.zone = LOCK_ZONE_DATA_SLOT, .param.hsmLock.slotID = 3};

  param.param.hsmLock.isLocked = false;  // should toggle

  will_return(__wrap_hsmInternalCommSync, true);  // mock
  will_return(__wrap_hsmInternalCommSync, 0);  // success
  expect_function_calls(__wrap_hsmInternalCommSync, 1);

  will_return(__wrap_ATECC508_lockSlot, ATECC508_ERROR_SUCCESS);  // success

  assert_int_equal(SecurityHsm_SetLock(&logd, &param), 0);  // success
  assert_true(param.param.hsmLock.isLocked);  // locked
}

//! @brief  hsmInternalCommSync fails
static void test_SecurityHsm_SetLock_02(void)
{
  hsmParams_S  param = {.paramType = HSM_PARAM_TYPE_eLOCK, .param.hsmLock.zone = LOCK_ZONE_CONFIG};

  param.param.hsmLock.isLocked = true;  // should toggle

  will_return(__wrap_hsmInternalCommSync, true);  // mock
  will_return(__wrap_hsmInternalCommSync, -1);  // fail
  expect_function_calls(__wrap_hsmInternalCommSync, 1);

  assert_int_equal(SecurityHsm_SetLock(&logd, &param), -2);  // fail
  assert_false(param.param.hsmLock.isLocked);  // fail safe
}

//! @brief  ATECC508_lockCfg fails
static void test_SecurityHsm_SetLock_03a(void)
{
  hsmParams_S  param = {.paramType = HSM_PARAM_TYPE_eLOCK, .param.hsmLock.zone = LOCK_ZONE_CONFIG};

  param.param.hsmLock.isLocked = true;  // should toggle

  will_return(__wrap_hsmInternalCommSync, true);  // mock
  will_return(__wrap_hsmInternalCommSync, 0);  // success
  expect_function_calls(__wrap_hsmInternalCommSync, 1);

  will_return(__wrap_ATECC508_lockCfg, ATECC508_ERROR_TIMEOUT);  // success

  assert_int_equal(SecurityHsm_SetLock(&logd, &param), -1);  // fail
  assert_false(param.param.hsmLock.isLocked);  // fail safe
}

//! @brief  ATECC508_lockDev fails
static void test_SecurityHsm_SetLock_03b(void)
{
  hsmParams_S  param = {.paramType = HSM_PARAM_TYPE_eLOCK, .param.hsmLock.zone = LOCK_ZONE_DATA};

  param.param.hsmLock.isLocked = true;  // should toggle

  will_return(__wrap_hsmInternalCommSync, true);  // mock
  will_return(__wrap_hsmInternalCommSync, 0);  // success
  expect_function_calls(__wrap_hsmInternalCommSync, 1);

  will_return(__wrap_ATECC508_lockDev, ATECC508_ERROR_TIMEOUT);  // success

  assert_int_equal(SecurityHsm_SetLock(&logd, &param), -1);  // fail
  assert_false(param.param.hsmLock.isLocked);  // fail safe
}

//! @brief  ATECC508_lockSlot fails
static void test_SecurityHsm_SetLock_03c(void)
{
  hsmParams_S  param = {.paramType = HSM_PARAM_TYPE_eLOCK, .param.hsmLock.zone = LOCK_ZONE_DATA_SLOT, .param.hsmLock.slotID = 3};

  param.param.hsmLock.isLocked = true;  // should toggle

  will_return(__wrap_hsmInternalCommSync, true);  // mock
  will_return(__wrap_hsmInternalCommSync, 0);  // success
  expect_function_calls(__wrap_hsmInternalCommSync, 1);

  will_return(__wrap_ATECC508_lockSlot, ATECC508_ERROR_TIMEOUT);  // fail

  assert_int_equal(SecurityHsm_SetLock(&logd, &param), -1);  // fail
  assert_false(param.param.hsmLock.isLocked);  // fail safe
}

//! @brief  bad paramtype
static void test_SecurityHsm_SetLock_04(void)
{
  hsmParams_S  param = {.paramType = HSM_PARAM_TYPE_ePUBKEY, .param.hsmLock.zone = LOCK_ZONE_CONFIG};

  param.param.hsmLock.isLocked = true;  // should toggle

  assert_int_equal(SecurityHsm_SetLock(&logd, &param), -1);  // fail
  assert_false(param.param.hsmLock.isLocked);  // fail safe
}

//! @brief  NULL-pointer arg
static void test_SecurityHsm_SetLock_05(void)
{
  hsmParams_S  param = {.paramType = HSM_PARAM_TYPE_eLOCK, .param.hsmLock.zone = LOCK_ZONE_CONFIG};

  param.param.hsmLock.isLocked = true;  // should toggle
  assert_int_equal(SecurityHsm_SetLock(NULL, &param), -1);  // fail
  assert_false(param.param.hsmLock.isLocked);  // fail safe

  assert_int_equal(SecurityHsm_SetLock(&logd, NULL), -1);  // fail

  assert_int_equal(SecurityHsm_SetLock(NULL, NULL), -1);  // fail
}

//! @brief  bad slot-no.
static void test_SecurityHsm_SetLock_06(void)
{
  hsmParams_S  param = {.paramType = HSM_PARAM_TYPE_eLOCK, .param.hsmLock.zone = LOCK_ZONE_DATA_SLOT, .param.hsmLock.slotID = 22};

  param.param.hsmLock.isLocked = true;  // should toggle

  will_return(__wrap_hsmInternalCommSync, true);  // mock
  will_return(__wrap_hsmInternalCommSync, 0);  // success
  expect_function_calls(__wrap_hsmInternalCommSync, 1);

  assert_int_equal(SecurityHsm_SetLock(&logd, &param), -1);  // fail
  assert_false(param.param.hsmLock.isLocked);  // fail safe
}

//! @brief  bad zone
static void test_SecurityHsm_SetLock_07(void)
{
  hsmParams_S  param = {.paramType = HSM_PARAM_TYPE_eLOCK, .param.hsmLock.zone = 255, .param.hsmLock.slotID = 0};

  param.param.hsmLock.isLocked = true;  // should toggle

  will_return(__wrap_hsmInternalCommSync, true);  // mock
  will_return(__wrap_hsmInternalCommSync, 0);  // success
  expect_function_calls(__wrap_hsmInternalCommSync, 1);

  assert_int_equal(SecurityHsm_SetLock(&logd, &param), -1);  // fail
  assert_false(param.param.hsmLock.isLocked);  // fail safe
}

static void test_SecurityHsm_SetLock(void** state)
{
  test_SecurityHsm_SetLock_01a();
  test_SecurityHsm_SetLock_01b();
  test_SecurityHsm_SetLock_01c();
  test_SecurityHsm_SetLock_02();
  test_SecurityHsm_SetLock_03a();
  test_SecurityHsm_SetLock_03b();
  test_SecurityHsm_SetLock_03c();
  test_SecurityHsm_SetLock_04();
  test_SecurityHsm_SetLock_05();
  test_SecurityHsm_SetLock_06();
  test_SecurityHsm_SetLock_07();

  (void) state;
}


//! @brief  SecurityHsm_GetLock LOCK_ZONE_CONFIG successful
static void test_SecurityHsm_GetLock_01a(void)
{
  hsmParams_S  param = {.paramType = HSM_PARAM_TYPE_eLOCK, .param.hsmLock.zone = LOCK_ZONE_CONFIG};

  param.param.hsmLock.isLocked = false;  // should toggle

  will_return(__wrap_hsmInternalCommSync, true);  // mock
  will_return(__wrap_hsmInternalCommSync, 0);  // success
  expect_function_calls(__wrap_hsmInternalCommSync, 1);

  will_return(__wrap_ATECC508_readCfgLock, ATECC508_ERROR_SUCCESS);  // success
  will_return(__wrap_ATECC508_readCfgLock, true);  // locked

  assert_int_equal(SecurityHsm_GetLock(&logd, &param), 0);  // success
  assert_true(param.param.hsmLock.isLocked);  // locked
}

//! @brief  SecurityHsm_GetLock LOCK_ZONE_DATA successful
static void test_SecurityHsm_GetLock_01b(void)
{
  hsmParams_S  param = {.paramType = HSM_PARAM_TYPE_eLOCK, .param.hsmLock.zone = LOCK_ZONE_DATA};

  param.param.hsmLock.isLocked = false;  // should toggle

  will_return(__wrap_hsmInternalCommSync, true);  // mock
  will_return(__wrap_hsmInternalCommSync, 0);  // success
  expect_function_calls(__wrap_hsmInternalCommSync, 1);

  will_return(__wrap_ATECC508_readDevLock, ATECC508_ERROR_SUCCESS);  // success
  will_return(__wrap_ATECC508_readDevLock, true);  // locked

  assert_int_equal(SecurityHsm_GetLock(&logd, &param), 0);  // success
  assert_true(param.param.hsmLock.isLocked);  // locked
}

//! @brief  SecurityHsm_GetLock LOCK_ZONE_DATA_SLOT successful
static void test_SecurityHsm_GetLock_01c(void)
{
  hsmParams_S  param = {.paramType = HSM_PARAM_TYPE_eLOCK, .param.hsmLock.zone = LOCK_ZONE_DATA_SLOT, .param.hsmLock.slotID = 3};

  param.param.hsmLock.isLocked = false;  // should toggle

  will_return(__wrap_hsmInternalCommSync, true);  // mock
  will_return(__wrap_hsmInternalCommSync, 0);  // success
  expect_function_calls(__wrap_hsmInternalCommSync, 1);

  will_return(__wrap_ATECC508_readSlotLock, ATECC508_ERROR_SUCCESS);  // success
  will_return(__wrap_ATECC508_readSlotLock, true);  // locked

  assert_int_equal(SecurityHsm_GetLock(&logd, &param), 0);  // success
  assert_true(param.param.hsmLock.isLocked);  // locked
}

//! @brief  hsmInternalCommSync fails
static void test_SecurityHsm_GetLock_02(void)
{
  hsmParams_S  param = {.paramType = HSM_PARAM_TYPE_eLOCK, .param.hsmLock.zone = LOCK_ZONE_CONFIG};

  param.param.hsmLock.isLocked = true;  // should toggle

  will_return(__wrap_hsmInternalCommSync, true);  // mock
  will_return(__wrap_hsmInternalCommSync, -1);  // fail
  expect_function_calls(__wrap_hsmInternalCommSync, 1);

  assert_int_equal(SecurityHsm_GetLock(&logd, &param), -2);  // fail
  assert_false(param.param.hsmLock.isLocked);  // fail safe
}

//! @brief  ATECC508_readCfgLock fails
static void test_SecurityHsm_GetLock_03(void)
{
  hsmParams_S  param = {.paramType = HSM_PARAM_TYPE_eLOCK, .param.hsmLock.zone = LOCK_ZONE_CONFIG};

  param.param.hsmLock.isLocked = true;  // should toggle

  will_return(__wrap_hsmInternalCommSync, true);  // mock
  will_return(__wrap_hsmInternalCommSync, 0);  // success
  expect_function_calls(__wrap_hsmInternalCommSync, 1);

  will_return(__wrap_ATECC508_readCfgLock, ATECC508_ERROR_TIMEOUT);  // fail
  will_return(__wrap_ATECC508_readCfgLock, true);  // report wrong locked value

  assert_int_equal(SecurityHsm_GetLock(&logd, &param), -1);  // fail
  assert_false(param.param.hsmLock.isLocked);  // fail safe
}

//! @brief  bad paramtype
static void test_SecurityHsm_GetLock_04(void)
{
  hsmParams_S  param = {.paramType = HSM_PARAM_TYPE_ePUBKEY, .param.hsmLock.zone = LOCK_ZONE_CONFIG};

  param.param.hsmLock.isLocked = true;  // should toggle

  assert_int_equal(SecurityHsm_GetLock(&logd, &param), -1);  // fail
  assert_false(param.param.hsmLock.isLocked);  // fail safe
}

//! @brief  NULL-pointer arg
static void test_SecurityHsm_GetLock_05(void)
{
  hsmParams_S  param = {.paramType = HSM_PARAM_TYPE_eLOCK, .param.hsmLock.zone = LOCK_ZONE_CONFIG};

  param.param.hsmLock.isLocked = true;  // should toggle
  assert_int_equal(SecurityHsm_GetLock(NULL, &param), -1);  // fail
  assert_false(param.param.hsmLock.isLocked);  // fail safe

  assert_int_equal(SecurityHsm_GetLock(&logd, NULL), -1);  // fail

  assert_int_equal(SecurityHsm_GetLock(NULL, NULL), -1);  // fail
}

//! @brief  bad slot-no.
static void test_SecurityHsm_GetLock_06(void)
{
  hsmParams_S  param = {.paramType = HSM_PARAM_TYPE_eLOCK, .param.hsmLock.zone = LOCK_ZONE_DATA_SLOT, .param.hsmLock.slotID = 22};

  param.param.hsmLock.isLocked = true;  // should toggle

  will_return(__wrap_hsmInternalCommSync, true);  // mock
  will_return(__wrap_hsmInternalCommSync, 0);  // success
  expect_function_calls(__wrap_hsmInternalCommSync, 1);

  assert_int_equal(SecurityHsm_GetLock(&logd, &param), -1);  // fail
  assert_false(param.param.hsmLock.isLocked);  // fail safe
}

//! @brief  bad zone
static void test_SecurityHsm_GetLock_07(void)
{
  hsmParams_S  param = {.paramType = HSM_PARAM_TYPE_eLOCK, .param.hsmLock.zone = 255, .param.hsmLock.slotID = 0};

  param.param.hsmLock.isLocked = true;  // should toggle

  will_return(__wrap_hsmInternalCommSync, true);  // mock
  will_return(__wrap_hsmInternalCommSync, 0);  // success
  expect_function_calls(__wrap_hsmInternalCommSync, 1);

  assert_int_equal(SecurityHsm_GetLock(&logd, &param), -1);  // fail
  assert_false(param.param.hsmLock.isLocked);  // fail safe
}

static void test_SecurityHsm_GetLock(void** state)
{
  test_SecurityHsm_GetLock_01a();
  test_SecurityHsm_GetLock_01b();
  test_SecurityHsm_GetLock_01c();
  test_SecurityHsm_GetLock_02();
  test_SecurityHsm_GetLock_03();
  test_SecurityHsm_GetLock_04();
  test_SecurityHsm_GetLock_05();
  test_SecurityHsm_GetLock_06();
  test_SecurityHsm_GetLock_07();

  (void) state;
}


//! @brief  SecurityHsm_GetConfig successful
static void test_SecurityHsm_GetConfig_01(void)
{
  hsmConfig_S  param = {0};
  size_t  i;

  will_return(__wrap_hsmInternalCommSync, true);  // mock
  will_return(__wrap_hsmInternalCommSync, 0);  // success
  expect_function_calls(__wrap_hsmInternalCommSync, 1);

  for ( i = 0; i < 16U; ++i )
  {
    will_return(__wrap_ATECC508_readSlotCfg, ATECC508_ERROR_SUCCESS);  // success
    will_return(__wrap_ATECC508_readKeyCfg, ATECC508_ERROR_SUCCESS);  // success
  }

  will_return(__wrap_ATECC508_GoIdle, ATECC508_ERROR_SUCCESS);  // success
  will_return(__wrap_ATECC508_WakeUp, ATECC508_ERROR_SUCCESS);  // success

  for ( i = 0; i < 7U; ++i )
  {
    will_return(__wrap_ATECC508_readData, ATECC508_ERROR_SUCCESS);  // success
  }

  will_return(__wrap_SecurityHsm_GetConfig, false);  // do not mock
  assert_int_equal(SecurityHsm_GetConfig(&logd, &param), 0);  // success
  assert_true(HSM_TYPE_eATECC508A == param.hsmType);  // match
}

//! @brief  hsmInternalCommSync fails
static void test_SecurityHsm_GetConfig_02(void)
{
  hsmConfig_S  param = {0};

  will_return(__wrap_hsmInternalCommSync, true);  // mock
  will_return(__wrap_hsmInternalCommSync, -1);  // fail
  expect_function_calls(__wrap_hsmInternalCommSync, 1);

  will_return(__wrap_SecurityHsm_GetConfig, false);  // do not mock
  assert_int_equal(SecurityHsm_GetConfig(&logd, &param), -1);  // fail
}

//! @brief  ATECC508_readSlotCfg fails
//! @param[in]  n  specifies that the n'th call to ATECC508_readSlotCfg() should fail, allowed range: 0 <= n < 16
static void test_SecurityHsm_GetConfig_03(const size_t n)
{
  hsmConfig_S  param = {0};
  size_t  i;

  will_return(__wrap_hsmInternalCommSync, true);  // mock
  will_return(__wrap_hsmInternalCommSync, 0);  // success
  expect_function_calls(__wrap_hsmInternalCommSync, 1);

  for ( i = 0; i < 16U; ++i )
  {
    if ( n == i )
    {
      will_return(__wrap_ATECC508_readSlotCfg, ATECC508_ERROR_TIMEOUT);  // fail
      break;
    }
    will_return(__wrap_ATECC508_readSlotCfg, ATECC508_ERROR_SUCCESS);  // success
    will_return(__wrap_ATECC508_readKeyCfg, ATECC508_ERROR_SUCCESS);  // success
  }

  will_return(__wrap_SecurityHsm_GetConfig, false);  // do not mock
  assert_int_equal(SecurityHsm_GetConfig(&logd, &param), -2);  // fail
}

//! @brief  ATECC508_readKeyCfg fails
//! @param[in]  n  specifies that the n'th call to ATECC508_readKeyCfg() should fail, allowed range: 0 <= n < 16
static void test_SecurityHsm_GetConfig_04(const size_t n)
{
  hsmConfig_S  param = {0};
  size_t  i;

  will_return(__wrap_hsmInternalCommSync, true);  // mock
  will_return(__wrap_hsmInternalCommSync, 0);  // success
  expect_function_calls(__wrap_hsmInternalCommSync, 1);

  for ( i = 0; i < 16U; ++i )
  {
    if ( n == i )
    {
      will_return(__wrap_ATECC508_readSlotCfg, ATECC508_ERROR_SUCCESS);  // success
      will_return(__wrap_ATECC508_readKeyCfg, ATECC508_ERROR_TIMEOUT);  // fail
      break;
    }
    will_return(__wrap_ATECC508_readSlotCfg, ATECC508_ERROR_SUCCESS);  // success
    will_return(__wrap_ATECC508_readKeyCfg, ATECC508_ERROR_SUCCESS);  // success
  }

  will_return(__wrap_SecurityHsm_GetConfig, false);  // do not mock
  assert_int_equal(SecurityHsm_GetConfig(&logd, &param), -2);  // fail
}

//! @brief  ATECC508_GoIdle fails
static void test_SecurityHsm_GetConfig_05(void)
{
  hsmConfig_S  param = {0};
  size_t  i;

  will_return(__wrap_hsmInternalCommSync, true);  // mock
  will_return(__wrap_hsmInternalCommSync, 0);  // success
  expect_function_calls(__wrap_hsmInternalCommSync, 1);

  for ( i = 0; i < 16U; ++i )
  {
    will_return(__wrap_ATECC508_readSlotCfg, ATECC508_ERROR_SUCCESS);  // success
    will_return(__wrap_ATECC508_readKeyCfg, ATECC508_ERROR_SUCCESS);  // success
  }

  will_return(__wrap_ATECC508_GoIdle, ATECC508_ERROR_TIMEOUT);  // fail

  will_return(__wrap_SecurityHsm_GetConfig, false);  // do not mock
  assert_int_equal(SecurityHsm_GetConfig(&logd, &param), -2);  // fail
}

//! @brief  ATECC508_WakeUp fails
static void test_SecurityHsm_GetConfig_06(void)
{
  hsmConfig_S  param = {0};
  size_t  i;

  will_return(__wrap_hsmInternalCommSync, true);  // mock
  will_return(__wrap_hsmInternalCommSync, 0);  // success
  expect_function_calls(__wrap_hsmInternalCommSync, 1);

  for ( i = 0; i < 16U; ++i )
  {
    will_return(__wrap_ATECC508_readSlotCfg, ATECC508_ERROR_SUCCESS);  // success
    will_return(__wrap_ATECC508_readKeyCfg, ATECC508_ERROR_SUCCESS);  // success
  }

  will_return(__wrap_ATECC508_GoIdle, ATECC508_ERROR_SUCCESS);  // success
  will_return(__wrap_ATECC508_WakeUp, ATECC508_ERROR_TIMEOUT);  // fail

  will_return(__wrap_SecurityHsm_GetConfig, false);  // do not mock
  assert_int_equal(SecurityHsm_GetConfig(&logd, &param), -2);  // fail
}

//! @brief  ATECC508_readData fails
//! @param[in]  n  specifies that the n'th call to ATECC508_readData() should fail, allowed range: 0 <= n < 16
static void test_SecurityHsm_GetConfig_07(const size_t n)
{
  hsmConfig_S  param = {0};
  size_t  i;

  will_return(__wrap_hsmInternalCommSync, true);  // mock
  will_return(__wrap_hsmInternalCommSync, 0);  // success
  expect_function_calls(__wrap_hsmInternalCommSync, 1);

  for ( i = 0; i < 16U; ++i )
  {
    will_return(__wrap_ATECC508_readSlotCfg, ATECC508_ERROR_SUCCESS);  // success
    will_return(__wrap_ATECC508_readKeyCfg, ATECC508_ERROR_SUCCESS);  // success
  }

  will_return(__wrap_ATECC508_GoIdle, ATECC508_ERROR_SUCCESS);  // success
  will_return(__wrap_ATECC508_WakeUp, ATECC508_ERROR_SUCCESS);  // success

  for ( i = 0; i < 7U; ++i )
  {
    if ( n == i )
    {
      will_return (__wrap_ATECC508_readData, ATECC508_ERROR_TIMEOUT);  // fail
      break;
    }
    will_return(__wrap_ATECC508_readData, ATECC508_ERROR_SUCCESS);  // success
  }

  will_return(__wrap_SecurityHsm_GetConfig, false);  // do not mock
  assert_int_equal(SecurityHsm_GetConfig(&logd, &param), -2);  // fail
}

static void test_SecurityHsm_GetConfig(void** state)
{
  size_t  n;

  test_SecurityHsm_GetConfig_01();
  test_SecurityHsm_GetConfig_02();

  for ( n = 0; n < 16U; ++n )
  {
    test_SecurityHsm_GetConfig_03(n);
  }

  for ( n = 0; n < 16U; ++n )
  {
    test_SecurityHsm_GetConfig_04(n);
  }

  test_SecurityHsm_GetConfig_05();
  test_SecurityHsm_GetConfig_06();

  for ( n = 0; n < 7U; ++n )
  {
    test_SecurityHsm_GetConfig_07(n);
  }

  (void) state;
}


//! @brief  SecurityHsm_VerifySignatureExternal successful
static void test_SecurityHsm_VerifySignatureExternal_01(void)
{
  hsmParam_S  param = {.signaturesize = ATECC_SIGNATURE_SIZE, .pubkeysize = ATECC_PUB_KEY_SIZE, .datasize = 1};

  param.result = 0;  // verify modification

  will_return(__wrap_hsmInternalCommSync, true);  // mock
  will_return(__wrap_hsmInternalCommSync, 0);  // success
  expect_function_calls(__wrap_hsmInternalCommSync, 1);

  will_return(__wrap_ATECC508_performCreateDataHash, ATECC508_ERROR_SUCCESS);  // success
  will_return(__wrap_ATECC508_Cmd_Verify, ATECC508_ERROR_SUCCESS);  // success

  assert_int_equal(SecurityHsm_VerifySignatureExternal(&logd, &param), 0);  // success
  assert_int_equal(param.result, 1);  // match
}

//! @brief  bad param
static void test_SecurityHsm_VerifySignatureExternal_02(void)
{
  hsmParam_S  param = {.signaturesize = ATECC_SIGNATURE_SIZE, .pubkeysize = ATECC_PUB_KEY_SIZE, .datasize = 1};

  assert_int_equal(SecurityHsm_VerifySignatureExternal(NULL, &param), -1);  // fail

  assert_int_equal(SecurityHsm_VerifySignatureExternal(&logd, NULL), -1);  // fail

  assert_int_equal(SecurityHsm_VerifySignatureExternal(NULL, NULL), -1);  // fail
}

//! @brief  bad signature size
static void test_SecurityHsm_VerifySignatureExternal_03(void)
{
  hsmParam_S  param = {.signaturesize = ATECC_SIGNATURE_SIZE + 1, .pubkeysize = ATECC_PUB_KEY_SIZE, .datasize = 1};

  param.result = 0;  // verify fail-safe

  assert_int_equal(SecurityHsm_VerifySignatureExternal(&logd, &param), -1);  // fail
  assert_int_equal(param.result, 0);  // mismatch
}

//! @brief  bad pubkey size
static void test_SecurityHsm_VerifySignatureExternal_04(void)
{
  hsmParam_S  param = {.signaturesize = ATECC_SIGNATURE_SIZE, .pubkeysize = ATECC_PUB_KEY_SIZE + 1, .datasize = 1};

  param.result = 1;  // verify fail-safe

  assert_int_equal(SecurityHsm_VerifySignatureExternal(&logd, &param), -1);  // fail
  assert_int_equal(param.result, 0);  // mismatch
}

//! @brief  bad data size
static void test_SecurityHsm_VerifySignatureExternal_05(void)
{
  hsmParam_S  param = {.signaturesize = ATECC_SIGNATURE_SIZE, .pubkeysize = ATECC_PUB_KEY_SIZE, .datasize = 0};

  param.result = 1;  // verify fail-safe

  assert_int_equal(SecurityHsm_VerifySignatureExternal(&logd, &param), -1);  // fail
  assert_int_equal(param.result, 0);  // mismatch
}

//! @brief  hsmInternalCommSync fails
static void test_SecurityHsm_VerifySignatureExternal_06(void)
{
  hsmParam_S  param = {.signaturesize = ATECC_SIGNATURE_SIZE, .pubkeysize = ATECC_PUB_KEY_SIZE, .datasize = 1};

  param.result = 1;  // verify fail-safe

  will_return(__wrap_hsmInternalCommSync, true);  // mock
  will_return(__wrap_hsmInternalCommSync, -1);  // fail
  expect_function_calls(__wrap_hsmInternalCommSync, 1);

  assert_int_equal(SecurityHsm_VerifySignatureExternal(&logd, &param), -2);  // fail
  assert_int_equal(param.result, 0);  // mismatch
}

//! @brief  ATECC508_performCreateDataHash fails
static void test_SecurityHsm_VerifySignatureExternal_07(void)
{
  hsmParam_S  param = {.signaturesize = ATECC_SIGNATURE_SIZE, .pubkeysize = ATECC_PUB_KEY_SIZE, .datasize = 1};

  param.result = 1;  // verify fail-safe

  will_return(__wrap_hsmInternalCommSync, true);  // mock
  will_return(__wrap_hsmInternalCommSync, 0);  // success
  expect_function_calls(__wrap_hsmInternalCommSync, 1);

  will_return(__wrap_ATECC508_performCreateDataHash, ATECC508_ERROR_TIMEOUT);  // fail

  assert_int_equal(SecurityHsm_VerifySignatureExternal(&logd, &param), -1);  // fail
  assert_int_equal(param.result, 0);  // mismatch
}

//! @brief  ATECC508_Cmd_Verify fails
static void test_SecurityHsm_VerifySignatureExternal_08(void)
{
  hsmParam_S  param = {.signaturesize = ATECC_SIGNATURE_SIZE, .pubkeysize = ATECC_PUB_KEY_SIZE, .datasize = 1};

  param.result = 1;  // verify fail-safe

  will_return(__wrap_hsmInternalCommSync, true);  // mock
  will_return(__wrap_hsmInternalCommSync, 0);  // success
  expect_function_calls(__wrap_hsmInternalCommSync, 1);

  will_return(__wrap_ATECC508_performCreateDataHash, ATECC508_ERROR_SUCCESS);  // success
  will_return(__wrap_ATECC508_Cmd_Verify, ATECC508_ERROR_TIMEOUT);  // fail

  assert_int_equal(SecurityHsm_VerifySignatureExternal(&logd, &param), -1);  // fail
  assert_int_equal(param.result, 0);  // mismatch
}

//! @brief  ATECC508_Cmd_Verify mismatch
static void test_SecurityHsm_VerifySignatureExternal_09(void)
{
  hsmParam_S  param = {.signaturesize = ATECC_SIGNATURE_SIZE, .pubkeysize = ATECC_PUB_KEY_SIZE, .datasize = 1};

  param.result = 1;  // verify fail-safe

  will_return(__wrap_hsmInternalCommSync, true);  // mock
  will_return(__wrap_hsmInternalCommSync, 0);  // success
  expect_function_calls(__wrap_hsmInternalCommSync, 1);

  will_return(__wrap_ATECC508_performCreateDataHash, ATECC508_ERROR_SUCCESS);  // success
  will_return(__wrap_ATECC508_Cmd_Verify, ATECC508_ERROR_CHECKMAC_VERIFY_ERR);  // mismatch

  assert_int_equal(SecurityHsm_VerifySignatureExternal(&logd, &param), 0);  // success
  assert_int_equal(param.result, 0);  // mismatch
}

static void test_SecurityHsm_VerifySignatureExternal(void** state)
{
  test_SecurityHsm_VerifySignatureExternal_01();
  test_SecurityHsm_VerifySignatureExternal_02();
  test_SecurityHsm_VerifySignatureExternal_03();
  test_SecurityHsm_VerifySignatureExternal_04();
  test_SecurityHsm_VerifySignatureExternal_05();
  test_SecurityHsm_VerifySignatureExternal_06();
  test_SecurityHsm_VerifySignatureExternal_07();
  test_SecurityHsm_VerifySignatureExternal_08();
  test_SecurityHsm_VerifySignatureExternal_09();

  (void) state;
}


//! @brief  SecurityHsm_GenKey successful
static void test_SecurityHsm_GenKey_01(void)
{
  hsmParams_S  param = {.paramType = HSM_PARAM_TYPE_ePUBKEY, .param.hsmPubKey.slotID = 0, .param.hsmPubKey.keySize = 0};

  will_return(__wrap_hsmInternalCheckParams, true);  // mock
  will_return(__wrap_hsmInternalCheckParams, 0);  // success
  expect_function_calls(__wrap_hsmInternalCheckParams, 1);

  will_return(__wrap_SecurityHsm_CheckConfig, true);  // mock
  will_return(__wrap_SecurityHsm_CheckConfig, 0);  // success
  expect_function_calls(__wrap_SecurityHsm_CheckConfig, 1);

  will_return(__wrap_ATECC508_Cmd_GenKey, ATECC508_ERROR_SUCCESS);  // success

  assert_int_equal(SecurityHsm_GenKey(&logd, &param), 0);  // success
  assert_true(ATECC_PUB_KEY_SIZE == param.param.hsmPubKey.keySize);
}

//! @brief  wrong message-param
static void test_SecurityHsm_GenKey_02(void)
{
  hsmParams_S  param = {.paramType = HSM_PARAM_TYPE_eSIGNATURE, .param.hsmPubKey.slotID = 0};

  will_return(__wrap_hsmInternalCheckParams, true);  // mock
  will_return(__wrap_hsmInternalCheckParams, 0);  // success
  expect_function_calls(__wrap_hsmInternalCheckParams, 1);

  assert_int_equal(SecurityHsm_GenKey(&logd, &param), -2);  // fail
}

//! @brief  bad slot-id
static void test_SecurityHsm_GenKey_03(void)
{
  hsmParams_S  param = {.paramType = HSM_PARAM_TYPE_ePUBKEY, .param.hsmPubKey.slotID = 100};

  will_return(__wrap_hsmInternalCheckParams, true);  // mock
  will_return(__wrap_hsmInternalCheckParams, 0);  // success
  expect_function_calls(__wrap_hsmInternalCheckParams, 1);

  assert_int_equal(SecurityHsm_GenKey(&logd, &param), -2);  // fail
}

//! @brief  hsmInternalCheckParams() fails
static void test_SecurityHsm_GenKey_04(void)
{
  hsmParams_S  param = {.paramType = HSM_PARAM_TYPE_ePUBKEY, .param.hsmPubKey.slotID = 0};

  will_return(__wrap_hsmInternalCheckParams, true);  // mock
  will_return(__wrap_hsmInternalCheckParams, -1);  // fail
  expect_function_calls(__wrap_hsmInternalCheckParams, 1);

  assert_int_equal(SecurityHsm_GenKey(&logd, &param), -2);  // fail
}

//! @brief  ATECC508_Cmd_GenKey fails
static void test_SecurityHsm_GenKey_05(void)
{
  hsmParams_S  param = {.paramType = HSM_PARAM_TYPE_ePUBKEY, .param.hsmPubKey.slotID = 0};

  will_return(__wrap_hsmInternalCheckParams, true);  // mock
  will_return(__wrap_hsmInternalCheckParams, 0);  // success
  expect_function_calls(__wrap_hsmInternalCheckParams, 1);

  will_return(__wrap_SecurityHsm_CheckConfig, true);  // mock
  will_return(__wrap_SecurityHsm_CheckConfig, 0);  // success
  expect_function_calls(__wrap_SecurityHsm_CheckConfig, 1);

  will_return(__wrap_ATECC508_Cmd_GenKey, ATECC508_ERROR_TIMEOUT);  // fail

  assert_int_equal(SecurityHsm_GenKey(&logd, &param), -2);  // fail
}

//! @brief  SecurityHsm_CheckConfig fails
static void test_SecurityHsm_GenKey_06(void)
{
  hsmParams_S  param = {.paramType = HSM_PARAM_TYPE_ePUBKEY, .param.hsmPubKey.slotID = 0};

  will_return(__wrap_hsmInternalCheckParams, true);  // mock
  will_return(__wrap_hsmInternalCheckParams, 0);  // success
  expect_function_calls(__wrap_hsmInternalCheckParams, 1);

  will_return(__wrap_SecurityHsm_CheckConfig, true);  // mock
  will_return(__wrap_SecurityHsm_CheckConfig, -1);  // fail
  expect_function_calls(__wrap_SecurityHsm_CheckConfig, 1);

  assert_int_equal(SecurityHsm_GenKey(&logd, &param), -1);  // fail
}

static void test_SecurityHsm_GenKey(void** state)
{
  test_SecurityHsm_GenKey_01();
  test_SecurityHsm_GenKey_02();
  test_SecurityHsm_GenKey_03();
  test_SecurityHsm_GenKey_04();
  test_SecurityHsm_GenKey_05();
  test_SecurityHsm_GenKey_06();

  (void) state;
}


//! @brief  good config
static void test_hsmInternalCompareConfiguration_01(void)
{
  will_return(__wrap_hsmInternalCompareConfiguration, false);  // do not mock
  assert_true(hsmInternalCompareConfiguration(&hsmDefaultConfig, &hsmDefaultConfig));
}

//! @brief  not the same type
static void test_hsmInternalCompareConfiguration_02(void)
{
  hsmConfig_S  c = hsmDefaultConfig;

  c.hsmType = HSM_TYPE_eATECC608A;

  will_return(__wrap_hsmInternalCompareConfiguration, false);  // do not mock
  assert_false(hsmInternalCompareConfiguration(&c, &hsmDefaultConfig));
}

//! @brief  same content, but wrong type
static void test_hsmInternalCompareConfiguration_03(void)
{
  hsmConfig_S  c1 = hsmDefaultConfig;
  hsmConfig_S  c2 = hsmDefaultConfig;

  c1.hsmType = HSM_TYPE_eATECC608A;
  c2.hsmType = HSM_TYPE_eATECC608A;

  will_return(__wrap_hsmInternalCompareConfiguration, false);  // do not mock
  assert_false(hsmInternalCompareConfiguration(&c1, &c2));
}

//! @brief  contents mismatch
static void test_hsmInternalCompareConfiguration_04(void)
{
  hsmConfig_S  c;
  uint8_t* const  p = (void*) &c.cfg.atecc508Cfg;
  size_t  byte;
  size_t  bit;

  // flip every single bit in the configuration itself
  for ( byte = 0; byte < sizeof (c.cfg.atecc508Cfg); ++byte )
  {
    for ( bit = 0; bit < 8U; ++bit )
    {
      c = hsmDefaultConfig;
      p[byte] ^= (1U << bit);
      will_return(__wrap_hsmInternalCompareConfiguration, false);  // do not mock
      assert_false(hsmInternalCompareConfiguration(&c, &hsmDefaultConfig));
    }
  }
}

static void test_hsmInternalCompareConfiguration(void** state)
{
  test_hsmInternalCompareConfiguration_01();
  test_hsmInternalCompareConfiguration_02();
  test_hsmInternalCompareConfiguration_03();
  test_hsmInternalCompareConfiguration_04();

  (void) state;
}


//! @brief  all parameters okay
extern void test_hsmInternalCheckParams_01(void)
{
  hsmParam_S  param = {0};
  will_return(__wrap_hsmInternalCheckParams, false);  // do not mock
  assert_int_equal(hsmInternalCheckParams(&logd, &param), 0);
}

//! @brief  logd is NULL
extern void test_hsmInternalCheckParams_02(void)
{
  hsmParam_S  param = {0};
  will_return(__wrap_hsmInternalCheckParams, false);  // do not mock
  assert_int_equal(hsmInternalCheckParams(NULL, &param), -1);
}

//! @brief  param is NULL
extern void test_hsmInternalCheckParams_03(void)
{
  will_return(__wrap_hsmInternalCheckParams, false);  // do not mock
  assert_int_equal(hsmInternalCheckParams(&logd, NULL), -1);
}

//! @brief  both parameters NULL
extern void test_hsmInternalCheckParams_04(void)
{
  will_return(__wrap_hsmInternalCheckParams, false);  // do not mock
  assert_int_equal(hsmInternalCheckParams(NULL, NULL), -1);
}

extern void test_hsmInternalCheckParams(void** state)
{
  test_hsmInternalCheckParams_01();
  test_hsmInternalCheckParams_02();
  test_hsmInternalCheckParams_03();
  test_hsmInternalCheckParams_04();

  (void) state;
}


//! @brief  success
extern void test_hsmInternalCommSync_01(void)
{
  will_return(__wrap_ATECC508_GoSleep, ATECC508_ERROR_SUCCESS);  // success
  will_return(__wrap_ATECC508_WakeUp, ATECC508_ERROR_SUCCESS);  // success

  will_return(__wrap_hsmInternalCommSync, false);  // do not mock
  assert_int_equal(hsmInternalCommSync(), 0);  // success
}

//! @brief  ATECC508_WakeUp fails
extern void test_hsmInternalCommSync_02(void)
{
  will_return(__wrap_ATECC508_GoSleep, ATECC508_ERROR_SUCCESS);  // success
  will_return(__wrap_ATECC508_WakeUp, ATECC508_ERROR_TIMEOUT);  // fail

  will_return(__wrap_hsmInternalCommSync, false);  // do not mock
  assert_int_equal(hsmInternalCommSync(), -2);
}

extern void test_hsmInternalCommSync(void** state)
{
  test_hsmInternalCommSync_01();
  test_hsmInternalCommSync_02();

  (void) state;
}


//! @brief  success
extern void test_SecurityHsm_CheckConfig_01(void)
{
  will_return(__wrap_SecurityHsm_GetConfig, true);  // mock
  will_return(__wrap_SecurityHsm_GetConfig, 0);  // success
  expect_function_calls(__wrap_SecurityHsm_GetConfig, 1);

  will_return(__wrap_hsmInternalCompareConfiguration, true);  // mock
  will_return(__wrap_hsmInternalCompareConfiguration, true);  // success
  expect_function_calls(__wrap_hsmInternalCompareConfiguration, 1);

  will_return(__wrap_SecurityHsm_CheckConfig, false);  // do not mock
  assert_int_equal(SecurityHsm_CheckConfig(&logd), 0);  // success
}

//! @brief  SecurityHsm_GetConfig fails
extern void test_SecurityHsm_CheckConfig_02(void)
{
  will_return(__wrap_SecurityHsm_GetConfig, true);  // mock
  will_return(__wrap_SecurityHsm_GetConfig, -1);  // fail
  expect_function_calls(__wrap_SecurityHsm_GetConfig, 1);

  will_return(__wrap_SecurityHsm_CheckConfig, false);  // do not mock
  assert_int_equal(SecurityHsm_CheckConfig(&logd), -1);  // fail
}

//! @brief  hsmInternalCompareConfiguration fails
extern void test_SecurityHsm_CheckConfig_03(void)
{
  will_return(__wrap_SecurityHsm_GetConfig, true);  // mock
  will_return(__wrap_SecurityHsm_GetConfig, 0);  // success
  expect_function_calls(__wrap_SecurityHsm_GetConfig, 1);

  will_return(__wrap_hsmInternalCompareConfiguration, true);  // mock
  will_return(__wrap_hsmInternalCompareConfiguration, false);  // fail
  expect_function_calls(__wrap_hsmInternalCompareConfiguration, 1);

  will_return(__wrap_SecurityHsm_CheckConfig, false);  // do not mock
  assert_int_equal(SecurityHsm_CheckConfig(&logd), -2);  // success
}

extern void test_SecurityHsm_CheckConfig(void** state)
{
  test_SecurityHsm_CheckConfig_01();
  test_SecurityHsm_CheckConfig_02();
  test_SecurityHsm_CheckConfig_03();

  (void) state;
}


int main(void)
{
  int  retval = 0;
    
#ifdef CMOCKA_DIAB
  putenv("CMOCKA_XML_FILE=src_common_Security_Hsm.xml"); // environment variable for XML file when running on PPC
#endif
    
  const struct CMUnitTest  tests[] =
  {
    cmocka_unit_test(test_SecurityHsm_SetConfig),
    cmocka_unit_test(test_SecurityHsm_SetLock),
    cmocka_unit_test(test_SecurityHsm_GetLock),
    cmocka_unit_test(test_SecurityHsm_GetConfig),
    cmocka_unit_test(test_SecurityHsm_VerifySignatureExternal),
    cmocka_unit_test(test_SecurityHsm_GenKey),
    cmocka_unit_test(test_hsmInternalCompareConfiguration),
    cmocka_unit_test(test_hsmInternalCheckParams),
    cmocka_unit_test(test_hsmInternalCommSync),
    cmocka_unit_test(test_SecurityHsm_CheckConfig),
  };

  cmocka_set_message_output (CM_OUTPUT_XML);

  retval = cmocka_run_group_tests_name("src_common_Security_Hsm", tests, NULL, NULL);
  
#ifdef CMOCKA_DIAB
  read_xml_file("src_common_Security_Hsm.xml"); // extract XML test results from file in RAM when running on PPC
#endif
  
  return;
}


//!@name Stubbed Functions
//!{
extern void __wrap_logd_printf(logd_t *self,
                               unsigned int level,
                               const char *fmt,
                               ...)
{
  va_list  argptr = NULL;
  va_start(argptr, fmt);
//  (void)vprintf(fmt, argptr);  // do not actually print, it will garble the test-output
  va_end(argptr);
}

extern logd_t * __wrap_logd_new(const char *logdProcessName,
                         int levelMax, /* obsolete ! */
                         const char *appl,
                         sc_poolid_t plid,
                         sc_ticks_t tmo)
{
  return &logd;
}

extern int8_t __wrap_hsmInternalCheckParams(const logd_t* const logd, const hsmParam_S *const pParam)
{
  int8_t  rc;

  if ( mock() )
  {
    rc = (int8_t) mock();
    function_called();
  }
  else
  {
    rc = __real_hsmInternalCheckParams(logd, pParam);
  }

  return rc;
}

extern int __wrap_SecurityHsm_CheckConfig(logd_t* const logd)
{
  int  rc;

  if ( mock() )
  {
    rc = (int) mock();
    function_called();
  }
  else
  {
    rc = __real_SecurityHsm_CheckConfig(logd);
  }

  return rc;
}

extern int __wrap_SecurityHsm_GetConfig(logd_t* const logd, hsmConfig_S* const hsmCfg)
{
  int  rc;

  if ( mock() )
  {
    rc = (int) mock();
    function_called();
  }
  else
  {
    rc = __real_SecurityHsm_GetConfig(logd, hsmCfg);
  }

  return rc;
}

extern int8_t __wrap_hsmInternalCommSync(void)
{
  int8_t  rc;

  if ( mock() )
  {
    rc = (int8_t) mock();
    function_called();
  }
  else
  {
    rc = __real_hsmInternalCommSync();
  }

  return rc;
}

extern bool __wrap_hsmInternalCompareConfiguration(const hsmConfig_S* const hsmCfgCurrent, const hsmConfig_S* const hsmCfgExpected)
{
  bool  rc;

  if ( mock() )
  {
    rc = (bool) mock();
    function_called();
  }
  else
  {
    rc = __real_hsmInternalCompareConfiguration(hsmCfgCurrent, hsmCfgExpected);
  }

  return rc;
}

//! @}


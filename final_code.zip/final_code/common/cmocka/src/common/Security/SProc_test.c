#include <setjmp.h>
#include <stdio.h>
#include <stdarg.h>
#include "cmocka.h"
#include "Cfg/MsgIds.h"
#include "Cfg/Self.h"
#include "Security/Hsm.h"
#include "Security/SProc.h"
#include "Security/SMsgs.h"

#include "wrap/sciopta.h"

union sc_msg
{
  sc_msgid_t            id;
  SecuritySMsgs_Msgs_U  security;
};


//! @brief  Check the handling of SecuritySProc_GetPid()
//! @param  state  cmocka-state, unused
static void test_SecuritySProc_GetPid(void** state)
{
  const sc_pid_t  pid = 23;

  expect_function_call (__wrap___sc_procIdGet);
  will_return (__wrap___sc_procIdGet, pid);

  assert_true (SecuritySProc_GetPid() == pid);
  (void) state;
}


//! @brief  Check for allocation of the VerifiySignatureExternalRequest message structure
//! @param  state  cmocka-state, unused
static void test_SecuritySProc_AllocVerifiySignatureExternalRequest(void** state)
{
  sc_msg_t  msg;

  // successful allocation
  sc_msgAlloc_will_return (INJECT_NO_ERROR);
  msg = SecuritySProc_AllocVerifiySignatureExternalRequest (SC_DEFAULT_POOL, SC_FATAL_IF_TMO);
  assert_true (msg != NULL);
  expect_function_call (__wrap___sc_msgFree);
  sc_msgFree (&msg);

  // out of memory
  sc_msgAlloc_will_return (INJECT_KERNEL_EOUT_OF_MEMORY);
  msg = SecuritySProc_AllocVerifiySignatureExternalRequest (SC_DEFAULT_POOL, SC_FATAL_IF_TMO);
  assert_true (msg == NULL);

  (void)state;
}

//! @brief  Check for allocation of the CryptoChipConfigureRequest message structure
//! @param  state  cmocka-state, unused
static void test_SecuritySProc_AllocCryptoChipConfigureRequest(void** state)
{
  sc_msg_t  msg;

  // successful allocation
  sc_msgAlloc_will_return (INJECT_NO_ERROR);
  msg = SecuritySProc_AllocCryptoChipConfigureRequest (SC_DEFAULT_POOL, SC_FATAL_IF_TMO);
  assert_true (msg != NULL);
  expect_function_call (__wrap___sc_msgFree);
  sc_msgFree (&msg);

  // out of memory
  sc_msgAlloc_will_return (INJECT_KERNEL_EOUT_OF_MEMORY);
  msg = SecuritySProc_AllocCryptoChipConfigureRequest (SC_DEFAULT_POOL, SC_FATAL_IF_TMO);
  assert_true (msg == NULL);

  (void)state;
}

//! @brief  Check for allocation of the CryptoChipGenKeyRequest message structure
//! @param  state  cmocka-state, unused
static void test_SecuritySProc_AllocCryptoChipGenKeyRequest(void** state)
{
  sc_msg_t  msg;

  // successful allocation
  sc_msgAlloc_will_return (INJECT_NO_ERROR);
  msg = SecuritySProc_AllocCryptoChipGenKeyRequest (SC_DEFAULT_POOL, SC_FATAL_IF_TMO);
  assert_true (msg != NULL);
  expect_function_call (__wrap___sc_msgFree);
  sc_msgFree (&msg);

  // out of memory
  sc_msgAlloc_will_return (INJECT_KERNEL_EOUT_OF_MEMORY);
  msg = SecuritySProc_AllocCryptoChipGenKeyRequest (SC_DEFAULT_POOL, SC_FATAL_IF_TMO);
  assert_true (msg == NULL);

  (void)state;
}

//! @brief  Check for allocation of the CryptoChipLockRequest message structure
//! @param  state  cmocka-state, unused
static void test_SecuritySProc_AllocCryptoChipLockRequest(void** state)
{
  sc_msg_t  msg;

  // successful allocation
  sc_msgAlloc_will_return (INJECT_NO_ERROR);
  msg = SecuritySProc_AllocCryptoChipLockRequest (SC_DEFAULT_POOL, SC_FATAL_IF_TMO);
  assert_true (msg != NULL);
  expect_function_call (__wrap___sc_msgFree);
  sc_msgFree (&msg);

  // out of memory
  sc_msgAlloc_will_return (INJECT_KERNEL_EOUT_OF_MEMORY);
  msg = SecuritySProc_AllocCryptoChipLockRequest (SC_DEFAULT_POOL, SC_FATAL_IF_TMO);
  assert_true (msg == NULL);

  (void)state;
}

//! @brief  Check for allocation of the SecureBootRequest message structure
//! @param  state  cmocka-state, unused
static void test_SecuritySProc_AllocSecureBootRequest(void** state)
{
  sc_msg_t  msg;

  // successful allocation
  sc_msgAlloc_will_return (INJECT_NO_ERROR);
  msg = SecuritySProc_AllocSecureBootRequest (SC_DEFAULT_POOL, SC_FATAL_IF_TMO);
  assert_true (msg != NULL);
  expect_function_call (__wrap___sc_msgFree);
  sc_msgFree (&msg);

  // out of memory
  sc_msgAlloc_will_return (INJECT_KERNEL_EOUT_OF_MEMORY);
  msg = SecuritySProc_AllocSecureBootRequest (SC_DEFAULT_POOL, SC_FATAL_IF_TMO);
  assert_true (msg == NULL);

  (void)state;
}


//! @brief  helper for test_handleMsgHsmVerifySignatureExternalRequest
//! @param[in]  verifyError  injected returncode of function SecurityHsm_VerifySignatureExternal()
//! @param[in]  signatureMatch  injected status from the CryptoChip (signature matches or mismatches)
//! @param[in]  expectedErrorCode  expected returncode of function SecurityHsm_VerifySignatureExternal()
//! @param[in]  expectedMatch  expected status from the CryptoChip (signature matches or mismatches)
static void test_handleMsgHsmVerifySignatureExternalRequest_helper(const int verifyError, const int signatureMatch, const int expectedErrorCode, const int expectedMatch)
{
  sc_msgAlloc_will_return(INJECT_NO_ERROR);
  // This message will be used as reply by #SecuritySProc_Proc, thus, no free required here.
  sc_msg_t pSc_msg_security_request = SecuritySProc_AllocVerifiySignatureExternalRequest (SC_DEFAULT_POOL, SC_FATAL_IF_TMO);
  pSc_msg_security_request->security.hsm_verifySignatureExternal.result      = ~signatureMatch;
  pSc_msg_security_request->security.hsm_verifySignatureExternal.errorcode_t = ~verifyError;

  sc_msgAlloc_will_return(INJECT_NO_ERROR);
  // This message will be used for comparison purpose, #SecuritySProc_Proc is not aware that this message exists, thus, a free is required here.
  // This message should match the reply message send by #SecuritySProc_Proc
  sc_msg_t pSc_msg_security_reply = SecuritySProc_AllocVerifiySignatureExternalRequest (SC_DEFAULT_POOL, SC_FATAL_IF_TMO);
  pSc_msg_security_reply->id = SECURITY_VERIFY_SIGNATURE_EXTERNAL_REPLY_MSGID;
  pSc_msg_security_reply->security.hsm_verifySignatureExternal.result      = expectedMatch;
  pSc_msg_security_reply->security.hsm_verifySignatureExternal.errorcode_t = expectedErrorCode;

  sc_msgRx_will_return(INJECT_NO_ERROR, pSc_msg_security_request);

  will_return (__wrap_SecurityHsm_VerifySignatureExternal, signatureMatch);
  will_return (__wrap_SecurityHsm_VerifySignatureExternal, verifyError);

  will_return (__wrap___sc_msgSndGet, 0);
  sc_msgTx_will_return(INJECT_NO_ERROR, pSc_msg_security_reply, sizeof(Security_Hsm_verifySignatureExternal_S), 0);
  expect_function_calls (__wrap___sc_msgTx, 1);

  expect_function_calls (__wrap_HlpMsg_AssertFreed_f, 1);

  will_return (__wrap_HlpProc_AlwaysTrue, true);
  will_return (__wrap_HlpProc_AlwaysTrue, false);
  (void) SecuritySProc_Proc();

  expect_function_call(__wrap___sc_msgFree);
  sc_msgFree(&pSc_msg_security_reply);
}

//! @brief  Check if correct status is replied in case of a request for external signature verification
//! @param  state  cmocka-state, unused
static void test_handleMsgHsmVerifySignatureExternalRequest (void** state)
{
  // verifyError, signatureMatch, expectedErrorCode, expectedMatch
  test_handleMsgHsmVerifySignatureExternalRequest_helper( 0, 1, 0, 1);  // signature matches
  test_handleMsgHsmVerifySignatureExternalRequest_helper( 0, 0, 0, 0);  // signature does not match

  test_handleMsgHsmVerifySignatureExternalRequest_helper(-1, 1, 1, 0);  // verify fail, hsmStatus reports for some reason signature-match (cannot happen, but hsmParam.result should be fail-safe)
  test_handleMsgHsmVerifySignatureExternalRequest_helper(-1, 0, 1, 0);  // verify fail, hsmStatus reports for some reason signature-mismatch

  test_handleMsgHsmVerifySignatureExternalRequest_helper(-2, 1, 2, 0);  // verify comm-error, hsmStatus reports signature-match (cannot happen, but hsmParam.result should be fail-safe)
  test_handleMsgHsmVerifySignatureExternalRequest_helper(-2, 0, 2, 0);  // verify comm-error, hsmStatus reports signature-mismatch

  (void) state;
}


//! @brief  helper for test_handleMsgHsmCryptoChipConfigureRequest()
//! @param[in]  setError  injected returncode of function SecurityHsm_SetConfig()
//! @param[in]  checkError  injected returncode of function SecurityHsm_CheckConfig()
//! @param[in]  expectedStatus  expected status from function handleMsgHsmCryptoChipConfigureRequest()
static void test_handleMsgHsmCryptoChipConfigureRequest_helper(const int setError, const int checkError, const int expectedStatus)
{
  sc_msgAlloc_will_return(INJECT_NO_ERROR);
  // This message will be used as reply by #SecuritySProc_Proc, thus, no free required here.
  sc_msg_t pSc_msg_security_request = sc_msgAlloc(sizeof(Security_Hsm_cryptoChipConfigure_S), SECURITY_CRYPTOCHIPCONFIGURE_REQUEST_MSGID, 0, 0);
  pSc_msg_security_request->security.hsm_cryptoChipConfigure.status = ~expectedStatus;

  sc_msgAlloc_will_return(INJECT_NO_ERROR);
  // This message will be used for comparison purpose, #SecuritySProc_Proc is not aware that this message exists, thus, a free is required here.
  // This message should match the reply message send by #SecuritySProc_Proc
  sc_msg_t pSc_msg_security_reply = sc_msgAlloc(sizeof(Security_Hsm_cryptoChipConfigure_S), SECURITY_CRYPTOCHIPCONFIGURE_REPLY_MSGID, 0, 0);
  pSc_msg_security_reply->security.hsm_cryptoChipConfigure.status = expectedStatus;

  sc_msgRx_will_return(INJECT_NO_ERROR, pSc_msg_security_request);

  will_return (__wrap_SecurityHsm_SetConfig, setError);
  if ( 0 == setError )
  {
    will_return (__wrap_SecurityHsm_CheckConfig, checkError);
  }

  sc_msgTx_will_return(INJECT_NO_ERROR, pSc_msg_security_reply, sizeof(Security_Hsm_cryptoChipConfigure_S), 0);
  will_return (__wrap___sc_msgSndGet, 0);
  expect_function_calls (__wrap___sc_msgTx, 1);

  expect_function_calls (__wrap_HlpMsg_AssertFreed_f, 1);

  will_return (__wrap_HlpProc_AlwaysTrue, true);
  will_return (__wrap_HlpProc_AlwaysTrue, false);

  (void) SecuritySProc_Proc();

  expect_function_call(__wrap___sc_msgFree);
  sc_msgFree(&pSc_msg_security_reply);
}

//! @brief  Check if correct status is replied in case of a request for the configuration of the crypto chip
//! @param  state  cmocka-state, unused
static void test_handleMsgHsmCryptoChipConfigureRequest(void** state)
{
  // check SetConfig
  test_handleMsgHsmCryptoChipConfigureRequest_helper( 0, 0, 0);  // success
  test_handleMsgHsmCryptoChipConfigureRequest_helper(-1, 0, 1);  // fail
  test_handleMsgHsmCryptoChipConfigureRequest_helper(-2, 0, 2);  // comm-error
  test_handleMsgHsmCryptoChipConfigureRequest_helper(99, 0, 1);  // unknown error

  // check CheckConfig
  test_handleMsgHsmCryptoChipConfigureRequest_helper(0,  0, 0);  // success
  test_handleMsgHsmCryptoChipConfigureRequest_helper(0, -1, 1);  // fail
  test_handleMsgHsmCryptoChipConfigureRequest_helper(0, -2, 2);  // comm-error
  test_handleMsgHsmCryptoChipConfigureRequest_helper(0, 99, 1);  // unknown error

  (void) state;
}


//! @brief  helper for test_handleMsgHsmCryptoChipGenKeyRequest()
//! @param[in]  genKeyError  injected returncode of function SecurityHsm_GenKey()
//! @param[in]  setLockError  injected returncode of function SecurityHsm_SetLock()
//! @param[in]  expectedStatus  expected status from function handleMsgHsmCryptoChipGenKeyRequest()
static void test_handleMsgHsmCryptoChipGenKeyRequest_helper(const int genKeyError, const int setLockError, const int expectedStatus)
{
  sc_msgAlloc_will_return(INJECT_NO_ERROR);
  // This message will be used as reply by #SecuritySProc_Proc, thus, no free required here.
  sc_msg_t pSc_msg_security_request = sc_msgAlloc(sizeof(Security_Hsm_cryptoChipGenKey_S), SECURITY_CRYPTOCHIPGENKEY_REQUEST_MSGID, 0, 0);
  pSc_msg_security_request->security.hsm_cryptoChipGenKey.status = ~expectedStatus;

  sc_msgAlloc_will_return(INJECT_NO_ERROR);
  // This message will be used for comparison purpose, #SecuritySProc_Proc is not aware that this message exists, thus, a free is required here.
  // This message should match the reply message send by #SecuritySProc_Proc
  sc_msg_t pSc_msg_security_reply = sc_msgAlloc(sizeof(Security_Hsm_cryptoChipGenKey_S), SECURITY_CRYPTOCHIPGENKEY_REPLY_MSGID, 0, 0);
  pSc_msg_security_reply->security.hsm_cryptoChipGenKey.status = expectedStatus;

  sc_msgRx_will_return(INJECT_NO_ERROR, pSc_msg_security_request);
  will_return (__wrap___sc_msgSndGet, 0);

#ifdef CNF_NEAR_PRODUCTION_CODE
  will_return (__wrap_SecurityHsm_GenKey, genKeyError);
  if ( 0 == genKeyError )
  {
    will_return (__wrap_SecurityHsm_SetLock, setLockError);
  }
#else
  will_return (__wrap_SecurityHsm_GenKey, genKeyError);
#endif

  sc_msgTx_will_return(INJECT_NO_ERROR, pSc_msg_security_reply, sizeof(Security_Hsm_cryptoChipGenKey_S), 0);
  expect_function_calls (__wrap___sc_msgTx, 1);
  expect_function_calls (__wrap_HlpMsg_AssertFreed_f, 1);

  will_return (__wrap_HlpProc_AlwaysTrue, true);
  will_return (__wrap_HlpProc_AlwaysTrue, false);
  (void) SecuritySProc_Proc();

  expect_function_call(__wrap___sc_msgFree);
  sc_msgFree(&pSc_msg_security_reply);
}

//! @brief  Check if correct status is replied in case of a request for the device-key generation in the crypto chip
//! @param  state  cmocka-state, unused
static void test_handleMsgHsmCryptoChipGenKeyRequest(void** state)
{
  // genKeyError, setLockError, expectedStatus
  test_handleMsgHsmCryptoChipGenKeyRequest_helper( 0,  0, 0);  // success

  test_handleMsgHsmCryptoChipGenKeyRequest_helper(-1,  0, 1);  // genKey fail
  test_handleMsgHsmCryptoChipGenKeyRequest_helper(-2,  0, 2);  // genKey comm-error
  test_handleMsgHsmCryptoChipGenKeyRequest_helper(99,  0, 1);  // unknown error

  test_handleMsgHsmCryptoChipGenKeyRequest_helper( 0, -1, 1);  // setLock fail
  test_handleMsgHsmCryptoChipGenKeyRequest_helper( 0, -2, 2);  // setLock comm-error
  test_handleMsgHsmCryptoChipGenKeyRequest_helper( 0, 99, 1);  // unknown error

  (void) state;
}


//! @brief  helper for test_handleMsgHsmCryptoChipLockRequest()
//! @param[in]  checkError  injected returncode of function SecurityHsm_CheckConfig()
//! @param[in]  lockError  injected returncode of function SecurityHsm_SetLock()
//! @param[in]  expectedStatus  expected status from function handleMsgHsmCryptoChipLockRequest()
static void test_handleMsgHsmCryptoChipLockRequest_helper(const int checkError, const int lockError, const int expectedStatus)
{
  sc_msgAlloc_will_return(INJECT_NO_ERROR);
  // This message will be used as reply by #SecuritySProc_Proc, thus, no free required here.
  sc_msg_t pSc_msg_security_request = sc_msgAlloc(sizeof(Security_Hsm_cryptoChipLock_S), SECURITY_CRYPTOCHIPLOCK_REQUEST_MSGID, 0, 0);
  pSc_msg_security_request->security.hsm_cryptoChipLock.status = ~expectedStatus;

  sc_msgAlloc_will_return(INJECT_NO_ERROR);
  // This message will be used for comparison purpose, #SecuritySProc_Proc is not aware that this message exists, thus, a free is required here.
  // This message should match the reply message send by #SecuritySProc_Proc
  sc_msg_t pSc_msg_security_reply = sc_msgAlloc(sizeof(Security_Hsm_cryptoChipLock_S), SECURITY_CRYPTOCHIPLOCK_REPLY_MSGID, 0, 0);
  pSc_msg_security_reply->security.hsm_cryptoChipLock.status = expectedStatus;

  sc_msgRx_will_return(INJECT_NO_ERROR, pSc_msg_security_request);
  will_return (__wrap___sc_msgSndGet, 0);

#ifdef CNF_NEAR_PRODUCTION_CODE
  will_return (__wrap_SecurityHsm_CheckConfig, checkError);
  if ( 0 == checkError )
  {
    will_return (__wrap_SecurityHsm_SetLock, lockError);
  }
#else
  will_return (__wrap_SecurityHsm_CheckConfig, checkError);
#endif

  sc_msgTx_will_return(INJECT_NO_ERROR, pSc_msg_security_reply, sizeof(Security_Hsm_cryptoChipLock_S), 0);
  expect_function_calls (__wrap___sc_msgTx, 1);
  expect_function_calls (__wrap_HlpMsg_AssertFreed_f, 1);

  will_return (__wrap_HlpProc_AlwaysTrue, true);
  will_return (__wrap_HlpProc_AlwaysTrue, false);
  (void) SecuritySProc_Proc();

  expect_function_call(__wrap___sc_msgFree);
  sc_msgFree(&pSc_msg_security_reply);
}

//! @brief  Check if correct status is replied in case of a request for final locking of the crypto chip
//! @param  state  cmocka-state, unused
static void test_handleMsgHsmCryptoChipLockRequest(void** state)
{
  // configError, lockError, expectedStatus
  test_handleMsgHsmCryptoChipLockRequest_helper( 0, 0, 0);  // success

  test_handleMsgHsmCryptoChipLockRequest_helper(-1, 0, 1);  // config fail
  test_handleMsgHsmCryptoChipLockRequest_helper(-2, 0, 2);  // config comm-error
  test_handleMsgHsmCryptoChipLockRequest_helper(99, 0, 1);  // unknown error

  test_handleMsgHsmCryptoChipLockRequest_helper(0, -1, 1);  // lock fail
  test_handleMsgHsmCryptoChipLockRequest_helper(0, -2, 2);  // lock comm-error
  test_handleMsgHsmCryptoChipLockRequest_helper(0, 99, 1);  // unknown error

  (void) state;
}


//! @brief  helper for test_handleMsgSecureBootRequest()
//! @param[in]  secureError  injected returncode of function SecuritySecureBoot_SecureDevice()
//! @param[in]  expectedStatus  expected status from function handleMsgSecureBootRequest()
static void test_handleMsgSecureBootRequest_helper(const int secureError, const int expectedStatus)
{
  sc_msgAlloc_will_return(INJECT_NO_ERROR);
  // This message will be used as reply by #SecuritySProc_Proc, thus, no free required here.
  sc_msg_t pSc_msg_security = sc_msgAlloc(sizeof(Security_SecureBoot_S), SECURITY_SECUREBOOT_REQUEST_MSGID, 0, 0);
  pSc_msg_security->security.secureBoot.status = ~expectedStatus;

  sc_msgAlloc_will_return(INJECT_NO_ERROR);
  // This message will be used for comparison purpose, #SecuritySProc_Proc is not aware that this message exists, thus, a free is required here.
  // This message should match the reply message send by #SecuritySProc_Proc
  sc_msg_t pSc_msg_security_reply = sc_msgAlloc(sizeof(Security_SecureBoot_S), SECURITY_SECUREBOOT_REPLY_MSGID, 0, 0);
  pSc_msg_security_reply->security.secureBoot.status = expectedStatus;

  sc_msgRx_will_return(INJECT_NO_ERROR, pSc_msg_security);
  will_return (__wrap___sc_msgSndGet, 0);

  will_return (__wrap_SecuritySecureBoot_SecureDevice, secureError);

  sc_msgTx_will_return(INJECT_NO_ERROR, pSc_msg_security_reply, sizeof(Security_SecureBoot_S), 0);
  expect_function_calls (__wrap___sc_msgTx, 1);
  expect_function_calls (__wrap_HlpMsg_AssertFreed_f, 1);

  will_return (__wrap_HlpProc_AlwaysTrue, true);
  will_return (__wrap_HlpProc_AlwaysTrue, false);
  (void) SecuritySProc_Proc();

  expect_function_call(__wrap___sc_msgFree);
  sc_msgFree(&pSc_msg_security_reply);
}

//! @brief  Check if correct status is replied in case of a request for the securing of the processor-OTP
//! @param  state  cmocka-state, unused
static void test_handleMsgSecureBootRequest(void** state)
{
  // secureError, expectedStatus
  test_handleMsgSecureBootRequest_helper( 0, 0);
  test_handleMsgSecureBootRequest_helper(-1, 1);
  test_handleMsgSecureBootRequest_helper(-2, 2);
  test_handleMsgSecureBootRequest_helper(99, 1);

  (void) state;
}


//! @brief  Check reaction if unexpected message is received
//! @param  state  cmocka-state, unused
static void test_handleMsgUnexpected(void** state)
{
  sc_msgAlloc_will_return(INJECT_NO_ERROR);
  sc_msg_t const  pSc_msg = sc_msgAlloc(42, 0xFFFFU /*invalid Id*/, 0, 0);

  sc_msgRx_will_return(INJECT_NO_ERROR, pSc_msg);

  expect_function_calls (__wrap_HlpMsg_Unexpected, 1);
  expect_function_calls (__wrap___sc_msgFree, 1);
  expect_function_calls (__wrap_HlpMsg_AssertFreed_f, 1);

  will_return (__wrap_HlpProc_AlwaysTrue, true);
  will_return (__wrap_HlpProc_AlwaysTrue, false);
  (void) SecuritySProc_Proc();
}


int main(void)
{
  int  retval = 0;
  
#ifdef CMOCKA_DIAB
  putenv("CMOCKA_XML_FILE=src_common_Security_SProc.xml"); // environment variable for XML file when running on PPC
#endif

  const struct CMUnitTest  tests[] =
  {
    // getPid-function
    cmocka_unit_test (test_SecuritySProc_GetPid),
    // alloc-functions
    cmocka_unit_test (test_SecuritySProc_AllocVerifiySignatureExternalRequest),
    cmocka_unit_test (test_SecuritySProc_AllocCryptoChipConfigureRequest),
    cmocka_unit_test (test_SecuritySProc_AllocCryptoChipGenKeyRequest),
    cmocka_unit_test (test_SecuritySProc_AllocCryptoChipLockRequest),
    cmocka_unit_test (test_SecuritySProc_AllocSecureBootRequest),
    // Cryptochip
    cmocka_unit_test (test_handleMsgHsmVerifySignatureExternalRequest),
    cmocka_unit_test (test_handleMsgHsmCryptoChipConfigureRequest),
    cmocka_unit_test (test_handleMsgHsmCryptoChipGenKeyRequest),
    cmocka_unit_test (test_handleMsgHsmCryptoChipLockRequest),
    // secure boot
    cmocka_unit_test (test_handleMsgSecureBootRequest),
    // unexpected msg
    cmocka_unit_test (test_handleMsgUnexpected),
  };

  cmocka_set_message_output (CM_OUTPUT_XML);

  retval = cmocka_run_group_tests_name ("src_common_Security_SProc", tests, NULL, NULL);
  
#ifdef CMOCKA_DIAB
  read_xml_file("src_common_Security_SProc.xml"); // extract XML test results from file in RAM when running on PPC
#endif

  return retval;
}


//!@name Stubbed Functions
//!{
const char * const __wrap_CfgProcNames_scpLogd = "/SCP_logd";
const char * const __wrap_CfgProcNames_securityProcess = "/user/SecurityProcess";

extern void __wrap_logd_printf(const char *fmt)
{
  (void) printf(fmt);
}

extern logd_t * __wrap_logd_new(const char *logdProcessName,
                         int levelMax, /* obsolete ! */
                         const char *appl,
                         sc_poolid_t plid,
                         sc_ticks_t tmo)
{
  return NULL;
}

extern uint32_t __wrap___sc_tickMs2Tick(uint32_t ticks)
{
  function_called();
  return ticks;
}

extern sc_pid_t __wrap___sc_msgSndGet(sc_msg_t* msg)
{
  return (sc_pid_t) mock();
}

extern void __wrap_HlpMsg_AssertFreed_f(logd_t * logd, sc_msg_t * pm, const char * file, int line, const char * func)
{
  function_called();
}

extern int8_t __wrap_SecurityHsm_VerifySignatureExternal(logd_t* const logd, hsmParam_S* const pParam)
{
  const uint8_t  signatureMatch = (uint8_t) mock();
  if ( NULL != pParam )
  {
    pParam->result = signatureMatch;
  }
  return (int) mock();
}

extern int __wrap_SecurityHsm_SetConfig(logd_t* const logd)
{
  return (int) mock();
}

extern int __wrap_SecurityHsm_CheckConfig(logd_t* const logd)
{
  return (int) mock();
}

extern int __wrap_SecurityHsm_GenKey(logd_t* const logd, hsmParams_S* const pParam)
{
  return (int) mock();
}

extern int __wrap_SecurityHsm_SetLock(logd_t* const logd, hsmParams_S* const pParam)
{
  return (int) mock();
}

extern int __wrap_SecuritySecureBoot_SecureDevice(logd_t* const logd)
{
  return (int) mock();
}

//! @}


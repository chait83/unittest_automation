#!/bin/bash

STUBS+=("logd_printf")
STUBS+=("ATECC508_Cmd_GenKey")
STUBS+=("ATECC508_Cmd_Verify")
STUBS+=("ATECC508_GoIdle")
STUBS+=("ATECC508_GoSleep")
STUBS+=("ATECC508_lockCfg")
STUBS+=("ATECC508_lockDev")
STUBS+=("ATECC508_lockSlot")
STUBS+=("ATECC508_performCreateDataHash")
STUBS+=("ATECC508_readCfgLock")
STUBS+=("ATECC508_readData")
STUBS+=("ATECC508_readDevLock")
STUBS+=("ATECC508_readKeyCfg")
STUBS+=("ATECC508_readSlotCfg")
STUBS+=("ATECC508_readSlotLock")
STUBS+=("ATECC508_WakeUp")
STUBS+=("ATECC508_writeData")
STUBS+=("ATECC508_writeKeyCfg")
STUBS+=("ATECC508_writeSlotCfg")
STUBS+=("SecurityHsm_CheckConfig")
STUBS+=("SecurityHsm_GetConfig")
STUBS+=("hsmInternalCheckParams")
STUBS+=("hsmInternalCommSync")
STUBS+=("hsmInternalCompareConfiguration")

#STUBS+=("")
STUB_WRAPS=${STUBS[@]/#/\-Wl,$2} # Diab wrap option syntax is different than GNU so pass in as parameter from make file

LINK+=("cmocka/wrap/sciopta.o")
LINK+=("cmocka/wrap/common/Hlp/Proc.o")
LINK+=("cmocka/wrap/common/Hlp/Msg.o")
LINK+=("cmocka/wrap/common/Crypto/ATECC508.o")
LINK+=("src/common/Security/HsmHelper.o")  ## use real module

LINK_OBJECT=${LINK[@]/#/$1}

shift 2

$* ${LINK_OBJECT} ${STUB_WRAPS}

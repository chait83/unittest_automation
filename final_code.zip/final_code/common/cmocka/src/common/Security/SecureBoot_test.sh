#!/bin/bash

STUBS+=("__sc_sleep")
STUBS+=("__sc_tickMs2Tick")
STUBS+=("logd_printf")
STUBS+=("Nvm_GetUInt64")
STUBS+=("Nvm_WriteUInt64")
STUBS+=("Nvm_Unlock")
STUBS+=("Nvm_Lock")
STUBS+=("EepromEProc_ReadData")
STUBS+=("ATECC508_performGenerateRandomNumber")
STUBS+=("SecuritySecureBoot_IsSecure")
STUBS+=("SecuritySecureBoot_Censor")
STUBS+=("SecuritySecureBoot_LockOtp")
STUBS+=("SecuritySecureBoot_Fill")
STUBS+=("SecuritySecureBoot_GenerateKey")
STUBS+=("SecuritySecureBoot_GetRandom")
STUBS+=("SecuritySecureBoot_DcfIsClean")
STUBS+=("SecuritySecureBoot_RandomCheck")
STUBS+=("SecuritySecureBoot_GetUid")
#STUBS+=("")
STUB_WRAPS=${STUBS[@]/#/\-Wl,$2} # Diab wrap option syntax is different than GNU so pass in as parameter from make file

LINK+=("cmocka/wrap/sciopta.o")
LINK+=("cmocka/wrap/common/Hlp/Proc.o")
LINK+=("cmocka/wrap/common/Hlp/Msg.o")
LINK+=("src/common/Security/SecureBootHelper.o")  ## use real module
LINK+=("src/common/Security/SecureBootRandom.o")  ## use real module

LINK_OBJECT=${LINK[@]/#/$1}

shift 2

$* $LINK_OBJECT $STUB_WRAPS

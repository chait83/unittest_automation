// *****************************************************************************
// **                _______   _________  _________   _______                 **
// **               (  ___  )  \__   __/  \__   __/  (  ____ \                **
// **               | (   ) |     ) (        ) (     | (    \/                **
// **               | |   | |     | |        | |     | (_____                 **
// **               | |   | |     | |        | |     (_____  )                **
// **               | |   | |     | |        | |           ) |                **
// **               | (___) |     | |     ___) (___  /\____) |                **
// **               (_______)     )_(     \_______/  \_______)                **
// **                                                                         **
// **                        Lead Design Center Berlin                        **
// **                                                                         **
// **   Copyright 2021 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **
// **                                                                         **
// *****************************************************************************
//!
//! @file
//!
//! @brief cmocka test file for src/common/Security/SecureBoot.c
//!
// *****************************************************************************
#include <setjmp.h>
#include <stdio.h>
#include <inttypes.h>
#include <stdarg.h>
#include "cmocka.h"
#include "Cfg/MsgIds.h"
#include "Cfg/Self.h"
#include "Nvm.h"
#include "Crypto/ATECC508.h"
#include "Security/SecureBoot.h"
#include "Security/SecureBootHelper.h"
#include "Security/SecureBootRandom.h"



//! @brief wrapper function for SecuritySecureBoot_IsSecure()
extern int __wrap_SecuritySecureBoot_IsSecure(void);
//! @brief callback for real function of SecuritySecureBoot_IsSecure()
extern int __real_SecuritySecureBoot_IsSecure(void);

//! @brief wrapper function for SecuritySecureBoot_Censor()
extern int __wrap_SecuritySecureBoot_Censor(logd_t* const logd);
//! @brief callback for real function of SecuritySecureBoot_Censor()
extern int __real_SecuritySecureBoot_Censor(logd_t* const logd);

//! @brief wrapper function for SecuritySecureBoot_LockOtp()
extern int __wrap_SecuritySecureBoot_LockOtp(void);
//! @brief callback for real function of SecuritySecureBoot_LockOtp()
extern int __real_SecuritySecureBoot_LockOtp(void);

//! @brief wrapper function for SecuritySecureBoot_Fill()
extern int __wrap_SecuritySecureBoot_Fill(void);
//! @brief callback for real function of SecuritySecureBoot_Fill()
extern int __real_SecuritySecureBoot_Fill(void);

//! @brief wrapper function for SecuritySecureBoot_DcfIsClean()
extern bool __wrap_SecuritySecureBoot_DcfIsClean(const size_t pos);
//! @brief callback for real function of SecuritySecureBoot_DcfIsClean()
extern bool __real_SecuritySecureBoot_DcfIsClean(const size_t pos);

//! @brief wrapper function for SecuritySecureBoot_GenerateKey()
extern int __wrap_SecuritySecureBoot_GenerateKey(logd_t* const logd, uint8_t* const pBuf, const size_t len);
//! @brief callback for real function of SecuritySecureBoot_GenerateKey()
extern int __real_SecuritySecureBoot_GenerateKey(logd_t* const logd, uint8_t* const pBuf, const size_t len);

//! @brief wrapper function for SecuritySecureBoot_GetRandom()
extern int __wrap_SecuritySecureBoot_GetRandom(logd_t* const logd, uint8_t* const pBuf, const size_t len);
//! @brief callback for real function of SecuritySecureBoot_GetRandom()
extern int __real_SecuritySecureBoot_GetRandom(logd_t* const logd, uint8_t* const pBuf, const size_t len);

//! @brief wrapper function for SecuritySecureBoot_RandomCheck()
extern bool __wrap_SecuritySecureBoot_RandomCheck(const uint8_t* const pBuf, const size_t len);
//! @brief callback for real function of SecuritySecureBoot_RandomCheck()
extern bool __real_SecuritySecureBoot_RandomCheck(const uint8_t* const pBuf, const size_t len);

//! @brief wrapper function for SecuritySecureBoot_GetUid()
extern int __wrap_SecuritySecureBoot_GetUid(uint8_t* const pBuf, const size_t len);
//! @brief callback for real function of SecuritySecureBoot_GetUid()
extern int __real_SecuritySecureBoot_GetUid(uint8_t* const pBuf, const size_t len);



#if 0
static void hexdump ( const void* const buf, const size_t buflen, const size_t width ) {

  const uint8_t* const  p = buf;
  size_t  i;

  if ( (NULL == buf)  ||  (0 == buflen) ) {
    return;
  }

  for ( i = 0; i < buflen; ++i ) {
    printf ("%02X", p[i]);
    if ( (i+1) == buflen ) {
      printf ("\n");
    } else if ( (0 < width)  &&  (0 == ((i+1) % width)) ) {
      printf ("\n");
    } else if ( (i+1) < buflen ) {
      printf (" ");
    }
  }
}
#endif


static logd_t  logd;


//! @brief  helper for filling DCF-records
static void test_SecuritySecureBoot_IsSecure_helper_record_reader(const uint64_t* const dcf, const size_t dcf_len)
{
  const size_t  limit = DCF_SIZE / sizeof (uint64_t);
  size_t  i;
  uint64_t  val;

  for ( i = 0; i < limit; ++i )
  {
    val = DCF_RECORD_EMPTY;
    if (   (NULL != dcf)
        && (i < dcf_len)
       )
    {
      val = dcf[i];
    }
    will_return (__wrap_Nvm_GetUInt64,   0);  // no error
    will_return (__wrap_Nvm_GetUInt64, val);  // value
    expect_function_calls (__wrap_Nvm_GetUInt64, 1);
    if ( DCF_RECORD_STOP == val )
    {
      break;
    }
    if ( DCF_RECORD_EMPTY == val )
    {
      break;
    }
  }
}


//! @brief  GetUInt64 fails
static void test_SecuritySecureBoot_IsSecure_read_fail(void)
{
  will_return (__wrap_Nvm_GetUInt64,  1);  // error
  will_return (__wrap_Nvm_GetUInt64, 42);  // value
  expect_function_calls (__wrap_Nvm_GetUInt64, 1);

  will_return (__wrap_SecuritySecureBoot_IsSecure, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_IsSecure(), -1);  // failed
}


//! @brief  all DCF records present and valid
static void test_SecuritySecureBoot_IsSecure_01(void)
{
  const uint64_t  dcf[] =
  { // DCF_CLIENT     | DCF_DATA
    DCF_CLIENT_NVSCI  | (DCF_DATA_NVSCI << 32U),
    DCF_CLIENT_NVPWDH | (((0x1234ULL << 16U) | (0x5678ULL << 0U)) << 32U),
    DCF_CLIENT_NVPWDL | (((0x1234ULL << 16U) | (0x5678ULL << 0U)) << 32U),
    DCF_CLIENT_OTP_256L,
    DCF_CLIENT_OTP_HI,
    DCF_CLIENT_OTP_LO_MID,
    DCF_RECORD_STOP,
  };

  test_SecuritySecureBoot_IsSecure_helper_record_reader (dcf, sizeof(dcf)/sizeof(*dcf));

  will_return (__wrap_SecuritySecureBoot_IsSecure, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_IsSecure(), 1);  // secure
}


//! @brief  DCF_CLIENT_NVSCI missing
static void test_SecuritySecureBoot_IsSecure_02a(void)
{
  const uint64_t  dcf[] =
  { // DCF_CLIENT     | DCF_DATA
//    DCF_CLIENT_NVSCI  | (DCF_DATA_NVSCI << 32U), missing
    DCF_CLIENT_NVPWDH | (((0x1234ULL << 16U) | (0x5678ULL << 0U)) << 32U),
    DCF_CLIENT_NVPWDL | (((0x1234ULL << 16U) | (0x5678ULL << 0U)) << 32U),
    DCF_CLIENT_OTP_256L,
    DCF_CLIENT_OTP_HI,
    DCF_CLIENT_OTP_LO_MID,
    DCF_RECORD_STOP,
  };

  test_SecuritySecureBoot_IsSecure_helper_record_reader (dcf, sizeof(dcf)/sizeof(*dcf));

  will_return (__wrap_SecuritySecureBoot_IsSecure, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_IsSecure(), 0);  // not secure
}


//! @brief  DCF_CLIENT_NVSCI has bad data
static void test_SecuritySecureBoot_IsSecure_02b(void)
{
  const uint64_t  dcf[] =
  { // DCF_CLIENT     | DCF_DATA
    DCF_CLIENT_NVSCI,  // no DCF_DATA_NVSCI
    DCF_CLIENT_NVPWDH | (((0x1234ULL << 16U) | (0x5678ULL << 0U)) << 32U),
    DCF_CLIENT_NVPWDL | (((0x1234ULL << 16U) | (0x5678ULL << 0U)) << 32U),
    DCF_CLIENT_OTP_256L,
    DCF_CLIENT_OTP_HI,
    DCF_CLIENT_OTP_LO_MID,
    DCF_RECORD_STOP,
  };

  test_SecuritySecureBoot_IsSecure_helper_record_reader (dcf, sizeof(dcf)/sizeof(*dcf));

  will_return (__wrap_SecuritySecureBoot_IsSecure, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_IsSecure(), 0);  // not secure
}


//! @brief  DCF_CLIENT_NVPWDH missing
static void test_SecuritySecureBoot_IsSecure_03(void)
{
  const uint64_t  dcf[] =
  { // DCF_CLIENT     | DCF_DATA
    DCF_CLIENT_NVSCI  | (DCF_DATA_NVSCI << 32U),
//    DCF_CLIENT_NVPWDH | (((0x1234ULL << 16U) | (0x5678ULL << 0U)) << 32U), missing
    DCF_CLIENT_NVPWDL | (((0x1234ULL << 16U) | (0x5678ULL << 0U)) << 32U),
    DCF_CLIENT_OTP_256L,
    DCF_CLIENT_OTP_HI,
    DCF_CLIENT_OTP_LO_MID,
    DCF_RECORD_STOP,
  };

  test_SecuritySecureBoot_IsSecure_helper_record_reader (dcf, sizeof(dcf)/sizeof(*dcf));

  will_return (__wrap_SecuritySecureBoot_IsSecure, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_IsSecure(), 0);  // not secure
}


//! @brief  DCF_CLIENT_NVPWDL missing
static void test_SecuritySecureBoot_IsSecure_04(void)
{
  const uint64_t  dcf[] =
  { // DCF_CLIENT     | DCF_DATA
    DCF_CLIENT_NVSCI  | (DCF_DATA_NVSCI << 32U),
    DCF_CLIENT_NVPWDH | (((0x1234ULL << 16U) | (0x5678ULL << 0U)) << 32U),
//    DCF_CLIENT_NVPWDL | (((0x1234ULL << 16U) | (0x5678ULL << 0U)) << 32U), missing
    DCF_CLIENT_OTP_256L,
    DCF_CLIENT_OTP_HI,
    DCF_CLIENT_OTP_LO_MID,
    DCF_RECORD_STOP,
  };

  test_SecuritySecureBoot_IsSecure_helper_record_reader (dcf, sizeof(dcf)/sizeof(*dcf));

  will_return (__wrap_SecuritySecureBoot_IsSecure, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_IsSecure(), 0);  // not secure
}


//! @brief  DCF_CLIENT_OTP_256L missing
static void test_SecuritySecureBoot_IsSecure_05(void)
{
  const uint64_t  dcf[] =
  { // DCF_CLIENT     | DCF_DATA
    DCF_CLIENT_NVSCI  | (DCF_DATA_NVSCI << 32U),
    DCF_CLIENT_NVPWDH | (((0x1234ULL << 16U) | (0x5678ULL << 0U)) << 32U),
    DCF_CLIENT_NVPWDL | (((0x1234ULL << 16U) | (0x5678ULL << 0U)) << 32U),
//    DCF_CLIENT_OTP_256L, missing
    DCF_CLIENT_OTP_HI,
    DCF_CLIENT_OTP_LO_MID,
    DCF_RECORD_STOP,
  };

  test_SecuritySecureBoot_IsSecure_helper_record_reader (dcf, sizeof(dcf)/sizeof(*dcf));

  will_return (__wrap_SecuritySecureBoot_IsSecure, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_IsSecure(), 0);  // not secure
}


//! @brief  DCF_CLIENT_OTP_HI missing
static void test_SecuritySecureBoot_IsSecure_06(void)
{
  const uint64_t  dcf[] =
  { // DCF_CLIENT     | DCF_DATA
    DCF_CLIENT_NVSCI  | (DCF_DATA_NVSCI << 32U),
    DCF_CLIENT_NVPWDH | (((0x1234ULL << 16U) | (0x5678ULL << 0U)) << 32U),
    DCF_CLIENT_NVPWDL | (((0x1234ULL << 16U) | (0x5678ULL << 0U)) << 32U),
    DCF_CLIENT_OTP_256L,
//    DCF_CLIENT_OTP_HI, missing
    DCF_CLIENT_OTP_LO_MID,
    DCF_RECORD_STOP,
  };

  test_SecuritySecureBoot_IsSecure_helper_record_reader (dcf, sizeof(dcf)/sizeof(*dcf));

  will_return (__wrap_SecuritySecureBoot_IsSecure, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_IsSecure(), 0);  // not secure
}


//! @brief  DCF_CLIENT_OTP_LO_MID missing
static void test_SecuritySecureBoot_IsSecure_07(void)
{
  const uint64_t  dcf[] =
  { // DCF_CLIENT     | DCF_DATA
    DCF_CLIENT_NVSCI  | (DCF_DATA_NVSCI << 32U),
    DCF_CLIENT_NVPWDH | (((0x1234ULL << 16U) | (0x5678ULL << 0U)) << 32U),
    DCF_CLIENT_NVPWDL | (((0x1234ULL << 16U) | (0x5678ULL << 0U)) << 32U),
    DCF_CLIENT_OTP_256L,
    DCF_CLIENT_OTP_HI,
//    DCF_CLIENT_OTP_LO_MID, missing
    DCF_RECORD_STOP,
  };

  test_SecuritySecureBoot_IsSecure_helper_record_reader (dcf, sizeof(dcf)/sizeof(*dcf));

  will_return (__wrap_SecuritySecureBoot_IsSecure, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_IsSecure(), 0);  // not secure
}


//! @brief  DCF_RECORD_STOP missing
static void test_SecuritySecureBoot_IsSecure_08(void)
{
  const uint64_t  dcf[] =
  { // DCF_CLIENT     | DCF_DATA
    DCF_CLIENT_NVSCI  | (DCF_DATA_NVSCI << 32U),
    DCF_CLIENT_NVPWDH | (((0x1234ULL << 16U) | (0x5678ULL << 0U)) << 32U),
    DCF_CLIENT_NVPWDL | (((0x1234ULL << 16U) | (0x5678ULL << 0U)) << 32U),
    DCF_CLIENT_OTP_256L,
    DCF_CLIENT_OTP_HI,
    DCF_CLIENT_OTP_LO_MID,
//    DCF_RECORD_STOP, missing
  };

  test_SecuritySecureBoot_IsSecure_helper_record_reader (dcf, sizeof(dcf)/sizeof(*dcf));

  will_return (__wrap_SecuritySecureBoot_IsSecure, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_IsSecure(), 0);  // not secure
}


//! @brief  DCF_CLIENT_NVPWDH high data invalid (0x0000)
static void test_SecuritySecureBoot_IsSecure_09a(void)
{
  const uint64_t  dcf[] =
  { // DCF_CLIENT     | DCF_DATA
    DCF_CLIENT_NVSCI  | (DCF_DATA_NVSCI << 32U),
    DCF_CLIENT_NVPWDH | (((0x0000ULL << 16U) | (0x5678ULL << 0U)) << 32U),  // high data invalid (0x0000)
    DCF_CLIENT_NVPWDL | (((0x1234ULL << 16U) | (0x5678ULL << 0U)) << 32U),
    DCF_CLIENT_OTP_256L,
    DCF_CLIENT_OTP_HI,
    DCF_CLIENT_OTP_LO_MID,
    DCF_RECORD_STOP,
  };

  test_SecuritySecureBoot_IsSecure_helper_record_reader (dcf, sizeof(dcf)/sizeof(*dcf));

  will_return (__wrap_SecuritySecureBoot_IsSecure, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_IsSecure(), 0);  // not secure
}


//! @brief  DCF_CLIENT_NVPWDH high data invalid (0xFFFF)
static void test_SecuritySecureBoot_IsSecure_09b(void)
{
  const uint64_t  dcf[] =
  { // DCF_CLIENT     | DCF_DATA
    DCF_CLIENT_NVSCI  | (DCF_DATA_NVSCI << 32U),
    DCF_CLIENT_NVPWDH | (((0xFFFFULL << 16U) | (0x5678ULL << 0U)) << 32U),  // high data invalid (0xFFFF)
    DCF_CLIENT_NVPWDL | (((0x1234ULL << 16U) | (0x5678ULL << 0U)) << 32U),
    DCF_CLIENT_OTP_256L,
    DCF_CLIENT_OTP_HI,
    DCF_CLIENT_OTP_LO_MID,
    DCF_RECORD_STOP,
  };

  test_SecuritySecureBoot_IsSecure_helper_record_reader (dcf, sizeof(dcf)/sizeof(*dcf));

  will_return (__wrap_SecuritySecureBoot_IsSecure, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_IsSecure(), 0);  // not secure
}


//! @brief  DCF_CLIENT_NVPWDH low data invalid (0x0000)
static void test_SecuritySecureBoot_IsSecure_09c(void)
{
  const uint64_t  dcf[] =
  { // DCF_CLIENT     | DCF_DATA
    DCF_CLIENT_NVSCI  | (DCF_DATA_NVSCI << 32U),
    DCF_CLIENT_NVPWDH | (((0x1234ULL << 16U) | (0x0000ULL << 0U)) << 32U),  // low data invalid (0x0000)
    DCF_CLIENT_NVPWDL | (((0x1234ULL << 16U) | (0x5678ULL << 0U)) << 32U),
    DCF_CLIENT_OTP_256L,
    DCF_CLIENT_OTP_HI,
    DCF_CLIENT_OTP_LO_MID,
    DCF_RECORD_STOP,
  };

  test_SecuritySecureBoot_IsSecure_helper_record_reader (dcf, sizeof(dcf)/sizeof(*dcf));

  will_return (__wrap_SecuritySecureBoot_IsSecure, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_IsSecure(), 0);  // not secure
}


//! @brief  DCF_CLIENT_NVPWDH low data invalid (0xFFFF)
static void test_SecuritySecureBoot_IsSecure_09d(void)
{
  const uint64_t  dcf[] =
  { // DCF_CLIENT     | DCF_DATA
    DCF_CLIENT_NVSCI  | (DCF_DATA_NVSCI << 32U),
    DCF_CLIENT_NVPWDH | (((0x1234ULL << 16U) | (0xFFFFULL << 0U)) << 32U),  // low data invalid (0xFFFF)
    DCF_CLIENT_NVPWDL | (((0x1234ULL << 16U) | (0x5678ULL << 0U)) << 32U),
    DCF_CLIENT_OTP_256L,
    DCF_CLIENT_OTP_HI,
    DCF_CLIENT_OTP_LO_MID,
    DCF_RECORD_STOP,
  };

  test_SecuritySecureBoot_IsSecure_helper_record_reader (dcf, sizeof(dcf)/sizeof(*dcf));

  will_return (__wrap_SecuritySecureBoot_IsSecure, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_IsSecure(), 0);  // not secure
}


//! @brief  DCF_CLIENT_NVPWDL high data invalid (0x0000)
static void test_SecuritySecureBoot_IsSecure_10a(void)
{
  const uint64_t  dcf[] =
  { // DCF_CLIENT     | DCF_DATA
    DCF_CLIENT_NVSCI  | (DCF_DATA_NVSCI << 32U),
    DCF_CLIENT_NVPWDH | (((0x1234ULL << 16U) | (0x5678ULL << 0U)) << 32U),
    DCF_CLIENT_NVPWDL | (((0x0000ULL << 16U) | (0x5678ULL << 0U)) << 32U),  // high data invalid (0x0000)
    DCF_CLIENT_OTP_256L,
    DCF_CLIENT_OTP_HI,
    DCF_CLIENT_OTP_LO_MID,
    DCF_RECORD_STOP,
  };

  test_SecuritySecureBoot_IsSecure_helper_record_reader (dcf, sizeof(dcf)/sizeof(*dcf));

  will_return (__wrap_SecuritySecureBoot_IsSecure, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_IsSecure(), 0);  // not secure
}


//! @brief  DCF_CLIENT_NVPWDL high data invalid (0xFFFF)
static void test_SecuritySecureBoot_IsSecure_10b(void)
{
  const uint64_t  dcf[] =
  { // DCF_CLIENT     | DCF_DATA
    DCF_CLIENT_NVSCI  | (DCF_DATA_NVSCI << 32U),
    DCF_CLIENT_NVPWDH | (((0x1234ULL << 16U) | (0x5678ULL << 0U)) << 32U),
    DCF_CLIENT_NVPWDL | (((0xFFFFULL << 16U) | (0x5678ULL << 0U)) << 32U),  // high data invalid (0xFFFF)
    DCF_CLIENT_OTP_256L,
    DCF_CLIENT_OTP_HI,
    DCF_CLIENT_OTP_LO_MID,
    DCF_RECORD_STOP,
  };

  test_SecuritySecureBoot_IsSecure_helper_record_reader (dcf, sizeof(dcf)/sizeof(*dcf));

  will_return (__wrap_SecuritySecureBoot_IsSecure, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_IsSecure(), 0);  // not secure
}


//! @brief  DCF_CLIENT_NVPWDL low data invalid (0x0000)
static void test_SecuritySecureBoot_IsSecure_10c(void)
{
  const uint64_t  dcf[] =
  { // DCF_CLIENT     | DCF_DATA
    DCF_CLIENT_NVSCI  | (DCF_DATA_NVSCI << 32U),
    DCF_CLIENT_NVPWDH | (((0x1234ULL << 16U) | (0x5678ULL << 0U)) << 32U),
    DCF_CLIENT_NVPWDL | (((0x1234ULL << 16U) | (0x0000ULL << 0U)) << 32U),  // low data invalid (0x0000)
    DCF_CLIENT_OTP_256L,
    DCF_CLIENT_OTP_HI,
    DCF_CLIENT_OTP_LO_MID,
    DCF_RECORD_STOP,
  };

  test_SecuritySecureBoot_IsSecure_helper_record_reader(dcf, sizeof(dcf)/sizeof(*dcf));

  will_return (__wrap_SecuritySecureBoot_IsSecure, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_IsSecure(), 0);  // not secure
}


//! @brief  DCF_CLIENT_NVPWDL low data invalid (0xFFFF)
static void test_SecuritySecureBoot_IsSecure_10d(void)
{
  const uint64_t  dcf[] =
  { // DCF_CLIENT     | DCF_DATA
    DCF_CLIENT_NVSCI  | (DCF_DATA_NVSCI << 32U),
    DCF_CLIENT_NVPWDH | (((0x1234ULL << 16U) | (0x5678ULL << 0U)) << 32U),
    DCF_CLIENT_NVPWDL | (((0x1234ULL << 16U) | (0xFFFFULL << 0U)) << 32U),  // low data invalid (0xFFFF)
    DCF_CLIENT_OTP_256L,
    DCF_CLIENT_OTP_HI,
    DCF_CLIENT_OTP_LO_MID,
    DCF_RECORD_STOP,
  };

  test_SecuritySecureBoot_IsSecure_helper_record_reader (dcf, sizeof(dcf)/sizeof(*dcf));

  will_return (__wrap_SecuritySecureBoot_IsSecure, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_IsSecure(), 0);  // not secure
}


//! @brief  DCF_CLIENT_NVPWDL invalid (0xFFFF) data follows valid data
static void test_SecuritySecureBoot_IsSecure_10e(void)
{
  const uint64_t  dcf[] =
  { // DCF_CLIENT     | DCF_DATA
    DCF_CLIENT_NVSCI  | (DCF_DATA_NVSCI << 32U),
    DCF_CLIENT_NVPWDH | (((0x1234ULL << 16U) | (0x5678ULL << 0U)) << 32U),
    DCF_CLIENT_NVPWDL | (((0x1234ULL << 16U) | (0x5678ULL << 0U)) << 32U),  // low data valid
    DCF_CLIENT_NVPWDL | (((0x1234ULL << 16U) | (0xFFFFULL << 0U)) << 32U),  // low data invalid (0xFFFF)
    DCF_CLIENT_OTP_256L,
    DCF_CLIENT_OTP_HI,
    DCF_CLIENT_OTP_LO_MID,
    DCF_RECORD_STOP,
  };

  test_SecuritySecureBoot_IsSecure_helper_record_reader (dcf, sizeof(dcf)/sizeof(*dcf));

  will_return (__wrap_SecuritySecureBoot_IsSecure, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_IsSecure(), 0);  // not secure
}


//! @brief  DCF_CLIENT_NVPWDH invalid (0xFFFF) data follows valid data
static void test_SecuritySecureBoot_IsSecure_10f(void)
{
  const uint64_t  dcf[] =
  { // DCF_CLIENT     | DCF_DATA
    DCF_CLIENT_NVSCI  | (DCF_DATA_NVSCI << 32U),
    DCF_CLIENT_NVPWDH | (((0x1234ULL << 16U) | (0x5678ULL << 0U)) << 32U),  // low data valid
    DCF_CLIENT_NVPWDH | (((0x1234ULL << 16U) | (0xFFFFULL << 0U)) << 32U),  // low data invalid (0xFFFF)
    DCF_CLIENT_OTP_256L,
    DCF_CLIENT_OTP_HI,
    DCF_CLIENT_OTP_LO_MID,
    DCF_RECORD_STOP,
  };

  test_SecuritySecureBoot_IsSecure_helper_record_reader (dcf, sizeof(dcf)/sizeof(*dcf));

  will_return (__wrap_SecuritySecureBoot_IsSecure, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_IsSecure(), 0);  // not secure
}


//! @brief  all DCF records present and valid, but unknown record present
static void test_SecuritySecureBoot_IsSecure_11(void)
{
  const uint64_t  dcf[] =
  { // DCF_CLIENT     | DCF_DATA
    DCF_CLIENT_NVSCI  | (DCF_DATA_NVSCI << 32U),
    DCF_CLIENT_NVPWDH | (((0x1234ULL << 16U) | (0x5678ULL << 0U)) << 32U),
    DCF_CLIENT_NVPWDL | (((0x1234ULL << 16U) | (0x5678ULL << 0U)) << 32U),
    DCF_CLIENT_OTP_256L,
    DCF_CLIENT_OTP_HI,
    DCF_CLIENT_OTP_LO_MID,
    0x1234567812345678ULL,  // unknown record must be ignored
    DCF_RECORD_STOP,
  };

  test_SecuritySecureBoot_IsSecure_helper_record_reader (dcf, sizeof(dcf)/sizeof(*dcf));

  will_return (__wrap_SecuritySecureBoot_IsSecure, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_IsSecure(), 1);  // secure
}


//! @brief  stop-record too early
static void test_SecuritySecureBoot_IsSecure_12(void)
{
  const uint64_t  dcf[] =
  { // DCF_CLIENT     | DCF_DATA
    DCF_CLIENT_NVSCI  | (DCF_DATA_NVSCI << 32U),
    DCF_CLIENT_NVPWDH | (((0x1234ULL << 16U) | (0x5678ULL << 0U)) << 32U),
    DCF_CLIENT_NVPWDL | (((0x1234ULL << 16U) | (0x5678ULL << 0U)) << 32U),
    DCF_CLIENT_OTP_256L,
    DCF_CLIENT_OTP_HI,
    DCF_RECORD_STOP,  // stop-record too early
    DCF_CLIENT_OTP_LO_MID,
  };

  test_SecuritySecureBoot_IsSecure_helper_record_reader (dcf, sizeof(dcf)/sizeof(*dcf));

  will_return (__wrap_SecuritySecureBoot_IsSecure, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_IsSecure(), 0);  // not secure
}

//! @brief  no DCF record programmed
static void test_SecuritySecureBoot_IsSecure_Unprogrammed(void)
{
  const uint64_t  dcf[] =
  {
    DCF_RECORD_EMPTY,
    DCF_RECORD_EMPTY,
    DCF_RECORD_EMPTY,
    DCF_RECORD_EMPTY,
  };

  test_SecuritySecureBoot_IsSecure_helper_record_reader (dcf, sizeof(dcf)/sizeof(*dcf));

  will_return (__wrap_SecuritySecureBoot_IsSecure, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_IsSecure(), 0);  // not secure
}

//! @brief  DCF-space full
static void test_SecuritySecureBoot_IsSecure_Full(void)
{
  const size_t  limit = DCF_SIZE / sizeof (uint64_t);
  size_t  i;

  for ( i = 0; i < limit; ++i )
  {
    will_return (__wrap_Nvm_GetUInt64, 0);  // no error
    will_return (__wrap_Nvm_GetUInt64, 0x1122334455667788ULL);  // value
    expect_function_calls (__wrap_Nvm_GetUInt64, 1);
  }

  will_return (__wrap_SecuritySecureBoot_IsSecure, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_IsSecure(), 0);  // not secure
}

//! @brief  preprogrammed password by manufacturer/attacker (without STOP)
static void test_SecuritySecureBoot_IsSecure_HoleNoStop(void)
{
  const uint64_t  dcf[] =
  { // DCF_CLIENT     | DCF_DATA
    DCF_RECORD_EMPTY,
    DCF_RECORD_EMPTY,
    DCF_RECORD_EMPTY,
    DCF_RECORD_EMPTY,
    DCF_RECORD_EMPTY,
    DCF_RECORD_EMPTY,
    DCF_CLIENT_NVPWDH | (((0x1234ULL << 16U) | (0x5678ULL << 0U)) << 32U),
    DCF_CLIENT_NVPWDL | (((0x1234ULL << 16U) | (0x5678ULL << 0U)) << 32U),
  };

  test_SecuritySecureBoot_IsSecure_helper_record_reader (dcf, sizeof(dcf)/sizeof(*dcf));

  will_return (__wrap_SecuritySecureBoot_IsSecure, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_IsSecure(), 0);  // not secure
}

//! @brief  preprogrammed password by manufacturer/attacker (with STOP)
static void test_SecuritySecureBoot_IsSecure_HoleWithStop(void)
{
  const uint64_t  dcf[] =
  { // DCF_CLIENT     | DCF_DATA
    DCF_RECORD_EMPTY,
    DCF_RECORD_EMPTY,
    DCF_RECORD_EMPTY,
    DCF_RECORD_EMPTY,
    DCF_RECORD_EMPTY,
    DCF_RECORD_EMPTY,
    DCF_CLIENT_NVPWDH | (((0x1234ULL << 16U) | (0x5678ULL << 0U)) << 32U),
    DCF_CLIENT_NVPWDL | (((0x1234ULL << 16U) | (0x5678ULL << 0U)) << 32U),
    DCF_RECORD_STOP,
  };

  test_SecuritySecureBoot_IsSecure_helper_record_reader (dcf, sizeof(dcf)/sizeof(*dcf));

  will_return (__wrap_SecuritySecureBoot_IsSecure, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_IsSecure(), 0);  // not secure
}

static void test_SecuritySecureBoot_IsSecure(void** state)
{
  test_SecuritySecureBoot_IsSecure_read_fail();
  test_SecuritySecureBoot_IsSecure_01();
  test_SecuritySecureBoot_IsSecure_02a();
  test_SecuritySecureBoot_IsSecure_02b();
  test_SecuritySecureBoot_IsSecure_03();
  test_SecuritySecureBoot_IsSecure_04();
  test_SecuritySecureBoot_IsSecure_05();
  test_SecuritySecureBoot_IsSecure_06();
  test_SecuritySecureBoot_IsSecure_07();
  test_SecuritySecureBoot_IsSecure_08();
  test_SecuritySecureBoot_IsSecure_09a();
  test_SecuritySecureBoot_IsSecure_09b();
  test_SecuritySecureBoot_IsSecure_09c();
  test_SecuritySecureBoot_IsSecure_09d();
  test_SecuritySecureBoot_IsSecure_10a();
  test_SecuritySecureBoot_IsSecure_10b();
  test_SecuritySecureBoot_IsSecure_10c();
  test_SecuritySecureBoot_IsSecure_10d();
  test_SecuritySecureBoot_IsSecure_10e();
  test_SecuritySecureBoot_IsSecure_10f();
  test_SecuritySecureBoot_IsSecure_11();
  test_SecuritySecureBoot_IsSecure_12();
  test_SecuritySecureBoot_IsSecure_Unprogrammed();
  test_SecuritySecureBoot_IsSecure_Full();
  test_SecuritySecureBoot_IsSecure_HoleNoStop();
  test_SecuritySecureBoot_IsSecure_HoleWithStop();

  (void) state;
}


//! @brief  read a UID
static void test_SecuritySecureBoot_GetUid_01(void)
{
  uint8_t  buf[8] = {0};

  will_return (__wrap_Nvm_GetUInt64, 0);  // no error
  will_return (__wrap_Nvm_GetUInt64, 0x12345678AABBCCDDULL);  // value
  expect_function_calls (__wrap_Nvm_GetUInt64, 1);

  will_return (__wrap_SecuritySecureBoot_GetUid, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_GetUid (buf, sizeof (buf)), 0);  // success
  assert_memory_equal (buf, (uint8_t [sizeof (buf)]){"\xDD\xCC\xBB\xAA\x78\x56\x34\x12"}, sizeof (buf));
}

//! @brief  no buffer
static void test_SecuritySecureBoot_GetUid_02(void)
{
  will_return (__wrap_SecuritySecureBoot_GetUid, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_GetUid (NULL, 8), -1);  // failed
}

//! @brief  zero-length buffer
static void test_SecuritySecureBoot_GetUid_03(void)
{
  uint8_t  buf[8] = {0};

  will_return (__wrap_SecuritySecureBoot_GetUid, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_GetUid (buf, 0), -1);  // failed
}

//! @brief  bad length
static void test_SecuritySecureBoot_GetUid_04(void)
{
  uint8_t  buf[23] = {0};

  will_return (__wrap_SecuritySecureBoot_GetUid, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_GetUid (buf, sizeof (buf)), -1);  // failed
}

//! @brief  read failed
static void test_SecuritySecureBoot_GetUid_05(void)
{
  uint8_t  buf[8] = {0};

  will_return (__wrap_Nvm_GetUInt64,  1);  // error
  will_return (__wrap_Nvm_GetUInt64, 23);  // value
  expect_function_calls (__wrap_Nvm_GetUInt64, 1);

  will_return (__wrap_SecuritySecureBoot_GetUid, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_GetUid (buf, sizeof (buf)), -1);  // failed
}


static void test_SecuritySecureBoot_GetUid(void** state)
{
  test_SecuritySecureBoot_GetUid_01();
  test_SecuritySecureBoot_GetUid_02();
  test_SecuritySecureBoot_GetUid_03();
  test_SecuritySecureBoot_GetUid_04();
  test_SecuritySecureBoot_GetUid_05();

  (void)state;
}


//! @brief  check various data-patterns for forbidden values
static void test_SecuritySecureBoot_RandomCheck(void** state)
{
  const struct
  {
    const bool            rc;
    const size_t          len;
    const uint8_t* const  buf;
  } tests[] =
  {
    {true ,  8, (const uint8_t* const) "\x01\x23\x45\x67\x89\xAB\xCD\xEF"},

    {false,  8, (const uint8_t* const) NULL},
    {false,  0, (const uint8_t* const) ""},
    {false, 11, (const uint8_t* const) "\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"},
    {false,  8, (const uint8_t* const) "\x00\x00\x00\x00\x00\x00\x00\x00"},
    {false,  8, (const uint8_t* const) "\xFF\xFF\x00\x00\xFF\xFF\x00\x00"},
    {false,  8, (const uint8_t* const) "\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF"},

    {true ,  8, (const uint8_t* const) "\x11\x11\x11\x11\x11\x11\x11\x11"},
    {false,  8, (const uint8_t* const) "\x11\x11\x11\x11\x11\x11\xFF\xFF"},
    {false,  8, (const uint8_t* const) "\x11\x11\x11\x11\xFF\xFF\x11\x11"},
    {false,  8, (const uint8_t* const) "\x11\x11\xFF\xFF\x11\x11\x11\x11"},
    {false,  8, (const uint8_t* const) "\xFF\xFF\x11\x11\x11\x11\x11\x11"},

    {true ,  8, (const uint8_t* const) "\x11\x11\x11\x11\x11\x11\x11\x11"},
    {false,  8, (const uint8_t* const) "\x11\x11\x11\x11\x11\x11\x00\x00"},
    {false,  8, (const uint8_t* const) "\x11\x11\x11\x11\x00\x00\x11\x11"},
    {false,  8, (const uint8_t* const) "\x11\x11\x00\x00\x11\x11\x11\x11"},
    {false,  8, (const uint8_t* const) "\x00\x00\x11\x11\x11\x11\x11\x11"},
  };
  size_t  i;

  for ( i = 0; i < sizeof(tests)/sizeof(*tests); ++i )
  {
    will_return (__wrap_SecuritySecureBoot_RandomCheck, false);  // do not mock

    assert_true (SecuritySecureBoot_RandomCheck (tests[i].buf, tests[i].len) == tests[i].rc);
  }

  (void)state;
}


//! @brief  get valid randomness from ATECC508
static void test_SecuritySecureBoot_GetRandom_01(void)
{
  uint8_t  buf[ATECC_RANDOM_SIZE] = {0};

  // (always mocked)
  will_return (__wrap_ATECC508_performGenerateRandomNumber, 0);  // no error
  expect_function_calls (__wrap_ATECC508_performGenerateRandomNumber, 1);

  will_return (__wrap_SecuritySecureBoot_RandomCheck, true);  // mock
  will_return (__wrap_SecuritySecureBoot_RandomCheck, true);  // no error
  expect_function_calls (__wrap_SecuritySecureBoot_RandomCheck, 1);

  will_return (__wrap_SecuritySecureBoot_GetRandom, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_GetRandom (&logd, buf, sizeof (buf)), 0);  // success
  assert_memory_not_equal (buf, (uint8_t [sizeof (buf)]){0}, sizeof (buf));
  assert_memory_not_equal (buf, (uint8_t [sizeof (buf)]){"\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF"}, sizeof (buf));
  assert_memory_not_equal (buf, (uint8_t [sizeof (buf)]){"\xFF\xFF\x00\x00\xFF\xFF\x00\x00\xFF\xFF\x00\x00\xFF\xFF\x00\x00\xFF\xFF\x00\x00\xFF\xFF\x00\x00\xFF\xFF\x00\x00\xFF\xFF\x00\x00"}, sizeof (buf));
}

//! @brief  get bad randomness-data from the ATECC (crypto chip not locked yet)
static void test_SecuritySecureBoot_GetRandom_02(void)
{
  uint8_t  buf[ATECC_RANDOM_SIZE] = {0};

  // (always mocked)
  will_return (__wrap_ATECC508_performGenerateRandomNumber, 42);  // get bad randomness
  expect_function_calls (__wrap_ATECC508_performGenerateRandomNumber, 1);

  will_return (__wrap_SecuritySecureBoot_RandomCheck, true);  // mock
  will_return (__wrap_SecuritySecureBoot_RandomCheck, false);  // error
  expect_function_calls (__wrap_SecuritySecureBoot_RandomCheck, 1);

  will_return (__wrap_SecuritySecureBoot_GetRandom, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_GetRandom (&logd, buf, sizeof (buf)), -1);  // failed
}

//! @brief  invalid length
static void test_SecuritySecureBoot_GetRandom_03(void)
{
  uint8_t  buf[ATECC_RANDOM_SIZE] = {0};

  will_return (__wrap_SecuritySecureBoot_GetRandom, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_GetRandom (&logd, buf, 0), -1);  // failed
}

//! @brief  invalid pointer
static void test_SecuritySecureBoot_GetRandom_04(void)
{
  uint8_t  buf[ATECC_RANDOM_SIZE];  // not initialized to prohibit "value stored to buf is never read" warnings

  will_return (__wrap_SecuritySecureBoot_GetRandom, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_GetRandom (&logd, NULL, sizeof (buf)), -1);  // failed
}

//! @brief  buffer too small
static void test_SecuritySecureBoot_GetRandom_05(void)
{
  uint8_t  buf[3] = {0};

  will_return (__wrap_SecuritySecureBoot_GetRandom, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_GetRandom (&logd, buf, sizeof (buf)), -1);  // failed
}

static void test_SecuritySecureBoot_GetRandom(void** state)
{
  test_SecuritySecureBoot_GetRandom_01();
  test_SecuritySecureBoot_GetRandom_02();
  test_SecuritySecureBoot_GetRandom_03();
  test_SecuritySecureBoot_GetRandom_04();
  test_SecuritySecureBoot_GetRandom_05();

  (void)state;
}


//! @brief  invalid pointer but correct size
static void test_SecuritySecureBoot_GenerateKey_01(void)
{
  uint8_t  buf[ATECC_RANDOM_SIZE];  // not initialized to prohibit "value stored to buf is never read" warnings

  will_return (__wrap_SecuritySecureBoot_GenerateKey, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_GenerateKey (&logd, NULL, sizeof (buf)), -1);  // failed
}

//! @brief  invalid pointer and invalid size
static void test_SecuritySecureBoot_GenerateKey_02(void)
{
  will_return (__wrap_SecuritySecureBoot_GenerateKey, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_GenerateKey (&logd, NULL, 42), -1);  // failed
}

//! @brief  invalid buffersize
static void test_SecuritySecureBoot_GenerateKey_03(void)
{
  uint8_t  buf[ATECC_RANDOM_SIZE] = {0};

  will_return (__wrap_SecuritySecureBoot_GenerateKey, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_GenerateKey (&logd, buf, 42), -1);  // failed
}

//! @brief  buffer too small
static void test_SecuritySecureBoot_GenerateKey_04(void)
{
  uint8_t  buf[4] = {0};

  will_return (__wrap_SecuritySecureBoot_GenerateKey, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_GenerateKey (&logd, buf, sizeof (buf)), -1);  // failed
}

//! @brief  bad entropy
static void test_SecuritySecureBoot_GenerateKey_05(void)
{
  uint8_t  buf[ATECC_RANDOM_SIZE] = {0};

  will_return (__wrap_SecuritySecureBoot_GetRandom, true);  // mock
  will_return (__wrap_SecuritySecureBoot_GetRandom, 0);  // no error
  expect_function_calls (__wrap_SecuritySecureBoot_GetRandom, 1);

  will_return (__wrap_SecuritySecureBoot_GetUid, true);  // mock
  will_return (__wrap_SecuritySecureBoot_GetUid, 0);  // no error
  expect_function_calls (__wrap_SecuritySecureBoot_GetUid, 1);

  will_return (__wrap_SecuritySecureBoot_RandomCheck, true);  // mock
  will_return (__wrap_SecuritySecureBoot_RandomCheck, false);  // error
  expect_function_calls (__wrap_SecuritySecureBoot_RandomCheck, 1);

  will_return (__wrap_SecuritySecureBoot_GenerateKey, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_GenerateKey (&logd, buf, sizeof (buf)), -1);  // failed
}

//! @brief  successful call
static void test_SecuritySecureBoot_GenerateKey_06(void)
{
  uint8_t  buf[ATECC_RANDOM_SIZE] = {0};

  will_return (__wrap_SecuritySecureBoot_GetRandom, true);  // mock
  will_return (__wrap_SecuritySecureBoot_GetRandom, 0);  // no error
  expect_function_calls (__wrap_SecuritySecureBoot_GetRandom, 1);

  will_return (__wrap_SecuritySecureBoot_GetUid, true);  // mock
  will_return (__wrap_SecuritySecureBoot_GetUid, 0);  // no error
  expect_function_calls (__wrap_SecuritySecureBoot_GetUid, 1);

  will_return (__wrap_SecuritySecureBoot_RandomCheck, true);  // mock
  will_return (__wrap_SecuritySecureBoot_RandomCheck, true);  // no error
  expect_function_calls (__wrap_SecuritySecureBoot_RandomCheck, 1);

  will_return (__wrap_SecuritySecureBoot_GenerateKey, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_GenerateKey (&logd, buf, sizeof (buf)), 0);  // success
  assert_memory_not_equal (buf, (uint8_t [sizeof (buf)]){0}, sizeof (buf));
  assert_memory_not_equal (buf, (uint8_t [sizeof (buf)]){"\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF"}, sizeof (buf));
  assert_memory_not_equal (buf, (uint8_t [sizeof (buf)]){"\xFF\xFF\x00\x00\xFF\xFF\x00\x00\xFF\xFF\x00\x00\xFF\xFF\x00\x00\xFF\xFF\x00\x00\xFF\xFF\x00\x00\xFF\xFF\x00\x00\xFF\xFF\x00\x00"}, sizeof (buf));
}

static void test_SecuritySecureBoot_GenerateKey(void** state)
{
  test_SecuritySecureBoot_GenerateKey_01();
  test_SecuritySecureBoot_GenerateKey_02();
  test_SecuritySecureBoot_GenerateKey_03();
  test_SecuritySecureBoot_GenerateKey_04();
  test_SecuritySecureBoot_GenerateKey_05();
  test_SecuritySecureBoot_GenerateKey_06();

  (void)state;
}


static void test_SecuritySecureBoot_WaitForEeprom(void** state)
{
  will_return (__wrap_EepromEProc_ReadData, 0);  // no error
  expect_function_calls (__wrap_EepromEProc_ReadData, 1);

  SecuritySecureBoot_WaitForEeprom();

  (void)state;
}


//! @brief  have all expected DCF-records
static void test_SecuritySecureBoot_Fill_01()
{
  const uint64_t  dcf[] =
  { // DCF_CLIENT     | DCF_DATA
    DCF_CLIENT_NVSCI  | (DCF_DATA_NVSCI << 32U),
    DCF_CLIENT_NVPWDH | (((0x1234ULL << 16U) | (0x00005678ULL << 0U)) << 32U),
    DCF_CLIENT_NVPWDL | (((0x1234ULL << 16U) | (0x00005678ULL << 0U)) << 32U),
    DCF_CLIENT_OTP_256L,
    DCF_CLIENT_OTP_HI,
    DCF_CLIENT_OTP_LO_MID,
    DCF_RECORD_STOP,
  };

  const size_t  limit = DCF_SIZE / sizeof (uint64_t);
  size_t    i;
  uint64_t  val;

  for ( i = 0; i < limit; ++i )
  {
    val = DCF_RECORD_EMPTY;
    if ( i < sizeof(dcf)/sizeof(*dcf) )
    {
      val = dcf[i];
    }
    will_return (__wrap_Nvm_GetUInt64,   0);  // no error
    will_return (__wrap_Nvm_GetUInt64, val);  // value
    expect_function_calls (__wrap_Nvm_GetUInt64, 1);

    if ( sizeof(dcf)/sizeof(*dcf) <= i )
    {
      expect_function_calls (__wrap_Nvm_Unlock, 1);
      will_return (__wrap_Nvm_WriteUInt64, 0);  // no error
      expect_function_calls (__wrap_Nvm_WriteUInt64, 1);
      expect_function_calls (__wrap_Nvm_Lock, 1);
    }
  }

  will_return (__wrap_SecuritySecureBoot_Fill, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_Fill(), 0);  // success
}

//! @brief  all DCF-records empty
static void test_SecuritySecureBoot_Fill_02()
{
  const size_t  limit = DCF_SIZE / sizeof (uint64_t);
  size_t  i;

  for ( i = 0; i < limit; ++i )
  {
    will_return (__wrap_Nvm_GetUInt64, 0);  // no error
    will_return (__wrap_Nvm_GetUInt64, DCF_RECORD_EMPTY);  // value
    expect_function_calls (__wrap_Nvm_GetUInt64, 1);

    expect_function_calls (__wrap_Nvm_Unlock, 1);
    will_return (__wrap_Nvm_WriteUInt64, 0);  // no error
    expect_function_calls (__wrap_Nvm_WriteUInt64, 1);
    expect_function_calls (__wrap_Nvm_Lock, 1);
  }

  will_return (__wrap_SecuritySecureBoot_Fill, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_Fill(), 0);  // success
}

//! @brief  read failed
static void test_SecuritySecureBoot_Fill_03()
{
  will_return (__wrap_Nvm_GetUInt64, 1);  // error
  will_return (__wrap_Nvm_GetUInt64, DCF_RECORD_EMPTY);  // value
  expect_function_calls (__wrap_Nvm_GetUInt64, 1);

  will_return (__wrap_SecuritySecureBoot_Fill, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_Fill(), -1);  // failed
}

//! @brief  write failed
static void test_SecuritySecureBoot_Fill_04()
{
  will_return (__wrap_Nvm_GetUInt64, 0);  // no error
  will_return (__wrap_Nvm_GetUInt64, DCF_RECORD_EMPTY);  // value
  expect_function_calls (__wrap_Nvm_GetUInt64, 1);

  expect_function_calls (__wrap_Nvm_Unlock, 1);
  will_return (__wrap_Nvm_WriteUInt64, 1);  // error
  expect_function_calls (__wrap_Nvm_WriteUInt64, 1);
  expect_function_calls (__wrap_Nvm_Lock, 1);

  will_return (__wrap_SecuritySecureBoot_Fill, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_Fill(), -1);  // failed
}

static void test_SecuritySecureBoot_Fill(void** state)
{
  test_SecuritySecureBoot_Fill_01();
  test_SecuritySecureBoot_Fill_02();
  test_SecuritySecureBoot_Fill_03();
  test_SecuritySecureBoot_Fill_04();

  (void)state;
}


//! @brief  no records found, successful operation
static void test_SecuritySecureBoot_Censor_01(void)
{
  size_t  i;

  // @todo commented out for CECBSAFETY-3127, enable with CECBSAFETY-3128
//  will_return (__wrap_SecuritySecureBoot_GenerateKey, true);  // mock function
//  will_return (__wrap_SecuritySecureBoot_GenerateKey, 0);  // no error
//  expect_function_calls (__wrap_SecuritySecureBoot_GenerateKey, 1);

  will_return (__wrap_Nvm_GetUInt64, 0);  // no error
  will_return (__wrap_Nvm_GetUInt64, DCF_RECORD_EMPTY);  // value
  expect_function_calls (__wrap_Nvm_GetUInt64, 1);

  will_return (__wrap_SecuritySecureBoot_DcfIsClean, true);  // mock function
  will_return (__wrap_SecuritySecureBoot_DcfIsClean, true);  // no error
  expect_function_calls (__wrap_SecuritySecureBoot_DcfIsClean, 1);

  for ( i = 0; i < 3; ++i )  // write 3 records
  {
    expect_function_calls (__wrap_Nvm_Unlock, 1);
    will_return (__wrap_Nvm_WriteUInt64, 0);  // no error
    expect_function_calls (__wrap_Nvm_WriteUInt64, 1);
    expect_function_calls (__wrap_Nvm_Lock, 1);
  }

  will_return (__wrap_SecuritySecureBoot_Censor, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_Censor (&logd), 0);  // success
}

//! @brief  just enough room for new DCF-records, successful operation
static void test_SecuritySecureBoot_Censor_02(void)
{
  const size_t  limit = DCF_SIZE / sizeof (uint64_t);
  size_t  i;

  // @todo commented out for CECBSAFETY-3127, enable with CECBSAFETY-3128
//  will_return (__wrap_SecuritySecureBoot_GenerateKey, true);  // mock function
//  will_return (__wrap_SecuritySecureBoot_GenerateKey, 0);  // no error
//  expect_function_calls (__wrap_SecuritySecureBoot_GenerateKey, 1);

  for ( i = 0; (i + 3) < limit; ++i )
  {
    will_return (__wrap_Nvm_GetUInt64, 0);  // no error
    will_return (__wrap_Nvm_GetUInt64, 0x1122334455667788ULL);  // value
    expect_function_calls (__wrap_Nvm_GetUInt64, 1);
  }
  will_return (__wrap_Nvm_GetUInt64, 0);  // no error
  will_return (__wrap_Nvm_GetUInt64, DCF_RECORD_EMPTY);  // value
  expect_function_calls (__wrap_Nvm_GetUInt64, 1);

  will_return (__wrap_SecuritySecureBoot_DcfIsClean, true);  // mock function
  will_return (__wrap_SecuritySecureBoot_DcfIsClean, true);  // no error
  expect_function_calls (__wrap_SecuritySecureBoot_DcfIsClean, 1);

  for ( i = 0; i < 3; ++i )  // write 3 records
  {
    expect_function_calls (__wrap_Nvm_Unlock, 1);
    will_return (__wrap_Nvm_WriteUInt64, 0);  // no error
    expect_function_calls (__wrap_Nvm_WriteUInt64, 1);
    expect_function_calls (__wrap_Nvm_Lock, 1);
  }

  will_return (__wrap_SecuritySecureBoot_Censor, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_Censor (&logd), 0);  // success
}

//! @brief  not enough room for DCF-records
static void test_SecuritySecureBoot_Censor_03(void)
{
  const size_t  limit = DCF_SIZE / sizeof (uint64_t);
  size_t  i;

  // @todo commented out for CECBSAFETY-3127, enable with CECBSAFETY-3128
//  will_return (__wrap_SecuritySecureBoot_GenerateKey, true);  // mock function
//  will_return (__wrap_SecuritySecureBoot_GenerateKey, 0);  // no error
//  expect_function_calls (__wrap_SecuritySecureBoot_GenerateKey, 1);

  for ( i = 0; (i + 2) < limit; ++i )  // only 2 records free
  {
    will_return (__wrap_Nvm_GetUInt64, 0);  // no error
    will_return (__wrap_Nvm_GetUInt64, 0x1122334455667788ULL);  // value
    expect_function_calls (__wrap_Nvm_GetUInt64, 1);
  }

  will_return (__wrap_SecuritySecureBoot_Censor, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_Censor (&logd), -1);  // failed
}

//! @brief  SecuritySecureBoot_GenerateKey fails
#if 0
// @todo commented out for CECBSAFETY-3127, enable with CECBSAFETY-3128
static void test_SecuritySecureBoot_Censor_04(void)
{
  will_return (__wrap_SecuritySecureBoot_GenerateKey, true);  // mock function
  will_return (__wrap_SecuritySecureBoot_GenerateKey, -1);  // error
  expect_function_calls (__wrap_SecuritySecureBoot_GenerateKey, 1);

  will_return (__wrap_SecuritySecureBoot_Censor, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_Censor (&logd), -1);  // failed
}
#endif

//! @brief  Nvm_GetUInt64 fails
static void test_SecuritySecureBoot_Censor_05(void)
{
  // @todo commented out for CECBSAFETY-3127, enable with CECBSAFETY-3128
//  will_return (__wrap_SecuritySecureBoot_GenerateKey, true);  // mock function
//  will_return (__wrap_SecuritySecureBoot_GenerateKey, 0);  // no error
//  expect_function_calls (__wrap_SecuritySecureBoot_GenerateKey, 1);

  will_return (__wrap_Nvm_GetUInt64, 1);  // error
  will_return (__wrap_Nvm_GetUInt64, 0x1122334455667788ULL);  // value
  expect_function_calls (__wrap_Nvm_GetUInt64, 1);

  will_return (__wrap_SecuritySecureBoot_Censor, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_Censor (&logd), -1);  // failed
}

//! @brief  first Nvm_WriteUInt64 fails
static void test_SecuritySecureBoot_Censor_06(void)
{
  const size_t  limit = DCF_SIZE / sizeof (uint64_t);
  size_t  i;

  // @todo commented out for CECBSAFETY-3127, enable with CECBSAFETY-3128
//  will_return (__wrap_SecuritySecureBoot_GenerateKey, true);  // mock function
//  will_return (__wrap_SecuritySecureBoot_GenerateKey, 0);  // no error
//  expect_function_calls (__wrap_SecuritySecureBoot_GenerateKey, 1);

  for ( i = 0; (i + 3) < limit; ++i )
  {
    will_return (__wrap_Nvm_GetUInt64, 0);  // no error
    will_return (__wrap_Nvm_GetUInt64, 0x1122334455667788ULL);  // value
    expect_function_calls (__wrap_Nvm_GetUInt64, 1);
  }
  will_return (__wrap_Nvm_GetUInt64, 0);  // no error
  will_return (__wrap_Nvm_GetUInt64, DCF_RECORD_EMPTY);  // value
  expect_function_calls (__wrap_Nvm_GetUInt64, 1);

  will_return (__wrap_SecuritySecureBoot_DcfIsClean, true);  // mock function
  will_return (__wrap_SecuritySecureBoot_DcfIsClean, true);  // no error
  expect_function_calls (__wrap_SecuritySecureBoot_DcfIsClean, 1);

  expect_function_calls (__wrap_Nvm_Unlock, 1);
  will_return (__wrap_Nvm_WriteUInt64, 1);  // error
  expect_function_calls (__wrap_Nvm_WriteUInt64, 1);
  expect_function_calls (__wrap_Nvm_Lock, 1);

  will_return (__wrap_SecuritySecureBoot_Censor, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_Censor (&logd), -1);  // failed
}

//! @brief  second Nvm_WriteUInt64 fails
static void test_SecuritySecureBoot_Censor_07(void)
{
  const size_t  limit = DCF_SIZE / sizeof (uint64_t);
  size_t  i;

  // @todo commented out for CECBSAFETY-3127, enable with CECBSAFETY-3128
//  will_return (__wrap_SecuritySecureBoot_GenerateKey, true);  // mock function
//  will_return (__wrap_SecuritySecureBoot_GenerateKey, 0);  // no error
//  expect_function_calls (__wrap_SecuritySecureBoot_GenerateKey, 1);

  for ( i = 0; (i + 3) < limit; ++i )
  {
    will_return (__wrap_Nvm_GetUInt64, 0);  // no error
    will_return (__wrap_Nvm_GetUInt64, 0x1122334455667788ULL);  // value
    expect_function_calls (__wrap_Nvm_GetUInt64, 1);
  }
  will_return (__wrap_Nvm_GetUInt64, 0);  // no error
  will_return (__wrap_Nvm_GetUInt64, DCF_RECORD_EMPTY);  // value
  expect_function_calls (__wrap_Nvm_GetUInt64, 1);

  will_return (__wrap_SecuritySecureBoot_DcfIsClean, true);  // mock function
  will_return (__wrap_SecuritySecureBoot_DcfIsClean, true);  // no error
  expect_function_calls (__wrap_SecuritySecureBoot_DcfIsClean, 1);

  expect_function_calls (__wrap_Nvm_Unlock, 1);
  will_return (__wrap_Nvm_WriteUInt64, 0);  // no error
  expect_function_calls (__wrap_Nvm_WriteUInt64, 1);
  expect_function_calls (__wrap_Nvm_Lock, 1);

  expect_function_calls (__wrap_Nvm_Unlock, 1);
  will_return (__wrap_Nvm_WriteUInt64, 1);  // error
  expect_function_calls (__wrap_Nvm_WriteUInt64, 1);
  expect_function_calls (__wrap_Nvm_Lock, 1);

  will_return (__wrap_SecuritySecureBoot_Censor, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_Censor (&logd), -1);  // failed
}

//! @brief  third Nvm_WriteUInt64 fails
static void test_SecuritySecureBoot_Censor_08(void)
{
  const size_t  limit = DCF_SIZE / sizeof (uint64_t);
  size_t  i;

  // @todo commented out for CECBSAFETY-3127, enable with CECBSAFETY-3128
//  will_return (__wrap_SecuritySecureBoot_GenerateKey, true);  // mock function
//  will_return (__wrap_SecuritySecureBoot_GenerateKey, 0);  // no error
//  expect_function_calls (__wrap_SecuritySecureBoot_GenerateKey, 1);

  for ( i = 0; (i + 3) < limit; ++i )
  {
    will_return (__wrap_Nvm_GetUInt64, 0);  // no error
    will_return (__wrap_Nvm_GetUInt64, 0x1122334455667788ULL);  // value
    expect_function_calls (__wrap_Nvm_GetUInt64, 1);
  }
  will_return (__wrap_Nvm_GetUInt64, 0);  // no error
  will_return (__wrap_Nvm_GetUInt64, DCF_RECORD_EMPTY);  // value
  expect_function_calls (__wrap_Nvm_GetUInt64, 1);

  will_return (__wrap_SecuritySecureBoot_DcfIsClean, true);  // mock function
  will_return (__wrap_SecuritySecureBoot_DcfIsClean, true);  // no error
  expect_function_calls (__wrap_SecuritySecureBoot_DcfIsClean, 1);

  expect_function_calls (__wrap_Nvm_Unlock, 1);
  will_return (__wrap_Nvm_WriteUInt64, 0);  // no error
  expect_function_calls (__wrap_Nvm_WriteUInt64, 1);
  expect_function_calls (__wrap_Nvm_Lock, 1);

  expect_function_calls (__wrap_Nvm_Unlock, 1);
  will_return (__wrap_Nvm_WriteUInt64, 0);  // no error
  expect_function_calls (__wrap_Nvm_WriteUInt64, 1);
  expect_function_calls (__wrap_Nvm_Lock, 1);

  expect_function_calls (__wrap_Nvm_Unlock, 1);
  will_return (__wrap_Nvm_WriteUInt64, 1);  // error
  expect_function_calls (__wrap_Nvm_WriteUInt64, 1);
  expect_function_calls (__wrap_Nvm_Lock, 1);

  will_return (__wrap_SecuritySecureBoot_Censor, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_Censor (&logd), -1);  // failed
}

//! @brief  STOP-record encountered
static void test_SecuritySecureBoot_Censor_09(void)
{
  const size_t  limit = 12;  // any random size
  size_t  i;

  will_return (__wrap_SecuritySecureBoot_GenerateKey, true);  // mock function
  will_return (__wrap_SecuritySecureBoot_GenerateKey, 0);  // no error
  expect_function_calls (__wrap_SecuritySecureBoot_GenerateKey, 1);

  for ( i = 0; i < limit; ++i )
  {
    will_return (__wrap_Nvm_GetUInt64, 0);  // no error
    will_return (__wrap_Nvm_GetUInt64, 0x1122334455667788ULL);  // value
    expect_function_calls (__wrap_Nvm_GetUInt64, 1);
  }
  will_return (__wrap_Nvm_GetUInt64, 0);  // no error
  will_return (__wrap_Nvm_GetUInt64, DCF_RECORD_STOP);  // value
  expect_function_calls (__wrap_Nvm_GetUInt64, 1);

  will_return (__wrap_SecuritySecureBoot_Censor, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_Censor (&logd), -1);  // failed
}

//! @brief  programmed hole encountered (DCF not clean)
static void test_SecuritySecureBoot_Censor_10(void)
{
  // @todo commented out for CECBSAFETY-3127, enable with CECBSAFETY-3128
//  will_return (__wrap_SecuritySecureBoot_GenerateKey, true);  // mock function
//  will_return (__wrap_SecuritySecureBoot_GenerateKey, 0);  // no error
//  expect_function_calls (__wrap_SecuritySecureBoot_GenerateKey, 1);

  will_return (__wrap_Nvm_GetUInt64, 0);  // no error
  will_return (__wrap_Nvm_GetUInt64, DCF_RECORD_EMPTY);  // value
  expect_function_calls (__wrap_Nvm_GetUInt64, 1);

  will_return (__wrap_SecuritySecureBoot_DcfIsClean, true);  // mock function
  will_return (__wrap_SecuritySecureBoot_DcfIsClean, false);  // error
  expect_function_calls (__wrap_SecuritySecureBoot_DcfIsClean, 1);

  will_return (__wrap_SecuritySecureBoot_Censor, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_Censor (&logd), -1);  // failed
}

static void test_SecuritySecureBoot_Censor(void** state)
{
  test_SecuritySecureBoot_Censor_01();
  test_SecuritySecureBoot_Censor_02();
  test_SecuritySecureBoot_Censor_03();
//  test_SecuritySecureBoot_Censor_04();  // @todo commented out for CECBSAFETY-3127, enable with CECBSAFETY-3128
  test_SecuritySecureBoot_Censor_05();
  test_SecuritySecureBoot_Censor_06();
  test_SecuritySecureBoot_Censor_07();
  test_SecuritySecureBoot_Censor_08();
//  test_SecuritySecureBoot_Censor_09();  // @todo commented out for CECBSAFETY-3127, enable with CECBSAFETY-3128
  test_SecuritySecureBoot_Censor_10();

  (void)state;
}


//! @brief  first record is empty
static void test_SecuritySecureBoot_LockOtp_01(void)
{
  will_return (__wrap_Nvm_GetUInt64, 0);  // no error
  will_return (__wrap_Nvm_GetUInt64, DCF_RECORD_EMPTY);  // value
  expect_function_calls (__wrap_Nvm_GetUInt64, 1);

  will_return (__wrap_SecuritySecureBoot_DcfIsClean, true);  // mock function
  will_return (__wrap_SecuritySecureBoot_DcfIsClean, true);  // no error
  expect_function_calls (__wrap_SecuritySecureBoot_DcfIsClean, 1);

  expect_function_calls (__wrap_Nvm_Unlock, 1);
  will_return (__wrap_Nvm_WriteUInt64, 0);  // no error
  expect_function_calls (__wrap_Nvm_WriteUInt64, 1);
  expect_function_calls (__wrap_Nvm_Lock, 1);

  expect_function_calls (__wrap_Nvm_Unlock, 1);
  will_return (__wrap_Nvm_WriteUInt64, 0);  // no error
  expect_function_calls (__wrap_Nvm_WriteUInt64, 1);
  expect_function_calls (__wrap_Nvm_Lock, 1);

  expect_function_calls (__wrap_Nvm_Unlock, 1);
  will_return (__wrap_Nvm_WriteUInt64, 0);  // no error
  expect_function_calls (__wrap_Nvm_WriteUInt64, 1);
  expect_function_calls (__wrap_Nvm_Lock, 1);

  will_return (__wrap_SecuritySecureBoot_LockOtp, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_LockOtp(), 0);  // success
}

//! @brief  first record is non-empty
static void test_SecuritySecureBoot_LockOtp_02(void)
{
  will_return (__wrap_Nvm_GetUInt64, 0);  // no error
  will_return (__wrap_Nvm_GetUInt64, 0x1122334455667788ULL);  // value
  expect_function_calls (__wrap_Nvm_GetUInt64, 1);

  will_return (__wrap_Nvm_GetUInt64, 0);  // no error
  will_return (__wrap_Nvm_GetUInt64, DCF_RECORD_EMPTY);  // value
  expect_function_calls (__wrap_Nvm_GetUInt64, 1);

  will_return (__wrap_SecuritySecureBoot_DcfIsClean, true);  // mock function
  will_return (__wrap_SecuritySecureBoot_DcfIsClean, true);  // no error
  expect_function_calls (__wrap_SecuritySecureBoot_DcfIsClean, 1);

  expect_function_calls (__wrap_Nvm_Unlock, 1);
  will_return (__wrap_Nvm_WriteUInt64, 0);  // no error
  expect_function_calls (__wrap_Nvm_WriteUInt64, 1);
  expect_function_calls (__wrap_Nvm_Lock, 1);

  expect_function_calls (__wrap_Nvm_Unlock, 1);
  will_return (__wrap_Nvm_WriteUInt64, 0);  // no error
  expect_function_calls (__wrap_Nvm_WriteUInt64, 1);
  expect_function_calls (__wrap_Nvm_Lock, 1);

  expect_function_calls (__wrap_Nvm_Unlock, 1);
  will_return (__wrap_Nvm_WriteUInt64, 0);  // no error
  expect_function_calls (__wrap_Nvm_WriteUInt64, 1);
  expect_function_calls (__wrap_Nvm_Lock, 1);

  will_return (__wrap_SecuritySecureBoot_LockOtp, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_LockOtp(), 0);  // success
}

//! @brief  just enough room for new DCF-records, successful operation
static void test_SecuritySecureBoot_LockOtp_03(void)
{
  const size_t  limit = DCF_SIZE / sizeof (uint64_t);
  size_t  i;

  for ( i = 0; (i + 3) < limit; ++i )
  {
    will_return (__wrap_Nvm_GetUInt64, 0);  // no error
    will_return (__wrap_Nvm_GetUInt64, 0x1122334455667788ULL);  // value
    expect_function_calls (__wrap_Nvm_GetUInt64, 1);
  }
  will_return (__wrap_Nvm_GetUInt64, 0);  // no error
  will_return (__wrap_Nvm_GetUInt64, DCF_RECORD_EMPTY);  // value
  expect_function_calls (__wrap_Nvm_GetUInt64, 1);

  will_return (__wrap_SecuritySecureBoot_DcfIsClean, true);  // mock function
  will_return (__wrap_SecuritySecureBoot_DcfIsClean, true);  // no error
  expect_function_calls (__wrap_SecuritySecureBoot_DcfIsClean, 1);

  expect_function_calls (__wrap_Nvm_Unlock, 1);
  will_return (__wrap_Nvm_WriteUInt64, 0);  // no error
  expect_function_calls (__wrap_Nvm_WriteUInt64, 1);
  expect_function_calls (__wrap_Nvm_Lock, 1);

  expect_function_calls (__wrap_Nvm_Unlock, 1);
  will_return (__wrap_Nvm_WriteUInt64, 0);  // no error
  expect_function_calls (__wrap_Nvm_WriteUInt64, 1);
  expect_function_calls (__wrap_Nvm_Lock, 1);

  expect_function_calls (__wrap_Nvm_Unlock, 1);
  will_return (__wrap_Nvm_WriteUInt64, 0);  // no error
  expect_function_calls (__wrap_Nvm_WriteUInt64, 1);
  expect_function_calls (__wrap_Nvm_Lock, 1);

  will_return (__wrap_SecuritySecureBoot_LockOtp, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_LockOtp(), 0);  // success
}

//! @brief  encountered STOP-block
static void test_SecuritySecureBoot_LockOtp_04(void)
{
  will_return (__wrap_Nvm_GetUInt64, 0);  // no error
  will_return (__wrap_Nvm_GetUInt64, 0x1122334455667788ULL);  // value
  expect_function_calls (__wrap_Nvm_GetUInt64, 1);

  will_return (__wrap_Nvm_GetUInt64, 0);  // no error
  will_return (__wrap_Nvm_GetUInt64, DCF_RECORD_STOP);  // value
  expect_function_calls (__wrap_Nvm_GetUInt64, 1);

  will_return (__wrap_SecuritySecureBoot_LockOtp, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_LockOtp(), -1);  // failed
}

//! @brief  read failed
static void test_SecuritySecureBoot_LockOtp_05(void)
{
  will_return (__wrap_Nvm_GetUInt64, 1);  // error
  will_return (__wrap_Nvm_GetUInt64, DCF_RECORD_EMPTY);  // value
  expect_function_calls (__wrap_Nvm_GetUInt64, 1);

  will_return (__wrap_SecuritySecureBoot_LockOtp, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_LockOtp(), -1);  // failed
}

//! @brief  write failed
static void test_SecuritySecureBoot_LockOtp_06(void)
{
  will_return (__wrap_Nvm_GetUInt64, 0);  // no error
  will_return (__wrap_Nvm_GetUInt64, 0x1122334455667788ULL);  // value
  expect_function_calls (__wrap_Nvm_GetUInt64, 1);

  will_return (__wrap_Nvm_GetUInt64, 0);  // no error
  will_return (__wrap_Nvm_GetUInt64, DCF_RECORD_EMPTY);  // value
  expect_function_calls (__wrap_Nvm_GetUInt64, 1);

  will_return (__wrap_SecuritySecureBoot_DcfIsClean, true);  // mock function
  will_return (__wrap_SecuritySecureBoot_DcfIsClean, true);  // no error
  expect_function_calls (__wrap_SecuritySecureBoot_DcfIsClean, 1);

  expect_function_calls (__wrap_Nvm_Unlock, 1);
  will_return (__wrap_Nvm_WriteUInt64, 1);  // error
  expect_function_calls (__wrap_Nvm_WriteUInt64, 1);
  expect_function_calls (__wrap_Nvm_Lock, 1);

  will_return (__wrap_SecuritySecureBoot_LockOtp, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_LockOtp(), -1);  // failed
}

//! @brief  DCF-space full
static void test_SecuritySecureBoot_LockOtp_07(void)
{
  const size_t  limit = DCF_SIZE / sizeof (uint64_t);
  size_t  i;

  for ( i = 0; (i + 3) <= limit; ++i )  // stops when less than 3 records are left
  {
    will_return (__wrap_Nvm_GetUInt64, 0);  // no error
    will_return (__wrap_Nvm_GetUInt64, 0x1122334455667788ULL);  // value
    expect_function_calls (__wrap_Nvm_GetUInt64, 1);
  }

  will_return (__wrap_SecuritySecureBoot_LockOtp, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_LockOtp(), -1);  // failed
}

//! @brief  DCF-space not clean
static void test_SecuritySecureBoot_LockOtp_08(void)
{
  will_return (__wrap_Nvm_GetUInt64, 0);  // no error
  will_return (__wrap_Nvm_GetUInt64, 0x1122334455667788ULL);  // value
  expect_function_calls (__wrap_Nvm_GetUInt64, 1);

  will_return (__wrap_Nvm_GetUInt64, 0);  // no error
  will_return (__wrap_Nvm_GetUInt64, DCF_RECORD_EMPTY);  // value
  expect_function_calls (__wrap_Nvm_GetUInt64, 1);

  will_return (__wrap_SecuritySecureBoot_DcfIsClean, true);  // mock function
  will_return (__wrap_SecuritySecureBoot_DcfIsClean, false);  // error
  expect_function_calls (__wrap_SecuritySecureBoot_DcfIsClean, 1);

  will_return (__wrap_SecuritySecureBoot_LockOtp, false);  // do not mock

  assert_int_equal (SecuritySecureBoot_LockOtp(), -1);  // failed
}

static void test_SecuritySecureBoot_LockOtp(void** state)
{
  test_SecuritySecureBoot_LockOtp_01();
  test_SecuritySecureBoot_LockOtp_02();
  test_SecuritySecureBoot_LockOtp_03();
  test_SecuritySecureBoot_LockOtp_04();
  test_SecuritySecureBoot_LockOtp_05();
  test_SecuritySecureBoot_LockOtp_06();
  test_SecuritySecureBoot_LockOtp_07();
  test_SecuritySecureBoot_LockOtp_08();
}


//! @brief  device is secure
static void test_SecuritySecureBoot_SecureDevice_01(void)
{
  will_return (__wrap_EepromEProc_ReadData, 0);
  expect_function_calls (__wrap_EepromEProc_ReadData, 1);

  will_return (__wrap_SecuritySecureBoot_IsSecure, true);  // mock function
  will_return (__wrap_SecuritySecureBoot_IsSecure, 1);  // is secure
  expect_function_calls (__wrap_SecuritySecureBoot_IsSecure, 1);

  assert_int_equal (SecuritySecureBoot_SecureDevice (&logd), 0);  // success
}

//! @brief  SecuritySecureBoot_IsSecure fails
static void test_SecuritySecureBoot_SecureDevice_02(void)
{
  will_return (__wrap_EepromEProc_ReadData, 0);
  expect_function_calls (__wrap_EepromEProc_ReadData, 1);

  will_return (__wrap_SecuritySecureBoot_IsSecure, true);  // mock function
  will_return (__wrap_SecuritySecureBoot_IsSecure, -1);  // error
  expect_function_calls (__wrap_SecuritySecureBoot_IsSecure, 1);

  assert_int_equal (SecuritySecureBoot_SecureDevice (&logd), -1);  // failed
}

//! @brief  device is not secure and SecuritySecureBoot_Censor fails
static void test_SecuritySecureBoot_SecureDevice_03(void)
{
  will_return (__wrap_EepromEProc_ReadData, 0);
  expect_function_calls (__wrap_EepromEProc_ReadData, 1);

  will_return (__wrap_SecuritySecureBoot_IsSecure, true);  // mock function
  will_return (__wrap_SecuritySecureBoot_IsSecure, 0);  // not secure
  expect_function_calls (__wrap_SecuritySecureBoot_IsSecure, 1);

  will_return (__wrap_SecuritySecureBoot_Censor, true);  // mock function
  will_return (__wrap_SecuritySecureBoot_Censor, -1);  // error
  expect_function_calls (__wrap_SecuritySecureBoot_Censor, 1);

  assert_int_equal (SecuritySecureBoot_SecureDevice (&logd), -1);  // failed
}

//! @brief  device is not secure and SecuritySecureBoot_Lock fails
static void test_SecuritySecureBoot_SecureDevice_04(void)
{
  will_return (__wrap_EepromEProc_ReadData, 0);
  expect_function_calls (__wrap_EepromEProc_ReadData, 1);

  will_return (__wrap_SecuritySecureBoot_IsSecure, true);  // mock function
  will_return (__wrap_SecuritySecureBoot_IsSecure, 0);  // not secure
  expect_function_calls (__wrap_SecuritySecureBoot_IsSecure, 1);

  will_return (__wrap_SecuritySecureBoot_Censor, true);  // mock function
  will_return (__wrap_SecuritySecureBoot_Censor, 0);  // no error
  expect_function_calls (__wrap_SecuritySecureBoot_Censor, 1);

  will_return (__wrap_SecuritySecureBoot_LockOtp, true);  // mock function
  will_return (__wrap_SecuritySecureBoot_LockOtp, -1);  // error
  expect_function_calls (__wrap_SecuritySecureBoot_LockOtp, 1);

  assert_int_equal (SecuritySecureBoot_SecureDevice (&logd), -1);  // failed
}

//! @brief  device is not secure and SecuritySecureBoot_Fill fails
static void test_SecuritySecureBoot_SecureDevice_05(void)
{
  will_return (__wrap_EepromEProc_ReadData, 0);
  expect_function_calls (__wrap_EepromEProc_ReadData, 1);

  will_return (__wrap_SecuritySecureBoot_IsSecure, true);  // mock function
  will_return (__wrap_SecuritySecureBoot_IsSecure, 0);  // not secure
  expect_function_calls (__wrap_SecuritySecureBoot_IsSecure, 1);

  will_return (__wrap_SecuritySecureBoot_Censor, true);  // mock function
  will_return (__wrap_SecuritySecureBoot_Censor, 0);  // no error
  expect_function_calls (__wrap_SecuritySecureBoot_Censor, 1);

  will_return (__wrap_SecuritySecureBoot_LockOtp, true);  // mock function
  will_return (__wrap_SecuritySecureBoot_LockOtp, 0);  // no error
  expect_function_calls (__wrap_SecuritySecureBoot_LockOtp, 1);

  will_return (__wrap_SecuritySecureBoot_Fill, true);  // mock function
  will_return (__wrap_SecuritySecureBoot_Fill, -1);  // error
  expect_function_calls (__wrap_SecuritySecureBoot_Fill, 1);

  assert_int_equal (SecuritySecureBoot_SecureDevice (&logd), -1);  // failed
}

static void test_SecuritySecureBoot_SecureDevice(void** state)
{
  test_SecuritySecureBoot_SecureDevice_01();
  test_SecuritySecureBoot_SecureDevice_02();
  test_SecuritySecureBoot_SecureDevice_03();
  test_SecuritySecureBoot_SecureDevice_04();
  test_SecuritySecureBoot_SecureDevice_05();

  (void)state;
}


//! @brief  test_SecuritySecureBoot_DcfIsClean successful (everything unprogrammed, search from index 0)
static void test_SecuritySecureBoot_DcfIsClean_01(void)
{
  const size_t  limit = DCF_SIZE / sizeof (uint64_t);
  const size_t  pos = 0;  // start-pos for search
  size_t  i;

  for ( i = pos; i < limit; ++i )
  {
    will_return (__wrap_Nvm_GetUInt64, 0);  // no error
    will_return (__wrap_Nvm_GetUInt64, DCF_RECORD_EMPTY);  // value
    expect_function_calls (__wrap_Nvm_GetUInt64, 1);
  }

  will_return (__wrap_SecuritySecureBoot_DcfIsClean, false);  // do not mock function

  assert_true (SecuritySecureBoot_DcfIsClean (pos));  // clean
}

//! @brief  test_SecuritySecureBoot_DcfIsClean successful (everything unprogrammed, search from index 42)
static void test_SecuritySecureBoot_DcfIsClean_02(void)
{
  const size_t  limit = DCF_SIZE / sizeof (uint64_t);
  const size_t  pos = 42;  // start-pos for search
  size_t  i;

  for ( i = pos; i < limit; ++i )
  {
    will_return (__wrap_Nvm_GetUInt64, 0);  // no error
    will_return (__wrap_Nvm_GetUInt64, DCF_RECORD_EMPTY);  // value
    expect_function_calls (__wrap_Nvm_GetUInt64, 1);
  }

  will_return (__wrap_SecuritySecureBoot_DcfIsClean, false);  // do not mock function

  assert_true (SecuritySecureBoot_DcfIsClean (pos));  // clean
}

//! @brief  test_SecuritySecureBoot_DcfIsClean fails (programmed entry at the very end)
static void test_SecuritySecureBoot_DcfIsClean_03(void)
{
  const size_t  limit = DCF_SIZE / sizeof (uint64_t);
  const size_t  pos = 0;  // start-pos for search
  size_t  i;

  for ( i = pos; (i + 1) < limit; ++i )  // stop at last value
  {
    will_return (__wrap_Nvm_GetUInt64, 0);  // no error
    will_return (__wrap_Nvm_GetUInt64, DCF_RECORD_EMPTY);  // value
    expect_function_calls (__wrap_Nvm_GetUInt64, 1);
  }
  will_return (__wrap_Nvm_GetUInt64, 0);  // no error
  will_return (__wrap_Nvm_GetUInt64, 0x1122334455667788ULL);  // value
  expect_function_calls (__wrap_Nvm_GetUInt64, 1);

  will_return (__wrap_SecuritySecureBoot_DcfIsClean, false);  // do not mock function

  assert_false (SecuritySecureBoot_DcfIsClean (pos));  // not clean
}

//! @brief  test_SecuritySecureBoot_DcfIsClean fails (programmed entry before the end)
static void test_SecuritySecureBoot_DcfIsClean_04(void)
{
  const size_t  limit = DCF_SIZE / sizeof (uint64_t);
  const size_t  pos = 0;  // start-pos for search
  size_t  i;

  for ( i = pos; (i + 17) < limit; ++i )  // stop at pos 17
  {
    will_return (__wrap_Nvm_GetUInt64, 0);  // no error
    will_return (__wrap_Nvm_GetUInt64, DCF_RECORD_EMPTY);  // value
    expect_function_calls (__wrap_Nvm_GetUInt64, 1);
  }
  will_return (__wrap_Nvm_GetUInt64, 0);  // no error
  will_return (__wrap_Nvm_GetUInt64, 0x1122334455667788ULL);  // value
  expect_function_calls (__wrap_Nvm_GetUInt64, 1);

  will_return (__wrap_SecuritySecureBoot_DcfIsClean, false);  // do not mock function

  assert_false (SecuritySecureBoot_DcfIsClean (pos));  // not clean
}

//! @brief  test_SecuritySecureBoot_DcfIsClean fails (start-pos too big)
static void test_SecuritySecureBoot_DcfIsClean_05(void)
{
  const size_t  pos = 9876;  // bigger than the size of the DCF-area (256 entries)

  will_return (__wrap_SecuritySecureBoot_DcfIsClean, false);  // do not mock function

  assert_false (SecuritySecureBoot_DcfIsClean (pos));  // not clean
}

//! @brief  test_SecuritySecureBoot_DcfIsClean fails (Nvm_GetUInt64 returns error)
static void test_SecuritySecureBoot_DcfIsClean_06(void)
{
  const size_t  limit = DCF_SIZE / sizeof (uint64_t);
  const size_t  pos = 0;  // start-pos for search
  size_t  i;

  for ( i = pos; (i + 23) < limit; ++i )
  {
    will_return (__wrap_Nvm_GetUInt64, 0);  // no error
    will_return (__wrap_Nvm_GetUInt64, DCF_RECORD_EMPTY);  // value
    expect_function_calls (__wrap_Nvm_GetUInt64, 1);
  }
  will_return (__wrap_Nvm_GetUInt64, 1);  // error
  will_return (__wrap_Nvm_GetUInt64, DCF_RECORD_EMPTY);  // value
  expect_function_calls (__wrap_Nvm_GetUInt64, 1);

  will_return (__wrap_SecuritySecureBoot_DcfIsClean, false);  // do not mock function

  assert_false (SecuritySecureBoot_DcfIsClean (pos));  // not clean
}

static void test_SecuritySecureBoot_DcfIsClean(void** state)
{
  test_SecuritySecureBoot_DcfIsClean_01();
  test_SecuritySecureBoot_DcfIsClean_02();
  test_SecuritySecureBoot_DcfIsClean_03();
  test_SecuritySecureBoot_DcfIsClean_04();
  test_SecuritySecureBoot_DcfIsClean_05();
  test_SecuritySecureBoot_DcfIsClean_06();

  (void)state;
}


int main(void)
{
  int  retval = 0;
    
#ifdef CMOCKA_DIAB
  putenv("CMOCKA_XML_FILE=src_common_Security_SecureBoot.xml"); // environment variable for XML file when running on PPC
#endif
    
  const struct CMUnitTest  tests[] =
  {
    cmocka_unit_test (test_SecuritySecureBoot_GetUid),
    cmocka_unit_test (test_SecuritySecureBoot_IsSecure),
    cmocka_unit_test (test_SecuritySecureBoot_RandomCheck),
    cmocka_unit_test (test_SecuritySecureBoot_GetRandom),
    cmocka_unit_test (test_SecuritySecureBoot_GenerateKey),
    cmocka_unit_test (test_SecuritySecureBoot_WaitForEeprom),
    cmocka_unit_test (test_SecuritySecureBoot_Fill),
    cmocka_unit_test (test_SecuritySecureBoot_Censor),
    cmocka_unit_test (test_SecuritySecureBoot_LockOtp),
    cmocka_unit_test (test_SecuritySecureBoot_SecureDevice),
    cmocka_unit_test (test_SecuritySecureBoot_DcfIsClean),
  };

  cmocka_set_message_output (CM_OUTPUT_XML);

  retval = cmocka_run_group_tests_name ("src_common_Security_SecureBoot", tests, NULL, NULL);
  
#ifdef CMOCKA_DIAB
  read_xml_file("src_common_Security_SecureBoot.xml"); // extract XML test results from file in RAM when running on PPC
#endif

  return retval;
}


//!@name Stubbed Functions
//!{
extern void __wrap_logd_printf(const char *fmt)
{
  (void) printf(fmt);
}

extern logd_t * __wrap_logd_new(const char *logdProcessName,
                         int levelMax, /* obsolete ! */
                         const char *appl,
                         sc_poolid_t plid,
                         sc_ticks_t tmo)
{
  return &logd;
}

extern uint32_t __wrap___sc_tickMs2Tick(uint32_t ticks)
{
  return ticks;
}

extern uint32_t __wrap_EepromEProc_ReadData(uint8_t id,  uint8_t * pBuffer, size_t bufferSize, uint32_t * pError)
{
  function_called();
  return (uint32_t) mock();
}

extern uint64_t __wrap_Nvm_GetUInt64(Nvm_Block_E db, uint32_t dwordNr, uint16_t * pError)
{
  function_called();

  const uint16_t  err = (uint16_t) mock();
  const uint64_t  val = (uint64_t) mock();

  if ( (NULL != pError)  &&  (0 != err) )
  {
    *pError = err;
  }

  return val;
}

extern void __wrap_Nvm_WriteUInt64(uint64_t dword, Nvm_Block_E db, uint32_t dwordNr, uint16_t * pError)
{
  function_called();

  const uint16_t  err = (uint16_t) mock();

  if ( (NULL != pError)  &&  (0 != err) )
  {
    *pError = err;
  }

  return;
}

extern void __wrap_Nvm_Lock(Nvm_Block_E db)
{
  function_called();
  return;
}

extern void __wrap_Nvm_Unlock(Nvm_Block_E db)
{
  function_called();
  return;
}

extern void __wrap_SecuritySecureBoot_WaitForEeprom(void)
{
  function_called();
}

extern int __wrap_ATECC508_performGenerateRandomNumber(logd_t* const logd, uint8_t* const pBuf, const size_t bufLength)
{
  int  rc = (int) mock();

  function_called();

  if ( NULL != pBuf )
  {
    if ( 0 == rc )
    {
      // success: fake some "random" data
      for ( size_t  i = 0; i < bufLength; ++i )
      {
        pBuf[i] = i & 0xFFU;
      }
    }
    else if ( 42 == rc )
    {
      // simulate an unlocked crypto-chip and return success
      for ( size_t  i = 0; (i + 4) <= bufLength; i += 4 )
      {
        memcpy (&pBuf[i], "\xFF\xFF\x00\x00", 4);
      }
      rc = 0;
    }
    else
    {
      // fail: return an empty buffer
      memset (pBuf, 0, bufLength);
    }
  }

  return rc;
}

extern int __wrap_SecuritySecureBoot_IsSecure(void)
{
  int  rc;

  if ( mock() )
  {
    rc = (int) mock();
    function_called();
  }
  else
  {
    rc = __real_SecuritySecureBoot_IsSecure();
  }

  return rc;
}

extern int __wrap_SecuritySecureBoot_Censor(logd_t* const logd)
{
  int  rc;

  if ( mock() )
  {
    rc = (int) mock();
    function_called();
  }
  else
  {
    rc = __real_SecuritySecureBoot_Censor (logd);
  }

  return rc;
}

extern int __wrap_SecuritySecureBoot_LockOtp(void)
{
  int  rc;

  if ( mock() )
  {
    rc = (int) mock();
    function_called();
  }
  else
  {
    rc = __real_SecuritySecureBoot_LockOtp();
  }

  return rc;
}

extern int __wrap_SecuritySecureBoot_Fill(void)
{
  int  rc;

  if ( mock() )
  {
    rc = (int) mock();
    function_called();
  }
  else
  {
    rc = __real_SecuritySecureBoot_Fill();
  }

  return rc;
}

extern bool __wrap_SecuritySecureBoot_DcfIsClean(const size_t pos)
{
  bool  rc;

  if ( mock() )
  {
    rc = (bool) mock();
    function_called();
  }
  else
  {
    rc = __real_SecuritySecureBoot_DcfIsClean (pos);
  }

  return rc;
}

extern int __wrap_SecuritySecureBoot_GenerateKey(logd_t* const logd, uint8_t* const pBuf, const size_t len)
{
  int  rc;

  if ( mock() )
  {
    rc = (int) mock();
    function_called();

    if ( NULL != pBuf )
    {
      if ( 0 == rc )
      {
        // success: fake some "random" data
        for ( size_t  i = 0; i < len; ++i )
        {
          pBuf[i] = i & 0xFFU;
        }
      }
      else if ( 42 == rc )
      {
        // simulate an unlocked crypto-chip and return success
        for ( size_t  i = 0; (i + 4) <= len; i += 4 )
        {
          memcpy (&pBuf[i], "\xFF\xFF\x00\x00", 4);
        }
        rc = 0;
      }
      else
      {
        // fail: return an empty buffer
        memset (pBuf, 0, len);
      }
    }
  }
  else
  {
    rc = __real_SecuritySecureBoot_GenerateKey (logd, pBuf, len);
  }

  return rc;
}

extern int __wrap_SecuritySecureBoot_GetRandom(logd_t* const logd, uint8_t* const pBuf, const size_t bufLength)
{
  int  rc;

  if ( mock() )
  {
    rc = (int) mock();
    function_called();
  }
  else
  {
    rc = __real_SecuritySecureBoot_GetRandom (logd, pBuf, bufLength);
  }

  return rc;
}

extern bool __wrap_SecuritySecureBoot_RandomCheck(const uint8_t* const pBuf, const size_t len)
{
  int  rc;

  if ( mock() )
  {
    rc = (int) mock();
    function_called();
  }
  else
  {
    rc = __real_SecuritySecureBoot_RandomCheck (pBuf, len);
  }

  return rc;
}

extern int __wrap_SecuritySecureBoot_GetUid(uint8_t* const pBuf, const size_t len)
{
  int  rc;

  if ( mock() )
  {
    rc = (int) mock();
    function_called();

    if ( 0 == rc )
    {
      // return some data in case of success
      for ( size_t  i = 0; i < len; ++i )
      {
        pBuf[i] = (uint8_t) i;
      }
    }
  }
  else
  {
    rc = __real_SecuritySecureBoot_GetUid (pBuf, len);
  }

  return rc;
}

//! @}


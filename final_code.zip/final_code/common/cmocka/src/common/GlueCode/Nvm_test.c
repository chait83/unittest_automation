#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <stdint.h>
#include <stdbool.h>
#include "GlueCode/SharedNvm.h"
#include "GlueCode/Nvm.h"

#include "cmocka.h"

enum GlueCodeNvmAction nvmAction;

#define CMOCKA_GLUECODE_NVM_MAX_SIZE 8

extern void test_GlueCodeNvmMap_Item(
    enum nvm_message_id msgId,
    uint8_t * nvmBuffer,
    GlueCodeProcessNvm_Common_S * nvmCommon,
    bool toBuffer)
{

  if (nvmAction == GlueCodeNvmAction_ReadItem)
  {
    assert_false(toBuffer);
  }
  if (nvmAction == GlueCodeNvmAction_WriteItem)
  {
    assert_true(toBuffer);
  }

  if (toBuffer)
  {
    nvmBuffer[msgId] = nvmCommon->flashMisr->UM[msgId];
  }

  if (!toBuffer)
  {
    nvmCommon->flashMisr->UM[msgId] = nvmBuffer[msgId];
  }

}

GlueCodeNvm_OfInterest_S common_nvmOfInterests[] = {
    // Certificate
    {.msgId = 0, .size = CMOCKA_GLUECODE_NVM_MAX_SIZE, .mapfunction = test_GlueCodeNvmMap_Item },
    {.msgId = 1, .size = CMOCKA_GLUECODE_NVM_MAX_SIZE, .mapfunction = test_GlueCodeNvmMap_Item },
    {.msgId = 2, .size = CMOCKA_GLUECODE_NVM_MAX_SIZE, .mapfunction = test_GlueCodeNvmMap_Item },
    {.msgId = 3, .size = CMOCKA_GLUECODE_NVM_MAX_SIZE, .mapfunction = test_GlueCodeNvmMap_Item },
    {.msgId = 4, .size = CMOCKA_GLUECODE_NVM_MAX_SIZE, .mapfunction = test_GlueCodeNvmMap_Item },
    {.msgId = 5, .size = CMOCKA_GLUECODE_NVM_MAX_SIZE, .mapfunction = test_GlueCodeNvmMap_Item },
    {.msgId = 6, .size = CMOCKA_GLUECODE_NVM_MAX_SIZE, .mapfunction = test_GlueCodeNvmMap_Item },
    {.msgId = 7, .size = CMOCKA_GLUECODE_NVM_MAX_SIZE, .mapfunction = test_GlueCodeNvmMap_Item },
    // For testing correct handling of NVM items which size is greater than allowed
    {.msgId = 8, .size = CMOCKA_GLUECODE_NVM_MAX_SIZE + 1, .mapfunction = test_GlueCodeNvmMap_Item },

};


static void test_unknown_action_nvm(void** state)
{
  GlueCodeProcessNvm_Common_IO_S nvmCommon;
  size_t size;
  size_t i;
  size = sizeof(common_nvmOfInterests)/sizeof(common_nvmOfInterests[0]);

  nvmAction = (enum GlueCodeNvmAction) UINT16_MAX;

  for (i = 0; i < size; i++)
  {
    expect_function_call(__wrap_HlpFailure_EndlessLoop);
  }
  GlueCodeNvm_HandleNvmItemsOfInterest(common_nvmOfInterests,
                                    size,
                                    nvmAction,
                                    &nvmCommon);
  (void) state;
}

static void test_read_nvm(void** state)
{
  GlueCodeProcessNvm_Common_IO_S nvmCommon;
  NvmLocalFlashMisr_B flashMisrU;
  NvmLocalFlashMisr_B flashMisrY;
  size_t size;
  size_t i;

  nvmCommon.U.flashMisr = &flashMisrU;
  nvmCommon.Y.flashMisr = &flashMisrY;

  size = sizeof(common_nvmOfInterests)/sizeof(common_nvmOfInterests[0]);

  nvmAction = GlueCodeNvmAction_ReadItem;

  for (i = 0; i < size; i++)
  {
    if (common_nvmOfInterests[i].size > CMOCKA_GLUECODE_NVM_MAX_SIZE)
    {
      expect_function_call(__wrap_HlpFailure_EndlessLoop);
    }
    else
    {
      expect_function_call(__wrap_ModelSupport_ReadNvm);
    }
  }
  GlueCodeNvm_HandleNvmItemsOfInterest(common_nvmOfInterests,
                                    size,
                                    nvmAction,
                                    &nvmCommon);
  (void) state;
}

static void test_write_nvm(void** state)
{
  GlueCodeProcessNvm_Common_IO_S nvmCommon;
  NvmLocalFlashMisr_B flashMisrU;
  NvmLocalFlashMisr_B flashMisrY;
  size_t size;
  size_t i;

  nvmCommon.U.flashMisr = &flashMisrU;
  nvmCommon.Y.flashMisr = &flashMisrY;
  size = sizeof(common_nvmOfInterests)/sizeof(common_nvmOfInterests[0]);

  nvmAction = GlueCodeNvmAction_WriteItem;

  for (i = 0; i < size; i++)
  {
    if (common_nvmOfInterests[i].size > CMOCKA_GLUECODE_NVM_MAX_SIZE)
    {
      expect_function_call(__wrap_HlpFailure_EndlessLoop);
    }
    else
    {
      expect_function_call(__wrap_ModelSupport_WriteNvm);
    }
  }
  GlueCodeNvm_HandleNvmItemsOfInterest(common_nvmOfInterests,
                                    size,
                                    nvmAction,
                                    &nvmCommon);
  (void) state;
}

static void test_write_if_changed_nvm_no_changes(void** state)
{
  GlueCodeProcessNvm_Common_IO_S nvmCommon;
  NvmLocalFlashMisr_B flashMisrU;
  NvmLocalFlashMisr_B flashMisrY;
  size_t size;
  size_t i;

  nvmCommon.U.flashMisr = &flashMisrU;
  nvmCommon.Y.flashMisr = &flashMisrY;
  size = sizeof(common_nvmOfInterests)/sizeof(common_nvmOfInterests[0]);

  nvmAction = GlueCodeNvmAction_WriteIfChangedLoopBack;

  for (i = 0; i < size; i++)
  {
    nvmCommon.U.flashMisr->UM[i] = i;
    nvmCommon.Y.flashMisr->UM[i] = i;

    if (common_nvmOfInterests[i].size > CMOCKA_GLUECODE_NVM_MAX_SIZE)
    {
      expect_function_call(__wrap_HlpFailure_EndlessLoop);
    }
  }
  GlueCodeNvm_HandleNvmItemsOfInterest(common_nvmOfInterests,
                                    size,
                                    nvmAction,
                                    &nvmCommon);

  for (i = 0; i < size; i++)
  {
    if (common_nvmOfInterests[i].size <= CMOCKA_GLUECODE_NVM_MAX_SIZE)
    {
      assert_true(nvmCommon.U.flashMisr->UM[i] == nvmCommon.Y.flashMisr->UM[i]);
    }
  }

  (void) state;
}

static void test_write_if_changed_nvm_with_changes(void** state)
{
  GlueCodeProcessNvm_Common_IO_S nvmCommon;
  NvmLocalFlashMisr_B flashMisrU;
  NvmLocalFlashMisr_B flashMisrY;
  size_t size;
  size_t i;

  nvmCommon.U.flashMisr = &flashMisrU;
  nvmCommon.Y.flashMisr = &flashMisrY;
  size = sizeof(common_nvmOfInterests)/sizeof(common_nvmOfInterests[0]);

  nvmAction = GlueCodeNvmAction_WriteIfChangedLoopBack;

  for (i = 0; i < size; i++)
  {
    nvmCommon.U.flashMisr->UM[i] = i;
    nvmCommon.Y.flashMisr->UM[i] = (i + 1)  * 10;

    if (common_nvmOfInterests[i].size > CMOCKA_GLUECODE_NVM_MAX_SIZE)
    {
      expect_function_call(__wrap_HlpFailure_EndlessLoop);
    }
    else
    {
      expect_function_call(__wrap_ModelSupport_WriteNvm);
    }
  }
  GlueCodeNvm_HandleNvmItemsOfInterest(common_nvmOfInterests,
                                    size,
                                    nvmAction,
                                    &nvmCommon);

  for (i = 0; i < size; i++)
  {
    if (common_nvmOfInterests[i].size <= CMOCKA_GLUECODE_NVM_MAX_SIZE)
    {
      assert_true(nvmCommon.U.flashMisr->UM[i] == nvmCommon.Y.flashMisr->UM[i]);
    }
  }

  (void) state;
}

int main(void)
{
    int retval = 0;

#ifdef CMOCKA_DIAB
    putenv("CMOCKA_XML_FILE=src_common_gluecode_Nvm.xml"); // environment variable for XML file when running on PPC
#endif

    const struct CMUnitTest tests[] =
    {
        cmocka_unit_test(test_read_nvm),
        cmocka_unit_test(test_write_nvm),
        cmocka_unit_test(test_write_if_changed_nvm_no_changes),
        cmocka_unit_test(test_write_if_changed_nvm_with_changes),
        cmocka_unit_test(test_unknown_action_nvm)
    };

    cmocka_set_message_output(CM_OUTPUT_XML);

    retval =  cmocka_run_group_tests_name("src_common_gluecode_Nvm", tests, NULL, NULL);
	
#ifdef CMOCKA_DIAB
    read_xml_file("src_common_gluecode_Nvm.xml"); // extract XML test results from file in RAM when running on PPC
#endif

    return retval;
}

extern void __wrap_ModelSupport_ReadNvm(int id, uint8_t * ptr, size_t length)
{
  function_called();
}

extern void __wrap_ModelSupport_WriteNvm(int id, const uint8_t * ptr, size_t length)
{
  function_called();
}

extern void __wrap_HlpFailure_EndlessLoop(void)
{
  function_called();
}

extern void __wrap___sc_procYield(void)
{

}


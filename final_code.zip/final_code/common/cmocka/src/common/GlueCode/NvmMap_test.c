#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h> /* polyspace MISRA-C3:21.4 [Not a defect:Low] "Required by CMOCKA" */
#include <stdint.h>
#include <stdbool.h>
#include "GlueCode/SharedNvm.h"
#include "GlueCode/NvmMap.h"
#include "GlueCode/Nvm.h"

#include "cmocka.h"

enum data_type {
  DATA_TYPE_UINT32,
  DATA_TYPE_UINT16,
  DATA_TYPE_UINT8,
  DATA_TYPE_BOOL
};


static void test_set_value(void * pointer, uint32_t value, uint16_t index, enum data_type type);
static uint32_t test_get_value(void * pointer, size_t index, enum data_type type);

static void test_correct_handling(enum nvm_message_id * msg_ids,
                                size_t size,
                                GlueCodeProcessNvm_Common_S * nvmCommon,
                                GlueCodeNvm_MapFunction mapfunction,
                                void * referenceValues,
                                enum data_type type);

//! @brief Check mapping of some reference values is working
static void test_GlueCodeNvmMap_Item208_usage(void** state)
{
  GlueCodeProcessNvm_Common_S nvmCommon;
  NvmLocalResetReasonCounter_B resetReasonCounter;
  nvmCommon.resetReasonCounter = &resetReasonCounter;

  enum nvm_message_id msg_ids[] = {NVMITEM208_ALL_MSGID_NvmId};
  uint8_t * pReferenceValue;

  pReferenceValue = &resetReasonCounter.destructiveResetFccuFailureToReact;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item208, (void *) &pReferenceValue, DATA_TYPE_UINT8);

  pReferenceValue = &resetReasonCounter.functionalResetExternalReset;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item208, (void *) &pReferenceValue, DATA_TYPE_UINT8);

  (void) state;
}

//! @brief Check mapping of some reference values is working
static void test_GlueCodeNvmMap_Item207_usage(void** state)
{
  GlueCodeProcessNvm_Common_S nvmCommon;
  NvmLocalFccu_B fccu = {0};
  nvmCommon.fccu = &fccu;

  enum nvm_message_id msg_ids[] = {NVMITEM207_ALL_FCCU2_MSGID_NvmId};
  uint32_t * pReferenceValue;

  pReferenceValue = &fccu.fault2;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item207, (void *) &pReferenceValue, DATA_TYPE_UINT32);

  (void) state;
}

//! @brief Check mapping of some reference values is working
static void test_GlueCodeNvmMap_Item206_usage(void** state)
{
  GlueCodeProcessNvm_Common_S nvmCommon;
  NvmLocalFccu_B fccu = {0};
  nvmCommon.fccu = &fccu;

  enum nvm_message_id msg_ids[] = {NVMITEM206_ALL_FCCU01_MSGID_NvmId};
  uint32_t * pReferenceValue;

  pReferenceValue = &fccu.fault0;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item206, (void *) &pReferenceValue, DATA_TYPE_UINT32);
  pReferenceValue = &fccu.fault1;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item206, (void *) &pReferenceValue, DATA_TYPE_UINT32);

  (void) state;
}

//! @brief Check mapping of some reference values is working
static void test_GlueCodeNvmMap_Item205_usage(void** state)
{
  GlueCodeProcessNvm_Common_S nvmCommon;
  uint8_t stimulationStep = 0;
  uint8_t resetPatternIndex = 0;
  NvmLocalResetBuffer_B resetBuffer;

  nvmCommon.stimulationStep = &stimulationStep;
  nvmCommon.resetPatternIndex = &resetPatternIndex;
  nvmCommon.resetBuffer = &resetBuffer;

  enum nvm_message_id msg_ids[] = {NVMITEM205_ALL_MSGID_NvmId};
  uint8_t * pReferenceValue;

  pReferenceValue = &stimulationStep;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item205, (void *) &pReferenceValue, DATA_TYPE_UINT8);
//  pReferenceValue = &resetPatternIndex;
//  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item205, (void *) &pReferenceValue, DATA_TYPE_UINT8);
//  pReferenceValue = &resetBuffer.index;
//  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item205, (void *) &pReferenceValue, DATA_TYPE_UINT8);

  (void) state;
}

//! @brief Check mapping of some reference values is working
static void test_GlueCodeNvmMap_Item140_usage(void** state)
{
  GlueCodeProcessNvm_Common_S nvmCommon;
  NvmGlobal_B global;
  nvmCommon.global = &global;

  enum nvm_message_id msg_ids[] = {NVMITEM140_MSGID_NvmId};
  uint16_t * pReferenceValue;

  pReferenceValue = &global.factoryCfg.Parameter.A11p0mmps2;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item140, (void *) &pReferenceValue, DATA_TYPE_UINT16);

  pReferenceValue = &global.factoryCfg.Parameter.A21p0mmps2;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item140, (void *) &pReferenceValue, DATA_TYPE_UINT16);

  pReferenceValue = &global.factoryCfg.Parameter.A2Down1p0mmps2;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item140, (void *) &pReferenceValue, DATA_TYPE_UINT16);

  pReferenceValue = &global.factoryCfg.Parameter.A31p0mmps2;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item140, (void *) &pReferenceValue, DATA_TYPE_UINT16);

  (void) state;
}

//! @brief Check mapping of some reference values is working
static void test_GlueCodeNvmMap_Item141_usage(void** state)
{
  GlueCodeProcessNvm_Common_S nvmCommon;
  NvmGlobal_B global;
  nvmCommon.global = &global;

  enum nvm_message_id msg_ids[] = {NVMITEM141_MSGID_NvmId};
  uint16_t * pReferenceValue;

  pReferenceValue = &global.factoryCfg.Parameter.A3Down1p0mmps2;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item141, (void *) &pReferenceValue, DATA_TYPE_UINT16);

  pReferenceValue = &global.factoryCfg.Parameter.DtBrake1p0ms;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item141, (void *) &pReferenceValue, DATA_TYPE_UINT16);
      
  pReferenceValue = &global.factoryCfg.Parameter.DtSFC1p0ms;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item141, (void *) &pReferenceValue, DATA_TYPE_UINT16);

  pReferenceValue = &global.factoryCfg.Parameter.StrikeSpeed1p0mmps;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item141, (void *) &pReferenceValue, DATA_TYPE_UINT16);

  (void) state;
}

//! @brief Check mapping of some reference values is working
static void test_GlueCodeNvmMap_Item142_usage(void** state)
{
  GlueCodeProcessNvm_Common_S nvmCommon;
  NvmGlobal_B global;
  nvmCommon.global = &global;

  enum nvm_message_id msg_ids[] = {NVMITEM142_MSGID_NvmId};
  uint16_t * pReferenceValue;

  pReferenceValue = &global.factoryCfg.Parameter.MinBuffer1p0mm;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item142, (void *) &pReferenceValue, DATA_TYPE_UINT16);

  pReferenceValue = &global.factoryCfg.Parameter.MinEtsSpeed1p0mmps;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item142, (void *) &pReferenceValue, DATA_TYPE_UINT16);

  pReferenceValue = &global.factoryCfg.Parameter.SpareWord[0];
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item142, (void *) &pReferenceValue, DATA_TYPE_UINT16);

  pReferenceValue = &global.factoryCfg.Parameter.SpareWord[1];
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item142, (void *) &pReferenceValue, DATA_TYPE_UINT16);

  (void) state;
}

//! @brief Check mapping of some reference values is working
static void test_GlueCodeNvmMap_Item143_usage(void** state)
{
  GlueCodeProcessNvm_Common_S nvmCommon;
  NvmGlobal_B global;
  nvmCommon.global = &global;

  enum nvm_message_id msg_ids[] = {NVMITEM143_MSGID_NvmId};
  uint16_t * pReferenceValue;

  pReferenceValue = &global.factoryCfg.Parameter.SpareWord[2];
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item143, (void *) &pReferenceValue, DATA_TYPE_UINT16);

  pReferenceValue = &global.factoryCfg.Parameter.SpareWord[3];
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item143, (void *) &pReferenceValue, DATA_TYPE_UINT16);

  pReferenceValue = &global.factoryCfg.Parameter.SpareWord[4];
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item143, (void *) &pReferenceValue, DATA_TYPE_UINT16);

  pReferenceValue = &global.factoryCfg.Parameter.SpareWord[5];
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item143, (void *) &pReferenceValue, DATA_TYPE_UINT16);

  (void) state;
}

//! @brief Check mapping of some reference values is working
static void test_GlueCodeNvmMap_Item23_usage(void** state)
{
  GlueCodeProcessNvm_Common_S nvmCommon;
  NvmGlobal_B global;
  nvmCommon.global = &global;

  enum nvm_message_id msg_ids[] = {NVMITEM23_MSGID_NvmId};
  bool_t *  pReferenceValue;
  uint8_t * pReferenceValue2;

  pReferenceValue = &global.factoryCfg.Parameter.PICS;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item23, (void *) &pReferenceValue, DATA_TYPE_BOOL);

  pReferenceValue = &global.factoryCfg.Parameter.CLAD;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item23, (void *) &pReferenceValue, DATA_TYPE_BOOL);

  pReferenceValue = &global.factoryCfg.Parameter.RearDoors;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item23, (void *) &pReferenceValue, DATA_TYPE_BOOL);

  pReferenceValue2 = &global.factoryCfg.Parameter.SpareJumper1_8;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item23, (void *) &pReferenceValue2, DATA_TYPE_UINT8);

  (void) state;
}


//! @brief Check mapping of some reference values is working
static void test_GlueCodeNvmMap_Item8_usage(void** state)
{
  GlueCodeProcessNvm_Common_S nvmCommon;
  NvmGlobal_B global;
  nvmCommon.global = &global;

  enum nvm_message_id msg_ids[] = {NVMITEM8_MSGID_NvmId};
  uint8_t * pReferenceValue;

  pReferenceValue = &global.factoryCfg.Factory.DateWeek[0];
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item8, (void *) &pReferenceValue, DATA_TYPE_UINT8);

  pReferenceValue = &global.factoryCfg.Factory.DateWeek[1];
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item8, (void *) &pReferenceValue, DATA_TYPE_UINT8);

  pReferenceValue = &global.factoryCfg.Factory.DateYear[2];
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item8, (void *) &pReferenceValue, DATA_TYPE_UINT8);

  pReferenceValue = &global.factoryCfg.Factory.DateYear[3];
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item8, (void *) &pReferenceValue, DATA_TYPE_UINT8);

  (void) state;
}

//! @brief Check mapping of some reference values is working
static void test_GlueCodeNvmMap_Item7_usage(void** state)
{
  GlueCodeProcessNvm_Common_S nvmCommon;
  NvmGlobal_B global;
  nvmCommon.global = &global;

  enum nvm_message_id msg_ids[] = {NVMITEM7_MSGID_NvmId};
  uint8_t * pReferenceValue;

  pReferenceValue = &global.factoryCfg.Factory.Name[0];
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item7, (void *) &pReferenceValue, DATA_TYPE_UINT8);

  pReferenceValue = &global.factoryCfg.Factory.Name[1];
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item7, (void *) &pReferenceValue, DATA_TYPE_UINT8);

  pReferenceValue = &global.factoryCfg.Factory.Name[4];
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item7, (void *) &pReferenceValue, DATA_TYPE_UINT8);

  pReferenceValue = &global.factoryCfg.Factory.Name[7];
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item7, (void *) &pReferenceValue, DATA_TYPE_UINT8);

  (void) state;
}

//! @brief Check mapping of some reference values is working
static void test_GlueCodeNvmMap_Item6_usage(void** state)
{
  GlueCodeProcessNvm_Common_S nvmCommon;
  NvmGlobal_B global;
  nvmCommon.global = &global;

  enum nvm_message_id msg_ids[] = {NVMITEM6_MSGID_NvmId};
  uint8_t * pReferenceValue;

  pReferenceValue = &global.factoryCfg.Certificate.Prefix;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item6, (void *) &pReferenceValue, DATA_TYPE_UINT8);

  pReferenceValue = &global.factoryCfg.Certificate.Number[0];
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item6, (void *) &pReferenceValue, DATA_TYPE_UINT8);

  pReferenceValue = &global.factoryCfg.Certificate.Number[2];
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item6, (void *) &pReferenceValue, DATA_TYPE_UINT8);

  pReferenceValue = &global.factoryCfg.Certificate.Number[4];
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item6, (void *) &pReferenceValue, DATA_TYPE_UINT8);

  (void) state;
}

//! @brief Check mapping of some reference values is working
static void test_GlueCodeNvmMap_Item5_usage(void** state)
{
  GlueCodeProcessNvm_Common_S nvmCommon;
  NvmGlobal_B global;
  nvmCommon.global = &global;

  enum nvm_message_id msg_ids[] = {NVMITEM5_MSGID_NvmId};
  uint16_t * pReferenceValue;

  pReferenceValue = &global.factoryCfg.Parameter.SabBoardVersion;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item5, (void *) &pReferenceValue, DATA_TYPE_UINT16);

  pReferenceValue = &global.factoryCfg.Parameter.DriveBoardVersion;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item5, (void *) &pReferenceValue, DATA_TYPE_UINT16);

  pReferenceValue = &global.factoryCfg.Parameter.CanProtocolVersion;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item5, (void *) &pReferenceValue, DATA_TYPE_UINT16);

  (void) state;
}

//! @brief Check mapping of some reference values is working
static void test_GlueCodeNvmMap_Item4_usage(void** state)
{
  GlueCodeProcessNvm_Common_S nvmCommon;
  NvmGlobal_B global;
  nvmCommon.global = &global;

  enum nvm_message_id msg_ids[] = {NVMITEM4_MSGID_NvmId};
  uint8_t * pReferenceValue;
  uint16_t * pReferenceValue2;

  pReferenceValue = &global.factoryCfg.Parameter.DzSiceUCM1p0mm;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item4, (void *) &pReferenceValue, DATA_TYPE_UINT8);

  pReferenceValue2 = &global.factoryCfg.Parameter.EIBoardVersion;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item4, (void *) &pReferenceValue2, DATA_TYPE_UINT16);

  pReferenceValue2 = &global.factoryCfg.Parameter.CarBoardVersion;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item4, (void *) &pReferenceValue2, DATA_TYPE_UINT16);

  (void) state;
}

//! @brief Check mapping of some reference values is working
static void test_GlueCodeNvmMap_Item3_usage(void** state)
{
  GlueCodeProcessNvm_Common_S nvmCommon;
  NvmGlobal_B global;
  nvmCommon.global = &global;

  enum nvm_message_id msg_ids[] = {NVMITEM3_MSGID_NvmId};
  uint16_t * pReferenceValue;

  pReferenceValue = &global.factoryCfg.Parameter.PitProtection1p0mm;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item3, (void *) &pReferenceValue, DATA_TYPE_UINT16);

  pReferenceValue = &global.factoryCfg.Parameter.OverheadProtection1p0mm;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item3, (void *) &pReferenceValue, DATA_TYPE_UINT16);

  pReferenceValue = &global.factoryCfg.Parameter.Overhead1p0mm;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item3, (void *) &pReferenceValue, DATA_TYPE_UINT16);

  (void) state;
}

//! @brief Check mapping of some reference values is working
static void test_GlueCodeNvmMap_Item2_usage(void** state)
{
  GlueCodeProcessNvm_Common_S nvmCommon;
  NvmGlobal_B global;
  nvmCommon.global = &global;

  enum nvm_message_id msg_ids[] = {NVMITEM2_MSGID_NvmId};
  uint16_t * pReferenceValue;

  pReferenceValue = &global.factoryCfg.Parameter.LS6MICAO1p0mm;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item2, (void *) &pReferenceValue, DATA_TYPE_UINT16);

  pReferenceValue = &global.factoryCfg.Parameter.LS6PINS1p0mm;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item2, (void *) &pReferenceValue, DATA_TYPE_UINT16);

  pReferenceValue = &global.factoryCfg.Parameter.LS5PINS1p0mm;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item2, (void *) &pReferenceValue, DATA_TYPE_UINT16);

  pReferenceValue = &global.factoryCfg.Parameter.LS5MICAO1p0mm;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item2, (void *) &pReferenceValue, DATA_TYPE_UINT16);

  (void) state;
}

//! @brief Check mapping of some reference values is working
static void test_GlueCodeNvmMap_Item1_usage(void** state)
{
  GlueCodeProcessNvm_Common_S nvmCommon;
  NvmGlobal_B global;
  nvmCommon.global = &global;

  enum nvm_message_id msg_ids[] = {NVMITEM1_MSGID_NvmId};
  uint16_t * pReferenceValue;
  uint8_t * pReferenceValue2;
  pReferenceValue = &global.factoryCfg.Parameter.NomSpeed1p0mmps;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item1, (void *) &pReferenceValue, DATA_TYPE_UINT16);

  pReferenceValue2 = &global.factoryCfg.Parameter.Rise1p0m;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item1, (void *) &pReferenceValue2, DATA_TYPE_UINT8);

  pReferenceValue2 = &global.factoryCfg.Parameter.LS8Position1p0mm;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item1, (void *) &pReferenceValue2, DATA_TYPE_UINT8);

  pReferenceValue2 = &global.factoryCfg.Parameter.LS7Position1p0mm;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item1, (void *) &pReferenceValue2, DATA_TYPE_UINT8);

  (void) state;
}

//! @brief Check mapping of some reference values is working
static void test_GlueCodeNvmMap_Item0_usage(void** state)
{
  GlueCodeProcessNvm_Common_S nvmCommon;
  NvmGlobal_B global;
  nvmCommon.global = &global;

  enum nvm_message_id msg_ids[] = {NVMITEM0_MSGID_NvmId};
  uint8_t * pReferenceValue;

  pReferenceValue = &global.factoryCfg.Parameter.UnitNr[0];
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item0, (void *) &pReferenceValue, DATA_TYPE_UINT8);

  pReferenceValue = &global.factoryCfg.Parameter.UnitNr[2];
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item0, (void *) &pReferenceValue, DATA_TYPE_UINT8);

  pReferenceValue = &global.factoryCfg.Parameter.UnitNr[4];
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item0, (void *) &pReferenceValue, DATA_TYPE_UINT8);

  pReferenceValue = &global.factoryCfg.Parameter.UnitNr[7];
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item0, (void *) &pReferenceValue, DATA_TYPE_UINT8);

  (void) state;
}

//! @brief Check mapping of some reference values is working
static void test_GlueCodeNvmMap_Item25_usage(void** state)
{
  GlueCodeProcessNvm_Common_S nvmCommon;
  NvmGlobal_B global;
  nvmCommon.global = &global;

  enum nvm_message_id msg_ids[] = {NVMITEM25_MSGID_NvmId};
  uint16_t * pReferenceValue;
  uint8_t * pReferenceValue2;

  pReferenceValue = &global.SystemFloorTable.RevisionIndex;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item25, (void *) &pReferenceValue, DATA_TYPE_UINT16);

  pReferenceValue2 = &global.SystemFloorTable.TableStatus.Accuracy;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item25, (void *) &pReferenceValue2, DATA_TYPE_UINT8);

  pReferenceValue2 = &global.SystemFloorTable.TableStatus.BottomFloorNumber;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item25, (void *) &pReferenceValue2, DATA_TYPE_UINT8);

  pReferenceValue2 = &global.SystemFloorTable.FormatVersion;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item25, (void *) &pReferenceValue2, DATA_TYPE_UINT8);

  (void) state;
}

//! @brief Check mapping of some reference values is working
static void test_GlueCodeNvmMap_Item26_usage(void** state)
{
  GlueCodeProcessNvm_Common_S nvmCommon;
  NvmGlobal_B global;
  nvmCommon.global = &global;

  enum nvm_message_id msg_ids[] = {NVMITEM26_MSGID_NvmId};
  uint32_t * pReferenceValue;
  uint8_t * pReferenceValue2;
  pReferenceValue = &global.SystemFloorTable.CWTBufferPosition;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item26, (void *) &pReferenceValue, DATA_TYPE_UINT32);

  pReferenceValue2 = &global.SystemFloorTable.CWTBufferReserved;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item26, (void *) &pReferenceValue2, DATA_TYPE_UINT8);

  pReferenceValue = &global.SystemFloorTable.CarBufferPosition;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item26, (void *) &pReferenceValue, DATA_TYPE_UINT32);

  pReferenceValue2 = &global.SystemFloorTable.CarBufferReserved;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item26, (void *) &pReferenceValue2, DATA_TYPE_UINT8);

  (void) state;
}

//! @brief Check mapping of some reference values is working
static void test_GlueCodeNvmMap_Item27_usage(void** state)
{
  GlueCodeProcessNvm_Common_S nvmCommon;
  NvmGlobal_B global;
  size_t i;
  nvmCommon.global = &global;

  enum nvm_message_id msg_ids[] = {NVMITEM27_MSGID_NvmId};
  int32_t * pReferenceValue;
  bool_t * pReferenceValue2;

  pReferenceValue = &global.cfg.TapeOffsetLdg00p1mm;
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item27, (void *) &pReferenceValue, DATA_TYPE_UINT32);

  for (i=0; i < sizeof(global.SystemFloorTable.FloorInfo) / sizeof(global.SystemFloorTable.FloorInfo[0]); i++)
  {
    pReferenceValue2 = &global.SystemFloorTable.FloorInfo[i].verified;
    test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item27, (void *) &pReferenceValue2, DATA_TYPE_BOOL);
  }

  (void) state;
}

//! @brief Check mapping of some reference values is working
static void test_GlueCodeNvmMap_Item28_39_usage(void** state)
{
  GlueCodeProcessNvm_Common_S nvmCommon;
  NvmGlobal_B global;
  nvmCommon.global = &global;
  size_t i;
  enum nvm_message_id msg_ids[] = {NVMITEM28_MSGID_NvmId, NVMITEM29_MSGID_NvmId, NVMITEM30_MSGID_NvmId, NVMITEM31_MSGID_NvmId,
                                     NVMITEM32_MSGID_NvmId, NVMITEM33_MSGID_NvmId, NVMITEM34_MSGID_NvmId, NVMITEM35_MSGID_NvmId, NVMITEM36_MSGID_NvmId,
                                     NVMITEM37_MSGID_NvmId, NVMITEM38_MSGID_NvmId, NVMITEM39_MSGID_NvmId};

  bool_t * pReferenceValues[sizeof(msg_ids)/sizeof(enum nvm_message_id)];

  for (i=0; i < sizeof(msg_ids)/sizeof(enum nvm_message_id); i++)
  {
    pReferenceValues[i] = &global.SystemFloorTable.FloorInfo[0+i*2].clipValid;
  }
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item28_39, (void *) pReferenceValues, DATA_TYPE_BOOL);

  for (i=0; i < sizeof(msg_ids)/sizeof(enum nvm_message_id); i++)
  {
    pReferenceValues[i] = &global.SystemFloorTable.FloorInfo[0+i*2].FloorFirstReserved2;
  }
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item28_39, (void *) pReferenceValues, DATA_TYPE_BOOL);

  for (i=0; i < sizeof(msg_ids)/sizeof(enum nvm_message_id); i++)
  {
    pReferenceValues[i] = &global.SystemFloorTable.FloorInfo[1+i*2].clipValid;
  }
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item28_39, (void *) pReferenceValues, DATA_TYPE_BOOL);

  for (i=0; i < sizeof(msg_ids)/sizeof(enum nvm_message_id); i++)
  {
    pReferenceValues[i] = &global.SystemFloorTable.FloorInfo[1+i*2].FloorFirstReserved2;
  }
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item28_39, (void *) pReferenceValues, DATA_TYPE_BOOL);

  (void) state;
}

//! @brief Check mapping of some reference values is working
static void test_GlueCodeNvmMap_Item100_105_usage(void** state)
{
  GlueCodeProcessNvm_Common_S nvmCommon;
  NvmGlobal_B global;
  nvmCommon.global = &global;
  size_t i;
  enum nvm_message_id msg_ids[] = {NVMITEM100_MSGID_NvmId, NVMITEM101_MSGID_NvmId, NVMITEM102_MSGID_NvmId,
                                     NVMITEM103_MSGID_NvmId, NVMITEM104_MSGID_NvmId, NVMITEM105_MSGID_NvmId};

  uint8_t * pReferenceValues[sizeof(msg_ids)/sizeof(enum nvm_message_id)];

  for (i=0; i < sizeof(msg_ids)/sizeof(enum nvm_message_id); i++)
  {
    pReferenceValues[i] = &global.SystemFloorTable.FloorInfo[0+i*4].frontDsSegs;
  }
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item100_105, (void *) pReferenceValues, DATA_TYPE_UINT8);

  for (i=0; i < sizeof(msg_ids)/sizeof(enum nvm_message_id); i++)
  {
    pReferenceValues[i] = &global.SystemFloorTable.FloorInfo[1+i*4].frontDsSegs;
  }
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item100_105, (void *) pReferenceValues, DATA_TYPE_UINT8);

  for (i=0; i < sizeof(msg_ids)/sizeof(enum nvm_message_id); i++)
  {
    pReferenceValues[i] = &global.SystemFloorTable.FloorInfo[2+i*4].rearDsSegs;
  }
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item100_105, (void *) pReferenceValues, DATA_TYPE_UINT8);

  for (i=0; i < sizeof(msg_ids)/sizeof(enum nvm_message_id); i++)
  {
    pReferenceValues[i] = &global.SystemFloorTable.FloorInfo[3+i*4].rearDsSegs;
  }
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item100_105, (void *) pReferenceValues, DATA_TYPE_UINT8);

  (void) state;
}

//! @brief Check mapping of some reference values is working
static void test_GlueCodeNvmMap_Item220_224_usage(void** state)
{
  GlueCodeProcessNvm_Common_S nvmCommon;
  NvmLocalFlashMisr_B  flashMisr;
  nvmCommon.flashMisr = &flashMisr;
  size_t i;
  enum nvm_message_id msg_ids[] = {NVMITEM220_MSGID_NvmId, NVMITEM221_MSGID_NvmId, NVMITEM222_MSGID_NvmId,
                                     NVMITEM223_MSGID_NvmId, NVMITEM224_MSGID_NvmId};

  uint32_t * pReferenceValues[sizeof(msg_ids)/sizeof(enum nvm_message_id)];

  for (i=0; i < sizeof(msg_ids)/sizeof(enum nvm_message_id); i++)
  {
    pReferenceValues[i] = &flashMisr.UM[0+i*2];
  }
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item220_224, pReferenceValues, DATA_TYPE_UINT32);

  for (i=0; i < sizeof(msg_ids)/sizeof(enum nvm_message_id); i++)
  {
    pReferenceValues[i] = &flashMisr.UM[1+i*2];
  }
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item220_224, pReferenceValues, DATA_TYPE_UINT32);

  (void) state;
}

//! @brief Check mapping of some reference values is working
static void test_GlueCodeNvmMap_Item209_219_usage(void** state)
{
  GlueCodeProcessNvm_Common_S nvmCommon;
  NvmLocalResetBuffer_B resetBuffer;

  nvmCommon.resetBuffer = &resetBuffer;
  size_t i;
  enum nvm_message_id msg_ids[] = {NVMITEM209_MSGID_NvmId, NVMITEM210_MSGID_NvmId, NVMITEM211_MSGID_NvmId, NVMITEM212_MSGID_NvmId, NVMITEM213_MSGID_NvmId,
                                     NVMITEM214_MSGID_NvmId, NVMITEM215_MSGID_NvmId, NVMITEM216_MSGID_NvmId, NVMITEM217_MSGID_NvmId, NVMITEM218_MSGID_NvmId,
                                     NVMITEM219_MSGID_NvmId };

  uint16_t * pReferenceValues[sizeof(msg_ids)/sizeof(enum nvm_message_id)];
  bool_t * pReferenceValues2[sizeof(msg_ids)/sizeof(enum nvm_message_id)];
  for (i=0; i < sizeof(msg_ids)/sizeof(enum nvm_message_id); i++)
  {
    pReferenceValues[i] = &resetBuffer.elements[i].Timestamp_5p0s;
  }
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item209_219, (void *) pReferenceValues, DATA_TYPE_UINT16);

  for (i=0; i < sizeof(msg_ids)/sizeof(enum nvm_message_id); i++)
  {
    pReferenceValues2[i] = &resetBuffer.elements[i].intended;
  }
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item209_219, (void *) pReferenceValues2, DATA_TYPE_BOOL);

  for (i=0; i < sizeof(msg_ids)/sizeof(enum nvm_message_id); i++)
  {
    pReferenceValues2[i] = &resetBuffer.elements[i].destructiveResetFccuFailureToReact;
  }
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item209_219, (void *) pReferenceValues2, DATA_TYPE_BOOL);

  for (i=0; i < sizeof(msg_ids)/sizeof(enum nvm_message_id); i++)
  {
    pReferenceValues2[i] = &resetBuffer.elements[i].functionalResetExternalReset;
  }
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item209_219, (void *) pReferenceValues2, DATA_TYPE_BOOL);

  for (i=0; i < sizeof(msg_ids)/sizeof(enum nvm_message_id); i++)
  {
    pReferenceValues2[i] = &resetBuffer.elements[i].functionalResetSelfTestCompleted;
  }
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item209_219, (void *) pReferenceValues2, DATA_TYPE_BOOL);

  for (i=0; i < sizeof(msg_ids)/sizeof(enum nvm_message_id); i++)
  {
    pReferenceValues2[i] = &resetBuffer.elements[i].functionalResetVoltageOutOfRange;
  }
  test_correct_handling(msg_ids, sizeof(msg_ids)/sizeof(enum nvm_message_id), &nvmCommon, GlueCodeNvmMap_Item209_219, (void *) pReferenceValues2, DATA_TYPE_BOOL);

  (void) state;
}

int main(void)
{
    int retval = 0;

#ifdef CMOCKA_DIAB
    putenv("CMOCKA_XML_FILE=src_common_gluecode_NvmMap.xml"); // environment variable for XML file when running on PPC
#endif
    
    const struct CMUnitTest tests[] =
    {
        cmocka_unit_test(test_GlueCodeNvmMap_Item208_usage),
        cmocka_unit_test(test_GlueCodeNvmMap_Item207_usage),
        cmocka_unit_test(test_GlueCodeNvmMap_Item206_usage),
        cmocka_unit_test(test_GlueCodeNvmMap_Item205_usage),
        cmocka_unit_test(test_GlueCodeNvmMap_Item140_usage),
        cmocka_unit_test(test_GlueCodeNvmMap_Item141_usage),
        cmocka_unit_test(test_GlueCodeNvmMap_Item142_usage),
        cmocka_unit_test(test_GlueCodeNvmMap_Item143_usage),
        cmocka_unit_test(test_GlueCodeNvmMap_Item23_usage),
        cmocka_unit_test(test_GlueCodeNvmMap_Item8_usage),
        cmocka_unit_test(test_GlueCodeNvmMap_Item7_usage),
        cmocka_unit_test(test_GlueCodeNvmMap_Item6_usage),
        cmocka_unit_test(test_GlueCodeNvmMap_Item5_usage),
        cmocka_unit_test(test_GlueCodeNvmMap_Item4_usage),
        cmocka_unit_test(test_GlueCodeNvmMap_Item3_usage),
        cmocka_unit_test(test_GlueCodeNvmMap_Item2_usage),
        cmocka_unit_test(test_GlueCodeNvmMap_Item1_usage),
        cmocka_unit_test(test_GlueCodeNvmMap_Item0_usage),
        cmocka_unit_test(test_GlueCodeNvmMap_Item25_usage),
        cmocka_unit_test(test_GlueCodeNvmMap_Item26_usage),
        cmocka_unit_test(test_GlueCodeNvmMap_Item27_usage),
        cmocka_unit_test(test_GlueCodeNvmMap_Item28_39_usage),
        cmocka_unit_test(test_GlueCodeNvmMap_Item100_105_usage),
        cmocka_unit_test(test_GlueCodeNvmMap_Item220_224_usage),
        cmocka_unit_test(test_GlueCodeNvmMap_Item209_219_usage)
    };

    cmocka_set_message_output(CM_OUTPUT_XML);

    retval =  cmocka_run_group_tests_name("src_common_gluecode_NvmMap", tests, NULL, NULL);

#ifdef CMOCKA_DIAB
    read_xml_file("src_common_gluecode_NvmMap.xml"); // extract XML test results from file in RAM when running on PPC
#endif

    return retval;
}

extern void __wrap_ModelSupport_ReadNvm(int id, uint8_t * ptr, size_t length)
{
  function_called();
}

extern void __wrap_ModelSupport_WriteNvm(int id, const uint8_t * ptr, size_t length)
{
  function_called();
}

extern   void __wrap_HlpFailure_EndlessLoop(void)
{
  function_called();
}

//! @brief generic check of GlueCode Nvm mapping functions
//!
//! @details
//!
//! @param[in] msg_ids contains a list of all valid nvm messsage ids
//! @param[in] size    of msg_ids
//! @param[in] nvmCommon caller is responsible to allocate the memory for this strucutre
//! @param[in] mapFunction a gludecode nvm mapping function
//! @param[in] referenceValues a list of pointers to various reference values, same size as msg_ids
//!
//! @details
//!
//! #test_correct_handling verifies for a given #mapFunction the correct reaction.
//! For checking this, two different sets of tests are executed.
//!
//! 1. Set of tests: Correct handling of invalid nvm message ids
//!   #mapFunction is called with each possible nvm message id in the range from 0..255.
//!   For each message, which is not element of #msg_ids, it is expected that #__wrap_HlpFailure_EndlessLoop is called.
//!
//! 2. Set of tests: Correct handling of the reference values for each valid message ids.
//!   For each msg_id within #msg_ids a referenceValue in #referenceValues is required.
//!   #mapFunction is called with msg_id, the related referenceValue and an NVM buffer under various conditions for a specific focus. After each call #MapFunction,
//!   refrenceValue and the NVM buffer are expected to fulfill specific conditions
//!
//!   - 1. Focus: NVM buffer affects reference values
//!     - None bit is set in the NVM buffer.
//!     - First bit of the reference value is set.
//!     - After function call, there is still no bit set in the NVM buffer, and also no bit in the reference value.

//!   - 2. Focus: NVM buffer affects reference values
//!     - All bits are set in the NVM buffer.
//!     - None bit of the reference value is set.
//!     - After function call, there are still all bits set in the NVM buffer, and any bit in the reference value is set.

//!   - 3. Focus: reference value affects NVM buffer
//!     - All bits are set in the NVM buffer.
//!     - None bit of the reference value is set.
//!     - After function call, any bit in the NVM buffer is not set anymore, and also no bit in the reference value.

//!   - 4. Focus: reference value affects NVM buffer
//!     - None bit is set in the NVM buffer.
//!     - First bit of the reference value is set.
//!     - After function call, any bit in the NVM buffer is set, and only first bit in the reference value is still set.

static void test_correct_handling(enum nvm_message_id * msg_ids,
                                        size_t size,
                                        GlueCodeProcessNvm_Common_S * nvmCommon,
                                        GlueCodeNvm_MapFunction mapfunction,
                                        void * referenceValues,
                                        enum data_type type)
{
  size_t i;
  size_t u;
  bool allowedMsgId;

  enum nvm_message_id msgId;

  uint64_t nvmBuffer = 0;
  uint64_t tmpNvmBuffer = 0;
  for(i=0; i < UINT16_MAX; i++)
  {
    msgId = (enum nvm_message_id) i;
    allowedMsgId = false;

    for (u = 0; u < size; u ++)
    {
      if (msgId == msg_ids[u])
      {
        allowedMsgId = true;
        break;
      }
    }

    if (!allowedMsgId)
    {
      expect_function_calls(__wrap_HlpFailure_EndlessLoop, 1);
      (*mapfunction)(msgId, (uint8_t *) &nvmBuffer, nvmCommon, true);
    }
  }

  for (u = 0; u < size; u ++)
  {

    msgId = msg_ids[u];

    // 1. Focus
    nvmBuffer = 0;
    test_set_value(referenceValues, 1, u, type);

    (*mapfunction)(msgId, (uint8_t *) &nvmBuffer, nvmCommon, false);

    assert_true(test_get_value(referenceValues, u, type) == 0);
    assert_true(nvmBuffer == 0);

    // 2. Focus
    nvmBuffer = UINT64_MAX;
    test_set_value(referenceValues, 0, u, type);

    (*mapfunction)(msgId, (uint8_t *) &nvmBuffer, nvmCommon, false);

    assert_true(test_get_value(referenceValues, u, type) > 0);
    assert_true(nvmBuffer == UINT64_MAX);

    // 3. Focus
    nvmBuffer = UINT64_MAX;
    test_set_value(referenceValues, 1, u, type);
    (*mapfunction)(msgId, (uint8_t *) &nvmBuffer, nvmCommon, true);
    tmpNvmBuffer = nvmBuffer;

    test_set_value(referenceValues, 0, u, type);
    (*mapfunction)(msgId, (uint8_t *) &nvmBuffer, nvmCommon, true);

    assert_true(test_get_value(referenceValues, u, type) == 0);
    assert_true(nvmBuffer != tmpNvmBuffer);

    // 4. Focus
    nvmBuffer = 0;
    test_set_value(referenceValues, 0, u, type);
    (*mapfunction)(msgId, (uint8_t *) &nvmBuffer, nvmCommon, true);
    tmpNvmBuffer = nvmBuffer;


    test_set_value(referenceValues, 1, u, type);
    (*mapfunction)(msgId, (uint8_t *) &nvmBuffer, nvmCommon, true);

    assert_true(test_get_value(referenceValues, u, type) == 1);
    assert_true(nvmBuffer != tmpNvmBuffer);

  }

}

static void test_set_value(void * pointer, uint32_t value, uint16_t index, enum data_type type)
{
  uint8_t  ** UInt8_pValue;
  uint16_t ** UInt16_pValue;
  uint32_t ** UInt32_pValue;
  bool_t   ** Bool_pValue;

  switch (type) {
    case DATA_TYPE_UINT8:
      UInt8_pValue        = (uint8_t **) pointer;
      *UInt8_pValue[index] = (uint8_t) value;
      break;
    case DATA_TYPE_UINT16:
      UInt16_pValue        = (uint16_t **) pointer;
      *UInt16_pValue[index] = (uint16_t) value;
      break;
    case DATA_TYPE_UINT32:
      UInt32_pValue        = (uint32_t **) pointer;
      *UInt32_pValue[index] = (uint32_t) value;
      break;
    case DATA_TYPE_BOOL:
      Bool_pValue        = (bool_t **) pointer;
      *Bool_pValue[index] = (bool_t) value;
      break;
    default:
      break;
  }
}

static uint32_t test_get_value(void * pointer, size_t index, enum data_type type)
{
  uint8_t  ** UInt8_pValue;
  uint16_t ** UInt16_pValue;
  uint32_t ** UInt32_pValue;
  bool_t   ** Bool_pValue;
  // 0 and 1 are used for some checks
  uint32_t retValue = UINT32_MAX;

  switch (type) {
    case DATA_TYPE_UINT8:
      UInt8_pValue        = (uint8_t **) pointer;
      retValue = (uint32_t) *UInt8_pValue[index];
      break;
    case DATA_TYPE_UINT16:
      UInt16_pValue        = (uint16_t **) pointer;
      retValue = (uint32_t) *UInt16_pValue[index];
      break;
    case DATA_TYPE_UINT32:
      UInt32_pValue        = (uint32_t **) pointer;
      retValue = (uint32_t) *UInt32_pValue[index];
      break;
    case DATA_TYPE_BOOL:
      Bool_pValue        = (bool_t **) pointer;
      retValue = (uint32_t) *Bool_pValue[index];
      break;
    default:
      break;
  }
  return retValue;
}

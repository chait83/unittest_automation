#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>

#include "GlueCode/CanInjectionDetection.h"
#include "cmocka.h"


// @note  for ease of implementation and reduction of complexity we use the lifetimecounter at a 1kHz clock, so that LifetimeCounter_Get() returns milliseconds and no clock-conversion is needed


// values used on SCON (src/pcb/Proc/SafetyProcess.c)
// see also src/pcb/Proc/SafetyProcess_test.c
#define CANINJECTIONDETECTIONCOUNT_SCON_HI  75  // <ReqId 385543>, messages per second: floor(1000ms/20ms * 1.50), floor(1000ms/19ms * 1.425)
#define CANINJECTIONDETECTIONCOUNT_SCON_LO  61  // <ReqId 385561>, messages per second: floor(1000ms/20ms * 1.22), floor(1000ms/19ms * 1.159)

#define GLUECODECANINJECTIONDETECTION_THRESHOLD_MS  1000U  // in ms, duration of the sliding window, <ReqId 385543>


extern void __wrap_HlpFailure_EndlessLoop(void);
extern uint64_t __wrap_LifetimeCounter_Get(void);
extern uint32_t __wrap_LifetimeCounter_ToMs32(const uint64_t timeClk);
extern uint64_t __wrap_LifetimeCounter_MsToLifetimeCounter(const uint32_t timeMs);


// @brief  verifies the expected output with the current @p oldInput and the given configuration at the current time of @p systemTimestamp
static void test_canInjectionDetection_Check_verifier(
  const bool oldInput,
  const bool expectedOutput,
  const uint32_t systemTimestamp,
  const size_t thresholdLo,
  const size_t thresholdHi,
  const size_t ringbufferIndex,
  const uint32_t* const ringbuffer,
  const size_t items
)
{
  const uint64_t  ticks = __wrap_LifetimeCounter_MsToLifetimeCounter(systemTimestamp);
  will_return(__wrap_LifetimeCounter_Get, ticks);
  assert_true(expectedOutput == GlueCodeCanInjectionDetection_Check(oldInput, thresholdLo, thresholdHi, ringbufferIndex, ringbuffer, items));
}


// @brief  test hitting/missing the edges of both thresholds, ringbuffer completely filled
static void test_canInjectionDetection_Check_01(const size_t thresholdLo, const size_t thresholdHi, const size_t offset)
{
  assert_true(2U < thresholdLo);
  assert_true(2U < thresholdHi);
  assert_true(thresholdLo < thresholdHi);

  size_t    ringbufferIndex = 0U;
  uint32_t  ringbuffer[thresholdHi];
  memset (ringbuffer, 0, sizeof (ringbuffer));

  const size_t  items = sizeof(ringbuffer)/sizeof(*ringbuffer);

  for ( size_t  i = 0U; i < offset; ++i )
  {
    GlueCodeCanInjectionDetection_Add(0U, &ringbufferIndex, ringbuffer, items);
  }

  uint32_t  msgTimestampMs = 0U;
  for ( size_t  i = 0U; i < (2U * items) + 13U; ++i )  // buffer is completely filled with a "random" number of entries, includes rollover of buffersize
  {
    GlueCodeCanInjectionDetection_Add(msgTimestampMs, &ringbufferIndex, ringbuffer, items);
    msgTimestampMs += 1U;  // reception-time is 1 ms for ease of calculations
  }

  // hit the higher threshold (expected output is true for any old input)
  const uint32_t  sysTimestampHiHit = msgTimestampMs + GLUECODECANINJECTIONDETECTION_THRESHOLD_MS - thresholdHi - 1U;
  test_canInjectionDetection_Check_verifier(false, true, sysTimestampHiHit, thresholdLo, thresholdHi, ringbufferIndex, ringbuffer, items);
  test_canInjectionDetection_Check_verifier(true,  true, sysTimestampHiHit, thresholdLo, thresholdHi, ringbufferIndex, ringbuffer, items);

  // hit the lower threshold (expected output is false for any old input)
  const uint32_t  sysTimestampLoHit = msgTimestampMs + GLUECODECANINJECTIONDETECTION_THRESHOLD_MS - thresholdLo + 1U;
  test_canInjectionDetection_Check_verifier(false, false, sysTimestampLoHit, thresholdLo, thresholdHi, ringbufferIndex, ringbuffer, items);
  test_canInjectionDetection_Check_verifier(true,  false, sysTimestampLoHit, thresholdLo, thresholdHi, ringbufferIndex, ringbuffer, items);

  // inside the range, no threshold hit (expected output is the old input)
  const uint32_t  sysTimestampNoHit = (sysTimestampHiHit + sysTimestampLoHit) / 2U;  // between lower and higher range
  test_canInjectionDetection_Check_verifier(false, false, sysTimestampNoHit, thresholdLo, thresholdHi, ringbufferIndex, ringbuffer, items);
  test_canInjectionDetection_Check_verifier(true,  true,  sysTimestampNoHit, thresholdLo, thresholdHi, ringbufferIndex, ringbuffer, items);

  // missed the higher threshold (expected output is the old input)
  const uint32_t  sysTimestampHiMiss = sysTimestampHiHit + 1U;  // increase duration -> less messages
  test_canInjectionDetection_Check_verifier(false, false, sysTimestampHiMiss, thresholdLo, thresholdHi, ringbufferIndex, ringbuffer, items);
  test_canInjectionDetection_Check_verifier(true,  true,  sysTimestampHiMiss, thresholdLo, thresholdHi, ringbufferIndex, ringbuffer, items);

  // missed the lower threshold (expected output is the old input)
  const uint32_t  sysTimestampLoMiss = sysTimestampLoHit - 1U;  // decrease duration -> more messages
  test_canInjectionDetection_Check_verifier(false, false, sysTimestampLoMiss, thresholdLo, thresholdHi, ringbufferIndex, ringbuffer, items);
  test_canInjectionDetection_Check_verifier(true,  true,  sysTimestampLoMiss, thresholdLo, thresholdHi, ringbufferIndex, ringbuffer, items);
}

// @brief  test hitting/missing the edges of both thresholds, ringbuffer not yet filled completely for lower threshold
static void test_canInjectionDetection_Check_02_lo(const size_t thresholdLo, const size_t thresholdHi, const size_t offset)
{
  assert_true(2U < thresholdLo);
  assert_true(2U < thresholdHi);
  assert_true(thresholdLo < thresholdHi);

  size_t    ringbufferIndex = 0U;
  uint32_t  ringbuffer[thresholdHi];
  memset (ringbuffer, 0, sizeof (ringbuffer));

  const size_t  items = sizeof(ringbuffer)/sizeof(*ringbuffer);

  for ( size_t  i = 0U; i < offset; ++i )
  {
    GlueCodeCanInjectionDetection_Add(0U, &ringbufferIndex, ringbuffer, items);
  }

  uint32_t  msgTimestampMs = 0U;

  for ( size_t  i = 0U; i < (thresholdLo - 1U); ++i )  // buffer is not filled with enough entries for thresholdLo
  {
    GlueCodeCanInjectionDetection_Add(msgTimestampMs, &ringbufferIndex, ringbuffer, items);
    msgTimestampMs += 1U;  // reception-time is 1 ms for ease of calculations
  }

  // try to hit the higher threshold, cannot be hit because of missing messages (expected output is the old input)
  const uint32_t  sysTimestampHiHit = msgTimestampMs + GLUECODECANINJECTIONDETECTION_THRESHOLD_MS - thresholdHi - 1U;
  test_canInjectionDetection_Check_verifier(false, false, sysTimestampHiHit, thresholdLo, thresholdHi, ringbufferIndex, ringbuffer, items);
  test_canInjectionDetection_Check_verifier(true,  true,  sysTimestampHiHit, thresholdLo, thresholdHi, ringbufferIndex, ringbuffer, items);

  // try to hit the lower threshold, cannot be hit because of missing messages (expected output is false for any old input)
  const uint32_t  sysTimestampLoHit = msgTimestampMs + GLUECODECANINJECTIONDETECTION_THRESHOLD_MS - thresholdLo + 1U;
  test_canInjectionDetection_Check_verifier(false, false, sysTimestampLoHit, thresholdLo, thresholdHi, ringbufferIndex, ringbuffer, items);
  test_canInjectionDetection_Check_verifier(true,  false, sysTimestampLoHit, thresholdLo, thresholdHi, ringbufferIndex, ringbuffer, items);

  // inside the range, no threshold hit (expected output is the old input)
  const uint32_t  sysTimestampNoHit = (sysTimestampHiHit + sysTimestampLoHit) / 2U;  // between lower and higher range
  test_canInjectionDetection_Check_verifier(false, false, sysTimestampNoHit, thresholdLo, thresholdHi, ringbufferIndex, ringbuffer, items);
  test_canInjectionDetection_Check_verifier(true,  true,  sysTimestampNoHit, thresholdLo, thresholdHi, ringbufferIndex, ringbuffer, items);

  // missed the higher threshold (expected output is the old input)
  const uint32_t  sysTimestampHiMiss = sysTimestampHiHit + 1U;  // increase duration -> less messages
  test_canInjectionDetection_Check_verifier(false, false, sysTimestampHiMiss, thresholdLo, thresholdHi, ringbufferIndex, ringbuffer, items);
  test_canInjectionDetection_Check_verifier(true,  true,  sysTimestampHiMiss, thresholdLo, thresholdHi, ringbufferIndex, ringbuffer, items);

  // missed the lower threshold (expected output is the old input)
  const uint32_t  sysTimestampLoMiss = sysTimestampLoHit - 1U;  // decrease duration -> more messages
  test_canInjectionDetection_Check_verifier(false, false, sysTimestampLoMiss, thresholdLo, thresholdHi, ringbufferIndex, ringbuffer, items);
  test_canInjectionDetection_Check_verifier(true,  true,  sysTimestampLoMiss, thresholdLo, thresholdHi, ringbufferIndex, ringbuffer, items);
}

// @brief  test hitting/missing the edges of both thresholds, ringbuffer not yet filled completely for higher threshold
static void test_canInjectionDetection_Check_02_hi(const size_t thresholdLo, const size_t thresholdHi, const size_t offset)
{
  assert_true(2U < thresholdLo);
  assert_true(2U < thresholdHi);
  assert_true(thresholdLo < thresholdHi);

  size_t    ringbufferIndex = 0U;
  uint32_t  ringbuffer[thresholdHi];
  memset (ringbuffer, 0, sizeof (ringbuffer));

  const size_t  items = sizeof(ringbuffer)/sizeof(*ringbuffer);

  for ( size_t  i = 0U; i < offset; ++i )
  {
    GlueCodeCanInjectionDetection_Add(0U, &ringbufferIndex, ringbuffer, items);
  }

  uint32_t  msgTimestampMs = 0U;

  for ( size_t  i = 0U; i < (thresholdHi - 1U); ++i )  // buffer is not filled with enough entries for thresholdLo
  {
    GlueCodeCanInjectionDetection_Add(msgTimestampMs, &ringbufferIndex, ringbuffer, items);
    msgTimestampMs += 1U;  // reception-time is 1 ms for ease of calculations
  }

  // try to hit the higher threshold, cannot be hit because of missing messages (expected output is the old input)
  const uint32_t  sysTimestampHiHit = msgTimestampMs + GLUECODECANINJECTIONDETECTION_THRESHOLD_MS - thresholdHi - 1U;
  test_canInjectionDetection_Check_verifier(false, false, sysTimestampHiHit, thresholdLo, thresholdHi, ringbufferIndex, ringbuffer, items);
  test_canInjectionDetection_Check_verifier(true,  true,  sysTimestampHiHit, thresholdLo, thresholdHi, ringbufferIndex, ringbuffer, items);

  // try to hit the lower threshold (expected output is false for any old input)
  const uint32_t  sysTimestampLoHit = msgTimestampMs + GLUECODECANINJECTIONDETECTION_THRESHOLD_MS - thresholdLo + 1U;
  test_canInjectionDetection_Check_verifier(false, false, sysTimestampLoHit, thresholdLo, thresholdHi, ringbufferIndex, ringbuffer, items);
  test_canInjectionDetection_Check_verifier(true,  false, sysTimestampLoHit, thresholdLo, thresholdHi, ringbufferIndex, ringbuffer, items);

  // inside the range, no threshold hit (expected output is the old input)
  const uint32_t  sysTimestampNoHit = (sysTimestampHiHit + sysTimestampLoHit) / 2U;  // between lower and higher range
  test_canInjectionDetection_Check_verifier(false, false, sysTimestampNoHit, thresholdLo, thresholdHi, ringbufferIndex, ringbuffer, items);
  test_canInjectionDetection_Check_verifier(true,  true,  sysTimestampNoHit, thresholdLo, thresholdHi, ringbufferIndex, ringbuffer, items);

  // missed the higher threshold (expected output is the old input)
  const uint32_t  sysTimestampHiMiss = sysTimestampHiHit + 1U;  // increase duration -> less messages
  test_canInjectionDetection_Check_verifier(false, false, sysTimestampHiMiss, thresholdLo, thresholdHi, ringbufferIndex, ringbuffer, items);
  test_canInjectionDetection_Check_verifier(true,  true,  sysTimestampHiMiss, thresholdLo, thresholdHi, ringbufferIndex, ringbuffer, items);

  // missed the lower threshold (expected output is the old input)
  const uint32_t  sysTimestampLoMiss = sysTimestampLoHit - 1U;  // decrease duration -> more messages
  test_canInjectionDetection_Check_verifier(false, false, sysTimestampLoMiss, thresholdLo, thresholdHi, ringbufferIndex, ringbuffer, items);
  test_canInjectionDetection_Check_verifier(true,  true,  sysTimestampLoMiss, thresholdLo, thresholdHi, ringbufferIndex, ringbuffer, items);
}

// @brief  thresholdLo too small
static void test_canInjectionDetection_Check_03(void)
{
  uint32_t        ringbuffer[13U] = {0U};  // dummy
  size_t          ringbufferIndex = 0U;  // dummy
  const size_t    items = sizeof(ringbuffer)/sizeof(*ringbuffer);

  const bool      oldState    = true;  // dummy
  const size_t    thresholdLo = 1U;  // value too small
  const size_t    thresholdHi = items / 2U;  // some "random" value

  const uint64_t  ticks = 0U;  // dummy

  will_return(__wrap_LifetimeCounter_Get, ticks);
  expect_function_call(__wrap_HlpFailure_EndlessLoop);
  (void)GlueCodeCanInjectionDetection_Check(oldState, thresholdLo, thresholdHi, ringbufferIndex, ringbuffer, items);
}

// @brief  thresholdHi too small
static void test_canInjectionDetection_Check_04(void)
{
  uint32_t        ringbuffer[13U] = {0U};  // dummy
  size_t          ringbufferIndex = 0U;  // dummy
  const size_t    items = sizeof(ringbuffer)/sizeof(*ringbuffer);

  const bool      oldState    = true;  // dummy
  const size_t    thresholdLo = items / 2U;  // some "random" value
  const size_t    thresholdHi = 1U;  // value too small

  const uint64_t  ticks = 0U;  // dummy

  will_return(__wrap_LifetimeCounter_Get, ticks);
  expect_function_call(__wrap_HlpFailure_EndlessLoop);
  (void)GlueCodeCanInjectionDetection_Check(oldState, thresholdLo, thresholdHi, ringbufferIndex, ringbuffer, items);
}

// @brief  thresholdLo too big
static void test_canInjectionDetection_Check_05(void)
{
  uint32_t        ringbuffer[13U] = {0U};  // dummy
  size_t          ringbufferIndex = 0U;  // dummy
  const size_t    items = sizeof(ringbuffer)/sizeof(*ringbuffer);

  const bool      oldState    = true;  // dummy
  const size_t    thresholdLo = items + 1U;  // value too big
  const size_t    thresholdHi = items / 2U;  // some "random" value

  const uint64_t  ticks = 0U;  // dummy

  will_return(__wrap_LifetimeCounter_Get, ticks);
  expect_function_call(__wrap_HlpFailure_EndlessLoop);
  (void)GlueCodeCanInjectionDetection_Check(oldState, thresholdLo, thresholdHi, ringbufferIndex, ringbuffer, items);
}

// @brief  thresholdHi too big
static void test_canInjectionDetection_Check_06(void)
{
  uint32_t        ringbuffer[13U] = {0U};  // dummy
  size_t          ringbufferIndex = 0U;  // dummy
  const size_t    items = sizeof(ringbuffer)/sizeof(*ringbuffer);

  const bool      oldState    = true;  // dummy
  const size_t    thresholdLo = items / 2U;  // some "random" value
  const size_t    thresholdHi = items + 1U;  // value too big

  const uint64_t  ticks = 0U;  // dummy

  will_return(__wrap_LifetimeCounter_Get, ticks);
  expect_function_call(__wrap_HlpFailure_EndlessLoop);
  (void)GlueCodeCanInjectionDetection_Check(oldState, thresholdLo, thresholdHi, ringbufferIndex, ringbuffer, items);
}

// @brief  thresholdLo not smaller than thresholdHi
static void test_canInjectionDetection_Check_07(void)
{
  uint32_t        ringbuffer[13U] = {0U};  // dummy
  size_t          ringbufferIndex = 0U;  // dummy
  const size_t    items = sizeof(ringbuffer)/sizeof(*ringbuffer);

  const bool      oldState    = true;  // dummy
  const size_t    thresholdLo = items / 2U;  // some "random" value
  const size_t    thresholdHi = thresholdLo;  // same value

  const uint64_t  ticks = 0U;  // dummy

  will_return(__wrap_LifetimeCounter_Get, ticks);
  expect_function_call(__wrap_HlpFailure_EndlessLoop);
  (void)GlueCodeCanInjectionDetection_Check(oldState, thresholdLo, thresholdHi, ringbufferIndex, ringbuffer, items);
}

// @brief  index out of range
static void test_canInjectionDetection_Check_08(void)
{
  uint32_t        ringbuffer[13U] = {0U};  // dummy
  const size_t    items = sizeof(ringbuffer)/sizeof(*ringbuffer);
  size_t          ringbufferIndex = items;  // index out of range

  const bool      oldState    = true;  // dummy
  const size_t    thresholdLo = items / 2U;  // dummy
  const size_t    thresholdHi = thresholdLo + 1U;  // dummy

  const uint64_t  ticks = 0U;  // dummy

  will_return(__wrap_LifetimeCounter_Get, ticks);
  expect_function_call(__wrap_HlpFailure_EndlessLoop);
  (void)GlueCodeCanInjectionDetection_Check(oldState, thresholdLo, thresholdHi, ringbufferIndex, ringbuffer, items);
}

// @brief  not enough items (DUT-condition cannot be triggered because of previous checks in the DUT-implementation)
static void test_canInjectionDetection_Check_09(void)
{
  uint32_t        ringbuffer[13U] = {0U};  // dummy
  size_t          ringbufferIndex = 0U;  // dummy
  const size_t    items = 1U;  // not enough items

  const bool      oldState    = true;  // dummy
  const size_t    thresholdLo = 1U;  // dummy
  const size_t    thresholdHi = 2U;  // dummy

  const uint64_t  ticks = 0U;  // dummy

  will_return(__wrap_LifetimeCounter_Get, ticks);
  expect_function_call(__wrap_HlpFailure_EndlessLoop);
  (void)GlueCodeCanInjectionDetection_Check(oldState, thresholdLo, thresholdHi, ringbufferIndex, ringbuffer, items);
}

static void test_canInjectionDetection_Check(void** state)
{
  const struct
  {
    const size_t  lo;
    const size_t  hi;
  } tbl[] =
  {
    {.lo = 10U                               , .hi = 100U                              },  // handpicked values
    {.lo = CANINJECTIONDETECTIONCOUNT_SCON_LO, .hi = CANINJECTIONDETECTIONCOUNT_SCON_HI},
  };

  for ( size_t  i = 0U; i < sizeof(tbl)/sizeof(*tbl); ++i )
  {
    for ( size_t  offset = 0U; offset < tbl[i].hi; ++offset )
    {
      test_canInjectionDetection_Check_01   (tbl[i].lo, tbl[i].hi, offset);  // test thresholds
      test_canInjectionDetection_Check_02_lo(tbl[i].lo, tbl[i].hi, offset);  // incomplete fill
      test_canInjectionDetection_Check_02_hi(tbl[i].lo, tbl[i].hi, offset);  // incomplete fill
    }
  }

  // error-tests
  test_canInjectionDetection_Check_03();
  test_canInjectionDetection_Check_04();
  test_canInjectionDetection_Check_05();
  test_canInjectionDetection_Check_06();
  test_canInjectionDetection_Check_07();
  test_canInjectionDetection_Check_08();
  test_canInjectionDetection_Check_09();

  (void)state;
}


// @brief  fill the ringbuffer with consecutive numbers and verify the contents
static void test_canInjectionDetection_Add_01(const size_t items, const size_t offset, const size_t entries)
{
  uint32_t  ringbuffer[items];
  memset (ringbuffer, 0, sizeof (ringbuffer));

  uint32_t  ringbufferExpect[items];
  memset (ringbufferExpect, 0, sizeof (ringbufferExpect));

  size_t  ringbufferIndex = offset;

  for ( size_t  i = 0U; i < entries; ++i )
  {
    const uint32_t  msgTimestampMs = (uint32_t) i + 1U;
    GlueCodeCanInjectionDetection_Add(msgTimestampMs, &ringbufferIndex, ringbuffer, items);

    // fill compare-buffer with the same data
    const size_t  index = (offset + i) % items;
    ringbufferExpect[index] = msgTimestampMs;

    // verify index
    assert_true(((index + 1U) % items) == ringbufferIndex);  // ringbufferIndex is the *next* usable index
    // verify contents
    assert_memory_equal(ringbuffer, ringbufferExpect, sizeof (ringbufferExpect));
  }

  // verify index
  assert_true(((offset + entries) % items) == ringbufferIndex);
  // verify contents
  assert_memory_equal(ringbuffer, ringbufferExpect, sizeof (ringbufferExpect));
}

// @brief  not enough items
static void test_canInjectionDetection_Add_02(void)
{
  uint32_t      ringbuffer[13U] = {0U};  // dummy
  const size_t  items = 1U;  // not enough items
  size_t        ringbufferIndex = 0U;  // dummy

  expect_function_call(__wrap_HlpFailure_EndlessLoop);
  GlueCodeCanInjectionDetection_Add(0U, &ringbufferIndex, ringbuffer, items);
}

// @brief  index out of range
static void test_canInjectionDetection_Add_03(void)
{
  uint32_t      ringbuffer[13U] = {0U};  // dummy
  const size_t  items = sizeof(ringbuffer)/sizeof(*ringbuffer);
  size_t        ringbufferIndex = items + 1U;  // index out of range

  expect_function_call(__wrap_HlpFailure_EndlessLoop);
#ifndef CMOCKA_DIAB
  // this may cause a runtime exception due to HlpFailure_EndlessLoop() returning and using an out-of-range ringbufferIndex
  GlueCodeCanInjectionDetection_Add(0U, &ringbufferIndex, ringbuffer, items);
#endif
}

// @brief  non-monotonic timestamps
static void test_canInjectionDetection_Add_04(void)
{
  uint32_t        ringbuffer[13U] = {0U};
  const size_t    items = sizeof(ringbuffer)/sizeof(*ringbuffer);
  size_t          ringbufferIndex = 0U;

  const uint32_t  msgTimestampMs = 1234U;  // some random timestamp

  GlueCodeCanInjectionDetection_Add(msgTimestampMs - 0U, &ringbufferIndex, ringbuffer, items);
  GlueCodeCanInjectionDetection_Add(msgTimestampMs - 0U, &ringbufferIndex, ringbuffer, items);  // same injected timestamp is allowed

  expect_function_call(__wrap_HlpFailure_EndlessLoop);
  GlueCodeCanInjectionDetection_Add(msgTimestampMs - 1U, &ringbufferIndex, ringbuffer, items);  // attempt to travel back in time
}

static void test_canInjectionDetection_Add(void** state)
{
  const size_t  items = 13U;  // some small random size

  // handpicked values
  test_canInjectionDetection_Add_01(items,         0U,    1U);
  test_canInjectionDetection_Add_01(items,         1U,    1U);
  test_canInjectionDetection_Add_01(items,         7U,    1U);
  test_canInjectionDetection_Add_01(items, items - 2U,    1U);
  test_canInjectionDetection_Add_01(items, items - 1U,    1U);

  // handpicked values
  test_canInjectionDetection_Add_01(items,         0U,    2U);
  test_canInjectionDetection_Add_01(items,         1U,    2U);
  test_canInjectionDetection_Add_01(items,         7U,    2U);
  test_canInjectionDetection_Add_01(items, items - 2U,    2U);
  test_canInjectionDetection_Add_01(items, items - 1U,    2U);

  // handpicked values
  test_canInjectionDetection_Add_01(items,         0U,    2U);
  test_canInjectionDetection_Add_01(items,         0U,    7U);
  test_canInjectionDetection_Add_01(items,         0U,   99U);
  test_canInjectionDetection_Add_01(items,         0U, items);

  // handpicked values
  test_canInjectionDetection_Add_01(items, items - 1U,    2U);
  test_canInjectionDetection_Add_01(items, items - 1U,    7U);
  test_canInjectionDetection_Add_01(items, items - 1U,   99U);
  test_canInjectionDetection_Add_01(items, items - 1U, items);

  // systematic test
  for ( size_t  offset = 0U; offset < items; ++offset )
  {
    for ( size_t  entries = 0U; entries < (2U * items); ++entries )  // includes a rollover of full buffersize
    {
      test_canInjectionDetection_Add_01(items, offset, entries);
    }
  }

  // error-tests
  test_canInjectionDetection_Add_02();
  test_canInjectionDetection_Add_03();
  test_canInjectionDetection_Add_04();

  (void)state;
}


int main(void)
{
  int  retval = 0;
  
#ifdef CMOCKA_DIAB
  putenv("CMOCKA_XML_FILE=src_common_gluecode_CanInjectionDetection.xml"); // environment variable for XML file when running on PPC
#endif

  const struct CMUnitTest  tests[] =
  {
    cmocka_unit_test(test_canInjectionDetection_Add),
    cmocka_unit_test(test_canInjectionDetection_Check),
  };

  cmocka_set_message_output(CM_OUTPUT_XML);

  retval = cmocka_run_group_tests_name("src_common_gluecode_CanInjectionDetection", tests, NULL, NULL);

#ifdef CMOCKA_DIAB
  read_xml_file("src_common_gluecode_CanInjectionDetection.xml"); // extract XML test results from file in RAM when running on PPC
#endif

  return retval;
}


extern void __wrap_HlpFailure_EndlessLoop(void)
{
  function_called();
}

extern uint32_t __wrap_LifetimeCounter_ToMs32(const uint64_t timeClk)
{
  return (uint32_t)(timeClk);
}

extern uint64_t __wrap_LifetimeCounter_Get(void)
{
  return (uint64_t) mock();
}

extern uint64_t __wrap_LifetimeCounter_MsToLifetimeCounter(const uint32_t timeMs)
{
  return (uint64_t)(timeMs);
}


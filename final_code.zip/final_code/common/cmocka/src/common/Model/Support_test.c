// *****************************************************************************
// **                _______   _________  _________   _______                 **
// **               (  ___  )  \__   __/  \__   __/  (  ____ \                **
// **               | (   ) |     ) (        ) (     | (    \/                **
// **               | |   | |     | |        | |     | (_____                 **
// **               | |   | |     | |        | |     (_____  )                **
// **               | |   | |     | |        | |           ) |                **
// **               | (___) |     | |     ___) (___  /\____) |                **
// **               (_______)     )_(     \_______/  \_______)                **
// **                                                                         **
// **                        Lead Design Center Berlin                        **
// **                                                                         **
// **   Copyright 2021 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **
// **                                                                         **
// *****************************************************************************
//!
//! @file
//!
//! @brief cmocka test file for src/common/Model/Support.c
//!
// *****************************************************************************
#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "Crc.h"

#include "Cfg/Self.h"
#include "Cfg/Scn.h"

#include "cmocka.h"

#include "Model/Support.h"
#include "Cfg/Crc.h"
#include "Cfg/MsgIds.h"
#include "Crypto/ATECC508.h"
#include "SwMon/Processes.h"
#include "Opb/Timestamp.h"
#include "Drv/inc/Drv_MC_RGM.h"
#include "Drv/inc/Drv_DebugCfg.h"
#include "Security/SMsgs.h"
#include "Scom/Sciopta/adc.h"

#include "NvmLocalFlashMisr_B.h"
#include "NvmSystemFloorTable_B.h"

#include <sciopta.msg>
#include "wrap/sciopta.h"


//! @brief wrapper function for HlpCrc32_Add()
extern void __wrap_HlpCrc32_Add(uint32_t *pSelf, const uint8_t *data, const uint32_t length);
//! @brief callback for real function of HlpCrc32_Add()
extern void __real_HlpCrc32_Add(uint32_t *pSelf, const uint8_t *data, const uint32_t length);


const char * const CfgProcNames_safetyProcess   = "/user/SafetyProcess";
const char * const CfgProcNames_securityProcess = "/user/SecurityProcess";
const char * const CfgProcNames_scomProc        = "/user/ScomProc";

//! @brief Without `extern` to prevent compiler warning from the gcc
//! @note
//!    warning: 'CfgSelf_self' initialized and declared 'extern' [enabled by default]
//!    Stackoverflow: https://stackoverflow.com/questions/4268589/warning-in-extern-declaration
const CfgSelf_Self_S CfgSelf_self = {
                                      .safetyNode  = SafetyNode_SPIT,
                                      .canNodeAddr = OpbNodeAddr_SPIT
                                    };

union sc_msg
{
  sc_msgid_t scmsgid;                  //!< Sciopta message ID
  adc_readConversionReply_t adcRead;   //!< ADC read message
  Security_Hsm_verifySignatureExternal_S hsmVerifySignatureExternal;  //!< crypto signature verification
  Security_Hsm_Status_S hsmStatus;     //!< crypto status
  sc_procNameGetMsgReply_t procName;
};

#define PID_UNKNOWN_PROC   ((sc_pid_t) 10)
#define PID_SCOM_PROC      ((sc_pid_t) 20)
#define PID_SAFETY_PROC    ((sc_pid_t) 40)
#define PID_SECURITY_PROC  ((sc_pid_t) 50)

//! @brief Without `extern` to prevent compiler warning from the gcc
//! @note
//!    warning: 'CfgScn_BoardScn' initialized and declared 'extern' [enabled by default]
//!    Stackoverflow: https://stackoverflow.com/questions/4268589/warning-in-extern-declaration
const union ScnType_Scn CfgScn_BoardScn =
{
  .part = { .country = "G", .releaseType = "00", .baseline = "00000", .releaseVersion = "123", .postfix = "     ", .terminator = "\0" }
  // required sizes:   "?"                 "??"              "?????"                    "???"             "?????"             DONT CHANGE
  //        example:   "G"                 "P1"              "12345"                    "AAA"             "+HL01"
};



// =======================================================================================
//! @brief Forward declarations
// =======================================================================================


static void HlpCrc32_Add_will_return(const uint32_t expectedLength, const uint8_t* const expectedBuffer, const size_t bufferSize);
static void CanSchedSrs_SetFilterBlocking_will_return(const CanSchedTypes_CanFilter_S* filterListExpected,
                                                      const size_t                     filterListLengthExpected,
                                                      const CanSchedTypes_Error_E      returnValue);


//! @brief Check correct handling of NULL pointers according to #ModelSupport_SerializeSystemFloorTable
//!
//! @param[in,out] state provided by CMOCKA, not used.
//!
//! @details
//!   It is verified that #HlpFailure_EndlessLoop is called in case a NULL pointer is provided
static void test_ModelSupport_SerializeSystemFloorTable_FailureHandlingPointer(void** state)
{
  NvmSystemFloorTable_B nvmSystemFloortable;
  memset(&nvmSystemFloortable, 0, sizeof(nvmSystemFloortable));
  uint8_t buffer[MODELSUPPORT_MAX_SIZE_FLOOR_TABLE_STREAM] = { 0 };

  expect_function_calls(__wrap_HlpFailure_EndlessLoop, 3);

  ModelSupport_SerializeSystemFloorTable(NULL, NULL);
  ModelSupport_SerializeSystemFloorTable(NULL, buffer);
  ModelSupport_SerializeSystemFloorTable(&nvmSystemFloortable, NULL);

  (void) state;
}

//! @brief Check correct handling of wrong content according to #ModelSupport_SerializeSystemFloorTable
//!
//! @param[in,out] state provided by CMOCKA, not used.
//!
//! @details
//!   It is verified that #HlpFailure_EndlessLoop is called in case wrong content is provided
static void test_ModelSupport_SerializeSystemFloorTable_FailureHandlingContent(void** state)
{
  NvmSystemFloorTable_B nvmSystemFloortable;
  memset(&nvmSystemFloortable, 0, sizeof(nvmSystemFloortable));
  uint8_t buffer[MODELSUPPORT_MAX_SIZE_FLOOR_TABLE_STREAM] = { 0 };
  size_t i;

  // Bottom landing is greater than top landing

  for (i = 0; i < UINT8_MAX; i++)
  {
    nvmSystemFloortable.TableStatus.BottomFloorNumber = i+1;
    nvmSystemFloortable.TableStatus.TopFloorNumber    = i;

    expect_function_call(__wrap_HlpFailure_EndlessLoop);
    ModelSupport_SerializeSystemFloorTable((NvmSystemFloorTable_B*) &nvmSystemFloortable, buffer);
  }

  // Amount of landings is to high
  for (i = 0; i <= (UINT8_MAX - MODELSUPPORT_MAX_AMOUNT_FLOORS - 1); i++)
  {
    nvmSystemFloortable.TableStatus.BottomFloorNumber = i;
    nvmSystemFloortable.TableStatus.TopFloorNumber    = i + MODELSUPPORT_MAX_AMOUNT_FLOORS + 1;

    expect_function_call(__wrap_HlpFailure_EndlessLoop);
    ModelSupport_SerializeSystemFloorTable((NvmSystemFloorTable_B*) &nvmSystemFloortable, buffer);
  }
  (void) state;
}

//! @brief Check serialization of bottom and top floor number
//!
//! @param[in] pNvmSystemFloortable is checked against an internal stored serialization according to the ICD
static void test_ModelSupport_SerializeSystemFloorTable_TopBottomFloorNumber()
{
  NvmSystemFloorTable_B nvmSystemFloortable;

  uint8_t buffer[MODELSUPPORT_MAX_SIZE_FLOOR_TABLE_STREAM] = { 0 };
  //   0    1    2    3    4    5    6    7
  const uint8_t expectedBuffer[] = {
     0x00,0x00,0x00,0x00,0x00,0x02,0x06,0x00,
     0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
     0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, // FloorConfig[0]
     0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, // FloorConfig[1]
     0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, // FloorConfig[2]
     0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, // FloorConfig[3]
     0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00  // FloorConfig[4]
  };

  memset(&nvmSystemFloortable, 0, sizeof(nvmSystemFloortable));

  nvmSystemFloortable.TableStatus.BottomFloorNumber = 2;
  nvmSystemFloortable.TableStatus.TopFloorNumber    = 6;

  ModelSupport_SerializeSystemFloorTable(&nvmSystemFloortable, buffer);

  assert_memory_equal(expectedBuffer, buffer, sizeof(expectedBuffer));
}

//! @brief Check serialization of revision index
//!
//! @param[in] pNvmSystemFloortable is checked against an internal stored serialization according to the ICD
static void test_ModelSupport_SerializeSystemFloorTable_RevisionIndex()
{
  NvmSystemFloorTable_B nvmSystemFloortable;

  uint8_t buffer[MODELSUPPORT_MAX_SIZE_FLOOR_TABLE_STREAM] = { 0 };
  //   0    1    2    3    4    5    6    7
  const uint8_t expectedBuffer[] = {
    0xDE,0xAD,0x00,0x00,0x00,0x00,0x00,0x00,
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  };

  memset(&nvmSystemFloortable, 0, sizeof(nvmSystemFloortable));

  nvmSystemFloortable.RevisionIndex = 0xDEAD;

  ModelSupport_SerializeSystemFloorTable(&nvmSystemFloortable, buffer);

  assert_memory_equal(expectedBuffer, buffer, sizeof(expectedBuffer));
}

//! @brief Check serialization of format version
//!
//! @param[in] pNvmSystemFloortable is checked against an internal stored serialization according to the ICD
static void test_ModelSupport_SerializeSystemFloorTable_FormatVersion()
{
  NvmSystemFloorTable_B nvmSystemFloortable;

  uint8_t buffer[MODELSUPPORT_MAX_SIZE_FLOOR_TABLE_STREAM] = { 0 };
  //  0    1    2    3    4    5    6    7
  const uint8_t expectedBuffer[] = {
    0x00,0x00,0x42,0x00,0x00,0x00,0x00,0x00,
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  };

  memset(&nvmSystemFloortable, 0, sizeof(nvmSystemFloortable));

  nvmSystemFloortable.FormatVersion = 0x42;

  ModelSupport_SerializeSystemFloorTable(&nvmSystemFloortable, buffer);

  assert_memory_equal(expectedBuffer, buffer, sizeof(expectedBuffer));
}

//! @brief Check serialization of table status information except bottom and top landing number
//!
//! @param[in] pNvmSystemFloortable is checked against an internal stored serialization according to the ICD
static void test_ModelSupport_SerializeSystemFloorTable_TableStatus()
{
  NvmSystemFloorTable_B nvmSystemFloortable;
  size_t i;
  uint8_t buffer[MODELSUPPORT_MAX_SIZE_FLOOR_TABLE_STREAM] = { 0 };
  uint8_t byte4;
  uint8_t byte7;

  //   0    1    2    3    4    5    6    7
  uint8_t expectedBuffer[] = {
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, // Nothing serialized, whole table status is created below
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  };

  memset(&nvmSystemFloortable, 0, sizeof(nvmSystemFloortable));

  for (i = 0; i <= UINT8_MAX; i++)
  {
    byte4 =  (uint8_t) i;
    byte7 = ((uint8_t) i) ^ 0xFF;

    expectedBuffer[4] = byte4;
    expectedBuffer[7] = byte7;

    nvmSystemFloortable.TableStatus.SafetyValid = (byte4 & 0x80) == 0x80;
    nvmSystemFloortable.TableStatus.LimitsValid = (byte4 & 0x40) == 0x40;
    nvmSystemFloortable.TableStatus.Accuracy    = (byte4 & 0x30) >> 4;

    nvmSystemFloortable.TableStatus.TableStatusReserved = ( byte4 & 0x0F);

    nvmSystemFloortable.TableStatus.Reserved = byte7;

    ModelSupport_SerializeSystemFloorTable(&nvmSystemFloortable, buffer);
    assert_memory_equal(expectedBuffer, buffer, sizeof(expectedBuffer));
  }
}

//! @brief Check serialization of car buffer and counter weight buffer related information
//!
//! @param[in] pNvmSystemFloortable is checked against an internal stored serialization according to the ICD
static void test_ModelSupport_SerializeSystemFloorTable_BufferPositition()
{
  NvmSystemFloorTable_B nvmSystemFloortable;

  uint8_t buffer[MODELSUPPORT_MAX_SIZE_FLOOR_TABLE_STREAM] = { 0 };
  //  0    1    2    3    4    5    6    7
  const uint8_t expectedBuffer[] = {
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    0xCC,0xDD,0xEE,0xAA,0x22,0x33,0x44,0x55,
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  };

  memset(&nvmSystemFloortable, 0, sizeof(nvmSystemFloortable));

  nvmSystemFloortable.CWTBufferPosition = 0xBBCCDDEE; // 24 bit position
  nvmSystemFloortable.CWTBufferReserved = 0xAA;
  nvmSystemFloortable.CarBufferPosition = 0x11223344; // 24 bit position
  nvmSystemFloortable.CarBufferReserved = 0x55;

  ModelSupport_SerializeSystemFloorTable(&nvmSystemFloortable, buffer);

  assert_memory_equal(expectedBuffer, buffer, sizeof(expectedBuffer));
}

//! @brief Check serialization of one landing
//!
//! @param[in] pNvmSystemFloortable is checked against an internal stored serialization according to the ICD
//!
//! @details
//!   This function checks if #test_ModelSupport_SerializeSystemFloorTable_CorrectSerialization serializes @p nvmSystemFloortable correctly
//!   regarding one landing with variable bottom.
//!
//!   It is also checked, that independent of bottom landing, the information regarding bottom landing, is always stored at the same place.
static void test_ModelSupport_SerializeSystemFloorTable_Floor0()
{
  NvmSystemFloorTable_B nvmSystemFloortable;
  uint8_t i;
  uint8_t bottomLanding;

  uint8_t buffer[MODELSUPPORT_MAX_SIZE_FLOOR_TABLE_STREAM] = { 0 };
  //  0    1    2    3    4    5    6    7
  uint8_t expectedBuffer[] = {
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    0x00,0x00,0x00,0x00,0x00,0xBB,0xCC,0xDD // Only the position is already serialized
  };

  for ( bottomLanding = 0; bottomLanding < UINT8_MAX; bottomLanding++)
  {
    memset(&nvmSystemFloortable, 0, sizeof(nvmSystemFloortable));

    expectedBuffer[5] = bottomLanding;
    nvmSystemFloortable.TableStatus.BottomFloorNumber = bottomLanding;
    // On purpose - This floor table describes only a hoistway with one landing
    expectedBuffer[6] = bottomLanding;
    nvmSystemFloortable.TableStatus.TopFloorNumber    = bottomLanding;

    for ( i=0; i < UINT8_MAX; i++)
    {
      // Every second step, mark as verified
      expectedBuffer[16] = ( i & 0x01) << 7;
      nvmSystemFloortable.FloorInfo[0].verified = (i & 0x01) == 0x01;

      // front and rear is different
      expectedBuffer[17] = i;
      nvmSystemFloortable.FloorInfo[0].frontDsSegs = i;
      expectedBuffer[18] = (i^0xFF);
      nvmSystemFloortable.FloorInfo[0].rearDsSegs  = (i^0xFF);

      expectedBuffer[20] = i;

      nvmSystemFloortable.FloorInfo[0].FloorFirstReserved1 = (i & 0x80) == 0x80;
      nvmSystemFloortable.FloorInfo[0].valid               = (i & 0x40) == 0x40;
      nvmSystemFloortable.FloorInfo[0].opening             = (i & 0x30) >> 4;
      nvmSystemFloortable.FloorInfo[0].FloorFirstReserved2 = (i & 0x08) == 0x08;
      nvmSystemFloortable.FloorInfo[0].clipValid           = (i & 0x04) == 0x04;
      nvmSystemFloortable.FloorInfo[0].clips               = (i & 0x03);

      nvmSystemFloortable.FloorInfo[0].position0p1mm = 0xAABBCCDD;

      ModelSupport_SerializeSystemFloorTable(&nvmSystemFloortable, buffer);

      assert_memory_equal(expectedBuffer, buffer, sizeof(expectedBuffer));
    }
  }

}

//! @brief Check serialization of more than one landing
//!
//! @param[in] pNvmSystemFloortable is checked against an internal stored serialization according to the ICD
//!
//! @details
//!   This function checks if #test_ModelSupport_SerializeSystemFloorTable_CorrectSerialization serializes @p nvmSystemFloortable correctly
//!   regarding all possible landings and possible combinations of landings by adapting bottom and top landing numbers.
//!
//!   For each landing, it is also checked that, like #test_ModelSupport_SerializeSystemFloorTable_Floor0, the serialization for each
//!   landing is done also as expected.
static void test_ModelSupport_SerializeSystemFloorTable_ManyFloors()
{
  NvmSystemFloorTable_B nvmSystemFloortable;
  uint8_t bottomLanding;
  uint8_t topLanding;
  uint8_t amountOfLanding;
  uint8_t floor;

  uint8_t buffer[MODELSUPPORT_MAX_SIZE_FLOOR_TABLE_STREAM] = { 0 };

  uint8_t expectedBuffer[MODELSUPPORT_MAX_SIZE_FLOOR_TABLE_STREAM] = { 0 };
  uint8_t offset;

  for (bottomLanding = 0; bottomLanding < UINT8_MAX; bottomLanding++)
  {
    // `topLanding < UINT8_MAX` prevents a wrap around
    for (topLanding = bottomLanding; topLanding < UINT8_MAX && topLanding < bottomLanding + MODELSUPPORT_MAX_AMOUNT_FLOORS; topLanding++)
    {
      memset(&nvmSystemFloortable, 0, sizeof(nvmSystemFloortable));
      memset(&expectedBuffer,      0, sizeof(expectedBuffer));
      memset(&buffer,              0, sizeof(buffer));

      expectedBuffer[5] = bottomLanding;
      expectedBuffer[6] = topLanding;

      nvmSystemFloortable.TableStatus.BottomFloorNumber = bottomLanding;
      nvmSystemFloortable.TableStatus.TopFloorNumber    = topLanding;

      amountOfLanding = topLanding - bottomLanding;

      for (floor = 0; floor < amountOfLanding; floor++)
      {
        offset = MODELSUPPORT_MIN_SIZE_TABLE_STREAM_WO_FLOORS+MODELSUPPORT_SIZE_OF_ONE_FLOOR_LANDING_INFO*floor;

        // Calculate a position based on all three indices to achieve a unique position for each landing
        // This would detect the fault, that a position from a landing @p n is also used for landing @p o.

        expectedBuffer[offset + 5] = ( (uint32_t) bottomLanding  << 16); // Position of upper  part of landing position according to ICD
        expectedBuffer[offset + 6] = ( (uint32_t) topLanding     <<  8); // Position of middle part of landing position according to ICD
        expectedBuffer[offset + 7] = ( (uint32_t) floor          <<  0); // Position of lower  part of landing position according to ICD

        nvmSystemFloortable.FloorInfo[floor].position0p1mm = expectedBuffer[offset + 5];
        nvmSystemFloortable.FloorInfo[floor].position0p1mm = expectedBuffer[offset + 6];
        nvmSystemFloortable.FloorInfo[floor].position0p1mm = expectedBuffer[offset + 7];

        // Because it doesn't require more effort, the same checks as already
        // used by #test_ModelSupport_SerializeSystemFloorTable_Floor0 are added

        // Every second step, mark as verified
        expectedBuffer[offset + 0] = ( floor & 0x01) << 7;
        nvmSystemFloortable.FloorInfo[floor].verified = (floor & 0x01) == 0x01;

        // front and rear is different
        expectedBuffer[offset + 1] = floor;
        nvmSystemFloortable.FloorInfo[floor].frontDsSegs = floor;
        expectedBuffer[offset + 2] = (floor^0xFF);
        nvmSystemFloortable.FloorInfo[floor].rearDsSegs  = (floor^0xFF);

        expectedBuffer[offset + 4] = floor;

        nvmSystemFloortable.FloorInfo[floor].FloorFirstReserved1 = (floor & 0x80) == 0x80;
        nvmSystemFloortable.FloorInfo[floor].valid               = (floor & 0x40) == 0x40;
        nvmSystemFloortable.FloorInfo[floor].opening             = (floor & 0x30) >> 4;
        nvmSystemFloortable.FloorInfo[floor].FloorFirstReserved2 = (floor & 0x08) == 0x08;
        nvmSystemFloortable.FloorInfo[floor].clipValid           = (floor & 0x04) == 0x04;
        nvmSystemFloortable.FloorInfo[floor].clips               = (floor & 0x03);
      }

      ModelSupport_SerializeSystemFloorTable(&nvmSystemFloortable, buffer);

      assert_memory_equal(expectedBuffer, buffer, sizeof(expectedBuffer));
    }
  }
}

//! @brief Checks the serialization that each bit is really recognized
//!
//! @param[in,out] state provided by CMOCKA, not used.
//!
//! @details
//!   This function checks the serialization for the maximum size of a floor table.
//!   A buffer with 0xFF is initialized and used as target for the serialization.
//!   It is expected that each bit, except for top floor number, are set to zero.
static void test_ModelSupport_SerializeSystemFloorTable_EveryBitIsRecognized(void** state)
{
  uint8_t targetBuffer[MODELSUPPORT_MAX_SIZE_FLOOR_TABLE_STREAM] = { 0 };
  const uint8_t expectedBuffer[MODELSUPPORT_MAX_SIZE_FLOOR_TABLE_STREAM] = {
      [6] = 23,
  };
  NvmSystemFloorTable_B nvmSystemFloortable;
  memset(&nvmSystemFloortable, 0, sizeof(nvmSystemFloortable));

  nvmSystemFloortable.TableStatus.TopFloorNumber = 23;

  memset(targetBuffer, 0xFF, sizeof(targetBuffer));

  ModelSupport_SerializeSystemFloorTable(&nvmSystemFloortable, targetBuffer);

  assert_memory_equal(expectedBuffer, targetBuffer, sizeof(expectedBuffer));
}

//! @brief Checks that the correct buffer size is used for CRC calculation
//!
//! @param[in,out] state provided by CMOCKA, not used.
//!
//! @details
//!   #ModelSupport_CalcCrc32SystemFloorTable allocates the buffer which
//!   is able to represent the maximum size of a floor table containing
//!   #MODELSUPPORT_MAX_AMOUNT_FLOORS different landings.
//!
//!   The same buffer is also used to only store a serialized floor table containing
//!   less than #MODELSUPPORT_MAX_AMOUNT_FLOORS different landings.
//!
//!   The test focus is to verify that according to the stored landings always the correct
//!   buffer size is provided to #ModelSupport_CalcCrc32Buf.
//!   There is no CRC32 calculated, which is realized by a stub of #HlpCrc32_Add.
//!   The stub #__wrap_HlpCrc32_Add is controlled by #HlpCrc32_Add_will_return.
static void test_ModelSupport_CalcCrc32SystemFloorTable_CorrectBufferSizeUsed(void** state)
{
  NvmSystemFloorTable_B nvmSystemFloortable;
  memset(&nvmSystemFloortable, 0, sizeof(nvmSystemFloortable));
  size_t bottomFloor;
  size_t topFloor;
  uint32_t amountOfLandings;
  // Simple tests for explanation of the following tests
  {

    nvmSystemFloortable.TableStatus.BottomFloorNumber = 0x00;
    nvmSystemFloortable.TableStatus.TopFloorNumber    = 0x00;
    amountOfLandings = nvmSystemFloortable.TableStatus.TopFloorNumber - nvmSystemFloortable.TableStatus.BottomFloorNumber + 1;
    HlpCrc32_Add_will_return(MODELSUPPORT_MIN_SIZE_TABLE_STREAM_WO_FLOORS + MODELSUPPORT_SIZE_OF_ONE_FLOOR_LANDING_INFO * amountOfLandings,NULL,0);
    ModelSupport_CalcCrc32SystemFloorTable(&nvmSystemFloortable);

    nvmSystemFloortable.TableStatus.BottomFloorNumber = 0x00;
    nvmSystemFloortable.TableStatus.TopFloorNumber = 0x01;
    amountOfLandings = nvmSystemFloortable.TableStatus.TopFloorNumber - nvmSystemFloortable.TableStatus.BottomFloorNumber + 1;
    HlpCrc32_Add_will_return(MODELSUPPORT_MIN_SIZE_TABLE_STREAM_WO_FLOORS + MODELSUPPORT_SIZE_OF_ONE_FLOOR_LANDING_INFO * amountOfLandings,NULL,0);
    ModelSupport_CalcCrc32SystemFloorTable(&nvmSystemFloortable);

    nvmSystemFloortable.TableStatus.BottomFloorNumber = 0x01;
    nvmSystemFloortable.TableStatus.TopFloorNumber    = 0x05;
    amountOfLandings = nvmSystemFloortable.TableStatus.TopFloorNumber - nvmSystemFloortable.TableStatus.BottomFloorNumber + 1;
    HlpCrc32_Add_will_return(MODELSUPPORT_MIN_SIZE_TABLE_STREAM_WO_FLOORS + MODELSUPPORT_SIZE_OF_ONE_FLOOR_LANDING_INFO * amountOfLandings,NULL,0);
    ModelSupport_CalcCrc32SystemFloorTable(&nvmSystemFloortable);
  }

  for (bottomFloor = 0; bottomFloor < (UINT8_MAX - MODELSUPPORT_MAX_AMOUNT_FLOORS - 1); bottomFloor++)
  {
    for (topFloor = bottomFloor; topFloor < (MODELSUPPORT_MAX_AMOUNT_FLOORS + bottomFloor); topFloor++)
    {
      amountOfLandings = topFloor - bottomFloor + 1;

      nvmSystemFloortable.TableStatus.BottomFloorNumber = bottomFloor;
      nvmSystemFloortable.TableStatus.TopFloorNumber    = topFloor;

      HlpCrc32_Add_will_return(MODELSUPPORT_MIN_SIZE_TABLE_STREAM_WO_FLOORS + MODELSUPPORT_SIZE_OF_ONE_FLOOR_LANDING_INFO * amountOfLandings,NULL,0);
      ModelSupport_CalcCrc32SystemFloorTable(&nvmSystemFloortable);
    }
  }

  (void) state;
}

//! @brief Checks that the correct CRC and correct serialized buffer is used
//!
//! @param[in,out] state provided by CMOCKA, not used.
//!
//! @details
//!   This checks that function works properly for an exemplary floor table regarding
//!     * Provided CRC32 is correct
//!     * Serialized data stream for CRC32 calculation is correct
static void test_ModelSupport_CalcCrc32SystemFloorTable_IntegrationTest(void** state)
{
  NvmSystemFloorTable_B nvmSystemFloortable;
  uint32_t crcReturned;
  const uint32_t crcExpected = 0xC06C5011;
  memset(&nvmSystemFloortable, 0, sizeof(nvmSystemFloortable));

  const uint8_t const expectedSerializedSystemFloorTable[] = {
   //  0    1    2    3    4    5    6    7
     0x58,0xAD,0x00,0x00,0x70,0x00,0x02,0x00,
     0x03,0x15,0x38,0x00,0x01,0x7A,0xE8,0x00,
     0x00,0x00,0x00,0x00,0x67,0x01,0x86,0xA0, // FloorConfig[0]
     0x00,0x00,0x00,0x00,0x67,0x01,0xE3,0x98, // FloorConfig[1]
     0x00,0x00,0x00,0x00,0x57,0x02,0x71,0x00, // FloorConfig[2]
  };

  nvmSystemFloortable.RevisionIndex =0x58AD;
  nvmSystemFloortable.TableStatus.LimitsValid = true;
  nvmSystemFloortable.TableStatus.Accuracy = 0x03;
  nvmSystemFloortable.TableStatus.TopFloorNumber = 2;

  nvmSystemFloortable.CWTBufferPosition = 0x031538;
  nvmSystemFloortable.CarBufferPosition = 0x017AE8;

  nvmSystemFloortable.FloorInfo[0].valid = true;
  nvmSystemFloortable.FloorInfo[0].opening = 2;
  nvmSystemFloortable.FloorInfo[0].clipValid = true;
  nvmSystemFloortable.FloorInfo[0].clips = 0x03;
  nvmSystemFloortable.FloorInfo[0].position0p1mm = 0x0186A0;

  nvmSystemFloortable.FloorInfo[1].valid = true;
  nvmSystemFloortable.FloorInfo[1].opening = 2;
  nvmSystemFloortable.FloorInfo[1].clipValid = true;
  nvmSystemFloortable.FloorInfo[1].clips = 0x03;
  nvmSystemFloortable.FloorInfo[1].position0p1mm = 0x01E398;

  nvmSystemFloortable.FloorInfo[2].valid = true;
  nvmSystemFloortable.FloorInfo[2].opening = 1;
  nvmSystemFloortable.FloorInfo[2].clipValid = true;
  nvmSystemFloortable.FloorInfo[2].clips = 0x03;
  nvmSystemFloortable.FloorInfo[2].position0p1mm = 0x027100;

  HlpCrc32_Add_will_return(
      MODELSUPPORT_MIN_SIZE_TABLE_STREAM_WO_FLOORS + MODELSUPPORT_SIZE_OF_ONE_FLOOR_LANDING_INFO * 3,
      expectedSerializedSystemFloorTable,
      sizeof(expectedSerializedSystemFloorTable)
    );
  crcReturned = ModelSupport_CalcCrc32SystemFloorTable(&nvmSystemFloortable);

  assert_int_equal(crcExpected, crcReturned);

}

//! @brief Check model wrapper for Hlp/Crc32
//!
//! @details
//!   1. Check if buffer with length = 1 and content  = 0 with uint32 is handled correctly
//!   2. Check if buffer with length > 1 and content != 0 with uint32 is handled correctly
//!     * The autogenerated c-code will provide a uint32 buffer
//!   3. Check if buffer with length > 1 and content != 0 with uint8  is handled correctly
//!     * To handle the interface accordingly
static void test_ModelSupport_CalcCrc32Buf(void** state)
{
  const uint8_t  sampleValue            = 0x00U;
  const uint32_t expectedCrcSampleValue = 0xD202EF8DUL;

  const uint32_t const sampleBuffer[]          = {0x42424242UL, 0x41414141UL, 0x42424242UL, 0x41414141UL};
  const uint32_t expectedCrcSampleBuffer = 0x3C49D595UL;

  const uint8_t const sampleBufferUint8[]            = {0xDEU, 0xEAU, 0xBEU, 0xEFU, 0x21U};
  const uint32_t expectedCrcSampleBufferUint8 = 0x136ABB1EUL;

  uint32_t calculatedCrc32;

  HlpCrc32_Add_will_return(sizeof(sampleValue), (const uint8_t*) &sampleValue, sizeof(sampleValue));
  calculatedCrc32 = ModelSupport_CalcCrc32Buf( (const uint8_t*) &sampleValue, 1);
  assert_int_equal(expectedCrcSampleValue, calculatedCrc32);

  HlpCrc32_Add_will_return(sizeof(sampleBuffer), (const uint8_t*) &sampleBuffer, sizeof(sampleBuffer));
  calculatedCrc32 = ModelSupport_CalcCrc32Buf((uint8_t*) sampleBuffer, sizeof(sampleBuffer));
  assert_int_equal(expectedCrcSampleBuffer, calculatedCrc32);

  HlpCrc32_Add_will_return(sizeof(sampleBufferUint8), (const uint8_t*) &sampleBufferUint8, sizeof(sampleBufferUint8));
  calculatedCrc32 = ModelSupport_CalcCrc32Buf((uint8_t*) sampleBufferUint8, sizeof(sampleBufferUint8));
  assert_int_equal(expectedCrcSampleBufferUint8, calculatedCrc32);

}
static void test_ModelSupport_CalcCrc32_calledByUnkownProc(void** state)
{
  uint32_t crc;
  //1. Called by Unknown Process

  expect_function_calls(__wrap___sc_procIdGet, 2);

  will_return(__wrap___sc_procIdGet, PID_SAFETY_PROC);
  will_return(__wrap___sc_procIdGet, PID_SCOM_PROC);

  will_return(__wrap_HlpProc_GetCurrentPid, PID_UNKNOWN_PROC);

  expect_function_call(__wrap_HlpFailure_EndlessLoop);
  expect_function_call(__wrap_Crc_Init);
  will_return(__wrap_Crc_Init, Crc_UNIT_0);

  crc = ModelSupport_CalcCrc32(0,0);
  assert_int_equal(crc, UINT32_MAX);

  (void) state;
}

static void test_ModelSupport_CalcCrc32_calledByScomProc(void** state)
{
  uint32_t crc;
  uint32_t usedCrc  = 42;
  uint32_t usedData = 40;

  will_return(__wrap_HlpProc_GetCurrentPid, PID_SCOM_PROC);

  expect_function_call(__wrap_Crc_Init);

  will_return(__wrap_Crc_Init, Crc_UNIT_1);

  crc = ModelSupport_CalcCrc32(0,0);
  assert_int_equal(crc, UINT32_MAX);

  will_return(__wrap_HlpProc_GetCurrentPid, PID_SCOM_PROC);

  will_return(__wrap_Crc_AddUint8, usedData);
  expect_function_call(__wrap_Crc_AddUint8);
  will_return(__wrap_Crc_Get, usedCrc);
  expect_function_call(__wrap_Crc_Get);
  crc = ModelSupport_CalcCrc32(1,usedData);
  assert_true(crc == usedCrc);

  (void) state;
}

static void test_ModelSupport_CalcCrc32_calledBySafetyProc(void** state)
{
  uint32_t crc;
  uint32_t usedCrc  = 42;
  uint32_t usedData = 40;

  will_return(__wrap_HlpProc_GetCurrentPid, PID_SAFETY_PROC);

  expect_function_call(__wrap_Crc_Init);

  will_return(__wrap_Crc_Init, Crc_UNIT_0);

  crc = ModelSupport_CalcCrc32(0,0);
  assert_int_equal(crc, UINT32_MAX);

  will_return(__wrap_HlpProc_GetCurrentPid, PID_SAFETY_PROC);

  will_return(__wrap_Crc_AddUint8, usedData);
  expect_function_call(__wrap_Crc_AddUint8);
  will_return(__wrap_Crc_Get, usedCrc);
  expect_function_call(__wrap_Crc_Get);
  crc = ModelSupport_CalcCrc32(1,usedData);
  assert_true(crc == usedCrc);

  (void) state;
}

//! @note For getting full coverage
static void test_ModelSupport_Integrity(void** state)
{

  expect_function_call(__wrap_SwMonSProc_Refresh);
  (void) ModelSupport_Integrity((sc_pid_t) 0, 0);
  (void) state;
}

//! @note For getting full coverage
static void test_ModelSupport_ResetBoard(void** state)
{

  sc_msgAlloc_will_return(INJECT_NO_ERROR);
  expect_function_call(__wrap_HlpProcVar_GetLogd);

  sc_msgTx_will_return(INJECT_NO_ERROR, NULL, 0, (sc_pid_t) 0);
  expect_function_call(__wrap___sc_msgTx);
  expect_function_call(__wrap_HlpMsg_AssertSentFatal_f);

  (void) ModelSupport_ResetBoard( (sc_pid_t) 0);
  (void) state;
}

//! @note For getting full coverage
static void test_ModelSupport_WriteCan(void** state)
{

  expect_function_call(__wrap_CanSchedSrs_SendFireAndForget);

  (void) ModelSupport_WriteCan( (sc_pid_t) 0, (CanSchedTypes_CanChannel_T)0, (const CanSchedTypes_CanMsg_S *) NULL);
  (void) state;
}

//! @note For getting full coverage
static void test_ModelSupport_ModelTimebaseToOpbTimestamp(void** state)
{
  OpbTimestamp_T optTime;
  expect_function_call(__wrap_OpbTimestamp_UsToOpb);

  optTime = ModelSupport_ModelTimebaseToOpbTimestamp(100, (OpbTimestamp_T) 0);
  assert_int_equal(optTime, 100*50);

  (void) state;
}

//! @note For getting full coverage
static void test_ModelSupport_CheckCrcCedesMsgCrc32Failed(void** state)
{
  const uint32_t crcExpected = 0x42;
  uint8_t crcNotCorrect;
  uint32_t i;
  uint32_t try;
  for (try = 0 ; try < 2; try++)
  {
    expect_function_call(__wrap_Crc_Init);
    for (i=0; i < 12; i++)
    {
      expect_function_call(__wrap_Crc_AddUint8);
      will_return(__wrap_Crc_AddUint8, 0);

    }
    expect_function_call(__wrap_Crc_Get);

    will_return(__wrap_Crc_Init, CFGCRC_UNIT_SAFETY_PROCESS);
    will_return(__wrap_Crc_Get, crcExpected + try);

    crcNotCorrect = ModelSupport_CheckCrcCedesMsgCrc32Failed(0,0,0,0,0,0,0,crcExpected);

    assert_int_equal(crcNotCorrect, 0 + try);

    (void) state;
  }
}

//! @note For getting full coverage
static void test_ModelSupport_ReadNvm(void** state)
{

  (void) ModelSupport_ReadNvm(0, NULL, (size_t) 0);

  expect_function_call(__wrap_EepromEProc_ReadData);
  (void) ModelSupport_ReadNvm(0, (uint8_t *) 1, (size_t) 0);
  (void) state;
}

//! @note For getting full coverage
static void test_ModelSupport_WriteNvm(void** state)
{

  (void) ModelSupport_WriteNvm(0, NULL, (size_t) 0);

  expect_function_call(__wrap_EepromEProc_WriteData);
  (void) ModelSupport_WriteNvm(0, (uint8_t *) 1, (size_t) 0);
  (void) state;
}

//! @note For getting full coverage
static void test_ModelSupport_ReadGpios(void** state)
{
  expect_function_call(__wrap_HlpFailure_EndlessLoopBusy);
  expect_function_call(__wrap_HlpProcVar_GetLogd);
  expect_function_call(__wrap_hlpio_readAllPortsIn);
  (void) ModelSupport_ReadGpios((sc_pid_t) 0, (hlpio_allPorts_t*) NULL);

  expect_function_call(__wrap_HlpProcVar_GetLogd);
  expect_function_call(__wrap_hlpio_readAllPortsIn);
  (void) ModelSupport_ReadGpios((sc_pid_t) 1, (hlpio_allPorts_t*) 1);
  (void) state;
}

//! @note For getting full coverage
static void test_ModelSupport_WriteGpios(void** state)
{
  expect_function_call(__wrap_HlpProcVar_GetLogd);
  expect_function_call(__wrap_hlpio_setAllPorts);
  (void) ModelSupport_WriteGpios((sc_pid_t) 0, (hlpio_allPorts_t*) NULL, (hlpio_allPorts_t*) NULL);
  (void) state;
}

//! @note For getting full coverage
static void test_ModelSupport_ReadCan(void** state)
{
  sc_msgRx_will_return(INJECT_NO_ERROR, (sc_msg_t) NULL);
  (void) ModelSupport_ReadCan();
  (void) state;
}

//! @note For getting full coverage
static void test_ModelSupport_ClearDesResetEscalation(void** state)
{
  expect_function_call(__wrap_Drv_MC_RGM_ClearDesResetEscalation);
  (void) ModelSupport_ClearDesResetEscalation();
  (void) state;
}

//! @note For getting full coverage
static void test_ModelSupport_UpdateFlashMisr(void** state)
{
  NvmLocalFlashMisr_B misr;

  expect_function_call(__wrap_Drv_EmbFlash_GetMisrSignature);
  (void) ModelSupport_UpdateFlashMisr(&misr);

  (void) ModelSupport_UpdateFlashMisr(NULL);

  (void) state;
}

//! @note For getting full coverage
static void test_ModelSupport_IsInDebugMode(void** state)
{
  bool retValue;
  uint32_t i;

  for (i=0; i < UINT16_MAX; i++)
  {
    will_return(__wrap_Dbg_getDebugState, (Dbg_Config_t) i);
    retValue = ModelSupport_IsInDebugMode();
    if ( (Dbg_Config_t) i == Dbg_CONFIG_ACTIVE)
    {
      assert_true(retValue);
    }
    else
    {
      assert_false(retValue);
    }
  }

  (void) state;
}


//! @brief  successful call to #ModelSupport_SetCanFilters()
static void test_ModelSupport_SetCanFilters_01(void)
{
  CanSchedTypes_Error_E  result;
  const CanSchedTypes_CanFilterIndex_T  nrExtended    = 1;
  const CanSchedTypes_CanFilterIndex_T  nrNonExtended = 1;
  const CanSchedTypes_CanFilter_S  filterList[] =
  {
    {
      .protocol = CanSchedTypes_PROTOCOL_EXTENDED,
      .mask     = 0x0000FFFF,
      .compare  = 0x0000BEEF
    },
    {
      .protocol = CanSchedTypes_PROTOCOL_STANDARD,
      .mask     = 0x07FF,
      .compare  = 0x0ABC
    }
  };

  const size_t  lengthOfFilterList = sizeof(filterList)/sizeof(*filterList);

  // First standard protocol filters
  CanSchedSrs_SetFilterBlocking_will_return(NULL, 0, CanSchedTypes_ERROR_SUCCESS);

  // Second extended protocol filters
  CanSchedSrs_SetFilterBlocking_will_return(NULL, 0, CanSchedTypes_ERROR_SUCCESS);

  result = ModelSupport_SetCanFilters((sc_pid_t)0,
                                      (CanSchedTypes_CanChannel_T)0,
                                      nrExtended,
                                      nrNonExtended,
                                      lengthOfFilterList,
                                      filterList);

  assert_true(CanSchedTypes_ERROR_SUCCESS == result);
}


//! @brief Split mixed protocol filterList properly into separate filterLists, one solely with standard protocol and the other solely with extended protocol
static void test_ModelSupport_SetCanFilters_02(void)
{
  CanSchedTypes_Error_E  result;
  const CanSchedTypes_CanFilterIndex_T  nrExtended    = 3;
  const CanSchedTypes_CanFilterIndex_T  nrNonExtended = 2;
  const CanSchedTypes_CanFilter_S  filterList[] =
  {
    {
      .protocol = CanSchedTypes_PROTOCOL_EXTENDED,
      .mask     = 0x0000FFFF,
      .compare  = 0x0000BEEF
    },
    {
      .protocol = CanSchedTypes_PROTOCOL_STANDARD,
      .mask     = 0x07FF,
      .compare  = 0x0ABC
    },
    {
      .protocol = CanSchedTypes_PROTOCOL_EXTENDED,
      .mask     = 0x000FFFFF,
      .compare  = 0x000BEEF2
    },
    {
      .protocol = CanSchedTypes_PROTOCOL_EXTENDED,
      .mask     = 0x00FFFFFF,
      .compare  = 0x000BEEF3
    },
    {
      .protocol = CanSchedTypes_PROTOCOL_STANDARD,
      .mask     = 0x07FF,
      .compare  = 0x0DEF
    }
  };
  const CanSchedTypes_CanFilter_S  filterListExpectedExtended[] =
  {
    {
      .protocol = CanSchedTypes_PROTOCOL_EXTENDED,
      .mask     = 0x0000FFFF,
      .compare  = 0x0000BEEF
    },
    {
      .protocol = CanSchedTypes_PROTOCOL_EXTENDED,
      .mask     = 0x000FFFFF,
      .compare  = 0x000BEEF2
    },
    {
      .protocol = CanSchedTypes_PROTOCOL_EXTENDED,
      .mask     = 0x00FFFFFF,
      .compare  = 0x000BEEF3
    }
  };
  const CanSchedTypes_CanFilter_S  filterListExpectedStandard[] =
  {
    {
      .protocol = CanSchedTypes_PROTOCOL_STANDARD,
      .mask     = 0x07FF,
      .compare  = 0x0ABC
    },
    {
      .protocol = CanSchedTypes_PROTOCOL_STANDARD,
      .mask     = 0x07FF,
      .compare  = 0x0DEF
    }
  };

  const size_t lengthOfFilterList = sizeof(filterList) / sizeof(*filterList);

  // First standard protocol filters
  CanSchedSrs_SetFilterBlocking_will_return(filterListExpectedStandard,
                                            sizeof(filterListExpectedStandard) / sizeof(filterListExpectedStandard[0]),
                                            CanSchedTypes_ERROR_SUCCESS);

  // Second extended protocol filters
  CanSchedSrs_SetFilterBlocking_will_return(filterListExpectedExtended,
                                            sizeof(filterListExpectedExtended) / sizeof(filterListExpectedExtended[0]),
                                            CanSchedTypes_ERROR_SUCCESS);

  result = ModelSupport_SetCanFilters((sc_pid_t)0,
                             (CanSchedTypes_CanChannel_T)0,
                             nrExtended,
                             nrNonExtended,
                             lengthOfFilterList,
                             filterList);

  assert_true(CanSchedTypes_ERROR_SUCCESS == result);
}


//! @brief  call of #CanSchedSrs_SetFilterBlocking() fails
static void test_ModelSupport_SetCanFilters_03(void)
{
  CanSchedTypes_Error_E  result;
  const CanSchedTypes_CanFilterIndex_T  nrExtended    = 0;
  const CanSchedTypes_CanFilterIndex_T  nrNonExtended = 1;
  const CanSchedTypes_CanFilter_S  filterList[] =
  {
    {
      .protocol = CanSchedTypes_PROTOCOL_STANDARD,
      .mask     = 0x07FF,
      .compare  = 0x0ABC
    }
  };
  const size_t  lengthOfFilterList = sizeof(filterList)/sizeof(*filterList);

  CanSchedSrs_SetFilterBlocking_will_return(NULL, 0, CanSchedTypes_ERROR_INTERNAL_SCMSG_TX);

  result = ModelSupport_SetCanFilters((sc_pid_t)0,
                             (CanSchedTypes_CanChannel_T)0,
                             nrExtended,
                             nrNonExtended,
                             lengthOfFilterList,
                             filterList);

  assert_true(CanSchedTypes_ERROR_INTERNAL_SCMSG_TX == result);
}

//! @brief  no inputs
static void test_ModelSupport_SetCanFilters_04(void)
{
  CanSchedTypes_Error_E  result;
  const CanSchedTypes_CanFilterIndex_T  nrExtended    = 0;  // none
  const CanSchedTypes_CanFilterIndex_T  nrNonExtended = 0;  // none
  const CanSchedTypes_CanFilter_S  filterList[1] = {{0}};
  const size_t  lengthOfFilterList = 0;  // empty list

  result = ModelSupport_SetCanFilters((sc_pid_t)0,
                             (CanSchedTypes_CanChannel_T)0,
                             nrExtended,
                             nrNonExtended,
                             lengthOfFilterList,
                             filterList);

  assert_true(CanSchedTypes_ERROR_SUCCESS == result);
}


static void test_ModelSupport_SetCanFilters(void** state)
{
  test_ModelSupport_SetCanFilters_01();
  test_ModelSupport_SetCanFilters_02();
  test_ModelSupport_SetCanFilters_03();
  test_ModelSupport_SetCanFilters_04();

  (void)state;
}


//! @brief  successful call of #ModelSupport_UpdateResetBufferElement()
static void test_ModelSupport_UpdateResetBufferElement_01(void)
{
  Rgm_ResetSources_U  resetSources = {0};
  NvmLocalResetBufferElement_B  elemEmpty = {0};
  NvmLocalResetBufferElement_B  elem = {0};

  will_return(__wrap_Drv_MC_RGM_GetSavedResetSources, &resetSources);
  expect_function_call(__wrap_Drv_MC_RGM_GetSavedResetSources);

  ModelSupport_UpdateResetBufferElement(&elem);
  assert_memory_equal(&elem, &elemEmpty, sizeof (elem));
}


//! @brief  #ModelSupport_UpdateResetBufferElement() test destructiveResetFccuFailureToReact
static void test_ModelSupport_UpdateResetBufferElement_02(void)
{
  Rgm_ResetSources_U  resetSources = {.B.destructiveResetFccuFailureToReact = true};
  NvmLocalResetBufferElement_B  elem;

  will_return(__wrap_Drv_MC_RGM_GetSavedResetSources, &resetSources);
  expect_function_call(__wrap_Drv_MC_RGM_GetSavedResetSources);

  ModelSupport_UpdateResetBufferElement(&elem);
  assert_true(elem.destructiveResetFccuFailureToReact);
}

//! @brief  #ModelSupport_UpdateResetBufferElement() test destructiveResetFlashInitFailure
static void test_ModelSupport_UpdateResetBufferElement_03(void)
{
  Rgm_ResetSources_U  resetSources = {.B.destructiveResetFlashInitFailure = true};
  NvmLocalResetBufferElement_B  elem;

  will_return(__wrap_Drv_MC_RGM_GetSavedResetSources, &resetSources);
  expect_function_call(__wrap_Drv_MC_RGM_GetSavedResetSources);

  ModelSupport_UpdateResetBufferElement(&elem);
  assert_true(elem.destructiveResetFlashInitFailure);
}

//! @brief  #ModelSupport_UpdateResetBufferElement() test destructiveResetFunctionalResetEscalation
static void test_ModelSupport_UpdateResetBufferElement_04(void)
{
  Rgm_ResetSources_U  resetSources = {.B.destructiveResetFunctionalResetEscalation = true};
  NvmLocalResetBufferElement_B  elem;

  will_return(__wrap_Drv_MC_RGM_GetSavedResetSources, &resetSources);
  expect_function_call(__wrap_Drv_MC_RGM_GetSavedResetSources);

  ModelSupport_UpdateResetBufferElement(&elem);
  assert_true(elem.destructiveResetFunctionalResetEscalation);
}

//! @brief  #ModelSupport_UpdateResetBufferElement() test destructiveResetPowerOn
static void test_ModelSupport_UpdateResetBufferElement_05(void)
{
  Rgm_ResetSources_U  resetSources = {.B.destructiveResetPowerOn = true};
  NvmLocalResetBufferElement_B  elem;

  will_return(__wrap_Drv_MC_RGM_GetSavedResetSources, &resetSources);
  expect_function_call(__wrap_Drv_MC_RGM_GetSavedResetSources);

  ModelSupport_UpdateResetBufferElement(&elem);
  assert_true(elem.destructiveResetPowerOn);
}

//! @brief  #ModelSupport_UpdateResetBufferElement() test destructiveResetSoftwareDestructiveReset
static void test_ModelSupport_UpdateResetBufferElement_06(void)
{
  Rgm_ResetSources_U  resetSources = {.B.destructiveResetSoftwareDestructiveReset = true};
  NvmLocalResetBufferElement_B  elem;

  will_return(__wrap_Drv_MC_RGM_GetSavedResetSources, &resetSources);
  expect_function_call(__wrap_Drv_MC_RGM_GetSavedResetSources);

  ModelSupport_UpdateResetBufferElement(&elem);
  assert_true(elem.destructiveResetSoftwareDestructiveReset);
}

//! @brief  #ModelSupport_UpdateResetBufferElement() test destructiveResetStcuUnrecoverableFault
static void test_ModelSupport_UpdateResetBufferElement_07(void)
{
  Rgm_ResetSources_U  resetSources = {.B.destructiveResetStcuUnrecoverableFault = true};
  NvmLocalResetBufferElement_B  elem;

  will_return(__wrap_Drv_MC_RGM_GetSavedResetSources, &resetSources);
  expect_function_call(__wrap_Drv_MC_RGM_GetSavedResetSources);

  ModelSupport_UpdateResetBufferElement(&elem);
  assert_true(elem.destructiveResetStcuUnrecoverableFault);
}

//! @brief  #ModelSupport_UpdateResetBufferElement() test destructiveResetTempSensorFailure
static void test_ModelSupport_UpdateResetBufferElement_08(void)
{
  Rgm_ResetSources_U  resetSources = {.B.destructiveResetTempSensorFailure = true};
  NvmLocalResetBufferElement_B  elem;

  will_return(__wrap_Drv_MC_RGM_GetSavedResetSources, &resetSources);
  expect_function_call(__wrap_Drv_MC_RGM_GetSavedResetSources);

  ModelSupport_UpdateResetBufferElement(&elem);
  assert_true(elem.destructiveResetTempSensorFailure);
}

//! @brief  #ModelSupport_UpdateResetBufferElement() test destructiveResetVoltageOutOfRange
static void test_ModelSupport_UpdateResetBufferElement_09(void)
{
  Rgm_ResetSources_U  resetSources = {.B.destructiveResetVoltageOutOfRange = true};
  NvmLocalResetBufferElement_B  elem;

  will_return(__wrap_Drv_MC_RGM_GetSavedResetSources, &resetSources);
  expect_function_call(__wrap_Drv_MC_RGM_GetSavedResetSources);

  ModelSupport_UpdateResetBufferElement(&elem);
  assert_true(elem.destructiveResetVoltageOutOfRange);
}

//! @brief  #ModelSupport_UpdateResetBufferElement() test functionalResetExternalReset
static void test_ModelSupport_UpdateResetBufferElement_10(void)
{
  Rgm_ResetSources_U  resetSources = {.B.functionalResetExternalReset = true};
  NvmLocalResetBufferElement_B  elem;

  will_return(__wrap_Drv_MC_RGM_GetSavedResetSources, &resetSources);
  expect_function_call(__wrap_Drv_MC_RGM_GetSavedResetSources);

  ModelSupport_UpdateResetBufferElement(&elem);
  assert_true(elem.functionalResetExternalReset);
}

//! @brief  #ModelSupport_UpdateResetBufferElement() test functionalResetFccuHardReaction
static void test_ModelSupport_UpdateResetBufferElement_11(void)
{
  Rgm_ResetSources_U  resetSources = {.B.functionalResetFccuHardReaction = true};
  NvmLocalResetBufferElement_B  elem;

  will_return(__wrap_Drv_MC_RGM_GetSavedResetSources, &resetSources);
  expect_function_call(__wrap_Drv_MC_RGM_GetSavedResetSources);

  ModelSupport_UpdateResetBufferElement(&elem);
  assert_true(elem.functionalResetFccuHardReaction);
}

//! @brief  #ModelSupport_UpdateResetBufferElement() test functionalResetFccuSoftReaction
static void test_ModelSupport_UpdateResetBufferElement_12(void)
{
  Rgm_ResetSources_U  resetSources = {.B.functionalResetFccuSoftReaction = true};
  NvmLocalResetBufferElement_B  elem;

  will_return(__wrap_Drv_MC_RGM_GetSavedResetSources, &resetSources);
  expect_function_call(__wrap_Drv_MC_RGM_GetSavedResetSources);

  ModelSupport_UpdateResetBufferElement(&elem);
  assert_true(elem.functionalResetFccuSoftReaction);
}

//! @brief  #ModelSupport_UpdateResetBufferElement() test functionalResetJtag
static void test_ModelSupport_UpdateResetBufferElement_13(void)
{
  Rgm_ResetSources_U  resetSources = {.B.functionalResetJtag = true};
  NvmLocalResetBufferElement_B  elem;

  will_return(__wrap_Drv_MC_RGM_GetSavedResetSources, &resetSources);
  expect_function_call(__wrap_Drv_MC_RGM_GetSavedResetSources);

  ModelSupport_UpdateResetBufferElement(&elem);
  assert_true(elem.functionalResetJtag);
}

//! @brief  #ModelSupport_UpdateResetBufferElement() test functionalResetSelfTestCompleted
static void test_ModelSupport_UpdateResetBufferElement_14(void)
{
  Rgm_ResetSources_U  resetSources = {.B.functionalResetSelfTestCompleted = true};
  NvmLocalResetBufferElement_B  elem;

  will_return(__wrap_Drv_MC_RGM_GetSavedResetSources, &resetSources);
  expect_function_call(__wrap_Drv_MC_RGM_GetSavedResetSources);

  ModelSupport_UpdateResetBufferElement(&elem);
  assert_true(elem.functionalResetSelfTestCompleted);
}

//! @brief  #ModelSupport_UpdateResetBufferElement() test functionalResetSoftwareFunctionalReset
static void test_ModelSupport_UpdateResetBufferElement_15(void)
{
  Rgm_ResetSources_U  resetSources = {.B.functionalResetSoftwareFunctionalReset = true};
  NvmLocalResetBufferElement_B  elem;

  will_return(__wrap_Drv_MC_RGM_GetSavedResetSources, &resetSources);
  expect_function_call(__wrap_Drv_MC_RGM_GetSavedResetSources);

  ModelSupport_UpdateResetBufferElement(&elem);
  assert_true(elem.functionalResetSoftwareFunctionalReset);
}

//! @brief  #ModelSupport_UpdateResetBufferElement() test functionalResetTempSensorFailure
static void test_ModelSupport_UpdateResetBufferElement_16(void)
{
  Rgm_ResetSources_U  resetSources = {.B.functionalResetTempSensorFailure = true};
  NvmLocalResetBufferElement_B  elem;

  will_return(__wrap_Drv_MC_RGM_GetSavedResetSources, &resetSources);
  expect_function_call(__wrap_Drv_MC_RGM_GetSavedResetSources);

  ModelSupport_UpdateResetBufferElement(&elem);
  assert_true(elem.functionalResetTempSensorFailure);
}

//! @brief  #ModelSupport_UpdateResetBufferElement() test functionalResetVoltageOutOfRange
static void test_ModelSupport_UpdateResetBufferElement_17(void)
{
  Rgm_ResetSources_U  resetSources = {.B.functionalResetVoltageOutOfRange = true};
  NvmLocalResetBufferElement_B  elem;

  will_return(__wrap_Drv_MC_RGM_GetSavedResetSources, &resetSources);
  expect_function_call(__wrap_Drv_MC_RGM_GetSavedResetSources);

  ModelSupport_UpdateResetBufferElement(&elem);
  assert_true(elem.functionalResetVoltageOutOfRange);
}

//! @brief  #ModelSupport_UpdateResetBufferElement() test NULL-pointer
static void test_ModelSupport_UpdateResetBufferElement_18(void)
{
  ModelSupport_UpdateResetBufferElement(NULL);
}

static void test_ModelSupport_UpdateResetBufferElement(void** state)
{
  test_ModelSupport_UpdateResetBufferElement_01();
  test_ModelSupport_UpdateResetBufferElement_02();
  test_ModelSupport_UpdateResetBufferElement_03();
  test_ModelSupport_UpdateResetBufferElement_04();
  test_ModelSupport_UpdateResetBufferElement_05();
  test_ModelSupport_UpdateResetBufferElement_06();
  test_ModelSupport_UpdateResetBufferElement_07();
  test_ModelSupport_UpdateResetBufferElement_08();
  test_ModelSupport_UpdateResetBufferElement_09();
  test_ModelSupport_UpdateResetBufferElement_10();
  test_ModelSupport_UpdateResetBufferElement_11();
  test_ModelSupport_UpdateResetBufferElement_12();
  test_ModelSupport_UpdateResetBufferElement_13();
  test_ModelSupport_UpdateResetBufferElement_14();
  test_ModelSupport_UpdateResetBufferElement_15();
  test_ModelSupport_UpdateResetBufferElement_16();
  test_ModelSupport_UpdateResetBufferElement_17();
  test_ModelSupport_UpdateResetBufferElement_18();

  (void)state;
}

//! @brief  successful call of #ModelSupport_GetPesScnData()
static void test_ModelSupport_GetPesScnData_01(void)
{
  uint8_t  CanNodeAddr = OpbNodeAddr_SPIT + 1;
  uint8_t  SafetyNode = SafetyNode_SPIT + 1;
  char     Scn[SCNTYPE_STR_LENGTH] = {0};

  ModelSupport_GetPesScnData(&CanNodeAddr, &SafetyNode, Scn, sizeof (Scn) - 1);

  assert_int_equal(CanNodeAddr, OpbNodeAddr_SPIT);
  assert_int_equal(SafetyNode, SafetyNode_SPIT);
  assert_memory_equal(Scn, "G0000000123     ", SCNTYPE_STR_LENGTH /*include zero-terminator*/);
}

//! @brief  #ModelSupport_GetPesScnData() called with bad length
static void test_ModelSupport_GetPesScnData_02(void)
{
  uint8_t  CanNodeAddr = OpbNodeAddr_SPIT + 1;
  uint8_t  SafetyNode = SafetyNode_SPIT + 1;
  char     Scn[SCNTYPE_STR_LENGTH] = {0};

  expect_function_call(__wrap_HlpFailure_EndlessLoop);

  ModelSupport_GetPesScnData(&CanNodeAddr, &SafetyNode, Scn, 0);
}

#if 0
//! @brief  #ModelSupport_GetPesScnData() called with pCanNodeAddr == NULL
//!
//! @note Can not yet be used to NULL exception. Function test has to be adapted.
static void test_ModelSupport_GetPesScnData_03(void)
{
//  uint8_t  CanNodeAddr = OpbNodeAddr_SPIT + 1;
  uint8_t  SafetyNode = SafetyNode_SPIT + 1;
  char     Scn[SCNTYPE_STR_LENGTH] = {0};

  expect_function_call(__wrap_HlpFailure_EndlessLoop);

  ModelSupport_GetPesScnData(NULL, &SafetyNode, Scn, sizeof (Scn) - 1);
}

//! @brief  #ModelSupport_GetPesScnData() called with pSafetyNode == NULL
//!
//! @note Can not yet be used to NULL exception. Function test has to be adapted.
static void test_ModelSupport_GetPesScnData_04(void)
{
  uint8_t  CanNodeAddr = OpbNodeAddr_SPIT + 1;
//  uint8_t  SafetyNode = SafetyNode_SPIT + 1;
  char     Scn[SCNTYPE_STR_LENGTH] = {0};

  expect_function_call(__wrap_HlpFailure_EndlessLoop);

  ModelSupport_GetPesScnData(&CanNodeAddr, NULL, Scn, sizeof (Scn) - 1);
}

//! @brief  #ModelSupport_GetPesScnData() called with pScn == NULL
//!
//! @note Can not yet be used to NULL exception. Function test has to be adapted.
static void test_ModelSupport_GetPesScnData_05(void)
{
  uint8_t  CanNodeAddr = OpbNodeAddr_SPIT + 1;
  uint8_t  SafetyNode = SafetyNode_SPIT + 1;
  char     Scn[SCNTYPE_STR_LENGTH] = {0};

  expect_function_call(__wrap_HlpFailure_EndlessLoop);

  ModelSupport_GetPesScnData(&CanNodeAddr, &SafetyNode, NULL, sizeof (Scn) - 1);
}
#endif


static void test_ModelSupport_GetPesScnData(void** state)
{
  test_ModelSupport_GetPesScnData_01();
  test_ModelSupport_GetPesScnData_02();
//  test_ModelSupport_GetPesScnData_03();  // not testable with current implementation of ModelSupport_GetPesScnData()
//  test_ModelSupport_GetPesScnData_04();  // not testable with current implementation of ModelSupport_GetPesScnData()
//  test_ModelSupport_GetPesScnData_05();  // not testable with current implementation of ModelSupport_GetPesScnData()

  (void)state;
}

//! @brief #ModelSupport_CanSafetyIntegrityReceiving check correct handling of return value
static void test_ModelSupport_CanSafetyIntegrityReceiving(void** state)
{
  will_return(__wrap_SafetyCanProtocol_Verify, true);
  assert_true(ModelSupport_CanSafetyIntegrityReceiving(NULL, NULL));

  will_return(__wrap_SafetyCanProtocol_Verify, false);
  assert_false(ModelSupport_CanSafetyIntegrityReceiving(NULL, NULL));

}

//! @brief #SafetyCanProtocol_WrapNodeOriented is just a simple wrapper, test only added to achieve 100% coverage
static void test_ModelSupport_CanSafetyIntegritySending(void** state)
{
  ModelSupport_CanSafetyIntegritySending(NULL, NULL);
}

//! @brief Check correct conversion by #ModelSupport_LtcToModelTimebase
//!
//! @note #usPerModelTimebaseTick is defined as 50
//!
//! @todo Export #usPerModelTimebaseTick as define
static void test_ModelSupport_LtcToModelTimebase(void** state)
{
  uint64_t lifetimeCounter[] = {0ULL, 50ULL, 49ULL, 51ULL, UINT32_MAX    , 61700ULL,  UINT64_MAX, ( (uint64_t) UINT32_MAX )*50+1, ((uint64_t) UINT32_MAX)*50 - 1};
  uint32_t expected_result[] = {0U  , 1U   , 0U   ,  1U  , UINT32_MAX/50 , 1234U,    0xEB851EB8U, UINT32_MAX,           UINT32_MAX-1};
  uint32_t is_result;
  size_t i;

  for (i = 0; i < sizeof(expected_result)/sizeof(expected_result[0]); i++)
  {
    is_result = ModelSupport_LtcToModelTimebase(lifetimeCounter[i]);

    if(expected_result[i] != is_result)
    {
      fail_msg("%" PRIX32 " != %" PRIX32 " at i == %u", expected_result[i], is_result, (uint32_t) i);
    }
  }
}


static void test_ModelSupport_CalcCrc16SystemFloorTable_01(void)
{
  const uint16_t  crcIn = 0;
  const uint8_t   data = 0;
  uint8_t   option;
  uint16_t  crc;

  will_return(__wrap_Crc_Init, Crc_UNIT_0);
  expect_function_call(__wrap_Crc_Init);
  option = 0;
  crc = ModelSupport_CalcCrc16SystemFloorTable(option, crcIn, data);
  assert_int_equal(crc, 0xFFFFU);

  will_return(__wrap_Crc_AddUint8, data);
  expect_function_call(__wrap_Crc_AddUint8);

  will_return(__wrap_Crc_Get, 0x1234U);
  expect_function_call(__wrap_Crc_Get);

  option = 1;
  crc = ModelSupport_CalcCrc16SystemFloorTable(option, crcIn, data);
  assert_int_equal(crc, 0x1234U);
}

static void test_ModelSupport_CalcCrc16SystemFloorTable(void** state)
{
  test_ModelSupport_CalcCrc16SystemFloorTable_01();

  (void)state;
}


static void test_ModelSupport_CalcCrc16_01(void)
{
  const uint8_t  data = 0;
  uint8_t   option;
  uint16_t  crc;

  will_return(__wrap_Crc_Init, Crc_UNIT_0);
  expect_function_call(__wrap_Crc_Init);
  option = 0;
  crc = ModelSupport_CalcCrc16(option, data);
  assert_int_equal(crc, 0);

  will_return(__wrap_Crc_AddUint8, data);
  expect_function_call(__wrap_Crc_AddUint8);

  will_return(__wrap_Crc_Get, 0x1234U);
  expect_function_call(__wrap_Crc_Get);

  option = 1;
  crc = ModelSupport_CalcCrc16(option, data);
  assert_int_equal(crc, 0x1234U);
}

static void test_ModelSupport_CalcCrc16(void** state)
{
  test_ModelSupport_CalcCrc16_01();

  (void)state;
}


static void test_ModelSupport_ReadAdcFree_01(void)
{
  sc_msgAlloc_will_return(INJECT_NO_ERROR);
  sc_msg_t  p = __wrap___sc_msgAlloc(sizeof (adc_readConversionReply_t), ADC_READ_CONVERSION_REPLY_MSG, 0, 0);

  expect_function_call(__wrap___sc_msgFree);
  ModelSupport_ReadAdcFree(&p);

  assert_true(NULL == p);
}

static void test_ModelSupport_ReadAdcFree(void** state)
{
  test_ModelSupport_ReadAdcFree_01();

  (void)state;
}


//! @brief  successful call of #ModelSupport_SndHsmRequest()
static void test_ModelSupport_SndHsmRequest_01(void)
{
  const GsmMsgAlias   msgName = GsmMsgAlias_HsmVerifySignatureExternalRequest_msg;
  const HsmRequest_B  hsmRequest =
  {
    .VerifySignatureExternalRequest.datasize      = 12,  // random value
    .VerifySignatureExternalRequest.signaturesize = ATECC_SIGNATURE_SIZE,
    .VerifySignatureExternalRequest.pubkeysize    = ATECC_PUB_KEY_SIZE,
  };
  const sc_pid_t  pid = PID_SECURITY_PROC;

  will_return(__wrap___sc_procIdGet, pid);
  expect_function_call(__wrap___sc_procIdGet);

  sc_msgAlloc_will_return(INJECT_NO_ERROR);
  sc_msg_t  p = __wrap___sc_msgAlloc(sizeof (struct Security_Hsm_VerifySignatureExternal), SECURITY_VERIFY_SIGNATURE_EXTERNAL_REQUEST_MSGID, SC_DEFAULT_POOL, SC_FATAL_IF_TMO);
  assert_true(p != NULL);
  will_return(__wrap_SecuritySProc_AllocVerifiySignatureExternalRequest, p);
  expect_function_call(__wrap_SecuritySProc_AllocVerifiySignatureExternalRequest);

  sc_msgTx_will_return(INJECT_NO_ERROR, p, sizeof (struct Security_Hsm_VerifySignatureExternal), pid);
  expect_function_call(__wrap___sc_msgTx);

  ModelSupport_SndHsmRequest(msgName, &hsmRequest);
}

//! @brief  #ModelSupport_SndHsmRequest() called with bad msgName
static void test_ModelSupport_SndHsmRequest_02(void)
{
  const GsmMsgAlias   msgName = GsmMsgAlias_CarShiftRegRequest_msg;
  const HsmRequest_B  hsmRequest =
  {
    .VerifySignatureExternalRequest.datasize      = 12,  // random value
    .VerifySignatureExternalRequest.signaturesize = ATECC_SIGNATURE_SIZE,
    .VerifySignatureExternalRequest.pubkeysize    = ATECC_PUB_KEY_SIZE,
  };

  ModelSupport_SndHsmRequest(msgName, &hsmRequest);
}

//! @brief  #SecuritySProc_AllocVerifiySignatureExternalRequest() fails
static void test_ModelSupport_SndHsmRequest_03(void)
{
  const GsmMsgAlias   msgName = GsmMsgAlias_HsmVerifySignatureExternalRequest_msg;
  const HsmRequest_B  hsmRequest =
  {
    .VerifySignatureExternalRequest.datasize      = 12,  // random value
    .VerifySignatureExternalRequest.signaturesize = ATECC_SIGNATURE_SIZE,
    .VerifySignatureExternalRequest.pubkeysize    = ATECC_PUB_KEY_SIZE,
  };
  const sc_pid_t  pid = PID_SECURITY_PROC;

  will_return(__wrap___sc_procIdGet, pid);
  expect_function_call(__wrap___sc_procIdGet);

  sc_msgAlloc_will_return(INJECT_KERNEL_EOUT_OF_MEMORY);
  sc_msg_t  p = __wrap___sc_msgAlloc(sizeof (struct Security_Hsm_VerifySignatureExternal), SECURITY_VERIFY_SIGNATURE_EXTERNAL_REQUEST_MSGID, SC_DEFAULT_POOL, SC_FATAL_IF_TMO);
  will_return(__wrap_SecuritySProc_AllocVerifiySignatureExternalRequest, p);
  expect_function_call(__wrap_SecuritySProc_AllocVerifiySignatureExternalRequest);

  ModelSupport_SndHsmRequest(msgName, &hsmRequest);
}

//! @brief  hsmRequest is NULL
static void test_ModelSupport_SndHsmRequest_04(void)
{
  const GsmMsgAlias   msgName = GsmMsgAlias_HsmVerifySignatureExternalRequest_msg;
  const sc_pid_t  pid = PID_SECURITY_PROC;

  will_return(__wrap___sc_procIdGet, pid);
  expect_function_call(__wrap___sc_procIdGet);

  sc_msgAlloc_will_return(INJECT_NO_ERROR);
  sc_msg_t  p = __wrap___sc_msgAlloc(sizeof (struct Security_Hsm_VerifySignatureExternal), SECURITY_VERIFY_SIGNATURE_EXTERNAL_REQUEST_MSGID, SC_DEFAULT_POOL, SC_FATAL_IF_TMO);
  will_return(__wrap_SecuritySProc_AllocVerifiySignatureExternalRequest, p);
  expect_function_call(__wrap_SecuritySProc_AllocVerifiySignatureExternalRequest);

  ModelSupport_SndHsmRequest(msgName, NULL);
}

static void test_ModelSupport_SndHsmRequest(void** state)
{
  test_ModelSupport_SndHsmRequest_01();
  test_ModelSupport_SndHsmRequest_02();
  test_ModelSupport_SndHsmRequest_03();
  test_ModelSupport_SndHsmRequest_04();

  (void)state;
}


static void test_ModelSupport_SndScMsg_01(void)
{
  const sc_pid_t  pid = PID_SECURITY_PROC;

  sc_msgAlloc_will_return(INJECT_NO_ERROR);
  sc_msg_t  p = __wrap___sc_msgAlloc(sizeof (struct Security_Hsm_VerifySignatureExternal), SECURITY_VERIFY_SIGNATURE_EXTERNAL_REQUEST_MSGID, SC_DEFAULT_POOL, SC_FATAL_IF_TMO);

  sc_msgTx_will_return(INJECT_NO_ERROR, p, sizeof (struct Security_Hsm_VerifySignatureExternal), pid);
  expect_function_call(__wrap___sc_msgTx);

  ModelSupport_SndScMsg(&p, pid);
}

#if 0
//! @brief  pScMsg is NULL
//!
//! @note Can not yet be used due to system not halted in #__wrap_HlpFailure_EndlessLoop(). Function #HlpFailure_EndlessLoop() has to be adapted.
static void test_ModelSupport_SndScMsg_02(void)
{
  const sc_pid_t  pid = PID_SECURITY_PROC;

  expect_function_call(__wrap_HlpFailure_EndlessLoop);

  ModelSupport_SndScMsg(NULL, pid);
}
#endif

//! @brief  __sc_msgTx() fails
static void test_ModelSupport_SndScMsg_03(void)
{
  const sc_pid_t  pid = PID_SECURITY_PROC;

  sc_msgAlloc_will_return(INJECT_NO_ERROR);
  sc_msg_t  p = __wrap___sc_msgAlloc(sizeof (struct Security_Hsm_VerifySignatureExternal), SECURITY_VERIFY_SIGNATURE_EXTERNAL_REQUEST_MSGID, SC_DEFAULT_POOL, SC_FATAL_IF_TMO);

  sc_msgTx_will_return(INJECT_KERNEL_EILL_PID, p, sizeof (struct Security_Hsm_VerifySignatureExternal), pid);
  expect_function_call(__wrap___sc_msgTx);

  expect_function_call(__wrap_HlpProcVar_GetLogd);
//  expect_function_call(__wrap_HlpMsg_AssertSent_f);  // @todo add #function_called() to #__wrap_HlpMsg_AssertSent_f() and adapt affected tests
  expect_function_call(__wrap_HlpFailure_EndlessLoopBusy);

  ModelSupport_SndScMsg(&p, pid);
}

static void test_ModelSupport_SndScMsg(void** state)
{
  test_ModelSupport_SndScMsg_01();
//  test_ModelSupport_SndScMsg_02();  // not testable with current implementation of ModelSupport_SndScMsg()
  test_ModelSupport_SndScMsg_03();

  (void)state;
}


//! @brief  helper-function for #test_ModelSupport_RcvScMsg()
static void test_ModelSupport_RcvScMsg_helper(const sc_pid_t sender, const bool endless, const InjectScioptaError_E errorAlloc, const InjectScioptaError_E errorRx)
{
  sc_msg_t  msg;
  sc_msg_t  msgRx;

  sc_msgAlloc_will_return(errorAlloc);
  msg = __wrap___sc_msgAlloc(sizeof (struct Security_Hsm_VerifySignatureExternal), SECURITY_VERIFY_SIGNATURE_EXTERNAL_REQUEST_MSGID, SC_DEFAULT_POOL, SC_FATAL_IF_TMO);

  if ( INJECT_KERNEL_EOUT_OF_MEMORY == errorAlloc )
  {
    assert_true (NULL == msg);
  }
  else
  {
    assert_true (NULL != msg);
  }

  sc_msgRx_will_return(errorRx, msg);
  msgRx = ModelSupport_RcvScMsg(SECURITY_VERIFY_SIGNATURE_EXTERNAL_REPLY_MSGID, sender, endless);

  if ( (INJECT_NO_ERROR == errorAlloc)  &&  (INJECT_NO_ERROR == errorRx) )
  {
    assert_true (NULL != msgRx);
  }
  else
  {
    assert_true (NULL == msgRx);
  }

  if ( NULL != msgRx )
  {
    // free message-memory
    expect_function_call(__wrap___sc_msgFree);
    __wrap___sc_msgFree(&msgRx);
  }
  assert_true(NULL == msgRx);
}

static void test_ModelSupport_RcvScMsg(void** state)
{
  const sc_pid_t              paramPid    [] = {PID_SECURITY_PROC, SC_ILLEGAL_PID};
  const bool                  paramEndless[] = {true, false};
  const InjectScioptaError_E  paramAlloc  [] = {INJECT_NO_ERROR, INJECT_KERNEL_EOUT_OF_MEMORY};
  const InjectScioptaError_E  paramRx     [] = {INJECT_NO_ERROR, INJECT_TIMEOUT};
  size_t  iPid, iEndless, iAlloc, iRx;

  for ( iPid = 0; iPid < sizeof(paramPid)/sizeof(*paramPid); ++iPid )
  {
    for ( iEndless = 0; iEndless < sizeof(paramEndless)/sizeof(*paramEndless); ++iEndless )
    {
      for ( iAlloc = 0; iAlloc < sizeof(paramAlloc)/sizeof(*paramAlloc); ++iAlloc )
      {
        for ( iRx = 0; iRx < sizeof(paramRx)/sizeof(*paramRx); ++iRx )
        {
          test_ModelSupport_RcvScMsg_helper(paramPid[iPid], paramEndless[iEndless], paramAlloc[iAlloc], paramRx[iRx]);
        }
      }
    }
  }

  (void)state;
}


//! @todo  improve implementation of #ModelSupport_ReadAdc()
static void test_ModelSupport_ReadAdc_01(void)
{
  const struct
  {
    const size_t  unit;
    const bool    msg;  // a message is expected
  } tests[] =
  {
#ifdef CNF_ADC0
    {  0, true },
#endif
#ifdef CNF_ADC1
    {  1, true },
#endif
#ifdef CNF_ADC2
    {  2, true },
#endif
#ifdef CNF_ADC3
    {  3, true },
#endif
    {  4, false},
    {  5, false},
    { 99, false},
    {255, false},
  };
  size_t    i;
  sc_msg_t  msg;

  for ( i = 0; i < sizeof(tests)/sizeof(*tests); ++i )
  {
    if ( true != tests[i].msg )
    {
      expect_function_call(__wrap_HlpFailure_EndlessLoopBusy);
    }
//    if ( true == tests[i].msg )  // @todo adapt #ModelSupport_ReadAdc(), message should not be allocated if #HlpFailure_EndlessLoopBusy() was entered
    {
      expect_function_call(__wrap_adc_readConversion);
    }
    msg = ModelSupport_ReadAdc(tests[i].unit);
    if ( true == tests[i].msg )
    {
      assert_true(NULL != msg);
    }
    else
    {
//      assert_true(NULL == msg);  // @todo adapt #ModelSupport_ReadAdc(), message should not be allocated if #HlpFailure_EndlessLoopBusy() was entered
    }

    // free message-memory
    if ( NULL != msg )
    {
      expect_function_call(__wrap___sc_msgFree);
      __wrap___sc_msgFree(&msg);
      assert_true(NULL == msg);
    }
  }
}

static void test_ModelSupport_ReadAdc(void** state)
{
  test_ModelSupport_ReadAdc_01();

  (void)state;
}


//! @brief  successful call of #ModelSupport_ReadAdcChannel()
static void test_ModelSupport_ReadAdcChannel_01(void)
{
  const uint16_t  resultDummy = 17;  // any value
  uint16_t  result;
  CanSchedTypes_CanChannel_T  channel;
  CanSchedTypes_CanChannel_T  channelMax = 0;
  sc_msg_t  msg;
  size_t    i;

#ifdef CNF_ADC0
  channelMax = 0;
#endif
#ifdef CNF_ADC1
  channelMax = 1;
#endif
#ifdef CNF_ADC2
  channelMax = 2;
#endif
#ifdef CNF_ADC3
  channelMax = 3;
#endif

  for ( channel = 0; channel <= channelMax; ++channel )  // include channelMax
  {
    sc_msgAlloc_will_return(INJECT_NO_ERROR);
    msg = __wrap___sc_msgAlloc(sizeof (adc_readConversionReply_t), ADC_READ_CONVERSION_MSG, SC_DEFAULT_POOL, SC_FATAL_IF_TMO);
    assert_true(NULL != msg);

    for ( i = 0; i <= channelMax; ++i )
    {
      msg->adcRead.chanMask |= (1U << i);
    }

    msg->adcRead.cdr[channel].B.CDATA = resultDummy;  // dummy ADC-value

    result = ModelSupport_ReadAdcChannel(&msg, channel);

    assert_true(resultDummy == result);  // check dummy ADC-value

    // free message-memory
    if ( NULL != msg )
    {
      expect_function_call(__wrap___sc_msgFree);
      __wrap___sc_msgFree(&msg);
      assert_true(NULL == msg);
    }
  }
}

//! @brief  channel exceeds msg->adcRead.cdr[channel]
static void test_ModelSupport_ReadAdcChannel_02(void)
{
  const uint16_t  resultDefault = 0;  // default zero-value
  uint16_t  result;
  sc_msg_t  msg;

  sc_msgAlloc_will_return(INJECT_NO_ERROR);
  msg = __wrap___sc_msgAlloc(sizeof (adc_readConversionReply_t), ADC_READ_CONVERSION_MSG, SC_DEFAULT_POOL, SC_FATAL_IF_TMO);
  assert_true(NULL != msg);

  const CanSchedTypes_CanChannel_T  channel = sizeof(msg->adcRead.cdr)/sizeof(*msg->adcRead.cdr);  // exceed array

  msg->adcRead.chanMask |= ~(uint32_t)0U;  // allow every possible channel

  expect_function_call(__wrap_HlpFailure_EndlessLoopBusy);

  result = ModelSupport_ReadAdcChannel(&msg, channel);

  assert_true(resultDefault == result);  // check default ADC-value

  // free message-memory
  if ( NULL != msg )
  {
    expect_function_call(__wrap___sc_msgFree);
    __wrap___sc_msgFree(&msg);
    assert_true(NULL == msg);
  }
}

//! @brief  mask is not set for channel
static void test_ModelSupport_ReadAdcChannel_03(void)
{
  const uint16_t  resultDefault = 0;  // default zero-value
  CanSchedTypes_CanChannel_T  channel;
  CanSchedTypes_CanChannel_T  channelMax = 0;
  uint16_t  result;
  sc_msg_t  msg;

#ifdef CNF_ADC0
  channelMax = 0;
#endif
#ifdef CNF_ADC1
  channelMax = 1;
#endif
#ifdef CNF_ADC2
  channelMax = 2;
#endif
#ifdef CNF_ADC3
  channelMax = 3;
#endif

  for ( channel = 0; channel <= channelMax; ++channel )  // include channelMax
  {
    sc_msgAlloc_will_return(INJECT_NO_ERROR);
    msg = __wrap___sc_msgAlloc(sizeof (adc_readConversionReply_t), ADC_READ_CONVERSION_MSG, SC_DEFAULT_POOL, SC_FATAL_IF_TMO);
    assert_true(NULL != msg);

    msg->adcRead.chanMask |= ~(uint32_t)0U;  // allow everything ...
    msg->adcRead.chanMask &= ~(uint32_t)(1U << channel);  // ... except the given channel

    expect_function_call(__wrap_HlpFailure_EndlessLoopBusy);

    result = ModelSupport_ReadAdcChannel(&msg, channel);

    assert_true(resultDefault == result);  // check default ADC-value

    // free message-memory
    if ( NULL != msg )
    {
      expect_function_call(__wrap___sc_msgFree);
      __wrap___sc_msgFree(&msg);
      assert_true(NULL == msg);
    }
  }
}

//! @brief  bad message
static void test_ModelSupport_ReadAdcChannel_04(void)
{
  const CanSchedTypes_CanChannel_T  channel = 0;
  const uint16_t  resultDefault = 0;  // default zero-value
  uint16_t  result;

  result = ModelSupport_ReadAdcChannel(NULL, channel);

  assert_true(resultDefault == result);  // check default ADC-value
}

//! @brief  bad message contents
static void test_ModelSupport_ReadAdcChannel_05(void)
{
  const CanSchedTypes_CanChannel_T  channel = 0;
  const uint16_t  resultDefault = 0;  // default zero-value
  uint16_t  result;
  sc_msg_t  msg = NULL;

  result = ModelSupport_ReadAdcChannel(&msg, channel);

  assert_true(resultDefault == result);  // check default ADC-value
}

static void test_ModelSupport_ReadAdcChannel(void** state)
{
  test_ModelSupport_ReadAdcChannel_01();
  test_ModelSupport_ReadAdcChannel_02();
  test_ModelSupport_ReadAdcChannel_03();
  test_ModelSupport_ReadAdcChannel_04();
  test_ModelSupport_ReadAdcChannel_05();

  (void)state;
}


int main(void)
{

    int retval = 0;
    
#ifdef CMOCKA_DIAB
    putenv("CMOCKA_XML_FILE=src_common_model_Support.xml"); // environment variable for XML file when running on PPC
#endif

    const struct CMUnitTest tests[] =
    {
        cmocka_unit_test(test_ModelSupport_SerializeSystemFloorTable_FailureHandlingPointer),
        cmocka_unit_test(test_ModelSupport_SerializeSystemFloorTable_FailureHandlingContent),
        cmocka_unit_test(test_ModelSupport_SerializeSystemFloorTable_BufferPositition),
        cmocka_unit_test(test_ModelSupport_SerializeSystemFloorTable_ManyFloors),
        cmocka_unit_test(test_ModelSupport_SerializeSystemFloorTable_Floor0),
        cmocka_unit_test(test_ModelSupport_SerializeSystemFloorTable_FormatVersion),
        cmocka_unit_test(test_ModelSupport_SerializeSystemFloorTable_RevisionIndex),
        cmocka_unit_test(test_ModelSupport_SerializeSystemFloorTable_TableStatus),
        cmocka_unit_test(test_ModelSupport_SerializeSystemFloorTable_TopBottomFloorNumber),
        cmocka_unit_test(test_ModelSupport_SerializeSystemFloorTable_EveryBitIsRecognized),
        cmocka_unit_test(test_ModelSupport_CalcCrc32SystemFloorTable_CorrectBufferSizeUsed),
        cmocka_unit_test(test_ModelSupport_CalcCrc32SystemFloorTable_IntegrationTest),
        cmocka_unit_test(test_ModelSupport_CalcCrc32Buf),
        cmocka_unit_test(test_ModelSupport_CalcCrc32_calledByUnkownProc),
        cmocka_unit_test(test_ModelSupport_CalcCrc32_calledByScomProc),
        cmocka_unit_test(test_ModelSupport_CalcCrc32_calledBySafetyProc),
        cmocka_unit_test(test_ModelSupport_Integrity),
        cmocka_unit_test(test_ModelSupport_ResetBoard),
        cmocka_unit_test(test_ModelSupport_WriteCan),
        cmocka_unit_test(test_ModelSupport_ModelTimebaseToOpbTimestamp),
        cmocka_unit_test(test_ModelSupport_CheckCrcCedesMsgCrc32Failed),
        cmocka_unit_test(test_ModelSupport_ReadNvm),
        cmocka_unit_test(test_ModelSupport_WriteNvm),
        cmocka_unit_test(test_ModelSupport_ReadGpios),
        cmocka_unit_test(test_ModelSupport_WriteGpios),
        cmocka_unit_test(test_ModelSupport_ReadCan),
        cmocka_unit_test(test_ModelSupport_ClearDesResetEscalation),
        cmocka_unit_test(test_ModelSupport_UpdateFlashMisr),
        cmocka_unit_test(test_ModelSupport_IsInDebugMode),
        cmocka_unit_test(test_ModelSupport_SetCanFilters),
        cmocka_unit_test(test_ModelSupport_UpdateResetBufferElement),
        cmocka_unit_test(test_ModelSupport_GetPesScnData),
        cmocka_unit_test(test_ModelSupport_CanSafetyIntegrityReceiving),
        cmocka_unit_test(test_ModelSupport_CanSafetyIntegritySending),
        cmocka_unit_test(test_ModelSupport_LtcToModelTimebase),
        cmocka_unit_test(test_ModelSupport_CalcCrc16SystemFloorTable),
        cmocka_unit_test(test_ModelSupport_CalcCrc16),
        cmocka_unit_test(test_ModelSupport_ReadAdcFree),
        cmocka_unit_test(test_ModelSupport_SndHsmRequest),
        cmocka_unit_test(test_ModelSupport_SndScMsg),
        cmocka_unit_test(test_ModelSupport_RcvScMsg),
        cmocka_unit_test(test_ModelSupport_ReadAdc),
        cmocka_unit_test(test_ModelSupport_ReadAdcChannel),
    };

    cmocka_set_message_output(CM_OUTPUT_XML);

    retval =  cmocka_run_group_tests_name("src_common_model_Support", tests, NULL, NULL);
    
#ifdef CMOCKA_DIAB
    read_xml_file("src_common_model_Support.xml"); // extract XML test results from file in RAM when running on PPC
#endif

    return retval;
}

void __wrap_Crc_Init(
    const Crc_Unit_E cu, const Crc_Type_E ct,
    const uint8_t sw, const uint8_t swby, const uint8_t swbi, const uint8_t inv,
    const uint32_t seed
  )
{
  Crc_Unit_E expected_value = (Crc_Unit_E) mock();
  assert_true(expected_value == cu);
  function_called();
}

void __wrap_Crc_AddUint8(const Crc_Unit_E cu, const uint8_t byte)
{
  uint8_t expected_value = (uint8_t) mock();
  assert_true(expected_value == byte);
  function_called();
}

uint32_t __wrap_Crc_Get(const Crc_Unit_E c)
{
  function_called();
  return (uint32_t) mock();
}

void __wrap_kprintf()
{

}

extern uint32_t  __wrap_EepromEProc_ReadData(uint8_t id,  uint8_t * pBuffer, size_t bufferSize, uint32_t * pError)
{
  function_called();
  return 0;
}

extern void __wrap_EepromEProc_WriteData(uint8_t id, const uint8_t * pBuffer, size_t bufferSize, uint32_t * pError)
{
  function_called();
}

extern void __wrap_SwMonSProc_Refresh(SwMonProcesses_ProcessId_E processID, uint32_t flowPointNo)
{
  function_called();
}
extern CanSchedTypes_Error_E __wrap_CanSchedSrs_SendFireAndForget(sc_pid_t                       canSchedPid,
                                                           CanSchedTypes_CanChannel_T     channel,
                                                           const CanSchedTypes_CanMsg_S * pCanMsg)
{
  function_called();
  return 0;
}

extern bool __wrap_SafetyCanProtocol_Verify(const CanSchedTypes_CanMsg_S * const msg,
                              uint8_t * const pPreviousCounter)
{
  return (bool) mock();
}

extern bool __wrap_SafetyCanProtocol_WrapNodeOriented(CanSchedTypes_CanMsg_S * const msg,
                                        uint8_t * const pSequenceCounter)
{
  return 0;
}

extern uint64_t __wrap_LifetimeCounter_ToUs64(const uint64_t timeClk)
{
  return timeClk;
}

extern OpbTimestamp_T __wrap_OpbTimestamp_UsToOpb(uint64_t us, OpbTimestamp_T offset)
{
  function_called();
  return offset + us;
}

sc_msg_t __wrap_adc_readConversion (int unit)
{
  function_called();

  bool      valid = false;
  sc_msg_t  p = NULL;

#ifdef CNF_ADC0
  valid = true;
#endif
#ifdef CNF_ADC1
  valid = true;
#endif
#ifdef CNF_ADC2
  valid = true;
#endif
#ifdef CNF_ADC3
  valid = true;
#endif

  if ( valid )
  {
    sc_msgAlloc_will_return(INJECT_NO_ERROR);
    p = __wrap___sc_msgAlloc(sizeof (adc_readConversionReply_t), ADC_READ_CONVERSION_REPLY_MSG, SC_DEFAULT_POOL, SC_FATAL_IF_TMO);
  }

  return p;
}


static void CanSchedSrs_SetFilterBlocking_will_return(const CanSchedTypes_CanFilter_S* filterListExpected,
                                                      const size_t                     filterListLengthExpected,
                                                      const CanSchedTypes_Error_E      returnValue)
{
  will_return(__wrap_CanSchedSrs_SetFilterBlocking, filterListExpected);
  will_return(__wrap_CanSchedSrs_SetFilterBlocking, filterListLengthExpected);
  will_return(__wrap_CanSchedSrs_SetFilterBlocking, returnValue);
  expect_function_call(__wrap_CanSchedSrs_SetFilterBlocking);
}


CanSchedTypes_Error_E __wrap_CanSchedSrs_SetFilterBlocking(sc_pid_t                          canSchedPid,
                                                           CanSchedTypes_CanChannel_T        channel,
                                                           CanSchedTypes_CanFilterIndex_T    filterIndex,
                                                           size_t                            filterListLength,
                                                           const CanSchedTypes_CanFilter_S * pFilterList)
{
  CanSchedTypes_CanFilter_S *filterListExpected      = (CanSchedTypes_CanFilter_S*)mock();
  size_t                    filterListLengthExpected = (size_t)mock();
  CanSchedTypes_Error_E     returnValue              = (CanSchedTypes_Error_E)mock();

  if (filterListExpected != NULL)
  {
    // Verify the filterListLength
    assert_true(filterListLength == filterListLengthExpected);

    // Verify the filterList contents
    size_t i;
    for (i = 0; i < filterListLengthExpected; i++)
    {
      assert_true(pFilterList[i].compare  == filterListExpected[i].compare);
      assert_true(pFilterList[i].mask     == filterListExpected[i].mask);
      assert_true(pFilterList[i].protocol == filterListExpected[i].protocol);
    }
  }

  function_called();

  return returnValue;
}

extern sc_msg_t __wrap_SecuritySProc_AllocVerifiySignatureExternalRequest(sc_poolid_t pool, sc_ticks_t tmo)
{
  function_called();

  return (sc_msg_t) mock();
}

extern Rgm_ResetSources_U __wrap_Drv_MC_RGM_GetSavedResetSources(void)
{
  function_called();

  const Rgm_ResetSources_U* const  p = (const Rgm_ResetSources_U*) mock();
  Rgm_ResetSources_U  resetSources = *p;
  return resetSources;
}

extern void __wrap_Drv_MC_RGM_ClearDesResetEscalation(void)
{
  function_called();
}

void __wrap_Drv_EmbFlash_GetMisrSignature(uint32_t * signature)
{
  function_called();
}

Dbg_Config_t __wrap_Dbg_getDebugState(void)
{
  return (Dbg_Config_t) mock();
}

//! @brief Helper for #__wrap_HlpCrc32_Add
//!
//! @param[in] expectedLength
//! @param[in] expectedBuffer
//! @param[in] bufferSize
//!
//! If @p expectedLength is greater than zero, #__wrap_HlpCrc32_Add enables the assert that @p expectedLength equals the parameter @p length
//! If @p expectedLength is zero, #__wrap_HlpCrc32_Add doesn't check the parameter @p length.
//! If @p bufferSize is greater than zero, #__wrap_HlpCrc32_Add enables the assert that @p expectedBuffer has the same content as the parameter @p data.
//! If @p bufferSize is zero, #__wrap_HlpCrc32_Add doesn't check the parameter @p data.
static void HlpCrc32_Add_will_return(const uint32_t expectedLength, const uint8_t* const expectedBuffer, const size_t bufferSize)
{
  will_return(__wrap_HlpCrc32_Add, expectedLength);
  will_return(__wrap_HlpCrc32_Add, expectedBuffer);
  will_return(__wrap_HlpCrc32_Add, bufferSize);
}


//!  @brief Wrapper for HlpCrc32_Add
//!
//!  @details
//!   For correct mocking, see sc_msgAlloc_will_return for details.
//!
//!   This wrapped function will forward @p pSelf, @p data and @p length
//!   to the original function #HlpCrc32_Add.
void __wrap_HlpCrc32_Add(uint32_t *pSelf, const uint8_t *data, const uint32_t length)
{
  const uint32_t expectedLength = (const uint32_t) mock();
  const uint8_t* expectedBuffer = (const uint8_t* const) mock();
  const size_t   bufferSize     = (const size_t)   mock();

  if (expectedLength > 0)
  {
    assert_int_equal(expectedLength, length);
  }

  if (bufferSize > 0)
  {
    assert_non_null(expectedBuffer);
    assert_memory_equal(data, expectedBuffer, bufferSize);
  }

  assert_non_null(data);

#ifndef CMOCKA_DIAB
  __real_HlpCrc32_Add(pSelf, data, length);
#else
  //no Diab support for __real_ :(
#endif
}


#!/bin/bash
STUBS+=("LifetimeCounter_Get")

STUBS+=("__sc_msgRx")
STUBS+=("__sc_msgFree")

STUBS+=("HlpMsg_AssertSentFatal_f")
STUBS+=("SwMonSProc_Refresh")
STUBS+=("__sc_msgAlloc")
STUBS+=("HlpProcVar_GetLogd")
STUBS+=("HlpFailure_EndlessLoopBusy")

STUBS+=("hlpio_readAllPortsIn")
STUBS+=("hlpio_setAllPorts")
STUBS+=("CanSchedSrs_SendFireAndForget")
STUBS+=("SafetyCanProtocol_Verify")

STUBS+=("LifetimeCounter_ToUs64")
STUBS+=("OpbTimestamp_UsToOpb")

STUBS+=("CanSchedSrs_SetFilterBlocking")
STUBS+=("Crc_Init")
STUBS+=("Crc_AddUint8")
STUBS+=("Crc_Get")
STUBS+=("kprintf")

STUBS+=("__sc_msgTx")
STUBS+=("__sc_procNameGet")
STUBS+=("__sc_procIdGet")
STUBS+=("SafetyCanProtocol_WrapNodeOriented")
STUBS+=("adc_readConversion")
STUBS+=("SecuritySProc_AllocVerifiySignatureExternalRequest")
STUBS+=("EepromEProc_ReadData")
STUBS+=("EepromEProc_WriteData")
STUBS+=("Drv_MC_RGM_GetSavedResetSources")
STUBS+=("Drv_MC_RGM_ClearDesResetEscalation")
STUBS+=("Drv_EmbFlash_GetMisrSignature")
STUBS+=("Dbg_getDebugState")
STUBS+=("HlpFailure_EndlessLoop")
STUBS+=("HlpMsg_AssertSent_f")
STUBS+=("HlpProc_GetCurrentPid")
STUBS+=("HlpCrc32_Add")

STUB_WRAPS=${STUBS[@]/#/\-Wl,$2} # Diab wrap option syntax is different than GNU so pass in as parameter from make file

LINK+=("src/common/Hlp/Crc32.o")

LINK+=("cmocka/wrap/sciopta.o")
LINK+=("cmocka/wrap/common/Hlp/Failure.o")
LINK+=("cmocka/wrap/common/Hlp/Msg.o")
LINK+=("cmocka/wrap/common/Hlp/Proc.o")
LINK+=("cmocka/wrap/common/Hlp/Io.o")

LINK_OBJECT=${LINK[@]/#/$1}

shift 2

$* $LINK_OBJECT $STUB_WRAPS

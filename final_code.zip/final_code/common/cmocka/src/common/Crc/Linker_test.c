// *****************************************************************************
// **                _______   _________  _________   _______                 **
// **               (  ___  )  \__   __/  \__   __/  (  ____ \                **
// **               | (   ) |     ) (        ) (     | (    \/                **
// **               | |   | |     | |        | |     | (_____                 **
// **               | |   | |     | |        | |     (_____  )                **
// **               | |   | |     | |        | |           ) |                **
// **               | (___) |     | |     ___) (___  /\____) |                **
// **               (_______)     )_(     \_______/  \_______)                **
// **                                                                         **
// **                        Lead Design Center Berlin                        **
// **                                                                         **
// **   Copyright 2021 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **
// **                                                                         **
// *****************************************************************************
//!
//! @file
//!
//! @brief cmocka test file for src/common/Crc/Linker.c
//!
// *****************************************************************************
#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <stdint.h>

#include "Crc.h"
#include "Crc/Linker.h"

#include "cmocka.h"

void __wrap_Crc_Init(
  const Crc_Unit_E cu, const Crc_Type_E ct,
  const uint8_t sw, const uint8_t swby, const uint8_t swbi, const uint8_t inv,
  const uint32_t seed
)
{
}


void __wrap_Crc_AddUint32(const Crc_Unit_E cu, const uint32_t byte4)
{
}


uint32_t __wrap_Crc_Get(const Crc_Unit_E c)
{
  return 0;
}


static void test_CrcLinker_CalcCrc32(void** state)
{
//  assert_int_equal(CrcLinker_CalcCrc32(Crc_UNIT_0, 0, 0), 0);

  assert_int_equal(CrcLinker_CalcCrc32(Crc_UNIT_0, (const void *) "fooo", 4), 0);

  (void) state;
}


int main(void)
{
  int retval = 0;
  
#ifdef CMOCKA_DIAB
  putenv("CMOCKA_XML_FILE=src_common_crc_Linker.xml"); // environment variable for XML file when running on PPC
#endif

  const struct CMUnitTest tests[] =
  {
    cmocka_unit_test(test_CrcLinker_CalcCrc32),
  };

  cmocka_set_message_output(CM_OUTPUT_XML);

  retval = cmocka_run_group_tests_name("src_common_crc_Linker", tests, NULL, NULL);
  
#ifdef CMOCKA_DIAB
  read_xml_file("src_common_crc_Linker.xml"); // extract XML test results from file in RAM when running on PPC
#endif

  return retval;
}


// *****************************************************************************
// **                _______   _________  _________   _______                 **
// **               (  ___  )  \__   __/  \__   __/  (  ____ \                **
// **               | (   ) |     ) (        ) (     | (    \/                **
// **               | |   | |     | |        | |     | (_____                 **
// **               | |   | |     | |        | |     (_____  )                **
// **               | |   | |     | |        | |           ) |                **
// **               | (___) |     | |     ___) (___  /\____) |                **
// **               (_______)     )_(     \_______/  \_______)                **
// **                                                                         **
// **                   Component Engineering Center Berlin                   **
// **                                                                         **
// **   Copyright 2021 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **
// **                                                                         **
// *****************************************************************************
//!
//! @file
//!
//! @brief test src/common/OtpDataManager/OtpDataManager.c
//!
// *****************************************************************************

#include "OtpDataManager/OtpDataManager.h"

#include <setjmp.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include "cmocka.h"

#include "logd/logd.h"
#include "Nvm.h"


// #############################################################################
// ## LOCAL TYPES ##############################################################
// #############################################################################

#define OTP_SEGMENTS  (12288U / 8U)


// #############################################################################
// ## LOCAL FUNCTION DECLARATIONS ##############################################
// #############################################################################

static void helper_initOtp(void);
static void helper_invertMem(void* const pMem, const size_t bytes);

static void test_OtpDataManager_OtpReadPcbManufacturingDate(void** state);
static void test_OtpDataManager_OtpWritePcbManufacturingDate(void** state);


// #############################################################################
// ## WRAP FUNCTION DECLARATIONS ###############################################
// #############################################################################

extern void __wrap_logd_printf(logd_t *self,
                               unsigned int level,
                               const char *fmt,
                               ...);

extern uint64_t __wrap_Nvm_GetUInt64(Nvm_Block_E db, uint32_t dwordNr, uint16_t * pError);
extern void __wrap_Nvm_Lock(Nvm_Block_E db);
extern void __wrap_Nvm_Unlock(Nvm_Block_E db);
extern void __wrap_Nvm_WriteUInt64(uint64_t dword, Nvm_Block_E db, uint32_t dwordNr, uint16_t * pError);
extern int __wrap_SecuritySecureBoot_IsSecure(void);


// #############################################################################
// ## GLOBAL VARIABLES #########################################################
// #############################################################################

static logd_t  logd;

// simulated OTP memory
static uint64_t  otpMemory[OTP_SEGMENTS];


union OtpDataManagerTypes_OtpFormatVersion
{
  struct
  {
    uint32_t  major;
    uint32_t  minor;
  } data;
  uint64_t  raw;
} __attribute__((packed));

union OtpDataManagerTypes_OtpItemHeader
{
  struct
  {
    uint32_t  integrityType :  8;
    uint32_t  id            : 24;
    uint32_t  size          : 32;
  } data;
  uint64_t  raw;
} __attribute__((packed));

union OtpDataManagerTypes_PcbManufacturingDate
{
  struct
  {
    uint16_t  year;
    uint8_t   month;
    uint8_t   day;
  } data;
  uint32_t  raw;
} __attribute__((packed));

union OtpDataManagerTypes_OtpItemPcbManufacturingDate
{
  struct
  {
    union OtpDataManagerTypes_PcbManufacturingDate  normal;
    union OtpDataManagerTypes_PcbManufacturingDate  inverse;
  } data;
  uint64_t  raw;
} __attribute__((packed));


// #############################################################################
// ## LOCAL FUNCTIONS ##########################################################
// #############################################################################

static void helper_initOtp(void)
{
  memset (otpMemory, 0xFFU, sizeof (otpMemory));
}

static void helper_invertMem(void* const pMem, const size_t bytes)
{
  assert_true(NULL != pMem);
  assert_true(0U < bytes);

  uint8_t* const  p = pMem;

  for ( size_t  i = 0U; i < bytes; ++i )
  {
    p[i] ^= 0xFFU;
  }
}


//! @brief  successful read of a supported version
static void test_OtpDataManager_IsFormatVersionSupported_01(void)
{
  size_t  n = 0U;

  helper_initOtp();
  otpMemory[n++] = 0x0000000000000000ULL;  // version major = 0, minor = 0
  otpMemory[n++] = 0xFFFFFFFFFFFFFFFFULL;  // inverted version

  for ( size_t  i = 0U; i < n; ++i )
  {
    will_return(__wrap_Nvm_GetUInt64, Nvm_ERROR_NONE);
    expect_function_call(__wrap_Nvm_GetUInt64);
  }

  const bool  rc = OtpDataManager_IsFormatVersionSupported(&logd);

  assert_true(rc);
}

//! @brief  no version is stored (empty) -> returns true
static void test_OtpDataManager_IsFormatVersionSupported_02(void)
{
  size_t  n = 0U;

  helper_initOtp();
  otpMemory[n++] = 0xFFFFFFFFFFFFFFFFULL;  // unprogrammed
  otpMemory[n++] = 0xFFFFFFFFFFFFFFFFULL;  // unprogrammed

  // this check is very implementation-specific and may change
  // 1st read: check for known format-version at index 0 -> false
  // 2nd read: check for UINT64_MAX (erased location) at index 0 -> true
  // 3rd read: check for UINT64_MAX (erased location) at index 1 -> true
  for ( size_t  i = 0U; i < 3U; ++i )
  {
    will_return(__wrap_Nvm_GetUInt64, Nvm_ERROR_NONE);
    expect_function_call(__wrap_Nvm_GetUInt64);
  }

  const bool  rc = OtpDataManager_IsFormatVersionSupported(&logd);

  assert_true(rc);
}

//! @brief  an unsupported version is stored
static void test_OtpDataManager_IsFormatVersionSupported_03(void)
{
  size_t  n = 0U;

  helper_initOtp();
  otpMemory[n++] = 0x0000000100000001ULL;  // version major = 1, minor = 1
  otpMemory[n++] = 0xFFFFFFFEFFFFFFFEULL;  // inverted version

  for ( size_t  i = 0U; i < n; ++i )
  {
    will_return(__wrap_Nvm_GetUInt64, Nvm_ERROR_NONE);
    expect_function_call(__wrap_Nvm_GetUInt64);
  }

  const bool  rc = OtpDataManager_IsFormatVersionSupported(&logd);

  assert_false(rc);
}

//! @brief  a supported version is corrupted
static void test_OtpDataManager_IsFormatVersionSupported_04(void)
{
  size_t  n = 0U;

  helper_initOtp();
  otpMemory[n++] = 0x0000000000000000ULL;  // version major = 0, minor = 0
  otpMemory[n++] = 0xDEADBEEFCAFECAFEULL;  // inverted value does not match

  // this check is very implementation-specific and may change
  // 1st read: check for known format-version at index 0 -> true
  // 2nd read: check for inverted format-version at index 1 -> false
  // 3rd read: check for UINT64_MAX (erased location) at index 0 -> false
  for ( size_t  i = 0U; i < 3U; ++i )
  {
    will_return(__wrap_Nvm_GetUInt64, Nvm_ERROR_NONE);
    expect_function_call(__wrap_Nvm_GetUInt64);
  }

  const bool  rc = OtpDataManager_IsFormatVersionSupported(&logd);

  assert_false(rc);
}

//! @brief  a read-call fails
static void test_OtpDataManager_IsFormatVersionSupported_05(const size_t failAt)
{
  // needed due to dependent execution of read-calls in the implementation
  const struct
  {
    const size_t  calls;
    const bool    fail[3U];
  } sequ[4U] =
  {
    {.calls = 2U, .fail = {true , false, false}},  // fail at condition 0
    {.calls = 3U, .fail = {false, true , false}},  // fail at condition 1
    {.calls = 2U, .fail = {true , true , false}},  // fail at condition 2
    {.calls = 3U, .fail = {true , false, true }},  // fail at condition 3
  };

  assert_true(failAt < sizeof(sequ)/sizeof(*sequ));
  assert_true(sequ[failAt].calls <= sizeof(sequ[failAt].fail)/sizeof(*sequ[failAt].fail));

  size_t  n = 0U;

  helper_initOtp();
  otpMemory[n++] = 0x0000000000000000ULL;  // version major = 0, minor = 0
  otpMemory[n++] = 0xFFFFFFFFFFFFFFFFULL;  // inverted version

  if ( 3U == failAt )
  {
    // need to modify OPT memory to actually reach the last conditionally call
    // practically the last condition cannot be reached in practice, because the contents of the OTP are not expected to change
    otpMemory[0U] = 0xFFFFFFFFFFFFFFFFULL;
  }

  for ( size_t  i = 0U; i < sequ[failAt].calls; ++i )
  {
    Nvm_Error_E  err = Nvm_ERROR_NONE;
    if ( sequ[failAt].fail[i] )
    {
      err = Nvm_ERROR_RBC;  // read back corrupted
    }
    will_return(__wrap_Nvm_GetUInt64, err);
    expect_function_call(__wrap_Nvm_GetUInt64);
  }

  const bool  rc = OtpDataManager_IsFormatVersionSupported(&logd);

  assert_false(rc);
}

static void test_OtpDataManager_IsFormatVersionSupported(void** state)
{
  test_OtpDataManager_IsFormatVersionSupported_01();
  test_OtpDataManager_IsFormatVersionSupported_02();
  test_OtpDataManager_IsFormatVersionSupported_03();
  test_OtpDataManager_IsFormatVersionSupported_04();
  // read-failures
  test_OtpDataManager_IsFormatVersionSupported_05(0U);
  test_OtpDataManager_IsFormatVersionSupported_05(1U);
  test_OtpDataManager_IsFormatVersionSupported_05(2U);
  test_OtpDataManager_IsFormatVersionSupported_05(3U);

  (void)state;
}


//! @brief  test successful read of the provided manufacturing date
static void test_OtpDataManager_OtpReadPcbManufacturingDate_01(const uint16_t yearIn, const uint8_t monthIn, const uint8_t dayIn)
{
  assert_true(2000U <= yearIn);
  assert_true(yearIn <= 9999U);
  assert_true(1U <= monthIn);
  assert_true(monthIn <= 12U);
  assert_true(1U <= dayIn);
  assert_true(dayIn <= 31U);

  // create raw-value
  union OtpDataManagerTypes_OtpItemPcbManufacturingDate  otpItem;
  memset(&otpItem, 0, sizeof (otpItem));
  otpItem.data.normal.data.year  = yearIn;
  otpItem.data.normal.data.month = monthIn;
  otpItem.data.normal.data.day   = dayIn;
  otpItem.data.inverse           = otpItem.data.normal;
  helper_invertMem(&otpItem.data.inverse, sizeof (otpItem.data.inverse));

  size_t  n = 0U;

  helper_initOtp();
  otpMemory[n++] = 0x0000000000000000ULL;  // version minor = 0, major = 0
  otpMemory[n++] = 0xFFFFFFFFFFFFFFFFULL;  // inverted version
  otpMemory[n++] = 0x0000000800000000ULL;  // size 8 bytes
  otpMemory[n++] = 0xFFFFFFF7FFFFFFFFULL;  // inverted size
  otpMemory[n++] = otpItem.raw;  // payload

  uint16_t  yearOut  = 0xFFFFU;  // invalid
  uint8_t   monthOut = 0xFFU;
  uint8_t   dayOut   = 0xFFU;

  for ( size_t  i = 0U; i < n; ++i )
  {
    will_return(__wrap_Nvm_GetUInt64, Nvm_ERROR_NONE);
    expect_function_call(__wrap_Nvm_GetUInt64);
  }

  const bool  rc = OtpDataManager_ReadPcbManufacturingDate(&logd, &yearOut, &monthOut, &dayOut);

  assert_true(rc);

  assert_true(yearIn  == yearOut);
  assert_true(monthIn == monthOut);
  assert_true(dayIn   == dayOut);
}

//! @brief  a read-call fails or the payload is corrupted
static void test_OtpDataManager_OtpReadPcbManufacturingDate_02(const size_t failAt, const bool corrupt)
{
  size_t  n = 0U;

  helper_initOtp();
  otpMemory[n++] = 0x0000000000000000ULL;  // version minor = 0, major = 0
  otpMemory[n++] = 0xFFFFFFFFFFFFFFFFULL;  // inverted version
  otpMemory[n++] = 0x0000000800000000ULL;  // size 8 bytes
  otpMemory[n++] = 0xFFFFFFF7FFFFFFFFULL;  // inverted size
  otpMemory[n++] = 0x07E50B16F81AF4E9ULL;  // payload

  if ( corrupt )
  {
    // corrupt the payload
    otpMemory[4U] ^= 1U;
  }

  uint16_t  yearOut  = 0xFFFFU;  // dummy
  uint8_t   monthOut = 0xFFU;
  uint8_t   dayOut   = 0xFFU;

  for ( size_t  i = 0U; (i < n)  &&  (i <= failAt); ++i )
  {
    Nvm_Error_E  err = Nvm_ERROR_NONE;

    if ( failAt == i )
    {
      err = Nvm_ERROR_RBC;  // read back corrupted
    }

    will_return(__wrap_Nvm_GetUInt64, err);
    expect_function_call(__wrap_Nvm_GetUInt64);
  }

  const bool  rc = OtpDataManager_ReadPcbManufacturingDate(&logd, &yearOut, &monthOut, &dayOut);

  assert_false(rc);
}

//! @brief  test OtpDataManager_OtpReadPcbManufacturingDate()
static void test_OtpDataManager_OtpReadPcbManufacturingDate(void** state)
{
  test_OtpDataManager_OtpReadPcbManufacturingDate_01(2021U, 10U, 18U);

  for ( uint16_t  year = 2021U; year < 2100U; ++year )
  {
    for ( uint8_t  month = 1U; month <= 12U; ++month )
    {
      for ( uint8_t  day = 1U; day <= 31U; ++day )
      {
        test_OtpDataManager_OtpReadPcbManufacturingDate_01(year, month, day);
      }
    }
  }

  // read-failures
  test_OtpDataManager_OtpReadPcbManufacturingDate_02(  0U, false);
  test_OtpDataManager_OtpReadPcbManufacturingDate_02(  1U, false);
  test_OtpDataManager_OtpReadPcbManufacturingDate_02(  2U, false);
  test_OtpDataManager_OtpReadPcbManufacturingDate_02(  3U, false);
  test_OtpDataManager_OtpReadPcbManufacturingDate_02(  4U, false);
  // read corrupted payload data
  test_OtpDataManager_OtpReadPcbManufacturingDate_02(999U, true );

  (void) state;
}


//! @brief  successful write of the given date
static void test_OtpDataManager_OtpWritePcbManufacturingDate_01(const uint16_t year, const uint8_t month, const uint8_t day)
{
  assert_true(2000U <= year);
  assert_true(year <= 9999U);
  assert_true(1U <= month);
  assert_true(month <= 12U);
  assert_true(1U <= day);
  assert_true(day <= 31U);

  helper_initOtp();

  will_return(__wrap_SecuritySecureBoot_IsSecure, false);
  expect_function_call(__wrap_SecuritySecureBoot_IsSecure);

  // isOtpRangeEmpty()
  for ( size_t  i = 0U; i < OTP_SEGMENTS; ++i )
  {
    will_return(__wrap_Nvm_GetUInt64, Nvm_ERROR_NONE);
    expect_function_call(__wrap_Nvm_GetUInt64);
  }

  const size_t  slots = 5U;

  // write:
  //   format version
  //   format version inverse
  //   item header
  //   item header inverse
  //   item payload
  for ( size_t  i = 0U; i < slots; ++i )
  {
    // write
    expect_function_call(__wrap_Nvm_Unlock);
    will_return(__wrap_Nvm_WriteUInt64, Nvm_ERROR_NONE);
    expect_function_call(__wrap_Nvm_WriteUInt64);
    expect_function_call(__wrap_Nvm_Lock);
    // read
    will_return(__wrap_Nvm_GetUInt64, Nvm_ERROR_NONE);
    expect_function_call(__wrap_Nvm_GetUInt64);
  }

  const bool  rc = OtpDataManager_WritePcbManufacturingDate(&logd, year, month, day);

  assert_true(rc);

  size_t  n = 0U;

  // check slot 1
  union OtpDataManagerTypes_OtpFormatVersion  otpFormat;
  memset(&otpFormat, 0, sizeof (otpFormat));
  otpFormat.data.major = 0U;
  otpFormat.data.minor = 0U;
  assert_true(otpMemory[n++] == otpFormat.raw);

  // check slot 2
  union OtpDataManagerTypes_OtpFormatVersion  otpFormatInverse = otpFormat;
  helper_invertMem(&otpFormatInverse, sizeof (otpFormatInverse));
  assert_true(otpMemory[n++] == otpFormatInverse.raw);

  // check slot 3
  union OtpDataManagerTypes_OtpItemHeader  otpHeader;
  memset(&otpHeader, 0, sizeof (otpHeader));
  otpHeader.data.id            = 0U;
  otpHeader.data.integrityType = 0U;
  otpHeader.data.size          = 8U;
  assert_true(otpMemory[n++] == otpHeader.raw);

  // check slot 4
  union OtpDataManagerTypes_OtpItemHeader  otpHeaderInverse = otpHeader;
  helper_invertMem(&otpHeaderInverse, sizeof (otpHeaderInverse));
  assert_true(otpMemory[n++] == otpHeaderInverse.raw);

  // check slot 5
  union OtpDataManagerTypes_OtpItemPcbManufacturingDate  otpItem;
  memset(&otpItem, 0, sizeof (otpItem));
  otpItem.data.normal.data.year  = year;
  otpItem.data.normal.data.month = month;
  otpItem.data.normal.data.day   = day;
  otpItem.data.inverse           = otpItem.data.normal;
  helper_invertMem(&otpItem.data.inverse, sizeof (otpItem.data.inverse));
  assert_true(otpMemory[n++] == otpItem.raw);

  assert_true(5U == n);
}

//! @brief  OTP already activated
static void test_OtpDataManager_OtpWritePcbManufacturingDate_02(void)
{
  helper_initOtp();

  will_return(__wrap_SecuritySecureBoot_IsSecure, true);
  expect_function_call(__wrap_SecuritySecureBoot_IsSecure);

  const bool  rc = OtpDataManager_WritePcbManufacturingDate(&logd, 2021U, 11U, 22U);

  assert_false(rc);
}

//! @brief  OTP range not empty
static void test_OtpDataManager_OtpWritePcbManufacturingDate_03(void)
{
  helper_initOtp();
  otpMemory[0U] = 0xFEEDFACEDEADBEEFULL;

  will_return(__wrap_SecuritySecureBoot_IsSecure, false);
  expect_function_call(__wrap_SecuritySecureBoot_IsSecure);

  // isOtpRangeEmpty()
  will_return(__wrap_Nvm_GetUInt64, Nvm_ERROR_NONE);
  expect_function_call(__wrap_Nvm_GetUInt64);

  const bool  rc = OtpDataManager_WritePcbManufacturingDate(&logd, 2021U, 11U, 22U);

  assert_false(rc);
}

//! @brief  a read- or write-call fails
static void test_OtpDataManager_OtpWritePcbManufacturingDate_04(const size_t failAt, const bool failWrite)
{
  helper_initOtp();

  will_return(__wrap_SecuritySecureBoot_IsSecure, false);
  expect_function_call(__wrap_SecuritySecureBoot_IsSecure);

  // isOtpRangeEmpty()
  for ( size_t  i = 0U; i < OTP_SEGMENTS; ++i )
  {
    will_return(__wrap_Nvm_GetUInt64, Nvm_ERROR_NONE);
    expect_function_call(__wrap_Nvm_GetUInt64);
  }

  const size_t  slots = 5U;

  // write:
  //   format version
  //   format version inverse
  //   item header
  //   item header inverse
  //   item payload
  for ( size_t  i = 0U; (i < slots)  &&  (i <= failAt); ++i )
  {
    Nvm_Error_E  errRead  = Nvm_ERROR_NONE;
    Nvm_Error_E  errWrite = Nvm_ERROR_NONE;

    if ( failAt == i )
    {
      if ( failWrite )
      {
        errWrite = Nvm_ERROR_RBC;  // read back corrupted
      }
      else
      {
        errRead = Nvm_ERROR_RVE;  // read voltage error
      }
    }

    // write
    expect_function_call(__wrap_Nvm_Unlock);
    will_return(__wrap_Nvm_WriteUInt64, errWrite);
    expect_function_call(__wrap_Nvm_WriteUInt64);
    expect_function_call(__wrap_Nvm_Lock);
    // only read back if write was successful
    if ( Nvm_ERROR_NONE == errWrite )
    {
      // read
      will_return(__wrap_Nvm_GetUInt64, errRead);
      expect_function_call(__wrap_Nvm_GetUInt64);
    }
  }

  const bool  rc = OtpDataManager_WritePcbManufacturingDate(&logd, 2021U, 11U, 22U);

  assert_false(rc);
}

//! @brief  test OtpDataManager_OtpWritePcbManufacturingDate()
static void test_OtpDataManager_OtpWritePcbManufacturingDate(void** state)
{
  test_OtpDataManager_OtpWritePcbManufacturingDate_01(2021U, 10U, 18U);

  for ( uint16_t  year = 2021U; year < 2100U; ++year )
  {
    for ( uint8_t  month = 1U; month <= 12U; ++month )
    {
      for ( uint8_t  day = 1U; day <= 31U; ++day )
      {
        test_OtpDataManager_OtpWritePcbManufacturingDate_01(year, month, day);
      }
    }
  }

  test_OtpDataManager_OtpWritePcbManufacturingDate_02();
  test_OtpDataManager_OtpWritePcbManufacturingDate_03();

  // read-back errors
  test_OtpDataManager_OtpWritePcbManufacturingDate_04(0U, false);
  test_OtpDataManager_OtpWritePcbManufacturingDate_04(1U, false);
  test_OtpDataManager_OtpWritePcbManufacturingDate_04(2U, false);
  test_OtpDataManager_OtpWritePcbManufacturingDate_04(3U, false);
  test_OtpDataManager_OtpWritePcbManufacturingDate_04(4U, false);
  // write-errors
  test_OtpDataManager_OtpWritePcbManufacturingDate_04(0U, true );
  test_OtpDataManager_OtpWritePcbManufacturingDate_04(1U, true );
  test_OtpDataManager_OtpWritePcbManufacturingDate_04(2U, true );
  test_OtpDataManager_OtpWritePcbManufacturingDate_04(3U, true );
  test_OtpDataManager_OtpWritePcbManufacturingDate_04(4U, true );

  (void) state;
}


// #############################################################################
// ## EXTERN FUNCTIONS #########################################################
// #############################################################################

// ============================================================================
//! @brief  main function
// ============================================================================

int main(void)
{
  int retval = 0;
    
#ifdef CMOCKA_DIAB
  putenv("CMOCKA_XML_FILE=src_common_OtpDataManager_OtpDataManager.xml"); // environment variable for XML file when running on PPC
#endif

  const struct CMUnitTest  tests[] =
  {
    cmocka_unit_test(test_OtpDataManager_IsFormatVersionSupported),
    cmocka_unit_test(test_OtpDataManager_OtpReadPcbManufacturingDate),
    cmocka_unit_test(test_OtpDataManager_OtpWritePcbManufacturingDate),
  };

  cmocka_set_message_output(CM_OUTPUT_XML);

  retval =  cmocka_run_group_tests_name("src_common_OtpDataManager_OtpDataManager", tests, NULL, NULL);
    
#ifdef CMOCKA_DIAB
  read_xml_file("src_common_OtpDataManager_OtpDataManager.xml"); // extract XML test results from file in RAM when running on PPC
#endif

  return retval;
}


// #############################################################################
// ## EXTERN WRAP FUNCTIONS ####################################################
// #############################################################################

extern void __wrap_logd_printf(logd_t *self, unsigned int level, const char *fmt, ...)
{
  // empty
}

extern uint64_t __wrap_Nvm_GetUInt64(Nvm_Block_E db, uint32_t dwordNr, uint16_t* pError)
{
  assert_true(Nvm_BLOCK_OTP == db);
  assert_true(dwordNr < sizeof(otpMemory)/sizeof(*otpMemory));

  function_called();

  if ( NULL != pError )
  {
    *pError = (uint16_t) mock();
  }

  uint64_t  result = otpMemory[dwordNr];

  if ( (NULL != pError)  &&  (Nvm_ERROR_NONE != *pError) )
  {
    result = 0xFFFFFFFFFFFFFFFFULL;
  }

  return result;
}

extern void __wrap_Nvm_Lock(Nvm_Block_E db)
{
  assert_true(Nvm_BLOCK_OTP == db);
  function_called();
}

extern void __wrap_Nvm_Unlock(Nvm_Block_E db)
{
  assert_true(Nvm_BLOCK_OTP == db);
  function_called();
}

extern void __wrap_Nvm_WriteUInt64(uint64_t dword, Nvm_Block_E db, uint32_t dwordNr, uint16_t * pError)
{
  assert_true(Nvm_BLOCK_OTP == db);
  assert_true(dwordNr < sizeof(otpMemory)/sizeof(*otpMemory));

  function_called();

  if ( NULL != pError )
  {
    *pError = (uint16_t) mock();
  }

  if ( (NULL == pError)  ||  (Nvm_ERROR_NONE == *pError) )
  {
    otpMemory[dwordNr] = dword;
  }
}

extern int __wrap_SecuritySecureBoot_IsSecure(void)
{
  function_called();
  return (int) mock();
}


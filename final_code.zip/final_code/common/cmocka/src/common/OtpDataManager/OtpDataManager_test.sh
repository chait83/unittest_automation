#!/bin/bash
#STUBS+=("CanSchedSrs_SendBlocking")
STUBS+=("logd_printf")
STUBS+=("Nvm_GetUInt64")
STUBS+=("Nvm_Unlock")
STUBS+=("Nvm_WriteUInt64")
STUBS+=("Nvm_Lock")
STUBS+=("SecuritySecureBoot_IsSecure")

STUB_WRAPS=${STUBS[@]/#/\-Wl,$2} # Diab wrap option syntax is different than GNU so pass in as parameter from make file

shift 2

$* $STUB_WRAPS

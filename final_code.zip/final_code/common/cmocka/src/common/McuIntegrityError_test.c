// *****************************************************************************
// **                _______   _________  _________   _______                 **
// **               (  ___  )  \__   __/  \__   __/  (  ____ \                **
// **               | (   ) |     ) (        ) (     | (    \/                **
// **               | |   | |     | |        | |     | (_____                 **
// **               | |   | |     | |        | |     (_____  )                **
// **               | |   | |     | |        | |           ) |                **
// **               | (___) |     | |     ___) (___  /\____) |                **
// **               (_______)     )_(     \_______/  \_______)                **
// **                                                                         **
// **                        Lead Design Center Berlin                        **
// **                                                                         **
// **   Copyright 2021 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **
// **                                                                         **
// *****************************************************************************
//!
//! @file
//!
//! @brief cmocka test file for src/common/McuIntegrityError.c
//!
// *****************************************************************************
#include <stdlib.h>
#include <time.h>
#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "cmocka.h"
#include "wrap/sciopta.h"
#include <sciopta.msg>
#include "logd/logd.h"
#include "McuIntegrityError.h"
#include "Fccu.h"
#include "Cfg/MsgIds.h"

extern void Fccu_ProcessFaults_will_return(FccuTypes_Error_E returncode, McuIntegrityError_Classes_S* const pIntegrityErrorClass);
extern void EepromEProc_ProcessFaults_will_return(McuIntegrityError_Classes_S* const pIntegrityErrorClass);
extern void SafetyLibApi_ProcessFaults_will_return(McuIntegrityError_Classes_S* const pIntegrityErrorClass);

union sc_msg
{
  sc_msgid_t                                          scMsgId;
  McuIntegrityError_ScMsgUpdateIntegrityErrorClass_S  scMsgUpdateIntegrityErrorClass; //!< Message for sending Integrity Error Class updates to Safety Process
};

const char* const  CfgProcNames_safetyProcess = "/user/SafetyProcess";

#define PID_SAFETY_PROC  ((sc_pid_t) 40)

const size_t  nSignals = 6;  // no. of signals in #McuIntegrityError_Classes_S


// @brief  helper-function to set faults from a bitmapped value
static McuIntegrityError_Classes_S test_McuIntegrityError_ProcessErrors_bin2struct(const uint8_t val)
{
  static McuIntegrityError_Classes_S  faults = {0};

  assert_true(val < (1U << nSignals));  // max. 6 bits

  faults.criticalDefect         = (val & (1U << 0U)) ? true : false;
  faults.criticalDiagnostic     = (val & (1U << 1U)) ? true : false;
  faults.criticalFunction       = (val & (1U << 2U)) ? true : false;
  faults.lessCriticalDiagnostic = (val & (1U << 3U)) ? true : false;
  faults.lessCriticalFunction   = (val & (1U << 4U)) ? true : false;
  faults.warning                = (val & (1U << 5U)) ? true : false;

  return faults;
}


// @brief  inject the given errors and faults
static void test_McuIntegrityError_ProcessErrors_injectState(
  const FccuTypes_Error_E fccuError,
  const InjectScioptaError_E allocError,
  const InjectScioptaError_E txError,
  const uint8_t fccuFaultsMap,
  const uint8_t eepromFaultsMap,
  const uint8_t safetyFaultsMap)
{
  static sc_pid_t   pid = SC_ILLEGAL_PID;
  const sc_msgid_t  msgId = CFGMSGIDS_MCUINTEGRITYERROR_UPDATE_INTEGRITY_ERROR_CLASS_MSGID;
  logd_t  logd = {0};
  McuIntegrityError_Classes_S  fccuFaults   = {0};
  McuIntegrityError_Classes_S  eepromFaults = {0};
  McuIntegrityError_Classes_S  safetyFaults = {0};
  static uint8_t  sumFaultsMapOld = 0;
  uint8_t  sumFaultsMap = 0;
  sc_msg_t  msg = NULL;

  fccuFaults   = test_McuIntegrityError_ProcessErrors_bin2struct(fccuFaultsMap);
  eepromFaults = test_McuIntegrityError_ProcessErrors_bin2struct(eepromFaultsMap);
  safetyFaults = test_McuIntegrityError_ProcessErrors_bin2struct(safetyFaultsMap);

  Fccu_ProcessFaults_will_return(fccuError, &fccuFaults);
  if ( (FccuTypes_ERROR_SUCCESS != fccuError)  &&  (FccuTypes_ERROR_CLEAR_FAULTS != fccuError) )
  {
    expect_function_call(__wrap_HlpFailure_EndlessLoopBusy);
  }
  else
  {
    sumFaultsMap |= fccuFaultsMap;
  }

  // @todo  these functions should not be called in case of #HlpFailure_EndlessLoopBusy(), implementation of #McuIntegrityError_ProcessErrors() needs to be adapted
  EepromEProc_ProcessFaults_will_return(&eepromFaults);
  SafetyLibApi_ProcessFaults_will_return(&safetyFaults);

  sumFaultsMap |= eepromFaultsMap | safetyFaultsMap;  // bitwise (not logical) OR

  if ( sumFaultsMapOld != sumFaultsMap )
  {
    if ( PID_SAFETY_PROC != pid )
    {
      pid = PID_SAFETY_PROC;

      expect_function_call(__wrap___sc_procIdGet);
      will_return(__wrap___sc_procIdGet, pid);
    }

    sc_msgAlloc_will_return(allocError);

    if ( INJECT_NO_ERROR == allocError )
    {
      // This message will be used for comparison purpose and should match the reply message sent by #updateIntegrityErrorClassNonSafetyProcess()
      sc_msgAlloc_will_return(INJECT_NO_ERROR);
      msg = sc_msgAlloc(sizeof(McuIntegrityError_ScMsgUpdateIntegrityErrorClass_S), msgId, SC_DEFAULT_POOL, SC_FATAL_IF_TMO);
      assert_non_null(msg);
      msg->scMsgUpdateIntegrityErrorClass.id                  = msgId;
      msg->scMsgUpdateIntegrityErrorClass.integrityErrorClass = test_McuIntegrityError_ProcessErrors_bin2struct(sumFaultsMap);

      expect_function_call (__wrap___sc_msgTx);
      sc_msgTx_will_return(txError, msg, sizeof(McuIntegrityError_ScMsgUpdateIntegrityErrorClass_S), pid);
    }

    sumFaultsMapOld = sumFaultsMap;
  }

  // in case of a safety error we expect also a reset
  if ( 0 != safetyFaultsMap )
  {
    expect_function_call(__wrap_ProcSafetyIntegrity_SbcReset);
  }

  McuIntegrityError_ProcessErrors(&logd);

  if ( NULL != msg )
  {
    expect_function_call (__wrap___sc_msgFree);
    __wrap___sc_msgFree(&msg);
    assert_null(msg);
  }
}


// @brief  successful call of #McuIntegrityError_ProcessErrors()
static void test_McuIntegrityError_ProcessErrors_01(void)
{
  logd_t  logd = {0};
  McuIntegrityError_Classes_S  faults = {0};

  Fccu_ProcessFaults_will_return(FccuTypes_ERROR_SUCCESS, &faults);
  EepromEProc_ProcessFaults_will_return(&faults);
  SafetyLibApi_ProcessFaults_will_return(&faults);

  McuIntegrityError_ProcessErrors(&logd);
}

// @brief  #Fccu_ProcessFaults returns Fccu_ERROR_CLEAR_FAULTS
static void test_McuIntegrityError_ProcessErrors_02(void)
{
  logd_t  logd = {0};
  McuIntegrityError_Classes_S  faults = {0};

  Fccu_ProcessFaults_will_return(FccuTypes_ERROR_CLEAR_FAULTS, &faults);
  EepromEProc_ProcessFaults_will_return(&faults);
  SafetyLibApi_ProcessFaults_will_return(&faults);

  McuIntegrityError_ProcessErrors(&logd);
}

// @brief  argument is NULL
static void test_McuIntegrityError_ProcessErrors_03(void)
{
  McuIntegrityError_Classes_S  faults = {0};

  Fccu_ProcessFaults_will_return(FccuTypes_ERROR_SUCCESS, &faults);
  EepromEProc_ProcessFaults_will_return(&faults);
  SafetyLibApi_ProcessFaults_will_return(&faults);

  McuIntegrityError_ProcessErrors(NULL);
}

// @brief  inject all possible fault-combinations
static void test_McuIntegrityError_ProcessErrors_04(void)
{
  uint8_t  fccuFaultsMapTo, eepromFaultsMapTo, safetyFaultsMapTo;

  for ( fccuFaultsMapTo = 0; fccuFaultsMapTo < (1U << nSignals); ++fccuFaultsMapTo )
  {
    for ( eepromFaultsMapTo = 0; eepromFaultsMapTo < (1U << nSignals); ++eepromFaultsMapTo )
    {
      for ( safetyFaultsMapTo = 0; safetyFaultsMapTo < (1U << nSignals); ++safetyFaultsMapTo )
      {
        // prepare next test by clearing IntegrityErrorClasses iecSumOld in #McuIntegrityError_ProcessErrors()
        test_McuIntegrityError_ProcessErrors_injectState(FccuTypes_ERROR_SUCCESS, INJECT_NO_ERROR, INJECT_NO_ERROR, 0, 0, 0);
        // inject new test-faults
        test_McuIntegrityError_ProcessErrors_injectState(FccuTypes_ERROR_SUCCESS, INJECT_NO_ERROR, INJECT_NO_ERROR, fccuFaultsMapTo, eepromFaultsMapTo, safetyFaultsMapTo);
      }
    }
  }
}

// @brief  inject all possible errors with random fault-transitions (testing every fault-transition would require (2^6)^6 = 2^36 = 68.719.476.736 test-calls, which is not fully feasible, so we use a limit of 10.000 random-transitions for each error)
static void test_McuIntegrityError_ProcessErrors_05(void)
{
#ifndef CMOCKA_DIAB
  const uint32_t  maxRandomTests = 10 * 1000;  // can be adapted to performance vs. reliability
#else
  const uint32_t  maxRandomTests = 10 * 500;  // TRACE32 Demo has some limitations and this causes problems
#endif
  uint32_t  i;

  uint8_t  fccuFaultsMapFrom = 0, eepromFaultsMapFrom = 0, safetyFaultsMapFrom = 0;
  uint8_t  fccuFaultsMapTo = 0, eepromFaultsMapTo = 0, safetyFaultsMapTo = 0;

  const FccuTypes_Error_E  fccuError[] = {FccuTypes_ERROR_SUCCESS, FccuTypes_ERROR_OPERATION_ABORTED, FccuTypes_ERROR_OPERATION_TIMEOUT, FccuTypes_ERROR_INVALID_PARAMETER, FccuTypes_ERROR_CLEAR_FAULTS, FccuTypes_ERROR_ASSUMPTION_NORMAL_STATE, FccuTypes_ERROR_ASSUMPTION_CONFIG_STATE};
  size_t  iFccuError;

  const InjectScioptaError_E  allocError[] = {INJECT_NO_ERROR, INJECT_KERNEL_EOUT_OF_MEMORY};
  size_t  iAllocError;

  const InjectScioptaError_E  txError[] = {INJECT_NO_ERROR, INJECT_KERNEL_EILL_PID};
  size_t  iTxError;

  srand(time(NULL));

  for ( iFccuError = 0; iFccuError < sizeof(fccuError)/sizeof(*fccuError); ++iFccuError )
  {
    for ( iAllocError = 0; iAllocError < sizeof(allocError)/sizeof(*allocError); ++iAllocError )
    {
      for ( iTxError = 0; iTxError < sizeof(txError)/sizeof(*txError); ++iTxError )
      {
        for ( i = 0; i < maxRandomTests; ++i )
        {
          fccuFaultsMapFrom   = rand() % (1U << nSignals);
          eepromFaultsMapFrom = rand() % (1U << nSignals);
          safetyFaultsMapFrom = rand() % (1U << nSignals);

          fccuFaultsMapTo     = rand() % (1U << nSignals);
          eepromFaultsMapTo   = rand() % (1U << nSignals);
          safetyFaultsMapTo   = rand() % (1U << nSignals);

          test_McuIntegrityError_ProcessErrors_injectState(FccuTypes_ERROR_SUCCESS   , INJECT_NO_ERROR        , INJECT_NO_ERROR  , fccuFaultsMapFrom, eepromFaultsMapFrom, safetyFaultsMapFrom);
          test_McuIntegrityError_ProcessErrors_injectState(fccuError[iFccuError], allocError[iAllocError], txError[iTxError], fccuFaultsMapTo  , eepromFaultsMapTo  , safetyFaultsMapTo  );
        }
      }
    }
  }
}

static void test_McuIntegrityError_ProcessErrors(void** state)
{
  test_McuIntegrityError_ProcessErrors_01();
  test_McuIntegrityError_ProcessErrors_02();
  test_McuIntegrityError_ProcessErrors_03();
  test_McuIntegrityError_ProcessErrors_04();
  test_McuIntegrityError_ProcessErrors_05();

  (void)state;
}


int main(void)
{
  int retval = 0;
  
#ifdef CMOCKA_DIAB
  putenv("CMOCKA_XML_FILE=src_common_McuIntegrityError.xml"); // environment variable for XML file when running on PPC
#endif

  const struct CMUnitTest  tests[] =
  {
    cmocka_unit_test(test_McuIntegrityError_ProcessErrors),
  };

  cmocka_set_message_output(CM_OUTPUT_XML);

  retval = cmocka_run_group_tests_name("src_common_McuIntegrityError", tests, NULL, NULL);
  
#ifdef CMOCKA_DIAB
  read_xml_file("src_common_McuIntegrityError.xml"); // extract XML test results from file in RAM when running on PPC
#endif

  return retval;
}


extern void __wrap_kprintf(const char* fmt)
{
//  (void) printf(fmt);
}


extern void Fccu_ProcessFaults_will_return(FccuTypes_Error_E returncode, McuIntegrityError_Classes_S* const pIntegrityErrorClass)
{
  will_return(__wrap_Fccu_ProcessFaults, returncode);
  will_return(__wrap_Fccu_ProcessFaults, pIntegrityErrorClass);

  expect_function_call(__wrap_Fccu_ProcessFaults);
}

extern FccuTypes_Error_E __wrap_Fccu_ProcessFaults(logd_t* logd, McuIntegrityError_Classes_S* const pIntegrityErrorClass)
{
  const FccuTypes_Error_E  returncode = (const FccuTypes_Error_E) mock();
  const McuIntegrityError_Classes_S* const  pClasses = (const McuIntegrityError_Classes_S*) mock();

  if ( NULL != pIntegrityErrorClass )
  {
    if ( NULL != pClasses )
    {
      *pIntegrityErrorClass = *pClasses;
    }
    else
    {
      memset (pIntegrityErrorClass, 0, sizeof (*pIntegrityErrorClass));
    }
  }

  function_called();

  return returncode;
}


extern void EepromEProc_ProcessFaults_will_return(McuIntegrityError_Classes_S* const pIntegrityErrorClass)
{
  will_return(__wrap_EepromEProc_ProcessFaults, pIntegrityErrorClass);

  expect_function_call(__wrap_EepromEProc_ProcessFaults);
}

extern void __wrap_EepromEProc_ProcessFaults(logd_t* logd, McuIntegrityError_Classes_S* const pIntegrityErrorClass)
{
  const McuIntegrityError_Classes_S* const  pClasses = (const McuIntegrityError_Classes_S*) mock();

  if ( NULL != pIntegrityErrorClass )
  {
    if ( NULL != pClasses )
    {
      *pIntegrityErrorClass = *pClasses;
    }
    else
    {
      memset (pIntegrityErrorClass, 0, sizeof (*pIntegrityErrorClass));
    }
  }

  function_called();
}


extern void SafetyLibApi_ProcessFaults_will_return(McuIntegrityError_Classes_S* const pIntegrityErrorClass)
{
  will_return(__wrap_SafetyLibApi_ProcessFaults, pIntegrityErrorClass);

  expect_function_call(__wrap_SafetyLibApi_ProcessFaults);
}

extern void __wrap_SafetyLibApi_ProcessFaults(logd_t* logd, McuIntegrityError_Classes_S* const pIntegrityErrorClass)
{
  const McuIntegrityError_Classes_S* const  pClasses = (const McuIntegrityError_Classes_S*) mock();

  if ( NULL != pIntegrityErrorClass )
  {
    if ( NULL != pClasses )
    {
      *pIntegrityErrorClass = *pClasses;
    }
    else
    {
      memset (pIntegrityErrorClass, 0, sizeof (*pIntegrityErrorClass));
    }
  }

  function_called();
}


extern void __wrap_ProcSafetyIntegrity_SbcReset(void)
{
  function_called();
}


extern void __wrap_logd_printf(const char *fmt)
{
//  (void) printf(fmt);
}


#!/bin/bash

# ==============================================================================
# usage: run_shared.sh <directory> [ clean | c ]
# ==============================================================================
# parameter 0 .. filename
# parameter 1 .. path to repository (MakefileCmocka in root expected)
# parameter 2 .. optional for cleaning for example

JOBS=$(($NUMBER_OF_PROCESSORS - 1))
#BROWSER="${LOCALAPPDATA}/Mozilla Firefox/firefox.exe"
BROWSER="C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"

if [[ ${#} < 1 ]]
then
	echo "no directory passed" >&2
	exit 1
fi

cd "${1}" || exit 1

if [[ ${#} == 2  &&  (${2} == "clean"  ||  ${2} == "c")  ]]; then
	mingw32-make.exe --no-builtin-rules --no-builtin-variables -f MakefileCmocka clean
	exit
fi

#mingw32-make.exe -j ${JOBS} -f MakefileCmocka build/tests/cmocka/src/common/FCan_test.exe  ||  exit
mingw32-make.exe -j ${JOBS} --no-builtin-rules --no-builtin-variables -f MakefileCmocka all  ||  exit
mingw32-make.exe --no-builtin-rules --no-builtin-variables -f MakefileCmocka report  ||  exit

## at least Chrome does not open files on relative paths, we need to make an absolute one ... in Windows-style (D:\ ...)
PREFIX="file://"$(cygpath --windows "${PWD}")

"${BROWSER}" "${PREFIX}/build/tests/covreport/index.html" &
#"${BROWSER}" "${PREFIX}/build/tests/testreport/report.html" &


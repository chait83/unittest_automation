// !!!!!!This file has been automatically generated.
// !!!!!!Please contact the owner of the file to assign the correct ITC marking.
#pragma once 

#include <stdint.h>
// -----------------------------------------------------------------------------
// CedesMsg1A_msg_can_data_fields_t
// -----------------------------------------------------------------------------
struct CedesMsg1A_msg_can_data_fields_t
{
  uint32_t SeqCnt : 8;
  uint32_t Position : 24;
  int16_t Velocity : 16;
  uint8_t ErrorWarn : 8;
  uint8_t ClipAlign : 8;
};
 
 
// -----------------------------------------------------------------------------
// CedesMsg1B_msg_can_data_fields_t
// -----------------------------------------------------------------------------
struct CedesMsg1B_msg_can_data_fields_t
{
  uint32_t CounterpartPosition : 24;
  uint32_t ClipOffset : 8;
  uint32_t CRC32 : 32;
};
 
 
// -----------------------------------------------------------------------------
// CedesMsg2A_msg_can_data_fields_t
// -----------------------------------------------------------------------------
struct CedesMsg2A_msg_can_data_fields_t
{
  uint32_t SeqCnt : 8;
  uint32_t Position : 24;
  int16_t Velocity : 16;
  uint8_t ErrorWarn : 8;
  uint8_t ClipAlign : 8;
};
 
 
// -----------------------------------------------------------------------------
// CedesMsg2B_msg_can_data_fields_t
// -----------------------------------------------------------------------------
struct CedesMsg2B_msg_can_data_fields_t
{
  uint32_t CounterpartPosition : 24;
  uint32_t ClipOffset : 8;
  uint32_t CRC32 : 32;
};
 
// -----------------------------------------------------------------------------
// DriveFeatureStatus_msg_can_data_fields_t
// -----------------------------------------------------------------------------
struct DriveFeatureStatus_msg_can_data_fields_t
{
  uint16_t MsgSubId : 16;
  uint8_t Data1 : 8;
  uint8_t Data2 : 8;
  uint8_t Data3 : 8;
  uint8_t Data4 : 8;
  uint8_t Data5 : 8;
  uint8_t Data6 : 8;
};
 
 
// -----------------------------------------------------------------------------
// DriveRequest2_msg_can_data_fields_t
// -----------------------------------------------------------------------------
struct DriveRequest2_msg_can_data_fields_t
{
  uint16_t MsgId : 16;
  uint16_t MsgSubId : 16;
  uint8_t ResponseType : 8;
  uint8_t Period : 8;
};
 
 
// -----------------------------------------------------------------------------
// FloorTableRequest_ByDrive_msg_can_data_fields_t
// -----------------------------------------------------------------------------
struct FloorTableRequest_msg_can_data_fields_t
{
  uint16_t RequesterNodeAddr : 16;
  uint8_t RequestId : 8;
  uint8_t ExtraData0 : 8;
  uint8_t ExtraData1 : 8;
  uint8_t ExtraData2 : 8;
  uint8_t ExtraData3 : 8;
  uint8_t ExtraData4 : 8;
};

// -----------------------------------------------------------------------------
// NvmItem0_msg_nvm_data_fields_t
// -----------------------------------------------------------------------------     sub/common/
struct NvmItem0_msg_nvm_data_fields_t
{
  uint64_t UnitNrPart1 : 8;
  uint64_t UnitNrPart2 : 8;
  uint64_t UnitNrPart3 : 8;
  uint64_t UnitNrPart4 : 8;
  uint64_t UnitNrPart5 : 8;
  uint64_t UnitNrPart6 : 8;
  uint64_t UnitNrPart7 : 8;
  uint64_t UnitNrPart8 : 8;
};
 

// -----------------------------------------------------------------------------
// NvmItemDsSegments_msg_nvm_data_fields_t
// -----------------------------------------------------------------------------
struct NvmItemDsSegments_msg_nvm_data_fields_t
{
  uint8_t hasSegs0 : 8;
  uint8_t hasSegs1 : 8;
  uint8_t hasSegs2 : 8;
  uint8_t hasSegs3 : 8;
  uint8_t hasSegs4 : 8;
  uint8_t hasSegs5 : 8;
  uint8_t hasSegs6 : 8;
  uint8_t hasSegs7 : 8;
};

// -----------------------------------------------------------------------------
// NvmItem100_msg_nvm_data_fields_t
// -----------------------------------------------------------------------------
struct NvmItem100_msg_nvm_data_fields_t
{
  uint8_t hasSegs0 : 8;
  uint8_t hasSegs1 : 8;
  uint8_t hasSegs2 : 8;
  uint8_t hasSegs3 : 8;
  uint8_t hasSegs4 : 8;
  uint8_t hasSegs5 : 8;
  uint8_t hasSegs6 : 8;
  uint8_t hasSegs7 : 8;
};


// -----------------------------------------------------------------------------
// NvmItem140_msg_nvm_data_fields_t
// -----------------------------------------------------------------------------
struct NvmItem140_msg_nvm_data_fields_t
{
  uint16_t A11p0mmps2;
  uint16_t A21p0mmps2;
  uint16_t A2Down1p0mmps2;
  uint16_t A31p0mmps2;
};


// -----------------------------------------------------------------------------
// NvmItem141_msg_nvm_data_fields_t
// -----------------------------------------------------------------------------
struct NvmItem141_msg_nvm_data_fields_t
{
  uint16_t A3Down1p0mmps2;
  uint16_t DtBrake1p0ms;
  uint16_t DtSFC1p0ms;
  uint16_t StrikeSpeed1p0mmps;
};


// -----------------------------------------------------------------------------
// NvmItem142_msg_nvm_data_fields_t
// -----------------------------------------------------------------------------
struct NvmItem142_msg_nvm_data_fields_t
{
  uint16_t MinBuffer1p0mm;
  uint16_t MinEtsSpeed1p0mmps;
  uint16_t SpareWord1 : 16;
  uint16_t SpareWord2 : 16;
};


// -----------------------------------------------------------------------------
// NvmItem143_msg_nvm_data_fields_t
// -----------------------------------------------------------------------------
struct NvmItem143_msg_nvm_data_fields_t
{
  uint16_t SpareWord3 : 16;
  uint16_t SpareWord4 : 16;
  uint16_t SpareWord5 : 16;
  uint16_t SpareWord6 : 16;
};
 
 
// -----------------------------------------------------------------------------
// NvmItem1_msg_nvm_data_fields_t
// -----------------------------------------------------------------------------
struct NvmItem1_msg_nvm_data_fields_t
{
  uint64_t NomSpeed : 12;
  uint64_t Rise : 8;
  uint64_t Spare : 5;
  uint64_t Spare1 : 5;
  uint64_t LS8Position : 8;
  uint64_t LS7Position : 8;
};
 
 
// -----------------------------------------------------------------------------
// NvmItem200_GecbpBlockages_msg_nvm_data_fields_t
// -----------------------------------------------------------------------------
struct NvmItem200_GecbpBlockages_msg_nvm_data_fields_t
{
  uint8_t EsaBlockage : 1;
  uint8_t PretripBlockage : 1;
  uint8_t OsBlockage : 1;
  uint8_t SosBlockage : 1;
  uint8_t UcmBlockage : 1;
  uint8_t BrakeFaultBlockage : 1;
  uint8_t IntegrityBlockage : 1;
  uint8_t SudBlockage : 1;
};
 
 
// -----------------------------------------------------------------------------
// NvmItem201_GecbpServiceModes_msg_nvm_data_fields_t
// -----------------------------------------------------------------------------
struct NvmItem201_GecbpServiceModes_msg_nvm_data_fields_t
{
  uint8_t DsbdDs : 1;
  uint8_t DsbdGs : 1;
  uint8_t EroMode : 1;
  uint8_t PitAccessMode : 1;
  uint8_t InstallationPhase : 2;
};
 
 
// -----------------------------------------------------------------------------
// NvmItem205_All_msg_nvm_data_fields_t
// -----------------------------------------------------------------------------
struct NvmItem205_All_msg_nvm_data_fields_t
{
  uint64_t StimulationStep : 8;
  uint64_t ResetPatternIndex : 8;
  uint64_t ResetReasonBufferIndex : 4;
  uint64_t Spare1 : 12;
  uint64_t Spare2 : 32;
};
 
 
// -----------------------------------------------------------------------------
// NvmItem206_All_Fccu01_msg_nvm_data_fields_t
// -----------------------------------------------------------------------------
struct NvmItem206_All_Fccu01_msg_nvm_data_fields_t
{
  uint32_t fault0 : 32;
  uint32_t fault1 : 32;
};
 
 
// -----------------------------------------------------------------------------
// NvmItem207_All_Fccu2_msg_nvm_data_fields_t
// -----------------------------------------------------------------------------
struct NvmItem207_All_Fccu2_msg_nvm_data_fields_t
{
  uint32_t fault2 : 32;
  uint32_t spare : 32;
};
 
 
// -----------------------------------------------------------------------------
// NvmItem208_ResetReasonCounter_msg_nvm_data_fields_t
// -----------------------------------------------------------------------------
struct NvmItem208_ResetReasonCounter_msg_nvm_data_fields_t
{
  uint64_t destructiveResetFccuFailureToReact : 3;
  uint64_t destructiveResetFlashInitFailure : 3;
  uint64_t destructiveResetFunctionalResetEscalation : 3;
  uint64_t destructiveResetPowerOn : 3;
  uint64_t destructiveResetSoftwareDestructiveReset : 3;
  uint64_t destructiveResetStcuUnrecoverableFault : 3;
  uint64_t destructiveResetTempSensorFailure : 3;
  uint64_t destructiveResetVoltageOutOfRange : 3;
  uint64_t functionalResetExternalReset : 3;
  uint64_t functionalResetFccuHardReaction : 3;
  uint64_t functionalResetFccuSoftReaction : 3;
  uint64_t functionalResetJtag : 3;
  uint64_t functionalResetSelfTestCompleted : 3;
  uint64_t functionalResetSoftwareFunctionalReset : 3;
  uint64_t functionalResetTempSensorFailure : 3;
  uint64_t functionalResetVoltageOutOfRange : 3;
};
 
 
// -----------------------------------------------------------------------------
// NvmItem209_ResetReasonBuffer_msg_nvm_data_fields_t
// -----------------------------------------------------------------------------
struct NvmItem209_ResetReasonBuffer_msg_nvm_data_fields_t
{
  uint64_t active : 1;
  uint64_t destructiveResetFccuFailureToReact : 1;
  uint64_t destructiveResetFlashInitFailure : 1;
  uint64_t destructiveResetFunctionalResetEscalation : 1;
  uint64_t destructiveResetPowerOn : 1;
  uint64_t destructiveResetSoftwareDestructiveReset : 1;
  uint64_t destructiveResetStcuUnrecoverableFault : 1;
  uint64_t destructiveResetTempSensorFailure : 1;
  uint64_t destructiveResetVoltageOutOfRange : 1;
  uint64_t functionalResetExternalReset : 1;
  uint64_t functionalResetFccuHardReaction : 1;
  uint64_t functionalResetFccuSoftReaction : 1;
  uint64_t functionalResetJtag : 1;
  uint64_t functionalResetSelfTestCompleted : 1;
  uint64_t functionalResetSoftwareFunctionalReset : 1;
  uint64_t functionalResetTempSensorFailure : 1;
  uint64_t functionalResetVoltageOutOfRange : 1;
  uint64_t Timestamp_5p0s : 15;
};

// -----------------------------------------------------------------------------
// NvmItem220_UM0_1_msg_nvm_data_fields_t
// -----------------------------------------------------------------------------
struct NvmItem220_UM0_1_msg_nvm_data_fields_t
{
  uint64_t UMk : 32;
  uint64_t UMk_1 : 32;
};
// -----------------------------------------------------------------------------
// NvmItem23_msg_nvm_data_fields_t
// -----------------------------------------------------------------------------
struct NvmItem23_msg_nvm_data_fields_t
{
  uint64_t PICS : 1;
  uint64_t BFS : 1;
  uint64_t PLAD : 1;
  uint64_t CLAD : 1;
  uint64_t MAC : 1;
  uint64_t SCS : 1;
  uint64_t RearDoors : 1;
  uint64_t RearDoorsInPit : 1;
  uint64_t SpareJumper1_8 : 8;
  uint64_t Spare : 48;
};
 

// -----------------------------------------------------------------------------
// NvmItemSystemFloorTable_TableStatus_t
// -----------------------------------------------------------------------------
struct NvmItemSystemFloorTable_TableStatus_t
{
  uint16_t TableStatusSafetyValid : 1;
  uint16_t TableStatusLimitsValid : 1;
  uint16_t TableStatusAccuracy : 2;
  uint16_t TableStatusReserved : 4;
  uint16_t Reserved : 8;
  uint16_t BottomFloorNumber : 8;
  uint16_t TopFloorNumber : 8;
  uint16_t RevisionIndex : 16;
  int16_t TableFormatVersion : 8;
  uint16_t Spare : 8;
};

// -----------------------------------------------------------------------------
// NvmItem25_msg_nvm_data_fields_t
// -----------------------------------------------------------------------------
struct NvmItem25_msg_nvm_data_fields_t
{
  uint16_t TableStatusSafetyValid : 1;
  uint16_t TableStatusLimitsValid : 1;
  uint16_t TableStatusAccuracy : 2;
  uint16_t TableStatusReserved : 4;
  uint16_t Reserved : 8;
  uint16_t BottomFloorNumber : 8;
  uint16_t TopFloorNumber : 8;
  uint16_t RevisionIndex : 16;
  uint16_t TableFormatVersion : 8;
  uint16_t Spare : 8;
};
 

// -----------------------------------------------------------------------------
// NvmItemCarCWT_Information_t
// -----------------------------------------------------------------------------
struct NvmItemCarCWT_Information_t
{
  uint32_t CarBufferReserved : 8;
  uint32_t CarBufferPosition : 24;
  uint32_t CWTBufferReserved : 8;
  uint32_t CWTBufferPosition : 24;
};

// -----------------------------------------------------------------------------
// NvmItem26_msg_nvm_data_fields_t
// -----------------------------------------------------------------------------
struct NvmItem26_msg_nvm_data_fields_t
{
  uint32_t CarBufferReserved : 8;
  uint32_t CarBufferPosition : 24;
  uint32_t CWTBufferReserved : 8;
  uint32_t CWTBufferPosition : 24;
};
 
 
// -----------------------------------------------------------------------------
// NvmItem27_msg_nvm_data_fields_t
// -----------------------------------------------------------------------------
struct NvmItem27_msg_nvm_data_fields_t
{
  uint64_t OffsetLowestLanding : 32;
  uint64_t FloorInfoVerified0 : 1;
  uint64_t FloorInfoVerified1 : 1;
  uint64_t FloorInfoVerified2 : 1;
  uint64_t FloorInfoVerified3 : 1;
  uint64_t FloorInfoVerified4 : 1;
  uint64_t FloorInfoVerified5 : 1;
  uint64_t FloorInfoVerified6 : 1;
  uint64_t FloorInfoVerified7 : 1;
  uint64_t FloorInfoVerified8 : 1;
  uint64_t FloorInfoVerified9 : 1;
  uint64_t FloorInfoVerified10 : 1;
  uint64_t FloorInfoVerified11 : 1;
  uint64_t FloorInfoVerified12 : 1;
  uint64_t FloorInfoVerified13 : 1;
  uint64_t FloorInfoVerified14 : 1;
  uint64_t FloorInfoVerified15 : 1;
  uint64_t FloorInfoVerified16 : 1;
  uint64_t FloorInfoVerified17 : 1;
  uint64_t FloorInfoVerified18 : 1;
  uint64_t FloorInfoVerified19 : 1;
  uint64_t FloorInfoVerified20 : 1;
  uint64_t FloorInfoVerified21 : 1;
  uint64_t FloorInfoVerified22 : 1;
  uint64_t FloorInfoVerified23 : 1;
  uint64_t Spare : 8;
};
 

// -----------------------------------------------------------------------------
// NvmItem28_msg_nvm_data_fields_t
// -----------------------------------------------------------------------------
struct NvmItem28_msg_nvm_data_fields_t
{
  uint64_t FloorFirstReserved1 : 1;
  uint64_t FloorFirstDoorConfigValid : 1;
  uint64_t FloorFirstOpening : 2;
  uint64_t FloorFirstReserved2 : 1;
  uint64_t FloorFirstClipConfigValid : 1;
  uint64_t FloorFirstClips : 2;
  uint64_t FloorFirstPosition : 24;
  uint64_t FloorSecondReserved1 : 1;
  uint64_t FloorSecondDoorConfigValid : 1;
  uint64_t FloorSecondOpening : 2;
  uint64_t FloorSecondReserved2 : 1;
  uint64_t FloorSecondClipConfigValid : 1;
  uint64_t FloorSecondClips : 2;
  uint64_t FloorSecondPosition : 24;
};
 
// -----------------------------------------------------------------------------
// NvmItem2_msg_nvm_data_fields_t
// -----------------------------------------------------------------------------
struct NvmItem2_msg_nvm_data_fields_t
{
  uint64_t LS6MICAO : 12;
  uint64_t LS6PINS : 12;
  uint64_t LS5PINS : 12;
  uint64_t LS5MICAO : 12;
  uint64_t Spare : 16;
};
 
 
// -----------------------------------------------------------------------------
// NvmItem30_msg_nvm_data_fields_t
// -----------------------------------------------------------------------------
struct NvmItem30_msg_nvm_data_fields_t
{
  uint64_t FloorFirstReserved1 : 1;
  uint64_t FloorFirstDoorConfigValid : 1;
  uint64_t FloorFirstOpening : 2;
  uint64_t FloorFirstReserved2 : 1;
  uint64_t FloorFirstClipConfigValid : 1;
  uint64_t FloorFirstClips : 2;
  uint64_t FloorFirstPosition : 24;
  uint64_t FloorSecondReserved1 : 1;
  uint64_t FloorSecondDoorConfigValid : 1;
  uint64_t FloorSecondOpening : 2;
  uint64_t FloorSecondReserved2 : 1;
  uint64_t FloorSecondClipConfigValid : 1;
  uint64_t FloorSecondClips : 2;
  uint64_t FloorSecondPosition : 24;
};
 
 
// -----------------------------------------------------------------------------
// NvmItem3_msg_nvm_data_fields_t
// -----------------------------------------------------------------------------
struct NvmItem3_msg_nvm_data_fields_t
{
  uint64_t PitProtection : 12;
  uint64_t PitDepth : 12;
  uint64_t OverheadProtection : 12;
  uint64_t Overhead : 13;
  uint64_t Spare : 15;
};
 
 
// -----------------------------------------------------------------------------
// NvmItem4_msg_nvm_data_fields_t
// -----------------------------------------------------------------------------
struct NvmItem4_msg_nvm_data_fields_t
{
  uint64_t DZSizeUCM : 8;
  uint64_t Spare : 5;
  uint64_t NrOfDsSegments : 3;
  uint64_t EIBoardVersion : 16;
  uint64_t PitBoardVersion : 16;
  uint64_t CarBoardVersion : 16;
};
 
 
// -----------------------------------------------------------------------------
// NvmItem5_msg_nvm_data_fields_t
// -----------------------------------------------------------------------------
struct NvmItem5_msg_nvm_data_fields_t
{
  uint16_t DriveBoardVersion : 16;
  uint16_t CANProtocolVersion : 16;
  uint16_t SabBoardVersion : 16;
  uint16_t Spare : 16;
};
 
 
// -----------------------------------------------------------------------------
// NvmItem6_msg_nvm_data_fields_t
// -----------------------------------------------------------------------------
struct NvmItem6_msg_nvm_data_fields_t
{
  uint8_t CertificatePrefix : 8;
  uint8_t CertificateNumber1 : 8;
  uint8_t CertificateNumber2 : 8;
  uint8_t CertificateNumber3 : 8;
  uint8_t CertificateNumber4 : 8;
  uint8_t CertificateNumber5 : 8;
  uint16_t CertificateSpare : 16;
};
 
 
// -----------------------------------------------------------------------------
// NvmItem7_msg_nvm_data_fields_t
// -----------------------------------------------------------------------------
struct NvmItem7_msg_nvm_data_fields_t
{
  uint8_t FactoryName1 : 8;
  uint8_t FactoryName2 : 8;
  uint8_t FactoryName3 : 8;
  uint8_t FactoryName4 : 8;
  uint8_t FactoryName5 : 8;
  uint8_t FactoryName6 : 8;
  uint8_t FactoryName7 : 8;
  uint8_t FactoryName8 : 8;
};
 
 
// -----------------------------------------------------------------------------
// NvmItem8_msg_nvm_data_fields_t
// -----------------------------------------------------------------------------
struct NvmItem8_msg_nvm_data_fields_t
{
  uint8_t FactoryDateYear1 : 8;
  uint8_t FactoryDateYear2 : 8;
  uint8_t FactoryDateYear3 : 8;
  uint8_t FactoryDateYear4 : 8;
  uint16_t FactoryDateWeek1 : 8;
  uint16_t FactoryDateWeek2 : 8;
  uint16_t FactorySpare : 16;
};

// -----------------------------------------------------------------------------
// PesAvAlarm_msg_can_data_fields_t
// -----------------------------------------------------------------------------
struct PesAvAlarm_msg_can_data_fields_t
{
  uint8_t AvAlarm : 8;
};
 
 
// -----------------------------------------------------------------------------
// PesCarPosition_msg_can_data_fields_t
// -----------------------------------------------------------------------------
struct PesCarPosition_msg_can_data_fields_t
{
  uint32_t Position : 24;
  uint32_t Floor : 8;
  int16_t DistanceToFloor : 16;
  uint16_t TimeStamp : 16;
};
 
 
// -----------------------------------------------------------------------------
// PesCarVelocity_msg_can_data_fields_t
// -----------------------------------------------------------------------------
struct PesCarVelocity_msg_can_data_fields_t
{
  int16_t Velocity : 16;
  uint16_t TimeStamp : 16;
  uint8_t ExtraData1 : 8;
  uint8_t ExtraData2 : 8;
};
 
 
// -----------------------------------------------------------------------------
// PesClipPosition_msg_can_data_fields_t
// -----------------------------------------------------------------------------
struct PesClipPosition_msg_can_data_fields_t
{
  uint32_t Spare1 : 1;
  uint32_t SingleAprsMessage : 1;
  uint32_t Spare2 : 1;
  uint32_t Camera : 1;
  uint32_t Spare3 : 2;
  uint32_t ClipInUpperCamera : 1;
  uint32_t ClipInLowerCamera : 1;
  uint32_t Position : 24;
};
 
 
// -----------------------------------------------------------------------------
// PesCommand_msg_can_data_fields_t
// -----------------------------------------------------------------------------
struct PesCommand_msg_can_data_fields_t
{
  uint8_t Command : 8;
  uint8_t ParameterB3 : 8;
  uint8_t ParameterB2 : 8;
  uint8_t ParameterB1 : 8;
  uint8_t ParameterB0 : 8;
};

// -----------------------------------------------------------------------------
// PesConfig_can_data_fields_t
// -----------------------------------------------------------------------------
struct PesConfig_can_data_fields_t
{
  uint8_t Data0 : 8;
  uint8_t Data1 : 8;
  uint8_t Data2 : 8;
  uint8_t Data3 : 8;
  uint8_t Data4 : 8;
  uint8_t Data5 : 8;
  uint8_t Data6 : 8;
  uint8_t Data7 : 8;
};
 
// -----------------------------------------------------------------------------
// PesConfigRequest_msg_can_data_fields_t
// -----------------------------------------------------------------------------
struct PesConfigRequest_msg_can_data_fields_t
{
  uint64_t StartAddress : 32;
  uint64_t Length : 8;
};
 
 
// -----------------------------------------------------------------------------
// PesDbpRequest_msg_can_data_fields_t
// -----------------------------------------------------------------------------
struct PesDbpRequest_msg_can_data_fields_t
{
  uint8_t Floor : 8;
  uint8_t DbpType : 8;
};
 
 
// -----------------------------------------------------------------------------
// PesDbpStatus_msg_can_data_fields_t
// -----------------------------------------------------------------------------
struct PesDbpStatus_msg_can_data_fields_t
{
  uint8_t Floor : 8;
  uint8_t DbpType : 8;
};
 
 
// -----------------------------------------------------------------------------
// PesFeatureStatus_BySab_msg_can_data_fields_t
// -----------------------------------------------------------------------------
struct PesFeatureStatus_msg_can_data_fields_t
{
  uint64_t SafetyNode : 8;
  uint64_t Feature : 16;
  uint64_t Data0 : 8;
  uint64_t Data1 : 8;
  uint64_t Data2 : 8;
  uint64_t Data3 : 8;
  uint64_t Data4 : 8;
};
 
// -----------------------------------------------------------------------------
// PesFieldTestRequest_msg_can_data_fields_t
// -----------------------------------------------------------------------------
struct PesFieldTestRequest_msg_can_data_fields_t
{
  uint8_t TestId : 8;
  uint8_t ExtraData1 : 8;
  uint16_t ExtraData2 : 16;
  uint16_t ExtraData3 : 16;
};
 
 
// -----------------------------------------------------------------------------
// PesFieldTestStatus_msg_can_data_fields_t
// -----------------------------------------------------------------------------
struct PesFieldTestStatus_msg_can_data_fields_t
{
  uint8_t TestId : 8;
  uint8_t Status : 8;
  uint16_t ExtraData2 : 16;
  uint16_t ExtraData3 : 16;
  uint16_t ExtraData4 : 16;
};
 
 
// -----------------------------------------------------------------------------
// PesFloorStatus_msg_can_data_fields_t
// -----------------------------------------------------------------------------
struct PesFloorStatus_msg_can_data_fields_t
{
  uint8_t Floor : 8;
  uint8_t Dz1 : 1;
  uint8_t Dz2 : 1;
  uint8_t Dz3 : 1;
  uint8_t Dz4 : 1;
  uint8_t Dbp1 : 1;
  uint8_t Dbp2 : 1;
  uint8_t Dbp3 : 1;
  uint8_t Dz23ChangeTriggerSendingMsg : 1;
};
 
 
// -----------------------------------------------------------------------------
// PesNonSafetyRequest_msg_can_data_fields_t
// -----------------------------------------------------------------------------
struct PesNonSafetyRequest_msg_can_data_fields_t
{
  uint8_t Requestee : 8;
  uint8_t RequestB1 : 8;
  uint8_t RequestB0 : 8;
  uint8_t ParameterB1 : 8;
  uint8_t ParameterB0 : 8;
};
 
 
// -----------------------------------------------------------------------------
// PesNonSafetyResponse_msg_can_data_fields_t
// -----------------------------------------------------------------------------
struct PesNonSafetyResponse_msg_can_data_fields_t
{
  uint8_t Requestee : 8;
  uint8_t RequestB1 : 8;
  uint8_t RequestB0 : 8;
  uint8_t ParameterB1 : 8;
  uint8_t ParameterB0 : 8;
  uint8_t ResponseB1 : 8;
  uint8_t ResponseB0 : 8;
};
 
 
// -----------------------------------------------------------------------------
// PesRequest_msg_can_data_fields_t
// -----------------------------------------------------------------------------
struct PesRequest_msg_can_data_fields_t
{
  uint64_t Requestee : 8;
  uint64_t Request : 16;
  uint64_t Parameter : 16;
};
 
// -----------------------------------------------------------------------------
// PesSafetyDetails1_msg_can_data_fields_t
// -----------------------------------------------------------------------------
struct PesSafetyDetails1_msg_can_data_fields_t
{
  uint8_t Spare1 : 7;
  uint8_t InputsValid : 1;
  uint8_t EsaStatus : 8;
  uint8_t AlertReason : 3;
  uint8_t SpecialOperation : 5;
  uint8_t Tes : 1;
  uint8_t Pes : 1;
  uint8_t Pces : 1;
  uint8_t EsbSafe : 1;
  uint8_t Spare2 : 4;
  uint8_t FinalLimitSafe : 1;
  uint8_t Os : 1;
  uint8_t Sos : 1;
  uint8_t RcSwitchActive : 1;
  uint8_t MacOpen : 1;
  uint8_t CLadRemoved : 1;
  uint8_t PicsSwitchActive : 1;
  uint8_t PladRemoved : 1;
  uint8_t Kslr : 1;
  uint8_t DsbdDsActive : 1;
  uint8_t DsbdGsActive : 1;
  uint8_t EsaFailure : 1;
  uint8_t EsaAprsFailure : 1;
  uint8_t BfsCompressed : 1;
  uint8_t ScsTriggered : 1;
  uint8_t CarDoorsSafe : 1;
  uint8_t DsSegmentSafe1 : 1;
  uint8_t DsSegmentSafe2 : 1;
  uint8_t DsSegmentSafe3 : 1;
  uint8_t DsSegmentSafe4 : 1;
  uint8_t DsSegmentSafe5 : 1;
  uint8_t DsSegmentSafe6 : 1;
  uint8_t DsbdSafe : 1;
  uint8_t InCarInspectionSafe : 1;
  uint8_t PicsSafe : 1;
  uint8_t SioSafe : 1;
  uint8_t EroSafe : 1;
  uint8_t Common : 1;
  uint8_t SafetyStatusMsgCounter : 4;
};
 
 
// -----------------------------------------------------------------------------
// PesSafetyDetails2_msg_can_data_fields_t
// -----------------------------------------------------------------------------
struct PesSafetyDetails2_msg_can_data_fields_t
{
  uint64_t OptSafe : 1;
  uint64_t UcmBlockage : 1;
  uint64_t SosBlockage : 1;
  uint64_t OsBlockage : 1;
  uint64_t SudBlockage : 1;
  uint64_t EsaSafe : 1;
  uint64_t BrakeFaultBlockage : 1;
  uint64_t PitDoorsSafe : 1;
  uint64_t IntegrityBlockage : 1;
  uint64_t SconIntegrityError : 1;
  uint64_t ScarIntegrityError : 1;
  uint64_t SpitIntegrityError : 1;
  uint64_t SabIntegrityError : 1;
  uint64_t Spare2 : 2;
  uint64_t FloorTableSafe : 1;
  uint64_t StopType : 4;
  uint64_t LatchType : 4;
  uint64_t InstallationPhase : 2;
  uint64_t TestStatus1h : 1;
  uint64_t TestStatus24h : 1;
  uint64_t Etsd : 1;
  uint64_t SabInstallationPhase : 2;
  uint64_t Spare1 : 1;
  uint64_t CriticalDefect : 1;
  uint64_t CriticalFunction : 1;
  uint64_t LessCriticalFunction : 1;
  uint64_t CriticalDiagnostic : 1;
  uint64_t LessCriticalDiagnostic : 1;
  uint64_t Warning : 1;
  uint64_t Spare4 : 2;
  uint64_t SafetyChainSafe : 1;
  uint64_t VirtualPad : 1;
  uint64_t DoorLockDevice : 1;
  uint64_t RearDoorLockDevice : 1;
  uint64_t Spare3 : 4;
  uint64_t UpperFinalLimit : 1;
  uint64_t UpperProtectionLimit : 1;
  uint64_t Ls6Pit : 1;
  uint64_t Ls6Car : 1;
  uint64_t LowerFinalLimit : 1;
  uint64_t LowerProtectionLimit : 1;
  uint64_t Ls5Pit : 1;
  uint64_t Ls5Car : 1;
  uint64_t Spare5 : 4;
  uint64_t SafetyStatusMsgCounter : 4;
};
 
 
// -----------------------------------------------------------------------------
// PesSafetyStatus_msg_can_data_fields_t
// -----------------------------------------------------------------------------
struct PesSafetyStatus_msg_can_data_fields_t
{
  uint8_t ScOut : 1;
  uint8_t Es : 1;
  uint8_t Gs : 1;
  uint8_t Rgs : 1;
  uint8_t DsSegment1 : 1;
  uint8_t DsSegment2 : 1;
  uint8_t DsSegment3 : 1;
  uint8_t DsSegment4 : 1;
  uint8_t DsSegment5 : 1;
  uint8_t DsSegment6 : 1;
  uint8_t Ds0 : 1;
  uint8_t Rds0 : 1;
  uint8_t Ero : 1;
  uint8_t CarInspection : 1;
  uint8_t Pics : 1;
  uint8_t Pad : 1;
  uint8_t ManualUp : 1;
  uint8_t ManualDown : 1;
  uint8_t RemainingSafetyContactsUnsafe : 1;
  uint8_t EsaTripped : 1;
  uint8_t SafetySystemOk : 1;
  uint8_t Alert : 1;
  uint8_t Sleep : 1;
  uint8_t Blockage : 1;
  uint8_t NormalOperationActive : 1;
  uint8_t CobAlive : 1;
  uint8_t PobAlive : 1;
  uint8_t SabAlive : 1;
  uint8_t SafetyStatusMsgCounter : 4;
};
 
 
// -----------------------------------------------------------------------------
// PesTestPermission_msg_can_data_fields_t
// -----------------------------------------------------------------------------
struct PesTestPermission_msg_can_data_fields_t
{
  uint8_t Spare : 6;
  uint8_t Grant1hTest : 1;
  uint8_t Grant24hTest : 1;
};
 
 
// -----------------------------------------------------------------------------
// PesTestRequest_msg_can_data_fields_t
// -----------------------------------------------------------------------------
struct PesTestRequest_msg_can_data_fields_t
{
  uint8_t Request : 8;
  uint8_t TimeLeft : 8;
};
 
 
// -----------------------------------------------------------------------------
// PesTimeLeftUntilTest_msg_can_data_fields_t
// -----------------------------------------------------------------------------
struct PesTimeLeftUntilTest_msg_can_data_fields_t
{
  uint16_t Spare : 4;
  uint16_t Request : 1;
  uint16_t Duration : 11;
};

// -----------------------------------------------------------------------------
// SafCarCommand_msg_can_data_fields_t
// -----------------------------------------------------------------------------
struct SafCarCommand_msg_can_data_fields_t
{
  uint64_t Spare1 : 8;
  uint64_t PowerSave : 1;
  uint64_t TestCommand : 2;
  uint64_t DldCommand : 1;
  uint64_t RdldCommand : 1;
  uint64_t EtsOffset : 3;
  uint64_t Spare2 : 19;
  uint64_t sel : 3;
  uint64_t Spare : 2;
};
 
 
// -----------------------------------------------------------------------------
// SafCarEvent_msg_can_data_fields_t
// -----------------------------------------------------------------------------
struct SafCarEvent_msg_can_data_fields_t
{
  uint64_t Spare1 : 8;
  uint64_t State : 1;
  uint64_t Event : 23;
  uint64_t Spare2 : 3;
  uint64_t sel : 3;
  uint64_t Spare : 2;
};
 
 
// -----------------------------------------------------------------------------
// SafCarInputs_msg_can_data_fields_t
// -----------------------------------------------------------------------------
struct SafCarInputs_msg_can_data_fields_t
{
  uint64_t Spare1 : 10;
  uint64_t MacOpen : 1;
  uint64_t Tes : 1;
  uint64_t CLadRemoved : 1;
  uint64_t FrontCarDoorsClosed : 1;
  uint64_t RcSwitchActive : 1;
  uint64_t RearCarDoorsClosed : 1;
  uint64_t Spare2 : 8;
  uint64_t LowerPitInspectionLimit : 1;
  uint64_t Etsd : 1;
  uint64_t CriticalDefect : 1;
  uint64_t CriticalFunction : 1;
  uint64_t LessCriticalFunction : 1;
  uint64_t CriticalDiagnostic : 1;
  uint64_t LessCriticalDiagnostic : 1;
  uint64_t Warning : 1;
  uint64_t Spare3 : 3;
  uint64_t sel : 3;
  uint64_t Spare : 2;
  uint64_t Spare4 : 8;
  uint64_t Cpbu : 1;
  uint64_t Cpbd : 1;
  uint64_t Cpbc : 1;
  uint64_t UpperFinalLimit : 1;
  uint64_t LowerFinalLimit : 1;
  uint64_t UpperCarInspectionLimit : 1;
  uint64_t LowerCarInspectionLimit : 1;
  uint64_t UpperPitInspectionLimit : 1;
};
 
 
// -----------------------------------------------------------------------------
// SafCarStatus_msg_can_data_fields_t
// -----------------------------------------------------------------------------
struct SafCarStatus_msg_can_data_fields_t
{
  uint64_t Spare1 : 8;
  uint64_t Floor : 8;
  uint64_t Spare2 : 19;
  uint64_t sel : 3;
  uint64_t Spare : 2;
  uint64_t Spare3 : 8;
  uint64_t Dz1 : 1;
  uint64_t Dz2 : 1;
  uint64_t Dz3 : 1;
  uint64_t Dz4 : 1;
  uint64_t OnLevel : 1;
  uint64_t SpeedLevel : 3;
};
 
 
// -----------------------------------------------------------------------------
// SafPitCommand_msg_can_data_fields_t
// -----------------------------------------------------------------------------
struct SafPitCommand_msg_can_data_fields_t
{
  uint64_t Spare1 : 8;
  uint64_t PowerSave : 1;
  uint64_t TestCommand : 3;
  uint64_t AvAlarm : 1;
  uint64_t Spare2 : 22;
  uint64_t sel : 3;
  uint64_t Spare : 2;
};
 
 
// -----------------------------------------------------------------------------
// SafPitEvent_msg_can_data_fields_t
// -----------------------------------------------------------------------------
struct SafPitEvent_msg_can_data_fields_t
{
  uint64_t Spare1 : 8;
  uint64_t State : 1;
  uint64_t Event : 23;
  uint64_t Spare2 : 3;
  uint64_t sel : 3;
  uint64_t Spare : 2;
};
 
 
// -----------------------------------------------------------------------------
// SafPitInputs_msg_can_data_fields_t
// -----------------------------------------------------------------------------
struct SafPitInputs_msg_can_data_fields_t
{
  uint64_t Spare1 : 10;
  uint64_t Pes : 1;
  uint64_t Ds0 : 1;
  uint64_t PladRemoved : 1;
  uint64_t Pces : 1;
  uint64_t PicsSwitchActive : 1;
  uint64_t Puib : 1;
  uint64_t Spare2 : 8;
  uint64_t LessCriticalDiagnostic : 1;
  uint64_t Warning : 1;
  uint64_t Spare5 : 6;
  uint64_t Spare4 : 3;
  uint64_t sel : 3;
  uint64_t Spare : 2;
  uint64_t Spare3 : 8;
  uint64_t Pdib : 1;
  uint64_t Rds0 : 1;
  uint64_t BfsCompressed : 1;
  uint64_t Padr : 1;
  uint64_t CriticalDefect : 1;
  uint64_t CriticalFunction : 1;
  uint64_t LessCriticalFunction : 1;
  uint64_t CriticalDiagnostic : 1;
};
 
 
// -----------------------------------------------------------------------------
// SafPitSupervisionReport_msg_can_data_fields_t
// -----------------------------------------------------------------------------
struct SafPitSupervisionReport_msg_can_data_fields_t
{
  uint64_t Spare3 : 8;
  uint64_t Rds0WasOpen : 1;
  uint64_t IntegrityFault : 1;
  uint64_t SupervisionExceeded : 1;
  uint64_t Spare : 5;
  uint64_t Spare4 : 8;
  uint64_t Spare2 : 8;
  uint64_t Spare7 : 3;
  uint64_t sel : 3;
  uint64_t WasRequested : 1;
  uint64_t Ds0WasOpen : 1;
  uint64_t Spare5 : 8;
  uint64_t Spare1 : 8;
  uint64_t Spare6 : 8;
};
 
 
// -----------------------------------------------------------------------------
// SafSabCommand_msg_can_data_fields_t
// -----------------------------------------------------------------------------
struct SafSabCommand_msg_can_data_fields_t
{
  uint64_t Spare1 : 8;
  uint64_t PowerSave : 1;
  uint64_t TestCommand : 2;
  uint64_t Command : 3;
  uint64_t DriveLearnRunSupport : 1;
  uint64_t Spare2 : 20;
  uint64_t sel : 3;
  uint64_t Spare : 2;
};
 
 
// -----------------------------------------------------------------------------
// SafSabEvent_msg_can_data_fields_t
// -----------------------------------------------------------------------------
struct SafSabEvent_msg_can_data_fields_t
{
  uint64_t Spare1 : 8;
  uint64_t State : 1;
  uint64_t Event : 23;
  uint64_t Spare2 : 3;
  uint64_t sel : 3;
  uint64_t Spare : 2;
};
 
 
// -----------------------------------------------------------------------------
// SafSabStatus_msg_can_data_fields_t
// -----------------------------------------------------------------------------
struct SafSabStatus_msg_can_data_fields_t
{
  uint64_t Spare1 : 8;
  uint64_t PitOperation : 1;
  uint64_t UpperProtectionLimit : 1;
  uint64_t LowerProtectionLimit : 1;
  uint64_t Overspeed : 1;
  uint64_t InstallationPhase : 2;
  uint64_t ActuatorsOverHeated : 1;
  uint64_t TestInProgress : 1;
  uint64_t Spare5 : 8;
  uint64_t AprsFailureReason : 2;
  uint64_t CriticalDefect : 1;
  uint64_t CriticalFunction : 1;
  uint64_t LessCriticalFunction : 1;
  uint64_t CriticalDiagnostic : 1;
  uint64_t LessCriticalDiagnostic : 1;
  uint64_t Warning : 1;
  uint64_t Spare6 : 3;
  uint64_t sel : 3;
  uint64_t Spare : 2;
  uint64_t Spare3 : 8;
  uint64_t TripStatus : 3;
  uint64_t Spare4 : 1;
  uint64_t TripReason : 4;
};
 
// -----------------------------------------------------------------------------
// Startup_msg_can_data_fields_t
// -----------------------------------------------------------------------------
struct Startup_msg_can_data_fields_t
{
  uint8_t Dummy : 8;
};
 
 
// -----------------------------------------------------------------------------
// SystemFloorTable_msg_can_data_fields_t
// -----------------------------------------------------------------------------
struct SystemFloorTable_msg_can_data_fields_t
{
  uint16_t RevisionIndex : 16;
  uint8_t ID : 8;
  uint8_t Data0 : 8;
  uint8_t Data1 : 8;
  uint8_t Data2 : 8;
  uint8_t Data3 : 8;
  uint8_t Data4 : 8;
};

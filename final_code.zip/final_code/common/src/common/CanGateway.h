// *****************************************************************************
// **                _______   _________  _________   _______                 **
// **               (  ___  )  \__   __/  \__   __/  (  ____ \                **
// **               | (   ) |     ) (        ) (     | (    \/                **
// **               | |   | |     | |        | |     | (_____                 **
// **               | |   | |     | |        | |     (_____  )                **
// **               | |   | |     | |        | |           ) |                **
// **               | (___) |     | |     ___) (___  /\____) |                **
// **               (_______)     )_(     \_______/  \_______)                **
// **                                                                         **
// **                   Component Engineering Center Berlin                   **
// **                                                                         **
// **   Copyright 2017 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **
// **                                                                         **
// *****************************************************************************
//!
//! @file
//!
//! @ingroup grp_CanGateway
//!
//! @brief  Module for Forwarding CAN messages from one CAN channel to another
//!
//!
//! @defgroup grp_CanGateway  CAN Gateway
//!
//! @brief forward CAN messages to another CAN channel
//!
//!   This module provides functions for forwarding CAN messages between two CAN
//!   channels.  It does not provide the process itself, this has to be
//!   implemented by the user.
//!
//!   Use CanGateway_Init() to initialize the relevant structures and
//!   CanGateway_Start() to install the relevant filters in the CAN Scheduler.
//!   Call CanGateway_HandleRcv() for each received message from
//!   the CAN Scheduler, that shall be forwarded.
//!
//!   If you need to forward CAN messages in both directions, you have to
//!   initialize two structures and call the other functions for both channels.
//!
//!
//!   @sa @ref grp_CanSched
//!
//! @reviewNoaction
//! * MW, KNU - 2019-04-25
//!   * No action required.
//!
// *****************************************************************************
#ifndef SRC_COMMON_CANGATEWAY_H_
#define SRC_COMMON_CANGATEWAY_H_

#include <sciopta_sc.h>
#include "logd/logd.h"
#include "CanSched/Types.h"

// =============================================================================
//! @brief  data about the messages that shall be forwarded
//!
//! @details
//!
//!   The messages that match the filters in #pFilterList (of length
//!   #filterListLength) are forwarded from channel #from to channel #to.
//!   In #filterIdx the CAN Scheduler's filter index is stored.
//!
// =============================================================================
struct CanGateway_Gateway
{
  CanSchedTypes_CanChannel_T        from;             //!< reception channel
  CanSchedTypes_CanChannel_T        to;               //!< forwarding channel
  CanSchedTypes_CanFilterIndex_T    filterIdx;        //!< CAN Scheduler filter index
  size_t                            filterListLength; //!< length of #pFilterList
  const CanSchedTypes_CanFilter_S * pFilterList;      //!< to be forwarded messages
};


// =============================================================================
//! @brief  initialize gateway
//!
//! @param [out]  pGw               to be initialized structure
//! @param [in]   from              CAN channel for reception
//! @param [in]   to                CAN channel for forwarding
//! @param [in]   filterListLength  length of #pFilterList
//! @param [in]   pFilterList       CAN filters for messages that shall be
//!                                 forwarded
//!
//!
//! @details
//!
//!   Call this function before calling CanGateway_Start().
//!
// =============================================================================
extern void CanGateway_Init(struct CanGateway_Gateway *       pGw,
                            CanSchedTypes_CanChannel_T        from,
                            CanSchedTypes_CanChannel_T        to,
                            size_t                            filterListLength,
                            const CanSchedTypes_CanFilter_S * pFilterList);

// =============================================================================
//! @brief  register filters in CAN Scheduler
//!
//! @param [in]      logd      log deamon for error reporting
//! @param [in]      canSched  process ID of CAN Scheduler
//! @param [in,out]  pGw       gateway
//!
//!
//! @details
//!
//!   If an error occurs, the function stops in an endless loop.
//!
// =============================================================================
extern void CanGateway_Start(logd_t *                    logd,
                             sc_pid_t                    canSched,
                             struct CanGateway_Gateway * pGw);

// =============================================================================
//! @brief  forward CAN message
//!
//! @param [in]      logd      log deamon for error reporting
//! @param [in]      canSched  process ID of CAN Scheduler
//! @param [in]      pGw       gateway
//! @param [in,out]  pScMsg    Sciopta message
//!
//!
//! @details
//!
//!   If the message is a CAN reception from channel `pGw->from`, it is assumed,
//!   that it is of type CanSchedMsgs_ScMsgRcvNotify_S.  In this case it is
//!   forwarded to CAN channel `pGw->to`.  If the message was forwarded, @p
//!   pScMsg is freed.
//!
//!   If an error occurs, the prints a warning and returns.
//!
// =============================================================================
extern void CanGateway_HandleRcv(logd_t *                          logd,
                                 sc_pid_t                          canSched,
                                 const struct CanGateway_Gateway * pGw,
                                 sc_msg_t *                        pScMsg);


#endif // SRC_COMMON_CANGATEWAY_H_

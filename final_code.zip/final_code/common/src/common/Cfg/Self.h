// =============================================================================
// Copyright 2019 OTIS GmbH & Co OHG - OTIS Component Engineering Center Berlin
// =============================================================================
//!
//! @file
//!
//! @brief Declaration of global structure CfgSelf_self for attributes of the node
//!
//! @reviewNoaction
//! GB, MW, KNU - 2019-04-24
//! * No action required
// =============================================================================


#ifndef CFGSELF_H
#define CFGSELF_H


#include <sciopta_sc.h>
#include "Event/SafetyNode.h"
#include "Opb/Opb.h"


// =============================================================================
//! @brief safety node attributes
// =============================================================================
typedef struct
{
  SafetyNode_E   safetyNode;         //!< define safety node
  OpbNodeAddr_E  canNodeAddr;        //!< OPB CAN address
} CfgSelf_Self_S;


// =============================================================================
//! @brief  attributes of executed safety node
//!
//! @details
//!
//!   The value is defined in the pcb section of the handwritten code.
// =============================================================================
extern const CfgSelf_Self_S CfgSelf_self;  // polyspace MISRA-C3:8.6 [To investigate:Low] "CECBSAFETY-3085"


#endif // CFGSELF_H

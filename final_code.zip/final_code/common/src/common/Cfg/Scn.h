// *****************************************************************************
// **                _______   _________  _________   _______                 **
// **               (  ___  )  \__   __/  \__   __/  (  ____ \                **
// **               | (   ) |     ) (        ) (     | (    \/                **
// **               | |   | |     | |        | |     | (_____                 **
// **               | |   | |     | |        | |     (_____  )                **
// **               | |   | |     | |        | |           ) |                **
// **               | (___) |     | |     ___) (___  /\____) |                **
// **               (_______)     )_(     \_______/  \_______)                **
// **                                                                         **
// **                   Component Engineering Center Berlin                   **
// **                                                                         **
// **   Copyright 2019 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **
// **                                                                         **
// *****************************************************************************
//!
//! @file
//!
//! @brief board SCN number
//!
//! @reviewNoaction
//! GB, MW, KNU - 2019-04-24
//! * No action required
//!
// *****************************************************************************
#ifndef CFGSCN_H
#define CFGSCN_H

#include "ScnType.h"

// =============================================================================
//! @brief board SCN number
//!
//! @details
//!
//!   The value is defined in the pcb section of the handwritten code.
// =============================================================================
extern const union ScnType_Scn CfgScn_BoardScn;  // polyspace MISRA-C3:8.6 [To investigate:Low] "CECBSAFETY-3085", polyspace MISRA-C3:8.5 [To investigate:Low] "SCOM-343"


#endif // CFGSCN_H

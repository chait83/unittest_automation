// *****************************************************************************
// **                _______   _________  _________   _______                 **
// **               (  ___  )  \__   __/  \__   __/  (  ____ \                **
// **               | (   ) |     ) (        ) (     | (    \/                **
// **               | |   | |     | |        | |     | (_____                 **
// **               | |   | |     | |        | |     (_____  )                **
// **               | |   | |     | |        | |           ) |                **
// **               | (___) |     | |     ___) (___  /\____) |                **
// **               (_______)     )_(     \_______/  \_______)                **
// **                                                                         **
// **                   Component Engineering Center Berlin                   **
// **                                                                         **
// **   Copyright 2019 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **
// **                                                                         **
// *****************************************************************************
//!
//! @file
//!
//! @brief PCB description for start hook
//!
//! @reviewNoaction
//! GB, MW, KNU - 2019-04-24
//! * No action required

// *****************************************************************************

#ifndef CFGPCB_H
#define CFGPCB_H

// =============================================================================
//! @brief string describing the PCB for start_hook_stack_safe()
//!
//! @details
//!
//!   The value is defined in the pcb section of the handwritten code.
// =============================================================================
extern const char * CfgPcb_PcbDescription;  // polyspace MISRA-C3:8.6 [To investigate:Low] "CECBSAFETY-3085"

#endif // CFGPCB_H

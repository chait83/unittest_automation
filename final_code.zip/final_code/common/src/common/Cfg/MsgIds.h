// =====================================================================================
// Copyright 2019 OTIS GmbH & Co OHG - OTIS Component Engineering Center Berlin
// =====================================================================================
//
//! @file
//!
//! @brief List of all message IDs used for SCIOPTA messages
//!
//!
//! @details
//!
//!   The message IDs here are not defined as an enum, because they are used as
//!   `sc_msgid_t`.  Defining these message IDs as enum would also cause
//!   compiler errors/warnings when comparing an `sc_msgid_t` with and enum
//!   member.
//

#ifndef CFG_MSGIDS_H
#define CFG_MSGIDS_H

#define OTIS_BASEMSGID  ((sc_msgid_t) 0x00000000UL)

// #############################################################################
//! @name CAN Scheduler
//! @{
#define CFGMSGIDS_CANSCHED_BASEMSGID                           (OTIS_BASEMSGID + 0x10UL)

// -----------------------------------------------------------------------------
// CanSchedPrivateMsgs_ScMsgSetFilterRequest_S
// -----------------------------------------------------------------------------
#define CFGMSGIDS_CANSCHED_SETFILTER_REQUEST_SRS_MSGID         (CFGMSGIDS_CANSCHED_BASEMSGID + 0x00)
#define CFGMSGIDS_CANSCHED_SETFILTER_REQUEST_NONSRS_MSGID      (CFGMSGIDS_CANSCHED_BASEMSGID + 0x01)

// -----------------------------------------------------------------------------
// CanSchedPrivateMsgs_ScMsgSetFilterReply_S
// -----------------------------------------------------------------------------
#define CFGMSGIDS_CANSCHED_SETFILTER_REPLY_MSGID               (CFGMSGIDS_CANSCHED_BASEMSGID + 0x02)


// -----------------------------------------------------------------------------
// CanSchedPrivateMsgs_ScMsgLongFilter_S
// -----------------------------------------------------------------------------
#define CFGMSGIDS_CANSCHED_LONGFILTER_SRS_MSGID                (CFGMSGIDS_CANSCHED_BASEMSGID + 0x03)
#define CFGMSGIDS_CANSCHED_LONGFILTER_NONSRS_MSGID             (CFGMSGIDS_CANSCHED_BASEMSGID + 0x04)


// -----------------------------------------------------------------------------
// CanSchedPrivateMsgs_ScMsgAllocateFilter_S
// -----------------------------------------------------------------------------
#define CFGMSGIDS_CANSCHED_ALLOCATEFILTER_REQUEST_SRS_MSGID    (CFGMSGIDS_CANSCHED_BASEMSGID + 0x05)
#define CFGMSGIDS_CANSCHED_ALLOCATEFILTER_REQUEST_NONSRS_MSGID (CFGMSGIDS_CANSCHED_BASEMSGID + 0x06)
#define CFGMSGIDS_CANSCHED_ALLOCATEFILTER_REPLY_MSGID          (CFGMSGIDS_CANSCHED_BASEMSGID + 0x07)


// -----------------------------------------------------------------------------
// CanSchedPrivateMsgs_ScMsgFreeFilter_S
// -----------------------------------------------------------------------------
#define CFGMSGIDS_CANSCHED_FREEFILTER_REQUEST_SRS_MSGID        (CFGMSGIDS_CANSCHED_BASEMSGID + 0x08)
#define CFGMSGIDS_CANSCHED_FREEFILTER_REQUEST_NONSRS_MSGID     (CFGMSGIDS_CANSCHED_BASEMSGID + 0x09)
#define CFGMSGIDS_CANSCHED_FREEFILTER_REPLY_MSGID              (CFGMSGIDS_CANSCHED_BASEMSGID + 0x0A)


// -----------------------------------------------------------------------------
// CanSchedPrivateMsgs_ScMsgSend_S
// -----------------------------------------------------------------------------
#define CFGMSGIDS_CANSCHED_SEND_REQUEST_SRS_MSGID              (CFGMSGIDS_CANSCHED_BASEMSGID + 0x0B)
#define CFGMSGIDS_CANSCHED_SEND_REQUEST_NONSRS_MSGID           (CFGMSGIDS_CANSCHED_BASEMSGID + 0x0C)
#define CFGMSGIDS_CANSCHED_SEND_REPLY_MSGID                    (CFGMSGIDS_CANSCHED_BASEMSGID + 0x0D)
#define CFGMSGIDS_CANSCHED_SEND_FIRE_REQUEST_SRS_MSGID         (CFGMSGIDS_CANSCHED_BASEMSGID + 0x0E)


// -----------------------------------------------------------------------------
// CanSchedMsgs_ScMsgRcvNotify_S
// -----------------------------------------------------------------------------
#define CFGMSGIDS_CANSCHED_RCVNOTIFY_MSGID(channel)            (CFGMSGIDS_CANSCHED_BASEMSGID + 0x0FUL + ((uint32_t)(channel)))
//! @}

// #############################################################################
//! @name EEProm
//! @{
#define EEPROM_BASEMSGID                     (OTIS_BASEMSGID + 0x40)

#define EEPROM_NVM_READ_MSGID                (EEPROM_BASEMSGID + 0x04)
#define EEPROM_NVM_WRITE_MSGID               (EEPROM_BASEMSGID + 0x05)
#define EEPROM_NVM_ERASEALL_MSGID            (EEPROM_BASEMSGID + 0x06)
#define CFGMSGIDS_EEPROM_OTP_WRITE_PCB_MANUFACTURING_DATE_MSGID         (EEPROM_BASEMSGID + 0x07)
#define CFGMSGIDS_EEPROM_OTP_WRITE_PCB_MANUFACTURING_DATE_REPLY_MSGID   (EEPROM_BASEMSGID + 0x08)
#define CFGMSGIDS_EEPROM_OTP_PCB_MANUFACTURING_DATE_MSGID               (EEPROM_BASEMSGID + 0x09)
#define CFGMSGIDS_EEPROM_OTP_FORMAT_VERSION_NOT_SUPPORTED_MSGID         (EEPROM_BASEMSGID + 0x10)
#define CFGMSGIDS_EEPROM_PCB_MANUFACTURING_DATE_NOT_SET_FAULT_MSGID     (EEPROM_BASEMSGID + 0x11)
#define CFGMSGIDS_EEPROM_OTP_NOT_ACTIVATED_FAULT_MSGID                  (EEPROM_BASEMSGID + 0x12)
#define CFGMSGIDS_EEPROM_JTAG_PASSWORD_NOT_SET_FAULT_MSGID              (EEPROM_BASEMSGID + 0x13)

//! @}

// #############################################################################
//! @name SwMon
//! @{
#define SWMON_BASEMSGID                      (OTIS_BASEMSGID + 0x60)

#define CFGMSGIDS_SWMON_PERIODIC_MSGID       (SWMON_BASEMSGID + 0x00)
#define SWMON_REFRESH_MSGID                  (SWMON_BASEMSGID + 0x01)
//! @}

// #############################################################################
//! @name SafetyProc
//! @{
#define SAFETYPROC_BASEMSGID                 (OTIS_BASEMSGID + 0x65)

#define SAFETYPROC_REFRESH_MSGID             (SAFETYPROC_BASEMSGID + 0x01)
#define SAFETYPROC_RESET_REQUEST_MSGID       (SAFETYPROC_BASEMSGID + 0x02)
//! @}

// #############################################################################
//! @name ScomProc
//! @{
#define SCOMPROC_BASEMSGID                   (OTIS_BASEMSGID + 0x70)

#define SCOMPROC_REFRESH_MSGID               (SCOMPROC_BASEMSGID + 0x01)
//! @}


// #############################################################################
//! @name SconProc
//! @{
#define SCONPROC_BASEMSGID                    (OTIS_BASEMSGID + 0x80)

#define SCONPROC_REFRESH_MSGID                (SCONPROC_BASEMSGID + 0x01)
#define SCONPROC_VALIDITY_STATUS_MSGID        (SCONPROC_BASEMSGID + 0x02)
//! @}

// #############################################################################
//! @name ScarProc
//! @{
#define SCARPROC_BASEMSGID                    (OTIS_BASEMSGID + 0x82)

#define SCARPROC_REFRESH_MSGID                (SCARPROC_BASEMSGID + 0x01)
#define SCARPROC_MEASUREMENT_REPORTING_MSGID  (SCARPROC_BASEMSGID + 0x02)
//! @}

// #############################################################################
//! @name StabProc
//! @{
#define STABPROC_BASEMSGID                    (OTIS_BASEMSGID + 0x85)

#define STABPROC_REFRESH_MSGID                (STABPROC_BASEMSGID + 0x01)
#define STABPROC_TRIP_SPEED_THRESHOLD_MSGID   (STABPROC_BASEMSGID + 0x02)
#define STABPROC_PIT_PROTECTION_LIMIT_MSGID   (STABPROC_BASEMSGID + 0x03)
#define STABPROC_OVERSPEED_THRESHOLD_MSGID    (STABPROC_BASEMSGID + 0x04)
//! @}


// #############################################################################
//! @name Safety Integrity Process
//! @{
#define SAFINT_BASEMSGID                     (OTIS_BASEMSGID + 0x90)

#define CFGMSGIDS_SAFINT_MCUINTEGRITY_MSGID  (SAFINT_BASEMSGID + 0x01)

#define SAFINT_SBCRESET_MSGID                (SAFINT_BASEMSGID + 0x02)

#define SAFINT_SBCINIT_MSGID                 (SAFINT_BASEMSGID + 0x03)

#define CFGMSGIDS_SAFINT_SBCCHECK_MSGID      (SAFINT_BASEMSGID + 0x04)
//! @}

// #############################################################################
//! @name Security Process
//! @{
#define SECURITY_BASEMSGID                   (OTIS_BASEMSGID + 0xA0)

#define SECURITY_NVMUPDATE_MSGID             (SECURITY_BASEMSGID + 0x00)

#define SECURITY_VERIFY_SIGNATURE_EXTERNAL_REQUEST_MSGID (SECURITY_BASEMSGID + 0x01)
#define SECURITY_VERIFY_SIGNATURE_EXTERNAL_REPLY_MSGID   (SECURITY_BASEMSGID + 0x02)
#define SECURITY_VERIFY_SIGNATURE_STATUS_MSGID           (SECURITY_BASEMSGID + 0x03)

#define SECURITY_CRYPTOCHIPCONFIGURE_REQUEST_MSGID       (SECURITY_BASEMSGID + 0x04)
#define SECURITY_CRYPTOCHIPCONFIGURE_REPLY_MSGID         (SECURITY_BASEMSGID + 0x05)

#define SECURITY_CRYPTOCHIPGENKEY_REQUEST_MSGID          (SECURITY_BASEMSGID + 0x06)
#define SECURITY_CRYPTOCHIPGENKEY_REPLY_MSGID            (SECURITY_BASEMSGID + 0x07)

#define SECURITY_CRYPTOCHIPLOCK_REQUEST_MSGID            (SECURITY_BASEMSGID + 0x08)
#define SECURITY_CRYPTOCHIPLOCK_REPLY_MSGID              (SECURITY_BASEMSGID + 0x09)


#define SECURITY_SECUREBOOT_REQUEST_MSGID                (SECURITY_BASEMSGID + 0x0A)
#define SECURITY_SECUREBOOT_REPLY_MSGID                  (SECURITY_BASEMSGID + 0x0B)
//! @}

// #############################################################################
//! @name OpbTimestamp
//! @{
#define OPBTIMESTAMP_BASEMSGID               (OTIS_BASEMSGID + 0xB0)

#define OPBTIMESTAMP_OFFSET_REQUEST_MSGID    (OPBTIMESTAMP_BASEMSGID + 0x00)
#define OPBTIMESTAMP_OFFSET_REPLY_MSGID      (OPBTIMESTAMP_BASEMSGID + 0x01)
//! @}

// #############################################################################
//! @name I2C
//! @{
#define I2C_BASEMSGID                        (OTIS_BASEMSGID + 0xC0)

#define I2C_CFG_REQUEST_MSGID                (I2C_BASEMSGID + 0x00)
#define I2C_CFG_REPLY_MSGID                  (I2C_BASEMSGID + 0x01)

#define I2C_WRITE_REQUEST_MSGID              (I2C_BASEMSGID + 0x02)
#define I2C_WRITE_REPLY_MSGID                (I2C_BASEMSGID + 0x03)

#define I2C_READ_REQUEST_MSGID               (I2C_BASEMSGID + 0x04)
#define I2C_READ_REPLY_MSGID                 (I2C_BASEMSGID + 0x05)

#define I2C_SDALOW_REQUEST_MSGID             (I2C_BASEMSGID + 0x06)
#define I2C_SDALOW_REPLY_MSGID               (I2C_BASEMSGID + 0x07)
//! @}

// #############################################################################
//! @name PESDBG
//! @{
#define CFGMSGIDS_PESDBG_BASEMSGID           (OTIS_BASEMSGID + 0xD0)

#define CFGMSGIDS_PESDBG_PERIODIC_MSGID      (CFGMSGIDS_PESDBG_BASEMSGID + 0x00)
//! @}

// #############################################################################
//! @name 74HC165
//! @{
#define CFGMSGIDS_74HC165_BASEMSGID            (OTIS_BASEMSGID + 0xE0)

#define CFGMSGIDS_74HC165_CFG_REQUEST_MSGID    (CFGMSGIDS_74HC165_BASEMSGID + 0x00)
#define CFGMSGIDS_74HC165_CFG_REPLY_MSGID      (CFGMSGIDS_74HC165_BASEMSGID + 0x01)
#define CFGMSGIDS_74HC165_READ_REQUEST_MSGID   (CFGMSGIDS_74HC165_BASEMSGID + 0x02)
#define CFGMSGIDS_74HC165_READ_2_REPLY_MSGID   (CFGMSGIDS_74HC165_BASEMSGID + 0x04)
//! @}

// #############################################################################
//! @name EventReporting
//! @{
#define CFGMSGIDS_EVENTREPORTING_BASEMSGID          (OTIS_BASEMSGID + 0xF0)

#define CFGMSGIDS_EVENTREPORTING_UPDATE_EVENT_MSGID (CFGMSGIDS_EVENTREPORTING_BASEMSGID + 0x00)
//! @}

// #############################################################################
//! @name McuIntegrityError
//! @{
#define CFGMSGIDS_MCUINTEGRITYERROR_BASEMSGID                          (OTIS_BASEMSGID + 0x100)

#define CFGMSGIDS_MCUINTEGRITYERROR_UPDATE_INTEGRITY_ERROR_CLASS_MSGID (CFGMSGIDS_MCUINTEGRITYERROR_BASEMSGID + 0x00)
//! @}

// #############################################################################
//! @name Diverse
//! @{
#define CFGMSGIDS_DIVERSE_BASEMSGID         (OTIS_BASEMSGID + 0x110)

#define CFGMSGIDS_DIVERSE_PROCESSES_CREATED (CFGMSGIDS_DIVERSE_BASEMSGID + 0x00)
//! @}

// #############################################################################
//! @name RsdProcess Read and Write NVM
//! @{
#define CFGMSGIDS_RSD_EEPROM_BASEMSGID                     (OTIS_BASEMSGID + 0x120)

#define CFGMSGIDS_RSD_EEPROM_ERASE_STATE_MSGID             (CFGMSGIDS_RSD_EEPROM_BASEMSGID + 0x00)
#define CFGMSGIDS_RSD_EEPROM_ERASE_STATE_REPLY_MSGID       (CFGMSGIDS_RSD_EEPROM_BASEMSGID + 0x01)
#define CFGMSGIDS_RSD_EEPROM_WRITE_STATE_MSGID             (CFGMSGIDS_RSD_EEPROM_BASEMSGID + 0x02)
#define CFGMSGIDS_RSD_EEPROM_WRITE_STATE_REPLY_MSGID       (CFGMSGIDS_RSD_EEPROM_BASEMSGID + 0x03)
#define CFGMSGIDS_RSD_EEPROM_STATE_MSGID                   (CFGMSGIDS_RSD_EEPROM_BASEMSGID + 0x04)
#define CFGMSGIDS_RSD_EEPROM_STATE_REPLY_MSGID             (CFGMSGIDS_RSD_EEPROM_BASEMSGID + 0x05)
//! @}

#endif // CFG_MSGIDS_H

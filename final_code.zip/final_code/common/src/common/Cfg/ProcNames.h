#ifndef CFGPROCNAMES_H
#define CFGPROCNAMES_H

#include "config.h"


//! @reviewNoaction
//! GB, MW, KNU - 2019-04-24
//! * No action required

// Sciopta Processes


#ifdef CNF_DSPI0
extern const char * const CfgProcNames_biDspi0;
#endif

#ifdef CNF_DSPI1
extern const char * const CfgProcNames_biDspi1;
#endif

#ifdef CNF_DSPI2
extern const char * const CfgProcNames_biDspi2;
#endif

#ifdef CNF_ADC0
extern const char * const CfgProcNames_bpAdc0;
#endif

#ifdef CNF_ADC1
extern const char * const CfgProcNames_bpAdc1;
#endif

extern const char * const CfgProcNames_bpIo;

#ifdef CNF_PWM0
extern const char * const CfgProcNames_bpPwm0;
#endif

extern const char * const CfgProcNames_scpDevman;
extern const char * const CfgProcNames_scpLogd;

// Other Processes
extern const char * const CfgProcNames_canSched;
extern const char * const CfgProcNames_eeprom;
extern const char * const CfgProcNames_i2c;
extern const char * const CfgProcNames_opbTimestamp;
extern const char * const CfgProcNames_safetyIntegrity;
extern const char * const CfgProcNames_safetyProcess;
extern const char * const CfgProcNames_securityProcess;
extern const char * const CfgProcNames_safetyTimer;

#ifdef CNF_SHIFTREG
extern const char * const CfgProcNames_shiftReg;
#endif

extern const char * const CfgProcNames_swMon;
extern const char * const CfgProcNames_fccuAlarmIr;
extern const char * const CfgProcNames_scomProc;
extern const char * const CfgProcNames_sconProc;
extern const char * const CfgProcNames_stabProc;
extern const char * const CfgProcNames_scarProc;

extern const char * const CfgProcNames_rsdProc; 
#endif // CFGPROCNAMES_H

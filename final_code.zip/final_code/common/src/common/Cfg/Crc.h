// =====================================================================================
// Copyright 2019 OTIS GmbH & Co OHG - OTIS Component Engineering Center Berlin
// =====================================================================================
//
//
//! @file
//!
//! @brief Assignment of the Cyclic Redundancy Check (CRC) Units
//!
//! @details
//!  The following range has to be readable and writable (MPU TABLE)
//!   // CRC
//!   #define MEM_HW_CRC0_START       0xfff64000
//!   #define MEM_HW_CRC0_END         0xfff67fff

#ifndef CFGCRC_H
#define CFGCRC_H

#include "Crc.h"

#define CFGCRC_UNIT_STARTUP          Crc_UNIT_0 //!< This CRC unit is intended to be used at startup, before the first processes start

#define CFGCRC_UNIT_SAFETY_PROCESS   Crc_UNIT_0 //!< This CRC unit is intended to be used only by the Safety Process
#define CFGCRC_UNIT_SCOM_PROCESS     Crc_UNIT_1 //!< This CRC unit is intended to be used only by the Scom Process
#define CFGCRC_UNIT_SAFETY_INTEGRITY Crc_UNIT_2 //!< This CRC unit is intended to be used only by the Integrity Process

#endif // CFGCRC_H

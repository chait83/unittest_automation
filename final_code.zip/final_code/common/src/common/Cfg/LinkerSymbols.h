// =====================================================================================
// Copyright 2019 OTIS GmbH & Co OHG - OTIS Component Engineering Center Berlin
// =====================================================================================
//
//! @file
//!
//! @brief
//!
//! @details
//!   The symbols, published by this file, are provided during linker run. They are used by the MPU
//!   table to set the correct access rights.

#ifndef CFG_LINKERSYMBOLS_H
#define CFG_LINKERSYMBOLS_H

// =============================================================================
// Module RAM Boundaries
// =============================================================================

//! @name Module RAM Boundaries
//! @{
extern uint8_t mod_system_start[];
extern uint8_t mod_system_top[];

extern uint8_t mod_dev_start[];
extern uint8_t mod_dev_top[];

extern uint8_t mod_user_start[];
extern uint8_t mod_user_top[];
//! @}




#endif // CFG_LINKERSYMBOLS_H

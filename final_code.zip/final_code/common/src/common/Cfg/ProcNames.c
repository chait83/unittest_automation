#include "Cfg/ProcNames.h"

// Sciopta Processes

//! @reviewNoaction
//! * GB, MW, KNU - 2019-04-24
//!   * GB will check if any faulty string within a CfgProcName_* yields a fault
//! * GB, KNU - 2019-04-24
//!   * Fault was triggered as expected

#ifdef CNF_DSPI0
const char * const CfgProcNames_biDspi0   = "/dev/BI_dspi0";
#endif

#ifdef CNF_DSPI1
const char * const CfgProcNames_biDspi1   = "/dev/BI_dspi1";
#endif

#ifdef CNF_DSPI2
const char * const CfgProcNames_biDspi2   = "/dev/BI_dspi2";
#endif

#ifdef CNF_ADC0
const char * const CfgProcNames_bpAdc0    = "/dev/BP_adc0";
#endif

#ifdef CNF_ADC1
const char * const CfgProcNames_bpAdc1    = "/dev/BP_adc1";
#endif

const char * const CfgProcNames_bpIo      = "/dev/BP_io";

#ifdef CNF_PWM0
const char * const CfgProcNames_bpPwm0    = BP_PWM0;
#endif

const char * const CfgProcNames_scpDevman = "/SCP_devman";
const char * const CfgProcNames_scpLogd   = "/SCP_logd";

// Other Processes
const char * const CfgProcNames_canSched        = "/user/CanSched";
const char * const CfgProcNames_eeprom          = "/dev/Eeprom";
const char * const CfgProcNames_i2c             = "/dev/I2C";
const char * const CfgProcNames_opbTimestamp    = "/user/OpbTimestamp";
const char * const CfgProcNames_safetyIntegrity = "/user/SafetyIntegrity";
const char * const CfgProcNames_safetyProcess   = "/user/SafetyProcess";
const char * const CfgProcNames_securityProcess = "/dev/SecurityProcess";
const char * const CfgProcNames_safetyTimer     = "/user/SafetyTimer";

#ifdef CNF_SHIFTREG
const char * const CfgProcNames_shiftReg        = "/dev/ShiftReg";
#endif

const char * const CfgProcNames_swMon           = "/user/SwMon";
const char * const CfgProcNames_fccuAlarmIr     = "/user/FccuAlarmIr";

const char * const CfgProcNames_scomProc        = "/user/ScomProc";
const char * const CfgProcNames_sconProc        = "/user/SconProc";
const char * const CfgProcNames_stabProc        = "/user/StabProc";
const char * const CfgProcNames_scarProc        = "/user/ScarProc";

const char * const CfgProcNames_rsdProc         = "/user/RsdProcess";

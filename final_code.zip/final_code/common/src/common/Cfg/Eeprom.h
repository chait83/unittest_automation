// =====================================================================================
// Copyright 2019 OTIS GmbH & Co OHG - OTIS Component Engineering Center Berlin
// =====================================================================================
//
//! @file
//!
//! @brief This file consists of the configuration for the Eeprom process.
//!

#ifndef CFGEEPROM_H
#define CFGEEPROM_H

#define CFGEEPROM_AMOUNT_OF_UNIQUE_IDS 50 //!< See #EEPROMEPROC_NVMData_AMOUNT_OF_IDS for description

#define CFGEEPROM_MIN_UINT64_LEFT_BEFORE_A_FULL_BLOCK_IS_ERASED 1000 //!< Other as full marked blocks are erased if the space of the active block is less than value

#endif /* CFGEEPROM_H */

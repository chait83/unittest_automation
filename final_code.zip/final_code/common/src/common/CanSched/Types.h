// *****************************************************************************
// **                _______   _________  _________   _______                 **
// **               (  ___  )  \__   __/  \__   __/  (  ____ \                **
// **               | (   ) |     ) (        ) (     | (    \/                **
// **               | |   | |     | |        | |     | (_____                 **
// **               | |   | |     | |        | |     (_____  )                **
// **               | |   | |     | |        | |           ) |                **
// **               | (___) |     | |     ___) (___  /\____) |                **
// **               (_______)     )_(     \_______/  \_______)                **
// **                                                                         **
// **                   Component Engineering Center Berlin                   **
// **                                                                         **
// **   Copyright 2017 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **
// **                                                                         **
// *****************************************************************************
//!
//! @file
//!
//! @ingroup grp_CanSchedInterface
//!
//! @brief This file provides the types for the public interface of the CAN
//!        scheduler.
//!
//! @reviewNoAction
//!  * 2019-05-28 - HeLLo, GB, MHn
//!    * No findings.
// *****************************************************************************

#ifndef CANSCHEDTYPES_H
#define CANSCHEDTYPES_H

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>





// #############################################################################
// ##  BASIC TYPES  ############################################################
// #############################################################################


// =============================================================================
//! @brief  CAN channel
//!
//! @details
//!
//!   Index to determine which CAN channel is associated.
//!
// =============================================================================
typedef uint8_t CanSchedTypes_CanChannel_T;


// =============================================================================
//! @brief  CAN filter index
//!
//! @details
//!
//!   Index to determine which CAN filter is associated.  This index is channel
//!   specific.
//!
// =============================================================================
typedef uint8_t CanSchedTypes_CanFilterIndex_T;


// =============================================================================
//! @brief  CAN identifier
//!
//! @details
//!
//!   Might hold 29 and 11 bit identifiers.
//!
// =============================================================================
typedef uint32_t CanSchedTypes_CanId_T;


// =============================================================================
//! @brief  CAN protocol
//!
//! @details
//!
//!   To distinguish standard protocol (11-bit identifiers) and extended
//!   protocol (29-bit identifiers).
//!
// =============================================================================
enum CanSchedTypes_CanProtocol
{
  CanSchedTypes_PROTOCOL_STANDARD,  //!< standard protocol, 11 bit
  CanSchedTypes_PROTOCOL_EXTENDED,  //!< extended protocol, 29 bit
};
typedef enum CanSchedTypes_CanProtocol CanSchedTypes_CanProtocol_E;


// =============================================================================
//! @brief  CanScheduler error values
// =============================================================================
enum CanSchedTypes_Error
{
  CanSchedTypes_ERROR_SUCCESS              = 0,    //!< no error
  CanSchedTypes_ERROR_INTERNAL_SCMSG_ALLOC = -1,   //!< allocation of sciopta message failed
  CanSchedTypes_ERROR_INTERNAL_SCMSG_TX    = -2,   //!< sending of sciopta message failed
  CanSchedTypes_ERROR_INTERNAL_SCMSG_RX    = -3,   //!< reception of sciopta message failed
  CanSchedTypes_ERROR_CHANNEL_INDEX        = -4,   //!< invalid channel index
  CanSchedTypes_ERROR_FILTER_INDEX         = -5,   //!< invalid filter index
  CanSchedTypes_ERROR_FILTER_LENGTH        = -6,   //!< invalid filter length
  CanSchedTypes_ERROR_FILTER_TYPE          = -7,   //!< invalid protocol type
  CanSchedTypes_ERROR_FILTER_CLEARED       = -8,   //!< filter was already cleared
  CanSchedTypes_ERROR_CAN_ID               = -9,   //!< can ID is out of range
  CanSchedTypes_ERROR_CAN_DATA_LENGTH      = -10,  //!< can data are to long
  CanSchedTypes_ERROR_CAN_BUS_OFF          = -11,  //!< can error: bus off
  CanSchedTypes_ERROR_CAN_ERROR_ACTIVE     = -12,  //!< can error: error active
  CanSchedTypes_ERROR_CAN_UNDEFINED        = -13,  //!< can error: unknown
  CanSchedTypes_ERROR_TRANSMISSION_ABORTED = -14,  //!< can transmission was aborted
  CanSchedTypes_ERROR_FAILURE              = -15,  //!< request failed
  CanSchedTypes_ERROR_FILTER_NOT_ALLOCATED = -16,  //!< filter index was not allocated at all
  CanSchedTypes_ERROR_FILTER_FALSE_OWNER   = -17,  //!< filter index was allocated by someone else
  CanSchedTypes_ERROR_UPDATE_PENDING       = -18,  //!< the last filter update is not finished yet
  CanSchedTypes_ERROR_QUEUE_FULL           = -19,  //!< transmit queue is full
};
typedef enum CanSchedTypes_Error CanSchedTypes_Error_E;






// #############################################################################
// ##  COMPLEX TYPES  ##########################################################
// #############################################################################


// =============================================================================
//! @brief  CAN data
//!
//! @details
//!
//!   Allows different accesses to the CAN data.
//!
// =============================================================================
union CanSchedTypes_CanData
{
  uint8_t  u8[sizeof(uint64_t) / sizeof(uint8_t)];    //!< access 8 times 1 byte
  uint16_t u16[sizeof(uint64_t) / sizeof(uint16_t)];  //!< access 4 times 2 bytes
  uint32_t u32[sizeof(uint64_t) / sizeof(uint32_t)];  //!< access 2 times 4 bytes
  uint64_t u64[sizeof(uint64_t) / sizeof(uint64_t)];  //!< access 1 time  8 bytes
};
typedef union CanSchedTypes_CanData CanSchedTypes_CanData_U;


// =============================================================================
//! @brief  filter for receiving CAN messages
//!
//! @details
//!
//!   The filter describes which messages shall be received.
//!
//!   A filter might only match for
//!
//!     * either extended CAN identifiers `(#protocol == #CanSchedTypes_PROTOCOL_EXTENDED)`
//!     * or     standard CAN identifiers `(#protocol == #CanSchedTypes_PROTOCOL_STANDARD)`.
//!
//!   If the CAN message has the right identifier length, the match is checked.
//!   For the match the following expression is calculated:
//!
//!           (receivedProtocol == filter.protocol)
//!        && ((receivedCanId & filter.mask) == filter.compare)
//!
//!   If this expression results to true, the message matches the filter and the
//!   CAN message is delivered to the process that installed the filter.
//!
//!
//! @par EXAMPLE 1
//!
//!     CanSchedTypes_CanFilter_S filter;
//!     filter.protocol = CanSchedTypes_PROTOCOL_EXTENDED;  // 29 bits
//!     filter.mask     = 0x0000FFFF;
//!     filter.compare  = 0x0000BEEF;
//!
//!   The following extended CAN identifiers match:
//!
//!     * `0x0BADBEEF`;
//!     * `0x0000BEEF`;
//!
//!   But `0x0BAD0000` does not match.
//!
//!
//! @par EXAMPLE 2
//!
//!     CanSchedTypes_CanFilter_S filter;
//!     filter.protocol = CanSchedTypes_PROTOCOL_STANDARD;  // 11 bits
//!     filter.mask     = 0x000000F0;
//!     filter.compare  = 0x00000070;
//!
//!   The following standard CAN identifiers match:
//!
//!     * `0x00000170`;
//!     * `0x0000007F`;
//!
//!   If the CAN message on the bus has extended protocol, the filter does not
//!   match!
//!
//!
//! @par EXAMPLE 3
//!
//!     CanSchedTypes_CanFilter_S filter;
//!     filter.protocol = CanSchedTypes_PROTOCOL_EXTENDED;  // 29 bits
//!     filter.mask     = 0x00000000;
//!     filter.compare  = 0x00000000;
//!
//!   This filter results in receiving all CAN messages with an extended
//!   identifier.
//!
//!
//! @par EXAMPLE 4
//!
//!     CanSchedTypes_CanFilter_S filter;
//!     filter.protocol = CanSchedTypes_PROTOCOL_EXTENDED;  // 29 bits
//!     filter.mask     = 0x00000000;
//!     filter.compare  = 0x00000001;
//!
//!   This filter results in receiving no CAN messages.
//!
// =============================================================================
struct CanSchedTypes_CanFilter
{
  CanSchedTypes_CanProtocol_E protocol;  //!< CAN protocol
  CanSchedTypes_CanId_T       mask;      //!< mask of relevant bits
  CanSchedTypes_CanId_T       compare;   //!< compared bits
};
typedef struct CanSchedTypes_CanFilter CanSchedTypes_CanFilter_S;


// =============================================================================
//! @brief  CAN message
//!
//! @details
//!
//!   Stores the data of a CAN message.  #protocol defines if the #canId is 11
//!   (#CanSchedTypes_PROTOCOL_STANDARD) or 29 (#CanSchedTypes_PROTOCOL_EXTENDED)
//!   bits long.  #dataLen defines how many bytes of the `data.u8` array are
//!   used.  #dataLen must be at least `0` and maximum `8`.
//!
// =============================================================================
struct CanSchedTypes_CanMsg
{
  CanSchedTypes_CanProtocol_E protocol;  //!< CAN protocol
  CanSchedTypes_CanId_T       canId;     //!< CAN identifier
  size_t                      dataLen;   //!< length of payload
  CanSchedTypes_CanData_U     data;      //!< payload
};
typedef struct CanSchedTypes_CanMsg CanSchedTypes_CanMsg_S;



#endif // CANSCHEDTYPES_H

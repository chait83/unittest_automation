// *****************************************************************************
// **                _______   _________  _________   _______                 **
// **               (  ___  )  \__   __/  \__   __/  (  ____ \                **
// **               | (   ) |     ) (        ) (     | (    \/                **
// **               | |   | |     | |        | |     | (_____                 **
// **               | |   | |     | |        | |     (_____  )                **
// **               | |   | |     | |        | |           ) |                **
// **               | (___) |     | |     ___) (___  /\____) |                **
// **               (_______)     )_(     \_______/  \_______)                **
// **                                                                         **
// **                   Component Engineering Center Berlin                   **
// **                                                                         **
// **   Copyright 2017 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **
// **                                                                         **
// *****************************************************************************
//!
//! @file
//!
//! @ingroup grp_CanSchedInterface
//!
//! @brief  interface for the CAN proxy to the CAN scheduler
//!
//!
//! @details
//!
//!   These functions provide the interface that is exclusive to the CAN proxy.
//!
//!   The functions behave like the CanSchedSrs_XXX() functions, except that
//!
//!    * they communicate to the CAN scheduler with different Sciopta message
//!      IDs.  This results in a prioritization of the requests of the safety
//!      processes.
//!
//!
//!
// *****************************************************************************

#ifndef CANSCHED_NONSRS_H
#define CANSCHED_NONSRS_H

#include <sciopta_sc.h>
#include "CanSched/Types.h"

// #############################################################################
// ## FUNCTIONS ################################################################
// #############################################################################


//! @name  CAN filter
//! @{

// =============================================================================
//! @brief  allocate a filter
//!
//! @param [in]  canSchedPid   process ID of the CAN scheduler
//! @param [in]  channel       CAN channel ID
//! @param [out] pFilterIndex  place where successful allocated filter ID is
//!                            stored
//!
//!
//! @details
//!
//!   This function works like CanSchedSrs_AllocFilter(), except that the proxy
//!   Sciopta message IDs are used.
//!
//!
//! @sa CanSchedNonSrs_AllocFilter()
//!
//! @reviewMinor
//!  * 2019-06-05 - HeLLo, GB, MHn
//!    * reword sa link from CanSchedNonSrs_AllocFilter to CanSchedSrs_AllocFilter
// =============================================================================
extern CanSchedTypes_Error_E CanSchedNonSrs_AllocFilter(sc_pid_t                         canSchedPid,
                                                        CanSchedTypes_CanChannel_T       channel,
                                                        CanSchedTypes_CanFilterIndex_T * pFilterIndex);

// =============================================================================
//! @brief  program a filter and return when programmed
//!
//! @param [in]  canSchedPid       process ID of the CAN scheduler
//! @param [in]  channel           CAN channel ID
//! @param [in]  filterIndex       already allocated filter ID
//! @param [in]  filterListLength  number of elements in @p pFilterList
//! @param [in]  pFilterList       list of CAN filters
//!
//!
//! @details
//!
//!   This function works like CanSchedSrs_SetFilterBlocking(), except that the
//!   proxy Sciopta message IDs are used.
//!
//!
//! @sa CanSchedNonSrs_SetFilterBlocking()
//!
//! @reviewMinor
//!  * 2019-06-05 - HeLLo, GB, MHn
//!    * reword sa link from CanSchedNonSrs_SetFilterBlocking to CanSchedSrs_SetFilterBlocking
// =============================================================================
extern CanSchedTypes_Error_E CanSchedNonSrs_SetFilterBlocking(sc_pid_t                          canSchedPid,
                                                              CanSchedTypes_CanChannel_T        channel,
                                                              CanSchedTypes_CanFilterIndex_T    filterIndex,
                                                              size_t                            filterListLength,
                                                              const CanSchedTypes_CanFilter_S * pFilterList);

// =============================================================================
//! @brief  program a filter and return immediately
//!
//! @param [in]  canSchedPid       process ID of the CAN scheduler
//! @param [in]  channel           CAN channel ID
//! @param [in]  filterIndex       already allocated filter ID
//! @param [in]  filterListLength  number of elements in @p pFilterList
//! @param [in]  pFilterList       list of CAN filters
//!
//!
//! @details
//!
//!   This function works like CanSchedSrs_SetFilterNonBlocking(), except that
//!   the proxy Sciopta message IDs are used.
//!
//!
//! @sa CanSchedNonSrs_SetFilterNonBlocking()
//!
//! @reviewMinor
//!  * 2019-06-05 - HeLLo, GB, MHn
//!    * reword sa link from CanSchedNonSrs_SetFilterNonBlocking to CanSchedSrs_SetFilterNonBlocking
// =============================================================================
extern CanSchedTypes_Error_E CanSchedNonSrs_SetFilterNonBlocking(sc_pid_t                          canSchedPid,
                                                                 CanSchedTypes_CanChannel_T        channel,
                                                                 CanSchedTypes_CanFilterIndex_T    filterIndex,
                                                                 size_t                            filterListLength,
                                                                 const CanSchedTypes_CanFilter_S * pFilterList);

// =============================================================================
//! @brief  free a filter
//!
//! @param [in]  canSchedPid  process ID of the CAN scheduler
//! @param [in]  channel      CAN channel ID
//! @param [in]  filterIndex  already allocated filter ID
//!
//!
//! @details
//!
//!   This function works like CanSchedSrs_FreeFilter(), except that the proxy
//!   Sciopta message IDs are used.
//!
//!
//! @sa CanSchedNonSrs_FreeFilter()
//!
//! @reviewMinor
//!  * 2019-06-05 - HeLLo, GB, MHn
//!    * reword sa link from CanSchedNonSrs_FreeFilter to CanSchedSrs_FreeFilter
// =============================================================================
extern CanSchedTypes_Error_E CanSchedNonSrs_FreeFilter(sc_pid_t                       canSchedPid,
                                                       CanSchedTypes_CanChannel_T     channel,
                                                       CanSchedTypes_CanFilterIndex_T filterIndex);

//! @}


//! @name sending CAN messages
//! @{

// =============================================================================
//! @brief  send a CAN message and return when on
//!
//! @param [in]  canSchedPid  process ID of the CAN scheduler
//! @param [in]  channel      CAN channel ID
//! @param [in]  pCanMsg      CAN message
//!
//!
//! @details
//!
//!   This function works like CanSchedSrs_SendBlocking(), except that the proxy
//!   Sciopta message IDs are used.
//!
//!
//! @sa CanSchedNonSrs_SendBlocking()
//!
//! @reviewMinor
//!  * 2019-06-05 - HeLLo, GB, MHn
//!    * reword sa link from CanSchedNonSrs_SendBlocking to CanSchedSrs_SendBlocking
// =============================================================================
extern CanSchedTypes_Error_E CanSchedNonSrs_SendBlocking(sc_pid_t                       canSchedPid,
                                                         CanSchedTypes_CanChannel_T     channel,
                                                         const CanSchedTypes_CanMsg_S * pCanMsg);

// =============================================================================
//! @brief  send a CAN message and return immediately
//!
//! @param [in]  canSchedPid  process ID of the CAN scheduler
//! @param [in]  channel      CAN channel ID
//! @param [in]  pCanMsg      CAN message
//!
//!
//! @details
//!
//!   This function works like CanSchedSrs_SendNonBlocking(), except that the
//!   proxy Sciopta message IDs are used.
//!
//!
//! @sa CanSchedNonSrs_SendNonBlocking()
//!
//! @reviewMinor
//!  * 2019-06-05 - HeLLo, GB, MHn
//!    * reword sa link from CanSchedNonSrs_SendNonBlocking to CanSchedSrs_SendNonBlocking
// =============================================================================
extern CanSchedTypes_Error_E CanSchedNonSrs_SendNonBlocking(sc_pid_t                       canSchedPid,
                                                            CanSchedTypes_CanChannel_T     channel,
                                                            const CanSchedTypes_CanMsg_S * pCanMsg);

//! @}


#endif // CANSCHED_NONSRS_H

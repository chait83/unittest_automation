// *****************************************************************************
// **                _______   _________  _________   _______                 **
// **               (  ___  )  \__   __/  \__   __/  (  ____ \                **
// **               | (   ) |     ) (        ) (     | (    \/                **
// **               | |   | |     | |        | |     | (_____                 **
// **               | |   | |     | |        | |     (_____  )                **
// **               | |   | |     | |        | |           ) |                **
// **               | (___) |     | |     ___) (___  /\____) |                **
// **               (_______)     )_(     \_______/  \_______)                **
// **                                                                         **
// **                   Component Engineering Center Berlin                   **
// **                                                                         **
// **   Copyright 2017 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **
// **                                                                         **
// *****************************************************************************
//!
//! @file
//!
//! @ingroup grp_CanSchedInterface
//!
//! @brief  Public Sciopta Messages for the CAN Driver Scheduler.
//!
//! @reviewNoAction
//!  * 2019-05-28 - HeLLo, GB, MHn
//!    * No findings.
// *****************************************************************************

#ifndef CANSCHEDMSGS_H
#define CANSCHEDMSGS_H

#include <sciopta_sc.h>
#include "CanSched/Types.h"


// =============================================================================
//! @brief  received CAN message
//!
//! @details
//!
//!   #CanSchedMsgs_ScMsgRcvNotify_S is used to inform a process about an
//!   incomming CAN message, that matched to an by the receiver installed
//!   filter.
//!
//! @par MESSAGE IDS
//!
//!   #CFGMSGIDS_CANSCHED_RCVNOTIFY_MSGID(ch), where `ch` is the channel the
//!                                            message was received on
//!
//! @reviewNice
//!  * 2019-05-28 - HeLLo, GB, MHn
//!    * s/!< ciopta/!< sciopta
//!    * s/incomming/incoming/
// =============================================================================
struct CanSchedMsgs_ScMsgRcvNotify
{
  sc_msgid_t                 scMsgId;           //!< ciopta message ID
  CanSchedTypes_CanChannel_T channel;           //!< channel (not unit)
  uint16_t                   canHwTimestamp;    //!< @brief hardware time stamp at
                                                //!  reception time
  uint64_t                   ltcReceptionTime;  //!< @brief lifetime counter value at
                                                //!  reception time in interrupt
                                                //!  routine
  CanSchedTypes_CanMsg_S     canMsg;            //!< CAN message that was received
};
typedef struct CanSchedMsgs_ScMsgRcvNotify CanSchedMsgs_ScMsgRcvNotify_S;

// =============================================================================
//! @brief  union with all public Sciopta messages
// =============================================================================
union CanSchedMsgs_Msgs
{
  CanSchedMsgs_ScMsgRcvNotify_S rcvNotify;  //!< received CAN message
};
typedef union CanSchedMsgs_Msgs CanSchedMsgs_Msgs_U;



#endif // CANSCHEDMSGS_H

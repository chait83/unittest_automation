// *****************************************************************************
// **                _______   _________  _________   _______                 **
// **               (  ___  )  \__   __/  \__   __/  (  ____ \                **
// **               | (   ) |     ) (        ) (     | (    \/                **
// **               | |   | |     | |        | |     | (_____                 **
// **               | |   | |     | |        | |     (_____  )                **
// **               | |   | |     | |        | |           ) |                **
// **               | (___) |     | |     ___) (___  /\____) |                **
// **               (_______)     )_(     \_______/  \_______)                **
// **                                                                         **
// **                   Component Engineering Center Berlin                   **
// **                                                                         **
// **   Copyright 2017 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **
// **                                                                         **
// *****************************************************************************
//!
//! @file
//!
//! @ingroup grp_CanSchedInterface
//!
//! @brief  CAN scheduler interface
//!
//! @details
//!
//!   The CAN scheduler provides an interface for SRS processes and the
//!   nonSRS proxy to access the sciopta CAN driver.  Both have different
//!   msg ids to send requests to the scheduler.  This is necessary to
//!   priorise the SRS requests.
//!
//!
//! @reviewMinor
//!  * 2019-05-28 - HeLLo, GB, MHn
//!    * check for @c NULL pointers
// *****************************************************************************

#include <sciopta_sc.h>
#include "CanSched/Srs.h"
#include "CanSched/NonSrs.h"
#include "CanSched/Private/Msgs.h"
#include "Hlp/Msg.h"
#include "Cfg/MsgIds.h"
#include "Cfg/ProcNames.h"



// #############################################################################
// ## LOCAL TYPES ##############################################################
// #############################################################################

// -----------------------------------------------------------------------------
//! @brief  union sc_msg CanSched/CanSched.c
// -----------------------------------------------------------------------------
union sc_msg  // polyspace MISRA-C3:5.7 [To investigate:Medium] "CECBSAFETY-3050"
{
  sc_msgid_t                        scMsgId;   //!< Sciopta message ID
  CanSchedPrivateMsgs_PrivateMsgs_U canSched;  //!< CAN scheduler private messages
};


// #############################################################################
// ## LOCAL FUNCTION DECLARATIONS ##############################################
// #############################################################################

// -----------------------------------------------------------------------------
// User Interface Implementation
// -----------------------------------------------------------------------------
static CanSchedTypes_Error_E sharedAllocFilter(sc_pid_t                         canSchedPid,
                                               CanSchedTypes_CanChannel_T       channel,
                                               CanSchedTypes_CanFilterIndex_T * pFilterIndex,
                                               bool                             isSrs);

static CanSchedTypes_Error_E sharedSetFilter(sc_pid_t                          canSchedPid,
                                             CanSchedTypes_CanChannel_T        channel,
                                             CanSchedTypes_CanFilterIndex_T    filterIndex,
                                             size_t                            filterListLength,
                                             const CanSchedTypes_CanFilter_S * pFilterList,
                                             bool                              isSrs,
                                             bool                              isBlocking);

static CanSchedTypes_Error_E sharedFreeFilter(sc_pid_t                       canSchedPid,
                                              CanSchedTypes_CanChannel_T     channel,
                                              CanSchedTypes_CanFilterIndex_T filterIndex,
                                              bool                           isSrs);

static CanSchedTypes_Error_E sharedSend(sc_pid_t                       canSchedPid,
                                        CanSchedTypes_CanChannel_T     channel,
                                        const CanSchedTypes_CanMsg_S * pCanMsg,
                                        bool                           isSrs,
                                        bool                           isBlocking,
                                        bool                           isFire);





// #############################################################################
// ## EXTERN FUNCTIONS #########################################################
// #############################################################################



// #############################################################################
// All Interfaces
// #############################################################################

// =============================================================================
extern sc_pid_t CanSchedCanSched_GetPid(void)
{
  return sc_procIdGet(CfgProcNames_canSched, SC_NO_TMO);
}



// #############################################################################
// Non Safety Related Software Interface
// #############################################################################

#if 0
// =============================================================================
extern CanSchedTypes_Error_E CanSchedNonSrs_AllocFilter(sc_pid_t                         canSchedPid,
                                                        CanSchedTypes_CanChannel_T       channel,
                                                        CanSchedTypes_CanFilterIndex_T * pFilterIndex)
{
  return sharedAllocFilter(canSchedPid, channel, pFilterIndex, false);
}

// =============================================================================
extern CanSchedTypes_Error_E CanSchedNonSrs_SetFilterBlocking(sc_pid_t                          canSchedPid,
                                                              CanSchedTypes_CanChannel_T        channel,
                                                              CanSchedTypes_CanFilterIndex_T    filterIndex,
                                                              size_t                            filterListLength,
                                                              const CanSchedTypes_CanFilter_S * pFilterList)
{
  return sharedSetFilter(canSchedPid, channel, filterIndex, filterListLength, pFilterList, false, true);
}


// =============================================================================
extern CanSchedTypes_Error_E CanSchedNonSrs_SetFilterNonBlocking(sc_pid_t                          canSchedPid,
                                                                 CanSchedTypes_CanChannel_T        channel,
                                                                 CanSchedTypes_CanFilterIndex_T    filterIndex,
                                                                 size_t                            filterListLength,
                                                                 const CanSchedTypes_CanFilter_S * pFilterList)
{
  return sharedSetFilter(canSchedPid, channel, filterIndex, filterListLength, pFilterList, false, false);
}

// =============================================================================
extern CanSchedTypes_Error_E CanSchedNonSrs_FreeFilter(sc_pid_t                       canSchedPid,
                                                       CanSchedTypes_CanChannel_T     channel,
                                                       CanSchedTypes_CanFilterIndex_T filterIndex)
{
  return sharedFreeFilter(canSchedPid, channel, filterIndex, false);
}

// =============================================================================
extern CanSchedTypes_Error_E CanSchedNonSrs_SendBlocking(sc_pid_t                       canSchedPid,
                                                         CanSchedTypes_CanChannel_T     channel,
                                                         const CanSchedTypes_CanMsg_S * pCanMsg)
{
  return sharedSend(canSchedPid, channel, pCanMsg, false, true, false);
}

// =============================================================================
extern CanSchedTypes_Error_E CanSchedNonSrs_SendNonBlocking(sc_pid_t                       canSchedPid,
                                                            CanSchedTypes_CanChannel_T     channel,
                                                            const CanSchedTypes_CanMsg_S * pCanMsg)
{
  return sharedSend(canSchedPid, channel, pCanMsg, false, false, false);
}
#endif





// #############################################################################
// Safety Related Software Interface
// #############################################################################

// =============================================================================
CanSchedTypes_Error_E CanSchedSrs_AllocFilter(sc_pid_t                         canSchedPid,
                                                     CanSchedTypes_CanChannel_T       channel,
                                                     CanSchedTypes_CanFilterIndex_T * pFilterIndex)
{
  return sharedAllocFilter(canSchedPid, channel, pFilterIndex, true);
}


// =============================================================================
//! @reviewNice
//!  * 2019-05-28 - HeLLo, GB, MHn
//!    * add `extern`
//!    * ditto for other functions
CanSchedTypes_Error_E CanSchedSrs_SetFilterBlocking(sc_pid_t                          canSchedPid,
                                                           CanSchedTypes_CanChannel_T        channel,
                                                           CanSchedTypes_CanFilterIndex_T    filterIndex,
                                                           size_t                            filterListLength,
                                                           const CanSchedTypes_CanFilter_S * pFilterList)
{
  return sharedSetFilter(canSchedPid, channel, filterIndex, filterListLength, pFilterList, true, true);
}

#if 0
// =============================================================================
extern CanSchedTypes_Error_E CanSchedSrs_SetFilterNonBlocking(sc_pid_t                          canSchedPid,
                                                              CanSchedTypes_CanChannel_T        channel,
                                                              CanSchedTypes_CanFilterIndex_T    filterIndex,
                                                              size_t                            filterListLength,
                                                              const CanSchedTypes_CanFilter_S * pFilterList)
{
  return sharedSetFilter(canSchedPid, channel, filterIndex, filterListLength, pFilterList, true, false);
}
#endif

// =============================================================================
extern CanSchedTypes_Error_E CanSchedSrs_FreeFilter(sc_pid_t                       canSchedPid,
                                                    CanSchedTypes_CanChannel_T     channel,
                                                    CanSchedTypes_CanFilterIndex_T filterIndex)
{
  return sharedFreeFilter(canSchedPid, channel, filterIndex, true);
}


// =============================================================================
CanSchedTypes_Error_E CanSchedSrs_SendBlocking(sc_pid_t                       canSchedPid,
                                                      CanSchedTypes_CanChannel_T     channel,
                                                      const CanSchedTypes_CanMsg_S * pCanMsg)
{
  return sharedSend(canSchedPid, channel, pCanMsg, true, true, false);
}


// =============================================================================
extern CanSchedTypes_Error_E CanSchedSrs_SendFireAndForget(sc_pid_t                       canSchedPid,
                                                           CanSchedTypes_CanChannel_T     channel,
                                                           const CanSchedTypes_CanMsg_S * pCanMsg)
{
  return sharedSend(canSchedPid, channel, pCanMsg, true, false, true);
}


// =============================================================================
CanSchedTypes_Error_E CanSchedSrs_SendNonBlocking(sc_pid_t                       canSchedPid,
                                                         CanSchedTypes_CanChannel_T     channel,
                                                         const CanSchedTypes_CanMsg_S * pCanMsg)
{
  return sharedSend(canSchedPid, channel, pCanMsg, true, false, false);
}



// #############################################################################
// ## LOCAL FUNCTIONS ##########################################################
// #############################################################################


// #############################################################################
// User Interface Implementation
// #############################################################################


// =============================================================================
//! @brief  implements CanSchedSrs_AllocFilter() and CanSchedNonSrs_AllocFilter()
//!
//! @param [in]  canSchedPid   process ID of the CAN scheduler
//! @param [in]  channel       channel index
//! @param [out] pFilterIndex  filter index of allocated filter
//! @param [in]  isSrs         use safety relevant Sciopta message IDs
//!
//!
//! @details
//!
//!  This function sends the request to the CAN scheduler and waits for its
//!  response.
//!
//!  @p canSchedPid, @p channel and @p pFilterIndex are as described for the
//!  implemented functions.
//!
//!  @p isSrs decides with which Sciopta message IDs the requests are sent.
//!
//!
//! @return
//!
//!   Returns #CanSchedTypes_ERROR_SUCCESS on success.  Otherwise the return
//!   value indicates the source of the error.
//!
//! @reviewMinor
//!  * 2019-06-11 - HeLLo, GB, MHn
//!    * Add to the descriptions of CanSchedSrs_AllocFilter() and
//!      CanSchedNonSrs_AllocFilter(), that if @p pFilterIndex is @c NULL, the
//!      filter is allocated but not returned.
//!
//! @reviewMinor
//!  * 2019-06-11 - HeLLo, GB, MHn
//!    * Improvement:  Check @p pFilterIndex for @c NULL.  If this is the case,
//!      do not allocate the filter and return an error instead.
// =============================================================================
static CanSchedTypes_Error_E sharedAllocFilter(sc_pid_t                         canSchedPid,
                                               CanSchedTypes_CanChannel_T       channel,
                                               CanSchedTypes_CanFilterIndex_T * pFilterIndex,
                                               bool                             isSrs)
{
  sc_msg_t scMsg;
  CanSchedTypes_Error_E result;

  //! @todo TODO: [HeLLo] check parameters

  // fill
  scMsg = CanSchedPrivateMsgs_AllocCanAllocateFilter(SC_DEFAULT_POOL, SC_FATAL_IF_TMO, isSrs);
  scMsg->canSched.allocateFilter.channel      = channel;

  // send
  HlpMsg_TxRtrn(&scMsg, canSchedPid);
  if (scMsg != NULL)
  {
    sc_msgFree(&scMsg);
    result = CanSchedTypes_ERROR_INTERNAL_SCMSG_TX;
  }
  else
  {
    // wait for answer
    scMsg = HlpMsg_RxMP(SC_ENDLESS_TMO, CFGMSGIDS_CANSCHED_ALLOCATEFILTER_REPLY_MSGID, canSchedPid);
    result = scMsg->canSched.freeFilter.base.result;
    if (result == CanSchedTypes_ERROR_SUCCESS)
    {
      if (pFilterIndex != NULL)
      {
        *pFilterIndex = scMsg->canSched.freeFilter.filterIndex;
      }
    }
    sc_msgFree(&scMsg);
  }

  return result;
}


// =============================================================================
//! @brief  implements CanSchedSrs_SetFilterBlocking(),
//!                    CanSchedSrs_SetFilterNonBlocking(),
//!                    CanSchedNonSrs_SetFilterBlocking() and
//!                    CanSchedNonSrs_SetFilterNonBlocking()
//!
//! @param [in]  canSchedPid       process ID of the CAN scheduler
//! @param [in]  channel           channel index
//! @param [in]  filterIndex       filter index of to be programmed filter
//! @param [in]  filterListLength  number of elements in @c pFilterList
//! @param [in]  pFilterList       list of filters
//! @param [in]  isSrs             use safety relevant Sciopta message IDs
//! @param [in]  isBlocking        wait till the filter is active
//!
//!
//! @details
//!
//!  This function sends the request to the CAN scheduler and waits for its
//!  response.
//!
//!  @p canSchedPid, @p channel and @p filterIndex, @p filterListLength and
//!  @p pFilterList are as described for the implemented functions.
//!
//!  @p isSrs decides with which Sciopta message IDs the requests are sent.
//!
//!  @p isBlocking decides, if the function returns when the filter was
//!  successfully exchanged (@c true) or already when the request was stored in
//!  the queue (@c false).
//!
//!
//! @return
//!
//!   Returns #CanSchedTypes_ERROR_SUCCESS on success.  Otherwise the return
//!   value indicates the source of the error.
//!
// =============================================================================
static CanSchedTypes_Error_E sharedSetFilter(sc_pid_t                          canSchedPid,
                                             CanSchedTypes_CanChannel_T        channel,
                                             CanSchedTypes_CanFilterIndex_T    filterIndex,
                                             size_t                            filterListLength,
                                             const CanSchedTypes_CanFilter_S * pFilterList,
                                             bool                              isSrs,
                                             bool                              isBlocking)
{
  sc_msg_t scMsg;
  size_t idx;
  CanSchedTypes_Error_E result;

  //! @todo TODO: [HeLLo] check parameters

  // fill
  scMsg = CanSchedPrivateMsgs_AllocCanSetFilter(SC_DEFAULT_POOL, SC_FATAL_IF_TMO, isSrs, filterListLength);
  scMsg->canSched.setFilterRequest.isBlockingCall   = isBlocking;
  scMsg->canSched.setFilterRequest.channel          = channel;
  scMsg->canSched.setFilterRequest.filterIndex      = filterIndex;
  scMsg->canSched.setFilterRequest.filterListLength = filterListLength;
  for (idx = 0; idx < filterListLength; ++idx)  /* polyspace MISRA-C3:D4.14 [Not a defect:Low] "sufficient memory allocated with CanSchedPrivateMsgs_AllocCanSetFilter()" */
  {
    scMsg->canSched.setFilterRequest.filterList[idx] = pFilterList[idx];  /* polyspace MISRA-C3:D4.14 [Not a defect:Low] "sufficient memory allocated with CanSchedPrivateMsgs_AllocCanSetFilter()" */
  }

  // send
  HlpMsg_TxRtrn(&scMsg, canSchedPid);
  if (scMsg != NULL)
  {
    sc_msgFree(&scMsg);
    result = CanSchedTypes_ERROR_INTERNAL_SCMSG_TX;
  }
  else
  {
    // wait for answer
    scMsg  = HlpMsg_RxMP(SC_ENDLESS_TMO, CFGMSGIDS_CANSCHED_SETFILTER_REPLY_MSGID, canSchedPid);
    result = scMsg->canSched.setFilterReply.base.result;
    sc_msgFree(&scMsg);
  }

  return result;
}


// =============================================================================
//! @brief  implements CanSchedSrs_FreeFilter() and CanSchedNonSrs_FreeFilter()
//!
//! @param [in]  canSchedPid       process ID of the CAN scheduler
//! @param [in]  channel           channel index
//! @param [in]  filterIndex       filter index of to be freed filter
//! @param [in]  isSrs             use safety relevant Sciopta message IDs
//!
//!
//! @details
//!
//!  This function sends the request to the CAN scheduler and waits for its
//!  response.
//!
//!  @p canSchedPid, @p channel and @p filterIndex are as described for the
//!  implemented functions.
//!
//!  @p isSrs decides with which Sciopta message IDs the requests are sent.
//!
//!
//! @return
//!
//!   Returns #CanSchedTypes_ERROR_SUCCESS on success.  Otherwise the return
//!   value indicates the source of the error.
//!
// =============================================================================
static CanSchedTypes_Error_E sharedFreeFilter(sc_pid_t                       canSchedPid,
                                              CanSchedTypes_CanChannel_T     channel,
                                              CanSchedTypes_CanFilterIndex_T filterIndex,
                                              bool                           isSrs)
{
  sc_msg_t scMsg;
  CanSchedTypes_Error_E result;

  //! @todo TODO: [HeLLo] check parameters

  // fill
  scMsg = CanSchedPrivateMsgs_AllocCanFreeFilter(SC_DEFAULT_POOL, SC_FATAL_IF_TMO, isSrs);
  scMsg->canSched.freeFilter.channel      = channel;
  scMsg->canSched.freeFilter.filterIndex  = filterIndex;

  // send
  HlpMsg_TxRtrn(&scMsg, canSchedPid);
  if (scMsg != NULL)
  {
    sc_msgFree(&scMsg);
    result = CanSchedTypes_ERROR_INTERNAL_SCMSG_TX;
  }
  else
  {
    // wait for answer
    scMsg = HlpMsg_RxMP(SC_ENDLESS_TMO, CFGMSGIDS_CANSCHED_FREEFILTER_REPLY_MSGID, canSchedPid);
    result = scMsg->canSched.freeFilter.base.result;
    sc_msgFree(&scMsg);
  }

  return result;
}


// =============================================================================
//! @brief  implements CanSchedSrs_SendBlocking(),
//!                    CanSchedSrs_SendFireAndForget(),
//!                    CanSchedSrs_SendNonBlocking(),
//!                    CanSchedNonSrs_SendBlocking() and
//!                    CanSchedNonSrs_SendNonBlocking()
//!
//! @param [in]  canSchedPid       process ID of the CAN scheduler
//! @param [in]  channel           channel index
//! @param [in]  pCanMsg           to be sent CAN message
//! @param [in]  isSrs             use safety relevant Sciopta message IDs
//! @param [in]  isBlocking        wait till the CAN message is on the bus
//! @param [in]  isFire            disable reply and return immediately
//!
//!
//! @details
//!
//!  This function sends the request to the CAN scheduler and waits for its
//!  response.
//!
//!  @p canSchedPid, @p channel and @p pCanMsg are as described for the
//!  implemented functions.
//!
//!  @p isSrs decides with which Sciopta message IDs the requests are sent.
//!
//!  @p isBlocking decides, if the function returns when the message was
//!  successfully sent (@c true) or already when the request was stored in the
//!  queue (@c false).
//!
//!  @p isFire disables the waiting for a response.  Therefore the function
//!  returns immediately after sending the request to the CanSched.
//!
//!
//! @return
//!
//!   Returns #CanSchedTypes_ERROR_SUCCESS on success.  Otherwise the return
//!   value indicates the source of the error.
//!
// =============================================================================
static CanSchedTypes_Error_E sharedSend(sc_pid_t                       canSchedPid,
                                        CanSchedTypes_CanChannel_T     channel,
                                        const CanSchedTypes_CanMsg_S * pCanMsg,
                                        bool                           isSrs,
                                        bool                           isBlocking,
                                        bool                           isFire)
{
  sc_msg_t scMsg;
  CanSchedTypes_Error_E result = CanSchedTypes_ERROR_FAILURE;

  //! @todo TODO: [HeLLo] check parameters
  
  if (pCanMsg != NULL)
  {
    // fill
    scMsg = CanSchedPrivateMsgs_AllocCanSend(SC_DEFAULT_POOL, SC_FATAL_IF_TMO, isSrs, isFire);
    scMsg->canSched.send.isBlockingCall = isBlocking;
    scMsg->canSched.send.channel        = channel;
    scMsg->canSched.send.canMsg         = *pCanMsg;  // polyspace MISRA-C3:D4.14 [To investigate:Medium] "CECBSAFETY-3068"  // polyspace ISO-17961:nullref [Not a defect:Low] "pointer is checked for NULL"  // polyspace ISO-17961:taintformatio [Not a defect:Low] "pointer is checked for NULL"

    // send
    HlpMsg_TxRtrn(&scMsg, canSchedPid);
    if (scMsg != NULL)
    {
      sc_msgFree(&scMsg);
      result = CanSchedTypes_ERROR_INTERNAL_SCMSG_TX;
    }
    else if (isFire == false)
    {
      // wait for answer
      scMsg  = HlpMsg_RxMP(SC_ENDLESS_TMO, CFGMSGIDS_CANSCHED_SEND_REPLY_MSGID, canSchedPid);
      result = scMsg->canSched.send.base.result;
      sc_msgFree(&scMsg);
    }
    else
    {
      // fire and forget --> don't wait for an answer
      result = CanSchedTypes_ERROR_SUCCESS;
    }
  }
  
  return result;
}

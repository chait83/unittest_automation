// *****************************************************************************
// **                _______   _________  _________   _______                 **
// **               (  ___  )  \__   __/  \__   __/  (  ____ \                **
// **               | (   ) |     ) (        ) (     | (    \/                **
// **               | |   | |     | |        | |     | (_____                 **
// **               | |   | |     | |        | |     (_____  )                **
// **               | |   | |     | |        | |           ) |                **
// **               | (___) |     | |     ___) (___  /\____) |                **
// **               (_______)     )_(     \_______/  \_______)                **
// **                                                                         **
// **                   Component Engineering Center Berlin                   **
// **                                                                         **
// **   Copyright 2017 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **
// **                                                                         **
// *****************************************************************************
//!
//! @file
//!
//! @ingroup grp_CanSchedPrivate
//!
//! @brief  functions that ease interaction with Sciopta driver
//!
// *****************************************************************************

#ifndef CANSCHEDPRIVATEDRIVER_H
#define CANSCHEDPRIVATEDRIVER_H

#include "CanSched/Types.h"
#include "CanSched/Private/Types.h"


// =============================================================================
//! @brief  open the device
//!
//! @param [in,out] pChannel  CAN channel object
//! @param [in]     pDevMan   sdd device manager
//!
//!
//! @details
//!
//!   This function opens the device of @p pChannel' to allow future interaction
//!   with the Sciopta driver.  Therefore `*pDevMan` is used to interact with
//!   the device manager.
//!
//!   The functions blocks until the driver has performed the request.
//!
//!
//! @return
//!
//!   The function returns #CanSchedTypes_ERROR_SUCCESS when the device was
//!   successfully opened.  All other values indicate an error.
//!
// =============================================================================
extern CanSchedTypes_Error_E CanSchedPrivateDriver_OpenBlocking(CanSchedPrivateTypes_Channel_S * pChannel,  // polyspace DEFECT:DECL_MISMATCH [To investigate:Medium] "CECBSAFETY-3063"  // polyspace MISRA-C3:8.3 [To investigate:Medium] "CECBSAFETY-3063"  // polyspace ISO-17961:argcomp [To investigate:Medium] "CECBSAFETY-3098"  // polyspace ISO-17961:funcdecl [To investigate:Medium] "CECBSAFETY-3100"
                                                                sdd_obj_t **                     pDevMan);


// =============================================================================
//! @brief  disable CAN reception
//!
//! @param [in,out] pChannel  CAN channel object
//!
//!
//! @details
//!
//!   This function disables CAN reception of channel @p pChannel in the Sciopta
//!   driver.
//!
//!   The functions blocks until the driver has performed the request.
//!
//!
//! @return
//!
//!   When an error occurred, a value different than #CanSchedTypes_ERROR_SUCCESS
//!   is returned.
//!
// =============================================================================
extern CanSchedTypes_Error_E CanSchedPrivateDriver_DisableReadBlocking(CanSchedPrivateTypes_Channel_S * pChannel);  // polyspace DEFECT:DECL_MISMATCH [To investigate:Medium] "CECBSAFETY-3063"  // polyspace MISRA-C3:8.3 [To investigate:Medium] "CECBSAFETY-3051"  // polyspace ISO-17961:argcomp [To investigate:Medium] "CECBSAFETY-3098"  // polyspace ISO-17961:funcdecl [To investigate:Medium] "CECBSAFETY-3100"


// =============================================================================
//! @brief  enable CAN reception
//!
//! @param [in,out] pChannel  CAN channel object
//!
//!
//! @details
//!
//!   This function enables CAN reception of channel @p pChannel in the Sciopta
//!   driver.
//!
//!   The functions blocks until the driver has performed the request.
//!
//!
//! @return
//!
//!   When an error occurred, a value different than #CanSchedTypes_ERROR_SUCCESS
//!   is returned.
//!
// =============================================================================
extern CanSchedTypes_Error_E CanSchedPrivateDriver_EnableReadBlocking(CanSchedPrivateTypes_Channel_S * pChannel);  // polyspace DEFECT:DECL_MISMATCH [To investigate:Medium] "CECBSAFETY-3063"  // polyspace MISRA-C3:8.3 [To investigate:Medium] "CECBSAFETY-3051"  // polyspace ISO-17961:argcomp [To investigate:Medium] "CECBSAFETY-3098"  // polyspace ISO-17961:funcdecl [To investigate:Medium] "CECBSAFETY-3100"


// =============================================================================
//! @brief  set baud rate
//!
//! @param [in,out] pChannel  CAN channel object
//!
//!
//! @details
//!
//!   This function sets a new baud rate `pChannel->baud` for channel @p pChannel
//!   in the Sciopta driver.
//!
//!   The functions blocks until the driver has performed the request.
//!
//!
//! @return
//!
//!   When an error occurred, a value different than #CanSchedTypes_ERROR_SUCCESS
//!   is returned.
//!
// =============================================================================
extern CanSchedTypes_Error_E CanSchedPrivateDriver_SetBaudBlocking(CanSchedPrivateTypes_Channel_S * pChannel);  // polyspace DEFECT:DECL_MISMATCH [To investigate:Medium] "CECBSAFETY-3063"  // polyspace MISRA-C3:8.3 [To investigate:Medium] "CECBSAFETY-3051"  // polyspace ISO-17961:argcomp [To investigate:Medium] "CECBSAFETY-3098"  // polyspace ISO-17961:funcdecl [To investigate:Medium] "CECBSAFETY-3100"


// =============================================================================
//! @brief  validate current baud rate
//!
//! @param [in,out] pChannel  CAN channel object
//!
//!
//! @details
//!
//!   This function reads the current baud rate for channel @p pChannel from the
//!   Sciopta driver and compares the result with `pChannel->baud`.
//!
//!   The functions blocks until the driver has performed the request.
//!
//!
//! @return
//!
//!   The function returns #CanSchedTypes_ERROR_SUCCESS when the read baud rate
//!   is equal to the baud rate in `pChannel->baud`.  All other values indicate
//!   an error.
//!
// =============================================================================
extern CanSchedTypes_Error_E CanSchedPrivateDriver_CmpBaudBlocking(CanSchedPrivateTypes_Channel_S * pChannel);


// =============================================================================
//! @brief  installs filters in Sciopta driver
//!
//! @param [in,out] pChannel  CAN channel object
//!
//!
//! @details
//!
//!   This function renews all filters of channel @p pChannel in the Sciopta
//!   driver.
//!
//!   The functions blocks until the driver has performed the request.
//!
//!
//! @return
//!
//!   When an error occurred, a value different than #CanSchedTypes_ERROR_SUCCESS
//!   is returned.
//!
// =============================================================================
extern CanSchedTypes_Error_E CanSchedPrivateDriver_SetFilterBlocking(CanSchedPrivateTypes_Channel_S * pChannel);  // polyspace DEFECT:DECL_MISMATCH [To investigate:Medium] "CECBSAFETY-3063"  // polyspace MISRA-C3:8.3 [To investigate:Medium] "CECBSAFETY-3051"  // polyspace ISO-17961:argcomp [To investigate:Medium] "CECBSAFETY-3098"  // polyspace ISO-17961:funcdecl [To investigate:Medium] "CECBSAFETY-3100"


// =============================================================================
//! @brief  start CAN message transmission
//!
//! @param [in,out] pChannel  CAN channel object
//! @param [in]     pCanMsg   to be sent CAN message
//!
//!
//! @details
//!
//!   This function requests the Sciopta driver for channel @p pChannel to send
//!   the CAN message @p pCanMsg.  The function returns immediately as when the
//!   request is sent to the driver.
//!
//!   The function does not wait for the response.  The caller is responsible to
//!   handle the reply of the CAN driver.
//!
//!
//! @return
//!
//!   The function returns #CanSchedTypes_ERROR_SUCCESS when the request was
//!   successfully sent to the driver.  All other values indicate an error.
// =============================================================================
extern CanSchedTypes_Error_E CanSchedPrivateDriver_SendTx(CanSchedPrivateTypes_Channel_S * pChannel,  // polyspace DEFECT:DECL_MISMATCH [To investigate:Medium] "CECBSAFETY-3063"  // polyspace MISRA-C3:8.3 [To investigate:Medium] "CECBSAFETY-3051"  // polyspace ISO-17961:argcomp [To investigate:Medium] "CECBSAFETY-3098"  // polyspace ISO-17961:funcdecl [To investigate:Medium] "CECBSAFETY-3100"
                                                          CanSchedTypes_CanMsg_S *         pCanMsg);



#endif // CANSCHEDPRIVATEDRIVER_H

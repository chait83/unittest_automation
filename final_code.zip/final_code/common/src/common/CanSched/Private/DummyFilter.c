// *****************************************************************************
// **                _______   _________  _________   _______                 **
// **               (  ___  )  \__   __/  \__   __/  (  ____ \                **
// **               | (   ) |     ) (        ) (     | (    \/                **
// **               | |   | |     | |        | |     | (_____                 **
// **               | |   | |     | |        | |     (_____  )                **
// **               | |   | |     | |        | |           ) |                **
// **               | (___) |     | |     ___) (___  /\____) |                **
// **               (_______)     )_(     \_______/  \_______)                **
// **                                                                         **
// **                   Component Engineering Center Berlin                   **
// **                                                                         **
// **   Copyright 2017 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **
// **                                                                         **
// *****************************************************************************
//!
//! @file CanSched/Private/DummyFilter.c
//!
//! @ingroup grp_CanSchedPrivate
//!
//! @brief  CAN scheduler dummy filter implementation
//!
// *****************************************************************************


#include "CanSched/Private/DummyFilter.h"


//! @reviewMinor
//!  * 2019-06-11 - HeLLo, GB, MHn
//!    * This filter seems to accept the CAN ID 0.  It should accept no CAN
//!      messages at all.
const sdd_canFilterType_t CanSchedPrivateDummyFilter_dummyFilter =
{
    .flags = CAN_FILTER_FLAG_EXTENDED,
    .canId = 0,
    .canMf = 0xFFFFFFFFUL
};

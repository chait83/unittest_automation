// *****************************************************************************
// **                _______   _________  _________   _______                 **
// **               (  ___  )  \__   __/  \__   __/  (  ____ \                **
// **               | (   ) |     ) (        ) (     | (    \/                **
// **               | |   | |     | |        | |     | (_____                 **
// **               | |   | |     | |        | |     (_____  )                **
// **               | |   | |     | |        | |           ) |                **
// **               | (___) |     | |     ___) (___  /\____) |                **
// **               (_______)     )_(     \_______/  \_______)                **
// **                                                                         **
// **                   Component Engineering Center Berlin                   **
// **                                                                         **
// **   Copyright 2017 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **
// **                                                                         **
// *****************************************************************************
//!
//! @file CanSched/Private/SendQueue.h
//!
//! @ingroup grp_CanSchedPrivate
//!
//! @brief  Send queue for the CAN scheduler.
//!
//!
//! @details
//!
//!   The queue is implemented as a linked list.  The first element in the
//!   list is always the one with the highest priority (lowest CAN ID).
//!   When multiple messages with the same ID are in the list, the order in
//!   the list indicates the order of their insertion.
//!
//!   Standard and extended IDs are mixed.  So inserting an extended ID 15
//!   and afterwards an standard ID 15 will result in a list that has as a
//!   first element extended ID 15 and as the second element standard ID
//!   15.
//!
//!   Vice versa inserting an standard ID 15 and afterwards an extended ID
//!   15 will result in a list that has as a first element standard ID 15
//!   and as the second element extended ID 15.
// *****************************************************************************
#ifndef CANSCHEDPRIVATESENDQUEUE_H
#define CANSCHEDPRIVATESENDQUEUE_H

#include <sciopta_sc.h>
#include "CanSched/Types.h"
#include "CanSched/Private/Types.h"


// =============================================================================
//! @brief  initialize empty send queue
//!
//! @param [out] pQueue  to be initialized send queue
//!
//!
//! @details
//!
//!   This function initializes the queue @p pQueue as an empty queue.
//!
// =============================================================================
extern void CanSchedPrivateSendQueue_Init(CanSchedPrivateTypes_SendQueue_S * pQueue);  // polyspace DEFECT:DECL_MISMATCH [To investigate:Medium] "CECBSAFETY-3063"  // polyspace MISRA-C3:8.3 [To investigate:Medium] "CECBSAFETY-3063"  // polyspace ISO-17961:argcomp [To investigate:Medium] "CECBSAFETY-3098"  // polyspace ISO-17961:funcdecl [To investigate:Medium] "CECBSAFETY-3100"


// =============================================================================
//! @brief  insert a send request into send queue
//!
//! @details
//!
//!   This function inserts the sending request @p pRequest into the sending queue
//!   @p pQueue.
//!
//!   @p pRequest shall point to a Sciopta message of type
//!   #CanSchedTypesMsgs_ScMsgSendRequest_S.
//!
//!   If the insertion was successful, @p pRequest is @c NULL after the call.
//!
//!   The insertion is sorted according the CAN ID -- highest priority first,
//!   lowest priority last.  If a message with the same CAN ID is already in the
//!   queue, the new one is inserted after all old ones with the same CAN ID.
//!   Standard and extended IDs are not distinguished.
//!
//!
//! @return
//!
//!   If the new request was successfully placed into the queue,
//!   #CanSchedTypes_ERROR_SUCCESS is returned.  All other return values
//!   indicate an error.
//!
// =============================================================================
extern CanSchedTypes_Error_E CanSchedPrivateSendQueue_Insert(CanSchedPrivateTypes_SendQueue_S * pQueue, sc_msg_t * pRequest);  // polyspace DEFECT:DECL_MISMATCH [To investigate:Medium] "CECBSAFETY-3063"  // polyspace MISRA-C3:8.3 [To investigate:Medium] "CECBSAFETY-3051"  // polyspace ISO-17961:argcomp [To investigate:Medium] "CECBSAFETY-3098"  // polyspace ISO-17961:funcdecl [To investigate:Medium] "CECBSAFETY-3100"


// =============================================================================
//! @brief  remove first element in queue and return it
//!
//! @param [in,out] pQueue  queue
//!
//!
//! @details
//!
//!   This function removes the first element in the send queue @p pQueue and
//!   returns it to the caller.  The caller is responsible for freeing the
//!   returned Sciopta message.
//!
//!
//! @return
//!
//!   If there was no element in the list, @c NULL is returned.  Otherwise the
//!   return value is a Sciopta Message of type
//!   #CanSchedTypesMsgs_ScMsgSendRequest_S.
//!
// =============================================================================
extern sc_msg_t CanSchedPrivateSendQueue_Pop(CanSchedPrivateTypes_SendQueue_S * pQueue);  // polyspace DEFECT:DECL_MISMATCH [To investigate:Medium] "CECBSAFETY-3063"  // polyspace MISRA-C3:8.3 [To investigate:Medium] "CECBSAFETY-3051"  // polyspace ISO-17961:argcomp [To investigate:Medium] "CECBSAFETY-3098"  // polyspace ISO-17961:funcdecl [To investigate:Medium] "CECBSAFETY-3100"


// =============================================================================
//! @brief  return the first element of the queue
//!
//! @param [in,out] pQueue  queue
//!
//!
//! @details
//!
//!   This function returns a pointer to the first request in the send queue
//!   @p pQueue without removing it from the list.  The caller shall not modify or
//!   free the Sciopta message.
//!
//!
//! @return
//!
//!   If there was no element in the list, @p NULL is returned.  Otherwise the
//!   return value is a pointer to a Sciopta Message of type
//!   #CanSchedTypesMsgs_ScMsgSendRequest_S.
//!
// =============================================================================
extern const sc_msg_t * CanSchedPrivateSendQueue_Peek(CanSchedPrivateTypes_SendQueue_S * pQueue);  // polyspace DEFECT:DECL_MISMATCH [To investigate:Medium] "CECBSAFETY-3063"  // polyspace MISRA-C3:8.3 [To investigate:Medium] "CECBSAFETY-3051"  // polyspace ISO-17961:argcomp [To investigate:Medium] "CECBSAFETY-3098"  // polyspace ISO-17961:funcdecl [To investigate:Medium] "CECBSAFETY-3100"


#endif // CANSCHEDPRIVATESENDQUEUE_H

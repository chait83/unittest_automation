// *****************************************************************************
// **                _______   _________  _________   _______                 **
// **               (  ___  )  \__   __/  \__   __/  (  ____ \                **
// **               | (   ) |     ) (        ) (     | (    \/                **
// **               | |   | |     | |        | |     | (_____                 **
// **               | |   | |     | |        | |     (_____  )                **
// **               | |   | |     | |        | |           ) |                **
// **               | (___) |     | |     ___) (___  /\____) |                **
// **               (_______)     )_(     \_______/  \_______)                **
// **                                                                         **
// **                   Component Engineering Center Berlin                   **
// **                                                                         **
// **   Copyright 2017 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **
// **                                                                         **
// *****************************************************************************
//!
//! @file CanSched/Private/Driver.c
//!
//! @ingroup grp_CanSchedPrivate
//!
//! @brief  implementation driver handling
//!
// *****************************************************************************


#include "CanSched/Private/Driver.h"
#include "Hlp/Msg.h"
#include <sys/fcntl.h>
#include <string.h>


// #############################################################################
// ## LOCAL TYPES ##############################################################
// #############################################################################

//! @brief  union sc_msg CanSched/Private/Channel.c
union sc_msg  // polyspace MISRA-C3:5.7 [To investigate:Medium] "CECBSAFETY-3050"
{
  sc_msgid_t           scMsgId;           //!< Sciopta message ID
  sdd_baseMessage_t    sddBase;           //!< driver message base
  sdd_canFilter_t      sddCanFilter;      //!< driver request/reply set filter
  sdd_canReadDisable_t sddCanReadDisable; //!< driver request/reply read disable
  sdd_canReadEnable_t  sddCanReadEnable;  //!< driver request/reply read enable
  sdd_canWrite_t       sddCanWrite;       //!< driver request/reply sending
};


// #############################################################################
// ## LOCAL FUNCTION DECLARATIONS ##############################################
// #############################################################################
static sc_msg_t allocClrSddCanReadEnable (sc_poolid_t pool, sc_ticks_t tmo);
static sc_msg_t allocClrSddCanReadDisable(sc_poolid_t pool, sc_ticks_t tmo);
static sc_msg_t allocClrSddCanFilter     (sc_poolid_t pool, sc_ticks_t tmo, size_t n);
static sc_msg_t allocClrSddCanWrite      (sc_poolid_t pool, sc_ticks_t tmo, size_t dataLength);





// #############################################################################
// ## EXTERN FUNCTIONS #########################################################
// #############################################################################

// =============================================================================
extern CanSchedTypes_Error_E CanSchedPrivateDriver_OpenBlocking(CanSchedPrivateTypes_Channel_S * pChannel,
                                                                sdd_obj_t **                     pDevMan)
{
  CanSchedTypes_Error_E result;
  uint32_t         waitCount    = 0U;
  const uint32_t   waitCountMax = 4U;
  const sc_ticks_t waitTicks    = sc_tickMs2Tick(5U);

  if ( NULL == pChannel  ||  NULL == pDevMan )
  {
    HlpFailure_EndlessLoop();
#ifdef __clang_analyzer__
    __builtin_unreachable();
#endif
  }

  // Retry finding the interface.  This is necessary, if the driver processes
  // run with a lower priority than the CanScheduler.  In this case, the drivers
  // have not connected to the device manager yet.
  while (waitCount < waitCountMax)
  {
    waitCount++;

    pChannel->pDev = sdd_manGetByName(*pDevMan, pChannel->interface);
    if (pChannel->pDev != NULL)
    {
      break;
    }
    else
    {
      sc_sleep(waitTicks);
    }
  }

  if (pChannel->pDev == NULL)
  {
    result = CanSchedTypes_ERROR_FAILURE;
  }
  else if (sdd_devOpen(pChannel->pDev, O_RDWR) == -1)
  {
    // ?? free dev?
    //! @reviewMinor
    //!  * 2019-06-11 - HeLLo, GB, MHn
    //!    * Explain the comment above better.
    result = CanSchedTypes_ERROR_FAILURE;
  }
  else
  {
    result = CanSchedTypes_ERROR_SUCCESS;
  }

  return result;
}


// =============================================================================
extern CanSchedTypes_Error_E CanSchedPrivateDriver_SetBaudBlocking(CanSchedPrivateTypes_Channel_S * pChannel)
{
  CanSchedTypes_Error_E result;
  int ret;

  if ( NULL == pChannel )
  {
    HlpFailure_EndlessLoop();
#ifdef __clang_analyzer__
    __builtin_unreachable();
#endif
  }

  ret = sdd_devIoctl(pChannel->pDev, IOCTL_CAN_SETBAUD, pChannel->baud);
  if (ret < 0)
  {
    result = CanSchedTypes_ERROR_FAILURE;
  }
  else
  {
    result = CanSchedTypes_ERROR_SUCCESS;
  }

  return result;
}


#if 0
// =============================================================================
extern CanSchedTypes_Error_E CanSchedPrivateDriver_CmpBaudBlocking(CanSchedPrivateTypes_Channel_S * pChannel)
{
  CanSchedTypes_Error_E result;
  int ret;
  
  if (pChannel != NULL)
  {
    ret = sdd_devIoctl(pChannel->pDev, IOCTL_CAN_GETBAUD, 0);
    if (ret < 0)
    {
      result = CanSchedTypes_ERROR_FAILURE;
    }
    else if ((uint8_t)ret != pChannel->baud)
    {
      result = CanSchedTypes_ERROR_FAILURE;
    }
    else
    {
      result = CanSchedTypes_ERROR_SUCCESS;
    }
  }
  else
  {
    result = CanSchedTypes_ERROR_FAILURE;
  }
  
  return result;
}
#endif

// =============================================================================
extern CanSchedTypes_Error_E CanSchedPrivateDriver_SetFilterBlocking(CanSchedPrivateTypes_Channel_S * pChannel)
{
  sc_msg_t              scMsg;
  CanSchedTypes_Error_E result;
  size_t                idx;

  if (    (NULL == pChannel)
      ||  (pChannel->mailboxesUsed > sizeof(pChannel->mailbox)/sizeof(*pChannel->mailbox))
     )
  {
    HlpFailure_EndlessLoop();
#ifdef __clang_analyzer__
    __builtin_unreachable();
#endif
  }

  scMsg = allocClrSddCanFilter(SC_DEFAULT_POOL, SC_ENDLESS_TMO, pChannel->mailboxesUsed);
  scMsg->sddCanFilter.n = (int)pChannel->mailboxesUsed;

  for (idx = 0; idx < pChannel->mailboxesUsed; ++idx)
  {
    scMsg->sddCanFilter.idMf[idx] = pChannel->mailbox[idx].programmedFilter;
  }

  HlpMsg_TxRtrn(&scMsg, pChannel->pDev->controller);
  if (scMsg != NULL)
  {
    sc_msgFree(&scMsg);
    result = CanSchedTypes_ERROR_INTERNAL_SCMSG_TX;
  }
  else
  {
    scMsg = HlpMsg_RxMP(SC_ENDLESS_TMO, SDD_CAN_FILTER_REPLY, pChannel->pDev->controller);
    if(scMsg->sddBase.error != 0)
    {
      result = CanSchedTypes_ERROR_FAILURE;
    }
    else
    {
      result = CanSchedTypes_ERROR_SUCCESS;
    }

    sc_msgFree(&scMsg);
  }

  return result;
}


// =============================================================================
extern CanSchedTypes_Error_E CanSchedPrivateDriver_DisableReadBlocking(CanSchedPrivateTypes_Channel_S * pChannel)
{
  sc_msg_t              scMsg;
  CanSchedTypes_Error_E result;

  scMsg = allocClrSddCanReadDisable(SC_DEFAULT_POOL, SC_FATAL_IF_TMO);

  HlpMsg_TxRtrn(&scMsg, pChannel->pDev->receiver);
  if (scMsg != NULL)
  {
    sc_msgFree(&scMsg);
    result = CanSchedTypes_ERROR_INTERNAL_SCMSG_TX;
  }
  else
  {
    scMsg = HlpMsg_RxMP(SC_ENDLESS_TMO, SDD_CAN_READ_DISABLE_REPLY, pChannel->pDev->receiver);

    if (scMsg->sddBase.error != 0)
    {
      result = CanSchedTypes_ERROR_FAILURE;
    }
    else
    {
      result = CanSchedTypes_ERROR_SUCCESS;
    }

    sc_msgFree(&scMsg);
  }

  return result;
}


// =============================================================================
extern CanSchedTypes_Error_E CanSchedPrivateDriver_EnableReadBlocking(CanSchedPrivateTypes_Channel_S * pChannel)
{
  sc_msg_t              scMsg;
  CanSchedTypes_Error_E result;

  if ( NULL == pChannel )
  {
    HlpFailure_EndlessLoop();
#ifdef __clang_analyzer__
    __builtin_unreachable();
#endif
  }

  scMsg = allocClrSddCanReadEnable(SC_DEFAULT_POOL, SC_FATAL_IF_TMO);

  HlpMsg_TxRtrn(&scMsg, pChannel->pDev->receiver);
  if (scMsg != NULL)
  {
    sc_msgFree(&scMsg);
    result = CanSchedTypes_ERROR_INTERNAL_SCMSG_TX;
  }
  else
  {
    scMsg = HlpMsg_RxMP(SC_ENDLESS_TMO, SDD_CAN_READ_ENABLE_REPLY, pChannel->pDev->receiver);

    if (scMsg->sddBase.error != 0)
    {
      result = CanSchedTypes_ERROR_FAILURE;
    }
    else
    {
      result = CanSchedTypes_ERROR_SUCCESS;
    }

    sc_msgFree(&scMsg);
  }

  return result;
}


// =============================================================================
extern CanSchedTypes_Error_E CanSchedPrivateDriver_SendTx(CanSchedPrivateTypes_Channel_S * pChannel,
                                                          CanSchedTypes_CanMsg_S *         pCanMsg)
{
  sc_msg_t              scMsg;
  CanSchedTypes_Error_E result;

  if ( NULL == pChannel  ||  NULL == pCanMsg )
  {
    HlpFailure_EndlessLoop();
#ifdef __clang_analyzer__
    __builtin_unreachable();
#endif
    result = CanSchedTypes_ERROR_FAILURE;  // never reached
  }
  else
  {
    if (pCanMsg->dataLen > 8)
    {
      result = CanSchedTypes_ERROR_CAN_DATA_LENGTH;
    }
    else
    {
      scMsg = allocClrSddCanWrite(SC_DEFAULT_POOL, SC_FATAL_IF_TMO, pCanMsg->dataLen);

      scMsg->sddCanWrite.size = (ssize_t)pCanMsg->dataLen;
      if (pCanMsg->protocol == CanSchedTypes_PROTOCOL_EXTENDED)
      {
        scMsg->sddCanWrite.extended = 1;
      }
      else
      {
        scMsg->sddCanWrite.extended = 0;
      }
      scMsg->sddCanWrite.canId = pCanMsg->canId;
      memcpy(scMsg->sddCanWrite.inlineBuf, pCanMsg->data.u8, pCanMsg->dataLen);

      HlpMsg_TxRtrn(&scMsg, pChannel->pDev->sender);
      if (scMsg != NULL)
      {
        sc_msgFree(&scMsg);
        result = CanSchedTypes_ERROR_FAILURE;
      }
      else
      {
        result = CanSchedTypes_ERROR_SUCCESS;
      }
    }
  }

  return result;
}





// #############################################################################
// ## IMPLEMENTATION LOCAL FUNCTIONS ###########################################
// #############################################################################

// =============================================================================
//! @brief  allocate a cleared message with correct size and scMsg id
//!
//! @param [in] pool   Sciopta message pool
//! @param [in] tmo    maximal timeout
//!
//!
//! @details
//!
//!   The function allocates a Sciopta message from the message pool @p pool of
//!   type #sdd_canReadEnable_t.  @p tmo defines the timeout for the
//!   sc_msgAlloc() function.
//!
//!
//! @retval NULL    no message allocated
//! @retval <else>  allocated message
//!
// =============================================================================
static sc_msg_t allocClrSddCanReadEnable(sc_poolid_t pool, sc_ticks_t tmo)
{
  return sc_msgAllocClr(sizeof(sdd_canReadEnable_t), SDD_CAN_READ_ENABLE, pool, tmo);
}

// =============================================================================
//! @brief  allocate a cleared message with correct size and scMsg id
//!
//! @param [in] pool   Sciopta message pool
//! @param [in] tmo    maximal timeout
//!
//!
//! @details
//!
//!   The function allocates a Sciopta message from the message pool @p pool of
//!   type #sdd_canReadDisable_t.  @p tmo defines the timeout for the
//!   sc_msgAlloc() function.
//!
//!
//! @retval NULL    no message allocated
//! @retval <else>  allocated message
//!
// =============================================================================
static sc_msg_t allocClrSddCanReadDisable(sc_poolid_t pool, sc_ticks_t tmo)
{
  return sc_msgAllocClr(sizeof(sdd_canReadDisable_t), SDD_CAN_READ_DISABLE, pool, tmo);
}

// =============================================================================
//! @brief  allocate a cleared message with correct size and scMsg id
//!
//! @param [in] pool   Sciopta message pool
//! @param [in] tmo    maximal timeout
//! @param [in] n      length of `sddCanFilter.idMf`
//!
//!
//! @details
//!
//!   The function allocates a Sciopta message from the message pool @p pool of
//!   type #sdd_canFilter_t.  @p tmo defines the timeout for the sc_msgAlloc()
//!   function.
//!
//!   @p n defines the number of members in `sddCanFilter.idMf`.
//!
//!
//! @retval NULL    no message allocated
//! @retval <else>  allocated message
//!
// =============================================================================
static sc_msg_t allocClrSddCanFilter(sc_poolid_t pool, sc_ticks_t tmo, size_t n)
{
  size_t size = sizeof(sdd_canFilter_t)
              + (n - 1) * sizeof(sdd_canFilterType_t);

  return sc_msgAllocClr(size, SDD_CAN_FILTER, pool, tmo);
}

// =============================================================================
//! @brief  allocate a cleared message with correct size and scMsg id
//!
//! @param [in] pool        Sciopta message pool
//! @param [in] tmo         maximal timeout
//! @param [in] dataLength  length of inlineBuf
//!
//!
//! @details
//!
//!   The function allocates a Sciopta message from the message pool @p pool of
//!   type #sdd_canWrite_t.  @p tmo defines the timeout for the sc_msgAlloc()
//!   function.
//!
//!   @p dataLength defines the number of members in `sddCanWrite.inlineBuf`.
//!
//!
//! @retval NULL    no message allocated
//! @retval <else>  allocated message
//!
//! @reviewMinor
//!  * 2019-06-11 - HeLLo, GB, MHn
//!    * In `sdd_canWrite_t` is already 1 byte reserved for the `inlineBuf`.
//!      Therefore `(dataLength - 1)` would be sufficient.
// =============================================================================
static sc_msg_t allocClrSddCanWrite(sc_poolid_t pool, sc_ticks_t tmo, size_t dataLength)
{
  size_t size = sizeof(sdd_canWrite_t)
              + dataLength * sizeof(uint8_t);

  return sc_msgAllocClr(size, SDD_CAN_WRITE, pool, tmo);
}

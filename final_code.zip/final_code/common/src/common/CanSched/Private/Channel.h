// *****************************************************************************
// **                _______   _________  _________   _______                 **
// **               (  ___  )  \__   __/  \__   __/  (  ____ \                **
// **               | (   ) |     ) (        ) (     | (    \/                **
// **               | |   | |     | |        | |     | (_____                 **
// **               | |   | |     | |        | |     (_____  )                **
// **               | |   | |     | |        | |           ) |                **
// **               | (___) |     | |     ___) (___  /\____) |                **
// **               (_______)     )_(     \_______/  \_______)                **
// **                                                                         **
// **                   Component Engineering Center Berlin                   **
// **                                                                         **
// **   Copyright 2017 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **
// **                                                                         **
// *****************************************************************************

//!
//! @file
//!
//! @ingroup grp_CanSchedPrivate
//!
//! @brief  CAN scheduler channel interface
//!

#ifndef CANSCHEDPRIVATECHANNEL_H
#define CANSCHEDPRIVATECHANNEL_H

#include "CanSched/Types.h"
#include "CanSched/Private/Types.h"


// =============================================================================
//! @brief  initialize CAN channel
//!
//! @param [in]  pSelf          CAN scheduler process variables
//! @param [out] pChannel       to be initialized channel
//! @param [in]  unitIdx        index of hardware unit
//! @param [in]  baud           baud rate of the CAN bus
//! @param [in]  interface      name of the device interface
//! @param [in]  mailboxesUsed  number of available mailboxes
//! @param [in]  mailboxesSrs   number of for safety software reserved mailboxes
//!
//!
//! @details
//!
//!   The members `pSelf->logd` and `pSelf->devMan` of @p pSelf shall be
//!   initialized before this call.
//!
//!   Initializes the channel @p pChannels.  The device (the CAN driver) of unit
//!   @p unitIdx is opened and the baud rate @p baud is set.
//!
//!   @p mailboxesUsed mailboxes in @p pChannel are initialized as not allocated
//!   and first @p mailboxesSrs are reserved for the SRS software.
//!
//!
//! @warning
//!   In case of an error during the driver initialization/interaction, the
//!   function does not return.
// =============================================================================
extern void CanSchedPrivateChannel_Init(CanSchedPrivateTypes_Self_S *    pSelf,  // polyspace DEFECT:DECL_MISMATCH [To investigate:Medium] "CECBSAFETY-3063"  // polyspace MISRA-C3:8.3 [To investigate:Medium] "CECBSAFETY-3063"  // polyspace ISO-17961:argcomp [To investigate:Medium] "CECBSAFETY-3098"  // polyspace ISO-17961:funcdecl [To investigate:Medium] "CECBSAFETY-3100"
                                        CanSchedPrivateTypes_Channel_S * pChannel,
                                        CanSchedPrivateTypes_UnitIdx_T   unitIdx,
                                        uint8_t                          baud,
                                        const char *                     interface,
                                        CanSchedTypes_CanFilterIndex_T   mailboxesUsed,
                                        CanSchedTypes_CanFilterIndex_T   mailboxesSrs);


// =============================================================================
//! @brief  handle an incoming Sciopta message
//!
//! @param [in]     pSelf     CAN scheduler process variables
//! @param [out]    pChannel  channel
//! @param [in,out] pScMsg    Sciopta message that needs to be handled
//!
//!
//! @brief
//!
//!   This function handles @p pScMsg for channel `pSelf->channel[channelIdx]`.
//!   This includes user requests, replies and driver interaction.
//!
//!   After return `*pScMsg` is @c NULL, if the message was handled.
//!
//!
//! @retval true   the message was handled
//! @retval false  the message was not handled
//!
//!
//! \par CONSTRAINTS
//!
//!   The caller has to ensure, that
//!
//!     * @p pSelf is initialized;
//!
//!     * @p channelIdx index of the channel
//!
//!     * @p pScMsg
//!         - is not NULL;
//!         - and the Sciopta message is associated with the channel
//!
//! @reviewMinor
//!  * 2019-06-11 - HeLLo, GB, MHn
//!    * The parameter `pChannel` was replaced by `channelIdx`.  Change the
//!      parameter description.
// =============================================================================
extern bool CanSchedPrivateChannel_HandleScMsg(CanSchedPrivateTypes_Self_S * pSelf,  // polyspace DEFECT:DECL_MISMATCH [To investigate:Medium] "CECBSAFETY-3063"  // polyspace MISRA-C3:8.3 [To investigate:Medium] "CECBSAFETY-3051"  // polyspace ISO-17961:argcomp [To investigate:Medium] "CECBSAFETY-3098"  // polyspace ISO-17961:funcdecl [To investigate:Medium] "CECBSAFETY-3100"
                                               CanSchedTypes_CanChannel_T    channelIdx,
                                               sc_msg_t *                    pScMsg);



#endif // CANSCHEDPRIVATECHANNEL_H

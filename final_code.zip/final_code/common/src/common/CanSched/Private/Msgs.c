// *****************************************************************************
// **                _______   _________  _________   _______                 **
// **               (  ___  )  \__   __/  \__   __/  (  ____ \                **
// **               | (   ) |     ) (        ) (     | (    \/                **
// **               | |   | |     | |        | |     | (_____                 **
// **               | |   | |     | |        | |     (_____  )                **
// **               | |   | |     | |        | |           ) |                **
// **               | (___) |     | |     ___) (___  /\____) |                **
// **               (_______)     )_(     \_______/  \_______)                **
// **                                                                         **
// **                   Component Engineering Center Berlin                   **
// **                                                                         **
// **   Copyright 2017 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **
// **                                                                         **
// *****************************************************************************
//!
//! @file CanSched/PrivateMsgs.c
//!
//! @ingroup grp_CanSchedPrivate
//!
//! @brief CAN scheduler message allocation implementation
//!
//! @reviewNoAction
//!  * 2019-06-11 - HeLLo, GB, MHn
//!    * No findings.
// *****************************************************************************


#include "CanSched/Private/Msgs.h"
#include "Cfg/MsgIds.h"



// #############################################################################
// ## EXTERN FUNCTIONS #########################################################
// #############################################################################

// =============================================================================
extern sc_msg_t CanSchedPrivateMsgs_AllocCanAllocateFilter(sc_poolid_t pool, sc_ticks_t tmo, bool isSrs)
{
  register sc_msgid_t msgId;

  if (isSrs)
  {
    msgId = CFGMSGIDS_CANSCHED_ALLOCATEFILTER_REQUEST_SRS_MSGID;
  }
  else
  {
    msgId = CFGMSGIDS_CANSCHED_ALLOCATEFILTER_REQUEST_NONSRS_MSGID;
  }

  return sc_msgAlloc(sizeof(CanSchedPrivateMsgs_ScMsgAllocateFilter_S), msgId, pool, tmo);
}


// =============================================================================
extern sc_msg_t CanSchedPrivateMsgs_AllocCanFreeFilter(sc_poolid_t pool, sc_ticks_t tmo, bool isSrs)
{
  register sc_msgid_t msgId;

  if (isSrs)
  {
    msgId = CFGMSGIDS_CANSCHED_FREEFILTER_REQUEST_SRS_MSGID;
  }
  else
  {
    msgId = CFGMSGIDS_CANSCHED_FREEFILTER_REQUEST_NONSRS_MSGID;
  }

  return sc_msgAlloc(sizeof(CanSchedPrivateMsgs_ScMsgFreeFilter_S), msgId, pool, tmo);
}


// =============================================================================
extern sc_msg_t CanSchedPrivateMsgs_AllocCanReceive(sc_poolid_t pool, sc_ticks_t tmo, CanSchedTypes_CanChannel_T channelIdx)
{
  return sc_msgAlloc(sizeof(CanSchedMsgs_ScMsgRcvNotify_S), CFGMSGIDS_CANSCHED_RCVNOTIFY_MSGID(channelIdx), pool, tmo);
}


// =============================================================================
extern sc_msg_t CanSchedPrivateMsgs_AllocCanSendReply (sc_poolid_t pool, sc_ticks_t tmo)  // polyspace MISRA-C3:5.1 [To fix:Medium] "CECBSAFETY-3049"
{
  return sc_msgAlloc(sizeof(CanSchedPrivateMsgs_ScMsgSend_S), CFGMSGIDS_CANSCHED_SEND_REPLY_MSGID, pool, tmo);
}


// =============================================================================
extern sc_msg_t CanSchedPrivateMsgs_AllocCanSetFilter(sc_poolid_t pool, sc_ticks_t tmo, bool isSrs, size_t n)  // polyspace MISRA-C3:5.1 [To fix:Medium] "CECBSAFETY-3049"
{
  register sc_msgid_t msgId;
  register size_t     size;

  if (isSrs)
  {
    msgId = CFGMSGIDS_CANSCHED_SETFILTER_REQUEST_SRS_MSGID;
  }
  else
  {
    msgId = CFGMSGIDS_CANSCHED_SETFILTER_REQUEST_NONSRS_MSGID;
  }

  size = sizeof(CanSchedPrivateMsgs_ScMsgSetFilterRequest_S) + n * sizeof(CanSchedTypes_CanFilter_S);

  return sc_msgAlloc(size, msgId, pool, tmo);
}


// =============================================================================
extern sc_msg_t CanSchedPrivateMsgs_AllocCanSetReply(sc_poolid_t pool, sc_ticks_t tmo)  // polyspace MISRA-C3:5.1 [To fix:Medium] "CECBSAFETY-3049"  // polyspace ISO-17961:funcdecl [To investigate:Medium] "CECBSAFETY-3100"
{
  return sc_msgAlloc(sizeof(CanSchedPrivateMsgs_ScMsgSetFilterReply_S), CFGMSGIDS_CANSCHED_SETFILTER_REPLY_MSGID, pool, tmo);
}


// =============================================================================
extern sc_msg_t CanSchedPrivateMsgs_AllocCanSend     (sc_poolid_t pool, sc_ticks_t tmo, bool isSrs, bool isFire)  // polyspace MISRA-C3:5.1 [To fix:Medium] "CECBSAFETY-3049"  // polyspace ISO-17961:funcdecl [To investigate:Medium] "CECBSAFETY-3100"
{
  register sc_msgid_t msgId;

  if (isSrs)
  {
    if (isFire)
    {
      msgId = CFGMSGIDS_CANSCHED_SEND_FIRE_REQUEST_SRS_MSGID;
    }
    else
    {
      msgId = CFGMSGIDS_CANSCHED_SEND_REQUEST_SRS_MSGID;
    }
  }
  else
  {
    msgId = CFGMSGIDS_CANSCHED_SEND_REQUEST_NONSRS_MSGID;
  }

  return sc_msgAlloc(sizeof(CanSchedPrivateMsgs_ScMsgSend_S), msgId, pool, tmo);
}

// *****************************************************************************
// **                _______   _________  _________   _______                 **
// **               (  ___  )  \__   __/  \__   __/  (  ____ \                **
// **               | (   ) |     ) (        ) (     | (    \/                **
// **               | |   | |     | |        | |     | (_____                 **
// **               | |   | |     | |        | |     (_____  )                **
// **               | |   | |     | |        | |           ) |                **
// **               | (___) |     | |     ___) (___  /\____) |                **
// **               (_______)     )_(     \_______/  \_______)                **
// **                                                                         **
// **                   Component Engineering Center Berlin                   **
// **                                                                         **
// **   Copyright 2017 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **
// **                                                                         **
// *****************************************************************************
//!
//! @file CanSched/Private/Channel.c
//!
//! @ingroup grp_CanSchedPrivate
//!
//! @brief  CAN scheduler channel implementation
//!
// *****************************************************************************

#include "CanSched/Private/Channel.h"
#include "CanSched/Private/Msgs.h"
#include "CanSched/Private/Driver.h"
#include "CanSched/Private/SendQueue.h"
#include "CanSched/Private/DummyFilter.h"
#include "Hlp/Failure.h"
#include "Hlp/Msg.h"
#include "Cfg/MsgIds.h"
#include <string.h>

// -----------------------------------------------------------------------------
//! @brief  union sc_msg CanSched/Private/Channel.c
// -----------------------------------------------------------------------------
union sc_msg  // polyspace MISRA-C3:5.7 [To investigate:Medium] "CECBSAFETY-3050"
{
  sc_msgid_t                        scMsgId;   //!< Sciopta message ID
  CanSchedPrivateMsgs_PrivateMsgs_U canSched;  //!< CAN scheduler private messages
  sdd_canRxHRTS_t                   sddCanRx;    //!< driver received CAN message
  sdd_canWrite_t                    sddCanWrite; //!< driver request/reply sending
};


// #############################################################################
// ## LOCAL FUNCTION DECLARATIONS ##############################################
// #############################################################################


// -----------------------------------------------------------------------------
// Identify Incoming Sciopta Messages
// -----------------------------------------------------------------------------
static bool isMySddReceived(sc_msg_t *                       pScMsg,
                            CanSchedPrivateTypes_Channel_S * pChannel);

static bool isMySddWriteReply(sc_msg_t *                       pScMsg,
                              CanSchedPrivateTypes_Channel_S * pChannel);

static bool isMySetFilterRequest(sc_msg_t *                 pScMsg,
                                 CanSchedTypes_CanChannel_T channelIdx);

static bool isMyFreeFilterRequest(sc_msg_t *                 pScMsg,
                                  CanSchedTypes_CanChannel_T channelIdx);

static bool isMyAllocateFilterRequest(sc_msg_t *                 pScMsg,
                                      CanSchedTypes_CanChannel_T channelIdx);

static bool isMySendRequest(sc_msg_t *                 pScMsg,
                            CanSchedTypes_CanChannel_T channelIdx);

// -----------------------------------------------------------------------------
// Handle Incoming Sciopta Messages
// -----------------------------------------------------------------------------
static void handleAllocateFilterRequest(CanSchedPrivateTypes_Self_S *    pSelf,
                                        CanSchedPrivateTypes_Channel_S * pChannel,
                                        sc_msg_t *                       pScMsg);

static void handleFreeFilterRequest    (CanSchedPrivateTypes_Self_S *    pSelf,
                                        CanSchedPrivateTypes_Channel_S * pChannel,
                                        sc_msg_t *                       pScMsg);

static void handleSddReceived          (CanSchedPrivateTypes_Self_S *    pSelf,
                                        CanSchedPrivateTypes_Channel_S * pChannel,
                                        sc_msg_t *                       pScMsg);

static void handleSddWriteReply        (CanSchedPrivateTypes_Self_S *    pSelf,
                                        CanSchedPrivateTypes_Channel_S * pChannel,
                                        sc_msg_t *                       pScMsg);

static void handleSetFilterRequest     (CanSchedPrivateTypes_Self_S *    pSelf,
                                        CanSchedPrivateTypes_Channel_S * pChannel,
                                        sc_msg_t *                       pScMsg);

static void handleSendRequest          (CanSchedPrivateTypes_Self_S *    pSelf,
                                        CanSchedPrivateTypes_Channel_S * pChannel,
                                        sc_msg_t *                       pScMsg);


// -----------------------------------------------------------------------------
// Driver Interaction
// -----------------------------------------------------------------------------
static void checkNewDriverInteraction(CanSchedPrivateTypes_Self_S *    pSelf,
                                      CanSchedPrivateTypes_Channel_S * pChannel);

static void sendNextMessageInQueue   (CanSchedPrivateTypes_Self_S *    pSelf,
                                      CanSchedPrivateTypes_Channel_S * pChannel);

static void updateFilters            (CanSchedPrivateTypes_Self_S *    pSelf,
                                      CanSchedPrivateTypes_Channel_S * pChannel);


// -----------------------------------------------------------------------------
// Others
// -----------------------------------------------------------------------------
static CanSchedTypes_CanProtocol_E sddCanMsgProtocol(sdd_canBufHRTS_t * pCanMsg);

static bool mailboxIsProgrammed(CanSchedPrivateTypes_Mailbox_S * pMailbox);

static bool isExtendedCanId(CanSchedTypes_CanId_T id);

static bool isStandardCanId(CanSchedTypes_CanId_T id);


// -----------------------------------------------------------------------------
// Filter Matches
// -----------------------------------------------------------------------------
static bool sddFilterMatchesCanMsg(sdd_canFilterType_t * pSddFilter,
                                   sdd_canBufHRTS_t *    pCanMsg);

static bool canSchedFilterMatchesCanMsg(CanSchedTypes_CanFilter_S * pCanSchedFilter,
                                        sdd_canBufHRTS_t *          pCanMsg);

static bool longFilterMatchesCanMsg(CanSchedPrivateMsgs_ScMsgLongFilter_S * pLongFilter,
                                    sdd_canBufHRTS_t *                      pCanMsg);

static bool mailboxMatchesCanMsg(CanSchedPrivateTypes_Mailbox_S * pMailbox,
                                 sdd_canBufHRTS_t *               pCanMsg);

// -----------------------------------------------------------------------------
// Filter helpers
// -----------------------------------------------------------------------------
static bool allSubFilterProtocolsAreConsistent(CanSchedPrivateMsgs_ScMsgLongFilter_S * pLongFilter);

static sdd_canFilterType_t commonSddFilter(CanSchedPrivateMsgs_ScMsgLongFilter_S * pLongFilter);

static void sddFilterOr(sdd_canFilterType_t * out, sdd_canFilterType_t * in1, sdd_canFilterType_t * in2);


// -----------------------------------------------------------------------------
// Communication
// -----------------------------------------------------------------------------
static void notifyFilterListener(CanSchedPrivateTypes_Self_S *           pSelf,
                                 CanSchedPrivateMsgs_ScMsgLongFilter_S * pLongFilter,
                                 sdd_canBufHRTS_t *                      pCanMsg);

static void sendSetFilterReply(CanSchedPrivateTypes_Self_S * pSelf,
                               sc_msg_t *                    pRequest,
                               CanSchedTypes_Error_E         result);

static void sendSendReply(CanSchedPrivateTypes_Self_S * pSelf,
                          sc_pid_t                      pid,
                          CanSchedTypes_Error_E         replyResult);





// #############################################################################
// ## EXTERN FUNCTIONS #########################################################
// #############################################################################

// =============================================================================
extern bool CanSchedPrivateChannel_HandleScMsg(CanSchedPrivateTypes_Self_S * pSelf,
                                               CanSchedTypes_CanChannel_T    channelIdx,
                                               sc_msg_t *                    pScMsg)
{
  bool handled;
  CanSchedPrivateTypes_Channel_S * pChannel = &(pSelf->channel[channelIdx]);

  if (isMySddReceived(pScMsg, pChannel))
  {
    handleSddReceived(pSelf, pChannel, pScMsg);
    handled = true;
  }
  else if (isMySddWriteReply(pScMsg, pChannel))
  {
    handleSddWriteReply(pSelf, pChannel, pScMsg);
    handled = true;
  }
  else if (isMySetFilterRequest(pScMsg, channelIdx))
  {
    handleSetFilterRequest(pSelf, pChannel, pScMsg);
    handled = true;
  }
  else if (isMyFreeFilterRequest(pScMsg, channelIdx))
  {
    handleFreeFilterRequest(pSelf, pChannel, pScMsg);
    handled = true;
  }
  else if (isMyAllocateFilterRequest(pScMsg, channelIdx))
  {
    handleAllocateFilterRequest(pSelf, pChannel, pScMsg);
    handled = true;
  }
  else if (isMySendRequest(pScMsg, channelIdx))
  {
    handleSendRequest(pSelf, pChannel, pScMsg);
    handled = true;
  }
  else
  {
    handled = false;
  }

  if (handled)
  {
    checkNewDriverInteraction(pSelf, pChannel);
  }

  return handled;
}

// =============================================================================
extern void CanSchedPrivateChannel_Init(CanSchedPrivateTypes_Self_S *    pSelf,
                                        CanSchedPrivateTypes_Channel_S * pChannel,
                                        CanSchedPrivateTypes_UnitIdx_T   unitIdx,
                                        uint8_t                          baud,
                                        const char *                     interface,
                                        CanSchedTypes_CanFilterIndex_T   mailboxesUsed,
                                        CanSchedTypes_CanFilterIndex_T   mailboxesSrs)
{
  if ( NULL == pChannel  ||  NULL == pSelf )
  {
    HlpFailure_EndlessLoop();
#ifdef __clang_analyzer__
    __builtin_unreachable();
#endif
  }

  pChannel->baud               = baud;
  pChannel->mailboxesSrs       = mailboxesSrs;
  pChannel->mailboxesUsed      = mailboxesUsed;
  pChannel->interface          = interface;
  pChannel->unitIdx            = unitIdx;
  pChannel->driverState        = CanSchedPrivateTypes_DRIVERSTATE_IDLE;
  pChannel->currentSendRequest = NULL;
  CanSchedPrivateSendQueue_Init(&(pChannel->sendQueue));
  pChannel->mailboxUpdateIsPending = false;

  for ( size_t  i = 0; i < sizeof(pChannel->mailbox)/sizeof(*pChannel->mailbox); ++i)
  {
    pChannel->mailbox[i].isAllocated      = false;
    pChannel->mailbox[i].owner            = SC_ILLEGAL_PID;
    pChannel->mailbox[i].longFilter       = NULL;
    pChannel->mailbox[i].programmedFilter = CanSchedPrivateDummyFilter_dummyFilter;
  }


  if (CanSchedPrivateDriver_OpenBlocking(pChannel, &(pSelf->devMan)) != CanSchedTypes_ERROR_SUCCESS)
  {
    logd_printf(pSelf->logd, LOGD_SEVERE,
                "CanSchedPrivateDriver_OpenBlocking(\"%s\"): (Error %d)\n",
                pChannel->interface,
                sc_miscErrnoGet());
    HlpFailure_EndlessLoopSleeping(sc_tickMs2Tick(1000));
  }

  if (CanSchedPrivateDriver_SetBaudBlocking(pChannel) != CanSchedTypes_ERROR_SUCCESS)
  {
    logd_printf(pSelf->logd, LOGD_SEVERE,
                "CanSchedPrivateDriver_SetBaudBlocking(\"%s\") failed\n",
                pChannel->interface);
    HlpFailure_EndlessLoopSleeping(sc_tickMs2Tick(1000));
  }
}


// #############################################################################
// ## LOCAL FUNCTIONS ##########################################################
// #############################################################################


// =============================================================================
//! @brief  check if sddReceived belongs to the channel
//!
//! @param [in] pScMSg    to be checked Sciopta message
//! @param [in] pChannel  CAN channel object
//!
//!
//! @details
//!
//!   The function checks, if the message is a #SDD_CAN_RECEIVED_MSG and is sent
//!   from the driver associated with @p pChannel.
//!
//!
//! @return
//!
//!   The function returns @c true if it is of type #sdd_canRxHRTS_t and from the
//!   associated driver.  Otherwise @c false is returned.
//!
// =============================================================================
static bool isMySddReceived(sc_msg_t *                       pScMsg,
                            CanSchedPrivateTypes_Channel_S * pChannel)
{
  const sc_msgid_t scMsgId = (*pScMsg)->scMsgId;
  const sc_pid_t   sender  = sc_msgSndGet(pScMsg);
  bool isMsg = false;

  if (   (scMsgId == SDD_CAN_RECEIVED_MSG(pChannel->unitIdx))
      && (sender  == pChannel->pDev->sender))
  {
    isMsg = true;
  }

  return isMsg;
}


// =============================================================================
//! @brief  check if sddWriteReply belongs to the channel
//!
//! @param [in] pScMSg    to be checked Sciopta message
//! @param [in] pChannel  CAN channel object
//!
//!
//! @details
//!
//!   The function checks, if the message is a #SDD_CAN_WRITE_REPLY and is sent
//!   from the driver associated with @p pChannel.
//!
//!
//! @return
//!
//!   The function returns @c true if it is of type #sdd_canWrite_t and from the
//!   associated driver.  Otherwise @c false is returned.
//!
// =============================================================================
static bool isMySddWriteReply(sc_msg_t *                       pScMsg,
                              CanSchedPrivateTypes_Channel_S * pChannel)
{
  const sc_msgid_t scMsgId = (*pScMsg)->scMsgId;
  const sc_pid_t   sender  = sc_msgSndGet(pScMsg);
  bool isMsg = false;

  if (   (scMsgId == SDD_CAN_WRITE_REPLY)
      && (sender  == pChannel->pDev->sender))
  {
    isMsg = true;
  }

  return isMsg;
}


// =============================================================================
//! @brief  check if SetFilterRequest belongs to the channel
//!
//! @param [in] pScMSg      to be checked Sciopta message
//! @param [in] channelIdx  channel index
//!
//!
//! @details
//!
//!   The function checks, if the message is a SRS or non-SRS request of type
//!   #CanSchedPrivateMsgs_ScMsgSetFilterRequest_S and is sent from the driver
//!   associated with @p pChannel.
//!
//!
//! @return
//!
//!   The function returns @c true if it is of correct type and from the
//!   associated driver.  Otherwise @c false is returned.
//!
// =============================================================================
static bool isMySetFilterRequest(sc_msg_t *                 pScMsg,
                                 CanSchedTypes_CanChannel_T channelIdx)
{
  const sc_msgid_t scMsgId = (*pScMsg)->scMsgId;
  bool isMsg = false;

  if (   (scMsgId == CFGMSGIDS_CANSCHED_SETFILTER_REQUEST_SRS_MSGID)
      || (scMsgId == CFGMSGIDS_CANSCHED_SETFILTER_REQUEST_NONSRS_MSGID))
  {
    if ((*pScMsg)->canSched.setFilterRequest.channel == channelIdx)
    {
      isMsg = true;
    }
  }

  return isMsg;
}


// =============================================================================
//! @brief  check if FreeFilterRequest belongs to the channel
//!
//! @param [in] pScMSg      to be checked Sciopta message
//! @param [in] channelIdx  channel index
//!
//!
//! @details
//!
//!   The function checks, if the message is a SRS or non-SRS request of type
//!   #CanSchedPrivateMsgs_ScMsgFreeFilter_S and is sent from the driver
//!   associated with @p pChannel.
//!
//!
//! @return
//!
//!   The function returns @c true if it is of correct type and from the
//!   associated driver.  Otherwise @c false is returned.
//!
// =============================================================================
static bool isMyFreeFilterRequest(sc_msg_t *                 pScMsg,
                                  CanSchedTypes_CanChannel_T channelIdx)
{
  const sc_msgid_t scMsgId = (*pScMsg)->scMsgId;
  bool isMsg = false;

  if (   (scMsgId == CFGMSGIDS_CANSCHED_FREEFILTER_REQUEST_SRS_MSGID)
      || (scMsgId == CFGMSGIDS_CANSCHED_FREEFILTER_REQUEST_NONSRS_MSGID))
  {
    if ((*pScMsg)->canSched.freeFilter.channel == channelIdx)
    {
      isMsg = true;
    }
  }

  return isMsg;
}


// =============================================================================
//! @brief  check if AllocateFilterRequest belongs to the channel
//!
//! @param [in] pScMSg      to be checked Sciopta message
//! @param [in] channelIdx  channel index
//!
//!
//! @details
//!
//!   The function checks, if the message is a SRS or non-SRS request of type
//!   #CanSchedPrivateMsgs_ScMsgAllocateFilter_S and is sent from the driver
//!   associated with @p pChannel.
//!
//!
//! @return
//!
//!   The function returns @c true if it is of correct type and from the
//!   associated driver.  Otherwise @c false is returned.
//!
// =============================================================================
static bool isMyAllocateFilterRequest(sc_msg_t *                 pScMsg,
                                      CanSchedTypes_CanChannel_T channelIdx)
{
  const sc_msgid_t scMsgId = (*pScMsg)->scMsgId;
  bool isMsg = false;

  if (   (scMsgId == CFGMSGIDS_CANSCHED_ALLOCATEFILTER_REQUEST_SRS_MSGID)
      || (scMsgId == CFGMSGIDS_CANSCHED_ALLOCATEFILTER_REQUEST_NONSRS_MSGID))
  {
    if ((*pScMsg)->canSched.allocateFilter.channel == channelIdx)
    {
      isMsg = true;
    }
  }

  return isMsg;
}


// =============================================================================
//! @brief  check if SendRequest belongs to the channel
//!
//! @param [in] pScMSg      to be checked Sciopta message
//! @param [in] channelIdx  channel index
//!
//!
//! @details
//!
//!   The function checks, if the message is a SRS or non-SRS request of type
//!   #CanSchedPrivateMsgs_ScMsgSend_S and is sent from the driver associated
//!   with @p pChannel.
//!
//!
//! @return
//!
//!   The function returns @c true if it is of correct type and from the
//!   associated driver.  Otherwise @c false is returned.
//!
// =============================================================================
static bool isMySendRequest(sc_msg_t *                 pScMsg,
                            CanSchedTypes_CanChannel_T channelIdx)
{
  const sc_msgid_t scMsgId = (*pScMsg)->scMsgId;
  bool isMsg = false;

  if (   (scMsgId == CFGMSGIDS_CANSCHED_SEND_REQUEST_SRS_MSGID)
      || (scMsgId == CFGMSGIDS_CANSCHED_SEND_REQUEST_NONSRS_MSGID)
      || (scMsgId ==  CFGMSGIDS_CANSCHED_SEND_FIRE_REQUEST_SRS_MSGID))
  {
    if ((*pScMsg)->canSched.send.channel == channelIdx)
    {
      isMsg = true;
    }
  }

  return isMsg;
}



// =============================================================================
//! @brief  handle a request message
//!
//! @param [in,out] pSelf     CAN scheduler object
//! @param [in,out] pChannel  CAN channel object
//! @param [in,out] pScMSg    to be handled allocate filter request
//!
//!
//! @details
//!
//!   The function searches for an empty filter in @p pChannel in the associated
//!   category (SRS/non-SRS) and returns the result via a Sciopta message to the
//!   requester.
//!
//!   @p pScMsg is @c NULL afterwards.
//!
//!
//! @par ERROR
//!
//!   An error is indicated by sending an appropriate result value to the
//!   requester.
//!
//!
//! @par CONSTRAINTS
//!
//!   The function assumes @p pScMsg to be an allocate-filter-request for
//!   @p pChannel.
//!
//! @reviewNice
//!   * 2019-06-13 - HeLLo, GB, MHn
//!     * `stopIdx` should be the index of the last used mailbox, not one
//!        behind.
//!     * Change assignment to `stopIdx = ... - 1;` and change the condition
//!       from `<` to `<=`.
//!     * OR rename it to `limitIdx`.
// =============================================================================
static void handleAllocateFilterRequest(CanSchedPrivateTypes_Self_S *    pSelf,
                                        CanSchedPrivateTypes_Channel_S * pChannel,
                                        sc_msg_t *                       pScMsg)
{
  CanSchedTypes_CanFilterIndex_T mailboxIdx;
  CanSchedTypes_CanFilterIndex_T startIdx;
  CanSchedTypes_CanFilterIndex_T stopIdx;
  CanSchedTypes_Error_E          replyResult = CanSchedTypes_ERROR_FILTER_INDEX;


  if ((*pScMsg)->scMsgId == CFGMSGIDS_CANSCHED_ALLOCATEFILTER_REQUEST_SRS_MSGID)
  {
    startIdx = 0;
    stopIdx  = pChannel->mailboxesSrs;
  }
  else
  {
    startIdx = pChannel->mailboxesSrs;
    stopIdx  = pChannel->mailboxesUsed;
  }

  for (mailboxIdx = startIdx; (mailboxIdx < stopIdx) && (replyResult == CanSchedTypes_ERROR_FILTER_INDEX); ++mailboxIdx)
  {
    if (pChannel->mailbox[mailboxIdx].isAllocated == false)
    {
      pChannel->mailbox[mailboxIdx].isAllocated = true;
      pChannel->mailbox[mailboxIdx].owner       = sc_msgSndGet(pScMsg);
      (*pScMsg)->canSched.allocateFilter.filterIndex = mailboxIdx;
      replyResult = CanSchedTypes_ERROR_SUCCESS;
    }
  }

  (*pScMsg)->scMsgId = CFGMSGIDS_CANSCHED_ALLOCATEFILTER_REPLY_MSGID;
  (*pScMsg)->canSched.allocateFilter.base.result = replyResult;

  HlpMsg_TxRtrn(pScMsg, sc_msgSndGet(pScMsg));
  HlpMsg_AssertSent_f(pSelf->logd, pScMsg, __FILE__, __LINE__, __func__);
}


// =============================================================================
//! @brief  handle a request message
//!
//! @param [in,out] pSelf     CAN scheduler object
//! @param [in,out] pChannel  CAN channel object
//! @param [in,out] pScMSg    to be handled free filter request
//!
//!
//! @details
//!
//!   The function verifies that the requester is authorized to free the filter
//!   and returns the result via a Sciopta message to the requester.
//!
//!   If the requester is authorized, the filter is cleared and freed.  The
//!   hardware filter is set to the dummy filter.
//!
//!   @p pScMsg is @c NULL afterwards.
//!
//!
//! @par ERROR
//!
//!   An error is indicated by sending an appropriate result value to the
//!   requester.
//!
//!
//! @par CONSTRAINTS
//!
//!   The function assumes @p pScMsg to be an free-filter-request for @p pChannel.
//!
// =============================================================================
static void handleFreeFilterRequest(CanSchedPrivateTypes_Self_S *    pSelf,
                                    CanSchedPrivateTypes_Channel_S * pChannel,
                                    sc_msg_t *                       pScMsg)
{
  CanSchedPrivateMsgs_ScMsgFreeFilter_S * pFreeMsg = &((*pScMsg)->canSched.freeFilter);
  CanSchedTypes_CanFilterIndex_T          idx      = pFreeMsg->filterIndex;
  sc_pid_t                                sender   = sc_msgSndGet(pScMsg);

  if (idx >= pChannel->mailboxesUsed)
  {
    pFreeMsg->base.result = CanSchedTypes_ERROR_FILTER_INDEX;
  }
  else if (pChannel->mailbox[idx].isAllocated == false)
  {
    pFreeMsg->base.result = CanSchedTypes_ERROR_FILTER_NOT_ALLOCATED;
  }
  else if (pChannel->mailbox[idx].owner != sender)
  {
    pFreeMsg->base.result = CanSchedTypes_ERROR_FILTER_FALSE_OWNER;
  }
  else
  {
    pChannel->mailbox[idx].owner            = SC_ILLEGAL_PID;
    pChannel->mailbox[idx].isAllocated      = false;
    pChannel->mailbox[idx].programmedFilter = CanSchedPrivateDummyFilter_dummyFilter;

    if (pChannel->mailbox[idx].longFilter != NULL)
    {
      sc_msgFree(&(pChannel->mailbox[idx].longFilter));
    }

    pChannel->mailboxUpdateIsPending = true;
    pFreeMsg->base.result = CanSchedTypes_ERROR_SUCCESS;
  }

  (*pScMsg)->scMsgId = CFGMSGIDS_CANSCHED_FREEFILTER_REPLY_MSGID;
  HlpMsg_TxRtrn(pScMsg, sender);
  HlpMsg_AssertSent_f(pSelf->logd, pScMsg, __FILE__, __LINE__, __func__);
}


// =============================================================================
//! @brief  handle a received CAN message
//!
//! @param [in,out] pSelf     CAN scheduler object
//! @param [in,out] pChannel  CAN channel object
//! @param [in,out] pScMSg    to be handled driver reception notice
//!
//!
//! @details
//!
//!   The function checks all installed filters if the received CAN messages
//!   match these filters.  If this is the case, each owner the matching filter
//!   is informed via a Sciopta message.
//!
//!   @p pScMsg is @c NULL afterwards.
//!
//!
//! @par CONSTRAINTS
//!
//!   The function assumes @p pScMsg to be an sdd-receive-notification for
//!   @p pChannel.
//!
// =============================================================================
static void handleSddReceived          (CanSchedPrivateTypes_Self_S *    pSelf,
                                        CanSchedPrivateTypes_Channel_S * pChannel,
                                        sc_msg_t *                       pScMsg)
{
  int                                     sddMsgIdx;
  size_t                                  mailboxIdx;
  CanSchedPrivateMsgs_ScMsgLongFilter_S * pLongFilter;
  CanSchedPrivateTypes_Mailbox_S *        pMailbox;
  sdd_canBufHRTS_t *                      pCanMsg;
  sdd_canRxHRTS_t *                           pSddCanRx = &((*pScMsg)->sddCanRx);

  // for each received message
  for (sddMsgIdx = 0; sddMsgIdx < pSddCanRx->n; ++sddMsgIdx)
  {
    pCanMsg  = &(pSddCanRx->mb[sddMsgIdx]);

    // check each filter
    for (mailboxIdx = 0; mailboxIdx < pChannel->mailboxesUsed; ++mailboxIdx)
    {
      pMailbox    = &(pChannel->mailbox[mailboxIdx]);
      pLongFilter = &(pMailbox->longFilter->canSched.longFilter);

      // if filter matches
      if (mailboxMatchesCanMsg(pMailbox, pCanMsg))
      {
        notifyFilterListener(pSelf, pLongFilter, pCanMsg);
      }
    }
  }
  sc_msgFree(pScMsg);
}


// =============================================================================
//! @brief  handle a sdd write reply message
//!
//! @param [in,out] pSelf     CAN scheduler object
//! @param [in,out] pChannel  CAN channel object
//! @param [in,out] pScMSg    to be handled driver write reply
//!
//!
//! @details
//!
//!   If the sending was a blocking call, the sender is informed about the result
//!   of the transmission.  Otherwise the message is just freed.
//!
//!   In both cases the driver state is idle afterwards.
//!
//!   @p pScMsg is @c NULL afterwards.
//!
//!
//! @par ERROR
//!
//!   An error is indicated by sending an appropriate result value to the
//!   requester, if it is a blocking request.
//!
//!
//! @par CONSTRAINTS
//!
//!   The function assumes @p pScMsg to be an sdd-write-reply for @p pChannel.
//!
// =============================================================================
static void handleSddWriteReply        (CanSchedPrivateTypes_Self_S *    pSelf,
                                        CanSchedPrivateTypes_Channel_S * pChannel,
                                        sc_msg_t *                       pScMsg)
{
  CanSchedTypes_Error_E replyResult;

  if (pChannel->currentSendRequest->canSched.send.isBlockingCall)
  {
    switch ( (*pScMsg)->sddCanWrite.base.error )
    {
      case IOCTL_CAN_BUS_OK:
        replyResult = CanSchedTypes_ERROR_SUCCESS;
        break;

      case IOCTL_CAN_BUS_WARN:
        replyResult = CanSchedTypes_ERROR_CAN_ERROR_ACTIVE;
        break;

      case IOCTL_CAN_BUS_ERR:
        replyResult = CanSchedTypes_ERROR_SUCCESS;  // @todo  investigate why this is a success-condition
        break;

      case IOCTL_CAN_BUS_OFF:
        replyResult = CanSchedTypes_ERROR_CAN_BUS_OFF;
        break;

      default:
        replyResult = CanSchedTypes_ERROR_CAN_UNDEFINED;
        break;
    }

    sendSendReply(pSelf, sc_msgSndGet(&(pChannel->currentSendRequest)), replyResult);
  }

  sc_msgFree(&(pChannel->currentSendRequest));
  sc_msgFree(pScMsg);
  pChannel->driverState = CanSchedPrivateTypes_DRIVERSTATE_IDLE;
}


// =============================================================================
//! @brief  handle a set filter request message
//!
//! @param [in,out] pSelf     CAN scheduler object
//! @param [in,out] pChannel  CAN channel object
//! @param [in,out] pScMsg    to be handled set filter request
//!
//!
//! @details
//!
//!   The function verifies that the requester is authorized to set the filter
//!   and no update for this filter is still pending.
//!
//!   If it is a non-blocking request, the result is returned via a Sciopta
//!   message to the requester as soon as the update request is stored or an
//!   error occurred.
//!
//!   If it is a blocking call, the result is sent from this function only when
//!   an error occurred.
//!
//!   @p pScMsg is @c NULL afterwards.
//!
//!
//! @par ERROR
//!
//!   An error is indicated by sending an appropriate result value to the
//!   requester.
//!
//!
//! @par CONSTRAINTS
//!
//!   The function assumes @p pScMsg to be an set-filter-request for @p pChannel.
// =============================================================================
static void handleSetFilterRequest     (CanSchedPrivateTypes_Self_S *    pSelf,
                                        CanSchedPrivateTypes_Channel_S * pChannel,
                                        sc_msg_t *                       pScMsg)
{
  CanSchedPrivateMsgs_ScMsgSetFilterRequest_S * pRequest = &((*pScMsg)->canSched.setFilterRequest);
  CanSchedTypes_CanFilterIndex_T                idx      = pRequest->filterIndex;
  sc_pid_t                                      sender   = sc_msgSndGet(pScMsg);

  if ((*pScMsg)->scMsgId == CFGMSGIDS_CANSCHED_SETFILTER_REQUEST_SRS_MSGID)
  {
    //! @reviewNice
    //!   * 2019-06-13 - HeLLo, GB, MHn
    //!     * use `pRequest` instead of `(*pScMsg)->canSched.setFilterRequest`
    (*pScMsg)->canSched.setFilterRequest.pool = SC_DEFAULT_POOL;
  }
  else
  {
    //! @reviewNice
    //!   * 2019-06-13 - HeLLo, GB, MHn
    //!     * use `pRequest` instead of `(*pScMsg)->canSched.setFilterRequest`
    (*pScMsg)->canSched.setFilterRequest.pool = pSelf->proxyPool;
  }

  if (idx >= pChannel->mailboxesUsed)
  {
    sendSetFilterReply(pSelf, pScMsg, CanSchedTypes_ERROR_FILTER_INDEX);
    sc_msgFree(pScMsg);
  }
  else if (pChannel->mailbox[idx].isAllocated == false)
  {
    sendSetFilterReply(pSelf, pScMsg, CanSchedTypes_ERROR_FILTER_NOT_ALLOCATED);
    sc_msgFree(pScMsg);
  }
  else if (pChannel->mailbox[idx].owner != sender)
  {
    sendSetFilterReply(pSelf, pScMsg, CanSchedTypes_ERROR_FILTER_FALSE_OWNER);
    sc_msgFree(pScMsg);
  }
  else if (   (pChannel->mailboxUpdateIsPending == true)
           && (pChannel->mailbox[idx].longFilter != NULL)
           && (pChannel->mailbox[idx].longFilter->canSched.longFilter.replyWasSent == false))
  {
    sendSetFilterReply(pSelf, pScMsg, CanSchedTypes_ERROR_UPDATE_PENDING);
    sc_msgFree(pScMsg);
  }
  else if (pRequest->filterListLength < 1)
  {
    sendSetFilterReply(pSelf, pScMsg, CanSchedTypes_ERROR_FILTER_LENGTH);
    sc_msgFree(pScMsg);
  }
  else if (allSubFilterProtocolsAreConsistent(pRequest) == false)
  {
    sendSetFilterReply(pSelf, pScMsg, CanSchedTypes_ERROR_FILTER_TYPE);
    sc_msgFree(pScMsg);
  }
  else
  {
    pChannel->mailboxUpdateIsPending = true;
    pChannel->mailbox[idx].programmedFilter = commonSddFilter(pRequest);

    if (pRequest->base.scMsgId == CFGMSGIDS_CANSCHED_SETFILTER_REQUEST_NONSRS_MSGID)
    {
      pRequest->base.scMsgId = CFGMSGIDS_CANSCHED_LONGFILTER_NONSRS_MSGID;
    }
    else
    {
      pRequest->base.scMsgId = CFGMSGIDS_CANSCHED_LONGFILTER_SRS_MSGID;
    }
    pRequest->owner = sender;

    if (pRequest->isBlockingCall == false)
    {
      sendSetFilterReply(pSelf, pScMsg, CanSchedTypes_ERROR_SUCCESS);
      pRequest->replyWasSent = true;
    }
    else
    {
      pRequest->replyWasSent = false;
    }

    if (pChannel->mailbox[idx].longFilter != NULL)
    {
      sc_msgFree(&(pChannel->mailbox[idx].longFilter));
    }
    pChannel->mailbox[idx].longFilter = *pScMsg;
    *pScMsg = NULL;
  }
}


// =============================================================================
//! @brief  handle a send request message
//!
//! @param [in,out] pSelf     CAN scheduler object
//! @param [in,out] pChannel  CAN channel object
//! @param [in,out] pScMSg    to be handled send request
//!
//!
//! @details
//!
//!   The function inserts the CAN message into the send queue of @p pChannel.
//!
//!   If it is a non-blocking request, the result is returned via a Sciopta
//!   message to the requester as soon as the CAN message is inserted into the
//!   send queue.
//!
//!   If it is a blocking call, the result is sent from this function only when
//!   an error occurred.
//!
//!   @p pScMsg is @c NULL afterwards.
//!
//!
//! @par ERROR
//!
//!   An error is indicated by sending an appropriate result value to the
//!   requester.
//!
//!
//! @par CONSTRAINTS
//!
//!   The function assumes @p pScMsg to be an send-request for @p pChannel.
//!
//! @reviewMinor
//!   * 2019-06-13 - HeLLo, GB, MHn
//!     * Mention, that no request is sent if it is fire and forget.
// =============================================================================
static void handleSendRequest          (CanSchedPrivateTypes_Self_S *    pSelf,
                                        CanSchedPrivateTypes_Channel_S * pChannel,
                                        sc_msg_t *                       pScMsg)
{
  CanSchedTypes_Error_E    replyResult;
  sc_pid_t                 sender;
  bool                     isBlocking;
  bool                     isFire;
  CanSchedTypes_CanMsg_S * pCanMsg;

  pCanMsg    = &((*pScMsg)->canSched.send.canMsg);
  sender     = sc_msgSndGet(pScMsg);
  isBlocking = (*pScMsg)->canSched.send.isBlockingCall;

  const bool  idIsExtendedCanId = isExtendedCanId (pCanMsg->canId);
  const bool  idIsStandardCanId = isStandardCanId (pCanMsg->canId);

  if ((*pScMsg)->canSched.send.base.scMsgId == CFGMSGIDS_CANSCHED_SEND_FIRE_REQUEST_SRS_MSGID)
  {
    isFire   = true;
  }
  else
  {
    isFire   = false;
  }

  if (    (pCanMsg->protocol == CanSchedTypes_PROTOCOL_EXTENDED)
       && (idIsExtendedCanId == false))
  {
    replyResult = CanSchedTypes_ERROR_CAN_ID;
  }
  else if (    (pCanMsg->protocol == CanSchedTypes_PROTOCOL_STANDARD)
            && (idIsStandardCanId == false))
  {
    replyResult = CanSchedTypes_ERROR_CAN_ID;
  }
  else if ( pCanMsg->dataLen > sizeof (pCanMsg->data) )
  {
    replyResult = CanSchedTypes_ERROR_CAN_DATA_LENGTH;
  }
  else
  {
    replyResult = CanSchedPrivateSendQueue_Insert(&(pChannel->sendQueue), pScMsg);
  }

  if (replyResult != CanSchedTypes_ERROR_SUCCESS)
  {
    if (isFire == false)
    {
      sendSendReply(pSelf, sender, replyResult);
    }
    sc_msgFree(pScMsg);
  }
  else if ((isBlocking == false) && (isFire == false))
  {
    sendSendReply(pSelf, sender, replyResult);
  }
  else
  {
    // nothing to be done
  }
}


// =============================================================================
//! @brief  start next driver interaction if idle
//!
//! @param [in,out] pSelf     CAN scheduler object
//! @param [in,out] pChannel  CAN channel object
//!
//!
//! @details
//!
//!   The function checks if the driver state associated with @p pChannel is idle.
//!
//!   If it is idle and the send queue is not empty, sending the first CAN
//!   message in the queue is started.  (Which is the highest priority message.)
//!   The start of the transmission might fail.  In this case the next message is
//!   tried to be sent until initiating the transmission is successful or the
//!   queue is empty.
//!
//!   Regardless of the driver state for sending, if a filter update is pending,
//!   all previously requested updates are performed at once.
//!
//!   If initiating the transmission fails, the requester is informed.
//!
//!   The requesters of all pending filter updates are informed about the
//!   success or fail.
//!
//!
//! @par ERROR
//!
//!   An error is indicated by sending an appropriate result value to the
//!   requester, if it is a blocking request.
//!
// =============================================================================
static void checkNewDriverInteraction(CanSchedPrivateTypes_Self_S *    pSelf,
                                      CanSchedPrivateTypes_Channel_S * pChannel)
{
  while ( pChannel->driverState == CanSchedPrivateTypes_DRIVERSTATE_IDLE )
  {
    if ( NULL == CanSchedPrivateSendQueue_Peek (&pChannel->sendQueue) )
    {
      break;
    }
    sendNextMessageInQueue(pSelf, pChannel);
  }

  //! @note
  //!   Formerly it was assumed, that the sciopta CAN driver did not support the
  //!   two operations sending and setting a filter in parallel.  Therefore the
  //!   driver states were idle, sending and updating filter.  This assumption
  //!   is obsolete:  The two operations are *not* mutual exclusive for the
  //!   driver.  Therefore
  //!
  //!    1. the updating of the filters could be removed here and put into
  //!       handleSetFilterRequest()
  //!
  //!    2. the logic could be simplified, so that set filter requests must no
  //!       longer be buffered and performed together (this might include
  //!       removing @c mailboxUpdateIsPending from
  //!       CanSchedPrivateTypes_Channel_S and removing @c replyWasSent from
  //!       CanSchedPrivateMsgs_ScMsgFilter)
  //!
  //!   That those two operations can be performed concurrently, was discovered
  //!   during the release process of Bellatrix.  The above described
  //!   improvements were not done yet, in order to
  //!
  //!    * minimize the changes to the code base during the release process
  //!
  //!    * simplify the impact analysis for the endurance test
  //!
  //!  see also SCOM-298
  if (pChannel->mailboxUpdateIsPending)
  {
    updateFilters(pSelf, pChannel);
  }
}


// =============================================================================
//! @brief  send the next message in send queue
//!
//! @param [in,out] pSelf     CAN scheduler object
//! @param [in,out] pChannel  CAN channel object
//!
//!
//! @details
//!
//!   The first element of the send queue is removed and stored as
//!   `pChannel->currentSendRequest`.  The transmission of the CAN message is
//!   initiated with the driver associated with @p pChannel.
//!
//!   If initiating the transmission fails, the requester is informed.
//!
//!
//! @par ERROR
//!
//!   An error is indicated by sending an appropriate result value to the
//!   requester, if it is a blocking request.
//!
//!
//! @par CONSTRAINTS
//!
//!   The function assumes the driver associated with @p pChannel to be in idle
//!   state.
//!
//!   The function assumes that the send queue of @p pChannel is not empty.
//!
//! @reviewMinor
//!   * 2019-06-13 - HeLLo, GB, MHn
//!     * Possible memory leak: A reply is sent, even when the request was
//!       non-blocking or fire and forget.
//!     * The defect is not critical, because an unwanted CanSchedReply is only
//!       sent when either the driver process is not alive anymore or the
//!       message pool of the driver process is empty, which both should not
//!       happen.
// =============================================================================
static void sendNextMessageInQueue(CanSchedPrivateTypes_Self_S *    pSelf,
                                   CanSchedPrivateTypes_Channel_S * pChannel)
{
  CanSchedTypes_Error_E    replyResult;

  pChannel->driverState        = CanSchedPrivateTypes_DRIVERSTATE_SENDING;
  pChannel->currentSendRequest = CanSchedPrivateSendQueue_Pop(&(pChannel->sendQueue));
  replyResult                  = CanSchedPrivateDriver_SendTx(pChannel, &(pChannel->currentSendRequest->canSched.send.canMsg));

  if (replyResult != CanSchedTypes_ERROR_SUCCESS)
  {
    sendSendReply(pSelf, sc_msgSndGet(&(pChannel->currentSendRequest)), replyResult);
    sc_msgFree(&(pChannel->currentSendRequest));
    pChannel->driverState        = CanSchedPrivateTypes_DRIVERSTATE_IDLE;
  }
}

// =============================================================================
//! @brief  perform filter update
//!
//! @param [in,out] pSelf     CAN scheduler object
//! @param [in,out] pChannel  CAN channel object
//!
//!
//! @details
//!
//!   The function disables reading on the bus associated with @p pChannel,
//!   replaces all hardware filters with the calculated hardware filters and
//!   enables reading on the bus again.
//!
//!   Afterwards requesters of a blocking filter update are informed about the
//!   success or fail of the update.
//!
//!   The driver state is not changed during the execution.
//!
//!
//! @par ERROR
//!
//!   An error is indicated by sending an appropriate result value to the
//!   requester, if it is a blocking request.
//!
//!
//! @par CONSTRAINTS
//!
//!   The function assumes the driver associated with @p pChannel to be in idle
//!   state.
//!
// =============================================================================
static void updateFilters(CanSchedPrivateTypes_Self_S *    pSelf,
                          CanSchedPrivateTypes_Channel_S * pChannel)
{
  size_t idx;
  CanSchedTypes_Error_E replyResult;
  pChannel->mailboxUpdateIsPending = false;

  replyResult = CanSchedPrivateDriver_DisableReadBlocking(pChannel);
  if (replyResult != CanSchedTypes_ERROR_SUCCESS)
  {
    // nothing to be done
  }
  else
  {
    replyResult = CanSchedPrivateDriver_SetFilterBlocking(pChannel);
    if (replyResult != CanSchedTypes_ERROR_SUCCESS)
    {
      (void)CanSchedPrivateDriver_EnableReadBlocking(pChannel);
    }
    else
    {
      replyResult = CanSchedPrivateDriver_EnableReadBlocking(pChannel);
    }
  }

  for (idx = 0; idx < pChannel->mailboxesUsed; ++idx)
  {
    if (pChannel->mailbox[idx].longFilter != NULL)
    {
      if (pChannel->mailbox[idx].longFilter->canSched.longFilter.replyWasSent == false)
      {
        sendSetFilterReply(pSelf, &(pChannel->mailbox[idx].longFilter), replyResult);
        pChannel->mailbox[idx].longFilter->canSched.longFilter.replyWasSent = true;
      }
    }
  }
}


// =============================================================================
//! @brief  return protocol of SDD filter
//!
//! @param [in] pSddFilter  filter
//!
//!
//! @details
//!
//!   The protocol is derived from the extended flag of @p pSddFilter.  It is not
//!   checked, that the CAN ID is in valid range.
//!
//!
//! @return
//!
//!   CAN protocol
//!
// =============================================================================
static CanSchedTypes_CanProtocol_E sddFilterProtocol(sdd_canFilterType_t * pSddFilter)
{
  CanSchedTypes_CanProtocol_E protocol;

  if ((pSddFilter->flags & (uint32_t)CAN_FILTER_FLAG_EXTENDED) != 0)
  {
    protocol = CanSchedTypes_PROTOCOL_EXTENDED;
  }
  else
  {
    protocol = CanSchedTypes_PROTOCOL_STANDARD;
  }

  return protocol;
}


// =============================================================================
//! @brief  return protocol of SDD CAN message
//!
//! @param [in] pCanMsg  CAN message
//!
//!
//! @details
//!
//!   The protocol is derived from the extended member of @p pCanMsg.  It is not
//!   checked, that the CAN ID is in valid range.
//!
//!
//! @return
//!
//!   CAN protocol
//!
// =============================================================================
static CanSchedTypes_CanProtocol_E sddCanMsgProtocol(sdd_canBufHRTS_t * pCanMsg)
{
  CanSchedTypes_CanProtocol_E protocol;

  if (pCanMsg->extended != 0)
  {
    protocol = CanSchedTypes_PROTOCOL_EXTENDED;
  }
  else
  {
    protocol = CanSchedTypes_PROTOCOL_STANDARD;
  }

  return protocol;
}


// =============================================================================
//! @brief  verify if a mailbox is programmed
//!
//! @param [in] pMailbox  mailbox
//!
//!
//! @details
//!
//!   The function checks, if a long filter is installed for @p pMailbox.
//!
//!
//! @retval true  mailbox is programmed
//! @retval false mailbox is not programmed
//!
//! @reviewNice
//!   * 2019-06-13 - HeLLo, GB, MHn
//!     * Rename variable `matching` to `isProgrammed`.
//!
//! @reviewNice
//!   * 2019-06-13 - HeLLo, GB, MHn
//!     * make parameter `const * const`
// =============================================================================
static bool mailboxIsProgrammed(CanSchedPrivateTypes_Mailbox_S * pMailbox)
{
  bool matching = false;

  if (pMailbox->longFilter != NULL)
  {
    matching = true;
  }

  return matching;
}


// =============================================================================
//! @brief  verify if a SDD filter would match a CAN message
//!
//! @param [in] pSddFilter  CAN filter
//! @param [in] pCanMsg     CAN message
//!
//!
//! @details
//!
//!   The function verifies if the CAN message of @p pCanMsg would be accepted
//!   by @p pSddFilter.
//!
//!
//! @retval true  @p pCanMsg is accepted by @p pSddFilter
//! @retval false @p pCanMsg is NOT accepted by @p pSddFilter
// =============================================================================
static bool sddFilterMatchesCanMsg(sdd_canFilterType_t * pSddFilter,
                                   sdd_canBufHRTS_t *    pCanMsg)
{
  bool matching = false;

  if (sddCanMsgProtocol(pCanMsg) == sddFilterProtocol(pSddFilter))
  {
    if ((pCanMsg->id & pSddFilter->canMf) == pSddFilter->canId)
    {
      matching = true;
    }
  }

  return matching;
}


// =============================================================================
//! @brief  verify if a basic CAN scheduler filter matches a CAN message
//!
//! @param [in] pCanSchedFilter  CAN filter
//! @param [in] pCanMsg          CAN message
//!
//!
//! @details
//!
//!   The function verifies if the CAN message of @p pCanMsg would be accepted
//!   by @p pCanSchedFilter.
//!
//!
//! @retval true  @p pCanMsg is accepted by @p pCanSchedFilter
//! @retval false @p pCanMsg is NOT accepted by @p pCanSchedFilter
// =============================================================================
static bool canSchedFilterMatchesCanMsg(CanSchedTypes_CanFilter_S * pCanSchedFilter,
                                        sdd_canBufHRTS_t *          pCanMsg)
{
  bool matching = false;

  if (sddCanMsgProtocol(pCanMsg) == pCanSchedFilter->protocol)
  {
    if ((pCanMsg->id & pCanSchedFilter->mask) == pCanSchedFilter->compare)
    {
      matching = true;
    }
  }

  return matching;
}


// =============================================================================
//! @brief  verify if any sub filter matches
//!
//! @param [in] pLongFilter  CAN filter
//! @param [in] pCanMsg      CAN message
//!
//!
//! @details
//!
//!   The function verifies if the CAN message of @p pCanMsg would be accept by
//!   at least one of the subfilters of @p pLongFilter.
//!
//!
//! @retval true  @p pCanMsg is accepted by at least one filter of @p pLongFilter
//! @retval false @p pCanMsg is NOT accepted by any filter of @p pLongFilter
// =============================================================================
static bool longFilterMatchesCanMsg(CanSchedPrivateMsgs_ScMsgLongFilter_S * pLongFilter,
                                    sdd_canBufHRTS_t *                      pCanMsg)
{
  size_t                      idx;
  size_t                      length;
  CanSchedTypes_CanFilter_S * pSubFilter;
  bool                        matching;

  matching = false;
  length = pLongFilter->filterListLength;

  for (idx = 0; (idx < length) && (matching == false); ++idx)
  {
    pSubFilter = &(pLongFilter->filterList[idx]);

    if (canSchedFilterMatchesCanMsg(pSubFilter, pCanMsg))
    {
      matching = true; // at least one sub filter matched
    }
  }

  return matching;
}

// =============================================================================
//! @brief  verify if a CAN message is accepted by a mailbox
//!
//! @param [in] pMailbox  CAN mailbox
//! @param [in] pCanMsg   CAN message
//!
//!
//! @details
//!
//!   The function verifys if at the CAN message of @p pCanMsg would be accept by
//!   @p pMailbox.
//!
//!
//! @retval true  @p pCanMsg is accepted by @p pMailbox
//! @retval false @p pCanMsg is NOT by @p pMailbox
//!
// =============================================================================
static bool mailboxMatchesCanMsg(CanSchedPrivateTypes_Mailbox_S * pMailbox,
                                 sdd_canBufHRTS_t *               pCanMsg)
{
  bool matching = false;

  if (mailboxIsProgrammed(pMailbox))
  {
    if (sddFilterMatchesCanMsg(&(pMailbox->programmedFilter), pCanMsg))
    {
      if (longFilterMatchesCanMsg(&(pMailbox->longFilter->canSched.longFilter), pCanMsg))
      {
        matching = true;
      }
    }
  }

  return matching;
}


// =============================================================================
//! @brief  notify a listener about a received CAN message
//!
//! @param [in,out] pSelf     CAN scheduler object
//! @param [in,out] pChannel  CAN channel object
//! @param [in]     pCanMsg   CAN message
//!
//!
//! @details
//!
//!   The function notifies `pLongFilter->owner` via a Sciopta message about the
//!   reception of the CAN message @p pCanMsg.
//!
//!
//! @par ERROR
//!
//!   When the Sciopta message can not be sent to the owner, the CAN message is
//!   "lost".
//!
//!
//! @par CONSTRAINTS
//!
//!   The function assumes @p pCanMsg matches @p pLongFilter
//!
//! @reviewMinor
//!   * 2019-06-13 - HeLLo, GB, MHn
//!     * doxygen parameters do not match function parameters
// =============================================================================
static void notifyFilterListener(CanSchedPrivateTypes_Self_S *           pSelf,
                                 CanSchedPrivateMsgs_ScMsgLongFilter_S * pLongFilter,
                                 sdd_canBufHRTS_t *                      pCanMsg)
{
  sc_msg_t scMsg;

  scMsg = CanSchedPrivateMsgs_AllocCanReceive(pLongFilter->pool,
                                              SC_FATAL_IF_TMO,
                                              pLongFilter->channel);

  scMsg->canSched.publicInterface.rcvNotify.channel           = pLongFilter->channel;
  scMsg->canSched.publicInterface.rcvNotify.canHwTimestamp    = pCanMsg->timestamp;
  scMsg->canSched.publicInterface.rcvNotify.ltcReceptionTime  = pCanMsg->hrTimestamp;
  scMsg->canSched.publicInterface.rcvNotify.canMsg.protocol   = sddCanMsgProtocol(pCanMsg);
  scMsg->canSched.publicInterface.rcvNotify.canMsg.canId      = pCanMsg->id;
  scMsg->canSched.publicInterface.rcvNotify.canMsg.dataLen    = pCanMsg->length;
  memcpy(&(scMsg->canSched.publicInterface.rcvNotify.canMsg.data),
         (CanSchedTypes_CanData_U*) ((void*) pCanMsg->data),
         sizeof(scMsg->canSched.publicInterface.rcvNotify.canMsg.data));

  HlpMsg_TxRtrn(&scMsg, pLongFilter->owner);

  HlpMsg_AssertSent_f(pSelf->logd, &scMsg, __FILE__, __LINE__, __func__);
}


// =============================================================================
//! @brief  reply to a set filter request
//!
//! @param [in,out] pSelf     CAN scheduler object
//! @param [in,out] pRequest  set filter request
//! @param [in]     result    result value
//!
//!
//! @details
//!
//!   The function notifies the sender of @p pRequest via a Sciopta message about
//!   the result @p result of the set filter operation.
//!
//!   @p pRequest is not freed.
//!
//!
//! @par ERROR
//!
//!   When the Sciopta message can not be sent to the requester, the answer is
//!   lost.
//!
//!
//! @par CONSTRAINTS
//!
//!   The function assumes @p pRequest to be a set-filter-request Sciopta message.
//!
// =============================================================================
static void sendSetFilterReply(CanSchedPrivateTypes_Self_S * pSelf,
                               sc_msg_t *                    pRequest,
                               CanSchedTypes_Error_E         result)
{
  sc_msg_t reply;

  reply = CanSchedPrivateMsgs_AllocCanSetReply((*pRequest)->canSched.setFilterRequest.pool, SC_FATAL_IF_TMO);

  reply->canSched.setFilterReply.base.result = result;

  HlpMsg_TxRtrn(&reply, sc_msgSndGet(pRequest));
  HlpMsg_AssertSent_f(pSelf->logd, &reply, __FILE__, __LINE__, __func__);
}


// =============================================================================
//! @brief  convert a CAN scheduler filter into a sdd filter
//!
//! @param [in] subFilter  CAN scheduler filter
//!
//!
//! @return
//!
//!   A sdd filter with the same information as @p subFilter is returned.
// =============================================================================
static sdd_canFilterType_t subFilter2SddFilter(CanSchedTypes_CanFilter_S * subFilter)
{
  sdd_canFilterType_t sddFilter;

  if (subFilter->protocol == CanSchedTypes_PROTOCOL_EXTENDED)
  {
    sddFilter.flags = CAN_FILTER_FLAG_EXTENDED;
  }
  else
  {
    sddFilter.flags = 0;
  }
  sddFilter.canId = subFilter->compare;
  sddFilter.canMf = subFilter->mask;

  return sddFilter;
}

// =============================================================================
//! @brief  create an sdd filter that accepts all sub filters
//!
//! @param [in] pLongFilter  long filter
//!
//!
//! @details
//!
//!   The function builds a sdd filter, that accepts at least all messages that
//!   would be accepted by the sub filters of @p pLongFilter.  The sdd filter
//!   might accept additional CAN messages, but not less.
//!
//!
//! @return
//!
//!   Equivalent sdd filter.
//!
//! @reviewNice
//!   * 2019-06-13 - HeLLo, GB, MHn
//!     * add a verb to the function name
// =============================================================================
static sdd_canFilterType_t commonSddFilter(CanSchedPrivateMsgs_ScMsgLongFilter_S * pLongFilter)
{
  size_t              idx;
  sdd_canFilterType_t preFilter;
  sdd_canFilterType_t tmpFilter;

  preFilter = subFilter2SddFilter(&(pLongFilter->filterList[0]));

  for (idx = 1; idx < pLongFilter->filterListLength; ++idx)
  {
    tmpFilter = subFilter2SddFilter(&(pLongFilter->filterList[idx]));

    sddFilterOr(&preFilter, &preFilter, &tmpFilter);
  }

  return preFilter;
}


// =============================================================================
//! @brief  combine two can filters to one that at least accepts both
//!
//! @param [out] out  result filter
//! @param [in]  in1  first input filter
//! @param [in]  in2  second input filter
//!
//!
//! @details
//!
//!   The result is a new filter, that accepts all messages that would be
//!   accepted by @p in1 and @p in2.  Additional CAN messages may be accepted too.
//!
//!   Can be used as in-place. (`out == in1 || out == in2`)
//!
//!       msk1  0000 0000  1111 1111
//!       cmp1  0011 0011  0011 0011
//!       msk2  0000 1111  0000 1111
//!       cmp2  0101 0101  0101 0101
//!       --------------------------
//!       msk   0000 0000  0000 1001
//!       cmp   0000 0000  0000 0001
//!
//!   Results in a new filter
//!      `in1 | in2 --> out`    (when in1 or in2 matches, the new one also matches)
//!   but NOT
//!      `out --> in1 | in2`    (when the new filter matches, it does not mean that
//!                              @p in1 or @p in2 matches)
//!
//! @reviewMinor
//!   * The flags of @p in1 and @p in2 are not checked.
//!   * Check them in code or make it a constraint, that they have to be equal.
// =============================================================================
static void sddFilterOr(sdd_canFilterType_t * out, sdd_canFilterType_t * in1, sdd_canFilterType_t * in2)
{
  out->flags = in1->flags;
  out->canMf = in1->canMf & in2->canMf & (~(in1->canId ^ in2->canId));
  out->canId = out->canMf & in1->canId;
}


// =============================================================================
//! @brief  check for same protocol type
//!
//! @param [in] pLongFilter  long filter
//!
//!
//! @details
//!
//!   The function checks, if all sub filters of @p pLongFilter have the same
//!   protocol type.
//!
//!
//! @return
//!
//!   @c true is returned, if all sub filters are of the same protocol type.
//!   Otherwise @c false is returned.
//!
//!
//! @par CONSTRAINTS
//!
//!   The function assumes @p pLongFilter to have at least one subfilter.
//!
// =============================================================================
static bool allSubFilterProtocolsAreConsistent(CanSchedPrivateMsgs_ScMsgLongFilter_S * pLongFilter)
{
  size_t                      idx;
  bool                        areConsistent = true;
  CanSchedTypes_CanProtocol_E protocol       = pLongFilter->filterList[0].protocol;

  for (idx = 1; (idx < pLongFilter->filterListLength) && areConsistent; ++idx)
  {
    if (pLongFilter->filterList[idx].protocol != protocol)
    {
      areConsistent = false;
    }
  }

  return areConsistent;
}


// =============================================================================
//! @brief  check for unallowed bits
//!
//! @param [in] id  extended CAN id
//!
//!
//! @details
//!
//!   This function checks, that only the lower 29 bits of @p id are used.
//!
//!
//! @return
//!
//!   @c true is returned, if only allowed bits are used.  @c false is returned,
//!   when not allowed bits are used.
//!
// =============================================================================
static bool isExtendedCanId(CanSchedTypes_CanId_T id)
{
  register CanSchedTypes_CanId_T canIdExtendedMask = 0x1FFFFFFFu; // 29Bits
  register CanSchedTypes_CanId_T unallowedBitsMask;
  register CanSchedTypes_CanId_T unallowedBits;
  register bool result;

  unallowedBitsMask = ~canIdExtendedMask;
  unallowedBits     = id & unallowedBitsMask;

  if (unallowedBits == 0)
  {
    result = true;
  }
  else
  {
    result = false;
  }

  return result;
}


// =============================================================================
//! @brief  check for unallowed bits
//!
//! @param [in] id  standard CAN id
//!
//!
//! @details
//!
//!   This function checks, that only the lower 11 bits of @p id are used.
//!
//!
//! @return
//!
//!   @c true is returned, if only allowed bits are used.  @c false is returned,
//!   when not allowed bits are used.
//!
// =============================================================================
static bool isStandardCanId(CanSchedTypes_CanId_T id)
{
  register CanSchedTypes_CanId_T canIdNonExtendedMask = 0x000007FFu; // 11Bits
  register CanSchedTypes_CanId_T unallowedBitsMask;
  register CanSchedTypes_CanId_T unallowedBits;
  register bool result;

  unallowedBitsMask = ~canIdNonExtendedMask;
  unallowedBits     = id & unallowedBitsMask;

  if (unallowedBits == 0)
  {
    result = true;
  }
  else
  {
    result = false;
  }

  return result;
}


// =============================================================================
//! @brief  reply to a send request
//!
//! @param [in,out] pSelf        CAN scheduler object
//! @param [in]     pid          requester
//! @param [in]     replyResult  answer
//!
//!
//! @details
//!
//!   The function notifies the process of @p pid via a Sciopta message about the
//!   result @p replyResult of the send operation.
//!
//!
//! @par ERROR
//!
//!   When the Sciopta message can not be sent to the requester, the answer is
//!   lost.
//!
// =============================================================================
static void sendSendReply(CanSchedPrivateTypes_Self_S * pSelf,
                          sc_pid_t                      pid,
                          CanSchedTypes_Error_E         replyResult)
{
  sc_msg_t scMsg;

  scMsg = CanSchedPrivateMsgs_AllocCanSendReply(SC_DEFAULT_POOL, SC_FATAL_IF_TMO);
  scMsg->canSched.send.base.result = replyResult;

  HlpMsg_TxRtrn(&scMsg, pid);
  HlpMsg_AssertSent_f(pSelf->logd, &scMsg, __FILE__, __LINE__, __func__);
}

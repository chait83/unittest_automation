// *****************************************************************************
// **                _______   _________  _________   _______                 **
// **               (  ___  )  \__   __/  \__   __/  (  ____ \                **
// **               | (   ) |     ) (        ) (     | (    \/                **
// **               | |   | |     | |        | |     | (_____                 **
// **               | |   | |     | |        | |     (_____  )                **
// **               | |   | |     | |        | |           ) |                **
// **               | (___) |     | |     ___) (___  /\____) |                **
// **               (_______)     )_(     \_______/  \_______)                **
// **                                                                         **
// **                   Component Engineering Center Berlin                   **
// **                                                                         **
// **   Copyright 2017 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **
// **                                                                         **
// *****************************************************************************
//!
//! @file  CanSched/Private/Proc.c
//!
//! @ingroup grp_CanSchedPrivate
//!
//! @brief  CAN schedueler process implementation
//!
// *****************************************************************************


#include <sciopta_sc.h>
#include <sdd/sdd.h>
#include <sdd/sddcan.h>
#include "Cfg/MsgIds.h"
#include "Cfg/ProcNames.h"
#include "Hlp/Msg.h"
#include "Hlp/ProcVar.h"
#include "Hlp/Failure.h"
#include "CanSched/Private/Msgs.h"
#include "CanSched/Private/Channel.h"


// #############################################################################
// ## LOCAL DEFINES ############################################################
// #############################################################################

//! @brief  pool that should be used for messages to the proxy pool
#define CANSCHEDPRRIVATEPROC_PROXY_POOL   (SC_DEFAULT_POOL)





// #############################################################################
// ## LOCAL TYPES ##############################################################
// #############################################################################

//! @brief  union sc_msg CanSched/Private/Proc.c
union sc_msg  // polyspace MISRA-C3:5.7 [To investigate:Medium] "CECBSAFETY-3050"
// =============================================================================
{
  sc_msgid_t                        scMsgId;   //!< Sciopta message ID
  CanSchedPrivateMsgs_PrivateMsgs_U canSched;  //!< CAN scheduler private messages
};





// #############################################################################
// ## LOCAL FUNCTION DECLARATIONS ##############################################
// #############################################################################

static void initCansched(CanSchedPrivateTypes_Self_S * pSelf);
static void handleScMsg(CanSchedPrivateTypes_Self_S * pSelf, sc_msg_t * pScMsg);





// #############################################################################
// ## IMPLEMENTATION OF SCIOPTA PROCESSES ######################################
// #############################################################################


// =============================================================================
extern SC_PROCESS(CanSchedPrivateProc_Proc)
{
  // messages expected from the device (can driver)
  const sc_msgid_t searchDev[] = {
#if CFGCANSCHED_CHANNELS >= 1
      SDD_CAN_RECEIVED_MSG(CFGCANSCHED_CHANNEL_0_UNIT),
#endif
#if CFGCANSCHED_CHANNELS >= 2
      SDD_CAN_RECEIVED_MSG(CFGCANSCHED_CHANNEL_1_UNIT),
#endif
#if CFGCANSCHED_CHANNELS >= 3
      SDD_CAN_RECEIVED_MSG(CFGCANSCHED_CHANNEL_2_UNIT),
#endif
      SDD_CAN_WRITE_REPLY,
      0 // terminating element
  };
  // messages expected from the SRS
  const sc_msgid_t searchSrs[] =
  {
      CFGMSGIDS_CANSCHED_ALLOCATEFILTER_REQUEST_SRS_MSGID,
      CFGMSGIDS_CANSCHED_FREEFILTER_REQUEST_SRS_MSGID,
      CFGMSGIDS_CANSCHED_SETFILTER_REQUEST_SRS_MSGID,
      CFGMSGIDS_CANSCHED_SEND_REQUEST_SRS_MSGID,
      0 // terminating element
  };
  // messages expected from the SCI proxy
  const sc_msgid_t searchProxy[] =
  {
      CFGMSGIDS_CANSCHED_ALLOCATEFILTER_REQUEST_NONSRS_MSGID,
      CFGMSGIDS_CANSCHED_FREEFILTER_REQUEST_NONSRS_MSGID,
      CFGMSGIDS_CANSCHED_SETFILTER_REQUEST_NONSRS_MSGID,
      CFGMSGIDS_CANSCHED_SEND_REQUEST_NONSRS_MSGID,
      0 // terminating element
  };
  cmsgidFilter_t const rxList[] = { searchDev, searchSrs, searchProxy, NULL };
  CanSchedPrivateTypes_Self_S self;
  sc_msg_t scMsg;

  HlpProcVar_Init("CanSched", 0);

  initCansched(&self);

  for (;;)
  {
    // get the next relevant msg
    scMsg = HlpMsg_RxPriorised(rxList);

    // handle the received message
    handleScMsg(&self, &scMsg);
  }
}





// #############################################################################
// ## LOCAL FUNCTIONS ##########################################################
// #############################################################################


// #############################################################################
// Handle Incoming Sciopta Messages
// #############################################################################

// =============================================================================
//! @brief  handle an received Sciopta message
//!
//! @param [in,out] pSelf   CAN scheduler object
//! @param [in,out] pScMsg  to be handled Sciopta message
//!
//!
//! @details
//!
//!   This function determines the associated channel of @p pScMsg and
//!   passes the message to the channel.
//!
//!   If it is an unexpected sciopta message, the message is deleted and a debug
//!   message is printed.
//!
// =============================================================================
static void handleScMsg(CanSchedPrivateTypes_Self_S * pSelf, sc_msg_t * pScMsg)
{
  ssize_t       channelIdx = -1;  // -1 == not found
  const size_t  channels = sizeof(pSelf->channel) / sizeof(pSelf->channel[0]);

  // check for driver sent messages
  for ( size_t  i = 0; (i < channels) && (channelIdx == -1); ++i)
  {
    const sc_pid_t  pid = sc_msgSndGet (pScMsg);

    if (   (pid == pSelf->channel[i].pDev->sender)
        || (pid == pSelf->channel[i].pDev->receiver)
       )
    {
      channelIdx = (ssize_t)i;
    }
  }

  // check for user sent messages
  if (channelIdx == -1)
  {
    switch ((*pScMsg)->scMsgId)
    {
      case CFGMSGIDS_CANSCHED_SETFILTER_REQUEST_SRS_MSGID:
      case CFGMSGIDS_CANSCHED_SETFILTER_REQUEST_NONSRS_MSGID:
        if ((*pScMsg)->canSched.setFilterRequest.channel >= channels)
        {
          (*pScMsg)->canSched.setFilterRequest.base.result = CanSchedTypes_ERROR_CHANNEL_INDEX;
          HlpMsg_TxIgnr(pScMsg, sc_msgSndGet(pScMsg));
        }
        else
        {
          channelIdx = (ssize_t)(*pScMsg)->canSched.setFilterRequest.channel;
        }
        break;

      case CFGMSGIDS_CANSCHED_ALLOCATEFILTER_REQUEST_SRS_MSGID:
      case CFGMSGIDS_CANSCHED_ALLOCATEFILTER_REQUEST_NONSRS_MSGID:
        if ((*pScMsg)->canSched.allocateFilter.channel >= channels)
        {
          (*pScMsg)->canSched.allocateFilter.base.result = CanSchedTypes_ERROR_CHANNEL_INDEX;
          HlpMsg_TxIgnr(pScMsg, sc_msgSndGet(pScMsg));
        }
        else
        {
          channelIdx = (ssize_t)(*pScMsg)->canSched.allocateFilter.channel;
        }
        break;

      case CFGMSGIDS_CANSCHED_FREEFILTER_REQUEST_SRS_MSGID:
      case CFGMSGIDS_CANSCHED_FREEFILTER_REQUEST_NONSRS_MSGID:
        if ((*pScMsg)->canSched.freeFilter.channel >= channels)
        {
          (*pScMsg)->canSched.freeFilter.base.result = CanSchedTypes_ERROR_CHANNEL_INDEX;
          HlpMsg_TxIgnr(pScMsg, sc_msgSndGet(pScMsg));
        }
        else
        {
          channelIdx = (ssize_t)(*pScMsg)->canSched.freeFilter.channel;
        }
        break;

      case CFGMSGIDS_CANSCHED_SEND_FIRE_REQUEST_SRS_MSGID:
      case CFGMSGIDS_CANSCHED_SEND_REQUEST_SRS_MSGID:
      case CFGMSGIDS_CANSCHED_SEND_REQUEST_NONSRS_MSGID:
        if ((*pScMsg)->canSched.send.channel >= channels)
        {
          (*pScMsg)->canSched.send.base.result = CanSchedTypes_ERROR_CHANNEL_INDEX;
          HlpMsg_TxIgnr(pScMsg, sc_msgSndGet(pScMsg));
        }
        else
        {
          channelIdx = (ssize_t)(*pScMsg)->canSched.send.channel;
        }
        break;

      default:
        // empty
        break;
    }
  }

  //! @review
  //!   * 2019-07-04 - HeLLo
  //!     * The above checks for a valid channel send the message back with the
  //!       correct error code and the message is @c NULL afterwards.
  //!     * This can cause a `NULL`-pointer access in HlpMsg_Unexpected().
  //!     * There are two ways to check this:
  //!       * Condition should also check for `(*pScMsg != NULL)`.
  //!       * Separate between `channelIdx == -1` (unexpected message) and
  //!         `channelIdx == -2` message was expected, but requested channel was
  //!         invalid.  In this case the HlpMsg_Unexpected() should only called
  //!         for `channelIdx == -1`.
  //!     * CECBSAFETY-2460
  if (channelIdx < 0)
  {
    HlpMsg_Unexpected(pSelf->logd, pScMsg);
  }
  else
  {
    (void)CanSchedPrivateChannel_HandleScMsg(pSelf, (CanSchedTypes_CanChannel_T) channelIdx, pScMsg);
  }

  HlpMsg_AssertFreed_f(pSelf->logd, pScMsg, __FILE__, __LINE__, __func__);
}



// #############################################################################
// Internal Data Initialization
// #############################################################################


// =============================================================================
//! @brief  initialize self structure of CAN scheduler
//!
//! @param [in,out] pSelf  to be initiated CAN scheduler object
//!
//!
//! @details
//!
//!   This function initializes the data structure @p pSelf.  It
//!
//!     * it initializes all local variables,
//!     * connects to the log deamon,
//!     * connects to the device manager and
//!     * initializes all configured channels (including opening the driver).
//!
// =============================================================================
static void initCansched(CanSchedPrivateTypes_Self_S * pSelf)
{
  pSelf->proxyPool = CANSCHEDPRRIVATEPROC_PROXY_POOL;

  pSelf->logd = HlpProcVar_GetLogd();

  pSelf->devMan = sdd_manGetRoot(CfgProcNames_scpDevman, "/", SC_DEFAULT_POOL, SC_ENDLESS_TMO);
  if (pSelf->devMan == NULL)
  {
    logd_printf(pSelf->logd, 0, "Could not open devman\n");
    HlpFailure_EndlessLoopSleeping(sc_tickMs2Tick(1000));
  }

#if CFGCANSCHED_CHANNELS >= 1
  CanSchedPrivateChannel_Init(pSelf,
                       &(pSelf->channel[0]),
                       CFGCANSCHED_CHANNEL_0_UNIT,
                       CFGCANSCHED_CHANNEL_0_BAUD,
                       CANSCHEDCFG_CHANNEL_0_INTERFACE,
                       CFGCANSCHED_CHANNEL_0_USED_MAILBOXES,
                       CFGCANSCHED_CHANNEL_0_SRS_FILTERS);
#endif

#if CFGCANSCHED_CHANNELS >= 2
  CanSchedPrivateChannel_Init(pSelf,
                       &(pSelf->channel[1]),
                       CFGCANSCHED_CHANNEL_1_UNIT,
                       CFGCANSCHED_CHANNEL_1_BAUD,
                       CANSCHEDCFG_CHANNEL_1_INTERFACE,
                       CFGCANSCHED_CHANNEL_1_USED_MAILBOXES,
                       CFGCANSCHED_CHANNEL_1_SRS_FILTERS);
#endif

#if CFGCANSCHED_CHANNELS >= 3
  CanSchedPrivateChannel_Init(pSelf,
                       &(pSelf->channel[2]),
                       CFGCANSCHED_CHANNEL_2_UNIT,
                       CFGCANSCHED_CHANNEL_2_BAUD,
                       CANSCHEDCFG_CHANNEL_2_INTERFACE,
                       CFGCANSCHED_CHANNEL_2_USED_MAILBOXES,
                       CFGCANSCHED_CHANNEL_2_SRS_FILTERS);
#endif
}

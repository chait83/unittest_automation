// *****************************************************************************
// **                _______   _________  _________   _______                 **
// **               (  ___  )  \__   __/  \__   __/  (  ____ \                **
// **               | (   ) |     ) (        ) (     | (    \/                **
// **               | |   | |     | |        | |     | (_____                 **
// **               | |   | |     | |        | |     (_____  )                **
// **               | |   | |     | |        | |           ) |                **
// **               | (___) |     | |     ___) (___  /\____) |                **
// **               (_______)     )_(     \_______/  \_______)                **
// **                                                                         **
// **                   Component Engineering Center Berlin                   **
// **                                                                         **
// **   Copyright 2017 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **
// **                                                                         **
// *****************************************************************************
//!
//! @file
//!
//! @ingroup grp_CanSchedPrivate
//!
//! @brief  CAN scheduler dummy filter
//!
//! @reviewNoAction
//!  * 2019-06-11 - HeLLo, GB, MHn
//!    * No findings.
// *****************************************************************************

#ifndef CANSCHEDPRIVATEDUMMYFILTER_H
#define CANSCHEDPRIVATEDUMMYFILTER_H



#include <sdd/sdd.h>
#include <sdd/sddcan.h>

// =============================================================================
//! @brief  used for unused mailbox slots
//!
//! @sa #CanSchedPrivateTypes_Channel_S
//!
// =============================================================================
extern const sdd_canFilterType_t CanSchedPrivateDummyFilter_dummyFilter;


#endif // CANSCHEDPRIVATEDUMMYFILTER_H

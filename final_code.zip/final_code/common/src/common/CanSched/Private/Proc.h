// *****************************************************************************
// **                _______   _________  _________   _______                 **
// **               (  ___  )  \__   __/  \__   __/  (  ____ \                **
// **               | (   ) |     ) (        ) (     | (    \/                **
// **               | |   | |     | |        | |     | (_____                 **
// **               | |   | |     | |        | |     (_____  )                **
// **               | |   | |     | |        | |           ) |                **
// **               | (___) |     | |     ___) (___  /\____) |                **
// **               (_______)     )_(     \_______/  \_______)                **
// **                                                                         **
// **                   Component Engineering Center Berlin                   **
// **                                                                         **
// **   Copyright 2017 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **
// **                                                                         **
// *****************************************************************************
//!
//! @file CanSched/Private/Proc.h
//!
//! @ingroup grp_CanSchedPrivate
//!
//! @brief  CAN scheduler process
//!
//! @reviewNoAction
//!   * 2019-06-13 - HeLLo, GB, MHn
//!     * No findings.
// *****************************************************************************

#ifndef CANSCHEDPRIVATEPROC_H
#define CANSCHEDPRIVATEPROC_H

#include <sciopta_sc.h>

// =============================================================================
//! @brief process of the CAN scheduler
//!
//!
//! @details
//!
//!   This function initializes all structures of the CAN scheduler and enters an
//!   endless loop.
//!
//!   In this loop it waits for Sciopta messages in a priorized order: first
//!   driver messages, then Srs requests and last requests from the proxy.  When
//!   no messages of these are available, it sleeps until any Sciopta message is
//!   received.
//!
//!   As soon as a message is received it is handled by a sub function, that
//!   passes the message to the associated channel.
//!
// =============================================================================
extern SC_PROCESS(CanSchedPrivateProc_Proc);


#endif // CANSCHEDPRIVATEPROC_H

// *****************************************************************************
// **                _______   _________  _________   _______                 **
// **               (  ___  )  \__   __/  \__   __/  (  ____ \                **
// **               | (   ) |     ) (        ) (     | (    \/                **
// **               | |   | |     | |        | |     | (_____                 **
// **               | |   | |     | |        | |     (_____  )                **
// **               | |   | |     | |        | |           ) |                **
// **               | (___) |     | |     ___) (___  /\____) |                **
// **               (_______)     )_(     \_______/  \_______)                **
// **                                                                         **
// **                   Component Engineering Center Berlin                   **
// **                                                                         **
// **   Copyright 2017 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **
// **                                                                         **
// *****************************************************************************

//!
//! @file
//!
//! @ingroup grp_CanSchedPrivate
//!
//! @brief  CanScheduler internal types
//!

#ifndef CANSCHEDPRIVATETYPES_H
#define CANSCHEDPRIVATETYPES_H


#include <sciopta_sc.h>
#include <stdbool.h>
#include <logd/logd.h>
#include "CanSched/Cfg.h"
#include "CanSched/Private/DummyFilter.h"





// #############################################################################
// ##  BASIC TYPES  ############################################################
// #############################################################################

// =============================================================================
//! @brief  index of a CAN unit
// =============================================================================
typedef uint8_t CanSchedPrivateTypes_UnitIdx_T;


// =============================================================================
//! @brief  state of the driver state machine
// =============================================================================
enum CanSchedPrivateTypes_DriverState
{
  CanSchedPrivateTypes_DRIVERSTATE_IDLE            = 0,  //!< driver has no tasks
  CanSchedPrivateTypes_DRIVERSTATE_SENDING         = 1,  //!< driver has send request
};
typedef enum CanSchedPrivateTypes_DriverState CanSchedPrivateTypes_DriverState_E;






// #############################################################################
// ##  COMPLEX TYPES  ##########################################################
// #############################################################################


// =============================================================================
//! @brief  data associated to a mailbox
//!
//!
//! @details
//!
//!   #isAllocated defines if this mailbox is already allocated.
//!
//!   #owner holds the Sciopta process id if the mailbox is already allocated.
//!   Otherwise it shall be #SC_ILLEGAL_PID.
//!
//!   #longFilter holds the Sciopta message of type
//!   #CanSchedPrivateMsgs_ScMsgLongFilter_S or @c NULL, if the filter is not
//!   programmed or not allocated yet.
//!
//!   #programmedFilter holds the sdd filter, that is installed in the
//!   associated hardware filter.  If the filter is not yet programmed by a
//!   process, the value is set to #CanSchedPrivateDummyFilter_dummyFilter.
//!   The same value is assigned, when the filter is freed.
//!
// =============================================================================
struct CanSchedPrivateTypes_Mailbox
{
  bool                isAllocated;        //!< mailbox is allocated by #owner
  sc_pid_t            owner;              //!< owner of the mailbox
  sdd_canFilterType_t programmedFilter;   //!< programmed hardware filter
  sc_msg_t            longFilter;         //!< user requested software filter
};
typedef struct CanSchedPrivateTypes_Mailbox CanSchedPrivateTypes_Mailbox_S;


// =============================================================================
//! @brief  element of sending queue
//!
//! @details
//!
//!   #request holds the requesting Sciopta message of type
//!   #CanSchedPrivateMsgs_ScMsgSend_S.  If the queue element is not filled,
//!   #request is @c NULL.
//!
//!   #pNext holds the pointer to the next element in the queue.  If there is no
//!   following element or the queue element is not filled, #pNext is @c NULL.
//!
// =============================================================================
struct CanSchedPrivateTypes_SendQueueElement
{
  sc_msg_t                                       request;  //!< sent request
  struct CanSchedPrivateTypes_SendQueueElement * pNext;    //!< next queue element
};
typedef struct CanSchedPrivateTypes_SendQueueElement CanSchedPrivateTypes_SendQueueElement_S;


// =============================================================================
//! @brief  sending queue
//!
//!
//! @details
//!
//!   #pFirst holds the pointer to the first element in the queue.  If the queue
//!   is empty, #pFirst is @c NULL.
//!
//!   #queue holds the queue as a single linked list.  #pFirst points to the
//!   first element in the queue.  `#pFirst->pNext` is the second,
//!   `#pFirst->pNext->pNext` the third and so on...
//!
//!   Not used elements of #queue have the value @c NULL for
//!   `#queue[i].request`.  @sa struct CanSchedPrivateTypes_SendQueueElement
// =============================================================================
struct CanSchedPrivateTypes_SendQueue
{
  CanSchedPrivateTypes_SendQueueElement_S * pFirst;                              //!< first used element in send queue
  CanSchedPrivateTypes_SendQueueElement_S queue[CFGCANSCHED_SEND_QUEUE_LENGTH];  //!< used and not used elements
};
typedef struct CanSchedPrivateTypes_SendQueue CanSchedPrivateTypes_SendQueue_S;


// =============================================================================
//! @brief  configuration of a channel
//!
//!
//! @details
//!
//!   #unitIdx is the unit number of the hardware unit.
//!
//!   #baud specifies the baud rate according to the unnamed enum in
//!   sdd/sddcan.h.  (`_CAN_125k_`, ...)
//!
//!   #interface holds the interface string.  (`"can0"`, `"can1"`, ...)  It is used
//!   to initiate the interaction with the Sciopta driver through the device
//!   manager.  #pDev holds the communication point with the driver.
//!
//!   #driverState stores if the driver is currently handling a request and
//!   which one.
//!
//!   #sendQueue holds the queue of CAN messages, that shall be sent but were
//!   not transfered to the driver yet.  The queue is sorted ascending the CAN
//!   id.  The extended and standard IDs are mixed.  #currentSendRequest is
//!   @c NULL, except when the #driverState is
//!   #CanSchedPrivateTypes_DRIVERSTATE_SENDING.  In this case
//!   #currentSendRequest holds a pointer to a sciopta message of type
//!   #CanSchedPrivateMsgs_ScMsgSend_S, which is the message that is currently
//!   put on the bus by the CAN scheduler.  This is used to inform the sender
//!   after a successful or failed transmission, if the sending call was
//!   blocking.
//!
//!   #mailboxesUsed specifies how many filters are allowed to be installed for
//!   this CAN channel.  From these #mailboxesUsed filters the first
//!   #mailboxesSrs filters are exclusive reserved for safety processes.  The
//!   last `#mailboxesUsed - #mailboxesSrs` mailboxes are exclusive reserved for
//!   the CAN proxy.
//!
//!   #mailbox is an array, that holds at least #mailboxesUsed members.
//!
//! @reviewMinor
//!  * 2019-06-11 - HeLLo, GB, MHn
//!    * Name of `mailboxesUsed` is misleading.  Rename to
//!      `mailboxesAvailableSize` or similar.
// =============================================================================
struct CanSchedPrivateTypes_Channel
{
  CanSchedPrivateTypes_UnitIdx_T     unitIdx;        //!< harware unit
  uint8_t                            baud;           //!< baud rate enum from sdd/sddcan.h
  const char *                       interface;      //!< interface identifier
  sdd_obj_t *                        pDev;           //!< device handler
  CanSchedTypes_CanFilterIndex_T     mailboxesUsed;  //!< number of members of #mailbox, that might be used
  CanSchedTypes_CanFilterIndex_T     mailboxesSrs;   //!< number of reserved mailboxes for safety software
  bool                               mailboxUpdateIsPending;  //!< filter update is pending
  CanSchedPrivateTypes_DriverState_E driverState;    //!< state if driver is performing a request
  CanSchedPrivateTypes_SendQueue_S   sendQueue;      //!< list of to be sent CAN messages
  sc_msg_t                           currentSendRequest;      //!< sent request that is currently handled by the driver
  CanSchedPrivateTypes_Mailbox_S     mailbox[CANSCHEDCFG_MAX_MAILBOX_SIZE];  //!< installed mailbox filters
};
typedef struct CanSchedPrivateTypes_Channel CanSchedPrivateTypes_Channel_S;


// =============================================================================
//! @brief  scheduler state (used as `self` in subfunctions)
//!
//!
//! @details
//!
//!   #logd holds the handler to print debug messages if necessary.
//!
//!   #channel holds the implemented channels.
//!
//!   #proxyPool holds the message pool ID, that shall be used to allocate
//!   messages from, when the message shall be sent to the CAN proxy.
//!
//!   #devMan holds the communication point to interact with the device manager.
//!
// =============================================================================
struct CanSchedPrivateTypes_Self
{
  logd_t *                       logd;         //!< log deamon
  CanSchedPrivateTypes_Channel_S channel[CFGCANSCHED_CHANNELS];    //!< channels
  sc_poolid_t                    proxyPool;    //!< pool for received non-safety messages
  sdd_obj_t *                    devMan;       //!< handler of device manager
};
typedef struct CanSchedPrivateTypes_Self CanSchedPrivateTypes_Self_S;



#endif // CANSCHEDPRIVATETYPES_H

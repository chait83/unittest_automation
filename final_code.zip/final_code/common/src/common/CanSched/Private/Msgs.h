// *****************************************************************************
// **                _______   _________  _________   _______                 **
// **               (  ___  )  \__   __/  \__   __/  (  ____ \                **
// **               | (   ) |     ) (        ) (     | (    \/                **
// **               | |   | |     | |        | |     | (_____                 **
// **               | |   | |     | |        | |     (_____  )                **
// **               | |   | |     | |        | |           ) |                **
// **               | (___) |     | |     ___) (___  /\____) |                **
// **               (_______)     )_(     \_______/  \_______)                **
// **                                                                         **
// **                   Component Engineering Center Berlin                   **
// **                                                                         **
// **   Copyright 2017 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **
// **                                                                         **
// *****************************************************************************
//!
//! @file  CanSched/Private/Msgs.h
//!
//! @ingroup grp_CanSchedPrivate
//!
//! @brief  Internal Sciopta Messages for the CAN Driver Scheduler.
//!
//! @reviewNice
//!  * 2019-05-28 - HeLLo, GB, MHn
//!    * s/CAN Driver Sched/CAN Sched/
//!
//! @reviewNice
//!  * 2019-05-28 - HeLLo, GB, MHn
//!    * Improvement: the `tmo` parameter could be removed and derived from isSrs
// *****************************************************************************

#ifndef CANSCHEDPRIVATEMSGS_H
#define CANSCHEDPRIVATEMSGS_H


#include "CanSched/CanSched.h"
#include "CanSched/Msgs.h"



// =============================================================================
//! @brief  basic type for all requests
//!
//!
//! @details
//!
//!   #CanSchedPrivateMsgs_ScMsgBase_S shall be used as the first member of
//!   Sciopta messages that are used as requests to the CAN scheduler to allow a
//!   direct response.
//!
//!
//! @par MEMBERS
//!
//!   #scMsgId holds the Sciopate message ID and is used always.
//!
//!   #result is only used when the message is reused as a reply.
//!
//!
//! @par MESSAGE IDS
//!
//!   Not used directly, therefore no message IDs.
//!
//! @reviewNice
//!  * 2019-05-28 - HeLLo, GB, MHn
//!    * s/Sciopate/Sciopta/
// =============================================================================
struct CanSchedPrivateMsgs_ScMsgBase
{
  sc_msgid_t            scMsgId;  //!< Sciopta message ID
  CanSchedTypes_Error_E result;   //!< result in reply
};
typedef struct CanSchedPrivateMsgs_ScMsgBase CanSchedPrivateMsgs_ScMsgBase_S;


// =============================================================================
//! @brief  represents a filter setting request
//!
//!
//! @details
//!
//!   #CanSchedPrivateMsgs_ScMsgFilter is used as a request to set a CAN receive
//!   filter and after installation as a memory area to store the filter data.
//!
//!
//! @par MEMBERS
//!
//!   #base holds the Sciopta message ID. `base.return` is not used.
//!
//!   #channel holds the channel (not unit).
//!
//!   #isBlockingCall defines when the reply shall be sent.  If @c true the reply
//!   is sent when the filter is successfully changed in hardware or an error
//!   occured.  If @c false the reply is sent as soon as the request is stored
//!   internally -- so the exchange in the hardware is asynchronous to the
//!   message exchange.
//!
//!   #replyWasSent is @c true if a reply of an accepted filter was already sent.
//!   It is not used for the request.
//!
//!   #owner holds the sender of the request.  It is not used for the request
//!   but only to manage incoming CAN messages.  Is filled by receiver.
//!
//!   #pool holds the pool id of the Sciopta message pool, where messages are
//!   allocated from to communicate with #owner in case of incoming CAN
//!   messages.  It is not used for the request but only to manage incoming CAN
//!   messages.  Is filled by receiver.
//!
//!   #filterIndex holds the index of the filter that shall be set in the
//!   channel #channel.  This filter index shall be requested by #owner with a
//!   preceding #CanSchedPrivateMsgs_ScMsgAllocateFilter_S request.  Is filled
//!   by receiver.
//!
//!   #filterListLength holds the number of elements that are in #filterList.
//!
//!   #filterList is an array of #filterListLength filters.  If at least one of
//!   these filters matches a CAN identifier on the bus, the CAN message is
//!   forwarded to #owner.  All filters have to be either extended or not
//!   extended (standard).
//!
//!
//! \par MESSAGE IDS
//!
//!    message ID                                        | purpose
//!   ---------------------------------------------------|------------------------------------
//!   #CFGMSGIDS_CANSCHED_SETFILTER_REQUEST_SRS_MSGID    | for requests from safety processes.
//!   #CFGMSGIDS_CANSCHED_SETFILTER_REQUEST_NONSRS_MSGID | for requests from CAN proxy process.
//!   #CFGMSGIDS_CANSCHED_LONGFILTER_SRS_MSGID           | for internal management of safety filters
//!   #CFGMSGIDS_CANSCHED_LONGFILTER_NONSRS_MSGID        | for internal management of proxy filters
//!
//! @reviewMinor
//!  * 2019-05-28 - HeLLo, GB, MHn
//!    * Filter length is not specified in array.  Use maximum value that can
//!      be configured in the config.
//!
//! @reviewMinor
//!  * 2019-05-28 - HeLLo, GB, MHn
//!    * Improvement: During reception the length of the sciopta message should
//!      be checked, that it can store at least #filterListLength parameters.
// =============================================================================

// polyspace +12 MISRA-C3:18.7 [To fix:Medium] "CECBSAFETY-3054"
struct CanSchedPrivateMsgs_ScMsgFilter
{
  CanSchedPrivateMsgs_ScMsgBase_S base;             //!< message base
  CanSchedTypes_CanChannel_T      channel;          //!< CAN channel index
  bool                            isBlockingCall;   //!< wait for configured hardware filter
  bool                            replyWasSent;     //!< reply was already sent
  sc_pid_t                        owner;            //!< PID of filter owner
  sc_poolid_t                     pool;             //!< Sciopta pool ID for incoming CAN messages
  CanSchedTypes_CanFilterIndex_T  filterIndex;      //!< filter slot
  size_t                          filterListLength; //!< elements in @p filterList
  CanSchedTypes_CanFilter_S       filterList[];     //!< filters
};
typedef struct CanSchedPrivateMsgs_ScMsgFilter CanSchedPrivateMsgs_ScMsgSetFilterRequest_S;
typedef struct CanSchedPrivateMsgs_ScMsgFilter CanSchedPrivateMsgs_ScMsgLongFilter_S;


// =============================================================================
//! @brief  allocate a sciopta message
//!
//! @param [in] pool   Sciopta message pool
//! @param [in] tmo    maximal timeout
//! @param [in] isSrs  use safety message ID
//! @param [in] n      number of filters
//!
//!
//! @details
//!
//!   The function allocates a Sciopta message from the message pool @p pool of
//!   type #CanSchedPrivateMsgs_ScMsgSetFilterRequest_S.  @p tmo defines the
//!   timeout for the sc_msgAlloc() function.  @p isSrs defines the message ID.
//!
//!   @p n defines the number of members in @p filterList.
//!
//!
//! @retval NULL    no message allocated
//! @retval <else>  allocated message
//!
// =============================================================================
extern sc_msg_t CanSchedPrivateMsgs_AllocCanSetFilter(sc_poolid_t pool, sc_ticks_t tmo, bool isSrs, size_t n);


// =============================================================================
//! @brief  represents a filter setting reply
//!
//!
//! @details
//!
//!   #CanSchedPrivateMsgs_ScMsgSetFilterReply_S is used as a reply to set a CAN
//!   receive filter.
//!
//!
//! @par MEMBERS
//!
//!   `base.scMsgId` holds the sciopta message ID.
//!
//!   `base.return` holds the result of the set operation.  The result
//!   #CanSchedTypes_ERROR_SUCCESS means success, all other values mean some
//!   kind of failure:
//!
//!    Error Code                                |  Description
//!   ------------------------------------------ | ----------------------------
//!    #CanSchedTypes_ERROR_CHANNEL_INDEX        |  `channel` is invalid
//!    #CanSchedTypes_ERROR_FILTER_INDEX         |  `filterIndex` is invalid
//!    #CanSchedTypes_ERROR_FILTER_NOT_ALLOCATED |  `filterIndex` is not allocated
//!    #CanSchedTypes_ERROR_FILTER_FALSE_OWNER   |  `filterIndex` is allocated by someone else
//!    #CanSchedTypes_ERROR_UPDATE_PENDING       |  there is an older set filter request, that was not applied yet
//!    #CanSchedTypes_ERROR_FILTER_LENGTH        |  `filterListLength` is invalid
//!    #CanSchedTypes_ERROR_FILTER_TYPE          |  `filterList` elements are not of same type (all extended/standard)
//!
//!
//! @par MESSAGE IDS
//!
//!    message ID                                 |  purpose
//!   ------------------------------------------- | -----------------------------------
//!    #CFGMSGIDS_CANSCHED_SETFILTER_REPLY_MSGID  |  for replies after setting filter requests
//!
// =============================================================================
struct CanSchedPrivateMsgs_ScMsgSetFilterReply
{
  CanSchedPrivateMsgs_ScMsgBase_S base;  //!< message base
};
typedef struct CanSchedPrivateMsgs_ScMsgSetFilterReply CanSchedPrivateMsgs_ScMsgSetFilterReply_S;


// =============================================================================
//! @brief  allocate a sciopta message
//!
//! @param [in] pool   Sciopta message pool
//! @param [in] tmo    maximal timeout
//!
//!
//! @details
//!
//!   The function allocates a Sciopta message from the message pool @p pool of
//!   type #CanSchedPrivateMsgs_ScMsgSetFilterReply_S.  @p tmo defines the
//!   timeout for the sc_msgAlloc() function.
//!
//!
//! @retval NULL    no message allocated
//! @retval <else>  allocated message
//!
// =============================================================================
extern sc_msg_t CanSchedPrivateMsgs_AllocCanSetReply(sc_poolid_t pool, sc_ticks_t tmo);  // polyspace MISRA-C3:5.1 [To fix:Medium] "CECBSAFETY-3049"  // polyspace ISO-17961:funcdecl [To investigate:Medium] "CECBSAFETY-3100"


// =============================================================================
//! @brief  allocate a filter index
//!
//! @details
//!
//!   #CanSchedPrivateMsgs_ScMsgAllocateFilter_S is used as a request to
//!   allocate a filter and as its reply.
//!
//!
//! @par MEMBERS
//!
//!   `base.scMsgId` holds the sciopta message ID.
//!
//!   `base.return` is only used, when the message is used as a reply.  It holds
//!   the result of the allocate operation.  #CanSchedTypes_ERROR_SUCCESS means
//!   success, all other values mean some kind of failure:
//!
//!    Error Code                           |  Description
//!   ------------------------------------- | ----------------------------
//!     #CanSchedTypes_ERROR_CHANNEL_INDEX  |  #channel is invalid
//!     #CanSchedTypes_ERROR_FILTER_INDEX   |  no free filter available
//!
//!   #channel holds the channel (not unit).
//!
//!   #filterIndex is ignored when used as a request.  When used as a reply and
//!   `base.return` does not indicate an error, #filterIndex holds the index of
//!   the new allocated filter.
//!
//!
//! @par MESSAGE IDS
//!
//!    message ID                                             |  purpose
//!   ------------------------------------------------------- | -----------------------------------
//!   #CFGMSGIDS_CANSCHED_ALLOCATEFILTER_REQUEST_SRS_MSGID    | for requests from SRS
//!   #CFGMSGIDS_CANSCHED_ALLOCATEFILTER_REQUEST_NONSRS_MSGID | for requests from proxy
//!   #CFGMSGIDS_CANSCHED_ALLOCATEFILTER_REPLY_MSGID          | for replies
//!
//! @reviewNice
//!  * 2019-05-28 - HeLLo, GB, MHn
//!    * remove "index" from brief description
// =============================================================================
struct CanSchedPrivateMsgs_ScMsgAllocateFilter
{
  CanSchedPrivateMsgs_ScMsgBase_S base;        //!< message base
  CanSchedTypes_CanChannel_T      channel;     //!< CAN channel index
  CanSchedTypes_CanFilterIndex_T  filterIndex; //!< filled when reply
};
typedef struct CanSchedPrivateMsgs_ScMsgAllocateFilter CanSchedPrivateMsgs_ScMsgAllocateFilter_S;


// =============================================================================
//! @brief  allocate a sciopta message
//!
//! @param [in] pool   Sciopta message pool
//! @param [in] tmo    maximal timeout
//! @param [in] isSrs  use safety message ID
//!
//!
//! @details
//!
//!   The function allocates a Sciopta message from the message pool @p pool of
//!   type #CanSchedPrivateMsgs_ScMsgAllocateFilter_S.  @p tmo defines the
//!   timeout for the sc_msgAlloc() function.  @p isSrs defines the message ID of
//!   the request.
//!
//!
//! @retval NULL    no message allocated
//! @retval <else>  allocated message
//!
// =============================================================================
extern sc_msg_t CanSchedPrivateMsgs_AllocCanAllocateFilter(sc_poolid_t pool, sc_ticks_t tmo, bool isSrs);


// =============================================================================
//! @brief  free a filter index
//!
//!
//! @details
//!
//!   #CanSchedPrivateMsgs_ScMsgFreeFilter_S is used as a request to free a
//!   filter and as its reply.
//!
//!
//! @par MEMBERS
//!
//!   `base.scMsgId` holds the sciopta message ID.
//!
//!   `base.return` s only used, when it the message is used as a reply.  It
//!   holds the result of the free operation.  #CanSchedTypes_ERROR_SUCCESS
//!   means success, all other values mean some kind of failure:
//!
//!    Error Code                                 |  Description
//!   ------------------------------------------- | ----------------------------
//!     #CanSchedTypes_ERROR_CHANNEL_INDEX        | #channel is invalid
//!     #CanSchedTypes_ERROR_FILTER_INDEX         | #filterIndex is invalid
//!     #CanSchedTypes_ERROR_FILTER_NOT_ALLOCATED | #filterIndex is not allocated
//!     #CanSchedTypes_ERROR_FILTER_FALSE_OWNER   | #filterIndex is allocated by someone else
//!
//!   #channel holds the channel (not unit).
//!
//!   #filterIndex holds the index of the to be freed filter.
//!
//!
//! @par MESSAGE IDS
//!
//!    message ID                                         |  purpose
//!   --------------------------------------------------- | -----------------------------------
//!   #CFGMSGIDS_CANSCHED_FREEFILTER_REQUEST_SRS_MSGID    | for requests from SRS
//!   #CFGMSGIDS_CANSCHED_FREEFILTER_REQUEST_NONSRS_MSGID | for requests from proxy
//!   #CFGMSGIDS_CANSCHED_FREEFILTER_REPLY_MSGID          | for replies
//!
// =============================================================================
struct CanSchedPrivateMsgs_ScMsgFreeFilter
{
  CanSchedPrivateMsgs_ScMsgBase_S base;        //!< message base
  CanSchedTypes_CanChannel_T      channel;     //!< CAN channel index
  CanSchedTypes_CanFilterIndex_T  filterIndex; //!< to be freed filter
};
typedef struct CanSchedPrivateMsgs_ScMsgFreeFilter CanSchedPrivateMsgs_ScMsgFreeFilter_S;


// =============================================================================
//! @brief  allocate a sciopta message
//!
//! @param [in] pool   Sciopta message pool
//! @param [in] tmo    maximal timeout
//! @param [in] isSrs  use safety message ID
//!
//!
//! @details
//!
//!   The function allocates a Sciopta message from the message pool @p pool of
//!   type #CanSchedPrivateMsgs_ScMsgFreeFilter_S.  @p tmo defines the timeout
//!   for the sc_msgAlloc() function.  @p isSrs defines the message ID of the
//!   request.
//!
//!
//! @retval NULL    no message allocated
//! @retval <else>  allocated message
//!
// =============================================================================
extern sc_msg_t CanSchedPrivateMsgs_AllocCanFreeFilter(sc_poolid_t pool, sc_ticks_t tmo, bool isSrs);


// =============================================================================
//! @brief  represents a can message sending request and reply
//!
//! @details
//!
//!   #CanSchedPrivateMsgs_ScMsgSend_S is used as a request to send a CAN
//!   message and as a reply to the request.
//!
//!
//! @par MEMBERS
//!
//!   `base.scMsgId` holds the sciopta message ID.
//!
//!   `base.return` is only used, when the message is used as a reply.  It holds
//!   the result of the send operation.  #CanSchedTypes_ERROR_SUCCESS means
//!   success, all other values mean some kind of failure:
//!
//!    Error Code                            |  Description
//!   -------------------------------------- | ----------------------------
//!    #CanSchedTypes_ERROR_CHANNEL_INDEX    | #channel is invalid
//!    #CanSchedTypes_ERROR_CAN_ID           | `canMsg.canId` is invalid
//!    #CanSchedTypes_ERROR_CAN_DATA_LENGTH  | `canMsg.dataLen` is invalid
//!    #CanSchedTypes_ERROR_QUEUE_FULL       | transmit queue is full
//!    #CanSchedTypes_ERROR_CAN_BUS_OFF      | CAN error: "bus off"
//!    #CanSchedTypes_ERROR_CAN_ERROR_ACTIVE | CAN error: "error active"
//!    #CanSchedTypes_ERROR_CAN_UNDEFINED    | undefined CAN error
//!
//!   #channel holds the channel (not unit).
//!
//!   #isBlockingCall defines when the reply shall be sent.  If @c true the reply
//!   is sent when the message is successfully placed on the bus or an error
//!   occured.  If @c false the reply is sent as soon as the request is stored
//!   internally -- so the sending is asynchronous to the message exchange.
//!
//!   #canMsg holds the CAN message that shall be sent on channel #channel.
//!
//!
//! @par MESSAGE IDS
//!
//!   #CFGMSGIDS_CANSCHED_SEND_REQUEST_SRS_MSGID      | for requests from safety processes.
//!   #CFGMSGIDS_CANSCHED_SEND_FIRE_REQUEST_SRS_MSGID | for requests from safety processes, that do not expect any replies.
//!   #CFGMSGIDS_CANSCHED_SEND_REQUEST_NONSRS_MSGID   | for requests from CAN proxy process.
//!   #CFGMSGIDS_CANSCHED_SEND_REPLY_MSGID            | for replies after sending requests.
//!
// =============================================================================
struct CanSchedPrivateMsgs_ScMsgSend
{
  CanSchedPrivateMsgs_ScMsgBase_S base;           //!< message base
  CanSchedTypes_CanChannel_T      channel;        //!< CAN channel index
  bool                            isBlockingCall; //!< defines when reply is sent
  CanSchedTypes_CanMsg_S          canMsg;         //!< CAN message
};
typedef struct CanSchedPrivateMsgs_ScMsgSend CanSchedPrivateMsgs_ScMsgSend_S;


// =============================================================================
//! @brief  allocate a sciopta message
//!
//! @param [in] pool   Sciopta message pool
//! @param [in] tmo    maximal timeout
//! @param [in] isSrs  use safety message ID
//! @param [in] isFire use message ID without reply
//!
//!
//! @details
//!
//!   The function allocates a Sciopta message from the message pool @p pool of
//!   type 'CanSchedPrivateMsgs_ScMsgSend_S'.  @p tmo defines the timeout for the
//!   sc_msgAlloc() function.  @p isSrs and @p isFire define the message ID of the
//!   request.
//!
//!
//! @retval NULL    no message allocated
//! @retval <else>  allocated message
//!
//! @reviewNice
//!  * 2019-06-11 - HeLLo, GB, MHn
//!    * @p isFire is only evaluated, if @p isSrs is @c true.  Add this to the
//!      documentation.
// =============================================================================
extern sc_msg_t CanSchedPrivateMsgs_AllocCanSend     (sc_poolid_t pool, sc_ticks_t tmo, bool isSrs, bool isFire);  // polyspace MISRA-C3:5.1 [To fix:Medium] "CECBSAFETY-3049"  // polyspace ISO-17961:funcdecl [To investigate:Medium] "CECBSAFETY-3100"


// =============================================================================
//! @brief  allocate a sciopta message
//!
//! @param [in] pool   Sciopta message pool
//! @param [in] tmo    maximal timeout
//!
//!
//! @details
//!
//!   The function allocates a Sciopta message from the message pool @p pool of
//!   type #CanSchedPrivateMsgs_ScMsgSend_S.  @p tmo defines the timeout for the
//!   sc_msgAlloc() function.  The message ID indicates a reply.
//!
//!
//! @retval NULL    no message allocated
//! @retval <else>  allocated message
//!
// =============================================================================
extern sc_msg_t CanSchedPrivateMsgs_AllocCanSendReply(sc_poolid_t pool, sc_ticks_t tmo);


// =============================================================================
//! @brief  allocate a receive notifiy message
//!
//! @param [in] pool        Sciopta message pool
//! @param [in] tmo         maximal timeout
//! @param [in] channelIdx  channel index of reception
//!
//!
//! @details
//!
//!   The function allocates a Sciopta message from the message pool @p pool of
//!   type #CanSchedPrivateMsgs_ScMsgSend_S.  @p tmo defines the timeout for the
//!   sc_msgAlloc() function.  @p channelIdx defines the Sciopta message ID that
//!   indicates the receiving channel.
//!
//!
//! @retval NULL    no message allocated
//! @retval <else>  allocated message
//!
//! @reviewMinor
//!  * 2019-05-28 - HeLLo, GB, MHn
//!    * message type is #CanSchedMsgs_ScMsgRcvNotify_S
// =============================================================================
extern sc_msg_t CanSchedPrivateMsgs_AllocCanReceive(sc_poolid_t pool, sc_ticks_t tmo, CanSchedTypes_CanChannel_T channelIdx);


// =============================================================================
//! @brief  union with all internal and external Sciopta messages
// =============================================================================
union CanSchedPrivateMsgs_PrivateMsgs
{
  CanSchedPrivateMsgs_ScMsgSetFilterRequest_S setFilterRequest;  //!< request setting a filter
  CanSchedPrivateMsgs_ScMsgSetFilterReply_S   setFilterReply;    //!< reply   setting a filter
  CanSchedPrivateMsgs_ScMsgAllocateFilter_S   allocateFilter;    //!< request/reply allocating a filter
  CanSchedPrivateMsgs_ScMsgFreeFilter_S       freeFilter;        //!< request/reply freeing a filter
  CanSchedPrivateMsgs_ScMsgSend_S             send;              //!< request/reply sending a CAN message
  CanSchedPrivateMsgs_ScMsgLongFilter_S       longFilter;        //!< stored filter
  CanSchedMsgs_Msgs_U                         publicInterface;   //!< public messages of CAN scheduler
};
typedef union CanSchedPrivateMsgs_PrivateMsgs CanSchedPrivateMsgs_PrivateMsgs_U;



#endif // CANSCHEDPRIVATEMSGS_H

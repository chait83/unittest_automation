// *****************************************************************************
// **                _______   _________  _________   _______                 **
// **               (  ___  )  \__   __/  \__   __/  (  ____ \                **
// **               | (   ) |     ) (        ) (     | (    \/                **
// **               | |   | |     | |        | |     | (_____                 **
// **               | |   | |     | |        | |     (_____  )                **
// **               | |   | |     | |        | |           ) |                **
// **               | (___) |     | |     ___) (___  /\____) |                **
// **               (_______)     )_(     \_______/  \_______)                **
// **                                                                         **
// **                   Component Engineering Center Berlin                   **
// **                                                                         **
// **   Copyright 2017 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **
// **                                                                         **
// *****************************************************************************
//!
//! @file CanSched/Private/SendQueue.c
//!
//! @ingroup grp_CanSchedPrivate
//!
//! @brief  CAN scheduler send queue implementation
//!
//!
//! @todo TODO more efficient handling/searching of unused members
//!      Implementation hint:
//!         * add queue->member `pFirstEmpty`
//!         * `pFirstEmpty->pNext` points to the next unused member
//!         * `pFirstEmpty->pNext` is @c NULL, if it is the last unused member
//!         * `pFirstEmpty` is @c NULL, if there is no unused member
//!         * result is that no loop is necessary to find an unused member
// *****************************************************************************

#include "CanSched/Private/SendQueue.h"
#include "CanSched/Private/Msgs.h"
#include "Hlp/Failure.h"





// #############################################################################
// ## LOCAL TYPES ##############################################################
// #############################################################################

//! @brief  union sc_msg CanSched/Private/Channel.c
union sc_msg  // polyspace MISRA-C3:5.7 [To investigate:Medium] "CECBSAFETY-3050"
{
  sc_msgid_t                        scMsgId;   //!< Sciopta message ID
  CanSchedPrivateMsgs_PrivateMsgs_U canSched;  //!< CAN scheduler private messages
};





// #############################################################################
// ## LOCAL FUNCTIONS ##########################################################
// #############################################################################

static size_t getQueueLength(CanSchedPrivateTypes_SendQueue_S * pQueue);
static CanSchedPrivateTypes_SendQueueElement_S * findEmptyElement(CanSchedPrivateTypes_SendQueue_S * pQueue);






// #############################################################################
// ## EXTERN FUNCTIONS #########################################################
// #############################################################################

// =============================================================================
extern void CanSchedPrivateSendQueue_Init(CanSchedPrivateTypes_SendQueue_S * pQueue)
{
  size_t length = getQueueLength(pQueue);
  size_t idx;

  if ( NULL == pQueue )
  {
    HlpFailure_EndlessLoop();
#ifdef __clang_analyzer__
    __builtin_unreachable();
#endif
  }

  pQueue->pFirst = NULL;

  for (idx = 0; idx < length; ++idx)
  {
    pQueue->queue[idx].pNext   = NULL;
    pQueue->queue[idx].request = NULL;
  }
}


// =============================================================================
extern CanSchedTypes_Error_E CanSchedPrivateSendQueue_Insert(CanSchedPrivateTypes_SendQueue_S * pQueue, sc_msg_t * pRequest)
{
  CanSchedTypes_Error_E result;
  CanSchedPrivateTypes_SendQueueElement_S * pNew;
  CanSchedPrivateTypes_SendQueueElement_S ** ppPrev;
  CanSchedTypes_CanId_T canId;
  bool searching;

  pNew = findEmptyElement(pQueue);

  if (pNew == NULL)
  {
    result = CanSchedTypes_ERROR_QUEUE_FULL;
  }
  else
  {
    pNew->request = (*pRequest);
    *pRequest = NULL;

    canId = pNew->request->canSched.send.canMsg.canId;

    ppPrev = &(pQueue->pFirst);
    searching = true;

    // somewhere in the list
    while (searching)
    {
      if (*ppPrev == NULL)
      {
        // insert before
        searching = false;
      }
      else if ((*ppPrev)->request->canSched.send.canMsg.canId > canId)
      {
        // new first item
        searching = false;
      }
      else
      {
        ppPrev = &((*ppPrev)->pNext);
      }
    }

    pNew->pNext = (*ppPrev);
    (*ppPrev) = pNew;

    result = CanSchedTypes_ERROR_SUCCESS;
  }

  return result;
}


// =============================================================================
extern sc_msg_t CanSchedPrivateSendQueue_Pop(CanSchedPrivateTypes_SendQueue_S * pQueue)
{
  sc_msg_t                                  result;
  CanSchedPrivateTypes_SendQueueElement_S * pOldFirst;

  pOldFirst = pQueue->pFirst;

  if (pOldFirst == NULL)
  {
    result = NULL;
  }
  else
  {
    result             = pOldFirst->request;
    pOldFirst->request = NULL;
    pQueue->pFirst     = pOldFirst->pNext;
    pOldFirst->pNext   = NULL;
  }

  return result;
}


// =============================================================================
extern const sc_msg_t * CanSchedPrivateSendQueue_Peek(CanSchedPrivateTypes_SendQueue_S * pQueue)
{
  sc_msg_t * result;

  if (pQueue->pFirst == NULL)
  {
    result = NULL;
  }
  else
  {
    result = &(pQueue->pFirst->request);
  }

  return result;
}





// #############################################################################
// ## IMPLEMENTATION LOCAL FUNCTIONS ###########################################
// #############################################################################

// =============================================================================
//! @brief  count the number of members in the queue (used and free)
//!
//! @param [in] pQueue  queue object
//!
//!
//! @return
//!
//!   Total number of queue members, used + free ones.
//!
//! @reviewMinor
//!  * 2019-06-11 - HeLLo, GB, MHn
//!    * Remove the `void` cast of @p pQueue, because the parameter _is_ _used_.
// =============================================================================
static size_t getQueueLength(CanSchedPrivateTypes_SendQueue_S * pQueue)
{
  (void) pQueue; // parameter not used
  return sizeof(pQueue->queue) / sizeof(pQueue->queue[0]);
}


// =============================================================================
//! @brief  find a not used element
//!
//! @param [in] pQueue  queue object
//!
//!
//! @details
//!
//!   The function searches for the first not used member in the list and returns
//!   it.
//!
//!
//! @retval NULL   all elements are already used
//! @retval <else> pointer to an empty member of the queue is returned
//!
// =============================================================================
static CanSchedPrivateTypes_SendQueueElement_S * findEmptyElement(CanSchedPrivateTypes_SendQueue_S * pQueue)
{
  size_t length = getQueueLength(pQueue);
  size_t idx;
  CanSchedPrivateTypes_SendQueueElement_S * pNew = NULL;

  for (idx = 0; (idx < length) && (pNew == NULL); ++idx)
  {
    if (pQueue->queue[idx].request == NULL)
    {
      pNew = &(pQueue->queue[idx]);
    }
  }

  return pNew;
}

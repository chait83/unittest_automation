// *****************************************************************************
// **                _______   _________  _________   _______                 **
// **               (  ___  )  \__   __/  \__   __/  (  ____ \                **
// **               | (   ) |     ) (        ) (     | (    \/                **
// **               | |   | |     | |        | |     | (_____                 **
// **               | |   | |     | |        | |     (_____  )                **
// **               | |   | |     | |        | |           ) |                **
// **               | (___) |     | |     ___) (___  /\____) |                **
// **               (_______)     )_(     \_______/  \_______)                **
// **                                                                         **
// **                   Component Engineering Center Berlin                   **
// **                                                                         **
// **   Copyright 2017 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **
// **                                                                         **
// *****************************************************************************
//!
//! @file
//!
//! @ingroup grp_CanSchedInterface
//!
//! @brief  Provides the Sciopta CAN Driver to multiple subscribers.
//!
//! @details
//!
//! @par FUNCTIONALITY
//!
//!   The CAN scheduler provides the possibility for multiple processes to
//!   use the same CAN driver at the same time.  All processes can send and
//!   receive CAN messages.
//!
//!   The interface distinguishes between safety and non-safety
//!   communication.  The safety communication may be used by the safety
//!   processes directly.  The non-safety communication must not be used
//!   directly by the non-safety processes.  Instead a proxy process shall
//!   control the communication between the CAN scheduler and the
//!   non-safety processes.
//!
//!   The proxy itself shall provide an interface for non-safety processes
//!   and ensure that not more than one request of all non-safety processes
//!   is forwarded to the CAN scheduler at a time.
//!
//!   Requests of the safety processes are served first.
//!
//!   The CAN scheduler can handle more than one bus at a time.  Therefore
//!   channels are introduced that can be assigned to units by configuring
//!   the file CanSched/Cfg.h .
//!
//!
//! @par FILTERS
//!
//!   CAN messages can be sent and filters can be set to register for
//!   incoming CAN messages.  There are
//!   `CANSCHEDCFG_CHANNEL_?_USED_MAILBOXES (16)` slots available.  Slots `(0)`
//!   to `(CANSCHEDCFG_CHANNEL_?_SRS_FILTERS - 1)` are reserved to SRS
//!   requests.
//!
//!   Slots `(CANSCHEDCFG_CHANNEL_?_SRS_FILTERS)` to
//!   `(CANSCHEDCFG_CHANNEL_?_USED_MAILBOXES - 1)` are reserved to filters of
//!   the nonSRS proxy.
//!
//!
//!   @sa CanSched/CanSched.h  -- to be used by safety processes and the proxy
//!   @sa CanSched/Srs.h       -- to be used only by safety processes
//!   @sa CanSched/NonSrs.h    -- to be used only by the proxy
//!   @sa CanSched/Cfg.h       -- configuration of the CAN scheduler
//!   @sa CanSched/Types.h     -- types introduced by the CAN scheduler
//!   @sa CanSched/Msgs.h      -- sciopta messages
//!   @sa CanSched/Private/xxx.h -- header files providing internal functions
//!
//! @reviewNoAction
//!  * 2019-05-28 - HeLLo, GB, MHn
//!    * No findings.
// *****************************************************************************

#ifndef CANSCHEDCANSCHED_H
#define CANSCHEDCANSCHED_H

#include <sciopta_sc.h>


// #############################################################################
// ## FUNCTIONS ################################################################
// #############################################################################

// =============================================================================
//! @brief  get the process ID of the CAN scheduler
//!
//!
//! @details
//!
//!   This function is necessary to prepare interaction with the CAN scheduler.
//!   It might be called both from safety software and from the CAN proxy.
//!
//!
//! @return
//!
//!   In case of an error `SC_ILLEGAL_PID` is returned.  In all other cases the
//!   function returns the process ID of the CAN scheduler.  The result has to be
//!   passed as the first parameter to all other function calls to interact with
//!   the CAN scheduler.
//!
//!
// =============================================================================
extern sc_pid_t CanSchedCanSched_GetPid(void);


#endif // CANSCHEDCANSCHED_H

// *****************************************************************************
// **                _______   _________  _________   _______                 **
// **               (  ___  )  \__   __/  \__   __/  (  ____ \                **
// **               | (   ) |     ) (        ) (     | (    \/                **
// **               | |   | |     | |        | |     | (_____                 **
// **               | |   | |     | |        | |     (_____  )                **
// **               | |   | |     | |        | |           ) |                **
// **               | (___) |     | |     ___) (___  /\____) |                **
// **               (_______)     )_(     \_______/  \_______)                **
// **                                                                         **
// **                   Component Engineering Center Berlin                   **
// **                                                                         **
// **   Copyright 2019 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **
// **                                                                         **
// *****************************************************************************
//!
//! @file
//!
//! @ingroup grp_CanSchedConfiguration
//!
//! @brief  Driver specific Configuration of the CAN scheduler
//!
//! @details
//!
//!   Change defines in this file only if the flexcan.c file makes this
//!   necessary.
//!
//! @sa CanSched/Cfg.h
//!
//! @reviewNoAction
//!  * 2019-06-11 - HeLLo, GB, MHn
//!    * No findings.
// *****************************************************************************

#ifndef CANSCHEDCFGDRIVER_H
#define CANSCHEDCFGDRIVER_H


//! @name interface names for each physical unit
//! @{

//! @brief  sdd name for unit 0
#define CANSCHEDCFGDRIVER_UNIT_0_INTERFACE "can0"

//! @brief  sdd name for unit 1
#define CANSCHEDCFGDRIVER_UNIT_1_INTERFACE "can1"

//! @brief  sdd name for unit 2
#define CANSCHEDCFGDRIVER_UNIT_2_INTERFACE "can2"

//! @}


//! @name mailbox sizes for each physical unit
//! @{

//  There are 64 mailboxes, but Sciopta flexcan driver uses
//    * 8 for tx and
//    * 8 for response messages
//  therefore only 48 mailboxes are left.
//  @sa #CAN_RX_FIFO_SIZE in flexcan.c.
//
//! @brief  maximum available filters for unit 0
#define CANSCHEDCFGDRIVER_UNIT_0_MAX_FILTERS (48)

//! @brief  maximum available filters for unit 1
#define CANSCHEDCFGDRIVER_UNIT_1_MAX_FILTERS (48)

//! @brief  maximum available filters for unit 2
#define CANSCHEDCFGDRIVER_UNIT_2_MAX_FILTERS (48)

//! @}

#endif  // CANSCHEDCFGDRIVER_H


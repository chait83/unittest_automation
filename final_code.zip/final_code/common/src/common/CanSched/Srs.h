// *****************************************************************************
// **                _______   _________  _________   _______                 **
// **               (  ___  )  \__   __/  \__   __/  (  ____ \                **
// **               | (   ) |     ) (        ) (     | (    \/                **
// **               | |   | |     | |        | |     | (_____                 **
// **               | |   | |     | |        | |     (_____  )                **
// **               | |   | |     | |        | |           ) |                **
// **               | (___) |     | |     ___) (___  /\____) |                **
// **               (_______)     )_(     \_______/  \_______)                **
// **                                                                         **
// **                   Component Engineering Center Berlin                   **
// **                                                                         **
// **   Copyright 2017 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **
// **                                                                         **
// *****************************************************************************
//!
//! @file
//!
//! @ingroup grp_CanSchedInterface
//!
//! @brief  interface for safety processes to the CAN scheduler
//!
//!
//! @details
//!
//!   These functions provide the interface that is exclusive to safety
//!   processes.
//!
//!   All functions have as their first parameters `canSchedPid` and `channel`,
//!   where `canSchedPid` is the process ID of the CAN scheduler, which can be
//!   found by calling CanSchedCanSched_GetPid() .  `channel` is the channel
//!   number.  The channel numbering begins with `0` and ends at
//!   `#CFGCANSCHED_CHANNELS - 1`, defined in Cfg/CanSched.h  Remark, that the
//!   channel index is not necessarily the unit number.
//!
// *****************************************************************************

#ifndef CANSCHEDSRS_H
#define CANSCHEDSRS_H

#include <sciopta_sc.h>
#include "CanSched/Types.h"

// #############################################################################
// ## FUNCTIONS ################################################################
// #############################################################################


//! @name  CAN filter
//! @{

// =============================================================================
//! @brief  allocate a filter
//!
//! @param [in]  canSchedPid   process ID of the CAN scheduler
//! @param [in]  channel       CAN channel ID
//! @param [out] pFilterIndex  place where successful allocated filter ID is
//!                            stored
//!
//!
//! @details
//!
//!   This function allocates a filter ID exclusively for the caller process.
//!   It is only associated with the passed @p channel.
//!
//!   The returned @p pFilterIndex can be used to set the filter.  When not
//!   used, it shall be freed via CanSchedSrs_FreeFilter().
//!
//!   If the function returns with an error, @p pFilterIndex is not modified.
//!
//!
//! @retval #CanSchedTypes_ERROR_SUCCESS  the allocated filter ID is stored in
//!                                       @p pFilterIndex
//! @retval <else>                        error description
//!
//!
//! @sa CanSchedSrs_FreeFilter()
//! @sa CanSchedSrs_SetFilterBlocking()
//! @sa CanSchedSrs_SetFilterNonBlocking()
//!
//! @note It is the callers responsibility, that @p canSchedPid is a valid
//!       Sciopta process ID.
//! @note It is the callers responsibility, that @p pFilterIndex points to a
//!       memory area, that is large enough to store a datum of
//!       CanSchedTypes_CanFilterIndex_T.
// =============================================================================
extern CanSchedTypes_Error_E CanSchedSrs_AllocFilter(sc_pid_t                         canSchedPid,
                                                     CanSchedTypes_CanChannel_T       channel,
                                                     CanSchedTypes_CanFilterIndex_T * pFilterIndex);

// =============================================================================
//! @brief  program a filter and return when programmed
//!
//! @param [in]  canSchedPid       process ID of the CAN scheduler
//! @param [in]  channel           CAN channel ID
//! @param [in]  filterIndex       already allocated filter ID
//! @param [in]  filterListLength  number of elements in @p pFilterList
//! @param [in]  pFilterList       list of CAN filters
//!
//!
//! @details
//!
//!   This function replaces a filter.  The CAN scheduler will then forward any
//!   message, that matches at least one of the @p filterListLength filters in
//!   @p pFilterList, that can be received on channel @p channel.
//!
//!   The function returns, when the filter is activated in hardware.
//!
//!   When the CAN scheduler receives a CAN message that matches at least one of
//!   the filters, a Sciopta message with the CAN ID
//!   `CFGMSGIDS_CANSCHED_RCVNOTIFY_MSGID(channel)` is sent to the caller.  The
//!   message is of type CanSchedMsgs_ScMsgRcvNotify_S.
//!
//!   All filters in the list have to be either of extended or of non-extended
//!   CAN IDs.  It is not possible to mix them in one mailbox.
//!
//!
//! @retval #CanSchedTypes_ERROR_SUCCESS  the filters are active
//! @retval <else>                        error description
//!
//!
//! @sa CanSchedSrs_AllocFilter()
//! @sa CanSchedSrs_FreeFilter()
//! @sa CanSchedSrs_SetFilterNonBlocking()
//! @sa struct CanSchedTypes_CanFilter for examples
//!
//! @note It is the callers responsibility, that @p canSchedPid is a valid
//!       Sciopta process ID.
//!
//! @reviewNice
//!  * 2019-05-28 - HeLLo, GB, MHn
//!    * reword "This function replaces a filter."
// =============================================================================
extern CanSchedTypes_Error_E CanSchedSrs_SetFilterBlocking(sc_pid_t                          canSchedPid,
                                                           CanSchedTypes_CanChannel_T        channel,
                                                           CanSchedTypes_CanFilterIndex_T    filterIndex,
                                                           size_t                            filterListLength,
                                                           const CanSchedTypes_CanFilter_S * pFilterList);

// =============================================================================
//! @brief  program a filter and return immediately
//!
//! @param [in]  canSchedPid       process ID of the CAN scheduler
//! @param [in]  channel           CAN channel ID
//! @param [in]  filterIndex       already allocated filter ID
//! @param [in]  filterListLength  number of elements in @p pFilterList
//! @param [in]  pFilterList       list of CAN filters
//!
//!
//! @details
//!
//!   This function works like CanSchedSrs_SetFilterBlocking(), except that the
//!   function does not wait for storage in the hardware filter.  It returns
//!   when the request was buffered in the CAN scheduler.
//!
//!
//! @sa CanSchedSrs_SetFilterNonBlocking()
// =============================================================================
extern CanSchedTypes_Error_E CanSchedSrs_SetFilterNonBlocking(sc_pid_t                          canSchedPid,
                                                              CanSchedTypes_CanChannel_T        channel,
                                                              CanSchedTypes_CanFilterIndex_T    filterIndex,
                                                              size_t                            filterListLength,
                                                              const CanSchedTypes_CanFilter_S * pFilterList);

// =============================================================================
//! @brief  free a filter
//!
//! @param [in]  canSchedPid  process ID of the CAN scheduler
//! @param [in]  channel      CAN channel ID
//! @param [in]  filterIndex  already allocated filter ID
//!
//!
//! @details
//!
//!   This function is used to tell the CAN scheduler, that the filter @p
//!   filterIndex on channel @p channel is not necessary anymore.  After this
//!   call, the filter index must not be used for further library calls.
//!
//!   No further CAN messages are forwarded from the CAN scheduler for this
//!   filter anymore.  If the caller has installed other filters that match the
//!   same IDs, the CAN messages for the other filter are still forwarded.
//!
//!
//! @retval #CanSchedTypes_ERROR_SUCCESS  the filter is freed
//! @retval <else>                        error description
// =============================================================================
extern CanSchedTypes_Error_E CanSchedSrs_FreeFilter(sc_pid_t                       canSchedPid,
                                                    CanSchedTypes_CanChannel_T     channel,
                                                    CanSchedTypes_CanFilterIndex_T filterIndex);

//! @}


//! @name sending CAN messages
//! @{

// =============================================================================
//! @brief  send a CAN message and return when on bus
//!
//! @param [in]  canSchedPid  process ID of the CAN scheduler
//! @param [in]  channel      CAN channel ID
//! @param [in]  pCanMsg      CAN message
//!
//!
//! @details
//!
//!   This function sends the message @p pCanMsg on the bus @p channel.  See the
//!   restrictions regarding protocol, CAN ID and message length in struct
//!   CanSchedTypes_CanMsg.
//!
//!   This functions returns when the message was sent on the bus or when an
//!   error occured.
//!
//!
//! @retval #CanSchedTypes_ERROR_SUCCESS  the message was sent on the bus
//! @retval <else>                        error description
//!
//!
//! @sa struct CanSchedTypes_CanMsg
// =============================================================================
extern CanSchedTypes_Error_E CanSchedSrs_SendBlocking(sc_pid_t                       canSchedPid,
                                                      CanSchedTypes_CanChannel_T     channel,
                                                      const CanSchedTypes_CanMsg_S * pCanMsg);

// =============================================================================
//! @brief  send a CAN message and return immediately
//!
//! @param [in]  canSchedPid  process ID of the CAN scheduler
//! @param [in]  channel      CAN channel ID
//! @param [in]  pCanMsg      CAN message
//!
//!
//! @details
//!
//!   This function works like CanSchedSrs_SendBlocking(), except that the
//!   function does not wait for the storage in the CAN scheduler's transmit
//!   queue.  It returns when the request was transmitted to the CAN scheduler.
//!
//!
//! @sa CanSchedSrs_SendBlocking()
// =============================================================================
extern CanSchedTypes_Error_E CanSchedSrs_SendFireAndForget(sc_pid_t                       canSchedPid,
                                                           CanSchedTypes_CanChannel_T     channel,
                                                           const CanSchedTypes_CanMsg_S * pCanMsg);

// =============================================================================
//! @brief  send a CAN message and return when in queue
//!
//! @param [in]  canSchedPid  process ID of the CAN scheduler
//! @param [in]  channel      CAN channel ID
//! @param [in]  pCanMsg      CAN message
//!
//!
//! @details
//!
//!   This function works like CanSchedSrs_SendBlocking(), except that the
//!   function does wait for transmission on the CAN bus.  It returns when the
//!   request was stored in the CAN scheduler's transmit queue.
//!
//!
//! @sa CanSchedSrs_SendBlocking()
// =============================================================================
extern CanSchedTypes_Error_E CanSchedSrs_SendNonBlocking(sc_pid_t                       canSchedPid,
                                                         CanSchedTypes_CanChannel_T     channel,
                                                         const CanSchedTypes_CanMsg_S * pCanMsg);

//! @}


#endif // CANSCHEDSRS_H

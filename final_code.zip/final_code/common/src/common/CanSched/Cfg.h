// *****************************************************************************
// **                _______   _________  _________   _______                 **
// **               (  ___  )  \__   __/  \__   __/  (  ____ \                **
// **               | (   ) |     ) (        ) (     | (    \/                **
// **               | |   | |     | |        | |     | (_____                 **
// **               | |   | |     | |        | |     (_____  )                **
// **               | |   | |     | |        | |           ) |                **
// **               | (___) |     | |     ___) (___  /\____) |                **
// **               (_______)     )_(     \_______/  \_______)                **
// **                                                                         **
// **                   Component Engineering Center Berlin                   **
// **                                                                         **
// **   Copyright 2019 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **
// **                                                                         **
// *****************************************************************************
//!
//! @file
//!
//! @ingroup grp_CanSchedConfiguration
//!
//! @brief  Configuration of the CAN Scheduler
//!
// *****************************************************************************

#ifndef CANSCHEDCFG_H
#define CANSCHEDCFG_H

#include "Cfg/CanSched.h"

// Note: CanSched/CfgDriver.h is included, although it is normally included in
//       Cfg/CanSched.h .  But since Cfg/CanSched.h is in the responsibility of
//       the user, it can't be relied on the include by the user.  It should
//       also not be included before Cfg/CanSched.h .  (This enforces the user
//       to correctly include its dependencies.)
#include "CanSched/CfgDriver.h"


// polyspace-begin MISRA-C3:20.9 [To investigate:Medium] "false positive, _MAX_FILTERS is not a define, however check if this heavy preprocessor-usage can be refactored: CECBSAFETY-3056"


// =============================================================================
// CHECK Cfg/CanSched.h
// =============================================================================
#ifndef CFGCANSCHED_CHANNELS
#  error  CFGCANSCHED_CHANNELS not defined in Cfg/CanSched.h
#endif

#ifndef CFGCANSCHED_SEND_QUEUE_LENGTH
#  error  CFGCANSCHED_SEND_QUEUE_LENGTH not defined in Cfg/CanSched.h
#endif


// -----------------------------------------------------------------------------
// Check Channel 0
// -----------------------------------------------------------------------------
#if CFGCANSCHED_CHANNELS >= 1
#  ifndef CFGCANSCHED_CHANNEL_0_UNIT
#    error  CFGCANSCHED_CHANNEL_0_UNIT not defined in Cfg/CanSched.h
#  endif

//! @reviewNice
//!  * 2019-06-11 - HeLLo, GB, MHn
//!    * This check is the same as above.
#  ifndef CFGCANSCHED_CHANNEL_0_UNIT
#    error  CFGCANSCHED_CHANNEL_0_UNIT not defined in Cfg/CanSched.h
#  endif

#  ifndef CFGCANSCHED_CHANNEL_0_BAUD
#    error  CFGCANSCHED_CHANNEL_0_BAUD not defined in Cfg/CanSched.h
#  endif

#  ifndef CFGCANSCHED_CHANNEL_0_SRS_FILTERS
#    error  CFGCANSCHED_CHANNEL_0_SRS_FILTERS not defined in Cfg/CanSched.h
#  endif

#  ifndef CFGCANSCHED_CHANNEL_0_USED_MAILBOXES
#    error  CFGCANSCHED_CHANNEL_0_USED_MAILBOXES not defined in Cfg/CanSched.h
#  endif
#endif


// -----------------------------------------------------------------------------
// Check Channel 1
// -----------------------------------------------------------------------------
#if CFGCANSCHED_CHANNELS >= 2
#  ifndef CFGCANSCHED_CHANNEL_1_UNIT
#    error  CFGCANSCHED_CHANNEL_1_UNIT not defined in Cfg/CanSched.h
#  endif

//! @reviewNice
//!  * 2019-06-11 - HeLLo, GB, MHn
//!    * This check is the same as above.
#  ifndef CFGCANSCHED_CHANNEL_1_UNIT
#    error  CFGCANSCHED_CHANNEL_1_UNIT not defined in Cfg/CanSched.h
#  endif

#  ifndef CFGCANSCHED_CHANNEL_1_BAUD
#    error  CFGCANSCHED_CHANNEL_1_BAUD not defined in Cfg/CanSched.h
#  endif

#  ifndef CFGCANSCHED_CHANNEL_1_SRS_FILTERS
#    error  CFGCANSCHED_CHANNEL_1_SRS_FILTERS not defined in Cfg/CanSched.h
#  endif

#  ifndef CFGCANSCHED_CHANNEL_1_USED_MAILBOXES
#    error  CFGCANSCHED_CHANNEL_1_USED_MAILBOXES not defined in Cfg/CanSched.h
#  endif
#endif

// -----------------------------------------------------------------------------
// Check Channel 2
// -----------------------------------------------------------------------------
#if CFGCANSCHED_CHANNELS >= 3
#  ifndef CFGCANSCHED_CHANNEL_2_UNIT
#    error  CFGCANSCHED_CHANNEL_2_UNIT not defined in Cfg/CanSched.h
#  endif

//! @reviewNice
//!  * 2019-06-11 - HeLLo, GB, MHn
//!    * This check is the same as above.
#  ifndef CFGCANSCHED_CHANNEL_2_UNIT
#    error  CFGCANSCHED_CHANNEL_2_UNIT not defined in Cfg/CanSched.h
#  endif

#  ifndef CFGCANSCHED_CHANNEL_2_BAUD
#    error  CFGCANSCHED_CHANNEL_2_BAUD not defined in Cfg/CanSched.h
#  endif

#  ifndef CFGCANSCHED_CHANNEL_2_SRS_FILTERS
#    error  CFGCANSCHED_CHANNEL_2_SRS_FILTERS not defined in Cfg/CanSched.h
#  endif

#  ifndef CFGCANSCHED_CHANNEL_2_USED_MAILBOXES
#    error  CFGCANSCHED_CHANNEL_2_USED_MAILBOXES not defined in Cfg/CanSched.h
#  endif
#endif





// =============================================================================
// RESULTING DATA
// =============================================================================
//
// This section calculates
//   * CANSCHEDCFG_CHANNEL_XXX_MAX_FILTERS and
//   * CANSCHEDCFG_CHANNEL_XXX_INTERFACE
// for each channel and
//   * CANSCHEDCFG_MAX_MAILBOX_SIZE
// as the maximum that the channels are using.
//
//! @def CANSCHEDCFG_MAX_MAILBOX_SIZE
//! @brief  maximum number of mailboxes of all used CAN units
// =============================================================================

// helping macros
//! @brief  concatenate 3 identifiers to one identifer
#define CONCAT3(A,B,C)        A ## B ## C
//! @brief  concatenate 3 expanded identifiers to one identifer
#define EXPAND_CONCAT3(A,B,C) CONCAT3(A,B,C)

// resulting data
#if CFGCANSCHED_CHANNELS >= 1
  //! @brief  maximum available filters for channel 0
  #define CANSCHEDCFG_CHANNEL_0_MAX_FILTERS  EXPAND_CONCAT3(CANSCHEDCFGDRIVER_UNIT_,CFGCANSCHED_CHANNEL_0_UNIT,_MAX_FILTERS)
  //! @brief  sdd name for channel 0
  #define CANSCHEDCFG_CHANNEL_0_INTERFACE    EXPAND_CONCAT3(CANSCHEDCFGDRIVER_UNIT_,CFGCANSCHED_CHANNEL_0_UNIT,_INTERFACE)

  // first MAX is channel 0
  // units
  #define CANSCHEDCFG_MAX_MAILBOX_SIZE       CFGCANSCHED_CHANNEL_0_USED_MAILBOXES
#endif

#if CFGCANSCHED_CHANNELS >= 2
  //! @brief  maximum available filters for channel 1
  #define CANSCHEDCFG_CHANNEL_1_MAX_FILTERS  EXPAND_CONCAT3(CANSCHEDCFGDRIVER_UNIT_,CFGCANSCHED_CHANNEL_1_UNIT,_MAX_FILTERS)
  //! @brief  sdd name for channel 1
  #define CANSCHEDCFG_CHANNEL_1_INTERFACE    EXPAND_CONCAT3(CANSCHEDCFGDRIVER_UNIT_,CFGCANSCHED_CHANNEL_1_UNIT,_INTERFACE)

 // if channel 1 has more mailboxes than channel 0, set it the maximum
  #if CANSCHEDCFG_MAX_MAILBOX_SIZE < CFGCANSCHED_CHANNEL_1_USED_MAILBOXES
    #undef  CANSCHEDCFG_MAX_MAILBOX_SIZE
    #define CANSCHEDCFG_MAX_MAILBOX_SIZE CFGCANSCHED_CHANNEL_1_USED_MAILBOXES
  #endif
#endif

#if CFGCANSCHED_CHANNELS >= 3
  //! @brief  maximum available filters for channel 2
  #define CANSCHEDCFG_CHANNEL_2_MAX_FILTERS  EXPAND_CONCAT3(CANSCHEDCFGDRIVER_UNIT_,CFGCANSCHED_CHANNEL_2_UNIT,_MAX_FILTERS)
  //! @brief  sdd name for channel 2
  #define CANSCHEDCFG_CHANNEL_2_INTERFACE    EXPAND_CONCAT3(CANSCHEDCFGDRIVER_UNIT_,CFGCANSCHED_CHANNEL_2_UNIT,_INTERFACE)

 // if channel 2 has more mailboxes than channel 0/1, set it the maximum
  #if CANSCHEDCFG_MAX_MAILBOX_SIZE < CFGCANSCHED_CHANNEL_2_USED_MAILBOXES
    #undef  CANSCHEDCFG_MAX_MAILBOX_SIZE
    #define CANSCHEDCFG_MAX_MAILBOX_SIZE CFGCANSCHED_CHANNEL_2_USED_MAILBOXES
  #endif
#endif





// =============================================================================
// COMPILE TIME CHECKS
// =============================================================================
//
// Don't modify this section.
//
// This section performs some compile time checks for validity.
//
// =============================================================================

// checks channel 0
#if CFGCANSCHED_CHANNELS >= 1
  #if CFGCANSCHED_CHANNEL_0_USED_MAILBOXES < 1
    #error channel 0: too less available filters
  #elif CFGCANSCHED_CHANNEL_0_USED_MAILBOXES > CANSCHEDCFG_CHANNEL_0_MAX_FILTERS
    #error channel 0: too many available filters
  #elif CFGCANSCHED_CHANNEL_0_SRS_FILTERS < 0
    #error channel 0: too less SRS filters
  #elif CFGCANSCHED_CHANNEL_0_SRS_FILTERS > CFGCANSCHED_CHANNEL_0_USED_MAILBOXES
    #error channel 0: too many SRS filters
  #endif
#endif

// checks channel 1
#if CFGCANSCHED_CHANNELS >= 2
  #if (CFGCANSCHED_CHANNEL_1_UNIT == CFGCANSCHED_CHANNEL_0_UNIT)
    #error CAN unit used multiple times
  #elif CFGCANSCHED_CHANNEL_1_USED_MAILBOXES < 1
    #error channel 1: too less available filters
  #elif CFGCANSCHED_CHANNEL_1_USED_MAILBOXES > CANSCHEDCFG_CHANNEL_1_MAX_FILTERS
    #error channel 1: too many available filters
  #elif CFGCANSCHED_CHANNEL_1_SRS_FILTERS < 0
    #error channel 1: too less SRS filters
  #elif CFGCANSCHED_CHANNEL_1_SRS_FILTERS > CFGCANSCHED_CHANNEL_1_USED_MAILBOXES
    #error channel 1: too many SRS filters
  #endif
#endif

// checks channel 3
#if CFGCANSCHED_CHANNELS >= 3
  #if (CFGCANSCHED_CHANNEL_2_UNIT == CFGCANSCHED_CHANNEL_0_UNIT)
    #error CAN unit used multiple times
  #elif (CFGCANSCHED_CHANNEL_2_UNIT == CFGCANSCHED_CHANNEL_1_UNIT)
    #error CAN unit used multiple times
  #elif CFGCANSCHED_CHANNEL_2_USED_MAILBOXES < 1
    #error channel 2: too less available filters
  #elif CFGCANSCHED_CHANNEL_2_USED_MAILBOXES > CANSCHEDCFG_CHANNEL_2_MAX_FILTERS
    #error channel 2: too many available filters
  #elif CFGCANSCHED_CHANNEL_2_SRS_FILTERS < 0
    #error channel 2: too less SRS filters
  #elif CFGCANSCHED_CHANNEL_2_SRS_FILTERS > CFGCANSCHED_CHANNEL_2_USED_MAILBOXES
    #error channel 2: too many SRS filters
  #endif
#endif

// polyspace-end MISRA-C3:20.9 [To investigate:Medium] "false positive, _MAX_FILTERS is not a define, however check if this heavy preprocessor-usage can be refactored: CECBSAFETY-3056"

#endif // CANSCHEDCFG_H

// =======================================================================================
// Copyright 2021 OTIS GmbH & Co. OHG - OTIS Lead Design Center Berlin
// =======================================================================================
//
//! @file
//!
//! @brief Measuring CAN latency
//!
//! @details
//!   CanLatency code is removed from production builds. In debug builds it can be included if CFGCANLATENCY_ENABLE is defined.
//!
//!   CanLatency measures the transmit latency between the model commands to send a CAN message and the CAN message is actually
//!   written to the transmit mailbox of the CAN controller for transmission.
//!
//!   The latencies are collected in a histogram of number of occurrences per latency in 100 us steps from 0 to
//!   ((@c CANLATENCY_TXLATENCYLIST_SIZE - 1) / 10) ms. The last latency also counts longer latencies. Latencies are
//!   distinguished depending on whether the latency ended during startup (<= @c startupDurationMs) or steady state
//!   (> @c startupDurationMs).
//!
//! @note
//!   The CAN Scheduler types CanSchedTypes_CanId_T and CanSchedTypes_CanChannel_T cannot be used in CanLatency because this
//!   would require including CanSched/Srs.h which includes sciopta_sc.h. Since CanLatency.h is included in Model/Support
//!   (includes sciopta_sc.h) and in flexcan.c (includes sciopta.h), this would lead to the error "Include only sciopta.h or
//!   sciopta_sc.h".
//
// =======================================================================================


#ifndef CANLATENCY_H
#define CANLATENCY_H


#include <stdbool.h>
#include "logd/logd.h"
#include "config.h"
#include "Cfg/CanLatency.h"


// =======================================================================================
// Defines
// =======================================================================================


// =============================================================================
//! @brief CanLatency code is removed from production builds. In debug builds it can be included if CFGCANLATENCY_ENABLE is defined.
//!
//! @note
//!   - @c CFGCANLATENCY_ENABLE can only be defined if CNF_NEAR_PRODUCTION_CODE = 0.
//!   - A general consistency check of @c CNF_NEAR_PRODUCTION_CODE is done in pcb/Cfg/Config.h.
// =============================================================================


#if (defined CFGCANLATENCY_ENABLE) && (CNF_NEAR_PRODUCTION_CODE != 0)
  #error "#define CFGCANLATENCY_ENABLE" is only allowed if CNF_NEAR_PRODUCTION_CODE = 0
#endif


// =====================================================================================
//! @brief Init CAN latency measurement
// =====================================================================================
extern void CanLatency_Init(void);


// =====================================================================================
//! @brief Start latency measurement for a CAN message to be sent
//!
//! @param[in]  logd                     Log Daemon for debug output
//! @param[in]  canIdentifier            CAN identifier of the message to be sent
//! @param[in]  isExtendedCanIdentifier  CAN identifier has 29 bits rather than 11 bits
//! @param[in]  canChannel               CAN channel the message is supposed to be sent on
//!
//! @note
//!   This function should be called in the function that sends CAN messages of the model of the SafetyProcess
//!   (@c ModelSupport_WriteCan).
// =====================================================================================
extern void CanLatency_StartTxLatency(logd_t* const logd, const uint32_t canIdentifier, const bool isExtendedCanIdentifier, const uint8_t canChannel);


// =====================================================================================
//! @brief Stop latency measurement for a CAN message to be sent
//!
//! @param[in]  canIdentifier            CAN identifier of the message to be sent
//! @param[in]  isExtendedCanIdentifier  CAN identifier has 29 bits rather than 11 bits
//! @param[in]  canChannel               CAN channel the message is supposed to be sent on
//!
//! @note
//!   This function should be called in the function that puts CAN messages into the transmit mailbox of the CAN controller
// =====================================================================================
extern void CanLatency_StopTxLatency(const uint32_t canIdentifier, const bool isExtendedCanIdentifier, const uint8_t canChannel);


// =====================================================================================
//! @brief Print histogram of CAN transmit latencies
//!
//! @param[in]  logd  Log daemon for debug output
//!
//! @note
//!   This function should be called in the RequestHandler
// =====================================================================================
extern void CanLatency_Print(logd_t* const logd);


// Macros are used to wrap the public functions to ensure the functions calls are removed when CFGCANLATENCY_ENABLE is not defined
#ifdef CFGCANLATENCY_ENABLE

  #define CANLATENCY_INIT()                                                                     CanLatency_Init()
  #define CANLATENCY_START_TX_LATENCY(logd, canIdentifier, isExtendedCanIdentifier, canChannel) CanLatency_StartTxLatency(logd, canIdentifier, isExtendedCanIdentifier, canChannel)
  #define CANLATENCY_STOP_TX_LATENCY(canIdentifier, isExtendedCanIdentifier, canChannel)        CanLatency_StopTxLatency(canIdentifier, isExtendedCanIdentifier, canChannel)

#else // #ifdef CFGCANLATENCY_ENABLE

  #define CANLATENCY_INIT()
  #define CANLATENCY_START_TX_LATENCY(logd, canIdentifier, isExtendedCanIdentifier, canChannel)
  #define CANLATENCY_STOP_TX_LATENCY(canIdentifier, isExtendedCanIdentifier,  canChannel)

#endif // #ifdef CFGCANLATENCY_ENABLE


#endif // #ifndef CANLATENCY_H

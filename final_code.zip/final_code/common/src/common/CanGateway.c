// *****************************************************************************
// **                _______   _________  _________   _______                 **
// **               (  ___  )  \__   __/  \__   __/  (  ____ \                **
// **               | (   ) |     ) (        ) (     | (    \/                **
// **               | |   | |     | |        | |     | (_____                 **
// **               | |   | |     | |        | |     (_____  )                **
// **               | |   | |     | |        | |           ) |                **
// **               | (___) |     | |     ___) (___  /\____) |                **
// **               (_______)     )_(     \_______/  \_______)                **
// **                                                                         **
// **                   Component Engineering Center Berlin                   **
// **                                                                         **
// **   Copyright 2017 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **
// **                                                                         **
// *****************************************************************************
//!
//! @file
//!
//! @ingroup grp_CanGateway
//!
//! @brief  Module for Forwarding CAN messages between CAN channels
//!
//! @reviewNoaction
//! * MW, KNU - 2019-04-25
//!   * No action required.
//!
// *****************************************************************************

#include <inttypes.h>
#include "CanGateway.h"
#include "Cfg/MsgIds.h"
#include "CanSched/Msgs.h"
#include "CanSched/Srs.h"
#include "Hlp/Failure.h"

// -----------------------------------------------------------------------------
//! @brief  union sc_msg CanSched/CanSched.c
// -----------------------------------------------------------------------------
union sc_msg  // polyspace MISRA-C3:5.7 [To investigate:Medium] "CECBSAFETY-3050"
{
  sc_msgid_t              scMsgId;   //!< Sciopta message ID
  union CanSchedMsgs_Msgs canSched;  //!< CAN Scheduler message interface
};



extern void CanGateway_Init(struct CanGateway_Gateway *       pGw,
                            CanSchedTypes_CanChannel_T        from,
                            CanSchedTypes_CanChannel_T        to,
                            size_t                            filterListLength,
                            const CanSchedTypes_CanFilter_S * pFilterList)
{
  if ( NULL == pGw  ||  NULL == pFilterList )
  {
    HlpFailure_EndlessLoopBusy();
#ifdef __clang_analyzer__
    __builtin_unreachable();
#endif
  }

  // polyspace +7 ISO-17961:taintformatio [Not a defect:Low] "pointer is checked for NULL"
  // polyspace +6 ISO-17961:nullref [Not a defect:Low] "pointer is checked for NULL"
  // polyspace +5 MISRA-C3:D4.14 [Not a defect:Low] "pointer is checked for NULL"
  pGw->from             = from;
  pGw->to               = to;
  pGw->filterIdx        = 0;
  pGw->filterListLength = filterListLength;
  pGw->pFilterList      = pFilterList;
}


extern void CanGateway_Start(logd_t * logd, sc_pid_t canSched, struct CanGateway_Gateway * pGw)
{
  if ( NULL == logd  ||  NULL == pGw )
  {
    HlpFailure_EndlessLoopBusy();
#ifdef __clang_analyzer__
    __builtin_unreachable();
#endif
  }

  // polyspace +5 ISO-17961:taintformatio [Not a defect:Low] "pointer is checked for NULL"
  // polyspace +4 ISO-17961:nullref [Not a defect:Low] "pointer is checked for NULL"
  // polyspace +3 MISRA-C3:D4.14 [Not a defect:Low] "pointer is checked for NULL"
  if (CanSchedSrs_AllocFilter(canSched,
                              pGw->from,
                              &(pGw->filterIdx))
      != CanSchedTypes_ERROR_SUCCESS)
  {
    HlpFailure_EndlessLoopSleepingMsg(sc_tickMs2Tick(1000),
                                      logd,
                                      "Error: could not allocate CAN filter\n");
  }

  // polyspace +5 MISRA-C3:D4.14 [Not a defect:Low] "pointer is checked for NULL"
  if (CanSchedSrs_SetFilterBlocking(canSched,
                                    pGw->from,
                                    pGw->filterIdx,
                                    pGw->filterListLength,
                                    pGw->pFilterList)
      != CanSchedTypes_ERROR_SUCCESS)
  {
    HlpFailure_EndlessLoopSleepingMsg(sc_tickMs2Tick(1000),
                                      logd,
                                      "Error: could not set CAN filter\n");
  }
}

extern void CanGateway_HandleRcv(logd_t * logd, sc_pid_t canSched, const struct CanGateway_Gateway * pGw, sc_msg_t * pScMsg)
{
  if ( NULL == logd  ||  NULL == pGw  ||  NULL == pScMsg  ||  NULL == *pScMsg )  // polyspace MISRA-C3:D4.14 [Not a defect:Low] "C99 section 6.5.14:4 If the first operand compares unequal to 0, the second operand is not evaluated."  // polyspace ISO-17961:nullref [Not a defect:Low] "C99 section 6.5.14:4 If the first operand compares unequal to 0, the second operand is not evaluated."  // polyspace ISO-17961:taintformatio [Not a defect:Low] "C99 section 6.5.14:4 If the first operand compares unequal to 0, the second operand is not evaluated."
  {
    HlpFailure_EndlessLoopBusy();
#ifdef __clang_analyzer__
    __builtin_unreachable();
#endif
  }

  if ((*pScMsg)->scMsgId == CFGMSGIDS_CANSCHED_RCVNOTIFY_MSGID(pGw->from))  // polyspace MISRA-C3:D4.14 [Not a defect:Low] "pointers are checked for NULL"  // polyspace ISO-17961:nullref [Not a defect:Low] "pointer is checked for NULL"  // polyspace ISO-17961:taintformatio [Not a defect:Low] "pointer is checked for NULL"
  {
    if (CanSchedSrs_SendNonBlocking(canSched,
                                    pGw->to,
                                    &((*pScMsg)->canSched.rcvNotify.canMsg))
        != CanSchedTypes_ERROR_SUCCESS)
    {
      logd_printf(logd, 0, "could not forward from %d to %d: 0x%08" PRIx32 "\n",
                  pGw->from,
                  pGw->to,
                  (*pScMsg)->canSched.rcvNotify.canMsg.canId);
    }
    sc_msgFree(pScMsg);
  }
}


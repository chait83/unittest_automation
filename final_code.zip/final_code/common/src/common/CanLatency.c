// =======================================================================================
// Copyright 2021 OTIS GmbH & Co. OHG - OTIS Lead Design Center Berlin
// =======================================================================================
//
//! @file
//!
//! @brief Measuring CAN latency
//!
//! @details
//!   CanLatency code is removed from production builds. In debug builds it can be included if CFGCANLATENCY_ENABLE is defined.
//!
//!   CanLatency measures the transmit latency between the model commands to send a CAN message and the CAN message is actually
//!   written to the transmit mailbox of the CAN controller for transmission.
//!
//!   The latencies are collected in a histogram of number of occurrences per latency in 100 us steps from 0 to
//!   ((@c CFGCANLATENCY_TXLATENCYLIST_SIZE - 1) / 10) ms. The last latency also counts longer latencies. Latencies are
//!   distinguished depending on whether the latency ended during startup (<= @c _startupDurationMs) or steady state
//!   (> @c _startupDurationMs).
//!
//! @note
//!   The CAN Scheduler types CanSchedTypes_CanId_T and CanSchedTypes_CanChannel_T cannot be used in CanLatency because this
//!   would require including CanSched/Srs.h which includes sciopta_sc.h. Since CanLatency.h is included in Model/Support
//!   (includes sciopta_sc.h) and in flexcan.c (includes sciopta.h), this would lead to the error "Include only sciopta.h or
//!   sciopta_sc.h".
//
// =======================================================================================


#include <sciopta_sc.h> // CanLatency.h cannot include sciopta_sc.h because this causes a conflict when including CanLatency.h
                        // in flexcan.c because flexcan.c includes sciopta.h
#include "CanLatency.h"
#include "LifetimeCounter.h"
#include "Hlp/DbgPrint.h"

#ifdef CFGCANLATENCY_ENABLE


// =======================================================================================
// Types
// =======================================================================================


// =======================================================================================
//! @brief Identification of CAN message to be sent and the LifetimeCounter time when the model initiates sending the message
//!
//! @details
//!   The CAN Scheduler reorders CAN messages to be sent based on their CAN identifier. CAN messages with the same CAN
//!   identifier are kept in the sequence of their send requests -> CAN data in addition to the CAN identifier is not needed
//!   for identifying the message to be sent.
// =======================================================================================
typedef struct
{
  uint32_t canIdentifier;           //!< CAN identifier
  bool     isExtendedCanIdentifier; //!< CAN identifier has 29 bits rather than 11 bits
  uint8_t  canChannel;              //!< CAN port the message is supposed to sent
  uint64_t timeOfSendRequest;       //!< LifetimeCounter when the model commands to send a CAN message
} CanLatency_S;


// =======================================================================================
//! @brief Number of occurrences of a latency, distinguishing startup and steady state
// =======================================================================================
typedef struct
{
  uint32_t startup;     //!< Number of occurrences in the first @c _startupDurationMs after power up
  uint32_t steadyState; //!< Number of occurrences after the first @c _startupDurationMs after power up
} CanLatency_Occurrences_S;


// =======================================================================================
//! @brief txList
// =======================================================================================
typedef struct
{
  CanLatency_S list[CFGCANLATENCY_TXLIST_SIZE]; //!< List of CAN messages to be sent
  uint8_t      length;                          //!< Current used length
  uint32_t     overflowCount;                   //!< Number of occurrences of "Latency of CAN message could not be measured
                                                //!< because CFGCANLATENCY_TXLIST_SIZE was too small"
} CanLatency_TxList_S;


// =======================================================================================
// Local constants and variables
// =======================================================================================


static const uint32_t      _startupDurationMs = 1000; //!< 1 s

static uint64_t            _startupDurationLifetimeCounter;
static CanLatency_TxList_S _txList;


// =======================================================================================
//! @brief Transmit latency histogram
// =======================================================================================
//!
//! @details
//!   The index of _txLatencyList is in units of 100 us.
//!
//!     index                                | Latency
//!     -------------------------------------|------------------------------------------------
//!     0                                    | 0.0 ms
//!     1                                    | 0.1 ms
//!     2                                    | 0.2 ms
//!     ...                                  |
//!     CFGCANLATENCY_TXLATENCYLIST_SIZE - 1 | (CFGCANLATENCY_TXLATENCYLIST_SIZE - 1) * 0.1 ms
//!
//!   _txLatencyList[0].startup     Number of occurrences of latency 0.0 ms in    the first _startupDurationMs after power up
//!   _txLatencyList[0].steadyState Number of occurrences of latency 0.0 ms after the first _startupDurationMs after power up
//!   _txLatencyList[1].startup     Number of occurrences of latency 0.1 ms in    the first _startupDurationMs after power up
//!   _txLatencyList[1].steadyState Number of occurrences of latency 0.1 ms after the first _startupDurationMs after power up
//!   ...
static CanLatency_Occurrences_S _txLatencyList[CFGCANLATENCY_TXLATENCYLIST_SIZE];


// =======================================================================================
// Private Functions
// =======================================================================================


// =====================================================================================
//! @brief Add CAN message to the list of CAN messages to be sent
//!
//! @param[in]      logd                     Log Daemon for debug output
//! @param[in,out]  pTxList                  Storage location of _txList
//! @param[in]      canIdentifier            CAN identifier of the message to be sent
//! @param[in]      isExtendedCanIdentifier  CAN identifier has 29 bits rather than 11 bits
//! @param[in]      canChannel               CAN channel the message is supposed to be sent on
// =====================================================================================
static void addCanMsg(logd_t* const logd, CanLatency_TxList_S* const pTxList, const uint32_t canIdentifier, const bool isExtendedCanIdentifier, const uint8_t canChannel)
{
  if (pTxList->length < CFGCANLATENCY_TXLIST_SIZE)
  {
    pTxList->list[pTxList->length].canIdentifier           = canIdentifier;
    pTxList->list[pTxList->length].isExtendedCanIdentifier = isExtendedCanIdentifier;
    pTxList->list[pTxList->length].canChannel              = canChannel;
    pTxList->list[pTxList->length].timeOfSendRequest       = LifetimeCounter_Get();
    pTxList->length++;
  }
  else
  {
    logd_printf(logd, LOGD_SEVERE, RED "*** ERROR - _txList too small to add CAN identifier 0x%08X" NORMAL "\n", canIdentifier);

    // Increment pTxList->overflowCount but prevent wrapping around
    if (pTxList->overflowCount < UINT32_MAX)
    {
      pTxList->overflowCount++;
    }
  }
}


// =====================================================================================
//! @brief Find CAN message in the list of CAN messages to be sent
//!
//! @param[in,out]  pTxList                  Storage location of _txList
//! @param[in]      canIdentifier            CAN identifier of the message to be sent
//! @param[in]      isExtendedCanIdentifier  CAN identifier has 29 bits rather than 11 bits
//! @param[in]      canChannel               CAN channel the message is supposed to be sent on
//! @param[out]     pIndex                   Storage location for the the CAN message was found in the list
//!
//! @retval  #true   CAN message found in the list and the index is written to the storage location @p pIndex
//! @retval  #false  CAN message not found in the list, the index at the storage location @p pIndex remains unchanged
// =====================================================================================
static bool findCanMsg(const CanLatency_TxList_S* const pTxList, const uint32_t canIdentifier, const bool isExtendedCanIdentifier, const uint8_t canChannel, uint8_t* const pIndex)
{
  uint8_t index = 0;
  bool    found;

  while (   (index < pTxList->length)
         && (   (pTxList->list[index].canIdentifier           != canIdentifier)
             || (pTxList->list[index].isExtendedCanIdentifier != isExtendedCanIdentifier)
             || (pTxList->list[index].canChannel              != canChannel)))
  {
    index++;
  }

  if (index < pTxList->length)
  {
    found = true;
    // kprintf(0, "Found canIdentifier = 0x%08X (%s) on canChannel = %u at index = %u\n", canIdentifier,
    //                                                                                    isExtendedCanIdentifier ? "extended" : "standard",
    //                                                                                    canChannel,
    //                                                                                    index);
    if (pIndex != NULL)
    {
      *pIndex = index;
    }
  }
  else
  {
    found = false;
    // kprintf(0, "*** ERROR - Could not find canIdentifier = 0x%08X (%s) on canChannel = %u\n", canIdentifier,
    //                                                                                           isExtendedCanIdentifier ? "extended" : "standard",
    //                                                                                           canChannel,
    //                                                                                           index);
  }

  return found;
}


// =====================================================================================
//! @brief Delete CAN message in the list of CAN messages to be sent
//!
//! @param[in,out]  pTxList  Storage location of _txList
//! @param[in]      index    Index of the message to be deleted
// =====================================================================================
static void deleteCanMsg(CanLatency_TxList_S* const pTxList, const uint8_t index)
{
  uint8_t i;

  if (pTxList->length > 0)
  {
    for (i = index; i < pTxList->length - 1; i++)
    {
      pTxList->list[i] = pTxList->list[i + 1];
    }
    pTxList->length--;
  }
}


// =====================================================================================
//! @brief Add latency to the list of latencies
//!
//! @param[in,out]   txLatencyList            List of transmit latencies
//! @param[in]       latency100us             Latency in 100 us to be added
//! @param[in]       stopTimeLifetimeCounter  LifetimeCounter time when this particular latency ended
//!
//! @details
//!   The number of occurrences of the @p latency100us is incremented depending on whether the latency ended during startup or
//!   steady state. The number of occurrences saturates at @c UINT32_MAX to prevent wrapping around.
// =====================================================================================
static void addLatency(CanLatency_Occurrences_S* const txLatencyList, const uint32_t latency100us, const uint64_t stopTimeLifetimeCounter)
{
  uint32_t index;

  if (latency100us < CFGCANLATENCY_TXLATENCYLIST_SIZE - 1)
  {
    index = latency100us;
  }
  else
  {
    index = CFGCANLATENCY_TXLATENCYLIST_SIZE - 1;
  }

  // Increment and prevent wrapping around
  if (stopTimeLifetimeCounter <= _startupDurationLifetimeCounter)
  {
    if (txLatencyList[index].startup < UINT32_MAX)
    {
      txLatencyList[index].startup++;
    }
  }
  else
  {
    if (txLatencyList[index].steadyState < UINT32_MAX)
    {
      txLatencyList[index].steadyState++;
    }
  }
}


// static void printTxList(const CanLatency_TxList_S* const pTxList)
// {
//   uint8_t index;
//
//   for (index = 0; index < pTxList->length; index++)
//   {
//     kprintf(0, "0x%08X (%s) %u\n", pTxList->list[index].canIdentifier,
//                                    pTxList->list[index].isExtendedCanIdentifier ? "extended" : "standard",
//                                    pTxList->list[index].canChannel);
//   }
//   kprintf(0, "\n");
// }


// =======================================================================================
// Public Functions
// =======================================================================================


extern void CanLatency_Init(void)
{
  uint8_t i;

  _startupDurationLifetimeCounter = LifetimeCounter_MsToLifetimeCounter(_startupDurationMs);

  for (i = 0; i < CFGCANLATENCY_TXLATENCYLIST_SIZE; i++)
  {
    _txLatencyList[i].startup     = 0;
    _txLatencyList[i].steadyState = 0;
  }
}


extern void CanLatency_StartTxLatency(logd_t* const logd, const uint32_t canIdentifier, const bool isExtendedCanIdentifier, const uint8_t canChannel)
{
  // kprintf(0, "%08X\n", canIdentifier);
  addCanMsg(logd, &_txList, canIdentifier, isExtendedCanIdentifier, canChannel);
  // printTxList();
  // kprintf(0, "\n");
}


extern void CanLatency_StopTxLatency(const uint32_t canIdentifier, const bool isExtendedCanIdentifier, const uint8_t canChannel)
{
  uint8_t  index = 0;
  uint32_t latency100Us;            // Latency in 100 us
  uint64_t stopTimeLifetimeCounter;

  if (findCanMsg(&_txList, canIdentifier, isExtendedCanIdentifier, canChannel, &index))
  {
    stopTimeLifetimeCounter = LifetimeCounter_Get();

    // Calculate latency
    latency100Us = LifetimeCounter_ToUsLimited(stopTimeLifetimeCounter - _txList.list[index].timeOfSendRequest) / 100;

    addLatency(_txLatencyList, latency100Us, stopTimeLifetimeCounter);

    // Delete canMsg in txList
    deleteCanMsg(&_txList, index);
  }
}


extern void CanLatency_Print(logd_t* const logd)
{
  uint8_t i;
  char    latencyAndMoreIndicator; // The last latency also counts longer latencies

  logd_printf(logd, LOGD_INFO, "\n");
  logd_printf(logd, LOGD_INFO, "CAN transmit latency\n");
  logd_printf(logd, LOGD_INFO, "Startup duration = %lu ms\n", _startupDurationMs);

  // Print histogram
  for (i = 0; i < CFGCANLATENCY_TXLATENCYLIST_SIZE; i++)
  {
    if (i < CFGCANLATENCY_TXLATENCYLIST_SIZE - 1)
    {
      latencyAndMoreIndicator = ' ';
    }
    else
    {
      latencyAndMoreIndicator = '+';
    }

    logd_printf(logd, LOGD_INFO, "%2u.%u%c %8lu %8lu\n", i / 10, // Integer of the latency
                                                         i % 10, // Fraction of the latency
                                                         latencyAndMoreIndicator,
                                                         _txLatencyList[i].startup,
                                                         _txLatencyList[i].steadyState);
  }

  // Indicate if latency of CAN message could not be measured
  if (_txList.overflowCount > 0)
  {
    logd_printf(logd, LOGD_INFO, RED "Latency of CAN message could not be measured because CFGCANLATENCY_TXLIST_SIZE was too small %lu times" NORMAL "\n", _txList.overflowCount);
  }

  logd_printf(logd, LOGD_INFO, "\n");
}


#endif // #ifdef CFGCANLATENCY_ENABLE

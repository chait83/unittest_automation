#ifndef CONFIG_PAD_H
#define CONFIG_PAD_H


// This file is empty.
//
// Sciopta's GPIO driver io_mpc5744p.h includes this file, despite it doesn't
// rely on any information provided from this file.



#endif // CONFIG_PAD_H

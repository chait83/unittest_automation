% M. Wilke @ CECB March 2017
% Model Advisor: Checks all models in the hierarchy starting at the root model with the chosen set of rules.
% When finished an HTML report of the analysis is shown.
% Inputs:
%          rootModel  = Highest model to be analyzed in the model hierarchy (e.g. 'Behavior'), w/o SLX extension.
%          setOfRules = Model Advisor set of rules to be loaded (e.g. 'ModelAdvisorConfigFirstChecks.mat'), with extension MAT.
function SLMA_CheckAll(rootModel ,setOfRules)
  tic;  % start stop watch
  % some parameter checks
  assert(nargin == 2, 'The number of parameters must be 2, not %d.',nargin);
  assert(isa(rootModel,'char'),'Parameter <rootModel> is from type %s, not char!', class(rootModel));
  assert(isa(setOfRules,'char'),'Parameter <setOfRules> is from type %s, not char!', class(setOfRules));
  
  % open the root model
  open_system(rootModel);
  
  % create Model Advisor application
  RootModel=rootModel;
  app = Advisor.Manager.createApplication();
  
  % set Root analysis
  setAnalysisRoot(app, 'Root', RootModel);
  
  % clear all check instances from Model Advisor analysis
  deselectCheckInstances(app);
  
  % load set of rules
  loadConfiguration(app, setOfRules);
  
  % run Model Advisor analysis
  run(app);
  
  % get analysis results
  getResults(app);
  
  % generate and view the Model Advisor report
  folder = strcat(rootModel, '_ModelAdvisorResults');
  mkdir(folder);
  report = generateReport(app, 'Location', folder, 'Name', rootModel);
  web(report)
  
  % close root model
  close_system(rootModel);
  
  toc;  % terminate stop watch
end

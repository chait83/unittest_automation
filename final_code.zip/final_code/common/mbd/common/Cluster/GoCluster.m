% M. Wilke @ CECB February 2017
% Spawns a job described in a MATLAB script file to the cluster.
% Inputs:
%         job       = MATLAB function script
%         numThread = # of worker tasks on cluster
%         model     = model to be analyzed (model or test harness)
%         p1        = parameter 1 for MATLAB function script
%         p2        = parameter 2 for MATLAB function script
function GoCluster(job ,numThreads, model, p1, p2)
  % some paramete checks
  assert(nargin == 5, 'The number of parameters must be 5, not %d.',nargin);
  assert(isa(job,'char'),'Parameter <job> is from type %s, not char!',class(job));
  assert(isnumeric(numThreads),'Parameter <numThreads> is from type %s, not numeric!',class(numThreads));
  assert(isa(model,'char'),'Parameter <model> is from type %s, not char!',class(model));
  assert(isa(p1,'char'),'Parameter <p1> is from type %s, not char!',class(p1));
  assert(isa(p2,'char'),'Parameter <p2> is from type %s, not char!',class(p2));
  
  j = batch(job,1,{model,p1,p2},'Pool',numThreads,'CaptureDiary',true);  % create batch on cluster
  wait(j);                 % wait until cluster jobs are finished
  diary(j);                % display jobs diary (console output)
  fetchOutputs(j);         % load job workspace into client workspace
end

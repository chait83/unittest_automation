% M. Wilke @ CECB February 2017
% Start the Simulink Design Verifier (SLDV) in a MATLAB function script.
% Inputs:
%         model = model to be analyzed (model or test harness)
%         p1    = parameter 1 (Mode) for SLDV ('PropertyProving', 'TestGeneration', 'DesignErrorDetection')
%         p2    = parameter 2 (Coverage) for SLDV ('None', 'Decision', 'ConditionDecision', 'MCDC')
% Outputs:
%         status = -1: exceeded max. processing time, 0: error, 1: normal completion
function status = SpawnSLDV(model, p1, p2)
  % some paramete checks
  assert(nargin == 3, 'The number of parameters must be 3, not %d.',nargin);
  assert(isa(model,'char'),'Parameter <model> is from type %s, not char!',class(model));
  assert(isa(p1,'char'),'Parameter <p1> is from type %s, not char!',class(p1));
  assert(isa(p2,'char'),'Parameter <p2> is from type %s, not char!',class(p2));
  
  open(model);                             % open the model to be analysed
  opts = sldvoptions(bdroot);              % get its SLDV options
  opts.Mode = p1;                          % set SLDV analysis mode
  opts.ModelCoverageObjectives = p2;       % set SLDV coverage obecjtive
  [status, ~] = sldvrun(model,opts);       % start SLDV
end

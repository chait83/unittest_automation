function rule = sys_BlkRepl_UpdateLastActiveBufferElement
rule = Sldv.xform.BlkRepRule; 
rule.FileName = mfilename;
rule.BlockType = 'SubSystem';
rule.ReplacementPath = sprintf('sys_BlkRepl_lib/UpdateLastActiveBufferElement');
rule.ReplacementMode = 'Normal';
rule.IsReplaceableCallBack = @replacementHandleUpdateLastActiveBufferElement;
end

%% Replace HandleResetReasons/StoreIntendedReset/UpdateLastActiveBufferElement
function out = replacementHandleUpdateLastActiveBufferElement(blockH)
    out =  strcmp(get_param(blockH, 'name'), 'UpdateLastActiveBufferElement') && ~contains(get_param(blockH, 'Parent'), 'HandleResetReasonsAtStartup');
end
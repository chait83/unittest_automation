function rule = sys_BlkRepl_SabScheduler
rule = Sldv.xform.BlkRepRule; 
rule.FileName = mfilename;
rule.BlockType = 'SubSystem';
rule.ReplacementPath = sprintf('sys_BlkRepl_lib/SabScheduler');
rule.ReplacementMode = 'Normal';
rule.IsReplaceableCallBack = @replacementTestSabScheduler;
end

%%
function out = replacementTestSabScheduler(blockH)
    out =  contains(get_param(blockH, 'Name'), 'SabScheduler');
end
function rule = sys_BlkRepl_CalculateCrc32
    rule =  SldvBlockReplacement.blockreprule;
    rule.FileName = mfilename;
    rule.BlockType = 'SubSystem';
    rule.ReplacementPath = sprintf('sys_BlkRepl_lib/CalculateCrc32');
    rule.ReplacementMode = 'Normal';
    rule.IsReplaceableCallBack = @replacementHandleCalculateCrc32;
end

function out = replacementHandleCalculateCrc32(blockH)
    out =  strcmp(get_param(blockH, 'Name'), 'CalculateCrc32');
end
function rule = sys_BlkRepl_PitScheduler
rule = Sldv.xform.BlkRepRule; 
rule.FileName = mfilename;
rule.BlockType = 'SubSystem';
rule.ReplacementPath = sprintf('sys_BlkRepl_lib/PitScheduler');
rule.ReplacementMode = 'Normal';
rule.IsReplaceableCallBack = @replacementTestPitScheduler;
end

%%
function out = replacementTestPitScheduler(blockH)
    out =  contains(get_param(blockH, 'Name'), 'PitScheduler');
end
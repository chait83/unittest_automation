function rule = sys_BlkRepl_HandleReceivedUpdateEventMessage
rule = Sldv.xform.BlkRepRule; 
rule.FileName = mfilename;
rule.BlockType = 'SubSystem';
rule.ReplacementPath = sprintf('sys_BlkRepl_lib/HandleReceivedUpdateEventMessage');
rule.ReplacementMode = 'Normal';
rule.IsReplaceableCallBack = @replacementHandleReceivedUpdateEventMessage;
end

%%
function out = replacementHandleReceivedUpdateEventMessage(blockH)
    out =  contains(get_param(blockH, 'Name'), 'HandleReceivedUpdateEventMessage');
end
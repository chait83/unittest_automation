function runDVPropertyProving(model)
% In order to analyze this model with Design Verifier
% you must first add the following folder to the Simulink Project path: 
% mbd/common/DVAnalasysSupport/functions_repl 
% This script updates the matlab path to contain this folder prior to 
% executing design verifier
% The folder contains replacement functions for those which make calls to 
% external c-functions which are not supported by Design Verifier. 
if(nargin < 1)
    model  = gcs;
end

%% Modify the path for DV Analysis
savedpath = path;
newpath = fullfile(fileparts(mfilename('fullpath')), 'functions_repl');
path(newpath, path)

%% Configure the analysis
opts = sldvoptions(model);
opts.Mode = 'DesignErrorDetection';
opts.ReportFileName = '$ModelName$_report_designerrors';
opts.OutputDir = 'sldv_output/$ModelName$/designerrors';
opts.BlockReplacement = 'off';
opts.BlockReplacementRulesList = 'sys_BlkRepl_DoubleSignalCollectionWindow,sys_BlkRepl_DoubleSignalCollectionWindowNoTrigger,sys_BlkRepl_CtrlScheduler,sys_BlkRepl_CarScheduler,sys_BlkRepl_PitScheduler';
opts.BlockReplacementModelFileName = '$ModelName$_pp_replace';
opts.DetectDivisionByZero = 'on';
opts.DetectIntegerOverflow = 'on';
opts.DetectOutOfBounds = 'on';
opts.DesignMinMaxCheck = 'on';
% opts.ReportPDFFormat = 'on';
opts.SaveReport = 'on';

%% Run the analysis
[status, filenames] = sldvrun(model, opts, true);

%% Restore the original path
path(savedpath);

%% Restore the data dictionary (discard tunable parameter changes)
%  only if the analysis was able to be started - otherwise we may
%  discard important changes to the DD
if (status ~= 0)
	DD = Simulink.data.dictionary.open('PessralFunctionalModelDataDictionary.sldd');
	discardChanges(DD);
end
end
function rule = sys_BlkRepl_MATLAB_FunctionCrc16
rule = Sldv.xform.BlkRepRule; 
rule.FileName = mfilename;
rule.BlockType = 'SubSystem';
rule.ReplacementPath = sprintf('sys_BlkRepl_lib/MATLAB_FunctionCrc16');
rule.ReplacementMode = 'Normal';
rule.IsReplaceableCallBack = @replacementHandleMATLAB_FunctionCrc16;
end

%replace req_analysis_SCON_flat/CtrlSafetyFunction/EvaluationRef/Model6/BuildNonSafetyCanMessages/Model5/BuildPesFeatureStatus/SendContractCertificate/CreatePesFeatureStatus
function out = replacementHandleMATLAB_FunctionCrc16(blockH)
    outputs = get_param(blockH, 'OutputSignalNames');
    out =  strcmp(get_param(blockH, 'Name'), 'MATLAB Function') && size(outputs, 2)==1 && strcmp(outputs{1,1}, 'CRC16');
end
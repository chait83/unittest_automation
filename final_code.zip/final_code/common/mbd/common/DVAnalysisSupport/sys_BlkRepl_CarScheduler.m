function rule = sys_BlkRepl_CarScheduler
rule = Sldv.xform.BlkRepRule; 
rule.FileName = mfilename;
rule.BlockType = 'SubSystem';
rule.ReplacementPath = sprintf('sys_BlkRepl_lib/CarScheduler');
rule.ReplacementMode = 'Normal';
rule.IsReplaceableCallBack = @replacementTestCarScheduler;
end

%%
function out = replacementTestCarScheduler(blockH)
    out =  contains(get_param(blockH, 'Name'), 'CarScheduler');
end
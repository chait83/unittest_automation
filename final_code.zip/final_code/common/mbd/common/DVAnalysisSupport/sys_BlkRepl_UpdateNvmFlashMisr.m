function rule = sys_BlkRepl_UpdateNvmFlashMisr
rule = Sldv.xform.BlkRepRule; 
rule.FileName = mfilename;
rule.BlockType = 'SubSystem';
rule.ReplacementPath = sprintf('sys_BlkRepl_lib/UpdateNvmFlashMisr');
rule.ReplacementMode = 'Normal';
rule.IsReplaceableCallBack = @replacementHandleUpdateNvmFlashMisr;
end

%% Replace OecbLib/PESSRAL/FlashIntegrityCheckSignature/CheckFlashIntegrityCheckSignature/UpdateNvmFlashMisr
function out = replacementHandleUpdateNvmFlashMisr(blockH)
    out =  strcmp(get_param(blockH, 'Name'), 'UpdateNvmFlashMisr');
end
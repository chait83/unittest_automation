function rule = sys_BlkRepl_TEMPORARY_Buzzer_Calls
rule = Sldv.xform.BlkRepRule; 
rule.FileName = mfilename;
rule.BlockType = 'SubSystem';
rule.ReplacementPath = sprintf('sys_BlkRepl_lib/TEMPORARY_Buzzer_Calls');
rule.ReplacementMode = 'Normal';
rule.IsReplaceableCallBack = @replacementHandleTEMPORARY_Buzzer_Calls;
end

%% Replace PitEvaluation/PitHandler/TEMPORARY_Buzzer_Calls
function out = replacementHandleTEMPORARY_Buzzer_Calls(blockH)
    out =  strcmp(get_param(blockH, 'Name'), 'TEMPORARY_Buzzer_Calls');
end
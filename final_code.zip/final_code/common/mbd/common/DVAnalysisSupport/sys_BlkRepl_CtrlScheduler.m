function rule = sys_BlkRepl_CtrlScheduler
rule = Sldv.xform.BlkRepRule; 
rule.FileName = mfilename;
rule.BlockType = 'SubSystem';
rule.ReplacementPath = sprintf('sys_BlkRepl_lib/CtrlScheduler');
rule.ReplacementMode = 'Normal';
rule.IsReplaceableCallBack = @replacementTestCtrlScheduler;
end

%%
function out = replacementTestCtrlScheduler(blockH)
    out =  contains(get_param(blockH, 'Name'), 'CtrlScheduler');
end
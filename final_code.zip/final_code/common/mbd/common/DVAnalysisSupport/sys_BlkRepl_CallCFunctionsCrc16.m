function rule = sys_BlkRepl_CallCFunctionsCrc16
rule = Sldv.xform.BlkRepRule; 
rule.FileName = mfilename;
rule.BlockType = 'SubSystem';
rule.ReplacementPath = sprintf('sys_BlkRepl_lib/CallCFunctionsCrc16');
rule.ReplacementMode = 'Normal';
rule.IsReplaceableCallBack = @replacementHandleCallCFunctionsCrc16;
end

%% Replace OecbLib/PESSRAL/HandleResetReasons/HandleResetReasonsAtStartup/ReadAndStoreLastResetReason/ReadAndUpdateLastResetReason/UpdatedResetBufferElement
function out = replacementHandleCallCFunctionsCrc16(blockH)
    out =  strcmp(get_param(blockH, 'Name'), 'CallCFunctions') && size(get_param(blockH, 'InputSignalNames'), 2)==7;
end
function rule = sys_BlkRepl_GetLastActiveBufferElement
rule = Sldv.xform.BlkRepRule; 
rule.FileName = mfilename;
rule.BlockType = 'SubSystem';
rule.ReplacementPath = sprintf('sys_BlkRepl_lib/GetLastActiveBufferElement');
rule.ReplacementMode = 'Normal';
rule.IsReplaceableCallBack = @replacementHandleGetLastActiveBufferElement;
end

%% Replace OecbLib/PESSRAL/FlashIntegrityCheckSignature/CheckFlashIntegrityCheckSignature/UpdateNvmFlashMisr
function out = replacementHandleGetLastActiveBufferElement(blockH)
    out =  strcmp(get_param(blockH, 'Name'), 'GetLastActiveBufferElement') && ~contains(get_param(blockH, 'Parent'), 'HandleResetReasonsAtStartup'); 
end
function rule = sys_BlkRepl_MATLAB_FunctionCrc32
rule = Sldv.xform.BlkRepRule; 
rule.FileName = mfilename;
rule.BlockType = 'SubSystem';
rule.ReplacementPath = sprintf('sys_BlkRepl_lib/MATLAB_FunctionCrc32');
rule.ReplacementMode = 'Normal';
rule.IsReplaceableCallBack = @replacementHandleMATLAB_FunctionCrc32;
end

%replace req_analysis_SCON_flat/CtrlSafetyFunction/EvaluationRef/Model5/DetermineSyncState/BuildCrc32FactoryConfiguration
function out = replacementHandleMATLAB_FunctionCrc32(blockH)
    outputs = get_param(blockH, 'OutputSignalNames');
    out =  strcmp(get_param(blockH, 'Name'), 'MATLAB Function') && size(outputs, 2)==1 && strcmp(outputs{1,1}, 'Crc32');
end
function runDVPropertyProving(maxViolationSteps, model)

if (nargin < 1)
    maxViolationSteps = 20;
    model  = gcs;
elseif(nargin == 1)
    model  = gcs;
end

%% use scripts written for BAMBOO
[status, text] = SL_DV_ExecutePropertyProving(model, 'PropertyProving', 'ProveWithViolationDetection', maxViolationSteps, 1, '', '', '_report_propertyproving');

end

function rule = sys_BlkRepl_CallCFunctionsCrc32
rule = Sldv.xform.BlkRepRule; 
rule.FileName = mfilename;
rule.BlockType = 'SubSystem';
rule.ReplacementPath = sprintf('sys_BlkRepl_lib/CallCFunctionsCrc32');
rule.ReplacementMode = 'Normal';
rule.IsReplaceableCallBack = @replacementHandleCallCFunctionsCrc32;
end

%% Replace OecbLib/PESSRAL/HandleResetReasons/HandleResetReasonsAtStartup/ReadAndStoreLastResetReason/ReadAndUpdateLastResetReason/UpdatedResetBufferElement
function out = replacementHandleCallCFunctionsCrc32(blockH)
    out =  strcmp(get_param(blockH, 'Name'), 'CallCFunctions') && size(get_param(blockH, 'InputSignalNames'), 2)==2;
end
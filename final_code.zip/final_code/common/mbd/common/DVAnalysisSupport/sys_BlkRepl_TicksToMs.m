function rule = sys_BlkRepl_TicksToMs
rule = Sldv.xform.BlkRepRule; 
rule.FileName = mfilename;
rule.BlockType = 'SubSystem';
rule.ReplacementPath = sprintf('sys_BlkRepl_lib/TicksToMs');
rule.ReplacementMode = 'Normal';
rule.IsReplaceableCallBack = @replacementHandleTicksToMs;
end

%% Replace OecbLib/PESSRAL/Time/TicksToMs/TicksToMs
function out = replacementHandleTicksToMs(blockH)
    out =  contains(get_param(blockH, 'Name'), 'TicksToMs');
end
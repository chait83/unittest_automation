function runDVPropertyProving(model)

if (nargin < 1)
    model  = gcs;
end

%% use scripts written for BAMBOO
[status, text] = SL_DV_ExecutePropertyProving(model, 'PropertyProving', 'Prove', 0, 1, '', '', '_report_propertyproving');

end

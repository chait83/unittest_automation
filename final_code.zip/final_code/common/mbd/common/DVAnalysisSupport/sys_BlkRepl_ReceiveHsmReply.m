function rule = sys_BlkRepl_ReceiveHsmReply
rule = Sldv.xform.BlkRepRule; 
rule.FileName = mfilename;
rule.BlockType = 'SubSystem';
rule.ReplacementPath = sprintf('sys_BlkRepl_lib/ReceiveHsmReply');
rule.ReplacementMode = 'Normal';
rule.IsReplaceableCallBack = @replacementHandleReceiveHsmReply;
end

%% Replace ParameterSynchronization/ParameterSynchronization/Security/ReceiveHsmReply
function out = replacementHandleReceiveHsmReply(blockH)
    out =  contains(get_param(blockH, 'Name'), 'ReceiveHsmReply');
end
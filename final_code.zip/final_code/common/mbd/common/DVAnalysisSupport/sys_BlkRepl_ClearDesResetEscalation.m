function rule = sys_BlkRepl_ClearDesResetEscalation
rule = Sldv.xform.BlkRepRule; 
rule.FileName = mfilename;
rule.BlockType = 'SubSystem';
rule.ReplacementPath = sprintf('sys_BlkRepl_lib/ClearDesResetEscalation');
rule.ReplacementMode = 'Normal';
rule.IsReplaceableCallBack = @replacementHandleClearDesResetEscalation;
end

%% Replace OecbLib/PESSRAL/HandleResetReasons/HandleResetOfResetReasonCounters/ClearDesResetEscalation
function out = replacementHandleClearDesResetEscalation(blockH)
    out =  contains(get_param(blockH, 'Name'), 'ClearDesResetEscalation');
end
function rule = sys_BlkRepl_MsToTimebase
rule = Sldv.xform.BlkRepRule; 
rule.FileName = mfilename;
rule.BlockType = 'SubSystem';
rule.ReplacementPath = sprintf('sys_BlkRepl_lib/MsToTimebase');
rule.ReplacementMode = 'Normal';
rule.IsReplaceableCallBack = @replacementHandleMsToTimebase;
end

%% Replace OecbLib/PESSRAL/Time/TicksToMs/TicksToMs
function out = replacementHandleMsToTimebase(blockH)
    out =  strcmp(get_param(blockH, 'Name'), 'MsToTimebase');
end
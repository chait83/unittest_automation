function rule = sys_BlkRepl_CallCrc1
rule = Sldv.xform.BlkRepRule; 
rule.FileName = mfilename;
rule.BlockType = 'SubSystem';
rule.ReplacementPath = sprintf('sys_BlkRepl_lib/CallCrc1');
rule.ReplacementMode = 'Normal';
rule.IsReplaceableCallBack = @replacementHandleCallCrc1;
end

%% Replace req_analysis_SAB_flat/CtrlSafetyFunction/Model/Model/Model/AnalyseAprsNP/BufferLastFourValidMessagesNP/BuildCedesIntegrity/IntegrityChecks/CheckCrc32Channel1
function out = replacementHandleCallCrc1(blockH)
    out =  strcmp(get_param(blockH, 'Name'), 'CallCrc1') && size(get_param(blockH, 'InputSignalNames'), 2)==2;
end
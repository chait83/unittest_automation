function params = sldv_params_whiteboxbehavior
    % This function defines a configuration for model parameters, which
    % Simulink Design Verifier will use during its analysis.
    %
    % The configuration is given as a structure defining constraints that
    % apply to parameters during analysis. Each field defines a configuration
    % for the parameter after which it is named. The value of these fields can 
    % be a point, an interval, or a list of points and intervals.
    %
    % Points are specified using the constructor Sldv.Point, which takes a 
    % single value as its argument.
    %
    % Intervals are specified using the constructor Sldv.Interval, which
    % takes a lower bound, an upper bound, and an optional string argument.
    % The string argument is used to define close-intervals ('[]'), open
    % intervals ('()'), left-open intervals ('(]'), or right-open intervals
    % ('[)'). If the string argument is omitted, the interval is closed.
    %
    % The following example defines two parameters: K can be 3 or 5,
    % and M can be any value in the closed interval [0 10].
    %
    % params.K = { Sldv.Point(3), Sldv.Point(5) };
    % params.M = Sldv.Interval(0, 10);
    %
    % If the parameter is a scalar, the Point and Interval notations can be
    % simplified respectively to a single value and a vector of two
    % elements. The previous example can thus be written as:
    %
    % params.K = { 3, 5 };
    % params.M = [0 10];
    %
    % Parameters with fixed-point data type are specified by using fi object
    % such as the following example:
    %
    % params.K = { fi(3,1,16,3), fi(5,1,16,3) };
    % params.M = Sldv.Interval(fi(0,1,32,0.01,0), fi(10,1,32,0.01,0),'[]');
    %
    % Only closed intervals can be specified this way; open, or half-open
    % intervals must use the Sldv.Interval notation.
    %
    % Several sets of parameters can be specified at once by defining a
    % struct array:
    %
    % % First set
    % params(1).K = { 3, 5 };
    % params(1).M = [0 10];
    %
    % % Second set
    % params(2).K = { 12, 15, Sldv.Interval(50, 60, '()') };
    % params(2).M = 5;
    %
    % This example defines two sets of parameters. In the first one, K is
    % either 3 or 5, and M is between 0 and 10. In the second one, K is
    % either 12, 15, or in the open interval (50,60), and M is 5.
    
    %% --------------------------------------------------------------------
    % DAG reduce the following parameters in order to let timers expire
    % in a shorter amount of time, which allows SLDV analysis to complete 
    % with shorter input traces
	% note: These are evaluated in the 19ms evaluation task
    params.ServiceActivationTicks = uint8(5);      %from 158
    params.ShortServiceActivationTicks = uint8(3); %from 27
    params.EroActivationTicks = uint8(3);          %from 27
    params.OneSecondTicks = uint8(4);              %from 106
    params.TwoSecondTicks = uint8(8);              %from 211
    params.ServiceButtonPressTicks = uint8(7);     %from 263
    params.AvAlarmPeriodTicks = uint8(4);          %from 53
    params.SystemActivationTicks = uint8(2);       %from 11
    params.SP_DsbdRequestToutTicks = uint32(2);    %from 737
    params.AvAlarmDurationTicks = uint8(params.AvAlarmPeriodTicks*3);
end
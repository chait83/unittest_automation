function rule = sys_BlkRepl_HandleResetReasonsAtStartup
rule = Sldv.xform.BlkRepRule; 
rule.FileName = mfilename;
rule.BlockType = 'SubSystem';
rule.ReplacementPath = sprintf('sys_BlkRepl_lib/HandleResetReasonsAtStartup');
rule.ReplacementMode = 'Normal';
rule.IsReplaceableCallBack = @replacementHandleHandleResetReasonsAtStartup;
end

%% Replace OecbLib/PESSRAL/HandleResetReasons/HandleResetReasonsAtStartup
function out = replacementHandleHandleResetReasonsAtStartup(blockH)
    out =  strcmp(get_param(blockH, 'Name'), 'HandleResetReasonsAtStartup');
end
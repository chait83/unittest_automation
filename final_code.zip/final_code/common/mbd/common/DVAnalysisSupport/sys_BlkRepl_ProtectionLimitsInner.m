function rule = sys_BlkRepl_ProtectionLimitsInner
rule = Sldv.xform.BlkRepRule; 
rule.FileName = mfilename;
rule.BlockType = 'SubSystem';
rule.ReplacementPath = sprintf('sys_BlkRepl_lib/ProtectionLimitsInner');
rule.ReplacementMode = 'Normal';
rule.IsReplaceableCallBack = @replacementHandleProtectionLimitsInner;
end

%% Replace req_analysis_SAB_flat/CtrlSafetyFunction/Operational/ProtectionLimits/ProtectionLimitsInner
function out = replacementHandleProtectionLimitsInner(blockH)
    out =  strcmp(get_param(blockH, 'Name'), 'ProtectionLimitsInner'); 
end
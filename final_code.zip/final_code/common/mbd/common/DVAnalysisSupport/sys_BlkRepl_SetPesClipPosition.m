function rule = sys_BlkRepl_SetPesClipPosition
rule = Sldv.xform.BlkRepRule; 
rule.FileName = mfilename;
rule.BlockType = 'SubSystem';
rule.ReplacementPath = sprintf('sys_BlkRepl_lib/SetPesClipPosition');
rule.ReplacementMode = 'Normal';
rule.IsReplaceableCallBack = @replacementHandleSetPesClipPosition;
end

%% Replace SPIT/SetpesClipPosition
function out = replacementHandleSetPesClipPosition(blockH)
    %out =  strcmp(get_param(blockH, 'Mask'), 'on') && strcmp(get_param(blockH, 'ModelName'), 'SetPesClipPosition');
    out =  strcmp(get_param(blockH, 'Name'), 'TEST') && strcmp(get_param(blockH, 'ModelName'), 'SetPesClipPosition');
end
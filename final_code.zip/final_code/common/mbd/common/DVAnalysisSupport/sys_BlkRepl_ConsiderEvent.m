function rule = sys_BlkRepl_ConsiderEvent
rule = Sldv.xform.BlkRepRule; 
rule.FileName = mfilename;
rule.BlockType = 'SubSystem';
rule.ReplacementPath = sprintf('sys_BlkRepl_lib/ConsiderEvent');
rule.ReplacementMode = 'Normal';
rule.IsReplaceableCallBack = @replacementConsiderEvent;
end

%%
function out = replacementConsiderEvent(blockH)
    out = false;
    if(~isempty(get_param(blockH, 'MaskObject')))
        mask = get_param(blockH, 'MaskObject');
        % ConsiderEventParameters is a masked ConsiderEvent with 3 param
        out = contains(mask.Type, 'ConsiderEvent') && size(mask.Parameters, 2)==3  && ~contains(get_param(blockH, 'Parent'), 'HandleResetReasonsAtStartup');
    end
end
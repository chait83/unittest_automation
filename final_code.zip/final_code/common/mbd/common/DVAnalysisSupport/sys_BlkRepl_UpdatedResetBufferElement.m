function rule = sys_BlkRepl_UpdatedResetBufferElement
rule = Sldv.xform.BlkRepRule; 
rule.FileName = mfilename;
rule.BlockType = 'SubSystem';
rule.ReplacementPath = sprintf('sys_BlkRepl_lib/UpdatedResetBufferElement');
rule.ReplacementMode = 'Normal';
rule.IsReplaceableCallBack = @replacementHandleUpdatedResetBufferElement;
end

%% Replace OecbLib/PESSRAL/HandleResetReasons/HandleResetReasonsAtStartup/ReadAndStoreLastResetReason/ReadAndUpdateLastResetReason/UpdatedResetBufferElement
function out = replacementHandleUpdatedResetBufferElement(blockH)
    out =  contains(get_param(blockH, 'Name'), 'UpdatedResetBufferElement') && ~contains(get_param(blockH, 'Parent'), 'HandleResetReasonsAtStartup'); ;
end
function rule = sys_BlkRepl_MATLABFunctionCrc16
rule = Sldv.xform.BlkRepRule; 
rule.FileName = mfilename;
rule.BlockType = 'SubSystem';
rule.ReplacementPath = sprintf('sys_BlkRepl_lib/MATLABFunctionCrc16');
rule.ReplacementMode = 'Normal';
rule.IsReplaceableCallBack = @replacementHandleMATLABFunctionCrc16;
end

%replace 
function out = replacementHandleMATLABFunctionCrc16(blockH)
    outputs = get_param(blockH, 'OutputSignalNames');
    out =  strcmp(get_param(blockH, 'Name'), 'MATLABFunction') && size(outputs, 2)==1 && strcmp(outputs{1,1}, 'CRC16');
end
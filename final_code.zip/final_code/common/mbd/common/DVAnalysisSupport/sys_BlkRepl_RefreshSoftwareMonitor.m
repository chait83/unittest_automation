function rule = sys_BlkRepl_RefreshSoftwareMonitor
rule = Sldv.xform.BlkRepRule; 
rule.FileName = mfilename;
rule.BlockType = 'SubSystem';
rule.ReplacementPath = sprintf('sys_BlkRepl_lib/RefreshSoftwareMonitor');
rule.ReplacementMode = 'Normal';
rule.IsReplaceableCallBack = @replacementTestRefreshSoftwareMonitor;
end

%%
function out = replacementTestRefreshSoftwareMonitor(blockH)
    out = contains(get_param(blockH, 'Name'), 'RefreshSoftwareMonitor');
end
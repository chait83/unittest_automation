function rule = sys_BlkRepl_ConsiderEventParametrs
rule = Sldv.xform.BlkRepRule; 
rule.FileName = mfilename;
rule.BlockType = 'SubSystem';
rule.ReplacementPath = sprintf('sys_BlkRepl_lib/ConsiderEventParameters');
rule.ReplacementMode = 'Normal';
rule.IsReplaceableCallBack = @replacementConsiderEventParametrs;
end

%%
function out = replacementConsiderEventParametrs(blockH)
    out = false;
    if(~isempty(get_param(blockH, 'MaskObject')))
        mask = get_param(blockH, 'MaskObject');
        % ConsiderEventParameters is a masked ConsiderEvent with 2 param
        out = contains(mask.Type, 'ConsiderEvent') && size(mask.Parameters, 2)==2;
    end
end
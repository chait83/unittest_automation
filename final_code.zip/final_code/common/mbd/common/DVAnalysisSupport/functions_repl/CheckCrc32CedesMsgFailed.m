function [ failed ] = CheckCrc32CedesMsgFailed( msgXA, msgXB )

    

        failed = false;

end


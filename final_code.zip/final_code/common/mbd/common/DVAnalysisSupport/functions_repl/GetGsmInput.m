function ret = GetGsmInput(msgAlias)
% CECB: GetGsmInput()
%

    ret = true;

end

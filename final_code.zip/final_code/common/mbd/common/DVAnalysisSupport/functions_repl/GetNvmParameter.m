function GetNvmParameter(nvmParameterAlias)
% OECB: GetNvmParameter()
%


	% -- do nothing

end

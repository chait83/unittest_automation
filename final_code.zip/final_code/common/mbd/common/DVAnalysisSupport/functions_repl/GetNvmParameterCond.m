function GetNvmParameterCond(cond, nvmParameterAlias)
% OECB: GetNvmParameter()
%


    % -- do nothing


end

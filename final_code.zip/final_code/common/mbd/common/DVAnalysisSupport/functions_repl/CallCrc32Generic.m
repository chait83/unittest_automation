function [ CRC32 ] = CallCrc32Generic( option,  data)

    retCrc = uint32(data) + uint32(1);

    CRC32 = retCrc;

end


function [ CRC32 ] = CallCrc32SystemFloorTable( option,  data)

    retCrc = uint32(data) + uint32(1);
    
    CRC32 = retCrc;

end


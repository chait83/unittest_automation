function ResetBoard()
% OECB: ResetBoard()
%

	% -- do nothing


end

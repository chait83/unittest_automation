function GetAdcInputs()
% CECB: GetAdcInputs()
%


	% -- do nothing

end

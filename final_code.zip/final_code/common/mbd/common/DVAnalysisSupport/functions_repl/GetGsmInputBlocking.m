function GetGsmInputBlocking(msgAlias)
% CECB: GetGsmInputBlocking()
%

end

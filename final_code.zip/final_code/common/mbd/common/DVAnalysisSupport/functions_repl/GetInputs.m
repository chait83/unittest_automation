function GetInputs()
% OECB: GetInputs()
%
% -- do nothing

end

function offset = OpbGetOffset()


        
        offset = uint16(0);
        


end

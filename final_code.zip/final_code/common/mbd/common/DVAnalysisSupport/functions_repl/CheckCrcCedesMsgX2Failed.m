function [ failed ] = CheckCrcCedesMsgX2Failed( msg )

        failed = false;
end


function EventReportingSendChangedEvents()
% CECB: EventReportingSendChangedEvents()
%

    % -- do nothing


end

function [ CRC16 ] = CallCrc16SystemFloorTable( option, crcin, data)

    retCrc = uint16(data) + uint16(1);

    CRC16 = retCrc;

end


function SetNvmParameterIfChanged(nvmParameterAlias)
% OECB: SetNvmParameterIfChanged()
%

	% -- do nothing


end

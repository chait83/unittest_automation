function opb = ModelTimebaseToOpb(model, opbOffset)


        
        opb = uint16(uint16(model / 5) + opbOffset);
        


end

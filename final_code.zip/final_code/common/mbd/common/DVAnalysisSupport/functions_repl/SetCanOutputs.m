function SetCanOutputs(canMsgAlias)
% OECB: SetCanOutputs()
%


	% -- do nothing


end

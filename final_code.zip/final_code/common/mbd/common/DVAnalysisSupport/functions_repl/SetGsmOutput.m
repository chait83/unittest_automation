function SetGsmOutput(gsmMsgAlias)
% OECB: SetCanOutputs()
%
	% -- do nothing

end

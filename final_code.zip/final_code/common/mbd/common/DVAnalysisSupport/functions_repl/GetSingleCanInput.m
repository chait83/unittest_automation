function ret = GetSingleCanInput()
% CECB: GetSingleCanInput()
%

    ret = CanMsgAlias.can_message_application_id_invalid;

end

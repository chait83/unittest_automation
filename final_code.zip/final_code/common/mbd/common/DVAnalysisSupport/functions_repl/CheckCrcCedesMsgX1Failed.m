function [ failed ] = CheckCrcCedesMsgX1Failed( msg )

    
        failed = false;
end


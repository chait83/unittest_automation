function [ CRC16 ] = CallCrc16Generic( option,  data)

    retCrc = uint16(data);
    CRC16 = retCrc;

end
function SetCanOutputsCond(cond, canMsgAlias)
% OECB: SetCanOutputs()
%

% -- do nothing

end

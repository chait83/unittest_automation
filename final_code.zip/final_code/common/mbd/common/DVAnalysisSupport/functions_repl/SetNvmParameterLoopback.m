function SetNvmParameterLoopback(nvmParameterAlias)
% CECB: SetNvmParameterLoopback()
%

	% -- do nothing

end

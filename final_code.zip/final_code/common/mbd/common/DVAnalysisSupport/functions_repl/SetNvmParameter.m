function SetNvmParameter(nvmParameterAlias)
% OECB: SetNvmParameter()
%


	% -- do nothing

end

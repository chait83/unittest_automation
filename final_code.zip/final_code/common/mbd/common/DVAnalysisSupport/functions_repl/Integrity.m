function Integrity(pattern)
 
 % do nothing
 
end

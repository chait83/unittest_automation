function UpdateEventMatlabFunction(Event, State, StateOld, Parameter, EventClass)

    % -- do nothing

end

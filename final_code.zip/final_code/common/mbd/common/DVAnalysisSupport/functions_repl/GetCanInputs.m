function GetCanInputs()
% OECB: GetCanInputs()
%

% -- do nothing

end

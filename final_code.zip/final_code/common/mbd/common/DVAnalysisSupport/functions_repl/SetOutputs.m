function SetOutputs()
% OECB: SetOutputs()
%

% -- do nothing

end

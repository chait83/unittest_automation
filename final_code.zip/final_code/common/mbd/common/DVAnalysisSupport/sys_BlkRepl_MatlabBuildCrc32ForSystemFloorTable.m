function rule = sys_BlkRepl_MatlabBuildCrc32ForSystemFloorTable
rule = Sldv.xform.BlkRepRule; 
rule.FileName = mfilename;
rule.BlockType = 'SubSystem';
rule.ReplacementPath = sprintf('sys_BlkRepl_lib/MatlabBuildCrc32ForSystemFloorTable');
rule.ReplacementMode = 'Normal';
rule.IsReplaceableCallBack = @replacementHandleMATLAB_MatlabBuildCrc32ForSystemFloorTable;
end

%replace req_analysis_SCON_flat/CtrlSafetyFunction/EvaluationRef/Model5/DetermineSyncState/BuildCrc32FactoryConfiguration
function out = replacementHandleMATLAB_MatlabBuildCrc32ForSystemFloorTable(blockH)
    outputs = get_param(blockH, 'OutputSignalNames');
    out =  strcmp(get_param(blockH, 'Name'), 'MatlabBuildCrc32ForSystemFloorTable') && size(outputs, 2)==1 && strcmp(outputs{1,1}, 'Crc32');
end
fprintf(2,['Simulation paused, assertion failed: ' gcb '\n'])
set_param(bdroot,'SimulationCommand','pause')
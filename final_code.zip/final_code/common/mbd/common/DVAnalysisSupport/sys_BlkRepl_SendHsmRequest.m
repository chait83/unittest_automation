function rule = sys_BlkRepl_SendHsmRequest
rule = Sldv.xform.BlkRepRule; 
rule.FileName = mfilename;
rule.BlockType = 'SubSystem';
rule.ReplacementPath = sprintf('sys_BlkRepl_lib/SendHsmRequest');
rule.ReplacementMode = 'Normal';
rule.IsReplaceableCallBack = @replacementHandleSendHsmRequest;
end

%% Replace ParameterSynchronization/ParameterSynchronization/Security/SendHsmRequest
function out = replacementHandleSendHsmRequest(blockH)
    out =  contains(get_param(blockH, 'Name'), 'SendHsmRequest');
end
function GetCanInputs()
% OECB: GetCanInputs()
%

	if (coder.target('Sfun'))  % Simulink ----------------------------------

	% -- do nothing

	else  % embedded coder -------------------------------------------------
		coder.cinclude('GlueCodeProcess.h');
		coder.ceval( 'GlueCodeProcess_ReadCan' );
	end

end

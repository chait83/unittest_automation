function SetNvmGlobalParametersLoopback( part )
%SETNVMGLOBALPARAMETER  Calls SetNvmParameterIfChangedLoopback for a subset of NvmItems
%   To set all NvmParameters for the global nvm it is necesary to call this function
%   four times with the parameter part=0 till part=3
    if part == 0
        SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM0_MSGID_NvmId);
        SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM1_MSGID_NvmId);
        SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM2_MSGID_NvmId);
        SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM3_MSGID_NvmId);
        SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM4_MSGID_NvmId);
        SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM5_MSGID_NvmId);
        SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM6_MSGID_NvmId);
        SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM7_MSGID_NvmId);
        SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM8_MSGID_NvmId);

    end
    if part == 1
        SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM23_MSGID_NvmId);
        SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM25_MSGID_NvmId);
        SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM26_MSGID_NvmId);
        SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM27_MSGID_NvmId);
        SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM28_MSGID_NvmId);
        SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM29_MSGID_NvmId);
    end
    if part == 2
        SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM30_MSGID_NvmId);
        SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM31_MSGID_NvmId);
        SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM32_MSGID_NvmId);
        SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM33_MSGID_NvmId);
        SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM34_MSGID_NvmId);
        SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM35_MSGID_NvmId);
    end
    if part == 3
        SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM36_MSGID_NvmId);
        SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM37_MSGID_NvmId);
        SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM38_MSGID_NvmId);
        SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM39_MSGID_NvmId);
        SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM100_MSGID_NvmId);
        SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM101_MSGID_NvmId);
        SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM102_MSGID_NvmId);
        SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM140_MSGID_NvmId);
        SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM141_MSGID_NvmId);
        SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM142_MSGID_NvmId);
        SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM143_MSGID_NvmId);

    end
end


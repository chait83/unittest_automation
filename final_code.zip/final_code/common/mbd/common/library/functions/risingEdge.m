function [ y ] = risingEdge( u )
%RISINGEDGE Summary of this function goes here
%   Detailed explanation goes here
persistent u_old;

if isempty(u_old)
    u_old = false;
end

if (u && ~u_old)
   y = true;
else
    y = false;
end

u_old = u;

end


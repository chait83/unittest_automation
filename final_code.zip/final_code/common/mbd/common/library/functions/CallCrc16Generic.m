function [ CRC16 ] = CallCrc16Generic( option,  data)

    if (coder.target('Sfun'))  % Simulink ----------------------------------------
        
        retCrc = uint16(0);
        if data ~= hex2dec('FFFF')
            retCrc = uint16(data) + uint16(1);
        end          
           
        
    else % embedded coder -------------------------------------------------------
        coder.cinclude('Model/Support.h'); % use header
        retCrc = uint16(0); % implicit declaration
        retCrc = coder.ceval('ModelSupport_CalcCrc16', ...
            uint8(option), data); % use c-function
    end

    CRC16 = retCrc;

end


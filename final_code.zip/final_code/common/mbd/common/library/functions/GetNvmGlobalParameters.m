function GetNvmGlobalParameters(part)
%GETNVMGLOBALPARAMETERS Calls GetNvmParameter for a subset of NvmItems
%   To get all NvmParameters for the global nvm it is necesary to call this function
%   four times with the parameter part=0 till part=3

    if part == 0
        GetNvmParameter(NvmMsgAlias.NVMITEM0_MSGID_NvmId);
        GetNvmParameter(NvmMsgAlias.NVMITEM1_MSGID_NvmId);
        GetNvmParameter(NvmMsgAlias.NVMITEM2_MSGID_NvmId);
        GetNvmParameter(NvmMsgAlias.NVMITEM3_MSGID_NvmId);
        GetNvmParameter(NvmMsgAlias.NVMITEM4_MSGID_NvmId);
        GetNvmParameter(NvmMsgAlias.NVMITEM5_MSGID_NvmId);
        GetNvmParameter(NvmMsgAlias.NVMITEM6_MSGID_NvmId);
        GetNvmParameter(NvmMsgAlias.NVMITEM7_MSGID_NvmId);
        GetNvmParameter(NvmMsgAlias.NVMITEM8_MSGID_NvmId);
    end
    if part == 1
        GetNvmParameter(NvmMsgAlias.NVMITEM23_MSGID_NvmId);
        GetNvmParameter(NvmMsgAlias.NVMITEM25_MSGID_NvmId);
        GetNvmParameter(NvmMsgAlias.NVMITEM26_MSGID_NvmId);
        GetNvmParameter(NvmMsgAlias.NVMITEM27_MSGID_NvmId);
        GetNvmParameter(NvmMsgAlias.NVMITEM28_MSGID_NvmId);
        GetNvmParameter(NvmMsgAlias.NVMITEM29_MSGID_NvmId);
    end
    if part == 2
        GetNvmParameter(NvmMsgAlias.NVMITEM30_MSGID_NvmId);
        GetNvmParameter(NvmMsgAlias.NVMITEM31_MSGID_NvmId);
        GetNvmParameter(NvmMsgAlias.NVMITEM32_MSGID_NvmId);
        GetNvmParameter(NvmMsgAlias.NVMITEM33_MSGID_NvmId);
        GetNvmParameter(NvmMsgAlias.NVMITEM34_MSGID_NvmId);
        GetNvmParameter(NvmMsgAlias.NVMITEM35_MSGID_NvmId);
    end
    if part == 3
        GetNvmParameter(NvmMsgAlias.NVMITEM36_MSGID_NvmId);
        GetNvmParameter(NvmMsgAlias.NVMITEM37_MSGID_NvmId);
        GetNvmParameter(NvmMsgAlias.NVMITEM38_MSGID_NvmId);
        GetNvmParameter(NvmMsgAlias.NVMITEM39_MSGID_NvmId);
        GetNvmParameter(NvmMsgAlias.NVMITEM100_MSGID_NvmId);
        GetNvmParameter(NvmMsgAlias.NVMITEM101_MSGID_NvmId);
        GetNvmParameter(NvmMsgAlias.NVMITEM102_MSGID_NvmId);
        GetNvmParameter(NvmMsgAlias.NVMITEM103_MSGID_NvmId);
        GetNvmParameter(NvmMsgAlias.NVMITEM104_MSGID_NvmId);
        GetNvmParameter(NvmMsgAlias.NVMITEM105_MSGID_NvmId);
        GetNvmParameter(NvmMsgAlias.NVMITEM106_MSGID_NvmId);
        GetNvmParameter(NvmMsgAlias.NVMITEM107_MSGID_NvmId);
        GetNvmParameter(NvmMsgAlias.NVMITEM140_MSGID_NvmId);
        GetNvmParameter(NvmMsgAlias.NVMITEM141_MSGID_NvmId);
        GetNvmParameter(NvmMsgAlias.NVMITEM142_MSGID_NvmId);
        GetNvmParameter(NvmMsgAlias.NVMITEM143_MSGID_NvmId);
    end

end


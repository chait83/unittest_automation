function GetNvmParameter(nvmParameterAlias)
% OECB: GetNvmParameter()
%

	if (coder.target('Sfun'))  % Simulink ----------------------------------

	% -- do nothing

	else  % embedded coder -------------------------------------------------
		coder.cinclude('GlueCodeProcess.h');
		coder.ceval('GlueCodeProcess_ReadNvm', nvmParameterAlias);
	end

end

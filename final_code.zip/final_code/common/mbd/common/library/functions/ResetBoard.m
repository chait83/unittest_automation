function ResetBoard()
% OECB: ResetBoard()
%

	if (coder.target('Sfun'))  % Simulink ----------------------------------

	% -- do nothing

	else  % embedded coder -------------------------------------------------
		coder.cinclude('Proc/SafetyProcess.h');
		coder.ceval( 'SafetyProcess_ResetBoard' );
	end

end

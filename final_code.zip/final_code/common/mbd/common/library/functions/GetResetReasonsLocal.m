function GetResetReasonsLocal( )

    GetNvmParameter(NvmMsgAlias.NVMITEM208_ALL_MSGID_NvmId);

    GetNvmParameter(NvmMsgAlias.NVMITEM209_MSGID_NvmId);
    GetNvmParameter(NvmMsgAlias.NVMITEM210_MSGID_NvmId);
    GetNvmParameter(NvmMsgAlias.NVMITEM211_MSGID_NvmId);
    GetNvmParameter(NvmMsgAlias.NVMITEM212_MSGID_NvmId);
    GetNvmParameter(NvmMsgAlias.NVMITEM213_MSGID_NvmId);
    GetNvmParameter(NvmMsgAlias.NVMITEM214_MSGID_NvmId);
    GetNvmParameter(NvmMsgAlias.NVMITEM215_MSGID_NvmId);
    GetNvmParameter(NvmMsgAlias.NVMITEM216_MSGID_NvmId);
    GetNvmParameter(NvmMsgAlias.NVMITEM217_MSGID_NvmId);
    GetNvmParameter(NvmMsgAlias.NVMITEM218_MSGID_NvmId);
end


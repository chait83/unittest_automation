function SetNvmParameterLoopback(nvmParameterAlias)
% CECB: SetNvmParameterLoopback()
%

	if (coder.target('Sfun'))  % Simulink ----------------------------------

	% -- do nothing

	else  % embedded coder -------------------------------------------------
		coder.cinclude('GlueCodeProcess.h');
		coder.ceval('GlueCodeProcess_WriteNvmLoopback', nvmParameterAlias);
	end

end

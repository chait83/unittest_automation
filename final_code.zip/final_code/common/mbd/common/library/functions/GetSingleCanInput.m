function ret = GetSingleCanInput()
% CECB: GetSingleCanInput()
%

    if (coder.target('Sfun'))  % Simulink ----------------------------------

        ret = CanMsgAlias.can_message_application_id_invalid;

    else  % embedded coder -------------------------------------------------

        coder.cinclude('Proc/SafetyProcess.h');
        ret = CanMsgAlias.can_message_application_id_invalid;
        ret = coder.ceval('SafetyProcess_ReadSingleCan');

    end

end

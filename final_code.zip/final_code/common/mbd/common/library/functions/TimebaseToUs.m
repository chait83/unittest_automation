function us = TimebaseToUs(base, ticks)
% CECB: TimebaseToUs() - MW @ CECB
% Calculates �s from # timebase-ticks.
% Inputs:  base [�s], ticks
% Return:  us [�s]
% Example: "TimebaseToUs(50, 1000);" Returns �s for 1000 timebas-ticks,
%                                    where the timebase runs with 50 �s.

us = ticks * base;

if ( uint32(( uint32(4294967295) / uint32(base))) < uint32(ticks))
    dbgPrintf(uint32(0), 'TimebaseToUs: Overflow \n');
end
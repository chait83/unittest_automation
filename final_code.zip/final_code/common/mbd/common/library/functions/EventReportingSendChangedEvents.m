function EventReportingSendChangedEvents()
% CECB: EventReportingSendChangedEvents()
%

	if (coder.target('Sfun'))  % Simulink ----------------------------------

	    % -- do nothing

	else  % embedded coder -------------------------------------------------
        
		coder.cinclude('Event/Reporting.h');
		coder.ceval('EventReporting_SendChangedEvents');
	end

end

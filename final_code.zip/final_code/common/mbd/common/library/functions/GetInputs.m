function GetInputs()
% OECB: GetInputs()
%

	if (coder.target('Sfun'))  % Simulink ----------------------------------

	% -- do nothing

	else  % embedded coder -------------------------------------------------
		coder.cinclude('Proc/SafetyProcess.h');
		coder.ceval( 'SafetyProcess_ReadGpios' );
	end

end

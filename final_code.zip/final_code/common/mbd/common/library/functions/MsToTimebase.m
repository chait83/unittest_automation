function ticks = MsToTimebase(base, ms)
% CECB: MsToTimebase() - MW @ CECB
% Calculates # timebase-ticks from ms.
% Inputs:  base [�s], ms [ms]
% Return:  ticks
% Example: "MsToTimebase(50, 10);" Returns the timebase ticks for 10 ms,
%                                  where the timebase runs with 50 �s.
% Note:    Sets result to zero in the following cases:
%             * base == 0
%             * base <  0
%             * base is larger than uint32
%             * ms   <  0
%             * ms   is larger than uint32
%
% Todo: Raise an error instead of setting the result to zero.

% We need to typecast these values, because for an uint8 matlab would cause
% a saturation:  uint8(1) * 1000 == uint(255)
base_tb = uint32(base);
ms_tb   = uint32(ms);

if (base_tb ~= base) || (ms_tb ~= ms) || (base_tb == 0)
    % raise error
    % ticks = uint32(1) / uint32(0);
    
    % because we cant raise an error in matlab and in C, we set ticks to
    % zero
    ticks = uint32(0);
    
elseif (ms_tb < (uint32(429496725) / uint32(1000)))
    % uint32 calculation
    ticks = (ms_tb * 1000) / base_tb;  % normalize ms to �s and divide by base
    
else
    % double calculation for large values
    % reason: uint32 calculation would cause a saturation of ms_tb
    
    if (coder.target('Sfun') || coder.target('MATLAB'))  % Simulink ----------------------------------------
        ticks = uint32((double(ms_tb) * 1000) / base_tb);  % normalize ms to �s and divide by base
    else % embedded coder -------------------------------------------------------
       % dbgPrintf(uint32(0), 'Saturation \n');
        ticks = uint32(((ms_tb) * 1000) / base_tb);  % normalize ms to �s and divide by base
    end
end

end

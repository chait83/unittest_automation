function [ ResetBuffer ] = MapResetBuffer(  DD )

for i=1:11
    ResetBuffer.elements{i,1}.Timestamp_5p0s                            = eval(['DD.nvm.NvmItem' num2str(208 + i) '_ResetReasonBuffer_msg.data.Timestamp_5p0s']);
    ResetBuffer.elements{i,1}.intended                                  = eval(['DD.nvm.NvmItem' num2str(208 + i) '_ResetReasonBuffer_msg.data.active']);
    ResetBuffer.elements{i,1}.destructiveResetFccuFailureToReact        = eval(['DD.nvm.NvmItem' num2str(208 + i) '_ResetReasonBuffer_msg.data.destructiveResetFccuFailureToReact']);
    ResetBuffer.elements{i,1}.destructiveResetFlashInitFailure          = eval(['DD.nvm.NvmItem' num2str(208 + i) '_ResetReasonBuffer_msg.data.destructiveResetFlashInitFailure']);
    ResetBuffer.elements{i,1}.destructiveResetFunctionalResetEscalation = eval(['DD.nvm.NvmItem' num2str(208 + i) '_ResetReasonBuffer_msg.data.destructiveResetFunctionalResetEscalation']);
    ResetBuffer.elements{i,1}.destructiveResetPowerOn                   = eval(['DD.nvm.NvmItem' num2str(208 + i) '_ResetReasonBuffer_msg.data.destructiveResetPowerOn']);  
    ResetBuffer.elements{i,1}.destructiveResetSoftwareDestructiveReset  = eval(['DD.nvm.NvmItem' num2str(208 + i) '_ResetReasonBuffer_msg.data.destructiveResetSoftwareDestructiveReset']);
    ResetBuffer.elements{i,1}.destructiveResetStcuUnrecoverableFault    = eval(['DD.nvm.NvmItem' num2str(208 + i) '_ResetReasonBuffer_msg.data.destructiveResetStcuUnrecoverableFault']);
    ResetBuffer.elements{i,1}.destructiveResetTempSensorFailure         = eval(['DD.nvm.NvmItem' num2str(208 + i) '_ResetReasonBuffer_msg.data.destructiveResetTempSensorFailure']);
    ResetBuffer.elements{i,1}.destructiveResetVoltageOutOfRange         = eval(['DD.nvm.NvmItem' num2str(208 + i) '_ResetReasonBuffer_msg.data.destructiveResetVoltageOutOfRange']);
    ResetBuffer.elements{i,1}.functionalResetExternalReset              = eval(['DD.nvm.NvmItem' num2str(208 + i) '_ResetReasonBuffer_msg.data.functionalResetExternalReset']);
    ResetBuffer.elements{i,1}.functionalResetFccuHardReaction           = eval(['DD.nvm.NvmItem' num2str(208 + i) '_ResetReasonBuffer_msg.data.functionalResetFccuHardReaction']);
    ResetBuffer.elements{i,1}.functionalResetFccuSoftReaction           = eval(['DD.nvm.NvmItem' num2str(208 + i) '_ResetReasonBuffer_msg.data.functionalResetFccuSoftReaction']);
    ResetBuffer.elements{i,1}.functionalResetJtag                       = eval(['DD.nvm.NvmItem' num2str(208 + i) '_ResetReasonBuffer_msg.data.functionalResetJtag']);
    ResetBuffer.elements{i,1}.functionalResetSelfTestCompleted          = eval(['DD.nvm.NvmItem' num2str(208 + i) '_ResetReasonBuffer_msg.data.functionalResetSelfTestCompleted']);
    ResetBuffer.elements{i,1}.functionalResetSoftwareFunctionalReset    = eval(['DD.nvm.NvmItem' num2str(208 + i) '_ResetReasonBuffer_msg.data.functionalResetSoftwareFunctionalReset']);
    ResetBuffer.elements{i,1}.functionalResetTempSensorFailure          = eval(['DD.nvm.NvmItem' num2str(208 + i) '_ResetReasonBuffer_msg.data.functionalResetTempSensorFailure']);
    ResetBuffer.elements{i,1}.functionalResetVoltageOutOfRange          = eval(['DD.nvm.NvmItem' num2str(208 + i) '_ResetReasonBuffer_msg.data.functionalResetVoltageOutOfRange']);
end

ResetBuffer.index                                                       = DD.nvm.NvmItem205_All_msg.data.ResetReasonBufferIndex;

end
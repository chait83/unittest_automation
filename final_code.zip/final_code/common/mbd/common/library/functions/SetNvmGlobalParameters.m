function SetNvmGlobalParameters( part )
%SETNVMGLOBALPARAMETER  Calls SetNvmParameterIfChanged for a subset of NvmItems
%   To set all NvmParameters for the global nvm it is necesary to call this function
%   four times with the parameter part=0 till part=3
    if part == 0
        SetNvmParameterIfChanged(NvmMsgAlias.NVMITEM0_MSGID_NvmId);
        SetNvmParameterIfChanged(NvmMsgAlias.NVMITEM1_MSGID_NvmId);
        SetNvmParameterIfChanged(NvmMsgAlias.NVMITEM2_MSGID_NvmId);
        SetNvmParameterIfChanged(NvmMsgAlias.NVMITEM3_MSGID_NvmId);
        SetNvmParameterIfChanged(NvmMsgAlias.NVMITEM4_MSGID_NvmId);
        SetNvmParameterIfChanged(NvmMsgAlias.NVMITEM5_MSGID_NvmId);
    end
    if part == 1
        SetNvmParameterIfChanged(NvmMsgAlias.NVMITEM23_MSGID_NvmId);
        SetNvmParameterIfChanged(NvmMsgAlias.NVMITEM25_MSGID_NvmId);
        SetNvmParameterIfChanged(NvmMsgAlias.NVMITEM26_MSGID_NvmId);
        SetNvmParameterIfChanged(NvmMsgAlias.NVMITEM27_MSGID_NvmId);
        SetNvmParameterIfChanged(NvmMsgAlias.NVMITEM28_MSGID_NvmId);
        SetNvmParameterIfChanged(NvmMsgAlias.NVMITEM29_MSGID_NvmId);
    end
    if part == 2
        SetNvmParameterIfChanged(NvmMsgAlias.NVMITEM30_MSGID_NvmId);
        SetNvmParameterIfChanged(NvmMsgAlias.NVMITEM31_MSGID_NvmId);
        SetNvmParameterIfChanged(NvmMsgAlias.NVMITEM32_MSGID_NvmId);
        SetNvmParameterIfChanged(NvmMsgAlias.NVMITEM33_MSGID_NvmId);
        SetNvmParameterIfChanged(NvmMsgAlias.NVMITEM34_MSGID_NvmId);
        SetNvmParameterIfChanged(NvmMsgAlias.NVMITEM35_MSGID_NvmId);
    end
    if part == 3
        SetNvmParameterIfChanged(NvmMsgAlias.NVMITEM36_MSGID_NvmId);
        SetNvmParameterIfChanged(NvmMsgAlias.NVMITEM37_MSGID_NvmId);
        SetNvmParameterIfChanged(NvmMsgAlias.NVMITEM38_MSGID_NvmId);
        SetNvmParameterIfChanged(NvmMsgAlias.NVMITEM39_MSGID_NvmId);
        SetNvmParameterIfChanged(NvmMsgAlias.NVMITEM100_MSGID_NvmId);
        SetNvmParameterIfChanged(NvmMsgAlias.NVMITEM101_MSGID_NvmId);
        SetNvmParameterIfChanged(NvmMsgAlias.NVMITEM102_MSGID_NvmId);
    end
end


function [ CRC16 ] = CallCrc16SystemFloorTable( option, crcin, data) %#codegen

    if (coder.target('Sfun'))  % Simulink ----------------------------------------
        retCrc = uint16(data) + uint16(1); % simplify under Simulink
    else % embedded coder -------------------------------------------------------
        coder.cinclude('Model/Support.h'); % include file directive
        retCrc = uint16(0); % init
        retCrc = coder.ceval('ModelSupport_CalcCrc16SystemFloorTable', ...
            uint8(option), uint16(crcin), uint8(data)); % invoke c-function
    end

    CRC16 = retCrc;

end


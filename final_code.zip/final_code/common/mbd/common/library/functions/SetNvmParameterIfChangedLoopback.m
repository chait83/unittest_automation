function SetNvmParameterIfChangedLoopback(nvmParameterAlias)
% CECB: SetNvmParameterIfChangedLoopback()
%

	if (coder.target('Sfun'))  % Simulink ----------------------------------

	% -- do nothing

	else  % embedded coder -------------------------------------------------
		coder.cinclude('GlueCodeProcess.h');
		coder.ceval('GlueCodeProcess_WriteIfChangedNvmLoopback', nvmParameterAlias);
	end

end

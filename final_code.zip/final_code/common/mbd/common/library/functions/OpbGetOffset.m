function offset = OpbGetOffset()

    if (coder.target('Sfun'))  % Simulink ----------------------------------------
        
        offset = uint16(0);
        
    else  % embedded coder -------------------------------------------------------
        
        coder.cinclude('Opb/Timestamp.h');
        %offset = coder.opaque('OpbTimestamp_T', 'HeaderFile', 'OpbTimestamp.h');
        offset = uint16(0);
        offset = coder.ceval('OpbTimestamp_GetOffset');
        
    end

end

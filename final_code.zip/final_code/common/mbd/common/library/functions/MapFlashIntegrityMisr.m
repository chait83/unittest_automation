function [ FlashIntegrityMisr] = MapFlashIntegrityMisr(  DD )

FlashIntegrityMisr.UM{1,1}   = DD.nvm.NvmItem220_UM0_1_msg.data.UMk;
FlashIntegrityMisr.UM{2,1}   = DD.nvm.NvmItem220_UM0_1_msg.data.UMk_1;

FlashIntegrityMisr.UM{3,1}   = DD.nvm.NvmItem221_UM2_3_msg.data.UMk;
FlashIntegrityMisr.UM{4,1}   = DD.nvm.NvmItem221_UM2_3_msg.data.UMk_1;

FlashIntegrityMisr.UM{5,1}   = DD.nvm.NvmItem222_UM4_5_msg.data.UMk;
FlashIntegrityMisr.UM{6,1}   = DD.nvm.NvmItem222_UM4_5_msg.data.UMk_1;

FlashIntegrityMisr.UM{7,1}   = DD.nvm.NvmItem223_UM6_7_msg.data.UMk;
FlashIntegrityMisr.UM{8,1}   = DD.nvm.NvmItem223_UM6_7_msg.data.UMk_1;

FlashIntegrityMisr.UM{9,1}   = DD.nvm.NvmItem224_UM8_9_msg.data.UMk;
FlashIntegrityMisr.UM{10,1}  = DD.nvm.NvmItem224_UM8_9_msg.data.UMk_1;
end
function [ failed ] = CheckCrcCedesMsgX1Failed( msg ) %#codegen

    
    if (coder.target('Sfun'))  % Simulink ----------------------------------------
        failed = false;
    else % embedded coder -------------------------------------------------------
        coder.cinclude('Model/Support.h');
        ret = uint8(0);
        ret = coder.ceval('ModelSupport_CheckCrcCedesMsgX1Failed', ...
            uint8(msg.SeqCnt), uint32(msg.Position), int16(msg.Velocity), uint16(msg.CRC16) );
        failed = false;
        if (ret)
            failed = true;
        end
    end
end


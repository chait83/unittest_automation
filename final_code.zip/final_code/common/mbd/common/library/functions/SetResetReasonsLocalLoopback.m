function SetResetReasonsLocalLoopback( )

    SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM208_ALL_MSGID_NvmId);

    SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM209_MSGID_NvmId);
    SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM210_MSGID_NvmId);
    SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM211_MSGID_NvmId);
    SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM212_MSGID_NvmId);
    SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM213_MSGID_NvmId);
    SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM214_MSGID_NvmId);
    SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM215_MSGID_NvmId);
    SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM216_MSGID_NvmId);
    SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM217_MSGID_NvmId);
    SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM218_MSGID_NvmId);
    SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM219_MSGID_NvmId);
end


function GetGsmInputBlocking(msgAlias)
% CECB: GetGsmInputBlocking()
%

    if (coder.target('Sfun'))  % Simulink ----------------------------------

        %ret = GsmMsgAlias.IdInvalid;

    else  % embedded coder -------------------------------------------------

        coder.cinclude('Proc/SafetyProcess.h');
        % ret = GsmMsgAlias.IdInvalid;
        coder.ceval('SafetyProcess_ReadScioptaMsg', msgAlias, true);

    end

end

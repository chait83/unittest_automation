function [ ResetReasonCounter ] = MapResetCounter(  DD )

ResetReasonCounter.destructiveResetFccuFailureToReact             = DD.nvm.NvmItem208_ResetReasonCounter_msg.data.destructiveResetFccuFailureToReact;
ResetReasonCounter.destructiveResetFlashInitFailure               = DD.nvm.NvmItem208_ResetReasonCounter_msg.data.destructiveResetFlashInitFailure;
ResetReasonCounter.destructiveResetFunctionalResetEscalation      = DD.nvm.NvmItem208_ResetReasonCounter_msg.data.destructiveResetFunctionalResetEscalation;
ResetReasonCounter.destructiveResetPowerOn                        = DD.nvm.NvmItem208_ResetReasonCounter_msg.data.destructiveResetPowerOn;
ResetReasonCounter.destructiveResetSoftwareDestructiveReset       = DD.nvm.NvmItem208_ResetReasonCounter_msg.data.destructiveResetSoftwareDestructiveReset;
ResetReasonCounter.destructiveResetStcuUnrecoverableFault         = DD.nvm.NvmItem208_ResetReasonCounter_msg.data.destructiveResetStcuUnrecoverableFault;
ResetReasonCounter.destructiveResetTempSensorFailure              = DD.nvm.NvmItem208_ResetReasonCounter_msg.data.destructiveResetTempSensorFailure;
ResetReasonCounter.destructiveResetVoltageOutOfRange              = DD.nvm.NvmItem208_ResetReasonCounter_msg.data.destructiveResetVoltageOutOfRange;
ResetReasonCounter.functionalResetExternalReset                   = DD.nvm.NvmItem208_ResetReasonCounter_msg.data.functionalResetExternalReset;
ResetReasonCounter.functionalResetFccuHardReaction                = DD.nvm.NvmItem208_ResetReasonCounter_msg.data.functionalResetFccuHardReaction;
ResetReasonCounter.functionalResetFccuSoftReaction                = DD.nvm.NvmItem208_ResetReasonCounter_msg.data.functionalResetFccuSoftReaction;
ResetReasonCounter.functionalResetJtag                            = DD.nvm.NvmItem208_ResetReasonCounter_msg.data.functionalResetJtag;
ResetReasonCounter.functionalResetSelfTestCompleted               = DD.nvm.NvmItem208_ResetReasonCounter_msg.data.functionalResetSelfTestCompleted;
ResetReasonCounter.functionalResetSoftwareFunctionalReset         = DD.nvm.NvmItem208_ResetReasonCounter_msg.data.functionalResetSoftwareFunctionalReset;
ResetReasonCounter.functionalResetTempSensorFailure               = DD.nvm.NvmItem208_ResetReasonCounter_msg.data.functionalResetTempSensorFailure;
ResetReasonCounter.functionalResetVoltageOutOfRange               = DD.nvm.NvmItem208_ResetReasonCounter_msg.data.functionalResetVoltageOutOfRange;

end
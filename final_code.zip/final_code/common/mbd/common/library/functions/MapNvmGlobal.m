function [ map_global ] = MapNvmGlobal(  DD )
%MAPNVMGLOBAL Summary of this function goes here
%   Detailed explanation goes here

%% NVM - Factory Configuration

map_global.factoryCfg.Certificate.Prefix                                             = DD.nvm.NvmItem6_msg.data.CertificatePrefix;

map_global.factoryCfg.Certificate.Number{1,1}                                        = DD.nvm.NvmItem6_msg.data.CertificateNumber1;
map_global.factoryCfg.Certificate.Number{2,1}                                        = DD.nvm.NvmItem6_msg.data.CertificateNumber2;
map_global.factoryCfg.Certificate.Number{3,1}                                        = DD.nvm.NvmItem6_msg.data.CertificateNumber3;
map_global.factoryCfg.Certificate.Number{4,1}                                        = DD.nvm.NvmItem6_msg.data.CertificateNumber4;
map_global.factoryCfg.Certificate.Number{5,1}                                        = DD.nvm.NvmItem6_msg.data.CertificateNumber5;

map_global.factoryCfg.Factory.Name{1,1}                                              = DD.nvm.NvmItem7_msg.data.FactoryName1;
map_global.factoryCfg.Factory.Name{2,1}                                              = DD.nvm.NvmItem7_msg.data.FactoryName2;
map_global.factoryCfg.Factory.Name{3,1}                                              = DD.nvm.NvmItem7_msg.data.FactoryName3;
map_global.factoryCfg.Factory.Name{4,1}                                              = DD.nvm.NvmItem7_msg.data.FactoryName4;
map_global.factoryCfg.Factory.Name{5,1}                                              = DD.nvm.NvmItem7_msg.data.FactoryName5;
map_global.factoryCfg.Factory.Name{6,1}                                              = DD.nvm.NvmItem7_msg.data.FactoryName6;
map_global.factoryCfg.Factory.Name{7,1}                                              = DD.nvm.NvmItem7_msg.data.FactoryName7;
map_global.factoryCfg.Factory.Name{8,1}                                              = DD.nvm.NvmItem7_msg.data.FactoryName8;

map_global.factoryCfg.Factory.DateWeek{1,1}                                          = DD.nvm.NvmItem8_msg.data.FactoryDateWeek1;
map_global.factoryCfg.Factory.DateWeek{2,1}                                          = DD.nvm.NvmItem8_msg.data.FactoryDateWeek2;
map_global.factoryCfg.Factory.DateYear{1,1}                                          = DD.nvm.NvmItem8_msg.data.FactoryDateYear1;
map_global.factoryCfg.Factory.DateYear{2,1}                                          = DD.nvm.NvmItem8_msg.data.FactoryDateYear2;
map_global.factoryCfg.Factory.DateYear{3,1}                                          = DD.nvm.NvmItem8_msg.data.FactoryDateYear3;
map_global.factoryCfg.Factory.DateYear{4,1}                                          = DD.nvm.NvmItem8_msg.data.FactoryDateYear4;

map_global.factoryCfg.Parameter.UnitNr{1,1}                                          = DD.nvm.NvmItem0_msg.data.UnitNrPart1;
map_global.factoryCfg.Parameter.UnitNr{2,1}                                          = DD.nvm.NvmItem0_msg.data.UnitNrPart2;
map_global.factoryCfg.Parameter.UnitNr{3,1}                                          = DD.nvm.NvmItem0_msg.data.UnitNrPart3;
map_global.factoryCfg.Parameter.UnitNr{4,1}                                          = DD.nvm.NvmItem0_msg.data.UnitNrPart4;
map_global.factoryCfg.Parameter.UnitNr{5,1}                                          = DD.nvm.NvmItem0_msg.data.UnitNrPart5;
map_global.factoryCfg.Parameter.UnitNr{6,1}                                          = DD.nvm.NvmItem0_msg.data.UnitNrPart6;
map_global.factoryCfg.Parameter.UnitNr{7,1}                                          = DD.nvm.NvmItem0_msg.data.UnitNrPart7;
map_global.factoryCfg.Parameter.UnitNr{8,1}                                          = DD.nvm.NvmItem0_msg.data.UnitNrPart8;

map_global.factoryCfg.Parameter.NomSpeed1p0mmps                                      = DD.nvm.NvmItem1_msg.data.NomSpeed;
map_global.factoryCfg.Parameter.Rise1p0m                                             = DD.nvm.NvmItem1_msg.data.Rise;
map_global.factoryCfg.Parameter.LS8Position1p0mm                                     = DD.nvm.NvmItem1_msg.data.LS8Position;
map_global.factoryCfg.Parameter.LS7Position1p0mm                                     = DD.nvm.NvmItem1_msg.data.LS7Position;

map_global.factoryCfg.Parameter.LS6MICAO1p0mm                                        = DD.nvm.NvmItem2_msg.data.LS6MICAO;
map_global.factoryCfg.Parameter.LS6PINS1p0mm                                         = DD.nvm.NvmItem2_msg.data.LS6PINS;
map_global.factoryCfg.Parameter.LS5PINS1p0mm                                         = DD.nvm.NvmItem2_msg.data.LS5PINS;
map_global.factoryCfg.Parameter.LS5MICAO1p0mm                                        = DD.nvm.NvmItem2_msg.data.LS5MICAO;

map_global.factoryCfg.Parameter.PitProtection1p0mm                                   = DD.nvm.NvmItem3_msg.data.PitProtection;
map_global.factoryCfg.Parameter.PitDepth1p0mm                                        = DD.nvm.NvmItem3_msg.data.PitDepth;
map_global.factoryCfg.Parameter.OverheadProtection1p0mm                              = DD.nvm.NvmItem3_msg.data.OverheadProtection;
map_global.factoryCfg.Parameter.Overhead1p0mm                                        = DD.nvm.NvmItem3_msg.data.Overhead;

map_global.factoryCfg.Parameter.DzSiceUCM1p0mm                                       = DD.nvm.NvmItem4_msg.data.DZSizeUCM;
map_global.factoryCfg.Parameter.NrOfDsSegments                                       = DD.nvm.NvmItem4_msg.data.NrOfDsSegments;

map_global.factoryCfg.Parameter.EIBoardVersion                                       = DD.nvm.NvmItem4_msg.data.EIBoardVersion;
map_global.factoryCfg.Parameter.PitBoardVersion                                      = DD.nvm.NvmItem4_msg.data.PitBoardVersion;
map_global.factoryCfg.Parameter.CarBoardVersion                                      = DD.nvm.NvmItem4_msg.data.CarBoardVersion;

map_global.factoryCfg.Parameter.SabBoardVersion                                      = DD.nvm.NvmItem5_msg.data.SabBoardVersion;
map_global.factoryCfg.Parameter.DriveBoardVersion                                    = DD.nvm.NvmItem5_msg.data.DriveBoardVersion;
map_global.factoryCfg.Parameter.CanProtocolVersion                                   = DD.nvm.NvmItem5_msg.data.CANProtocolVersion;

map_global.factoryCfg.Parameter.A11p0mmps2                                           = DD.nvm.NvmItem9_msg.data.A11p0mmps2;
map_global.factoryCfg.Parameter.A21p0mmps2                                           = DD.nvm.NvmItem9_msg.data.A21p0mmps2;
map_global.factoryCfg.Parameter.A2Down1pmmps2                                        = DD.nvm.NvmItem9_msg.data.A2Down1pmmps2;
map_global.factoryCfg.Parameter.A31p0mmps2                                           = DD.nvm.NvmItem9_msg.data.A31p0mmps2;

map_global.factoryCfg.Parameter.A3Down1p0mmps2                                       = DD.nvm.NvmItem10_msg.data.A3Down1p0mmps2;
map_global.factoryCfg.Parameter.DtBrake1p0ms                                         = DD.nvm.NvmItem10_msg.data.DtBrake1p0ms;
map_global.factoryCfg.Parameter.DtSFC1p0ms                                           = DD.nvm.NvmItem10_msg.data.DtSFC1p0ms;
map_global.factoryCfg.Parameter.StrikeSpeed1p0mmps                                   = DD.nvm.NvmItem10_msg.data.StrikeSpeed1p0mmps;

map_global.factoryCfg.Parameter.MinBuffer1p0mm                                       = DD.nvm.NvmItem11_msg.data.MinBuffer1p0mm;
map_global.factoryCfg.Parameter.MinEtsSpeed1p0mmps                                   = DD.nvm.NvmItem11_msg.data.MinEtsSpeed1p0mmps;

map_global.factoryCfg.Parameter.SpareWord{1,1}                                       = DD.nvm.NvmItem140_msg.data.SpareWord1;
map_global.factoryCfg.Parameter.SpareWord{2,1}                                       = DD.nvm.NvmItem140_msg.data.SpareWord2;
map_global.factoryCfg.Parameter.SpareWord{3,1}                                       = DD.nvm.NvmItem140_msg.data.SpareWord3;
map_global.factoryCfg.Parameter.SpareWord{4,1}                                       = DD.nvm.NvmItem141_msg.data.SpareWord4;

map_global.factoryCfg.Parameter.SpareWord{5,1}                                       = DD.nvm.NvmItem141_msg.data.SpareWord1;
map_global.factoryCfg.Parameter.SpareWord{6,1}                                       = DD.nvm.NvmItem141_msg.data.SpareWord2;

map_global.factoryCfg.Parameter.PICS                                                 = DD.nvm.NvmItem23_msg.data.PICS;
map_global.factoryCfg.Parameter.BFS                                                  = DD.nvm.NvmItem23_msg.data.BFS;
map_global.factoryCfg.Parameter.PLAD                                                 = DD.nvm.NvmItem23_msg.data.PLAD;
map_global.factoryCfg.Parameter.CLAD                                                 = DD.nvm.NvmItem23_msg.data.CLAD;
map_global.factoryCfg.Parameter.MAC                                                  = DD.nvm.NvmItem23_msg.data.MAC;
map_global.factoryCfg.Parameter.SCS                                                  = DD.nvm.NvmItem23_msg.data.SCS;
map_global.factoryCfg.Parameter.RearDoors                                            = DD.nvm.NvmItem23_msg.data.RearDoors;
map_global.factoryCfg.Parameter.RearDoorsInPit                                       = DD.nvm.NvmItem23_msg.data.RearDoorsInPit;

map_global.factoryCfg.Parameter.SpareJumper1_8                                       = DD.nvm.NvmItem23_msg.data.SpareJumper1_8;

%% NVM - Pessral Configuration

map_global.cfg.TapeOffsetLdg00p1mm                                      = DD.nvm.NvmItem27_msg.data.OffsetLowestLanding;

%% NVM - SystemFloorTable

map_global.SystemFloorTable.CWTBufferPosition                     = DD.nvm.NvmItem26_msg.data.CWTBufferPosition;
map_global.SystemFloorTable.CWTBufferReserved                     = DD.nvm.NvmItem26_msg.data.CWTBufferReserved;

map_global.SystemFloorTable.CarBufferPosition                     = DD.nvm.NvmItem26_msg.data.CarBufferPosition;
map_global.SystemFloorTable.CarBufferReserved                     = DD.nvm.NvmItem26_msg.data.CarBufferReserved;


o = 1;
u = 100;
p = 0;
for i=28:39
	map_global.SystemFloorTable.FloorInfo{o,1}.clipValid            = eval(['DD.nvm.NvmItem' num2str(i) '_msg.data.FloorFirstClipConfigValid']);
	map_global.SystemFloorTable.FloorInfo{o,1}.clips                = eval(['DD.nvm.NvmItem' num2str(i) '_msg.data.FloorFirstClips']);
	map_global.SystemFloorTable.FloorInfo{o,1}.opening              = eval(['DD.nvm.NvmItem' num2str(i) '_msg.data.FloorFirstOpening']);
	map_global.SystemFloorTable.FloorInfo{o,1}.position0p1mm        = eval(['DD.nvm.NvmItem' num2str(i) '_msg.data.FloorFirstPosition']);
	map_global.SystemFloorTable.FloorInfo{o,1}.valid                = eval(['DD.nvm.NvmItem' num2str(i) '_msg.data.FloorFirstDoorConfigValid']);
	map_global.SystemFloorTable.FloorInfo{o,1}.FloorFirstReserved1  = eval(['DD.nvm.NvmItem' num2str(i) '_msg.data.FloorFirstReserved1']);
	map_global.SystemFloorTable.FloorInfo{o,1}.FloorFirstReserved2  = eval(['DD.nvm.NvmItem' num2str(i) '_msg.data.FloorFirstReserved2']);
    
	map_global.SystemFloorTable.FloorInfo{o,1}.frontDsSegs          = eval(['DD.nvm.NvmItem' num2str(u) '_msg.data.hasSegs' num2str(p)]);
	map_global.SystemFloorTable.FloorInfo{o,1}.rearDsSegs           = eval(['DD.nvm.NvmItem' num2str(u) '_msg.data.hasSegs' num2str(p + 1)]);
    
    map_global.SystemFloorTable.FloorInfo{o,1}.verified             = eval(['DD.nvm.NvmItem27_msg.data.FloorInfoVerified' num2str(o-1)]);
    
	map_global.SystemFloorTable.FloorInfo{o+1,1}.clipValid          = eval(['DD.nvm.NvmItem' num2str(i) '_msg.data.FloorSecondClipConfigValid']);
	map_global.SystemFloorTable.FloorInfo{o+1,1}.clips              = eval(['DD.nvm.NvmItem' num2str(i) '_msg.data.FloorSecondClips']);
	map_global.SystemFloorTable.FloorInfo{o+1,1}.opening            = eval(['DD.nvm.NvmItem' num2str(i) '_msg.data.FloorSecondOpening']);
	map_global.SystemFloorTable.FloorInfo{o+1,1}.position0p1mm      = eval(['DD.nvm.NvmItem' num2str(i) '_msg.data.FloorSecondPosition']);
	map_global.SystemFloorTable.FloorInfo{o+1,1}.valid              = eval(['DD.nvm.NvmItem' num2str(i) '_msg.data.FloorSecondDoorConfigValid']);
    map_global.SystemFloorTable.FloorInfo{o+1,1}.FloorFirstReserved1= eval(['DD.nvm.NvmItem' num2str(i) '_msg.data.FloorSecondReserved1']);
    map_global.SystemFloorTable.FloorInfo{o+1,1}.FloorFirstReserved2= eval(['DD.nvm.NvmItem' num2str(i) '_msg.data.FloorSecondReserved2']);
    
	map_global.SystemFloorTable.FloorInfo{o+1,1}.frontDsSegs        = eval(['DD.nvm.NvmItem' num2str(u) '_msg.data.hasSegs' num2str(p + 2)]);
	map_global.SystemFloorTable.FloorInfo{o+1,1}.rearDsSegs         = eval(['DD.nvm.NvmItem' num2str(u) '_msg.data.hasSegs' num2str(p + 3)]);
    map_global.SystemFloorTable.FloorInfo{o+1,1}.verified           = eval(['DD.nvm.NvmItem27_msg.data.FloorInfoVerified' num2str(o+1-1)]);
    o = o + 2;
    p = p + 4;
    if ( mod(o+1,4) == 0)
       u = u + 1; 
       p = 0;
    end
    
end

map_global.SystemFloorTable.RevisionIndex                           = DD.nvm.NvmItem25_msg.data.RevisionIndex;
map_global.SystemFloorTable.TableStatus.Accuracy                    = DD.nvm.NvmItem25_msg.data.TableStatusAccuracy;
map_global.SystemFloorTable.TableStatus.BottomFloorNumber           = DD.nvm.NvmItem25_msg.data.BottomFloorNumber;
map_global.SystemFloorTable.TableStatus.LimitsValid                 = DD.nvm.NvmItem25_msg.data.TableStatusLimitsValid;
map_global.SystemFloorTable.TableStatus.SafetyValid                 = DD.nvm.NvmItem25_msg.data.TableStatusSafetyValid;
map_global.SystemFloorTable.TableStatus.TopFloorNumber              = DD.nvm.NvmItem25_msg.data.TopFloorNumber;
map_global.SystemFloorTable.TableStatus.TableStatusReserved         = DD.nvm.NvmItem25_msg.data.TableStatusReserved;
map_global.SystemFloorTable.TableStatus.Reserved                    = DD.nvm.NvmItem25_msg.data.Reserved;


map_global.SystemFloorTable.RevisionIndex                         = DD.nvm.NvmItem25_msg.data.RevisionIndex;
map_global.SystemFloorTable.TableStatus.Accuracy                  = DD.nvm.NvmItem25_msg.data.TableStatusAccuracy;
map_global.SystemFloorTable.TableStatus.BottomFloorNumber         = DD.nvm.NvmItem25_msg.data.BottomFloorNumber;
map_global.SystemFloorTable.TableStatus.LimitsValid               = DD.nvm.NvmItem25_msg.data.TableStatusLimitsValid;
map_global.SystemFloorTable.TableStatus.SafetyValid               = DD.nvm.NvmItem25_msg.data.TableStatusSafetyValid;
map_global.SystemFloorTable.TableStatus.TopFloorNumber            = DD.nvm.NvmItem25_msg.data.TopFloorNumber;

map_global.SystemFloorTable.FormatVersion                         = DD.nvm.NvmItem25_msg.data.TableFormatVersion;

end


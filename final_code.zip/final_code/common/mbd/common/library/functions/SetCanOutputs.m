function SetCanOutputs(canMsgAlias)
% OECB: SetCanOutputs()
%

	if (coder.target('Sfun'))  % Simulink ----------------------------------

	% -- do nothing

	else  % embedded coder -------------------------------------------------
		coder.cinclude('Proc/SafetyProcess.h');
		coder.ceval('SafetyProcess_WriteCan', canMsgAlias);
	end

end

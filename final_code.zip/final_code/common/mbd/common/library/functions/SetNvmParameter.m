function SetNvmParameter(nvmParameterAlias)
% OECB: SetNvmParameter()
%

	if (coder.target('Sfun'))  % Simulink ----------------------------------

	% -- do nothing

	else  % embedded coder -------------------------------------------------
		coder.cinclude('GlueCodeProcess.h');
		coder.ceval('GlueCodeProcess_WriteNvm', nvmParameterAlias);
	end

end

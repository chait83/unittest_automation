function [ failed ] = CheckCrcCedesMsgX2Failed( msg ) %#codegen

    if (coder.target('Sfun'))  % Simulink ----------------------------------------
        failed = false;
    else % embedded coder -------------------------------------------------------
        coder.cinclude('Model/Support.h');
        ret = uint8(0);
        ret = coder.ceval('ModelSupport_CheckCrcCedesMsgX2Failed', ...
            uint8(msg.SeqCnt), uint8(msg.Error), int16(msg.Status), uint16(msg.CRC16) );
        failed = false;
        if (ret)
            failed = true;
        end
    end
end


function GetNvmParameterCond(cond, nvmParameterAlias)
% OECB: GetNvmParameter()
%

    if (coder.target('Sfun'))  % Simulink ----------------------------------

    % -- do nothing

    else  % embedded coder -------------------------------------------------
        coder.cinclude('GlueCodeProcess.h');
        if cond
            coder.ceval('GlueCodeProcess_ReadNvm', nvmParameterAlias);

            SetNvmParameterIfChanged(nvmParameterAlias)
        
        end
    end

end

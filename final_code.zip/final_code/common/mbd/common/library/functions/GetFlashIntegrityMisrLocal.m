function GetFlashIntegrityMisrLocal( )
    GetNvmParameter(NvmMsgAlias.NVMITEM220_MSGID_NvmId);
    GetNvmParameter(NvmMsgAlias.NVMITEM221_MSGID_NvmId);
    GetNvmParameter(NvmMsgAlias.NVMITEM222_MSGID_NvmId);
    GetNvmParameter(NvmMsgAlias.NVMITEM223_MSGID_NvmId);
    GetNvmParameter(NvmMsgAlias.NVMITEM224_MSGID_NvmId);
end


function ConsiderEventMatlabFunction(Event, State, StateOld, Parameter, EventClass)

    if (coder.target('Sfun'))  % Simulink ----------------------------------

        % -- do nothing

    else  % embedded coder -------------------------------------------------

        coder.cinclude('Event/Reporting.h');
        coder.ceval('EventReporting_ConsiderEvent', Event, State, StateOld, Parameter, EventClass);

    end

end
function [ CRC32 ] = CallCrc32SystemFloorTable( option,  data) %#codegen

    if (coder.target('Sfun'))  % Simulink ----------------------------------------
        % simple sum for simulation
        retCrc = uint32(data) + uint32(1);
    else % embedded coder -------------------------------------------------------
        coder.cinclude('Model/Support.h');
        retCrc = uint32(0);
        
        % invoke model support function
        retCrc = coder.ceval('ModelSupport_CalcCrc32', ...
            uint8(option), uint32(data));
    end

    CRC32 = retCrc;

end


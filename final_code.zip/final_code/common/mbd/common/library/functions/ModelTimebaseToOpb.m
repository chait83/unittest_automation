function opb = ModelTimebaseToOpb(model, opbOffset)

    if (coder.target('Sfun'))  % Simulink ----------------------------------------
        
        opb = uint16(uint16(model / 5) + opbOffset);
        
    else  % embedded coder -------------------------------------------------------
        
        coder.cinclude('Model/Support.h');
        %opb = coder.opaque('OpbTimestamp_T', 'HeaderFile', 'OpbTimestamp.h');
        opb = uint16(0);
        opb = coder.ceval('ModelSupport_ModelTimebaseToOpbTimestamp', uint32(model), uint16(opbOffset));
        
    end

end

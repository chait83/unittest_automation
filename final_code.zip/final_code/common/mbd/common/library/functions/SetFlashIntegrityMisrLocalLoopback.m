function SetFlashIntegrityMisrLocalLoopback( )
    SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM220_MSGID_NvmId);
    SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM221_MSGID_NvmId);
    SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM222_MSGID_NvmId);
    SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM223_MSGID_NvmId);
    SetNvmParameterIfChangedLoopback(NvmMsgAlias.NVMITEM224_MSGID_NvmId);
end


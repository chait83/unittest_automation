function Integrity(pattern)
% OECB: Integrity()
%

	if (coder.target('Sfun'))  % Simulink ----------------------------------

	% -- do nothing

	else  % embedded coder -------------------------------------------------
		coder.cinclude('Proc/SafetyProcess.h');
		coder.ceval( 'SafetyProcess_Integrity', uint32(pattern));
	end

end

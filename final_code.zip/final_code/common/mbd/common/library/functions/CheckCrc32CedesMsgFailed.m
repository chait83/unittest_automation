function [ failed ] = CheckCrc32CedesMsgFailed( msgXA, msgXB ) %#codegen

    ret = uint8(0);
    if (coder.target('Sfun'))  % Simulink ----------------------------------------
        failed = false;
    else % embedded coder -------------------------------------------------------
        coder.cinclude('Model/Support.h');
        ret = uint8(0);
        % note: The C function ModelSupport_CheckCrcCedesMsgCrc32Failed()
        %       expects ClipOffset to be a uint8.  But casting it via the MATLAB
        %       functions to uint8 results in all former negativ values to be 0.
        %       This results in false negative CRC checks.
        ret = coder.ceval('ModelSupport_CheckCrcCedesMsgCrc32Failed', ...
            uint8(msgXA.SeqCnt), uint32(msgXA.Position), int16(msgXA.Velocity), ...
            uint8(msgXA.ErrorWarn), uint8(msgXA.ClipAlign), ...
            uint32(msgXB.CounterpartPosition), int8(msgXB.ClipOffset), ...
            uint32(msgXB.Crc32));
        if (ret)
            failed = true;
        else
            failed = false;
        end
    end

end


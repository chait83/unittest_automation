function ret = GetGsmInput(msgAlias)
% CECB: GetGsmInput()
%

    if (coder.target('Sfun'))  % Simulink ----------------------------------

        ret = true;

    else  % embedded coder -------------------------------------------------

        coder.cinclude('Proc/SafetyProcess.h');
        ret = true;
        ret = coder.ceval('SafetyProcess_ReadScioptaMsg', msgAlias, false);

    end

end

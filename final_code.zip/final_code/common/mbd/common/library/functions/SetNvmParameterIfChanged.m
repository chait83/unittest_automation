function SetNvmParameterIfChanged(nvmParameterAlias)
% OECB: SetNvmParameterIfChanged()
%

	if (coder.target('Sfun'))  % Simulink ----------------------------------

	% -- do nothing

	else  % embedded coder -------------------------------------------------
		coder.cinclude('GlueCodeProcess.h');
		coder.ceval('GlueCodeProcess_WriteIfChangedNvm', nvmParameterAlias);
	end

end

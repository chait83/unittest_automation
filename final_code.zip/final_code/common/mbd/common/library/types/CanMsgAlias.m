classdef CanMsgAlias < Simulink.IntEnumType

    enumeration
        can_message_application_id_invalid        (0),
        CedesMsg11_msg_MSGID                      (1),
        CedesMsg12_msg_MSGID                      (2),
        CedesMsg21_msg_MSGID                      (3),
        CedesMsg22_msg_MSGID                      (4),
        PesCarPosition_msg_MSGID                  (5),
        PesFloorStatus_msg_MSGID                  (6),
        PesClipPosition_msg_MSGID                 (7),
        PesSafetyDetails1_msg_MSGID               (8),
        PesSafetyDetails2_msg_MSGID               (9),
        PesSafetyStatus_msg_MSGID                 (10),
        PesDbpStatus_msg_MSGID                    (11),
        PesFieldTestStatus_msg_MSGID              (12),
        SafCarCommand_msg_MSGID                   (13),
        SafCarInputs_msg_MSGID                    (14),
        SafCarStatus_msg_MSGID                    (15),
        SafPitCommand_msg_MSGID                   (16),
        SafPitInputs_msg_MSGID                    (17),
        SafSabCommand_msg_MSGID                   (18),
        SafSabStatus_msg_MSGID                    (19),
        SystemFloorTable_ByScon_msg_MSGID         (20),
        SystemFloorTable_ByDrive_msg_MSGID        (21),
        SystemFloorTable_ByOcss_msg_MSGID         (22),
        FloorTableRequest_ByScon_msg_MSGID        (23),
        FloorTableRequest_ByDrive_msg_MSGID       (24),
        FloorTableRequest_ByOcss_msg_MSGID        (25),
        DriveRequest2_msg_MSGID                   (26),
        PesAvAlarm_msg_MSGID                      (27),
        DriveFeatureStatus_msg_MSGID              (28),
        PesDbpRequest_msg_MSGID                   (29),
        PesFieldTestRequest_ByDrive_msg_MSGID     (30),
        PesFieldTestRequest_msg_MSGID             (31),
        CedesMsg1A_msg_MSGID                      (32),
        CedesMsg1B_msg_MSGID                      (33),
        CedesMsg2A_msg_MSGID                      (34),
        CedesMsg2B_msg_MSGID                      (35),
        PesCommand_msg_MSGID                      (36),
        PesTestRequest_msg_MSGID                  (37),
        SafCarEvent_msg_MSGID                     (38),
        SafPitEvent_msg_MSGID                     (39),
        SafSabEvent_msg_MSGID                     (40),
        PesRequestByOcss_msg_MSGID                (41),
        PesFeatureStatus_ByScon_msg_MSGID         (42),
        PesTimeLeftUntilTest_ByOcss_msg_MSGID     (43),
        PesTestPermission_msg_MSGID               (44),
        PesTimeLeftUntilTest_ByScon_msg_MSGID     (45),
        PesConfigBySpit_msg_MSGID                 (46),
        PesConfigByScar_msg_MSGID                 (47),
        PesConfigBySab_msg_MSGID                  (48),
        PesConfigByOcss_msg_MSGID                 (49),
        PesRequestByScar_msg_MSGID                (50),
        PesRequestBySconOnCarBus_msg_MSGID        (51),
        PesRequestBySconOnPitBus_msg_MSGID        (52),
        PesConfigBySconOnCarBus_msg_MSGID         (53),
        PesConfigBySconOnPitBus_msg_MSGID         (54),
        PesConfigByScon_msg_MSGID                 (55),
        PesRequestByDrive_msg_MSGID               (56),
        PesConfigRequest_msg_MSGID                (57),
        StartupByScon_msg_MSGID                   (58),
        StartupByScar_msg_MSGID                   (59),
        StartupBySpit_msg_MSGID                   (60),
        StartupBySab_msg_MSGID                    (61),
        SafPitSupervisionReport_msg_MSGID         (62),
        PesFeatureStatus_BySab_msg_MSGID          (63),
        PesNonSafetyRequestByScon_msg_MSGID       (64),
        PesNonSafetyResponseByOcss_msg_MSGID      (65)
    end

    methods (Static)
        function y = getDataScope()
            y = 'Exported';
        end
        function y = getHeaderFile()
            y = 'CanMsgAlias.h';
        end
    end

end


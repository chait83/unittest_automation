classdef GsmMsgAlias < Simulink.IntEnumType %#codegen

  % OS messages used in architecture
  
  % message definitions
    enumeration
        IdInvalid                                 (0),
        AdcReadTemp0Request_msg                   (1),
        AdcReadTemp0Reply_msg                     (2),
        CtrlShiftRegReadRequest_msg               (3),
        CtrlShiftRegRead2Reply_msg                (4),
        CarShiftRegRequest_msg                    (5),
        CarShiftRegRead2Reply_msg                 (6),
        PitShiftRegRequest_msg                    (7),
        PitShiftRegRead2Reply_msg                 (8),
        AdcReadTemp1Request_msg                   (9),
        AdcReadTemp1Reply_msg                     (10),
        UpdateEvent_msg                           (11),
        UpdateIntegrityErrorClass_msg             (12),
        HsmVerifySignatureExternalReply_msg       (13),
        HsmVerifySignatureExternalRequest_msg     (14),
        HsmStatus_msg                             (15)
    end

    % class methods
    methods (Static)
        function y = addClassNameToEnumNames()
            y = true;
        end
        function y = getDataScope()
            y = 'Exported';
        end
        function y = getHeaderFile()
            y = 'GsmMsgAlias.h';
        end
    end

end


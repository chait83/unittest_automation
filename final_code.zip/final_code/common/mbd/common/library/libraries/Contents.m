% BCL Toolbox
% Version 0.8 23-Dec-2016
%
% BCL Toolbox for model-based requirement formalization
%% Init Data

g = 9.81;
m = 1200; %kg, mass of the elevator

ESA_REPSONSE_TIME = 0.085; %ms
BRAKE_TIME = 0.150; %ms

Vrated = 1.5; %m/s
VOS = 1.1; %m/s, normed by Vrated

VratedReal = 1.75; %m/s

Vtrip = @(v) 1.25 .* v + 0.25./v;

atrip = @(v,vtrip) (vtrip - v)./ESA_REPSONSE_TIME;

atripOS = @(v,vos) (vos - v)./BRAKE_TIME;

g_ki = 0.001102;
g_kp = 0.561;

%%

sim_Elevator = sim('Elevator_Simulation','SimulationMode','normal');
dataRun = sim_Elevator.get('dataRun');


%%
s = dataRun(:,1);
v = dataRun(:,2) ./ Vrated;
a = dataRun(:,3) ./ g;

hold on;

title('Composite');
plot(v,a,'.')
xlabel('Velocity [m/s]/Vrated');
ylabel('Acceleration [g]');



axis([-2 2 -1.2 1.2]);
vline(-Vtrip(Vrated)./Vrated,'r-');
vline(Vtrip(Vrated)./Vrated,'r-');

vline(-VOS,'g-');
vline(VOS,'g-');

grid on;
% ESA Safety Trip Speed
vRange = -Vtrip(Vrated)/Vrated:0.1:Vtrip(Vrated)/Vrated;

% Parameter used by Farmington

m = -1.2008;
b = -2.7136;

atripFarm = @(v) b + m*v;

plot(vRange, atrip(vRange, -Vtrip(Vrated)/Vrated)./(g),'b--');

plot(vRange, atripFarm(vRange)./(g),'b.-');

% ESA OS Safety brake

vRange = -VOS:0.1:VOS;
plot(vRange, atripOS(vRange, -VOS)./(g),'b--');
plot(vRange, atripOS(vRange, VOS)./(g),'b--');


%% Load data from here: d:\Users\OEC_Farmington\Model33\DataFiles_Moved\Org - martins matlab rechner

path = 'd:\Users\OEC_Farmington\Model33\DataFiles_Moved\Org\';

%% Ascending + Bouncing (REAL DATA)

load([ path 'Acc_Bounce_Asc.mat']);
Acc_Bounce_Asc = a(2,:);

load([ path 'Vel_Bounce_Asc.mat']);
Vel_Bounce_Asc = v(2,:)./VratedReal;

plot(Vel_Bounce_Asc, Acc_Bounce_Asc);

%% Descending + Bouncing (REAL DATA)

load([ path 'Acc_Bounce_Dec.mat']);
Acc_Bounce_Dec = a(2,:);

load([ path 'Vel_Bounce_Dec.mat']);
Vel_Bounce_Dec = v(2,:)./VratedReal;

plot(Vel_Bounce_Dec, Acc_Bounce_Dec);

%% Descending + Estop (REAL DATA)

load([ path 'Acc_Estop_Dec.mat']);
Acc_Estop_Dec = a(2,:);

load([ path 'Vel_Estop_Dec.mat']);
Vel_Estop_Dec = v(2,:)./VratedReal;

plot(Vel_Estop_Dec, Acc_Estop_Dec);

%% Bouncing Stop (REAL DATA)

load([ path 'Acc_Bounce_Stop.mat']);
Acc_Bounce_Stop = a(2,:);

load([ path 'Vel_Bounce_Stop.mat']);
Vel_Bounce_Stop = v(2,:)./VratedReal;

plot(Vel_Bounce_Stop, Acc_Bounce_Stop);

%% Free fall (SIM DATA)

load([ path 'Acc_FreeFall_Full.mat']);
Acc_FreeFall_Full = a(2,:);

load([ path 'Vel_FreeFall_Full.mat']);
Vel_FreeFall_Full = v(2,:)./VratedReal;

plot(Vel_FreeFall_Full, Acc_FreeFall_Full);

%%

hold off;

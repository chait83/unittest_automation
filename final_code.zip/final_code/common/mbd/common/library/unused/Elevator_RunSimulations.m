%% Constants

run_ESA_RESPONSE_TIME = 0.085;

%% Load

clear all

load_system('Elevator_Simulation');

system = 'Elevator_Simulation';
clearvars run* 
run_choice_block = 'chose_mode';
run_vrated_block = 'cVrated';



run_arr_vrated = [1, 1.5, 1.75, 2, 2.5];
runNr = 0;
%% Simulation with FF detection by velocity only


for i=1:length(run_arr_vrated)
    
    run_vrated = run_arr_vrated(i);

    set_param([system '/' run_vrated_block], 'Value',num2str(run_vrated));
    
    % Simulation with FF detection by velocity only
    set_param([system '/' run_choice_block], 'Value', '1');

    a = sim('Elevator_Simulation','SimulationMode','normal');

    simElevator = a.get('simElevator');
    
    runNr = runNr + 1;
    Elevator_parseSimulationData;

    clearvars -except system choice_block run*

    % Simulation with FF detection by velocity and acceleration (OCEB Method)
    set_param([system '/' run_choice_block], 'Value', '3')

    a = sim('Elevator_Simulation','SimulationMode','normal');
    simElevator = a.get('simElevator');
    runNr = runNr + 1;
    
    Elevator_parseSimulationData;

    clearvars -except system choice_block evalTime run*
    
    % Simulation with FF detection by velocity and acceleration (OCEF Method)
    set_param([system '/' run_choice_block], 'Value', '6')

    a = sim('Elevator_Simulation','SimulationMode','normal');
    simElevator = a.get('simElevator');
    runNr = runNr + 1;
    
    Elevator_parseSimulationData;

    clearvars -except system choice_block evalTime run*
    
end



%%

for i=1:1:15
hold on;
stairs(run_res(:,end,1),run_res(:,1,i),'r'); 
pause
  
hold off; 
end
%%

hold on;
stairs(run_res(:,end,1),run_res(:,1,1),'r--');
stairs(run_res(:,end,1),run_res(:,1,2),'r-');
stairs(run_res(:,end,1),run_res(:,1,3),'r.');

stairs(run_res(:,end,1),run_res(:,3,1),'b--');
stairs(run_res(:,end,1),run_res(:,3,2),'b-');
stairs(run_res(:,end,1),run_res(:,3,3),'b.');

stairs(run_res(:,end,1),run_res(:,4,1),'k--');
stairs(run_res(:,end,1),run_res(:,4,2),'k-');
stairs(run_res(:,end,1),run_res(:,4,3),'k.');

stairs(run_res(:,end,1),run_res(:,8,1),'g--');
stairs(run_res(:,end,1),run_res(:,8,2),'g-');
stairs(run_res(:,end,1),run_res(:,8,3),'g.');
hold off;


%% Evaluate Data


res_table = [];

for i=1:1:size(run_res,3)/3
    i
    res_table(i,1) = min(run_res(:,1,i*3));
    res_table(1,2) = min(run_res(:,1,i*3+1));
    res_table(1,3) = min(run_res(:,1,i*3+2));
end

simVelRaw = simElevator.Data(:,1);
simAccRaw = simElevator.Data(:,2);
simAccFil = simElevator.Data(:,3);
simOutTripSafety = simElevator.Data(:,4);
simOutTripBreaks = simElevator.Data(:,5);

simOutTripDelayed = simElevator.Data(:,8);

evalTs = 1/200;

evalTime = 0:evalTs:length(simVelRaw)*evalTs-evalTs;

run_res(:,:,runNr) = [ simElevator.Data, evalTime'];

simVrated  = 1.75;

simVtrip = 1.25 + 0.25/simVrated^2;

%
evalB = -2.7136;
evalM = -1.2008;

evalG_ActuateSafetyVel = 1.25*simVrated + 0.25/simVrated;
evalACC_RA_LIMIT = -0.2;
evalBRAKE_TIME = 0.150;

evalESA_RESPONSE_TIME = 0.085;

evalESA_TIME = 0.085;
evalG_fp = 9.81;
evalVrated_fp = simVrated;

evalVCodeOS = -evalG_ActuateSafetyVel + .115*evalG_ActuateSafetyVel + (evalG_ActuateSafetyVel*3/100); % not in Vrated

evalVOS = @(Atest) ( max(-evalG_ActuateSafetyVel - (Atest * evalESA_TIME + max(evalACC_RA_LIMIT,Atest)*evalBRAKE_TIME) * evalG_fp, evalVCodeOS) ) / evalVrated_fp;


evalVSafety = @(Atest) ((Atest - evalB)* (1/evalM)) /  evalVrated_fp;
fs = 200;             %#sampling rate
f0 = 4;                %#notch frequency
fn = fs/2;              %#Nyquist frequency
freqRatio = f0/fn;      %#ratio of notch freq. to Nyquist freq.

notchWidth = 0.05;       %#width of the notch

%#Compute zeros
notchZeros = [exp( sqrt(-1)*pi*freqRatio ), exp( -sqrt(-1)*pi*freqRatio )];

%#Compute poles
notchPoles = (1-notchWidth) * notchZeros;
% 
figure;
zplane(notchZeros.', notchPoles.');

not_b = poly( notchZeros ); %# Get moving average filter coefficients
not_a = poly( notchPoles ); %# Get autoregressive filter coefficients


%%
figure;
freqz(not_b,not_a,32000,fs)
%%

x = ones(1,fs*10);
x(1:length(x)/2) = 0;


y = filter(not_b, not_a, x);
gain = y(end) / x(end);


hold on;
plot(y*1/gain);
plot(x);
hold off;
simVelRaw = simElevator.Data(:,1);
simAccRaw = simElevator.Data(:,2);
simAccFil = simElevator.Data(:,3);
simOutTripSafety = simElevator.Data(:,4);
simOutTripBreaks = simElevator.Data(:,5);

simVrated = simElevator.Data(end,10);

evalTs = 1/200;

evalTime = 0:evalTs:length(simVelRaw)*evalTs-evalTs;


simVtrip = 1.25 + 0.25/simVrated^2;

%
evalB = -2.7136;
evalM = -1.2008;

evalG_ActuateSafetyVel = 1.25*simVrated + 0.25/simVrated;
evalACC_RA_LIMIT = -0.2;
evalBRAKE_TIME = 0.150;

evalESA_RESPONSE_TIME = 0.085;

evalESA_TIME = 0.085;
evalG_fp = 9.81;
evalVrated_fp = simVrated;

evalVCodeOS = -evalG_ActuateSafetyVel + .115*evalG_ActuateSafetyVel + (evalG_ActuateSafetyVel*3/100); % not in Vrated

evalVOS = @(Atest) ( max(-evalG_ActuateSafetyVel - (Atest * evalESA_TIME + max(evalACC_RA_LIMIT,Atest)*evalBRAKE_TIME) * evalG_fp, evalVCodeOS) ) / evalVrated_fp;


evalVSafety = @(Atest) ((Atest - evalB)* (1/evalM));% /  evalVrated_fp;


evalVtrip = @(v) 1.25 .* v + 0.25./v;

%evalVSafetyOCEB = @(v,vrated) (evalVtrip(vrated) - v)./ESA_REPSONSE_TIME;

evalVSafetyOCEB = @(Atest, vrated) -evalVtrip(vrated) - evalESA_RESPONSE_TIME * Atest;

atripOS = @(v,vos) (vos - v)./BRAKE_TIME;

%%
figure

hold on;
plot(simVelRaw);
plot(evalVOS(simAccFil));
plot(evalVSafety(simAccFil));
plot(simOutTripBreaks);
plot(simOutTripSafety);
plot(simAccFil);
hline(-0.69);
%%
figure;
hold on;

accRange = -3:0.01:3;

%plot(simVelRaw, simAccRaw);

plot(simVelRaw, simAccFil);
%plot(evalVSafety(accRange)/simVrated, accRange);

plot(evalVSafetyOCEB(accRange*evalG_fp, simVrated)/simVrated, accRange);

plot(evalVOS(accRange),accRange);
vline(-simVtrip);
vline(evalVCodeOS / evalVrated_fp);

vline(-evalVCodeOS / evalVrated_fp);

vline(-1.11,'-r');
vline(1,'-r');


% Plot OCEB limits 

% Acceleration
hline(-0.69,'k--');
% Velocity
vline(-1.15,'k--');
vline(-1.20,'k-.');

%% Real data from TT1

fig = figure;
hold on;

title('Real data from TT2 : EStop by opening the safety chain');

stairs(evalTime, simVelRaw);
stairs(evalTime, simOutTripSafety);
stairs(evalTime, simAccRaw);
stairs(evalTime, simAccFil);
hline(-simVtrip);
hline(-0.69);

text( 30,-0.7, ['0.69g']);

text( 5,1.10, ['V=1.15 VRated']);
hline(1.15,'r--');
hline(1.20,'-r');


hline(-1.20,'r-');
hline(-1.15,'r--');
text( 5,-1.25, ['V=1.20 VRated']);

legend('Velocity','Trip Safeties','AccRaw','AccFiltered');

xlabel('Time [s]');
ylabel('V [Vrated], Acc [g]');
hold off;
%%
saveas(fig, ['RealData_EStop_by_Bouncing_1m_per_s_N_1.svg'])
close(fig);

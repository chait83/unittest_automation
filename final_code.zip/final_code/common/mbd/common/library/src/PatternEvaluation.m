classdef PatternEvaluation < Simulink.IntEnumType
  enumeration
    VIOLATED(0)
    NOT_VIOLATED(1)
%     PENDING(2) 
  end
end 
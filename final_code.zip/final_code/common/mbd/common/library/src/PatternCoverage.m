classdef PatternCoverage < Simulink.IntEnumType
  enumeration
    NOT_COVERED(0)
    COVERED(1)
  end
end 
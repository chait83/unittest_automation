function cts = getBlockCompiledSampleTime(blk)
    %%
    cts = -1;
    %% blk belongs to a library return
    if ~strcmpi(get_param(bdroot(blk), 'LibraryType'), 'none')
        return;
    end
    %% blk belongs to a model
    try
        cts = getCompiledSampleTime(blk);
    catch ME
        disp(ME.message);
        cts = -1;
    end
end

function ts = getCompiledSampleTime(blk)
    %%
    ts = -1;
    cts = get_param(blk, 'CompiledSampleTime');
    if isempty(cts)
        return;
    end
    ts = resolveCompiledSampleTime(cts);
%     if ts <= 0
%         ts = -1;
%     end
end

function ts = resolveCompiledSampleTime(cts)
    %%
    if ~iscell(cts)
        cts = {cts};
    end
    % slide cell and resolve potential sample time issues
    ts = zeros(size(cts));
    for i = 1:length(cts)
        ts(i) = cts{i}(1);
    end
    ts = unique(ts);
    idx_inf = isinf(ts);
    idx_minusone = ts == -1;
    ts(idx_inf | idx_minusone) = [];
    
    if length(ts) ~= 1 || ts <=0
        ts = -1;
    end
end
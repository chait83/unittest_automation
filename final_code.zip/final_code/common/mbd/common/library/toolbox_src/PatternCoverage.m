%% PatternCoverage (Enumeration)
%
%   PatternCoverage is an enumeration specifying the coverage status of a
%   pattern. It can be either:
%
%   - NOT_COVERED
%   - COVERED
%   

% Copyright (c) ALES S.r.l. This document/file and its contents are
% property of ALES S.r.l.. You may not possess, use, copy or disclose this
% document/file or any information in it, for any purpose, including
% without limitation, to design, manufacture or repair parts, or obtain any
% government approval to do so, without ALES S.r.l.'s express written
% permission. Neither receipt nor possession of this document/file alone,
% from any source, constitutes such permission. Possession, use, copying or
% disclosure by anyone without ALES S.r.l. express written permission is
% not authorized and may result in criminal and/or civil liability.
% 
% All rights reserved.
% This document or file contains no United States or EU controlled technical data.

classdef PatternCoverage < Simulink.IntEnumType
  enumeration
    NOT_COVERED(0)
    COVERED(1)
  end
end 
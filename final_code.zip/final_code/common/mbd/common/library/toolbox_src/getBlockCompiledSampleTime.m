%% cts = getBlockCompiledSampleTime(blk)
%
%   cts = getBlockCompiledSampleTime(blk) retrieves the sample time
%   associated with the given blk. Sample time is available if it has
%   been manually specified by the user or inherited by the block after the
%   model compilation. If the block belongs to a library, the sample time
%   is not available.
%   
%   blk: string specifying the system or block path name
%   cts: double specifying the block sample time. -1 means the value is not
%        available yet.

% Copyright (c) ALES S.r.l. This document/file and its contents are
% property of ALES S.r.l.. You may not possess, use, copy or disclose this
% document/file or any information in it, for any purpose, including
% without limitation, to design, manufacture or repair parts, or obtain any
% government approval to do so, without ALES S.r.l.'s express written
% permission. Neither receipt nor possession of this document/file alone,
% from any source, constitutes such permission. Possession, use, copying or
% disclosure by anyone without ALES S.r.l. express written permission is
% not authorized and may result in criminal and/or civil liability.
% 
% All rights reserved.
% This document or file contains no United States or EU controlled technical data.

function cts = getBlockCompiledSampleTime(blk)
    %%
    cts = -1;
    %% blk belongs to a library return
    if ~strcmpi(get_param(bdroot(blk), 'LibraryType'), 'none')
        return;
    end
    %% blk belongs to a model
    try
        cts = getCompiledSampleTime(blk);
    catch ME
        disp(ME.message);
        cts = -1;
    end
end

function ts = getCompiledSampleTime(blk)
    %%
    ts = -1;
    cts = get_param(blk, 'CompiledSampleTime');
    if isempty(cts)
        return;
    end
    ts = resolveCompiledSampleTime(cts);
%     if ts <= 0
%         ts = -1;
%     end
end

function ts = resolveCompiledSampleTime(cts)
    %%
    if ~iscell(cts)
        cts = {cts};
    end
    % slide cell and resolve potential sample time issues
    ts = zeros(size(cts));
    for i = 1:length(cts)
        ts(i) = cts{i}(1);
    end
    ts = unique(ts);
    idx_inf = isinf(ts);
    idx_minusone = ts == -1;
    ts(idx_inf | idx_minusone) = [];
    
    if length(ts) ~= 1 || ts <=0
        ts = -1;
    end
end
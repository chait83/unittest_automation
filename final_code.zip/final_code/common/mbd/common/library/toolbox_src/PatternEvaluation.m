%% PatternEvaluation (Enumeration)
%
%   PatternEvaluation is an enumeration specifying the status of a pattern
%   during the analysis. It can be either:
%
%   - VIOLATED
%   - NOT_VIOLATED
%   

% Copyright (c) ALES S.r.l. This document/file and its contents are
% property of ALES S.r.l.. You may not possess, use, copy or disclose this
% document/file or any information in it, for any purpose, including
% without limitation, to design, manufacture or repair parts, or obtain any
% government approval to do so, without ALES S.r.l.'s express written
% permission. Neither receipt nor possession of this document/file alone,
% from any source, constitutes such permission. Possession, use, copying or
% disclosure by anyone without ALES S.r.l. express written permission is
% not authorized and may result in criminal and/or civil liability.
% 
% All rights reserved.
% This document or file contains no United States or EU controlled technical data.

classdef PatternEvaluation < Simulink.IntEnumType
  enumeration
    VIOLATED(0)
    NOT_VIOLATED(1)
  end
end 
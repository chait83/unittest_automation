function VCodeTrip = fun_VCodeTripOCEF(acc,b,m)


    VSafety_OCEF = ((acc - b)* (1/m));
    VCodeTrip = VSafety_OCEF ;      % Normalized to contract speed

end
function VCodeTrip = fun_VCodeTripWithAcc(vrated, ESA_RESPONSE_TIME, g, Acc)

    VTrip = 1.25*vrated + 0.25/vrated;

    VCodeTrip  = -VTrip - ESA_RESPONSE_TIME * Acc*g;
 
end
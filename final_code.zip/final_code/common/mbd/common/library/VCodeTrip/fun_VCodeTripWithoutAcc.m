function VCodeTrip = fun_VCodeTripWithoutAcc(vrated, ESA_RESPONSE_TIME, g, v_err)

    VTrip = 1.25*vrated + 0.25/vrated;

    timeToTrippingSpeed = (VTrip - vrated*v_err) / g;

    timeFor130mm = -VTrip/g + sqrt( (VTrip/g)^2 + 2/g*0.130);

    % Allowed free fall time

    timeAllowedFreeFallTime = (timeToTrippingSpeed+timeFor130mm) - ESA_RESPONSE_TIME;

    VCodeTrip = (vrated*v_err + timeAllowedFreeFallTime*g);

end
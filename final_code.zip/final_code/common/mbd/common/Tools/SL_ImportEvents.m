% =======================================================================================
% Copyright 2022 OTIS GmbH & Co. OHG - OTIS Lead Design Center Berlin
% =======================================================================================
%
% Import PesEvt_Event_E enum from PesEvt.h header file into PessralEventDataDictionary
%
% 2017-06-21 M. Hnida

% Constants
headerFileName = 'sub\common\sub\subcommon\src\Event\PesEvt.h';
dataDictionaryName = 'sub\common\mbd\common\DataDictionary\PessralEventDataDictionary.sldd';
enumName = 'PesEvt_Event_E';

% Delete previous PesEvt_Event_E in Data Dictionary if already present
dictionaryObj = Simulink.data.dictionary.open(dataDictionaryName);
dataSectObj = dictionaryObj.getSection('Design Data');
if (dataSectObj.exist(enumName))
  enumObj = dataSectObj.getEntry(enumName);
  enumObj.deleteEntry();
end

% Import PesEvt_Event_E into Data Dictionary
importInfo = Simulink.importExternalCTypes(headerFileName, 'DataDictionary', dataDictionaryName);

% Print status of importing
importInfo

% Set PesEvt_Event_E's Header File properly with relative path in Data Dictionary 
dictionaryObj = Simulink.data.dictionary.open(dataDictionaryName);
dataSectObj = dictionaryObj.getSection('Design Data');
enumObj = dataSectObj.getEntry(enumName);
enumVal = enumObj.getValue();
enumVal.HeaderFile = 'Event/PesEvt.h';
enumObj.setValue(enumVal);
dictionaryObj.saveChanges();

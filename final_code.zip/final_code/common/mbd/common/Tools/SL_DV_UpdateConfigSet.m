function SL_DV_UpdateConfigSet(modelName, ddName, configName)
% Loads configSet from data dictionary and attaches configSet to model
    dictObj = Simulink.data.dictionary.open(ddName);
    dConfigObj = getSection(dictObj,'Configurations');
    configEntry = getEntry(dConfigObj, configName);
    newConfig = getValue(configEntry);
    attachConfigSet(modelName, newConfig);
    
    % set active configuration for MIL
    setActiveConfigSet(modelName, configName);

end


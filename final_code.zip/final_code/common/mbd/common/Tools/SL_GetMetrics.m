% Get Simulink Metrics
%
% Prerequisite:
%   - The project needs to opened before calling SL_GetMetrics, e.g. by double clicking SCON.prj
%
% Call
%   SL_GetMetrics(model, csvFileName)
%
% Example call
%   SL_GetMetrics('CtrlSafetyFunction', 'SimulinkMetrics.csv')
%
% If SL_GetMetrics is called again for the same model, the metricEngine of the previous call
% is reused to save time. If reusing is not intended, metricEngine should be deleted before
% running SL_GetMetrics again by typing
%   clear metricEngine
% at the MATLAB command prompt


function SL_GetMetrics(model, csvFileName)

    % Metrics to be written to the CSV file
    % Available metrics may be obtained by typing the following at the MATLAB command prompt
    %   slmetric.metric.getAvailableMetrics()
    metrics = { ...
        'mathworks.metrics.CyclomaticComplexity', ...
        'mathworks.metrics.SimulinkBlockCount', ...
        'mathworks.metrics.SubSystemCount', ...
        'mathworks.metrics.StateflowChartCount'};

    reuseMetricEngine = true;
    
    % Reuse metricEngine if it is present in the workspace (import from workspace)
    try
        metricEngine = evalin('base', 'metricEngine');
    catch exception
        if strcmp(exception.identifier, 'MATLAB:UndefinedFunction') == 1
            reuseMetricEngine = false;
        end 
    end
    
    if reuseMetricEngine
        try
            metricEngineModel = evalin('base', 'metricEngineModel');
        catch exception
            if strcmp(exception.identifier, 'MATLAB:UndefinedFunction') == 1
                reuseMetricEngine = false;
            end
        end
    end
        
        
    if    reuseMetricEngine ...
       && (strcmp(metricEngineModel, model) == 1)
        % Reusing metricEngine of a previous call
        fprintf("Reusing metrics data of a previous call for model %s\n", metricEngineModel);
        fprintf("If reusing is not intended, metricEngine should be deleted before running SL_GetMetrics again by typing\n");
        fprintf("  clear metricEngine\n");
        fprintf("at the MATLAB command prompt\n");
    else
        % metricEngine has not been created yet
        metricEngine = slmetric.Engine();
        metricEngineModel = model;
        setAnalysisRoot(metricEngine, 'Root', metricEngineModel, 'RootType', 'Model');
        tic; % Start stopwatch
        % Determine all available metrics
        fprintf("Determine all available metrics for %s\n", metricEngineModel);
        execute(metricEngine);
        toc; % Stop stopwtach
    end

    % Get subset of metrics to be written to CSV file
    resultCollection = getMetrics(metricEngine, metrics);

    % Headline of CSV file
    metricData = {'MetricID', 'ComponentPath', 'Value'};

    cnt = 2;
    for metricIndex = 1 : length(resultCollection)
        % disp(['metricIndex = ', num2str(metricIndex)]);
        % fprintf('metricIndex = %u\n', metricIndex);

        resultCollection(metricIndex);

        if resultCollection(metricIndex).Status == 0
            % Result was collected successfully
            results = resultCollection(metricIndex).Results;

            % results

            for m = 1 : length(results)
                % disp(['m = ', num2str(m)]);
                % disp(['MetricID: ',results(m).MetricID]);
                % disp(['  ComponentPath: ',results(m).ComponentPath]);
                % disp(['  Value: ',num2str(results(m).Value)]);
                metricData{cnt, 1} = results(m).MetricID;
                metricData{cnt, 2} = results(m).ComponentPath;
                metricData{cnt, 3} = results(m).Value;
                cnt = cnt + 1;
            end
        else
            % Failed to collect result
            disp(['*** Error - No results for ', resultCollection(metricIndex).MetricID]);
            return
        end
    end


    fprintf('Write the following metrics to CSV file %s\n', csvFileName);
    % disp(metrics);
    fprintf("  %s\n", metrics{:});
    
    % Write metrics to CSV file
    file = fopen(csvFileName, 'wt');
    
    % Headline
    row = 1;
    fprintf(file, '%s;%s;%s\n', metricData{row, 1}, metricData{row, 2}, metricData{row, 3});
    
    % Contents
    for row = 2 : length(metricData)
        % disp([metricData{row, 1}, ';', metricData{row, 2}, ';', num2str(metricData{row, 3})]);
        fprintf(file, '%s;%s;%s\n', extractAfter(metricData{row, 1}, 'mathworks.metrics.'), metricData{row, 2}, num2str(metricData{row, 3}));
    end
    fclose(file);
    
    % Save metricEngine and metricEngineModel in the workspace to be reused in the next call (export to workspace)
    assignin('base', 'metricEngine', metricEngine);
    assignin('base', 'metricEngineModel', metricEngineModel);

end


function repl_block_names = SL_DV_GetReplacementBlockList()
% Create list of replacement block names
%   Reads replacement blocks out of sys_BlkRepl_lib library and creates list
%   of replacement block functions in DVAnalysisSupport. It then creates
%   a replacement block list from entries that exist in both the library 
%   and directory of replacement block functions
% return values
%   repl_block_names - returns string list of replacement functions to be 
%                      used for setting sldvoptions BlockReplacementRulesList 
%                      setting. 

load_system('sys_BlkRepl_lib');

% Find all toplevel replecement blocks in library
sys_cells = find_system('sys_BlkRepl_lib','SearchDepth','1','Type','Block');

% list all sys repl blocks from analysis directory
analysisSupportPath = strcat(what('DVAnalysisSupport').path, filesep);
blkFuncNames = dir(strcat(analysisSupportPath, '*sys_BlkRepl_*.m'));

% Create array of block names from directory
dir_block_names = string(length(blkFuncNames));
for j=1:length(blkFuncNames)
    % generate current block name to match function name needed by DV
    formatted_block_name = strrep(blkFuncNames(j).name, '.m', '');
    % Add pre-formatted block name for comparision with cell array
    dir_block_names(j) = formatted_block_name;
end

% Setup map for comparision with cell data
indices = 1:length(dir_block_names);
block_name_map = containers.Map(dir_block_names, indices);

% Loop through cell array of names and convert to comma seperated
% string needed by DV
repl_block_names = '';
for k=1:length(sys_cells)
    % generate current block name to match function name needed by DV
    current_block_name = strrep(sys_cells{k},'_lib/','_');
    
    % lookup current block name in comparison map
    if isKey(block_name_map, current_block_name)
        % concatenate each new block name onto string
        if isempty(repl_block_names)
            repl_block_names = current_block_name;
        else
            repl_block_names = repl_block_names + "," + current_block_name;
        end
    end
end
end



% M. Wilke @ CECB April 2017
% Simulink: Open all models starting from the root model and write them to
% an excel file.
% Inputs:
%          rootModel  = Highest model as a starting point in the model hierarchy (e.g. 'Behavior'), w/o SLX extension.
%          filename   = Name of excel file with XLSX extension (e.g. 'Behavior.XLSX')
function SL_WriteXlsxAll(rootModel, filename)
  tic;  % start stop watch
  % some parameter checks
  assert(nargin == 2, 'The number of parameters must be 2, not %d.',nargin);
  assert(isa(rootModel,'char'),'Parameter <rootModel> is from type %s, not char!', class(rootModel));
  assert(isa(filename,'char'),'Parameter <filename> is from type %s, not char!', class(filename));

  % load root model w/o GUI
  load_system(rootModel);
  
  % get all models
  [myModels,~] = find_mdlrefs(rootModel,'AllLevels',true,'Variants','AllVariants','IncludeCommented','on','IncludeProtectedModels',true);
  %blocks = find_system(rootModel,'FollowLinks','on','LookUnderMasks','on','LinkStatus','resolved');
  close_system(rootModel);
  
  % write excel file
  xlswrite(filename, myModels);
  %xlswrite(filename, blocks);
  toc;  % terminate stop watch
end

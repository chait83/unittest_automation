function CodeGenfRebuild ( model_name )
%CODEGENREBUILD clear generated files and rebuildall

    tic;
    ales.codegeneration.cleanup(model_name)
    ales.codegeneration.generate_model_code(model_name)
    % enable_io_map_check is used by generate_glue_code()
    enable_io_map_check = true;
    % true as a second parameter enforces to check all in- and outputs
    ales.codegeneration.generate_glue_code(model_name, true)
    toc;
    datetime('now')

end

function CodeGenFInit ( model_name )
%CODEGENFINIT adapt model as an incremental model and generate code for it

    tic;
    ales.codegeneration.cleanup(model_name)
    ales.codegeneration.persist_codegen_config(model_name)
    ales.codegeneration.generate_model_code(model_name)
    % enable_io_map_check is used by generate_glue_code()
    enable_io_map_check = true;
    % true as a second parameter enforces to check all in- and outputs
    ales.codegeneration.generate_glue_code(model_name, true)
    toc;
    datetime('now')

end


function CodeGenFIncremental ( model_name )
%CODEGENFINCREMENTAL don't clear generated files, only build of changed files

    tic;
    ales.codegeneration.generate_model_code(model_name)
    enable_io_map_check = true;
    % false as a second paramter disables full checks for in- and outputs
    ales.codegeneration.generate_glue_code(model_name, false)
    toc;
    datetime('now')

end



function [result] = SL_DV_Back2Back_CompareResult(milSimOut,silSimOut,numScenerios)
%SL_DV_Back2Back_CompareResult Verifies simulation results from Back2Back
%tests.

%% Compare MIL & SIL simulation outputs
    result = 1;
    for sceneNum = numScenerios:-1:1
        % Get the results for current scenerio
        localMilSimOut = milSimOut(:,sceneNum);
        localSilSimOut = silSimOut(:,sceneNum);
        
        % Get the number of outputs for the current test
        elementCount = localMilSimOut.yout.numElements;
        
        for elementNum = 1:1:elementCount
            % Get results for the current output result
            milData = localMilSimOut.yout.getElement(elementNum).Values.Data;
            silData = localSilSimOut.yout.getElement(elementNum).Values.Data;
            
            [itemCount, ~] = size(milData);
            
            for itemNum = 1:1:itemCount
            
                % compare the output for current item using a tolerance
                compData = ismembertol(double(milData(itemNum)), double(silData(itemNum)), eps);

                % ensure all data matched, result = 1 success, otherwise 0
                result = all(compData);

                % if any result was a mismatch, return failure for test
                if result == 0
                    return;
                end
            end
        end
    end
end


function [status, text] = SL_DV_IsCompatible(testHarness, designModel )
% Test DesignVerifier compatibility of test harness and design model
% parameters
%   testHarness - indentifies the test harness which should be checked, 
%                 which is assumed to be part of the project
%   designModel - indentifies the referenced design model within the test 
%                 harness
% return values
%   status - returns 0 on success, 
%                    1 designModel update error,
%                    2 testHarness update error,
%                    3 designModel DV incompatibility
%                    4 testHarness DV incompatibility
%   text   - error message returned by function or execeptions.

status = 1;

%% Modify the path for DV Analysis
% Otherwise, the replacement functions are not found. 
% Can not be part of the project, because the replacement functions would
% shadow the original functions used by embedded coder
savedpath = path;
newpath = fullfile(fileparts(mfilename('fullpath')), '..\DVAnalysisSupport\functions_repl');
path(newpath, path)

%% Exeute analysis

try
    load_system(designModel);
    status = 1;
    set_param(designModel, 'SimulationCommand', 'Update');
    
    load_system(testHarness);
    status = 2;
    set_param(testHarness, 'SimulationCommand', 'Update');

    diaryFilename = [tempname,'.txt'];

    diary(diaryFilename);
    diary on;

    % Test DV compatibility if DV license available
    if (license('test','Simulink_Design_Verifier'))
        
        noError = 1;
        
        %% Configure the analysis
        opts_design = sldvoptions(designModel);
                
        % configure block replacement, replacement block list is generated
        % in SL_DV_GetReplacementBlockList()
        opts_design.BlockReplacement = 'on';
        opts_design.BlockReplacementRulesList = SL_DV_GetReplacementBlockList();
        opts_design.BlockReplacementModelFileName = '$ModelName$_pp_replace';
        
        retVal = sldvcompat(designModel,opts_design,false,'');
        if( retVal ~= 1)
            status = 3;
            noError = 0;
        end

        %% Configure the analysis
        opts_harness = sldvoptions(testHarness);
                
        % configure block replacement, replacement block list is generated
        % in SL_DV_GetReplacementBlockList()
        opts_harness.BlockReplacement = 'on';
        opts_harness.BlockReplacementRulesList = SL_DV_GetReplacementBlockList();
        opts_harness.BlockReplacementModelFileName = '$ModelName$_pp_replace';

        if (noError == 1)
            retVal = sldvcompat(testHarness,opts_harness,false,'');
            if(retVal ~= 1)
                status = 4;
                noError = 0;
            end
        end
        
        if(noError == 1)
            status = 0;
        end
    end
    
    close_system(designModel);
    close_system(testHarness);
    
    diary off;
    text = fileread(diaryFilename);
    delete(diaryFilename);


catch ME
    text = ME.message;
end

%% Restore the original path 
path(savedpath);

end


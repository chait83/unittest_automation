function [status, text, coverage] = SL_DV_CheckCoverage(testModel, testHarness, saveReports, artifactPath, prefix, postfix)
% Use DesignVerifier to check test coverage on testHarness
% parameters
%   testHarness - Test harness to check coverage
%   saveReports - true to save report file, otherwise false
%   reportPath  - path to save report file, if saveReports is true
%                 (optional)
%   prefix      - prefix for report name (optional)
%   postfix     - postfix for report name (optional)
% return values
%   status   - returns 0 on success, 1 on error and 2 on test timeout.
%   text     - error message returned by function, diagnostics or execeptions.
%   coverage - test coverage percentage

status = 1;
coverage = 0;

% construct report file name
reportFileName = '$ModelName$';

% add prefix to report name if available
if exist('prefix','var')
    reportFileName= strcat(prefix, reportFileName);
end

% add postfix to report name if available
if exist('postfix','var')
    reportFileName = strcat(reportFileName, postfix);
end

% construct complete report path
if exist('reportPath','var')
    reportFileName = strcat(artifactPath, reportFileName);
end

try
    testHarnessPath = strcat(artifactPath,testHarness,'.slx');
    
    % delete previously generated test harness
    if exist(testHarnessPath, 'file') > 0
        delete(testHarnessPath);
    end
    % enable diagnostic window logging for error reporting
    diagFilename = [tempname, '.txt'];
    sldiagviewer.diary(diagFilename);
    sldiagviewer.diary('on');

    % enable stderr diary in case diagnostics report nothing.
    diaryFilename = [tempname,'.txt'];
    diary(diaryFilename);
    diary on;
            
    % load the test harness into memory
    load_system(testModel);
    
    %% Configure the analysis
    opts = sldvoptions(testModel);
    
    % configure coverage and setup output directory
    opts.Mode = 'TestGeneration';
    opts.ModelCoverageObjectives = 'ConditionDecision';
    opts.TestSuiteOptimization = 'Auto'; % use both long and short tests
    opts.TestConditions = 'EnableAll';
    opts.TestObjectives = 'EnableAll';
    %opts.SaveHarnessModel = 'off'; 
    opts.SaveHarnessModel = 'on';
    opts.HarnessSource = 'Signal Editor';
    opts.HarnessModelFileName = '$ModelName$_harness';
    opts.OutputDir = 'sldv_output/$ModelName$/checkcoverage';
    opts.MakeOutputFilesUnique = 'off';
    
    % configure block replacement, replacement block list is generated
    % in SL_DV_GetReplacementBlockList()
    opts.BlockReplacement = 'on';
    opts.BlockReplacementRulesList = SL_DV_GetReplacementBlockList();
    opts.BlockReplacementModelFileName = '$ModelName$_pp_replace';
    
    % configure parameter replacement. 
    opts.Parameters = 'on';
    opts.ParametersConfigFileName = 'sub/common/mbd/common/DVAnalysisSupport/sldv_params_whiteboxbehavior.m';
    
    opts.MaxProcessTime = 43200; % 12 hours;

    % configure reports if enabled
    if (saveReports == 1)
        opts.ReportFileName = reportFileName;
        opts.ReportPDFFormat = 'on';
        opts.SaveReport = 'on';
        opts.DisplayReport = 'off';
    else
        opts.SaveReport = 'off';
    end
    
    %% Run the analysis
    [retVal, files] = sldvrun(testModel, opts, true);

    % update status based on sldvrun value
    switch retVal 
        case -1
            status = 2;  % timeout
        case 0
            status = 1;  % error
        case 1
            status = 0;  % success
    end
    
    % read and cleanup diagnostic logging
    sldiagviewer.diary('off');
    text = fileread(diagFilename);
    delete(diagFilename);
    
    % cleanup stderr logging and read if no
    % errors from diagnostics
    diary off;
    if isempty(text)
        text = fileread(diaryFilename);
    end
    delete(diaryFilename);
    
    % load the test results
    test_data = open(files.DataFile);
    
    % get the total objectives tested
    total_count = length(test_data.sldvData.Objectives);
    % get the status of each of the test objectives
    statuses = {test_data.sldvData.Objectives.status};
    % get the objectives that were successfully satisfied
    satisfied_status = find(ismember(statuses, 'Satisfied'));
    satisfied_count = length(satisfied_status);
    % coverage is the satisfied objectives over the total objectives
    coverage = (satisfied_count/total_count) * 100;
    
    close_system(testModel);
    
catch ME
    % Handle exceptions, in case of exception diary text is not useful.
    % use error message from exception.
    text = ME.message;
end

%% Restore the data dictionary (discard tunable parameter changes)
%  only if the analysis was able to be started - otherwise we may
%  discard important changes to the DD
if (status ~= 0)

    DD_names = ['PessralFunctionalModelDataDictionary.sldd', ... 
                'PessralPesDataDictionary.sldd', ... 
                'SabDataDictionary.sldd'];

    % discard any changes to data dictionary
    for i=1:length(DD_names)
        DD_name = DD_names(i);

        if isfile(DD_name)
            DD = Simulink.data.dictionary.open(DD_name);
            discardChanges(DD);  
            DD.close();
        end        
    end
end

end


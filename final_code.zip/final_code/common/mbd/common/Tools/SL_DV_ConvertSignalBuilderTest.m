function result = SL_DV_ConvertSignalBuilderTest(harness, mat_file_name)
% Convert data types in test harness to be compatible with code generation
% first converts signal builder block to signal editor block
%   testHarness - Test harness input to be updated
    result = 0;
    
    % open the test harness
    if bdIsLoaded(harness) == 0
        open(harness);
    end
    
    % get handle to type conversion block
    simBlockH = get_param(strcat(harness,'/Size-Type'), 'Handle');
    % get handles to actual data type converstion blocks
    handles = find_system(simBlockH, 'LookUnderMasks', 'on', 'FollowLinks', 'on', 'SearchDepth', '1', 'BlockType', 'DataTypeConversion');
    % get the output types for each of the conversion block
    dataTypeNames = cellstr(get_param(handles, 'OutDataTypeStr'));

    % get handle to signal builder block
    sbBlockH = get_param(strcat(harness, '/Inputs'), 'Handle');
    % convert signal builder block to signal editor
    seBlockH = signalBuilderToSignalEditor(sbBlockH, 'Replace', true, 'Filename', mat_file_name);

    % get the number of scenarios
    num_scenarios = str2double(get_param(seBlockH,'NumberOfScenarios'));
    % get the number of signals
    num_signals = str2double(get_param(seBlockH,'NumberOfSignals'));

    % get the fixed step size for updating the converted signals
    fixed_step_time = get_param(harness, 'FixedStep');
    % loop through each signal in each scenario
    for scene_num = 1:num_scenarios
        set_param(seBlockH, 'ActiveScenario', scene_num);
        for sig_num = 1:num_signals
            set_param(seBlockH, 'ActiveSignal', sig_num);
            % update the interpolation and sample time for signals for 
            % compatibility with SIL and fixed point
            set_param(seBlockH, 'SampleTime', fixed_step_time);
            set_param(seBlockH, 'Interpolate', 'off');
            set_param(seBlockH, 'OutputAfterFinalValue', 'Holding final value');
        end
    end
    % update for compatibility with SIL
    set_param(harness, 'SupportAbsoluteTime', 'on');

    % open the underlying signals
    converted_test_case = open(mat_file_name);

    % parse the data type information
    exp='[^()]*';

    % get the field names of the test case struct
    field_names = fieldnames(converted_test_case);
    % loop through signals and convert to corrected data types
    for data_index = 1:num_signals
        type_name = dataTypeNames{data_index};
        type_info = regexp(type_name, exp, 'match');
        % parse datatype information
        [~, type_info_size] = size(type_info);
        if type_info_size == 2
            % process fixed point datatype
            num_type = numerictype(strrep(type_info{2},'''',''));
        else
            % process all other datatypes
            num_type = numerictype(type_info{1});
        end

        % loop through the scenarios and update the current signal in each
        for field_index = 1:num_scenarios
            field = converted_test_case.(field_names{field_index});
            % update datatype
            field{data_index}.Data = fi(field{data_index}.Data, num_type);
            % update interpolation for compatibility with fixed point
            field{data_index}.DataInfo.Interpolation = 'zoh';
            % 
            converted_test_case.(field_names{field_index}) = field;
        end
    end


    save(mat_file_name, '-struct', 'converted_test_case');
end
function result = SL_DV_ConvertSignalEditorTest(harness)
% Convert data types in test harness to be compatible with code generation
%   testHarness - Test harness input to be updated
    result = 0;
    
    % open the test harness
    if bdIsLoaded(harness) == 0
        open(harness);
    end
    
    % get handle to signal builder block
    seBlockH = get_param(strcat(harness, '/Inputs'), 'Handle');

    % get the number of scenarios
    num_scenarios = str2double(get_param(seBlockH,'NumberOfScenarios'));
    % get the number of signals
    num_signals = str2double(get_param(seBlockH,'NumberOfSignals'));

    % get the fixed step size for updating the converted signals
    fixed_step_time = get_param(harness, 'FixedStep');
    
    % loop through each signal in each scenario
    for scene_num = 1:num_scenarios
        set_param(seBlockH, 'ActiveScenario', scene_num);
        for sig_num = 1:num_signals
            set_param(seBlockH, 'ActiveSignal', sig_num);
            % update the interpolation and sample time for signals for 
            % compatibility with SIL and fixed point
            set_param(seBlockH, 'SampleTime', fixed_step_time);
            set_param(seBlockH, 'Interpolate', 'off');
            set_param(seBlockH, 'OutputAfterFinalValue', 'Holding final value');
        end
    end
    
    % update for compatibility with SIL
    set_param(harness, 'SupportAbsoluteTime', 'on');
end
function [status, text] = SL_DV_ExecutePropertyProving(testHarness, mode, provingStrategy, maxViolationSteps, saveReports, reportPath, prefix, postfix)
% Use DesignVerifier to prove properties on testHarness
% parameters
%   testHarness - Test harness to run property proving
%   mode              - 'PropertyProving', 'TestGeneration'
%   provingStrategy   - 'Prove', 'FindViolation', 'ProveWithViolationDetection'
%   maxViolationSteps - number of steps to analyze for modes 'FindViolation' and 'ProveWithViolationDetection', otherwise 0
%   saveReports       - true to save report file, otherwise false
%   reportPath        - path to save report file, if saveReports is true
%                      (optional)
%   prefix            - prefix for report name (optional)
%   postfix           - postfix for report name (optional)
% return values
%   status - returns 0 on success, 1 on error and 2 on test timeout.
%   text   - error message returned by function, diagnostics or execeptions.
status = 1;

% construct report file name
reportFileName = '$ModelName$';

% add prefix to report name if available
if exist('prefix','var')
    reportFileName= strcat(prefix, reportFileName);
end

% add postfix to report name if available
if exist('postfix','var')
    reportFileName = strcat(reportFileName, postfix);
end

% construct complete report path
if exist('reportPath','var')
    reportFileName = strcat(reportPath, reportFileName);
end

%% Modify the path for DV Analysis
% Otherwise, the replacement functions are not found. 
% Can not be part of the project, because the replacement functions would
% shadow the original functions used by embedded coder
savedpath = path;
newpath = fullfile(fileparts(mfilename('fullpath')), '..\DVAnalysisSupport\functions_repl');
path(newpath, path)

%% Exeute analysis

try
    % enable diagnostic window logging for error reporting
    diagFilename = [tempname, '.txt'];
    sldiagviewer.diary(diagFilename);
    sldiagviewer.diary('on');

    % enable stderr diary in case diagnostics report nothing.
    diaryFilename = [tempname,'.txt'];
    diary(diaryFilename);
    diary on;
            
    % load the test harness into memory
    load_system(testHarness);
    
    %% Configure the analysis
    opts = sldvoptions(testHarness);
    
    % configure property proving and setup output directory
    opts.Mode = mode;
    opts.ProvingStrategy = provingStrategy;
    opts.MaxViolationSteps = maxViolationSteps;
    opts.OutputDir = 'sldv_output/$ModelName$/propertyproving';
    
    % configure block replacement, replacement block list is generated
    % in SL_DV_GetReplacementBlockList()
    opts.BlockReplacement = 'on';
    opts.BlockReplacementRulesList = SL_DV_GetReplacementBlockList();
    opts.BlockReplacementModelFileName = '$ModelName$_pp_replace';
    opts.MaxProcessTime = 43200; % 12 hours;
    
    % configure reports if enabled
    if (saveReports == 1)
        opts.ReportFileName = reportFileName;
        opts.ReportPDFFormat = 'on';
        opts.SaveReport = 'on';
        opts.DisplayReport = 'off';
    else
        opts.SaveReport = 'off';
    end
    
    %% Run the analysis
    retVal = sldvrun(testHarness, opts, true);

    % update status based on sldvrun value
    switch retVal 
        case -1
            status = 2;  % timeout
        case 0
            status = 1;  % error
        case 1
            status = 0;  % success
    end
    
    % read and cleanup diagnostic logging
    sldiagviewer.diary('off');
    text = fileread(diagFilename);
    delete(diagFilename);
    
    % cleanup stderr logging and read if no
    % errors from diagnostics
    diary off;
    if isempty(text)
        text = fileread(diaryFilename);
    end
    delete(diaryFilename);
    
    close_system(testHarness);
    
catch ME
    % Handle exceptions, in case of exception diary text is not useful.
    % use error message from exception.
    text = ME.message;
end

%% Restore the data dictionary (discard tunable parameter changes)
%  only if the analysis was able to be started - otherwise we may
%  discard important changes to the DD
if (status ~= 0)

    DD_names = ['PessralFunctionalModelDataDictionary.sldd', ... 
                'PessralPesDataDictionary.sldd', ... 
                'SabDataDictionary.sldd'];

    % discard any changes to data dictionary
    for i=1:length(DD_names)
        DD_name = DD_names(i);

        if isfile(DD_name)
            DD = Simulink.data.dictionary.open(DD_name);
            discardChanges(DD);  
            DD.close();
        end        
    end
end

%% Restore the original path 
path(savedpath);

end


function CodeGenFGlueCode ( model_name )
%CODEGENFGLUECODE only generate glue code

    tic;
    % enable_io_map_check is used by generate_glue_code()
    enable_io_map_check = true;
    % true as a second parameter enforces to check all in- and outputs
    ales.codegeneration.generate_glue_code(model_name, true)
    toc;
    datetime('now')

end


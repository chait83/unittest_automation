function SL_BuildModel(ModelName)

    tic
    Simulink.fileGenControl('reset');

    % Change CacheFolder and CodeGenFolder
    buildFolder = [ModelName,'Build'];
    Simulink.fileGenControl('set', ...
                            'CacheFolder', buildFolder, ...
                            'CodeGenFolder', buildFolder, ...
                            'keepPreviousPath', true, 'createDir', true);

    % Get the current configuration
    cfg = Simulink.fileGenControl('getConfig');

    % Show current working directory
    pwd

    rtwbuild(ModelName);

    Simulink.fileGenControl('reset');
    
    timeSpent = toc;
    timeSpentStr = sprintf('\n\tDone in %9.3f s', timeSpent);
    disp(timeSpentStr);

end


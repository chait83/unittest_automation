function [report] = SL_DV_Reporting(testType,fileName,information)
%% this function will provide human redable output from running the SL_DV_MILCoverage nad SL_DV_Back2Back

    switch nargin
        case 0
            report = {'Insufficient Input arguments'};
        case 1
            report = {'Insufficient Input arguments'};
        case 2
            report = {'Insufficient Input arguments'};
        case 3
            if(strcmp(testType,'Back2Back'))
                MILSIL_status = information;
                if (MILSIL_status == 1)
                    testStatus = 'Test Status: MIL/SIL comparison produced identical results';
                else
                    testStatus = 'Test Status: MIL/SIL comparison did not produce identical results';
                end
                report = {'Test Type: SIL MIL Back to Back comparison';strcat('Test File: ',fileName);testStatus};
            elseif(strcmp(testType,'Coverage'))
                report = [{'Test Type: MIL Coverage';strcat('Test File: ',fileName)}' information']';
            end                            
        otherwise
            report = {'Unexpected Input arguments to the reporting function'};
    end
    
end  
% M. Wilke @ CECB January 2019
% Simulink: Search for Stateflow object in Stateflow charts in all model references starting at the root level.
% Inputs:
%          rootModel  = Highest model as a starting point in the model hierarchy (e.g. 'Behavior'), w/o SLX extension.
%          object     = Stateflow object, e.g. 'Stateflow.State'
function SL_CheckChartObject(rootModel, object)
  tic;  % start stop watch
  % some parameter checks
  assert(nargin == 2, 'The number of parameters must be 2, not %d.',nargin);
  assert(isa(rootModel,'char'),'Parameter <rootModel> is from type %s, not char!', class(rootModel));
  assert(isa(object,'char'),'Parameter <object> is from type %s, not char!', class(object));

  % load root model w/o GUI
  load_system(rootModel);
  
  % get all models
  [myModels,~] = find_mdlrefs(rootModel,'AllLevels',true,'Variants','AllVariants');
  close_system(rootModel);
  
  % loop trough all model files
  s = size(myModels);
  for i = 1:s(1) % for all models
    model = myModels(i);
    fprintf("[%s]:\n", model{i});
    load_system(model);
    rt = sfroot;
    m = rt.find('-isa','Stateflow.State');
    s1 = size(m);
    for k = 1:s1(1) % for all States    
      if ~isempty(m)
        ch = find(m(k), '-isa','Stateflow.State');
        if ~isempty(ch)
          s2 = size(ch);
          for j = 1:s2(1) % for all sub charts                   
            fprintf("Chart: %s - State: %s\n", ch(j).Path, ch(j).Name);
          end
        end              
      end    
    end
    
    close_system(model);    
  end
  toc;  % terminate stop watch
end

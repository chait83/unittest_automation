% M. Wilke @ LDCB October 2019
% Simulink: Open all models starting from the root model and print them
% Inputs:
%   rootModel  = Highest model as a starting point in the model hierarchy (e.g. 'Behavior'), w/o SLX extension.

function SL_ListAllUsedModels(rootModel)
  tic;  % start stop watch
  % some parameter checks
  assert(nargin == 1, 'The number of parameters must be 1, not %d.',nargin);
  assert(isa(rootModel,'char'),'Parameter <rootModel> is of type %s, not char!', class(rootModel));

  % load root model without GUI
  load_system(rootModel);
  
  % get all models
  [myModels,~] = find_mdlrefs(rootModel,'AllLevels',true,...
                              'Variants','AllVariants');
  
  % loop trough all model files
  s = size(myModels);
  for i = 1:s(1)
    model = myModels(i);
    
    % get additional model information
    info = Simulink.MDLInfo(char(model));
    simulinkVersion = info.ReleaseName;    % MATLAB release name
    modelVersion = info.ModelVersion;      % model version
    isLib = info.IsLibrary;                % lib or not
    modifiedBy = info.LastModifiedBy;      % modified by <user>  
    if (isLib)
      str = sprintf('Library Model = %s\t\t\t\t\tSimulink Release = %s\tModel Version = %s\tModified = %s', char(model), simulinkVersion, modelVersion, modifiedBy);
    else
      str = sprintf('        Model = %s\t\t\t\t\tSimulink Release = %s\tModel Version = %s\tModified = %s', char(model), simulinkVersion, modelVersion, modifiedBy);
    end
    str
    
    % Print model
    load_system(model);
    %model
    
    blocks = find_system(model,'FollowLinks','on',...
                         'LookUnderMasks','on',...
                         'LinkStatus','resolved');
    % Display the block names, replacing newlines with spaces for clarity
    for i=1:numel(blocks)
      disp(strrep(blocks{i},char(10),' '));
    end
    close_system(model); 
  end
  toc;  % terminate stop watch
end

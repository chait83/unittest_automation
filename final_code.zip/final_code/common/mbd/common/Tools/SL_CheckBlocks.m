% M. Wilke @ CECB January 2019
% M. Wilke @ LDCB March 2022 - Added libraries
% Simulink: Search for specific Simulink block type in all model references and libraries starting at the root level.
% Inputs:
%          rootModel  = Highest model as a starting point in the model hierarchy (e.g. 'Behavior'), w/o SLX extension.
%          blockType  = Specific block type (e.g. 'Inport')
function SL_CheckBlocks(rootModel, blockType)
  tic;  % start stop watch
  % some parameter checks
  assert(nargin == 2, 'The number of parameters must be 2, not %d.',nargin);
  assert(isa(rootModel,'char'),'Parameter <rootModel> is from type %s, not char!', class(rootModel));
  assert(isa(blockType,'char'),'Parameter <blockType> is from type %s, not char!', class(blockType));

  % load root model w/o GUI
  load_system(rootModel);
  
  % get all models
  [myModels,~] = find_mdlrefs(rootModel,'AllLevels',true,'Variants','AllVariants','IncludeCommented','off','IncludeProtectedModels',true);
  close_system(rootModel);
  
  % loop trough all model files
  s = size(myModels);
  for i = 1:s(1) % for all models
    model = myModels(i);
    load_system(model);
    
    found = find_system(model, 'BlockType', blockType);    
    if isempty(found)      
      fprintf("[%s]: Block Type [%s] not found.\n", model{1}, blockType);
    else
      found
    end

    % get all library blocks (subsystems)
    libraries = find_system(model,'FollowLinks','on','LookUnderMasks','on','LinkStatus','resolved');
    ss = size(libraries);
    for k = 1:ss(1)  % loop through all library blocks        
      libPath = get_param(libraries(k),'ReferenceBlock');  % get path of linked library
      load_system(libPath);
      found = find_system(libPath, 'BlockType', blockType);  
      if isempty(found)      
        fprintf("[%s]: Block Type [%s] not found.\n", libPath{1}, blockType);
      else
        found
      end  
      close_system(libPath);
    end

    close_system(model);    
  end
  toc;  % terminate stop watch
end

function [status,text] = SL_DV_HasDesignErrors(designModel, saveReports, reportPath, prefix, postfix)
% Check designModel for DesignVerifier design errors
% parameters
%   designModel - indentifies the design model 
%   saveReports - true to save report file, otherwise false
%   reportPath  - path to save report file, if saveReports is true
%                 (optional)
%   prefix      - prefix for report name (optional)
%   postfix     - postfix for report name (optional)
% return values
%   status - returns 0 on success, 1 on error and 2 on test timeout.
%   text   - error message returned by function or execeptions.

status = 1;

% construct report file name
reportFileName = '$ModelName$';

if exist('prefix','var')
    reportFileName= strcat(prefix, reportFileName);
end

if exist('postfix','var')
    reportFileName = strcat(reportFileName, postfix);
end

if exist('reportPath','var')
    reportFileName = strcat(reportPath, reportFileName);
end

%% Modify the path for DV Analysis
% Otherwise, the replacement functions are not found. 
% Can not be part of the project, because the replacement functions would
% shadow the original functions used by embedded coder
savedpath = path;
newpath = fullfile(fileparts(mfilename('fullpath')), '..\DVAnalysisSupport\functions_repl');
path(newpath, path)

%% Exeute analysis

try
    load_system(designModel);
    
    %% Configure the analysis
    opts = sldvoptions(designModel);
    
    opts.Mode = 'DesignErrorDetection';
    opts.OutputDir = 'sldv_output/$ModelName$/';
    
    opts.DetectActiveLogic = 'on';
    opts.DetectDeadLogic = 'on';
    opts.DetectDivisionByZero = 'on';
    opts.DetectDSMAccessViolations = 'on';
    opts.DetectIntegerOverflow = 'on';
    opts.DetectInfNaN = 'on';
    opts.DetectOutOfBounds = 'on';
    opts.DesignMinMaxCheck = 'on';
    opts.DetectSubnormal = 'on';
    opts.MaxProcessTime = 43200; % 12 hours
    
    % configure block replacement, replacement block list is generated
    % in SL_DV_GetReplacementBlockList()
    opts.BlockReplacement = 'on';
    opts.BlockReplacementRulesList = SL_DV_GetReplacementBlockList();
    opts.BlockReplacementModelFileName = '$ModelName$_pp_replace';

    if (saveReports == 1)
        opts.ReportFileName = reportFileName;
        opts.ReportPDFFormat = 'on';
        opts.SaveReport = 'on';
        opts.DisplayReport = 'off';
    else
        opts.SaveReport = 'off';
    end
    
    diaryFilename = [tempname,'.txt'];

    diary(diaryFilename);
    diary on;
        
    %% Run the analysis
    retVal = sldvrun(designModel, opts, false);

    % update status based on sldvrun value
    switch retVal 
        case -1
            status = 2;
        case 0
            status = 1;
        case 1
            status = 0;
    end
    
    diary off;

    text = fileread(diaryFilename);
    delete(diaryFilename);

    close_system(designModel);
    
catch ME
    % Handle exceptions, in case of exception diary text is not useful.
    % use error message from exception.
    text = ME.message;
end

%% Restore the data dictionary (discard tunable parameter changes)
%  only if the analysis was able to be started - otherwise we may
%  discard important changes to the DD
if (status ~= 0)

    DD_names = ['PessralFunctionalModelDataDictionary.sldd', ... 
                'PessralPesDataDictionary.sldd', ... 
                'SabDataDictionary.sldd'];

    for i=1:length(DD_names)
        DD_name = DD_names(i);

        if isfile(DD_name)
            DD = Simulink.data.dictionary.open(DD_name);
            discardChanges(DD);  
            DD.close();
        end        
    end
end

%% Restore the original path 
path(savedpath);

end


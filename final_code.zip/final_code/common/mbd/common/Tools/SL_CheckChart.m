% M. Wilke @ CECB January 2019
% Simulink: Search for Stateflow Charts in all model references starting at the root level.
% Inputs:
%          rootModel  = Highest model as a starting point in the model hierarchy (e.g. 'Behavior'), w/o SLX extension.
function SL_CheckChart(rootModel)
  tic;  % start stop watch
  % some parameter checks
  assert(nargin == 1, 'The number of parameters must be 1, not %d.',nargin);
  assert(isa(rootModel,'char'),'Parameter <rootModel> is from type %s, not char!', class(rootModel));

  % load root model w/o GUI
  load_system(rootModel);
  
  % get all models
  [myModels,~] = find_mdlrefs(rootModel,'AllLevels',true,'Variants','AllVariants');
  close_system(rootModel);
  
  % loop trough all model files
  s = size(myModels);
  for i = 1:s(1) % for all models
    model = myModels(i);
    load_system(model);
    
    found = find_system(model, 'BlockType', 'SubSystem'); 
    if ~isempty(found)      
      s1 = size(found);
      for k = 1:s1(1) % for all Subsystems
        gcbh = getSimulinkBlockHandle(found{k});
        if strcmp(get_param(gcbh,'SFBlockType'),'Chart'); % search for Chart
          fprintf("[%s]: Chart: %s\n", model{1}, found{k});        
        end
      end
    end
    
    close_system(model);    
  end
  toc;  % terminate stop watch
end

% M. Wilke @ CECB March 2017
% Simulink: Open all models starting from the root model and save them.
% Inputs:
%          rootModel  = Highest model as a starting point in the model hierarchy (e.g. 'Behavior'), w/o SLX extension.
function SL_OpenSaveAll(rootModel)
  tic;  % start stop watch
  % some parameter checks
  assert(nargin == 1, 'The number of parameters must be 1, not %d.',nargin);
  assert(isa(rootModel,'char'),'Parameter <rootModel> is from type %s, not char!', class(rootModel));

  % load root model w/o GUI
  load_system(rootModel);
  
  % get all models
  [myModels,~] = find_mdlrefs(rootModel,'AllLevels',true,'Variants','AllVariants');
  close_system(rootModel);
  
  % loop trough all model files
  s = size(myModels);
  for i = 1:s(1)
    model = myModels(i);
    open_system(model);
    save_system(model);
    close_system(model);    
  end
  toc;  % terminate stop watch
end

function [report,mil_cvdg,mil_cvdo,mil_handle] = SL_DV_MILCoverage(testModel)
% Use DesignVerifier to check test coverage, create and save test harness

%% Generate path for all artifacts for a given run
    artifactPath = strcat('sldv_output/',testModel,'/checkcoverage/');

%% Generate artifact names
    testHarness = strcat(testModel, '_harness');
	mat_file_name = strcat(artifactPath,testModel,'_testharness.mat');
    
%% Generate test harness   
    [status, ~, ~] = SL_DV_CheckCoverage(testModel, testHarness, true, artifactPath);
    disp(status);
    
      
%% Select the correct script to run.
    InputsH= get_param(strcat(testHarness, '/Inputs'), 'Handle');
    if(isfield(get_param(InputsH,'ObjectParameters'),'NumberOfScenarios'))
    % In case of SignalEditor use this line
        SL_DV_ConvertSignalEditorTest(testHarness);
    else
    % In case of SignalBuilder use the next two lines      
        if exist(mat_file_name, 'file') > 0
        	delete(mat_file_name);
        end
        SL_DV_ConvertSignalBuilderTest(testHarness,mat_file_name);
    end
        
    % configure test harness to match child settings
    set_param(testHarness, 'LifeSpan', '1');
    set_param(testHarness, 'PortableWordSizes', 'on');
    set_param(testHarness, 'GenerateMakefile', 'off');
    
    % get handle to signal builder block
    seBlockH = get_param(strcat(testHarness, '/Inputs'), 'Handle');

    % get the number of scenarios
    num_scenarios = str2double(get_param(seBlockH,'NumberOfScenarios'));
            
    % assign pessral data dictionary to generated test harness
    set_param(testHarness,'DataDictionary','PessralPesDataDictionary.sldd');

%     attach configSet
    SL_DV_UpdateConfigSet(testHarness,'PessralPesDataDictionary.sldd', ...
        'FunctionalModelCoverageConfiguration');
    
    % enable generating floating point to support test harness
    set_param(testHarness, 'PurelyIntegerCode', 'off');
    set_param(testHarness, 'SupportAbsoluteTime', 'on');

%% Run test harness in MIL
    set_param(testHarness, 'SimulationMode', 'normal');
        % loop through each signal in each scenario
 
    for scene_num = num_scenarios:-1:1
        set_param(seBlockH, 'ActiveScenario', scene_num);
        mil_cvdo(scene_num) = cvsim(testHarness);
    end
    mil_cvdg = cv.cvdatagroup(mil_cvdo(:,:));
    mil_handle = get_param(testHarness, 'Handle');
    
    if(isempty(complexityinfo(mil_cvdg,mil_handle)))
        complexityInfo = 'NA';
    else 
        complexityInfo = complexityinfo(mil_cvdg,mil_handle);
        complexityInfo = num2str(complexityInfo(1));
    end
    
    if(isempty(executioninfo(mil_cvdg,mil_handle)))
        executionCoverage = 'NA';
    else 
        executionCov = executioninfo(mil_cvdg,mil_handle);
        executionCoverage = strcat(num2str(executionCov(1)/executionCov(2)*100),'%');
    end
    
    if(isempty(conditioninfo(mil_cvdg,mil_handle)))
        conditionCoverage = 'NA';
    else 
        conditionCov = conditioninfo(mil_cvdg,mil_handle);
        conditionCoverage = strcat(num2str(conditionCov(1)/conditionCov(2)*100),'%');
    end
    
    if(isempty(decisioninfo(mil_cvdg,mil_handle)))
        decisionCoverage = 'NA';
    else 
        decisionCov = decisioninfo(mil_cvdg,mil_handle);
        decisionCoverage = strcat(num2str(decisionCov(1)/decisionCov(2)*100),'%');
    end
    
    coverageInfo = {strcat('Complexity Info: ',complexityInfo);strcat('Execution Coverage: ',executionCoverage);strcat('Condition Coverage: ',conditionCoverage);strcat('Decision Coverage: ',decisionCoverage)};
    
    report = SL_DV_Reporting('Coverage',testModel,coverageInfo);
    
    

    
%% Generate MIL Coverage Test Report
    MIL_TestCoverageReport = strcat(artifactPath,'MIL_CoverageReport_',testModel,'.html');
	% delete previously generated coverage report
    if exist(MIL_TestCoverageReport, 'file') > 0
        delete(MIL_TestCoverageReport);
    end
    cvhtml(MIL_TestCoverageReport,mil_cvdg);

end
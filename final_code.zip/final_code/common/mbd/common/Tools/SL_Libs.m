function SL_Libs(rootModel)

load_system(rootModel);
blocks = find_system(rootModel,'FollowLinks','on',...
                            'LookUnderMasks','on',...
                            'LinkStatus','resolved');
% Display the block names, replacing newlines with spaces for clarity
for i=1:numel(blocks)
    disp(strrep(blocks{i},char(10),' '));
end
end
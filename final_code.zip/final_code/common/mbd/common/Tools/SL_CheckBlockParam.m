% M. Wilke @ CECB January 2019
% Simulink: Search for specific Simulink block type and block parameter in all model references starting at the root level.
% Inputs:
%          rootModel  = Highest model as a starting point in the model hierarchy (e.g. 'Behavior'), w/o SLX extension.
%          blockType  = Specific block type (e.g. 'Inport')
%          param      = Specific parameter of found block 
function SL_CheckBlockParam(rootModel, blockType, blockParam)
  tic;  % start stop watch
  % some parameter checks
  assert(nargin == 3, 'The number of parameters must be 3, not %d.',nargin);
  assert(isa(rootModel,'char'),'Parameter <rootModel> is from type %s, not char!', class(rootModel));
  assert(isa(blockType,'char'),'Parameter <blockType> is from type %s, not char!', class(blockType));
  assert(isa(blockParam,'char'),'Parameter <blockParam> is from type %s, not char!', class(blockParam));

  % load root model w/o GUI
  load_system(rootModel);
  
  % get all models
  [myModels,~] = find_mdlrefs(rootModel,'AllLevels',true,'Variants','AllVariants');
  close_system(rootModel);
  
  % loop trough all model files
  s = size(myModels);
  for i = 1:s(1) % for all models
    model = myModels(i);
    load_system(model);
    
    found = find_system(model, 'BlockType', blockType);    
    if isempty(found)      
      fprintf("[%s] Block Type [%s] not found.\n", model{1}, blockType);
    else
      s1 = size(found);
      for k = 1:s1(1) % for all blocks of specific type 'blockType'
        blockHandle         = getSimulinkBlockHandle(found{k}, true);
        if blockHandle ~= -1
          blockParameterValue = get_param(blockHandle, blockParam);
          fprintf("[%s]: %s: %s = %s\n", model{1}, found{k}, blockParam, blockParameterValue);
        else
          fprintf("[%s] Parameter [%s] in Block Type [%s] not found.\n", model{1}, blockParam, blockType);      
        end
      end
    end
    
    close_system(model);    
  end
  toc;  % terminate stop watch
end

% =======================================================================================
% Copyright 2020 OTIS GmbH & Co OHG - Lead Design Center Berlin
% =======================================================================================

addpath(genpath('mbd/common/amt'));
addpath('mbd/common/DataDictionary');
addpath(genpath('mbd/common/library'));
addpath(genpath('mbd/common/DVAnalysisSupport'));
addpath(genpath('mbd/common/DvLibrary'));
addpath(genpath('mbd/common/Scom'));
addpath('mbd/common/Tools');

/*
 * ---------------------------------------------------------------------------
 * Copyright (c) 2015 UTC - All rights reserved.
 *
 * Model Name:         HandlePesRequest
 * Code Generation:     -
 * Svn:
 * ---------------------------------------------------------------------------
 */

#include "HandlePesRequest.h"

/* Named constants for Chart: '<S2>/SetPcbManufacturingDateAlgorithm' */
#define HandlePesRequest_IN_Idle       ((uint8_T)1U)
#define HandlePesRequest_IN_PerformingWrite ((uint8_T)2U)
#define HandlePesRequest_IN_WaitingForPesData ((uint8_T)3U)

/* user code (top of source file) */

/* *****************************************************************************/
/* **                _______   _________  _________   _______                 **/
/* **               (  ___  )  \__   __/  \__   __/  (  ____ \                **/
/* **               | (   ) |     ) (        ) (     | (    \/                **/
/* **               | |   | |     | |        | |     | (_____                 **/
/* **               | |   | |     | |        | |     (_____  )                **/
/* **               | |   | |     | |        | |           ) |                **/
/* **               | (___) |     | |     ___) (___  /\____) |                **/
/* **               (_______)     )_(     \_______/  \_______)                **/
/* **                                                                         **/
/* **                      OTIS Lead Design Center Berlin                     **/
/* **                                                                         **/
/* **   Copyright 2020 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **/
/* **                                                                         **/
/* *****************************************************************************/
/* **                                                                         **/
/* ** Simulink Model                                                          **/
/* **                                                                         **/
/* ** Purpose                                                                 **/
/* **  Model of Functional Safety Logic of the Pessral System                 **/
/* **                                                                         **/
/* ** Functionality                                                           **/
/* **  This is one of the source files auto-generated from the Simulink Model **/
/* **  with the help of the Simulink Embedded Coder.                          **/
/* **                                                                         **/
/* **                    DO NOT MANUALLY CHANGE THIS FILE                     **/
/* **                    ================================                     **/
/* **                                                                         **/
/* *****************************************************************************/
const PesData_C HandlePesRequest_rtZPesData_C =
{
    OpbNodeAddr_GECB,                  /* RequesterNodeAddr */

    {
        0U, 0U, 0U, 0U, 0U, 0U
    }
    ,                                  /* Data */
    false                              /* Send */
} ;                                    /* PesData_C ground */

/* Constant parameters (default storage) */
const ConstP_HandlePesRequest_T HandlePesRequest_ConstP =
{
    /* Computed Parameter: Unused2_Value
     * Referenced by: '<Root>/Unused2'
     */
    {
        OpbNodeAddr_GECB,              /* RequesterNodeAddr */

        {
            0U, 0U, 0U, 0U, 0U, 0U
        }
        ,                              /* Data */
        false                          /* Send */
    }
};

/* Invariant block signals (default storage) */
const ConstB_HandlePesRequest_hb4t_T HandlePesRequest_ConstB =
{
    /* Start of '<Root>/HandlePesRequestSetData' */
    {
        /* Start of '<S2>/CheckWriteTimeout' */
        {
            50U,                       /* '<S60>/Signal Conversion2' */
            3300U                      /* '<S60>/Signal Conversion1' */
        }
        ,

        /* End of '<S2>/CheckWriteTimeout' */

        /* Start of '<S2>/CheckPayloadTimeout' */
        {
            1200U,                     /* '<S11>/Add1' */
            50U,                       /* '<S58>/Signal Conversion2' */
            1200U                      /* '<S58>/Signal Conversion1' */
        }
        ,

        /* End of '<S2>/CheckPayloadTimeout' */

        /* Start of '<S2>/BuildPesData' */
        {
            OpbNodeAddr_CONFIGURATION_MASTER,/* '<S22>/Signal Conversion10' */
            6U,                        /* '<S22>/Signal Conversion2' */
            6U,                        /* '<S23>/uint8_boolean' */
            0U,                        /* '<S23>/Math Function' */
            PesDataId_SET_PCB_MANUFACTURING_DATE_STATUS,/* '<S22>/Signal Conversion4' */
            1U                         /* '<S27>/Compare' */
        }
        /* End of '<S2>/BuildPesData' */
    }
    /* End of '<Root>/HandlePesRequestSetData' */
};

/* Outputs for atomic system: '<S2>/BufferOtpWriteReply' */
void HandlePesRequest_BufferOtpWriteReply(const
    OtpWritePcbManufacturingDateReply_B *rtu_OtpWritePcbManufacturingDateReply,
    bool_t rtu_WriteOtpCommandOld, bool_t *rty_ReceivedOtpWriteReply,
    OtpWritePcbManufacturingDateReply_B *rty_BufferedOtpWriteReply,
    DW_BufferOtpWriteReply_HandlePesRequest_T *localDW)
{
    /* Logic: '<S6>/Logical Operator2' incorporates:
     *  RelationalOperator: '<S6>/Equal2'
     *  UnitDelay: '<S6>/Unit Delay2'
     */
    *rty_ReceivedOtpWriteReply =
        ((rtu_OtpWritePcbManufacturingDateReply->ReceptionTimeStamp !=
          localDW->UnitDelay2_DSTATE.ReceptionTimeStamp) &&
         rtu_WriteOtpCommandOld);

    /* Switch: '<S6>/Switch' incorporates:
     *  UnitDelay: '<S6>/Unit Delay2'
     */
    if (*rty_ReceivedOtpWriteReply)
    {
        *rty_BufferedOtpWriteReply = *rtu_OtpWritePcbManufacturingDateReply;
    }
    else
    {
        *rty_BufferedOtpWriteReply = localDW->UnitDelay2_DSTATE;
    }

    /* End of Switch: '<S6>/Switch' */
}

/* Update for atomic system: '<S2>/BufferOtpWriteReply' */
void HandlePesRequest_BufferOtpWriteReply_Update
    (OtpWritePcbManufacturingDateReply_B *rty_BufferedOtpWriteReply,
     DW_BufferOtpWriteReply_HandlePesRequest_T *localDW)
{
    /* Update for UnitDelay: '<S6>/Unit Delay2' */
    localDW->UnitDelay2_DSTATE = *rty_BufferedOtpWriteReply;
}

/* Outputs for atomic system: '<S2>/BufferPesData' */
void HandlePesRequest_BufferPesData(const
    PesDataSetPcbManufacturingDateReceived_B
    *rtu_SetPcbManufacturingDateFromConfigurationMaster, bool_t
    rtu_ReceivePesDataCommandOld, bool_t *rty_ReceivedPesData,
    PesDataSetPcbManufacturingDateReceived_B *rty_BufferedPesData,
    DW_BufferPesData_HandlePesRequest_T *localDW)
{
    /* Logic: '<S7>/Logical Operator2' incorporates:
     *  RelationalOperator: '<S7>/Equal2'
     *  UnitDelay: '<S7>/Unit Delay2'
     */
    *rty_ReceivedPesData =
        ((rtu_SetPcbManufacturingDateFromConfigurationMaster->Timestamp !=
          localDW->UnitDelay2_DSTATE.Timestamp) && rtu_ReceivePesDataCommandOld);

    /* Switch: '<S7>/Switch' incorporates:
     *  UnitDelay: '<S7>/Unit Delay2'
     */
    if (*rty_ReceivedPesData)
    {
        *rty_BufferedPesData =
            *rtu_SetPcbManufacturingDateFromConfigurationMaster;
    }
    else
    {
        *rty_BufferedPesData = localDW->UnitDelay2_DSTATE;
    }

    /* End of Switch: '<S7>/Switch' */
}

/* Update for atomic system: '<S2>/BufferPesData' */
void HandlePesRequest_BufferPesData_Update
    (PesDataSetPcbManufacturingDateReceived_B *rty_BufferedPesData,
     DW_BufferPesData_HandlePesRequest_T *localDW)
{
    /* Update for UnitDelay: '<S7>/Unit Delay2' */
    localDW->UnitDelay2_DSTATE = *rty_BufferedPesData;
}

/* Outputs for atomic system: '<S2>/BuildOtpWriteRequest' */
void HandlePesRequest_BuildOtpWriteRequest(bool_t rtu_WriteOtpCommand, const
    PesDataSetPcbManufacturingDateReceived_B *rtu_PesDataBuffered,
    OtpWritePcbManufacturingDate_B *rty_OtpWritePcbManufacturingDate,
    B_BuildOtpWriteRequest_HandlePesRequest_T *localB,
    DW_BuildOtpWriteRequest_HandlePesRequest_T *localDW)
{
    /* Outputs for Atomic SubSystem: '<S8>/Bit Shift' */
    /* Sum: '<S8>/Add' incorporates:
     *  DataTypeConversion: '<S8>/Data Type Conversion'
     *  DataTypeConversion: '<S8>/Data Type Conversion1'
     *  MATLAB Function: '<S14>/bit_shift'
     */
    /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S17>:1' */
    /* '<S17>:1:4' switch mode */
    /* '<S17>:1:5' case 1 */
    /* '<S17>:1:6' y = bitsll(cast_to_fi(u), N); */
    /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S18>:1' */
    /* '<S18>:1:4' switch mode */
    /* '<S18>:1:5' case 1 */
    /* '<S18>:1:6' y = bitsll(cast_to_fi(u), N); */
    rty_OtpWritePcbManufacturingDate->Year = (uint16_T)(((uint32_T)((uint32_T)
        (((uint32_T)rtu_PesDataBuffered->SetPcbManufacturingDate.raw[0]) <<
         ((uint64_T)8)))) + ((uint32_T)
        rtu_PesDataBuffered->SetPcbManufacturingDate.raw[1]));

    /* End of Outputs for SubSystem: '<S8>/Bit Shift' */

    /* SignalConversion: '<S16>/Signal Conversion' */
    localB->SignalConversion = rtu_WriteOtpCommand;

    /* BusCreator: '<S8>/Bus Creator' incorporates:
     *  Constant: '<S19>/Constant'
     *  Delay: '<S16>/Delay'
     *  Logic: '<S16>/Logical Operator'
     *  RelationalOperator: '<S16>/Relational Operator'
     *  RelationalOperator: '<S19>/Compare'
     */
    rty_OtpWritePcbManufacturingDate->Day =
        rtu_PesDataBuffered->SetPcbManufacturingDate.raw[3];
    rty_OtpWritePcbManufacturingDate->Month =
        rtu_PesDataBuffered->SetPcbManufacturingDate.raw[2];
    rty_OtpWritePcbManufacturingDate->Send = ((localB->SignalConversion == true)
        && (localB->SignalConversion != localDW->Delay_DSTATE));
}

/* Update for atomic system: '<S2>/BuildOtpWriteRequest' */
void HandlePesRequest_BuildOtpWriteRequest_Update
    (B_BuildOtpWriteRequest_HandlePesRequest_T *localB,
     DW_BuildOtpWriteRequest_HandlePesRequest_T *localDW)
{
    /* Update for Delay: '<S16>/Delay' */
    localDW->Delay_DSTATE = localB->SignalConversion;
}

/* System initialize for atomic system: '<S2>/BuildPesData' */
void HandlePesRequest_BuildPesData_Init(DW_BuildPesData_HandlePesRequest_T
    *localDW)
{
    /* InitializeConditions for UnitDelay: '<S24>/Unit Delay3' */
    localDW->UnitDelay3_DSTATE = PesDataId_None;
}

/* Outputs for atomic system: '<S2>/BuildPesData' */
void HandlePesRequest_BuildPesData(bool_t rtu_SendAnswer,
    PesDataSetPcbManufacturingDateStatus_E rtu_AnswerStatus, const PesData_C
    *rtu_PesDataIn, bool_t rtu_BusyOld, PesData_C *rty_PesData, bool_t
    *rty_BusySetData, B_BuildPesData_HandlePesRequest_T *localB, const
    ConstB_BuildPesData_HandlePesRequest_T *localC,
    DW_BuildPesData_HandlePesRequest_T *localDW)
{
    uint32_T Crc32;
    bool_t rtb_SendHeader;
    uint16_T rtb_uint8_boolean;
    bool_t rtb_LogicalOperator_h0yy;
    bool_t rtb_NoReset;
    bool_t rtb_Busy;
    uint8_T rtb_Data_d0ov[6];
    int32_T i;
    uint8_T tmp[6];
    uint8_T tmp_0;

    /* SignalConversion: '<S28>/Signal Conversion' incorporates:
     *  SignalConversion: '<S22>/Signal Conversion3'
     */
    localB->SignalConversion = rtu_SendAnswer;

    /* Logic: '<S23>/Logical Operator2' incorporates:
     *  Constant: '<S29>/Constant'
     *  Delay: '<S28>/Delay'
     *  Logic: '<S22>/Logical Operator3'
     *  Logic: '<S23>/Logical Operator1'
     *  Logic: '<S28>/Logical Operator'
     *  RelationalOperator: '<S28>/Relational Operator'
     *  RelationalOperator: '<S29>/Compare'
     *  SignalConversion: '<S22>/Signal Conversion7'
     *  UnitDelay: '<S22>/Unit Delay'
     */
    rtb_SendHeader = ((((localB->SignalConversion == true) &&
                        (localB->SignalConversion != localDW->Delay_DSTATE)) &&
                       (((int32_T)localC->Compare) != 0)) && ((!rtu_BusyOld) &&
                       (!localDW->UnitDelay_DSTATE_e0nc)));

    /* Switch: '<S24>/Switch1' incorporates:
     *  SignalConversion: '<S22>/Signal Conversion8'
     *  UnitDelay: '<S24>/Unit Delay3'
     */
    if (rtb_SendHeader)
    {
        localB->PesDataIdLatched = localC->PesDataId;
    }
    else
    {
        localB->PesDataIdLatched = localDW->UnitDelay3_DSTATE;
    }

    /* End of Switch: '<S24>/Switch1' */

    /* DataTypeConversion: '<S26>/uint8_boolean' */
    rtb_uint8_boolean = (uint16_T)localB->PesDataIdLatched;

    /* Switch: '<S24>/Switch2' incorporates:
     *  Constant: '<S9>/Constant'
     *  DataTypeConversion: '<S9>/Data Type Conversion'
     *  SignalConversion: '<S22>/Signal Conversion1'
     *  SignalConversion: '<S22>/Signal Conversion8'
     *  UnitDelay: '<S24>/Unit Delay1'
     */
    /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S46>:1' */
    /* '<S46>:1:4' switch mode */
    /* '<S46>:1:7' case 2 */
    /* '<S46>:1:8' y = bitsrl(cast_to_fi(u), N); */
    /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S47>:1' */
    /* '<S47>:1:4' switch mode */
    /* '<S47>:1:7' case 2 */
    /* '<S47>:1:8' y = bitsrl(cast_to_fi(u), N); */
    if (rtb_SendHeader)
    {
        localB->Switch2[0] = (uint8_T)rtu_AnswerStatus;
        localB->Switch2[1] = ((uint8_T)0U);
        localB->Switch2[2] = ((uint8_T)0U);
        localB->Switch2[3] = ((uint8_T)0U);
        localB->Switch2[4] = ((uint8_T)0U);
        localB->Switch2[5] = ((uint8_T)0U);
    }
    else
    {
        for (i = 0; i < 6; i++)
        {
            localB->Switch2[i] = localDW->UnitDelay1_DSTATE[i];
        }
    }

    /* End of Switch: '<S24>/Switch2' */

    /* Switch: '<S24>/Switch3' incorporates:
     *  SignalConversion: '<S22>/Signal Conversion8'
     *  UnitDelay: '<S24>/Unit Delay2'
     */
    if (rtb_SendHeader)
    {
        localB->Switch3 = localC->Length;
    }
    else
    {
        localB->Switch3 = localDW->UnitDelay2_DSTATE;
    }

    /* End of Switch: '<S24>/Switch3' */

    /* SignalConversion: '<S39>/Signal Conversion4' */
    /* MATLAB Function 'CalculateCrc32/MatlabFunctionCall': '<S42>:1' */
    /* '<S42>:1:3' if (coder.target('Sfun')) */
    /* '<S42>:1:8' else */
    /*  embedded coder ------------------------------------------------- */
    /* '<S42>:1:10' coder.cinclude('Hlp/Crc32.h'); */
    /*  invoke C function */
    /* '<S42>:1:13' Crc32 = coder.ceval('HlpCrc32_Calculate16BitLength', data, length); */
    for (i = 0; i < 6; i++)
    {
        tmp[i] = localB->Switch2[i];
    }

    /* End of SignalConversion: '<S39>/Signal Conversion4' */

    /* MATLAB Function: '<S39>/MatlabFunctionCall' incorporates:
     *  SignalConversion: '<S39>/Signal Conversion1'
     */
    Crc32 = HlpCrc32_Calculate16BitLength(tmp, localB->Switch3);

    /* SignalConversion: '<S32>/Signal Conversion' */
    /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S56>:1' */
    /* '<S56>:1:4' switch mode */
    /* '<S56>:1:7' case 2 */
    /* '<S56>:1:8' y = bitsrl(cast_to_fi(u), N); */
    /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S55>:1' */
    /* '<S55>:1:4' switch mode */
    /* '<S55>:1:7' case 2 */
    /* '<S55>:1:8' y = bitsrl(cast_to_fi(u), N); */
    /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S53>:1' */
    /* '<S53>:1:4' switch mode */
    /* '<S53>:1:7' case 2 */
    /* '<S53>:1:8' y = bitsrl(cast_to_fi(u), N); */
    /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S54>:1' */
    /* '<S54>:1:4' switch mode */
    /* '<S54>:1:7' case 2 */
    /* '<S54>:1:8' y = bitsrl(cast_to_fi(u), N); */
    localB->SignalConversion_mdcc = rtb_SendHeader;

    /* Logic: '<S32>/Logical Operator' incorporates:
     *  Constant: '<S38>/Constant'
     *  Delay: '<S32>/Delay'
     *  RelationalOperator: '<S32>/Relational Operator'
     *  RelationalOperator: '<S38>/Compare'
     */
    rtb_LogicalOperator_h0yy = ((localB->SignalConversion_mdcc == false) &&
        (localB->SignalConversion_mdcc != localDW->Delay_DSTATE_ggbo));

    /* SignalConversion: '<S36>/Signal Conversion' incorporates:
     *  Constant: '<S31>/Unused'
     *  Logic: '<S31>/Logical Operator1'
     *  Logic: '<S31>/Logical Operator2'
     *  Logic: '<S31>/Logical Operator3'
     *  RelationalOperator: '<S31>/Relational Operator1'
     *  SignalConversion: '<S32>/Signal Conversion1'
     *  Sum: '<S31>/Add1'
     *  UnitDelay: '<S25>/Unit Delay'
     */
    localB->SignalConversion_exxk = (((((uint16_T)((uint8_T)(((uint32_T)
        ((uint8_T)6U)) + ((uint32_T)localDW->UnitDelay_DSTATE)))) >=
        localB->Switch3) && (!rtb_SendHeader)) && (!rtb_LogicalOperator_h0yy));

    /* Logic: '<S35>/Logical Operator2' incorporates:
     *  Constant: '<S37>/Constant'
     *  Delay: '<S36>/Delay'
     *  Logic: '<S36>/Logical Operator'
     *  RelationalOperator: '<S36>/Relational Operator'
     *  RelationalOperator: '<S37>/Compare'
     */
    rtb_NoReset = ((localB->SignalConversion_exxk != true) ||
                   (localB->SignalConversion_exxk == localDW->Delay_DSTATE_gedn));

    /* Logic: '<S35>/Logical Operator3' incorporates:
     *  Logic: '<S35>/Logical Operator1'
     *  Logic: '<S35>/Logical Operator4'
     *  SignalConversion: '<S32>/Signal Conversion1'
     *  UnitDelay: '<S35>/Unit Delay1'
     */
    localB->Out = ((rtb_LogicalOperator_h0yy && rtb_NoReset) || (rtb_NoReset &&
                    (localDW->UnitDelay1_DSTATE_av1i)));

    /* Logic: '<S25>/Logical Operator3' incorporates:
     *  SignalConversion: '<S35>/Signal Conversion2'
     */
    rtb_Busy = (rtb_SendHeader || (localB->Out));

    /* Switch: '<S25>/Switch' incorporates:
     *  Constant: '<S25>/Unused1'
     *  Logic: '<S25>/Logical Operator1'
     *  Logic: '<S25>/Logical Operator4'
     *  SignalConversion: '<S32>/Signal Conversion1'
     *  SignalConversion: '<S35>/Signal Conversion2'
     *  Sum: '<S34>/Add'
     *  Switch: '<S34>/Switch1'
     *  UnitDelay: '<S25>/Unit Delay'
     */
    if (((!rtb_Busy) || rtb_SendHeader) || rtb_LogicalOperator_h0yy)
    {
        localB->Index = ((uint8_T)0U);
    }
    else
    {
        if (localB->Out)
        {
            /* Switch: '<S34>/Switch1' incorporates:
             *  Constant: '<S34>/Unused'
             */
            tmp_0 = ((uint8_T)6U);
        }
        else
        {
            /* Switch: '<S34>/Switch1' incorporates:
             *  Constant: '<S34>/Unused3'
             */
            tmp_0 = ((uint8_T)0U);
        }

        localB->Index = (uint8_T)(((uint32_T)tmp_0) + ((uint32_T)
            localDW->UnitDelay_DSTATE));
    }

    /* End of Switch: '<S25>/Switch' */

    /* Switch: '<S22>/Switch7' incorporates:
     *  Constant: '<S22>/Unused2'
     */
    if (rtb_Busy)
    {
        /* Switch: '<S22>/Switch' incorporates:
         *  DataTypeConversion: '<S43>/Data Type Conversion2'
         *  DataTypeConversion: '<S48>/Data Type Conversion'
         *  DataTypeConversion: '<S48>/Data Type Conversion1'
         *  DataTypeConversion: '<S48>/Data Type Conversion2'
         *  DataTypeConversion: '<S48>/Data Type Conversion3'
         *  MATLAB Function: '<S39>/MatlabFunctionCall'
         *  MATLAB Function: '<S44>/bit_shift'
         *  MATLAB Function: '<S49>/bit_shift'
         *  MATLAB Function: '<S51>/bit_shift'
         *  MATLAB Function: '<S52>/bit_shift'
         *  S-Function (sfix_bitop): '<S43>/Bitwise Operator1'
         *  S-Function (sfix_bitop): '<S43>/Bitwise Operator2'
         *  S-Function (sfix_bitop): '<S48>/Bitwise Operator1'
         *  S-Function (sfix_bitop): '<S48>/Bitwise Operator2'
         *  S-Function (sfix_bitop): '<S48>/Bitwise Operator3'
         *  S-Function (sfix_bitop): '<S48>/Bitwise Operator4'
         *  Selector: '<S22>/Selector'
         *  SignalConversion: '<S40>/Signal Conversion4'
         */
        if (rtb_SendHeader)
        {
            /* Outputs for Atomic SubSystem: '<S43>/Bit Shift1' */
            rtb_Data_d0ov[0] = (uint8_T)((int32_T)(((int32_T)((uint32_T)
                (((uint32_T)rtb_uint8_boolean) >> ((uint64_T)8)))) & ((int32_T)
                ((uint16_T)255U))));

            /* End of Outputs for SubSystem: '<S43>/Bit Shift1' */
            rtb_Data_d0ov[1] = (uint8_T)(rtb_uint8_boolean & ((uint16_T)255U));

            /* Outputs for Atomic SubSystem: '<S48>/Bit Shift4' */
            rtb_Data_d0ov[2] = (uint8_T)((Crc32 >> ((uint64_T)24)) & 255U);

            /* End of Outputs for SubSystem: '<S48>/Bit Shift4' */

            /* Outputs for Atomic SubSystem: '<S48>/Bit Shift3' */
            rtb_Data_d0ov[3] = (uint8_T)((Crc32 >> ((uint64_T)16)) & 255U);

            /* End of Outputs for SubSystem: '<S48>/Bit Shift3' */

            /* Outputs for Atomic SubSystem: '<S48>/Bit Shift1' */
            rtb_Data_d0ov[4] = (uint8_T)((Crc32 >> ((uint64_T)8)) & 255U);

            /* End of Outputs for SubSystem: '<S48>/Bit Shift1' */
            rtb_Data_d0ov[5] = (uint8_T)(Crc32 & 255U);
        }
        else
        {
            for (i = 0; i < 6; i++)
            {
                rtb_Data_d0ov[i] = localB->Switch2[i + ((int32_T)localB->Index)];
            }
        }

        /* End of Switch: '<S22>/Switch' */
    }
    else
    {
        for (i = 0; i < 6; i++)
        {
            rtb_Data_d0ov[i] = ((uint8_T)0U);
        }
    }

    /* End of Switch: '<S22>/Switch7' */

    /* SignalConversion: '<S33>/Signal Conversion4' */
    localB->SignalConversion4 = rtb_Busy;

    /* SignalConversion: '<S22>/Signal Conversion9' */
    *rty_BusySetData = localB->SignalConversion4;

    /* Switch: '<S9>/Switch' incorporates:
     *  BusCreator: '<S22>/Bus Creator'
     *  SignalConversion: '<S22>/Signal Conversion6'
     */
    if (rtb_Busy)
    {
        rty_PesData->RequesterNodeAddr = localC->RequesterNodeAddr;
        for (i = 0; i < 6; i++)
        {
            rty_PesData->Data[i] = rtb_Data_d0ov[i];
        }

        rty_PesData->Send = true;
    }
    else
    {
        *rty_PesData = *rtu_PesDataIn;
    }

    /* End of Switch: '<S9>/Switch' */
}

/* Update for atomic system: '<S2>/BuildPesData' */
void HandlePesRequest_BuildPesData_Update(B_BuildPesData_HandlePesRequest_T
    *localB, DW_BuildPesData_HandlePesRequest_T *localDW)
{
    int32_T i;

    /* Update for Delay: '<S28>/Delay' */
    localDW->Delay_DSTATE = localB->SignalConversion;

    /* Update for UnitDelay: '<S22>/Unit Delay' */
    localDW->UnitDelay_DSTATE_e0nc = localB->SignalConversion4;

    /* Update for UnitDelay: '<S24>/Unit Delay3' */
    localDW->UnitDelay3_DSTATE = localB->PesDataIdLatched;

    /* Update for UnitDelay: '<S24>/Unit Delay1' */
    for (i = 0; i < 6; i++)
    {
        localDW->UnitDelay1_DSTATE[i] = localB->Switch2[i];
    }

    /* End of Update for UnitDelay: '<S24>/Unit Delay1' */

    /* Update for UnitDelay: '<S24>/Unit Delay2' */
    localDW->UnitDelay2_DSTATE = localB->Switch3;

    /* Update for Delay: '<S32>/Delay' */
    localDW->Delay_DSTATE_ggbo = localB->SignalConversion_mdcc;

    /* Update for UnitDelay: '<S25>/Unit Delay' */
    localDW->UnitDelay_DSTATE = localB->Index;

    /* Update for Delay: '<S36>/Delay' */
    localDW->Delay_DSTATE_gedn = localB->SignalConversion_exxk;

    /* Update for UnitDelay: '<S35>/Unit Delay1' */
    localDW->UnitDelay1_DSTATE_av1i = localB->Out;
}

/* Outputs for atomic system: '<S2>/CheckNewRequest' */
void HandlePesRequest_CheckNewRequest(bool_t rtu_IsNewRequestSetData, uint16_T
    rtu_Parameter, bool_t rtu_RequestIsOngoingOld, Timebase_t
    rtu_ReceptionTimeStampPesRequest, bool_t *rty_NewRequest, Timebase_t
    *rty_BufferedReceptionTimePesRequest, DW_CheckNewRequest_HandlePesRequest_T *
    localDW)
{
    /* Logic: '<S10>/Logical Operator' incorporates:
     *  DataTypeConversion: '<S10>/Data Type Conversion'
     *  Logic: '<S10>/Logical Operator1'
     *  RelationalOperator: '<S10>/Equal1'
     */
    *rty_NewRequest = ((rtu_IsNewRequestSetData && (((int32_T)
                          PesRequestSetData_SET_PCB_MANUFACTURING_DATE) ==
                         ((int32_T)rtu_Parameter))) && (!rtu_RequestIsOngoingOld));

    /* Switch: '<S10>/Switch' incorporates:
     *  UnitDelay: '<S10>/Unit Delay2'
     */
    if (*rty_NewRequest)
    {
        *rty_BufferedReceptionTimePesRequest = rtu_ReceptionTimeStampPesRequest;
    }
    else
    {
        *rty_BufferedReceptionTimePesRequest = localDW->UnitDelay2_DSTATE;
    }

    /* End of Switch: '<S10>/Switch' */
}

/* Update for atomic system: '<S2>/CheckNewRequest' */
void HandlePesRequest_CheckNewRequest_Update(Timebase_t
    *rty_BufferedReceptionTimePesRequest, DW_CheckNewRequest_HandlePesRequest_T *
    localDW)
{
    /* Update for UnitDelay: '<S10>/Unit Delay2' */
    localDW->UnitDelay2_DSTATE = *rty_BufferedReceptionTimePesRequest;
}

/*
 * Output and update for atomic system:
 *    '<S58>/MsToTimebase'
 *    '<S60>/MsToTimebase'
 */
void HandlePesRequest_MsToTimebase(Timebase_t rtu_base, uint32_T *rty_ms)
{
    uint32_T ms;
    uint32_T b_y;
    uint64_T tmp;

    /* MATLAB Function 'PESSRAL/Time/MsToTimebase/MsToTimebase': '<S59>:1' */
    /* '<S59>:1:3' ms = MsToTimebase(base, ms); */
    /*  CECB: MsToTimebase() - MW @ CECB */
    /*  Calculates # timebase-ticks from ms. */
    /*  Inputs:  base [�s], ms [ms] */
    /*  Return:  ticks */
    /*  Example: "MsToTimebase(50, 10);" Returns the timebase ticks for 10 ms, */
    /*                                   where the timebase runs with 50 �s. */
    /*  Note:    Sets result to zero in the following cases: */
    /*              * base == 0 */
    /*              * base <  0 */
    /*              * base is larger than uint32 */
    /*              * ms   <  0 */
    /*              * ms   is larger than uint32 */
    /*  */
    /*  Todo: Raise an error instead of setting the result to zero. */
    /*  We need to typecast these values, because for an uint8 matlab would cause */
    /*  a saturation:  uint8(1) * 1000 == uint(255) */
    /* 'MsToTimebase:19' base_tb = uint32(base); */
    /* 'MsToTimebase:20' ms_tb   = uint32(ms); */
    /* 'MsToTimebase:22' if (base_tb ~= base) || (ms_tb ~= ms) || (base_tb == 0) */
    if (rtu_base == 0U)
    {
        /*  raise error */
        /*  ticks = uint32(1) / uint32(0); */
        /*  because we cant raise an error in matlab and in C, we set ticks to */
        /*  zero */
        /* 'MsToTimebase:28' ticks = uint32(0); */
        ms = 0U;
    }
    else if ((*rty_ms) < 429497U)
    {
        /* 'MsToTimebase:30' elseif (ms_tb < (uint32(429496725) / uint32(1000))) */
        /*  uint32 calculation */
        /* 'MsToTimebase:32' ticks = (ms_tb * 1000) / base_tb; */
        tmp = ((uint64_T)(*rty_ms)) * 1000ULL;
        if (tmp > 4294967295ULL)
        {
            tmp = 4294967295ULL;
        }

        b_y = (uint32_T)tmp;
        ms = b_y / ((uint32_T)rtu_base);
        b_y -= ms * ((uint32_T)rtu_base);
        if ((b_y > 0U) && (b_y >= ((uint32_T)(((uint32_T)(((uint32_T)rtu_base) >>
                 1U)) + ((uint32_T)((Timebase_t)(rtu_base & 1U)))))))
        {
            ms++;
        }

        /*  normalize ms to �s and divide by base */
    }
    else
    {
        /* 'MsToTimebase:34' else */
        /*  double calculation for large values */
        /*  reason: uint32 calculation would cause a saturation of ms_tb */
        /* 'MsToTimebase:38' if (coder.target('Sfun') || coder.target('MATLAB')) */
        /* 'MsToTimebase:40' else */
        /*  embedded coder ------------------------------------------------------- */
        /*  dbgPrintf(uint32(0), 'Saturation \n'); */
        /* 'MsToTimebase:42' ticks = uint32(((ms_tb) * 1000) / base_tb); */
        tmp = ((uint64_T)(*rty_ms)) * 1000ULL;
        if (tmp > 4294967295ULL)
        {
            tmp = 4294967295ULL;
        }

        b_y = (uint32_T)tmp;
        ms = b_y / ((uint32_T)rtu_base);
        b_y -= ms * ((uint32_T)rtu_base);
        if ((b_y > 0U) && (b_y >= ((uint32_T)(((uint32_T)(((uint32_T)rtu_base) >>
                 1U)) + ((uint32_T)((Timebase_t)(rtu_base & 1U)))))))
        {
            ms++;
        }

        /*  normalize ms to �s and divide by base */
    }

    *rty_ms = ms;
}

/* Output and update for atomic system: '<S2>/CheckPayloadTimeout' */
bool_t HandlePesRequest_CheckPayloadTimeout(Timebase_t rtu_Timestamp, Timebase_t
    rtu_BufferedReceptionTimePesRequest, const
    ConstB_CheckPayloadTimeout_HandlePesRequest_T *localC)
{
    /* local block i/o variables */
    uint32_T rtb_ms;
    bool_t rty_PayloadTimeout_0;

    /* MATLAB Function: '<S58>/MsToTimebase' */
    rtb_ms = localC->SignalConversion1;
    HandlePesRequest_MsToTimebase(localC->SignalConversion2, &rtb_ms);

    /* RelationalOperator: '<S11>/Equal' incorporates:
     *  SignalConversion: '<S58>/Signal Conversion3'
     *  Sum: '<S11>/Add'
     */
    rty_PayloadTimeout_0 = (rtu_Timestamp >=
                            (rtu_BufferedReceptionTimePesRequest + ((Timebase_t)
        rtb_ms)));
    return rty_PayloadTimeout_0;
}

/* Output and update for atomic system: '<S2>/CheckWriteTimeout' */
bool_t HandlePesRequest_CheckWriteTimeout(Timebase_t rtu_Timestamp, const
    PesDataSetPcbManufacturingDateReceived_B *rtu_BufferedPesData, const
    ConstB_CheckWriteTimeout_HandlePesRequest_T *localC)
{
    /* local block i/o variables */
    uint32_T rtb_ms_f5r2;
    bool_t rty_WriteTimeout_0;

    /* MATLAB Function: '<S60>/MsToTimebase' */
    rtb_ms_f5r2 = localC->SignalConversion1;
    HandlePesRequest_MsToTimebase(localC->SignalConversion2, &rtb_ms_f5r2);

    /* RelationalOperator: '<S12>/Equal' incorporates:
     *  SignalConversion: '<S60>/Signal Conversion3'
     *  Sum: '<S12>/Add1'
     */
    rty_WriteTimeout_0 = (rtu_Timestamp >= (rtu_BufferedPesData->Timestamp +
                           ((Timebase_t)rtb_ms_f5r2)));
    return rty_WriteTimeout_0;
}

/* Output and update for atomic system: '<S2>/SetPcbManufacturingDateAlgorithm' */
void HandlePesRequest_SetPcbManufacturingDateAlgorithm(bool_t rtu_NewRequest,
    bool_t rtu_PesDataTimeout, bool_t rtu_ReceivedReply, const
    OtpWritePcbManufacturingDateReply_B *rtu_BufferedOtpWriteReply, bool_t
    rtu_ReceivedPesData, bool_t rtu_WriteTimeout, bool_t *rty_RequestIsOngoing,
    bool_t *rty_ReceivePesDataCommand, bool_t *rty_WriteOtpCommand, bool_t
    *rty_SendAnswerCommand, PesDataSetPcbManufacturingDateStatus_E
    *rty_AnswerStatus, DW_SetPcbManufacturingDateAlgorithm_HandlePesRequest_T
    *localDW)
{
    bool_t guard1 = false;

    /* Chart: '<S2>/SetPcbManufacturingDateAlgorithm' */
    /* Gateway: HandlePesRequestSetData/SetPcbManufacturingDateAlgorithm */
    /* During: HandlePesRequestSetData/SetPcbManufacturingDateAlgorithm */
    if (((uint32_T)localDW->bitsForTID0.is_active_c3_HandlePesRequest) == 0U)
    {
        /* Entry: HandlePesRequestSetData/SetPcbManufacturingDateAlgorithm */
        localDW->bitsForTID0.is_active_c3_HandlePesRequest = 1U;

        /* Entry Internal: HandlePesRequestSetData/SetPcbManufacturingDateAlgorithm */
        /* Transition: '<S13>:2' */
        /* '<S13>:2:2' SendAnswerCommand = false */
        *rty_SendAnswerCommand = false;

        /* '<S13>:2:3' AnswerStatus = PesDataSetPcbManufacturingDateStatus_E.PesDataSetPcbManufacturingDateStatus_COMMUNICATION_FAILURE */
        *rty_AnswerStatus =
            PesDataSetPcbManufacturingDateStatus_COMMUNICATION_FAILURE;

        /* Transition: '<S13>:25' */
        /* '<S13>:25:2' RequestIsOngoing = false */
        *rty_RequestIsOngoing = false;

        /* '<S13>:25:3' ReceivePesDataCommand = false */
        *rty_ReceivePesDataCommand = false;

        /* '<S13>:25:4' WriteOtpCommand = false */
        *rty_WriteOtpCommand = false;

        /* Transition: '<S13>:100' */
        /* Transition: '<S13>:101' */
        /* '<S13>:7:1' sf_internal_predicateOutput = NewRequest; */
        if (rtu_NewRequest)
        {
            /* Transition: '<S13>:7' */
            /* Transition: '<S13>:11' */
            /* '<S13>:11:2' RequestIsOngoing = true */
            *rty_RequestIsOngoing = true;

            /* '<S13>:11:3' ReceivePesDataCommand = true */
            *rty_ReceivePesDataCommand = true;
            localDW->bitsForTID0.is_c3_HandlePesRequest =
                HandlePesRequest_IN_WaitingForPesData;
        }
        else
        {
            /* Transition: '<S13>:103' */
            localDW->bitsForTID0.is_c3_HandlePesRequest =
                HandlePesRequest_IN_Idle;
        }
    }
    else
    {
        guard1 = false;
        switch (localDW->bitsForTID0.is_c3_HandlePesRequest)
        {
          case HandlePesRequest_IN_Idle:
            /* During 'Idle': '<S13>:1' */
            /* Transition: '<S13>:102' */
            /* '<S13>:7:1' sf_internal_predicateOutput = NewRequest; */
            if (rtu_NewRequest)
            {
                /* Transition: '<S13>:7' */
                /* Transition: '<S13>:11' */
                /* '<S13>:11:2' RequestIsOngoing = true */
                *rty_RequestIsOngoing = true;

                /* '<S13>:11:3' ReceivePesDataCommand = true */
                *rty_ReceivePesDataCommand = true;
                localDW->bitsForTID0.is_c3_HandlePesRequest =
                    HandlePesRequest_IN_WaitingForPesData;
            }
            else
            {
                /* Transition: '<S13>:52' */
                /* '<S13>:52:2' SendAnswerCommand = false */
                *rty_SendAnswerCommand = false;
                localDW->bitsForTID0.is_c3_HandlePesRequest =
                    HandlePesRequest_IN_Idle;
            }
            break;

          case HandlePesRequest_IN_PerformingWrite:
            /* During 'PerformingWrite': '<S13>:4' */
            /* '<S13>:38:1' sf_internal_predicateOutput = WriteTimeout; */
            if (rtu_WriteTimeout)
            {
                /* Transition: '<S13>:38' */
                /* Transition: '<S13>:43' */
                /* '<S13>:43:2' WriteOtpCommand = false */
                *rty_WriteOtpCommand = false;

                /* '<S13>:43:3' AnswerStatus = PesDataSetPcbManufacturingDateStatus_E.PesDataSetPcbManufacturingDateStatus_COMMAND_FAILED */
                *rty_AnswerStatus =
                    PesDataSetPcbManufacturingDateStatus_COMMAND_FAILED;

                /* Transition: '<S13>:44' */
                /* Transition: '<S13>:75' */
                /* Transition: '<S13>:76' */
                guard1 = true;
            }
            else
            {
                /* '<S13>:14:1' sf_internal_predicateOutput = ReceivedReply; */
                if (rtu_ReceivedReply)
                {
                    /* Transition: '<S13>:14' */
                    /* Transition: '<S13>:31' */
                    /* '<S13>:31:2' WriteOtpCommand = false */
                    *rty_WriteOtpCommand = false;

                    /* '<S13>:56:1' sf_internal_predicateOutput = false == BufferedOtpWriteReply.Result; */
                    if (!rtu_BufferedOtpWriteReply->Result)
                    {
                        /* Transition: '<S13>:56' */
                        /* Transition: '<S13>:63' */
                        /* '<S13>:63:2' AnswerStatus = PesDataSetPcbManufacturingDateStatus_E.PesDataSetPcbManufacturingDateStatus_COMMAND_FAILED */
                        *rty_AnswerStatus =
                            PesDataSetPcbManufacturingDateStatus_COMMAND_FAILED;

                        /* Transition: '<S13>:74' */
                        /* Transition: '<S13>:76' */
                        guard1 = true;
                    }
                    else
                    {
                        /* Transition: '<S13>:78' */
                        /* Transition: '<S13>:79' */
                        /* Transition: '<S13>:57' */
                        /* '<S13>:57:2' AnswerStatus = PesDataSetPcbManufacturingDateStatus_E.PesDataSetPcbManufacturingDateStatus_SUCCESS */
                        *rty_AnswerStatus =
                            PesDataSetPcbManufacturingDateStatus_SUCCESS;

                        /* Transition: '<S13>:69' */
                        guard1 = true;
                    }
                }
            }
            break;

          default:
            /* During 'WaitingForPesData': '<S13>:3' */
            /* '<S13>:41:1' sf_internal_predicateOutput = PesDataTimeout; */
            if (rtu_PesDataTimeout)
            {
                /* Transition: '<S13>:41' */
                /* Transition: '<S13>:40' */
                /* '<S13>:40:2' ReceivePesDataCommand = false */
                /* '<S13>:40:3' AnswerStatus = PesDataSetPcbManufacturingDateStatus_E.PesDataSetPcbManufacturingDateStatus_COMMUNICATION_FAILURE */
                *rty_AnswerStatus =
                    PesDataSetPcbManufacturingDateStatus_COMMUNICATION_FAILURE;

                /* Transition: '<S13>:83' */
                /* Transition: '<S13>:82' */
                /* Transition: '<S13>:75' */
                /* Transition: '<S13>:76' */
                /* Transition: '<S13>:46' */
                /* '<S13>:46:2' SendAnswerCommand = true */
                *rty_SendAnswerCommand = true;

                /* Transition: '<S13>:20' */
                /* Transition: '<S13>:23' */
                /* Transition: '<S13>:26' */
                /* Transition: '<S13>:25' */
                /* '<S13>:25:2' RequestIsOngoing = false */
                *rty_RequestIsOngoing = false;

                /* '<S13>:25:3' ReceivePesDataCommand = false */
                *rty_ReceivePesDataCommand = false;

                /* '<S13>:25:4' WriteOtpCommand = false */
                *rty_WriteOtpCommand = false;

                /* Transition: '<S13>:100' */
                /* Transition: '<S13>:101' */
                /* '<S13>:7:1' sf_internal_predicateOutput = NewRequest; */
                if (rtu_NewRequest)
                {
                    /* Transition: '<S13>:7' */
                    /* Transition: '<S13>:11' */
                    /* '<S13>:11:2' RequestIsOngoing = true */
                    *rty_RequestIsOngoing = true;

                    /* '<S13>:11:3' ReceivePesDataCommand = true */
                    *rty_ReceivePesDataCommand = true;
                    localDW->bitsForTID0.is_c3_HandlePesRequest =
                        HandlePesRequest_IN_WaitingForPesData;
                }
                else
                {
                    /* Transition: '<S13>:103' */
                    localDW->bitsForTID0.is_c3_HandlePesRequest =
                        HandlePesRequest_IN_Idle;
                }
            }
            else
            {
                /* '<S13>:13:1' sf_internal_predicateOutput = ReceivedPesData; */
                if (rtu_ReceivedPesData)
                {
                    /* Transition: '<S13>:13' */
                    /* Transition: '<S13>:29' */
                    /* '<S13>:29:2' ReceivePesDataCommand = false */
                    *rty_ReceivePesDataCommand = false;

                    /* '<S13>:29:3' WriteOtpCommand = true */
                    *rty_WriteOtpCommand = true;
                    localDW->bitsForTID0.is_c3_HandlePesRequest =
                        HandlePesRequest_IN_PerformingWrite;
                }
            }
            break;
        }

        if (guard1)
        {
            /* Transition: '<S13>:46' */
            /* '<S13>:46:2' SendAnswerCommand = true */
            *rty_SendAnswerCommand = true;

            /* Transition: '<S13>:20' */
            /* Transition: '<S13>:23' */
            /* Transition: '<S13>:26' */
            /* Transition: '<S13>:25' */
            /* '<S13>:25:2' RequestIsOngoing = false */
            *rty_RequestIsOngoing = false;

            /* '<S13>:25:3' ReceivePesDataCommand = false */
            *rty_ReceivePesDataCommand = false;

            /* '<S13>:25:4' WriteOtpCommand = false */
            *rty_WriteOtpCommand = false;

            /* Transition: '<S13>:100' */
            /* Transition: '<S13>:101' */
            /* '<S13>:7:1' sf_internal_predicateOutput = NewRequest; */
            if (rtu_NewRequest)
            {
                /* Transition: '<S13>:7' */
                /* Transition: '<S13>:11' */
                /* '<S13>:11:2' RequestIsOngoing = true */
                *rty_RequestIsOngoing = true;

                /* '<S13>:11:3' ReceivePesDataCommand = true */
                *rty_ReceivePesDataCommand = true;
                localDW->bitsForTID0.is_c3_HandlePesRequest =
                    HandlePesRequest_IN_WaitingForPesData;
            }
            else
            {
                /* Transition: '<S13>:103' */
                localDW->bitsForTID0.is_c3_HandlePesRequest =
                    HandlePesRequest_IN_Idle;
            }
        }
    }

    /* End of Chart: '<S2>/SetPcbManufacturingDateAlgorithm' */
}

/* System initialize for atomic system: '<Root>/HandlePesRequestSetData' */
void HandlePesRequest_HandlePesRequestSetData_Init(bool_t
    *rty_waitForPesDataSetPcbManufacturingDateFromConfigurationMaste,
    B_HandlePesRequestSetData_HandlePesRequest_T *localB,
    DW_HandlePesRequestSetData_HandlePesRequest_T *localDW)
{
    /* SystemInitialize for Atomic SubSystem: '<S2>/BuildPesData' */
    HandlePesRequest_BuildPesData_Init(&localDW->BuildPesData);

    /* End of SystemInitialize for SubSystem: '<S2>/BuildPesData' */

    /* SystemInitialize for SignalConversion: '<S2>/Signal Conversion' */
    *rty_waitForPesDataSetPcbManufacturingDateFromConfigurationMaste =
        localB->ReceivePesDataCommand;
}

/* Outputs for atomic system: '<Root>/HandlePesRequestSetData' */
void HandlePesRequest_HandlePesRequestSetData(const
    OtpWritePcbManufacturingDateReply_B *rtu_OtpWritePcbManufacturingDateReply,
    Timebase_t rtu_Timebase, const PesDataSetPcbManufacturingDateReceived_B
    *rtu_SetPcbManufacturingDateFromConfigurationMaster, Timebase_t
    rtu_ReceptionTimeStampPesRequest, bool_t rtu_IsNewRequestSetData, uint16_T
    rtu_Parameter, bool_t rtu_BusyOld, const PesData_C *rtu_PesDataIn, PesData_C
    *rty_PesData, bool_t *rty_BusySetData, OtpWritePcbManufacturingDate_B
    *rty_OtpWritePcbManufacturingDate, bool_t
    *rty_waitForPesDataSetPcbManufacturingDateFromConfigurationMaste,
    B_HandlePesRequestSetData_HandlePesRequest_T *localB, const
    ConstB_HandlePesRequestSetData_HandlePesRequest_T *localC,
    DW_HandlePesRequestSetData_HandlePesRequest_T *localDW)
{
    /* local block i/o variables */
    bool_t rtb_UnitDelay2;
    bool_t rtb_UnitDelay;
    bool_t rtb_RequestIsOngoingOld;
    bool_t rtb_Equal;
    bool_t rtb_Equal_e5v4;
    bool_t rtb_NewRequest;
    bool_t rtb_ReceivedPesData;
    bool_t rtb_ReceivedOtpWriteReply;

    /* UnitDelay: '<S2>/Unit Delay2' */
    rtb_UnitDelay2 = localDW->UnitDelay2_DSTATE;

    /* Outputs for Atomic SubSystem: '<S2>/BufferOtpWriteReply' */
    HandlePesRequest_BufferOtpWriteReply(rtu_OtpWritePcbManufacturingDateReply,
        rtb_UnitDelay2, &rtb_ReceivedOtpWriteReply,
        &localB->BufferedOtpWriteReply, &localDW->BufferOtpWriteReply);

    /* End of Outputs for SubSystem: '<S2>/BufferOtpWriteReply' */

    /* UnitDelay: '<S2>/Unit Delay' */
    rtb_UnitDelay = localDW->UnitDelay_DSTATE;

    /* Outputs for Atomic SubSystem: '<S2>/BufferPesData' */
    HandlePesRequest_BufferPesData
        (rtu_SetPcbManufacturingDateFromConfigurationMaster, rtb_UnitDelay,
         &rtb_ReceivedPesData, &localB->BufferedPesData, &localDW->BufferPesData);

    /* End of Outputs for SubSystem: '<S2>/BufferPesData' */

    /* UnitDelay: '<S2>/Unit Delay1' */
    rtb_RequestIsOngoingOld = localDW->UnitDelay1_DSTATE;

    /* Outputs for Atomic SubSystem: '<S2>/CheckNewRequest' */
    HandlePesRequest_CheckNewRequest(rtu_IsNewRequestSetData, rtu_Parameter,
        rtb_RequestIsOngoingOld, rtu_ReceptionTimeStampPesRequest,
        &rtb_NewRequest, &localB->BufferedReceptionTimePesRequest,
        &localDW->CheckNewRequest);

    /* End of Outputs for SubSystem: '<S2>/CheckNewRequest' */

    /* Outputs for Atomic SubSystem: '<S2>/CheckPayloadTimeout' */
    rtb_Equal_e5v4 = HandlePesRequest_CheckPayloadTimeout(rtu_Timebase,
        localB->BufferedReceptionTimePesRequest, &localC->CheckPayloadTimeout);

    /* End of Outputs for SubSystem: '<S2>/CheckPayloadTimeout' */

    /* Outputs for Atomic SubSystem: '<S2>/CheckWriteTimeout' */
    rtb_Equal = HandlePesRequest_CheckWriteTimeout(rtu_Timebase,
        &localB->BufferedPesData, &localC->CheckWriteTimeout);

    /* End of Outputs for SubSystem: '<S2>/CheckWriteTimeout' */

    /* Chart: '<S2>/SetPcbManufacturingDateAlgorithm' */
    HandlePesRequest_SetPcbManufacturingDateAlgorithm(rtb_NewRequest,
        rtb_Equal_e5v4, rtb_ReceivedOtpWriteReply,
        &localB->BufferedOtpWriteReply, rtb_ReceivedPesData, rtb_Equal,
        &localB->RequestIsOngoing, &localB->ReceivePesDataCommand,
        &localB->WriteOtpCommand, &localB->SendAnswerCommand,
        &localB->AnswerStatus, &localDW->sf_SetPcbManufacturingDateAlgorithm);

    /* Outputs for Atomic SubSystem: '<S2>/BuildOtpWriteRequest' */
    HandlePesRequest_BuildOtpWriteRequest(localB->WriteOtpCommand,
        &localB->BufferedPesData, rty_OtpWritePcbManufacturingDate,
        &localB->BuildOtpWriteRequest, &localDW->BuildOtpWriteRequest);

    /* End of Outputs for SubSystem: '<S2>/BuildOtpWriteRequest' */

    /* Outputs for Atomic SubSystem: '<S2>/BuildPesData' */
    HandlePesRequest_BuildPesData(localB->SendAnswerCommand,
        localB->AnswerStatus, rtu_PesDataIn, rtu_BusyOld, rty_PesData,
        rty_BusySetData, &localB->BuildPesData, &localC->BuildPesData,
        &localDW->BuildPesData);

    /* End of Outputs for SubSystem: '<S2>/BuildPesData' */

    /* SignalConversion: '<S2>/Signal Conversion' */
    *rty_waitForPesDataSetPcbManufacturingDateFromConfigurationMaste =
        localB->ReceivePesDataCommand;
}

/* Update for atomic system: '<Root>/HandlePesRequestSetData' */
void HandlePesRequest_HandlePesRequestSetData_Update
    (B_HandlePesRequestSetData_HandlePesRequest_T *localB,
     DW_HandlePesRequestSetData_HandlePesRequest_T *localDW)
{
    /* Update for UnitDelay: '<S2>/Unit Delay2' */
    localDW->UnitDelay2_DSTATE = localB->WriteOtpCommand;

    /* Update for Atomic SubSystem: '<S2>/BufferOtpWriteReply' */
    HandlePesRequest_BufferOtpWriteReply_Update(&localB->BufferedOtpWriteReply,
        &localDW->BufferOtpWriteReply);

    /* End of Update for SubSystem: '<S2>/BufferOtpWriteReply' */

    /* Update for UnitDelay: '<S2>/Unit Delay' */
    localDW->UnitDelay_DSTATE = localB->ReceivePesDataCommand;

    /* Update for Atomic SubSystem: '<S2>/BufferPesData' */
    HandlePesRequest_BufferPesData_Update(&localB->BufferedPesData,
        &localDW->BufferPesData);

    /* End of Update for SubSystem: '<S2>/BufferPesData' */

    /* Update for UnitDelay: '<S2>/Unit Delay1' */
    localDW->UnitDelay1_DSTATE = localB->RequestIsOngoing;

    /* Update for Atomic SubSystem: '<S2>/CheckNewRequest' */
    HandlePesRequest_CheckNewRequest_Update
        (&localB->BufferedReceptionTimePesRequest, &localDW->CheckNewRequest);

    /* End of Update for SubSystem: '<S2>/CheckNewRequest' */

    /* Update for Atomic SubSystem: '<S2>/BuildOtpWriteRequest' */
    HandlePesRequest_BuildOtpWriteRequest_Update(&localB->BuildOtpWriteRequest,
        &localDW->BuildOtpWriteRequest);

    /* End of Update for SubSystem: '<S2>/BuildOtpWriteRequest' */

    /* Update for Atomic SubSystem: '<S2>/BuildPesData' */
    HandlePesRequest_BuildPesData_Update(&localB->BuildPesData,
        &localDW->BuildPesData);

    /* End of Update for SubSystem: '<S2>/BuildPesData' */
}

/* Output and update for atomic system: '<Root>/IsNewRequestData' */
void HandlePesRequest_IsNewRequestData(const PesRequestNew_C *rtu_PesRequest,
    bool_t rtu_IsNewReception, bool_t *rty_IsNewRequestData)
{
    /* Logic: '<S3>/Logical Operator1' incorporates:
     *  Constant: '<S3>/Unused1'
     *  Constant: '<S3>/Unused2'
     *  Constant: '<S62>/Constant'
     *  Logic: '<S3>/Logical Operator'
     *  RelationalOperator: '<S3>/Relational Operator1'
     *  RelationalOperator: '<S3>/Relational Operator2'
     *  RelationalOperator: '<S3>/Relational Operator3'
     */
    *rty_IsNewRequestData = ((((OpbNodeAddr_CONFIGURATION_MASTER ==
        rtu_PesRequest->RequesterNodeAddr) || (OpbNodeAddr_GECB ==
        rtu_PesRequest->RequesterNodeAddr)) && (PesRequest_Request_E_Data ==
        rtu_PesRequest->Request)) && rtu_IsNewReception);
}

/* Output and update for atomic system: '<Root>/IsNewRequestSetData' */
bool_t HandlePesRequest_IsNewRequestSetData(const PesRequestNew_C
    *rtu_PesRequest, bool_t rtu_IsNewReception)
{
    /* Logic: '<S5>/Logical Operator1' incorporates:
     *  Constant: '<S63>/Constant'
     *  Constant: '<S64>/Constant'
     *  RelationalOperator: '<S5>/Relational Operator1'
     *  RelationalOperator: '<S5>/Relational Operator2'
     */
    return ((OpbNodeAddr_CONFIGURATION_MASTER ==
             rtu_PesRequest->RequesterNodeAddr) && (PesRequest_Request_E_SetData
             == rtu_PesRequest->Request)) && rtu_IsNewReception;
}

/* System initialize for referenced model: 'HandlePesRequest' */
void HandlePesRequest_Init(bool_t
    *rty_waitForPesDataSetPcbManufacturingDateFromConfigurationMaste,
    B_HandlePesRequest_caua_T *localB, DW_HandlePesRequest_fwu4_T *localDW)
{
    /* SystemInitialize for Atomic SubSystem: '<Root>/HandlePesRequestSetData' */
    HandlePesRequest_HandlePesRequestSetData_Init
        (rty_waitForPesDataSetPcbManufacturingDateFromConfigurationMaste,
         &localB->HandlePesRequestSetData, &localDW->HandlePesRequestSetData);

    /* End of SystemInitialize for SubSystem: '<Root>/HandlePesRequestSetData' */

    /* SystemInitialize for ModelReference: '<Root>/HandlePesRequestDataRef' */
    HandlePesRequestData_Init
        (&(localDW->HandlePesRequestDataRef_InstanceData.rtdw));
}

/* Outputs for referenced model: 'HandlePesRequest' */
void HandlePesRequest(const PesRequestNew_C *rtu_PesRequest, const
                      PesDataSetPcbManufacturingDateReceived_B
                      *rtu_SetPcbManufacturingDateFromConfigurationMaster, const
                      PcbInfo_B *rtu_PcbInfo, const
                      OtpWritePcbManufacturingDateReply_B
                      *rtu_OtpWritePcbManufacturingDateReply, Timebase_t
                      rtu_Timebase, PesData_C *rty_PesData,
                      SecurityRequestCryptoChipConfigure_B
                      *rty_SecurityRequestCryptoChipConfigure,
                      SecurityRequestCryptoChipCreateKey_B
                      *rty_SecurityRequestCryptoChipCreateKey,
                      SecurityRequestCryptoChipLockConfig_B
                      *rty_SecurityRequestCryptoChipLockConfig,
                      SecurityRequestOtpActivate_B
                      *rty_SecurityRequestOtpActivate,
                      OtpWritePcbManufacturingDate_B
                      *rty_OtpWritePcbManufacturingDate, bool_t
                      *rty_waitForPesDataSetPcbManufacturingDateFromConfigurationMaste,
                      B_HandlePesRequest_caua_T *localB,
                      DW_HandlePesRequest_fwu4_T *localDW)
{
    /* local block i/o variables */
    PesData_C rtb_PesData_er2v;
    bool_t rtb_RelationalOperator;
    bool_t rtb_BusyData;
    bool_t rtb_IsNewRequestSecurity;
    bool_t rtb_IsNewRequestSetData;
    bool_t rtb_SignalConversion9;

    /* RelationalOperator: '<S1>/Relational Operator' incorporates:
     *  Delay: '<S1>/Delay'
     */
    rtb_RelationalOperator = (rtu_PesRequest->ReceptionTimeStamp !=
        localDW->Delay_DSTATE);

    /* Outputs for Atomic SubSystem: '<Root>/IsNewRequestData' */
    HandlePesRequest_IsNewRequestData(rtu_PesRequest, rtb_RelationalOperator,
        &localB->IsNewRequestData_hz2s);

    /* End of Outputs for SubSystem: '<Root>/IsNewRequestData' */

    /* UnitDelay: '<Root>/Unit Delay' */
    localB->BusyOld = localDW->UnitDelay_DSTATE;

    /* Outputs for Atomic SubSystem: '<Root>/IsNewRequestSetData' */
    rtb_IsNewRequestSetData = HandlePesRequest_IsNewRequestSetData
        (rtu_PesRequest, rtb_RelationalOperator);

    /* End of Outputs for SubSystem: '<Root>/IsNewRequestSetData' */

    /* Outputs for Atomic SubSystem: '<Root>/HandlePesRequestSetData' */

    /* Constant: '<Root>/Unused2' */
    HandlePesRequest_HandlePesRequestSetData
        (rtu_OtpWritePcbManufacturingDateReply, rtu_Timebase,
         rtu_SetPcbManufacturingDateFromConfigurationMaster,
         rtu_PesRequest->ReceptionTimeStamp, rtb_IsNewRequestSetData,
         rtu_PesRequest->Parameter, localB->BusyOld,
         &HandlePesRequest_ConstP.Unused2_Value, &rtb_PesData_er2v,
         &rtb_SignalConversion9, rty_OtpWritePcbManufacturingDate,
         rty_waitForPesDataSetPcbManufacturingDateFromConfigurationMaste,
         &localB->HandlePesRequestSetData,
         &HandlePesRequest_ConstB.HandlePesRequestSetData,
         &localDW->HandlePesRequestSetData);

    /* End of Outputs for SubSystem: '<Root>/HandlePesRequestSetData' */

    /* SignalConversion: '<Root>/Signal Conversion' */
    localB->PesDataIn = rtb_PesData_er2v;

    /* ModelReference: '<Root>/HandlePesRequestDataRef' */
    HandlePesRequestData(rtu_PcbInfo, localB->IsNewRequestData_hz2s,
                         rtu_PesRequest->RequesterNodeAddr,
                         rtu_PesRequest->Parameter, localB->BusyOld,
                         &localB->PesDataIn, rty_PesData, &rtb_BusyData,
                         &(localDW->HandlePesRequestDataRef_InstanceData.rtb),
                         &(localDW->HandlePesRequestDataRef_InstanceData.rtdw));

    /* Logic: '<S4>/Logical Operator1' incorporates:
     *  Constant: '<S4>/Unused1'
     *  Constant: '<S4>/Unused2'
     *  RelationalOperator: '<S4>/Relational Operator1'
     *  RelationalOperator: '<S4>/Relational Operator2'
     */
    rtb_IsNewRequestSecurity = (((OpbNodeAddr_CONFIGURATION_MASTER ==
        rtu_PesRequest->RequesterNodeAddr) && (PesRequest_Request_E_Security ==
        rtu_PesRequest->Request)) && rtb_RelationalOperator);

    /* ModelReference: '<Root>/HandlePesRequestSecurityRef' */
    HandlePesRequestSecurity(rtb_IsNewRequestSecurity, rtu_PesRequest->Parameter,
        rty_SecurityRequestCryptoChipConfigure,
        rty_SecurityRequestCryptoChipCreateKey,
        rty_SecurityRequestCryptoChipLockConfig, rty_SecurityRequestOtpActivate);

    /* Logic: '<Root>/Logical Operator' */
    localB->LogicalOperator = (rtb_BusyData || rtb_SignalConversion9);
}

/* Update for referenced model: 'HandlePesRequest' */
void HandlePesRequest_Update(const PesRequestNew_C *rtu_PesRequest,
    B_HandlePesRequest_caua_T *localB, DW_HandlePesRequest_fwu4_T *localDW)
{
    /* Update for Delay: '<S1>/Delay' */
    localDW->Delay_DSTATE = rtu_PesRequest->ReceptionTimeStamp;

    /* Update for UnitDelay: '<Root>/Unit Delay' */
    localDW->UnitDelay_DSTATE = localB->LogicalOperator;

    /* Update for Atomic SubSystem: '<Root>/HandlePesRequestSetData' */
    HandlePesRequest_HandlePesRequestSetData_Update
        (&localB->HandlePesRequestSetData, &localDW->HandlePesRequestSetData);

    /* End of Update for SubSystem: '<Root>/HandlePesRequestSetData' */

    /* Update for ModelReference: '<Root>/HandlePesRequestDataRef' */
    HandlePesRequestData_Update
        (&(localDW->HandlePesRequestDataRef_InstanceData.rtb),
         &(localDW->HandlePesRequestDataRef_InstanceData.rtdw));
}

/* Model initialize function */
void HandlePesRequest_initialize(B_HandlePesRequest_caua_T *localB,
    DW_HandlePesRequest_fwu4_T *localDW)
{
    /* Registration code */

    /* block I/O */
    {
        localB->PesDataIn = HandlePesRequest_rtZPesData_C;
        localB->HandlePesRequestSetData.BuildPesData.PesDataIdLatched =
            PesDataId_SYSTEM_MANUFACTURER;
    }

    /* Model Initialize function for ModelReference Block: '<Root>/HandlePesRequestDataRef' */
    HandlePesRequestData_initialize
        (&(localDW->HandlePesRequestDataRef_InstanceData.rtb));
}

function CodeDefine() { 
this.def = new Array();
this.def["HandlePesRequest_rtZPesData_C"] = {file: "HandlePesRequest_c.html",line:49,type:"var"};
this.def["HandlePesRequest_ConstP"] = {file: "HandlePesRequest_c.html",line:61,type:"var"};
this.def["HandlePesRequest_ConstB"] = {file: "HandlePesRequest_c.html",line:78,type:"var"};
this.def["HandlePesRequest_BufferOtpWriteReply"] = {file: "HandlePesRequest_c.html",line:116,type:"fcn"};
this.def["HandlePesRequest_BufferOtpWriteReply_Update"] = {file: "HandlePesRequest_c.html",line:147,type:"fcn"};
this.def["HandlePesRequest_BufferPesData"] = {file: "HandlePesRequest_c.html",line:156,type:"fcn"};
this.def["HandlePesRequest_BufferPesData_Update"] = {file: "HandlePesRequest_c.html",line:188,type:"fcn"};
this.def["HandlePesRequest_BuildOtpWriteRequest"] = {file: "HandlePesRequest_c.html",line:197,type:"fcn"};
this.def["HandlePesRequest_BuildOtpWriteRequest_Update"] = {file: "HandlePesRequest_c.html",line:243,type:"fcn"};
this.def["HandlePesRequest_BuildPesData_Init"] = {file: "HandlePesRequest_c.html",line:252,type:"fcn"};
this.def["HandlePesRequest_BuildPesData"] = {file: "HandlePesRequest_c.html",line:260,type:"fcn"};
this.def["HandlePesRequest_BuildPesData_Update"] = {file: "HandlePesRequest_c.html",line:589,type:"fcn"};
this.def["HandlePesRequest_CheckNewRequest"] = {file: "HandlePesRequest_c.html",line:628,type:"fcn"};
this.def["HandlePesRequest_CheckNewRequest_Update"] = {file: "HandlePesRequest_c.html",line:659,type:"fcn"};
this.def["HandlePesRequest_MsToTimebase"] = {file: "HandlePesRequest_c.html",line:672,type:"fcn"};
this.def["HandlePesRequest_CheckPayloadTimeout"] = {file: "HandlePesRequest_c.html",line:762,type:"fcn"};
this.def["HandlePesRequest_CheckWriteTimeout"] = {file: "HandlePesRequest_c.html",line:785,type:"fcn"};
this.def["HandlePesRequest_SetPcbManufacturingDateAlgorithm"] = {file: "HandlePesRequest_c.html",line:807,type:"fcn"};
this.def["HandlePesRequest_HandlePesRequestSetData_Init"] = {file: "HandlePesRequest_c.html",line:1077,type:"fcn"};
this.def["HandlePesRequest_HandlePesRequestSetData"] = {file: "HandlePesRequest_c.html",line:1093,type:"fcn"};
this.def["HandlePesRequest_HandlePesRequestSetData_Update"] = {file: "HandlePesRequest_c.html",line:1188,type:"fcn"};
this.def["HandlePesRequest_IsNewRequestData"] = {file: "HandlePesRequest_c.html",line:1233,type:"fcn"};
this.def["HandlePesRequest_IsNewRequestSetData"] = {file: "HandlePesRequest_c.html",line:1252,type:"fcn"};
this.def["HandlePesRequest_Init"] = {file: "HandlePesRequest_c.html",line:1267,type:"fcn"};
this.def["HandlePesRequest"] = {file: "HandlePesRequest_c.html",line:1284,type:"fcn"};
this.def["HandlePesRequest_Update"] = {file: "HandlePesRequest_c.html",line:1383,type:"fcn"};
this.def["HandlePesRequest_initialize"] = {file: "HandlePesRequest_c.html",line:1405,type:"fcn"};
this.def["PesRequest_Request_E"] = {file: "HandlePesRequest_h.html",line:81,type:"type"};
this.def["PesRequestNew_C"] = {file: "HandlePesRequest_h.html",line:129,type:"type"};
this.def["PcbManufacturingDate_B"] = {file: "HandlePesRequest_h.html",line:140,type:"type"};
this.def["PesDataSetPcbManufacturingDateReceived_B"] = {file: "HandlePesRequest_h.html",line:152,type:"type"};
this.def["PcbInfo_B"] = {file: "HandlePesRequest_h.html",line:172,type:"type"};
this.def["OtpWritePcbManufacturingDateReply_B"] = {file: "HandlePesRequest_h.html",line:185,type:"type"};
this.def["PesData_C"] = {file: "HandlePesRequest_h.html",line:202,type:"type"};
this.def["SecurityRequestCryptoChipConfigure_B"] = {file: "HandlePesRequest_h.html",line:213,type:"type"};
this.def["SecurityRequestCryptoChipCreateKey_B"] = {file: "HandlePesRequest_h.html",line:224,type:"type"};
this.def["SecurityRequestCryptoChipLockConfig_B"] = {file: "HandlePesRequest_h.html",line:235,type:"type"};
this.def["SecurityRequestOtpActivate_B"] = {file: "HandlePesRequest_h.html",line:246,type:"type"};
this.def["OtpWritePcbManufacturingDate_B"] = {file: "HandlePesRequest_h.html",line:260,type:"type"};
this.def["PesDataId_E"] = {file: "HandlePesRequest_h.html",line:267,type:"type"};
this.def["PesRequestSetData_E"] = {file: "HandlePesRequest_h.html",line:304,type:"type"};
this.def["PesDataSetPcbManufacturingDateStatus_E"] = {file: "HandlePesRequest_h.html",line:311,type:"type"};
this.def["DW_BufferOtpWriteReply_HandlePesRequest_T"] = {file: "HandlePesRequest_h.html",line:324,type:"type"};
this.def["DW_BufferPesData_HandlePesRequest_T"] = {file: "HandlePesRequest_h.html",line:331,type:"type"};
this.def["B_BuildOtpWriteRequest_HandlePesRequest_T"] = {file: "HandlePesRequest_h.html",line:338,type:"type"};
this.def["DW_BuildOtpWriteRequest_HandlePesRequest_T"] = {file: "HandlePesRequest_h.html",line:345,type:"type"};
this.def["B_BuildPesData_HandlePesRequest_T"] = {file: "HandlePesRequest_h.html",line:360,type:"type"};
this.def["DW_BuildPesData_HandlePesRequest_T"] = {file: "HandlePesRequest_h.html",line:375,type:"type"};
this.def["DW_CheckNewRequest_HandlePesRequest_T"] = {file: "HandlePesRequest_h.html",line:382,type:"type"};
this.def["DW_SetPcbManufacturingDateAlgorithm_HandlePesRequest_T"] = {file: "HandlePesRequest_h.html",line:396,type:"type"};
this.def["B_HandlePesRequestSetData_HandlePesRequest_T"] = {file: "HandlePesRequest_h.html",line:413,type:"type"};
this.def["DW_HandlePesRequestSetData_HandlePesRequest_T"] = {file: "HandlePesRequest_h.html",line:430,type:"type"};
this.def["B_HandlePesRequest_caua_T"] = {file: "HandlePesRequest_h.html",line:441,type:"type"};
this.def["DW_HandlePesRequest_fwu4_T"] = {file: "HandlePesRequest_h.html",line:451,type:"type"};
this.def["ConstB_BuildPesData_HandlePesRequest_T"] = {file: "HandlePesRequest_h.html",line:463,type:"type"};
this.def["ConstB_CheckPayloadTimeout_HandlePesRequest_T"] = {file: "HandlePesRequest_h.html",line:472,type:"type"};
this.def["ConstB_CheckWriteTimeout_HandlePesRequest_T"] = {file: "HandlePesRequest_h.html",line:480,type:"type"};
this.def["ConstB_HandlePesRequestSetData_HandlePesRequest_T"] = {file: "HandlePesRequest_h.html",line:489,type:"type"};
this.def["ConstB_HandlePesRequest_hb4t_T"] = {file: "HandlePesRequest_h.html",line:496,type:"type"};
this.def["ConstP_HandlePesRequest_T"] = {file: "HandlePesRequest_h.html",line:506,type:"type"};
this.def["MdlrefDW_HandlePesRequest_T"] = {file: "HandlePesRequest_h.html",line:513,type:"type"};
this.def["OpbNodeAddr_E"] = {file: "../../_sharedutils/html/OpbNodeAddr_h.html",line:25,type:"type"};
this.def["Timebase_t"] = {file: "../../_sharedutils/html/Timebase_t_h.html",line:18,type:"type"};
this.def["int8_T"] = {file: "../../_sharedutils/html/rtwtypes_h.html",line:41,type:"type"};
this.def["uint8_T"] = {file: "../../_sharedutils/html/rtwtypes_h.html",line:42,type:"type"};
this.def["int16_T"] = {file: "../../_sharedutils/html/rtwtypes_h.html",line:43,type:"type"};
this.def["uint16_T"] = {file: "../../_sharedutils/html/rtwtypes_h.html",line:44,type:"type"};
this.def["int32_T"] = {file: "../../_sharedutils/html/rtwtypes_h.html",line:45,type:"type"};
this.def["uint32_T"] = {file: "../../_sharedutils/html/rtwtypes_h.html",line:46,type:"type"};
this.def["int64_T"] = {file: "../../_sharedutils/html/rtwtypes_h.html",line:47,type:"type"};
this.def["uint64_T"] = {file: "../../_sharedutils/html/rtwtypes_h.html",line:48,type:"type"};
this.def["boolean_T"] = {file: "../../_sharedutils/html/rtwtypes_h.html",line:54,type:"type"};
this.def["int_T"] = {file: "../../_sharedutils/html/rtwtypes_h.html",line:55,type:"type"};
this.def["uint_T"] = {file: "../../_sharedutils/html/rtwtypes_h.html",line:56,type:"type"};
this.def["ulong_T"] = {file: "../../_sharedutils/html/rtwtypes_h.html",line:57,type:"type"};
this.def["ulonglong_T"] = {file: "../../_sharedutils/html/rtwtypes_h.html",line:58,type:"type"};
this.def["char_T"] = {file: "../../_sharedutils/html/rtwtypes_h.html",line:59,type:"type"};
this.def["uchar_T"] = {file: "../../_sharedutils/html/rtwtypes_h.html",line:60,type:"type"};
this.def["byte_T"] = {file: "../../_sharedutils/html/rtwtypes_h.html",line:61,type:"type"};
this.def["pointer_T"] = {file: "../../_sharedutils/html/rtwtypes_h.html",line:82,type:"type"};
}
CodeDefine.instance = new CodeDefine();
var testHarnessInfo = {OwnerFileName: "", HarnessOwner: "", HarnessName: "", IsTestHarness: "0"};
var relPathToBuildDir = "../ert_main.c";
var fileSep = "\\";
var isPC = true;
function Html2SrcLink() {
	this.html2SrcPath = new Array;
	this.html2Root = new Array;
	this.html2SrcPath["HandlePesRequest_c.html"] = "../HandlePesRequest.c";
	this.html2Root["HandlePesRequest_c.html"] = "HandlePesRequest_c.html";
	this.html2SrcPath["HandlePesRequest_h.html"] = "../HandlePesRequest.h";
	this.html2Root["HandlePesRequest_h.html"] = "HandlePesRequest_h.html";
	this.html2SrcPath["OpbNodeAddr_h.html"] = "../OpbNodeAddr.h";
	this.html2Root["OpbNodeAddr_h.html"] = "../../_sharedutils/html/OpbNodeAddr_h.html";
	this.html2SrcPath["Timebase_t_h.html"] = "../Timebase_t.h";
	this.html2Root["Timebase_t_h.html"] = "../../_sharedutils/html/Timebase_t_h.html";
	this.html2SrcPath["rtwtypes_h.html"] = "../rtwtypes.h";
	this.html2Root["rtwtypes_h.html"] = "../../_sharedutils/html/rtwtypes_h.html";
	this.getLink2Src = function (htmlFileName) {
		 if (this.html2SrcPath[htmlFileName])
			 return this.html2SrcPath[htmlFileName];
		 else
			 return null;
	}
	this.getLinkFromRoot = function (htmlFileName) {
		 if (this.html2Root[htmlFileName])
			 return this.html2Root[htmlFileName];
		 else
			 return null;
	}
}
Html2SrcLink.instance = new Html2SrcLink();
var fileList = [
"HandlePesRequest_c.html","HandlePesRequest_h.html","OpbNodeAddr_h.html","Timebase_t_h.html","rtwtypes_h.html"];

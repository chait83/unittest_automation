/*
 * ---------------------------------------------------------------------------
 * Copyright (c) 2015 UTC - All rights reserved.
 *
 * Model Name:         HandlePesRequestData
 * Code Generation:     -
 * Svn:
 * ---------------------------------------------------------------------------
 */

#include "HandlePesRequestData.h"

/* user code (top of source file) */

/* *****************************************************************************/
/* **                _______   _________  _________   _______                 **/
/* **               (  ___  )  \__   __/  \__   __/  (  ____ \                **/
/* **               | (   ) |     ) (        ) (     | (    \/                **/
/* **               | |   | |     | |        | |     | (_____                 **/
/* **               | |   | |     | |        | |     (_____  )                **/
/* **               | |   | |     | |        | |           ) |                **/
/* **               | (___) |     | |     ___) (___  /\____) |                **/
/* **               (_______)     )_(     \_______/  \_______)                **/
/* **                                                                         **/
/* **                      OTIS Lead Design Center Berlin                     **/
/* **                                                                         **/
/* **   Copyright 2020 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **/
/* **                                                                         **/
/* *****************************************************************************/
/* **                                                                         **/
/* ** Simulink Model                                                          **/
/* **                                                                         **/
/* ** Purpose                                                                 **/
/* **  Model of Functional Safety Logic of the Pessral System                 **/
/* **                                                                         **/
/* ** Functionality                                                           **/
/* **  This is one of the source files auto-generated from the Simulink Model **/
/* **  with the help of the Simulink Embedded Coder.                          **/
/* **                                                                         **/
/* **                    DO NOT MANUALLY CHANGE THIS FILE                     **/
/* **                    ================================                     **/
/* **                                                                         **/
/* *****************************************************************************/

/* Invariant block signals (default storage) */
const ConstB_HandlePesRequestData_hb4t_T HandlePesRequestData_ConstB =
{
    6U,                                /* '<S1>/Signal Conversion2' */
    6U,                                /* '<S9>/Signal Conversion2' */
    6U,                                /* '<S10>/uint8_boolean' */
    0U,                                /* '<S10>/Math Function' */
    7U,                                /* '<S1>/uint8_boolean' */
    6U,                                /* '<S2>/Signal Conversion2' */
    6U,                                /* '<S44>/Signal Conversion2' */
    6U,                                /* '<S45>/uint8_boolean' */
    0U,                                /* '<S45>/Math Function' */
    6U,                                /* '<S2>/uint8_boolean' */
    36U,                               /* '<S3>/Signal Conversion2' */
    36U,                               /* '<S79>/Signal Conversion2' */
    6U,                                /* '<S80>/uint8_boolean' */
    0U,                                /* '<S80>/Math Function' */
    5U,                                /* '<S3>/uint8_boolean' */
    36U,                               /* '<S4>/Signal Conversion2' */
    36U,                               /* '<S114>/Signal Conversion2' */
    6U,                                /* '<S115>/uint8_boolean' */
    0U,                                /* '<S115>/Math Function' */
    2U,                                /* '<S4>/uint8_boolean' */
    36U,                               /* '<S5>/Signal Conversion2' */
    36U,                               /* '<S149>/Signal Conversion2' */
    6U,                                /* '<S150>/uint8_boolean' */
    0U,                                /* '<S150>/Math Function' */
    3U,                                /* '<S5>/uint8_boolean' */
    18U,                               /* '<S6>/Signal Conversion2' */
    18U,                               /* '<S184>/Signal Conversion2' */
    6U,                                /* '<S185>/uint8_boolean' */
    0U,                                /* '<S185>/Math Function' */
    4U,                                /* '<S6>/uint8_boolean' */
    36U,                               /* '<S7>/Signal Conversion2' */
    36U,                               /* '<S219>/Signal Conversion2' */
    6U,                                /* '<S220>/uint8_boolean' */
    0U,                                /* '<S220>/Math Function' */
    1U,                                /* '<S7>/uint8_boolean' */
    PesDataId_PCB_MANUFACTURING_DATE,  /* '<S1>/Signal Conversion4' */
    PesDataId_PCB_MANUFACTURING_DATE,  /* '<S9>/Signal Conversion4' */
    PesDataId_MISSION_TIME,            /* '<S2>/Signal Conversion4' */
    PesDataId_MISSION_TIME,            /* '<S44>/Signal Conversion4' */
    PesDataId_PCB_MANUFACTURER,        /* '<S3>/Signal Conversion4' */
    PesDataId_PCB_MANUFACTURER,        /* '<S79>/Signal Conversion4' */
    PesDataId_SAFETY_SYSTEM_TYPE,      /* '<S4>/Signal Conversion4' */
    PesDataId_SAFETY_SYSTEM_TYPE,      /* '<S114>/Signal Conversion4' */
    PesDataId_EXAMINATION_CERTIFICATE, /* '<S5>/Signal Conversion4' */
    PesDataId_EXAMINATION_CERTIFICATE, /* '<S149>/Signal Conversion4' */
    PesDataId_PCB_PART_NUMBER,         /* '<S6>/Signal Conversion4' */
    PesDataId_PCB_PART_NUMBER,         /* '<S184>/Signal Conversion4' */
    PesDataId_SYSTEM_MANUFACTURER,     /* '<S7>/Signal Conversion4' */
    PesDataId_SYSTEM_MANUFACTURER,     /* '<S219>/Signal Conversion4' */
    1U,                                /* '<S14>/Compare' */
    1U,                                /* '<S49>/Compare' */
    1U,                                /* '<S84>/Compare' */
    1U,                                /* '<S119>/Compare' */
    1U,                                /* '<S154>/Compare' */
    1U,                                /* '<S189>/Compare' */
    1U                                 /* '<S224>/Compare' */
};

/*
 * Output and update for atomic system:
 *    '<S26>/MatlabFunctionCall'
 *    '<S61>/MatlabFunctionCall'
 */
void HandlePesRequestData_MatlabFunctionCall(const uint8_T rtu_data[6], uint16_T
    rtu_length, uint32_T *rty_Crc32)
{
    uint8_T rtu_data_0[6];
    int32_T i;

    /* MATLAB Function 'CalculateCrc32/MatlabFunctionCall': '<S29>:1' */
    /* '<S29>:1:3' if (coder.target('Sfun')) */
    /* '<S29>:1:8' else */
    /*  embedded coder ------------------------------------------------- */
    /* '<S29>:1:10' coder.cinclude('Hlp/Crc32.h'); */
    /*  invoke C function */
    /* '<S29>:1:13' Crc32 = coder.ceval('HlpCrc32_Calculate16BitLength', data, length); */
    for (i = 0; i < 6; i++)
    {
        rtu_data_0[i] = rtu_data[i];
    }

    *rty_Crc32 = HlpCrc32_Calculate16BitLength(rtu_data_0, rtu_length);
}

/*
 * Output and update for atomic system:
 *    '<S30>/Bit Shift1'
 *    '<S65>/Bit Shift1'
 *    '<S100>/Bit Shift1'
 *    '<S135>/Bit Shift1'
 *    '<S170>/Bit Shift1'
 *    '<S205>/Bit Shift1'
 *    '<S240>/Bit Shift1'
 */
uint16_T HandlePesRequestData_BitShift1(uint16_T rtu_u)
{
    /* MATLAB Function: '<S31>/bit_shift' */
    /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S33>:1' */
    /* '<S33>:1:4' switch mode */
    /* '<S33>:1:7' case 2 */
    /* '<S33>:1:8' y = bitsrl(cast_to_fi(u), N); */
    return (uint16_T)(((uint32_T)rtu_u) >> ((uint64_T)8));
}

/*
 * Output and update for atomic system:
 *    '<S30>/Bit Shift2'
 *    '<S65>/Bit Shift2'
 *    '<S100>/Bit Shift2'
 *    '<S135>/Bit Shift2'
 *    '<S170>/Bit Shift2'
 *    '<S205>/Bit Shift2'
 *    '<S240>/Bit Shift2'
 */
uint16_T HandlePesRequestData_BitShift2(uint16_T rtu_u)
{
    /* MATLAB Function: '<S32>/bit_shift' */
    /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S34>:1' */
    /* '<S34>:1:4' switch mode */
    /* '<S34>:1:7' case 2 */
    /* '<S34>:1:8' y = bitsrl(cast_to_fi(u), N); */
    return rtu_u;
}

/*
 * Output and update for atomic system:
 *    '<S35>/Bit Shift1'
 *    '<S70>/Bit Shift1'
 *    '<S105>/Bit Shift1'
 *    '<S140>/Bit Shift1'
 *    '<S175>/Bit Shift1'
 *    '<S210>/Bit Shift1'
 *    '<S245>/Bit Shift1'
 */
uint32_T HandlePesRequestData_BitShift1_llun(uint32_T rtu_u)
{
    /* MATLAB Function: '<S36>/bit_shift' */
    /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S40>:1' */
    /* '<S40>:1:4' switch mode */
    /* '<S40>:1:7' case 2 */
    /* '<S40>:1:8' y = bitsrl(cast_to_fi(u), N); */
    return rtu_u >> ((uint64_T)8);
}

/*
 * Output and update for atomic system:
 *    '<S35>/Bit Shift2'
 *    '<S70>/Bit Shift2'
 *    '<S105>/Bit Shift2'
 *    '<S140>/Bit Shift2'
 *    '<S175>/Bit Shift2'
 *    '<S210>/Bit Shift2'
 *    '<S245>/Bit Shift2'
 */
uint32_T HandlePesRequestData_BitShift2_jycu(uint32_T rtu_u)
{
    /* MATLAB Function: '<S37>/bit_shift' */
    /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S41>:1' */
    /* '<S41>:1:4' switch mode */
    /* '<S41>:1:7' case 2 */
    /* '<S41>:1:8' y = bitsrl(cast_to_fi(u), N); */
    return rtu_u;
}

/*
 * Output and update for atomic system:
 *    '<S35>/Bit Shift3'
 *    '<S70>/Bit Shift3'
 *    '<S105>/Bit Shift3'
 *    '<S140>/Bit Shift3'
 *    '<S175>/Bit Shift3'
 *    '<S210>/Bit Shift3'
 *    '<S245>/Bit Shift3'
 */
uint32_T HandlePesRequestData_BitShift3(uint32_T rtu_u)
{
    /* MATLAB Function: '<S38>/bit_shift' */
    /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S42>:1' */
    /* '<S42>:1:4' switch mode */
    /* '<S42>:1:7' case 2 */
    /* '<S42>:1:8' y = bitsrl(cast_to_fi(u), N); */
    return rtu_u >> ((uint64_T)16);
}

/*
 * Output and update for atomic system:
 *    '<S35>/Bit Shift4'
 *    '<S70>/Bit Shift4'
 *    '<S105>/Bit Shift4'
 *    '<S140>/Bit Shift4'
 *    '<S175>/Bit Shift4'
 *    '<S210>/Bit Shift4'
 *    '<S245>/Bit Shift4'
 */
uint32_T HandlePesRequestData_BitShift4(uint32_T rtu_u)
{
    /* MATLAB Function: '<S39>/bit_shift' */
    /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S43>:1' */
    /* '<S43>:1:4' switch mode */
    /* '<S43>:1:7' case 2 */
    /* '<S43>:1:8' y = bitsrl(cast_to_fi(u), N); */
    return rtu_u >> ((uint64_T)24);
}

/*
 * Output and update for atomic system:
 *    '<S96>/MatlabFunctionCall'
 *    '<S131>/MatlabFunctionCall'
 *    '<S166>/MatlabFunctionCall'
 *    '<S236>/MatlabFunctionCall'
 */
void HandlePesRequestData_MatlabFunctionCall_i5sj(const uint8_T rtu_data[36],
    uint16_T rtu_length, uint32_T *rty_Crc32)
{
    uint8_T rtu_data_0[36];
    int32_T i;

    /* MATLAB Function 'CalculateCrc32/MatlabFunctionCall': '<S99>:1' */
    /* '<S99>:1:3' if (coder.target('Sfun')) */
    /* '<S99>:1:8' else */
    /*  embedded coder ------------------------------------------------- */
    /* '<S99>:1:10' coder.cinclude('Hlp/Crc32.h'); */
    /*  invoke C function */
    /* '<S99>:1:13' Crc32 = coder.ceval('HlpCrc32_Calculate16BitLength', data, length); */
    for (i = 0; i < 36; i++)
    {
        rtu_data_0[i] = rtu_data[i];
    }

    *rty_Crc32 = HlpCrc32_Calculate16BitLength(rtu_data_0, rtu_length);
}

/* System initialize for referenced model: 'HandlePesRequestData' */
void HandlePesRequestData_Init(DW_HandlePesRequestData_fwu4_T *localDW)
{
    /* InitializeConditions for UnitDelay: '<S11>/Unit Delay3' */
    localDW->UnitDelay3_DSTATE = PesDataId_None;

    /* InitializeConditions for UnitDelay: '<S46>/Unit Delay3' */
    localDW->UnitDelay3_DSTATE_ix02 = PesDataId_None;

    /* InitializeConditions for UnitDelay: '<S81>/Unit Delay3' */
    localDW->UnitDelay3_DSTATE_ckas = PesDataId_None;

    /* InitializeConditions for UnitDelay: '<S116>/Unit Delay3' */
    localDW->UnitDelay3_DSTATE_bm3i = PesDataId_None;

    /* InitializeConditions for UnitDelay: '<S151>/Unit Delay3' */
    localDW->UnitDelay3_DSTATE_k43c = PesDataId_None;

    /* InitializeConditions for UnitDelay: '<S186>/Unit Delay3' */
    localDW->UnitDelay3_DSTATE_nu0k = PesDataId_None;

    /* InitializeConditions for UnitDelay: '<S221>/Unit Delay3' */
    localDW->UnitDelay3_DSTATE_mpus = PesDataId_None;
}

/* Outputs for referenced model: 'HandlePesRequestData' */
void HandlePesRequestData(const PcbInfo_B *rtu_PcbInfo, bool_t
    rtu_IsNewRequestData, OpbNodeAddr_E rtu_RequesterNodeAddr, uint16_T
    rtu_Parameter, bool_t rtu_BusyOld, const PesData_C *rtu_PesDataIn, PesData_C
    *rty_PesData, bool_t *rty_BusyData, B_HandlePesRequestData_caua_T *localB,
    DW_HandlePesRequestData_fwu4_T *localDW)
{
    /* local block i/o variables */
    uint32_T rtb_Uint32;
    uint32_T rtb_Uint32_fxzn;
    uint32_T rtb_Uint32_cuw4;
    uint32_T rtb_Uint32_dkis;
    uint32_T rtb_Uint32_bfzd;
    uint32_T rtb_Uint32_msw4;
    uint32_T rtb_Uint32_nakg;
    uint32_T rtb_y;
    uint32_T rtb_y_dcue;
    uint32_T rtb_y_gk5b;
    uint32_T rtb_y_icwy;
    uint32_T rtb_Crc32;
    uint32_T rtb_y_hzzr;
    uint32_T rtb_y_nfcz;
    uint32_T rtb_y_apym;
    uint32_T rtb_y_ofuc;
    uint32_T rtb_y_ktlp;
    uint32_T rtb_y_kbdv;
    uint32_T rtb_y_obcg;
    uint32_T rtb_y_nfoj;
    uint32_T rtb_Crc32_pai3;
    uint32_T rtb_y_nfbv;
    uint32_T rtb_y_ocqs;
    uint32_T rtb_y_hfle;
    uint32_T rtb_y_cfob;
    uint32_T rtb_Crc32_pk0z;
    uint32_T rtb_y_n2ws;
    uint32_T rtb_y_exwq;
    uint32_T rtb_y_lhej;
    uint32_T rtb_y_ltis;
    uint32_T rtb_Crc32_ftfd;
    uint32_T rtb_y_az2y;
    uint32_T rtb_y_k22g;
    uint32_T rtb_y_en41;
    uint32_T rtb_y_bfmr;
    uint32_T rtb_Crc32_kuxu;
    uint32_T rtb_y_nsrc;
    uint32_T rtb_y_pt0r;
    uint32_T rtb_y_ldtz;
    uint32_T rtb_y_afrl;
    uint32_T rtb_Crc32_hfbk;
    uint16_T rtb_Uint16;
    uint16_T rtb_Length;
    uint16_T rtb_Uint16_nvcw;
    uint16_T rtb_Length_bvup;
    uint16_T rtb_Uint16_f21n;
    uint16_T rtb_Length_ez22;
    uint16_T rtb_Uint16_bxpj;
    uint16_T rtb_Length_pbxz;
    uint16_T rtb_Uint16_h1sr;
    uint16_T rtb_Length_marn;
    uint16_T rtb_Uint16_p4ia;
    uint16_T rtb_Uint16_oifs;
    uint16_T rtb_Length_mnta;
    uint16_T rtb_y_pctd;
    uint16_T rtb_y_lqsb;
    uint16_T rtb_y_arqy;
    uint16_T rtb_y_go0w;
    uint16_T rtb_y_ge1k;
    uint16_T rtb_y_nj0x;
    uint16_T rtb_y_d5sy;
    uint16_T rtb_y_oncc;
    uint16_T rtb_y_nlei;
    uint16_T rtb_y_iq15;
    uint16_T rtb_y_i5q5;
    uint16_T rtb_y_fdak;
    uint16_T rtb_y_jumj;
    uint16_T rtb_y_ei0m;
    uint8_T rtb_Data[6];
    uint8_T rtb_Data_nxc5[6];
    uint8_T rtb_Data_kyhu[36];
    uint8_T rtb_Data_fwf3[36];
    uint8_T rtb_Data_izzq[36];
    uint8_T rtb_Data_fgmn[36];
    bool_t rtb_SendHeader;
    bool_t rtb_LogicalOperator_edxo;
    bool_t rtb_NoReset;
    bool_t rtb_Busy;
    uint8_T rtb_Data_nmj0[6];
    bool_t rtb_IsNewRequestFromGecb;
    bool_t rtb_SendHeader_k22x;
    bool_t rtb_LogicalOperator_ey4q;
    bool_t rtb_NoReset_gslk;
    bool_t rtb_Busy_jtgs;
    uint8_T rtb_Data_h0vb[6];
    bool_t rtb_SendHeader_o30o;
    bool_t rtb_LogicalOperator_gxvx;
    bool_t rtb_NoReset_kd5d;
    bool_t rtb_Busy_lntr;
    uint8_T rtb_Data_ov5q[6];
    bool_t rtb_SendHeader_emxy;
    bool_t rtb_LogicalOperator_gn0u;
    bool_t rtb_NoReset_dizi;
    bool_t rtb_Busy_lemt;
    uint8_T rtb_Data_feal[6];
    bool_t rtb_SendHeader_h3le;
    bool_t rtb_LogicalOperator_iueu;
    bool_t rtb_NoReset_f0k3;
    bool_t rtb_Busy_bzxf;
    uint8_T rtb_Data_i1qt[6];
    bool_t rtb_SendHeader_nmps;
    bool_t rtb_LogicalOperator_pwgp;
    bool_t rtb_NoReset_fgq1;
    bool_t rtb_Busy_n5fp;
    uint8_T rtb_Data_autm[6];
    bool_t rtb_SendHeader_c3cc;
    bool_t rtb_LogicalOperator_izy4;
    bool_t rtb_NoReset_lqry;
    bool_t rtb_Busy_lxks;
    uint8_T rtb_Data_fp3n[6];
    uint8_T rtb_PesData_hbel_Data[6];
    int32_T i;
    uint8_T tmp[18];
    uint8_T tmp_0;
    bool_t rtb_SendHeader_tmp;

    /* SignalConversion: '<S15>/Signal Conversion' incorporates:
     *  Logic: '<Root>/Logical Operator1'
     *  Logic: '<S1>/Logical Operator2'
     *  RelationalOperator: '<S1>/Relational Operator1'
     *  SignalConversion: '<Root>/Signal Conversion4'
     *  SignalConversion: '<S1>/Signal Conversion3'
     */
    localB->SignalConversion = ((HandlePesRequestData_ConstB.uint8_boolean_okxj ==
        rtu_Parameter) && ((rtu_PcbInfo->PcbManufacturingDateIsValid) &&
                           rtu_IsNewRequestData));

    /* SignalConversion: '<Root>/Signal Conversion1' */
    rtb_SendHeader_tmp = !rtu_BusyOld;

    /* Logic: '<S10>/Logical Operator2' incorporates:
     *  Constant: '<S16>/Constant'
     *  Delay: '<S15>/Delay'
     *  Logic: '<S10>/Logical Operator1'
     *  Logic: '<S15>/Logical Operator'
     *  Logic: '<S9>/Logical Operator3'
     *  RelationalOperator: '<S15>/Relational Operator'
     *  RelationalOperator: '<S16>/Compare'
     *  SignalConversion: '<Root>/Signal Conversion1'
     *  UnitDelay: '<S9>/Unit Delay'
     */
    rtb_SendHeader = ((((localB->SignalConversion == true) &&
                        (localB->SignalConversion != localDW->Delay_DSTATE)) &&
                       (((int32_T)HandlePesRequestData_ConstB.Compare) != 0)) &&
                      (rtb_SendHeader_tmp && (!localDW->UnitDelay_DSTATE_mbfm)));

    /* Switch: '<S11>/Switch1' incorporates:
     *  SignalConversion: '<S9>/Signal Conversion8'
     *  UnitDelay: '<S11>/Unit Delay3'
     */
    if (rtb_SendHeader)
    {
        localB->PesDataIdLatched = HandlePesRequestData_ConstB.PesDataId_cnrq;
    }
    else
    {
        localB->PesDataIdLatched = localDW->UnitDelay3_DSTATE;
    }

    /* End of Switch: '<S11>/Switch1' */

    /* SignalConversion: '<S27>/Signal Conversion4' incorporates:
     *  DataTypeConversion: '<S13>/uint8_boolean'
     */
    rtb_Uint16 = (uint16_T)localB->PesDataIdLatched;

    /* Outputs for Atomic SubSystem: '<S30>/Bit Shift1' */
    rtb_y_ei0m = HandlePesRequestData_BitShift1(rtb_Uint16);

    /* End of Outputs for SubSystem: '<S30>/Bit Shift1' */

    /* Outputs for Atomic SubSystem: '<S30>/Bit Shift2' */
    rtb_y_jumj = HandlePesRequestData_BitShift2(rtb_Uint16);

    /* End of Outputs for SubSystem: '<S30>/Bit Shift2' */

    /* Switch: '<S11>/Switch2' incorporates:
     *  SignalConversion: '<S1>/Signal Conversion1'
     *  SignalConversion: '<S9>/Signal Conversion8'
     *  UnitDelay: '<S11>/Unit Delay1'
     */
    for (i = 0; i < 6; i++)
    {
        if (rtb_SendHeader)
        {
            localB->Switch2[i] = rtu_PcbInfo->PcbManufacturingDate.raw[i];
        }
        else
        {
            localB->Switch2[i] = localDW->UnitDelay1_DSTATE[i];
        }
    }

    /* End of Switch: '<S11>/Switch2' */

    /* SignalConversion: '<S26>/Signal Conversion4' */
    for (i = 0; i < 6; i++)
    {
        rtb_Data[i] = localB->Switch2[i];
    }

    /* End of SignalConversion: '<S26>/Signal Conversion4' */

    /* Switch: '<S11>/Switch3' incorporates:
     *  SignalConversion: '<S9>/Signal Conversion8'
     *  UnitDelay: '<S11>/Unit Delay2'
     */
    if (rtb_SendHeader)
    {
        localB->Switch3 = HandlePesRequestData_ConstB.Length_fic3;
    }
    else
    {
        localB->Switch3 = localDW->UnitDelay2_DSTATE;
    }

    /* End of Switch: '<S11>/Switch3' */

    /* SignalConversion: '<S26>/Signal Conversion1' */
    rtb_Length = localB->Switch3;

    /* MATLAB Function: '<S26>/MatlabFunctionCall' */
    HandlePesRequestData_MatlabFunctionCall(rtb_Data, rtb_Length,
        &rtb_Crc32_hfbk);

    /* SignalConversion: '<S28>/Signal Conversion4' incorporates:
     *  SignalConversion: '<S26>/Signal Conversion2'
     */
    rtb_Uint32 = rtb_Crc32_hfbk;

    /* Outputs for Atomic SubSystem: '<S35>/Bit Shift4' */
    rtb_y_nsrc = HandlePesRequestData_BitShift4(rtb_Uint32);

    /* End of Outputs for SubSystem: '<S35>/Bit Shift4' */

    /* Outputs for Atomic SubSystem: '<S35>/Bit Shift3' */
    rtb_y_pt0r = HandlePesRequestData_BitShift3(rtb_Uint32);

    /* End of Outputs for SubSystem: '<S35>/Bit Shift3' */

    /* Outputs for Atomic SubSystem: '<S35>/Bit Shift1' */
    rtb_y_afrl = HandlePesRequestData_BitShift1_llun(rtb_Uint32);

    /* End of Outputs for SubSystem: '<S35>/Bit Shift1' */

    /* Outputs for Atomic SubSystem: '<S35>/Bit Shift2' */
    rtb_y_ldtz = HandlePesRequestData_BitShift2_jycu(rtb_Uint32);

    /* End of Outputs for SubSystem: '<S35>/Bit Shift2' */

    /* SignalConversion: '<S19>/Signal Conversion' */
    localB->SignalConversion_pamv = rtb_SendHeader;

    /* Logic: '<S19>/Logical Operator' incorporates:
     *  Constant: '<S25>/Constant'
     *  Delay: '<S19>/Delay'
     *  RelationalOperator: '<S19>/Relational Operator'
     *  RelationalOperator: '<S25>/Compare'
     */
    rtb_LogicalOperator_edxo = ((localB->SignalConversion_pamv == false) &&
        (localB->SignalConversion_pamv != localDW->Delay_DSTATE_mouf));

    /* SignalConversion: '<S23>/Signal Conversion' incorporates:
     *  Constant: '<S18>/Unused'
     *  Logic: '<S18>/Logical Operator1'
     *  Logic: '<S18>/Logical Operator2'
     *  Logic: '<S18>/Logical Operator3'
     *  RelationalOperator: '<S18>/Relational Operator1'
     *  SignalConversion: '<S19>/Signal Conversion1'
     *  Sum: '<S18>/Add1'
     *  UnitDelay: '<S12>/Unit Delay'
     */
    localB->SignalConversion_h52q = (((((uint16_T)((uint8_T)(((uint32_T)
        ((uint8_T)6U)) + ((uint32_T)localDW->UnitDelay_DSTATE)))) >=
        localB->Switch3) && (!rtb_SendHeader)) && (!rtb_LogicalOperator_edxo));

    /* Logic: '<S22>/Logical Operator2' incorporates:
     *  Constant: '<S24>/Constant'
     *  Delay: '<S23>/Delay'
     *  Logic: '<S23>/Logical Operator'
     *  RelationalOperator: '<S23>/Relational Operator'
     *  RelationalOperator: '<S24>/Compare'
     */
    rtb_NoReset = ((localB->SignalConversion_h52q != true) ||
                   (localB->SignalConversion_h52q == localDW->Delay_DSTATE_kpxz));

    /* Logic: '<S22>/Logical Operator3' incorporates:
     *  Logic: '<S22>/Logical Operator1'
     *  Logic: '<S22>/Logical Operator4'
     *  SignalConversion: '<S19>/Signal Conversion1'
     *  UnitDelay: '<S22>/Unit Delay1'
     */
    localB->Out = ((rtb_LogicalOperator_edxo && rtb_NoReset) || (rtb_NoReset &&
                    (localDW->UnitDelay1_DSTATE_cybj)));

    /* Logic: '<S12>/Logical Operator3' incorporates:
     *  SignalConversion: '<S22>/Signal Conversion2'
     */
    rtb_Busy = (rtb_SendHeader || (localB->Out));

    /* Switch: '<S12>/Switch' incorporates:
     *  Constant: '<S12>/Unused1'
     *  Logic: '<S12>/Logical Operator1'
     *  Logic: '<S12>/Logical Operator4'
     *  SignalConversion: '<S19>/Signal Conversion1'
     *  SignalConversion: '<S22>/Signal Conversion2'
     *  Sum: '<S21>/Add'
     *  Switch: '<S21>/Switch1'
     *  UnitDelay: '<S12>/Unit Delay'
     */
    if (((!rtb_Busy) || rtb_SendHeader) || rtb_LogicalOperator_edxo)
    {
        localB->Index = ((uint8_T)0U);
    }
    else
    {
        if (localB->Out)
        {
            /* Switch: '<S21>/Switch1' incorporates:
             *  Constant: '<S21>/Unused'
             */
            tmp_0 = ((uint8_T)6U);
        }
        else
        {
            /* Switch: '<S21>/Switch1' incorporates:
             *  Constant: '<S21>/Unused3'
             */
            tmp_0 = ((uint8_T)0U);
        }

        localB->Index = (uint8_T)(((uint32_T)tmp_0) + ((uint32_T)
            localDW->UnitDelay_DSTATE));
    }

    /* End of Switch: '<S12>/Switch' */

    /* Switch: '<S9>/Switch7' incorporates:
     *  Constant: '<S9>/Unused2'
     */
    if (rtb_Busy)
    {
        /* Switch: '<S9>/Switch' incorporates:
         *  DataTypeConversion: '<S30>/Data Type Conversion1'
         *  DataTypeConversion: '<S30>/Data Type Conversion2'
         *  DataTypeConversion: '<S35>/Data Type Conversion'
         *  DataTypeConversion: '<S35>/Data Type Conversion1'
         *  DataTypeConversion: '<S35>/Data Type Conversion2'
         *  DataTypeConversion: '<S35>/Data Type Conversion3'
         *  S-Function (sfix_bitop): '<S30>/Bitwise Operator1'
         *  S-Function (sfix_bitop): '<S30>/Bitwise Operator2'
         *  S-Function (sfix_bitop): '<S35>/Bitwise Operator1'
         *  S-Function (sfix_bitop): '<S35>/Bitwise Operator2'
         *  S-Function (sfix_bitop): '<S35>/Bitwise Operator3'
         *  S-Function (sfix_bitop): '<S35>/Bitwise Operator4'
         *  Selector: '<S9>/Selector'
         */
        if (rtb_SendHeader)
        {
            rtb_Data_nmj0[0] = (uint8_T)(rtb_y_ei0m & ((uint16_T)255U));
            rtb_Data_nmj0[1] = (uint8_T)(rtb_y_jumj & ((uint16_T)255U));
            rtb_Data_nmj0[2] = (uint8_T)(rtb_y_nsrc & 255U);
            rtb_Data_nmj0[3] = (uint8_T)(rtb_y_pt0r & 255U);
            rtb_Data_nmj0[4] = (uint8_T)(rtb_y_afrl & 255U);
            rtb_Data_nmj0[5] = (uint8_T)(rtb_y_ldtz & 255U);
        }
        else
        {
            for (i = 0; i < 6; i++)
            {
                rtb_Data_nmj0[i] = localB->Switch2[i + ((int32_T)localB->Index)];
            }
        }

        /* End of Switch: '<S9>/Switch' */
    }
    else
    {
        for (i = 0; i < 6; i++)
        {
            rtb_Data_nmj0[i] = ((uint8_T)0U);
        }
    }

    /* End of Switch: '<S9>/Switch7' */

    /* SignalConversion: '<S20>/Signal Conversion4' */
    localB->SignalConversion4 = rtb_Busy;

    /* Logic: '<Root>/Logical Operator' incorporates:
     *  Constant: '<S8>/Constant'
     *  RelationalOperator: '<Root>/Relational Operator3'
     *  SignalConversion: '<Root>/Signal Conversion4'
     */
    rtb_IsNewRequestFromGecb = (rtu_IsNewRequestData && (OpbNodeAddr_GECB ==
        rtu_RequesterNodeAddr));

    /* SignalConversion: '<S50>/Signal Conversion' incorporates:
     *  Logic: '<S2>/Logical Operator2'
     *  RelationalOperator: '<S2>/Relational Operator1'
     *  SignalConversion: '<S2>/Signal Conversion3'
     *  SignalConversion: '<S2>/Signal Conversion5'
     */
    localB->SignalConversion_gntb =
        ((HandlePesRequestData_ConstB.uint8_boolean_fowc == rtu_Parameter) &&
         rtb_IsNewRequestFromGecb);

    /* Logic: '<S45>/Logical Operator2' incorporates:
     *  Constant: '<S51>/Constant'
     *  Delay: '<S50>/Delay'
     *  Logic: '<S44>/Logical Operator3'
     *  Logic: '<S45>/Logical Operator1'
     *  Logic: '<S50>/Logical Operator'
     *  RelationalOperator: '<S50>/Relational Operator'
     *  RelationalOperator: '<S51>/Compare'
     *  UnitDelay: '<S44>/Unit Delay'
     */
    rtb_SendHeader_k22x = ((((localB->SignalConversion_gntb == true) &&
        (localB->SignalConversion_gntb != localDW->Delay_DSTATE_guu4)) &&
                            (((int32_T)HandlePesRequestData_ConstB.Compare_ixka)
        != 0)) && (rtb_SendHeader_tmp && (!localDW->UnitDelay_DSTATE_bhvq)));

    /* Switch: '<S46>/Switch1' incorporates:
     *  SignalConversion: '<S44>/Signal Conversion8'
     *  UnitDelay: '<S46>/Unit Delay3'
     */
    if (rtb_SendHeader_k22x)
    {
        localB->PesDataIdLatched_paou =
            HandlePesRequestData_ConstB.PesDataId_ai0i;
    }
    else
    {
        localB->PesDataIdLatched_paou = localDW->UnitDelay3_DSTATE_ix02;
    }

    /* End of Switch: '<S46>/Switch1' */

    /* SignalConversion: '<S62>/Signal Conversion4' incorporates:
     *  DataTypeConversion: '<S48>/uint8_boolean'
     */
    rtb_Uint16_nvcw = (uint16_T)localB->PesDataIdLatched_paou;

    /* Outputs for Atomic SubSystem: '<S65>/Bit Shift1' */
    rtb_y_fdak = HandlePesRequestData_BitShift1(rtb_Uint16_nvcw);

    /* End of Outputs for SubSystem: '<S65>/Bit Shift1' */

    /* Outputs for Atomic SubSystem: '<S65>/Bit Shift2' */
    rtb_y_i5q5 = HandlePesRequestData_BitShift2(rtb_Uint16_nvcw);

    /* End of Outputs for SubSystem: '<S65>/Bit Shift2' */

    /* Switch: '<S46>/Switch2' incorporates:
     *  SignalConversion: '<S2>/Signal Conversion1'
     *  SignalConversion: '<S44>/Signal Conversion8'
     *  UnitDelay: '<S46>/Unit Delay1'
     */
    for (i = 0; i < 6; i++)
    {
        if (rtb_SendHeader_k22x)
        {
            localB->Switch2_cv3x[i] = rtu_PcbInfo->MissionTime[i];
        }
        else
        {
            localB->Switch2_cv3x[i] = localDW->UnitDelay1_DSTATE_fdfy[i];
        }
    }

    /* End of Switch: '<S46>/Switch2' */

    /* SignalConversion: '<S61>/Signal Conversion4' */
    for (i = 0; i < 6; i++)
    {
        rtb_Data_nxc5[i] = localB->Switch2_cv3x[i];
    }

    /* End of SignalConversion: '<S61>/Signal Conversion4' */

    /* Switch: '<S46>/Switch3' incorporates:
     *  SignalConversion: '<S44>/Signal Conversion8'
     *  UnitDelay: '<S46>/Unit Delay2'
     */
    if (rtb_SendHeader_k22x)
    {
        localB->Switch3_pywv = HandlePesRequestData_ConstB.Length_m5l1;
    }
    else
    {
        localB->Switch3_pywv = localDW->UnitDelay2_DSTATE_lsm4;
    }

    /* End of Switch: '<S46>/Switch3' */

    /* SignalConversion: '<S61>/Signal Conversion1' */
    rtb_Length_bvup = localB->Switch3_pywv;

    /* MATLAB Function: '<S61>/MatlabFunctionCall' */
    HandlePesRequestData_MatlabFunctionCall(rtb_Data_nxc5, rtb_Length_bvup,
        &rtb_Crc32_kuxu);

    /* SignalConversion: '<S63>/Signal Conversion4' incorporates:
     *  SignalConversion: '<S61>/Signal Conversion2'
     */
    rtb_Uint32_fxzn = rtb_Crc32_kuxu;

    /* Outputs for Atomic SubSystem: '<S70>/Bit Shift4' */
    rtb_y_az2y = HandlePesRequestData_BitShift4(rtb_Uint32_fxzn);

    /* End of Outputs for SubSystem: '<S70>/Bit Shift4' */

    /* Outputs for Atomic SubSystem: '<S70>/Bit Shift3' */
    rtb_y_k22g = HandlePesRequestData_BitShift3(rtb_Uint32_fxzn);

    /* End of Outputs for SubSystem: '<S70>/Bit Shift3' */

    /* Outputs for Atomic SubSystem: '<S70>/Bit Shift1' */
    rtb_y_bfmr = HandlePesRequestData_BitShift1_llun(rtb_Uint32_fxzn);

    /* End of Outputs for SubSystem: '<S70>/Bit Shift1' */

    /* Outputs for Atomic SubSystem: '<S70>/Bit Shift2' */
    rtb_y_en41 = HandlePesRequestData_BitShift2_jycu(rtb_Uint32_fxzn);

    /* End of Outputs for SubSystem: '<S70>/Bit Shift2' */

    /* SignalConversion: '<S54>/Signal Conversion' */
    localB->SignalConversion_iqjc = rtb_SendHeader_k22x;

    /* Logic: '<S54>/Logical Operator' incorporates:
     *  Constant: '<S60>/Constant'
     *  Delay: '<S54>/Delay'
     *  RelationalOperator: '<S54>/Relational Operator'
     *  RelationalOperator: '<S60>/Compare'
     */
    rtb_LogicalOperator_ey4q = ((localB->SignalConversion_iqjc == false) &&
        (localB->SignalConversion_iqjc != localDW->Delay_DSTATE_lpb0));

    /* SignalConversion: '<S58>/Signal Conversion' incorporates:
     *  Constant: '<S53>/Unused'
     *  Logic: '<S53>/Logical Operator1'
     *  Logic: '<S53>/Logical Operator2'
     *  Logic: '<S53>/Logical Operator3'
     *  RelationalOperator: '<S53>/Relational Operator1'
     *  SignalConversion: '<S54>/Signal Conversion1'
     *  Sum: '<S53>/Add1'
     *  UnitDelay: '<S47>/Unit Delay'
     */
    localB->SignalConversion_jtmq = (((((uint16_T)((uint8_T)(((uint32_T)
        ((uint8_T)6U)) + ((uint32_T)localDW->UnitDelay_DSTATE_dzrj)))) >=
        localB->Switch3_pywv) && (!rtb_SendHeader_k22x)) &&
        (!rtb_LogicalOperator_ey4q));

    /* Logic: '<S57>/Logical Operator2' incorporates:
     *  Constant: '<S59>/Constant'
     *  Delay: '<S58>/Delay'
     *  Logic: '<S58>/Logical Operator'
     *  RelationalOperator: '<S58>/Relational Operator'
     *  RelationalOperator: '<S59>/Compare'
     */
    rtb_NoReset_gslk = ((localB->SignalConversion_jtmq != true) ||
                        (localB->SignalConversion_jtmq ==
                         localDW->Delay_DSTATE_jyba));

    /* Logic: '<S57>/Logical Operator3' incorporates:
     *  Logic: '<S57>/Logical Operator1'
     *  Logic: '<S57>/Logical Operator4'
     *  SignalConversion: '<S54>/Signal Conversion1'
     *  UnitDelay: '<S57>/Unit Delay1'
     */
    localB->Out_ax5q = ((rtb_LogicalOperator_ey4q && rtb_NoReset_gslk) ||
                        (rtb_NoReset_gslk && (localDW->UnitDelay1_DSTATE_oeub)));

    /* Logic: '<S47>/Logical Operator3' incorporates:
     *  SignalConversion: '<S57>/Signal Conversion2'
     */
    rtb_Busy_jtgs = (rtb_SendHeader_k22x || (localB->Out_ax5q));

    /* Switch: '<S47>/Switch' incorporates:
     *  Constant: '<S47>/Unused1'
     *  Logic: '<S47>/Logical Operator1'
     *  Logic: '<S47>/Logical Operator4'
     *  SignalConversion: '<S54>/Signal Conversion1'
     *  SignalConversion: '<S57>/Signal Conversion2'
     *  Sum: '<S56>/Add'
     *  Switch: '<S56>/Switch1'
     *  UnitDelay: '<S47>/Unit Delay'
     */
    if (((!rtb_Busy_jtgs) || rtb_SendHeader_k22x) || rtb_LogicalOperator_ey4q)
    {
        localB->Index_dzmr = ((uint8_T)0U);
    }
    else
    {
        if (localB->Out_ax5q)
        {
            /* Switch: '<S56>/Switch1' incorporates:
             *  Constant: '<S56>/Unused'
             */
            tmp_0 = ((uint8_T)6U);
        }
        else
        {
            /* Switch: '<S56>/Switch1' incorporates:
             *  Constant: '<S56>/Unused3'
             */
            tmp_0 = ((uint8_T)0U);
        }

        localB->Index_dzmr = (uint8_T)(((uint32_T)tmp_0) + ((uint32_T)
            localDW->UnitDelay_DSTATE_dzrj));
    }

    /* End of Switch: '<S47>/Switch' */

    /* Switch: '<S44>/Switch7' incorporates:
     *  Constant: '<S44>/Unused2'
     */
    if (rtb_Busy_jtgs)
    {
        /* Switch: '<S44>/Switch' incorporates:
         *  DataTypeConversion: '<S65>/Data Type Conversion1'
         *  DataTypeConversion: '<S65>/Data Type Conversion2'
         *  DataTypeConversion: '<S70>/Data Type Conversion'
         *  DataTypeConversion: '<S70>/Data Type Conversion1'
         *  DataTypeConversion: '<S70>/Data Type Conversion2'
         *  DataTypeConversion: '<S70>/Data Type Conversion3'
         *  S-Function (sfix_bitop): '<S65>/Bitwise Operator1'
         *  S-Function (sfix_bitop): '<S65>/Bitwise Operator2'
         *  S-Function (sfix_bitop): '<S70>/Bitwise Operator1'
         *  S-Function (sfix_bitop): '<S70>/Bitwise Operator2'
         *  S-Function (sfix_bitop): '<S70>/Bitwise Operator3'
         *  S-Function (sfix_bitop): '<S70>/Bitwise Operator4'
         *  Selector: '<S44>/Selector'
         */
        if (rtb_SendHeader_k22x)
        {
            rtb_Data_h0vb[0] = (uint8_T)(rtb_y_fdak & ((uint16_T)255U));
            rtb_Data_h0vb[1] = (uint8_T)(rtb_y_i5q5 & ((uint16_T)255U));
            rtb_Data_h0vb[2] = (uint8_T)(rtb_y_az2y & 255U);
            rtb_Data_h0vb[3] = (uint8_T)(rtb_y_k22g & 255U);
            rtb_Data_h0vb[4] = (uint8_T)(rtb_y_bfmr & 255U);
            rtb_Data_h0vb[5] = (uint8_T)(rtb_y_en41 & 255U);
        }
        else
        {
            for (i = 0; i < 6; i++)
            {
                rtb_Data_h0vb[i] = localB->Switch2_cv3x[i + ((int32_T)
                    localB->Index_dzmr)];
            }
        }

        /* End of Switch: '<S44>/Switch' */
    }
    else
    {
        for (i = 0; i < 6; i++)
        {
            rtb_Data_h0vb[i] = ((uint8_T)0U);
        }
    }

    /* End of Switch: '<S44>/Switch7' */

    /* SignalConversion: '<S55>/Signal Conversion4' */
    localB->SignalConversion4_ha1f = rtb_Busy_jtgs;

    /* SignalConversion: '<S85>/Signal Conversion' incorporates:
     *  Logic: '<S3>/Logical Operator2'
     *  RelationalOperator: '<S3>/Relational Operator1'
     *  SignalConversion: '<S3>/Signal Conversion3'
     *  SignalConversion: '<S3>/Signal Conversion5'
     */
    localB->SignalConversion_gt40 =
        ((HandlePesRequestData_ConstB.uint8_boolean_nkuv == rtu_Parameter) &&
         rtb_IsNewRequestFromGecb);

    /* Logic: '<S80>/Logical Operator2' incorporates:
     *  Constant: '<S86>/Constant'
     *  Delay: '<S85>/Delay'
     *  Logic: '<S79>/Logical Operator3'
     *  Logic: '<S80>/Logical Operator1'
     *  Logic: '<S85>/Logical Operator'
     *  RelationalOperator: '<S85>/Relational Operator'
     *  RelationalOperator: '<S86>/Compare'
     *  UnitDelay: '<S79>/Unit Delay'
     */
    rtb_SendHeader_o30o = ((((localB->SignalConversion_gt40 == true) &&
        (localB->SignalConversion_gt40 != localDW->Delay_DSTATE_an3l)) &&
                            (((int32_T)HandlePesRequestData_ConstB.Compare_jgd3)
        != 0)) && (rtb_SendHeader_tmp && (!localDW->UnitDelay_DSTATE_jbyd)));

    /* Switch: '<S81>/Switch1' incorporates:
     *  SignalConversion: '<S79>/Signal Conversion8'
     *  UnitDelay: '<S81>/Unit Delay3'
     */
    if (rtb_SendHeader_o30o)
    {
        localB->PesDataIdLatched_k0fn =
            HandlePesRequestData_ConstB.PesDataId_bzxw;
    }
    else
    {
        localB->PesDataIdLatched_k0fn = localDW->UnitDelay3_DSTATE_ckas;
    }

    /* End of Switch: '<S81>/Switch1' */

    /* SignalConversion: '<S97>/Signal Conversion4' incorporates:
     *  DataTypeConversion: '<S83>/uint8_boolean'
     */
    rtb_Uint16_f21n = (uint16_T)localB->PesDataIdLatched_k0fn;

    /* Outputs for Atomic SubSystem: '<S100>/Bit Shift1' */
    rtb_y_iq15 = HandlePesRequestData_BitShift1(rtb_Uint16_f21n);

    /* End of Outputs for SubSystem: '<S100>/Bit Shift1' */

    /* Outputs for Atomic SubSystem: '<S100>/Bit Shift2' */
    rtb_y_nlei = HandlePesRequestData_BitShift2(rtb_Uint16_f21n);

    /* End of Outputs for SubSystem: '<S100>/Bit Shift2' */

    /* Switch: '<S81>/Switch2' incorporates:
     *  SignalConversion: '<S3>/Signal Conversion1'
     *  SignalConversion: '<S79>/Signal Conversion8'
     *  UnitDelay: '<S81>/Unit Delay1'
     */
    for (i = 0; i < 36; i++)
    {
        if (rtb_SendHeader_o30o)
        {
            localB->Switch2_ieay[i] = rtu_PcbInfo->PcbManufacturer[i];
        }
        else
        {
            localB->Switch2_ieay[i] = localDW->UnitDelay1_DSTATE_gxz0[i];
        }
    }

    /* End of Switch: '<S81>/Switch2' */

    /* SignalConversion: '<S96>/Signal Conversion4' */
    for (i = 0; i < 36; i++)
    {
        rtb_Data_kyhu[i] = localB->Switch2_ieay[i];
    }

    /* End of SignalConversion: '<S96>/Signal Conversion4' */

    /* Switch: '<S81>/Switch3' incorporates:
     *  SignalConversion: '<S79>/Signal Conversion8'
     *  UnitDelay: '<S81>/Unit Delay2'
     */
    if (rtb_SendHeader_o30o)
    {
        localB->Switch3_d2lp = HandlePesRequestData_ConstB.Length_bu5u;
    }
    else
    {
        localB->Switch3_d2lp = localDW->UnitDelay2_DSTATE_gg5l;
    }

    /* End of Switch: '<S81>/Switch3' */

    /* SignalConversion: '<S96>/Signal Conversion1' */
    rtb_Length_ez22 = localB->Switch3_d2lp;

    /* MATLAB Function: '<S96>/MatlabFunctionCall' */
    HandlePesRequestData_MatlabFunctionCall_i5sj(rtb_Data_kyhu, rtb_Length_ez22,
        &rtb_Crc32_ftfd);

    /* SignalConversion: '<S98>/Signal Conversion4' incorporates:
     *  SignalConversion: '<S96>/Signal Conversion2'
     */
    rtb_Uint32_cuw4 = rtb_Crc32_ftfd;

    /* Outputs for Atomic SubSystem: '<S105>/Bit Shift4' */
    rtb_y_n2ws = HandlePesRequestData_BitShift4(rtb_Uint32_cuw4);

    /* End of Outputs for SubSystem: '<S105>/Bit Shift4' */

    /* Outputs for Atomic SubSystem: '<S105>/Bit Shift3' */
    rtb_y_exwq = HandlePesRequestData_BitShift3(rtb_Uint32_cuw4);

    /* End of Outputs for SubSystem: '<S105>/Bit Shift3' */

    /* Outputs for Atomic SubSystem: '<S105>/Bit Shift1' */
    rtb_y_ltis = HandlePesRequestData_BitShift1_llun(rtb_Uint32_cuw4);

    /* End of Outputs for SubSystem: '<S105>/Bit Shift1' */

    /* Outputs for Atomic SubSystem: '<S105>/Bit Shift2' */
    rtb_y_lhej = HandlePesRequestData_BitShift2_jycu(rtb_Uint32_cuw4);

    /* End of Outputs for SubSystem: '<S105>/Bit Shift2' */

    /* SignalConversion: '<S89>/Signal Conversion' */
    localB->SignalConversion_artt = rtb_SendHeader_o30o;

    /* Logic: '<S89>/Logical Operator' incorporates:
     *  Constant: '<S95>/Constant'
     *  Delay: '<S89>/Delay'
     *  RelationalOperator: '<S89>/Relational Operator'
     *  RelationalOperator: '<S95>/Compare'
     */
    rtb_LogicalOperator_gxvx = ((localB->SignalConversion_artt == false) &&
        (localB->SignalConversion_artt != localDW->Delay_DSTATE_dvqt));

    /* SignalConversion: '<S93>/Signal Conversion' incorporates:
     *  Constant: '<S88>/Unused'
     *  Logic: '<S88>/Logical Operator1'
     *  Logic: '<S88>/Logical Operator2'
     *  Logic: '<S88>/Logical Operator3'
     *  RelationalOperator: '<S88>/Relational Operator1'
     *  SignalConversion: '<S89>/Signal Conversion1'
     *  Sum: '<S88>/Add1'
     *  UnitDelay: '<S82>/Unit Delay'
     */
    localB->SignalConversion_fly3 = (((((uint16_T)((uint8_T)(((uint32_T)
        ((uint8_T)6U)) + ((uint32_T)localDW->UnitDelay_DSTATE_aw22)))) >=
        localB->Switch3_d2lp) && (!rtb_SendHeader_o30o)) &&
        (!rtb_LogicalOperator_gxvx));

    /* Logic: '<S92>/Logical Operator2' incorporates:
     *  Constant: '<S94>/Constant'
     *  Delay: '<S93>/Delay'
     *  Logic: '<S93>/Logical Operator'
     *  RelationalOperator: '<S93>/Relational Operator'
     *  RelationalOperator: '<S94>/Compare'
     */
    rtb_NoReset_kd5d = ((localB->SignalConversion_fly3 != true) ||
                        (localB->SignalConversion_fly3 ==
                         localDW->Delay_DSTATE_ng4x));

    /* Logic: '<S92>/Logical Operator3' incorporates:
     *  Logic: '<S92>/Logical Operator1'
     *  Logic: '<S92>/Logical Operator4'
     *  SignalConversion: '<S89>/Signal Conversion1'
     *  UnitDelay: '<S92>/Unit Delay1'
     */
    localB->Out_dpks = ((rtb_LogicalOperator_gxvx && rtb_NoReset_kd5d) ||
                        (rtb_NoReset_kd5d && (localDW->UnitDelay1_DSTATE_oqju)));

    /* Logic: '<S82>/Logical Operator3' incorporates:
     *  SignalConversion: '<S92>/Signal Conversion2'
     */
    rtb_Busy_lntr = (rtb_SendHeader_o30o || (localB->Out_dpks));

    /* Switch: '<S82>/Switch' incorporates:
     *  Constant: '<S82>/Unused1'
     *  Logic: '<S82>/Logical Operator1'
     *  Logic: '<S82>/Logical Operator4'
     *  SignalConversion: '<S89>/Signal Conversion1'
     *  SignalConversion: '<S92>/Signal Conversion2'
     *  Sum: '<S91>/Add'
     *  Switch: '<S91>/Switch1'
     *  UnitDelay: '<S82>/Unit Delay'
     */
    if (((!rtb_Busy_lntr) || rtb_SendHeader_o30o) || rtb_LogicalOperator_gxvx)
    {
        localB->Index_dp2j = ((uint8_T)0U);
    }
    else
    {
        if (localB->Out_dpks)
        {
            /* Switch: '<S91>/Switch1' incorporates:
             *  Constant: '<S91>/Unused'
             */
            tmp_0 = ((uint8_T)6U);
        }
        else
        {
            /* Switch: '<S91>/Switch1' incorporates:
             *  Constant: '<S91>/Unused3'
             */
            tmp_0 = ((uint8_T)0U);
        }

        localB->Index_dp2j = (uint8_T)(((uint32_T)tmp_0) + ((uint32_T)
            localDW->UnitDelay_DSTATE_aw22));
    }

    /* End of Switch: '<S82>/Switch' */

    /* Switch: '<S79>/Switch7' incorporates:
     *  Constant: '<S79>/Unused2'
     */
    if (rtb_Busy_lntr)
    {
        /* Switch: '<S79>/Switch' incorporates:
         *  DataTypeConversion: '<S100>/Data Type Conversion1'
         *  DataTypeConversion: '<S100>/Data Type Conversion2'
         *  DataTypeConversion: '<S105>/Data Type Conversion'
         *  DataTypeConversion: '<S105>/Data Type Conversion1'
         *  DataTypeConversion: '<S105>/Data Type Conversion2'
         *  DataTypeConversion: '<S105>/Data Type Conversion3'
         *  S-Function (sfix_bitop): '<S100>/Bitwise Operator1'
         *  S-Function (sfix_bitop): '<S100>/Bitwise Operator2'
         *  S-Function (sfix_bitop): '<S105>/Bitwise Operator1'
         *  S-Function (sfix_bitop): '<S105>/Bitwise Operator2'
         *  S-Function (sfix_bitop): '<S105>/Bitwise Operator3'
         *  S-Function (sfix_bitop): '<S105>/Bitwise Operator4'
         *  Selector: '<S79>/Selector'
         */
        if (rtb_SendHeader_o30o)
        {
            rtb_Data_ov5q[0] = (uint8_T)(rtb_y_iq15 & ((uint16_T)255U));
            rtb_Data_ov5q[1] = (uint8_T)(rtb_y_nlei & ((uint16_T)255U));
            rtb_Data_ov5q[2] = (uint8_T)(rtb_y_n2ws & 255U);
            rtb_Data_ov5q[3] = (uint8_T)(rtb_y_exwq & 255U);
            rtb_Data_ov5q[4] = (uint8_T)(rtb_y_ltis & 255U);
            rtb_Data_ov5q[5] = (uint8_T)(rtb_y_lhej & 255U);
        }
        else
        {
            for (i = 0; i < 6; i++)
            {
                rtb_Data_ov5q[i] = localB->Switch2_ieay[i + ((int32_T)
                    localB->Index_dp2j)];
            }
        }

        /* End of Switch: '<S79>/Switch' */
    }
    else
    {
        for (i = 0; i < 6; i++)
        {
            rtb_Data_ov5q[i] = ((uint8_T)0U);
        }
    }

    /* End of Switch: '<S79>/Switch7' */

    /* SignalConversion: '<S90>/Signal Conversion4' */
    localB->SignalConversion4_dtni = rtb_Busy_lntr;

    /* SignalConversion: '<S120>/Signal Conversion' incorporates:
     *  Logic: '<S4>/Logical Operator2'
     *  RelationalOperator: '<S4>/Relational Operator1'
     *  SignalConversion: '<S4>/Signal Conversion3'
     *  SignalConversion: '<S4>/Signal Conversion5'
     */
    localB->SignalConversion_dkfe =
        ((HandlePesRequestData_ConstB.uint8_boolean_cdgw == rtu_Parameter) &&
         rtb_IsNewRequestFromGecb);

    /* Logic: '<S115>/Logical Operator2' incorporates:
     *  Constant: '<S121>/Constant'
     *  Delay: '<S120>/Delay'
     *  Logic: '<S114>/Logical Operator3'
     *  Logic: '<S115>/Logical Operator1'
     *  Logic: '<S120>/Logical Operator'
     *  RelationalOperator: '<S120>/Relational Operator'
     *  RelationalOperator: '<S121>/Compare'
     *  UnitDelay: '<S114>/Unit Delay'
     */
    rtb_SendHeader_emxy = ((((localB->SignalConversion_dkfe == true) &&
        (localB->SignalConversion_dkfe != localDW->Delay_DSTATE_dkya)) &&
                            (((int32_T)HandlePesRequestData_ConstB.Compare_jene)
        != 0)) && (rtb_SendHeader_tmp && (!localDW->UnitDelay_DSTATE_gum5)));

    /* Switch: '<S116>/Switch1' incorporates:
     *  SignalConversion: '<S114>/Signal Conversion8'
     *  UnitDelay: '<S116>/Unit Delay3'
     */
    if (rtb_SendHeader_emxy)
    {
        localB->PesDataIdLatched_o5dp =
            HandlePesRequestData_ConstB.PesDataId_int1;
    }
    else
    {
        localB->PesDataIdLatched_o5dp = localDW->UnitDelay3_DSTATE_bm3i;
    }

    /* End of Switch: '<S116>/Switch1' */

    /* SignalConversion: '<S132>/Signal Conversion4' incorporates:
     *  DataTypeConversion: '<S118>/uint8_boolean'
     */
    rtb_Uint16_bxpj = (uint16_T)localB->PesDataIdLatched_o5dp;

    /* Outputs for Atomic SubSystem: '<S135>/Bit Shift1' */
    rtb_y_oncc = HandlePesRequestData_BitShift1(rtb_Uint16_bxpj);

    /* End of Outputs for SubSystem: '<S135>/Bit Shift1' */

    /* Outputs for Atomic SubSystem: '<S135>/Bit Shift2' */
    rtb_y_d5sy = HandlePesRequestData_BitShift2(rtb_Uint16_bxpj);

    /* End of Outputs for SubSystem: '<S135>/Bit Shift2' */

    /* Switch: '<S116>/Switch2' incorporates:
     *  SignalConversion: '<S114>/Signal Conversion8'
     *  SignalConversion: '<S4>/Signal Conversion1'
     *  UnitDelay: '<S116>/Unit Delay1'
     */
    for (i = 0; i < 36; i++)
    {
        if (rtb_SendHeader_emxy)
        {
            localB->Switch2_pagy[i] = rtu_PcbInfo->SafetySystemType[i];
        }
        else
        {
            localB->Switch2_pagy[i] = localDW->UnitDelay1_DSTATE_ayds[i];
        }
    }

    /* End of Switch: '<S116>/Switch2' */

    /* SignalConversion: '<S131>/Signal Conversion4' */
    for (i = 0; i < 36; i++)
    {
        rtb_Data_fwf3[i] = localB->Switch2_pagy[i];
    }

    /* End of SignalConversion: '<S131>/Signal Conversion4' */

    /* Switch: '<S116>/Switch3' incorporates:
     *  SignalConversion: '<S114>/Signal Conversion8'
     *  UnitDelay: '<S116>/Unit Delay2'
     */
    if (rtb_SendHeader_emxy)
    {
        localB->Switch3_jogv = HandlePesRequestData_ConstB.Length_eqin;
    }
    else
    {
        localB->Switch3_jogv = localDW->UnitDelay2_DSTATE_eqis;
    }

    /* End of Switch: '<S116>/Switch3' */

    /* SignalConversion: '<S131>/Signal Conversion1' */
    rtb_Length_pbxz = localB->Switch3_jogv;

    /* MATLAB Function: '<S131>/MatlabFunctionCall' */
    HandlePesRequestData_MatlabFunctionCall_i5sj(rtb_Data_fwf3, rtb_Length_pbxz,
        &rtb_Crc32_pk0z);

    /* SignalConversion: '<S133>/Signal Conversion4' incorporates:
     *  SignalConversion: '<S131>/Signal Conversion2'
     */
    rtb_Uint32_dkis = rtb_Crc32_pk0z;

    /* Outputs for Atomic SubSystem: '<S140>/Bit Shift4' */
    rtb_y_nfbv = HandlePesRequestData_BitShift4(rtb_Uint32_dkis);

    /* End of Outputs for SubSystem: '<S140>/Bit Shift4' */

    /* Outputs for Atomic SubSystem: '<S140>/Bit Shift3' */
    rtb_y_ocqs = HandlePesRequestData_BitShift3(rtb_Uint32_dkis);

    /* End of Outputs for SubSystem: '<S140>/Bit Shift3' */

    /* Outputs for Atomic SubSystem: '<S140>/Bit Shift1' */
    rtb_y_cfob = HandlePesRequestData_BitShift1_llun(rtb_Uint32_dkis);

    /* End of Outputs for SubSystem: '<S140>/Bit Shift1' */

    /* Outputs for Atomic SubSystem: '<S140>/Bit Shift2' */
    rtb_y_hfle = HandlePesRequestData_BitShift2_jycu(rtb_Uint32_dkis);

    /* End of Outputs for SubSystem: '<S140>/Bit Shift2' */

    /* SignalConversion: '<S124>/Signal Conversion' */
    localB->SignalConversion_pfwa = rtb_SendHeader_emxy;

    /* Logic: '<S124>/Logical Operator' incorporates:
     *  Constant: '<S130>/Constant'
     *  Delay: '<S124>/Delay'
     *  RelationalOperator: '<S124>/Relational Operator'
     *  RelationalOperator: '<S130>/Compare'
     */
    rtb_LogicalOperator_gn0u = ((localB->SignalConversion_pfwa == false) &&
        (localB->SignalConversion_pfwa != localDW->Delay_DSTATE_lsmp));

    /* SignalConversion: '<S128>/Signal Conversion' incorporates:
     *  Constant: '<S123>/Unused'
     *  Logic: '<S123>/Logical Operator1'
     *  Logic: '<S123>/Logical Operator2'
     *  Logic: '<S123>/Logical Operator3'
     *  RelationalOperator: '<S123>/Relational Operator1'
     *  SignalConversion: '<S124>/Signal Conversion1'
     *  Sum: '<S123>/Add1'
     *  UnitDelay: '<S117>/Unit Delay'
     */
    localB->SignalConversion_bvfq = (((((uint16_T)((uint8_T)(((uint32_T)
        ((uint8_T)6U)) + ((uint32_T)localDW->UnitDelay_DSTATE_c5nx)))) >=
        localB->Switch3_jogv) && (!rtb_SendHeader_emxy)) &&
        (!rtb_LogicalOperator_gn0u));

    /* Logic: '<S127>/Logical Operator2' incorporates:
     *  Constant: '<S129>/Constant'
     *  Delay: '<S128>/Delay'
     *  Logic: '<S128>/Logical Operator'
     *  RelationalOperator: '<S128>/Relational Operator'
     *  RelationalOperator: '<S129>/Compare'
     */
    rtb_NoReset_dizi = ((localB->SignalConversion_bvfq != true) ||
                        (localB->SignalConversion_bvfq ==
                         localDW->Delay_DSTATE_psqk));

    /* Logic: '<S127>/Logical Operator3' incorporates:
     *  Logic: '<S127>/Logical Operator1'
     *  Logic: '<S127>/Logical Operator4'
     *  SignalConversion: '<S124>/Signal Conversion1'
     *  UnitDelay: '<S127>/Unit Delay1'
     */
    localB->Out_p3o0 = ((rtb_LogicalOperator_gn0u && rtb_NoReset_dizi) ||
                        (rtb_NoReset_dizi && (localDW->UnitDelay1_DSTATE_hmbk)));

    /* Logic: '<S117>/Logical Operator3' incorporates:
     *  SignalConversion: '<S127>/Signal Conversion2'
     */
    rtb_Busy_lemt = (rtb_SendHeader_emxy || (localB->Out_p3o0));

    /* Switch: '<S117>/Switch' incorporates:
     *  Constant: '<S117>/Unused1'
     *  Logic: '<S117>/Logical Operator1'
     *  Logic: '<S117>/Logical Operator4'
     *  SignalConversion: '<S124>/Signal Conversion1'
     *  SignalConversion: '<S127>/Signal Conversion2'
     *  Sum: '<S126>/Add'
     *  Switch: '<S126>/Switch1'
     *  UnitDelay: '<S117>/Unit Delay'
     */
    if (((!rtb_Busy_lemt) || rtb_SendHeader_emxy) || rtb_LogicalOperator_gn0u)
    {
        localB->Index_fzh5 = ((uint8_T)0U);
    }
    else
    {
        if (localB->Out_p3o0)
        {
            /* Switch: '<S126>/Switch1' incorporates:
             *  Constant: '<S126>/Unused'
             */
            tmp_0 = ((uint8_T)6U);
        }
        else
        {
            /* Switch: '<S126>/Switch1' incorporates:
             *  Constant: '<S126>/Unused3'
             */
            tmp_0 = ((uint8_T)0U);
        }

        localB->Index_fzh5 = (uint8_T)(((uint32_T)tmp_0) + ((uint32_T)
            localDW->UnitDelay_DSTATE_c5nx));
    }

    /* End of Switch: '<S117>/Switch' */

    /* Switch: '<S114>/Switch7' incorporates:
     *  Constant: '<S114>/Unused2'
     */
    if (rtb_Busy_lemt)
    {
        /* Switch: '<S114>/Switch' incorporates:
         *  DataTypeConversion: '<S135>/Data Type Conversion1'
         *  DataTypeConversion: '<S135>/Data Type Conversion2'
         *  DataTypeConversion: '<S140>/Data Type Conversion'
         *  DataTypeConversion: '<S140>/Data Type Conversion1'
         *  DataTypeConversion: '<S140>/Data Type Conversion2'
         *  DataTypeConversion: '<S140>/Data Type Conversion3'
         *  S-Function (sfix_bitop): '<S135>/Bitwise Operator1'
         *  S-Function (sfix_bitop): '<S135>/Bitwise Operator2'
         *  S-Function (sfix_bitop): '<S140>/Bitwise Operator1'
         *  S-Function (sfix_bitop): '<S140>/Bitwise Operator2'
         *  S-Function (sfix_bitop): '<S140>/Bitwise Operator3'
         *  S-Function (sfix_bitop): '<S140>/Bitwise Operator4'
         *  Selector: '<S114>/Selector'
         */
        if (rtb_SendHeader_emxy)
        {
            rtb_Data_feal[0] = (uint8_T)(rtb_y_oncc & ((uint16_T)255U));
            rtb_Data_feal[1] = (uint8_T)(rtb_y_d5sy & ((uint16_T)255U));
            rtb_Data_feal[2] = (uint8_T)(rtb_y_nfbv & 255U);
            rtb_Data_feal[3] = (uint8_T)(rtb_y_ocqs & 255U);
            rtb_Data_feal[4] = (uint8_T)(rtb_y_cfob & 255U);
            rtb_Data_feal[5] = (uint8_T)(rtb_y_hfle & 255U);
        }
        else
        {
            for (i = 0; i < 6; i++)
            {
                rtb_Data_feal[i] = localB->Switch2_pagy[i + ((int32_T)
                    localB->Index_fzh5)];
            }
        }

        /* End of Switch: '<S114>/Switch' */
    }
    else
    {
        for (i = 0; i < 6; i++)
        {
            rtb_Data_feal[i] = ((uint8_T)0U);
        }
    }

    /* End of Switch: '<S114>/Switch7' */

    /* SignalConversion: '<S125>/Signal Conversion4' */
    localB->SignalConversion4_doml = rtb_Busy_lemt;

    /* SignalConversion: '<S155>/Signal Conversion' incorporates:
     *  Logic: '<S5>/Logical Operator2'
     *  RelationalOperator: '<S5>/Relational Operator1'
     *  SignalConversion: '<S5>/Signal Conversion3'
     *  SignalConversion: '<S5>/Signal Conversion5'
     */
    localB->SignalConversion_k1xg =
        ((HandlePesRequestData_ConstB.uint8_boolean_no2a == rtu_Parameter) &&
         rtb_IsNewRequestFromGecb);

    /* Logic: '<S150>/Logical Operator2' incorporates:
     *  Constant: '<S156>/Constant'
     *  Delay: '<S155>/Delay'
     *  Logic: '<S149>/Logical Operator3'
     *  Logic: '<S150>/Logical Operator1'
     *  Logic: '<S155>/Logical Operator'
     *  RelationalOperator: '<S155>/Relational Operator'
     *  RelationalOperator: '<S156>/Compare'
     *  UnitDelay: '<S149>/Unit Delay'
     */
    rtb_SendHeader_h3le = ((((localB->SignalConversion_k1xg == true) &&
        (localB->SignalConversion_k1xg != localDW->Delay_DSTATE_hxzp)) &&
                            (((int32_T)HandlePesRequestData_ConstB.Compare_cfss)
        != 0)) && (rtb_SendHeader_tmp && (!localDW->UnitDelay_DSTATE_dn2y)));

    /* Switch: '<S151>/Switch1' incorporates:
     *  SignalConversion: '<S149>/Signal Conversion8'
     *  UnitDelay: '<S151>/Unit Delay3'
     */
    if (rtb_SendHeader_h3le)
    {
        localB->PesDataIdLatched_dyzs =
            HandlePesRequestData_ConstB.PesDataId_foh3;
    }
    else
    {
        localB->PesDataIdLatched_dyzs = localDW->UnitDelay3_DSTATE_k43c;
    }

    /* End of Switch: '<S151>/Switch1' */

    /* SignalConversion: '<S167>/Signal Conversion4' incorporates:
     *  DataTypeConversion: '<S153>/uint8_boolean'
     */
    rtb_Uint16_h1sr = (uint16_T)localB->PesDataIdLatched_dyzs;

    /* Outputs for Atomic SubSystem: '<S170>/Bit Shift1' */
    rtb_y_nj0x = HandlePesRequestData_BitShift1(rtb_Uint16_h1sr);

    /* End of Outputs for SubSystem: '<S170>/Bit Shift1' */

    /* Outputs for Atomic SubSystem: '<S170>/Bit Shift2' */
    rtb_y_ge1k = HandlePesRequestData_BitShift2(rtb_Uint16_h1sr);

    /* End of Outputs for SubSystem: '<S170>/Bit Shift2' */

    /* Switch: '<S151>/Switch2' incorporates:
     *  SignalConversion: '<S149>/Signal Conversion8'
     *  SignalConversion: '<S5>/Signal Conversion1'
     *  UnitDelay: '<S151>/Unit Delay1'
     */
    for (i = 0; i < 36; i++)
    {
        if (rtb_SendHeader_h3le)
        {
            localB->Switch2_mx0e[i] = rtu_PcbInfo->ExaminationCertificate[i];
        }
        else
        {
            localB->Switch2_mx0e[i] = localDW->UnitDelay1_DSTATE_moda[i];
        }
    }

    /* End of Switch: '<S151>/Switch2' */

    /* SignalConversion: '<S166>/Signal Conversion4' */
    for (i = 0; i < 36; i++)
    {
        rtb_Data_izzq[i] = localB->Switch2_mx0e[i];
    }

    /* End of SignalConversion: '<S166>/Signal Conversion4' */

    /* Switch: '<S151>/Switch3' incorporates:
     *  SignalConversion: '<S149>/Signal Conversion8'
     *  UnitDelay: '<S151>/Unit Delay2'
     */
    if (rtb_SendHeader_h3le)
    {
        localB->Switch3_dica = HandlePesRequestData_ConstB.Length_iir3;
    }
    else
    {
        localB->Switch3_dica = localDW->UnitDelay2_DSTATE_ewl0;
    }

    /* End of Switch: '<S151>/Switch3' */

    /* SignalConversion: '<S166>/Signal Conversion1' */
    rtb_Length_marn = localB->Switch3_dica;

    /* MATLAB Function: '<S166>/MatlabFunctionCall' */
    HandlePesRequestData_MatlabFunctionCall_i5sj(rtb_Data_izzq, rtb_Length_marn,
        &rtb_Crc32_pai3);

    /* SignalConversion: '<S168>/Signal Conversion4' incorporates:
     *  SignalConversion: '<S166>/Signal Conversion2'
     */
    rtb_Uint32_bfzd = rtb_Crc32_pai3;

    /* Outputs for Atomic SubSystem: '<S175>/Bit Shift4' */
    rtb_y_ktlp = HandlePesRequestData_BitShift4(rtb_Uint32_bfzd);

    /* End of Outputs for SubSystem: '<S175>/Bit Shift4' */

    /* Outputs for Atomic SubSystem: '<S175>/Bit Shift3' */
    rtb_y_kbdv = HandlePesRequestData_BitShift3(rtb_Uint32_bfzd);

    /* End of Outputs for SubSystem: '<S175>/Bit Shift3' */

    /* Outputs for Atomic SubSystem: '<S175>/Bit Shift1' */
    rtb_y_nfoj = HandlePesRequestData_BitShift1_llun(rtb_Uint32_bfzd);

    /* End of Outputs for SubSystem: '<S175>/Bit Shift1' */

    /* Outputs for Atomic SubSystem: '<S175>/Bit Shift2' */
    rtb_y_obcg = HandlePesRequestData_BitShift2_jycu(rtb_Uint32_bfzd);

    /* End of Outputs for SubSystem: '<S175>/Bit Shift2' */

    /* SignalConversion: '<S159>/Signal Conversion' */
    localB->SignalConversion_jy20 = rtb_SendHeader_h3le;

    /* Logic: '<S159>/Logical Operator' incorporates:
     *  Constant: '<S165>/Constant'
     *  Delay: '<S159>/Delay'
     *  RelationalOperator: '<S159>/Relational Operator'
     *  RelationalOperator: '<S165>/Compare'
     */
    rtb_LogicalOperator_iueu = ((localB->SignalConversion_jy20 == false) &&
        (localB->SignalConversion_jy20 != localDW->Delay_DSTATE_gtwo));

    /* SignalConversion: '<S163>/Signal Conversion' incorporates:
     *  Constant: '<S158>/Unused'
     *  Logic: '<S158>/Logical Operator1'
     *  Logic: '<S158>/Logical Operator2'
     *  Logic: '<S158>/Logical Operator3'
     *  RelationalOperator: '<S158>/Relational Operator1'
     *  SignalConversion: '<S159>/Signal Conversion1'
     *  Sum: '<S158>/Add1'
     *  UnitDelay: '<S152>/Unit Delay'
     */
    localB->SignalConversion_gbds = (((((uint16_T)((uint8_T)(((uint32_T)
        ((uint8_T)6U)) + ((uint32_T)localDW->UnitDelay_DSTATE_a320)))) >=
        localB->Switch3_dica) && (!rtb_SendHeader_h3le)) &&
        (!rtb_LogicalOperator_iueu));

    /* Logic: '<S162>/Logical Operator2' incorporates:
     *  Constant: '<S164>/Constant'
     *  Delay: '<S163>/Delay'
     *  Logic: '<S163>/Logical Operator'
     *  RelationalOperator: '<S163>/Relational Operator'
     *  RelationalOperator: '<S164>/Compare'
     */
    rtb_NoReset_f0k3 = ((localB->SignalConversion_gbds != true) ||
                        (localB->SignalConversion_gbds ==
                         localDW->Delay_DSTATE_kedp));

    /* Logic: '<S162>/Logical Operator3' incorporates:
     *  Logic: '<S162>/Logical Operator1'
     *  Logic: '<S162>/Logical Operator4'
     *  SignalConversion: '<S159>/Signal Conversion1'
     *  UnitDelay: '<S162>/Unit Delay1'
     */
    localB->Out_ol0y = ((rtb_LogicalOperator_iueu && rtb_NoReset_f0k3) ||
                        (rtb_NoReset_f0k3 && (localDW->UnitDelay1_DSTATE_owaq)));

    /* Logic: '<S152>/Logical Operator3' incorporates:
     *  SignalConversion: '<S162>/Signal Conversion2'
     */
    rtb_Busy_bzxf = (rtb_SendHeader_h3le || (localB->Out_ol0y));

    /* Switch: '<S152>/Switch' incorporates:
     *  Constant: '<S152>/Unused1'
     *  Logic: '<S152>/Logical Operator1'
     *  Logic: '<S152>/Logical Operator4'
     *  SignalConversion: '<S159>/Signal Conversion1'
     *  SignalConversion: '<S162>/Signal Conversion2'
     *  Sum: '<S161>/Add'
     *  Switch: '<S161>/Switch1'
     *  UnitDelay: '<S152>/Unit Delay'
     */
    if (((!rtb_Busy_bzxf) || rtb_SendHeader_h3le) || rtb_LogicalOperator_iueu)
    {
        localB->Index_lxaz = ((uint8_T)0U);
    }
    else
    {
        if (localB->Out_ol0y)
        {
            /* Switch: '<S161>/Switch1' incorporates:
             *  Constant: '<S161>/Unused'
             */
            tmp_0 = ((uint8_T)6U);
        }
        else
        {
            /* Switch: '<S161>/Switch1' incorporates:
             *  Constant: '<S161>/Unused3'
             */
            tmp_0 = ((uint8_T)0U);
        }

        localB->Index_lxaz = (uint8_T)(((uint32_T)tmp_0) + ((uint32_T)
            localDW->UnitDelay_DSTATE_a320));
    }

    /* End of Switch: '<S152>/Switch' */

    /* Switch: '<S149>/Switch7' incorporates:
     *  Constant: '<S149>/Unused2'
     */
    if (rtb_Busy_bzxf)
    {
        /* Switch: '<S149>/Switch' incorporates:
         *  DataTypeConversion: '<S170>/Data Type Conversion1'
         *  DataTypeConversion: '<S170>/Data Type Conversion2'
         *  DataTypeConversion: '<S175>/Data Type Conversion'
         *  DataTypeConversion: '<S175>/Data Type Conversion1'
         *  DataTypeConversion: '<S175>/Data Type Conversion2'
         *  DataTypeConversion: '<S175>/Data Type Conversion3'
         *  S-Function (sfix_bitop): '<S170>/Bitwise Operator1'
         *  S-Function (sfix_bitop): '<S170>/Bitwise Operator2'
         *  S-Function (sfix_bitop): '<S175>/Bitwise Operator1'
         *  S-Function (sfix_bitop): '<S175>/Bitwise Operator2'
         *  S-Function (sfix_bitop): '<S175>/Bitwise Operator3'
         *  S-Function (sfix_bitop): '<S175>/Bitwise Operator4'
         *  Selector: '<S149>/Selector'
         */
        if (rtb_SendHeader_h3le)
        {
            rtb_Data_i1qt[0] = (uint8_T)(rtb_y_nj0x & ((uint16_T)255U));
            rtb_Data_i1qt[1] = (uint8_T)(rtb_y_ge1k & ((uint16_T)255U));
            rtb_Data_i1qt[2] = (uint8_T)(rtb_y_ktlp & 255U);
            rtb_Data_i1qt[3] = (uint8_T)(rtb_y_kbdv & 255U);
            rtb_Data_i1qt[4] = (uint8_T)(rtb_y_nfoj & 255U);
            rtb_Data_i1qt[5] = (uint8_T)(rtb_y_obcg & 255U);
        }
        else
        {
            for (i = 0; i < 6; i++)
            {
                rtb_Data_i1qt[i] = localB->Switch2_mx0e[i + ((int32_T)
                    localB->Index_lxaz)];
            }
        }

        /* End of Switch: '<S149>/Switch' */
    }
    else
    {
        for (i = 0; i < 6; i++)
        {
            rtb_Data_i1qt[i] = ((uint8_T)0U);
        }
    }

    /* End of Switch: '<S149>/Switch7' */

    /* SignalConversion: '<S160>/Signal Conversion4' */
    localB->SignalConversion4_p5cw = rtb_Busy_bzxf;

    /* SignalConversion: '<S190>/Signal Conversion' incorporates:
     *  Logic: '<S6>/Logical Operator2'
     *  RelationalOperator: '<S6>/Relational Operator1'
     *  SignalConversion: '<S6>/Signal Conversion3'
     *  SignalConversion: '<S6>/Signal Conversion5'
     */
    localB->SignalConversion_ia23 =
        ((HandlePesRequestData_ConstB.uint8_boolean_jkzh == rtu_Parameter) &&
         rtb_IsNewRequestFromGecb);

    /* Logic: '<S185>/Logical Operator2' incorporates:
     *  Constant: '<S191>/Constant'
     *  Delay: '<S190>/Delay'
     *  Logic: '<S184>/Logical Operator3'
     *  Logic: '<S185>/Logical Operator1'
     *  Logic: '<S190>/Logical Operator'
     *  RelationalOperator: '<S190>/Relational Operator'
     *  RelationalOperator: '<S191>/Compare'
     *  UnitDelay: '<S184>/Unit Delay'
     */
    rtb_SendHeader_nmps = ((((localB->SignalConversion_ia23 == true) &&
        (localB->SignalConversion_ia23 != localDW->Delay_DSTATE_phxe)) &&
                            (((int32_T)HandlePesRequestData_ConstB.Compare_lkdi)
        != 0)) && (rtb_SendHeader_tmp && (!localDW->UnitDelay_DSTATE_f2tt)));

    /* Switch: '<S186>/Switch1' incorporates:
     *  SignalConversion: '<S184>/Signal Conversion8'
     *  UnitDelay: '<S186>/Unit Delay3'
     */
    if (rtb_SendHeader_nmps)
    {
        localB->PesDataIdLatched_k0h1 =
            HandlePesRequestData_ConstB.PesDataId_goyp;
    }
    else
    {
        localB->PesDataIdLatched_k0h1 = localDW->UnitDelay3_DSTATE_nu0k;
    }

    /* End of Switch: '<S186>/Switch1' */

    /* SignalConversion: '<S202>/Signal Conversion4' incorporates:
     *  DataTypeConversion: '<S188>/uint8_boolean'
     */
    rtb_Uint16_p4ia = (uint16_T)localB->PesDataIdLatched_k0h1;

    /* Outputs for Atomic SubSystem: '<S205>/Bit Shift1' */
    rtb_y_go0w = HandlePesRequestData_BitShift1(rtb_Uint16_p4ia);

    /* End of Outputs for SubSystem: '<S205>/Bit Shift1' */

    /* Outputs for Atomic SubSystem: '<S205>/Bit Shift2' */
    rtb_y_arqy = HandlePesRequestData_BitShift2(rtb_Uint16_p4ia);

    /* End of Outputs for SubSystem: '<S205>/Bit Shift2' */

    /* Switch: '<S186>/Switch3' incorporates:
     *  SignalConversion: '<S184>/Signal Conversion8'
     *  UnitDelay: '<S186>/Unit Delay2'
     */
    if (rtb_SendHeader_nmps)
    {
        localB->Switch3_arr0 = HandlePesRequestData_ConstB.Length_o4bp;
    }
    else
    {
        localB->Switch3_arr0 = localDW->UnitDelay2_DSTATE_exsu;
    }

    /* End of Switch: '<S186>/Switch3' */
    /* MATLAB Function 'CalculateCrc32/MatlabFunctionCall': '<S204>:1' */
    /* '<S204>:1:3' if (coder.target('Sfun')) */
    /* '<S204>:1:8' else */
    /*  embedded coder ------------------------------------------------- */
    /* '<S204>:1:10' coder.cinclude('Hlp/Crc32.h'); */
    /*  invoke C function */
    /* '<S204>:1:13' Crc32 = coder.ceval('HlpCrc32_Calculate16BitLength', data, length); */
    for (i = 0; i < 18; i++)
    {
        /* Switch: '<S186>/Switch2' incorporates:
         *  SignalConversion: '<S184>/Signal Conversion8'
         *  SignalConversion: '<S6>/Signal Conversion1'
         *  UnitDelay: '<S186>/Unit Delay1'
         */
        if (rtb_SendHeader_nmps)
        {
            localB->Switch2_cjtx[i] = rtu_PcbInfo->PcbPartNumber[i];
        }
        else
        {
            localB->Switch2_cjtx[i] = localDW->UnitDelay1_DSTATE_cybz[i];
        }

        /* End of Switch: '<S186>/Switch2' */

        /* SignalConversion: '<S201>/Signal Conversion4' */
        tmp[i] = localB->Switch2_cjtx[i];
    }

    /* SignalConversion: '<S203>/Signal Conversion4' incorporates:
     *  MATLAB Function: '<S201>/MatlabFunctionCall'
     *  SignalConversion: '<S201>/Signal Conversion1'
     */
    rtb_Uint32_msw4 = HlpCrc32_Calculate16BitLength(tmp, localB->Switch3_arr0);

    /* Outputs for Atomic SubSystem: '<S210>/Bit Shift4' */
    rtb_y_hzzr = HandlePesRequestData_BitShift4(rtb_Uint32_msw4);

    /* End of Outputs for SubSystem: '<S210>/Bit Shift4' */

    /* Outputs for Atomic SubSystem: '<S210>/Bit Shift3' */
    rtb_y_nfcz = HandlePesRequestData_BitShift3(rtb_Uint32_msw4);

    /* End of Outputs for SubSystem: '<S210>/Bit Shift3' */

    /* Outputs for Atomic SubSystem: '<S210>/Bit Shift1' */
    rtb_y_ofuc = HandlePesRequestData_BitShift1_llun(rtb_Uint32_msw4);

    /* End of Outputs for SubSystem: '<S210>/Bit Shift1' */

    /* Outputs for Atomic SubSystem: '<S210>/Bit Shift2' */
    rtb_y_apym = HandlePesRequestData_BitShift2_jycu(rtb_Uint32_msw4);

    /* End of Outputs for SubSystem: '<S210>/Bit Shift2' */

    /* SignalConversion: '<S194>/Signal Conversion' */
    localB->SignalConversion_g5jk = rtb_SendHeader_nmps;

    /* Logic: '<S194>/Logical Operator' incorporates:
     *  Constant: '<S200>/Constant'
     *  Delay: '<S194>/Delay'
     *  RelationalOperator: '<S194>/Relational Operator'
     *  RelationalOperator: '<S200>/Compare'
     */
    rtb_LogicalOperator_pwgp = ((localB->SignalConversion_g5jk == false) &&
        (localB->SignalConversion_g5jk != localDW->Delay_DSTATE_dj3a));

    /* SignalConversion: '<S198>/Signal Conversion' incorporates:
     *  Constant: '<S193>/Unused'
     *  Logic: '<S193>/Logical Operator1'
     *  Logic: '<S193>/Logical Operator2'
     *  Logic: '<S193>/Logical Operator3'
     *  RelationalOperator: '<S193>/Relational Operator1'
     *  SignalConversion: '<S194>/Signal Conversion1'
     *  Sum: '<S193>/Add1'
     *  UnitDelay: '<S187>/Unit Delay'
     */
    localB->SignalConversion_gbpe = (((((uint16_T)((uint8_T)(((uint32_T)
        ((uint8_T)6U)) + ((uint32_T)localDW->UnitDelay_DSTATE_npvr)))) >=
        localB->Switch3_arr0) && (!rtb_SendHeader_nmps)) &&
        (!rtb_LogicalOperator_pwgp));

    /* Logic: '<S197>/Logical Operator2' incorporates:
     *  Constant: '<S199>/Constant'
     *  Delay: '<S198>/Delay'
     *  Logic: '<S198>/Logical Operator'
     *  RelationalOperator: '<S198>/Relational Operator'
     *  RelationalOperator: '<S199>/Compare'
     */
    rtb_NoReset_fgq1 = ((localB->SignalConversion_gbpe != true) ||
                        (localB->SignalConversion_gbpe ==
                         localDW->Delay_DSTATE_hyd1));

    /* Logic: '<S197>/Logical Operator3' incorporates:
     *  Logic: '<S197>/Logical Operator1'
     *  Logic: '<S197>/Logical Operator4'
     *  SignalConversion: '<S194>/Signal Conversion1'
     *  UnitDelay: '<S197>/Unit Delay1'
     */
    localB->Out_oztf = ((rtb_LogicalOperator_pwgp && rtb_NoReset_fgq1) ||
                        (rtb_NoReset_fgq1 && (localDW->UnitDelay1_DSTATE_jega)));

    /* Logic: '<S187>/Logical Operator3' incorporates:
     *  SignalConversion: '<S197>/Signal Conversion2'
     */
    rtb_Busy_n5fp = (rtb_SendHeader_nmps || (localB->Out_oztf));

    /* Switch: '<S187>/Switch' incorporates:
     *  Constant: '<S187>/Unused1'
     *  Logic: '<S187>/Logical Operator1'
     *  Logic: '<S187>/Logical Operator4'
     *  SignalConversion: '<S194>/Signal Conversion1'
     *  SignalConversion: '<S197>/Signal Conversion2'
     *  Sum: '<S196>/Add'
     *  Switch: '<S196>/Switch1'
     *  UnitDelay: '<S187>/Unit Delay'
     */
    if (((!rtb_Busy_n5fp) || rtb_SendHeader_nmps) || rtb_LogicalOperator_pwgp)
    {
        localB->Index_j1ov = ((uint8_T)0U);
    }
    else
    {
        if (localB->Out_oztf)
        {
            /* Switch: '<S196>/Switch1' incorporates:
             *  Constant: '<S196>/Unused'
             */
            tmp_0 = ((uint8_T)6U);
        }
        else
        {
            /* Switch: '<S196>/Switch1' incorporates:
             *  Constant: '<S196>/Unused3'
             */
            tmp_0 = ((uint8_T)0U);
        }

        localB->Index_j1ov = (uint8_T)(((uint32_T)tmp_0) + ((uint32_T)
            localDW->UnitDelay_DSTATE_npvr));
    }

    /* End of Switch: '<S187>/Switch' */

    /* Switch: '<S184>/Switch7' incorporates:
     *  Constant: '<S184>/Unused2'
     */
    if (rtb_Busy_n5fp)
    {
        /* Switch: '<S184>/Switch' incorporates:
         *  DataTypeConversion: '<S205>/Data Type Conversion1'
         *  DataTypeConversion: '<S205>/Data Type Conversion2'
         *  DataTypeConversion: '<S210>/Data Type Conversion'
         *  DataTypeConversion: '<S210>/Data Type Conversion1'
         *  DataTypeConversion: '<S210>/Data Type Conversion2'
         *  DataTypeConversion: '<S210>/Data Type Conversion3'
         *  S-Function (sfix_bitop): '<S205>/Bitwise Operator1'
         *  S-Function (sfix_bitop): '<S205>/Bitwise Operator2'
         *  S-Function (sfix_bitop): '<S210>/Bitwise Operator1'
         *  S-Function (sfix_bitop): '<S210>/Bitwise Operator2'
         *  S-Function (sfix_bitop): '<S210>/Bitwise Operator3'
         *  S-Function (sfix_bitop): '<S210>/Bitwise Operator4'
         *  Selector: '<S184>/Selector'
         */
        if (rtb_SendHeader_nmps)
        {
            rtb_Data_autm[0] = (uint8_T)(rtb_y_go0w & ((uint16_T)255U));
            rtb_Data_autm[1] = (uint8_T)(rtb_y_arqy & ((uint16_T)255U));
            rtb_Data_autm[2] = (uint8_T)(rtb_y_hzzr & 255U);
            rtb_Data_autm[3] = (uint8_T)(rtb_y_nfcz & 255U);
            rtb_Data_autm[4] = (uint8_T)(rtb_y_ofuc & 255U);
            rtb_Data_autm[5] = (uint8_T)(rtb_y_apym & 255U);
        }
        else
        {
            for (i = 0; i < 6; i++)
            {
                rtb_Data_autm[i] = localB->Switch2_cjtx[i + ((int32_T)
                    localB->Index_j1ov)];
            }
        }

        /* End of Switch: '<S184>/Switch' */
    }
    else
    {
        for (i = 0; i < 6; i++)
        {
            rtb_Data_autm[i] = ((uint8_T)0U);
        }
    }

    /* End of Switch: '<S184>/Switch7' */

    /* SignalConversion: '<S195>/Signal Conversion4' */
    localB->SignalConversion4_jr4x = rtb_Busy_n5fp;

    /* SignalConversion: '<S225>/Signal Conversion' incorporates:
     *  Logic: '<S7>/Logical Operator2'
     *  RelationalOperator: '<S7>/Relational Operator1'
     *  SignalConversion: '<S7>/Signal Conversion3'
     *  SignalConversion: '<S7>/Signal Conversion5'
     */
    localB->SignalConversion_aofk =
        ((HandlePesRequestData_ConstB.uint8_boolean_gubr == rtu_Parameter) &&
         rtb_IsNewRequestFromGecb);

    /* Logic: '<S220>/Logical Operator2' incorporates:
     *  Constant: '<S226>/Constant'
     *  Delay: '<S225>/Delay'
     *  Logic: '<S219>/Logical Operator3'
     *  Logic: '<S220>/Logical Operator1'
     *  Logic: '<S225>/Logical Operator'
     *  RelationalOperator: '<S225>/Relational Operator'
     *  RelationalOperator: '<S226>/Compare'
     *  UnitDelay: '<S219>/Unit Delay'
     */
    rtb_SendHeader_c3cc = ((((localB->SignalConversion_aofk == true) &&
        (localB->SignalConversion_aofk != localDW->Delay_DSTATE_c1vr)) &&
                            (((int32_T)HandlePesRequestData_ConstB.Compare_nssh)
        != 0)) && (rtb_SendHeader_tmp && (!localDW->UnitDelay_DSTATE_jupf)));

    /* Switch: '<S221>/Switch1' incorporates:
     *  SignalConversion: '<S219>/Signal Conversion8'
     *  UnitDelay: '<S221>/Unit Delay3'
     */
    if (rtb_SendHeader_c3cc)
    {
        localB->PesDataIdLatched_pnve =
            HandlePesRequestData_ConstB.PesDataId_pd32;
    }
    else
    {
        localB->PesDataIdLatched_pnve = localDW->UnitDelay3_DSTATE_mpus;
    }

    /* End of Switch: '<S221>/Switch1' */

    /* SignalConversion: '<S237>/Signal Conversion4' incorporates:
     *  DataTypeConversion: '<S223>/uint8_boolean'
     */
    rtb_Uint16_oifs = (uint16_T)localB->PesDataIdLatched_pnve;

    /* Outputs for Atomic SubSystem: '<S240>/Bit Shift1' */
    rtb_y_lqsb = HandlePesRequestData_BitShift1(rtb_Uint16_oifs);

    /* End of Outputs for SubSystem: '<S240>/Bit Shift1' */

    /* Outputs for Atomic SubSystem: '<S240>/Bit Shift2' */
    rtb_y_pctd = HandlePesRequestData_BitShift2(rtb_Uint16_oifs);

    /* End of Outputs for SubSystem: '<S240>/Bit Shift2' */

    /* Switch: '<S221>/Switch2' incorporates:
     *  SignalConversion: '<S219>/Signal Conversion8'
     *  SignalConversion: '<S7>/Signal Conversion1'
     *  UnitDelay: '<S221>/Unit Delay1'
     */
    for (i = 0; i < 36; i++)
    {
        if (rtb_SendHeader_c3cc)
        {
            localB->Switch2_p0tp[i] = rtu_PcbInfo->SystemManufacturer[i];
        }
        else
        {
            localB->Switch2_p0tp[i] = localDW->UnitDelay1_DSTATE_mcyh[i];
        }
    }

    /* End of Switch: '<S221>/Switch2' */

    /* SignalConversion: '<S236>/Signal Conversion4' */
    for (i = 0; i < 36; i++)
    {
        rtb_Data_fgmn[i] = localB->Switch2_p0tp[i];
    }

    /* End of SignalConversion: '<S236>/Signal Conversion4' */

    /* Switch: '<S221>/Switch3' incorporates:
     *  SignalConversion: '<S219>/Signal Conversion8'
     *  UnitDelay: '<S221>/Unit Delay2'
     */
    if (rtb_SendHeader_c3cc)
    {
        localB->Switch3_h3dv = HandlePesRequestData_ConstB.Length_nla4;
    }
    else
    {
        localB->Switch3_h3dv = localDW->UnitDelay2_DSTATE_esvh;
    }

    /* End of Switch: '<S221>/Switch3' */

    /* SignalConversion: '<S236>/Signal Conversion1' */
    rtb_Length_mnta = localB->Switch3_h3dv;

    /* MATLAB Function: '<S236>/MatlabFunctionCall' */
    HandlePesRequestData_MatlabFunctionCall_i5sj(rtb_Data_fgmn, rtb_Length_mnta,
        &rtb_Crc32);

    /* SignalConversion: '<S238>/Signal Conversion4' incorporates:
     *  SignalConversion: '<S236>/Signal Conversion2'
     */
    rtb_Uint32_nakg = rtb_Crc32;

    /* Outputs for Atomic SubSystem: '<S245>/Bit Shift4' */
    rtb_y = HandlePesRequestData_BitShift4(rtb_Uint32_nakg);

    /* End of Outputs for SubSystem: '<S245>/Bit Shift4' */

    /* Outputs for Atomic SubSystem: '<S245>/Bit Shift3' */
    rtb_y_dcue = HandlePesRequestData_BitShift3(rtb_Uint32_nakg);

    /* End of Outputs for SubSystem: '<S245>/Bit Shift3' */

    /* Outputs for Atomic SubSystem: '<S245>/Bit Shift1' */
    rtb_y_icwy = HandlePesRequestData_BitShift1_llun(rtb_Uint32_nakg);

    /* End of Outputs for SubSystem: '<S245>/Bit Shift1' */

    /* Outputs for Atomic SubSystem: '<S245>/Bit Shift2' */
    rtb_y_gk5b = HandlePesRequestData_BitShift2_jycu(rtb_Uint32_nakg);

    /* End of Outputs for SubSystem: '<S245>/Bit Shift2' */

    /* SignalConversion: '<S229>/Signal Conversion' */
    localB->SignalConversion_ppux = rtb_SendHeader_c3cc;

    /* Logic: '<S229>/Logical Operator' incorporates:
     *  Constant: '<S235>/Constant'
     *  Delay: '<S229>/Delay'
     *  RelationalOperator: '<S229>/Relational Operator'
     *  RelationalOperator: '<S235>/Compare'
     */
    rtb_LogicalOperator_izy4 = ((localB->SignalConversion_ppux == false) &&
        (localB->SignalConversion_ppux != localDW->Delay_DSTATE_lhko));

    /* SignalConversion: '<S233>/Signal Conversion' incorporates:
     *  Constant: '<S228>/Unused'
     *  Logic: '<S228>/Logical Operator1'
     *  Logic: '<S228>/Logical Operator2'
     *  Logic: '<S228>/Logical Operator3'
     *  RelationalOperator: '<S228>/Relational Operator1'
     *  SignalConversion: '<S229>/Signal Conversion1'
     *  Sum: '<S228>/Add1'
     *  UnitDelay: '<S222>/Unit Delay'
     */
    localB->SignalConversion_kmeu = (((((uint16_T)((uint8_T)(((uint32_T)
        ((uint8_T)6U)) + ((uint32_T)localDW->UnitDelay_DSTATE_c4uk)))) >=
        localB->Switch3_h3dv) && (!rtb_SendHeader_c3cc)) &&
        (!rtb_LogicalOperator_izy4));

    /* Logic: '<S232>/Logical Operator2' incorporates:
     *  Constant: '<S234>/Constant'
     *  Delay: '<S233>/Delay'
     *  Logic: '<S233>/Logical Operator'
     *  RelationalOperator: '<S233>/Relational Operator'
     *  RelationalOperator: '<S234>/Compare'
     */
    rtb_NoReset_lqry = ((localB->SignalConversion_kmeu != true) ||
                        (localB->SignalConversion_kmeu ==
                         localDW->Delay_DSTATE_ksay));

    /* Logic: '<S232>/Logical Operator3' incorporates:
     *  Logic: '<S232>/Logical Operator1'
     *  Logic: '<S232>/Logical Operator4'
     *  SignalConversion: '<S229>/Signal Conversion1'
     *  UnitDelay: '<S232>/Unit Delay1'
     */
    localB->Out_pvzw = ((rtb_LogicalOperator_izy4 && rtb_NoReset_lqry) ||
                        (rtb_NoReset_lqry && (localDW->UnitDelay1_DSTATE_cr4r)));

    /* Logic: '<S222>/Logical Operator3' incorporates:
     *  SignalConversion: '<S232>/Signal Conversion2'
     */
    rtb_Busy_lxks = (rtb_SendHeader_c3cc || (localB->Out_pvzw));

    /* Switch: '<S222>/Switch' incorporates:
     *  Constant: '<S222>/Unused1'
     *  Logic: '<S222>/Logical Operator1'
     *  Logic: '<S222>/Logical Operator4'
     *  SignalConversion: '<S229>/Signal Conversion1'
     *  SignalConversion: '<S232>/Signal Conversion2'
     *  Sum: '<S231>/Add'
     *  Switch: '<S231>/Switch1'
     *  UnitDelay: '<S222>/Unit Delay'
     */
    if (((!rtb_Busy_lxks) || rtb_SendHeader_c3cc) || rtb_LogicalOperator_izy4)
    {
        localB->Index_fvuh = ((uint8_T)0U);
    }
    else
    {
        if (localB->Out_pvzw)
        {
            /* Switch: '<S231>/Switch1' incorporates:
             *  Constant: '<S231>/Unused'
             */
            tmp_0 = ((uint8_T)6U);
        }
        else
        {
            /* Switch: '<S231>/Switch1' incorporates:
             *  Constant: '<S231>/Unused3'
             */
            tmp_0 = ((uint8_T)0U);
        }

        localB->Index_fvuh = (uint8_T)(((uint32_T)tmp_0) + ((uint32_T)
            localDW->UnitDelay_DSTATE_c4uk));
    }

    /* End of Switch: '<S222>/Switch' */

    /* Switch: '<S219>/Switch7' incorporates:
     *  Constant: '<S219>/Unused2'
     */
    if (rtb_Busy_lxks)
    {
        /* Switch: '<S219>/Switch' incorporates:
         *  DataTypeConversion: '<S240>/Data Type Conversion1'
         *  DataTypeConversion: '<S240>/Data Type Conversion2'
         *  DataTypeConversion: '<S245>/Data Type Conversion'
         *  DataTypeConversion: '<S245>/Data Type Conversion1'
         *  DataTypeConversion: '<S245>/Data Type Conversion2'
         *  DataTypeConversion: '<S245>/Data Type Conversion3'
         *  S-Function (sfix_bitop): '<S240>/Bitwise Operator1'
         *  S-Function (sfix_bitop): '<S240>/Bitwise Operator2'
         *  S-Function (sfix_bitop): '<S245>/Bitwise Operator1'
         *  S-Function (sfix_bitop): '<S245>/Bitwise Operator2'
         *  S-Function (sfix_bitop): '<S245>/Bitwise Operator3'
         *  S-Function (sfix_bitop): '<S245>/Bitwise Operator4'
         *  Selector: '<S219>/Selector'
         */
        if (rtb_SendHeader_c3cc)
        {
            rtb_Data_fp3n[0] = (uint8_T)(rtb_y_lqsb & ((uint16_T)255U));
            rtb_Data_fp3n[1] = (uint8_T)(rtb_y_pctd & ((uint16_T)255U));
            rtb_Data_fp3n[2] = (uint8_T)(rtb_y & 255U);
            rtb_Data_fp3n[3] = (uint8_T)(rtb_y_dcue & 255U);
            rtb_Data_fp3n[4] = (uint8_T)(rtb_y_icwy & 255U);
            rtb_Data_fp3n[5] = (uint8_T)(rtb_y_gk5b & 255U);
        }
        else
        {
            for (i = 0; i < 6; i++)
            {
                rtb_Data_fp3n[i] = localB->Switch2_p0tp[i + ((int32_T)
                    localB->Index_fvuh)];
            }
        }

        /* End of Switch: '<S219>/Switch' */
    }
    else
    {
        for (i = 0; i < 6; i++)
        {
            rtb_Data_fp3n[i] = ((uint8_T)0U);
        }
    }

    /* End of Switch: '<S219>/Switch7' */

    /* SignalConversion: '<S230>/Signal Conversion4' */
    localB->SignalConversion4_mesa = rtb_Busy_lxks;

    /* Switch: '<S7>/Switch' incorporates:
     *  BusCreator: '<S219>/Bus Creator'
     *  SignalConversion: '<S114>/Signal Conversion6'
     *  SignalConversion: '<S149>/Signal Conversion6'
     *  SignalConversion: '<S184>/Signal Conversion6'
     *  SignalConversion: '<S219>/Signal Conversion6'
     *  SignalConversion: '<S44>/Signal Conversion6'
     *  SignalConversion: '<S79>/Signal Conversion6'
     *  SignalConversion: '<S9>/Signal Conversion6'
     *  Switch: '<S1>/Switch'
     *  Switch: '<S2>/Switch'
     *  Switch: '<S3>/Switch'
     *  Switch: '<S4>/Switch'
     *  Switch: '<S5>/Switch'
     *  Switch: '<S6>/Switch'
     */
    if (rtb_Busy_lxks)
    {
        /* SignalConversion: '<S7>/Signal Conversion8' incorporates:
         *  SignalConversion: '<S7>/Signal Conversion10'
         */
        rty_PesData->RequesterNodeAddr = rtu_RequesterNodeAddr;
        for (i = 0; i < 6; i++)
        {
            rtb_PesData_hbel_Data[i] = rtb_Data_fp3n[i];
        }

        rtb_SendHeader_tmp = true;
    }
    else if (rtb_Busy_n5fp)
    {
        /* SignalConversion: '<S7>/Signal Conversion8' incorporates:
         *  SignalConversion: '<S6>/Signal Conversion10'
         *  Switch: '<S6>/Switch'
         */
        rty_PesData->RequesterNodeAddr = rtu_RequesterNodeAddr;

        /* Switch: '<S6>/Switch' incorporates:
         *  BusCreator: '<S184>/Bus Creator'
         *  SignalConversion: '<S184>/Signal Conversion6'
         */
        for (i = 0; i < 6; i++)
        {
            rtb_PesData_hbel_Data[i] = rtb_Data_autm[i];
        }

        rtb_SendHeader_tmp = true;
    }
    else if (rtb_Busy_bzxf)
    {
        /* SignalConversion: '<S7>/Signal Conversion8' incorporates:
         *  SignalConversion: '<S5>/Signal Conversion10'
         *  Switch: '<S5>/Switch'
         *  Switch: '<S6>/Switch'
         */
        rty_PesData->RequesterNodeAddr = rtu_RequesterNodeAddr;
        for (i = 0; i < 6; i++)
        {
            /* Switch: '<S5>/Switch' incorporates:
             *  BusCreator: '<S149>/Bus Creator'
             *  Switch: '<S6>/Switch'
             */
            rtb_PesData_hbel_Data[i] = rtb_Data_i1qt[i];
        }

        /* Switch: '<S5>/Switch' incorporates:
         *  SignalConversion: '<S149>/Signal Conversion6'
         *  Switch: '<S6>/Switch'
         */
        rtb_SendHeader_tmp = true;
    }
    else if (rtb_Busy_lemt)
    {
        /* SignalConversion: '<S7>/Signal Conversion8' incorporates:
         *  SignalConversion: '<S4>/Signal Conversion10'
         *  Switch: '<S4>/Switch'
         *  Switch: '<S5>/Switch'
         *  Switch: '<S6>/Switch'
         */
        rty_PesData->RequesterNodeAddr = rtu_RequesterNodeAddr;
        for (i = 0; i < 6; i++)
        {
            /* Switch: '<S5>/Switch' incorporates:
             *  BusCreator: '<S114>/Bus Creator'
             *  Switch: '<S4>/Switch'
             *  Switch: '<S6>/Switch'
             */
            rtb_PesData_hbel_Data[i] = rtb_Data_feal[i];
        }

        /* Switch: '<S5>/Switch' incorporates:
         *  SignalConversion: '<S114>/Signal Conversion6'
         *  Switch: '<S4>/Switch'
         *  Switch: '<S6>/Switch'
         */
        rtb_SendHeader_tmp = true;
    }
    else if (rtb_Busy_lntr)
    {
        /* SignalConversion: '<S7>/Signal Conversion8' incorporates:
         *  SignalConversion: '<S3>/Signal Conversion10'
         *  Switch: '<S3>/Switch'
         *  Switch: '<S4>/Switch'
         *  Switch: '<S5>/Switch'
         *  Switch: '<S6>/Switch'
         */
        rty_PesData->RequesterNodeAddr = rtu_RequesterNodeAddr;
        for (i = 0; i < 6; i++)
        {
            /* Switch: '<S3>/Switch' incorporates:
             *  BusCreator: '<S79>/Bus Creator'
             *  Switch: '<S4>/Switch'
             *  Switch: '<S5>/Switch'
             *  Switch: '<S6>/Switch'
             */
            rtb_PesData_hbel_Data[i] = rtb_Data_ov5q[i];
        }

        /* Switch: '<S3>/Switch' incorporates:
         *  SignalConversion: '<S79>/Signal Conversion6'
         *  Switch: '<S4>/Switch'
         *  Switch: '<S5>/Switch'
         *  Switch: '<S6>/Switch'
         */
        rtb_SendHeader_tmp = true;
    }
    else if (rtb_Busy_jtgs)
    {
        /* SignalConversion: '<S7>/Signal Conversion8' incorporates:
         *  SignalConversion: '<S2>/Signal Conversion10'
         *  Switch: '<S2>/Switch'
         *  Switch: '<S3>/Switch'
         *  Switch: '<S4>/Switch'
         *  Switch: '<S5>/Switch'
         *  Switch: '<S6>/Switch'
         */
        rty_PesData->RequesterNodeAddr = rtu_RequesterNodeAddr;
        for (i = 0; i < 6; i++)
        {
            /* Switch: '<S3>/Switch' incorporates:
             *  BusCreator: '<S44>/Bus Creator'
             *  Switch: '<S2>/Switch'
             *  Switch: '<S4>/Switch'
             *  Switch: '<S5>/Switch'
             *  Switch: '<S6>/Switch'
             */
            rtb_PesData_hbel_Data[i] = rtb_Data_h0vb[i];
        }

        /* Switch: '<S3>/Switch' incorporates:
         *  SignalConversion: '<S44>/Signal Conversion6'
         *  Switch: '<S2>/Switch'
         *  Switch: '<S4>/Switch'
         *  Switch: '<S5>/Switch'
         *  Switch: '<S6>/Switch'
         */
        rtb_SendHeader_tmp = true;
    }
    else if (rtb_Busy)
    {
        /* SignalConversion: '<S7>/Signal Conversion8' incorporates:
         *  SignalConversion: '<S1>/Signal Conversion10'
         *  Switch: '<S1>/Switch'
         *  Switch: '<S2>/Switch'
         *  Switch: '<S3>/Switch'
         *  Switch: '<S4>/Switch'
         *  Switch: '<S5>/Switch'
         *  Switch: '<S6>/Switch'
         */
        rty_PesData->RequesterNodeAddr = rtu_RequesterNodeAddr;
        for (i = 0; i < 6; i++)
        {
            /* Switch: '<S3>/Switch' incorporates:
             *  BusCreator: '<S9>/Bus Creator'
             *  Switch: '<S1>/Switch'
             *  Switch: '<S2>/Switch'
             *  Switch: '<S4>/Switch'
             *  Switch: '<S5>/Switch'
             *  Switch: '<S6>/Switch'
             */
            rtb_PesData_hbel_Data[i] = rtb_Data_nmj0[i];
        }

        /* Switch: '<S3>/Switch' incorporates:
         *  SignalConversion: '<S9>/Signal Conversion6'
         *  Switch: '<S1>/Switch'
         *  Switch: '<S2>/Switch'
         *  Switch: '<S4>/Switch'
         *  Switch: '<S5>/Switch'
         *  Switch: '<S6>/Switch'
         */
        rtb_SendHeader_tmp = true;
    }
    else
    {
        /* SignalConversion: '<S7>/Signal Conversion8' incorporates:
         *  SignalConversion: '<S1>/Signal Conversion7'
         *  Switch: '<S1>/Switch'
         *  Switch: '<S2>/Switch'
         *  Switch: '<S3>/Switch'
         *  Switch: '<S4>/Switch'
         *  Switch: '<S5>/Switch'
         *  Switch: '<S6>/Switch'
         */
        rty_PesData->RequesterNodeAddr = rtu_PesDataIn->RequesterNodeAddr;
        for (i = 0; i < 6; i++)
        {
            /* Switch: '<S3>/Switch' incorporates:
             *  SignalConversion: '<S1>/Signal Conversion7'
             *  Switch: '<S1>/Switch'
             *  Switch: '<S2>/Switch'
             *  Switch: '<S4>/Switch'
             *  Switch: '<S5>/Switch'
             *  Switch: '<S6>/Switch'
             */
            rtb_PesData_hbel_Data[i] = rtu_PesDataIn->Data[i];
        }

        /* Switch: '<S3>/Switch' incorporates:
         *  SignalConversion: '<S1>/Signal Conversion7'
         *  Switch: '<S1>/Switch'
         *  Switch: '<S2>/Switch'
         *  Switch: '<S4>/Switch'
         *  Switch: '<S5>/Switch'
         *  Switch: '<S6>/Switch'
         */
        rtb_SendHeader_tmp = rtu_PesDataIn->Send;
    }

    /* End of Switch: '<S7>/Switch' */

    /* SignalConversion: '<S7>/Signal Conversion8' */
    for (i = 0; i < 6; i++)
    {
        rty_PesData->Data[i] = rtb_PesData_hbel_Data[i];
    }

    rty_PesData->Send = rtb_SendHeader_tmp;

    /* Logic: '<Root>/Logical Operator3' incorporates:
     *  SignalConversion: '<S114>/Signal Conversion9'
     *  SignalConversion: '<S149>/Signal Conversion9'
     *  SignalConversion: '<S184>/Signal Conversion9'
     *  SignalConversion: '<S219>/Signal Conversion9'
     *  SignalConversion: '<S44>/Signal Conversion9'
     *  SignalConversion: '<S79>/Signal Conversion9'
     *  SignalConversion: '<S9>/Signal Conversion9'
     */
    *rty_BusyData = (((((((localB->SignalConversion4_mesa) ||
                          (localB->SignalConversion4_jr4x)) ||
                         (localB->SignalConversion4_p5cw)) ||
                        (localB->SignalConversion4_doml)) ||
                       (localB->SignalConversion4_dtni)) ||
                      (localB->SignalConversion4_ha1f)) ||
                     (localB->SignalConversion4));
}

/* Update for referenced model: 'HandlePesRequestData' */
void HandlePesRequestData_Update(B_HandlePesRequestData_caua_T *localB,
    DW_HandlePesRequestData_fwu4_T *localDW)
{
    int32_T i;

    /* Update for Delay: '<S15>/Delay' */
    localDW->Delay_DSTATE = localB->SignalConversion;

    /* Update for UnitDelay: '<S9>/Unit Delay' */
    localDW->UnitDelay_DSTATE_mbfm = localB->SignalConversion4;

    /* Update for UnitDelay: '<S11>/Unit Delay3' */
    localDW->UnitDelay3_DSTATE = localB->PesDataIdLatched;

    /* Update for UnitDelay: '<S11>/Unit Delay2' */
    localDW->UnitDelay2_DSTATE = localB->Switch3;

    /* Update for Delay: '<S19>/Delay' */
    localDW->Delay_DSTATE_mouf = localB->SignalConversion_pamv;

    /* Update for UnitDelay: '<S12>/Unit Delay' */
    localDW->UnitDelay_DSTATE = localB->Index;

    /* Update for Delay: '<S23>/Delay' */
    localDW->Delay_DSTATE_kpxz = localB->SignalConversion_h52q;

    /* Update for UnitDelay: '<S22>/Unit Delay1' */
    localDW->UnitDelay1_DSTATE_cybj = localB->Out;

    /* Update for Delay: '<S50>/Delay' */
    localDW->Delay_DSTATE_guu4 = localB->SignalConversion_gntb;

    /* Update for UnitDelay: '<S44>/Unit Delay' */
    localDW->UnitDelay_DSTATE_bhvq = localB->SignalConversion4_ha1f;

    /* Update for UnitDelay: '<S46>/Unit Delay3' */
    localDW->UnitDelay3_DSTATE_ix02 = localB->PesDataIdLatched_paou;
    for (i = 0; i < 6; i++)
    {
        /* Update for UnitDelay: '<S11>/Unit Delay1' */
        localDW->UnitDelay1_DSTATE[i] = localB->Switch2[i];

        /* Update for UnitDelay: '<S46>/Unit Delay1' */
        localDW->UnitDelay1_DSTATE_fdfy[i] = localB->Switch2_cv3x[i];
    }

    /* Update for UnitDelay: '<S46>/Unit Delay2' */
    localDW->UnitDelay2_DSTATE_lsm4 = localB->Switch3_pywv;

    /* Update for Delay: '<S54>/Delay' */
    localDW->Delay_DSTATE_lpb0 = localB->SignalConversion_iqjc;

    /* Update for UnitDelay: '<S47>/Unit Delay' */
    localDW->UnitDelay_DSTATE_dzrj = localB->Index_dzmr;

    /* Update for Delay: '<S58>/Delay' */
    localDW->Delay_DSTATE_jyba = localB->SignalConversion_jtmq;

    /* Update for UnitDelay: '<S57>/Unit Delay1' */
    localDW->UnitDelay1_DSTATE_oeub = localB->Out_ax5q;

    /* Update for Delay: '<S85>/Delay' */
    localDW->Delay_DSTATE_an3l = localB->SignalConversion_gt40;

    /* Update for UnitDelay: '<S79>/Unit Delay' */
    localDW->UnitDelay_DSTATE_jbyd = localB->SignalConversion4_dtni;

    /* Update for UnitDelay: '<S81>/Unit Delay3' */
    localDW->UnitDelay3_DSTATE_ckas = localB->PesDataIdLatched_k0fn;

    /* Update for UnitDelay: '<S81>/Unit Delay2' */
    localDW->UnitDelay2_DSTATE_gg5l = localB->Switch3_d2lp;

    /* Update for Delay: '<S89>/Delay' */
    localDW->Delay_DSTATE_dvqt = localB->SignalConversion_artt;

    /* Update for UnitDelay: '<S82>/Unit Delay' */
    localDW->UnitDelay_DSTATE_aw22 = localB->Index_dp2j;

    /* Update for Delay: '<S93>/Delay' */
    localDW->Delay_DSTATE_ng4x = localB->SignalConversion_fly3;

    /* Update for UnitDelay: '<S92>/Unit Delay1' */
    localDW->UnitDelay1_DSTATE_oqju = localB->Out_dpks;

    /* Update for Delay: '<S120>/Delay' */
    localDW->Delay_DSTATE_dkya = localB->SignalConversion_dkfe;

    /* Update for UnitDelay: '<S114>/Unit Delay' */
    localDW->UnitDelay_DSTATE_gum5 = localB->SignalConversion4_doml;

    /* Update for UnitDelay: '<S116>/Unit Delay3' */
    localDW->UnitDelay3_DSTATE_bm3i = localB->PesDataIdLatched_o5dp;

    /* Update for UnitDelay: '<S116>/Unit Delay2' */
    localDW->UnitDelay2_DSTATE_eqis = localB->Switch3_jogv;

    /* Update for Delay: '<S124>/Delay' */
    localDW->Delay_DSTATE_lsmp = localB->SignalConversion_pfwa;

    /* Update for UnitDelay: '<S117>/Unit Delay' */
    localDW->UnitDelay_DSTATE_c5nx = localB->Index_fzh5;

    /* Update for Delay: '<S128>/Delay' */
    localDW->Delay_DSTATE_psqk = localB->SignalConversion_bvfq;

    /* Update for UnitDelay: '<S127>/Unit Delay1' */
    localDW->UnitDelay1_DSTATE_hmbk = localB->Out_p3o0;

    /* Update for Delay: '<S155>/Delay' */
    localDW->Delay_DSTATE_hxzp = localB->SignalConversion_k1xg;

    /* Update for UnitDelay: '<S149>/Unit Delay' */
    localDW->UnitDelay_DSTATE_dn2y = localB->SignalConversion4_p5cw;

    /* Update for UnitDelay: '<S151>/Unit Delay3' */
    localDW->UnitDelay3_DSTATE_k43c = localB->PesDataIdLatched_dyzs;
    for (i = 0; i < 36; i++)
    {
        /* Update for UnitDelay: '<S81>/Unit Delay1' */
        localDW->UnitDelay1_DSTATE_gxz0[i] = localB->Switch2_ieay[i];

        /* Update for UnitDelay: '<S116>/Unit Delay1' */
        localDW->UnitDelay1_DSTATE_ayds[i] = localB->Switch2_pagy[i];

        /* Update for UnitDelay: '<S151>/Unit Delay1' */
        localDW->UnitDelay1_DSTATE_moda[i] = localB->Switch2_mx0e[i];
    }

    /* Update for UnitDelay: '<S151>/Unit Delay2' */
    localDW->UnitDelay2_DSTATE_ewl0 = localB->Switch3_dica;

    /* Update for Delay: '<S159>/Delay' */
    localDW->Delay_DSTATE_gtwo = localB->SignalConversion_jy20;

    /* Update for UnitDelay: '<S152>/Unit Delay' */
    localDW->UnitDelay_DSTATE_a320 = localB->Index_lxaz;

    /* Update for Delay: '<S163>/Delay' */
    localDW->Delay_DSTATE_kedp = localB->SignalConversion_gbds;

    /* Update for UnitDelay: '<S162>/Unit Delay1' */
    localDW->UnitDelay1_DSTATE_owaq = localB->Out_ol0y;

    /* Update for Delay: '<S190>/Delay' */
    localDW->Delay_DSTATE_phxe = localB->SignalConversion_ia23;

    /* Update for UnitDelay: '<S184>/Unit Delay' */
    localDW->UnitDelay_DSTATE_f2tt = localB->SignalConversion4_jr4x;

    /* Update for UnitDelay: '<S186>/Unit Delay3' */
    localDW->UnitDelay3_DSTATE_nu0k = localB->PesDataIdLatched_k0h1;

    /* Update for UnitDelay: '<S186>/Unit Delay1' */
    for (i = 0; i < 18; i++)
    {
        localDW->UnitDelay1_DSTATE_cybz[i] = localB->Switch2_cjtx[i];
    }

    /* End of Update for UnitDelay: '<S186>/Unit Delay1' */

    /* Update for UnitDelay: '<S186>/Unit Delay2' */
    localDW->UnitDelay2_DSTATE_exsu = localB->Switch3_arr0;

    /* Update for Delay: '<S194>/Delay' */
    localDW->Delay_DSTATE_dj3a = localB->SignalConversion_g5jk;

    /* Update for UnitDelay: '<S187>/Unit Delay' */
    localDW->UnitDelay_DSTATE_npvr = localB->Index_j1ov;

    /* Update for Delay: '<S198>/Delay' */
    localDW->Delay_DSTATE_hyd1 = localB->SignalConversion_gbpe;

    /* Update for UnitDelay: '<S197>/Unit Delay1' */
    localDW->UnitDelay1_DSTATE_jega = localB->Out_oztf;

    /* Update for Delay: '<S225>/Delay' */
    localDW->Delay_DSTATE_c1vr = localB->SignalConversion_aofk;

    /* Update for UnitDelay: '<S219>/Unit Delay' */
    localDW->UnitDelay_DSTATE_jupf = localB->SignalConversion4_mesa;

    /* Update for UnitDelay: '<S221>/Unit Delay3' */
    localDW->UnitDelay3_DSTATE_mpus = localB->PesDataIdLatched_pnve;

    /* Update for UnitDelay: '<S221>/Unit Delay1' */
    for (i = 0; i < 36; i++)
    {
        localDW->UnitDelay1_DSTATE_mcyh[i] = localB->Switch2_p0tp[i];
    }

    /* End of Update for UnitDelay: '<S221>/Unit Delay1' */

    /* Update for UnitDelay: '<S221>/Unit Delay2' */
    localDW->UnitDelay2_DSTATE_esvh = localB->Switch3_h3dv;

    /* Update for Delay: '<S229>/Delay' */
    localDW->Delay_DSTATE_lhko = localB->SignalConversion_ppux;

    /* Update for UnitDelay: '<S222>/Unit Delay' */
    localDW->UnitDelay_DSTATE_c4uk = localB->Index_fvuh;

    /* Update for Delay: '<S233>/Delay' */
    localDW->Delay_DSTATE_ksay = localB->SignalConversion_kmeu;

    /* Update for UnitDelay: '<S232>/Unit Delay1' */
    localDW->UnitDelay1_DSTATE_cr4r = localB->Out_pvzw;
}

/* Model initialize function */
void HandlePesRequestData_initialize(B_HandlePesRequestData_caua_T *localB)
{
    /* Registration code */

    /* block I/O */
    {
        localB->PesDataIdLatched = PesDataId_SYSTEM_MANUFACTURER;
        localB->PesDataIdLatched_paou = PesDataId_SYSTEM_MANUFACTURER;
        localB->PesDataIdLatched_k0fn = PesDataId_SYSTEM_MANUFACTURER;
        localB->PesDataIdLatched_o5dp = PesDataId_SYSTEM_MANUFACTURER;
        localB->PesDataIdLatched_dyzs = PesDataId_SYSTEM_MANUFACTURER;
        localB->PesDataIdLatched_k0h1 = PesDataId_SYSTEM_MANUFACTURER;
        localB->PesDataIdLatched_pnve = PesDataId_SYSTEM_MANUFACTURER;
    }
}

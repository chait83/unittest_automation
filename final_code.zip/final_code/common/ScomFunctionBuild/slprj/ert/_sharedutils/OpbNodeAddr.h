/*
 * ---------------------------------------------------------------------------
 * Copyright (c) 2015 UTC - All rights reserved.
 *
 * Model Name:         HandlePesRequestData
 * Code Generation:     -
 * Svn:
 * ---------------------------------------------------------------------------
 */

#ifndef RTW_HEADER_OpbNodeAddr_h_
#define RTW_HEADER_OpbNodeAddr_h_
#include "rtwtypes.h"

typedef enum
{
    OpbNodeAddr_GECB = 1,              /* Default value */
    OpbNodeAddr_SCON = 175,
    OpbNodeAddr_SCAR = 176,
    OpbNodeAddr_STAB = 178,
    OpbNodeAddr_SPIT = 179,
    OpbNodeAddr_CONFIGURATION_MASTER = 189
}

OpbNodeAddr_E;

#endif                                 /* RTW_HEADER_OpbNodeAddr_h_ */

/*
 * ---------------------------------------------------------------------------
 * Copyright (c) 2015 UTC - All rights reserved.
 *
 * Model Name:         ScomFunction
 * Code Generation:    wroblema - Wed Jun 22 13:12:32 2022
 * Svn:
 * ---------------------------------------------------------------------------
 */

#ifndef RTW_HEADER_NvmGlobalFactoryCfgCertificate_B_h_
#define RTW_HEADER_NvmGlobalFactoryCfgCertificate_B_h_
#include "rtwtypes.h"

typedef struct
{
    /* Prefix for manufacturing country */
    uint8_T Prefix;
    uint8_T Number[5];
}

NvmGlobalFactoryCfgCertificate_B;

#endif                      /* RTW_HEADER_NvmGlobalFactoryCfgCertificate_B_h_ */

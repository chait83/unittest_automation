/*
 * ---------------------------------------------------------------------------
 * Copyright (c) 2015 UTC - All rights reserved.
 *
 * Model Name:         ScomFunction
 * Code Generation:    wroblema - Wed Jun 22 13:12:32 2022
 * Svn:
 * ---------------------------------------------------------------------------
 */

#ifndef RTW_HEADER_NvmSystemFloorTable_B_h_
#define RTW_HEADER_NvmSystemFloorTable_B_h_
#include "NvmTableStatus_B.h"
#include "NvmFloorConfiguration_B.h"
#include "rtwtypes.h"

typedef struct
{
    uint16_T RevisionIndex;
    NvmTableStatus_B TableStatus;
    uint32_T CarBufferPosition;
    uint8_T CarBufferReserved;
    uint32_T CWTBufferPosition;
    uint8_T CWTBufferReserved;
    NvmFloorConfiguration_B FloorInfo[24];
    uint8_T FormatVersion;
}

NvmSystemFloorTable_B;

#endif                                 /* RTW_HEADER_NvmSystemFloorTable_B_h_ */

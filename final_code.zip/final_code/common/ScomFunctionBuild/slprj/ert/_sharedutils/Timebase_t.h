/*
 * ---------------------------------------------------------------------------
 * Copyright (c) 2015 UTC - All rights reserved.
 *
 * Model Name:         HandlePesRequest
 * Code Generation:     -
 * Svn:
 * ---------------------------------------------------------------------------
 */

#ifndef RTW_HEADER_Timebase_t_h_
#define RTW_HEADER_Timebase_t_h_
#include "rtwtypes.h"

/* Time since reset in units of 50 us

   The time would wrap around after around 2.48 days if no 24 h reset would occur */
typedef uint32_T Timebase_t;

#endif                                 /* RTW_HEADER_Timebase_t_h_ */

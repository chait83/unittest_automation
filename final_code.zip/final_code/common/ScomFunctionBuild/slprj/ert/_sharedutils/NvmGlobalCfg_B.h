/*
 * ---------------------------------------------------------------------------
 * Copyright (c) 2015 UTC - All rights reserved.
 *
 * Model Name:         ScomFunction
 * Code Generation:    wroblema - Wed Jun 22 13:12:32 2022
 * Svn:
 * ---------------------------------------------------------------------------
 */

#ifndef RTW_HEADER_NvmGlobalCfg_B_h_
#define RTW_HEADER_NvmGlobalCfg_B_h_
#include "rtwtypes.h"

typedef struct
{
    int32_T TapeOffsetLdg00p1mm;
}

NvmGlobalCfg_B;

#endif                                 /* RTW_HEADER_NvmGlobalCfg_B_h_ */

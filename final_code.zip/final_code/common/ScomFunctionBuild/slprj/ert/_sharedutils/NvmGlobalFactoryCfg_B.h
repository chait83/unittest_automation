/*
 * ---------------------------------------------------------------------------
 * Copyright (c) 2015 UTC - All rights reserved.
 *
 * Model Name:         ScomFunction
 * Code Generation:    wroblema - Wed Jun 22 13:12:32 2022
 * Svn:
 * ---------------------------------------------------------------------------
 */

#ifndef RTW_HEADER_NvmGlobalFactoryCfg_B_h_
#define RTW_HEADER_NvmGlobalFactoryCfg_B_h_
#include "NvmGlobalFactoryCfgCertificate_B.h"
#include "NvmGlobalFactoryCfgFactory_B.h"
#include "NvmGlobalFactoryCfgParameter_B.h"
#include "rtwtypes.h"

typedef struct
{
    NvmGlobalFactoryCfgCertificate_B Certificate;
    NvmGlobalFactoryCfgFactory_B Factory;
    NvmGlobalFactoryCfgParameter_B Parameter;
}

NvmGlobalFactoryCfg_B;

#endif                                 /* RTW_HEADER_NvmGlobalFactoryCfg_B_h_ */

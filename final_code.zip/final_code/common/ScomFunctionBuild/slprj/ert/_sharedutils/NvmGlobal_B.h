/*
 * ---------------------------------------------------------------------------
 * Copyright (c) 2015 UTC - All rights reserved.
 *
 * Model Name:         ScomFunction
 * Code Generation:    wroblema - Wed Jun 22 13:12:32 2022
 * Svn:
 * ---------------------------------------------------------------------------
 */

#ifndef RTW_HEADER_NvmGlobal_B_h_
#define RTW_HEADER_NvmGlobal_B_h_
#include "NvmGlobalFactoryCfg_B.h"
#include "NvmGlobalCfg_B.h"
#include "NvmSystemFloorTable_B.h"
#include "rtwtypes.h"

typedef struct
{
    NvmGlobalFactoryCfg_B factoryCfg;
    NvmGlobalCfg_B cfg;
    NvmSystemFloorTable_B SystemFloorTable;
}

NvmGlobal_B;

#endif                                 /* RTW_HEADER_NvmGlobal_B_h_ */

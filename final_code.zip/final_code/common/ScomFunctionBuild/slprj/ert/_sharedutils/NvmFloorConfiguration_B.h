/*
 * ---------------------------------------------------------------------------
 * Copyright (c) 2015 UTC - All rights reserved.
 *
 * Model Name:         ScomFunction
 * Code Generation:    wroblema - Wed Jun 22 13:12:32 2022
 * Svn:
 * ---------------------------------------------------------------------------
 */

#ifndef RTW_HEADER_NvmFloorConfiguration_B_h_
#define RTW_HEADER_NvmFloorConfiguration_B_h_
#include "rtwtypes.h"

typedef struct
{
    bool_t valid;
    bool_t verified;
    uint8_T opening;
    bool_t clipValid;
    uint8_T clips;

    /* min = 0 mm
       max = 1800m = 1800 * 1000 mm = 1500 * 1000 * 10 [1/10 mm] */
    uint32_T position0p1mm;
    uint8_T frontDsSegs;
    uint8_T rearDsSegs;

    /* Bit7 */
    bool_t FloorFirstReserved1;

    /* Bit3 */
    bool_t FloorFirstReserved2;
}

NvmFloorConfiguration_B;

#endif                               /* RTW_HEADER_NvmFloorConfiguration_B_h_ */

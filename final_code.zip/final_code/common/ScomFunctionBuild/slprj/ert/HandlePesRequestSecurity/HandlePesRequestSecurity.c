/*
 * ---------------------------------------------------------------------------
 * Copyright (c) 2015 UTC - All rights reserved.
 *
 * Model Name:         HandlePesRequestSecurity
 * Code Generation:     -
 * Svn:
 * ---------------------------------------------------------------------------
 */

#include "HandlePesRequestSecurity.h"

/* user code (top of source file) */

/* *****************************************************************************/
/* **                _______   _________  _________   _______                 **/
/* **               (  ___  )  \__   __/  \__   __/  (  ____ \                **/
/* **               | (   ) |     ) (        ) (     | (    \/                **/
/* **               | |   | |     | |        | |     | (_____                 **/
/* **               | |   | |     | |        | |     (_____  )                **/
/* **               | |   | |     | |        | |           ) |                **/
/* **               | (___) |     | |     ___) (___  /\____) |                **/
/* **               (_______)     )_(     \_______/  \_______)                **/
/* **                                                                         **/
/* **                      OTIS Lead Design Center Berlin                     **/
/* **                                                                         **/
/* **   Copyright 2020 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **/
/* **                                                                         **/
/* *****************************************************************************/
/* **                                                                         **/
/* ** Simulink Model                                                          **/
/* **                                                                         **/
/* ** Purpose                                                                 **/
/* **  Model of Functional Safety Logic of the Pessral System                 **/
/* **                                                                         **/
/* ** Functionality                                                           **/
/* **  This is one of the source files auto-generated from the Simulink Model **/
/* **  with the help of the Simulink Embedded Coder.                          **/
/* **                                                                         **/
/* **                    DO NOT MANUALLY CHANGE THIS FILE                     **/
/* **                    ================================                     **/
/* **                                                                         **/
/* *****************************************************************************/

/* Invariant block signals (default storage) */
const ConstB_HandlePesRequestSecurity_hb4t_T HandlePesRequestSecurity_ConstB =
{
    2U,                                /* '<Root>/uint8_boolean' */
    1U,                                /* '<Root>/uint8_boolean1' */
    3U,                                /* '<Root>/uint8_boolean2' */
    5U                                 /* '<Root>/uint8_boolean3' */
};

/* Output and update for referenced model: 'HandlePesRequestSecurity' */
void HandlePesRequestSecurity(bool_t rtu_IsNewRequestSecurity, uint16_T
    rtu_Parameter, SecurityRequestCryptoChipConfigure_B
    *rty_SecurityRequestCryptoChipConfigure,
    SecurityRequestCryptoChipCreateKey_B *rty_SecurityRequestCryptoChipCreateKey,
    SecurityRequestCryptoChipLockConfig_B
    *rty_SecurityRequestCryptoChipLockConfig, SecurityRequestOtpActivate_B
    *rty_SecurityRequestOtpActivate)
{
    /* Logic: '<Root>/Logical Operator1' incorporates:
     *  RelationalOperator: '<Root>/Relational Operator3'
     */
    rty_SecurityRequestCryptoChipConfigure->Send =
        ((HandlePesRequestSecurity_ConstB.uint8_boolean1 == rtu_Parameter) &&
         rtu_IsNewRequestSecurity);

    /* Logic: '<Root>/Logical Operator2' incorporates:
     *  RelationalOperator: '<Root>/Relational Operator1'
     */
    rty_SecurityRequestCryptoChipCreateKey->Send =
        ((HandlePesRequestSecurity_ConstB.uint8_boolean == rtu_Parameter) &&
         rtu_IsNewRequestSecurity);

    /* Logic: '<Root>/Logical Operator3' incorporates:
     *  RelationalOperator: '<Root>/Relational Operator2'
     */
    rty_SecurityRequestCryptoChipLockConfig->Send =
        ((HandlePesRequestSecurity_ConstB.uint8_boolean2 == rtu_Parameter) &&
         rtu_IsNewRequestSecurity);

    /* Logic: '<Root>/Logical Operator4' incorporates:
     *  RelationalOperator: '<Root>/Relational Operator4'
     */
    rty_SecurityRequestOtpActivate->Send =
        ((HandlePesRequestSecurity_ConstB.uint8_boolean3 == rtu_Parameter) &&
         rtu_IsNewRequestSecurity);
}

function TraceInfoFlag() {
    this.traceFlag = new Array();
    this.traceFlag["HandlePesRequestSecurity.c:67c58"]=1;
    this.traceFlag["HandlePesRequestSecurity.c:67c76"]=1;
    this.traceFlag["HandlePesRequestSecurity.c:74c57"]=1;
    this.traceFlag["HandlePesRequestSecurity.c:74c75"]=1;
    this.traceFlag["HandlePesRequestSecurity.c:81c58"]=1;
    this.traceFlag["HandlePesRequestSecurity.c:81c76"]=1;
    this.traceFlag["HandlePesRequestSecurity.c:88c58"]=1;
    this.traceFlag["HandlePesRequestSecurity.c:88c76"]=1;
}
top.TraceInfoFlag.instance = new TraceInfoFlag();
function TraceInfoLineFlag() {
    this.lineTraceFlag = new Array();
    this.lineTraceFlag["HandlePesRequestSecurity.c:66"]=1;
    this.lineTraceFlag["HandlePesRequestSecurity.c:67"]=1;
    this.lineTraceFlag["HandlePesRequestSecurity.c:68"]=1;
    this.lineTraceFlag["HandlePesRequestSecurity.c:73"]=1;
    this.lineTraceFlag["HandlePesRequestSecurity.c:74"]=1;
    this.lineTraceFlag["HandlePesRequestSecurity.c:75"]=1;
    this.lineTraceFlag["HandlePesRequestSecurity.c:80"]=1;
    this.lineTraceFlag["HandlePesRequestSecurity.c:81"]=1;
    this.lineTraceFlag["HandlePesRequestSecurity.c:82"]=1;
    this.lineTraceFlag["HandlePesRequestSecurity.c:87"]=1;
    this.lineTraceFlag["HandlePesRequestSecurity.c:88"]=1;
    this.lineTraceFlag["HandlePesRequestSecurity.c:89"]=1;
    this.lineTraceFlag["HandlePesRequestSecurity.h:112"]=1;
    this.lineTraceFlag["HandlePesRequestSecurity.h:113"]=1;
    this.lineTraceFlag["HandlePesRequestSecurity.h:114"]=1;
    this.lineTraceFlag["HandlePesRequestSecurity.h:115"]=1;
}
top.TraceInfoLineFlag.instance = new TraceInfoLineFlag();

/*
 * ---------------------------------------------------------------------------
 * Copyright (c) 2015 UTC - All rights reserved.
 *
 * Model Name:         ScomFunction
 * Code Generation:    wroblema - Wed Jun 22 13:12:32 2022
 * Svn:
 * ---------------------------------------------------------------------------
 */

#ifndef RTW_HEADER_ScomFunction_h_
#define RTW_HEADER_ScomFunction_h_
#include "rtwtypes.h"
#include "OpbNodeAddr.h"
#include "Event/SafetyNode.h"
#include "Timebase_t.h"
#include "NvmGlobal_B.h"
#ifndef ScomFunction_COMMON_INCLUDES_
# define ScomFunction_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "zero_crossing_types.h"
#include "Hlp/Crc32.h"
#endif                                 /* ScomFunction_COMMON_INCLUDES_ */

/* Child system includes */
#include "HandlePesRequest.h"

/* Macros for accessing real-time model data structure */

/* user code (top of header file) */

/* *****************************************************************************/
/* **                _______   _________  _________   _______                 **/
/* **               (  ___  )  \__   __/  \__   __/  (  ____ \                **/
/* **               | (   ) |     ) (        ) (     | (    \/                **/
/* **               | |   | |     | |        | |     | (_____                 **/
/* **               | |   | |     | |        | |     (_____  )                **/
/* **               | |   | |     | |        | |           ) |                **/
/* **               | (___) |     | |     ___) (___  /\____) |                **/
/* **               (_______)     )_(     \_______/  \_______)                **/
/* **                                                                         **/
/* **                      OTIS Lead Design Center Berlin                     **/
/* **                                                                         **/
/* **   Copyright 2020 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **/
/* **                                                                         **/
/* *****************************************************************************/
/* **                                                                         **/
/* ** Simulink Model                                                          **/
/* **                                                                         **/
/* ** Purpose                                                                 **/
/* **  Model of Functional Safety Logic of the Pessral System                 **/
/* **                                                                         **/
/* ** Functionality                                                           **/
/* **  This is one of the source files auto-generated from the Simulink Model **/
/* **  with the help of the Simulink Embedded Coder.                          **/
/* **                                                                         **/
/* **                    DO NOT MANUALLY CHANGE THIS FILE                     **/
/* **                    ================================                     **/
/* **                                                                         **/
/* *****************************************************************************/
#ifndef DEFINED_TYPEDEF_FOR_PesRequest_Request_E_
#define DEFINED_TYPEDEF_FOR_PesRequest_Request_E_

typedef enum
{
    PesRequest_Request_E_ApplicationScn = 0,
    PesRequest_Request_E_ProcTiming = 2,
    PesRequest_Request_E_DsSegmentTable = 4,/* Default value */
    PesRequest_Request_E_CarVelocity = 5,
    PesRequest_Request_E_FloorStatus = 6,
    PesRequest_Request_E_PesConfig = 7,
    PesRequest_Request_E_ContractCertificate = 8,
    PesRequest_Request_E_StartupPhase = 9,
    PesRequest_Request_E_NormalPhase = 10,
    PesRequest_Request_E_OverspeedThreshold = 11,
    PesRequest_Request_E_InjectFccuFault = 12,
    PesRequest_Request_E_ProductionDate = 13,
    PesRequest_Request_E_InjectHwError = 14,
    PesRequest_Request_E_SupportedFeatures = 15,
    PesRequest_Request_E_Data = 16,
    PesRequest_Request_E_Security = 17,
    PesRequest_Request_E_SetData = 19
}
PesRequest_Request_E;

#endif

#ifndef DEFINED_TYPEDEF_FOR_PesRequestNew_C_
#define DEFINED_TYPEDEF_FOR_PesRequestNew_C_

/* Non-safety CAN message PesRequest. */
typedef struct
{
    /* OPB node address of the requester */
    OpbNodeAddr_E RequesterNodeAddr;

    /* Requestee:
       0 = SCON
       1 = SCAR
       2 = SPIT
       3 = SAB
       4..254 = Spare
       255 = All safety nodes that are present */
    SafetyNode_E Requestee;

    /* 0  = SCN (sofware version)
       1  = active events
       2  = ProcTiming
       3  = Update factory configuration
       4  = Ds segment table
       5  = car velocity
       6  = floor status
       7  = configuration
       8  = contract certificate
       9  = startup phase request
       10 = normal phase request
       11 = overspeed threshold
       12 = inject FCCU fault
       13 = produciton date
       14 = inject HWC error
       15 = SupportedFeatures
       16 = Data
       17 = Security */
    PesRequest_Request_E Request;

    /* The parameters depend on the request type (see PESSRAL-ESA to OCSS-Drive ICD). */
    uint16_T Parameter;

    /* Timestamp when the message was received by receiver. */
    Timebase_t ReceptionTimeStamp;
}
PesRequestNew_C;

#endif

#ifndef DEFINED_TYPEDEF_FOR_PesDataReceived_C_
#define DEFINED_TYPEDEF_FOR_PesDataReceived_C_

typedef struct
{
    /* Timestamp when the message was received by receiver. */
    Timebase_t ReceptionTimeStamp;

    /* The PesData contains a payload of 6 * Bytes, with a fixed length. */
    uint8_T Data[6];
}
PesDataReceived_C;

#endif

#ifndef DEFINED_TYPEDEF_FOR_ScomCanInputs_B_
#define DEFINED_TYPEDEF_FOR_ScomCanInputs_B_

typedef struct
{
    PesRequestNew_C PesRequest;
    PesDataReceived_C PesDataFromConfigurationMaster;
}
ScomCanInputs_B;

#endif

#ifndef DEFINED_TYPEDEF_FOR_PcbManufacturingDate_B_
#define DEFINED_TYPEDEF_FOR_PcbManufacturingDate_B_

typedef struct
{
    uint8_T raw[6];
}
PcbManufacturingDate_B;

#endif

#ifndef DEFINED_TYPEDEF_FOR_PcbInfo_B_
#define DEFINED_TYPEDEF_FOR_PcbInfo_B_

typedef struct
{
    uint8_T SystemManufacturer[36];
    uint8_T PcbPartNumber[18];
    uint8_T ExaminationCertificate[36];
    uint8_T SafetySystemType[36];
    uint8_T PcbManufacturer[36];
    uint8_T MissionTime[6];
    PcbManufacturingDate_B PcbManufacturingDate;

    /* Determines, if PcbManufacturingDate is has a valid value. */
    bool_t PcbManufacturingDateIsValid;
}
PcbInfo_B;

#endif

#ifndef DEFINED_TYPEDEF_FOR_OtpWritePcbManufacturingDateReply_B_
#define DEFINED_TYPEDEF_FOR_OtpWritePcbManufacturingDateReply_B_

typedef struct
{
    /* Timestamp of the time when the message was received. */
    Timebase_t ReceptionTimeStamp;
    bool_t Result;
}
OtpWritePcbManufacturingDateReply_B;

#endif

#ifndef DEFINED_TYPEDEF_FOR_ScomMsgInputs_B_
#define DEFINED_TYPEDEF_FOR_ScomMsgInputs_B_

typedef struct
{
    OtpWritePcbManufacturingDateReply_B OtpWritePcbManufacturingDateReply;
}
ScomMsgInputs_B;

#endif

#ifndef DEFINED_TYPEDEF_FOR_PesDataSetPcbManufacturingDateReceived_B_
#define DEFINED_TYPEDEF_FOR_PesDataSetPcbManufacturingDateReceived_B_

typedef struct
{
    PcbManufacturingDate_B SetPcbManufacturingDate;
    Timebase_t Timestamp;
}
PesDataSetPcbManufacturingDateReceived_B;

#endif

#ifndef DEFINED_TYPEDEF_FOR_ScomHandledCanMessages_B_
#define DEFINED_TYPEDEF_FOR_ScomHandledCanMessages_B_

typedef struct
{
    PesRequestNew_C PesRequest;
    PesDataSetPcbManufacturingDateReceived_B
        SetPcbManufacturingDateFromConfigurationMaster;
}
ScomHandledCanMessages_B;

#endif

#ifndef DEFINED_TYPEDEF_FOR_PesData_C_
#define DEFINED_TYPEDEF_FOR_PesData_C_

typedef struct
{
    OpbNodeAddr_E RequesterNodeAddr;

    /* The PesData contains a payload of 6 * Bytes, with a fixed length. */
    uint8_T Data[6];

    /* This boolean indicates for sending logic that this message shall be send. */
    bool_t Send;
}
PesData_C;

#endif

#ifndef DEFINED_TYPEDEF_FOR_ScomCanOutputs_B_
#define DEFINED_TYPEDEF_FOR_ScomCanOutputs_B_

typedef struct
{
    PesData_C PesData;
}
ScomCanOutputs_B;

#endif

#ifndef DEFINED_TYPEDEF_FOR_ScomHandleCanMessagesCommand_B_
#define DEFINED_TYPEDEF_FOR_ScomHandleCanMessagesCommand_B_

typedef struct
{
    bool_t waitForPesDataSetPcbManufacturingDateFromConfigurationMaster;
}
ScomHandleCanMessagesCommand_B;

#endif

#ifndef DEFINED_TYPEDEF_FOR_SecurityRequestCryptoChipConfigure_B_
#define DEFINED_TYPEDEF_FOR_SecurityRequestCryptoChipConfigure_B_

typedef struct
{
    bool_t Send;
}
SecurityRequestCryptoChipConfigure_B;

#endif

#ifndef DEFINED_TYPEDEF_FOR_SecurityRequestCryptoChipCreateKey_B_
#define DEFINED_TYPEDEF_FOR_SecurityRequestCryptoChipCreateKey_B_

typedef struct
{
    bool_t Send;
}
SecurityRequestCryptoChipCreateKey_B;

#endif

#ifndef DEFINED_TYPEDEF_FOR_SecurityRequestCryptoChipLockConfig_B_
#define DEFINED_TYPEDEF_FOR_SecurityRequestCryptoChipLockConfig_B_

typedef struct
{
    bool_t Send;
}
SecurityRequestCryptoChipLockConfig_B;

#endif

#ifndef DEFINED_TYPEDEF_FOR_SecurityRequestOtpActivate_B_
#define DEFINED_TYPEDEF_FOR_SecurityRequestOtpActivate_B_

typedef struct
{
    bool_t Send;
}
SecurityRequestOtpActivate_B;

#endif

#ifndef DEFINED_TYPEDEF_FOR_OtpWritePcbManufacturingDate_B_
#define DEFINED_TYPEDEF_FOR_OtpWritePcbManufacturingDate_B_

typedef struct
{
    uint8_T Day;
    uint8_T Month;
    uint16_T Year;
    bool_t Send;
}
OtpWritePcbManufacturingDate_B;

#endif

#ifndef DEFINED_TYPEDEF_FOR_ScomMsgOutputs_B_
#define DEFINED_TYPEDEF_FOR_ScomMsgOutputs_B_

typedef struct
{
    SecurityRequestCryptoChipConfigure_B SecurityRequestCryptoChipConfigure;
    SecurityRequestCryptoChipCreateKey_B SecurityRequestCryptoChipCreateKey;
    SecurityRequestCryptoChipLockConfig_B SecurityRequestCryptoChipLockConfig;
    SecurityRequestOtpActivate_B SecurityRequestOtpActivate;
    OtpWritePcbManufacturingDate_B OtpWritePcbManufacturingDate;
}
ScomMsgOutputs_B;

#endif

#ifndef DEFINED_TYPEDEF_FOR_PesDataId_E_
#define DEFINED_TYPEDEF_FOR_PesDataId_E_

typedef uint16_T PesDataId_E;

/* enum PesDataId_E */
#define PesDataId_None                 ((PesDataId_E)0U)
#define PesDataId_SYSTEM_MANUFACTURER  ((PesDataId_E)1U)         /* Default value */
#define PesDataId_SAFETY_SYSTEM_TYPE   ((PesDataId_E)2U)
#define PesDataId_EXAMINATION_CERTIFICATE ((PesDataId_E)3U)
#define PesDataId_PCB_PART_NUMBER      ((PesDataId_E)4U)
#define PesDataId_PCB_MANUFACTURER     ((PesDataId_E)5U)
#define PesDataId_MISSION_TIME         ((PesDataId_E)6U)
#define PesDataId_PCB_MANUFACTURING_DATE ((PesDataId_E)7U)
#define PesDataId_CONTRACT_CERTIFICATE ((PesDataId_E)8U)
#define PesDataId_TRIP_SPEED_THRESHOLD ((PesDataId_E)9U)
#define PesDataId_PIT_PROTECTION_LIMIT ((PesDataId_E)10U)
#define PesDataId_VALIDITY_STATUS      ((PesDataId_E)11U)
#define PesDataId_HOISTWAY_LEARN_STATUS ((PesDataId_E)12U)
#define PesDataId_OVERSPEED_THRESHOLD  ((PesDataId_E)13U)
#define PesDataId_ETS_STOP_DIST_DN     ((PesDataId_E)14U)
#define PesDataId_ETS_STOP_DIST_UP     ((PesDataId_E)15U)
#define PesDataId_ETS_ACTIVATION_POS_DN ((PesDataId_E)16U)
#define PesDataId_ETS_ACTIVATION_POS_UP ((PesDataId_E)17U)
#define PesDataId_OS_STOP_DIST_UP      ((PesDataId_E)18U)
#define PesDataId_CRYPTOCHIP_CONFIGURE ((PesDataId_E)257U)
#define PesDataId_CRYPTOCHIP_GENKEY    ((PesDataId_E)258U)
#define PesDataId_CRYPTOCHIP_LOCK_CONFIG ((PesDataId_E)259U)
#define PesDataId_CRYPTOCHIP_LOCK_FINAL ((PesDataId_E)260U)
#define PesDataId_OTP_ACTIVATE         ((PesDataId_E)261U)
#define PesDataId_SET_PCB_MANUFACTURING_DATE_STATUS ((PesDataId_E)519U)
#endif

/* Block states (default storage) for system '<S4>/Chart' */
typedef struct
{
    struct
    {
        uint_T is_c3_ScomFunction:2;   /* '<S4>/Chart' */
        uint_T is_Receiving:2;         /* '<S4>/Chart' */
        uint_T is_active_c3_ScomFunction:1;/* '<S4>/Chart' */
    }
    bitsForTID0;
}
DW_Chart_ScomFunction_T;

/* Block states (default storage) for system '<S4>/CheckPcbManufacturingDate' */
typedef struct
{
    PesDataSetPcbManufacturingDateReceived_B UnitDelay_DSTATE;/* '<S7>/Unit Delay' */
}
DW_CheckPcbManufacturingDate_ScomFunction_T;

/* Zero-crossing (trigger) state for system '<S4>/CheckPcbManufacturingDate' */
typedef struct
{
    ZCSigState CheckPcbManufacturingDate_Trig_ZCE;/* '<S4>/CheckPcbManufacturingDate' */
}
ZCE_CheckPcbManufacturingDate_ScomFunction_T;

/* Block signals for system '<S3>/ScomHandlePesData' */
typedef struct
{
    PesDataReceived_C BufferedHeader;  /* '<S4>/Switch' */
    Timebase_t RequestTime;            /* '<S4>/Switch2' */
    bool_t SignalConversion;           /* '<S8>/Signal Conversion' */
    bool_t BufferData1;                /* '<S4>/Chart' */
    bool_t BufferData2;                /* '<S4>/Chart' */
}
B_ScomHandlePesData_ScomFunction_T;

/* Block states (default storage) for system '<S3>/ScomHandlePesData' */
typedef struct
{
    PesDataReceived_C UnitDelay1_DSTATE;/* '<S4>/Unit Delay1' */
    Timebase_t UnitDelay_DSTATE;       /* '<S4>/Unit Delay' */
    Timebase_t UnitDelay3_DSTATE;      /* '<S4>/Unit Delay3' */
    bool_t Delay_DSTATE;               /* '<S8>/Delay' */
    DW_CheckPcbManufacturingDate_ScomFunction_T CheckPcbManufacturingDate;/* '<S4>/CheckPcbManufacturingDate' */
    DW_Chart_ScomFunction_T sf_Chart;  /* '<S4>/Chart' */
}
DW_ScomHandlePesData_ScomFunction_T;

/* Zero-crossing (trigger) state for system '<S3>/ScomHandlePesData' */
typedef struct
{
    ZCE_CheckPcbManufacturingDate_ScomFunction_T CheckPcbManufacturingDate;/* '<S4>/CheckPcbManufacturingDate' */
}
ZCE_ScomHandlePesData_ScomFunction_T;

/* Block signals (default storage) */
typedef struct
{
    ScomHandledCanMessages_B ScomHandledCanMessages;/* '<S3>/Bus Creator' */
    PesRequestNew_C PesRequestToEvaluate;/* '<S35>/Signal Conversion4' */
    PesDataSetPcbManufacturingDateReceived_B
        SetPcbManufacturingDateFromConfigurationMaster;/* '<S7>/Switch' */
    ScomHandleCanMessagesCommand_B ScomHandleCanMessagesCommandOld;/* '<Root>/Unit Delay' */
    ScomHandleCanMessagesCommand_B ScomHandleCanMessagesCommand;/* '<S1>/Bus Creator1' */
    OtpWritePcbManufacturingDate_B OtpWritePcbManufacturingDate;/* '<S1>/HandlePesRequestRef' */
    bool_t LogicalOperator1;           /* '<Root>/Logical Operator1' */
    bool_t waitForPesDataSetPcbManufacturingDateFromConfigurationMaster;/* '<S1>/HandlePesRequestRef' */
    B_ScomHandlePesData_ScomFunction_T ScomHandlePesData;/* '<S3>/ScomHandlePesData' */
}
B_ScomFunction_T;

/* Block states (default storage) for system '<Root>' */
typedef struct
{
    ScomHandleCanMessagesCommand_B UnitDelay_DSTATE;/* '<Root>/Unit Delay' */
    Timebase_t Delay_DSTATE;           /* '<S34>/Delay' */
    MdlrefDW_HandlePesRequest_T HandlePesRequestRef_InstanceData;/* '<S1>/HandlePesRequestRef' */
    DW_ScomHandlePesData_ScomFunction_T ScomHandlePesData;/* '<S3>/ScomHandlePesData' */
}
DW_ScomFunction_T;

/* Zero-crossing (trigger) state */
typedef struct
{
    ZCE_ScomHandlePesData_ScomFunction_T ScomHandlePesData;/* '<S3>/ScomHandlePesData' */
}
PrevZCX_ScomFunction_T;

/* Invariant block signals for system '<S7>/CheckTimeoutHeader' */
typedef struct
{
    const Timebase_t SignalConversion2;/* '<S19>/Signal Conversion2' */
    const uint32_T SignalConversion1;  /* '<S19>/Signal Conversion1' */
}
ConstB_CheckTimeoutHeader_ScomFunction_T;

/* Invariant block signals for system '<S7>/CheckTimeoutPayload' */
typedef struct
{
    const Timebase_t SignalConversion2;/* '<S21>/Signal Conversion2' */
    const uint32_T SignalConversion1;  /* '<S21>/Signal Conversion1' */
}
ConstB_CheckTimeoutPayload_ScomFunction_T;

/* Invariant block signals for system '<S7>/GetCrc' */
typedef struct
{
    const uint16_T Width;              /* '<S13>/Width' */
    const uint16_T Length;             /* '<S27>/Signal Conversion1' */
}
ConstB_GetCrc_ScomFunction_T;

/* Invariant block signals for system '<S4>/CheckPcbManufacturingDate' */
typedef struct
{
    ConstB_GetCrc_ScomFunction_T GetCrc;/* '<S7>/GetCrc' */
    ConstB_CheckTimeoutPayload_ScomFunction_T CheckTimeoutPayload;/* '<S7>/CheckTimeoutPayload' */
    ConstB_CheckTimeoutHeader_ScomFunction_T CheckTimeoutHeader;/* '<S7>/CheckTimeoutHeader' */
}
ConstB_CheckPcbManufacturingDate_ScomFunction_T;

/* Invariant block signals for system '<S3>/ScomHandlePesData' */
typedef struct
{
    ConstB_CheckPcbManufacturingDate_ScomFunction_T CheckPcbManufacturingDate;/* '<S4>/CheckPcbManufacturingDate' */
}
ConstB_ScomHandlePesData_ScomFunction_T;

/* Invariant block signals (default storage) */
typedef struct
{
    ConstB_ScomHandlePesData_ScomFunction_T ScomHandlePesData;/* '<S3>/ScomHandlePesData' */
}
ConstB_ScomFunction_T;

/* External inputs (root inport signals with default storage) */
typedef struct
{
    bool_t IsPeriodicCall;             /* '<Root>/IsPeriodicCall' */
    ScomCanInputs_B ScomCanInputs;     /* '<Root>/ScomCanInputs' */
    SafetyNode_E ScomHost;             /* '<Root>/ScomHost' */
    PcbInfo_B PcbInfo;                 /* '<Root>/PcbInfo' */
    NvmGlobal_B NvmGlobalIn;           /* '<Root>/NvmGlobalIn' */
    ScomMsgInputs_B ScomMsgInputs;     /* '<Root>/ScomMsgInputs' */
    Timebase_t Timebase;               /* '<Root>/Timebase' */
}
ExtU_ScomFunction_T;

/* External outputs (root outports fed by signals with default storage) */
typedef struct
{
    ScomMsgOutputs_B ScomMsgOutputs;   /* '<Root>/ScomMsgOutputs' */
    ScomCanOutputs_B ScomCanOutputs;   /* '<Root>/ScomCanOutputs' */
    NvmGlobal_B NvmGlobalOut;          /* '<Root>/NvmGlobalOut' */
}
ExtY_ScomFunction_T;

/* Block signals (default storage) */
extern B_ScomFunction_T ScomFunction_B;

/* Block states (default storage) */
extern DW_ScomFunction_T ScomFunction_DW;

/* External inputs (root inport signals with default storage) */
extern ExtU_ScomFunction_T ScomFunction_U;

/* External outputs (root outports fed by signals with default storage) */
extern ExtY_ScomFunction_T ScomFunction_Y;

/* External data declarations for dependent source files */
extern const PesRequestNew_C ScomFunction_rtZPesRequestNew_C;/* PesRequestNew_C ground */
extern const ScomCanInputs_B ScomFunction_rtZScomCanInputs_B;/* ScomCanInputs_B ground */
extern const ScomHandledCanMessages_B ScomFunction_rtZScomHandledCanMessages_B;/* ScomHandledCanMessages_B ground */
extern const ScomCanOutputs_B ScomFunction_rtZScomCanOutputs_B;/* ScomCanOutputs_B ground */
extern const ConstB_ScomFunction_T ScomFunction_ConstB;/* constant block i/o */

/* Model entry point functions */
extern void ScomFunction_initialize(void);
extern void ScomFunction_output(void);
extern void ScomFunction_update(void);

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'ScomFunction'
 * '<S1>'   : 'ScomFunction/ScomEvaluation'
 * '<S2>'   : 'ScomFunction/ScomFunctionModelInfo'
 * '<S3>'   : 'ScomFunction/ScomHandleMessage'
 * '<S4>'   : 'ScomFunction/ScomHandleMessage/ScomHandlePesData'
 * '<S5>'   : 'ScomFunction/ScomHandleMessage/ScomHandlePesRequest'
 * '<S6>'   : 'ScomFunction/ScomHandleMessage/ScomHandlePesData/Chart'
 * '<S7>'   : 'ScomFunction/ScomHandleMessage/ScomHandlePesData/CheckPcbManufacturingDate'
 * '<S8>'   : 'ScomFunction/ScomHandleMessage/ScomHandlePesData/RisingEdge'
 * '<S9>'   : 'ScomFunction/ScomHandleMessage/ScomHandlePesData/CheckPcbManufacturingDate/CheckPaddingBytes'
 * '<S10>'  : 'ScomFunction/ScomHandleMessage/ScomHandlePesData/CheckPcbManufacturingDate/CheckPesDataId'
 * '<S11>'  : 'ScomFunction/ScomHandleMessage/ScomHandlePesData/CheckPcbManufacturingDate/CheckTimeoutHeader'
 * '<S12>'  : 'ScomFunction/ScomHandleMessage/ScomHandlePesData/CheckPcbManufacturingDate/CheckTimeoutPayload'
 * '<S13>'  : 'ScomFunction/ScomHandleMessage/ScomHandlePesData/CheckPcbManufacturingDate/GetCrc'
 * '<S14>'  : 'ScomFunction/ScomHandleMessage/ScomHandlePesData/CheckPcbManufacturingDate/CheckPesDataId/Bit Shift'
 * '<S15>'  : 'ScomFunction/ScomHandleMessage/ScomHandlePesData/CheckPcbManufacturingDate/CheckPesDataId/Bit Shift1'
 * '<S16>'  : 'ScomFunction/ScomHandleMessage/ScomHandlePesData/CheckPcbManufacturingDate/CheckPesDataId/Enumerated Constant'
 * '<S17>'  : 'ScomFunction/ScomHandleMessage/ScomHandlePesData/CheckPcbManufacturingDate/CheckPesDataId/Bit Shift/bit_shift'
 * '<S18>'  : 'ScomFunction/ScomHandleMessage/ScomHandlePesData/CheckPcbManufacturingDate/CheckPesDataId/Bit Shift1/bit_shift'
 * '<S19>'  : 'ScomFunction/ScomHandleMessage/ScomHandlePesData/CheckPcbManufacturingDate/CheckTimeoutHeader/MsToTimebase'
 * '<S20>'  : 'ScomFunction/ScomHandleMessage/ScomHandlePesData/CheckPcbManufacturingDate/CheckTimeoutHeader/MsToTimebase/MsToTimebase'
 * '<S21>'  : 'ScomFunction/ScomHandleMessage/ScomHandlePesData/CheckPcbManufacturingDate/CheckTimeoutPayload/MsToTimebase1'
 * '<S22>'  : 'ScomFunction/ScomHandleMessage/ScomHandlePesData/CheckPcbManufacturingDate/CheckTimeoutPayload/MsToTimebase1/MsToTimebase'
 * '<S23>'  : 'ScomFunction/ScomHandleMessage/ScomHandlePesData/CheckPcbManufacturingDate/GetCrc/Bit Shift'
 * '<S24>'  : 'ScomFunction/ScomHandleMessage/ScomHandlePesData/CheckPcbManufacturingDate/GetCrc/Bit Shift1'
 * '<S25>'  : 'ScomFunction/ScomHandleMessage/ScomHandlePesData/CheckPcbManufacturingDate/GetCrc/Bit Shift2'
 * '<S26>'  : 'ScomFunction/ScomHandleMessage/ScomHandlePesData/CheckPcbManufacturingDate/GetCrc/Bit Shift3'
 * '<S27>'  : 'ScomFunction/ScomHandleMessage/ScomHandlePesData/CheckPcbManufacturingDate/GetCrc/CalculateCrc32'
 * '<S28>'  : 'ScomFunction/ScomHandleMessage/ScomHandlePesData/CheckPcbManufacturingDate/GetCrc/Bit Shift/bit_shift'
 * '<S29>'  : 'ScomFunction/ScomHandleMessage/ScomHandlePesData/CheckPcbManufacturingDate/GetCrc/Bit Shift1/bit_shift'
 * '<S30>'  : 'ScomFunction/ScomHandleMessage/ScomHandlePesData/CheckPcbManufacturingDate/GetCrc/Bit Shift2/bit_shift'
 * '<S31>'  : 'ScomFunction/ScomHandleMessage/ScomHandlePesData/CheckPcbManufacturingDate/GetCrc/Bit Shift3/bit_shift'
 * '<S32>'  : 'ScomFunction/ScomHandleMessage/ScomHandlePesData/CheckPcbManufacturingDate/GetCrc/CalculateCrc32/MatlabFunctionCall'
 * '<S33>'  : 'ScomFunction/ScomHandleMessage/ScomHandlePesData/RisingEdge/Compare To Constant'
 * '<S34>'  : 'ScomFunction/ScomHandleMessage/ScomHandlePesRequest/AnyChange'
 * '<S35>'  : 'ScomFunction/ScomHandleMessage/ScomHandlePesRequest/LatchPesRequest'
 */

/*-
 * Requirements for '<Root>': ScomFunction
 */
#endif                                 /* RTW_HEADER_ScomFunction_h_ */

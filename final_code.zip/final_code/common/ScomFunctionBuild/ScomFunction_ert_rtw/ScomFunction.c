/*
 * ---------------------------------------------------------------------------
 * Copyright (c) 2015 UTC - All rights reserved.
 *
 * Model Name:         ScomFunction
 * Code Generation:    wroblema - Wed Jun 22 13:12:32 2022
 * Svn:
 * ---------------------------------------------------------------------------
 */

#include "ScomFunction.h"

/* Named constants for Chart: '<S4>/Chart' */
#define ScomFunction_IN_Idle           ((uint8_T)1U)
#define ScomFunction_IN_NO_ACTIVE_CHILD ((uint8_T)0U)
#define ScomFunction_IN_ReceivedContent ((uint8_T)1U)
#define ScomFunction_IN_Receiving      ((uint8_T)2U)
#define ScomFunction_IN_WaitingForContent ((uint8_T)2U)
#define ScomFunction_IN_WaitingForHeader ((uint8_T)3U)

/* user code (top of source file) */

/* *****************************************************************************/
/* **                _______   _________  _________   _______                 **/
/* **               (  ___  )  \__   __/  \__   __/  (  ____ \                **/
/* **               | (   ) |     ) (        ) (     | (    \/                **/
/* **               | |   | |     | |        | |     | (_____                 **/
/* **               | |   | |     | |        | |     (_____  )                **/
/* **               | |   | |     | |        | |           ) |                **/
/* **               | (___) |     | |     ___) (___  /\____) |                **/
/* **               (_______)     )_(     \_______/  \_______)                **/
/* **                                                                         **/
/* **                      OTIS Lead Design Center Berlin                     **/
/* **                                                                         **/
/* **   Copyright 2020 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **/
/* **                                                                         **/
/* *****************************************************************************/
/* **                                                                         **/
/* ** Simulink Model                                                          **/
/* **                                                                         **/
/* ** Purpose                                                                 **/
/* **  Model of Functional Safety Logic of the Pessral System                 **/
/* **                                                                         **/
/* ** Functionality                                                           **/
/* **  This is one of the source files auto-generated from the Simulink Model **/
/* **  with the help of the Simulink Embedded Coder.                          **/
/* **                                                                         **/
/* **                    DO NOT MANUALLY CHANGE THIS FILE                     **/
/* **                    ================================                     **/
/* **                                                                         **/
/* *****************************************************************************/
const PesRequestNew_C ScomFunction_rtZPesRequestNew_C =
{
    OpbNodeAddr_GECB,                  /* RequesterNodeAddr */
    SafetyNode_SCON,                   /* Requestee */
    PesRequest_Request_E_DsSegmentTable,/* Request */
    0U,                                /* Parameter */
    0U                                 /* ReceptionTimeStamp */
} ;                                    /* PesRequestNew_C ground */

const ScomHandledCanMessages_B ScomFunction_rtZScomHandledCanMessages_B =
{
    {
        OpbNodeAddr_GECB,              /* RequesterNodeAddr */
        SafetyNode_SCON,               /* Requestee */
        PesRequest_Request_E_DsSegmentTable,/* Request */
        0U,                            /* Parameter */
        0U                             /* ReceptionTimeStamp */
    },                                 /* PesRequest */

    {
        {
            {
                0U, 0U, 0U, 0U, 0U, 0U
            }
            /* raw */
        },                             /* SetPcbManufacturingDate */
        0U                             /* Timestamp */
    }                       /* SetPcbManufacturingDateFromConfigurationMaster */
} ;                                    /* ScomHandledCanMessages_B ground */

const ScomCanOutputs_B ScomFunction_rtZScomCanOutputs_B =
{
    {
        OpbNodeAddr_GECB,              /* RequesterNodeAddr */

        {
            0U, 0U, 0U, 0U, 0U, 0U
        }
        ,                              /* Data */
        false                          /* Send */
    }                                  /* PesData */
} ;                                    /* ScomCanOutputs_B ground */

/* Invariant block signals (default storage) */
const ConstB_ScomFunction_T ScomFunction_ConstB =
{
    /* Start of '<S3>/ScomHandlePesData' */
    {
        /* Start of '<S4>/CheckPcbManufacturingDate' */
        {
            /* Start of '<S7>/GetCrc' */
            {
                6U,                    /* '<S13>/Width' */
                6U                     /* '<S27>/Signal Conversion1' */
            }
            ,

            /* End of '<S7>/GetCrc' */

            /* Start of '<S7>/CheckTimeoutPayload' */
            {
                50U,                   /* '<S21>/Signal Conversion2' */
                100U                   /* '<S21>/Signal Conversion1' */
            }
            ,

            /* End of '<S7>/CheckTimeoutPayload' */

            /* Start of '<S7>/CheckTimeoutHeader' */
            {
                50U,                   /* '<S19>/Signal Conversion2' */
                1000U                  /* '<S19>/Signal Conversion1' */
            }
            /* End of '<S7>/CheckTimeoutHeader' */
        }
        /* End of '<S4>/CheckPcbManufacturingDate' */
    }
    /* End of '<S3>/ScomHandlePesData' */
};

/* Block signals (default storage) */
B_ScomFunction_T ScomFunction_B;

/* Block states (default storage) */
DW_ScomFunction_T ScomFunction_DW;

/* Previous zero-crossings (trigger) states */
PrevZCX_ScomFunction_T ScomFunction_PrevZCX;

/* External inputs (root inport signals with default storage) */
ExtU_ScomFunction_T ScomFunction_U;

/* External outputs (root outports fed by signals with default storage) */
ExtY_ScomFunction_T ScomFunction_Y;
static void ScomFunction_Chart(bool_t rtu_WaitForMessages, bool_t
    rtu_ReceivedPesData, bool_t *rty_BufferData1, bool_t *rty_BufferData2,
    DW_Chart_ScomFunction_T *localDW);
static void ScomFunction_CheckPaddingBytes(const uint8_T rtu_PayloadData[6],
    bool_t *rty_PaddingBytesOkay);
static void ScomFunction_CheckPesDataId(const uint8_T rtu_HeaderData[6], bool_t *
    rty_PesDataIdCorrect);
static void ScomFunction_MsToTimebase(Timebase_t rtu_base, uint32_T *rty_ms);
static void ScomFunction_CheckTimeoutHeader(Timebase_t rtu_RequestTime,
    Timebase_t rtu_ReceptionTimeStamp, bool_t *rty_HeaderWithinTimeout, const
    ConstB_CheckTimeoutHeader_ScomFunction_T *localC);
static void ScomFunction_CheckTimeoutPayload(Timebase_t
    rtu_PreviousMessageTimestamp, Timebase_t rtu_NextMessagetimeStamp, bool_t
    *rty_PayloadWithinTimeout, const ConstB_CheckTimeoutPayload_ScomFunction_T
    *localC);
static void ScomFunction_GetCrc(const uint8_T rtu_HeaderData[6], const uint8_T
    rtu_PayloadData[6], bool_t *rty_CrcMatches, const
    ConstB_GetCrc_ScomFunction_T *localC);
static void ScomFunction_CheckPcbManufacturingDate(bool_t rtu_Trigger,
    Timebase_t rtu_RequestTime, const PesDataReceived_C *rtu_PesData1, const
    PesDataReceived_C *rtu_PesData2, PesDataSetPcbManufacturingDateReceived_B
    *rty_SetPcbManufacturingDateFromConfigurationMaster, const
    ConstB_CheckPcbManufacturingDate_ScomFunction_T *localC,
    DW_CheckPcbManufacturingDate_ScomFunction_T *localDW,
    ZCE_CheckPcbManufacturingDate_ScomFunction_T *localZCE);
static void ScomFunction_ScomHandlePesData_Update(const PesDataReceived_C
    *rtu_PesDataFromConfigurationMaster, B_ScomHandlePesData_ScomFunction_T
    *localB, DW_ScomHandlePesData_ScomFunction_T *localDW);
static void ScomFunction_ScomHandlePesData(const PesDataReceived_C
    *rtu_PesDataFromConfigurationMaster, bool_t
    rtu_waitForPesDataSetPcbManufacturingDateFromConfigurationMaste, Timebase_t
    rtu_Timebase, PesDataSetPcbManufacturingDateReceived_B
    *rty_SetPcbManufacturingDateFromConfigurationMaster,
    B_ScomHandlePesData_ScomFunction_T *localB, const
    ConstB_ScomHandlePesData_ScomFunction_T *localC,
    DW_ScomHandlePesData_ScomFunction_T *localDW,
    ZCE_ScomHandlePesData_ScomFunction_T *localZCE);
static void ScomFunction_ScomEvaluation_Init(void);
static void ScomFunction_ScomEvaluation_Update(void);
static void ScomFunction_ScomEvaluation(void);
static void ScomFunction_ScomHandleMessage_Init(void);
static void ScomFunction_ScomHandleMessage_Update(void);
static void ScomFunction_ScomHandleMessage(void);
const ScomCanInputs_B ScomFunction_rtZScomCanInputs_B =
{
    {
        OpbNodeAddr_GECB,              /* RequesterNodeAddr */
        SafetyNode_SCON,               /* Requestee */
        PesRequest_Request_E_DsSegmentTable,/* Request */
        0U,                            /* Parameter */
        0U                             /* ReceptionTimeStamp */
    },                                 /* PesRequest */
    {
        0U,                            /* ReceptionTimeStamp */
        {
            0U, 0U, 0U, 0U, 0U, 0U
        }                              /* Data */
    }                                  /* PesDataFromConfigurationMaster */
};

/* System initialize for enable system: '<Root>/ScomEvaluation' */
static void ScomFunction_ScomEvaluation_Init(void)
{
    /* SystemInitialize for ModelReference: '<S1>/HandlePesRequestRef' incorporates:
     *  Inport: '<Root>/PcbInfo'
     *  Inport: '<Root>/ScomMsgInputs'
     *  Inport: '<Root>/Timebase'
     *
     * Block description for '<Root>/Timebase':
     *  Safety discrete inputs of the GECBP to be sampled by the SCON
     *  software, read in via a 2nd channel: Hardware shift register.
     */
    HandlePesRequest_Init
        (&ScomFunction_B.waitForPesDataSetPcbManufacturingDateFromConfigurationMaster,
         &(ScomFunction_DW.HandlePesRequestRef_InstanceData.rtb),
         &(ScomFunction_DW.HandlePesRequestRef_InstanceData.rtdw));

    /* SystemInitialize for BusCreator: '<S1>/Bus Creator1' */
    ScomFunction_B.ScomHandleCanMessagesCommand.waitForPesDataSetPcbManufacturingDateFromConfigurationMaster
        =
        ScomFunction_B.waitForPesDataSetPcbManufacturingDateFromConfigurationMaster;

    /* SystemInitialize for Outport: '<Root>/ScomCanOutputs' incorporates:
     *  Outport: '<S1>/ScomCanOutputs'
     */
    ScomFunction_Y.ScomCanOutputs = ScomFunction_rtZScomCanOutputs_B;
}

/* Outputs for enable system: '<Root>/ScomEvaluation' */
static void ScomFunction_ScomEvaluation(void)
{
    /* local block i/o variables */
    PesData_C rtb_PesData;
    SecurityRequestOtpActivate_B rtb_SecurityRequestOtpActivate;
    SecurityRequestCryptoChipLockConfig_B
        rtb_SecurityRequestCryptoChipLockConfig;
    SecurityRequestCryptoChipCreateKey_B rtb_SecurityRequestCryptoChipCreateKey;
    SecurityRequestCryptoChipConfigure_B rtb_SecurityRequestCryptoChipConfigure;

    /* Outputs for Enabled SubSystem: '<Root>/ScomEvaluation' incorporates:
     *  EnablePort: '<S1>/Enable'
     */
    /* Inport: '<Root>/IsPeriodicCall'
     *
     * Block description for '<Root>/IsPeriodicCall':
     *  Safety discrete inputs of the GECBP to be sampled by the SCON
     *  software, read in via a 2nd channel: Hardware shift register.
     */
    if (ScomFunction_U.IsPeriodicCall)
    {
        /* ModelReference: '<S1>/HandlePesRequestRef' incorporates:
         *  Inport: '<Root>/PcbInfo'
         *  Inport: '<Root>/ScomMsgInputs'
         *  Inport: '<Root>/Timebase'
         *
         * Block description for '<Root>/Timebase':
         *  Safety discrete inputs of the GECBP to be sampled by the SCON
         *  software, read in via a 2nd channel: Hardware shift register.
         */
        HandlePesRequest(&ScomFunction_B.ScomHandledCanMessages.PesRequest,
                         &ScomFunction_B.ScomHandledCanMessages.SetPcbManufacturingDateFromConfigurationMaster,
                         &ScomFunction_U.PcbInfo,
                         &ScomFunction_U.ScomMsgInputs.OtpWritePcbManufacturingDateReply,
                         ScomFunction_U.Timebase, &rtb_PesData,
                         &rtb_SecurityRequestCryptoChipConfigure,
                         &rtb_SecurityRequestCryptoChipCreateKey,
                         &rtb_SecurityRequestCryptoChipLockConfig,
                         &rtb_SecurityRequestOtpActivate,
                         &ScomFunction_B.OtpWritePcbManufacturingDate,
                         &ScomFunction_B.waitForPesDataSetPcbManufacturingDateFromConfigurationMaster,
                         &(ScomFunction_DW.HandlePesRequestRef_InstanceData.rtb),
                         &(ScomFunction_DW.HandlePesRequestRef_InstanceData.rtdw));

        /* BusCreator: '<S1>/Bus Creator' incorporates:
         *  Outport: '<Root>/ScomCanOutputs'
         */
        ScomFunction_Y.ScomCanOutputs.PesData = rtb_PesData;

        /* BusCreator: '<S1>/Bus Creator1' */
        ScomFunction_B.ScomHandleCanMessagesCommand.waitForPesDataSetPcbManufacturingDateFromConfigurationMaster
            =
            ScomFunction_B.waitForPesDataSetPcbManufacturingDateFromConfigurationMaster;

        /* BusCreator: '<S1>/Bus Creator2' incorporates:
         *  Outport: '<Root>/ScomMsgOutputs'
         */
        ScomFunction_Y.ScomMsgOutputs.SecurityRequestCryptoChipConfigure =
            rtb_SecurityRequestCryptoChipConfigure;
        ScomFunction_Y.ScomMsgOutputs.SecurityRequestCryptoChipCreateKey =
            rtb_SecurityRequestCryptoChipCreateKey;
        ScomFunction_Y.ScomMsgOutputs.SecurityRequestCryptoChipLockConfig =
            rtb_SecurityRequestCryptoChipLockConfig;
        ScomFunction_Y.ScomMsgOutputs.SecurityRequestOtpActivate =
            rtb_SecurityRequestOtpActivate;
        ScomFunction_Y.ScomMsgOutputs.OtpWritePcbManufacturingDate =
            ScomFunction_B.OtpWritePcbManufacturingDate;
    }

    /* End of Inport: '<Root>/IsPeriodicCall' */
    /* End of Outputs for SubSystem: '<Root>/ScomEvaluation' */
}

/* Update for enable system: '<Root>/ScomEvaluation' */
static void ScomFunction_ScomEvaluation_Update(void)
{
    /* Update for Enabled SubSystem: '<Root>/ScomEvaluation' incorporates:
     *  EnablePort: '<S1>/Enable'
     */
    /* Inport: '<Root>/IsPeriodicCall'
     *
     * Block description for '<Root>/IsPeriodicCall':
     *  Safety discrete inputs of the GECBP to be sampled by the SCON
     *  software, read in via a 2nd channel: Hardware shift register.
     */
    if (ScomFunction_U.IsPeriodicCall)
    {
        /* Update for ModelReference: '<S1>/HandlePesRequestRef' incorporates:
         *  Inport: '<Root>/PcbInfo'
         *  Inport: '<Root>/ScomMsgInputs'
         *  Inport: '<Root>/Timebase'
         *
         * Block description for '<Root>/Timebase':
         *  Safety discrete inputs of the GECBP to be sampled by the SCON
         *  software, read in via a 2nd channel: Hardware shift register.
         */
        HandlePesRequest_Update
            (&ScomFunction_B.ScomHandledCanMessages.PesRequest,
             &(ScomFunction_DW.HandlePesRequestRef_InstanceData.rtb),
             &(ScomFunction_DW.HandlePesRequestRef_InstanceData.rtdw));
    }

    /* End of Inport: '<Root>/IsPeriodicCall' */
    /* End of Update for SubSystem: '<Root>/ScomEvaluation' */
}

/* Output and update for atomic system: '<S4>/Chart' */
static void ScomFunction_Chart(bool_t rtu_WaitForMessages, bool_t
    rtu_ReceivedPesData, bool_t *rty_BufferData1, bool_t *rty_BufferData2,
    DW_Chart_ScomFunction_T *localDW)
{
    /* Chart: '<S4>/Chart' */
    /* Gateway: ScomHandleMessage/ScomHandlePesData/Chart */
    /* During: ScomHandleMessage/ScomHandlePesData/Chart */
    if (((uint32_T)localDW->bitsForTID0.is_active_c3_ScomFunction) == 0U)
    {
        /* Entry: ScomHandleMessage/ScomHandlePesData/Chart */
        localDW->bitsForTID0.is_active_c3_ScomFunction = 1U;

        /* Entry Internal: ScomHandleMessage/ScomHandlePesData/Chart */
        /* Transition: '<S6>:2' */
        /* Transition: '<S6>:23' */
        /* '<S6>:23:2' BufferData1 = false */
        *rty_BufferData1 = false;

        /* '<S6>:23:3' BufferData2 = false */
        *rty_BufferData2 = false;
        localDW->bitsForTID0.is_c3_ScomFunction = ScomFunction_IN_Idle;
    }
    else if (((uint32_T)localDW->bitsForTID0.is_c3_ScomFunction) ==
             ScomFunction_IN_Idle)
    {
        /* During 'Idle': '<S6>:1' */
        /* '<S6>:5:1' sf_internal_predicateOutput = WaitForMessages; */
        if (rtu_WaitForMessages)
        {
            /* Transition: '<S6>:5' */
            localDW->bitsForTID0.is_c3_ScomFunction = ScomFunction_IN_Receiving;

            /* Entry Internal 'Receiving': '<S6>:9' */
            /* Transition: '<S6>:10' */
            /* '<S6>:10:2' BufferData1 = false */
            *rty_BufferData1 = false;

            /* '<S6>:10:3' BufferData2 = false */
            *rty_BufferData2 = false;

            /* Transition: '<S6>:29' */
            /* '<S6>:6:1' sf_internal_predicateOutput = ReceivedPesData; */
            if (rtu_ReceivedPesData)
            {
                /* Transition: '<S6>:6' */
                /* Transition: '<S6>:20' */
                /* '<S6>:20:2' BufferData1 = true */
                *rty_BufferData1 = true;
                localDW->bitsForTID0.is_Receiving =
                    ScomFunction_IN_WaitingForContent;
            }
            else
            {
                /* Transition: '<S6>:30' */
                localDW->bitsForTID0.is_Receiving =
                    ScomFunction_IN_WaitingForHeader;
            }
        }
    }
    else
    {
        /* During 'Receiving': '<S6>:9' */
        /* '<S6>:12:1' sf_internal_predicateOutput = ~WaitForMessages; */
        if (!rtu_WaitForMessages)
        {
            /* Transition: '<S6>:12' */
            /* Transition: '<S6>:23' */
            /* '<S6>:23:2' BufferData1 = false */
            *rty_BufferData1 = false;

            /* '<S6>:23:3' BufferData2 = false */
            *rty_BufferData2 = false;

            /* Exit Internal 'Receiving': '<S6>:9' */
            localDW->bitsForTID0.is_Receiving = ScomFunction_IN_NO_ACTIVE_CHILD;
            localDW->bitsForTID0.is_c3_ScomFunction = ScomFunction_IN_Idle;
        }
        else
        {
            switch (localDW->bitsForTID0.is_Receiving)
            {
              case ScomFunction_IN_ReceivedContent:
                /* During 'ReceivedContent': '<S6>:15' */
                /* Transition: '<S6>:25' */
                /* '<S6>:25:2' BufferData2 = false */
                *rty_BufferData2 = false;
                localDW->bitsForTID0.is_Receiving =
                    ScomFunction_IN_ReceivedContent;
                break;

              case ScomFunction_IN_WaitingForContent:
                /* During 'WaitingForContent': '<S6>:4' */
                /* '<S6>:16:1' sf_internal_predicateOutput = ReceivedPesData; */
                if (rtu_ReceivedPesData)
                {
                    /* Transition: '<S6>:16' */
                    /* Transition: '<S6>:18' */
                    /* '<S6>:18:2' BufferData1 = false */
                    *rty_BufferData1 = false;

                    /* '<S6>:18:3' BufferData2 = true */
                    *rty_BufferData2 = true;
                    localDW->bitsForTID0.is_Receiving =
                        ScomFunction_IN_ReceivedContent;
                }
                else
                {
                    /* Transition: '<S6>:24' */
                    /* '<S6>:24:2' BufferData1 = false */
                    *rty_BufferData1 = false;
                    localDW->bitsForTID0.is_Receiving =
                        ScomFunction_IN_WaitingForContent;
                }
                break;

              default:
                /* During 'WaitingForHeader': '<S6>:3' */
                /* Transition: '<S6>:27' */
                /* '<S6>:6:1' sf_internal_predicateOutput = ReceivedPesData; */
                if (rtu_ReceivedPesData)
                {
                    /* Transition: '<S6>:6' */
                    /* Transition: '<S6>:20' */
                    /* '<S6>:20:2' BufferData1 = true */
                    *rty_BufferData1 = true;
                    localDW->bitsForTID0.is_Receiving =
                        ScomFunction_IN_WaitingForContent;
                }
                break;
            }
        }
    }

    /* End of Chart: '<S4>/Chart' */
}

/* Output and update for atomic system: '<S7>/CheckPaddingBytes' */
static void ScomFunction_CheckPaddingBytes(const uint8_T rtu_PayloadData[6],
    bool_t *rty_PaddingBytesOkay)
{
    /* Logic: '<S9>/Logical Operator' incorporates:
     *  Constant: '<S9>/Constant'
     *  RelationalOperator: '<S9>/Equal3'
     */
    *rty_PaddingBytesOkay = ((rtu_PayloadData[4] == ((uint8_T)0U)) &&
        (rtu_PayloadData[5] == ((uint8_T)0U)));
}

/* Output and update for atomic system: '<S7>/CheckPesDataId' */
static void ScomFunction_CheckPesDataId(const uint8_T rtu_HeaderData[6], bool_t *
    rty_PesDataIdCorrect)
{
    /* Outputs for Atomic SubSystem: '<S10>/Bit Shift' */
    /* RelationalOperator: '<S10>/Equal' incorporates:
     *  Constant: '<S16>/Constant'
     *  DataTypeConversion: '<S10>/Data Type Conversion'
     *  DataTypeConversion: '<S10>/Data Type Conversion1'
     *  DataTypeConversion: '<S10>/Data Type Conversion2'
     *  MATLAB Function: '<S14>/bit_shift'
     *  Sum: '<S10>/Add'
     */
    /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S17>:1' */
    /* '<S17>:1:4' switch mode */
    /* '<S17>:1:5' case 1 */
    /* '<S17>:1:6' y = bitsll(cast_to_fi(u), N); */
    /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S18>:1' */
    /* '<S18>:1:4' switch mode */
    /* '<S18>:1:5' case 1 */
    /* '<S18>:1:6' y = bitsll(cast_to_fi(u), N); */
    *rty_PesDataIdCorrect = (PesDataId_PCB_MANUFACTURING_DATE == ((PesDataId_E)
        (((uint32_T)((uint32_T)(((uint32_T)rtu_HeaderData[0]) << ((uint64_T)8))))
         + ((uint32_T)rtu_HeaderData[1]))));

    /* End of Outputs for SubSystem: '<S10>/Bit Shift' */
}

/*
 * Output and update for atomic system:
 *    '<S19>/MsToTimebase'
 *    '<S21>/MsToTimebase'
 */
static void ScomFunction_MsToTimebase(Timebase_t rtu_base, uint32_T *rty_ms)
{
    uint32_T ms;
    uint32_T b_y;
    uint64_T tmp;

    /* MATLAB Function 'PESSRAL/Time/MsToTimebase/MsToTimebase': '<S20>:1' */
    /* '<S20>:1:3' ms = MsToTimebase(base, ms); */
    /*  CECB: MsToTimebase() - MW @ CECB */
    /*  Calculates # timebase-ticks from ms. */
    /*  Inputs:  base [�s], ms [ms] */
    /*  Return:  ticks */
    /*  Example: "MsToTimebase(50, 10);" Returns the timebase ticks for 10 ms, */
    /*                                   where the timebase runs with 50 �s. */
    /*  Note:    Sets result to zero in the following cases: */
    /*              * base == 0 */
    /*              * base <  0 */
    /*              * base is larger than uint32 */
    /*              * ms   <  0 */
    /*              * ms   is larger than uint32 */
    /*  */
    /*  Todo: Raise an error instead of setting the result to zero. */
    /*  We need to typecast these values, because for an uint8 matlab would cause */
    /*  a saturation:  uint8(1) * 1000 == uint(255) */
    /* 'MsToTimebase:19' base_tb = uint32(base); */
    /* 'MsToTimebase:20' ms_tb   = uint32(ms); */
    /* 'MsToTimebase:22' if (base_tb ~= base) || (ms_tb ~= ms) || (base_tb == 0) */
    if (rtu_base == 0U)
    {
        /*  raise error */
        /*  ticks = uint32(1) / uint32(0); */
        /*  because we cant raise an error in matlab and in C, we set ticks to */
        /*  zero */
        /* 'MsToTimebase:28' ticks = uint32(0); */
        ms = 0U;
    }
    else if ((*rty_ms) < 429497U)
    {
        /* 'MsToTimebase:30' elseif (ms_tb < (uint32(429496725) / uint32(1000))) */
        /*  uint32 calculation */
        /* 'MsToTimebase:32' ticks = (ms_tb * 1000) / base_tb; */
        tmp = ((uint64_T)(*rty_ms)) * 1000ULL;
        if (tmp > 4294967295ULL)
        {
            tmp = 4294967295ULL;
        }

        b_y = (uint32_T)tmp;
        ms = b_y / ((uint32_T)rtu_base);
        b_y -= ms * ((uint32_T)rtu_base);
        if ((b_y > 0U) && (b_y >= ((uint32_T)(((uint32_T)(((uint32_T)rtu_base) >>
                 1U)) + ((uint32_T)((Timebase_t)(rtu_base & 1U)))))))
        {
            ms++;
        }

        /*  normalize ms to �s and divide by base */
    }
    else
    {
        /* 'MsToTimebase:34' else */
        /*  double calculation for large values */
        /*  reason: uint32 calculation would cause a saturation of ms_tb */
        /* 'MsToTimebase:38' if (coder.target('Sfun') || coder.target('MATLAB')) */
        /* 'MsToTimebase:40' else */
        /*  embedded coder ------------------------------------------------------- */
        /*  dbgPrintf(uint32(0), 'Saturation \n'); */
        /* 'MsToTimebase:42' ticks = uint32(((ms_tb) * 1000) / base_tb); */
        tmp = ((uint64_T)(*rty_ms)) * 1000ULL;
        if (tmp > 4294967295ULL)
        {
            tmp = 4294967295ULL;
        }

        b_y = (uint32_T)tmp;
        ms = b_y / ((uint32_T)rtu_base);
        b_y -= ms * ((uint32_T)rtu_base);
        if ((b_y > 0U) && (b_y >= ((uint32_T)(((uint32_T)(((uint32_T)rtu_base) >>
                 1U)) + ((uint32_T)((Timebase_t)(rtu_base & 1U)))))))
        {
            ms++;
        }

        /*  normalize ms to �s and divide by base */
    }

    *rty_ms = ms;
}

/* Output and update for atomic system: '<S7>/CheckTimeoutHeader' */
static void ScomFunction_CheckTimeoutHeader(Timebase_t rtu_RequestTime,
    Timebase_t rtu_ReceptionTimeStamp, bool_t *rty_HeaderWithinTimeout, const
    ConstB_CheckTimeoutHeader_ScomFunction_T *localC)
{
    uint32_T rtb_ms;

    /* MATLAB Function: '<S19>/MsToTimebase' */
    rtb_ms = localC->SignalConversion1;
    ScomFunction_MsToTimebase(localC->SignalConversion2, &rtb_ms);

    /* RelationalOperator: '<S11>/Equal1' incorporates:
     *  SignalConversion: '<S19>/Signal Conversion3'
     *  Sum: '<S11>/Add'
     */
    *rty_HeaderWithinTimeout = ((rtu_RequestTime + ((Timebase_t)rtb_ms)) >=
        rtu_ReceptionTimeStamp);
}

/* Output and update for atomic system: '<S7>/CheckTimeoutPayload' */
static void ScomFunction_CheckTimeoutPayload(Timebase_t
    rtu_PreviousMessageTimestamp, Timebase_t rtu_NextMessagetimeStamp, bool_t
    *rty_PayloadWithinTimeout, const ConstB_CheckTimeoutPayload_ScomFunction_T
    *localC)
{
    uint32_T rtb_ms;

    /* MATLAB Function: '<S21>/MsToTimebase' */
    rtb_ms = localC->SignalConversion1;
    ScomFunction_MsToTimebase(localC->SignalConversion2, &rtb_ms);

    /* RelationalOperator: '<S12>/Equal2' incorporates:
     *  SignalConversion: '<S21>/Signal Conversion3'
     *  Sum: '<S12>/Add1'
     */
    *rty_PayloadWithinTimeout = ((rtu_PreviousMessageTimestamp + ((Timebase_t)
        rtb_ms)) >= rtu_NextMessagetimeStamp);
}

/* Output and update for atomic system: '<S7>/GetCrc' */
static void ScomFunction_GetCrc(const uint8_T rtu_HeaderData[6], const uint8_T
    rtu_PayloadData[6], bool_t *rty_CrcMatches, const
    ConstB_GetCrc_ScomFunction_T *localC)
{
    uint32_T Crc32;
    uint8_T rtu_PayloadData_0[6];
    int32_T i;

    /* SignalConversion: '<S27>/Signal Conversion4' */
    /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S28>:1' */
    /* '<S28>:1:4' switch mode */
    /* '<S28>:1:5' case 1 */
    /* '<S28>:1:6' y = bitsll(cast_to_fi(u), N); */
    /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S29>:1' */
    /* '<S29>:1:4' switch mode */
    /* '<S29>:1:5' case 1 */
    /* '<S29>:1:6' y = bitsll(cast_to_fi(u), N); */
    /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S30>:1' */
    /* '<S30>:1:4' switch mode */
    /* '<S30>:1:5' case 1 */
    /* '<S30>:1:6' y = bitsll(cast_to_fi(u), N); */
    /* MATLAB Function 'Logic and Bit Operations/Bit Shift/bit_shift': '<S31>:1' */
    /* '<S31>:1:4' switch mode */
    /* '<S31>:1:5' case 1 */
    /* '<S31>:1:6' y = bitsll(cast_to_fi(u), N); */
    /* MATLAB Function 'CalculateCrc32/MatlabFunctionCall': '<S32>:1' */
    /* '<S32>:1:3' if (coder.target('Sfun')) */
    /* '<S32>:1:8' else */
    /*  embedded coder ------------------------------------------------- */
    /* '<S32>:1:10' coder.cinclude('Hlp/Crc32.h'); */
    /*  invoke C function */
    /* '<S32>:1:13' Crc32 = coder.ceval('HlpCrc32_Calculate16BitLength', data, length); */
    for (i = 0; i < 6; i++)
    {
        rtu_PayloadData_0[i] = rtu_PayloadData[i];
    }

    /* End of SignalConversion: '<S27>/Signal Conversion4' */

    /* MATLAB Function: '<S27>/MatlabFunctionCall' */
    Crc32 = HlpCrc32_Calculate16BitLength(rtu_PayloadData_0, localC->Length);

    /* Outputs for Atomic SubSystem: '<S13>/Bit Shift' */
    /* Outputs for Atomic SubSystem: '<S13>/Bit Shift1' */
    /* Outputs for Atomic SubSystem: '<S13>/Bit Shift2' */
    /* RelationalOperator: '<S13>/Equal3' incorporates:
     *  DataTypeConversion: '<S13>/Data Type Conversion'
     *  DataTypeConversion: '<S13>/Data Type Conversion1'
     *  DataTypeConversion: '<S13>/Data Type Conversion2'
     *  DataTypeConversion: '<S13>/Data Type Conversion3'
     *  MATLAB Function: '<S23>/bit_shift'
     *  MATLAB Function: '<S24>/bit_shift'
     *  MATLAB Function: '<S25>/bit_shift'
     *  MATLAB Function: '<S27>/MatlabFunctionCall'
     *  Sum: '<S13>/Add'
     */
    *rty_CrcMatches = (((((((uint32_T)rtu_HeaderData[2]) << ((uint64_T)24)) +
                          (((uint32_T)rtu_HeaderData[3]) << ((uint64_T)16))) +
                         (((uint32_T)rtu_HeaderData[4]) << ((uint64_T)8))) +
                        ((uint32_T)rtu_HeaderData[5])) == Crc32);

    /* End of Outputs for SubSystem: '<S13>/Bit Shift2' */
    /* End of Outputs for SubSystem: '<S13>/Bit Shift1' */
    /* End of Outputs for SubSystem: '<S13>/Bit Shift' */
}

/* Output and update for trigger system: '<S4>/CheckPcbManufacturingDate' */
static void ScomFunction_CheckPcbManufacturingDate(bool_t rtu_Trigger,
    Timebase_t rtu_RequestTime, const PesDataReceived_C *rtu_PesData1, const
    PesDataReceived_C *rtu_PesData2, PesDataSetPcbManufacturingDateReceived_B
    *rty_SetPcbManufacturingDateFromConfigurationMaster, const
    ConstB_CheckPcbManufacturingDate_ScomFunction_T *localC,
    DW_CheckPcbManufacturingDate_ScomFunction_T *localDW,
    ZCE_CheckPcbManufacturingDate_ScomFunction_T *localZCE)
{
    bool_t rtb_HeaderWithinTimeout;
    bool_t rtb_PayloadWithinTimeout;
    bool_t rtb_PesDataIdCorrect;
    bool_t rtb_CrcMatches;
    bool_t rtb_PaddingBytesOkay;
    int32_T i;

    /* Outputs for Triggered SubSystem: '<S4>/CheckPcbManufacturingDate' incorporates:
     *  TriggerPort: '<S7>/Trigger'
     */
    if (rtu_Trigger && (((uint32_T)localZCE->CheckPcbManufacturingDate_Trig_ZCE)
                        != POS_ZCSIG))
    {
        /* Outputs for Atomic SubSystem: '<S7>/CheckTimeoutHeader' */
        ScomFunction_CheckTimeoutHeader(rtu_RequestTime,
            rtu_PesData1->ReceptionTimeStamp, &rtb_HeaderWithinTimeout,
            &localC->CheckTimeoutHeader);

        /* End of Outputs for SubSystem: '<S7>/CheckTimeoutHeader' */

        /* Outputs for Atomic SubSystem: '<S7>/CheckTimeoutPayload' */
        ScomFunction_CheckTimeoutPayload(rtu_PesData1->ReceptionTimeStamp,
            rtu_PesData2->ReceptionTimeStamp, &rtb_PayloadWithinTimeout,
            &localC->CheckTimeoutPayload);

        /* End of Outputs for SubSystem: '<S7>/CheckTimeoutPayload' */

        /* Outputs for Atomic SubSystem: '<S7>/CheckPesDataId' */
        ScomFunction_CheckPesDataId(rtu_PesData1->Data, &rtb_PesDataIdCorrect);

        /* End of Outputs for SubSystem: '<S7>/CheckPesDataId' */

        /* Outputs for Atomic SubSystem: '<S7>/GetCrc' */
        ScomFunction_GetCrc(rtu_PesData1->Data, rtu_PesData2->Data,
                            &rtb_CrcMatches, &localC->GetCrc);

        /* End of Outputs for SubSystem: '<S7>/GetCrc' */

        /* Outputs for Atomic SubSystem: '<S7>/CheckPaddingBytes' */
        ScomFunction_CheckPaddingBytes(rtu_PesData2->Data, &rtb_PaddingBytesOkay);

        /* End of Outputs for SubSystem: '<S7>/CheckPaddingBytes' */

        /* Switch: '<S7>/Switch' incorporates:
         *  BusAssignment: '<S7>/Bus Assignment'
         *  Logic: '<S7>/AND'
         *  UnitDelay: '<S7>/Unit Delay'
         */
        if ((((rtb_HeaderWithinTimeout && rtb_PayloadWithinTimeout) &&
                rtb_PesDataIdCorrect) && rtb_CrcMatches) && rtb_PaddingBytesOkay)
        {
            for (i = 0; i < 6; i++)
            {
                rty_SetPcbManufacturingDateFromConfigurationMaster->SetPcbManufacturingDate.raw
                    [i] = rtu_PesData2->Data[i];
            }

            rty_SetPcbManufacturingDateFromConfigurationMaster->Timestamp =
                rtu_PesData2->ReceptionTimeStamp;
        }
        else
        {
            *rty_SetPcbManufacturingDateFromConfigurationMaster =
                localDW->UnitDelay_DSTATE;
        }

        /* End of Switch: '<S7>/Switch' */

        /* Update for UnitDelay: '<S7>/Unit Delay' */
        localDW->UnitDelay_DSTATE =
            *rty_SetPcbManufacturingDateFromConfigurationMaster;
    }

    localZCE->CheckPcbManufacturingDate_Trig_ZCE = rtu_Trigger ? ((ZCSigState)1)
        : ((ZCSigState)0);

    /* End of Outputs for SubSystem: '<S4>/CheckPcbManufacturingDate' */
}

/* Outputs for atomic system: '<S3>/ScomHandlePesData' */
static void ScomFunction_ScomHandlePesData(const PesDataReceived_C
    *rtu_PesDataFromConfigurationMaster, bool_t
    rtu_waitForPesDataSetPcbManufacturingDateFromConfigurationMaste, Timebase_t
    rtu_Timebase, PesDataSetPcbManufacturingDateReceived_B
    *rty_SetPcbManufacturingDateFromConfigurationMaster,
    B_ScomHandlePesData_ScomFunction_T *localB, const
    ConstB_ScomHandlePesData_ScomFunction_T *localC,
    DW_ScomHandlePesData_ScomFunction_T *localDW,
    ZCE_ScomHandlePesData_ScomFunction_T *localZCE)
{
    bool_t rtb_ReceivedNewPesData;
    bool_t rtb_HiddenBuf_InsertedFor_CheckPcbManufacturingDate_at_inport_3;

    /* RelationalOperator: '<S4>/Equal' incorporates:
     *  UnitDelay: '<S4>/Unit Delay'
     */
    rtb_ReceivedNewPesData =
        (rtu_PesDataFromConfigurationMaster->ReceptionTimeStamp !=
         localDW->UnitDelay_DSTATE);

    /* Chart: '<S4>/Chart' */
    ScomFunction_Chart
        (rtu_waitForPesDataSetPcbManufacturingDateFromConfigurationMaste,
         rtb_ReceivedNewPesData, &localB->BufferData1, &localB->BufferData2,
         &localDW->sf_Chart);

    /* SignalConversion: '<S8>/Signal Conversion' */
    localB->SignalConversion =
        rtu_waitForPesDataSetPcbManufacturingDateFromConfigurationMaste;

    /* Switch: '<S4>/Switch2' incorporates:
     *  Constant: '<S33>/Constant'
     *  Delay: '<S8>/Delay'
     *  Logic: '<S8>/Logical Operator'
     *  RelationalOperator: '<S33>/Compare'
     *  RelationalOperator: '<S8>/Relational Operator'
     *  UnitDelay: '<S4>/Unit Delay3'
     */
    if ((localB->SignalConversion == true) && (localB->SignalConversion !=
            localDW->Delay_DSTATE))
    {
        localB->RequestTime = rtu_Timebase;
    }
    else
    {
        localB->RequestTime = localDW->UnitDelay3_DSTATE;
    }

    /* End of Switch: '<S4>/Switch2' */

    /* Switch: '<S4>/Switch' incorporates:
     *  UnitDelay: '<S4>/Unit Delay1'
     */
    if (localB->BufferData1)
    {
        localB->BufferedHeader = *rtu_PesDataFromConfigurationMaster;
    }
    else
    {
        localB->BufferedHeader = localDW->UnitDelay1_DSTATE;
    }

    /* End of Switch: '<S4>/Switch' */

    /* SignalConversion generated from: '<S7>/Trigger' */
    rtb_HiddenBuf_InsertedFor_CheckPcbManufacturingDate_at_inport_3 =
        localB->BufferData2;

    /* Outputs for Triggered SubSystem: '<S4>/CheckPcbManufacturingDate' */
    ScomFunction_CheckPcbManufacturingDate
        (rtb_HiddenBuf_InsertedFor_CheckPcbManufacturingDate_at_inport_3,
         localB->RequestTime, &localB->BufferedHeader,
         rtu_PesDataFromConfigurationMaster,
         rty_SetPcbManufacturingDateFromConfigurationMaster,
         &localC->CheckPcbManufacturingDate, &localDW->CheckPcbManufacturingDate,
         &localZCE->CheckPcbManufacturingDate);

    /* End of Outputs for SubSystem: '<S4>/CheckPcbManufacturingDate' */
}

/* Update for atomic system: '<S3>/ScomHandlePesData' */
static void ScomFunction_ScomHandlePesData_Update(const PesDataReceived_C
    *rtu_PesDataFromConfigurationMaster, B_ScomHandlePesData_ScomFunction_T
    *localB, DW_ScomHandlePesData_ScomFunction_T *localDW)
{
    /* Update for UnitDelay: '<S4>/Unit Delay' */
    localDW->UnitDelay_DSTATE =
        rtu_PesDataFromConfigurationMaster->ReceptionTimeStamp;

    /* Update for Delay: '<S8>/Delay' */
    localDW->Delay_DSTATE = localB->SignalConversion;

    /* Update for UnitDelay: '<S4>/Unit Delay3' */
    localDW->UnitDelay3_DSTATE = localB->RequestTime;

    /* Update for UnitDelay: '<S4>/Unit Delay1' */
    localDW->UnitDelay1_DSTATE = localB->BufferedHeader;
}

/* System initialize for enable system: '<Root>/ScomHandleMessage' */
static void ScomFunction_ScomHandleMessage_Init(void)
{
    /* SystemInitialize for Enabled SubSystem: '<S5>/LatchPesRequest' */
    /* SystemInitialize for Outport: '<S35>/PesRequestToEvaluate' */
    ScomFunction_B.PesRequestToEvaluate = ScomFunction_rtZPesRequestNew_C;

    /* End of SystemInitialize for SubSystem: '<S5>/LatchPesRequest' */

    /* SystemInitialize for BusCreator: '<S3>/Bus Creator' incorporates:
     *  SignalConversion: '<S3>/MapPesRequestToScomHandled'
     */
    ScomFunction_B.ScomHandledCanMessages.PesRequest =
        ScomFunction_B.PesRequestToEvaluate;
    ScomFunction_B.ScomHandledCanMessages.SetPcbManufacturingDateFromConfigurationMaster
        = ScomFunction_B.SetPcbManufacturingDateFromConfigurationMaster;
}

/* Outputs for enable system: '<Root>/ScomHandleMessage' */
static void ScomFunction_ScomHandleMessage(void)
{
    /* Outputs for Enabled SubSystem: '<Root>/ScomHandleMessage' incorporates:
     *  EnablePort: '<S3>/Enable'
     */
    if (ScomFunction_B.LogicalOperator1)
    {
        /* Outputs for Enabled SubSystem: '<S5>/LatchPesRequest' incorporates:
         *  EnablePort: '<S35>/Enable'
         */
        /* Logic: '<S5>/Logical Operator' incorporates:
         *  Delay: '<S34>/Delay'
         *  Inport: '<Root>/ScomCanInputs'
         *  Inport: '<Root>/ScomHost'
         *  RelationalOperator: '<S34>/Relational Operator'
         *  RelationalOperator: '<S5>/Relational Operator'
         *
         * Block description for '<Root>/ScomCanInputs':
         *  Read-back input of the output SafeOut (Safety Chain Output).
         */
        if ((ScomFunction_U.ScomHost ==
                ScomFunction_U.ScomCanInputs.PesRequest.Requestee) &&
                (ScomFunction_U.ScomCanInputs.PesRequest.ReceptionTimeStamp !=
                 ScomFunction_DW.Delay_DSTATE))
        {
            /* SignalConversion: '<S35>/Signal Conversion4' */
            ScomFunction_B.PesRequestToEvaluate =
                ScomFunction_U.ScomCanInputs.PesRequest;
        }

        /* End of Logic: '<S5>/Logical Operator' */
        /* End of Outputs for SubSystem: '<S5>/LatchPesRequest' */

        /* Outputs for Atomic SubSystem: '<S3>/ScomHandlePesData' */
        /* Inport: '<Root>/ScomCanInputs' incorporates:
         *  Inport: '<Root>/Timebase'
         *
         * Block description for '<Root>/ScomCanInputs':
         *  Read-back input of the output SafeOut (Safety Chain Output).
         *
         * Block description for '<Root>/Timebase':
         *  Safety discrete inputs of the GECBP to be sampled by the SCON
         *  software, read in via a 2nd channel: Hardware shift register.
         */
        ScomFunction_ScomHandlePesData
            (&ScomFunction_U.ScomCanInputs.PesDataFromConfigurationMaster,
             ScomFunction_B.ScomHandleCanMessagesCommandOld.waitForPesDataSetPcbManufacturingDateFromConfigurationMaster,
             ScomFunction_U.Timebase,
             &ScomFunction_B.SetPcbManufacturingDateFromConfigurationMaster,
             &ScomFunction_B.ScomHandlePesData,
             &ScomFunction_ConstB.ScomHandlePesData,
             &ScomFunction_DW.ScomHandlePesData,
             &ScomFunction_PrevZCX.ScomHandlePesData);

        /* End of Outputs for SubSystem: '<S3>/ScomHandlePesData' */

        /* BusCreator: '<S3>/Bus Creator' incorporates:
         *  SignalConversion: '<S3>/MapPesRequestToScomHandled'
         */
        ScomFunction_B.ScomHandledCanMessages.PesRequest =
            ScomFunction_B.PesRequestToEvaluate;
        ScomFunction_B.ScomHandledCanMessages.SetPcbManufacturingDateFromConfigurationMaster
            = ScomFunction_B.SetPcbManufacturingDateFromConfigurationMaster;
    }

    /* End of Outputs for SubSystem: '<Root>/ScomHandleMessage' */
}

/* Update for enable system: '<Root>/ScomHandleMessage' */
static void ScomFunction_ScomHandleMessage_Update(void)
{
    /* Update for Enabled SubSystem: '<Root>/ScomHandleMessage' incorporates:
     *  EnablePort: '<S3>/Enable'
     */
    if (ScomFunction_B.LogicalOperator1)
    {
        /* Update for Delay: '<S34>/Delay' incorporates:
         *  Inport: '<Root>/ScomCanInputs'
         *
         * Block description for '<Root>/ScomCanInputs':
         *  Read-back input of the output SafeOut (Safety Chain Output).
         */
        ScomFunction_DW.Delay_DSTATE =
            ScomFunction_U.ScomCanInputs.PesRequest.ReceptionTimeStamp;

        /* Update for Atomic SubSystem: '<S3>/ScomHandlePesData' */
        /* Update for Inport: '<Root>/ScomCanInputs'
         *
         * Block description for '<Root>/ScomCanInputs':
         *  Read-back input of the output SafeOut (Safety Chain Output).
         */
        ScomFunction_ScomHandlePesData_Update
            (&ScomFunction_U.ScomCanInputs.PesDataFromConfigurationMaster,
             &ScomFunction_B.ScomHandlePesData,
             &ScomFunction_DW.ScomHandlePesData);

        /* End of Update for SubSystem: '<S3>/ScomHandlePesData' */
    }

    /* End of Update for SubSystem: '<Root>/ScomHandleMessage' */
}

/* Model output function */
void ScomFunction_output(void)
{
    /* UnitDelay: '<Root>/Unit Delay' */
    ScomFunction_B.ScomHandleCanMessagesCommandOld =
        ScomFunction_DW.UnitDelay_DSTATE;

    /* Logic: '<Root>/Logical Operator1' incorporates:
     *  Inport: '<Root>/IsPeriodicCall'
     *
     * Block description for '<Root>/IsPeriodicCall':
     *  Safety discrete inputs of the GECBP to be sampled by the SCON
     *  software, read in via a 2nd channel: Hardware shift register.
     */
    ScomFunction_B.LogicalOperator1 = !ScomFunction_U.IsPeriodicCall;

    /* Outputs for Enabled SubSystem: '<Root>/ScomHandleMessage' */
    ScomFunction_ScomHandleMessage();

    /* End of Outputs for SubSystem: '<Root>/ScomHandleMessage' */

    /* Outputs for Enabled SubSystem: '<Root>/ScomEvaluation' */
    ScomFunction_ScomEvaluation();

    /* End of Outputs for SubSystem: '<Root>/ScomEvaluation' */

    /* Outport: '<Root>/NvmGlobalOut' incorporates:
     *  Inport: '<Root>/NvmGlobalIn'
     */
    ScomFunction_Y.NvmGlobalOut = ScomFunction_U.NvmGlobalIn;
}

/* Model update function */
void ScomFunction_update(void)
{
    /* Update for UnitDelay: '<Root>/Unit Delay' */
    ScomFunction_DW.UnitDelay_DSTATE =
        ScomFunction_B.ScomHandleCanMessagesCommand;

    /* Update for Enabled SubSystem: '<Root>/ScomHandleMessage' */
    ScomFunction_ScomHandleMessage_Update();

    /* End of Update for SubSystem: '<Root>/ScomHandleMessage' */

    /* Update for Enabled SubSystem: '<Root>/ScomEvaluation' */
    ScomFunction_ScomEvaluation_Update();

    /* End of Update for SubSystem: '<Root>/ScomEvaluation' */
}

/* Model initialize function */
void ScomFunction_initialize(void)
{
    /* Registration code */

    /* block I/O */
    {
        ScomFunction_B.ScomHandledCanMessages =
            ScomFunction_rtZScomHandledCanMessages_B;
        ScomFunction_B.PesRequestToEvaluate = ScomFunction_rtZPesRequestNew_C;
    }

    /* external inputs */
    ScomFunction_U.ScomCanInputs = ScomFunction_rtZScomCanInputs_B;

    /* external outputs */
    ScomFunction_Y.ScomCanOutputs = ScomFunction_rtZScomCanOutputs_B;

    /* Model Initialize function for ModelReference Block: '<S1>/HandlePesRequestRef' */
    HandlePesRequest_initialize
        (&(ScomFunction_DW.HandlePesRequestRef_InstanceData.rtb),
         &(ScomFunction_DW.HandlePesRequestRef_InstanceData.rtdw));
    ScomFunction_PrevZCX.ScomHandlePesData.CheckPcbManufacturingDate.CheckPcbManufacturingDate_Trig_ZCE
        = POS_ZCSIG;

    /* SystemInitialize for Enabled SubSystem: '<Root>/ScomHandleMessage' */
    ScomFunction_ScomHandleMessage_Init();

    /* End of SystemInitialize for SubSystem: '<Root>/ScomHandleMessage' */

    /* SystemInitialize for Enabled SubSystem: '<Root>/ScomEvaluation' */
    ScomFunction_ScomEvaluation_Init();

    /* End of SystemInitialize for SubSystem: '<Root>/ScomEvaluation' */
}

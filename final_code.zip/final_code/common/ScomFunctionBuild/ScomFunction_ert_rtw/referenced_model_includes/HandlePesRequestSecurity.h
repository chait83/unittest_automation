/*
 * ---------------------------------------------------------------------------
 * Copyright (c) 2015 UTC - All rights reserved.
 *
 * Model Name:         HandlePesRequestSecurity
 * Code Generation:     -
 * Svn:
 * ---------------------------------------------------------------------------
 */

#ifndef RTW_HEADER_HandlePesRequestSecurity_h_
#define RTW_HEADER_HandlePesRequestSecurity_h_
#include "rtwtypes.h"
#ifndef HandlePesRequestSecurity_COMMON_INCLUDES_
# define HandlePesRequestSecurity_COMMON_INCLUDES_
#include "rtwtypes.h"
#endif                           /* HandlePesRequestSecurity_COMMON_INCLUDES_ */

/* user code (top of header file) */

/* *****************************************************************************/
/* **                _______   _________  _________   _______                 **/
/* **               (  ___  )  \__   __/  \__   __/  (  ____ \                **/
/* **               | (   ) |     ) (        ) (     | (    \/                **/
/* **               | |   | |     | |        | |     | (_____                 **/
/* **               | |   | |     | |        | |     (_____  )                **/
/* **               | |   | |     | |        | |           ) |                **/
/* **               | (___) |     | |     ___) (___  /\____) |                **/
/* **               (_______)     )_(     \_______/  \_______)                **/
/* **                                                                         **/
/* **                      OTIS Lead Design Center Berlin                     **/
/* **                                                                         **/
/* **   Copyright 2020 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **/
/* **                                                                         **/
/* *****************************************************************************/
/* **                                                                         **/
/* ** Simulink Model                                                          **/
/* **                                                                         **/
/* ** Purpose                                                                 **/
/* **  Model of Functional Safety Logic of the Pessral System                 **/
/* **                                                                         **/
/* ** Functionality                                                           **/
/* **  This is one of the source files auto-generated from the Simulink Model **/
/* **  with the help of the Simulink Embedded Coder.                          **/
/* **                                                                         **/
/* **                    DO NOT MANUALLY CHANGE THIS FILE                     **/
/* **                    ================================                     **/
/* **                                                                         **/
/* *****************************************************************************/
#ifndef DEFINED_TYPEDEF_FOR_SecurityRequestCryptoChipConfigure_B_
#define DEFINED_TYPEDEF_FOR_SecurityRequestCryptoChipConfigure_B_

typedef struct
{
    bool_t Send;
}
SecurityRequestCryptoChipConfigure_B;

#endif

#ifndef DEFINED_TYPEDEF_FOR_SecurityRequestCryptoChipCreateKey_B_
#define DEFINED_TYPEDEF_FOR_SecurityRequestCryptoChipCreateKey_B_

typedef struct
{
    bool_t Send;
}
SecurityRequestCryptoChipCreateKey_B;

#endif

#ifndef DEFINED_TYPEDEF_FOR_SecurityRequestCryptoChipLockConfig_B_
#define DEFINED_TYPEDEF_FOR_SecurityRequestCryptoChipLockConfig_B_

typedef struct
{
    bool_t Send;
}
SecurityRequestCryptoChipLockConfig_B;

#endif

#ifndef DEFINED_TYPEDEF_FOR_SecurityRequestOtpActivate_B_
#define DEFINED_TYPEDEF_FOR_SecurityRequestOtpActivate_B_

typedef struct
{
    bool_t Send;
}
SecurityRequestOtpActivate_B;

#endif

#ifndef DEFINED_TYPEDEF_FOR_PesRequestSecurity_E_
#define DEFINED_TYPEDEF_FOR_PesRequestSecurity_E_

typedef enum
{
    PesRequestSecurity_CRYPTOCHIP_CONFIGURE = 1,/* Default value */
    PesRequestSecurity_CRYPTOCHIP_CREATEKEY,
    PesRequestSecurity_CRYPTOCHIP_LOCK_CONFIG,
    PesRequestSecurity_CRYPTOCHIP_LOCK_FINAL,
    PesRequestSecurity_OTP_ACTIVATE
}
PesRequestSecurity_E;

#endif

/* Invariant block signals for model 'HandlePesRequestSecurity' */
typedef struct
{
    const uint16_T uint8_boolean;      /* '<Root>/uint8_boolean' */
    const uint16_T uint8_boolean1;     /* '<Root>/uint8_boolean1' */
    const uint16_T uint8_boolean2;     /* '<Root>/uint8_boolean2' */
    const uint16_T uint8_boolean3;     /* '<Root>/uint8_boolean3' */
}
ConstB_HandlePesRequestSecurity_hb4t_T;

extern const ConstB_HandlePesRequestSecurity_hb4t_T
    HandlePesRequestSecurity_ConstB;
extern void HandlePesRequestSecurity(bool_t rtu_IsNewRequestSecurity, uint16_T
    rtu_Parameter, SecurityRequestCryptoChipConfigure_B
    *rty_SecurityRequestCryptoChipConfigure,
    SecurityRequestCryptoChipCreateKey_B *rty_SecurityRequestCryptoChipCreateKey,
    SecurityRequestCryptoChipLockConfig_B
    *rty_SecurityRequestCryptoChipLockConfig, SecurityRequestOtpActivate_B
    *rty_SecurityRequestOtpActivate);

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'HandlePesRequestSecurity'
 */

/*-
 * Requirements for '<Root>': HandlePesRequestSecurity
 */
#endif                              /* RTW_HEADER_HandlePesRequestSecurity_h_ */

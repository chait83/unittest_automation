/*
 * ---------------------------------------------------------------------------
 * Copyright (c) 2015 UTC - All rights reserved.
 *
 * Model Name:         HandlePesRequest
 * Code Generation:     -
 * Svn:
 * ---------------------------------------------------------------------------
 */

#ifndef RTW_HEADER_HandlePesRequest_h_
#define RTW_HEADER_HandlePesRequest_h_
#include "rtwtypes.h"
#include "OpbNodeAddr.h"
#include "Event/SafetyNode.h"
#include "Timebase_t.h"
#ifndef HandlePesRequest_COMMON_INCLUDES_
# define HandlePesRequest_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "Hlp/Crc32.h"
#endif                                 /* HandlePesRequest_COMMON_INCLUDES_ */

/* Child system includes */
#include "HandlePesRequestData.h"
#include "HandlePesRequestSecurity.h"

/* user code (top of header file) */

/* *****************************************************************************/
/* **                _______   _________  _________   _______                 **/
/* **               (  ___  )  \__   __/  \__   __/  (  ____ \                **/
/* **               | (   ) |     ) (        ) (     | (    \/                **/
/* **               | |   | |     | |        | |     | (_____                 **/
/* **               | |   | |     | |        | |     (_____  )                **/
/* **               | |   | |     | |        | |           ) |                **/
/* **               | (___) |     | |     ___) (___  /\____) |                **/
/* **               (_______)     )_(     \_______/  \_______)                **/
/* **                                                                         **/
/* **                      OTIS Lead Design Center Berlin                     **/
/* **                                                                         **/
/* **   Copyright 2020 OTIS GmbH & Co. OHG -- PROPRIETARY and CONFIDENTIAL    **/
/* **                                                                         **/
/* *****************************************************************************/
/* **                                                                         **/
/* ** Simulink Model                                                          **/
/* **                                                                         **/
/* ** Purpose                                                                 **/
/* **  Model of Functional Safety Logic of the Pessral System                 **/
/* **                                                                         **/
/* ** Functionality                                                           **/
/* **  This is one of the source files auto-generated from the Simulink Model **/
/* **  with the help of the Simulink Embedded Coder.                          **/
/* **                                                                         **/
/* **                    DO NOT MANUALLY CHANGE THIS FILE                     **/
/* **                    ================================                     **/
/* **                                                                         **/
/* *****************************************************************************/
#ifndef DEFINED_TYPEDEF_FOR_PesRequest_Request_E_
#define DEFINED_TYPEDEF_FOR_PesRequest_Request_E_

typedef enum
{
    PesRequest_Request_E_ApplicationScn = 0,
    PesRequest_Request_E_ProcTiming = 2,
    PesRequest_Request_E_DsSegmentTable = 4,/* Default value */
    PesRequest_Request_E_CarVelocity = 5,
    PesRequest_Request_E_FloorStatus = 6,
    PesRequest_Request_E_PesConfig = 7,
    PesRequest_Request_E_ContractCertificate = 8,
    PesRequest_Request_E_StartupPhase = 9,
    PesRequest_Request_E_NormalPhase = 10,
    PesRequest_Request_E_OverspeedThreshold = 11,
    PesRequest_Request_E_InjectFccuFault = 12,
    PesRequest_Request_E_ProductionDate = 13,
    PesRequest_Request_E_InjectHwError = 14,
    PesRequest_Request_E_SupportedFeatures = 15,
    PesRequest_Request_E_Data = 16,
    PesRequest_Request_E_Security = 17,
    PesRequest_Request_E_SetData = 19
}
PesRequest_Request_E;

#endif

#ifndef DEFINED_TYPEDEF_FOR_PesRequestNew_C_
#define DEFINED_TYPEDEF_FOR_PesRequestNew_C_

/* Non-safety CAN message PesRequest. */
typedef struct
{
    /* OPB node address of the requester */
    OpbNodeAddr_E RequesterNodeAddr;

    /* Requestee:
       0 = SCON
       1 = SCAR
       2 = SPIT
       3 = SAB
       4..254 = Spare
       255 = All safety nodes that are present */
    SafetyNode_E Requestee;

    /* 0  = SCN (sofware version)
       1  = active events
       2  = ProcTiming
       3  = Update factory configuration
       4  = Ds segment table
       5  = car velocity
       6  = floor status
       7  = configuration
       8  = contract certificate
       9  = startup phase request
       10 = normal phase request
       11 = overspeed threshold
       12 = inject FCCU fault
       13 = produciton date
       14 = inject HWC error
       15 = SupportedFeatures
       16 = Data
       17 = Security */
    PesRequest_Request_E Request;

    /* The parameters depend on the request type (see PESSRAL-ESA to OCSS-Drive ICD). */
    uint16_T Parameter;

    /* Timestamp when the message was received by receiver. */
    Timebase_t ReceptionTimeStamp;
}
PesRequestNew_C;

#endif

#ifndef DEFINED_TYPEDEF_FOR_PcbManufacturingDate_B_
#define DEFINED_TYPEDEF_FOR_PcbManufacturingDate_B_

typedef struct
{
    uint8_T raw[6];
}
PcbManufacturingDate_B;

#endif

#ifndef DEFINED_TYPEDEF_FOR_PesDataSetPcbManufacturingDateReceived_B_
#define DEFINED_TYPEDEF_FOR_PesDataSetPcbManufacturingDateReceived_B_

typedef struct
{
    PcbManufacturingDate_B SetPcbManufacturingDate;
    Timebase_t Timestamp;
}
PesDataSetPcbManufacturingDateReceived_B;

#endif

#ifndef DEFINED_TYPEDEF_FOR_PcbInfo_B_
#define DEFINED_TYPEDEF_FOR_PcbInfo_B_

typedef struct
{
    uint8_T SystemManufacturer[36];
    uint8_T PcbPartNumber[18];
    uint8_T ExaminationCertificate[36];
    uint8_T SafetySystemType[36];
    uint8_T PcbManufacturer[36];
    uint8_T MissionTime[6];
    PcbManufacturingDate_B PcbManufacturingDate;

    /* Determines, if PcbManufacturingDate is has a valid value. */
    bool_t PcbManufacturingDateIsValid;
}
PcbInfo_B;

#endif

#ifndef DEFINED_TYPEDEF_FOR_OtpWritePcbManufacturingDateReply_B_
#define DEFINED_TYPEDEF_FOR_OtpWritePcbManufacturingDateReply_B_

typedef struct
{
    /* Timestamp of the time when the message was received. */
    Timebase_t ReceptionTimeStamp;
    bool_t Result;
}
OtpWritePcbManufacturingDateReply_B;

#endif

#ifndef DEFINED_TYPEDEF_FOR_PesData_C_
#define DEFINED_TYPEDEF_FOR_PesData_C_

typedef struct
{
    OpbNodeAddr_E RequesterNodeAddr;

    /* The PesData contains a payload of 6 * Bytes, with a fixed length. */
    uint8_T Data[6];

    /* This boolean indicates for sending logic that this message shall be send. */
    bool_t Send;
}
PesData_C;

#endif

#ifndef DEFINED_TYPEDEF_FOR_SecurityRequestCryptoChipConfigure_B_
#define DEFINED_TYPEDEF_FOR_SecurityRequestCryptoChipConfigure_B_

typedef struct
{
    bool_t Send;
}
SecurityRequestCryptoChipConfigure_B;

#endif

#ifndef DEFINED_TYPEDEF_FOR_SecurityRequestCryptoChipCreateKey_B_
#define DEFINED_TYPEDEF_FOR_SecurityRequestCryptoChipCreateKey_B_

typedef struct
{
    bool_t Send;
}
SecurityRequestCryptoChipCreateKey_B;

#endif

#ifndef DEFINED_TYPEDEF_FOR_SecurityRequestCryptoChipLockConfig_B_
#define DEFINED_TYPEDEF_FOR_SecurityRequestCryptoChipLockConfig_B_

typedef struct
{
    bool_t Send;
}
SecurityRequestCryptoChipLockConfig_B;

#endif

#ifndef DEFINED_TYPEDEF_FOR_SecurityRequestOtpActivate_B_
#define DEFINED_TYPEDEF_FOR_SecurityRequestOtpActivate_B_

typedef struct
{
    bool_t Send;
}
SecurityRequestOtpActivate_B;

#endif

#ifndef DEFINED_TYPEDEF_FOR_OtpWritePcbManufacturingDate_B_
#define DEFINED_TYPEDEF_FOR_OtpWritePcbManufacturingDate_B_

typedef struct
{
    uint8_T Day;
    uint8_T Month;
    uint16_T Year;
    bool_t Send;
}
OtpWritePcbManufacturingDate_B;

#endif

#ifndef DEFINED_TYPEDEF_FOR_PesDataId_E_
#define DEFINED_TYPEDEF_FOR_PesDataId_E_

typedef uint16_T PesDataId_E;

/* enum PesDataId_E */
#define PesDataId_None                 ((PesDataId_E)0U)
#define PesDataId_SYSTEM_MANUFACTURER  ((PesDataId_E)1U)         /* Default value */
#define PesDataId_SAFETY_SYSTEM_TYPE   ((PesDataId_E)2U)
#define PesDataId_EXAMINATION_CERTIFICATE ((PesDataId_E)3U)
#define PesDataId_PCB_PART_NUMBER      ((PesDataId_E)4U)
#define PesDataId_PCB_MANUFACTURER     ((PesDataId_E)5U)
#define PesDataId_MISSION_TIME         ((PesDataId_E)6U)
#define PesDataId_PCB_MANUFACTURING_DATE ((PesDataId_E)7U)
#define PesDataId_CONTRACT_CERTIFICATE ((PesDataId_E)8U)
#define PesDataId_TRIP_SPEED_THRESHOLD ((PesDataId_E)9U)
#define PesDataId_PIT_PROTECTION_LIMIT ((PesDataId_E)10U)
#define PesDataId_VALIDITY_STATUS      ((PesDataId_E)11U)
#define PesDataId_HOISTWAY_LEARN_STATUS ((PesDataId_E)12U)
#define PesDataId_OVERSPEED_THRESHOLD  ((PesDataId_E)13U)
#define PesDataId_ETS_STOP_DIST_DN     ((PesDataId_E)14U)
#define PesDataId_ETS_STOP_DIST_UP     ((PesDataId_E)15U)
#define PesDataId_ETS_ACTIVATION_POS_DN ((PesDataId_E)16U)
#define PesDataId_ETS_ACTIVATION_POS_UP ((PesDataId_E)17U)
#define PesDataId_OS_STOP_DIST_UP      ((PesDataId_E)18U)
#define PesDataId_CRYPTOCHIP_CONFIGURE ((PesDataId_E)257U)
#define PesDataId_CRYPTOCHIP_GENKEY    ((PesDataId_E)258U)
#define PesDataId_CRYPTOCHIP_LOCK_CONFIG ((PesDataId_E)259U)
#define PesDataId_CRYPTOCHIP_LOCK_FINAL ((PesDataId_E)260U)
#define PesDataId_OTP_ACTIVATE         ((PesDataId_E)261U)
#define PesDataId_SET_PCB_MANUFACTURING_DATE_STATUS ((PesDataId_E)519U)
#endif

#ifndef DEFINED_TYPEDEF_FOR_PesRequestSetData_E_
#define DEFINED_TYPEDEF_FOR_PesRequestSetData_E_

typedef enum
{
    PesRequestSetData_SET_PCB_MANUFACTURING_DATE = 7/* Default value */
}
PesRequestSetData_E;

#endif

#ifndef DEFINED_TYPEDEF_FOR_PesDataSetPcbManufacturingDateStatus_E_
#define DEFINED_TYPEDEF_FOR_PesDataSetPcbManufacturingDateStatus_E_

typedef uint16_T PesDataSetPcbManufacturingDateStatus_E;

/* enum PesDataSetPcbManufacturingDateStatus_E */
#define PesDataSetPcbManufacturingDateStatus_SUCCESS ((PesDataSetPcbManufacturingDateStatus_E)0U) /* Default value */
#define PesDataSetPcbManufacturingDateStatus_COMMAND_FAILED ((PesDataSetPcbManufacturingDateStatus_E)1U)
#define PesDataSetPcbManufacturingDateStatus_COMMUNICATION_FAILURE ((PesDataSetPcbManufacturingDateStatus_E)2U)
#endif

/* Block states (default storage) for system '<S2>/BufferOtpWriteReply' */
typedef struct
{
    OtpWritePcbManufacturingDateReply_B UnitDelay2_DSTATE;/* '<S6>/Unit Delay2' */
}
DW_BufferOtpWriteReply_HandlePesRequest_T;

/* Block states (default storage) for system '<S2>/BufferPesData' */
typedef struct
{
    PesDataSetPcbManufacturingDateReceived_B UnitDelay2_DSTATE;/* '<S7>/Unit Delay2' */
}
DW_BufferPesData_HandlePesRequest_T;

/* Block signals for system '<S2>/BuildOtpWriteRequest' */
typedef struct
{
    bool_t SignalConversion;           /* '<S16>/Signal Conversion' */
}
B_BuildOtpWriteRequest_HandlePesRequest_T;

/* Block states (default storage) for system '<S2>/BuildOtpWriteRequest' */
typedef struct
{
    bool_t Delay_DSTATE;               /* '<S16>/Delay' */
}
DW_BuildOtpWriteRequest_HandlePesRequest_T;

/* Block signals for system '<S2>/BuildPesData' */
typedef struct
{
    uint16_T Switch3;                  /* '<S24>/Switch3' */
    PesDataId_E PesDataIdLatched;      /* '<S24>/Switch1' */
    uint8_T Switch2[6];                /* '<S24>/Switch2' */
    uint8_T Index;                     /* '<S25>/Switch' */
    bool_t SignalConversion;           /* '<S28>/Signal Conversion' */
    bool_t SignalConversion_mdcc;      /* '<S32>/Signal Conversion' */
    bool_t SignalConversion_exxk;      /* '<S36>/Signal Conversion' */
    bool_t Out;                        /* '<S35>/Logical Operator3' */
    bool_t SignalConversion4;          /* '<S33>/Signal Conversion4' */
}
B_BuildPesData_HandlePesRequest_T;

/* Block states (default storage) for system '<S2>/BuildPesData' */
typedef struct
{
    uint16_T UnitDelay2_DSTATE;        /* '<S24>/Unit Delay2' */
    PesDataId_E UnitDelay3_DSTATE;     /* '<S24>/Unit Delay3' */
    uint8_T UnitDelay1_DSTATE[6];      /* '<S24>/Unit Delay1' */
    uint8_T UnitDelay_DSTATE;          /* '<S25>/Unit Delay' */
    bool_t Delay_DSTATE;               /* '<S28>/Delay' */
    bool_t UnitDelay_DSTATE_e0nc;      /* '<S22>/Unit Delay' */
    bool_t Delay_DSTATE_ggbo;          /* '<S32>/Delay' */
    bool_t Delay_DSTATE_gedn;          /* '<S36>/Delay' */
    bool_t UnitDelay1_DSTATE_av1i;     /* '<S35>/Unit Delay1' */
}
DW_BuildPesData_HandlePesRequest_T;

/* Block states (default storage) for system '<S2>/CheckNewRequest' */
typedef struct
{
    Timebase_t UnitDelay2_DSTATE;      /* '<S10>/Unit Delay2' */
}
DW_CheckNewRequest_HandlePesRequest_T;

/* Block states (default storage) for system '<S2>/SetPcbManufacturingDateAlgorithm' */
typedef struct
{
    struct
    {
        uint_T is_c3_HandlePesRequest:2;
                                   /* '<S2>/SetPcbManufacturingDateAlgorithm' */
        uint_T is_active_c3_HandlePesRequest:1;
                                   /* '<S2>/SetPcbManufacturingDateAlgorithm' */
    }
    bitsForTID0;
}
DW_SetPcbManufacturingDateAlgorithm_HandlePesRequest_T;

/* Block signals for system '<Root>/HandlePesRequestSetData' */
typedef struct
{
    PesDataSetPcbManufacturingDateReceived_B BufferedPesData;/* '<S7>/Switch' */
    OtpWritePcbManufacturingDateReply_B BufferedOtpWriteReply;/* '<S6>/Switch' */
    Timebase_t BufferedReceptionTimePesRequest;/* '<S10>/Switch' */
    PesDataSetPcbManufacturingDateStatus_E AnswerStatus;
                                   /* '<S2>/SetPcbManufacturingDateAlgorithm' */
    bool_t RequestIsOngoing;       /* '<S2>/SetPcbManufacturingDateAlgorithm' */
    bool_t ReceivePesDataCommand;  /* '<S2>/SetPcbManufacturingDateAlgorithm' */
    bool_t WriteOtpCommand;        /* '<S2>/SetPcbManufacturingDateAlgorithm' */
    bool_t SendAnswerCommand;      /* '<S2>/SetPcbManufacturingDateAlgorithm' */
    B_BuildPesData_HandlePesRequest_T BuildPesData;/* '<S2>/BuildPesData' */
    B_BuildOtpWriteRequest_HandlePesRequest_T BuildOtpWriteRequest;/* '<S2>/BuildOtpWriteRequest' */
}
B_HandlePesRequestSetData_HandlePesRequest_T;

/* Block states (default storage) for system '<Root>/HandlePesRequestSetData' */
typedef struct
{
    bool_t UnitDelay2_DSTATE;          /* '<S2>/Unit Delay2' */
    bool_t UnitDelay_DSTATE;           /* '<S2>/Unit Delay' */
    bool_t UnitDelay1_DSTATE;          /* '<S2>/Unit Delay1' */
    DW_SetPcbManufacturingDateAlgorithm_HandlePesRequest_T
        sf_SetPcbManufacturingDateAlgorithm;
                                   /* '<S2>/SetPcbManufacturingDateAlgorithm' */
    DW_CheckNewRequest_HandlePesRequest_T CheckNewRequest;/* '<S2>/CheckNewRequest' */
    DW_BuildPesData_HandlePesRequest_T BuildPesData;/* '<S2>/BuildPesData' */
    DW_BuildOtpWriteRequest_HandlePesRequest_T BuildOtpWriteRequest;/* '<S2>/BuildOtpWriteRequest' */
    DW_BufferPesData_HandlePesRequest_T BufferPesData;/* '<S2>/BufferPesData' */
    DW_BufferOtpWriteReply_HandlePesRequest_T BufferOtpWriteReply;/* '<S2>/BufferOtpWriteReply' */
}
DW_HandlePesRequestSetData_HandlePesRequest_T;

/* Block signals for model 'HandlePesRequest' */
typedef struct
{
    PesData_C PesDataIn;               /* '<Root>/Signal Conversion' */
    bool_t BusyOld;                    /* '<Root>/Unit Delay' */
    bool_t LogicalOperator;            /* '<Root>/Logical Operator' */
    bool_t IsNewRequestData_hz2s;      /* '<S3>/Logical Operator1' */
    B_HandlePesRequestSetData_HandlePesRequest_T HandlePesRequestSetData;/* '<Root>/HandlePesRequestSetData' */
}
B_HandlePesRequest_caua_T;

/* Block states (default storage) for model 'HandlePesRequest' */
typedef struct
{
    Timebase_t Delay_DSTATE;           /* '<S1>/Delay' */
    bool_t UnitDelay_DSTATE;           /* '<Root>/Unit Delay' */
    MdlrefDW_HandlePesRequestData_T HandlePesRequestDataRef_InstanceData;/* '<Root>/HandlePesRequestDataRef' */
    DW_HandlePesRequestSetData_HandlePesRequest_T HandlePesRequestSetData;/* '<Root>/HandlePesRequestSetData' */
}
DW_HandlePesRequest_fwu4_T;

/* Invariant block signals for system '<S2>/BuildPesData' */
typedef struct
{
    const OpbNodeAddr_E RequesterNodeAddr;/* '<S22>/Signal Conversion10' */
    const uint16_T Length;             /* '<S22>/Signal Conversion2' */
    const uint16_T uint8_boolean;      /* '<S23>/uint8_boolean' */
    const uint16_T MathFunction;       /* '<S23>/Math Function' */
    const PesDataId_E PesDataId;       /* '<S22>/Signal Conversion4' */
    const uint8_T Compare;             /* '<S27>/Compare' */
}
ConstB_BuildPesData_HandlePesRequest_T;

/* Invariant block signals for system '<S2>/CheckPayloadTimeout' */
typedef struct
{
    const uint32_T Add1;               /* '<S11>/Add1' */
    const Timebase_t SignalConversion2;/* '<S58>/Signal Conversion2' */
    const uint32_T SignalConversion1;  /* '<S58>/Signal Conversion1' */
}
ConstB_CheckPayloadTimeout_HandlePesRequest_T;

/* Invariant block signals for system '<S2>/CheckWriteTimeout' */
typedef struct
{
    const Timebase_t SignalConversion2;/* '<S60>/Signal Conversion2' */
    const uint32_T SignalConversion1;  /* '<S60>/Signal Conversion1' */
}
ConstB_CheckWriteTimeout_HandlePesRequest_T;

/* Invariant block signals for system '<Root>/HandlePesRequestSetData' */
typedef struct
{
    ConstB_CheckWriteTimeout_HandlePesRequest_T CheckWriteTimeout;/* '<S2>/CheckWriteTimeout' */
    ConstB_CheckPayloadTimeout_HandlePesRequest_T CheckPayloadTimeout;/* '<S2>/CheckPayloadTimeout' */
    ConstB_BuildPesData_HandlePesRequest_T BuildPesData;/* '<S2>/BuildPesData' */
}
ConstB_HandlePesRequestSetData_HandlePesRequest_T;

/* Invariant block signals for model 'HandlePesRequest' */
typedef struct
{
    ConstB_HandlePesRequestSetData_HandlePesRequest_T HandlePesRequestSetData;/* '<Root>/HandlePesRequestSetData' */
}
ConstB_HandlePesRequest_hb4t_T;

/* Constant parameters (default storage) */
typedef struct
{
    /* Computed Parameter: Unused2_Value
     * Referenced by: '<Root>/Unused2'
     */
    PesData_C Unused2_Value;
}
ConstP_HandlePesRequest_T;

typedef struct
{
    B_HandlePesRequest_caua_T rtb;
    DW_HandlePesRequest_fwu4_T rtdw;
}
MdlrefDW_HandlePesRequest_T;

/* Constant parameters (default storage) */
extern const ConstP_HandlePesRequest_T HandlePesRequest_ConstP;
extern const ConstB_HandlePesRequest_hb4t_T HandlePesRequest_ConstB;

/* Model reference registration function */
extern void HandlePesRequest_initialize(B_HandlePesRequest_caua_T *localB,
    DW_HandlePesRequest_fwu4_T *localDW);
extern const PesData_C HandlePesRequest_rtZPesData_C;/* PesData_C ground */
extern void HandlePesRequest_BufferOtpWriteReply_Update
    (OtpWritePcbManufacturingDateReply_B *rty_BufferedOtpWriteReply,
     DW_BufferOtpWriteReply_HandlePesRequest_T *localDW);
extern void HandlePesRequest_BufferOtpWriteReply(const
    OtpWritePcbManufacturingDateReply_B *rtu_OtpWritePcbManufacturingDateReply,
    bool_t rtu_WriteOtpCommandOld, bool_t *rty_ReceivedOtpWriteReply,
    OtpWritePcbManufacturingDateReply_B *rty_BufferedOtpWriteReply,
    DW_BufferOtpWriteReply_HandlePesRequest_T *localDW);
extern void HandlePesRequest_BufferPesData_Update
    (PesDataSetPcbManufacturingDateReceived_B *rty_BufferedPesData,
     DW_BufferPesData_HandlePesRequest_T *localDW);
extern void HandlePesRequest_BufferPesData(const
    PesDataSetPcbManufacturingDateReceived_B
    *rtu_SetPcbManufacturingDateFromConfigurationMaster, bool_t
    rtu_ReceivePesDataCommandOld, bool_t *rty_ReceivedPesData,
    PesDataSetPcbManufacturingDateReceived_B *rty_BufferedPesData,
    DW_BufferPesData_HandlePesRequest_T *localDW);
extern void HandlePesRequest_BuildOtpWriteRequest_Update
    (B_BuildOtpWriteRequest_HandlePesRequest_T *localB,
     DW_BuildOtpWriteRequest_HandlePesRequest_T *localDW);
extern void HandlePesRequest_BuildOtpWriteRequest(bool_t rtu_WriteOtpCommand,
    const PesDataSetPcbManufacturingDateReceived_B *rtu_PesDataBuffered,
    OtpWritePcbManufacturingDate_B *rty_OtpWritePcbManufacturingDate,
    B_BuildOtpWriteRequest_HandlePesRequest_T *localB,
    DW_BuildOtpWriteRequest_HandlePesRequest_T *localDW);
extern void HandlePesRequest_BuildPesData_Init
    (DW_BuildPesData_HandlePesRequest_T *localDW);
extern void HandlePesRequest_BuildPesData_Update
    (B_BuildPesData_HandlePesRequest_T *localB,
     DW_BuildPesData_HandlePesRequest_T *localDW);
extern void HandlePesRequest_BuildPesData(bool_t rtu_SendAnswer,
    PesDataSetPcbManufacturingDateStatus_E rtu_AnswerStatus, const PesData_C
    *rtu_PesDataIn, bool_t rtu_BusyOld, PesData_C *rty_PesData, bool_t
    *rty_BusySetData, B_BuildPesData_HandlePesRequest_T *localB, const
    ConstB_BuildPesData_HandlePesRequest_T *localC,
    DW_BuildPesData_HandlePesRequest_T *localDW);
extern void HandlePesRequest_CheckNewRequest_Update(Timebase_t
    *rty_BufferedReceptionTimePesRequest, DW_CheckNewRequest_HandlePesRequest_T *
    localDW);
extern void HandlePesRequest_CheckNewRequest(bool_t rtu_IsNewRequestSetData,
    uint16_T rtu_Parameter, bool_t rtu_RequestIsOngoingOld, Timebase_t
    rtu_ReceptionTimeStampPesRequest, bool_t *rty_NewRequest, Timebase_t
    *rty_BufferedReceptionTimePesRequest, DW_CheckNewRequest_HandlePesRequest_T *
    localDW);
extern void HandlePesRequest_MsToTimebase(Timebase_t rtu_base, uint32_T *rty_ms);
extern bool_t HandlePesRequest_CheckPayloadTimeout(Timebase_t rtu_Timestamp,
    Timebase_t rtu_BufferedReceptionTimePesRequest, const
    ConstB_CheckPayloadTimeout_HandlePesRequest_T *localC);
extern bool_t HandlePesRequest_CheckWriteTimeout(Timebase_t rtu_Timestamp, const
    PesDataSetPcbManufacturingDateReceived_B *rtu_BufferedPesData, const
    ConstB_CheckWriteTimeout_HandlePesRequest_T *localC);
extern void HandlePesRequest_SetPcbManufacturingDateAlgorithm(bool_t
    rtu_NewRequest, bool_t rtu_PesDataTimeout, bool_t rtu_ReceivedReply, const
    OtpWritePcbManufacturingDateReply_B *rtu_BufferedOtpWriteReply, bool_t
    rtu_ReceivedPesData, bool_t rtu_WriteTimeout, bool_t *rty_RequestIsOngoing,
    bool_t *rty_ReceivePesDataCommand, bool_t *rty_WriteOtpCommand, bool_t
    *rty_SendAnswerCommand, PesDataSetPcbManufacturingDateStatus_E
    *rty_AnswerStatus, DW_SetPcbManufacturingDateAlgorithm_HandlePesRequest_T
    *localDW);
extern void HandlePesRequest_HandlePesRequestSetData_Init(bool_t
    *rty_waitForPesDataSetPcbManufacturingDateFromConfigurationMaste,
    B_HandlePesRequestSetData_HandlePesRequest_T *localB,
    DW_HandlePesRequestSetData_HandlePesRequest_T *localDW);
extern void HandlePesRequest_HandlePesRequestSetData_Update
    (B_HandlePesRequestSetData_HandlePesRequest_T *localB,
     DW_HandlePesRequestSetData_HandlePesRequest_T *localDW);
extern void HandlePesRequest_HandlePesRequestSetData(const
    OtpWritePcbManufacturingDateReply_B *rtu_OtpWritePcbManufacturingDateReply,
    Timebase_t rtu_Timebase, const PesDataSetPcbManufacturingDateReceived_B
    *rtu_SetPcbManufacturingDateFromConfigurationMaster, Timebase_t
    rtu_ReceptionTimeStampPesRequest, bool_t rtu_IsNewRequestSetData, uint16_T
    rtu_Parameter, bool_t rtu_BusyOld, const PesData_C *rtu_PesDataIn, PesData_C
    *rty_PesData, bool_t *rty_BusySetData, OtpWritePcbManufacturingDate_B
    *rty_OtpWritePcbManufacturingDate, bool_t
    *rty_waitForPesDataSetPcbManufacturingDateFromConfigurationMaste,
    B_HandlePesRequestSetData_HandlePesRequest_T *localB, const
    ConstB_HandlePesRequestSetData_HandlePesRequest_T *localC,
    DW_HandlePesRequestSetData_HandlePesRequest_T *localDW);
extern void HandlePesRequest_IsNewRequestData(const PesRequestNew_C
    *rtu_PesRequest, bool_t rtu_IsNewReception, bool_t *rty_IsNewRequestData);
extern bool_t HandlePesRequest_IsNewRequestSetData(const PesRequestNew_C
    *rtu_PesRequest, bool_t rtu_IsNewReception);
extern void HandlePesRequest_Init(bool_t
    *rty_waitForPesDataSetPcbManufacturingDateFromConfigurationMaste,
    B_HandlePesRequest_caua_T *localB, DW_HandlePesRequest_fwu4_T *localDW);
extern void HandlePesRequest_Update(const PesRequestNew_C *rtu_PesRequest,
    B_HandlePesRequest_caua_T *localB, DW_HandlePesRequest_fwu4_T *localDW);
extern void HandlePesRequest(const PesRequestNew_C *rtu_PesRequest, const
    PesDataSetPcbManufacturingDateReceived_B
    *rtu_SetPcbManufacturingDateFromConfigurationMaster, const PcbInfo_B
    *rtu_PcbInfo, const OtpWritePcbManufacturingDateReply_B
    *rtu_OtpWritePcbManufacturingDateReply, Timebase_t rtu_Timebase, PesData_C
    *rty_PesData, SecurityRequestCryptoChipConfigure_B
    *rty_SecurityRequestCryptoChipConfigure,
    SecurityRequestCryptoChipCreateKey_B *rty_SecurityRequestCryptoChipCreateKey,
    SecurityRequestCryptoChipLockConfig_B
    *rty_SecurityRequestCryptoChipLockConfig, SecurityRequestOtpActivate_B
    *rty_SecurityRequestOtpActivate, OtpWritePcbManufacturingDate_B
    *rty_OtpWritePcbManufacturingDate, bool_t
    *rty_waitForPesDataSetPcbManufacturingDateFromConfigurationMaste,
    B_HandlePesRequest_caua_T *localB, DW_HandlePesRequest_fwu4_T *localDW);

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'HandlePesRequest'
 * '<S1>'   : 'HandlePesRequest/AnyChange'
 * '<S2>'   : 'HandlePesRequest/HandlePesRequestSetData'
 * '<S3>'   : 'HandlePesRequest/IsNewRequestData'
 * '<S4>'   : 'HandlePesRequest/IsNewRequestSecurity'
 * '<S5>'   : 'HandlePesRequest/IsNewRequestSetData'
 * '<S6>'   : 'HandlePesRequest/HandlePesRequestSetData/BufferOtpWriteReply'
 * '<S7>'   : 'HandlePesRequest/HandlePesRequestSetData/BufferPesData'
 * '<S8>'   : 'HandlePesRequest/HandlePesRequestSetData/BuildOtpWriteRequest'
 * '<S9>'   : 'HandlePesRequest/HandlePesRequestSetData/BuildPesData'
 * '<S10>'  : 'HandlePesRequest/HandlePesRequestSetData/CheckNewRequest'
 * '<S11>'  : 'HandlePesRequest/HandlePesRequestSetData/CheckPayloadTimeout'
 * '<S12>'  : 'HandlePesRequest/HandlePesRequestSetData/CheckWriteTimeout'
 * '<S13>'  : 'HandlePesRequest/HandlePesRequestSetData/SetPcbManufacturingDateAlgorithm'
 * '<S14>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildOtpWriteRequest/Bit Shift'
 * '<S15>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildOtpWriteRequest/Bit Shift1'
 * '<S16>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildOtpWriteRequest/RisingEdge'
 * '<S17>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildOtpWriteRequest/Bit Shift/bit_shift'
 * '<S18>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildOtpWriteRequest/Bit Shift1/bit_shift'
 * '<S19>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildOtpWriteRequest/RisingEdge/Compare To Constant'
 * '<S20>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildPesData/Enumerated Constant'
 * '<S21>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildPesData/Enumerated Constant2'
 * '<S22>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildPesData/SendPesData'
 * '<S23>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildPesData/SendPesData/CheckSend'
 * '<S24>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildPesData/SendPesData/Latch'
 * '<S25>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildPesData/SendPesData/Sequencer'
 * '<S26>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildPesData/SendPesData/SetHeader'
 * '<S27>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildPesData/SendPesData/CheckSend/Logic  Value1'
 * '<S28>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildPesData/SendPesData/CheckSend/RisingEdge'
 * '<S29>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildPesData/SendPesData/CheckSend/RisingEdge/Compare To Constant'
 * '<S30>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildPesData/SendPesData/Sequencer/CheckBusyWithPayload'
 * '<S31>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildPesData/SendPesData/Sequencer/CheckFinishedSendingPayload'
 * '<S32>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildPesData/SendPesData/Sequencer/FallingEdge'
 * '<S33>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildPesData/SendPesData/Sequencer/ToDo'
 * '<S34>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildPesData/SendPesData/Sequencer/UpdateIndex'
 * '<S35>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildPesData/SendPesData/Sequencer/CheckBusyWithPayload/LatchTrueUntilReset'
 * '<S36>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildPesData/SendPesData/Sequencer/CheckBusyWithPayload/RisingEdge'
 * '<S37>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildPesData/SendPesData/Sequencer/CheckBusyWithPayload/RisingEdge/Compare To Constant'
 * '<S38>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildPesData/SendPesData/Sequencer/FallingEdge/Compare To Constant'
 * '<S39>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildPesData/SendPesData/SetHeader/CalculateCrc32'
 * '<S40>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildPesData/SendPesData/SetHeader/GetUint16Bytes'
 * '<S41>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildPesData/SendPesData/SetHeader/GetUint32Bytes'
 * '<S42>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildPesData/SendPesData/SetHeader/CalculateCrc32/MatlabFunctionCall'
 * '<S43>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildPesData/SendPesData/SetHeader/GetUint16Bytes/Uint16to2Uint8'
 * '<S44>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildPesData/SendPesData/SetHeader/GetUint16Bytes/Uint16to2Uint8/Bit Shift1'
 * '<S45>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildPesData/SendPesData/SetHeader/GetUint16Bytes/Uint16to2Uint8/Bit Shift2'
 * '<S46>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildPesData/SendPesData/SetHeader/GetUint16Bytes/Uint16to2Uint8/Bit Shift1/bit_shift'
 * '<S47>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildPesData/SendPesData/SetHeader/GetUint16Bytes/Uint16to2Uint8/Bit Shift2/bit_shift'
 * '<S48>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildPesData/SendPesData/SetHeader/GetUint32Bytes/Uint32to4Uint8'
 * '<S49>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildPesData/SendPesData/SetHeader/GetUint32Bytes/Uint32to4Uint8/Bit Shift1'
 * '<S50>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildPesData/SendPesData/SetHeader/GetUint32Bytes/Uint32to4Uint8/Bit Shift2'
 * '<S51>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildPesData/SendPesData/SetHeader/GetUint32Bytes/Uint32to4Uint8/Bit Shift3'
 * '<S52>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildPesData/SendPesData/SetHeader/GetUint32Bytes/Uint32to4Uint8/Bit Shift4'
 * '<S53>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildPesData/SendPesData/SetHeader/GetUint32Bytes/Uint32to4Uint8/Bit Shift1/bit_shift'
 * '<S54>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildPesData/SendPesData/SetHeader/GetUint32Bytes/Uint32to4Uint8/Bit Shift2/bit_shift'
 * '<S55>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildPesData/SendPesData/SetHeader/GetUint32Bytes/Uint32to4Uint8/Bit Shift3/bit_shift'
 * '<S56>'  : 'HandlePesRequest/HandlePesRequestSetData/BuildPesData/SendPesData/SetHeader/GetUint32Bytes/Uint32to4Uint8/Bit Shift4/bit_shift'
 * '<S57>'  : 'HandlePesRequest/HandlePesRequestSetData/CheckNewRequest/Enumerated Constant1'
 * '<S58>'  : 'HandlePesRequest/HandlePesRequestSetData/CheckPayloadTimeout/MsToTimebase'
 * '<S59>'  : 'HandlePesRequest/HandlePesRequestSetData/CheckPayloadTimeout/MsToTimebase/MsToTimebase'
 * '<S60>'  : 'HandlePesRequest/HandlePesRequestSetData/CheckWriteTimeout/MsToTimebase'
 * '<S61>'  : 'HandlePesRequest/HandlePesRequestSetData/CheckWriteTimeout/MsToTimebase/MsToTimebase'
 * '<S62>'  : 'HandlePesRequest/IsNewRequestData/Enumerated Constant'
 * '<S63>'  : 'HandlePesRequest/IsNewRequestSetData/Enumerated Constant'
 * '<S64>'  : 'HandlePesRequest/IsNewRequestSetData/Enumerated Constant1'
 */

/*-
 * Requirements for '<Root>': HandlePesRequest
 */
#endif                                 /* RTW_HEADER_HandlePesRequest_h_ */

#ifndef DEF_H
#define DEF_H
#define ABC 1

#endif
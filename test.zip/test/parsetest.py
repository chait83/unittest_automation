import json

if __name__ == "__main__":
    f = open("temp.json")
    data = json.load(f)
    parse = data["ext"]
    for func in parse:
        if func["_nodetype"] != 'FuncDef':
            continue
        if not func["decl"]["type"]["args"]:
            continue
        params = func["decl"]["type"]["args"]["params"]
        for param in params:
            if param["type"]["type"]["_nodetype"] == 'TypeDecl':
                print("Name: %s, type: %s "%(param["name"], param["type"]["type"]["type"]["names"]))
            elif param["type"]["type"]["_nodetype"] =='IdentifierType':
                print("Name: %s, type: %s " % (param["name"], param["type"]["type"]["names"]))

import os


def list_c_files(directory):
    """List all C files in a directory, recursively."""
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.endswith(".c"):
                yield os.path.join(root, file)


if __name__ == "__main__":
    directory = "."
    for file in list_c_files(directory):
        print(file)

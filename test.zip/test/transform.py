import lxml.etree as ET


dom = ET.parse("test.xml")
xslt = ET.parse("temp.xslt")
transform = ET.XSLT(xslt)
newdom = transform(dom)
print(ET.tostring(newdom))


int main(){
	printf("hello world");
	return 0;
}

void a(int *inp1, float inp2){
    int i = *inp1;
    int j=inp2;
    if (i > 0 ){
        print("a");
    }
}
void b(char c){
}

#!/bin/bash

# Get the filename from the parameter
filename=$1
dir=$2
# Check if the file exists
cd template
echo -e "\033[32mNow generating the test cases\033[0m"
# Transform the XML based code to actual test case using the XSLT template
java TestMain


tail -n +2 output.txt > $filename

echo -e "\033[32mTest cases generated successfully, now deleting old build\033[0m"
cd $dir
rm -rf build

echo -e "\033[32mRunning test cases\033[0m"

make coverage

echo -e "\033[32mCoverage report is ready\033[0m"

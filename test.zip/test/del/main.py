import json
import sys
import os
import argparse
from ParserFactory import ParserFactory
import subprocess


def validate_args():
    """Validate the system arguments."""
    parser = argparse.ArgumentParser()
    parser.add_argument("-type", help="The type of file to compile.")
    parser.add_argument("-src", help="The path to the source file.")
    parser.add_argument("-dest", help="The path to the destination file.")
    args = parser.parse_args()

    if not args.type:
        parser.error("Please specify the type Code to compile.")
    elif not args.src:
        parser.error("Please specify the path to the source folder.")
    elif not args.dest:
        parser.error("Please specify the path to the destination folder.")

    return args


def list_files(dir, filter):
    op_files = []
    for root, dirs, files in os.walk(dir):
        for file in files:
            if file.endswith(filter):
                op_files.append(os.path.join(root, file))
    return op_files


def create_directory(directory_name):
    """Create a directory."""
    if not os.path.exists(directory_name):
        os.mkdir(directory_name)


def execute_bash_script(script_path, arguments):
    """Execute a bash script."""
    process = subprocess.Popen(["bash", script_path] + arguments)
    process.wait()


def get_func_det(data):
    # print(data)
    parse = data["ext"]
    str_data = "<code>"
    try:
        for func in parse:
            if func["_nodetype"] != 'FuncDef':
                continue
            str_data = str_data + "<func><name>" + func["decl"]["name"] + "</name>"
            if func["decl"]["name"] == "response_exception":
                a = 1
            if not func["decl"]["type"]["args"]:
                str_data = str_data + "<params><p><t> </t><n> </n></p></params></func>"
                continue
            params = func["decl"]["type"]["args"]["params"]

            str_data = str_data + "<params>"
            for param in params:
                str_data = str_data + "<p>"
                if param["_nodetype"] == 'EllipsisParam':
                    str_data = str_data + "</p>"
                    continue
                elif param["type"]["_nodetype"] == 'PtrDecl':
                    str_data = str_data + "<pt>1</pt>"
                else:
                    str_data = str_data + "<pt>0</pt>"

                if param["type"]["type"]["_nodetype"] == 'TypeDecl':
                    type = " ".join(param["type"]["type"]["type"]["names"])
                    str_data = str_data + ("<n>%s </n> <t>%s </t>" % (param["name"], type))
                elif param["type"]["type"]["_nodetype"] == 'IdentifierType':
                    type = " ".join(param["type"]["type"]["names"])
                    str_data = str_data + ("<n>%s </n> <t>%s </t>" % (param["name"], type))
                str_data = str_data + "</p>"

            str_data = str_data + "</params></func>"
    except Exception as ex:
        print(ex)
    finally:
        str_data = str_data + "</code>"
        return str_data


if __name__ == "__main__":
    # First list all the files in the folder.
    args = validate_args()
    print("Type:", args.type)
    print("Source:", args.src)
    print("Destination:", args.dest)
    src = args.src
    c_files = []
    h_file = []

    # Now get the list of file
    c_files = list_files(args.src, ".c")
    h_files = list_files(args.src, ".h")

    # Now get the parser for the given data type
    factory = ParserFactory()
    parser = factory.get_parser(args.type)

    gen_dir = os.path.join(src, "gen_dir")
    create_directory(gen_dir)
    # Parse the code.
    json_data = parser.parse_code("/home/ubuntu/hackathon/libmodbus/src/modbus.c")
    data = json.loads(json_data)
    # json_file = os.path.join(gen_dir, 'parse.json')
    # f = open(json_file,"w")
    # f.write(json_data)
    # f.close()
    # f = open(json_file, "r")
    # # f = open("/home/ubuntu/hackathon/test/temp.json", "r")
    # data = json.load(f)

    op = get_func_det(data)
    f = open("/home/ubuntu/hackathon/test/del/template/test.xml","w")
    f.write(op)
    f.close()
    script_path = "./transform.sh"
    arguments = ["/home/ubuntu/hackathon/test/del/project/test/test_modbus.c", "/home/ubuntu/hackathon/test/del/project/"]
    execute_bash_script(script_path, arguments)

    # print(op)
    a = 1

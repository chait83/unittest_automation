from abc import ABC, abstractmethod


class AbsParser(ABC):
    @abstractmethod
    def parse_code(self, file_name):
        pass


class AbsFactoryParser(ABC):
    @abstractmethod
    def get_parser(self, type):
        pass

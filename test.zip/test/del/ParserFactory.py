import argparse
from AbsFactoryParser import AbsFactoryParser
from CParser import CParser


class ParserFactory(AbsFactoryParser):
    """Parser factory class that creates objects based on command arguments."""

    def __init__(self):
        """Initialize the factory class."""

    pass

    def get_parser(self, type):
        """Create an object based on the command arguments."""

        if type == "C":
            return CParser()

        else:
            raise ValueError("Unknown object type: {}".format(type))

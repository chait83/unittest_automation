
void a(int inp1, float inp2){
    int i =inp1;
    int j=inp2;
    if (i > 0 ){
        j=2;
    }
}

void b(char c){

}

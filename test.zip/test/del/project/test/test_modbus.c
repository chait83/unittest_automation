#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>
#include "modbus.h"
#include "modbus-private.h"


static void test_modbus_strerror(void **state){
    int errnum ;
    modbus_strerror( errnum );
}

static void test__sleep_response_timeout(void **state){
    modbus_t ctx ;
    _sleep_response_timeout( &ctx );
}

static void test_modbus_flush(void **state){
    modbus_t ctx ;
    modbus_flush( &ctx );
}

static void test_compute_response_length_from_request(void **state){
    modbus_t ctx ;
    uint8_t req ;
    compute_response_length_from_request( &ctx ,&req );
}

static void test_send_msg(void **state){
    modbus_t ctx ;
    uint8_t msg ;
    int msg_length ;
    send_msg( &ctx ,&msg ,msg_length );
}

static void test_modbus_send_raw_request(void **state){
    modbus_t ctx ;
    uint8_t raw_req ;
    int raw_req_length ;
    modbus_send_raw_request( &ctx ,&raw_req ,raw_req_length );
}

static void test_compute_meta_length_after_function(void **state){
    int function ;
    msg_type_t msg_type ;
    compute_meta_length_after_function( function ,msg_type );
}

static void test_compute_data_length_after_meta(void **state){
    modbus_t ctx ;
    uint8_t msg ;
    msg_type_t msg_type ;
    compute_data_length_after_meta( &ctx ,&msg ,msg_type );
}

static void test__modbus_receive_msg(void **state){
    modbus_t ctx ;
    uint8_t msg ;
    msg_type_t msg_type ;
    _modbus_receive_msg( &ctx ,&msg ,msg_type );
}

static void test_modbus_receive(void **state){
    modbus_t ctx ;
    uint8_t req ;
    modbus_receive( &ctx ,&req );
}

static void test_modbus_receive_confirmation(void **state){
    modbus_t ctx ;
    uint8_t rsp ;
    modbus_receive_confirmation( &ctx ,&rsp );
}

static void test_check_confirmation(void **state){
    modbus_t ctx ;
    uint8_t req ;
    uint8_t rsp ;
    int rsp_length ;
    check_confirmation( &ctx ,&req ,&rsp ,rsp_length );
}

static void test_response_io_status(void **state){
    uint8_t tab_io_status ;
    int address ;
    int nb ;
    uint8_t rsp ;
    int offset ;
    response_io_status( &tab_io_status ,address ,nb ,&rsp ,offset );
}

static void test_modbus_reply(void **state){
    modbus_t ctx ;
    uint8_t req ;
    int req_length ;
    modbus_mapping_t mb_mapping ;
    modbus_reply( &ctx ,&req ,req_length ,&mb_mapping );
}

static void test_modbus_reply_exception(void **state){
    modbus_t ctx ;
    uint8_t req ;
    unsigned int exception_code ;
    modbus_reply_exception( &ctx ,&req ,exception_code );
}

static void test_read_io_status(void **state){
    modbus_t ctx ;
    int function ;
    int addr ;
    int nb ;
    uint8_t dest ;
    read_io_status( &ctx ,function ,addr ,nb ,&dest );
}

static void test_modbus_read_bits(void **state){
    modbus_t ctx ;
    int addr ;
    int nb ;
    uint8_t dest ;
    modbus_read_bits( &ctx ,addr ,nb ,&dest );
}

static void test_modbus_read_input_bits(void **state){
    modbus_t ctx ;
    int addr ;
    int nb ;
    uint8_t dest ;
    modbus_read_input_bits( &ctx ,addr ,nb ,&dest );
}

static void test_read_registers(void **state){
    modbus_t ctx ;
    int function ;
    int addr ;
    int nb ;
    uint16_t dest ;
    read_registers( &ctx ,function ,addr ,nb ,&dest );
}

static void test_modbus_read_registers(void **state){
    modbus_t ctx ;
    int addr ;
    int nb ;
    uint16_t dest ;
    modbus_read_registers( &ctx ,addr ,nb ,&dest );
}

static void test_modbus_read_input_registers(void **state){
    modbus_t ctx ;
    int addr ;
    int nb ;
    uint16_t dest ;
    modbus_read_input_registers( &ctx ,addr ,nb ,&dest );
}

static void test_write_single(void **state){
    modbus_t ctx ;
    int function ;
    int addr ;
    uint16_t value ;
    write_single( &ctx ,function ,addr ,value );
}

static void test_modbus_write_bit(void **state){
    modbus_t ctx ;
    int addr ;
    int status ;
    modbus_write_bit( &ctx ,addr ,status );
}

static void test_modbus_write_register(void **state){
    modbus_t ctx ;
    int addr ;
    uint16_t value ;
    modbus_write_register( &ctx ,addr ,value );
}

static void test_modbus_write_bits(void **state){
    modbus_t ctx ;
    int addr ;
    int nb ;
    uint8_t src ;
    modbus_write_bits( &ctx ,addr ,nb ,&src );
}

static void test_modbus_write_registers(void **state){
    modbus_t ctx ;
    int addr ;
    int nb ;
    uint16_t src ;
    modbus_write_registers( &ctx ,addr ,nb ,&src );
}

static void test_modbus_mask_write_register(void **state){
    modbus_t ctx ;
    int addr ;
    uint16_t and_mask ;
    uint16_t or_mask ;
    modbus_mask_write_register( &ctx ,addr ,and_mask ,or_mask );
}

static void test_modbus_write_and_read_registers(void **state){
    modbus_t ctx ;
    int write_addr ;
    int write_nb ;
    uint16_t src ;
    int read_addr ;
    int read_nb ;
    uint16_t dest ;
    modbus_write_and_read_registers( &ctx ,write_addr ,write_nb ,&src ,read_addr ,read_nb ,&dest );
}

static void test_modbus_report_slave_id(void **state){
    modbus_t ctx ;
    int max_dest ;
    uint8_t dest ;
    modbus_report_slave_id( &ctx ,max_dest ,&dest );
}

static void test__modbus_init_common(void **state){
    modbus_t ctx ;
    _modbus_init_common( &ctx );
}

static void test_modbus_set_slave(void **state){
    modbus_t ctx ;
    int slave ;
    modbus_set_slave( &ctx ,slave );
}

static void test_modbus_get_slave(void **state){
    modbus_t ctx ;
    modbus_get_slave( &ctx );
}

static void test_modbus_set_error_recovery(void **state){
    modbus_t ctx ;
    modbus_error_recovery_mode error_recovery ;
    modbus_set_error_recovery( &ctx ,error_recovery );
}

static void test_modbus_set_socket(void **state){
    modbus_t ctx ;
    int s ;
    modbus_set_socket( &ctx ,s );
}

static void test_modbus_get_socket(void **state){
    modbus_t ctx ;
    modbus_get_socket( &ctx );
}

static void test_modbus_get_response_timeout(void **state){
    modbus_t ctx ;
    uint32_t to_sec ;
    uint32_t to_usec ;
    modbus_get_response_timeout( &ctx ,&to_sec ,&to_usec );
}

static void test_modbus_set_response_timeout(void **state){
    modbus_t ctx ;
    uint32_t to_sec ;
    uint32_t to_usec ;
    modbus_set_response_timeout( &ctx ,to_sec ,to_usec );
}

static void test_modbus_get_byte_timeout(void **state){
    modbus_t ctx ;
    uint32_t to_sec ;
    uint32_t to_usec ;
    modbus_get_byte_timeout( &ctx ,&to_sec ,&to_usec );
}

static void test_modbus_set_byte_timeout(void **state){
    modbus_t ctx ;
    uint32_t to_sec ;
    uint32_t to_usec ;
    modbus_set_byte_timeout( &ctx ,to_sec ,to_usec );
}

static void test_modbus_get_indication_timeout(void **state){
    modbus_t ctx ;
    uint32_t to_sec ;
    uint32_t to_usec ;
    modbus_get_indication_timeout( &ctx ,&to_sec ,&to_usec );
}

static void test_modbus_set_indication_timeout(void **state){
    modbus_t ctx ;
    uint32_t to_sec ;
    uint32_t to_usec ;
    modbus_set_indication_timeout( &ctx ,to_sec ,to_usec );
}

static void test_modbus_get_header_length(void **state){
    modbus_t ctx ;
    modbus_get_header_length( &ctx );
}

static void test_modbus_enable_quirks(void **state){
    modbus_t ctx ;
    unsigned int quirks_mask ;
    modbus_enable_quirks( &ctx ,quirks_mask );
}

static void test_modbus_disable_quirks(void **state){
    modbus_t ctx ;
    unsigned int quirks_mask ;
    modbus_disable_quirks( &ctx ,quirks_mask );
}

static void test_modbus_connect(void **state){
    modbus_t ctx ;
    modbus_connect( &ctx );
}

static void test_modbus_close(void **state){
    modbus_t ctx ;
    modbus_close( &ctx );
}

static void test_modbus_free(void **state){
    modbus_t ctx ;
    modbus_free( &ctx );
}

static void test_modbus_set_debug(void **state){
    modbus_t ctx ;
    int flag ;
    modbus_set_debug( &ctx ,flag );
}

static void test_modbus_mapping_new_start_address(void **state){
    unsigned int start_bits ;
    unsigned int nb_bits ;
    unsigned int start_input_bits ;
    unsigned int nb_input_bits ;
    unsigned int start_registers ;
    unsigned int nb_registers ;
    unsigned int start_input_registers ;
    unsigned int nb_input_registers ;
    modbus_mapping_new_start_address( start_bits ,nb_bits ,start_input_bits ,nb_input_bits ,start_registers ,nb_registers ,start_input_registers ,nb_input_registers );
}

static void test_modbus_mapping_new(void **state){
    int nb_bits ;
    int nb_input_bits ;
    int nb_registers ;
    int nb_input_registers ;
    modbus_mapping_new( nb_bits ,nb_input_bits ,nb_registers ,nb_input_registers );
}

int main(void) {
    const struct CMUnitTest tests[] = {
        
        cmocka_unit_test(test_modbus_strerror),
        cmocka_unit_test(test__sleep_response_timeout),
        cmocka_unit_test(test_modbus_flush),
        cmocka_unit_test(test_compute_response_length_from_request),
        cmocka_unit_test(test_send_msg),
        cmocka_unit_test(test_modbus_send_raw_request),
        cmocka_unit_test(test_compute_meta_length_after_function),
        cmocka_unit_test(test_compute_data_length_after_meta),
        cmocka_unit_test(test__modbus_receive_msg),
        cmocka_unit_test(test_modbus_receive),
        cmocka_unit_test(test_modbus_receive_confirmation),
        cmocka_unit_test(test_check_confirmation),
        cmocka_unit_test(test_response_io_status),
        cmocka_unit_test(test_modbus_reply),
        cmocka_unit_test(test_modbus_reply_exception),
        cmocka_unit_test(test_read_io_status),
        cmocka_unit_test(test_modbus_read_bits),
        cmocka_unit_test(test_modbus_read_input_bits),
        cmocka_unit_test(test_read_registers),
        cmocka_unit_test(test_modbus_read_registers),
        cmocka_unit_test(test_modbus_read_input_registers),
        cmocka_unit_test(test_write_single),
        cmocka_unit_test(test_modbus_write_bit),
        cmocka_unit_test(test_modbus_write_register),
        cmocka_unit_test(test_modbus_write_bits),
        cmocka_unit_test(test_modbus_write_registers),
        cmocka_unit_test(test_modbus_mask_write_register),
        cmocka_unit_test(test_modbus_write_and_read_registers),
        cmocka_unit_test(test_modbus_report_slave_id),
        cmocka_unit_test(test__modbus_init_common),
        cmocka_unit_test(test_modbus_set_slave),
        cmocka_unit_test(test_modbus_get_slave),
        cmocka_unit_test(test_modbus_set_error_recovery),
        cmocka_unit_test(test_modbus_set_socket),
        cmocka_unit_test(test_modbus_get_socket),
        cmocka_unit_test(test_modbus_get_response_timeout),
        cmocka_unit_test(test_modbus_set_response_timeout),
        cmocka_unit_test(test_modbus_get_byte_timeout),
        cmocka_unit_test(test_modbus_set_byte_timeout),
        cmocka_unit_test(test_modbus_get_indication_timeout),
        cmocka_unit_test(test_modbus_set_indication_timeout),
        cmocka_unit_test(test_modbus_get_header_length),
        cmocka_unit_test(test_modbus_enable_quirks),
        cmocka_unit_test(test_modbus_disable_quirks),
        cmocka_unit_test(test_modbus_connect),
        cmocka_unit_test(test_modbus_close),
        cmocka_unit_test(test_modbus_free),
        cmocka_unit_test(test_modbus_set_debug),
        cmocka_unit_test(test_modbus_mapping_new_start_address),
        cmocka_unit_test(test_modbus_mapping_new),
    };

    return cmocka_run_group_tests(tests, NULL, NULL);
}
    
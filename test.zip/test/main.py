import sys
import json
from CToJson import  CToJSON

def get_func_det(data):
    # print(data)
    parse = data["ext"]
    str_data = "<code>"
    try:
        for func in parse:
            if func["_nodetype"] != 'FuncDef':
                continue
            str_data = str_data + "<func><name>" + func["decl"]["name"] + "</name>"
            if func["decl"]["name"] == "response_exception":
                a = 1
            if not func["decl"]["type"]["args"]:
                str_data = str_data + "<params><p><t> </t><n> </n></p></params></func>"
                continue
            params = func["decl"]["type"]["args"]["params"]

            str_data = str_data + "<params>"
            for param in params:
                str_data = str_data + "<p>"
                if param["_nodetype"] == 'EllipsisParam':
                    str_data = str_data + "</p>"
                    continue
                elif param["type"] ["_nodetype"] == 'PtrDecl':
                    str_data = str_data + "<pt>1</pt>"
                else:
                    str_data = str_data + "<pt>0</pt>"

                if param["type"]["type"]["_nodetype"] == 'TypeDecl':
                    type = " ".join(param["type"]["type"]["type"]["names"])
                    str_data = str_data + ("<n>%s </n> <t>%s </t>" % (param["name"], type))
                elif param["type"]["type"]["_nodetype"] == 'IdentifierType':
                    type = " ".join(param["type"]["type"]["names"])
                    str_data = str_data + ("<n>%s </n> <t>%s </t>" % (param["name"], type))
                str_data = str_data + "</p>"

            str_data = str_data + "</params></func>"
    except Exception as ex:
        print(ex)
    finally:
        str_data = str_data + "</code>"
        return str_data


if __name__ == "__main__":
    objCToJSON = CToJSON()
    fileName = "hello.c"
    if len(sys.argv) > 1:
        fileName = sys.argv[1]

    ast_dict = objCToJSON.file_to_dict(fileName)
    # ast = objCToJSON.from_dict(ast_dict)
    # op = objCToJSON.to_json(ast,sort_keys=True,indent=2)
    # print(op)
    f = open("temp.json","r")
    op = f.read()
    f.close()
    data = json.loads(op)
    op = get_func_det(data)
    print(op)
    # f = open("temp.json", "r")

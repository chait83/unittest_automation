enum NUM{
ONE=1,
THREE=3,
SEVEN=7,
EIGHT,
NINE

};
typedef struct {
    int f ;
    int e ;
    char c;
}a ;

typedef struct  {
    int f ;
    int e ;
    char c;
}b;
typedef struct {
    a f;
    b e;
}hello;
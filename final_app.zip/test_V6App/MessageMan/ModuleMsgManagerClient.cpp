/// @file 
/// *****************************************************************
/// © Honeywell Trendview
/// *****************************************************************
/// @n Module : Module Message Manager (MMM )
/// @n FileName: ModuleMsgManagerClient.cpp
/// @n Desc	: Implementation File for the ModuleMsgManagerClient
///			Class.
///			
/// *****************************************************************
/// @b Revision @b History
/// *****************************************************************
/// $Log[4]:
/// 13	Stability Project 1.8.1.3	7/2/2011 4:58:52 PM	Hemant(HAIL) 
///		Stability Project: Recorder source has been upgraded from IL
///	version of firmware to JF version of firmware.
/// 12	Stability Project 1.8.1.2	7/1/2011 4:38:31 PM	Hemant(HAIL) 
///		Stability Project: Files has been checked in before the merging
///	task. The merging will be done between IL version of firmware and JF
///	version of firmware. 
/// 11	Stability Project 1.8.1.1	3/17/2011 3:20:30 PM	Hemant(HAIL) 
///		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
///	new operator in DEBUG mode only. To detect memory leaks in files, use
///	it in preprocessor definition when in debug mode.
/// 10	Stability Project 1.8.1.0	2/15/2011 3:03:22 PM	Hemant(HAIL) 
///		File updated during Heap Management. Call to the default behaviour
///	of new operator has been commented.
/// $
///
#include "ModuleMsgManagerClient.h"
#include "CircularArrayMsgQueue.h"
QMutex CModuleMsgManagerClient::m_hMsgCompleted;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
//****************************************************************************
/// Module Message Manger Client Constructor 
///
/// @param[in] moduleId - Module Identification Number
///									
//****************************************************************************
CModuleMsgManagerClient::CModuleMsgManagerClient() {
	m_hMessageQueueEventHandler = NULL;
	m_MsgReadStatus = MMMCLIENT_MSG_READ_AND_RELEASED;
	m_ModuleRegistered = FALSE;
	m_pModuleMsgManager = NULL; //CModuleMsgManager::GetHandle(); // Obtain the Instance to the Module Message Manager
} // End of Constructor
//****************************************************************************
/// Module Message Manger Client Destructor									
//****************************************************************************
CModuleMsgManagerClient::~CModuleMsgManagerClient() {
	if (m_hMessageQueueEventHandler != NULL) {
		//No need to close the mutex in Qt
		m_hMessageQueueEventHandler = NULL;
	}
} // End of Destructor
//****************************************************************************
/// Releasing a message from the modules' Message Queue. Must be called after the
/// a pending message in the queue has been read.
///
/// @param - none
///
/// @return whether the message has been released, or a failure condition
///
/// @note Message must be Read before being Released
///
//****************************************************************************
T_MMMCLIENT_RETURN_VALUE CModuleMsgManagerClient::MMMClientRemoveMsg() {
	T_MMMCLIENT_RETURN_VALUE retValue = MMMCLIENT_MESSAGE_NOT_READ; ///< Member Function Return Value 
	CCircularArrayMsgQueue *pOwnMessageQueue = m_pModuleMsgManager->m_pMessageQueue[m_ModuleId];
	if (MMMCLIENT_MSG_READ_NOT_RELEASED == m_MsgReadStatus) {
		// Release Message from the Message Queue
		//
		if (CAMQ_MSG_RELEASED_SUCESSFULLY == pOwnMessageQueue->RemoveMsg()) {
			m_MsgReadStatus = MMMCLIENT_MSG_READ_AND_RELEASED;
			retValue = MMMCLIENT_MESSAGE_RELEASED;
		}
	} // End of If
	return (retValue);
} // End of MMMClientRemoveMsg
//**********************************************************************************
/// Register the module with the Module Message Manager, to allow the module
/// to set-up the way in which it wishes to be informed of new messages, and
/// whether the queue created shall be wrapped or to stop receiving messages
/// when the queue is full. 
///
/// @param[in] 	moduleNotification - Determines whether module will be notified 
///									by an event or thread message, on a message 
///									arriving
/// @param[in]	queueWrap		- Should the queue wrap around once full, 
///									or stop receiving messages
///
/// @return whether the registration process was successful or failed
///
/// @note Must be called to allow the module to receive incoming messages.
///
//**********************************************************************************
T_MMMCLIENT_RETURN_VALUE CModuleMsgManagerClient::MMMClientRegister(T_MODULE_ID moduleId,
		T_MODULE_MSG_NOTIFICATION moduleNotification, T_MODULE_QUEUE_WRAP_STATUS queueWrap) {
	T_MMMCLIENT_RETURN_VALUE retValue = MMMCLIENT_MODULE_ALREADY_REGISTERED; ///< Member Function Return Value 
	wchar_t msgCompletedEventName[MSGCOMPLETEDEVENTNAMESIZE]; ///< Message Completed Event Name
	wchar_t msgMessageQueueEventName[MSGQUEUEEVENTNAMESIZE]; ///< Message Queue Event Name
	m_pModuleMsgManager = CModuleMsgManager::GetHandle(); // Obtain the Instance to the Module Message Manager
	// Ensure the module has not already registered with the Module Message Manager
	//
	if ( FALSE == m_ModuleRegistered) {
		m_ModuleRegistered = TRUE;
#if _MSC_VER < 1400 
		swprintf(msgCompletedEventName, MSGCOMPLETEDEVENTNAMESIZE, L"%s%d", MSGCOMPLETED_EVENTNAME, moduleId);
		swprintf(msgMessageQueueEventName, MSGQUEUEEVENTNAMESIZE, L"%s%d", MSGQUEUE_EVENTNAME, moduleId);
#else
		swprintf(msgCompletedEventName, sizeof(msgCompletedEventName)/sizeof(WCHAR),L"%s%d", MSGCOMPLETED_EVENTNAME, moduleId ); 
		swprintf(msgMessageQueueEventName, sizeof(msgMessageQueueEventName)/sizeof(WCHAR),L"%s%d", MSGQUEUE_EVENTNAME, moduleId ); 
#endif
		// Initialise Member Variables to known values
		//
		m_ModuleId = moduleId;
		/// TODO: CreateEvent find alternative
//		m_hMessageQueueEventHandler = CreateEvent( NULL, TRUE, FALSE, msgMessageQueueEventName );
//		m_hMsgCompleted = CreateEvent( NULL, FALSE, FALSE, msgCompletedEventName );
		///TODO get thread id.
		m_pModuleMsgManager->m_pMessageQueue[m_ModuleId]->RegisterMessageQueue(moduleNotification,
				QThread::currentThreadId(), queueWrap);
		retValue = MMMCLIENT_REGISTRATION_SUCCESSFUL;
	}
	return (retValue);
}		// End of MMMClientRegister
//****************************************************************************
/// Obtain the next avialable message from the modules' own message queue. This
/// shall be called once the module is informed that a message is waiting within
/// its Message Queue. A pointer is returned to the user to allow them to 
/// access the data directly. This is for efficiency purpose, after reading the
/// message the message must be removed from the message queue. 
///
/// @param[in,out] rMsg - Reference to a message, if one is available
///
/// @return whether a message is aviable to be read
///
/// @note Previous message must be removed before reading the next message
///
//****************************************************************************
const CMsgQueueMessage* CModuleMsgManagerClient::MMMClientReadMsg(void) {
	const CMsgQueueMessage *msg = NULL; ///< Pointer to the current message
	// Obtain a pointer to the module Message Queue
	//
	CCircularArrayMsgQueue *pOwnMsgQueue = m_pModuleMsgManager->m_pMessageQueue[m_ModuleId];
	if (MMMCLIENT_MSG_READ_AND_RELEASED == m_MsgReadStatus) {
		msg = pOwnMsgQueue->RetrieveMsg();
		if (NULL != msg) {
			m_MsgReadStatus = MMMCLIENT_MSG_READ_NOT_RELEASED;
		}
	}
	return (msg);
} // End of MMMClientReadMsg
//****************************************************************************
/// Obtain the event handler for the module message queue, this handler can be
/// used within the wait functions provided in CE and VC++. i.e. WaitForSingleObject().
/// Users requesting to be notified by event when a message arrives within its
/// message queue, should check this event handler. 
///
/// @param - None
///
/// @return Return the Event Handler associted with the modules' Message Queue
/// 
//****************************************************************************
HANDLE CModuleMsgManagerClient::GetMessageQueueEventHandler() {
	// Obtain the Event handler associated with the module Message Queue
	//
	return (m_hMessageQueueEventHandler);
} // End of GetMessageQueueEventHandler()
//****************************************************************************
/// Post a message to the message queue as specified by the destinationModule
/// parameter. The function will re-try posting the message, for a specified 
/// amount of time until the message has been added to the message queue. 
/// If after this time the message has not been posted, this is report to the 
/// user.
/// @param[in]	waitForSpaceInQueueInMs - Time to wait for space in the queue 
///										to become available
/// @param[in] 	destinationModule	- Destination Module for the message
/// @param[in] 	sendingModule		- Sending Module
/// @param[in]	messageType			- Type of Message to be posted
/// @param[in] 	datalength			- Size in bytes of the data of the message
/// @param[in]	pData				- Pointer to the Data to be sent with message 
/// 
/// @return whether the message was posted, posted and completed or failure condition
///
//****************************************************************************
T_MMMCLIENT_RETURN_VALUE CModuleMsgManagerClient::MMMClientPostIntMsg(DWORD waitForSpaceInQueueInMs,
		T_MODULE_ID destinationModule, T_MODULE_ID sendingModule, USHORT messageType, USHORT datalength, BYTE *pData) {
	T_MMMCLIENT_RETURN_VALUE retValue = MMMCLIENT_MESSAGE_NOT_POSTED; ///< Member Function Return Value 
	T_CAMQ_RETURN_VALUE addMsgResult = CAMQ_MSG_ADDED_TO_QUEUE;	///< Message Successfully added to queue or not
	DWORD waitTimer = 0;										///< Wait timer 
	// Create a local pointer to the destination module queue for readability.
	//
	CCircularArrayMsgQueue *pDestinationMsgQueue = m_pModuleMsgManager->m_pMessageQueue[destinationModule];
	// check the destination message queue reads message
	if (!pDestinationMsgQueue->QueueSendMsgOnly()) {
		// Limit check the value the user has entered for waiting for space in queue
		// 
		if (waitForSpaceInQueueInMs > MMMCLIENT_MESSAGE_QUEUE_MAX_WAIT) {
			waitForSpaceInQueueInMs = MMMCLIENT_MESSAGE_QUEUE_MAX_WAIT;
		}
		do {
			// Attempt to add the messaage to the Destination Message Queue
			//
			addMsgResult = pDestinationMsgQueue->AddMessageToQueue(MMMCLIENT_MESSAGEQUEUE_MUTEX_WAIT,
					MMMCLIENT_INTERNAL_MESSAGE, destinationModule, sendingModule, MODULE_MSG_COMPLETION_NO_WAIT,
					messageType, datalength, pData);
			if (CAMQ_MSG_ADDED_TO_QUEUE != addMsgResult) {
				// Unable to add message, wait for determined amount of time before retry
				//
				sleep(MMMCLIENT_MESSAGE_QUEUE_RETRY_VALUE);
				waitTimer += MMMCLIENT_MESSAGE_QUEUE_RETRY_VALUE;
			}
		} while ((CAMQ_MSG_ADDED_TO_QUEUE != addMsgResult) && (waitTimer < waitForSpaceInQueueInMs));
		if (CAMQ_MSG_ADDED_TO_QUEUE == addMsgResult) {
			retValue = MMMCLIENT_MESSAGE_POSTED;
		}
	} else {
		// even though nothing posted return that it has to indicate success
		retValue = MMMCLIENT_MESSAGE_POSTED;
	}
	return (retValue);
} // End of MMMClientPostIntMsg()
//****************************************************************************
/// Post a message to the message queue as specified by the destinationModule
/// parameter. Function will wait for a specified amount of time for the 
/// destination module to complete the message. The function will also attempt
/// to re-try posting the message, for a specified amount of time until the 
/// message has been added to the message queue. If after this time the message
/// has not been posted, this is report to the user. 
///		
/// @param[in]	waitForSpaceInQueueInMs - Time to wait for space in the queue 
///										to become available
/// @param[in]	waitTimeOutInMs		- Time to wait for the message to be completed.
/// @param[in] 	destinationModule	- Destination Module for the message
/// @param[in] 	sendingModule		- Sending Module
/// @param[in]	messageType			- Type of Message to be posted
/// @param[in] 	datalength			- Size in bytes of the data of the message
/// @param[in]	pData				- Pointer to the Data to be sent with message
///
/// @return whether the message has been posted, or the failure condition
///
/// @note If the Ip Address has been set to an external device, then the destination
///	module refers to the receiving module on the receiving device. 
///
//****************************************************************************
T_MMMCLIENT_RETURN_VALUE CModuleMsgManagerClient::MMMClientPostIntMsgAndWait(DWORD waitForSpaceInQueueInMs,
		DWORD waitTimeOutInMs, T_MODULE_ID destinationModule, T_MODULE_ID sendingModule, USHORT messageType,
		USHORT datalength, BYTE *pData) {
	DWORD waitTimer = 0; ///< Wait timer 
//	DWORD waitSingleObjectResult	= WAIT_OBJECT_0;
	T_MMMCLIENT_RETURN_VALUE retValue = MMMCLIENT_MESSAGE_NOT_POSTED; ///< Member Function Return Value 
	T_CAMQ_RETURN_VALUE addMsgResult = CAMQ_MSG_ADDED_TO_QUEUE; ///< Message Successfully added to queue or not
	// Create a local pointer to the destination message queue, for readability
	//
	CCircularArrayMsgQueue *pDestinationMsgQueue = m_pModuleMsgManager->m_pMessageQueue[destinationModule];
	// Limit check the value the user has entered for waiting for space in queue
	// 
	if (waitForSpaceInQueueInMs > MMMCLIENT_MESSAGE_QUEUE_MAX_WAIT) {
		waitForSpaceInQueueInMs = MMMCLIENT_MESSAGE_QUEUE_MAX_WAIT;
	}
	// check the destination message queue reads message
	if (!pDestinationMsgQueue->QueueSendMsgOnly()) {
		do {
			// Attempt to add the messaage to the Destination Message Queue
			//
			addMsgResult = pDestinationMsgQueue->AddMessageToQueue(MMMCLIENT_MESSAGEQUEUE_MUTEX_WAIT,
					MMMCLIENT_INTERNAL_MESSAGE, destinationModule, sendingModule, MODULE_MSG_COMPLETION_WAIT,
					messageType, datalength, pData);
			if (CAMQ_MSG_ADDED_TO_QUEUE != addMsgResult) {
				// Unable to add message, wait for determined amount of time before retry
				//
				sleep(MMMCLIENT_MESSAGE_QUEUE_RETRY_VALUE);
				waitTimer += MMMCLIENT_MESSAGE_QUEUE_RETRY_VALUE;
			}
		} while ((CAMQ_MSG_ADDED_TO_QUEUE != addMsgResult) && (waitTimer < waitForSpaceInQueueInMs));
		if (CAMQ_MSG_ADDED_TO_QUEUE == addMsgResult) {
			// Message has been added to the destination queue, wait for the message to be
			// processed and completed
			//
			retValue = WaitForMessageCompletion(waitTimeOutInMs);
		} else {
			retValue = MMMCLIENT_MESSAGE_NOT_POSTED;
		} // End of If
	} else {
		// even though nothing processed return that it has to indicate success
		retValue = MMMCLIENT_MESSAGE_COMPLETED;
	}
	return (retValue);
} // End of MMMClientPostIntMsgAndWait()
//****************************************************************************
/// Posts a message to an external device, as specified by the Internet Protocol
/// Address. The message will be posted into the destination module message queue 
/// on the external device. The Message is posted into a internal message queue
/// of the module that is capable of transmitting to external devices. The function 
/// will re-try posting the message, for a specified amount of time until the 
/// message has been added to the message queue. If after this time the message has 
/// not been posted, this is report to the user.				
///
/// @param[in] 	waitForSpaceInQueueInMs - Time to wait for space in the queue 
///										to become available
/// @param[in]	ipAddress			- Determine whether message to be sent 
///										External of device or internal
/// @param[in] 	destinationModule	- Destination Module
/// @param[in] 	sendingModule		- Sending Module
/// @param[in]	messageType			- Type of Message to be posted
/// @param[in] 	datalength			- Size in bytes of the data of the message
/// @param[in]	pData				- Pointer to the Data to be sent with message
///
/// @return whether the message has been posted, or the failure condition
///
//****************************************************************************
T_MMMCLIENT_RETURN_VALUE CModuleMsgManagerClient::MMMClientPostExtMsg(DWORD waitForSpaceInQueueInMs, ULONG ipAddress,
		T_MODULE_ID destinationModule, T_MODULE_ID sendingModule, USHORT messageType, USHORT datalength, BYTE *pData) {
	DWORD waitTimer = 0;	///< Wait timer 
	T_MMMCLIENT_RETURN_VALUE retValue = MMMCLIENT_MESSAGE_POSTED; ///< Member Function Return Value 
	T_CAMQ_RETURN_VALUE addMsgResult = CAMQ_MSG_ADDED_TO_QUEUE; ///< Message Successfully added to queue or not
	// Create a local pointer to the destination message queue, for readability
	//
	CCircularArrayMsgQueue *pDestinationMsgQueue = m_pModuleMsgManager->m_pMessageQueue[MODULE_CONTROL_PROTOCOL];
	// Limit check the value the user has entered for waiting for space in queue
	// 
	if (waitForSpaceInQueueInMs > MMMCLIENT_MESSAGE_QUEUE_MAX_WAIT) {
		waitForSpaceInQueueInMs = MMMCLIENT_MESSAGE_QUEUE_MAX_WAIT;
	}
	// check the destination message queue reads message
	if (!pDestinationMsgQueue->QueueSendMsgOnly()) {
		do {
			// Attempt to add the messaage to the Destination Message Queue
			//
			addMsgResult = pDestinationMsgQueue->AddMessageToQueue(MMMCLIENT_MESSAGEQUEUE_MUTEX_WAIT, ipAddress,
					destinationModule, sendingModule, MODULE_MSG_COMPLETION_NO_WAIT, messageType, datalength, pData);
			if (CAMQ_MSG_ADDED_TO_QUEUE != addMsgResult) {
				// Unable to add message, wait for determined amount of time before retry
				//
				sleep(MMMCLIENT_MESSAGE_QUEUE_RETRY_VALUE);
				waitTimer += MMMCLIENT_MESSAGE_QUEUE_RETRY_VALUE;
			}
		} while ((CAMQ_MSG_ADDED_TO_QUEUE != addMsgResult) && (waitTimer < waitForSpaceInQueueInMs));
		if (CAMQ_MSG_ADDED_TO_QUEUE == addMsgResult) {
			retValue = MMMCLIENT_MESSAGE_POSTED;
		}
	} else {
		// even though nothing posted return that it has to indicate success
		retValue = MMMCLIENT_MESSAGE_POSTED;
	}
	return (retValue);
} // End of MMMClientPostExtMsg()
//***************************************************************************
//
// Private Member Functions
//
//***************************************************************************
/// This function waits for a specified amount of time for the message sent to the
/// destination module to be completed.			
///
/// @param[in]	timeOutInMs - Time to wait for message to be completed by 
///							destination module
///
/// @return whether the message was completed, or the timeout was reached
/// 
//****************************************************************************
T_MMMCLIENT_RETURN_VALUE CModuleMsgManagerClient::WaitForMessageCompletion(DWORD timeOutInMs) {
	T_MMMCLIENT_RETURN_VALUE retValue = MMMCLIENT_ERROR; ///< Member Function Return Value
	DWORD waitSingleObjectResult = WAIT_OBJECT_0; ///< Result of the WaitForSingleObject function call
	// Use WaitSingleObjectResult for efficiency, does not use processor cycles
	//
	waitSingleObjectResult = m_hMsgCompleted.tryLock(timeOutInMs);
	// Determine whether the event was triggered, or the wait timed out
	//
	switch (waitSingleObjectResult) {
	case WAIT_OBJECT_0:
		retValue = MMMCLIENT_MESSAGE_COMPLETED;
		break;
	case WAIT_TIMEOUT:
		retValue = MMMCLIENT_MESSAGE_COMPLETED_TIMEOUT;
		break;
	case WAIT_ABANDONED:
	case WAIT_FAILED:
		retValue = MMMCLIENT_ERROR;
		break;
		break;
	default:
		retValue = MMMCLIENT_ERROR;
		break;
	} // End of switch
	return (retValue);
} // End of WaitForMessageCompletion()

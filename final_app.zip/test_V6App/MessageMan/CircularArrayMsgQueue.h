/// @file 
/// *****************************************************************
/// © Honeywell Trendview
/// *****************************************************************
/// @n Module : Module Message Manager (MMM )
/// @n FileName: HeapBipBuffer.h
/// @n Desc	: Class Declaration for the CCircularArrayMsgQueue
///			
/// *****************************************************************
/// @b Revision @b History
/// *****************************************************************
/// $Log[4]:
/// 6	Stability Project 1.3.1.1	7/2/2011 4:56:05 PM	Hemant(HAIL) 
///		Stability Project: Recorder source has been upgraded from IL
///	version of firmware to JF version of firmware.
/// 5	Stability Project 1.3.1.0	7/1/2011 4:26:58 PM	Hemant(HAIL) 
///		Stability Project: Files has been checked in before the merging
///	task. The merging will be done between IL version of firmware and JF
///	version of firmware. 
/// 4	V6 Firmware 1.3		9/23/2008 3:09:22 PM	Build Machine 
///	AMS2750 Merge
/// 3	V6 Firmware 1.2		9/8/2004 5:28:52 PM	Alistair Brugsch
///	Changed T_MODULE_MESSAGE_ID to USHORT, as the messages to be used
///	have been taken out of an enum and declared as constants for
///	clarification and usability.
/// $
///
#ifndef _CIRCULARARRAYMSGQUEUE_H
#define _CIRCULARARRAYMSGQUEUE_H
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "HeapBipBuffer.h"
#include "ModuleConstants.h"
#include "MsgQueueMessage.h"
#include "MsgQueueStatistics.h"
/// Maximum number of message allowed in the queue at any one time.
const USHORT CAMQ_MAX_QUEUE_SIZE = 50;
/// constant value to represent the value zero
///
const USHORT CAMQ_DEFAULT_ZERO_VALUE = 0;
/// Return Values for CCircularArrayMsgQueue Member Functions, used to describe the type of 
/// success or failure.
typedef enum {
	CAMQ_OK,
	CAMQ_EMPTY,
	CAMQ_FULL,
	CAMQ_SPACE_AVAILABLE,
	CAMQ_INVALID_ITEM_NUMBER,
	CAMQ_ITEM_AVAILABLE,
	CAMQ_ITEM_ADDED,
	CAMQ_MSG_CREATED,
	CAMQ_MSG_ADDED_TO_QUEUE,
	CAMQ_MSG_RELEASED_SUCESSFULLY,
	CAMQ_NO_MEMORY_AVAILABLE,
	CAMQ_MODULE_REGISTERED,
	CAMQ_MODULE_ALREADY_REGISTERED,
	CAMQ_MUTEX_TIMED_OUT,
	CAMQ_MUTEX_OBTAINED,
	CAMQ_MUTEX_ERROR,
	CAMQ_STATS_UPDATED,
	CAMQ_NEW_MESSAGE_NOTIFICATION_SENT,
	CAMQ_SENDING_MODULE_SIGNALLED,
	CAMQ_ALL_MESSAGE_REMOVED,
	CAMQ_ERROR
} T_CAMQ_RETURN_VALUE;
//**Class*********************************************************************
///
/// @brief Creates a FIFO Message Queue, which interfaces directly to allocated 
///		heap memory. 
///	
/// Provides the functionality to create a FIFO message queue, and allows messages
/// to be added, retrieved, peeked and removed from the queue. The queue is
/// constructed using an array, this ensures efficiency when adding and removing
/// items. An index to the front and rear are stored and incremented and decrement
/// accordingly.If a linked list immplementation was used memory would have to be
/// allocated and deallocated on adding/removing items. This class directly 
/// an overlay to a heap buffer which contains the message data. The Heap Buffer
/// stores the bytes of data and has no concept of messages. The Message Queue
/// class interprets the bytes of data stored into messages that can be used.
/// For efficency, data read from the message queue is not released, instead a 
/// pointer is returned so that the user can obtain the data directly. Once the 
/// user has finished reading the message, they call a release message function 
/// that will then remove the message from the queue. The owner of the Message
/// Queue is informed of a message is avialble either through an event being 
/// triggered, or by a thread message being posted to them. A Message Queue can
/// be allowed to wrap, overidding any messages already in the queue.	
///
/// The class is thread-safe through using a mutex when data is added and removed.
/// 
/// Statistics are stored within the class to provide the user will information
/// regarding loading, and the amount of data being received.		
///
/// @note Message Queue does not support Priority Messages
///
//****************************************************************************
#include <QMutex>
class CCircularArrayMsgQueue: public CHeapBipBuffer {
public:
	/// CCircularArrayMsgQueue Constructor
	CCircularArrayMsgQueue(T_MODULE_ID MsgQueueId);
	/// CCircularArrayMsgQueue Destructor
	virtual ~CCircularArrayMsgQueue();
	/// Allows the owner of the queue to register, to allow notification to be sent once messages arrive. 
	T_CAMQ_RETURN_VALUE RegisterMessageQueue(T_MODULE_MSG_NOTIFICATION notificationMode, DWORD ownerThreadId,
			T_MODULE_QUEUE_WRAP_STATUS QueueWrapStatus);
	/// Add a Message to the End of the Queue
	T_CAMQ_RETURN_VALUE AddMessageToQueue(DWORD timeOutInMilliseconds, ULONG ipAddress, T_MODULE_ID destModule,
			T_MODULE_ID sendingModule, T_MODULE_MSG_COMPLETION waitForMsgCompletion, USHORT messageType,
			USHORT dataLength, BYTE *pData);
	/// Obtain the available message at the front of the Queue
	const CMsgQueueMessage* RetrieveMsg(void);
	/// Remove Message from the Front of the Queue
	T_CAMQ_RETURN_VALUE RemoveMsg(void);
	/// Allows a message at a specific location to be read from the Message Queue
	T_CAMQ_RETURN_VALUE PeekMsg(USHORT itemNumber, CMsgQueueMessage &item) const;
	/// Obtains the Queue Statistics
	CMsgQueueStatistics GetQueueStatistics(void);
	// Method that indicates if the message quene only sends message and does nto read them
	const bool QueueSendMsgOnly() {
		return (m_MsgQueueOwnerEventNotification == MODULE_SEND_ONLY);
	}
private:
	/// Remove All Messages from the Message Queue
	T_CAMQ_RETURN_VALUE RemoveAllMessagesFromMessageQueue(void);
	/// Obtain whether the Queue is FULL, EMPTY, or SPACE AVAILABLE
	T_CAMQ_RETURN_VALUE QueueStatus(void) const;
	/// Carry out a check to determine whether the sending module needs to be told when the message has been completed.
	T_CAMQ_RETURN_VALUE CheckAndSignalWaitingModule(void);
	/// Signal to the owner that messages are available
	T_CAMQ_RETURN_VALUE SignalMsgToProcess(void);
	/// Update the Queue Statistics
	T_CAMQ_RETURN_VALUE UpdateQueueStats(USHORT &dataLength, USHORT &allocatedMessageLength);
	/// Obtain hold of the Mutex, within a fixed period of time
	T_CAMQ_RETURN_VALUE ObtainQueueMutex(DWORD timeOutInMilliseconds);
	T_MODULE_ID m_MsgQueueModuleId; ///< Module Id associated with Message Queue.
	T_MODULE_QUEUE_WRAP_STATUS m_QueueWrapStatus; ///< Stores whether the queue shall wrap once full.
	T_MODULE_MSG_NOTIFICATION m_MsgQueueOwnerEventNotification; ///< Notification method, Event or Thread Message.
	DWORD m_MsgQueueOwnerThreadId; ///< Thread Id of the owner.
	BOOL m_MsgQueueOwnerRegistered; ///< Indication whether the associated module has registered.
	CMsgQueueStatistics m_QueueStats; ///< Structure for storing Message Queue Statistics
	static QMutex m_hQueueMutex;			///< Handler to Message Queue Mutex
	USHORT m_FrontOfQueue; ///< Postion of the Front of the Queue
	USHORT m_RearOfQueue; ///< Position of the Rear of the Queue
	USHORT m_NumOfMsgsToProcess; ///< Number of Messages within Queue to Process
	CMsgQueueMessage *m_MsgItem[CAMQ_MAX_QUEUE_SIZE]; ///< Array of Message Items
	HANDLE m_hNewMessageAvailableInQueue; ///< Event Handler to determine message are waiting to be processed
};
// End of CCircularArrayMsgQueue Class Declaration
#endif // _CIRCULARARRAYMSGQUEUE_H

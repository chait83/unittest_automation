/// @file 
/// *****************************************************************
/// © Honeywell Trendview
/// *****************************************************************
/// @n Module : Module Message Manager (MMM )
/// @n FileName: MsgQueueStatistics.cpp
/// @n Desc  : Implementation File for the CMsgQueueStatistics
///  
/// *****************************************************************
/// @b Revision @b History
/// *****************************************************************
/// $Log[4]:
/// 6 Stability Project 1.1.1.3 7/2/2011 4:58:53 PM Hemant(HAIL) 
/// Stability Project: Recorder source has been upgraded from IL
///  version of firmware to JF version of firmware.
/// 5 Stability Project 1.1.1.2 7/1/2011 4:38:31 PM Hemant(HAIL) 
/// Stability Project: Files has been checked in before the merging
///  task. The merging will be done between IL version of firmware and JF
///  version of firmware. 
/// 4 Stability Project 1.1.1.1 3/17/2011 3:20:30 PM  Hemant(HAIL) 
/// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
///  new operator in DEBUG mode only. To detect memory leaks in files, use
///  it in preprocessor definition when in debug mode.
/// 3 Stability Project 1.1.1.0 2/15/2011 3:03:22 PM  Hemant(HAIL) 
/// File updated during Heap Management. Call to the default behaviour
///  of new operator has been commented.
/// $
///
#include "MsgQueueStatistics.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
//****************************************************************************
/// CMsgQueueStatistics Constructor
///
//****************************************************************************
CMsgQueueStatistics::CMsgQueueStatistics() {
	// Initialise Queue Statistics
	//
	m_NumberOfDataBytesReceived = MQS_DEFAULT_ZERO_VALUE;
	m_NumberOfBytesReceived = MQS_DEFAULT_ZERO_VALUE;
	m_QueueLoad = MQS_DEFAULT_ZERO_VALUE;
	m_NumberOfTimesQueueWrapped = MQS_DEFAULT_ZERO_VALUE;
	m_NumberOfMessageLostDueToQueueWrap = MQS_DEFAULT_ZERO_VALUE;
	m_NumOfMsgsAddedToQueue = MQS_DEFAULT_ZERO_VALUE;
	m_NumOfMsgsRemovedFromQueue = MQS_DEFAULT_ZERO_VALUE;
	m_NumOfTimesQueueLackOfMemory = MQS_DEFAULT_ZERO_VALUE;
	m_NumOfTimesQueueFull = MQS_DEFAULT_ZERO_VALUE;
	m_LargestMessageSizeReceived = MQS_DEFAULT_ZERO_VALUE;
	m_LargestDataSizeReceived = MQS_DEFAULT_ZERO_VALUE;
} // End of Constructor
//****************************************************************************
/// CMsgQueueStatistics Destructor
///
//****************************************************************************
CMsgQueueStatistics::~CMsgQueueStatistics() {
} // End of Destructor

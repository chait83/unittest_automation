/// @file 
/// *****************************************************************
/// © Honeywell Trendview
/// *****************************************************************
/// @n Module : Module Message Manager (MMM )
/// @n FileName: CircularArrayMsgQueue.cpp
/// @n Desc	: Implementation File for the CCircularArrayMsgQueue Class
///			
/// *****************************************************************
/// @b Revision @b History
/// *****************************************************************
/// $Log[4]:
/// 11	Stability Project 1.6.1.3	7/2/2011 4:56:05 PM	Hemant(HAIL) 
///		Stability Project: Recorder source has been upgraded from IL
///	version of firmware to JF version of firmware.
/// 10	Stability Project 1.6.1.2	7/1/2011 4:38:05 PM	Hemant(HAIL) 
///		Stability Project: Files has been checked in before the merging
///	task. The merging will be done between IL version of firmware and JF
///	version of firmware. 
/// 9	Stability Project 1.6.1.1	3/17/2011 3:20:16 PM	Hemant(HAIL) 
///		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
///	new operator in DEBUG mode only. To detect memory leaks in files, use
///	it in preprocessor definition when in debug mode.
/// 8	Stability Project 1.6.1.0	2/15/2011 3:02:33 PM	Hemant(HAIL) 
///		File updated during Heap Management. Call to the default behaviour
///	of new operator has been commented.
/// $
///
#include "ModuleMsgManager.h"
#include "CircularArrayMsgQueue.h"
#include "MsgQueueMessage.h"
#include "V6defines.h"
#include "V6globals.h"
QMutex CCircularArrayMsgQueue::m_hQueueMutex;
//****************************************************************************
/// Class Constructor, Initialise all member variables to known default values 
///
/// @param[in]	MsgQueueId - the owner of the queue
///
//****************************************************************************
CCircularArrayMsgQueue::CCircularArrayMsgQueue(T_MODULE_ID MsgQueueId) {
	// Set the Queue Id
	//
	m_MsgQueueModuleId = MsgQueueId;
	// Initialise Queue Member Variables
	//
	m_FrontOfQueue = CAMQ_DEFAULT_ZERO_VALUE;
	m_RearOfQueue = CAMQ_MAX_QUEUE_SIZE - 1; // 0 to max - 1
	m_QueueWrapStatus = CAMQ_QUEUE_WRAP_DISABLED;
	m_MsgQueueOwnerEventNotification = MODULE_USE_EVENT;
	m_MsgQueueOwnerThreadId = CAMQ_DEFAULT_ZERO_VALUE;
	m_MsgQueueOwnerRegistered = FALSE;
	m_NumOfMsgsToProcess = CAMQ_DEFAULT_ZERO_VALUE;
	m_hNewMessageAvailableInQueue = NULL;
	// Initialise Each item in the Queue to default values
	//
	for (USHORT itemIndex = CAMQ_MAX_QUEUE_SIZE; itemIndex < CAMQ_MAX_QUEUE_SIZE; itemIndex++) {
		m_MsgItem[itemIndex] = NULL;
	}
} // End of constructor
//****************************************************************************
/// Class Destructor, Release the Mutex Handler 
///
//****************************************************************************
CCircularArrayMsgQueue::~CCircularArrayMsgQueue() {
	//No need to close the mutex in Qt
	if (m_hNewMessageAvailableInQueue != NULL) {
		//No need to close the mutex in Qt
		m_hNewMessageAvailableInQueue = NULL;
	}
} // End of Destructor
//****************************************************************************
/// Each module requiring a message queue must register with the queue to allow
/// event notification and thread messages to sent when new messages arrive.
/// When a module registers, the module will then receive notification via their
/// chosen method. On registering the queue is intialised to either allow wrapping 
/// of messages when the queue is full, or to refuse messages if the queue is full.
/// The function checks to ensure that registration is only carried out once.
///
/// Please Note: Message Queues will be up and running on startup of the system,
///			messages can be added to any queue. Messages can only be read
///			and remove from the queue when the module registers.	
///		
///
/// @param[in] notificationMode	- Method in which to module to be notified 
///								when message arrive in queue
/// @param[in] ownerThreadId	- Module thread id, to allow post thread messages to be sent	
/// @param[in] QueueWrapStatus	- Allow Queue Wrapping or not
///
/// @return whether module has registered sucessfully, or module has been already registered. 
///
/// @note If queue wrapping is enabled, message will be over-riden if not read
///
/// @todo JU:Post Thread Message requires a pre-defined message, needs to be 
///	used by each module, and must be unique.
///
//****************************************************************************
T_CAMQ_RETURN_VALUE CCircularArrayMsgQueue::RegisterMessageQueue(T_MODULE_MSG_NOTIFICATION notificationMode,
		DWORD ownerThreadId, T_MODULE_QUEUE_WRAP_STATUS QueueWrapStatus) {
	T_CAMQ_RETURN_VALUE retValue = CAMQ_MODULE_ALREADY_REGISTERED;
	wchar_t msgMessageQueueEventName[MSGQUEUEEVENTNAMESIZE];
#if _MSC_VER < 1400 
	swprintf(msgMessageQueueEventName, MSGQUEUEEVENTNAMESIZE, L"%s%d", MSGQUEUE_EVENTNAME, m_MsgQueueModuleId);
#else
	swprintf(msgMessageQueueEventName, MSGQUEUEEVENTNAMESIZE, L"%s%d", MSGQUEUE_EVENTNAME, m_MsgQueueModuleId ); 
#endif
	ObtainQueueMutex(g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);
	// Indicate that the module has registered, stops users trying to register more than once
	//
	m_MsgQueueOwnerRegistered = TRUE;
	m_QueueWrapStatus = QueueWrapStatus;
	m_MsgQueueOwnerEventNotification = notificationMode;
	// Create an Event object if the module wants to be notified of new messages via this method. 
	//
	switch (m_MsgQueueOwnerEventNotification) {
	case MODULE_USE_EVENT:
		m_hNewMessageAvailableInQueue = CreateEvent(NULL,
		TRUE,
		FALSE, msgMessageQueueEventName);
		// Signal Event if message are waiting within Message Queue
		//
		if (CAMQ_EMPTY != QueueStatus()) {
			SetEvent(m_hNewMessageAvailableInQueue);
		}
		break;
	case MODULE_USE_POSTMESSAGE:
		if (CAMQ_EMPTY != QueueStatus()) {
			// Inform module new messages are waiting
			//
			PostThreadMessage(ownerThreadId, WM_MODULE_NEW_MESSAGE_IN_QUEUE, NULL, NULL);
		}
		break;
	case MODULE_MANUAL:
		break;	// Do Nothing
	case MODULE_SEND_ONLY:
		break;	// Do Nothing
	default:
		break;				// Do Nothing
	} // End of Switch
	m_MsgQueueOwnerThreadId = ownerThreadId;
	retValue = CAMQ_MODULE_REGISTERED;
	m_hQueueMutex.unlock();
	return (retValue);
} // End of RegisterMessageQueue
//****************************************************************************
/// Adds a message to the end of the message queue, the member function will
/// wait for a specified amount of time to obtain access to the queue. If mutex
/// can not be obtained within the period of time, the message will not be added
/// to the queue.	
///
/// @param[in] timeOutInMilliseconds - Timeout for obtaining ownership of the mutex
/// @param[in] ipAddress			- Device to send the message too, LOCAL if internal
/// @param[in] destModule			- The destination module for the message to be sent
/// @param[in] sendingModule		- Module that is sending the message
/// @param[in] messageType		- Type of Message to be posted
/// @param[in] dataLength			- The length of the data to be sent
/// @param[in] waitForMsgCompletion - Indication to whether sending module requires to 
///									be told when message has been completed.
/// @param[in] *pData				- Pointer to the data to be sent
///
/// @return whether the message has been added to the queue, or the assocaited error.
///
//****************************************************************************
T_CAMQ_RETURN_VALUE CCircularArrayMsgQueue::AddMessageToQueue(DWORD timeOutInMilliseconds, ULONG ipAddress,
		T_MODULE_ID destModule, T_MODULE_ID sendingModule, T_MODULE_MSG_COMPLETION waitForMsgCompletion,
		USHORT messageType, USHORT dataLength, BYTE *pData) {
	T_CAMQ_RETURN_VALUE retValue = CAMQ_MUTEX_ERROR;
	CMsgQueueMessage *pMessage = NULL;
	BYTE *pCommitedMemory = NULL;
	BOOL addMessage = TRUE;
	// Message Structure contains first byte of the data, therefore this byte must be
	// removed from the data length to obtain the correct message size in bytes. 
	//
	USHORT messageLength = (USHORT) (sizeof(CMsgQueueMessage) + (dataLength - 1));
	USHORT allocatedMessageLength = 0;
	// Obtain Access to the Message Queue
	//
	if (CAMQ_MUTEX_OBTAINED == ObtainQueueMutex(timeOutInMilliseconds)) {
		retValue = QueueStatus();
		if ((CAMQ_QUEUE_WRAP_DISABLED == m_QueueWrapStatus) && (retValue == CAMQ_FULL)) {
			m_QueueStats.m_NumOfTimesQueueFull++;
			retValue = CAMQ_FULL;
			addMessage = FALSE;
		} else if ((CAMQ_QUEUE_WRAP_ENABLED == m_QueueWrapStatus) && (retValue == CAMQ_FULL)) {
			m_QueueStats.m_NumberOfTimesQueueWrapped++;
			m_QueueStats.m_NumberOfMessageLostDueToQueueWrap += m_NumOfMsgsToProcess;
			// Remove All Messages from the Message Queue, to ensure no memeory leaks occur. 
			//
			RemoveAllMessagesFromMessageQueue();
			addMessage = TRUE;
		}
		if (addMessage == TRUE) {
			// Commit Heap Memory for the New Message
			//
			pCommitedMemory = CommitMemory(messageLength, allocatedMessageLength);
			if (pCommitedMemory != NULL) {
				m_NumOfMsgsToProcess++;
				m_QueueStats.m_NumOfMsgsAddedToQueue++;
				// Write Header
				//
				pMessage = (CMsgQueueMessage*) pCommitedMemory;
				pMessage->m_IpAddress = ipAddress;
				pMessage->m_DestinationModule = destModule;
				pMessage->m_SendingModule = sendingModule;
				pMessage->m_WaitForMsgCompletion = waitForMsgCompletion;
				pMessage->m_MsgSize = allocatedMessageLength;
				pMessage->m_DataLength = dataLength;
				pMessage->m_MessageType = messageType;
				// Copy the data passed in, to the heap memory committed
				//
				memcpy(pMessage->m_MsgData, pData, pMessage->m_DataLength);
				// Update the Queue Statistic
				//
				UpdateQueueStats(dataLength, allocatedMessageLength);
				// Move the Rear of the Queue on by one 
				//
				if ((m_RearOfQueue + 1) == CAMQ_MAX_QUEUE_SIZE) {
					m_RearOfQueue = CAMQ_DEFAULT_ZERO_VALUE;
				} else {
					m_RearOfQueue++;
				}
				// Assign the Create Item to a item within the queue
				//
				m_MsgItem[m_RearOfQueue] = pMessage;
				// Indicate to the owner that a new message is waiting to be read
				//
				SignalMsgToProcess();
				retValue = CAMQ_MSG_ADDED_TO_QUEUE;
			} else {
				// Unable to add message as the heap memory is full
				//
				m_QueueStats.m_NumOfTimesQueueLackOfMemory++;
				retValue = CAMQ_NO_MEMORY_AVAILABLE;
			} // End of If
		} // End of If
		m_hQueueMutex.unlock();
	} // End of If
	return (retValue);
} // End of AddMessageToQueue()
//****************************************************************************
/// Retrieve the first item within the Message Queue, if an item is available.
///
/// @param[in,out] item - if available, first item in the queue 
///
/// @return whether an item was obtained, or the message queue was empty
/// 
//****************************************************************************
const CMsgQueueMessage* CCircularArrayMsgQueue::RetrieveMsg(void) {
	CMsgQueueMessage *item = NULL;
	if (CAMQ_EMPTY != QueueStatus()) {
		item = m_MsgItem[m_FrontOfQueue];
	}
	return (item);
} // End of RetrieveMsg
//****************************************************************************
/// Removes the first item of the queue, to allow if any the next message 
/// to be read. If the queue is not empty after the removal of the message,
/// the event indicating messages in queue is not reset, or a post thread
/// messsage is invoked to allow the module to read the next message in the
/// queue.	
///	
/// @param[in] - none
///
/// @return whether message has been released 
///
/// @todo JU:Post Thread Message requires a pre-defined message, needs to be 
///	used by each module, and must be unique.
///
//****************************************************************************
T_CAMQ_RETURN_VALUE CCircularArrayMsgQueue::RemoveMsg(void) {
	ObtainQueueMutex(g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);
	ReleaseCommittedMemory(m_MsgItem[m_FrontOfQueue]->m_MsgSize);
	CheckAndSignalWaitingModule();
	// Reset the current item to NULL for safe operation
	//
	m_MsgItem[m_FrontOfQueue] = NULL;
	m_NumOfMsgsToProcess--;
	m_QueueStats.m_NumOfMsgsRemovedFromQueue++;
	if ((m_FrontOfQueue + 1) == CAMQ_MAX_QUEUE_SIZE) {
		m_FrontOfQueue = CAMQ_DEFAULT_ZERO_VALUE;
	} else {
		m_FrontOfQueue++;
	}
	// Check to determine if the new message notification needs to be invoked
	// to allow the module to receive the next message in the queue.
	//
	if (CAMQ_EMPTY == QueueStatus()) {
		if (MODULE_USE_EVENT == m_MsgQueueOwnerEventNotification) {
			// Reset the Event, to allow the thread waiting on the message
			// queue to wait for a new message to be added to the queue. 
			//
			ResetEvent(m_hNewMessageAvailableInQueue);
		}
	} else {
		if (MODULE_USE_POSTMESSAGE == m_MsgQueueOwnerEventNotification) {
			// Message(s) are still waiting to be processed, signal to the module
			// that message are waiting.
			//
			PostThreadMessage(m_MsgQueueOwnerThreadId, WM_MODULE_NEW_MESSAGE_IN_QUEUE, NULL, NULL);
		}
	} // End of If
	m_hQueueMutex.unlock();
	return (CAMQ_MSG_RELEASED_SUCESSFULLY);
} // End of RemoveMsg()
//****************************************************************************
/// Allows a particular item( if any ) in the queue to be obtained, the item is not 
/// remove from the queue, and can not be released.	
///
/// @param[in]	itemNumber - Position in Queue to be peeked
/// @param[in,out] item	- Reference to the item at the specified position in Queue
///
/// @return whether an item is available, or not
/// 
//****************************************************************************
T_CAMQ_RETURN_VALUE CCircularArrayMsgQueue::PeekMsg(USHORT itemNumber, CMsgQueueMessage &item) const {
	T_CAMQ_RETURN_VALUE retValue = QueueStatus();
	if (CAMQ_EMPTY != retValue) {
		// Bounds check the itemNumber,ensuring that it is within the limites
		// of the queue settings. 
		//
		//PSR - Coverity issue fix --Out-Of-Bounds read #772570	
		if ((itemNumber >= CAMQ_MAX_QUEUE_SIZE) || (itemNumber < CAMQ_DEFAULT_ZERO_VALUE)) {
			retValue = CAMQ_INVALID_ITEM_NUMBER;
		} else {
			item = *m_MsgItem[itemNumber];
			retValue = CAMQ_ITEM_AVAILABLE;
		} // End of If	
	} // End of If 
	return (retValue);
} // End of PeekMsg
//****************************************************************************
/// Obtains the Queue Latest Statistics, in terms of number of messages
/// received, queue loading, number of bytes received including message header,
/// and the amount of byte of data received.	
///	
/// @param[in] - none
///
/// @return A Structure containing the Queue Statisitics
///
//****************************************************************************
CMsgQueueStatistics CCircularArrayMsgQueue::GetQueueStatistics() {
	CMsgQueueStatistics queueStatistics;
	ObtainQueueMutex(g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);
	// Once the mutex has been obtained, obtain the latest queue statistics.
	// 
	queueStatistics = m_QueueStats;
	m_hQueueMutex.unlock();
	return (queueStatistics);
}
//*************************************************************************************
//
// Private Member Functions
//
//*************************************************************************************
//****************************************************************************
/// Obtain hold of the mutex to allow, messages to be add and removed from
/// the Message Queue. Wait for a specified time for the mutex to become
/// available. 
///
/// @param timeOutInMilliseconds - Timeout value for the mutex to be obtained
///
/// @return 
/// 
//****************************************************************************
T_CAMQ_RETURN_VALUE CCircularArrayMsgQueue::ObtainQueueMutex(DWORD timeOutInMilliseconds) {
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;
	T_CAMQ_RETURN_VALUE retValue = CAMQ_MUTEX_ERROR;
	waitSingleObjectResult = m_hQueueMutex.tryLock(timeOutInMilliseconds);
	switch (waitSingleObjectResult) {
	case WAIT_OBJECT_0:
		retValue = CAMQ_MUTEX_OBTAINED;
		break;
	case WAIT_TIMEOUT:
		retValue = CAMQ_MUTEX_TIMED_OUT;
		break;
	case WAIT_ABANDONED:
	case WAIT_FAILED:
		V6WarningMessageBox(NULL, "CCircularArrayMsgQueue WaitForSingleObject Error", "CCircularArrayMsgQueue Error",
		MB_OK);
		retValue = CAMQ_MUTEX_ERROR;
		break;
		break;
	default:
		retValue = CAMQ_MUTEX_ERROR;
		break;
	}
	return (retValue);
} // End of ObtainQueueMutex
//****************************************************************************
/// Obtains the Current Status of the Message Queue, in terms of whether the 
/// queue is FULL, EMPTY or SPACE AVAILABLE. 
///
/// @param - None
///
/// @return whether the Queue is FULL, EMPTY or SPACE AVAILABLE
///
/// @note To be used within a member function that has ownership of the mutex
///
//****************************************************************************
T_CAMQ_RETURN_VALUE CCircularArrayMsgQueue::QueueStatus(void) const {
	USHORT numOfMsgItemAvailable = (USHORT) (CAMQ_MAX_QUEUE_SIZE - m_NumOfMsgsToProcess);
	T_CAMQ_RETURN_VALUE retValue = CAMQ_SPACE_AVAILABLE;
	if (CAMQ_DEFAULT_ZERO_VALUE == numOfMsgItemAvailable) {
		retValue = CAMQ_FULL;
	} else if (CAMQ_MAX_QUEUE_SIZE == numOfMsgItemAvailable) {
		retValue = CAMQ_EMPTY;
	}
	return (retValue);
} // End of QueueStatus() 
//****************************************************************************
/// Update the Message Queue Statistics. 
///
/// @param[in,out] dataLength - Length of the Data for the Current Message
/// @param[in,out] allocatedMessageLength - Allocated Number of buffer for message( 4 byte aligned )
///
/// @return Indication that the Message Queue stats have been updated successfully
///
//****************************************************************************
T_CAMQ_RETURN_VALUE CCircularArrayMsgQueue::UpdateQueueStats(USHORT &dataLength, USHORT &allocatedMessageLength) {
	m_QueueStats.m_NumberOfDataBytesReceived += (FLOAT) (dataLength);
	m_QueueStats.m_NumberOfBytesReceived += (FLOAT) (allocatedMessageLength);
	if (allocatedMessageLength > m_QueueStats.m_LargestMessageSizeReceived) {
		m_QueueStats.m_LargestMessageSizeReceived = allocatedMessageLength;
	}
	if (dataLength > m_QueueStats.m_LargestDataSizeReceived) {
		m_QueueStats.m_LargestDataSizeReceived = dataLength;
	}
	if (m_NumOfMsgsToProcess > m_QueueStats.m_QueueLoad) {
		m_QueueStats.m_QueueLoad = m_NumOfMsgsToProcess;
	}
	return (CAMQ_STATS_UPDATED);
} // End of UpdateQueueStats
//****************************************************************************
/// Checks whether the current message item has been told to notify the sender
/// once it has been undertaken by the destination module. The event is 
/// signalled is the sender is waiting for a response from the destination module.	
///
/// @param[in] - None
///
/// @return Nothing
///
//****************************************************************************
T_CAMQ_RETURN_VALUE CCircularArrayMsgQueue::CheckAndSignalWaitingModule(void) {
	wchar_t msgCompletedEventName[MSGCOMPLETEDEVENTNAMESIZE];
	HANDLE hSignalModuleEvent = NULL; //PSR - Fix for V6Desktop crash on config change reboot (05-13-2014)
	if (MODULE_MSG_COMPLETION_WAIT == m_MsgItem[m_FrontOfQueue]->m_WaitForMsgCompletion) {
		// Construct the name of the Event Handler for the module to be signalled
		//
#if _MSC_VER < 1400 
		swprintf(msgCompletedEventName, MSGQUEUEEVENTNAMESIZE, L"%s%d", MSGCOMPLETED_EVENTNAME,
				m_MsgItem[m_FrontOfQueue]->m_SendingModule);
#else
	swprintf(msgCompletedEventName, MSGCOMPLETEDEVENTNAMESIZE, L"%s%d", MSGCOMPLETED_EVENTNAME, m_MsgItem[m_FrontOfQueue]->m_SendingModule ); 
#endif
		// Obtain the handler to the event object, the CreateEvent() function will return
		// the handler to the event object if already created, or will create it
		//
		hSignalModuleEvent = CreateEvent(NULL, FALSE, FALSE, msgCompletedEventName);
		// Signal the Event
		//
		SetEvent(hSignalModuleEvent);
	}
	if (hSignalModuleEvent != NULL) {
		//No need to close the mutex in Qt
		hSignalModuleEvent = NULL;
	}
	return (CAMQ_SENDING_MODULE_SIGNALLED);
}
//****************************************************************************
/// Signal to the Module that a new message is waiting within the message queue,
/// the way in which this is carried out depending on the module. It can either
/// be using a event, or through a post thread message.	
///	
/// @param[in] - none
///
/// @return Module has been signalled
///
/// @todo JU: Post Thread Message requires a pre-defined message, needs to be 
///	used by each module, and must be unique.
//****************************************************************************
T_CAMQ_RETURN_VALUE CCircularArrayMsgQueue::SignalMsgToProcess(void) {
	if ( TRUE == m_MsgQueueOwnerRegistered) {
		switch (m_MsgQueueOwnerEventNotification) {
		case MODULE_USE_EVENT:
			// Determine which method to signal the thread that a message is available
			//
			SetEvent(m_hNewMessageAvailableInQueue);
			break;
		case MODULE_USE_POSTMESSAGE:
			// Post a Thread Message
			//
			PostThreadMessage(m_MsgQueueOwnerThreadId, WM_MODULE_NEW_MESSAGE_IN_QUEUE, NULL, NULL);
			break;
		case MODULE_MANUAL:
			break; // Do Nothing
		case MODULE_SEND_ONLY:
			break;	// Do Nothing
		default:
			break; // Do Nothing
		} // End of Switch
	} // End of If
	return (CAMQ_NEW_MESSAGE_NOTIFICATION_SENT);
} // End of SignalMsgToProcess()
//****************************************************************************
/// Remove all messages from the Message Queue	
///	
/// @param[in] - none
///
/// @return CAMQ_ALL_MESSAGE_REMOVED - Queue has been emptied
///
//****************************************************************************
T_CAMQ_RETURN_VALUE CCircularArrayMsgQueue::RemoveAllMessagesFromMessageQueue(void) {
	// Remove All Items from the Message Queue, as the 
	// queue will wrap
	//
	for (USHORT msgIndex = CAMQ_DEFAULT_ZERO_VALUE; msgIndex < CAMQ_MAX_QUEUE_SIZE; msgIndex++) {
		if (NULL != m_MsgItem[msgIndex]) {
			ReleaseCommittedMemory(m_MsgItem[msgIndex]->m_MsgSize);
			m_MsgItem[msgIndex] = NULL;
			m_QueueStats.m_NumOfMsgsRemovedFromQueue++;
		}
	}
	// Reset Message Queue Variables
	//
	m_FrontOfQueue = CAMQ_DEFAULT_ZERO_VALUE;
	m_RearOfQueue = CAMQ_MAX_QUEUE_SIZE - 1; // 0 to max - 1
	m_NumOfMsgsToProcess = CAMQ_DEFAULT_ZERO_VALUE;
	// Reset Event
	//
	ResetEvent(m_hNewMessageAvailableInQueue);
	return (CAMQ_ALL_MESSAGE_REMOVED);
} // End of RemoveAllMessagesFromMessageQueue()

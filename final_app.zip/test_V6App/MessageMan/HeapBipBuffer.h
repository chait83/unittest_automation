/// @file 
/// *****************************************************************
/// © Honeywell Trendview
/// *****************************************************************
/// @n Module : Module Message Manager (MMM )
/// @n FileName: HeapBipBuffer.h
/// @n Desc  : Class Declaration for the HeapBipBuffer
///  
/// *****************************************************************
/// @b Revision @b History
/// *****************************************************************
/// $Log[4]:
/// 4 Stability Project 1.1.1.1 7/2/2011 4:57:50 PM Hemant(HAIL) 
/// Stability Project: Recorder source has been upgraded from IL
///  version of firmware to JF version of firmware.
/// 3 Stability Project 1.1.1.0 7/1/2011 4:26:59 PM Hemant(HAIL) 
/// Stability Project: Files has been checked in before the merging
///  task. The merging will be done between IL version of firmware and JF
///  version of firmware. 
/// 2 V6 Firmware 1.1 12/20/2006 3:19:03 PM  Jason Parker  
///  Removed Heap creation. Allocated memory block in general heap
///  instead.
/// 1 V6 Firmware 1.0 8/17/2004 2:05:25 PM  Alistair Brugsch 
/// $
///
#ifndef _HEAPBIPBUFFER_H
#define _HEAPBIPBUFFER_H
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "Defines.h"
const DWORD HEAPBIPBUFFER_HEAP_ABLE_TO_GROW = 0;
const USHORT HEAPBIPBUFFER_FOUR_BYTES = 4;
const USHORT HEAPBIPBUFFER_ZERO_VALUE = 0;
/// Values to be used to indicate which region of the buffer is in use
///
typedef enum {
	PRIMARY_REGION, SECONDARY_REGION
} T_HEAPBIPBUFFER_REGION;
/// Return Values for CHeapBipBuffer Member Functions, used to describe the type of 
/// success or failure.
///  
typedef enum {
	HEAPBIPBUFFER_COMMITTED_MEMORY_RELEASED, HEAPBIPBUFFER_HEAP_ALLOCATED, HEAPBIPBUFFER_HEAP_ERROR
} T_HEAPBIPBUFFER_RETURN_VALUE;
//**Class*********************************************************************
///
/// @brief Creates a circular Bi-Partial(BIP) buffer, using Heap Memory.  
/// 
/// A BIP-Buffer is a form of a circular buffer, but instead of keeping a head 
/// and tail pointer to the data, two revolving regions are used. The use of 
/// the two regions allows fast data access without the additional requirement 
/// of wrapping the end of the buffer. The Primary Region is where the data is 
/// written too, until no more data can be written due to the end of the buffer 
/// being reached. Data is always read from the Primary Region. A Secondary 
/// Region becomes available once data is released from the buffer, this region 
/// will be used once the primary region can no longer accept data because the 
/// end of the buffer has been reached. Both regions can be active at the same 
/// time, in terms of data is being read from the primary region, and data is 
/// being added to the secondary. Once the primary region has read all the data, 
/// the secondary region then becomes the primary region, and the process starts 
/// again. 
//****************************************************************************
class CHeapBipBuffer {
public:
	/// CHeapBipBuffer Constructor
	CHeapBipBuffer();
	/// CHeapBipBuffer Destructor
	virtual ~CHeapBipBuffer();
	/// Allocate the BIP Buffer using Heap Memory
	T_HEAPBIPBUFFER_RETURN_VALUE AllocatedHeapBipBuffer(USHORT heapSize);
	/// Commit an amount of memory in the buffer
	BYTE* CommitMemory(USHORT memorySize, USHORT &allocatedMemorySize);
	/// Release Committed Memory from the BIP Buffer
	T_HEAPBIPBUFFER_RETURN_VALUE ReleaseCommittedMemory(USHORT memorySize);
private:
	BYTE *m_pHeapBipBuffer; ///< Pointer to the start of the Heap Buffer.
	BYTE *m_pCurrentData;  ///< Pointer to the start of the available buffer. 
	BYTE *m_pAvailableSpace; ///< Pointer to the start of the buffer where data can be inserted.
	USHORT m_PrimRegionFreeSpace; ///< Amount of free space available in the Primary Region.
	USHORT m_SecRegionFreeSpace; ///< Amount of free space available in the Secondary Region.
	T_HEAPBIPBUFFER_REGION m_ReceivingRegion; ///< Primary or Secondary region is use.
	USHORT m_BipBufferSize; ///< The total size of the BIP Buffer, allocated.
	USHORT m_PrimCommittedMemSize; ///< Amount of used memory in the Primary Region.
	USHORT m_SecCommittedMemSize;  ///< Amount of used memory in the Secondary Region.
};
// End of CHeapBipBuffer Class Declaration 
#endif // _HEAPBIPBUFFER_H

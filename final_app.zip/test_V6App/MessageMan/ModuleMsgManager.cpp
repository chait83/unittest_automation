/// @file 
/// *****************************************************************
/// © Honeywell Trendview
/// *****************************************************************
/// @n Module : Module Message Manager (MMM )
/// @n FileName: ModuleMsgManager.cpp
/// @n Desc	: Implementation File for the Routines to create and 
///			manage the Module Message Queues. 
///
/// *****************************************************************
/// @b Revision @b History
/// *****************************************************************
/// $Log[4]:
/// 11	Stability Project 1.6.1.3	7/2/2011 4:58:52 PM	Hemant(HAIL) 
///		Stability Project: Recorder source has been upgraded from IL
///	version of firmware to JF version of firmware.
/// 10	Stability Project 1.6.1.2	7/1/2011 4:38:31 PM	Hemant(HAIL) 
///		Stability Project: Files has been checked in before the merging
///	task. The merging will be done between IL version of firmware and JF
///	version of firmware. 
/// 9	Stability Project 1.6.1.1	3/17/2011 3:20:30 PM	Hemant(HAIL) 
///		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
///	new operator in DEBUG mode only. To detect memory leaks in files, use
///	it in preprocessor definition when in debug mode.
/// 8	Stability Project 1.6.1.0	2/15/2011 3:03:22 PM	Hemant(HAIL) 
///		File updated during Heap Management. Call to the default behaviour
///	of new operator has been commented.
/// $
///
#include "ModuleMsgManager.h"
#include "V6defines.h"
#include "V6globals.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
#endif
/// Static Variable Initialisation, these variables will remain for the
/// lifetime of the application or system
CModuleMsgManager *CModuleMsgManager::m_pInstance = NULL; ///< Singleton Module Message Manager Instance
QMutex CModuleMsgManager::m_CreationMutex;		///< Singleton Mutex
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CModuleMsgManager::CModuleMsgManager() {
	for (USHORT moduleNumber = 0; moduleNumber < MODULE_NUM_OF_MODULES; moduleNumber++) {
		// Only Delete the Queues that have actually been created
		//	
		m_pMessageQueue[moduleNumber] = NULL;
	} // End of for
} // End of Constructor
CModuleMsgManager::~CModuleMsgManager() {
	// Do Nothing - Never Called
} // End of Destructor
//****************************************************************************	
/// Creates or return a pointer to an instance of CModuleMsgManager Singleton.
/// Uses a Double-Check Locking Pattern, for multi-threaded environments, if
/// creation of the Instance is required. 
///
/// @param - None
///
/// @return A Pointer to the single instance of CModuleMsgManager
///
/// @note Delete should never be called on this pointer, unless you are cleaning
///	up the class when the application / system is closing down. 
///
//****************************************************************************
CModuleMsgManager* CModuleMsgManager::GetHandle(void) {
	DWORD waitSingleObjectResult = WAIT_OBJECT_0;
	if (NULL == m_pInstance) {
		// An instance has yet to be completed
		//
		waitSingleObjectResult = m_CreationMutex.tryLock(g_dwSTD_WAIT_FOR_OBJ_TIMEOUT_IN_MS);
		switch (waitSingleObjectResult) {
		case WAIT_OBJECT_0:
			// Object was signaled
			//
			if (NULL == m_pInstance) {
				m_pInstance = new CModuleMsgManager;
				//qDebug("MMM singleton created - new() called\n");
			}
			m_CreationMutex.unlock();
			break;
		case WAIT_TIMEOUT:
		case WAIT_ABANDONED:
		case WAIT_FAILED:
		default:
			V6WarningMessageBox(NULL, "ModuleMsgManager WaitForSingleObject Error", "CModuleMsgManager Error", MB_OK);
			break;
		}
		// Close the Mutex as no longer required
		//
		//No need to close the mutex in Qt
	}
	return (m_pInstance);
} // End of GetHandle()
//**************************************************************************** 
/// De-allocate all the memory used in the construction of the Module Message
/// Manager, this includes the associated heap with each message queue. 
///
/// @param - None
///
/// @return whether the Message Queues are created, or errors occurred
///
//****************************************************************************
T_MODMSGMAN_RETURN_VALUE CModuleMsgManager::CleanUp(void) {
	// Delete each Message Queue that has been created
	//
	for (USHORT moduleNumber = 0; moduleNumber < MODULE_NUM_OF_MODULES; moduleNumber++) {
		// Only Delete the Queues that have actually been created
		//	
		if (NULL != m_pMessageQueue[moduleNumber]) {
			delete (m_pMessageQueue[moduleNumber]);
			m_pMessageQueue[moduleNumber] = NULL;
		}
	} // End of for
	// Delete the instance of the Module Message Manager
	//
	delete (m_pInstance);
	qDebug("MMM singleton deleted - delete() called\n");
	return (MODMSGMAN_CLEANUP_COMPLETE);
} // End of CleanUp()
//****************************************************************************
/// This Member creates a message queue for each module requiring communication
/// with one or more modules within the system, or if a module requires
/// communication to other devices on a Network. For each queue that is created,
/// a heap buffer is initialised with the size indicated by the user.	
///
/// @param - None
///
/// @return whether the Message Queues are created, or errors occurred
///
//****************************************************************************
T_MODMSGMAN_RETURN_VALUE CModuleMsgManager::InitialiseModules(void) {
	T_MODMSGMAN_RETURN_VALUE retValue = MODMSGMAN_MODULES_INITIALISED;
	for (USHORT moduleNumber = 0; moduleNumber < MODULE_NUM_OF_MODULES; moduleNumber++) {
		// Create the Message Queue for the module
		//
		m_pMessageQueue[moduleNumber] = new CCircularArrayMsgQueue((T_MODULE_ID) moduleNumber);
		if (NULL != m_pMessageQueue[moduleNumber]) {
			// Allocate the Heap Buffer for the newly created Message Queue 
			//
			if (HEAPBIPBUFFER_HEAP_ERROR
					== m_pMessageQueue[moduleNumber]->AllocatedHeapBipBuffer(ModuleHeapSize[moduleNumber])) {
				retValue = MODMSGMAN_MESSAGE_QUEUE_CREATION_ERROR;
			}
		} else {
			// Creation of Message Queue FAILED
			//
			retValue = MODMSGMAN_MESSAGE_QUEUE_CREATION_ERROR;
		}
	} // End of for
	return (retValue);
} // End of InitialiseModules() 

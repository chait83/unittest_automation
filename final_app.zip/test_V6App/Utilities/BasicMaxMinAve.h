/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	Utilities
/// @n Filename: BasicMaxMinAve.h
/// @n Desc:	Manage a basic max and min and averages for a reading
///				
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 3	Stability Project 1.0.1.1	7/2/2011 4:55:37 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 2	Stability Project 1.0.1.0	7/1/2011 4:27:28 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 1	V6 Firmware 1.0		4/28/2005 5:20:59 PM	Andy Kassell	
// $
//
// ****************************************************************
#ifndef __BASICMAXMINAVE_H__
#define __BASICMAXMINAVE_H__
#include "Defines.h"
//**Class*********************************************************************
///
/// @brief Basic max & min
/// 
/// Maintain a basic max and min value form a floating point reading
///
//****************************************************************************
class CBasicMaxMin {
public:
	CBasicMaxMin();
public:		// API methods
	void ResetMaxMin();				///< Reset the Max and Min to float limits
	void ResetMaxMin(float reading);				///< Reset the Max and Min to a current reading
	float GetMax() {
		return m_maxValue;
	}
	;		///< Get the max value
	float GetMin() {
		return m_minValue;
	}
	;		///< Get the min value
	virtual void DoMaxMinForReading(float reading);	///< Calculate the Main and Min Value 
private:	// Member variables
	float m_maxValue;									///< Current Max Value
	float m_minValue;									///< Current Min Value
};
//**Class*********************************************************************
///
/// @brief Basic averge, this is NOT a rolling average
/// 
/// Maintain a basic average value from a floating point reading
///
//****************************************************************************
class CBasicAverage {
public:
	CBasicAverage();
public:		// API methods
	void ResetAverage();	///< Reset the Average reading, emtpy with 0 value
	void ResetAverage(float reading);	///< Reset the Average reading to current reading
	float GetAverage();								///< Get the Average value
	virtual void DoAverageForReading(float reading);							///< Calculate the Main and Min Value
	void InitialiseAverage(USHORT penNumber);		///< Initialise the average
private:	// Member variables
	double m_runningAverageTotal;	///< Running total of reading for averaging
	ULONG m_numberOfReadingInAverage;	///< Current number of readings in the average value
};
#endif //__BASICMAXMINAVE_H__

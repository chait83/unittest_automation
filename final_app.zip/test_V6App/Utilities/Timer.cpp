//////////////////////////////////////////////////////////////////////
/// @file
/// *******************************************
/// © Honeywell Trendview
/// *******************************************
/// V6 I/O scheduler
/// @n Timer.h
/// @n implementation for a high resolution timer.
/// @author GKW
/// @date 28/07/2004
///
// 
// *******************************************
// Revision History
// *******************************************
// $Log[4]:
//
//////////////////////////////////////////////////////////////////////
#include "Timer.h"
double CTimer::tfreq = getSystemFreq();
CTimer::CTimer() {
	// constructor
	nFrames = 0;
	// perform calibration
	starttimer();
	stoptimer();
	tcorrection = (double) (endCount.QuadPart - startCount.QuadPart);
}
CTimer::~CTimer() {
	// destructor
}
//******************************************************
// starttimer()
///
/// Starts a new timer session
///
//******************************************************
void CTimer::starttimer(void) {
	time = 0.0;
	QueryPerformanceCounter(&startCount);
	tstart = (double) startCount.QuadPart;
}
//******************************************************
// stoptimer()
///
/// Stops the timer, this session
///
//******************************************************
void CTimer::stoptimer(void) {
	QueryPerformanceCounter(&endCount);
	tstop = (double) endCount.QuadPart;
}
//******************************************************
// timeintv()
///
/// Measure the time between the starttimer() event and stoptimer() event being issued
///
/// @return the time for this session
/// 
//******************************************************
double CTimer::timeintv(void) {
	return (tstop - tstart - tcorrection) / (tfreq);
}
//******************************************************
// getSystemFreq()
///
/// Obtains the system frequency
///
/// @return the frequency of the system timer
/// 
//******************************************************
double CTimer::getSystemFreq(void) {
	LARGE_INTEGER timerFrequency;
	QueryPerformanceFrequency(&timerFrequency);
	return (double) timerFrequency.QuadPart;
}
//******************************************************
// timeCheck()
///
/// Schedules the next run time, from now
/// @param[in] interval - The interval until the next schedule.
///
/// @return the time for next scheduled operation
/// 
//******************************************************
LONGLONG CTimer::timeCheck(LONGLONG schedTime) {
	LARGE_INTEGER now;
	QueryPerformanceCounter(&now);
	return (LONGLONG) (now.QuadPart - schedTime);
}
//******************************************************
// scheduleRuntime()
///
/// Schedules the next run time, from now
/// @param[in] interval - The interval until the next schedule.
///
/// @return the time for next scheduled operation
/// 
//******************************************************
LONGLONG CTimer::scheduleRuntime(double interval) {
	LARGE_INTEGER now;
	QueryPerformanceCounter(&now);
	return (LONGLONG) (now.QuadPart + (interval * tfreq));
}
//******************************************************
// scheduleTimeTo()
///
/// Tests the time until scheduled operation required
/// @param[in] schedule - Next scheduled time.
///
/// @return the time duration until scheduled operation
/// 
//******************************************************
LONGLONG CTimer::scheduleTimeTo(LONGLONG schedule) {
	LARGE_INTEGER now;
	QueryPerformanceCounter(&now);
	return (LONGLONG) schedule - now.QuadPart;
}
//******************************************************
// scheduleTimeTo()
///
/// Schedules the next run time, from previous schedule point
/// @param[in] lastSchedule - Schedule reference point.
/// @param[in] interval - The interval until the next schedule.
///
/// @return the time the next scheduled operation is due.
/// 
//******************************************************
LONGLONG CTimer::scheduleReferencedRuntime(LONGLONG lastSchedule, double interval) {
	return (lastSchedule + (LONGLONG) (interval * tfreq));
}

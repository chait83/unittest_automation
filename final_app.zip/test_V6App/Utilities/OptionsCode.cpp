/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	 Utilties
/// @n Filename: OptionsCode.cpp
/// @n Desc:	 Build/decipher options code
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
//  6 Stability Project 1.1.1.3 7/2/2011 4:59:21 PM Hemant(HAIL) 
// Stability Project: Recorder source has been upgraded from IL
//  version of firmware to JF version of firmware.
//  5 Stability Project 1.1.1.2 7/1/2011 4:38:34 PM Hemant(HAIL) 
// Stability Project: Files has been checked in before the merging
//  task. The merging will be done between IL version of firmware and JF
//  version of firmware. 
//  4 Stability Project 1.1.1.1 3/17/2011 3:20:32 PM  Hemant(HAIL) 
// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//  new operator in DEBUG mode only. To detect memory leaks in files, use
//  it in preprocessor definition when in debug mode.
//  3 Stability Project 1.1.1.0 2/15/2011 3:03:35 PM  Hemant(HAIL) 
// File updated during Heap Management. Call to the default behaviour
//  of new operator has been commented.
// $
//
// ****************************************************************
#include "OptionsCode.h"
#include "V6crc.h"
#include <math.h>
#include <wchar.h>
//const int SECURECOMM_VALUE	= 4;
const int PASSWORDCFR_VALUE = 2;
const int PASTRISTAION_VALUE = 1;
//=========================================================================
// Options code has following format
// 13 digit code in the format of AAAAAABCCDDDD where
// AAAAAA	= 6 digit serial number (999999 default)
// B		= fixed options of pasturisation(1) or CFR passwords(2) or both(3)
// CC		= 2 digit number of credits
// DDDD		= Basic CRC of AAAAAABCC 
//=========================================================================
//*************************************************************************************
/// Method that generates an options code part AAAAAABCC, use EncodeOptionsCode to add DDDD
/// 
///
/// @param[in, out]	rstrOptionsCode - Pointer to the options code to validate
/// @param[in]		Serial - Serial number to set
/// @param[in]		Credits - number of credits 
/// @param[in]		PasswordCFR - CFR password option 
/// @param[in]		Pasturisation - Pasturisation option 
///
/// @return		True if the options code was valid
///
//*************************************************************************************
void COptionCode::CreateOptionsCode(QString &rstrOptionsCode, ULONG Serial, ULONG Credits, BOOL PasswordCFR,
		BOOL Pasturisation, /*BOOL SecureComm,*/int devType) {
	int presetOptions = 0;
	if (PasswordCFR == TRUE) {
		presetOptions += PASSWORDCFR_VALUE;
	}
	if (Pasturisation == TRUE) {
		presetOptions += PASTRISTAION_VALUE;
	}
	/*if ( SecureComm == TRUE )
	 {
	 presetOptions += SECURECOMM_VALUE;
	 }*/
	if (devType == DEV_XSERIES)
        rstrOptionsCode = QString::asprintf("%06ld%1d%02ld", Serial, presetOptions, Credits);
	else
		rstrOptionsCode = QString::asprintf("%06d%1d%03d", Serial, presetOptions, Credits);
}
//**************************************************************************************
/// 
/// Method that encodes the options code, essentially add "DDDD" to "AAAAAABCC"
///
/// @param[in/out]			const QString  &rstrOptionsCode - String containing the options code - the 
///							encoded value is added to this string
///
//**************************************************************************************
void COptionCode::EncodeOptionsCode(QString &rstrOptionsCode, int devType) {
	USHORT usCode = 0;
	char optCode[40];
#if _MSC_VER < 1400 
	sprintf(optCode, "%S", rstrOptionsCode.toLocal8Bit().data());
#else
	sprintf_s( optCode, 40, "%S", rstrOptionsCode );
#endif
	usCode = CrcCalc((UCHAR*) optCode, strlen(optCode));
	QString strCode("");
	if (devType == DEV_XSERIES)
		strCode = QString::asprintf("%04d", 10000 - (usCode % 10000));
	else
		strCode = QString::asprintf("%05d", 100000 - (usCode % 100000));
	rstrOptionsCode += strCode;
}
//*************************************************************************************
/// Method that validates and deciphers an encoded options code and sets credits, Password and Pasturistaion if valid
///
/// @param[in]		pwcOptionsCode - Pointer to the options code to validate
/// @param[in]		Serial - Serial number to validate against
/// @param[out]		Credits - reference to number of credits extracted from options code
/// @param[out]		PasswordCFR - reference to CFR password option extracted from options code
/// @param[out]		Pasturisation - reference to Pasturisation option extracted from options code
///
/// @return		True if the options code was valid
///
//*************************************************************************************
bool COptionCode::DecipherOptionsCode(const QString pwcOptionsCode, ULONG Serial, ULONG &Credits,
		BOOL &PasswordCFR, BOOL &Pasturisation, /*BOOL &SecureComm,*/int devType) {
	bool bValid = false;
	// the code will be broken down as follows - the first six bytes must match the serial number, the
	// next two bytes will be the number of credits and the last 4 bytes will be the encoded string proving
	// the data has not been altered
	// confirm the string is the correct length
	QString strOptionsCode("");
	strOptionsCode = QString::asprintf("%s", pwcOptionsCode.toLocal8Bit().data());
	int OpCodeLength = 15;
	if (devType == DEV_XSERIES)
		OpCodeLength = 13;
	if (strOptionsCode.size() == OpCodeLength) {
		// extract the first 6 bytes
		QString strSerialNo(strOptionsCode);
		strSerialNo = strSerialNo.left(6);
        QString pwcStopChar = "";
        ULONG ulSerialNo = strSerialNo.toULong();
		if (ulSerialNo == Serial) {
			// serial number is okay, now check the encoded value
			QString strOriginalStr(strOptionsCode);
			if (devType == DEV_XSERIES)
				strOptionsCode = strOptionsCode.left(9);
			else
				strOptionsCode = strOptionsCode.left(10);
			EncodeOptionsCode(strOptionsCode);
			if (strOriginalStr == strOptionsCode) {
				// the data is valid therefore extract and set the new number of credits and return true
				QString strCredits(strOptionsCode);
				if (devType == DEV_XSERIES)
					strCredits = strCredits.mid(7, 2);
				else
					strCredits = strCredits.mid(7, 3); // Credits 3 digits now.. 
				QString strFixedOptions(strOptionsCode);
				strFixedOptions = strFixedOptions.mid(6, 1);
				char *str = strFixedOptions.toLocal8Bit().data();
				switch (str[0] - '0') {
				case PASTRISTAION_VALUE:
					PasswordCFR = FALSE;
					Pasturisation = TRUE;
					//SecureComm	= FALSE;
					break;
				case PASSWORDCFR_VALUE:
					PasswordCFR = TRUE;
					Pasturisation = FALSE;
					//	SecureComm	= FALSE;
					break;
					/*	case SECURECOMM_VALUE:
					 PasswordCFR = FALSE;
					 Pasturisation = FALSE;
					 SecureComm	= TRUE;
					 break;*/
				case PASSWORDCFR_VALUE + PASTRISTAION_VALUE:
					PasswordCFR = TRUE;
					Pasturisation = TRUE;
					//	SecureComm	= FALSE;
					break;
					/*case PASSWORDCFR_VALUE + SECURECOMM_VALUE:
					 PasswordCFR = TRUE;
					 Pasturisation = FALSE;
					 SecureComm	= TRUE;
					 break;
					 case PASTRISTAION_VALUE + SECURECOMM_VALUE:
					 PasswordCFR = FALSE;
					 Pasturisation = TRUE;
					 SecureComm	= TRUE;
					 break;
					 case PASSWORDCFR_VALUE + PASTRISTAION_VALUE + SECURECOMM_VALUE:
					 PasswordCFR = TRUE;
					 Pasturisation = TRUE;
					 SecureComm	= TRUE;
					 break;*/
				default:
					PasswordCFR = FALSE;
					Pasturisation = FALSE;
//						SecureComm	= FALSE;
					break;
				}
                Credits = strCredits.toULong();
				bValid = true;
			}
		}
	}
	return bValid;
}
// Option tester
void COptionCode::UniqueCodeChecker() {
	QString strTest;
	int serno, credits, opts;
	for (serno = 800000; serno < 800099; serno++) {
		for (credits = 0; credits < 2; credits++) {
			for (opts = 0; opts < 4; opts++) {
				strTest = QString::asprintf("%06d%1d%02d", serno, opts, credits);
				EncodeOptionsCode(strTest);
				qDebug(strTest.toLocal8Bit().data());
				qDebug("\n");
			}
			qDebug(strTest.toLocal8Bit().data());
			qDebug("----------------\n");
		}
        qDebug(strTest.toLocal8Bit().data());
		qDebug("================\n");
	}
}

/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	Utilties
/// @n Filename: TV6Timer.cpp
/// @n Desc:	Routines to provide timing, both std (mSec) and 
///				high performance (uSec)
///
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 10	Stability Project 1.7.1.1	7/2/2011 5:02:13 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 9	Stability Project 1.7.1.0	7/1/2011 4:26:46 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 8	V6 Firmware 1.7		9/23/2008 3:09:34 PM	Build Machine 
//		AMS2750 Merge
// 7	V6 Firmware 1.6		6/21/2006 3:17:15 PM	Andy Kassell	Add
//		rollover code to normal resolution timer
// $
//
// ****************************************************************
#include "TV6Timer.h"
#define MSEC_PER_SEC	1000			///< Milliseconds per second
#define USEC_PER_SEC	1000000			///< Microseconds per second
#define USEC_PER_MSEC	1000			///< Microseconds per Millisecond
#include <unistd.h>
#include <time.h>
DWORD CTV6Timer::GetTickCount() {
	struct timespec ts;
	DWORD theTick = 0U;
	clock_gettime(CLOCK_REALTIME, &ts);
	theTick = ts.tv_nsec / 1000000;
	theTick += ts.tv_sec * 1000;
	return theTick;
}
//**********************************************************************
/// CTV6Timer constructor
///
/// @param[in]	type - resolution of timer required, TIMER_HIGH_RES for uSec
///						or TIMER_NORMAL_RES for mSec 
///
//**********************************************************************
CTV6Timer::CTV6Timer(T_TIMER_RESOLUTION type) {
	m_Type = type;
	ResetAllTimers();	// Reset All timers
	// Get the frequency of the system clock (clock speed in Hz)
	LARGE_INTEGER queryFreq;
	/// TODO : Get the clock frequency of the system.
//	QueryPerformanceFrequency(&queryFreq);
	m_clockFreq = (DWORD) queryFreq.QuadPart;
	// If the returned frequency is 0 then no High Resolutiuon time support is available
	// so we must use the std timer routines
	if (m_clockFreq == 0) {
		m_Type = TIMER_NORMAL_RES;
	} else {
		// Calculate the Millisecond and Microsecond ratios for the High Performance Timer
		m_milliSecGearing = (double) m_clockFreq / MSEC_PER_SEC;
		m_microSecGearing = (double) m_clockFreq / USEC_PER_SEC;
	}
	m_LastTickTime = 0;
	m_Running = FALSE;
}
//**********************************************************************
/// Reset all timers within the timer object
///
/// @return		Nothing 
///
//**********************************************************************
void CTV6Timer::ResetAllTimers() {
	// Reset all splitTimers
	for (int i = 0; i < TIMER_TOTAL_TIMERS; i++)
		m_timer[i].QuadPart = 0;
	ResetMaxMin();
}
//**********************************************************************
/// Reset the Max and Mins, setting Max to 0 and Min to Max size for LONGLONG
///
/// @return		Nothing 
///
//**********************************************************************
void CTV6Timer::ResetMaxMin() {
	m_timer[TIMER_MAX].QuadPart = 0;
	m_timer[TIMER_MIN].QuadPart = MAX_LONGLONG;
}
//**********************************************************************
/// Start the timer from current time. Use this to baseline the timer
///
/// @return		Nothing 
///
//**********************************************************************
void CTV6Timer::StartTimer() {
	m_timer[TIMER_BASE].QuadPart = 0;
	if (m_Type == TIMER_NORMAL_RES) {
		// Get current time from 1ms resolution timer
		///TODO find alt for GetTickCount
//		m_timer[TIMER_BASE].LowPart = GetTickCount();
		m_LastTickTime = m_timer[TIMER_BASE].LowPart;
	} else {
		// Get current time of performance timer
		///TODO indexOf alt for QueryPerformanceCounter
//		QueryPerformanceCounter(&m_timer[TIMER_BASE]);
	}
	m_theTime.QuadPart = 0;
	m_timer[TIMER_SINGLE].QuadPart = 0;	// Reset current timer
	m_Running = TRUE;
}
//**********************************************************************
/// Update the current timer, this will also update the max and min times
/// use in multiple Starts and Updates. Max and Min run over the lifetime of
/// the object
///
/// @return		Nothing 
///
//**********************************************************************
void CTV6Timer::StopTimer() {
	// Get the latest Time 
	GetTimeOffSetFromBase();
	// Do Max check and update if Exceeded
	if (m_timer[TIMER_SINGLE].QuadPart > m_timer[TIMER_MAX].QuadPart)
		m_timer[TIMER_MAX].QuadPart = m_timer[TIMER_SINGLE].QuadPart;
	// Do Min check and Update if Exceeded
	if (m_timer[TIMER_SINGLE].QuadPart < m_timer[TIMER_MIN].QuadPart)
		m_timer[TIMER_MIN].QuadPart = m_timer[TIMER_SINGLE].QuadPart;
	m_Running = FALSE;
}
//**********************************************************************
/// Returns the elapsed time in microseconds from the start of the timer
/// Not affected by time stop
///
/// @return		Nothing 
///
//**********************************************************************
LONGLONG CTV6Timer::ElapsedTimeInMicroSeconds() {
	// Get the latest Time 
	GetTimeOffSetFromBase();
	return GetTimeInMicroSec(TIMER_SINGLE);
}
//**********************************************************************
/// Returns the elapsed time in milliseconds from the start of the timer
/// Not affected by time stop
///
/// @return		Nothing 
///
//**********************************************************************
LONGLONG CTV6Timer::ElapsedTimeInMilliSeconds() {
	// Get the latest Time 
	GetTimeOffSetFromBase();
	return GetTimeInMilliSec(TIMER_SINGLE);
}
//**********************************************************************
/// Returns the recorded time(uSec) since start timer, until stop timer
///
/// @return		time in uSec 
//**********************************************************************
LONGLONG CTV6Timer::RecordedTimeInMicroSeconds() {
	LONGLONG retTime = 0;
	if (m_Running == TRUE) {
		retTime = ElapsedTimeInMicroSeconds();	// Timer still running so get time so far
	} else {
		retTime = GetTimeInMicroSec(TIMER_SINGLE);	// Timer stopped, get completed time
	}
	return retTime;
}
//**********************************************************************
/// Returns the recorded time(mSec) since start timer, until stop timer
///
/// @return		time in mSec 
//**********************************************************************
LONGLONG CTV6Timer::RecordedTimeInMilliSeconds() {
	LONGLONG retTime = 0;
	if (m_Running == TRUE) {
		retTime = ElapsedTimeInMilliSeconds();	// Timer still running so get time so far
	} else {
		retTime = GetTimeInMilliSec(TIMER_SINGLE);	// Timer stopped, get completed time
	}
	return retTime;
}
//**********************************************************************
/// Get the time of the timer in Milliseconds 1/1000th of a sec
///
/// @param[in]	timer - ID of timer to get in mSec, see T_TIMER_TYPE in TV6Timer.h
///
/// @return		timespan of timer requested, or 0 if invalid timer 
///
//**********************************************************************
LONGLONG CTV6Timer::GetTimeInMilliSec(T_TIMER_TYPE timer) {
	LONGLONG calcTimer = m_timer[timer].QuadPart;
	// If timer is High performance then scale to mSec, as Normal res
	// timers are already mSec then return these directly
	if (m_Type == TIMER_HIGH_RES) {
		calcTimer = (LONGLONG) (calcTimer / m_milliSecGearing);	// Divide by clock frequency gearing for MilliSeconds
	}
	return calcTimer;
}
//**********************************************************************
/// Get the time of the timer in Microseconds 1/1,000,000th of a sec as a LONGLONG (8 bytes)
///
/// @param[in]	timer - ID of timer to get in uSec, see T_TIMER_TYPE in TV6Timer.h
///
/// @return		timespan of timer requested, or 0 if invalid timer 
///
//**********************************************************************
LONGLONG CTV6Timer::GetTimeInMicroSec(T_TIMER_TYPE timer) {
	LONGLONG calcTimer = m_timer[timer].QuadPart;
	// If timer is High performance then scale to uSec, as Normal res
	// timers are already mSec then scale down to uSec
	if (m_Type == TIMER_HIGH_RES) {
		calcTimer = (LONGLONG) (calcTimer / m_microSecGearing);	// Divide by clock frequency gearing for MicroSeconds
	} else {
		calcTimer *= USEC_PER_MSEC;		// Multiply mSec up to Usec
	}
	return calcTimer;
}
//**********************************************************************
/// Set the split time of current timer, up to 5 are allowed
///
/// @param[in]	timer - ID of split timer, use TIMER_SPLIT1 to TIMER_SPLIT5
///
/// @return		TRUE if split time set, FALSE if invalid timer
///
//**********************************************************************
BOOL CTV6Timer::SetSplitTime(T_TIMER_TYPE splitTimer) {
	LONGLONG theSplit = GetTimeOffSetFromBase();
	if (splitTimer >= TIMER_SPLIT1 && splitTimer <= TIMER_SPLIT5) {
		m_timer[splitTimer].QuadPart = theSplit;
		return TRUE;
	} else {
		return FALSE;
	}
}
//**********************************************************************
/// Get the current time offset after timer started, used to supply split times and current times
///
/// @return		time offset in desired units, high performance in ticks not uSec at this point
///
//**********************************************************************
LONGLONG CTV6Timer::GetTimeOffSetFromBase() {
	if (m_Type == TIMER_NORMAL_RES) {
		// The GetTickCount will roll on 49.7 days, so we keep a running difference
		// from the timer start (not CE start)
		DWORD newTickTime = GetTickCount();
		DWORD TickDifference = 0;
		// If new tick time is smaller then the last tick timer then an overflow has occured
		if (newTickTime < m_LastTickTime) {
			TickDifference = (0xFFFFFFFF - m_LastTickTime) + newTickTime;
		} else {
			TickDifference = newTickTime - m_LastTickTime;
		}
		m_LastTickTime = newTickTime;
		m_timer[TIMER_SINGLE].QuadPart += TickDifference;
	} else {
		// Get count in uSec, this timer is zero based from CE boot, so to get an absolute span
		// the TIMER_BASE is subrtracted
		m_theTime.QuadPart = 0;
		/// TODO
//		QueryPerformanceCounter(&m_theTime);		// Get current time from performance counter
		m_timer[TIMER_SINGLE].QuadPart = m_theTime.QuadPart - m_timer[TIMER_BASE].QuadPart;
	}
	return m_timer[TIMER_SINGLE].QuadPart;
}
//**********************************************************************
/// Trace out valid information to qDebug Windows
///
/// @param[in]	*pTimerName - Text name of timer for ease of use
/// @return		nothing
///
//**********************************************************************
void CTV6Timer::TraceTimer(char *pTimerName) {
	WCHAR resTxt[10];
	LONGLONG (CTV6Timer::*pFunc)(T_TIMER_TYPE timer);
	// Get either Millisecond or Microsecond times depending on resolution required
	if (m_Type == TIMER_NORMAL_RES) {
#if _MSC_VER < 1400 
		wcscpy(resTxt, L"mSec");
#else
		wcscpy_s( resTxt, 10, L"mSec" );
#endif
		pFunc = &CTV6Timer::GetTimeInMilliSec;
	} else {
#if _MSC_VER < 1400 
		wcscpy(resTxt, L"uSec");
#else
		wcscpy_s( resTxt, 10, L"uSec" );
#endif
		pFunc = &CTV6Timer::GetTimeInMicroSec;
	}
	qDebug("\n %s Timer single=%d %s\n ", pTimerName, (ULONG) ((this->*pFunc)(TIMER_SINGLE)), resTxt);
	if (m_timer[TIMER_MAX].QuadPart > m_timer[TIMER_MIN].QuadPart)
		qDebug(" %s Timer MIN=%d MAX=%d %s\n", pTimerName, (ULONG) ((this->*pFunc)(TIMER_MIN)),
				(ULONG) ((this->*pFunc)(TIMER_MAX)), resTxt);
	for (int i = TIMER_SPLIT1; i <= TIMER_SPLIT5; i++) {
		if (m_timer[i].QuadPart != 0)
			qDebug(" %s Timer Split%d=%d %s\n", pTimerName, i - TIMER_SPLIT1 + 1,
					(ULONG) ((this->*pFunc)((T_TIMER_TYPE) i)), resTxt);
	}
}
void TestTV6Timer() {
	CTV6Timer highTimer(TIMER_HIGH_RES);
	CTV6Timer normTimer(TIMER_NORMAL_RES);
	// Start normal res timer
	normTimer.StartTimer();
	// Start high res timer
	highTimer.StartTimer();
	sleep(10);
	// sleep a while then set split 1
	highTimer.SetSplitTime(TIMER_SPLIT1);
	sleep(10);
	// sleep a while then set split 2
	highTimer.SetSplitTime(TIMER_SPLIT2);
	sleep(10);
	// another sleep then complete timing
	highTimer.StopTimer();
	// Complete normal timer
	normTimer.StopTimer();
	highTimer.TraceTimer("HighRes with Splits");
	normTimer.TraceTimer("Normal straight");
	highTimer.ResetAllTimers();
	// Perform some max & min timeouts
	for (int i = 10; i < 100; i += 5) {
		highTimer.StartTimer();
		sleep(i);
		highTimer.StopTimer();
	}
	highTimer.TraceTimer("HighRes with MM");
}

/// @file 
/// *****************************************************************
/// © Honeywell Trendview
/// *****************************************************************
/// @n Module : Internal Message Queue ( IMQ )
/// @n FileName: InternalMessageQueue.h
/// @n Desc  : Class Declaration for the CInternalMessageQueue
///
/// *****************************************************************
/// @b Revision @b History
/// *****************************************************************
/// $Log[4]:
/// 6 Stability Project 1.3.1.1 7/2/2011 4:58:00 PM Hemant(HAIL) 
/// Stability Project: Recorder source has been upgraded from IL
///  version of firmware to JF version of firmware.
/// 5 Stability Project 1.3.1.0 7/1/2011 4:27:00 PM Hemant(HAIL) 
/// Stability Project: Files has been checked in before the merging
///  task. The merging will be done between IL version of firmware and JF
///  version of firmware. 
/// 4 V6 Firmware 1.3 7/5/2006 8:23:23 PM Jason Parker  
///  Allow a larger queue
/// 3 V6 Firmware 1.2 7/4/2006 6:48:34 PM Jason Parker  
///  re-arranged T_IMQ_RETURN_VALUE - putting 'error' conditions at the
///  bottom
/// $
///
#ifndef _INTERNALMESSAGEQUEUE_H
#define _INTERNALMESSAGEQUEUE_H
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include <QMutex>
#include "HeapBipBuffer.h"
#include "InternalMessage.h"
#include "InternalMessageQueueStats.h"
/// Maximum Number of Message Items Allowed at one time
//
const USHORT IMQ_MAX_MESSAGE_ITEMS = 100;
/// Minimum Number of Message Items
//
const USHORT IMQ_MIN_MESSAGE_ITEMS = 1;
/// Constant to represent the value Zero
//
const USHORT IMQ_DEFAULT_ZERO_VALUE = 0;
/// Return Values for CInternalMessageQueue Member Functions, used to describe the type of 
/// success or failure.
//
typedef enum {
	IMQ_OK,
	IMQ_INITIALISED,
	IMQ_EMPTY,
	IMQ_SPACE_AVAILABLE,
	IMQ_ITEM_AVAILABLE,
	IMQ_MESSAGE_POSTED,
	IMQ_MESSAGE_SIGNALLED,
	IMQ_MESSAGE_REMOVED,
	IMQ_QUEUE_STATS_UPDATED,
	IMQ_ERROR,					// error conditions BELOW here
	IMQ_FULL,
	IMQ_INITIALISATION_FAILED,
	IMQ_BIP_BUFFER_FULL,
} T_IMQ_RETURN_VALUE;
/// Message Notification Mode
//
typedef enum {
	IMQ_USE_MANUAL, IMQ_USE_EVENT, IMQ_USE_POST_THREAD_MESSAGE
} T_IMQ_NEW_MESSAGE_NOTIFICATION;
//**Class*********************************************************************
///
/// @brief Creates a FIFO Message Queue, which interfaces directly to allocated 
///  heap memory.  
/// 
/// Provides the functionality to create a FIFO message queue, and allows messages
/// to be added, retrieved and removed from the queue. The queue is
/// constructed using an array, this ensures efficiency when adding and removing
/// items. An index to the front and rear are stored and incremented and decrement
/// accordingly. If a linked list immplementation was used memory would have to be
/// allocated and deallocated on adding/removing items. This class directly provides 
/// an overlay to a heap buffer which contains the message data. The Heap Buffer
/// stores the bytes of data and has no concept of messages. The Message Queue
/// class interprets the bytes of data stored into messages that can be used.
/// For efficency, data read from the message queue is not released, instead a 
/// pointer is returned so that the user can obtain the data directly. Once the 
/// user has finished reading the message, they call a release message function 
/// that will then remove the message from the queue. The owner of the Message
/// Queue is informed of a message is avialble either through an event being 
/// triggered, thread message being posted to them or manually checking the queue 
/// periodically. The queue has a maximum number of queue items, the user does 
/// have the option to specify the number of items upto the maximum allowed. 
///
/// The class is thread-safe within the same process.
/// 
/// Statistics are stored within the class to provide the user will information
/// regarding loading, and the amount of data being received. 
///
/// @note Message Queue does not support Priority Messages
///
//****************************************************************************
#include "EventWrapper.h"
class CInternalMessageQueue: public CHeapBipBuffer,EventWrapper {
public:
	/// Constructor
	CInternalMessageQueue();
	/// Destructor
	virtual ~CInternalMessageQueue();
	/// Initialise the Message Queue to user requirements
	T_IMQ_RETURN_VALUE InitInternalMessageQueue(USHORT numOfMessageItems, USHORT heapSize, DWORD threadIdToNotify,
			T_IMQ_NEW_MESSAGE_NOTIFICATION notificationMethod);
	/// Post an Internal Message to the Message Queue
	T_IMQ_RETURN_VALUE PostInternalMessage(T_IMQ_MESSAGE_TYPE messageType, USHORT dataLength, BYTE *pData);
	/// Read a message from the Message Queue
	const CInternalMessage* ReadInternalMessage(void);
	/// Remove the first item in the Message Queue
	T_IMQ_RETURN_VALUE RemoveInternalMessage(void);
	/// Obtain the handler for the event which signals new messages avialable
    EventWrapper* GetEventHandler(void);
	/// Get the Number of Messages within the Message Queue
	USHORT GetNumberOfMessagesInQueue(void);
	/// Get the Message Queue Statistics
	CInternalMessageQueueStats GetMessageQueueStats(void);
private:
	/// Obtain whether the Queue is FULL, EMPTY, or SPACE AVAILABLE
	T_IMQ_RETURN_VALUE InternalMessageQueueStatus(void);
	/// Signal messages are available
	T_IMQ_RETURN_VALUE SignalNewMessageAvailable(void);
	/// Update Queue Statistics
	T_IMQ_RETURN_VALUE UpdateIMQueueStats(void);
	static QMutex m_csMessageQueueCriticalSection; ///< Critical Section for the Message Queue
	CInternalMessage *m_MsgItem[IMQ_MAX_MESSAGE_ITEMS]; ///< Array of Message Items
	USHORT m_UserMaxNumOfMessageItems;  ///< Maximum number of items set by user 
	USHORT m_NumOfItemsInQueueToProcess; ///< Number of Messages within Queue to Process
	USHORT m_RearOfQueue;				 ///< Position of the Rear of the Queue
	USHORT m_FrontOfQueue;				 ///< Postion of the Front of the Queue
	T_IMQ_NEW_MESSAGE_NOTIFICATION m_NotificationMethod; ///< Notification method, Event or Thread Message or Manual.
    EventWrapper* m_hNewMessageEvent;	 ///< Event Handler to determine message are waiting to be processed
	DWORD m_DestinationThreadId; ///< Destination Thread which will receive messages
	CInternalMessageQueueStats m_QueueStats; ///< Queue Statistics
};
// End of CInternalMessageQueue Declaration
#endif // _INTERNALMESSAGEQUEUE_H

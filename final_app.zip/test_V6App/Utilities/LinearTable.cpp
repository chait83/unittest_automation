/// @file 
/// ****************************************************************
/// © Honeywell Trendview
/// ****************************************************************
/// @n Module:	Utilities
/// @n Filename: LinearTable.cpp
/// @n Desc:	Provide a table lookup linearisation facility
///				
// ****************************************************************
// Revision History
// ****************************************************************
// $Log[4]:
// 15	Stability Project 1.10.1.3	7/2/2011 4:58:21 PM	Hemant(HAIL) 
//		Stability Project: Recorder source has been upgraded from IL
//		version of firmware to JF version of firmware.
// 14	Stability Project 1.10.1.2	7/1/2011 4:38:26 PM	Hemant(HAIL) 
//		Stability Project: Files has been checked in before the merging
//		task. The merging will be done between IL version of firmware and JF
//		version of firmware. 
// 13	Stability Project 1.10.1.1	3/17/2011 3:20:27 PM	Hemant(HAIL) 
//		Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
//		new operator in DEBUG mode only. To detect memory leaks in files, use
//		it in preprocessor definition when in debug mode.
// 12	Stability Project 1.10.1.0	2/15/2011 3:03:13 PM	Hemant(HAIL) 
//		File updated during Heap Management. Call to the default behaviour
//		of new operator has been commented.
// $
//
// ****************************************************************
#include "float.h"
#include "LinearTable.h"
#include "math.h"
#ifdef _DEBUG
#ifdef _STD_HEAP_IMPLMT_
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#endif
#ifdef DBG_FILE_LOG_LNR_TBL_DBG_ENABLE
CDebugFileLogger CLinearTable::m_debugFileLogger(L"\\SDMemory\\LinearTableDbgLog.txt", TRUE, 20*1024*1024 );
#endif
//**********************************************************************
/// CLinearTable constructor
///
//**********************************************************************
CLinearTable::CLinearTable(void) {
	m_pSourceTable = NULL;
	m_pReferenceTable = NULL;
}
//**********************************************************************
/// CLinearTable destructor
///
//**********************************************************************
CLinearTable::~CLinearTable() {
	FreeTables();
}
//**********************************************************************
///
/// Free off memeory used by linearisation tables
///
/// @return		nothing
/// 
//**********************************************************************
void CLinearTable::FreeTables() {
	if (m_pSourceTable != NULL) {
		delete[] m_pSourceTable;
	}
	if (m_pReferenceTable != NULL) {
		delete[] m_pReferenceTable;
	}
	m_pSourceTable = NULL;
	m_pReferenceTable = NULL;
}
//**********************************************************************
///
/// Generate a user defined linearisation table header
///
/// @param[in]	- ptr to the input table header
/// @param[in]	inTable - ptr to an array of T_IP_TABLE_ELEMENT's forming the input table
/// @param[in]	noEntries - number of entries in the input table inTable
/// @param[in]	suggElements - suggested number of elements to generate, can extend the resolution of a table
/// @param[in]	direction - build a normal(NORMAL_TABLE) or reverse(REVERSE_TABLE) lookup from source table
/// 
/// @return		T_TABLE_RETURN value showing status
/// 
//**********************************************************************
T_TABLE_RETURN CLinearTable::GenerateUserTableHdr(T_PDEVICETABLEHDR pSensorHdr, T_PIP_TABLE_ELEMENT inTable,
		const USHORT DeviceID, const USHORT noEntries) {
	float IPRangeLow;					// Minimum table I/P value
	float IPRangeHigh;				// Maximum table I/P value
	float OPRangeLow;					// Minimum table O/P value
	float OPRangeHigh;				// Maximum table O/P value
	USHORT srcIx = 0;
	T_TABLE_RETURN retValue = TABLE_OK;
	IPRangeLow = IPRangeHigh = inTable[srcIx].in;
	OPRangeLow = OPRangeHigh = inTable[srcIx].out;
	for (srcIx = 0; srcIx < noEntries; srcIx++) {
		// indexOf lowest and highest input values specified
		if (inTable[srcIx].in < IPRangeLow)
			IPRangeLow = inTable[srcIx].in;
		if (inTable[srcIx].in > IPRangeHigh)
			IPRangeHigh = inTable[srcIx].in;
		// indexOf lowest and highest output values specified
		if (inTable[srcIx].out < OPRangeLow)
			OPRangeLow = inTable[srcIx].out;
		if (inTable[srcIx].in > IPRangeHigh)
			OPRangeHigh = inTable[srcIx].out;
	}
	pSensorHdr->IPRangeLow = IPRangeLow;
	pSensorHdr->IPRangeHigh = IPRangeHigh;
	pSensorHdr->OPRangeLow = OPRangeLow;
	pSensorHdr->OPRangeHigh = OPRangeHigh;
	pSensorHdr->DeviceID = DeviceID;		///< The unique device identity ID
//	pSensorHdr->DeviceType = DeviceID;
	pSensorHdr->TableReadings = noEntries;
	pSensorHdr->CJLookup = FALSE;		///< The device table cannot be used as a CJ lookup
	pSensorHdr->Referenced = FALSE;	///< Table is currently not referenced by the CMM
	pSensorHdr->IPRangeType = AI_CHANNEL_TYPE_ENG;
	pSensorHdr->IPRangeUnits = UNITS;
	pSensorHdr->OPRangeType = AI_CHANNEL_TYPE_ENG;
	pSensorHdr->OPRangeUnits = UNITS;
	return retValue;
}
//**********************************************************************
///
/// Generate a linearisation table
///
/// @param[in]	inTable - ptr to an array of T_IP_TABLE_ELEMENT's forming the input table
/// @param[in]	noEntries - number of entries in the input table inTable
/// @param[in]	suggElements - suggested number of elements to generate, can extend the resolution of a table
/// @param[in]	direction - build a normal(NORMAL_TABLE) or reverse(REVERSE_TABLE) lookup from source table
/// 
/// @return		T_TABLE_RETURN value showing status
/// 
//**********************************************************************
T_TABLE_RETURN CLinearTable::GenerateTable(T_PIP_TABLE_ELEMENT inTable, const USHORT noEntries,
		const USHORT suggElements, const T_TABLE_TYPE direction, const BOOL ignorePointChecks /* = false */) {
	// Itterate through table and find the smallest gap, divide this between the limits and see if it's 
	// an acceptable table size
	m_sourceZero = inTable[0].in;
	m_sourceElemets = noEntries;
	m_sourceRange = inTable[noEntries - 1].in - inTable[0].in;	// Get absolute range
#ifdef DBG_FILE_LOG_LNR_TBL_DBG_ENABLE
	QString  strLogMessage;
	strLogMessage = QString::asprintf("CLinearTable::GenerateTable begin m_sourceZero %f m_sourceRange %f m_sourceElemets %d", m_sourceZero, m_sourceRange, m_sourceElemets);
	CLinearTable::LogDbgMessageToFile(strLogMessage);
	#endif
	// remove allocated tables in memory
	FreeTables();
	// Allocate a source table to store working linarisation table
	m_pSourceTable = new T_TABLE_ELEMENT[m_sourceElemets];
	if (m_pSourceTable == NULL) {
		return TERR_MEMORY_ALLOC_FAILED;
	}
	// Check for scale direction and indicate accordingly, 
	int srcIx;
	if (m_sourceRange < 0) {
		srcIx = noEntries - 1;
		m_tableDirection = TABLE_NEG;
	} else {
		srcIx = 0;
		m_tableDirection = TABLE_POS;
	}
	// Copy source table into working internal table, if reversed scale then 
	// reverse to make a +ve going scale for rest of calculation and lookup.
	for (int destIx = 0; destIx < noEntries; destIx++) {
		if (direction == NORMAL_TABLE) {
			// Forward looking table
			m_pSourceTable[destIx].in = inTable[srcIx].in;
			m_pSourceTable[destIx].out = inTable[srcIx].out;
		} else {
			// Reverse looking table
			m_pSourceTable[destIx].in = inTable[srcIx].out;
			m_pSourceTable[destIx].out = inTable[srcIx].in;
		}
		m_pSourceTable[destIx].ipfac = 0;
		srcIx += m_tableDirection;
	}
	// Check through source table, test for erros such as donkey legs and same readings
	// generate the interpollation factor.
	float lastVal = m_sourceZero;		// Get first entry
	float lastDiff = 0;	// diff between current and last entry, set to max float
	float lastDiffAbs = 0;	// diff between current and last entry, set to max float
	m_smallestGap = FLT_MAX;		// Smallest span found between table entries
	int i;								// Index counter
	for (i = 1; i < noEntries - 1; i++) {
		lastDiff = m_pSourceTable[i].in - lastVal;					// get abs difference, this maybe a -ve going scale
		lastDiffAbs = (float) fabs(lastDiff);
		if ( TRUE == ignorePointChecks) {
			// Check that the in entries are not the same for two different points	
			///< @todo check for no diffs in outgoing table
			if (lastDiffAbs == 0) {
				return TERR_TWO_ENTRIES_AT_SAME_POINT;
			}
			// Check that the table does not donkeylegg
			// +ve going table, so all entries should be greater then the last
			if (lastDiff < 0) {
				return TERR_DONKEY_LEG_DETECTED;
			}
		}
		// Check for smallest source table difference in span between elements
		if (lastDiffAbs < m_smallestGap) {
			m_smallestGap = lastDiffAbs;
		}
		lastVal = m_pSourceTable[i].in;
	}
	// To calculate the factor 	fac[n] = (tableout[n+1]-tableout[n])/(tablein[n+1]-tablein[n])
	// Calculate the interpolation factor, the relation between the slope of the input to that of the output.
	for (i = 0; i < noEntries - 1; i++) {
		m_pSourceTable[i].ipfac = (m_pSourceTable[i + 1].out - m_pSourceTable[i].out)
				/ (m_pSourceTable[i + 1].in - m_pSourceTable[i].in);
		m_pSourceTable[i].intercept =
				m_pSourceTable[i].out - (m_pSourceTable[i].ipfac * m_pSourceTable[i].in); //calculating the intercept value, to substitute in the equation y = mx+c
#ifdef DBG_FILE_LOG_LNR_TBL_DBG_ENABLE
		strLogMessage = QString::asprintf("CLT::GT SourceTable index %d x1 %f y1 %f x2 %f y2 %f ipfac(m) %f intercept(c) %f", i, 
			m_pSourceTable[i].in, 
			m_pSourceTable[i].out,
			m_pSourceTable[i+1].in, 
			m_pSourceTable[i+1].out,
			m_pSourceTable[i].ipfac,
			m_pSourceTable[i].intercept);
		CLinearTable::LogDbgMessageToFile(strLogMessage);
		#endif
	}
	m_pSourceTable[i].ipfac = m_pSourceTable[i - 1].ipfac; // Last elements slope contunues from previous straight line.
	m_pSourceTable[i].intercept = m_pSourceTable[i - 1].intercept; // Last elements intercept contunues from previous straight line.
	// Setup the reference table resolution
	float reqElements = (float) fabs(m_sourceRange / m_smallestGap) + 1;// indexOf the number of elements based on the smallest source table difference
	if (reqElements > TABLE_MAX_ELEMENTS)// the calculated number of elements exceeds the max table size allowed, cap to max table size.
			{
		reqElements = TABLE_MAX_ELEMENTS;
	}
	if (reqElements < suggElements)	// If the calculated number of elements is less then the suggested number, then use suggested
			{
		reqElements = suggElements;
	}
	m_refElements = (int) reqElements;	// Set the number of elements of the reference table.
	// Generate the reference, allocate the reference table with the required resolution
	m_pReferenceTable = new T_TABLE_ELEMENT*[m_refElements];
	if (m_pReferenceTable == NULL) {
		return TERR_MEMORY_ALLOC_FAILED;
	}
	m_srcElementStep = (float) (fabs(m_sourceRange) / m_refElements);	// Calculate source step units
#ifdef DBG_FILE_LOG_LNR_TBL_DBG_ENABLE
	strLogMessage = QString::asprintf("CLT::GT m_srcElementStep %f source Range %f RefElements %f", m_srcElementStep,
	m_sourceRange, m_refElements);
	CLinearTable::LogDbgMessageToFile(strLogMessage);
	#endif
	float currStep = m_pSourceTable[0].in;
	int sourceTableElement = 0;
	// Build linear pointer table to non-liner source table, an entry for every m_srcElementStep in the source scale
	// contains pointer to relevant entry in source table. 
	for (i = 0; i < m_refElements; i++) {
		if (currStep < m_pSourceTable[sourceTableElement + 1].in) {
			m_pReferenceTable[i] = &m_pSourceTable[sourceTableElement];	// Entries fall within current index
		} else {
			sourceTableElement++;					// Entry falls in next index
			if (sourceTableElement >= m_sourceElemets)
				sourceTableElement = m_sourceElemets - 1;
			m_pReferenceTable[i] = &m_pSourceTable[sourceTableElement];
		}
//		sprintf(debugtxt,"ix(%d) source(%f) dest index(%d) \n", i, currStep, sourceTableElement );
//		OutputDebugString(debugtxt);
#ifdef DBG_FILE_LOG_LNR_TBL_DBG_ENABLE
		strLogMessage = QString::asprintf("CLT::GT Build linear pointer table ix %d source %f dest_index %d", i, currStep, sourceTableElement);
		CLinearTable::LogDbgMessageToFile(strLogMessage);
		strLogMessage = QString::asprintf("CLT::GT Ref table ix %d in %f out %f ipfac %f intercept %f", i, 
			m_pReferenceTable[i]->in,
			m_pReferenceTable[i]->out,
			m_pReferenceTable[i]->ipfac,
			m_pReferenceTable[i]->intercept);
		CLinearTable::LogDbgMessageToFile(strLogMessage);
		#endif
		currStep += m_srcElementStep;
	}
#ifdef DBG_FILE_LOG_LNR_TBL_DBG_ENABLE
	strLogMessage = QString::asprintf("CLinearTable::GenerateTable End m_refElements %d m_sourceElemets %d", m_refElements, m_sourceElemets);
	CLinearTable::LogDbgMessageToFile(strLogMessage);
	#endif
	return TABLE_OK;
}
//**********************************************************************
///
/// Lookup a value from a table
///
/// @param[in]	inVal - Input value to lookup in table
/// 
/// @return		corrisponding table value to inVal passed.
/// 
/// Rev History
/// @Version	@Date			@Author					@Remarks
/// 2.0			09/May/2019		Shankar Rao	Pendyala	TVR220 - Consider direct lookup table entry for actual values present in tables
///														And lineraization is only for intermediate values with in the range
//**********************************************************************
float CLinearTable::LookUpValue(const float inVal) const {
	UINT i = 0;
	BOOL bWithInRange = FALSE;
	for (i = 0; i < m_sourceElemets; i++) {
		////TVR200 - fix for the array out of bounds in case of extreme boundary conditions
		if ((inVal >= m_pSourceTable[i].in)) {
			if ((i + 1 < m_sourceElemets) && (inVal <= m_pSourceTable[i + 1].in)) {
				bWithInRange = TRUE;
				break;
			}
		}
	}
	if (!bWithInRange) {
		if (inVal < m_pSourceTable[0].in) {
			i = 0;
		} else if (inVal > m_pSourceTable[i - 1].in) {
			i--;
		}
	}
	//m is slope, where m = (y2-y1)/(x2-x1)
	//c is the Y Intercept (where the line crosses the Y axis)
	//straight line equation formula 
	//y=				m			x	+ c
	return (m_pSourceTable[i].ipfac * inVal) + m_pSourceTable[i].intercept;
}
//**********************************************************************
///
/// Performs a reverse lookup to get us back to an original pre-conditioned reading
///
/// @param[in]	conditionedReading - conditioned reading wew want to reverse back to it's original value
/// 
/// @return		corresponding unconditioned table value
/// 
//**********************************************************************
const float CLinearTable::ReverseLookUpValue(const float conditionedReading) const {
	float rawValue = conditionedReading;
	UINT setpointIndex = 0;
	BOOL bWithInRange = FALSE;
	for (setpointIndex = 0; setpointIndex < m_sourceElemets; setpointIndex++) {
		////TVR200 - fix for the array out of bounds in case of extreme boundary conditions
		if ((conditionedReading >= m_pSourceTable[setpointIndex].out)) {
			if ((setpointIndex + 1 < m_sourceElemets)
					&& (conditionedReading <= m_pSourceTable[setpointIndex + 1].out)) {
				bWithInRange = TRUE;
				break;
			}
		}
	}
	if (!bWithInRange) {
		if (conditionedReading < m_pSourceTable[0].out) {
			setpointIndex = 0;
		} else if (conditionedReading > m_pSourceTable[setpointIndex - 1].out) {
			setpointIndex--;
		}
	}
	// reverse the equation y = mx + c
	rawValue -= m_pSourceTable[setpointIndex].intercept;
	rawValue /= m_pSourceTable[setpointIndex].ipfac;
	return rawValue;
}
#if defined (DBG_FILE_LOG_LNR_TBL_DBG_ENABLE)
//**********************************************************************
/// Output debug info on Linear Table (for debug purposes only)
///
/// @param[in] strLogMessage - Log message buffer 
/// @return	nothing 
/// 
//**********************************************************************
void CLinearTable::LogDbgMessageToFile(QString  strLogMessage)
{
	QString  strDbgMessage;
	strDbgMessage = QString::asprintf("%s - GTC:%d\r\n", strLogMessage, GetTickCount() );
	m_debugFileLogger.WriteToDebugLogFile(strDbgMessage);
}
#endif

/******************************************************************************************
 COPYRIGHT (c) 2004
 HONEYWELL INC.,
 ALL RIGHTS RESERVED
 This software is a copyrighted work and/or information protected
 as a trade secret. Legal rights of Honeywell Inc. in this
 software is distinct from ownership of any medium in which the
 software is embodied. Copyright or trade secret notices included
 must be reproduced in any copies authorized by Honeywell Inc.
 The information in this software is subject to change without
 notice and should not be considered as a commitment by Honeywell
 Inc.
 ******************************************************************************************
 Project              : Debug Trace Logging Module
 Module               : 
 FileName             : TraceLog.h
 Author(s)            : Martin M
 Description          : Trace logging declarations
 Date Of Creation     : 12/07/2004
 Modification History : 
 Name					Date								Modifications
 ----					-----								-------------
 Martin M 12/07/2004     Created
 *******************************************************************************************/
/// @file 
/// **************************************************************************
/// Honeywell Trendview
/// **************************************************************************
/// @n Module: 	   Debug Trace Loging 
/// @n Filename:     TraceLog.h 
/// @n Description:  Main trace log class declaration 
///
//  **************************************************************************
//  Revision History
//  **************************************************************************
//  $Log:
//   3     Stability Project 1.0.1.1      7/2/2011 5:02:09 PM     Hemant(HAIL) 
//          Stability Project: Recorder source has been upgraded from IL
//        version of firmware to JF version of firmware.
//   2     Stability Project 1.0.1.0      7/1/2011 4:26:43 PM     Hemant(HAIL) 
//          Stability Project: Files has been checked in before the merging
//        task. The merging will be done between IL version of firmware and JF
//        version of firmware. 
//   1     V6 Firmware 1.0          8/12/2004 3:55:06 PM    Martin Miller   
//  $
//
//  **************************************************************************
// Trace.h : main header file for the TRACE application
//
#if !defined(__TRACE_H__)
#define __TRACE_H__
#include "TVtime.h"
#include <QMutex>
#define MAX_MESSAGE_LEN	512
#define TRACE_FILTER	0xffff
// Message levels
enum _MESSAGE_LEVELS_ {
	LEVEL_INFO = 0, LEVEL_TESTPOINT, LEVEL_WARNING, LEVEL_ERROR, LEVEL_CRITICAL
};
//**Class*********************************************************************
///
/// @brief  CTraceLog singleton class 
/// 
///  Accepts trace messages, filters by module, 
///  maintains log start and date change messages,
///  expands arguments and passes the text to the Destination class 
///
//****************************************************************************
class CTraceLog {
public:
	void Header(unsigned long Module, int Level, char *File, char *Function, short Line);
	void Message(QString Message, ...);
	static CTraceLog* Instance();
	virtual ~CTraceLog();
protected:
	CTraceLog();
	CTraceLog(const CTraceLog&);
	CTraceLog& operator=(const CTraceLog&);
private:
	void DefaultOutput(QString Text);
	void Output(char Type, char Level, QString Text);
	class CTVtime m_LastMessageTime;					///< Last/previous message time and date
	class CTVtime m_ThisMessageTime;					///< Current message time and date
	char m_FirstMessage;								///< TRUE for the first message (used for log started message)
	int m_LastLevel;						///< Last message level (used for a default if no further level is given)
	unsigned long m_LastModule;				///< Last message module (used for a default if no further module is given)
	WCHAR m_Buffer[MAX_MESSAGE_LEN];               					///< Message work space
	static CTraceLog *m_pInstance;						///< Singleton instance pointer
	static QMutex hCreationMutex;						///< Singleton creation mutex
	static QMutex csTrace;
};
// Wrapper macros, dummy these to remove trace messages
#define _INFO_		Trace->Header( __MODULE__, LEVEL_INFO, __FILE__, __METHOD__, __LINE__ );
#define _TESTPOINT_ Trace->Header( __MODULE__, LEVEL_TESTPOINT, __FILE__, __METHOD__, __LINE__ );
#define _WARNING_	Trace->Header( __MODULE__, LEVEL_WARNING, __FILE__, __METHOD__, __LINE__ );
#define _ERROR_		Trace->Header( __MODULE__, LEVEL_ERROR, __FILE__, __METHOD__, __LINE__ );
#define _CRITICAL_	Trace->Header( __MODULE__, LEVEL_CRITICAL, __FILE__, __METHOD__, __LINE__ );
#define MESSAGE		Trace->Message
#define V6INFO		_INFO_		MESSAGE
#define V6TESTPOINT	_TESTPOINT_	MESSAGE
#define V6WARNING	_WARNING_	MESSAGE
#define V6ERROR		_ERROR_		MESSAGE
#define V6CRITICAL	_CRITICAL_	MESSAGE
#define USES_TRACE 	CTraceLog *Trace = CTraceLog::Instance( );
// Primary modules, used for filtering
#define MODULE_DATA_IO			0x01
#define MODULE_DTAT_PROCESS		0x02
#define MODULE_DATA_STORE		0x04
#define MODULE_CONTROL			0x08
#define MODULE_SERVICES			0x10
#define MODULE_COMMUNICATE		0x20
#define MODULE_USER_IF			0x40
#define MODULE_PERIPHERAL		0x80
#define MODULE_MISC				0x100
#endif // !defined(__TRACE_H__)

/// @file 
/// *****************************************************************
/// © Honeywell Trendview
/// *****************************************************************
/// @n Module : Module Message Manager (MMM )
/// @n FileName: InternalMessageQueueStats.cpp
/// @n Desc  : Implementation File for the CInternalMessageQueueStats Class
///  
/// *****************************************************************
/// @b Revision @b History
/// *****************************************************************
/// $Log[4]:
/// 6 Stability Project 1.1.1.3 7/2/2011 4:58:00 PM Hemant(HAIL) 
/// Stability Project: Recorder source has been upgraded from IL
///  version of firmware to JF version of firmware.
/// 5 Stability Project 1.1.1.2 7/1/2011 4:38:21 PM Hemant(HAIL) 
/// Stability Project: Files has been checked in before the merging
///  task. The merging will be done between IL version of firmware and JF
///  version of firmware. 
/// 4 Stability Project 1.1.1.1 3/17/2011 3:20:25 PM  Hemant(HAIL) 
/// Implemented "#ifdef _STD_HEAP_IMPLMT_" for default functioning of
///  new operator in DEBUG mode only. To detect memory leaks in files, use
///  it in preprocessor definition when in debug mode.
/// 3 Stability Project 1.1.1.0 2/15/2011 3:03:10 PM  Hemant(HAIL) 
/// File updated during Heap Management. Call to the default behaviour
///  of new operator has been commented.
/// $
///
#include "InternalMessageQueueStats.h"
#include "Defines.h"
//****************************************************************************
/// CInternalMessageQueueStats Constructor
///
//****************************************************************************
CInternalMessageQueueStats::CInternalMessageQueueStats(void) {
	// Initialise Member Variables
	//
	m_IMQueueLoad = 0;
	m_IMQTotalNumberOfMessagesProcessed = 0;
} // End of Constructor
//****************************************************************************
/// CInternalMessageQueueStats Constructor
///
//****************************************************************************
CInternalMessageQueueStats::~CInternalMessageQueueStats(void) {
} // End of Destructor
